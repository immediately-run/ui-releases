var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
require("./index.css");
require("./lib-ui/styles.css");
var _sdk = _interopRequireDefault(require("./lib-ui/sdk"));
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// Root component — immediately.run renders the default export of THIS file.
// Global CSS is imported here (not main.tsx). The shipped app is now assembled
// entirely from the headless library + its SDK adapter (`<SdkFileExplorer/>`) —
// the parity proof for the file-explorer-library extraction.

function App() {
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_sdk.default, {});
}
_c = App;
var _default = exports.default = App;
var _c;
$RefreshReg$(_c, "App");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJyZXF1aXJlIiwiX3NkayIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJfanN4UnVudGltZSIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsIkFwcCIsImpzeCIsIl9jIiwiX2RlZmF1bHQiLCJleHBvcnRzIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQXBwLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBSb290IGNvbXBvbmVudCDigJQgaW1tZWRpYXRlbHkucnVuIHJlbmRlcnMgdGhlIGRlZmF1bHQgZXhwb3J0IG9mIFRISVMgZmlsZS5cbi8vIEdsb2JhbCBDU1MgaXMgaW1wb3J0ZWQgaGVyZSAobm90IG1haW4udHN4KS4gVGhlIHNoaXBwZWQgYXBwIGlzIG5vdyBhc3NlbWJsZWRcbi8vIGVudGlyZWx5IGZyb20gdGhlIGhlYWRsZXNzIGxpYnJhcnkgKyBpdHMgU0RLIGFkYXB0ZXIgKGA8U2RrRmlsZUV4cGxvcmVyLz5gKSDigJRcbi8vIHRoZSBwYXJpdHkgcHJvb2YgZm9yIHRoZSBmaWxlLWV4cGxvcmVyLWxpYnJhcnkgZXh0cmFjdGlvbi5cbmltcG9ydCBcIi4vaW5kZXguY3NzXCI7XG5pbXBvcnQgXCIuL2xpYi11aS9zdHlsZXMuY3NzXCI7XG5pbXBvcnQgU2RrRmlsZUV4cGxvcmVyIGZyb20gXCIuL2xpYi11aS9zZGtcIjtcblxuZnVuY3Rpb24gQXBwKCkge1xuICByZXR1cm4gPFNka0ZpbGVFeHBsb3JlciAvPjtcbn1cblxuZXhwb3J0IGRlZmF1bHQgQXBwO1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFJQUEsT0FBQTtBQUNBQSxPQUFBO0FBQ0EsSUFBQUMsSUFBQSxHQUFBQyxzQkFBQSxDQUFBRixPQUFBO0FBQTJDLElBQUFHLFdBQUEsR0FBQUgsT0FBQTtBQUFBLFNBQUFFLHVCQUFBRSxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBTjNDO0FBQ0E7QUFDQTtBQUNBOztBQUtBLFNBQVNHLEdBQUdBLENBQUEsRUFBRztFQUNiLG9CQUFPLElBQUFKLFdBQUEsQ0FBQUssR0FBQSxFQUFDUCxJQUFBLENBQUFLLE9BQWUsSUFBRSxDQUFDO0FBQzVCO0FBQUNHLEVBQUEsR0FGUUYsR0FBRztBQUFBLElBQUFHLFFBQUEsR0FBQUMsT0FBQSxDQUFBTCxPQUFBLEdBSUdDLEdBQUc7QUFBQSxJQUFBRSxFQUFBO0FBQUFHLFlBQUEsQ0FBQUgsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}