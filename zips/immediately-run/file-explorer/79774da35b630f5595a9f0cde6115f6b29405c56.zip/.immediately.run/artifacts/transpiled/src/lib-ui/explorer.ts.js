"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.uploadTargetDir = exports.uploadRowFromEvent = exports.toMountRel = exports.subtreeLabel = exports.orderMounts = exports.moveRejection = exports.moveRefusalLabel = exports.mountSpaceId = exports.mountScopes = exports.mountLabel = exports.mountKind = exports.joinRel = exports.joinPath = exports.isWritableMount = exports.isProtected = exports.isEjectable = exports.grantedModeAt = exports.dirOf = exports.breadcrumbFor = exports.basename = exports.WRITE_ERR = exports.MOVE_MIME = exports.MAX_UPLOAD_BYTES = void 0;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.find.js");
// Pure helpers for the file explorer — path math, root metadata read from the
// generalized ExplorerRoot, and the move/upload/drag validity predicates.
// Framework-free and side-effect-free so they unit-test directly (ways_of_working
// §5; file-explorer CLAUDE.md). No React, NO SDK import here — the view reads
// roots through ExplorerRoot, and the SDK adapter (`sdk/mounts.ts`) is what maps
// a SandboxMount onto that shape.

/** Join a directory and a child name into one normalized absolute/rel path. */
const joinPath = (dir, name) => `${dir.replace(/\/+$/, "")}/${name}`;

/** The last path segment (basename) of a slash path. */
exports.joinPath = joinPath;
const basename = p => p.split("/").filter(Boolean).pop() ?? "";

/** The parent directory of a slash path (no trailing slash; "/" for a root child). */
exports.basename = basename;
const dirOf = p => {
  const trimmed = p.replace(/\/+$/, "");
  const i = trimmed.lastIndexOf("/");
  return i <= 0 ? "/" : trimmed.slice(0, i);
};

/** A mount-absolute path made repo-/mount-relative (leading slash) for the SDK
 *  intents, which take mount-relative paths (e.g. `/src/App.tsx`). */
exports.dirOf = dirOf;
const toMountRel = (rootPath, absPath) => absPath.slice(rootPath.replace(/\/+$/, "").length) || "/";

/** The inverse of {@link toMountRel}: a mount-relative dir ("/src") made
 *  absolute under `rootPath` ("<root>/src"); "/" maps to the root itself. */
exports.toMountRel = toMountRel;
const joinRel = (rootPath, relDir) => {
  const normalized = normalizeRel(relDir);
  return normalized === "/" ? rootPath.replace(/\/+$/, "") : joinPath(rootPath, normalized.slice(1));
};

// ---------------------------------------------------------------------------
// Root metadata (R3-79 / FILE_EXPLORER_SPEC §2) — over the generalized
// ExplorerRoot. The SDK adapter populates these fields from a SandboxMount; the
// view reads them through these accessors so the layouts stay decoupled.
// ---------------------------------------------------------------------------

/** A human-readable scope label (already resolved onto the root by the adapter). */
exports.joinRel = joinRel;
const mountLabel = r => r.label;

/** The provider/type kind of a root, for the App-scope header icon (PRINCIPALS
 *  §9 B1). A classifier only — the icon mapping lives in the view. */
exports.mountLabel = mountLabel;
const mountKind = r => r.kind;

/** The spaceId of a space root, for eject (`unmountSpace`). Null for roots that
 *  aren't ejectable spaces (worktree, settings). */
exports.mountKind = mountKind;
const mountSpaceId = r => r.spaceId ?? null;

/**
 * Whether the explorer offers an EJECT (detach) affordance on this root
 * (SPACES_UI_SPEC §3, R-SPACES-3). Eject = `unmountSpace` — closes the space for
 * this session only; it is NOT leave/revoke. Offered for spaces / granted
 * subtrees; NEVER for the worktree or the per-app `settings:` store.
 */
exports.mountSpaceId = mountSpaceId;
const isEjectable = r => !!r.ejectable;

/**
 * Whether the explorer should offer WRITE affordances (new/rename/delete/upload/
 * move) on this root. The adapter computes effective writability; the view just
 * reflects it — the affordances are HIDDEN on a read-only root, never
 * shown-then-`EROFS` (CLAUDE.md: never surface `EROFS` as UX).
 */
exports.isEjectable = isEjectable;
const isWritableMount = r => r.writable;

/** A mount-relative path in one shape: leading slash, no trailing slash. */
exports.isWritableMount = isWritableMount;
const normalizeRel = p => {
  const trimmed = (p || "/").replace(/\/+$/, "");
  if (trimmed === "") return "/";
  return trimmed.startsWith("/") ? trimmed : `/${trimmed}`;
};

/**
 * The mode the app actually HOLDS at `relPath` in this root — longest matching
 * `grants` prefix wins, exactly as the host resolves a delegation against its rule
 * set. `ro` when nothing is known, so a missing rule-set can only ever under-ask.
 *
 * This is the mode to DELEGATE at (R3-267 / R3-266: dispatch changes the packaging,
 * not the authority — the mount decides whether the opened viewer can edit). It is
 * NOT {@link isWritableMount}, which answers a different question: whether the
 * explorer itself offers create/rename/delete here.
 */
const grantedModeAt = (r, relPath) => {
  const target = normalizeRel(relPath);
  let best = -1;
  let mode = "ro";
  for (const rule of r.grants ?? []) {
    const subtree = normalizeRel(rule.subtree);
    const covers = subtree === "/" || target === subtree || target.startsWith(`${subtree}/`);
    if (covers && subtree.length > best) {
      best = subtree.length;
      mode = rule.mode;
    }
  }
  return mode;
};

/** One display row in the App-scope header: a granted subtree and the mode shown
 *  there (PRINCIPALS §9 B1 / FILE_EXPLORER §2). */
exports.grantedModeAt = grantedModeAt;
/**
 * The granted scopes of a root as display rows — one per scope, so a root with
 * several subtrees lists each (FILE_EXPLORER §2 step 2). Falls back to a single
 * whole-mount row from the root's effective writability when `scopes` is absent.
 * The displayed mode is the EFFECTIVE mode the adapter already baked into each
 * scope. De-duped by subtree and ordered root-first then A→Z.
 */
const mountScopes = r => {
  const fallbackMode = isWritableMount(r) ? "rw" : "ro";
  const scopes = r.scopes?.length ? r.scopes : [{
    subtree: "/",
    mode: fallbackMode
  }];
  const seen = new Map();
  for (const s of scopes) {
    const subtree = s.subtree && s.subtree.trim() && s.subtree !== "/" ? s.subtree.trim() : "/";
    if (seen.has(subtree)) continue;
    seen.set(subtree, {
      subtree,
      mode: s.mode
    });
  }
  return [...seen.values()].sort((a, b) => a.subtree === "/" ? -1 : b.subtree === "/" ? 1 : a.subtree.localeCompare(b.subtree));
};

/** A short subtree label for the single-chip layouts (breadcrumb / columns) where
 *  only the current directory's owning root is shown ("/" for a whole-mount grant).
 *  The per-mount header uses {@link mountScopes} for the full list. */
exports.mountScopes = mountScopes;
const subtreeLabel = r => {
  const first = r.scopes?.[0];
  return first?.subtree && first.subtree !== "/" ? first.subtree : "/";
};

/** Order roots for display: worktree first, then spaces, then others, A→Z. */
exports.subtreeLabel = subtreeLabel;
const orderMounts = roots => [...roots].sort((a, b) => {
  const rank = r => r.kind === "worktree" ? 0 : r.kind === "space" ? 1 : 2;
  return rank(a) - rank(b) || mountLabel(a).localeCompare(mountLabel(b));
});

// Files the host refuses to delete/rename — hide the affordance to match (the
// host also enforces it, returning `protected`). Shared by every layout so the
// gating is identical in tree / list / icons / columns. Mount-relative paths.
exports.orderMounts = orderMounts;
const PROTECTED = new Set(["/package.json"]);

/** Is this mount-relative path one the host protects from delete/rename? */
const isProtected = mountRel => PROTECTED.has(mountRel);

// ---------------------------------------------------------------------------
// Breadcrumb / current-directory navigation (R3-84 list + icons layouts)
// ---------------------------------------------------------------------------
exports.isProtected = isProtected;
/**
 * Resolve a current directory (`cwd`, absolute or null = the Spaces root) into the
 * owning root and a breadcrumb trail. The trail always starts at "Spaces" so the
 * user can step back out to the root list (mirroring the mobile projection in
 * brief 13). When `cwd` falls inside a root, segments are: Spaces > <root> >
 * <subdir...>. When `cwd` is null (or unresolvable), only the Spaces root is shown.
 * Pure — no React, no I/O.
 */
const breadcrumbFor = (cwd, ordered) => {
  const root = {
    label: "Spaces",
    path: null
  };
  if (!cwd) return {
    mount: null,
    crumbs: [root]
  };
  const mount = ordered.find(m => cwd === m.path || cwd.startsWith(m.path + "/")) ?? null;
  if (!mount) return {
    mount: null,
    crumbs: [root]
  };
  const crumbs = [root, {
    label: mountLabel(mount),
    path: mount.path
  }];
  const rel = toMountRel(mount.path, cwd); // e.g. "/src/components" or "/"
  const segs = rel.split("/").filter(Boolean);
  let acc = mount.path;
  for (const seg of segs) {
    acc = joinPath(acc, seg);
    crumbs.push({
      label: seg,
      path: acc
    });
  }
  return {
    mount,
    crumbs
  };
};

// ---------------------------------------------------------------------------
// Drag-and-drop validity (R3-81 move / R3-82 upload)
// ---------------------------------------------------------------------------

/** Private MIME the explorer sets on an internal (same-app) move drag, so an
 *  internal row drag is distinguishable from an OS-file drop and a §7 drag-out. */
exports.breadcrumbFor = breadcrumbFor;
const MOVE_MIME = exports.MOVE_MIME = "application/x-ir-file-move";
/**
 * Can `from` be moved INTO directory `targetDir` (both absolute paths in the same
 * mount)? Rejects: a no-op (already in that dir), a directory dropped onto itself
 * or a descendant, and (the caller enforces) cross-mount drops. Returns the reason
 * code on rejection so the UI can hint, or `null` when the move is allowed.
 */
const moveRejection = (from, targetDir, fromRoot, targetRoot) => {
  if (fromRoot !== targetRoot) return "cross-mount";
  if (dirOf(from) === targetDir.replace(/\/+$/, "")) return "same-dir";
  const f = from.replace(/\/+$/, "");
  const t = targetDir.replace(/\/+$/, "");
  if (t === f || t.startsWith(f + "/")) return "into-self";
  return null;
};

/** The human sentence for a destination the move refuses, or null when it
 *  doesn't — the move picker's disabled-button reason. */
exports.moveRejection = moveRejection;
const moveRefusalLabel = (target, dirAbs, dirRootPath) => {
  const reason = moveRejection(target.absPath, dirAbs, target.rootPath, dirRootPath);
  if (reason === "cross-mount") return WRITE_ERR["cross-mount"];
  if (reason === "same-dir") return `${target.name} is already in this folder.`;
  if (reason === "into-self") return "A folder can’t move into itself.";
  return null;
};

/**
 * Where an OS-file drop lands (`FILE_EXPLORER_SPEC §5`): the directory row under
 * the pointer, the PARENT of a file row, or the scope root when the drop misses
 * every row — a drop on the blank space below the tree, or on the scope header.
 * The §5 upload BUTTON resolves its destination through the same shape: its
 * "row" is the SELECTION (a selected dir itself, a selected file's parent)
 * and the fallback is the repo root when nothing is selected.
 *
 * `row` is what the drop point resolves to, or `null` when it resolves to nothing.
 * Directory rows answer this for themselves before the event reaches a container,
 * so in practice this decides the two cases that used to be silent no-ops.
 */
exports.moveRefusalLabel = moveRefusalLabel;
const uploadTargetDir = (row, scopeRoot) => row ? row.isDir ? row.path : dirOf(row.path) : scopeRoot;

/**
 * The DOM→row half of an OS-file drop (R3-626): resolve the element the drop
 * landed on to a row via the `data-path`/`data-dir` attributes every row
 * carries, then `uploadTargetDir` against the container's fallback. ONE home —
 * the flat containers' hook and the tree's scope resolve identically, and this
 * is the block that must not drift between them.
 */
exports.uploadTargetDir = uploadTargetDir;
const uploadRowFromEvent = (e, fallbackDir) => {
  const el = e.target?.closest?.("[data-path]") ?? null;
  const row = el ? {
    path: el.getAttribute("data-path") ?? fallbackDir,
    isDir: el.getAttribute("data-dir") === "1"
  } : null;
  return uploadTargetDir(row, fallbackDir);
};

/** A soft client cap on inlined upload/drag bytes; the host enforces the real one. */
exports.uploadRowFromEvent = uploadRowFromEvent;
const MAX_UPLOAD_BYTES = exports.MAX_UPLOAD_BYTES = 512 * 1024;

/** Map a host write-outcome code to a friendly message (shared by every mutation). */
const WRITE_ERR = exports.WRITE_ERR = {
  exists: "Something with that name already exists.",
  protected: "That file can’t be deleted.",
  "too-large": "That file is too large to upload.",
  "not-found": "That file no longer exists.",
  forbidden: "You don’t have permission to change files here.",
  "invalid-params": "That name isn’t valid.",
  "cross-mount": "Can’t move between spaces yet."
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJqb2luUGF0aCIsImRpciIsIm5hbWUiLCJyZXBsYWNlIiwiZXhwb3J0cyIsImJhc2VuYW1lIiwicCIsInNwbGl0IiwiZmlsdGVyIiwiQm9vbGVhbiIsInBvcCIsImRpck9mIiwidHJpbW1lZCIsImkiLCJsYXN0SW5kZXhPZiIsInNsaWNlIiwidG9Nb3VudFJlbCIsInJvb3RQYXRoIiwiYWJzUGF0aCIsImxlbmd0aCIsImpvaW5SZWwiLCJyZWxEaXIiLCJub3JtYWxpemVkIiwibm9ybWFsaXplUmVsIiwibW91bnRMYWJlbCIsInIiLCJsYWJlbCIsIm1vdW50S2luZCIsImtpbmQiLCJtb3VudFNwYWNlSWQiLCJzcGFjZUlkIiwiaXNFamVjdGFibGUiLCJlamVjdGFibGUiLCJpc1dyaXRhYmxlTW91bnQiLCJ3cml0YWJsZSIsInN0YXJ0c1dpdGgiLCJncmFudGVkTW9kZUF0IiwicmVsUGF0aCIsInRhcmdldCIsImJlc3QiLCJtb2RlIiwicnVsZSIsImdyYW50cyIsInN1YnRyZWUiLCJjb3ZlcnMiLCJtb3VudFNjb3BlcyIsImZhbGxiYWNrTW9kZSIsInNjb3BlcyIsInNlZW4iLCJNYXAiLCJzIiwidHJpbSIsImhhcyIsInNldCIsInZhbHVlcyIsInNvcnQiLCJhIiwiYiIsImxvY2FsZUNvbXBhcmUiLCJzdWJ0cmVlTGFiZWwiLCJmaXJzdCIsIm9yZGVyTW91bnRzIiwicm9vdHMiLCJyYW5rIiwiUFJPVEVDVEVEIiwiU2V0IiwiaXNQcm90ZWN0ZWQiLCJtb3VudFJlbCIsImJyZWFkY3J1bWJGb3IiLCJjd2QiLCJvcmRlcmVkIiwicm9vdCIsInBhdGgiLCJtb3VudCIsImNydW1icyIsImZpbmQiLCJtIiwicmVsIiwic2VncyIsImFjYyIsInNlZyIsInB1c2giLCJNT1ZFX01JTUUiLCJtb3ZlUmVqZWN0aW9uIiwiZnJvbSIsInRhcmdldERpciIsImZyb21Sb290IiwidGFyZ2V0Um9vdCIsImYiLCJ0IiwibW92ZVJlZnVzYWxMYWJlbCIsImRpckFicyIsImRpclJvb3RQYXRoIiwicmVhc29uIiwiV1JJVEVfRVJSIiwidXBsb2FkVGFyZ2V0RGlyIiwicm93Iiwic2NvcGVSb290IiwiaXNEaXIiLCJ1cGxvYWRSb3dGcm9tRXZlbnQiLCJlIiwiZmFsbGJhY2tEaXIiLCJlbCIsImNsb3Nlc3QiLCJnZXRBdHRyaWJ1dGUiLCJNQVhfVVBMT0FEX0JZVEVTIiwiZXhpc3RzIiwicHJvdGVjdGVkIiwiZm9yYmlkZGVuIl0sInNvdXJjZXMiOlsiZXhwbG9yZXIudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gUHVyZSBoZWxwZXJzIGZvciB0aGUgZmlsZSBleHBsb3JlciDigJQgcGF0aCBtYXRoLCByb290IG1ldGFkYXRhIHJlYWQgZnJvbSB0aGVcbi8vIGdlbmVyYWxpemVkIEV4cGxvcmVyUm9vdCwgYW5kIHRoZSBtb3ZlL3VwbG9hZC9kcmFnIHZhbGlkaXR5IHByZWRpY2F0ZXMuXG4vLyBGcmFtZXdvcmstZnJlZSBhbmQgc2lkZS1lZmZlY3QtZnJlZSBzbyB0aGV5IHVuaXQtdGVzdCBkaXJlY3RseSAod2F5c19vZl93b3JraW5nXG4vLyDCpzU7IGZpbGUtZXhwbG9yZXIgQ0xBVURFLm1kKS4gTm8gUmVhY3QsIE5PIFNESyBpbXBvcnQgaGVyZSDigJQgdGhlIHZpZXcgcmVhZHNcbi8vIHJvb3RzIHRocm91Z2ggRXhwbG9yZXJSb290LCBhbmQgdGhlIFNESyBhZGFwdGVyIChgc2RrL21vdW50cy50c2ApIGlzIHdoYXQgbWFwc1xuLy8gYSBTYW5kYm94TW91bnQgb250byB0aGF0IHNoYXBlLlxuaW1wb3J0IHR5cGUgeyBFeHBsb3JlclJvb3QgfSBmcm9tIFwiLi90eXBlc1wiO1xuXG4vKiogSm9pbiBhIGRpcmVjdG9yeSBhbmQgYSBjaGlsZCBuYW1lIGludG8gb25lIG5vcm1hbGl6ZWQgYWJzb2x1dGUvcmVsIHBhdGguICovXG5leHBvcnQgY29uc3Qgam9pblBhdGggPSAoZGlyOiBzdHJpbmcsIG5hbWU6IHN0cmluZyk6IHN0cmluZyA9PlxuICBgJHtkaXIucmVwbGFjZSgvXFwvKyQvLCBcIlwiKX0vJHtuYW1lfWA7XG5cbi8qKiBUaGUgbGFzdCBwYXRoIHNlZ21lbnQgKGJhc2VuYW1lKSBvZiBhIHNsYXNoIHBhdGguICovXG5leHBvcnQgY29uc3QgYmFzZW5hbWUgPSAocDogc3RyaW5nKTogc3RyaW5nID0+IHAuc3BsaXQoXCIvXCIpLmZpbHRlcihCb29sZWFuKS5wb3AoKSA/PyBcIlwiO1xuXG4vKiogVGhlIHBhcmVudCBkaXJlY3Rvcnkgb2YgYSBzbGFzaCBwYXRoIChubyB0cmFpbGluZyBzbGFzaDsgXCIvXCIgZm9yIGEgcm9vdCBjaGlsZCkuICovXG5leHBvcnQgY29uc3QgZGlyT2YgPSAocDogc3RyaW5nKTogc3RyaW5nID0+IHtcbiAgY29uc3QgdHJpbW1lZCA9IHAucmVwbGFjZSgvXFwvKyQvLCBcIlwiKTtcbiAgY29uc3QgaSA9IHRyaW1tZWQubGFzdEluZGV4T2YoXCIvXCIpO1xuICByZXR1cm4gaSA8PSAwID8gXCIvXCIgOiB0cmltbWVkLnNsaWNlKDAsIGkpO1xufTtcblxuLyoqIEEgbW91bnQtYWJzb2x1dGUgcGF0aCBtYWRlIHJlcG8tL21vdW50LXJlbGF0aXZlIChsZWFkaW5nIHNsYXNoKSBmb3IgdGhlIFNES1xuICogIGludGVudHMsIHdoaWNoIHRha2UgbW91bnQtcmVsYXRpdmUgcGF0aHMgKGUuZy4gYC9zcmMvQXBwLnRzeGApLiAqL1xuZXhwb3J0IGNvbnN0IHRvTW91bnRSZWwgPSAocm9vdFBhdGg6IHN0cmluZywgYWJzUGF0aDogc3RyaW5nKTogc3RyaW5nID0+XG4gIGFic1BhdGguc2xpY2Uocm9vdFBhdGgucmVwbGFjZSgvXFwvKyQvLCBcIlwiKS5sZW5ndGgpIHx8IFwiL1wiO1xuXG4vKiogVGhlIGludmVyc2Ugb2Yge0BsaW5rIHRvTW91bnRSZWx9OiBhIG1vdW50LXJlbGF0aXZlIGRpciAoXCIvc3JjXCIpIG1hZGVcbiAqICBhYnNvbHV0ZSB1bmRlciBgcm9vdFBhdGhgIChcIjxyb290Pi9zcmNcIik7IFwiL1wiIG1hcHMgdG8gdGhlIHJvb3QgaXRzZWxmLiAqL1xuZXhwb3J0IGNvbnN0IGpvaW5SZWwgPSAocm9vdFBhdGg6IHN0cmluZywgcmVsRGlyOiBzdHJpbmcpOiBzdHJpbmcgPT4ge1xuICBjb25zdCBub3JtYWxpemVkID0gbm9ybWFsaXplUmVsKHJlbERpcik7XG4gIHJldHVybiBub3JtYWxpemVkID09PSBcIi9cIiA/IHJvb3RQYXRoLnJlcGxhY2UoL1xcLyskLywgXCJcIikgOiBqb2luUGF0aChyb290UGF0aCwgbm9ybWFsaXplZC5zbGljZSgxKSk7XG59O1xuXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbi8vIFJvb3QgbWV0YWRhdGEgKFIzLTc5IC8gRklMRV9FWFBMT1JFUl9TUEVDIMKnMikg4oCUIG92ZXIgdGhlIGdlbmVyYWxpemVkXG4vLyBFeHBsb3JlclJvb3QuIFRoZSBTREsgYWRhcHRlciBwb3B1bGF0ZXMgdGhlc2UgZmllbGRzIGZyb20gYSBTYW5kYm94TW91bnQ7IHRoZVxuLy8gdmlldyByZWFkcyB0aGVtIHRocm91Z2ggdGhlc2UgYWNjZXNzb3JzIHNvIHRoZSBsYXlvdXRzIHN0YXkgZGVjb3VwbGVkLlxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbi8qKiBBIGh1bWFuLXJlYWRhYmxlIHNjb3BlIGxhYmVsIChhbHJlYWR5IHJlc29sdmVkIG9udG8gdGhlIHJvb3QgYnkgdGhlIGFkYXB0ZXIpLiAqL1xuZXhwb3J0IGNvbnN0IG1vdW50TGFiZWwgPSAocjogRXhwbG9yZXJSb290KTogc3RyaW5nID0+IHIubGFiZWw7XG5cbi8qKiBUaGUgcHJvdmlkZXIvdHlwZSBraW5kIG9mIGEgcm9vdCwgZm9yIHRoZSBBcHAtc2NvcGUgaGVhZGVyIGljb24gKFBSSU5DSVBBTFNcbiAqICDCpzkgQjEpLiBBIGNsYXNzaWZpZXIgb25seSDigJQgdGhlIGljb24gbWFwcGluZyBsaXZlcyBpbiB0aGUgdmlldy4gKi9cbmV4cG9ydCB0eXBlIE1vdW50S2luZCA9IEV4cGxvcmVyUm9vdFtcImtpbmRcIl07XG5leHBvcnQgY29uc3QgbW91bnRLaW5kID0gKHI6IEV4cGxvcmVyUm9vdCk6IE1vdW50S2luZCA9PiByLmtpbmQ7XG5cbi8qKiBUaGUgc3BhY2VJZCBvZiBhIHNwYWNlIHJvb3QsIGZvciBlamVjdCAoYHVubW91bnRTcGFjZWApLiBOdWxsIGZvciByb290cyB0aGF0XG4gKiAgYXJlbid0IGVqZWN0YWJsZSBzcGFjZXMgKHdvcmt0cmVlLCBzZXR0aW5ncykuICovXG5leHBvcnQgY29uc3QgbW91bnRTcGFjZUlkID0gKHI6IEV4cGxvcmVyUm9vdCk6IHN0cmluZyB8IG51bGwgPT4gci5zcGFjZUlkID8/IG51bGw7XG5cbi8qKlxuICogV2hldGhlciB0aGUgZXhwbG9yZXIgb2ZmZXJzIGFuIEVKRUNUIChkZXRhY2gpIGFmZm9yZGFuY2Ugb24gdGhpcyByb290XG4gKiAoU1BBQ0VTX1VJX1NQRUMgwqczLCBSLVNQQUNFUy0zKS4gRWplY3QgPSBgdW5tb3VudFNwYWNlYCDigJQgY2xvc2VzIHRoZSBzcGFjZSBmb3JcbiAqIHRoaXMgc2Vzc2lvbiBvbmx5OyBpdCBpcyBOT1QgbGVhdmUvcmV2b2tlLiBPZmZlcmVkIGZvciBzcGFjZXMgLyBncmFudGVkXG4gKiBzdWJ0cmVlczsgTkVWRVIgZm9yIHRoZSB3b3JrdHJlZSBvciB0aGUgcGVyLWFwcCBgc2V0dGluZ3M6YCBzdG9yZS5cbiAqL1xuZXhwb3J0IGNvbnN0IGlzRWplY3RhYmxlID0gKHI6IEV4cGxvcmVyUm9vdCk6IGJvb2xlYW4gPT4gISFyLmVqZWN0YWJsZTtcblxuLyoqXG4gKiBXaGV0aGVyIHRoZSBleHBsb3JlciBzaG91bGQgb2ZmZXIgV1JJVEUgYWZmb3JkYW5jZXMgKG5ldy9yZW5hbWUvZGVsZXRlL3VwbG9hZC9cbiAqIG1vdmUpIG9uIHRoaXMgcm9vdC4gVGhlIGFkYXB0ZXIgY29tcHV0ZXMgZWZmZWN0aXZlIHdyaXRhYmlsaXR5OyB0aGUgdmlldyBqdXN0XG4gKiByZWZsZWN0cyBpdCDigJQgdGhlIGFmZm9yZGFuY2VzIGFyZSBISURERU4gb24gYSByZWFkLW9ubHkgcm9vdCwgbmV2ZXJcbiAqIHNob3duLXRoZW4tYEVST0ZTYCAoQ0xBVURFLm1kOiBuZXZlciBzdXJmYWNlIGBFUk9GU2AgYXMgVVgpLlxuICovXG5leHBvcnQgY29uc3QgaXNXcml0YWJsZU1vdW50ID0gKHI6IEV4cGxvcmVyUm9vdCk6IGJvb2xlYW4gPT4gci53cml0YWJsZTtcblxuLyoqIEEgbW91bnQtcmVsYXRpdmUgcGF0aCBpbiBvbmUgc2hhcGU6IGxlYWRpbmcgc2xhc2gsIG5vIHRyYWlsaW5nIHNsYXNoLiAqL1xuY29uc3Qgbm9ybWFsaXplUmVsID0gKHA6IHN0cmluZyk6IHN0cmluZyA9PiB7XG4gIGNvbnN0IHRyaW1tZWQgPSAocCB8fCBcIi9cIikucmVwbGFjZSgvXFwvKyQvLCBcIlwiKTtcbiAgaWYgKHRyaW1tZWQgPT09IFwiXCIpIHJldHVybiBcIi9cIjtcbiAgcmV0dXJuIHRyaW1tZWQuc3RhcnRzV2l0aChcIi9cIikgPyB0cmltbWVkIDogYC8ke3RyaW1tZWR9YDtcbn07XG5cbi8qKlxuICogVGhlIG1vZGUgdGhlIGFwcCBhY3R1YWxseSBIT0xEUyBhdCBgcmVsUGF0aGAgaW4gdGhpcyByb290IOKAlCBsb25nZXN0IG1hdGNoaW5nXG4gKiBgZ3JhbnRzYCBwcmVmaXggd2lucywgZXhhY3RseSBhcyB0aGUgaG9zdCByZXNvbHZlcyBhIGRlbGVnYXRpb24gYWdhaW5zdCBpdHMgcnVsZVxuICogc2V0LiBgcm9gIHdoZW4gbm90aGluZyBpcyBrbm93biwgc28gYSBtaXNzaW5nIHJ1bGUtc2V0IGNhbiBvbmx5IGV2ZXIgdW5kZXItYXNrLlxuICpcbiAqIFRoaXMgaXMgdGhlIG1vZGUgdG8gREVMRUdBVEUgYXQgKFIzLTI2NyAvIFIzLTI2NjogZGlzcGF0Y2ggY2hhbmdlcyB0aGUgcGFja2FnaW5nLFxuICogbm90IHRoZSBhdXRob3JpdHkg4oCUIHRoZSBtb3VudCBkZWNpZGVzIHdoZXRoZXIgdGhlIG9wZW5lZCB2aWV3ZXIgY2FuIGVkaXQpLiBJdCBpc1xuICogTk9UIHtAbGluayBpc1dyaXRhYmxlTW91bnR9LCB3aGljaCBhbnN3ZXJzIGEgZGlmZmVyZW50IHF1ZXN0aW9uOiB3aGV0aGVyIHRoZVxuICogZXhwbG9yZXIgaXRzZWxmIG9mZmVycyBjcmVhdGUvcmVuYW1lL2RlbGV0ZSBoZXJlLlxuICovXG5leHBvcnQgY29uc3QgZ3JhbnRlZE1vZGVBdCA9IChyOiBFeHBsb3JlclJvb3QsIHJlbFBhdGg6IHN0cmluZyk6IFwicm9cIiB8IFwicndcIiA9PiB7XG4gIGNvbnN0IHRhcmdldCA9IG5vcm1hbGl6ZVJlbChyZWxQYXRoKTtcbiAgbGV0IGJlc3QgPSAtMTtcbiAgbGV0IG1vZGU6IFwicm9cIiB8IFwicndcIiA9IFwicm9cIjtcbiAgZm9yIChjb25zdCBydWxlIG9mIHIuZ3JhbnRzID8/IFtdKSB7XG4gICAgY29uc3Qgc3VidHJlZSA9IG5vcm1hbGl6ZVJlbChydWxlLnN1YnRyZWUpO1xuICAgIGNvbnN0IGNvdmVycyA9IHN1YnRyZWUgPT09IFwiL1wiIHx8IHRhcmdldCA9PT0gc3VidHJlZSB8fCB0YXJnZXQuc3RhcnRzV2l0aChgJHtzdWJ0cmVlfS9gKTtcbiAgICBpZiAoY292ZXJzICYmIHN1YnRyZWUubGVuZ3RoID4gYmVzdCkge1xuICAgICAgYmVzdCA9IHN1YnRyZWUubGVuZ3RoO1xuICAgICAgbW9kZSA9IHJ1bGUubW9kZTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIG1vZGU7XG59O1xuXG4vKiogT25lIGRpc3BsYXkgcm93IGluIHRoZSBBcHAtc2NvcGUgaGVhZGVyOiBhIGdyYW50ZWQgc3VidHJlZSBhbmQgdGhlIG1vZGUgc2hvd25cbiAqICB0aGVyZSAoUFJJTkNJUEFMUyDCpzkgQjEgLyBGSUxFX0VYUExPUkVSIMKnMikuICovXG5leHBvcnQgaW50ZXJmYWNlIE1vdW50U2NvcGUge1xuICBzdWJ0cmVlOiBzdHJpbmc7XG4gIG1vZGU6IFwicm9cIiB8IFwicndcIjtcbn1cblxuLyoqXG4gKiBUaGUgZ3JhbnRlZCBzY29wZXMgb2YgYSByb290IGFzIGRpc3BsYXkgcm93cyDigJQgb25lIHBlciBzY29wZSwgc28gYSByb290IHdpdGhcbiAqIHNldmVyYWwgc3VidHJlZXMgbGlzdHMgZWFjaCAoRklMRV9FWFBMT1JFUiDCpzIgc3RlcCAyKS4gRmFsbHMgYmFjayB0byBhIHNpbmdsZVxuICogd2hvbGUtbW91bnQgcm93IGZyb20gdGhlIHJvb3QncyBlZmZlY3RpdmUgd3JpdGFiaWxpdHkgd2hlbiBgc2NvcGVzYCBpcyBhYnNlbnQuXG4gKiBUaGUgZGlzcGxheWVkIG1vZGUgaXMgdGhlIEVGRkVDVElWRSBtb2RlIHRoZSBhZGFwdGVyIGFscmVhZHkgYmFrZWQgaW50byBlYWNoXG4gKiBzY29wZS4gRGUtZHVwZWQgYnkgc3VidHJlZSBhbmQgb3JkZXJlZCByb290LWZpcnN0IHRoZW4gQeKGklouXG4gKi9cbmV4cG9ydCBjb25zdCBtb3VudFNjb3BlcyA9IChyOiBFeHBsb3JlclJvb3QpOiBNb3VudFNjb3BlW10gPT4ge1xuICBjb25zdCBmYWxsYmFja01vZGU6IFwicm9cIiB8IFwicndcIiA9IGlzV3JpdGFibGVNb3VudChyKSA/IFwicndcIiA6IFwicm9cIjtcbiAgY29uc3Qgc2NvcGVzID0gci5zY29wZXM/Lmxlbmd0aCA/IHIuc2NvcGVzIDogW3sgc3VidHJlZTogXCIvXCIsIG1vZGU6IGZhbGxiYWNrTW9kZSB9XTtcbiAgY29uc3Qgc2VlbiA9IG5ldyBNYXA8c3RyaW5nLCBNb3VudFNjb3BlPigpO1xuICBmb3IgKGNvbnN0IHMgb2Ygc2NvcGVzKSB7XG4gICAgY29uc3Qgc3VidHJlZSA9IHMuc3VidHJlZSAmJiBzLnN1YnRyZWUudHJpbSgpICYmIHMuc3VidHJlZSAhPT0gXCIvXCIgPyBzLnN1YnRyZWUudHJpbSgpIDogXCIvXCI7XG4gICAgaWYgKHNlZW4uaGFzKHN1YnRyZWUpKSBjb250aW51ZTtcbiAgICBzZWVuLnNldChzdWJ0cmVlLCB7IHN1YnRyZWUsIG1vZGU6IHMubW9kZSB9KTtcbiAgfVxuICByZXR1cm4gWy4uLnNlZW4udmFsdWVzKCldLnNvcnQoKGEsIGIpID0+XG4gICAgYS5zdWJ0cmVlID09PSBcIi9cIiA/IC0xIDogYi5zdWJ0cmVlID09PSBcIi9cIiA/IDEgOiBhLnN1YnRyZWUubG9jYWxlQ29tcGFyZShiLnN1YnRyZWUpLFxuICApO1xufTtcblxuLyoqIEEgc2hvcnQgc3VidHJlZSBsYWJlbCBmb3IgdGhlIHNpbmdsZS1jaGlwIGxheW91dHMgKGJyZWFkY3J1bWIgLyBjb2x1bW5zKSB3aGVyZVxuICogIG9ubHkgdGhlIGN1cnJlbnQgZGlyZWN0b3J5J3Mgb3duaW5nIHJvb3QgaXMgc2hvd24gKFwiL1wiIGZvciBhIHdob2xlLW1vdW50IGdyYW50KS5cbiAqICBUaGUgcGVyLW1vdW50IGhlYWRlciB1c2VzIHtAbGluayBtb3VudFNjb3Blc30gZm9yIHRoZSBmdWxsIGxpc3QuICovXG5leHBvcnQgY29uc3Qgc3VidHJlZUxhYmVsID0gKHI6IEV4cGxvcmVyUm9vdCk6IHN0cmluZyA9PiB7XG4gIGNvbnN0IGZpcnN0ID0gci5zY29wZXM/LlswXTtcbiAgcmV0dXJuIGZpcnN0Py5zdWJ0cmVlICYmIGZpcnN0LnN1YnRyZWUgIT09IFwiL1wiID8gZmlyc3Quc3VidHJlZSA6IFwiL1wiO1xufTtcblxuLyoqIE9yZGVyIHJvb3RzIGZvciBkaXNwbGF5OiB3b3JrdHJlZSBmaXJzdCwgdGhlbiBzcGFjZXMsIHRoZW4gb3RoZXJzLCBB4oaSWi4gKi9cbmV4cG9ydCBjb25zdCBvcmRlck1vdW50cyA9IChyb290czogRXhwbG9yZXJSb290W10pOiBFeHBsb3JlclJvb3RbXSA9PlxuICBbLi4ucm9vdHNdLnNvcnQoKGEsIGIpID0+IHtcbiAgICBjb25zdCByYW5rID0gKHI6IEV4cGxvcmVyUm9vdCkgPT5cbiAgICAgIHIua2luZCA9PT0gXCJ3b3JrdHJlZVwiID8gMCA6IHIua2luZCA9PT0gXCJzcGFjZVwiID8gMSA6IDI7XG4gICAgcmV0dXJuIHJhbmsoYSkgLSByYW5rKGIpIHx8IG1vdW50TGFiZWwoYSkubG9jYWxlQ29tcGFyZShtb3VudExhYmVsKGIpKTtcbiAgfSk7XG5cbi8vIEZpbGVzIHRoZSBob3N0IHJlZnVzZXMgdG8gZGVsZXRlL3JlbmFtZSDigJQgaGlkZSB0aGUgYWZmb3JkYW5jZSB0byBtYXRjaCAodGhlXG4vLyBob3N0IGFsc28gZW5mb3JjZXMgaXQsIHJldHVybmluZyBgcHJvdGVjdGVkYCkuIFNoYXJlZCBieSBldmVyeSBsYXlvdXQgc28gdGhlXG4vLyBnYXRpbmcgaXMgaWRlbnRpY2FsIGluIHRyZWUgLyBsaXN0IC8gaWNvbnMgLyBjb2x1bW5zLiBNb3VudC1yZWxhdGl2ZSBwYXRocy5cbmNvbnN0IFBST1RFQ1RFRCA9IG5ldyBTZXQoW1wiL3BhY2thZ2UuanNvblwiXSk7XG5cbi8qKiBJcyB0aGlzIG1vdW50LXJlbGF0aXZlIHBhdGggb25lIHRoZSBob3N0IHByb3RlY3RzIGZyb20gZGVsZXRlL3JlbmFtZT8gKi9cbmV4cG9ydCBjb25zdCBpc1Byb3RlY3RlZCA9IChtb3VudFJlbDogc3RyaW5nKTogYm9vbGVhbiA9PiBQUk9URUNURUQuaGFzKG1vdW50UmVsKTtcblxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vLyBCcmVhZGNydW1iIC8gY3VycmVudC1kaXJlY3RvcnkgbmF2aWdhdGlvbiAoUjMtODQgbGlzdCArIGljb25zIGxheW91dHMpXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGludGVyZmFjZSBDcnVtYiB7XG4gIC8qKiBEaXNwbGF5IGxhYmVsIGZvciB0aGUgc2VnbWVudC4gKi9cbiAgbGFiZWw6IHN0cmluZztcbiAgLyoqIEFic29sdXRlIHBhdGggdGhlIHNlZ21lbnQgbmF2aWdhdGVzIHRvLCBvciBudWxsIGZvciB0aGUgXCJTcGFjZXNcIiByb290LiAqL1xuICBwYXRoOiBzdHJpbmcgfCBudWxsO1xufVxuXG4vKipcbiAqIFJlc29sdmUgYSBjdXJyZW50IGRpcmVjdG9yeSAoYGN3ZGAsIGFic29sdXRlIG9yIG51bGwgPSB0aGUgU3BhY2VzIHJvb3QpIGludG8gdGhlXG4gKiBvd25pbmcgcm9vdCBhbmQgYSBicmVhZGNydW1iIHRyYWlsLiBUaGUgdHJhaWwgYWx3YXlzIHN0YXJ0cyBhdCBcIlNwYWNlc1wiIHNvIHRoZVxuICogdXNlciBjYW4gc3RlcCBiYWNrIG91dCB0byB0aGUgcm9vdCBsaXN0IChtaXJyb3JpbmcgdGhlIG1vYmlsZSBwcm9qZWN0aW9uIGluXG4gKiBicmllZiAxMykuIFdoZW4gYGN3ZGAgZmFsbHMgaW5zaWRlIGEgcm9vdCwgc2VnbWVudHMgYXJlOiBTcGFjZXMgPiA8cm9vdD4gPlxuICogPHN1YmRpci4uLj4uIFdoZW4gYGN3ZGAgaXMgbnVsbCAob3IgdW5yZXNvbHZhYmxlKSwgb25seSB0aGUgU3BhY2VzIHJvb3QgaXMgc2hvd24uXG4gKiBQdXJlIOKAlCBubyBSZWFjdCwgbm8gSS9PLlxuICovXG5leHBvcnQgY29uc3QgYnJlYWRjcnVtYkZvciA9IChcbiAgY3dkOiBzdHJpbmcgfCBudWxsLFxuICBvcmRlcmVkOiBFeHBsb3JlclJvb3RbXSxcbik6IHsgbW91bnQ6IEV4cGxvcmVyUm9vdCB8IG51bGw7IGNydW1iczogQ3J1bWJbXSB9ID0+IHtcbiAgY29uc3Qgcm9vdDogQ3J1bWIgPSB7IGxhYmVsOiBcIlNwYWNlc1wiLCBwYXRoOiBudWxsIH07XG4gIGlmICghY3dkKSByZXR1cm4geyBtb3VudDogbnVsbCwgY3J1bWJzOiBbcm9vdF0gfTtcbiAgY29uc3QgbW91bnQgPSBvcmRlcmVkLmZpbmQoKG0pID0+IGN3ZCA9PT0gbS5wYXRoIHx8IGN3ZC5zdGFydHNXaXRoKG0ucGF0aCArIFwiL1wiKSkgPz8gbnVsbDtcbiAgaWYgKCFtb3VudCkgcmV0dXJuIHsgbW91bnQ6IG51bGwsIGNydW1iczogW3Jvb3RdIH07XG5cbiAgY29uc3QgY3J1bWJzOiBDcnVtYltdID0gW3Jvb3QsIHsgbGFiZWw6IG1vdW50TGFiZWwobW91bnQpLCBwYXRoOiBtb3VudC5wYXRoIH1dO1xuICBjb25zdCByZWwgPSB0b01vdW50UmVsKG1vdW50LnBhdGgsIGN3ZCk7IC8vIGUuZy4gXCIvc3JjL2NvbXBvbmVudHNcIiBvciBcIi9cIlxuICBjb25zdCBzZWdzID0gcmVsLnNwbGl0KFwiL1wiKS5maWx0ZXIoQm9vbGVhbik7XG4gIGxldCBhY2MgPSBtb3VudC5wYXRoO1xuICBmb3IgKGNvbnN0IHNlZyBvZiBzZWdzKSB7XG4gICAgYWNjID0gam9pblBhdGgoYWNjLCBzZWcpO1xuICAgIGNydW1icy5wdXNoKHsgbGFiZWw6IHNlZywgcGF0aDogYWNjIH0pO1xuICB9XG4gIHJldHVybiB7IG1vdW50LCBjcnVtYnMgfTtcbn07XG5cbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuLy8gRHJhZy1hbmQtZHJvcCB2YWxpZGl0eSAoUjMtODEgbW92ZSAvIFIzLTgyIHVwbG9hZClcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG4vKiogUHJpdmF0ZSBNSU1FIHRoZSBleHBsb3JlciBzZXRzIG9uIGFuIGludGVybmFsIChzYW1lLWFwcCkgbW92ZSBkcmFnLCBzbyBhblxuICogIGludGVybmFsIHJvdyBkcmFnIGlzIGRpc3Rpbmd1aXNoYWJsZSBmcm9tIGFuIE9TLWZpbGUgZHJvcCBhbmQgYSDCpzcgZHJhZy1vdXQuICovXG5leHBvcnQgY29uc3QgTU9WRV9NSU1FID0gXCJhcHBsaWNhdGlvbi94LWlyLWZpbGUtbW92ZVwiO1xuXG5leHBvcnQgaW50ZXJmYWNlIE1vdmVQYXlsb2FkIHtcbiAgLyoqIEFic29sdXRlIHNvdXJjZSBwYXRoLiAqL1xuICBmcm9tOiBzdHJpbmc7XG4gIC8qKiBUaGUgcm9vdCBwYXRoIG9mIHRoZSBzb3VyY2UgbW91bnQgKHRvIGZvcmJpZCBjcm9zcy1tb3VudCBtb3ZlcykuICovXG4gIHJvb3RQYXRoOiBzdHJpbmc7XG4gIC8qKiBXaGV0aGVyIHRoZSBkcmFnZ2VkIHRoaW5nIGlzIGEgZm9sZGVyIChzbyBhIGZhaWxlZCBtb3ZlIHJlc3RvcmVzIHRoZVxuICAgKiAgcmlnaHQgcm93IHNoYXBlIHdoZW4gdGhlIHNvdXJjZSBsaXN0aW5nIGlzIG5vIGxvbmdlciBjYWNoZWQpLiAqL1xuICBpc0RpcjogYm9vbGVhbjtcbn1cblxuLyoqXG4gKiBDYW4gYGZyb21gIGJlIG1vdmVkIElOVE8gZGlyZWN0b3J5IGB0YXJnZXREaXJgIChib3RoIGFic29sdXRlIHBhdGhzIGluIHRoZSBzYW1lXG4gKiBtb3VudCk/IFJlamVjdHM6IGEgbm8tb3AgKGFscmVhZHkgaW4gdGhhdCBkaXIpLCBhIGRpcmVjdG9yeSBkcm9wcGVkIG9udG8gaXRzZWxmXG4gKiBvciBhIGRlc2NlbmRhbnQsIGFuZCAodGhlIGNhbGxlciBlbmZvcmNlcykgY3Jvc3MtbW91bnQgZHJvcHMuIFJldHVybnMgdGhlIHJlYXNvblxuICogY29kZSBvbiByZWplY3Rpb24gc28gdGhlIFVJIGNhbiBoaW50LCBvciBgbnVsbGAgd2hlbiB0aGUgbW92ZSBpcyBhbGxvd2VkLlxuICovXG5leHBvcnQgY29uc3QgbW92ZVJlamVjdGlvbiA9IChcbiAgZnJvbTogc3RyaW5nLFxuICB0YXJnZXREaXI6IHN0cmluZyxcbiAgZnJvbVJvb3Q6IHN0cmluZyxcbiAgdGFyZ2V0Um9vdDogc3RyaW5nLFxuKTogXCJjcm9zcy1tb3VudFwiIHwgXCJzYW1lLWRpclwiIHwgXCJpbnRvLXNlbGZcIiB8IG51bGwgPT4ge1xuICBpZiAoZnJvbVJvb3QgIT09IHRhcmdldFJvb3QpIHJldHVybiBcImNyb3NzLW1vdW50XCI7XG4gIGlmIChkaXJPZihmcm9tKSA9PT0gdGFyZ2V0RGlyLnJlcGxhY2UoL1xcLyskLywgXCJcIikpIHJldHVybiBcInNhbWUtZGlyXCI7XG4gIGNvbnN0IGYgPSBmcm9tLnJlcGxhY2UoL1xcLyskLywgXCJcIik7XG4gIGNvbnN0IHQgPSB0YXJnZXREaXIucmVwbGFjZSgvXFwvKyQvLCBcIlwiKTtcbiAgaWYgKHQgPT09IGYgfHwgdC5zdGFydHNXaXRoKGYgKyBcIi9cIikpIHJldHVybiBcImludG8tc2VsZlwiO1xuICByZXR1cm4gbnVsbDtcbn07XG5cbi8qKiBUaGUgaHVtYW4gc2VudGVuY2UgZm9yIGEgZGVzdGluYXRpb24gdGhlIG1vdmUgcmVmdXNlcywgb3IgbnVsbCB3aGVuIGl0XG4gKiAgZG9lc24ndCDigJQgdGhlIG1vdmUgcGlja2VyJ3MgZGlzYWJsZWQtYnV0dG9uIHJlYXNvbi4gKi9cbmV4cG9ydCBjb25zdCBtb3ZlUmVmdXNhbExhYmVsID0gKFxuICB0YXJnZXQ6IHsgYWJzUGF0aDogc3RyaW5nOyByb290UGF0aDogc3RyaW5nOyBuYW1lOiBzdHJpbmcgfSxcbiAgZGlyQWJzOiBzdHJpbmcsXG4gIGRpclJvb3RQYXRoOiBzdHJpbmcsXG4pOiBzdHJpbmcgfCBudWxsID0+IHtcbiAgY29uc3QgcmVhc29uID0gbW92ZVJlamVjdGlvbih0YXJnZXQuYWJzUGF0aCwgZGlyQWJzLCB0YXJnZXQucm9vdFBhdGgsIGRpclJvb3RQYXRoKTtcbiAgaWYgKHJlYXNvbiA9PT0gXCJjcm9zcy1tb3VudFwiKSByZXR1cm4gV1JJVEVfRVJSW1wiY3Jvc3MtbW91bnRcIl07XG4gIGlmIChyZWFzb24gPT09IFwic2FtZS1kaXJcIikgcmV0dXJuIGAke3RhcmdldC5uYW1lfSBpcyBhbHJlYWR5IGluIHRoaXMgZm9sZGVyLmA7XG4gIGlmIChyZWFzb24gPT09IFwiaW50by1zZWxmXCIpIHJldHVybiBcIkEgZm9sZGVyIGNhbuKAmXQgbW92ZSBpbnRvIGl0c2VsZi5cIjtcbiAgcmV0dXJuIG51bGw7XG59O1xuXG4vKipcbiAqIFdoZXJlIGFuIE9TLWZpbGUgZHJvcCBsYW5kcyAoYEZJTEVfRVhQTE9SRVJfU1BFQyDCpzVgKTogdGhlIGRpcmVjdG9yeSByb3cgdW5kZXJcbiAqIHRoZSBwb2ludGVyLCB0aGUgUEFSRU5UIG9mIGEgZmlsZSByb3csIG9yIHRoZSBzY29wZSByb290IHdoZW4gdGhlIGRyb3AgbWlzc2VzXG4gKiBldmVyeSByb3cg4oCUIGEgZHJvcCBvbiB0aGUgYmxhbmsgc3BhY2UgYmVsb3cgdGhlIHRyZWUsIG9yIG9uIHRoZSBzY29wZSBoZWFkZXIuXG4gKiBUaGUgwqc1IHVwbG9hZCBCVVRUT04gcmVzb2x2ZXMgaXRzIGRlc3RpbmF0aW9uIHRocm91Z2ggdGhlIHNhbWUgc2hhcGU6IGl0c1xuICogXCJyb3dcIiBpcyB0aGUgU0VMRUNUSU9OIChhIHNlbGVjdGVkIGRpciBpdHNlbGYsIGEgc2VsZWN0ZWQgZmlsZSdzIHBhcmVudClcbiAqIGFuZCB0aGUgZmFsbGJhY2sgaXMgdGhlIHJlcG8gcm9vdCB3aGVuIG5vdGhpbmcgaXMgc2VsZWN0ZWQuXG4gKlxuICogYHJvd2AgaXMgd2hhdCB0aGUgZHJvcCBwb2ludCByZXNvbHZlcyB0bywgb3IgYG51bGxgIHdoZW4gaXQgcmVzb2x2ZXMgdG8gbm90aGluZy5cbiAqIERpcmVjdG9yeSByb3dzIGFuc3dlciB0aGlzIGZvciB0aGVtc2VsdmVzIGJlZm9yZSB0aGUgZXZlbnQgcmVhY2hlcyBhIGNvbnRhaW5lcixcbiAqIHNvIGluIHByYWN0aWNlIHRoaXMgZGVjaWRlcyB0aGUgdHdvIGNhc2VzIHRoYXQgdXNlZCB0byBiZSBzaWxlbnQgbm8tb3BzLlxuICovXG5leHBvcnQgY29uc3QgdXBsb2FkVGFyZ2V0RGlyID0gKFxuICByb3c6IHsgcGF0aDogc3RyaW5nOyBpc0RpcjogYm9vbGVhbiB9IHwgbnVsbCxcbiAgc2NvcGVSb290OiBzdHJpbmcsXG4pOiBzdHJpbmcgPT4gKHJvdyA/IChyb3cuaXNEaXIgPyByb3cucGF0aCA6IGRpck9mKHJvdy5wYXRoKSkgOiBzY29wZVJvb3QpO1xuXG4vKipcbiAqIFRoZSBET03ihpJyb3cgaGFsZiBvZiBhbiBPUy1maWxlIGRyb3AgKFIzLTYyNik6IHJlc29sdmUgdGhlIGVsZW1lbnQgdGhlIGRyb3BcbiAqIGxhbmRlZCBvbiB0byBhIHJvdyB2aWEgdGhlIGBkYXRhLXBhdGhgL2BkYXRhLWRpcmAgYXR0cmlidXRlcyBldmVyeSByb3dcbiAqIGNhcnJpZXMsIHRoZW4gYHVwbG9hZFRhcmdldERpcmAgYWdhaW5zdCB0aGUgY29udGFpbmVyJ3MgZmFsbGJhY2suIE9ORSBob21lIOKAlFxuICogdGhlIGZsYXQgY29udGFpbmVycycgaG9vayBhbmQgdGhlIHRyZWUncyBzY29wZSByZXNvbHZlIGlkZW50aWNhbGx5LCBhbmQgdGhpc1xuICogaXMgdGhlIGJsb2NrIHRoYXQgbXVzdCBub3QgZHJpZnQgYmV0d2VlbiB0aGVtLlxuICovXG5leHBvcnQgY29uc3QgdXBsb2FkUm93RnJvbUV2ZW50ID0gKGU6IHsgdGFyZ2V0OiBFdmVudFRhcmdldCB8IG51bGwgfSwgZmFsbGJhY2tEaXI6IHN0cmluZyk6IHN0cmluZyA9PiB7XG4gIGNvbnN0IGVsID0gKGUudGFyZ2V0IGFzIEhUTUxFbGVtZW50IHwgbnVsbCk/LmNsb3Nlc3Q/LihcIltkYXRhLXBhdGhdXCIpID8/IG51bGw7XG4gIGNvbnN0IHJvdyA9IGVsXG4gICAgPyB7IHBhdGg6IGVsLmdldEF0dHJpYnV0ZShcImRhdGEtcGF0aFwiKSA/PyBmYWxsYmFja0RpciwgaXNEaXI6IGVsLmdldEF0dHJpYnV0ZShcImRhdGEtZGlyXCIpID09PSBcIjFcIiB9XG4gICAgOiBudWxsO1xuICByZXR1cm4gdXBsb2FkVGFyZ2V0RGlyKHJvdywgZmFsbGJhY2tEaXIpO1xufTtcblxuLyoqIEEgc29mdCBjbGllbnQgY2FwIG9uIGlubGluZWQgdXBsb2FkL2RyYWcgYnl0ZXM7IHRoZSBob3N0IGVuZm9yY2VzIHRoZSByZWFsIG9uZS4gKi9cbmV4cG9ydCBjb25zdCBNQVhfVVBMT0FEX0JZVEVTID0gNTEyICogMTAyNDtcblxuLyoqIE1hcCBhIGhvc3Qgd3JpdGUtb3V0Y29tZSBjb2RlIHRvIGEgZnJpZW5kbHkgbWVzc2FnZSAoc2hhcmVkIGJ5IGV2ZXJ5IG11dGF0aW9uKS4gKi9cbmV4cG9ydCBjb25zdCBXUklURV9FUlI6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7XG4gIGV4aXN0czogXCJTb21ldGhpbmcgd2l0aCB0aGF0IG5hbWUgYWxyZWFkeSBleGlzdHMuXCIsXG4gIHByb3RlY3RlZDogXCJUaGF0IGZpbGUgY2Fu4oCZdCBiZSBkZWxldGVkLlwiLFxuICBcInRvby1sYXJnZVwiOiBcIlRoYXQgZmlsZSBpcyB0b28gbGFyZ2UgdG8gdXBsb2FkLlwiLFxuICBcIm5vdC1mb3VuZFwiOiBcIlRoYXQgZmlsZSBubyBsb25nZXIgZXhpc3RzLlwiLFxuICBmb3JiaWRkZW46IFwiWW91IGRvbuKAmXQgaGF2ZSBwZXJtaXNzaW9uIHRvIGNoYW5nZSBmaWxlcyBoZXJlLlwiLFxuICBcImludmFsaWQtcGFyYW1zXCI6IFwiVGhhdCBuYW1lIGlzbuKAmXQgdmFsaWQuXCIsXG4gIFwiY3Jvc3MtbW91bnRcIjogXCJDYW7igJl0IG1vdmUgYmV0d2VlbiBzcGFjZXMgeWV0LlwiLFxufTtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUdBO0FBQ08sTUFBTUEsUUFBUSxHQUFHQSxDQUFDQyxHQUFXLEVBQUVDLElBQVksS0FDaEQsR0FBR0QsR0FBRyxDQUFDRSxPQUFPLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxJQUFJRCxJQUFJLEVBQUU7O0FBRXRDO0FBQUFFLE9BQUEsQ0FBQUosUUFBQSxHQUFBQSxRQUFBO0FBQ08sTUFBTUssUUFBUSxHQUFJQyxDQUFTLElBQWFBLENBQUMsQ0FBQ0MsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDQyxNQUFNLENBQUNDLE9BQU8sQ0FBQyxDQUFDQyxHQUFHLENBQUMsQ0FBQyxJQUFJLEVBQUU7O0FBRXZGO0FBQUFOLE9BQUEsQ0FBQUMsUUFBQSxHQUFBQSxRQUFBO0FBQ08sTUFBTU0sS0FBSyxHQUFJTCxDQUFTLElBQWE7RUFDMUMsTUFBTU0sT0FBTyxHQUFHTixDQUFDLENBQUNILE9BQU8sQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDO0VBQ3JDLE1BQU1VLENBQUMsR0FBR0QsT0FBTyxDQUFDRSxXQUFXLENBQUMsR0FBRyxDQUFDO0VBQ2xDLE9BQU9ELENBQUMsSUFBSSxDQUFDLEdBQUcsR0FBRyxHQUFHRCxPQUFPLENBQUNHLEtBQUssQ0FBQyxDQUFDLEVBQUVGLENBQUMsQ0FBQztBQUMzQyxDQUFDOztBQUVEO0FBQ0E7QUFEQVQsT0FBQSxDQUFBTyxLQUFBLEdBQUFBLEtBQUE7QUFFTyxNQUFNSyxVQUFVLEdBQUdBLENBQUNDLFFBQWdCLEVBQUVDLE9BQWUsS0FDMURBLE9BQU8sQ0FBQ0gsS0FBSyxDQUFDRSxRQUFRLENBQUNkLE9BQU8sQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLENBQUNnQixNQUFNLENBQUMsSUFBSSxHQUFHOztBQUUzRDtBQUNBO0FBREFmLE9BQUEsQ0FBQVksVUFBQSxHQUFBQSxVQUFBO0FBRU8sTUFBTUksT0FBTyxHQUFHQSxDQUFDSCxRQUFnQixFQUFFSSxNQUFjLEtBQWE7RUFDbkUsTUFBTUMsVUFBVSxHQUFHQyxZQUFZLENBQUNGLE1BQU0sQ0FBQztFQUN2QyxPQUFPQyxVQUFVLEtBQUssR0FBRyxHQUFHTCxRQUFRLENBQUNkLE9BQU8sQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEdBQUdILFFBQVEsQ0FBQ2lCLFFBQVEsRUFBRUssVUFBVSxDQUFDUCxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEcsQ0FBQzs7QUFFRDtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQUFYLE9BQUEsQ0FBQWdCLE9BQUEsR0FBQUEsT0FBQTtBQUNPLE1BQU1JLFVBQVUsR0FBSUMsQ0FBZSxJQUFhQSxDQUFDLENBQUNDLEtBQUs7O0FBRTlEO0FBQ0E7QUFEQXRCLE9BQUEsQ0FBQW9CLFVBQUEsR0FBQUEsVUFBQTtBQUdPLE1BQU1HLFNBQVMsR0FBSUYsQ0FBZSxJQUFnQkEsQ0FBQyxDQUFDRyxJQUFJOztBQUUvRDtBQUNBO0FBREF4QixPQUFBLENBQUF1QixTQUFBLEdBQUFBLFNBQUE7QUFFTyxNQUFNRSxZQUFZLEdBQUlKLENBQWUsSUFBb0JBLENBQUMsQ0FBQ0ssT0FBTyxJQUFJLElBQUk7O0FBRWpGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUxBMUIsT0FBQSxDQUFBeUIsWUFBQSxHQUFBQSxZQUFBO0FBTU8sTUFBTUUsV0FBVyxHQUFJTixDQUFlLElBQWMsQ0FBQyxDQUFDQSxDQUFDLENBQUNPLFNBQVM7O0FBRXRFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUxBNUIsT0FBQSxDQUFBMkIsV0FBQSxHQUFBQSxXQUFBO0FBTU8sTUFBTUUsZUFBZSxHQUFJUixDQUFlLElBQWNBLENBQUMsQ0FBQ1MsUUFBUTs7QUFFdkU7QUFBQTlCLE9BQUEsQ0FBQTZCLGVBQUEsR0FBQUEsZUFBQTtBQUNBLE1BQU1WLFlBQVksR0FBSWpCLENBQVMsSUFBYTtFQUMxQyxNQUFNTSxPQUFPLEdBQUcsQ0FBQ04sQ0FBQyxJQUFJLEdBQUcsRUFBRUgsT0FBTyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUM7RUFDOUMsSUFBSVMsT0FBTyxLQUFLLEVBQUUsRUFBRSxPQUFPLEdBQUc7RUFDOUIsT0FBT0EsT0FBTyxDQUFDdUIsVUFBVSxDQUFDLEdBQUcsQ0FBQyxHQUFHdkIsT0FBTyxHQUFHLElBQUlBLE9BQU8sRUFBRTtBQUMxRCxDQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sTUFBTXdCLGFBQWEsR0FBR0EsQ0FBQ1gsQ0FBZSxFQUFFWSxPQUFlLEtBQWtCO0VBQzlFLE1BQU1DLE1BQU0sR0FBR2YsWUFBWSxDQUFDYyxPQUFPLENBQUM7RUFDcEMsSUFBSUUsSUFBSSxHQUFHLENBQUMsQ0FBQztFQUNiLElBQUlDLElBQWlCLEdBQUcsSUFBSTtFQUM1QixLQUFLLE1BQU1DLElBQUksSUFBSWhCLENBQUMsQ0FBQ2lCLE1BQU0sSUFBSSxFQUFFLEVBQUU7SUFDakMsTUFBTUMsT0FBTyxHQUFHcEIsWUFBWSxDQUFDa0IsSUFBSSxDQUFDRSxPQUFPLENBQUM7SUFDMUMsTUFBTUMsTUFBTSxHQUFHRCxPQUFPLEtBQUssR0FBRyxJQUFJTCxNQUFNLEtBQUtLLE9BQU8sSUFBSUwsTUFBTSxDQUFDSCxVQUFVLENBQUMsR0FBR1EsT0FBTyxHQUFHLENBQUM7SUFDeEYsSUFBSUMsTUFBTSxJQUFJRCxPQUFPLENBQUN4QixNQUFNLEdBQUdvQixJQUFJLEVBQUU7TUFDbkNBLElBQUksR0FBR0ksT0FBTyxDQUFDeEIsTUFBTTtNQUNyQnFCLElBQUksR0FBR0MsSUFBSSxDQUFDRCxJQUFJO0lBQ2xCO0VBQ0Y7RUFDQSxPQUFPQSxJQUFJO0FBQ2IsQ0FBQzs7QUFFRDtBQUNBO0FBREFwQyxPQUFBLENBQUFnQyxhQUFBLEdBQUFBLGFBQUE7QUFPQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLE1BQU1TLFdBQVcsR0FBSXBCLENBQWUsSUFBbUI7RUFDNUQsTUFBTXFCLFlBQXlCLEdBQUdiLGVBQWUsQ0FBQ1IsQ0FBQyxDQUFDLEdBQUcsSUFBSSxHQUFHLElBQUk7RUFDbEUsTUFBTXNCLE1BQU0sR0FBR3RCLENBQUMsQ0FBQ3NCLE1BQU0sRUFBRTVCLE1BQU0sR0FBR00sQ0FBQyxDQUFDc0IsTUFBTSxHQUFHLENBQUM7SUFBRUosT0FBTyxFQUFFLEdBQUc7SUFBRUgsSUFBSSxFQUFFTTtFQUFhLENBQUMsQ0FBQztFQUNuRixNQUFNRSxJQUFJLEdBQUcsSUFBSUMsR0FBRyxDQUFxQixDQUFDO0VBQzFDLEtBQUssTUFBTUMsQ0FBQyxJQUFJSCxNQUFNLEVBQUU7SUFDdEIsTUFBTUosT0FBTyxHQUFHTyxDQUFDLENBQUNQLE9BQU8sSUFBSU8sQ0FBQyxDQUFDUCxPQUFPLENBQUNRLElBQUksQ0FBQyxDQUFDLElBQUlELENBQUMsQ0FBQ1AsT0FBTyxLQUFLLEdBQUcsR0FBR08sQ0FBQyxDQUFDUCxPQUFPLENBQUNRLElBQUksQ0FBQyxDQUFDLEdBQUcsR0FBRztJQUMzRixJQUFJSCxJQUFJLENBQUNJLEdBQUcsQ0FBQ1QsT0FBTyxDQUFDLEVBQUU7SUFDdkJLLElBQUksQ0FBQ0ssR0FBRyxDQUFDVixPQUFPLEVBQUU7TUFBRUEsT0FBTztNQUFFSCxJQUFJLEVBQUVVLENBQUMsQ0FBQ1Y7SUFBSyxDQUFDLENBQUM7RUFDOUM7RUFDQSxPQUFPLENBQUMsR0FBR1EsSUFBSSxDQUFDTSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUNDLElBQUksQ0FBQyxDQUFDQyxDQUFDLEVBQUVDLENBQUMsS0FDbENELENBQUMsQ0FBQ2IsT0FBTyxLQUFLLEdBQUcsR0FBRyxDQUFDLENBQUMsR0FBR2MsQ0FBQyxDQUFDZCxPQUFPLEtBQUssR0FBRyxHQUFHLENBQUMsR0FBR2EsQ0FBQyxDQUFDYixPQUFPLENBQUNlLGFBQWEsQ0FBQ0QsQ0FBQyxDQUFDZCxPQUFPLENBQ3BGLENBQUM7QUFDSCxDQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUZBdkMsT0FBQSxDQUFBeUMsV0FBQSxHQUFBQSxXQUFBO0FBR08sTUFBTWMsWUFBWSxHQUFJbEMsQ0FBZSxJQUFhO0VBQ3ZELE1BQU1tQyxLQUFLLEdBQUduQyxDQUFDLENBQUNzQixNQUFNLEdBQUcsQ0FBQyxDQUFDO0VBQzNCLE9BQU9hLEtBQUssRUFBRWpCLE9BQU8sSUFBSWlCLEtBQUssQ0FBQ2pCLE9BQU8sS0FBSyxHQUFHLEdBQUdpQixLQUFLLENBQUNqQixPQUFPLEdBQUcsR0FBRztBQUN0RSxDQUFDOztBQUVEO0FBQUF2QyxPQUFBLENBQUF1RCxZQUFBLEdBQUFBLFlBQUE7QUFDTyxNQUFNRSxXQUFXLEdBQUlDLEtBQXFCLElBQy9DLENBQUMsR0FBR0EsS0FBSyxDQUFDLENBQUNQLElBQUksQ0FBQyxDQUFDQyxDQUFDLEVBQUVDLENBQUMsS0FBSztFQUN4QixNQUFNTSxJQUFJLEdBQUl0QyxDQUFlLElBQzNCQSxDQUFDLENBQUNHLElBQUksS0FBSyxVQUFVLEdBQUcsQ0FBQyxHQUFHSCxDQUFDLENBQUNHLElBQUksS0FBSyxPQUFPLEdBQUcsQ0FBQyxHQUFHLENBQUM7RUFDeEQsT0FBT21DLElBQUksQ0FBQ1AsQ0FBQyxDQUFDLEdBQUdPLElBQUksQ0FBQ04sQ0FBQyxDQUFDLElBQUlqQyxVQUFVLENBQUNnQyxDQUFDLENBQUMsQ0FBQ0UsYUFBYSxDQUFDbEMsVUFBVSxDQUFDaUMsQ0FBQyxDQUFDLENBQUM7QUFDeEUsQ0FBQyxDQUFDOztBQUVKO0FBQ0E7QUFDQTtBQUFBckQsT0FBQSxDQUFBeUQsV0FBQSxHQUFBQSxXQUFBO0FBQ0EsTUFBTUcsU0FBUyxHQUFHLElBQUlDLEdBQUcsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDOztBQUU1QztBQUNPLE1BQU1DLFdBQVcsR0FBSUMsUUFBZ0IsSUFBY0gsU0FBUyxDQUFDWixHQUFHLENBQUNlLFFBQVEsQ0FBQzs7QUFFakY7QUFDQTtBQUNBO0FBQUEvRCxPQUFBLENBQUE4RCxXQUFBLEdBQUFBLFdBQUE7QUFTQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sTUFBTUUsYUFBYSxHQUFHQSxDQUMzQkMsR0FBa0IsRUFDbEJDLE9BQXVCLEtBQzZCO0VBQ3BELE1BQU1DLElBQVcsR0FBRztJQUFFN0MsS0FBSyxFQUFFLFFBQVE7SUFBRThDLElBQUksRUFBRTtFQUFLLENBQUM7RUFDbkQsSUFBSSxDQUFDSCxHQUFHLEVBQUUsT0FBTztJQUFFSSxLQUFLLEVBQUUsSUFBSTtJQUFFQyxNQUFNLEVBQUUsQ0FBQ0gsSUFBSTtFQUFFLENBQUM7RUFDaEQsTUFBTUUsS0FBSyxHQUFHSCxPQUFPLENBQUNLLElBQUksQ0FBRUMsQ0FBQyxJQUFLUCxHQUFHLEtBQUtPLENBQUMsQ0FBQ0osSUFBSSxJQUFJSCxHQUFHLENBQUNsQyxVQUFVLENBQUN5QyxDQUFDLENBQUNKLElBQUksR0FBRyxHQUFHLENBQUMsQ0FBQyxJQUFJLElBQUk7RUFDekYsSUFBSSxDQUFDQyxLQUFLLEVBQUUsT0FBTztJQUFFQSxLQUFLLEVBQUUsSUFBSTtJQUFFQyxNQUFNLEVBQUUsQ0FBQ0gsSUFBSTtFQUFFLENBQUM7RUFFbEQsTUFBTUcsTUFBZSxHQUFHLENBQUNILElBQUksRUFBRTtJQUFFN0MsS0FBSyxFQUFFRixVQUFVLENBQUNpRCxLQUFLLENBQUM7SUFBRUQsSUFBSSxFQUFFQyxLQUFLLENBQUNEO0VBQUssQ0FBQyxDQUFDO0VBQzlFLE1BQU1LLEdBQUcsR0FBRzdELFVBQVUsQ0FBQ3lELEtBQUssQ0FBQ0QsSUFBSSxFQUFFSCxHQUFHLENBQUMsQ0FBQyxDQUFDO0VBQ3pDLE1BQU1TLElBQUksR0FBR0QsR0FBRyxDQUFDdEUsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDQyxNQUFNLENBQUNDLE9BQU8sQ0FBQztFQUMzQyxJQUFJc0UsR0FBRyxHQUFHTixLQUFLLENBQUNELElBQUk7RUFDcEIsS0FBSyxNQUFNUSxHQUFHLElBQUlGLElBQUksRUFBRTtJQUN0QkMsR0FBRyxHQUFHL0UsUUFBUSxDQUFDK0UsR0FBRyxFQUFFQyxHQUFHLENBQUM7SUFDeEJOLE1BQU0sQ0FBQ08sSUFBSSxDQUFDO01BQUV2RCxLQUFLLEVBQUVzRCxHQUFHO01BQUVSLElBQUksRUFBRU87SUFBSSxDQUFDLENBQUM7RUFDeEM7RUFDQSxPQUFPO0lBQUVOLEtBQUs7SUFBRUM7RUFBTyxDQUFDO0FBQzFCLENBQUM7O0FBRUQ7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFEQXRFLE9BQUEsQ0FBQWdFLGFBQUEsR0FBQUEsYUFBQTtBQUVPLE1BQU1jLFNBQVMsR0FBQTlFLE9BQUEsQ0FBQThFLFNBQUEsR0FBRyw0QkFBNEI7QUFZckQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sTUFBTUMsYUFBYSxHQUFHQSxDQUMzQkMsSUFBWSxFQUNaQyxTQUFpQixFQUNqQkMsUUFBZ0IsRUFDaEJDLFVBQWtCLEtBQ2tDO0VBQ3BELElBQUlELFFBQVEsS0FBS0MsVUFBVSxFQUFFLE9BQU8sYUFBYTtFQUNqRCxJQUFJNUUsS0FBSyxDQUFDeUUsSUFBSSxDQUFDLEtBQUtDLFNBQVMsQ0FBQ2xGLE9BQU8sQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUUsT0FBTyxVQUFVO0VBQ3BFLE1BQU1xRixDQUFDLEdBQUdKLElBQUksQ0FBQ2pGLE9BQU8sQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDO0VBQ2xDLE1BQU1zRixDQUFDLEdBQUdKLFNBQVMsQ0FBQ2xGLE9BQU8sQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDO0VBQ3ZDLElBQUlzRixDQUFDLEtBQUtELENBQUMsSUFBSUMsQ0FBQyxDQUFDdEQsVUFBVSxDQUFDcUQsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxFQUFFLE9BQU8sV0FBVztFQUN4RCxPQUFPLElBQUk7QUFDYixDQUFDOztBQUVEO0FBQ0E7QUFEQXBGLE9BQUEsQ0FBQStFLGFBQUEsR0FBQUEsYUFBQTtBQUVPLE1BQU1PLGdCQUFnQixHQUFHQSxDQUM5QnBELE1BQTJELEVBQzNEcUQsTUFBYyxFQUNkQyxXQUFtQixLQUNEO0VBQ2xCLE1BQU1DLE1BQU0sR0FBR1YsYUFBYSxDQUFDN0MsTUFBTSxDQUFDcEIsT0FBTyxFQUFFeUUsTUFBTSxFQUFFckQsTUFBTSxDQUFDckIsUUFBUSxFQUFFMkUsV0FBVyxDQUFDO0VBQ2xGLElBQUlDLE1BQU0sS0FBSyxhQUFhLEVBQUUsT0FBT0MsU0FBUyxDQUFDLGFBQWEsQ0FBQztFQUM3RCxJQUFJRCxNQUFNLEtBQUssVUFBVSxFQUFFLE9BQU8sR0FBR3ZELE1BQU0sQ0FBQ3BDLElBQUksNkJBQTZCO0VBQzdFLElBQUkyRixNQUFNLEtBQUssV0FBVyxFQUFFLE9BQU8sa0NBQWtDO0VBQ3JFLE9BQU8sSUFBSTtBQUNiLENBQUM7O0FBRUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBWEF6RixPQUFBLENBQUFzRixnQkFBQSxHQUFBQSxnQkFBQTtBQVlPLE1BQU1LLGVBQWUsR0FBR0EsQ0FDN0JDLEdBQTRDLEVBQzVDQyxTQUFpQixLQUNMRCxHQUFHLEdBQUlBLEdBQUcsQ0FBQ0UsS0FBSyxHQUFHRixHQUFHLENBQUN4QixJQUFJLEdBQUc3RCxLQUFLLENBQUNxRixHQUFHLENBQUN4QixJQUFJLENBQUMsR0FBSXlCLFNBQVU7O0FBRXpFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTkE3RixPQUFBLENBQUEyRixlQUFBLEdBQUFBLGVBQUE7QUFPTyxNQUFNSSxrQkFBa0IsR0FBR0EsQ0FBQ0MsQ0FBaUMsRUFBRUMsV0FBbUIsS0FBYTtFQUNwRyxNQUFNQyxFQUFFLEdBQUlGLENBQUMsQ0FBQzlELE1BQU0sRUFBeUJpRSxPQUFPLEdBQUcsYUFBYSxDQUFDLElBQUksSUFBSTtFQUM3RSxNQUFNUCxHQUFHLEdBQUdNLEVBQUUsR0FDVjtJQUFFOUIsSUFBSSxFQUFFOEIsRUFBRSxDQUFDRSxZQUFZLENBQUMsV0FBVyxDQUFDLElBQUlILFdBQVc7SUFBRUgsS0FBSyxFQUFFSSxFQUFFLENBQUNFLFlBQVksQ0FBQyxVQUFVLENBQUMsS0FBSztFQUFJLENBQUMsR0FDakcsSUFBSTtFQUNSLE9BQU9ULGVBQWUsQ0FBQ0MsR0FBRyxFQUFFSyxXQUFXLENBQUM7QUFDMUMsQ0FBQzs7QUFFRDtBQUFBakcsT0FBQSxDQUFBK0Ysa0JBQUEsR0FBQUEsa0JBQUE7QUFDTyxNQUFNTSxnQkFBZ0IsR0FBQXJHLE9BQUEsQ0FBQXFHLGdCQUFBLEdBQUcsR0FBRyxHQUFHLElBQUk7O0FBRTFDO0FBQ08sTUFBTVgsU0FBaUMsR0FBQTFGLE9BQUEsQ0FBQTBGLFNBQUEsR0FBRztFQUMvQ1ksTUFBTSxFQUFFLDBDQUEwQztFQUNsREMsU0FBUyxFQUFFLDZCQUE2QjtFQUN4QyxXQUFXLEVBQUUsbUNBQW1DO0VBQ2hELFdBQVcsRUFBRSw2QkFBNkI7RUFDMUNDLFNBQVMsRUFBRSxpREFBaUQ7RUFDNUQsZ0JBQWdCLEVBQUUsd0JBQXdCO0VBQzFDLGFBQWEsRUFBRTtBQUNqQixDQUFDIiwiaWdub3JlTGlzdCI6W119