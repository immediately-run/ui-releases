"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.makeSdkActions = makeSdkActions;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.find.js");
var _sdk = require("@immediately-run/sdk");
var _explorer = require("../explorer");
var _mountFs = require("./mountFs");
// `makeSdkActions()` — the SDK adapter's `ExplorerActions` (Phase 02 §B.3). Each
// method wraps the matching host-gated intent (`editor:open` / `editor:write`) or
// the cross-app drag-out, carrying over the EXACT path conversion and per-file
// upload cap the original `FileExplorer.tsx` used. The view passes mount-relative
// paths (it already trimmed the owning root), so these forward them straight to
// the SDK; rejections (`{ code }`) propagate to the view's `runWrite`, which maps
// them through `WRITE_ERR`.

/** Build the SDK-backed action bundle for the shipped file-explorer app. */
function makeSdkActions() {
  return {
    // R3-79/§4: open a file in the neighboring editor (`editor:open`). `not-found`
    // is swallowed (the file may have just been deleted); the call is best-effort.
    open: (_root, relPath) => {
      void (0, _sdk.openInEditor)(relPath).catch(() => undefined);
    },
    // Create / rename / delete: the app NAMES a mount-relative path; the host
    // performs the COW write behind `editor:write`. Each write resolves the
    // entry it produced (the caller renders and settles the write's own
    // result — R-IX-4); rejections flow to the view's write flow. `rename`
    // derives the settled entry from the destination listing — the authority's
    // own answer, including whether the moved thing is a folder — and degrades
    // to the name it asked for if the listing can't be read.
    createFile: async (_root, relPath) => {
      await (0, _sdk.createFile)(relPath);
      return {
        name: (0, _explorer.basename)(relPath),
        isDir: false
      };
    },
    createFolder: async (_root, relPath) => {
      await (0, _sdk.createFolder)(relPath);
      return {
        name: (0, _explorer.basename)(relPath),
        isDir: true
      };
    },
    rename: async (root, fromRel, toRel, isDir) => {
      await (0, _sdk.renameEntry)(fromRel, toRel);
      const name = (0, _explorer.basename)(toRel);
      const parentAbs = (0, _explorer.joinRel)(root.path, (0, _explorer.dirOf)(toRel));
      try {
        const list = await _mountFs.sdkFsSource.readdir(parentAbs);
        const hit = list.find(e => e.name === name);
        if (hit) return hit;
      } catch {
        /* unreadable listing — the narrow refetch is still the authority */
      }
      // Degraded settle: the name it asked for, and the caller's own fact
      // about the row (never a fabricated file).
      return {
        name,
        isDir: isDir ?? false
      };
    },
    delete: async (_root, relPath) => {
      await (0, _sdk.deleteEntry)(relPath);
      return relPath;
    },
    // R3-82 upload: inline each file's bytes; a per-file soft cap throws `too-large`
    // (the host enforces the real one), mapped by WRITE_ERR.
    upload: async (_root, dirRel, files) => {
      for (const f of files) {
        if (f.size > _explorer.MAX_UPLOAD_BYTES) {
          throw Object.assign(new Error("too large"), {
            code: "too-large"
          });
        }
        const bytes = new Uint8Array(await f.arrayBuffer());
        await (0, _sdk.uploadFile)((0, _explorer.joinPath)(dirRel, (0, _explorer.basename)(f.name)), bytes);
      }
    },
    // R3-83 drag-out: ask the host to begin a cross-app drag. Reference-only for
    // dirs / large files; inline bytes for a small file (best-effort — the source
    // can only relay bytes it can already read). `forbidden`/no host is swallowed:
    // the internal move still works.
    beginDragOut: (root, relPath, isDir) => {
      void (async () => {
        const item = {
          kind: isDir ? "dir" : "file",
          name: (0, _explorer.basename)(relPath),
          mountId: root.id,
          relPath
        };
        if (!isDir) {
          try {
            const abs = (0, _explorer.joinPath)(root.path, relPath.replace(/^\/+/, ""));
            const bytes = await _mountFs.sdkFsSource.readFile(abs);
            if (bytes.byteLength <= _explorer.MAX_UPLOAD_BYTES) item.bytes = bytes;
          } catch {
            /* unreadable → reference-only */
          }
        }
        try {
          await (0, _sdk.startItemDrag)(item);
        } catch {
          /* no dnd:source / no host → drag-out unavailable, internal move unaffected */
        }
      })();
    },
    cancelDragOut: () => (0, _sdk.cancelItemDrag)(),
    // R-SPACES-3 eject: detach a space for this session (`unmountSpace`). The mount
    // disappears via the `useMounts()` subscription; typed errors degrade quietly.
    eject: async root => {
      if (!root.spaceId) return;
      await (0, _sdk.unmountSpace)({
        spaceId: root.spaceId
      });
    }
  };
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfc2RrIiwicmVxdWlyZSIsIl9leHBsb3JlciIsIl9tb3VudEZzIiwibWFrZVNka0FjdGlvbnMiLCJvcGVuIiwiX3Jvb3QiLCJyZWxQYXRoIiwib3BlbkluRWRpdG9yIiwiY2F0Y2giLCJ1bmRlZmluZWQiLCJjcmVhdGVGaWxlIiwibmFtZSIsImJhc2VuYW1lIiwiaXNEaXIiLCJjcmVhdGVGb2xkZXIiLCJyZW5hbWUiLCJyb290IiwiZnJvbVJlbCIsInRvUmVsIiwicmVuYW1lRW50cnkiLCJwYXJlbnRBYnMiLCJqb2luUmVsIiwicGF0aCIsImRpck9mIiwibGlzdCIsInNka0ZzU291cmNlIiwicmVhZGRpciIsImhpdCIsImZpbmQiLCJlIiwiZGVsZXRlIiwiZGVsZXRlRW50cnkiLCJ1cGxvYWQiLCJkaXJSZWwiLCJmaWxlcyIsImYiLCJzaXplIiwiTUFYX1VQTE9BRF9CWVRFUyIsIk9iamVjdCIsImFzc2lnbiIsIkVycm9yIiwiY29kZSIsImJ5dGVzIiwiVWludDhBcnJheSIsImFycmF5QnVmZmVyIiwidXBsb2FkRmlsZSIsImpvaW5QYXRoIiwiYmVnaW5EcmFnT3V0IiwiaXRlbSIsImtpbmQiLCJtb3VudElkIiwiaWQiLCJhYnMiLCJyZXBsYWNlIiwicmVhZEZpbGUiLCJieXRlTGVuZ3RoIiwic3RhcnRJdGVtRHJhZyIsImNhbmNlbERyYWdPdXQiLCJjYW5jZWxJdGVtRHJhZyIsImVqZWN0Iiwic3BhY2VJZCIsInVubW91bnRTcGFjZSJdLCJzb3VyY2VzIjpbImFjdGlvbnMudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gYG1ha2VTZGtBY3Rpb25zKClgIOKAlCB0aGUgU0RLIGFkYXB0ZXIncyBgRXhwbG9yZXJBY3Rpb25zYCAoUGhhc2UgMDIgwqdCLjMpLiBFYWNoXG4vLyBtZXRob2Qgd3JhcHMgdGhlIG1hdGNoaW5nIGhvc3QtZ2F0ZWQgaW50ZW50IChgZWRpdG9yOm9wZW5gIC8gYGVkaXRvcjp3cml0ZWApIG9yXG4vLyB0aGUgY3Jvc3MtYXBwIGRyYWctb3V0LCBjYXJyeWluZyBvdmVyIHRoZSBFWEFDVCBwYXRoIGNvbnZlcnNpb24gYW5kIHBlci1maWxlXG4vLyB1cGxvYWQgY2FwIHRoZSBvcmlnaW5hbCBgRmlsZUV4cGxvcmVyLnRzeGAgdXNlZC4gVGhlIHZpZXcgcGFzc2VzIG1vdW50LXJlbGF0aXZlXG4vLyBwYXRocyAoaXQgYWxyZWFkeSB0cmltbWVkIHRoZSBvd25pbmcgcm9vdCksIHNvIHRoZXNlIGZvcndhcmQgdGhlbSBzdHJhaWdodCB0b1xuLy8gdGhlIFNESzsgcmVqZWN0aW9ucyAoYHsgY29kZSB9YCkgcHJvcGFnYXRlIHRvIHRoZSB2aWV3J3MgYHJ1bldyaXRlYCwgd2hpY2ggbWFwc1xuLy8gdGhlbSB0aHJvdWdoIGBXUklURV9FUlJgLlxuaW1wb3J0IHtcbiAgb3BlbkluRWRpdG9yLFxuICBjcmVhdGVGaWxlLFxuICBjcmVhdGVGb2xkZXIsXG4gIGRlbGV0ZUVudHJ5LFxuICByZW5hbWVFbnRyeSxcbiAgdXBsb2FkRmlsZSxcbiAgc3RhcnRJdGVtRHJhZyxcbiAgY2FuY2VsSXRlbURyYWcsXG4gIHVubW91bnRTcGFjZSxcbn0gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrXCI7XG5pbXBvcnQgeyBiYXNlbmFtZSwgZGlyT2YsIGpvaW5QYXRoLCBqb2luUmVsLCBNQVhfVVBMT0FEX0JZVEVTIH0gZnJvbSBcIi4uL2V4cGxvcmVyXCI7XG5pbXBvcnQgeyBzZGtGc1NvdXJjZSB9IGZyb20gXCIuL21vdW50RnNcIjtcbmltcG9ydCB0eXBlIHsgRW50cnksIEV4cGxvcmVyQWN0aW9ucyB9IGZyb20gXCIuLi90eXBlc1wiO1xuXG4vKiogQnVpbGQgdGhlIFNESy1iYWNrZWQgYWN0aW9uIGJ1bmRsZSBmb3IgdGhlIHNoaXBwZWQgZmlsZS1leHBsb3JlciBhcHAuICovXG5leHBvcnQgZnVuY3Rpb24gbWFrZVNka0FjdGlvbnMoKTogRXhwbG9yZXJBY3Rpb25zIHtcbiAgcmV0dXJuIHtcbiAgICAvLyBSMy03OS/CpzQ6IG9wZW4gYSBmaWxlIGluIHRoZSBuZWlnaGJvcmluZyBlZGl0b3IgKGBlZGl0b3I6b3BlbmApLiBgbm90LWZvdW5kYFxuICAgIC8vIGlzIHN3YWxsb3dlZCAodGhlIGZpbGUgbWF5IGhhdmUganVzdCBiZWVuIGRlbGV0ZWQpOyB0aGUgY2FsbCBpcyBiZXN0LWVmZm9ydC5cbiAgICBvcGVuOiAoX3Jvb3QsIHJlbFBhdGgpID0+IHtcbiAgICAgIHZvaWQgb3BlbkluRWRpdG9yKHJlbFBhdGgpLmNhdGNoKCgpID0+IHVuZGVmaW5lZCk7XG4gICAgfSxcblxuICAgIC8vIENyZWF0ZSAvIHJlbmFtZSAvIGRlbGV0ZTogdGhlIGFwcCBOQU1FUyBhIG1vdW50LXJlbGF0aXZlIHBhdGg7IHRoZSBob3N0XG4gICAgLy8gcGVyZm9ybXMgdGhlIENPVyB3cml0ZSBiZWhpbmQgYGVkaXRvcjp3cml0ZWAuIEVhY2ggd3JpdGUgcmVzb2x2ZXMgdGhlXG4gICAgLy8gZW50cnkgaXQgcHJvZHVjZWQgKHRoZSBjYWxsZXIgcmVuZGVycyBhbmQgc2V0dGxlcyB0aGUgd3JpdGUncyBvd25cbiAgICAvLyByZXN1bHQg4oCUIFItSVgtNCk7IHJlamVjdGlvbnMgZmxvdyB0byB0aGUgdmlldydzIHdyaXRlIGZsb3cuIGByZW5hbWVgXG4gICAgLy8gZGVyaXZlcyB0aGUgc2V0dGxlZCBlbnRyeSBmcm9tIHRoZSBkZXN0aW5hdGlvbiBsaXN0aW5nIOKAlCB0aGUgYXV0aG9yaXR5J3NcbiAgICAvLyBvd24gYW5zd2VyLCBpbmNsdWRpbmcgd2hldGhlciB0aGUgbW92ZWQgdGhpbmcgaXMgYSBmb2xkZXIg4oCUIGFuZCBkZWdyYWRlc1xuICAgIC8vIHRvIHRoZSBuYW1lIGl0IGFza2VkIGZvciBpZiB0aGUgbGlzdGluZyBjYW4ndCBiZSByZWFkLlxuICAgIGNyZWF0ZUZpbGU6IGFzeW5jIChfcm9vdCwgcmVsUGF0aCkgPT4ge1xuICAgICAgYXdhaXQgY3JlYXRlRmlsZShyZWxQYXRoKTtcbiAgICAgIHJldHVybiB7IG5hbWU6IGJhc2VuYW1lKHJlbFBhdGgpLCBpc0RpcjogZmFsc2UgfSBzYXRpc2ZpZXMgRW50cnk7XG4gICAgfSxcbiAgICBjcmVhdGVGb2xkZXI6IGFzeW5jIChfcm9vdCwgcmVsUGF0aCkgPT4ge1xuICAgICAgYXdhaXQgY3JlYXRlRm9sZGVyKHJlbFBhdGgpO1xuICAgICAgcmV0dXJuIHsgbmFtZTogYmFzZW5hbWUocmVsUGF0aCksIGlzRGlyOiB0cnVlIH0gc2F0aXNmaWVzIEVudHJ5O1xuICAgIH0sXG4gICAgcmVuYW1lOiBhc3luYyAocm9vdCwgZnJvbVJlbCwgdG9SZWwsIGlzRGlyKSA9PiB7XG4gICAgICBhd2FpdCByZW5hbWVFbnRyeShmcm9tUmVsLCB0b1JlbCk7XG4gICAgICBjb25zdCBuYW1lID0gYmFzZW5hbWUodG9SZWwpO1xuICAgICAgY29uc3QgcGFyZW50QWJzID0gam9pblJlbChyb290LnBhdGgsIGRpck9mKHRvUmVsKSk7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBsaXN0ID0gYXdhaXQgc2RrRnNTb3VyY2UucmVhZGRpcihwYXJlbnRBYnMpO1xuICAgICAgICBjb25zdCBoaXQgPSBsaXN0LmZpbmQoKGUpID0+IGUubmFtZSA9PT0gbmFtZSk7XG4gICAgICAgIGlmIChoaXQpIHJldHVybiBoaXQ7XG4gICAgICB9IGNhdGNoIHtcbiAgICAgICAgLyogdW5yZWFkYWJsZSBsaXN0aW5nIOKAlCB0aGUgbmFycm93IHJlZmV0Y2ggaXMgc3RpbGwgdGhlIGF1dGhvcml0eSAqL1xuICAgICAgfVxuICAgICAgLy8gRGVncmFkZWQgc2V0dGxlOiB0aGUgbmFtZSBpdCBhc2tlZCBmb3IsIGFuZCB0aGUgY2FsbGVyJ3Mgb3duIGZhY3RcbiAgICAgIC8vIGFib3V0IHRoZSByb3cgKG5ldmVyIGEgZmFicmljYXRlZCBmaWxlKS5cbiAgICAgIHJldHVybiB7IG5hbWUsIGlzRGlyOiBpc0RpciA/PyBmYWxzZSB9IHNhdGlzZmllcyBFbnRyeTtcbiAgICB9LFxuICAgIGRlbGV0ZTogYXN5bmMgKF9yb290LCByZWxQYXRoKSA9PiB7XG4gICAgICBhd2FpdCBkZWxldGVFbnRyeShyZWxQYXRoKTtcbiAgICAgIHJldHVybiByZWxQYXRoO1xuICAgIH0sXG5cbiAgICAvLyBSMy04MiB1cGxvYWQ6IGlubGluZSBlYWNoIGZpbGUncyBieXRlczsgYSBwZXItZmlsZSBzb2Z0IGNhcCB0aHJvd3MgYHRvby1sYXJnZWBcbiAgICAvLyAodGhlIGhvc3QgZW5mb3JjZXMgdGhlIHJlYWwgb25lKSwgbWFwcGVkIGJ5IFdSSVRFX0VSUi5cbiAgICB1cGxvYWQ6IGFzeW5jIChfcm9vdCwgZGlyUmVsLCBmaWxlcykgPT4ge1xuICAgICAgZm9yIChjb25zdCBmIG9mIGZpbGVzKSB7XG4gICAgICAgIGlmIChmLnNpemUgPiBNQVhfVVBMT0FEX0JZVEVTKSB7XG4gICAgICAgICAgdGhyb3cgT2JqZWN0LmFzc2lnbihuZXcgRXJyb3IoXCJ0b28gbGFyZ2VcIiksIHsgY29kZTogXCJ0b28tbGFyZ2VcIiB9KTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBieXRlcyA9IG5ldyBVaW50OEFycmF5KGF3YWl0IGYuYXJyYXlCdWZmZXIoKSk7XG4gICAgICAgIGF3YWl0IHVwbG9hZEZpbGUoam9pblBhdGgoZGlyUmVsLCBiYXNlbmFtZShmLm5hbWUpKSwgYnl0ZXMpO1xuICAgICAgfVxuICAgIH0sXG5cbiAgICAvLyBSMy04MyBkcmFnLW91dDogYXNrIHRoZSBob3N0IHRvIGJlZ2luIGEgY3Jvc3MtYXBwIGRyYWcuIFJlZmVyZW5jZS1vbmx5IGZvclxuICAgIC8vIGRpcnMgLyBsYXJnZSBmaWxlczsgaW5saW5lIGJ5dGVzIGZvciBhIHNtYWxsIGZpbGUgKGJlc3QtZWZmb3J0IOKAlCB0aGUgc291cmNlXG4gICAgLy8gY2FuIG9ubHkgcmVsYXkgYnl0ZXMgaXQgY2FuIGFscmVhZHkgcmVhZCkuIGBmb3JiaWRkZW5gL25vIGhvc3QgaXMgc3dhbGxvd2VkOlxuICAgIC8vIHRoZSBpbnRlcm5hbCBtb3ZlIHN0aWxsIHdvcmtzLlxuICAgIGJlZ2luRHJhZ091dDogKHJvb3QsIHJlbFBhdGgsIGlzRGlyKSA9PiB7XG4gICAgICB2b2lkIChhc3luYyAoKSA9PiB7XG4gICAgICAgIGNvbnN0IGl0ZW0gPSB7XG4gICAgICAgICAga2luZDogKGlzRGlyID8gXCJkaXJcIiA6IFwiZmlsZVwiKSBhcyBcImRpclwiIHwgXCJmaWxlXCIsXG4gICAgICAgICAgbmFtZTogYmFzZW5hbWUocmVsUGF0aCksXG4gICAgICAgICAgbW91bnRJZDogcm9vdC5pZCxcbiAgICAgICAgICByZWxQYXRoLFxuICAgICAgICB9IGFzIFBhcmFtZXRlcnM8dHlwZW9mIHN0YXJ0SXRlbURyYWc+WzBdO1xuICAgICAgICBpZiAoIWlzRGlyKSB7XG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IGFicyA9IGpvaW5QYXRoKHJvb3QucGF0aCwgcmVsUGF0aC5yZXBsYWNlKC9eXFwvKy8sIFwiXCIpKTtcbiAgICAgICAgICAgIGNvbnN0IGJ5dGVzID0gYXdhaXQgc2RrRnNTb3VyY2UucmVhZEZpbGUhKGFicyk7XG4gICAgICAgICAgICBpZiAoYnl0ZXMuYnl0ZUxlbmd0aCA8PSBNQVhfVVBMT0FEX0JZVEVTKSBpdGVtLmJ5dGVzID0gYnl0ZXM7XG4gICAgICAgICAgfSBjYXRjaCB7XG4gICAgICAgICAgICAvKiB1bnJlYWRhYmxlIOKGkiByZWZlcmVuY2Utb25seSAqL1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICB0cnkge1xuICAgICAgICAgIGF3YWl0IHN0YXJ0SXRlbURyYWcoaXRlbSk7XG4gICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgIC8qIG5vIGRuZDpzb3VyY2UgLyBubyBob3N0IOKGkiBkcmFnLW91dCB1bmF2YWlsYWJsZSwgaW50ZXJuYWwgbW92ZSB1bmFmZmVjdGVkICovXG4gICAgICAgIH1cbiAgICAgIH0pKCk7XG4gICAgfSxcbiAgICBjYW5jZWxEcmFnT3V0OiAoKSA9PiBjYW5jZWxJdGVtRHJhZygpLFxuXG4gICAgLy8gUi1TUEFDRVMtMyBlamVjdDogZGV0YWNoIGEgc3BhY2UgZm9yIHRoaXMgc2Vzc2lvbiAoYHVubW91bnRTcGFjZWApLiBUaGUgbW91bnRcbiAgICAvLyBkaXNhcHBlYXJzIHZpYSB0aGUgYHVzZU1vdW50cygpYCBzdWJzY3JpcHRpb247IHR5cGVkIGVycm9ycyBkZWdyYWRlIHF1aWV0bHkuXG4gICAgZWplY3Q6IGFzeW5jIChyb290KSA9PiB7XG4gICAgICBpZiAoIXJvb3Quc3BhY2VJZCkgcmV0dXJuO1xuICAgICAgYXdhaXQgdW5tb3VudFNwYWNlKHsgc3BhY2VJZDogcm9vdC5zcGFjZUlkIH0pO1xuICAgIH0sXG4gIH07XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBT0EsSUFBQUEsSUFBQSxHQUFBQyxPQUFBO0FBV0EsSUFBQUMsU0FBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsUUFBQSxHQUFBRixPQUFBO0FBbkJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQWdCQTtBQUNPLFNBQVNHLGNBQWNBLENBQUEsRUFBb0I7RUFDaEQsT0FBTztJQUNMO0lBQ0E7SUFDQUMsSUFBSSxFQUFFQSxDQUFDQyxLQUFLLEVBQUVDLE9BQU8sS0FBSztNQUN4QixLQUFLLElBQUFDLGlCQUFZLEVBQUNELE9BQU8sQ0FBQyxDQUFDRSxLQUFLLENBQUMsTUFBTUMsU0FBUyxDQUFDO0lBQ25ELENBQUM7SUFFRDtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBQyxVQUFVLEVBQUUsTUFBQUEsQ0FBT0wsS0FBSyxFQUFFQyxPQUFPLEtBQUs7TUFDcEMsTUFBTSxJQUFBSSxlQUFVLEVBQUNKLE9BQU8sQ0FBQztNQUN6QixPQUFPO1FBQUVLLElBQUksRUFBRSxJQUFBQyxrQkFBUSxFQUFDTixPQUFPLENBQUM7UUFBRU8sS0FBSyxFQUFFO01BQU0sQ0FBQztJQUNsRCxDQUFDO0lBQ0RDLFlBQVksRUFBRSxNQUFBQSxDQUFPVCxLQUFLLEVBQUVDLE9BQU8sS0FBSztNQUN0QyxNQUFNLElBQUFRLGlCQUFZLEVBQUNSLE9BQU8sQ0FBQztNQUMzQixPQUFPO1FBQUVLLElBQUksRUFBRSxJQUFBQyxrQkFBUSxFQUFDTixPQUFPLENBQUM7UUFBRU8sS0FBSyxFQUFFO01BQUssQ0FBQztJQUNqRCxDQUFDO0lBQ0RFLE1BQU0sRUFBRSxNQUFBQSxDQUFPQyxJQUFJLEVBQUVDLE9BQU8sRUFBRUMsS0FBSyxFQUFFTCxLQUFLLEtBQUs7TUFDN0MsTUFBTSxJQUFBTSxnQkFBVyxFQUFDRixPQUFPLEVBQUVDLEtBQUssQ0FBQztNQUNqQyxNQUFNUCxJQUFJLEdBQUcsSUFBQUMsa0JBQVEsRUFBQ00sS0FBSyxDQUFDO01BQzVCLE1BQU1FLFNBQVMsR0FBRyxJQUFBQyxpQkFBTyxFQUFDTCxJQUFJLENBQUNNLElBQUksRUFBRSxJQUFBQyxlQUFLLEVBQUNMLEtBQUssQ0FBQyxDQUFDO01BQ2xELElBQUk7UUFDRixNQUFNTSxJQUFJLEdBQUcsTUFBTUMsb0JBQVcsQ0FBQ0MsT0FBTyxDQUFDTixTQUFTLENBQUM7UUFDakQsTUFBTU8sR0FBRyxHQUFHSCxJQUFJLENBQUNJLElBQUksQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUNsQixJQUFJLEtBQUtBLElBQUksQ0FBQztRQUM3QyxJQUFJZ0IsR0FBRyxFQUFFLE9BQU9BLEdBQUc7TUFDckIsQ0FBQyxDQUFDLE1BQU07UUFDTjtNQUFBO01BRUY7TUFDQTtNQUNBLE9BQU87UUFBRWhCLElBQUk7UUFBRUUsS0FBSyxFQUFFQSxLQUFLLElBQUk7TUFBTSxDQUFDO0lBQ3hDLENBQUM7SUFDRGlCLE1BQU0sRUFBRSxNQUFBQSxDQUFPekIsS0FBSyxFQUFFQyxPQUFPLEtBQUs7TUFDaEMsTUFBTSxJQUFBeUIsZ0JBQVcsRUFBQ3pCLE9BQU8sQ0FBQztNQUMxQixPQUFPQSxPQUFPO0lBQ2hCLENBQUM7SUFFRDtJQUNBO0lBQ0EwQixNQUFNLEVBQUUsTUFBQUEsQ0FBTzNCLEtBQUssRUFBRTRCLE1BQU0sRUFBRUMsS0FBSyxLQUFLO01BQ3RDLEtBQUssTUFBTUMsQ0FBQyxJQUFJRCxLQUFLLEVBQUU7UUFDckIsSUFBSUMsQ0FBQyxDQUFDQyxJQUFJLEdBQUdDLDBCQUFnQixFQUFFO1VBQzdCLE1BQU1DLE1BQU0sQ0FBQ0MsTUFBTSxDQUFDLElBQUlDLEtBQUssQ0FBQyxXQUFXLENBQUMsRUFBRTtZQUFFQyxJQUFJLEVBQUU7VUFBWSxDQUFDLENBQUM7UUFDcEU7UUFDQSxNQUFNQyxLQUFLLEdBQUcsSUFBSUMsVUFBVSxDQUFDLE1BQU1SLENBQUMsQ0FBQ1MsV0FBVyxDQUFDLENBQUMsQ0FBQztRQUNuRCxNQUFNLElBQUFDLGVBQVUsRUFBQyxJQUFBQyxrQkFBUSxFQUFDYixNQUFNLEVBQUUsSUFBQXJCLGtCQUFRLEVBQUN1QixDQUFDLENBQUN4QixJQUFJLENBQUMsQ0FBQyxFQUFFK0IsS0FBSyxDQUFDO01BQzdEO0lBQ0YsQ0FBQztJQUVEO0lBQ0E7SUFDQTtJQUNBO0lBQ0FLLFlBQVksRUFBRUEsQ0FBQy9CLElBQUksRUFBRVYsT0FBTyxFQUFFTyxLQUFLLEtBQUs7TUFDdEMsS0FBSyxDQUFDLFlBQVk7UUFDaEIsTUFBTW1DLElBQUksR0FBRztVQUNYQyxJQUFJLEVBQUdwQyxLQUFLLEdBQUcsS0FBSyxHQUFHLE1BQXlCO1VBQ2hERixJQUFJLEVBQUUsSUFBQUMsa0JBQVEsRUFBQ04sT0FBTyxDQUFDO1VBQ3ZCNEMsT0FBTyxFQUFFbEMsSUFBSSxDQUFDbUMsRUFBRTtVQUNoQjdDO1FBQ0YsQ0FBd0M7UUFDeEMsSUFBSSxDQUFDTyxLQUFLLEVBQUU7VUFDVixJQUFJO1lBQ0YsTUFBTXVDLEdBQUcsR0FBRyxJQUFBTixrQkFBUSxFQUFDOUIsSUFBSSxDQUFDTSxJQUFJLEVBQUVoQixPQUFPLENBQUMrQyxPQUFPLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1lBQzVELE1BQU1YLEtBQUssR0FBRyxNQUFNakIsb0JBQVcsQ0FBQzZCLFFBQVEsQ0FBRUYsR0FBRyxDQUFDO1lBQzlDLElBQUlWLEtBQUssQ0FBQ2EsVUFBVSxJQUFJbEIsMEJBQWdCLEVBQUVXLElBQUksQ0FBQ04sS0FBSyxHQUFHQSxLQUFLO1VBQzlELENBQUMsQ0FBQyxNQUFNO1lBQ047VUFBQTtRQUVKO1FBQ0EsSUFBSTtVQUNGLE1BQU0sSUFBQWMsa0JBQWEsRUFBQ1IsSUFBSSxDQUFDO1FBQzNCLENBQUMsQ0FBQyxNQUFNO1VBQ047UUFBQTtNQUVKLENBQUMsRUFBRSxDQUFDO0lBQ04sQ0FBQztJQUNEUyxhQUFhLEVBQUVBLENBQUEsS0FBTSxJQUFBQyxtQkFBYyxFQUFDLENBQUM7SUFFckM7SUFDQTtJQUNBQyxLQUFLLEVBQUUsTUFBTzNDLElBQUksSUFBSztNQUNyQixJQUFJLENBQUNBLElBQUksQ0FBQzRDLE9BQU8sRUFBRTtNQUNuQixNQUFNLElBQUFDLGlCQUFZLEVBQUM7UUFBRUQsT0FBTyxFQUFFNUMsSUFBSSxDQUFDNEM7TUFBUSxDQUFDLENBQUM7SUFDL0M7RUFDRixDQUFDO0FBQ0giLCJpZ25vcmVMaXN0IjpbXX0=