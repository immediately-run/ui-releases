"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "Breadcrumb", {
  enumerable: true,
  get: function () {
    return _Breadcrumb.default;
  }
});
Object.defineProperty(exports, "CONTENT_MARKER_FILE", {
  enumerable: true,
  get: function () {
    return _opensWith.CONTENT_MARKER_FILE;
  }
});
Object.defineProperty(exports, "ColumnView", {
  enumerable: true,
  get: function () {
    return _ColumnView.default;
  }
});
Object.defineProperty(exports, "ContextMenu", {
  enumerable: true,
  get: function () {
    return _ContextMenu.default;
  }
});
Object.defineProperty(exports, "FileExplorerView", {
  enumerable: true,
  get: function () {
    return _FileExplorerView.default;
  }
});
Object.defineProperty(exports, "FileGlyph", {
  enumerable: true,
  get: function () {
    return _FileGlyph.default;
  }
});
Object.defineProperty(exports, "IconGrid", {
  enumerable: true,
  get: function () {
    return _IconGrid.default;
  }
});
Object.defineProperty(exports, "LAYOUTS", {
  enumerable: true,
  get: function () {
    return _useLayout.LAYOUTS;
  }
});
Object.defineProperty(exports, "LONG_PRESS_MS", {
  enumerable: true,
  get: function () {
    return _useLongPress.LONG_PRESS_MS;
  }
});
Object.defineProperty(exports, "LayoutSwitcher", {
  enumerable: true,
  get: function () {
    return _LayoutSwitcher.default;
  }
});
Object.defineProperty(exports, "ListView", {
  enumerable: true,
  get: function () {
    return _ListView.default;
  }
});
Object.defineProperty(exports, "MAX_UPLOAD_BYTES", {
  enumerable: true,
  get: function () {
    return _explorer.MAX_UPLOAD_BYTES;
  }
});
Object.defineProperty(exports, "MOVE_MIME", {
  enumerable: true,
  get: function () {
    return _explorer.MOVE_MIME;
  }
});
Object.defineProperty(exports, "TreeStore", {
  enumerable: true,
  get: function () {
    return _treeStore.TreeStore;
  }
});
Object.defineProperty(exports, "WRITE_ERR", {
  enumerable: true,
  get: function () {
    return _explorer.WRITE_ERR;
  }
});
Object.defineProperty(exports, "basename", {
  enumerable: true,
  get: function () {
    return _explorer.basename;
  }
});
Object.defineProperty(exports, "breadcrumbFor", {
  enumerable: true,
  get: function () {
    return _explorer.breadcrumbFor;
  }
});
Object.defineProperty(exports, "compareEntries", {
  enumerable: true,
  get: function () {
    return _entryMeta.compareEntries;
  }
});
Object.defineProperty(exports, "dirOf", {
  enumerable: true,
  get: function () {
    return _explorer.dirOf;
  }
});
Object.defineProperty(exports, "extOf", {
  enumerable: true,
  get: function () {
    return _entryMeta.extOf;
  }
});
Object.defineProperty(exports, "fileTypeLabel", {
  enumerable: true,
  get: function () {
    return _entryMeta.fileTypeLabel;
  }
});
Object.defineProperty(exports, "grantedModeAt", {
  enumerable: true,
  get: function () {
    return _explorer.grantedModeAt;
  }
});
Object.defineProperty(exports, "isEjectable", {
  enumerable: true,
  get: function () {
    return _explorer.isEjectable;
  }
});
Object.defineProperty(exports, "isProtected", {
  enumerable: true,
  get: function () {
    return _explorer.isProtected;
  }
});
Object.defineProperty(exports, "isWritableMount", {
  enumerable: true,
  get: function () {
    return _explorer.isWritableMount;
  }
});
Object.defineProperty(exports, "joinPath", {
  enumerable: true,
  get: function () {
    return _explorer.joinPath;
  }
});
Object.defineProperty(exports, "joinRel", {
  enumerable: true,
  get: function () {
    return _explorer.joinRel;
  }
});
Object.defineProperty(exports, "mountKind", {
  enumerable: true,
  get: function () {
    return _explorer.mountKind;
  }
});
Object.defineProperty(exports, "mountLabel", {
  enumerable: true,
  get: function () {
    return _explorer.mountLabel;
  }
});
Object.defineProperty(exports, "mountScopes", {
  enumerable: true,
  get: function () {
    return _explorer.mountScopes;
  }
});
Object.defineProperty(exports, "mountSpaceId", {
  enumerable: true,
  get: function () {
    return _explorer.mountSpaceId;
  }
});
Object.defineProperty(exports, "moveRejection", {
  enumerable: true,
  get: function () {
    return _explorer.moveRejection;
  }
});
Object.defineProperty(exports, "openWithLabel", {
  enumerable: true,
  get: function () {
    return _opensWith.openWithLabel;
  }
});
Object.defineProperty(exports, "opensInPlaceOffer", {
  enumerable: true,
  get: function () {
    return _opensWith.opensInPlaceOffer;
  }
});
Object.defineProperty(exports, "opensWithOffer", {
  enumerable: true,
  get: function () {
    return _opensWith.opensWithOffer;
  }
});
Object.defineProperty(exports, "orderMounts", {
  enumerable: true,
  get: function () {
    return _explorer.orderMounts;
  }
});
Object.defineProperty(exports, "parseOpensWith", {
  enumerable: true,
  get: function () {
    return _opensWith.parseOpensWith;
  }
});
Object.defineProperty(exports, "runCreate", {
  enumerable: true,
  get: function () {
    return _writeFlow.runCreate;
  }
});
Object.defineProperty(exports, "runDelete", {
  enumerable: true,
  get: function () {
    return _writeFlow.runDelete;
  }
});
Object.defineProperty(exports, "runRename", {
  enumerable: true,
  get: function () {
    return _writeFlow.runRename;
  }
});
Object.defineProperty(exports, "runUpload", {
  enumerable: true,
  get: function () {
    return _writeFlow.runUpload;
  }
});
Object.defineProperty(exports, "subtreeLabel", {
  enumerable: true,
  get: function () {
    return _explorer.subtreeLabel;
  }
});
Object.defineProperty(exports, "toMountRel", {
  enumerable: true,
  get: function () {
    return _explorer.toMountRel;
  }
});
Object.defineProperty(exports, "uploadTargetDir", {
  enumerable: true,
  get: function () {
    return _explorer.uploadTargetDir;
  }
});
Object.defineProperty(exports, "useActive", {
  enumerable: true,
  get: function () {
    return _treeStore.useActive;
  }
});
Object.defineProperty(exports, "useBrowse", {
  enumerable: true,
  get: function () {
    return _useBrowse.useBrowse;
  }
});
Object.defineProperty(exports, "useDir", {
  enumerable: true,
  get: function () {
    return _treeStore.useDir;
  }
});
Object.defineProperty(exports, "useFocused", {
  enumerable: true,
  get: function () {
    return _treeStore.useFocused;
  }
});
Object.defineProperty(exports, "useLayout", {
  enumerable: true,
  get: function () {
    return _useLayout.useLayout;
  }
});
Object.defineProperty(exports, "useLongPress", {
  enumerable: true,
  get: function () {
    return _useLongPress.useLongPress;
  }
});
Object.defineProperty(exports, "useNode", {
  enumerable: true,
  get: function () {
    return _treeStore.useNode;
  }
});
Object.defineProperty(exports, "useOverlayFocusDismiss", {
  enumerable: true,
  get: function () {
    return _useOverlayFocusDismiss.useOverlayFocusDismiss;
  }
});
Object.defineProperty(exports, "usePending", {
  enumerable: true,
  get: function () {
    return _treeStore.usePending;
  }
});
Object.defineProperty(exports, "useRowInteractions", {
  enumerable: true,
  get: function () {
    return _useRowInteractions.useRowInteractions;
  }
});
Object.defineProperty(exports, "useSelected", {
  enumerable: true,
  get: function () {
    return _treeStore.useSelected;
  }
});
Object.defineProperty(exports, "useSelectedRow", {
  enumerable: true,
  get: function () {
    return _treeStore.useSelectedRow;
  }
});
Object.defineProperty(exports, "withdrawsOffer", {
  enumerable: true,
  get: function () {
    return _opensWith.withdrawsOffer;
  }
});
Object.defineProperty(exports, "writeError", {
  enumerable: true,
  get: function () {
    return _writeFlow.writeError;
  }
});
var _FileExplorerView = _interopRequireDefault(require("./FileExplorerView"));
var _useRowInteractions = require("./hooks/useRowInteractions");
var _explorer = require("./explorer");
var _opensWith = require("./opensWith");
var _entryMeta = require("./entryMeta");
var _treeStore = require("./treeStore");
var _writeFlow = require("./writeFlow");
var _useOverlayFocusDismiss = require("./hooks/useOverlayFocusDismiss");
var _ContextMenu = _interopRequireDefault(require("./ContextMenu"));
var _FileGlyph = _interopRequireDefault(require("./FileGlyph"));
var _LayoutSwitcher = _interopRequireDefault(require("./LayoutSwitcher"));
var _Breadcrumb = _interopRequireDefault(require("./Breadcrumb"));
var _ListView = _interopRequireDefault(require("./ListView"));
var _ColumnView = _interopRequireDefault(require("./ColumnView"));
var _IconGrid = _interopRequireDefault(require("./IconGrid"));
var _useLongPress = require("./hooks/useLongPress");
var _useLayout = require("./hooks/useLayout");
var _useBrowse = require("./hooks/useBrowse");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfRmlsZUV4cGxvcmVyVmlldyIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJyZXF1aXJlIiwiX3VzZVJvd0ludGVyYWN0aW9ucyIsIl9leHBsb3JlciIsIl9vcGVuc1dpdGgiLCJfZW50cnlNZXRhIiwiX3RyZWVTdG9yZSIsIl93cml0ZUZsb3ciLCJfdXNlT3ZlcmxheUZvY3VzRGlzbWlzcyIsIl9Db250ZXh0TWVudSIsIl9GaWxlR2x5cGgiLCJfTGF5b3V0U3dpdGNoZXIiLCJfQnJlYWRjcnVtYiIsIl9MaXN0VmlldyIsIl9Db2x1bW5WaWV3IiwiX0ljb25HcmlkIiwiX3VzZUxvbmdQcmVzcyIsIl91c2VMYXlvdXQiLCJfdXNlQnJvd3NlIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0Il0sInNvdXJjZXMiOlsiaW5kZXgudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gUHVibGljIHN1cmZhY2Ugb2YgdGhlIGhlYWRsZXNzIGZpbGUtZXhwbG9yZXIgbGlicmFyeSAodGhlIGNvcmUgdmlldywgTk8gU0RLKS5cbi8vIGBGaWxlRXhwbG9yZXJWaWV3YCBpcyB0aGUgZW50cnkgcG9pbnQ7IHRoZSByZXN0IGFyZSB0aGUgdHlwZXMsIGhlbHBlcnMsIHN0b3JlLFxuLy8gaG9va3MsIGFuZCBwcmVzZW50YXRpb25hbCBwaWVjZXMgY29uc3VtZXJzIGJ1aWxkIG9uLlxuXG4vLyBUaGUgaGVhZGxlc3Mgdmlldy5cbmV4cG9ydCB7IGRlZmF1bHQgYXMgRmlsZUV4cGxvcmVyVmlldyB9IGZyb20gXCIuL0ZpbGVFeHBsb3JlclZpZXdcIjtcbmV4cG9ydCB0eXBlIHsgRmlsZUV4cGxvcmVyVmlld1Byb3BzIH0gZnJvbSBcIi4vRmlsZUV4cGxvcmVyVmlld1wiO1xuXG4vLyBUaGUgcm93IGdlc3R1cmUgYnVuZGxlICsgaXRzIHR5cGVzLlxuZXhwb3J0IHsgdXNlUm93SW50ZXJhY3Rpb25zIH0gZnJvbSBcIi4vaG9va3MvdXNlUm93SW50ZXJhY3Rpb25zXCI7XG5leHBvcnQgdHlwZSB7IE5vZGVIYW5kbGVycywgUm93UHJvcHMgfSBmcm9tIFwiLi9ob29rcy91c2VSb3dJbnRlcmFjdGlvbnNcIjtcblxuLy8gVHlwZXMgKHRoZSBpbmplY3RlZCBpbnRlcmZhY2VzIOKAlCAwMC1vdmVydmlldyDCpzMuMSkuXG5leHBvcnQgdHlwZSB7XG4gIEV4cGxvcmVyUm9vdCxcbiAgRGlyRW50cnksXG4gIEVudHJ5LFxuICBGc1NvdXJjZSxcbiAgRXhwbG9yZXJBY3Rpb25zLFxuICBMYXlvdXQsXG4gIE1lbnVJdGVtLFxuICBNZW51QW5jaG9yLFxuICBSb3dDdHgsXG59IGZyb20gXCIuL3R5cGVzXCI7XG5cbi8vIFB1cmUgaGVscGVycyAocGF0aCBtYXRoLCByb290IG1ldGFkYXRhLCBkcmFnL21vdmUgdmFsaWRpdHkpLlxuZXhwb3J0IHtcbiAgam9pblBhdGgsXG4gIGpvaW5SZWwsXG4gIGJhc2VuYW1lLFxuICBkaXJPZixcbiAgdG9Nb3VudFJlbCxcbiAgbW91bnRMYWJlbCxcbiAgbW91bnRLaW5kLFxuICBtb3VudFNwYWNlSWQsXG4gIGlzRWplY3RhYmxlLFxuICBpc1dyaXRhYmxlTW91bnQsXG4gIGdyYW50ZWRNb2RlQXQsXG4gIG1vdW50U2NvcGVzLFxuICBzdWJ0cmVlTGFiZWwsXG4gIG9yZGVyTW91bnRzLFxuICBpc1Byb3RlY3RlZCxcbiAgYnJlYWRjcnVtYkZvcixcbiAgbW92ZVJlamVjdGlvbixcbiAgdXBsb2FkVGFyZ2V0RGlyLFxuICBNT1ZFX01JTUUsXG4gIE1BWF9VUExPQURfQllURVMsXG4gIFdSSVRFX0VSUixcbn0gZnJvbSBcIi4vZXhwbG9yZXJcIjtcbmV4cG9ydCB0eXBlIHsgTW91bnRLaW5kLCBNb3VudFNjb3BlLCBDcnVtYiwgTW92ZVBheWxvYWQgfSBmcm9tIFwiLi9leHBsb3JlclwiO1xuXG4vLyBSMy0yNjc6IHRoZSBgb3BlbnNXaXRoYCBkZWNpc2lvbiDigJQgcHVyZSwgc28gYW55IGZpbGUgbWFuYWdlciBidWlsdCBvbiB0aGlzIGxpYnJhcnlcbi8vIGNhbiBvZmZlciBhIG1hcmtlZCBmb2xkZXIgd2l0aG91dCByZS1kZXJpdmluZyB0aGUgcnVsZXMuIFIzLTE1OSBhZGRzIHRoZVxuLy8gaW50by1zdGFnZSB0d2luIChgb3BlbnNJblBsYWNlT2ZmZXJgIOKAlCBsYXVuY2hhYmxlLW9ubHksIGZpeGVkIHByb2R1Y3QgbGFiZWwpLlxuZXhwb3J0IHtcbiAgQ09OVEVOVF9NQVJLRVJfRklMRSxcbiAgb3BlbldpdGhMYWJlbCxcbiAgb3BlbnNJblBsYWNlT2ZmZXIsXG4gIG9wZW5zV2l0aE9mZmVyLFxuICBwYXJzZU9wZW5zV2l0aCxcbiAgd2l0aGRyYXdzT2ZmZXIsXG59IGZyb20gXCIuL29wZW5zV2l0aFwiO1xuZXhwb3J0IHR5cGUgeyBPcGVuc1dpdGhNYXJrZXIsIE9wZW5zV2l0aE9mZmVyLCBPcGVuc1dpdGhQb2xpY3ksIE9wZW5zSW5QbGFjZVBvbGljeSB9IGZyb20gXCIuL29wZW5zV2l0aFwiO1xuXG5leHBvcnQgeyBleHRPZiwgZmlsZVR5cGVMYWJlbCwgY29tcGFyZUVudHJpZXMgfSBmcm9tIFwiLi9lbnRyeU1ldGFcIjtcbmV4cG9ydCB0eXBlIHsgU29ydEtleSwgU29ydGFibGVFbnRyeSB9IGZyb20gXCIuL2VudHJ5TWV0YVwiO1xuXG4vLyBUaGUgcGF0aC1rZXllZCB0cmVlIHN0b3JlICsgaXRzIHBlci1zbGljZSBzdWJzY3JpcHRpb24gaG9va3MuXG5leHBvcnQge1xuICBUcmVlU3RvcmUsXG4gIHVzZU5vZGUsXG4gIHVzZVNlbGVjdGVkLFxuICB1c2VTZWxlY3RlZFJvdyxcbiAgdXNlQWN0aXZlLFxuICB1c2VEaXIsXG4gIHVzZVBlbmRpbmcsXG4gIHVzZUZvY3VzZWQsXG59IGZyb20gXCIuL3RyZWVTdG9yZVwiO1xuXG4vLyBUaGUgb3B0aW1pc3RpYyB3cml0ZSBmbG93IChwb3J0cyArIHBlci1vcCBvcmNoZXN0cmF0aW9uKS5cbmV4cG9ydCB7IHJ1bkNyZWF0ZSwgcnVuUmVuYW1lLCBydW5EZWxldGUsIHJ1blVwbG9hZCwgd3JpdGVFcnJvciB9IGZyb20gXCIuL3dyaXRlRmxvd1wiO1xuZXhwb3J0IHR5cGUgeyBXcml0ZVBvcnRzIH0gZnJvbSBcIi4vd3JpdGVGbG93XCI7XG5cbi8vIFRoZSBvdmVybGF5IGNvbnRyYWN0IGhvb2sgKGRpYWxvZyArIG1lbnUgZm9jdXMvRXNjYXBlL1RhYiBiZWhhdmlvdXIpLlxuZXhwb3J0IHsgdXNlT3ZlcmxheUZvY3VzRGlzbWlzcyB9IGZyb20gXCIuL2hvb2tzL3VzZU92ZXJsYXlGb2N1c0Rpc21pc3NcIjtcblxuLy8gUHJlc2VudGF0aW9uYWwgcGllY2VzICsgdGhlIGxheW91dHMuXG5leHBvcnQgeyBkZWZhdWx0IGFzIENvbnRleHRNZW51IH0gZnJvbSBcIi4vQ29udGV4dE1lbnVcIjtcbmV4cG9ydCB7IGRlZmF1bHQgYXMgRmlsZUdseXBoIH0gZnJvbSBcIi4vRmlsZUdseXBoXCI7XG5leHBvcnQgeyBkZWZhdWx0IGFzIExheW91dFN3aXRjaGVyIH0gZnJvbSBcIi4vTGF5b3V0U3dpdGNoZXJcIjtcbmV4cG9ydCB7IGRlZmF1bHQgYXMgQnJlYWRjcnVtYiB9IGZyb20gXCIuL0JyZWFkY3J1bWJcIjtcbmV4cG9ydCB7IGRlZmF1bHQgYXMgTGlzdFZpZXcgfSBmcm9tIFwiLi9MaXN0Vmlld1wiO1xuZXhwb3J0IHsgZGVmYXVsdCBhcyBDb2x1bW5WaWV3IH0gZnJvbSBcIi4vQ29sdW1uVmlld1wiO1xuZXhwb3J0IHsgZGVmYXVsdCBhcyBJY29uR3JpZCB9IGZyb20gXCIuL0ljb25HcmlkXCI7XG5cbi8vIEhvb2tzLlxuZXhwb3J0IHsgdXNlTG9uZ1ByZXNzLCBMT05HX1BSRVNTX01TIH0gZnJvbSBcIi4vaG9va3MvdXNlTG9uZ1ByZXNzXCI7XG5leHBvcnQgeyB1c2VMYXlvdXQsIExBWU9VVFMgfSBmcm9tIFwiLi9ob29rcy91c2VMYXlvdXRcIjtcbmV4cG9ydCB7IHVzZUJyb3dzZSB9IGZyb20gXCIuL2hvb2tzL3VzZUJyb3dzZVwiO1xuZXhwb3J0IHR5cGUgeyBCcm93c2VSb3csIEJyb3dzZSB9IGZyb20gXCIuL2hvb2tzL3VzZUJyb3dzZVwiO1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUtBLElBQUFBLGlCQUFBLEdBQUFDLHNCQUFBLENBQUFDLE9BQUE7QUFJQSxJQUFBQyxtQkFBQSxHQUFBRCxPQUFBO0FBaUJBLElBQUFFLFNBQUEsR0FBQUYsT0FBQTtBQTRCQSxJQUFBRyxVQUFBLEdBQUFILE9BQUE7QUFVQSxJQUFBSSxVQUFBLEdBQUFKLE9BQUE7QUFJQSxJQUFBSyxVQUFBLEdBQUFMLE9BQUE7QUFZQSxJQUFBTSxVQUFBLEdBQUFOLE9BQUE7QUFJQSxJQUFBTyx1QkFBQSxHQUFBUCxPQUFBO0FBR0EsSUFBQVEsWUFBQSxHQUFBVCxzQkFBQSxDQUFBQyxPQUFBO0FBQ0EsSUFBQVMsVUFBQSxHQUFBVixzQkFBQSxDQUFBQyxPQUFBO0FBQ0EsSUFBQVUsZUFBQSxHQUFBWCxzQkFBQSxDQUFBQyxPQUFBO0FBQ0EsSUFBQVcsV0FBQSxHQUFBWixzQkFBQSxDQUFBQyxPQUFBO0FBQ0EsSUFBQVksU0FBQSxHQUFBYixzQkFBQSxDQUFBQyxPQUFBO0FBQ0EsSUFBQWEsV0FBQSxHQUFBZCxzQkFBQSxDQUFBQyxPQUFBO0FBQ0EsSUFBQWMsU0FBQSxHQUFBZixzQkFBQSxDQUFBQyxPQUFBO0FBR0EsSUFBQWUsYUFBQSxHQUFBZixPQUFBO0FBQ0EsSUFBQWdCLFVBQUEsR0FBQWhCLE9BQUE7QUFDQSxJQUFBaUIsVUFBQSxHQUFBakIsT0FBQTtBQUE4QyxTQUFBRCx1QkFBQW1CLENBQUEsV0FBQUEsQ0FBQSxJQUFBQSxDQUFBLENBQUFDLFVBQUEsR0FBQUQsQ0FBQSxLQUFBRSxPQUFBLEVBQUFGLENBQUEiLCJpZ25vcmVMaXN0IjpbXX0=