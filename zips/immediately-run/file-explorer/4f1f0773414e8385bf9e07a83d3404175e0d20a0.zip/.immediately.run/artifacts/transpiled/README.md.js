var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      code: "code",
      h1: "h1",
      p: "p",
      strong: "strong",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "file-explorer",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "file-explorer"
      }), "file-explorer"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["A read-only ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "file explorer"
      }), " system app for ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "https://immediately.run",
        children: "immediately.run"
      }), "\n— the Phase 03 read-only pilot for the §3.2 app-as-chrome loader\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "UI_AS_APPS_SPEC"
      }), " §4 / §8.7, design brief 10)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["It shows a tree of a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "mount"
      }), "'s contents — a space or a granted subtree the user\nhas shared with this app — with each mount's grant scope made visible. It reads\nthe active mounts through the SDK (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "useMounts"
      }), ") and file entries from the sandbox\nfilesystem at the mount path. It explores only granted mounts, never the project\nyou're editing: a sandboxed app can only see what its mounts expose."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Read-only by design (no create / rename / delete). Loaded into a chrome region\nby the host; not meant to be run standalone."
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/README.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiY29kZSIsImgxIiwicCIsInN0cm9uZyIsIl9wcm92aWRlQ29tcG9uZW50cyIsImNvbXBvbmVudHMiLCJIZWFkaW5nQW5jaG9yIiwiX21pc3NpbmdNZHhSZWZlcmVuY2UiLCJqc3hzIiwiRnJhZ21lbnQiLCJjaGlsZHJlbiIsImlkIiwianN4IiwiaHJlZiIsIk1EWENvbnRlbnQiLCJ3cmFwcGVyIiwiTURYTGF5b3V0IiwiX2MiLCJjb21wb25lbnQiLCJwbGFjZSIsIkVycm9yIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUkVBRE1FLm1kIl0sInNvdXJjZXNDb250ZW50IjpbIi8qQGpzeFJ1bnRpbWUgYXV0b21hdGljKi9cbi8qQGpzeEltcG9ydFNvdXJjZSByZWFjdCovXG5pbXBvcnQge3VzZU1EWENvbXBvbmVudHMgYXMgX3Byb3ZpZGVDb21wb25lbnRzfSBmcm9tIFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGsvTURYUHJvdmlkZXJcIjtcbmZ1bmN0aW9uIF9jcmVhdGVNZHhDb250ZW50KHByb3BzKSB7XG4gIGNvbnN0IF9jb21wb25lbnRzID0ge1xuICAgIGE6IFwiYVwiLFxuICAgIGNvZGU6IFwiY29kZVwiLFxuICAgIGgxOiBcImgxXCIsXG4gICAgcDogXCJwXCIsXG4gICAgc3Ryb25nOiBcInN0cm9uZ1wiLFxuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfSwge0hlYWRpbmdBbmNob3J9ID0gX2NvbXBvbmVudHM7XG4gIGlmICghSGVhZGluZ0FuY2hvcikgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJIZWFkaW5nQW5jaG9yXCIsIHRydWUpO1xuICByZXR1cm4gPD48X2NvbXBvbmVudHMuaDEgaWQ9XCJmaWxlLWV4cGxvcmVyXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJmaWxlLWV4cGxvcmVyXCIgLz57XCJmaWxlLWV4cGxvcmVyXCJ9PC9fY29tcG9uZW50cy5oMT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJBIHJlYWQtb25seSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImZpbGUgZXhwbG9yZXJcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgc3lzdGVtIGFwcCBmb3IgXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cImh0dHBzOi8vaW1tZWRpYXRlbHkucnVuXCI+e1wiaW1tZWRpYXRlbHkucnVuXCJ9PC9fY29tcG9uZW50cy5hPntcIlxcbuKAlCB0aGUgUGhhc2UgMDMgcmVhZC1vbmx5IHBpbG90IGZvciB0aGUgwqczLjIgYXBwLWFzLWNocm9tZSBsb2FkZXJcXG4oXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiVUlfQVNfQVBQU19TUEVDXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDCpzQgLyDCpzguNywgZGVzaWduIGJyaWVmIDEwKS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiSXQgc2hvd3MgYSB0cmVlIG9mIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJtb3VudFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIidzIGNvbnRlbnRzIOKAlCBhIHNwYWNlIG9yIGEgZ3JhbnRlZCBzdWJ0cmVlIHRoZSB1c2VyXFxuaGFzIHNoYXJlZCB3aXRoIHRoaXMgYXBwIOKAlCB3aXRoIGVhY2ggbW91bnQncyBncmFudCBzY29wZSBtYWRlIHZpc2libGUuIEl0IHJlYWRzXFxudGhlIGFjdGl2ZSBtb3VudHMgdGhyb3VnaCB0aGUgU0RLIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJ1c2VNb3VudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSBhbmQgZmlsZSBlbnRyaWVzIGZyb20gdGhlIHNhbmRib3hcXG5maWxlc3lzdGVtIGF0IHRoZSBtb3VudCBwYXRoLiBJdCBleHBsb3JlcyBvbmx5IGdyYW50ZWQgbW91bnRzLCBuZXZlciB0aGUgcHJvamVjdFxcbnlvdSdyZSBlZGl0aW5nOiBhIHNhbmRib3hlZCBhcHAgY2FuIG9ubHkgc2VlIHdoYXQgaXRzIG1vdW50cyBleHBvc2UuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlJlYWQtb25seSBieSBkZXNpZ24gKG5vIGNyZWF0ZSAvIHJlbmFtZSAvIGRlbGV0ZSkuIExvYWRlZCBpbnRvIGEgY2hyb21lIHJlZ2lvblxcbmJ5IHRoZSBob3N0OyBub3QgbWVhbnQgdG8gYmUgcnVuIHN0YW5kYWxvbmUuXCJ9PC9fY29tcG9uZW50cy5wPjwvPjtcbn1cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE1EWENvbnRlbnQocHJvcHMgPSB7fSkge1xuICBjb25zdCB7d3JhcHBlcjogTURYTGF5b3V0fSA9IHtcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH07XG4gIHJldHVybiBNRFhMYXlvdXQgPyA8TURYTGF5b3V0IHsuLi5wcm9wc30+PF9jcmVhdGVNZHhDb250ZW50IHsuLi5wcm9wc30gLz48L01EWExheW91dD4gOiBfY3JlYXRlTWR4Q29udGVudChwcm9wcyk7XG59XG5mdW5jdGlvbiBfbWlzc2luZ01keFJlZmVyZW5jZShpZCwgY29tcG9uZW50LCBwbGFjZSkge1xuICB0aHJvdyBuZXcgRXJyb3IoXCJFeHBlY3RlZCBcIiArIChjb21wb25lbnQgPyBcImNvbXBvbmVudFwiIDogXCJvYmplY3RcIikgKyBcIiBgXCIgKyBpZCArIFwiYCB0byBiZSBkZWZpbmVkOiB5b3UgbGlrZWx5IGZvcmdvdCB0byBpbXBvcnQsIHBhc3MsIG9yIHByb3ZpZGUgaXQuXCIgKyAocGxhY2UgPyBcIlxcbkl04oCZcyByZWZlcmVuY2VkIGluIHlvdXIgY29kZSBhdCBgXCIgKyBwbGFjZSArIFwiYCBpbiBgL2FwcC9SRUFETUUubWRgXCIgOiBcIlwiKSk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUVBLElBQUFBLFlBQUEsR0FBQUMsT0FBQTtBQUF3RixJQUFBQyxXQUFBLEdBQUFELE9BQUE7QUFGeEY7QUFDQTs7QUFFQSxTQUFTRSxpQkFBaUJBLENBQUNDLEtBQUssRUFBRTtFQUNoQyxNQUFNQyxXQUFXLEdBQUc7TUFDbEJDLENBQUMsRUFBRSxHQUFHO01BQ05DLElBQUksRUFBRSxNQUFNO01BQ1pDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLENBQUMsRUFBRSxHQUFHO01BQ05DLE1BQU0sRUFBRSxRQUFRO01BQ2hCLEdBQUcsSUFBQUMsNkJBQWtCLEVBQUMsQ0FBQztNQUN2QixHQUFHUCxLQUFLLENBQUNRO0lBQ1gsQ0FBQztJQUFFO01BQUNDO0lBQWEsQ0FBQyxHQUFHUixXQUFXO0VBQ2hDLElBQUksQ0FBQ1EsYUFBYSxFQUFFQyxvQkFBb0IsQ0FBQyxlQUFlLEVBQUUsSUFBSSxDQUFDO0VBQy9ELG9CQUFPLElBQUFaLFdBQUEsQ0FBQWEsSUFBQSxFQUFBYixXQUFBLENBQUFjLFFBQUE7SUFBQUMsUUFBQSxnQkFBRSxJQUFBZixXQUFBLENBQUFhLElBQUEsRUFBQ1YsV0FBVyxDQUFDRyxFQUFFO01BQUNVLEVBQUUsRUFBQyxlQUFlO01BQUFELFFBQUEsZ0JBQUMsSUFBQWYsV0FBQSxDQUFBaUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFlLENBQUUsQ0FBQyxFQUFDLGVBQWU7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFoQixXQUFBLENBQUFhLElBQUEsRUFBQ1YsV0FBVyxDQUFDSSxDQUFDO01BQUFRLFFBQUEsR0FBRSxjQUFjLGVBQUMsSUFBQWYsV0FBQSxDQUFBaUIsR0FBQSxFQUFDZCxXQUFXLENBQUNLLE1BQU07UUFBQU8sUUFBQSxFQUFFO01BQWUsQ0FBcUIsQ0FBQyxFQUFDLGtCQUFrQixlQUFDLElBQUFmLFdBQUEsQ0FBQWlCLEdBQUEsRUFBQ2QsV0FBVyxDQUFDQyxDQUFDO1FBQUNjLElBQUksRUFBQyx5QkFBeUI7UUFBQUgsUUFBQSxFQUFFO01BQWlCLENBQWdCLENBQUMsRUFBQyx1RUFBdUUsZUFBQyxJQUFBZixXQUFBLENBQUFpQixHQUFBLEVBQUNkLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBVSxRQUFBLEVBQUU7TUFBaUIsQ0FBbUIsQ0FBQyxFQUFDLCtCQUErQjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWYsV0FBQSxDQUFBYSxJQUFBLEVBQUNWLFdBQVcsQ0FBQ0ksQ0FBQztNQUFBUSxRQUFBLEdBQUUsdUJBQXVCLGVBQUMsSUFBQWYsV0FBQSxDQUFBaUIsR0FBQSxFQUFDZCxXQUFXLENBQUNLLE1BQU07UUFBQU8sUUFBQSxFQUFFO01BQU8sQ0FBcUIsQ0FBQyxFQUFDLDJLQUEySyxlQUFDLElBQUFmLFdBQUEsQ0FBQWlCLEdBQUEsRUFBQ2QsV0FBVyxDQUFDRSxJQUFJO1FBQUFVLFFBQUEsRUFBRTtNQUFXLENBQW1CLENBQUMsRUFBQyw2TEFBNkw7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFmLFdBQUEsQ0FBQWlCLEdBQUEsRUFBQ2QsV0FBVyxDQUFDSSxDQUFDO01BQUFRLFFBQUEsRUFBRTtJQUE4SCxDQUFnQixDQUFDO0VBQUEsQ0FBRSxDQUFDO0FBQ2hxQztBQUNlLFNBQVNJLFVBQVVBLENBQUNqQixLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUU7RUFDN0MsTUFBTTtJQUFDa0IsT0FBTyxFQUFFQztFQUFTLENBQUMsR0FBRztJQUMzQixHQUFHLElBQUFaLDZCQUFrQixFQUFDLENBQUM7SUFDdkIsR0FBR1AsS0FBSyxDQUFDUTtFQUNYLENBQUM7RUFDRCxPQUFPVyxTQUFTLGdCQUFHLElBQUFyQixXQUFBLENBQUFpQixHQUFBLEVBQUNJLFNBQVM7SUFBQSxHQUFLbkIsS0FBSztJQUFBYSxRQUFBLGVBQUUsSUFBQWYsV0FBQSxDQUFBaUIsR0FBQSxFQUFDaEIsaUJBQWlCO01BQUEsR0FBS0M7SUFBSyxDQUFHO0VBQUMsQ0FBVyxDQUFDLEdBQUdELGlCQUFpQixDQUFDQyxLQUFLLENBQUM7QUFDbEg7QUFBQ29CLEVBQUEsR0FOdUJILFVBQVU7QUFPbEMsU0FBU1Asb0JBQW9CQSxDQUFDSSxFQUFFLEVBQUVPLFNBQVMsRUFBRUMsS0FBSyxFQUFFO0VBQ2xELE1BQU0sSUFBSUMsS0FBSyxDQUFDLFdBQVcsSUFBSUYsU0FBUyxHQUFHLFdBQVcsR0FBRyxRQUFRLENBQUMsR0FBRyxJQUFJLEdBQUdQLEVBQUUsR0FBRyxvRUFBb0UsSUFBSVEsS0FBSyxHQUFHLHFDQUFxQyxHQUFHQSxLQUFLLEdBQUcsdUJBQXVCLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDalA7QUFBQyxJQUFBRixFQUFBO0FBQUFJLFlBQUEsQ0FBQUosRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}