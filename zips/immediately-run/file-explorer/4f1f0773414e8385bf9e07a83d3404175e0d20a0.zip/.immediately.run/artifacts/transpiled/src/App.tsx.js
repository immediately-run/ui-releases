var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
require("./index.css");
require("./App.css");
var _FileExplorer = _interopRequireDefault(require("./components/FileExplorer"));
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// Root component — immediately.run renders the default export of THIS file.
// Global CSS is imported here (not main.tsx). A read-only system app: a tree
// view of the mounts (spaces / granted subtrees) shared with this app.

function App() {
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_FileExplorer.default, {});
}
_c = App;
var _default = exports.default = App;
var _c;
$RefreshReg$(_c, "App");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJyZXF1aXJlIiwiX0ZpbGVFeHBsb3JlciIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJfanN4UnVudGltZSIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsIkFwcCIsImpzeCIsIl9jIiwiX2RlZmF1bHQiLCJleHBvcnRzIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQXBwLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBSb290IGNvbXBvbmVudCDigJQgaW1tZWRpYXRlbHkucnVuIHJlbmRlcnMgdGhlIGRlZmF1bHQgZXhwb3J0IG9mIFRISVMgZmlsZS5cbi8vIEdsb2JhbCBDU1MgaXMgaW1wb3J0ZWQgaGVyZSAobm90IG1haW4udHN4KS4gQSByZWFkLW9ubHkgc3lzdGVtIGFwcDogYSB0cmVlXG4vLyB2aWV3IG9mIHRoZSBtb3VudHMgKHNwYWNlcyAvIGdyYW50ZWQgc3VidHJlZXMpIHNoYXJlZCB3aXRoIHRoaXMgYXBwLlxuaW1wb3J0IFwiLi9pbmRleC5jc3NcIjtcbmltcG9ydCBcIi4vQXBwLmNzc1wiO1xuaW1wb3J0IEZpbGVFeHBsb3JlciBmcm9tIFwiLi9jb21wb25lbnRzL0ZpbGVFeHBsb3JlclwiO1xuXG5mdW5jdGlvbiBBcHAoKSB7XG4gIHJldHVybiA8RmlsZUV4cGxvcmVyIC8+O1xufVxuXG5leHBvcnQgZGVmYXVsdCBBcHA7XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUdBQSxPQUFBO0FBQ0FBLE9BQUE7QUFDQSxJQUFBQyxhQUFBLEdBQUFDLHNCQUFBLENBQUFGLE9BQUE7QUFBcUQsSUFBQUcsV0FBQSxHQUFBSCxPQUFBO0FBQUEsU0FBQUUsdUJBQUFFLENBQUEsV0FBQUEsQ0FBQSxJQUFBQSxDQUFBLENBQUFDLFVBQUEsR0FBQUQsQ0FBQSxLQUFBRSxPQUFBLEVBQUFGLENBQUE7QUFMckQ7QUFDQTtBQUNBOztBQUtBLFNBQVNHLEdBQUdBLENBQUEsRUFBRztFQUNiLG9CQUFPLElBQUFKLFdBQUEsQ0FBQUssR0FBQSxFQUFDUCxhQUFBLENBQUFLLE9BQVksSUFBRSxDQUFDO0FBQ3pCO0FBQUNHLEVBQUEsR0FGUUYsR0FBRztBQUFBLElBQUFHLFFBQUEsR0FBQUMsT0FBQSxDQUFBTCxPQUFBLEdBSUdDLEdBQUc7QUFBQSxJQUFBRSxFQUFBO0FBQUFHLFlBQUEsQ0FBQUgsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}