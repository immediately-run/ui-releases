var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.find.js");
require("core-js/modules/esnext.iterator.map.js");
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
var _lucideReact = require("lucide-react");
var _mountFs = require("../fs/mountFs");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(),
  _s2 = $RefreshSig$(); // The file explorer (UI_AS_APPS_SPEC §4 / §3.5; migrate-sidebars Phase 03). A
// tree view of the EDITOR SESSION's working tree — the repo you're editing —
// surfaced to this app as a scoped `/mnt/{hash}` mount (`type: 'worktree'`, §3.5).
// Clicking a file asks the host to open it in the editor (`openInEditor`, the §4
// `editor:open` intent — the editor stays host-owned, §2).
//
// Read-only for now: no create / rename / delete / upload (working-tree mutation
// is a separate kernel-gated host action, migrate-sidebars Phase 04). With no
// editor session (e.g. signed-out, or no working tree), it shows an empty state.
//
// Known v1 gap: a system app keeps its OWN route (drivesHostRoute=false), so it
// can't read the host editor's ACTIVE file from routing — there is no
// active-file highlight / auto-reveal yet. Surfacing the active file to a panel is
// a small additive editor-context channel (a later phase).
const joinPath = (dir, name) => `${dir.replace(/\/+$/, "")}/${name}`;

// The working-tree fs can lag its mount descriptor at boot: `useMounts()` surfaces
// the worktree as soon as the host announces it, but the sandbox-local ZenFS mount
// it points at may not be attached the instant the root folder first reads. A
// single failure used to latch a permanent "Couldn't read this folder"; instead we
// retry a bounded number of times before giving up, so the common boot race heals
// itself. ~READ_MAX_ATTEMPTS × READ_RETRY_MS ≈ a few seconds of patience.
const READ_MAX_ATTEMPTS = 12;
const READ_RETRY_MS = 250;

/** A lazily-loaded tree node following the ARIA tree pattern. File rows are
 *  buttons that open the file in the host editor; directory rows expand/collapse. */
function TreeNode({
  path,
  name,
  isDir,
  depth,
  rootPath,
  collapseEpoch,
  defaultOpen = false,
  onOpenFile
}) {
  _s();
  const [open, setOpen] = (0, _react.useState)(defaultOpen);
  const [entries, setEntries] = (0, _react.useState)(null);
  const [errored, setErrored] = (0, _react.useState)(false);
  // Bumped to re-trigger the read effect when a read fails transiently (the
  // boot-time fs race). Counts toward READ_MAX_ATTEMPTS before we give up.
  const [attempt, setAttempt] = (0, _react.useState)(0);
  // Loading is DERIVED (not effect-set state): a dir that's open with nothing
  // loaded yet and no error is loading (including while we retry).
  const loading = isDir && open && entries === null && !errored;

  // A "collapse all" closes every node; re-opening a folder re-reads it.
  (0, _react.useEffect)(() => {
    if (!defaultOpen) setOpen(false);
  }, [collapseEpoch, defaultOpen]);
  (0, _react.useEffect)(() => {
    if (!isDir || !open || entries !== null || errored) return;
    let live = true;
    let timer;
    (0, _mountFs.readdir)(path).then(list => live && setEntries(list)).catch(() => {
      if (!live) return;
      // Transient at boot (fs not yet attached at the mount path) — retry a
      // bounded number of times before surfacing the error, so a too-early
      // first read doesn't strand the folder permanently.
      if (attempt < READ_MAX_ATTEMPTS) {
        timer = setTimeout(() => live && setAttempt(a => a + 1), READ_RETRY_MS);
      } else {
        setErrored(true);
      }
    });
    return () => {
      live = false;
      if (timer) clearTimeout(timer);
    };
  }, [isDir, open, entries, errored, path, attempt]);
  const openFile = () => {
    // Repo-relative path = the mount-rooted path minus the `/mnt/{hash}` prefix
    // (openInEditor accepts a leading slash). NOT the sandbox `/mnt/...` path.
    onOpenFile(path.slice(rootPath.length) || "/" + name);
  };
  const activate = () => isDir ? setOpen(v => !v) : openFile();
  const onKeyDown = e => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      activate();
    } else if (isDir && e.key === "ArrowRight" && !open) {
      setOpen(true);
    } else if (isDir && e.key === "ArrowLeft" && open) {
      setOpen(false);
    }
  };
  const Icon = isDir ? open ? _lucideReact.FolderOpen : _lucideReact.Folder : _lucideReact.File;
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("li", {
    role: "treeitem",
    "aria-expanded": isDir ? open : undefined,
    "aria-label": name,
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "tnode",
      style: {
        paddingLeft: 8 + depth * 14
      },
      tabIndex: 0,
      onClick: activate,
      onKeyDown: onKeyDown,
      "data-dir": isDir ? "1" : "0",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "tnode__icon",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(Icon, {
          size: 15,
          "aria-hidden": "true"
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "tnode__name",
        children: name
      }), loading && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "tnode__spin",
        "aria-hidden": "true",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.Loader2, {
          size: 13
        })
      })]
    }), isDir && open && /*#__PURE__*/(0, _jsxRuntime.jsxs)("ul", {
      role: "group",
      children: [errored && /*#__PURE__*/(0, _jsxRuntime.jsx)("li", {
        className: "tnode tnode--muted",
        style: {
          paddingLeft: 8 + (depth + 1) * 14
        },
        children: "Couldn\u2019t read this folder."
      }), entries?.length === 0 && /*#__PURE__*/(0, _jsxRuntime.jsx)("li", {
        className: "tnode tnode--muted",
        style: {
          paddingLeft: 8 + (depth + 1) * 14
        },
        children: "Empty"
      }), entries?.map(e => /*#__PURE__*/(0, _jsxRuntime.jsx)(TreeNode, {
        path: joinPath(path, e.name),
        name: e.name,
        isDir: e.isDir,
        depth: depth + 1,
        rootPath: rootPath,
        collapseEpoch: collapseEpoch,
        onOpenFile: onOpenFile
      }, e.name))]
    })]
  });
}
_s(TreeNode, "LZa5H63xglnCQhGgVhKp+gl63Qk=");
_c = TreeNode;
function FileExplorer() {
  _s2();
  const mounts = (0, _sdk.useMounts)();
  const [collapseEpoch, setCollapseEpoch] = (0, _react.useState)(0);
  const [openError, setOpenError] = (0, _react.useState)(null);

  // The working tree (the repo being edited) is published to this panel as a
  // `type: 'worktree'` mount (§3.5). Prefer it; there is at most one.
  const worktree = mounts.find(m => m.type === "worktree");
  const onOpenFile = repoRelativePath => {
    setOpenError(null);
    void (0, _sdk.openInEditor)(repoRelativePath).catch(e => {
      const code = e?.code;
      // `forbidden` shouldn't happen for the correctly-bound panel; `not-found`
      // is a benign race (file deleted under us). Surface only the unexpected.
      if (code && code !== "not-found") setOpenError("Couldn’t open that file.");
    });
  };
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("section", {
    className: "panel",
    "aria-label": "Files",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("header", {
      className: "panel__head",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "panel__glyph",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.FolderTree, {
          size: 15,
          "aria-hidden": "true"
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "panel__title",
        children: "Files"
      }), worktree && /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        type: "button",
        className: "panel__action",
        title: "Collapse all folders",
        "aria-label": "Collapse all folders",
        onClick: () => setCollapseEpoch(e => e + 1),
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.ChevronsDownUp, {
          size: 15,
          "aria-hidden": "true"
        })
      })]
    }), openError && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "panel__error",
      role: "alert",
      onClick: () => setOpenError(null),
      children: openError
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "panel__body",
      children: !worktree ? /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "state",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "state__icon",
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.FolderTree, {
            size: 20,
            "aria-hidden": "true"
          })
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("h4", {
          children: "No files to show yet."
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
          children: "Open a project in the editor and its files appear here."
        })]
      }) : /*#__PURE__*/(0, _jsxRuntime.jsx)("ul", {
        role: "tree",
        "aria-label": "Working tree",
        className: "tree",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(TreeNode, {
          path: worktree.path,
          name: worktree.id ?? "Files",
          isDir: true,
          depth: 0,
          rootPath: worktree.path,
          collapseEpoch: collapseEpoch,
          defaultOpen: true,
          onOpenFile: onOpenFile
        }, worktree.path)
      })
    })]
  });
}
_s2(FileExplorer, "AfTlQVyKzDpfTCbIm6hfD2uSHnw=", false, function () {
  return [_sdk.useMounts];
});
_c2 = FileExplorer;
var _default = exports.default = FileExplorer;
var _c, _c2;
$RefreshReg$(_c, "TreeNode");
$RefreshReg$(_c2, "FileExplorer");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NkayIsIl9sdWNpZGVSZWFjdCIsIl9tb3VudEZzIiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsIl9zMiIsImpvaW5QYXRoIiwiZGlyIiwibmFtZSIsInJlcGxhY2UiLCJSRUFEX01BWF9BVFRFTVBUUyIsIlJFQURfUkVUUllfTVMiLCJUcmVlTm9kZSIsInBhdGgiLCJpc0RpciIsImRlcHRoIiwicm9vdFBhdGgiLCJjb2xsYXBzZUVwb2NoIiwiZGVmYXVsdE9wZW4iLCJvbk9wZW5GaWxlIiwib3BlbiIsInNldE9wZW4iLCJ1c2VTdGF0ZSIsImVudHJpZXMiLCJzZXRFbnRyaWVzIiwiZXJyb3JlZCIsInNldEVycm9yZWQiLCJhdHRlbXB0Iiwic2V0QXR0ZW1wdCIsImxvYWRpbmciLCJ1c2VFZmZlY3QiLCJsaXZlIiwidGltZXIiLCJyZWFkZGlyIiwidGhlbiIsImxpc3QiLCJjYXRjaCIsInNldFRpbWVvdXQiLCJhIiwiY2xlYXJUaW1lb3V0Iiwib3BlbkZpbGUiLCJzbGljZSIsImxlbmd0aCIsImFjdGl2YXRlIiwidiIsIm9uS2V5RG93biIsImUiLCJrZXkiLCJwcmV2ZW50RGVmYXVsdCIsIkljb24iLCJGb2xkZXJPcGVuIiwiRm9sZGVyIiwiRmlsZUljb24iLCJqc3hzIiwicm9sZSIsInVuZGVmaW5lZCIsImNoaWxkcmVuIiwiY2xhc3NOYW1lIiwic3R5bGUiLCJwYWRkaW5nTGVmdCIsInRhYkluZGV4Iiwib25DbGljayIsImpzeCIsInNpemUiLCJMb2FkZXIyIiwibWFwIiwiX2MiLCJGaWxlRXhwbG9yZXIiLCJtb3VudHMiLCJ1c2VNb3VudHMiLCJzZXRDb2xsYXBzZUVwb2NoIiwib3BlbkVycm9yIiwic2V0T3BlbkVycm9yIiwid29ya3RyZWUiLCJmaW5kIiwibSIsInR5cGUiLCJyZXBvUmVsYXRpdmVQYXRoIiwib3BlbkluRWRpdG9yIiwiY29kZSIsIkZvbGRlclRyZWUiLCJ0aXRsZSIsIkNoZXZyb25zRG93blVwIiwiaWQiLCJfYzIiLCJfZGVmYXVsdCIsImV4cG9ydHMiLCJkZWZhdWx0IiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiRmlsZUV4cGxvcmVyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBUaGUgZmlsZSBleHBsb3JlciAoVUlfQVNfQVBQU19TUEVDIMKnNCAvIMKnMy41OyBtaWdyYXRlLXNpZGViYXJzIFBoYXNlIDAzKS4gQVxuLy8gdHJlZSB2aWV3IG9mIHRoZSBFRElUT1IgU0VTU0lPTidzIHdvcmtpbmcgdHJlZSDigJQgdGhlIHJlcG8geW91J3JlIGVkaXRpbmcg4oCUXG4vLyBzdXJmYWNlZCB0byB0aGlzIGFwcCBhcyBhIHNjb3BlZCBgL21udC97aGFzaH1gIG1vdW50IChgdHlwZTogJ3dvcmt0cmVlJ2AsIMKnMy41KS5cbi8vIENsaWNraW5nIGEgZmlsZSBhc2tzIHRoZSBob3N0IHRvIG9wZW4gaXQgaW4gdGhlIGVkaXRvciAoYG9wZW5JbkVkaXRvcmAsIHRoZSDCpzRcbi8vIGBlZGl0b3I6b3BlbmAgaW50ZW50IOKAlCB0aGUgZWRpdG9yIHN0YXlzIGhvc3Qtb3duZWQsIMKnMikuXG4vL1xuLy8gUmVhZC1vbmx5IGZvciBub3c6IG5vIGNyZWF0ZSAvIHJlbmFtZSAvIGRlbGV0ZSAvIHVwbG9hZCAod29ya2luZy10cmVlIG11dGF0aW9uXG4vLyBpcyBhIHNlcGFyYXRlIGtlcm5lbC1nYXRlZCBob3N0IGFjdGlvbiwgbWlncmF0ZS1zaWRlYmFycyBQaGFzZSAwNCkuIFdpdGggbm9cbi8vIGVkaXRvciBzZXNzaW9uIChlLmcuIHNpZ25lZC1vdXQsIG9yIG5vIHdvcmtpbmcgdHJlZSksIGl0IHNob3dzIGFuIGVtcHR5IHN0YXRlLlxuLy9cbi8vIEtub3duIHYxIGdhcDogYSBzeXN0ZW0gYXBwIGtlZXBzIGl0cyBPV04gcm91dGUgKGRyaXZlc0hvc3RSb3V0ZT1mYWxzZSksIHNvIGl0XG4vLyBjYW4ndCByZWFkIHRoZSBob3N0IGVkaXRvcidzIEFDVElWRSBmaWxlIGZyb20gcm91dGluZyDigJQgdGhlcmUgaXMgbm9cbi8vIGFjdGl2ZS1maWxlIGhpZ2hsaWdodCAvIGF1dG8tcmV2ZWFsIHlldC4gU3VyZmFjaW5nIHRoZSBhY3RpdmUgZmlsZSB0byBhIHBhbmVsIGlzXG4vLyBhIHNtYWxsIGFkZGl0aXZlIGVkaXRvci1jb250ZXh0IGNoYW5uZWwgKGEgbGF0ZXIgcGhhc2UpLlxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgdXNlTW91bnRzLCBvcGVuSW5FZGl0b3IsIHR5cGUgU2FuZGJveE1vdW50IH0gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrXCI7XG5pbXBvcnQge1xuICBGb2xkZXJUcmVlLFxuICBGb2xkZXIsXG4gIEZvbGRlck9wZW4sXG4gIEZpbGUgYXMgRmlsZUljb24sXG4gIExvYWRlcjIsXG4gIENoZXZyb25zRG93blVwLFxufSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQgeyByZWFkZGlyLCB0eXBlIERpckVudHJ5IH0gZnJvbSBcIi4uL2ZzL21vdW50RnNcIjtcblxuY29uc3Qgam9pblBhdGggPSAoZGlyOiBzdHJpbmcsIG5hbWU6IHN0cmluZyk6IHN0cmluZyA9PlxuICBgJHtkaXIucmVwbGFjZSgvXFwvKyQvLCBcIlwiKX0vJHtuYW1lfWA7XG5cbi8vIFRoZSB3b3JraW5nLXRyZWUgZnMgY2FuIGxhZyBpdHMgbW91bnQgZGVzY3JpcHRvciBhdCBib290OiBgdXNlTW91bnRzKClgIHN1cmZhY2VzXG4vLyB0aGUgd29ya3RyZWUgYXMgc29vbiBhcyB0aGUgaG9zdCBhbm5vdW5jZXMgaXQsIGJ1dCB0aGUgc2FuZGJveC1sb2NhbCBaZW5GUyBtb3VudFxuLy8gaXQgcG9pbnRzIGF0IG1heSBub3QgYmUgYXR0YWNoZWQgdGhlIGluc3RhbnQgdGhlIHJvb3QgZm9sZGVyIGZpcnN0IHJlYWRzLiBBXG4vLyBzaW5nbGUgZmFpbHVyZSB1c2VkIHRvIGxhdGNoIGEgcGVybWFuZW50IFwiQ291bGRuJ3QgcmVhZCB0aGlzIGZvbGRlclwiOyBpbnN0ZWFkIHdlXG4vLyByZXRyeSBhIGJvdW5kZWQgbnVtYmVyIG9mIHRpbWVzIGJlZm9yZSBnaXZpbmcgdXAsIHNvIHRoZSBjb21tb24gYm9vdCByYWNlIGhlYWxzXG4vLyBpdHNlbGYuIH5SRUFEX01BWF9BVFRFTVBUUyDDlyBSRUFEX1JFVFJZX01TIOKJiCBhIGZldyBzZWNvbmRzIG9mIHBhdGllbmNlLlxuY29uc3QgUkVBRF9NQVhfQVRURU1QVFMgPSAxMjtcbmNvbnN0IFJFQURfUkVUUllfTVMgPSAyNTA7XG5cbi8qKiBBIGxhemlseS1sb2FkZWQgdHJlZSBub2RlIGZvbGxvd2luZyB0aGUgQVJJQSB0cmVlIHBhdHRlcm4uIEZpbGUgcm93cyBhcmVcbiAqICBidXR0b25zIHRoYXQgb3BlbiB0aGUgZmlsZSBpbiB0aGUgaG9zdCBlZGl0b3I7IGRpcmVjdG9yeSByb3dzIGV4cGFuZC9jb2xsYXBzZS4gKi9cbmZ1bmN0aW9uIFRyZWVOb2RlKHtcbiAgcGF0aCxcbiAgbmFtZSxcbiAgaXNEaXIsXG4gIGRlcHRoLFxuICByb290UGF0aCxcbiAgY29sbGFwc2VFcG9jaCxcbiAgZGVmYXVsdE9wZW4gPSBmYWxzZSxcbiAgb25PcGVuRmlsZSxcbn06IHtcbiAgcGF0aDogc3RyaW5nO1xuICBuYW1lOiBzdHJpbmc7XG4gIGlzRGlyOiBib29sZWFuO1xuICBkZXB0aDogbnVtYmVyO1xuICAvKiogVGhlIG1vdW50IHJvb3QsIHNvIGEgZmlsZSdzIHJlcG8tcmVsYXRpdmUgcGF0aCBjYW4gYmUgZGVyaXZlZCBmb3Igb3BlbmluZy4gKi9cbiAgcm9vdFBhdGg6IHN0cmluZztcbiAgLyoqIEJ1bXBpbmcgdGhpcyBjb2xsYXBzZXMgZXZlcnkgbm9kZSAodGhlIGhlYWRlcidzIFwiY29sbGFwc2UgYWxsXCIpLiAqL1xuICBjb2xsYXBzZUVwb2NoOiBudW1iZXI7XG4gIGRlZmF1bHRPcGVuPzogYm9vbGVhbjtcbiAgb25PcGVuRmlsZTogKHJlcG9SZWxhdGl2ZVBhdGg6IHN0cmluZykgPT4gdm9pZDtcbn0pIHtcbiAgY29uc3QgW29wZW4sIHNldE9wZW5dID0gdXNlU3RhdGUoZGVmYXVsdE9wZW4pO1xuICBjb25zdCBbZW50cmllcywgc2V0RW50cmllc10gPSB1c2VTdGF0ZTxEaXJFbnRyeVtdIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtlcnJvcmVkLCBzZXRFcnJvcmVkXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgLy8gQnVtcGVkIHRvIHJlLXRyaWdnZXIgdGhlIHJlYWQgZWZmZWN0IHdoZW4gYSByZWFkIGZhaWxzIHRyYW5zaWVudGx5ICh0aGVcbiAgLy8gYm9vdC10aW1lIGZzIHJhY2UpLiBDb3VudHMgdG93YXJkIFJFQURfTUFYX0FUVEVNUFRTIGJlZm9yZSB3ZSBnaXZlIHVwLlxuICBjb25zdCBbYXR0ZW1wdCwgc2V0QXR0ZW1wdF0gPSB1c2VTdGF0ZSgwKTtcbiAgLy8gTG9hZGluZyBpcyBERVJJVkVEIChub3QgZWZmZWN0LXNldCBzdGF0ZSk6IGEgZGlyIHRoYXQncyBvcGVuIHdpdGggbm90aGluZ1xuICAvLyBsb2FkZWQgeWV0IGFuZCBubyBlcnJvciBpcyBsb2FkaW5nIChpbmNsdWRpbmcgd2hpbGUgd2UgcmV0cnkpLlxuICBjb25zdCBsb2FkaW5nID0gaXNEaXIgJiYgb3BlbiAmJiBlbnRyaWVzID09PSBudWxsICYmICFlcnJvcmVkO1xuXG4gIC8vIEEgXCJjb2xsYXBzZSBhbGxcIiBjbG9zZXMgZXZlcnkgbm9kZTsgcmUtb3BlbmluZyBhIGZvbGRlciByZS1yZWFkcyBpdC5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIWRlZmF1bHRPcGVuKSBzZXRPcGVuKGZhbHNlKTtcbiAgfSwgW2NvbGxhcHNlRXBvY2gsIGRlZmF1bHRPcGVuXSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIWlzRGlyIHx8ICFvcGVuIHx8IGVudHJpZXMgIT09IG51bGwgfHwgZXJyb3JlZCkgcmV0dXJuO1xuICAgIGxldCBsaXZlID0gdHJ1ZTtcbiAgICBsZXQgdGltZXI6IFJldHVyblR5cGU8dHlwZW9mIHNldFRpbWVvdXQ+IHwgdW5kZWZpbmVkO1xuICAgIHJlYWRkaXIocGF0aClcbiAgICAgIC50aGVuKChsaXN0KSA9PiBsaXZlICYmIHNldEVudHJpZXMobGlzdCkpXG4gICAgICAuY2F0Y2goKCkgPT4ge1xuICAgICAgICBpZiAoIWxpdmUpIHJldHVybjtcbiAgICAgICAgLy8gVHJhbnNpZW50IGF0IGJvb3QgKGZzIG5vdCB5ZXQgYXR0YWNoZWQgYXQgdGhlIG1vdW50IHBhdGgpIOKAlCByZXRyeSBhXG4gICAgICAgIC8vIGJvdW5kZWQgbnVtYmVyIG9mIHRpbWVzIGJlZm9yZSBzdXJmYWNpbmcgdGhlIGVycm9yLCBzbyBhIHRvby1lYXJseVxuICAgICAgICAvLyBmaXJzdCByZWFkIGRvZXNuJ3Qgc3RyYW5kIHRoZSBmb2xkZXIgcGVybWFuZW50bHkuXG4gICAgICAgIGlmIChhdHRlbXB0IDwgUkVBRF9NQVhfQVRURU1QVFMpIHtcbiAgICAgICAgICB0aW1lciA9IHNldFRpbWVvdXQoKCkgPT4gbGl2ZSAmJiBzZXRBdHRlbXB0KChhKSA9PiBhICsgMSksIFJFQURfUkVUUllfTVMpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHNldEVycm9yZWQodHJ1ZSk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBsaXZlID0gZmFsc2U7XG4gICAgICBpZiAodGltZXIpIGNsZWFyVGltZW91dCh0aW1lcik7XG4gICAgfTtcbiAgfSwgW2lzRGlyLCBvcGVuLCBlbnRyaWVzLCBlcnJvcmVkLCBwYXRoLCBhdHRlbXB0XSk7XG5cbiAgY29uc3Qgb3BlbkZpbGUgPSAoKSA9PiB7XG4gICAgLy8gUmVwby1yZWxhdGl2ZSBwYXRoID0gdGhlIG1vdW50LXJvb3RlZCBwYXRoIG1pbnVzIHRoZSBgL21udC97aGFzaH1gIHByZWZpeFxuICAgIC8vIChvcGVuSW5FZGl0b3IgYWNjZXB0cyBhIGxlYWRpbmcgc2xhc2gpLiBOT1QgdGhlIHNhbmRib3ggYC9tbnQvLi4uYCBwYXRoLlxuICAgIG9uT3BlbkZpbGUocGF0aC5zbGljZShyb290UGF0aC5sZW5ndGgpIHx8IFwiL1wiICsgbmFtZSk7XG4gIH07XG4gIGNvbnN0IGFjdGl2YXRlID0gKCkgPT4gKGlzRGlyID8gc2V0T3BlbigodikgPT4gIXYpIDogb3BlbkZpbGUoKSk7XG4gIGNvbnN0IG9uS2V5RG93biA9IChlOiBSZWFjdC5LZXlib2FyZEV2ZW50KSA9PiB7XG4gICAgaWYgKGUua2V5ID09PSBcIkVudGVyXCIgfHwgZS5rZXkgPT09IFwiIFwiKSB7XG4gICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICBhY3RpdmF0ZSgpO1xuICAgIH0gZWxzZSBpZiAoaXNEaXIgJiYgZS5rZXkgPT09IFwiQXJyb3dSaWdodFwiICYmICFvcGVuKSB7XG4gICAgICBzZXRPcGVuKHRydWUpO1xuICAgIH0gZWxzZSBpZiAoaXNEaXIgJiYgZS5rZXkgPT09IFwiQXJyb3dMZWZ0XCIgJiYgb3Blbikge1xuICAgICAgc2V0T3BlbihmYWxzZSk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IEljb24gPSBpc0RpciA/IChvcGVuID8gRm9sZGVyT3BlbiA6IEZvbGRlcikgOiBGaWxlSWNvbjtcblxuICByZXR1cm4gKFxuICAgIDxsaSByb2xlPVwidHJlZWl0ZW1cIiBhcmlhLWV4cGFuZGVkPXtpc0RpciA/IG9wZW4gOiB1bmRlZmluZWR9IGFyaWEtbGFiZWw9e25hbWV9PlxuICAgICAgPGRpdlxuICAgICAgICBjbGFzc05hbWU9XCJ0bm9kZVwiXG4gICAgICAgIHN0eWxlPXt7IHBhZGRpbmdMZWZ0OiA4ICsgZGVwdGggKiAxNCB9fVxuICAgICAgICB0YWJJbmRleD17MH1cbiAgICAgICAgb25DbGljaz17YWN0aXZhdGV9XG4gICAgICAgIG9uS2V5RG93bj17b25LZXlEb3dufVxuICAgICAgICBkYXRhLWRpcj17aXNEaXIgPyBcIjFcIiA6IFwiMFwifVxuICAgICAgPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0bm9kZV9faWNvblwiPlxuICAgICAgICAgIDxJY29uIHNpemU9ezE1fSBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICA8L3NwYW4+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRub2RlX19uYW1lXCI+e25hbWV9PC9zcGFuPlxuICAgICAgICB7bG9hZGluZyAmJiAoXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidG5vZGVfX3NwaW5cIiBhcmlhLWhpZGRlbj1cInRydWVcIj5cbiAgICAgICAgICAgIDxMb2FkZXIyIHNpemU9ezEzfSAvPlxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7aXNEaXIgJiYgb3BlbiAmJiAoXG4gICAgICAgIDx1bCByb2xlPVwiZ3JvdXBcIj5cbiAgICAgICAgICB7ZXJyb3JlZCAmJiAoXG4gICAgICAgICAgICA8bGkgY2xhc3NOYW1lPVwidG5vZGUgdG5vZGUtLW11dGVkXCIgc3R5bGU9e3sgcGFkZGluZ0xlZnQ6IDggKyAoZGVwdGggKyAxKSAqIDE0IH19PlxuICAgICAgICAgICAgICBDb3VsZG7igJl0IHJlYWQgdGhpcyBmb2xkZXIuXG4gICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICl9XG4gICAgICAgICAge2VudHJpZXM/Lmxlbmd0aCA9PT0gMCAmJiAoXG4gICAgICAgICAgICA8bGkgY2xhc3NOYW1lPVwidG5vZGUgdG5vZGUtLW11dGVkXCIgc3R5bGU9e3sgcGFkZGluZ0xlZnQ6IDggKyAoZGVwdGggKyAxKSAqIDE0IH19PlxuICAgICAgICAgICAgICBFbXB0eVxuICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICApfVxuICAgICAgICAgIHtlbnRyaWVzPy5tYXAoKGUpID0+IChcbiAgICAgICAgICAgIDxUcmVlTm9kZVxuICAgICAgICAgICAgICBrZXk9e2UubmFtZX1cbiAgICAgICAgICAgICAgcGF0aD17am9pblBhdGgocGF0aCwgZS5uYW1lKX1cbiAgICAgICAgICAgICAgbmFtZT17ZS5uYW1lfVxuICAgICAgICAgICAgICBpc0Rpcj17ZS5pc0Rpcn1cbiAgICAgICAgICAgICAgZGVwdGg9e2RlcHRoICsgMX1cbiAgICAgICAgICAgICAgcm9vdFBhdGg9e3Jvb3RQYXRofVxuICAgICAgICAgICAgICBjb2xsYXBzZUVwb2NoPXtjb2xsYXBzZUVwb2NofVxuICAgICAgICAgICAgICBvbk9wZW5GaWxlPXtvbk9wZW5GaWxlfVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC91bD5cbiAgICAgICl9XG4gICAgPC9saT5cbiAgKTtcbn1cblxuZnVuY3Rpb24gRmlsZUV4cGxvcmVyKCkge1xuICBjb25zdCBtb3VudHMgPSB1c2VNb3VudHMoKTtcbiAgY29uc3QgW2NvbGxhcHNlRXBvY2gsIHNldENvbGxhcHNlRXBvY2hdID0gdXNlU3RhdGUoMCk7XG4gIGNvbnN0IFtvcGVuRXJyb3IsIHNldE9wZW5FcnJvcl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcblxuICAvLyBUaGUgd29ya2luZyB0cmVlICh0aGUgcmVwbyBiZWluZyBlZGl0ZWQpIGlzIHB1Ymxpc2hlZCB0byB0aGlzIHBhbmVsIGFzIGFcbiAgLy8gYHR5cGU6ICd3b3JrdHJlZSdgIG1vdW50ICjCpzMuNSkuIFByZWZlciBpdDsgdGhlcmUgaXMgYXQgbW9zdCBvbmUuXG4gIGNvbnN0IHdvcmt0cmVlOiBTYW5kYm94TW91bnQgfCB1bmRlZmluZWQgPSBtb3VudHMuZmluZCgobSkgPT4gbS50eXBlID09PSBcIndvcmt0cmVlXCIpO1xuXG4gIGNvbnN0IG9uT3BlbkZpbGUgPSAocmVwb1JlbGF0aXZlUGF0aDogc3RyaW5nKSA9PiB7XG4gICAgc2V0T3BlbkVycm9yKG51bGwpO1xuICAgIHZvaWQgb3BlbkluRWRpdG9yKHJlcG9SZWxhdGl2ZVBhdGgpLmNhdGNoKChlKSA9PiB7XG4gICAgICBjb25zdCBjb2RlID0gKGUgYXMgeyBjb2RlPzogc3RyaW5nIH0pPy5jb2RlO1xuICAgICAgLy8gYGZvcmJpZGRlbmAgc2hvdWxkbid0IGhhcHBlbiBmb3IgdGhlIGNvcnJlY3RseS1ib3VuZCBwYW5lbDsgYG5vdC1mb3VuZGBcbiAgICAgIC8vIGlzIGEgYmVuaWduIHJhY2UgKGZpbGUgZGVsZXRlZCB1bmRlciB1cykuIFN1cmZhY2Ugb25seSB0aGUgdW5leHBlY3RlZC5cbiAgICAgIGlmIChjb2RlICYmIGNvZGUgIT09IFwibm90LWZvdW5kXCIpIHNldE9wZW5FcnJvcihcIkNvdWxkbuKAmXQgb3BlbiB0aGF0IGZpbGUuXCIpO1xuICAgIH0pO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwicGFuZWxcIiBhcmlhLWxhYmVsPVwiRmlsZXNcIj5cbiAgICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwicGFuZWxfX2hlYWRcIj5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicGFuZWxfX2dseXBoXCI+XG4gICAgICAgICAgPEZvbGRlclRyZWUgc2l6ZT17MTV9IGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgIDwvc3Bhbj5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicGFuZWxfX3RpdGxlXCI+RmlsZXM8L3NwYW4+XG4gICAgICAgIHt3b3JrdHJlZSAmJiAoXG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJwYW5lbF9fYWN0aW9uXCJcbiAgICAgICAgICAgIHRpdGxlPVwiQ29sbGFwc2UgYWxsIGZvbGRlcnNcIlxuICAgICAgICAgICAgYXJpYS1sYWJlbD1cIkNvbGxhcHNlIGFsbCBmb2xkZXJzXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldENvbGxhcHNlRXBvY2goKGUpID0+IGUgKyAxKX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICA8Q2hldnJvbnNEb3duVXAgc2l6ZT17MTV9IGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICl9XG4gICAgICA8L2hlYWRlcj5cblxuICAgICAge29wZW5FcnJvciAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGFuZWxfX2Vycm9yXCIgcm9sZT1cImFsZXJ0XCIgb25DbGljaz17KCkgPT4gc2V0T3BlbkVycm9yKG51bGwpfT5cbiAgICAgICAgICB7b3BlbkVycm9yfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGFuZWxfX2JvZHlcIj5cbiAgICAgICAgeyF3b3JrdHJlZSA/IChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN0YXRlXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzdGF0ZV9faWNvblwiPlxuICAgICAgICAgICAgICA8Rm9sZGVyVHJlZSBzaXplPXsyMH0gYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDxoND5ObyBmaWxlcyB0byBzaG93IHlldC48L2g0PlxuICAgICAgICAgICAgPHA+T3BlbiBhIHByb2plY3QgaW4gdGhlIGVkaXRvciBhbmQgaXRzIGZpbGVzIGFwcGVhciBoZXJlLjwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKSA6IChcbiAgICAgICAgICA8dWwgcm9sZT1cInRyZWVcIiBhcmlhLWxhYmVsPVwiV29ya2luZyB0cmVlXCIgY2xhc3NOYW1lPVwidHJlZVwiPlxuICAgICAgICAgICAgPFRyZWVOb2RlXG4gICAgICAgICAgICAgIGtleT17d29ya3RyZWUucGF0aH1cbiAgICAgICAgICAgICAgcGF0aD17d29ya3RyZWUucGF0aH1cbiAgICAgICAgICAgICAgbmFtZT17d29ya3RyZWUuaWQgPz8gXCJGaWxlc1wifVxuICAgICAgICAgICAgICBpc0RpclxuICAgICAgICAgICAgICBkZXB0aD17MH1cbiAgICAgICAgICAgICAgcm9vdFBhdGg9e3dvcmt0cmVlLnBhdGh9XG4gICAgICAgICAgICAgIGNvbGxhcHNlRXBvY2g9e2NvbGxhcHNlRXBvY2h9XG4gICAgICAgICAgICAgIGRlZmF1bHRPcGVuXG4gICAgICAgICAgICAgIG9uT3BlbkZpbGU9e29uT3BlbkZpbGV9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvdWw+XG4gICAgICAgICl9XG4gICAgICA8L2Rpdj5cbiAgICA8L3NlY3Rpb24+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IEZpbGVFeHBsb3JlcjtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBY0EsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsSUFBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsWUFBQSxHQUFBRixPQUFBO0FBUUEsSUFBQUcsUUFBQSxHQUFBSCxPQUFBO0FBQXVELElBQUFJLFdBQUEsR0FBQUosT0FBQTtBQUFBLElBQUFLLEVBQUEsR0FBQUMsWUFBQTtFQUFBQyxHQUFBLEdBQUFELFlBQUEsSUF4QnZEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFhQSxNQUFNRSxRQUFRLEdBQUdBLENBQUNDLEdBQVcsRUFBRUMsSUFBWSxLQUN6QyxHQUFHRCxHQUFHLENBQUNFLE9BQU8sQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLElBQUlELElBQUksRUFBRTs7QUFFdEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTUUsaUJBQWlCLEdBQUcsRUFBRTtBQUM1QixNQUFNQyxhQUFhLEdBQUcsR0FBRzs7QUFFekI7QUFDQTtBQUNBLFNBQVNDLFFBQVFBLENBQUM7RUFDaEJDLElBQUk7RUFDSkwsSUFBSTtFQUNKTSxLQUFLO0VBQ0xDLEtBQUs7RUFDTEMsUUFBUTtFQUNSQyxhQUFhO0VBQ2JDLFdBQVcsR0FBRyxLQUFLO0VBQ25CQztBQVlGLENBQUMsRUFBRTtFQUFBaEIsRUFBQTtFQUNELE1BQU0sQ0FBQ2lCLElBQUksRUFBRUMsT0FBTyxDQUFDLEdBQUcsSUFBQUMsZUFBUSxFQUFDSixXQUFXLENBQUM7RUFDN0MsTUFBTSxDQUFDSyxPQUFPLEVBQUVDLFVBQVUsQ0FBQyxHQUFHLElBQUFGLGVBQVEsRUFBb0IsSUFBSSxDQUFDO0VBQy9ELE1BQU0sQ0FBQ0csT0FBTyxFQUFFQyxVQUFVLENBQUMsR0FBRyxJQUFBSixlQUFRLEVBQUMsS0FBSyxDQUFDO0VBQzdDO0VBQ0E7RUFDQSxNQUFNLENBQUNLLE9BQU8sRUFBRUMsVUFBVSxDQUFDLEdBQUcsSUFBQU4sZUFBUSxFQUFDLENBQUMsQ0FBQztFQUN6QztFQUNBO0VBQ0EsTUFBTU8sT0FBTyxHQUFHZixLQUFLLElBQUlNLElBQUksSUFBSUcsT0FBTyxLQUFLLElBQUksSUFBSSxDQUFDRSxPQUFPOztFQUU3RDtFQUNBLElBQUFLLGdCQUFTLEVBQUMsTUFBTTtJQUNkLElBQUksQ0FBQ1osV0FBVyxFQUFFRyxPQUFPLENBQUMsS0FBSyxDQUFDO0VBQ2xDLENBQUMsRUFBRSxDQUFDSixhQUFhLEVBQUVDLFdBQVcsQ0FBQyxDQUFDO0VBRWhDLElBQUFZLGdCQUFTLEVBQUMsTUFBTTtJQUNkLElBQUksQ0FBQ2hCLEtBQUssSUFBSSxDQUFDTSxJQUFJLElBQUlHLE9BQU8sS0FBSyxJQUFJLElBQUlFLE9BQU8sRUFBRTtJQUNwRCxJQUFJTSxJQUFJLEdBQUcsSUFBSTtJQUNmLElBQUlDLEtBQWdEO0lBQ3BELElBQUFDLGdCQUFPLEVBQUNwQixJQUFJLENBQUMsQ0FDVnFCLElBQUksQ0FBRUMsSUFBSSxJQUFLSixJQUFJLElBQUlQLFVBQVUsQ0FBQ1csSUFBSSxDQUFDLENBQUMsQ0FDeENDLEtBQUssQ0FBQyxNQUFNO01BQ1gsSUFBSSxDQUFDTCxJQUFJLEVBQUU7TUFDWDtNQUNBO01BQ0E7TUFDQSxJQUFJSixPQUFPLEdBQUdqQixpQkFBaUIsRUFBRTtRQUMvQnNCLEtBQUssR0FBR0ssVUFBVSxDQUFDLE1BQU1OLElBQUksSUFBSUgsVUFBVSxDQUFFVSxDQUFDLElBQUtBLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRTNCLGFBQWEsQ0FBQztNQUMzRSxDQUFDLE1BQU07UUFDTGUsVUFBVSxDQUFDLElBQUksQ0FBQztNQUNsQjtJQUNGLENBQUMsQ0FBQztJQUNKLE9BQU8sTUFBTTtNQUNYSyxJQUFJLEdBQUcsS0FBSztNQUNaLElBQUlDLEtBQUssRUFBRU8sWUFBWSxDQUFDUCxLQUFLLENBQUM7SUFDaEMsQ0FBQztFQUNILENBQUMsRUFBRSxDQUFDbEIsS0FBSyxFQUFFTSxJQUFJLEVBQUVHLE9BQU8sRUFBRUUsT0FBTyxFQUFFWixJQUFJLEVBQUVjLE9BQU8sQ0FBQyxDQUFDO0VBRWxELE1BQU1hLFFBQVEsR0FBR0EsQ0FBQSxLQUFNO0lBQ3JCO0lBQ0E7SUFDQXJCLFVBQVUsQ0FBQ04sSUFBSSxDQUFDNEIsS0FBSyxDQUFDekIsUUFBUSxDQUFDMEIsTUFBTSxDQUFDLElBQUksR0FBRyxHQUFHbEMsSUFBSSxDQUFDO0VBQ3ZELENBQUM7RUFDRCxNQUFNbUMsUUFBUSxHQUFHQSxDQUFBLEtBQU83QixLQUFLLEdBQUdPLE9BQU8sQ0FBRXVCLENBQUMsSUFBSyxDQUFDQSxDQUFDLENBQUMsR0FBR0osUUFBUSxDQUFDLENBQUU7RUFDaEUsTUFBTUssU0FBUyxHQUFJQyxDQUFzQixJQUFLO0lBQzVDLElBQUlBLENBQUMsQ0FBQ0MsR0FBRyxLQUFLLE9BQU8sSUFBSUQsQ0FBQyxDQUFDQyxHQUFHLEtBQUssR0FBRyxFQUFFO01BQ3RDRCxDQUFDLENBQUNFLGNBQWMsQ0FBQyxDQUFDO01BQ2xCTCxRQUFRLENBQUMsQ0FBQztJQUNaLENBQUMsTUFBTSxJQUFJN0IsS0FBSyxJQUFJZ0MsQ0FBQyxDQUFDQyxHQUFHLEtBQUssWUFBWSxJQUFJLENBQUMzQixJQUFJLEVBQUU7TUFDbkRDLE9BQU8sQ0FBQyxJQUFJLENBQUM7SUFDZixDQUFDLE1BQU0sSUFBSVAsS0FBSyxJQUFJZ0MsQ0FBQyxDQUFDQyxHQUFHLEtBQUssV0FBVyxJQUFJM0IsSUFBSSxFQUFFO01BQ2pEQyxPQUFPLENBQUMsS0FBSyxDQUFDO0lBQ2hCO0VBQ0YsQ0FBQztFQUVELE1BQU00QixJQUFJLEdBQUduQyxLQUFLLEdBQUlNLElBQUksR0FBRzhCLHVCQUFVLEdBQUdDLG1CQUFNLEdBQUlDLGlCQUFRO0VBRTVELG9CQUNFLElBQUFsRCxXQUFBLENBQUFtRCxJQUFBO0lBQUlDLElBQUksRUFBQyxVQUFVO0lBQUMsaUJBQWV4QyxLQUFLLEdBQUdNLElBQUksR0FBR21DLFNBQVU7SUFBQyxjQUFZL0MsSUFBSztJQUFBZ0QsUUFBQSxnQkFDNUUsSUFBQXRELFdBQUEsQ0FBQW1ELElBQUE7TUFDRUksU0FBUyxFQUFDLE9BQU87TUFDakJDLEtBQUssRUFBRTtRQUFFQyxXQUFXLEVBQUUsQ0FBQyxHQUFHNUMsS0FBSyxHQUFHO01BQUcsQ0FBRTtNQUN2QzZDLFFBQVEsRUFBRSxDQUFFO01BQ1pDLE9BQU8sRUFBRWxCLFFBQVM7TUFDbEJFLFNBQVMsRUFBRUEsU0FBVTtNQUNyQixZQUFVL0IsS0FBSyxHQUFHLEdBQUcsR0FBRyxHQUFJO01BQUEwQyxRQUFBLGdCQUU1QixJQUFBdEQsV0FBQSxDQUFBNEQsR0FBQTtRQUFNTCxTQUFTLEVBQUMsYUFBYTtRQUFBRCxRQUFBLGVBQzNCLElBQUF0RCxXQUFBLENBQUE0RCxHQUFBLEVBQUNiLElBQUk7VUFBQ2MsSUFBSSxFQUFFLEVBQUc7VUFBQyxlQUFZO1FBQU0sQ0FBRTtNQUFDLENBQ2pDLENBQUMsZUFDUCxJQUFBN0QsV0FBQSxDQUFBNEQsR0FBQTtRQUFNTCxTQUFTLEVBQUMsYUFBYTtRQUFBRCxRQUFBLEVBQUVoRDtNQUFJLENBQU8sQ0FBQyxFQUMxQ3FCLE9BQU8saUJBQ04sSUFBQTNCLFdBQUEsQ0FBQTRELEdBQUE7UUFBTUwsU0FBUyxFQUFDLGFBQWE7UUFBQyxlQUFZLE1BQU07UUFBQUQsUUFBQSxlQUM5QyxJQUFBdEQsV0FBQSxDQUFBNEQsR0FBQSxFQUFDOUQsWUFBQSxDQUFBZ0UsT0FBTztVQUFDRCxJQUFJLEVBQUU7UUFBRyxDQUFFO01BQUMsQ0FDakIsQ0FDUDtJQUFBLENBQ0UsQ0FBQyxFQUVMakQsS0FBSyxJQUFJTSxJQUFJLGlCQUNaLElBQUFsQixXQUFBLENBQUFtRCxJQUFBO01BQUlDLElBQUksRUFBQyxPQUFPO01BQUFFLFFBQUEsR0FDYi9CLE9BQU8saUJBQ04sSUFBQXZCLFdBQUEsQ0FBQTRELEdBQUE7UUFBSUwsU0FBUyxFQUFDLG9CQUFvQjtRQUFDQyxLQUFLLEVBQUU7VUFBRUMsV0FBVyxFQUFFLENBQUMsR0FBRyxDQUFDNUMsS0FBSyxHQUFHLENBQUMsSUFBSTtRQUFHLENBQUU7UUFBQXlDLFFBQUEsRUFBQztNQUVqRixDQUFJLENBQ0wsRUFDQWpDLE9BQU8sRUFBRW1CLE1BQU0sS0FBSyxDQUFDLGlCQUNwQixJQUFBeEMsV0FBQSxDQUFBNEQsR0FBQTtRQUFJTCxTQUFTLEVBQUMsb0JBQW9CO1FBQUNDLEtBQUssRUFBRTtVQUFFQyxXQUFXLEVBQUUsQ0FBQyxHQUFHLENBQUM1QyxLQUFLLEdBQUcsQ0FBQyxJQUFJO1FBQUcsQ0FBRTtRQUFBeUMsUUFBQSxFQUFDO01BRWpGLENBQUksQ0FDTCxFQUNBakMsT0FBTyxFQUFFMEMsR0FBRyxDQUFFbkIsQ0FBQyxpQkFDZCxJQUFBNUMsV0FBQSxDQUFBNEQsR0FBQSxFQUFDbEQsUUFBUTtRQUVQQyxJQUFJLEVBQUVQLFFBQVEsQ0FBQ08sSUFBSSxFQUFFaUMsQ0FBQyxDQUFDdEMsSUFBSSxDQUFFO1FBQzdCQSxJQUFJLEVBQUVzQyxDQUFDLENBQUN0QyxJQUFLO1FBQ2JNLEtBQUssRUFBRWdDLENBQUMsQ0FBQ2hDLEtBQU07UUFDZkMsS0FBSyxFQUFFQSxLQUFLLEdBQUcsQ0FBRTtRQUNqQkMsUUFBUSxFQUFFQSxRQUFTO1FBQ25CQyxhQUFhLEVBQUVBLGFBQWM7UUFDN0JFLFVBQVUsRUFBRUE7TUFBVyxHQVBsQjJCLENBQUMsQ0FBQ3RDLElBUVIsQ0FDRixDQUFDO0lBQUEsQ0FDQSxDQUNMO0VBQUEsQ0FDQyxDQUFDO0FBRVQ7QUFBQ0wsRUFBQSxDQS9IUVMsUUFBUTtBQUFBc0QsRUFBQSxHQUFSdEQsUUFBUTtBQWlJakIsU0FBU3VELFlBQVlBLENBQUEsRUFBRztFQUFBOUQsR0FBQTtFQUN0QixNQUFNK0QsTUFBTSxHQUFHLElBQUFDLGNBQVMsRUFBQyxDQUFDO0VBQzFCLE1BQU0sQ0FBQ3BELGFBQWEsRUFBRXFELGdCQUFnQixDQUFDLEdBQUcsSUFBQWhELGVBQVEsRUFBQyxDQUFDLENBQUM7RUFDckQsTUFBTSxDQUFDaUQsU0FBUyxFQUFFQyxZQUFZLENBQUMsR0FBRyxJQUFBbEQsZUFBUSxFQUFnQixJQUFJLENBQUM7O0VBRS9EO0VBQ0E7RUFDQSxNQUFNbUQsUUFBa0MsR0FBR0wsTUFBTSxDQUFDTSxJQUFJLENBQUVDLENBQUMsSUFBS0EsQ0FBQyxDQUFDQyxJQUFJLEtBQUssVUFBVSxDQUFDO0VBRXBGLE1BQU16RCxVQUFVLEdBQUkwRCxnQkFBd0IsSUFBSztJQUMvQ0wsWUFBWSxDQUFDLElBQUksQ0FBQztJQUNsQixLQUFLLElBQUFNLGlCQUFZLEVBQUNELGdCQUFnQixDQUFDLENBQUN6QyxLQUFLLENBQUVVLENBQUMsSUFBSztNQUMvQyxNQUFNaUMsSUFBSSxHQUFJakMsQ0FBQyxFQUF3QmlDLElBQUk7TUFDM0M7TUFDQTtNQUNBLElBQUlBLElBQUksSUFBSUEsSUFBSSxLQUFLLFdBQVcsRUFBRVAsWUFBWSxDQUFDLDBCQUEwQixDQUFDO0lBQzVFLENBQUMsQ0FBQztFQUNKLENBQUM7RUFFRCxvQkFDRSxJQUFBdEUsV0FBQSxDQUFBbUQsSUFBQTtJQUFTSSxTQUFTLEVBQUMsT0FBTztJQUFDLGNBQVcsT0FBTztJQUFBRCxRQUFBLGdCQUMzQyxJQUFBdEQsV0FBQSxDQUFBbUQsSUFBQTtNQUFRSSxTQUFTLEVBQUMsYUFBYTtNQUFBRCxRQUFBLGdCQUM3QixJQUFBdEQsV0FBQSxDQUFBNEQsR0FBQTtRQUFNTCxTQUFTLEVBQUMsY0FBYztRQUFBRCxRQUFBLGVBQzVCLElBQUF0RCxXQUFBLENBQUE0RCxHQUFBLEVBQUM5RCxZQUFBLENBQUFnRixVQUFVO1VBQUNqQixJQUFJLEVBQUUsRUFBRztVQUFDLGVBQVk7UUFBTSxDQUFFO01BQUMsQ0FDdkMsQ0FBQyxlQUNQLElBQUE3RCxXQUFBLENBQUE0RCxHQUFBO1FBQU1MLFNBQVMsRUFBQyxjQUFjO1FBQUFELFFBQUEsRUFBQztNQUFLLENBQU0sQ0FBQyxFQUMxQ2lCLFFBQVEsaUJBQ1AsSUFBQXZFLFdBQUEsQ0FBQTRELEdBQUE7UUFDRWMsSUFBSSxFQUFDLFFBQVE7UUFDYm5CLFNBQVMsRUFBQyxlQUFlO1FBQ3pCd0IsS0FBSyxFQUFDLHNCQUFzQjtRQUM1QixjQUFXLHNCQUFzQjtRQUNqQ3BCLE9BQU8sRUFBRUEsQ0FBQSxLQUFNUyxnQkFBZ0IsQ0FBRXhCLENBQUMsSUFBS0EsQ0FBQyxHQUFHLENBQUMsQ0FBRTtRQUFBVSxRQUFBLGVBRTlDLElBQUF0RCxXQUFBLENBQUE0RCxHQUFBLEVBQUM5RCxZQUFBLENBQUFrRixjQUFjO1VBQUNuQixJQUFJLEVBQUUsRUFBRztVQUFDLGVBQVk7UUFBTSxDQUFFO01BQUMsQ0FDekMsQ0FDVDtJQUFBLENBQ0ssQ0FBQyxFQUVSUSxTQUFTLGlCQUNSLElBQUFyRSxXQUFBLENBQUE0RCxHQUFBO01BQUtMLFNBQVMsRUFBQyxjQUFjO01BQUNILElBQUksRUFBQyxPQUFPO01BQUNPLE9BQU8sRUFBRUEsQ0FBQSxLQUFNVyxZQUFZLENBQUMsSUFBSSxDQUFFO01BQUFoQixRQUFBLEVBQzFFZTtJQUFTLENBQ1AsQ0FDTixlQUVELElBQUFyRSxXQUFBLENBQUE0RCxHQUFBO01BQUtMLFNBQVMsRUFBQyxhQUFhO01BQUFELFFBQUEsRUFDekIsQ0FBQ2lCLFFBQVEsZ0JBQ1IsSUFBQXZFLFdBQUEsQ0FBQW1ELElBQUE7UUFBS0ksU0FBUyxFQUFDLE9BQU87UUFBQUQsUUFBQSxnQkFDcEIsSUFBQXRELFdBQUEsQ0FBQTRELEdBQUE7VUFBTUwsU0FBUyxFQUFDLGFBQWE7VUFBQUQsUUFBQSxlQUMzQixJQUFBdEQsV0FBQSxDQUFBNEQsR0FBQSxFQUFDOUQsWUFBQSxDQUFBZ0YsVUFBVTtZQUFDakIsSUFBSSxFQUFFLEVBQUc7WUFBQyxlQUFZO1VBQU0sQ0FBRTtRQUFDLENBQ3ZDLENBQUMsZUFDUCxJQUFBN0QsV0FBQSxDQUFBNEQsR0FBQTtVQUFBTixRQUFBLEVBQUk7UUFBcUIsQ0FBSSxDQUFDLGVBQzlCLElBQUF0RCxXQUFBLENBQUE0RCxHQUFBO1VBQUFOLFFBQUEsRUFBRztRQUF1RCxDQUFHLENBQUM7TUFBQSxDQUMzRCxDQUFDLGdCQUVOLElBQUF0RCxXQUFBLENBQUE0RCxHQUFBO1FBQUlSLElBQUksRUFBQyxNQUFNO1FBQUMsY0FBVyxjQUFjO1FBQUNHLFNBQVMsRUFBQyxNQUFNO1FBQUFELFFBQUEsZUFDeEQsSUFBQXRELFdBQUEsQ0FBQTRELEdBQUEsRUFBQ2xELFFBQVE7VUFFUEMsSUFBSSxFQUFFNEQsUUFBUSxDQUFDNUQsSUFBSztVQUNwQkwsSUFBSSxFQUFFaUUsUUFBUSxDQUFDVSxFQUFFLElBQUksT0FBUTtVQUM3QnJFLEtBQUs7VUFDTEMsS0FBSyxFQUFFLENBQUU7VUFDVEMsUUFBUSxFQUFFeUQsUUFBUSxDQUFDNUQsSUFBSztVQUN4QkksYUFBYSxFQUFFQSxhQUFjO1VBQzdCQyxXQUFXO1VBQ1hDLFVBQVUsRUFBRUE7UUFBVyxHQVJsQnNELFFBQVEsQ0FBQzVELElBU2Y7TUFBQyxDQUNBO0lBQ0wsQ0FDRSxDQUFDO0VBQUEsQ0FDQyxDQUFDO0FBRWQ7QUFBQ1IsR0FBQSxDQXhFUThELFlBQVk7RUFBQSxRQUNKRSxjQUFTO0FBQUE7QUFBQWUsR0FBQSxHQURqQmpCLFlBQVk7QUFBQSxJQUFBa0IsUUFBQSxHQUFBQyxPQUFBLENBQUFDLE9BQUEsR0EwRU5wQixZQUFZO0FBQUEsSUFBQUQsRUFBQSxFQUFBa0IsR0FBQTtBQUFBSSxZQUFBLENBQUF0QixFQUFBO0FBQUFzQixZQUFBLENBQUFKLEdBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}