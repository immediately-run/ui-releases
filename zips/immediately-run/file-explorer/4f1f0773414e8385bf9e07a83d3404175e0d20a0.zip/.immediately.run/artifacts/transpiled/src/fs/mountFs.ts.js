"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.fsAvailable = fsAvailable;
exports.readdir = readdir;
// Read a mount's directory entries from the sandbox filesystem.
//
// Mounts (a space / a granted subtree / the working tree) are attached into the
// sandbox's own filesystem at their absolute `path` (e.g. `/spaces/{id}`,
// `/mnt/{hash}`) by ZenFS's global `mount()`. To LIST a directory we need a
// node-compatible fs (`promises.readdir`/`stat`) rooted at `/` so those absolute
// mount paths resolve.
//
// IMPORTANT: that is NOT `module.evaluation.module.bundler.fs` — despite the name
// that is the bundler's own layered `FileSystem` (memory + zenfs + node-modules
// layers) whose surface is only `readFile`/`isFile`/`writeFile`; it has no
// `readdir`/`promises`, so reading through it throws on every call. The
// node-compatible fs is the ZenFS bound context the sandbox creates at
// `globalThis.__sandpackSharedFs` (`bindContext({root:'/'})`), mirrored by the
// bundler's `zenFsLayer.boundContext.fs`. We read through its `promises` API and
// tolerate the two common `readdir` shapes (Dirent[] vs string[]).
//
// This helper only works inside the sandbox (where these globals exist); it is
// not exercised in local `vite` dev, so every access is guarded.

/* eslint-disable @typescript-eslint/no-explicit-any */
const hasReaddir = fs => typeof fs?.promises?.readdir === "function" || typeof fs?.readdir === "function";
function sandboxFs() {
  // 1. The sandbox publishes a '/'-rooted bound ZenFS on globalThis — the
  //    canonical node-compatible fs that sees every mount.
  try {
    const shared = globalThis.__sandpackSharedFs;
    if (hasReaddir(shared)) return shared;
  } catch {
    /* not in the sandbox */
  }
  // 2. Fall back to the bundler's ZenFS layer bound context (also '/'-rooted),
  //    reached the same way the SDK reaches other bundler services.
  try {
    // @ts-expect-error - `module` is injected by the sandbox runtime (see SDK mounts.ts)
    const layers = module?.evaluation?.module?.bundler?.fs?.layers;
    if (Array.isArray(layers)) {
      for (const layer of layers) {
        const fs = layer?.boundContext?.fs;
        if (hasReaddir(fs)) return fs;
      }
    }
  } catch {
    /* not in the sandbox */
  }
  return null;
}
const joinPath = (dir, name) => `${dir.replace(/\/+$/, "")}/${name}`;

/** Is the sandbox fs reachable at all? (false in local dev / before boot). */
function fsAvailable() {
  return sandboxFs() != null;
}

/** List `path`'s immediate entries, directories first then files, A→Z. */
async function readdir(path) {
  const fs = sandboxFs();
  if (!fs) throw new Error("sandbox filesystem unavailable");
  const p = fs.promises ?? fs;
  let raw;
  try {
    raw = await p.readdir(path, {
      withFileTypes: true
    });
  } catch {
    raw = await p.readdir(path);
  }
  const entries = [];
  for (const item of raw) {
    if (typeof item === "string") {
      // string[] shape — stat each to learn directory-ness.
      let isDir = false;
      try {
        const st = await p.stat(joinPath(path, item));
        isDir = typeof st?.isDirectory === "function" ? st.isDirectory() : !!st?.isDirectory;
      } catch {
        /* unreadable entry — treat as a file */
      }
      entries.push({
        name: item,
        isDir
      });
    } else {
      // Dirent shape.
      const isDir = typeof item?.isDirectory === "function" ? item.isDirectory() : !!item?.isDirectory;
      entries.push({
        name: String(item?.name ?? item),
        isDir
      });
    }
  }
  return entries.sort((a, b) => a.isDir === b.isDir ? a.name.localeCompare(b.name) : a.isDir ? -1 : 1);
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJoYXNSZWFkZGlyIiwiZnMiLCJwcm9taXNlcyIsInJlYWRkaXIiLCJzYW5kYm94RnMiLCJzaGFyZWQiLCJnbG9iYWxUaGlzIiwiX19zYW5kcGFja1NoYXJlZEZzIiwibGF5ZXJzIiwibW9kdWxlIiwiZXZhbHVhdGlvbiIsImJ1bmRsZXIiLCJBcnJheSIsImlzQXJyYXkiLCJsYXllciIsImJvdW5kQ29udGV4dCIsImpvaW5QYXRoIiwiZGlyIiwibmFtZSIsInJlcGxhY2UiLCJmc0F2YWlsYWJsZSIsInBhdGgiLCJFcnJvciIsInAiLCJyYXciLCJ3aXRoRmlsZVR5cGVzIiwiZW50cmllcyIsIml0ZW0iLCJpc0RpciIsInN0Iiwic3RhdCIsImlzRGlyZWN0b3J5IiwicHVzaCIsIlN0cmluZyIsInNvcnQiLCJhIiwiYiIsImxvY2FsZUNvbXBhcmUiXSwic291cmNlcyI6WyJtb3VudEZzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIFJlYWQgYSBtb3VudCdzIGRpcmVjdG9yeSBlbnRyaWVzIGZyb20gdGhlIHNhbmRib3ggZmlsZXN5c3RlbS5cbi8vXG4vLyBNb3VudHMgKGEgc3BhY2UgLyBhIGdyYW50ZWQgc3VidHJlZSAvIHRoZSB3b3JraW5nIHRyZWUpIGFyZSBhdHRhY2hlZCBpbnRvIHRoZVxuLy8gc2FuZGJveCdzIG93biBmaWxlc3lzdGVtIGF0IHRoZWlyIGFic29sdXRlIGBwYXRoYCAoZS5nLiBgL3NwYWNlcy97aWR9YCxcbi8vIGAvbW50L3toYXNofWApIGJ5IFplbkZTJ3MgZ2xvYmFsIGBtb3VudCgpYC4gVG8gTElTVCBhIGRpcmVjdG9yeSB3ZSBuZWVkIGFcbi8vIG5vZGUtY29tcGF0aWJsZSBmcyAoYHByb21pc2VzLnJlYWRkaXJgL2BzdGF0YCkgcm9vdGVkIGF0IGAvYCBzbyB0aG9zZSBhYnNvbHV0ZVxuLy8gbW91bnQgcGF0aHMgcmVzb2x2ZS5cbi8vXG4vLyBJTVBPUlRBTlQ6IHRoYXQgaXMgTk9UIGBtb2R1bGUuZXZhbHVhdGlvbi5tb2R1bGUuYnVuZGxlci5mc2Ag4oCUIGRlc3BpdGUgdGhlIG5hbWVcbi8vIHRoYXQgaXMgdGhlIGJ1bmRsZXIncyBvd24gbGF5ZXJlZCBgRmlsZVN5c3RlbWAgKG1lbW9yeSArIHplbmZzICsgbm9kZS1tb2R1bGVzXG4vLyBsYXllcnMpIHdob3NlIHN1cmZhY2UgaXMgb25seSBgcmVhZEZpbGVgL2Bpc0ZpbGVgL2B3cml0ZUZpbGVgOyBpdCBoYXMgbm9cbi8vIGByZWFkZGlyYC9gcHJvbWlzZXNgLCBzbyByZWFkaW5nIHRocm91Z2ggaXQgdGhyb3dzIG9uIGV2ZXJ5IGNhbGwuIFRoZVxuLy8gbm9kZS1jb21wYXRpYmxlIGZzIGlzIHRoZSBaZW5GUyBib3VuZCBjb250ZXh0IHRoZSBzYW5kYm94IGNyZWF0ZXMgYXRcbi8vIGBnbG9iYWxUaGlzLl9fc2FuZHBhY2tTaGFyZWRGc2AgKGBiaW5kQ29udGV4dCh7cm9vdDonLyd9KWApLCBtaXJyb3JlZCBieSB0aGVcbi8vIGJ1bmRsZXIncyBgemVuRnNMYXllci5ib3VuZENvbnRleHQuZnNgLiBXZSByZWFkIHRocm91Z2ggaXRzIGBwcm9taXNlc2AgQVBJIGFuZFxuLy8gdG9sZXJhdGUgdGhlIHR3byBjb21tb24gYHJlYWRkaXJgIHNoYXBlcyAoRGlyZW50W10gdnMgc3RyaW5nW10pLlxuLy9cbi8vIFRoaXMgaGVscGVyIG9ubHkgd29ya3MgaW5zaWRlIHRoZSBzYW5kYm94ICh3aGVyZSB0aGVzZSBnbG9iYWxzIGV4aXN0KTsgaXQgaXNcbi8vIG5vdCBleGVyY2lzZWQgaW4gbG9jYWwgYHZpdGVgIGRldiwgc28gZXZlcnkgYWNjZXNzIGlzIGd1YXJkZWQuXG5cbmV4cG9ydCBpbnRlcmZhY2UgRGlyRW50cnkge1xuICBuYW1lOiBzdHJpbmc7XG4gIGlzRGlyOiBib29sZWFuO1xufVxuXG4vKiBlc2xpbnQtZGlzYWJsZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55ICovXG5jb25zdCBoYXNSZWFkZGlyID0gKGZzOiBhbnkpOiBib29sZWFuID0+XG4gIHR5cGVvZiBmcz8ucHJvbWlzZXM/LnJlYWRkaXIgPT09IFwiZnVuY3Rpb25cIiB8fCB0eXBlb2YgZnM/LnJlYWRkaXIgPT09IFwiZnVuY3Rpb25cIjtcblxuZnVuY3Rpb24gc2FuZGJveEZzKCk6IGFueSB8IG51bGwge1xuICAvLyAxLiBUaGUgc2FuZGJveCBwdWJsaXNoZXMgYSAnLyctcm9vdGVkIGJvdW5kIFplbkZTIG9uIGdsb2JhbFRoaXMg4oCUIHRoZVxuICAvLyAgICBjYW5vbmljYWwgbm9kZS1jb21wYXRpYmxlIGZzIHRoYXQgc2VlcyBldmVyeSBtb3VudC5cbiAgdHJ5IHtcbiAgICBjb25zdCBzaGFyZWQgPSAoZ2xvYmFsVGhpcyBhcyBhbnkpLl9fc2FuZHBhY2tTaGFyZWRGcztcbiAgICBpZiAoaGFzUmVhZGRpcihzaGFyZWQpKSByZXR1cm4gc2hhcmVkO1xuICB9IGNhdGNoIHtcbiAgICAvKiBub3QgaW4gdGhlIHNhbmRib3ggKi9cbiAgfVxuICAvLyAyLiBGYWxsIGJhY2sgdG8gdGhlIGJ1bmRsZXIncyBaZW5GUyBsYXllciBib3VuZCBjb250ZXh0IChhbHNvICcvJy1yb290ZWQpLFxuICAvLyAgICByZWFjaGVkIHRoZSBzYW1lIHdheSB0aGUgU0RLIHJlYWNoZXMgb3RoZXIgYnVuZGxlciBzZXJ2aWNlcy5cbiAgdHJ5IHtcbiAgICAvLyBAdHMtZXhwZWN0LWVycm9yIC0gYG1vZHVsZWAgaXMgaW5qZWN0ZWQgYnkgdGhlIHNhbmRib3ggcnVudGltZSAoc2VlIFNESyBtb3VudHMudHMpXG4gICAgY29uc3QgbGF5ZXJzID0gbW9kdWxlPy5ldmFsdWF0aW9uPy5tb2R1bGU/LmJ1bmRsZXI/LmZzPy5sYXllcnM7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkobGF5ZXJzKSkge1xuICAgICAgZm9yIChjb25zdCBsYXllciBvZiBsYXllcnMpIHtcbiAgICAgICAgY29uc3QgZnMgPSBsYXllcj8uYm91bmRDb250ZXh0Py5mcztcbiAgICAgICAgaWYgKGhhc1JlYWRkaXIoZnMpKSByZXR1cm4gZnM7XG4gICAgICB9XG4gICAgfVxuICB9IGNhdGNoIHtcbiAgICAvKiBub3QgaW4gdGhlIHNhbmRib3ggKi9cbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cblxuY29uc3Qgam9pblBhdGggPSAoZGlyOiBzdHJpbmcsIG5hbWU6IHN0cmluZyk6IHN0cmluZyA9PlxuICBgJHtkaXIucmVwbGFjZSgvXFwvKyQvLCBcIlwiKX0vJHtuYW1lfWA7XG5cbi8qKiBJcyB0aGUgc2FuZGJveCBmcyByZWFjaGFibGUgYXQgYWxsPyAoZmFsc2UgaW4gbG9jYWwgZGV2IC8gYmVmb3JlIGJvb3QpLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGZzQXZhaWxhYmxlKCk6IGJvb2xlYW4ge1xuICByZXR1cm4gc2FuZGJveEZzKCkgIT0gbnVsbDtcbn1cblxuLyoqIExpc3QgYHBhdGhgJ3MgaW1tZWRpYXRlIGVudHJpZXMsIGRpcmVjdG9yaWVzIGZpcnN0IHRoZW4gZmlsZXMsIEHihpJaLiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJlYWRkaXIocGF0aDogc3RyaW5nKTogUHJvbWlzZTxEaXJFbnRyeVtdPiB7XG4gIGNvbnN0IGZzID0gc2FuZGJveEZzKCk7XG4gIGlmICghZnMpIHRocm93IG5ldyBFcnJvcihcInNhbmRib3ggZmlsZXN5c3RlbSB1bmF2YWlsYWJsZVwiKTtcbiAgY29uc3QgcCA9IGZzLnByb21pc2VzID8/IGZzO1xuXG4gIGxldCByYXc6IGFueVtdO1xuICB0cnkge1xuICAgIHJhdyA9IGF3YWl0IHAucmVhZGRpcihwYXRoLCB7IHdpdGhGaWxlVHlwZXM6IHRydWUgfSk7XG4gIH0gY2F0Y2gge1xuICAgIHJhdyA9IGF3YWl0IHAucmVhZGRpcihwYXRoKTtcbiAgfVxuXG4gIGNvbnN0IGVudHJpZXM6IERpckVudHJ5W10gPSBbXTtcbiAgZm9yIChjb25zdCBpdGVtIG9mIHJhdykge1xuICAgIGlmICh0eXBlb2YgaXRlbSA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgLy8gc3RyaW5nW10gc2hhcGUg4oCUIHN0YXQgZWFjaCB0byBsZWFybiBkaXJlY3RvcnktbmVzcy5cbiAgICAgIGxldCBpc0RpciA9IGZhbHNlO1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3Qgc3QgPSBhd2FpdCBwLnN0YXQoam9pblBhdGgocGF0aCwgaXRlbSkpO1xuICAgICAgICBpc0RpciA9IHR5cGVvZiBzdD8uaXNEaXJlY3RvcnkgPT09IFwiZnVuY3Rpb25cIiA/IHN0LmlzRGlyZWN0b3J5KCkgOiAhIXN0Py5pc0RpcmVjdG9yeTtcbiAgICAgIH0gY2F0Y2gge1xuICAgICAgICAvKiB1bnJlYWRhYmxlIGVudHJ5IOKAlCB0cmVhdCBhcyBhIGZpbGUgKi9cbiAgICAgIH1cbiAgICAgIGVudHJpZXMucHVzaCh7IG5hbWU6IGl0ZW0sIGlzRGlyIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICAvLyBEaXJlbnQgc2hhcGUuXG4gICAgICBjb25zdCBpc0RpciA9XG4gICAgICAgIHR5cGVvZiBpdGVtPy5pc0RpcmVjdG9yeSA9PT0gXCJmdW5jdGlvblwiID8gaXRlbS5pc0RpcmVjdG9yeSgpIDogISFpdGVtPy5pc0RpcmVjdG9yeTtcbiAgICAgIGVudHJpZXMucHVzaCh7IG5hbWU6IFN0cmluZyhpdGVtPy5uYW1lID8/IGl0ZW0pLCBpc0RpciB9KTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gZW50cmllcy5zb3J0KChhLCBiKSA9PlxuICAgIGEuaXNEaXIgPT09IGIuaXNEaXIgPyBhLm5hbWUubG9jYWxlQ29tcGFyZShiLm5hbWUpIDogYS5pc0RpciA/IC0xIDogMSxcbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQU9BO0FBQ0EsTUFBTUEsVUFBVSxHQUFJQyxFQUFPLElBQ3pCLE9BQU9BLEVBQUUsRUFBRUMsUUFBUSxFQUFFQyxPQUFPLEtBQUssVUFBVSxJQUFJLE9BQU9GLEVBQUUsRUFBRUUsT0FBTyxLQUFLLFVBQVU7QUFFbEYsU0FBU0MsU0FBU0EsQ0FBQSxFQUFlO0VBQy9CO0VBQ0E7RUFDQSxJQUFJO0lBQ0YsTUFBTUMsTUFBTSxHQUFJQyxVQUFVLENBQVNDLGtCQUFrQjtJQUNyRCxJQUFJUCxVQUFVLENBQUNLLE1BQU0sQ0FBQyxFQUFFLE9BQU9BLE1BQU07RUFDdkMsQ0FBQyxDQUFDLE1BQU07SUFDTjtFQUFBO0VBRUY7RUFDQTtFQUNBLElBQUk7SUFDRjtJQUNBLE1BQU1HLE1BQU0sR0FBR0MsTUFBTSxFQUFFQyxVQUFVLEVBQUVELE1BQU0sRUFBRUUsT0FBTyxFQUFFVixFQUFFLEVBQUVPLE1BQU07SUFDOUQsSUFBSUksS0FBSyxDQUFDQyxPQUFPLENBQUNMLE1BQU0sQ0FBQyxFQUFFO01BQ3pCLEtBQUssTUFBTU0sS0FBSyxJQUFJTixNQUFNLEVBQUU7UUFDMUIsTUFBTVAsRUFBRSxHQUFHYSxLQUFLLEVBQUVDLFlBQVksRUFBRWQsRUFBRTtRQUNsQyxJQUFJRCxVQUFVLENBQUNDLEVBQUUsQ0FBQyxFQUFFLE9BQU9BLEVBQUU7TUFDL0I7SUFDRjtFQUNGLENBQUMsQ0FBQyxNQUFNO0lBQ047RUFBQTtFQUVGLE9BQU8sSUFBSTtBQUNiO0FBRUEsTUFBTWUsUUFBUSxHQUFHQSxDQUFDQyxHQUFXLEVBQUVDLElBQVksS0FDekMsR0FBR0QsR0FBRyxDQUFDRSxPQUFPLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxJQUFJRCxJQUFJLEVBQUU7O0FBRXRDO0FBQ08sU0FBU0UsV0FBV0EsQ0FBQSxFQUFZO0VBQ3JDLE9BQU9oQixTQUFTLENBQUMsQ0FBQyxJQUFJLElBQUk7QUFDNUI7O0FBRUE7QUFDTyxlQUFlRCxPQUFPQSxDQUFDa0IsSUFBWSxFQUF1QjtFQUMvRCxNQUFNcEIsRUFBRSxHQUFHRyxTQUFTLENBQUMsQ0FBQztFQUN0QixJQUFJLENBQUNILEVBQUUsRUFBRSxNQUFNLElBQUlxQixLQUFLLENBQUMsZ0NBQWdDLENBQUM7RUFDMUQsTUFBTUMsQ0FBQyxHQUFHdEIsRUFBRSxDQUFDQyxRQUFRLElBQUlELEVBQUU7RUFFM0IsSUFBSXVCLEdBQVU7RUFDZCxJQUFJO0lBQ0ZBLEdBQUcsR0FBRyxNQUFNRCxDQUFDLENBQUNwQixPQUFPLENBQUNrQixJQUFJLEVBQUU7TUFBRUksYUFBYSxFQUFFO0lBQUssQ0FBQyxDQUFDO0VBQ3RELENBQUMsQ0FBQyxNQUFNO0lBQ05ELEdBQUcsR0FBRyxNQUFNRCxDQUFDLENBQUNwQixPQUFPLENBQUNrQixJQUFJLENBQUM7RUFDN0I7RUFFQSxNQUFNSyxPQUFtQixHQUFHLEVBQUU7RUFDOUIsS0FBSyxNQUFNQyxJQUFJLElBQUlILEdBQUcsRUFBRTtJQUN0QixJQUFJLE9BQU9HLElBQUksS0FBSyxRQUFRLEVBQUU7TUFDNUI7TUFDQSxJQUFJQyxLQUFLLEdBQUcsS0FBSztNQUNqQixJQUFJO1FBQ0YsTUFBTUMsRUFBRSxHQUFHLE1BQU1OLENBQUMsQ0FBQ08sSUFBSSxDQUFDZCxRQUFRLENBQUNLLElBQUksRUFBRU0sSUFBSSxDQUFDLENBQUM7UUFDN0NDLEtBQUssR0FBRyxPQUFPQyxFQUFFLEVBQUVFLFdBQVcsS0FBSyxVQUFVLEdBQUdGLEVBQUUsQ0FBQ0UsV0FBVyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUNGLEVBQUUsRUFBRUUsV0FBVztNQUN0RixDQUFDLENBQUMsTUFBTTtRQUNOO01BQUE7TUFFRkwsT0FBTyxDQUFDTSxJQUFJLENBQUM7UUFBRWQsSUFBSSxFQUFFUyxJQUFJO1FBQUVDO01BQU0sQ0FBQyxDQUFDO0lBQ3JDLENBQUMsTUFBTTtNQUNMO01BQ0EsTUFBTUEsS0FBSyxHQUNULE9BQU9ELElBQUksRUFBRUksV0FBVyxLQUFLLFVBQVUsR0FBR0osSUFBSSxDQUFDSSxXQUFXLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQ0osSUFBSSxFQUFFSSxXQUFXO01BQ3BGTCxPQUFPLENBQUNNLElBQUksQ0FBQztRQUFFZCxJQUFJLEVBQUVlLE1BQU0sQ0FBQ04sSUFBSSxFQUFFVCxJQUFJLElBQUlTLElBQUksQ0FBQztRQUFFQztNQUFNLENBQUMsQ0FBQztJQUMzRDtFQUNGO0VBRUEsT0FBT0YsT0FBTyxDQUFDUSxJQUFJLENBQUMsQ0FBQ0MsQ0FBQyxFQUFFQyxDQUFDLEtBQ3ZCRCxDQUFDLENBQUNQLEtBQUssS0FBS1EsQ0FBQyxDQUFDUixLQUFLLEdBQUdPLENBQUMsQ0FBQ2pCLElBQUksQ0FBQ21CLGFBQWEsQ0FBQ0QsQ0FBQyxDQUFDbEIsSUFBSSxDQUFDLEdBQUdpQixDQUFDLENBQUNQLEtBQUssR0FBRyxDQUFDLENBQUMsR0FBRyxDQUN0RSxDQUFDO0FBQ0giLCJpZ25vcmVMaXN0IjpbXX0=