// The shared row gesture bundle (R3-84). Every layout — tree, list, icons,
// columns — must support the SAME shipped affordances (FILE_EXPLORER_SPEC §3/§4):
// the context menu (right-click + 3s long-press), the internal move (R3-81) and
// upload (R3-82) drops onto a directory, and the cross-app drag-out (R3-83). The
// tree (`TreeNode`) grew these inline first; this hook lifts that logic out so
// list rows, icon tiles and column rows reuse ONE implementation instead of four
// drifting copies. It returns the spreadable DOM props + the live drop-target
// flag; the layout supplies its own onClick/onKeyDown (selection/navigation
// differ per layout) and renders the per-row delete affordance.
import { useState } from "react";
import { MOVE_MIME } from "../explorer";
import type { RowCtx } from "../types";

export type { RowCtx };

/** The stable per-explorer callback bundle handed to every row. Each callback
 *  takes explicit args so one instance serves every scope/layout. The one host
 *  call this used to make directly (`cancelItemDrag`) is now the injected
 *  `cancelDragOut` callback (Phase 02 §C.2), so this hook holds NO SDK import. */
export interface NodeHandlers {
  onActivate: (absPath: string, isDir: boolean) => void;
  /** `e` is the (structural) context-menu event; `currentTarget`, when present,
   *  is the row element that opened the menu — the view reads it synchronously
   *  (a synthetic event's `currentTarget` dies with the handler) to know where
   *  to return focus when the menu's inline prompt is Escape-cancelled. The
   *  long-press path has no currentTarget (nothing is focused on touch). */
  onMenu: (
    e: { clientX: number; clientY: number; currentTarget?: EventTarget | null },
    ctx: RowCtx,
  ) => void;
  onMoveDrop: (
    fromAbs: string,
    fromRoot: string,
    fromIsDir: boolean,
    targetDir: string,
    targetRoot: string,
  ) => void;
  onUploadDrop: (files: File[], targetDir: string, writable: boolean) => void;
  beginDragOut: (absPath: string, isDir: boolean, mountId: string, rootPath: string) => void;
  cancelDragOut: () => void;
  onDelete: (absPath: string, isDir: boolean, rootPath: string) => void;
}

export interface RowProps {
  /** R3-626 — the row's identity, so a container that catches what the row
   *  declines (a blank-space/file-row upload drop) can resolve the target
   *  directory from the DOM (`closest("[data-path]")`), the same attributes
   *  the tree row has carried since file-explorer#40. */
  "data-path": string;
  "data-dir": string;
  draggable: true;
  onContextMenu: (e: React.MouseEvent) => void;
  onDragStart: (e: React.DragEvent) => void;
  onDragEnd: () => void;
  onDragOver: (e: React.DragEvent) => void;
  onDragLeave: () => void;
  onDrop: (e: React.DragEvent) => void;
  onPointerDown: (e: React.PointerEvent) => void;
  onPointerMove: (e: React.PointerEvent) => void;
  onPointerUp: () => void;
  onPointerCancel: () => void;
}

/**
 * The keyboard spelling of the row's context menu (ContextMenu key, or
 * Shift+F10 where keyboards have no menu key) — the ONE handler every layout's
 * row keydown calls first, so a row's menu actions (delete, rename, move…)
 * are never pointer-only in any layout. Returns whether the key was consumed.
 */
export function openRowMenuKey(
  e: React.KeyboardEvent,
  handlers: NodeHandlers,
  ctx: RowCtx,
): boolean {
  if (e.key !== "ContextMenu" && !(e.shiftKey && e.key === "F10")) return false;
  e.preventDefault();
  const r = (e.currentTarget as HTMLElement).getBoundingClientRect();
  handlers.onMenu(
    { clientX: r.left + 12, clientY: r.bottom, currentTarget: e.currentTarget },
    ctx,
  );
  return true;
}

/**
 * Build the gesture props for one row. `longPress` is the pointer bundle from
 * `useLongPress` (the layout creates it so the menu opens at the row, mirroring
 * the tree). Returns `{ dropTarget, rowProps }`.
 */
export function useRowInteractions(
  ctx: RowCtx,
  handlers: NodeHandlers,
  longPress: {
    onPointerDown: (e: React.PointerEvent) => void;
    onPointerMove: (e: React.PointerEvent) => void;
    onPointerUp: () => void;
    onPointerCancel: () => void;
  },
): { dropTarget: boolean; rowProps: RowProps } {
  const [dropTarget, setDropTarget] = useState(false);
  const { absPath, isDir, rootPath, mountId, writable } = ctx;

  // Drag-out (R3-83) + internal move (R3-81) both start here: set the private move
  // payload (used only for an in-explorer drop — it names whether the dragged
  // thing is a folder, so the drop side can restore the right row) AND ask the
  // host to begin a cross-app drag-out; whichever drop fires wins.
  const onDragStart = (e: React.DragEvent) => {
    e.dataTransfer.setData(MOVE_MIME, JSON.stringify({ from: absPath, rootPath, isDir }));
    e.dataTransfer.effectAllowed = "copyMove";
    handlers.beginDragOut(absPath, isDir, mountId, rootPath);
  };
  const onDragEnd = () => handlers.cancelDragOut();

  // A directory row is a drop target for internal moves and OS-file uploads.
  const onDragOver = (e: React.DragEvent) => {
    if (!isDir) return;
    const isMove = e.dataTransfer.types.includes(MOVE_MIME);
    const isUpload = e.dataTransfer.types.includes("Files");
    if (!isMove && !isUpload) return;
    if (isUpload && !writable) return;
    e.preventDefault();
    e.stopPropagation();
    e.dataTransfer.dropEffect = isMove ? "move" : "copy";
    setDropTarget(true);
  };
  const onDragLeave = () => setDropTarget(false);
  const onDrop = (e: React.DragEvent) => {
    if (!isDir) return;
    const move = e.dataTransfer.getData(MOVE_MIME);
    const files = Array.from(e.dataTransfer.files);
    if (!move && !files.length) return;
    e.preventDefault();
    e.stopPropagation();
    setDropTarget(false);
    handlers.cancelDragOut(); // the drop landed inside the explorer → not a drag-out
    if (move) {
      const { from, rootPath: fromRoot, isDir: fromIsDir } = JSON.parse(move) as {
        from: string;
        rootPath: string;
        isDir: boolean;
      };
      handlers.onMoveDrop(from, fromRoot, fromIsDir, absPath, rootPath);
    } else if (files.length) {
      handlers.onUploadDrop(files, absPath, writable);
    }
  };

  const rowProps: RowProps = {
    "data-path": absPath,
    "data-dir": isDir ? "1" : "0",
    draggable: true,
    onContextMenu: (e) => {
      e.preventDefault();
      handlers.onMenu(e, ctx);
    },
    onDragStart,
    onDragEnd,
    onDragOver,
    onDragLeave,
    onDrop,
    onPointerDown: longPress.onPointerDown,
    onPointerMove: longPress.onPointerMove,
    onPointerUp: longPress.onPointerUp,
    onPointerCancel: longPress.onPointerCancel,
  };

  return { dropTarget, rowProps };
}
