// `SdkFileExplorer` — the shipped file-explorer app, assembled from the headless
// library + the SDK adapter (Phase 02 §B.5). This IS the former app: it wires
// `useSdkRoots()` → roots, `sdkFsSource` → fs, `makeSdkActions()` → actions, the
// editor's active file (`useEditorContext`) → activePath, the per-app settings
// roots (`listSettingsApps`/`openSettingsOf`), and the "Summarize…" feature (an
// `extraMenuItems` contribution + the modal) into `<FileExplorerView/>`.
//
// The existing FileExplorer test suite renders THIS and keeps the same SDK mocks —
// the parity proof that the extraction is behavior-preserving.
import { useCallback, useEffect, useRef, useState } from "react";
import { FolderTree, Eye, EyeOff, Plus, Users, BookOpen, Play } from "lucide-react";
import {
  useEditorContext,
  listSettingsApps,
  openSettingsOf,
  reportReady,
  requestMount,
  useMounts,
  useRegion,
} from "@immediately-run/sdk";
import { addListener } from "@immediately-run/sdk/sandboxUtils";
import FileExplorerView from "../FileExplorerView";
import LensSwitcher, { type Lens } from "../LensSwitcher";
import { useShowAllFilesystems } from "../hooks/useShowAllFilesystems";
import { isSettingsMount } from "./mounts";
import { useSdkRoots } from "./useSdkRoots";
import { useSessionRoots } from "./useSessionRoots";
import { sdkFsSource } from "./mountFs";
import { makeSdkActions } from "./actions";
import { summarizeMenuItems } from "./summarize";
import { useOpensWith } from "./useOpensWith";
import type { OpensWithOffer } from "../opensWith";
import { openWith, openInPlace } from "./openWith";
import SummaryModal, { type SummaryTarget } from "./SummaryModal";
import type { ExplorerActions, MenuItem, RowCtx } from "../types";

// The action bundle + fs are stable for the lifetime of the app.
const actions: ExplorerActions = makeSdkActions();

// The HOST origin, recovered from the iframe's `?href=` boot param (the sandbox URL
// carries the host page it renders for). Needed to open host routes (`/spaces`) in a
// new tab — a relative URL would resolve against the sandbox origin. Null when absent
// (plain `vite dev`), in which case host-route affordances are hidden, never broken.
const getHostOrigin = (): string | null => {
  try {
    const href = new URLSearchParams(window.location.search).get("href");
    return href ? new URL(href).origin : null;
  } catch {
    return null;
  }
};

/** The full-tab space-manager, at a space (R3-269 D4: entry point only — the
 *  membership/share/create VERBS stay in space-manager, R-SPACES-7). */
const openManageSharing = (spaceId: string) => {
  const hostOrigin = getHostOrigin();
  if (!hostOrigin) return;
  window.open(
    `${hostOrigin}/spaces?space=${encodeURIComponent(spaceId)}`,
    "_blank",
    "noopener,noreferrer",
  );
};

function SdkFileExplorer() {
  // R3-238: settings stores and the affordance that opens them are advanced plumbing,
  // hidden unless the user opts in. One flag governs BOTH halves — a session that shows
  // no `settings:` roots must not still advertise `settings · <app>` buttons.
  const [showAll, setShowAll] = useShowAllFilesystems();
  const roots = useSdkRoots(showAll);
  const mounts = useMounts();
  const editorContext = useEditorContext();
  const { activeFile } = editorContext;
  // The stage's viewed-document hint (R3-268). Read defensively so this app
  // works against both SDK generations: an SDK without the field yields
  // `undefined` → no marker, never a crash.
  const viewedFile =
    (editorContext as { viewedFile?: string | null }).viewedFile ?? null;
  const [summary, setSummary] = useState<SummaryTarget | null>(null);
  // Gesture-gated reveal (R3-268 follow-up): the HOST sends a one-shot
  // `viewed-reveal` only for navigations that provably rode a real user click
  // (it samples its own transient activation — this frame cannot fake it) and
  // only to `editor:read` frames. The view expands ancestors + scrolls the row
  // into view; focus never moves. Everything else stays highlight-only.
  const [reveal, setReveal] = useState<{ path: string; nonce: number } | null>(null);
  const revealNonceRef = useRef(0);
  useEffect(() => {
    let dispose: (() => void) | undefined;
    try {
      dispose = addListener("viewed-reveal", (m: { path?: unknown }) => {
        if (typeof m.path === "string") {
          revealNonceRef.current += 1;
          setReveal({ path: m.path, nonce: revealNonceRef.current });
        }
      });
      // R3-440 (the R3-392 readiness contract, extended): report ready
      // IMMEDIATELY after subscribing — the host holds a gesture's pending
      // `viewed-reveal` until this report, and a raw dispatch sent before it
      // is silently dropped. A frame that never reports never receives.
      //
      // This deliberately overloads the SDK's skeleton-timing contract
      // (ready.ts: "not at mount"): this report is LISTENER readiness, and the
      // skeleton cost is nil because the mount effect commits with the root
      // render (max(commit, report) ≈ commit). The spend is permanent
      // (first-call-wins), and accepted: this app has no later usefully-
      // interactive moment to delay for. The boot race the report opens
      // (a reveal released before roots exist) is closed by the view's
      // rootKey retry, not by reporting later. TOOLS_ACTIVITY_SPEC §4.1.
      reportReady();
    } catch {
      /* no host transport — a standalone dev-server render */
    }
    return () => dispose?.();
  }, []);

  // The first-party "App | Session" lens (PRINCIPALS §9 B2). `sessionAvailable` is
  // true only when the host delivered a session signal (first-party frame); a
  // URL-loaded fork gets none, so the toggle never renders and the app is App-only.
  const {
    roots: sessionRoots,
    available: sessionAvailable,
    hidden: sessionHidden,
  } = useSessionRoots(showAll);
  // PRINCIPALS §9 B4 (R3-96): as the standalone User-scope `page.commander` surface this
  // app IS the cross-app "everything you've ever opened" navigator, so it defaults to the
  // broad `mounts:registry` lens rather than the app's own mounts. In the workbench
  // `panel.files` projection it defaults to App as before. (A fork never holds
  // `mounts:registry`, so `sessionAvailable` is false there and it stays App-only anyway.)
  const isCommander = useRegion() === "page.commander";
  const [lens, setLens] = useState<Lens>(isCommander ? "session" : "app");
  // Fall back to App if the session signal goes away (mounts revoked / not first-party).
  const effectiveLens: Lens = sessionAvailable ? lens : "app";
  const shownRoots = effectiveLens === "session" ? sessionRoots : roots;

  // The "file commander": every app that has per-user settings (elevated
  // `settings:all`). Empty for a fork/preview lacking the capability. Each opened
  // app's settings mount flows in as its own root via `useSdkRoots()`; this slice
  // only drives a "click to open" affordance for apps not yet mounted.
  const [settingsApps, setSettingsApps] = useState<string[]>([]);
  useEffect(() => {
    let live = true;
    void listSettingsApps()
      .then((apps) => live && setSettingsApps(apps))
      .catch(() => undefined);
    return () => {
      live = false;
    };
  }, []);
  const openAppSettings = useCallback((appKey: string) => {
    void openSettingsOf(appKey).catch(() => undefined);
  }, []);

  // R3-269 D5: "Add a space…" asks the HOST powerbox to enumerate + grant
  // (R-SPACES-2: the explorer never lists spaces or mints mounts itself). The granted
  // mount then flows in through `useMounts()` like any other. `cancelled` is a normal
  // outcome, not an error.
  const addSpace = useCallback(() => {
    void requestMount().catch(() => undefined);
  }, []);

  // R3-267: the `opensWith` caller. The wrapped fs probes each listed directory for
  // its content marker, so a folder that declares what opens it can be offered one.
  // R3-159 adds the into-stage twin: a launchable contract also gets "Open in place".
  const { fs: opensWithFs, offerFor, inPlaceFor, withdraw, viewOffersFor } = useOpensWith(sdkFsSource);
  const rootByPath = useCallback(
    (absPath: string) => shownRoots.find((r) => absPath === r.path || absPath.startsWith(`${r.path}/`)) ?? null,
    [shownRoots],
  );
  const runOpenWith = useCallback(
    // `chosen` — a declared view's offer (R3-789); absent ⇒ the marker's own offer.
    (absPath: string, chosen?: OpensWithOffer) => {
      const root = rootByPath(absPath);
      const offer = chosen ?? offerFor(absPath);
      if (!root || !offer) return;
      // Fire-and-forget: the host draws the viewer. Every refusal is handled inside
      // `openWith` — `cancelled` is the ordinary close, and a contract-level refusal
      // withdraws the affordance rather than putting a protocol code on screen.
      void openWith(root, absPath, offer).then((outcome) => {
        if (outcome.status === "withdraw") withdraw(outcome.task);
      });
    },
    [rootByPath, offerFor, withdraw],
  );
  // R3-159: fire-and-forget like runOpenWith — the host draws the into-stage overlay
  // and the suspend/restore. A launch refusal just declines (invisibly): no launch
  // code is a session-permanent verdict, so the affordance always stays.
  const runOpenInPlace = useCallback(
    (absPath: string) => {
      const root = rootByPath(absPath);
      const offer = inPlaceFor(absPath);
      if (!root || !offer) return;
      void openInPlace(root, absPath, offer);
    },
    [rootByPath, inPlaceFor],
  );

  const extraMenuItems = useCallback((ctx: RowCtx): MenuItem[] => {
    const items = summarizeMenuItems(ctx, setSummary);
    // The affordance is on the ITEM, offered by the marker's own `kind` — no task name
    // reaches this code, so a folder declaring a later contract works with no change
    // here (only a manifest entry, which the host enforces anyway).
    const offer = ctx.isDir ? offerFor(ctx.absPath) : null;
    const inPlace = ctx.isDir ? inPlaceFor(ctx.absPath) : null;
    const declaredViews = ctx.isDir ? viewOffersFor(ctx.absPath) : [];
    if (offer || inPlace || declaredViews.length > 0) {
      // Unshifted as a pair so the for-result offer leads and the into-stage twin
      // (R3-159) sits directly under it, above everything else the menu offers.
      const openItems: MenuItem[] = [];
      if (offer) {
        openItems.push({
          key: "open-with",
          label: offer.label,
          icon: <BookOpen size={14} aria-hidden="true" />,
          onSelect: () => runOpenWith(ctx.absPath),
        });
      }
      // R3-789 (§4b.1a): one item per declared view, under the bundle's own offer.
      declaredViews.forEach((v, i) => {
        openItems.push({
          key: `open-view-${i}`,
          label: v.label,
          icon: <BookOpen size={14} aria-hidden="true" />,
          onSelect: () => runOpenWith(ctx.absPath, v),
        });
      });
      if (inPlace) {
        openItems.push({
          key: "open-in-place",
          label: inPlace.label,
          icon: <Play size={14} aria-hidden="true" />,
          onSelect: () => runOpenInPlace(ctx.absPath),
        });
      }
      items.unshift(...openItems);
    }
    // R3-269 D4: the per-space "Manage sharing →" entry point, on the space's ROOT row
    // only. Opens the full-tab space-manager AT that space — the verbs live there.
    const spaceId = ctx.mountId.startsWith("space:")
      ? ctx.mountId.slice("space:".length)
      : null;
    if (getHostOrigin() && spaceId && ctx.absPath === ctx.rootPath) {
      items.push({
        key: "manage-sharing",
        label: "Manage sharing →",
        icon: <Users size={14} aria-hidden="true" />,
        onSelect: () => openManageSharing(spaceId),
      });
    }
    return items;
  }, [offerFor, inPlaceFor, viewOffersFor, runOpenWith, runOpenInPlace]);

  // Apps with per-user settings that aren't mounted yet — click to open
  // (`settings:all`). An already-opened settings mount renders as its own root
  // (via `useSdkRoots`), so filter those out. Surfaced in the header (the view is
  // settings-app-agnostic per Phase 02 §A.1).
  const unmountedSettingsApps = settingsApps.filter(
    (ak) => !mounts.some((m) => m.id === `settings:${ak}`),
  );
  const settingsButtons =
    showAll && unmountedSettingsApps.length > 0
      ? unmountedSettingsApps.map((ak) => (
          <button
            key={ak}
            type="button"
            className="settings-app"
            onClick={() => openAppSettings(ak)}
            title={`Open ${ak} settings`}
          >
            <FolderTree size={14} aria-hidden="true" />
            {/* The label is its own element so it can ellipsis-truncate (R3-239):
                `text-overflow` needs a block container, and a bare text node inside
                a flex button is an anonymous item that can only overflow. */}
            <span className="settings-app__label">settings · {ak}</span>
          </button>
        ))
      : null;

  // The reveal affordance is offered only when this session actually HAS something
  // hidden — otherwise every ordinary session pays for an advanced control it can
  // never use. Once the flag is on it stays offered, so the door swings both ways.
  const hasHidden =
    mounts.some(isSettingsMount) || sessionHidden > 0 || unmountedSettingsApps.length > 0;
  const showAllToggle =
    showAll || hasHidden ? (
      <button
        type="button"
        className="panel__action"
        aria-pressed={showAll}
        title={showAll ? "Hide advanced filesystems" : "Show all filesystems"}
        aria-label={showAll ? "Hide advanced filesystems" : "Show all filesystems"}
        onClick={() => setShowAll(!showAll)}
      >
        {showAll ? <Eye size={15} aria-hidden="true" /> : <EyeOff size={15} aria-hidden="true" />}
      </button>
    ) : null;

  // R3-269 D5: the explorer is the add-a-space entry point — a header affordance
  // that invokes the host powerbox. Always offered (it may be the very control that
  // produces the first root).
  const addSpaceButton = (
    <button
      type="button"
      className="panel__action"
      title="Add a space…"
      aria-label="Add a space…"
      onClick={addSpace}
    >
      <Plus size={15} aria-hidden="true" />
    </button>
  );

  // The Session lens toggle leads the header actions, but only when the host
  // delivered a session signal (first-party). A fork never sees it.
  const headerActions = (
    <>
      {sessionAvailable && <LensSwitcher value={effectiveLens} onChange={setLens} />}
      {addSpaceButton}
      {showAllToggle}
    </>
  );
  // NOT in `headerActions`: there is one of these per app with settings, so the count
  // grows with the session. Sharing a fixed row out among an unbounded N is what
  // squashed them into overlapping slivers on a phone; the tray is a row of their own.
  const headerTray = settingsButtons;

  return (
    <>
      <FileExplorerView
        roots={shownRoots}
        fs={opensWithFs}
        actions={actions}
        activePath={activeFile}
        viewedPath={viewedFile}
        extraMenuItems={extraMenuItems}
        reveal={reveal}
        header={{ actions: headerActions, tray: headerTray }}
        emptyState={
          <div className="state">
            <span className="state__icon">
              <FolderTree size={20} aria-hidden="true" />
            </span>
            <h4>No files to show yet.</h4>
            {/* R3-269 D6 first-timer sentence, R-SPACES-1 vocabulary. */}
            <p>
              A space is a folder that lives in your account. You can share it with
              others and open it from any app.
            </p>
            <button type="button" className="state__action" onClick={addSpace}>
              <Plus size={14} aria-hidden="true" />
              Add a space…
            </button>
          </div>
        }
      />
      {summary && <SummaryModal target={summary} onClose={() => setSummary(null)} />}
    </>
  );
}

export default SdkFileExplorer;
