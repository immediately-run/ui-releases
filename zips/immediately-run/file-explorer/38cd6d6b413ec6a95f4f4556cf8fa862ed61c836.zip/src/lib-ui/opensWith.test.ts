import {
  viewOffers,
  APP_FORM_CONTRACT,
  CONTENT_MARKER_FILE,
  openWithLabel,
  opensInPlaceOffer,
  opensWithOffer,
  parseOpensWith,
  withdrawsOffer,
} from "./opensWith";

const policy = { offerable: ["open-wiki", "open-project"] };
const marker = (o: unknown) => JSON.stringify(o);

describe("parseOpensWith — an untrusted marker never throws", () => {
  it("names the marker file the specs name", () => {
    expect(CONTENT_MARKER_FILE).toBe("immediately.run.json");
  });

  it("reads the task and defaults the version to the v1 shape", () => {
    expect(parseOpensWith(marker({ opensWith: { task: "open-wiki" }, kind: "wiki" }))).toEqual({
      task: "open-wiki",
      version: "1.0",
      kind: "wiki",
    });
  });

  it("keeps an explicit version", () => {
    expect(
      parseOpensWith(marker({ opensWith: { task: "open-wiki", version: "1.2" } })),
    ).toMatchObject({ version: "1.2" });
  });

  it.each<[string, unknown]>([
    ["empty text", ""],
    ["whitespace", "   "],
    ["invalid JSON", "{ not json"],
    ["a JSON scalar", '"wiki"'],
    ["a JSON array", "[1,2]"],
    ["no opensWith key", marker({ kind: "wiki" })],
    ["opensWith not an object", marker({ opensWith: "open-wiki" })],
    ["opensWith an array", marker({ opensWith: ["open-wiki"] })],
    ["a non-string task", marker({ opensWith: { task: 7 } })],
    ["an empty task", marker({ opensWith: { task: "  " } })],
  ])("returns null for %s", (_why, text) => {
    expect(parseOpensWith(text as string)).toBeNull();
  });

  it("an APP-form marker opens through the fixed contract, and the app it names is not returned", () => {
    // BUNDLE_EMBEDDING §4b.2 rule 2: the caller never names the app — the host reads the
    // marker at invoke time and resolves the opener itself.
    const parsed = parseOpensWith(marker({ opensWith: { app: "github:mallory/evil", version: "9.9" }, kind: "board" }));
    expect(parsed).toEqual({ task: APP_FORM_CONTRACT, version: "1.0", kind: "board" });
    expect(APP_FORM_CONTRACT).toBe("open-declared");
    expect(JSON.stringify(parsed)).not.toMatch(/mallory|9\.9/);
  });

  it.each<[string, unknown]>([
    ["both forms at once (the host refuses it)", marker({ opensWith: { task: "open-wiki", app: "github:a/b" } })],
    ["an empty app", marker({ opensWith: { app: "" } })],
    ["a non-string app", marker({ opensWith: { app: { repo: "a/b" } } })],
    // Each mirrors a host refusal (site-main parseContentMarker, §4b.1) — offered, it
    // would be a dead click that never withdraws.
    ["an app carrying a revision (revision-in-app)", marker({ opensWith: { app: "github:a/b@main" }, kind: "board" })],
    ["an app carrying a commit pin (revision-in-app)", marker({ opensWith: { app: `github:a/b#${"a".repeat(40)}` }, kind: "board" })],
    ["an app-form entry key (entry-in-app)", marker({ opensWith: { app: "github:a/b", entry: "x.tsx" }, kind: "board" })],
    ["an app form with no kind (missing-kind)", marker({ opensWith: { app: "github:a/b" } })],
    ["whitespace task beside an app (the host does not trim: ambiguous-opens)", marker({ opensWith: { task: " ", app: "github:a/b" }, kind: "board" })],
    ["a task-form marker naming open-declared itself (a cycle)", marker({ opensWith: { task: "open-declared" }, kind: "board" })],
  ])("returns null for %s", (_why, text) => {
    expect(parseOpensWith(text as string)).toBeNull();
  });

  it("returns null for absent bytes (an unreadable / missing marker)", () => {
    expect(parseOpensWith(null)).toBeNull();
    expect(parseOpensWith(undefined)).toBeNull();
  });
});

describe("openWithLabel — the label comes from the marker's kind, never a task name", () => {
  it("uses the author's kind", () => {
    expect(openWithLabel("wiki")).toBe("Open as wiki");
    expect(openWithLabel("board")).toBe("Open as board");
    expect(openWithLabel("Design System")).toBe("Open as design system");
  });

  it("falls back to a generic label when there is no kind", () => {
    expect(openWithLabel(undefined)).toBe("Open with its app");
    expect(openWithLabel("")).toBe("Open with its app");
  });

  it.each([
    ["markup", "<img src=x onerror=alert(1)>"],
    ["a newline", "wiki\nSign in to continue"],
    ["a control character", "wiki"],
    ["a right-to-left override", "wiki‮gnp.exe"],
    ["an essay", "w".repeat(200)],
    ["a leading joiner", "-wiki"],
  ])(
    "refuses %s and shows the generic label instead of sanitizing it into shape",
    (_why, kind) => {
      expect(openWithLabel(kind)).toBe("Open with its app");
    },
  );
});

describe("opensWithOffer — absent affordance is the answer to every refusal", () => {
  it("offers a declared contract, labelled by the marker's kind", () => {
    const o = opensWithOffer(marker({ opensWith: { task: "open-wiki" }, kind: "wiki" }), policy);
    expect(o).toEqual({ task: "open-wiki", version: "1.0", label: "Open as wiki" });
  });

  it("offers a SECOND contract from the same code path, with no task name in it", () => {
    const o = opensWithOffer(
      marker({ opensWith: { task: "open-project" }, kind: "project" }),
      policy,
    );
    expect(o).toEqual({ task: "open-project", version: "1.0", label: "Open as project" });
  });

  it("offers a declared contract even when the marker names no usable kind", () => {
    const o = opensWithOffer(marker({ opensWith: { task: "open-wiki" } }), policy);
    expect(o).toMatchObject({ task: "open-wiki", label: "Open with its app" });
  });

  it("a marker naming a contract this app does not invoke → no affordance, not an error", () => {
    expect(
      opensWithOffer(marker({ opensWith: { task: "open-hologram" }, kind: "hologram" }), policy),
    ).toBeNull();
  });

  it("a folder with no marker → no affordance", () => {
    expect(opensWithOffer(null, policy)).toBeNull();
  });

  it("withdraws a contract the host has already refused this session", () => {
    const text = marker({ opensWith: { task: "open-wiki" }, kind: "wiki" });
    expect(opensWithOffer(text, policy)).not.toBeNull();
    expect(opensWithOffer(text, { ...policy, unavailable: new Set(["open-wiki"]) })).toBeNull();
  });

  it("cannot be talked into offering anything when the app declares nothing", () => {
    expect(opensWithOffer(marker({ opensWith: { task: "open-wiki" } }), { offerable: [] })).toBeNull();
  });
});

describe("opensInPlaceOffer — the into-stage twin (R3-159)", () => {
  const offer = { task: "open-project", version: "1.0", label: "Open as board" };

  it("offers a launch-declared contract with the FIXED product label", () => {
    expect(opensInPlaceOffer(offer, { launchable: ["open-project"] })).toEqual({
      task: "open-project",
      version: "1.0",
      label: "Open in place",
    });
  });

  it("never lets the marker's kind reach the in-place label", () => {
    // The for-result label is author text ("Open as board"); the in-place verb is
    // the product's. A hostile kind cannot ride it.
    const hostile = { task: "open-project", version: "1.0", label: "Open as <img>" };
    expect(opensInPlaceOffer(hostile, { launchable: ["open-project"] })?.label).toBe(
      "Open in place",
    );
  });

  it("offers nothing for a contract the app may only INVOKE, never launch", () => {
    const wiki = { task: "open-wiki", version: "1.0", label: "Open as wiki" };
    expect(opensInPlaceOffer(wiki, { launchable: ["open-project"] })).toBeNull();
  });

  it("offers nothing when there is no offer to twin", () => {
    expect(opensInPlaceOffer(null, { launchable: ["open-project"] })).toBeNull();
  });

  it("cannot be talked into launching anything when the app declares no launches", () => {
    expect(opensInPlaceOffer(offer, { launchable: [] })).toBeNull();
  });
});

describe("withdrawsOffer — a cancel is not a refusal", () => {
  it("keeps offering after the user closes the viewer", () => {
    expect(withdrawsOffer("cancelled")).toBe(false);
  });

  it("stops offering a contract that is structurally dead", () => {
    expect(withdrawsOffer("no-such-task")).toBe(true);
    expect(withdrawsOffer("not-declared")).toBe(true);
    expect(withdrawsOffer("task-version-mismatch")).toBe(true);
  });

  it("keeps offering after a one-off failure (transient, unknown, or a bad delegation)", () => {
    expect(withdrawsOffer("forbidden")).toBe(false);
    expect(withdrawsOffer("timeout")).toBe(false);
    expect(withdrawsOffer(undefined)).toBe(false);
  });
});

// R3-789 (BUNDLE_EMBEDDING §4b.1a) — one offer per declared view; the view's app never leaves.
describe("viewOffers — declared views", () => {
  const board = {
    name: "Roadmap board",
    opensWith: { app: "github:immediately-run/kanban-board", version: "1.0" },
    subtree: "/roadmap",
  };
  const wiki = (views: unknown) => marker({ opensWith: { task: "open-wiki" }, kind: "wiki", views });
  const declared = { offerable: ["open-wiki", "open-declared"] };

  it("offers each view by name through open-declared, and carries no app", () => {
    const o = viewOffers(wiki([board, { ...board, name: "Specs board", subtree: "/specs" }]), declared);
    expect(o).toEqual([
      { task: "open-declared", version: "1.0", label: "Open as Roadmap board", view: "Roadmap board" },
      { task: "open-declared", version: "1.0", label: "Open as Specs board", view: "Specs board" },
    ]);
    expect(JSON.stringify(o)).not.toContain("kanban-board");
  });

  it.each<[string, unknown]>([
    ["a revision in app", { ...board, opensWith: { app: "github:a/b@main" } }],
    ["a commit pin in app", { ...board, opensWith: { app: `github:a/b#${"a".repeat(40)}` } }],
    ["an entry key", { ...board, opensWith: { ...board.opensWith, entry: "x" } }],
    ["the task form", { ...board, opensWith: { task: "open-wiki" } }],
    ["a traversing subtree", { ...board, subtree: "/a/../b" }],
    ["a relative subtree", { ...board, subtree: "roadmap" }],
    ["a bidi name", { ...board, name: "a\u202eb" }],
    ["an empty name", { ...board, name: " " }],
    ["the root subtree (the host refuses '/')", { ...board, subtree: "/" }],
    ["an empty segment", { ...board, subtree: "/a//b" }],
    ["a name with a trailing tab (the host tests the untrimmed name)", { ...board, name: "Board\t" }],
  ])("mirrors the host and does not offer %s", (_why, v) => {
    expect(viewOffers(wiki([v]), declared)).toEqual([]);
  });

  it.each([0x00, 0x1f, 0x7f, 0x9f, 0x061c, 0x200e, 0x200f, 0x2028, 0x2029, 0x202a, 0x202e, 0x2066, 0x2069])(
    "refuses a name carrying code unit %i — the host's label class, every range edge",
    (c) => {
      expect(viewOffers(wiki([{ ...board, name: `Board${String.fromCharCode(c)}x` }]), declared)).toEqual([]);
    },
  );

  it.each([
    ["no opensWith", { kind: "wiki" }],
    ["task and app together (ambiguous-opens)", { opensWith: { task: "open-wiki", app: "github:a/b" }, kind: "wiki" }],
    ["an app-form marker with an entry", { opensWith: { app: "github:a/b", entry: "x" }, kind: "board" }],
    ["an app-form marker with a revision", { opensWith: { app: "github:a/b@main" }, kind: "board" }],
    ["an app-form marker with no kind", { opensWith: { app: "github:a/b" } }],
  ])("offers no views on a marker the host rejects as a whole: %s", (_why, top) => {
    expect(viewOffers(marker({ ...top, views: [board] }), declared)).toEqual([]);
  });

  it("accepts the subtrees the host accepts, including a trailing slash", () => {
    for (const subtree of ["/a", "/a/", "/a/b"]) {
      expect(viewOffers(wiki([{ ...board, subtree }]), declared)).toHaveLength(1);
    }
  });

  it("offers nothing when this app does not invoke open-declared, or it was withdrawn", () => {
    expect(viewOffers(wiki([board]), { offerable: ["open-wiki"] })).toEqual([]);
    expect(viewOffers(wiki([board]), { ...declared, unavailable: new Set(["open-declared"]) })).toEqual([]);
  });

  it("drops duplicates and caps at eight", () => {
    expect(viewOffers(wiki([board, board]), declared)).toHaveLength(1);
    const many = Array.from({ length: 12 }, (_, i) => ({ ...board, name: `v${i}` }));
    expect(viewOffers(wiki(many), declared)).toHaveLength(8);
  });
});

