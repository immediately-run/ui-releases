# CODE_SPEC_REFERENCES — file-explorer

Durable index of **non-trivial** code↔spec mappings a reader wouldn't rediscover
quickly. Trivial mappings live as inline `// <SPEC> §X` comments. Seeded by the
2026-06 code-verification pass (R3-124; plan `08-system-apps.md`).

## The write-intent indirection (the load-bearing one)

**Spec:** `FILE_EXPLORER_SPEC §4` (write actions) + `UI_AS_APPS_SPEC §4` (one app,
two slots / host-gated intents) + the host's copy-on-write layer.

**Mapping:** the app holds **no write port**. Create / rename / delete / upload /
move are *not* direct filesystem writes — the app **names a path** and the **host**
performs the copy-on-write write behind the `editor:write` intent. The COW/journal
lives in the host (core_concepts §2), never in this app. This is why the affordances
appear only on a **writable** mount (v1: the worktree) and never surface `EROFS` as
UX — the host adjudicates writability, the app reflects it.

- `src/lib-ui/sdk/actions.ts` (`makeSdkActions`) — the §4 `editor:open` /
  `editor:write` intent indirection. (The headless `src/lib-ui/FileExplorerView.tsx`
  only NAMES the path through injected `actions`; the SDK calls live in the adapter.)
- SDK calls `deleteEntry` / `renameEntry` / `uploadFile` / `createFile` (in
  `src/lib-ui/sdk/actions.ts`) are host-gated intents, not local writes.

## The `llm.chat@1` "Summarize" fork feature

**Spec:** `SERVICE_PROVIDERS_SPEC` (`llm:chat` capability) + the `llm.chat@1` service
slot. `ui:overlay` self-overlay is the richer follow-up (`SERVICE_PROVIDERS_SPEC §6.3`,
proposed) — today the modal is drawn in-iframe.

**Mapping:** `src/lib-ui/sdk/SummaryModal.tsx` calls `chat()` (needs only the
`llm:chat` capability the fork consented), streams the summary, and can save it next
to the source file (gated on a writable mount). The "provider-agnostic LLM" wording
means the **LLM service provider** (Anthropic/OpenAI), core_concepts §6 sense — not
the app-identity source host.

## Multi-root tree store

**Spec:** `FILE_EXPLORER_SPEC §2` (multiple mounts) — `src/lib-ui/treeStore.ts`
keeps one scope-headed tree per root (worktree + spaces + granted subtrees). It
reads entries through an injected `FsSource` (the SDK adapter's `sdkFsSource`), so
the store is pure of any concrete fs.

## The §5 upload button's selection-derived destination

**Spec:** `FILE_EXPLORER_SPEC §5` (amended 2026-09-14 — the picker path).

**Mapping:** the header Upload button in `src/lib-ui/FileExplorerView.tsx` reuses
the ONE hidden `<input type="file" multiple>` the §3 "Upload here…" menu item
opens (`uploadTargetRef` + `onUploadInput`), so both ingestion paths share the
upload write flow. The destination cannot be pointed at (a drop can), so it is
derived from the **selection** — which is why `TreeStore.select` now records the
row's KIND (`select(path, isDir)`, read via `getSelectedRow()`/`useSelectedRow`)
and why directory activation/navigation selects the entered folder in every
layout (`handleActivate`, `navigateCwd`, `navigateCols`). The dir/file/none →
dir/parent/repo-root resolution itself is the pure `uploadTargetDir`
(`src/lib-ui/explorer.ts`), shared with the drag-drop target computation; the
writable-root fallback (read-only selection → repo root; no writable scope → the
button hides) lives in the view beside `uploadRoot`.

---

## Recorded findings (code-verification pass, 2026-06)

> **CLOSED, verified on 2026-09-16 (R3-653).** The two SDK entries below — *DONE-BUT-DIVERGENT
> (`chat` not exported)* and *SDK-version skew* — are stale and are kept as the record rather
> than deleted; the third bullet, *Comment vocab fixes applied*, is untouched by this note.
> `package.json` now pins `@immediately-run/sdk` at `^0.43.0`, the installed
> `dist/index.d.ts:24` exports `chat`, and `npm run build` exits 0 on this PR's head — a
> branch whose only source change is the CI workflow (`git diff origin/main...HEAD --stat`
> is three files: `.github/workflows/ci.yml`, `package.json`'s `lint` script, and this file).
> So the `TS2305` failure is gone and the "newest among the bound apps at 0.11.0" skew
> reading is obsolete. Found while adding CI to this repo: the PR asserted the build passes
> on `main`, which is the direct negation of the first entry, so leaving it open would have
> been a claim this repo's own gate contradicts.

- **[CLOSED 2026-09-16]** ~~**DONE-BUT-DIVERGENT (CRIT, pre-existing on origin/main) —
  `chat` not exported by the pinned SDK.**~~ The shipped "Summarize" feature (`src/lib-ui/sdk/SummaryModal.tsx:2`
  `import { chat } from "@immediately-run/sdk"`, added in PR #9) does **not**
  type-check against the repo's own pinned `@immediately-run/sdk@0.11.0`, which has
  no `chat` export → `npm run build` fails with `TS2305` **on a clean origin/main
  checkout** (verified by stashing this pass's comment-only edits and rebuilding).
  This is a real Done-but-divergent gap: the feature shipped against a `chat`/
  `llm.chat@1` SDK surface newer than the pinned version (an instance of the
  SDK-version skew below). **Not introduced by this pass** — this pass made only
  comment-level edits (`kernel`→`host`, `PR #84 §6.3`→`SERVICE_PROVIDERS_SPEC §6.3`)
  and seeded this file; `npm run lint` and `npm test` (36 tests) are green. Fix is a
  coordinated SDK bump to a version exporting `chat` (out of scope for this
  verify/record pass — filed as a roadmap child of R3-124).
- **[CLOSED 2026-09-16]** ~~**SDK-version skew (record only, do not bump):**~~ file-explorer pins
  `@immediately-run/sdk` at **`0.11.0`** — the newest among the bound apps (others on
  `0.2.8` / `0.8.1`; agent-demo `^0.12.0`). Recorded as fleet maintenance debt; a
  coordinated bump is its own gated change.
- **Comment vocab fixes applied:** `kernel` → `host` (FileExplorer.tsx docstring);
  `PR #84 §6.3` → `SERVICE_PROVIDERS_SPEC §6.3` (SummaryModal.tsx — the unstable PR
  pointer cited the right § but the wrong source).
