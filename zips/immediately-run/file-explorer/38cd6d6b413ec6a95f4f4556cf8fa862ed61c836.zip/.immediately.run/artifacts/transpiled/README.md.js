var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      code: "code",
      h1: "h1",
      h2: "h2",
      li: "li",
      p: "p",
      strong: "strong",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "file-explorer",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "file-explorer"
      }), "file-explorer"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["A read-only ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "file explorer"
      }), " system app for ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "https://immediately.run",
        children: "immediately.run"
      }), "\n— the Phase 03 read-only pilot for the §3.2 app-as-chrome loader\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "UI_AS_APPS_SPEC"
      }), " §4 / §8.7, design brief 10)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["It shows a tree of a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "mount"
      }), "'s contents — a space or a granted subtree the user\nhas shared with this app — with each mount's grant scope made visible. It reads\nthe active mounts through the SDK (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "useMounts"
      }), ") and file entries from the sandbox\nfilesystem at the mount path. It explores only granted mounts, never the project\nyou're editing: a sandboxed app can only see what its mounts expose."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Loaded into a chrome region by the host; not meant to be run standalone."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "library-structure-file-explorer-library-extraction",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "library-structure-file-explorer-library-extraction"
      }), "Library structure (file-explorer-library extraction)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The filesystem-browsing UI is a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "headless library"
      }), " under ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/lib-ui/"
      }), " with the\nSDK wiring isolated in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/lib-ui/sdk/"
      }), ":"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "src/lib-ui/"
          })
        }), " — the headless core: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "FileExplorerView"
        }), " (the view), the\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "TreeStore"
        }), ", the four layouts, the path/metadata helpers, and the injected\ninterfaces (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ExplorerRoot"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "FsSource"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ExplorerActions"
        }), ") in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "types.ts"
        }), ". It\nimports ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "no"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "@immediately-run/sdk"
        }), ". Public surface: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/lib-ui/index.ts"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "src/lib-ui/sdk/"
          })
        }), " — the SDK adapter: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "useSdkRoots()"
        }), " (maps ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "useMounts()"
        }), " →\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ExplorerRoot[]"
        }), "), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "sdkFsSource"
        }), " (the ZenFS accessor), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "makeSdkActions()"
        }), " (the\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "editor:open"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "editor:write"
        }), " + drag-out + eject wiring), the \"Summarize\" feature,\nand ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "SdkFileExplorer"
        }), " — the fully-assembled shipped app. Barrel:\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/lib-ui/sdk/index.ts"
        }), ". ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/App.tsx"
        }), " renders ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<SdkFileExplorer/>"
        }), "."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Purity guard:"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "npm run check:core"
      }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "scripts/check-core-pure.mjs"
      }), ") fails if any\nfile under ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/lib-ui/"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "except"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/lib-ui/sdk/"
      }), " imports ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "@immediately-run/sdk"
      }), ".\nRun it alongside ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "npm run lint"
      }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "npm run build"
      }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "npm test"
      }), " in CI."]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/README.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiY29kZSIsImgxIiwiaDIiLCJsaSIsInAiLCJzdHJvbmciLCJ1bCIsIl9wcm92aWRlQ29tcG9uZW50cyIsImNvbXBvbmVudHMiLCJIZWFkaW5nQW5jaG9yIiwiX21pc3NpbmdNZHhSZWZlcmVuY2UiLCJqc3hzIiwiRnJhZ21lbnQiLCJjaGlsZHJlbiIsImlkIiwianN4IiwiaHJlZiIsIk1EWENvbnRlbnQiLCJ3cmFwcGVyIiwiTURYTGF5b3V0IiwiX2MiLCJjb21wb25lbnQiLCJwbGFjZSIsIkVycm9yIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUkVBRE1FLm1kIl0sInNvdXJjZXNDb250ZW50IjpbIi8qQGpzeFJ1bnRpbWUgYXV0b21hdGljKi9cbi8qQGpzeEltcG9ydFNvdXJjZSByZWFjdCovXG5pbXBvcnQge3VzZU1EWENvbXBvbmVudHMgYXMgX3Byb3ZpZGVDb21wb25lbnRzfSBmcm9tIFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGsvTURYUHJvdmlkZXJcIjtcbmZ1bmN0aW9uIF9jcmVhdGVNZHhDb250ZW50KHByb3BzKSB7XG4gIGNvbnN0IF9jb21wb25lbnRzID0ge1xuICAgIGE6IFwiYVwiLFxuICAgIGNvZGU6IFwiY29kZVwiLFxuICAgIGgxOiBcImgxXCIsXG4gICAgaDI6IFwiaDJcIixcbiAgICBsaTogXCJsaVwiLFxuICAgIHA6IFwicFwiLFxuICAgIHN0cm9uZzogXCJzdHJvbmdcIixcbiAgICB1bDogXCJ1bFwiLFxuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfSwge0hlYWRpbmdBbmNob3J9ID0gX2NvbXBvbmVudHM7XG4gIGlmICghSGVhZGluZ0FuY2hvcikgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJIZWFkaW5nQW5jaG9yXCIsIHRydWUpO1xuICByZXR1cm4gPD48X2NvbXBvbmVudHMuaDEgaWQ9XCJmaWxlLWV4cGxvcmVyXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJmaWxlLWV4cGxvcmVyXCIgLz57XCJmaWxlLWV4cGxvcmVyXCJ9PC9fY29tcG9uZW50cy5oMT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJBIHJlYWQtb25seSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImZpbGUgZXhwbG9yZXJcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgc3lzdGVtIGFwcCBmb3IgXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cImh0dHBzOi8vaW1tZWRpYXRlbHkucnVuXCI+e1wiaW1tZWRpYXRlbHkucnVuXCJ9PC9fY29tcG9uZW50cy5hPntcIlxcbuKAlCB0aGUgUGhhc2UgMDMgcmVhZC1vbmx5IHBpbG90IGZvciB0aGUgwqczLjIgYXBwLWFzLWNocm9tZSBsb2FkZXJcXG4oXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiVUlfQVNfQVBQU19TUEVDXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDCpzQgLyDCpzguNywgZGVzaWduIGJyaWVmIDEwKS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiSXQgc2hvd3MgYSB0cmVlIG9mIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJtb3VudFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIidzIGNvbnRlbnRzIOKAlCBhIHNwYWNlIG9yIGEgZ3JhbnRlZCBzdWJ0cmVlIHRoZSB1c2VyXFxuaGFzIHNoYXJlZCB3aXRoIHRoaXMgYXBwIOKAlCB3aXRoIGVhY2ggbW91bnQncyBncmFudCBzY29wZSBtYWRlIHZpc2libGUuIEl0IHJlYWRzXFxudGhlIGFjdGl2ZSBtb3VudHMgdGhyb3VnaCB0aGUgU0RLIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJ1c2VNb3VudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSBhbmQgZmlsZSBlbnRyaWVzIGZyb20gdGhlIHNhbmRib3hcXG5maWxlc3lzdGVtIGF0IHRoZSBtb3VudCBwYXRoLiBJdCBleHBsb3JlcyBvbmx5IGdyYW50ZWQgbW91bnRzLCBuZXZlciB0aGUgcHJvamVjdFxcbnlvdSdyZSBlZGl0aW5nOiBhIHNhbmRib3hlZCBhcHAgY2FuIG9ubHkgc2VlIHdoYXQgaXRzIG1vdW50cyBleHBvc2UuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkxvYWRlZCBpbnRvIGEgY2hyb21lIHJlZ2lvbiBieSB0aGUgaG9zdDsgbm90IG1lYW50IHRvIGJlIHJ1biBzdGFuZGFsb25lLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJsaWJyYXJ5LXN0cnVjdHVyZS1maWxlLWV4cGxvcmVyLWxpYnJhcnktZXh0cmFjdGlvblwiPjxIZWFkaW5nQW5jaG9yIGlkPVwibGlicmFyeS1zdHJ1Y3R1cmUtZmlsZS1leHBsb3Jlci1saWJyYXJ5LWV4dHJhY3Rpb25cIiAvPntcIkxpYnJhcnkgc3RydWN0dXJlIChmaWxlLWV4cGxvcmVyLWxpYnJhcnkgZXh0cmFjdGlvbilcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSBmaWxlc3lzdGVtLWJyb3dzaW5nIFVJIGlzIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJoZWFkbGVzcyBsaWJyYXJ5XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHVuZGVyIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9saWItdWkvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB3aXRoIHRoZVxcblNESyB3aXJpbmcgaXNvbGF0ZWQgaW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2xpYi11aS9zZGsvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPjxfY29tcG9uZW50cy5jb2RlPntcInNyYy9saWItdWkvXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgdGhlIGhlYWRsZXNzIGNvcmU6IFwifTxfY29tcG9uZW50cy5jb2RlPntcIkZpbGVFeHBsb3JlclZpZXdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICh0aGUgdmlldyksIHRoZVxcblwifTxfY29tcG9uZW50cy5jb2RlPntcIlRyZWVTdG9yZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIHRoZSBmb3VyIGxheW91dHMsIHRoZSBwYXRoL21ldGFkYXRhIGhlbHBlcnMsIGFuZCB0aGUgaW5qZWN0ZWRcXG5pbnRlcmZhY2VzIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJFeHBsb3JlclJvb3RcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJGc1NvdXJjZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkV4cGxvcmVyQWN0aW9uc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpIGluIFwifTxfY29tcG9uZW50cy5jb2RlPntcInR5cGVzLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi4gSXRcXG5pbXBvcnRzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibm9cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQGltbWVkaWF0ZWx5LXJ1bi9zZGtcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLiBQdWJsaWMgc3VyZmFjZTogXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2xpYi11aS9pbmRleC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz48X2NvbXBvbmVudHMuY29kZT57XCJzcmMvbGliLXVpL3Nkay9cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCB0aGUgU0RLIGFkYXB0ZXI6IFwifTxfY29tcG9uZW50cy5jb2RlPntcInVzZVNka1Jvb3RzKClcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChtYXBzIFwifTxfY29tcG9uZW50cy5jb2RlPntcInVzZU1vdW50cygpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDihpJcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJFeHBsb3JlclJvb3RbXVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzZGtGc1NvdXJjZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKHRoZSBaZW5GUyBhY2Nlc3NvciksIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1ha2VTZGtBY3Rpb25zKClcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICh0aGVcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJlZGl0b3I6b3BlblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZWRpdG9yOndyaXRlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiArIGRyYWctb3V0ICsgZWplY3Qgd2lyaW5nKSwgdGhlIFxcXCJTdW1tYXJpemVcXFwiIGZlYXR1cmUsXFxuYW5kIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlNka0ZpbGVFeHBsb3JlclwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIHRoZSBmdWxseS1hc3NlbWJsZWQgc2hpcHBlZCBhcHAuIEJhcnJlbDpcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvbGliLXVpL3Nkay9pbmRleC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIuIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9BcHAudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiByZW5kZXJzIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjxTZGtGaWxlRXhwbG9yZXIvPlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUHVyaXR5IGd1YXJkOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJucG0gcnVuIGNoZWNrOmNvcmVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJzY3JpcHRzL2NoZWNrLWNvcmUtcHVyZS5tanNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSBmYWlscyBpZiBhbnlcXG5maWxlIHVuZGVyIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9saWItdWkvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImV4Y2VwdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvbGliLXVpL3Nkay9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGltcG9ydHMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQGltbWVkaWF0ZWx5LXJ1bi9zZGtcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLlxcblJ1biBpdCBhbG9uZ3NpZGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibnBtIHJ1biBsaW50XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAvIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm5wbSBydW4gYnVpbGRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIC8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibnBtIHRlc3RcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGluIENJLlwifTwvX2NvbXBvbmVudHMucD48Lz47XG59XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNRFhDb250ZW50KHByb3BzID0ge30pIHtcbiAgY29uc3Qge3dyYXBwZXI6IE1EWExheW91dH0gPSB7XG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9O1xuICByZXR1cm4gTURYTGF5b3V0ID8gPE1EWExheW91dCB7Li4ucHJvcHN9PjxfY3JlYXRlTWR4Q29udGVudCB7Li4ucHJvcHN9IC8+PC9NRFhMYXlvdXQ+IDogX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpO1xufVxuZnVuY3Rpb24gX21pc3NpbmdNZHhSZWZlcmVuY2UoaWQsIGNvbXBvbmVudCwgcGxhY2UpIHtcbiAgdGhyb3cgbmV3IEVycm9yKFwiRXhwZWN0ZWQgXCIgKyAoY29tcG9uZW50ID8gXCJjb21wb25lbnRcIiA6IFwib2JqZWN0XCIpICsgXCIgYFwiICsgaWQgKyBcImAgdG8gYmUgZGVmaW5lZDogeW91IGxpa2VseSBmb3Jnb3QgdG8gaW1wb3J0LCBwYXNzLCBvciBwcm92aWRlIGl0LlwiICsgKHBsYWNlID8gXCJcXG5JdOKAmXMgcmVmZXJlbmNlZCBpbiB5b3VyIGNvZGUgYXQgYFwiICsgcGxhY2UgKyBcImAgaW4gYC9hcHAvUkVBRE1FLm1kYFwiIDogXCJcIikpO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFFQSxJQUFBQSxZQUFBLEdBQUFDLE9BQUE7QUFBd0YsSUFBQUMsV0FBQSxHQUFBRCxPQUFBO0FBRnhGO0FBQ0E7O0FBRUEsU0FBU0UsaUJBQWlCQSxDQUFDQyxLQUFLLEVBQUU7RUFDaEMsTUFBTUMsV0FBVyxHQUFHO01BQ2xCQyxDQUFDLEVBQUUsR0FBRztNQUNOQyxJQUFJLEVBQUUsTUFBTTtNQUNaQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxDQUFDLEVBQUUsR0FBRztNQUNOQyxNQUFNLEVBQUUsUUFBUTtNQUNoQkMsRUFBRSxFQUFFLElBQUk7TUFDUixHQUFHLElBQUFDLDZCQUFrQixFQUFDLENBQUM7TUFDdkIsR0FBR1YsS0FBSyxDQUFDVztJQUNYLENBQUM7SUFBRTtNQUFDQztJQUFhLENBQUMsR0FBR1gsV0FBVztFQUNoQyxJQUFJLENBQUNXLGFBQWEsRUFBRUMsb0JBQW9CLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQztFQUMvRCxvQkFBTyxJQUFBZixXQUFBLENBQUFnQixJQUFBLEVBQUFoQixXQUFBLENBQUFpQixRQUFBO0lBQUFDLFFBQUEsZ0JBQUUsSUFBQWxCLFdBQUEsQ0FBQWdCLElBQUEsRUFBQ2IsV0FBVyxDQUFDRyxFQUFFO01BQUNhLEVBQUUsRUFBQyxlQUFlO01BQUFELFFBQUEsZ0JBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBZSxDQUFFLENBQUMsRUFBQyxlQUFlO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBZ0IsSUFBQSxFQUFDYixXQUFXLENBQUNNLENBQUM7TUFBQVMsUUFBQSxHQUFFLGNBQWMsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDTyxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFlLENBQXFCLENBQUMsRUFBQyxrQkFBa0IsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDQyxDQUFDO1FBQUNpQixJQUFJLEVBQUMseUJBQXlCO1FBQUFILFFBQUEsRUFBRTtNQUFpQixDQUFnQixDQUFDLEVBQUMsdUVBQXVFLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBYSxRQUFBLEVBQUU7TUFBaUIsQ0FBbUIsQ0FBQyxFQUFDLCtCQUErQjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQWdCLElBQUEsRUFBQ2IsV0FBVyxDQUFDTSxDQUFDO01BQUFTLFFBQUEsR0FBRSx1QkFBdUIsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDTyxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFPLENBQXFCLENBQUMsRUFBQywyS0FBMkssZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDRSxJQUFJO1FBQUFhLFFBQUEsRUFBRTtNQUFXLENBQW1CLENBQUMsRUFBQyw2TEFBNkw7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNNLENBQUM7TUFBQVMsUUFBQSxFQUFFO0lBQTBFLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQWdCLElBQUEsRUFBQ2IsV0FBVyxDQUFDSSxFQUFFO01BQUNZLEVBQUUsRUFBQyxvREFBb0Q7TUFBQUQsUUFBQSxnQkFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFvRCxDQUFFLENBQUMsRUFBQyxzREFBc0Q7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFnQixJQUFBLEVBQUNiLFdBQVcsQ0FBQ00sQ0FBQztNQUFBUyxRQUFBLEdBQUUsa0NBQWtDLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBa0IsQ0FBcUIsQ0FBQyxFQUFDLFNBQVMsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDRSxJQUFJO1FBQUFhLFFBQUEsRUFBRTtNQUFhLENBQW1CLENBQUMsRUFBQyxvQ0FBb0MsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDRSxJQUFJO1FBQUFhLFFBQUEsRUFBRTtNQUFpQixDQUFtQixDQUFDLEVBQUMsR0FBRztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQWdCLElBQUEsRUFBQ2IsV0FBVyxDQUFDUSxFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQWdCLElBQUEsRUFBQ2IsV0FBVyxDQUFDSyxFQUFFO1FBQUFVLFFBQUEsZ0JBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sTUFBTTtVQUFBUSxRQUFBLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBYSxRQUFBLEVBQUU7VUFBYSxDQUFtQjtRQUFDLENBQW9CLENBQUMsRUFBQyx3QkFBd0IsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDRSxJQUFJO1VBQUFhLFFBQUEsRUFBRTtRQUFrQixDQUFtQixDQUFDLEVBQUMsb0JBQW9CLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBYSxRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsK0VBQStFLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBYSxRQUFBLEVBQUU7UUFBYyxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNFLElBQUk7VUFBQWEsUUFBQSxFQUFFO1FBQVUsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDRSxJQUFJO1VBQUFhLFFBQUEsRUFBRTtRQUFpQixDQUFtQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNFLElBQUk7VUFBQWEsUUFBQSxFQUFFO1FBQVUsQ0FBbUIsQ0FBQyxFQUFDLGdCQUFnQixlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNPLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQUksQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDRSxJQUFJO1VBQUFhLFFBQUEsRUFBRTtRQUFzQixDQUFtQixDQUFDLEVBQUMsb0JBQW9CLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBYSxRQUFBLEVBQUU7UUFBcUIsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFsQixXQUFBLENBQUFnQixJQUFBLEVBQUNiLFdBQVcsQ0FBQ0ssRUFBRTtRQUFBVSxRQUFBLGdCQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNPLE1BQU07VUFBQVEsUUFBQSxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNFLElBQUk7WUFBQWEsUUFBQSxFQUFFO1VBQWlCLENBQW1CO1FBQUMsQ0FBb0IsQ0FBQyxFQUFDLHNCQUFzQixlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNFLElBQUk7VUFBQWEsUUFBQSxFQUFFO1FBQWUsQ0FBbUIsQ0FBQyxFQUFDLFNBQVMsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDRSxJQUFJO1VBQUFhLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyxNQUFNLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBYSxRQUFBLEVBQUU7UUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDRSxJQUFJO1VBQUFhLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyx5QkFBeUIsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDRSxJQUFJO1VBQUFhLFFBQUEsRUFBRTtRQUFrQixDQUFtQixDQUFDLEVBQUMsU0FBUyxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNFLElBQUk7VUFBQWEsUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDRSxJQUFJO1VBQUFhLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUMsRUFBQywrREFBK0QsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDRSxJQUFJO1VBQUFhLFFBQUEsRUFBRTtRQUFpQixDQUFtQixDQUFDLEVBQUMsK0NBQStDLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBYSxRQUFBLEVBQUU7UUFBeUIsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDRSxJQUFJO1VBQUFhLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyxXQUFXLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBYSxRQUFBLEVBQUU7UUFBb0IsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQWdCLElBQUEsRUFBQ2IsV0FBVyxDQUFDTSxDQUFDO01BQUFTLFFBQUEsZ0JBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBZSxDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNFLElBQUk7UUFBQWEsUUFBQSxFQUFFO01BQW9CLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBYSxRQUFBLEVBQUU7TUFBNkIsQ0FBbUIsQ0FBQyxFQUFDLDZCQUE2QixlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNFLElBQUk7UUFBQWEsUUFBQSxFQUFFO01BQWEsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDTyxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFRLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBYSxRQUFBLEVBQUU7TUFBaUIsQ0FBbUIsQ0FBQyxFQUFDLFdBQVcsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDRSxJQUFJO1FBQUFhLFFBQUEsRUFBRTtNQUFzQixDQUFtQixDQUFDLEVBQUMsc0JBQXNCLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBYSxRQUFBLEVBQUU7TUFBYyxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNFLElBQUk7UUFBQWEsUUFBQSxFQUFFO01BQWUsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDRSxJQUFJO1FBQUFhLFFBQUEsRUFBRTtNQUFVLENBQW1CLENBQUMsRUFBQyxTQUFTO0lBQUEsQ0FBZ0IsQ0FBQztFQUFBLENBQUUsQ0FBQztBQUNwbUk7QUFDZSxTQUFTSSxVQUFVQSxDQUFDcEIsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFO0VBQzdDLE1BQU07SUFBQ3FCLE9BQU8sRUFBRUM7RUFBUyxDQUFDLEdBQUc7SUFDM0IsR0FBRyxJQUFBWiw2QkFBa0IsRUFBQyxDQUFDO0lBQ3ZCLEdBQUdWLEtBQUssQ0FBQ1c7RUFDWCxDQUFDO0VBQ0QsT0FBT1csU0FBUyxnQkFBRyxJQUFBeEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDSSxTQUFTO0lBQUEsR0FBS3RCLEtBQUs7SUFBQWdCLFFBQUEsZUFBRSxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDbkIsaUJBQWlCO01BQUEsR0FBS0M7SUFBSyxDQUFHO0VBQUMsQ0FBVyxDQUFDLEdBQUdELGlCQUFpQixDQUFDQyxLQUFLLENBQUM7QUFDbEg7QUFBQ3VCLEVBQUEsR0FOdUJILFVBQVU7QUFPbEMsU0FBU1Asb0JBQW9CQSxDQUFDSSxFQUFFLEVBQUVPLFNBQVMsRUFBRUMsS0FBSyxFQUFFO0VBQ2xELE1BQU0sSUFBSUMsS0FBSyxDQUFDLFdBQVcsSUFBSUYsU0FBUyxHQUFHLFdBQVcsR0FBRyxRQUFRLENBQUMsR0FBRyxJQUFJLEdBQUdQLEVBQUUsR0FBRyxvRUFBb0UsSUFBSVEsS0FBSyxHQUFHLHFDQUFxQyxHQUFHQSxLQUFLLEdBQUcsdUJBQXVCLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDalA7QUFBQyxJQUFBRixFQUFBO0FBQUFJLFlBQUEsQ0FBQUosRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}