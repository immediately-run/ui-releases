var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
var _react = require("react");
var _useOverlayFocusDismiss = require("./hooks/useOverlayFocusDismiss");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // App-local context menu for the file explorer (R3-80 / FILE_EXPLORER_SPEC §3).
//
// This is APP UI inside the explorer's own iframe — it is NOT host chrome and must
// not imitate the host's consent / seam / sign-in surfaces (UI_AS_APPS_SPEC §8
// anti-spoofing). It only ever lists actions the app can already perform on the
// target under its mount's grant; the caller passes a pre-filtered item list, so
// nothing here can offer an action that would come back forbidden/protected/EROFS.
//
// ARIA `menu`/`menuitem` with roving focus + arrow keys; dismiss on outside-click,
// Escape, or scroll. The dialog/menu contract (focus in, Escape, Tab-as-leave
// closing behind the move, focus returned to the invoker) is the shared
// useOverlayFocusDismiss hook — one spelling for this menu, the summarize modal
// and the move picker.
function ContextMenu({
  anchor,
  onClose
}) {
  _s();
  // A menu does not trap Tab (APG Menu Button): Tab is leave, and the menu
  // closes behind the browser's own focus move. Focus returns to the invoker
  // on every close path — including that one never yanking it back.
  const ref = (0, _useOverlayFocusDismiss.useOverlayFocusDismiss)(true, onClose, {
    trapTab: false,
    returnTo: anchor.invoker ?? null
  });
  const [pos, setPos] = (0, _react.useState)({
    x: anchor.x,
    y: anchor.y
  });

  // Clamp into the viewport once measured.
  (0, _react.useLayoutEffect)(() => {
    const el = ref.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const x = Math.min(anchor.x, window.innerWidth - r.width - 6);
    const y = Math.min(anchor.y, window.innerHeight - r.height - 6);
    setPos({
      x: Math.max(6, x),
      y: Math.max(6, y)
    });
    // Focus the first item for keyboard users.
    el.querySelector("[role=menuitem]")?.focus();
  }, [anchor, ref]);

  // Dismiss on outside pointer or scroll (Escape and Tab are the hook's).
  (0, _react.useEffect)(() => {
    const onDocPointer = e => {
      if (!ref.current?.contains(e.target)) onClose();
    };
    document.addEventListener("pointerdown", onDocPointer, true);
    window.addEventListener("scroll", onClose, true);
    return () => {
      document.removeEventListener("pointerdown", onDocPointer, true);
      window.removeEventListener("scroll", onClose, true);
    };
  }, [ref, onClose]);
  const onMenuKeyDown = e => {
    const items = Array.from(ref.current?.querySelectorAll("[role=menuitem]") ?? []);
    const i = items.indexOf(document.activeElement);
    if (e.key === "ArrowDown") {
      e.preventDefault();
      items[(i + 1) % items.length]?.focus();
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      items[(i - 1 + items.length) % items.length]?.focus();
    }
  };
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("ul", {
    ref: ref,
    role: "menu",
    "aria-label": "Actions",
    className: "ctxmenu",
    style: {
      left: pos.x,
      top: pos.y
    },
    onKeyDown: onMenuKeyDown,
    children: anchor.items.map(it => /*#__PURE__*/(0, _jsxRuntime.jsx)("li", {
      role: "none",
      children: /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
        type: "button",
        role: "menuitem",
        tabIndex: -1,
        className: "ctxmenu__item" + (it.danger ? " ctxmenu__item--danger" : ""),
        onClick: () => {
          onClose();
          it.onSelect();
        },
        children: [it.icon && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "ctxmenu__icon",
          children: it.icon
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "ctxmenu__label",
          children: it.label
        })]
      })
    }, it.key))
  });
}
_s(ContextMenu, "d8RUoIJPHf6iVvD+IuGammQzss4=", false, function () {
  return [_useOverlayFocusDismiss.useOverlayFocusDismiss];
});
_c = ContextMenu;
var _default = exports.default = ContextMenu;
var _c;
$RefreshReg$(_c, "ContextMenu");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3VzZU92ZXJsYXlGb2N1c0Rpc21pc3MiLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiQ29udGV4dE1lbnUiLCJhbmNob3IiLCJvbkNsb3NlIiwicmVmIiwidXNlT3ZlcmxheUZvY3VzRGlzbWlzcyIsInRyYXBUYWIiLCJyZXR1cm5UbyIsImludm9rZXIiLCJwb3MiLCJzZXRQb3MiLCJ1c2VTdGF0ZSIsIngiLCJ5IiwidXNlTGF5b3V0RWZmZWN0IiwiZWwiLCJjdXJyZW50IiwiciIsImdldEJvdW5kaW5nQ2xpZW50UmVjdCIsIk1hdGgiLCJtaW4iLCJ3aW5kb3ciLCJpbm5lcldpZHRoIiwid2lkdGgiLCJpbm5lckhlaWdodCIsImhlaWdodCIsIm1heCIsInF1ZXJ5U2VsZWN0b3IiLCJmb2N1cyIsInVzZUVmZmVjdCIsIm9uRG9jUG9pbnRlciIsImUiLCJjb250YWlucyIsInRhcmdldCIsImRvY3VtZW50IiwiYWRkRXZlbnRMaXN0ZW5lciIsInJlbW92ZUV2ZW50TGlzdGVuZXIiLCJvbk1lbnVLZXlEb3duIiwiaXRlbXMiLCJBcnJheSIsImZyb20iLCJxdWVyeVNlbGVjdG9yQWxsIiwiaSIsImluZGV4T2YiLCJhY3RpdmVFbGVtZW50Iiwia2V5IiwicHJldmVudERlZmF1bHQiLCJsZW5ndGgiLCJqc3giLCJyb2xlIiwiY2xhc3NOYW1lIiwic3R5bGUiLCJsZWZ0IiwidG9wIiwib25LZXlEb3duIiwiY2hpbGRyZW4iLCJtYXAiLCJpdCIsImpzeHMiLCJ0eXBlIiwidGFiSW5kZXgiLCJkYW5nZXIiLCJvbkNsaWNrIiwib25TZWxlY3QiLCJpY29uIiwibGFiZWwiLCJfYyIsIl9kZWZhdWx0IiwiZXhwb3J0cyIsImRlZmF1bHQiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJDb250ZXh0TWVudS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gQXBwLWxvY2FsIGNvbnRleHQgbWVudSBmb3IgdGhlIGZpbGUgZXhwbG9yZXIgKFIzLTgwIC8gRklMRV9FWFBMT1JFUl9TUEVDIMKnMykuXG4vL1xuLy8gVGhpcyBpcyBBUFAgVUkgaW5zaWRlIHRoZSBleHBsb3JlcidzIG93biBpZnJhbWUg4oCUIGl0IGlzIE5PVCBob3N0IGNocm9tZSBhbmQgbXVzdFxuLy8gbm90IGltaXRhdGUgdGhlIGhvc3QncyBjb25zZW50IC8gc2VhbSAvIHNpZ24taW4gc3VyZmFjZXMgKFVJX0FTX0FQUFNfU1BFQyDCpzhcbi8vIGFudGktc3Bvb2ZpbmcpLiBJdCBvbmx5IGV2ZXIgbGlzdHMgYWN0aW9ucyB0aGUgYXBwIGNhbiBhbHJlYWR5IHBlcmZvcm0gb24gdGhlXG4vLyB0YXJnZXQgdW5kZXIgaXRzIG1vdW50J3MgZ3JhbnQ7IHRoZSBjYWxsZXIgcGFzc2VzIGEgcHJlLWZpbHRlcmVkIGl0ZW0gbGlzdCwgc29cbi8vIG5vdGhpbmcgaGVyZSBjYW4gb2ZmZXIgYW4gYWN0aW9uIHRoYXQgd291bGQgY29tZSBiYWNrIGZvcmJpZGRlbi9wcm90ZWN0ZWQvRVJPRlMuXG4vL1xuLy8gQVJJQSBgbWVudWAvYG1lbnVpdGVtYCB3aXRoIHJvdmluZyBmb2N1cyArIGFycm93IGtleXM7IGRpc21pc3Mgb24gb3V0c2lkZS1jbGljayxcbi8vIEVzY2FwZSwgb3Igc2Nyb2xsLiBUaGUgZGlhbG9nL21lbnUgY29udHJhY3QgKGZvY3VzIGluLCBFc2NhcGUsIFRhYi1hcy1sZWF2ZVxuLy8gY2xvc2luZyBiZWhpbmQgdGhlIG1vdmUsIGZvY3VzIHJldHVybmVkIHRvIHRoZSBpbnZva2VyKSBpcyB0aGUgc2hhcmVkXG4vLyB1c2VPdmVybGF5Rm9jdXNEaXNtaXNzIGhvb2sg4oCUIG9uZSBzcGVsbGluZyBmb3IgdGhpcyBtZW51LCB0aGUgc3VtbWFyaXplIG1vZGFsXG4vLyBhbmQgdGhlIG1vdmUgcGlja2VyLlxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VMYXlvdXRFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyB1c2VPdmVybGF5Rm9jdXNEaXNtaXNzIH0gZnJvbSBcIi4vaG9va3MvdXNlT3ZlcmxheUZvY3VzRGlzbWlzc1wiO1xuaW1wb3J0IHR5cGUgeyBNZW51QW5jaG9yIH0gZnJvbSBcIi4vdHlwZXNcIjtcblxuZnVuY3Rpb24gQ29udGV4dE1lbnUoeyBhbmNob3IsIG9uQ2xvc2UgfTogeyBhbmNob3I6IE1lbnVBbmNob3I7IG9uQ2xvc2U6ICgpID0+IHZvaWQgfSkge1xuICAvLyBBIG1lbnUgZG9lcyBub3QgdHJhcCBUYWIgKEFQRyBNZW51IEJ1dHRvbik6IFRhYiBpcyBsZWF2ZSwgYW5kIHRoZSBtZW51XG4gIC8vIGNsb3NlcyBiZWhpbmQgdGhlIGJyb3dzZXIncyBvd24gZm9jdXMgbW92ZS4gRm9jdXMgcmV0dXJucyB0byB0aGUgaW52b2tlclxuICAvLyBvbiBldmVyeSBjbG9zZSBwYXRoIOKAlCBpbmNsdWRpbmcgdGhhdCBvbmUgbmV2ZXIgeWFua2luZyBpdCBiYWNrLlxuICBjb25zdCByZWYgPSB1c2VPdmVybGF5Rm9jdXNEaXNtaXNzPEhUTUxVTGlzdEVsZW1lbnQ+KHRydWUsIG9uQ2xvc2UsIHtcbiAgICB0cmFwVGFiOiBmYWxzZSxcbiAgICByZXR1cm5UbzogYW5jaG9yLmludm9rZXIgPz8gbnVsbCxcbiAgfSk7XG4gIGNvbnN0IFtwb3MsIHNldFBvc10gPSB1c2VTdGF0ZSh7IHg6IGFuY2hvci54LCB5OiBhbmNob3IueSB9KTtcblxuICAvLyBDbGFtcCBpbnRvIHRoZSB2aWV3cG9ydCBvbmNlIG1lYXN1cmVkLlxuICB1c2VMYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IGVsID0gcmVmLmN1cnJlbnQ7XG4gICAgaWYgKCFlbCkgcmV0dXJuO1xuICAgIGNvbnN0IHIgPSBlbC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICBjb25zdCB4ID0gTWF0aC5taW4oYW5jaG9yLngsIHdpbmRvdy5pbm5lcldpZHRoIC0gci53aWR0aCAtIDYpO1xuICAgIGNvbnN0IHkgPSBNYXRoLm1pbihhbmNob3IueSwgd2luZG93LmlubmVySGVpZ2h0IC0gci5oZWlnaHQgLSA2KTtcbiAgICBzZXRQb3MoeyB4OiBNYXRoLm1heCg2LCB4KSwgeTogTWF0aC5tYXgoNiwgeSkgfSk7XG4gICAgLy8gRm9jdXMgdGhlIGZpcnN0IGl0ZW0gZm9yIGtleWJvYXJkIHVzZXJzLlxuICAgIGVsLnF1ZXJ5U2VsZWN0b3I8SFRNTEJ1dHRvbkVsZW1lbnQ+KFwiW3JvbGU9bWVudWl0ZW1dXCIpPy5mb2N1cygpO1xuICB9LCBbYW5jaG9yLCByZWZdKTtcblxuICAvLyBEaXNtaXNzIG9uIG91dHNpZGUgcG9pbnRlciBvciBzY3JvbGwgKEVzY2FwZSBhbmQgVGFiIGFyZSB0aGUgaG9vaydzKS5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBvbkRvY1BvaW50ZXIgPSAoZTogUG9pbnRlckV2ZW50KSA9PiB7XG4gICAgICBpZiAoIXJlZi5jdXJyZW50Py5jb250YWlucyhlLnRhcmdldCBhcyBOb2RlKSkgb25DbG9zZSgpO1xuICAgIH07XG4gICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcInBvaW50ZXJkb3duXCIsIG9uRG9jUG9pbnRlciwgdHJ1ZSk7XG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJzY3JvbGxcIiwgb25DbG9zZSwgdHJ1ZSk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJwb2ludGVyZG93blwiLCBvbkRvY1BvaW50ZXIsIHRydWUpO1xuICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJzY3JvbGxcIiwgb25DbG9zZSwgdHJ1ZSk7XG4gICAgfTtcbiAgfSwgW3JlZiwgb25DbG9zZV0pO1xuXG4gIGNvbnN0IG9uTWVudUtleURvd24gPSAoZTogUmVhY3QuS2V5Ym9hcmRFdmVudDxIVE1MVUxpc3RFbGVtZW50PikgPT4ge1xuICAgIGNvbnN0IGl0ZW1zID0gQXJyYXkuZnJvbShyZWYuY3VycmVudD8ucXVlcnlTZWxlY3RvckFsbDxIVE1MQnV0dG9uRWxlbWVudD4oXCJbcm9sZT1tZW51aXRlbV1cIikgPz8gW10pO1xuICAgIGNvbnN0IGkgPSBpdGVtcy5pbmRleE9mKGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQgYXMgSFRNTEJ1dHRvbkVsZW1lbnQpO1xuICAgIGlmIChlLmtleSA9PT0gXCJBcnJvd0Rvd25cIikge1xuICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgaXRlbXNbKGkgKyAxKSAlIGl0ZW1zLmxlbmd0aF0/LmZvY3VzKCk7XG4gICAgfSBlbHNlIGlmIChlLmtleSA9PT0gXCJBcnJvd1VwXCIpIHtcbiAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgIGl0ZW1zWyhpIC0gMSArIGl0ZW1zLmxlbmd0aCkgJSBpdGVtcy5sZW5ndGhdPy5mb2N1cygpO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDx1bFxuICAgICAgcmVmPXtyZWZ9XG4gICAgICByb2xlPVwibWVudVwiXG4gICAgICBhcmlhLWxhYmVsPVwiQWN0aW9uc1wiXG4gICAgICBjbGFzc05hbWU9XCJjdHhtZW51XCJcbiAgICAgIHN0eWxlPXt7IGxlZnQ6IHBvcy54LCB0b3A6IHBvcy55IH19XG4gICAgICBvbktleURvd249e29uTWVudUtleURvd259XG4gICAgPlxuICAgICAge2FuY2hvci5pdGVtcy5tYXAoKGl0KSA9PiAoXG4gICAgICAgIDxsaSBrZXk9e2l0LmtleX0gcm9sZT1cIm5vbmVcIj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgIHJvbGU9XCJtZW51aXRlbVwiXG4gICAgICAgICAgICB0YWJJbmRleD17LTF9XG4gICAgICAgICAgICBjbGFzc05hbWU9e1wiY3R4bWVudV9faXRlbVwiICsgKGl0LmRhbmdlciA/IFwiIGN0eG1lbnVfX2l0ZW0tLWRhbmdlclwiIDogXCJcIil9XG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgIG9uQ2xvc2UoKTtcbiAgICAgICAgICAgICAgaXQub25TZWxlY3QoKTtcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgPlxuICAgICAgICAgICAge2l0Lmljb24gJiYgPHNwYW4gY2xhc3NOYW1lPVwiY3R4bWVudV9faWNvblwiPntpdC5pY29ufTwvc3Bhbj59XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjdHhtZW51X19sYWJlbFwiPntpdC5sYWJlbH08L3NwYW4+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvbGk+XG4gICAgICApKX1cbiAgICA8L3VsPlxuICApO1xufVxuXG5leHBvcnQgZGVmYXVsdCBDb250ZXh0TWVudTtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFhQSxJQUFBQSxNQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyx1QkFBQSxHQUFBRCxPQUFBO0FBQXdFLElBQUFFLFdBQUEsR0FBQUYsT0FBQTtBQUFBLElBQUFHLEVBQUEsR0FBQUMsWUFBQSxJQWR4RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUtBLFNBQVNDLFdBQVdBLENBQUM7RUFBRUMsTUFBTTtFQUFFQztBQUFxRCxDQUFDLEVBQUU7RUFBQUosRUFBQTtFQUNyRjtFQUNBO0VBQ0E7RUFDQSxNQUFNSyxHQUFHLEdBQUcsSUFBQUMsOENBQXNCLEVBQW1CLElBQUksRUFBRUYsT0FBTyxFQUFFO0lBQ2xFRyxPQUFPLEVBQUUsS0FBSztJQUNkQyxRQUFRLEVBQUVMLE1BQU0sQ0FBQ00sT0FBTyxJQUFJO0VBQzlCLENBQUMsQ0FBQztFQUNGLE1BQU0sQ0FBQ0MsR0FBRyxFQUFFQyxNQUFNLENBQUMsR0FBRyxJQUFBQyxlQUFRLEVBQUM7SUFBRUMsQ0FBQyxFQUFFVixNQUFNLENBQUNVLENBQUM7SUFBRUMsQ0FBQyxFQUFFWCxNQUFNLENBQUNXO0VBQUUsQ0FBQyxDQUFDOztFQUU1RDtFQUNBLElBQUFDLHNCQUFlLEVBQUMsTUFBTTtJQUNwQixNQUFNQyxFQUFFLEdBQUdYLEdBQUcsQ0FBQ1ksT0FBTztJQUN0QixJQUFJLENBQUNELEVBQUUsRUFBRTtJQUNULE1BQU1FLENBQUMsR0FBR0YsRUFBRSxDQUFDRyxxQkFBcUIsQ0FBQyxDQUFDO0lBQ3BDLE1BQU1OLENBQUMsR0FBR08sSUFBSSxDQUFDQyxHQUFHLENBQUNsQixNQUFNLENBQUNVLENBQUMsRUFBRVMsTUFBTSxDQUFDQyxVQUFVLEdBQUdMLENBQUMsQ0FBQ00sS0FBSyxHQUFHLENBQUMsQ0FBQztJQUM3RCxNQUFNVixDQUFDLEdBQUdNLElBQUksQ0FBQ0MsR0FBRyxDQUFDbEIsTUFBTSxDQUFDVyxDQUFDLEVBQUVRLE1BQU0sQ0FBQ0csV0FBVyxHQUFHUCxDQUFDLENBQUNRLE1BQU0sR0FBRyxDQUFDLENBQUM7SUFDL0RmLE1BQU0sQ0FBQztNQUFFRSxDQUFDLEVBQUVPLElBQUksQ0FBQ08sR0FBRyxDQUFDLENBQUMsRUFBRWQsQ0FBQyxDQUFDO01BQUVDLENBQUMsRUFBRU0sSUFBSSxDQUFDTyxHQUFHLENBQUMsQ0FBQyxFQUFFYixDQUFDO0lBQUUsQ0FBQyxDQUFDO0lBQ2hEO0lBQ0FFLEVBQUUsQ0FBQ1ksYUFBYSxDQUFvQixpQkFBaUIsQ0FBQyxFQUFFQyxLQUFLLENBQUMsQ0FBQztFQUNqRSxDQUFDLEVBQUUsQ0FBQzFCLE1BQU0sRUFBRUUsR0FBRyxDQUFDLENBQUM7O0VBRWpCO0VBQ0EsSUFBQXlCLGdCQUFTLEVBQUMsTUFBTTtJQUNkLE1BQU1DLFlBQVksR0FBSUMsQ0FBZSxJQUFLO01BQ3hDLElBQUksQ0FBQzNCLEdBQUcsQ0FBQ1ksT0FBTyxFQUFFZ0IsUUFBUSxDQUFDRCxDQUFDLENBQUNFLE1BQWMsQ0FBQyxFQUFFOUIsT0FBTyxDQUFDLENBQUM7SUFDekQsQ0FBQztJQUNEK0IsUUFBUSxDQUFDQyxnQkFBZ0IsQ0FBQyxhQUFhLEVBQUVMLFlBQVksRUFBRSxJQUFJLENBQUM7SUFDNURULE1BQU0sQ0FBQ2MsZ0JBQWdCLENBQUMsUUFBUSxFQUFFaEMsT0FBTyxFQUFFLElBQUksQ0FBQztJQUNoRCxPQUFPLE1BQU07TUFDWCtCLFFBQVEsQ0FBQ0UsbUJBQW1CLENBQUMsYUFBYSxFQUFFTixZQUFZLEVBQUUsSUFBSSxDQUFDO01BQy9EVCxNQUFNLENBQUNlLG1CQUFtQixDQUFDLFFBQVEsRUFBRWpDLE9BQU8sRUFBRSxJQUFJLENBQUM7SUFDckQsQ0FBQztFQUNILENBQUMsRUFBRSxDQUFDQyxHQUFHLEVBQUVELE9BQU8sQ0FBQyxDQUFDO0VBRWxCLE1BQU1rQyxhQUFhLEdBQUlOLENBQXdDLElBQUs7SUFDbEUsTUFBTU8sS0FBSyxHQUFHQyxLQUFLLENBQUNDLElBQUksQ0FBQ3BDLEdBQUcsQ0FBQ1ksT0FBTyxFQUFFeUIsZ0JBQWdCLENBQW9CLGlCQUFpQixDQUFDLElBQUksRUFBRSxDQUFDO0lBQ25HLE1BQU1DLENBQUMsR0FBR0osS0FBSyxDQUFDSyxPQUFPLENBQUNULFFBQVEsQ0FBQ1UsYUFBa0MsQ0FBQztJQUNwRSxJQUFJYixDQUFDLENBQUNjLEdBQUcsS0FBSyxXQUFXLEVBQUU7TUFDekJkLENBQUMsQ0FBQ2UsY0FBYyxDQUFDLENBQUM7TUFDbEJSLEtBQUssQ0FBQyxDQUFDSSxDQUFDLEdBQUcsQ0FBQyxJQUFJSixLQUFLLENBQUNTLE1BQU0sQ0FBQyxFQUFFbkIsS0FBSyxDQUFDLENBQUM7SUFDeEMsQ0FBQyxNQUFNLElBQUlHLENBQUMsQ0FBQ2MsR0FBRyxLQUFLLFNBQVMsRUFBRTtNQUM5QmQsQ0FBQyxDQUFDZSxjQUFjLENBQUMsQ0FBQztNQUNsQlIsS0FBSyxDQUFDLENBQUNJLENBQUMsR0FBRyxDQUFDLEdBQUdKLEtBQUssQ0FBQ1MsTUFBTSxJQUFJVCxLQUFLLENBQUNTLE1BQU0sQ0FBQyxFQUFFbkIsS0FBSyxDQUFDLENBQUM7SUFDdkQ7RUFDRixDQUFDO0VBRUQsb0JBQ0UsSUFBQTlCLFdBQUEsQ0FBQWtELEdBQUE7SUFDRTVDLEdBQUcsRUFBRUEsR0FBSTtJQUNUNkMsSUFBSSxFQUFDLE1BQU07SUFDWCxjQUFXLFNBQVM7SUFDcEJDLFNBQVMsRUFBQyxTQUFTO0lBQ25CQyxLQUFLLEVBQUU7TUFBRUMsSUFBSSxFQUFFM0MsR0FBRyxDQUFDRyxDQUFDO01BQUV5QyxHQUFHLEVBQUU1QyxHQUFHLENBQUNJO0lBQUUsQ0FBRTtJQUNuQ3lDLFNBQVMsRUFBRWpCLGFBQWM7SUFBQWtCLFFBQUEsRUFFeEJyRCxNQUFNLENBQUNvQyxLQUFLLENBQUNrQixHQUFHLENBQUVDLEVBQUUsaUJBQ25CLElBQUEzRCxXQUFBLENBQUFrRCxHQUFBO01BQWlCQyxJQUFJLEVBQUMsTUFBTTtNQUFBTSxRQUFBLGVBQzFCLElBQUF6RCxXQUFBLENBQUE0RCxJQUFBO1FBQ0VDLElBQUksRUFBQyxRQUFRO1FBQ2JWLElBQUksRUFBQyxVQUFVO1FBQ2ZXLFFBQVEsRUFBRSxDQUFDLENBQUU7UUFDYlYsU0FBUyxFQUFFLGVBQWUsSUFBSU8sRUFBRSxDQUFDSSxNQUFNLEdBQUcsd0JBQXdCLEdBQUcsRUFBRSxDQUFFO1FBQ3pFQyxPQUFPLEVBQUVBLENBQUEsS0FBTTtVQUNiM0QsT0FBTyxDQUFDLENBQUM7VUFDVHNELEVBQUUsQ0FBQ00sUUFBUSxDQUFDLENBQUM7UUFDZixDQUFFO1FBQUFSLFFBQUEsR0FFREUsRUFBRSxDQUFDTyxJQUFJLGlCQUFJLElBQUFsRSxXQUFBLENBQUFrRCxHQUFBO1VBQU1FLFNBQVMsRUFBQyxlQUFlO1VBQUFLLFFBQUEsRUFBRUUsRUFBRSxDQUFDTztRQUFJLENBQU8sQ0FBQyxlQUM1RCxJQUFBbEUsV0FBQSxDQUFBa0QsR0FBQTtVQUFNRSxTQUFTLEVBQUMsZ0JBQWdCO1VBQUFLLFFBQUEsRUFBRUUsRUFBRSxDQUFDUTtRQUFLLENBQU8sQ0FBQztNQUFBLENBQzVDO0lBQUMsR0FiRlIsRUFBRSxDQUFDWixHQWNSLENBQ0w7RUFBQyxDQUNBLENBQUM7QUFFVDtBQUFDOUMsRUFBQSxDQTNFUUUsV0FBVztFQUFBLFFBSU5JLDhDQUFzQjtBQUFBO0FBQUE2RCxFQUFBLEdBSjNCakUsV0FBVztBQUFBLElBQUFrRSxRQUFBLEdBQUFDLE9BQUEsQ0FBQUMsT0FBQSxHQTZFTHBFLFdBQVc7QUFBQSxJQUFBaUUsRUFBQTtBQUFBSSxZQUFBLENBQUFKLEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}