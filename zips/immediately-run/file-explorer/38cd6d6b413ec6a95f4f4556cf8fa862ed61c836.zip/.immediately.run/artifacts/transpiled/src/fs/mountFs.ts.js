"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "fsAvailable", {
  enumerable: true,
  get: function () {
    return _fs.fsAvailable;
  }
});
exports.readFile = readFile;
exports.readdir = readdir;
var _fs = require("@immediately-run/sdk/fs");
// Read a mount's directory entries from the sandbox filesystem, over the SDK's typed
// sandbox-fs accessor.
//
// The ZenFS resolution order (globalThis.__sandpackSharedFs, with the bundler-layer
// fallback) used to be hand-rolled here AND in the editor app, kept in sync by hand. It
// now lives ONCE in `@immediately-run/sdk/fs` (`sandboxFs`/`fsAvailable`,
// SDK_FS_SURFACE_SPEC). This file keeps only the file-explorer's domain helpers — a
// directories-first `readdir` and a raw `readFile` — over absolute mount paths
// (`/spaces/{id}`, `/mnt/{hash}`), so it uses the SDK's `sandboxFs` escape hatch rather
// than a single mount-anchored `openFs`.

/** Is the sandbox fs reachable at all? (false in local dev / before boot.) Re-exported
 *  from the SDK so existing imports of `mountFs` are unchanged. */

/* eslint-disable @typescript-eslint/no-explicit-any */
const joinPath = (dir, name) => `${dir.replace(/\/+$/, "")}/${name}`;

/** List `path`'s immediate entries, directories first then files, A→Z. */
async function readdir(path) {
  const fs = (0, _fs.sandboxFs)();
  if (!fs) throw new Error("sandbox filesystem unavailable");
  const p = fs.promises ?? fs;
  let raw;
  try {
    raw = await p.readdir(path, {
      withFileTypes: true
    });
  } catch {
    raw = await p.readdir(path);
  }
  const entries = [];
  for (const item of raw) {
    if (typeof item === "string") {
      // string[] shape — stat each to learn directory-ness.
      let isDir = false;
      try {
        const st = await p.stat(joinPath(path, item));
        isDir = typeof st?.isDirectory === "function" ? st.isDirectory() : !!st?.isDirectory;
      } catch {
        /* unreadable entry — treat as a file */
      }
      entries.push({
        name: item,
        isDir
      });
    } else {
      // Dirent shape.
      const isDir = typeof item?.isDirectory === "function" ? item.isDirectory() : !!item?.isDirectory;
      entries.push({
        name: String(item?.name ?? item),
        isDir
      });
    }
  }
  return entries.sort((a, b) => a.isDir === b.isDir ? a.name.localeCompare(b.name) : a.isDir ? -1 : 1);
}

/**
 * Read a file's raw bytes from a mount (R3-83 drag-out: the source inlines a small
 * file's content so the host can relay it to the previewed app — the source can only
 * ever hand over bytes it can already read). Throws if the sandbox fs is unavailable
 * or the read fails; callers fall back to a reference-only drag.
 */
async function readFile(path) {
  const fs = (0, _fs.sandboxFs)();
  if (!fs) throw new Error("sandbox filesystem unavailable");
  const p = fs.promises ?? fs;
  const data = await p.readFile(path);
  return data instanceof Uint8Array ? data : new Uint8Array(data);
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfZnMiLCJyZXF1aXJlIiwiam9pblBhdGgiLCJkaXIiLCJuYW1lIiwicmVwbGFjZSIsInJlYWRkaXIiLCJwYXRoIiwiZnMiLCJzYW5kYm94RnMiLCJFcnJvciIsInAiLCJwcm9taXNlcyIsInJhdyIsIndpdGhGaWxlVHlwZXMiLCJlbnRyaWVzIiwiaXRlbSIsImlzRGlyIiwic3QiLCJzdGF0IiwiaXNEaXJlY3RvcnkiLCJwdXNoIiwiU3RyaW5nIiwic29ydCIsImEiLCJiIiwibG9jYWxlQ29tcGFyZSIsInJlYWRGaWxlIiwiZGF0YSIsIlVpbnQ4QXJyYXkiXSwic291cmNlcyI6WyJtb3VudEZzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIFJlYWQgYSBtb3VudCdzIGRpcmVjdG9yeSBlbnRyaWVzIGZyb20gdGhlIHNhbmRib3ggZmlsZXN5c3RlbSwgb3ZlciB0aGUgU0RLJ3MgdHlwZWRcbi8vIHNhbmRib3gtZnMgYWNjZXNzb3IuXG4vL1xuLy8gVGhlIFplbkZTIHJlc29sdXRpb24gb3JkZXIgKGdsb2JhbFRoaXMuX19zYW5kcGFja1NoYXJlZEZzLCB3aXRoIHRoZSBidW5kbGVyLWxheWVyXG4vLyBmYWxsYmFjaykgdXNlZCB0byBiZSBoYW5kLXJvbGxlZCBoZXJlIEFORCBpbiB0aGUgZWRpdG9yIGFwcCwga2VwdCBpbiBzeW5jIGJ5IGhhbmQuIEl0XG4vLyBub3cgbGl2ZXMgT05DRSBpbiBgQGltbWVkaWF0ZWx5LXJ1bi9zZGsvZnNgIChgc2FuZGJveEZzYC9gZnNBdmFpbGFibGVgLFxuLy8gU0RLX0ZTX1NVUkZBQ0VfU1BFQykuIFRoaXMgZmlsZSBrZWVwcyBvbmx5IHRoZSBmaWxlLWV4cGxvcmVyJ3MgZG9tYWluIGhlbHBlcnMg4oCUIGFcbi8vIGRpcmVjdG9yaWVzLWZpcnN0IGByZWFkZGlyYCBhbmQgYSByYXcgYHJlYWRGaWxlYCDigJQgb3ZlciBhYnNvbHV0ZSBtb3VudCBwYXRoc1xuLy8gKGAvc3BhY2VzL3tpZH1gLCBgL21udC97aGFzaH1gKSwgc28gaXQgdXNlcyB0aGUgU0RLJ3MgYHNhbmRib3hGc2AgZXNjYXBlIGhhdGNoIHJhdGhlclxuLy8gdGhhbiBhIHNpbmdsZSBtb3VudC1hbmNob3JlZCBgb3BlbkZzYC5cbmltcG9ydCB7IHNhbmRib3hGcywgZnNBdmFpbGFibGUgfSBmcm9tICdAaW1tZWRpYXRlbHktcnVuL3Nkay9mcyc7XG5cbi8qKiBJcyB0aGUgc2FuZGJveCBmcyByZWFjaGFibGUgYXQgYWxsPyAoZmFsc2UgaW4gbG9jYWwgZGV2IC8gYmVmb3JlIGJvb3QuKSBSZS1leHBvcnRlZFxuICogIGZyb20gdGhlIFNESyBzbyBleGlzdGluZyBpbXBvcnRzIG9mIGBtb3VudEZzYCBhcmUgdW5jaGFuZ2VkLiAqL1xuZXhwb3J0IHsgZnNBdmFpbGFibGUgfTtcblxuZXhwb3J0IGludGVyZmFjZSBEaXJFbnRyeSB7XG4gIG5hbWU6IHN0cmluZztcbiAgaXNEaXI6IGJvb2xlYW47XG59XG5cbi8qIGVzbGludC1kaXNhYmxlIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHBsaWNpdC1hbnkgKi9cbmNvbnN0IGpvaW5QYXRoID0gKGRpcjogc3RyaW5nLCBuYW1lOiBzdHJpbmcpOiBzdHJpbmcgPT5cbiAgYCR7ZGlyLnJlcGxhY2UoL1xcLyskLywgXCJcIil9LyR7bmFtZX1gO1xuXG4vKiogTGlzdCBgcGF0aGAncyBpbW1lZGlhdGUgZW50cmllcywgZGlyZWN0b3JpZXMgZmlyc3QgdGhlbiBmaWxlcywgQeKGklouICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcmVhZGRpcihwYXRoOiBzdHJpbmcpOiBQcm9taXNlPERpckVudHJ5W10+IHtcbiAgY29uc3QgZnM6IGFueSA9IHNhbmRib3hGcygpO1xuICBpZiAoIWZzKSB0aHJvdyBuZXcgRXJyb3IoXCJzYW5kYm94IGZpbGVzeXN0ZW0gdW5hdmFpbGFibGVcIik7XG4gIGNvbnN0IHAgPSBmcy5wcm9taXNlcyA/PyBmcztcblxuICBsZXQgcmF3OiBhbnlbXTtcbiAgdHJ5IHtcbiAgICByYXcgPSBhd2FpdCBwLnJlYWRkaXIocGF0aCwgeyB3aXRoRmlsZVR5cGVzOiB0cnVlIH0pO1xuICB9IGNhdGNoIHtcbiAgICByYXcgPSBhd2FpdCBwLnJlYWRkaXIocGF0aCk7XG4gIH1cblxuICBjb25zdCBlbnRyaWVzOiBEaXJFbnRyeVtdID0gW107XG4gIGZvciAoY29uc3QgaXRlbSBvZiByYXcpIHtcbiAgICBpZiAodHlwZW9mIGl0ZW0gPT09IFwic3RyaW5nXCIpIHtcbiAgICAgIC8vIHN0cmluZ1tdIHNoYXBlIOKAlCBzdGF0IGVhY2ggdG8gbGVhcm4gZGlyZWN0b3J5LW5lc3MuXG4gICAgICBsZXQgaXNEaXIgPSBmYWxzZTtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHN0ID0gYXdhaXQgcC5zdGF0KGpvaW5QYXRoKHBhdGgsIGl0ZW0pKTtcbiAgICAgICAgaXNEaXIgPSB0eXBlb2Ygc3Q/LmlzRGlyZWN0b3J5ID09PSBcImZ1bmN0aW9uXCIgPyBzdC5pc0RpcmVjdG9yeSgpIDogISFzdD8uaXNEaXJlY3Rvcnk7XG4gICAgICB9IGNhdGNoIHtcbiAgICAgICAgLyogdW5yZWFkYWJsZSBlbnRyeSDigJQgdHJlYXQgYXMgYSBmaWxlICovXG4gICAgICB9XG4gICAgICBlbnRyaWVzLnB1c2goeyBuYW1lOiBpdGVtLCBpc0RpciB9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gRGlyZW50IHNoYXBlLlxuICAgICAgY29uc3QgaXNEaXIgPVxuICAgICAgICB0eXBlb2YgaXRlbT8uaXNEaXJlY3RvcnkgPT09IFwiZnVuY3Rpb25cIiA/IGl0ZW0uaXNEaXJlY3RvcnkoKSA6ICEhaXRlbT8uaXNEaXJlY3Rvcnk7XG4gICAgICBlbnRyaWVzLnB1c2goeyBuYW1lOiBTdHJpbmcoaXRlbT8ubmFtZSA/PyBpdGVtKSwgaXNEaXIgfSk7XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIGVudHJpZXMuc29ydCgoYSwgYikgPT5cbiAgICBhLmlzRGlyID09PSBiLmlzRGlyID8gYS5uYW1lLmxvY2FsZUNvbXBhcmUoYi5uYW1lKSA6IGEuaXNEaXIgPyAtMSA6IDEsXG4gICk7XG59XG5cbi8qKlxuICogUmVhZCBhIGZpbGUncyByYXcgYnl0ZXMgZnJvbSBhIG1vdW50IChSMy04MyBkcmFnLW91dDogdGhlIHNvdXJjZSBpbmxpbmVzIGEgc21hbGxcbiAqIGZpbGUncyBjb250ZW50IHNvIHRoZSBob3N0IGNhbiByZWxheSBpdCB0byB0aGUgcHJldmlld2VkIGFwcCDigJQgdGhlIHNvdXJjZSBjYW4gb25seVxuICogZXZlciBoYW5kIG92ZXIgYnl0ZXMgaXQgY2FuIGFscmVhZHkgcmVhZCkuIFRocm93cyBpZiB0aGUgc2FuZGJveCBmcyBpcyB1bmF2YWlsYWJsZVxuICogb3IgdGhlIHJlYWQgZmFpbHM7IGNhbGxlcnMgZmFsbCBiYWNrIHRvIGEgcmVmZXJlbmNlLW9ubHkgZHJhZy5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJlYWRGaWxlKHBhdGg6IHN0cmluZyk6IFByb21pc2U8VWludDhBcnJheT4ge1xuICBjb25zdCBmczogYW55ID0gc2FuZGJveEZzKCk7XG4gIGlmICghZnMpIHRocm93IG5ldyBFcnJvcihcInNhbmRib3ggZmlsZXN5c3RlbSB1bmF2YWlsYWJsZVwiKTtcbiAgY29uc3QgcCA9IGZzLnByb21pc2VzID8/IGZzO1xuICBjb25zdCBkYXRhID0gYXdhaXQgcC5yZWFkRmlsZShwYXRoKTtcbiAgcmV0dXJuIGRhdGEgaW5zdGFuY2VvZiBVaW50OEFycmF5ID8gZGF0YSA6IG5ldyBVaW50OEFycmF5KGRhdGEpO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7O0FBVUEsSUFBQUEsR0FBQSxHQUFBQyxPQUFBO0FBVkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBR0E7QUFDQTs7QUFRQTtBQUNBLE1BQU1DLFFBQVEsR0FBR0EsQ0FBQ0MsR0FBVyxFQUFFQyxJQUFZLEtBQ3pDLEdBQUdELEdBQUcsQ0FBQ0UsT0FBTyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsSUFBSUQsSUFBSSxFQUFFOztBQUV0QztBQUNPLGVBQWVFLE9BQU9BLENBQUNDLElBQVksRUFBdUI7RUFDL0QsTUFBTUMsRUFBTyxHQUFHLElBQUFDLGFBQVMsRUFBQyxDQUFDO0VBQzNCLElBQUksQ0FBQ0QsRUFBRSxFQUFFLE1BQU0sSUFBSUUsS0FBSyxDQUFDLGdDQUFnQyxDQUFDO0VBQzFELE1BQU1DLENBQUMsR0FBR0gsRUFBRSxDQUFDSSxRQUFRLElBQUlKLEVBQUU7RUFFM0IsSUFBSUssR0FBVTtFQUNkLElBQUk7SUFDRkEsR0FBRyxHQUFHLE1BQU1GLENBQUMsQ0FBQ0wsT0FBTyxDQUFDQyxJQUFJLEVBQUU7TUFBRU8sYUFBYSxFQUFFO0lBQUssQ0FBQyxDQUFDO0VBQ3RELENBQUMsQ0FBQyxNQUFNO0lBQ05ELEdBQUcsR0FBRyxNQUFNRixDQUFDLENBQUNMLE9BQU8sQ0FBQ0MsSUFBSSxDQUFDO0VBQzdCO0VBRUEsTUFBTVEsT0FBbUIsR0FBRyxFQUFFO0VBQzlCLEtBQUssTUFBTUMsSUFBSSxJQUFJSCxHQUFHLEVBQUU7SUFDdEIsSUFBSSxPQUFPRyxJQUFJLEtBQUssUUFBUSxFQUFFO01BQzVCO01BQ0EsSUFBSUMsS0FBSyxHQUFHLEtBQUs7TUFDakIsSUFBSTtRQUNGLE1BQU1DLEVBQUUsR0FBRyxNQUFNUCxDQUFDLENBQUNRLElBQUksQ0FBQ2pCLFFBQVEsQ0FBQ0ssSUFBSSxFQUFFUyxJQUFJLENBQUMsQ0FBQztRQUM3Q0MsS0FBSyxHQUFHLE9BQU9DLEVBQUUsRUFBRUUsV0FBVyxLQUFLLFVBQVUsR0FBR0YsRUFBRSxDQUFDRSxXQUFXLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQ0YsRUFBRSxFQUFFRSxXQUFXO01BQ3RGLENBQUMsQ0FBQyxNQUFNO1FBQ047TUFBQTtNQUVGTCxPQUFPLENBQUNNLElBQUksQ0FBQztRQUFFakIsSUFBSSxFQUFFWSxJQUFJO1FBQUVDO01BQU0sQ0FBQyxDQUFDO0lBQ3JDLENBQUMsTUFBTTtNQUNMO01BQ0EsTUFBTUEsS0FBSyxHQUNULE9BQU9ELElBQUksRUFBRUksV0FBVyxLQUFLLFVBQVUsR0FBR0osSUFBSSxDQUFDSSxXQUFXLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQ0osSUFBSSxFQUFFSSxXQUFXO01BQ3BGTCxPQUFPLENBQUNNLElBQUksQ0FBQztRQUFFakIsSUFBSSxFQUFFa0IsTUFBTSxDQUFDTixJQUFJLEVBQUVaLElBQUksSUFBSVksSUFBSSxDQUFDO1FBQUVDO01BQU0sQ0FBQyxDQUFDO0lBQzNEO0VBQ0Y7RUFFQSxPQUFPRixPQUFPLENBQUNRLElBQUksQ0FBQyxDQUFDQyxDQUFDLEVBQUVDLENBQUMsS0FDdkJELENBQUMsQ0FBQ1AsS0FBSyxLQUFLUSxDQUFDLENBQUNSLEtBQUssR0FBR08sQ0FBQyxDQUFDcEIsSUFBSSxDQUFDc0IsYUFBYSxDQUFDRCxDQUFDLENBQUNyQixJQUFJLENBQUMsR0FBR29CLENBQUMsQ0FBQ1AsS0FBSyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQ3RFLENBQUM7QUFDSDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxlQUFlVSxRQUFRQSxDQUFDcEIsSUFBWSxFQUF1QjtFQUNoRSxNQUFNQyxFQUFPLEdBQUcsSUFBQUMsYUFBUyxFQUFDLENBQUM7RUFDM0IsSUFBSSxDQUFDRCxFQUFFLEVBQUUsTUFBTSxJQUFJRSxLQUFLLENBQUMsZ0NBQWdDLENBQUM7RUFDMUQsTUFBTUMsQ0FBQyxHQUFHSCxFQUFFLENBQUNJLFFBQVEsSUFBSUosRUFBRTtFQUMzQixNQUFNb0IsSUFBSSxHQUFHLE1BQU1qQixDQUFDLENBQUNnQixRQUFRLENBQUNwQixJQUFJLENBQUM7RUFDbkMsT0FBT3FCLElBQUksWUFBWUMsVUFBVSxHQUFHRCxJQUFJLEdBQUcsSUFBSUMsVUFBVSxDQUFDRCxJQUFJLENBQUM7QUFDakUiLCJpZ25vcmVMaXN0IjpbXX0=