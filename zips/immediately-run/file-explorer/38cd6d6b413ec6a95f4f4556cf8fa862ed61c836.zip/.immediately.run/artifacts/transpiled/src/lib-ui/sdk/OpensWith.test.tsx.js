var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.map.js");
var _react = require("@testing-library/react");
var _userEvent = _interopRequireDefault(require("@testing-library/user-event"));
var _vitest = require("vitest");
var _SdkFileExplorer = _interopRequireDefault(require("./SdkFileExplorer"));
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// R3-267 — the directory-as-content trigger, end to end through the shipped app.
//
// The defect this closes was not a missing mechanism: the contracts, bindings,
// delegation minting and overlay all existed and were tested. What was missing was
// the CALLER. So these tests assert exactly that — a folder that declares what opens
// it gets an affordance in the file manager, and using it invokes the contract the
// marker names with a delegation for that folder.

const TREE = {
  "/spaces/s1": [{
    name: "handbook",
    isDir: true
  }, {
    name: "board",
    isDir: true
  }, {
    name: "sketches",
    isDir: true
  }, {
    name: "shed",
    isDir: true
  }, {
    name: "content",
    isDir: true
  }, {
    name: "orphan-views",
    isDir: true
  }, {
    name: "note.md",
    isDir: false
  }],
  "/spaces/s1/content": [{
    name: "roadmap",
    isDir: true
  }],
  "/spaces/s1/orphan-views": [],
  "/spaces/s1/handbook": [{
    name: "home.mdx",
    isDir: false
  }],
  "/spaces/s1/board": [{
    name: "objects.json",
    isDir: false
  }],
  "/spaces/s1/sketches": [],
  "/spaces/s1/shed": []
};

// Marker files, keyed by their absolute path. `handbook` is a wiki, `board` a
// project, `sketches` names a contract this app does not invoke, `shed` has none.
const MARKERS = {
  "/spaces/s1/handbook/immediately.run.json": JSON.stringify({
    opensWith: {
      task: "open-wiki",
      version: "1.0"
    },
    kind: "wiki"
  }),
  "/spaces/s1/board/immediately.run.json": JSON.stringify({
    opensWith: {
      task: "open-project"
    },
    kind: "board"
  }),
  // R3-789: a wiki declaring a named view (§4b.1a), and a marker the host rejects as a whole
  // (no opensWith) whose views must therefore never be offered.
  "/spaces/s1/content/immediately.run.json": JSON.stringify({
    opensWith: {
      task: "open-wiki",
      version: "1.0"
    },
    kind: "wiki",
    views: [{
      name: "Roadmap board",
      opensWith: {
        app: "github:immediately-run/kanban-board",
        version: "1.0"
      },
      subtree: "/roadmap"
    }]
  }),
  "/spaces/s1/orphan-views/immediately.run.json": JSON.stringify({
    kind: "wiki",
    views: [{
      name: "Board",
      opensWith: {
        app: "github:a/b"
      },
      subtree: "/r"
    }]
  }),
  "/spaces/s1/sketches/immediately.run.json": JSON.stringify({
    opensWith: {
      task: "open-hologram"
    },
    kind: "hologram"
  })
};
const h = _vitest.vi.hoisted(() => ({
  mounts: [],
  readdir: _vitest.vi.fn(() => Promise.resolve([])),
  readFile: _vitest.vi.fn(() => Promise.reject(new Error("ENOENT"))),
  invokeTask: _vitest.vi.fn(() => Promise.resolve({
    opened: true
  })),
  launch: _vitest.vi.fn(() => Promise.resolve({
    launchId: "launch-1",
    onDismiss: () => () => {}
  }))
}));
_vitest.vi.mock("@immediately-run/sdk/sandboxUtils", () => ({
  addListener: () => () => {},
  sendMessage: _vitest.vi.fn()
}));
_vitest.vi.mock("@immediately-run/sdk", () => ({
  useMounts: () => h.mounts,
  useSessionMounts: () => [],
  useEditorContext: () => ({
    dirtyPaths: [],
    openFiles: [],
    activeFile: null,
    viewedFile: null
  }),
  openInEditor: _vitest.vi.fn(() => Promise.resolve()),
  createFile: _vitest.vi.fn(() => Promise.resolve()),
  createFolder: _vitest.vi.fn(() => Promise.resolve()),
  deleteEntry: _vitest.vi.fn(() => Promise.resolve()),
  renameEntry: _vitest.vi.fn(() => Promise.resolve()),
  uploadFile: _vitest.vi.fn(() => Promise.resolve()),
  startItemDrag: _vitest.vi.fn(() => Promise.resolve()),
  cancelItemDrag: _vitest.vi.fn(),
  unmountSpace: _vitest.vi.fn(() => Promise.resolve()),
  listSettingsApps: _vitest.vi.fn(() => Promise.resolve([])),
  openSettingsOf: _vitest.vi.fn(() => Promise.resolve({})),
  requestMount: _vitest.vi.fn(() => new Promise(() => {})),
  useRegion: () => null,
  invokeTask: (task, params) => h.invokeTask(task, params),
  launch: (target, opts) => h.launch(target, opts),
  capDir: (ref, opts) => ({
    $cap: "dir",
    ...ref,
    ...opts
  })
}));
_vitest.vi.mock("./mountFs", () => ({
  readdir: p => h.readdir(p),
  readFile: p => h.readFile(p),
  sdkFsSource: {
    readdir: p => h.readdir(p),
    readFile: p => h.readFile(p)
  }
}));
const space = (over = {}) => ({
  type: "firestore",
  path: "/spaces/s1",
  id: "space:s1",
  name: "Team",
  mode: "rw",
  rules: [{
    subtree: "/",
    mode: "rw"
  }],
  ...over
});

/** Right-click a row and return its open menu. */
async function menuFor(label) {
  _react.fireEvent.contextMenu(_react.screen.getByText(label));
  return _react.screen.findByRole("menu");
}

/** The labels a row's context menu offers. Empty when the row has no menu at all —
 *  the view opens none when nothing is offerable, which is the strongest form of
 *  "no affordance". */
function menuLabelsFor(label) {
  _react.fireEvent.contextMenu(_react.screen.getByText(label));
  const menu = _react.screen.queryByRole("menu");
  return menu ? (0, _react.within)(menu).queryAllByRole("menuitem").map(el => el.textContent ?? "") : [];
}
(0, _vitest.beforeEach)(() => {
  h.mounts = [space()];
  h.readdir.mockReset();
  h.readdir.mockImplementation(path => Promise.resolve(TREE[path] ?? []));
  h.readFile.mockReset();
  h.readFile.mockImplementation(path => MARKERS[path] !== undefined ? Promise.resolve(new TextEncoder().encode(MARKERS[path])) : Promise.reject(Object.assign(new Error("ENOENT"), {
    code: "ENOENT"
  })));
  h.invokeTask.mockReset();
  h.invokeTask.mockResolvedValue({
    opened: true
  });
  h.launch.mockReset();
  h.launch.mockResolvedValue({
    launchId: "launch-1",
    onDismiss: () => () => {}
  });
});
(0, _vitest.afterEach)(() => _vitest.vi.clearAllMocks());
(0, _vitest.describe)("R3-267 — a folder's opensWith marker finally has a caller", () => {
  (0, _vitest.it)("offers a marked folder by its KIND, and opens it with the contract the marker names", async () => {
    const user = _userEvent.default.setup();
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    await _react.screen.findByText("handbook");
    // The probe rides the listing the explorer already did.
    await (0, _react.waitFor)(() => (0, _vitest.expect)(h.readFile).toHaveBeenCalledWith("/spaces/s1/handbook/immediately.run.json"));
    const menu = await menuFor("handbook");
    const item = (0, _react.within)(menu).getByRole("menuitem", {
      name: /Open as wiki/
    });
    await user.click(item);
    (0, _vitest.expect)(h.invokeTask).toHaveBeenCalledTimes(1);
    const [task, params] = h.invokeTask.mock.calls[0];
    (0, _vitest.expect)(task).toBe("open-wiki");
    (0, _vitest.expect)(params.dir).toEqual({
      $cap: "dir",
      mountId: "space:s1",
      relPath: "/handbook",
      mode: "rw"
    });
  });
  (0, _vitest.it)("opens a DIFFERENT contract from the same code path — no task name in the caller", async () => {
    const user = _userEvent.default.setup();
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    await _react.screen.findByText("board");
    await (0, _react.waitFor)(() => (0, _vitest.expect)(h.readFile).toHaveBeenCalledWith("/spaces/s1/board/immediately.run.json"));
    const menu = await menuFor("board");
    await user.click((0, _react.within)(menu).getByRole("menuitem", {
      name: /Open as board/
    }));
    (0, _vitest.expect)(h.invokeTask.mock.calls[0][0]).toBe("open-project");
  });
  (0, _vitest.it)("a marker naming a contract nothing is bound to degrades to NO affordance", async () => {
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    await _react.screen.findByText("sketches");
    await (0, _react.waitFor)(() => (0, _vitest.expect)(h.readFile).toHaveBeenCalledWith("/spaces/s1/sketches/immediately.run.json"));
    (0, _vitest.expect)(menuLabelsFor("sketches")).toEqual([]);
    (0, _vitest.expect)(h.invokeTask).not.toHaveBeenCalled();
  });
  (0, _vitest.it)("an ordinary folder gets no affordance", async () => {
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    await _react.screen.findByText("shed");
    await (0, _react.waitFor)(() => (0, _vitest.expect)(h.readFile).toHaveBeenCalledWith("/spaces/s1/shed/immediately.run.json"));
    (0, _vitest.expect)(menuLabelsFor("shed")).toEqual([]);
  });
  (0, _vitest.it)("delegates at the mount's own mode — a ro space opens a ro corpus, never EROFS-later", async () => {
    h.mounts = [space({
      mode: "ro",
      rules: [{
        subtree: "/",
        mode: "ro"
      }]
    })];
    const user = _userEvent.default.setup();
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    await _react.screen.findByText("handbook");
    await (0, _react.waitFor)(() => (0, _vitest.expect)(h.readFile).toHaveBeenCalledWith("/spaces/s1/handbook/immediately.run.json"));
    await user.click((0, _react.within)(await menuFor("handbook")).getByRole("menuitem", {
      name: /Open as wiki/
    }));
    (0, _vitest.expect)(h.invokeTask.mock.calls[0][1].dir.mode).toBe("ro");
  });
  (0, _vitest.it)("a user closing the viewer (cancelled) leaves the affordance in place", async () => {
    h.invokeTask.mockRejectedValue(Object.assign(new Error("dismissed"), {
      code: "cancelled"
    }));
    const user = _userEvent.default.setup();
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    await _react.screen.findByText("handbook");
    await (0, _react.waitFor)(() => (0, _vitest.expect)(h.readFile).toHaveBeenCalledWith("/spaces/s1/handbook/immediately.run.json"));
    await user.click((0, _react.within)(await menuFor("handbook")).getByRole("menuitem", {
      name: /Open as wiki/
    }));
    await (0, _react.waitFor)(() => (0, _vitest.expect)(h.invokeTask).toHaveBeenCalledTimes(1));
    const again = await menuFor("handbook");
    (0, _vitest.expect)((0, _react.within)(again).getByRole("menuitem", {
      name: /Open as wiki/
    })).toBeInTheDocument();
  });
  (0, _vitest.it)("a host refusal WITHDRAWS the affordance instead of showing a protocol code", async () => {
    h.invokeTask.mockRejectedValue(Object.assign(new Error("nope"), {
      code: "no-such-task"
    }));
    const user = _userEvent.default.setup();
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    await _react.screen.findByText("handbook");
    await (0, _react.waitFor)(() => (0, _vitest.expect)(h.readFile).toHaveBeenCalledWith("/spaces/s1/handbook/immediately.run.json"));
    await user.click((0, _react.within)(await menuFor("handbook")).getByRole("menuitem", {
      name: /Open as wiki/
    }));
    await (0, _react.waitFor)(() => (0, _vitest.expect)(h.invokeTask).toHaveBeenCalledTimes(1));

    // No error text anywhere, and the dead affordance is gone.
    (0, _vitest.expect)(_react.screen.queryByText(/no-such-task/)).not.toBeInTheDocument();
    await (0, _react.waitFor)(() => (0, _vitest.expect)(menuLabelsFor("handbook")).toEqual([]));
  });
  (0, _vitest.it)("probes each listed directory once, not on every menu open", async () => {
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    await _react.screen.findByText("handbook");
    await (0, _react.waitFor)(() => (0, _vitest.expect)(h.readFile).toHaveBeenCalledWith("/spaces/s1/handbook/immediately.run.json"));
    const after = h.readFile.mock.calls.filter(c => c[0] === "/spaces/s1/handbook/immediately.run.json").length;
    await menuFor("handbook");
    _react.fireEvent.keyDown(document, {
      key: "Escape"
    });
    await menuFor("handbook");
    (0, _vitest.expect)(h.readFile.mock.calls.filter(c => c[0] === "/spaces/s1/handbook/immediately.run.json").length).toBe(after);
  });
});
(0, _vitest.describe)("R3-159 — a launchable marker ALSO gets the into-stage affordance", () => {
  (0, _vitest.it)("offers 'Open in place' for an open-project folder and LAUNCHES it into the stage", async () => {
    const user = _userEvent.default.setup();
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    await _react.screen.findByText("board");
    await (0, _react.waitFor)(() => (0, _vitest.expect)(h.readFile).toHaveBeenCalledWith("/spaces/s1/board/immediately.run.json"));
    const menu = await menuFor("board");
    await user.click((0, _react.within)(menu).getByRole("menuitem", {
      name: /Open in place/
    }));
    (0, _vitest.expect)(h.launch).toHaveBeenCalledTimes(1);
    const [target, opts] = h.launch.mock.calls[0];
    (0, _vitest.expect)(target).toEqual({
      task: "open-project"
    });
    (0, _vitest.expect)(opts.region).toBe("stage");
    // R-SAL-6: the into-stage delegation is ro even though this mount is rw.
    (0, _vitest.expect)(opts.input.dir).toEqual({
      $cap: "dir",
      mountId: "space:s1",
      relPath: "/board",
      mode: "ro"
    });
    // …and the for-result invoke never fired.
    (0, _vitest.expect)(h.invokeTask).not.toHaveBeenCalled();
  });
  (0, _vitest.it)("offers BOTH affordances for a launchable contract — the for-result one leads", async () => {
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    await _react.screen.findByText("board");
    await (0, _react.waitFor)(() => (0, _vitest.expect)(h.readFile).toHaveBeenCalledWith("/spaces/s1/board/immediately.run.json"));
    (0, _vitest.expect)(menuLabelsFor("board")).toEqual(_vitest.expect.arrayContaining(["Open as board", "Open in place"]));
    const labels = menuLabelsFor("board");
    (0, _vitest.expect)(labels.indexOf("Open as board")).toBeLessThan(labels.indexOf("Open in place"));
  });
  (0, _vitest.it)("an invoke-only contract (open-wiki) gets NO in-place affordance", async () => {
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    await _react.screen.findByText("handbook");
    await (0, _react.waitFor)(() => (0, _vitest.expect)(h.readFile).toHaveBeenCalledWith("/spaces/s1/handbook/immediately.run.json"));
    const labels = menuLabelsFor("handbook");
    (0, _vitest.expect)(labels).toContain("Open as wiki");
    (0, _vitest.expect)(labels).not.toContain("Open in place");
  });
  _vitest.it.each(["forbidden", "unsupported"])("a launch refusal (%s) leaves BOTH affordances in place — no launch code withdraws", async code => {
    // `forbidden` is the fork case; `unsupported` doubles as a transient host
    // state (launch host not yet mounted), so it cannot be a session-permanent
    // verdict either. The decline is invisible — no protocol code on screen.
    h.launch.mockResolvedValue({
      ok: false,
      code
    });
    const user = _userEvent.default.setup();
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    await _react.screen.findByText("board");
    await (0, _react.waitFor)(() => (0, _vitest.expect)(h.readFile).toHaveBeenCalledWith("/spaces/s1/board/immediately.run.json"));
    await user.click((0, _react.within)(await menuFor("board")).getByRole("menuitem", {
      name: /Open in place/
    }));
    await (0, _react.waitFor)(() => (0, _vitest.expect)(h.launch).toHaveBeenCalledTimes(1));
    const labels = menuLabelsFor("board");
    (0, _vitest.expect)(labels).toContain("Open in place");
    (0, _vitest.expect)(labels).toContain("Open as board");
    (0, _vitest.expect)(_react.screen.queryByText(new RegExp(code))).not.toBeInTheDocument();
  });
});
(0, _vitest.describe)("R3-789 — a declared view gets its own 'Open as <name>' (§4b.1a)", () => {
  const settle = async dir => {
    await _react.screen.findByText(dir);
    await (0, _react.waitFor)(() => (0, _vitest.expect)(h.readFile).toHaveBeenCalledWith(`/spaces/s1/${dir}/immediately.run.json`));
  };
  (0, _vitest.it)("offers the view beside the bundle's own offer, and opens it by NAME through open-declared", async () => {
    const user = _userEvent.default.setup();
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    await settle("content");
    await (0, _react.waitFor)(() => (0, _vitest.expect)(menuLabelsFor("content")).toContain("Open as Roadmap board"));
    _react.fireEvent.keyDown(document, {
      key: "Escape"
    });
    const menu = await menuFor("content");
    (0, _vitest.expect)((0, _react.within)(menu).getByRole("menuitem", {
      name: /Open as wiki/
    })).toBeInTheDocument();
    await user.click((0, _react.within)(menu).getByRole("menuitem", {
      name: /Open as Roadmap board/
    }));
    (0, _vitest.expect)(h.invokeTask).toHaveBeenCalledTimes(1);
    const [task, params] = h.invokeTask.mock.calls[0];
    (0, _vitest.expect)(task).toBe("open-declared");
    // The view's NAME and the folder — never its app, never an entry.
    (0, _vitest.expect)(params).toEqual({
      dir: {
        $cap: "dir",
        mountId: "space:s1",
        relPath: "/content",
        mode: "rw"
      },
      view: "Roadmap board"
    });
  });
  (0, _vitest.it)("a withdrawn open-declared removes the view item and leaves the bundle's own offer", async () => {
    h.invokeTask.mockRejectedValue(Object.assign(new Error("nope"), {
      code: "no-such-task"
    }));
    const user = _userEvent.default.setup();
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    await settle("content");
    await (0, _react.waitFor)(() => (0, _vitest.expect)(menuLabelsFor("content")).toContain("Open as Roadmap board"));
    _react.fireEvent.keyDown(document, {
      key: "Escape"
    });
    await user.click((0, _react.within)(await menuFor("content")).getByRole("menuitem", {
      name: /Open as Roadmap board/
    }));
    await (0, _react.waitFor)(() => (0, _vitest.expect)(h.invokeTask).toHaveBeenCalledTimes(1));
    _react.fireEvent.keyDown(document, {
      key: "Escape"
    });
    await (0, _react.waitFor)(() => (0, _vitest.expect)(menuLabelsFor("content")).not.toContain("Open as Roadmap board"));
    (0, _vitest.expect)(menuLabelsFor("content")).toContain("Open as wiki");
  });
  (0, _vitest.it)("views on a marker the host rejects as a whole are never offered", async () => {
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    await settle("orphan-views");
    (0, _vitest.expect)(menuLabelsFor("orphan-views")).toEqual([]);
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3VzZXJFdmVudCIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJfdml0ZXN0IiwiX1Nka0ZpbGVFeHBsb3JlciIsIl9qc3hSdW50aW1lIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiVFJFRSIsIm5hbWUiLCJpc0RpciIsIk1BUktFUlMiLCJKU09OIiwic3RyaW5naWZ5Iiwib3BlbnNXaXRoIiwidGFzayIsInZlcnNpb24iLCJraW5kIiwidmlld3MiLCJhcHAiLCJzdWJ0cmVlIiwiaCIsInZpIiwiaG9pc3RlZCIsIm1vdW50cyIsInJlYWRkaXIiLCJmbiIsIlByb21pc2UiLCJyZXNvbHZlIiwicmVhZEZpbGUiLCJyZWplY3QiLCJFcnJvciIsImludm9rZVRhc2siLCJvcGVuZWQiLCJsYXVuY2giLCJsYXVuY2hJZCIsIm9uRGlzbWlzcyIsIm1vY2siLCJhZGRMaXN0ZW5lciIsInNlbmRNZXNzYWdlIiwidXNlTW91bnRzIiwidXNlU2Vzc2lvbk1vdW50cyIsInVzZUVkaXRvckNvbnRleHQiLCJkaXJ0eVBhdGhzIiwib3BlbkZpbGVzIiwiYWN0aXZlRmlsZSIsInZpZXdlZEZpbGUiLCJvcGVuSW5FZGl0b3IiLCJjcmVhdGVGaWxlIiwiY3JlYXRlRm9sZGVyIiwiZGVsZXRlRW50cnkiLCJyZW5hbWVFbnRyeSIsInVwbG9hZEZpbGUiLCJzdGFydEl0ZW1EcmFnIiwiY2FuY2VsSXRlbURyYWciLCJ1bm1vdW50U3BhY2UiLCJsaXN0U2V0dGluZ3NBcHBzIiwib3BlblNldHRpbmdzT2YiLCJyZXF1ZXN0TW91bnQiLCJ1c2VSZWdpb24iLCJwYXJhbXMiLCJ0YXJnZXQiLCJvcHRzIiwiY2FwRGlyIiwicmVmIiwiJGNhcCIsInAiLCJzZGtGc1NvdXJjZSIsInNwYWNlIiwib3ZlciIsInR5cGUiLCJwYXRoIiwiaWQiLCJtb2RlIiwicnVsZXMiLCJtZW51Rm9yIiwibGFiZWwiLCJmaXJlRXZlbnQiLCJjb250ZXh0TWVudSIsInNjcmVlbiIsImdldEJ5VGV4dCIsImZpbmRCeVJvbGUiLCJtZW51TGFiZWxzRm9yIiwibWVudSIsInF1ZXJ5QnlSb2xlIiwid2l0aGluIiwicXVlcnlBbGxCeVJvbGUiLCJtYXAiLCJlbCIsInRleHRDb250ZW50IiwiYmVmb3JlRWFjaCIsIm1vY2tSZXNldCIsIm1vY2tJbXBsZW1lbnRhdGlvbiIsInVuZGVmaW5lZCIsIlRleHRFbmNvZGVyIiwiZW5jb2RlIiwiT2JqZWN0IiwiYXNzaWduIiwiY29kZSIsIm1vY2tSZXNvbHZlZFZhbHVlIiwiYWZ0ZXJFYWNoIiwiY2xlYXJBbGxNb2NrcyIsImRlc2NyaWJlIiwiaXQiLCJ1c2VyIiwidXNlckV2ZW50Iiwic2V0dXAiLCJyZW5kZXIiLCJqc3giLCJmaW5kQnlUZXh0Iiwid2FpdEZvciIsImV4cGVjdCIsInRvSGF2ZUJlZW5DYWxsZWRXaXRoIiwiaXRlbSIsImdldEJ5Um9sZSIsImNsaWNrIiwidG9IYXZlQmVlbkNhbGxlZFRpbWVzIiwiY2FsbHMiLCJ0b0JlIiwiZGlyIiwidG9FcXVhbCIsIm1vdW50SWQiLCJyZWxQYXRoIiwibm90IiwidG9IYXZlQmVlbkNhbGxlZCIsIm1vY2tSZWplY3RlZFZhbHVlIiwiYWdhaW4iLCJ0b0JlSW5UaGVEb2N1bWVudCIsInF1ZXJ5QnlUZXh0IiwiYWZ0ZXIiLCJmaWx0ZXIiLCJjIiwibGVuZ3RoIiwia2V5RG93biIsImRvY3VtZW50Iiwia2V5IiwicmVnaW9uIiwiaW5wdXQiLCJhcnJheUNvbnRhaW5pbmciLCJsYWJlbHMiLCJpbmRleE9mIiwidG9CZUxlc3NUaGFuIiwidG9Db250YWluIiwiZWFjaCIsIm9rIiwiUmVnRXhwIiwic2V0dGxlIiwidmlldyJdLCJzb3VyY2VzIjpbIk9wZW5zV2l0aC50ZXN0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBSMy0yNjcg4oCUIHRoZSBkaXJlY3RvcnktYXMtY29udGVudCB0cmlnZ2VyLCBlbmQgdG8gZW5kIHRocm91Z2ggdGhlIHNoaXBwZWQgYXBwLlxuLy9cbi8vIFRoZSBkZWZlY3QgdGhpcyBjbG9zZXMgd2FzIG5vdCBhIG1pc3NpbmcgbWVjaGFuaXNtOiB0aGUgY29udHJhY3RzLCBiaW5kaW5ncyxcbi8vIGRlbGVnYXRpb24gbWludGluZyBhbmQgb3ZlcmxheSBhbGwgZXhpc3RlZCBhbmQgd2VyZSB0ZXN0ZWQuIFdoYXQgd2FzIG1pc3Npbmcgd2FzXG4vLyB0aGUgQ0FMTEVSLiBTbyB0aGVzZSB0ZXN0cyBhc3NlcnQgZXhhY3RseSB0aGF0IOKAlCBhIGZvbGRlciB0aGF0IGRlY2xhcmVzIHdoYXQgb3BlbnNcbi8vIGl0IGdldHMgYW4gYWZmb3JkYW5jZSBpbiB0aGUgZmlsZSBtYW5hZ2VyLCBhbmQgdXNpbmcgaXQgaW52b2tlcyB0aGUgY29udHJhY3QgdGhlXG4vLyBtYXJrZXIgbmFtZXMgd2l0aCBhIGRlbGVnYXRpb24gZm9yIHRoYXQgZm9sZGVyLlxuaW1wb3J0IHsgZmlyZUV2ZW50LCByZW5kZXIsIHNjcmVlbiwgd2FpdEZvciwgd2l0aGluIH0gZnJvbSBcIkB0ZXN0aW5nLWxpYnJhcnkvcmVhY3RcIjtcbmltcG9ydCB1c2VyRXZlbnQgZnJvbSBcIkB0ZXN0aW5nLWxpYnJhcnkvdXNlci1ldmVudFwiO1xuaW1wb3J0IHsgYWZ0ZXJFYWNoLCBiZWZvcmVFYWNoLCBkZXNjcmliZSwgZXhwZWN0LCBpdCwgdmkgfSBmcm9tIFwidml0ZXN0XCI7XG5pbXBvcnQgdHlwZSB7IERpckVudHJ5IH0gZnJvbSBcIi4uL3R5cGVzXCI7XG5cbmNvbnN0IFRSRUU6IFJlY29yZDxzdHJpbmcsIERpckVudHJ5W10+ID0ge1xuICBcIi9zcGFjZXMvczFcIjogW1xuICAgIHsgbmFtZTogXCJoYW5kYm9va1wiLCBpc0RpcjogdHJ1ZSB9LFxuICAgIHsgbmFtZTogXCJib2FyZFwiLCBpc0RpcjogdHJ1ZSB9LFxuICAgIHsgbmFtZTogXCJza2V0Y2hlc1wiLCBpc0RpcjogdHJ1ZSB9LFxuICAgIHsgbmFtZTogXCJzaGVkXCIsIGlzRGlyOiB0cnVlIH0sXG4gICAgeyBuYW1lOiBcImNvbnRlbnRcIiwgaXNEaXI6IHRydWUgfSxcbiAgICB7IG5hbWU6IFwib3JwaGFuLXZpZXdzXCIsIGlzRGlyOiB0cnVlIH0sXG4gICAgeyBuYW1lOiBcIm5vdGUubWRcIiwgaXNEaXI6IGZhbHNlIH0sXG4gIF0sXG4gIFwiL3NwYWNlcy9zMS9jb250ZW50XCI6IFt7IG5hbWU6IFwicm9hZG1hcFwiLCBpc0RpcjogdHJ1ZSB9XSxcbiAgXCIvc3BhY2VzL3MxL29ycGhhbi12aWV3c1wiOiBbXSxcbiAgXCIvc3BhY2VzL3MxL2hhbmRib29rXCI6IFt7IG5hbWU6IFwiaG9tZS5tZHhcIiwgaXNEaXI6IGZhbHNlIH1dLFxuICBcIi9zcGFjZXMvczEvYm9hcmRcIjogW3sgbmFtZTogXCJvYmplY3RzLmpzb25cIiwgaXNEaXI6IGZhbHNlIH1dLFxuICBcIi9zcGFjZXMvczEvc2tldGNoZXNcIjogW10sXG4gIFwiL3NwYWNlcy9zMS9zaGVkXCI6IFtdLFxufTtcblxuLy8gTWFya2VyIGZpbGVzLCBrZXllZCBieSB0aGVpciBhYnNvbHV0ZSBwYXRoLiBgaGFuZGJvb2tgIGlzIGEgd2lraSwgYGJvYXJkYCBhXG4vLyBwcm9qZWN0LCBgc2tldGNoZXNgIG5hbWVzIGEgY29udHJhY3QgdGhpcyBhcHAgZG9lcyBub3QgaW52b2tlLCBgc2hlZGAgaGFzIG5vbmUuXG5jb25zdCBNQVJLRVJTOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge1xuICBcIi9zcGFjZXMvczEvaGFuZGJvb2svaW1tZWRpYXRlbHkucnVuLmpzb25cIjogSlNPTi5zdHJpbmdpZnkoe1xuICAgIG9wZW5zV2l0aDogeyB0YXNrOiBcIm9wZW4td2lraVwiLCB2ZXJzaW9uOiBcIjEuMFwiIH0sXG4gICAga2luZDogXCJ3aWtpXCIsXG4gIH0pLFxuICBcIi9zcGFjZXMvczEvYm9hcmQvaW1tZWRpYXRlbHkucnVuLmpzb25cIjogSlNPTi5zdHJpbmdpZnkoe1xuICAgIG9wZW5zV2l0aDogeyB0YXNrOiBcIm9wZW4tcHJvamVjdFwiIH0sXG4gICAga2luZDogXCJib2FyZFwiLFxuICB9KSxcbiAgLy8gUjMtNzg5OiBhIHdpa2kgZGVjbGFyaW5nIGEgbmFtZWQgdmlldyAowqc0Yi4xYSksIGFuZCBhIG1hcmtlciB0aGUgaG9zdCByZWplY3RzIGFzIGEgd2hvbGVcbiAgLy8gKG5vIG9wZW5zV2l0aCkgd2hvc2Ugdmlld3MgbXVzdCB0aGVyZWZvcmUgbmV2ZXIgYmUgb2ZmZXJlZC5cbiAgXCIvc3BhY2VzL3MxL2NvbnRlbnQvaW1tZWRpYXRlbHkucnVuLmpzb25cIjogSlNPTi5zdHJpbmdpZnkoe1xuICAgIG9wZW5zV2l0aDogeyB0YXNrOiBcIm9wZW4td2lraVwiLCB2ZXJzaW9uOiBcIjEuMFwiIH0sXG4gICAga2luZDogXCJ3aWtpXCIsXG4gICAgdmlld3M6IFtcbiAgICAgIHtcbiAgICAgICAgbmFtZTogXCJSb2FkbWFwIGJvYXJkXCIsXG4gICAgICAgIG9wZW5zV2l0aDogeyBhcHA6IFwiZ2l0aHViOmltbWVkaWF0ZWx5LXJ1bi9rYW5iYW4tYm9hcmRcIiwgdmVyc2lvbjogXCIxLjBcIiB9LFxuICAgICAgICBzdWJ0cmVlOiBcIi9yb2FkbWFwXCIsXG4gICAgICB9LFxuICAgIF0sXG4gIH0pLFxuICBcIi9zcGFjZXMvczEvb3JwaGFuLXZpZXdzL2ltbWVkaWF0ZWx5LnJ1bi5qc29uXCI6IEpTT04uc3RyaW5naWZ5KHtcbiAgICBraW5kOiBcIndpa2lcIixcbiAgICB2aWV3czogW3sgbmFtZTogXCJCb2FyZFwiLCBvcGVuc1dpdGg6IHsgYXBwOiBcImdpdGh1YjphL2JcIiB9LCBzdWJ0cmVlOiBcIi9yXCIgfV0sXG4gIH0pLFxuICBcIi9zcGFjZXMvczEvc2tldGNoZXMvaW1tZWRpYXRlbHkucnVuLmpzb25cIjogSlNPTi5zdHJpbmdpZnkoe1xuICAgIG9wZW5zV2l0aDogeyB0YXNrOiBcIm9wZW4taG9sb2dyYW1cIiB9LFxuICAgIGtpbmQ6IFwiaG9sb2dyYW1cIixcbiAgfSksXG59O1xuXG5jb25zdCBoID0gdmkuaG9pc3RlZCgoKSA9PiAoe1xuICBtb3VudHM6IFtdIGFzIEFycmF5PFJlY29yZDxzdHJpbmcsIHVua25vd24+PixcbiAgcmVhZGRpcjogdmkuZm48KHBhdGg6IHN0cmluZykgPT4gUHJvbWlzZTxEaXJFbnRyeVtdPj4oKCkgPT4gUHJvbWlzZS5yZXNvbHZlKFtdKSksXG4gIHJlYWRGaWxlOiB2aS5mbjwocGF0aDogc3RyaW5nKSA9PiBQcm9taXNlPFVpbnQ4QXJyYXk+PigoKSA9PiBQcm9taXNlLnJlamVjdChuZXcgRXJyb3IoXCJFTk9FTlRcIikpKSxcbiAgaW52b2tlVGFzazogdmkuZm4oKCk6IFByb21pc2U8dW5rbm93bj4gPT4gUHJvbWlzZS5yZXNvbHZlKHsgb3BlbmVkOiB0cnVlIH0pKSxcbiAgbGF1bmNoOiB2aS5mbigoKTogUHJvbWlzZTx1bmtub3duPiA9PlxuICAgIFByb21pc2UucmVzb2x2ZSh7IGxhdW5jaElkOiBcImxhdW5jaC0xXCIsIG9uRGlzbWlzczogKCkgPT4gKCkgPT4ge30gfSksXG4gICksXG59KSk7XG5cbnZpLm1vY2soXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9zYW5kYm94VXRpbHNcIiwgKCkgPT4gKHtcbiAgYWRkTGlzdGVuZXI6ICgpID0+ICgpID0+IHt9LFxuICBzZW5kTWVzc2FnZTogdmkuZm4oKSxcbn0pKTtcblxudmkubW9jayhcIkBpbW1lZGlhdGVseS1ydW4vc2RrXCIsICgpID0+ICh7XG4gIHVzZU1vdW50czogKCkgPT4gaC5tb3VudHMsXG4gIHVzZVNlc3Npb25Nb3VudHM6ICgpID0+IFtdLFxuICB1c2VFZGl0b3JDb250ZXh0OiAoKSA9PiAoeyBkaXJ0eVBhdGhzOiBbXSwgb3BlbkZpbGVzOiBbXSwgYWN0aXZlRmlsZTogbnVsbCwgdmlld2VkRmlsZTogbnVsbCB9KSxcbiAgb3BlbkluRWRpdG9yOiB2aS5mbigoKSA9PiBQcm9taXNlLnJlc29sdmUoKSksXG4gIGNyZWF0ZUZpbGU6IHZpLmZuKCgpID0+IFByb21pc2UucmVzb2x2ZSgpKSxcbiAgY3JlYXRlRm9sZGVyOiB2aS5mbigoKSA9PiBQcm9taXNlLnJlc29sdmUoKSksXG4gIGRlbGV0ZUVudHJ5OiB2aS5mbigoKSA9PiBQcm9taXNlLnJlc29sdmUoKSksXG4gIHJlbmFtZUVudHJ5OiB2aS5mbigoKSA9PiBQcm9taXNlLnJlc29sdmUoKSksXG4gIHVwbG9hZEZpbGU6IHZpLmZuKCgpID0+IFByb21pc2UucmVzb2x2ZSgpKSxcbiAgc3RhcnRJdGVtRHJhZzogdmkuZm4oKCkgPT4gUHJvbWlzZS5yZXNvbHZlKCkpLFxuICBjYW5jZWxJdGVtRHJhZzogdmkuZm4oKSxcbiAgdW5tb3VudFNwYWNlOiB2aS5mbigoKSA9PiBQcm9taXNlLnJlc29sdmUoKSksXG4gIGxpc3RTZXR0aW5nc0FwcHM6IHZpLmZuKCgpID0+IFByb21pc2UucmVzb2x2ZShbXSkpLFxuICBvcGVuU2V0dGluZ3NPZjogdmkuZm4oKCkgPT4gUHJvbWlzZS5yZXNvbHZlKHt9KSksXG4gIHJlcXVlc3RNb3VudDogdmkuZm4oKCkgPT4gbmV3IFByb21pc2UoKCkgPT4ge30pKSxcbiAgdXNlUmVnaW9uOiAoKSA9PiBudWxsLFxuICBpbnZva2VUYXNrOiAodGFzazogc3RyaW5nLCBwYXJhbXM6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KSA9PiBoLmludm9rZVRhc2sodGFzaywgcGFyYW1zKSxcbiAgbGF1bmNoOiAodGFyZ2V0OiB1bmtub3duLCBvcHRzOiB1bmtub3duKSA9PiBoLmxhdW5jaCh0YXJnZXQsIG9wdHMpLFxuICBjYXBEaXI6IChyZWY6IHsgbW91bnRJZDogc3RyaW5nOyByZWxQYXRoOiBzdHJpbmcgfSwgb3B0czogeyBtb2RlOiBcInJvXCIgfCBcInJ3XCIgfSkgPT4gKHtcbiAgICAkY2FwOiBcImRpclwiLFxuICAgIC4uLnJlZixcbiAgICAuLi5vcHRzLFxuICB9KSxcbn0pKTtcblxudmkubW9jayhcIi4vbW91bnRGc1wiLCAoKSA9PiAoe1xuICByZWFkZGlyOiAocDogc3RyaW5nKSA9PiBoLnJlYWRkaXIocCksXG4gIHJlYWRGaWxlOiAocDogc3RyaW5nKSA9PiBoLnJlYWRGaWxlKHApLFxuICBzZGtGc1NvdXJjZTogeyByZWFkZGlyOiAocDogc3RyaW5nKSA9PiBoLnJlYWRkaXIocCksIHJlYWRGaWxlOiAocDogc3RyaW5nKSA9PiBoLnJlYWRGaWxlKHApIH0sXG59KSk7XG5cbmltcG9ydCBGaWxlRXhwbG9yZXIgZnJvbSBcIi4vU2RrRmlsZUV4cGxvcmVyXCI7XG5cbmNvbnN0IHNwYWNlID0gKG92ZXI6IFJlY29yZDxzdHJpbmcsIHVua25vd24+ID0ge30pID0+ICh7XG4gIHR5cGU6IFwiZmlyZXN0b3JlXCIsXG4gIHBhdGg6IFwiL3NwYWNlcy9zMVwiLFxuICBpZDogXCJzcGFjZTpzMVwiLFxuICBuYW1lOiBcIlRlYW1cIixcbiAgbW9kZTogXCJyd1wiLFxuICBydWxlczogW3sgc3VidHJlZTogXCIvXCIsIG1vZGU6IFwicndcIiB9XSxcbiAgLi4ub3Zlcixcbn0pO1xuXG4vKiogUmlnaHQtY2xpY2sgYSByb3cgYW5kIHJldHVybiBpdHMgb3BlbiBtZW51LiAqL1xuYXN5bmMgZnVuY3Rpb24gbWVudUZvcihsYWJlbDogc3RyaW5nKSB7XG4gIGZpcmVFdmVudC5jb250ZXh0TWVudShzY3JlZW4uZ2V0QnlUZXh0KGxhYmVsKSk7XG4gIHJldHVybiBzY3JlZW4uZmluZEJ5Um9sZShcIm1lbnVcIik7XG59XG5cbi8qKiBUaGUgbGFiZWxzIGEgcm93J3MgY29udGV4dCBtZW51IG9mZmVycy4gRW1wdHkgd2hlbiB0aGUgcm93IGhhcyBubyBtZW51IGF0IGFsbCDigJRcbiAqICB0aGUgdmlldyBvcGVucyBub25lIHdoZW4gbm90aGluZyBpcyBvZmZlcmFibGUsIHdoaWNoIGlzIHRoZSBzdHJvbmdlc3QgZm9ybSBvZlxuICogIFwibm8gYWZmb3JkYW5jZVwiLiAqL1xuZnVuY3Rpb24gbWVudUxhYmVsc0ZvcihsYWJlbDogc3RyaW5nKTogc3RyaW5nW10ge1xuICBmaXJlRXZlbnQuY29udGV4dE1lbnUoc2NyZWVuLmdldEJ5VGV4dChsYWJlbCkpO1xuICBjb25zdCBtZW51ID0gc2NyZWVuLnF1ZXJ5QnlSb2xlKFwibWVudVwiKTtcbiAgcmV0dXJuIG1lbnVcbiAgICA/IHdpdGhpbihtZW51KVxuICAgICAgICAucXVlcnlBbGxCeVJvbGUoXCJtZW51aXRlbVwiKVxuICAgICAgICAubWFwKChlbCkgPT4gZWwudGV4dENvbnRlbnQgPz8gXCJcIilcbiAgICA6IFtdO1xufVxuXG5iZWZvcmVFYWNoKCgpID0+IHtcbiAgaC5tb3VudHMgPSBbc3BhY2UoKV07XG4gIGgucmVhZGRpci5tb2NrUmVzZXQoKTtcbiAgaC5yZWFkZGlyLm1vY2tJbXBsZW1lbnRhdGlvbigocGF0aDogc3RyaW5nKSA9PiBQcm9taXNlLnJlc29sdmUoVFJFRVtwYXRoXSA/PyBbXSkpO1xuICBoLnJlYWRGaWxlLm1vY2tSZXNldCgpO1xuICBoLnJlYWRGaWxlLm1vY2tJbXBsZW1lbnRhdGlvbigocGF0aDogc3RyaW5nKSA9PlxuICAgIE1BUktFUlNbcGF0aF0gIT09IHVuZGVmaW5lZFxuICAgICAgPyBQcm9taXNlLnJlc29sdmUobmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKE1BUktFUlNbcGF0aF0pKVxuICAgICAgOiBQcm9taXNlLnJlamVjdChPYmplY3QuYXNzaWduKG5ldyBFcnJvcihcIkVOT0VOVFwiKSwgeyBjb2RlOiBcIkVOT0VOVFwiIH0pKSxcbiAgKTtcbiAgaC5pbnZva2VUYXNrLm1vY2tSZXNldCgpO1xuICBoLmludm9rZVRhc2subW9ja1Jlc29sdmVkVmFsdWUoeyBvcGVuZWQ6IHRydWUgfSk7XG4gIGgubGF1bmNoLm1vY2tSZXNldCgpO1xuICBoLmxhdW5jaC5tb2NrUmVzb2x2ZWRWYWx1ZSh7IGxhdW5jaElkOiBcImxhdW5jaC0xXCIsIG9uRGlzbWlzczogKCkgPT4gKCkgPT4ge30gfSk7XG59KTtcblxuYWZ0ZXJFYWNoKCgpID0+IHZpLmNsZWFyQWxsTW9ja3MoKSk7XG5cbmRlc2NyaWJlKFwiUjMtMjY3IOKAlCBhIGZvbGRlcidzIG9wZW5zV2l0aCBtYXJrZXIgZmluYWxseSBoYXMgYSBjYWxsZXJcIiwgKCkgPT4ge1xuICBpdChcIm9mZmVycyBhIG1hcmtlZCBmb2xkZXIgYnkgaXRzIEtJTkQsIGFuZCBvcGVucyBpdCB3aXRoIHRoZSBjb250cmFjdCB0aGUgbWFya2VyIG5hbWVzXCIsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCB1c2VyID0gdXNlckV2ZW50LnNldHVwKCk7XG4gICAgcmVuZGVyKDxGaWxlRXhwbG9yZXIgLz4pO1xuICAgIGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KFwiaGFuZGJvb2tcIik7XG4gICAgLy8gVGhlIHByb2JlIHJpZGVzIHRoZSBsaXN0aW5nIHRoZSBleHBsb3JlciBhbHJlYWR5IGRpZC5cbiAgICBhd2FpdCB3YWl0Rm9yKCgpID0+IGV4cGVjdChoLnJlYWRGaWxlKS50b0hhdmVCZWVuQ2FsbGVkV2l0aChcIi9zcGFjZXMvczEvaGFuZGJvb2svaW1tZWRpYXRlbHkucnVuLmpzb25cIikpO1xuXG4gICAgY29uc3QgbWVudSA9IGF3YWl0IG1lbnVGb3IoXCJoYW5kYm9va1wiKTtcbiAgICBjb25zdCBpdGVtID0gd2l0aGluKG1lbnUpLmdldEJ5Um9sZShcIm1lbnVpdGVtXCIsIHsgbmFtZTogL09wZW4gYXMgd2lraS8gfSk7XG4gICAgYXdhaXQgdXNlci5jbGljayhpdGVtKTtcblxuICAgIGV4cGVjdChoLmludm9rZVRhc2spLnRvSGF2ZUJlZW5DYWxsZWRUaW1lcygxKTtcbiAgICBjb25zdCBbdGFzaywgcGFyYW1zXSA9IGguaW52b2tlVGFzay5tb2NrLmNhbGxzWzBdIGFzIFtzdHJpbmcsIFJlY29yZDxzdHJpbmcsIHVua25vd24+XTtcbiAgICBleHBlY3QodGFzaykudG9CZShcIm9wZW4td2lraVwiKTtcbiAgICBleHBlY3QocGFyYW1zLmRpcikudG9FcXVhbCh7ICRjYXA6IFwiZGlyXCIsIG1vdW50SWQ6IFwic3BhY2U6czFcIiwgcmVsUGF0aDogXCIvaGFuZGJvb2tcIiwgbW9kZTogXCJyd1wiIH0pO1xuICB9KTtcblxuICBpdChcIm9wZW5zIGEgRElGRkVSRU5UIGNvbnRyYWN0IGZyb20gdGhlIHNhbWUgY29kZSBwYXRoIOKAlCBubyB0YXNrIG5hbWUgaW4gdGhlIGNhbGxlclwiLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgdXNlciA9IHVzZXJFdmVudC5zZXR1cCgpO1xuICAgIHJlbmRlcig8RmlsZUV4cGxvcmVyIC8+KTtcbiAgICBhd2FpdCBzY3JlZW4uZmluZEJ5VGV4dChcImJvYXJkXCIpO1xuICAgIGF3YWl0IHdhaXRGb3IoKCkgPT4gZXhwZWN0KGgucmVhZEZpbGUpLnRvSGF2ZUJlZW5DYWxsZWRXaXRoKFwiL3NwYWNlcy9zMS9ib2FyZC9pbW1lZGlhdGVseS5ydW4uanNvblwiKSk7XG5cbiAgICBjb25zdCBtZW51ID0gYXdhaXQgbWVudUZvcihcImJvYXJkXCIpO1xuICAgIGF3YWl0IHVzZXIuY2xpY2sod2l0aGluKG1lbnUpLmdldEJ5Um9sZShcIm1lbnVpdGVtXCIsIHsgbmFtZTogL09wZW4gYXMgYm9hcmQvIH0pKTtcblxuICAgIGV4cGVjdChoLmludm9rZVRhc2subW9jay5jYWxsc1swXVswXSkudG9CZShcIm9wZW4tcHJvamVjdFwiKTtcbiAgfSk7XG5cbiAgaXQoXCJhIG1hcmtlciBuYW1pbmcgYSBjb250cmFjdCBub3RoaW5nIGlzIGJvdW5kIHRvIGRlZ3JhZGVzIHRvIE5PIGFmZm9yZGFuY2VcIiwgYXN5bmMgKCkgPT4ge1xuICAgIHJlbmRlcig8RmlsZUV4cGxvcmVyIC8+KTtcbiAgICBhd2FpdCBzY3JlZW4uZmluZEJ5VGV4dChcInNrZXRjaGVzXCIpO1xuICAgIGF3YWl0IHdhaXRGb3IoKCkgPT4gZXhwZWN0KGgucmVhZEZpbGUpLnRvSGF2ZUJlZW5DYWxsZWRXaXRoKFwiL3NwYWNlcy9zMS9za2V0Y2hlcy9pbW1lZGlhdGVseS5ydW4uanNvblwiKSk7XG5cbiAgICBleHBlY3QobWVudUxhYmVsc0ZvcihcInNrZXRjaGVzXCIpKS50b0VxdWFsKFtdKTtcbiAgICBleHBlY3QoaC5pbnZva2VUYXNrKS5ub3QudG9IYXZlQmVlbkNhbGxlZCgpO1xuICB9KTtcblxuICBpdChcImFuIG9yZGluYXJ5IGZvbGRlciBnZXRzIG5vIGFmZm9yZGFuY2VcIiwgYXN5bmMgKCkgPT4ge1xuICAgIHJlbmRlcig8RmlsZUV4cGxvcmVyIC8+KTtcbiAgICBhd2FpdCBzY3JlZW4uZmluZEJ5VGV4dChcInNoZWRcIik7XG4gICAgYXdhaXQgd2FpdEZvcigoKSA9PiBleHBlY3QoaC5yZWFkRmlsZSkudG9IYXZlQmVlbkNhbGxlZFdpdGgoXCIvc3BhY2VzL3MxL3NoZWQvaW1tZWRpYXRlbHkucnVuLmpzb25cIikpO1xuXG4gICAgZXhwZWN0KG1lbnVMYWJlbHNGb3IoXCJzaGVkXCIpKS50b0VxdWFsKFtdKTtcbiAgfSk7XG5cbiAgaXQoXCJkZWxlZ2F0ZXMgYXQgdGhlIG1vdW50J3Mgb3duIG1vZGUg4oCUIGEgcm8gc3BhY2Ugb3BlbnMgYSBybyBjb3JwdXMsIG5ldmVyIEVST0ZTLWxhdGVyXCIsIGFzeW5jICgpID0+IHtcbiAgICBoLm1vdW50cyA9IFtzcGFjZSh7IG1vZGU6IFwicm9cIiwgcnVsZXM6IFt7IHN1YnRyZWU6IFwiL1wiLCBtb2RlOiBcInJvXCIgfV0gfSldO1xuICAgIGNvbnN0IHVzZXIgPSB1c2VyRXZlbnQuc2V0dXAoKTtcbiAgICByZW5kZXIoPEZpbGVFeHBsb3JlciAvPik7XG4gICAgYXdhaXQgc2NyZWVuLmZpbmRCeVRleHQoXCJoYW5kYm9va1wiKTtcbiAgICBhd2FpdCB3YWl0Rm9yKCgpID0+IGV4cGVjdChoLnJlYWRGaWxlKS50b0hhdmVCZWVuQ2FsbGVkV2l0aChcIi9zcGFjZXMvczEvaGFuZGJvb2svaW1tZWRpYXRlbHkucnVuLmpzb25cIikpO1xuXG4gICAgYXdhaXQgdXNlci5jbGljayh3aXRoaW4oYXdhaXQgbWVudUZvcihcImhhbmRib29rXCIpKS5nZXRCeVJvbGUoXCJtZW51aXRlbVwiLCB7IG5hbWU6IC9PcGVuIGFzIHdpa2kvIH0pKTtcbiAgICBleHBlY3QoKGguaW52b2tlVGFzay5tb2NrLmNhbGxzWzBdWzFdIGFzIHsgZGlyOiB7IG1vZGU6IHN0cmluZyB9IH0pLmRpci5tb2RlKS50b0JlKFwicm9cIik7XG4gIH0pO1xuXG4gIGl0KFwiYSB1c2VyIGNsb3NpbmcgdGhlIHZpZXdlciAoY2FuY2VsbGVkKSBsZWF2ZXMgdGhlIGFmZm9yZGFuY2UgaW4gcGxhY2VcIiwgYXN5bmMgKCkgPT4ge1xuICAgIGguaW52b2tlVGFzay5tb2NrUmVqZWN0ZWRWYWx1ZShPYmplY3QuYXNzaWduKG5ldyBFcnJvcihcImRpc21pc3NlZFwiKSwgeyBjb2RlOiBcImNhbmNlbGxlZFwiIH0pKTtcbiAgICBjb25zdCB1c2VyID0gdXNlckV2ZW50LnNldHVwKCk7XG4gICAgcmVuZGVyKDxGaWxlRXhwbG9yZXIgLz4pO1xuICAgIGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KFwiaGFuZGJvb2tcIik7XG4gICAgYXdhaXQgd2FpdEZvcigoKSA9PiBleHBlY3QoaC5yZWFkRmlsZSkudG9IYXZlQmVlbkNhbGxlZFdpdGgoXCIvc3BhY2VzL3MxL2hhbmRib29rL2ltbWVkaWF0ZWx5LnJ1bi5qc29uXCIpKTtcblxuICAgIGF3YWl0IHVzZXIuY2xpY2sod2l0aGluKGF3YWl0IG1lbnVGb3IoXCJoYW5kYm9va1wiKSkuZ2V0QnlSb2xlKFwibWVudWl0ZW1cIiwgeyBuYW1lOiAvT3BlbiBhcyB3aWtpLyB9KSk7XG4gICAgYXdhaXQgd2FpdEZvcigoKSA9PiBleHBlY3QoaC5pbnZva2VUYXNrKS50b0hhdmVCZWVuQ2FsbGVkVGltZXMoMSkpO1xuXG4gICAgY29uc3QgYWdhaW4gPSBhd2FpdCBtZW51Rm9yKFwiaGFuZGJvb2tcIik7XG4gICAgZXhwZWN0KHdpdGhpbihhZ2FpbikuZ2V0QnlSb2xlKFwibWVudWl0ZW1cIiwgeyBuYW1lOiAvT3BlbiBhcyB3aWtpLyB9KSkudG9CZUluVGhlRG9jdW1lbnQoKTtcbiAgfSk7XG5cbiAgaXQoXCJhIGhvc3QgcmVmdXNhbCBXSVRIRFJBV1MgdGhlIGFmZm9yZGFuY2UgaW5zdGVhZCBvZiBzaG93aW5nIGEgcHJvdG9jb2wgY29kZVwiLCBhc3luYyAoKSA9PiB7XG4gICAgaC5pbnZva2VUYXNrLm1vY2tSZWplY3RlZFZhbHVlKE9iamVjdC5hc3NpZ24obmV3IEVycm9yKFwibm9wZVwiKSwgeyBjb2RlOiBcIm5vLXN1Y2gtdGFza1wiIH0pKTtcbiAgICBjb25zdCB1c2VyID0gdXNlckV2ZW50LnNldHVwKCk7XG4gICAgcmVuZGVyKDxGaWxlRXhwbG9yZXIgLz4pO1xuICAgIGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KFwiaGFuZGJvb2tcIik7XG4gICAgYXdhaXQgd2FpdEZvcigoKSA9PiBleHBlY3QoaC5yZWFkRmlsZSkudG9IYXZlQmVlbkNhbGxlZFdpdGgoXCIvc3BhY2VzL3MxL2hhbmRib29rL2ltbWVkaWF0ZWx5LnJ1bi5qc29uXCIpKTtcblxuICAgIGF3YWl0IHVzZXIuY2xpY2sod2l0aGluKGF3YWl0IG1lbnVGb3IoXCJoYW5kYm9va1wiKSkuZ2V0QnlSb2xlKFwibWVudWl0ZW1cIiwgeyBuYW1lOiAvT3BlbiBhcyB3aWtpLyB9KSk7XG4gICAgYXdhaXQgd2FpdEZvcigoKSA9PiBleHBlY3QoaC5pbnZva2VUYXNrKS50b0hhdmVCZWVuQ2FsbGVkVGltZXMoMSkpO1xuXG4gICAgLy8gTm8gZXJyb3IgdGV4dCBhbnl3aGVyZSwgYW5kIHRoZSBkZWFkIGFmZm9yZGFuY2UgaXMgZ29uZS5cbiAgICBleHBlY3Qoc2NyZWVuLnF1ZXJ5QnlUZXh0KC9uby1zdWNoLXRhc2svKSkubm90LnRvQmVJblRoZURvY3VtZW50KCk7XG4gICAgYXdhaXQgd2FpdEZvcigoKSA9PiBleHBlY3QobWVudUxhYmVsc0ZvcihcImhhbmRib29rXCIpKS50b0VxdWFsKFtdKSk7XG4gIH0pO1xuXG4gIGl0KFwicHJvYmVzIGVhY2ggbGlzdGVkIGRpcmVjdG9yeSBvbmNlLCBub3Qgb24gZXZlcnkgbWVudSBvcGVuXCIsIGFzeW5jICgpID0+IHtcbiAgICByZW5kZXIoPEZpbGVFeHBsb3JlciAvPik7XG4gICAgYXdhaXQgc2NyZWVuLmZpbmRCeVRleHQoXCJoYW5kYm9va1wiKTtcbiAgICBhd2FpdCB3YWl0Rm9yKCgpID0+IGV4cGVjdChoLnJlYWRGaWxlKS50b0hhdmVCZWVuQ2FsbGVkV2l0aChcIi9zcGFjZXMvczEvaGFuZGJvb2svaW1tZWRpYXRlbHkucnVuLmpzb25cIikpO1xuICAgIGNvbnN0IGFmdGVyID0gaC5yZWFkRmlsZS5tb2NrLmNhbGxzLmZpbHRlcihcbiAgICAgIChjKSA9PiBjWzBdID09PSBcIi9zcGFjZXMvczEvaGFuZGJvb2svaW1tZWRpYXRlbHkucnVuLmpzb25cIixcbiAgICApLmxlbmd0aDtcblxuICAgIGF3YWl0IG1lbnVGb3IoXCJoYW5kYm9va1wiKTtcbiAgICBmaXJlRXZlbnQua2V5RG93bihkb2N1bWVudCwgeyBrZXk6IFwiRXNjYXBlXCIgfSk7XG4gICAgYXdhaXQgbWVudUZvcihcImhhbmRib29rXCIpO1xuXG4gICAgZXhwZWN0KFxuICAgICAgaC5yZWFkRmlsZS5tb2NrLmNhbGxzLmZpbHRlcigoYykgPT4gY1swXSA9PT0gXCIvc3BhY2VzL3MxL2hhbmRib29rL2ltbWVkaWF0ZWx5LnJ1bi5qc29uXCIpLmxlbmd0aCxcbiAgICApLnRvQmUoYWZ0ZXIpO1xuICB9KTtcbn0pO1xuXG5kZXNjcmliZShcIlIzLTE1OSDigJQgYSBsYXVuY2hhYmxlIG1hcmtlciBBTFNPIGdldHMgdGhlIGludG8tc3RhZ2UgYWZmb3JkYW5jZVwiLCAoKSA9PiB7XG4gIGl0KFwib2ZmZXJzICdPcGVuIGluIHBsYWNlJyBmb3IgYW4gb3Blbi1wcm9qZWN0IGZvbGRlciBhbmQgTEFVTkNIRVMgaXQgaW50byB0aGUgc3RhZ2VcIiwgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHVzZXIgPSB1c2VyRXZlbnQuc2V0dXAoKTtcbiAgICByZW5kZXIoPEZpbGVFeHBsb3JlciAvPik7XG4gICAgYXdhaXQgc2NyZWVuLmZpbmRCeVRleHQoXCJib2FyZFwiKTtcbiAgICBhd2FpdCB3YWl0Rm9yKCgpID0+IGV4cGVjdChoLnJlYWRGaWxlKS50b0hhdmVCZWVuQ2FsbGVkV2l0aChcIi9zcGFjZXMvczEvYm9hcmQvaW1tZWRpYXRlbHkucnVuLmpzb25cIikpO1xuXG4gICAgY29uc3QgbWVudSA9IGF3YWl0IG1lbnVGb3IoXCJib2FyZFwiKTtcbiAgICBhd2FpdCB1c2VyLmNsaWNrKHdpdGhpbihtZW51KS5nZXRCeVJvbGUoXCJtZW51aXRlbVwiLCB7IG5hbWU6IC9PcGVuIGluIHBsYWNlLyB9KSk7XG5cbiAgICBleHBlY3QoaC5sYXVuY2gpLnRvSGF2ZUJlZW5DYWxsZWRUaW1lcygxKTtcbiAgICBjb25zdCBbdGFyZ2V0LCBvcHRzXSA9IGgubGF1bmNoLm1vY2suY2FsbHNbMF0gYXMgW1xuICAgICAgeyB0YXNrOiBzdHJpbmcgfSxcbiAgICAgIHsgcmVnaW9uOiBzdHJpbmc7IGlucHV0OiB7IGRpcjogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gfSB9LFxuICAgIF07XG4gICAgZXhwZWN0KHRhcmdldCkudG9FcXVhbCh7IHRhc2s6IFwib3Blbi1wcm9qZWN0XCIgfSk7XG4gICAgZXhwZWN0KG9wdHMucmVnaW9uKS50b0JlKFwic3RhZ2VcIik7XG4gICAgLy8gUi1TQUwtNjogdGhlIGludG8tc3RhZ2UgZGVsZWdhdGlvbiBpcyBybyBldmVuIHRob3VnaCB0aGlzIG1vdW50IGlzIHJ3LlxuICAgIGV4cGVjdChvcHRzLmlucHV0LmRpcikudG9FcXVhbCh7ICRjYXA6IFwiZGlyXCIsIG1vdW50SWQ6IFwic3BhY2U6czFcIiwgcmVsUGF0aDogXCIvYm9hcmRcIiwgbW9kZTogXCJyb1wiIH0pO1xuICAgIC8vIOKApmFuZCB0aGUgZm9yLXJlc3VsdCBpbnZva2UgbmV2ZXIgZmlyZWQuXG4gICAgZXhwZWN0KGguaW52b2tlVGFzaykubm90LnRvSGF2ZUJlZW5DYWxsZWQoKTtcbiAgfSk7XG5cbiAgaXQoXCJvZmZlcnMgQk9USCBhZmZvcmRhbmNlcyBmb3IgYSBsYXVuY2hhYmxlIGNvbnRyYWN0IOKAlCB0aGUgZm9yLXJlc3VsdCBvbmUgbGVhZHNcIiwgYXN5bmMgKCkgPT4ge1xuICAgIHJlbmRlcig8RmlsZUV4cGxvcmVyIC8+KTtcbiAgICBhd2FpdCBzY3JlZW4uZmluZEJ5VGV4dChcImJvYXJkXCIpO1xuICAgIGF3YWl0IHdhaXRGb3IoKCkgPT4gZXhwZWN0KGgucmVhZEZpbGUpLnRvSGF2ZUJlZW5DYWxsZWRXaXRoKFwiL3NwYWNlcy9zMS9ib2FyZC9pbW1lZGlhdGVseS5ydW4uanNvblwiKSk7XG5cbiAgICBleHBlY3QobWVudUxhYmVsc0ZvcihcImJvYXJkXCIpKS50b0VxdWFsKFxuICAgICAgZXhwZWN0LmFycmF5Q29udGFpbmluZyhbXCJPcGVuIGFzIGJvYXJkXCIsIFwiT3BlbiBpbiBwbGFjZVwiXSksXG4gICAgKTtcbiAgICBjb25zdCBsYWJlbHMgPSBtZW51TGFiZWxzRm9yKFwiYm9hcmRcIik7XG4gICAgZXhwZWN0KGxhYmVscy5pbmRleE9mKFwiT3BlbiBhcyBib2FyZFwiKSkudG9CZUxlc3NUaGFuKGxhYmVscy5pbmRleE9mKFwiT3BlbiBpbiBwbGFjZVwiKSk7XG4gIH0pO1xuXG4gIGl0KFwiYW4gaW52b2tlLW9ubHkgY29udHJhY3QgKG9wZW4td2lraSkgZ2V0cyBOTyBpbi1wbGFjZSBhZmZvcmRhbmNlXCIsIGFzeW5jICgpID0+IHtcbiAgICByZW5kZXIoPEZpbGVFeHBsb3JlciAvPik7XG4gICAgYXdhaXQgc2NyZWVuLmZpbmRCeVRleHQoXCJoYW5kYm9va1wiKTtcbiAgICBhd2FpdCB3YWl0Rm9yKCgpID0+IGV4cGVjdChoLnJlYWRGaWxlKS50b0hhdmVCZWVuQ2FsbGVkV2l0aChcIi9zcGFjZXMvczEvaGFuZGJvb2svaW1tZWRpYXRlbHkucnVuLmpzb25cIikpO1xuXG4gICAgY29uc3QgbGFiZWxzID0gbWVudUxhYmVsc0ZvcihcImhhbmRib29rXCIpO1xuICAgIGV4cGVjdChsYWJlbHMpLnRvQ29udGFpbihcIk9wZW4gYXMgd2lraVwiKTtcbiAgICBleHBlY3QobGFiZWxzKS5ub3QudG9Db250YWluKFwiT3BlbiBpbiBwbGFjZVwiKTtcbiAgfSk7XG5cbiAgaXQuZWFjaChbXCJmb3JiaWRkZW5cIiwgXCJ1bnN1cHBvcnRlZFwiXSkoXG4gICAgXCJhIGxhdW5jaCByZWZ1c2FsICglcykgbGVhdmVzIEJPVEggYWZmb3JkYW5jZXMgaW4gcGxhY2Ug4oCUIG5vIGxhdW5jaCBjb2RlIHdpdGhkcmF3c1wiLFxuICAgIGFzeW5jIChjb2RlKSA9PiB7XG4gICAgICAvLyBgZm9yYmlkZGVuYCBpcyB0aGUgZm9yayBjYXNlOyBgdW5zdXBwb3J0ZWRgIGRvdWJsZXMgYXMgYSB0cmFuc2llbnQgaG9zdFxuICAgICAgLy8gc3RhdGUgKGxhdW5jaCBob3N0IG5vdCB5ZXQgbW91bnRlZCksIHNvIGl0IGNhbm5vdCBiZSBhIHNlc3Npb24tcGVybWFuZW50XG4gICAgICAvLyB2ZXJkaWN0IGVpdGhlci4gVGhlIGRlY2xpbmUgaXMgaW52aXNpYmxlIOKAlCBubyBwcm90b2NvbCBjb2RlIG9uIHNjcmVlbi5cbiAgICAgIGgubGF1bmNoLm1vY2tSZXNvbHZlZFZhbHVlKHsgb2s6IGZhbHNlLCBjb2RlIH0pO1xuICAgICAgY29uc3QgdXNlciA9IHVzZXJFdmVudC5zZXR1cCgpO1xuICAgICAgcmVuZGVyKDxGaWxlRXhwbG9yZXIgLz4pO1xuICAgICAgYXdhaXQgc2NyZWVuLmZpbmRCeVRleHQoXCJib2FyZFwiKTtcbiAgICAgIGF3YWl0IHdhaXRGb3IoKCkgPT4gZXhwZWN0KGgucmVhZEZpbGUpLnRvSGF2ZUJlZW5DYWxsZWRXaXRoKFwiL3NwYWNlcy9zMS9ib2FyZC9pbW1lZGlhdGVseS5ydW4uanNvblwiKSk7XG5cbiAgICAgIGF3YWl0IHVzZXIuY2xpY2sod2l0aGluKGF3YWl0IG1lbnVGb3IoXCJib2FyZFwiKSkuZ2V0QnlSb2xlKFwibWVudWl0ZW1cIiwgeyBuYW1lOiAvT3BlbiBpbiBwbGFjZS8gfSkpO1xuICAgICAgYXdhaXQgd2FpdEZvcigoKSA9PiBleHBlY3QoaC5sYXVuY2gpLnRvSGF2ZUJlZW5DYWxsZWRUaW1lcygxKSk7XG5cbiAgICAgIGNvbnN0IGxhYmVscyA9IG1lbnVMYWJlbHNGb3IoXCJib2FyZFwiKTtcbiAgICAgIGV4cGVjdChsYWJlbHMpLnRvQ29udGFpbihcIk9wZW4gaW4gcGxhY2VcIik7XG4gICAgICBleHBlY3QobGFiZWxzKS50b0NvbnRhaW4oXCJPcGVuIGFzIGJvYXJkXCIpO1xuICAgICAgZXhwZWN0KHNjcmVlbi5xdWVyeUJ5VGV4dChuZXcgUmVnRXhwKGNvZGUpKSkubm90LnRvQmVJblRoZURvY3VtZW50KCk7XG4gICAgfSxcbiAgKTtcbn0pO1xuXG5kZXNjcmliZShcIlIzLTc4OSDigJQgYSBkZWNsYXJlZCB2aWV3IGdldHMgaXRzIG93biAnT3BlbiBhcyA8bmFtZT4nICjCpzRiLjFhKVwiLCAoKSA9PiB7XG4gIGNvbnN0IHNldHRsZSA9IGFzeW5jIChkaXI6IHN0cmluZykgPT4ge1xuICAgIGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KGRpcik7XG4gICAgYXdhaXQgd2FpdEZvcigoKSA9PiBleHBlY3QoaC5yZWFkRmlsZSkudG9IYXZlQmVlbkNhbGxlZFdpdGgoYC9zcGFjZXMvczEvJHtkaXJ9L2ltbWVkaWF0ZWx5LnJ1bi5qc29uYCkpO1xuICB9O1xuXG4gIGl0KFwib2ZmZXJzIHRoZSB2aWV3IGJlc2lkZSB0aGUgYnVuZGxlJ3Mgb3duIG9mZmVyLCBhbmQgb3BlbnMgaXQgYnkgTkFNRSB0aHJvdWdoIG9wZW4tZGVjbGFyZWRcIiwgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHVzZXIgPSB1c2VyRXZlbnQuc2V0dXAoKTtcbiAgICByZW5kZXIoPEZpbGVFeHBsb3JlciAvPik7XG4gICAgYXdhaXQgc2V0dGxlKFwiY29udGVudFwiKTtcbiAgICBhd2FpdCB3YWl0Rm9yKCgpID0+IGV4cGVjdChtZW51TGFiZWxzRm9yKFwiY29udGVudFwiKSkudG9Db250YWluKFwiT3BlbiBhcyBSb2FkbWFwIGJvYXJkXCIpKTtcbiAgICBmaXJlRXZlbnQua2V5RG93bihkb2N1bWVudCwgeyBrZXk6IFwiRXNjYXBlXCIgfSk7XG5cbiAgICBjb25zdCBtZW51ID0gYXdhaXQgbWVudUZvcihcImNvbnRlbnRcIik7XG4gICAgZXhwZWN0KHdpdGhpbihtZW51KS5nZXRCeVJvbGUoXCJtZW51aXRlbVwiLCB7IG5hbWU6IC9PcGVuIGFzIHdpa2kvIH0pKS50b0JlSW5UaGVEb2N1bWVudCgpO1xuICAgIGF3YWl0IHVzZXIuY2xpY2sod2l0aGluKG1lbnUpLmdldEJ5Um9sZShcIm1lbnVpdGVtXCIsIHsgbmFtZTogL09wZW4gYXMgUm9hZG1hcCBib2FyZC8gfSkpO1xuXG4gICAgZXhwZWN0KGguaW52b2tlVGFzaykudG9IYXZlQmVlbkNhbGxlZFRpbWVzKDEpO1xuICAgIGNvbnN0IFt0YXNrLCBwYXJhbXNdID0gaC5pbnZva2VUYXNrLm1vY2suY2FsbHNbMF0gYXMgW3N0cmluZywgUmVjb3JkPHN0cmluZywgdW5rbm93bj5dO1xuICAgIGV4cGVjdCh0YXNrKS50b0JlKFwib3Blbi1kZWNsYXJlZFwiKTtcbiAgICAvLyBUaGUgdmlldydzIE5BTUUgYW5kIHRoZSBmb2xkZXIg4oCUIG5ldmVyIGl0cyBhcHAsIG5ldmVyIGFuIGVudHJ5LlxuICAgIGV4cGVjdChwYXJhbXMpLnRvRXF1YWwoe1xuICAgICAgZGlyOiB7ICRjYXA6IFwiZGlyXCIsIG1vdW50SWQ6IFwic3BhY2U6czFcIiwgcmVsUGF0aDogXCIvY29udGVudFwiLCBtb2RlOiBcInJ3XCIgfSxcbiAgICAgIHZpZXc6IFwiUm9hZG1hcCBib2FyZFwiLFxuICAgIH0pO1xuICB9KTtcblxuICBpdChcImEgd2l0aGRyYXduIG9wZW4tZGVjbGFyZWQgcmVtb3ZlcyB0aGUgdmlldyBpdGVtIGFuZCBsZWF2ZXMgdGhlIGJ1bmRsZSdzIG93biBvZmZlclwiLCBhc3luYyAoKSA9PiB7XG4gICAgaC5pbnZva2VUYXNrLm1vY2tSZWplY3RlZFZhbHVlKE9iamVjdC5hc3NpZ24obmV3IEVycm9yKFwibm9wZVwiKSwgeyBjb2RlOiBcIm5vLXN1Y2gtdGFza1wiIH0pKTtcbiAgICBjb25zdCB1c2VyID0gdXNlckV2ZW50LnNldHVwKCk7XG4gICAgcmVuZGVyKDxGaWxlRXhwbG9yZXIgLz4pO1xuICAgIGF3YWl0IHNldHRsZShcImNvbnRlbnRcIik7XG4gICAgYXdhaXQgd2FpdEZvcigoKSA9PiBleHBlY3QobWVudUxhYmVsc0ZvcihcImNvbnRlbnRcIikpLnRvQ29udGFpbihcIk9wZW4gYXMgUm9hZG1hcCBib2FyZFwiKSk7XG4gICAgZmlyZUV2ZW50LmtleURvd24oZG9jdW1lbnQsIHsga2V5OiBcIkVzY2FwZVwiIH0pO1xuXG4gICAgYXdhaXQgdXNlci5jbGljayh3aXRoaW4oYXdhaXQgbWVudUZvcihcImNvbnRlbnRcIikpLmdldEJ5Um9sZShcIm1lbnVpdGVtXCIsIHsgbmFtZTogL09wZW4gYXMgUm9hZG1hcCBib2FyZC8gfSkpO1xuICAgIGF3YWl0IHdhaXRGb3IoKCkgPT4gZXhwZWN0KGguaW52b2tlVGFzaykudG9IYXZlQmVlbkNhbGxlZFRpbWVzKDEpKTtcbiAgICBmaXJlRXZlbnQua2V5RG93bihkb2N1bWVudCwgeyBrZXk6IFwiRXNjYXBlXCIgfSk7XG5cbiAgICBhd2FpdCB3YWl0Rm9yKCgpID0+IGV4cGVjdChtZW51TGFiZWxzRm9yKFwiY29udGVudFwiKSkubm90LnRvQ29udGFpbihcIk9wZW4gYXMgUm9hZG1hcCBib2FyZFwiKSk7XG4gICAgZXhwZWN0KG1lbnVMYWJlbHNGb3IoXCJjb250ZW50XCIpKS50b0NvbnRhaW4oXCJPcGVuIGFzIHdpa2lcIik7XG4gIH0pO1xuXG4gIGl0KFwidmlld3Mgb24gYSBtYXJrZXIgdGhlIGhvc3QgcmVqZWN0cyBhcyBhIHdob2xlIGFyZSBuZXZlciBvZmZlcmVkXCIsIGFzeW5jICgpID0+IHtcbiAgICByZW5kZXIoPEZpbGVFeHBsb3JlciAvPik7XG4gICAgYXdhaXQgc2V0dGxlKFwib3JwaGFuLXZpZXdzXCIpO1xuICAgIGV4cGVjdChtZW51TGFiZWxzRm9yKFwib3JwaGFuLXZpZXdzXCIpKS50b0VxdWFsKFtdKTtcbiAgfSk7XG59KTtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7QUFPQSxJQUFBQSxNQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxVQUFBLEdBQUFDLHNCQUFBLENBQUFGLE9BQUE7QUFDQSxJQUFBRyxPQUFBLEdBQUFILE9BQUE7QUFzR0EsSUFBQUksZ0JBQUEsR0FBQUYsc0JBQUEsQ0FBQUYsT0FBQTtBQUE2QyxJQUFBSyxXQUFBLEdBQUFMLE9BQUE7QUFBQSxTQUFBRSx1QkFBQUksQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQS9HN0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBTUEsTUFBTUcsSUFBZ0MsR0FBRztFQUN2QyxZQUFZLEVBQUUsQ0FDWjtJQUFFQyxJQUFJLEVBQUUsVUFBVTtJQUFFQyxLQUFLLEVBQUU7RUFBSyxDQUFDLEVBQ2pDO0lBQUVELElBQUksRUFBRSxPQUFPO0lBQUVDLEtBQUssRUFBRTtFQUFLLENBQUMsRUFDOUI7SUFBRUQsSUFBSSxFQUFFLFVBQVU7SUFBRUMsS0FBSyxFQUFFO0VBQUssQ0FBQyxFQUNqQztJQUFFRCxJQUFJLEVBQUUsTUFBTTtJQUFFQyxLQUFLLEVBQUU7RUFBSyxDQUFDLEVBQzdCO0lBQUVELElBQUksRUFBRSxTQUFTO0lBQUVDLEtBQUssRUFBRTtFQUFLLENBQUMsRUFDaEM7SUFBRUQsSUFBSSxFQUFFLGNBQWM7SUFBRUMsS0FBSyxFQUFFO0VBQUssQ0FBQyxFQUNyQztJQUFFRCxJQUFJLEVBQUUsU0FBUztJQUFFQyxLQUFLLEVBQUU7RUFBTSxDQUFDLENBQ2xDO0VBQ0Qsb0JBQW9CLEVBQUUsQ0FBQztJQUFFRCxJQUFJLEVBQUUsU0FBUztJQUFFQyxLQUFLLEVBQUU7RUFBSyxDQUFDLENBQUM7RUFDeEQseUJBQXlCLEVBQUUsRUFBRTtFQUM3QixxQkFBcUIsRUFBRSxDQUFDO0lBQUVELElBQUksRUFBRSxVQUFVO0lBQUVDLEtBQUssRUFBRTtFQUFNLENBQUMsQ0FBQztFQUMzRCxrQkFBa0IsRUFBRSxDQUFDO0lBQUVELElBQUksRUFBRSxjQUFjO0lBQUVDLEtBQUssRUFBRTtFQUFNLENBQUMsQ0FBQztFQUM1RCxxQkFBcUIsRUFBRSxFQUFFO0VBQ3pCLGlCQUFpQixFQUFFO0FBQ3JCLENBQUM7O0FBRUQ7QUFDQTtBQUNBLE1BQU1DLE9BQStCLEdBQUc7RUFDdEMsMENBQTBDLEVBQUVDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO0lBQ3pEQyxTQUFTLEVBQUU7TUFBRUMsSUFBSSxFQUFFLFdBQVc7TUFBRUMsT0FBTyxFQUFFO0lBQU0sQ0FBQztJQUNoREMsSUFBSSxFQUFFO0VBQ1IsQ0FBQyxDQUFDO0VBQ0YsdUNBQXVDLEVBQUVMLElBQUksQ0FBQ0MsU0FBUyxDQUFDO0lBQ3REQyxTQUFTLEVBQUU7TUFBRUMsSUFBSSxFQUFFO0lBQWUsQ0FBQztJQUNuQ0UsSUFBSSxFQUFFO0VBQ1IsQ0FBQyxDQUFDO0VBQ0Y7RUFDQTtFQUNBLHlDQUF5QyxFQUFFTCxJQUFJLENBQUNDLFNBQVMsQ0FBQztJQUN4REMsU0FBUyxFQUFFO01BQUVDLElBQUksRUFBRSxXQUFXO01BQUVDLE9BQU8sRUFBRTtJQUFNLENBQUM7SUFDaERDLElBQUksRUFBRSxNQUFNO0lBQ1pDLEtBQUssRUFBRSxDQUNMO01BQ0VULElBQUksRUFBRSxlQUFlO01BQ3JCSyxTQUFTLEVBQUU7UUFBRUssR0FBRyxFQUFFLHFDQUFxQztRQUFFSCxPQUFPLEVBQUU7TUFBTSxDQUFDO01BQ3pFSSxPQUFPLEVBQUU7SUFDWCxDQUFDO0VBRUwsQ0FBQyxDQUFDO0VBQ0YsOENBQThDLEVBQUVSLElBQUksQ0FBQ0MsU0FBUyxDQUFDO0lBQzdESSxJQUFJLEVBQUUsTUFBTTtJQUNaQyxLQUFLLEVBQUUsQ0FBQztNQUFFVCxJQUFJLEVBQUUsT0FBTztNQUFFSyxTQUFTLEVBQUU7UUFBRUssR0FBRyxFQUFFO01BQWEsQ0FBQztNQUFFQyxPQUFPLEVBQUU7SUFBSyxDQUFDO0VBQzVFLENBQUMsQ0FBQztFQUNGLDBDQUEwQyxFQUFFUixJQUFJLENBQUNDLFNBQVMsQ0FBQztJQUN6REMsU0FBUyxFQUFFO01BQUVDLElBQUksRUFBRTtJQUFnQixDQUFDO0lBQ3BDRSxJQUFJLEVBQUU7RUFDUixDQUFDO0FBQ0gsQ0FBQztBQUVELE1BQU1JLENBQUMsR0FBR0MsVUFBRSxDQUFDQyxPQUFPLENBQUMsT0FBTztFQUMxQkMsTUFBTSxFQUFFLEVBQW9DO0VBQzVDQyxPQUFPLEVBQUVILFVBQUUsQ0FBQ0ksRUFBRSxDQUF3QyxNQUFNQyxPQUFPLENBQUNDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQztFQUNoRkMsUUFBUSxFQUFFUCxVQUFFLENBQUNJLEVBQUUsQ0FBd0MsTUFBTUMsT0FBTyxDQUFDRyxNQUFNLENBQUMsSUFBSUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7RUFDakdDLFVBQVUsRUFBRVYsVUFBRSxDQUFDSSxFQUFFLENBQUMsTUFBd0JDLE9BQU8sQ0FBQ0MsT0FBTyxDQUFDO0lBQUVLLE1BQU0sRUFBRTtFQUFLLENBQUMsQ0FBQyxDQUFDO0VBQzVFQyxNQUFNLEVBQUVaLFVBQUUsQ0FBQ0ksRUFBRSxDQUFDLE1BQ1pDLE9BQU8sQ0FBQ0MsT0FBTyxDQUFDO0lBQUVPLFFBQVEsRUFBRSxVQUFVO0lBQUVDLFNBQVMsRUFBRUEsQ0FBQSxLQUFNLE1BQU0sQ0FBQztFQUFFLENBQUMsQ0FDckU7QUFDRixDQUFDLENBQUMsQ0FBQztBQUVIZCxVQUFFLENBQUNlLElBQUksQ0FBQyxtQ0FBbUMsRUFBRSxPQUFPO0VBQ2xEQyxXQUFXLEVBQUVBLENBQUEsS0FBTSxNQUFNLENBQUMsQ0FBQztFQUMzQkMsV0FBVyxFQUFFakIsVUFBRSxDQUFDSSxFQUFFLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUM7QUFFSEosVUFBRSxDQUFDZSxJQUFJLENBQUMsc0JBQXNCLEVBQUUsT0FBTztFQUNyQ0csU0FBUyxFQUFFQSxDQUFBLEtBQU1uQixDQUFDLENBQUNHLE1BQU07RUFDekJpQixnQkFBZ0IsRUFBRUEsQ0FBQSxLQUFNLEVBQUU7RUFDMUJDLGdCQUFnQixFQUFFQSxDQUFBLE1BQU87SUFBRUMsVUFBVSxFQUFFLEVBQUU7SUFBRUMsU0FBUyxFQUFFLEVBQUU7SUFBRUMsVUFBVSxFQUFFLElBQUk7SUFBRUMsVUFBVSxFQUFFO0VBQUssQ0FBQyxDQUFDO0VBQy9GQyxZQUFZLEVBQUV6QixVQUFFLENBQUNJLEVBQUUsQ0FBQyxNQUFNQyxPQUFPLENBQUNDLE9BQU8sQ0FBQyxDQUFDLENBQUM7RUFDNUNvQixVQUFVLEVBQUUxQixVQUFFLENBQUNJLEVBQUUsQ0FBQyxNQUFNQyxPQUFPLENBQUNDLE9BQU8sQ0FBQyxDQUFDLENBQUM7RUFDMUNxQixZQUFZLEVBQUUzQixVQUFFLENBQUNJLEVBQUUsQ0FBQyxNQUFNQyxPQUFPLENBQUNDLE9BQU8sQ0FBQyxDQUFDLENBQUM7RUFDNUNzQixXQUFXLEVBQUU1QixVQUFFLENBQUNJLEVBQUUsQ0FBQyxNQUFNQyxPQUFPLENBQUNDLE9BQU8sQ0FBQyxDQUFDLENBQUM7RUFDM0N1QixXQUFXLEVBQUU3QixVQUFFLENBQUNJLEVBQUUsQ0FBQyxNQUFNQyxPQUFPLENBQUNDLE9BQU8sQ0FBQyxDQUFDLENBQUM7RUFDM0N3QixVQUFVLEVBQUU5QixVQUFFLENBQUNJLEVBQUUsQ0FBQyxNQUFNQyxPQUFPLENBQUNDLE9BQU8sQ0FBQyxDQUFDLENBQUM7RUFDMUN5QixhQUFhLEVBQUUvQixVQUFFLENBQUNJLEVBQUUsQ0FBQyxNQUFNQyxPQUFPLENBQUNDLE9BQU8sQ0FBQyxDQUFDLENBQUM7RUFDN0MwQixjQUFjLEVBQUVoQyxVQUFFLENBQUNJLEVBQUUsQ0FBQyxDQUFDO0VBQ3ZCNkIsWUFBWSxFQUFFakMsVUFBRSxDQUFDSSxFQUFFLENBQUMsTUFBTUMsT0FBTyxDQUFDQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0VBQzVDNEIsZ0JBQWdCLEVBQUVsQyxVQUFFLENBQUNJLEVBQUUsQ0FBQyxNQUFNQyxPQUFPLENBQUNDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQztFQUNsRDZCLGNBQWMsRUFBRW5DLFVBQUUsQ0FBQ0ksRUFBRSxDQUFDLE1BQU1DLE9BQU8sQ0FBQ0MsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDaEQ4QixZQUFZLEVBQUVwQyxVQUFFLENBQUNJLEVBQUUsQ0FBQyxNQUFNLElBQUlDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDaERnQyxTQUFTLEVBQUVBLENBQUEsS0FBTSxJQUFJO0VBQ3JCM0IsVUFBVSxFQUFFQSxDQUFDakIsSUFBWSxFQUFFNkMsTUFBK0IsS0FBS3ZDLENBQUMsQ0FBQ1csVUFBVSxDQUFDakIsSUFBSSxFQUFFNkMsTUFBTSxDQUFDO0VBQ3pGMUIsTUFBTSxFQUFFQSxDQUFDMkIsTUFBZSxFQUFFQyxJQUFhLEtBQUt6QyxDQUFDLENBQUNhLE1BQU0sQ0FBQzJCLE1BQU0sRUFBRUMsSUFBSSxDQUFDO0VBQ2xFQyxNQUFNLEVBQUVBLENBQUNDLEdBQXlDLEVBQUVGLElBQTJCLE1BQU07SUFDbkZHLElBQUksRUFBRSxLQUFLO0lBQ1gsR0FBR0QsR0FBRztJQUNOLEdBQUdGO0VBQ0wsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDO0FBRUh4QyxVQUFFLENBQUNlLElBQUksQ0FBQyxXQUFXLEVBQUUsT0FBTztFQUMxQlosT0FBTyxFQUFHeUMsQ0FBUyxJQUFLN0MsQ0FBQyxDQUFDSSxPQUFPLENBQUN5QyxDQUFDLENBQUM7RUFDcENyQyxRQUFRLEVBQUdxQyxDQUFTLElBQUs3QyxDQUFDLENBQUNRLFFBQVEsQ0FBQ3FDLENBQUMsQ0FBQztFQUN0Q0MsV0FBVyxFQUFFO0lBQUUxQyxPQUFPLEVBQUd5QyxDQUFTLElBQUs3QyxDQUFDLENBQUNJLE9BQU8sQ0FBQ3lDLENBQUMsQ0FBQztJQUFFckMsUUFBUSxFQUFHcUMsQ0FBUyxJQUFLN0MsQ0FBQyxDQUFDUSxRQUFRLENBQUNxQyxDQUFDO0VBQUU7QUFDOUYsQ0FBQyxDQUFDLENBQUM7QUFJSCxNQUFNRSxLQUFLLEdBQUdBLENBQUNDLElBQTZCLEdBQUcsQ0FBQyxDQUFDLE1BQU07RUFDckRDLElBQUksRUFBRSxXQUFXO0VBQ2pCQyxJQUFJLEVBQUUsWUFBWTtFQUNsQkMsRUFBRSxFQUFFLFVBQVU7RUFDZC9ELElBQUksRUFBRSxNQUFNO0VBQ1pnRSxJQUFJLEVBQUUsSUFBSTtFQUNWQyxLQUFLLEVBQUUsQ0FBQztJQUFFdEQsT0FBTyxFQUFFLEdBQUc7SUFBRXFELElBQUksRUFBRTtFQUFLLENBQUMsQ0FBQztFQUNyQyxHQUFHSjtBQUNMLENBQUMsQ0FBQzs7QUFFRjtBQUNBLGVBQWVNLE9BQU9BLENBQUNDLEtBQWEsRUFBRTtFQUNwQ0MsZ0JBQVMsQ0FBQ0MsV0FBVyxDQUFDQyxhQUFNLENBQUNDLFNBQVMsQ0FBQ0osS0FBSyxDQUFDLENBQUM7RUFDOUMsT0FBT0csYUFBTSxDQUFDRSxVQUFVLENBQUMsTUFBTSxDQUFDO0FBQ2xDOztBQUVBO0FBQ0E7QUFDQTtBQUNBLFNBQVNDLGFBQWFBLENBQUNOLEtBQWEsRUFBWTtFQUM5Q0MsZ0JBQVMsQ0FBQ0MsV0FBVyxDQUFDQyxhQUFNLENBQUNDLFNBQVMsQ0FBQ0osS0FBSyxDQUFDLENBQUM7RUFDOUMsTUFBTU8sSUFBSSxHQUFHSixhQUFNLENBQUNLLFdBQVcsQ0FBQyxNQUFNLENBQUM7RUFDdkMsT0FBT0QsSUFBSSxHQUNQLElBQUFFLGFBQU0sRUFBQ0YsSUFBSSxDQUFDLENBQ1RHLGNBQWMsQ0FBQyxVQUFVLENBQUMsQ0FDMUJDLEdBQUcsQ0FBRUMsRUFBRSxJQUFLQSxFQUFFLENBQUNDLFdBQVcsSUFBSSxFQUFFLENBQUMsR0FDcEMsRUFBRTtBQUNSO0FBRUEsSUFBQUMsa0JBQVUsRUFBQyxNQUFNO0VBQ2ZyRSxDQUFDLENBQUNHLE1BQU0sR0FBRyxDQUFDNEMsS0FBSyxDQUFDLENBQUMsQ0FBQztFQUNwQi9DLENBQUMsQ0FBQ0ksT0FBTyxDQUFDa0UsU0FBUyxDQUFDLENBQUM7RUFDckJ0RSxDQUFDLENBQUNJLE9BQU8sQ0FBQ21FLGtCQUFrQixDQUFFckIsSUFBWSxJQUFLNUMsT0FBTyxDQUFDQyxPQUFPLENBQUNwQixJQUFJLENBQUMrRCxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQztFQUNqRmxELENBQUMsQ0FBQ1EsUUFBUSxDQUFDOEQsU0FBUyxDQUFDLENBQUM7RUFDdEJ0RSxDQUFDLENBQUNRLFFBQVEsQ0FBQytELGtCQUFrQixDQUFFckIsSUFBWSxJQUN6QzVELE9BQU8sQ0FBQzRELElBQUksQ0FBQyxLQUFLc0IsU0FBUyxHQUN2QmxFLE9BQU8sQ0FBQ0MsT0FBTyxDQUFDLElBQUlrRSxXQUFXLENBQUMsQ0FBQyxDQUFDQyxNQUFNLENBQUNwRixPQUFPLENBQUM0RCxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQ3hENUMsT0FBTyxDQUFDRyxNQUFNLENBQUNrRSxNQUFNLENBQUNDLE1BQU0sQ0FBQyxJQUFJbEUsS0FBSyxDQUFDLFFBQVEsQ0FBQyxFQUFFO0lBQUVtRSxJQUFJLEVBQUU7RUFBUyxDQUFDLENBQUMsQ0FDM0UsQ0FBQztFQUNEN0UsQ0FBQyxDQUFDVyxVQUFVLENBQUMyRCxTQUFTLENBQUMsQ0FBQztFQUN4QnRFLENBQUMsQ0FBQ1csVUFBVSxDQUFDbUUsaUJBQWlCLENBQUM7SUFBRWxFLE1BQU0sRUFBRTtFQUFLLENBQUMsQ0FBQztFQUNoRFosQ0FBQyxDQUFDYSxNQUFNLENBQUN5RCxTQUFTLENBQUMsQ0FBQztFQUNwQnRFLENBQUMsQ0FBQ2EsTUFBTSxDQUFDaUUsaUJBQWlCLENBQUM7SUFBRWhFLFFBQVEsRUFBRSxVQUFVO0lBQUVDLFNBQVMsRUFBRUEsQ0FBQSxLQUFNLE1BQU0sQ0FBQztFQUFFLENBQUMsQ0FBQztBQUNqRixDQUFDLENBQUM7QUFFRixJQUFBZ0UsaUJBQVMsRUFBQyxNQUFNOUUsVUFBRSxDQUFDK0UsYUFBYSxDQUFDLENBQUMsQ0FBQztBQUVuQyxJQUFBQyxnQkFBUSxFQUFDLDJEQUEyRCxFQUFFLE1BQU07RUFDMUUsSUFBQUMsVUFBRSxFQUFDLHFGQUFxRixFQUFFLFlBQVk7SUFDcEcsTUFBTUMsSUFBSSxHQUFHQyxrQkFBUyxDQUFDQyxLQUFLLENBQUMsQ0FBQztJQUM5QixJQUFBQyxhQUFNLGVBQUMsSUFBQXZHLFdBQUEsQ0FBQXdHLEdBQUEsRUFBQ3pHLGdCQUFBLENBQUFJLE9BQVksSUFBRSxDQUFDLENBQUM7SUFDeEIsTUFBTXdFLGFBQU0sQ0FBQzhCLFVBQVUsQ0FBQyxVQUFVLENBQUM7SUFDbkM7SUFDQSxNQUFNLElBQUFDLGNBQU8sRUFBQyxNQUFNLElBQUFDLGNBQU0sRUFBQzFGLENBQUMsQ0FBQ1EsUUFBUSxDQUFDLENBQUNtRixvQkFBb0IsQ0FBQywwQ0FBMEMsQ0FBQyxDQUFDO0lBRXhHLE1BQU03QixJQUFJLEdBQUcsTUFBTVIsT0FBTyxDQUFDLFVBQVUsQ0FBQztJQUN0QyxNQUFNc0MsSUFBSSxHQUFHLElBQUE1QixhQUFNLEVBQUNGLElBQUksQ0FBQyxDQUFDK0IsU0FBUyxDQUFDLFVBQVUsRUFBRTtNQUFFekcsSUFBSSxFQUFFO0lBQWUsQ0FBQyxDQUFDO0lBQ3pFLE1BQU0rRixJQUFJLENBQUNXLEtBQUssQ0FBQ0YsSUFBSSxDQUFDO0lBRXRCLElBQUFGLGNBQU0sRUFBQzFGLENBQUMsQ0FBQ1csVUFBVSxDQUFDLENBQUNvRixxQkFBcUIsQ0FBQyxDQUFDLENBQUM7SUFDN0MsTUFBTSxDQUFDckcsSUFBSSxFQUFFNkMsTUFBTSxDQUFDLEdBQUd2QyxDQUFDLENBQUNXLFVBQVUsQ0FBQ0ssSUFBSSxDQUFDZ0YsS0FBSyxDQUFDLENBQUMsQ0FBc0M7SUFDdEYsSUFBQU4sY0FBTSxFQUFDaEcsSUFBSSxDQUFDLENBQUN1RyxJQUFJLENBQUMsV0FBVyxDQUFDO0lBQzlCLElBQUFQLGNBQU0sRUFBQ25ELE1BQU0sQ0FBQzJELEdBQUcsQ0FBQyxDQUFDQyxPQUFPLENBQUM7TUFBRXZELElBQUksRUFBRSxLQUFLO01BQUV3RCxPQUFPLEVBQUUsVUFBVTtNQUFFQyxPQUFPLEVBQUUsV0FBVztNQUFFakQsSUFBSSxFQUFFO0lBQUssQ0FBQyxDQUFDO0VBQ3BHLENBQUMsQ0FBQztFQUVGLElBQUE4QixVQUFFLEVBQUMsaUZBQWlGLEVBQUUsWUFBWTtJQUNoRyxNQUFNQyxJQUFJLEdBQUdDLGtCQUFTLENBQUNDLEtBQUssQ0FBQyxDQUFDO0lBQzlCLElBQUFDLGFBQU0sZUFBQyxJQUFBdkcsV0FBQSxDQUFBd0csR0FBQSxFQUFDekcsZ0JBQUEsQ0FBQUksT0FBWSxJQUFFLENBQUMsQ0FBQztJQUN4QixNQUFNd0UsYUFBTSxDQUFDOEIsVUFBVSxDQUFDLE9BQU8sQ0FBQztJQUNoQyxNQUFNLElBQUFDLGNBQU8sRUFBQyxNQUFNLElBQUFDLGNBQU0sRUFBQzFGLENBQUMsQ0FBQ1EsUUFBUSxDQUFDLENBQUNtRixvQkFBb0IsQ0FBQyx1Q0FBdUMsQ0FBQyxDQUFDO0lBRXJHLE1BQU03QixJQUFJLEdBQUcsTUFBTVIsT0FBTyxDQUFDLE9BQU8sQ0FBQztJQUNuQyxNQUFNNkIsSUFBSSxDQUFDVyxLQUFLLENBQUMsSUFBQTlCLGFBQU0sRUFBQ0YsSUFBSSxDQUFDLENBQUMrQixTQUFTLENBQUMsVUFBVSxFQUFFO01BQUV6RyxJQUFJLEVBQUU7SUFBZ0IsQ0FBQyxDQUFDLENBQUM7SUFFL0UsSUFBQXNHLGNBQU0sRUFBQzFGLENBQUMsQ0FBQ1csVUFBVSxDQUFDSyxJQUFJLENBQUNnRixLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLGNBQWMsQ0FBQztFQUM1RCxDQUFDLENBQUM7RUFFRixJQUFBZixVQUFFLEVBQUMsMEVBQTBFLEVBQUUsWUFBWTtJQUN6RixJQUFBSSxhQUFNLGVBQUMsSUFBQXZHLFdBQUEsQ0FBQXdHLEdBQUEsRUFBQ3pHLGdCQUFBLENBQUFJLE9BQVksSUFBRSxDQUFDLENBQUM7SUFDeEIsTUFBTXdFLGFBQU0sQ0FBQzhCLFVBQVUsQ0FBQyxVQUFVLENBQUM7SUFDbkMsTUFBTSxJQUFBQyxjQUFPLEVBQUMsTUFBTSxJQUFBQyxjQUFNLEVBQUMxRixDQUFDLENBQUNRLFFBQVEsQ0FBQyxDQUFDbUYsb0JBQW9CLENBQUMsMENBQTBDLENBQUMsQ0FBQztJQUV4RyxJQUFBRCxjQUFNLEVBQUM3QixhQUFhLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQ3NDLE9BQU8sQ0FBQyxFQUFFLENBQUM7SUFDN0MsSUFBQVQsY0FBTSxFQUFDMUYsQ0FBQyxDQUFDVyxVQUFVLENBQUMsQ0FBQzJGLEdBQUcsQ0FBQ0MsZ0JBQWdCLENBQUMsQ0FBQztFQUM3QyxDQUFDLENBQUM7RUFFRixJQUFBckIsVUFBRSxFQUFDLHVDQUF1QyxFQUFFLFlBQVk7SUFDdEQsSUFBQUksYUFBTSxlQUFDLElBQUF2RyxXQUFBLENBQUF3RyxHQUFBLEVBQUN6RyxnQkFBQSxDQUFBSSxPQUFZLElBQUUsQ0FBQyxDQUFDO0lBQ3hCLE1BQU13RSxhQUFNLENBQUM4QixVQUFVLENBQUMsTUFBTSxDQUFDO0lBQy9CLE1BQU0sSUFBQUMsY0FBTyxFQUFDLE1BQU0sSUFBQUMsY0FBTSxFQUFDMUYsQ0FBQyxDQUFDUSxRQUFRLENBQUMsQ0FBQ21GLG9CQUFvQixDQUFDLHNDQUFzQyxDQUFDLENBQUM7SUFFcEcsSUFBQUQsY0FBTSxFQUFDN0IsYUFBYSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUNzQyxPQUFPLENBQUMsRUFBRSxDQUFDO0VBQzNDLENBQUMsQ0FBQztFQUVGLElBQUFqQixVQUFFLEVBQUMscUZBQXFGLEVBQUUsWUFBWTtJQUNwR2xGLENBQUMsQ0FBQ0csTUFBTSxHQUFHLENBQUM0QyxLQUFLLENBQUM7TUFBRUssSUFBSSxFQUFFLElBQUk7TUFBRUMsS0FBSyxFQUFFLENBQUM7UUFBRXRELE9BQU8sRUFBRSxHQUFHO1FBQUVxRCxJQUFJLEVBQUU7TUFBSyxDQUFDO0lBQUUsQ0FBQyxDQUFDLENBQUM7SUFDekUsTUFBTStCLElBQUksR0FBR0Msa0JBQVMsQ0FBQ0MsS0FBSyxDQUFDLENBQUM7SUFDOUIsSUFBQUMsYUFBTSxlQUFDLElBQUF2RyxXQUFBLENBQUF3RyxHQUFBLEVBQUN6RyxnQkFBQSxDQUFBSSxPQUFZLElBQUUsQ0FBQyxDQUFDO0lBQ3hCLE1BQU13RSxhQUFNLENBQUM4QixVQUFVLENBQUMsVUFBVSxDQUFDO0lBQ25DLE1BQU0sSUFBQUMsY0FBTyxFQUFDLE1BQU0sSUFBQUMsY0FBTSxFQUFDMUYsQ0FBQyxDQUFDUSxRQUFRLENBQUMsQ0FBQ21GLG9CQUFvQixDQUFDLDBDQUEwQyxDQUFDLENBQUM7SUFFeEcsTUFBTVIsSUFBSSxDQUFDVyxLQUFLLENBQUMsSUFBQTlCLGFBQU0sRUFBQyxNQUFNVixPQUFPLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQ3VDLFNBQVMsQ0FBQyxVQUFVLEVBQUU7TUFBRXpHLElBQUksRUFBRTtJQUFlLENBQUMsQ0FBQyxDQUFDO0lBQ25HLElBQUFzRyxjQUFNLEVBQUUxRixDQUFDLENBQUNXLFVBQVUsQ0FBQ0ssSUFBSSxDQUFDZ0YsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUErQkUsR0FBRyxDQUFDOUMsSUFBSSxDQUFDLENBQUM2QyxJQUFJLENBQUMsSUFBSSxDQUFDO0VBQzFGLENBQUMsQ0FBQztFQUVGLElBQUFmLFVBQUUsRUFBQyxzRUFBc0UsRUFBRSxZQUFZO0lBQ3JGbEYsQ0FBQyxDQUFDVyxVQUFVLENBQUM2RixpQkFBaUIsQ0FBQzdCLE1BQU0sQ0FBQ0MsTUFBTSxDQUFDLElBQUlsRSxLQUFLLENBQUMsV0FBVyxDQUFDLEVBQUU7TUFBRW1FLElBQUksRUFBRTtJQUFZLENBQUMsQ0FBQyxDQUFDO0lBQzVGLE1BQU1NLElBQUksR0FBR0Msa0JBQVMsQ0FBQ0MsS0FBSyxDQUFDLENBQUM7SUFDOUIsSUFBQUMsYUFBTSxlQUFDLElBQUF2RyxXQUFBLENBQUF3RyxHQUFBLEVBQUN6RyxnQkFBQSxDQUFBSSxPQUFZLElBQUUsQ0FBQyxDQUFDO0lBQ3hCLE1BQU13RSxhQUFNLENBQUM4QixVQUFVLENBQUMsVUFBVSxDQUFDO0lBQ25DLE1BQU0sSUFBQUMsY0FBTyxFQUFDLE1BQU0sSUFBQUMsY0FBTSxFQUFDMUYsQ0FBQyxDQUFDUSxRQUFRLENBQUMsQ0FBQ21GLG9CQUFvQixDQUFDLDBDQUEwQyxDQUFDLENBQUM7SUFFeEcsTUFBTVIsSUFBSSxDQUFDVyxLQUFLLENBQUMsSUFBQTlCLGFBQU0sRUFBQyxNQUFNVixPQUFPLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQ3VDLFNBQVMsQ0FBQyxVQUFVLEVBQUU7TUFBRXpHLElBQUksRUFBRTtJQUFlLENBQUMsQ0FBQyxDQUFDO0lBQ25HLE1BQU0sSUFBQXFHLGNBQU8sRUFBQyxNQUFNLElBQUFDLGNBQU0sRUFBQzFGLENBQUMsQ0FBQ1csVUFBVSxDQUFDLENBQUNvRixxQkFBcUIsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUVsRSxNQUFNVSxLQUFLLEdBQUcsTUFBTW5ELE9BQU8sQ0FBQyxVQUFVLENBQUM7SUFDdkMsSUFBQW9DLGNBQU0sRUFBQyxJQUFBMUIsYUFBTSxFQUFDeUMsS0FBSyxDQUFDLENBQUNaLFNBQVMsQ0FBQyxVQUFVLEVBQUU7TUFBRXpHLElBQUksRUFBRTtJQUFlLENBQUMsQ0FBQyxDQUFDLENBQUNzSCxpQkFBaUIsQ0FBQyxDQUFDO0VBQzNGLENBQUMsQ0FBQztFQUVGLElBQUF4QixVQUFFLEVBQUMsNEVBQTRFLEVBQUUsWUFBWTtJQUMzRmxGLENBQUMsQ0FBQ1csVUFBVSxDQUFDNkYsaUJBQWlCLENBQUM3QixNQUFNLENBQUNDLE1BQU0sQ0FBQyxJQUFJbEUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxFQUFFO01BQUVtRSxJQUFJLEVBQUU7SUFBZSxDQUFDLENBQUMsQ0FBQztJQUMxRixNQUFNTSxJQUFJLEdBQUdDLGtCQUFTLENBQUNDLEtBQUssQ0FBQyxDQUFDO0lBQzlCLElBQUFDLGFBQU0sZUFBQyxJQUFBdkcsV0FBQSxDQUFBd0csR0FBQSxFQUFDekcsZ0JBQUEsQ0FBQUksT0FBWSxJQUFFLENBQUMsQ0FBQztJQUN4QixNQUFNd0UsYUFBTSxDQUFDOEIsVUFBVSxDQUFDLFVBQVUsQ0FBQztJQUNuQyxNQUFNLElBQUFDLGNBQU8sRUFBQyxNQUFNLElBQUFDLGNBQU0sRUFBQzFGLENBQUMsQ0FBQ1EsUUFBUSxDQUFDLENBQUNtRixvQkFBb0IsQ0FBQywwQ0FBMEMsQ0FBQyxDQUFDO0lBRXhHLE1BQU1SLElBQUksQ0FBQ1csS0FBSyxDQUFDLElBQUE5QixhQUFNLEVBQUMsTUFBTVYsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUN1QyxTQUFTLENBQUMsVUFBVSxFQUFFO01BQUV6RyxJQUFJLEVBQUU7SUFBZSxDQUFDLENBQUMsQ0FBQztJQUNuRyxNQUFNLElBQUFxRyxjQUFPLEVBQUMsTUFBTSxJQUFBQyxjQUFNLEVBQUMxRixDQUFDLENBQUNXLFVBQVUsQ0FBQyxDQUFDb0YscUJBQXFCLENBQUMsQ0FBQyxDQUFDLENBQUM7O0lBRWxFO0lBQ0EsSUFBQUwsY0FBTSxFQUFDaEMsYUFBTSxDQUFDaUQsV0FBVyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUNMLEdBQUcsQ0FBQ0ksaUJBQWlCLENBQUMsQ0FBQztJQUNsRSxNQUFNLElBQUFqQixjQUFPLEVBQUMsTUFBTSxJQUFBQyxjQUFNLEVBQUM3QixhQUFhLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQ3NDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQztFQUNwRSxDQUFDLENBQUM7RUFFRixJQUFBakIsVUFBRSxFQUFDLDJEQUEyRCxFQUFFLFlBQVk7SUFDMUUsSUFBQUksYUFBTSxlQUFDLElBQUF2RyxXQUFBLENBQUF3RyxHQUFBLEVBQUN6RyxnQkFBQSxDQUFBSSxPQUFZLElBQUUsQ0FBQyxDQUFDO0lBQ3hCLE1BQU13RSxhQUFNLENBQUM4QixVQUFVLENBQUMsVUFBVSxDQUFDO0lBQ25DLE1BQU0sSUFBQUMsY0FBTyxFQUFDLE1BQU0sSUFBQUMsY0FBTSxFQUFDMUYsQ0FBQyxDQUFDUSxRQUFRLENBQUMsQ0FBQ21GLG9CQUFvQixDQUFDLDBDQUEwQyxDQUFDLENBQUM7SUFDeEcsTUFBTWlCLEtBQUssR0FBRzVHLENBQUMsQ0FBQ1EsUUFBUSxDQUFDUSxJQUFJLENBQUNnRixLQUFLLENBQUNhLE1BQU0sQ0FDdkNDLENBQUMsSUFBS0EsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLDBDQUNsQixDQUFDLENBQUNDLE1BQU07SUFFUixNQUFNekQsT0FBTyxDQUFDLFVBQVUsQ0FBQztJQUN6QkUsZ0JBQVMsQ0FBQ3dELE9BQU8sQ0FBQ0MsUUFBUSxFQUFFO01BQUVDLEdBQUcsRUFBRTtJQUFTLENBQUMsQ0FBQztJQUM5QyxNQUFNNUQsT0FBTyxDQUFDLFVBQVUsQ0FBQztJQUV6QixJQUFBb0MsY0FBTSxFQUNKMUYsQ0FBQyxDQUFDUSxRQUFRLENBQUNRLElBQUksQ0FBQ2dGLEtBQUssQ0FBQ2EsTUFBTSxDQUFFQyxDQUFDLElBQUtBLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSywwQ0FBMEMsQ0FBQyxDQUFDQyxNQUMzRixDQUFDLENBQUNkLElBQUksQ0FBQ1csS0FBSyxDQUFDO0VBQ2YsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDO0FBRUYsSUFBQTNCLGdCQUFRLEVBQUMsa0VBQWtFLEVBQUUsTUFBTTtFQUNqRixJQUFBQyxVQUFFLEVBQUMsa0ZBQWtGLEVBQUUsWUFBWTtJQUNqRyxNQUFNQyxJQUFJLEdBQUdDLGtCQUFTLENBQUNDLEtBQUssQ0FBQyxDQUFDO0lBQzlCLElBQUFDLGFBQU0sZUFBQyxJQUFBdkcsV0FBQSxDQUFBd0csR0FBQSxFQUFDekcsZ0JBQUEsQ0FBQUksT0FBWSxJQUFFLENBQUMsQ0FBQztJQUN4QixNQUFNd0UsYUFBTSxDQUFDOEIsVUFBVSxDQUFDLE9BQU8sQ0FBQztJQUNoQyxNQUFNLElBQUFDLGNBQU8sRUFBQyxNQUFNLElBQUFDLGNBQU0sRUFBQzFGLENBQUMsQ0FBQ1EsUUFBUSxDQUFDLENBQUNtRixvQkFBb0IsQ0FBQyx1Q0FBdUMsQ0FBQyxDQUFDO0lBRXJHLE1BQU03QixJQUFJLEdBQUcsTUFBTVIsT0FBTyxDQUFDLE9BQU8sQ0FBQztJQUNuQyxNQUFNNkIsSUFBSSxDQUFDVyxLQUFLLENBQUMsSUFBQTlCLGFBQU0sRUFBQ0YsSUFBSSxDQUFDLENBQUMrQixTQUFTLENBQUMsVUFBVSxFQUFFO01BQUV6RyxJQUFJLEVBQUU7SUFBZ0IsQ0FBQyxDQUFDLENBQUM7SUFFL0UsSUFBQXNHLGNBQU0sRUFBQzFGLENBQUMsQ0FBQ2EsTUFBTSxDQUFDLENBQUNrRixxQkFBcUIsQ0FBQyxDQUFDLENBQUM7SUFDekMsTUFBTSxDQUFDdkQsTUFBTSxFQUFFQyxJQUFJLENBQUMsR0FBR3pDLENBQUMsQ0FBQ2EsTUFBTSxDQUFDRyxJQUFJLENBQUNnRixLQUFLLENBQUMsQ0FBQyxDQUczQztJQUNELElBQUFOLGNBQU0sRUFBQ2xELE1BQU0sQ0FBQyxDQUFDMkQsT0FBTyxDQUFDO01BQUV6RyxJQUFJLEVBQUU7SUFBZSxDQUFDLENBQUM7SUFDaEQsSUFBQWdHLGNBQU0sRUFBQ2pELElBQUksQ0FBQzBFLE1BQU0sQ0FBQyxDQUFDbEIsSUFBSSxDQUFDLE9BQU8sQ0FBQztJQUNqQztJQUNBLElBQUFQLGNBQU0sRUFBQ2pELElBQUksQ0FBQzJFLEtBQUssQ0FBQ2xCLEdBQUcsQ0FBQyxDQUFDQyxPQUFPLENBQUM7TUFBRXZELElBQUksRUFBRSxLQUFLO01BQUV3RCxPQUFPLEVBQUUsVUFBVTtNQUFFQyxPQUFPLEVBQUUsUUFBUTtNQUFFakQsSUFBSSxFQUFFO0lBQUssQ0FBQyxDQUFDO0lBQ25HO0lBQ0EsSUFBQXNDLGNBQU0sRUFBQzFGLENBQUMsQ0FBQ1csVUFBVSxDQUFDLENBQUMyRixHQUFHLENBQUNDLGdCQUFnQixDQUFDLENBQUM7RUFDN0MsQ0FBQyxDQUFDO0VBRUYsSUFBQXJCLFVBQUUsRUFBQyw4RUFBOEUsRUFBRSxZQUFZO0lBQzdGLElBQUFJLGFBQU0sZUFBQyxJQUFBdkcsV0FBQSxDQUFBd0csR0FBQSxFQUFDekcsZ0JBQUEsQ0FBQUksT0FBWSxJQUFFLENBQUMsQ0FBQztJQUN4QixNQUFNd0UsYUFBTSxDQUFDOEIsVUFBVSxDQUFDLE9BQU8sQ0FBQztJQUNoQyxNQUFNLElBQUFDLGNBQU8sRUFBQyxNQUFNLElBQUFDLGNBQU0sRUFBQzFGLENBQUMsQ0FBQ1EsUUFBUSxDQUFDLENBQUNtRixvQkFBb0IsQ0FBQyx1Q0FBdUMsQ0FBQyxDQUFDO0lBRXJHLElBQUFELGNBQU0sRUFBQzdCLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDc0MsT0FBTyxDQUNwQ1QsY0FBTSxDQUFDMkIsZUFBZSxDQUFDLENBQUMsZUFBZSxFQUFFLGVBQWUsQ0FBQyxDQUMzRCxDQUFDO0lBQ0QsTUFBTUMsTUFBTSxHQUFHekQsYUFBYSxDQUFDLE9BQU8sQ0FBQztJQUNyQyxJQUFBNkIsY0FBTSxFQUFDNEIsTUFBTSxDQUFDQyxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQ0MsWUFBWSxDQUFDRixNQUFNLENBQUNDLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQztFQUN2RixDQUFDLENBQUM7RUFFRixJQUFBckMsVUFBRSxFQUFDLGlFQUFpRSxFQUFFLFlBQVk7SUFDaEYsSUFBQUksYUFBTSxlQUFDLElBQUF2RyxXQUFBLENBQUF3RyxHQUFBLEVBQUN6RyxnQkFBQSxDQUFBSSxPQUFZLElBQUUsQ0FBQyxDQUFDO0lBQ3hCLE1BQU13RSxhQUFNLENBQUM4QixVQUFVLENBQUMsVUFBVSxDQUFDO0lBQ25DLE1BQU0sSUFBQUMsY0FBTyxFQUFDLE1BQU0sSUFBQUMsY0FBTSxFQUFDMUYsQ0FBQyxDQUFDUSxRQUFRLENBQUMsQ0FBQ21GLG9CQUFvQixDQUFDLDBDQUEwQyxDQUFDLENBQUM7SUFFeEcsTUFBTTJCLE1BQU0sR0FBR3pELGFBQWEsQ0FBQyxVQUFVLENBQUM7SUFDeEMsSUFBQTZCLGNBQU0sRUFBQzRCLE1BQU0sQ0FBQyxDQUFDRyxTQUFTLENBQUMsY0FBYyxDQUFDO0lBQ3hDLElBQUEvQixjQUFNLEVBQUM0QixNQUFNLENBQUMsQ0FBQ2hCLEdBQUcsQ0FBQ21CLFNBQVMsQ0FBQyxlQUFlLENBQUM7RUFDL0MsQ0FBQyxDQUFDO0VBRUZ2QyxVQUFFLENBQUN3QyxJQUFJLENBQUMsQ0FBQyxXQUFXLEVBQUUsYUFBYSxDQUFDLENBQUMsQ0FDbkMsbUZBQW1GLEVBQ25GLE1BQU83QyxJQUFJLElBQUs7SUFDZDtJQUNBO0lBQ0E7SUFDQTdFLENBQUMsQ0FBQ2EsTUFBTSxDQUFDaUUsaUJBQWlCLENBQUM7TUFBRTZDLEVBQUUsRUFBRSxLQUFLO01BQUU5QztJQUFLLENBQUMsQ0FBQztJQUMvQyxNQUFNTSxJQUFJLEdBQUdDLGtCQUFTLENBQUNDLEtBQUssQ0FBQyxDQUFDO0lBQzlCLElBQUFDLGFBQU0sZUFBQyxJQUFBdkcsV0FBQSxDQUFBd0csR0FBQSxFQUFDekcsZ0JBQUEsQ0FBQUksT0FBWSxJQUFFLENBQUMsQ0FBQztJQUN4QixNQUFNd0UsYUFBTSxDQUFDOEIsVUFBVSxDQUFDLE9BQU8sQ0FBQztJQUNoQyxNQUFNLElBQUFDLGNBQU8sRUFBQyxNQUFNLElBQUFDLGNBQU0sRUFBQzFGLENBQUMsQ0FBQ1EsUUFBUSxDQUFDLENBQUNtRixvQkFBb0IsQ0FBQyx1Q0FBdUMsQ0FBQyxDQUFDO0lBRXJHLE1BQU1SLElBQUksQ0FBQ1csS0FBSyxDQUFDLElBQUE5QixhQUFNLEVBQUMsTUFBTVYsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUN1QyxTQUFTLENBQUMsVUFBVSxFQUFFO01BQUV6RyxJQUFJLEVBQUU7SUFBZ0IsQ0FBQyxDQUFDLENBQUM7SUFDakcsTUFBTSxJQUFBcUcsY0FBTyxFQUFDLE1BQU0sSUFBQUMsY0FBTSxFQUFDMUYsQ0FBQyxDQUFDYSxNQUFNLENBQUMsQ0FBQ2tGLHFCQUFxQixDQUFDLENBQUMsQ0FBQyxDQUFDO0lBRTlELE1BQU11QixNQUFNLEdBQUd6RCxhQUFhLENBQUMsT0FBTyxDQUFDO0lBQ3JDLElBQUE2QixjQUFNLEVBQUM0QixNQUFNLENBQUMsQ0FBQ0csU0FBUyxDQUFDLGVBQWUsQ0FBQztJQUN6QyxJQUFBL0IsY0FBTSxFQUFDNEIsTUFBTSxDQUFDLENBQUNHLFNBQVMsQ0FBQyxlQUFlLENBQUM7SUFDekMsSUFBQS9CLGNBQU0sRUFBQ2hDLGFBQU0sQ0FBQ2lELFdBQVcsQ0FBQyxJQUFJaUIsTUFBTSxDQUFDL0MsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDeUIsR0FBRyxDQUFDSSxpQkFBaUIsQ0FBQyxDQUFDO0VBQ3RFLENBQ0YsQ0FBQztBQUNILENBQUMsQ0FBQztBQUVGLElBQUF6QixnQkFBUSxFQUFDLGlFQUFpRSxFQUFFLE1BQU07RUFDaEYsTUFBTTRDLE1BQU0sR0FBRyxNQUFPM0IsR0FBVyxJQUFLO0lBQ3BDLE1BQU14QyxhQUFNLENBQUM4QixVQUFVLENBQUNVLEdBQUcsQ0FBQztJQUM1QixNQUFNLElBQUFULGNBQU8sRUFBQyxNQUFNLElBQUFDLGNBQU0sRUFBQzFGLENBQUMsQ0FBQ1EsUUFBUSxDQUFDLENBQUNtRixvQkFBb0IsQ0FBQyxjQUFjTyxHQUFHLHVCQUF1QixDQUFDLENBQUM7RUFDeEcsQ0FBQztFQUVELElBQUFoQixVQUFFLEVBQUMsMkZBQTJGLEVBQUUsWUFBWTtJQUMxRyxNQUFNQyxJQUFJLEdBQUdDLGtCQUFTLENBQUNDLEtBQUssQ0FBQyxDQUFDO0lBQzlCLElBQUFDLGFBQU0sZUFBQyxJQUFBdkcsV0FBQSxDQUFBd0csR0FBQSxFQUFDekcsZ0JBQUEsQ0FBQUksT0FBWSxJQUFFLENBQUMsQ0FBQztJQUN4QixNQUFNMkksTUFBTSxDQUFDLFNBQVMsQ0FBQztJQUN2QixNQUFNLElBQUFwQyxjQUFPLEVBQUMsTUFBTSxJQUFBQyxjQUFNLEVBQUM3QixhQUFhLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQzRELFNBQVMsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO0lBQ3hGakUsZ0JBQVMsQ0FBQ3dELE9BQU8sQ0FBQ0MsUUFBUSxFQUFFO01BQUVDLEdBQUcsRUFBRTtJQUFTLENBQUMsQ0FBQztJQUU5QyxNQUFNcEQsSUFBSSxHQUFHLE1BQU1SLE9BQU8sQ0FBQyxTQUFTLENBQUM7SUFDckMsSUFBQW9DLGNBQU0sRUFBQyxJQUFBMUIsYUFBTSxFQUFDRixJQUFJLENBQUMsQ0FBQytCLFNBQVMsQ0FBQyxVQUFVLEVBQUU7TUFBRXpHLElBQUksRUFBRTtJQUFlLENBQUMsQ0FBQyxDQUFDLENBQUNzSCxpQkFBaUIsQ0FBQyxDQUFDO0lBQ3hGLE1BQU12QixJQUFJLENBQUNXLEtBQUssQ0FBQyxJQUFBOUIsYUFBTSxFQUFDRixJQUFJLENBQUMsQ0FBQytCLFNBQVMsQ0FBQyxVQUFVLEVBQUU7TUFBRXpHLElBQUksRUFBRTtJQUF3QixDQUFDLENBQUMsQ0FBQztJQUV2RixJQUFBc0csY0FBTSxFQUFDMUYsQ0FBQyxDQUFDVyxVQUFVLENBQUMsQ0FBQ29GLHFCQUFxQixDQUFDLENBQUMsQ0FBQztJQUM3QyxNQUFNLENBQUNyRyxJQUFJLEVBQUU2QyxNQUFNLENBQUMsR0FBR3ZDLENBQUMsQ0FBQ1csVUFBVSxDQUFDSyxJQUFJLENBQUNnRixLQUFLLENBQUMsQ0FBQyxDQUFzQztJQUN0RixJQUFBTixjQUFNLEVBQUNoRyxJQUFJLENBQUMsQ0FBQ3VHLElBQUksQ0FBQyxlQUFlLENBQUM7SUFDbEM7SUFDQSxJQUFBUCxjQUFNLEVBQUNuRCxNQUFNLENBQUMsQ0FBQzRELE9BQU8sQ0FBQztNQUNyQkQsR0FBRyxFQUFFO1FBQUV0RCxJQUFJLEVBQUUsS0FBSztRQUFFd0QsT0FBTyxFQUFFLFVBQVU7UUFBRUMsT0FBTyxFQUFFLFVBQVU7UUFBRWpELElBQUksRUFBRTtNQUFLLENBQUM7TUFDMUUwRSxJQUFJLEVBQUU7SUFDUixDQUFDLENBQUM7RUFDSixDQUFDLENBQUM7RUFFRixJQUFBNUMsVUFBRSxFQUFDLG1GQUFtRixFQUFFLFlBQVk7SUFDbEdsRixDQUFDLENBQUNXLFVBQVUsQ0FBQzZGLGlCQUFpQixDQUFDN0IsTUFBTSxDQUFDQyxNQUFNLENBQUMsSUFBSWxFLEtBQUssQ0FBQyxNQUFNLENBQUMsRUFBRTtNQUFFbUUsSUFBSSxFQUFFO0lBQWUsQ0FBQyxDQUFDLENBQUM7SUFDMUYsTUFBTU0sSUFBSSxHQUFHQyxrQkFBUyxDQUFDQyxLQUFLLENBQUMsQ0FBQztJQUM5QixJQUFBQyxhQUFNLGVBQUMsSUFBQXZHLFdBQUEsQ0FBQXdHLEdBQUEsRUFBQ3pHLGdCQUFBLENBQUFJLE9BQVksSUFBRSxDQUFDLENBQUM7SUFDeEIsTUFBTTJJLE1BQU0sQ0FBQyxTQUFTLENBQUM7SUFDdkIsTUFBTSxJQUFBcEMsY0FBTyxFQUFDLE1BQU0sSUFBQUMsY0FBTSxFQUFDN0IsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM0RCxTQUFTLENBQUMsdUJBQXVCLENBQUMsQ0FBQztJQUN4RmpFLGdCQUFTLENBQUN3RCxPQUFPLENBQUNDLFFBQVEsRUFBRTtNQUFFQyxHQUFHLEVBQUU7SUFBUyxDQUFDLENBQUM7SUFFOUMsTUFBTS9CLElBQUksQ0FBQ1csS0FBSyxDQUFDLElBQUE5QixhQUFNLEVBQUMsTUFBTVYsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUN1QyxTQUFTLENBQUMsVUFBVSxFQUFFO01BQUV6RyxJQUFJLEVBQUU7SUFBd0IsQ0FBQyxDQUFDLENBQUM7SUFDM0csTUFBTSxJQUFBcUcsY0FBTyxFQUFDLE1BQU0sSUFBQUMsY0FBTSxFQUFDMUYsQ0FBQyxDQUFDVyxVQUFVLENBQUMsQ0FBQ29GLHFCQUFxQixDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ2xFdkMsZ0JBQVMsQ0FBQ3dELE9BQU8sQ0FBQ0MsUUFBUSxFQUFFO01BQUVDLEdBQUcsRUFBRTtJQUFTLENBQUMsQ0FBQztJQUU5QyxNQUFNLElBQUF6QixjQUFPLEVBQUMsTUFBTSxJQUFBQyxjQUFNLEVBQUM3QixhQUFhLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQ3lDLEdBQUcsQ0FBQ21CLFNBQVMsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO0lBQzVGLElBQUEvQixjQUFNLEVBQUM3QixhQUFhLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQzRELFNBQVMsQ0FBQyxjQUFjLENBQUM7RUFDNUQsQ0FBQyxDQUFDO0VBRUYsSUFBQXZDLFVBQUUsRUFBQyxpRUFBaUUsRUFBRSxZQUFZO0lBQ2hGLElBQUFJLGFBQU0sZUFBQyxJQUFBdkcsV0FBQSxDQUFBd0csR0FBQSxFQUFDekcsZ0JBQUEsQ0FBQUksT0FBWSxJQUFFLENBQUMsQ0FBQztJQUN4QixNQUFNMkksTUFBTSxDQUFDLGNBQWMsQ0FBQztJQUM1QixJQUFBbkMsY0FBTSxFQUFDN0IsYUFBYSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUNzQyxPQUFPLENBQUMsRUFBRSxDQUFDO0VBQ25ELENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}