var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

var _react = require("react");
var _react2 = require("@testing-library/react");
var _userEvent = _interopRequireDefault(require("@testing-library/user-event"));
var _vitest = require("vitest");
var _LayoutSwitcher = _interopRequireDefault(require("./LayoutSwitcher"));
var _LensSwitcher = _interopRequireDefault(require("./LensSwitcher"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(),
  _s2 = $RefreshSig$(); // The two `.viewswitch` segmented controls (LayoutSwitcher, LensSwitcher) against
// the APG Radio Group contract the interaction standards adopt by reference:
// roving tabindex (the checked radio is the group's one tab stop), arrows that
// move selection AND check, and Home/End. Rendered headless with local state —
// no SDK, matching FileExplorerView.test.tsx's approach.
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function Harness({
  initial
}) {
  _s();
  const [value, setValue] = (0, _react.useState)(initial);
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_LayoutSwitcher.default, {
    value: value,
    onChange: setValue
  });
}
_s(Harness, "SfNoMBvK9aVYEr/zPo8IyelSSW4=");
_c = Harness;
function LensHarness({
  initial
}) {
  _s2();
  const [value, setValue] = (0, _react.useState)(initial);
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_LensSwitcher.default, {
    value: value,
    onChange: setValue
  });
}
_s2(LensHarness, "SfNoMBvK9aVYEr/zPo8IyelSSW4=");
_c2 = LensHarness;
(0, _vitest.describe)("LayoutSwitcher (APG radio group)", () => {
  (0, _vitest.it)("only the checked radio is a tab stop (roving tabindex)", () => {
    (0, _react2.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(Harness, {
      initial: "tree"
    }));
    (0, _vitest.expect)(_react2.screen.getByRole("radio", {
      name: "Tree view"
    })).toHaveAttribute("tabindex", "0");
    for (const name of ["List view", "Column view", "Icon view"]) {
      (0, _vitest.expect)(_react2.screen.getByRole("radio", {
        name
      })).toHaveAttribute("tabindex", "-1");
    }
  });
  (0, _vitest.it)("ArrowRight moves selection AND check, and focus follows", async () => {
    (0, _react2.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(Harness, {
      initial: "tree"
    }));
    _react2.screen.getByRole("radio", {
      name: "Tree view"
    }).focus();
    await _userEvent.default.setup().keyboard("{ArrowRight}");
    const list = _react2.screen.getByRole("radio", {
      name: "List view"
    });
    (0, _vitest.expect)(list).toHaveAttribute("aria-checked", "true");
    (0, _vitest.expect)(list).toHaveAttribute("tabindex", "0");
    (0, _vitest.expect)(list).toHaveFocus();
    (0, _vitest.expect)(_react2.screen.getByRole("radio", {
      name: "Tree view"
    })).toHaveAttribute("tabindex", "-1");
  });
  (0, _vitest.it)("ArrowLeft wraps from the first radio to the last", async () => {
    (0, _react2.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(Harness, {
      initial: "tree"
    }));
    _react2.screen.getByRole("radio", {
      name: "Tree view"
    }).focus();
    await _userEvent.default.setup().keyboard("{ArrowLeft}");
    (0, _vitest.expect)(_react2.screen.getByRole("radio", {
      name: "Icon view"
    })).toHaveAttribute("aria-checked", "true");
  });
  (0, _vitest.it)("End jumps to the last radio and Home back to the first", async () => {
    (0, _react2.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(Harness, {
      initial: "tree"
    }));
    _react2.screen.getByRole("radio", {
      name: "Tree view"
    }).focus();
    const user = _userEvent.default.setup();
    await user.keyboard("{End}");
    (0, _vitest.expect)(_react2.screen.getByRole("radio", {
      name: "Icon view"
    })).toHaveFocus();
    await user.keyboard("{Home}");
    (0, _vitest.expect)(_react2.screen.getByRole("radio", {
      name: "Tree view"
    })).toHaveFocus();
  });
});
(0, _vitest.describe)("LensSwitcher (APG radio group)", () => {
  (0, _vitest.it)("names the group and options in space vocabulary, with roving tabindex", () => {
    (0, _react2.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(LensHarness, {
      initial: "app"
    }));
    (0, _vitest.expect)(_react2.screen.getByRole("radiogroup", {
      name: "Spaces lens"
    })).toBeInTheDocument();
    (0, _vitest.expect)(_react2.screen.getByRole("radio", {
      name: "This app's spaces"
    })).toHaveAttribute("tabindex", "0");
    (0, _vitest.expect)(_react2.screen.getByRole("radio", {
      name: "The session's spaces"
    })).toHaveAttribute("tabindex", "-1");
  });
  (0, _vitest.it)("ArrowDown moves selection AND check from App to Session", async () => {
    (0, _react2.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(LensHarness, {
      initial: "app"
    }));
    _react2.screen.getByRole("radio", {
      name: "This app's spaces"
    }).focus();
    await _userEvent.default.setup().keyboard("{ArrowDown}");
    const session = _react2.screen.getByRole("radio", {
      name: "The session's spaces"
    });
    (0, _vitest.expect)(session).toHaveAttribute("aria-checked", "true");
    (0, _vitest.expect)(session).toHaveFocus();
  });
});
var _c, _c2;
$RefreshReg$(_c, "Harness");
$RefreshReg$(_c2, "LensHarness");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3JlYWN0MiIsIl91c2VyRXZlbnQiLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX3ZpdGVzdCIsIl9MYXlvdXRTd2l0Y2hlciIsIl9MZW5zU3dpdGNoZXIiLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiX3MyIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiSGFybmVzcyIsImluaXRpYWwiLCJ2YWx1ZSIsInNldFZhbHVlIiwidXNlU3RhdGUiLCJqc3giLCJvbkNoYW5nZSIsIl9jIiwiTGVuc0hhcm5lc3MiLCJfYzIiLCJkZXNjcmliZSIsIml0IiwicmVuZGVyIiwiZXhwZWN0Iiwic2NyZWVuIiwiZ2V0QnlSb2xlIiwibmFtZSIsInRvSGF2ZUF0dHJpYnV0ZSIsImZvY3VzIiwidXNlckV2ZW50Iiwic2V0dXAiLCJrZXlib2FyZCIsImxpc3QiLCJ0b0hhdmVGb2N1cyIsInVzZXIiLCJ0b0JlSW5UaGVEb2N1bWVudCIsInNlc3Npb24iLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJTd2l0Y2hlcnMudGVzdC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gVGhlIHR3byBgLnZpZXdzd2l0Y2hgIHNlZ21lbnRlZCBjb250cm9scyAoTGF5b3V0U3dpdGNoZXIsIExlbnNTd2l0Y2hlcikgYWdhaW5zdFxuLy8gdGhlIEFQRyBSYWRpbyBHcm91cCBjb250cmFjdCB0aGUgaW50ZXJhY3Rpb24gc3RhbmRhcmRzIGFkb3B0IGJ5IHJlZmVyZW5jZTpcbi8vIHJvdmluZyB0YWJpbmRleCAodGhlIGNoZWNrZWQgcmFkaW8gaXMgdGhlIGdyb3VwJ3Mgb25lIHRhYiBzdG9wKSwgYXJyb3dzIHRoYXRcbi8vIG1vdmUgc2VsZWN0aW9uIEFORCBjaGVjaywgYW5kIEhvbWUvRW5kLiBSZW5kZXJlZCBoZWFkbGVzcyB3aXRoIGxvY2FsIHN0YXRlIOKAlFxuLy8gbm8gU0RLLCBtYXRjaGluZyBGaWxlRXhwbG9yZXJWaWV3LnRlc3QudHN4J3MgYXBwcm9hY2guXG5pbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgcmVuZGVyLCBzY3JlZW4gfSBmcm9tIFwiQHRlc3RpbmctbGlicmFyeS9yZWFjdFwiO1xuaW1wb3J0IHVzZXJFdmVudCBmcm9tIFwiQHRlc3RpbmctbGlicmFyeS91c2VyLWV2ZW50XCI7XG5pbXBvcnQgeyBkZXNjcmliZSwgZXhwZWN0LCBpdCB9IGZyb20gXCJ2aXRlc3RcIjtcbmltcG9ydCBMYXlvdXRTd2l0Y2hlciBmcm9tIFwiLi9MYXlvdXRTd2l0Y2hlclwiO1xuaW1wb3J0IExlbnNTd2l0Y2hlciBmcm9tIFwiLi9MZW5zU3dpdGNoZXJcIjtcbmltcG9ydCB0eXBlIHsgTGF5b3V0IH0gZnJvbSBcIi4vdHlwZXNcIjtcblxuZnVuY3Rpb24gSGFybmVzcyh7XG4gIGluaXRpYWwsXG59OiB7XG4gIGluaXRpYWw6IExheW91dDtcbn0pIHtcbiAgY29uc3QgW3ZhbHVlLCBzZXRWYWx1ZV0gPSB1c2VTdGF0ZTxMYXlvdXQ+KGluaXRpYWwpO1xuICByZXR1cm4gPExheW91dFN3aXRjaGVyIHZhbHVlPXt2YWx1ZX0gb25DaGFuZ2U9e3NldFZhbHVlfSAvPjtcbn1cblxuZnVuY3Rpb24gTGVuc0hhcm5lc3MoeyBpbml0aWFsIH06IHsgaW5pdGlhbDogXCJhcHBcIiB8IFwic2Vzc2lvblwiIH0pIHtcbiAgY29uc3QgW3ZhbHVlLCBzZXRWYWx1ZV0gPSB1c2VTdGF0ZShpbml0aWFsKTtcbiAgcmV0dXJuIDxMZW5zU3dpdGNoZXIgdmFsdWU9e3ZhbHVlfSBvbkNoYW5nZT17c2V0VmFsdWV9IC8+O1xufVxuXG5kZXNjcmliZShcIkxheW91dFN3aXRjaGVyIChBUEcgcmFkaW8gZ3JvdXApXCIsICgpID0+IHtcbiAgaXQoXCJvbmx5IHRoZSBjaGVja2VkIHJhZGlvIGlzIGEgdGFiIHN0b3AgKHJvdmluZyB0YWJpbmRleClcIiwgKCkgPT4ge1xuICAgIHJlbmRlcig8SGFybmVzcyBpbml0aWFsPVwidHJlZVwiIC8+KTtcbiAgICBleHBlY3Qoc2NyZWVuLmdldEJ5Um9sZShcInJhZGlvXCIsIHsgbmFtZTogXCJUcmVlIHZpZXdcIiB9KSkudG9IYXZlQXR0cmlidXRlKFwidGFiaW5kZXhcIiwgXCIwXCIpO1xuICAgIGZvciAoY29uc3QgbmFtZSBvZiBbXCJMaXN0IHZpZXdcIiwgXCJDb2x1bW4gdmlld1wiLCBcIkljb24gdmlld1wiXSkge1xuICAgICAgZXhwZWN0KHNjcmVlbi5nZXRCeVJvbGUoXCJyYWRpb1wiLCB7IG5hbWUgfSkpLnRvSGF2ZUF0dHJpYnV0ZShcInRhYmluZGV4XCIsIFwiLTFcIik7XG4gICAgfVxuICB9KTtcblxuICBpdChcIkFycm93UmlnaHQgbW92ZXMgc2VsZWN0aW9uIEFORCBjaGVjaywgYW5kIGZvY3VzIGZvbGxvd3NcIiwgYXN5bmMgKCkgPT4ge1xuICAgIHJlbmRlcig8SGFybmVzcyBpbml0aWFsPVwidHJlZVwiIC8+KTtcbiAgICBzY3JlZW4uZ2V0QnlSb2xlKFwicmFkaW9cIiwgeyBuYW1lOiBcIlRyZWUgdmlld1wiIH0pLmZvY3VzKCk7XG4gICAgYXdhaXQgdXNlckV2ZW50LnNldHVwKCkua2V5Ym9hcmQoXCJ7QXJyb3dSaWdodH1cIik7XG4gICAgY29uc3QgbGlzdCA9IHNjcmVlbi5nZXRCeVJvbGUoXCJyYWRpb1wiLCB7IG5hbWU6IFwiTGlzdCB2aWV3XCIgfSk7XG4gICAgZXhwZWN0KGxpc3QpLnRvSGF2ZUF0dHJpYnV0ZShcImFyaWEtY2hlY2tlZFwiLCBcInRydWVcIik7XG4gICAgZXhwZWN0KGxpc3QpLnRvSGF2ZUF0dHJpYnV0ZShcInRhYmluZGV4XCIsIFwiMFwiKTtcbiAgICBleHBlY3QobGlzdCkudG9IYXZlRm9jdXMoKTtcbiAgICBleHBlY3Qoc2NyZWVuLmdldEJ5Um9sZShcInJhZGlvXCIsIHsgbmFtZTogXCJUcmVlIHZpZXdcIiB9KSkudG9IYXZlQXR0cmlidXRlKFwidGFiaW5kZXhcIiwgXCItMVwiKTtcbiAgfSk7XG5cbiAgaXQoXCJBcnJvd0xlZnQgd3JhcHMgZnJvbSB0aGUgZmlyc3QgcmFkaW8gdG8gdGhlIGxhc3RcIiwgYXN5bmMgKCkgPT4ge1xuICAgIHJlbmRlcig8SGFybmVzcyBpbml0aWFsPVwidHJlZVwiIC8+KTtcbiAgICBzY3JlZW4uZ2V0QnlSb2xlKFwicmFkaW9cIiwgeyBuYW1lOiBcIlRyZWUgdmlld1wiIH0pLmZvY3VzKCk7XG4gICAgYXdhaXQgdXNlckV2ZW50LnNldHVwKCkua2V5Ym9hcmQoXCJ7QXJyb3dMZWZ0fVwiKTtcbiAgICBleHBlY3Qoc2NyZWVuLmdldEJ5Um9sZShcInJhZGlvXCIsIHsgbmFtZTogXCJJY29uIHZpZXdcIiB9KSkudG9IYXZlQXR0cmlidXRlKFwiYXJpYS1jaGVja2VkXCIsIFwidHJ1ZVwiKTtcbiAgfSk7XG5cbiAgaXQoXCJFbmQganVtcHMgdG8gdGhlIGxhc3QgcmFkaW8gYW5kIEhvbWUgYmFjayB0byB0aGUgZmlyc3RcIiwgYXN5bmMgKCkgPT4ge1xuICAgIHJlbmRlcig8SGFybmVzcyBpbml0aWFsPVwidHJlZVwiIC8+KTtcbiAgICBzY3JlZW4uZ2V0QnlSb2xlKFwicmFkaW9cIiwgeyBuYW1lOiBcIlRyZWUgdmlld1wiIH0pLmZvY3VzKCk7XG4gICAgY29uc3QgdXNlciA9IHVzZXJFdmVudC5zZXR1cCgpO1xuICAgIGF3YWl0IHVzZXIua2V5Ym9hcmQoXCJ7RW5kfVwiKTtcbiAgICBleHBlY3Qoc2NyZWVuLmdldEJ5Um9sZShcInJhZGlvXCIsIHsgbmFtZTogXCJJY29uIHZpZXdcIiB9KSkudG9IYXZlRm9jdXMoKTtcbiAgICBhd2FpdCB1c2VyLmtleWJvYXJkKFwie0hvbWV9XCIpO1xuICAgIGV4cGVjdChzY3JlZW4uZ2V0QnlSb2xlKFwicmFkaW9cIiwgeyBuYW1lOiBcIlRyZWUgdmlld1wiIH0pKS50b0hhdmVGb2N1cygpO1xuICB9KTtcbn0pO1xuXG5kZXNjcmliZShcIkxlbnNTd2l0Y2hlciAoQVBHIHJhZGlvIGdyb3VwKVwiLCAoKSA9PiB7XG4gIGl0KFwibmFtZXMgdGhlIGdyb3VwIGFuZCBvcHRpb25zIGluIHNwYWNlIHZvY2FidWxhcnksIHdpdGggcm92aW5nIHRhYmluZGV4XCIsICgpID0+IHtcbiAgICByZW5kZXIoPExlbnNIYXJuZXNzIGluaXRpYWw9XCJhcHBcIiAvPik7XG4gICAgZXhwZWN0KHNjcmVlbi5nZXRCeVJvbGUoXCJyYWRpb2dyb3VwXCIsIHsgbmFtZTogXCJTcGFjZXMgbGVuc1wiIH0pKS50b0JlSW5UaGVEb2N1bWVudCgpO1xuICAgIGV4cGVjdChzY3JlZW4uZ2V0QnlSb2xlKFwicmFkaW9cIiwgeyBuYW1lOiBcIlRoaXMgYXBwJ3Mgc3BhY2VzXCIgfSkpLnRvSGF2ZUF0dHJpYnV0ZShcInRhYmluZGV4XCIsIFwiMFwiKTtcbiAgICBleHBlY3Qoc2NyZWVuLmdldEJ5Um9sZShcInJhZGlvXCIsIHsgbmFtZTogXCJUaGUgc2Vzc2lvbidzIHNwYWNlc1wiIH0pKS50b0hhdmVBdHRyaWJ1dGUoXCJ0YWJpbmRleFwiLCBcIi0xXCIpO1xuICB9KTtcblxuICBpdChcIkFycm93RG93biBtb3ZlcyBzZWxlY3Rpb24gQU5EIGNoZWNrIGZyb20gQXBwIHRvIFNlc3Npb25cIiwgYXN5bmMgKCkgPT4ge1xuICAgIHJlbmRlcig8TGVuc0hhcm5lc3MgaW5pdGlhbD1cImFwcFwiIC8+KTtcbiAgICBzY3JlZW4uZ2V0QnlSb2xlKFwicmFkaW9cIiwgeyBuYW1lOiBcIlRoaXMgYXBwJ3Mgc3BhY2VzXCIgfSkuZm9jdXMoKTtcbiAgICBhd2FpdCB1c2VyRXZlbnQuc2V0dXAoKS5rZXlib2FyZChcIntBcnJvd0Rvd259XCIpO1xuICAgIGNvbnN0IHNlc3Npb24gPSBzY3JlZW4uZ2V0QnlSb2xlKFwicmFkaW9cIiwgeyBuYW1lOiBcIlRoZSBzZXNzaW9uJ3Mgc3BhY2VzXCIgfSk7XG4gICAgZXhwZWN0KHNlc3Npb24pLnRvSGF2ZUF0dHJpYnV0ZShcImFyaWEtY2hlY2tlZFwiLCBcInRydWVcIik7XG4gICAgZXhwZWN0KHNlc3Npb24pLnRvSGF2ZUZvY3VzKCk7XG4gIH0pO1xufSk7XG4iXSwibWFwcGluZ3MiOiI7O0FBS0EsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsT0FBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsVUFBQSxHQUFBQyxzQkFBQSxDQUFBSCxPQUFBO0FBQ0EsSUFBQUksT0FBQSxHQUFBSixPQUFBO0FBQ0EsSUFBQUssZUFBQSxHQUFBRixzQkFBQSxDQUFBSCxPQUFBO0FBQ0EsSUFBQU0sYUFBQSxHQUFBSCxzQkFBQSxDQUFBSCxPQUFBO0FBQTBDLElBQUFPLFdBQUEsR0FBQVAsT0FBQTtBQUFBLElBQUFRLEVBQUEsR0FBQUMsWUFBQTtFQUFBQyxHQUFBLEdBQUFELFlBQUEsSUFWMUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUFBLFNBQUFOLHVCQUFBUSxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBU0EsU0FBU0csT0FBT0EsQ0FBQztFQUNmQztBQUdGLENBQUMsRUFBRTtFQUFBUCxFQUFBO0VBQ0QsTUFBTSxDQUFDUSxLQUFLLEVBQUVDLFFBQVEsQ0FBQyxHQUFHLElBQUFDLGVBQVEsRUFBU0gsT0FBTyxDQUFDO0VBQ25ELG9CQUFPLElBQUFSLFdBQUEsQ0FBQVksR0FBQSxFQUFDZCxlQUFBLENBQUFRLE9BQWM7SUFBQ0csS0FBSyxFQUFFQSxLQUFNO0lBQUNJLFFBQVEsRUFBRUg7RUFBUyxDQUFFLENBQUM7QUFDN0Q7QUFBQ1QsRUFBQSxDQVBRTSxPQUFPO0FBQUFPLEVBQUEsR0FBUFAsT0FBTztBQVNoQixTQUFTUSxXQUFXQSxDQUFDO0VBQUVQO0FBQXdDLENBQUMsRUFBRTtFQUFBTCxHQUFBO0VBQ2hFLE1BQU0sQ0FBQ00sS0FBSyxFQUFFQyxRQUFRLENBQUMsR0FBRyxJQUFBQyxlQUFRLEVBQUNILE9BQU8sQ0FBQztFQUMzQyxvQkFBTyxJQUFBUixXQUFBLENBQUFZLEdBQUEsRUFBQ2IsYUFBQSxDQUFBTyxPQUFZO0lBQUNHLEtBQUssRUFBRUEsS0FBTTtJQUFDSSxRQUFRLEVBQUVIO0VBQVMsQ0FBRSxDQUFDO0FBQzNEO0FBQUNQLEdBQUEsQ0FIUVksV0FBVztBQUFBQyxHQUFBLEdBQVhELFdBQVc7QUFLcEIsSUFBQUUsZ0JBQVEsRUFBQyxrQ0FBa0MsRUFBRSxNQUFNO0VBQ2pELElBQUFDLFVBQUUsRUFBQyx3REFBd0QsRUFBRSxNQUFNO0lBQ2pFLElBQUFDLGNBQU0sZUFBQyxJQUFBbkIsV0FBQSxDQUFBWSxHQUFBLEVBQUNMLE9BQU87TUFBQ0MsT0FBTyxFQUFDO0lBQU0sQ0FBRSxDQUFDLENBQUM7SUFDbEMsSUFBQVksY0FBTSxFQUFDQyxjQUFNLENBQUNDLFNBQVMsQ0FBQyxPQUFPLEVBQUU7TUFBRUMsSUFBSSxFQUFFO0lBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQ0MsZUFBZSxDQUFDLFVBQVUsRUFBRSxHQUFHLENBQUM7SUFDekYsS0FBSyxNQUFNRCxJQUFJLElBQUksQ0FBQyxXQUFXLEVBQUUsYUFBYSxFQUFFLFdBQVcsQ0FBQyxFQUFFO01BQzVELElBQUFILGNBQU0sRUFBQ0MsY0FBTSxDQUFDQyxTQUFTLENBQUMsT0FBTyxFQUFFO1FBQUVDO01BQUssQ0FBQyxDQUFDLENBQUMsQ0FBQ0MsZUFBZSxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUM7SUFDL0U7RUFDRixDQUFDLENBQUM7RUFFRixJQUFBTixVQUFFLEVBQUMseURBQXlELEVBQUUsWUFBWTtJQUN4RSxJQUFBQyxjQUFNLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQVksR0FBQSxFQUFDTCxPQUFPO01BQUNDLE9BQU8sRUFBQztJQUFNLENBQUUsQ0FBQyxDQUFDO0lBQ2xDYSxjQUFNLENBQUNDLFNBQVMsQ0FBQyxPQUFPLEVBQUU7TUFBRUMsSUFBSSxFQUFFO0lBQVksQ0FBQyxDQUFDLENBQUNFLEtBQUssQ0FBQyxDQUFDO0lBQ3hELE1BQU1DLGtCQUFTLENBQUNDLEtBQUssQ0FBQyxDQUFDLENBQUNDLFFBQVEsQ0FBQyxjQUFjLENBQUM7SUFDaEQsTUFBTUMsSUFBSSxHQUFHUixjQUFNLENBQUNDLFNBQVMsQ0FBQyxPQUFPLEVBQUU7TUFBRUMsSUFBSSxFQUFFO0lBQVksQ0FBQyxDQUFDO0lBQzdELElBQUFILGNBQU0sRUFBQ1MsSUFBSSxDQUFDLENBQUNMLGVBQWUsQ0FBQyxjQUFjLEVBQUUsTUFBTSxDQUFDO0lBQ3BELElBQUFKLGNBQU0sRUFBQ1MsSUFBSSxDQUFDLENBQUNMLGVBQWUsQ0FBQyxVQUFVLEVBQUUsR0FBRyxDQUFDO0lBQzdDLElBQUFKLGNBQU0sRUFBQ1MsSUFBSSxDQUFDLENBQUNDLFdBQVcsQ0FBQyxDQUFDO0lBQzFCLElBQUFWLGNBQU0sRUFBQ0MsY0FBTSxDQUFDQyxTQUFTLENBQUMsT0FBTyxFQUFFO01BQUVDLElBQUksRUFBRTtJQUFZLENBQUMsQ0FBQyxDQUFDLENBQUNDLGVBQWUsQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDO0VBQzVGLENBQUMsQ0FBQztFQUVGLElBQUFOLFVBQUUsRUFBQyxrREFBa0QsRUFBRSxZQUFZO0lBQ2pFLElBQUFDLGNBQU0sZUFBQyxJQUFBbkIsV0FBQSxDQUFBWSxHQUFBLEVBQUNMLE9BQU87TUFBQ0MsT0FBTyxFQUFDO0lBQU0sQ0FBRSxDQUFDLENBQUM7SUFDbENhLGNBQU0sQ0FBQ0MsU0FBUyxDQUFDLE9BQU8sRUFBRTtNQUFFQyxJQUFJLEVBQUU7SUFBWSxDQUFDLENBQUMsQ0FBQ0UsS0FBSyxDQUFDLENBQUM7SUFDeEQsTUFBTUMsa0JBQVMsQ0FBQ0MsS0FBSyxDQUFDLENBQUMsQ0FBQ0MsUUFBUSxDQUFDLGFBQWEsQ0FBQztJQUMvQyxJQUFBUixjQUFNLEVBQUNDLGNBQU0sQ0FBQ0MsU0FBUyxDQUFDLE9BQU8sRUFBRTtNQUFFQyxJQUFJLEVBQUU7SUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDQyxlQUFlLENBQUMsY0FBYyxFQUFFLE1BQU0sQ0FBQztFQUNsRyxDQUFDLENBQUM7RUFFRixJQUFBTixVQUFFLEVBQUMsd0RBQXdELEVBQUUsWUFBWTtJQUN2RSxJQUFBQyxjQUFNLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQVksR0FBQSxFQUFDTCxPQUFPO01BQUNDLE9BQU8sRUFBQztJQUFNLENBQUUsQ0FBQyxDQUFDO0lBQ2xDYSxjQUFNLENBQUNDLFNBQVMsQ0FBQyxPQUFPLEVBQUU7TUFBRUMsSUFBSSxFQUFFO0lBQVksQ0FBQyxDQUFDLENBQUNFLEtBQUssQ0FBQyxDQUFDO0lBQ3hELE1BQU1NLElBQUksR0FBR0wsa0JBQVMsQ0FBQ0MsS0FBSyxDQUFDLENBQUM7SUFDOUIsTUFBTUksSUFBSSxDQUFDSCxRQUFRLENBQUMsT0FBTyxDQUFDO0lBQzVCLElBQUFSLGNBQU0sRUFBQ0MsY0FBTSxDQUFDQyxTQUFTLENBQUMsT0FBTyxFQUFFO01BQUVDLElBQUksRUFBRTtJQUFZLENBQUMsQ0FBQyxDQUFDLENBQUNPLFdBQVcsQ0FBQyxDQUFDO0lBQ3RFLE1BQU1DLElBQUksQ0FBQ0gsUUFBUSxDQUFDLFFBQVEsQ0FBQztJQUM3QixJQUFBUixjQUFNLEVBQUNDLGNBQU0sQ0FBQ0MsU0FBUyxDQUFDLE9BQU8sRUFBRTtNQUFFQyxJQUFJLEVBQUU7SUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDTyxXQUFXLENBQUMsQ0FBQztFQUN4RSxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7QUFFRixJQUFBYixnQkFBUSxFQUFDLGdDQUFnQyxFQUFFLE1BQU07RUFDL0MsSUFBQUMsVUFBRSxFQUFDLHVFQUF1RSxFQUFFLE1BQU07SUFDaEYsSUFBQUMsY0FBTSxlQUFDLElBQUFuQixXQUFBLENBQUFZLEdBQUEsRUFBQ0csV0FBVztNQUFDUCxPQUFPLEVBQUM7SUFBSyxDQUFFLENBQUMsQ0FBQztJQUNyQyxJQUFBWSxjQUFNLEVBQUNDLGNBQU0sQ0FBQ0MsU0FBUyxDQUFDLFlBQVksRUFBRTtNQUFFQyxJQUFJLEVBQUU7SUFBYyxDQUFDLENBQUMsQ0FBQyxDQUFDUyxpQkFBaUIsQ0FBQyxDQUFDO0lBQ25GLElBQUFaLGNBQU0sRUFBQ0MsY0FBTSxDQUFDQyxTQUFTLENBQUMsT0FBTyxFQUFFO01BQUVDLElBQUksRUFBRTtJQUFvQixDQUFDLENBQUMsQ0FBQyxDQUFDQyxlQUFlLENBQUMsVUFBVSxFQUFFLEdBQUcsQ0FBQztJQUNqRyxJQUFBSixjQUFNLEVBQUNDLGNBQU0sQ0FBQ0MsU0FBUyxDQUFDLE9BQU8sRUFBRTtNQUFFQyxJQUFJLEVBQUU7SUFBdUIsQ0FBQyxDQUFDLENBQUMsQ0FBQ0MsZUFBZSxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUM7RUFDdkcsQ0FBQyxDQUFDO0VBRUYsSUFBQU4sVUFBRSxFQUFDLHlEQUF5RCxFQUFFLFlBQVk7SUFDeEUsSUFBQUMsY0FBTSxlQUFDLElBQUFuQixXQUFBLENBQUFZLEdBQUEsRUFBQ0csV0FBVztNQUFDUCxPQUFPLEVBQUM7SUFBSyxDQUFFLENBQUMsQ0FBQztJQUNyQ2EsY0FBTSxDQUFDQyxTQUFTLENBQUMsT0FBTyxFQUFFO01BQUVDLElBQUksRUFBRTtJQUFvQixDQUFDLENBQUMsQ0FBQ0UsS0FBSyxDQUFDLENBQUM7SUFDaEUsTUFBTUMsa0JBQVMsQ0FBQ0MsS0FBSyxDQUFDLENBQUMsQ0FBQ0MsUUFBUSxDQUFDLGFBQWEsQ0FBQztJQUMvQyxNQUFNSyxPQUFPLEdBQUdaLGNBQU0sQ0FBQ0MsU0FBUyxDQUFDLE9BQU8sRUFBRTtNQUFFQyxJQUFJLEVBQUU7SUFBdUIsQ0FBQyxDQUFDO0lBQzNFLElBQUFILGNBQU0sRUFBQ2EsT0FBTyxDQUFDLENBQUNULGVBQWUsQ0FBQyxjQUFjLEVBQUUsTUFBTSxDQUFDO0lBQ3ZELElBQUFKLGNBQU0sRUFBQ2EsT0FBTyxDQUFDLENBQUNILFdBQVcsQ0FBQyxDQUFDO0VBQy9CLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQztBQUFDLElBQUFoQixFQUFBLEVBQUFFLEdBQUE7QUFBQWtCLFlBQUEsQ0FBQXBCLEVBQUE7QUFBQW9CLFlBQUEsQ0FBQWxCLEdBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}