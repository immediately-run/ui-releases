"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.uploadTargetDir = exports.uploadRowFromEvent = exports.toMountRel = exports.subtreeLabel = exports.orderMounts = exports.moveRejection = exports.moveRefusalLabel = exports.mountSpaceId = exports.mountScopes = exports.mountLabel = exports.mountKind = exports.joinRel = exports.joinPath = exports.isWritableMount = exports.isProtected = exports.isEjectable = exports.grantedModeAt = exports.dirOf = exports.breadcrumbFor = exports.basename = exports.WRITE_ERR = exports.MOVE_MIME = exports.INLINE_DRAG_OUT_BYTES = void 0;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.find.js");
// Pure helpers for the file explorer — path math, root metadata read from the
// generalized ExplorerRoot, and the move/upload/drag validity predicates.
// Framework-free and side-effect-free so they unit-test directly (ways_of_working
// §5; file-explorer CLAUDE.md). No React, NO SDK import here — the view reads
// roots through ExplorerRoot, and the SDK adapter (`sdk/mounts.ts`) is what maps
// a SandboxMount onto that shape.

/** Join a directory and a child name into one normalized absolute/rel path. */
const joinPath = (dir, name) => `${dir.replace(/\/+$/, "")}/${name}`;

/** The last path segment (basename) of a slash path. */
exports.joinPath = joinPath;
const basename = p => p.split("/").filter(Boolean).pop() ?? "";

/** The parent directory of a slash path (no trailing slash; "/" for a root child). */
exports.basename = basename;
const dirOf = p => {
  const trimmed = p.replace(/\/+$/, "");
  const i = trimmed.lastIndexOf("/");
  return i <= 0 ? "/" : trimmed.slice(0, i);
};

/** A mount-absolute path made repo-/mount-relative (leading slash) for the SDK
 *  intents, which take mount-relative paths (e.g. `/src/App.tsx`). */
exports.dirOf = dirOf;
const toMountRel = (rootPath, absPath) => absPath.slice(rootPath.replace(/\/+$/, "").length) || "/";

/** The inverse of {@link toMountRel}: a mount-relative dir ("/src") made
 *  absolute under `rootPath` ("<root>/src"); "/" maps to the root itself. */
exports.toMountRel = toMountRel;
const joinRel = (rootPath, relDir) => {
  const normalized = normalizeRel(relDir);
  return normalized === "/" ? rootPath.replace(/\/+$/, "") : joinPath(rootPath, normalized.slice(1));
};

// ---------------------------------------------------------------------------
// Root metadata (R3-79 / FILE_EXPLORER_SPEC §2) — over the generalized
// ExplorerRoot. The SDK adapter populates these fields from a SandboxMount; the
// view reads them through these accessors so the layouts stay decoupled.
// ---------------------------------------------------------------------------

/** A human-readable scope label (already resolved onto the root by the adapter). */
exports.joinRel = joinRel;
const mountLabel = r => r.label;

/** The provider/type kind of a root, for the App-scope header icon (PRINCIPALS
 *  §9 B1). A classifier only — the icon mapping lives in the view. */
exports.mountLabel = mountLabel;
const mountKind = r => r.kind;

/** The spaceId of a space root, for eject (`unmountSpace`). Null for roots that
 *  aren't ejectable spaces (worktree, settings). */
exports.mountKind = mountKind;
const mountSpaceId = r => r.spaceId ?? null;

/**
 * Whether the explorer offers an EJECT (detach) affordance on this root
 * (SPACES_UI_SPEC §3, R-SPACES-3). Eject = `unmountSpace` — closes the space for
 * this session only; it is NOT leave/revoke. Offered for spaces / granted
 * subtrees; NEVER for the worktree or the per-app `settings:` store.
 */
exports.mountSpaceId = mountSpaceId;
const isEjectable = r => !!r.ejectable;

/**
 * Whether the explorer should offer WRITE affordances (new/rename/delete/upload/
 * move) on this root. The adapter computes effective writability; the view just
 * reflects it — the affordances are HIDDEN on a read-only root, never
 * shown-then-`EROFS` (CLAUDE.md: never surface `EROFS` as UX).
 */
exports.isEjectable = isEjectable;
const isWritableMount = r => r.writable;

/** A mount-relative path in one shape: leading slash, no trailing slash. */
exports.isWritableMount = isWritableMount;
const normalizeRel = p => {
  const trimmed = (p || "/").replace(/\/+$/, "");
  if (trimmed === "") return "/";
  return trimmed.startsWith("/") ? trimmed : `/${trimmed}`;
};

/**
 * The mode the app actually HOLDS at `relPath` in this root — longest matching
 * `grants` prefix wins, exactly as the host resolves a delegation against its rule
 * set. `ro` when nothing is known, so a missing rule-set can only ever under-ask.
 *
 * This is the mode to DELEGATE at (R3-267 / R3-266: dispatch changes the packaging,
 * not the authority — the mount decides whether the opened viewer can edit). It is
 * NOT {@link isWritableMount}, which answers a different question: whether the
 * explorer itself offers create/rename/delete here.
 */
const grantedModeAt = (r, relPath) => {
  const target = normalizeRel(relPath);
  let best = -1;
  let mode = "ro";
  for (const rule of r.grants ?? []) {
    const subtree = normalizeRel(rule.subtree);
    const covers = subtree === "/" || target === subtree || target.startsWith(`${subtree}/`);
    if (covers && subtree.length > best) {
      best = subtree.length;
      mode = rule.mode;
    }
  }
  return mode;
};

/** One display row in the App-scope header: a granted subtree and the mode shown
 *  there (PRINCIPALS §9 B1 / FILE_EXPLORER §2). */
exports.grantedModeAt = grantedModeAt;
/**
 * The granted scopes of a root as display rows — one per scope, so a root with
 * several subtrees lists each (FILE_EXPLORER §2 step 2). Falls back to a single
 * whole-mount row from the root's effective writability when `scopes` is absent.
 * The displayed mode is the EFFECTIVE mode the adapter already baked into each
 * scope. De-duped by subtree and ordered root-first then A→Z.
 */
const mountScopes = r => {
  const fallbackMode = isWritableMount(r) ? "rw" : "ro";
  const scopes = r.scopes?.length ? r.scopes : [{
    subtree: "/",
    mode: fallbackMode
  }];
  const seen = new Map();
  for (const s of scopes) {
    const subtree = s.subtree && s.subtree.trim() && s.subtree !== "/" ? s.subtree.trim() : "/";
    if (seen.has(subtree)) continue;
    seen.set(subtree, {
      subtree,
      mode: s.mode
    });
  }
  return [...seen.values()].sort((a, b) => a.subtree === "/" ? -1 : b.subtree === "/" ? 1 : a.subtree.localeCompare(b.subtree));
};

/** A short subtree label for the single-chip layouts (breadcrumb / columns) where
 *  only the current directory's owning root is shown ("/" for a whole-mount grant).
 *  The per-mount header uses {@link mountScopes} for the full list. */
exports.mountScopes = mountScopes;
const subtreeLabel = r => {
  const first = r.scopes?.[0];
  return first?.subtree && first.subtree !== "/" ? first.subtree : "/";
};

/** Order roots for display: worktree first, then spaces, then others, A→Z. */
exports.subtreeLabel = subtreeLabel;
const orderMounts = roots => [...roots].sort((a, b) => {
  const rank = r => r.kind === "worktree" ? 0 : r.kind === "space" ? 1 : 2;
  return rank(a) - rank(b) || mountLabel(a).localeCompare(mountLabel(b));
});

// Files the host refuses to delete/rename — hide the affordance to match (the
// host also enforces it, returning `protected`). Shared by every layout so the
// gating is identical in tree / list / icons / columns. Mount-relative paths.
exports.orderMounts = orderMounts;
const PROTECTED = new Set(["/package.json"]);

/** Is this mount-relative path one the host protects from delete/rename? */
const isProtected = mountRel => PROTECTED.has(mountRel);

// ---------------------------------------------------------------------------
// Breadcrumb / current-directory navigation (R3-84 list + icons layouts)
// ---------------------------------------------------------------------------
exports.isProtected = isProtected;
/**
 * Resolve a current directory (`cwd`, absolute or null = the Spaces root) into the
 * owning root and a breadcrumb trail. The trail always starts at "Spaces" so the
 * user can step back out to the root list (mirroring the mobile projection in
 * brief 13). When `cwd` falls inside a root, segments are: Spaces > <root> >
 * <subdir...>. When `cwd` is null (or unresolvable), only the Spaces root is shown.
 * Pure — no React, no I/O.
 */
const breadcrumbFor = (cwd, ordered) => {
  const root = {
    label: "Spaces",
    path: null
  };
  if (!cwd) return {
    mount: null,
    crumbs: [root]
  };
  const mount = ordered.find(m => cwd === m.path || cwd.startsWith(m.path + "/")) ?? null;
  if (!mount) return {
    mount: null,
    crumbs: [root]
  };
  const crumbs = [root, {
    label: mountLabel(mount),
    path: mount.path
  }];
  const rel = toMountRel(mount.path, cwd); // e.g. "/src/components" or "/"
  const segs = rel.split("/").filter(Boolean);
  let acc = mount.path;
  for (const seg of segs) {
    acc = joinPath(acc, seg);
    crumbs.push({
      label: seg,
      path: acc
    });
  }
  return {
    mount,
    crumbs
  };
};

// ---------------------------------------------------------------------------
// Drag-and-drop validity (R3-81 move / R3-82 upload)
// ---------------------------------------------------------------------------

/** Private MIME the explorer sets on an internal (same-app) move drag, so an
 *  internal row drag is distinguishable from an OS-file drop and a §7 drag-out. */
exports.breadcrumbFor = breadcrumbFor;
const MOVE_MIME = exports.MOVE_MIME = "application/x-ir-file-move";
/**
 * Can `from` be moved INTO directory `targetDir` (both absolute paths in the same
 * mount)? Rejects: a no-op (already in that dir), a directory dropped onto itself
 * or a descendant, and (the caller enforces) cross-mount drops. Returns the reason
 * code on rejection so the UI can hint, or `null` when the move is allowed.
 */
const moveRejection = (from, targetDir, fromRoot, targetRoot) => {
  if (fromRoot !== targetRoot) return "cross-mount";
  if (dirOf(from) === targetDir.replace(/\/+$/, "")) return "same-dir";
  const f = from.replace(/\/+$/, "");
  const t = targetDir.replace(/\/+$/, "");
  if (t === f || t.startsWith(f + "/")) return "into-self";
  return null;
};

/** The human sentence for a destination the move refuses, or null when it
 *  doesn't — the move picker's disabled-button reason. */
exports.moveRejection = moveRejection;
const moveRefusalLabel = (target, dirAbs, dirRootPath) => {
  const reason = moveRejection(target.absPath, dirAbs, target.rootPath, dirRootPath);
  if (reason === "cross-mount") return WRITE_ERR["cross-mount"];
  if (reason === "same-dir") return `${target.name} is already in this folder.`;
  if (reason === "into-self") return "A folder can’t move into itself.";
  return null;
};

/**
 * Where an OS-file drop lands (`FILE_EXPLORER_SPEC §5`): the directory row under
 * the pointer, the PARENT of a file row, or the scope root when the drop misses
 * every row — a drop on the blank space below the tree, or on the scope header.
 * The §5 upload BUTTON resolves its destination through the same shape: its
 * "row" is the SELECTION (a selected dir itself, a selected file's parent)
 * and the fallback is the repo root when nothing is selected.
 *
 * `row` is what the drop point resolves to, or `null` when it resolves to nothing.
 * Directory rows answer this for themselves before the event reaches a container,
 * so in practice this decides the two cases that used to be silent no-ops.
 */
exports.moveRefusalLabel = moveRefusalLabel;
const uploadTargetDir = (row, scopeRoot) => row ? row.isDir ? row.path : dirOf(row.path) : scopeRoot;

/**
 * The DOM→row half of an OS-file drop (R3-626): resolve the element the drop
 * landed on to a row via the `data-path`/`data-dir` attributes every row
 * carries, then `uploadTargetDir` against the container's fallback. ONE home —
 * the flat containers' hook and the tree's scope resolve identically, and this
 * is the block that must not drift between them.
 */
exports.uploadTargetDir = uploadTargetDir;
const uploadRowFromEvent = (e, fallbackDir) => {
  const el = e.target?.closest?.("[data-path]") ?? null;
  const row = el ? {
    path: el.getAttribute("data-path") ?? fallbackDir,
    isDir: el.getAttribute("data-dir") === "1"
  } : null;
  return uploadTargetDir(row, fallbackDir);
};

/** R3-853: the inline-bytes convenience bound for DRAG-OUT only. Inlining is a
 *  best-effort convenience — a larger file goes reference-only, which is not a
 *  refusal. The UPLOAD path has no client cap at all anymore: the host enforces
 *  (and names) the real one (`writeLimits.MAX_TRANSFER_BYTES` in site-main). */
exports.uploadRowFromEvent = uploadRowFromEvent;
const INLINE_DRAG_OUT_BYTES = exports.INLINE_DRAG_OUT_BYTES = 1024 * 1024;

/** Map a host write-outcome code to a friendly message (shared by every mutation). */
const WRITE_ERR = exports.WRITE_ERR = {
  exists: "Something with that name already exists.",
  protected: "That file can’t be deleted.",
  "too-large": "That file is too large to upload.",
  // the no-limitBytes fallback (an older host)
  "not-found": "That file no longer exists.",
  forbidden: "You don’t have permission to change files here.",
  "invalid-params": "That name isn’t valid.",
  "cross-mount": "Can’t move between spaces yet."
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJqb2luUGF0aCIsImRpciIsIm5hbWUiLCJyZXBsYWNlIiwiZXhwb3J0cyIsImJhc2VuYW1lIiwicCIsInNwbGl0IiwiZmlsdGVyIiwiQm9vbGVhbiIsInBvcCIsImRpck9mIiwidHJpbW1lZCIsImkiLCJsYXN0SW5kZXhPZiIsInNsaWNlIiwidG9Nb3VudFJlbCIsInJvb3RQYXRoIiwiYWJzUGF0aCIsImxlbmd0aCIsImpvaW5SZWwiLCJyZWxEaXIiLCJub3JtYWxpemVkIiwibm9ybWFsaXplUmVsIiwibW91bnRMYWJlbCIsInIiLCJsYWJlbCIsIm1vdW50S2luZCIsImtpbmQiLCJtb3VudFNwYWNlSWQiLCJzcGFjZUlkIiwiaXNFamVjdGFibGUiLCJlamVjdGFibGUiLCJpc1dyaXRhYmxlTW91bnQiLCJ3cml0YWJsZSIsInN0YXJ0c1dpdGgiLCJncmFudGVkTW9kZUF0IiwicmVsUGF0aCIsInRhcmdldCIsImJlc3QiLCJtb2RlIiwicnVsZSIsImdyYW50cyIsInN1YnRyZWUiLCJjb3ZlcnMiLCJtb3VudFNjb3BlcyIsImZhbGxiYWNrTW9kZSIsInNjb3BlcyIsInNlZW4iLCJNYXAiLCJzIiwidHJpbSIsImhhcyIsInNldCIsInZhbHVlcyIsInNvcnQiLCJhIiwiYiIsImxvY2FsZUNvbXBhcmUiLCJzdWJ0cmVlTGFiZWwiLCJmaXJzdCIsIm9yZGVyTW91bnRzIiwicm9vdHMiLCJyYW5rIiwiUFJPVEVDVEVEIiwiU2V0IiwiaXNQcm90ZWN0ZWQiLCJtb3VudFJlbCIsImJyZWFkY3J1bWJGb3IiLCJjd2QiLCJvcmRlcmVkIiwicm9vdCIsInBhdGgiLCJtb3VudCIsImNydW1icyIsImZpbmQiLCJtIiwicmVsIiwic2VncyIsImFjYyIsInNlZyIsInB1c2giLCJNT1ZFX01JTUUiLCJtb3ZlUmVqZWN0aW9uIiwiZnJvbSIsInRhcmdldERpciIsImZyb21Sb290IiwidGFyZ2V0Um9vdCIsImYiLCJ0IiwibW92ZVJlZnVzYWxMYWJlbCIsImRpckFicyIsImRpclJvb3RQYXRoIiwicmVhc29uIiwiV1JJVEVfRVJSIiwidXBsb2FkVGFyZ2V0RGlyIiwicm93Iiwic2NvcGVSb290IiwiaXNEaXIiLCJ1cGxvYWRSb3dGcm9tRXZlbnQiLCJlIiwiZmFsbGJhY2tEaXIiLCJlbCIsImNsb3Nlc3QiLCJnZXRBdHRyaWJ1dGUiLCJJTkxJTkVfRFJBR19PVVRfQllURVMiLCJleGlzdHMiLCJwcm90ZWN0ZWQiLCJmb3JiaWRkZW4iXSwic291cmNlcyI6WyJleHBsb3Jlci50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBQdXJlIGhlbHBlcnMgZm9yIHRoZSBmaWxlIGV4cGxvcmVyIOKAlCBwYXRoIG1hdGgsIHJvb3QgbWV0YWRhdGEgcmVhZCBmcm9tIHRoZVxuLy8gZ2VuZXJhbGl6ZWQgRXhwbG9yZXJSb290LCBhbmQgdGhlIG1vdmUvdXBsb2FkL2RyYWcgdmFsaWRpdHkgcHJlZGljYXRlcy5cbi8vIEZyYW1ld29yay1mcmVlIGFuZCBzaWRlLWVmZmVjdC1mcmVlIHNvIHRoZXkgdW5pdC10ZXN0IGRpcmVjdGx5ICh3YXlzX29mX3dvcmtpbmdcbi8vIMKnNTsgZmlsZS1leHBsb3JlciBDTEFVREUubWQpLiBObyBSZWFjdCwgTk8gU0RLIGltcG9ydCBoZXJlIOKAlCB0aGUgdmlldyByZWFkc1xuLy8gcm9vdHMgdGhyb3VnaCBFeHBsb3JlclJvb3QsIGFuZCB0aGUgU0RLIGFkYXB0ZXIgKGBzZGsvbW91bnRzLnRzYCkgaXMgd2hhdCBtYXBzXG4vLyBhIFNhbmRib3hNb3VudCBvbnRvIHRoYXQgc2hhcGUuXG5pbXBvcnQgdHlwZSB7IEV4cGxvcmVyUm9vdCB9IGZyb20gXCIuL3R5cGVzXCI7XG5cbi8qKiBKb2luIGEgZGlyZWN0b3J5IGFuZCBhIGNoaWxkIG5hbWUgaW50byBvbmUgbm9ybWFsaXplZCBhYnNvbHV0ZS9yZWwgcGF0aC4gKi9cbmV4cG9ydCBjb25zdCBqb2luUGF0aCA9IChkaXI6IHN0cmluZywgbmFtZTogc3RyaW5nKTogc3RyaW5nID0+XG4gIGAke2Rpci5yZXBsYWNlKC9cXC8rJC8sIFwiXCIpfS8ke25hbWV9YDtcblxuLyoqIFRoZSBsYXN0IHBhdGggc2VnbWVudCAoYmFzZW5hbWUpIG9mIGEgc2xhc2ggcGF0aC4gKi9cbmV4cG9ydCBjb25zdCBiYXNlbmFtZSA9IChwOiBzdHJpbmcpOiBzdHJpbmcgPT4gcC5zcGxpdChcIi9cIikuZmlsdGVyKEJvb2xlYW4pLnBvcCgpID8/IFwiXCI7XG5cbi8qKiBUaGUgcGFyZW50IGRpcmVjdG9yeSBvZiBhIHNsYXNoIHBhdGggKG5vIHRyYWlsaW5nIHNsYXNoOyBcIi9cIiBmb3IgYSByb290IGNoaWxkKS4gKi9cbmV4cG9ydCBjb25zdCBkaXJPZiA9IChwOiBzdHJpbmcpOiBzdHJpbmcgPT4ge1xuICBjb25zdCB0cmltbWVkID0gcC5yZXBsYWNlKC9cXC8rJC8sIFwiXCIpO1xuICBjb25zdCBpID0gdHJpbW1lZC5sYXN0SW5kZXhPZihcIi9cIik7XG4gIHJldHVybiBpIDw9IDAgPyBcIi9cIiA6IHRyaW1tZWQuc2xpY2UoMCwgaSk7XG59O1xuXG4vKiogQSBtb3VudC1hYnNvbHV0ZSBwYXRoIG1hZGUgcmVwby0vbW91bnQtcmVsYXRpdmUgKGxlYWRpbmcgc2xhc2gpIGZvciB0aGUgU0RLXG4gKiAgaW50ZW50cywgd2hpY2ggdGFrZSBtb3VudC1yZWxhdGl2ZSBwYXRocyAoZS5nLiBgL3NyYy9BcHAudHN4YCkuICovXG5leHBvcnQgY29uc3QgdG9Nb3VudFJlbCA9IChyb290UGF0aDogc3RyaW5nLCBhYnNQYXRoOiBzdHJpbmcpOiBzdHJpbmcgPT5cbiAgYWJzUGF0aC5zbGljZShyb290UGF0aC5yZXBsYWNlKC9cXC8rJC8sIFwiXCIpLmxlbmd0aCkgfHwgXCIvXCI7XG5cbi8qKiBUaGUgaW52ZXJzZSBvZiB7QGxpbmsgdG9Nb3VudFJlbH06IGEgbW91bnQtcmVsYXRpdmUgZGlyIChcIi9zcmNcIikgbWFkZVxuICogIGFic29sdXRlIHVuZGVyIGByb290UGF0aGAgKFwiPHJvb3Q+L3NyY1wiKTsgXCIvXCIgbWFwcyB0byB0aGUgcm9vdCBpdHNlbGYuICovXG5leHBvcnQgY29uc3Qgam9pblJlbCA9IChyb290UGF0aDogc3RyaW5nLCByZWxEaXI6IHN0cmluZyk6IHN0cmluZyA9PiB7XG4gIGNvbnN0IG5vcm1hbGl6ZWQgPSBub3JtYWxpemVSZWwocmVsRGlyKTtcbiAgcmV0dXJuIG5vcm1hbGl6ZWQgPT09IFwiL1wiID8gcm9vdFBhdGgucmVwbGFjZSgvXFwvKyQvLCBcIlwiKSA6IGpvaW5QYXRoKHJvb3RQYXRoLCBub3JtYWxpemVkLnNsaWNlKDEpKTtcbn07XG5cbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuLy8gUm9vdCBtZXRhZGF0YSAoUjMtNzkgLyBGSUxFX0VYUExPUkVSX1NQRUMgwqcyKSDigJQgb3ZlciB0aGUgZ2VuZXJhbGl6ZWRcbi8vIEV4cGxvcmVyUm9vdC4gVGhlIFNESyBhZGFwdGVyIHBvcHVsYXRlcyB0aGVzZSBmaWVsZHMgZnJvbSBhIFNhbmRib3hNb3VudDsgdGhlXG4vLyB2aWV3IHJlYWRzIHRoZW0gdGhyb3VnaCB0aGVzZSBhY2Nlc3NvcnMgc28gdGhlIGxheW91dHMgc3RheSBkZWNvdXBsZWQuXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuLyoqIEEgaHVtYW4tcmVhZGFibGUgc2NvcGUgbGFiZWwgKGFscmVhZHkgcmVzb2x2ZWQgb250byB0aGUgcm9vdCBieSB0aGUgYWRhcHRlcikuICovXG5leHBvcnQgY29uc3QgbW91bnRMYWJlbCA9IChyOiBFeHBsb3JlclJvb3QpOiBzdHJpbmcgPT4gci5sYWJlbDtcblxuLyoqIFRoZSBwcm92aWRlci90eXBlIGtpbmQgb2YgYSByb290LCBmb3IgdGhlIEFwcC1zY29wZSBoZWFkZXIgaWNvbiAoUFJJTkNJUEFMU1xuICogIMKnOSBCMSkuIEEgY2xhc3NpZmllciBvbmx5IOKAlCB0aGUgaWNvbiBtYXBwaW5nIGxpdmVzIGluIHRoZSB2aWV3LiAqL1xuZXhwb3J0IHR5cGUgTW91bnRLaW5kID0gRXhwbG9yZXJSb290W1wia2luZFwiXTtcbmV4cG9ydCBjb25zdCBtb3VudEtpbmQgPSAocjogRXhwbG9yZXJSb290KTogTW91bnRLaW5kID0+IHIua2luZDtcblxuLyoqIFRoZSBzcGFjZUlkIG9mIGEgc3BhY2Ugcm9vdCwgZm9yIGVqZWN0IChgdW5tb3VudFNwYWNlYCkuIE51bGwgZm9yIHJvb3RzIHRoYXRcbiAqICBhcmVuJ3QgZWplY3RhYmxlIHNwYWNlcyAod29ya3RyZWUsIHNldHRpbmdzKS4gKi9cbmV4cG9ydCBjb25zdCBtb3VudFNwYWNlSWQgPSAocjogRXhwbG9yZXJSb290KTogc3RyaW5nIHwgbnVsbCA9PiByLnNwYWNlSWQgPz8gbnVsbDtcblxuLyoqXG4gKiBXaGV0aGVyIHRoZSBleHBsb3JlciBvZmZlcnMgYW4gRUpFQ1QgKGRldGFjaCkgYWZmb3JkYW5jZSBvbiB0aGlzIHJvb3RcbiAqIChTUEFDRVNfVUlfU1BFQyDCpzMsIFItU1BBQ0VTLTMpLiBFamVjdCA9IGB1bm1vdW50U3BhY2VgIOKAlCBjbG9zZXMgdGhlIHNwYWNlIGZvclxuICogdGhpcyBzZXNzaW9uIG9ubHk7IGl0IGlzIE5PVCBsZWF2ZS9yZXZva2UuIE9mZmVyZWQgZm9yIHNwYWNlcyAvIGdyYW50ZWRcbiAqIHN1YnRyZWVzOyBORVZFUiBmb3IgdGhlIHdvcmt0cmVlIG9yIHRoZSBwZXItYXBwIGBzZXR0aW5nczpgIHN0b3JlLlxuICovXG5leHBvcnQgY29uc3QgaXNFamVjdGFibGUgPSAocjogRXhwbG9yZXJSb290KTogYm9vbGVhbiA9PiAhIXIuZWplY3RhYmxlO1xuXG4vKipcbiAqIFdoZXRoZXIgdGhlIGV4cGxvcmVyIHNob3VsZCBvZmZlciBXUklURSBhZmZvcmRhbmNlcyAobmV3L3JlbmFtZS9kZWxldGUvdXBsb2FkL1xuICogbW92ZSkgb24gdGhpcyByb290LiBUaGUgYWRhcHRlciBjb21wdXRlcyBlZmZlY3RpdmUgd3JpdGFiaWxpdHk7IHRoZSB2aWV3IGp1c3RcbiAqIHJlZmxlY3RzIGl0IOKAlCB0aGUgYWZmb3JkYW5jZXMgYXJlIEhJRERFTiBvbiBhIHJlYWQtb25seSByb290LCBuZXZlclxuICogc2hvd24tdGhlbi1gRVJPRlNgIChDTEFVREUubWQ6IG5ldmVyIHN1cmZhY2UgYEVST0ZTYCBhcyBVWCkuXG4gKi9cbmV4cG9ydCBjb25zdCBpc1dyaXRhYmxlTW91bnQgPSAocjogRXhwbG9yZXJSb290KTogYm9vbGVhbiA9PiByLndyaXRhYmxlO1xuXG4vKiogQSBtb3VudC1yZWxhdGl2ZSBwYXRoIGluIG9uZSBzaGFwZTogbGVhZGluZyBzbGFzaCwgbm8gdHJhaWxpbmcgc2xhc2guICovXG5jb25zdCBub3JtYWxpemVSZWwgPSAocDogc3RyaW5nKTogc3RyaW5nID0+IHtcbiAgY29uc3QgdHJpbW1lZCA9IChwIHx8IFwiL1wiKS5yZXBsYWNlKC9cXC8rJC8sIFwiXCIpO1xuICBpZiAodHJpbW1lZCA9PT0gXCJcIikgcmV0dXJuIFwiL1wiO1xuICByZXR1cm4gdHJpbW1lZC5zdGFydHNXaXRoKFwiL1wiKSA/IHRyaW1tZWQgOiBgLyR7dHJpbW1lZH1gO1xufTtcblxuLyoqXG4gKiBUaGUgbW9kZSB0aGUgYXBwIGFjdHVhbGx5IEhPTERTIGF0IGByZWxQYXRoYCBpbiB0aGlzIHJvb3Qg4oCUIGxvbmdlc3QgbWF0Y2hpbmdcbiAqIGBncmFudHNgIHByZWZpeCB3aW5zLCBleGFjdGx5IGFzIHRoZSBob3N0IHJlc29sdmVzIGEgZGVsZWdhdGlvbiBhZ2FpbnN0IGl0cyBydWxlXG4gKiBzZXQuIGByb2Agd2hlbiBub3RoaW5nIGlzIGtub3duLCBzbyBhIG1pc3NpbmcgcnVsZS1zZXQgY2FuIG9ubHkgZXZlciB1bmRlci1hc2suXG4gKlxuICogVGhpcyBpcyB0aGUgbW9kZSB0byBERUxFR0FURSBhdCAoUjMtMjY3IC8gUjMtMjY2OiBkaXNwYXRjaCBjaGFuZ2VzIHRoZSBwYWNrYWdpbmcsXG4gKiBub3QgdGhlIGF1dGhvcml0eSDigJQgdGhlIG1vdW50IGRlY2lkZXMgd2hldGhlciB0aGUgb3BlbmVkIHZpZXdlciBjYW4gZWRpdCkuIEl0IGlzXG4gKiBOT1Qge0BsaW5rIGlzV3JpdGFibGVNb3VudH0sIHdoaWNoIGFuc3dlcnMgYSBkaWZmZXJlbnQgcXVlc3Rpb246IHdoZXRoZXIgdGhlXG4gKiBleHBsb3JlciBpdHNlbGYgb2ZmZXJzIGNyZWF0ZS9yZW5hbWUvZGVsZXRlIGhlcmUuXG4gKi9cbmV4cG9ydCBjb25zdCBncmFudGVkTW9kZUF0ID0gKHI6IEV4cGxvcmVyUm9vdCwgcmVsUGF0aDogc3RyaW5nKTogXCJyb1wiIHwgXCJyd1wiID0+IHtcbiAgY29uc3QgdGFyZ2V0ID0gbm9ybWFsaXplUmVsKHJlbFBhdGgpO1xuICBsZXQgYmVzdCA9IC0xO1xuICBsZXQgbW9kZTogXCJyb1wiIHwgXCJyd1wiID0gXCJyb1wiO1xuICBmb3IgKGNvbnN0IHJ1bGUgb2Ygci5ncmFudHMgPz8gW10pIHtcbiAgICBjb25zdCBzdWJ0cmVlID0gbm9ybWFsaXplUmVsKHJ1bGUuc3VidHJlZSk7XG4gICAgY29uc3QgY292ZXJzID0gc3VidHJlZSA9PT0gXCIvXCIgfHwgdGFyZ2V0ID09PSBzdWJ0cmVlIHx8IHRhcmdldC5zdGFydHNXaXRoKGAke3N1YnRyZWV9L2ApO1xuICAgIGlmIChjb3ZlcnMgJiYgc3VidHJlZS5sZW5ndGggPiBiZXN0KSB7XG4gICAgICBiZXN0ID0gc3VidHJlZS5sZW5ndGg7XG4gICAgICBtb2RlID0gcnVsZS5tb2RlO1xuICAgIH1cbiAgfVxuICByZXR1cm4gbW9kZTtcbn07XG5cbi8qKiBPbmUgZGlzcGxheSByb3cgaW4gdGhlIEFwcC1zY29wZSBoZWFkZXI6IGEgZ3JhbnRlZCBzdWJ0cmVlIGFuZCB0aGUgbW9kZSBzaG93blxuICogIHRoZXJlIChQUklOQ0lQQUxTIMKnOSBCMSAvIEZJTEVfRVhQTE9SRVIgwqcyKS4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgTW91bnRTY29wZSB7XG4gIHN1YnRyZWU6IHN0cmluZztcbiAgbW9kZTogXCJyb1wiIHwgXCJyd1wiO1xufVxuXG4vKipcbiAqIFRoZSBncmFudGVkIHNjb3BlcyBvZiBhIHJvb3QgYXMgZGlzcGxheSByb3dzIOKAlCBvbmUgcGVyIHNjb3BlLCBzbyBhIHJvb3Qgd2l0aFxuICogc2V2ZXJhbCBzdWJ0cmVlcyBsaXN0cyBlYWNoIChGSUxFX0VYUExPUkVSIMKnMiBzdGVwIDIpLiBGYWxscyBiYWNrIHRvIGEgc2luZ2xlXG4gKiB3aG9sZS1tb3VudCByb3cgZnJvbSB0aGUgcm9vdCdzIGVmZmVjdGl2ZSB3cml0YWJpbGl0eSB3aGVuIGBzY29wZXNgIGlzIGFic2VudC5cbiAqIFRoZSBkaXNwbGF5ZWQgbW9kZSBpcyB0aGUgRUZGRUNUSVZFIG1vZGUgdGhlIGFkYXB0ZXIgYWxyZWFkeSBiYWtlZCBpbnRvIGVhY2hcbiAqIHNjb3BlLiBEZS1kdXBlZCBieSBzdWJ0cmVlIGFuZCBvcmRlcmVkIHJvb3QtZmlyc3QgdGhlbiBB4oaSWi5cbiAqL1xuZXhwb3J0IGNvbnN0IG1vdW50U2NvcGVzID0gKHI6IEV4cGxvcmVyUm9vdCk6IE1vdW50U2NvcGVbXSA9PiB7XG4gIGNvbnN0IGZhbGxiYWNrTW9kZTogXCJyb1wiIHwgXCJyd1wiID0gaXNXcml0YWJsZU1vdW50KHIpID8gXCJyd1wiIDogXCJyb1wiO1xuICBjb25zdCBzY29wZXMgPSByLnNjb3Blcz8ubGVuZ3RoID8gci5zY29wZXMgOiBbeyBzdWJ0cmVlOiBcIi9cIiwgbW9kZTogZmFsbGJhY2tNb2RlIH1dO1xuICBjb25zdCBzZWVuID0gbmV3IE1hcDxzdHJpbmcsIE1vdW50U2NvcGU+KCk7XG4gIGZvciAoY29uc3QgcyBvZiBzY29wZXMpIHtcbiAgICBjb25zdCBzdWJ0cmVlID0gcy5zdWJ0cmVlICYmIHMuc3VidHJlZS50cmltKCkgJiYgcy5zdWJ0cmVlICE9PSBcIi9cIiA/IHMuc3VidHJlZS50cmltKCkgOiBcIi9cIjtcbiAgICBpZiAoc2Vlbi5oYXMoc3VidHJlZSkpIGNvbnRpbnVlO1xuICAgIHNlZW4uc2V0KHN1YnRyZWUsIHsgc3VidHJlZSwgbW9kZTogcy5tb2RlIH0pO1xuICB9XG4gIHJldHVybiBbLi4uc2Vlbi52YWx1ZXMoKV0uc29ydCgoYSwgYikgPT5cbiAgICBhLnN1YnRyZWUgPT09IFwiL1wiID8gLTEgOiBiLnN1YnRyZWUgPT09IFwiL1wiID8gMSA6IGEuc3VidHJlZS5sb2NhbGVDb21wYXJlKGIuc3VidHJlZSksXG4gICk7XG59O1xuXG4vKiogQSBzaG9ydCBzdWJ0cmVlIGxhYmVsIGZvciB0aGUgc2luZ2xlLWNoaXAgbGF5b3V0cyAoYnJlYWRjcnVtYiAvIGNvbHVtbnMpIHdoZXJlXG4gKiAgb25seSB0aGUgY3VycmVudCBkaXJlY3RvcnkncyBvd25pbmcgcm9vdCBpcyBzaG93biAoXCIvXCIgZm9yIGEgd2hvbGUtbW91bnQgZ3JhbnQpLlxuICogIFRoZSBwZXItbW91bnQgaGVhZGVyIHVzZXMge0BsaW5rIG1vdW50U2NvcGVzfSBmb3IgdGhlIGZ1bGwgbGlzdC4gKi9cbmV4cG9ydCBjb25zdCBzdWJ0cmVlTGFiZWwgPSAocjogRXhwbG9yZXJSb290KTogc3RyaW5nID0+IHtcbiAgY29uc3QgZmlyc3QgPSByLnNjb3Blcz8uWzBdO1xuICByZXR1cm4gZmlyc3Q/LnN1YnRyZWUgJiYgZmlyc3Quc3VidHJlZSAhPT0gXCIvXCIgPyBmaXJzdC5zdWJ0cmVlIDogXCIvXCI7XG59O1xuXG4vKiogT3JkZXIgcm9vdHMgZm9yIGRpc3BsYXk6IHdvcmt0cmVlIGZpcnN0LCB0aGVuIHNwYWNlcywgdGhlbiBvdGhlcnMsIEHihpJaLiAqL1xuZXhwb3J0IGNvbnN0IG9yZGVyTW91bnRzID0gKHJvb3RzOiBFeHBsb3JlclJvb3RbXSk6IEV4cGxvcmVyUm9vdFtdID0+XG4gIFsuLi5yb290c10uc29ydCgoYSwgYikgPT4ge1xuICAgIGNvbnN0IHJhbmsgPSAocjogRXhwbG9yZXJSb290KSA9PlxuICAgICAgci5raW5kID09PSBcIndvcmt0cmVlXCIgPyAwIDogci5raW5kID09PSBcInNwYWNlXCIgPyAxIDogMjtcbiAgICByZXR1cm4gcmFuayhhKSAtIHJhbmsoYikgfHwgbW91bnRMYWJlbChhKS5sb2NhbGVDb21wYXJlKG1vdW50TGFiZWwoYikpO1xuICB9KTtcblxuLy8gRmlsZXMgdGhlIGhvc3QgcmVmdXNlcyB0byBkZWxldGUvcmVuYW1lIOKAlCBoaWRlIHRoZSBhZmZvcmRhbmNlIHRvIG1hdGNoICh0aGVcbi8vIGhvc3QgYWxzbyBlbmZvcmNlcyBpdCwgcmV0dXJuaW5nIGBwcm90ZWN0ZWRgKS4gU2hhcmVkIGJ5IGV2ZXJ5IGxheW91dCBzbyB0aGVcbi8vIGdhdGluZyBpcyBpZGVudGljYWwgaW4gdHJlZSAvIGxpc3QgLyBpY29ucyAvIGNvbHVtbnMuIE1vdW50LXJlbGF0aXZlIHBhdGhzLlxuY29uc3QgUFJPVEVDVEVEID0gbmV3IFNldChbXCIvcGFja2FnZS5qc29uXCJdKTtcblxuLyoqIElzIHRoaXMgbW91bnQtcmVsYXRpdmUgcGF0aCBvbmUgdGhlIGhvc3QgcHJvdGVjdHMgZnJvbSBkZWxldGUvcmVuYW1lPyAqL1xuZXhwb3J0IGNvbnN0IGlzUHJvdGVjdGVkID0gKG1vdW50UmVsOiBzdHJpbmcpOiBib29sZWFuID0+IFBST1RFQ1RFRC5oYXMobW91bnRSZWwpO1xuXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbi8vIEJyZWFkY3J1bWIgLyBjdXJyZW50LWRpcmVjdG9yeSBuYXZpZ2F0aW9uIChSMy04NCBsaXN0ICsgaWNvbnMgbGF5b3V0cylcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgaW50ZXJmYWNlIENydW1iIHtcbiAgLyoqIERpc3BsYXkgbGFiZWwgZm9yIHRoZSBzZWdtZW50LiAqL1xuICBsYWJlbDogc3RyaW5nO1xuICAvKiogQWJzb2x1dGUgcGF0aCB0aGUgc2VnbWVudCBuYXZpZ2F0ZXMgdG8sIG9yIG51bGwgZm9yIHRoZSBcIlNwYWNlc1wiIHJvb3QuICovXG4gIHBhdGg6IHN0cmluZyB8IG51bGw7XG59XG5cbi8qKlxuICogUmVzb2x2ZSBhIGN1cnJlbnQgZGlyZWN0b3J5IChgY3dkYCwgYWJzb2x1dGUgb3IgbnVsbCA9IHRoZSBTcGFjZXMgcm9vdCkgaW50byB0aGVcbiAqIG93bmluZyByb290IGFuZCBhIGJyZWFkY3J1bWIgdHJhaWwuIFRoZSB0cmFpbCBhbHdheXMgc3RhcnRzIGF0IFwiU3BhY2VzXCIgc28gdGhlXG4gKiB1c2VyIGNhbiBzdGVwIGJhY2sgb3V0IHRvIHRoZSByb290IGxpc3QgKG1pcnJvcmluZyB0aGUgbW9iaWxlIHByb2plY3Rpb24gaW5cbiAqIGJyaWVmIDEzKS4gV2hlbiBgY3dkYCBmYWxscyBpbnNpZGUgYSByb290LCBzZWdtZW50cyBhcmU6IFNwYWNlcyA+IDxyb290PiA+XG4gKiA8c3ViZGlyLi4uPi4gV2hlbiBgY3dkYCBpcyBudWxsIChvciB1bnJlc29sdmFibGUpLCBvbmx5IHRoZSBTcGFjZXMgcm9vdCBpcyBzaG93bi5cbiAqIFB1cmUg4oCUIG5vIFJlYWN0LCBubyBJL08uXG4gKi9cbmV4cG9ydCBjb25zdCBicmVhZGNydW1iRm9yID0gKFxuICBjd2Q6IHN0cmluZyB8IG51bGwsXG4gIG9yZGVyZWQ6IEV4cGxvcmVyUm9vdFtdLFxuKTogeyBtb3VudDogRXhwbG9yZXJSb290IHwgbnVsbDsgY3J1bWJzOiBDcnVtYltdIH0gPT4ge1xuICBjb25zdCByb290OiBDcnVtYiA9IHsgbGFiZWw6IFwiU3BhY2VzXCIsIHBhdGg6IG51bGwgfTtcbiAgaWYgKCFjd2QpIHJldHVybiB7IG1vdW50OiBudWxsLCBjcnVtYnM6IFtyb290XSB9O1xuICBjb25zdCBtb3VudCA9IG9yZGVyZWQuZmluZCgobSkgPT4gY3dkID09PSBtLnBhdGggfHwgY3dkLnN0YXJ0c1dpdGgobS5wYXRoICsgXCIvXCIpKSA/PyBudWxsO1xuICBpZiAoIW1vdW50KSByZXR1cm4geyBtb3VudDogbnVsbCwgY3J1bWJzOiBbcm9vdF0gfTtcblxuICBjb25zdCBjcnVtYnM6IENydW1iW10gPSBbcm9vdCwgeyBsYWJlbDogbW91bnRMYWJlbChtb3VudCksIHBhdGg6IG1vdW50LnBhdGggfV07XG4gIGNvbnN0IHJlbCA9IHRvTW91bnRSZWwobW91bnQucGF0aCwgY3dkKTsgLy8gZS5nLiBcIi9zcmMvY29tcG9uZW50c1wiIG9yIFwiL1wiXG4gIGNvbnN0IHNlZ3MgPSByZWwuc3BsaXQoXCIvXCIpLmZpbHRlcihCb29sZWFuKTtcbiAgbGV0IGFjYyA9IG1vdW50LnBhdGg7XG4gIGZvciAoY29uc3Qgc2VnIG9mIHNlZ3MpIHtcbiAgICBhY2MgPSBqb2luUGF0aChhY2MsIHNlZyk7XG4gICAgY3J1bWJzLnB1c2goeyBsYWJlbDogc2VnLCBwYXRoOiBhY2MgfSk7XG4gIH1cbiAgcmV0dXJuIHsgbW91bnQsIGNydW1icyB9O1xufTtcblxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vLyBEcmFnLWFuZC1kcm9wIHZhbGlkaXR5IChSMy04MSBtb3ZlIC8gUjMtODIgdXBsb2FkKVxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbi8qKiBQcml2YXRlIE1JTUUgdGhlIGV4cGxvcmVyIHNldHMgb24gYW4gaW50ZXJuYWwgKHNhbWUtYXBwKSBtb3ZlIGRyYWcsIHNvIGFuXG4gKiAgaW50ZXJuYWwgcm93IGRyYWcgaXMgZGlzdGluZ3Vpc2hhYmxlIGZyb20gYW4gT1MtZmlsZSBkcm9wIGFuZCBhIMKnNyBkcmFnLW91dC4gKi9cbmV4cG9ydCBjb25zdCBNT1ZFX01JTUUgPSBcImFwcGxpY2F0aW9uL3gtaXItZmlsZS1tb3ZlXCI7XG5cbmV4cG9ydCBpbnRlcmZhY2UgTW92ZVBheWxvYWQge1xuICAvKiogQWJzb2x1dGUgc291cmNlIHBhdGguICovXG4gIGZyb206IHN0cmluZztcbiAgLyoqIFRoZSByb290IHBhdGggb2YgdGhlIHNvdXJjZSBtb3VudCAodG8gZm9yYmlkIGNyb3NzLW1vdW50IG1vdmVzKS4gKi9cbiAgcm9vdFBhdGg6IHN0cmluZztcbiAgLyoqIFdoZXRoZXIgdGhlIGRyYWdnZWQgdGhpbmcgaXMgYSBmb2xkZXIgKHNvIGEgZmFpbGVkIG1vdmUgcmVzdG9yZXMgdGhlXG4gICAqICByaWdodCByb3cgc2hhcGUgd2hlbiB0aGUgc291cmNlIGxpc3RpbmcgaXMgbm8gbG9uZ2VyIGNhY2hlZCkuICovXG4gIGlzRGlyOiBib29sZWFuO1xufVxuXG4vKipcbiAqIENhbiBgZnJvbWAgYmUgbW92ZWQgSU5UTyBkaXJlY3RvcnkgYHRhcmdldERpcmAgKGJvdGggYWJzb2x1dGUgcGF0aHMgaW4gdGhlIHNhbWVcbiAqIG1vdW50KT8gUmVqZWN0czogYSBuby1vcCAoYWxyZWFkeSBpbiB0aGF0IGRpciksIGEgZGlyZWN0b3J5IGRyb3BwZWQgb250byBpdHNlbGZcbiAqIG9yIGEgZGVzY2VuZGFudCwgYW5kICh0aGUgY2FsbGVyIGVuZm9yY2VzKSBjcm9zcy1tb3VudCBkcm9wcy4gUmV0dXJucyB0aGUgcmVhc29uXG4gKiBjb2RlIG9uIHJlamVjdGlvbiBzbyB0aGUgVUkgY2FuIGhpbnQsIG9yIGBudWxsYCB3aGVuIHRoZSBtb3ZlIGlzIGFsbG93ZWQuXG4gKi9cbmV4cG9ydCBjb25zdCBtb3ZlUmVqZWN0aW9uID0gKFxuICBmcm9tOiBzdHJpbmcsXG4gIHRhcmdldERpcjogc3RyaW5nLFxuICBmcm9tUm9vdDogc3RyaW5nLFxuICB0YXJnZXRSb290OiBzdHJpbmcsXG4pOiBcImNyb3NzLW1vdW50XCIgfCBcInNhbWUtZGlyXCIgfCBcImludG8tc2VsZlwiIHwgbnVsbCA9PiB7XG4gIGlmIChmcm9tUm9vdCAhPT0gdGFyZ2V0Um9vdCkgcmV0dXJuIFwiY3Jvc3MtbW91bnRcIjtcbiAgaWYgKGRpck9mKGZyb20pID09PSB0YXJnZXREaXIucmVwbGFjZSgvXFwvKyQvLCBcIlwiKSkgcmV0dXJuIFwic2FtZS1kaXJcIjtcbiAgY29uc3QgZiA9IGZyb20ucmVwbGFjZSgvXFwvKyQvLCBcIlwiKTtcbiAgY29uc3QgdCA9IHRhcmdldERpci5yZXBsYWNlKC9cXC8rJC8sIFwiXCIpO1xuICBpZiAodCA9PT0gZiB8fCB0LnN0YXJ0c1dpdGgoZiArIFwiL1wiKSkgcmV0dXJuIFwiaW50by1zZWxmXCI7XG4gIHJldHVybiBudWxsO1xufTtcblxuLyoqIFRoZSBodW1hbiBzZW50ZW5jZSBmb3IgYSBkZXN0aW5hdGlvbiB0aGUgbW92ZSByZWZ1c2VzLCBvciBudWxsIHdoZW4gaXRcbiAqICBkb2Vzbid0IOKAlCB0aGUgbW92ZSBwaWNrZXIncyBkaXNhYmxlZC1idXR0b24gcmVhc29uLiAqL1xuZXhwb3J0IGNvbnN0IG1vdmVSZWZ1c2FsTGFiZWwgPSAoXG4gIHRhcmdldDogeyBhYnNQYXRoOiBzdHJpbmc7IHJvb3RQYXRoOiBzdHJpbmc7IG5hbWU6IHN0cmluZyB9LFxuICBkaXJBYnM6IHN0cmluZyxcbiAgZGlyUm9vdFBhdGg6IHN0cmluZyxcbik6IHN0cmluZyB8IG51bGwgPT4ge1xuICBjb25zdCByZWFzb24gPSBtb3ZlUmVqZWN0aW9uKHRhcmdldC5hYnNQYXRoLCBkaXJBYnMsIHRhcmdldC5yb290UGF0aCwgZGlyUm9vdFBhdGgpO1xuICBpZiAocmVhc29uID09PSBcImNyb3NzLW1vdW50XCIpIHJldHVybiBXUklURV9FUlJbXCJjcm9zcy1tb3VudFwiXTtcbiAgaWYgKHJlYXNvbiA9PT0gXCJzYW1lLWRpclwiKSByZXR1cm4gYCR7dGFyZ2V0Lm5hbWV9IGlzIGFscmVhZHkgaW4gdGhpcyBmb2xkZXIuYDtcbiAgaWYgKHJlYXNvbiA9PT0gXCJpbnRvLXNlbGZcIikgcmV0dXJuIFwiQSBmb2xkZXIgY2Fu4oCZdCBtb3ZlIGludG8gaXRzZWxmLlwiO1xuICByZXR1cm4gbnVsbDtcbn07XG5cbi8qKlxuICogV2hlcmUgYW4gT1MtZmlsZSBkcm9wIGxhbmRzIChgRklMRV9FWFBMT1JFUl9TUEVDIMKnNWApOiB0aGUgZGlyZWN0b3J5IHJvdyB1bmRlclxuICogdGhlIHBvaW50ZXIsIHRoZSBQQVJFTlQgb2YgYSBmaWxlIHJvdywgb3IgdGhlIHNjb3BlIHJvb3Qgd2hlbiB0aGUgZHJvcCBtaXNzZXNcbiAqIGV2ZXJ5IHJvdyDigJQgYSBkcm9wIG9uIHRoZSBibGFuayBzcGFjZSBiZWxvdyB0aGUgdHJlZSwgb3Igb24gdGhlIHNjb3BlIGhlYWRlci5cbiAqIFRoZSDCpzUgdXBsb2FkIEJVVFRPTiByZXNvbHZlcyBpdHMgZGVzdGluYXRpb24gdGhyb3VnaCB0aGUgc2FtZSBzaGFwZTogaXRzXG4gKiBcInJvd1wiIGlzIHRoZSBTRUxFQ1RJT04gKGEgc2VsZWN0ZWQgZGlyIGl0c2VsZiwgYSBzZWxlY3RlZCBmaWxlJ3MgcGFyZW50KVxuICogYW5kIHRoZSBmYWxsYmFjayBpcyB0aGUgcmVwbyByb290IHdoZW4gbm90aGluZyBpcyBzZWxlY3RlZC5cbiAqXG4gKiBgcm93YCBpcyB3aGF0IHRoZSBkcm9wIHBvaW50IHJlc29sdmVzIHRvLCBvciBgbnVsbGAgd2hlbiBpdCByZXNvbHZlcyB0byBub3RoaW5nLlxuICogRGlyZWN0b3J5IHJvd3MgYW5zd2VyIHRoaXMgZm9yIHRoZW1zZWx2ZXMgYmVmb3JlIHRoZSBldmVudCByZWFjaGVzIGEgY29udGFpbmVyLFxuICogc28gaW4gcHJhY3RpY2UgdGhpcyBkZWNpZGVzIHRoZSB0d28gY2FzZXMgdGhhdCB1c2VkIHRvIGJlIHNpbGVudCBuby1vcHMuXG4gKi9cbmV4cG9ydCBjb25zdCB1cGxvYWRUYXJnZXREaXIgPSAoXG4gIHJvdzogeyBwYXRoOiBzdHJpbmc7IGlzRGlyOiBib29sZWFuIH0gfCBudWxsLFxuICBzY29wZVJvb3Q6IHN0cmluZyxcbik6IHN0cmluZyA9PiAocm93ID8gKHJvdy5pc0RpciA/IHJvdy5wYXRoIDogZGlyT2Yocm93LnBhdGgpKSA6IHNjb3BlUm9vdCk7XG5cbi8qKlxuICogVGhlIERPTeKGknJvdyBoYWxmIG9mIGFuIE9TLWZpbGUgZHJvcCAoUjMtNjI2KTogcmVzb2x2ZSB0aGUgZWxlbWVudCB0aGUgZHJvcFxuICogbGFuZGVkIG9uIHRvIGEgcm93IHZpYSB0aGUgYGRhdGEtcGF0aGAvYGRhdGEtZGlyYCBhdHRyaWJ1dGVzIGV2ZXJ5IHJvd1xuICogY2FycmllcywgdGhlbiBgdXBsb2FkVGFyZ2V0RGlyYCBhZ2FpbnN0IHRoZSBjb250YWluZXIncyBmYWxsYmFjay4gT05FIGhvbWUg4oCUXG4gKiB0aGUgZmxhdCBjb250YWluZXJzJyBob29rIGFuZCB0aGUgdHJlZSdzIHNjb3BlIHJlc29sdmUgaWRlbnRpY2FsbHksIGFuZCB0aGlzXG4gKiBpcyB0aGUgYmxvY2sgdGhhdCBtdXN0IG5vdCBkcmlmdCBiZXR3ZWVuIHRoZW0uXG4gKi9cbmV4cG9ydCBjb25zdCB1cGxvYWRSb3dGcm9tRXZlbnQgPSAoZTogeyB0YXJnZXQ6IEV2ZW50VGFyZ2V0IHwgbnVsbCB9LCBmYWxsYmFja0Rpcjogc3RyaW5nKTogc3RyaW5nID0+IHtcbiAgY29uc3QgZWwgPSAoZS50YXJnZXQgYXMgSFRNTEVsZW1lbnQgfCBudWxsKT8uY2xvc2VzdD8uKFwiW2RhdGEtcGF0aF1cIikgPz8gbnVsbDtcbiAgY29uc3Qgcm93ID0gZWxcbiAgICA/IHsgcGF0aDogZWwuZ2V0QXR0cmlidXRlKFwiZGF0YS1wYXRoXCIpID8/IGZhbGxiYWNrRGlyLCBpc0RpcjogZWwuZ2V0QXR0cmlidXRlKFwiZGF0YS1kaXJcIikgPT09IFwiMVwiIH1cbiAgICA6IG51bGw7XG4gIHJldHVybiB1cGxvYWRUYXJnZXREaXIocm93LCBmYWxsYmFja0Rpcik7XG59O1xuXG4vKiogUjMtODUzOiB0aGUgaW5saW5lLWJ5dGVzIGNvbnZlbmllbmNlIGJvdW5kIGZvciBEUkFHLU9VVCBvbmx5LiBJbmxpbmluZyBpcyBhXG4gKiAgYmVzdC1lZmZvcnQgY29udmVuaWVuY2Ug4oCUIGEgbGFyZ2VyIGZpbGUgZ29lcyByZWZlcmVuY2Utb25seSwgd2hpY2ggaXMgbm90IGFcbiAqICByZWZ1c2FsLiBUaGUgVVBMT0FEIHBhdGggaGFzIG5vIGNsaWVudCBjYXAgYXQgYWxsIGFueW1vcmU6IHRoZSBob3N0IGVuZm9yY2VzXG4gKiAgKGFuZCBuYW1lcykgdGhlIHJlYWwgb25lIChgd3JpdGVMaW1pdHMuTUFYX1RSQU5TRkVSX0JZVEVTYCBpbiBzaXRlLW1haW4pLiAqL1xuZXhwb3J0IGNvbnN0IElOTElORV9EUkFHX09VVF9CWVRFUyA9IDEwMjQgKiAxMDI0O1xuXG4vKiogTWFwIGEgaG9zdCB3cml0ZS1vdXRjb21lIGNvZGUgdG8gYSBmcmllbmRseSBtZXNzYWdlIChzaGFyZWQgYnkgZXZlcnkgbXV0YXRpb24pLiAqL1xuZXhwb3J0IGNvbnN0IFdSSVRFX0VSUjogUmVjb3JkPHN0cmluZywgc3RyaW5nPiA9IHtcbiAgZXhpc3RzOiBcIlNvbWV0aGluZyB3aXRoIHRoYXQgbmFtZSBhbHJlYWR5IGV4aXN0cy5cIixcbiAgcHJvdGVjdGVkOiBcIlRoYXQgZmlsZSBjYW7igJl0IGJlIGRlbGV0ZWQuXCIsXG4gIFwidG9vLWxhcmdlXCI6IFwiVGhhdCBmaWxlIGlzIHRvbyBsYXJnZSB0byB1cGxvYWQuXCIsIC8vIHRoZSBuby1saW1pdEJ5dGVzIGZhbGxiYWNrIChhbiBvbGRlciBob3N0KVxuICBcIm5vdC1mb3VuZFwiOiBcIlRoYXQgZmlsZSBubyBsb25nZXIgZXhpc3RzLlwiLFxuICBmb3JiaWRkZW46IFwiWW91IGRvbuKAmXQgaGF2ZSBwZXJtaXNzaW9uIHRvIGNoYW5nZSBmaWxlcyBoZXJlLlwiLFxuICBcImludmFsaWQtcGFyYW1zXCI6IFwiVGhhdCBuYW1lIGlzbuKAmXQgdmFsaWQuXCIsXG4gIFwiY3Jvc3MtbW91bnRcIjogXCJDYW7igJl0IG1vdmUgYmV0d2VlbiBzcGFjZXMgeWV0LlwiLFxufTtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUdBO0FBQ08sTUFBTUEsUUFBUSxHQUFHQSxDQUFDQyxHQUFXLEVBQUVDLElBQVksS0FDaEQsR0FBR0QsR0FBRyxDQUFDRSxPQUFPLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxJQUFJRCxJQUFJLEVBQUU7O0FBRXRDO0FBQUFFLE9BQUEsQ0FBQUosUUFBQSxHQUFBQSxRQUFBO0FBQ08sTUFBTUssUUFBUSxHQUFJQyxDQUFTLElBQWFBLENBQUMsQ0FBQ0MsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDQyxNQUFNLENBQUNDLE9BQU8sQ0FBQyxDQUFDQyxHQUFHLENBQUMsQ0FBQyxJQUFJLEVBQUU7O0FBRXZGO0FBQUFOLE9BQUEsQ0FBQUMsUUFBQSxHQUFBQSxRQUFBO0FBQ08sTUFBTU0sS0FBSyxHQUFJTCxDQUFTLElBQWE7RUFDMUMsTUFBTU0sT0FBTyxHQUFHTixDQUFDLENBQUNILE9BQU8sQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDO0VBQ3JDLE1BQU1VLENBQUMsR0FBR0QsT0FBTyxDQUFDRSxXQUFXLENBQUMsR0FBRyxDQUFDO0VBQ2xDLE9BQU9ELENBQUMsSUFBSSxDQUFDLEdBQUcsR0FBRyxHQUFHRCxPQUFPLENBQUNHLEtBQUssQ0FBQyxDQUFDLEVBQUVGLENBQUMsQ0FBQztBQUMzQyxDQUFDOztBQUVEO0FBQ0E7QUFEQVQsT0FBQSxDQUFBTyxLQUFBLEdBQUFBLEtBQUE7QUFFTyxNQUFNSyxVQUFVLEdBQUdBLENBQUNDLFFBQWdCLEVBQUVDLE9BQWUsS0FDMURBLE9BQU8sQ0FBQ0gsS0FBSyxDQUFDRSxRQUFRLENBQUNkLE9BQU8sQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLENBQUNnQixNQUFNLENBQUMsSUFBSSxHQUFHOztBQUUzRDtBQUNBO0FBREFmLE9BQUEsQ0FBQVksVUFBQSxHQUFBQSxVQUFBO0FBRU8sTUFBTUksT0FBTyxHQUFHQSxDQUFDSCxRQUFnQixFQUFFSSxNQUFjLEtBQWE7RUFDbkUsTUFBTUMsVUFBVSxHQUFHQyxZQUFZLENBQUNGLE1BQU0sQ0FBQztFQUN2QyxPQUFPQyxVQUFVLEtBQUssR0FBRyxHQUFHTCxRQUFRLENBQUNkLE9BQU8sQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEdBQUdILFFBQVEsQ0FBQ2lCLFFBQVEsRUFBRUssVUFBVSxDQUFDUCxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEcsQ0FBQzs7QUFFRDtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQUFYLE9BQUEsQ0FBQWdCLE9BQUEsR0FBQUEsT0FBQTtBQUNPLE1BQU1JLFVBQVUsR0FBSUMsQ0FBZSxJQUFhQSxDQUFDLENBQUNDLEtBQUs7O0FBRTlEO0FBQ0E7QUFEQXRCLE9BQUEsQ0FBQW9CLFVBQUEsR0FBQUEsVUFBQTtBQUdPLE1BQU1HLFNBQVMsR0FBSUYsQ0FBZSxJQUFnQkEsQ0FBQyxDQUFDRyxJQUFJOztBQUUvRDtBQUNBO0FBREF4QixPQUFBLENBQUF1QixTQUFBLEdBQUFBLFNBQUE7QUFFTyxNQUFNRSxZQUFZLEdBQUlKLENBQWUsSUFBb0JBLENBQUMsQ0FBQ0ssT0FBTyxJQUFJLElBQUk7O0FBRWpGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUxBMUIsT0FBQSxDQUFBeUIsWUFBQSxHQUFBQSxZQUFBO0FBTU8sTUFBTUUsV0FBVyxHQUFJTixDQUFlLElBQWMsQ0FBQyxDQUFDQSxDQUFDLENBQUNPLFNBQVM7O0FBRXRFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUxBNUIsT0FBQSxDQUFBMkIsV0FBQSxHQUFBQSxXQUFBO0FBTU8sTUFBTUUsZUFBZSxHQUFJUixDQUFlLElBQWNBLENBQUMsQ0FBQ1MsUUFBUTs7QUFFdkU7QUFBQTlCLE9BQUEsQ0FBQTZCLGVBQUEsR0FBQUEsZUFBQTtBQUNBLE1BQU1WLFlBQVksR0FBSWpCLENBQVMsSUFBYTtFQUMxQyxNQUFNTSxPQUFPLEdBQUcsQ0FBQ04sQ0FBQyxJQUFJLEdBQUcsRUFBRUgsT0FBTyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUM7RUFDOUMsSUFBSVMsT0FBTyxLQUFLLEVBQUUsRUFBRSxPQUFPLEdBQUc7RUFDOUIsT0FBT0EsT0FBTyxDQUFDdUIsVUFBVSxDQUFDLEdBQUcsQ0FBQyxHQUFHdkIsT0FBTyxHQUFHLElBQUlBLE9BQU8sRUFBRTtBQUMxRCxDQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sTUFBTXdCLGFBQWEsR0FBR0EsQ0FBQ1gsQ0FBZSxFQUFFWSxPQUFlLEtBQWtCO0VBQzlFLE1BQU1DLE1BQU0sR0FBR2YsWUFBWSxDQUFDYyxPQUFPLENBQUM7RUFDcEMsSUFBSUUsSUFBSSxHQUFHLENBQUMsQ0FBQztFQUNiLElBQUlDLElBQWlCLEdBQUcsSUFBSTtFQUM1QixLQUFLLE1BQU1DLElBQUksSUFBSWhCLENBQUMsQ0FBQ2lCLE1BQU0sSUFBSSxFQUFFLEVBQUU7SUFDakMsTUFBTUMsT0FBTyxHQUFHcEIsWUFBWSxDQUFDa0IsSUFBSSxDQUFDRSxPQUFPLENBQUM7SUFDMUMsTUFBTUMsTUFBTSxHQUFHRCxPQUFPLEtBQUssR0FBRyxJQUFJTCxNQUFNLEtBQUtLLE9BQU8sSUFBSUwsTUFBTSxDQUFDSCxVQUFVLENBQUMsR0FBR1EsT0FBTyxHQUFHLENBQUM7SUFDeEYsSUFBSUMsTUFBTSxJQUFJRCxPQUFPLENBQUN4QixNQUFNLEdBQUdvQixJQUFJLEVBQUU7TUFDbkNBLElBQUksR0FBR0ksT0FBTyxDQUFDeEIsTUFBTTtNQUNyQnFCLElBQUksR0FBR0MsSUFBSSxDQUFDRCxJQUFJO0lBQ2xCO0VBQ0Y7RUFDQSxPQUFPQSxJQUFJO0FBQ2IsQ0FBQzs7QUFFRDtBQUNBO0FBREFwQyxPQUFBLENBQUFnQyxhQUFBLEdBQUFBLGFBQUE7QUFPQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLE1BQU1TLFdBQVcsR0FBSXBCLENBQWUsSUFBbUI7RUFDNUQsTUFBTXFCLFlBQXlCLEdBQUdiLGVBQWUsQ0FBQ1IsQ0FBQyxDQUFDLEdBQUcsSUFBSSxHQUFHLElBQUk7RUFDbEUsTUFBTXNCLE1BQU0sR0FBR3RCLENBQUMsQ0FBQ3NCLE1BQU0sRUFBRTVCLE1BQU0sR0FBR00sQ0FBQyxDQUFDc0IsTUFBTSxHQUFHLENBQUM7SUFBRUosT0FBTyxFQUFFLEdBQUc7SUFBRUgsSUFBSSxFQUFFTTtFQUFhLENBQUMsQ0FBQztFQUNuRixNQUFNRSxJQUFJLEdBQUcsSUFBSUMsR0FBRyxDQUFxQixDQUFDO0VBQzFDLEtBQUssTUFBTUMsQ0FBQyxJQUFJSCxNQUFNLEVBQUU7SUFDdEIsTUFBTUosT0FBTyxHQUFHTyxDQUFDLENBQUNQLE9BQU8sSUFBSU8sQ0FBQyxDQUFDUCxPQUFPLENBQUNRLElBQUksQ0FBQyxDQUFDLElBQUlELENBQUMsQ0FBQ1AsT0FBTyxLQUFLLEdBQUcsR0FBR08sQ0FBQyxDQUFDUCxPQUFPLENBQUNRLElBQUksQ0FBQyxDQUFDLEdBQUcsR0FBRztJQUMzRixJQUFJSCxJQUFJLENBQUNJLEdBQUcsQ0FBQ1QsT0FBTyxDQUFDLEVBQUU7SUFDdkJLLElBQUksQ0FBQ0ssR0FBRyxDQUFDVixPQUFPLEVBQUU7TUFBRUEsT0FBTztNQUFFSCxJQUFJLEVBQUVVLENBQUMsQ0FBQ1Y7SUFBSyxDQUFDLENBQUM7RUFDOUM7RUFDQSxPQUFPLENBQUMsR0FBR1EsSUFBSSxDQUFDTSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUNDLElBQUksQ0FBQyxDQUFDQyxDQUFDLEVBQUVDLENBQUMsS0FDbENELENBQUMsQ0FBQ2IsT0FBTyxLQUFLLEdBQUcsR0FBRyxDQUFDLENBQUMsR0FBR2MsQ0FBQyxDQUFDZCxPQUFPLEtBQUssR0FBRyxHQUFHLENBQUMsR0FBR2EsQ0FBQyxDQUFDYixPQUFPLENBQUNlLGFBQWEsQ0FBQ0QsQ0FBQyxDQUFDZCxPQUFPLENBQ3BGLENBQUM7QUFDSCxDQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUZBdkMsT0FBQSxDQUFBeUMsV0FBQSxHQUFBQSxXQUFBO0FBR08sTUFBTWMsWUFBWSxHQUFJbEMsQ0FBZSxJQUFhO0VBQ3ZELE1BQU1tQyxLQUFLLEdBQUduQyxDQUFDLENBQUNzQixNQUFNLEdBQUcsQ0FBQyxDQUFDO0VBQzNCLE9BQU9hLEtBQUssRUFBRWpCLE9BQU8sSUFBSWlCLEtBQUssQ0FBQ2pCLE9BQU8sS0FBSyxHQUFHLEdBQUdpQixLQUFLLENBQUNqQixPQUFPLEdBQUcsR0FBRztBQUN0RSxDQUFDOztBQUVEO0FBQUF2QyxPQUFBLENBQUF1RCxZQUFBLEdBQUFBLFlBQUE7QUFDTyxNQUFNRSxXQUFXLEdBQUlDLEtBQXFCLElBQy9DLENBQUMsR0FBR0EsS0FBSyxDQUFDLENBQUNQLElBQUksQ0FBQyxDQUFDQyxDQUFDLEVBQUVDLENBQUMsS0FBSztFQUN4QixNQUFNTSxJQUFJLEdBQUl0QyxDQUFlLElBQzNCQSxDQUFDLENBQUNHLElBQUksS0FBSyxVQUFVLEdBQUcsQ0FBQyxHQUFHSCxDQUFDLENBQUNHLElBQUksS0FBSyxPQUFPLEdBQUcsQ0FBQyxHQUFHLENBQUM7RUFDeEQsT0FBT21DLElBQUksQ0FBQ1AsQ0FBQyxDQUFDLEdBQUdPLElBQUksQ0FBQ04sQ0FBQyxDQUFDLElBQUlqQyxVQUFVLENBQUNnQyxDQUFDLENBQUMsQ0FBQ0UsYUFBYSxDQUFDbEMsVUFBVSxDQUFDaUMsQ0FBQyxDQUFDLENBQUM7QUFDeEUsQ0FBQyxDQUFDOztBQUVKO0FBQ0E7QUFDQTtBQUFBckQsT0FBQSxDQUFBeUQsV0FBQSxHQUFBQSxXQUFBO0FBQ0EsTUFBTUcsU0FBUyxHQUFHLElBQUlDLEdBQUcsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDOztBQUU1QztBQUNPLE1BQU1DLFdBQVcsR0FBSUMsUUFBZ0IsSUFBY0gsU0FBUyxDQUFDWixHQUFHLENBQUNlLFFBQVEsQ0FBQzs7QUFFakY7QUFDQTtBQUNBO0FBQUEvRCxPQUFBLENBQUE4RCxXQUFBLEdBQUFBLFdBQUE7QUFTQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sTUFBTUUsYUFBYSxHQUFHQSxDQUMzQkMsR0FBa0IsRUFDbEJDLE9BQXVCLEtBQzZCO0VBQ3BELE1BQU1DLElBQVcsR0FBRztJQUFFN0MsS0FBSyxFQUFFLFFBQVE7SUFBRThDLElBQUksRUFBRTtFQUFLLENBQUM7RUFDbkQsSUFBSSxDQUFDSCxHQUFHLEVBQUUsT0FBTztJQUFFSSxLQUFLLEVBQUUsSUFBSTtJQUFFQyxNQUFNLEVBQUUsQ0FBQ0gsSUFBSTtFQUFFLENBQUM7RUFDaEQsTUFBTUUsS0FBSyxHQUFHSCxPQUFPLENBQUNLLElBQUksQ0FBRUMsQ0FBQyxJQUFLUCxHQUFHLEtBQUtPLENBQUMsQ0FBQ0osSUFBSSxJQUFJSCxHQUFHLENBQUNsQyxVQUFVLENBQUN5QyxDQUFDLENBQUNKLElBQUksR0FBRyxHQUFHLENBQUMsQ0FBQyxJQUFJLElBQUk7RUFDekYsSUFBSSxDQUFDQyxLQUFLLEVBQUUsT0FBTztJQUFFQSxLQUFLLEVBQUUsSUFBSTtJQUFFQyxNQUFNLEVBQUUsQ0FBQ0gsSUFBSTtFQUFFLENBQUM7RUFFbEQsTUFBTUcsTUFBZSxHQUFHLENBQUNILElBQUksRUFBRTtJQUFFN0MsS0FBSyxFQUFFRixVQUFVLENBQUNpRCxLQUFLLENBQUM7SUFBRUQsSUFBSSxFQUFFQyxLQUFLLENBQUNEO0VBQUssQ0FBQyxDQUFDO0VBQzlFLE1BQU1LLEdBQUcsR0FBRzdELFVBQVUsQ0FBQ3lELEtBQUssQ0FBQ0QsSUFBSSxFQUFFSCxHQUFHLENBQUMsQ0FBQyxDQUFDO0VBQ3pDLE1BQU1TLElBQUksR0FBR0QsR0FBRyxDQUFDdEUsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDQyxNQUFNLENBQUNDLE9BQU8sQ0FBQztFQUMzQyxJQUFJc0UsR0FBRyxHQUFHTixLQUFLLENBQUNELElBQUk7RUFDcEIsS0FBSyxNQUFNUSxHQUFHLElBQUlGLElBQUksRUFBRTtJQUN0QkMsR0FBRyxHQUFHL0UsUUFBUSxDQUFDK0UsR0FBRyxFQUFFQyxHQUFHLENBQUM7SUFDeEJOLE1BQU0sQ0FBQ08sSUFBSSxDQUFDO01BQUV2RCxLQUFLLEVBQUVzRCxHQUFHO01BQUVSLElBQUksRUFBRU87SUFBSSxDQUFDLENBQUM7RUFDeEM7RUFDQSxPQUFPO0lBQUVOLEtBQUs7SUFBRUM7RUFBTyxDQUFDO0FBQzFCLENBQUM7O0FBRUQ7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFEQXRFLE9BQUEsQ0FBQWdFLGFBQUEsR0FBQUEsYUFBQTtBQUVPLE1BQU1jLFNBQVMsR0FBQTlFLE9BQUEsQ0FBQThFLFNBQUEsR0FBRyw0QkFBNEI7QUFZckQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sTUFBTUMsYUFBYSxHQUFHQSxDQUMzQkMsSUFBWSxFQUNaQyxTQUFpQixFQUNqQkMsUUFBZ0IsRUFDaEJDLFVBQWtCLEtBQ2tDO0VBQ3BELElBQUlELFFBQVEsS0FBS0MsVUFBVSxFQUFFLE9BQU8sYUFBYTtFQUNqRCxJQUFJNUUsS0FBSyxDQUFDeUUsSUFBSSxDQUFDLEtBQUtDLFNBQVMsQ0FBQ2xGLE9BQU8sQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUUsT0FBTyxVQUFVO0VBQ3BFLE1BQU1xRixDQUFDLEdBQUdKLElBQUksQ0FBQ2pGLE9BQU8sQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDO0VBQ2xDLE1BQU1zRixDQUFDLEdBQUdKLFNBQVMsQ0FBQ2xGLE9BQU8sQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDO0VBQ3ZDLElBQUlzRixDQUFDLEtBQUtELENBQUMsSUFBSUMsQ0FBQyxDQUFDdEQsVUFBVSxDQUFDcUQsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxFQUFFLE9BQU8sV0FBVztFQUN4RCxPQUFPLElBQUk7QUFDYixDQUFDOztBQUVEO0FBQ0E7QUFEQXBGLE9BQUEsQ0FBQStFLGFBQUEsR0FBQUEsYUFBQTtBQUVPLE1BQU1PLGdCQUFnQixHQUFHQSxDQUM5QnBELE1BQTJELEVBQzNEcUQsTUFBYyxFQUNkQyxXQUFtQixLQUNEO0VBQ2xCLE1BQU1DLE1BQU0sR0FBR1YsYUFBYSxDQUFDN0MsTUFBTSxDQUFDcEIsT0FBTyxFQUFFeUUsTUFBTSxFQUFFckQsTUFBTSxDQUFDckIsUUFBUSxFQUFFMkUsV0FBVyxDQUFDO0VBQ2xGLElBQUlDLE1BQU0sS0FBSyxhQUFhLEVBQUUsT0FBT0MsU0FBUyxDQUFDLGFBQWEsQ0FBQztFQUM3RCxJQUFJRCxNQUFNLEtBQUssVUFBVSxFQUFFLE9BQU8sR0FBR3ZELE1BQU0sQ0FBQ3BDLElBQUksNkJBQTZCO0VBQzdFLElBQUkyRixNQUFNLEtBQUssV0FBVyxFQUFFLE9BQU8sa0NBQWtDO0VBQ3JFLE9BQU8sSUFBSTtBQUNiLENBQUM7O0FBRUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBWEF6RixPQUFBLENBQUFzRixnQkFBQSxHQUFBQSxnQkFBQTtBQVlPLE1BQU1LLGVBQWUsR0FBR0EsQ0FDN0JDLEdBQTRDLEVBQzVDQyxTQUFpQixLQUNMRCxHQUFHLEdBQUlBLEdBQUcsQ0FBQ0UsS0FBSyxHQUFHRixHQUFHLENBQUN4QixJQUFJLEdBQUc3RCxLQUFLLENBQUNxRixHQUFHLENBQUN4QixJQUFJLENBQUMsR0FBSXlCLFNBQVU7O0FBRXpFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTkE3RixPQUFBLENBQUEyRixlQUFBLEdBQUFBLGVBQUE7QUFPTyxNQUFNSSxrQkFBa0IsR0FBR0EsQ0FBQ0MsQ0FBaUMsRUFBRUMsV0FBbUIsS0FBYTtFQUNwRyxNQUFNQyxFQUFFLEdBQUlGLENBQUMsQ0FBQzlELE1BQU0sRUFBeUJpRSxPQUFPLEdBQUcsYUFBYSxDQUFDLElBQUksSUFBSTtFQUM3RSxNQUFNUCxHQUFHLEdBQUdNLEVBQUUsR0FDVjtJQUFFOUIsSUFBSSxFQUFFOEIsRUFBRSxDQUFDRSxZQUFZLENBQUMsV0FBVyxDQUFDLElBQUlILFdBQVc7SUFBRUgsS0FBSyxFQUFFSSxFQUFFLENBQUNFLFlBQVksQ0FBQyxVQUFVLENBQUMsS0FBSztFQUFJLENBQUMsR0FDakcsSUFBSTtFQUNSLE9BQU9ULGVBQWUsQ0FBQ0MsR0FBRyxFQUFFSyxXQUFXLENBQUM7QUFDMUMsQ0FBQzs7QUFFRDtBQUNBO0FBQ0E7QUFDQTtBQUhBakcsT0FBQSxDQUFBK0Ysa0JBQUEsR0FBQUEsa0JBQUE7QUFJTyxNQUFNTSxxQkFBcUIsR0FBQXJHLE9BQUEsQ0FBQXFHLHFCQUFBLEdBQUcsSUFBSSxHQUFHLElBQUk7O0FBRWhEO0FBQ08sTUFBTVgsU0FBaUMsR0FBQTFGLE9BQUEsQ0FBQTBGLFNBQUEsR0FBRztFQUMvQ1ksTUFBTSxFQUFFLDBDQUEwQztFQUNsREMsU0FBUyxFQUFFLDZCQUE2QjtFQUN4QyxXQUFXLEVBQUUsbUNBQW1DO0VBQUU7RUFDbEQsV0FBVyxFQUFFLDZCQUE2QjtFQUMxQ0MsU0FBUyxFQUFFLGlEQUFpRDtFQUM1RCxnQkFBZ0IsRUFBRSx3QkFBd0I7RUFDMUMsYUFBYSxFQUFFO0FBQ2pCLENBQUMiLCJpZ25vcmVMaXN0IjpbXX0=