"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.TreeStore = void 0;
exports.useActive = useActive;
exports.useActiveAncestor = useActiveAncestor;
exports.useDir = useDir;
exports.useFocused = useFocused;
exports.useInSelection = useInSelection;
exports.useNode = useNode;
exports.usePending = usePending;
exports.useRowFocused = useRowFocused;
exports.useSelected = useSelected;
exports.useSelectedRow = useSelectedRow;
exports.useTreeUnfocused = useTreeUnfocused;
exports.useViewed = useViewed;
exports.useViewedAncestor = useViewedAncestor;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.find.js");
require("core-js/modules/esnext.iterator.some.js");
var _react = require("react");
var _entryMeta = require("./entryMeta");
// Path-keyed tree state, lifted OUT of the recursive TreeNode (migrate-sidebars
// Phase 03 + the file-explorer-rendering-fixes plan, FX-1/FX-2/FX-4a).
//
// Why this exists: expansion used to live in each node's `useState`, so it was
// bound to the component INSTANCE — any remount (e.g. a worktree mount
// re-announce after `editor:open`) dropped it, collapsing the clicked file's
// parent directory (FX-2), and selecting a file repainted/remounted the whole
// tree (FX-1, visible flicker). Holding expansion / the lazily-read child cache /
// the selected path here — keyed by ABSOLUTE PATH — makes that state durable
// across re-renders and remounts and independent of component identity.
//
// R3-79 (FILE_EXPLORER_SPEC §2): the store is now MULTI-ROOT — one root per
// mounted filesystem (worktree + spaces + granted subtrees). A single store with
// a `roots` set (rather than one store per mount) keeps selection/active global
// and the per-scope invariants intact (expansion is per-absolute-path, so two
// scopes never collide), with less machinery. Adding/removing a mount reconciles
// the root set; a removed mount's subtree state is purged.
//
// Each node subscribes to ONLY its own slice via `useSyncExternalStore`, so a
// toggle or a selection re-renders just the affected rows, never the tree.

class TreeStore {
  expanded = new Set();
  entries = new Map();
  errored = new Set();
  inflight = new Set();
  selected = null;
  // Whether the selected row is a directory, recorded at select time so the
  // upload button can resolve its destination (a selected dir IS the
  // destination; a selected file's parent is) without a listing read.
  selectedIsDir = false;
  // Stable snapshot of `{ selected, selectedIsDir }` — `getSelectedRow` is a
  // `useSyncExternalStore` getter, so it must return the same identity between
  // real mutations (mirrors `selectionSnapshot`).
  selectedRowSnapshot = null;
  // Optimistically inserted rows whose write has not settled yet (absolute
  // paths). A pending row renders in a pending treatment; the write's own
  // return settles it (R-IX-3/R-IX-4) — never a blanket refetch.
  pending = new Set();
  // The last-focused row (absolute path), shared by every layout — the roving
  // tab stop. Null until a row takes focus; each tree then keeps its tab stop
  // on its root row.
  focused = null;
  // A multi-select SET (absolute paths), DISTINCT from `selected` (the single
  // cursor / active-open path). Used by a batch consumer (file-commander) under
  // `selectionMode === "multi"`: a row click toggles membership here rather than
  // moving the single cursor. Held here — keyed by absolute path — so it survives
  // remounts and each row subscribes to only its own membership via
  // `useInSelection`. A stable snapshot (`selectionSnapshot`) is cached so
  // `getSelection` returns the same array identity until the set actually changes,
  // avoiding `useSyncExternalStore` tearing.
  selection = new Set();
  selectionSnapshot = [];
  // The editor's active file (mount-relative, e.g. `/src/App.tsx`), mirrored from
  // the host `editor-context` channel. Held here — NOT threaded as a prop through
  // the memoized tree — so a change re-renders ONLY the two rows whose active state
  // flips (via `useSyncExternalStore`), never the whole tree (FX-1 / FX-4b).
  activeFile = null;
  // The stage's viewed-document hint (mount-relative), mirrored from the host
  // `editor-context.viewedFile` (R3-268). Same store-not-prop shape as
  // `activeFile` (FX-4b): a change re-renders only the affected rows.
  // Highlight-only by contract — the store never scrolls or selects on it.
  viewedFile = null;
  roots = new Set();
  listeners = new Set();

  // The injected filesystem source the store reads directory entries through. The
  // view constructs the store with a concrete `FsSource` (the SDK adapter's ZenFS
  // `sdkFsSource`, file-commander's in-memory fs, or a test fake), so the store
  // never imports a concrete fs (Phase 02 §A.2). An explicit field assignment
  // (not a parameter property) keeps `erasableSyntaxOnly` happy.

  constructor(fs) {
    this.fs = fs;
  }

  /** Stable subscribe fn for `useSyncExternalStore` (identity must not change). */
  subscribe = listener => {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  };
  emit() {
    for (const l of this.listeners) l();
  }

  /**
   * Reconcile the set of mounted roots (R3-79). Each root starts open. Idempotent
   * and side-effect-free when the set is unchanged, so it is safe to call during
   * render; it does NOT emit (new scopes read the seeded state on first render; a
   * removed scope simply stops rendering). Purges the subtree state of any root no
   * longer present so it can't leak.
   */
  ensureRoots(rootPaths) {
    const next = new Set(rootPaths);
    if (next.size === this.roots.size && [...next].every(p => this.roots.has(p))) return;

    // Purge state under roots that went away.
    for (const gone of this.roots) {
      if (next.has(gone)) continue;
      this.purgeUnder(gone);
    }
    // Open each (still-/newly-) present root by default.
    for (const p of next) this.expanded.add(p);
    this.roots = next;
  }

  /** Drop expansion / entry / error / selection state at `root` and everything
   *  under it (a `root/`-prefixed path). */
  purgeUnder(root) {
    const under = p => p === root || p.startsWith(root + "/") || p.startsWith(root.replace(/\/+$/, "") + "/");
    for (const p of [...this.expanded]) if (under(p)) this.expanded.delete(p);
    for (const p of [...this.entries.keys()]) if (under(p)) this.entries.delete(p);
    for (const p of [...this.errored]) if (under(p)) this.errored.delete(p);
    for (const p of [...this.pending]) if (under(p)) this.pending.delete(p);
    if (this.selected && under(this.selected)) {
      this.selected = null;
      this.selectedIsDir = false;
      this.selectedRowSnapshot = null;
    }
    if (this.focused && under(this.focused)) this.focused = null;
    let dropped = false;
    for (const p of [...this.selection]) {
      if (under(p)) {
        this.selection.delete(p);
        dropped = true;
      }
    }
    if (dropped) this.refreshSelectionSnapshot();
  }

  // --- per-path selectors (stable primitive / array snapshots) ---
  isExpanded = p => this.expanded.has(p);
  isSelected = p => this.selected === p;
  isErrored = p => this.errored.has(p);
  getEntries = p => this.entries.get(p);
  /** The selected absolute path (shared across every layout). */
  getSelected = () => this.selected;
  /** The selected row — path + whether it is a directory — for consumers that
   *  need the selection's SHAPE, not just its path (the upload button's
   *  destination). Stable identity between mutations. */
  getSelectedRow = () => this.selectedRowSnapshot;
  /** Is `p` (absolute) in the multi-select set? Drives the `lrow--selected`
   *  highlight under `selectionMode === "multi"`. */
  isInSelection = p => this.selection.has(p);
  /** The multi-select set as a stable-identity array (absolute paths). The
   *  returned array is cached and only re-created when the set changes, so
   *  `useSyncExternalStore` sees a stable snapshot between real mutations. */
  getSelection = () => this.selectionSnapshot;
  /** Is `repoRel` (mount-relative) the editor's active file? Drives the FX-4b row
   *  highlight without a per-node prop (compared mount-relative, matching the
   *  host's `editor-context.activeFile`). */
  isActive = repoRel => this.activeFile === repoRel;
  /** The editor's active file, mount-relative (shared across every layout). */
  getActiveFile = () => this.activeFile;
  /** Is `repoRel` the file the STAGE claims to be rendering (R3-268)? Drives the
   *  "on stage" marker, visually distinct from the editor-active highlight. */
  isViewed = repoRel => this.viewedFile === repoRel;
  /** The stage's viewed-document hint, mount-relative (or null — no hint). */
  getViewedFile = () => this.viewedFile;
  /** Is the row at absolute `p` a write in flight (optimistically inserted)? */
  isPending = p => this.pending.has(p);
  /** The last-focused row's absolute path (the roving tab stop), or null. */
  getFocused = () => this.focused;
  /** Does any focused row sit inside the tree rooted at `rootPath`? */
  isFocusInTree = rootPath => this.focused !== null && (this.focused === rootPath || this.focused.startsWith(rootPath + "/"));
  /** Is `repoRel` (a DIRECTORY, mount-relative) an ancestor of the viewed
   *  document? Drives the collapsed-folder "contains the on-stage file" dot —
   *  a corpus under a chroot subdir stays discoverable while the tree itself is
   *  untouched (the highlight-only contract). */
  isViewedAncestor = repoRel => {
    if (!this.viewedFile) return false;
    if (repoRel === "/") return true;
    return this.viewedFile.startsWith(repoRel + "/");
  };
  /** Is `repoRel` (a DIRECTORY, mount-relative) an ancestor of the editor's
   *  active file? The counterpart of {@link isViewedAncestor} for the FX-4b
   *  signal: once the user collapses the folder holding the edited file, the
   *  marker must not simply vanish. */
  isActiveAncestor = repoRel => {
    if (!this.activeFile) return false;
    if (repoRel === "/") return true;
    return this.activeFile.startsWith(repoRel + "/");
  };

  // --- mutations (called from handlers / effects, never during render) ---
  toggle = p => {
    if (this.expanded.has(p)) {
      this.expanded.delete(p);
      // The rows underneath are about to unmount — a focus pointing at one of
      // them would leave its tree with no tab stop. Hand it to the folder.
      if (this.focused !== null && this.focused !== p && this.focused.startsWith(p + "/")) {
        this.focused = p;
      }
    } else {
      this.expanded.add(p);
    }
    this.emit();
  };

  /** Expand every ancestor of the mount-relative `path` under EVERY root. Used
   *  by the gesture-gated stage reveal (the host's one-shot `viewed-reveal`) and
   *  by the editor-active reveal. A path that
   *  doesn't exist under a root never renders, so over-expansion is inert.
   *  Rendering only — never focuses; the caller owns the (optional) scroll. */
  revealPath = path => {
    const segs = path.split("/").filter(Boolean);
    segs.pop(); // the file itself — expansion applies to its ancestor dirs
    let changed = false;
    for (const root of this.roots) {
      let p = root;
      for (const seg of segs) {
        p = `${p}/${seg}`;
        if (!this.expanded.has(p)) {
          this.expanded.add(p);
          changed = true;
        }
      }
    }
    if (changed) this.emit();
  };

  /** Force a directory open (used when revealing a drop target / a created path). */
  open = p => {
    if (this.expanded.has(p)) return;
    this.expanded.add(p);
    this.emit();
  };

  /** Record the selected row (absolute path). Drives the FX-4a row highlight.
   *  Files AND directories are selectable — a selected directory is the upload
   *  button's destination (FILE_EXPLORER_SPEC §5), so its kind travels along. */
  select = (p, isDir = false) => {
    if (this.selected === p && this.selectedIsDir === isDir) return;
    this.selected = p;
    this.selectedIsDir = isDir;
    this.selectedRowSnapshot = {
      path: p,
      isDir
    };
    this.emit();
  };

  /** Record the focused row (absolute path) — moves the roving tab stop. */
  setFocus = p => {
    if (this.focused === p) return;
    this.focused = p;
    this.emit();
  };

  // --- optimistic write mutations (called by the write flow, never render) ---
  // Every mutation replaces the directory's array (never mutates it in place)
  // so `getEntries` snapshots change identity and `useSyncExternalStore` sees
  // the update.

  /** Insert `entry` into `dir`'s cached listing at its final (sorted)
   *  position. A directory whose listing is not loaded yet (collapsed,
   *  never read) is left alone — nothing renders there until it loads, and
   *  the post-settle `refreshDir` is the authority. */
  sortedInsert = (dir, entry, asPending) => {
    const list = this.entries.get(dir);
    if (!list) return;
    const next = [...list];
    let i = next.findIndex(e => (0, _entryMeta.compareEntries)(entry, e, "name") < 0);
    if (i < 0) i = next.length;
    next.splice(i, 0, entry);
    this.entries.set(dir, next);
    if (asPending) this.pending.add(`${dir}/${entry.name}`);
    this.emit();
  };

  /** Insert an entry that is NOT yet real — the row the user just asked for,
   *  rendered immediately at its final position in a pending treatment
   *  (R-IX-3). The write's own return settles it via {@link settleEntry}. */
  insertPending = (dir, entry) => {
    this.sortedInsert(dir, entry, true);
  };

  /** Insert (or restore, after a failed write) a real entry. */
  insertEntry = (dir, entry) => {
    this.sortedInsert(dir, entry, false);
  };

  /** Replace the pending row `pendingName` in `dir` with the authoritative
   *  `entry` the write returned — the settle, with no read at all (R-IX-4). */
  settleEntry = (dir, pendingName, entry) => {
    const list = this.entries.get(dir);
    this.pending.delete(`${dir}/${pendingName}`);
    if (!list) return;
    const i = list.findIndex(e => e.name === pendingName);
    if (i < 0) return;
    const next = [...list];
    next[i] = entry;
    // The authority may have normalized the name; keep the listing sorted.
    next.sort((a, b) => (0, _entryMeta.compareEntries)(a, b, "name"));
    this.entries.set(dir, next);
    this.emit();
  };

  /** Drop `name` from `dir`'s cached listing (an optimistic remove, or the
   *  cleanup of a pending row). No-op when the listing is not loaded. */
  removeEntry = (dir, name) => {
    const gone = `${dir}/${name}`;
    const list = this.entries.get(dir);
    this.pending.delete(gone);
    if (this.focused === gone) this.focused = null;
    if (!list) return;
    const i = list.findIndex(e => e.name === name);
    if (i < 0) return;
    const next = [...list];
    next.splice(i, 1);
    this.entries.set(dir, next);
    this.emit();
  };

  /** Recompute the cached selection snapshot after a set mutation. */
  refreshSelectionSnapshot() {
    this.selectionSnapshot = [...this.selection];
  }

  /** Toggle `p` (absolute) in the multi-select set and emit. */
  toggleInSelection = p => {
    if (this.selection.has(p)) this.selection.delete(p);else this.selection.add(p);
    this.refreshSelectionSnapshot();
    this.emit();
  };

  /** Clear the multi-select set (emits only if it held anything). */
  clearSelection = () => {
    if (this.selection.size === 0) return;
    this.selection.clear();
    this.refreshSelectionSnapshot();
    this.emit();
  };

  /** Mirror the editor's active file (mount-relative). Emits only on a real change,
   *  so the editor-context push re-renders just the two affected rows (FX-4b). */
  setActiveFile = next => {
    if (this.activeFile === next) return;
    this.activeFile = next;
    this.emit();
  };

  /** Mirror the stage's viewed-document hint (mount-relative; R3-268). Emits only
   *  on a real change so a navigation re-renders just the affected rows. */
  setViewedFile = next => {
    if (this.viewedFile === next) return;
    this.viewedFile = next;
    this.emit();
  };

  /** Collapse every directory but keep the mounted roots open ("collapse all"). */
  collapseAll = () => {
    this.expanded = new Set(this.roots);
    this.emit();
  };

  /** Lazily read a directory's children once. Dedupes concurrent/repeat reads. */
  ensureLoaded = p => {
    if (this.entries.has(p) || this.errored.has(p) || this.inflight.has(p)) return;
    this.inflight.add(p);
    void this.fs.readdir(p).then(list => {
      this.inflight.delete(p);
      this.entries.set(p, list);
      this.errored.delete(p);
      this.emit();
    }, () => {
      this.inflight.delete(p);
      this.errored.add(p);
      this.emit();
    });
  };

  /**
   * Re-read every currently-open directory in place — the EXPLICIT reload
   * (layout switches, a consumer's "refresh" affordance). The post-write path
   * does NOT use this; it settles from the write's return and then calls the
   * narrow {@link refreshDir}. Stale content stays visible until fresh entries
   * land — no spinner flash — and expansion/selection are untouched.
   */
  refresh = () => {
    for (const p of [...this.expanded]) {
      void this.fs.readdir(p).then(list => {
        this.entries.set(p, list);
        this.errored.delete(p);
        this.emit();
      }, () => {
        this.errored.add(p);
        this.emit();
      });
    }
  };

  /**
   * Re-read ONE directory in place — the narrow post-write authority refetch
   * (R-IX-4: refetch what changed, not everything that happens to be open).
   * Settles the write's directory against the authority, EXCEPT rows whose
   * write is still in flight: a fresh listing cannot know about them, and
   * wiping them would un-render a change the user just made (R-IX-3) and
   * orphan its settle. Their settle is the write's own return.
   */
  refreshDir = p => {
    void this.fs.readdir(p).then(list => {
      // A fresh listing cannot know about rows whose write is still in
      // flight — re-insert them (their cached selves, pending treatment
      // intact) so the refetch never un-renders a change in progress.
      const cached = this.entries.get(p);
      let next = list;
      for (const pendingPath of this.pending) {
        if (!pendingPath.startsWith(p + "/")) continue;
        const name = pendingPath.slice(p.length + 1);
        if (next.some(e => e.name === name)) continue;
        const pendingEntry = cached?.find(e => e.name === name);
        if (!pendingEntry) continue;
        if (next === list) next = [...list];
        let i = next.findIndex(e => (0, _entryMeta.compareEntries)(pendingEntry, e, "name") < 0);
        if (i < 0) i = next.length;
        next.splice(i, 0, pendingEntry);
      }
      this.entries.set(p, next);
      this.errored.delete(p);
      this.emit();
    }, () => {
      this.errored.add(p);
      this.emit();
    });
  };
}

/** Subscribe a node to exactly its own slice of the store. */
exports.TreeStore = TreeStore;
function useNode(store, path) {
  const expanded = (0, _react.useSyncExternalStore)(store.subscribe, () => store.isExpanded(path));
  const selected = (0, _react.useSyncExternalStore)(store.subscribe, () => store.isSelected(path));
  const errored = (0, _react.useSyncExternalStore)(store.subscribe, () => store.isErrored(path));
  const entries = (0, _react.useSyncExternalStore)(store.subscribe, () => store.getEntries(path));
  return {
    expanded,
    selected,
    errored,
    entries
  };
}

/** Subscribe to the shared selected path (drives the highlight in every layout). */
function useSelected(store) {
  return (0, _react.useSyncExternalStore)(store.subscribe, store.getSelected);
}

/** Subscribe to the selected ROW (path + isDir) — the shape the upload button's
 *  destination needs. Same slice as {@link useSelected}, stable identity. */
function useSelectedRow(store) {
  return (0, _react.useSyncExternalStore)(store.subscribe, store.getSelectedRow);
}

/** Subscribe a row to ONLY whether it is in the multi-select set. Mirrors
 *  `useSelected`/`useActive`: keyed by the row's absolute path so toggling one
 *  row re-renders just that row, not the whole list. */
function useInSelection(store, path) {
  return (0, _react.useSyncExternalStore)(store.subscribe, () => store.isInSelection(path));
}

/** Subscribe a node to ONLY whether it is the editor's active file (FX-4b). Keyed
 *  by the node's mount-relative path so a change re-renders just the two rows whose
 *  active state flips — not the whole memoized tree. */
function useActive(store, repoRel) {
  return (0, _react.useSyncExternalStore)(store.subscribe, () => store.isActive(repoRel));
}

/** Subscribe a node to ONLY whether it is the stage's viewed document (R3-268).
 *  Mirrors {@link useActive}: keyed per row so a navigation re-renders just the
 *  two rows whose viewed state flips. */
function useViewed(store, repoRel) {
  return (0, _react.useSyncExternalStore)(store.subscribe, () => store.isViewed(repoRel));
}

/** Subscribe a DIRECTORY row to whether its subtree contains the viewed document
 *  (the collapsed-ancestor dot). Same per-row shape as {@link useViewed}. */
function useViewedAncestor(store, repoRel) {
  return (0, _react.useSyncExternalStore)(store.subscribe, () => store.isViewedAncestor(repoRel));
}

/** Subscribe a DIRECTORY row to whether its subtree contains the editor's active
 *  file (the collapsed-ancestor dot). Same per-row shape as {@link useActive}. */
function useActiveAncestor(store, repoRel) {
  return (0, _react.useSyncExternalStore)(store.subscribe, () => store.isActiveAncestor(repoRel));
}

/** Subscribe a row to whether its write is still in flight (the pending
 *  treatment). Keyed by absolute path so a settle re-renders one row. */
function usePending(store, path) {
  return (0, _react.useSyncExternalStore)(store.subscribe, () => store.isPending(path));
}

/** Subscribe to the shared focused row (the roving tab stop). */
function useFocused(store) {
  return (0, _react.useSyncExternalStore)(store.subscribe, store.getFocused);
}

/** Subscribe a row to ONLY whether IT holds the roving tab stop — a boolean
 *  slice, so a focus move re-renders the two rows whose slice flipped, not
 *  every row (the string selector above re-renders all of its subscribers). */
function useRowFocused(store, path) {
  return (0, _react.useSyncExternalStore)(store.subscribe, () => store.getFocused() === path);
}

/** Subscribe a tree to whether its roving tab stop lives on the root row (no
 *  row of this tree holds focus — some other tree, or nothing, does). */
function useTreeUnfocused(store, rootPath) {
  return (0, _react.useSyncExternalStore)(store.subscribe, () => !store.isFocusInTree(rootPath));
}

/**
 * Read one directory's entries for the flat layouts (list / icons / columns) and
 * ensure they are lazily loaded — reusing the SAME path-keyed cache and dedupe as
 * the tree, so switching layout never re-reads what the tree already loaded.
 */
function useDir(store, path) {
  const entries = (0, _react.useSyncExternalStore)(store.subscribe, () => path ? store.getEntries(path) : undefined);
  const errored = (0, _react.useSyncExternalStore)(store.subscribe, () => path ? store.isErrored(path) : false);
  (0, _react.useEffect)(() => {
    if (path && entries === undefined && !errored) store.ensureLoaded(path);
  }, [store, path, entries, errored]);
  return {
    entries,
    errored
  };
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX2VudHJ5TWV0YSIsIlRyZWVTdG9yZSIsImV4cGFuZGVkIiwiU2V0IiwiZW50cmllcyIsIk1hcCIsImVycm9yZWQiLCJpbmZsaWdodCIsInNlbGVjdGVkIiwic2VsZWN0ZWRJc0RpciIsInNlbGVjdGVkUm93U25hcHNob3QiLCJwZW5kaW5nIiwiZm9jdXNlZCIsInNlbGVjdGlvbiIsInNlbGVjdGlvblNuYXBzaG90IiwiYWN0aXZlRmlsZSIsInZpZXdlZEZpbGUiLCJyb290cyIsImxpc3RlbmVycyIsImNvbnN0cnVjdG9yIiwiZnMiLCJzdWJzY3JpYmUiLCJsaXN0ZW5lciIsImFkZCIsImRlbGV0ZSIsImVtaXQiLCJsIiwiZW5zdXJlUm9vdHMiLCJyb290UGF0aHMiLCJuZXh0Iiwic2l6ZSIsImV2ZXJ5IiwicCIsImhhcyIsImdvbmUiLCJwdXJnZVVuZGVyIiwicm9vdCIsInVuZGVyIiwic3RhcnRzV2l0aCIsInJlcGxhY2UiLCJrZXlzIiwiZHJvcHBlZCIsInJlZnJlc2hTZWxlY3Rpb25TbmFwc2hvdCIsImlzRXhwYW5kZWQiLCJpc1NlbGVjdGVkIiwiaXNFcnJvcmVkIiwiZ2V0RW50cmllcyIsImdldCIsImdldFNlbGVjdGVkIiwiZ2V0U2VsZWN0ZWRSb3ciLCJpc0luU2VsZWN0aW9uIiwiZ2V0U2VsZWN0aW9uIiwiaXNBY3RpdmUiLCJyZXBvUmVsIiwiZ2V0QWN0aXZlRmlsZSIsImlzVmlld2VkIiwiZ2V0Vmlld2VkRmlsZSIsImlzUGVuZGluZyIsImdldEZvY3VzZWQiLCJpc0ZvY3VzSW5UcmVlIiwicm9vdFBhdGgiLCJpc1ZpZXdlZEFuY2VzdG9yIiwiaXNBY3RpdmVBbmNlc3RvciIsInRvZ2dsZSIsInJldmVhbFBhdGgiLCJwYXRoIiwic2VncyIsInNwbGl0IiwiZmlsdGVyIiwiQm9vbGVhbiIsInBvcCIsImNoYW5nZWQiLCJzZWciLCJvcGVuIiwic2VsZWN0IiwiaXNEaXIiLCJzZXRGb2N1cyIsInNvcnRlZEluc2VydCIsImRpciIsImVudHJ5IiwiYXNQZW5kaW5nIiwibGlzdCIsImkiLCJmaW5kSW5kZXgiLCJlIiwiY29tcGFyZUVudHJpZXMiLCJsZW5ndGgiLCJzcGxpY2UiLCJzZXQiLCJuYW1lIiwiaW5zZXJ0UGVuZGluZyIsImluc2VydEVudHJ5Iiwic2V0dGxlRW50cnkiLCJwZW5kaW5nTmFtZSIsInNvcnQiLCJhIiwiYiIsInJlbW92ZUVudHJ5IiwidG9nZ2xlSW5TZWxlY3Rpb24iLCJjbGVhclNlbGVjdGlvbiIsImNsZWFyIiwic2V0QWN0aXZlRmlsZSIsInNldFZpZXdlZEZpbGUiLCJjb2xsYXBzZUFsbCIsImVuc3VyZUxvYWRlZCIsInJlYWRkaXIiLCJ0aGVuIiwicmVmcmVzaCIsInJlZnJlc2hEaXIiLCJjYWNoZWQiLCJwZW5kaW5nUGF0aCIsInNsaWNlIiwic29tZSIsInBlbmRpbmdFbnRyeSIsImZpbmQiLCJleHBvcnRzIiwidXNlTm9kZSIsInN0b3JlIiwidXNlU3luY0V4dGVybmFsU3RvcmUiLCJ1c2VTZWxlY3RlZCIsInVzZVNlbGVjdGVkUm93IiwidXNlSW5TZWxlY3Rpb24iLCJ1c2VBY3RpdmUiLCJ1c2VWaWV3ZWQiLCJ1c2VWaWV3ZWRBbmNlc3RvciIsInVzZUFjdGl2ZUFuY2VzdG9yIiwidXNlUGVuZGluZyIsInVzZUZvY3VzZWQiLCJ1c2VSb3dGb2N1c2VkIiwidXNlVHJlZVVuZm9jdXNlZCIsInVzZURpciIsInVuZGVmaW5lZCIsInVzZUVmZmVjdCJdLCJzb3VyY2VzIjpbInRyZWVTdG9yZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBQYXRoLWtleWVkIHRyZWUgc3RhdGUsIGxpZnRlZCBPVVQgb2YgdGhlIHJlY3Vyc2l2ZSBUcmVlTm9kZSAobWlncmF0ZS1zaWRlYmFyc1xuLy8gUGhhc2UgMDMgKyB0aGUgZmlsZS1leHBsb3Jlci1yZW5kZXJpbmctZml4ZXMgcGxhbiwgRlgtMS9GWC0yL0ZYLTRhKS5cbi8vXG4vLyBXaHkgdGhpcyBleGlzdHM6IGV4cGFuc2lvbiB1c2VkIHRvIGxpdmUgaW4gZWFjaCBub2RlJ3MgYHVzZVN0YXRlYCwgc28gaXQgd2FzXG4vLyBib3VuZCB0byB0aGUgY29tcG9uZW50IElOU1RBTkNFIOKAlCBhbnkgcmVtb3VudCAoZS5nLiBhIHdvcmt0cmVlIG1vdW50XG4vLyByZS1hbm5vdW5jZSBhZnRlciBgZWRpdG9yOm9wZW5gKSBkcm9wcGVkIGl0LCBjb2xsYXBzaW5nIHRoZSBjbGlja2VkIGZpbGUnc1xuLy8gcGFyZW50IGRpcmVjdG9yeSAoRlgtMiksIGFuZCBzZWxlY3RpbmcgYSBmaWxlIHJlcGFpbnRlZC9yZW1vdW50ZWQgdGhlIHdob2xlXG4vLyB0cmVlIChGWC0xLCB2aXNpYmxlIGZsaWNrZXIpLiBIb2xkaW5nIGV4cGFuc2lvbiAvIHRoZSBsYXppbHktcmVhZCBjaGlsZCBjYWNoZSAvXG4vLyB0aGUgc2VsZWN0ZWQgcGF0aCBoZXJlIOKAlCBrZXllZCBieSBBQlNPTFVURSBQQVRIIOKAlCBtYWtlcyB0aGF0IHN0YXRlIGR1cmFibGVcbi8vIGFjcm9zcyByZS1yZW5kZXJzIGFuZCByZW1vdW50cyBhbmQgaW5kZXBlbmRlbnQgb2YgY29tcG9uZW50IGlkZW50aXR5LlxuLy9cbi8vIFIzLTc5IChGSUxFX0VYUExPUkVSX1NQRUMgwqcyKTogdGhlIHN0b3JlIGlzIG5vdyBNVUxUSS1ST09UIOKAlCBvbmUgcm9vdCBwZXJcbi8vIG1vdW50ZWQgZmlsZXN5c3RlbSAod29ya3RyZWUgKyBzcGFjZXMgKyBncmFudGVkIHN1YnRyZWVzKS4gQSBzaW5nbGUgc3RvcmUgd2l0aFxuLy8gYSBgcm9vdHNgIHNldCAocmF0aGVyIHRoYW4gb25lIHN0b3JlIHBlciBtb3VudCkga2VlcHMgc2VsZWN0aW9uL2FjdGl2ZSBnbG9iYWxcbi8vIGFuZCB0aGUgcGVyLXNjb3BlIGludmFyaWFudHMgaW50YWN0IChleHBhbnNpb24gaXMgcGVyLWFic29sdXRlLXBhdGgsIHNvIHR3b1xuLy8gc2NvcGVzIG5ldmVyIGNvbGxpZGUpLCB3aXRoIGxlc3MgbWFjaGluZXJ5LiBBZGRpbmcvcmVtb3ZpbmcgYSBtb3VudCByZWNvbmNpbGVzXG4vLyB0aGUgcm9vdCBzZXQ7IGEgcmVtb3ZlZCBtb3VudCdzIHN1YnRyZWUgc3RhdGUgaXMgcHVyZ2VkLlxuLy9cbi8vIEVhY2ggbm9kZSBzdWJzY3JpYmVzIHRvIE9OTFkgaXRzIG93biBzbGljZSB2aWEgYHVzZVN5bmNFeHRlcm5hbFN0b3JlYCwgc28gYVxuLy8gdG9nZ2xlIG9yIGEgc2VsZWN0aW9uIHJlLXJlbmRlcnMganVzdCB0aGUgYWZmZWN0ZWQgcm93cywgbmV2ZXIgdGhlIHRyZWUuXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN5bmNFeHRlcm5hbFN0b3JlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBjb21wYXJlRW50cmllcyB9IGZyb20gXCIuL2VudHJ5TWV0YVwiO1xuaW1wb3J0IHR5cGUgeyBEaXJFbnRyeSwgRnNTb3VyY2UgfSBmcm9tIFwiLi90eXBlc1wiO1xuXG5leHBvcnQgY2xhc3MgVHJlZVN0b3JlIHtcbiAgcHJpdmF0ZSBleHBhbmRlZCA9IG5ldyBTZXQ8c3RyaW5nPigpO1xuICBwcml2YXRlIGVudHJpZXMgPSBuZXcgTWFwPHN0cmluZywgRGlyRW50cnlbXT4oKTtcbiAgcHJpdmF0ZSBlcnJvcmVkID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gIHByaXZhdGUgaW5mbGlnaHQgPSBuZXcgU2V0PHN0cmluZz4oKTtcbiAgcHJpdmF0ZSBzZWxlY3RlZDogc3RyaW5nIHwgbnVsbCA9IG51bGw7XG4gIC8vIFdoZXRoZXIgdGhlIHNlbGVjdGVkIHJvdyBpcyBhIGRpcmVjdG9yeSwgcmVjb3JkZWQgYXQgc2VsZWN0IHRpbWUgc28gdGhlXG4gIC8vIHVwbG9hZCBidXR0b24gY2FuIHJlc29sdmUgaXRzIGRlc3RpbmF0aW9uIChhIHNlbGVjdGVkIGRpciBJUyB0aGVcbiAgLy8gZGVzdGluYXRpb247IGEgc2VsZWN0ZWQgZmlsZSdzIHBhcmVudCBpcykgd2l0aG91dCBhIGxpc3RpbmcgcmVhZC5cbiAgcHJpdmF0ZSBzZWxlY3RlZElzRGlyID0gZmFsc2U7XG4gIC8vIFN0YWJsZSBzbmFwc2hvdCBvZiBgeyBzZWxlY3RlZCwgc2VsZWN0ZWRJc0RpciB9YCDigJQgYGdldFNlbGVjdGVkUm93YCBpcyBhXG4gIC8vIGB1c2VTeW5jRXh0ZXJuYWxTdG9yZWAgZ2V0dGVyLCBzbyBpdCBtdXN0IHJldHVybiB0aGUgc2FtZSBpZGVudGl0eSBiZXR3ZWVuXG4gIC8vIHJlYWwgbXV0YXRpb25zIChtaXJyb3JzIGBzZWxlY3Rpb25TbmFwc2hvdGApLlxuICBwcml2YXRlIHNlbGVjdGVkUm93U25hcHNob3Q6IHsgcGF0aDogc3RyaW5nOyBpc0RpcjogYm9vbGVhbiB9IHwgbnVsbCA9IG51bGw7XG4gIC8vIE9wdGltaXN0aWNhbGx5IGluc2VydGVkIHJvd3Mgd2hvc2Ugd3JpdGUgaGFzIG5vdCBzZXR0bGVkIHlldCAoYWJzb2x1dGVcbiAgLy8gcGF0aHMpLiBBIHBlbmRpbmcgcm93IHJlbmRlcnMgaW4gYSBwZW5kaW5nIHRyZWF0bWVudDsgdGhlIHdyaXRlJ3Mgb3duXG4gIC8vIHJldHVybiBzZXR0bGVzIGl0IChSLUlYLTMvUi1JWC00KSDigJQgbmV2ZXIgYSBibGFua2V0IHJlZmV0Y2guXG4gIHByaXZhdGUgcGVuZGluZyA9IG5ldyBTZXQ8c3RyaW5nPigpO1xuICAvLyBUaGUgbGFzdC1mb2N1c2VkIHJvdyAoYWJzb2x1dGUgcGF0aCksIHNoYXJlZCBieSBldmVyeSBsYXlvdXQg4oCUIHRoZSByb3ZpbmdcbiAgLy8gdGFiIHN0b3AuIE51bGwgdW50aWwgYSByb3cgdGFrZXMgZm9jdXM7IGVhY2ggdHJlZSB0aGVuIGtlZXBzIGl0cyB0YWIgc3RvcFxuICAvLyBvbiBpdHMgcm9vdCByb3cuXG4gIHByaXZhdGUgZm9jdXNlZDogc3RyaW5nIHwgbnVsbCA9IG51bGw7XG4gIC8vIEEgbXVsdGktc2VsZWN0IFNFVCAoYWJzb2x1dGUgcGF0aHMpLCBESVNUSU5DVCBmcm9tIGBzZWxlY3RlZGAgKHRoZSBzaW5nbGVcbiAgLy8gY3Vyc29yIC8gYWN0aXZlLW9wZW4gcGF0aCkuIFVzZWQgYnkgYSBiYXRjaCBjb25zdW1lciAoZmlsZS1jb21tYW5kZXIpIHVuZGVyXG4gIC8vIGBzZWxlY3Rpb25Nb2RlID09PSBcIm11bHRpXCJgOiBhIHJvdyBjbGljayB0b2dnbGVzIG1lbWJlcnNoaXAgaGVyZSByYXRoZXIgdGhhblxuICAvLyBtb3ZpbmcgdGhlIHNpbmdsZSBjdXJzb3IuIEhlbGQgaGVyZSDigJQga2V5ZWQgYnkgYWJzb2x1dGUgcGF0aCDigJQgc28gaXQgc3Vydml2ZXNcbiAgLy8gcmVtb3VudHMgYW5kIGVhY2ggcm93IHN1YnNjcmliZXMgdG8gb25seSBpdHMgb3duIG1lbWJlcnNoaXAgdmlhXG4gIC8vIGB1c2VJblNlbGVjdGlvbmAuIEEgc3RhYmxlIHNuYXBzaG90IChgc2VsZWN0aW9uU25hcHNob3RgKSBpcyBjYWNoZWQgc29cbiAgLy8gYGdldFNlbGVjdGlvbmAgcmV0dXJucyB0aGUgc2FtZSBhcnJheSBpZGVudGl0eSB1bnRpbCB0aGUgc2V0IGFjdHVhbGx5IGNoYW5nZXMsXG4gIC8vIGF2b2lkaW5nIGB1c2VTeW5jRXh0ZXJuYWxTdG9yZWAgdGVhcmluZy5cbiAgcHJpdmF0ZSBzZWxlY3Rpb24gPSBuZXcgU2V0PHN0cmluZz4oKTtcbiAgcHJpdmF0ZSBzZWxlY3Rpb25TbmFwc2hvdDogc3RyaW5nW10gPSBbXTtcbiAgLy8gVGhlIGVkaXRvcidzIGFjdGl2ZSBmaWxlIChtb3VudC1yZWxhdGl2ZSwgZS5nLiBgL3NyYy9BcHAudHN4YCksIG1pcnJvcmVkIGZyb21cbiAgLy8gdGhlIGhvc3QgYGVkaXRvci1jb250ZXh0YCBjaGFubmVsLiBIZWxkIGhlcmUg4oCUIE5PVCB0aHJlYWRlZCBhcyBhIHByb3AgdGhyb3VnaFxuICAvLyB0aGUgbWVtb2l6ZWQgdHJlZSDigJQgc28gYSBjaGFuZ2UgcmUtcmVuZGVycyBPTkxZIHRoZSB0d28gcm93cyB3aG9zZSBhY3RpdmUgc3RhdGVcbiAgLy8gZmxpcHMgKHZpYSBgdXNlU3luY0V4dGVybmFsU3RvcmVgKSwgbmV2ZXIgdGhlIHdob2xlIHRyZWUgKEZYLTEgLyBGWC00YikuXG4gIHByaXZhdGUgYWN0aXZlRmlsZTogc3RyaW5nIHwgbnVsbCA9IG51bGw7XG4gIC8vIFRoZSBzdGFnZSdzIHZpZXdlZC1kb2N1bWVudCBoaW50IChtb3VudC1yZWxhdGl2ZSksIG1pcnJvcmVkIGZyb20gdGhlIGhvc3RcbiAgLy8gYGVkaXRvci1jb250ZXh0LnZpZXdlZEZpbGVgIChSMy0yNjgpLiBTYW1lIHN0b3JlLW5vdC1wcm9wIHNoYXBlIGFzXG4gIC8vIGBhY3RpdmVGaWxlYCAoRlgtNGIpOiBhIGNoYW5nZSByZS1yZW5kZXJzIG9ubHkgdGhlIGFmZmVjdGVkIHJvd3MuXG4gIC8vIEhpZ2hsaWdodC1vbmx5IGJ5IGNvbnRyYWN0IOKAlCB0aGUgc3RvcmUgbmV2ZXIgc2Nyb2xscyBvciBzZWxlY3RzIG9uIGl0LlxuICBwcml2YXRlIHZpZXdlZEZpbGU6IHN0cmluZyB8IG51bGwgPSBudWxsO1xuICBwcml2YXRlIHJvb3RzID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gIHByaXZhdGUgbGlzdGVuZXJzID0gbmV3IFNldDwoKSA9PiB2b2lkPigpO1xuXG4gIC8vIFRoZSBpbmplY3RlZCBmaWxlc3lzdGVtIHNvdXJjZSB0aGUgc3RvcmUgcmVhZHMgZGlyZWN0b3J5IGVudHJpZXMgdGhyb3VnaC4gVGhlXG4gIC8vIHZpZXcgY29uc3RydWN0cyB0aGUgc3RvcmUgd2l0aCBhIGNvbmNyZXRlIGBGc1NvdXJjZWAgKHRoZSBTREsgYWRhcHRlcidzIFplbkZTXG4gIC8vIGBzZGtGc1NvdXJjZWAsIGZpbGUtY29tbWFuZGVyJ3MgaW4tbWVtb3J5IGZzLCBvciBhIHRlc3QgZmFrZSksIHNvIHRoZSBzdG9yZVxuICAvLyBuZXZlciBpbXBvcnRzIGEgY29uY3JldGUgZnMgKFBoYXNlIDAyIMKnQS4yKS4gQW4gZXhwbGljaXQgZmllbGQgYXNzaWdubWVudFxuICAvLyAobm90IGEgcGFyYW1ldGVyIHByb3BlcnR5KSBrZWVwcyBgZXJhc2FibGVTeW50YXhPbmx5YCBoYXBweS5cbiAgcHJpdmF0ZSBmczogRnNTb3VyY2U7XG4gIGNvbnN0cnVjdG9yKGZzOiBGc1NvdXJjZSkge1xuICAgIHRoaXMuZnMgPSBmcztcbiAgfVxuXG4gIC8qKiBTdGFibGUgc3Vic2NyaWJlIGZuIGZvciBgdXNlU3luY0V4dGVybmFsU3RvcmVgIChpZGVudGl0eSBtdXN0IG5vdCBjaGFuZ2UpLiAqL1xuICBzdWJzY3JpYmUgPSAobGlzdGVuZXI6ICgpID0+IHZvaWQpOiAoKCkgPT4gdm9pZCkgPT4ge1xuICAgIHRoaXMubGlzdGVuZXJzLmFkZChsaXN0ZW5lcik7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIHRoaXMubGlzdGVuZXJzLmRlbGV0ZShsaXN0ZW5lcik7XG4gICAgfTtcbiAgfTtcblxuICBwcml2YXRlIGVtaXQoKSB7XG4gICAgZm9yIChjb25zdCBsIG9mIHRoaXMubGlzdGVuZXJzKSBsKCk7XG4gIH1cblxuICAvKipcbiAgICogUmVjb25jaWxlIHRoZSBzZXQgb2YgbW91bnRlZCByb290cyAoUjMtNzkpLiBFYWNoIHJvb3Qgc3RhcnRzIG9wZW4uIElkZW1wb3RlbnRcbiAgICogYW5kIHNpZGUtZWZmZWN0LWZyZWUgd2hlbiB0aGUgc2V0IGlzIHVuY2hhbmdlZCwgc28gaXQgaXMgc2FmZSB0byBjYWxsIGR1cmluZ1xuICAgKiByZW5kZXI7IGl0IGRvZXMgTk9UIGVtaXQgKG5ldyBzY29wZXMgcmVhZCB0aGUgc2VlZGVkIHN0YXRlIG9uIGZpcnN0IHJlbmRlcjsgYVxuICAgKiByZW1vdmVkIHNjb3BlIHNpbXBseSBzdG9wcyByZW5kZXJpbmcpLiBQdXJnZXMgdGhlIHN1YnRyZWUgc3RhdGUgb2YgYW55IHJvb3Qgbm9cbiAgICogbG9uZ2VyIHByZXNlbnQgc28gaXQgY2FuJ3QgbGVhay5cbiAgICovXG4gIGVuc3VyZVJvb3RzKHJvb3RQYXRoczogc3RyaW5nW10pOiB2b2lkIHtcbiAgICBjb25zdCBuZXh0ID0gbmV3IFNldChyb290UGF0aHMpO1xuICAgIGlmIChuZXh0LnNpemUgPT09IHRoaXMucm9vdHMuc2l6ZSAmJiBbLi4ubmV4dF0uZXZlcnkoKHApID0+IHRoaXMucm9vdHMuaGFzKHApKSkgcmV0dXJuO1xuXG4gICAgLy8gUHVyZ2Ugc3RhdGUgdW5kZXIgcm9vdHMgdGhhdCB3ZW50IGF3YXkuXG4gICAgZm9yIChjb25zdCBnb25lIG9mIHRoaXMucm9vdHMpIHtcbiAgICAgIGlmIChuZXh0Lmhhcyhnb25lKSkgY29udGludWU7XG4gICAgICB0aGlzLnB1cmdlVW5kZXIoZ29uZSk7XG4gICAgfVxuICAgIC8vIE9wZW4gZWFjaCAoc3RpbGwtL25ld2x5LSkgcHJlc2VudCByb290IGJ5IGRlZmF1bHQuXG4gICAgZm9yIChjb25zdCBwIG9mIG5leHQpIHRoaXMuZXhwYW5kZWQuYWRkKHApO1xuICAgIHRoaXMucm9vdHMgPSBuZXh0O1xuICB9XG5cbiAgLyoqIERyb3AgZXhwYW5zaW9uIC8gZW50cnkgLyBlcnJvciAvIHNlbGVjdGlvbiBzdGF0ZSBhdCBgcm9vdGAgYW5kIGV2ZXJ5dGhpbmdcbiAgICogIHVuZGVyIGl0IChhIGByb290L2AtcHJlZml4ZWQgcGF0aCkuICovXG4gIHByaXZhdGUgcHVyZ2VVbmRlcihyb290OiBzdHJpbmcpIHtcbiAgICBjb25zdCB1bmRlciA9IChwOiBzdHJpbmcpID0+IHAgPT09IHJvb3QgfHwgcC5zdGFydHNXaXRoKHJvb3QgKyBcIi9cIikgfHwgcC5zdGFydHNXaXRoKHJvb3QucmVwbGFjZSgvXFwvKyQvLCBcIlwiKSArIFwiL1wiKTtcbiAgICBmb3IgKGNvbnN0IHAgb2YgWy4uLnRoaXMuZXhwYW5kZWRdKSBpZiAodW5kZXIocCkpIHRoaXMuZXhwYW5kZWQuZGVsZXRlKHApO1xuICAgIGZvciAoY29uc3QgcCBvZiBbLi4udGhpcy5lbnRyaWVzLmtleXMoKV0pIGlmICh1bmRlcihwKSkgdGhpcy5lbnRyaWVzLmRlbGV0ZShwKTtcbiAgICBmb3IgKGNvbnN0IHAgb2YgWy4uLnRoaXMuZXJyb3JlZF0pIGlmICh1bmRlcihwKSkgdGhpcy5lcnJvcmVkLmRlbGV0ZShwKTtcbiAgICBmb3IgKGNvbnN0IHAgb2YgWy4uLnRoaXMucGVuZGluZ10pIGlmICh1bmRlcihwKSkgdGhpcy5wZW5kaW5nLmRlbGV0ZShwKTtcbiAgICBpZiAodGhpcy5zZWxlY3RlZCAmJiB1bmRlcih0aGlzLnNlbGVjdGVkKSkge1xuICAgICAgdGhpcy5zZWxlY3RlZCA9IG51bGw7XG4gICAgICB0aGlzLnNlbGVjdGVkSXNEaXIgPSBmYWxzZTtcbiAgICAgIHRoaXMuc2VsZWN0ZWRSb3dTbmFwc2hvdCA9IG51bGw7XG4gICAgfVxuICAgIGlmICh0aGlzLmZvY3VzZWQgJiYgdW5kZXIodGhpcy5mb2N1c2VkKSkgdGhpcy5mb2N1c2VkID0gbnVsbDtcbiAgICBsZXQgZHJvcHBlZCA9IGZhbHNlO1xuICAgIGZvciAoY29uc3QgcCBvZiBbLi4udGhpcy5zZWxlY3Rpb25dKSB7XG4gICAgICBpZiAodW5kZXIocCkpIHtcbiAgICAgICAgdGhpcy5zZWxlY3Rpb24uZGVsZXRlKHApO1xuICAgICAgICBkcm9wcGVkID0gdHJ1ZTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKGRyb3BwZWQpIHRoaXMucmVmcmVzaFNlbGVjdGlvblNuYXBzaG90KCk7XG4gIH1cblxuICAvLyAtLS0gcGVyLXBhdGggc2VsZWN0b3JzIChzdGFibGUgcHJpbWl0aXZlIC8gYXJyYXkgc25hcHNob3RzKSAtLS1cbiAgaXNFeHBhbmRlZCA9IChwOiBzdHJpbmcpOiBib29sZWFuID0+IHRoaXMuZXhwYW5kZWQuaGFzKHApO1xuICBpc1NlbGVjdGVkID0gKHA6IHN0cmluZyk6IGJvb2xlYW4gPT4gdGhpcy5zZWxlY3RlZCA9PT0gcDtcbiAgaXNFcnJvcmVkID0gKHA6IHN0cmluZyk6IGJvb2xlYW4gPT4gdGhpcy5lcnJvcmVkLmhhcyhwKTtcbiAgZ2V0RW50cmllcyA9IChwOiBzdHJpbmcpOiBEaXJFbnRyeVtdIHwgdW5kZWZpbmVkID0+IHRoaXMuZW50cmllcy5nZXQocCk7XG4gIC8qKiBUaGUgc2VsZWN0ZWQgYWJzb2x1dGUgcGF0aCAoc2hhcmVkIGFjcm9zcyBldmVyeSBsYXlvdXQpLiAqL1xuICBnZXRTZWxlY3RlZCA9ICgpOiBzdHJpbmcgfCBudWxsID0+IHRoaXMuc2VsZWN0ZWQ7XG4gIC8qKiBUaGUgc2VsZWN0ZWQgcm93IOKAlCBwYXRoICsgd2hldGhlciBpdCBpcyBhIGRpcmVjdG9yeSDigJQgZm9yIGNvbnN1bWVycyB0aGF0XG4gICAqICBuZWVkIHRoZSBzZWxlY3Rpb24ncyBTSEFQRSwgbm90IGp1c3QgaXRzIHBhdGggKHRoZSB1cGxvYWQgYnV0dG9uJ3NcbiAgICogIGRlc3RpbmF0aW9uKS4gU3RhYmxlIGlkZW50aXR5IGJldHdlZW4gbXV0YXRpb25zLiAqL1xuICBnZXRTZWxlY3RlZFJvdyA9ICgpOiB7IHBhdGg6IHN0cmluZzsgaXNEaXI6IGJvb2xlYW4gfSB8IG51bGwgPT4gdGhpcy5zZWxlY3RlZFJvd1NuYXBzaG90O1xuICAvKiogSXMgYHBgIChhYnNvbHV0ZSkgaW4gdGhlIG11bHRpLXNlbGVjdCBzZXQ/IERyaXZlcyB0aGUgYGxyb3ctLXNlbGVjdGVkYFxuICAgKiAgaGlnaGxpZ2h0IHVuZGVyIGBzZWxlY3Rpb25Nb2RlID09PSBcIm11bHRpXCJgLiAqL1xuICBpc0luU2VsZWN0aW9uID0gKHA6IHN0cmluZyk6IGJvb2xlYW4gPT4gdGhpcy5zZWxlY3Rpb24uaGFzKHApO1xuICAvKiogVGhlIG11bHRpLXNlbGVjdCBzZXQgYXMgYSBzdGFibGUtaWRlbnRpdHkgYXJyYXkgKGFic29sdXRlIHBhdGhzKS4gVGhlXG4gICAqICByZXR1cm5lZCBhcnJheSBpcyBjYWNoZWQgYW5kIG9ubHkgcmUtY3JlYXRlZCB3aGVuIHRoZSBzZXQgY2hhbmdlcywgc29cbiAgICogIGB1c2VTeW5jRXh0ZXJuYWxTdG9yZWAgc2VlcyBhIHN0YWJsZSBzbmFwc2hvdCBiZXR3ZWVuIHJlYWwgbXV0YXRpb25zLiAqL1xuICBnZXRTZWxlY3Rpb24gPSAoKTogc3RyaW5nW10gPT4gdGhpcy5zZWxlY3Rpb25TbmFwc2hvdDtcbiAgLyoqIElzIGByZXBvUmVsYCAobW91bnQtcmVsYXRpdmUpIHRoZSBlZGl0b3IncyBhY3RpdmUgZmlsZT8gRHJpdmVzIHRoZSBGWC00YiByb3dcbiAgICogIGhpZ2hsaWdodCB3aXRob3V0IGEgcGVyLW5vZGUgcHJvcCAoY29tcGFyZWQgbW91bnQtcmVsYXRpdmUsIG1hdGNoaW5nIHRoZVxuICAgKiAgaG9zdCdzIGBlZGl0b3ItY29udGV4dC5hY3RpdmVGaWxlYCkuICovXG4gIGlzQWN0aXZlID0gKHJlcG9SZWw6IHN0cmluZyk6IGJvb2xlYW4gPT4gdGhpcy5hY3RpdmVGaWxlID09PSByZXBvUmVsO1xuICAvKiogVGhlIGVkaXRvcidzIGFjdGl2ZSBmaWxlLCBtb3VudC1yZWxhdGl2ZSAoc2hhcmVkIGFjcm9zcyBldmVyeSBsYXlvdXQpLiAqL1xuICBnZXRBY3RpdmVGaWxlID0gKCk6IHN0cmluZyB8IG51bGwgPT4gdGhpcy5hY3RpdmVGaWxlO1xuICAvKiogSXMgYHJlcG9SZWxgIHRoZSBmaWxlIHRoZSBTVEFHRSBjbGFpbXMgdG8gYmUgcmVuZGVyaW5nIChSMy0yNjgpPyBEcml2ZXMgdGhlXG4gICAqICBcIm9uIHN0YWdlXCIgbWFya2VyLCB2aXN1YWxseSBkaXN0aW5jdCBmcm9tIHRoZSBlZGl0b3ItYWN0aXZlIGhpZ2hsaWdodC4gKi9cbiAgaXNWaWV3ZWQgPSAocmVwb1JlbDogc3RyaW5nKTogYm9vbGVhbiA9PiB0aGlzLnZpZXdlZEZpbGUgPT09IHJlcG9SZWw7XG4gIC8qKiBUaGUgc3RhZ2UncyB2aWV3ZWQtZG9jdW1lbnQgaGludCwgbW91bnQtcmVsYXRpdmUgKG9yIG51bGwg4oCUIG5vIGhpbnQpLiAqL1xuICBnZXRWaWV3ZWRGaWxlID0gKCk6IHN0cmluZyB8IG51bGwgPT4gdGhpcy52aWV3ZWRGaWxlO1xuICAvKiogSXMgdGhlIHJvdyBhdCBhYnNvbHV0ZSBgcGAgYSB3cml0ZSBpbiBmbGlnaHQgKG9wdGltaXN0aWNhbGx5IGluc2VydGVkKT8gKi9cbiAgaXNQZW5kaW5nID0gKHA6IHN0cmluZyk6IGJvb2xlYW4gPT4gdGhpcy5wZW5kaW5nLmhhcyhwKTtcbiAgLyoqIFRoZSBsYXN0LWZvY3VzZWQgcm93J3MgYWJzb2x1dGUgcGF0aCAodGhlIHJvdmluZyB0YWIgc3RvcCksIG9yIG51bGwuICovXG4gIGdldEZvY3VzZWQgPSAoKTogc3RyaW5nIHwgbnVsbCA9PiB0aGlzLmZvY3VzZWQ7XG4gIC8qKiBEb2VzIGFueSBmb2N1c2VkIHJvdyBzaXQgaW5zaWRlIHRoZSB0cmVlIHJvb3RlZCBhdCBgcm9vdFBhdGhgPyAqL1xuICBpc0ZvY3VzSW5UcmVlID0gKHJvb3RQYXRoOiBzdHJpbmcpOiBib29sZWFuID0+XG4gICAgdGhpcy5mb2N1c2VkICE9PSBudWxsICYmXG4gICAgKHRoaXMuZm9jdXNlZCA9PT0gcm9vdFBhdGggfHwgdGhpcy5mb2N1c2VkLnN0YXJ0c1dpdGgocm9vdFBhdGggKyBcIi9cIikpO1xuICAvKiogSXMgYHJlcG9SZWxgIChhIERJUkVDVE9SWSwgbW91bnQtcmVsYXRpdmUpIGFuIGFuY2VzdG9yIG9mIHRoZSB2aWV3ZWRcbiAgICogIGRvY3VtZW50PyBEcml2ZXMgdGhlIGNvbGxhcHNlZC1mb2xkZXIgXCJjb250YWlucyB0aGUgb24tc3RhZ2UgZmlsZVwiIGRvdCDigJRcbiAgICogIGEgY29ycHVzIHVuZGVyIGEgY2hyb290IHN1YmRpciBzdGF5cyBkaXNjb3ZlcmFibGUgd2hpbGUgdGhlIHRyZWUgaXRzZWxmIGlzXG4gICAqICB1bnRvdWNoZWQgKHRoZSBoaWdobGlnaHQtb25seSBjb250cmFjdCkuICovXG4gIGlzVmlld2VkQW5jZXN0b3IgPSAocmVwb1JlbDogc3RyaW5nKTogYm9vbGVhbiA9PiB7XG4gICAgaWYgKCF0aGlzLnZpZXdlZEZpbGUpIHJldHVybiBmYWxzZTtcbiAgICBpZiAocmVwb1JlbCA9PT0gXCIvXCIpIHJldHVybiB0cnVlO1xuICAgIHJldHVybiB0aGlzLnZpZXdlZEZpbGUuc3RhcnRzV2l0aChyZXBvUmVsICsgXCIvXCIpO1xuICB9O1xuICAvKiogSXMgYHJlcG9SZWxgIChhIERJUkVDVE9SWSwgbW91bnQtcmVsYXRpdmUpIGFuIGFuY2VzdG9yIG9mIHRoZSBlZGl0b3Inc1xuICAgKiAgYWN0aXZlIGZpbGU/IFRoZSBjb3VudGVycGFydCBvZiB7QGxpbmsgaXNWaWV3ZWRBbmNlc3Rvcn0gZm9yIHRoZSBGWC00YlxuICAgKiAgc2lnbmFsOiBvbmNlIHRoZSB1c2VyIGNvbGxhcHNlcyB0aGUgZm9sZGVyIGhvbGRpbmcgdGhlIGVkaXRlZCBmaWxlLCB0aGVcbiAgICogIG1hcmtlciBtdXN0IG5vdCBzaW1wbHkgdmFuaXNoLiAqL1xuICBpc0FjdGl2ZUFuY2VzdG9yID0gKHJlcG9SZWw6IHN0cmluZyk6IGJvb2xlYW4gPT4ge1xuICAgIGlmICghdGhpcy5hY3RpdmVGaWxlKSByZXR1cm4gZmFsc2U7XG4gICAgaWYgKHJlcG9SZWwgPT09IFwiL1wiKSByZXR1cm4gdHJ1ZTtcbiAgICByZXR1cm4gdGhpcy5hY3RpdmVGaWxlLnN0YXJ0c1dpdGgocmVwb1JlbCArIFwiL1wiKTtcbiAgfTtcblxuICAvLyAtLS0gbXV0YXRpb25zIChjYWxsZWQgZnJvbSBoYW5kbGVycyAvIGVmZmVjdHMsIG5ldmVyIGR1cmluZyByZW5kZXIpIC0tLVxuICB0b2dnbGUgPSAocDogc3RyaW5nKTogdm9pZCA9PiB7XG4gICAgaWYgKHRoaXMuZXhwYW5kZWQuaGFzKHApKSB7XG4gICAgICB0aGlzLmV4cGFuZGVkLmRlbGV0ZShwKTtcbiAgICAgIC8vIFRoZSByb3dzIHVuZGVybmVhdGggYXJlIGFib3V0IHRvIHVubW91bnQg4oCUIGEgZm9jdXMgcG9pbnRpbmcgYXQgb25lIG9mXG4gICAgICAvLyB0aGVtIHdvdWxkIGxlYXZlIGl0cyB0cmVlIHdpdGggbm8gdGFiIHN0b3AuIEhhbmQgaXQgdG8gdGhlIGZvbGRlci5cbiAgICAgIGlmICh0aGlzLmZvY3VzZWQgIT09IG51bGwgJiYgdGhpcy5mb2N1c2VkICE9PSBwICYmIHRoaXMuZm9jdXNlZC5zdGFydHNXaXRoKHAgKyBcIi9cIikpIHtcbiAgICAgICAgdGhpcy5mb2N1c2VkID0gcDtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5leHBhbmRlZC5hZGQocCk7XG4gICAgfVxuICAgIHRoaXMuZW1pdCgpO1xuICB9O1xuXG4gIC8qKiBFeHBhbmQgZXZlcnkgYW5jZXN0b3Igb2YgdGhlIG1vdW50LXJlbGF0aXZlIGBwYXRoYCB1bmRlciBFVkVSWSByb290LiBVc2VkXG4gICAqICBieSB0aGUgZ2VzdHVyZS1nYXRlZCBzdGFnZSByZXZlYWwgKHRoZSBob3N0J3Mgb25lLXNob3QgYHZpZXdlZC1yZXZlYWxgKSBhbmRcbiAgICogIGJ5IHRoZSBlZGl0b3ItYWN0aXZlIHJldmVhbC4gQSBwYXRoIHRoYXRcbiAgICogIGRvZXNuJ3QgZXhpc3QgdW5kZXIgYSByb290IG5ldmVyIHJlbmRlcnMsIHNvIG92ZXItZXhwYW5zaW9uIGlzIGluZXJ0LlxuICAgKiAgUmVuZGVyaW5nIG9ubHkg4oCUIG5ldmVyIGZvY3VzZXM7IHRoZSBjYWxsZXIgb3ducyB0aGUgKG9wdGlvbmFsKSBzY3JvbGwuICovXG4gIHJldmVhbFBhdGggPSAocGF0aDogc3RyaW5nKTogdm9pZCA9PiB7XG4gICAgY29uc3Qgc2VncyA9IHBhdGguc3BsaXQoXCIvXCIpLmZpbHRlcihCb29sZWFuKTtcbiAgICBzZWdzLnBvcCgpOyAvLyB0aGUgZmlsZSBpdHNlbGYg4oCUIGV4cGFuc2lvbiBhcHBsaWVzIHRvIGl0cyBhbmNlc3RvciBkaXJzXG4gICAgbGV0IGNoYW5nZWQgPSBmYWxzZTtcbiAgICBmb3IgKGNvbnN0IHJvb3Qgb2YgdGhpcy5yb290cykge1xuICAgICAgbGV0IHAgPSByb290O1xuICAgICAgZm9yIChjb25zdCBzZWcgb2Ygc2Vncykge1xuICAgICAgICBwID0gYCR7cH0vJHtzZWd9YDtcbiAgICAgICAgaWYgKCF0aGlzLmV4cGFuZGVkLmhhcyhwKSkge1xuICAgICAgICAgIHRoaXMuZXhwYW5kZWQuYWRkKHApO1xuICAgICAgICAgIGNoYW5nZWQgPSB0cnVlO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChjaGFuZ2VkKSB0aGlzLmVtaXQoKTtcbiAgfTtcblxuICAvKiogRm9yY2UgYSBkaXJlY3Rvcnkgb3BlbiAodXNlZCB3aGVuIHJldmVhbGluZyBhIGRyb3AgdGFyZ2V0IC8gYSBjcmVhdGVkIHBhdGgpLiAqL1xuICBvcGVuID0gKHA6IHN0cmluZyk6IHZvaWQgPT4ge1xuICAgIGlmICh0aGlzLmV4cGFuZGVkLmhhcyhwKSkgcmV0dXJuO1xuICAgIHRoaXMuZXhwYW5kZWQuYWRkKHApO1xuICAgIHRoaXMuZW1pdCgpO1xuICB9O1xuXG4gIC8qKiBSZWNvcmQgdGhlIHNlbGVjdGVkIHJvdyAoYWJzb2x1dGUgcGF0aCkuIERyaXZlcyB0aGUgRlgtNGEgcm93IGhpZ2hsaWdodC5cbiAgICogIEZpbGVzIEFORCBkaXJlY3RvcmllcyBhcmUgc2VsZWN0YWJsZSDigJQgYSBzZWxlY3RlZCBkaXJlY3RvcnkgaXMgdGhlIHVwbG9hZFxuICAgKiAgYnV0dG9uJ3MgZGVzdGluYXRpb24gKEZJTEVfRVhQTE9SRVJfU1BFQyDCpzUpLCBzbyBpdHMga2luZCB0cmF2ZWxzIGFsb25nLiAqL1xuICBzZWxlY3QgPSAocDogc3RyaW5nLCBpc0RpciA9IGZhbHNlKTogdm9pZCA9PiB7XG4gICAgaWYgKHRoaXMuc2VsZWN0ZWQgPT09IHAgJiYgdGhpcy5zZWxlY3RlZElzRGlyID09PSBpc0RpcikgcmV0dXJuO1xuICAgIHRoaXMuc2VsZWN0ZWQgPSBwO1xuICAgIHRoaXMuc2VsZWN0ZWRJc0RpciA9IGlzRGlyO1xuICAgIHRoaXMuc2VsZWN0ZWRSb3dTbmFwc2hvdCA9IHsgcGF0aDogcCwgaXNEaXIgfTtcbiAgICB0aGlzLmVtaXQoKTtcbiAgfTtcblxuICAvKiogUmVjb3JkIHRoZSBmb2N1c2VkIHJvdyAoYWJzb2x1dGUgcGF0aCkg4oCUIG1vdmVzIHRoZSByb3ZpbmcgdGFiIHN0b3AuICovXG4gIHNldEZvY3VzID0gKHA6IHN0cmluZyB8IG51bGwpOiB2b2lkID0+IHtcbiAgICBpZiAodGhpcy5mb2N1c2VkID09PSBwKSByZXR1cm47XG4gICAgdGhpcy5mb2N1c2VkID0gcDtcbiAgICB0aGlzLmVtaXQoKTtcbiAgfTtcblxuICAvLyAtLS0gb3B0aW1pc3RpYyB3cml0ZSBtdXRhdGlvbnMgKGNhbGxlZCBieSB0aGUgd3JpdGUgZmxvdywgbmV2ZXIgcmVuZGVyKSAtLS1cbiAgLy8gRXZlcnkgbXV0YXRpb24gcmVwbGFjZXMgdGhlIGRpcmVjdG9yeSdzIGFycmF5IChuZXZlciBtdXRhdGVzIGl0IGluIHBsYWNlKVxuICAvLyBzbyBgZ2V0RW50cmllc2Agc25hcHNob3RzIGNoYW5nZSBpZGVudGl0eSBhbmQgYHVzZVN5bmNFeHRlcm5hbFN0b3JlYCBzZWVzXG4gIC8vIHRoZSB1cGRhdGUuXG5cbiAgLyoqIEluc2VydCBgZW50cnlgIGludG8gYGRpcmAncyBjYWNoZWQgbGlzdGluZyBhdCBpdHMgZmluYWwgKHNvcnRlZClcbiAgICogIHBvc2l0aW9uLiBBIGRpcmVjdG9yeSB3aG9zZSBsaXN0aW5nIGlzIG5vdCBsb2FkZWQgeWV0IChjb2xsYXBzZWQsXG4gICAqICBuZXZlciByZWFkKSBpcyBsZWZ0IGFsb25lIOKAlCBub3RoaW5nIHJlbmRlcnMgdGhlcmUgdW50aWwgaXQgbG9hZHMsIGFuZFxuICAgKiAgdGhlIHBvc3Qtc2V0dGxlIGByZWZyZXNoRGlyYCBpcyB0aGUgYXV0aG9yaXR5LiAqL1xuICBwcml2YXRlIHNvcnRlZEluc2VydCA9IChkaXI6IHN0cmluZywgZW50cnk6IERpckVudHJ5LCBhc1BlbmRpbmc6IGJvb2xlYW4pOiB2b2lkID0+IHtcbiAgICBjb25zdCBsaXN0ID0gdGhpcy5lbnRyaWVzLmdldChkaXIpO1xuICAgIGlmICghbGlzdCkgcmV0dXJuO1xuICAgIGNvbnN0IG5leHQgPSBbLi4ubGlzdF07XG4gICAgbGV0IGkgPSBuZXh0LmZpbmRJbmRleCgoZSkgPT4gY29tcGFyZUVudHJpZXMoZW50cnksIGUsIFwibmFtZVwiKSA8IDApO1xuICAgIGlmIChpIDwgMCkgaSA9IG5leHQubGVuZ3RoO1xuICAgIG5leHQuc3BsaWNlKGksIDAsIGVudHJ5KTtcbiAgICB0aGlzLmVudHJpZXMuc2V0KGRpciwgbmV4dCk7XG4gICAgaWYgKGFzUGVuZGluZykgdGhpcy5wZW5kaW5nLmFkZChgJHtkaXJ9LyR7ZW50cnkubmFtZX1gKTtcbiAgICB0aGlzLmVtaXQoKTtcbiAgfTtcblxuICAvKiogSW5zZXJ0IGFuIGVudHJ5IHRoYXQgaXMgTk9UIHlldCByZWFsIOKAlCB0aGUgcm93IHRoZSB1c2VyIGp1c3QgYXNrZWQgZm9yLFxuICAgKiAgcmVuZGVyZWQgaW1tZWRpYXRlbHkgYXQgaXRzIGZpbmFsIHBvc2l0aW9uIGluIGEgcGVuZGluZyB0cmVhdG1lbnRcbiAgICogIChSLUlYLTMpLiBUaGUgd3JpdGUncyBvd24gcmV0dXJuIHNldHRsZXMgaXQgdmlhIHtAbGluayBzZXR0bGVFbnRyeX0uICovXG4gIGluc2VydFBlbmRpbmcgPSAoZGlyOiBzdHJpbmcsIGVudHJ5OiBEaXJFbnRyeSk6IHZvaWQgPT4ge1xuICAgIHRoaXMuc29ydGVkSW5zZXJ0KGRpciwgZW50cnksIHRydWUpO1xuICB9O1xuXG4gIC8qKiBJbnNlcnQgKG9yIHJlc3RvcmUsIGFmdGVyIGEgZmFpbGVkIHdyaXRlKSBhIHJlYWwgZW50cnkuICovXG4gIGluc2VydEVudHJ5ID0gKGRpcjogc3RyaW5nLCBlbnRyeTogRGlyRW50cnkpOiB2b2lkID0+IHtcbiAgICB0aGlzLnNvcnRlZEluc2VydChkaXIsIGVudHJ5LCBmYWxzZSk7XG4gIH07XG5cbiAgLyoqIFJlcGxhY2UgdGhlIHBlbmRpbmcgcm93IGBwZW5kaW5nTmFtZWAgaW4gYGRpcmAgd2l0aCB0aGUgYXV0aG9yaXRhdGl2ZVxuICAgKiAgYGVudHJ5YCB0aGUgd3JpdGUgcmV0dXJuZWQg4oCUIHRoZSBzZXR0bGUsIHdpdGggbm8gcmVhZCBhdCBhbGwgKFItSVgtNCkuICovXG4gIHNldHRsZUVudHJ5ID0gKGRpcjogc3RyaW5nLCBwZW5kaW5nTmFtZTogc3RyaW5nLCBlbnRyeTogRGlyRW50cnkpOiB2b2lkID0+IHtcbiAgICBjb25zdCBsaXN0ID0gdGhpcy5lbnRyaWVzLmdldChkaXIpO1xuICAgIHRoaXMucGVuZGluZy5kZWxldGUoYCR7ZGlyfS8ke3BlbmRpbmdOYW1lfWApO1xuICAgIGlmICghbGlzdCkgcmV0dXJuO1xuICAgIGNvbnN0IGkgPSBsaXN0LmZpbmRJbmRleCgoZSkgPT4gZS5uYW1lID09PSBwZW5kaW5nTmFtZSk7XG4gICAgaWYgKGkgPCAwKSByZXR1cm47XG4gICAgY29uc3QgbmV4dCA9IFsuLi5saXN0XTtcbiAgICBuZXh0W2ldID0gZW50cnk7XG4gICAgLy8gVGhlIGF1dGhvcml0eSBtYXkgaGF2ZSBub3JtYWxpemVkIHRoZSBuYW1lOyBrZWVwIHRoZSBsaXN0aW5nIHNvcnRlZC5cbiAgICBuZXh0LnNvcnQoKGEsIGIpID0+IGNvbXBhcmVFbnRyaWVzKGEsIGIsIFwibmFtZVwiKSk7XG4gICAgdGhpcy5lbnRyaWVzLnNldChkaXIsIG5leHQpO1xuICAgIHRoaXMuZW1pdCgpO1xuICB9O1xuXG4gIC8qKiBEcm9wIGBuYW1lYCBmcm9tIGBkaXJgJ3MgY2FjaGVkIGxpc3RpbmcgKGFuIG9wdGltaXN0aWMgcmVtb3ZlLCBvciB0aGVcbiAgICogIGNsZWFudXAgb2YgYSBwZW5kaW5nIHJvdykuIE5vLW9wIHdoZW4gdGhlIGxpc3RpbmcgaXMgbm90IGxvYWRlZC4gKi9cbiAgcmVtb3ZlRW50cnkgPSAoZGlyOiBzdHJpbmcsIG5hbWU6IHN0cmluZyk6IHZvaWQgPT4ge1xuICAgIGNvbnN0IGdvbmUgPSBgJHtkaXJ9LyR7bmFtZX1gO1xuICAgIGNvbnN0IGxpc3QgPSB0aGlzLmVudHJpZXMuZ2V0KGRpcik7XG4gICAgdGhpcy5wZW5kaW5nLmRlbGV0ZShnb25lKTtcbiAgICBpZiAodGhpcy5mb2N1c2VkID09PSBnb25lKSB0aGlzLmZvY3VzZWQgPSBudWxsO1xuICAgIGlmICghbGlzdCkgcmV0dXJuO1xuICAgIGNvbnN0IGkgPSBsaXN0LmZpbmRJbmRleCgoZSkgPT4gZS5uYW1lID09PSBuYW1lKTtcbiAgICBpZiAoaSA8IDApIHJldHVybjtcbiAgICBjb25zdCBuZXh0ID0gWy4uLmxpc3RdO1xuICAgIG5leHQuc3BsaWNlKGksIDEpO1xuICAgIHRoaXMuZW50cmllcy5zZXQoZGlyLCBuZXh0KTtcbiAgICB0aGlzLmVtaXQoKTtcbiAgfTtcblxuICAvKiogUmVjb21wdXRlIHRoZSBjYWNoZWQgc2VsZWN0aW9uIHNuYXBzaG90IGFmdGVyIGEgc2V0IG11dGF0aW9uLiAqL1xuICBwcml2YXRlIHJlZnJlc2hTZWxlY3Rpb25TbmFwc2hvdCgpIHtcbiAgICB0aGlzLnNlbGVjdGlvblNuYXBzaG90ID0gWy4uLnRoaXMuc2VsZWN0aW9uXTtcbiAgfVxuXG4gIC8qKiBUb2dnbGUgYHBgIChhYnNvbHV0ZSkgaW4gdGhlIG11bHRpLXNlbGVjdCBzZXQgYW5kIGVtaXQuICovXG4gIHRvZ2dsZUluU2VsZWN0aW9uID0gKHA6IHN0cmluZyk6IHZvaWQgPT4ge1xuICAgIGlmICh0aGlzLnNlbGVjdGlvbi5oYXMocCkpIHRoaXMuc2VsZWN0aW9uLmRlbGV0ZShwKTtcbiAgICBlbHNlIHRoaXMuc2VsZWN0aW9uLmFkZChwKTtcbiAgICB0aGlzLnJlZnJlc2hTZWxlY3Rpb25TbmFwc2hvdCgpO1xuICAgIHRoaXMuZW1pdCgpO1xuICB9O1xuXG4gIC8qKiBDbGVhciB0aGUgbXVsdGktc2VsZWN0IHNldCAoZW1pdHMgb25seSBpZiBpdCBoZWxkIGFueXRoaW5nKS4gKi9cbiAgY2xlYXJTZWxlY3Rpb24gPSAoKTogdm9pZCA9PiB7XG4gICAgaWYgKHRoaXMuc2VsZWN0aW9uLnNpemUgPT09IDApIHJldHVybjtcbiAgICB0aGlzLnNlbGVjdGlvbi5jbGVhcigpO1xuICAgIHRoaXMucmVmcmVzaFNlbGVjdGlvblNuYXBzaG90KCk7XG4gICAgdGhpcy5lbWl0KCk7XG4gIH07XG5cbiAgLyoqIE1pcnJvciB0aGUgZWRpdG9yJ3MgYWN0aXZlIGZpbGUgKG1vdW50LXJlbGF0aXZlKS4gRW1pdHMgb25seSBvbiBhIHJlYWwgY2hhbmdlLFxuICAgKiAgc28gdGhlIGVkaXRvci1jb250ZXh0IHB1c2ggcmUtcmVuZGVycyBqdXN0IHRoZSB0d28gYWZmZWN0ZWQgcm93cyAoRlgtNGIpLiAqL1xuICBzZXRBY3RpdmVGaWxlID0gKG5leHQ6IHN0cmluZyB8IG51bGwpOiB2b2lkID0+IHtcbiAgICBpZiAodGhpcy5hY3RpdmVGaWxlID09PSBuZXh0KSByZXR1cm47XG4gICAgdGhpcy5hY3RpdmVGaWxlID0gbmV4dDtcbiAgICB0aGlzLmVtaXQoKTtcbiAgfTtcblxuICAvKiogTWlycm9yIHRoZSBzdGFnZSdzIHZpZXdlZC1kb2N1bWVudCBoaW50IChtb3VudC1yZWxhdGl2ZTsgUjMtMjY4KS4gRW1pdHMgb25seVxuICAgKiAgb24gYSByZWFsIGNoYW5nZSBzbyBhIG5hdmlnYXRpb24gcmUtcmVuZGVycyBqdXN0IHRoZSBhZmZlY3RlZCByb3dzLiAqL1xuICBzZXRWaWV3ZWRGaWxlID0gKG5leHQ6IHN0cmluZyB8IG51bGwpOiB2b2lkID0+IHtcbiAgICBpZiAodGhpcy52aWV3ZWRGaWxlID09PSBuZXh0KSByZXR1cm47XG4gICAgdGhpcy52aWV3ZWRGaWxlID0gbmV4dDtcbiAgICB0aGlzLmVtaXQoKTtcbiAgfTtcblxuICAvKiogQ29sbGFwc2UgZXZlcnkgZGlyZWN0b3J5IGJ1dCBrZWVwIHRoZSBtb3VudGVkIHJvb3RzIG9wZW4gKFwiY29sbGFwc2UgYWxsXCIpLiAqL1xuICBjb2xsYXBzZUFsbCA9ICgpOiB2b2lkID0+IHtcbiAgICB0aGlzLmV4cGFuZGVkID0gbmV3IFNldCh0aGlzLnJvb3RzKTtcbiAgICB0aGlzLmVtaXQoKTtcbiAgfTtcblxuICAvKiogTGF6aWx5IHJlYWQgYSBkaXJlY3RvcnkncyBjaGlsZHJlbiBvbmNlLiBEZWR1cGVzIGNvbmN1cnJlbnQvcmVwZWF0IHJlYWRzLiAqL1xuICBlbnN1cmVMb2FkZWQgPSAocDogc3RyaW5nKTogdm9pZCA9PiB7XG4gICAgaWYgKHRoaXMuZW50cmllcy5oYXMocCkgfHwgdGhpcy5lcnJvcmVkLmhhcyhwKSB8fCB0aGlzLmluZmxpZ2h0LmhhcyhwKSkgcmV0dXJuO1xuICAgIHRoaXMuaW5mbGlnaHQuYWRkKHApO1xuICAgIHZvaWQgdGhpcy5mcy5yZWFkZGlyKHApLnRoZW4oXG4gICAgICAobGlzdCkgPT4ge1xuICAgICAgICB0aGlzLmluZmxpZ2h0LmRlbGV0ZShwKTtcbiAgICAgICAgdGhpcy5lbnRyaWVzLnNldChwLCBsaXN0KTtcbiAgICAgICAgdGhpcy5lcnJvcmVkLmRlbGV0ZShwKTtcbiAgICAgICAgdGhpcy5lbWl0KCk7XG4gICAgICB9LFxuICAgICAgKCkgPT4ge1xuICAgICAgICB0aGlzLmluZmxpZ2h0LmRlbGV0ZShwKTtcbiAgICAgICAgdGhpcy5lcnJvcmVkLmFkZChwKTtcbiAgICAgICAgdGhpcy5lbWl0KCk7XG4gICAgICB9LFxuICAgICk7XG4gIH07XG5cbiAgLyoqXG4gICAqIFJlLXJlYWQgZXZlcnkgY3VycmVudGx5LW9wZW4gZGlyZWN0b3J5IGluIHBsYWNlIOKAlCB0aGUgRVhQTElDSVQgcmVsb2FkXG4gICAqIChsYXlvdXQgc3dpdGNoZXMsIGEgY29uc3VtZXIncyBcInJlZnJlc2hcIiBhZmZvcmRhbmNlKS4gVGhlIHBvc3Qtd3JpdGUgcGF0aFxuICAgKiBkb2VzIE5PVCB1c2UgdGhpczsgaXQgc2V0dGxlcyBmcm9tIHRoZSB3cml0ZSdzIHJldHVybiBhbmQgdGhlbiBjYWxscyB0aGVcbiAgICogbmFycm93IHtAbGluayByZWZyZXNoRGlyfS4gU3RhbGUgY29udGVudCBzdGF5cyB2aXNpYmxlIHVudGlsIGZyZXNoIGVudHJpZXNcbiAgICogbGFuZCDigJQgbm8gc3Bpbm5lciBmbGFzaCDigJQgYW5kIGV4cGFuc2lvbi9zZWxlY3Rpb24gYXJlIHVudG91Y2hlZC5cbiAgICovXG4gIHJlZnJlc2ggPSAoKTogdm9pZCA9PiB7XG4gICAgZm9yIChjb25zdCBwIG9mIFsuLi50aGlzLmV4cGFuZGVkXSkge1xuICAgICAgdm9pZCB0aGlzLmZzLnJlYWRkaXIocCkudGhlbihcbiAgICAgICAgKGxpc3QpID0+IHtcbiAgICAgICAgICB0aGlzLmVudHJpZXMuc2V0KHAsIGxpc3QpO1xuICAgICAgICAgIHRoaXMuZXJyb3JlZC5kZWxldGUocCk7XG4gICAgICAgICAgdGhpcy5lbWl0KCk7XG4gICAgICAgIH0sXG4gICAgICAgICgpID0+IHtcbiAgICAgICAgICB0aGlzLmVycm9yZWQuYWRkKHApO1xuICAgICAgICAgIHRoaXMuZW1pdCgpO1xuICAgICAgICB9LFxuICAgICAgKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogUmUtcmVhZCBPTkUgZGlyZWN0b3J5IGluIHBsYWNlIOKAlCB0aGUgbmFycm93IHBvc3Qtd3JpdGUgYXV0aG9yaXR5IHJlZmV0Y2hcbiAgICogKFItSVgtNDogcmVmZXRjaCB3aGF0IGNoYW5nZWQsIG5vdCBldmVyeXRoaW5nIHRoYXQgaGFwcGVucyB0byBiZSBvcGVuKS5cbiAgICogU2V0dGxlcyB0aGUgd3JpdGUncyBkaXJlY3RvcnkgYWdhaW5zdCB0aGUgYXV0aG9yaXR5LCBFWENFUFQgcm93cyB3aG9zZVxuICAgKiB3cml0ZSBpcyBzdGlsbCBpbiBmbGlnaHQ6IGEgZnJlc2ggbGlzdGluZyBjYW5ub3Qga25vdyBhYm91dCB0aGVtLCBhbmRcbiAgICogd2lwaW5nIHRoZW0gd291bGQgdW4tcmVuZGVyIGEgY2hhbmdlIHRoZSB1c2VyIGp1c3QgbWFkZSAoUi1JWC0zKSBhbmRcbiAgICogb3JwaGFuIGl0cyBzZXR0bGUuIFRoZWlyIHNldHRsZSBpcyB0aGUgd3JpdGUncyBvd24gcmV0dXJuLlxuICAgKi9cbiAgcmVmcmVzaERpciA9IChwOiBzdHJpbmcpOiB2b2lkID0+IHtcbiAgICB2b2lkIHRoaXMuZnMucmVhZGRpcihwKS50aGVuKFxuICAgICAgKGxpc3QpID0+IHtcbiAgICAgICAgLy8gQSBmcmVzaCBsaXN0aW5nIGNhbm5vdCBrbm93IGFib3V0IHJvd3Mgd2hvc2Ugd3JpdGUgaXMgc3RpbGwgaW5cbiAgICAgICAgLy8gZmxpZ2h0IOKAlCByZS1pbnNlcnQgdGhlbSAodGhlaXIgY2FjaGVkIHNlbHZlcywgcGVuZGluZyB0cmVhdG1lbnRcbiAgICAgICAgLy8gaW50YWN0KSBzbyB0aGUgcmVmZXRjaCBuZXZlciB1bi1yZW5kZXJzIGEgY2hhbmdlIGluIHByb2dyZXNzLlxuICAgICAgICBjb25zdCBjYWNoZWQgPSB0aGlzLmVudHJpZXMuZ2V0KHApO1xuICAgICAgICBsZXQgbmV4dCA9IGxpc3Q7XG4gICAgICAgIGZvciAoY29uc3QgcGVuZGluZ1BhdGggb2YgdGhpcy5wZW5kaW5nKSB7XG4gICAgICAgICAgaWYgKCFwZW5kaW5nUGF0aC5zdGFydHNXaXRoKHAgKyBcIi9cIikpIGNvbnRpbnVlO1xuICAgICAgICAgIGNvbnN0IG5hbWUgPSBwZW5kaW5nUGF0aC5zbGljZShwLmxlbmd0aCArIDEpO1xuICAgICAgICAgIGlmIChuZXh0LnNvbWUoKGUpID0+IGUubmFtZSA9PT0gbmFtZSkpIGNvbnRpbnVlO1xuICAgICAgICAgIGNvbnN0IHBlbmRpbmdFbnRyeSA9IGNhY2hlZD8uZmluZCgoZSkgPT4gZS5uYW1lID09PSBuYW1lKTtcbiAgICAgICAgICBpZiAoIXBlbmRpbmdFbnRyeSkgY29udGludWU7XG4gICAgICAgICAgaWYgKG5leHQgPT09IGxpc3QpIG5leHQgPSBbLi4ubGlzdF07XG4gICAgICAgICAgbGV0IGkgPSBuZXh0LmZpbmRJbmRleCgoZSkgPT4gY29tcGFyZUVudHJpZXMocGVuZGluZ0VudHJ5LCBlLCBcIm5hbWVcIikgPCAwKTtcbiAgICAgICAgICBpZiAoaSA8IDApIGkgPSBuZXh0Lmxlbmd0aDtcbiAgICAgICAgICBuZXh0LnNwbGljZShpLCAwLCBwZW5kaW5nRW50cnkpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuZW50cmllcy5zZXQocCwgbmV4dCk7XG4gICAgICAgIHRoaXMuZXJyb3JlZC5kZWxldGUocCk7XG4gICAgICAgIHRoaXMuZW1pdCgpO1xuICAgICAgfSxcbiAgICAgICgpID0+IHtcbiAgICAgICAgdGhpcy5lcnJvcmVkLmFkZChwKTtcbiAgICAgICAgdGhpcy5lbWl0KCk7XG4gICAgICB9LFxuICAgICk7XG4gIH07XG59XG5cbi8qKiBTdWJzY3JpYmUgYSBub2RlIHRvIGV4YWN0bHkgaXRzIG93biBzbGljZSBvZiB0aGUgc3RvcmUuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlTm9kZShcbiAgc3RvcmU6IFRyZWVTdG9yZSxcbiAgcGF0aDogc3RyaW5nLFxuKTogeyBleHBhbmRlZDogYm9vbGVhbjsgc2VsZWN0ZWQ6IGJvb2xlYW47IGVycm9yZWQ6IGJvb2xlYW47IGVudHJpZXM6IERpckVudHJ5W10gfCB1bmRlZmluZWQgfSB7XG4gIGNvbnN0IGV4cGFuZGVkID0gdXNlU3luY0V4dGVybmFsU3RvcmUoc3RvcmUuc3Vic2NyaWJlLCAoKSA9PiBzdG9yZS5pc0V4cGFuZGVkKHBhdGgpKTtcbiAgY29uc3Qgc2VsZWN0ZWQgPSB1c2VTeW5jRXh0ZXJuYWxTdG9yZShzdG9yZS5zdWJzY3JpYmUsICgpID0+IHN0b3JlLmlzU2VsZWN0ZWQocGF0aCkpO1xuICBjb25zdCBlcnJvcmVkID0gdXNlU3luY0V4dGVybmFsU3RvcmUoc3RvcmUuc3Vic2NyaWJlLCAoKSA9PiBzdG9yZS5pc0Vycm9yZWQocGF0aCkpO1xuICBjb25zdCBlbnRyaWVzID0gdXNlU3luY0V4dGVybmFsU3RvcmUoc3RvcmUuc3Vic2NyaWJlLCAoKSA9PiBzdG9yZS5nZXRFbnRyaWVzKHBhdGgpKTtcbiAgcmV0dXJuIHsgZXhwYW5kZWQsIHNlbGVjdGVkLCBlcnJvcmVkLCBlbnRyaWVzIH07XG59XG5cbi8qKiBTdWJzY3JpYmUgdG8gdGhlIHNoYXJlZCBzZWxlY3RlZCBwYXRoIChkcml2ZXMgdGhlIGhpZ2hsaWdodCBpbiBldmVyeSBsYXlvdXQpLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVzZVNlbGVjdGVkKHN0b3JlOiBUcmVlU3RvcmUpOiBzdHJpbmcgfCBudWxsIHtcbiAgcmV0dXJuIHVzZVN5bmNFeHRlcm5hbFN0b3JlKHN0b3JlLnN1YnNjcmliZSwgc3RvcmUuZ2V0U2VsZWN0ZWQpO1xufVxuXG4vKiogU3Vic2NyaWJlIHRvIHRoZSBzZWxlY3RlZCBST1cgKHBhdGggKyBpc0Rpcikg4oCUIHRoZSBzaGFwZSB0aGUgdXBsb2FkIGJ1dHRvbidzXG4gKiAgZGVzdGluYXRpb24gbmVlZHMuIFNhbWUgc2xpY2UgYXMge0BsaW5rIHVzZVNlbGVjdGVkfSwgc3RhYmxlIGlkZW50aXR5LiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVzZVNlbGVjdGVkUm93KHN0b3JlOiBUcmVlU3RvcmUpOiB7IHBhdGg6IHN0cmluZzsgaXNEaXI6IGJvb2xlYW4gfSB8IG51bGwge1xuICByZXR1cm4gdXNlU3luY0V4dGVybmFsU3RvcmUoc3RvcmUuc3Vic2NyaWJlLCBzdG9yZS5nZXRTZWxlY3RlZFJvdyk7XG59XG5cbi8qKiBTdWJzY3JpYmUgYSByb3cgdG8gT05MWSB3aGV0aGVyIGl0IGlzIGluIHRoZSBtdWx0aS1zZWxlY3Qgc2V0LiBNaXJyb3JzXG4gKiAgYHVzZVNlbGVjdGVkYC9gdXNlQWN0aXZlYDoga2V5ZWQgYnkgdGhlIHJvdydzIGFic29sdXRlIHBhdGggc28gdG9nZ2xpbmcgb25lXG4gKiAgcm93IHJlLXJlbmRlcnMganVzdCB0aGF0IHJvdywgbm90IHRoZSB3aG9sZSBsaXN0LiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVzZUluU2VsZWN0aW9uKHN0b3JlOiBUcmVlU3RvcmUsIHBhdGg6IHN0cmluZyk6IGJvb2xlYW4ge1xuICByZXR1cm4gdXNlU3luY0V4dGVybmFsU3RvcmUoc3RvcmUuc3Vic2NyaWJlLCAoKSA9PiBzdG9yZS5pc0luU2VsZWN0aW9uKHBhdGgpKTtcbn1cblxuLyoqIFN1YnNjcmliZSBhIG5vZGUgdG8gT05MWSB3aGV0aGVyIGl0IGlzIHRoZSBlZGl0b3IncyBhY3RpdmUgZmlsZSAoRlgtNGIpLiBLZXllZFxuICogIGJ5IHRoZSBub2RlJ3MgbW91bnQtcmVsYXRpdmUgcGF0aCBzbyBhIGNoYW5nZSByZS1yZW5kZXJzIGp1c3QgdGhlIHR3byByb3dzIHdob3NlXG4gKiAgYWN0aXZlIHN0YXRlIGZsaXBzIOKAlCBub3QgdGhlIHdob2xlIG1lbW9pemVkIHRyZWUuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlQWN0aXZlKHN0b3JlOiBUcmVlU3RvcmUsIHJlcG9SZWw6IHN0cmluZyk6IGJvb2xlYW4ge1xuICByZXR1cm4gdXNlU3luY0V4dGVybmFsU3RvcmUoc3RvcmUuc3Vic2NyaWJlLCAoKSA9PiBzdG9yZS5pc0FjdGl2ZShyZXBvUmVsKSk7XG59XG5cbi8qKiBTdWJzY3JpYmUgYSBub2RlIHRvIE9OTFkgd2hldGhlciBpdCBpcyB0aGUgc3RhZ2UncyB2aWV3ZWQgZG9jdW1lbnQgKFIzLTI2OCkuXG4gKiAgTWlycm9ycyB7QGxpbmsgdXNlQWN0aXZlfToga2V5ZWQgcGVyIHJvdyBzbyBhIG5hdmlnYXRpb24gcmUtcmVuZGVycyBqdXN0IHRoZVxuICogIHR3byByb3dzIHdob3NlIHZpZXdlZCBzdGF0ZSBmbGlwcy4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VWaWV3ZWQoc3RvcmU6IFRyZWVTdG9yZSwgcmVwb1JlbDogc3RyaW5nKTogYm9vbGVhbiB7XG4gIHJldHVybiB1c2VTeW5jRXh0ZXJuYWxTdG9yZShzdG9yZS5zdWJzY3JpYmUsICgpID0+IHN0b3JlLmlzVmlld2VkKHJlcG9SZWwpKTtcbn1cblxuLyoqIFN1YnNjcmliZSBhIERJUkVDVE9SWSByb3cgdG8gd2hldGhlciBpdHMgc3VidHJlZSBjb250YWlucyB0aGUgdmlld2VkIGRvY3VtZW50XG4gKiAgKHRoZSBjb2xsYXBzZWQtYW5jZXN0b3IgZG90KS4gU2FtZSBwZXItcm93IHNoYXBlIGFzIHtAbGluayB1c2VWaWV3ZWR9LiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVzZVZpZXdlZEFuY2VzdG9yKHN0b3JlOiBUcmVlU3RvcmUsIHJlcG9SZWw6IHN0cmluZyk6IGJvb2xlYW4ge1xuICByZXR1cm4gdXNlU3luY0V4dGVybmFsU3RvcmUoc3RvcmUuc3Vic2NyaWJlLCAoKSA9PiBzdG9yZS5pc1ZpZXdlZEFuY2VzdG9yKHJlcG9SZWwpKTtcbn1cblxuLyoqIFN1YnNjcmliZSBhIERJUkVDVE9SWSByb3cgdG8gd2hldGhlciBpdHMgc3VidHJlZSBjb250YWlucyB0aGUgZWRpdG9yJ3MgYWN0aXZlXG4gKiAgZmlsZSAodGhlIGNvbGxhcHNlZC1hbmNlc3RvciBkb3QpLiBTYW1lIHBlci1yb3cgc2hhcGUgYXMge0BsaW5rIHVzZUFjdGl2ZX0uICovXG5leHBvcnQgZnVuY3Rpb24gdXNlQWN0aXZlQW5jZXN0b3Ioc3RvcmU6IFRyZWVTdG9yZSwgcmVwb1JlbDogc3RyaW5nKTogYm9vbGVhbiB7XG4gIHJldHVybiB1c2VTeW5jRXh0ZXJuYWxTdG9yZShzdG9yZS5zdWJzY3JpYmUsICgpID0+IHN0b3JlLmlzQWN0aXZlQW5jZXN0b3IocmVwb1JlbCkpO1xufVxuXG4vKiogU3Vic2NyaWJlIGEgcm93IHRvIHdoZXRoZXIgaXRzIHdyaXRlIGlzIHN0aWxsIGluIGZsaWdodCAodGhlIHBlbmRpbmdcbiAqICB0cmVhdG1lbnQpLiBLZXllZCBieSBhYnNvbHV0ZSBwYXRoIHNvIGEgc2V0dGxlIHJlLXJlbmRlcnMgb25lIHJvdy4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VQZW5kaW5nKHN0b3JlOiBUcmVlU3RvcmUsIHBhdGg6IHN0cmluZyk6IGJvb2xlYW4ge1xuICByZXR1cm4gdXNlU3luY0V4dGVybmFsU3RvcmUoc3RvcmUuc3Vic2NyaWJlLCAoKSA9PiBzdG9yZS5pc1BlbmRpbmcocGF0aCkpO1xufVxuXG4vKiogU3Vic2NyaWJlIHRvIHRoZSBzaGFyZWQgZm9jdXNlZCByb3cgKHRoZSByb3ZpbmcgdGFiIHN0b3ApLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVzZUZvY3VzZWQoc3RvcmU6IFRyZWVTdG9yZSk6IHN0cmluZyB8IG51bGwge1xuICByZXR1cm4gdXNlU3luY0V4dGVybmFsU3RvcmUoc3RvcmUuc3Vic2NyaWJlLCBzdG9yZS5nZXRGb2N1c2VkKTtcbn1cblxuLyoqIFN1YnNjcmliZSBhIHJvdyB0byBPTkxZIHdoZXRoZXIgSVQgaG9sZHMgdGhlIHJvdmluZyB0YWIgc3RvcCDigJQgYSBib29sZWFuXG4gKiAgc2xpY2UsIHNvIGEgZm9jdXMgbW92ZSByZS1yZW5kZXJzIHRoZSB0d28gcm93cyB3aG9zZSBzbGljZSBmbGlwcGVkLCBub3RcbiAqICBldmVyeSByb3cgKHRoZSBzdHJpbmcgc2VsZWN0b3IgYWJvdmUgcmUtcmVuZGVycyBhbGwgb2YgaXRzIHN1YnNjcmliZXJzKS4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VSb3dGb2N1c2VkKHN0b3JlOiBUcmVlU3RvcmUsIHBhdGg6IHN0cmluZyk6IGJvb2xlYW4ge1xuICByZXR1cm4gdXNlU3luY0V4dGVybmFsU3RvcmUoc3RvcmUuc3Vic2NyaWJlLCAoKSA9PiBzdG9yZS5nZXRGb2N1c2VkKCkgPT09IHBhdGgpO1xufVxuXG4vKiogU3Vic2NyaWJlIGEgdHJlZSB0byB3aGV0aGVyIGl0cyByb3ZpbmcgdGFiIHN0b3AgbGl2ZXMgb24gdGhlIHJvb3Qgcm93IChub1xuICogIHJvdyBvZiB0aGlzIHRyZWUgaG9sZHMgZm9jdXMg4oCUIHNvbWUgb3RoZXIgdHJlZSwgb3Igbm90aGluZywgZG9lcykuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlVHJlZVVuZm9jdXNlZChzdG9yZTogVHJlZVN0b3JlLCByb290UGF0aDogc3RyaW5nKTogYm9vbGVhbiB7XG4gIHJldHVybiB1c2VTeW5jRXh0ZXJuYWxTdG9yZShzdG9yZS5zdWJzY3JpYmUsICgpID0+ICFzdG9yZS5pc0ZvY3VzSW5UcmVlKHJvb3RQYXRoKSk7XG59XG5cbi8qKlxuICogUmVhZCBvbmUgZGlyZWN0b3J5J3MgZW50cmllcyBmb3IgdGhlIGZsYXQgbGF5b3V0cyAobGlzdCAvIGljb25zIC8gY29sdW1ucykgYW5kXG4gKiBlbnN1cmUgdGhleSBhcmUgbGF6aWx5IGxvYWRlZCDigJQgcmV1c2luZyB0aGUgU0FNRSBwYXRoLWtleWVkIGNhY2hlIGFuZCBkZWR1cGUgYXNcbiAqIHRoZSB0cmVlLCBzbyBzd2l0Y2hpbmcgbGF5b3V0IG5ldmVyIHJlLXJlYWRzIHdoYXQgdGhlIHRyZWUgYWxyZWFkeSBsb2FkZWQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VEaXIoXG4gIHN0b3JlOiBUcmVlU3RvcmUsXG4gIHBhdGg6IHN0cmluZyB8IG51bGwsXG4pOiB7IGVudHJpZXM6IERpckVudHJ5W10gfCB1bmRlZmluZWQ7IGVycm9yZWQ6IGJvb2xlYW4gfSB7XG4gIGNvbnN0IGVudHJpZXMgPSB1c2VTeW5jRXh0ZXJuYWxTdG9yZShzdG9yZS5zdWJzY3JpYmUsICgpID0+XG4gICAgcGF0aCA/IHN0b3JlLmdldEVudHJpZXMocGF0aCkgOiB1bmRlZmluZWQsXG4gICk7XG4gIGNvbnN0IGVycm9yZWQgPSB1c2VTeW5jRXh0ZXJuYWxTdG9yZShzdG9yZS5zdWJzY3JpYmUsICgpID0+XG4gICAgcGF0aCA/IHN0b3JlLmlzRXJyb3JlZChwYXRoKSA6IGZhbHNlLFxuICApO1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChwYXRoICYmIGVudHJpZXMgPT09IHVuZGVmaW5lZCAmJiAhZXJyb3JlZCkgc3RvcmUuZW5zdXJlTG9hZGVkKHBhdGgpO1xuICB9LCBbc3RvcmUsIHBhdGgsIGVudHJpZXMsIGVycm9yZWRdKTtcbiAgcmV0dXJuIHsgZW50cmllcywgZXJyb3JlZCB9O1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQW9CQSxJQUFBQSxNQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxVQUFBLEdBQUFELE9BQUE7QUFyQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFLTyxNQUFNRSxTQUFTLENBQUM7RUFDYkMsUUFBUSxHQUFHLElBQUlDLEdBQUcsQ0FBUyxDQUFDO0VBQzVCQyxPQUFPLEdBQUcsSUFBSUMsR0FBRyxDQUFxQixDQUFDO0VBQ3ZDQyxPQUFPLEdBQUcsSUFBSUgsR0FBRyxDQUFTLENBQUM7RUFDM0JJLFFBQVEsR0FBRyxJQUFJSixHQUFHLENBQVMsQ0FBQztFQUM1QkssUUFBUSxHQUFrQixJQUFJO0VBQ3RDO0VBQ0E7RUFDQTtFQUNRQyxhQUFhLEdBQUcsS0FBSztFQUM3QjtFQUNBO0VBQ0E7RUFDUUMsbUJBQW1CLEdBQTRDLElBQUk7RUFDM0U7RUFDQTtFQUNBO0VBQ1FDLE9BQU8sR0FBRyxJQUFJUixHQUFHLENBQVMsQ0FBQztFQUNuQztFQUNBO0VBQ0E7RUFDUVMsT0FBTyxHQUFrQixJQUFJO0VBQ3JDO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDUUMsU0FBUyxHQUFHLElBQUlWLEdBQUcsQ0FBUyxDQUFDO0VBQzdCVyxpQkFBaUIsR0FBYSxFQUFFO0VBQ3hDO0VBQ0E7RUFDQTtFQUNBO0VBQ1FDLFVBQVUsR0FBa0IsSUFBSTtFQUN4QztFQUNBO0VBQ0E7RUFDQTtFQUNRQyxVQUFVLEdBQWtCLElBQUk7RUFDaENDLEtBQUssR0FBRyxJQUFJZCxHQUFHLENBQVMsQ0FBQztFQUN6QmUsU0FBUyxHQUFHLElBQUlmLEdBQUcsQ0FBYSxDQUFDOztFQUV6QztFQUNBO0VBQ0E7RUFDQTtFQUNBOztFQUVBZ0IsV0FBV0EsQ0FBQ0MsRUFBWSxFQUFFO0lBQ3hCLElBQUksQ0FBQ0EsRUFBRSxHQUFHQSxFQUFFO0VBQ2Q7O0VBRUE7RUFDQUMsU0FBUyxHQUFJQyxRQUFvQixJQUFtQjtJQUNsRCxJQUFJLENBQUNKLFNBQVMsQ0FBQ0ssR0FBRyxDQUFDRCxRQUFRLENBQUM7SUFDNUIsT0FBTyxNQUFNO01BQ1gsSUFBSSxDQUFDSixTQUFTLENBQUNNLE1BQU0sQ0FBQ0YsUUFBUSxDQUFDO0lBQ2pDLENBQUM7RUFDSCxDQUFDO0VBRU9HLElBQUlBLENBQUEsRUFBRztJQUNiLEtBQUssTUFBTUMsQ0FBQyxJQUFJLElBQUksQ0FBQ1IsU0FBUyxFQUFFUSxDQUFDLENBQUMsQ0FBQztFQUNyQzs7RUFFQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNFQyxXQUFXQSxDQUFDQyxTQUFtQixFQUFRO0lBQ3JDLE1BQU1DLElBQUksR0FBRyxJQUFJMUIsR0FBRyxDQUFDeUIsU0FBUyxDQUFDO0lBQy9CLElBQUlDLElBQUksQ0FBQ0MsSUFBSSxLQUFLLElBQUksQ0FBQ2IsS0FBSyxDQUFDYSxJQUFJLElBQUksQ0FBQyxHQUFHRCxJQUFJLENBQUMsQ0FBQ0UsS0FBSyxDQUFFQyxDQUFDLElBQUssSUFBSSxDQUFDZixLQUFLLENBQUNnQixHQUFHLENBQUNELENBQUMsQ0FBQyxDQUFDLEVBQUU7O0lBRWhGO0lBQ0EsS0FBSyxNQUFNRSxJQUFJLElBQUksSUFBSSxDQUFDakIsS0FBSyxFQUFFO01BQzdCLElBQUlZLElBQUksQ0FBQ0ksR0FBRyxDQUFDQyxJQUFJLENBQUMsRUFBRTtNQUNwQixJQUFJLENBQUNDLFVBQVUsQ0FBQ0QsSUFBSSxDQUFDO0lBQ3ZCO0lBQ0E7SUFDQSxLQUFLLE1BQU1GLENBQUMsSUFBSUgsSUFBSSxFQUFFLElBQUksQ0FBQzNCLFFBQVEsQ0FBQ3FCLEdBQUcsQ0FBQ1MsQ0FBQyxDQUFDO0lBQzFDLElBQUksQ0FBQ2YsS0FBSyxHQUFHWSxJQUFJO0VBQ25COztFQUVBO0FBQ0Y7RUFDVU0sVUFBVUEsQ0FBQ0MsSUFBWSxFQUFFO0lBQy9CLE1BQU1DLEtBQUssR0FBSUwsQ0FBUyxJQUFLQSxDQUFDLEtBQUtJLElBQUksSUFBSUosQ0FBQyxDQUFDTSxVQUFVLENBQUNGLElBQUksR0FBRyxHQUFHLENBQUMsSUFBSUosQ0FBQyxDQUFDTSxVQUFVLENBQUNGLElBQUksQ0FBQ0csT0FBTyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsR0FBRyxHQUFHLENBQUM7SUFDbkgsS0FBSyxNQUFNUCxDQUFDLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQzlCLFFBQVEsQ0FBQyxFQUFFLElBQUltQyxLQUFLLENBQUNMLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQzlCLFFBQVEsQ0FBQ3NCLE1BQU0sQ0FBQ1EsQ0FBQyxDQUFDO0lBQ3pFLEtBQUssTUFBTUEsQ0FBQyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUM1QixPQUFPLENBQUNvQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsSUFBSUgsS0FBSyxDQUFDTCxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUM1QixPQUFPLENBQUNvQixNQUFNLENBQUNRLENBQUMsQ0FBQztJQUM5RSxLQUFLLE1BQU1BLENBQUMsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDMUIsT0FBTyxDQUFDLEVBQUUsSUFBSStCLEtBQUssQ0FBQ0wsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDMUIsT0FBTyxDQUFDa0IsTUFBTSxDQUFDUSxDQUFDLENBQUM7SUFDdkUsS0FBSyxNQUFNQSxDQUFDLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQ3JCLE9BQU8sQ0FBQyxFQUFFLElBQUkwQixLQUFLLENBQUNMLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQ3JCLE9BQU8sQ0FBQ2EsTUFBTSxDQUFDUSxDQUFDLENBQUM7SUFDdkUsSUFBSSxJQUFJLENBQUN4QixRQUFRLElBQUk2QixLQUFLLENBQUMsSUFBSSxDQUFDN0IsUUFBUSxDQUFDLEVBQUU7TUFDekMsSUFBSSxDQUFDQSxRQUFRLEdBQUcsSUFBSTtNQUNwQixJQUFJLENBQUNDLGFBQWEsR0FBRyxLQUFLO01BQzFCLElBQUksQ0FBQ0MsbUJBQW1CLEdBQUcsSUFBSTtJQUNqQztJQUNBLElBQUksSUFBSSxDQUFDRSxPQUFPLElBQUl5QixLQUFLLENBQUMsSUFBSSxDQUFDekIsT0FBTyxDQUFDLEVBQUUsSUFBSSxDQUFDQSxPQUFPLEdBQUcsSUFBSTtJQUM1RCxJQUFJNkIsT0FBTyxHQUFHLEtBQUs7SUFDbkIsS0FBSyxNQUFNVCxDQUFDLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQ25CLFNBQVMsQ0FBQyxFQUFFO01BQ25DLElBQUl3QixLQUFLLENBQUNMLENBQUMsQ0FBQyxFQUFFO1FBQ1osSUFBSSxDQUFDbkIsU0FBUyxDQUFDVyxNQUFNLENBQUNRLENBQUMsQ0FBQztRQUN4QlMsT0FBTyxHQUFHLElBQUk7TUFDaEI7SUFDRjtJQUNBLElBQUlBLE9BQU8sRUFBRSxJQUFJLENBQUNDLHdCQUF3QixDQUFDLENBQUM7RUFDOUM7O0VBRUE7RUFDQUMsVUFBVSxHQUFJWCxDQUFTLElBQWMsSUFBSSxDQUFDOUIsUUFBUSxDQUFDK0IsR0FBRyxDQUFDRCxDQUFDLENBQUM7RUFDekRZLFVBQVUsR0FBSVosQ0FBUyxJQUFjLElBQUksQ0FBQ3hCLFFBQVEsS0FBS3dCLENBQUM7RUFDeERhLFNBQVMsR0FBSWIsQ0FBUyxJQUFjLElBQUksQ0FBQzFCLE9BQU8sQ0FBQzJCLEdBQUcsQ0FBQ0QsQ0FBQyxDQUFDO0VBQ3ZEYyxVQUFVLEdBQUlkLENBQVMsSUFBNkIsSUFBSSxDQUFDNUIsT0FBTyxDQUFDMkMsR0FBRyxDQUFDZixDQUFDLENBQUM7RUFDdkU7RUFDQWdCLFdBQVcsR0FBR0EsQ0FBQSxLQUFxQixJQUFJLENBQUN4QyxRQUFRO0VBQ2hEO0FBQ0Y7QUFDQTtFQUNFeUMsY0FBYyxHQUFHQSxDQUFBLEtBQStDLElBQUksQ0FBQ3ZDLG1CQUFtQjtFQUN4RjtBQUNGO0VBQ0V3QyxhQUFhLEdBQUlsQixDQUFTLElBQWMsSUFBSSxDQUFDbkIsU0FBUyxDQUFDb0IsR0FBRyxDQUFDRCxDQUFDLENBQUM7RUFDN0Q7QUFDRjtBQUNBO0VBQ0VtQixZQUFZLEdBQUdBLENBQUEsS0FBZ0IsSUFBSSxDQUFDckMsaUJBQWlCO0VBQ3JEO0FBQ0Y7QUFDQTtFQUNFc0MsUUFBUSxHQUFJQyxPQUFlLElBQWMsSUFBSSxDQUFDdEMsVUFBVSxLQUFLc0MsT0FBTztFQUNwRTtFQUNBQyxhQUFhLEdBQUdBLENBQUEsS0FBcUIsSUFBSSxDQUFDdkMsVUFBVTtFQUNwRDtBQUNGO0VBQ0V3QyxRQUFRLEdBQUlGLE9BQWUsSUFBYyxJQUFJLENBQUNyQyxVQUFVLEtBQUtxQyxPQUFPO0VBQ3BFO0VBQ0FHLGFBQWEsR0FBR0EsQ0FBQSxLQUFxQixJQUFJLENBQUN4QyxVQUFVO0VBQ3BEO0VBQ0F5QyxTQUFTLEdBQUl6QixDQUFTLElBQWMsSUFBSSxDQUFDckIsT0FBTyxDQUFDc0IsR0FBRyxDQUFDRCxDQUFDLENBQUM7RUFDdkQ7RUFDQTBCLFVBQVUsR0FBR0EsQ0FBQSxLQUFxQixJQUFJLENBQUM5QyxPQUFPO0VBQzlDO0VBQ0ErQyxhQUFhLEdBQUlDLFFBQWdCLElBQy9CLElBQUksQ0FBQ2hELE9BQU8sS0FBSyxJQUFJLEtBQ3BCLElBQUksQ0FBQ0EsT0FBTyxLQUFLZ0QsUUFBUSxJQUFJLElBQUksQ0FBQ2hELE9BQU8sQ0FBQzBCLFVBQVUsQ0FBQ3NCLFFBQVEsR0FBRyxHQUFHLENBQUMsQ0FBQztFQUN4RTtBQUNGO0FBQ0E7QUFDQTtFQUNFQyxnQkFBZ0IsR0FBSVIsT0FBZSxJQUFjO0lBQy9DLElBQUksQ0FBQyxJQUFJLENBQUNyQyxVQUFVLEVBQUUsT0FBTyxLQUFLO0lBQ2xDLElBQUlxQyxPQUFPLEtBQUssR0FBRyxFQUFFLE9BQU8sSUFBSTtJQUNoQyxPQUFPLElBQUksQ0FBQ3JDLFVBQVUsQ0FBQ3NCLFVBQVUsQ0FBQ2UsT0FBTyxHQUFHLEdBQUcsQ0FBQztFQUNsRCxDQUFDO0VBQ0Q7QUFDRjtBQUNBO0FBQ0E7RUFDRVMsZ0JBQWdCLEdBQUlULE9BQWUsSUFBYztJQUMvQyxJQUFJLENBQUMsSUFBSSxDQUFDdEMsVUFBVSxFQUFFLE9BQU8sS0FBSztJQUNsQyxJQUFJc0MsT0FBTyxLQUFLLEdBQUcsRUFBRSxPQUFPLElBQUk7SUFDaEMsT0FBTyxJQUFJLENBQUN0QyxVQUFVLENBQUN1QixVQUFVLENBQUNlLE9BQU8sR0FBRyxHQUFHLENBQUM7RUFDbEQsQ0FBQzs7RUFFRDtFQUNBVSxNQUFNLEdBQUkvQixDQUFTLElBQVc7SUFDNUIsSUFBSSxJQUFJLENBQUM5QixRQUFRLENBQUMrQixHQUFHLENBQUNELENBQUMsQ0FBQyxFQUFFO01BQ3hCLElBQUksQ0FBQzlCLFFBQVEsQ0FBQ3NCLE1BQU0sQ0FBQ1EsQ0FBQyxDQUFDO01BQ3ZCO01BQ0E7TUFDQSxJQUFJLElBQUksQ0FBQ3BCLE9BQU8sS0FBSyxJQUFJLElBQUksSUFBSSxDQUFDQSxPQUFPLEtBQUtvQixDQUFDLElBQUksSUFBSSxDQUFDcEIsT0FBTyxDQUFDMEIsVUFBVSxDQUFDTixDQUFDLEdBQUcsR0FBRyxDQUFDLEVBQUU7UUFDbkYsSUFBSSxDQUFDcEIsT0FBTyxHQUFHb0IsQ0FBQztNQUNsQjtJQUNGLENBQUMsTUFBTTtNQUNMLElBQUksQ0FBQzlCLFFBQVEsQ0FBQ3FCLEdBQUcsQ0FBQ1MsQ0FBQyxDQUFDO0lBQ3RCO0lBQ0EsSUFBSSxDQUFDUCxJQUFJLENBQUMsQ0FBQztFQUNiLENBQUM7O0VBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtFQUNFdUMsVUFBVSxHQUFJQyxJQUFZLElBQVc7SUFDbkMsTUFBTUMsSUFBSSxHQUFHRCxJQUFJLENBQUNFLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQ0MsTUFBTSxDQUFDQyxPQUFPLENBQUM7SUFDNUNILElBQUksQ0FBQ0ksR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ1osSUFBSUMsT0FBTyxHQUFHLEtBQUs7SUFDbkIsS0FBSyxNQUFNbkMsSUFBSSxJQUFJLElBQUksQ0FBQ25CLEtBQUssRUFBRTtNQUM3QixJQUFJZSxDQUFDLEdBQUdJLElBQUk7TUFDWixLQUFLLE1BQU1vQyxHQUFHLElBQUlOLElBQUksRUFBRTtRQUN0QmxDLENBQUMsR0FBRyxHQUFHQSxDQUFDLElBQUl3QyxHQUFHLEVBQUU7UUFDakIsSUFBSSxDQUFDLElBQUksQ0FBQ3RFLFFBQVEsQ0FBQytCLEdBQUcsQ0FBQ0QsQ0FBQyxDQUFDLEVBQUU7VUFDekIsSUFBSSxDQUFDOUIsUUFBUSxDQUFDcUIsR0FBRyxDQUFDUyxDQUFDLENBQUM7VUFDcEJ1QyxPQUFPLEdBQUcsSUFBSTtRQUNoQjtNQUNGO0lBQ0Y7SUFDQSxJQUFJQSxPQUFPLEVBQUUsSUFBSSxDQUFDOUMsSUFBSSxDQUFDLENBQUM7RUFDMUIsQ0FBQzs7RUFFRDtFQUNBZ0QsSUFBSSxHQUFJekMsQ0FBUyxJQUFXO0lBQzFCLElBQUksSUFBSSxDQUFDOUIsUUFBUSxDQUFDK0IsR0FBRyxDQUFDRCxDQUFDLENBQUMsRUFBRTtJQUMxQixJQUFJLENBQUM5QixRQUFRLENBQUNxQixHQUFHLENBQUNTLENBQUMsQ0FBQztJQUNwQixJQUFJLENBQUNQLElBQUksQ0FBQyxDQUFDO0VBQ2IsQ0FBQzs7RUFFRDtBQUNGO0FBQ0E7RUFDRWlELE1BQU0sR0FBR0EsQ0FBQzFDLENBQVMsRUFBRTJDLEtBQUssR0FBRyxLQUFLLEtBQVc7SUFDM0MsSUFBSSxJQUFJLENBQUNuRSxRQUFRLEtBQUt3QixDQUFDLElBQUksSUFBSSxDQUFDdkIsYUFBYSxLQUFLa0UsS0FBSyxFQUFFO0lBQ3pELElBQUksQ0FBQ25FLFFBQVEsR0FBR3dCLENBQUM7SUFDakIsSUFBSSxDQUFDdkIsYUFBYSxHQUFHa0UsS0FBSztJQUMxQixJQUFJLENBQUNqRSxtQkFBbUIsR0FBRztNQUFFdUQsSUFBSSxFQUFFakMsQ0FBQztNQUFFMkM7SUFBTSxDQUFDO0lBQzdDLElBQUksQ0FBQ2xELElBQUksQ0FBQyxDQUFDO0VBQ2IsQ0FBQzs7RUFFRDtFQUNBbUQsUUFBUSxHQUFJNUMsQ0FBZ0IsSUFBVztJQUNyQyxJQUFJLElBQUksQ0FBQ3BCLE9BQU8sS0FBS29CLENBQUMsRUFBRTtJQUN4QixJQUFJLENBQUNwQixPQUFPLEdBQUdvQixDQUFDO0lBQ2hCLElBQUksQ0FBQ1AsSUFBSSxDQUFDLENBQUM7RUFDYixDQUFDOztFQUVEO0VBQ0E7RUFDQTtFQUNBOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0VBQ1VvRCxZQUFZLEdBQUdBLENBQUNDLEdBQVcsRUFBRUMsS0FBZSxFQUFFQyxTQUFrQixLQUFXO0lBQ2pGLE1BQU1DLElBQUksR0FBRyxJQUFJLENBQUM3RSxPQUFPLENBQUMyQyxHQUFHLENBQUMrQixHQUFHLENBQUM7SUFDbEMsSUFBSSxDQUFDRyxJQUFJLEVBQUU7SUFDWCxNQUFNcEQsSUFBSSxHQUFHLENBQUMsR0FBR29ELElBQUksQ0FBQztJQUN0QixJQUFJQyxDQUFDLEdBQUdyRCxJQUFJLENBQUNzRCxTQUFTLENBQUVDLENBQUMsSUFBSyxJQUFBQyx5QkFBYyxFQUFDTixLQUFLLEVBQUVLLENBQUMsRUFBRSxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDbkUsSUFBSUYsQ0FBQyxHQUFHLENBQUMsRUFBRUEsQ0FBQyxHQUFHckQsSUFBSSxDQUFDeUQsTUFBTTtJQUMxQnpELElBQUksQ0FBQzBELE1BQU0sQ0FBQ0wsQ0FBQyxFQUFFLENBQUMsRUFBRUgsS0FBSyxDQUFDO0lBQ3hCLElBQUksQ0FBQzNFLE9BQU8sQ0FBQ29GLEdBQUcsQ0FBQ1YsR0FBRyxFQUFFakQsSUFBSSxDQUFDO0lBQzNCLElBQUltRCxTQUFTLEVBQUUsSUFBSSxDQUFDckUsT0FBTyxDQUFDWSxHQUFHLENBQUMsR0FBR3VELEdBQUcsSUFBSUMsS0FBSyxDQUFDVSxJQUFJLEVBQUUsQ0FBQztJQUN2RCxJQUFJLENBQUNoRSxJQUFJLENBQUMsQ0FBQztFQUNiLENBQUM7O0VBRUQ7QUFDRjtBQUNBO0VBQ0VpRSxhQUFhLEdBQUdBLENBQUNaLEdBQVcsRUFBRUMsS0FBZSxLQUFXO0lBQ3RELElBQUksQ0FBQ0YsWUFBWSxDQUFDQyxHQUFHLEVBQUVDLEtBQUssRUFBRSxJQUFJLENBQUM7RUFDckMsQ0FBQzs7RUFFRDtFQUNBWSxXQUFXLEdBQUdBLENBQUNiLEdBQVcsRUFBRUMsS0FBZSxLQUFXO0lBQ3BELElBQUksQ0FBQ0YsWUFBWSxDQUFDQyxHQUFHLEVBQUVDLEtBQUssRUFBRSxLQUFLLENBQUM7RUFDdEMsQ0FBQzs7RUFFRDtBQUNGO0VBQ0VhLFdBQVcsR0FBR0EsQ0FBQ2QsR0FBVyxFQUFFZSxXQUFtQixFQUFFZCxLQUFlLEtBQVc7SUFDekUsTUFBTUUsSUFBSSxHQUFHLElBQUksQ0FBQzdFLE9BQU8sQ0FBQzJDLEdBQUcsQ0FBQytCLEdBQUcsQ0FBQztJQUNsQyxJQUFJLENBQUNuRSxPQUFPLENBQUNhLE1BQU0sQ0FBQyxHQUFHc0QsR0FBRyxJQUFJZSxXQUFXLEVBQUUsQ0FBQztJQUM1QyxJQUFJLENBQUNaLElBQUksRUFBRTtJQUNYLE1BQU1DLENBQUMsR0FBR0QsSUFBSSxDQUFDRSxTQUFTLENBQUVDLENBQUMsSUFBS0EsQ0FBQyxDQUFDSyxJQUFJLEtBQUtJLFdBQVcsQ0FBQztJQUN2RCxJQUFJWCxDQUFDLEdBQUcsQ0FBQyxFQUFFO0lBQ1gsTUFBTXJELElBQUksR0FBRyxDQUFDLEdBQUdvRCxJQUFJLENBQUM7SUFDdEJwRCxJQUFJLENBQUNxRCxDQUFDLENBQUMsR0FBR0gsS0FBSztJQUNmO0lBQ0FsRCxJQUFJLENBQUNpRSxJQUFJLENBQUMsQ0FBQ0MsQ0FBQyxFQUFFQyxDQUFDLEtBQUssSUFBQVgseUJBQWMsRUFBQ1UsQ0FBQyxFQUFFQyxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUM7SUFDakQsSUFBSSxDQUFDNUYsT0FBTyxDQUFDb0YsR0FBRyxDQUFDVixHQUFHLEVBQUVqRCxJQUFJLENBQUM7SUFDM0IsSUFBSSxDQUFDSixJQUFJLENBQUMsQ0FBQztFQUNiLENBQUM7O0VBRUQ7QUFDRjtFQUNFd0UsV0FBVyxHQUFHQSxDQUFDbkIsR0FBVyxFQUFFVyxJQUFZLEtBQVc7SUFDakQsTUFBTXZELElBQUksR0FBRyxHQUFHNEMsR0FBRyxJQUFJVyxJQUFJLEVBQUU7SUFDN0IsTUFBTVIsSUFBSSxHQUFHLElBQUksQ0FBQzdFLE9BQU8sQ0FBQzJDLEdBQUcsQ0FBQytCLEdBQUcsQ0FBQztJQUNsQyxJQUFJLENBQUNuRSxPQUFPLENBQUNhLE1BQU0sQ0FBQ1UsSUFBSSxDQUFDO0lBQ3pCLElBQUksSUFBSSxDQUFDdEIsT0FBTyxLQUFLc0IsSUFBSSxFQUFFLElBQUksQ0FBQ3RCLE9BQU8sR0FBRyxJQUFJO0lBQzlDLElBQUksQ0FBQ3FFLElBQUksRUFBRTtJQUNYLE1BQU1DLENBQUMsR0FBR0QsSUFBSSxDQUFDRSxTQUFTLENBQUVDLENBQUMsSUFBS0EsQ0FBQyxDQUFDSyxJQUFJLEtBQUtBLElBQUksQ0FBQztJQUNoRCxJQUFJUCxDQUFDLEdBQUcsQ0FBQyxFQUFFO0lBQ1gsTUFBTXJELElBQUksR0FBRyxDQUFDLEdBQUdvRCxJQUFJLENBQUM7SUFDdEJwRCxJQUFJLENBQUMwRCxNQUFNLENBQUNMLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDakIsSUFBSSxDQUFDOUUsT0FBTyxDQUFDb0YsR0FBRyxDQUFDVixHQUFHLEVBQUVqRCxJQUFJLENBQUM7SUFDM0IsSUFBSSxDQUFDSixJQUFJLENBQUMsQ0FBQztFQUNiLENBQUM7O0VBRUQ7RUFDUWlCLHdCQUF3QkEsQ0FBQSxFQUFHO0lBQ2pDLElBQUksQ0FBQzVCLGlCQUFpQixHQUFHLENBQUMsR0FBRyxJQUFJLENBQUNELFNBQVMsQ0FBQztFQUM5Qzs7RUFFQTtFQUNBcUYsaUJBQWlCLEdBQUlsRSxDQUFTLElBQVc7SUFDdkMsSUFBSSxJQUFJLENBQUNuQixTQUFTLENBQUNvQixHQUFHLENBQUNELENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQ25CLFNBQVMsQ0FBQ1csTUFBTSxDQUFDUSxDQUFDLENBQUMsQ0FBQyxLQUMvQyxJQUFJLENBQUNuQixTQUFTLENBQUNVLEdBQUcsQ0FBQ1MsQ0FBQyxDQUFDO0lBQzFCLElBQUksQ0FBQ1Usd0JBQXdCLENBQUMsQ0FBQztJQUMvQixJQUFJLENBQUNqQixJQUFJLENBQUMsQ0FBQztFQUNiLENBQUM7O0VBRUQ7RUFDQTBFLGNBQWMsR0FBR0EsQ0FBQSxLQUFZO0lBQzNCLElBQUksSUFBSSxDQUFDdEYsU0FBUyxDQUFDaUIsSUFBSSxLQUFLLENBQUMsRUFBRTtJQUMvQixJQUFJLENBQUNqQixTQUFTLENBQUN1RixLQUFLLENBQUMsQ0FBQztJQUN0QixJQUFJLENBQUMxRCx3QkFBd0IsQ0FBQyxDQUFDO0lBQy9CLElBQUksQ0FBQ2pCLElBQUksQ0FBQyxDQUFDO0VBQ2IsQ0FBQzs7RUFFRDtBQUNGO0VBQ0U0RSxhQUFhLEdBQUl4RSxJQUFtQixJQUFXO0lBQzdDLElBQUksSUFBSSxDQUFDZCxVQUFVLEtBQUtjLElBQUksRUFBRTtJQUM5QixJQUFJLENBQUNkLFVBQVUsR0FBR2MsSUFBSTtJQUN0QixJQUFJLENBQUNKLElBQUksQ0FBQyxDQUFDO0VBQ2IsQ0FBQzs7RUFFRDtBQUNGO0VBQ0U2RSxhQUFhLEdBQUl6RSxJQUFtQixJQUFXO0lBQzdDLElBQUksSUFBSSxDQUFDYixVQUFVLEtBQUthLElBQUksRUFBRTtJQUM5QixJQUFJLENBQUNiLFVBQVUsR0FBR2EsSUFBSTtJQUN0QixJQUFJLENBQUNKLElBQUksQ0FBQyxDQUFDO0VBQ2IsQ0FBQzs7RUFFRDtFQUNBOEUsV0FBVyxHQUFHQSxDQUFBLEtBQVk7SUFDeEIsSUFBSSxDQUFDckcsUUFBUSxHQUFHLElBQUlDLEdBQUcsQ0FBQyxJQUFJLENBQUNjLEtBQUssQ0FBQztJQUNuQyxJQUFJLENBQUNRLElBQUksQ0FBQyxDQUFDO0VBQ2IsQ0FBQzs7RUFFRDtFQUNBK0UsWUFBWSxHQUFJeEUsQ0FBUyxJQUFXO0lBQ2xDLElBQUksSUFBSSxDQUFDNUIsT0FBTyxDQUFDNkIsR0FBRyxDQUFDRCxDQUFDLENBQUMsSUFBSSxJQUFJLENBQUMxQixPQUFPLENBQUMyQixHQUFHLENBQUNELENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQ3pCLFFBQVEsQ0FBQzBCLEdBQUcsQ0FBQ0QsQ0FBQyxDQUFDLEVBQUU7SUFDeEUsSUFBSSxDQUFDekIsUUFBUSxDQUFDZ0IsR0FBRyxDQUFDUyxDQUFDLENBQUM7SUFDcEIsS0FBSyxJQUFJLENBQUNaLEVBQUUsQ0FBQ3FGLE9BQU8sQ0FBQ3pFLENBQUMsQ0FBQyxDQUFDMEUsSUFBSSxDQUN6QnpCLElBQUksSUFBSztNQUNSLElBQUksQ0FBQzFFLFFBQVEsQ0FBQ2lCLE1BQU0sQ0FBQ1EsQ0FBQyxDQUFDO01BQ3ZCLElBQUksQ0FBQzVCLE9BQU8sQ0FBQ29GLEdBQUcsQ0FBQ3hELENBQUMsRUFBRWlELElBQUksQ0FBQztNQUN6QixJQUFJLENBQUMzRSxPQUFPLENBQUNrQixNQUFNLENBQUNRLENBQUMsQ0FBQztNQUN0QixJQUFJLENBQUNQLElBQUksQ0FBQyxDQUFDO0lBQ2IsQ0FBQyxFQUNELE1BQU07TUFDSixJQUFJLENBQUNsQixRQUFRLENBQUNpQixNQUFNLENBQUNRLENBQUMsQ0FBQztNQUN2QixJQUFJLENBQUMxQixPQUFPLENBQUNpQixHQUFHLENBQUNTLENBQUMsQ0FBQztNQUNuQixJQUFJLENBQUNQLElBQUksQ0FBQyxDQUFDO0lBQ2IsQ0FDRixDQUFDO0VBQ0gsQ0FBQzs7RUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNFa0YsT0FBTyxHQUFHQSxDQUFBLEtBQVk7SUFDcEIsS0FBSyxNQUFNM0UsQ0FBQyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUM5QixRQUFRLENBQUMsRUFBRTtNQUNsQyxLQUFLLElBQUksQ0FBQ2tCLEVBQUUsQ0FBQ3FGLE9BQU8sQ0FBQ3pFLENBQUMsQ0FBQyxDQUFDMEUsSUFBSSxDQUN6QnpCLElBQUksSUFBSztRQUNSLElBQUksQ0FBQzdFLE9BQU8sQ0FBQ29GLEdBQUcsQ0FBQ3hELENBQUMsRUFBRWlELElBQUksQ0FBQztRQUN6QixJQUFJLENBQUMzRSxPQUFPLENBQUNrQixNQUFNLENBQUNRLENBQUMsQ0FBQztRQUN0QixJQUFJLENBQUNQLElBQUksQ0FBQyxDQUFDO01BQ2IsQ0FBQyxFQUNELE1BQU07UUFDSixJQUFJLENBQUNuQixPQUFPLENBQUNpQixHQUFHLENBQUNTLENBQUMsQ0FBQztRQUNuQixJQUFJLENBQUNQLElBQUksQ0FBQyxDQUFDO01BQ2IsQ0FDRixDQUFDO0lBQ0g7RUFDRixDQUFDOztFQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDRW1GLFVBQVUsR0FBSTVFLENBQVMsSUFBVztJQUNoQyxLQUFLLElBQUksQ0FBQ1osRUFBRSxDQUFDcUYsT0FBTyxDQUFDekUsQ0FBQyxDQUFDLENBQUMwRSxJQUFJLENBQ3pCekIsSUFBSSxJQUFLO01BQ1I7TUFDQTtNQUNBO01BQ0EsTUFBTTRCLE1BQU0sR0FBRyxJQUFJLENBQUN6RyxPQUFPLENBQUMyQyxHQUFHLENBQUNmLENBQUMsQ0FBQztNQUNsQyxJQUFJSCxJQUFJLEdBQUdvRCxJQUFJO01BQ2YsS0FBSyxNQUFNNkIsV0FBVyxJQUFJLElBQUksQ0FBQ25HLE9BQU8sRUFBRTtRQUN0QyxJQUFJLENBQUNtRyxXQUFXLENBQUN4RSxVQUFVLENBQUNOLENBQUMsR0FBRyxHQUFHLENBQUMsRUFBRTtRQUN0QyxNQUFNeUQsSUFBSSxHQUFHcUIsV0FBVyxDQUFDQyxLQUFLLENBQUMvRSxDQUFDLENBQUNzRCxNQUFNLEdBQUcsQ0FBQyxDQUFDO1FBQzVDLElBQUl6RCxJQUFJLENBQUNtRixJQUFJLENBQUU1QixDQUFDLElBQUtBLENBQUMsQ0FBQ0ssSUFBSSxLQUFLQSxJQUFJLENBQUMsRUFBRTtRQUN2QyxNQUFNd0IsWUFBWSxHQUFHSixNQUFNLEVBQUVLLElBQUksQ0FBRTlCLENBQUMsSUFBS0EsQ0FBQyxDQUFDSyxJQUFJLEtBQUtBLElBQUksQ0FBQztRQUN6RCxJQUFJLENBQUN3QixZQUFZLEVBQUU7UUFDbkIsSUFBSXBGLElBQUksS0FBS29ELElBQUksRUFBRXBELElBQUksR0FBRyxDQUFDLEdBQUdvRCxJQUFJLENBQUM7UUFDbkMsSUFBSUMsQ0FBQyxHQUFHckQsSUFBSSxDQUFDc0QsU0FBUyxDQUFFQyxDQUFDLElBQUssSUFBQUMseUJBQWMsRUFBQzRCLFlBQVksRUFBRTdCLENBQUMsRUFBRSxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDMUUsSUFBSUYsQ0FBQyxHQUFHLENBQUMsRUFBRUEsQ0FBQyxHQUFHckQsSUFBSSxDQUFDeUQsTUFBTTtRQUMxQnpELElBQUksQ0FBQzBELE1BQU0sQ0FBQ0wsQ0FBQyxFQUFFLENBQUMsRUFBRStCLFlBQVksQ0FBQztNQUNqQztNQUNBLElBQUksQ0FBQzdHLE9BQU8sQ0FBQ29GLEdBQUcsQ0FBQ3hELENBQUMsRUFBRUgsSUFBSSxDQUFDO01BQ3pCLElBQUksQ0FBQ3ZCLE9BQU8sQ0FBQ2tCLE1BQU0sQ0FBQ1EsQ0FBQyxDQUFDO01BQ3RCLElBQUksQ0FBQ1AsSUFBSSxDQUFDLENBQUM7SUFDYixDQUFDLEVBQ0QsTUFBTTtNQUNKLElBQUksQ0FBQ25CLE9BQU8sQ0FBQ2lCLEdBQUcsQ0FBQ1MsQ0FBQyxDQUFDO01BQ25CLElBQUksQ0FBQ1AsSUFBSSxDQUFDLENBQUM7SUFDYixDQUNGLENBQUM7RUFDSCxDQUFDO0FBQ0g7O0FBRUE7QUFBQTBGLE9BQUEsQ0FBQWxILFNBQUEsR0FBQUEsU0FBQTtBQUNPLFNBQVNtSCxPQUFPQSxDQUNyQkMsS0FBZ0IsRUFDaEJwRCxJQUFZLEVBQ2lGO0VBQzdGLE1BQU0vRCxRQUFRLEdBQUcsSUFBQW9ILDJCQUFvQixFQUFDRCxLQUFLLENBQUNoRyxTQUFTLEVBQUUsTUFBTWdHLEtBQUssQ0FBQzFFLFVBQVUsQ0FBQ3NCLElBQUksQ0FBQyxDQUFDO0VBQ3BGLE1BQU16RCxRQUFRLEdBQUcsSUFBQThHLDJCQUFvQixFQUFDRCxLQUFLLENBQUNoRyxTQUFTLEVBQUUsTUFBTWdHLEtBQUssQ0FBQ3pFLFVBQVUsQ0FBQ3FCLElBQUksQ0FBQyxDQUFDO0VBQ3BGLE1BQU0zRCxPQUFPLEdBQUcsSUFBQWdILDJCQUFvQixFQUFDRCxLQUFLLENBQUNoRyxTQUFTLEVBQUUsTUFBTWdHLEtBQUssQ0FBQ3hFLFNBQVMsQ0FBQ29CLElBQUksQ0FBQyxDQUFDO0VBQ2xGLE1BQU03RCxPQUFPLEdBQUcsSUFBQWtILDJCQUFvQixFQUFDRCxLQUFLLENBQUNoRyxTQUFTLEVBQUUsTUFBTWdHLEtBQUssQ0FBQ3ZFLFVBQVUsQ0FBQ21CLElBQUksQ0FBQyxDQUFDO0VBQ25GLE9BQU87SUFBRS9ELFFBQVE7SUFBRU0sUUFBUTtJQUFFRixPQUFPO0lBQUVGO0VBQVEsQ0FBQztBQUNqRDs7QUFFQTtBQUNPLFNBQVNtSCxXQUFXQSxDQUFDRixLQUFnQixFQUFpQjtFQUMzRCxPQUFPLElBQUFDLDJCQUFvQixFQUFDRCxLQUFLLENBQUNoRyxTQUFTLEVBQUVnRyxLQUFLLENBQUNyRSxXQUFXLENBQUM7QUFDakU7O0FBRUE7QUFDQTtBQUNPLFNBQVN3RSxjQUFjQSxDQUFDSCxLQUFnQixFQUEyQztFQUN4RixPQUFPLElBQUFDLDJCQUFvQixFQUFDRCxLQUFLLENBQUNoRyxTQUFTLEVBQUVnRyxLQUFLLENBQUNwRSxjQUFjLENBQUM7QUFDcEU7O0FBRUE7QUFDQTtBQUNBO0FBQ08sU0FBU3dFLGNBQWNBLENBQUNKLEtBQWdCLEVBQUVwRCxJQUFZLEVBQVc7RUFDdEUsT0FBTyxJQUFBcUQsMkJBQW9CLEVBQUNELEtBQUssQ0FBQ2hHLFNBQVMsRUFBRSxNQUFNZ0csS0FBSyxDQUFDbkUsYUFBYSxDQUFDZSxJQUFJLENBQUMsQ0FBQztBQUMvRTs7QUFFQTtBQUNBO0FBQ0E7QUFDTyxTQUFTeUQsU0FBU0EsQ0FBQ0wsS0FBZ0IsRUFBRWhFLE9BQWUsRUFBVztFQUNwRSxPQUFPLElBQUFpRSwyQkFBb0IsRUFBQ0QsS0FBSyxDQUFDaEcsU0FBUyxFQUFFLE1BQU1nRyxLQUFLLENBQUNqRSxRQUFRLENBQUNDLE9BQU8sQ0FBQyxDQUFDO0FBQzdFOztBQUVBO0FBQ0E7QUFDQTtBQUNPLFNBQVNzRSxTQUFTQSxDQUFDTixLQUFnQixFQUFFaEUsT0FBZSxFQUFXO0VBQ3BFLE9BQU8sSUFBQWlFLDJCQUFvQixFQUFDRCxLQUFLLENBQUNoRyxTQUFTLEVBQUUsTUFBTWdHLEtBQUssQ0FBQzlELFFBQVEsQ0FBQ0YsT0FBTyxDQUFDLENBQUM7QUFDN0U7O0FBRUE7QUFDQTtBQUNPLFNBQVN1RSxpQkFBaUJBLENBQUNQLEtBQWdCLEVBQUVoRSxPQUFlLEVBQVc7RUFDNUUsT0FBTyxJQUFBaUUsMkJBQW9CLEVBQUNELEtBQUssQ0FBQ2hHLFNBQVMsRUFBRSxNQUFNZ0csS0FBSyxDQUFDeEQsZ0JBQWdCLENBQUNSLE9BQU8sQ0FBQyxDQUFDO0FBQ3JGOztBQUVBO0FBQ0E7QUFDTyxTQUFTd0UsaUJBQWlCQSxDQUFDUixLQUFnQixFQUFFaEUsT0FBZSxFQUFXO0VBQzVFLE9BQU8sSUFBQWlFLDJCQUFvQixFQUFDRCxLQUFLLENBQUNoRyxTQUFTLEVBQUUsTUFBTWdHLEtBQUssQ0FBQ3ZELGdCQUFnQixDQUFDVCxPQUFPLENBQUMsQ0FBQztBQUNyRjs7QUFFQTtBQUNBO0FBQ08sU0FBU3lFLFVBQVVBLENBQUNULEtBQWdCLEVBQUVwRCxJQUFZLEVBQVc7RUFDbEUsT0FBTyxJQUFBcUQsMkJBQW9CLEVBQUNELEtBQUssQ0FBQ2hHLFNBQVMsRUFBRSxNQUFNZ0csS0FBSyxDQUFDNUQsU0FBUyxDQUFDUSxJQUFJLENBQUMsQ0FBQztBQUMzRTs7QUFFQTtBQUNPLFNBQVM4RCxVQUFVQSxDQUFDVixLQUFnQixFQUFpQjtFQUMxRCxPQUFPLElBQUFDLDJCQUFvQixFQUFDRCxLQUFLLENBQUNoRyxTQUFTLEVBQUVnRyxLQUFLLENBQUMzRCxVQUFVLENBQUM7QUFDaEU7O0FBRUE7QUFDQTtBQUNBO0FBQ08sU0FBU3NFLGFBQWFBLENBQUNYLEtBQWdCLEVBQUVwRCxJQUFZLEVBQVc7RUFDckUsT0FBTyxJQUFBcUQsMkJBQW9CLEVBQUNELEtBQUssQ0FBQ2hHLFNBQVMsRUFBRSxNQUFNZ0csS0FBSyxDQUFDM0QsVUFBVSxDQUFDLENBQUMsS0FBS08sSUFBSSxDQUFDO0FBQ2pGOztBQUVBO0FBQ0E7QUFDTyxTQUFTZ0UsZ0JBQWdCQSxDQUFDWixLQUFnQixFQUFFekQsUUFBZ0IsRUFBVztFQUM1RSxPQUFPLElBQUEwRCwyQkFBb0IsRUFBQ0QsS0FBSyxDQUFDaEcsU0FBUyxFQUFFLE1BQU0sQ0FBQ2dHLEtBQUssQ0FBQzFELGFBQWEsQ0FBQ0MsUUFBUSxDQUFDLENBQUM7QUFDcEY7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVNzRSxNQUFNQSxDQUNwQmIsS0FBZ0IsRUFDaEJwRCxJQUFtQixFQUNvQztFQUN2RCxNQUFNN0QsT0FBTyxHQUFHLElBQUFrSCwyQkFBb0IsRUFBQ0QsS0FBSyxDQUFDaEcsU0FBUyxFQUFFLE1BQ3BENEMsSUFBSSxHQUFHb0QsS0FBSyxDQUFDdkUsVUFBVSxDQUFDbUIsSUFBSSxDQUFDLEdBQUdrRSxTQUNsQyxDQUFDO0VBQ0QsTUFBTTdILE9BQU8sR0FBRyxJQUFBZ0gsMkJBQW9CLEVBQUNELEtBQUssQ0FBQ2hHLFNBQVMsRUFBRSxNQUNwRDRDLElBQUksR0FBR29ELEtBQUssQ0FBQ3hFLFNBQVMsQ0FBQ29CLElBQUksQ0FBQyxHQUFHLEtBQ2pDLENBQUM7RUFDRCxJQUFBbUUsZ0JBQVMsRUFBQyxNQUFNO0lBQ2QsSUFBSW5FLElBQUksSUFBSTdELE9BQU8sS0FBSytILFNBQVMsSUFBSSxDQUFDN0gsT0FBTyxFQUFFK0csS0FBSyxDQUFDYixZQUFZLENBQUN2QyxJQUFJLENBQUM7RUFDekUsQ0FBQyxFQUFFLENBQUNvRCxLQUFLLEVBQUVwRCxJQUFJLEVBQUU3RCxPQUFPLEVBQUVFLE9BQU8sQ0FBQyxDQUFDO0VBQ25DLE9BQU87SUFBRUYsT0FBTztJQUFFRTtFQUFRLENBQUM7QUFDN0IiLCJpZ25vcmVMaXN0IjpbXX0=