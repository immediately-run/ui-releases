"use strict";

var _opensWith = require("./opensWith");
const policy = {
  offerable: ["open-wiki", "open-project"]
};
const marker = o => JSON.stringify(o);
describe("parseOpensWith — an untrusted marker never throws", () => {
  it("names the marker file the specs name", () => {
    expect(_opensWith.CONTENT_MARKER_FILE).toBe("immediately.run.json");
  });
  it("reads the task and defaults the version to the v1 shape", () => {
    expect((0, _opensWith.parseOpensWith)(marker({
      opensWith: {
        task: "open-wiki"
      },
      kind: "wiki"
    }))).toEqual({
      task: "open-wiki",
      version: "1.0",
      kind: "wiki"
    });
  });
  it("keeps an explicit version", () => {
    expect((0, _opensWith.parseOpensWith)(marker({
      opensWith: {
        task: "open-wiki",
        version: "1.2"
      }
    }))).toMatchObject({
      version: "1.2"
    });
  });
  it.each([["empty text", ""], ["whitespace", "   "], ["invalid JSON", "{ not json"], ["a JSON scalar", '"wiki"'], ["a JSON array", "[1,2]"], ["no opensWith key", marker({
    kind: "wiki"
  })], ["opensWith not an object", marker({
    opensWith: "open-wiki"
  })], ["opensWith an array", marker({
    opensWith: ["open-wiki"]
  })], ["a non-string task", marker({
    opensWith: {
      task: 7
    }
  })], ["an empty task", marker({
    opensWith: {
      task: "  "
    }
  })]])("returns null for %s", (_why, text) => {
    expect((0, _opensWith.parseOpensWith)(text)).toBeNull();
  });
  it("an APP-form marker opens through the fixed contract, and the app it names is not returned", () => {
    // BUNDLE_EMBEDDING §4b.2 rule 2: the caller never names the app — the host reads the
    // marker at invoke time and resolves the opener itself.
    const parsed = (0, _opensWith.parseOpensWith)(marker({
      opensWith: {
        app: "github:mallory/evil",
        version: "9.9"
      },
      kind: "board"
    }));
    expect(parsed).toEqual({
      task: _opensWith.APP_FORM_CONTRACT,
      version: "1.0",
      kind: "board"
    });
    expect(_opensWith.APP_FORM_CONTRACT).toBe("open-declared");
    expect(JSON.stringify(parsed)).not.toMatch(/mallory|9\.9/);
  });
  it.each([["both forms at once (the host refuses it)", marker({
    opensWith: {
      task: "open-wiki",
      app: "github:a/b"
    }
  })], ["an empty app", marker({
    opensWith: {
      app: ""
    }
  })], ["a non-string app", marker({
    opensWith: {
      app: {
        repo: "a/b"
      }
    }
  })],
  // Each mirrors a host refusal (site-main parseContentMarker, §4b.1) — offered, it
  // would be a dead click that never withdraws.
  ["an app carrying a revision (revision-in-app)", marker({
    opensWith: {
      app: "github:a/b@main"
    },
    kind: "board"
  })], ["an app carrying a commit pin (revision-in-app)", marker({
    opensWith: {
      app: `github:a/b#${"a".repeat(40)}`
    },
    kind: "board"
  })], ["an app-form entry key (entry-in-app)", marker({
    opensWith: {
      app: "github:a/b",
      entry: "x.tsx"
    },
    kind: "board"
  })], ["an app form with no kind (missing-kind)", marker({
    opensWith: {
      app: "github:a/b"
    }
  })], ["whitespace task beside an app (the host does not trim: ambiguous-opens)", marker({
    opensWith: {
      task: " ",
      app: "github:a/b"
    },
    kind: "board"
  })], ["a task-form marker naming open-declared itself (a cycle)", marker({
    opensWith: {
      task: "open-declared"
    },
    kind: "board"
  })]])("returns null for %s", (_why, text) => {
    expect((0, _opensWith.parseOpensWith)(text)).toBeNull();
  });
  it("returns null for absent bytes (an unreadable / missing marker)", () => {
    expect((0, _opensWith.parseOpensWith)(null)).toBeNull();
    expect((0, _opensWith.parseOpensWith)(undefined)).toBeNull();
  });
});
describe("openWithLabel — the label comes from the marker's kind, never a task name", () => {
  it("uses the author's kind", () => {
    expect((0, _opensWith.openWithLabel)("wiki")).toBe("Open as wiki");
    expect((0, _opensWith.openWithLabel)("board")).toBe("Open as board");
    expect((0, _opensWith.openWithLabel)("Design System")).toBe("Open as design system");
  });
  it("falls back to a generic label when there is no kind", () => {
    expect((0, _opensWith.openWithLabel)(undefined)).toBe("Open with its app");
    expect((0, _opensWith.openWithLabel)("")).toBe("Open with its app");
  });
  it.each([["markup", "<img src=x onerror=alert(1)>"], ["a newline", "wiki\nSign in to continue"], ["a control character", "wiki"], ["a right-to-left override", "wiki‮gnp.exe"], ["an essay", "w".repeat(200)], ["a leading joiner", "-wiki"]])("refuses %s and shows the generic label instead of sanitizing it into shape", (_why, kind) => {
    expect((0, _opensWith.openWithLabel)(kind)).toBe("Open with its app");
  });
});
describe("opensWithOffer — absent affordance is the answer to every refusal", () => {
  it("offers a declared contract, labelled by the marker's kind", () => {
    const o = (0, _opensWith.opensWithOffer)(marker({
      opensWith: {
        task: "open-wiki"
      },
      kind: "wiki"
    }), policy);
    expect(o).toEqual({
      task: "open-wiki",
      version: "1.0",
      label: "Open as wiki"
    });
  });
  it("offers a SECOND contract from the same code path, with no task name in it", () => {
    const o = (0, _opensWith.opensWithOffer)(marker({
      opensWith: {
        task: "open-project"
      },
      kind: "project"
    }), policy);
    expect(o).toEqual({
      task: "open-project",
      version: "1.0",
      label: "Open as project"
    });
  });
  it("offers a declared contract even when the marker names no usable kind", () => {
    const o = (0, _opensWith.opensWithOffer)(marker({
      opensWith: {
        task: "open-wiki"
      }
    }), policy);
    expect(o).toMatchObject({
      task: "open-wiki",
      label: "Open with its app"
    });
  });
  it("a marker naming a contract this app does not invoke → no affordance, not an error", () => {
    expect((0, _opensWith.opensWithOffer)(marker({
      opensWith: {
        task: "open-hologram"
      },
      kind: "hologram"
    }), policy)).toBeNull();
  });
  it("a folder with no marker → no affordance", () => {
    expect((0, _opensWith.opensWithOffer)(null, policy)).toBeNull();
  });
  it("withdraws a contract the host has already refused this session", () => {
    const text = marker({
      opensWith: {
        task: "open-wiki"
      },
      kind: "wiki"
    });
    expect((0, _opensWith.opensWithOffer)(text, policy)).not.toBeNull();
    expect((0, _opensWith.opensWithOffer)(text, {
      ...policy,
      unavailable: new Set(["open-wiki"])
    })).toBeNull();
  });
  it("cannot be talked into offering anything when the app declares nothing", () => {
    expect((0, _opensWith.opensWithOffer)(marker({
      opensWith: {
        task: "open-wiki"
      }
    }), {
      offerable: []
    })).toBeNull();
  });
});
describe("opensInPlaceOffer — the into-stage twin (R3-159)", () => {
  const offer = {
    task: "open-project",
    version: "1.0",
    label: "Open as board"
  };
  it("offers a launch-declared contract with the FIXED product label", () => {
    expect((0, _opensWith.opensInPlaceOffer)(offer, {
      launchable: ["open-project"]
    })).toEqual({
      task: "open-project",
      version: "1.0",
      label: "Open in place"
    });
  });
  it("never lets the marker's kind reach the in-place label", () => {
    // The for-result label is author text ("Open as board"); the in-place verb is
    // the product's. A hostile kind cannot ride it.
    const hostile = {
      task: "open-project",
      version: "1.0",
      label: "Open as <img>"
    };
    expect((0, _opensWith.opensInPlaceOffer)(hostile, {
      launchable: ["open-project"]
    })?.label).toBe("Open in place");
  });
  it("offers nothing for a contract the app may only INVOKE, never launch", () => {
    const wiki = {
      task: "open-wiki",
      version: "1.0",
      label: "Open as wiki"
    };
    expect((0, _opensWith.opensInPlaceOffer)(wiki, {
      launchable: ["open-project"]
    })).toBeNull();
  });
  it("offers nothing when there is no offer to twin", () => {
    expect((0, _opensWith.opensInPlaceOffer)(null, {
      launchable: ["open-project"]
    })).toBeNull();
  });
  it("cannot be talked into launching anything when the app declares no launches", () => {
    expect((0, _opensWith.opensInPlaceOffer)(offer, {
      launchable: []
    })).toBeNull();
  });
});
describe("withdrawsOffer — a cancel is not a refusal", () => {
  it("keeps offering after the user closes the viewer", () => {
    expect((0, _opensWith.withdrawsOffer)("cancelled")).toBe(false);
  });
  it("stops offering a contract that is structurally dead", () => {
    expect((0, _opensWith.withdrawsOffer)("no-such-task")).toBe(true);
    expect((0, _opensWith.withdrawsOffer)("not-declared")).toBe(true);
    expect((0, _opensWith.withdrawsOffer)("task-version-mismatch")).toBe(true);
  });
  it("keeps offering after a one-off failure (transient, unknown, or a bad delegation)", () => {
    expect((0, _opensWith.withdrawsOffer)("forbidden")).toBe(false);
    expect((0, _opensWith.withdrawsOffer)("timeout")).toBe(false);
    expect((0, _opensWith.withdrawsOffer)(undefined)).toBe(false);
  });
});

// R3-789 (BUNDLE_EMBEDDING §4b.1a) — one offer per declared view; the view's app never leaves.
describe("viewOffers — declared views", () => {
  const board = {
    name: "Roadmap board",
    opensWith: {
      app: "github:immediately-run/kanban-board",
      version: "1.0"
    },
    subtree: "/roadmap"
  };
  const wiki = views => marker({
    opensWith: {
      task: "open-wiki"
    },
    kind: "wiki",
    views
  });
  const declared = {
    offerable: ["open-wiki", "open-declared"]
  };
  it("offers each view by name through open-declared, and carries no app", () => {
    const o = (0, _opensWith.viewOffers)(wiki([board, {
      ...board,
      name: "Specs board",
      subtree: "/specs"
    }]), declared);
    expect(o).toEqual([{
      task: "open-declared",
      version: "1.0",
      label: "Open as Roadmap board",
      view: "Roadmap board"
    }, {
      task: "open-declared",
      version: "1.0",
      label: "Open as Specs board",
      view: "Specs board"
    }]);
    expect(JSON.stringify(o)).not.toContain("kanban-board");
  });
  it.each([["a revision in app", {
    ...board,
    opensWith: {
      app: "github:a/b@main"
    }
  }], ["a commit pin in app", {
    ...board,
    opensWith: {
      app: `github:a/b#${"a".repeat(40)}`
    }
  }], ["an entry key", {
    ...board,
    opensWith: {
      ...board.opensWith,
      entry: "x"
    }
  }], ["the task form", {
    ...board,
    opensWith: {
      task: "open-wiki"
    }
  }], ["a traversing subtree", {
    ...board,
    subtree: "/a/../b"
  }], ["a relative subtree", {
    ...board,
    subtree: "roadmap"
  }], ["a bidi name", {
    ...board,
    name: "a\u202eb"
  }], ["an empty name", {
    ...board,
    name: " "
  }], ["the root subtree (the host refuses '/')", {
    ...board,
    subtree: "/"
  }], ["an empty segment", {
    ...board,
    subtree: "/a//b"
  }], ["a name with a trailing tab (the host tests the untrimmed name)", {
    ...board,
    name: "Board\t"
  }]])("mirrors the host and does not offer %s", (_why, v) => {
    expect((0, _opensWith.viewOffers)(wiki([v]), declared)).toEqual([]);
  });
  it.each([0x00, 0x1f, 0x7f, 0x9f, 0x061c, 0x200e, 0x200f, 0x2028, 0x2029, 0x202a, 0x202e, 0x2066, 0x2069])("refuses a name carrying code unit %i — the host's label class, every range edge", c => {
    expect((0, _opensWith.viewOffers)(wiki([{
      ...board,
      name: `Board${String.fromCharCode(c)}x`
    }]), declared)).toEqual([]);
  });
  it.each([["no opensWith", {
    kind: "wiki"
  }], ["task and app together (ambiguous-opens)", {
    opensWith: {
      task: "open-wiki",
      app: "github:a/b"
    },
    kind: "wiki"
  }], ["an app-form marker with an entry", {
    opensWith: {
      app: "github:a/b",
      entry: "x"
    },
    kind: "board"
  }], ["an app-form marker with a revision", {
    opensWith: {
      app: "github:a/b@main"
    },
    kind: "board"
  }], ["an app-form marker with no kind", {
    opensWith: {
      app: "github:a/b"
    }
  }]])("offers no views on a marker the host rejects as a whole: %s", (_why, top) => {
    expect((0, _opensWith.viewOffers)(marker({
      ...top,
      views: [board]
    }), declared)).toEqual([]);
  });
  it("accepts the subtrees the host accepts, including a trailing slash", () => {
    for (const subtree of ["/a", "/a/", "/a/b"]) {
      expect((0, _opensWith.viewOffers)(wiki([{
        ...board,
        subtree
      }]), declared)).toHaveLength(1);
    }
  });
  it("offers nothing when this app does not invoke open-declared, or it was withdrawn", () => {
    expect((0, _opensWith.viewOffers)(wiki([board]), {
      offerable: ["open-wiki"]
    })).toEqual([]);
    expect((0, _opensWith.viewOffers)(wiki([board]), {
      ...declared,
      unavailable: new Set(["open-declared"])
    })).toEqual([]);
  });
  it("drops duplicates and caps at eight", () => {
    expect((0, _opensWith.viewOffers)(wiki([board, board]), declared)).toHaveLength(1);
    const many = Array.from({
      length: 12
    }, (_, i) => ({
      ...board,
      name: `v${i}`
    }));
    expect((0, _opensWith.viewOffers)(wiki(many), declared)).toHaveLength(8);
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfb3BlbnNXaXRoIiwicmVxdWlyZSIsInBvbGljeSIsIm9mZmVyYWJsZSIsIm1hcmtlciIsIm8iLCJKU09OIiwic3RyaW5naWZ5IiwiZGVzY3JpYmUiLCJpdCIsImV4cGVjdCIsIkNPTlRFTlRfTUFSS0VSX0ZJTEUiLCJ0b0JlIiwicGFyc2VPcGVuc1dpdGgiLCJvcGVuc1dpdGgiLCJ0YXNrIiwia2luZCIsInRvRXF1YWwiLCJ2ZXJzaW9uIiwidG9NYXRjaE9iamVjdCIsImVhY2giLCJfd2h5IiwidGV4dCIsInRvQmVOdWxsIiwicGFyc2VkIiwiYXBwIiwiQVBQX0ZPUk1fQ09OVFJBQ1QiLCJub3QiLCJ0b01hdGNoIiwicmVwbyIsInJlcGVhdCIsImVudHJ5IiwidW5kZWZpbmVkIiwib3BlbldpdGhMYWJlbCIsIm9wZW5zV2l0aE9mZmVyIiwibGFiZWwiLCJ1bmF2YWlsYWJsZSIsIlNldCIsIm9mZmVyIiwib3BlbnNJblBsYWNlT2ZmZXIiLCJsYXVuY2hhYmxlIiwiaG9zdGlsZSIsIndpa2kiLCJ3aXRoZHJhd3NPZmZlciIsImJvYXJkIiwibmFtZSIsInN1YnRyZWUiLCJ2aWV3cyIsImRlY2xhcmVkIiwidmlld09mZmVycyIsInZpZXciLCJ0b0NvbnRhaW4iLCJ2IiwiYyIsIlN0cmluZyIsImZyb21DaGFyQ29kZSIsInRvcCIsInRvSGF2ZUxlbmd0aCIsIm1hbnkiLCJBcnJheSIsImZyb20iLCJsZW5ndGgiLCJfIiwiaSJdLCJzb3VyY2VzIjpbIm9wZW5zV2l0aC50ZXN0LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIHZpZXdPZmZlcnMsXG4gIEFQUF9GT1JNX0NPTlRSQUNULFxuICBDT05URU5UX01BUktFUl9GSUxFLFxuICBvcGVuV2l0aExhYmVsLFxuICBvcGVuc0luUGxhY2VPZmZlcixcbiAgb3BlbnNXaXRoT2ZmZXIsXG4gIHBhcnNlT3BlbnNXaXRoLFxuICB3aXRoZHJhd3NPZmZlcixcbn0gZnJvbSBcIi4vb3BlbnNXaXRoXCI7XG5cbmNvbnN0IHBvbGljeSA9IHsgb2ZmZXJhYmxlOiBbXCJvcGVuLXdpa2lcIiwgXCJvcGVuLXByb2plY3RcIl0gfTtcbmNvbnN0IG1hcmtlciA9IChvOiB1bmtub3duKSA9PiBKU09OLnN0cmluZ2lmeShvKTtcblxuZGVzY3JpYmUoXCJwYXJzZU9wZW5zV2l0aCDigJQgYW4gdW50cnVzdGVkIG1hcmtlciBuZXZlciB0aHJvd3NcIiwgKCkgPT4ge1xuICBpdChcIm5hbWVzIHRoZSBtYXJrZXIgZmlsZSB0aGUgc3BlY3MgbmFtZVwiLCAoKSA9PiB7XG4gICAgZXhwZWN0KENPTlRFTlRfTUFSS0VSX0ZJTEUpLnRvQmUoXCJpbW1lZGlhdGVseS5ydW4uanNvblwiKTtcbiAgfSk7XG5cbiAgaXQoXCJyZWFkcyB0aGUgdGFzayBhbmQgZGVmYXVsdHMgdGhlIHZlcnNpb24gdG8gdGhlIHYxIHNoYXBlXCIsICgpID0+IHtcbiAgICBleHBlY3QocGFyc2VPcGVuc1dpdGgobWFya2VyKHsgb3BlbnNXaXRoOiB7IHRhc2s6IFwib3Blbi13aWtpXCIgfSwga2luZDogXCJ3aWtpXCIgfSkpKS50b0VxdWFsKHtcbiAgICAgIHRhc2s6IFwib3Blbi13aWtpXCIsXG4gICAgICB2ZXJzaW9uOiBcIjEuMFwiLFxuICAgICAga2luZDogXCJ3aWtpXCIsXG4gICAgfSk7XG4gIH0pO1xuXG4gIGl0KFwia2VlcHMgYW4gZXhwbGljaXQgdmVyc2lvblwiLCAoKSA9PiB7XG4gICAgZXhwZWN0KFxuICAgICAgcGFyc2VPcGVuc1dpdGgobWFya2VyKHsgb3BlbnNXaXRoOiB7IHRhc2s6IFwib3Blbi13aWtpXCIsIHZlcnNpb246IFwiMS4yXCIgfSB9KSksXG4gICAgKS50b01hdGNoT2JqZWN0KHsgdmVyc2lvbjogXCIxLjJcIiB9KTtcbiAgfSk7XG5cbiAgaXQuZWFjaDxbc3RyaW5nLCB1bmtub3duXT4oW1xuICAgIFtcImVtcHR5IHRleHRcIiwgXCJcIl0sXG4gICAgW1wid2hpdGVzcGFjZVwiLCBcIiAgIFwiXSxcbiAgICBbXCJpbnZhbGlkIEpTT05cIiwgXCJ7IG5vdCBqc29uXCJdLFxuICAgIFtcImEgSlNPTiBzY2FsYXJcIiwgJ1wid2lraVwiJ10sXG4gICAgW1wiYSBKU09OIGFycmF5XCIsIFwiWzEsMl1cIl0sXG4gICAgW1wibm8gb3BlbnNXaXRoIGtleVwiLCBtYXJrZXIoeyBraW5kOiBcIndpa2lcIiB9KV0sXG4gICAgW1wib3BlbnNXaXRoIG5vdCBhbiBvYmplY3RcIiwgbWFya2VyKHsgb3BlbnNXaXRoOiBcIm9wZW4td2lraVwiIH0pXSxcbiAgICBbXCJvcGVuc1dpdGggYW4gYXJyYXlcIiwgbWFya2VyKHsgb3BlbnNXaXRoOiBbXCJvcGVuLXdpa2lcIl0gfSldLFxuICAgIFtcImEgbm9uLXN0cmluZyB0YXNrXCIsIG1hcmtlcih7IG9wZW5zV2l0aDogeyB0YXNrOiA3IH0gfSldLFxuICAgIFtcImFuIGVtcHR5IHRhc2tcIiwgbWFya2VyKHsgb3BlbnNXaXRoOiB7IHRhc2s6IFwiICBcIiB9IH0pXSxcbiAgXSkoXCJyZXR1cm5zIG51bGwgZm9yICVzXCIsIChfd2h5LCB0ZXh0KSA9PiB7XG4gICAgZXhwZWN0KHBhcnNlT3BlbnNXaXRoKHRleHQgYXMgc3RyaW5nKSkudG9CZU51bGwoKTtcbiAgfSk7XG5cbiAgaXQoXCJhbiBBUFAtZm9ybSBtYXJrZXIgb3BlbnMgdGhyb3VnaCB0aGUgZml4ZWQgY29udHJhY3QsIGFuZCB0aGUgYXBwIGl0IG5hbWVzIGlzIG5vdCByZXR1cm5lZFwiLCAoKSA9PiB7XG4gICAgLy8gQlVORExFX0VNQkVERElORyDCpzRiLjIgcnVsZSAyOiB0aGUgY2FsbGVyIG5ldmVyIG5hbWVzIHRoZSBhcHAg4oCUIHRoZSBob3N0IHJlYWRzIHRoZVxuICAgIC8vIG1hcmtlciBhdCBpbnZva2UgdGltZSBhbmQgcmVzb2x2ZXMgdGhlIG9wZW5lciBpdHNlbGYuXG4gICAgY29uc3QgcGFyc2VkID0gcGFyc2VPcGVuc1dpdGgobWFya2VyKHsgb3BlbnNXaXRoOiB7IGFwcDogXCJnaXRodWI6bWFsbG9yeS9ldmlsXCIsIHZlcnNpb246IFwiOS45XCIgfSwga2luZDogXCJib2FyZFwiIH0pKTtcbiAgICBleHBlY3QocGFyc2VkKS50b0VxdWFsKHsgdGFzazogQVBQX0ZPUk1fQ09OVFJBQ1QsIHZlcnNpb246IFwiMS4wXCIsIGtpbmQ6IFwiYm9hcmRcIiB9KTtcbiAgICBleHBlY3QoQVBQX0ZPUk1fQ09OVFJBQ1QpLnRvQmUoXCJvcGVuLWRlY2xhcmVkXCIpO1xuICAgIGV4cGVjdChKU09OLnN0cmluZ2lmeShwYXJzZWQpKS5ub3QudG9NYXRjaCgvbWFsbG9yeXw5XFwuOS8pO1xuICB9KTtcblxuICBpdC5lYWNoPFtzdHJpbmcsIHVua25vd25dPihbXG4gICAgW1wiYm90aCBmb3JtcyBhdCBvbmNlICh0aGUgaG9zdCByZWZ1c2VzIGl0KVwiLCBtYXJrZXIoeyBvcGVuc1dpdGg6IHsgdGFzazogXCJvcGVuLXdpa2lcIiwgYXBwOiBcImdpdGh1YjphL2JcIiB9IH0pXSxcbiAgICBbXCJhbiBlbXB0eSBhcHBcIiwgbWFya2VyKHsgb3BlbnNXaXRoOiB7IGFwcDogXCJcIiB9IH0pXSxcbiAgICBbXCJhIG5vbi1zdHJpbmcgYXBwXCIsIG1hcmtlcih7IG9wZW5zV2l0aDogeyBhcHA6IHsgcmVwbzogXCJhL2JcIiB9IH0gfSldLFxuICAgIC8vIEVhY2ggbWlycm9ycyBhIGhvc3QgcmVmdXNhbCAoc2l0ZS1tYWluIHBhcnNlQ29udGVudE1hcmtlciwgwqc0Yi4xKSDigJQgb2ZmZXJlZCwgaXRcbiAgICAvLyB3b3VsZCBiZSBhIGRlYWQgY2xpY2sgdGhhdCBuZXZlciB3aXRoZHJhd3MuXG4gICAgW1wiYW4gYXBwIGNhcnJ5aW5nIGEgcmV2aXNpb24gKHJldmlzaW9uLWluLWFwcClcIiwgbWFya2VyKHsgb3BlbnNXaXRoOiB7IGFwcDogXCJnaXRodWI6YS9iQG1haW5cIiB9LCBraW5kOiBcImJvYXJkXCIgfSldLFxuICAgIFtcImFuIGFwcCBjYXJyeWluZyBhIGNvbW1pdCBwaW4gKHJldmlzaW9uLWluLWFwcClcIiwgbWFya2VyKHsgb3BlbnNXaXRoOiB7IGFwcDogYGdpdGh1YjphL2IjJHtcImFcIi5yZXBlYXQoNDApfWAgfSwga2luZDogXCJib2FyZFwiIH0pXSxcbiAgICBbXCJhbiBhcHAtZm9ybSBlbnRyeSBrZXkgKGVudHJ5LWluLWFwcClcIiwgbWFya2VyKHsgb3BlbnNXaXRoOiB7IGFwcDogXCJnaXRodWI6YS9iXCIsIGVudHJ5OiBcIngudHN4XCIgfSwga2luZDogXCJib2FyZFwiIH0pXSxcbiAgICBbXCJhbiBhcHAgZm9ybSB3aXRoIG5vIGtpbmQgKG1pc3Npbmcta2luZClcIiwgbWFya2VyKHsgb3BlbnNXaXRoOiB7IGFwcDogXCJnaXRodWI6YS9iXCIgfSB9KV0sXG4gICAgW1wid2hpdGVzcGFjZSB0YXNrIGJlc2lkZSBhbiBhcHAgKHRoZSBob3N0IGRvZXMgbm90IHRyaW06IGFtYmlndW91cy1vcGVucylcIiwgbWFya2VyKHsgb3BlbnNXaXRoOiB7IHRhc2s6IFwiIFwiLCBhcHA6IFwiZ2l0aHViOmEvYlwiIH0sIGtpbmQ6IFwiYm9hcmRcIiB9KV0sXG4gICAgW1wiYSB0YXNrLWZvcm0gbWFya2VyIG5hbWluZyBvcGVuLWRlY2xhcmVkIGl0c2VsZiAoYSBjeWNsZSlcIiwgbWFya2VyKHsgb3BlbnNXaXRoOiB7IHRhc2s6IFwib3Blbi1kZWNsYXJlZFwiIH0sIGtpbmQ6IFwiYm9hcmRcIiB9KV0sXG4gIF0pKFwicmV0dXJucyBudWxsIGZvciAlc1wiLCAoX3doeSwgdGV4dCkgPT4ge1xuICAgIGV4cGVjdChwYXJzZU9wZW5zV2l0aCh0ZXh0IGFzIHN0cmluZykpLnRvQmVOdWxsKCk7XG4gIH0pO1xuXG4gIGl0KFwicmV0dXJucyBudWxsIGZvciBhYnNlbnQgYnl0ZXMgKGFuIHVucmVhZGFibGUgLyBtaXNzaW5nIG1hcmtlcilcIiwgKCkgPT4ge1xuICAgIGV4cGVjdChwYXJzZU9wZW5zV2l0aChudWxsKSkudG9CZU51bGwoKTtcbiAgICBleHBlY3QocGFyc2VPcGVuc1dpdGgodW5kZWZpbmVkKSkudG9CZU51bGwoKTtcbiAgfSk7XG59KTtcblxuZGVzY3JpYmUoXCJvcGVuV2l0aExhYmVsIOKAlCB0aGUgbGFiZWwgY29tZXMgZnJvbSB0aGUgbWFya2VyJ3Mga2luZCwgbmV2ZXIgYSB0YXNrIG5hbWVcIiwgKCkgPT4ge1xuICBpdChcInVzZXMgdGhlIGF1dGhvcidzIGtpbmRcIiwgKCkgPT4ge1xuICAgIGV4cGVjdChvcGVuV2l0aExhYmVsKFwid2lraVwiKSkudG9CZShcIk9wZW4gYXMgd2lraVwiKTtcbiAgICBleHBlY3Qob3BlbldpdGhMYWJlbChcImJvYXJkXCIpKS50b0JlKFwiT3BlbiBhcyBib2FyZFwiKTtcbiAgICBleHBlY3Qob3BlbldpdGhMYWJlbChcIkRlc2lnbiBTeXN0ZW1cIikpLnRvQmUoXCJPcGVuIGFzIGRlc2lnbiBzeXN0ZW1cIik7XG4gIH0pO1xuXG4gIGl0KFwiZmFsbHMgYmFjayB0byBhIGdlbmVyaWMgbGFiZWwgd2hlbiB0aGVyZSBpcyBubyBraW5kXCIsICgpID0+IHtcbiAgICBleHBlY3Qob3BlbldpdGhMYWJlbCh1bmRlZmluZWQpKS50b0JlKFwiT3BlbiB3aXRoIGl0cyBhcHBcIik7XG4gICAgZXhwZWN0KG9wZW5XaXRoTGFiZWwoXCJcIikpLnRvQmUoXCJPcGVuIHdpdGggaXRzIGFwcFwiKTtcbiAgfSk7XG5cbiAgaXQuZWFjaChbXG4gICAgW1wibWFya3VwXCIsIFwiPGltZyBzcmM9eCBvbmVycm9yPWFsZXJ0KDEpPlwiXSxcbiAgICBbXCJhIG5ld2xpbmVcIiwgXCJ3aWtpXFxuU2lnbiBpbiB0byBjb250aW51ZVwiXSxcbiAgICBbXCJhIGNvbnRyb2wgY2hhcmFjdGVyXCIsIFwid2lraVx1MDAwN1wiXSxcbiAgICBbXCJhIHJpZ2h0LXRvLWxlZnQgb3ZlcnJpZGVcIiwgXCJ3aWtp4oCuZ25wLmV4ZVwiXSxcbiAgICBbXCJhbiBlc3NheVwiLCBcIndcIi5yZXBlYXQoMjAwKV0sXG4gICAgW1wiYSBsZWFkaW5nIGpvaW5lclwiLCBcIi13aWtpXCJdLFxuICBdKShcbiAgICBcInJlZnVzZXMgJXMgYW5kIHNob3dzIHRoZSBnZW5lcmljIGxhYmVsIGluc3RlYWQgb2Ygc2FuaXRpemluZyBpdCBpbnRvIHNoYXBlXCIsXG4gICAgKF93aHksIGtpbmQpID0+IHtcbiAgICAgIGV4cGVjdChvcGVuV2l0aExhYmVsKGtpbmQpKS50b0JlKFwiT3BlbiB3aXRoIGl0cyBhcHBcIik7XG4gICAgfSxcbiAgKTtcbn0pO1xuXG5kZXNjcmliZShcIm9wZW5zV2l0aE9mZmVyIOKAlCBhYnNlbnQgYWZmb3JkYW5jZSBpcyB0aGUgYW5zd2VyIHRvIGV2ZXJ5IHJlZnVzYWxcIiwgKCkgPT4ge1xuICBpdChcIm9mZmVycyBhIGRlY2xhcmVkIGNvbnRyYWN0LCBsYWJlbGxlZCBieSB0aGUgbWFya2VyJ3Mga2luZFwiLCAoKSA9PiB7XG4gICAgY29uc3QgbyA9IG9wZW5zV2l0aE9mZmVyKG1hcmtlcih7IG9wZW5zV2l0aDogeyB0YXNrOiBcIm9wZW4td2lraVwiIH0sIGtpbmQ6IFwid2lraVwiIH0pLCBwb2xpY3kpO1xuICAgIGV4cGVjdChvKS50b0VxdWFsKHsgdGFzazogXCJvcGVuLXdpa2lcIiwgdmVyc2lvbjogXCIxLjBcIiwgbGFiZWw6IFwiT3BlbiBhcyB3aWtpXCIgfSk7XG4gIH0pO1xuXG4gIGl0KFwib2ZmZXJzIGEgU0VDT05EIGNvbnRyYWN0IGZyb20gdGhlIHNhbWUgY29kZSBwYXRoLCB3aXRoIG5vIHRhc2sgbmFtZSBpbiBpdFwiLCAoKSA9PiB7XG4gICAgY29uc3QgbyA9IG9wZW5zV2l0aE9mZmVyKFxuICAgICAgbWFya2VyKHsgb3BlbnNXaXRoOiB7IHRhc2s6IFwib3Blbi1wcm9qZWN0XCIgfSwga2luZDogXCJwcm9qZWN0XCIgfSksXG4gICAgICBwb2xpY3ksXG4gICAgKTtcbiAgICBleHBlY3QobykudG9FcXVhbCh7IHRhc2s6IFwib3Blbi1wcm9qZWN0XCIsIHZlcnNpb246IFwiMS4wXCIsIGxhYmVsOiBcIk9wZW4gYXMgcHJvamVjdFwiIH0pO1xuICB9KTtcblxuICBpdChcIm9mZmVycyBhIGRlY2xhcmVkIGNvbnRyYWN0IGV2ZW4gd2hlbiB0aGUgbWFya2VyIG5hbWVzIG5vIHVzYWJsZSBraW5kXCIsICgpID0+IHtcbiAgICBjb25zdCBvID0gb3BlbnNXaXRoT2ZmZXIobWFya2VyKHsgb3BlbnNXaXRoOiB7IHRhc2s6IFwib3Blbi13aWtpXCIgfSB9KSwgcG9saWN5KTtcbiAgICBleHBlY3QobykudG9NYXRjaE9iamVjdCh7IHRhc2s6IFwib3Blbi13aWtpXCIsIGxhYmVsOiBcIk9wZW4gd2l0aCBpdHMgYXBwXCIgfSk7XG4gIH0pO1xuXG4gIGl0KFwiYSBtYXJrZXIgbmFtaW5nIGEgY29udHJhY3QgdGhpcyBhcHAgZG9lcyBub3QgaW52b2tlIOKGkiBubyBhZmZvcmRhbmNlLCBub3QgYW4gZXJyb3JcIiwgKCkgPT4ge1xuICAgIGV4cGVjdChcbiAgICAgIG9wZW5zV2l0aE9mZmVyKG1hcmtlcih7IG9wZW5zV2l0aDogeyB0YXNrOiBcIm9wZW4taG9sb2dyYW1cIiB9LCBraW5kOiBcImhvbG9ncmFtXCIgfSksIHBvbGljeSksXG4gICAgKS50b0JlTnVsbCgpO1xuICB9KTtcblxuICBpdChcImEgZm9sZGVyIHdpdGggbm8gbWFya2VyIOKGkiBubyBhZmZvcmRhbmNlXCIsICgpID0+IHtcbiAgICBleHBlY3Qob3BlbnNXaXRoT2ZmZXIobnVsbCwgcG9saWN5KSkudG9CZU51bGwoKTtcbiAgfSk7XG5cbiAgaXQoXCJ3aXRoZHJhd3MgYSBjb250cmFjdCB0aGUgaG9zdCBoYXMgYWxyZWFkeSByZWZ1c2VkIHRoaXMgc2Vzc2lvblwiLCAoKSA9PiB7XG4gICAgY29uc3QgdGV4dCA9IG1hcmtlcih7IG9wZW5zV2l0aDogeyB0YXNrOiBcIm9wZW4td2lraVwiIH0sIGtpbmQ6IFwid2lraVwiIH0pO1xuICAgIGV4cGVjdChvcGVuc1dpdGhPZmZlcih0ZXh0LCBwb2xpY3kpKS5ub3QudG9CZU51bGwoKTtcbiAgICBleHBlY3Qob3BlbnNXaXRoT2ZmZXIodGV4dCwgeyAuLi5wb2xpY3ksIHVuYXZhaWxhYmxlOiBuZXcgU2V0KFtcIm9wZW4td2lraVwiXSkgfSkpLnRvQmVOdWxsKCk7XG4gIH0pO1xuXG4gIGl0KFwiY2Fubm90IGJlIHRhbGtlZCBpbnRvIG9mZmVyaW5nIGFueXRoaW5nIHdoZW4gdGhlIGFwcCBkZWNsYXJlcyBub3RoaW5nXCIsICgpID0+IHtcbiAgICBleHBlY3Qob3BlbnNXaXRoT2ZmZXIobWFya2VyKHsgb3BlbnNXaXRoOiB7IHRhc2s6IFwib3Blbi13aWtpXCIgfSB9KSwgeyBvZmZlcmFibGU6IFtdIH0pKS50b0JlTnVsbCgpO1xuICB9KTtcbn0pO1xuXG5kZXNjcmliZShcIm9wZW5zSW5QbGFjZU9mZmVyIOKAlCB0aGUgaW50by1zdGFnZSB0d2luIChSMy0xNTkpXCIsICgpID0+IHtcbiAgY29uc3Qgb2ZmZXIgPSB7IHRhc2s6IFwib3Blbi1wcm9qZWN0XCIsIHZlcnNpb246IFwiMS4wXCIsIGxhYmVsOiBcIk9wZW4gYXMgYm9hcmRcIiB9O1xuXG4gIGl0KFwib2ZmZXJzIGEgbGF1bmNoLWRlY2xhcmVkIGNvbnRyYWN0IHdpdGggdGhlIEZJWEVEIHByb2R1Y3QgbGFiZWxcIiwgKCkgPT4ge1xuICAgIGV4cGVjdChvcGVuc0luUGxhY2VPZmZlcihvZmZlciwgeyBsYXVuY2hhYmxlOiBbXCJvcGVuLXByb2plY3RcIl0gfSkpLnRvRXF1YWwoe1xuICAgICAgdGFzazogXCJvcGVuLXByb2plY3RcIixcbiAgICAgIHZlcnNpb246IFwiMS4wXCIsXG4gICAgICBsYWJlbDogXCJPcGVuIGluIHBsYWNlXCIsXG4gICAgfSk7XG4gIH0pO1xuXG4gIGl0KFwibmV2ZXIgbGV0cyB0aGUgbWFya2VyJ3Mga2luZCByZWFjaCB0aGUgaW4tcGxhY2UgbGFiZWxcIiwgKCkgPT4ge1xuICAgIC8vIFRoZSBmb3ItcmVzdWx0IGxhYmVsIGlzIGF1dGhvciB0ZXh0IChcIk9wZW4gYXMgYm9hcmRcIik7IHRoZSBpbi1wbGFjZSB2ZXJiIGlzXG4gICAgLy8gdGhlIHByb2R1Y3Qncy4gQSBob3N0aWxlIGtpbmQgY2Fubm90IHJpZGUgaXQuXG4gICAgY29uc3QgaG9zdGlsZSA9IHsgdGFzazogXCJvcGVuLXByb2plY3RcIiwgdmVyc2lvbjogXCIxLjBcIiwgbGFiZWw6IFwiT3BlbiBhcyA8aW1nPlwiIH07XG4gICAgZXhwZWN0KG9wZW5zSW5QbGFjZU9mZmVyKGhvc3RpbGUsIHsgbGF1bmNoYWJsZTogW1wib3Blbi1wcm9qZWN0XCJdIH0pPy5sYWJlbCkudG9CZShcbiAgICAgIFwiT3BlbiBpbiBwbGFjZVwiLFxuICAgICk7XG4gIH0pO1xuXG4gIGl0KFwib2ZmZXJzIG5vdGhpbmcgZm9yIGEgY29udHJhY3QgdGhlIGFwcCBtYXkgb25seSBJTlZPS0UsIG5ldmVyIGxhdW5jaFwiLCAoKSA9PiB7XG4gICAgY29uc3Qgd2lraSA9IHsgdGFzazogXCJvcGVuLXdpa2lcIiwgdmVyc2lvbjogXCIxLjBcIiwgbGFiZWw6IFwiT3BlbiBhcyB3aWtpXCIgfTtcbiAgICBleHBlY3Qob3BlbnNJblBsYWNlT2ZmZXIod2lraSwgeyBsYXVuY2hhYmxlOiBbXCJvcGVuLXByb2plY3RcIl0gfSkpLnRvQmVOdWxsKCk7XG4gIH0pO1xuXG4gIGl0KFwib2ZmZXJzIG5vdGhpbmcgd2hlbiB0aGVyZSBpcyBubyBvZmZlciB0byB0d2luXCIsICgpID0+IHtcbiAgICBleHBlY3Qob3BlbnNJblBsYWNlT2ZmZXIobnVsbCwgeyBsYXVuY2hhYmxlOiBbXCJvcGVuLXByb2plY3RcIl0gfSkpLnRvQmVOdWxsKCk7XG4gIH0pO1xuXG4gIGl0KFwiY2Fubm90IGJlIHRhbGtlZCBpbnRvIGxhdW5jaGluZyBhbnl0aGluZyB3aGVuIHRoZSBhcHAgZGVjbGFyZXMgbm8gbGF1bmNoZXNcIiwgKCkgPT4ge1xuICAgIGV4cGVjdChvcGVuc0luUGxhY2VPZmZlcihvZmZlciwgeyBsYXVuY2hhYmxlOiBbXSB9KSkudG9CZU51bGwoKTtcbiAgfSk7XG59KTtcblxuZGVzY3JpYmUoXCJ3aXRoZHJhd3NPZmZlciDigJQgYSBjYW5jZWwgaXMgbm90IGEgcmVmdXNhbFwiLCAoKSA9PiB7XG4gIGl0KFwia2VlcHMgb2ZmZXJpbmcgYWZ0ZXIgdGhlIHVzZXIgY2xvc2VzIHRoZSB2aWV3ZXJcIiwgKCkgPT4ge1xuICAgIGV4cGVjdCh3aXRoZHJhd3NPZmZlcihcImNhbmNlbGxlZFwiKSkudG9CZShmYWxzZSk7XG4gIH0pO1xuXG4gIGl0KFwic3RvcHMgb2ZmZXJpbmcgYSBjb250cmFjdCB0aGF0IGlzIHN0cnVjdHVyYWxseSBkZWFkXCIsICgpID0+IHtcbiAgICBleHBlY3Qod2l0aGRyYXdzT2ZmZXIoXCJuby1zdWNoLXRhc2tcIikpLnRvQmUodHJ1ZSk7XG4gICAgZXhwZWN0KHdpdGhkcmF3c09mZmVyKFwibm90LWRlY2xhcmVkXCIpKS50b0JlKHRydWUpO1xuICAgIGV4cGVjdCh3aXRoZHJhd3NPZmZlcihcInRhc2stdmVyc2lvbi1taXNtYXRjaFwiKSkudG9CZSh0cnVlKTtcbiAgfSk7XG5cbiAgaXQoXCJrZWVwcyBvZmZlcmluZyBhZnRlciBhIG9uZS1vZmYgZmFpbHVyZSAodHJhbnNpZW50LCB1bmtub3duLCBvciBhIGJhZCBkZWxlZ2F0aW9uKVwiLCAoKSA9PiB7XG4gICAgZXhwZWN0KHdpdGhkcmF3c09mZmVyKFwiZm9yYmlkZGVuXCIpKS50b0JlKGZhbHNlKTtcbiAgICBleHBlY3Qod2l0aGRyYXdzT2ZmZXIoXCJ0aW1lb3V0XCIpKS50b0JlKGZhbHNlKTtcbiAgICBleHBlY3Qod2l0aGRyYXdzT2ZmZXIodW5kZWZpbmVkKSkudG9CZShmYWxzZSk7XG4gIH0pO1xufSk7XG5cbi8vIFIzLTc4OSAoQlVORExFX0VNQkVERElORyDCpzRiLjFhKSDigJQgb25lIG9mZmVyIHBlciBkZWNsYXJlZCB2aWV3OyB0aGUgdmlldydzIGFwcCBuZXZlciBsZWF2ZXMuXG5kZXNjcmliZShcInZpZXdPZmZlcnMg4oCUIGRlY2xhcmVkIHZpZXdzXCIsICgpID0+IHtcbiAgY29uc3QgYm9hcmQgPSB7XG4gICAgbmFtZTogXCJSb2FkbWFwIGJvYXJkXCIsXG4gICAgb3BlbnNXaXRoOiB7IGFwcDogXCJnaXRodWI6aW1tZWRpYXRlbHktcnVuL2thbmJhbi1ib2FyZFwiLCB2ZXJzaW9uOiBcIjEuMFwiIH0sXG4gICAgc3VidHJlZTogXCIvcm9hZG1hcFwiLFxuICB9O1xuICBjb25zdCB3aWtpID0gKHZpZXdzOiB1bmtub3duKSA9PiBtYXJrZXIoeyBvcGVuc1dpdGg6IHsgdGFzazogXCJvcGVuLXdpa2lcIiB9LCBraW5kOiBcIndpa2lcIiwgdmlld3MgfSk7XG4gIGNvbnN0IGRlY2xhcmVkID0geyBvZmZlcmFibGU6IFtcIm9wZW4td2lraVwiLCBcIm9wZW4tZGVjbGFyZWRcIl0gfTtcblxuICBpdChcIm9mZmVycyBlYWNoIHZpZXcgYnkgbmFtZSB0aHJvdWdoIG9wZW4tZGVjbGFyZWQsIGFuZCBjYXJyaWVzIG5vIGFwcFwiLCAoKSA9PiB7XG4gICAgY29uc3QgbyA9IHZpZXdPZmZlcnMod2lraShbYm9hcmQsIHsgLi4uYm9hcmQsIG5hbWU6IFwiU3BlY3MgYm9hcmRcIiwgc3VidHJlZTogXCIvc3BlY3NcIiB9XSksIGRlY2xhcmVkKTtcbiAgICBleHBlY3QobykudG9FcXVhbChbXG4gICAgICB7IHRhc2s6IFwib3Blbi1kZWNsYXJlZFwiLCB2ZXJzaW9uOiBcIjEuMFwiLCBsYWJlbDogXCJPcGVuIGFzIFJvYWRtYXAgYm9hcmRcIiwgdmlldzogXCJSb2FkbWFwIGJvYXJkXCIgfSxcbiAgICAgIHsgdGFzazogXCJvcGVuLWRlY2xhcmVkXCIsIHZlcnNpb246IFwiMS4wXCIsIGxhYmVsOiBcIk9wZW4gYXMgU3BlY3MgYm9hcmRcIiwgdmlldzogXCJTcGVjcyBib2FyZFwiIH0sXG4gICAgXSk7XG4gICAgZXhwZWN0KEpTT04uc3RyaW5naWZ5KG8pKS5ub3QudG9Db250YWluKFwia2FuYmFuLWJvYXJkXCIpO1xuICB9KTtcblxuICBpdC5lYWNoPFtzdHJpbmcsIHVua25vd25dPihbXG4gICAgW1wiYSByZXZpc2lvbiBpbiBhcHBcIiwgeyAuLi5ib2FyZCwgb3BlbnNXaXRoOiB7IGFwcDogXCJnaXRodWI6YS9iQG1haW5cIiB9IH1dLFxuICAgIFtcImEgY29tbWl0IHBpbiBpbiBhcHBcIiwgeyAuLi5ib2FyZCwgb3BlbnNXaXRoOiB7IGFwcDogYGdpdGh1YjphL2IjJHtcImFcIi5yZXBlYXQoNDApfWAgfSB9XSxcbiAgICBbXCJhbiBlbnRyeSBrZXlcIiwgeyAuLi5ib2FyZCwgb3BlbnNXaXRoOiB7IC4uLmJvYXJkLm9wZW5zV2l0aCwgZW50cnk6IFwieFwiIH0gfV0sXG4gICAgW1widGhlIHRhc2sgZm9ybVwiLCB7IC4uLmJvYXJkLCBvcGVuc1dpdGg6IHsgdGFzazogXCJvcGVuLXdpa2lcIiB9IH1dLFxuICAgIFtcImEgdHJhdmVyc2luZyBzdWJ0cmVlXCIsIHsgLi4uYm9hcmQsIHN1YnRyZWU6IFwiL2EvLi4vYlwiIH1dLFxuICAgIFtcImEgcmVsYXRpdmUgc3VidHJlZVwiLCB7IC4uLmJvYXJkLCBzdWJ0cmVlOiBcInJvYWRtYXBcIiB9XSxcbiAgICBbXCJhIGJpZGkgbmFtZVwiLCB7IC4uLmJvYXJkLCBuYW1lOiBcImFcXHUyMDJlYlwiIH1dLFxuICAgIFtcImFuIGVtcHR5IG5hbWVcIiwgeyAuLi5ib2FyZCwgbmFtZTogXCIgXCIgfV0sXG4gICAgW1widGhlIHJvb3Qgc3VidHJlZSAodGhlIGhvc3QgcmVmdXNlcyAnLycpXCIsIHsgLi4uYm9hcmQsIHN1YnRyZWU6IFwiL1wiIH1dLFxuICAgIFtcImFuIGVtcHR5IHNlZ21lbnRcIiwgeyAuLi5ib2FyZCwgc3VidHJlZTogXCIvYS8vYlwiIH1dLFxuICAgIFtcImEgbmFtZSB3aXRoIGEgdHJhaWxpbmcgdGFiICh0aGUgaG9zdCB0ZXN0cyB0aGUgdW50cmltbWVkIG5hbWUpXCIsIHsgLi4uYm9hcmQsIG5hbWU6IFwiQm9hcmRcXHRcIiB9XSxcbiAgXSkoXCJtaXJyb3JzIHRoZSBob3N0IGFuZCBkb2VzIG5vdCBvZmZlciAlc1wiLCAoX3doeSwgdikgPT4ge1xuICAgIGV4cGVjdCh2aWV3T2ZmZXJzKHdpa2koW3ZdKSwgZGVjbGFyZWQpKS50b0VxdWFsKFtdKTtcbiAgfSk7XG5cbiAgaXQuZWFjaChbMHgwMCwgMHgxZiwgMHg3ZiwgMHg5ZiwgMHgwNjFjLCAweDIwMGUsIDB4MjAwZiwgMHgyMDI4LCAweDIwMjksIDB4MjAyYSwgMHgyMDJlLCAweDIwNjYsIDB4MjA2OV0pKFxuICAgIFwicmVmdXNlcyBhIG5hbWUgY2FycnlpbmcgY29kZSB1bml0ICVpIOKAlCB0aGUgaG9zdCdzIGxhYmVsIGNsYXNzLCBldmVyeSByYW5nZSBlZGdlXCIsXG4gICAgKGMpID0+IHtcbiAgICAgIGV4cGVjdCh2aWV3T2ZmZXJzKHdpa2koW3sgLi4uYm9hcmQsIG5hbWU6IGBCb2FyZCR7U3RyaW5nLmZyb21DaGFyQ29kZShjKX14YCB9XSksIGRlY2xhcmVkKSkudG9FcXVhbChbXSk7XG4gICAgfSxcbiAgKTtcblxuICBpdC5lYWNoKFtcbiAgICBbXCJubyBvcGVuc1dpdGhcIiwgeyBraW5kOiBcIndpa2lcIiB9XSxcbiAgICBbXCJ0YXNrIGFuZCBhcHAgdG9nZXRoZXIgKGFtYmlndW91cy1vcGVucylcIiwgeyBvcGVuc1dpdGg6IHsgdGFzazogXCJvcGVuLXdpa2lcIiwgYXBwOiBcImdpdGh1YjphL2JcIiB9LCBraW5kOiBcIndpa2lcIiB9XSxcbiAgICBbXCJhbiBhcHAtZm9ybSBtYXJrZXIgd2l0aCBhbiBlbnRyeVwiLCB7IG9wZW5zV2l0aDogeyBhcHA6IFwiZ2l0aHViOmEvYlwiLCBlbnRyeTogXCJ4XCIgfSwga2luZDogXCJib2FyZFwiIH1dLFxuICAgIFtcImFuIGFwcC1mb3JtIG1hcmtlciB3aXRoIGEgcmV2aXNpb25cIiwgeyBvcGVuc1dpdGg6IHsgYXBwOiBcImdpdGh1YjphL2JAbWFpblwiIH0sIGtpbmQ6IFwiYm9hcmRcIiB9XSxcbiAgICBbXCJhbiBhcHAtZm9ybSBtYXJrZXIgd2l0aCBubyBraW5kXCIsIHsgb3BlbnNXaXRoOiB7IGFwcDogXCJnaXRodWI6YS9iXCIgfSB9XSxcbiAgXSkoXCJvZmZlcnMgbm8gdmlld3Mgb24gYSBtYXJrZXIgdGhlIGhvc3QgcmVqZWN0cyBhcyBhIHdob2xlOiAlc1wiLCAoX3doeSwgdG9wKSA9PiB7XG4gICAgZXhwZWN0KHZpZXdPZmZlcnMobWFya2VyKHsgLi4udG9wLCB2aWV3czogW2JvYXJkXSB9KSwgZGVjbGFyZWQpKS50b0VxdWFsKFtdKTtcbiAgfSk7XG5cbiAgaXQoXCJhY2NlcHRzIHRoZSBzdWJ0cmVlcyB0aGUgaG9zdCBhY2NlcHRzLCBpbmNsdWRpbmcgYSB0cmFpbGluZyBzbGFzaFwiLCAoKSA9PiB7XG4gICAgZm9yIChjb25zdCBzdWJ0cmVlIG9mIFtcIi9hXCIsIFwiL2EvXCIsIFwiL2EvYlwiXSkge1xuICAgICAgZXhwZWN0KHZpZXdPZmZlcnMod2lraShbeyAuLi5ib2FyZCwgc3VidHJlZSB9XSksIGRlY2xhcmVkKSkudG9IYXZlTGVuZ3RoKDEpO1xuICAgIH1cbiAgfSk7XG5cbiAgaXQoXCJvZmZlcnMgbm90aGluZyB3aGVuIHRoaXMgYXBwIGRvZXMgbm90IGludm9rZSBvcGVuLWRlY2xhcmVkLCBvciBpdCB3YXMgd2l0aGRyYXduXCIsICgpID0+IHtcbiAgICBleHBlY3Qodmlld09mZmVycyh3aWtpKFtib2FyZF0pLCB7IG9mZmVyYWJsZTogW1wib3Blbi13aWtpXCJdIH0pKS50b0VxdWFsKFtdKTtcbiAgICBleHBlY3Qodmlld09mZmVycyh3aWtpKFtib2FyZF0pLCB7IC4uLmRlY2xhcmVkLCB1bmF2YWlsYWJsZTogbmV3IFNldChbXCJvcGVuLWRlY2xhcmVkXCJdKSB9KSkudG9FcXVhbChbXSk7XG4gIH0pO1xuXG4gIGl0KFwiZHJvcHMgZHVwbGljYXRlcyBhbmQgY2FwcyBhdCBlaWdodFwiLCAoKSA9PiB7XG4gICAgZXhwZWN0KHZpZXdPZmZlcnMod2lraShbYm9hcmQsIGJvYXJkXSksIGRlY2xhcmVkKSkudG9IYXZlTGVuZ3RoKDEpO1xuICAgIGNvbnN0IG1hbnkgPSBBcnJheS5mcm9tKHsgbGVuZ3RoOiAxMiB9LCAoXywgaSkgPT4gKHsgLi4uYm9hcmQsIG5hbWU6IGB2JHtpfWAgfSkpO1xuICAgIGV4cGVjdCh2aWV3T2ZmZXJzKHdpa2kobWFueSksIGRlY2xhcmVkKSkudG9IYXZlTGVuZ3RoKDgpO1xuICB9KTtcbn0pO1xuXG4iXSwibWFwcGluZ3MiOiI7O0FBQUEsSUFBQUEsVUFBQSxHQUFBQyxPQUFBO0FBV0EsTUFBTUMsTUFBTSxHQUFHO0VBQUVDLFNBQVMsRUFBRSxDQUFDLFdBQVcsRUFBRSxjQUFjO0FBQUUsQ0FBQztBQUMzRCxNQUFNQyxNQUFNLEdBQUlDLENBQVUsSUFBS0MsSUFBSSxDQUFDQyxTQUFTLENBQUNGLENBQUMsQ0FBQztBQUVoREcsUUFBUSxDQUFDLG1EQUFtRCxFQUFFLE1BQU07RUFDbEVDLEVBQUUsQ0FBQyxzQ0FBc0MsRUFBRSxNQUFNO0lBQy9DQyxNQUFNLENBQUNDLDhCQUFtQixDQUFDLENBQUNDLElBQUksQ0FBQyxzQkFBc0IsQ0FBQztFQUMxRCxDQUFDLENBQUM7RUFFRkgsRUFBRSxDQUFDLHlEQUF5RCxFQUFFLE1BQU07SUFDbEVDLE1BQU0sQ0FBQyxJQUFBRyx5QkFBYyxFQUFDVCxNQUFNLENBQUM7TUFBRVUsU0FBUyxFQUFFO1FBQUVDLElBQUksRUFBRTtNQUFZLENBQUM7TUFBRUMsSUFBSSxFQUFFO0lBQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDQyxPQUFPLENBQUM7TUFDekZGLElBQUksRUFBRSxXQUFXO01BQ2pCRyxPQUFPLEVBQUUsS0FBSztNQUNkRixJQUFJLEVBQUU7SUFDUixDQUFDLENBQUM7RUFDSixDQUFDLENBQUM7RUFFRlAsRUFBRSxDQUFDLDJCQUEyQixFQUFFLE1BQU07SUFDcENDLE1BQU0sQ0FDSixJQUFBRyx5QkFBYyxFQUFDVCxNQUFNLENBQUM7TUFBRVUsU0FBUyxFQUFFO1FBQUVDLElBQUksRUFBRSxXQUFXO1FBQUVHLE9BQU8sRUFBRTtNQUFNO0lBQUUsQ0FBQyxDQUFDLENBQzdFLENBQUMsQ0FBQ0MsYUFBYSxDQUFDO01BQUVELE9BQU8sRUFBRTtJQUFNLENBQUMsQ0FBQztFQUNyQyxDQUFDLENBQUM7RUFFRlQsRUFBRSxDQUFDVyxJQUFJLENBQW9CLENBQ3pCLENBQUMsWUFBWSxFQUFFLEVBQUUsQ0FBQyxFQUNsQixDQUFDLFlBQVksRUFBRSxLQUFLLENBQUMsRUFDckIsQ0FBQyxjQUFjLEVBQUUsWUFBWSxDQUFDLEVBQzlCLENBQUMsZUFBZSxFQUFFLFFBQVEsQ0FBQyxFQUMzQixDQUFDLGNBQWMsRUFBRSxPQUFPLENBQUMsRUFDekIsQ0FBQyxrQkFBa0IsRUFBRWhCLE1BQU0sQ0FBQztJQUFFWSxJQUFJLEVBQUU7RUFBTyxDQUFDLENBQUMsQ0FBQyxFQUM5QyxDQUFDLHlCQUF5QixFQUFFWixNQUFNLENBQUM7SUFBRVUsU0FBUyxFQUFFO0VBQVksQ0FBQyxDQUFDLENBQUMsRUFDL0QsQ0FBQyxvQkFBb0IsRUFBRVYsTUFBTSxDQUFDO0lBQUVVLFNBQVMsRUFBRSxDQUFDLFdBQVc7RUFBRSxDQUFDLENBQUMsQ0FBQyxFQUM1RCxDQUFDLG1CQUFtQixFQUFFVixNQUFNLENBQUM7SUFBRVUsU0FBUyxFQUFFO01BQUVDLElBQUksRUFBRTtJQUFFO0VBQUUsQ0FBQyxDQUFDLENBQUMsRUFDekQsQ0FBQyxlQUFlLEVBQUVYLE1BQU0sQ0FBQztJQUFFVSxTQUFTLEVBQUU7TUFBRUMsSUFBSSxFQUFFO0lBQUs7RUFBRSxDQUFDLENBQUMsQ0FBQyxDQUN6RCxDQUFDLENBQUMscUJBQXFCLEVBQUUsQ0FBQ00sSUFBSSxFQUFFQyxJQUFJLEtBQUs7SUFDeENaLE1BQU0sQ0FBQyxJQUFBRyx5QkFBYyxFQUFDUyxJQUFjLENBQUMsQ0FBQyxDQUFDQyxRQUFRLENBQUMsQ0FBQztFQUNuRCxDQUFDLENBQUM7RUFFRmQsRUFBRSxDQUFDLDJGQUEyRixFQUFFLE1BQU07SUFDcEc7SUFDQTtJQUNBLE1BQU1lLE1BQU0sR0FBRyxJQUFBWCx5QkFBYyxFQUFDVCxNQUFNLENBQUM7TUFBRVUsU0FBUyxFQUFFO1FBQUVXLEdBQUcsRUFBRSxxQkFBcUI7UUFBRVAsT0FBTyxFQUFFO01BQU0sQ0FBQztNQUFFRixJQUFJLEVBQUU7SUFBUSxDQUFDLENBQUMsQ0FBQztJQUNuSE4sTUFBTSxDQUFDYyxNQUFNLENBQUMsQ0FBQ1AsT0FBTyxDQUFDO01BQUVGLElBQUksRUFBRVcsNEJBQWlCO01BQUVSLE9BQU8sRUFBRSxLQUFLO01BQUVGLElBQUksRUFBRTtJQUFRLENBQUMsQ0FBQztJQUNsRk4sTUFBTSxDQUFDZ0IsNEJBQWlCLENBQUMsQ0FBQ2QsSUFBSSxDQUFDLGVBQWUsQ0FBQztJQUMvQ0YsTUFBTSxDQUFDSixJQUFJLENBQUNDLFNBQVMsQ0FBQ2lCLE1BQU0sQ0FBQyxDQUFDLENBQUNHLEdBQUcsQ0FBQ0MsT0FBTyxDQUFDLGNBQWMsQ0FBQztFQUM1RCxDQUFDLENBQUM7RUFFRm5CLEVBQUUsQ0FBQ1csSUFBSSxDQUFvQixDQUN6QixDQUFDLDBDQUEwQyxFQUFFaEIsTUFBTSxDQUFDO0lBQUVVLFNBQVMsRUFBRTtNQUFFQyxJQUFJLEVBQUUsV0FBVztNQUFFVSxHQUFHLEVBQUU7SUFBYTtFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQzdHLENBQUMsY0FBYyxFQUFFckIsTUFBTSxDQUFDO0lBQUVVLFNBQVMsRUFBRTtNQUFFVyxHQUFHLEVBQUU7SUFBRztFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQ3BELENBQUMsa0JBQWtCLEVBQUVyQixNQUFNLENBQUM7SUFBRVUsU0FBUyxFQUFFO01BQUVXLEdBQUcsRUFBRTtRQUFFSSxJQUFJLEVBQUU7TUFBTTtJQUFFO0VBQUUsQ0FBQyxDQUFDLENBQUM7RUFDckU7RUFDQTtFQUNBLENBQUMsOENBQThDLEVBQUV6QixNQUFNLENBQUM7SUFBRVUsU0FBUyxFQUFFO01BQUVXLEdBQUcsRUFBRTtJQUFrQixDQUFDO0lBQUVULElBQUksRUFBRTtFQUFRLENBQUMsQ0FBQyxDQUFDLEVBQ2xILENBQUMsZ0RBQWdELEVBQUVaLE1BQU0sQ0FBQztJQUFFVSxTQUFTLEVBQUU7TUFBRVcsR0FBRyxFQUFFLGNBQWMsR0FBRyxDQUFDSyxNQUFNLENBQUMsRUFBRSxDQUFDO0lBQUcsQ0FBQztJQUFFZCxJQUFJLEVBQUU7RUFBUSxDQUFDLENBQUMsQ0FBQyxFQUNqSSxDQUFDLHNDQUFzQyxFQUFFWixNQUFNLENBQUM7SUFBRVUsU0FBUyxFQUFFO01BQUVXLEdBQUcsRUFBRSxZQUFZO01BQUVNLEtBQUssRUFBRTtJQUFRLENBQUM7SUFBRWYsSUFBSSxFQUFFO0VBQVEsQ0FBQyxDQUFDLENBQUMsRUFDckgsQ0FBQyx5Q0FBeUMsRUFBRVosTUFBTSxDQUFDO0lBQUVVLFNBQVMsRUFBRTtNQUFFVyxHQUFHLEVBQUU7SUFBYTtFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQ3pGLENBQUMseUVBQXlFLEVBQUVyQixNQUFNLENBQUM7SUFBRVUsU0FBUyxFQUFFO01BQUVDLElBQUksRUFBRSxHQUFHO01BQUVVLEdBQUcsRUFBRTtJQUFhLENBQUM7SUFBRVQsSUFBSSxFQUFFO0VBQVEsQ0FBQyxDQUFDLENBQUMsRUFDbkosQ0FBQywwREFBMEQsRUFBRVosTUFBTSxDQUFDO0lBQUVVLFNBQVMsRUFBRTtNQUFFQyxJQUFJLEVBQUU7SUFBZ0IsQ0FBQztJQUFFQyxJQUFJLEVBQUU7RUFBUSxDQUFDLENBQUMsQ0FBQyxDQUM5SCxDQUFDLENBQUMscUJBQXFCLEVBQUUsQ0FBQ0ssSUFBSSxFQUFFQyxJQUFJLEtBQUs7SUFDeENaLE1BQU0sQ0FBQyxJQUFBRyx5QkFBYyxFQUFDUyxJQUFjLENBQUMsQ0FBQyxDQUFDQyxRQUFRLENBQUMsQ0FBQztFQUNuRCxDQUFDLENBQUM7RUFFRmQsRUFBRSxDQUFDLGdFQUFnRSxFQUFFLE1BQU07SUFDekVDLE1BQU0sQ0FBQyxJQUFBRyx5QkFBYyxFQUFDLElBQUksQ0FBQyxDQUFDLENBQUNVLFFBQVEsQ0FBQyxDQUFDO0lBQ3ZDYixNQUFNLENBQUMsSUFBQUcseUJBQWMsRUFBQ21CLFNBQVMsQ0FBQyxDQUFDLENBQUNULFFBQVEsQ0FBQyxDQUFDO0VBQzlDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQztBQUVGZixRQUFRLENBQUMsMkVBQTJFLEVBQUUsTUFBTTtFQUMxRkMsRUFBRSxDQUFDLHdCQUF3QixFQUFFLE1BQU07SUFDakNDLE1BQU0sQ0FBQyxJQUFBdUIsd0JBQWEsRUFBQyxNQUFNLENBQUMsQ0FBQyxDQUFDckIsSUFBSSxDQUFDLGNBQWMsQ0FBQztJQUNsREYsTUFBTSxDQUFDLElBQUF1Qix3QkFBYSxFQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUNyQixJQUFJLENBQUMsZUFBZSxDQUFDO0lBQ3BERixNQUFNLENBQUMsSUFBQXVCLHdCQUFhLEVBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQ3JCLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztFQUN0RSxDQUFDLENBQUM7RUFFRkgsRUFBRSxDQUFDLHFEQUFxRCxFQUFFLE1BQU07SUFDOURDLE1BQU0sQ0FBQyxJQUFBdUIsd0JBQWEsRUFBQ0QsU0FBUyxDQUFDLENBQUMsQ0FBQ3BCLElBQUksQ0FBQyxtQkFBbUIsQ0FBQztJQUMxREYsTUFBTSxDQUFDLElBQUF1Qix3QkFBYSxFQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUNyQixJQUFJLENBQUMsbUJBQW1CLENBQUM7RUFDckQsQ0FBQyxDQUFDO0VBRUZILEVBQUUsQ0FBQ1csSUFBSSxDQUFDLENBQ04sQ0FBQyxRQUFRLEVBQUUsOEJBQThCLENBQUMsRUFDMUMsQ0FBQyxXQUFXLEVBQUUsMkJBQTJCLENBQUMsRUFDMUMsQ0FBQyxxQkFBcUIsRUFBRSxPQUFPLENBQUMsRUFDaEMsQ0FBQywwQkFBMEIsRUFBRSxjQUFjLENBQUMsRUFDNUMsQ0FBQyxVQUFVLEVBQUUsR0FBRyxDQUFDVSxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsRUFDN0IsQ0FBQyxrQkFBa0IsRUFBRSxPQUFPLENBQUMsQ0FDOUIsQ0FBQyxDQUNBLDRFQUE0RSxFQUM1RSxDQUFDVCxJQUFJLEVBQUVMLElBQUksS0FBSztJQUNkTixNQUFNLENBQUMsSUFBQXVCLHdCQUFhLEVBQUNqQixJQUFJLENBQUMsQ0FBQyxDQUFDSixJQUFJLENBQUMsbUJBQW1CLENBQUM7RUFDdkQsQ0FDRixDQUFDO0FBQ0gsQ0FBQyxDQUFDO0FBRUZKLFFBQVEsQ0FBQyxtRUFBbUUsRUFBRSxNQUFNO0VBQ2xGQyxFQUFFLENBQUMsMkRBQTJELEVBQUUsTUFBTTtJQUNwRSxNQUFNSixDQUFDLEdBQUcsSUFBQTZCLHlCQUFjLEVBQUM5QixNQUFNLENBQUM7TUFBRVUsU0FBUyxFQUFFO1FBQUVDLElBQUksRUFBRTtNQUFZLENBQUM7TUFBRUMsSUFBSSxFQUFFO0lBQU8sQ0FBQyxDQUFDLEVBQUVkLE1BQU0sQ0FBQztJQUM1RlEsTUFBTSxDQUFDTCxDQUFDLENBQUMsQ0FBQ1ksT0FBTyxDQUFDO01BQUVGLElBQUksRUFBRSxXQUFXO01BQUVHLE9BQU8sRUFBRSxLQUFLO01BQUVpQixLQUFLLEVBQUU7SUFBZSxDQUFDLENBQUM7RUFDakYsQ0FBQyxDQUFDO0VBRUYxQixFQUFFLENBQUMsMkVBQTJFLEVBQUUsTUFBTTtJQUNwRixNQUFNSixDQUFDLEdBQUcsSUFBQTZCLHlCQUFjLEVBQ3RCOUIsTUFBTSxDQUFDO01BQUVVLFNBQVMsRUFBRTtRQUFFQyxJQUFJLEVBQUU7TUFBZSxDQUFDO01BQUVDLElBQUksRUFBRTtJQUFVLENBQUMsQ0FBQyxFQUNoRWQsTUFDRixDQUFDO0lBQ0RRLE1BQU0sQ0FBQ0wsQ0FBQyxDQUFDLENBQUNZLE9BQU8sQ0FBQztNQUFFRixJQUFJLEVBQUUsY0FBYztNQUFFRyxPQUFPLEVBQUUsS0FBSztNQUFFaUIsS0FBSyxFQUFFO0lBQWtCLENBQUMsQ0FBQztFQUN2RixDQUFDLENBQUM7RUFFRjFCLEVBQUUsQ0FBQyxzRUFBc0UsRUFBRSxNQUFNO0lBQy9FLE1BQU1KLENBQUMsR0FBRyxJQUFBNkIseUJBQWMsRUFBQzlCLE1BQU0sQ0FBQztNQUFFVSxTQUFTLEVBQUU7UUFBRUMsSUFBSSxFQUFFO01BQVk7SUFBRSxDQUFDLENBQUMsRUFBRWIsTUFBTSxDQUFDO0lBQzlFUSxNQUFNLENBQUNMLENBQUMsQ0FBQyxDQUFDYyxhQUFhLENBQUM7TUFBRUosSUFBSSxFQUFFLFdBQVc7TUFBRW9CLEtBQUssRUFBRTtJQUFvQixDQUFDLENBQUM7RUFDNUUsQ0FBQyxDQUFDO0VBRUYxQixFQUFFLENBQUMsbUZBQW1GLEVBQUUsTUFBTTtJQUM1RkMsTUFBTSxDQUNKLElBQUF3Qix5QkFBYyxFQUFDOUIsTUFBTSxDQUFDO01BQUVVLFNBQVMsRUFBRTtRQUFFQyxJQUFJLEVBQUU7TUFBZ0IsQ0FBQztNQUFFQyxJQUFJLEVBQUU7SUFBVyxDQUFDLENBQUMsRUFBRWQsTUFBTSxDQUMzRixDQUFDLENBQUNxQixRQUFRLENBQUMsQ0FBQztFQUNkLENBQUMsQ0FBQztFQUVGZCxFQUFFLENBQUMseUNBQXlDLEVBQUUsTUFBTTtJQUNsREMsTUFBTSxDQUFDLElBQUF3Qix5QkFBYyxFQUFDLElBQUksRUFBRWhDLE1BQU0sQ0FBQyxDQUFDLENBQUNxQixRQUFRLENBQUMsQ0FBQztFQUNqRCxDQUFDLENBQUM7RUFFRmQsRUFBRSxDQUFDLGdFQUFnRSxFQUFFLE1BQU07SUFDekUsTUFBTWEsSUFBSSxHQUFHbEIsTUFBTSxDQUFDO01BQUVVLFNBQVMsRUFBRTtRQUFFQyxJQUFJLEVBQUU7TUFBWSxDQUFDO01BQUVDLElBQUksRUFBRTtJQUFPLENBQUMsQ0FBQztJQUN2RU4sTUFBTSxDQUFDLElBQUF3Qix5QkFBYyxFQUFDWixJQUFJLEVBQUVwQixNQUFNLENBQUMsQ0FBQyxDQUFDeUIsR0FBRyxDQUFDSixRQUFRLENBQUMsQ0FBQztJQUNuRGIsTUFBTSxDQUFDLElBQUF3Qix5QkFBYyxFQUFDWixJQUFJLEVBQUU7TUFBRSxHQUFHcEIsTUFBTTtNQUFFa0MsV0FBVyxFQUFFLElBQUlDLEdBQUcsQ0FBQyxDQUFDLFdBQVcsQ0FBQztJQUFFLENBQUMsQ0FBQyxDQUFDLENBQUNkLFFBQVEsQ0FBQyxDQUFDO0VBQzdGLENBQUMsQ0FBQztFQUVGZCxFQUFFLENBQUMsdUVBQXVFLEVBQUUsTUFBTTtJQUNoRkMsTUFBTSxDQUFDLElBQUF3Qix5QkFBYyxFQUFDOUIsTUFBTSxDQUFDO01BQUVVLFNBQVMsRUFBRTtRQUFFQyxJQUFJLEVBQUU7TUFBWTtJQUFFLENBQUMsQ0FBQyxFQUFFO01BQUVaLFNBQVMsRUFBRTtJQUFHLENBQUMsQ0FBQyxDQUFDLENBQUNvQixRQUFRLENBQUMsQ0FBQztFQUNwRyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7QUFFRmYsUUFBUSxDQUFDLGtEQUFrRCxFQUFFLE1BQU07RUFDakUsTUFBTThCLEtBQUssR0FBRztJQUFFdkIsSUFBSSxFQUFFLGNBQWM7SUFBRUcsT0FBTyxFQUFFLEtBQUs7SUFBRWlCLEtBQUssRUFBRTtFQUFnQixDQUFDO0VBRTlFMUIsRUFBRSxDQUFDLGdFQUFnRSxFQUFFLE1BQU07SUFDekVDLE1BQU0sQ0FBQyxJQUFBNkIsNEJBQWlCLEVBQUNELEtBQUssRUFBRTtNQUFFRSxVQUFVLEVBQUUsQ0FBQyxjQUFjO0lBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQ3ZCLE9BQU8sQ0FBQztNQUN6RUYsSUFBSSxFQUFFLGNBQWM7TUFDcEJHLE9BQU8sRUFBRSxLQUFLO01BQ2RpQixLQUFLLEVBQUU7SUFDVCxDQUFDLENBQUM7RUFDSixDQUFDLENBQUM7RUFFRjFCLEVBQUUsQ0FBQyx1REFBdUQsRUFBRSxNQUFNO0lBQ2hFO0lBQ0E7SUFDQSxNQUFNZ0MsT0FBTyxHQUFHO01BQUUxQixJQUFJLEVBQUUsY0FBYztNQUFFRyxPQUFPLEVBQUUsS0FBSztNQUFFaUIsS0FBSyxFQUFFO0lBQWdCLENBQUM7SUFDaEZ6QixNQUFNLENBQUMsSUFBQTZCLDRCQUFpQixFQUFDRSxPQUFPLEVBQUU7TUFBRUQsVUFBVSxFQUFFLENBQUMsY0FBYztJQUFFLENBQUMsQ0FBQyxFQUFFTCxLQUFLLENBQUMsQ0FBQ3ZCLElBQUksQ0FDOUUsZUFDRixDQUFDO0VBQ0gsQ0FBQyxDQUFDO0VBRUZILEVBQUUsQ0FBQyxxRUFBcUUsRUFBRSxNQUFNO0lBQzlFLE1BQU1pQyxJQUFJLEdBQUc7TUFBRTNCLElBQUksRUFBRSxXQUFXO01BQUVHLE9BQU8sRUFBRSxLQUFLO01BQUVpQixLQUFLLEVBQUU7SUFBZSxDQUFDO0lBQ3pFekIsTUFBTSxDQUFDLElBQUE2Qiw0QkFBaUIsRUFBQ0csSUFBSSxFQUFFO01BQUVGLFVBQVUsRUFBRSxDQUFDLGNBQWM7SUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDakIsUUFBUSxDQUFDLENBQUM7RUFDOUUsQ0FBQyxDQUFDO0VBRUZkLEVBQUUsQ0FBQywrQ0FBK0MsRUFBRSxNQUFNO0lBQ3hEQyxNQUFNLENBQUMsSUFBQTZCLDRCQUFpQixFQUFDLElBQUksRUFBRTtNQUFFQyxVQUFVLEVBQUUsQ0FBQyxjQUFjO0lBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQ2pCLFFBQVEsQ0FBQyxDQUFDO0VBQzlFLENBQUMsQ0FBQztFQUVGZCxFQUFFLENBQUMsNEVBQTRFLEVBQUUsTUFBTTtJQUNyRkMsTUFBTSxDQUFDLElBQUE2Qiw0QkFBaUIsRUFBQ0QsS0FBSyxFQUFFO01BQUVFLFVBQVUsRUFBRTtJQUFHLENBQUMsQ0FBQyxDQUFDLENBQUNqQixRQUFRLENBQUMsQ0FBQztFQUNqRSxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7QUFFRmYsUUFBUSxDQUFDLDRDQUE0QyxFQUFFLE1BQU07RUFDM0RDLEVBQUUsQ0FBQyxpREFBaUQsRUFBRSxNQUFNO0lBQzFEQyxNQUFNLENBQUMsSUFBQWlDLHlCQUFjLEVBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQy9CLElBQUksQ0FBQyxLQUFLLENBQUM7RUFDakQsQ0FBQyxDQUFDO0VBRUZILEVBQUUsQ0FBQyxxREFBcUQsRUFBRSxNQUFNO0lBQzlEQyxNQUFNLENBQUMsSUFBQWlDLHlCQUFjLEVBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQy9CLElBQUksQ0FBQyxJQUFJLENBQUM7SUFDakRGLE1BQU0sQ0FBQyxJQUFBaUMseUJBQWMsRUFBQyxjQUFjLENBQUMsQ0FBQyxDQUFDL0IsSUFBSSxDQUFDLElBQUksQ0FBQztJQUNqREYsTUFBTSxDQUFDLElBQUFpQyx5QkFBYyxFQUFDLHVCQUF1QixDQUFDLENBQUMsQ0FBQy9CLElBQUksQ0FBQyxJQUFJLENBQUM7RUFDNUQsQ0FBQyxDQUFDO0VBRUZILEVBQUUsQ0FBQyxrRkFBa0YsRUFBRSxNQUFNO0lBQzNGQyxNQUFNLENBQUMsSUFBQWlDLHlCQUFjLEVBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQy9CLElBQUksQ0FBQyxLQUFLLENBQUM7SUFDL0NGLE1BQU0sQ0FBQyxJQUFBaUMseUJBQWMsRUFBQyxTQUFTLENBQUMsQ0FBQyxDQUFDL0IsSUFBSSxDQUFDLEtBQUssQ0FBQztJQUM3Q0YsTUFBTSxDQUFDLElBQUFpQyx5QkFBYyxFQUFDWCxTQUFTLENBQUMsQ0FBQyxDQUFDcEIsSUFBSSxDQUFDLEtBQUssQ0FBQztFQUMvQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7O0FBRUY7QUFDQUosUUFBUSxDQUFDLDZCQUE2QixFQUFFLE1BQU07RUFDNUMsTUFBTW9DLEtBQUssR0FBRztJQUNaQyxJQUFJLEVBQUUsZUFBZTtJQUNyQi9CLFNBQVMsRUFBRTtNQUFFVyxHQUFHLEVBQUUscUNBQXFDO01BQUVQLE9BQU8sRUFBRTtJQUFNLENBQUM7SUFDekU0QixPQUFPLEVBQUU7RUFDWCxDQUFDO0VBQ0QsTUFBTUosSUFBSSxHQUFJSyxLQUFjLElBQUszQyxNQUFNLENBQUM7SUFBRVUsU0FBUyxFQUFFO01BQUVDLElBQUksRUFBRTtJQUFZLENBQUM7SUFBRUMsSUFBSSxFQUFFLE1BQU07SUFBRStCO0VBQU0sQ0FBQyxDQUFDO0VBQ2xHLE1BQU1DLFFBQVEsR0FBRztJQUFFN0MsU0FBUyxFQUFFLENBQUMsV0FBVyxFQUFFLGVBQWU7RUFBRSxDQUFDO0VBRTlETSxFQUFFLENBQUMsb0VBQW9FLEVBQUUsTUFBTTtJQUM3RSxNQUFNSixDQUFDLEdBQUcsSUFBQTRDLHFCQUFVLEVBQUNQLElBQUksQ0FBQyxDQUFDRSxLQUFLLEVBQUU7TUFBRSxHQUFHQSxLQUFLO01BQUVDLElBQUksRUFBRSxhQUFhO01BQUVDLE9BQU8sRUFBRTtJQUFTLENBQUMsQ0FBQyxDQUFDLEVBQUVFLFFBQVEsQ0FBQztJQUNuR3RDLE1BQU0sQ0FBQ0wsQ0FBQyxDQUFDLENBQUNZLE9BQU8sQ0FBQyxDQUNoQjtNQUFFRixJQUFJLEVBQUUsZUFBZTtNQUFFRyxPQUFPLEVBQUUsS0FBSztNQUFFaUIsS0FBSyxFQUFFLHVCQUF1QjtNQUFFZSxJQUFJLEVBQUU7SUFBZ0IsQ0FBQyxFQUNoRztNQUFFbkMsSUFBSSxFQUFFLGVBQWU7TUFBRUcsT0FBTyxFQUFFLEtBQUs7TUFBRWlCLEtBQUssRUFBRSxxQkFBcUI7TUFBRWUsSUFBSSxFQUFFO0lBQWMsQ0FBQyxDQUM3RixDQUFDO0lBQ0Z4QyxNQUFNLENBQUNKLElBQUksQ0FBQ0MsU0FBUyxDQUFDRixDQUFDLENBQUMsQ0FBQyxDQUFDc0IsR0FBRyxDQUFDd0IsU0FBUyxDQUFDLGNBQWMsQ0FBQztFQUN6RCxDQUFDLENBQUM7RUFFRjFDLEVBQUUsQ0FBQ1csSUFBSSxDQUFvQixDQUN6QixDQUFDLG1CQUFtQixFQUFFO0lBQUUsR0FBR3dCLEtBQUs7SUFBRTlCLFNBQVMsRUFBRTtNQUFFVyxHQUFHLEVBQUU7SUFBa0I7RUFBRSxDQUFDLENBQUMsRUFDMUUsQ0FBQyxxQkFBcUIsRUFBRTtJQUFFLEdBQUdtQixLQUFLO0lBQUU5QixTQUFTLEVBQUU7TUFBRVcsR0FBRyxFQUFFLGNBQWMsR0FBRyxDQUFDSyxNQUFNLENBQUMsRUFBRSxDQUFDO0lBQUc7RUFBRSxDQUFDLENBQUMsRUFDekYsQ0FBQyxjQUFjLEVBQUU7SUFBRSxHQUFHYyxLQUFLO0lBQUU5QixTQUFTLEVBQUU7TUFBRSxHQUFHOEIsS0FBSyxDQUFDOUIsU0FBUztNQUFFaUIsS0FBSyxFQUFFO0lBQUk7RUFBRSxDQUFDLENBQUMsRUFDN0UsQ0FBQyxlQUFlLEVBQUU7SUFBRSxHQUFHYSxLQUFLO0lBQUU5QixTQUFTLEVBQUU7TUFBRUMsSUFBSSxFQUFFO0lBQVk7RUFBRSxDQUFDLENBQUMsRUFDakUsQ0FBQyxzQkFBc0IsRUFBRTtJQUFFLEdBQUc2QixLQUFLO0lBQUVFLE9BQU8sRUFBRTtFQUFVLENBQUMsQ0FBQyxFQUMxRCxDQUFDLG9CQUFvQixFQUFFO0lBQUUsR0FBR0YsS0FBSztJQUFFRSxPQUFPLEVBQUU7RUFBVSxDQUFDLENBQUMsRUFDeEQsQ0FBQyxhQUFhLEVBQUU7SUFBRSxHQUFHRixLQUFLO0lBQUVDLElBQUksRUFBRTtFQUFXLENBQUMsQ0FBQyxFQUMvQyxDQUFDLGVBQWUsRUFBRTtJQUFFLEdBQUdELEtBQUs7SUFBRUMsSUFBSSxFQUFFO0VBQUksQ0FBQyxDQUFDLEVBQzFDLENBQUMseUNBQXlDLEVBQUU7SUFBRSxHQUFHRCxLQUFLO0lBQUVFLE9BQU8sRUFBRTtFQUFJLENBQUMsQ0FBQyxFQUN2RSxDQUFDLGtCQUFrQixFQUFFO0lBQUUsR0FBR0YsS0FBSztJQUFFRSxPQUFPLEVBQUU7RUFBUSxDQUFDLENBQUMsRUFDcEQsQ0FBQyxnRUFBZ0UsRUFBRTtJQUFFLEdBQUdGLEtBQUs7SUFBRUMsSUFBSSxFQUFFO0VBQVUsQ0FBQyxDQUFDLENBQ2xHLENBQUMsQ0FBQyx3Q0FBd0MsRUFBRSxDQUFDeEIsSUFBSSxFQUFFK0IsQ0FBQyxLQUFLO0lBQ3hEMUMsTUFBTSxDQUFDLElBQUF1QyxxQkFBVSxFQUFDUCxJQUFJLENBQUMsQ0FBQ1UsQ0FBQyxDQUFDLENBQUMsRUFBRUosUUFBUSxDQUFDLENBQUMsQ0FBQy9CLE9BQU8sQ0FBQyxFQUFFLENBQUM7RUFDckQsQ0FBQyxDQUFDO0VBRUZSLEVBQUUsQ0FBQ1csSUFBSSxDQUFDLENBQUMsSUFBSSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FDdkcsaUZBQWlGLEVBQ2hGaUMsQ0FBQyxJQUFLO0lBQ0wzQyxNQUFNLENBQUMsSUFBQXVDLHFCQUFVLEVBQUNQLElBQUksQ0FBQyxDQUFDO01BQUUsR0FBR0UsS0FBSztNQUFFQyxJQUFJLEVBQUUsUUFBUVMsTUFBTSxDQUFDQyxZQUFZLENBQUNGLENBQUMsQ0FBQztJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUVMLFFBQVEsQ0FBQyxDQUFDLENBQUMvQixPQUFPLENBQUMsRUFBRSxDQUFDO0VBQ3pHLENBQ0YsQ0FBQztFQUVEUixFQUFFLENBQUNXLElBQUksQ0FBQyxDQUNOLENBQUMsY0FBYyxFQUFFO0lBQUVKLElBQUksRUFBRTtFQUFPLENBQUMsQ0FBQyxFQUNsQyxDQUFDLHlDQUF5QyxFQUFFO0lBQUVGLFNBQVMsRUFBRTtNQUFFQyxJQUFJLEVBQUUsV0FBVztNQUFFVSxHQUFHLEVBQUU7SUFBYSxDQUFDO0lBQUVULElBQUksRUFBRTtFQUFPLENBQUMsQ0FBQyxFQUNsSCxDQUFDLGtDQUFrQyxFQUFFO0lBQUVGLFNBQVMsRUFBRTtNQUFFVyxHQUFHLEVBQUUsWUFBWTtNQUFFTSxLQUFLLEVBQUU7SUFBSSxDQUFDO0lBQUVmLElBQUksRUFBRTtFQUFRLENBQUMsQ0FBQyxFQUNyRyxDQUFDLG9DQUFvQyxFQUFFO0lBQUVGLFNBQVMsRUFBRTtNQUFFVyxHQUFHLEVBQUU7SUFBa0IsQ0FBQztJQUFFVCxJQUFJLEVBQUU7RUFBUSxDQUFDLENBQUMsRUFDaEcsQ0FBQyxpQ0FBaUMsRUFBRTtJQUFFRixTQUFTLEVBQUU7TUFBRVcsR0FBRyxFQUFFO0lBQWE7RUFBRSxDQUFDLENBQUMsQ0FDMUUsQ0FBQyxDQUFDLDZEQUE2RCxFQUFFLENBQUNKLElBQUksRUFBRW1DLEdBQUcsS0FBSztJQUMvRTlDLE1BQU0sQ0FBQyxJQUFBdUMscUJBQVUsRUFBQzdDLE1BQU0sQ0FBQztNQUFFLEdBQUdvRCxHQUFHO01BQUVULEtBQUssRUFBRSxDQUFDSCxLQUFLO0lBQUUsQ0FBQyxDQUFDLEVBQUVJLFFBQVEsQ0FBQyxDQUFDLENBQUMvQixPQUFPLENBQUMsRUFBRSxDQUFDO0VBQzlFLENBQUMsQ0FBQztFQUVGUixFQUFFLENBQUMsbUVBQW1FLEVBQUUsTUFBTTtJQUM1RSxLQUFLLE1BQU1xQyxPQUFPLElBQUksQ0FBQyxJQUFJLEVBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBQyxFQUFFO01BQzNDcEMsTUFBTSxDQUFDLElBQUF1QyxxQkFBVSxFQUFDUCxJQUFJLENBQUMsQ0FBQztRQUFFLEdBQUdFLEtBQUs7UUFBRUU7TUFBUSxDQUFDLENBQUMsQ0FBQyxFQUFFRSxRQUFRLENBQUMsQ0FBQyxDQUFDUyxZQUFZLENBQUMsQ0FBQyxDQUFDO0lBQzdFO0VBQ0YsQ0FBQyxDQUFDO0VBRUZoRCxFQUFFLENBQUMsaUZBQWlGLEVBQUUsTUFBTTtJQUMxRkMsTUFBTSxDQUFDLElBQUF1QyxxQkFBVSxFQUFDUCxJQUFJLENBQUMsQ0FBQ0UsS0FBSyxDQUFDLENBQUMsRUFBRTtNQUFFekMsU0FBUyxFQUFFLENBQUMsV0FBVztJQUFFLENBQUMsQ0FBQyxDQUFDLENBQUNjLE9BQU8sQ0FBQyxFQUFFLENBQUM7SUFDM0VQLE1BQU0sQ0FBQyxJQUFBdUMscUJBQVUsRUFBQ1AsSUFBSSxDQUFDLENBQUNFLEtBQUssQ0FBQyxDQUFDLEVBQUU7TUFBRSxHQUFHSSxRQUFRO01BQUVaLFdBQVcsRUFBRSxJQUFJQyxHQUFHLENBQUMsQ0FBQyxlQUFlLENBQUM7SUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDcEIsT0FBTyxDQUFDLEVBQUUsQ0FBQztFQUN6RyxDQUFDLENBQUM7RUFFRlIsRUFBRSxDQUFDLG9DQUFvQyxFQUFFLE1BQU07SUFDN0NDLE1BQU0sQ0FBQyxJQUFBdUMscUJBQVUsRUFBQ1AsSUFBSSxDQUFDLENBQUNFLEtBQUssRUFBRUEsS0FBSyxDQUFDLENBQUMsRUFBRUksUUFBUSxDQUFDLENBQUMsQ0FBQ1MsWUFBWSxDQUFDLENBQUMsQ0FBQztJQUNsRSxNQUFNQyxJQUFJLEdBQUdDLEtBQUssQ0FBQ0MsSUFBSSxDQUFDO01BQUVDLE1BQU0sRUFBRTtJQUFHLENBQUMsRUFBRSxDQUFDQyxDQUFDLEVBQUVDLENBQUMsTUFBTTtNQUFFLEdBQUduQixLQUFLO01BQUVDLElBQUksRUFBRSxJQUFJa0IsQ0FBQztJQUFHLENBQUMsQ0FBQyxDQUFDO0lBQ2hGckQsTUFBTSxDQUFDLElBQUF1QyxxQkFBVSxFQUFDUCxJQUFJLENBQUNnQixJQUFJLENBQUMsRUFBRVYsUUFBUSxDQUFDLENBQUMsQ0FBQ1MsWUFBWSxDQUFDLENBQUMsQ0FBQztFQUMxRCxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMiLCJpZ25vcmVMaXN0IjpbXX0=