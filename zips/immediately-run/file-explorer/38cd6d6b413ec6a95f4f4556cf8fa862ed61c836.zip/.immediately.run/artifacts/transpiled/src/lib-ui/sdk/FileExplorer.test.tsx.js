var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.drop.js");
require("core-js/modules/esnext.iterator.map.js");
var _react = require("@testing-library/react");
var _userEvent = _interopRequireDefault(require("@testing-library/user-event"));
var _vitest = require("vitest");
var _SdkFileExplorer = _interopRequireDefault(require("./SdkFileExplorer"));
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// FX-3 regression guard for the file-explorer rendering/expansion fixes.
//
// Covers the two reported defects and the selection indicator:
// - FX-2: clicking a file in an expanded subdirectory must NOT collapse it, and
//   opens it with the repo-relative path.
// - FX-4a: the clicked row is marked selected, and the selection survives a
//   benign worktree re-announce.
// - FX-1 (no-remount proxy): a benign worktree re-announce (a new mount object
//   with the same path) must not remount/reload the tree — asserted via the
//   `readdir` call count staying flat and expansion being preserved.

// A two-level fixture tree; `readdir` resolves from it.
const TREE = {
  "/mnt/abc": [{
    name: "src",
    isDir: true
  }, {
    name: "README.md",
    isDir: false
  }],
  "/mnt/abc/src": [{
    name: "index.ts",
    isDir: false
  }, {
    name: "util.ts",
    isDir: false
  }],
  "/spaces/s1": [{
    name: "note.md",
    isDir: false
  }]
};

// Mutable test doubles, shared with the hoisted module mocks below.
const h = _vitest.vi.hoisted(() => ({
  // Raw host->app message listeners (the mocked sandboxUtils.addListener registry).
  rawListeners: new Map(),
  emit(type, msg) {
    for (const fn of h.rawListeners.get(type) ?? []) fn(msg);
  },
  mounts: [],
  // The first-party Session-lens list (R3-95). Default none: a non-first-party frame
  // (a fork) receives `[]`, so the "App | Session" toggle never renders.
  sessionMounts: [],
  // The editor-context active file (FX-4b). Mutable so a test can move it and
  // re-render, mirroring a host push.
  activeFile: null,
  // The stage's viewed-document hint (R3-268), pushed on the same channel.
  viewedFile: null,
  // The arg is recorded by the spy via the factory call below, so the impl needs
  // no param; assertions use `toHaveBeenCalledWith`.
  openInEditor: _vitest.vi.fn(() => Promise.resolve()),
  // R3-440: reportReady — recorded, with the subscription state captured AT the
  // call so the ordering contract ("report immediately after subscribing") is
  // assertable rather than assumed.
  reportReady: _vitest.vi.fn(() => {
    h.reportReadyListenerCount.push(h.rawListeners.get("viewed-reveal")?.size ?? 0);
  }),
  reportReadyListenerCount: [],
  deleteEntry: _vitest.vi.fn(() => Promise.resolve()),
  renameEntry: _vitest.vi.fn(() => Promise.resolve()),
  uploadFile: _vitest.vi.fn(() => Promise.resolve()),
  startItemDrag: _vitest.vi.fn(() => Promise.resolve()),
  cancelItemDrag: _vitest.vi.fn(() => {}),
  readdir: _vitest.vi.fn(path => Promise.resolve(TREE[path] ?? [])),
  listSettingsApps: _vitest.vi.fn(() => Promise.resolve([])),
  // R3-269 D5: the host powerbox request. Never resolves by default — the flow is
  // host-owned; these tests only assert the app ASKS.
  requestMount: _vitest.vi.fn(() => new Promise(() => {})),
  // The app's RegionId (R3-96): `page.commander` makes the app default to the broad
  // registry lens. Default null (a `panel.files` projection behaves App-first as before).
  region: null
}));

// The subpath module the reveal listener rides. The REAL sandboxUtils cannot load
// under vitest (tsup extensionless specifiers), and mocking it here also gives the
// suite a controllable host->app channel: push with h.emit('viewed-reveal', msg).
_vitest.vi.mock("@immediately-run/sdk/sandboxUtils", () => ({
  addListener: (type, handler) => {
    const set = h.rawListeners.get(type) ?? new Set();
    set.add(handler);
    h.rawListeners.set(type, set);
    return () => set.delete(handler);
  },
  sendMessage: _vitest.vi.fn()
}));
_vitest.vi.mock("@immediately-run/sdk", () => ({
  useMounts: () => h.mounts,
  useSessionMounts: () => h.sessionMounts,
  useEditorContext: () => ({
    dirtyPaths: [],
    openFiles: [],
    activeFile: h.activeFile,
    viewedFile: h.viewedFile
  }),
  openInEditor: path => h.openInEditor(path),
  createFile: _vitest.vi.fn(() => Promise.resolve()),
  createFolder: _vitest.vi.fn(() => Promise.resolve()),
  deleteEntry: path => h.deleteEntry(path),
  renameEntry: (from, to) => h.renameEntry(from, to),
  uploadFile: (path, bytes) => h.uploadFile(path, bytes),
  startItemDrag: item => h.startItemDrag(item),
  cancelItemDrag: () => h.cancelItemDrag(),
  unmountSpace: _vitest.vi.fn(() => Promise.resolve()),
  // settings:all enumeration — default to none so the base file tree is unaffected.
  listSettingsApps: () => h.listSettingsApps(),
  openSettingsOf: _vitest.vi.fn(() => Promise.resolve({
    type: "firestore",
    path: "/mnt/set",
    id: "settings:x"
  })),
  requestMount: () => h.requestMount(),
  useRegion: () => h.region,
  // R3-440: the readiness report the host gates the viewed-reveal one-shot on.
  // The mock asserts the CONTRACT at call time: the reveal listener must already
  // be subscribed (a report before it would release reveals nobody hears).
  reportReady: () => h.reportReady()
}));
_vitest.vi.mock("./mountFs", () => ({
  readdir: path => h.readdir(path),
  readFile: () => Promise.resolve(new Uint8Array([1, 2, 3])),
  sdkFsSource: {
    readdir: path => h.readdir(path),
    readFile: () => Promise.resolve(new Uint8Array([1, 2, 3]))
  }
}));
const worktree = (id = "repo") => ({
  type: "worktree",
  path: "/mnt/abc",
  id
});
(0, _vitest.beforeEach)(() => {
  h.mounts = [worktree()];
  h.sessionMounts = [];
  h.activeFile = null;
  h.viewedFile = null;
  h.rawListeners.clear();
  h.region = null;
  h.openInEditor.mockClear();
  h.readdir.mockClear();
});
(0, _vitest.afterEach)(() => {
  _vitest.vi.clearAllMocks();
});

/** Render, wait for the root to load, expand `src`, wait for its children.
 *  When `activeFile` points into `src`, the editor-active reveal has already
 *  opened it — clicking again would CLOSE it, so only click when still closed. */
async function renderWithSrcExpanded() {
  const user = _userEvent.default.setup();
  const utils = (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
  // Root is open by default → top-level entries appear.
  await _react.screen.findByText("src");
  const src = _react.screen.getByRole("treeitem", {
    name: "src"
  });
  if (src.getAttribute("aria-expanded") !== "true") {
    await user.click(_react.screen.getByText("src"));
  }
  // Subdirectory children appear once readdir resolves.
  await _react.screen.findByText("index.ts");
  return {
    user,
    ...utils
  };
}
(0, _vitest.describe)("FileExplorer", () => {
  (0, _vitest.it)("FX-2: clicking a file in a subdirectory keeps the subdirectory open", async () => {
    const {
      user
    } = await renderWithSrcExpanded();
    await user.click(_react.screen.getByText("index.ts"));

    // Opened with the repo-relative path (mount prefix stripped), not /mnt/...
    (0, _vitest.expect)(h.openInEditor).toHaveBeenCalledTimes(1);
    (0, _vitest.expect)(h.openInEditor).toHaveBeenCalledWith("/src/index.ts");

    // The subdirectory is still expanded and its contents still visible.
    // (The treeitem is the row element; its child rows live in the sibling
    // group, so scope the query to the row's list item.)
    const src = _react.screen.getByRole("treeitem", {
      name: "src"
    });
    (0, _vitest.expect)(src).toHaveAttribute("aria-expanded", "true");
    const srcItem = src.closest("li");
    (0, _vitest.expect)((0, _react.within)(srcItem).getByText("index.ts")).toBeInTheDocument();
    (0, _vitest.expect)((0, _react.within)(srcItem).getByText("util.ts")).toBeInTheDocument();
  });
  (0, _vitest.it)("FX-4a: the clicked file is marked selected and stays selected across a re-announce", async () => {
    const {
      user,
      rerender
    } = await renderWithSrcExpanded();
    await user.click(_react.screen.getByText("index.ts"));
    (0, _vitest.expect)(_react.screen.getByRole("treeitem", {
      name: "index.ts"
    })).toHaveAttribute("aria-selected", "true");

    // A benign worktree re-announce: a NEW mount object, same path.
    h.mounts = [worktree()];
    rerender(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    (0, _vitest.expect)(_react.screen.getByRole("treeitem", {
      name: "index.ts"
    })).toHaveAttribute("aria-selected", "true");
    (0, _vitest.expect)(_react.screen.getByRole("treeitem", {
      name: "src"
    })).toHaveAttribute("aria-expanded", "true");
  });
  (0, _vitest.it)("FX-4b: the editor's active file is highlighted, and the highlight moves without collapsing the tree", async () => {
    h.activeFile = "/src/index.ts";
    const {
      rerender
    } = await renderWithSrcExpanded();
    const rowOf = name => _react.screen.getByText(name).closest("div.tnode");

    // The active file's row is marked --active (distinct from selection); a sibling
    // file in the same open directory is not.
    (0, _vitest.expect)(rowOf("index.ts")).toHaveClass("tnode--active");
    (0, _vitest.expect)(rowOf("index.ts")).toHaveAttribute("aria-current", "true");
    (0, _vitest.expect)(rowOf("util.ts")).not.toHaveClass("tnode--active");
    // Active highlight is independent of explorer selection — nothing was clicked.
    (0, _vitest.expect)(_react.screen.getByRole("treeitem", {
      name: "index.ts"
    })).not.toHaveAttribute("aria-selected", "true");

    // The host moves the active file → the highlight follows, and `src` stays open
    // (no remount, no collapse).
    h.activeFile = "/src/util.ts";
    rerender(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    (0, _vitest.expect)(rowOf("util.ts")).toHaveClass("tnode--active");
    (0, _vitest.expect)(rowOf("index.ts")).not.toHaveClass("tnode--active");
    (0, _vitest.expect)(_react.screen.getByRole("treeitem", {
      name: "src"
    })).toHaveAttribute("aria-expanded", "true");
  });
  (0, _vitest.it)("FX-1: a benign worktree re-announce does not reload or collapse the tree", async () => {
    const {
      rerender
    } = await renderWithSrcExpanded();

    // readdir was called once for the root and once for src.
    const callsBefore = h.readdir.mock.calls.length;
    (0, _vitest.expect)(callsBefore).toBe(2);
    h.mounts = [worktree()]; // new object, same path
    rerender(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));

    // No remount/reload: readdir is not called again, and src stays expanded.
    (0, _vitest.expect)(h.readdir.mock.calls.length).toBe(callsBefore);
    (0, _vitest.expect)(_react.screen.getByRole("treeitem", {
      name: "src"
    })).toHaveAttribute("aria-expanded", "true");
    (0, _vitest.expect)(_react.screen.getByText("index.ts")).toBeInTheDocument();
  });
  (0, _vitest.it)("clicking a file does not trigger a directory reload", async () => {
    const {
      user
    } = await renderWithSrcExpanded();
    const callsBefore = h.readdir.mock.calls.length;
    await user.click(_react.screen.getByText("index.ts"));
    (0, _vitest.expect)(h.readdir.mock.calls.length).toBe(callsBefore);
  });
});

// --- R3-79: multiple mounts -------------------------------------------------
const space = () => ({
  type: "space",
  path: "/spaces/s1",
  id: "s1",
  name: "Shared notes",
  mode: "ro"
});
(0, _vitest.describe)("R3-79 — multiple mounts", () => {
  (0, _vitest.beforeEach)(() => {
    h.mounts = [worktree(), space()];
  });
  (0, _vitest.it)("renders one scope per mount (worktree + space)", async () => {
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    (0, _vitest.expect)(await _react.screen.findByRole("tree", {
      name: "repo"
    })).toBeInTheDocument();
    (0, _vitest.expect)(_react.screen.getByRole("tree", {
      name: "Shared notes"
    })).toBeInTheDocument();
  });
  (0, _vitest.it)("a read-only space mount shows a read-only chip and no delete affordance", async () => {
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    const spaceTree = await _react.screen.findByRole("tree", {
      name: "Shared notes"
    });
    const scope = spaceTree.closest(".mount");
    (0, _vitest.expect)((0, _react.within)(scope).getByText(/read-only/)).toBeInTheDocument();
    // The space scope root row has no delete button (read-only).
    (0, _vitest.expect)((0, _react.within)(scope).queryByLabelText(/^Delete /)).not.toBeInTheDocument();
  });
  (0, _vitest.it)("a revoked mount's scope disappears within one re-announce", async () => {
    const {
      rerender
    } = (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    (0, _vitest.expect)(await _react.screen.findByRole("tree", {
      name: "Shared notes"
    })).toBeInTheDocument();
    h.mounts = [worktree()]; // space unshared
    rerender(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    (0, _vitest.expect)(_react.screen.queryByRole("tree", {
      name: "Shared notes"
    })).not.toBeInTheDocument();
    (0, _vitest.expect)(_react.screen.getByRole("tree", {
      name: "repo"
    })).toBeInTheDocument();
  });
});

// --- R3-94: App-scope per-mount header (PRINCIPALS §9 B1 / FILE_EXPLORER §2) ----
(0, _vitest.describe)("R3-94 — app-scope per-mount header", () => {
  (0, _vitest.it)("lists one mode chip per granted subtree, each read-only on a non-worktree mount", async () => {
    h.mounts = [{
      type: "firestore",
      path: "/spaces/s1",
      id: "space:s1",
      name: "Shared notes",
      mode: "ro",
      rules: [{
        subtree: "/notes",
        mode: "rw"
      }, {
        subtree: "/drafts",
        mode: "ro"
      }]
    }];
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    const scope = (await _react.screen.findByRole("tree", {
      name: "Shared notes"
    })).closest(".mount");
    const chips = (0, _react.within)(scope).getAllByText(/read-only|read-write/);
    // One chip per subtree, and a granted `rw` subtree is still shown read-only (v1:
    // only the worktree is writable — never shown-then-EROFS).
    // Ordered root-first then A→Z (here: /drafts before /notes).
    (0, _vitest.expect)(chips.map(c => c.textContent)).toEqual([_vitest.expect.stringContaining("/drafts · read-only"), _vitest.expect.stringContaining("/notes · read-only")]);
  });
  (0, _vitest.it)("the worktree header shows a single read-write whole-mount chip", async () => {
    h.mounts = [worktree()];
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    const scope = (await _react.screen.findByRole("tree", {
      name: "repo"
    })).closest(".mount");
    const chips = (0, _react.within)(scope).getAllByText(/read-only|read-write/);
    (0, _vitest.expect)(chips).toHaveLength(1);
    (0, _vitest.expect)(chips[0].textContent).toContain("/ · read-write");
  });
});

// --- R3-80: context menu ----------------------------------------------------
(0, _vitest.describe)("R3-80 — context menu", () => {
  (0, _vitest.it)("right-clicking a worktree file opens a menu with Open + write actions", async () => {
    const {
      user
    } = await renderWithSrcExpanded();
    _react.fireEvent.contextMenu(_react.screen.getByText("index.ts"));
    const menu = await _react.screen.findByRole("menu");
    for (const label of ["Open", "New file here", "New folder here", "Rename…", "Delete"]) {
      (0, _vitest.expect)((0, _react.within)(menu).getByRole("menuitem", {
        name: new RegExp(label)
      })).toBeInTheDocument();
    }
    // Delete from the menu confirms then calls deleteEntry with the mount-rel path.
    const confirm = _vitest.vi.spyOn(window, "confirm").mockReturnValue(true);
    await user.click((0, _react.within)(menu).getByRole("menuitem", {
      name: /Delete/
    }));
    (0, _vitest.expect)(h.deleteEntry).toHaveBeenCalledWith("/src/index.ts");
    confirm.mockRestore();
  });

  // The confirm is the only thing between a click and a lost file, and the row's
  // disappearance is the user's evidence the delete happened. Cancelling must
  // therefore change nothing at all — no intent, and the row still there. Asserted
  // because it was reached for by hand (2026-09-13) and had no guard.
  (0, _vitest.it)("cancelling the delete confirm removes nothing and leaves the row in place", async () => {
    const user = _userEvent.default.setup();
    await renderWithSrcExpanded();
    const confirm = _vitest.vi.spyOn(window, "confirm").mockReturnValue(false);
    _react.fireEvent.contextMenu(_react.screen.getByText("index.ts"));
    const menu = await _react.screen.findByRole("menu");
    await user.click((0, _react.within)(menu).getByRole("menuitem", {
      name: /^Delete/
    }));
    (0, _vitest.expect)(h.deleteEntry).not.toHaveBeenCalled();
    (0, _vitest.expect)(_react.screen.getByRole("treeitem", {
      name: "index.ts"
    })).toBeInTheDocument();
    confirm.mockRestore();
  });
  (0, _vitest.it)("a read-only space file's menu offers only Open (no write actions)", async () => {
    h.mounts = [space()];
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    // The space root is open by default → its file appears once readdir resolves.
    _react.fireEvent.contextMenu(await _react.screen.findByText("note.md"));
    const menu = await _react.screen.findByRole("menu");
    (0, _vitest.expect)((0, _react.within)(menu).getByRole("menuitem", {
      name: /Open/
    })).toBeInTheDocument();
    (0, _vitest.expect)((0, _react.within)(menu).queryByRole("menuitem", {
      name: /New file here/
    })).not.toBeInTheDocument();
    (0, _vitest.expect)((0, _react.within)(menu).queryByRole("menuitem", {
      name: /Delete/
    })).not.toBeInTheDocument();
  });
});

// --- R3-269 D4/D5/D6 — the explorer as the spaces entry point ----------------
(0, _vitest.describe)("R3-269 — add-a-space + manage-sharing entry points", () => {
  (0, _vitest.it)("the header's 'Add a space…' asks the HOST powerbox (requestMount)", async () => {
    const user = _userEvent.default.setup();
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    await _react.screen.findByText("src");
    await user.click(_react.screen.getByRole("button", {
      name: "Add a space…"
    }));
    (0, _vitest.expect)(h.requestMount).toHaveBeenCalledTimes(1);
  });
  (0, _vitest.it)("the empty state carries the first-timer sentence + an Add-a-space action", async () => {
    h.mounts = [];
    const user = _userEvent.default.setup();
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    // D6 copy, R-SPACES-1 vocabulary (space/folder — never mount/filesystem).
    const copy = await _react.screen.findByText(/A space is a folder that lives in your account/);
    const state = copy.closest(".state");
    await user.click((0, _react.within)(state).getByRole("button", {
      name: /Add a space…/
    }));
    (0, _vitest.expect)(h.requestMount).toHaveBeenCalled();
  });
  (0, _vitest.it)("a space ROOT row's menu offers 'Manage sharing →' opening /spaces at that space", async () => {
    // getHostOrigin() reads the iframe's `?href=` boot param — simulate the sandbox URL.
    window.history.replaceState({}, "", "/?href=" + encodeURIComponent("https://immediately.run/edit/github/a/b/main/"));
    const open = _vitest.vi.spyOn(window, "open").mockReturnValue(null);
    try {
      h.mounts = [{
        type: "space",
        path: "/spaces/s1",
        id: "space:s1",
        name: "Shared notes"
      }];
      const user = _userEvent.default.setup();
      (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
      // The label appears in the scope header AND as the tree's root row — the row
      // (inside role=tree) is the one carrying the context menu.
      const tree = await _react.screen.findByRole("tree", {
        name: "Shared notes"
      });
      _react.fireEvent.contextMenu((0, _react.within)(tree).getByText("Shared notes"));
      const menu = await _react.screen.findByRole("menu");
      await user.click((0, _react.within)(menu).getByRole("menuitem", {
        name: /Manage sharing/
      }));
      (0, _vitest.expect)(open).toHaveBeenCalledWith("https://immediately.run/spaces?space=s1", "_blank", "noopener,noreferrer");
    } finally {
      open.mockRestore();
      window.history.replaceState({}, "", "/");
    }
  });
  (0, _vitest.it)("a non-root row inside a space does NOT offer 'Manage sharing →'", async () => {
    window.history.replaceState({}, "", "/?href=" + encodeURIComponent("https://immediately.run/edit/github/a/b/main/"));
    try {
      h.mounts = [{
        type: "space",
        path: "/spaces/s1",
        id: "space:s1",
        name: "Shared notes"
      }];
      (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
      _react.fireEvent.contextMenu(await _react.screen.findByText("note.md"));
      const menu = await _react.screen.findByRole("menu");
      (0, _vitest.expect)((0, _react.within)(menu).queryByRole("menuitem", {
        name: /Manage sharing/
      })).not.toBeInTheDocument();
    } finally {
      window.history.replaceState({}, "", "/");
    }
  });
});

// --- helpers for synthetic drag events --------------------------------------
function dataTransfer(opts) {
  const types = [];
  if (opts.move) types.push("application/x-ir-file-move");
  if (opts.files?.length) types.push("Files");
  return {
    types,
    files: opts.files ?? [],
    getData: t => t === "application/x-ir-file-move" ? opts.move ?? "" : "",
    setData: () => {},
    dropEffect: "",
    effectAllowed: ""
  };
}

// --- R3-81: drag to move ----------------------------------------------------
(0, _vitest.describe)("R3-81 — drag to move within a filesystem", () => {
  (0, _vitest.it)("dropping a file onto a sibling directory calls renameEntry", async () => {
    await renderWithSrcExpanded();
    const srcRow = _react.screen.getByText("src").closest(".tnode");
    _react.fireEvent.drop(srcRow, {
      dataTransfer: dataTransfer({
        move: JSON.stringify({
          from: "/mnt/abc/README.md",
          rootPath: "/mnt/abc"
        })
      })
    });
    (0, _vitest.expect)(h.renameEntry).toHaveBeenCalledWith("/README.md", "/src/README.md");
  });
  (0, _vitest.it)("a cross-mount drop is rejected (no rename)", async () => {
    await renderWithSrcExpanded();
    const srcRow = _react.screen.getByText("src").closest(".tnode");
    _react.fireEvent.drop(srcRow, {
      dataTransfer: dataTransfer({
        move: JSON.stringify({
          from: "/spaces/s1/x.md",
          rootPath: "/spaces/s1"
        })
      })
    });
    (0, _vitest.expect)(h.renameEntry).not.toHaveBeenCalled();
    (0, _vitest.expect)(await _react.screen.findByRole("alert")).toHaveTextContent(/spaces/);
  });
});

// --- R3-82: drag to upload --------------------------------------------------
(0, _vitest.describe)("R3-82 — drag local files to upload into a directory", () => {
  (0, _vitest.it)("dropping an OS file onto a directory uploads it into that directory", async () => {
    await renderWithSrcExpanded();
    const srcRow = _react.screen.getByText("src").closest(".tnode");
    const file = new File(["hello"], "note.txt", {
      type: "text/plain"
    });
    _react.fireEvent.drop(srcRow, {
      dataTransfer: dataTransfer({
        files: [file]
      })
    });
    await _vitest.vi.waitFor(() => (0, _vitest.expect)(h.uploadFile).toHaveBeenCalled());
    (0, _vitest.expect)(h.uploadFile.mock.calls[0][0]).toBe("/src/note.txt");
  });

  // §5: "or the scope root if dropped on empty space within a scope". These two
  // drops were silent no-ops — the whole of the panel except a directory row was
  // dead to an OS drag.
  (0, _vitest.it)("dropping on the scope's blank space uploads into the scope root", async () => {
    await renderWithSrcExpanded();
    const scope = _react.screen.getByText("src").closest(".mount");
    const file = new File(["hello"], "note.txt", {
      type: "text/plain"
    });
    _react.fireEvent.drop(scope, {
      dataTransfer: dataTransfer({
        files: [file]
      })
    });
    await _vitest.vi.waitFor(() => (0, _vitest.expect)(h.uploadFile).toHaveBeenCalled());
    (0, _vitest.expect)(h.uploadFile.mock.calls[0][0]).toBe("/note.txt");
  });
  (0, _vitest.it)("dropping onto a file row uploads into that file's directory", async () => {
    await renderWithSrcExpanded();
    const fileRow = _react.screen.getByText("index.ts").closest(".tnode");
    const file = new File(["hello"], "note.txt", {
      type: "text/plain"
    });
    _react.fireEvent.drop(fileRow, {
      dataTransfer: dataTransfer({
        files: [file]
      })
    });
    await _vitest.vi.waitFor(() => (0, _vitest.expect)(h.uploadFile).toHaveBeenCalled());
    (0, _vitest.expect)(h.uploadFile.mock.calls[0][0]).toBe("/src/note.txt");
  });
  (0, _vitest.it)("a directory row's drop is not also handled by the scope", async () => {
    await renderWithSrcExpanded();
    const srcRow = _react.screen.getByText("src").closest(".tnode");
    const file = new File(["hello"], "note.txt", {
      type: "text/plain"
    });
    _react.fireEvent.drop(srcRow, {
      dataTransfer: dataTransfer({
        files: [file]
      })
    });
    await _vitest.vi.waitFor(() => (0, _vitest.expect)(h.uploadFile).toHaveBeenCalled());
    (0, _vitest.expect)(h.uploadFile).toHaveBeenCalledTimes(1);
  });
  (0, _vitest.it)("the scope lights its drop affordance while OS files are dragged over it", async () => {
    await renderWithSrcExpanded();
    const scope = _react.screen.getByText("src").closest(".mount");
    (0, _vitest.expect)(scope.getAttribute("data-drag")).toBe(null);
    _react.fireEvent.dragOver(scope, {
      dataTransfer: dataTransfer({
        files: [new File(["x"], "x.txt")]
      })
    });
    (0, _vitest.expect)(scope.getAttribute("data-drag")).toBe("1");
    _react.fireEvent.dragLeave(scope, {
      relatedTarget: document.body
    });
    (0, _vitest.expect)(scope.getAttribute("data-drag")).toBe(null);
  });
  (0, _vitest.it)("an internal move dragged over blank space is not taken by the scope", async () => {
    await renderWithSrcExpanded();
    const scope = _react.screen.getByText("src").closest(".mount");
    _react.fireEvent.dragOver(scope, {
      dataTransfer: dataTransfer({
        move: JSON.stringify({
          from: "/README.md",
          rootPath: "/mnt/abc"
        })
      })
    });
    (0, _vitest.expect)(scope.getAttribute("data-drag")).toBe(null);
    _react.fireEvent.drop(scope, {
      dataTransfer: dataTransfer({
        move: JSON.stringify({
          from: "/README.md",
          rootPath: "/mnt/abc"
        })
      })
    });
    (0, _vitest.expect)(h.renameEntry).not.toHaveBeenCalled();
    (0, _vitest.expect)(h.uploadFile).not.toHaveBeenCalled();
  });

  // §5 upload BUTTON: the native file-picker path (the discoverable/mobile
  // alternative to a drag), routing through the same `uploadFile` intent with
  // the selected file's folder as the destination.
  (0, _vitest.it)("the Upload button uploads the picked file next to the selected file", async () => {
    const {
      user,
      container
    } = await renderWithSrcExpanded();
    await user.click(_react.screen.getByText("index.ts")); // selects the file

    _react.fireEvent.click(_react.screen.getByRole("button", {
      name: "Upload files to /src"
    }));
    const input = container.querySelector('input[type="file"]');
    _react.fireEvent.change(input, {
      target: {
        files: [new File(["hello"], "note.txt", {
          type: "text/plain"
        })]
      }
    });
    await _vitest.vi.waitFor(() => (0, _vitest.expect)(h.uploadFile).toHaveBeenCalled());
    (0, _vitest.expect)(h.uploadFile.mock.calls[0][0]).toBe("/src/note.txt");
  });
});

// --- R3-83: drag-out source -------------------------------------------------
(0, _vitest.describe)("R3-83 — drag-out asks the host to begin a cross-app drag", () => {
  (0, _vitest.it)("dragging a file row calls startItemDrag with a reference to that file", async () => {
    await renderWithSrcExpanded();
    const fileRow = _react.screen.getByText("index.ts").closest(".tnode");
    _react.fireEvent.dragStart(fileRow, {
      dataTransfer: dataTransfer({})
    });
    await _vitest.vi.waitFor(() => (0, _vitest.expect)(h.startItemDrag).toHaveBeenCalled());
    (0, _vitest.expect)(h.startItemDrag.mock.calls[0][0]).toMatchObject({
      kind: "file",
      name: "index.ts",
      relPath: "/src/index.ts"
    });
  });
});
(0, _vitest.describe)("R3-95 — App | Session lens (PRINCIPALS §9 B2 / D-PRIN-4)", () => {
  const sessionSpace = () => ({
    type: "space",
    path: "/spaces/sess",
    id: "sess",
    name: "Session space",
    mode: "ro",
    forwardedToApp: false
  });
  (0, _vitest.it)("(#5) hides the lens toggle when the host delivers no session signal (a fork)", async () => {
    h.mounts = [worktree()];
    h.sessionMounts = []; // fork: mounts:registry withheld → empty session list
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    (0, _vitest.expect)(await _react.screen.findByRole("tree", {
      name: "repo"
    })).toBeInTheDocument();
    // No Session lens: neither the toggle group nor the Session radio exists.
    (0, _vitest.expect)(_react.screen.queryByRole("radiogroup", {
      name: "Spaces lens"
    })).toBeNull();
    (0, _vitest.expect)(_react.screen.queryByRole("radio", {
      name: "The session's spaces"
    })).toBeNull();
  });
  (0, _vitest.it)("shows the toggle for a first-party frame and switches roots to the session mounts", async () => {
    h.mounts = [worktree()]; // the App lens = this app's own mounts
    h.sessionMounts = [sessionSpace()]; // first-party: the session's mounts
    const user = _userEvent.default.setup();
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));

    // App lens (default): the app's own worktree shows; the session-only space does NOT
    // (exit #1 — a session-only mount is never in the app's own view).
    (0, _vitest.expect)(await _react.screen.findByRole("tree", {
      name: "repo"
    })).toBeInTheDocument();
    (0, _vitest.expect)(_react.screen.queryByRole("tree", {
      name: "Session space"
    })).toBeNull();

    // The toggle is present (a session signal arrived). Switch to the Session lens.
    await user.click(_react.screen.getByRole("radio", {
      name: "The session's spaces"
    }));

    // Session lens: the session mount shows; the App-lens worktree is replaced.
    (0, _vitest.expect)(await _react.screen.findByRole("tree", {
      name: "Session space"
    })).toBeInTheDocument();
    (0, _vitest.expect)(_react.screen.queryByRole("tree", {
      name: "repo"
    })).toBeNull();
  });
  (0, _vitest.it)("(R3-96 step 4b) as the page.commander surface, DEFAULTS to the registry lens — no toggle", async () => {
    h.mounts = [worktree()]; // the app's own worktree (App lens)
    h.sessionMounts = [sessionSpace()]; // first-party registry lens available
    h.region = "page.commander"; // the standalone User-scope full manager
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    // WITHOUT clicking the toggle: the commander opens on the broad registry lens
    // (the "everything you've ever opened" navigator), so the session mount is the
    // default view and the app's own worktree is NOT.
    (0, _vitest.expect)(await _react.screen.findByRole("tree", {
      name: "Session space"
    })).toBeInTheDocument();
    (0, _vitest.expect)(_react.screen.queryByRole("tree", {
      name: "repo"
    })).toBeNull();
    // The toggle is still present so the user can narrow to the App lens.
    (0, _vitest.expect)(_react.screen.getByRole("radio", {
      name: "The session's spaces"
    })).toBeInTheDocument();
  });
});
(0, _vitest.describe)("R3-238 — settings filesystems are hidden behind one advanced flag", () => {
  const settingsMount = () => ({
    type: "firestore",
    path: "/mnt/set/color-picker",
    id: "settings:color-picker",
    name: "color-picker settings",
    mode: "rw"
  });
  (0, _vitest.beforeEach)(() => {
    localStorage.clear(); // the flag persists; each case starts from the shipped default
  });
  (0, _vitest.it)("a default session shows no settings root and no `settings · <app>` button", async () => {
    h.mounts = [worktree(), settingsMount()];
    h.listSettingsApps.mockResolvedValue(["agent-demo"]); // an app whose store isn't mounted
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));

    // The ordinary mount is untouched…
    (0, _vitest.expect)(await _react.screen.findByRole("tree", {
      name: "repo"
    })).toBeInTheDocument();
    // …and both settings affordances are absent.
    (0, _vitest.expect)(_react.screen.queryByRole("tree", {
      name: "color-picker settings"
    })).toBeNull();
    (0, _vitest.expect)(_react.screen.queryByTitle("Open agent-demo settings")).toBeNull();
    // The reveal control is offered, because this session HAS something hidden.
    (0, _vitest.expect)(_react.screen.getByRole("button", {
      name: "Show all filesystems"
    })).toHaveAttribute("aria-pressed", "false");
  });
  (0, _vitest.it)("toggling the flag restores both the settings root and the header button, and persists", async () => {
    h.mounts = [worktree(), settingsMount()];
    h.listSettingsApps.mockResolvedValue(["agent-demo"]);
    const user = _userEvent.default.setup();
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    await _react.screen.findByRole("tree", {
      name: "repo"
    });
    await user.click(_react.screen.getByRole("button", {
      name: "Show all filesystems"
    }));
    (0, _vitest.expect)(await _react.screen.findByRole("tree", {
      name: "color-picker settings"
    })).toBeInTheDocument();
    (0, _vitest.expect)(await _react.screen.findByTitle("Open agent-demo settings")).toBeInTheDocument();
    // The ordinary mount is still there — this reveals, it does not replace.
    (0, _vitest.expect)(_react.screen.getByRole("tree", {
      name: "repo"
    })).toBeInTheDocument();
    (0, _vitest.expect)(localStorage.getItem("ir.fileexplorer.showAllFilesystems")).toBe("1");
    // And the door swings back.
    (0, _vitest.expect)(_react.screen.getByRole("button", {
      name: "Hide advanced filesystems"
    })).toHaveAttribute("aria-pressed", "true");
  });
  (0, _vitest.it)("offers no reveal control when the session has nothing hidden", async () => {
    h.mounts = [worktree()];
    h.listSettingsApps.mockResolvedValue([]);
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    await _react.screen.findByRole("tree", {
      name: "repo"
    });
    (0, _vitest.expect)(_react.screen.queryByRole("button", {
      name: "Show all filesystems"
    })).toBeNull();
  });
  (0, _vitest.it)("keeps the reveal control reachable when EVERYTHING is hidden (no dead end)", async () => {
    // The pathological commander case: every mount is a settings store, so the root
    // list is empty. The header's action cluster used to be gated on having roots —
    // which would hide the one control that brings them back.
    h.mounts = [settingsMount()];
    h.listSettingsApps.mockResolvedValue([]);
    const user = _userEvent.default.setup();
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    const toggle = await _react.screen.findByRole("button", {
      name: "Show all filesystems"
    });
    (0, _vitest.expect)(_react.screen.queryByRole("tree")).toBeNull();
    await user.click(toggle);
    (0, _vitest.expect)(await _react.screen.findByRole("tree", {
      name: "color-picker settings"
    })).toBeInTheDocument();
  });
  (0, _vitest.it)("hides settings stores in the Session lens too (the commander's default view)", async () => {
    h.mounts = [worktree()];
    h.sessionMounts = [{
      type: "space",
      path: "/spaces/s",
      id: "space:s",
      name: "Session space",
      mode: "ro",
      forwardedToApp: false
    }, {
      ...settingsMount(),
      forwardedToApp: false
    }];
    h.region = "page.commander"; // defaults to the Session lens
    h.listSettingsApps.mockResolvedValue([]);
    const user = _userEvent.default.setup();
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    (0, _vitest.expect)(await _react.screen.findByRole("tree", {
      name: "Session space"
    })).toBeInTheDocument();
    (0, _vitest.expect)(_react.screen.queryByRole("tree", {
      name: "color-picker settings"
    })).toBeNull();
    // The lens toggle still renders — `available` reads the raw session signal, not
    // the filtered roots, so filtering can never strand the user in one lens.
    (0, _vitest.expect)(_react.screen.getByRole("radio", {
      name: "The session's spaces"
    })).toBeInTheDocument();
    await user.click(_react.screen.getByRole("button", {
      name: "Show all filesystems"
    }));
    (0, _vitest.expect)(await _react.screen.findByRole("tree", {
      name: "color-picker settings"
    })).toBeInTheDocument();
  });
});
(0, _vitest.describe)("R3-239 — the header's size must not follow the mount-label length", () => {
  // The fix is CSS, which jsdom cannot lay out. What jsdom CAN pin is the MARKUP
  // CONTRACT the CSS depends on — the two seams that would silently un-fix it:
  // an ellipsis needs its own block box (a bare text node in a flex button can only
  // overflow), and the compact-view-switcher rule keys off the `--extra` modifier.
  // Geometry itself is verified in a headless-Chrome harness; numbers in the PR.
  (0, _vitest.beforeEach)(() => {
    localStorage.clear();
    localStorage.setItem("ir.fileexplorer.showAllFilesystems", "1");
  });
  (0, _vitest.it)("renders the settings-app label in its own truncatable element", async () => {
    h.mounts = [worktree()];
    h.listSettingsApps.mockResolvedValue(["a-really-long-application-key"]);
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    const btn = await _react.screen.findByTitle("Open a-really-long-application-key settings");
    const label = btn.querySelector(".settings-app__label");
    (0, _vitest.expect)(label).not.toBeNull();
    (0, _vitest.expect)(label).toHaveTextContent("settings · a-really-long-application-key");
    // The label must be the ONLY text — an icon sibling, not a text sibling, or the
    // anonymous text node reappears and defeats `text-overflow`.
    (0, _vitest.expect)(btn.textContent).toBe(label.textContent);
  });
  (0, _vitest.it)("marks the action cluster `--extra` when a consumer supplies header controls", async () => {
    h.mounts = [worktree()];
    h.listSettingsApps.mockResolvedValue(["cp"]);
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    await _react.screen.findByTitle("Open cp settings");
    (0, _vitest.expect)(document.querySelector(".panel__actions")).toHaveClass("panel__actions--extra");
  });

  // The header row is a FIXED budget; there is one settings pill per app with settings,
  // so their count is data. Sharing the row out among them is what shrank each pill to
  // 17px — narrower than the 14px icon in it, which then spilled over its neighbour and
  // off the panel edge. jsdom has no layout, so the assertion is the structural fact
  // that prevents it: the pills are not in the fixed row at all.
  (0, _vitest.it)("puts the settings pills in the tray, not in the fixed header row", async () => {
    h.mounts = [worktree()];
    h.listSettingsApps.mockResolvedValue(["one", "two", "three"]);
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    await _react.screen.findByTitle("Open one settings");
    const tray = document.querySelector(".panel__tray");
    (0, _vitest.expect)(tray).not.toBeNull();
    (0, _vitest.expect)(tray.querySelectorAll(".settings-app")).toHaveLength(3);
    (0, _vitest.expect)(document.querySelector(".panel__actions").querySelectorAll(".settings-app")).toHaveLength(0);
    // The controls with a fixed count stay in the header row, where they belong.
    (0, _vitest.expect)(document.querySelector(".panel__actions").querySelector('[aria-label="Add a space…"]')).not.toBeNull();
  });
  (0, _vitest.it)("grows no tray when there is nothing to put in it", async () => {
    h.mounts = [worktree()];
    h.listSettingsApps.mockResolvedValue([]);
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    await _react.screen.findByText("src");
    (0, _vitest.expect)(document.querySelector(".panel__tray")).toBeNull();
  });
  (0, _vitest.it)("drops the tray again when the settings apps are hidden", async () => {
    const user = _userEvent.default.setup();
    h.mounts = [worktree()];
    h.listSettingsApps.mockResolvedValue(["cp"]);
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    await _react.screen.findByTitle("Open cp settings");
    (0, _vitest.expect)(document.querySelector(".panel__tray")).not.toBeNull();
    await user.click(_react.screen.getByRole("button", {
      name: "Hide advanced filesystems"
    }));
    (0, _vitest.expect)(document.querySelector(".panel__tray")).toBeNull();
  });
});

// --- R3-268 follow-up: gesture-gated reveal + collapsed-ancestor dot ----------
(0, _vitest.describe)("viewed-document reveal + ancestor dot", () => {
  (0, _vitest.it)("a collapsed folder containing the viewed file carries the dimmed ancestor dot", async () => {
    h.viewedFile = "/src/index.ts";
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    await _react.screen.findByText("src"); // root listed; `src` starts COLLAPSED
    // The dot names its meaning; the folder itself never opens on its own.
    (0, _vitest.expect)(await _react.screen.findByRole("img", {
      name: "Contains the file shown in the running app"
    })).toBeInTheDocument();
    (0, _vitest.expect)(_react.screen.queryByText("index.ts")).not.toBeInTheDocument();
  });
  (0, _vitest.it)("R3-440: the app reports ready immediately after subscribing the reveal listener (the host holds pending reveals until then)", async () => {
    const before = h.reportReadyListenerCount.length;
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    await _react.screen.findByText("src");
    const mine = h.reportReadyListenerCount.slice(before);
    (0, _vitest.expect)(mine).toHaveLength(1); // exactly one report per mount (the SDK dedupes beyond that)
    // The ordering IS the contract: at the report, the viewed-reveal listener
    // was already subscribed (a report before it would release the host's held
    // one-shot into a frame that cannot hear it).
    (0, _vitest.expect)(mine[0]).toBe(1);
  });
  (0, _vitest.it)("R3-440: a reveal emitted before the roots exist lands when they arrive (the rootKey retry)", async () => {
    const scrolls = [];
    const orig = Element.prototype.scrollIntoView;
    Element.prototype.scrollIntoView = function () {
      scrolls.push(this);
    };
    try {
      // The boot race the host's readiness gate exposes: the report fires at the
      // mount effect, so the held reveal can land while the store has NO roots.
      // (The marker itself rides the `viewedFile` hint — the host pushes it with
      // the navigation; the reveal is the expand+scroll gesture half.)
      h.viewedFile = "/src/index.ts";
      h.mounts = [];
      const {
        rerender
      } = (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
      (0, _react.act)(() => h.emit("viewed-reveal", {
        type: "viewed-reveal",
        path: "/src/index.ts"
      }));
      (0, _vitest.expect)(_react.screen.queryByText("src")).not.toBeInTheDocument(); // nothing to expand into

      // The mounts arrive (the host's push) — the reveal must RETRY, not be lost.
      h.mounts = [worktree()];
      rerender(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
      const src = await _react.screen.findByText("src");
      (0, _vitest.expect)(src).toBeInTheDocument();
      // The ancestors expanded on their own: the file row renders without any click…
      const row = await _react.screen.findByText("index.ts");
      (0, _vitest.expect)(row).toBeInTheDocument();
      // …carrying the marker, scrolled into view once it rendered.
      (0, _vitest.expect)(await _react.screen.findByRole("img", {
        name: "Shown in the running app"
      })).toBeInTheDocument();
      await (0, _react.waitFor)(() => (0, _vitest.expect)(scrolls.length).toBeGreaterThan(0));
    } finally {
      Element.prototype.scrollIntoView = orig;
    }
  });
  (0, _vitest.it)("a host `viewed-reveal` expands the ancestors and scrolls the row into view — without focus", async () => {
    const scrolls = [];
    const orig = Element.prototype.scrollIntoView;
    Element.prototype.scrollIntoView = function () {
      scrolls.push(this);
    };
    try {
      h.viewedFile = "/src/index.ts";
      (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
      await _react.screen.findByText("src");
      const before = document.activeElement;
      (0, _react.act)(() => h.emit("viewed-reveal", {
        type: "viewed-reveal",
        path: "/src/index.ts"
      }));

      // Ancestors expanded → the row renders, carrying the on-stage marker…
      const row = await _react.screen.findByText("index.ts");
      (0, _vitest.expect)(row).toBeInTheDocument();
      (0, _vitest.expect)(await _react.screen.findByRole("img", {
        name: "Shown in the running app"
      })).toBeInTheDocument();
      // …the row is scrolled into view (bounded poll inside the view)…
      await (0, _react.waitFor)(() => (0, _vitest.expect)(scrolls.length).toBeGreaterThan(0));
      // …and focus NEVER moved (the activation-free half that still holds).
      (0, _vitest.expect)(document.activeElement).toBe(before);
    } finally {
      Element.prototype.scrollIntoView = orig;
    }
  });
  (0, _vitest.it)("without a reveal message the tree never moves on its own (highlight-only)", async () => {
    h.viewedFile = "/src/index.ts";
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    await _react.screen.findByText("src");
    await new Promise(r => setTimeout(r, 50));
    (0, _vitest.expect)(_react.screen.queryByText("index.ts")).not.toBeInTheDocument(); // still collapsed
  });
});

// --- The editor-active counterpart: reveal + glyph + ancestor dot -------------
// The bug this covers: switching a `/present/...` session to edit mode seeds the
// editor with the app's ENTRYPOINT, which lives under a collapsed folder — so the
// tree showed nothing at all about the file being edited.
(0, _vitest.describe)("editor-active reveal + marker", () => {
  (0, _vitest.it)("the editor's active file is revealed: ancestors expand and the row scrolls into view", async () => {
    const scrolls = [];
    const orig = Element.prototype.scrollIntoView;
    Element.prototype.scrollIntoView = function () {
      scrolls.push(this);
    };
    try {
      h.activeFile = "/src/index.ts";
      (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
      await _react.screen.findByText("src");
      const before = document.activeElement;

      // No gesture, no message: the host's editor-context push is enough.
      (0, _vitest.expect)(await _react.screen.findByText("index.ts")).toBeInTheDocument();
      (0, _vitest.expect)(_react.screen.getByRole("treeitem", {
        name: "src"
      })).toHaveAttribute("aria-expanded", "true");
      await (0, _react.waitFor)(() => (0, _vitest.expect)(scrolls.length).toBeGreaterThan(0));
      // Reveal is scroll-only — focus never moves.
      (0, _vitest.expect)(document.activeElement).toBe(before);
    } finally {
      Element.prototype.scrollIntoView = orig;
    }
  });
  (0, _vitest.it)("the revealed row carries the 'Open in the editor' glyph, and siblings do not", async () => {
    h.activeFile = "/src/index.ts";
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    await _react.screen.findByText("util.ts"); // the whole open directory rendered
    const marks = _react.screen.getAllByRole("img", {
      name: "Open in the editor"
    });
    (0, _vitest.expect)(marks).toHaveLength(1);
    (0, _vitest.expect)(marks[0].closest("div.tnode")).toHaveClass("tnode--active");
    (0, _vitest.expect)(marks[0].closest("div.tnode")).toContainElement(_react.screen.getByText("index.ts"));
  });
  (0, _vitest.it)("collapsing the folder leaves the dimmed ancestor dot — and never re-opens it", async () => {
    h.activeFile = "/src/index.ts";
    const user = _userEvent.default.setup();
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    await _react.screen.findByText("index.ts"); // revealed

    await user.click(_react.screen.getByText("src")); // the user closes it again

    (0, _vitest.expect)(_react.screen.queryByText("index.ts")).not.toBeInTheDocument();
    (0, _vitest.expect)(_react.screen.getByRole("img", {
      name: "Contains the file open in the editor"
    })).toBeInTheDocument();
    // Expand-only: a folder the user closed stays closed.
    await new Promise(r => setTimeout(r, 400));
    (0, _vitest.expect)(_react.screen.queryByText("index.ts")).not.toBeInTheDocument();
  });
  (0, _vitest.it)("the mounts arriving AFTER the active file still reveal it (the load race)", async () => {
    // The real ordering on a cold edit-mode boot: the editor-context push can beat
    // the mount list, and a reveal against an empty root set expands nothing.
    h.mounts = [];
    h.activeFile = "/src/index.ts";
    const {
      rerender
    } = (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    await new Promise(r => setTimeout(r, 50));
    (0, _vitest.expect)(_react.screen.queryByText("src")).not.toBeInTheDocument(); // no roots yet

    h.mounts = [worktree()];
    rerender(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    (0, _vitest.expect)(await _react.screen.findByText("index.ts")).toBeInTheDocument();
    (0, _vitest.expect)(_react.screen.getByRole("treeitem", {
      name: "src"
    })).toHaveAttribute("aria-expanded", "true");
  });
  (0, _vitest.it)("no active file → no marker and no reveal", async () => {
    h.activeFile = null;
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    await _react.screen.findByText("src");
    await new Promise(r => setTimeout(r, 50));
    (0, _vitest.expect)(_react.screen.queryByText("index.ts")).not.toBeInTheDocument();
    (0, _vitest.expect)(_react.screen.queryByRole("img", {
      name: "Open in the editor"
    })).not.toBeInTheDocument();
    (0, _vitest.expect)(_react.screen.queryByRole("img", {
      name: "Contains the file open in the editor"
    })).not.toBeInTheDocument();
  });
});

// --- R3-626: the flat layouts take what their rows decline -------------------
// file-explorer#40 gave the tree's scope the drop; list, icons and columns were
// left dead outside a directory row. Per layout: blank space → cwd (columns:
// THAT column's directory — the second-column assertion fails any view-level
// fallback), a file row → its parent, a directory row → itself exactly once,
// and the owning container lights `data-drag`.
(0, _vitest.describe)("R3-626 — the flat layouts' containers are upload drop zones", () => {
  const note = () => new File(["hello"], "note.txt", {
    type: "text/plain"
  });
  (0, _vitest.beforeEach)(() => {
    // The layout choice persists (useLayout → localStorage); each case starts
    // from the tree default so renderWithSrcExpanded's expansion applies.
    localStorage.clear();
  });
  async function toLayout(layoutTip) {
    const user = _userEvent.default.setup();
    await renderWithSrcExpanded();
    await user.click(_react.screen.getByRole("radio", {
      name: layoutTip
    }));
    return user;
  }
  (0, _vitest.it)("list: a drop on the layout's blank space uploads into the cwd", async () => {
    const user = await toLayout("List view");
    await user.click(await _react.screen.findByText("repo")); // enter the mount → cwd /mnt/abc
    await _react.screen.findByText("src");
    const layout = document.querySelector(".layout--list");
    _react.fireEvent.drop(layout, {
      dataTransfer: dataTransfer({
        files: [note()]
      })
    });
    await _vitest.vi.waitFor(() => (0, _vitest.expect)(h.uploadFile).toHaveBeenCalled());
    (0, _vitest.expect)(h.uploadFile.mock.calls[0][0]).toBe("/note.txt");
  });
  (0, _vitest.it)("list: a drop on a file row uploads into the directory holding it", async () => {
    const user = await toLayout("List view");
    await user.click(await _react.screen.findByText("repo"));
    await _react.screen.findByText("src");
    await user.click(_react.screen.getByText("src"));
    await _react.screen.findByText("index.ts");
    const row = _react.screen.getByText("index.ts").closest("[data-path]");
    _react.fireEvent.drop(row, {
      dataTransfer: dataTransfer({
        files: [note()]
      })
    });
    await _vitest.vi.waitFor(() => (0, _vitest.expect)(h.uploadFile).toHaveBeenCalled());
    (0, _vitest.expect)(h.uploadFile.mock.calls[0][0]).toBe("/src/note.txt");
  });
  (0, _vitest.it)("list: a directory-row drop still lands once, in that directory", async () => {
    const user = await toLayout("List view");
    await user.click(await _react.screen.findAllByText("repo")[0]);
    await _react.screen.findAllByText("src");
    const row = _react.screen.getAllByText("src")[0].closest("[data-path]");
    _react.fireEvent.drop(row, {
      dataTransfer: dataTransfer({
        files: [note()]
      })
    });
    await _vitest.vi.waitFor(() => (0, _vitest.expect)(h.uploadFile).toHaveBeenCalled());
    (0, _vitest.expect)(h.uploadFile).toHaveBeenCalledTimes(1);
    (0, _vitest.expect)(h.uploadFile.mock.calls[0][0]).toBe("/src/note.txt");
  });
  (0, _vitest.it)("icons: a directory-row drop still lands once, in that directory", async () => {
    const user = await toLayout("Icon view");
    await user.click(await _react.screen.findAllByText("repo")[0]);
    await _react.screen.findAllByText("src");
    const row = _react.screen.getAllByText("src")[0].closest("[data-path]");
    _react.fireEvent.drop(row, {
      dataTransfer: dataTransfer({
        files: [note()]
      })
    });
    await _vitest.vi.waitFor(() => (0, _vitest.expect)(h.uploadFile).toHaveBeenCalled());
    (0, _vitest.expect)(h.uploadFile).toHaveBeenCalledTimes(1);
    (0, _vitest.expect)(h.uploadFile.mock.calls[0][0]).toBe("/src/note.txt");
  });
  (0, _vitest.it)("columns: a directory-row drop still lands once, in that directory", async () => {
    const user = await toLayout("Column view");
    await user.click(await _react.screen.findAllByText("repo")[0]); // column 1 = /mnt/abc
    await _react.screen.findAllByText("src");
    const row = _react.screen.getAllByText("src")[0].closest("[data-path]");
    _react.fireEvent.drop(row, {
      dataTransfer: dataTransfer({
        files: [note()]
      })
    });
    await _vitest.vi.waitFor(() => (0, _vitest.expect)(h.uploadFile).toHaveBeenCalled());
    (0, _vitest.expect)(h.uploadFile).toHaveBeenCalledTimes(1);
    (0, _vitest.expect)(h.uploadFile.mock.calls[0][0]).toBe("/src/note.txt");
  });
  (0, _vitest.it)("list: a drop a directory row takes clears the affordance the hover lit", async () => {
    // The row's onDrop stops propagation, so the container's onDrop never runs —
    // only the capture-phase clear un-lights the container here.
    const user = await toLayout("List view");
    await user.click(await _react.screen.findAllByText("repo")[0]);
    await _react.screen.findAllByText("src");
    const layout = document.querySelector(".layout--list");
    const row = _react.screen.getAllByText("src")[0].closest("[data-path]");
    _react.fireEvent.dragOver(layout, {
      dataTransfer: dataTransfer({
        files: [note()]
      })
    });
    (0, _vitest.expect)(layout.getAttribute("data-drag")).toBe("1");
    _react.fireEvent.drop(row, {
      dataTransfer: dataTransfer({
        files: [note()]
      })
    });
    await _vitest.vi.waitFor(() => (0, _vitest.expect)(h.uploadFile).toHaveBeenCalled());
    (0, _vitest.expect)(h.uploadFile).toHaveBeenCalledTimes(1);
    (0, _vitest.expect)(layout.getAttribute("data-drag")).toBe(null);
  });
  (0, _vitest.it)("list: the layout lights and clears data-drag", async () => {
    const user = await toLayout("List view");
    await user.click(await _react.screen.findByText("repo"));
    await _react.screen.findByText("src");
    const layout = document.querySelector(".layout--list");
    (0, _vitest.expect)(layout.getAttribute("data-drag")).toBe(null);
    _react.fireEvent.dragOver(layout, {
      dataTransfer: dataTransfer({
        files: [note()]
      })
    });
    (0, _vitest.expect)(layout.getAttribute("data-drag")).toBe("1");
    _react.fireEvent.dragLeave(layout, {
      relatedTarget: document.body
    });
    (0, _vitest.expect)(layout.getAttribute("data-drag")).toBe(null);
  });
  (0, _vitest.it)("icons: a drop on the layout's blank space uploads into the cwd", async () => {
    const user = await toLayout("Icon view");
    await user.click(await _react.screen.findByText("repo"));
    await _react.screen.findByText("src");
    const layout = document.querySelector(".layout--icons");
    _react.fireEvent.drop(layout, {
      dataTransfer: dataTransfer({
        files: [note()]
      })
    });
    await _vitest.vi.waitFor(() => (0, _vitest.expect)(h.uploadFile).toHaveBeenCalled());
    (0, _vitest.expect)(h.uploadFile.mock.calls[0][0]).toBe("/note.txt");
  });
  (0, _vitest.it)("icons: a drop on a file row uploads into the directory holding it", async () => {
    const user = await toLayout("Icon view");
    await user.click(await _react.screen.findByText("repo"));
    await _react.screen.findByText("src");
    await user.click(_react.screen.getByText("src"));
    await _react.screen.findByText("index.ts");
    const row = _react.screen.getByText("index.ts").closest("[data-path]");
    _react.fireEvent.drop(row, {
      dataTransfer: dataTransfer({
        files: [note()]
      })
    });
    await _vitest.vi.waitFor(() => (0, _vitest.expect)(h.uploadFile).toHaveBeenCalled());
    (0, _vitest.expect)(h.uploadFile.mock.calls[0][0]).toBe("/src/note.txt");
  });
  (0, _vitest.it)("icons: the layout lights and clears data-drag", async () => {
    const user = await toLayout("Icon view");
    await user.click(await _react.screen.findByText("repo"));
    await _react.screen.findByText("src");
    const layout = document.querySelector(".layout--icons");
    (0, _vitest.expect)(layout.getAttribute("data-drag")).toBe(null);
    _react.fireEvent.dragOver(layout, {
      dataTransfer: dataTransfer({
        files: [note()]
      })
    });
    (0, _vitest.expect)(layout.getAttribute("data-drag")).toBe("1");
    _react.fireEvent.dragLeave(layout, {
      relatedTarget: document.body
    });
    (0, _vitest.expect)(layout.getAttribute("data-drag")).toBe(null);
  });
  (0, _vitest.it)("columns: a drop in the SECOND column's blank space uploads into THAT column's directory", async () => {
    const user = await toLayout("Column view");
    await user.click(await _react.screen.findByText("repo")); // column 1 = /mnt/abc
    await _react.screen.findByText("src");
    await user.click(_react.screen.getByText("src")); // column 2 = /mnt/abc/src
    await _react.screen.findByText("index.ts");
    const col1 = document.querySelector('[data-col="1"]');
    _react.fireEvent.drop(col1, {
      dataTransfer: dataTransfer({
        files: [note()]
      })
    });
    await _vitest.vi.waitFor(() => (0, _vitest.expect)(h.uploadFile).toHaveBeenCalled());
    // A view-level fallback (the deepest open path, /mnt/abc/src) fails this.
    (0, _vitest.expect)(h.uploadFile.mock.calls[0][0]).toBe("/note.txt");
  });
  (0, _vitest.it)("columns: a drop on a file row uploads into the directory holding it", async () => {
    const user = await toLayout("Column view");
    await user.click(await _react.screen.findByText("repo"));
    await _react.screen.findByText("src");
    await user.click(_react.screen.getByText("src"));
    await _react.screen.findByText("index.ts");
    const row = _react.screen.getByText("index.ts").closest("[data-path]");
    _react.fireEvent.drop(row, {
      dataTransfer: dataTransfer({
        files: [note()]
      })
    });
    await _vitest.vi.waitFor(() => (0, _vitest.expect)(h.uploadFile).toHaveBeenCalled());
    (0, _vitest.expect)(h.uploadFile.mock.calls[0][0]).toBe("/src/note.txt");
  });
  (0, _vitest.it)("columns: the landed column lights data-drag, and only it", async () => {
    const user = await toLayout("Column view");
    await user.click(await _react.screen.findByText("repo"));
    await _react.screen.findByText("src");
    await user.click(_react.screen.getByText("src"));
    await _react.screen.findByText("index.ts");
    const col1 = document.querySelector('[data-col="1"]');
    const col2 = document.querySelector('[data-col="2"]');
    (0, _vitest.expect)(col1.getAttribute("data-drag")).toBe(null);
    (0, _vitest.expect)(col2.getAttribute("data-drag")).toBe(null);
    _react.fireEvent.dragOver(col2, {
      dataTransfer: dataTransfer({
        files: [note()]
      })
    });
    (0, _vitest.expect)(col2.getAttribute("data-drag")).toBe("1");
    (0, _vitest.expect)(col1.getAttribute("data-drag")).toBe(null);
    _react.fireEvent.dragLeave(col2, {
      relatedTarget: document.body
    });
    (0, _vitest.expect)(col2.getAttribute("data-drag")).toBe(null);
  });
  (0, _vitest.it)("a null cwd (the roots-root) accepts nothing: there is no directory to fall back to", async () => {
    // With NO selection and TWO mounts, chooseLayout("list") seeds cwd = null
    // (the roots-root), where the container has no directory to offer and must
    // accept nothing at all. So: no renderWithSrcExpanded (its click selects).
    const user = _userEvent.default.setup();
    h.mounts = [worktree("r1"), {
      type: "worktree",
      path: "/mnt/xyz",
      id: "r2"
    }];
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    await _react.screen.findAllByText("r1"); // the tree renders both mount scopes
    await user.click(_react.screen.getByRole("radio", {
      name: "List view"
    }));
    await _react.screen.findAllByText("r2"); // the roots-root lists both mounts
    const layout = document.querySelector(".layout--list");
    _react.fireEvent.dragOver(layout, {
      dataTransfer: dataTransfer({
        files: [note()]
      })
    });
    (0, _vitest.expect)(layout.getAttribute("data-drag")).toBe(null);
    _react.fireEvent.drop(layout, {
      dataTransfer: dataTransfer({
        files: [note()]
      })
    });
    (0, _vitest.expect)(h.uploadFile).not.toHaveBeenCalled();
  });
  (0, _vitest.it)("list: an internal MOVE drag is not taken by the flat container", async () => {
    const user = await toLayout("List view");
    await user.click(await _react.screen.findAllByText("repo")[0]);
    await _react.screen.findAllByText("src");
    const layout = document.querySelector(".layout--list");
    const move = dataTransfer({
      move: JSON.stringify({
        from: "/mnt/abc/README.md",
        rootPath: "/mnt/abc"
      })
    });
    _react.fireEvent.dragOver(layout, {
      dataTransfer: move
    });
    (0, _vitest.expect)(layout.getAttribute("data-drag")).toBe(null);
    _react.fireEvent.drop(layout, {
      dataTransfer: move
    });
    (0, _vitest.expect)(h.uploadFile).not.toHaveBeenCalled();
    (0, _vitest.expect)(h.renameEntry).not.toHaveBeenCalled();
  });
  (0, _vitest.it)("a read-only mount's flat container accepts nothing", async () => {
    const user = _userEvent.default.setup();
    h.mounts = [space()]; // mode "ro"
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_SdkFileExplorer.default, {}));
    await _react.screen.findAllByText("Shared notes");
    await user.click(_react.screen.getByRole("radio", {
      name: "List view"
    }));
    await _react.screen.findAllByText("Shared notes"); // the cwd seeded to the space root
    const layout = document.querySelector(".layout--list");
    _react.fireEvent.dragOver(layout, {
      dataTransfer: dataTransfer({
        files: [note()]
      })
    });
    (0, _vitest.expect)(layout.getAttribute("data-drag")).toBe(null);
    _react.fireEvent.drop(layout, {
      dataTransfer: dataTransfer({
        files: [note()]
      })
    });
    (0, _vitest.expect)(h.uploadFile).not.toHaveBeenCalled();
  });
  (0, _vitest.it)("the tree scope: a drop a directory row takes clears the affordance the hover lit", async () => {
    // The same capture-clear, on the tree's scope — its rows stopPropagation on
    // drop, so without the capture handler data-drag would stick here too.
    await renderWithSrcExpanded();
    const scope = _react.screen.getByText("src").closest(".mount");
    const row = _react.screen.getByText("src").closest(".tnode");
    _react.fireEvent.dragOver(scope, {
      dataTransfer: dataTransfer({
        files: [note()]
      })
    });
    (0, _vitest.expect)(scope.getAttribute("data-drag")).toBe("1");
    _react.fireEvent.drop(row, {
      dataTransfer: dataTransfer({
        files: [note()]
      })
    });
    await _vitest.vi.waitFor(() => (0, _vitest.expect)(h.uploadFile).toHaveBeenCalled());
    (0, _vitest.expect)(h.uploadFile).toHaveBeenCalledTimes(1);
    (0, _vitest.expect)(scope.getAttribute("data-drag")).toBe(null);
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3VzZXJFdmVudCIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJfdml0ZXN0IiwiX1Nka0ZpbGVFeHBsb3JlciIsIl9qc3hSdW50aW1lIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiVFJFRSIsIm5hbWUiLCJpc0RpciIsImgiLCJ2aSIsImhvaXN0ZWQiLCJyYXdMaXN0ZW5lcnMiLCJNYXAiLCJlbWl0IiwidHlwZSIsIm1zZyIsImZuIiwiZ2V0IiwibW91bnRzIiwic2Vzc2lvbk1vdW50cyIsImFjdGl2ZUZpbGUiLCJ2aWV3ZWRGaWxlIiwib3BlbkluRWRpdG9yIiwiUHJvbWlzZSIsInJlc29sdmUiLCJyZXBvcnRSZWFkeSIsInJlcG9ydFJlYWR5TGlzdGVuZXJDb3VudCIsInB1c2giLCJzaXplIiwiZGVsZXRlRW50cnkiLCJyZW5hbWVFbnRyeSIsInVwbG9hZEZpbGUiLCJzdGFydEl0ZW1EcmFnIiwiY2FuY2VsSXRlbURyYWciLCJyZWFkZGlyIiwicGF0aCIsImxpc3RTZXR0aW5nc0FwcHMiLCJyZXF1ZXN0TW91bnQiLCJyZWdpb24iLCJtb2NrIiwiYWRkTGlzdGVuZXIiLCJoYW5kbGVyIiwic2V0IiwiU2V0IiwiYWRkIiwiZGVsZXRlIiwic2VuZE1lc3NhZ2UiLCJ1c2VNb3VudHMiLCJ1c2VTZXNzaW9uTW91bnRzIiwidXNlRWRpdG9yQ29udGV4dCIsImRpcnR5UGF0aHMiLCJvcGVuRmlsZXMiLCJjcmVhdGVGaWxlIiwiY3JlYXRlRm9sZGVyIiwiZnJvbSIsInRvIiwiYnl0ZXMiLCJpdGVtIiwidW5tb3VudFNwYWNlIiwib3BlblNldHRpbmdzT2YiLCJpZCIsInVzZVJlZ2lvbiIsInJlYWRGaWxlIiwiVWludDhBcnJheSIsInNka0ZzU291cmNlIiwid29ya3RyZWUiLCJiZWZvcmVFYWNoIiwiY2xlYXIiLCJtb2NrQ2xlYXIiLCJhZnRlckVhY2giLCJjbGVhckFsbE1vY2tzIiwicmVuZGVyV2l0aFNyY0V4cGFuZGVkIiwidXNlciIsInVzZXJFdmVudCIsInNldHVwIiwidXRpbHMiLCJyZW5kZXIiLCJqc3giLCJzY3JlZW4iLCJmaW5kQnlUZXh0Iiwic3JjIiwiZ2V0QnlSb2xlIiwiZ2V0QXR0cmlidXRlIiwiY2xpY2siLCJnZXRCeVRleHQiLCJkZXNjcmliZSIsIml0IiwiZXhwZWN0IiwidG9IYXZlQmVlbkNhbGxlZFRpbWVzIiwidG9IYXZlQmVlbkNhbGxlZFdpdGgiLCJ0b0hhdmVBdHRyaWJ1dGUiLCJzcmNJdGVtIiwiY2xvc2VzdCIsIndpdGhpbiIsInRvQmVJblRoZURvY3VtZW50IiwicmVyZW5kZXIiLCJyb3dPZiIsInRvSGF2ZUNsYXNzIiwibm90IiwiY2FsbHNCZWZvcmUiLCJjYWxscyIsImxlbmd0aCIsInRvQmUiLCJzcGFjZSIsIm1vZGUiLCJmaW5kQnlSb2xlIiwic3BhY2VUcmVlIiwic2NvcGUiLCJxdWVyeUJ5TGFiZWxUZXh0IiwicXVlcnlCeVJvbGUiLCJydWxlcyIsInN1YnRyZWUiLCJjaGlwcyIsImdldEFsbEJ5VGV4dCIsIm1hcCIsImMiLCJ0ZXh0Q29udGVudCIsInRvRXF1YWwiLCJzdHJpbmdDb250YWluaW5nIiwidG9IYXZlTGVuZ3RoIiwidG9Db250YWluIiwiZmlyZUV2ZW50IiwiY29udGV4dE1lbnUiLCJtZW51IiwibGFiZWwiLCJSZWdFeHAiLCJjb25maXJtIiwic3B5T24iLCJ3aW5kb3ciLCJtb2NrUmV0dXJuVmFsdWUiLCJtb2NrUmVzdG9yZSIsInRvSGF2ZUJlZW5DYWxsZWQiLCJjb3B5Iiwic3RhdGUiLCJoaXN0b3J5IiwicmVwbGFjZVN0YXRlIiwiZW5jb2RlVVJJQ29tcG9uZW50Iiwib3BlbiIsInRyZWUiLCJkYXRhVHJhbnNmZXIiLCJvcHRzIiwidHlwZXMiLCJtb3ZlIiwiZmlsZXMiLCJnZXREYXRhIiwidCIsInNldERhdGEiLCJkcm9wRWZmZWN0IiwiZWZmZWN0QWxsb3dlZCIsInNyY1JvdyIsImRyb3AiLCJKU09OIiwic3RyaW5naWZ5Iiwicm9vdFBhdGgiLCJ0b0hhdmVUZXh0Q29udGVudCIsImZpbGUiLCJGaWxlIiwid2FpdEZvciIsImZpbGVSb3ciLCJkcmFnT3ZlciIsImRyYWdMZWF2ZSIsInJlbGF0ZWRUYXJnZXQiLCJkb2N1bWVudCIsImJvZHkiLCJjb250YWluZXIiLCJpbnB1dCIsInF1ZXJ5U2VsZWN0b3IiLCJjaGFuZ2UiLCJ0YXJnZXQiLCJkcmFnU3RhcnQiLCJ0b01hdGNoT2JqZWN0Iiwia2luZCIsInJlbFBhdGgiLCJzZXNzaW9uU3BhY2UiLCJmb3J3YXJkZWRUb0FwcCIsInRvQmVOdWxsIiwic2V0dGluZ3NNb3VudCIsImxvY2FsU3RvcmFnZSIsIm1vY2tSZXNvbHZlZFZhbHVlIiwicXVlcnlCeVRpdGxlIiwiZmluZEJ5VGl0bGUiLCJnZXRJdGVtIiwidG9nZ2xlIiwic2V0SXRlbSIsImJ0biIsInRyYXkiLCJxdWVyeVNlbGVjdG9yQWxsIiwicXVlcnlCeVRleHQiLCJiZWZvcmUiLCJtaW5lIiwic2xpY2UiLCJzY3JvbGxzIiwib3JpZyIsIkVsZW1lbnQiLCJwcm90b3R5cGUiLCJzY3JvbGxJbnRvVmlldyIsImFjdCIsInJvdyIsInRvQmVHcmVhdGVyVGhhbiIsImFjdGl2ZUVsZW1lbnQiLCJyIiwic2V0VGltZW91dCIsIm1hcmtzIiwiZ2V0QWxsQnlSb2xlIiwidG9Db250YWluRWxlbWVudCIsIm5vdGUiLCJ0b0xheW91dCIsImxheW91dFRpcCIsImxheW91dCIsImZpbmRBbGxCeVRleHQiLCJjb2wxIiwiY29sMiJdLCJzb3VyY2VzIjpbIkZpbGVFeHBsb3Jlci50ZXN0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBGWC0zIHJlZ3Jlc3Npb24gZ3VhcmQgZm9yIHRoZSBmaWxlLWV4cGxvcmVyIHJlbmRlcmluZy9leHBhbnNpb24gZml4ZXMuXG4vL1xuLy8gQ292ZXJzIHRoZSB0d28gcmVwb3J0ZWQgZGVmZWN0cyBhbmQgdGhlIHNlbGVjdGlvbiBpbmRpY2F0b3I6XG4vLyAtIEZYLTI6IGNsaWNraW5nIGEgZmlsZSBpbiBhbiBleHBhbmRlZCBzdWJkaXJlY3RvcnkgbXVzdCBOT1QgY29sbGFwc2UgaXQsIGFuZFxuLy8gICBvcGVucyBpdCB3aXRoIHRoZSByZXBvLXJlbGF0aXZlIHBhdGguXG4vLyAtIEZYLTRhOiB0aGUgY2xpY2tlZCByb3cgaXMgbWFya2VkIHNlbGVjdGVkLCBhbmQgdGhlIHNlbGVjdGlvbiBzdXJ2aXZlcyBhXG4vLyAgIGJlbmlnbiB3b3JrdHJlZSByZS1hbm5vdW5jZS5cbi8vIC0gRlgtMSAobm8tcmVtb3VudCBwcm94eSk6IGEgYmVuaWduIHdvcmt0cmVlIHJlLWFubm91bmNlIChhIG5ldyBtb3VudCBvYmplY3Rcbi8vICAgd2l0aCB0aGUgc2FtZSBwYXRoKSBtdXN0IG5vdCByZW1vdW50L3JlbG9hZCB0aGUgdHJlZSDigJQgYXNzZXJ0ZWQgdmlhIHRoZVxuLy8gICBgcmVhZGRpcmAgY2FsbCBjb3VudCBzdGF5aW5nIGZsYXQgYW5kIGV4cGFuc2lvbiBiZWluZyBwcmVzZXJ2ZWQuXG5pbXBvcnQgeyBhY3QsIGZpcmVFdmVudCwgcmVuZGVyLCBzY3JlZW4sIHdhaXRGb3IsIHdpdGhpbiB9IGZyb20gXCJAdGVzdGluZy1saWJyYXJ5L3JlYWN0XCI7XG5pbXBvcnQgdXNlckV2ZW50IGZyb20gXCJAdGVzdGluZy1saWJyYXJ5L3VzZXItZXZlbnRcIjtcbmltcG9ydCB7IGFmdGVyRWFjaCwgYmVmb3JlRWFjaCwgZGVzY3JpYmUsIGV4cGVjdCwgaXQsIHZpIH0gZnJvbSBcInZpdGVzdFwiO1xuaW1wb3J0IHR5cGUgeyBEaXJFbnRyeSB9IGZyb20gXCIuLi90eXBlc1wiO1xuXG4vLyBBIHR3by1sZXZlbCBmaXh0dXJlIHRyZWU7IGByZWFkZGlyYCByZXNvbHZlcyBmcm9tIGl0LlxuY29uc3QgVFJFRTogUmVjb3JkPHN0cmluZywgRGlyRW50cnlbXT4gPSB7XG4gIFwiL21udC9hYmNcIjogW1xuICAgIHsgbmFtZTogXCJzcmNcIiwgaXNEaXI6IHRydWUgfSxcbiAgICB7IG5hbWU6IFwiUkVBRE1FLm1kXCIsIGlzRGlyOiBmYWxzZSB9LFxuICBdLFxuICBcIi9tbnQvYWJjL3NyY1wiOiBbXG4gICAgeyBuYW1lOiBcImluZGV4LnRzXCIsIGlzRGlyOiBmYWxzZSB9LFxuICAgIHsgbmFtZTogXCJ1dGlsLnRzXCIsIGlzRGlyOiBmYWxzZSB9LFxuICBdLFxuICBcIi9zcGFjZXMvczFcIjogW3sgbmFtZTogXCJub3RlLm1kXCIsIGlzRGlyOiBmYWxzZSB9XSxcbn07XG5cbi8vIE11dGFibGUgdGVzdCBkb3VibGVzLCBzaGFyZWQgd2l0aCB0aGUgaG9pc3RlZCBtb2R1bGUgbW9ja3MgYmVsb3cuXG5jb25zdCBoID0gdmkuaG9pc3RlZCgoKSA9PiAoe1xuICAvLyBSYXcgaG9zdC0+YXBwIG1lc3NhZ2UgbGlzdGVuZXJzICh0aGUgbW9ja2VkIHNhbmRib3hVdGlscy5hZGRMaXN0ZW5lciByZWdpc3RyeSkuXG4gIHJhd0xpc3RlbmVyczogbmV3IE1hcDxzdHJpbmcsIFNldDwobTogdW5rbm93bikgPT4gdm9pZD4+KCksXG4gIGVtaXQodHlwZTogc3RyaW5nLCBtc2c6IHVua25vd24pIHtcbiAgICBmb3IgKGNvbnN0IGZuIG9mIGgucmF3TGlzdGVuZXJzLmdldCh0eXBlKSA/PyBbXSkgZm4obXNnKTtcbiAgfSxcbiAgbW91bnRzOiBbXSBhcyBBcnJheTx7IHR5cGU6IHN0cmluZzsgcGF0aDogc3RyaW5nOyBpZD86IHN0cmluZyB9PixcbiAgLy8gVGhlIGZpcnN0LXBhcnR5IFNlc3Npb24tbGVucyBsaXN0IChSMy05NSkuIERlZmF1bHQgbm9uZTogYSBub24tZmlyc3QtcGFydHkgZnJhbWVcbiAgLy8gKGEgZm9yaykgcmVjZWl2ZXMgYFtdYCwgc28gdGhlIFwiQXBwIHwgU2Vzc2lvblwiIHRvZ2dsZSBuZXZlciByZW5kZXJzLlxuICBzZXNzaW9uTW91bnRzOiBbXSBhcyBBcnJheTx7IHR5cGU6IHN0cmluZzsgcGF0aDogc3RyaW5nOyBpZD86IHN0cmluZzsgbmFtZT86IHN0cmluZzsgbW9kZT86IFwicm9cIiB8IFwicndcIjsgZm9yd2FyZGVkVG9BcHA6IGJvb2xlYW4gfT4sXG4gIC8vIFRoZSBlZGl0b3ItY29udGV4dCBhY3RpdmUgZmlsZSAoRlgtNGIpLiBNdXRhYmxlIHNvIGEgdGVzdCBjYW4gbW92ZSBpdCBhbmRcbiAgLy8gcmUtcmVuZGVyLCBtaXJyb3JpbmcgYSBob3N0IHB1c2guXG4gIGFjdGl2ZUZpbGU6IG51bGwgYXMgc3RyaW5nIHwgbnVsbCxcbiAgLy8gVGhlIHN0YWdlJ3Mgdmlld2VkLWRvY3VtZW50IGhpbnQgKFIzLTI2OCksIHB1c2hlZCBvbiB0aGUgc2FtZSBjaGFubmVsLlxuICB2aWV3ZWRGaWxlOiBudWxsIGFzIHN0cmluZyB8IG51bGwsXG4gIC8vIFRoZSBhcmcgaXMgcmVjb3JkZWQgYnkgdGhlIHNweSB2aWEgdGhlIGZhY3RvcnkgY2FsbCBiZWxvdywgc28gdGhlIGltcGwgbmVlZHNcbiAgLy8gbm8gcGFyYW07IGFzc2VydGlvbnMgdXNlIGB0b0hhdmVCZWVuQ2FsbGVkV2l0aGAuXG4gIG9wZW5JbkVkaXRvcjogdmkuZm4oKCk6IFByb21pc2U8dm9pZD4gPT4gUHJvbWlzZS5yZXNvbHZlKCkpLFxuICAvLyBSMy00NDA6IHJlcG9ydFJlYWR5IOKAlCByZWNvcmRlZCwgd2l0aCB0aGUgc3Vic2NyaXB0aW9uIHN0YXRlIGNhcHR1cmVkIEFUIHRoZVxuICAvLyBjYWxsIHNvIHRoZSBvcmRlcmluZyBjb250cmFjdCAoXCJyZXBvcnQgaW1tZWRpYXRlbHkgYWZ0ZXIgc3Vic2NyaWJpbmdcIikgaXNcbiAgLy8gYXNzZXJ0YWJsZSByYXRoZXIgdGhhbiBhc3N1bWVkLlxuICByZXBvcnRSZWFkeTogdmkuZm4oKCkgPT4ge1xuICAgIGgucmVwb3J0UmVhZHlMaXN0ZW5lckNvdW50LnB1c2goaC5yYXdMaXN0ZW5lcnMuZ2V0KFwidmlld2VkLXJldmVhbFwiKT8uc2l6ZSA/PyAwKTtcbiAgfSksXG4gIHJlcG9ydFJlYWR5TGlzdGVuZXJDb3VudDogW10gYXMgbnVtYmVyW10sXG4gIGRlbGV0ZUVudHJ5OiB2aS5mbigoKTogUHJvbWlzZTx2b2lkPiA9PiBQcm9taXNlLnJlc29sdmUoKSksXG4gIHJlbmFtZUVudHJ5OiB2aS5mbigoKTogUHJvbWlzZTx2b2lkPiA9PiBQcm9taXNlLnJlc29sdmUoKSksXG4gIHVwbG9hZEZpbGU6IHZpLmZuKCgpOiBQcm9taXNlPHZvaWQ+ID0+IFByb21pc2UucmVzb2x2ZSgpKSxcbiAgc3RhcnRJdGVtRHJhZzogdmkuZm4oKCk6IFByb21pc2U8dm9pZD4gPT4gUHJvbWlzZS5yZXNvbHZlKCkpLFxuICBjYW5jZWxJdGVtRHJhZzogdmkuZm4oKCkgPT4ge30pLFxuICByZWFkZGlyOiB2aS5mbigocGF0aDogc3RyaW5nKSA9PiBQcm9taXNlLnJlc29sdmUoVFJFRVtwYXRoXSA/PyBbXSkpLFxuICBsaXN0U2V0dGluZ3NBcHBzOiB2aS5mbigoKTogUHJvbWlzZTxzdHJpbmdbXT4gPT4gUHJvbWlzZS5yZXNvbHZlKFtdKSksXG4gIC8vIFIzLTI2OSBENTogdGhlIGhvc3QgcG93ZXJib3ggcmVxdWVzdC4gTmV2ZXIgcmVzb2x2ZXMgYnkgZGVmYXVsdCDigJQgdGhlIGZsb3cgaXNcbiAgLy8gaG9zdC1vd25lZDsgdGhlc2UgdGVzdHMgb25seSBhc3NlcnQgdGhlIGFwcCBBU0tTLlxuICByZXF1ZXN0TW91bnQ6IHZpLmZuKCgpOiBQcm9taXNlPHVua25vd24+ID0+IG5ldyBQcm9taXNlKCgpID0+IHt9KSksXG4gIC8vIFRoZSBhcHAncyBSZWdpb25JZCAoUjMtOTYpOiBgcGFnZS5jb21tYW5kZXJgIG1ha2VzIHRoZSBhcHAgZGVmYXVsdCB0byB0aGUgYnJvYWRcbiAgLy8gcmVnaXN0cnkgbGVucy4gRGVmYXVsdCBudWxsIChhIGBwYW5lbC5maWxlc2AgcHJvamVjdGlvbiBiZWhhdmVzIEFwcC1maXJzdCBhcyBiZWZvcmUpLlxuICByZWdpb246IG51bGwgYXMgc3RyaW5nIHwgbnVsbCxcbn0pKTtcblxuLy8gVGhlIHN1YnBhdGggbW9kdWxlIHRoZSByZXZlYWwgbGlzdGVuZXIgcmlkZXMuIFRoZSBSRUFMIHNhbmRib3hVdGlscyBjYW5ub3QgbG9hZFxuLy8gdW5kZXIgdml0ZXN0ICh0c3VwIGV4dGVuc2lvbmxlc3Mgc3BlY2lmaWVycyksIGFuZCBtb2NraW5nIGl0IGhlcmUgYWxzbyBnaXZlcyB0aGVcbi8vIHN1aXRlIGEgY29udHJvbGxhYmxlIGhvc3QtPmFwcCBjaGFubmVsOiBwdXNoIHdpdGggaC5lbWl0KCd2aWV3ZWQtcmV2ZWFsJywgbXNnKS5cbnZpLm1vY2soXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9zYW5kYm94VXRpbHNcIiwgKCkgPT4gKHtcbiAgYWRkTGlzdGVuZXI6ICh0eXBlOiBzdHJpbmcsIGhhbmRsZXI6IChtOiB1bmtub3duKSA9PiB2b2lkKSA9PiB7XG4gICAgY29uc3Qgc2V0ID0gaC5yYXdMaXN0ZW5lcnMuZ2V0KHR5cGUpID8/IG5ldyBTZXQ8KG06IHVua25vd24pID0+IHZvaWQ+KCk7XG4gICAgc2V0LmFkZChoYW5kbGVyKTtcbiAgICBoLnJhd0xpc3RlbmVycy5zZXQodHlwZSwgc2V0KTtcbiAgICByZXR1cm4gKCkgPT4gc2V0LmRlbGV0ZShoYW5kbGVyKTtcbiAgfSxcbiAgc2VuZE1lc3NhZ2U6IHZpLmZuKCksXG59KSk7XG5cbnZpLm1vY2soXCJAaW1tZWRpYXRlbHktcnVuL3Nka1wiLCAoKSA9PiAoe1xuICB1c2VNb3VudHM6ICgpID0+IGgubW91bnRzLFxuICB1c2VTZXNzaW9uTW91bnRzOiAoKSA9PiBoLnNlc3Npb25Nb3VudHMsXG4gIHVzZUVkaXRvckNvbnRleHQ6ICgpID0+ICh7XG4gICAgZGlydHlQYXRoczogW10sXG4gICAgb3BlbkZpbGVzOiBbXSxcbiAgICBhY3RpdmVGaWxlOiBoLmFjdGl2ZUZpbGUsXG4gICAgdmlld2VkRmlsZTogaC52aWV3ZWRGaWxlLFxuICB9KSxcbiAgb3BlbkluRWRpdG9yOiAocGF0aDogc3RyaW5nKSA9PiBoLm9wZW5JbkVkaXRvcihwYXRoKSxcbiAgY3JlYXRlRmlsZTogdmkuZm4oKCkgPT4gUHJvbWlzZS5yZXNvbHZlKCkpLFxuICBjcmVhdGVGb2xkZXI6IHZpLmZuKCgpID0+IFByb21pc2UucmVzb2x2ZSgpKSxcbiAgZGVsZXRlRW50cnk6IChwYXRoOiBzdHJpbmcpID0+IGguZGVsZXRlRW50cnkocGF0aCksXG4gIHJlbmFtZUVudHJ5OiAoZnJvbTogc3RyaW5nLCB0bzogc3RyaW5nKSA9PiBoLnJlbmFtZUVudHJ5KGZyb20sIHRvKSxcbiAgdXBsb2FkRmlsZTogKHBhdGg6IHN0cmluZywgYnl0ZXM6IFVpbnQ4QXJyYXkpID0+IGgudXBsb2FkRmlsZShwYXRoLCBieXRlcyksXG4gIHN0YXJ0SXRlbURyYWc6IChpdGVtOiB1bmtub3duKSA9PiBoLnN0YXJ0SXRlbURyYWcoaXRlbSksXG4gIGNhbmNlbEl0ZW1EcmFnOiAoKSA9PiBoLmNhbmNlbEl0ZW1EcmFnKCksXG4gIHVubW91bnRTcGFjZTogdmkuZm4oKCkgPT4gUHJvbWlzZS5yZXNvbHZlKCkpLFxuICAvLyBzZXR0aW5nczphbGwgZW51bWVyYXRpb24g4oCUIGRlZmF1bHQgdG8gbm9uZSBzbyB0aGUgYmFzZSBmaWxlIHRyZWUgaXMgdW5hZmZlY3RlZC5cbiAgbGlzdFNldHRpbmdzQXBwczogKCkgPT4gaC5saXN0U2V0dGluZ3NBcHBzKCksXG4gIG9wZW5TZXR0aW5nc09mOiB2aS5mbigoKSA9PiBQcm9taXNlLnJlc29sdmUoeyB0eXBlOiBcImZpcmVzdG9yZVwiLCBwYXRoOiBcIi9tbnQvc2V0XCIsIGlkOiBcInNldHRpbmdzOnhcIiB9KSksXG4gIHJlcXVlc3RNb3VudDogKCkgPT4gaC5yZXF1ZXN0TW91bnQoKSxcbiAgdXNlUmVnaW9uOiAoKSA9PiBoLnJlZ2lvbixcbiAgLy8gUjMtNDQwOiB0aGUgcmVhZGluZXNzIHJlcG9ydCB0aGUgaG9zdCBnYXRlcyB0aGUgdmlld2VkLXJldmVhbCBvbmUtc2hvdCBvbi5cbiAgLy8gVGhlIG1vY2sgYXNzZXJ0cyB0aGUgQ09OVFJBQ1QgYXQgY2FsbCB0aW1lOiB0aGUgcmV2ZWFsIGxpc3RlbmVyIG11c3QgYWxyZWFkeVxuICAvLyBiZSBzdWJzY3JpYmVkIChhIHJlcG9ydCBiZWZvcmUgaXQgd291bGQgcmVsZWFzZSByZXZlYWxzIG5vYm9keSBoZWFycykuXG4gIHJlcG9ydFJlYWR5OiAoKSA9PiBoLnJlcG9ydFJlYWR5KCksXG59KSk7XG5cbnZpLm1vY2soXCIuL21vdW50RnNcIiwgKCkgPT4gKHtcbiAgcmVhZGRpcjogKHBhdGg6IHN0cmluZykgPT4gaC5yZWFkZGlyKHBhdGgpLFxuICByZWFkRmlsZTogKCkgPT4gUHJvbWlzZS5yZXNvbHZlKG5ldyBVaW50OEFycmF5KFsxLCAyLCAzXSkpLFxuICBzZGtGc1NvdXJjZToge1xuICAgIHJlYWRkaXI6IChwYXRoOiBzdHJpbmcpID0+IGgucmVhZGRpcihwYXRoKSxcbiAgICByZWFkRmlsZTogKCkgPT4gUHJvbWlzZS5yZXNvbHZlKG5ldyBVaW50OEFycmF5KFsxLCAyLCAzXSkpLFxuICB9LFxufSkpO1xuXG5pbXBvcnQgRmlsZUV4cGxvcmVyIGZyb20gXCIuL1Nka0ZpbGVFeHBsb3JlclwiO1xuXG5jb25zdCB3b3JrdHJlZSA9IChpZCA9IFwicmVwb1wiKSA9PiAoeyB0eXBlOiBcIndvcmt0cmVlXCIsIHBhdGg6IFwiL21udC9hYmNcIiwgaWQgfSk7XG5cbmJlZm9yZUVhY2goKCkgPT4ge1xuICBoLm1vdW50cyA9IFt3b3JrdHJlZSgpXTtcbiAgaC5zZXNzaW9uTW91bnRzID0gW107XG4gIGguYWN0aXZlRmlsZSA9IG51bGw7XG4gIGgudmlld2VkRmlsZSA9IG51bGw7XG4gIGgucmF3TGlzdGVuZXJzLmNsZWFyKCk7XG4gIGgucmVnaW9uID0gbnVsbDtcbiAgaC5vcGVuSW5FZGl0b3IubW9ja0NsZWFyKCk7XG4gIGgucmVhZGRpci5tb2NrQ2xlYXIoKTtcbn0pO1xuXG5hZnRlckVhY2goKCkgPT4ge1xuICB2aS5jbGVhckFsbE1vY2tzKCk7XG59KTtcblxuLyoqIFJlbmRlciwgd2FpdCBmb3IgdGhlIHJvb3QgdG8gbG9hZCwgZXhwYW5kIGBzcmNgLCB3YWl0IGZvciBpdHMgY2hpbGRyZW4uXG4gKiAgV2hlbiBgYWN0aXZlRmlsZWAgcG9pbnRzIGludG8gYHNyY2AsIHRoZSBlZGl0b3ItYWN0aXZlIHJldmVhbCBoYXMgYWxyZWFkeVxuICogIG9wZW5lZCBpdCDigJQgY2xpY2tpbmcgYWdhaW4gd291bGQgQ0xPU0UgaXQsIHNvIG9ubHkgY2xpY2sgd2hlbiBzdGlsbCBjbG9zZWQuICovXG5hc3luYyBmdW5jdGlvbiByZW5kZXJXaXRoU3JjRXhwYW5kZWQoKSB7XG4gIGNvbnN0IHVzZXIgPSB1c2VyRXZlbnQuc2V0dXAoKTtcbiAgY29uc3QgdXRpbHMgPSByZW5kZXIoPEZpbGVFeHBsb3JlciAvPik7XG4gIC8vIFJvb3QgaXMgb3BlbiBieSBkZWZhdWx0IOKGkiB0b3AtbGV2ZWwgZW50cmllcyBhcHBlYXIuXG4gIGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KFwic3JjXCIpO1xuICBjb25zdCBzcmMgPSBzY3JlZW4uZ2V0QnlSb2xlKFwidHJlZWl0ZW1cIiwgeyBuYW1lOiBcInNyY1wiIH0pO1xuICBpZiAoc3JjLmdldEF0dHJpYnV0ZShcImFyaWEtZXhwYW5kZWRcIikgIT09IFwidHJ1ZVwiKSB7XG4gICAgYXdhaXQgdXNlci5jbGljayhzY3JlZW4uZ2V0QnlUZXh0KFwic3JjXCIpKTtcbiAgfVxuICAvLyBTdWJkaXJlY3RvcnkgY2hpbGRyZW4gYXBwZWFyIG9uY2UgcmVhZGRpciByZXNvbHZlcy5cbiAgYXdhaXQgc2NyZWVuLmZpbmRCeVRleHQoXCJpbmRleC50c1wiKTtcbiAgcmV0dXJuIHsgdXNlciwgLi4udXRpbHMgfTtcbn1cblxuZGVzY3JpYmUoXCJGaWxlRXhwbG9yZXJcIiwgKCkgPT4ge1xuICBpdChcIkZYLTI6IGNsaWNraW5nIGEgZmlsZSBpbiBhIHN1YmRpcmVjdG9yeSBrZWVwcyB0aGUgc3ViZGlyZWN0b3J5IG9wZW5cIiwgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHsgdXNlciB9ID0gYXdhaXQgcmVuZGVyV2l0aFNyY0V4cGFuZGVkKCk7XG5cbiAgICBhd2FpdCB1c2VyLmNsaWNrKHNjcmVlbi5nZXRCeVRleHQoXCJpbmRleC50c1wiKSk7XG5cbiAgICAvLyBPcGVuZWQgd2l0aCB0aGUgcmVwby1yZWxhdGl2ZSBwYXRoIChtb3VudCBwcmVmaXggc3RyaXBwZWQpLCBub3QgL21udC8uLi5cbiAgICBleHBlY3QoaC5vcGVuSW5FZGl0b3IpLnRvSGF2ZUJlZW5DYWxsZWRUaW1lcygxKTtcbiAgICBleHBlY3QoaC5vcGVuSW5FZGl0b3IpLnRvSGF2ZUJlZW5DYWxsZWRXaXRoKFwiL3NyYy9pbmRleC50c1wiKTtcblxuICAgIC8vIFRoZSBzdWJkaXJlY3RvcnkgaXMgc3RpbGwgZXhwYW5kZWQgYW5kIGl0cyBjb250ZW50cyBzdGlsbCB2aXNpYmxlLlxuICAgIC8vIChUaGUgdHJlZWl0ZW0gaXMgdGhlIHJvdyBlbGVtZW50OyBpdHMgY2hpbGQgcm93cyBsaXZlIGluIHRoZSBzaWJsaW5nXG4gICAgLy8gZ3JvdXAsIHNvIHNjb3BlIHRoZSBxdWVyeSB0byB0aGUgcm93J3MgbGlzdCBpdGVtLilcbiAgICBjb25zdCBzcmMgPSBzY3JlZW4uZ2V0QnlSb2xlKFwidHJlZWl0ZW1cIiwgeyBuYW1lOiBcInNyY1wiIH0pO1xuICAgIGV4cGVjdChzcmMpLnRvSGF2ZUF0dHJpYnV0ZShcImFyaWEtZXhwYW5kZWRcIiwgXCJ0cnVlXCIpO1xuICAgIGNvbnN0IHNyY0l0ZW0gPSBzcmMuY2xvc2VzdChcImxpXCIpIGFzIEhUTUxFbGVtZW50O1xuICAgIGV4cGVjdCh3aXRoaW4oc3JjSXRlbSkuZ2V0QnlUZXh0KFwiaW5kZXgudHNcIikpLnRvQmVJblRoZURvY3VtZW50KCk7XG4gICAgZXhwZWN0KHdpdGhpbihzcmNJdGVtKS5nZXRCeVRleHQoXCJ1dGlsLnRzXCIpKS50b0JlSW5UaGVEb2N1bWVudCgpO1xuICB9KTtcblxuICBpdChcIkZYLTRhOiB0aGUgY2xpY2tlZCBmaWxlIGlzIG1hcmtlZCBzZWxlY3RlZCBhbmQgc3RheXMgc2VsZWN0ZWQgYWNyb3NzIGEgcmUtYW5ub3VuY2VcIiwgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHsgdXNlciwgcmVyZW5kZXIgfSA9IGF3YWl0IHJlbmRlcldpdGhTcmNFeHBhbmRlZCgpO1xuXG4gICAgYXdhaXQgdXNlci5jbGljayhzY3JlZW4uZ2V0QnlUZXh0KFwiaW5kZXgudHNcIikpO1xuICAgIGV4cGVjdChzY3JlZW4uZ2V0QnlSb2xlKFwidHJlZWl0ZW1cIiwgeyBuYW1lOiBcImluZGV4LnRzXCIgfSkpLnRvSGF2ZUF0dHJpYnV0ZShcbiAgICAgIFwiYXJpYS1zZWxlY3RlZFwiLFxuICAgICAgXCJ0cnVlXCIsXG4gICAgKTtcblxuICAgIC8vIEEgYmVuaWduIHdvcmt0cmVlIHJlLWFubm91bmNlOiBhIE5FVyBtb3VudCBvYmplY3QsIHNhbWUgcGF0aC5cbiAgICBoLm1vdW50cyA9IFt3b3JrdHJlZSgpXTtcbiAgICByZXJlbmRlcig8RmlsZUV4cGxvcmVyIC8+KTtcblxuICAgIGV4cGVjdChzY3JlZW4uZ2V0QnlSb2xlKFwidHJlZWl0ZW1cIiwgeyBuYW1lOiBcImluZGV4LnRzXCIgfSkpLnRvSGF2ZUF0dHJpYnV0ZShcbiAgICAgIFwiYXJpYS1zZWxlY3RlZFwiLFxuICAgICAgXCJ0cnVlXCIsXG4gICAgKTtcbiAgICBleHBlY3Qoc2NyZWVuLmdldEJ5Um9sZShcInRyZWVpdGVtXCIsIHsgbmFtZTogXCJzcmNcIiB9KSkudG9IYXZlQXR0cmlidXRlKFxuICAgICAgXCJhcmlhLWV4cGFuZGVkXCIsXG4gICAgICBcInRydWVcIixcbiAgICApO1xuICB9KTtcblxuICBpdChcIkZYLTRiOiB0aGUgZWRpdG9yJ3MgYWN0aXZlIGZpbGUgaXMgaGlnaGxpZ2h0ZWQsIGFuZCB0aGUgaGlnaGxpZ2h0IG1vdmVzIHdpdGhvdXQgY29sbGFwc2luZyB0aGUgdHJlZVwiLCBhc3luYyAoKSA9PiB7XG4gICAgaC5hY3RpdmVGaWxlID0gXCIvc3JjL2luZGV4LnRzXCI7XG4gICAgY29uc3QgeyByZXJlbmRlciB9ID0gYXdhaXQgcmVuZGVyV2l0aFNyY0V4cGFuZGVkKCk7XG5cbiAgICBjb25zdCByb3dPZiA9IChuYW1lOiBzdHJpbmcpID0+XG4gICAgICBzY3JlZW4uZ2V0QnlUZXh0KG5hbWUpLmNsb3Nlc3QoXCJkaXYudG5vZGVcIikgYXMgSFRNTEVsZW1lbnQ7XG5cbiAgICAvLyBUaGUgYWN0aXZlIGZpbGUncyByb3cgaXMgbWFya2VkIC0tYWN0aXZlIChkaXN0aW5jdCBmcm9tIHNlbGVjdGlvbik7IGEgc2libGluZ1xuICAgIC8vIGZpbGUgaW4gdGhlIHNhbWUgb3BlbiBkaXJlY3RvcnkgaXMgbm90LlxuICAgIGV4cGVjdChyb3dPZihcImluZGV4LnRzXCIpKS50b0hhdmVDbGFzcyhcInRub2RlLS1hY3RpdmVcIik7XG4gICAgZXhwZWN0KHJvd09mKFwiaW5kZXgudHNcIikpLnRvSGF2ZUF0dHJpYnV0ZShcImFyaWEtY3VycmVudFwiLCBcInRydWVcIik7XG4gICAgZXhwZWN0KHJvd09mKFwidXRpbC50c1wiKSkubm90LnRvSGF2ZUNsYXNzKFwidG5vZGUtLWFjdGl2ZVwiKTtcbiAgICAvLyBBY3RpdmUgaGlnaGxpZ2h0IGlzIGluZGVwZW5kZW50IG9mIGV4cGxvcmVyIHNlbGVjdGlvbiDigJQgbm90aGluZyB3YXMgY2xpY2tlZC5cbiAgICBleHBlY3Qoc2NyZWVuLmdldEJ5Um9sZShcInRyZWVpdGVtXCIsIHsgbmFtZTogXCJpbmRleC50c1wiIH0pKS5ub3QudG9IYXZlQXR0cmlidXRlKFxuICAgICAgXCJhcmlhLXNlbGVjdGVkXCIsXG4gICAgICBcInRydWVcIixcbiAgICApO1xuXG4gICAgLy8gVGhlIGhvc3QgbW92ZXMgdGhlIGFjdGl2ZSBmaWxlIOKGkiB0aGUgaGlnaGxpZ2h0IGZvbGxvd3MsIGFuZCBgc3JjYCBzdGF5cyBvcGVuXG4gICAgLy8gKG5vIHJlbW91bnQsIG5vIGNvbGxhcHNlKS5cbiAgICBoLmFjdGl2ZUZpbGUgPSBcIi9zcmMvdXRpbC50c1wiO1xuICAgIHJlcmVuZGVyKDxGaWxlRXhwbG9yZXIgLz4pO1xuXG4gICAgZXhwZWN0KHJvd09mKFwidXRpbC50c1wiKSkudG9IYXZlQ2xhc3MoXCJ0bm9kZS0tYWN0aXZlXCIpO1xuICAgIGV4cGVjdChyb3dPZihcImluZGV4LnRzXCIpKS5ub3QudG9IYXZlQ2xhc3MoXCJ0bm9kZS0tYWN0aXZlXCIpO1xuICAgIGV4cGVjdChzY3JlZW4uZ2V0QnlSb2xlKFwidHJlZWl0ZW1cIiwgeyBuYW1lOiBcInNyY1wiIH0pKS50b0hhdmVBdHRyaWJ1dGUoXG4gICAgICBcImFyaWEtZXhwYW5kZWRcIixcbiAgICAgIFwidHJ1ZVwiLFxuICAgICk7XG4gIH0pO1xuXG4gIGl0KFwiRlgtMTogYSBiZW5pZ24gd29ya3RyZWUgcmUtYW5ub3VuY2UgZG9lcyBub3QgcmVsb2FkIG9yIGNvbGxhcHNlIHRoZSB0cmVlXCIsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCB7IHJlcmVuZGVyIH0gPSBhd2FpdCByZW5kZXJXaXRoU3JjRXhwYW5kZWQoKTtcblxuICAgIC8vIHJlYWRkaXIgd2FzIGNhbGxlZCBvbmNlIGZvciB0aGUgcm9vdCBhbmQgb25jZSBmb3Igc3JjLlxuICAgIGNvbnN0IGNhbGxzQmVmb3JlID0gaC5yZWFkZGlyLm1vY2suY2FsbHMubGVuZ3RoO1xuICAgIGV4cGVjdChjYWxsc0JlZm9yZSkudG9CZSgyKTtcblxuICAgIGgubW91bnRzID0gW3dvcmt0cmVlKCldOyAvLyBuZXcgb2JqZWN0LCBzYW1lIHBhdGhcbiAgICByZXJlbmRlcig8RmlsZUV4cGxvcmVyIC8+KTtcblxuICAgIC8vIE5vIHJlbW91bnQvcmVsb2FkOiByZWFkZGlyIGlzIG5vdCBjYWxsZWQgYWdhaW4sIGFuZCBzcmMgc3RheXMgZXhwYW5kZWQuXG4gICAgZXhwZWN0KGgucmVhZGRpci5tb2NrLmNhbGxzLmxlbmd0aCkudG9CZShjYWxsc0JlZm9yZSk7XG4gICAgZXhwZWN0KHNjcmVlbi5nZXRCeVJvbGUoXCJ0cmVlaXRlbVwiLCB7IG5hbWU6IFwic3JjXCIgfSkpLnRvSGF2ZUF0dHJpYnV0ZShcbiAgICAgIFwiYXJpYS1leHBhbmRlZFwiLFxuICAgICAgXCJ0cnVlXCIsXG4gICAgKTtcbiAgICBleHBlY3Qoc2NyZWVuLmdldEJ5VGV4dChcImluZGV4LnRzXCIpKS50b0JlSW5UaGVEb2N1bWVudCgpO1xuICB9KTtcblxuICBpdChcImNsaWNraW5nIGEgZmlsZSBkb2VzIG5vdCB0cmlnZ2VyIGEgZGlyZWN0b3J5IHJlbG9hZFwiLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgeyB1c2VyIH0gPSBhd2FpdCByZW5kZXJXaXRoU3JjRXhwYW5kZWQoKTtcbiAgICBjb25zdCBjYWxsc0JlZm9yZSA9IGgucmVhZGRpci5tb2NrLmNhbGxzLmxlbmd0aDtcblxuICAgIGF3YWl0IHVzZXIuY2xpY2soc2NyZWVuLmdldEJ5VGV4dChcImluZGV4LnRzXCIpKTtcblxuICAgIGV4cGVjdChoLnJlYWRkaXIubW9jay5jYWxscy5sZW5ndGgpLnRvQmUoY2FsbHNCZWZvcmUpO1xuICB9KTtcbn0pO1xuXG4vLyAtLS0gUjMtNzk6IG11bHRpcGxlIG1vdW50cyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5jb25zdCBzcGFjZSA9ICgpID0+ICh7IHR5cGU6IFwic3BhY2VcIiwgcGF0aDogXCIvc3BhY2VzL3MxXCIsIGlkOiBcInMxXCIsIG5hbWU6IFwiU2hhcmVkIG5vdGVzXCIsIG1vZGU6IFwicm9cIiBhcyBjb25zdCB9KTtcblxuZGVzY3JpYmUoXCJSMy03OSDigJQgbXVsdGlwbGUgbW91bnRzXCIsICgpID0+IHtcbiAgYmVmb3JlRWFjaCgoKSA9PiB7XG4gICAgaC5tb3VudHMgPSBbd29ya3RyZWUoKSwgc3BhY2UoKV07XG4gIH0pO1xuXG4gIGl0KFwicmVuZGVycyBvbmUgc2NvcGUgcGVyIG1vdW50ICh3b3JrdHJlZSArIHNwYWNlKVwiLCBhc3luYyAoKSA9PiB7XG4gICAgcmVuZGVyKDxGaWxlRXhwbG9yZXIgLz4pO1xuICAgIGV4cGVjdChhd2FpdCBzY3JlZW4uZmluZEJ5Um9sZShcInRyZWVcIiwgeyBuYW1lOiBcInJlcG9cIiB9KSkudG9CZUluVGhlRG9jdW1lbnQoKTtcbiAgICBleHBlY3Qoc2NyZWVuLmdldEJ5Um9sZShcInRyZWVcIiwgeyBuYW1lOiBcIlNoYXJlZCBub3Rlc1wiIH0pKS50b0JlSW5UaGVEb2N1bWVudCgpO1xuICB9KTtcblxuICBpdChcImEgcmVhZC1vbmx5IHNwYWNlIG1vdW50IHNob3dzIGEgcmVhZC1vbmx5IGNoaXAgYW5kIG5vIGRlbGV0ZSBhZmZvcmRhbmNlXCIsIGFzeW5jICgpID0+IHtcbiAgICByZW5kZXIoPEZpbGVFeHBsb3JlciAvPik7XG4gICAgY29uc3Qgc3BhY2VUcmVlID0gYXdhaXQgc2NyZWVuLmZpbmRCeVJvbGUoXCJ0cmVlXCIsIHsgbmFtZTogXCJTaGFyZWQgbm90ZXNcIiB9KTtcbiAgICBjb25zdCBzY29wZSA9IHNwYWNlVHJlZS5jbG9zZXN0KFwiLm1vdW50XCIpIGFzIEhUTUxFbGVtZW50O1xuICAgIGV4cGVjdCh3aXRoaW4oc2NvcGUpLmdldEJ5VGV4dCgvcmVhZC1vbmx5LykpLnRvQmVJblRoZURvY3VtZW50KCk7XG4gICAgLy8gVGhlIHNwYWNlIHNjb3BlIHJvb3Qgcm93IGhhcyBubyBkZWxldGUgYnV0dG9uIChyZWFkLW9ubHkpLlxuICAgIGV4cGVjdCh3aXRoaW4oc2NvcGUpLnF1ZXJ5QnlMYWJlbFRleHQoL15EZWxldGUgLykpLm5vdC50b0JlSW5UaGVEb2N1bWVudCgpO1xuICB9KTtcblxuICBpdChcImEgcmV2b2tlZCBtb3VudCdzIHNjb3BlIGRpc2FwcGVhcnMgd2l0aGluIG9uZSByZS1hbm5vdW5jZVwiLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgeyByZXJlbmRlciB9ID0gcmVuZGVyKDxGaWxlRXhwbG9yZXIgLz4pO1xuICAgIGV4cGVjdChhd2FpdCBzY3JlZW4uZmluZEJ5Um9sZShcInRyZWVcIiwgeyBuYW1lOiBcIlNoYXJlZCBub3Rlc1wiIH0pKS50b0JlSW5UaGVEb2N1bWVudCgpO1xuICAgIGgubW91bnRzID0gW3dvcmt0cmVlKCldOyAvLyBzcGFjZSB1bnNoYXJlZFxuICAgIHJlcmVuZGVyKDxGaWxlRXhwbG9yZXIgLz4pO1xuICAgIGV4cGVjdChzY3JlZW4ucXVlcnlCeVJvbGUoXCJ0cmVlXCIsIHsgbmFtZTogXCJTaGFyZWQgbm90ZXNcIiB9KSkubm90LnRvQmVJblRoZURvY3VtZW50KCk7XG4gICAgZXhwZWN0KHNjcmVlbi5nZXRCeVJvbGUoXCJ0cmVlXCIsIHsgbmFtZTogXCJyZXBvXCIgfSkpLnRvQmVJblRoZURvY3VtZW50KCk7XG4gIH0pO1xufSk7XG5cbi8vIC0tLSBSMy05NDogQXBwLXNjb3BlIHBlci1tb3VudCBoZWFkZXIgKFBSSU5DSVBBTFMgwqc5IEIxIC8gRklMRV9FWFBMT1JFUiDCpzIpIC0tLS1cbmRlc2NyaWJlKFwiUjMtOTQg4oCUIGFwcC1zY29wZSBwZXItbW91bnQgaGVhZGVyXCIsICgpID0+IHtcbiAgaXQoXCJsaXN0cyBvbmUgbW9kZSBjaGlwIHBlciBncmFudGVkIHN1YnRyZWUsIGVhY2ggcmVhZC1vbmx5IG9uIGEgbm9uLXdvcmt0cmVlIG1vdW50XCIsIGFzeW5jICgpID0+IHtcbiAgICBoLm1vdW50cyA9IFtcbiAgICAgIHtcbiAgICAgICAgdHlwZTogXCJmaXJlc3RvcmVcIixcbiAgICAgICAgcGF0aDogXCIvc3BhY2VzL3MxXCIsXG4gICAgICAgIGlkOiBcInNwYWNlOnMxXCIsXG4gICAgICAgIG5hbWU6IFwiU2hhcmVkIG5vdGVzXCIsXG4gICAgICAgIG1vZGU6IFwicm9cIixcbiAgICAgICAgcnVsZXM6IFtcbiAgICAgICAgICB7IHN1YnRyZWU6IFwiL25vdGVzXCIsIG1vZGU6IFwicndcIiB9LFxuICAgICAgICAgIHsgc3VidHJlZTogXCIvZHJhZnRzXCIsIG1vZGU6IFwicm9cIiB9LFxuICAgICAgICBdLFxuICAgICAgfSBhcyBuZXZlcixcbiAgICBdO1xuICAgIHJlbmRlcig8RmlsZUV4cGxvcmVyIC8+KTtcbiAgICBjb25zdCBzY29wZSA9IChhd2FpdCBzY3JlZW4uZmluZEJ5Um9sZShcInRyZWVcIiwgeyBuYW1lOiBcIlNoYXJlZCBub3Rlc1wiIH0pKS5jbG9zZXN0KFxuICAgICAgXCIubW91bnRcIixcbiAgICApIGFzIEhUTUxFbGVtZW50O1xuICAgIGNvbnN0IGNoaXBzID0gd2l0aGluKHNjb3BlKS5nZXRBbGxCeVRleHQoL3JlYWQtb25seXxyZWFkLXdyaXRlLyk7XG4gICAgLy8gT25lIGNoaXAgcGVyIHN1YnRyZWUsIGFuZCBhIGdyYW50ZWQgYHJ3YCBzdWJ0cmVlIGlzIHN0aWxsIHNob3duIHJlYWQtb25seSAodjE6XG4gICAgLy8gb25seSB0aGUgd29ya3RyZWUgaXMgd3JpdGFibGUg4oCUIG5ldmVyIHNob3duLXRoZW4tRVJPRlMpLlxuICAgIC8vIE9yZGVyZWQgcm9vdC1maXJzdCB0aGVuIEHihpJaIChoZXJlOiAvZHJhZnRzIGJlZm9yZSAvbm90ZXMpLlxuICAgIGV4cGVjdChjaGlwcy5tYXAoKGMpID0+IGMudGV4dENvbnRlbnQpKS50b0VxdWFsKFtcbiAgICAgIGV4cGVjdC5zdHJpbmdDb250YWluaW5nKFwiL2RyYWZ0cyDCtyByZWFkLW9ubHlcIiksXG4gICAgICBleHBlY3Quc3RyaW5nQ29udGFpbmluZyhcIi9ub3RlcyDCtyByZWFkLW9ubHlcIiksXG4gICAgXSk7XG4gIH0pO1xuXG4gIGl0KFwidGhlIHdvcmt0cmVlIGhlYWRlciBzaG93cyBhIHNpbmdsZSByZWFkLXdyaXRlIHdob2xlLW1vdW50IGNoaXBcIiwgYXN5bmMgKCkgPT4ge1xuICAgIGgubW91bnRzID0gW3dvcmt0cmVlKCldO1xuICAgIHJlbmRlcig8RmlsZUV4cGxvcmVyIC8+KTtcbiAgICBjb25zdCBzY29wZSA9IChhd2FpdCBzY3JlZW4uZmluZEJ5Um9sZShcInRyZWVcIiwgeyBuYW1lOiBcInJlcG9cIiB9KSkuY2xvc2VzdChcbiAgICAgIFwiLm1vdW50XCIsXG4gICAgKSBhcyBIVE1MRWxlbWVudDtcbiAgICBjb25zdCBjaGlwcyA9IHdpdGhpbihzY29wZSkuZ2V0QWxsQnlUZXh0KC9yZWFkLW9ubHl8cmVhZC13cml0ZS8pO1xuICAgIGV4cGVjdChjaGlwcykudG9IYXZlTGVuZ3RoKDEpO1xuICAgIGV4cGVjdChjaGlwc1swXS50ZXh0Q29udGVudCkudG9Db250YWluKFwiLyDCtyByZWFkLXdyaXRlXCIpO1xuICB9KTtcbn0pO1xuXG4vLyAtLS0gUjMtODA6IGNvbnRleHQgbWVudSAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5kZXNjcmliZShcIlIzLTgwIOKAlCBjb250ZXh0IG1lbnVcIiwgKCkgPT4ge1xuICBpdChcInJpZ2h0LWNsaWNraW5nIGEgd29ya3RyZWUgZmlsZSBvcGVucyBhIG1lbnUgd2l0aCBPcGVuICsgd3JpdGUgYWN0aW9uc1wiLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgeyB1c2VyIH0gPSBhd2FpdCByZW5kZXJXaXRoU3JjRXhwYW5kZWQoKTtcbiAgICBmaXJlRXZlbnQuY29udGV4dE1lbnUoc2NyZWVuLmdldEJ5VGV4dChcImluZGV4LnRzXCIpKTtcbiAgICBjb25zdCBtZW51ID0gYXdhaXQgc2NyZWVuLmZpbmRCeVJvbGUoXCJtZW51XCIpO1xuICAgIGZvciAoY29uc3QgbGFiZWwgb2YgW1wiT3BlblwiLCBcIk5ldyBmaWxlIGhlcmVcIiwgXCJOZXcgZm9sZGVyIGhlcmVcIiwgXCJSZW5hbWXigKZcIiwgXCJEZWxldGVcIl0pIHtcbiAgICAgIGV4cGVjdCh3aXRoaW4obWVudSkuZ2V0QnlSb2xlKFwibWVudWl0ZW1cIiwgeyBuYW1lOiBuZXcgUmVnRXhwKGxhYmVsKSB9KSkudG9CZUluVGhlRG9jdW1lbnQoKTtcbiAgICB9XG4gICAgLy8gRGVsZXRlIGZyb20gdGhlIG1lbnUgY29uZmlybXMgdGhlbiBjYWxscyBkZWxldGVFbnRyeSB3aXRoIHRoZSBtb3VudC1yZWwgcGF0aC5cbiAgICBjb25zdCBjb25maXJtID0gdmkuc3B5T24od2luZG93LCBcImNvbmZpcm1cIikubW9ja1JldHVyblZhbHVlKHRydWUpO1xuICAgIGF3YWl0IHVzZXIuY2xpY2sod2l0aGluKG1lbnUpLmdldEJ5Um9sZShcIm1lbnVpdGVtXCIsIHsgbmFtZTogL0RlbGV0ZS8gfSkpO1xuICAgIGV4cGVjdChoLmRlbGV0ZUVudHJ5KS50b0hhdmVCZWVuQ2FsbGVkV2l0aChcIi9zcmMvaW5kZXgudHNcIik7XG4gICAgY29uZmlybS5tb2NrUmVzdG9yZSgpO1xuICB9KTtcblxuICAvLyBUaGUgY29uZmlybSBpcyB0aGUgb25seSB0aGluZyBiZXR3ZWVuIGEgY2xpY2sgYW5kIGEgbG9zdCBmaWxlLCBhbmQgdGhlIHJvdydzXG4gIC8vIGRpc2FwcGVhcmFuY2UgaXMgdGhlIHVzZXIncyBldmlkZW5jZSB0aGUgZGVsZXRlIGhhcHBlbmVkLiBDYW5jZWxsaW5nIG11c3RcbiAgLy8gdGhlcmVmb3JlIGNoYW5nZSBub3RoaW5nIGF0IGFsbCDigJQgbm8gaW50ZW50LCBhbmQgdGhlIHJvdyBzdGlsbCB0aGVyZS4gQXNzZXJ0ZWRcbiAgLy8gYmVjYXVzZSBpdCB3YXMgcmVhY2hlZCBmb3IgYnkgaGFuZCAoMjAyNi0wOS0xMykgYW5kIGhhZCBubyBndWFyZC5cbiAgaXQoXCJjYW5jZWxsaW5nIHRoZSBkZWxldGUgY29uZmlybSByZW1vdmVzIG5vdGhpbmcgYW5kIGxlYXZlcyB0aGUgcm93IGluIHBsYWNlXCIsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCB1c2VyID0gdXNlckV2ZW50LnNldHVwKCk7XG4gICAgYXdhaXQgcmVuZGVyV2l0aFNyY0V4cGFuZGVkKCk7XG4gICAgY29uc3QgY29uZmlybSA9IHZpLnNweU9uKHdpbmRvdywgXCJjb25maXJtXCIpLm1vY2tSZXR1cm5WYWx1ZShmYWxzZSk7XG4gICAgZmlyZUV2ZW50LmNvbnRleHRNZW51KHNjcmVlbi5nZXRCeVRleHQoXCJpbmRleC50c1wiKSk7XG4gICAgY29uc3QgbWVudSA9IGF3YWl0IHNjcmVlbi5maW5kQnlSb2xlKFwibWVudVwiKTtcbiAgICBhd2FpdCB1c2VyLmNsaWNrKHdpdGhpbihtZW51KS5nZXRCeVJvbGUoXCJtZW51aXRlbVwiLCB7IG5hbWU6IC9eRGVsZXRlLyB9KSk7XG4gICAgZXhwZWN0KGguZGVsZXRlRW50cnkpLm5vdC50b0hhdmVCZWVuQ2FsbGVkKCk7XG4gICAgZXhwZWN0KHNjcmVlbi5nZXRCeVJvbGUoXCJ0cmVlaXRlbVwiLCB7IG5hbWU6IFwiaW5kZXgudHNcIiB9KSkudG9CZUluVGhlRG9jdW1lbnQoKTtcbiAgICBjb25maXJtLm1vY2tSZXN0b3JlKCk7XG4gIH0pO1xuXG4gIGl0KFwiYSByZWFkLW9ubHkgc3BhY2UgZmlsZSdzIG1lbnUgb2ZmZXJzIG9ubHkgT3BlbiAobm8gd3JpdGUgYWN0aW9ucylcIiwgYXN5bmMgKCkgPT4ge1xuICAgIGgubW91bnRzID0gW3NwYWNlKCldO1xuICAgIHJlbmRlcig8RmlsZUV4cGxvcmVyIC8+KTtcbiAgICAvLyBUaGUgc3BhY2Ugcm9vdCBpcyBvcGVuIGJ5IGRlZmF1bHQg4oaSIGl0cyBmaWxlIGFwcGVhcnMgb25jZSByZWFkZGlyIHJlc29sdmVzLlxuICAgIGZpcmVFdmVudC5jb250ZXh0TWVudShhd2FpdCBzY3JlZW4uZmluZEJ5VGV4dChcIm5vdGUubWRcIikpO1xuICAgIGNvbnN0IG1lbnUgPSBhd2FpdCBzY3JlZW4uZmluZEJ5Um9sZShcIm1lbnVcIik7XG4gICAgZXhwZWN0KHdpdGhpbihtZW51KS5nZXRCeVJvbGUoXCJtZW51aXRlbVwiLCB7IG5hbWU6IC9PcGVuLyB9KSkudG9CZUluVGhlRG9jdW1lbnQoKTtcbiAgICBleHBlY3Qod2l0aGluKG1lbnUpLnF1ZXJ5QnlSb2xlKFwibWVudWl0ZW1cIiwgeyBuYW1lOiAvTmV3IGZpbGUgaGVyZS8gfSkpLm5vdC50b0JlSW5UaGVEb2N1bWVudCgpO1xuICAgIGV4cGVjdCh3aXRoaW4obWVudSkucXVlcnlCeVJvbGUoXCJtZW51aXRlbVwiLCB7IG5hbWU6IC9EZWxldGUvIH0pKS5ub3QudG9CZUluVGhlRG9jdW1lbnQoKTtcbiAgfSk7XG59KTtcblxuLy8gLS0tIFIzLTI2OSBENC9ENS9ENiDigJQgdGhlIGV4cGxvcmVyIGFzIHRoZSBzcGFjZXMgZW50cnkgcG9pbnQgLS0tLS0tLS0tLS0tLS0tLVxuZGVzY3JpYmUoXCJSMy0yNjkg4oCUIGFkZC1hLXNwYWNlICsgbWFuYWdlLXNoYXJpbmcgZW50cnkgcG9pbnRzXCIsICgpID0+IHtcbiAgaXQoXCJ0aGUgaGVhZGVyJ3MgJ0FkZCBhIHNwYWNl4oCmJyBhc2tzIHRoZSBIT1NUIHBvd2VyYm94IChyZXF1ZXN0TW91bnQpXCIsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCB1c2VyID0gdXNlckV2ZW50LnNldHVwKCk7XG4gICAgcmVuZGVyKDxGaWxlRXhwbG9yZXIgLz4pO1xuICAgIGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KFwic3JjXCIpO1xuICAgIGF3YWl0IHVzZXIuY2xpY2soc2NyZWVuLmdldEJ5Um9sZShcImJ1dHRvblwiLCB7IG5hbWU6IFwiQWRkIGEgc3BhY2XigKZcIiB9KSk7XG4gICAgZXhwZWN0KGgucmVxdWVzdE1vdW50KS50b0hhdmVCZWVuQ2FsbGVkVGltZXMoMSk7XG4gIH0pO1xuXG4gIGl0KFwidGhlIGVtcHR5IHN0YXRlIGNhcnJpZXMgdGhlIGZpcnN0LXRpbWVyIHNlbnRlbmNlICsgYW4gQWRkLWEtc3BhY2UgYWN0aW9uXCIsIGFzeW5jICgpID0+IHtcbiAgICBoLm1vdW50cyA9IFtdO1xuICAgIGNvbnN0IHVzZXIgPSB1c2VyRXZlbnQuc2V0dXAoKTtcbiAgICByZW5kZXIoPEZpbGVFeHBsb3JlciAvPik7XG4gICAgLy8gRDYgY29weSwgUi1TUEFDRVMtMSB2b2NhYnVsYXJ5IChzcGFjZS9mb2xkZXIg4oCUIG5ldmVyIG1vdW50L2ZpbGVzeXN0ZW0pLlxuICAgIGNvbnN0IGNvcHkgPSBhd2FpdCBzY3JlZW4uZmluZEJ5VGV4dCgvQSBzcGFjZSBpcyBhIGZvbGRlciB0aGF0IGxpdmVzIGluIHlvdXIgYWNjb3VudC8pO1xuICAgIGNvbnN0IHN0YXRlID0gY29weS5jbG9zZXN0KFwiLnN0YXRlXCIpIGFzIEhUTUxFbGVtZW50O1xuICAgIGF3YWl0IHVzZXIuY2xpY2sod2l0aGluKHN0YXRlKS5nZXRCeVJvbGUoXCJidXR0b25cIiwgeyBuYW1lOiAvQWRkIGEgc3BhY2XigKYvIH0pKTtcbiAgICBleHBlY3QoaC5yZXF1ZXN0TW91bnQpLnRvSGF2ZUJlZW5DYWxsZWQoKTtcbiAgfSk7XG5cbiAgaXQoXCJhIHNwYWNlIFJPT1Qgcm93J3MgbWVudSBvZmZlcnMgJ01hbmFnZSBzaGFyaW5nIOKGkicgb3BlbmluZyAvc3BhY2VzIGF0IHRoYXQgc3BhY2VcIiwgYXN5bmMgKCkgPT4ge1xuICAgIC8vIGdldEhvc3RPcmlnaW4oKSByZWFkcyB0aGUgaWZyYW1lJ3MgYD9ocmVmPWAgYm9vdCBwYXJhbSDigJQgc2ltdWxhdGUgdGhlIHNhbmRib3ggVVJMLlxuICAgIHdpbmRvdy5oaXN0b3J5LnJlcGxhY2VTdGF0ZShcbiAgICAgIHt9LFxuICAgICAgXCJcIixcbiAgICAgIFwiLz9ocmVmPVwiICsgZW5jb2RlVVJJQ29tcG9uZW50KFwiaHR0cHM6Ly9pbW1lZGlhdGVseS5ydW4vZWRpdC9naXRodWIvYS9iL21haW4vXCIpLFxuICAgICk7XG4gICAgY29uc3Qgb3BlbiA9IHZpLnNweU9uKHdpbmRvdywgXCJvcGVuXCIpLm1vY2tSZXR1cm5WYWx1ZShudWxsKTtcbiAgICB0cnkge1xuICAgICAgaC5tb3VudHMgPSBbeyB0eXBlOiBcInNwYWNlXCIsIHBhdGg6IFwiL3NwYWNlcy9zMVwiLCBpZDogXCJzcGFjZTpzMVwiLCBuYW1lOiBcIlNoYXJlZCBub3Rlc1wiIH1dO1xuICAgICAgY29uc3QgdXNlciA9IHVzZXJFdmVudC5zZXR1cCgpO1xuICAgICAgcmVuZGVyKDxGaWxlRXhwbG9yZXIgLz4pO1xuICAgICAgLy8gVGhlIGxhYmVsIGFwcGVhcnMgaW4gdGhlIHNjb3BlIGhlYWRlciBBTkQgYXMgdGhlIHRyZWUncyByb290IHJvdyDigJQgdGhlIHJvd1xuICAgICAgLy8gKGluc2lkZSByb2xlPXRyZWUpIGlzIHRoZSBvbmUgY2FycnlpbmcgdGhlIGNvbnRleHQgbWVudS5cbiAgICAgIGNvbnN0IHRyZWUgPSBhd2FpdCBzY3JlZW4uZmluZEJ5Um9sZShcInRyZWVcIiwgeyBuYW1lOiBcIlNoYXJlZCBub3Rlc1wiIH0pO1xuICAgICAgZmlyZUV2ZW50LmNvbnRleHRNZW51KHdpdGhpbih0cmVlKS5nZXRCeVRleHQoXCJTaGFyZWQgbm90ZXNcIikpO1xuICAgICAgY29uc3QgbWVudSA9IGF3YWl0IHNjcmVlbi5maW5kQnlSb2xlKFwibWVudVwiKTtcbiAgICAgIGF3YWl0IHVzZXIuY2xpY2sod2l0aGluKG1lbnUpLmdldEJ5Um9sZShcIm1lbnVpdGVtXCIsIHsgbmFtZTogL01hbmFnZSBzaGFyaW5nLyB9KSk7XG4gICAgICBleHBlY3Qob3BlbikudG9IYXZlQmVlbkNhbGxlZFdpdGgoXG4gICAgICAgIFwiaHR0cHM6Ly9pbW1lZGlhdGVseS5ydW4vc3BhY2VzP3NwYWNlPXMxXCIsXG4gICAgICAgIFwiX2JsYW5rXCIsXG4gICAgICAgIFwibm9vcGVuZXIsbm9yZWZlcnJlclwiLFxuICAgICAgKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgb3Blbi5tb2NrUmVzdG9yZSgpO1xuICAgICAgd2luZG93Lmhpc3RvcnkucmVwbGFjZVN0YXRlKHt9LCBcIlwiLCBcIi9cIik7XG4gICAgfVxuICB9KTtcblxuICBpdChcImEgbm9uLXJvb3Qgcm93IGluc2lkZSBhIHNwYWNlIGRvZXMgTk9UIG9mZmVyICdNYW5hZ2Ugc2hhcmluZyDihpInXCIsIGFzeW5jICgpID0+IHtcbiAgICB3aW5kb3cuaGlzdG9yeS5yZXBsYWNlU3RhdGUoXG4gICAgICB7fSxcbiAgICAgIFwiXCIsXG4gICAgICBcIi8/aHJlZj1cIiArIGVuY29kZVVSSUNvbXBvbmVudChcImh0dHBzOi8vaW1tZWRpYXRlbHkucnVuL2VkaXQvZ2l0aHViL2EvYi9tYWluL1wiKSxcbiAgICApO1xuICAgIHRyeSB7XG4gICAgICBoLm1vdW50cyA9IFt7IHR5cGU6IFwic3BhY2VcIiwgcGF0aDogXCIvc3BhY2VzL3MxXCIsIGlkOiBcInNwYWNlOnMxXCIsIG5hbWU6IFwiU2hhcmVkIG5vdGVzXCIgfV07XG4gICAgICByZW5kZXIoPEZpbGVFeHBsb3JlciAvPik7XG4gICAgICBmaXJlRXZlbnQuY29udGV4dE1lbnUoYXdhaXQgc2NyZWVuLmZpbmRCeVRleHQoXCJub3RlLm1kXCIpKTtcbiAgICAgIGNvbnN0IG1lbnUgPSBhd2FpdCBzY3JlZW4uZmluZEJ5Um9sZShcIm1lbnVcIik7XG4gICAgICBleHBlY3QoXG4gICAgICAgIHdpdGhpbihtZW51KS5xdWVyeUJ5Um9sZShcIm1lbnVpdGVtXCIsIHsgbmFtZTogL01hbmFnZSBzaGFyaW5nLyB9KSxcbiAgICAgICkubm90LnRvQmVJblRoZURvY3VtZW50KCk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHdpbmRvdy5oaXN0b3J5LnJlcGxhY2VTdGF0ZSh7fSwgXCJcIiwgXCIvXCIpO1xuICAgIH1cbiAgfSk7XG59KTtcblxuLy8gLS0tIGhlbHBlcnMgZm9yIHN5bnRoZXRpYyBkcmFnIGV2ZW50cyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuZnVuY3Rpb24gZGF0YVRyYW5zZmVyKG9wdHM6IHsgbW92ZT86IHN0cmluZzsgZmlsZXM/OiBGaWxlW10gfSkge1xuICBjb25zdCB0eXBlczogc3RyaW5nW10gPSBbXTtcbiAgaWYgKG9wdHMubW92ZSkgdHlwZXMucHVzaChcImFwcGxpY2F0aW9uL3gtaXItZmlsZS1tb3ZlXCIpO1xuICBpZiAob3B0cy5maWxlcz8ubGVuZ3RoKSB0eXBlcy5wdXNoKFwiRmlsZXNcIik7XG4gIHJldHVybiB7XG4gICAgdHlwZXMsXG4gICAgZmlsZXM6IG9wdHMuZmlsZXMgPz8gW10sXG4gICAgZ2V0RGF0YTogKHQ6IHN0cmluZykgPT4gKHQgPT09IFwiYXBwbGljYXRpb24veC1pci1maWxlLW1vdmVcIiA/IChvcHRzLm1vdmUgPz8gXCJcIikgOiBcIlwiKSxcbiAgICBzZXREYXRhOiAoKSA9PiB7fSxcbiAgICBkcm9wRWZmZWN0OiBcIlwiLFxuICAgIGVmZmVjdEFsbG93ZWQ6IFwiXCIsXG4gIH07XG59XG5cbi8vIC0tLSBSMy04MTogZHJhZyB0byBtb3ZlIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbmRlc2NyaWJlKFwiUjMtODEg4oCUIGRyYWcgdG8gbW92ZSB3aXRoaW4gYSBmaWxlc3lzdGVtXCIsICgpID0+IHtcbiAgaXQoXCJkcm9wcGluZyBhIGZpbGUgb250byBhIHNpYmxpbmcgZGlyZWN0b3J5IGNhbGxzIHJlbmFtZUVudHJ5XCIsIGFzeW5jICgpID0+IHtcbiAgICBhd2FpdCByZW5kZXJXaXRoU3JjRXhwYW5kZWQoKTtcbiAgICBjb25zdCBzcmNSb3cgPSBzY3JlZW4uZ2V0QnlUZXh0KFwic3JjXCIpLmNsb3Nlc3QoXCIudG5vZGVcIikgYXMgSFRNTEVsZW1lbnQ7XG4gICAgZmlyZUV2ZW50LmRyb3Aoc3JjUm93LCB7XG4gICAgICBkYXRhVHJhbnNmZXI6IGRhdGFUcmFuc2Zlcih7IG1vdmU6IEpTT04uc3RyaW5naWZ5KHsgZnJvbTogXCIvbW50L2FiYy9SRUFETUUubWRcIiwgcm9vdFBhdGg6IFwiL21udC9hYmNcIiB9KSB9KSxcbiAgICB9KTtcbiAgICBleHBlY3QoaC5yZW5hbWVFbnRyeSkudG9IYXZlQmVlbkNhbGxlZFdpdGgoXCIvUkVBRE1FLm1kXCIsIFwiL3NyYy9SRUFETUUubWRcIik7XG4gIH0pO1xuXG4gIGl0KFwiYSBjcm9zcy1tb3VudCBkcm9wIGlzIHJlamVjdGVkIChubyByZW5hbWUpXCIsIGFzeW5jICgpID0+IHtcbiAgICBhd2FpdCByZW5kZXJXaXRoU3JjRXhwYW5kZWQoKTtcbiAgICBjb25zdCBzcmNSb3cgPSBzY3JlZW4uZ2V0QnlUZXh0KFwic3JjXCIpLmNsb3Nlc3QoXCIudG5vZGVcIikgYXMgSFRNTEVsZW1lbnQ7XG4gICAgZmlyZUV2ZW50LmRyb3Aoc3JjUm93LCB7XG4gICAgICBkYXRhVHJhbnNmZXI6IGRhdGFUcmFuc2Zlcih7IG1vdmU6IEpTT04uc3RyaW5naWZ5KHsgZnJvbTogXCIvc3BhY2VzL3MxL3gubWRcIiwgcm9vdFBhdGg6IFwiL3NwYWNlcy9zMVwiIH0pIH0pLFxuICAgIH0pO1xuICAgIGV4cGVjdChoLnJlbmFtZUVudHJ5KS5ub3QudG9IYXZlQmVlbkNhbGxlZCgpO1xuICAgIGV4cGVjdChhd2FpdCBzY3JlZW4uZmluZEJ5Um9sZShcImFsZXJ0XCIpKS50b0hhdmVUZXh0Q29udGVudCgvc3BhY2VzLyk7XG4gIH0pO1xufSk7XG5cbi8vIC0tLSBSMy04MjogZHJhZyB0byB1cGxvYWQgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbmRlc2NyaWJlKFwiUjMtODIg4oCUIGRyYWcgbG9jYWwgZmlsZXMgdG8gdXBsb2FkIGludG8gYSBkaXJlY3RvcnlcIiwgKCkgPT4ge1xuICBpdChcImRyb3BwaW5nIGFuIE9TIGZpbGUgb250byBhIGRpcmVjdG9yeSB1cGxvYWRzIGl0IGludG8gdGhhdCBkaXJlY3RvcnlcIiwgYXN5bmMgKCkgPT4ge1xuICAgIGF3YWl0IHJlbmRlcldpdGhTcmNFeHBhbmRlZCgpO1xuICAgIGNvbnN0IHNyY1JvdyA9IHNjcmVlbi5nZXRCeVRleHQoXCJzcmNcIikuY2xvc2VzdChcIi50bm9kZVwiKSBhcyBIVE1MRWxlbWVudDtcbiAgICBjb25zdCBmaWxlID0gbmV3IEZpbGUoW1wiaGVsbG9cIl0sIFwibm90ZS50eHRcIiwgeyB0eXBlOiBcInRleHQvcGxhaW5cIiB9KTtcbiAgICBmaXJlRXZlbnQuZHJvcChzcmNSb3csIHsgZGF0YVRyYW5zZmVyOiBkYXRhVHJhbnNmZXIoeyBmaWxlczogW2ZpbGVdIH0pIH0pO1xuICAgIGF3YWl0IHZpLndhaXRGb3IoKCkgPT4gZXhwZWN0KGgudXBsb2FkRmlsZSkudG9IYXZlQmVlbkNhbGxlZCgpKTtcbiAgICBleHBlY3QoaC51cGxvYWRGaWxlLm1vY2suY2FsbHNbMF1bMF0pLnRvQmUoXCIvc3JjL25vdGUudHh0XCIpO1xuICB9KTtcblxuICAvLyDCpzU6IFwib3IgdGhlIHNjb3BlIHJvb3QgaWYgZHJvcHBlZCBvbiBlbXB0eSBzcGFjZSB3aXRoaW4gYSBzY29wZVwiLiBUaGVzZSB0d29cbiAgLy8gZHJvcHMgd2VyZSBzaWxlbnQgbm8tb3BzIOKAlCB0aGUgd2hvbGUgb2YgdGhlIHBhbmVsIGV4Y2VwdCBhIGRpcmVjdG9yeSByb3cgd2FzXG4gIC8vIGRlYWQgdG8gYW4gT1MgZHJhZy5cbiAgaXQoXCJkcm9wcGluZyBvbiB0aGUgc2NvcGUncyBibGFuayBzcGFjZSB1cGxvYWRzIGludG8gdGhlIHNjb3BlIHJvb3RcIiwgYXN5bmMgKCkgPT4ge1xuICAgIGF3YWl0IHJlbmRlcldpdGhTcmNFeHBhbmRlZCgpO1xuICAgIGNvbnN0IHNjb3BlID0gc2NyZWVuLmdldEJ5VGV4dChcInNyY1wiKS5jbG9zZXN0KFwiLm1vdW50XCIpIGFzIEhUTUxFbGVtZW50O1xuICAgIGNvbnN0IGZpbGUgPSBuZXcgRmlsZShbXCJoZWxsb1wiXSwgXCJub3RlLnR4dFwiLCB7IHR5cGU6IFwidGV4dC9wbGFpblwiIH0pO1xuICAgIGZpcmVFdmVudC5kcm9wKHNjb3BlLCB7IGRhdGFUcmFuc2ZlcjogZGF0YVRyYW5zZmVyKHsgZmlsZXM6IFtmaWxlXSB9KSB9KTtcbiAgICBhd2FpdCB2aS53YWl0Rm9yKCgpID0+IGV4cGVjdChoLnVwbG9hZEZpbGUpLnRvSGF2ZUJlZW5DYWxsZWQoKSk7XG4gICAgZXhwZWN0KGgudXBsb2FkRmlsZS5tb2NrLmNhbGxzWzBdWzBdKS50b0JlKFwiL25vdGUudHh0XCIpO1xuICB9KTtcblxuICBpdChcImRyb3BwaW5nIG9udG8gYSBmaWxlIHJvdyB1cGxvYWRzIGludG8gdGhhdCBmaWxlJ3MgZGlyZWN0b3J5XCIsIGFzeW5jICgpID0+IHtcbiAgICBhd2FpdCByZW5kZXJXaXRoU3JjRXhwYW5kZWQoKTtcbiAgICBjb25zdCBmaWxlUm93ID0gc2NyZWVuLmdldEJ5VGV4dChcImluZGV4LnRzXCIpLmNsb3Nlc3QoXCIudG5vZGVcIikgYXMgSFRNTEVsZW1lbnQ7XG4gICAgY29uc3QgZmlsZSA9IG5ldyBGaWxlKFtcImhlbGxvXCJdLCBcIm5vdGUudHh0XCIsIHsgdHlwZTogXCJ0ZXh0L3BsYWluXCIgfSk7XG4gICAgZmlyZUV2ZW50LmRyb3AoZmlsZVJvdywgeyBkYXRhVHJhbnNmZXI6IGRhdGFUcmFuc2Zlcih7IGZpbGVzOiBbZmlsZV0gfSkgfSk7XG4gICAgYXdhaXQgdmkud2FpdEZvcigoKSA9PiBleHBlY3QoaC51cGxvYWRGaWxlKS50b0hhdmVCZWVuQ2FsbGVkKCkpO1xuICAgIGV4cGVjdChoLnVwbG9hZEZpbGUubW9jay5jYWxsc1swXVswXSkudG9CZShcIi9zcmMvbm90ZS50eHRcIik7XG4gIH0pO1xuXG4gIGl0KFwiYSBkaXJlY3Rvcnkgcm93J3MgZHJvcCBpcyBub3QgYWxzbyBoYW5kbGVkIGJ5IHRoZSBzY29wZVwiLCBhc3luYyAoKSA9PiB7XG4gICAgYXdhaXQgcmVuZGVyV2l0aFNyY0V4cGFuZGVkKCk7XG4gICAgY29uc3Qgc3JjUm93ID0gc2NyZWVuLmdldEJ5VGV4dChcInNyY1wiKS5jbG9zZXN0KFwiLnRub2RlXCIpIGFzIEhUTUxFbGVtZW50O1xuICAgIGNvbnN0IGZpbGUgPSBuZXcgRmlsZShbXCJoZWxsb1wiXSwgXCJub3RlLnR4dFwiLCB7IHR5cGU6IFwidGV4dC9wbGFpblwiIH0pO1xuICAgIGZpcmVFdmVudC5kcm9wKHNyY1JvdywgeyBkYXRhVHJhbnNmZXI6IGRhdGFUcmFuc2Zlcih7IGZpbGVzOiBbZmlsZV0gfSkgfSk7XG4gICAgYXdhaXQgdmkud2FpdEZvcigoKSA9PiBleHBlY3QoaC51cGxvYWRGaWxlKS50b0hhdmVCZWVuQ2FsbGVkKCkpO1xuICAgIGV4cGVjdChoLnVwbG9hZEZpbGUpLnRvSGF2ZUJlZW5DYWxsZWRUaW1lcygxKTtcbiAgfSk7XG5cbiAgaXQoXCJ0aGUgc2NvcGUgbGlnaHRzIGl0cyBkcm9wIGFmZm9yZGFuY2Ugd2hpbGUgT1MgZmlsZXMgYXJlIGRyYWdnZWQgb3ZlciBpdFwiLCBhc3luYyAoKSA9PiB7XG4gICAgYXdhaXQgcmVuZGVyV2l0aFNyY0V4cGFuZGVkKCk7XG4gICAgY29uc3Qgc2NvcGUgPSBzY3JlZW4uZ2V0QnlUZXh0KFwic3JjXCIpLmNsb3Nlc3QoXCIubW91bnRcIikgYXMgSFRNTEVsZW1lbnQ7XG4gICAgZXhwZWN0KHNjb3BlLmdldEF0dHJpYnV0ZShcImRhdGEtZHJhZ1wiKSkudG9CZShudWxsKTtcbiAgICBmaXJlRXZlbnQuZHJhZ092ZXIoc2NvcGUsIHsgZGF0YVRyYW5zZmVyOiBkYXRhVHJhbnNmZXIoeyBmaWxlczogW25ldyBGaWxlKFtcInhcIl0sIFwieC50eHRcIildIH0pIH0pO1xuICAgIGV4cGVjdChzY29wZS5nZXRBdHRyaWJ1dGUoXCJkYXRhLWRyYWdcIikpLnRvQmUoXCIxXCIpO1xuICAgIGZpcmVFdmVudC5kcmFnTGVhdmUoc2NvcGUsIHsgcmVsYXRlZFRhcmdldDogZG9jdW1lbnQuYm9keSB9KTtcbiAgICBleHBlY3Qoc2NvcGUuZ2V0QXR0cmlidXRlKFwiZGF0YS1kcmFnXCIpKS50b0JlKG51bGwpO1xuICB9KTtcblxuICBpdChcImFuIGludGVybmFsIG1vdmUgZHJhZ2dlZCBvdmVyIGJsYW5rIHNwYWNlIGlzIG5vdCB0YWtlbiBieSB0aGUgc2NvcGVcIiwgYXN5bmMgKCkgPT4ge1xuICAgIGF3YWl0IHJlbmRlcldpdGhTcmNFeHBhbmRlZCgpO1xuICAgIGNvbnN0IHNjb3BlID0gc2NyZWVuLmdldEJ5VGV4dChcInNyY1wiKS5jbG9zZXN0KFwiLm1vdW50XCIpIGFzIEhUTUxFbGVtZW50O1xuICAgIGZpcmVFdmVudC5kcmFnT3ZlcihzY29wZSwge1xuICAgICAgZGF0YVRyYW5zZmVyOiBkYXRhVHJhbnNmZXIoeyBtb3ZlOiBKU09OLnN0cmluZ2lmeSh7IGZyb206IFwiL1JFQURNRS5tZFwiLCByb290UGF0aDogXCIvbW50L2FiY1wiIH0pIH0pLFxuICAgIH0pO1xuICAgIGV4cGVjdChzY29wZS5nZXRBdHRyaWJ1dGUoXCJkYXRhLWRyYWdcIikpLnRvQmUobnVsbCk7XG4gICAgZmlyZUV2ZW50LmRyb3Aoc2NvcGUsIHtcbiAgICAgIGRhdGFUcmFuc2ZlcjogZGF0YVRyYW5zZmVyKHsgbW92ZTogSlNPTi5zdHJpbmdpZnkoeyBmcm9tOiBcIi9SRUFETUUubWRcIiwgcm9vdFBhdGg6IFwiL21udC9hYmNcIiB9KSB9KSxcbiAgICB9KTtcbiAgICBleHBlY3QoaC5yZW5hbWVFbnRyeSkubm90LnRvSGF2ZUJlZW5DYWxsZWQoKTtcbiAgICBleHBlY3QoaC51cGxvYWRGaWxlKS5ub3QudG9IYXZlQmVlbkNhbGxlZCgpO1xuICB9KTtcblxuICAvLyDCpzUgdXBsb2FkIEJVVFRPTjogdGhlIG5hdGl2ZSBmaWxlLXBpY2tlciBwYXRoICh0aGUgZGlzY292ZXJhYmxlL21vYmlsZVxuICAvLyBhbHRlcm5hdGl2ZSB0byBhIGRyYWcpLCByb3V0aW5nIHRocm91Z2ggdGhlIHNhbWUgYHVwbG9hZEZpbGVgIGludGVudCB3aXRoXG4gIC8vIHRoZSBzZWxlY3RlZCBmaWxlJ3MgZm9sZGVyIGFzIHRoZSBkZXN0aW5hdGlvbi5cbiAgaXQoXCJ0aGUgVXBsb2FkIGJ1dHRvbiB1cGxvYWRzIHRoZSBwaWNrZWQgZmlsZSBuZXh0IHRvIHRoZSBzZWxlY3RlZCBmaWxlXCIsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCB7IHVzZXIsIGNvbnRhaW5lciB9ID0gYXdhaXQgcmVuZGVyV2l0aFNyY0V4cGFuZGVkKCk7XG4gICAgYXdhaXQgdXNlci5jbGljayhzY3JlZW4uZ2V0QnlUZXh0KFwiaW5kZXgudHNcIikpOyAvLyBzZWxlY3RzIHRoZSBmaWxlXG5cbiAgICBmaXJlRXZlbnQuY2xpY2soc2NyZWVuLmdldEJ5Um9sZShcImJ1dHRvblwiLCB7IG5hbWU6IFwiVXBsb2FkIGZpbGVzIHRvIC9zcmNcIiB9KSk7XG4gICAgY29uc3QgaW5wdXQgPSBjb250YWluZXIucXVlcnlTZWxlY3RvcjxIVE1MSW5wdXRFbGVtZW50PignaW5wdXRbdHlwZT1cImZpbGVcIl0nKSE7XG4gICAgZmlyZUV2ZW50LmNoYW5nZShpbnB1dCwge1xuICAgICAgdGFyZ2V0OiB7IGZpbGVzOiBbbmV3IEZpbGUoW1wiaGVsbG9cIl0sIFwibm90ZS50eHRcIiwgeyB0eXBlOiBcInRleHQvcGxhaW5cIiB9KV0gfSxcbiAgICB9KTtcblxuICAgIGF3YWl0IHZpLndhaXRGb3IoKCkgPT4gZXhwZWN0KGgudXBsb2FkRmlsZSkudG9IYXZlQmVlbkNhbGxlZCgpKTtcbiAgICBleHBlY3QoaC51cGxvYWRGaWxlLm1vY2suY2FsbHNbMF1bMF0pLnRvQmUoXCIvc3JjL25vdGUudHh0XCIpO1xuICB9KTtcbn0pO1xuXG4vLyAtLS0gUjMtODM6IGRyYWctb3V0IHNvdXJjZSAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5kZXNjcmliZShcIlIzLTgzIOKAlCBkcmFnLW91dCBhc2tzIHRoZSBob3N0IHRvIGJlZ2luIGEgY3Jvc3MtYXBwIGRyYWdcIiwgKCkgPT4ge1xuICBpdChcImRyYWdnaW5nIGEgZmlsZSByb3cgY2FsbHMgc3RhcnRJdGVtRHJhZyB3aXRoIGEgcmVmZXJlbmNlIHRvIHRoYXQgZmlsZVwiLCBhc3luYyAoKSA9PiB7XG4gICAgYXdhaXQgcmVuZGVyV2l0aFNyY0V4cGFuZGVkKCk7XG4gICAgY29uc3QgZmlsZVJvdyA9IHNjcmVlbi5nZXRCeVRleHQoXCJpbmRleC50c1wiKS5jbG9zZXN0KFwiLnRub2RlXCIpIGFzIEhUTUxFbGVtZW50O1xuICAgIGZpcmVFdmVudC5kcmFnU3RhcnQoZmlsZVJvdywgeyBkYXRhVHJhbnNmZXI6IGRhdGFUcmFuc2Zlcih7fSkgfSk7XG4gICAgYXdhaXQgdmkud2FpdEZvcigoKSA9PiBleHBlY3QoaC5zdGFydEl0ZW1EcmFnKS50b0hhdmVCZWVuQ2FsbGVkKCkpO1xuICAgIGV4cGVjdChoLnN0YXJ0SXRlbURyYWcubW9jay5jYWxsc1swXVswXSkudG9NYXRjaE9iamVjdCh7XG4gICAgICBraW5kOiBcImZpbGVcIixcbiAgICAgIG5hbWU6IFwiaW5kZXgudHNcIixcbiAgICAgIHJlbFBhdGg6IFwiL3NyYy9pbmRleC50c1wiLFxuICAgIH0pO1xuICB9KTtcbn0pO1xuXG5kZXNjcmliZShcIlIzLTk1IOKAlCBBcHAgfCBTZXNzaW9uIGxlbnMgKFBSSU5DSVBBTFMgwqc5IEIyIC8gRC1QUklOLTQpXCIsICgpID0+IHtcbiAgY29uc3Qgc2Vzc2lvblNwYWNlID0gKCkgPT4gKHtcbiAgICB0eXBlOiBcInNwYWNlXCIsXG4gICAgcGF0aDogXCIvc3BhY2VzL3Nlc3NcIixcbiAgICBpZDogXCJzZXNzXCIsXG4gICAgbmFtZTogXCJTZXNzaW9uIHNwYWNlXCIsXG4gICAgbW9kZTogXCJyb1wiIGFzIGNvbnN0LFxuICAgIGZvcndhcmRlZFRvQXBwOiBmYWxzZSxcbiAgfSk7XG5cbiAgaXQoXCIoIzUpIGhpZGVzIHRoZSBsZW5zIHRvZ2dsZSB3aGVuIHRoZSBob3N0IGRlbGl2ZXJzIG5vIHNlc3Npb24gc2lnbmFsIChhIGZvcmspXCIsIGFzeW5jICgpID0+IHtcbiAgICBoLm1vdW50cyA9IFt3b3JrdHJlZSgpXTtcbiAgICBoLnNlc3Npb25Nb3VudHMgPSBbXTsgLy8gZm9yazogbW91bnRzOnJlZ2lzdHJ5IHdpdGhoZWxkIOKGkiBlbXB0eSBzZXNzaW9uIGxpc3RcbiAgICByZW5kZXIoPEZpbGVFeHBsb3JlciAvPik7XG4gICAgZXhwZWN0KGF3YWl0IHNjcmVlbi5maW5kQnlSb2xlKFwidHJlZVwiLCB7IG5hbWU6IFwicmVwb1wiIH0pKS50b0JlSW5UaGVEb2N1bWVudCgpO1xuICAgIC8vIE5vIFNlc3Npb24gbGVuczogbmVpdGhlciB0aGUgdG9nZ2xlIGdyb3VwIG5vciB0aGUgU2Vzc2lvbiByYWRpbyBleGlzdHMuXG4gICAgZXhwZWN0KHNjcmVlbi5xdWVyeUJ5Um9sZShcInJhZGlvZ3JvdXBcIiwgeyBuYW1lOiBcIlNwYWNlcyBsZW5zXCIgfSkpLnRvQmVOdWxsKCk7XG4gICAgZXhwZWN0KHNjcmVlbi5xdWVyeUJ5Um9sZShcInJhZGlvXCIsIHsgbmFtZTogXCJUaGUgc2Vzc2lvbidzIHNwYWNlc1wiIH0pKS50b0JlTnVsbCgpO1xuICB9KTtcblxuICBpdChcInNob3dzIHRoZSB0b2dnbGUgZm9yIGEgZmlyc3QtcGFydHkgZnJhbWUgYW5kIHN3aXRjaGVzIHJvb3RzIHRvIHRoZSBzZXNzaW9uIG1vdW50c1wiLCBhc3luYyAoKSA9PiB7XG4gICAgaC5tb3VudHMgPSBbd29ya3RyZWUoKV07IC8vIHRoZSBBcHAgbGVucyA9IHRoaXMgYXBwJ3Mgb3duIG1vdW50c1xuICAgIGguc2Vzc2lvbk1vdW50cyA9IFtzZXNzaW9uU3BhY2UoKV07IC8vIGZpcnN0LXBhcnR5OiB0aGUgc2Vzc2lvbidzIG1vdW50c1xuICAgIGNvbnN0IHVzZXIgPSB1c2VyRXZlbnQuc2V0dXAoKTtcbiAgICByZW5kZXIoPEZpbGVFeHBsb3JlciAvPik7XG5cbiAgICAvLyBBcHAgbGVucyAoZGVmYXVsdCk6IHRoZSBhcHAncyBvd24gd29ya3RyZWUgc2hvd3M7IHRoZSBzZXNzaW9uLW9ubHkgc3BhY2UgZG9lcyBOT1RcbiAgICAvLyAoZXhpdCAjMSDigJQgYSBzZXNzaW9uLW9ubHkgbW91bnQgaXMgbmV2ZXIgaW4gdGhlIGFwcCdzIG93biB2aWV3KS5cbiAgICBleHBlY3QoYXdhaXQgc2NyZWVuLmZpbmRCeVJvbGUoXCJ0cmVlXCIsIHsgbmFtZTogXCJyZXBvXCIgfSkpLnRvQmVJblRoZURvY3VtZW50KCk7XG4gICAgZXhwZWN0KHNjcmVlbi5xdWVyeUJ5Um9sZShcInRyZWVcIiwgeyBuYW1lOiBcIlNlc3Npb24gc3BhY2VcIiB9KSkudG9CZU51bGwoKTtcblxuICAgIC8vIFRoZSB0b2dnbGUgaXMgcHJlc2VudCAoYSBzZXNzaW9uIHNpZ25hbCBhcnJpdmVkKS4gU3dpdGNoIHRvIHRoZSBTZXNzaW9uIGxlbnMuXG4gICAgYXdhaXQgdXNlci5jbGljayhzY3JlZW4uZ2V0QnlSb2xlKFwicmFkaW9cIiwgeyBuYW1lOiBcIlRoZSBzZXNzaW9uJ3Mgc3BhY2VzXCIgfSkpO1xuXG4gICAgLy8gU2Vzc2lvbiBsZW5zOiB0aGUgc2Vzc2lvbiBtb3VudCBzaG93czsgdGhlIEFwcC1sZW5zIHdvcmt0cmVlIGlzIHJlcGxhY2VkLlxuICAgIGV4cGVjdChhd2FpdCBzY3JlZW4uZmluZEJ5Um9sZShcInRyZWVcIiwgeyBuYW1lOiBcIlNlc3Npb24gc3BhY2VcIiB9KSkudG9CZUluVGhlRG9jdW1lbnQoKTtcbiAgICBleHBlY3Qoc2NyZWVuLnF1ZXJ5QnlSb2xlKFwidHJlZVwiLCB7IG5hbWU6IFwicmVwb1wiIH0pKS50b0JlTnVsbCgpO1xuICB9KTtcblxuICBpdChcIihSMy05NiBzdGVwIDRiKSBhcyB0aGUgcGFnZS5jb21tYW5kZXIgc3VyZmFjZSwgREVGQVVMVFMgdG8gdGhlIHJlZ2lzdHJ5IGxlbnMg4oCUIG5vIHRvZ2dsZVwiLCBhc3luYyAoKSA9PiB7XG4gICAgaC5tb3VudHMgPSBbd29ya3RyZWUoKV07IC8vIHRoZSBhcHAncyBvd24gd29ya3RyZWUgKEFwcCBsZW5zKVxuICAgIGguc2Vzc2lvbk1vdW50cyA9IFtzZXNzaW9uU3BhY2UoKV07IC8vIGZpcnN0LXBhcnR5IHJlZ2lzdHJ5IGxlbnMgYXZhaWxhYmxlXG4gICAgaC5yZWdpb24gPSBcInBhZ2UuY29tbWFuZGVyXCI7IC8vIHRoZSBzdGFuZGFsb25lIFVzZXItc2NvcGUgZnVsbCBtYW5hZ2VyXG4gICAgcmVuZGVyKDxGaWxlRXhwbG9yZXIgLz4pO1xuICAgIC8vIFdJVEhPVVQgY2xpY2tpbmcgdGhlIHRvZ2dsZTogdGhlIGNvbW1hbmRlciBvcGVucyBvbiB0aGUgYnJvYWQgcmVnaXN0cnkgbGVuc1xuICAgIC8vICh0aGUgXCJldmVyeXRoaW5nIHlvdSd2ZSBldmVyIG9wZW5lZFwiIG5hdmlnYXRvciksIHNvIHRoZSBzZXNzaW9uIG1vdW50IGlzIHRoZVxuICAgIC8vIGRlZmF1bHQgdmlldyBhbmQgdGhlIGFwcCdzIG93biB3b3JrdHJlZSBpcyBOT1QuXG4gICAgZXhwZWN0KGF3YWl0IHNjcmVlbi5maW5kQnlSb2xlKFwidHJlZVwiLCB7IG5hbWU6IFwiU2Vzc2lvbiBzcGFjZVwiIH0pKS50b0JlSW5UaGVEb2N1bWVudCgpO1xuICAgIGV4cGVjdChzY3JlZW4ucXVlcnlCeVJvbGUoXCJ0cmVlXCIsIHsgbmFtZTogXCJyZXBvXCIgfSkpLnRvQmVOdWxsKCk7XG4gICAgLy8gVGhlIHRvZ2dsZSBpcyBzdGlsbCBwcmVzZW50IHNvIHRoZSB1c2VyIGNhbiBuYXJyb3cgdG8gdGhlIEFwcCBsZW5zLlxuICAgIGV4cGVjdChzY3JlZW4uZ2V0QnlSb2xlKFwicmFkaW9cIiwgeyBuYW1lOiBcIlRoZSBzZXNzaW9uJ3Mgc3BhY2VzXCIgfSkpLnRvQmVJblRoZURvY3VtZW50KCk7XG4gIH0pO1xufSk7XG5cbmRlc2NyaWJlKFwiUjMtMjM4IOKAlCBzZXR0aW5ncyBmaWxlc3lzdGVtcyBhcmUgaGlkZGVuIGJlaGluZCBvbmUgYWR2YW5jZWQgZmxhZ1wiLCAoKSA9PiB7XG4gIGNvbnN0IHNldHRpbmdzTW91bnQgPSAoKSA9PiAoe1xuICAgIHR5cGU6IFwiZmlyZXN0b3JlXCIsXG4gICAgcGF0aDogXCIvbW50L3NldC9jb2xvci1waWNrZXJcIixcbiAgICBpZDogXCJzZXR0aW5nczpjb2xvci1waWNrZXJcIixcbiAgICBuYW1lOiBcImNvbG9yLXBpY2tlciBzZXR0aW5nc1wiLFxuICAgIG1vZGU6IFwicndcIiBhcyBjb25zdCxcbiAgfSk7XG5cbiAgYmVmb3JlRWFjaCgoKSA9PiB7XG4gICAgbG9jYWxTdG9yYWdlLmNsZWFyKCk7IC8vIHRoZSBmbGFnIHBlcnNpc3RzOyBlYWNoIGNhc2Ugc3RhcnRzIGZyb20gdGhlIHNoaXBwZWQgZGVmYXVsdFxuICB9KTtcblxuICBpdChcImEgZGVmYXVsdCBzZXNzaW9uIHNob3dzIG5vIHNldHRpbmdzIHJvb3QgYW5kIG5vIGBzZXR0aW5ncyDCtyA8YXBwPmAgYnV0dG9uXCIsIGFzeW5jICgpID0+IHtcbiAgICBoLm1vdW50cyA9IFt3b3JrdHJlZSgpLCBzZXR0aW5nc01vdW50KCldO1xuICAgIGgubGlzdFNldHRpbmdzQXBwcy5tb2NrUmVzb2x2ZWRWYWx1ZShbXCJhZ2VudC1kZW1vXCJdKTsgLy8gYW4gYXBwIHdob3NlIHN0b3JlIGlzbid0IG1vdW50ZWRcbiAgICByZW5kZXIoPEZpbGVFeHBsb3JlciAvPik7XG5cbiAgICAvLyBUaGUgb3JkaW5hcnkgbW91bnQgaXMgdW50b3VjaGVk4oCmXG4gICAgZXhwZWN0KGF3YWl0IHNjcmVlbi5maW5kQnlSb2xlKFwidHJlZVwiLCB7IG5hbWU6IFwicmVwb1wiIH0pKS50b0JlSW5UaGVEb2N1bWVudCgpO1xuICAgIC8vIOKApmFuZCBib3RoIHNldHRpbmdzIGFmZm9yZGFuY2VzIGFyZSBhYnNlbnQuXG4gICAgZXhwZWN0KHNjcmVlbi5xdWVyeUJ5Um9sZShcInRyZWVcIiwgeyBuYW1lOiBcImNvbG9yLXBpY2tlciBzZXR0aW5nc1wiIH0pKS50b0JlTnVsbCgpO1xuICAgIGV4cGVjdChzY3JlZW4ucXVlcnlCeVRpdGxlKFwiT3BlbiBhZ2VudC1kZW1vIHNldHRpbmdzXCIpKS50b0JlTnVsbCgpO1xuICAgIC8vIFRoZSByZXZlYWwgY29udHJvbCBpcyBvZmZlcmVkLCBiZWNhdXNlIHRoaXMgc2Vzc2lvbiBIQVMgc29tZXRoaW5nIGhpZGRlbi5cbiAgICBleHBlY3Qoc2NyZWVuLmdldEJ5Um9sZShcImJ1dHRvblwiLCB7IG5hbWU6IFwiU2hvdyBhbGwgZmlsZXN5c3RlbXNcIiB9KSkudG9IYXZlQXR0cmlidXRlKFxuICAgICAgXCJhcmlhLXByZXNzZWRcIixcbiAgICAgIFwiZmFsc2VcIixcbiAgICApO1xuICB9KTtcblxuICBpdChcInRvZ2dsaW5nIHRoZSBmbGFnIHJlc3RvcmVzIGJvdGggdGhlIHNldHRpbmdzIHJvb3QgYW5kIHRoZSBoZWFkZXIgYnV0dG9uLCBhbmQgcGVyc2lzdHNcIiwgYXN5bmMgKCkgPT4ge1xuICAgIGgubW91bnRzID0gW3dvcmt0cmVlKCksIHNldHRpbmdzTW91bnQoKV07XG4gICAgaC5saXN0U2V0dGluZ3NBcHBzLm1vY2tSZXNvbHZlZFZhbHVlKFtcImFnZW50LWRlbW9cIl0pO1xuICAgIGNvbnN0IHVzZXIgPSB1c2VyRXZlbnQuc2V0dXAoKTtcbiAgICByZW5kZXIoPEZpbGVFeHBsb3JlciAvPik7XG4gICAgYXdhaXQgc2NyZWVuLmZpbmRCeVJvbGUoXCJ0cmVlXCIsIHsgbmFtZTogXCJyZXBvXCIgfSk7XG5cbiAgICBhd2FpdCB1c2VyLmNsaWNrKHNjcmVlbi5nZXRCeVJvbGUoXCJidXR0b25cIiwgeyBuYW1lOiBcIlNob3cgYWxsIGZpbGVzeXN0ZW1zXCIgfSkpO1xuXG4gICAgZXhwZWN0KGF3YWl0IHNjcmVlbi5maW5kQnlSb2xlKFwidHJlZVwiLCB7IG5hbWU6IFwiY29sb3ItcGlja2VyIHNldHRpbmdzXCIgfSkpLnRvQmVJblRoZURvY3VtZW50KCk7XG4gICAgZXhwZWN0KGF3YWl0IHNjcmVlbi5maW5kQnlUaXRsZShcIk9wZW4gYWdlbnQtZGVtbyBzZXR0aW5nc1wiKSkudG9CZUluVGhlRG9jdW1lbnQoKTtcbiAgICAvLyBUaGUgb3JkaW5hcnkgbW91bnQgaXMgc3RpbGwgdGhlcmUg4oCUIHRoaXMgcmV2ZWFscywgaXQgZG9lcyBub3QgcmVwbGFjZS5cbiAgICBleHBlY3Qoc2NyZWVuLmdldEJ5Um9sZShcInRyZWVcIiwgeyBuYW1lOiBcInJlcG9cIiB9KSkudG9CZUluVGhlRG9jdW1lbnQoKTtcbiAgICBleHBlY3QobG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJpci5maWxlZXhwbG9yZXIuc2hvd0FsbEZpbGVzeXN0ZW1zXCIpKS50b0JlKFwiMVwiKTtcbiAgICAvLyBBbmQgdGhlIGRvb3Igc3dpbmdzIGJhY2suXG4gICAgZXhwZWN0KHNjcmVlbi5nZXRCeVJvbGUoXCJidXR0b25cIiwgeyBuYW1lOiBcIkhpZGUgYWR2YW5jZWQgZmlsZXN5c3RlbXNcIiB9KSkudG9IYXZlQXR0cmlidXRlKFxuICAgICAgXCJhcmlhLXByZXNzZWRcIixcbiAgICAgIFwidHJ1ZVwiLFxuICAgICk7XG4gIH0pO1xuXG4gIGl0KFwib2ZmZXJzIG5vIHJldmVhbCBjb250cm9sIHdoZW4gdGhlIHNlc3Npb24gaGFzIG5vdGhpbmcgaGlkZGVuXCIsIGFzeW5jICgpID0+IHtcbiAgICBoLm1vdW50cyA9IFt3b3JrdHJlZSgpXTtcbiAgICBoLmxpc3RTZXR0aW5nc0FwcHMubW9ja1Jlc29sdmVkVmFsdWUoW10pO1xuICAgIHJlbmRlcig8RmlsZUV4cGxvcmVyIC8+KTtcbiAgICBhd2FpdCBzY3JlZW4uZmluZEJ5Um9sZShcInRyZWVcIiwgeyBuYW1lOiBcInJlcG9cIiB9KTtcbiAgICBleHBlY3Qoc2NyZWVuLnF1ZXJ5QnlSb2xlKFwiYnV0dG9uXCIsIHsgbmFtZTogXCJTaG93IGFsbCBmaWxlc3lzdGVtc1wiIH0pKS50b0JlTnVsbCgpO1xuICB9KTtcblxuICBpdChcImtlZXBzIHRoZSByZXZlYWwgY29udHJvbCByZWFjaGFibGUgd2hlbiBFVkVSWVRISU5HIGlzIGhpZGRlbiAobm8gZGVhZCBlbmQpXCIsIGFzeW5jICgpID0+IHtcbiAgICAvLyBUaGUgcGF0aG9sb2dpY2FsIGNvbW1hbmRlciBjYXNlOiBldmVyeSBtb3VudCBpcyBhIHNldHRpbmdzIHN0b3JlLCBzbyB0aGUgcm9vdFxuICAgIC8vIGxpc3QgaXMgZW1wdHkuIFRoZSBoZWFkZXIncyBhY3Rpb24gY2x1c3RlciB1c2VkIHRvIGJlIGdhdGVkIG9uIGhhdmluZyByb290cyDigJRcbiAgICAvLyB3aGljaCB3b3VsZCBoaWRlIHRoZSBvbmUgY29udHJvbCB0aGF0IGJyaW5ncyB0aGVtIGJhY2suXG4gICAgaC5tb3VudHMgPSBbc2V0dGluZ3NNb3VudCgpXTtcbiAgICBoLmxpc3RTZXR0aW5nc0FwcHMubW9ja1Jlc29sdmVkVmFsdWUoW10pO1xuICAgIGNvbnN0IHVzZXIgPSB1c2VyRXZlbnQuc2V0dXAoKTtcbiAgICByZW5kZXIoPEZpbGVFeHBsb3JlciAvPik7XG5cbiAgICBjb25zdCB0b2dnbGUgPSBhd2FpdCBzY3JlZW4uZmluZEJ5Um9sZShcImJ1dHRvblwiLCB7IG5hbWU6IFwiU2hvdyBhbGwgZmlsZXN5c3RlbXNcIiB9KTtcbiAgICBleHBlY3Qoc2NyZWVuLnF1ZXJ5QnlSb2xlKFwidHJlZVwiKSkudG9CZU51bGwoKTtcbiAgICBhd2FpdCB1c2VyLmNsaWNrKHRvZ2dsZSk7XG4gICAgZXhwZWN0KGF3YWl0IHNjcmVlbi5maW5kQnlSb2xlKFwidHJlZVwiLCB7IG5hbWU6IFwiY29sb3ItcGlja2VyIHNldHRpbmdzXCIgfSkpLnRvQmVJblRoZURvY3VtZW50KCk7XG4gIH0pO1xuXG4gIGl0KFwiaGlkZXMgc2V0dGluZ3Mgc3RvcmVzIGluIHRoZSBTZXNzaW9uIGxlbnMgdG9vICh0aGUgY29tbWFuZGVyJ3MgZGVmYXVsdCB2aWV3KVwiLCBhc3luYyAoKSA9PiB7XG4gICAgaC5tb3VudHMgPSBbd29ya3RyZWUoKV07XG4gICAgaC5zZXNzaW9uTW91bnRzID0gW1xuICAgICAgeyB0eXBlOiBcInNwYWNlXCIsIHBhdGg6IFwiL3NwYWNlcy9zXCIsIGlkOiBcInNwYWNlOnNcIiwgbmFtZTogXCJTZXNzaW9uIHNwYWNlXCIsIG1vZGU6IFwicm9cIiwgZm9yd2FyZGVkVG9BcHA6IGZhbHNlIH0sXG4gICAgICB7IC4uLnNldHRpbmdzTW91bnQoKSwgZm9yd2FyZGVkVG9BcHA6IGZhbHNlIH0sXG4gICAgXTtcbiAgICBoLnJlZ2lvbiA9IFwicGFnZS5jb21tYW5kZXJcIjsgLy8gZGVmYXVsdHMgdG8gdGhlIFNlc3Npb24gbGVuc1xuICAgIGgubGlzdFNldHRpbmdzQXBwcy5tb2NrUmVzb2x2ZWRWYWx1ZShbXSk7XG4gICAgY29uc3QgdXNlciA9IHVzZXJFdmVudC5zZXR1cCgpO1xuICAgIHJlbmRlcig8RmlsZUV4cGxvcmVyIC8+KTtcblxuICAgIGV4cGVjdChhd2FpdCBzY3JlZW4uZmluZEJ5Um9sZShcInRyZWVcIiwgeyBuYW1lOiBcIlNlc3Npb24gc3BhY2VcIiB9KSkudG9CZUluVGhlRG9jdW1lbnQoKTtcbiAgICBleHBlY3Qoc2NyZWVuLnF1ZXJ5QnlSb2xlKFwidHJlZVwiLCB7IG5hbWU6IFwiY29sb3ItcGlja2VyIHNldHRpbmdzXCIgfSkpLnRvQmVOdWxsKCk7XG4gICAgLy8gVGhlIGxlbnMgdG9nZ2xlIHN0aWxsIHJlbmRlcnMg4oCUIGBhdmFpbGFibGVgIHJlYWRzIHRoZSByYXcgc2Vzc2lvbiBzaWduYWwsIG5vdFxuICAgIC8vIHRoZSBmaWx0ZXJlZCByb290cywgc28gZmlsdGVyaW5nIGNhbiBuZXZlciBzdHJhbmQgdGhlIHVzZXIgaW4gb25lIGxlbnMuXG4gICAgZXhwZWN0KHNjcmVlbi5nZXRCeVJvbGUoXCJyYWRpb1wiLCB7IG5hbWU6IFwiVGhlIHNlc3Npb24ncyBzcGFjZXNcIiB9KSkudG9CZUluVGhlRG9jdW1lbnQoKTtcblxuICAgIGF3YWl0IHVzZXIuY2xpY2soc2NyZWVuLmdldEJ5Um9sZShcImJ1dHRvblwiLCB7IG5hbWU6IFwiU2hvdyBhbGwgZmlsZXN5c3RlbXNcIiB9KSk7XG4gICAgZXhwZWN0KGF3YWl0IHNjcmVlbi5maW5kQnlSb2xlKFwidHJlZVwiLCB7IG5hbWU6IFwiY29sb3ItcGlja2VyIHNldHRpbmdzXCIgfSkpLnRvQmVJblRoZURvY3VtZW50KCk7XG4gIH0pO1xufSk7XG5cbmRlc2NyaWJlKFwiUjMtMjM5IOKAlCB0aGUgaGVhZGVyJ3Mgc2l6ZSBtdXN0IG5vdCBmb2xsb3cgdGhlIG1vdW50LWxhYmVsIGxlbmd0aFwiLCAoKSA9PiB7XG4gIC8vIFRoZSBmaXggaXMgQ1NTLCB3aGljaCBqc2RvbSBjYW5ub3QgbGF5IG91dC4gV2hhdCBqc2RvbSBDQU4gcGluIGlzIHRoZSBNQVJLVVBcbiAgLy8gQ09OVFJBQ1QgdGhlIENTUyBkZXBlbmRzIG9uIOKAlCB0aGUgdHdvIHNlYW1zIHRoYXQgd291bGQgc2lsZW50bHkgdW4tZml4IGl0OlxuICAvLyBhbiBlbGxpcHNpcyBuZWVkcyBpdHMgb3duIGJsb2NrIGJveCAoYSBiYXJlIHRleHQgbm9kZSBpbiBhIGZsZXggYnV0dG9uIGNhbiBvbmx5XG4gIC8vIG92ZXJmbG93KSwgYW5kIHRoZSBjb21wYWN0LXZpZXctc3dpdGNoZXIgcnVsZSBrZXlzIG9mZiB0aGUgYC0tZXh0cmFgIG1vZGlmaWVyLlxuICAvLyBHZW9tZXRyeSBpdHNlbGYgaXMgdmVyaWZpZWQgaW4gYSBoZWFkbGVzcy1DaHJvbWUgaGFybmVzczsgbnVtYmVycyBpbiB0aGUgUFIuXG4gIGJlZm9yZUVhY2goKCkgPT4ge1xuICAgIGxvY2FsU3RvcmFnZS5jbGVhcigpO1xuICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwiaXIuZmlsZWV4cGxvcmVyLnNob3dBbGxGaWxlc3lzdGVtc1wiLCBcIjFcIik7XG4gIH0pO1xuXG4gIGl0KFwicmVuZGVycyB0aGUgc2V0dGluZ3MtYXBwIGxhYmVsIGluIGl0cyBvd24gdHJ1bmNhdGFibGUgZWxlbWVudFwiLCBhc3luYyAoKSA9PiB7XG4gICAgaC5tb3VudHMgPSBbd29ya3RyZWUoKV07XG4gICAgaC5saXN0U2V0dGluZ3NBcHBzLm1vY2tSZXNvbHZlZFZhbHVlKFtcImEtcmVhbGx5LWxvbmctYXBwbGljYXRpb24ta2V5XCJdKTtcbiAgICByZW5kZXIoPEZpbGVFeHBsb3JlciAvPik7XG5cbiAgICBjb25zdCBidG4gPSBhd2FpdCBzY3JlZW4uZmluZEJ5VGl0bGUoXCJPcGVuIGEtcmVhbGx5LWxvbmctYXBwbGljYXRpb24ta2V5IHNldHRpbmdzXCIpO1xuICAgIGNvbnN0IGxhYmVsID0gYnRuLnF1ZXJ5U2VsZWN0b3IoXCIuc2V0dGluZ3MtYXBwX19sYWJlbFwiKTtcbiAgICBleHBlY3QobGFiZWwpLm5vdC50b0JlTnVsbCgpO1xuICAgIGV4cGVjdChsYWJlbCkudG9IYXZlVGV4dENvbnRlbnQoXCJzZXR0aW5ncyDCtyBhLXJlYWxseS1sb25nLWFwcGxpY2F0aW9uLWtleVwiKTtcbiAgICAvLyBUaGUgbGFiZWwgbXVzdCBiZSB0aGUgT05MWSB0ZXh0IOKAlCBhbiBpY29uIHNpYmxpbmcsIG5vdCBhIHRleHQgc2libGluZywgb3IgdGhlXG4gICAgLy8gYW5vbnltb3VzIHRleHQgbm9kZSByZWFwcGVhcnMgYW5kIGRlZmVhdHMgYHRleHQtb3ZlcmZsb3dgLlxuICAgIGV4cGVjdChidG4udGV4dENvbnRlbnQpLnRvQmUobGFiZWwhLnRleHRDb250ZW50KTtcbiAgfSk7XG5cbiAgaXQoXCJtYXJrcyB0aGUgYWN0aW9uIGNsdXN0ZXIgYC0tZXh0cmFgIHdoZW4gYSBjb25zdW1lciBzdXBwbGllcyBoZWFkZXIgY29udHJvbHNcIiwgYXN5bmMgKCkgPT4ge1xuICAgIGgubW91bnRzID0gW3dvcmt0cmVlKCldO1xuICAgIGgubGlzdFNldHRpbmdzQXBwcy5tb2NrUmVzb2x2ZWRWYWx1ZShbXCJjcFwiXSk7XG4gICAgcmVuZGVyKDxGaWxlRXhwbG9yZXIgLz4pO1xuICAgIGF3YWl0IHNjcmVlbi5maW5kQnlUaXRsZShcIk9wZW4gY3Agc2V0dGluZ3NcIik7XG4gICAgZXhwZWN0KGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIucGFuZWxfX2FjdGlvbnNcIikpLnRvSGF2ZUNsYXNzKFwicGFuZWxfX2FjdGlvbnMtLWV4dHJhXCIpO1xuICB9KTtcblxuICAvLyBUaGUgaGVhZGVyIHJvdyBpcyBhIEZJWEVEIGJ1ZGdldDsgdGhlcmUgaXMgb25lIHNldHRpbmdzIHBpbGwgcGVyIGFwcCB3aXRoIHNldHRpbmdzLFxuICAvLyBzbyB0aGVpciBjb3VudCBpcyBkYXRhLiBTaGFyaW5nIHRoZSByb3cgb3V0IGFtb25nIHRoZW0gaXMgd2hhdCBzaHJhbmsgZWFjaCBwaWxsIHRvXG4gIC8vIDE3cHgg4oCUIG5hcnJvd2VyIHRoYW4gdGhlIDE0cHggaWNvbiBpbiBpdCwgd2hpY2ggdGhlbiBzcGlsbGVkIG92ZXIgaXRzIG5laWdoYm91ciBhbmRcbiAgLy8gb2ZmIHRoZSBwYW5lbCBlZGdlLiBqc2RvbSBoYXMgbm8gbGF5b3V0LCBzbyB0aGUgYXNzZXJ0aW9uIGlzIHRoZSBzdHJ1Y3R1cmFsIGZhY3RcbiAgLy8gdGhhdCBwcmV2ZW50cyBpdDogdGhlIHBpbGxzIGFyZSBub3QgaW4gdGhlIGZpeGVkIHJvdyBhdCBhbGwuXG4gIGl0KFwicHV0cyB0aGUgc2V0dGluZ3MgcGlsbHMgaW4gdGhlIHRyYXksIG5vdCBpbiB0aGUgZml4ZWQgaGVhZGVyIHJvd1wiLCBhc3luYyAoKSA9PiB7XG4gICAgaC5tb3VudHMgPSBbd29ya3RyZWUoKV07XG4gICAgaC5saXN0U2V0dGluZ3NBcHBzLm1vY2tSZXNvbHZlZFZhbHVlKFtcIm9uZVwiLCBcInR3b1wiLCBcInRocmVlXCJdKTtcbiAgICByZW5kZXIoPEZpbGVFeHBsb3JlciAvPik7XG4gICAgYXdhaXQgc2NyZWVuLmZpbmRCeVRpdGxlKFwiT3BlbiBvbmUgc2V0dGluZ3NcIik7XG5cbiAgICBjb25zdCB0cmF5ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIi5wYW5lbF9fdHJheVwiKTtcbiAgICBleHBlY3QodHJheSkubm90LnRvQmVOdWxsKCk7XG4gICAgZXhwZWN0KHRyYXkhLnF1ZXJ5U2VsZWN0b3JBbGwoXCIuc2V0dGluZ3MtYXBwXCIpKS50b0hhdmVMZW5ndGgoMyk7XG4gICAgZXhwZWN0KGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIucGFuZWxfX2FjdGlvbnNcIikhLnF1ZXJ5U2VsZWN0b3JBbGwoXCIuc2V0dGluZ3MtYXBwXCIpKS50b0hhdmVMZW5ndGgoMCk7XG4gICAgLy8gVGhlIGNvbnRyb2xzIHdpdGggYSBmaXhlZCBjb3VudCBzdGF5IGluIHRoZSBoZWFkZXIgcm93LCB3aGVyZSB0aGV5IGJlbG9uZy5cbiAgICBleHBlY3QoXG4gICAgICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiLnBhbmVsX19hY3Rpb25zXCIpIS5xdWVyeVNlbGVjdG9yKCdbYXJpYS1sYWJlbD1cIkFkZCBhIHNwYWNl4oCmXCJdJyksXG4gICAgKS5ub3QudG9CZU51bGwoKTtcbiAgfSk7XG5cbiAgaXQoXCJncm93cyBubyB0cmF5IHdoZW4gdGhlcmUgaXMgbm90aGluZyB0byBwdXQgaW4gaXRcIiwgYXN5bmMgKCkgPT4ge1xuICAgIGgubW91bnRzID0gW3dvcmt0cmVlKCldO1xuICAgIGgubGlzdFNldHRpbmdzQXBwcy5tb2NrUmVzb2x2ZWRWYWx1ZShbXSk7XG4gICAgcmVuZGVyKDxGaWxlRXhwbG9yZXIgLz4pO1xuICAgIGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KFwic3JjXCIpO1xuICAgIGV4cGVjdChkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiLnBhbmVsX190cmF5XCIpKS50b0JlTnVsbCgpO1xuICB9KTtcblxuICBpdChcImRyb3BzIHRoZSB0cmF5IGFnYWluIHdoZW4gdGhlIHNldHRpbmdzIGFwcHMgYXJlIGhpZGRlblwiLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgdXNlciA9IHVzZXJFdmVudC5zZXR1cCgpO1xuICAgIGgubW91bnRzID0gW3dvcmt0cmVlKCldO1xuICAgIGgubGlzdFNldHRpbmdzQXBwcy5tb2NrUmVzb2x2ZWRWYWx1ZShbXCJjcFwiXSk7XG4gICAgcmVuZGVyKDxGaWxlRXhwbG9yZXIgLz4pO1xuICAgIGF3YWl0IHNjcmVlbi5maW5kQnlUaXRsZShcIk9wZW4gY3Agc2V0dGluZ3NcIik7XG4gICAgZXhwZWN0KGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIucGFuZWxfX3RyYXlcIikpLm5vdC50b0JlTnVsbCgpO1xuXG4gICAgYXdhaXQgdXNlci5jbGljayhzY3JlZW4uZ2V0QnlSb2xlKFwiYnV0dG9uXCIsIHsgbmFtZTogXCJIaWRlIGFkdmFuY2VkIGZpbGVzeXN0ZW1zXCIgfSkpO1xuXG4gICAgZXhwZWN0KGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIucGFuZWxfX3RyYXlcIikpLnRvQmVOdWxsKCk7XG4gIH0pO1xufSk7XG5cbi8vIC0tLSBSMy0yNjggZm9sbG93LXVwOiBnZXN0dXJlLWdhdGVkIHJldmVhbCArIGNvbGxhcHNlZC1hbmNlc3RvciBkb3QgLS0tLS0tLS0tLVxuZGVzY3JpYmUoXCJ2aWV3ZWQtZG9jdW1lbnQgcmV2ZWFsICsgYW5jZXN0b3IgZG90XCIsICgpID0+IHtcbiAgaXQoXCJhIGNvbGxhcHNlZCBmb2xkZXIgY29udGFpbmluZyB0aGUgdmlld2VkIGZpbGUgY2FycmllcyB0aGUgZGltbWVkIGFuY2VzdG9yIGRvdFwiLCBhc3luYyAoKSA9PiB7XG4gICAgaC52aWV3ZWRGaWxlID0gXCIvc3JjL2luZGV4LnRzXCI7XG4gICAgcmVuZGVyKDxGaWxlRXhwbG9yZXIgLz4pO1xuICAgIGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KFwic3JjXCIpOyAvLyByb290IGxpc3RlZDsgYHNyY2Agc3RhcnRzIENPTExBUFNFRFxuICAgIC8vIFRoZSBkb3QgbmFtZXMgaXRzIG1lYW5pbmc7IHRoZSBmb2xkZXIgaXRzZWxmIG5ldmVyIG9wZW5zIG9uIGl0cyBvd24uXG4gICAgZXhwZWN0KFxuICAgICAgYXdhaXQgc2NyZWVuLmZpbmRCeVJvbGUoXCJpbWdcIiwgeyBuYW1lOiBcIkNvbnRhaW5zIHRoZSBmaWxlIHNob3duIGluIHRoZSBydW5uaW5nIGFwcFwiIH0pLFxuICAgICkudG9CZUluVGhlRG9jdW1lbnQoKTtcbiAgICBleHBlY3Qoc2NyZWVuLnF1ZXJ5QnlUZXh0KFwiaW5kZXgudHNcIikpLm5vdC50b0JlSW5UaGVEb2N1bWVudCgpO1xuICB9KTtcblxuICBpdChcIlIzLTQ0MDogdGhlIGFwcCByZXBvcnRzIHJlYWR5IGltbWVkaWF0ZWx5IGFmdGVyIHN1YnNjcmliaW5nIHRoZSByZXZlYWwgbGlzdGVuZXIgKHRoZSBob3N0IGhvbGRzIHBlbmRpbmcgcmV2ZWFscyB1bnRpbCB0aGVuKVwiLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgYmVmb3JlID0gaC5yZXBvcnRSZWFkeUxpc3RlbmVyQ291bnQubGVuZ3RoO1xuICAgIHJlbmRlcig8RmlsZUV4cGxvcmVyIC8+KTtcbiAgICBhd2FpdCBzY3JlZW4uZmluZEJ5VGV4dChcInNyY1wiKTtcbiAgICBjb25zdCBtaW5lID0gaC5yZXBvcnRSZWFkeUxpc3RlbmVyQ291bnQuc2xpY2UoYmVmb3JlKTtcbiAgICBleHBlY3QobWluZSkudG9IYXZlTGVuZ3RoKDEpOyAvLyBleGFjdGx5IG9uZSByZXBvcnQgcGVyIG1vdW50ICh0aGUgU0RLIGRlZHVwZXMgYmV5b25kIHRoYXQpXG4gICAgLy8gVGhlIG9yZGVyaW5nIElTIHRoZSBjb250cmFjdDogYXQgdGhlIHJlcG9ydCwgdGhlIHZpZXdlZC1yZXZlYWwgbGlzdGVuZXJcbiAgICAvLyB3YXMgYWxyZWFkeSBzdWJzY3JpYmVkIChhIHJlcG9ydCBiZWZvcmUgaXQgd291bGQgcmVsZWFzZSB0aGUgaG9zdCdzIGhlbGRcbiAgICAvLyBvbmUtc2hvdCBpbnRvIGEgZnJhbWUgdGhhdCBjYW5ub3QgaGVhciBpdCkuXG4gICAgZXhwZWN0KG1pbmVbMF0pLnRvQmUoMSk7XG4gIH0pO1xuXG4gIGl0KFwiUjMtNDQwOiBhIHJldmVhbCBlbWl0dGVkIGJlZm9yZSB0aGUgcm9vdHMgZXhpc3QgbGFuZHMgd2hlbiB0aGV5IGFycml2ZSAodGhlIHJvb3RLZXkgcmV0cnkpXCIsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCBzY3JvbGxzOiBFbGVtZW50W10gPSBbXTtcbiAgICBjb25zdCBvcmlnID0gRWxlbWVudC5wcm90b3R5cGUuc2Nyb2xsSW50b1ZpZXc7XG4gICAgRWxlbWVudC5wcm90b3R5cGUuc2Nyb2xsSW50b1ZpZXcgPSBmdW5jdGlvbiAoKSB7XG4gICAgICBzY3JvbGxzLnB1c2godGhpcyk7XG4gICAgfTtcbiAgICB0cnkge1xuICAgICAgLy8gVGhlIGJvb3QgcmFjZSB0aGUgaG9zdCdzIHJlYWRpbmVzcyBnYXRlIGV4cG9zZXM6IHRoZSByZXBvcnQgZmlyZXMgYXQgdGhlXG4gICAgICAvLyBtb3VudCBlZmZlY3QsIHNvIHRoZSBoZWxkIHJldmVhbCBjYW4gbGFuZCB3aGlsZSB0aGUgc3RvcmUgaGFzIE5PIHJvb3RzLlxuICAgICAgLy8gKFRoZSBtYXJrZXIgaXRzZWxmIHJpZGVzIHRoZSBgdmlld2VkRmlsZWAgaGludCDigJQgdGhlIGhvc3QgcHVzaGVzIGl0IHdpdGhcbiAgICAgIC8vIHRoZSBuYXZpZ2F0aW9uOyB0aGUgcmV2ZWFsIGlzIHRoZSBleHBhbmQrc2Nyb2xsIGdlc3R1cmUgaGFsZi4pXG4gICAgICBoLnZpZXdlZEZpbGUgPSBcIi9zcmMvaW5kZXgudHNcIjtcbiAgICAgIGgubW91bnRzID0gW107XG4gICAgICBjb25zdCB7IHJlcmVuZGVyIH0gPSByZW5kZXIoPEZpbGVFeHBsb3JlciAvPik7XG4gICAgICBhY3QoKCkgPT4gaC5lbWl0KFwidmlld2VkLXJldmVhbFwiLCB7IHR5cGU6IFwidmlld2VkLXJldmVhbFwiLCBwYXRoOiBcIi9zcmMvaW5kZXgudHNcIiB9KSk7XG4gICAgICBleHBlY3Qoc2NyZWVuLnF1ZXJ5QnlUZXh0KFwic3JjXCIpKS5ub3QudG9CZUluVGhlRG9jdW1lbnQoKTsgLy8gbm90aGluZyB0byBleHBhbmQgaW50b1xuXG4gICAgICAvLyBUaGUgbW91bnRzIGFycml2ZSAodGhlIGhvc3QncyBwdXNoKSDigJQgdGhlIHJldmVhbCBtdXN0IFJFVFJZLCBub3QgYmUgbG9zdC5cbiAgICAgIGgubW91bnRzID0gW3dvcmt0cmVlKCldO1xuICAgICAgcmVyZW5kZXIoPEZpbGVFeHBsb3JlciAvPik7XG5cbiAgICAgIGNvbnN0IHNyYyA9IGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KFwic3JjXCIpO1xuICAgICAgZXhwZWN0KHNyYykudG9CZUluVGhlRG9jdW1lbnQoKTtcbiAgICAgIC8vIFRoZSBhbmNlc3RvcnMgZXhwYW5kZWQgb24gdGhlaXIgb3duOiB0aGUgZmlsZSByb3cgcmVuZGVycyB3aXRob3V0IGFueSBjbGlja+KAplxuICAgICAgY29uc3Qgcm93ID0gYXdhaXQgc2NyZWVuLmZpbmRCeVRleHQoXCJpbmRleC50c1wiKTtcbiAgICAgIGV4cGVjdChyb3cpLnRvQmVJblRoZURvY3VtZW50KCk7XG4gICAgICAvLyDigKZjYXJyeWluZyB0aGUgbWFya2VyLCBzY3JvbGxlZCBpbnRvIHZpZXcgb25jZSBpdCByZW5kZXJlZC5cbiAgICAgIGV4cGVjdChcbiAgICAgICAgYXdhaXQgc2NyZWVuLmZpbmRCeVJvbGUoXCJpbWdcIiwgeyBuYW1lOiBcIlNob3duIGluIHRoZSBydW5uaW5nIGFwcFwiIH0pLFxuICAgICAgKS50b0JlSW5UaGVEb2N1bWVudCgpO1xuICAgICAgYXdhaXQgd2FpdEZvcigoKSA9PiBleHBlY3Qoc2Nyb2xscy5sZW5ndGgpLnRvQmVHcmVhdGVyVGhhbigwKSk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIEVsZW1lbnQucHJvdG90eXBlLnNjcm9sbEludG9WaWV3ID0gb3JpZztcbiAgICB9XG4gIH0pO1xuXG4gIGl0KFwiYSBob3N0IGB2aWV3ZWQtcmV2ZWFsYCBleHBhbmRzIHRoZSBhbmNlc3RvcnMgYW5kIHNjcm9sbHMgdGhlIHJvdyBpbnRvIHZpZXcg4oCUIHdpdGhvdXQgZm9jdXNcIiwgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHNjcm9sbHM6IEVsZW1lbnRbXSA9IFtdO1xuICAgIGNvbnN0IG9yaWcgPSBFbGVtZW50LnByb3RvdHlwZS5zY3JvbGxJbnRvVmlldztcbiAgICBFbGVtZW50LnByb3RvdHlwZS5zY3JvbGxJbnRvVmlldyA9IGZ1bmN0aW9uICgpIHtcbiAgICAgIHNjcm9sbHMucHVzaCh0aGlzKTtcbiAgICB9O1xuICAgIHRyeSB7XG4gICAgICBoLnZpZXdlZEZpbGUgPSBcIi9zcmMvaW5kZXgudHNcIjtcbiAgICAgIHJlbmRlcig8RmlsZUV4cGxvcmVyIC8+KTtcbiAgICAgIGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KFwic3JjXCIpO1xuICAgICAgY29uc3QgYmVmb3JlID0gZG9jdW1lbnQuYWN0aXZlRWxlbWVudDtcblxuICAgICAgYWN0KCgpID0+IGguZW1pdChcInZpZXdlZC1yZXZlYWxcIiwgeyB0eXBlOiBcInZpZXdlZC1yZXZlYWxcIiwgcGF0aDogXCIvc3JjL2luZGV4LnRzXCIgfSkpO1xuXG4gICAgICAvLyBBbmNlc3RvcnMgZXhwYW5kZWQg4oaSIHRoZSByb3cgcmVuZGVycywgY2FycnlpbmcgdGhlIG9uLXN0YWdlIG1hcmtlcuKAplxuICAgICAgY29uc3Qgcm93ID0gYXdhaXQgc2NyZWVuLmZpbmRCeVRleHQoXCJpbmRleC50c1wiKTtcbiAgICAgIGV4cGVjdChyb3cpLnRvQmVJblRoZURvY3VtZW50KCk7XG4gICAgICBleHBlY3QoXG4gICAgICAgIGF3YWl0IHNjcmVlbi5maW5kQnlSb2xlKFwiaW1nXCIsIHsgbmFtZTogXCJTaG93biBpbiB0aGUgcnVubmluZyBhcHBcIiB9KSxcbiAgICAgICkudG9CZUluVGhlRG9jdW1lbnQoKTtcbiAgICAgIC8vIOKApnRoZSByb3cgaXMgc2Nyb2xsZWQgaW50byB2aWV3IChib3VuZGVkIHBvbGwgaW5zaWRlIHRoZSB2aWV3KeKAplxuICAgICAgYXdhaXQgd2FpdEZvcigoKSA9PiBleHBlY3Qoc2Nyb2xscy5sZW5ndGgpLnRvQmVHcmVhdGVyVGhhbigwKSk7XG4gICAgICAvLyDigKZhbmQgZm9jdXMgTkVWRVIgbW92ZWQgKHRoZSBhY3RpdmF0aW9uLWZyZWUgaGFsZiB0aGF0IHN0aWxsIGhvbGRzKS5cbiAgICAgIGV4cGVjdChkb2N1bWVudC5hY3RpdmVFbGVtZW50KS50b0JlKGJlZm9yZSk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIEVsZW1lbnQucHJvdG90eXBlLnNjcm9sbEludG9WaWV3ID0gb3JpZztcbiAgICB9XG4gIH0pO1xuXG4gIGl0KFwid2l0aG91dCBhIHJldmVhbCBtZXNzYWdlIHRoZSB0cmVlIG5ldmVyIG1vdmVzIG9uIGl0cyBvd24gKGhpZ2hsaWdodC1vbmx5KVwiLCBhc3luYyAoKSA9PiB7XG4gICAgaC52aWV3ZWRGaWxlID0gXCIvc3JjL2luZGV4LnRzXCI7XG4gICAgcmVuZGVyKDxGaWxlRXhwbG9yZXIgLz4pO1xuICAgIGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KFwic3JjXCIpO1xuICAgIGF3YWl0IG5ldyBQcm9taXNlKChyKSA9PiBzZXRUaW1lb3V0KHIsIDUwKSk7XG4gICAgZXhwZWN0KHNjcmVlbi5xdWVyeUJ5VGV4dChcImluZGV4LnRzXCIpKS5ub3QudG9CZUluVGhlRG9jdW1lbnQoKTsgLy8gc3RpbGwgY29sbGFwc2VkXG4gIH0pO1xufSk7XG5cbi8vIC0tLSBUaGUgZWRpdG9yLWFjdGl2ZSBjb3VudGVycGFydDogcmV2ZWFsICsgZ2x5cGggKyBhbmNlc3RvciBkb3QgLS0tLS0tLS0tLS0tLVxuLy8gVGhlIGJ1ZyB0aGlzIGNvdmVyczogc3dpdGNoaW5nIGEgYC9wcmVzZW50Ly4uLmAgc2Vzc2lvbiB0byBlZGl0IG1vZGUgc2VlZHMgdGhlXG4vLyBlZGl0b3Igd2l0aCB0aGUgYXBwJ3MgRU5UUllQT0lOVCwgd2hpY2ggbGl2ZXMgdW5kZXIgYSBjb2xsYXBzZWQgZm9sZGVyIOKAlCBzbyB0aGVcbi8vIHRyZWUgc2hvd2VkIG5vdGhpbmcgYXQgYWxsIGFib3V0IHRoZSBmaWxlIGJlaW5nIGVkaXRlZC5cbmRlc2NyaWJlKFwiZWRpdG9yLWFjdGl2ZSByZXZlYWwgKyBtYXJrZXJcIiwgKCkgPT4ge1xuICBpdChcInRoZSBlZGl0b3IncyBhY3RpdmUgZmlsZSBpcyByZXZlYWxlZDogYW5jZXN0b3JzIGV4cGFuZCBhbmQgdGhlIHJvdyBzY3JvbGxzIGludG8gdmlld1wiLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3Qgc2Nyb2xsczogRWxlbWVudFtdID0gW107XG4gICAgY29uc3Qgb3JpZyA9IEVsZW1lbnQucHJvdG90eXBlLnNjcm9sbEludG9WaWV3O1xuICAgIEVsZW1lbnQucHJvdG90eXBlLnNjcm9sbEludG9WaWV3ID0gZnVuY3Rpb24gKCkge1xuICAgICAgc2Nyb2xscy5wdXNoKHRoaXMpO1xuICAgIH07XG4gICAgdHJ5IHtcbiAgICAgIGguYWN0aXZlRmlsZSA9IFwiL3NyYy9pbmRleC50c1wiO1xuICAgICAgcmVuZGVyKDxGaWxlRXhwbG9yZXIgLz4pO1xuICAgICAgYXdhaXQgc2NyZWVuLmZpbmRCeVRleHQoXCJzcmNcIik7XG4gICAgICBjb25zdCBiZWZvcmUgPSBkb2N1bWVudC5hY3RpdmVFbGVtZW50O1xuXG4gICAgICAvLyBObyBnZXN0dXJlLCBubyBtZXNzYWdlOiB0aGUgaG9zdCdzIGVkaXRvci1jb250ZXh0IHB1c2ggaXMgZW5vdWdoLlxuICAgICAgZXhwZWN0KGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KFwiaW5kZXgudHNcIikpLnRvQmVJblRoZURvY3VtZW50KCk7XG4gICAgICBleHBlY3Qoc2NyZWVuLmdldEJ5Um9sZShcInRyZWVpdGVtXCIsIHsgbmFtZTogXCJzcmNcIiB9KSkudG9IYXZlQXR0cmlidXRlKFxuICAgICAgICBcImFyaWEtZXhwYW5kZWRcIixcbiAgICAgICAgXCJ0cnVlXCIsXG4gICAgICApO1xuICAgICAgYXdhaXQgd2FpdEZvcigoKSA9PiBleHBlY3Qoc2Nyb2xscy5sZW5ndGgpLnRvQmVHcmVhdGVyVGhhbigwKSk7XG4gICAgICAvLyBSZXZlYWwgaXMgc2Nyb2xsLW9ubHkg4oCUIGZvY3VzIG5ldmVyIG1vdmVzLlxuICAgICAgZXhwZWN0KGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQpLnRvQmUoYmVmb3JlKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgRWxlbWVudC5wcm90b3R5cGUuc2Nyb2xsSW50b1ZpZXcgPSBvcmlnO1xuICAgIH1cbiAgfSk7XG5cbiAgaXQoXCJ0aGUgcmV2ZWFsZWQgcm93IGNhcnJpZXMgdGhlICdPcGVuIGluIHRoZSBlZGl0b3InIGdseXBoLCBhbmQgc2libGluZ3MgZG8gbm90XCIsIGFzeW5jICgpID0+IHtcbiAgICBoLmFjdGl2ZUZpbGUgPSBcIi9zcmMvaW5kZXgudHNcIjtcbiAgICByZW5kZXIoPEZpbGVFeHBsb3JlciAvPik7XG4gICAgYXdhaXQgc2NyZWVuLmZpbmRCeVRleHQoXCJ1dGlsLnRzXCIpOyAvLyB0aGUgd2hvbGUgb3BlbiBkaXJlY3RvcnkgcmVuZGVyZWRcbiAgICBjb25zdCBtYXJrcyA9IHNjcmVlbi5nZXRBbGxCeVJvbGUoXCJpbWdcIiwgeyBuYW1lOiBcIk9wZW4gaW4gdGhlIGVkaXRvclwiIH0pO1xuICAgIGV4cGVjdChtYXJrcykudG9IYXZlTGVuZ3RoKDEpO1xuICAgIGV4cGVjdChtYXJrc1swXS5jbG9zZXN0KFwiZGl2LnRub2RlXCIpKS50b0hhdmVDbGFzcyhcInRub2RlLS1hY3RpdmVcIik7XG4gICAgZXhwZWN0KG1hcmtzWzBdLmNsb3Nlc3QoXCJkaXYudG5vZGVcIikpLnRvQ29udGFpbkVsZW1lbnQoc2NyZWVuLmdldEJ5VGV4dChcImluZGV4LnRzXCIpKTtcbiAgfSk7XG5cbiAgaXQoXCJjb2xsYXBzaW5nIHRoZSBmb2xkZXIgbGVhdmVzIHRoZSBkaW1tZWQgYW5jZXN0b3IgZG90IOKAlCBhbmQgbmV2ZXIgcmUtb3BlbnMgaXRcIiwgYXN5bmMgKCkgPT4ge1xuICAgIGguYWN0aXZlRmlsZSA9IFwiL3NyYy9pbmRleC50c1wiO1xuICAgIGNvbnN0IHVzZXIgPSB1c2VyRXZlbnQuc2V0dXAoKTtcbiAgICByZW5kZXIoPEZpbGVFeHBsb3JlciAvPik7XG4gICAgYXdhaXQgc2NyZWVuLmZpbmRCeVRleHQoXCJpbmRleC50c1wiKTsgLy8gcmV2ZWFsZWRcblxuICAgIGF3YWl0IHVzZXIuY2xpY2soc2NyZWVuLmdldEJ5VGV4dChcInNyY1wiKSk7IC8vIHRoZSB1c2VyIGNsb3NlcyBpdCBhZ2FpblxuXG4gICAgZXhwZWN0KHNjcmVlbi5xdWVyeUJ5VGV4dChcImluZGV4LnRzXCIpKS5ub3QudG9CZUluVGhlRG9jdW1lbnQoKTtcbiAgICBleHBlY3QoXG4gICAgICBzY3JlZW4uZ2V0QnlSb2xlKFwiaW1nXCIsIHsgbmFtZTogXCJDb250YWlucyB0aGUgZmlsZSBvcGVuIGluIHRoZSBlZGl0b3JcIiB9KSxcbiAgICApLnRvQmVJblRoZURvY3VtZW50KCk7XG4gICAgLy8gRXhwYW5kLW9ubHk6IGEgZm9sZGVyIHRoZSB1c2VyIGNsb3NlZCBzdGF5cyBjbG9zZWQuXG4gICAgYXdhaXQgbmV3IFByb21pc2UoKHIpID0+IHNldFRpbWVvdXQociwgNDAwKSk7XG4gICAgZXhwZWN0KHNjcmVlbi5xdWVyeUJ5VGV4dChcImluZGV4LnRzXCIpKS5ub3QudG9CZUluVGhlRG9jdW1lbnQoKTtcbiAgfSk7XG5cbiAgaXQoXCJ0aGUgbW91bnRzIGFycml2aW5nIEFGVEVSIHRoZSBhY3RpdmUgZmlsZSBzdGlsbCByZXZlYWwgaXQgKHRoZSBsb2FkIHJhY2UpXCIsIGFzeW5jICgpID0+IHtcbiAgICAvLyBUaGUgcmVhbCBvcmRlcmluZyBvbiBhIGNvbGQgZWRpdC1tb2RlIGJvb3Q6IHRoZSBlZGl0b3ItY29udGV4dCBwdXNoIGNhbiBiZWF0XG4gICAgLy8gdGhlIG1vdW50IGxpc3QsIGFuZCBhIHJldmVhbCBhZ2FpbnN0IGFuIGVtcHR5IHJvb3Qgc2V0IGV4cGFuZHMgbm90aGluZy5cbiAgICBoLm1vdW50cyA9IFtdO1xuICAgIGguYWN0aXZlRmlsZSA9IFwiL3NyYy9pbmRleC50c1wiO1xuICAgIGNvbnN0IHsgcmVyZW5kZXIgfSA9IHJlbmRlcig8RmlsZUV4cGxvcmVyIC8+KTtcbiAgICBhd2FpdCBuZXcgUHJvbWlzZSgocikgPT4gc2V0VGltZW91dChyLCA1MCkpO1xuICAgIGV4cGVjdChzY3JlZW4ucXVlcnlCeVRleHQoXCJzcmNcIikpLm5vdC50b0JlSW5UaGVEb2N1bWVudCgpOyAvLyBubyByb290cyB5ZXRcblxuICAgIGgubW91bnRzID0gW3dvcmt0cmVlKCldO1xuICAgIHJlcmVuZGVyKDxGaWxlRXhwbG9yZXIgLz4pO1xuXG4gICAgZXhwZWN0KGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KFwiaW5kZXgudHNcIikpLnRvQmVJblRoZURvY3VtZW50KCk7XG4gICAgZXhwZWN0KHNjcmVlbi5nZXRCeVJvbGUoXCJ0cmVlaXRlbVwiLCB7IG5hbWU6IFwic3JjXCIgfSkpLnRvSGF2ZUF0dHJpYnV0ZShcbiAgICAgIFwiYXJpYS1leHBhbmRlZFwiLFxuICAgICAgXCJ0cnVlXCIsXG4gICAgKTtcbiAgfSk7XG5cbiAgaXQoXCJubyBhY3RpdmUgZmlsZSDihpIgbm8gbWFya2VyIGFuZCBubyByZXZlYWxcIiwgYXN5bmMgKCkgPT4ge1xuICAgIGguYWN0aXZlRmlsZSA9IG51bGw7XG4gICAgcmVuZGVyKDxGaWxlRXhwbG9yZXIgLz4pO1xuICAgIGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KFwic3JjXCIpO1xuICAgIGF3YWl0IG5ldyBQcm9taXNlKChyKSA9PiBzZXRUaW1lb3V0KHIsIDUwKSk7XG4gICAgZXhwZWN0KHNjcmVlbi5xdWVyeUJ5VGV4dChcImluZGV4LnRzXCIpKS5ub3QudG9CZUluVGhlRG9jdW1lbnQoKTtcbiAgICBleHBlY3Qoc2NyZWVuLnF1ZXJ5QnlSb2xlKFwiaW1nXCIsIHsgbmFtZTogXCJPcGVuIGluIHRoZSBlZGl0b3JcIiB9KSkubm90LnRvQmVJblRoZURvY3VtZW50KCk7XG4gICAgZXhwZWN0KFxuICAgICAgc2NyZWVuLnF1ZXJ5QnlSb2xlKFwiaW1nXCIsIHsgbmFtZTogXCJDb250YWlucyB0aGUgZmlsZSBvcGVuIGluIHRoZSBlZGl0b3JcIiB9KSxcbiAgICApLm5vdC50b0JlSW5UaGVEb2N1bWVudCgpO1xuICB9KTtcbn0pO1xuXG4vLyAtLS0gUjMtNjI2OiB0aGUgZmxhdCBsYXlvdXRzIHRha2Ugd2hhdCB0aGVpciByb3dzIGRlY2xpbmUgLS0tLS0tLS0tLS0tLS0tLS0tLVxuLy8gZmlsZS1leHBsb3JlciM0MCBnYXZlIHRoZSB0cmVlJ3Mgc2NvcGUgdGhlIGRyb3A7IGxpc3QsIGljb25zIGFuZCBjb2x1bW5zIHdlcmVcbi8vIGxlZnQgZGVhZCBvdXRzaWRlIGEgZGlyZWN0b3J5IHJvdy4gUGVyIGxheW91dDogYmxhbmsgc3BhY2Ug4oaSIGN3ZCAoY29sdW1uczpcbi8vIFRIQVQgY29sdW1uJ3MgZGlyZWN0b3J5IOKAlCB0aGUgc2Vjb25kLWNvbHVtbiBhc3NlcnRpb24gZmFpbHMgYW55IHZpZXctbGV2ZWxcbi8vIGZhbGxiYWNrKSwgYSBmaWxlIHJvdyDihpIgaXRzIHBhcmVudCwgYSBkaXJlY3Rvcnkgcm93IOKGkiBpdHNlbGYgZXhhY3RseSBvbmNlLFxuLy8gYW5kIHRoZSBvd25pbmcgY29udGFpbmVyIGxpZ2h0cyBgZGF0YS1kcmFnYC5cbmRlc2NyaWJlKFwiUjMtNjI2IOKAlCB0aGUgZmxhdCBsYXlvdXRzJyBjb250YWluZXJzIGFyZSB1cGxvYWQgZHJvcCB6b25lc1wiLCAoKSA9PiB7XG4gIGNvbnN0IG5vdGUgPSAoKSA9PiBuZXcgRmlsZShbXCJoZWxsb1wiXSwgXCJub3RlLnR4dFwiLCB7IHR5cGU6IFwidGV4dC9wbGFpblwiIH0pO1xuXG4gIGJlZm9yZUVhY2goKCkgPT4ge1xuICAgIC8vIFRoZSBsYXlvdXQgY2hvaWNlIHBlcnNpc3RzICh1c2VMYXlvdXQg4oaSIGxvY2FsU3RvcmFnZSk7IGVhY2ggY2FzZSBzdGFydHNcbiAgICAvLyBmcm9tIHRoZSB0cmVlIGRlZmF1bHQgc28gcmVuZGVyV2l0aFNyY0V4cGFuZGVkJ3MgZXhwYW5zaW9uIGFwcGxpZXMuXG4gICAgbG9jYWxTdG9yYWdlLmNsZWFyKCk7XG4gIH0pO1xuXG4gIGFzeW5jIGZ1bmN0aW9uIHRvTGF5b3V0KGxheW91dFRpcDogc3RyaW5nKSB7XG4gICAgY29uc3QgdXNlciA9IHVzZXJFdmVudC5zZXR1cCgpO1xuICAgIGF3YWl0IHJlbmRlcldpdGhTcmNFeHBhbmRlZCgpO1xuICAgIGF3YWl0IHVzZXIuY2xpY2soc2NyZWVuLmdldEJ5Um9sZShcInJhZGlvXCIsIHsgbmFtZTogbGF5b3V0VGlwIH0pKTtcbiAgICByZXR1cm4gdXNlcjtcbiAgfVxuXG4gIGl0KFwibGlzdDogYSBkcm9wIG9uIHRoZSBsYXlvdXQncyBibGFuayBzcGFjZSB1cGxvYWRzIGludG8gdGhlIGN3ZFwiLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgdXNlciA9IGF3YWl0IHRvTGF5b3V0KFwiTGlzdCB2aWV3XCIpO1xuICAgIGF3YWl0IHVzZXIuY2xpY2soYXdhaXQgc2NyZWVuLmZpbmRCeVRleHQoXCJyZXBvXCIpKTsgLy8gZW50ZXIgdGhlIG1vdW50IOKGkiBjd2QgL21udC9hYmNcbiAgICBhd2FpdCBzY3JlZW4uZmluZEJ5VGV4dChcInNyY1wiKTtcbiAgICBjb25zdCBsYXlvdXQgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiLmxheW91dC0tbGlzdFwiKSBhcyBIVE1MRWxlbWVudDtcbiAgICBmaXJlRXZlbnQuZHJvcChsYXlvdXQsIHsgZGF0YVRyYW5zZmVyOiBkYXRhVHJhbnNmZXIoeyBmaWxlczogW25vdGUoKV0gfSkgfSk7XG4gICAgYXdhaXQgdmkud2FpdEZvcigoKSA9PiBleHBlY3QoaC51cGxvYWRGaWxlKS50b0hhdmVCZWVuQ2FsbGVkKCkpO1xuICAgIGV4cGVjdChoLnVwbG9hZEZpbGUubW9jay5jYWxsc1swXVswXSkudG9CZShcIi9ub3RlLnR4dFwiKTtcbiAgfSk7XG5cbiAgaXQoXCJsaXN0OiBhIGRyb3Agb24gYSBmaWxlIHJvdyB1cGxvYWRzIGludG8gdGhlIGRpcmVjdG9yeSBob2xkaW5nIGl0XCIsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCB1c2VyID0gYXdhaXQgdG9MYXlvdXQoXCJMaXN0IHZpZXdcIik7XG4gICAgYXdhaXQgdXNlci5jbGljayhhd2FpdCBzY3JlZW4uZmluZEJ5VGV4dChcInJlcG9cIikpO1xuICAgIGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KFwic3JjXCIpO1xuICAgIGF3YWl0IHVzZXIuY2xpY2soc2NyZWVuLmdldEJ5VGV4dChcInNyY1wiKSk7XG4gICAgYXdhaXQgc2NyZWVuLmZpbmRCeVRleHQoXCJpbmRleC50c1wiKTtcbiAgICBjb25zdCByb3cgPSBzY3JlZW4uZ2V0QnlUZXh0KFwiaW5kZXgudHNcIikuY2xvc2VzdChcIltkYXRhLXBhdGhdXCIpIGFzIEhUTUxFbGVtZW50O1xuICAgIGZpcmVFdmVudC5kcm9wKHJvdywgeyBkYXRhVHJhbnNmZXI6IGRhdGFUcmFuc2Zlcih7IGZpbGVzOiBbbm90ZSgpXSB9KSB9KTtcbiAgICBhd2FpdCB2aS53YWl0Rm9yKCgpID0+IGV4cGVjdChoLnVwbG9hZEZpbGUpLnRvSGF2ZUJlZW5DYWxsZWQoKSk7XG4gICAgZXhwZWN0KGgudXBsb2FkRmlsZS5tb2NrLmNhbGxzWzBdWzBdKS50b0JlKFwiL3NyYy9ub3RlLnR4dFwiKTtcbiAgfSk7XG5cbiAgaXQoXCJsaXN0OiBhIGRpcmVjdG9yeS1yb3cgZHJvcCBzdGlsbCBsYW5kcyBvbmNlLCBpbiB0aGF0IGRpcmVjdG9yeVwiLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgdXNlciA9IGF3YWl0IHRvTGF5b3V0KFwiTGlzdCB2aWV3XCIpO1xuICAgIGF3YWl0IHVzZXIuY2xpY2soYXdhaXQgc2NyZWVuLmZpbmRBbGxCeVRleHQoXCJyZXBvXCIpWzBdKTtcbiAgICBhd2FpdCBzY3JlZW4uZmluZEFsbEJ5VGV4dChcInNyY1wiKTtcbiAgICBjb25zdCByb3cgPSBzY3JlZW4uZ2V0QWxsQnlUZXh0KFwic3JjXCIpWzBdLmNsb3Nlc3QoXCJbZGF0YS1wYXRoXVwiKSBhcyBIVE1MRWxlbWVudDtcbiAgICBmaXJlRXZlbnQuZHJvcChyb3csIHsgZGF0YVRyYW5zZmVyOiBkYXRhVHJhbnNmZXIoeyBmaWxlczogW25vdGUoKV0gfSkgfSk7XG4gICAgYXdhaXQgdmkud2FpdEZvcigoKSA9PiBleHBlY3QoaC51cGxvYWRGaWxlKS50b0hhdmVCZWVuQ2FsbGVkKCkpO1xuICAgIGV4cGVjdChoLnVwbG9hZEZpbGUpLnRvSGF2ZUJlZW5DYWxsZWRUaW1lcygxKTtcbiAgICBleHBlY3QoaC51cGxvYWRGaWxlLm1vY2suY2FsbHNbMF1bMF0pLnRvQmUoXCIvc3JjL25vdGUudHh0XCIpO1xuICB9KTtcblxuICBpdChcImljb25zOiBhIGRpcmVjdG9yeS1yb3cgZHJvcCBzdGlsbCBsYW5kcyBvbmNlLCBpbiB0aGF0IGRpcmVjdG9yeVwiLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgdXNlciA9IGF3YWl0IHRvTGF5b3V0KFwiSWNvbiB2aWV3XCIpO1xuICAgIGF3YWl0IHVzZXIuY2xpY2soYXdhaXQgc2NyZWVuLmZpbmRBbGxCeVRleHQoXCJyZXBvXCIpWzBdKTtcbiAgICBhd2FpdCBzY3JlZW4uZmluZEFsbEJ5VGV4dChcInNyY1wiKTtcbiAgICBjb25zdCByb3cgPSBzY3JlZW4uZ2V0QWxsQnlUZXh0KFwic3JjXCIpWzBdLmNsb3Nlc3QoXCJbZGF0YS1wYXRoXVwiKSBhcyBIVE1MRWxlbWVudDtcbiAgICBmaXJlRXZlbnQuZHJvcChyb3csIHsgZGF0YVRyYW5zZmVyOiBkYXRhVHJhbnNmZXIoeyBmaWxlczogW25vdGUoKV0gfSkgfSk7XG4gICAgYXdhaXQgdmkud2FpdEZvcigoKSA9PiBleHBlY3QoaC51cGxvYWRGaWxlKS50b0hhdmVCZWVuQ2FsbGVkKCkpO1xuICAgIGV4cGVjdChoLnVwbG9hZEZpbGUpLnRvSGF2ZUJlZW5DYWxsZWRUaW1lcygxKTtcbiAgICBleHBlY3QoaC51cGxvYWRGaWxlLm1vY2suY2FsbHNbMF1bMF0pLnRvQmUoXCIvc3JjL25vdGUudHh0XCIpO1xuICB9KTtcblxuICBpdChcImNvbHVtbnM6IGEgZGlyZWN0b3J5LXJvdyBkcm9wIHN0aWxsIGxhbmRzIG9uY2UsIGluIHRoYXQgZGlyZWN0b3J5XCIsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCB1c2VyID0gYXdhaXQgdG9MYXlvdXQoXCJDb2x1bW4gdmlld1wiKTtcbiAgICBhd2FpdCB1c2VyLmNsaWNrKGF3YWl0IHNjcmVlbi5maW5kQWxsQnlUZXh0KFwicmVwb1wiKVswXSk7IC8vIGNvbHVtbiAxID0gL21udC9hYmNcbiAgICBhd2FpdCBzY3JlZW4uZmluZEFsbEJ5VGV4dChcInNyY1wiKTtcbiAgICBjb25zdCByb3cgPSBzY3JlZW4uZ2V0QWxsQnlUZXh0KFwic3JjXCIpWzBdLmNsb3Nlc3QoXCJbZGF0YS1wYXRoXVwiKSBhcyBIVE1MRWxlbWVudDtcbiAgICBmaXJlRXZlbnQuZHJvcChyb3csIHsgZGF0YVRyYW5zZmVyOiBkYXRhVHJhbnNmZXIoeyBmaWxlczogW25vdGUoKV0gfSkgfSk7XG4gICAgYXdhaXQgdmkud2FpdEZvcigoKSA9PiBleHBlY3QoaC51cGxvYWRGaWxlKS50b0hhdmVCZWVuQ2FsbGVkKCkpO1xuICAgIGV4cGVjdChoLnVwbG9hZEZpbGUpLnRvSGF2ZUJlZW5DYWxsZWRUaW1lcygxKTtcbiAgICBleHBlY3QoaC51cGxvYWRGaWxlLm1vY2suY2FsbHNbMF1bMF0pLnRvQmUoXCIvc3JjL25vdGUudHh0XCIpO1xuICB9KTtcblxuICBpdChcImxpc3Q6IGEgZHJvcCBhIGRpcmVjdG9yeSByb3cgdGFrZXMgY2xlYXJzIHRoZSBhZmZvcmRhbmNlIHRoZSBob3ZlciBsaXRcIiwgYXN5bmMgKCkgPT4ge1xuICAgIC8vIFRoZSByb3cncyBvbkRyb3Agc3RvcHMgcHJvcGFnYXRpb24sIHNvIHRoZSBjb250YWluZXIncyBvbkRyb3AgbmV2ZXIgcnVucyDigJRcbiAgICAvLyBvbmx5IHRoZSBjYXB0dXJlLXBoYXNlIGNsZWFyIHVuLWxpZ2h0cyB0aGUgY29udGFpbmVyIGhlcmUuXG4gICAgY29uc3QgdXNlciA9IGF3YWl0IHRvTGF5b3V0KFwiTGlzdCB2aWV3XCIpO1xuICAgIGF3YWl0IHVzZXIuY2xpY2soYXdhaXQgc2NyZWVuLmZpbmRBbGxCeVRleHQoXCJyZXBvXCIpWzBdKTtcbiAgICBhd2FpdCBzY3JlZW4uZmluZEFsbEJ5VGV4dChcInNyY1wiKTtcbiAgICBjb25zdCBsYXlvdXQgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiLmxheW91dC0tbGlzdFwiKSBhcyBIVE1MRWxlbWVudDtcbiAgICBjb25zdCByb3cgPSBzY3JlZW4uZ2V0QWxsQnlUZXh0KFwic3JjXCIpWzBdLmNsb3Nlc3QoXCJbZGF0YS1wYXRoXVwiKSBhcyBIVE1MRWxlbWVudDtcbiAgICBmaXJlRXZlbnQuZHJhZ092ZXIobGF5b3V0LCB7IGRhdGFUcmFuc2ZlcjogZGF0YVRyYW5zZmVyKHsgZmlsZXM6IFtub3RlKCldIH0pIH0pO1xuICAgIGV4cGVjdChsYXlvdXQuZ2V0QXR0cmlidXRlKFwiZGF0YS1kcmFnXCIpKS50b0JlKFwiMVwiKTtcbiAgICBmaXJlRXZlbnQuZHJvcChyb3csIHsgZGF0YVRyYW5zZmVyOiBkYXRhVHJhbnNmZXIoeyBmaWxlczogW25vdGUoKV0gfSkgfSk7XG4gICAgYXdhaXQgdmkud2FpdEZvcigoKSA9PiBleHBlY3QoaC51cGxvYWRGaWxlKS50b0hhdmVCZWVuQ2FsbGVkKCkpO1xuICAgIGV4cGVjdChoLnVwbG9hZEZpbGUpLnRvSGF2ZUJlZW5DYWxsZWRUaW1lcygxKTtcbiAgICBleHBlY3QobGF5b3V0LmdldEF0dHJpYnV0ZShcImRhdGEtZHJhZ1wiKSkudG9CZShudWxsKTtcbiAgfSk7XG5cbiAgaXQoXCJsaXN0OiB0aGUgbGF5b3V0IGxpZ2h0cyBhbmQgY2xlYXJzIGRhdGEtZHJhZ1wiLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgdXNlciA9IGF3YWl0IHRvTGF5b3V0KFwiTGlzdCB2aWV3XCIpO1xuICAgIGF3YWl0IHVzZXIuY2xpY2soYXdhaXQgc2NyZWVuLmZpbmRCeVRleHQoXCJyZXBvXCIpKTtcbiAgICBhd2FpdCBzY3JlZW4uZmluZEJ5VGV4dChcInNyY1wiKTtcbiAgICBjb25zdCBsYXlvdXQgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiLmxheW91dC0tbGlzdFwiKSBhcyBIVE1MRWxlbWVudDtcbiAgICBleHBlY3QobGF5b3V0LmdldEF0dHJpYnV0ZShcImRhdGEtZHJhZ1wiKSkudG9CZShudWxsKTtcbiAgICBmaXJlRXZlbnQuZHJhZ092ZXIobGF5b3V0LCB7IGRhdGFUcmFuc2ZlcjogZGF0YVRyYW5zZmVyKHsgZmlsZXM6IFtub3RlKCldIH0pIH0pO1xuICAgIGV4cGVjdChsYXlvdXQuZ2V0QXR0cmlidXRlKFwiZGF0YS1kcmFnXCIpKS50b0JlKFwiMVwiKTtcbiAgICBmaXJlRXZlbnQuZHJhZ0xlYXZlKGxheW91dCwgeyByZWxhdGVkVGFyZ2V0OiBkb2N1bWVudC5ib2R5IH0pO1xuICAgIGV4cGVjdChsYXlvdXQuZ2V0QXR0cmlidXRlKFwiZGF0YS1kcmFnXCIpKS50b0JlKG51bGwpO1xuICB9KTtcblxuICBpdChcImljb25zOiBhIGRyb3Agb24gdGhlIGxheW91dCdzIGJsYW5rIHNwYWNlIHVwbG9hZHMgaW50byB0aGUgY3dkXCIsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCB1c2VyID0gYXdhaXQgdG9MYXlvdXQoXCJJY29uIHZpZXdcIik7XG4gICAgYXdhaXQgdXNlci5jbGljayhhd2FpdCBzY3JlZW4uZmluZEJ5VGV4dChcInJlcG9cIikpO1xuICAgIGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KFwic3JjXCIpO1xuICAgIGNvbnN0IGxheW91dCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIubGF5b3V0LS1pY29uc1wiKSBhcyBIVE1MRWxlbWVudDtcbiAgICBmaXJlRXZlbnQuZHJvcChsYXlvdXQsIHsgZGF0YVRyYW5zZmVyOiBkYXRhVHJhbnNmZXIoeyBmaWxlczogW25vdGUoKV0gfSkgfSk7XG4gICAgYXdhaXQgdmkud2FpdEZvcigoKSA9PiBleHBlY3QoaC51cGxvYWRGaWxlKS50b0hhdmVCZWVuQ2FsbGVkKCkpO1xuICAgIGV4cGVjdChoLnVwbG9hZEZpbGUubW9jay5jYWxsc1swXVswXSkudG9CZShcIi9ub3RlLnR4dFwiKTtcbiAgfSk7XG5cbiAgaXQoXCJpY29uczogYSBkcm9wIG9uIGEgZmlsZSByb3cgdXBsb2FkcyBpbnRvIHRoZSBkaXJlY3RvcnkgaG9sZGluZyBpdFwiLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgdXNlciA9IGF3YWl0IHRvTGF5b3V0KFwiSWNvbiB2aWV3XCIpO1xuICAgIGF3YWl0IHVzZXIuY2xpY2soYXdhaXQgc2NyZWVuLmZpbmRCeVRleHQoXCJyZXBvXCIpKTtcbiAgICBhd2FpdCBzY3JlZW4uZmluZEJ5VGV4dChcInNyY1wiKTtcbiAgICBhd2FpdCB1c2VyLmNsaWNrKHNjcmVlbi5nZXRCeVRleHQoXCJzcmNcIikpO1xuICAgIGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KFwiaW5kZXgudHNcIik7XG4gICAgY29uc3Qgcm93ID0gc2NyZWVuLmdldEJ5VGV4dChcImluZGV4LnRzXCIpLmNsb3Nlc3QoXCJbZGF0YS1wYXRoXVwiKSBhcyBIVE1MRWxlbWVudDtcbiAgICBmaXJlRXZlbnQuZHJvcChyb3csIHsgZGF0YVRyYW5zZmVyOiBkYXRhVHJhbnNmZXIoeyBmaWxlczogW25vdGUoKV0gfSkgfSk7XG4gICAgYXdhaXQgdmkud2FpdEZvcigoKSA9PiBleHBlY3QoaC51cGxvYWRGaWxlKS50b0hhdmVCZWVuQ2FsbGVkKCkpO1xuICAgIGV4cGVjdChoLnVwbG9hZEZpbGUubW9jay5jYWxsc1swXVswXSkudG9CZShcIi9zcmMvbm90ZS50eHRcIik7XG4gIH0pO1xuXG4gIGl0KFwiaWNvbnM6IHRoZSBsYXlvdXQgbGlnaHRzIGFuZCBjbGVhcnMgZGF0YS1kcmFnXCIsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCB1c2VyID0gYXdhaXQgdG9MYXlvdXQoXCJJY29uIHZpZXdcIik7XG4gICAgYXdhaXQgdXNlci5jbGljayhhd2FpdCBzY3JlZW4uZmluZEJ5VGV4dChcInJlcG9cIikpO1xuICAgIGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KFwic3JjXCIpO1xuICAgIGNvbnN0IGxheW91dCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIubGF5b3V0LS1pY29uc1wiKSBhcyBIVE1MRWxlbWVudDtcbiAgICBleHBlY3QobGF5b3V0LmdldEF0dHJpYnV0ZShcImRhdGEtZHJhZ1wiKSkudG9CZShudWxsKTtcbiAgICBmaXJlRXZlbnQuZHJhZ092ZXIobGF5b3V0LCB7IGRhdGFUcmFuc2ZlcjogZGF0YVRyYW5zZmVyKHsgZmlsZXM6IFtub3RlKCldIH0pIH0pO1xuICAgIGV4cGVjdChsYXlvdXQuZ2V0QXR0cmlidXRlKFwiZGF0YS1kcmFnXCIpKS50b0JlKFwiMVwiKTtcbiAgICBmaXJlRXZlbnQuZHJhZ0xlYXZlKGxheW91dCwgeyByZWxhdGVkVGFyZ2V0OiBkb2N1bWVudC5ib2R5IH0pO1xuICAgIGV4cGVjdChsYXlvdXQuZ2V0QXR0cmlidXRlKFwiZGF0YS1kcmFnXCIpKS50b0JlKG51bGwpO1xuICB9KTtcblxuICBpdChcImNvbHVtbnM6IGEgZHJvcCBpbiB0aGUgU0VDT05EIGNvbHVtbidzIGJsYW5rIHNwYWNlIHVwbG9hZHMgaW50byBUSEFUIGNvbHVtbidzIGRpcmVjdG9yeVwiLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgdXNlciA9IGF3YWl0IHRvTGF5b3V0KFwiQ29sdW1uIHZpZXdcIik7XG4gICAgYXdhaXQgdXNlci5jbGljayhhd2FpdCBzY3JlZW4uZmluZEJ5VGV4dChcInJlcG9cIikpOyAvLyBjb2x1bW4gMSA9IC9tbnQvYWJjXG4gICAgYXdhaXQgc2NyZWVuLmZpbmRCeVRleHQoXCJzcmNcIik7XG4gICAgYXdhaXQgdXNlci5jbGljayhzY3JlZW4uZ2V0QnlUZXh0KFwic3JjXCIpKTsgLy8gY29sdW1uIDIgPSAvbW50L2FiYy9zcmNcbiAgICBhd2FpdCBzY3JlZW4uZmluZEJ5VGV4dChcImluZGV4LnRzXCIpO1xuICAgIGNvbnN0IGNvbDEgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCdbZGF0YS1jb2w9XCIxXCJdJykgYXMgSFRNTEVsZW1lbnQ7XG4gICAgZmlyZUV2ZW50LmRyb3AoY29sMSwgeyBkYXRhVHJhbnNmZXI6IGRhdGFUcmFuc2Zlcih7IGZpbGVzOiBbbm90ZSgpXSB9KSB9KTtcbiAgICBhd2FpdCB2aS53YWl0Rm9yKCgpID0+IGV4cGVjdChoLnVwbG9hZEZpbGUpLnRvSGF2ZUJlZW5DYWxsZWQoKSk7XG4gICAgLy8gQSB2aWV3LWxldmVsIGZhbGxiYWNrICh0aGUgZGVlcGVzdCBvcGVuIHBhdGgsIC9tbnQvYWJjL3NyYykgZmFpbHMgdGhpcy5cbiAgICBleHBlY3QoaC51cGxvYWRGaWxlLm1vY2suY2FsbHNbMF1bMF0pLnRvQmUoXCIvbm90ZS50eHRcIik7XG4gIH0pO1xuXG4gIGl0KFwiY29sdW1uczogYSBkcm9wIG9uIGEgZmlsZSByb3cgdXBsb2FkcyBpbnRvIHRoZSBkaXJlY3RvcnkgaG9sZGluZyBpdFwiLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgdXNlciA9IGF3YWl0IHRvTGF5b3V0KFwiQ29sdW1uIHZpZXdcIik7XG4gICAgYXdhaXQgdXNlci5jbGljayhhd2FpdCBzY3JlZW4uZmluZEJ5VGV4dChcInJlcG9cIikpO1xuICAgIGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KFwic3JjXCIpO1xuICAgIGF3YWl0IHVzZXIuY2xpY2soc2NyZWVuLmdldEJ5VGV4dChcInNyY1wiKSk7XG4gICAgYXdhaXQgc2NyZWVuLmZpbmRCeVRleHQoXCJpbmRleC50c1wiKTtcbiAgICBjb25zdCByb3cgPSBzY3JlZW4uZ2V0QnlUZXh0KFwiaW5kZXgudHNcIikuY2xvc2VzdChcIltkYXRhLXBhdGhdXCIpIGFzIEhUTUxFbGVtZW50O1xuICAgIGZpcmVFdmVudC5kcm9wKHJvdywgeyBkYXRhVHJhbnNmZXI6IGRhdGFUcmFuc2Zlcih7IGZpbGVzOiBbbm90ZSgpXSB9KSB9KTtcbiAgICBhd2FpdCB2aS53YWl0Rm9yKCgpID0+IGV4cGVjdChoLnVwbG9hZEZpbGUpLnRvSGF2ZUJlZW5DYWxsZWQoKSk7XG4gICAgZXhwZWN0KGgudXBsb2FkRmlsZS5tb2NrLmNhbGxzWzBdWzBdKS50b0JlKFwiL3NyYy9ub3RlLnR4dFwiKTtcbiAgfSk7XG5cbiAgaXQoXCJjb2x1bW5zOiB0aGUgbGFuZGVkIGNvbHVtbiBsaWdodHMgZGF0YS1kcmFnLCBhbmQgb25seSBpdFwiLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgdXNlciA9IGF3YWl0IHRvTGF5b3V0KFwiQ29sdW1uIHZpZXdcIik7XG4gICAgYXdhaXQgdXNlci5jbGljayhhd2FpdCBzY3JlZW4uZmluZEJ5VGV4dChcInJlcG9cIikpO1xuICAgIGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KFwic3JjXCIpO1xuICAgIGF3YWl0IHVzZXIuY2xpY2soc2NyZWVuLmdldEJ5VGV4dChcInNyY1wiKSk7XG4gICAgYXdhaXQgc2NyZWVuLmZpbmRCeVRleHQoXCJpbmRleC50c1wiKTtcbiAgICBjb25zdCBjb2wxID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignW2RhdGEtY29sPVwiMVwiXScpIGFzIEhUTUxFbGVtZW50O1xuICAgIGNvbnN0IGNvbDIgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCdbZGF0YS1jb2w9XCIyXCJdJykgYXMgSFRNTEVsZW1lbnQ7XG4gICAgZXhwZWN0KGNvbDEuZ2V0QXR0cmlidXRlKFwiZGF0YS1kcmFnXCIpKS50b0JlKG51bGwpO1xuICAgIGV4cGVjdChjb2wyLmdldEF0dHJpYnV0ZShcImRhdGEtZHJhZ1wiKSkudG9CZShudWxsKTtcbiAgICBmaXJlRXZlbnQuZHJhZ092ZXIoY29sMiwgeyBkYXRhVHJhbnNmZXI6IGRhdGFUcmFuc2Zlcih7IGZpbGVzOiBbbm90ZSgpXSB9KSB9KTtcbiAgICBleHBlY3QoY29sMi5nZXRBdHRyaWJ1dGUoXCJkYXRhLWRyYWdcIikpLnRvQmUoXCIxXCIpO1xuICAgIGV4cGVjdChjb2wxLmdldEF0dHJpYnV0ZShcImRhdGEtZHJhZ1wiKSkudG9CZShudWxsKTtcbiAgICBmaXJlRXZlbnQuZHJhZ0xlYXZlKGNvbDIsIHsgcmVsYXRlZFRhcmdldDogZG9jdW1lbnQuYm9keSB9KTtcbiAgICBleHBlY3QoY29sMi5nZXRBdHRyaWJ1dGUoXCJkYXRhLWRyYWdcIikpLnRvQmUobnVsbCk7XG4gIH0pO1xuXG4gIGl0KFwiYSBudWxsIGN3ZCAodGhlIHJvb3RzLXJvb3QpIGFjY2VwdHMgbm90aGluZzogdGhlcmUgaXMgbm8gZGlyZWN0b3J5IHRvIGZhbGwgYmFjayB0b1wiLCBhc3luYyAoKSA9PiB7XG4gICAgLy8gV2l0aCBOTyBzZWxlY3Rpb24gYW5kIFRXTyBtb3VudHMsIGNob29zZUxheW91dChcImxpc3RcIikgc2VlZHMgY3dkID0gbnVsbFxuICAgIC8vICh0aGUgcm9vdHMtcm9vdCksIHdoZXJlIHRoZSBjb250YWluZXIgaGFzIG5vIGRpcmVjdG9yeSB0byBvZmZlciBhbmQgbXVzdFxuICAgIC8vIGFjY2VwdCBub3RoaW5nIGF0IGFsbC4gU286IG5vIHJlbmRlcldpdGhTcmNFeHBhbmRlZCAoaXRzIGNsaWNrIHNlbGVjdHMpLlxuICAgIGNvbnN0IHVzZXIgPSB1c2VyRXZlbnQuc2V0dXAoKTtcbiAgICBoLm1vdW50cyA9IFt3b3JrdHJlZShcInIxXCIpLCB7IHR5cGU6IFwid29ya3RyZWVcIiwgcGF0aDogXCIvbW50L3h5elwiLCBpZDogXCJyMlwiIH1dO1xuICAgIHJlbmRlcig8RmlsZUV4cGxvcmVyIC8+KTtcbiAgICBhd2FpdCBzY3JlZW4uZmluZEFsbEJ5VGV4dChcInIxXCIpOyAvLyB0aGUgdHJlZSByZW5kZXJzIGJvdGggbW91bnQgc2NvcGVzXG4gICAgYXdhaXQgdXNlci5jbGljayhzY3JlZW4uZ2V0QnlSb2xlKFwicmFkaW9cIiwgeyBuYW1lOiBcIkxpc3Qgdmlld1wiIH0pKTtcbiAgICBhd2FpdCBzY3JlZW4uZmluZEFsbEJ5VGV4dChcInIyXCIpOyAvLyB0aGUgcm9vdHMtcm9vdCBsaXN0cyBib3RoIG1vdW50c1xuICAgIGNvbnN0IGxheW91dCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIubGF5b3V0LS1saXN0XCIpIGFzIEhUTUxFbGVtZW50O1xuICAgIGZpcmVFdmVudC5kcmFnT3ZlcihsYXlvdXQsIHsgZGF0YVRyYW5zZmVyOiBkYXRhVHJhbnNmZXIoeyBmaWxlczogW25vdGUoKV0gfSkgfSk7XG4gICAgZXhwZWN0KGxheW91dC5nZXRBdHRyaWJ1dGUoXCJkYXRhLWRyYWdcIikpLnRvQmUobnVsbCk7XG4gICAgZmlyZUV2ZW50LmRyb3AobGF5b3V0LCB7IGRhdGFUcmFuc2ZlcjogZGF0YVRyYW5zZmVyKHsgZmlsZXM6IFtub3RlKCldIH0pIH0pO1xuICAgIGV4cGVjdChoLnVwbG9hZEZpbGUpLm5vdC50b0hhdmVCZWVuQ2FsbGVkKCk7XG4gIH0pO1xuXG4gIGl0KFwibGlzdDogYW4gaW50ZXJuYWwgTU9WRSBkcmFnIGlzIG5vdCB0YWtlbiBieSB0aGUgZmxhdCBjb250YWluZXJcIiwgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHVzZXIgPSBhd2FpdCB0b0xheW91dChcIkxpc3Qgdmlld1wiKTtcbiAgICBhd2FpdCB1c2VyLmNsaWNrKGF3YWl0IHNjcmVlbi5maW5kQWxsQnlUZXh0KFwicmVwb1wiKVswXSk7XG4gICAgYXdhaXQgc2NyZWVuLmZpbmRBbGxCeVRleHQoXCJzcmNcIik7XG4gICAgY29uc3QgbGF5b3V0ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIi5sYXlvdXQtLWxpc3RcIikgYXMgSFRNTEVsZW1lbnQ7XG4gICAgY29uc3QgbW92ZSA9IGRhdGFUcmFuc2Zlcih7IG1vdmU6IEpTT04uc3RyaW5naWZ5KHsgZnJvbTogXCIvbW50L2FiYy9SRUFETUUubWRcIiwgcm9vdFBhdGg6IFwiL21udC9hYmNcIiB9KSB9KTtcbiAgICBmaXJlRXZlbnQuZHJhZ092ZXIobGF5b3V0LCB7IGRhdGFUcmFuc2ZlcjogbW92ZSB9KTtcbiAgICBleHBlY3QobGF5b3V0LmdldEF0dHJpYnV0ZShcImRhdGEtZHJhZ1wiKSkudG9CZShudWxsKTtcbiAgICBmaXJlRXZlbnQuZHJvcChsYXlvdXQsIHsgZGF0YVRyYW5zZmVyOiBtb3ZlIH0pO1xuICAgIGV4cGVjdChoLnVwbG9hZEZpbGUpLm5vdC50b0hhdmVCZWVuQ2FsbGVkKCk7XG4gICAgZXhwZWN0KGgucmVuYW1lRW50cnkpLm5vdC50b0hhdmVCZWVuQ2FsbGVkKCk7XG4gIH0pO1xuXG4gIGl0KFwiYSByZWFkLW9ubHkgbW91bnQncyBmbGF0IGNvbnRhaW5lciBhY2NlcHRzIG5vdGhpbmdcIiwgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHVzZXIgPSB1c2VyRXZlbnQuc2V0dXAoKTtcbiAgICBoLm1vdW50cyA9IFtzcGFjZSgpXTsgLy8gbW9kZSBcInJvXCJcbiAgICByZW5kZXIoPEZpbGVFeHBsb3JlciAvPik7XG4gICAgYXdhaXQgc2NyZWVuLmZpbmRBbGxCeVRleHQoXCJTaGFyZWQgbm90ZXNcIik7XG4gICAgYXdhaXQgdXNlci5jbGljayhzY3JlZW4uZ2V0QnlSb2xlKFwicmFkaW9cIiwgeyBuYW1lOiBcIkxpc3Qgdmlld1wiIH0pKTtcbiAgICBhd2FpdCBzY3JlZW4uZmluZEFsbEJ5VGV4dChcIlNoYXJlZCBub3Rlc1wiKTsgLy8gdGhlIGN3ZCBzZWVkZWQgdG8gdGhlIHNwYWNlIHJvb3RcbiAgICBjb25zdCBsYXlvdXQgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiLmxheW91dC0tbGlzdFwiKSBhcyBIVE1MRWxlbWVudDtcbiAgICBmaXJlRXZlbnQuZHJhZ092ZXIobGF5b3V0LCB7IGRhdGFUcmFuc2ZlcjogZGF0YVRyYW5zZmVyKHsgZmlsZXM6IFtub3RlKCldIH0pIH0pO1xuICAgIGV4cGVjdChsYXlvdXQuZ2V0QXR0cmlidXRlKFwiZGF0YS1kcmFnXCIpKS50b0JlKG51bGwpO1xuICAgIGZpcmVFdmVudC5kcm9wKGxheW91dCwgeyBkYXRhVHJhbnNmZXI6IGRhdGFUcmFuc2Zlcih7IGZpbGVzOiBbbm90ZSgpXSB9KSB9KTtcbiAgICBleHBlY3QoaC51cGxvYWRGaWxlKS5ub3QudG9IYXZlQmVlbkNhbGxlZCgpO1xuICB9KTtcblxuICBpdChcInRoZSB0cmVlIHNjb3BlOiBhIGRyb3AgYSBkaXJlY3Rvcnkgcm93IHRha2VzIGNsZWFycyB0aGUgYWZmb3JkYW5jZSB0aGUgaG92ZXIgbGl0XCIsIGFzeW5jICgpID0+IHtcbiAgICAvLyBUaGUgc2FtZSBjYXB0dXJlLWNsZWFyLCBvbiB0aGUgdHJlZSdzIHNjb3BlIOKAlCBpdHMgcm93cyBzdG9wUHJvcGFnYXRpb24gb25cbiAgICAvLyBkcm9wLCBzbyB3aXRob3V0IHRoZSBjYXB0dXJlIGhhbmRsZXIgZGF0YS1kcmFnIHdvdWxkIHN0aWNrIGhlcmUgdG9vLlxuICAgIGF3YWl0IHJlbmRlcldpdGhTcmNFeHBhbmRlZCgpO1xuICAgIGNvbnN0IHNjb3BlID0gc2NyZWVuLmdldEJ5VGV4dChcInNyY1wiKS5jbG9zZXN0KFwiLm1vdW50XCIpIGFzIEhUTUxFbGVtZW50O1xuICAgIGNvbnN0IHJvdyA9IHNjcmVlbi5nZXRCeVRleHQoXCJzcmNcIikuY2xvc2VzdChcIi50bm9kZVwiKSBhcyBIVE1MRWxlbWVudDtcbiAgICBmaXJlRXZlbnQuZHJhZ092ZXIoc2NvcGUsIHsgZGF0YVRyYW5zZmVyOiBkYXRhVHJhbnNmZXIoeyBmaWxlczogW25vdGUoKV0gfSkgfSk7XG4gICAgZXhwZWN0KHNjb3BlLmdldEF0dHJpYnV0ZShcImRhdGEtZHJhZ1wiKSkudG9CZShcIjFcIik7XG4gICAgZmlyZUV2ZW50LmRyb3Aocm93LCB7IGRhdGFUcmFuc2ZlcjogZGF0YVRyYW5zZmVyKHsgZmlsZXM6IFtub3RlKCldIH0pIH0pO1xuICAgIGF3YWl0IHZpLndhaXRGb3IoKCkgPT4gZXhwZWN0KGgudXBsb2FkRmlsZSkudG9IYXZlQmVlbkNhbGxlZCgpKTtcbiAgICBleHBlY3QoaC51cGxvYWRGaWxlKS50b0hhdmVCZWVuQ2FsbGVkVGltZXMoMSk7XG4gICAgZXhwZWN0KHNjb3BlLmdldEF0dHJpYnV0ZShcImRhdGEtZHJhZ1wiKSkudG9CZShudWxsKTtcbiAgfSk7XG59KTtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7QUFVQSxJQUFBQSxNQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxVQUFBLEdBQUFDLHNCQUFBLENBQUFGLE9BQUE7QUFDQSxJQUFBRyxPQUFBLEdBQUFILE9BQUE7QUE0R0EsSUFBQUksZ0JBQUEsR0FBQUYsc0JBQUEsQ0FBQUYsT0FBQTtBQUE2QyxJQUFBSyxXQUFBLEdBQUFMLE9BQUE7QUFBQSxTQUFBRSx1QkFBQUksQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQXhIN0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBTUE7QUFDQSxNQUFNRyxJQUFnQyxHQUFHO0VBQ3ZDLFVBQVUsRUFBRSxDQUNWO0lBQUVDLElBQUksRUFBRSxLQUFLO0lBQUVDLEtBQUssRUFBRTtFQUFLLENBQUMsRUFDNUI7SUFBRUQsSUFBSSxFQUFFLFdBQVc7SUFBRUMsS0FBSyxFQUFFO0VBQU0sQ0FBQyxDQUNwQztFQUNELGNBQWMsRUFBRSxDQUNkO0lBQUVELElBQUksRUFBRSxVQUFVO0lBQUVDLEtBQUssRUFBRTtFQUFNLENBQUMsRUFDbEM7SUFBRUQsSUFBSSxFQUFFLFNBQVM7SUFBRUMsS0FBSyxFQUFFO0VBQU0sQ0FBQyxDQUNsQztFQUNELFlBQVksRUFBRSxDQUFDO0lBQUVELElBQUksRUFBRSxTQUFTO0lBQUVDLEtBQUssRUFBRTtFQUFNLENBQUM7QUFDbEQsQ0FBQzs7QUFFRDtBQUNBLE1BQU1DLENBQUMsR0FBR0MsVUFBRSxDQUFDQyxPQUFPLENBQUMsT0FBTztFQUMxQjtFQUNBQyxZQUFZLEVBQUUsSUFBSUMsR0FBRyxDQUFvQyxDQUFDO0VBQzFEQyxJQUFJQSxDQUFDQyxJQUFZLEVBQUVDLEdBQVksRUFBRTtJQUMvQixLQUFLLE1BQU1DLEVBQUUsSUFBSVIsQ0FBQyxDQUFDRyxZQUFZLENBQUNNLEdBQUcsQ0FBQ0gsSUFBSSxDQUFDLElBQUksRUFBRSxFQUFFRSxFQUFFLENBQUNELEdBQUcsQ0FBQztFQUMxRCxDQUFDO0VBQ0RHLE1BQU0sRUFBRSxFQUF3RDtFQUNoRTtFQUNBO0VBQ0FDLGFBQWEsRUFBRSxFQUFvSDtFQUNuSTtFQUNBO0VBQ0FDLFVBQVUsRUFBRSxJQUFxQjtFQUNqQztFQUNBQyxVQUFVLEVBQUUsSUFBcUI7RUFDakM7RUFDQTtFQUNBQyxZQUFZLEVBQUViLFVBQUUsQ0FBQ08sRUFBRSxDQUFDLE1BQXFCTyxPQUFPLENBQUNDLE9BQU8sQ0FBQyxDQUFDLENBQUM7RUFDM0Q7RUFDQTtFQUNBO0VBQ0FDLFdBQVcsRUFBRWhCLFVBQUUsQ0FBQ08sRUFBRSxDQUFDLE1BQU07SUFDdkJSLENBQUMsQ0FBQ2tCLHdCQUF3QixDQUFDQyxJQUFJLENBQUNuQixDQUFDLENBQUNHLFlBQVksQ0FBQ00sR0FBRyxDQUFDLGVBQWUsQ0FBQyxFQUFFVyxJQUFJLElBQUksQ0FBQyxDQUFDO0VBQ2pGLENBQUMsQ0FBQztFQUNGRix3QkFBd0IsRUFBRSxFQUFjO0VBQ3hDRyxXQUFXLEVBQUVwQixVQUFFLENBQUNPLEVBQUUsQ0FBQyxNQUFxQk8sT0FBTyxDQUFDQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0VBQzFETSxXQUFXLEVBQUVyQixVQUFFLENBQUNPLEVBQUUsQ0FBQyxNQUFxQk8sT0FBTyxDQUFDQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0VBQzFETyxVQUFVLEVBQUV0QixVQUFFLENBQUNPLEVBQUUsQ0FBQyxNQUFxQk8sT0FBTyxDQUFDQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0VBQ3pEUSxhQUFhLEVBQUV2QixVQUFFLENBQUNPLEVBQUUsQ0FBQyxNQUFxQk8sT0FBTyxDQUFDQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0VBQzVEUyxjQUFjLEVBQUV4QixVQUFFLENBQUNPLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0VBQy9Ca0IsT0FBTyxFQUFFekIsVUFBRSxDQUFDTyxFQUFFLENBQUVtQixJQUFZLElBQUtaLE9BQU8sQ0FBQ0MsT0FBTyxDQUFDbkIsSUFBSSxDQUFDOEIsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUM7RUFDbkVDLGdCQUFnQixFQUFFM0IsVUFBRSxDQUFDTyxFQUFFLENBQUMsTUFBeUJPLE9BQU8sQ0FBQ0MsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0VBQ3JFO0VBQ0E7RUFDQWEsWUFBWSxFQUFFNUIsVUFBRSxDQUFDTyxFQUFFLENBQUMsTUFBd0IsSUFBSU8sT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUNsRTtFQUNBO0VBQ0FlLE1BQU0sRUFBRTtBQUNWLENBQUMsQ0FBQyxDQUFDOztBQUVIO0FBQ0E7QUFDQTtBQUNBN0IsVUFBRSxDQUFDOEIsSUFBSSxDQUFDLG1DQUFtQyxFQUFFLE9BQU87RUFDbERDLFdBQVcsRUFBRUEsQ0FBQzFCLElBQVksRUFBRTJCLE9BQTZCLEtBQUs7SUFDNUQsTUFBTUMsR0FBRyxHQUFHbEMsQ0FBQyxDQUFDRyxZQUFZLENBQUNNLEdBQUcsQ0FBQ0gsSUFBSSxDQUFDLElBQUksSUFBSTZCLEdBQUcsQ0FBdUIsQ0FBQztJQUN2RUQsR0FBRyxDQUFDRSxHQUFHLENBQUNILE9BQU8sQ0FBQztJQUNoQmpDLENBQUMsQ0FBQ0csWUFBWSxDQUFDK0IsR0FBRyxDQUFDNUIsSUFBSSxFQUFFNEIsR0FBRyxDQUFDO0lBQzdCLE9BQU8sTUFBTUEsR0FBRyxDQUFDRyxNQUFNLENBQUNKLE9BQU8sQ0FBQztFQUNsQyxDQUFDO0VBQ0RLLFdBQVcsRUFBRXJDLFVBQUUsQ0FBQ08sRUFBRSxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxDQUFDO0FBRUhQLFVBQUUsQ0FBQzhCLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxPQUFPO0VBQ3JDUSxTQUFTLEVBQUVBLENBQUEsS0FBTXZDLENBQUMsQ0FBQ1UsTUFBTTtFQUN6QjhCLGdCQUFnQixFQUFFQSxDQUFBLEtBQU14QyxDQUFDLENBQUNXLGFBQWE7RUFDdkM4QixnQkFBZ0IsRUFBRUEsQ0FBQSxNQUFPO0lBQ3ZCQyxVQUFVLEVBQUUsRUFBRTtJQUNkQyxTQUFTLEVBQUUsRUFBRTtJQUNiL0IsVUFBVSxFQUFFWixDQUFDLENBQUNZLFVBQVU7SUFDeEJDLFVBQVUsRUFBRWIsQ0FBQyxDQUFDYTtFQUNoQixDQUFDLENBQUM7RUFDRkMsWUFBWSxFQUFHYSxJQUFZLElBQUszQixDQUFDLENBQUNjLFlBQVksQ0FBQ2EsSUFBSSxDQUFDO0VBQ3BEaUIsVUFBVSxFQUFFM0MsVUFBRSxDQUFDTyxFQUFFLENBQUMsTUFBTU8sT0FBTyxDQUFDQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0VBQzFDNkIsWUFBWSxFQUFFNUMsVUFBRSxDQUFDTyxFQUFFLENBQUMsTUFBTU8sT0FBTyxDQUFDQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0VBQzVDSyxXQUFXLEVBQUdNLElBQVksSUFBSzNCLENBQUMsQ0FBQ3FCLFdBQVcsQ0FBQ00sSUFBSSxDQUFDO0VBQ2xETCxXQUFXLEVBQUVBLENBQUN3QixJQUFZLEVBQUVDLEVBQVUsS0FBSy9DLENBQUMsQ0FBQ3NCLFdBQVcsQ0FBQ3dCLElBQUksRUFBRUMsRUFBRSxDQUFDO0VBQ2xFeEIsVUFBVSxFQUFFQSxDQUFDSSxJQUFZLEVBQUVxQixLQUFpQixLQUFLaEQsQ0FBQyxDQUFDdUIsVUFBVSxDQUFDSSxJQUFJLEVBQUVxQixLQUFLLENBQUM7RUFDMUV4QixhQUFhLEVBQUd5QixJQUFhLElBQUtqRCxDQUFDLENBQUN3QixhQUFhLENBQUN5QixJQUFJLENBQUM7RUFDdkR4QixjQUFjLEVBQUVBLENBQUEsS0FBTXpCLENBQUMsQ0FBQ3lCLGNBQWMsQ0FBQyxDQUFDO0VBQ3hDeUIsWUFBWSxFQUFFakQsVUFBRSxDQUFDTyxFQUFFLENBQUMsTUFBTU8sT0FBTyxDQUFDQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0VBQzVDO0VBQ0FZLGdCQUFnQixFQUFFQSxDQUFBLEtBQU01QixDQUFDLENBQUM0QixnQkFBZ0IsQ0FBQyxDQUFDO0VBQzVDdUIsY0FBYyxFQUFFbEQsVUFBRSxDQUFDTyxFQUFFLENBQUMsTUFBTU8sT0FBTyxDQUFDQyxPQUFPLENBQUM7SUFBRVYsSUFBSSxFQUFFLFdBQVc7SUFBRXFCLElBQUksRUFBRSxVQUFVO0lBQUV5QixFQUFFLEVBQUU7RUFBYSxDQUFDLENBQUMsQ0FBQztFQUN2R3ZCLFlBQVksRUFBRUEsQ0FBQSxLQUFNN0IsQ0FBQyxDQUFDNkIsWUFBWSxDQUFDLENBQUM7RUFDcEN3QixTQUFTLEVBQUVBLENBQUEsS0FBTXJELENBQUMsQ0FBQzhCLE1BQU07RUFDekI7RUFDQTtFQUNBO0VBQ0FiLFdBQVcsRUFBRUEsQ0FBQSxLQUFNakIsQ0FBQyxDQUFDaUIsV0FBVyxDQUFDO0FBQ25DLENBQUMsQ0FBQyxDQUFDO0FBRUhoQixVQUFFLENBQUM4QixJQUFJLENBQUMsV0FBVyxFQUFFLE9BQU87RUFDMUJMLE9BQU8sRUFBR0MsSUFBWSxJQUFLM0IsQ0FBQyxDQUFDMEIsT0FBTyxDQUFDQyxJQUFJLENBQUM7RUFDMUMyQixRQUFRLEVBQUVBLENBQUEsS0FBTXZDLE9BQU8sQ0FBQ0MsT0FBTyxDQUFDLElBQUl1QyxVQUFVLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDMURDLFdBQVcsRUFBRTtJQUNYOUIsT0FBTyxFQUFHQyxJQUFZLElBQUszQixDQUFDLENBQUMwQixPQUFPLENBQUNDLElBQUksQ0FBQztJQUMxQzJCLFFBQVEsRUFBRUEsQ0FBQSxLQUFNdkMsT0FBTyxDQUFDQyxPQUFPLENBQUMsSUFBSXVDLFVBQVUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7RUFDM0Q7QUFDRixDQUFDLENBQUMsQ0FBQztBQUlILE1BQU1FLFFBQVEsR0FBR0EsQ0FBQ0wsRUFBRSxHQUFHLE1BQU0sTUFBTTtFQUFFOUMsSUFBSSxFQUFFLFVBQVU7RUFBRXFCLElBQUksRUFBRSxVQUFVO0VBQUV5QjtBQUFHLENBQUMsQ0FBQztBQUU5RSxJQUFBTSxrQkFBVSxFQUFDLE1BQU07RUFDZjFELENBQUMsQ0FBQ1UsTUFBTSxHQUFHLENBQUMrQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0VBQ3ZCekQsQ0FBQyxDQUFDVyxhQUFhLEdBQUcsRUFBRTtFQUNwQlgsQ0FBQyxDQUFDWSxVQUFVLEdBQUcsSUFBSTtFQUNuQlosQ0FBQyxDQUFDYSxVQUFVLEdBQUcsSUFBSTtFQUNuQmIsQ0FBQyxDQUFDRyxZQUFZLENBQUN3RCxLQUFLLENBQUMsQ0FBQztFQUN0QjNELENBQUMsQ0FBQzhCLE1BQU0sR0FBRyxJQUFJO0VBQ2Y5QixDQUFDLENBQUNjLFlBQVksQ0FBQzhDLFNBQVMsQ0FBQyxDQUFDO0VBQzFCNUQsQ0FBQyxDQUFDMEIsT0FBTyxDQUFDa0MsU0FBUyxDQUFDLENBQUM7QUFDdkIsQ0FBQyxDQUFDO0FBRUYsSUFBQUMsaUJBQVMsRUFBQyxNQUFNO0VBQ2Q1RCxVQUFFLENBQUM2RCxhQUFhLENBQUMsQ0FBQztBQUNwQixDQUFDLENBQUM7O0FBRUY7QUFDQTtBQUNBO0FBQ0EsZUFBZUMscUJBQXFCQSxDQUFBLEVBQUc7RUFDckMsTUFBTUMsSUFBSSxHQUFHQyxrQkFBUyxDQUFDQyxLQUFLLENBQUMsQ0FBQztFQUM5QixNQUFNQyxLQUFLLEdBQUcsSUFBQUMsYUFBTSxlQUFDLElBQUEzRSxXQUFBLENBQUE0RSxHQUFBLEVBQUM3RSxnQkFBQSxDQUFBSSxPQUFZLElBQUUsQ0FBQyxDQUFDO0VBQ3RDO0VBQ0EsTUFBTTBFLGFBQU0sQ0FBQ0MsVUFBVSxDQUFDLEtBQUssQ0FBQztFQUM5QixNQUFNQyxHQUFHLEdBQUdGLGFBQU0sQ0FBQ0csU0FBUyxDQUFDLFVBQVUsRUFBRTtJQUFFM0UsSUFBSSxFQUFFO0VBQU0sQ0FBQyxDQUFDO0VBQ3pELElBQUkwRSxHQUFHLENBQUNFLFlBQVksQ0FBQyxlQUFlLENBQUMsS0FBSyxNQUFNLEVBQUU7SUFDaEQsTUFBTVYsSUFBSSxDQUFDVyxLQUFLLENBQUNMLGFBQU0sQ0FBQ00sU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDO0VBQzNDO0VBQ0E7RUFDQSxNQUFNTixhQUFNLENBQUNDLFVBQVUsQ0FBQyxVQUFVLENBQUM7RUFDbkMsT0FBTztJQUFFUCxJQUFJO0lBQUUsR0FBR0c7RUFBTSxDQUFDO0FBQzNCO0FBRUEsSUFBQVUsZ0JBQVEsRUFBQyxjQUFjLEVBQUUsTUFBTTtFQUM3QixJQUFBQyxVQUFFLEVBQUMscUVBQXFFLEVBQUUsWUFBWTtJQUNwRixNQUFNO01BQUVkO0lBQUssQ0FBQyxHQUFHLE1BQU1ELHFCQUFxQixDQUFDLENBQUM7SUFFOUMsTUFBTUMsSUFBSSxDQUFDVyxLQUFLLENBQUNMLGFBQU0sQ0FBQ00sU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDOztJQUU5QztJQUNBLElBQUFHLGNBQU0sRUFBQy9FLENBQUMsQ0FBQ2MsWUFBWSxDQUFDLENBQUNrRSxxQkFBcUIsQ0FBQyxDQUFDLENBQUM7SUFDL0MsSUFBQUQsY0FBTSxFQUFDL0UsQ0FBQyxDQUFDYyxZQUFZLENBQUMsQ0FBQ21FLG9CQUFvQixDQUFDLGVBQWUsQ0FBQzs7SUFFNUQ7SUFDQTtJQUNBO0lBQ0EsTUFBTVQsR0FBRyxHQUFHRixhQUFNLENBQUNHLFNBQVMsQ0FBQyxVQUFVLEVBQUU7TUFBRTNFLElBQUksRUFBRTtJQUFNLENBQUMsQ0FBQztJQUN6RCxJQUFBaUYsY0FBTSxFQUFDUCxHQUFHLENBQUMsQ0FBQ1UsZUFBZSxDQUFDLGVBQWUsRUFBRSxNQUFNLENBQUM7SUFDcEQsTUFBTUMsT0FBTyxHQUFHWCxHQUFHLENBQUNZLE9BQU8sQ0FBQyxJQUFJLENBQWdCO0lBQ2hELElBQUFMLGNBQU0sRUFBQyxJQUFBTSxhQUFNLEVBQUNGLE9BQU8sQ0FBQyxDQUFDUCxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQ1UsaUJBQWlCLENBQUMsQ0FBQztJQUNqRSxJQUFBUCxjQUFNLEVBQUMsSUFBQU0sYUFBTSxFQUFDRixPQUFPLENBQUMsQ0FBQ1AsU0FBUyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUNVLGlCQUFpQixDQUFDLENBQUM7RUFDbEUsQ0FBQyxDQUFDO0VBRUYsSUFBQVIsVUFBRSxFQUFDLG9GQUFvRixFQUFFLFlBQVk7SUFDbkcsTUFBTTtNQUFFZCxJQUFJO01BQUV1QjtJQUFTLENBQUMsR0FBRyxNQUFNeEIscUJBQXFCLENBQUMsQ0FBQztJQUV4RCxNQUFNQyxJQUFJLENBQUNXLEtBQUssQ0FBQ0wsYUFBTSxDQUFDTSxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDOUMsSUFBQUcsY0FBTSxFQUFDVCxhQUFNLENBQUNHLFNBQVMsQ0FBQyxVQUFVLEVBQUU7TUFBRTNFLElBQUksRUFBRTtJQUFXLENBQUMsQ0FBQyxDQUFDLENBQUNvRixlQUFlLENBQ3hFLGVBQWUsRUFDZixNQUNGLENBQUM7O0lBRUQ7SUFDQWxGLENBQUMsQ0FBQ1UsTUFBTSxHQUFHLENBQUMrQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0lBQ3ZCOEIsUUFBUSxjQUFDLElBQUE5RixXQUFBLENBQUE0RSxHQUFBLEVBQUM3RSxnQkFBQSxDQUFBSSxPQUFZLElBQUUsQ0FBQyxDQUFDO0lBRTFCLElBQUFtRixjQUFNLEVBQUNULGFBQU0sQ0FBQ0csU0FBUyxDQUFDLFVBQVUsRUFBRTtNQUFFM0UsSUFBSSxFQUFFO0lBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQ29GLGVBQWUsQ0FDeEUsZUFBZSxFQUNmLE1BQ0YsQ0FBQztJQUNELElBQUFILGNBQU0sRUFBQ1QsYUFBTSxDQUFDRyxTQUFTLENBQUMsVUFBVSxFQUFFO01BQUUzRSxJQUFJLEVBQUU7SUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDb0YsZUFBZSxDQUNuRSxlQUFlLEVBQ2YsTUFDRixDQUFDO0VBQ0gsQ0FBQyxDQUFDO0VBRUYsSUFBQUosVUFBRSxFQUFDLHFHQUFxRyxFQUFFLFlBQVk7SUFDcEg5RSxDQUFDLENBQUNZLFVBQVUsR0FBRyxlQUFlO0lBQzlCLE1BQU07TUFBRTJFO0lBQVMsQ0FBQyxHQUFHLE1BQU14QixxQkFBcUIsQ0FBQyxDQUFDO0lBRWxELE1BQU15QixLQUFLLEdBQUkxRixJQUFZLElBQ3pCd0UsYUFBTSxDQUFDTSxTQUFTLENBQUM5RSxJQUFJLENBQUMsQ0FBQ3NGLE9BQU8sQ0FBQyxXQUFXLENBQWdCOztJQUU1RDtJQUNBO0lBQ0EsSUFBQUwsY0FBTSxFQUFDUyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQ0MsV0FBVyxDQUFDLGVBQWUsQ0FBQztJQUN0RCxJQUFBVixjQUFNLEVBQUNTLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDTixlQUFlLENBQUMsY0FBYyxFQUFFLE1BQU0sQ0FBQztJQUNqRSxJQUFBSCxjQUFNLEVBQUNTLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDRSxHQUFHLENBQUNELFdBQVcsQ0FBQyxlQUFlLENBQUM7SUFDekQ7SUFDQSxJQUFBVixjQUFNLEVBQUNULGFBQU0sQ0FBQ0csU0FBUyxDQUFDLFVBQVUsRUFBRTtNQUFFM0UsSUFBSSxFQUFFO0lBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQzRGLEdBQUcsQ0FBQ1IsZUFBZSxDQUM1RSxlQUFlLEVBQ2YsTUFDRixDQUFDOztJQUVEO0lBQ0E7SUFDQWxGLENBQUMsQ0FBQ1ksVUFBVSxHQUFHLGNBQWM7SUFDN0IyRSxRQUFRLGNBQUMsSUFBQTlGLFdBQUEsQ0FBQTRFLEdBQUEsRUFBQzdFLGdCQUFBLENBQUFJLE9BQVksSUFBRSxDQUFDLENBQUM7SUFFMUIsSUFBQW1GLGNBQU0sRUFBQ1MsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUNDLFdBQVcsQ0FBQyxlQUFlLENBQUM7SUFDckQsSUFBQVYsY0FBTSxFQUFDUyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQ0UsR0FBRyxDQUFDRCxXQUFXLENBQUMsZUFBZSxDQUFDO0lBQzFELElBQUFWLGNBQU0sRUFBQ1QsYUFBTSxDQUFDRyxTQUFTLENBQUMsVUFBVSxFQUFFO01BQUUzRSxJQUFJLEVBQUU7SUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDb0YsZUFBZSxDQUNuRSxlQUFlLEVBQ2YsTUFDRixDQUFDO0VBQ0gsQ0FBQyxDQUFDO0VBRUYsSUFBQUosVUFBRSxFQUFDLDBFQUEwRSxFQUFFLFlBQVk7SUFDekYsTUFBTTtNQUFFUztJQUFTLENBQUMsR0FBRyxNQUFNeEIscUJBQXFCLENBQUMsQ0FBQzs7SUFFbEQ7SUFDQSxNQUFNNEIsV0FBVyxHQUFHM0YsQ0FBQyxDQUFDMEIsT0FBTyxDQUFDSyxJQUFJLENBQUM2RCxLQUFLLENBQUNDLE1BQU07SUFDL0MsSUFBQWQsY0FBTSxFQUFDWSxXQUFXLENBQUMsQ0FBQ0csSUFBSSxDQUFDLENBQUMsQ0FBQztJQUUzQjlGLENBQUMsQ0FBQ1UsTUFBTSxHQUFHLENBQUMrQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUN6QjhCLFFBQVEsY0FBQyxJQUFBOUYsV0FBQSxDQUFBNEUsR0FBQSxFQUFDN0UsZ0JBQUEsQ0FBQUksT0FBWSxJQUFFLENBQUMsQ0FBQzs7SUFFMUI7SUFDQSxJQUFBbUYsY0FBTSxFQUFDL0UsQ0FBQyxDQUFDMEIsT0FBTyxDQUFDSyxJQUFJLENBQUM2RCxLQUFLLENBQUNDLE1BQU0sQ0FBQyxDQUFDQyxJQUFJLENBQUNILFdBQVcsQ0FBQztJQUNyRCxJQUFBWixjQUFNLEVBQUNULGFBQU0sQ0FBQ0csU0FBUyxDQUFDLFVBQVUsRUFBRTtNQUFFM0UsSUFBSSxFQUFFO0lBQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQ29GLGVBQWUsQ0FDbkUsZUFBZSxFQUNmLE1BQ0YsQ0FBQztJQUNELElBQUFILGNBQU0sRUFBQ1QsYUFBTSxDQUFDTSxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQ1UsaUJBQWlCLENBQUMsQ0FBQztFQUMxRCxDQUFDLENBQUM7RUFFRixJQUFBUixVQUFFLEVBQUMscURBQXFELEVBQUUsWUFBWTtJQUNwRSxNQUFNO01BQUVkO0lBQUssQ0FBQyxHQUFHLE1BQU1ELHFCQUFxQixDQUFDLENBQUM7SUFDOUMsTUFBTTRCLFdBQVcsR0FBRzNGLENBQUMsQ0FBQzBCLE9BQU8sQ0FBQ0ssSUFBSSxDQUFDNkQsS0FBSyxDQUFDQyxNQUFNO0lBRS9DLE1BQU03QixJQUFJLENBQUNXLEtBQUssQ0FBQ0wsYUFBTSxDQUFDTSxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7SUFFOUMsSUFBQUcsY0FBTSxFQUFDL0UsQ0FBQyxDQUFDMEIsT0FBTyxDQUFDSyxJQUFJLENBQUM2RCxLQUFLLENBQUNDLE1BQU0sQ0FBQyxDQUFDQyxJQUFJLENBQUNILFdBQVcsQ0FBQztFQUN2RCxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7O0FBRUY7QUFDQSxNQUFNSSxLQUFLLEdBQUdBLENBQUEsTUFBTztFQUFFekYsSUFBSSxFQUFFLE9BQU87RUFBRXFCLElBQUksRUFBRSxZQUFZO0VBQUV5QixFQUFFLEVBQUUsSUFBSTtFQUFFdEQsSUFBSSxFQUFFLGNBQWM7RUFBRWtHLElBQUksRUFBRTtBQUFjLENBQUMsQ0FBQztBQUVoSCxJQUFBbkIsZ0JBQVEsRUFBQyx5QkFBeUIsRUFBRSxNQUFNO0VBQ3hDLElBQUFuQixrQkFBVSxFQUFDLE1BQU07SUFDZjFELENBQUMsQ0FBQ1UsTUFBTSxHQUFHLENBQUMrQyxRQUFRLENBQUMsQ0FBQyxFQUFFc0MsS0FBSyxDQUFDLENBQUMsQ0FBQztFQUNsQyxDQUFDLENBQUM7RUFFRixJQUFBakIsVUFBRSxFQUFDLGdEQUFnRCxFQUFFLFlBQVk7SUFDL0QsSUFBQVYsYUFBTSxlQUFDLElBQUEzRSxXQUFBLENBQUE0RSxHQUFBLEVBQUM3RSxnQkFBQSxDQUFBSSxPQUFZLElBQUUsQ0FBQyxDQUFDO0lBQ3hCLElBQUFtRixjQUFNLEVBQUMsTUFBTVQsYUFBTSxDQUFDMkIsVUFBVSxDQUFDLE1BQU0sRUFBRTtNQUFFbkcsSUFBSSxFQUFFO0lBQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQ3dGLGlCQUFpQixDQUFDLENBQUM7SUFDN0UsSUFBQVAsY0FBTSxFQUFDVCxhQUFNLENBQUNHLFNBQVMsQ0FBQyxNQUFNLEVBQUU7TUFBRTNFLElBQUksRUFBRTtJQUFlLENBQUMsQ0FBQyxDQUFDLENBQUN3RixpQkFBaUIsQ0FBQyxDQUFDO0VBQ2hGLENBQUMsQ0FBQztFQUVGLElBQUFSLFVBQUUsRUFBQyx5RUFBeUUsRUFBRSxZQUFZO0lBQ3hGLElBQUFWLGFBQU0sZUFBQyxJQUFBM0UsV0FBQSxDQUFBNEUsR0FBQSxFQUFDN0UsZ0JBQUEsQ0FBQUksT0FBWSxJQUFFLENBQUMsQ0FBQztJQUN4QixNQUFNc0csU0FBUyxHQUFHLE1BQU01QixhQUFNLENBQUMyQixVQUFVLENBQUMsTUFBTSxFQUFFO01BQUVuRyxJQUFJLEVBQUU7SUFBZSxDQUFDLENBQUM7SUFDM0UsTUFBTXFHLEtBQUssR0FBR0QsU0FBUyxDQUFDZCxPQUFPLENBQUMsUUFBUSxDQUFnQjtJQUN4RCxJQUFBTCxjQUFNLEVBQUMsSUFBQU0sYUFBTSxFQUFDYyxLQUFLLENBQUMsQ0FBQ3ZCLFNBQVMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDVSxpQkFBaUIsQ0FBQyxDQUFDO0lBQ2hFO0lBQ0EsSUFBQVAsY0FBTSxFQUFDLElBQUFNLGFBQU0sRUFBQ2MsS0FBSyxDQUFDLENBQUNDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUNWLEdBQUcsQ0FBQ0osaUJBQWlCLENBQUMsQ0FBQztFQUM1RSxDQUFDLENBQUM7RUFFRixJQUFBUixVQUFFLEVBQUMsMkRBQTJELEVBQUUsWUFBWTtJQUMxRSxNQUFNO01BQUVTO0lBQVMsQ0FBQyxHQUFHLElBQUFuQixhQUFNLGVBQUMsSUFBQTNFLFdBQUEsQ0FBQTRFLEdBQUEsRUFBQzdFLGdCQUFBLENBQUFJLE9BQVksSUFBRSxDQUFDLENBQUM7SUFDN0MsSUFBQW1GLGNBQU0sRUFBQyxNQUFNVCxhQUFNLENBQUMyQixVQUFVLENBQUMsTUFBTSxFQUFFO01BQUVuRyxJQUFJLEVBQUU7SUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDd0YsaUJBQWlCLENBQUMsQ0FBQztJQUNyRnRGLENBQUMsQ0FBQ1UsTUFBTSxHQUFHLENBQUMrQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUN6QjhCLFFBQVEsY0FBQyxJQUFBOUYsV0FBQSxDQUFBNEUsR0FBQSxFQUFDN0UsZ0JBQUEsQ0FBQUksT0FBWSxJQUFFLENBQUMsQ0FBQztJQUMxQixJQUFBbUYsY0FBTSxFQUFDVCxhQUFNLENBQUMrQixXQUFXLENBQUMsTUFBTSxFQUFFO01BQUV2RyxJQUFJLEVBQUU7SUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDNEYsR0FBRyxDQUFDSixpQkFBaUIsQ0FBQyxDQUFDO0lBQ3BGLElBQUFQLGNBQU0sRUFBQ1QsYUFBTSxDQUFDRyxTQUFTLENBQUMsTUFBTSxFQUFFO01BQUUzRSxJQUFJLEVBQUU7SUFBTyxDQUFDLENBQUMsQ0FBQyxDQUFDd0YsaUJBQWlCLENBQUMsQ0FBQztFQUN4RSxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7O0FBRUY7QUFDQSxJQUFBVCxnQkFBUSxFQUFDLG9DQUFvQyxFQUFFLE1BQU07RUFDbkQsSUFBQUMsVUFBRSxFQUFDLGlGQUFpRixFQUFFLFlBQVk7SUFDaEc5RSxDQUFDLENBQUNVLE1BQU0sR0FBRyxDQUNUO01BQ0VKLElBQUksRUFBRSxXQUFXO01BQ2pCcUIsSUFBSSxFQUFFLFlBQVk7TUFDbEJ5QixFQUFFLEVBQUUsVUFBVTtNQUNkdEQsSUFBSSxFQUFFLGNBQWM7TUFDcEJrRyxJQUFJLEVBQUUsSUFBSTtNQUNWTSxLQUFLLEVBQUUsQ0FDTDtRQUFFQyxPQUFPLEVBQUUsUUFBUTtRQUFFUCxJQUFJLEVBQUU7TUFBSyxDQUFDLEVBQ2pDO1FBQUVPLE9BQU8sRUFBRSxTQUFTO1FBQUVQLElBQUksRUFBRTtNQUFLLENBQUM7SUFFdEMsQ0FBQyxDQUNGO0lBQ0QsSUFBQTVCLGFBQU0sZUFBQyxJQUFBM0UsV0FBQSxDQUFBNEUsR0FBQSxFQUFDN0UsZ0JBQUEsQ0FBQUksT0FBWSxJQUFFLENBQUMsQ0FBQztJQUN4QixNQUFNdUcsS0FBSyxHQUFHLENBQUMsTUFBTTdCLGFBQU0sQ0FBQzJCLFVBQVUsQ0FBQyxNQUFNLEVBQUU7TUFBRW5HLElBQUksRUFBRTtJQUFlLENBQUMsQ0FBQyxFQUFFc0YsT0FBTyxDQUMvRSxRQUNGLENBQWdCO0lBQ2hCLE1BQU1vQixLQUFLLEdBQUcsSUFBQW5CLGFBQU0sRUFBQ2MsS0FBSyxDQUFDLENBQUNNLFlBQVksQ0FBQyxzQkFBc0IsQ0FBQztJQUNoRTtJQUNBO0lBQ0E7SUFDQSxJQUFBMUIsY0FBTSxFQUFDeUIsS0FBSyxDQUFDRSxHQUFHLENBQUVDLENBQUMsSUFBS0EsQ0FBQyxDQUFDQyxXQUFXLENBQUMsQ0FBQyxDQUFDQyxPQUFPLENBQUMsQ0FDOUM5QixjQUFNLENBQUMrQixnQkFBZ0IsQ0FBQyxxQkFBcUIsQ0FBQyxFQUM5Qy9CLGNBQU0sQ0FBQytCLGdCQUFnQixDQUFDLG9CQUFvQixDQUFDLENBQzlDLENBQUM7RUFDSixDQUFDLENBQUM7RUFFRixJQUFBaEMsVUFBRSxFQUFDLGdFQUFnRSxFQUFFLFlBQVk7SUFDL0U5RSxDQUFDLENBQUNVLE1BQU0sR0FBRyxDQUFDK0MsUUFBUSxDQUFDLENBQUMsQ0FBQztJQUN2QixJQUFBVyxhQUFNLGVBQUMsSUFBQTNFLFdBQUEsQ0FBQTRFLEdBQUEsRUFBQzdFLGdCQUFBLENBQUFJLE9BQVksSUFBRSxDQUFDLENBQUM7SUFDeEIsTUFBTXVHLEtBQUssR0FBRyxDQUFDLE1BQU03QixhQUFNLENBQUMyQixVQUFVLENBQUMsTUFBTSxFQUFFO01BQUVuRyxJQUFJLEVBQUU7SUFBTyxDQUFDLENBQUMsRUFBRXNGLE9BQU8sQ0FDdkUsUUFDRixDQUFnQjtJQUNoQixNQUFNb0IsS0FBSyxHQUFHLElBQUFuQixhQUFNLEVBQUNjLEtBQUssQ0FBQyxDQUFDTSxZQUFZLENBQUMsc0JBQXNCLENBQUM7SUFDaEUsSUFBQTFCLGNBQU0sRUFBQ3lCLEtBQUssQ0FBQyxDQUFDTyxZQUFZLENBQUMsQ0FBQyxDQUFDO0lBQzdCLElBQUFoQyxjQUFNLEVBQUN5QixLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUNJLFdBQVcsQ0FBQyxDQUFDSSxTQUFTLENBQUMsZ0JBQWdCLENBQUM7RUFDMUQsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDOztBQUVGO0FBQ0EsSUFBQW5DLGdCQUFRLEVBQUMsc0JBQXNCLEVBQUUsTUFBTTtFQUNyQyxJQUFBQyxVQUFFLEVBQUMsdUVBQXVFLEVBQUUsWUFBWTtJQUN0RixNQUFNO01BQUVkO0lBQUssQ0FBQyxHQUFHLE1BQU1ELHFCQUFxQixDQUFDLENBQUM7SUFDOUNrRCxnQkFBUyxDQUFDQyxXQUFXLENBQUM1QyxhQUFNLENBQUNNLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUNuRCxNQUFNdUMsSUFBSSxHQUFHLE1BQU03QyxhQUFNLENBQUMyQixVQUFVLENBQUMsTUFBTSxDQUFDO0lBQzVDLEtBQUssTUFBTW1CLEtBQUssSUFBSSxDQUFDLE1BQU0sRUFBRSxlQUFlLEVBQUUsaUJBQWlCLEVBQUUsU0FBUyxFQUFFLFFBQVEsQ0FBQyxFQUFFO01BQ3JGLElBQUFyQyxjQUFNLEVBQUMsSUFBQU0sYUFBTSxFQUFDOEIsSUFBSSxDQUFDLENBQUMxQyxTQUFTLENBQUMsVUFBVSxFQUFFO1FBQUUzRSxJQUFJLEVBQUUsSUFBSXVILE1BQU0sQ0FBQ0QsS0FBSztNQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM5QixpQkFBaUIsQ0FBQyxDQUFDO0lBQzdGO0lBQ0E7SUFDQSxNQUFNZ0MsT0FBTyxHQUFHckgsVUFBRSxDQUFDc0gsS0FBSyxDQUFDQyxNQUFNLEVBQUUsU0FBUyxDQUFDLENBQUNDLGVBQWUsQ0FBQyxJQUFJLENBQUM7SUFDakUsTUFBTXpELElBQUksQ0FBQ1csS0FBSyxDQUFDLElBQUFVLGFBQU0sRUFBQzhCLElBQUksQ0FBQyxDQUFDMUMsU0FBUyxDQUFDLFVBQVUsRUFBRTtNQUFFM0UsSUFBSSxFQUFFO0lBQVMsQ0FBQyxDQUFDLENBQUM7SUFDeEUsSUFBQWlGLGNBQU0sRUFBQy9FLENBQUMsQ0FBQ3FCLFdBQVcsQ0FBQyxDQUFDNEQsb0JBQW9CLENBQUMsZUFBZSxDQUFDO0lBQzNEcUMsT0FBTyxDQUFDSSxXQUFXLENBQUMsQ0FBQztFQUN2QixDQUFDLENBQUM7O0VBRUY7RUFDQTtFQUNBO0VBQ0E7RUFDQSxJQUFBNUMsVUFBRSxFQUFDLDJFQUEyRSxFQUFFLFlBQVk7SUFDMUYsTUFBTWQsSUFBSSxHQUFHQyxrQkFBUyxDQUFDQyxLQUFLLENBQUMsQ0FBQztJQUM5QixNQUFNSCxxQkFBcUIsQ0FBQyxDQUFDO0lBQzdCLE1BQU11RCxPQUFPLEdBQUdySCxVQUFFLENBQUNzSCxLQUFLLENBQUNDLE1BQU0sRUFBRSxTQUFTLENBQUMsQ0FBQ0MsZUFBZSxDQUFDLEtBQUssQ0FBQztJQUNsRVIsZ0JBQVMsQ0FBQ0MsV0FBVyxDQUFDNUMsYUFBTSxDQUFDTSxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDbkQsTUFBTXVDLElBQUksR0FBRyxNQUFNN0MsYUFBTSxDQUFDMkIsVUFBVSxDQUFDLE1BQU0sQ0FBQztJQUM1QyxNQUFNakMsSUFBSSxDQUFDVyxLQUFLLENBQUMsSUFBQVUsYUFBTSxFQUFDOEIsSUFBSSxDQUFDLENBQUMxQyxTQUFTLENBQUMsVUFBVSxFQUFFO01BQUUzRSxJQUFJLEVBQUU7SUFBVSxDQUFDLENBQUMsQ0FBQztJQUN6RSxJQUFBaUYsY0FBTSxFQUFDL0UsQ0FBQyxDQUFDcUIsV0FBVyxDQUFDLENBQUNxRSxHQUFHLENBQUNpQyxnQkFBZ0IsQ0FBQyxDQUFDO0lBQzVDLElBQUE1QyxjQUFNLEVBQUNULGFBQU0sQ0FBQ0csU0FBUyxDQUFDLFVBQVUsRUFBRTtNQUFFM0UsSUFBSSxFQUFFO0lBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQ3dGLGlCQUFpQixDQUFDLENBQUM7SUFDOUVnQyxPQUFPLENBQUNJLFdBQVcsQ0FBQyxDQUFDO0VBQ3ZCLENBQUMsQ0FBQztFQUVGLElBQUE1QyxVQUFFLEVBQUMsbUVBQW1FLEVBQUUsWUFBWTtJQUNsRjlFLENBQUMsQ0FBQ1UsTUFBTSxHQUFHLENBQUNxRixLQUFLLENBQUMsQ0FBQyxDQUFDO0lBQ3BCLElBQUEzQixhQUFNLGVBQUMsSUFBQTNFLFdBQUEsQ0FBQTRFLEdBQUEsRUFBQzdFLGdCQUFBLENBQUFJLE9BQVksSUFBRSxDQUFDLENBQUM7SUFDeEI7SUFDQXFILGdCQUFTLENBQUNDLFdBQVcsQ0FBQyxNQUFNNUMsYUFBTSxDQUFDQyxVQUFVLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDekQsTUFBTTRDLElBQUksR0FBRyxNQUFNN0MsYUFBTSxDQUFDMkIsVUFBVSxDQUFDLE1BQU0sQ0FBQztJQUM1QyxJQUFBbEIsY0FBTSxFQUFDLElBQUFNLGFBQU0sRUFBQzhCLElBQUksQ0FBQyxDQUFDMUMsU0FBUyxDQUFDLFVBQVUsRUFBRTtNQUFFM0UsSUFBSSxFQUFFO0lBQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQ3dGLGlCQUFpQixDQUFDLENBQUM7SUFDaEYsSUFBQVAsY0FBTSxFQUFDLElBQUFNLGFBQU0sRUFBQzhCLElBQUksQ0FBQyxDQUFDZCxXQUFXLENBQUMsVUFBVSxFQUFFO01BQUV2RyxJQUFJLEVBQUU7SUFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQzRGLEdBQUcsQ0FBQ0osaUJBQWlCLENBQUMsQ0FBQztJQUMvRixJQUFBUCxjQUFNLEVBQUMsSUFBQU0sYUFBTSxFQUFDOEIsSUFBSSxDQUFDLENBQUNkLFdBQVcsQ0FBQyxVQUFVLEVBQUU7TUFBRXZHLElBQUksRUFBRTtJQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM0RixHQUFHLENBQUNKLGlCQUFpQixDQUFDLENBQUM7RUFDMUYsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDOztBQUVGO0FBQ0EsSUFBQVQsZ0JBQVEsRUFBQyxvREFBb0QsRUFBRSxNQUFNO0VBQ25FLElBQUFDLFVBQUUsRUFBQyxtRUFBbUUsRUFBRSxZQUFZO0lBQ2xGLE1BQU1kLElBQUksR0FBR0Msa0JBQVMsQ0FBQ0MsS0FBSyxDQUFDLENBQUM7SUFDOUIsSUFBQUUsYUFBTSxlQUFDLElBQUEzRSxXQUFBLENBQUE0RSxHQUFBLEVBQUM3RSxnQkFBQSxDQUFBSSxPQUFZLElBQUUsQ0FBQyxDQUFDO0lBQ3hCLE1BQU0wRSxhQUFNLENBQUNDLFVBQVUsQ0FBQyxLQUFLLENBQUM7SUFDOUIsTUFBTVAsSUFBSSxDQUFDVyxLQUFLLENBQUNMLGFBQU0sQ0FBQ0csU0FBUyxDQUFDLFFBQVEsRUFBRTtNQUFFM0UsSUFBSSxFQUFFO0lBQWUsQ0FBQyxDQUFDLENBQUM7SUFDdEUsSUFBQWlGLGNBQU0sRUFBQy9FLENBQUMsQ0FBQzZCLFlBQVksQ0FBQyxDQUFDbUQscUJBQXFCLENBQUMsQ0FBQyxDQUFDO0VBQ2pELENBQUMsQ0FBQztFQUVGLElBQUFGLFVBQUUsRUFBQywwRUFBMEUsRUFBRSxZQUFZO0lBQ3pGOUUsQ0FBQyxDQUFDVSxNQUFNLEdBQUcsRUFBRTtJQUNiLE1BQU1zRCxJQUFJLEdBQUdDLGtCQUFTLENBQUNDLEtBQUssQ0FBQyxDQUFDO0lBQzlCLElBQUFFLGFBQU0sZUFBQyxJQUFBM0UsV0FBQSxDQUFBNEUsR0FBQSxFQUFDN0UsZ0JBQUEsQ0FBQUksT0FBWSxJQUFFLENBQUMsQ0FBQztJQUN4QjtJQUNBLE1BQU1nSSxJQUFJLEdBQUcsTUFBTXRELGFBQU0sQ0FBQ0MsVUFBVSxDQUFDLGdEQUFnRCxDQUFDO0lBQ3RGLE1BQU1zRCxLQUFLLEdBQUdELElBQUksQ0FBQ3hDLE9BQU8sQ0FBQyxRQUFRLENBQWdCO0lBQ25ELE1BQU1wQixJQUFJLENBQUNXLEtBQUssQ0FBQyxJQUFBVSxhQUFNLEVBQUN3QyxLQUFLLENBQUMsQ0FBQ3BELFNBQVMsQ0FBQyxRQUFRLEVBQUU7TUFBRTNFLElBQUksRUFBRTtJQUFlLENBQUMsQ0FBQyxDQUFDO0lBQzdFLElBQUFpRixjQUFNLEVBQUMvRSxDQUFDLENBQUM2QixZQUFZLENBQUMsQ0FBQzhGLGdCQUFnQixDQUFDLENBQUM7RUFDM0MsQ0FBQyxDQUFDO0VBRUYsSUFBQTdDLFVBQUUsRUFBQyxpRkFBaUYsRUFBRSxZQUFZO0lBQ2hHO0lBQ0EwQyxNQUFNLENBQUNNLE9BQU8sQ0FBQ0MsWUFBWSxDQUN6QixDQUFDLENBQUMsRUFDRixFQUFFLEVBQ0YsU0FBUyxHQUFHQyxrQkFBa0IsQ0FBQywrQ0FBK0MsQ0FDaEYsQ0FBQztJQUNELE1BQU1DLElBQUksR0FBR2hJLFVBQUUsQ0FBQ3NILEtBQUssQ0FBQ0MsTUFBTSxFQUFFLE1BQU0sQ0FBQyxDQUFDQyxlQUFlLENBQUMsSUFBSSxDQUFDO0lBQzNELElBQUk7TUFDRnpILENBQUMsQ0FBQ1UsTUFBTSxHQUFHLENBQUM7UUFBRUosSUFBSSxFQUFFLE9BQU87UUFBRXFCLElBQUksRUFBRSxZQUFZO1FBQUV5QixFQUFFLEVBQUUsVUFBVTtRQUFFdEQsSUFBSSxFQUFFO01BQWUsQ0FBQyxDQUFDO01BQ3hGLE1BQU1rRSxJQUFJLEdBQUdDLGtCQUFTLENBQUNDLEtBQUssQ0FBQyxDQUFDO01BQzlCLElBQUFFLGFBQU0sZUFBQyxJQUFBM0UsV0FBQSxDQUFBNEUsR0FBQSxFQUFDN0UsZ0JBQUEsQ0FBQUksT0FBWSxJQUFFLENBQUMsQ0FBQztNQUN4QjtNQUNBO01BQ0EsTUFBTXNJLElBQUksR0FBRyxNQUFNNUQsYUFBTSxDQUFDMkIsVUFBVSxDQUFDLE1BQU0sRUFBRTtRQUFFbkcsSUFBSSxFQUFFO01BQWUsQ0FBQyxDQUFDO01BQ3RFbUgsZ0JBQVMsQ0FBQ0MsV0FBVyxDQUFDLElBQUE3QixhQUFNLEVBQUM2QyxJQUFJLENBQUMsQ0FBQ3RELFNBQVMsQ0FBQyxjQUFjLENBQUMsQ0FBQztNQUM3RCxNQUFNdUMsSUFBSSxHQUFHLE1BQU03QyxhQUFNLENBQUMyQixVQUFVLENBQUMsTUFBTSxDQUFDO01BQzVDLE1BQU1qQyxJQUFJLENBQUNXLEtBQUssQ0FBQyxJQUFBVSxhQUFNLEVBQUM4QixJQUFJLENBQUMsQ0FBQzFDLFNBQVMsQ0FBQyxVQUFVLEVBQUU7UUFBRTNFLElBQUksRUFBRTtNQUFpQixDQUFDLENBQUMsQ0FBQztNQUNoRixJQUFBaUYsY0FBTSxFQUFDa0QsSUFBSSxDQUFDLENBQUNoRCxvQkFBb0IsQ0FDL0IseUNBQXlDLEVBQ3pDLFFBQVEsRUFDUixxQkFDRixDQUFDO0lBQ0gsQ0FBQyxTQUFTO01BQ1JnRCxJQUFJLENBQUNQLFdBQVcsQ0FBQyxDQUFDO01BQ2xCRixNQUFNLENBQUNNLE9BQU8sQ0FBQ0MsWUFBWSxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsRUFBRSxHQUFHLENBQUM7SUFDMUM7RUFDRixDQUFDLENBQUM7RUFFRixJQUFBakQsVUFBRSxFQUFDLGlFQUFpRSxFQUFFLFlBQVk7SUFDaEYwQyxNQUFNLENBQUNNLE9BQU8sQ0FBQ0MsWUFBWSxDQUN6QixDQUFDLENBQUMsRUFDRixFQUFFLEVBQ0YsU0FBUyxHQUFHQyxrQkFBa0IsQ0FBQywrQ0FBK0MsQ0FDaEYsQ0FBQztJQUNELElBQUk7TUFDRmhJLENBQUMsQ0FBQ1UsTUFBTSxHQUFHLENBQUM7UUFBRUosSUFBSSxFQUFFLE9BQU87UUFBRXFCLElBQUksRUFBRSxZQUFZO1FBQUV5QixFQUFFLEVBQUUsVUFBVTtRQUFFdEQsSUFBSSxFQUFFO01BQWUsQ0FBQyxDQUFDO01BQ3hGLElBQUFzRSxhQUFNLGVBQUMsSUFBQTNFLFdBQUEsQ0FBQTRFLEdBQUEsRUFBQzdFLGdCQUFBLENBQUFJLE9BQVksSUFBRSxDQUFDLENBQUM7TUFDeEJxSCxnQkFBUyxDQUFDQyxXQUFXLENBQUMsTUFBTTVDLGFBQU0sQ0FBQ0MsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDO01BQ3pELE1BQU00QyxJQUFJLEdBQUcsTUFBTTdDLGFBQU0sQ0FBQzJCLFVBQVUsQ0FBQyxNQUFNLENBQUM7TUFDNUMsSUFBQWxCLGNBQU0sRUFDSixJQUFBTSxhQUFNLEVBQUM4QixJQUFJLENBQUMsQ0FBQ2QsV0FBVyxDQUFDLFVBQVUsRUFBRTtRQUFFdkcsSUFBSSxFQUFFO01BQWlCLENBQUMsQ0FDakUsQ0FBQyxDQUFDNEYsR0FBRyxDQUFDSixpQkFBaUIsQ0FBQyxDQUFDO0lBQzNCLENBQUMsU0FBUztNQUNSa0MsTUFBTSxDQUFDTSxPQUFPLENBQUNDLFlBQVksQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLEVBQUUsR0FBRyxDQUFDO0lBQzFDO0VBQ0YsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDOztBQUVGO0FBQ0EsU0FBU0ksWUFBWUEsQ0FBQ0MsSUFBdUMsRUFBRTtFQUM3RCxNQUFNQyxLQUFlLEdBQUcsRUFBRTtFQUMxQixJQUFJRCxJQUFJLENBQUNFLElBQUksRUFBRUQsS0FBSyxDQUFDbEgsSUFBSSxDQUFDLDRCQUE0QixDQUFDO0VBQ3ZELElBQUlpSCxJQUFJLENBQUNHLEtBQUssRUFBRTFDLE1BQU0sRUFBRXdDLEtBQUssQ0FBQ2xILElBQUksQ0FBQyxPQUFPLENBQUM7RUFDM0MsT0FBTztJQUNMa0gsS0FBSztJQUNMRSxLQUFLLEVBQUVILElBQUksQ0FBQ0csS0FBSyxJQUFJLEVBQUU7SUFDdkJDLE9BQU8sRUFBR0MsQ0FBUyxJQUFNQSxDQUFDLEtBQUssNEJBQTRCLEdBQUlMLElBQUksQ0FBQ0UsSUFBSSxJQUFJLEVBQUUsR0FBSSxFQUFHO0lBQ3JGSSxPQUFPLEVBQUVBLENBQUEsS0FBTSxDQUFDLENBQUM7SUFDakJDLFVBQVUsRUFBRSxFQUFFO0lBQ2RDLGFBQWEsRUFBRTtFQUNqQixDQUFDO0FBQ0g7O0FBRUE7QUFDQSxJQUFBL0QsZ0JBQVEsRUFBQywwQ0FBMEMsRUFBRSxNQUFNO0VBQ3pELElBQUFDLFVBQUUsRUFBQyw0REFBNEQsRUFBRSxZQUFZO0lBQzNFLE1BQU1mLHFCQUFxQixDQUFDLENBQUM7SUFDN0IsTUFBTThFLE1BQU0sR0FBR3ZFLGFBQU0sQ0FBQ00sU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDUSxPQUFPLENBQUMsUUFBUSxDQUFnQjtJQUN2RTZCLGdCQUFTLENBQUM2QixJQUFJLENBQUNELE1BQU0sRUFBRTtNQUNyQlYsWUFBWSxFQUFFQSxZQUFZLENBQUM7UUFBRUcsSUFBSSxFQUFFUyxJQUFJLENBQUNDLFNBQVMsQ0FBQztVQUFFbEcsSUFBSSxFQUFFLG9CQUFvQjtVQUFFbUcsUUFBUSxFQUFFO1FBQVcsQ0FBQztNQUFFLENBQUM7SUFDM0csQ0FBQyxDQUFDO0lBQ0YsSUFBQWxFLGNBQU0sRUFBQy9FLENBQUMsQ0FBQ3NCLFdBQVcsQ0FBQyxDQUFDMkQsb0JBQW9CLENBQUMsWUFBWSxFQUFFLGdCQUFnQixDQUFDO0VBQzVFLENBQUMsQ0FBQztFQUVGLElBQUFILFVBQUUsRUFBQyw0Q0FBNEMsRUFBRSxZQUFZO0lBQzNELE1BQU1mLHFCQUFxQixDQUFDLENBQUM7SUFDN0IsTUFBTThFLE1BQU0sR0FBR3ZFLGFBQU0sQ0FBQ00sU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDUSxPQUFPLENBQUMsUUFBUSxDQUFnQjtJQUN2RTZCLGdCQUFTLENBQUM2QixJQUFJLENBQUNELE1BQU0sRUFBRTtNQUNyQlYsWUFBWSxFQUFFQSxZQUFZLENBQUM7UUFBRUcsSUFBSSxFQUFFUyxJQUFJLENBQUNDLFNBQVMsQ0FBQztVQUFFbEcsSUFBSSxFQUFFLGlCQUFpQjtVQUFFbUcsUUFBUSxFQUFFO1FBQWEsQ0FBQztNQUFFLENBQUM7SUFDMUcsQ0FBQyxDQUFDO0lBQ0YsSUFBQWxFLGNBQU0sRUFBQy9FLENBQUMsQ0FBQ3NCLFdBQVcsQ0FBQyxDQUFDb0UsR0FBRyxDQUFDaUMsZ0JBQWdCLENBQUMsQ0FBQztJQUM1QyxJQUFBNUMsY0FBTSxFQUFDLE1BQU1ULGFBQU0sQ0FBQzJCLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDaUQsaUJBQWlCLENBQUMsUUFBUSxDQUFDO0VBQ3RFLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQzs7QUFFRjtBQUNBLElBQUFyRSxnQkFBUSxFQUFDLHFEQUFxRCxFQUFFLE1BQU07RUFDcEUsSUFBQUMsVUFBRSxFQUFDLHFFQUFxRSxFQUFFLFlBQVk7SUFDcEYsTUFBTWYscUJBQXFCLENBQUMsQ0FBQztJQUM3QixNQUFNOEUsTUFBTSxHQUFHdkUsYUFBTSxDQUFDTSxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUNRLE9BQU8sQ0FBQyxRQUFRLENBQWdCO0lBQ3ZFLE1BQU0rRCxJQUFJLEdBQUcsSUFBSUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLEVBQUUsVUFBVSxFQUFFO01BQUU5SSxJQUFJLEVBQUU7SUFBYSxDQUFDLENBQUM7SUFDcEUyRyxnQkFBUyxDQUFDNkIsSUFBSSxDQUFDRCxNQUFNLEVBQUU7TUFBRVYsWUFBWSxFQUFFQSxZQUFZLENBQUM7UUFBRUksS0FBSyxFQUFFLENBQUNZLElBQUk7TUFBRSxDQUFDO0lBQUUsQ0FBQyxDQUFDO0lBQ3pFLE1BQU1sSixVQUFFLENBQUNvSixPQUFPLENBQUMsTUFBTSxJQUFBdEUsY0FBTSxFQUFDL0UsQ0FBQyxDQUFDdUIsVUFBVSxDQUFDLENBQUNvRyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUM7SUFDL0QsSUFBQTVDLGNBQU0sRUFBQy9FLENBQUMsQ0FBQ3VCLFVBQVUsQ0FBQ1EsSUFBSSxDQUFDNkQsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUNFLElBQUksQ0FBQyxlQUFlLENBQUM7RUFDN0QsQ0FBQyxDQUFDOztFQUVGO0VBQ0E7RUFDQTtFQUNBLElBQUFoQixVQUFFLEVBQUMsaUVBQWlFLEVBQUUsWUFBWTtJQUNoRixNQUFNZixxQkFBcUIsQ0FBQyxDQUFDO0lBQzdCLE1BQU1vQyxLQUFLLEdBQUc3QixhQUFNLENBQUNNLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQ1EsT0FBTyxDQUFDLFFBQVEsQ0FBZ0I7SUFDdEUsTUFBTStELElBQUksR0FBRyxJQUFJQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBRSxVQUFVLEVBQUU7TUFBRTlJLElBQUksRUFBRTtJQUFhLENBQUMsQ0FBQztJQUNwRTJHLGdCQUFTLENBQUM2QixJQUFJLENBQUMzQyxLQUFLLEVBQUU7TUFBRWdDLFlBQVksRUFBRUEsWUFBWSxDQUFDO1FBQUVJLEtBQUssRUFBRSxDQUFDWSxJQUFJO01BQUUsQ0FBQztJQUFFLENBQUMsQ0FBQztJQUN4RSxNQUFNbEosVUFBRSxDQUFDb0osT0FBTyxDQUFDLE1BQU0sSUFBQXRFLGNBQU0sRUFBQy9FLENBQUMsQ0FBQ3VCLFVBQVUsQ0FBQyxDQUFDb0csZ0JBQWdCLENBQUMsQ0FBQyxDQUFDO0lBQy9ELElBQUE1QyxjQUFNLEVBQUMvRSxDQUFDLENBQUN1QixVQUFVLENBQUNRLElBQUksQ0FBQzZELEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDRSxJQUFJLENBQUMsV0FBVyxDQUFDO0VBQ3pELENBQUMsQ0FBQztFQUVGLElBQUFoQixVQUFFLEVBQUMsNkRBQTZELEVBQUUsWUFBWTtJQUM1RSxNQUFNZixxQkFBcUIsQ0FBQyxDQUFDO0lBQzdCLE1BQU11RixPQUFPLEdBQUdoRixhQUFNLENBQUNNLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQ1EsT0FBTyxDQUFDLFFBQVEsQ0FBZ0I7SUFDN0UsTUFBTStELElBQUksR0FBRyxJQUFJQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBRSxVQUFVLEVBQUU7TUFBRTlJLElBQUksRUFBRTtJQUFhLENBQUMsQ0FBQztJQUNwRTJHLGdCQUFTLENBQUM2QixJQUFJLENBQUNRLE9BQU8sRUFBRTtNQUFFbkIsWUFBWSxFQUFFQSxZQUFZLENBQUM7UUFBRUksS0FBSyxFQUFFLENBQUNZLElBQUk7TUFBRSxDQUFDO0lBQUUsQ0FBQyxDQUFDO0lBQzFFLE1BQU1sSixVQUFFLENBQUNvSixPQUFPLENBQUMsTUFBTSxJQUFBdEUsY0FBTSxFQUFDL0UsQ0FBQyxDQUFDdUIsVUFBVSxDQUFDLENBQUNvRyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUM7SUFDL0QsSUFBQTVDLGNBQU0sRUFBQy9FLENBQUMsQ0FBQ3VCLFVBQVUsQ0FBQ1EsSUFBSSxDQUFDNkQsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUNFLElBQUksQ0FBQyxlQUFlLENBQUM7RUFDN0QsQ0FBQyxDQUFDO0VBRUYsSUFBQWhCLFVBQUUsRUFBQyx5REFBeUQsRUFBRSxZQUFZO0lBQ3hFLE1BQU1mLHFCQUFxQixDQUFDLENBQUM7SUFDN0IsTUFBTThFLE1BQU0sR0FBR3ZFLGFBQU0sQ0FBQ00sU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDUSxPQUFPLENBQUMsUUFBUSxDQUFnQjtJQUN2RSxNQUFNK0QsSUFBSSxHQUFHLElBQUlDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxFQUFFLFVBQVUsRUFBRTtNQUFFOUksSUFBSSxFQUFFO0lBQWEsQ0FBQyxDQUFDO0lBQ3BFMkcsZ0JBQVMsQ0FBQzZCLElBQUksQ0FBQ0QsTUFBTSxFQUFFO01BQUVWLFlBQVksRUFBRUEsWUFBWSxDQUFDO1FBQUVJLEtBQUssRUFBRSxDQUFDWSxJQUFJO01BQUUsQ0FBQztJQUFFLENBQUMsQ0FBQztJQUN6RSxNQUFNbEosVUFBRSxDQUFDb0osT0FBTyxDQUFDLE1BQU0sSUFBQXRFLGNBQU0sRUFBQy9FLENBQUMsQ0FBQ3VCLFVBQVUsQ0FBQyxDQUFDb0csZ0JBQWdCLENBQUMsQ0FBQyxDQUFDO0lBQy9ELElBQUE1QyxjQUFNLEVBQUMvRSxDQUFDLENBQUN1QixVQUFVLENBQUMsQ0FBQ3lELHFCQUFxQixDQUFDLENBQUMsQ0FBQztFQUMvQyxDQUFDLENBQUM7RUFFRixJQUFBRixVQUFFLEVBQUMseUVBQXlFLEVBQUUsWUFBWTtJQUN4RixNQUFNZixxQkFBcUIsQ0FBQyxDQUFDO0lBQzdCLE1BQU1vQyxLQUFLLEdBQUc3QixhQUFNLENBQUNNLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQ1EsT0FBTyxDQUFDLFFBQVEsQ0FBZ0I7SUFDdEUsSUFBQUwsY0FBTSxFQUFDb0IsS0FBSyxDQUFDekIsWUFBWSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUNvQixJQUFJLENBQUMsSUFBSSxDQUFDO0lBQ2xEbUIsZ0JBQVMsQ0FBQ3NDLFFBQVEsQ0FBQ3BELEtBQUssRUFBRTtNQUFFZ0MsWUFBWSxFQUFFQSxZQUFZLENBQUM7UUFBRUksS0FBSyxFQUFFLENBQUMsSUFBSWEsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsT0FBTyxDQUFDO01BQUUsQ0FBQztJQUFFLENBQUMsQ0FBQztJQUNoRyxJQUFBckUsY0FBTSxFQUFDb0IsS0FBSyxDQUFDekIsWUFBWSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUNvQixJQUFJLENBQUMsR0FBRyxDQUFDO0lBQ2pEbUIsZ0JBQVMsQ0FBQ3VDLFNBQVMsQ0FBQ3JELEtBQUssRUFBRTtNQUFFc0QsYUFBYSxFQUFFQyxRQUFRLENBQUNDO0lBQUssQ0FBQyxDQUFDO0lBQzVELElBQUE1RSxjQUFNLEVBQUNvQixLQUFLLENBQUN6QixZQUFZLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQ29CLElBQUksQ0FBQyxJQUFJLENBQUM7RUFDcEQsQ0FBQyxDQUFDO0VBRUYsSUFBQWhCLFVBQUUsRUFBQyxxRUFBcUUsRUFBRSxZQUFZO0lBQ3BGLE1BQU1mLHFCQUFxQixDQUFDLENBQUM7SUFDN0IsTUFBTW9DLEtBQUssR0FBRzdCLGFBQU0sQ0FBQ00sU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDUSxPQUFPLENBQUMsUUFBUSxDQUFnQjtJQUN0RTZCLGdCQUFTLENBQUNzQyxRQUFRLENBQUNwRCxLQUFLLEVBQUU7TUFDeEJnQyxZQUFZLEVBQUVBLFlBQVksQ0FBQztRQUFFRyxJQUFJLEVBQUVTLElBQUksQ0FBQ0MsU0FBUyxDQUFDO1VBQUVsRyxJQUFJLEVBQUUsWUFBWTtVQUFFbUcsUUFBUSxFQUFFO1FBQVcsQ0FBQztNQUFFLENBQUM7SUFDbkcsQ0FBQyxDQUFDO0lBQ0YsSUFBQWxFLGNBQU0sRUFBQ29CLEtBQUssQ0FBQ3pCLFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDb0IsSUFBSSxDQUFDLElBQUksQ0FBQztJQUNsRG1CLGdCQUFTLENBQUM2QixJQUFJLENBQUMzQyxLQUFLLEVBQUU7TUFDcEJnQyxZQUFZLEVBQUVBLFlBQVksQ0FBQztRQUFFRyxJQUFJLEVBQUVTLElBQUksQ0FBQ0MsU0FBUyxDQUFDO1VBQUVsRyxJQUFJLEVBQUUsWUFBWTtVQUFFbUcsUUFBUSxFQUFFO1FBQVcsQ0FBQztNQUFFLENBQUM7SUFDbkcsQ0FBQyxDQUFDO0lBQ0YsSUFBQWxFLGNBQU0sRUFBQy9FLENBQUMsQ0FBQ3NCLFdBQVcsQ0FBQyxDQUFDb0UsR0FBRyxDQUFDaUMsZ0JBQWdCLENBQUMsQ0FBQztJQUM1QyxJQUFBNUMsY0FBTSxFQUFDL0UsQ0FBQyxDQUFDdUIsVUFBVSxDQUFDLENBQUNtRSxHQUFHLENBQUNpQyxnQkFBZ0IsQ0FBQyxDQUFDO0VBQzdDLENBQUMsQ0FBQzs7RUFFRjtFQUNBO0VBQ0E7RUFDQSxJQUFBN0MsVUFBRSxFQUFDLHFFQUFxRSxFQUFFLFlBQVk7SUFDcEYsTUFBTTtNQUFFZCxJQUFJO01BQUU0RjtJQUFVLENBQUMsR0FBRyxNQUFNN0YscUJBQXFCLENBQUMsQ0FBQztJQUN6RCxNQUFNQyxJQUFJLENBQUNXLEtBQUssQ0FBQ0wsYUFBTSxDQUFDTSxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDOztJQUVoRHFDLGdCQUFTLENBQUN0QyxLQUFLLENBQUNMLGFBQU0sQ0FBQ0csU0FBUyxDQUFDLFFBQVEsRUFBRTtNQUFFM0UsSUFBSSxFQUFFO0lBQXVCLENBQUMsQ0FBQyxDQUFDO0lBQzdFLE1BQU0rSixLQUFLLEdBQUdELFNBQVMsQ0FBQ0UsYUFBYSxDQUFtQixvQkFBb0IsQ0FBRTtJQUM5RTdDLGdCQUFTLENBQUM4QyxNQUFNLENBQUNGLEtBQUssRUFBRTtNQUN0QkcsTUFBTSxFQUFFO1FBQUV6QixLQUFLLEVBQUUsQ0FBQyxJQUFJYSxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBRSxVQUFVLEVBQUU7VUFBRTlJLElBQUksRUFBRTtRQUFhLENBQUMsQ0FBQztNQUFFO0lBQzdFLENBQUMsQ0FBQztJQUVGLE1BQU1MLFVBQUUsQ0FBQ29KLE9BQU8sQ0FBQyxNQUFNLElBQUF0RSxjQUFNLEVBQUMvRSxDQUFDLENBQUN1QixVQUFVLENBQUMsQ0FBQ29HLGdCQUFnQixDQUFDLENBQUMsQ0FBQztJQUMvRCxJQUFBNUMsY0FBTSxFQUFDL0UsQ0FBQyxDQUFDdUIsVUFBVSxDQUFDUSxJQUFJLENBQUM2RCxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ0UsSUFBSSxDQUFDLGVBQWUsQ0FBQztFQUM3RCxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7O0FBRUY7QUFDQSxJQUFBakIsZ0JBQVEsRUFBQywwREFBMEQsRUFBRSxNQUFNO0VBQ3pFLElBQUFDLFVBQUUsRUFBQyx1RUFBdUUsRUFBRSxZQUFZO0lBQ3RGLE1BQU1mLHFCQUFxQixDQUFDLENBQUM7SUFDN0IsTUFBTXVGLE9BQU8sR0FBR2hGLGFBQU0sQ0FBQ00sU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDUSxPQUFPLENBQUMsUUFBUSxDQUFnQjtJQUM3RTZCLGdCQUFTLENBQUNnRCxTQUFTLENBQUNYLE9BQU8sRUFBRTtNQUFFbkIsWUFBWSxFQUFFQSxZQUFZLENBQUMsQ0FBQyxDQUFDO0lBQUUsQ0FBQyxDQUFDO0lBQ2hFLE1BQU1sSSxVQUFFLENBQUNvSixPQUFPLENBQUMsTUFBTSxJQUFBdEUsY0FBTSxFQUFDL0UsQ0FBQyxDQUFDd0IsYUFBYSxDQUFDLENBQUNtRyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUM7SUFDbEUsSUFBQTVDLGNBQU0sRUFBQy9FLENBQUMsQ0FBQ3dCLGFBQWEsQ0FBQ08sSUFBSSxDQUFDNkQsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUNzRSxhQUFhLENBQUM7TUFDckRDLElBQUksRUFBRSxNQUFNO01BQ1pySyxJQUFJLEVBQUUsVUFBVTtNQUNoQnNLLE9BQU8sRUFBRTtJQUNYLENBQUMsQ0FBQztFQUNKLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQztBQUVGLElBQUF2RixnQkFBUSxFQUFDLDBEQUEwRCxFQUFFLE1BQU07RUFDekUsTUFBTXdGLFlBQVksR0FBR0EsQ0FBQSxNQUFPO0lBQzFCL0osSUFBSSxFQUFFLE9BQU87SUFDYnFCLElBQUksRUFBRSxjQUFjO0lBQ3BCeUIsRUFBRSxFQUFFLE1BQU07SUFDVnRELElBQUksRUFBRSxlQUFlO0lBQ3JCa0csSUFBSSxFQUFFLElBQWE7SUFDbkJzRSxjQUFjLEVBQUU7RUFDbEIsQ0FBQyxDQUFDO0VBRUYsSUFBQXhGLFVBQUUsRUFBQyw4RUFBOEUsRUFBRSxZQUFZO0lBQzdGOUUsQ0FBQyxDQUFDVSxNQUFNLEdBQUcsQ0FBQytDLFFBQVEsQ0FBQyxDQUFDLENBQUM7SUFDdkJ6RCxDQUFDLENBQUNXLGFBQWEsR0FBRyxFQUFFLENBQUMsQ0FBQztJQUN0QixJQUFBeUQsYUFBTSxlQUFDLElBQUEzRSxXQUFBLENBQUE0RSxHQUFBLEVBQUM3RSxnQkFBQSxDQUFBSSxPQUFZLElBQUUsQ0FBQyxDQUFDO0lBQ3hCLElBQUFtRixjQUFNLEVBQUMsTUFBTVQsYUFBTSxDQUFDMkIsVUFBVSxDQUFDLE1BQU0sRUFBRTtNQUFFbkcsSUFBSSxFQUFFO0lBQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQ3dGLGlCQUFpQixDQUFDLENBQUM7SUFDN0U7SUFDQSxJQUFBUCxjQUFNLEVBQUNULGFBQU0sQ0FBQytCLFdBQVcsQ0FBQyxZQUFZLEVBQUU7TUFBRXZHLElBQUksRUFBRTtJQUFjLENBQUMsQ0FBQyxDQUFDLENBQUN5SyxRQUFRLENBQUMsQ0FBQztJQUM1RSxJQUFBeEYsY0FBTSxFQUFDVCxhQUFNLENBQUMrQixXQUFXLENBQUMsT0FBTyxFQUFFO01BQUV2RyxJQUFJLEVBQUU7SUFBdUIsQ0FBQyxDQUFDLENBQUMsQ0FBQ3lLLFFBQVEsQ0FBQyxDQUFDO0VBQ2xGLENBQUMsQ0FBQztFQUVGLElBQUF6RixVQUFFLEVBQUMsbUZBQW1GLEVBQUUsWUFBWTtJQUNsRzlFLENBQUMsQ0FBQ1UsTUFBTSxHQUFHLENBQUMrQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUN6QnpELENBQUMsQ0FBQ1csYUFBYSxHQUFHLENBQUMwSixZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUNwQyxNQUFNckcsSUFBSSxHQUFHQyxrQkFBUyxDQUFDQyxLQUFLLENBQUMsQ0FBQztJQUM5QixJQUFBRSxhQUFNLGVBQUMsSUFBQTNFLFdBQUEsQ0FBQTRFLEdBQUEsRUFBQzdFLGdCQUFBLENBQUFJLE9BQVksSUFBRSxDQUFDLENBQUM7O0lBRXhCO0lBQ0E7SUFDQSxJQUFBbUYsY0FBTSxFQUFDLE1BQU1ULGFBQU0sQ0FBQzJCLFVBQVUsQ0FBQyxNQUFNLEVBQUU7TUFBRW5HLElBQUksRUFBRTtJQUFPLENBQUMsQ0FBQyxDQUFDLENBQUN3RixpQkFBaUIsQ0FBQyxDQUFDO0lBQzdFLElBQUFQLGNBQU0sRUFBQ1QsYUFBTSxDQUFDK0IsV0FBVyxDQUFDLE1BQU0sRUFBRTtNQUFFdkcsSUFBSSxFQUFFO0lBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUN5SyxRQUFRLENBQUMsQ0FBQzs7SUFFeEU7SUFDQSxNQUFNdkcsSUFBSSxDQUFDVyxLQUFLLENBQUNMLGFBQU0sQ0FBQ0csU0FBUyxDQUFDLE9BQU8sRUFBRTtNQUFFM0UsSUFBSSxFQUFFO0lBQXVCLENBQUMsQ0FBQyxDQUFDOztJQUU3RTtJQUNBLElBQUFpRixjQUFNLEVBQUMsTUFBTVQsYUFBTSxDQUFDMkIsVUFBVSxDQUFDLE1BQU0sRUFBRTtNQUFFbkcsSUFBSSxFQUFFO0lBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUN3RixpQkFBaUIsQ0FBQyxDQUFDO0lBQ3RGLElBQUFQLGNBQU0sRUFBQ1QsYUFBTSxDQUFDK0IsV0FBVyxDQUFDLE1BQU0sRUFBRTtNQUFFdkcsSUFBSSxFQUFFO0lBQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQ3lLLFFBQVEsQ0FBQyxDQUFDO0VBQ2pFLENBQUMsQ0FBQztFQUVGLElBQUF6RixVQUFFLEVBQUMsMEZBQTBGLEVBQUUsWUFBWTtJQUN6RzlFLENBQUMsQ0FBQ1UsTUFBTSxHQUFHLENBQUMrQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUN6QnpELENBQUMsQ0FBQ1csYUFBYSxHQUFHLENBQUMwSixZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUNwQ3JLLENBQUMsQ0FBQzhCLE1BQU0sR0FBRyxnQkFBZ0IsQ0FBQyxDQUFDO0lBQzdCLElBQUFzQyxhQUFNLGVBQUMsSUFBQTNFLFdBQUEsQ0FBQTRFLEdBQUEsRUFBQzdFLGdCQUFBLENBQUFJLE9BQVksSUFBRSxDQUFDLENBQUM7SUFDeEI7SUFDQTtJQUNBO0lBQ0EsSUFBQW1GLGNBQU0sRUFBQyxNQUFNVCxhQUFNLENBQUMyQixVQUFVLENBQUMsTUFBTSxFQUFFO01BQUVuRyxJQUFJLEVBQUU7SUFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQ3dGLGlCQUFpQixDQUFDLENBQUM7SUFDdEYsSUFBQVAsY0FBTSxFQUFDVCxhQUFNLENBQUMrQixXQUFXLENBQUMsTUFBTSxFQUFFO01BQUV2RyxJQUFJLEVBQUU7SUFBTyxDQUFDLENBQUMsQ0FBQyxDQUFDeUssUUFBUSxDQUFDLENBQUM7SUFDL0Q7SUFDQSxJQUFBeEYsY0FBTSxFQUFDVCxhQUFNLENBQUNHLFNBQVMsQ0FBQyxPQUFPLEVBQUU7TUFBRTNFLElBQUksRUFBRTtJQUF1QixDQUFDLENBQUMsQ0FBQyxDQUFDd0YsaUJBQWlCLENBQUMsQ0FBQztFQUN6RixDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7QUFFRixJQUFBVCxnQkFBUSxFQUFDLG1FQUFtRSxFQUFFLE1BQU07RUFDbEYsTUFBTTJGLGFBQWEsR0FBR0EsQ0FBQSxNQUFPO0lBQzNCbEssSUFBSSxFQUFFLFdBQVc7SUFDakJxQixJQUFJLEVBQUUsdUJBQXVCO0lBQzdCeUIsRUFBRSxFQUFFLHVCQUF1QjtJQUMzQnRELElBQUksRUFBRSx1QkFBdUI7SUFDN0JrRyxJQUFJLEVBQUU7RUFDUixDQUFDLENBQUM7RUFFRixJQUFBdEMsa0JBQVUsRUFBQyxNQUFNO0lBQ2YrRyxZQUFZLENBQUM5RyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDeEIsQ0FBQyxDQUFDO0VBRUYsSUFBQW1CLFVBQUUsRUFBQywyRUFBMkUsRUFBRSxZQUFZO0lBQzFGOUUsQ0FBQyxDQUFDVSxNQUFNLEdBQUcsQ0FBQytDLFFBQVEsQ0FBQyxDQUFDLEVBQUUrRyxhQUFhLENBQUMsQ0FBQyxDQUFDO0lBQ3hDeEssQ0FBQyxDQUFDNEIsZ0JBQWdCLENBQUM4SSxpQkFBaUIsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUN0RCxJQUFBdEcsYUFBTSxlQUFDLElBQUEzRSxXQUFBLENBQUE0RSxHQUFBLEVBQUM3RSxnQkFBQSxDQUFBSSxPQUFZLElBQUUsQ0FBQyxDQUFDOztJQUV4QjtJQUNBLElBQUFtRixjQUFNLEVBQUMsTUFBTVQsYUFBTSxDQUFDMkIsVUFBVSxDQUFDLE1BQU0sRUFBRTtNQUFFbkcsSUFBSSxFQUFFO0lBQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQ3dGLGlCQUFpQixDQUFDLENBQUM7SUFDN0U7SUFDQSxJQUFBUCxjQUFNLEVBQUNULGFBQU0sQ0FBQytCLFdBQVcsQ0FBQyxNQUFNLEVBQUU7TUFBRXZHLElBQUksRUFBRTtJQUF3QixDQUFDLENBQUMsQ0FBQyxDQUFDeUssUUFBUSxDQUFDLENBQUM7SUFDaEYsSUFBQXhGLGNBQU0sRUFBQ1QsYUFBTSxDQUFDcUcsWUFBWSxDQUFDLDBCQUEwQixDQUFDLENBQUMsQ0FBQ0osUUFBUSxDQUFDLENBQUM7SUFDbEU7SUFDQSxJQUFBeEYsY0FBTSxFQUFDVCxhQUFNLENBQUNHLFNBQVMsQ0FBQyxRQUFRLEVBQUU7TUFBRTNFLElBQUksRUFBRTtJQUF1QixDQUFDLENBQUMsQ0FBQyxDQUFDb0YsZUFBZSxDQUNsRixjQUFjLEVBQ2QsT0FDRixDQUFDO0VBQ0gsQ0FBQyxDQUFDO0VBRUYsSUFBQUosVUFBRSxFQUFDLHVGQUF1RixFQUFFLFlBQVk7SUFDdEc5RSxDQUFDLENBQUNVLE1BQU0sR0FBRyxDQUFDK0MsUUFBUSxDQUFDLENBQUMsRUFBRStHLGFBQWEsQ0FBQyxDQUFDLENBQUM7SUFDeEN4SyxDQUFDLENBQUM0QixnQkFBZ0IsQ0FBQzhJLGlCQUFpQixDQUFDLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDcEQsTUFBTTFHLElBQUksR0FBR0Msa0JBQVMsQ0FBQ0MsS0FBSyxDQUFDLENBQUM7SUFDOUIsSUFBQUUsYUFBTSxlQUFDLElBQUEzRSxXQUFBLENBQUE0RSxHQUFBLEVBQUM3RSxnQkFBQSxDQUFBSSxPQUFZLElBQUUsQ0FBQyxDQUFDO0lBQ3hCLE1BQU0wRSxhQUFNLENBQUMyQixVQUFVLENBQUMsTUFBTSxFQUFFO01BQUVuRyxJQUFJLEVBQUU7SUFBTyxDQUFDLENBQUM7SUFFakQsTUFBTWtFLElBQUksQ0FBQ1csS0FBSyxDQUFDTCxhQUFNLENBQUNHLFNBQVMsQ0FBQyxRQUFRLEVBQUU7TUFBRTNFLElBQUksRUFBRTtJQUF1QixDQUFDLENBQUMsQ0FBQztJQUU5RSxJQUFBaUYsY0FBTSxFQUFDLE1BQU1ULGFBQU0sQ0FBQzJCLFVBQVUsQ0FBQyxNQUFNLEVBQUU7TUFBRW5HLElBQUksRUFBRTtJQUF3QixDQUFDLENBQUMsQ0FBQyxDQUFDd0YsaUJBQWlCLENBQUMsQ0FBQztJQUM5RixJQUFBUCxjQUFNLEVBQUMsTUFBTVQsYUFBTSxDQUFDc0csV0FBVyxDQUFDLDBCQUEwQixDQUFDLENBQUMsQ0FBQ3RGLGlCQUFpQixDQUFDLENBQUM7SUFDaEY7SUFDQSxJQUFBUCxjQUFNLEVBQUNULGFBQU0sQ0FBQ0csU0FBUyxDQUFDLE1BQU0sRUFBRTtNQUFFM0UsSUFBSSxFQUFFO0lBQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQ3dGLGlCQUFpQixDQUFDLENBQUM7SUFDdEUsSUFBQVAsY0FBTSxFQUFDMEYsWUFBWSxDQUFDSSxPQUFPLENBQUMsb0NBQW9DLENBQUMsQ0FBQyxDQUFDL0UsSUFBSSxDQUFDLEdBQUcsQ0FBQztJQUM1RTtJQUNBLElBQUFmLGNBQU0sRUFBQ1QsYUFBTSxDQUFDRyxTQUFTLENBQUMsUUFBUSxFQUFFO01BQUUzRSxJQUFJLEVBQUU7SUFBNEIsQ0FBQyxDQUFDLENBQUMsQ0FBQ29GLGVBQWUsQ0FDdkYsY0FBYyxFQUNkLE1BQ0YsQ0FBQztFQUNILENBQUMsQ0FBQztFQUVGLElBQUFKLFVBQUUsRUFBQyw4REFBOEQsRUFBRSxZQUFZO0lBQzdFOUUsQ0FBQyxDQUFDVSxNQUFNLEdBQUcsQ0FBQytDLFFBQVEsQ0FBQyxDQUFDLENBQUM7SUFDdkJ6RCxDQUFDLENBQUM0QixnQkFBZ0IsQ0FBQzhJLGlCQUFpQixDQUFDLEVBQUUsQ0FBQztJQUN4QyxJQUFBdEcsYUFBTSxlQUFDLElBQUEzRSxXQUFBLENBQUE0RSxHQUFBLEVBQUM3RSxnQkFBQSxDQUFBSSxPQUFZLElBQUUsQ0FBQyxDQUFDO0lBQ3hCLE1BQU0wRSxhQUFNLENBQUMyQixVQUFVLENBQUMsTUFBTSxFQUFFO01BQUVuRyxJQUFJLEVBQUU7SUFBTyxDQUFDLENBQUM7SUFDakQsSUFBQWlGLGNBQU0sRUFBQ1QsYUFBTSxDQUFDK0IsV0FBVyxDQUFDLFFBQVEsRUFBRTtNQUFFdkcsSUFBSSxFQUFFO0lBQXVCLENBQUMsQ0FBQyxDQUFDLENBQUN5SyxRQUFRLENBQUMsQ0FBQztFQUNuRixDQUFDLENBQUM7RUFFRixJQUFBekYsVUFBRSxFQUFDLDRFQUE0RSxFQUFFLFlBQVk7SUFDM0Y7SUFDQTtJQUNBO0lBQ0E5RSxDQUFDLENBQUNVLE1BQU0sR0FBRyxDQUFDOEosYUFBYSxDQUFDLENBQUMsQ0FBQztJQUM1QnhLLENBQUMsQ0FBQzRCLGdCQUFnQixDQUFDOEksaUJBQWlCLENBQUMsRUFBRSxDQUFDO0lBQ3hDLE1BQU0xRyxJQUFJLEdBQUdDLGtCQUFTLENBQUNDLEtBQUssQ0FBQyxDQUFDO0lBQzlCLElBQUFFLGFBQU0sZUFBQyxJQUFBM0UsV0FBQSxDQUFBNEUsR0FBQSxFQUFDN0UsZ0JBQUEsQ0FBQUksT0FBWSxJQUFFLENBQUMsQ0FBQztJQUV4QixNQUFNa0wsTUFBTSxHQUFHLE1BQU14RyxhQUFNLENBQUMyQixVQUFVLENBQUMsUUFBUSxFQUFFO01BQUVuRyxJQUFJLEVBQUU7SUFBdUIsQ0FBQyxDQUFDO0lBQ2xGLElBQUFpRixjQUFNLEVBQUNULGFBQU0sQ0FBQytCLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDa0UsUUFBUSxDQUFDLENBQUM7SUFDN0MsTUFBTXZHLElBQUksQ0FBQ1csS0FBSyxDQUFDbUcsTUFBTSxDQUFDO0lBQ3hCLElBQUEvRixjQUFNLEVBQUMsTUFBTVQsYUFBTSxDQUFDMkIsVUFBVSxDQUFDLE1BQU0sRUFBRTtNQUFFbkcsSUFBSSxFQUFFO0lBQXdCLENBQUMsQ0FBQyxDQUFDLENBQUN3RixpQkFBaUIsQ0FBQyxDQUFDO0VBQ2hHLENBQUMsQ0FBQztFQUVGLElBQUFSLFVBQUUsRUFBQyw4RUFBOEUsRUFBRSxZQUFZO0lBQzdGOUUsQ0FBQyxDQUFDVSxNQUFNLEdBQUcsQ0FBQytDLFFBQVEsQ0FBQyxDQUFDLENBQUM7SUFDdkJ6RCxDQUFDLENBQUNXLGFBQWEsR0FBRyxDQUNoQjtNQUFFTCxJQUFJLEVBQUUsT0FBTztNQUFFcUIsSUFBSSxFQUFFLFdBQVc7TUFBRXlCLEVBQUUsRUFBRSxTQUFTO01BQUV0RCxJQUFJLEVBQUUsZUFBZTtNQUFFa0csSUFBSSxFQUFFLElBQUk7TUFBRXNFLGNBQWMsRUFBRTtJQUFNLENBQUMsRUFDN0c7TUFBRSxHQUFHRSxhQUFhLENBQUMsQ0FBQztNQUFFRixjQUFjLEVBQUU7SUFBTSxDQUFDLENBQzlDO0lBQ0R0SyxDQUFDLENBQUM4QixNQUFNLEdBQUcsZ0JBQWdCLENBQUMsQ0FBQztJQUM3QjlCLENBQUMsQ0FBQzRCLGdCQUFnQixDQUFDOEksaUJBQWlCLENBQUMsRUFBRSxDQUFDO0lBQ3hDLE1BQU0xRyxJQUFJLEdBQUdDLGtCQUFTLENBQUNDLEtBQUssQ0FBQyxDQUFDO0lBQzlCLElBQUFFLGFBQU0sZUFBQyxJQUFBM0UsV0FBQSxDQUFBNEUsR0FBQSxFQUFDN0UsZ0JBQUEsQ0FBQUksT0FBWSxJQUFFLENBQUMsQ0FBQztJQUV4QixJQUFBbUYsY0FBTSxFQUFDLE1BQU1ULGFBQU0sQ0FBQzJCLFVBQVUsQ0FBQyxNQUFNLEVBQUU7TUFBRW5HLElBQUksRUFBRTtJQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDd0YsaUJBQWlCLENBQUMsQ0FBQztJQUN0RixJQUFBUCxjQUFNLEVBQUNULGFBQU0sQ0FBQytCLFdBQVcsQ0FBQyxNQUFNLEVBQUU7TUFBRXZHLElBQUksRUFBRTtJQUF3QixDQUFDLENBQUMsQ0FBQyxDQUFDeUssUUFBUSxDQUFDLENBQUM7SUFDaEY7SUFDQTtJQUNBLElBQUF4RixjQUFNLEVBQUNULGFBQU0sQ0FBQ0csU0FBUyxDQUFDLE9BQU8sRUFBRTtNQUFFM0UsSUFBSSxFQUFFO0lBQXVCLENBQUMsQ0FBQyxDQUFDLENBQUN3RixpQkFBaUIsQ0FBQyxDQUFDO0lBRXZGLE1BQU10QixJQUFJLENBQUNXLEtBQUssQ0FBQ0wsYUFBTSxDQUFDRyxTQUFTLENBQUMsUUFBUSxFQUFFO01BQUUzRSxJQUFJLEVBQUU7SUFBdUIsQ0FBQyxDQUFDLENBQUM7SUFDOUUsSUFBQWlGLGNBQU0sRUFBQyxNQUFNVCxhQUFNLENBQUMyQixVQUFVLENBQUMsTUFBTSxFQUFFO01BQUVuRyxJQUFJLEVBQUU7SUFBd0IsQ0FBQyxDQUFDLENBQUMsQ0FBQ3dGLGlCQUFpQixDQUFDLENBQUM7RUFDaEcsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDO0FBRUYsSUFBQVQsZ0JBQVEsRUFBQyxtRUFBbUUsRUFBRSxNQUFNO0VBQ2xGO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxJQUFBbkIsa0JBQVUsRUFBQyxNQUFNO0lBQ2YrRyxZQUFZLENBQUM5RyxLQUFLLENBQUMsQ0FBQztJQUNwQjhHLFlBQVksQ0FBQ00sT0FBTyxDQUFDLG9DQUFvQyxFQUFFLEdBQUcsQ0FBQztFQUNqRSxDQUFDLENBQUM7RUFFRixJQUFBakcsVUFBRSxFQUFDLCtEQUErRCxFQUFFLFlBQVk7SUFDOUU5RSxDQUFDLENBQUNVLE1BQU0sR0FBRyxDQUFDK0MsUUFBUSxDQUFDLENBQUMsQ0FBQztJQUN2QnpELENBQUMsQ0FBQzRCLGdCQUFnQixDQUFDOEksaUJBQWlCLENBQUMsQ0FBQywrQkFBK0IsQ0FBQyxDQUFDO0lBQ3ZFLElBQUF0RyxhQUFNLGVBQUMsSUFBQTNFLFdBQUEsQ0FBQTRFLEdBQUEsRUFBQzdFLGdCQUFBLENBQUFJLE9BQVksSUFBRSxDQUFDLENBQUM7SUFFeEIsTUFBTW9MLEdBQUcsR0FBRyxNQUFNMUcsYUFBTSxDQUFDc0csV0FBVyxDQUFDLDZDQUE2QyxDQUFDO0lBQ25GLE1BQU14RCxLQUFLLEdBQUc0RCxHQUFHLENBQUNsQixhQUFhLENBQUMsc0JBQXNCLENBQUM7SUFDdkQsSUFBQS9FLGNBQU0sRUFBQ3FDLEtBQUssQ0FBQyxDQUFDMUIsR0FBRyxDQUFDNkUsUUFBUSxDQUFDLENBQUM7SUFDNUIsSUFBQXhGLGNBQU0sRUFBQ3FDLEtBQUssQ0FBQyxDQUFDOEIsaUJBQWlCLENBQUMsMENBQTBDLENBQUM7SUFDM0U7SUFDQTtJQUNBLElBQUFuRSxjQUFNLEVBQUNpRyxHQUFHLENBQUNwRSxXQUFXLENBQUMsQ0FBQ2QsSUFBSSxDQUFDc0IsS0FBSyxDQUFFUixXQUFXLENBQUM7RUFDbEQsQ0FBQyxDQUFDO0VBRUYsSUFBQTlCLFVBQUUsRUFBQyw2RUFBNkUsRUFBRSxZQUFZO0lBQzVGOUUsQ0FBQyxDQUFDVSxNQUFNLEdBQUcsQ0FBQytDLFFBQVEsQ0FBQyxDQUFDLENBQUM7SUFDdkJ6RCxDQUFDLENBQUM0QixnQkFBZ0IsQ0FBQzhJLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDNUMsSUFBQXRHLGFBQU0sZUFBQyxJQUFBM0UsV0FBQSxDQUFBNEUsR0FBQSxFQUFDN0UsZ0JBQUEsQ0FBQUksT0FBWSxJQUFFLENBQUMsQ0FBQztJQUN4QixNQUFNMEUsYUFBTSxDQUFDc0csV0FBVyxDQUFDLGtCQUFrQixDQUFDO0lBQzVDLElBQUE3RixjQUFNLEVBQUMyRSxRQUFRLENBQUNJLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUNyRSxXQUFXLENBQUMsdUJBQXVCLENBQUM7RUFDeEYsQ0FBQyxDQUFDOztFQUVGO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxJQUFBWCxVQUFFLEVBQUMsa0VBQWtFLEVBQUUsWUFBWTtJQUNqRjlFLENBQUMsQ0FBQ1UsTUFBTSxHQUFHLENBQUMrQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0lBQ3ZCekQsQ0FBQyxDQUFDNEIsZ0JBQWdCLENBQUM4SSxpQkFBaUIsQ0FBQyxDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsT0FBTyxDQUFDLENBQUM7SUFDN0QsSUFBQXRHLGFBQU0sZUFBQyxJQUFBM0UsV0FBQSxDQUFBNEUsR0FBQSxFQUFDN0UsZ0JBQUEsQ0FBQUksT0FBWSxJQUFFLENBQUMsQ0FBQztJQUN4QixNQUFNMEUsYUFBTSxDQUFDc0csV0FBVyxDQUFDLG1CQUFtQixDQUFDO0lBRTdDLE1BQU1LLElBQUksR0FBR3ZCLFFBQVEsQ0FBQ0ksYUFBYSxDQUFDLGNBQWMsQ0FBQztJQUNuRCxJQUFBL0UsY0FBTSxFQUFDa0csSUFBSSxDQUFDLENBQUN2RixHQUFHLENBQUM2RSxRQUFRLENBQUMsQ0FBQztJQUMzQixJQUFBeEYsY0FBTSxFQUFDa0csSUFBSSxDQUFFQyxnQkFBZ0IsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDbkUsWUFBWSxDQUFDLENBQUMsQ0FBQztJQUMvRCxJQUFBaEMsY0FBTSxFQUFDMkUsUUFBUSxDQUFDSSxhQUFhLENBQUMsaUJBQWlCLENBQUMsQ0FBRW9CLGdCQUFnQixDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUNuRSxZQUFZLENBQUMsQ0FBQyxDQUFDO0lBQ3BHO0lBQ0EsSUFBQWhDLGNBQU0sRUFDSjJFLFFBQVEsQ0FBQ0ksYUFBYSxDQUFDLGlCQUFpQixDQUFDLENBQUVBLGFBQWEsQ0FBQyw2QkFBNkIsQ0FDeEYsQ0FBQyxDQUFDcEUsR0FBRyxDQUFDNkUsUUFBUSxDQUFDLENBQUM7RUFDbEIsQ0FBQyxDQUFDO0VBRUYsSUFBQXpGLFVBQUUsRUFBQyxrREFBa0QsRUFBRSxZQUFZO0lBQ2pFOUUsQ0FBQyxDQUFDVSxNQUFNLEdBQUcsQ0FBQytDLFFBQVEsQ0FBQyxDQUFDLENBQUM7SUFDdkJ6RCxDQUFDLENBQUM0QixnQkFBZ0IsQ0FBQzhJLGlCQUFpQixDQUFDLEVBQUUsQ0FBQztJQUN4QyxJQUFBdEcsYUFBTSxlQUFDLElBQUEzRSxXQUFBLENBQUE0RSxHQUFBLEVBQUM3RSxnQkFBQSxDQUFBSSxPQUFZLElBQUUsQ0FBQyxDQUFDO0lBQ3hCLE1BQU0wRSxhQUFNLENBQUNDLFVBQVUsQ0FBQyxLQUFLLENBQUM7SUFDOUIsSUFBQVEsY0FBTSxFQUFDMkUsUUFBUSxDQUFDSSxhQUFhLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQ1MsUUFBUSxDQUFDLENBQUM7RUFDM0QsQ0FBQyxDQUFDO0VBRUYsSUFBQXpGLFVBQUUsRUFBQyx3REFBd0QsRUFBRSxZQUFZO0lBQ3ZFLE1BQU1kLElBQUksR0FBR0Msa0JBQVMsQ0FBQ0MsS0FBSyxDQUFDLENBQUM7SUFDOUJsRSxDQUFDLENBQUNVLE1BQU0sR0FBRyxDQUFDK0MsUUFBUSxDQUFDLENBQUMsQ0FBQztJQUN2QnpELENBQUMsQ0FBQzRCLGdCQUFnQixDQUFDOEksaUJBQWlCLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUM1QyxJQUFBdEcsYUFBTSxlQUFDLElBQUEzRSxXQUFBLENBQUE0RSxHQUFBLEVBQUM3RSxnQkFBQSxDQUFBSSxPQUFZLElBQUUsQ0FBQyxDQUFDO0lBQ3hCLE1BQU0wRSxhQUFNLENBQUNzRyxXQUFXLENBQUMsa0JBQWtCLENBQUM7SUFDNUMsSUFBQTdGLGNBQU0sRUFBQzJFLFFBQVEsQ0FBQ0ksYUFBYSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUNwRSxHQUFHLENBQUM2RSxRQUFRLENBQUMsQ0FBQztJQUU3RCxNQUFNdkcsSUFBSSxDQUFDVyxLQUFLLENBQUNMLGFBQU0sQ0FBQ0csU0FBUyxDQUFDLFFBQVEsRUFBRTtNQUFFM0UsSUFBSSxFQUFFO0lBQTRCLENBQUMsQ0FBQyxDQUFDO0lBRW5GLElBQUFpRixjQUFNLEVBQUMyRSxRQUFRLENBQUNJLGFBQWEsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDUyxRQUFRLENBQUMsQ0FBQztFQUMzRCxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7O0FBRUY7QUFDQSxJQUFBMUYsZ0JBQVEsRUFBQyx1Q0FBdUMsRUFBRSxNQUFNO0VBQ3RELElBQUFDLFVBQUUsRUFBQywrRUFBK0UsRUFBRSxZQUFZO0lBQzlGOUUsQ0FBQyxDQUFDYSxVQUFVLEdBQUcsZUFBZTtJQUM5QixJQUFBdUQsYUFBTSxlQUFDLElBQUEzRSxXQUFBLENBQUE0RSxHQUFBLEVBQUM3RSxnQkFBQSxDQUFBSSxPQUFZLElBQUUsQ0FBQyxDQUFDO0lBQ3hCLE1BQU0wRSxhQUFNLENBQUNDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0lBQ2hDO0lBQ0EsSUFBQVEsY0FBTSxFQUNKLE1BQU1ULGFBQU0sQ0FBQzJCLFVBQVUsQ0FBQyxLQUFLLEVBQUU7TUFBRW5HLElBQUksRUFBRTtJQUE2QyxDQUFDLENBQ3ZGLENBQUMsQ0FBQ3dGLGlCQUFpQixDQUFDLENBQUM7SUFDckIsSUFBQVAsY0FBTSxFQUFDVCxhQUFNLENBQUM2RyxXQUFXLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQ3pGLEdBQUcsQ0FBQ0osaUJBQWlCLENBQUMsQ0FBQztFQUNoRSxDQUFDLENBQUM7RUFFRixJQUFBUixVQUFFLEVBQUMsNkhBQTZILEVBQUUsWUFBWTtJQUM1SSxNQUFNc0csTUFBTSxHQUFHcEwsQ0FBQyxDQUFDa0Isd0JBQXdCLENBQUMyRSxNQUFNO0lBQ2hELElBQUF6QixhQUFNLGVBQUMsSUFBQTNFLFdBQUEsQ0FBQTRFLEdBQUEsRUFBQzdFLGdCQUFBLENBQUFJLE9BQVksSUFBRSxDQUFDLENBQUM7SUFDeEIsTUFBTTBFLGFBQU0sQ0FBQ0MsVUFBVSxDQUFDLEtBQUssQ0FBQztJQUM5QixNQUFNOEcsSUFBSSxHQUFHckwsQ0FBQyxDQUFDa0Isd0JBQXdCLENBQUNvSyxLQUFLLENBQUNGLE1BQU0sQ0FBQztJQUNyRCxJQUFBckcsY0FBTSxFQUFDc0csSUFBSSxDQUFDLENBQUN0RSxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUM5QjtJQUNBO0lBQ0E7SUFDQSxJQUFBaEMsY0FBTSxFQUFDc0csSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUN2RixJQUFJLENBQUMsQ0FBQyxDQUFDO0VBQ3pCLENBQUMsQ0FBQztFQUVGLElBQUFoQixVQUFFLEVBQUMsNEZBQTRGLEVBQUUsWUFBWTtJQUMzRyxNQUFNeUcsT0FBa0IsR0FBRyxFQUFFO0lBQzdCLE1BQU1DLElBQUksR0FBR0MsT0FBTyxDQUFDQyxTQUFTLENBQUNDLGNBQWM7SUFDN0NGLE9BQU8sQ0FBQ0MsU0FBUyxDQUFDQyxjQUFjLEdBQUcsWUFBWTtNQUM3Q0osT0FBTyxDQUFDcEssSUFBSSxDQUFDLElBQUksQ0FBQztJQUNwQixDQUFDO0lBQ0QsSUFBSTtNQUNGO01BQ0E7TUFDQTtNQUNBO01BQ0FuQixDQUFDLENBQUNhLFVBQVUsR0FBRyxlQUFlO01BQzlCYixDQUFDLENBQUNVLE1BQU0sR0FBRyxFQUFFO01BQ2IsTUFBTTtRQUFFNkU7TUFBUyxDQUFDLEdBQUcsSUFBQW5CLGFBQU0sZUFBQyxJQUFBM0UsV0FBQSxDQUFBNEUsR0FBQSxFQUFDN0UsZ0JBQUEsQ0FBQUksT0FBWSxJQUFFLENBQUMsQ0FBQztNQUM3QyxJQUFBZ00sVUFBRyxFQUFDLE1BQU01TCxDQUFDLENBQUNLLElBQUksQ0FBQyxlQUFlLEVBQUU7UUFBRUMsSUFBSSxFQUFFLGVBQWU7UUFBRXFCLElBQUksRUFBRTtNQUFnQixDQUFDLENBQUMsQ0FBQztNQUNwRixJQUFBb0QsY0FBTSxFQUFDVCxhQUFNLENBQUM2RyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQ3pGLEdBQUcsQ0FBQ0osaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUM7O01BRTNEO01BQ0F0RixDQUFDLENBQUNVLE1BQU0sR0FBRyxDQUFDK0MsUUFBUSxDQUFDLENBQUMsQ0FBQztNQUN2QjhCLFFBQVEsY0FBQyxJQUFBOUYsV0FBQSxDQUFBNEUsR0FBQSxFQUFDN0UsZ0JBQUEsQ0FBQUksT0FBWSxJQUFFLENBQUMsQ0FBQztNQUUxQixNQUFNNEUsR0FBRyxHQUFHLE1BQU1GLGFBQU0sQ0FBQ0MsVUFBVSxDQUFDLEtBQUssQ0FBQztNQUMxQyxJQUFBUSxjQUFNLEVBQUNQLEdBQUcsQ0FBQyxDQUFDYyxpQkFBaUIsQ0FBQyxDQUFDO01BQy9CO01BQ0EsTUFBTXVHLEdBQUcsR0FBRyxNQUFNdkgsYUFBTSxDQUFDQyxVQUFVLENBQUMsVUFBVSxDQUFDO01BQy9DLElBQUFRLGNBQU0sRUFBQzhHLEdBQUcsQ0FBQyxDQUFDdkcsaUJBQWlCLENBQUMsQ0FBQztNQUMvQjtNQUNBLElBQUFQLGNBQU0sRUFDSixNQUFNVCxhQUFNLENBQUMyQixVQUFVLENBQUMsS0FBSyxFQUFFO1FBQUVuRyxJQUFJLEVBQUU7TUFBMkIsQ0FBQyxDQUNyRSxDQUFDLENBQUN3RixpQkFBaUIsQ0FBQyxDQUFDO01BQ3JCLE1BQU0sSUFBQStELGNBQU8sRUFBQyxNQUFNLElBQUF0RSxjQUFNLEVBQUN3RyxPQUFPLENBQUMxRixNQUFNLENBQUMsQ0FBQ2lHLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUNoRSxDQUFDLFNBQVM7TUFDUkwsT0FBTyxDQUFDQyxTQUFTLENBQUNDLGNBQWMsR0FBR0gsSUFBSTtJQUN6QztFQUNGLENBQUMsQ0FBQztFQUVGLElBQUExRyxVQUFFLEVBQUMsNEZBQTRGLEVBQUUsWUFBWTtJQUMzRyxNQUFNeUcsT0FBa0IsR0FBRyxFQUFFO0lBQzdCLE1BQU1DLElBQUksR0FBR0MsT0FBTyxDQUFDQyxTQUFTLENBQUNDLGNBQWM7SUFDN0NGLE9BQU8sQ0FBQ0MsU0FBUyxDQUFDQyxjQUFjLEdBQUcsWUFBWTtNQUM3Q0osT0FBTyxDQUFDcEssSUFBSSxDQUFDLElBQUksQ0FBQztJQUNwQixDQUFDO0lBQ0QsSUFBSTtNQUNGbkIsQ0FBQyxDQUFDYSxVQUFVLEdBQUcsZUFBZTtNQUM5QixJQUFBdUQsYUFBTSxlQUFDLElBQUEzRSxXQUFBLENBQUE0RSxHQUFBLEVBQUM3RSxnQkFBQSxDQUFBSSxPQUFZLElBQUUsQ0FBQyxDQUFDO01BQ3hCLE1BQU0wRSxhQUFNLENBQUNDLFVBQVUsQ0FBQyxLQUFLLENBQUM7TUFDOUIsTUFBTTZHLE1BQU0sR0FBRzFCLFFBQVEsQ0FBQ3FDLGFBQWE7TUFFckMsSUFBQUgsVUFBRyxFQUFDLE1BQU01TCxDQUFDLENBQUNLLElBQUksQ0FBQyxlQUFlLEVBQUU7UUFBRUMsSUFBSSxFQUFFLGVBQWU7UUFBRXFCLElBQUksRUFBRTtNQUFnQixDQUFDLENBQUMsQ0FBQzs7TUFFcEY7TUFDQSxNQUFNa0ssR0FBRyxHQUFHLE1BQU12SCxhQUFNLENBQUNDLFVBQVUsQ0FBQyxVQUFVLENBQUM7TUFDL0MsSUFBQVEsY0FBTSxFQUFDOEcsR0FBRyxDQUFDLENBQUN2RyxpQkFBaUIsQ0FBQyxDQUFDO01BQy9CLElBQUFQLGNBQU0sRUFDSixNQUFNVCxhQUFNLENBQUMyQixVQUFVLENBQUMsS0FBSyxFQUFFO1FBQUVuRyxJQUFJLEVBQUU7TUFBMkIsQ0FBQyxDQUNyRSxDQUFDLENBQUN3RixpQkFBaUIsQ0FBQyxDQUFDO01BQ3JCO01BQ0EsTUFBTSxJQUFBK0QsY0FBTyxFQUFDLE1BQU0sSUFBQXRFLGNBQU0sRUFBQ3dHLE9BQU8sQ0FBQzFGLE1BQU0sQ0FBQyxDQUFDaUcsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDO01BQzlEO01BQ0EsSUFBQS9HLGNBQU0sRUFBQzJFLFFBQVEsQ0FBQ3FDLGFBQWEsQ0FBQyxDQUFDakcsSUFBSSxDQUFDc0YsTUFBTSxDQUFDO0lBQzdDLENBQUMsU0FBUztNQUNSSyxPQUFPLENBQUNDLFNBQVMsQ0FBQ0MsY0FBYyxHQUFHSCxJQUFJO0lBQ3pDO0VBQ0YsQ0FBQyxDQUFDO0VBRUYsSUFBQTFHLFVBQUUsRUFBQywyRUFBMkUsRUFBRSxZQUFZO0lBQzFGOUUsQ0FBQyxDQUFDYSxVQUFVLEdBQUcsZUFBZTtJQUM5QixJQUFBdUQsYUFBTSxlQUFDLElBQUEzRSxXQUFBLENBQUE0RSxHQUFBLEVBQUM3RSxnQkFBQSxDQUFBSSxPQUFZLElBQUUsQ0FBQyxDQUFDO0lBQ3hCLE1BQU0wRSxhQUFNLENBQUNDLFVBQVUsQ0FBQyxLQUFLLENBQUM7SUFDOUIsTUFBTSxJQUFJeEQsT0FBTyxDQUFFaUwsQ0FBQyxJQUFLQyxVQUFVLENBQUNELENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztJQUMzQyxJQUFBakgsY0FBTSxFQUFDVCxhQUFNLENBQUM2RyxXQUFXLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQ3pGLEdBQUcsQ0FBQ0osaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDbEUsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDOztBQUVGO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBQVQsZ0JBQVEsRUFBQywrQkFBK0IsRUFBRSxNQUFNO0VBQzlDLElBQUFDLFVBQUUsRUFBQyxzRkFBc0YsRUFBRSxZQUFZO0lBQ3JHLE1BQU15RyxPQUFrQixHQUFHLEVBQUU7SUFDN0IsTUFBTUMsSUFBSSxHQUFHQyxPQUFPLENBQUNDLFNBQVMsQ0FBQ0MsY0FBYztJQUM3Q0YsT0FBTyxDQUFDQyxTQUFTLENBQUNDLGNBQWMsR0FBRyxZQUFZO01BQzdDSixPQUFPLENBQUNwSyxJQUFJLENBQUMsSUFBSSxDQUFDO0lBQ3BCLENBQUM7SUFDRCxJQUFJO01BQ0ZuQixDQUFDLENBQUNZLFVBQVUsR0FBRyxlQUFlO01BQzlCLElBQUF3RCxhQUFNLGVBQUMsSUFBQTNFLFdBQUEsQ0FBQTRFLEdBQUEsRUFBQzdFLGdCQUFBLENBQUFJLE9BQVksSUFBRSxDQUFDLENBQUM7TUFDeEIsTUFBTTBFLGFBQU0sQ0FBQ0MsVUFBVSxDQUFDLEtBQUssQ0FBQztNQUM5QixNQUFNNkcsTUFBTSxHQUFHMUIsUUFBUSxDQUFDcUMsYUFBYTs7TUFFckM7TUFDQSxJQUFBaEgsY0FBTSxFQUFDLE1BQU1ULGFBQU0sQ0FBQ0MsVUFBVSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUNlLGlCQUFpQixDQUFDLENBQUM7TUFDL0QsSUFBQVAsY0FBTSxFQUFDVCxhQUFNLENBQUNHLFNBQVMsQ0FBQyxVQUFVLEVBQUU7UUFBRTNFLElBQUksRUFBRTtNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUNvRixlQUFlLENBQ25FLGVBQWUsRUFDZixNQUNGLENBQUM7TUFDRCxNQUFNLElBQUFtRSxjQUFPLEVBQUMsTUFBTSxJQUFBdEUsY0FBTSxFQUFDd0csT0FBTyxDQUFDMUYsTUFBTSxDQUFDLENBQUNpRyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUM7TUFDOUQ7TUFDQSxJQUFBL0csY0FBTSxFQUFDMkUsUUFBUSxDQUFDcUMsYUFBYSxDQUFDLENBQUNqRyxJQUFJLENBQUNzRixNQUFNLENBQUM7SUFDN0MsQ0FBQyxTQUFTO01BQ1JLLE9BQU8sQ0FBQ0MsU0FBUyxDQUFDQyxjQUFjLEdBQUdILElBQUk7SUFDekM7RUFDRixDQUFDLENBQUM7RUFFRixJQUFBMUcsVUFBRSxFQUFDLDhFQUE4RSxFQUFFLFlBQVk7SUFDN0Y5RSxDQUFDLENBQUNZLFVBQVUsR0FBRyxlQUFlO0lBQzlCLElBQUF3RCxhQUFNLGVBQUMsSUFBQTNFLFdBQUEsQ0FBQTRFLEdBQUEsRUFBQzdFLGdCQUFBLENBQUFJLE9BQVksSUFBRSxDQUFDLENBQUM7SUFDeEIsTUFBTTBFLGFBQU0sQ0FBQ0MsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7SUFDcEMsTUFBTTJILEtBQUssR0FBRzVILGFBQU0sQ0FBQzZILFlBQVksQ0FBQyxLQUFLLEVBQUU7TUFBRXJNLElBQUksRUFBRTtJQUFxQixDQUFDLENBQUM7SUFDeEUsSUFBQWlGLGNBQU0sRUFBQ21ILEtBQUssQ0FBQyxDQUFDbkYsWUFBWSxDQUFDLENBQUMsQ0FBQztJQUM3QixJQUFBaEMsY0FBTSxFQUFDbUgsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDOUcsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUNLLFdBQVcsQ0FBQyxlQUFlLENBQUM7SUFDbEUsSUFBQVYsY0FBTSxFQUFDbUgsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDOUcsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUNnSCxnQkFBZ0IsQ0FBQzlILGFBQU0sQ0FBQ00sU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0VBQ3RGLENBQUMsQ0FBQztFQUVGLElBQUFFLFVBQUUsRUFBQyw4RUFBOEUsRUFBRSxZQUFZO0lBQzdGOUUsQ0FBQyxDQUFDWSxVQUFVLEdBQUcsZUFBZTtJQUM5QixNQUFNb0QsSUFBSSxHQUFHQyxrQkFBUyxDQUFDQyxLQUFLLENBQUMsQ0FBQztJQUM5QixJQUFBRSxhQUFNLGVBQUMsSUFBQTNFLFdBQUEsQ0FBQTRFLEdBQUEsRUFBQzdFLGdCQUFBLENBQUFJLE9BQVksSUFBRSxDQUFDLENBQUM7SUFDeEIsTUFBTTBFLGFBQU0sQ0FBQ0MsVUFBVSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUM7O0lBRXJDLE1BQU1QLElBQUksQ0FBQ1csS0FBSyxDQUFDTCxhQUFNLENBQUNNLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7O0lBRTNDLElBQUFHLGNBQU0sRUFBQ1QsYUFBTSxDQUFDNkcsV0FBVyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUN6RixHQUFHLENBQUNKLGlCQUFpQixDQUFDLENBQUM7SUFDOUQsSUFBQVAsY0FBTSxFQUNKVCxhQUFNLENBQUNHLFNBQVMsQ0FBQyxLQUFLLEVBQUU7TUFBRTNFLElBQUksRUFBRTtJQUF1QyxDQUFDLENBQzFFLENBQUMsQ0FBQ3dGLGlCQUFpQixDQUFDLENBQUM7SUFDckI7SUFDQSxNQUFNLElBQUl2RSxPQUFPLENBQUVpTCxDQUFDLElBQUtDLFVBQVUsQ0FBQ0QsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQzVDLElBQUFqSCxjQUFNLEVBQUNULGFBQU0sQ0FBQzZHLFdBQVcsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDekYsR0FBRyxDQUFDSixpQkFBaUIsQ0FBQyxDQUFDO0VBQ2hFLENBQUMsQ0FBQztFQUVGLElBQUFSLFVBQUUsRUFBQywyRUFBMkUsRUFBRSxZQUFZO0lBQzFGO0lBQ0E7SUFDQTlFLENBQUMsQ0FBQ1UsTUFBTSxHQUFHLEVBQUU7SUFDYlYsQ0FBQyxDQUFDWSxVQUFVLEdBQUcsZUFBZTtJQUM5QixNQUFNO01BQUUyRTtJQUFTLENBQUMsR0FBRyxJQUFBbkIsYUFBTSxlQUFDLElBQUEzRSxXQUFBLENBQUE0RSxHQUFBLEVBQUM3RSxnQkFBQSxDQUFBSSxPQUFZLElBQUUsQ0FBQyxDQUFDO0lBQzdDLE1BQU0sSUFBSW1CLE9BQU8sQ0FBRWlMLENBQUMsSUFBS0MsVUFBVSxDQUFDRCxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7SUFDM0MsSUFBQWpILGNBQU0sRUFBQ1QsYUFBTSxDQUFDNkcsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUN6RixHQUFHLENBQUNKLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDOztJQUUzRHRGLENBQUMsQ0FBQ1UsTUFBTSxHQUFHLENBQUMrQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0lBQ3ZCOEIsUUFBUSxjQUFDLElBQUE5RixXQUFBLENBQUE0RSxHQUFBLEVBQUM3RSxnQkFBQSxDQUFBSSxPQUFZLElBQUUsQ0FBQyxDQUFDO0lBRTFCLElBQUFtRixjQUFNLEVBQUMsTUFBTVQsYUFBTSxDQUFDQyxVQUFVLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQ2UsaUJBQWlCLENBQUMsQ0FBQztJQUMvRCxJQUFBUCxjQUFNLEVBQUNULGFBQU0sQ0FBQ0csU0FBUyxDQUFDLFVBQVUsRUFBRTtNQUFFM0UsSUFBSSxFQUFFO0lBQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQ29GLGVBQWUsQ0FDbkUsZUFBZSxFQUNmLE1BQ0YsQ0FBQztFQUNILENBQUMsQ0FBQztFQUVGLElBQUFKLFVBQUUsRUFBQywwQ0FBMEMsRUFBRSxZQUFZO0lBQ3pEOUUsQ0FBQyxDQUFDWSxVQUFVLEdBQUcsSUFBSTtJQUNuQixJQUFBd0QsYUFBTSxlQUFDLElBQUEzRSxXQUFBLENBQUE0RSxHQUFBLEVBQUM3RSxnQkFBQSxDQUFBSSxPQUFZLElBQUUsQ0FBQyxDQUFDO0lBQ3hCLE1BQU0wRSxhQUFNLENBQUNDLFVBQVUsQ0FBQyxLQUFLLENBQUM7SUFDOUIsTUFBTSxJQUFJeEQsT0FBTyxDQUFFaUwsQ0FBQyxJQUFLQyxVQUFVLENBQUNELENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztJQUMzQyxJQUFBakgsY0FBTSxFQUFDVCxhQUFNLENBQUM2RyxXQUFXLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQ3pGLEdBQUcsQ0FBQ0osaUJBQWlCLENBQUMsQ0FBQztJQUM5RCxJQUFBUCxjQUFNLEVBQUNULGFBQU0sQ0FBQytCLFdBQVcsQ0FBQyxLQUFLLEVBQUU7TUFBRXZHLElBQUksRUFBRTtJQUFxQixDQUFDLENBQUMsQ0FBQyxDQUFDNEYsR0FBRyxDQUFDSixpQkFBaUIsQ0FBQyxDQUFDO0lBQ3pGLElBQUFQLGNBQU0sRUFDSlQsYUFBTSxDQUFDK0IsV0FBVyxDQUFDLEtBQUssRUFBRTtNQUFFdkcsSUFBSSxFQUFFO0lBQXVDLENBQUMsQ0FDNUUsQ0FBQyxDQUFDNEYsR0FBRyxDQUFDSixpQkFBaUIsQ0FBQyxDQUFDO0VBQzNCLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQzs7QUFFRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFBVCxnQkFBUSxFQUFDLDZEQUE2RCxFQUFFLE1BQU07RUFDNUUsTUFBTXdILElBQUksR0FBR0EsQ0FBQSxLQUFNLElBQUlqRCxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBRSxVQUFVLEVBQUU7SUFBRTlJLElBQUksRUFBRTtFQUFhLENBQUMsQ0FBQztFQUUxRSxJQUFBb0Qsa0JBQVUsRUFBQyxNQUFNO0lBQ2Y7SUFDQTtJQUNBK0csWUFBWSxDQUFDOUcsS0FBSyxDQUFDLENBQUM7RUFDdEIsQ0FBQyxDQUFDO0VBRUYsZUFBZTJJLFFBQVFBLENBQUNDLFNBQWlCLEVBQUU7SUFDekMsTUFBTXZJLElBQUksR0FBR0Msa0JBQVMsQ0FBQ0MsS0FBSyxDQUFDLENBQUM7SUFDOUIsTUFBTUgscUJBQXFCLENBQUMsQ0FBQztJQUM3QixNQUFNQyxJQUFJLENBQUNXLEtBQUssQ0FBQ0wsYUFBTSxDQUFDRyxTQUFTLENBQUMsT0FBTyxFQUFFO01BQUUzRSxJQUFJLEVBQUV5TTtJQUFVLENBQUMsQ0FBQyxDQUFDO0lBQ2hFLE9BQU92SSxJQUFJO0VBQ2I7RUFFQSxJQUFBYyxVQUFFLEVBQUMsK0RBQStELEVBQUUsWUFBWTtJQUM5RSxNQUFNZCxJQUFJLEdBQUcsTUFBTXNJLFFBQVEsQ0FBQyxXQUFXLENBQUM7SUFDeEMsTUFBTXRJLElBQUksQ0FBQ1csS0FBSyxDQUFDLE1BQU1MLGFBQU0sQ0FBQ0MsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUNuRCxNQUFNRCxhQUFNLENBQUNDLFVBQVUsQ0FBQyxLQUFLLENBQUM7SUFDOUIsTUFBTWlJLE1BQU0sR0FBRzlDLFFBQVEsQ0FBQ0ksYUFBYSxDQUFDLGVBQWUsQ0FBZ0I7SUFDckU3QyxnQkFBUyxDQUFDNkIsSUFBSSxDQUFDMEQsTUFBTSxFQUFFO01BQUVyRSxZQUFZLEVBQUVBLFlBQVksQ0FBQztRQUFFSSxLQUFLLEVBQUUsQ0FBQzhELElBQUksQ0FBQyxDQUFDO01BQUUsQ0FBQztJQUFFLENBQUMsQ0FBQztJQUMzRSxNQUFNcE0sVUFBRSxDQUFDb0osT0FBTyxDQUFDLE1BQU0sSUFBQXRFLGNBQU0sRUFBQy9FLENBQUMsQ0FBQ3VCLFVBQVUsQ0FBQyxDQUFDb0csZ0JBQWdCLENBQUMsQ0FBQyxDQUFDO0lBQy9ELElBQUE1QyxjQUFNLEVBQUMvRSxDQUFDLENBQUN1QixVQUFVLENBQUNRLElBQUksQ0FBQzZELEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDRSxJQUFJLENBQUMsV0FBVyxDQUFDO0VBQ3pELENBQUMsQ0FBQztFQUVGLElBQUFoQixVQUFFLEVBQUMsa0VBQWtFLEVBQUUsWUFBWTtJQUNqRixNQUFNZCxJQUFJLEdBQUcsTUFBTXNJLFFBQVEsQ0FBQyxXQUFXLENBQUM7SUFDeEMsTUFBTXRJLElBQUksQ0FBQ1csS0FBSyxDQUFDLE1BQU1MLGFBQU0sQ0FBQ0MsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ2pELE1BQU1ELGFBQU0sQ0FBQ0MsVUFBVSxDQUFDLEtBQUssQ0FBQztJQUM5QixNQUFNUCxJQUFJLENBQUNXLEtBQUssQ0FBQ0wsYUFBTSxDQUFDTSxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDekMsTUFBTU4sYUFBTSxDQUFDQyxVQUFVLENBQUMsVUFBVSxDQUFDO0lBQ25DLE1BQU1zSCxHQUFHLEdBQUd2SCxhQUFNLENBQUNNLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQ1EsT0FBTyxDQUFDLGFBQWEsQ0FBZ0I7SUFDOUU2QixnQkFBUyxDQUFDNkIsSUFBSSxDQUFDK0MsR0FBRyxFQUFFO01BQUUxRCxZQUFZLEVBQUVBLFlBQVksQ0FBQztRQUFFSSxLQUFLLEVBQUUsQ0FBQzhELElBQUksQ0FBQyxDQUFDO01BQUUsQ0FBQztJQUFFLENBQUMsQ0FBQztJQUN4RSxNQUFNcE0sVUFBRSxDQUFDb0osT0FBTyxDQUFDLE1BQU0sSUFBQXRFLGNBQU0sRUFBQy9FLENBQUMsQ0FBQ3VCLFVBQVUsQ0FBQyxDQUFDb0csZ0JBQWdCLENBQUMsQ0FBQyxDQUFDO0lBQy9ELElBQUE1QyxjQUFNLEVBQUMvRSxDQUFDLENBQUN1QixVQUFVLENBQUNRLElBQUksQ0FBQzZELEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDRSxJQUFJLENBQUMsZUFBZSxDQUFDO0VBQzdELENBQUMsQ0FBQztFQUVGLElBQUFoQixVQUFFLEVBQUMsZ0VBQWdFLEVBQUUsWUFBWTtJQUMvRSxNQUFNZCxJQUFJLEdBQUcsTUFBTXNJLFFBQVEsQ0FBQyxXQUFXLENBQUM7SUFDeEMsTUFBTXRJLElBQUksQ0FBQ1csS0FBSyxDQUFDLE1BQU1MLGFBQU0sQ0FBQ21JLGFBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUN2RCxNQUFNbkksYUFBTSxDQUFDbUksYUFBYSxDQUFDLEtBQUssQ0FBQztJQUNqQyxNQUFNWixHQUFHLEdBQUd2SCxhQUFNLENBQUNtQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUNyQixPQUFPLENBQUMsYUFBYSxDQUFnQjtJQUMvRTZCLGdCQUFTLENBQUM2QixJQUFJLENBQUMrQyxHQUFHLEVBQUU7TUFBRTFELFlBQVksRUFBRUEsWUFBWSxDQUFDO1FBQUVJLEtBQUssRUFBRSxDQUFDOEQsSUFBSSxDQUFDLENBQUM7TUFBRSxDQUFDO0lBQUUsQ0FBQyxDQUFDO0lBQ3hFLE1BQU1wTSxVQUFFLENBQUNvSixPQUFPLENBQUMsTUFBTSxJQUFBdEUsY0FBTSxFQUFDL0UsQ0FBQyxDQUFDdUIsVUFBVSxDQUFDLENBQUNvRyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUM7SUFDL0QsSUFBQTVDLGNBQU0sRUFBQy9FLENBQUMsQ0FBQ3VCLFVBQVUsQ0FBQyxDQUFDeUQscUJBQXFCLENBQUMsQ0FBQyxDQUFDO0lBQzdDLElBQUFELGNBQU0sRUFBQy9FLENBQUMsQ0FBQ3VCLFVBQVUsQ0FBQ1EsSUFBSSxDQUFDNkQsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUNFLElBQUksQ0FBQyxlQUFlLENBQUM7RUFDN0QsQ0FBQyxDQUFDO0VBRUYsSUFBQWhCLFVBQUUsRUFBQyxpRUFBaUUsRUFBRSxZQUFZO0lBQ2hGLE1BQU1kLElBQUksR0FBRyxNQUFNc0ksUUFBUSxDQUFDLFdBQVcsQ0FBQztJQUN4QyxNQUFNdEksSUFBSSxDQUFDVyxLQUFLLENBQUMsTUFBTUwsYUFBTSxDQUFDbUksYUFBYSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ3ZELE1BQU1uSSxhQUFNLENBQUNtSSxhQUFhLENBQUMsS0FBSyxDQUFDO0lBQ2pDLE1BQU1aLEdBQUcsR0FBR3ZILGFBQU0sQ0FBQ21DLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ3JCLE9BQU8sQ0FBQyxhQUFhLENBQWdCO0lBQy9FNkIsZ0JBQVMsQ0FBQzZCLElBQUksQ0FBQytDLEdBQUcsRUFBRTtNQUFFMUQsWUFBWSxFQUFFQSxZQUFZLENBQUM7UUFBRUksS0FBSyxFQUFFLENBQUM4RCxJQUFJLENBQUMsQ0FBQztNQUFFLENBQUM7SUFBRSxDQUFDLENBQUM7SUFDeEUsTUFBTXBNLFVBQUUsQ0FBQ29KLE9BQU8sQ0FBQyxNQUFNLElBQUF0RSxjQUFNLEVBQUMvRSxDQUFDLENBQUN1QixVQUFVLENBQUMsQ0FBQ29HLGdCQUFnQixDQUFDLENBQUMsQ0FBQztJQUMvRCxJQUFBNUMsY0FBTSxFQUFDL0UsQ0FBQyxDQUFDdUIsVUFBVSxDQUFDLENBQUN5RCxxQkFBcUIsQ0FBQyxDQUFDLENBQUM7SUFDN0MsSUFBQUQsY0FBTSxFQUFDL0UsQ0FBQyxDQUFDdUIsVUFBVSxDQUFDUSxJQUFJLENBQUM2RCxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ0UsSUFBSSxDQUFDLGVBQWUsQ0FBQztFQUM3RCxDQUFDLENBQUM7RUFFRixJQUFBaEIsVUFBRSxFQUFDLG1FQUFtRSxFQUFFLFlBQVk7SUFDbEYsTUFBTWQsSUFBSSxHQUFHLE1BQU1zSSxRQUFRLENBQUMsYUFBYSxDQUFDO0lBQzFDLE1BQU10SSxJQUFJLENBQUNXLEtBQUssQ0FBQyxNQUFNTCxhQUFNLENBQUNtSSxhQUFhLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ3pELE1BQU1uSSxhQUFNLENBQUNtSSxhQUFhLENBQUMsS0FBSyxDQUFDO0lBQ2pDLE1BQU1aLEdBQUcsR0FBR3ZILGFBQU0sQ0FBQ21DLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ3JCLE9BQU8sQ0FBQyxhQUFhLENBQWdCO0lBQy9FNkIsZ0JBQVMsQ0FBQzZCLElBQUksQ0FBQytDLEdBQUcsRUFBRTtNQUFFMUQsWUFBWSxFQUFFQSxZQUFZLENBQUM7UUFBRUksS0FBSyxFQUFFLENBQUM4RCxJQUFJLENBQUMsQ0FBQztNQUFFLENBQUM7SUFBRSxDQUFDLENBQUM7SUFDeEUsTUFBTXBNLFVBQUUsQ0FBQ29KLE9BQU8sQ0FBQyxNQUFNLElBQUF0RSxjQUFNLEVBQUMvRSxDQUFDLENBQUN1QixVQUFVLENBQUMsQ0FBQ29HLGdCQUFnQixDQUFDLENBQUMsQ0FBQztJQUMvRCxJQUFBNUMsY0FBTSxFQUFDL0UsQ0FBQyxDQUFDdUIsVUFBVSxDQUFDLENBQUN5RCxxQkFBcUIsQ0FBQyxDQUFDLENBQUM7SUFDN0MsSUFBQUQsY0FBTSxFQUFDL0UsQ0FBQyxDQUFDdUIsVUFBVSxDQUFDUSxJQUFJLENBQUM2RCxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ0UsSUFBSSxDQUFDLGVBQWUsQ0FBQztFQUM3RCxDQUFDLENBQUM7RUFFRixJQUFBaEIsVUFBRSxFQUFDLHdFQUF3RSxFQUFFLFlBQVk7SUFDdkY7SUFDQTtJQUNBLE1BQU1kLElBQUksR0FBRyxNQUFNc0ksUUFBUSxDQUFDLFdBQVcsQ0FBQztJQUN4QyxNQUFNdEksSUFBSSxDQUFDVyxLQUFLLENBQUMsTUFBTUwsYUFBTSxDQUFDbUksYUFBYSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ3ZELE1BQU1uSSxhQUFNLENBQUNtSSxhQUFhLENBQUMsS0FBSyxDQUFDO0lBQ2pDLE1BQU1ELE1BQU0sR0FBRzlDLFFBQVEsQ0FBQ0ksYUFBYSxDQUFDLGVBQWUsQ0FBZ0I7SUFDckUsTUFBTStCLEdBQUcsR0FBR3ZILGFBQU0sQ0FBQ21DLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ3JCLE9BQU8sQ0FBQyxhQUFhLENBQWdCO0lBQy9FNkIsZ0JBQVMsQ0FBQ3NDLFFBQVEsQ0FBQ2lELE1BQU0sRUFBRTtNQUFFckUsWUFBWSxFQUFFQSxZQUFZLENBQUM7UUFBRUksS0FBSyxFQUFFLENBQUM4RCxJQUFJLENBQUMsQ0FBQztNQUFFLENBQUM7SUFBRSxDQUFDLENBQUM7SUFDL0UsSUFBQXRILGNBQU0sRUFBQ3lILE1BQU0sQ0FBQzlILFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDb0IsSUFBSSxDQUFDLEdBQUcsQ0FBQztJQUNsRG1CLGdCQUFTLENBQUM2QixJQUFJLENBQUMrQyxHQUFHLEVBQUU7TUFBRTFELFlBQVksRUFBRUEsWUFBWSxDQUFDO1FBQUVJLEtBQUssRUFBRSxDQUFDOEQsSUFBSSxDQUFDLENBQUM7TUFBRSxDQUFDO0lBQUUsQ0FBQyxDQUFDO0lBQ3hFLE1BQU1wTSxVQUFFLENBQUNvSixPQUFPLENBQUMsTUFBTSxJQUFBdEUsY0FBTSxFQUFDL0UsQ0FBQyxDQUFDdUIsVUFBVSxDQUFDLENBQUNvRyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUM7SUFDL0QsSUFBQTVDLGNBQU0sRUFBQy9FLENBQUMsQ0FBQ3VCLFVBQVUsQ0FBQyxDQUFDeUQscUJBQXFCLENBQUMsQ0FBQyxDQUFDO0lBQzdDLElBQUFELGNBQU0sRUFBQ3lILE1BQU0sQ0FBQzlILFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDb0IsSUFBSSxDQUFDLElBQUksQ0FBQztFQUNyRCxDQUFDLENBQUM7RUFFRixJQUFBaEIsVUFBRSxFQUFDLDhDQUE4QyxFQUFFLFlBQVk7SUFDN0QsTUFBTWQsSUFBSSxHQUFHLE1BQU1zSSxRQUFRLENBQUMsV0FBVyxDQUFDO0lBQ3hDLE1BQU10SSxJQUFJLENBQUNXLEtBQUssQ0FBQyxNQUFNTCxhQUFNLENBQUNDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUNqRCxNQUFNRCxhQUFNLENBQUNDLFVBQVUsQ0FBQyxLQUFLLENBQUM7SUFDOUIsTUFBTWlJLE1BQU0sR0FBRzlDLFFBQVEsQ0FBQ0ksYUFBYSxDQUFDLGVBQWUsQ0FBZ0I7SUFDckUsSUFBQS9FLGNBQU0sRUFBQ3lILE1BQU0sQ0FBQzlILFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDb0IsSUFBSSxDQUFDLElBQUksQ0FBQztJQUNuRG1CLGdCQUFTLENBQUNzQyxRQUFRLENBQUNpRCxNQUFNLEVBQUU7TUFBRXJFLFlBQVksRUFBRUEsWUFBWSxDQUFDO1FBQUVJLEtBQUssRUFBRSxDQUFDOEQsSUFBSSxDQUFDLENBQUM7TUFBRSxDQUFDO0lBQUUsQ0FBQyxDQUFDO0lBQy9FLElBQUF0SCxjQUFNLEVBQUN5SCxNQUFNLENBQUM5SCxZQUFZLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQ29CLElBQUksQ0FBQyxHQUFHLENBQUM7SUFDbERtQixnQkFBUyxDQUFDdUMsU0FBUyxDQUFDZ0QsTUFBTSxFQUFFO01BQUUvQyxhQUFhLEVBQUVDLFFBQVEsQ0FBQ0M7SUFBSyxDQUFDLENBQUM7SUFDN0QsSUFBQTVFLGNBQU0sRUFBQ3lILE1BQU0sQ0FBQzlILFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDb0IsSUFBSSxDQUFDLElBQUksQ0FBQztFQUNyRCxDQUFDLENBQUM7RUFFRixJQUFBaEIsVUFBRSxFQUFDLGdFQUFnRSxFQUFFLFlBQVk7SUFDL0UsTUFBTWQsSUFBSSxHQUFHLE1BQU1zSSxRQUFRLENBQUMsV0FBVyxDQUFDO0lBQ3hDLE1BQU10SSxJQUFJLENBQUNXLEtBQUssQ0FBQyxNQUFNTCxhQUFNLENBQUNDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUNqRCxNQUFNRCxhQUFNLENBQUNDLFVBQVUsQ0FBQyxLQUFLLENBQUM7SUFDOUIsTUFBTWlJLE1BQU0sR0FBRzlDLFFBQVEsQ0FBQ0ksYUFBYSxDQUFDLGdCQUFnQixDQUFnQjtJQUN0RTdDLGdCQUFTLENBQUM2QixJQUFJLENBQUMwRCxNQUFNLEVBQUU7TUFBRXJFLFlBQVksRUFBRUEsWUFBWSxDQUFDO1FBQUVJLEtBQUssRUFBRSxDQUFDOEQsSUFBSSxDQUFDLENBQUM7TUFBRSxDQUFDO0lBQUUsQ0FBQyxDQUFDO0lBQzNFLE1BQU1wTSxVQUFFLENBQUNvSixPQUFPLENBQUMsTUFBTSxJQUFBdEUsY0FBTSxFQUFDL0UsQ0FBQyxDQUFDdUIsVUFBVSxDQUFDLENBQUNvRyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUM7SUFDL0QsSUFBQTVDLGNBQU0sRUFBQy9FLENBQUMsQ0FBQ3VCLFVBQVUsQ0FBQ1EsSUFBSSxDQUFDNkQsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUNFLElBQUksQ0FBQyxXQUFXLENBQUM7RUFDekQsQ0FBQyxDQUFDO0VBRUYsSUFBQWhCLFVBQUUsRUFBQyxtRUFBbUUsRUFBRSxZQUFZO0lBQ2xGLE1BQU1kLElBQUksR0FBRyxNQUFNc0ksUUFBUSxDQUFDLFdBQVcsQ0FBQztJQUN4QyxNQUFNdEksSUFBSSxDQUFDVyxLQUFLLENBQUMsTUFBTUwsYUFBTSxDQUFDQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDakQsTUFBTUQsYUFBTSxDQUFDQyxVQUFVLENBQUMsS0FBSyxDQUFDO0lBQzlCLE1BQU1QLElBQUksQ0FBQ1csS0FBSyxDQUFDTCxhQUFNLENBQUNNLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUN6QyxNQUFNTixhQUFNLENBQUNDLFVBQVUsQ0FBQyxVQUFVLENBQUM7SUFDbkMsTUFBTXNILEdBQUcsR0FBR3ZILGFBQU0sQ0FBQ00sU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDUSxPQUFPLENBQUMsYUFBYSxDQUFnQjtJQUM5RTZCLGdCQUFTLENBQUM2QixJQUFJLENBQUMrQyxHQUFHLEVBQUU7TUFBRTFELFlBQVksRUFBRUEsWUFBWSxDQUFDO1FBQUVJLEtBQUssRUFBRSxDQUFDOEQsSUFBSSxDQUFDLENBQUM7TUFBRSxDQUFDO0lBQUUsQ0FBQyxDQUFDO0lBQ3hFLE1BQU1wTSxVQUFFLENBQUNvSixPQUFPLENBQUMsTUFBTSxJQUFBdEUsY0FBTSxFQUFDL0UsQ0FBQyxDQUFDdUIsVUFBVSxDQUFDLENBQUNvRyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUM7SUFDL0QsSUFBQTVDLGNBQU0sRUFBQy9FLENBQUMsQ0FBQ3VCLFVBQVUsQ0FBQ1EsSUFBSSxDQUFDNkQsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUNFLElBQUksQ0FBQyxlQUFlLENBQUM7RUFDN0QsQ0FBQyxDQUFDO0VBRUYsSUFBQWhCLFVBQUUsRUFBQywrQ0FBK0MsRUFBRSxZQUFZO0lBQzlELE1BQU1kLElBQUksR0FBRyxNQUFNc0ksUUFBUSxDQUFDLFdBQVcsQ0FBQztJQUN4QyxNQUFNdEksSUFBSSxDQUFDVyxLQUFLLENBQUMsTUFBTUwsYUFBTSxDQUFDQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDakQsTUFBTUQsYUFBTSxDQUFDQyxVQUFVLENBQUMsS0FBSyxDQUFDO0lBQzlCLE1BQU1pSSxNQUFNLEdBQUc5QyxRQUFRLENBQUNJLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBZ0I7SUFDdEUsSUFBQS9FLGNBQU0sRUFBQ3lILE1BQU0sQ0FBQzlILFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDb0IsSUFBSSxDQUFDLElBQUksQ0FBQztJQUNuRG1CLGdCQUFTLENBQUNzQyxRQUFRLENBQUNpRCxNQUFNLEVBQUU7TUFBRXJFLFlBQVksRUFBRUEsWUFBWSxDQUFDO1FBQUVJLEtBQUssRUFBRSxDQUFDOEQsSUFBSSxDQUFDLENBQUM7TUFBRSxDQUFDO0lBQUUsQ0FBQyxDQUFDO0lBQy9FLElBQUF0SCxjQUFNLEVBQUN5SCxNQUFNLENBQUM5SCxZQUFZLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQ29CLElBQUksQ0FBQyxHQUFHLENBQUM7SUFDbERtQixnQkFBUyxDQUFDdUMsU0FBUyxDQUFDZ0QsTUFBTSxFQUFFO01BQUUvQyxhQUFhLEVBQUVDLFFBQVEsQ0FBQ0M7SUFBSyxDQUFDLENBQUM7SUFDN0QsSUFBQTVFLGNBQU0sRUFBQ3lILE1BQU0sQ0FBQzlILFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDb0IsSUFBSSxDQUFDLElBQUksQ0FBQztFQUNyRCxDQUFDLENBQUM7RUFFRixJQUFBaEIsVUFBRSxFQUFDLHlGQUF5RixFQUFFLFlBQVk7SUFDeEcsTUFBTWQsSUFBSSxHQUFHLE1BQU1zSSxRQUFRLENBQUMsYUFBYSxDQUFDO0lBQzFDLE1BQU10SSxJQUFJLENBQUNXLEtBQUssQ0FBQyxNQUFNTCxhQUFNLENBQUNDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDbkQsTUFBTUQsYUFBTSxDQUFDQyxVQUFVLENBQUMsS0FBSyxDQUFDO0lBQzlCLE1BQU1QLElBQUksQ0FBQ1csS0FBSyxDQUFDTCxhQUFNLENBQUNNLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDM0MsTUFBTU4sYUFBTSxDQUFDQyxVQUFVLENBQUMsVUFBVSxDQUFDO0lBQ25DLE1BQU1tSSxJQUFJLEdBQUdoRCxRQUFRLENBQUNJLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBZ0I7SUFDcEU3QyxnQkFBUyxDQUFDNkIsSUFBSSxDQUFDNEQsSUFBSSxFQUFFO01BQUV2RSxZQUFZLEVBQUVBLFlBQVksQ0FBQztRQUFFSSxLQUFLLEVBQUUsQ0FBQzhELElBQUksQ0FBQyxDQUFDO01BQUUsQ0FBQztJQUFFLENBQUMsQ0FBQztJQUN6RSxNQUFNcE0sVUFBRSxDQUFDb0osT0FBTyxDQUFDLE1BQU0sSUFBQXRFLGNBQU0sRUFBQy9FLENBQUMsQ0FBQ3VCLFVBQVUsQ0FBQyxDQUFDb0csZ0JBQWdCLENBQUMsQ0FBQyxDQUFDO0lBQy9EO0lBQ0EsSUFBQTVDLGNBQU0sRUFBQy9FLENBQUMsQ0FBQ3VCLFVBQVUsQ0FBQ1EsSUFBSSxDQUFDNkQsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUNFLElBQUksQ0FBQyxXQUFXLENBQUM7RUFDekQsQ0FBQyxDQUFDO0VBRUYsSUFBQWhCLFVBQUUsRUFBQyxxRUFBcUUsRUFBRSxZQUFZO0lBQ3BGLE1BQU1kLElBQUksR0FBRyxNQUFNc0ksUUFBUSxDQUFDLGFBQWEsQ0FBQztJQUMxQyxNQUFNdEksSUFBSSxDQUFDVyxLQUFLLENBQUMsTUFBTUwsYUFBTSxDQUFDQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDakQsTUFBTUQsYUFBTSxDQUFDQyxVQUFVLENBQUMsS0FBSyxDQUFDO0lBQzlCLE1BQU1QLElBQUksQ0FBQ1csS0FBSyxDQUFDTCxhQUFNLENBQUNNLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUN6QyxNQUFNTixhQUFNLENBQUNDLFVBQVUsQ0FBQyxVQUFVLENBQUM7SUFDbkMsTUFBTXNILEdBQUcsR0FBR3ZILGFBQU0sQ0FBQ00sU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDUSxPQUFPLENBQUMsYUFBYSxDQUFnQjtJQUM5RTZCLGdCQUFTLENBQUM2QixJQUFJLENBQUMrQyxHQUFHLEVBQUU7TUFBRTFELFlBQVksRUFBRUEsWUFBWSxDQUFDO1FBQUVJLEtBQUssRUFBRSxDQUFDOEQsSUFBSSxDQUFDLENBQUM7TUFBRSxDQUFDO0lBQUUsQ0FBQyxDQUFDO0lBQ3hFLE1BQU1wTSxVQUFFLENBQUNvSixPQUFPLENBQUMsTUFBTSxJQUFBdEUsY0FBTSxFQUFDL0UsQ0FBQyxDQUFDdUIsVUFBVSxDQUFDLENBQUNvRyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUM7SUFDL0QsSUFBQTVDLGNBQU0sRUFBQy9FLENBQUMsQ0FBQ3VCLFVBQVUsQ0FBQ1EsSUFBSSxDQUFDNkQsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUNFLElBQUksQ0FBQyxlQUFlLENBQUM7RUFDN0QsQ0FBQyxDQUFDO0VBRUYsSUFBQWhCLFVBQUUsRUFBQywwREFBMEQsRUFBRSxZQUFZO0lBQ3pFLE1BQU1kLElBQUksR0FBRyxNQUFNc0ksUUFBUSxDQUFDLGFBQWEsQ0FBQztJQUMxQyxNQUFNdEksSUFBSSxDQUFDVyxLQUFLLENBQUMsTUFBTUwsYUFBTSxDQUFDQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDakQsTUFBTUQsYUFBTSxDQUFDQyxVQUFVLENBQUMsS0FBSyxDQUFDO0lBQzlCLE1BQU1QLElBQUksQ0FBQ1csS0FBSyxDQUFDTCxhQUFNLENBQUNNLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUN6QyxNQUFNTixhQUFNLENBQUNDLFVBQVUsQ0FBQyxVQUFVLENBQUM7SUFDbkMsTUFBTW1JLElBQUksR0FBR2hELFFBQVEsQ0FBQ0ksYUFBYSxDQUFDLGdCQUFnQixDQUFnQjtJQUNwRSxNQUFNNkMsSUFBSSxHQUFHakQsUUFBUSxDQUFDSSxhQUFhLENBQUMsZ0JBQWdCLENBQWdCO0lBQ3BFLElBQUEvRSxjQUFNLEVBQUMySCxJQUFJLENBQUNoSSxZQUFZLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQ29CLElBQUksQ0FBQyxJQUFJLENBQUM7SUFDakQsSUFBQWYsY0FBTSxFQUFDNEgsSUFBSSxDQUFDakksWUFBWSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUNvQixJQUFJLENBQUMsSUFBSSxDQUFDO0lBQ2pEbUIsZ0JBQVMsQ0FBQ3NDLFFBQVEsQ0FBQ29ELElBQUksRUFBRTtNQUFFeEUsWUFBWSxFQUFFQSxZQUFZLENBQUM7UUFBRUksS0FBSyxFQUFFLENBQUM4RCxJQUFJLENBQUMsQ0FBQztNQUFFLENBQUM7SUFBRSxDQUFDLENBQUM7SUFDN0UsSUFBQXRILGNBQU0sRUFBQzRILElBQUksQ0FBQ2pJLFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDb0IsSUFBSSxDQUFDLEdBQUcsQ0FBQztJQUNoRCxJQUFBZixjQUFNLEVBQUMySCxJQUFJLENBQUNoSSxZQUFZLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQ29CLElBQUksQ0FBQyxJQUFJLENBQUM7SUFDakRtQixnQkFBUyxDQUFDdUMsU0FBUyxDQUFDbUQsSUFBSSxFQUFFO01BQUVsRCxhQUFhLEVBQUVDLFFBQVEsQ0FBQ0M7SUFBSyxDQUFDLENBQUM7SUFDM0QsSUFBQTVFLGNBQU0sRUFBQzRILElBQUksQ0FBQ2pJLFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDb0IsSUFBSSxDQUFDLElBQUksQ0FBQztFQUNuRCxDQUFDLENBQUM7RUFFRixJQUFBaEIsVUFBRSxFQUFDLG9GQUFvRixFQUFFLFlBQVk7SUFDbkc7SUFDQTtJQUNBO0lBQ0EsTUFBTWQsSUFBSSxHQUFHQyxrQkFBUyxDQUFDQyxLQUFLLENBQUMsQ0FBQztJQUM5QmxFLENBQUMsQ0FBQ1UsTUFBTSxHQUFHLENBQUMrQyxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUU7TUFBRW5ELElBQUksRUFBRSxVQUFVO01BQUVxQixJQUFJLEVBQUUsVUFBVTtNQUFFeUIsRUFBRSxFQUFFO0lBQUssQ0FBQyxDQUFDO0lBQzdFLElBQUFnQixhQUFNLGVBQUMsSUFBQTNFLFdBQUEsQ0FBQTRFLEdBQUEsRUFBQzdFLGdCQUFBLENBQUFJLE9BQVksSUFBRSxDQUFDLENBQUM7SUFDeEIsTUFBTTBFLGFBQU0sQ0FBQ21JLGFBQWEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQ2xDLE1BQU16SSxJQUFJLENBQUNXLEtBQUssQ0FBQ0wsYUFBTSxDQUFDRyxTQUFTLENBQUMsT0FBTyxFQUFFO01BQUUzRSxJQUFJLEVBQUU7SUFBWSxDQUFDLENBQUMsQ0FBQztJQUNsRSxNQUFNd0UsYUFBTSxDQUFDbUksYUFBYSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7SUFDbEMsTUFBTUQsTUFBTSxHQUFHOUMsUUFBUSxDQUFDSSxhQUFhLENBQUMsZUFBZSxDQUFnQjtJQUNyRTdDLGdCQUFTLENBQUNzQyxRQUFRLENBQUNpRCxNQUFNLEVBQUU7TUFBRXJFLFlBQVksRUFBRUEsWUFBWSxDQUFDO1FBQUVJLEtBQUssRUFBRSxDQUFDOEQsSUFBSSxDQUFDLENBQUM7TUFBRSxDQUFDO0lBQUUsQ0FBQyxDQUFDO0lBQy9FLElBQUF0SCxjQUFNLEVBQUN5SCxNQUFNLENBQUM5SCxZQUFZLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQ29CLElBQUksQ0FBQyxJQUFJLENBQUM7SUFDbkRtQixnQkFBUyxDQUFDNkIsSUFBSSxDQUFDMEQsTUFBTSxFQUFFO01BQUVyRSxZQUFZLEVBQUVBLFlBQVksQ0FBQztRQUFFSSxLQUFLLEVBQUUsQ0FBQzhELElBQUksQ0FBQyxDQUFDO01BQUUsQ0FBQztJQUFFLENBQUMsQ0FBQztJQUMzRSxJQUFBdEgsY0FBTSxFQUFDL0UsQ0FBQyxDQUFDdUIsVUFBVSxDQUFDLENBQUNtRSxHQUFHLENBQUNpQyxnQkFBZ0IsQ0FBQyxDQUFDO0VBQzdDLENBQUMsQ0FBQztFQUVGLElBQUE3QyxVQUFFLEVBQUMsZ0VBQWdFLEVBQUUsWUFBWTtJQUMvRSxNQUFNZCxJQUFJLEdBQUcsTUFBTXNJLFFBQVEsQ0FBQyxXQUFXLENBQUM7SUFDeEMsTUFBTXRJLElBQUksQ0FBQ1csS0FBSyxDQUFDLE1BQU1MLGFBQU0sQ0FBQ21JLGFBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUN2RCxNQUFNbkksYUFBTSxDQUFDbUksYUFBYSxDQUFDLEtBQUssQ0FBQztJQUNqQyxNQUFNRCxNQUFNLEdBQUc5QyxRQUFRLENBQUNJLGFBQWEsQ0FBQyxlQUFlLENBQWdCO0lBQ3JFLE1BQU14QixJQUFJLEdBQUdILFlBQVksQ0FBQztNQUFFRyxJQUFJLEVBQUVTLElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQUVsRyxJQUFJLEVBQUUsb0JBQW9CO1FBQUVtRyxRQUFRLEVBQUU7TUFBVyxDQUFDO0lBQUUsQ0FBQyxDQUFDO0lBQ3pHaEMsZ0JBQVMsQ0FBQ3NDLFFBQVEsQ0FBQ2lELE1BQU0sRUFBRTtNQUFFckUsWUFBWSxFQUFFRztJQUFLLENBQUMsQ0FBQztJQUNsRCxJQUFBdkQsY0FBTSxFQUFDeUgsTUFBTSxDQUFDOUgsWUFBWSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUNvQixJQUFJLENBQUMsSUFBSSxDQUFDO0lBQ25EbUIsZ0JBQVMsQ0FBQzZCLElBQUksQ0FBQzBELE1BQU0sRUFBRTtNQUFFckUsWUFBWSxFQUFFRztJQUFLLENBQUMsQ0FBQztJQUM5QyxJQUFBdkQsY0FBTSxFQUFDL0UsQ0FBQyxDQUFDdUIsVUFBVSxDQUFDLENBQUNtRSxHQUFHLENBQUNpQyxnQkFBZ0IsQ0FBQyxDQUFDO0lBQzNDLElBQUE1QyxjQUFNLEVBQUMvRSxDQUFDLENBQUNzQixXQUFXLENBQUMsQ0FBQ29FLEdBQUcsQ0FBQ2lDLGdCQUFnQixDQUFDLENBQUM7RUFDOUMsQ0FBQyxDQUFDO0VBRUYsSUFBQTdDLFVBQUUsRUFBQyxvREFBb0QsRUFBRSxZQUFZO0lBQ25FLE1BQU1kLElBQUksR0FBR0Msa0JBQVMsQ0FBQ0MsS0FBSyxDQUFDLENBQUM7SUFDOUJsRSxDQUFDLENBQUNVLE1BQU0sR0FBRyxDQUFDcUYsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDdEIsSUFBQTNCLGFBQU0sZUFBQyxJQUFBM0UsV0FBQSxDQUFBNEUsR0FBQSxFQUFDN0UsZ0JBQUEsQ0FBQUksT0FBWSxJQUFFLENBQUMsQ0FBQztJQUN4QixNQUFNMEUsYUFBTSxDQUFDbUksYUFBYSxDQUFDLGNBQWMsQ0FBQztJQUMxQyxNQUFNekksSUFBSSxDQUFDVyxLQUFLLENBQUNMLGFBQU0sQ0FBQ0csU0FBUyxDQUFDLE9BQU8sRUFBRTtNQUFFM0UsSUFBSSxFQUFFO0lBQVksQ0FBQyxDQUFDLENBQUM7SUFDbEUsTUFBTXdFLGFBQU0sQ0FBQ21JLGFBQWEsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDO0lBQzVDLE1BQU1ELE1BQU0sR0FBRzlDLFFBQVEsQ0FBQ0ksYUFBYSxDQUFDLGVBQWUsQ0FBZ0I7SUFDckU3QyxnQkFBUyxDQUFDc0MsUUFBUSxDQUFDaUQsTUFBTSxFQUFFO01BQUVyRSxZQUFZLEVBQUVBLFlBQVksQ0FBQztRQUFFSSxLQUFLLEVBQUUsQ0FBQzhELElBQUksQ0FBQyxDQUFDO01BQUUsQ0FBQztJQUFFLENBQUMsQ0FBQztJQUMvRSxJQUFBdEgsY0FBTSxFQUFDeUgsTUFBTSxDQUFDOUgsWUFBWSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUNvQixJQUFJLENBQUMsSUFBSSxDQUFDO0lBQ25EbUIsZ0JBQVMsQ0FBQzZCLElBQUksQ0FBQzBELE1BQU0sRUFBRTtNQUFFckUsWUFBWSxFQUFFQSxZQUFZLENBQUM7UUFBRUksS0FBSyxFQUFFLENBQUM4RCxJQUFJLENBQUMsQ0FBQztNQUFFLENBQUM7SUFBRSxDQUFDLENBQUM7SUFDM0UsSUFBQXRILGNBQU0sRUFBQy9FLENBQUMsQ0FBQ3VCLFVBQVUsQ0FBQyxDQUFDbUUsR0FBRyxDQUFDaUMsZ0JBQWdCLENBQUMsQ0FBQztFQUM3QyxDQUFDLENBQUM7RUFFRixJQUFBN0MsVUFBRSxFQUFDLGtGQUFrRixFQUFFLFlBQVk7SUFDakc7SUFDQTtJQUNBLE1BQU1mLHFCQUFxQixDQUFDLENBQUM7SUFDN0IsTUFBTW9DLEtBQUssR0FBRzdCLGFBQU0sQ0FBQ00sU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDUSxPQUFPLENBQUMsUUFBUSxDQUFnQjtJQUN0RSxNQUFNeUcsR0FBRyxHQUFHdkgsYUFBTSxDQUFDTSxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUNRLE9BQU8sQ0FBQyxRQUFRLENBQWdCO0lBQ3BFNkIsZ0JBQVMsQ0FBQ3NDLFFBQVEsQ0FBQ3BELEtBQUssRUFBRTtNQUFFZ0MsWUFBWSxFQUFFQSxZQUFZLENBQUM7UUFBRUksS0FBSyxFQUFFLENBQUM4RCxJQUFJLENBQUMsQ0FBQztNQUFFLENBQUM7SUFBRSxDQUFDLENBQUM7SUFDOUUsSUFBQXRILGNBQU0sRUFBQ29CLEtBQUssQ0FBQ3pCLFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDb0IsSUFBSSxDQUFDLEdBQUcsQ0FBQztJQUNqRG1CLGdCQUFTLENBQUM2QixJQUFJLENBQUMrQyxHQUFHLEVBQUU7TUFBRTFELFlBQVksRUFBRUEsWUFBWSxDQUFDO1FBQUVJLEtBQUssRUFBRSxDQUFDOEQsSUFBSSxDQUFDLENBQUM7TUFBRSxDQUFDO0lBQUUsQ0FBQyxDQUFDO0lBQ3hFLE1BQU1wTSxVQUFFLENBQUNvSixPQUFPLENBQUMsTUFBTSxJQUFBdEUsY0FBTSxFQUFDL0UsQ0FBQyxDQUFDdUIsVUFBVSxDQUFDLENBQUNvRyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUM7SUFDL0QsSUFBQTVDLGNBQU0sRUFBQy9FLENBQUMsQ0FBQ3VCLFVBQVUsQ0FBQyxDQUFDeUQscUJBQXFCLENBQUMsQ0FBQyxDQUFDO0lBQzdDLElBQUFELGNBQU0sRUFBQ29CLEtBQUssQ0FBQ3pCLFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDb0IsSUFBSSxDQUFDLElBQUksQ0FBQztFQUNwRCxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}