"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.CONTENT_MARKER_FILE = exports.APP_FORM_CONTRACT = void 0;
exports.openWithLabel = openWithLabel;
exports.opensInPlaceOffer = opensInPlaceOffer;
exports.opensWithOffer = opensWithOffer;
exports.parseOpensWith = parseOpensWith;
exports.viewOffers = viewOffers;
exports.withdrawsOffer = withdrawsOffer;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.some.js");
// R3-267 — the `opensWith` caller: decide whether a folder gets an "open it with the
// app it belongs to" affordance, and what that affordance says.
//
// Background. The directory-as-content pipeline shipped its callee (a bound viewer),
// its contract table (`open-project` / `open-wiki`), its binding and its host
// delegation plumbing — and no CALLER. A folder carrying
// `immediately.run.json` → `{ "opensWith": { "task": … }, "kind": … }` was read by
// nothing, so the trigger the specs describe could not fire. This module is the
// decision half of that caller. It is pure (no SDK, no React, no fs) so the rules
// below are testable without a host; the adapter under `sdk/` does the reading and
// the invoking.
//
// Three properties are deliberate, and each one is a rule the tests pin:
//
//   • **The marker is untrusted author input.** It travels with a folder anyone may
//     have written, so nothing here throws, and every field is validated before it is
//     shown or used. A marker we cannot vouch for yields NO offer — never a partial
//     one, and never an error in front of the user.
//   • **No marker-chosen task name appears in this file.** A contract-form offer is
//     labelled by the marker's own `kind` and invoked with the marker's own `task`;
//     which contracts this app may invoke arrives as data
//     ({@link OpensWithPolicy.offerable}), mirroring the `invokes` declaration the host
//     enforces anyway (UI_AS_APPS_SPEC §5.8), so a future contract works by declaring
//     it, with no change here. The one name this file does hold is
//     {@link APP_FORM_CONTRACT}: not a marker's choice but the protocol's fixed door for
//     every app-form marker, and the one contract a marker may never name itself.
//   • **The caller never names an app.** A contract-form marker names a CONTRACT and
//     the host's binding table decides which app opens it (REPO_CONTENT_DISPATCH_SPEC
//     §4). An app-form marker (`opensWith.app`, BUNDLE_EMBEDDING §4b.1) does name an
//     app, and this file still never reads it: that form is invoked through the one
//     fixed contract {@link APP_FORM_CONTRACT} with the directory alone, and the HOST
//     reads the marker, resolves the opener and offers it before anything runs
//     (§4b.2 rule 2). So there is still nothing app-shaped to parse, or to pass on.

/**
 * The contract an APP-form marker is opened through (BUNDLE_EMBEDDING §4b.2 rule 2).
 * The one task name in this file, and deliberately so: it is not a marker's choice
 * but the protocol's single door for every app-declared bundle, whatever app it names.
 * A task-form marker naming it offers nothing (the host refuses the cycle).
 */
const APP_FORM_CONTRACT = exports.APP_FORM_CONTRACT = "open-declared";

/** The marker file a directory carries to declare what opens it. */
const CONTENT_MARKER_FILE = exports.CONTENT_MARKER_FILE = "immediately.run.json";

/** What a marker declares, once validated. */

/** An offer the file manager may render for a directory. */

/** What the app may currently offer. Data, not code — see the header. */

// A `kind` is author-authored text that lands in UI. Keep it to a short, boring,
// single-line token: letters, digits, spaces and the two joiners a compound kind
// plausibly uses. Anything else (control characters, markup, a paragraph, a
// right-to-left override) is not sanitized into shape — it is simply not used, and
// the generic label is shown instead. Refusing is always safe here: the label is
// decoration, and the contract still opens.
const KIND_RE = /^[a-z0-9][a-z0-9 _-]{0,23}$/i;

/** The label for a marker `kind`, or the generic one when there is no usable kind. */
function openWithLabel(kind) {
  const trimmed = typeof kind === "string" ? kind.trim() : "";
  return KIND_RE.test(trimmed) ? `Open as ${trimmed.toLowerCase()}` : "Open with its app";
}

/** §4b.1a: at most this many declared views per marker; names are plain text ≤ 40 chars. */
const MAX_VIEWS = 8;
const VIEW_NAME_MAX = 40;
// The host's label class (site-main `contentMarker.ts` isUnsafeLabelChar): control
// characters, line/paragraph separators and every bidi control — marks, embeddings,
// overrides, isolates. A label must read as what it is.
const isUnsafeLabelChar = c => c <= 0x1f || c >= 0x7f && c <= 0x9f || c === 0x061c || c === 0x200e || c === 0x200f || c >= 0x2028 && c <= 0x202e || c >= 0x2066 && c <= 0x2069;
const hasUnsafeLabelChar = s => {
  for (let i = 0; i < s.length; i++) if (isUnsafeLabelChar(s.charCodeAt(i))) return true;
  return false;
};
// The host's subtree shape test, ported verbatim (site-main `bundleFederation.ts`
// isUnsafeSubtreeShape / hasUnsafeSegments): bundle-absolute, no traversal, no empty
// segment — which refuses "/" itself, as the host does.
const unsafeSubtree = s => {
  if (typeof s !== "string" || !s.startsWith("/")) return true;
  if (s.includes("\0") || s.includes("\\")) return true;
  const segs = s.split("/");
  if (segs[0] === "") segs.shift();
  if (segs.length > 1 && segs[segs.length - 1] === "") segs.pop();
  return segs.some(seg => seg === "" || seg === "." || seg === "..");
};

/**
 * R3-789 (§4b.1a) — one offer per VIEW the marker declares, each invoking `open-declared`
 * with `view: <name>`. Offered only where the host would open it: the marker as a whole must
 * be one the host accepts ({@link parseOpensWith} — a rejected marker is refused before its
 * views are read), and each view passes the host's own view refusals (`parseViews`): app
 * form only, revision-less, no `entry`, a bundle-absolute traversal-free `subtree`, a plain
 * name, no duplicates, at most eight. A refused one would be a dead click (`no-target` does
 * not withdraw the shared contract). The view's app is validated but never returned.
 *
 * The label is the view's name as written — not lower-cased and not held to the `kind`
 * token: §4b.1a's parse rule (plain text ≤ 40, no control or bidi characters) is what
 * makes it safe to show, and a view name is a title ("Roadmap board"), not a type word.
 */
function viewOffers(text, policy) {
  if (!policy.offerable.includes(APP_FORM_CONTRACT) || policy.unavailable?.has(APP_FORM_CONTRACT)) return [];
  if (parseOpensWith(text) === null) return [];
  const obj = JSON.parse(text);
  if (!Array.isArray(obj.views)) return [];
  const out = [];
  const seen = new Set();
  for (const v of obj.views) {
    if (out.length >= MAX_VIEWS) break;
    if (!v || typeof v !== "object" || Array.isArray(v)) continue;
    const e = v;
    // The host tests the UNTRIMMED name for unsafe characters and the trimmed one for length.
    if (typeof e.name !== "string" || hasUnsafeLabelChar(e.name)) continue;
    const name = e.name.trim();
    if (name === "" || name.length > VIEW_NAME_MAX || seen.has(name)) continue;
    const ow = e.opensWith;
    if (!ow || typeof ow !== "object" || Array.isArray(ow) || "task" in ow || ow.entry !== undefined) continue;
    const app = ow.app;
    if (typeof app !== "string" || app === "" || app.includes("@") || app.includes("#")) continue;
    if (unsafeSubtree(e.subtree)) continue;
    seen.add(name);
    out.push({
      task: APP_FORM_CONTRACT,
      version: "1.0",
      label: `Open as ${name}`,
      view: name
    });
  }
  return out;
}

/**
 * Parse a marker file's TEXT into a validated marker, or null.
 *
 * Never throws: unreadable bytes, invalid JSON, a non-object, a marker with neither
 * (or both) of `opensWith.task` / `opensWith.app` all mean "no marker" — the same
 * outcome as a folder that carries none at all. An app-form marker comes back as
 * {@link APP_FORM_CONTRACT}; the app it names is never returned.
 */
function parseOpensWith(text) {
  if (typeof text !== "string" || text.trim() === "") return null;
  let obj;
  try {
    obj = JSON.parse(text);
  } catch {
    return null;
  }
  if (!obj || typeof obj !== "object" || Array.isArray(obj)) return null;
  const opensWith = obj.opensWith;
  if (!opensWith || typeof opensWith !== "object" || Array.isArray(opensWith)) return null;
  const task = opensWith.task;
  const app = opensWith.app;
  const kind = obj.kind;
  const kindPart = typeof kind === "string" && kind.trim() !== "" ? {
    kind: kind.trim()
  } : {};
  // The app form is offered only where the HOST would accept it (site-main
  // `parseContentMarker`, §4b.1), with the host's own untrimmed emptiness test. A marker
  // it refuses reaches `no-target` at invoke, which does not withdraw the shared
  // open-declared affordance — so offering one would be a dead click on every visit.
  const hostHasTask = typeof task === "string" && task !== "";
  const hostHasApp = typeof app === "string" && app !== "";
  if (hostHasTask && hostHasApp) return null; // ambiguous-opens
  if (hostHasApp) {
    if (opensWith.entry !== undefined) return null; // entry-in-app
    // revision-in-app: a ref (`@…`) or a commit pin (`#…`) — the reader chooses the commit.
    if (app.includes("@") || app.includes("#")) return null;
    if (!(typeof kind === "string" && kind !== "")) return null; // missing-kind
    // Opened through the fixed contract at its own v1. The marker's `version` is the
    // BUNDLE format the opener must cover (§4b.1) — the host checks it against the
    // opener's `opens` range, so it is not a contract version and not ours.
    return {
      task: APP_FORM_CONTRACT,
      version: "1.0",
      ...kindPart
    };
  }
  const hasTask = typeof task === "string" && task.trim() !== "";
  if (!hasTask) return null;
  // A task-form marker naming the app-form door would re-enter the contract that read
  // it; the host refuses that as a cycle (`openDeclaredRefusal`), so it offers nothing.
  if (task.trim() === APP_FORM_CONTRACT) return null;
  const version = opensWith.version;
  return {
    task: task.trim(),
    // An omitted version means the contract's v1 shape. The host still enforces the
    // T31 compatibility check against the BOUND app at invoke time, so defaulting
    // here widens nothing.
    version: typeof version === "string" && version.trim() !== "" ? version.trim() : "1.0",
    ...kindPart
  };
}

/**
 * The offer for a directory's marker text under a policy, or null for no affordance.
 *
 * Null — an absent affordance — is the outcome for every negative case, including a
 * marker naming a contract this app does not invoke: an unbound or unknown contract
 * must degrade to *nothing to click*, not to a protocol error the user has to read.
 */
function opensWithOffer(text, policy) {
  const marker = parseOpensWith(text);
  if (!marker) return null;
  if (!policy.offerable.includes(marker.task)) return null;
  if (policy.unavailable?.has(marker.task)) return null;
  return {
    task: marker.task,
    version: marker.version,
    label: openWithLabel(marker.kind)
  };
}

/** What the app may currently LAUNCH into the stage (R3-159). Data, like
 *  {@link OpensWithPolicy} — `launchable` mirrors the `launches` manifest block. */

/**
 * The into-stage twin of an open-with offer (R3-159): run the folder's project
 * TO-RUN in the stage region, replacing the focal app, rather than opening it
 * for-result. Offered only for a contract this app declares it LAUNCHES — one it
 * may merely invoke gets the for-result affordance alone, and a folder with no
 * offer gets nothing (an absent affordance, never an error).
 *
 * The label is FIXED, never derived from the marker's `kind`: the verb is the
 * product's ("open in place"), and the less untrusted text reaches a menu the
 * better.
 *
 * Unlike the for-result offer there is NO session withdrawal here: the host
 * resolves `unsupported` — the only launch code that could be a contract verdict —
 * for transient states too (the launch host not yet mounted, an absent launch
 * context, a create failing before bind), so no `LaunchErrorCode` is a safe
 * session-permanent verdict and a refusal simply leaves the affordance standing.
 */
function opensInPlaceOffer(offer, policy) {
  if (!offer) return null;
  if (!policy.launchable.includes(offer.task)) return null;
  return {
    task: offer.task,
    version: offer.version,
    label: "Open in place"
  };
}

/**
 * Should a refusal WITHDRAW the affordance for this contract for the rest of the
 * session, or was it about this one attempt?
 *
 * `cancelled` is the user closing the viewer — the most ordinary outcome there is, and
 * the affordance must survive it. A refusal that is a property of the CONTRACT (nothing
 * bound to it, this app not declared for it, the versions no longer meet) will repeat
 * identically on every click, so the honest response is to stop offering it. Anything
 * else (a transient host failure, an unknown code) leaves the offer standing.
 */
function withdrawsOffer(code) {
  return code === "no-such-task" || code === "not-declared" || code === "task-version-mismatch";
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJBUFBfRk9STV9DT05UUkFDVCIsImV4cG9ydHMiLCJDT05URU5UX01BUktFUl9GSUxFIiwiS0lORF9SRSIsIm9wZW5XaXRoTGFiZWwiLCJraW5kIiwidHJpbW1lZCIsInRyaW0iLCJ0ZXN0IiwidG9Mb3dlckNhc2UiLCJNQVhfVklFV1MiLCJWSUVXX05BTUVfTUFYIiwiaXNVbnNhZmVMYWJlbENoYXIiLCJjIiwiaGFzVW5zYWZlTGFiZWxDaGFyIiwicyIsImkiLCJsZW5ndGgiLCJjaGFyQ29kZUF0IiwidW5zYWZlU3VidHJlZSIsInN0YXJ0c1dpdGgiLCJpbmNsdWRlcyIsInNlZ3MiLCJzcGxpdCIsInNoaWZ0IiwicG9wIiwic29tZSIsInNlZyIsInZpZXdPZmZlcnMiLCJ0ZXh0IiwicG9saWN5Iiwib2ZmZXJhYmxlIiwidW5hdmFpbGFibGUiLCJoYXMiLCJwYXJzZU9wZW5zV2l0aCIsIm9iaiIsIkpTT04iLCJwYXJzZSIsIkFycmF5IiwiaXNBcnJheSIsInZpZXdzIiwib3V0Iiwic2VlbiIsIlNldCIsInYiLCJlIiwibmFtZSIsIm93Iiwib3BlbnNXaXRoIiwiZW50cnkiLCJ1bmRlZmluZWQiLCJhcHAiLCJzdWJ0cmVlIiwiYWRkIiwicHVzaCIsInRhc2siLCJ2ZXJzaW9uIiwibGFiZWwiLCJ2aWV3Iiwia2luZFBhcnQiLCJob3N0SGFzVGFzayIsImhvc3RIYXNBcHAiLCJoYXNUYXNrIiwib3BlbnNXaXRoT2ZmZXIiLCJtYXJrZXIiLCJvcGVuc0luUGxhY2VPZmZlciIsIm9mZmVyIiwibGF1bmNoYWJsZSIsIndpdGhkcmF3c09mZmVyIiwiY29kZSJdLCJzb3VyY2VzIjpbIm9wZW5zV2l0aC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBSMy0yNjcg4oCUIHRoZSBgb3BlbnNXaXRoYCBjYWxsZXI6IGRlY2lkZSB3aGV0aGVyIGEgZm9sZGVyIGdldHMgYW4gXCJvcGVuIGl0IHdpdGggdGhlXG4vLyBhcHAgaXQgYmVsb25ncyB0b1wiIGFmZm9yZGFuY2UsIGFuZCB3aGF0IHRoYXQgYWZmb3JkYW5jZSBzYXlzLlxuLy9cbi8vIEJhY2tncm91bmQuIFRoZSBkaXJlY3RvcnktYXMtY29udGVudCBwaXBlbGluZSBzaGlwcGVkIGl0cyBjYWxsZWUgKGEgYm91bmQgdmlld2VyKSxcbi8vIGl0cyBjb250cmFjdCB0YWJsZSAoYG9wZW4tcHJvamVjdGAgLyBgb3Blbi13aWtpYCksIGl0cyBiaW5kaW5nIGFuZCBpdHMgaG9zdFxuLy8gZGVsZWdhdGlvbiBwbHVtYmluZyDigJQgYW5kIG5vIENBTExFUi4gQSBmb2xkZXIgY2Fycnlpbmdcbi8vIGBpbW1lZGlhdGVseS5ydW4uanNvbmAg4oaSIGB7IFwib3BlbnNXaXRoXCI6IHsgXCJ0YXNrXCI6IOKApiB9LCBcImtpbmRcIjog4oCmIH1gIHdhcyByZWFkIGJ5XG4vLyBub3RoaW5nLCBzbyB0aGUgdHJpZ2dlciB0aGUgc3BlY3MgZGVzY3JpYmUgY291bGQgbm90IGZpcmUuIFRoaXMgbW9kdWxlIGlzIHRoZVxuLy8gZGVjaXNpb24gaGFsZiBvZiB0aGF0IGNhbGxlci4gSXQgaXMgcHVyZSAobm8gU0RLLCBubyBSZWFjdCwgbm8gZnMpIHNvIHRoZSBydWxlc1xuLy8gYmVsb3cgYXJlIHRlc3RhYmxlIHdpdGhvdXQgYSBob3N0OyB0aGUgYWRhcHRlciB1bmRlciBgc2RrL2AgZG9lcyB0aGUgcmVhZGluZyBhbmRcbi8vIHRoZSBpbnZva2luZy5cbi8vXG4vLyBUaHJlZSBwcm9wZXJ0aWVzIGFyZSBkZWxpYmVyYXRlLCBhbmQgZWFjaCBvbmUgaXMgYSBydWxlIHRoZSB0ZXN0cyBwaW46XG4vL1xuLy8gICDigKIgKipUaGUgbWFya2VyIGlzIHVudHJ1c3RlZCBhdXRob3IgaW5wdXQuKiogSXQgdHJhdmVscyB3aXRoIGEgZm9sZGVyIGFueW9uZSBtYXlcbi8vICAgICBoYXZlIHdyaXR0ZW4sIHNvIG5vdGhpbmcgaGVyZSB0aHJvd3MsIGFuZCBldmVyeSBmaWVsZCBpcyB2YWxpZGF0ZWQgYmVmb3JlIGl0IGlzXG4vLyAgICAgc2hvd24gb3IgdXNlZC4gQSBtYXJrZXIgd2UgY2Fubm90IHZvdWNoIGZvciB5aWVsZHMgTk8gb2ZmZXIg4oCUIG5ldmVyIGEgcGFydGlhbFxuLy8gICAgIG9uZSwgYW5kIG5ldmVyIGFuIGVycm9yIGluIGZyb250IG9mIHRoZSB1c2VyLlxuLy8gICDigKIgKipObyBtYXJrZXItY2hvc2VuIHRhc2sgbmFtZSBhcHBlYXJzIGluIHRoaXMgZmlsZS4qKiBBIGNvbnRyYWN0LWZvcm0gb2ZmZXIgaXNcbi8vICAgICBsYWJlbGxlZCBieSB0aGUgbWFya2VyJ3Mgb3duIGBraW5kYCBhbmQgaW52b2tlZCB3aXRoIHRoZSBtYXJrZXIncyBvd24gYHRhc2tgO1xuLy8gICAgIHdoaWNoIGNvbnRyYWN0cyB0aGlzIGFwcCBtYXkgaW52b2tlIGFycml2ZXMgYXMgZGF0YVxuLy8gICAgICh7QGxpbmsgT3BlbnNXaXRoUG9saWN5Lm9mZmVyYWJsZX0pLCBtaXJyb3JpbmcgdGhlIGBpbnZva2VzYCBkZWNsYXJhdGlvbiB0aGUgaG9zdFxuLy8gICAgIGVuZm9yY2VzIGFueXdheSAoVUlfQVNfQVBQU19TUEVDIMKnNS44KSwgc28gYSBmdXR1cmUgY29udHJhY3Qgd29ya3MgYnkgZGVjbGFyaW5nXG4vLyAgICAgaXQsIHdpdGggbm8gY2hhbmdlIGhlcmUuIFRoZSBvbmUgbmFtZSB0aGlzIGZpbGUgZG9lcyBob2xkIGlzXG4vLyAgICAge0BsaW5rIEFQUF9GT1JNX0NPTlRSQUNUfTogbm90IGEgbWFya2VyJ3MgY2hvaWNlIGJ1dCB0aGUgcHJvdG9jb2wncyBmaXhlZCBkb29yIGZvclxuLy8gICAgIGV2ZXJ5IGFwcC1mb3JtIG1hcmtlciwgYW5kIHRoZSBvbmUgY29udHJhY3QgYSBtYXJrZXIgbWF5IG5ldmVyIG5hbWUgaXRzZWxmLlxuLy8gICDigKIgKipUaGUgY2FsbGVyIG5ldmVyIG5hbWVzIGFuIGFwcC4qKiBBIGNvbnRyYWN0LWZvcm0gbWFya2VyIG5hbWVzIGEgQ09OVFJBQ1QgYW5kXG4vLyAgICAgdGhlIGhvc3QncyBiaW5kaW5nIHRhYmxlIGRlY2lkZXMgd2hpY2ggYXBwIG9wZW5zIGl0IChSRVBPX0NPTlRFTlRfRElTUEFUQ0hfU1BFQ1xuLy8gICAgIMKnNCkuIEFuIGFwcC1mb3JtIG1hcmtlciAoYG9wZW5zV2l0aC5hcHBgLCBCVU5ETEVfRU1CRURESU5HIMKnNGIuMSkgZG9lcyBuYW1lIGFuXG4vLyAgICAgYXBwLCBhbmQgdGhpcyBmaWxlIHN0aWxsIG5ldmVyIHJlYWRzIGl0OiB0aGF0IGZvcm0gaXMgaW52b2tlZCB0aHJvdWdoIHRoZSBvbmVcbi8vICAgICBmaXhlZCBjb250cmFjdCB7QGxpbmsgQVBQX0ZPUk1fQ09OVFJBQ1R9IHdpdGggdGhlIGRpcmVjdG9yeSBhbG9uZSwgYW5kIHRoZSBIT1NUXG4vLyAgICAgcmVhZHMgdGhlIG1hcmtlciwgcmVzb2x2ZXMgdGhlIG9wZW5lciBhbmQgb2ZmZXJzIGl0IGJlZm9yZSBhbnl0aGluZyBydW5zXG4vLyAgICAgKMKnNGIuMiBydWxlIDIpLiBTbyB0aGVyZSBpcyBzdGlsbCBub3RoaW5nIGFwcC1zaGFwZWQgdG8gcGFyc2UsIG9yIHRvIHBhc3Mgb24uXG5cbi8qKlxuICogVGhlIGNvbnRyYWN0IGFuIEFQUC1mb3JtIG1hcmtlciBpcyBvcGVuZWQgdGhyb3VnaCAoQlVORExFX0VNQkVERElORyDCpzRiLjIgcnVsZSAyKS5cbiAqIFRoZSBvbmUgdGFzayBuYW1lIGluIHRoaXMgZmlsZSwgYW5kIGRlbGliZXJhdGVseSBzbzogaXQgaXMgbm90IGEgbWFya2VyJ3MgY2hvaWNlXG4gKiBidXQgdGhlIHByb3RvY29sJ3Mgc2luZ2xlIGRvb3IgZm9yIGV2ZXJ5IGFwcC1kZWNsYXJlZCBidW5kbGUsIHdoYXRldmVyIGFwcCBpdCBuYW1lcy5cbiAqIEEgdGFzay1mb3JtIG1hcmtlciBuYW1pbmcgaXQgb2ZmZXJzIG5vdGhpbmcgKHRoZSBob3N0IHJlZnVzZXMgdGhlIGN5Y2xlKS5cbiAqL1xuZXhwb3J0IGNvbnN0IEFQUF9GT1JNX0NPTlRSQUNUID0gXCJvcGVuLWRlY2xhcmVkXCI7XG5cbi8qKiBUaGUgbWFya2VyIGZpbGUgYSBkaXJlY3RvcnkgY2FycmllcyB0byBkZWNsYXJlIHdoYXQgb3BlbnMgaXQuICovXG5leHBvcnQgY29uc3QgQ09OVEVOVF9NQVJLRVJfRklMRSA9IFwiaW1tZWRpYXRlbHkucnVuLmpzb25cIjtcblxuLyoqIFdoYXQgYSBtYXJrZXIgZGVjbGFyZXMsIG9uY2UgdmFsaWRhdGVkLiAqL1xuZXhwb3J0IGludGVyZmFjZSBPcGVuc1dpdGhNYXJrZXIge1xuICAvKiogVGhlIHRhc2sgQ09OVFJBQ1QgdG8gaW52b2tlOiB0aGUgbWFya2VyJ3Mgb3duIGB0YXNrYCwgb3Ige0BsaW5rIEFQUF9GT1JNX0NPTlRSQUNUfVxuICAgKiAgZm9yIGFuIGFwcC1mb3JtIG1hcmtlci4gKi9cbiAgdGFzazogc3RyaW5nO1xuICAvKiogVGhlIENPTlRSQUNUIHZlcnNpb246IHRoZSBvbmUgdGhlIGF1dGhvciB3cm90ZSBmb3IgdGhlIHRhc2sgZm9ybSAoYFwiMS4wXCJgIHdoZW5cbiAgICogIG9taXR0ZWQpLCBhbmQgYWx3YXlzIGBcIjEuMFwiYCBmb3IgdGhlIGFwcCBmb3JtIOKAlCB3aG9zZSBvd24gYHZlcnNpb25gIGlzIGEgYnVuZGxlXG4gICAqICBmb3JtYXQgdGhlIGhvc3QgY2hlY2tzIGFnYWluc3QgdGhlIG9wZW5lciwgbm90IGEgY29udHJhY3QgdmVyc2lvbi4gKi9cbiAgdmVyc2lvbjogc3RyaW5nO1xuICAvKiogV2hhdCB0aGUgZGlyZWN0b3J5IElTLCBpbiB0aGUgYXV0aG9yJ3Mgd29yZHMg4oCUIHRoZSBsYWJlbCdzIG9ubHkgc291cmNlLiAqL1xuICBraW5kPzogc3RyaW5nO1xufVxuXG4vKiogQW4gb2ZmZXIgdGhlIGZpbGUgbWFuYWdlciBtYXkgcmVuZGVyIGZvciBhIGRpcmVjdG9yeS4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgT3BlbnNXaXRoT2ZmZXIge1xuICB0YXNrOiBzdHJpbmc7XG4gIHZlcnNpb246IHN0cmluZztcbiAgLyoqIFRoZSBtZW51IGxhYmVsLCBkZXJpdmVkIGZyb20gdGhlIG1hcmtlcidzIGBraW5kYCAob3IgYSBkZWNsYXJlZCB2aWV3J3MgYG5hbWVgKS4gKi9cbiAgbGFiZWw6IHN0cmluZztcbiAgLyoqIFIzLTc4OSAoQlVORExFX0VNQkVERElORyDCpzRiLjFhKSDigJQgdGhlIE5BTUUgb2YgYSB2aWV3IHRoZSBtYXJrZXIgZGVjbGFyZXMsIHBhc3NlZCB0b1xuICAgKiAgYG9wZW4tZGVjbGFyZWRgIGFzIGB2aWV3YC4gVGhlIHZpZXcncyBhcHAgaXMgbmV2ZXIgcmVhZCBoZXJlOiB0aGUgaG9zdCByZXNvbHZlcyBpdC4gKi9cbiAgdmlldz86IHN0cmluZztcbn1cblxuLyoqIFdoYXQgdGhlIGFwcCBtYXkgY3VycmVudGx5IG9mZmVyLiBEYXRhLCBub3QgY29kZSDigJQgc2VlIHRoZSBoZWFkZXIuICovXG5leHBvcnQgaW50ZXJmYWNlIE9wZW5zV2l0aFBvbGljeSB7XG4gIC8qKiBUaGUgdGFzayBjb250cmFjdHMgdGhpcyBhcHAgZGVjbGFyZXMgaXQgaW52b2tlcyAoaXRzIGBpbnZva2VzYCBtYW5pZmVzdCkuICovXG4gIG9mZmVyYWJsZTogcmVhZG9ubHkgc3RyaW5nW107XG4gIC8qKiBDb250cmFjdHMgdGhlIGhvc3QgaGFzIHJlZnVzZWQgYXQgaW52b2tlIHRpbWUgdGhpcyBzZXNzaW9uLCBzbyB0aGUgYWZmb3JkYW5jZVxuICAgKiAgd2l0aGRyYXdzIGl0c2VsZiBpbnN0ZWFkIG9mIG9mZmVyaW5nIGEgc2Vjb25kIGRlYWQgY2xpY2suICovXG4gIHVuYXZhaWxhYmxlPzogUmVhZG9ubHlTZXQ8c3RyaW5nPjtcbn1cblxuLy8gQSBga2luZGAgaXMgYXV0aG9yLWF1dGhvcmVkIHRleHQgdGhhdCBsYW5kcyBpbiBVSS4gS2VlcCBpdCB0byBhIHNob3J0LCBib3JpbmcsXG4vLyBzaW5nbGUtbGluZSB0b2tlbjogbGV0dGVycywgZGlnaXRzLCBzcGFjZXMgYW5kIHRoZSB0d28gam9pbmVycyBhIGNvbXBvdW5kIGtpbmRcbi8vIHBsYXVzaWJseSB1c2VzLiBBbnl0aGluZyBlbHNlIChjb250cm9sIGNoYXJhY3RlcnMsIG1hcmt1cCwgYSBwYXJhZ3JhcGgsIGFcbi8vIHJpZ2h0LXRvLWxlZnQgb3ZlcnJpZGUpIGlzIG5vdCBzYW5pdGl6ZWQgaW50byBzaGFwZSDigJQgaXQgaXMgc2ltcGx5IG5vdCB1c2VkLCBhbmRcbi8vIHRoZSBnZW5lcmljIGxhYmVsIGlzIHNob3duIGluc3RlYWQuIFJlZnVzaW5nIGlzIGFsd2F5cyBzYWZlIGhlcmU6IHRoZSBsYWJlbCBpc1xuLy8gZGVjb3JhdGlvbiwgYW5kIHRoZSBjb250cmFjdCBzdGlsbCBvcGVucy5cbmNvbnN0IEtJTkRfUkUgPSAvXlthLXowLTldW2EtejAtOSBfLV17MCwyM30kL2k7XG5cbi8qKiBUaGUgbGFiZWwgZm9yIGEgbWFya2VyIGBraW5kYCwgb3IgdGhlIGdlbmVyaWMgb25lIHdoZW4gdGhlcmUgaXMgbm8gdXNhYmxlIGtpbmQuICovXG5leHBvcnQgZnVuY3Rpb24gb3BlbldpdGhMYWJlbChraW5kOiBzdHJpbmcgfCB1bmRlZmluZWQpOiBzdHJpbmcge1xuICBjb25zdCB0cmltbWVkID0gdHlwZW9mIGtpbmQgPT09IFwic3RyaW5nXCIgPyBraW5kLnRyaW0oKSA6IFwiXCI7XG4gIHJldHVybiBLSU5EX1JFLnRlc3QodHJpbW1lZCkgPyBgT3BlbiBhcyAke3RyaW1tZWQudG9Mb3dlckNhc2UoKX1gIDogXCJPcGVuIHdpdGggaXRzIGFwcFwiO1xufVxuXG4vKiogwqc0Yi4xYTogYXQgbW9zdCB0aGlzIG1hbnkgZGVjbGFyZWQgdmlld3MgcGVyIG1hcmtlcjsgbmFtZXMgYXJlIHBsYWluIHRleHQg4omkIDQwIGNoYXJzLiAqL1xuY29uc3QgTUFYX1ZJRVdTID0gODtcbmNvbnN0IFZJRVdfTkFNRV9NQVggPSA0MDtcbi8vIFRoZSBob3N0J3MgbGFiZWwgY2xhc3MgKHNpdGUtbWFpbiBgY29udGVudE1hcmtlci50c2AgaXNVbnNhZmVMYWJlbENoYXIpOiBjb250cm9sXG4vLyBjaGFyYWN0ZXJzLCBsaW5lL3BhcmFncmFwaCBzZXBhcmF0b3JzIGFuZCBldmVyeSBiaWRpIGNvbnRyb2wg4oCUIG1hcmtzLCBlbWJlZGRpbmdzLFxuLy8gb3ZlcnJpZGVzLCBpc29sYXRlcy4gQSBsYWJlbCBtdXN0IHJlYWQgYXMgd2hhdCBpdCBpcy5cbmNvbnN0IGlzVW5zYWZlTGFiZWxDaGFyID0gKGM6IG51bWJlcik6IGJvb2xlYW4gPT5cbiAgYyA8PSAweDFmIHx8XG4gIChjID49IDB4N2YgJiYgYyA8PSAweDlmKSB8fFxuICBjID09PSAweDA2MWMgfHxcbiAgYyA9PT0gMHgyMDBlIHx8XG4gIGMgPT09IDB4MjAwZiB8fFxuICAoYyA+PSAweDIwMjggJiYgYyA8PSAweDIwMmUpIHx8XG4gIChjID49IDB4MjA2NiAmJiBjIDw9IDB4MjA2OSk7XG5jb25zdCBoYXNVbnNhZmVMYWJlbENoYXIgPSAoczogc3RyaW5nKTogYm9vbGVhbiA9PiB7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgcy5sZW5ndGg7IGkrKykgaWYgKGlzVW5zYWZlTGFiZWxDaGFyKHMuY2hhckNvZGVBdChpKSkpIHJldHVybiB0cnVlO1xuICByZXR1cm4gZmFsc2U7XG59O1xuLy8gVGhlIGhvc3QncyBzdWJ0cmVlIHNoYXBlIHRlc3QsIHBvcnRlZCB2ZXJiYXRpbSAoc2l0ZS1tYWluIGBidW5kbGVGZWRlcmF0aW9uLnRzYFxuLy8gaXNVbnNhZmVTdWJ0cmVlU2hhcGUgLyBoYXNVbnNhZmVTZWdtZW50cyk6IGJ1bmRsZS1hYnNvbHV0ZSwgbm8gdHJhdmVyc2FsLCBubyBlbXB0eVxuLy8gc2VnbWVudCDigJQgd2hpY2ggcmVmdXNlcyBcIi9cIiBpdHNlbGYsIGFzIHRoZSBob3N0IGRvZXMuXG5jb25zdCB1bnNhZmVTdWJ0cmVlID0gKHM6IHVua25vd24pOiBib29sZWFuID0+IHtcbiAgaWYgKHR5cGVvZiBzICE9PSBcInN0cmluZ1wiIHx8ICFzLnN0YXJ0c1dpdGgoXCIvXCIpKSByZXR1cm4gdHJ1ZTtcbiAgaWYgKHMuaW5jbHVkZXMoXCJcXDBcIikgfHwgcy5pbmNsdWRlcyhcIlxcXFxcIikpIHJldHVybiB0cnVlO1xuICBjb25zdCBzZWdzID0gcy5zcGxpdChcIi9cIik7XG4gIGlmIChzZWdzWzBdID09PSBcIlwiKSBzZWdzLnNoaWZ0KCk7XG4gIGlmIChzZWdzLmxlbmd0aCA+IDEgJiYgc2Vnc1tzZWdzLmxlbmd0aCAtIDFdID09PSBcIlwiKSBzZWdzLnBvcCgpO1xuICByZXR1cm4gc2Vncy5zb21lKChzZWcpID0+IHNlZyA9PT0gXCJcIiB8fCBzZWcgPT09IFwiLlwiIHx8IHNlZyA9PT0gXCIuLlwiKTtcbn07XG5cbi8qKlxuICogUjMtNzg5ICjCpzRiLjFhKSDigJQgb25lIG9mZmVyIHBlciBWSUVXIHRoZSBtYXJrZXIgZGVjbGFyZXMsIGVhY2ggaW52b2tpbmcgYG9wZW4tZGVjbGFyZWRgXG4gKiB3aXRoIGB2aWV3OiA8bmFtZT5gLiBPZmZlcmVkIG9ubHkgd2hlcmUgdGhlIGhvc3Qgd291bGQgb3BlbiBpdDogdGhlIG1hcmtlciBhcyBhIHdob2xlIG11c3RcbiAqIGJlIG9uZSB0aGUgaG9zdCBhY2NlcHRzICh7QGxpbmsgcGFyc2VPcGVuc1dpdGh9IOKAlCBhIHJlamVjdGVkIG1hcmtlciBpcyByZWZ1c2VkIGJlZm9yZSBpdHNcbiAqIHZpZXdzIGFyZSByZWFkKSwgYW5kIGVhY2ggdmlldyBwYXNzZXMgdGhlIGhvc3QncyBvd24gdmlldyByZWZ1c2FscyAoYHBhcnNlVmlld3NgKTogYXBwXG4gKiBmb3JtIG9ubHksIHJldmlzaW9uLWxlc3MsIG5vIGBlbnRyeWAsIGEgYnVuZGxlLWFic29sdXRlIHRyYXZlcnNhbC1mcmVlIGBzdWJ0cmVlYCwgYSBwbGFpblxuICogbmFtZSwgbm8gZHVwbGljYXRlcywgYXQgbW9zdCBlaWdodC4gQSByZWZ1c2VkIG9uZSB3b3VsZCBiZSBhIGRlYWQgY2xpY2sgKGBuby10YXJnZXRgIGRvZXNcbiAqIG5vdCB3aXRoZHJhdyB0aGUgc2hhcmVkIGNvbnRyYWN0KS4gVGhlIHZpZXcncyBhcHAgaXMgdmFsaWRhdGVkIGJ1dCBuZXZlciByZXR1cm5lZC5cbiAqXG4gKiBUaGUgbGFiZWwgaXMgdGhlIHZpZXcncyBuYW1lIGFzIHdyaXR0ZW4g4oCUIG5vdCBsb3dlci1jYXNlZCBhbmQgbm90IGhlbGQgdG8gdGhlIGBraW5kYFxuICogdG9rZW46IMKnNGIuMWEncyBwYXJzZSBydWxlIChwbGFpbiB0ZXh0IOKJpCA0MCwgbm8gY29udHJvbCBvciBiaWRpIGNoYXJhY3RlcnMpIGlzIHdoYXRcbiAqIG1ha2VzIGl0IHNhZmUgdG8gc2hvdywgYW5kIGEgdmlldyBuYW1lIGlzIGEgdGl0bGUgKFwiUm9hZG1hcCBib2FyZFwiKSwgbm90IGEgdHlwZSB3b3JkLlxuICovXG5leHBvcnQgZnVuY3Rpb24gdmlld09mZmVycyh0ZXh0OiBzdHJpbmcgfCBudWxsIHwgdW5kZWZpbmVkLCBwb2xpY3k6IE9wZW5zV2l0aFBvbGljeSk6IE9wZW5zV2l0aE9mZmVyW10ge1xuICBpZiAoIXBvbGljeS5vZmZlcmFibGUuaW5jbHVkZXMoQVBQX0ZPUk1fQ09OVFJBQ1QpIHx8IHBvbGljeS51bmF2YWlsYWJsZT8uaGFzKEFQUF9GT1JNX0NPTlRSQUNUKSkgcmV0dXJuIFtdO1xuICBpZiAocGFyc2VPcGVuc1dpdGgodGV4dCkgPT09IG51bGwpIHJldHVybiBbXTtcbiAgY29uc3Qgb2JqID0gSlNPTi5wYXJzZSh0ZXh0IGFzIHN0cmluZykgYXMgeyB2aWV3cz86IHVua25vd24gfTtcbiAgaWYgKCFBcnJheS5pc0FycmF5KG9iai52aWV3cykpIHJldHVybiBbXTtcbiAgY29uc3Qgb3V0OiBPcGVuc1dpdGhPZmZlcltdID0gW107XG4gIGNvbnN0IHNlZW4gPSBuZXcgU2V0PHN0cmluZz4oKTtcbiAgZm9yIChjb25zdCB2IG9mIG9iai52aWV3cykge1xuICAgIGlmIChvdXQubGVuZ3RoID49IE1BWF9WSUVXUykgYnJlYWs7XG4gICAgaWYgKCF2IHx8IHR5cGVvZiB2ICE9PSBcIm9iamVjdFwiIHx8IEFycmF5LmlzQXJyYXkodikpIGNvbnRpbnVlO1xuICAgIGNvbnN0IGUgPSB2IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICAgIC8vIFRoZSBob3N0IHRlc3RzIHRoZSBVTlRSSU1NRUQgbmFtZSBmb3IgdW5zYWZlIGNoYXJhY3RlcnMgYW5kIHRoZSB0cmltbWVkIG9uZSBmb3IgbGVuZ3RoLlxuICAgIGlmICh0eXBlb2YgZS5uYW1lICE9PSBcInN0cmluZ1wiIHx8IGhhc1Vuc2FmZUxhYmVsQ2hhcihlLm5hbWUpKSBjb250aW51ZTtcbiAgICBjb25zdCBuYW1lID0gZS5uYW1lLnRyaW0oKTtcbiAgICBpZiAobmFtZSA9PT0gXCJcIiB8fCBuYW1lLmxlbmd0aCA+IFZJRVdfTkFNRV9NQVggfHwgc2Vlbi5oYXMobmFtZSkpIGNvbnRpbnVlO1xuICAgIGNvbnN0IG93ID0gZS5vcGVuc1dpdGggYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4gfCB1bmRlZmluZWQ7XG4gICAgaWYgKCFvdyB8fCB0eXBlb2Ygb3cgIT09IFwib2JqZWN0XCIgfHwgQXJyYXkuaXNBcnJheShvdykgfHwgXCJ0YXNrXCIgaW4gb3cgfHwgb3cuZW50cnkgIT09IHVuZGVmaW5lZCkgY29udGludWU7XG4gICAgY29uc3QgYXBwID0gb3cuYXBwO1xuICAgIGlmICh0eXBlb2YgYXBwICE9PSBcInN0cmluZ1wiIHx8IGFwcCA9PT0gXCJcIiB8fCBhcHAuaW5jbHVkZXMoXCJAXCIpIHx8IGFwcC5pbmNsdWRlcyhcIiNcIikpIGNvbnRpbnVlO1xuICAgIGlmICh1bnNhZmVTdWJ0cmVlKGUuc3VidHJlZSkpIGNvbnRpbnVlO1xuICAgIHNlZW4uYWRkKG5hbWUpO1xuICAgIG91dC5wdXNoKHsgdGFzazogQVBQX0ZPUk1fQ09OVFJBQ1QsIHZlcnNpb246IFwiMS4wXCIsIGxhYmVsOiBgT3BlbiBhcyAke25hbWV9YCwgdmlldzogbmFtZSB9KTtcbiAgfVxuICByZXR1cm4gb3V0O1xufVxuXG4vKipcbiAqIFBhcnNlIGEgbWFya2VyIGZpbGUncyBURVhUIGludG8gYSB2YWxpZGF0ZWQgbWFya2VyLCBvciBudWxsLlxuICpcbiAqIE5ldmVyIHRocm93czogdW5yZWFkYWJsZSBieXRlcywgaW52YWxpZCBKU09OLCBhIG5vbi1vYmplY3QsIGEgbWFya2VyIHdpdGggbmVpdGhlclxuICogKG9yIGJvdGgpIG9mIGBvcGVuc1dpdGgudGFza2AgLyBgb3BlbnNXaXRoLmFwcGAgYWxsIG1lYW4gXCJubyBtYXJrZXJcIiDigJQgdGhlIHNhbWVcbiAqIG91dGNvbWUgYXMgYSBmb2xkZXIgdGhhdCBjYXJyaWVzIG5vbmUgYXQgYWxsLiBBbiBhcHAtZm9ybSBtYXJrZXIgY29tZXMgYmFjayBhc1xuICoge0BsaW5rIEFQUF9GT1JNX0NPTlRSQUNUfTsgdGhlIGFwcCBpdCBuYW1lcyBpcyBuZXZlciByZXR1cm5lZC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlT3BlbnNXaXRoKHRleHQ6IHN0cmluZyB8IG51bGwgfCB1bmRlZmluZWQpOiBPcGVuc1dpdGhNYXJrZXIgfCBudWxsIHtcbiAgaWYgKHR5cGVvZiB0ZXh0ICE9PSBcInN0cmluZ1wiIHx8IHRleHQudHJpbSgpID09PSBcIlwiKSByZXR1cm4gbnVsbDtcbiAgbGV0IG9iajogdW5rbm93bjtcbiAgdHJ5IHtcbiAgICBvYmogPSBKU09OLnBhcnNlKHRleHQpO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICBpZiAoIW9iaiB8fCB0eXBlb2Ygb2JqICE9PSBcIm9iamVjdFwiIHx8IEFycmF5LmlzQXJyYXkob2JqKSkgcmV0dXJuIG51bGw7XG4gIGNvbnN0IG9wZW5zV2l0aCA9IChvYmogYXMgeyBvcGVuc1dpdGg/OiB1bmtub3duIH0pLm9wZW5zV2l0aDtcbiAgaWYgKCFvcGVuc1dpdGggfHwgdHlwZW9mIG9wZW5zV2l0aCAhPT0gXCJvYmplY3RcIiB8fCBBcnJheS5pc0FycmF5KG9wZW5zV2l0aCkpIHJldHVybiBudWxsO1xuICBjb25zdCB0YXNrID0gKG9wZW5zV2l0aCBhcyB7IHRhc2s/OiB1bmtub3duIH0pLnRhc2s7XG4gIGNvbnN0IGFwcCA9IChvcGVuc1dpdGggYXMgeyBhcHA/OiB1bmtub3duIH0pLmFwcDtcbiAgY29uc3Qga2luZCA9IChvYmogYXMgeyBraW5kPzogdW5rbm93biB9KS5raW5kO1xuICBjb25zdCBraW5kUGFydCA9IHR5cGVvZiBraW5kID09PSBcInN0cmluZ1wiICYmIGtpbmQudHJpbSgpICE9PSBcIlwiID8geyBraW5kOiBraW5kLnRyaW0oKSB9IDoge307XG4gIC8vIFRoZSBhcHAgZm9ybSBpcyBvZmZlcmVkIG9ubHkgd2hlcmUgdGhlIEhPU1Qgd291bGQgYWNjZXB0IGl0IChzaXRlLW1haW5cbiAgLy8gYHBhcnNlQ29udGVudE1hcmtlcmAsIMKnNGIuMSksIHdpdGggdGhlIGhvc3QncyBvd24gdW50cmltbWVkIGVtcHRpbmVzcyB0ZXN0LiBBIG1hcmtlclxuICAvLyBpdCByZWZ1c2VzIHJlYWNoZXMgYG5vLXRhcmdldGAgYXQgaW52b2tlLCB3aGljaCBkb2VzIG5vdCB3aXRoZHJhdyB0aGUgc2hhcmVkXG4gIC8vIG9wZW4tZGVjbGFyZWQgYWZmb3JkYW5jZSDigJQgc28gb2ZmZXJpbmcgb25lIHdvdWxkIGJlIGEgZGVhZCBjbGljayBvbiBldmVyeSB2aXNpdC5cbiAgY29uc3QgaG9zdEhhc1Rhc2sgPSB0eXBlb2YgdGFzayA9PT0gXCJzdHJpbmdcIiAmJiB0YXNrICE9PSBcIlwiO1xuICBjb25zdCBob3N0SGFzQXBwID0gdHlwZW9mIGFwcCA9PT0gXCJzdHJpbmdcIiAmJiBhcHAgIT09IFwiXCI7XG4gIGlmIChob3N0SGFzVGFzayAmJiBob3N0SGFzQXBwKSByZXR1cm4gbnVsbDsgLy8gYW1iaWd1b3VzLW9wZW5zXG4gIGlmIChob3N0SGFzQXBwKSB7XG4gICAgaWYgKChvcGVuc1dpdGggYXMgeyBlbnRyeT86IHVua25vd24gfSkuZW50cnkgIT09IHVuZGVmaW5lZCkgcmV0dXJuIG51bGw7IC8vIGVudHJ5LWluLWFwcFxuICAgIC8vIHJldmlzaW9uLWluLWFwcDogYSByZWYgKGBA4oCmYCkgb3IgYSBjb21taXQgcGluIChgI+KApmApIOKAlCB0aGUgcmVhZGVyIGNob29zZXMgdGhlIGNvbW1pdC5cbiAgICBpZiAoKGFwcCBhcyBzdHJpbmcpLmluY2x1ZGVzKFwiQFwiKSB8fCAoYXBwIGFzIHN0cmluZykuaW5jbHVkZXMoXCIjXCIpKSByZXR1cm4gbnVsbDtcbiAgICBpZiAoISh0eXBlb2Yga2luZCA9PT0gXCJzdHJpbmdcIiAmJiBraW5kICE9PSBcIlwiKSkgcmV0dXJuIG51bGw7IC8vIG1pc3Npbmcta2luZFxuICAgIC8vIE9wZW5lZCB0aHJvdWdoIHRoZSBmaXhlZCBjb250cmFjdCBhdCBpdHMgb3duIHYxLiBUaGUgbWFya2VyJ3MgYHZlcnNpb25gIGlzIHRoZVxuICAgIC8vIEJVTkRMRSBmb3JtYXQgdGhlIG9wZW5lciBtdXN0IGNvdmVyICjCpzRiLjEpIOKAlCB0aGUgaG9zdCBjaGVja3MgaXQgYWdhaW5zdCB0aGVcbiAgICAvLyBvcGVuZXIncyBgb3BlbnNgIHJhbmdlLCBzbyBpdCBpcyBub3QgYSBjb250cmFjdCB2ZXJzaW9uIGFuZCBub3Qgb3Vycy5cbiAgICByZXR1cm4geyB0YXNrOiBBUFBfRk9STV9DT05UUkFDVCwgdmVyc2lvbjogXCIxLjBcIiwgLi4ua2luZFBhcnQgfTtcbiAgfVxuICBjb25zdCBoYXNUYXNrID0gdHlwZW9mIHRhc2sgPT09IFwic3RyaW5nXCIgJiYgdGFzay50cmltKCkgIT09IFwiXCI7XG4gIGlmICghaGFzVGFzaykgcmV0dXJuIG51bGw7XG4gIC8vIEEgdGFzay1mb3JtIG1hcmtlciBuYW1pbmcgdGhlIGFwcC1mb3JtIGRvb3Igd291bGQgcmUtZW50ZXIgdGhlIGNvbnRyYWN0IHRoYXQgcmVhZFxuICAvLyBpdDsgdGhlIGhvc3QgcmVmdXNlcyB0aGF0IGFzIGEgY3ljbGUgKGBvcGVuRGVjbGFyZWRSZWZ1c2FsYCksIHNvIGl0IG9mZmVycyBub3RoaW5nLlxuICBpZiAoKHRhc2sgYXMgc3RyaW5nKS50cmltKCkgPT09IEFQUF9GT1JNX0NPTlRSQUNUKSByZXR1cm4gbnVsbDtcbiAgY29uc3QgdmVyc2lvbiA9IChvcGVuc1dpdGggYXMgeyB2ZXJzaW9uPzogdW5rbm93biB9KS52ZXJzaW9uO1xuICByZXR1cm4ge1xuICAgIHRhc2s6ICh0YXNrIGFzIHN0cmluZykudHJpbSgpLFxuICAgIC8vIEFuIG9taXR0ZWQgdmVyc2lvbiBtZWFucyB0aGUgY29udHJhY3QncyB2MSBzaGFwZS4gVGhlIGhvc3Qgc3RpbGwgZW5mb3JjZXMgdGhlXG4gICAgLy8gVDMxIGNvbXBhdGliaWxpdHkgY2hlY2sgYWdhaW5zdCB0aGUgQk9VTkQgYXBwIGF0IGludm9rZSB0aW1lLCBzbyBkZWZhdWx0aW5nXG4gICAgLy8gaGVyZSB3aWRlbnMgbm90aGluZy5cbiAgICB2ZXJzaW9uOiB0eXBlb2YgdmVyc2lvbiA9PT0gXCJzdHJpbmdcIiAmJiB2ZXJzaW9uLnRyaW0oKSAhPT0gXCJcIiA/IHZlcnNpb24udHJpbSgpIDogXCIxLjBcIixcbiAgICAuLi5raW5kUGFydCxcbiAgfTtcbn1cblxuLyoqXG4gKiBUaGUgb2ZmZXIgZm9yIGEgZGlyZWN0b3J5J3MgbWFya2VyIHRleHQgdW5kZXIgYSBwb2xpY3ksIG9yIG51bGwgZm9yIG5vIGFmZm9yZGFuY2UuXG4gKlxuICogTnVsbCDigJQgYW4gYWJzZW50IGFmZm9yZGFuY2Ug4oCUIGlzIHRoZSBvdXRjb21lIGZvciBldmVyeSBuZWdhdGl2ZSBjYXNlLCBpbmNsdWRpbmcgYVxuICogbWFya2VyIG5hbWluZyBhIGNvbnRyYWN0IHRoaXMgYXBwIGRvZXMgbm90IGludm9rZTogYW4gdW5ib3VuZCBvciB1bmtub3duIGNvbnRyYWN0XG4gKiBtdXN0IGRlZ3JhZGUgdG8gKm5vdGhpbmcgdG8gY2xpY2sqLCBub3QgdG8gYSBwcm90b2NvbCBlcnJvciB0aGUgdXNlciBoYXMgdG8gcmVhZC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIG9wZW5zV2l0aE9mZmVyKFxuICB0ZXh0OiBzdHJpbmcgfCBudWxsIHwgdW5kZWZpbmVkLFxuICBwb2xpY3k6IE9wZW5zV2l0aFBvbGljeSxcbik6IE9wZW5zV2l0aE9mZmVyIHwgbnVsbCB7XG4gIGNvbnN0IG1hcmtlciA9IHBhcnNlT3BlbnNXaXRoKHRleHQpO1xuICBpZiAoIW1hcmtlcikgcmV0dXJuIG51bGw7XG4gIGlmICghcG9saWN5Lm9mZmVyYWJsZS5pbmNsdWRlcyhtYXJrZXIudGFzaykpIHJldHVybiBudWxsO1xuICBpZiAocG9saWN5LnVuYXZhaWxhYmxlPy5oYXMobWFya2VyLnRhc2spKSByZXR1cm4gbnVsbDtcbiAgcmV0dXJuIHsgdGFzazogbWFya2VyLnRhc2ssIHZlcnNpb246IG1hcmtlci52ZXJzaW9uLCBsYWJlbDogb3BlbldpdGhMYWJlbChtYXJrZXIua2luZCkgfTtcbn1cblxuLyoqIFdoYXQgdGhlIGFwcCBtYXkgY3VycmVudGx5IExBVU5DSCBpbnRvIHRoZSBzdGFnZSAoUjMtMTU5KS4gRGF0YSwgbGlrZVxuICogIHtAbGluayBPcGVuc1dpdGhQb2xpY3l9IOKAlCBgbGF1bmNoYWJsZWAgbWlycm9ycyB0aGUgYGxhdW5jaGVzYCBtYW5pZmVzdCBibG9jay4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgT3BlbnNJblBsYWNlUG9saWN5IHtcbiAgLyoqIFRoZSB0YXNrIGNvbnRyYWN0cyB0aGlzIGFwcCBkZWNsYXJlcyBpdCBsYXVuY2hlcyAoaXRzIGBsYXVuY2hlc2AgbWFuaWZlc3QpLiAqL1xuICBsYXVuY2hhYmxlOiByZWFkb25seSBzdHJpbmdbXTtcbn1cblxuLyoqXG4gKiBUaGUgaW50by1zdGFnZSB0d2luIG9mIGFuIG9wZW4td2l0aCBvZmZlciAoUjMtMTU5KTogcnVuIHRoZSBmb2xkZXIncyBwcm9qZWN0XG4gKiBUTy1SVU4gaW4gdGhlIHN0YWdlIHJlZ2lvbiwgcmVwbGFjaW5nIHRoZSBmb2NhbCBhcHAsIHJhdGhlciB0aGFuIG9wZW5pbmcgaXRcbiAqIGZvci1yZXN1bHQuIE9mZmVyZWQgb25seSBmb3IgYSBjb250cmFjdCB0aGlzIGFwcCBkZWNsYXJlcyBpdCBMQVVOQ0hFUyDigJQgb25lIGl0XG4gKiBtYXkgbWVyZWx5IGludm9rZSBnZXRzIHRoZSBmb3ItcmVzdWx0IGFmZm9yZGFuY2UgYWxvbmUsIGFuZCBhIGZvbGRlciB3aXRoIG5vXG4gKiBvZmZlciBnZXRzIG5vdGhpbmcgKGFuIGFic2VudCBhZmZvcmRhbmNlLCBuZXZlciBhbiBlcnJvcikuXG4gKlxuICogVGhlIGxhYmVsIGlzIEZJWEVELCBuZXZlciBkZXJpdmVkIGZyb20gdGhlIG1hcmtlcidzIGBraW5kYDogdGhlIHZlcmIgaXMgdGhlXG4gKiBwcm9kdWN0J3MgKFwib3BlbiBpbiBwbGFjZVwiKSwgYW5kIHRoZSBsZXNzIHVudHJ1c3RlZCB0ZXh0IHJlYWNoZXMgYSBtZW51IHRoZVxuICogYmV0dGVyLlxuICpcbiAqIFVubGlrZSB0aGUgZm9yLXJlc3VsdCBvZmZlciB0aGVyZSBpcyBOTyBzZXNzaW9uIHdpdGhkcmF3YWwgaGVyZTogdGhlIGhvc3RcbiAqIHJlc29sdmVzIGB1bnN1cHBvcnRlZGAg4oCUIHRoZSBvbmx5IGxhdW5jaCBjb2RlIHRoYXQgY291bGQgYmUgYSBjb250cmFjdCB2ZXJkaWN0IOKAlFxuICogZm9yIHRyYW5zaWVudCBzdGF0ZXMgdG9vICh0aGUgbGF1bmNoIGhvc3Qgbm90IHlldCBtb3VudGVkLCBhbiBhYnNlbnQgbGF1bmNoXG4gKiBjb250ZXh0LCBhIGNyZWF0ZSBmYWlsaW5nIGJlZm9yZSBiaW5kKSwgc28gbm8gYExhdW5jaEVycm9yQ29kZWAgaXMgYSBzYWZlXG4gKiBzZXNzaW9uLXBlcm1hbmVudCB2ZXJkaWN0IGFuZCBhIHJlZnVzYWwgc2ltcGx5IGxlYXZlcyB0aGUgYWZmb3JkYW5jZSBzdGFuZGluZy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIG9wZW5zSW5QbGFjZU9mZmVyKFxuICBvZmZlcjogT3BlbnNXaXRoT2ZmZXIgfCBudWxsLFxuICBwb2xpY3k6IE9wZW5zSW5QbGFjZVBvbGljeSxcbik6IE9wZW5zV2l0aE9mZmVyIHwgbnVsbCB7XG4gIGlmICghb2ZmZXIpIHJldHVybiBudWxsO1xuICBpZiAoIXBvbGljeS5sYXVuY2hhYmxlLmluY2x1ZGVzKG9mZmVyLnRhc2spKSByZXR1cm4gbnVsbDtcbiAgcmV0dXJuIHsgdGFzazogb2ZmZXIudGFzaywgdmVyc2lvbjogb2ZmZXIudmVyc2lvbiwgbGFiZWw6IFwiT3BlbiBpbiBwbGFjZVwiIH07XG59XG5cbi8qKlxuICogU2hvdWxkIGEgcmVmdXNhbCBXSVRIRFJBVyB0aGUgYWZmb3JkYW5jZSBmb3IgdGhpcyBjb250cmFjdCBmb3IgdGhlIHJlc3Qgb2YgdGhlXG4gKiBzZXNzaW9uLCBvciB3YXMgaXQgYWJvdXQgdGhpcyBvbmUgYXR0ZW1wdD9cbiAqXG4gKiBgY2FuY2VsbGVkYCBpcyB0aGUgdXNlciBjbG9zaW5nIHRoZSB2aWV3ZXIg4oCUIHRoZSBtb3N0IG9yZGluYXJ5IG91dGNvbWUgdGhlcmUgaXMsIGFuZFxuICogdGhlIGFmZm9yZGFuY2UgbXVzdCBzdXJ2aXZlIGl0LiBBIHJlZnVzYWwgdGhhdCBpcyBhIHByb3BlcnR5IG9mIHRoZSBDT05UUkFDVCAobm90aGluZ1xuICogYm91bmQgdG8gaXQsIHRoaXMgYXBwIG5vdCBkZWNsYXJlZCBmb3IgaXQsIHRoZSB2ZXJzaW9ucyBubyBsb25nZXIgbWVldCkgd2lsbCByZXBlYXRcbiAqIGlkZW50aWNhbGx5IG9uIGV2ZXJ5IGNsaWNrLCBzbyB0aGUgaG9uZXN0IHJlc3BvbnNlIGlzIHRvIHN0b3Agb2ZmZXJpbmcgaXQuIEFueXRoaW5nXG4gKiBlbHNlIChhIHRyYW5zaWVudCBob3N0IGZhaWx1cmUsIGFuIHVua25vd24gY29kZSkgbGVhdmVzIHRoZSBvZmZlciBzdGFuZGluZy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHdpdGhkcmF3c09mZmVyKGNvZGU6IHN0cmluZyB8IHVuZGVmaW5lZCk6IGJvb2xlYW4ge1xuICByZXR1cm4gY29kZSA9PT0gXCJuby1zdWNoLXRhc2tcIiB8fCBjb2RlID09PSBcIm5vdC1kZWNsYXJlZFwiIHx8IGNvZGUgPT09IFwidGFzay12ZXJzaW9uLW1pc21hdGNoXCI7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLE1BQU1BLGlCQUFpQixHQUFBQyxPQUFBLENBQUFELGlCQUFBLEdBQUcsZUFBZTs7QUFFaEQ7QUFDTyxNQUFNRSxtQkFBbUIsR0FBQUQsT0FBQSxDQUFBQyxtQkFBQSxHQUFHLHNCQUFzQjs7QUFFekQ7O0FBYUE7O0FBV0E7O0FBU0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTUMsT0FBTyxHQUFHLDhCQUE4Qjs7QUFFOUM7QUFDTyxTQUFTQyxhQUFhQSxDQUFDQyxJQUF3QixFQUFVO0VBQzlELE1BQU1DLE9BQU8sR0FBRyxPQUFPRCxJQUFJLEtBQUssUUFBUSxHQUFHQSxJQUFJLENBQUNFLElBQUksQ0FBQyxDQUFDLEdBQUcsRUFBRTtFQUMzRCxPQUFPSixPQUFPLENBQUNLLElBQUksQ0FBQ0YsT0FBTyxDQUFDLEdBQUcsV0FBV0EsT0FBTyxDQUFDRyxXQUFXLENBQUMsQ0FBQyxFQUFFLEdBQUcsbUJBQW1CO0FBQ3pGOztBQUVBO0FBQ0EsTUFBTUMsU0FBUyxHQUFHLENBQUM7QUFDbkIsTUFBTUMsYUFBYSxHQUFHLEVBQUU7QUFDeEI7QUFDQTtBQUNBO0FBQ0EsTUFBTUMsaUJBQWlCLEdBQUlDLENBQVMsSUFDbENBLENBQUMsSUFBSSxJQUFJLElBQ1JBLENBQUMsSUFBSSxJQUFJLElBQUlBLENBQUMsSUFBSSxJQUFLLElBQ3hCQSxDQUFDLEtBQUssTUFBTSxJQUNaQSxDQUFDLEtBQUssTUFBTSxJQUNaQSxDQUFDLEtBQUssTUFBTSxJQUNYQSxDQUFDLElBQUksTUFBTSxJQUFJQSxDQUFDLElBQUksTUFBTyxJQUMzQkEsQ0FBQyxJQUFJLE1BQU0sSUFBSUEsQ0FBQyxJQUFJLE1BQU87QUFDOUIsTUFBTUMsa0JBQWtCLEdBQUlDLENBQVMsSUFBYztFQUNqRCxLQUFLLElBQUlDLENBQUMsR0FBRyxDQUFDLEVBQUVBLENBQUMsR0FBR0QsQ0FBQyxDQUFDRSxNQUFNLEVBQUVELENBQUMsRUFBRSxFQUFFLElBQUlKLGlCQUFpQixDQUFDRyxDQUFDLENBQUNHLFVBQVUsQ0FBQ0YsQ0FBQyxDQUFDLENBQUMsRUFBRSxPQUFPLElBQUk7RUFDdEYsT0FBTyxLQUFLO0FBQ2QsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBLE1BQU1HLGFBQWEsR0FBSUosQ0FBVSxJQUFjO0VBQzdDLElBQUksT0FBT0EsQ0FBQyxLQUFLLFFBQVEsSUFBSSxDQUFDQSxDQUFDLENBQUNLLFVBQVUsQ0FBQyxHQUFHLENBQUMsRUFBRSxPQUFPLElBQUk7RUFDNUQsSUFBSUwsQ0FBQyxDQUFDTSxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUlOLENBQUMsQ0FBQ00sUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFLE9BQU8sSUFBSTtFQUNyRCxNQUFNQyxJQUFJLEdBQUdQLENBQUMsQ0FBQ1EsS0FBSyxDQUFDLEdBQUcsQ0FBQztFQUN6QixJQUFJRCxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssRUFBRSxFQUFFQSxJQUFJLENBQUNFLEtBQUssQ0FBQyxDQUFDO0VBQ2hDLElBQUlGLElBQUksQ0FBQ0wsTUFBTSxHQUFHLENBQUMsSUFBSUssSUFBSSxDQUFDQSxJQUFJLENBQUNMLE1BQU0sR0FBRyxDQUFDLENBQUMsS0FBSyxFQUFFLEVBQUVLLElBQUksQ0FBQ0csR0FBRyxDQUFDLENBQUM7RUFDL0QsT0FBT0gsSUFBSSxDQUFDSSxJQUFJLENBQUVDLEdBQUcsSUFBS0EsR0FBRyxLQUFLLEVBQUUsSUFBSUEsR0FBRyxLQUFLLEdBQUcsSUFBSUEsR0FBRyxLQUFLLElBQUksQ0FBQztBQUN0RSxDQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBU0MsVUFBVUEsQ0FBQ0MsSUFBK0IsRUFBRUMsTUFBdUIsRUFBb0I7RUFDckcsSUFBSSxDQUFDQSxNQUFNLENBQUNDLFNBQVMsQ0FBQ1YsUUFBUSxDQUFDckIsaUJBQWlCLENBQUMsSUFBSThCLE1BQU0sQ0FBQ0UsV0FBVyxFQUFFQyxHQUFHLENBQUNqQyxpQkFBaUIsQ0FBQyxFQUFFLE9BQU8sRUFBRTtFQUMxRyxJQUFJa0MsY0FBYyxDQUFDTCxJQUFJLENBQUMsS0FBSyxJQUFJLEVBQUUsT0FBTyxFQUFFO0VBQzVDLE1BQU1NLEdBQUcsR0FBR0MsSUFBSSxDQUFDQyxLQUFLLENBQUNSLElBQWMsQ0FBd0I7RUFDN0QsSUFBSSxDQUFDUyxLQUFLLENBQUNDLE9BQU8sQ0FBQ0osR0FBRyxDQUFDSyxLQUFLLENBQUMsRUFBRSxPQUFPLEVBQUU7RUFDeEMsTUFBTUMsR0FBcUIsR0FBRyxFQUFFO0VBQ2hDLE1BQU1DLElBQUksR0FBRyxJQUFJQyxHQUFHLENBQVMsQ0FBQztFQUM5QixLQUFLLE1BQU1DLENBQUMsSUFBSVQsR0FBRyxDQUFDSyxLQUFLLEVBQUU7SUFDekIsSUFBSUMsR0FBRyxDQUFDeEIsTUFBTSxJQUFJUCxTQUFTLEVBQUU7SUFDN0IsSUFBSSxDQUFDa0MsQ0FBQyxJQUFJLE9BQU9BLENBQUMsS0FBSyxRQUFRLElBQUlOLEtBQUssQ0FBQ0MsT0FBTyxDQUFDSyxDQUFDLENBQUMsRUFBRTtJQUNyRCxNQUFNQyxDQUFDLEdBQUdELENBQTRCO0lBQ3RDO0lBQ0EsSUFBSSxPQUFPQyxDQUFDLENBQUNDLElBQUksS0FBSyxRQUFRLElBQUloQyxrQkFBa0IsQ0FBQytCLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLEVBQUU7SUFDOUQsTUFBTUEsSUFBSSxHQUFHRCxDQUFDLENBQUNDLElBQUksQ0FBQ3ZDLElBQUksQ0FBQyxDQUFDO0lBQzFCLElBQUl1QyxJQUFJLEtBQUssRUFBRSxJQUFJQSxJQUFJLENBQUM3QixNQUFNLEdBQUdOLGFBQWEsSUFBSStCLElBQUksQ0FBQ1QsR0FBRyxDQUFDYSxJQUFJLENBQUMsRUFBRTtJQUNsRSxNQUFNQyxFQUFFLEdBQUdGLENBQUMsQ0FBQ0csU0FBZ0Q7SUFDN0QsSUFBSSxDQUFDRCxFQUFFLElBQUksT0FBT0EsRUFBRSxLQUFLLFFBQVEsSUFBSVQsS0FBSyxDQUFDQyxPQUFPLENBQUNRLEVBQUUsQ0FBQyxJQUFJLE1BQU0sSUFBSUEsRUFBRSxJQUFJQSxFQUFFLENBQUNFLEtBQUssS0FBS0MsU0FBUyxFQUFFO0lBQ2xHLE1BQU1DLEdBQUcsR0FBR0osRUFBRSxDQUFDSSxHQUFHO0lBQ2xCLElBQUksT0FBT0EsR0FBRyxLQUFLLFFBQVEsSUFBSUEsR0FBRyxLQUFLLEVBQUUsSUFBSUEsR0FBRyxDQUFDOUIsUUFBUSxDQUFDLEdBQUcsQ0FBQyxJQUFJOEIsR0FBRyxDQUFDOUIsUUFBUSxDQUFDLEdBQUcsQ0FBQyxFQUFFO0lBQ3JGLElBQUlGLGFBQWEsQ0FBQzBCLENBQUMsQ0FBQ08sT0FBTyxDQUFDLEVBQUU7SUFDOUJWLElBQUksQ0FBQ1csR0FBRyxDQUFDUCxJQUFJLENBQUM7SUFDZEwsR0FBRyxDQUFDYSxJQUFJLENBQUM7TUFBRUMsSUFBSSxFQUFFdkQsaUJBQWlCO01BQUV3RCxPQUFPLEVBQUUsS0FBSztNQUFFQyxLQUFLLEVBQUUsV0FBV1gsSUFBSSxFQUFFO01BQUVZLElBQUksRUFBRVo7SUFBSyxDQUFDLENBQUM7RUFDN0Y7RUFDQSxPQUFPTCxHQUFHO0FBQ1o7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVNQLGNBQWNBLENBQUNMLElBQStCLEVBQTBCO0VBQ3RGLElBQUksT0FBT0EsSUFBSSxLQUFLLFFBQVEsSUFBSUEsSUFBSSxDQUFDdEIsSUFBSSxDQUFDLENBQUMsS0FBSyxFQUFFLEVBQUUsT0FBTyxJQUFJO0VBQy9ELElBQUk0QixHQUFZO0VBQ2hCLElBQUk7SUFDRkEsR0FBRyxHQUFHQyxJQUFJLENBQUNDLEtBQUssQ0FBQ1IsSUFBSSxDQUFDO0VBQ3hCLENBQUMsQ0FBQyxNQUFNO0lBQ04sT0FBTyxJQUFJO0VBQ2I7RUFDQSxJQUFJLENBQUNNLEdBQUcsSUFBSSxPQUFPQSxHQUFHLEtBQUssUUFBUSxJQUFJRyxLQUFLLENBQUNDLE9BQU8sQ0FBQ0osR0FBRyxDQUFDLEVBQUUsT0FBTyxJQUFJO0VBQ3RFLE1BQU1hLFNBQVMsR0FBSWIsR0FBRyxDQUE2QmEsU0FBUztFQUM1RCxJQUFJLENBQUNBLFNBQVMsSUFBSSxPQUFPQSxTQUFTLEtBQUssUUFBUSxJQUFJVixLQUFLLENBQUNDLE9BQU8sQ0FBQ1MsU0FBUyxDQUFDLEVBQUUsT0FBTyxJQUFJO0VBQ3hGLE1BQU1PLElBQUksR0FBSVAsU0FBUyxDQUF3Qk8sSUFBSTtFQUNuRCxNQUFNSixHQUFHLEdBQUlILFNBQVMsQ0FBdUJHLEdBQUc7RUFDaEQsTUFBTTlDLElBQUksR0FBSThCLEdBQUcsQ0FBd0I5QixJQUFJO0VBQzdDLE1BQU1zRCxRQUFRLEdBQUcsT0FBT3RELElBQUksS0FBSyxRQUFRLElBQUlBLElBQUksQ0FBQ0UsSUFBSSxDQUFDLENBQUMsS0FBSyxFQUFFLEdBQUc7SUFBRUYsSUFBSSxFQUFFQSxJQUFJLENBQUNFLElBQUksQ0FBQztFQUFFLENBQUMsR0FBRyxDQUFDLENBQUM7RUFDNUY7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNcUQsV0FBVyxHQUFHLE9BQU9MLElBQUksS0FBSyxRQUFRLElBQUlBLElBQUksS0FBSyxFQUFFO0VBQzNELE1BQU1NLFVBQVUsR0FBRyxPQUFPVixHQUFHLEtBQUssUUFBUSxJQUFJQSxHQUFHLEtBQUssRUFBRTtFQUN4RCxJQUFJUyxXQUFXLElBQUlDLFVBQVUsRUFBRSxPQUFPLElBQUksQ0FBQyxDQUFDO0VBQzVDLElBQUlBLFVBQVUsRUFBRTtJQUNkLElBQUtiLFNBQVMsQ0FBeUJDLEtBQUssS0FBS0MsU0FBUyxFQUFFLE9BQU8sSUFBSSxDQUFDLENBQUM7SUFDekU7SUFDQSxJQUFLQyxHQUFHLENBQVk5QixRQUFRLENBQUMsR0FBRyxDQUFDLElBQUs4QixHQUFHLENBQVk5QixRQUFRLENBQUMsR0FBRyxDQUFDLEVBQUUsT0FBTyxJQUFJO0lBQy9FLElBQUksRUFBRSxPQUFPaEIsSUFBSSxLQUFLLFFBQVEsSUFBSUEsSUFBSSxLQUFLLEVBQUUsQ0FBQyxFQUFFLE9BQU8sSUFBSSxDQUFDLENBQUM7SUFDN0Q7SUFDQTtJQUNBO0lBQ0EsT0FBTztNQUFFa0QsSUFBSSxFQUFFdkQsaUJBQWlCO01BQUV3RCxPQUFPLEVBQUUsS0FBSztNQUFFLEdBQUdHO0lBQVMsQ0FBQztFQUNqRTtFQUNBLE1BQU1HLE9BQU8sR0FBRyxPQUFPUCxJQUFJLEtBQUssUUFBUSxJQUFJQSxJQUFJLENBQUNoRCxJQUFJLENBQUMsQ0FBQyxLQUFLLEVBQUU7RUFDOUQsSUFBSSxDQUFDdUQsT0FBTyxFQUFFLE9BQU8sSUFBSTtFQUN6QjtFQUNBO0VBQ0EsSUFBS1AsSUFBSSxDQUFZaEQsSUFBSSxDQUFDLENBQUMsS0FBS1AsaUJBQWlCLEVBQUUsT0FBTyxJQUFJO0VBQzlELE1BQU13RCxPQUFPLEdBQUlSLFNBQVMsQ0FBMkJRLE9BQU87RUFDNUQsT0FBTztJQUNMRCxJQUFJLEVBQUdBLElBQUksQ0FBWWhELElBQUksQ0FBQyxDQUFDO0lBQzdCO0lBQ0E7SUFDQTtJQUNBaUQsT0FBTyxFQUFFLE9BQU9BLE9BQU8sS0FBSyxRQUFRLElBQUlBLE9BQU8sQ0FBQ2pELElBQUksQ0FBQyxDQUFDLEtBQUssRUFBRSxHQUFHaUQsT0FBTyxDQUFDakQsSUFBSSxDQUFDLENBQUMsR0FBRyxLQUFLO0lBQ3RGLEdBQUdvRDtFQUNMLENBQUM7QUFDSDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVNJLGNBQWNBLENBQzVCbEMsSUFBK0IsRUFDL0JDLE1BQXVCLEVBQ0E7RUFDdkIsTUFBTWtDLE1BQU0sR0FBRzlCLGNBQWMsQ0FBQ0wsSUFBSSxDQUFDO0VBQ25DLElBQUksQ0FBQ21DLE1BQU0sRUFBRSxPQUFPLElBQUk7RUFDeEIsSUFBSSxDQUFDbEMsTUFBTSxDQUFDQyxTQUFTLENBQUNWLFFBQVEsQ0FBQzJDLE1BQU0sQ0FBQ1QsSUFBSSxDQUFDLEVBQUUsT0FBTyxJQUFJO0VBQ3hELElBQUl6QixNQUFNLENBQUNFLFdBQVcsRUFBRUMsR0FBRyxDQUFDK0IsTUFBTSxDQUFDVCxJQUFJLENBQUMsRUFBRSxPQUFPLElBQUk7RUFDckQsT0FBTztJQUFFQSxJQUFJLEVBQUVTLE1BQU0sQ0FBQ1QsSUFBSTtJQUFFQyxPQUFPLEVBQUVRLE1BQU0sQ0FBQ1IsT0FBTztJQUFFQyxLQUFLLEVBQUVyRCxhQUFhLENBQUM0RCxNQUFNLENBQUMzRCxJQUFJO0VBQUUsQ0FBQztBQUMxRjs7QUFFQTtBQUNBOztBQU1BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxTQUFTNEQsaUJBQWlCQSxDQUMvQkMsS0FBNEIsRUFDNUJwQyxNQUEwQixFQUNIO0VBQ3ZCLElBQUksQ0FBQ29DLEtBQUssRUFBRSxPQUFPLElBQUk7RUFDdkIsSUFBSSxDQUFDcEMsTUFBTSxDQUFDcUMsVUFBVSxDQUFDOUMsUUFBUSxDQUFDNkMsS0FBSyxDQUFDWCxJQUFJLENBQUMsRUFBRSxPQUFPLElBQUk7RUFDeEQsT0FBTztJQUFFQSxJQUFJLEVBQUVXLEtBQUssQ0FBQ1gsSUFBSTtJQUFFQyxPQUFPLEVBQUVVLEtBQUssQ0FBQ1YsT0FBTztJQUFFQyxLQUFLLEVBQUU7RUFBZ0IsQ0FBQztBQUM3RTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVNXLGNBQWNBLENBQUNDLElBQXdCLEVBQVc7RUFDaEUsT0FBT0EsSUFBSSxLQUFLLGNBQWMsSUFBSUEsSUFBSSxLQUFLLGNBQWMsSUFBSUEsSUFBSSxLQUFLLHVCQUF1QjtBQUMvRiIsImlnbm9yZUxpc3QiOltdfQ==