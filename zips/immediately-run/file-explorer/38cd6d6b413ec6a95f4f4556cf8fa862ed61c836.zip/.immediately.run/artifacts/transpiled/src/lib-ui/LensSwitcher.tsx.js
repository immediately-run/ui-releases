var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _lucideReact = require("lucide-react");
var _useRadiogroupNav = require("./hooks/useRadiogroupNav");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The "App | Session" lens switcher (R3-95; PRINCIPALS_SPEC §9 B2). A compact
// segmented control in the panel header that swaps the explorer between the App
// lens (this app's spaces, `useMounts()`) and the Session lens (the session's
// spaces beyond the app's own, `useSessionMounts()` — first-party only). Rendered
// ONLY when the host delivers a session signal, so a URL-loaded fork never shows it.
// Same ARIA radiogroup + `.viewswitch` styling as LayoutSwitcher (announces as one
// control with two mutually-exclusive options), and the same APG Radio Group
// keyboard contract via `useRadiogroupNav`.
const OPTIONS = [{
  value: "app",
  label: "App",
  tip: "This app's spaces",
  Icon: _lucideReact.AppWindow
}, {
  value: "session",
  label: "Session",
  tip: "The session's spaces",
  Icon: _lucideReact.Users
}];
function LensSwitcher({
  value,
  onChange
}) {
  _s();
  const {
    ref,
    onKeyDown
  } = (0, _useRadiogroupNav.useRadiogroupNav)(OPTIONS.map(o => o.value), value, onChange);
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    ref: ref,
    className: "viewswitch",
    role: "radiogroup",
    "aria-label": "Spaces lens",
    onKeyDown: onKeyDown,
    children: OPTIONS.map(({
      value: v,
      label,
      tip,
      Icon
    }) => {
      const active = v === value;
      return /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
        type: "button",
        role: "radio",
        "aria-checked": active,
        tabIndex: active ? 0 : -1,
        className: "viewswitch__btn" + (active ? " viewswitch__btn--active" : ""),
        title: tip,
        "aria-label": tip,
        onClick: () => onChange(v),
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(Icon, {
          size: 15,
          "aria-hidden": "true"
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "viewswitch__label",
          children: label
        })]
      }, v);
    })
  });
}
_s(LensSwitcher, "j+gNN3KwaQoaiWtxQ+lkKdwZEBg=", false, function () {
  return [_useRadiogroupNav.useRadiogroupNav];
});
_c = LensSwitcher;
var _default = exports.default = LensSwitcher;
var _c;
$RefreshReg$(_c, "LensSwitcher");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfbHVjaWRlUmVhY3QiLCJyZXF1aXJlIiwiX3VzZVJhZGlvZ3JvdXBOYXYiLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiT1BUSU9OUyIsInZhbHVlIiwibGFiZWwiLCJ0aXAiLCJJY29uIiwiQXBwV2luZG93IiwiVXNlcnMiLCJMZW5zU3dpdGNoZXIiLCJvbkNoYW5nZSIsInJlZiIsIm9uS2V5RG93biIsInVzZVJhZGlvZ3JvdXBOYXYiLCJtYXAiLCJvIiwianN4IiwiY2xhc3NOYW1lIiwicm9sZSIsImNoaWxkcmVuIiwidiIsImFjdGl2ZSIsImpzeHMiLCJ0eXBlIiwidGFiSW5kZXgiLCJ0aXRsZSIsIm9uQ2xpY2siLCJzaXplIiwiX2MiLCJfZGVmYXVsdCIsImV4cG9ydHMiLCJkZWZhdWx0IiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiTGVuc1N3aXRjaGVyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBUaGUgXCJBcHAgfCBTZXNzaW9uXCIgbGVucyBzd2l0Y2hlciAoUjMtOTU7IFBSSU5DSVBBTFNfU1BFQyDCpzkgQjIpLiBBIGNvbXBhY3Rcbi8vIHNlZ21lbnRlZCBjb250cm9sIGluIHRoZSBwYW5lbCBoZWFkZXIgdGhhdCBzd2FwcyB0aGUgZXhwbG9yZXIgYmV0d2VlbiB0aGUgQXBwXG4vLyBsZW5zICh0aGlzIGFwcCdzIHNwYWNlcywgYHVzZU1vdW50cygpYCkgYW5kIHRoZSBTZXNzaW9uIGxlbnMgKHRoZSBzZXNzaW9uJ3Ncbi8vIHNwYWNlcyBiZXlvbmQgdGhlIGFwcCdzIG93biwgYHVzZVNlc3Npb25Nb3VudHMoKWAg4oCUIGZpcnN0LXBhcnR5IG9ubHkpLiBSZW5kZXJlZFxuLy8gT05MWSB3aGVuIHRoZSBob3N0IGRlbGl2ZXJzIGEgc2Vzc2lvbiBzaWduYWwsIHNvIGEgVVJMLWxvYWRlZCBmb3JrIG5ldmVyIHNob3dzIGl0LlxuLy8gU2FtZSBBUklBIHJhZGlvZ3JvdXAgKyBgLnZpZXdzd2l0Y2hgIHN0eWxpbmcgYXMgTGF5b3V0U3dpdGNoZXIgKGFubm91bmNlcyBhcyBvbmVcbi8vIGNvbnRyb2wgd2l0aCB0d28gbXV0dWFsbHktZXhjbHVzaXZlIG9wdGlvbnMpLCBhbmQgdGhlIHNhbWUgQVBHIFJhZGlvIEdyb3VwXG4vLyBrZXlib2FyZCBjb250cmFjdCB2aWEgYHVzZVJhZGlvZ3JvdXBOYXZgLlxuaW1wb3J0IHsgQXBwV2luZG93LCBVc2VycywgdHlwZSBMdWNpZGVJY29uIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuaW1wb3J0IHsgdXNlUmFkaW9ncm91cE5hdiB9IGZyb20gXCIuL2hvb2tzL3VzZVJhZGlvZ3JvdXBOYXZcIjtcblxuZXhwb3J0IHR5cGUgTGVucyA9IFwiYXBwXCIgfCBcInNlc3Npb25cIjtcblxuY29uc3QgT1BUSU9OUzogeyB2YWx1ZTogTGVuczsgbGFiZWw6IHN0cmluZzsgdGlwOiBzdHJpbmc7IEljb246IEx1Y2lkZUljb24gfVtdID0gW1xuICB7IHZhbHVlOiBcImFwcFwiLCBsYWJlbDogXCJBcHBcIiwgdGlwOiBcIlRoaXMgYXBwJ3Mgc3BhY2VzXCIsIEljb246IEFwcFdpbmRvdyB9LFxuICB7IHZhbHVlOiBcInNlc3Npb25cIiwgbGFiZWw6IFwiU2Vzc2lvblwiLCB0aXA6IFwiVGhlIHNlc3Npb24ncyBzcGFjZXNcIiwgSWNvbjogVXNlcnMgfSxcbl07XG5cbmZ1bmN0aW9uIExlbnNTd2l0Y2hlcih7XG4gIHZhbHVlLFxuICBvbkNoYW5nZSxcbn06IHtcbiAgdmFsdWU6IExlbnM7XG4gIG9uQ2hhbmdlOiAobmV4dDogTGVucykgPT4gdm9pZDtcbn0pIHtcbiAgY29uc3QgeyByZWYsIG9uS2V5RG93biB9ID0gdXNlUmFkaW9ncm91cE5hdihcbiAgICBPUFRJT05TLm1hcCgobykgPT4gby52YWx1ZSksXG4gICAgdmFsdWUsXG4gICAgb25DaGFuZ2UsXG4gICk7XG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgcmVmPXtyZWZ9XG4gICAgICBjbGFzc05hbWU9XCJ2aWV3c3dpdGNoXCJcbiAgICAgIHJvbGU9XCJyYWRpb2dyb3VwXCJcbiAgICAgIGFyaWEtbGFiZWw9XCJTcGFjZXMgbGVuc1wiXG4gICAgICBvbktleURvd249e29uS2V5RG93bn1cbiAgICA+XG4gICAgICB7T1BUSU9OUy5tYXAoKHsgdmFsdWU6IHYsIGxhYmVsLCB0aXAsIEljb24gfSkgPT4ge1xuICAgICAgICBjb25zdCBhY3RpdmUgPSB2ID09PSB2YWx1ZTtcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBrZXk9e3Z9XG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgIHJvbGU9XCJyYWRpb1wiXG4gICAgICAgICAgICBhcmlhLWNoZWNrZWQ9e2FjdGl2ZX1cbiAgICAgICAgICAgIHRhYkluZGV4PXthY3RpdmUgPyAwIDogLTF9XG4gICAgICAgICAgICBjbGFzc05hbWU9e1widmlld3N3aXRjaF9fYnRuXCIgKyAoYWN0aXZlID8gXCIgdmlld3N3aXRjaF9fYnRuLS1hY3RpdmVcIiA6IFwiXCIpfVxuICAgICAgICAgICAgdGl0bGU9e3RpcH1cbiAgICAgICAgICAgIGFyaWEtbGFiZWw9e3RpcH1cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uQ2hhbmdlKHYpfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxJY29uIHNpemU9ezE1fSBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidmlld3N3aXRjaF9fbGFiZWxcIj57bGFiZWx9PC9zcGFuPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICApO1xuICAgICAgfSl9XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IExlbnNTd2l0Y2hlcjtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBUUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsaUJBQUEsR0FBQUQsT0FBQTtBQUE0RCxJQUFBRSxXQUFBLEdBQUFGLE9BQUE7QUFBQSxJQUFBRyxFQUFBLEdBQUFDLFlBQUEsSUFUNUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQU1BLE1BQU1DLE9BQXdFLEdBQUcsQ0FDL0U7RUFBRUMsS0FBSyxFQUFFLEtBQUs7RUFBRUMsS0FBSyxFQUFFLEtBQUs7RUFBRUMsR0FBRyxFQUFFLG1CQUFtQjtFQUFFQyxJQUFJLEVBQUVDO0FBQVUsQ0FBQyxFQUN6RTtFQUFFSixLQUFLLEVBQUUsU0FBUztFQUFFQyxLQUFLLEVBQUUsU0FBUztFQUFFQyxHQUFHLEVBQUUsc0JBQXNCO0VBQUVDLElBQUksRUFBRUU7QUFBTSxDQUFDLENBQ2pGO0FBRUQsU0FBU0MsWUFBWUEsQ0FBQztFQUNwQk4sS0FBSztFQUNMTztBQUlGLENBQUMsRUFBRTtFQUFBVixFQUFBO0VBQ0QsTUFBTTtJQUFFVyxHQUFHO0lBQUVDO0VBQVUsQ0FBQyxHQUFHLElBQUFDLGtDQUFnQixFQUN6Q1gsT0FBTyxDQUFDWSxHQUFHLENBQUVDLENBQUMsSUFBS0EsQ0FBQyxDQUFDWixLQUFLLENBQUMsRUFDM0JBLEtBQUssRUFDTE8sUUFDRixDQUFDO0VBQ0Qsb0JBQ0UsSUFBQVgsV0FBQSxDQUFBaUIsR0FBQTtJQUNFTCxHQUFHLEVBQUVBLEdBQUk7SUFDVE0sU0FBUyxFQUFDLFlBQVk7SUFDdEJDLElBQUksRUFBQyxZQUFZO0lBQ2pCLGNBQVcsYUFBYTtJQUN4Qk4sU0FBUyxFQUFFQSxTQUFVO0lBQUFPLFFBQUEsRUFFcEJqQixPQUFPLENBQUNZLEdBQUcsQ0FBQyxDQUFDO01BQUVYLEtBQUssRUFBRWlCLENBQUM7TUFBRWhCLEtBQUs7TUFBRUMsR0FBRztNQUFFQztJQUFLLENBQUMsS0FBSztNQUMvQyxNQUFNZSxNQUFNLEdBQUdELENBQUMsS0FBS2pCLEtBQUs7TUFDMUIsb0JBQ0UsSUFBQUosV0FBQSxDQUFBdUIsSUFBQTtRQUVFQyxJQUFJLEVBQUMsUUFBUTtRQUNiTCxJQUFJLEVBQUMsT0FBTztRQUNaLGdCQUFjRyxNQUFPO1FBQ3JCRyxRQUFRLEVBQUVILE1BQU0sR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFFO1FBQzFCSixTQUFTLEVBQUUsaUJBQWlCLElBQUlJLE1BQU0sR0FBRywwQkFBMEIsR0FBRyxFQUFFLENBQUU7UUFDMUVJLEtBQUssRUFBRXBCLEdBQUk7UUFDWCxjQUFZQSxHQUFJO1FBQ2hCcUIsT0FBTyxFQUFFQSxDQUFBLEtBQU1oQixRQUFRLENBQUNVLENBQUMsQ0FBRTtRQUFBRCxRQUFBLGdCQUUzQixJQUFBcEIsV0FBQSxDQUFBaUIsR0FBQSxFQUFDVixJQUFJO1VBQUNxQixJQUFJLEVBQUUsRUFBRztVQUFDLGVBQVk7UUFBTSxDQUFFLENBQUMsZUFDckMsSUFBQTVCLFdBQUEsQ0FBQWlCLEdBQUE7VUFBTUMsU0FBUyxFQUFDLG1CQUFtQjtVQUFBRSxRQUFBLEVBQUVmO1FBQUssQ0FBTyxDQUFDO01BQUEsR0FYN0NnQixDQVlDLENBQUM7SUFFYixDQUFDO0VBQUMsQ0FDQyxDQUFDO0FBRVY7QUFBQ3BCLEVBQUEsQ0F6Q1FTLFlBQVk7RUFBQSxRQU9RSSxrQ0FBZ0I7QUFBQTtBQUFBZSxFQUFBLEdBUHBDbkIsWUFBWTtBQUFBLElBQUFvQixRQUFBLEdBQUFDLE9BQUEsQ0FBQUMsT0FBQSxHQTJDTnRCLFlBQVk7QUFBQSxJQUFBbUIsRUFBQTtBQUFBSSxZQUFBLENBQUFKLEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}