var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.find.js");
require("core-js/modules/esnext.iterator.map.js");
require("core-js/modules/esnext.iterator.some.js");
var _react = require("react");
var _lucideReact = require("lucide-react");
var _treeStore = require("./treeStore");
var _ContextMenu = _interopRequireDefault(require("./ContextMenu"));
var _LayoutSwitcher = _interopRequireDefault(require("./LayoutSwitcher"));
var _ListView = _interopRequireDefault(require("./ListView"));
var _IconGrid = _interopRequireDefault(require("./IconGrid"));
var _ColumnView = _interopRequireDefault(require("./ColumnView"));
var _MoveDialog = _interopRequireDefault(require("./MoveDialog"));
var _useLongPress = require("./hooks/useLongPress");
var _useLayout = require("./hooks/useLayout");
var _rovingTreeFocus = require("./hooks/rovingTreeFocus");
var _useRowInteractions = require("./hooks/useRowInteractions");
var _writeFlow = require("./writeFlow");
var _announce = require("./announce");
var _explorer = require("./explorer");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(),
  _s2 = $RefreshSig$(),
  _s3 = $RefreshSig$(); // The headless file-explorer view (00-overview §3.2; Phase 02 §A). This is the
// former `FileExplorer.tsx` orchestrator with EVERY host/SDK call severed into an
// injected prop: it reads roots through `roots: ExplorerRoot[]`, bytes/entries
// through `fs: FsSource`, the active file through `activePath`, and emits intents
// through `actions`/`onActivate`/`onSelect`. It imports NO SDK — the SDK adapter
// (`sdk/SdkFileExplorer.tsx`) wires all of that up and re-creates the shipped app.
// A non-SDK consumer (file-commander) supplies its own fs/roots and simply omits
// the actions it doesn't implement (the affordance then hides).
//
// Writes render their own result (R-IX-3/R-IX-4): the write flow in writeFlow.ts
// inserts the pending row, settles it from the action's return, and refetches
// only the changed directory. The tree follows the APG Tree View pattern (one
// roving tab stop per tree; the focusable row IS the treeitem), and pending and
// settled states announce through ONE live region beside the view (R-IX-7).
/** Optional extension slots + chrome supplied by a consumer. */
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
const TreeNode = /*#__PURE__*/_s(/*#__PURE__*/(0, _react.memo)(_c = _s(function TreeNode({
  path,
  name,
  isDir,
  depth,
  rootPath,
  mountId,
  writable,
  store,
  handlers,
  renderRowAccessory
}) {
  _s();
  const {
    expanded,
    selected,
    errored,
    entries
  } = (0, _treeStore.useNode)(store, path);
  const open = isDir && expanded;
  const loading = isDir && open && entries === undefined && !errored;
  // A write in flight: the row the user just asked for, rendered pending at
  // its final position until the write's own return settles it (R-IX-3/4).
  const pending = (0, _treeStore.usePending)(store, path);
  const [dropTarget, setDropTarget] = (0, _react.useState)(false);
  // Roving tabIndex (APG Tree View): exactly one row per tree is the tab stop —
  // the focused row, or the tree's root while no row of this tree holds focus.
  const rowFocused = (0, _treeStore.useRowFocused)(store, path);
  const treeUnfocused = (0, _treeStore.useTreeUnfocused)(store, rootPath);
  const tabStop = rowFocused || treeUnfocused && depth === 0;
  const groupId = (0, _react.useId)();
  (0, _react.useEffect)(() => {
    if (isDir && open && entries === undefined && !errored) store.ensureLoaded(path);
  }, [isDir, open, entries, errored, path, store]);
  const repoRel = (0, _explorer.toMountRel)(rootPath, path);
  // Active highlight via a per-node store subscription (NOT a threaded prop), so
  // an active-path change re-renders only the affected rows (FX-4b).
  const activeMatch = (0, _treeStore.useActive)(store, repoRel);
  const active = !isDir && activeMatch;
  // The collapsed-ancestor dot for the EDITOR's file, mirroring the on-stage one
  // below: a closed folder holding the edited file keeps saying so, so collapsing
  // `src/` doesn't make the answer to "what am I editing?" disappear entirely.
  const activeAncestorMatch = (0, _treeStore.useActiveAncestor)(store, repoRel);
  const containsActive = isDir && !open && activeAncestorMatch;
  // The "on stage" marker (R3-268) — same per-node subscription shape as active.
  const viewedMatch = (0, _treeStore.useViewed)(store, repoRel);
  const viewed = !isDir && viewedMatch;
  // The collapsed-ancestor dot: a closed folder whose subtree contains the
  // on-stage file shows a dimmed marker, so the viewed highlight is discoverable
  // without the tree ever moving on its own (the highlight-only contract).
  const ancestorMatch = (0, _treeStore.useViewedAncestor)(store, repoRel);
  const containsViewed = isDir && !open && ancestorMatch;
  const rowCtx = {
    absPath: path,
    isDir,
    rootPath,
    mountId,
    writable
  };
  const longPress = (0, _useLongPress.useLongPress)((x, y) => handlers.onMenu({
    clientX: x,
    clientY: y
  }, rowCtx));
  const onKeyDown = e => {
    if ((0, _useRowInteractions.openRowMenuKey)(e, handlers, rowCtx)) return;
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      handlers.onActivate(path, isDir);
    } else if (e.key === "ArrowRight" && isDir) {
      // APG Tree View: expand a closed folder; in an open one, move to the
      // first child (its rows may still be loading — the move then no-ops).
      if (!open) {
        store.toggle(path);
      } else {
        (0, _rovingTreeFocus.firstTreeChildFocus)(e.currentTarget);
      }
    } else if (e.key === "ArrowLeft") {
      // Collapse an open folder; otherwise step out to the parent row.
      if (isDir && open) {
        store.toggle(path);
      } else {
        const group = e.currentTarget.closest('ul[role="group"]');
        group?.previousElementSibling?.focus();
      }
    }
  };

  // Drag-out (R3-83) + internal move (R3-81) both start here. We set the private
  // move payload (used only for an in-explorer drop — it names whether the
  // dragged thing is a folder, so the drop side can restore the right row) AND
  // ask the host to begin a cross-app drag-out; whichever drop fires wins (the
  // other is cancelled).
  const onDragStart = e => {
    e.dataTransfer.setData(_explorer.MOVE_MIME, JSON.stringify({
      from: path,
      rootPath,
      isDir
    }));
    e.dataTransfer.effectAllowed = "copyMove";
    handlers.beginDragOut(path, isDir, mountId, rootPath);
  };
  const onDragEnd = () => handlers.cancelDragOut();

  // A directory row is a drop target for internal moves and OS-file uploads.
  const onDragOver = e => {
    if (!isDir) return;
    const isMove = e.dataTransfer.types.includes(_explorer.MOVE_MIME);
    const isUpload = e.dataTransfer.types.includes("Files");
    if (!isMove && !isUpload) return;
    if (isUpload && !writable) return;
    e.preventDefault();
    e.stopPropagation();
    e.dataTransfer.dropEffect = isMove ? "move" : "copy";
    setDropTarget(true);
  };
  const onDragLeave = () => setDropTarget(false);
  const onDrop = e => {
    if (!isDir) return;
    const move = e.dataTransfer.getData(_explorer.MOVE_MIME);
    const files = Array.from(e.dataTransfer.files);
    if (!move && !files.length) return;
    e.preventDefault();
    e.stopPropagation();
    setDropTarget(false);
    handlers.cancelDragOut(); // the drop landed inside the explorer → not a drag-out
    if (move) {
      const {
        from,
        rootPath: fromRoot,
        isDir: fromIsDir
      } = JSON.parse(move);
      handlers.onMoveDrop(from, fromRoot, fromIsDir, path, rootPath);
    } else if (files.length) {
      handlers.onUploadDrop(files, path, writable);
    }
  };
  const Icon = isDir ? open ? _lucideReact.FolderOpen : _lucideReact.Folder : _lucideReact.File;
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("li", {
    role: "none",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      role: "treeitem",
      "aria-owns": isDir && open ? groupId : undefined,
      "aria-expanded": isDir ? open : undefined,
      "aria-selected": selected,
      "aria-busy": pending ? true : undefined,
      "aria-label": name,
      className: "tnode" + (selected ? " tnode--selected" : "") + (active ? " tnode--active" : "") + (viewed ? " tnode--viewed" : "") + (dropTarget ? " tnode--droptarget" : "") + (pending ? " tnode--pending" : ""),
      style: {
        paddingLeft: 8 + depth * 14
      },
      tabIndex: tabStop ? 0 : -1,
      draggable: true,
      onFocus: () => store.setFocus(path),
      onClick: () => handlers.onActivate(path, isDir),
      onKeyDown: onKeyDown,
      onContextMenu: e => {
        e.preventDefault();
        handlers.onMenu(e, rowCtx);
      },
      onDragStart: onDragStart,
      onDragEnd: onDragEnd,
      onDragOver: onDragOver,
      onDragLeave: onDragLeave,
      onDrop: onDrop,
      onPointerDown: longPress.onPointerDown,
      onPointerMove: longPress.onPointerMove,
      onPointerUp: longPress.onPointerUp,
      onPointerCancel: longPress.onPointerCancel,
      "data-dir": isDir ? "1" : "0",
      "data-path": path,
      "aria-current": active ? "true" : undefined,
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "tnode__icon",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(Icon, {
          size: 15,
          "aria-hidden": "true"
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "tnode__name",
        children: name
      }), active && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "tnode__active",
        role: "img",
        "aria-label": "Open in the editor",
        title: "Open in the editor",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.Pencil, {
          size: 11,
          "aria-hidden": "true"
        })
      }), containsActive && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "tnode__active tnode__active--ancestor",
        role: "img",
        "aria-label": "Contains the file open in the editor",
        title: "Contains the file open in the editor",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.Pencil, {
          size: 11,
          "aria-hidden": "true"
        })
      }), viewed && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "tnode__viewed",
        role: "img",
        "aria-label": "Shown in the running app",
        title: "Shown in the running app",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.Play, {
          size: 11,
          "aria-hidden": "true"
        })
      }), containsViewed && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "tnode__viewed tnode__viewed--ancestor",
        role: "img",
        "aria-label": "Contains the file shown in the running app",
        title: "Contains the file shown in the running app",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.Play, {
          size: 11,
          "aria-hidden": "true"
        })
      }), (loading || pending) && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "tnode__spin",
        "aria-hidden": "true",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.Loader2, {
          size: 13
        })
      }), renderRowAccessory?.(rowCtx)]
    }), isDir && open && /*#__PURE__*/(0, _jsxRuntime.jsxs)("ul", {
      role: "group",
      id: groupId,
      className: "tree__group",
      children: [errored && /*#__PURE__*/(0, _jsxRuntime.jsx)("li", {
        className: "tnode tnode--muted",
        style: {
          paddingLeft: 8 + (depth + 1) * 14
        },
        children: "Couldn\u2019t read this folder."
      }), entries?.length === 0 && /*#__PURE__*/(0, _jsxRuntime.jsx)("li", {
        className: "tnode tnode--muted",
        style: {
          paddingLeft: 8 + (depth + 1) * 14
        },
        children: "Empty"
      }), entries?.map(entry => /*#__PURE__*/(0, _jsxRuntime.jsx)(TreeNode, {
        path: (0, _explorer.joinPath)(path, entry.name),
        name: entry.name,
        isDir: entry.isDir,
        depth: depth + 1,
        rootPath: rootPath,
        mountId: mountId,
        writable: writable,
        store: store,
        handlers: handlers,
        renderRowAccessory: renderRowAccessory
      }, entry.name))]
    })]
  });
}, "t+k4B44ulaYPwa8tg+w6oGot4QE=", false, function () {
  return [_treeStore.useNode, _treeStore.usePending, _treeStore.useRowFocused, _treeStore.useTreeUnfocused, _treeStore.useActive, _treeStore.useActiveAncestor, _treeStore.useViewed, _treeStore.useViewedAncestor, _useLongPress.useLongPress];
})), "t+k4B44ulaYPwa8tg+w6oGot4QE=", false, function () {
  return [useNode, usePending, useRowFocused, useTreeUnfocused, useActive, useActiveAncestor, useViewed, useViewedAncestor, useLongPress];
});

/** Provider/type icon for the App-scope header (R3-94 / PRINCIPALS §9 B1). */
_c2 = TreeNode;
const MOUNT_ICON = {
  worktree: _lucideReact.FolderGit2,
  settings: _lucideReact.Settings,
  space: _lucideReact.Users,
  other: _lucideReact.Folder
};

/** A single browsable root: scope header (type icon + name + per-subtree mode
 *  chips + optional eject) + its tree. */
const Scope = /*#__PURE__*/_s2(/*#__PURE__*/(0, _react.memo)(_c3 = _s2(function Scope({
  root,
  store,
  handlers,
  onEject,
  renderRowAccessory
}) {
  _s2();
  const writable = (0, _explorer.isWritableMount)(root);
  const mountId = root.id;
  // Eject (detach) — spaces / granted subtrees only, never the worktree or a
  // settings store (SPACES_UI_SPEC §3, R-SPACES-3). Closes the space for this
  // session; membership/grant are untouched and it re-adds via the powerbox.
  const canEject = (0, _explorer.isEjectable)(root) && !!onEject;
  const [ejecting, setEjecting] = (0, _react.useState)(false);
  const doEject = (0, _react.useCallback)(async () => {
    if (!onEject || ejecting) return;
    setEjecting(true);
    try {
      await onEject(root);
    } catch {
      setEjecting(false);
    }
  }, [onEject, ejecting, root]);
  const label = (0, _explorer.mountLabel)(root);
  const scopes = (0, _explorer.mountScopes)(root);
  const TypeIcon = MOUNT_ICON[(0, _explorer.mountKind)(root)];

  // The scope is the drop target for every OS-file drop a directory row does not
  // take (§5: "or the scope root if dropped on empty space within a scope") — the
  // blank space below the tree, the scope header, and file rows, which resolve to
  // their parent directory. A directory row stops propagation, so it is never this
  // handler's business and the two affordances never light at once. Internal moves
  // (MOVE_MIME) are deliberately NOT accepted here: a move needs a real directory,
  // and `moveRejection` is the rows' to apply.
  const [dragging, setDragging] = (0, _react.useState)(false);
  const acceptsUpload = e => writable && e.dataTransfer.types.includes("Files");
  const onScopeDragOver = e => {
    if (!acceptsUpload(e)) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = "copy";
    setDragging(true);
  };
  const onScopeDragLeave = e => {
    // `dragleave` fires when crossing between children too; only a pointer that has
    // actually left the scope clears the affordance.
    if (!e.currentTarget.contains(e.relatedTarget)) setDragging(false);
  };
  const onScopeDrop = e => {
    if (!acceptsUpload(e)) return;
    const files = Array.from(e.dataTransfer.files);
    if (!files.length) return;
    e.preventDefault();
    setDragging(false);
    handlers.onUploadDrop(files, (0, _explorer.uploadRowFromEvent)(e, root.path), writable);
  };
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "mount",
    "data-drag": dragging ? "1" : undefined,
    onDragOver: onScopeDragOver,
    onDragLeave: onScopeDragLeave,
    onDropCapture: () => setDragging(false),
    onDrop: onScopeDrop,
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "scope",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "scope__head",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(TypeIcon, {
          className: "scope__icon",
          size: 13,
          "aria-hidden": "true"
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "scope__name",
          children: label
        })]
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "scope__chips",
        children: scopes.map(s => {
          const sro = s.mode === "ro";
          return /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
            className: "scope__chip",
            children: [sro && /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.Lock, {
              size: 11,
              "aria-hidden": "true"
            }), s.subtree, " \xB7 ", sro ? "read-only" : "read-write"]
          }, s.subtree);
        })
      }), canEject && /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        type: "button",
        className: "scope__eject",
        onClick: doEject,
        disabled: ejecting,
        "aria-label": `Eject ${label}`,
        title: `Eject ${label} (closes it here; your access is unchanged)`,
        children: ejecting ? /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.Loader2, {
          size: 13,
          className: "tnode__spin",
          "aria-hidden": "true"
        }) : /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.CircleArrowUp, {
          size: 13,
          "aria-hidden": "true"
        })
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("ul", {
      role: "tree",
      "aria-label": label,
      className: "tree",
      onKeyDown: e => {
        if ((0, _rovingTreeFocus.rovingTreeFocus)(e.currentTarget, e.key)) e.preventDefault();
      },
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(TreeNode, {
        path: root.path,
        name: label,
        isDir: true,
        depth: 0,
        rootPath: root.path,
        mountId: mountId,
        writable: writable,
        store: store,
        handlers: handlers,
        renderRowAccessory: renderRowAccessory
      }, root.path)
    })]
  });
}, "ZhLJ9cdQPFVY/GAOx72r1gqkkgQ=")), "ZhLJ9cdQPFVY/GAOx72r1gqkkgQ=");
_c4 = Scope;
function FileExplorerView({
  roots,
  fs,
  actions,
  activePath = null,
  viewedPath = null,
  reveal = null,
  selectionMode = "single",
  onSelect,
  onSelectionChange,
  onActivate,
  onNavigate,
  cwd: cwdProp,
  layout: layoutProp,
  onLayoutChange,
  storageKey,
  extraMenuItems,
  renderRowAccessory,
  header,
  emptyState
}) {
  _s3();
  const [error, setError] = (0, _react.useState)(null);
  const [menu, setMenu] = (0, _react.useState)(null);
  // "Move to…" picker target (the non-drag move path, WCAG 2.5.7).
  const [moveTarget, setMoveTarget] = (0, _react.useState)(null);
  // The ONE live region (R-IX-7): pending and settled states are announced
  // here, never scattered per component. The region's message comes from the
  // announcement channel (announce.ts), so the view's own writes AND sibling
  // overlays (the summarize modal) reach the same single region.
  const [statusMsg, setStatusMsg] = (0, _react.useState)("");
  (0, _react.useEffect)(() => (0, _announce.subscribeToAnnouncements)(setStatusMsg), []);
  // Inline prompt for create / rename: a single targeted input.
  const [prompt, setPrompt] = (0, _react.useState)(null);
  const [promptValue, setPromptValue] = (0, _react.useState)("");
  // The row that opened the menu the prompt came from — read synchronously in
  // `openMenu` (a synthetic event's `currentTarget` dies with its handler) and
  // consumed by the prompt's Escape-cancel to hand focus back (R-IX-1's return).
  const promptReturnRef = (0, _react.useRef)(null);
  // Set while an Escape-cancel is closing the prompt, so the input's blur (fired
  // synchronously by the focus hand-back) cannot run `submitPrompt` and turn the
  // cancel into a commit.
  const promptCancellingRef = (0, _react.useRef)(false);
  // The prompt takes focus in a mount EFFECT, not `autoFocus`: the prompt
  // usually opens as the context menu closes, and the menu's focus-return
  // (its unmount cleanup) would otherwise land after `autoFocus` and steal
  // focus straight back — blurring the input into a phantom blur-commit.
  // Effect setup runs after every cleanup in the same commit, so the input
  // reliably ends up focused.
  const promptInputRef = (0, _react.useRef)(null);
  (0, _react.useEffect)(() => {
    if (prompt) promptInputRef.current?.focus();
  }, [prompt]);
  const uploadInputRef = (0, _react.useRef)(null);
  const uploadTargetRef = (0, _react.useRef)(null);

  // The store reads through the injected fs. `fs` is stable per consumer, so the
  // store is constructed once (a changing `fs` would warrant a fresh store).
  const [store] = (0, _react.useState)(() => new _treeStore.TreeStore(fs));
  const [layoutState, setLayoutState] = (0, _useLayout.useLayout)(storageKey);
  const layout = layoutProp ?? layoutState;
  const setLayout = (0, _react.useCallback)(next => {
    if (onLayoutChange) onLayoutChange(next);
    if (layoutProp === undefined) setLayoutState(next);
  }, [onLayoutChange, layoutProp, setLayoutState]);
  const [cwd, setCwd] = (0, _react.useState)(null);
  const [colPath, setColPath] = (0, _react.useState)([]);
  const ordered = (0, _react.useMemo)(() => (0, _explorer.orderMounts)(roots), [roots]);
  const rootByPath = (0, _react.useCallback)(p => ordered.find(m => p === m.path || p.startsWith(m.path + "/")) ?? null, [ordered]);
  // The upload button's destination (FILE_EXPLORER_SPEC §5): the selected row's
  // directory — a selected directory itself, a selected file's PARENT (the
  // upload becomes its sibling) — or the repo root when nothing is selected.
  // The destination resolves under the SELECTION'S OWN root when that root is
  // writable (so "a directory → that directory" holds in any writable scope,
  // not just the first); a selection inside a read-only scope cannot receive
  // an upload, and the destination then falls back to the repo root —
  // `ordered` ranks the worktree first, so the first writable root IS the
  // repo root. Never shown-then-`EROFS`, per §2.
  const uploadRoot = (0, _react.useMemo)(() => ordered.find(m => (0, _explorer.isWritableMount)(m)) ?? null, [ordered]);
  const selectedRow = (0, _treeStore.useSelectedRow)(store);
  const selectedRowRoot = selectedRow ? rootByPath(selectedRow.path) : null;
  const usableSelectedRow = selectedRow && selectedRowRoot?.writable ? selectedRow : null;
  // The root the destination is resolved against: the selection's own writable
  // root, else the repo-root fallback. `uploadTargetDir` answers an absolute
  // path, so it MUST be relativized against the same root that owns it — a
  // blind slice against `uploadRoot` would corrupt a selection living under a
  // different (writable) mount.
  const destRoot = usableSelectedRow && selectedRowRoot ? selectedRowRoot : uploadRoot;
  const uploadDirRel = destRoot ? (0, _explorer.toMountRel)(destRoot.path, (0, _explorer.uploadTargetDir)(usableSelectedRow, destRoot.path)) : null;
  const uploadDestLabel = !destRoot || uploadDirRel === null ? "" : uploadDirRel === "/" ? destRoot === uploadRoot ? "the repo root" : `the ${(0, _explorer.mountLabel)(destRoot)} root` : uploadDirRel;
  /** §5 upload button: open the browser's native file picker on the shared
   *  hidden input (the same one the §3 "Upload here…" item uses). */
  const openUploadPicker = () => {
    if (!actions?.upload || !destRoot || uploadDirRel === null) return;
    uploadTargetRef.current = {
      dir: uploadDirRel,
      rootPath: destRoot.path
    };
    uploadInputRef.current?.click();
  };
  // Idempotent + emit-free: safe during render so new scopes paint open.
  store.ensureRoots(ordered.map(m => m.path));

  // Mirror the controlled active path into the store (FX-4b). Held in the store —
  // not threaded as a prop through the memoized tree — so a change re-renders only
  // the two rows whose active state flips, never the whole tree.
  (0, _react.useEffect)(() => {
    store.setActiveFile(activePath);
  }, [store, activePath]);
  // Mirror the stage's viewed-document hint the same way (R3-268).
  (0, _react.useEffect)(() => {
    store.setViewedFile(viewedPath);
  }, [store, viewedPath]);

  // Gesture-gated reveal: one-shot per nonce. Expand the ancestors, then scroll
  // the row into view once it renders (children load lazily on expand, so poll
  // briefly and give up quietly). scrollIntoView only — focus NEVER moves.
  //
  // `rootKey` (declared here so BOTH reveal effects share it) is in the deps for
  // the same reason FX-4b documents below: the reveal routinely lands before the
  // mounts do (R3-440 — now guaranteed by the host holding the one-shot until the
  // app's `reportReady`, which fires at the mount effect, before any roots reach
  // the store), and a `revealPath` against an empty root set is silently inert.
  // The expansion is idempotent, so a roots-arrived re-run is a retry, not a
  // re-fire; the nonce guard keeps the SCROLL one-shot per gesture.
  const rootKey = (0, _react.useMemo)(() => ordered.map(m => m.path).join("\u0000"), [ordered]);
  const panelElRef = (0, _react.useRef)(null);
  // One SCROLL per gesture (the nonce), but the poll re-arms on a roots change
  // until the row exists: a reveal that landed during boot expands via the
  // idempotent retry and still scrolls once the tree can show it. A path that
  // is never in the tree gives up per round and stays put.
  const scrolledRevealNonceRef = (0, _react.useRef)(null);
  (0, _react.useEffect)(() => {
    if (!reveal) return;
    store.revealPath(reveal.path);
    if (scrolledRevealNonceRef.current === reveal.nonce) return;
    let tries = 0;
    const timer = setInterval(() => {
      const el = panelElRef.current?.querySelector(".tnode--viewed");
      if (el) {
        el.scrollIntoView({
          block: "nearest"
        });
        scrolledRevealNonceRef.current = reveal.nonce;
        clearInterval(timer);
      } else if (++tries > 16) {
        clearInterval(timer); // no rows this round — a roots change re-arms
      }
    }, 150);
    return () => clearInterval(timer);
  }, [reveal, store, rootKey]);

  // Reveal the EDITOR's active file (FX-4b). Distinct from the stage hint above in
  // both trust and intent: `activeFile` rides the elevated `editor-context` push
  // from the host, and it changes only through a GATED host intent — `editor:open`
  // (the cross-app "open this file" the explorer itself uses) or `editor:document`
  // `setActive` (the editor's own session) — so following it is not the untrusted,
  // activation-free highlight the R3-268 contract governs.
  //
  // This used to say `activeFile` "only ever changes because a user opened that
  // file". That was already strained — `setActive` is programmatic — and R3-388
  // falsified it outright by adding a second `editor:open` holder whose calls fire on
  // a run completing and on Enter in a list, not only on a click. The invariant that
  // actually holds is the one above: not "a human clicked", but "a frame the host
  // gated did this", of which there are now several. Following it is safe because the
  // GATE is the check, not because a human was assumed. Without this
  // the very first thing an edit-mode session shows is an entrypoint deep under a
  // COLLAPSED folder, with nothing in the tree saying which file that is.
  // Expand-only (a folder the user closed is never re-opened) + `scrollIntoView`;
  // focus never moves. Children load lazily on expand, so poll briefly for the row
  // and give up quietly when the path isn't in this tree.
  // `rootKey` is in the deps because the two inputs RACE: the editor's active file
  // routinely lands before the mounts do, and `revealPath` can only expand under
  // roots the store already knows — a reveal against an empty root set is silently
  // inert, and `activePath` alone would never fire again to retry it.
  // (Declared above, shared with the gesture-reveal effect.)
  (0, _react.useEffect)(() => {
    if (!activePath) return;
    store.revealPath(activePath);
    let tries = 0;
    const timer = setInterval(() => {
      const el = panelElRef.current?.querySelector(".tnode--active");
      if (el) {
        el.scrollIntoView({
          block: "nearest"
        });
        clearInterval(timer);
      } else if (++tries > 16) {
        clearInterval(timer); // rows never appeared (path not in this tree) — stay put
      }
    }, 150);
    return () => clearInterval(timer);
  }, [activePath, rootKey, store]);

  // The multi-select SET, subscribed via the store's STABLE snapshot (identity
  // changes only on a real mutation — see `getSelection`), so this doesn't tear.
  // On each change, report the mount-relative paths of the set to a batch consumer
  // via `onSelectionChange`, resolving the owning root (single-panel consumers keep
  // the set within one root). Runs only under `selectionMode === "multi"`.
  const selectionSet = (0, _react.useSyncExternalStore)(store.subscribe, store.getSelection);
  const prevSelectionRef = (0, _react.useRef)(selectionSet);
  (0, _react.useEffect)(() => {
    // Skip the mount-time run (no change yet) so we don't emit a spurious empty set.
    const changed = prevSelectionRef.current !== selectionSet;
    prevSelectionRef.current = selectionSet;
    if (!changed) return;
    if (selectionMode !== "multi" || !onSelectionChange) return;
    const root = selectionSet.length ? rootByPath(selectionSet[0]) : null;
    const owner = root ?? ordered[0] ?? null;
    if (!owner) return;
    onSelectionChange(owner, selectionSet.map(abs => (0, _explorer.toMountRel)(owner.path, abs)));
  }, [selectionSet, selectionMode, onSelectionChange, rootByPath, ordered]);

  // Keep the flat-layout cursors valid as roots come and go — derive, don't store.
  // When `cwd` is controlled (prop `!== undefined`) it WINS over internal state; a
  // navigation only fires `onNavigate` (below) and the consumer feeds the new cwd
  // back. When uncontrolled, the internal state drives it (today's behavior). Either
  // way the value is validated against the live roots so a stale path can't linger.
  const controlledCwd = cwdProp !== undefined;
  const sourceCwd = controlledCwd ? cwdProp : cwd;
  const effCwd = sourceCwd && ordered.some(m => sourceCwd === m.path || sourceCwd.startsWith(m.path + "/")) ? sourceCwd : null;
  const effColPath = colPath.length && ordered.some(m => m.path === colPath[0]) ? colPath : [];

  // Navigate the flat (list/icons) layout's browsed directory, and report it to a
  // consumer via `onNavigate` (the extension point file-commander uses to track a
  // panel's current directory — the copy/move destination). A `null` cwd is the
  // synthetic roots-root (no single directory) and is not reported. Entering a
  // directory also SELECTS it (FILE_EXPLORER_SPEC §5): in a flat layout the
  // browsed folder is the upload button's destination. Gated on
  // `selectionMode !== "none"` exactly like the tree's activation path, so a
  // consumer that disabled selection never gets selection writes from
  // navigation (its upload destination stays the repo root).
  const navigateCwd = (0, _react.useCallback)(path => {
    // Controlled: don't touch internal state — just report; the consumer updates
    // its own `cwd` and passes it back. Uncontrolled: set internal + report (today).
    if (!controlledCwd) setCwd(path);
    if (path) {
      if (selectionMode !== "none") store.select(path, true);
      const root = rootByPath(path);
      if (root) onNavigate?.(root, (0, _explorer.toMountRel)(root.path, path));
    }
  }, [store, rootByPath, onNavigate, controlledCwd, selectionMode]);
  // The Miller-columns analog: the focused column is the deepest path segment.
  // Like `navigateCwd`, the deepest column is selected — it is the layout's
  // "current directory" and the upload button's destination — under the same
  // `selectionMode` gate.
  const navigateCols = (0, _react.useCallback)(path => {
    setColPath(path);
    const last = path[path.length - 1];
    if (last) {
      if (selectionMode !== "none") store.select(last, true);
      const root = rootByPath(last);
      if (root) onNavigate?.(root, (0, _explorer.toMountRel)(root.path, last));
    }
  }, [store, rootByPath, onNavigate, selectionMode]);

  // Switching layout seeds the new view from the current selection so the selected
  // file stays in view (acceptance: selection survives a switch).
  const chooseLayout = (0, _react.useCallback)(next => {
    if (next !== layout) {
      const sel = store.getSelected();
      if (next === "list" || next === "icons") {
        setCwd(sel ? (0, _explorer.dirOf)(sel) : ordered.length === 1 ? ordered[0].path : null);
      } else if (next === "columns") {
        const mount = sel ? ordered.find(m => sel === m.path || sel.startsWith(m.path + "/")) : ordered.length === 1 ? ordered[0] : undefined;
        if (!mount) setColPath([]);else {
          const path = [mount.path];
          const segs = (0, _explorer.toMountRel)(mount.path, sel ? (0, _explorer.dirOf)(sel) : mount.path).split("/").filter(Boolean);
          let acc = mount.path;
          for (const s of segs) {
            acc = (0, _explorer.joinPath)(acc, s);
            path.push(acc);
          }
          setColPath(path);
        }
      }
    }
    setLayout(next);
  }, [layout, ordered, store, setLayout]);

  // The optimistic write flow (R-IX-3/R-IX-4): every write renders its own
  // result — pending row first, the action's return settles it, one narrow
  // refetch for authority — and announces both halves (R-IX-7).
  const writePorts = (0, _react.useMemo)(() => ({
    store,
    actions: actions ?? {},
    announce: _announce.announce,
    fail: message => setError(message),
    begin: () => setError(null)
  }), [store, actions]);

  // --- stable node handlers (so the memoized tree doesn't re-render) ---
  // Open is dispatched where the owning root is known (onActivate / the menu); it
  // calls onActivate then actions.open with the mount-relative path.
  const dispatchOpen = (0, _react.useCallback)((root, mountRel) => {
    setError(null);
    onActivate?.(root, mountRel, false);
    if (!actions?.open) return;
    try {
      actions.open(root, mountRel);
    } catch {
      setError("Couldn’t open that file.");
    }
  }, [actions, onActivate]);
  const handleActivate = (0, _react.useCallback)((absPath, isDir) => {
    const root = rootByPath(absPath);
    if (isDir) {
      store.toggle(absPath);
      // A clicked folder is also SELECTED (not just expanded): the selected
      // directory is the upload button's destination (FILE_EXPLORER_SPEC §5).
      if (selectionMode !== "none") store.select(absPath, true);
      if (root) onActivate?.(root, (0, _explorer.toMountRel)(root.path, absPath), true);
    } else {
      if (selectionMode !== "none") store.select(absPath, false);
      if (!root) return; // a row always belongs to a rendered root
      const rel = (0, _explorer.toMountRel)(root.path, absPath);
      onSelect?.(root, rel);
      dispatchOpen(root, rel);
    }
  }, [store, rootByPath, onActivate, onSelect, dispatchOpen, selectionMode]);
  const onMoveDrop = (0, _react.useCallback)((fromAbs, fromRoot, fromIsDir, targetDir, targetRoot) => {
    if (!actions?.rename) return;
    const reason = (0, _explorer.moveRejection)(fromAbs, targetDir, fromRoot, targetRoot);
    if (reason) {
      if (reason === "cross-mount") setError(_explorer.WRITE_ERR["cross-mount"]);
      return; // same-dir / into-self: silent no-op
    }
    const root = rootByPath(targetDir);
    if (!root) return;
    const to = (0, _explorer.toMountRel)(targetRoot, (0, _explorer.joinPath)(targetDir, (0, _explorer.basename)(fromAbs)));
    // The moved row's own entry, from the store that rendered it (falling
    // back to the drag payload's facts only if the listing already went).
    const entry = store.getEntries((0, _explorer.dirOf)(fromAbs))?.find(en => en.name === (0, _explorer.basename)(fromAbs)) ?? {
      name: (0, _explorer.basename)(fromAbs),
      isDir: fromIsDir
    };
    (0, _writeFlow.runRename)(writePorts, root, fromAbs, entry, to);
  }, [actions, writePorts, rootByPath, store]);
  const onUploadDrop = (0, _react.useCallback)((files, targetDirAbs, writable) => {
    if (!actions?.upload || !writable || !files.length) return;
    const root = rootByPath(targetDirAbs);
    if (!root) return;
    (0, _writeFlow.runUpload)(writePorts, root, targetDirAbs, (0, _explorer.toMountRel)(root.path, targetDirAbs), files);
  }, [actions, writePorts, rootByPath]);
  const beginDragOut = (0, _react.useCallback)((absPath, isDir) => {
    if (!actions?.beginDragOut) return;
    const root = rootByPath(absPath);
    if (!root) return;
    actions.beginDragOut(root, (0, _explorer.toMountRel)(root.path, absPath), isDir);
  }, [actions, rootByPath]);
  const cancelDragOut = (0, _react.useCallback)(() => {
    actions?.cancelDragOut?.();
  }, [actions]);
  const onDelete = (0, _react.useCallback)((absPath, isDir, rootPath) => {
    if (!actions?.delete) return;
    const root = rootByPath(absPath);
    if (!root) return;
    const mountRel = (0, _explorer.toMountRel)(rootPath, absPath);
    if (!window.confirm(`Delete ${isDir ? "folder" : "file"} ${mountRel}?`)) return;
    const entry = store.getEntries((0, _explorer.dirOf)(absPath))?.find(en => en.name === (0, _explorer.basename)(absPath)) ?? {
      name: (0, _explorer.basename)(absPath),
      isDir
    };
    (0, _writeFlow.runDelete)(writePorts, root, (0, _explorer.dirOf)(absPath), entry, mountRel);
  }, [actions, writePorts, rootByPath, store]);

  // --- context menu construction (gated items only) ---
  const openMenu = (0, _react.useCallback)((e, ctx) => {
    // Remember the row that opened this menu — the prompt's Escape-cancel
    // returns focus here. Touch long-press has no row element (nothing is
    // focused), so it clears to null rather than keeping a stale row.
    promptReturnRef.current = e.currentTarget instanceof HTMLElement ? e.currentTarget : null;
    const items = [];
    const root = rootByPath(ctx.absPath);
    const mountRel = (0, _explorer.toMountRel)(ctx.rootPath, ctx.absPath);
    if (!ctx.isDir && actions?.open && root) {
      items.push({
        key: "open",
        label: "Open",
        icon: /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.ExternalLink, {
          size: 14
        }),
        onSelect: () => dispatchOpen(root, mountRel)
      });
    }
    if (ctx.writable) {
      const baseDir = ctx.isDir ? ctx.absPath : (0, _explorer.dirOf)(ctx.absPath);
      if (actions?.createFile) {
        items.push({
          key: "new-file",
          label: "New file here",
          icon: /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.FilePlus, {
            size: 14
          }),
          onSelect: () => {
            setPrompt({
              mode: "create-file",
              baseDir,
              rootPath: ctx.rootPath
            });
            setPromptValue("");
          }
        });
      }
      if (actions?.createFolder) {
        items.push({
          key: "new-folder",
          label: "New folder here",
          icon: /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.FolderPlus, {
            size: 14
          }),
          onSelect: () => {
            setPrompt({
              mode: "create-folder",
              baseDir,
              rootPath: ctx.rootPath
            });
            setPromptValue("");
          }
        });
      }
      if (actions?.upload) {
        items.push({
          key: "upload",
          label: "Upload here…",
          icon: /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.Upload, {
            size: 14
          }),
          onSelect: () => {
            uploadTargetRef.current = {
              dir: (0, _explorer.toMountRel)(ctx.rootPath, baseDir),
              rootPath: ctx.rootPath
            };
            uploadInputRef.current?.click();
          }
        });
      }
      if (!(0, _explorer.isProtected)(mountRel) && ctx.absPath !== ctx.rootPath) {
        if (actions?.rename) {
          // The non-drag move path (WCAG 2.5.7): a directory picker that
          // commits through the SAME move the drag-drop takes.
          items.push({
            key: "move-to",
            label: "Move to…",
            icon: /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.FolderInput, {
              size: 14
            }),
            onSelect: () => setMoveTarget({
              absPath: ctx.absPath,
              rootPath: ctx.rootPath,
              name: (0, _explorer.basename)(ctx.absPath),
              isDir: ctx.isDir
            })
          });
          items.push({
            key: "rename",
            label: "Rename…",
            icon: /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.Pencil, {
              size: 14
            }),
            onSelect: () => {
              setPrompt({
                mode: "rename",
                targetAbs: ctx.absPath,
                rootPath: ctx.rootPath,
                initial: (0, _explorer.basename)(ctx.absPath),
                isDir: ctx.isDir
              });
              setPromptValue((0, _explorer.basename)(ctx.absPath));
            }
          });
        }
        if (actions?.delete) {
          items.push({
            key: "delete",
            label: "Delete",
            icon: /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.Trash2, {
              size: 14
            }),
            danger: true,
            onSelect: () => onDelete(ctx.absPath, ctx.isDir, ctx.rootPath)
          });
        }
      }
    }
    // Consumer extension slot (e.g. the SDK adapter's "Summarize…").
    if (extraMenuItems) items.push(...extraMenuItems(ctx));
    if (!items.length) return;
    setMenu({
      x: e.clientX,
      y: e.clientY,
      items,
      invoker: promptReturnRef.current
    });
  }, [actions, rootByPath, dispatchOpen, onDelete, extraMenuItems]);
  const handlers = (0, _react.useMemo)(() => ({
    onActivate: handleActivate,
    onMenu: openMenu,
    onMoveDrop,
    onUploadDrop,
    beginDragOut: (absPath, isDir) => beginDragOut(absPath, isDir),
    cancelDragOut,
    onDelete: actions?.delete ? onDelete : undefined
  }), [handleActivate, openMenu, onMoveDrop, onUploadDrop, beginDragOut, cancelDragOut, onDelete, actions]);
  const submitPrompt = () => {
    if (promptCancellingRef.current) return; // an Escape-cancel closed it, not a blur commit
    const p = prompt;
    setPrompt(null);
    if (!p) return;
    const value = promptValue.trim().replace(/^\/+/, "");
    setPromptValue("");
    if (!value) return;
    const root = rootByPath(p.rootPath === "" ? "" : p.rootPath) ?? ordered.find(m => m.path === p.rootPath) ?? null;
    if (!root) return;
    if (p.mode === "rename") {
      if (!actions?.rename) return;
      const fromRel = (0, _explorer.toMountRel)(p.rootPath, p.targetAbs);
      const toRel = (0, _explorer.joinPath)((0, _explorer.dirOf)(fromRel), (0, _explorer.basename)(value));
      (0, _writeFlow.runRename)(writePorts, root, p.targetAbs, {
        name: p.initial,
        isDir: p.isDir
      }, toRel);
    } else {
      const rel = (0, _explorer.joinPath)((0, _explorer.toMountRel)(p.rootPath, p.baseDir), value);
      if (p.mode === "create-file") {
        if (!actions?.createFile) return;
        (0, _writeFlow.runCreate)(writePorts, "file", root, p.baseDir, rel);
      } else {
        if (!actions?.createFolder) return;
        (0, _writeFlow.runCreate)(writePorts, "folder", root, p.baseDir, rel);
      }
    }
  };
  const onUploadInput = e => {
    const files = Array.from(e.target.files ?? []);
    const target = uploadTargetRef.current;
    e.target.value = "";
    if (!files.length || !target || !actions?.upload) return;
    // The owning root was captured at menu time (target.rootPath).
    const root = rootByPath(target.rootPath);
    if (!root) return;
    (0, _writeFlow.runUpload)(writePorts, root, (0, _explorer.joinRel)(root.path, target.dir), target.dir, files);
  };
  const hasRoots = ordered.length > 0;
  const title = header?.title ?? "Files";
  const glyph = header?.glyph ?? /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.FolderTree, {
    size: 15,
    "aria-hidden": "true"
  });
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("section", {
    className: "panel fx-root",
    "aria-label": title,
    ref: panelElRef,
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("header", {
      className: "panel__head",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "panel__glyph",
        children: glyph
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "panel__title",
        children: title
      }), (hasRoots || header?.actions) &&
      /*#__PURE__*/
      // `--extra` marks a header carrying consumer-supplied controls on top of
      // the view's own. The stylesheet uses it to keep the view switcher compact
      // until the panel is genuinely wide (R3-239): the switcher's text labels
      // are the header's largest single consumer, and a container query cannot
      // see how many siblings it is competing with.
      (0, _jsxRuntime.jsxs)("div", {
        className: "panel__actions" + (header?.actions ? " panel__actions--extra" : ""),
        children: [hasRoots && /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
          children: [actions?.upload && uploadRoot && /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
            type: "button",
            className: "panel__action",
            title: `Upload files to ${uploadDestLabel}`,
            "aria-label": `Upload files to ${uploadDestLabel}`,
            onClick: openUploadPicker,
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.Upload, {
              size: 15,
              "aria-hidden": "true"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_LayoutSwitcher.default, {
            value: layout,
            onChange: chooseLayout
          }), layout === "tree" && /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
            type: "button",
            className: "panel__action",
            title: "Collapse all folders",
            "aria-label": "Collapse all folders",
            onClick: () => store.collapseAll(),
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.ChevronsDownUp, {
              size: 15,
              "aria-hidden": "true"
            })
          })]
        }), header?.actions]
      })]
    }), header?.tray && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "panel__tray",
      children: header.tray
    }), error && /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "panel__error",
      role: "alert",
      children: [error, /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        type: "button",
        className: "panel__error-dismiss",
        onClick: () => setError(null),
        children: "Dismiss"
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "fx-status",
      role: "status",
      children: statusMsg
    }), prompt && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "panel__create",
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)("input", {
        ref: promptInputRef,
        className: "panel__create-input",
        spellCheck: false,
        "aria-label": prompt.mode === "rename" ? `Rename ${prompt.initial}` : `New ${prompt.mode === "create-folder" ? "folder" : "file"} in ${(0, _explorer.toMountRel)(prompt.rootPath, prompt.baseDir)}`,
        placeholder: prompt.mode === "rename" ? "new name" : prompt.mode === "create-folder" ? "folder/path" : "path/name.ext",
        value: promptValue,
        onChange: e => setPromptValue(e.target.value),
        onKeyDown: e => {
          if (e.key === "Enter") submitPrompt();else if (e.key === "Escape") {
            // Cancel: close the prompt and return focus to the row that
            // opened it. The flag keeps the blur the focus hand-back fires
            // from re-entering `submitPrompt` (blur still commits — that
            // is deliberate, and Enter/Escape are the explicit paths).
            promptCancellingRef.current = true;
            setPrompt(null);
            setPromptValue("");
            promptReturnRef.current?.focus();
            promptCancellingRef.current = false;
          }
        },
        onBlur: submitPrompt
      })
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("input", {
      ref: uploadInputRef,
      type: "file",
      multiple: true,
      hidden: true,
      onChange: onUploadInput,
      "aria-hidden": "true",
      tabIndex: -1
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "panel__body",
      children: !hasRoots ? emptyState ?? /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "state",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "state__icon",
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.FolderTree, {
            size: 20,
            "aria-hidden": "true"
          })
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("h4", {
          children: "No files to show yet."
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
          children: "Open a project or add a space and its files appear here."
        })]
      }) : layout === "list" ? /*#__PURE__*/(0, _jsxRuntime.jsx)(_ListView.default, {
        store: store,
        ordered: ordered,
        cwd: effCwd,
        setCwd: navigateCwd,
        activeFile: activePath,
        selectionMode: selectionMode,
        handlers: handlers
      }) : layout === "icons" ? /*#__PURE__*/(0, _jsxRuntime.jsx)(_IconGrid.default, {
        store: store,
        ordered: ordered,
        cwd: effCwd,
        setCwd: navigateCwd,
        activeFile: activePath,
        viewedFile: viewedPath,
        handlers: handlers
      }) : layout === "columns" ? /*#__PURE__*/(0, _jsxRuntime.jsx)(_ColumnView.default, {
        store: store,
        ordered: ordered,
        colPath: effColPath,
        setColPath: navigateCols,
        activeFile: activePath,
        viewedFile: viewedPath,
        handlers: handlers
      }) : ordered.map(m => /*#__PURE__*/(0, _jsxRuntime.jsx)(Scope, {
        root: m,
        store: store,
        handlers: handlers,
        onEject: actions?.eject,
        renderRowAccessory: renderRowAccessory
      }, m.path))
    }), menu && /*#__PURE__*/(0, _jsxRuntime.jsx)(_ContextMenu.default, {
      anchor: menu,
      onClose: () => setMenu(null)
    }), moveTarget && /*#__PURE__*/(0, _jsxRuntime.jsx)(_MoveDialog.default, {
      target: moveTarget,
      roots: ordered,
      store: store,
      onMove: (dirAbs, dirRootPath) => {
        onMoveDrop(moveTarget.absPath, moveTarget.rootPath, moveTarget.isDir, dirAbs, dirRootPath);
        setMoveTarget(null);
      },
      onClose: () => setMoveTarget(null)
    })]
  });
}
_s3(FileExplorerView, "r9ZnzbqRVgZK6/IN/cWnMVp0wcM=", false, function () {
  return [_useLayout.useLayout, _treeStore.useSelectedRow];
});
_c5 = FileExplorerView;
var _default = exports.default = FileExplorerView;
var _c, _c2, _c3, _c4, _c5;
$RefreshReg$(_c, "TreeNode$memo");
$RefreshReg$(_c2, "TreeNode");
$RefreshReg$(_c3, "Scope$memo");
$RefreshReg$(_c4, "Scope");
$RefreshReg$(_c5, "FileExplorerView");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX2x1Y2lkZVJlYWN0IiwiX3RyZWVTdG9yZSIsIl9Db250ZXh0TWVudSIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJfTGF5b3V0U3dpdGNoZXIiLCJfTGlzdFZpZXciLCJfSWNvbkdyaWQiLCJfQ29sdW1uVmlldyIsIl9Nb3ZlRGlhbG9nIiwiX3VzZUxvbmdQcmVzcyIsIl91c2VMYXlvdXQiLCJfcm92aW5nVHJlZUZvY3VzIiwiX3VzZVJvd0ludGVyYWN0aW9ucyIsIl93cml0ZUZsb3ciLCJfYW5ub3VuY2UiLCJfZXhwbG9yZXIiLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiX3MyIiwiX3MzIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiVHJlZU5vZGUiLCJtZW1vIiwiX2MiLCJwYXRoIiwibmFtZSIsImlzRGlyIiwiZGVwdGgiLCJyb290UGF0aCIsIm1vdW50SWQiLCJ3cml0YWJsZSIsInN0b3JlIiwiaGFuZGxlcnMiLCJyZW5kZXJSb3dBY2Nlc3NvcnkiLCJleHBhbmRlZCIsInNlbGVjdGVkIiwiZXJyb3JlZCIsImVudHJpZXMiLCJ1c2VOb2RlIiwib3BlbiIsImxvYWRpbmciLCJ1bmRlZmluZWQiLCJwZW5kaW5nIiwidXNlUGVuZGluZyIsImRyb3BUYXJnZXQiLCJzZXREcm9wVGFyZ2V0IiwidXNlU3RhdGUiLCJyb3dGb2N1c2VkIiwidXNlUm93Rm9jdXNlZCIsInRyZWVVbmZvY3VzZWQiLCJ1c2VUcmVlVW5mb2N1c2VkIiwidGFiU3RvcCIsImdyb3VwSWQiLCJ1c2VJZCIsInVzZUVmZmVjdCIsImVuc3VyZUxvYWRlZCIsInJlcG9SZWwiLCJ0b01vdW50UmVsIiwiYWN0aXZlTWF0Y2giLCJ1c2VBY3RpdmUiLCJhY3RpdmUiLCJhY3RpdmVBbmNlc3Rvck1hdGNoIiwidXNlQWN0aXZlQW5jZXN0b3IiLCJjb250YWluc0FjdGl2ZSIsInZpZXdlZE1hdGNoIiwidXNlVmlld2VkIiwidmlld2VkIiwiYW5jZXN0b3JNYXRjaCIsInVzZVZpZXdlZEFuY2VzdG9yIiwiY29udGFpbnNWaWV3ZWQiLCJyb3dDdHgiLCJhYnNQYXRoIiwibG9uZ1ByZXNzIiwidXNlTG9uZ1ByZXNzIiwieCIsInkiLCJvbk1lbnUiLCJjbGllbnRYIiwiY2xpZW50WSIsIm9uS2V5RG93biIsIm9wZW5Sb3dNZW51S2V5Iiwia2V5IiwicHJldmVudERlZmF1bHQiLCJvbkFjdGl2YXRlIiwidG9nZ2xlIiwiZmlyc3RUcmVlQ2hpbGRGb2N1cyIsImN1cnJlbnRUYXJnZXQiLCJncm91cCIsImNsb3Nlc3QiLCJwcmV2aW91c0VsZW1lbnRTaWJsaW5nIiwiZm9jdXMiLCJvbkRyYWdTdGFydCIsImRhdGFUcmFuc2ZlciIsInNldERhdGEiLCJNT1ZFX01JTUUiLCJKU09OIiwic3RyaW5naWZ5IiwiZnJvbSIsImVmZmVjdEFsbG93ZWQiLCJiZWdpbkRyYWdPdXQiLCJvbkRyYWdFbmQiLCJjYW5jZWxEcmFnT3V0Iiwib25EcmFnT3ZlciIsImlzTW92ZSIsInR5cGVzIiwiaW5jbHVkZXMiLCJpc1VwbG9hZCIsInN0b3BQcm9wYWdhdGlvbiIsImRyb3BFZmZlY3QiLCJvbkRyYWdMZWF2ZSIsIm9uRHJvcCIsIm1vdmUiLCJnZXREYXRhIiwiZmlsZXMiLCJBcnJheSIsImxlbmd0aCIsImZyb21Sb290IiwiZnJvbUlzRGlyIiwicGFyc2UiLCJvbk1vdmVEcm9wIiwib25VcGxvYWREcm9wIiwiSWNvbiIsIkZvbGRlck9wZW4iLCJGb2xkZXIiLCJGaWxlSWNvbiIsImpzeHMiLCJyb2xlIiwiY2hpbGRyZW4iLCJjbGFzc05hbWUiLCJzdHlsZSIsInBhZGRpbmdMZWZ0IiwidGFiSW5kZXgiLCJkcmFnZ2FibGUiLCJvbkZvY3VzIiwic2V0Rm9jdXMiLCJvbkNsaWNrIiwib25Db250ZXh0TWVudSIsIm9uUG9pbnRlckRvd24iLCJvblBvaW50ZXJNb3ZlIiwib25Qb2ludGVyVXAiLCJvblBvaW50ZXJDYW5jZWwiLCJqc3giLCJzaXplIiwidGl0bGUiLCJQZW5jaWwiLCJQbGF5IiwiTG9hZGVyMiIsImlkIiwibWFwIiwiZW50cnkiLCJqb2luUGF0aCIsIl9jMiIsIk1PVU5UX0lDT04iLCJ3b3JrdHJlZSIsIkZvbGRlckdpdDIiLCJzZXR0aW5ncyIsIlNldHRpbmdzSWNvbiIsInNwYWNlIiwiVXNlcnMiLCJvdGhlciIsIlNjb3BlIiwiX2MzIiwicm9vdCIsIm9uRWplY3QiLCJpc1dyaXRhYmxlTW91bnQiLCJjYW5FamVjdCIsImlzRWplY3RhYmxlIiwiZWplY3RpbmciLCJzZXRFamVjdGluZyIsImRvRWplY3QiLCJ1c2VDYWxsYmFjayIsImxhYmVsIiwibW91bnRMYWJlbCIsInNjb3BlcyIsIm1vdW50U2NvcGVzIiwiVHlwZUljb24iLCJtb3VudEtpbmQiLCJkcmFnZ2luZyIsInNldERyYWdnaW5nIiwiYWNjZXB0c1VwbG9hZCIsIm9uU2NvcGVEcmFnT3ZlciIsIm9uU2NvcGVEcmFnTGVhdmUiLCJjb250YWlucyIsInJlbGF0ZWRUYXJnZXQiLCJvblNjb3BlRHJvcCIsInVwbG9hZFJvd0Zyb21FdmVudCIsIm9uRHJvcENhcHR1cmUiLCJzIiwic3JvIiwibW9kZSIsIkxvY2siLCJzdWJ0cmVlIiwidHlwZSIsImRpc2FibGVkIiwiQ2lyY2xlQXJyb3dVcCIsInJvdmluZ1RyZWVGb2N1cyIsIl9jNCIsIkZpbGVFeHBsb3JlclZpZXciLCJyb290cyIsImZzIiwiYWN0aW9ucyIsImFjdGl2ZVBhdGgiLCJ2aWV3ZWRQYXRoIiwicmV2ZWFsIiwic2VsZWN0aW9uTW9kZSIsIm9uU2VsZWN0Iiwib25TZWxlY3Rpb25DaGFuZ2UiLCJvbk5hdmlnYXRlIiwiY3dkIiwiY3dkUHJvcCIsImxheW91dCIsImxheW91dFByb3AiLCJvbkxheW91dENoYW5nZSIsInN0b3JhZ2VLZXkiLCJleHRyYU1lbnVJdGVtcyIsImhlYWRlciIsImVtcHR5U3RhdGUiLCJlcnJvciIsInNldEVycm9yIiwibWVudSIsInNldE1lbnUiLCJtb3ZlVGFyZ2V0Iiwic2V0TW92ZVRhcmdldCIsInN0YXR1c01zZyIsInNldFN0YXR1c01zZyIsInN1YnNjcmliZVRvQW5ub3VuY2VtZW50cyIsInByb21wdCIsInNldFByb21wdCIsInByb21wdFZhbHVlIiwic2V0UHJvbXB0VmFsdWUiLCJwcm9tcHRSZXR1cm5SZWYiLCJ1c2VSZWYiLCJwcm9tcHRDYW5jZWxsaW5nUmVmIiwicHJvbXB0SW5wdXRSZWYiLCJjdXJyZW50IiwidXBsb2FkSW5wdXRSZWYiLCJ1cGxvYWRUYXJnZXRSZWYiLCJUcmVlU3RvcmUiLCJsYXlvdXRTdGF0ZSIsInNldExheW91dFN0YXRlIiwidXNlTGF5b3V0Iiwic2V0TGF5b3V0IiwibmV4dCIsInNldEN3ZCIsImNvbFBhdGgiLCJzZXRDb2xQYXRoIiwib3JkZXJlZCIsInVzZU1lbW8iLCJvcmRlck1vdW50cyIsInJvb3RCeVBhdGgiLCJwIiwiZmluZCIsIm0iLCJzdGFydHNXaXRoIiwidXBsb2FkUm9vdCIsInNlbGVjdGVkUm93IiwidXNlU2VsZWN0ZWRSb3ciLCJzZWxlY3RlZFJvd1Jvb3QiLCJ1c2FibGVTZWxlY3RlZFJvdyIsImRlc3RSb290IiwidXBsb2FkRGlyUmVsIiwidXBsb2FkVGFyZ2V0RGlyIiwidXBsb2FkRGVzdExhYmVsIiwib3BlblVwbG9hZFBpY2tlciIsInVwbG9hZCIsImRpciIsImNsaWNrIiwiZW5zdXJlUm9vdHMiLCJzZXRBY3RpdmVGaWxlIiwic2V0Vmlld2VkRmlsZSIsInJvb3RLZXkiLCJqb2luIiwicGFuZWxFbFJlZiIsInNjcm9sbGVkUmV2ZWFsTm9uY2VSZWYiLCJyZXZlYWxQYXRoIiwibm9uY2UiLCJ0cmllcyIsInRpbWVyIiwic2V0SW50ZXJ2YWwiLCJlbCIsInF1ZXJ5U2VsZWN0b3IiLCJzY3JvbGxJbnRvVmlldyIsImJsb2NrIiwiY2xlYXJJbnRlcnZhbCIsInNlbGVjdGlvblNldCIsInVzZVN5bmNFeHRlcm5hbFN0b3JlIiwic3Vic2NyaWJlIiwiZ2V0U2VsZWN0aW9uIiwicHJldlNlbGVjdGlvblJlZiIsImNoYW5nZWQiLCJvd25lciIsImFicyIsImNvbnRyb2xsZWRDd2QiLCJzb3VyY2VDd2QiLCJlZmZDd2QiLCJzb21lIiwiZWZmQ29sUGF0aCIsIm5hdmlnYXRlQ3dkIiwic2VsZWN0IiwibmF2aWdhdGVDb2xzIiwibGFzdCIsImNob29zZUxheW91dCIsInNlbCIsImdldFNlbGVjdGVkIiwiZGlyT2YiLCJtb3VudCIsInNlZ3MiLCJzcGxpdCIsImZpbHRlciIsIkJvb2xlYW4iLCJhY2MiLCJwdXNoIiwid3JpdGVQb3J0cyIsImFubm91bmNlIiwiYW5ub3VuY2VNZXNzYWdlIiwiZmFpbCIsIm1lc3NhZ2UiLCJiZWdpbiIsImRpc3BhdGNoT3BlbiIsIm1vdW50UmVsIiwiaGFuZGxlQWN0aXZhdGUiLCJyZWwiLCJmcm9tQWJzIiwidGFyZ2V0RGlyIiwidGFyZ2V0Um9vdCIsInJlbmFtZSIsInJlYXNvbiIsIm1vdmVSZWplY3Rpb24iLCJXUklURV9FUlIiLCJ0byIsImJhc2VuYW1lIiwiZ2V0RW50cmllcyIsImVuIiwicnVuUmVuYW1lIiwidGFyZ2V0RGlyQWJzIiwicnVuVXBsb2FkIiwib25EZWxldGUiLCJkZWxldGUiLCJ3aW5kb3ciLCJjb25maXJtIiwicnVuRGVsZXRlIiwib3Blbk1lbnUiLCJjdHgiLCJIVE1MRWxlbWVudCIsIml0ZW1zIiwiaWNvbiIsIkV4dGVybmFsTGluayIsImJhc2VEaXIiLCJjcmVhdGVGaWxlIiwiRmlsZVBsdXMiLCJjcmVhdGVGb2xkZXIiLCJGb2xkZXJQbHVzIiwiVXBsb2FkIiwiaXNQcm90ZWN0ZWQiLCJGb2xkZXJJbnB1dCIsInRhcmdldEFicyIsImluaXRpYWwiLCJUcmFzaDIiLCJkYW5nZXIiLCJpbnZva2VyIiwic3VibWl0UHJvbXB0IiwidmFsdWUiLCJ0cmltIiwicmVwbGFjZSIsImZyb21SZWwiLCJ0b1JlbCIsInJ1bkNyZWF0ZSIsIm9uVXBsb2FkSW5wdXQiLCJ0YXJnZXQiLCJqb2luUmVsIiwiaGFzUm9vdHMiLCJnbHlwaCIsIkZvbGRlclRyZWUiLCJyZWYiLCJGcmFnbWVudCIsIm9uQ2hhbmdlIiwiY29sbGFwc2VBbGwiLCJDaGV2cm9uc0Rvd25VcCIsInRyYXkiLCJzcGVsbENoZWNrIiwicGxhY2Vob2xkZXIiLCJvbkJsdXIiLCJtdWx0aXBsZSIsImhpZGRlbiIsImFjdGl2ZUZpbGUiLCJ2aWV3ZWRGaWxlIiwiZWplY3QiLCJhbmNob3IiLCJvbkNsb3NlIiwib25Nb3ZlIiwiZGlyQWJzIiwiZGlyUm9vdFBhdGgiLCJfYzUiLCJfZGVmYXVsdCIsImV4cG9ydHMiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJGaWxlRXhwbG9yZXJWaWV3LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBUaGUgaGVhZGxlc3MgZmlsZS1leHBsb3JlciB2aWV3ICgwMC1vdmVydmlldyDCpzMuMjsgUGhhc2UgMDIgwqdBKS4gVGhpcyBpcyB0aGVcbi8vIGZvcm1lciBgRmlsZUV4cGxvcmVyLnRzeGAgb3JjaGVzdHJhdG9yIHdpdGggRVZFUlkgaG9zdC9TREsgY2FsbCBzZXZlcmVkIGludG8gYW5cbi8vIGluamVjdGVkIHByb3A6IGl0IHJlYWRzIHJvb3RzIHRocm91Z2ggYHJvb3RzOiBFeHBsb3JlclJvb3RbXWAsIGJ5dGVzL2VudHJpZXNcbi8vIHRocm91Z2ggYGZzOiBGc1NvdXJjZWAsIHRoZSBhY3RpdmUgZmlsZSB0aHJvdWdoIGBhY3RpdmVQYXRoYCwgYW5kIGVtaXRzIGludGVudHNcbi8vIHRocm91Z2ggYGFjdGlvbnNgL2BvbkFjdGl2YXRlYC9gb25TZWxlY3RgLiBJdCBpbXBvcnRzIE5PIFNESyDigJQgdGhlIFNESyBhZGFwdGVyXG4vLyAoYHNkay9TZGtGaWxlRXhwbG9yZXIudHN4YCkgd2lyZXMgYWxsIG9mIHRoYXQgdXAgYW5kIHJlLWNyZWF0ZXMgdGhlIHNoaXBwZWQgYXBwLlxuLy8gQSBub24tU0RLIGNvbnN1bWVyIChmaWxlLWNvbW1hbmRlcikgc3VwcGxpZXMgaXRzIG93biBmcy9yb290cyBhbmQgc2ltcGx5IG9taXRzXG4vLyB0aGUgYWN0aW9ucyBpdCBkb2Vzbid0IGltcGxlbWVudCAodGhlIGFmZm9yZGFuY2UgdGhlbiBoaWRlcykuXG4vL1xuLy8gV3JpdGVzIHJlbmRlciB0aGVpciBvd24gcmVzdWx0IChSLUlYLTMvUi1JWC00KTogdGhlIHdyaXRlIGZsb3cgaW4gd3JpdGVGbG93LnRzXG4vLyBpbnNlcnRzIHRoZSBwZW5kaW5nIHJvdywgc2V0dGxlcyBpdCBmcm9tIHRoZSBhY3Rpb24ncyByZXR1cm4sIGFuZCByZWZldGNoZXNcbi8vIG9ubHkgdGhlIGNoYW5nZWQgZGlyZWN0b3J5LiBUaGUgdHJlZSBmb2xsb3dzIHRoZSBBUEcgVHJlZSBWaWV3IHBhdHRlcm4gKG9uZVxuLy8gcm92aW5nIHRhYiBzdG9wIHBlciB0cmVlOyB0aGUgZm9jdXNhYmxlIHJvdyBJUyB0aGUgdHJlZWl0ZW0pLCBhbmQgcGVuZGluZyBhbmRcbi8vIHNldHRsZWQgc3RhdGVzIGFubm91bmNlIHRocm91Z2ggT05FIGxpdmUgcmVnaW9uIGJlc2lkZSB0aGUgdmlldyAoUi1JWC03KS5cbmltcG9ydCB7XG4gIG1lbW8sXG4gIHVzZUNhbGxiYWNrLFxuICB1c2VFZmZlY3QsXG4gIHVzZUlkLFxuICB1c2VNZW1vLFxuICB1c2VSZWYsXG4gIHVzZVN0YXRlLFxuICB1c2VTeW5jRXh0ZXJuYWxTdG9yZSxcbiAgdHlwZSBSZWFjdE5vZGUsXG59IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHtcbiAgRm9sZGVyVHJlZSxcbiAgRm9sZGVyLFxuICBGb2xkZXJPcGVuLFxuICBGb2xkZXJHaXQyLFxuICBVc2VycyxcbiAgU2V0dGluZ3MgYXMgU2V0dGluZ3NJY29uLFxuICBGaWxlIGFzIEZpbGVJY29uLFxuICBMb2FkZXIyLFxuICBDaGV2cm9uc0Rvd25VcCxcbiAgRmlsZVBsdXMsXG4gIEZvbGRlclBsdXMsXG4gIEZvbGRlcklucHV0LFxuICBUcmFzaDIsXG4gIFBlbmNpbCxcbiAgVXBsb2FkLFxuICBFeHRlcm5hbExpbmssXG4gIExvY2ssXG4gIENpcmNsZUFycm93VXAsXG4gIFBsYXksXG4gIHR5cGUgTHVjaWRlSWNvbixcbn0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuaW1wb3J0IHtcbiAgVHJlZVN0b3JlLFxuICB1c2VOb2RlLFxuICB1c2VBY3RpdmUsXG4gIHVzZUFjdGl2ZUFuY2VzdG9yLFxuICB1c2VQZW5kaW5nLFxuICB1c2VSb3dGb2N1c2VkLFxuICB1c2VTZWxlY3RlZFJvdyxcbiAgdXNlVHJlZVVuZm9jdXNlZCxcbiAgdXNlVmlld2VkLFxuICB1c2VWaWV3ZWRBbmNlc3Rvcixcbn0gZnJvbSBcIi4vdHJlZVN0b3JlXCI7XG5pbXBvcnQgQ29udGV4dE1lbnUgZnJvbSBcIi4vQ29udGV4dE1lbnVcIjtcbmltcG9ydCBMYXlvdXRTd2l0Y2hlciBmcm9tIFwiLi9MYXlvdXRTd2l0Y2hlclwiO1xuaW1wb3J0IExpc3RWaWV3IGZyb20gXCIuL0xpc3RWaWV3XCI7XG5pbXBvcnQgSWNvbkdyaWQgZnJvbSBcIi4vSWNvbkdyaWRcIjtcbmltcG9ydCBDb2x1bW5WaWV3IGZyb20gXCIuL0NvbHVtblZpZXdcIjtcbmltcG9ydCBNb3ZlRGlhbG9nLCB7IHR5cGUgTW92ZVRhcmdldCB9IGZyb20gXCIuL01vdmVEaWFsb2dcIjtcbmltcG9ydCB7IHVzZUxvbmdQcmVzcyB9IGZyb20gXCIuL2hvb2tzL3VzZUxvbmdQcmVzc1wiO1xuaW1wb3J0IHsgdXNlTGF5b3V0IH0gZnJvbSBcIi4vaG9va3MvdXNlTGF5b3V0XCI7XG5pbXBvcnQgeyBmaXJzdFRyZWVDaGlsZEZvY3VzLCByb3ZpbmdUcmVlRm9jdXMgfSBmcm9tIFwiLi9ob29rcy9yb3ZpbmdUcmVlRm9jdXNcIjtcbmltcG9ydCB7IHR5cGUgTm9kZUhhbmRsZXJzLCBvcGVuUm93TWVudUtleSB9IGZyb20gXCIuL2hvb2tzL3VzZVJvd0ludGVyYWN0aW9uc1wiO1xuaW1wb3J0IHsgcnVuQ3JlYXRlLCBydW5EZWxldGUsIHJ1blJlbmFtZSwgcnVuVXBsb2FkLCB0eXBlIFdyaXRlUG9ydHMgfSBmcm9tIFwiLi93cml0ZUZsb3dcIjtcbmltcG9ydCB7IGFubm91bmNlIGFzIGFubm91bmNlTWVzc2FnZSwgc3Vic2NyaWJlVG9Bbm5vdW5jZW1lbnRzIH0gZnJvbSBcIi4vYW5ub3VuY2VcIjtcbmltcG9ydCB7XG4gIGpvaW5QYXRoLFxuICBqb2luUmVsLFxuICBiYXNlbmFtZSxcbiAgZGlyT2YsXG4gIHRvTW91bnRSZWwsXG4gIG1vdW50TGFiZWwsXG4gIG1vdW50S2luZCxcbiAgbW91bnRTY29wZXMsXG4gIGlzV3JpdGFibGVNb3VudCxcbiAgaXNFamVjdGFibGUsXG4gIGlzUHJvdGVjdGVkLFxuICBvcmRlck1vdW50cyxcbiAgbW92ZVJlamVjdGlvbixcbiAgdXBsb2FkUm93RnJvbUV2ZW50LFxuICB1cGxvYWRUYXJnZXREaXIsXG4gIE1PVkVfTUlNRSxcbiAgV1JJVEVfRVJSLFxufSBmcm9tIFwiLi9leHBsb3JlclwiO1xuaW1wb3J0IHR5cGUge1xuICBFeHBsb3JlclJvb3QsXG4gIEZzU291cmNlLFxuICBFeHBsb3JlckFjdGlvbnMsXG4gIExheW91dCxcbiAgTWVudUFuY2hvcixcbiAgTWVudUl0ZW0sXG4gIFJvd0N0eCxcbn0gZnJvbSBcIi4vdHlwZXNcIjtcblxuLyoqIE9wdGlvbmFsIGV4dGVuc2lvbiBzbG90cyArIGNocm9tZSBzdXBwbGllZCBieSBhIGNvbnN1bWVyLiAqL1xuZXhwb3J0IGludGVyZmFjZSBGaWxlRXhwbG9yZXJWaWV3UHJvcHMge1xuICByb290czogRXhwbG9yZXJSb290W107XG4gIGZzOiBGc1NvdXJjZTtcbiAgLyoqIE9wdGlvbmFsIHByaXZpbGVnZWQgb3BlcmF0aW9uczsgYW4gb21pdHRlZCBhY3Rpb24gaGlkZXMgaXRzIGFmZm9yZGFuY2UuICovXG4gIGFjdGlvbnM/OiBFeHBsb3JlckFjdGlvbnM7XG4gIC8qKiBDb250cm9sbGVkIGhpZ2hsaWdodCAodGhlIGVkaXRvcidzIG9wZW4gZmlsZSwgbW91bnQtcmVsYXRpdmUpLiAqL1xuICBhY3RpdmVQYXRoPzogc3RyaW5nIHwgbnVsbDtcbiAgLyoqIFRoZSBzdGFnZSdzIHZpZXdlZC1kb2N1bWVudCBoaW50IChtb3VudC1yZWxhdGl2ZSwgbGVhZGluZyBzbGFzaDsgUjMtMjY4KSDigJRcbiAgICogIHRoZSBmaWxlIHRoZSBSVU5OSU5HIEFQUCBjbGFpbXMgdG8gYmUgcmVuZGVyaW5nLCBvciBudWxsLiBSZW5kZXJlZCBhcyBhXG4gICAqICBtYXJrZXIgdmlzdWFsbHkgZGlzdGluY3QgZnJvbSB0aGUgZWRpdG9yLWFjdGl2ZSBoaWdobGlnaHQuIEhpZ2hsaWdodC1vbmx5OlxuICAgKiAgdGhlIGV4cGxvcmVyIG5ldmVyIHNjcm9sbHMsIHNlbGVjdHMsIG9yIG5hdmlnYXRlcyBvbiBpdC4gKi9cbiAgdmlld2VkUGF0aD86IHN0cmluZyB8IG51bGw7XG4gIC8qKiBHZXN0dXJlLWdhdGVkIHJldmVhbCAoaG9zdCBgdmlld2VkLXJldmVhbGAsIG9uZS1zaG90IHBlciBub25jZSk6IGV4cGFuZCB0aGVcbiAgICogIHZpZXdlZCBmaWxlJ3MgYW5jZXN0b3JzIGFuZCBzY3JvbGwgaXRzIHJvdyBpbnRvIHZpZXcg4oCUIE5FVkVSIGZvY3VzLiBPbmx5XG4gICAqICBmaXJlZCBieSB0aGUgaG9zdCBmb3IgbmF2aWdhdGlvbnMgdGhhdCBwcm92YWJseSByb2RlIGEgcmVhbCB1c2VyIGNsaWNrO1xuICAgKiAgZXZlcnl0aGluZyBlbHNlIHN0YXlzIGhpZ2hsaWdodC1vbmx5ICsgYW5jZXN0b3IgZG90LiAqL1xuICByZXZlYWw/OiB7IHBhdGg6IHN0cmluZzsgbm9uY2U6IG51bWJlciB9IHwgbnVsbDtcbiAgc2VsZWN0aW9uTW9kZT86IFwic2luZ2xlXCIgfCBcIm11bHRpXCIgfCBcIm5vbmVcIjtcbiAgb25TZWxlY3Q/OiAocm9vdDogRXhwbG9yZXJSb290LCByZWxQYXRoOiBzdHJpbmcpID0+IHZvaWQ7XG4gIC8qKlxuICAgKiBDb250cm9sbGVkIG11bHRpLXNlbGVjdCBub3RpZmljYXRpb24gKGZvciBhIGJhdGNoIGNvbnN1bWVyLCBlLmcuXG4gICAqIGZpbGUtY29tbWFuZGVyJ3MgY29weS9tb3ZlKS4gRmlyZWQgdW5kZXIgYHNlbGVjdGlvbk1vZGUgPT09IFwibXVsdGlcImAgd2hlbmV2ZXJcbiAgICogdGhlIG11bHRpLXNlbGVjdCBTRVQgY2hhbmdlcywgd2l0aCB0aGUgb3duaW5nIGByb290YCBhbmQgdGhlIG1vdW50LXJlbGF0aXZlXG4gICAqIHBhdGhzIG9mIHRoZSBjdXJyZW50IHNldC4gRGlzdGluY3QgZnJvbSBgb25TZWxlY3RgICh0aGUgc2luZ2xlIGN1cnNvciksIHdoaWNoXG4gICAqIHN0aWxsIGZpcmVzIGFzIGJlZm9yZS4gRm9yIGEgc2luZ2xlLXBhbmVsIGNvbnN1bWVyIHRoZSBzZXQgbGl2ZXMgd2l0aGluIG9uZVxuICAgKiByb290OyB0aGF0IHJvb3QgaXMgcmVwb3J0ZWQuXG4gICAqL1xuICBvblNlbGVjdGlvbkNoYW5nZT86IChyb290OiBFeHBsb3JlclJvb3QsIHJlbFBhdGhzOiBzdHJpbmdbXSkgPT4gdm9pZDtcbiAgLyoqXG4gICAqIFNlbWktY29udHJvbGxlZCBjdXJyZW50IGRpcmVjdG9yeSBmb3IgdGhlIGZsYXQgTElTVCBhbmQgSUNPTlMgbGF5b3V0czogYW5cbiAgICogQUJTT0xVVEUgZGlyZWN0b3J5IHBhdGggdGhlIGBGc1NvdXJjZWAgdW5kZXJzdGFuZHMg4oCUIGEgcm9vdCdzIGBwYXRoYCBqb2luZWRcbiAgICogd2l0aCB0aGUgYnJvd3NlZCBzdWJwYXRoLCBvciBgbnVsbGAgZm9yIHRoZSBzeW50aGV0aWMgcm9vdHMtcm9vdC4gV2hlblxuICAgKiBwcm92aWRlZCAoYCE9PSB1bmRlZmluZWRgKSB0aGUgcHJvcCBXSU5TIG92ZXIgaW50ZXJuYWwgc3RhdGU6IHRoZSB2aWV3IHJlbmRlcnNcbiAgICogdGhhdCBkaXJlY3RvcnkgYW5kIG5hdmlnYXRpb24gZmlyZXMgYG9uTmF2aWdhdGUocm9vdCwgcmVsUGF0aClgIFdJVEhPVVRcbiAgICogbXV0YXRpbmcgaW50ZXJuYWwgc3RhdGUsIHNvIGEgY29udHJvbGxlZCBjb25zdW1lciB1cGRhdGVzIGl0cyBvd24gYGN3ZGAgYW5kXG4gICAqIHBhc3NlcyBpdCBiYWNrICh0aGUgc3RhbmRhcmQgY29udHJvbGxlZCBwYXR0ZXJuKS4gV2hlbiBvbWl0dGVkIHRoZSBsaXN0L2ljb25zXG4gICAqIGN3ZCBpcyB1bmNvbnRyb2xsZWQgKHRvZGF5J3MgYmVoYXZpb3IpLiBUaGUgQ09MVU1OUyBsYXlvdXQgaXMgYWx3YXlzXG4gICAqIHVuY29udHJvbGxlZCDigJQgYGN3ZGAgY29udHJvbCBjb3ZlcnMgbGlzdC9pY29ucyAoZmlsZS1jb21tYW5kZXIgdXNlcyBsaXN0KS5cbiAgICovXG4gIGN3ZD86IHN0cmluZyB8IG51bGw7XG4gIG9uQWN0aXZhdGU/OiAocm9vdDogRXhwbG9yZXJSb290LCByZWxQYXRoOiBzdHJpbmcsIGlzRGlyOiBib29sZWFuKSA9PiB2b2lkO1xuICAvKipcbiAgICogRmlyZWQgd2hlbiB0aGUgYnJvd3NlZCBkaXJlY3RvcnkgY2hhbmdlcyBpbiBhIGZsYXQgbGF5b3V0IChsaXN0IC8gaWNvbnMgL1xuICAgKiBjb2x1bW5zKSDigJQgYSBjb25zdW1lciAoZS5nLiBmaWxlLWNvbW1hbmRlcikgb2JzZXJ2ZXMgZWFjaCBwYW5lbCdzIGN1cnJlbnRcbiAgICogZGlyZWN0b3J5LCB0aGUgZGVzdGluYXRpb24gZm9yIGEgY3Jvc3MtcGFuZWwgY29weS9tb3ZlLiBgcmVsUGF0aGAgaXMgdGhlXG4gICAqIG1vdW50LXJlbGF0aXZlIGRpcmVjdG9yeSB3aXRoaW4gYHJvb3RgLiBOb3QgZmlyZWQgZm9yIHRoZSB0cmVlIGxheW91dCAobm9cbiAgICogc2luZ2xlIFwiY3VycmVudCBkaXJlY3RvcnlcIikgbm9yIGZvciB0aGUgc3ludGhldGljIHJvb3RzLXJvb3Qgdmlldy5cbiAgICovXG4gIG9uTmF2aWdhdGU/OiAocm9vdDogRXhwbG9yZXJSb290LCByZWxQYXRoOiBzdHJpbmcpID0+IHZvaWQ7XG4gIC8qKiBDb250cm9sbGVkIGxheW91dCwgb3Igb21pdCBhbmQgcGFzcyBgc3RvcmFnZUtleWAgZm9yIHRoZSBwZXJzaXN0ZWQgZGVmYXVsdC4gKi9cbiAgbGF5b3V0PzogTGF5b3V0O1xuICBvbkxheW91dENoYW5nZT86IChuZXh0OiBMYXlvdXQpID0+IHZvaWQ7XG4gIHN0b3JhZ2VLZXk/OiBzdHJpbmc7XG4gIC8qKiBBcHBlbmQgaXRlbXMgdG8gYSByb3cncyBjb250ZXh0IG1lbnUgKGUuZy4gXCJTdW1tYXJpemXigKZcIikuICovXG4gIGV4dHJhTWVudUl0ZW1zPzogKGN0eDogUm93Q3R4KSA9PiBNZW51SXRlbVtdO1xuICAvKiogUmVuZGVyIGFuIGFjY2Vzc29yeSBuZXh0IHRvIGEgcm93J3MgZGVsZXRlIGJ1dHRvbi4gKi9cbiAgcmVuZGVyUm93QWNjZXNzb3J5PzogKGN0eDogUm93Q3R4KSA9PiBSZWFjdE5vZGU7XG4gIC8qKiBQYW5lbCBoZWFkZXIgY2hyb21lLiBgYWN0aW9uc2AgaXMgdGhlIG9uZS1yb3cgY2x1c3RlciBiZXNpZGUgdGhlIHRpdGxlOyBpdCBob2xkc1xuICAgKiAgY29udHJvbHMgd2hvc2UgY291bnQgaXMgRklYRUQsIGJlY2F1c2UgYSBzaW5nbGUgcm93IGNhbiBvbmx5IGJlIHNoYXJlZCBvdXQgc28gZmFyLlxuICAgKiAgYHRyYXlgIGlzIGEgc2Vjb25kIHJvdyBiZWxvdyB0aGUgaGVhZGVyIGZvciBjb250cm9scyB3aG9zZSBjb3VudCBncm93cyB3aXRoIERBVEFcbiAgICogIChvbmUgcGVyIGFwcCB3aXRoIHNldHRpbmdzLCBzYXkpIOKAlCBhbiB1bmJvdW5kZWQgTiBjYW5ub3QgYmUgc3F1ZWV6ZWQgaW50byBhIGZpeGVkXG4gICAqICByb3csIHNvIGl0IGdldHMgaXRzIG93biBzY3JvbGxhYmxlIHN0cmlwIGluc3RlYWQgb2Ygc2hyaW5raW5nIGl0cyBzaWJsaW5ncyB0b1xuICAgKiAgc2xpdmVycy4gKi9cbiAgaGVhZGVyPzoge1xuICAgIHRpdGxlPzogc3RyaW5nO1xuICAgIGdseXBoPzogUmVhY3ROb2RlO1xuICAgIGFjdGlvbnM/OiBSZWFjdE5vZGU7XG4gICAgdHJheT86IFJlYWN0Tm9kZTtcbiAgfTtcbiAgLyoqIFJlcGxhY2VzIHRoZSBidWlsdC1pbiBcIm5vIGZpbGVzXCIgZW1wdHkgc3RhdGUuICovXG4gIGVtcHR5U3RhdGU/OiBSZWFjdE5vZGU7XG59XG5cbmNvbnN0IFRyZWVOb2RlID0gbWVtbyhmdW5jdGlvbiBUcmVlTm9kZSh7XG4gIHBhdGgsXG4gIG5hbWUsXG4gIGlzRGlyLFxuICBkZXB0aCxcbiAgcm9vdFBhdGgsXG4gIG1vdW50SWQsXG4gIHdyaXRhYmxlLFxuICBzdG9yZSxcbiAgaGFuZGxlcnMsXG4gIHJlbmRlclJvd0FjY2Vzc29yeSxcbn06IHtcbiAgcGF0aDogc3RyaW5nO1xuICBuYW1lOiBzdHJpbmc7XG4gIGlzRGlyOiBib29sZWFuO1xuICBkZXB0aDogbnVtYmVyO1xuICByb290UGF0aDogc3RyaW5nO1xuICBtb3VudElkOiBzdHJpbmc7XG4gIHdyaXRhYmxlOiBib29sZWFuO1xuICBzdG9yZTogVHJlZVN0b3JlO1xuICBoYW5kbGVyczogTm9kZUhhbmRsZXJzO1xuICByZW5kZXJSb3dBY2Nlc3Nvcnk/OiAoY3R4OiBSb3dDdHgpID0+IFJlYWN0Tm9kZTtcbn0pIHtcbiAgY29uc3QgeyBleHBhbmRlZCwgc2VsZWN0ZWQsIGVycm9yZWQsIGVudHJpZXMgfSA9IHVzZU5vZGUoc3RvcmUsIHBhdGgpO1xuICBjb25zdCBvcGVuID0gaXNEaXIgJiYgZXhwYW5kZWQ7XG4gIGNvbnN0IGxvYWRpbmcgPSBpc0RpciAmJiBvcGVuICYmIGVudHJpZXMgPT09IHVuZGVmaW5lZCAmJiAhZXJyb3JlZDtcbiAgLy8gQSB3cml0ZSBpbiBmbGlnaHQ6IHRoZSByb3cgdGhlIHVzZXIganVzdCBhc2tlZCBmb3IsIHJlbmRlcmVkIHBlbmRpbmcgYXRcbiAgLy8gaXRzIGZpbmFsIHBvc2l0aW9uIHVudGlsIHRoZSB3cml0ZSdzIG93biByZXR1cm4gc2V0dGxlcyBpdCAoUi1JWC0zLzQpLlxuICBjb25zdCBwZW5kaW5nID0gdXNlUGVuZGluZyhzdG9yZSwgcGF0aCk7XG4gIGNvbnN0IFtkcm9wVGFyZ2V0LCBzZXREcm9wVGFyZ2V0XSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgLy8gUm92aW5nIHRhYkluZGV4IChBUEcgVHJlZSBWaWV3KTogZXhhY3RseSBvbmUgcm93IHBlciB0cmVlIGlzIHRoZSB0YWIgc3RvcCDigJRcbiAgLy8gdGhlIGZvY3VzZWQgcm93LCBvciB0aGUgdHJlZSdzIHJvb3Qgd2hpbGUgbm8gcm93IG9mIHRoaXMgdHJlZSBob2xkcyBmb2N1cy5cbiAgY29uc3Qgcm93Rm9jdXNlZCA9IHVzZVJvd0ZvY3VzZWQoc3RvcmUsIHBhdGgpO1xuICBjb25zdCB0cmVlVW5mb2N1c2VkID0gdXNlVHJlZVVuZm9jdXNlZChzdG9yZSwgcm9vdFBhdGgpO1xuICBjb25zdCB0YWJTdG9wID0gcm93Rm9jdXNlZCB8fCAodHJlZVVuZm9jdXNlZCAmJiBkZXB0aCA9PT0gMCk7XG4gIGNvbnN0IGdyb3VwSWQgPSB1c2VJZCgpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGlzRGlyICYmIG9wZW4gJiYgZW50cmllcyA9PT0gdW5kZWZpbmVkICYmICFlcnJvcmVkKVxuICAgICAgc3RvcmUuZW5zdXJlTG9hZGVkKHBhdGgpO1xuICB9LCBbaXNEaXIsIG9wZW4sIGVudHJpZXMsIGVycm9yZWQsIHBhdGgsIHN0b3JlXSk7XG5cbiAgY29uc3QgcmVwb1JlbCA9IHRvTW91bnRSZWwocm9vdFBhdGgsIHBhdGgpO1xuICAvLyBBY3RpdmUgaGlnaGxpZ2h0IHZpYSBhIHBlci1ub2RlIHN0b3JlIHN1YnNjcmlwdGlvbiAoTk9UIGEgdGhyZWFkZWQgcHJvcCksIHNvXG4gIC8vIGFuIGFjdGl2ZS1wYXRoIGNoYW5nZSByZS1yZW5kZXJzIG9ubHkgdGhlIGFmZmVjdGVkIHJvd3MgKEZYLTRiKS5cbiAgY29uc3QgYWN0aXZlTWF0Y2ggPSB1c2VBY3RpdmUoc3RvcmUsIHJlcG9SZWwpO1xuICBjb25zdCBhY3RpdmUgPSAhaXNEaXIgJiYgYWN0aXZlTWF0Y2g7XG4gIC8vIFRoZSBjb2xsYXBzZWQtYW5jZXN0b3IgZG90IGZvciB0aGUgRURJVE9SJ3MgZmlsZSwgbWlycm9yaW5nIHRoZSBvbi1zdGFnZSBvbmVcbiAgLy8gYmVsb3c6IGEgY2xvc2VkIGZvbGRlciBob2xkaW5nIHRoZSBlZGl0ZWQgZmlsZSBrZWVwcyBzYXlpbmcgc28sIHNvIGNvbGxhcHNpbmdcbiAgLy8gYHNyYy9gIGRvZXNuJ3QgbWFrZSB0aGUgYW5zd2VyIHRvIFwid2hhdCBhbSBJIGVkaXRpbmc/XCIgZGlzYXBwZWFyIGVudGlyZWx5LlxuICBjb25zdCBhY3RpdmVBbmNlc3Rvck1hdGNoID0gdXNlQWN0aXZlQW5jZXN0b3Ioc3RvcmUsIHJlcG9SZWwpO1xuICBjb25zdCBjb250YWluc0FjdGl2ZSA9IGlzRGlyICYmICFvcGVuICYmIGFjdGl2ZUFuY2VzdG9yTWF0Y2g7XG4gIC8vIFRoZSBcIm9uIHN0YWdlXCIgbWFya2VyIChSMy0yNjgpIOKAlCBzYW1lIHBlci1ub2RlIHN1YnNjcmlwdGlvbiBzaGFwZSBhcyBhY3RpdmUuXG4gIGNvbnN0IHZpZXdlZE1hdGNoID0gdXNlVmlld2VkKHN0b3JlLCByZXBvUmVsKTtcbiAgY29uc3Qgdmlld2VkID0gIWlzRGlyICYmIHZpZXdlZE1hdGNoO1xuICAvLyBUaGUgY29sbGFwc2VkLWFuY2VzdG9yIGRvdDogYSBjbG9zZWQgZm9sZGVyIHdob3NlIHN1YnRyZWUgY29udGFpbnMgdGhlXG4gIC8vIG9uLXN0YWdlIGZpbGUgc2hvd3MgYSBkaW1tZWQgbWFya2VyLCBzbyB0aGUgdmlld2VkIGhpZ2hsaWdodCBpcyBkaXNjb3ZlcmFibGVcbiAgLy8gd2l0aG91dCB0aGUgdHJlZSBldmVyIG1vdmluZyBvbiBpdHMgb3duICh0aGUgaGlnaGxpZ2h0LW9ubHkgY29udHJhY3QpLlxuICBjb25zdCBhbmNlc3Rvck1hdGNoID0gdXNlVmlld2VkQW5jZXN0b3Ioc3RvcmUsIHJlcG9SZWwpO1xuICBjb25zdCBjb250YWluc1ZpZXdlZCA9IGlzRGlyICYmICFvcGVuICYmIGFuY2VzdG9yTWF0Y2g7XG4gIGNvbnN0IHJvd0N0eDogUm93Q3R4ID0geyBhYnNQYXRoOiBwYXRoLCBpc0Rpciwgcm9vdFBhdGgsIG1vdW50SWQsIHdyaXRhYmxlIH07XG5cbiAgY29uc3QgbG9uZ1ByZXNzID0gdXNlTG9uZ1ByZXNzKCh4LCB5KSA9PlxuICAgIGhhbmRsZXJzLm9uTWVudSh7IGNsaWVudFg6IHgsIGNsaWVudFk6IHkgfSwgcm93Q3R4KSxcbiAgKTtcblxuICBjb25zdCBvbktleURvd24gPSAoZTogUmVhY3QuS2V5Ym9hcmRFdmVudCkgPT4ge1xuICAgIGlmIChvcGVuUm93TWVudUtleShlLCBoYW5kbGVycywgcm93Q3R4KSkgcmV0dXJuO1xuICAgIGlmIChlLmtleSA9PT0gXCJFbnRlclwiIHx8IGUua2V5ID09PSBcIiBcIikge1xuICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgaGFuZGxlcnMub25BY3RpdmF0ZShwYXRoLCBpc0Rpcik7XG4gICAgfSBlbHNlIGlmIChlLmtleSA9PT0gXCJBcnJvd1JpZ2h0XCIgJiYgaXNEaXIpIHtcbiAgICAgIC8vIEFQRyBUcmVlIFZpZXc6IGV4cGFuZCBhIGNsb3NlZCBmb2xkZXI7IGluIGFuIG9wZW4gb25lLCBtb3ZlIHRvIHRoZVxuICAgICAgLy8gZmlyc3QgY2hpbGQgKGl0cyByb3dzIG1heSBzdGlsbCBiZSBsb2FkaW5nIOKAlCB0aGUgbW92ZSB0aGVuIG5vLW9wcykuXG4gICAgICBpZiAoIW9wZW4pIHtcbiAgICAgICAgc3RvcmUudG9nZ2xlKHBhdGgpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgZmlyc3RUcmVlQ2hpbGRGb2N1cyhlLmN1cnJlbnRUYXJnZXQgYXMgSFRNTEVsZW1lbnQpO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAoZS5rZXkgPT09IFwiQXJyb3dMZWZ0XCIpIHtcbiAgICAgIC8vIENvbGxhcHNlIGFuIG9wZW4gZm9sZGVyOyBvdGhlcndpc2Ugc3RlcCBvdXQgdG8gdGhlIHBhcmVudCByb3cuXG4gICAgICBpZiAoaXNEaXIgJiYgb3Blbikge1xuICAgICAgICBzdG9yZS50b2dnbGUocGF0aCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zdCBncm91cCA9IGUuY3VycmVudFRhcmdldC5jbG9zZXN0KCd1bFtyb2xlPVwiZ3JvdXBcIl0nKTtcbiAgICAgICAgKGdyb3VwPy5wcmV2aW91c0VsZW1lbnRTaWJsaW5nIGFzIEhUTUxFbGVtZW50IHwgbnVsbCk/LmZvY3VzKCk7XG4gICAgICB9XG4gICAgfVxuICB9O1xuXG4gIC8vIERyYWctb3V0IChSMy04MykgKyBpbnRlcm5hbCBtb3ZlIChSMy04MSkgYm90aCBzdGFydCBoZXJlLiBXZSBzZXQgdGhlIHByaXZhdGVcbiAgLy8gbW92ZSBwYXlsb2FkICh1c2VkIG9ubHkgZm9yIGFuIGluLWV4cGxvcmVyIGRyb3Ag4oCUIGl0IG5hbWVzIHdoZXRoZXIgdGhlXG4gIC8vIGRyYWdnZWQgdGhpbmcgaXMgYSBmb2xkZXIsIHNvIHRoZSBkcm9wIHNpZGUgY2FuIHJlc3RvcmUgdGhlIHJpZ2h0IHJvdykgQU5EXG4gIC8vIGFzayB0aGUgaG9zdCB0byBiZWdpbiBhIGNyb3NzLWFwcCBkcmFnLW91dDsgd2hpY2hldmVyIGRyb3AgZmlyZXMgd2lucyAodGhlXG4gIC8vIG90aGVyIGlzIGNhbmNlbGxlZCkuXG4gIGNvbnN0IG9uRHJhZ1N0YXJ0ID0gKGU6IFJlYWN0LkRyYWdFdmVudCkgPT4ge1xuICAgIGUuZGF0YVRyYW5zZmVyLnNldERhdGEoTU9WRV9NSU1FLCBKU09OLnN0cmluZ2lmeSh7IGZyb206IHBhdGgsIHJvb3RQYXRoLCBpc0RpciB9KSk7XG4gICAgZS5kYXRhVHJhbnNmZXIuZWZmZWN0QWxsb3dlZCA9IFwiY29weU1vdmVcIjtcbiAgICBoYW5kbGVycy5iZWdpbkRyYWdPdXQocGF0aCwgaXNEaXIsIG1vdW50SWQsIHJvb3RQYXRoKTtcbiAgfTtcbiAgY29uc3Qgb25EcmFnRW5kID0gKCkgPT4gaGFuZGxlcnMuY2FuY2VsRHJhZ091dCgpO1xuXG4gIC8vIEEgZGlyZWN0b3J5IHJvdyBpcyBhIGRyb3AgdGFyZ2V0IGZvciBpbnRlcm5hbCBtb3ZlcyBhbmQgT1MtZmlsZSB1cGxvYWRzLlxuICBjb25zdCBvbkRyYWdPdmVyID0gKGU6IFJlYWN0LkRyYWdFdmVudCkgPT4ge1xuICAgIGlmICghaXNEaXIpIHJldHVybjtcbiAgICBjb25zdCBpc01vdmUgPSBlLmRhdGFUcmFuc2Zlci50eXBlcy5pbmNsdWRlcyhNT1ZFX01JTUUpO1xuICAgIGNvbnN0IGlzVXBsb2FkID0gZS5kYXRhVHJhbnNmZXIudHlwZXMuaW5jbHVkZXMoXCJGaWxlc1wiKTtcbiAgICBpZiAoIWlzTW92ZSAmJiAhaXNVcGxvYWQpIHJldHVybjtcbiAgICBpZiAoaXNVcGxvYWQgJiYgIXdyaXRhYmxlKSByZXR1cm47XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgZS5kYXRhVHJhbnNmZXIuZHJvcEVmZmVjdCA9IGlzTW92ZSA/IFwibW92ZVwiIDogXCJjb3B5XCI7XG4gICAgc2V0RHJvcFRhcmdldCh0cnVlKTtcbiAgfTtcbiAgY29uc3Qgb25EcmFnTGVhdmUgPSAoKSA9PiBzZXREcm9wVGFyZ2V0KGZhbHNlKTtcbiAgY29uc3Qgb25Ecm9wID0gKGU6IFJlYWN0LkRyYWdFdmVudCkgPT4ge1xuICAgIGlmICghaXNEaXIpIHJldHVybjtcbiAgICBjb25zdCBtb3ZlID0gZS5kYXRhVHJhbnNmZXIuZ2V0RGF0YShNT1ZFX01JTUUpO1xuICAgIGNvbnN0IGZpbGVzID0gQXJyYXkuZnJvbShlLmRhdGFUcmFuc2Zlci5maWxlcyk7XG4gICAgaWYgKCFtb3ZlICYmICFmaWxlcy5sZW5ndGgpIHJldHVybjtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICBzZXREcm9wVGFyZ2V0KGZhbHNlKTtcbiAgICBoYW5kbGVycy5jYW5jZWxEcmFnT3V0KCk7IC8vIHRoZSBkcm9wIGxhbmRlZCBpbnNpZGUgdGhlIGV4cGxvcmVyIOKGkiBub3QgYSBkcmFnLW91dFxuICAgIGlmIChtb3ZlKSB7XG4gICAgICBjb25zdCB7IGZyb20sIHJvb3RQYXRoOiBmcm9tUm9vdCwgaXNEaXI6IGZyb21Jc0RpciB9ID0gSlNPTi5wYXJzZShtb3ZlKSBhcyB7XG4gICAgICAgIGZyb206IHN0cmluZztcbiAgICAgICAgcm9vdFBhdGg6IHN0cmluZztcbiAgICAgICAgaXNEaXI6IGJvb2xlYW47XG4gICAgICB9O1xuICAgICAgaGFuZGxlcnMub25Nb3ZlRHJvcChmcm9tLCBmcm9tUm9vdCwgZnJvbUlzRGlyLCBwYXRoLCByb290UGF0aCk7XG4gICAgfSBlbHNlIGlmIChmaWxlcy5sZW5ndGgpIHtcbiAgICAgIGhhbmRsZXJzLm9uVXBsb2FkRHJvcChmaWxlcywgcGF0aCwgd3JpdGFibGUpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBJY29uID0gaXNEaXIgPyAob3BlbiA/IEZvbGRlck9wZW4gOiBGb2xkZXIpIDogRmlsZUljb247XG5cbiAgcmV0dXJuIChcbiAgICA8bGkgcm9sZT1cIm5vbmVcIj5cbiAgICAgIHsvKiBUaGUgcm93IElTIHRoZSB0cmVlaXRlbSAoNC4xLjIpOiB0aGUgZm9jdXNhYmxlIGVsZW1lbnQgY2FycmllcyB0aGVcbiAgICAgICAgICByb2xlIGFuZCB0aGUgZnVsbCBhY2Nlc3NpYmxlIG5hbWUsIGFuZCBuZXN0cyBubyBpbnRlcmFjdGl2ZSBlbGVtZW50IOKAlFxuICAgICAgICAgIGRlbGV0ZSBsaXZlcyBpbiB0aGUgcm93J3MgY29udGV4dCBtZW51LiBgYXJpYS1vd25zYCByZS1wYXJlbnRzIHRoZVxuICAgICAgICAgIHNpYmxpbmcgZ3JvdXAgaW50byB0aGUgYWNjZXNzaWJpbGl0eSB0cmVlLCB3aGVyZSB0aGUgRE9NICh3aGljaCBrZWVwc1xuICAgICAgICAgIHRoZSBncm91cCBvdXRzaWRlIHRoZSByb3cgc28gcm93IGV2ZW50cyBuZXZlciBidWJibGUgdGhyb3VnaCBpdClcbiAgICAgICAgICBjYW5ub3QuICovfVxuICAgICAgPGRpdlxuICAgICAgICByb2xlPVwidHJlZWl0ZW1cIlxuICAgICAgICBhcmlhLW93bnM9e2lzRGlyICYmIG9wZW4gPyBncm91cElkIDogdW5kZWZpbmVkfVxuICAgICAgICBhcmlhLWV4cGFuZGVkPXtpc0RpciA/IG9wZW4gOiB1bmRlZmluZWR9XG4gICAgICAgIGFyaWEtc2VsZWN0ZWQ9e3NlbGVjdGVkfVxuICAgICAgICBhcmlhLWJ1c3k9e3BlbmRpbmcgPyB0cnVlIDogdW5kZWZpbmVkfVxuICAgICAgICBhcmlhLWxhYmVsPXtuYW1lfVxuICAgICAgICBjbGFzc05hbWU9e1xuICAgICAgICAgIFwidG5vZGVcIiArXG4gICAgICAgICAgKHNlbGVjdGVkID8gXCIgdG5vZGUtLXNlbGVjdGVkXCIgOiBcIlwiKSArXG4gICAgICAgICAgKGFjdGl2ZSA/IFwiIHRub2RlLS1hY3RpdmVcIiA6IFwiXCIpICtcbiAgICAgICAgICAodmlld2VkID8gXCIgdG5vZGUtLXZpZXdlZFwiIDogXCJcIikgK1xuICAgICAgICAgIChkcm9wVGFyZ2V0ID8gXCIgdG5vZGUtLWRyb3B0YXJnZXRcIiA6IFwiXCIpICtcbiAgICAgICAgICAocGVuZGluZyA/IFwiIHRub2RlLS1wZW5kaW5nXCIgOiBcIlwiKVxuICAgICAgICB9XG4gICAgICAgIHN0eWxlPXt7IHBhZGRpbmdMZWZ0OiA4ICsgZGVwdGggKiAxNCB9fVxuICAgICAgICB0YWJJbmRleD17dGFiU3RvcCA/IDAgOiAtMX1cbiAgICAgICAgZHJhZ2dhYmxlXG4gICAgICAgIG9uRm9jdXM9eygpID0+IHN0b3JlLnNldEZvY3VzKHBhdGgpfVxuICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVycy5vbkFjdGl2YXRlKHBhdGgsIGlzRGlyKX1cbiAgICAgICAgb25LZXlEb3duPXtvbktleURvd259XG4gICAgICAgIG9uQ29udGV4dE1lbnU9eyhlKSA9PiB7XG4gICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgIGhhbmRsZXJzLm9uTWVudShlLCByb3dDdHgpO1xuICAgICAgICB9fVxuICAgICAgICBvbkRyYWdTdGFydD17b25EcmFnU3RhcnR9XG4gICAgICAgIG9uRHJhZ0VuZD17b25EcmFnRW5kfVxuICAgICAgICBvbkRyYWdPdmVyPXtvbkRyYWdPdmVyfVxuICAgICAgICBvbkRyYWdMZWF2ZT17b25EcmFnTGVhdmV9XG4gICAgICAgIG9uRHJvcD17b25Ecm9wfVxuICAgICAgICBvblBvaW50ZXJEb3duPXtsb25nUHJlc3Mub25Qb2ludGVyRG93bn1cbiAgICAgICAgb25Qb2ludGVyTW92ZT17bG9uZ1ByZXNzLm9uUG9pbnRlck1vdmV9XG4gICAgICAgIG9uUG9pbnRlclVwPXtsb25nUHJlc3Mub25Qb2ludGVyVXB9XG4gICAgICAgIG9uUG9pbnRlckNhbmNlbD17bG9uZ1ByZXNzLm9uUG9pbnRlckNhbmNlbH1cbiAgICAgICAgZGF0YS1kaXI9e2lzRGlyID8gXCIxXCIgOiBcIjBcIn1cbiAgICAgICAgZGF0YS1wYXRoPXtwYXRofVxuICAgICAgICBhcmlhLWN1cnJlbnQ9e2FjdGl2ZSA/IFwidHJ1ZVwiIDogdW5kZWZpbmVkfVxuICAgICAgPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0bm9kZV9faWNvblwiPlxuICAgICAgICAgIDxJY29uIHNpemU9ezE1fSBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICA8L3NwYW4+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRub2RlX19uYW1lXCI+e25hbWV9PC9zcGFuPlxuICAgICAgICB7YWN0aXZlICYmIChcbiAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidG5vZGVfX2FjdGl2ZVwiXG4gICAgICAgICAgICByb2xlPVwiaW1nXCJcbiAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJPcGVuIGluIHRoZSBlZGl0b3JcIlxuICAgICAgICAgICAgdGl0bGU9XCJPcGVuIGluIHRoZSBlZGl0b3JcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxQZW5jaWwgc2l6ZT17MTF9IGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICApfVxuICAgICAgICB7Y29udGFpbnNBY3RpdmUgJiYgKFxuICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ0bm9kZV9fYWN0aXZlIHRub2RlX19hY3RpdmUtLWFuY2VzdG9yXCJcbiAgICAgICAgICAgIHJvbGU9XCJpbWdcIlxuICAgICAgICAgICAgYXJpYS1sYWJlbD1cIkNvbnRhaW5zIHRoZSBmaWxlIG9wZW4gaW4gdGhlIGVkaXRvclwiXG4gICAgICAgICAgICB0aXRsZT1cIkNvbnRhaW5zIHRoZSBmaWxlIG9wZW4gaW4gdGhlIGVkaXRvclwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFBlbmNpbCBzaXplPXsxMX0gYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICl9XG4gICAgICAgIHt2aWV3ZWQgJiYgKFxuICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ0bm9kZV9fdmlld2VkXCJcbiAgICAgICAgICAgIHJvbGU9XCJpbWdcIlxuICAgICAgICAgICAgYXJpYS1sYWJlbD1cIlNob3duIGluIHRoZSBydW5uaW5nIGFwcFwiXG4gICAgICAgICAgICB0aXRsZT1cIlNob3duIGluIHRoZSBydW5uaW5nIGFwcFwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFBsYXkgc2l6ZT17MTF9IGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICApfVxuICAgICAgICB7Y29udGFpbnNWaWV3ZWQgJiYgKFxuICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ0bm9kZV9fdmlld2VkIHRub2RlX192aWV3ZWQtLWFuY2VzdG9yXCJcbiAgICAgICAgICAgIHJvbGU9XCJpbWdcIlxuICAgICAgICAgICAgYXJpYS1sYWJlbD1cIkNvbnRhaW5zIHRoZSBmaWxlIHNob3duIGluIHRoZSBydW5uaW5nIGFwcFwiXG4gICAgICAgICAgICB0aXRsZT1cIkNvbnRhaW5zIHRoZSBmaWxlIHNob3duIGluIHRoZSBydW5uaW5nIGFwcFwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFBsYXkgc2l6ZT17MTF9IGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICApfVxuICAgICAgICB7KGxvYWRpbmcgfHwgcGVuZGluZykgJiYgKFxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRub2RlX19zcGluXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+XG4gICAgICAgICAgICA8TG9hZGVyMiBzaXplPXsxM30gLz5cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICl9XG4gICAgICAgIHtyZW5kZXJSb3dBY2Nlc3Nvcnk/Lihyb3dDdHgpfVxuICAgICAgPC9kaXY+XG5cbiAgICAgIHtpc0RpciAmJiBvcGVuICYmIChcbiAgICAgICAgPHVsIHJvbGU9XCJncm91cFwiIGlkPXtncm91cElkfSBjbGFzc05hbWU9XCJ0cmVlX19ncm91cFwiPlxuICAgICAgICAgIHtlcnJvcmVkICYmIChcbiAgICAgICAgICAgIDxsaVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0bm9kZSB0bm9kZS0tbXV0ZWRcIlxuICAgICAgICAgICAgICBzdHlsZT17eyBwYWRkaW5nTGVmdDogOCArIChkZXB0aCArIDEpICogMTQgfX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgQ291bGRu4oCZdCByZWFkIHRoaXMgZm9sZGVyLlxuICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICApfVxuICAgICAgICAgIHtlbnRyaWVzPy5sZW5ndGggPT09IDAgJiYgKFxuICAgICAgICAgICAgPGxpXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRub2RlIHRub2RlLS1tdXRlZFwiXG4gICAgICAgICAgICAgIHN0eWxlPXt7IHBhZGRpbmdMZWZ0OiA4ICsgKGRlcHRoICsgMSkgKiAxNCB9fVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICBFbXB0eVxuICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICApfVxuICAgICAgICAgIHtlbnRyaWVzPy5tYXAoKGVudHJ5KSA9PiAoXG4gICAgICAgICAgICA8VHJlZU5vZGVcbiAgICAgICAgICAgICAga2V5PXtlbnRyeS5uYW1lfVxuICAgICAgICAgICAgICBwYXRoPXtqb2luUGF0aChwYXRoLCBlbnRyeS5uYW1lKX1cbiAgICAgICAgICAgICAgbmFtZT17ZW50cnkubmFtZX1cbiAgICAgICAgICAgICAgaXNEaXI9e2VudHJ5LmlzRGlyfVxuICAgICAgICAgICAgICBkZXB0aD17ZGVwdGggKyAxfVxuICAgICAgICAgICAgICByb290UGF0aD17cm9vdFBhdGh9XG4gICAgICAgICAgICAgIG1vdW50SWQ9e21vdW50SWR9XG4gICAgICAgICAgICAgIHdyaXRhYmxlPXt3cml0YWJsZX1cbiAgICAgICAgICAgICAgc3RvcmU9e3N0b3JlfVxuICAgICAgICAgICAgICBoYW5kbGVycz17aGFuZGxlcnN9XG4gICAgICAgICAgICAgIHJlbmRlclJvd0FjY2Vzc29yeT17cmVuZGVyUm93QWNjZXNzb3J5fVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC91bD5cbiAgICAgICl9XG4gICAgPC9saT5cbiAgKTtcbn0pO1xuXG4vKiogUHJvdmlkZXIvdHlwZSBpY29uIGZvciB0aGUgQXBwLXNjb3BlIGhlYWRlciAoUjMtOTQgLyBQUklOQ0lQQUxTIMKnOSBCMSkuICovXG5jb25zdCBNT1VOVF9JQ09OOiBSZWNvcmQ8UmV0dXJuVHlwZTx0eXBlb2YgbW91bnRLaW5kPiwgTHVjaWRlSWNvbj4gPSB7XG4gIHdvcmt0cmVlOiBGb2xkZXJHaXQyLFxuICBzZXR0aW5nczogU2V0dGluZ3NJY29uLFxuICBzcGFjZTogVXNlcnMsXG4gIG90aGVyOiBGb2xkZXIsXG59O1xuXG4vKiogQSBzaW5nbGUgYnJvd3NhYmxlIHJvb3Q6IHNjb3BlIGhlYWRlciAodHlwZSBpY29uICsgbmFtZSArIHBlci1zdWJ0cmVlIG1vZGVcbiAqICBjaGlwcyArIG9wdGlvbmFsIGVqZWN0KSArIGl0cyB0cmVlLiAqL1xuY29uc3QgU2NvcGUgPSBtZW1vKGZ1bmN0aW9uIFNjb3BlKHtcbiAgcm9vdCxcbiAgc3RvcmUsXG4gIGhhbmRsZXJzLFxuICBvbkVqZWN0LFxuICByZW5kZXJSb3dBY2Nlc3NvcnksXG59OiB7XG4gIHJvb3Q6IEV4cGxvcmVyUm9vdDtcbiAgc3RvcmU6IFRyZWVTdG9yZTtcbiAgaGFuZGxlcnM6IE5vZGVIYW5kbGVycztcbiAgb25FamVjdD86IChyb290OiBFeHBsb3JlclJvb3QpID0+IFByb21pc2U8dm9pZD47XG4gIHJlbmRlclJvd0FjY2Vzc29yeT86IChjdHg6IFJvd0N0eCkgPT4gUmVhY3ROb2RlO1xufSkge1xuICBjb25zdCB3cml0YWJsZSA9IGlzV3JpdGFibGVNb3VudChyb290KTtcbiAgY29uc3QgbW91bnRJZCA9IHJvb3QuaWQ7XG4gIC8vIEVqZWN0IChkZXRhY2gpIOKAlCBzcGFjZXMgLyBncmFudGVkIHN1YnRyZWVzIG9ubHksIG5ldmVyIHRoZSB3b3JrdHJlZSBvciBhXG4gIC8vIHNldHRpbmdzIHN0b3JlIChTUEFDRVNfVUlfU1BFQyDCpzMsIFItU1BBQ0VTLTMpLiBDbG9zZXMgdGhlIHNwYWNlIGZvciB0aGlzXG4gIC8vIHNlc3Npb247IG1lbWJlcnNoaXAvZ3JhbnQgYXJlIHVudG91Y2hlZCBhbmQgaXQgcmUtYWRkcyB2aWEgdGhlIHBvd2VyYm94LlxuICBjb25zdCBjYW5FamVjdCA9IGlzRWplY3RhYmxlKHJvb3QpICYmICEhb25FamVjdDtcbiAgY29uc3QgW2VqZWN0aW5nLCBzZXRFamVjdGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IGRvRWplY3QgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XG4gICAgaWYgKCFvbkVqZWN0IHx8IGVqZWN0aW5nKSByZXR1cm47XG4gICAgc2V0RWplY3RpbmcodHJ1ZSk7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IG9uRWplY3Qocm9vdCk7XG4gICAgfSBjYXRjaCB7XG4gICAgICBzZXRFamVjdGluZyhmYWxzZSk7XG4gICAgfVxuICB9LCBbb25FamVjdCwgZWplY3RpbmcsIHJvb3RdKTtcbiAgY29uc3QgbGFiZWwgPSBtb3VudExhYmVsKHJvb3QpO1xuICBjb25zdCBzY29wZXMgPSBtb3VudFNjb3Blcyhyb290KTtcbiAgY29uc3QgVHlwZUljb24gPSBNT1VOVF9JQ09OW21vdW50S2luZChyb290KV07XG5cbiAgLy8gVGhlIHNjb3BlIGlzIHRoZSBkcm9wIHRhcmdldCBmb3IgZXZlcnkgT1MtZmlsZSBkcm9wIGEgZGlyZWN0b3J5IHJvdyBkb2VzIG5vdFxuICAvLyB0YWtlICjCpzU6IFwib3IgdGhlIHNjb3BlIHJvb3QgaWYgZHJvcHBlZCBvbiBlbXB0eSBzcGFjZSB3aXRoaW4gYSBzY29wZVwiKSDigJQgdGhlXG4gIC8vIGJsYW5rIHNwYWNlIGJlbG93IHRoZSB0cmVlLCB0aGUgc2NvcGUgaGVhZGVyLCBhbmQgZmlsZSByb3dzLCB3aGljaCByZXNvbHZlIHRvXG4gIC8vIHRoZWlyIHBhcmVudCBkaXJlY3RvcnkuIEEgZGlyZWN0b3J5IHJvdyBzdG9wcyBwcm9wYWdhdGlvbiwgc28gaXQgaXMgbmV2ZXIgdGhpc1xuICAvLyBoYW5kbGVyJ3MgYnVzaW5lc3MgYW5kIHRoZSB0d28gYWZmb3JkYW5jZXMgbmV2ZXIgbGlnaHQgYXQgb25jZS4gSW50ZXJuYWwgbW92ZXNcbiAgLy8gKE1PVkVfTUlNRSkgYXJlIGRlbGliZXJhdGVseSBOT1QgYWNjZXB0ZWQgaGVyZTogYSBtb3ZlIG5lZWRzIGEgcmVhbCBkaXJlY3RvcnksXG4gIC8vIGFuZCBgbW92ZVJlamVjdGlvbmAgaXMgdGhlIHJvd3MnIHRvIGFwcGx5LlxuICBjb25zdCBbZHJhZ2dpbmcsIHNldERyYWdnaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgYWNjZXB0c1VwbG9hZCA9IChlOiBSZWFjdC5EcmFnRXZlbnQpID0+IHdyaXRhYmxlICYmIGUuZGF0YVRyYW5zZmVyLnR5cGVzLmluY2x1ZGVzKFwiRmlsZXNcIik7XG4gIGNvbnN0IG9uU2NvcGVEcmFnT3ZlciA9IChlOiBSZWFjdC5EcmFnRXZlbnQpID0+IHtcbiAgICBpZiAoIWFjY2VwdHNVcGxvYWQoZSkpIHJldHVybjtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgZS5kYXRhVHJhbnNmZXIuZHJvcEVmZmVjdCA9IFwiY29weVwiO1xuICAgIHNldERyYWdnaW5nKHRydWUpO1xuICB9O1xuICBjb25zdCBvblNjb3BlRHJhZ0xlYXZlID0gKGU6IFJlYWN0LkRyYWdFdmVudCkgPT4ge1xuICAgIC8vIGBkcmFnbGVhdmVgIGZpcmVzIHdoZW4gY3Jvc3NpbmcgYmV0d2VlbiBjaGlsZHJlbiB0b287IG9ubHkgYSBwb2ludGVyIHRoYXQgaGFzXG4gICAgLy8gYWN0dWFsbHkgbGVmdCB0aGUgc2NvcGUgY2xlYXJzIHRoZSBhZmZvcmRhbmNlLlxuICAgIGlmICghZS5jdXJyZW50VGFyZ2V0LmNvbnRhaW5zKGUucmVsYXRlZFRhcmdldCBhcyBOb2RlIHwgbnVsbCkpIHNldERyYWdnaW5nKGZhbHNlKTtcbiAgfTtcbiAgY29uc3Qgb25TY29wZURyb3AgPSAoZTogUmVhY3QuRHJhZ0V2ZW50KSA9PiB7XG4gICAgaWYgKCFhY2NlcHRzVXBsb2FkKGUpKSByZXR1cm47XG4gICAgY29uc3QgZmlsZXMgPSBBcnJheS5mcm9tKGUuZGF0YVRyYW5zZmVyLmZpbGVzKTtcbiAgICBpZiAoIWZpbGVzLmxlbmd0aCkgcmV0dXJuO1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBzZXREcmFnZ2luZyhmYWxzZSk7XG4gICAgaGFuZGxlcnMub25VcGxvYWREcm9wKGZpbGVzLCB1cGxvYWRSb3dGcm9tRXZlbnQoZSwgcm9vdC5wYXRoKSwgd3JpdGFibGUpO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgY2xhc3NOYW1lPVwibW91bnRcIlxuICAgICAgZGF0YS1kcmFnPXtkcmFnZ2luZyA/IFwiMVwiIDogdW5kZWZpbmVkfVxuICAgICAgb25EcmFnT3Zlcj17b25TY29wZURyYWdPdmVyfVxuICAgICAgb25EcmFnTGVhdmU9e29uU2NvcGVEcmFnTGVhdmV9XG4gICAgICBvbkRyb3BDYXB0dXJlPXsoKSA9PiBzZXREcmFnZ2luZyhmYWxzZSl9XG4gICAgICBvbkRyb3A9e29uU2NvcGVEcm9wfVxuICAgID5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2NvcGVcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzY29wZV9faGVhZFwiPlxuICAgICAgICAgIDxUeXBlSWNvbiBjbGFzc05hbWU9XCJzY29wZV9faWNvblwiIHNpemU9ezEzfSBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNjb3BlX19uYW1lXCI+e2xhYmVsfTwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2NvcGVfX2NoaXBzXCI+XG4gICAgICAgICAge3Njb3Blcy5tYXAoKHMpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHNybyA9IHMubW9kZSA9PT0gXCJyb1wiO1xuICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgPHNwYW4ga2V5PXtzLnN1YnRyZWV9IGNsYXNzTmFtZT1cInNjb3BlX19jaGlwXCI+XG4gICAgICAgICAgICAgICAge3NybyAmJiA8TG9jayBzaXplPXsxMX0gYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz59XG4gICAgICAgICAgICAgICAge3Muc3VidHJlZX0gwrcge3NybyA/IFwicmVhZC1vbmx5XCIgOiBcInJlYWQtd3JpdGVcIn1cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9KX1cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIHtjYW5FamVjdCAmJiAoXG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJzY29wZV9fZWplY3RcIlxuICAgICAgICAgICAgb25DbGljaz17ZG9FamVjdH1cbiAgICAgICAgICAgIGRpc2FibGVkPXtlamVjdGluZ31cbiAgICAgICAgICAgIGFyaWEtbGFiZWw9e2BFamVjdCAke2xhYmVsfWB9XG4gICAgICAgICAgICB0aXRsZT17YEVqZWN0ICR7bGFiZWx9IChjbG9zZXMgaXQgaGVyZTsgeW91ciBhY2Nlc3MgaXMgdW5jaGFuZ2VkKWB9XG4gICAgICAgICAgPlxuICAgICAgICAgICAge2VqZWN0aW5nID8gKFxuICAgICAgICAgICAgICA8TG9hZGVyMiBzaXplPXsxM30gY2xhc3NOYW1lPVwidG5vZGVfX3NwaW5cIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgPENpcmNsZUFycm93VXAgc2l6ZT17MTN9IGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG4gICAgICB7LyogVXAvRG93bi9Ib21lL0VuZCByb2FtIHRoZSBWSVNJQkxFIHJvd3MgKGEgY29sbGFwc2VkIGZvbGRlcidzIHJvd3MgYXJlXG4gICAgICAgICAgc2ltcGx5IG5vdCByZW5kZXJlZCwgc28gRE9NIG9yZGVyIGlzIHZpc3VhbCBvcmRlcik7IFJpZ2h0L0xlZnQgYXJlIHRoZVxuICAgICAgICAgIHJvd3MnIG93biAoZXhwYW5kIC8gY29sbGFwc2UgLyBzdGVwIG91dCkuICovfVxuICAgICAgPHVsXG4gICAgICAgIHJvbGU9XCJ0cmVlXCJcbiAgICAgICAgYXJpYS1sYWJlbD17bGFiZWx9XG4gICAgICAgIGNsYXNzTmFtZT1cInRyZWVcIlxuICAgICAgICBvbktleURvd249eyhlKSA9PiB7XG4gICAgICAgICAgaWYgKHJvdmluZ1RyZWVGb2N1cyhlLmN1cnJlbnRUYXJnZXQsIGUua2V5KSkgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICB9fVxuICAgICAgPlxuICAgICAgICA8VHJlZU5vZGVcbiAgICAgICAgICBrZXk9e3Jvb3QucGF0aH1cbiAgICAgICAgICBwYXRoPXtyb290LnBhdGh9XG4gICAgICAgICAgbmFtZT17bGFiZWx9XG4gICAgICAgICAgaXNEaXJcbiAgICAgICAgICBkZXB0aD17MH1cbiAgICAgICAgICByb290UGF0aD17cm9vdC5wYXRofVxuICAgICAgICAgIG1vdW50SWQ9e21vdW50SWR9XG4gICAgICAgICAgd3JpdGFibGU9e3dyaXRhYmxlfVxuICAgICAgICAgIHN0b3JlPXtzdG9yZX1cbiAgICAgICAgICBoYW5kbGVycz17aGFuZGxlcnN9XG4gICAgICAgICAgcmVuZGVyUm93QWNjZXNzb3J5PXtyZW5kZXJSb3dBY2Nlc3Nvcnl9XG4gICAgICAgIC8+XG4gICAgICA8L3VsPlxuICAgIDwvZGl2PlxuICApO1xufSk7XG5cbmZ1bmN0aW9uIEZpbGVFeHBsb3JlclZpZXcoe1xuICByb290cyxcbiAgZnMsXG4gIGFjdGlvbnMsXG4gIGFjdGl2ZVBhdGggPSBudWxsLFxuICB2aWV3ZWRQYXRoID0gbnVsbCxcbiAgcmV2ZWFsID0gbnVsbCxcbiAgc2VsZWN0aW9uTW9kZSA9IFwic2luZ2xlXCIsXG4gIG9uU2VsZWN0LFxuICBvblNlbGVjdGlvbkNoYW5nZSxcbiAgb25BY3RpdmF0ZSxcbiAgb25OYXZpZ2F0ZSxcbiAgY3dkOiBjd2RQcm9wLFxuICBsYXlvdXQ6IGxheW91dFByb3AsXG4gIG9uTGF5b3V0Q2hhbmdlLFxuICBzdG9yYWdlS2V5LFxuICBleHRyYU1lbnVJdGVtcyxcbiAgcmVuZGVyUm93QWNjZXNzb3J5LFxuICBoZWFkZXIsXG4gIGVtcHR5U3RhdGUsXG59OiBGaWxlRXhwbG9yZXJWaWV3UHJvcHMpIHtcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW21lbnUsIHNldE1lbnVdID0gdXNlU3RhdGU8TWVudUFuY2hvciB8IG51bGw+KG51bGwpO1xuICAvLyBcIk1vdmUgdG/igKZcIiBwaWNrZXIgdGFyZ2V0ICh0aGUgbm9uLWRyYWcgbW92ZSBwYXRoLCBXQ0FHIDIuNS43KS5cbiAgY29uc3QgW21vdmVUYXJnZXQsIHNldE1vdmVUYXJnZXRdID0gdXNlU3RhdGU8TW92ZVRhcmdldCB8IG51bGw+KG51bGwpO1xuICAvLyBUaGUgT05FIGxpdmUgcmVnaW9uIChSLUlYLTcpOiBwZW5kaW5nIGFuZCBzZXR0bGVkIHN0YXRlcyBhcmUgYW5ub3VuY2VkXG4gIC8vIGhlcmUsIG5ldmVyIHNjYXR0ZXJlZCBwZXIgY29tcG9uZW50LiBUaGUgcmVnaW9uJ3MgbWVzc2FnZSBjb21lcyBmcm9tIHRoZVxuICAvLyBhbm5vdW5jZW1lbnQgY2hhbm5lbCAoYW5ub3VuY2UudHMpLCBzbyB0aGUgdmlldydzIG93biB3cml0ZXMgQU5EIHNpYmxpbmdcbiAgLy8gb3ZlcmxheXMgKHRoZSBzdW1tYXJpemUgbW9kYWwpIHJlYWNoIHRoZSBzYW1lIHNpbmdsZSByZWdpb24uXG4gIGNvbnN0IFtzdGF0dXNNc2csIHNldFN0YXR1c01zZ10gPSB1c2VTdGF0ZShcIlwiKTtcbiAgdXNlRWZmZWN0KCgpID0+IHN1YnNjcmliZVRvQW5ub3VuY2VtZW50cyhzZXRTdGF0dXNNc2cpLCBbXSk7XG4gIC8vIElubGluZSBwcm9tcHQgZm9yIGNyZWF0ZSAvIHJlbmFtZTogYSBzaW5nbGUgdGFyZ2V0ZWQgaW5wdXQuXG4gIGNvbnN0IFtwcm9tcHQsIHNldFByb21wdF0gPSB1c2VTdGF0ZTxcbiAgICB8IHtcbiAgICAgICAgbW9kZTogXCJjcmVhdGUtZmlsZVwiIHwgXCJjcmVhdGUtZm9sZGVyXCI7XG4gICAgICAgIGJhc2VEaXI6IHN0cmluZztcbiAgICAgICAgcm9vdFBhdGg6IHN0cmluZztcbiAgICAgIH1cbiAgICB8IHtcbiAgICAgICAgbW9kZTogXCJyZW5hbWVcIjtcbiAgICAgICAgdGFyZ2V0QWJzOiBzdHJpbmc7XG4gICAgICAgIHJvb3RQYXRoOiBzdHJpbmc7XG4gICAgICAgIGluaXRpYWw6IHN0cmluZztcbiAgICAgICAgaXNEaXI6IGJvb2xlYW47XG4gICAgICB9XG4gICAgfCBudWxsXG4gID4obnVsbCk7XG4gIGNvbnN0IFtwcm9tcHRWYWx1ZSwgc2V0UHJvbXB0VmFsdWVdID0gdXNlU3RhdGUoXCJcIik7XG4gIC8vIFRoZSByb3cgdGhhdCBvcGVuZWQgdGhlIG1lbnUgdGhlIHByb21wdCBjYW1lIGZyb20g4oCUIHJlYWQgc3luY2hyb25vdXNseSBpblxuICAvLyBgb3Blbk1lbnVgIChhIHN5bnRoZXRpYyBldmVudCdzIGBjdXJyZW50VGFyZ2V0YCBkaWVzIHdpdGggaXRzIGhhbmRsZXIpIGFuZFxuICAvLyBjb25zdW1lZCBieSB0aGUgcHJvbXB0J3MgRXNjYXBlLWNhbmNlbCB0byBoYW5kIGZvY3VzIGJhY2sgKFItSVgtMSdzIHJldHVybikuXG4gIGNvbnN0IHByb21wdFJldHVyblJlZiA9IHVzZVJlZjxIVE1MRWxlbWVudCB8IG51bGw+KG51bGwpO1xuICAvLyBTZXQgd2hpbGUgYW4gRXNjYXBlLWNhbmNlbCBpcyBjbG9zaW5nIHRoZSBwcm9tcHQsIHNvIHRoZSBpbnB1dCdzIGJsdXIgKGZpcmVkXG4gIC8vIHN5bmNocm9ub3VzbHkgYnkgdGhlIGZvY3VzIGhhbmQtYmFjaykgY2Fubm90IHJ1biBgc3VibWl0UHJvbXB0YCBhbmQgdHVybiB0aGVcbiAgLy8gY2FuY2VsIGludG8gYSBjb21taXQuXG4gIGNvbnN0IHByb21wdENhbmNlbGxpbmdSZWYgPSB1c2VSZWYoZmFsc2UpO1xuICAvLyBUaGUgcHJvbXB0IHRha2VzIGZvY3VzIGluIGEgbW91bnQgRUZGRUNULCBub3QgYGF1dG9Gb2N1c2A6IHRoZSBwcm9tcHRcbiAgLy8gdXN1YWxseSBvcGVucyBhcyB0aGUgY29udGV4dCBtZW51IGNsb3NlcywgYW5kIHRoZSBtZW51J3MgZm9jdXMtcmV0dXJuXG4gIC8vIChpdHMgdW5tb3VudCBjbGVhbnVwKSB3b3VsZCBvdGhlcndpc2UgbGFuZCBhZnRlciBgYXV0b0ZvY3VzYCBhbmQgc3RlYWxcbiAgLy8gZm9jdXMgc3RyYWlnaHQgYmFjayDigJQgYmx1cnJpbmcgdGhlIGlucHV0IGludG8gYSBwaGFudG9tIGJsdXItY29tbWl0LlxuICAvLyBFZmZlY3Qgc2V0dXAgcnVucyBhZnRlciBldmVyeSBjbGVhbnVwIGluIHRoZSBzYW1lIGNvbW1pdCwgc28gdGhlIGlucHV0XG4gIC8vIHJlbGlhYmx5IGVuZHMgdXAgZm9jdXNlZC5cbiAgY29uc3QgcHJvbXB0SW5wdXRSZWYgPSB1c2VSZWY8SFRNTElucHV0RWxlbWVudD4obnVsbCk7XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKHByb21wdCkgcHJvbXB0SW5wdXRSZWYuY3VycmVudD8uZm9jdXMoKTtcbiAgfSwgW3Byb21wdF0pO1xuICBjb25zdCB1cGxvYWRJbnB1dFJlZiA9IHVzZVJlZjxIVE1MSW5wdXRFbGVtZW50PihudWxsKTtcbiAgY29uc3QgdXBsb2FkVGFyZ2V0UmVmID0gdXNlUmVmPHsgZGlyOiBzdHJpbmc7IHJvb3RQYXRoOiBzdHJpbmcgfSB8IG51bGw+KFxuICAgIG51bGwsXG4gICk7XG5cbiAgLy8gVGhlIHN0b3JlIHJlYWRzIHRocm91Z2ggdGhlIGluamVjdGVkIGZzLiBgZnNgIGlzIHN0YWJsZSBwZXIgY29uc3VtZXIsIHNvIHRoZVxuICAvLyBzdG9yZSBpcyBjb25zdHJ1Y3RlZCBvbmNlIChhIGNoYW5naW5nIGBmc2Agd291bGQgd2FycmFudCBhIGZyZXNoIHN0b3JlKS5cbiAgY29uc3QgW3N0b3JlXSA9IHVzZVN0YXRlKCgpID0+IG5ldyBUcmVlU3RvcmUoZnMpKTtcblxuICBjb25zdCBbbGF5b3V0U3RhdGUsIHNldExheW91dFN0YXRlXSA9IHVzZUxheW91dChzdG9yYWdlS2V5KTtcbiAgY29uc3QgbGF5b3V0ID0gbGF5b3V0UHJvcCA/PyBsYXlvdXRTdGF0ZTtcbiAgY29uc3Qgc2V0TGF5b3V0ID0gdXNlQ2FsbGJhY2soXG4gICAgKG5leHQ6IExheW91dCkgPT4ge1xuICAgICAgaWYgKG9uTGF5b3V0Q2hhbmdlKSBvbkxheW91dENoYW5nZShuZXh0KTtcbiAgICAgIGlmIChsYXlvdXRQcm9wID09PSB1bmRlZmluZWQpIHNldExheW91dFN0YXRlKG5leHQpO1xuICAgIH0sXG4gICAgW29uTGF5b3V0Q2hhbmdlLCBsYXlvdXRQcm9wLCBzZXRMYXlvdXRTdGF0ZV0sXG4gICk7XG4gIGNvbnN0IFtjd2QsIHNldEN3ZF0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2NvbFBhdGgsIHNldENvbFBhdGhdID0gdXNlU3RhdGU8c3RyaW5nW10+KFtdKTtcblxuICBjb25zdCBvcmRlcmVkID0gdXNlTWVtbygoKSA9PiBvcmRlck1vdW50cyhyb290cyksIFtyb290c10pO1xuICBjb25zdCByb290QnlQYXRoID0gdXNlQ2FsbGJhY2soXG4gICAgKHA6IHN0cmluZykgPT5cbiAgICAgIG9yZGVyZWQuZmluZCgobSkgPT4gcCA9PT0gbS5wYXRoIHx8IHAuc3RhcnRzV2l0aChtLnBhdGggKyBcIi9cIikpID8/IG51bGwsXG4gICAgW29yZGVyZWRdLFxuICApO1xuICAvLyBUaGUgdXBsb2FkIGJ1dHRvbidzIGRlc3RpbmF0aW9uIChGSUxFX0VYUExPUkVSX1NQRUMgwqc1KTogdGhlIHNlbGVjdGVkIHJvdydzXG4gIC8vIGRpcmVjdG9yeSDigJQgYSBzZWxlY3RlZCBkaXJlY3RvcnkgaXRzZWxmLCBhIHNlbGVjdGVkIGZpbGUncyBQQVJFTlQgKHRoZVxuICAvLyB1cGxvYWQgYmVjb21lcyBpdHMgc2libGluZykg4oCUIG9yIHRoZSByZXBvIHJvb3Qgd2hlbiBub3RoaW5nIGlzIHNlbGVjdGVkLlxuICAvLyBUaGUgZGVzdGluYXRpb24gcmVzb2x2ZXMgdW5kZXIgdGhlIFNFTEVDVElPTidTIE9XTiByb290IHdoZW4gdGhhdCByb290IGlzXG4gIC8vIHdyaXRhYmxlIChzbyBcImEgZGlyZWN0b3J5IOKGkiB0aGF0IGRpcmVjdG9yeVwiIGhvbGRzIGluIGFueSB3cml0YWJsZSBzY29wZSxcbiAgLy8gbm90IGp1c3QgdGhlIGZpcnN0KTsgYSBzZWxlY3Rpb24gaW5zaWRlIGEgcmVhZC1vbmx5IHNjb3BlIGNhbm5vdCByZWNlaXZlXG4gIC8vIGFuIHVwbG9hZCwgYW5kIHRoZSBkZXN0aW5hdGlvbiB0aGVuIGZhbGxzIGJhY2sgdG8gdGhlIHJlcG8gcm9vdCDigJRcbiAgLy8gYG9yZGVyZWRgIHJhbmtzIHRoZSB3b3JrdHJlZSBmaXJzdCwgc28gdGhlIGZpcnN0IHdyaXRhYmxlIHJvb3QgSVMgdGhlXG4gIC8vIHJlcG8gcm9vdC4gTmV2ZXIgc2hvd24tdGhlbi1gRVJPRlNgLCBwZXIgwqcyLlxuICBjb25zdCB1cGxvYWRSb290ID0gdXNlTWVtbyhcbiAgICAoKSA9PiBvcmRlcmVkLmZpbmQoKG0pID0+IGlzV3JpdGFibGVNb3VudChtKSkgPz8gbnVsbCxcbiAgICBbb3JkZXJlZF0sXG4gICk7XG4gIGNvbnN0IHNlbGVjdGVkUm93ID0gdXNlU2VsZWN0ZWRSb3coc3RvcmUpO1xuICBjb25zdCBzZWxlY3RlZFJvd1Jvb3QgPSBzZWxlY3RlZFJvdyA/IHJvb3RCeVBhdGgoc2VsZWN0ZWRSb3cucGF0aCkgOiBudWxsO1xuICBjb25zdCB1c2FibGVTZWxlY3RlZFJvdyA9XG4gICAgc2VsZWN0ZWRSb3cgJiYgc2VsZWN0ZWRSb3dSb290Py53cml0YWJsZSA/IHNlbGVjdGVkUm93IDogbnVsbDtcbiAgLy8gVGhlIHJvb3QgdGhlIGRlc3RpbmF0aW9uIGlzIHJlc29sdmVkIGFnYWluc3Q6IHRoZSBzZWxlY3Rpb24ncyBvd24gd3JpdGFibGVcbiAgLy8gcm9vdCwgZWxzZSB0aGUgcmVwby1yb290IGZhbGxiYWNrLiBgdXBsb2FkVGFyZ2V0RGlyYCBhbnN3ZXJzIGFuIGFic29sdXRlXG4gIC8vIHBhdGgsIHNvIGl0IE1VU1QgYmUgcmVsYXRpdml6ZWQgYWdhaW5zdCB0aGUgc2FtZSByb290IHRoYXQgb3ducyBpdCDigJQgYVxuICAvLyBibGluZCBzbGljZSBhZ2FpbnN0IGB1cGxvYWRSb290YCB3b3VsZCBjb3JydXB0IGEgc2VsZWN0aW9uIGxpdmluZyB1bmRlciBhXG4gIC8vIGRpZmZlcmVudCAod3JpdGFibGUpIG1vdW50LlxuICBjb25zdCBkZXN0Um9vdCA9IHVzYWJsZVNlbGVjdGVkUm93ICYmIHNlbGVjdGVkUm93Um9vdCA/IHNlbGVjdGVkUm93Um9vdCA6IHVwbG9hZFJvb3Q7XG4gIGNvbnN0IHVwbG9hZERpclJlbCA9IGRlc3RSb290XG4gICAgPyB0b01vdW50UmVsKGRlc3RSb290LnBhdGgsIHVwbG9hZFRhcmdldERpcih1c2FibGVTZWxlY3RlZFJvdywgZGVzdFJvb3QucGF0aCkpXG4gICAgOiBudWxsO1xuICBjb25zdCB1cGxvYWREZXN0TGFiZWwgPVxuICAgICFkZXN0Um9vdCB8fCB1cGxvYWREaXJSZWwgPT09IG51bGxcbiAgICAgID8gXCJcIlxuICAgICAgOiB1cGxvYWREaXJSZWwgPT09IFwiL1wiXG4gICAgICAgID8gZGVzdFJvb3QgPT09IHVwbG9hZFJvb3RcbiAgICAgICAgICA/IFwidGhlIHJlcG8gcm9vdFwiXG4gICAgICAgICAgOiBgdGhlICR7bW91bnRMYWJlbChkZXN0Um9vdCl9IHJvb3RgXG4gICAgICAgIDogdXBsb2FkRGlyUmVsO1xuICAvKiogwqc1IHVwbG9hZCBidXR0b246IG9wZW4gdGhlIGJyb3dzZXIncyBuYXRpdmUgZmlsZSBwaWNrZXIgb24gdGhlIHNoYXJlZFxuICAgKiAgaGlkZGVuIGlucHV0ICh0aGUgc2FtZSBvbmUgdGhlIMKnMyBcIlVwbG9hZCBoZXJl4oCmXCIgaXRlbSB1c2VzKS4gKi9cbiAgY29uc3Qgb3BlblVwbG9hZFBpY2tlciA9ICgpID0+IHtcbiAgICBpZiAoIWFjdGlvbnM/LnVwbG9hZCB8fCAhZGVzdFJvb3QgfHwgdXBsb2FkRGlyUmVsID09PSBudWxsKSByZXR1cm47XG4gICAgdXBsb2FkVGFyZ2V0UmVmLmN1cnJlbnQgPSB7IGRpcjogdXBsb2FkRGlyUmVsLCByb290UGF0aDogZGVzdFJvb3QucGF0aCB9O1xuICAgIHVwbG9hZElucHV0UmVmLmN1cnJlbnQ/LmNsaWNrKCk7XG4gIH07XG4gIC8vIElkZW1wb3RlbnQgKyBlbWl0LWZyZWU6IHNhZmUgZHVyaW5nIHJlbmRlciBzbyBuZXcgc2NvcGVzIHBhaW50IG9wZW4uXG4gIHN0b3JlLmVuc3VyZVJvb3RzKG9yZGVyZWQubWFwKChtKSA9PiBtLnBhdGgpKTtcblxuICAvLyBNaXJyb3IgdGhlIGNvbnRyb2xsZWQgYWN0aXZlIHBhdGggaW50byB0aGUgc3RvcmUgKEZYLTRiKS4gSGVsZCBpbiB0aGUgc3RvcmUg4oCUXG4gIC8vIG5vdCB0aHJlYWRlZCBhcyBhIHByb3AgdGhyb3VnaCB0aGUgbWVtb2l6ZWQgdHJlZSDigJQgc28gYSBjaGFuZ2UgcmUtcmVuZGVycyBvbmx5XG4gIC8vIHRoZSB0d28gcm93cyB3aG9zZSBhY3RpdmUgc3RhdGUgZmxpcHMsIG5ldmVyIHRoZSB3aG9sZSB0cmVlLlxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHN0b3JlLnNldEFjdGl2ZUZpbGUoYWN0aXZlUGF0aCk7XG4gIH0sIFtzdG9yZSwgYWN0aXZlUGF0aF0pO1xuICAvLyBNaXJyb3IgdGhlIHN0YWdlJ3Mgdmlld2VkLWRvY3VtZW50IGhpbnQgdGhlIHNhbWUgd2F5IChSMy0yNjgpLlxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHN0b3JlLnNldFZpZXdlZEZpbGUodmlld2VkUGF0aCk7XG4gIH0sIFtzdG9yZSwgdmlld2VkUGF0aF0pO1xuXG4gIC8vIEdlc3R1cmUtZ2F0ZWQgcmV2ZWFsOiBvbmUtc2hvdCBwZXIgbm9uY2UuIEV4cGFuZCB0aGUgYW5jZXN0b3JzLCB0aGVuIHNjcm9sbFxuICAvLyB0aGUgcm93IGludG8gdmlldyBvbmNlIGl0IHJlbmRlcnMgKGNoaWxkcmVuIGxvYWQgbGF6aWx5IG9uIGV4cGFuZCwgc28gcG9sbFxuICAvLyBicmllZmx5IGFuZCBnaXZlIHVwIHF1aWV0bHkpLiBzY3JvbGxJbnRvVmlldyBvbmx5IOKAlCBmb2N1cyBORVZFUiBtb3Zlcy5cbiAgLy9cbiAgLy8gYHJvb3RLZXlgIChkZWNsYXJlZCBoZXJlIHNvIEJPVEggcmV2ZWFsIGVmZmVjdHMgc2hhcmUgaXQpIGlzIGluIHRoZSBkZXBzIGZvclxuICAvLyB0aGUgc2FtZSByZWFzb24gRlgtNGIgZG9jdW1lbnRzIGJlbG93OiB0aGUgcmV2ZWFsIHJvdXRpbmVseSBsYW5kcyBiZWZvcmUgdGhlXG4gIC8vIG1vdW50cyBkbyAoUjMtNDQwIOKAlCBub3cgZ3VhcmFudGVlZCBieSB0aGUgaG9zdCBob2xkaW5nIHRoZSBvbmUtc2hvdCB1bnRpbCB0aGVcbiAgLy8gYXBwJ3MgYHJlcG9ydFJlYWR5YCwgd2hpY2ggZmlyZXMgYXQgdGhlIG1vdW50IGVmZmVjdCwgYmVmb3JlIGFueSByb290cyByZWFjaFxuICAvLyB0aGUgc3RvcmUpLCBhbmQgYSBgcmV2ZWFsUGF0aGAgYWdhaW5zdCBhbiBlbXB0eSByb290IHNldCBpcyBzaWxlbnRseSBpbmVydC5cbiAgLy8gVGhlIGV4cGFuc2lvbiBpcyBpZGVtcG90ZW50LCBzbyBhIHJvb3RzLWFycml2ZWQgcmUtcnVuIGlzIGEgcmV0cnksIG5vdCBhXG4gIC8vIHJlLWZpcmU7IHRoZSBub25jZSBndWFyZCBrZWVwcyB0aGUgU0NST0xMIG9uZS1zaG90IHBlciBnZXN0dXJlLlxuICBjb25zdCByb290S2V5ID0gdXNlTWVtbyhcbiAgICAoKSA9PiBvcmRlcmVkLm1hcCgobSkgPT4gbS5wYXRoKS5qb2luKFwiXFx1MDAwMFwiKSxcbiAgICBbb3JkZXJlZF0sXG4gICk7XG4gIGNvbnN0IHBhbmVsRWxSZWYgPSB1c2VSZWY8SFRNTEVsZW1lbnQgfCBudWxsPihudWxsKTtcbiAgLy8gT25lIFNDUk9MTCBwZXIgZ2VzdHVyZSAodGhlIG5vbmNlKSwgYnV0IHRoZSBwb2xsIHJlLWFybXMgb24gYSByb290cyBjaGFuZ2VcbiAgLy8gdW50aWwgdGhlIHJvdyBleGlzdHM6IGEgcmV2ZWFsIHRoYXQgbGFuZGVkIGR1cmluZyBib290IGV4cGFuZHMgdmlhIHRoZVxuICAvLyBpZGVtcG90ZW50IHJldHJ5IGFuZCBzdGlsbCBzY3JvbGxzIG9uY2UgdGhlIHRyZWUgY2FuIHNob3cgaXQuIEEgcGF0aCB0aGF0XG4gIC8vIGlzIG5ldmVyIGluIHRoZSB0cmVlIGdpdmVzIHVwIHBlciByb3VuZCBhbmQgc3RheXMgcHV0LlxuICBjb25zdCBzY3JvbGxlZFJldmVhbE5vbmNlUmVmID0gdXNlUmVmPG51bWJlciB8IG51bGw+KG51bGwpO1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghcmV2ZWFsKSByZXR1cm47XG4gICAgc3RvcmUucmV2ZWFsUGF0aChyZXZlYWwucGF0aCk7XG4gICAgaWYgKHNjcm9sbGVkUmV2ZWFsTm9uY2VSZWYuY3VycmVudCA9PT0gcmV2ZWFsLm5vbmNlKSByZXR1cm47XG4gICAgbGV0IHRyaWVzID0gMDtcbiAgICBjb25zdCB0aW1lciA9IHNldEludGVydmFsKCgpID0+IHtcbiAgICAgIGNvbnN0IGVsID0gcGFuZWxFbFJlZi5jdXJyZW50Py5xdWVyeVNlbGVjdG9yKFwiLnRub2RlLS12aWV3ZWRcIik7XG4gICAgICBpZiAoZWwpIHtcbiAgICAgICAgZWwuc2Nyb2xsSW50b1ZpZXcoeyBibG9jazogXCJuZWFyZXN0XCIgfSk7XG4gICAgICAgIHNjcm9sbGVkUmV2ZWFsTm9uY2VSZWYuY3VycmVudCA9IHJldmVhbC5ub25jZTtcbiAgICAgICAgY2xlYXJJbnRlcnZhbCh0aW1lcik7XG4gICAgICB9IGVsc2UgaWYgKCsrdHJpZXMgPiAxNikge1xuICAgICAgICBjbGVhckludGVydmFsKHRpbWVyKTsgLy8gbm8gcm93cyB0aGlzIHJvdW5kIOKAlCBhIHJvb3RzIGNoYW5nZSByZS1hcm1zXG4gICAgICB9XG4gICAgfSwgMTUwKTtcbiAgICByZXR1cm4gKCkgPT4gY2xlYXJJbnRlcnZhbCh0aW1lcik7XG4gIH0sIFtyZXZlYWwsIHN0b3JlLCByb290S2V5XSk7XG5cbiAgLy8gUmV2ZWFsIHRoZSBFRElUT1IncyBhY3RpdmUgZmlsZSAoRlgtNGIpLiBEaXN0aW5jdCBmcm9tIHRoZSBzdGFnZSBoaW50IGFib3ZlIGluXG4gIC8vIGJvdGggdHJ1c3QgYW5kIGludGVudDogYGFjdGl2ZUZpbGVgIHJpZGVzIHRoZSBlbGV2YXRlZCBgZWRpdG9yLWNvbnRleHRgIHB1c2hcbiAgLy8gZnJvbSB0aGUgaG9zdCwgYW5kIGl0IGNoYW5nZXMgb25seSB0aHJvdWdoIGEgR0FURUQgaG9zdCBpbnRlbnQg4oCUIGBlZGl0b3I6b3BlbmBcbiAgLy8gKHRoZSBjcm9zcy1hcHAgXCJvcGVuIHRoaXMgZmlsZVwiIHRoZSBleHBsb3JlciBpdHNlbGYgdXNlcykgb3IgYGVkaXRvcjpkb2N1bWVudGBcbiAgLy8gYHNldEFjdGl2ZWAgKHRoZSBlZGl0b3IncyBvd24gc2Vzc2lvbikg4oCUIHNvIGZvbGxvd2luZyBpdCBpcyBub3QgdGhlIHVudHJ1c3RlZCxcbiAgLy8gYWN0aXZhdGlvbi1mcmVlIGhpZ2hsaWdodCB0aGUgUjMtMjY4IGNvbnRyYWN0IGdvdmVybnMuXG4gIC8vXG4gIC8vIFRoaXMgdXNlZCB0byBzYXkgYGFjdGl2ZUZpbGVgIFwib25seSBldmVyIGNoYW5nZXMgYmVjYXVzZSBhIHVzZXIgb3BlbmVkIHRoYXRcbiAgLy8gZmlsZVwiLiBUaGF0IHdhcyBhbHJlYWR5IHN0cmFpbmVkIOKAlCBgc2V0QWN0aXZlYCBpcyBwcm9ncmFtbWF0aWMg4oCUIGFuZCBSMy0zODhcbiAgLy8gZmFsc2lmaWVkIGl0IG91dHJpZ2h0IGJ5IGFkZGluZyBhIHNlY29uZCBgZWRpdG9yOm9wZW5gIGhvbGRlciB3aG9zZSBjYWxscyBmaXJlIG9uXG4gIC8vIGEgcnVuIGNvbXBsZXRpbmcgYW5kIG9uIEVudGVyIGluIGEgbGlzdCwgbm90IG9ubHkgb24gYSBjbGljay4gVGhlIGludmFyaWFudCB0aGF0XG4gIC8vIGFjdHVhbGx5IGhvbGRzIGlzIHRoZSBvbmUgYWJvdmU6IG5vdCBcImEgaHVtYW4gY2xpY2tlZFwiLCBidXQgXCJhIGZyYW1lIHRoZSBob3N0XG4gIC8vIGdhdGVkIGRpZCB0aGlzXCIsIG9mIHdoaWNoIHRoZXJlIGFyZSBub3cgc2V2ZXJhbC4gRm9sbG93aW5nIGl0IGlzIHNhZmUgYmVjYXVzZSB0aGVcbiAgLy8gR0FURSBpcyB0aGUgY2hlY2ssIG5vdCBiZWNhdXNlIGEgaHVtYW4gd2FzIGFzc3VtZWQuIFdpdGhvdXQgdGhpc1xuICAvLyB0aGUgdmVyeSBmaXJzdCB0aGluZyBhbiBlZGl0LW1vZGUgc2Vzc2lvbiBzaG93cyBpcyBhbiBlbnRyeXBvaW50IGRlZXAgdW5kZXIgYVxuICAvLyBDT0xMQVBTRUQgZm9sZGVyLCB3aXRoIG5vdGhpbmcgaW4gdGhlIHRyZWUgc2F5aW5nIHdoaWNoIGZpbGUgdGhhdCBpcy5cbiAgLy8gRXhwYW5kLW9ubHkgKGEgZm9sZGVyIHRoZSB1c2VyIGNsb3NlZCBpcyBuZXZlciByZS1vcGVuZWQpICsgYHNjcm9sbEludG9WaWV3YDtcbiAgLy8gZm9jdXMgbmV2ZXIgbW92ZXMuIENoaWxkcmVuIGxvYWQgbGF6aWx5IG9uIGV4cGFuZCwgc28gcG9sbCBicmllZmx5IGZvciB0aGUgcm93XG4gIC8vIGFuZCBnaXZlIHVwIHF1aWV0bHkgd2hlbiB0aGUgcGF0aCBpc24ndCBpbiB0aGlzIHRyZWUuXG4gIC8vIGByb290S2V5YCBpcyBpbiB0aGUgZGVwcyBiZWNhdXNlIHRoZSB0d28gaW5wdXRzIFJBQ0U6IHRoZSBlZGl0b3IncyBhY3RpdmUgZmlsZVxuICAvLyByb3V0aW5lbHkgbGFuZHMgYmVmb3JlIHRoZSBtb3VudHMgZG8sIGFuZCBgcmV2ZWFsUGF0aGAgY2FuIG9ubHkgZXhwYW5kIHVuZGVyXG4gIC8vIHJvb3RzIHRoZSBzdG9yZSBhbHJlYWR5IGtub3dzIOKAlCBhIHJldmVhbCBhZ2FpbnN0IGFuIGVtcHR5IHJvb3Qgc2V0IGlzIHNpbGVudGx5XG4gIC8vIGluZXJ0LCBhbmQgYGFjdGl2ZVBhdGhgIGFsb25lIHdvdWxkIG5ldmVyIGZpcmUgYWdhaW4gdG8gcmV0cnkgaXQuXG4gIC8vIChEZWNsYXJlZCBhYm92ZSwgc2hhcmVkIHdpdGggdGhlIGdlc3R1cmUtcmV2ZWFsIGVmZmVjdC4pXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFhY3RpdmVQYXRoKSByZXR1cm47XG4gICAgc3RvcmUucmV2ZWFsUGF0aChhY3RpdmVQYXRoKTtcbiAgICBsZXQgdHJpZXMgPSAwO1xuICAgIGNvbnN0IHRpbWVyID0gc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICAgICAgY29uc3QgZWwgPSBwYW5lbEVsUmVmLmN1cnJlbnQ/LnF1ZXJ5U2VsZWN0b3IoXCIudG5vZGUtLWFjdGl2ZVwiKTtcbiAgICAgIGlmIChlbCkge1xuICAgICAgICBlbC5zY3JvbGxJbnRvVmlldyh7IGJsb2NrOiBcIm5lYXJlc3RcIiB9KTtcbiAgICAgICAgY2xlYXJJbnRlcnZhbCh0aW1lcik7XG4gICAgICB9IGVsc2UgaWYgKCsrdHJpZXMgPiAxNikge1xuICAgICAgICBjbGVhckludGVydmFsKHRpbWVyKTsgLy8gcm93cyBuZXZlciBhcHBlYXJlZCAocGF0aCBub3QgaW4gdGhpcyB0cmVlKSDigJQgc3RheSBwdXRcbiAgICAgIH1cbiAgICB9LCAxNTApO1xuICAgIHJldHVybiAoKSA9PiBjbGVhckludGVydmFsKHRpbWVyKTtcbiAgfSwgW2FjdGl2ZVBhdGgsIHJvb3RLZXksIHN0b3JlXSk7XG5cbiAgLy8gVGhlIG11bHRpLXNlbGVjdCBTRVQsIHN1YnNjcmliZWQgdmlhIHRoZSBzdG9yZSdzIFNUQUJMRSBzbmFwc2hvdCAoaWRlbnRpdHlcbiAgLy8gY2hhbmdlcyBvbmx5IG9uIGEgcmVhbCBtdXRhdGlvbiDigJQgc2VlIGBnZXRTZWxlY3Rpb25gKSwgc28gdGhpcyBkb2Vzbid0IHRlYXIuXG4gIC8vIE9uIGVhY2ggY2hhbmdlLCByZXBvcnQgdGhlIG1vdW50LXJlbGF0aXZlIHBhdGhzIG9mIHRoZSBzZXQgdG8gYSBiYXRjaCBjb25zdW1lclxuICAvLyB2aWEgYG9uU2VsZWN0aW9uQ2hhbmdlYCwgcmVzb2x2aW5nIHRoZSBvd25pbmcgcm9vdCAoc2luZ2xlLXBhbmVsIGNvbnN1bWVycyBrZWVwXG4gIC8vIHRoZSBzZXQgd2l0aGluIG9uZSByb290KS4gUnVucyBvbmx5IHVuZGVyIGBzZWxlY3Rpb25Nb2RlID09PSBcIm11bHRpXCJgLlxuICBjb25zdCBzZWxlY3Rpb25TZXQgPSB1c2VTeW5jRXh0ZXJuYWxTdG9yZShcbiAgICBzdG9yZS5zdWJzY3JpYmUsXG4gICAgc3RvcmUuZ2V0U2VsZWN0aW9uLFxuICApO1xuICBjb25zdCBwcmV2U2VsZWN0aW9uUmVmID0gdXNlUmVmKHNlbGVjdGlvblNldCk7XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgLy8gU2tpcCB0aGUgbW91bnQtdGltZSBydW4gKG5vIGNoYW5nZSB5ZXQpIHNvIHdlIGRvbid0IGVtaXQgYSBzcHVyaW91cyBlbXB0eSBzZXQuXG4gICAgY29uc3QgY2hhbmdlZCA9IHByZXZTZWxlY3Rpb25SZWYuY3VycmVudCAhPT0gc2VsZWN0aW9uU2V0O1xuICAgIHByZXZTZWxlY3Rpb25SZWYuY3VycmVudCA9IHNlbGVjdGlvblNldDtcbiAgICBpZiAoIWNoYW5nZWQpIHJldHVybjtcbiAgICBpZiAoc2VsZWN0aW9uTW9kZSAhPT0gXCJtdWx0aVwiIHx8ICFvblNlbGVjdGlvbkNoYW5nZSkgcmV0dXJuO1xuICAgIGNvbnN0IHJvb3QgPSBzZWxlY3Rpb25TZXQubGVuZ3RoID8gcm9vdEJ5UGF0aChzZWxlY3Rpb25TZXRbMF0pIDogbnVsbDtcbiAgICBjb25zdCBvd25lciA9IHJvb3QgPz8gb3JkZXJlZFswXSA/PyBudWxsO1xuICAgIGlmICghb3duZXIpIHJldHVybjtcbiAgICBvblNlbGVjdGlvbkNoYW5nZShcbiAgICAgIG93bmVyLFxuICAgICAgc2VsZWN0aW9uU2V0Lm1hcCgoYWJzKSA9PiB0b01vdW50UmVsKG93bmVyLnBhdGgsIGFicykpLFxuICAgICk7XG4gIH0sIFtzZWxlY3Rpb25TZXQsIHNlbGVjdGlvbk1vZGUsIG9uU2VsZWN0aW9uQ2hhbmdlLCByb290QnlQYXRoLCBvcmRlcmVkXSk7XG5cbiAgLy8gS2VlcCB0aGUgZmxhdC1sYXlvdXQgY3Vyc29ycyB2YWxpZCBhcyByb290cyBjb21lIGFuZCBnbyDigJQgZGVyaXZlLCBkb24ndCBzdG9yZS5cbiAgLy8gV2hlbiBgY3dkYCBpcyBjb250cm9sbGVkIChwcm9wIGAhPT0gdW5kZWZpbmVkYCkgaXQgV0lOUyBvdmVyIGludGVybmFsIHN0YXRlOyBhXG4gIC8vIG5hdmlnYXRpb24gb25seSBmaXJlcyBgb25OYXZpZ2F0ZWAgKGJlbG93KSBhbmQgdGhlIGNvbnN1bWVyIGZlZWRzIHRoZSBuZXcgY3dkXG4gIC8vIGJhY2suIFdoZW4gdW5jb250cm9sbGVkLCB0aGUgaW50ZXJuYWwgc3RhdGUgZHJpdmVzIGl0ICh0b2RheSdzIGJlaGF2aW9yKS4gRWl0aGVyXG4gIC8vIHdheSB0aGUgdmFsdWUgaXMgdmFsaWRhdGVkIGFnYWluc3QgdGhlIGxpdmUgcm9vdHMgc28gYSBzdGFsZSBwYXRoIGNhbid0IGxpbmdlci5cbiAgY29uc3QgY29udHJvbGxlZEN3ZCA9IGN3ZFByb3AgIT09IHVuZGVmaW5lZDtcbiAgY29uc3Qgc291cmNlQ3dkID0gY29udHJvbGxlZEN3ZCA/IGN3ZFByb3AgOiBjd2Q7XG4gIGNvbnN0IGVmZkN3ZCA9XG4gICAgc291cmNlQ3dkICYmXG4gICAgb3JkZXJlZC5zb21lKFxuICAgICAgKG0pID0+IHNvdXJjZUN3ZCA9PT0gbS5wYXRoIHx8IHNvdXJjZUN3ZC5zdGFydHNXaXRoKG0ucGF0aCArIFwiL1wiKSxcbiAgICApXG4gICAgICA/IHNvdXJjZUN3ZFxuICAgICAgOiBudWxsO1xuICBjb25zdCBlZmZDb2xQYXRoID1cbiAgICBjb2xQYXRoLmxlbmd0aCAmJiBvcmRlcmVkLnNvbWUoKG0pID0+IG0ucGF0aCA9PT0gY29sUGF0aFswXSkgPyBjb2xQYXRoIDogW107XG5cbiAgLy8gTmF2aWdhdGUgdGhlIGZsYXQgKGxpc3QvaWNvbnMpIGxheW91dCdzIGJyb3dzZWQgZGlyZWN0b3J5LCBhbmQgcmVwb3J0IGl0IHRvIGFcbiAgLy8gY29uc3VtZXIgdmlhIGBvbk5hdmlnYXRlYCAodGhlIGV4dGVuc2lvbiBwb2ludCBmaWxlLWNvbW1hbmRlciB1c2VzIHRvIHRyYWNrIGFcbiAgLy8gcGFuZWwncyBjdXJyZW50IGRpcmVjdG9yeSDigJQgdGhlIGNvcHkvbW92ZSBkZXN0aW5hdGlvbikuIEEgYG51bGxgIGN3ZCBpcyB0aGVcbiAgLy8gc3ludGhldGljIHJvb3RzLXJvb3QgKG5vIHNpbmdsZSBkaXJlY3RvcnkpIGFuZCBpcyBub3QgcmVwb3J0ZWQuIEVudGVyaW5nIGFcbiAgLy8gZGlyZWN0b3J5IGFsc28gU0VMRUNUUyBpdCAoRklMRV9FWFBMT1JFUl9TUEVDIMKnNSk6IGluIGEgZmxhdCBsYXlvdXQgdGhlXG4gIC8vIGJyb3dzZWQgZm9sZGVyIGlzIHRoZSB1cGxvYWQgYnV0dG9uJ3MgZGVzdGluYXRpb24uIEdhdGVkIG9uXG4gIC8vIGBzZWxlY3Rpb25Nb2RlICE9PSBcIm5vbmVcImAgZXhhY3RseSBsaWtlIHRoZSB0cmVlJ3MgYWN0aXZhdGlvbiBwYXRoLCBzbyBhXG4gIC8vIGNvbnN1bWVyIHRoYXQgZGlzYWJsZWQgc2VsZWN0aW9uIG5ldmVyIGdldHMgc2VsZWN0aW9uIHdyaXRlcyBmcm9tXG4gIC8vIG5hdmlnYXRpb24gKGl0cyB1cGxvYWQgZGVzdGluYXRpb24gc3RheXMgdGhlIHJlcG8gcm9vdCkuXG4gIGNvbnN0IG5hdmlnYXRlQ3dkID0gdXNlQ2FsbGJhY2soXG4gICAgKHBhdGg6IHN0cmluZyB8IG51bGwpID0+IHtcbiAgICAgIC8vIENvbnRyb2xsZWQ6IGRvbid0IHRvdWNoIGludGVybmFsIHN0YXRlIOKAlCBqdXN0IHJlcG9ydDsgdGhlIGNvbnN1bWVyIHVwZGF0ZXNcbiAgICAgIC8vIGl0cyBvd24gYGN3ZGAgYW5kIHBhc3NlcyBpdCBiYWNrLiBVbmNvbnRyb2xsZWQ6IHNldCBpbnRlcm5hbCArIHJlcG9ydCAodG9kYXkpLlxuICAgICAgaWYgKCFjb250cm9sbGVkQ3dkKSBzZXRDd2QocGF0aCk7XG4gICAgICBpZiAocGF0aCkge1xuICAgICAgICBpZiAoc2VsZWN0aW9uTW9kZSAhPT0gXCJub25lXCIpIHN0b3JlLnNlbGVjdChwYXRoLCB0cnVlKTtcbiAgICAgICAgY29uc3Qgcm9vdCA9IHJvb3RCeVBhdGgocGF0aCk7XG4gICAgICAgIGlmIChyb290KSBvbk5hdmlnYXRlPy4ocm9vdCwgdG9Nb3VudFJlbChyb290LnBhdGgsIHBhdGgpKTtcbiAgICAgIH1cbiAgICB9LFxuICAgIFtzdG9yZSwgcm9vdEJ5UGF0aCwgb25OYXZpZ2F0ZSwgY29udHJvbGxlZEN3ZCwgc2VsZWN0aW9uTW9kZV0sXG4gICk7XG4gIC8vIFRoZSBNaWxsZXItY29sdW1ucyBhbmFsb2c6IHRoZSBmb2N1c2VkIGNvbHVtbiBpcyB0aGUgZGVlcGVzdCBwYXRoIHNlZ21lbnQuXG4gIC8vIExpa2UgYG5hdmlnYXRlQ3dkYCwgdGhlIGRlZXBlc3QgY29sdW1uIGlzIHNlbGVjdGVkIOKAlCBpdCBpcyB0aGUgbGF5b3V0J3NcbiAgLy8gXCJjdXJyZW50IGRpcmVjdG9yeVwiIGFuZCB0aGUgdXBsb2FkIGJ1dHRvbidzIGRlc3RpbmF0aW9uIOKAlCB1bmRlciB0aGUgc2FtZVxuICAvLyBgc2VsZWN0aW9uTW9kZWAgZ2F0ZS5cbiAgY29uc3QgbmF2aWdhdGVDb2xzID0gdXNlQ2FsbGJhY2soXG4gICAgKHBhdGg6IHN0cmluZ1tdKSA9PiB7XG4gICAgICBzZXRDb2xQYXRoKHBhdGgpO1xuICAgICAgY29uc3QgbGFzdCA9IHBhdGhbcGF0aC5sZW5ndGggLSAxXTtcbiAgICAgIGlmIChsYXN0KSB7XG4gICAgICAgIGlmIChzZWxlY3Rpb25Nb2RlICE9PSBcIm5vbmVcIikgc3RvcmUuc2VsZWN0KGxhc3QsIHRydWUpO1xuICAgICAgICBjb25zdCByb290ID0gcm9vdEJ5UGF0aChsYXN0KTtcbiAgICAgICAgaWYgKHJvb3QpIG9uTmF2aWdhdGU/Lihyb290LCB0b01vdW50UmVsKHJvb3QucGF0aCwgbGFzdCkpO1xuICAgICAgfVxuICAgIH0sXG4gICAgW3N0b3JlLCByb290QnlQYXRoLCBvbk5hdmlnYXRlLCBzZWxlY3Rpb25Nb2RlXSxcbiAgKTtcblxuICAvLyBTd2l0Y2hpbmcgbGF5b3V0IHNlZWRzIHRoZSBuZXcgdmlldyBmcm9tIHRoZSBjdXJyZW50IHNlbGVjdGlvbiBzbyB0aGUgc2VsZWN0ZWRcbiAgLy8gZmlsZSBzdGF5cyBpbiB2aWV3IChhY2NlcHRhbmNlOiBzZWxlY3Rpb24gc3Vydml2ZXMgYSBzd2l0Y2gpLlxuICBjb25zdCBjaG9vc2VMYXlvdXQgPSB1c2VDYWxsYmFjayhcbiAgICAobmV4dDogTGF5b3V0KSA9PiB7XG4gICAgICBpZiAobmV4dCAhPT0gbGF5b3V0KSB7XG4gICAgICAgIGNvbnN0IHNlbCA9IHN0b3JlLmdldFNlbGVjdGVkKCk7XG4gICAgICAgIGlmIChuZXh0ID09PSBcImxpc3RcIiB8fCBuZXh0ID09PSBcImljb25zXCIpIHtcbiAgICAgICAgICBzZXRDd2QoXG4gICAgICAgICAgICBzZWwgPyBkaXJPZihzZWwpIDogb3JkZXJlZC5sZW5ndGggPT09IDEgPyBvcmRlcmVkWzBdLnBhdGggOiBudWxsLFxuICAgICAgICAgICk7XG4gICAgICAgIH0gZWxzZSBpZiAobmV4dCA9PT0gXCJjb2x1bW5zXCIpIHtcbiAgICAgICAgICBjb25zdCBtb3VudCA9IHNlbFxuICAgICAgICAgICAgPyBvcmRlcmVkLmZpbmQoXG4gICAgICAgICAgICAgICAgKG0pID0+IHNlbCA9PT0gbS5wYXRoIHx8IHNlbC5zdGFydHNXaXRoKG0ucGF0aCArIFwiL1wiKSxcbiAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgOiBvcmRlcmVkLmxlbmd0aCA9PT0gMVxuICAgICAgICAgICAgICA/IG9yZGVyZWRbMF1cbiAgICAgICAgICAgICAgOiB1bmRlZmluZWQ7XG4gICAgICAgICAgaWYgKCFtb3VudCkgc2V0Q29sUGF0aChbXSk7XG4gICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBjb25zdCBwYXRoID0gW21vdW50LnBhdGhdO1xuICAgICAgICAgICAgY29uc3Qgc2VncyA9IHRvTW91bnRSZWwobW91bnQucGF0aCwgc2VsID8gZGlyT2Yoc2VsKSA6IG1vdW50LnBhdGgpXG4gICAgICAgICAgICAgIC5zcGxpdChcIi9cIilcbiAgICAgICAgICAgICAgLmZpbHRlcihCb29sZWFuKTtcbiAgICAgICAgICAgIGxldCBhY2MgPSBtb3VudC5wYXRoO1xuICAgICAgICAgICAgZm9yIChjb25zdCBzIG9mIHNlZ3MpIHtcbiAgICAgICAgICAgICAgYWNjID0gam9pblBhdGgoYWNjLCBzKTtcbiAgICAgICAgICAgICAgcGF0aC5wdXNoKGFjYyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBzZXRDb2xQYXRoKHBhdGgpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgc2V0TGF5b3V0KG5leHQpO1xuICAgIH0sXG4gICAgW2xheW91dCwgb3JkZXJlZCwgc3RvcmUsIHNldExheW91dF0sXG4gICk7XG5cbiAgLy8gVGhlIG9wdGltaXN0aWMgd3JpdGUgZmxvdyAoUi1JWC0zL1ItSVgtNCk6IGV2ZXJ5IHdyaXRlIHJlbmRlcnMgaXRzIG93blxuICAvLyByZXN1bHQg4oCUIHBlbmRpbmcgcm93IGZpcnN0LCB0aGUgYWN0aW9uJ3MgcmV0dXJuIHNldHRsZXMgaXQsIG9uZSBuYXJyb3dcbiAgLy8gcmVmZXRjaCBmb3IgYXV0aG9yaXR5IOKAlCBhbmQgYW5ub3VuY2VzIGJvdGggaGFsdmVzIChSLUlYLTcpLlxuICBjb25zdCB3cml0ZVBvcnRzID0gdXNlTWVtbzxXcml0ZVBvcnRzPihcbiAgICAoKSA9PiAoe1xuICAgICAgc3RvcmUsXG4gICAgICBhY3Rpb25zOiBhY3Rpb25zID8/ICh7fSBhcyBFeHBsb3JlckFjdGlvbnMpLFxuICAgICAgYW5ub3VuY2U6IGFubm91bmNlTWVzc2FnZSxcbiAgICAgIGZhaWw6IChtZXNzYWdlOiBzdHJpbmcpID0+IHNldEVycm9yKG1lc3NhZ2UpLFxuICAgICAgYmVnaW46ICgpID0+IHNldEVycm9yKG51bGwpLFxuICAgIH0pLFxuICAgIFtzdG9yZSwgYWN0aW9uc10sXG4gICk7XG5cbiAgLy8gLS0tIHN0YWJsZSBub2RlIGhhbmRsZXJzIChzbyB0aGUgbWVtb2l6ZWQgdHJlZSBkb2Vzbid0IHJlLXJlbmRlcikgLS0tXG4gIC8vIE9wZW4gaXMgZGlzcGF0Y2hlZCB3aGVyZSB0aGUgb3duaW5nIHJvb3QgaXMga25vd24gKG9uQWN0aXZhdGUgLyB0aGUgbWVudSk7IGl0XG4gIC8vIGNhbGxzIG9uQWN0aXZhdGUgdGhlbiBhY3Rpb25zLm9wZW4gd2l0aCB0aGUgbW91bnQtcmVsYXRpdmUgcGF0aC5cbiAgY29uc3QgZGlzcGF0Y2hPcGVuID0gdXNlQ2FsbGJhY2soXG4gICAgKHJvb3Q6IEV4cGxvcmVyUm9vdCwgbW91bnRSZWw6IHN0cmluZykgPT4ge1xuICAgICAgc2V0RXJyb3IobnVsbCk7XG4gICAgICBvbkFjdGl2YXRlPy4ocm9vdCwgbW91bnRSZWwsIGZhbHNlKTtcbiAgICAgIGlmICghYWN0aW9ucz8ub3BlbikgcmV0dXJuO1xuICAgICAgdHJ5IHtcbiAgICAgICAgYWN0aW9ucy5vcGVuKHJvb3QsIG1vdW50UmVsKTtcbiAgICAgIH0gY2F0Y2gge1xuICAgICAgICBzZXRFcnJvcihcIkNvdWxkbuKAmXQgb3BlbiB0aGF0IGZpbGUuXCIpO1xuICAgICAgfVxuICAgIH0sXG4gICAgW2FjdGlvbnMsIG9uQWN0aXZhdGVdLFxuICApO1xuXG4gIGNvbnN0IGhhbmRsZUFjdGl2YXRlID0gdXNlQ2FsbGJhY2soXG4gICAgKGFic1BhdGg6IHN0cmluZywgaXNEaXI6IGJvb2xlYW4pID0+IHtcbiAgICAgIGNvbnN0IHJvb3QgPSByb290QnlQYXRoKGFic1BhdGgpO1xuICAgICAgaWYgKGlzRGlyKSB7XG4gICAgICAgIHN0b3JlLnRvZ2dsZShhYnNQYXRoKTtcbiAgICAgICAgLy8gQSBjbGlja2VkIGZvbGRlciBpcyBhbHNvIFNFTEVDVEVEIChub3QganVzdCBleHBhbmRlZCk6IHRoZSBzZWxlY3RlZFxuICAgICAgICAvLyBkaXJlY3RvcnkgaXMgdGhlIHVwbG9hZCBidXR0b24ncyBkZXN0aW5hdGlvbiAoRklMRV9FWFBMT1JFUl9TUEVDIMKnNSkuXG4gICAgICAgIGlmIChzZWxlY3Rpb25Nb2RlICE9PSBcIm5vbmVcIikgc3RvcmUuc2VsZWN0KGFic1BhdGgsIHRydWUpO1xuICAgICAgICBpZiAocm9vdCkgb25BY3RpdmF0ZT8uKHJvb3QsIHRvTW91bnRSZWwocm9vdC5wYXRoLCBhYnNQYXRoKSwgdHJ1ZSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBpZiAoc2VsZWN0aW9uTW9kZSAhPT0gXCJub25lXCIpIHN0b3JlLnNlbGVjdChhYnNQYXRoLCBmYWxzZSk7XG4gICAgICAgIGlmICghcm9vdCkgcmV0dXJuOyAvLyBhIHJvdyBhbHdheXMgYmVsb25ncyB0byBhIHJlbmRlcmVkIHJvb3RcbiAgICAgICAgY29uc3QgcmVsID0gdG9Nb3VudFJlbChyb290LnBhdGgsIGFic1BhdGgpO1xuICAgICAgICBvblNlbGVjdD8uKHJvb3QsIHJlbCk7XG4gICAgICAgIGRpc3BhdGNoT3Blbihyb290LCByZWwpO1xuICAgICAgfVxuICAgIH0sXG4gICAgW3N0b3JlLCByb290QnlQYXRoLCBvbkFjdGl2YXRlLCBvblNlbGVjdCwgZGlzcGF0Y2hPcGVuLCBzZWxlY3Rpb25Nb2RlXSxcbiAgKTtcblxuICBjb25zdCBvbk1vdmVEcm9wID0gdXNlQ2FsbGJhY2soXG4gICAgKFxuICAgICAgZnJvbUFiczogc3RyaW5nLFxuICAgICAgZnJvbVJvb3Q6IHN0cmluZyxcbiAgICAgIGZyb21Jc0RpcjogYm9vbGVhbixcbiAgICAgIHRhcmdldERpcjogc3RyaW5nLFxuICAgICAgdGFyZ2V0Um9vdDogc3RyaW5nLFxuICAgICkgPT4ge1xuICAgICAgaWYgKCFhY3Rpb25zPy5yZW5hbWUpIHJldHVybjtcbiAgICAgIGNvbnN0IHJlYXNvbiA9IG1vdmVSZWplY3Rpb24oZnJvbUFicywgdGFyZ2V0RGlyLCBmcm9tUm9vdCwgdGFyZ2V0Um9vdCk7XG4gICAgICBpZiAocmVhc29uKSB7XG4gICAgICAgIGlmIChyZWFzb24gPT09IFwiY3Jvc3MtbW91bnRcIikgc2V0RXJyb3IoV1JJVEVfRVJSW1wiY3Jvc3MtbW91bnRcIl0pO1xuICAgICAgICByZXR1cm47IC8vIHNhbWUtZGlyIC8gaW50by1zZWxmOiBzaWxlbnQgbm8tb3BcbiAgICAgIH1cbiAgICAgIGNvbnN0IHJvb3QgPSByb290QnlQYXRoKHRhcmdldERpcik7XG4gICAgICBpZiAoIXJvb3QpIHJldHVybjtcbiAgICAgIGNvbnN0IHRvID0gdG9Nb3VudFJlbCh0YXJnZXRSb290LCBqb2luUGF0aCh0YXJnZXREaXIsIGJhc2VuYW1lKGZyb21BYnMpKSk7XG4gICAgICAvLyBUaGUgbW92ZWQgcm93J3Mgb3duIGVudHJ5LCBmcm9tIHRoZSBzdG9yZSB0aGF0IHJlbmRlcmVkIGl0IChmYWxsaW5nXG4gICAgICAvLyBiYWNrIHRvIHRoZSBkcmFnIHBheWxvYWQncyBmYWN0cyBvbmx5IGlmIHRoZSBsaXN0aW5nIGFscmVhZHkgd2VudCkuXG4gICAgICBjb25zdCBlbnRyeSA9XG4gICAgICAgIHN0b3JlLmdldEVudHJpZXMoZGlyT2YoZnJvbUFicykpPy5maW5kKChlbikgPT4gZW4ubmFtZSA9PT0gYmFzZW5hbWUoZnJvbUFicykpID8/XG4gICAgICAgIHsgbmFtZTogYmFzZW5hbWUoZnJvbUFicyksIGlzRGlyOiBmcm9tSXNEaXIgfTtcbiAgICAgIHJ1blJlbmFtZSh3cml0ZVBvcnRzLCByb290LCBmcm9tQWJzLCBlbnRyeSwgdG8pO1xuICAgIH0sXG4gICAgW2FjdGlvbnMsIHdyaXRlUG9ydHMsIHJvb3RCeVBhdGgsIHN0b3JlXSxcbiAgKTtcblxuICBjb25zdCBvblVwbG9hZERyb3AgPSB1c2VDYWxsYmFjayhcbiAgICAoZmlsZXM6IEZpbGVbXSwgdGFyZ2V0RGlyQWJzOiBzdHJpbmcsIHdyaXRhYmxlOiBib29sZWFuKSA9PiB7XG4gICAgICBpZiAoIWFjdGlvbnM/LnVwbG9hZCB8fCAhd3JpdGFibGUgfHwgIWZpbGVzLmxlbmd0aCkgcmV0dXJuO1xuICAgICAgY29uc3Qgcm9vdCA9IHJvb3RCeVBhdGgodGFyZ2V0RGlyQWJzKTtcbiAgICAgIGlmICghcm9vdCkgcmV0dXJuO1xuICAgICAgcnVuVXBsb2FkKHdyaXRlUG9ydHMsIHJvb3QsIHRhcmdldERpckFicywgdG9Nb3VudFJlbChyb290LnBhdGgsIHRhcmdldERpckFicyksIGZpbGVzKTtcbiAgICB9LFxuICAgIFthY3Rpb25zLCB3cml0ZVBvcnRzLCByb290QnlQYXRoXSxcbiAgKTtcblxuICBjb25zdCBiZWdpbkRyYWdPdXQgPSB1c2VDYWxsYmFjayhcbiAgICAoYWJzUGF0aDogc3RyaW5nLCBpc0RpcjogYm9vbGVhbikgPT4ge1xuICAgICAgaWYgKCFhY3Rpb25zPy5iZWdpbkRyYWdPdXQpIHJldHVybjtcbiAgICAgIGNvbnN0IHJvb3QgPSByb290QnlQYXRoKGFic1BhdGgpO1xuICAgICAgaWYgKCFyb290KSByZXR1cm47XG4gICAgICBhY3Rpb25zLmJlZ2luRHJhZ091dChyb290LCB0b01vdW50UmVsKHJvb3QucGF0aCwgYWJzUGF0aCksIGlzRGlyKTtcbiAgICB9LFxuICAgIFthY3Rpb25zLCByb290QnlQYXRoXSxcbiAgKTtcblxuICBjb25zdCBjYW5jZWxEcmFnT3V0ID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIGFjdGlvbnM/LmNhbmNlbERyYWdPdXQ/LigpO1xuICB9LCBbYWN0aW9uc10pO1xuXG4gIGNvbnN0IG9uRGVsZXRlID0gdXNlQ2FsbGJhY2soXG4gICAgKGFic1BhdGg6IHN0cmluZywgaXNEaXI6IGJvb2xlYW4sIHJvb3RQYXRoOiBzdHJpbmcpID0+IHtcbiAgICAgIGlmICghYWN0aW9ucz8uZGVsZXRlKSByZXR1cm47XG4gICAgICBjb25zdCByb290ID0gcm9vdEJ5UGF0aChhYnNQYXRoKTtcbiAgICAgIGlmICghcm9vdCkgcmV0dXJuO1xuICAgICAgY29uc3QgbW91bnRSZWwgPSB0b01vdW50UmVsKHJvb3RQYXRoLCBhYnNQYXRoKTtcbiAgICAgIGlmICghd2luZG93LmNvbmZpcm0oYERlbGV0ZSAke2lzRGlyID8gXCJmb2xkZXJcIiA6IFwiZmlsZVwifSAke21vdW50UmVsfT9gKSlcbiAgICAgICAgcmV0dXJuO1xuICAgICAgY29uc3QgZW50cnkgPVxuICAgICAgICBzdG9yZS5nZXRFbnRyaWVzKGRpck9mKGFic1BhdGgpKT8uZmluZCgoZW4pID0+IGVuLm5hbWUgPT09IGJhc2VuYW1lKGFic1BhdGgpKSA/P1xuICAgICAgICB7IG5hbWU6IGJhc2VuYW1lKGFic1BhdGgpLCBpc0RpciB9O1xuICAgICAgcnVuRGVsZXRlKHdyaXRlUG9ydHMsIHJvb3QsIGRpck9mKGFic1BhdGgpLCBlbnRyeSwgbW91bnRSZWwpO1xuICAgIH0sXG4gICAgW2FjdGlvbnMsIHdyaXRlUG9ydHMsIHJvb3RCeVBhdGgsIHN0b3JlXSxcbiAgKTtcblxuICAvLyAtLS0gY29udGV4dCBtZW51IGNvbnN0cnVjdGlvbiAoZ2F0ZWQgaXRlbXMgb25seSkgLS0tXG4gIGNvbnN0IG9wZW5NZW51ID0gdXNlQ2FsbGJhY2soXG4gICAgKGU6IHsgY2xpZW50WDogbnVtYmVyOyBjbGllbnRZOiBudW1iZXI7IGN1cnJlbnRUYXJnZXQ/OiBFdmVudFRhcmdldCB8IG51bGwgfSwgY3R4OiBSb3dDdHgpID0+IHtcbiAgICAgIC8vIFJlbWVtYmVyIHRoZSByb3cgdGhhdCBvcGVuZWQgdGhpcyBtZW51IOKAlCB0aGUgcHJvbXB0J3MgRXNjYXBlLWNhbmNlbFxuICAgICAgLy8gcmV0dXJucyBmb2N1cyBoZXJlLiBUb3VjaCBsb25nLXByZXNzIGhhcyBubyByb3cgZWxlbWVudCAobm90aGluZyBpc1xuICAgICAgLy8gZm9jdXNlZCksIHNvIGl0IGNsZWFycyB0byBudWxsIHJhdGhlciB0aGFuIGtlZXBpbmcgYSBzdGFsZSByb3cuXG4gICAgICBwcm9tcHRSZXR1cm5SZWYuY3VycmVudCA9XG4gICAgICAgIGUuY3VycmVudFRhcmdldCBpbnN0YW5jZW9mIEhUTUxFbGVtZW50ID8gZS5jdXJyZW50VGFyZ2V0IDogbnVsbDtcbiAgICAgIGNvbnN0IGl0ZW1zOiBNZW51SXRlbVtdID0gW107XG4gICAgICBjb25zdCByb290ID0gcm9vdEJ5UGF0aChjdHguYWJzUGF0aCk7XG4gICAgICBjb25zdCBtb3VudFJlbCA9IHRvTW91bnRSZWwoY3R4LnJvb3RQYXRoLCBjdHguYWJzUGF0aCk7XG4gICAgICBpZiAoIWN0eC5pc0RpciAmJiBhY3Rpb25zPy5vcGVuICYmIHJvb3QpIHtcbiAgICAgICAgaXRlbXMucHVzaCh7XG4gICAgICAgICAga2V5OiBcIm9wZW5cIixcbiAgICAgICAgICBsYWJlbDogXCJPcGVuXCIsXG4gICAgICAgICAgaWNvbjogPEV4dGVybmFsTGluayBzaXplPXsxNH0gLz4sXG4gICAgICAgICAgb25TZWxlY3Q6ICgpID0+IGRpc3BhdGNoT3Blbihyb290LCBtb3VudFJlbCksXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgICAgaWYgKGN0eC53cml0YWJsZSkge1xuICAgICAgICBjb25zdCBiYXNlRGlyID0gY3R4LmlzRGlyID8gY3R4LmFic1BhdGggOiBkaXJPZihjdHguYWJzUGF0aCk7XG4gICAgICAgIGlmIChhY3Rpb25zPy5jcmVhdGVGaWxlKSB7XG4gICAgICAgICAgaXRlbXMucHVzaCh7XG4gICAgICAgICAgICBrZXk6IFwibmV3LWZpbGVcIixcbiAgICAgICAgICAgIGxhYmVsOiBcIk5ldyBmaWxlIGhlcmVcIixcbiAgICAgICAgICAgIGljb246IDxGaWxlUGx1cyBzaXplPXsxNH0gLz4sXG4gICAgICAgICAgICBvblNlbGVjdDogKCkgPT4ge1xuICAgICAgICAgICAgICBzZXRQcm9tcHQoe1xuICAgICAgICAgICAgICAgIG1vZGU6IFwiY3JlYXRlLWZpbGVcIixcbiAgICAgICAgICAgICAgICBiYXNlRGlyLFxuICAgICAgICAgICAgICAgIHJvb3RQYXRoOiBjdHgucm9vdFBhdGgsXG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICBzZXRQcm9tcHRWYWx1ZShcIlwiKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGFjdGlvbnM/LmNyZWF0ZUZvbGRlcikge1xuICAgICAgICAgIGl0ZW1zLnB1c2goe1xuICAgICAgICAgICAga2V5OiBcIm5ldy1mb2xkZXJcIixcbiAgICAgICAgICAgIGxhYmVsOiBcIk5ldyBmb2xkZXIgaGVyZVwiLFxuICAgICAgICAgICAgaWNvbjogPEZvbGRlclBsdXMgc2l6ZT17MTR9IC8+LFxuICAgICAgICAgICAgb25TZWxlY3Q6ICgpID0+IHtcbiAgICAgICAgICAgICAgc2V0UHJvbXB0KHtcbiAgICAgICAgICAgICAgICBtb2RlOiBcImNyZWF0ZS1mb2xkZXJcIixcbiAgICAgICAgICAgICAgICBiYXNlRGlyLFxuICAgICAgICAgICAgICAgIHJvb3RQYXRoOiBjdHgucm9vdFBhdGgsXG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICBzZXRQcm9tcHRWYWx1ZShcIlwiKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGFjdGlvbnM/LnVwbG9hZCkge1xuICAgICAgICAgIGl0ZW1zLnB1c2goe1xuICAgICAgICAgICAga2V5OiBcInVwbG9hZFwiLFxuICAgICAgICAgICAgbGFiZWw6IFwiVXBsb2FkIGhlcmXigKZcIixcbiAgICAgICAgICAgIGljb246IDxVcGxvYWQgc2l6ZT17MTR9IC8+LFxuICAgICAgICAgICAgb25TZWxlY3Q6ICgpID0+IHtcbiAgICAgICAgICAgICAgdXBsb2FkVGFyZ2V0UmVmLmN1cnJlbnQgPSB7XG4gICAgICAgICAgICAgICAgZGlyOiB0b01vdW50UmVsKGN0eC5yb290UGF0aCwgYmFzZURpciksXG4gICAgICAgICAgICAgICAgcm9vdFBhdGg6IGN0eC5yb290UGF0aCxcbiAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgdXBsb2FkSW5wdXRSZWYuY3VycmVudD8uY2xpY2soKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFpc1Byb3RlY3RlZChtb3VudFJlbCkgJiYgY3R4LmFic1BhdGggIT09IGN0eC5yb290UGF0aCkge1xuICAgICAgICAgIGlmIChhY3Rpb25zPy5yZW5hbWUpIHtcbiAgICAgICAgICAgIC8vIFRoZSBub24tZHJhZyBtb3ZlIHBhdGggKFdDQUcgMi41LjcpOiBhIGRpcmVjdG9yeSBwaWNrZXIgdGhhdFxuICAgICAgICAgICAgLy8gY29tbWl0cyB0aHJvdWdoIHRoZSBTQU1FIG1vdmUgdGhlIGRyYWctZHJvcCB0YWtlcy5cbiAgICAgICAgICAgIGl0ZW1zLnB1c2goe1xuICAgICAgICAgICAgICBrZXk6IFwibW92ZS10b1wiLFxuICAgICAgICAgICAgICBsYWJlbDogXCJNb3ZlIHRv4oCmXCIsXG4gICAgICAgICAgICAgIGljb246IDxGb2xkZXJJbnB1dCBzaXplPXsxNH0gLz4sXG4gICAgICAgICAgICAgIG9uU2VsZWN0OiAoKSA9PlxuICAgICAgICAgICAgICAgIHNldE1vdmVUYXJnZXQoe1xuICAgICAgICAgICAgICAgICAgYWJzUGF0aDogY3R4LmFic1BhdGgsXG4gICAgICAgICAgICAgICAgICByb290UGF0aDogY3R4LnJvb3RQYXRoLFxuICAgICAgICAgICAgICAgICAgbmFtZTogYmFzZW5hbWUoY3R4LmFic1BhdGgpLFxuICAgICAgICAgICAgICAgICAgaXNEaXI6IGN0eC5pc0RpcixcbiAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgaXRlbXMucHVzaCh7XG4gICAgICAgICAgICAgIGtleTogXCJyZW5hbWVcIixcbiAgICAgICAgICAgICAgbGFiZWw6IFwiUmVuYW1l4oCmXCIsXG4gICAgICAgICAgICAgIGljb246IDxQZW5jaWwgc2l6ZT17MTR9IC8+LFxuICAgICAgICAgICAgICBvblNlbGVjdDogKCkgPT4ge1xuICAgICAgICAgICAgICAgIHNldFByb21wdCh7XG4gICAgICAgICAgICAgICAgICBtb2RlOiBcInJlbmFtZVwiLFxuICAgICAgICAgICAgICAgICAgdGFyZ2V0QWJzOiBjdHguYWJzUGF0aCxcbiAgICAgICAgICAgICAgICAgIHJvb3RQYXRoOiBjdHgucm9vdFBhdGgsXG4gICAgICAgICAgICAgICAgICBpbml0aWFsOiBiYXNlbmFtZShjdHguYWJzUGF0aCksXG4gICAgICAgICAgICAgICAgICBpc0RpcjogY3R4LmlzRGlyLFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIHNldFByb21wdFZhbHVlKGJhc2VuYW1lKGN0eC5hYnNQYXRoKSk7XG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKGFjdGlvbnM/LmRlbGV0ZSkge1xuICAgICAgICAgICAgaXRlbXMucHVzaCh7XG4gICAgICAgICAgICAgIGtleTogXCJkZWxldGVcIixcbiAgICAgICAgICAgICAgbGFiZWw6IFwiRGVsZXRlXCIsXG4gICAgICAgICAgICAgIGljb246IDxUcmFzaDIgc2l6ZT17MTR9IC8+LFxuICAgICAgICAgICAgICBkYW5nZXI6IHRydWUsXG4gICAgICAgICAgICAgIG9uU2VsZWN0OiAoKSA9PiBvbkRlbGV0ZShjdHguYWJzUGF0aCwgY3R4LmlzRGlyLCBjdHgucm9vdFBhdGgpLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICAvLyBDb25zdW1lciBleHRlbnNpb24gc2xvdCAoZS5nLiB0aGUgU0RLIGFkYXB0ZXIncyBcIlN1bW1hcml6ZeKAplwiKS5cbiAgICAgIGlmIChleHRyYU1lbnVJdGVtcykgaXRlbXMucHVzaCguLi5leHRyYU1lbnVJdGVtcyhjdHgpKTtcbiAgICAgIGlmICghaXRlbXMubGVuZ3RoKSByZXR1cm47XG4gICAgICBzZXRNZW51KHsgeDogZS5jbGllbnRYLCB5OiBlLmNsaWVudFksIGl0ZW1zLCBpbnZva2VyOiBwcm9tcHRSZXR1cm5SZWYuY3VycmVudCB9KTtcbiAgICB9LFxuICAgIFthY3Rpb25zLCByb290QnlQYXRoLCBkaXNwYXRjaE9wZW4sIG9uRGVsZXRlLCBleHRyYU1lbnVJdGVtc10sXG4gICk7XG5cbiAgY29uc3QgaGFuZGxlcnM6IE5vZGVIYW5kbGVycyA9IHVzZU1lbW8oXG4gICAgKCkgPT4gKHtcbiAgICAgIG9uQWN0aXZhdGU6IGhhbmRsZUFjdGl2YXRlLFxuICAgICAgb25NZW51OiBvcGVuTWVudSxcbiAgICAgIG9uTW92ZURyb3AsXG4gICAgICBvblVwbG9hZERyb3AsXG4gICAgICBiZWdpbkRyYWdPdXQ6IChhYnNQYXRoLCBpc0RpcikgPT4gYmVnaW5EcmFnT3V0KGFic1BhdGgsIGlzRGlyKSxcbiAgICAgIGNhbmNlbERyYWdPdXQsXG4gICAgICBvbkRlbGV0ZTogYWN0aW9ucz8uZGVsZXRlXG4gICAgICAgID8gb25EZWxldGVcbiAgICAgICAgOiAodW5kZWZpbmVkIGFzIHVua25vd24gYXMgTm9kZUhhbmRsZXJzW1wib25EZWxldGVcIl0pLFxuICAgIH0pLFxuICAgIFtcbiAgICAgIGhhbmRsZUFjdGl2YXRlLFxuICAgICAgb3Blbk1lbnUsXG4gICAgICBvbk1vdmVEcm9wLFxuICAgICAgb25VcGxvYWREcm9wLFxuICAgICAgYmVnaW5EcmFnT3V0LFxuICAgICAgY2FuY2VsRHJhZ091dCxcbiAgICAgIG9uRGVsZXRlLFxuICAgICAgYWN0aW9ucyxcbiAgICBdLFxuICApO1xuXG4gIGNvbnN0IHN1Ym1pdFByb21wdCA9ICgpID0+IHtcbiAgICBpZiAocHJvbXB0Q2FuY2VsbGluZ1JlZi5jdXJyZW50KSByZXR1cm47IC8vIGFuIEVzY2FwZS1jYW5jZWwgY2xvc2VkIGl0LCBub3QgYSBibHVyIGNvbW1pdFxuICAgIGNvbnN0IHAgPSBwcm9tcHQ7XG4gICAgc2V0UHJvbXB0KG51bGwpO1xuICAgIGlmICghcCkgcmV0dXJuO1xuICAgIGNvbnN0IHZhbHVlID0gcHJvbXB0VmFsdWUudHJpbSgpLnJlcGxhY2UoL15cXC8rLywgXCJcIik7XG4gICAgc2V0UHJvbXB0VmFsdWUoXCJcIik7XG4gICAgaWYgKCF2YWx1ZSkgcmV0dXJuO1xuICAgIGNvbnN0IHJvb3QgPVxuICAgICAgcm9vdEJ5UGF0aChwLnJvb3RQYXRoID09PSBcIlwiID8gXCJcIiA6IHAucm9vdFBhdGgpID8/XG4gICAgICBvcmRlcmVkLmZpbmQoKG0pID0+IG0ucGF0aCA9PT0gcC5yb290UGF0aCkgPz9cbiAgICAgIG51bGw7XG4gICAgaWYgKCFyb290KSByZXR1cm47XG4gICAgaWYgKHAubW9kZSA9PT0gXCJyZW5hbWVcIikge1xuICAgICAgaWYgKCFhY3Rpb25zPy5yZW5hbWUpIHJldHVybjtcbiAgICAgIGNvbnN0IGZyb21SZWwgPSB0b01vdW50UmVsKHAucm9vdFBhdGgsIHAudGFyZ2V0QWJzKTtcbiAgICAgIGNvbnN0IHRvUmVsID0gam9pblBhdGgoZGlyT2YoZnJvbVJlbCksIGJhc2VuYW1lKHZhbHVlKSk7XG4gICAgICBydW5SZW5hbWUod3JpdGVQb3J0cywgcm9vdCwgcC50YXJnZXRBYnMsIHsgbmFtZTogcC5pbml0aWFsLCBpc0RpcjogcC5pc0RpciB9LCB0b1JlbCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IHJlbCA9IGpvaW5QYXRoKHRvTW91bnRSZWwocC5yb290UGF0aCwgcC5iYXNlRGlyKSwgdmFsdWUpO1xuICAgICAgaWYgKHAubW9kZSA9PT0gXCJjcmVhdGUtZmlsZVwiKSB7XG4gICAgICAgIGlmICghYWN0aW9ucz8uY3JlYXRlRmlsZSkgcmV0dXJuO1xuICAgICAgICBydW5DcmVhdGUod3JpdGVQb3J0cywgXCJmaWxlXCIsIHJvb3QsIHAuYmFzZURpciwgcmVsKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGlmICghYWN0aW9ucz8uY3JlYXRlRm9sZGVyKSByZXR1cm47XG4gICAgICAgIHJ1bkNyZWF0ZSh3cml0ZVBvcnRzLCBcImZvbGRlclwiLCByb290LCBwLmJhc2VEaXIsIHJlbCk7XG4gICAgICB9XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IG9uVXBsb2FkSW5wdXQgPSAoZTogUmVhY3QuQ2hhbmdlRXZlbnQ8SFRNTElucHV0RWxlbWVudD4pID0+IHtcbiAgICBjb25zdCBmaWxlcyA9IEFycmF5LmZyb20oZS50YXJnZXQuZmlsZXMgPz8gW10pO1xuICAgIGNvbnN0IHRhcmdldCA9IHVwbG9hZFRhcmdldFJlZi5jdXJyZW50O1xuICAgIGUudGFyZ2V0LnZhbHVlID0gXCJcIjtcbiAgICBpZiAoIWZpbGVzLmxlbmd0aCB8fCAhdGFyZ2V0IHx8ICFhY3Rpb25zPy51cGxvYWQpIHJldHVybjtcbiAgICAvLyBUaGUgb3duaW5nIHJvb3Qgd2FzIGNhcHR1cmVkIGF0IG1lbnUgdGltZSAodGFyZ2V0LnJvb3RQYXRoKS5cbiAgICBjb25zdCByb290ID0gcm9vdEJ5UGF0aCh0YXJnZXQucm9vdFBhdGgpO1xuICAgIGlmICghcm9vdCkgcmV0dXJuO1xuICAgIHJ1blVwbG9hZCh3cml0ZVBvcnRzLCByb290LCBqb2luUmVsKHJvb3QucGF0aCwgdGFyZ2V0LmRpciksIHRhcmdldC5kaXIsIGZpbGVzKTtcbiAgfTtcblxuICBjb25zdCBoYXNSb290cyA9IG9yZGVyZWQubGVuZ3RoID4gMDtcbiAgY29uc3QgdGl0bGUgPSBoZWFkZXI/LnRpdGxlID8/IFwiRmlsZXNcIjtcbiAgY29uc3QgZ2x5cGggPSBoZWFkZXI/LmdseXBoID8/IDxGb2xkZXJUcmVlIHNpemU9ezE1fSBhcmlhLWhpZGRlbj1cInRydWVcIiAvPjtcblxuICByZXR1cm4gKFxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInBhbmVsIGZ4LXJvb3RcIiBhcmlhLWxhYmVsPXt0aXRsZX0gcmVmPXtwYW5lbEVsUmVmfT5cbiAgICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwicGFuZWxfX2hlYWRcIj5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicGFuZWxfX2dseXBoXCI+e2dseXBofTwvc3Bhbj5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicGFuZWxfX3RpdGxlXCI+e3RpdGxlfTwvc3Bhbj5cbiAgICAgICAgey8qIFRoZSB2aWV3J3MgT1dOIGFmZm9yZGFuY2VzIChsYXlvdXQsIGNvbGxhcHNlKSBhY3Qgb24gcm9vdHMsIHNvIHRoZXkgc3RheVxuICAgICAgICAgICAgZ2F0ZWQgb24gaGF2aW5nIHNvbWUuIEEgY2FsbGVyLXN1cHBsaWVkIGFjdGlvbiBtYXkgYmUgdGhlIHZlcnkgdGhpbmcgdGhhdFxuICAgICAgICAgICAgUFJPRFVDRVMgcm9vdHMgKFIzLTIzOCdzIFwic2hvdyBhbGwgZmlsZXN5c3RlbXNcIiByZXZlYWwpLCBzbyB0aGUgY2x1c3RlclxuICAgICAgICAgICAgcmVuZGVycyBmb3IgaXQgZXZlbiB3aGVuIHRoZSBsaXN0IGlzIGVtcHR5IOKAlCBhIGNvbnRyb2wgdGhhdCBkaXNhcHBlYXJzXG4gICAgICAgICAgICBleGFjdGx5IHdoZW4gaXQgaXMgbmVlZGVkIGlzIGEgdHJhcC4gKi99XG4gICAgICAgIHsoaGFzUm9vdHMgfHwgaGVhZGVyPy5hY3Rpb25zKSAmJiAoXG4gICAgICAgICAgLy8gYC0tZXh0cmFgIG1hcmtzIGEgaGVhZGVyIGNhcnJ5aW5nIGNvbnN1bWVyLXN1cHBsaWVkIGNvbnRyb2xzIG9uIHRvcCBvZlxuICAgICAgICAgIC8vIHRoZSB2aWV3J3Mgb3duLiBUaGUgc3R5bGVzaGVldCB1c2VzIGl0IHRvIGtlZXAgdGhlIHZpZXcgc3dpdGNoZXIgY29tcGFjdFxuICAgICAgICAgIC8vIHVudGlsIHRoZSBwYW5lbCBpcyBnZW51aW5lbHkgd2lkZSAoUjMtMjM5KTogdGhlIHN3aXRjaGVyJ3MgdGV4dCBsYWJlbHNcbiAgICAgICAgICAvLyBhcmUgdGhlIGhlYWRlcidzIGxhcmdlc3Qgc2luZ2xlIGNvbnN1bWVyLCBhbmQgYSBjb250YWluZXIgcXVlcnkgY2Fubm90XG4gICAgICAgICAgLy8gc2VlIGhvdyBtYW55IHNpYmxpbmdzIGl0IGlzIGNvbXBldGluZyB3aXRoLlxuICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgIGNsYXNzTmFtZT17XG4gICAgICAgICAgICAgIFwicGFuZWxfX2FjdGlvbnNcIiArXG4gICAgICAgICAgICAgIChoZWFkZXI/LmFjdGlvbnMgPyBcIiBwYW5lbF9fYWN0aW9ucy0tZXh0cmFcIiA6IFwiXCIpXG4gICAgICAgICAgICB9XG4gICAgICAgICAgPlxuICAgICAgICAgICAge2hhc1Jvb3RzICYmIChcbiAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICB7Lyogwqc1IHVwbG9hZCBidXR0b24g4oCUIHRoZSBwaWNrZXIgcGF0aCBmb3IgdXNlcnMgd2hvIGRvbid0IGZpbmRcbiAgICAgICAgICAgICAgICAgICAgZHJhZy1hbmQtZHJvcCAoYW5kIHRoZSBtb2JpbGUgcGF0aDogYSB0YXAgb3BlbnMgdGhlIG5hdGl2ZVxuICAgICAgICAgICAgICAgICAgICBmaWxlIHNlbGVjdG9yKS4gVGhlIGxhYmVsIG5hbWVzIHRoZSBsaXZlIGRlc3RpbmF0aW9uIHNvIHRoZVxuICAgICAgICAgICAgICAgICAgICBydWxlIGlzIGRpc2NvdmVyYWJsZSBvbiB0aGUgYWZmb3JkYW5jZSBpdHNlbGYuICovfVxuICAgICAgICAgICAgICAgIHthY3Rpb25zPy51cGxvYWQgJiYgdXBsb2FkUm9vdCAmJiAoXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwYW5lbF9fYWN0aW9uXCJcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU9e2BVcGxvYWQgZmlsZXMgdG8gJHt1cGxvYWREZXN0TGFiZWx9YH1cbiAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD17YFVwbG9hZCBmaWxlcyB0byAke3VwbG9hZERlc3RMYWJlbH1gfVxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtvcGVuVXBsb2FkUGlja2VyfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8VXBsb2FkIHNpemU9ezE1fSBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8TGF5b3V0U3dpdGNoZXIgdmFsdWU9e2xheW91dH0gb25DaGFuZ2U9e2Nob29zZUxheW91dH0gLz5cbiAgICAgICAgICAgICAgICB7bGF5b3V0ID09PSBcInRyZWVcIiAmJiAoXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwYW5lbF9fYWN0aW9uXCJcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJDb2xsYXBzZSBhbGwgZm9sZGVyc1wiXG4gICAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJDb2xsYXBzZSBhbGwgZm9sZGVyc1wiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHN0b3JlLmNvbGxhcHNlQWxsKCl9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxDaGV2cm9uc0Rvd25VcCBzaXplPXsxNX0gYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIHtoZWFkZXI/LmFjdGlvbnN9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG4gICAgICA8L2hlYWRlcj5cblxuICAgICAgey8qIFRoZSBvdmVyZmxvdyByb3cuIENvbnRyb2xzIHdob3NlIENPVU5UIGlzIGRhdGEtZHJpdmVuIGxpdmUgaGVyZSByYXRoZXIgdGhhbiBpblxuICAgICAgICAgIHRoZSBoZWFkZXIgY2x1c3RlciBhYm92ZTogdGhyZWUgXCJzZXR0aW5ncyDCtyA8YXBwPlwiIHBpbGxzIGluIGEgMzU0cHggcGFuZWwgZWFjaFxuICAgICAgICAgIHNocmFuayB0byAxN3B4IOKAlCBuYXJyb3dlciB0aGFuIHRoZSAxNHB4IGljb24gdGhleSBjb250YWluLCB3aGljaCB0aGVuIHNwaWxsZWRcbiAgICAgICAgICBvdXQgb3ZlciBpdHMgbmVpZ2hib3VyIGFuZCBvZmYgdGhlIHBhbmVsIGVkZ2UuIFIzLTIzOSBtYWRlIE9ORSBzdWNoIGNvbnRyb2xcbiAgICAgICAgICBzaHJpbmstYW5kLXRydW5jYXRlIGdyYWNlZnVsbHk7IE4gb2YgdGhlbSBpcyBhIGRpZmZlcmVudCBwcm9ibGVtLCBhbmQgdGhlIGZpeFxuICAgICAgICAgIGZvciBpdCBpcyBhIHJvdyBvZiB0aGVpciBvd24uIENoaWxkcmVuIG5ldmVyIHNocmluazsgdGhlIHN0cmlwIHNjcm9sbHMuICovfVxuICAgICAge2hlYWRlcj8udHJheSAmJiA8ZGl2IGNsYXNzTmFtZT1cInBhbmVsX190cmF5XCI+e2hlYWRlci50cmF5fTwvZGl2Pn1cblxuICAgICAge2Vycm9yICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYW5lbF9fZXJyb3JcIiByb2xlPVwiYWxlcnRcIj5cbiAgICAgICAgICB7ZXJyb3J9XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJwYW5lbF9fZXJyb3ItZGlzbWlzc1wiXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRFcnJvcihudWxsKX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICBEaXNtaXNzXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIFRoZSBvbmUgbGl2ZSByZWdpb24gKFItSVgtNyAvIFdDQUcgNC4xLjMpOiBwZW5kaW5nIGFuZCBzZXR0bGVkIHdyaXRlc1xuICAgICAgICAgIGFyZSBhbm5vdW5jZWQgaGVyZSDigJQgdmlzdWFsbHkgaGlkZGVuLCBwcmVzZW50IGluIHRoZSBhY2Nlc3NpYmlsaXR5XG4gICAgICAgICAgdHJlZSwgbmV2ZXIgc3RlYWxpbmcgZm9jdXMuICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmeC1zdGF0dXNcIiByb2xlPVwic3RhdHVzXCI+XG4gICAgICAgIHtzdGF0dXNNc2d9XG4gICAgICA8L2Rpdj5cblxuICAgICAge3Byb21wdCAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGFuZWxfX2NyZWF0ZVwiPlxuICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgcmVmPXtwcm9tcHRJbnB1dFJlZn1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInBhbmVsX19jcmVhdGUtaW5wdXRcIlxuICAgICAgICAgICAgc3BlbGxDaGVjaz17ZmFsc2V9XG4gICAgICAgICAgICBhcmlhLWxhYmVsPXtcbiAgICAgICAgICAgICAgcHJvbXB0Lm1vZGUgPT09IFwicmVuYW1lXCJcbiAgICAgICAgICAgICAgICA/IGBSZW5hbWUgJHtwcm9tcHQuaW5pdGlhbH1gXG4gICAgICAgICAgICAgICAgOiBgTmV3ICR7cHJvbXB0Lm1vZGUgPT09IFwiY3JlYXRlLWZvbGRlclwiID8gXCJmb2xkZXJcIiA6IFwiZmlsZVwifSBpbiAke3RvTW91bnRSZWwocHJvbXB0LnJvb3RQYXRoLCBwcm9tcHQuYmFzZURpcil9YFxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9e1xuICAgICAgICAgICAgICBwcm9tcHQubW9kZSA9PT0gXCJyZW5hbWVcIlxuICAgICAgICAgICAgICAgID8gXCJuZXcgbmFtZVwiXG4gICAgICAgICAgICAgICAgOiBwcm9tcHQubW9kZSA9PT0gXCJjcmVhdGUtZm9sZGVyXCJcbiAgICAgICAgICAgICAgICAgID8gXCJmb2xkZXIvcGF0aFwiXG4gICAgICAgICAgICAgICAgICA6IFwicGF0aC9uYW1lLmV4dFwiXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB2YWx1ZT17cHJvbXB0VmFsdWV9XG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFByb21wdFZhbHVlKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgIG9uS2V5RG93bj17KGUpID0+IHtcbiAgICAgICAgICAgICAgaWYgKGUua2V5ID09PSBcIkVudGVyXCIpIHN1Ym1pdFByb21wdCgpO1xuICAgICAgICAgICAgICBlbHNlIGlmIChlLmtleSA9PT0gXCJFc2NhcGVcIikge1xuICAgICAgICAgICAgICAgIC8vIENhbmNlbDogY2xvc2UgdGhlIHByb21wdCBhbmQgcmV0dXJuIGZvY3VzIHRvIHRoZSByb3cgdGhhdFxuICAgICAgICAgICAgICAgIC8vIG9wZW5lZCBpdC4gVGhlIGZsYWcga2VlcHMgdGhlIGJsdXIgdGhlIGZvY3VzIGhhbmQtYmFjayBmaXJlc1xuICAgICAgICAgICAgICAgIC8vIGZyb20gcmUtZW50ZXJpbmcgYHN1Ym1pdFByb21wdGAgKGJsdXIgc3RpbGwgY29tbWl0cyDigJQgdGhhdFxuICAgICAgICAgICAgICAgIC8vIGlzIGRlbGliZXJhdGUsIGFuZCBFbnRlci9Fc2NhcGUgYXJlIHRoZSBleHBsaWNpdCBwYXRocykuXG4gICAgICAgICAgICAgICAgcHJvbXB0Q2FuY2VsbGluZ1JlZi5jdXJyZW50ID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICBzZXRQcm9tcHQobnVsbCk7XG4gICAgICAgICAgICAgICAgc2V0UHJvbXB0VmFsdWUoXCJcIik7XG4gICAgICAgICAgICAgICAgcHJvbXB0UmV0dXJuUmVmLmN1cnJlbnQ/LmZvY3VzKCk7XG4gICAgICAgICAgICAgICAgcHJvbXB0Q2FuY2VsbGluZ1JlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH19XG4gICAgICAgICAgICBvbkJsdXI9e3N1Ym1pdFByb21wdH1cbiAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIDxpbnB1dFxuICAgICAgICByZWY9e3VwbG9hZElucHV0UmVmfVxuICAgICAgICB0eXBlPVwiZmlsZVwiXG4gICAgICAgIG11bHRpcGxlXG4gICAgICAgIGhpZGRlblxuICAgICAgICBvbkNoYW5nZT17b25VcGxvYWRJbnB1dH1cbiAgICAgICAgYXJpYS1oaWRkZW49XCJ0cnVlXCJcbiAgICAgICAgdGFiSW5kZXg9ey0xfVxuICAgICAgLz5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYW5lbF9fYm9keVwiPlxuICAgICAgICB7IWhhc1Jvb3RzID8gKFxuICAgICAgICAgIChlbXB0eVN0YXRlID8/IChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3RhdGVcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic3RhdGVfX2ljb25cIj5cbiAgICAgICAgICAgICAgICA8Rm9sZGVyVHJlZSBzaXplPXsyMH0gYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8aDQ+Tm8gZmlsZXMgdG8gc2hvdyB5ZXQuPC9oND5cbiAgICAgICAgICAgICAgPHA+T3BlbiBhIHByb2plY3Qgb3IgYWRkIGEgc3BhY2UgYW5kIGl0cyBmaWxlcyBhcHBlYXIgaGVyZS48L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApKVxuICAgICAgICApIDogbGF5b3V0ID09PSBcImxpc3RcIiA/IChcbiAgICAgICAgICA8TGlzdFZpZXdcbiAgICAgICAgICAgIHN0b3JlPXtzdG9yZX1cbiAgICAgICAgICAgIG9yZGVyZWQ9e29yZGVyZWR9XG4gICAgICAgICAgICBjd2Q9e2VmZkN3ZH1cbiAgICAgICAgICAgIHNldEN3ZD17bmF2aWdhdGVDd2R9XG4gICAgICAgICAgICBhY3RpdmVGaWxlPXthY3RpdmVQYXRofVxuICAgICAgICAgICAgc2VsZWN0aW9uTW9kZT17c2VsZWN0aW9uTW9kZX1cbiAgICAgICAgICAgIGhhbmRsZXJzPXtoYW5kbGVyc31cbiAgICAgICAgICAvPlxuICAgICAgICApIDogbGF5b3V0ID09PSBcImljb25zXCIgPyAoXG4gICAgICAgICAgPEljb25HcmlkXG4gICAgICAgICAgICBzdG9yZT17c3RvcmV9XG4gICAgICAgICAgICBvcmRlcmVkPXtvcmRlcmVkfVxuICAgICAgICAgICAgY3dkPXtlZmZDd2R9XG4gICAgICAgICAgICBzZXRDd2Q9e25hdmlnYXRlQ3dkfVxuICAgICAgICAgICAgYWN0aXZlRmlsZT17YWN0aXZlUGF0aH1cbiAgICAgICAgICAgIHZpZXdlZEZpbGU9e3ZpZXdlZFBhdGh9XG4gICAgICAgICAgICBoYW5kbGVycz17aGFuZGxlcnN9XG4gICAgICAgICAgLz5cbiAgICAgICAgKSA6IGxheW91dCA9PT0gXCJjb2x1bW5zXCIgPyAoXG4gICAgICAgICAgPENvbHVtblZpZXdcbiAgICAgICAgICAgIHN0b3JlPXtzdG9yZX1cbiAgICAgICAgICAgIG9yZGVyZWQ9e29yZGVyZWR9XG4gICAgICAgICAgICBjb2xQYXRoPXtlZmZDb2xQYXRofVxuICAgICAgICAgICAgc2V0Q29sUGF0aD17bmF2aWdhdGVDb2xzfVxuICAgICAgICAgICAgYWN0aXZlRmlsZT17YWN0aXZlUGF0aH1cbiAgICAgICAgICAgIHZpZXdlZEZpbGU9e3ZpZXdlZFBhdGh9XG4gICAgICAgICAgICBoYW5kbGVycz17aGFuZGxlcnN9XG4gICAgICAgICAgLz5cbiAgICAgICAgKSA6IChcbiAgICAgICAgICBvcmRlcmVkLm1hcCgobSkgPT4gKFxuICAgICAgICAgICAgPFNjb3BlXG4gICAgICAgICAgICAgIGtleT17bS5wYXRofVxuICAgICAgICAgICAgICByb290PXttfVxuICAgICAgICAgICAgICBzdG9yZT17c3RvcmV9XG4gICAgICAgICAgICAgIGhhbmRsZXJzPXtoYW5kbGVyc31cbiAgICAgICAgICAgICAgb25FamVjdD17YWN0aW9ucz8uZWplY3R9XG4gICAgICAgICAgICAgIHJlbmRlclJvd0FjY2Vzc29yeT17cmVuZGVyUm93QWNjZXNzb3J5fVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICApKVxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG5cbiAgICAgIHttZW51ICYmIDxDb250ZXh0TWVudSBhbmNob3I9e21lbnV9IG9uQ2xvc2U9eygpID0+IHNldE1lbnUobnVsbCl9IC8+fVxuXG4gICAgICB7bW92ZVRhcmdldCAmJiAoXG4gICAgICAgIDxNb3ZlRGlhbG9nXG4gICAgICAgICAgdGFyZ2V0PXttb3ZlVGFyZ2V0fVxuICAgICAgICAgIHJvb3RzPXtvcmRlcmVkfVxuICAgICAgICAgIHN0b3JlPXtzdG9yZX1cbiAgICAgICAgICBvbk1vdmU9eyhkaXJBYnMsIGRpclJvb3RQYXRoKSA9PiB7XG4gICAgICAgICAgICBvbk1vdmVEcm9wKG1vdmVUYXJnZXQuYWJzUGF0aCwgbW92ZVRhcmdldC5yb290UGF0aCwgbW92ZVRhcmdldC5pc0RpciwgZGlyQWJzLCBkaXJSb290UGF0aCk7XG4gICAgICAgICAgICBzZXRNb3ZlVGFyZ2V0KG51bGwpO1xuICAgICAgICAgIH19XG4gICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0TW92ZVRhcmdldChudWxsKX1cbiAgICAgICAgLz5cbiAgICAgICl9XG4gICAgPC9zZWN0aW9uPlxuICApO1xufVxuXG5leHBvcnQgZGVmYXVsdCBGaWxlRXhwbG9yZXJWaWV3O1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQWNBLElBQUFBLE1BQUEsR0FBQUMsT0FBQTtBQVdBLElBQUFDLFlBQUEsR0FBQUQsT0FBQTtBQXNCQSxJQUFBRSxVQUFBLEdBQUFGLE9BQUE7QUFZQSxJQUFBRyxZQUFBLEdBQUFDLHNCQUFBLENBQUFKLE9BQUE7QUFDQSxJQUFBSyxlQUFBLEdBQUFELHNCQUFBLENBQUFKLE9BQUE7QUFDQSxJQUFBTSxTQUFBLEdBQUFGLHNCQUFBLENBQUFKLE9BQUE7QUFDQSxJQUFBTyxTQUFBLEdBQUFILHNCQUFBLENBQUFKLE9BQUE7QUFDQSxJQUFBUSxXQUFBLEdBQUFKLHNCQUFBLENBQUFKLE9BQUE7QUFDQSxJQUFBUyxXQUFBLEdBQUFMLHNCQUFBLENBQUFKLE9BQUE7QUFDQSxJQUFBVSxhQUFBLEdBQUFWLE9BQUE7QUFDQSxJQUFBVyxVQUFBLEdBQUFYLE9BQUE7QUFDQSxJQUFBWSxnQkFBQSxHQUFBWixPQUFBO0FBQ0EsSUFBQWEsbUJBQUEsR0FBQWIsT0FBQTtBQUNBLElBQUFjLFVBQUEsR0FBQWQsT0FBQTtBQUNBLElBQUFlLFNBQUEsR0FBQWYsT0FBQTtBQUNBLElBQUFnQixTQUFBLEdBQUFoQixPQUFBO0FBa0JvQixJQUFBaUIsV0FBQSxHQUFBakIsT0FBQTtBQUFBLElBQUFrQixFQUFBLEdBQUFDLFlBQUE7RUFBQUMsR0FBQSxHQUFBRCxZQUFBO0VBQUFFLEdBQUEsR0FBQUYsWUFBQSxJQXpGcEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQXVGQTtBQUFBLFNBQUFmLHVCQUFBa0IsQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQTBFQSxNQUFNRyxRQUFRLGdCQUFBUCxFQUFBLGNBQUcsSUFBQVEsV0FBSSxFQUFBQyxFQUFBLEdBQUFULEVBQUEsQ0FBQyxTQUFTTyxRQUFRQSxDQUFDO0VBQ3RDRyxJQUFJO0VBQ0pDLElBQUk7RUFDSkMsS0FBSztFQUNMQyxLQUFLO0VBQ0xDLFFBQVE7RUFDUkMsT0FBTztFQUNQQyxRQUFRO0VBQ1JDLEtBQUs7RUFDTEMsUUFBUTtFQUNSQztBQVlGLENBQUMsRUFBRTtFQUFBbkIsRUFBQTtFQUNELE1BQU07SUFBRW9CLFFBQVE7SUFBRUMsUUFBUTtJQUFFQyxPQUFPO0lBQUVDO0VBQVEsQ0FBQyxHQUFHLElBQUFDLGtCQUFPLEVBQUNQLEtBQUssRUFBRVAsSUFBSSxDQUFDO0VBQ3JFLE1BQU1lLElBQUksR0FBR2IsS0FBSyxJQUFJUSxRQUFRO0VBQzlCLE1BQU1NLE9BQU8sR0FBR2QsS0FBSyxJQUFJYSxJQUFJLElBQUlGLE9BQU8sS0FBS0ksU0FBUyxJQUFJLENBQUNMLE9BQU87RUFDbEU7RUFDQTtFQUNBLE1BQU1NLE9BQU8sR0FBRyxJQUFBQyxxQkFBVSxFQUFDWixLQUFLLEVBQUVQLElBQUksQ0FBQztFQUN2QyxNQUFNLENBQUNvQixVQUFVLEVBQUVDLGFBQWEsQ0FBQyxHQUFHLElBQUFDLGVBQVEsRUFBQyxLQUFLLENBQUM7RUFDbkQ7RUFDQTtFQUNBLE1BQU1DLFVBQVUsR0FBRyxJQUFBQyx3QkFBYSxFQUFDakIsS0FBSyxFQUFFUCxJQUFJLENBQUM7RUFDN0MsTUFBTXlCLGFBQWEsR0FBRyxJQUFBQywyQkFBZ0IsRUFBQ25CLEtBQUssRUFBRUgsUUFBUSxDQUFDO0VBQ3ZELE1BQU11QixPQUFPLEdBQUdKLFVBQVUsSUFBS0UsYUFBYSxJQUFJdEIsS0FBSyxLQUFLLENBQUU7RUFDNUQsTUFBTXlCLE9BQU8sR0FBRyxJQUFBQyxZQUFLLEVBQUMsQ0FBQztFQUV2QixJQUFBQyxnQkFBUyxFQUFDLE1BQU07SUFDZCxJQUFJNUIsS0FBSyxJQUFJYSxJQUFJLElBQUlGLE9BQU8sS0FBS0ksU0FBUyxJQUFJLENBQUNMLE9BQU8sRUFDcERMLEtBQUssQ0FBQ3dCLFlBQVksQ0FBQy9CLElBQUksQ0FBQztFQUM1QixDQUFDLEVBQUUsQ0FBQ0UsS0FBSyxFQUFFYSxJQUFJLEVBQUVGLE9BQU8sRUFBRUQsT0FBTyxFQUFFWixJQUFJLEVBQUVPLEtBQUssQ0FBQyxDQUFDO0VBRWhELE1BQU15QixPQUFPLEdBQUcsSUFBQUMsb0JBQVUsRUFBQzdCLFFBQVEsRUFBRUosSUFBSSxDQUFDO0VBQzFDO0VBQ0E7RUFDQSxNQUFNa0MsV0FBVyxHQUFHLElBQUFDLG9CQUFTLEVBQUM1QixLQUFLLEVBQUV5QixPQUFPLENBQUM7RUFDN0MsTUFBTUksTUFBTSxHQUFHLENBQUNsQyxLQUFLLElBQUlnQyxXQUFXO0VBQ3BDO0VBQ0E7RUFDQTtFQUNBLE1BQU1HLG1CQUFtQixHQUFHLElBQUFDLDRCQUFpQixFQUFDL0IsS0FBSyxFQUFFeUIsT0FBTyxDQUFDO0VBQzdELE1BQU1PLGNBQWMsR0FBR3JDLEtBQUssSUFBSSxDQUFDYSxJQUFJLElBQUlzQixtQkFBbUI7RUFDNUQ7RUFDQSxNQUFNRyxXQUFXLEdBQUcsSUFBQUMsb0JBQVMsRUFBQ2xDLEtBQUssRUFBRXlCLE9BQU8sQ0FBQztFQUM3QyxNQUFNVSxNQUFNLEdBQUcsQ0FBQ3hDLEtBQUssSUFBSXNDLFdBQVc7RUFDcEM7RUFDQTtFQUNBO0VBQ0EsTUFBTUcsYUFBYSxHQUFHLElBQUFDLDRCQUFpQixFQUFDckMsS0FBSyxFQUFFeUIsT0FBTyxDQUFDO0VBQ3ZELE1BQU1hLGNBQWMsR0FBRzNDLEtBQUssSUFBSSxDQUFDYSxJQUFJLElBQUk0QixhQUFhO0VBQ3RELE1BQU1HLE1BQWMsR0FBRztJQUFFQyxPQUFPLEVBQUUvQyxJQUFJO0lBQUVFLEtBQUs7SUFBRUUsUUFBUTtJQUFFQyxPQUFPO0lBQUVDO0VBQVMsQ0FBQztFQUU1RSxNQUFNMEMsU0FBUyxHQUFHLElBQUFDLDBCQUFZLEVBQUMsQ0FBQ0MsQ0FBQyxFQUFFQyxDQUFDLEtBQ2xDM0MsUUFBUSxDQUFDNEMsTUFBTSxDQUFDO0lBQUVDLE9BQU8sRUFBRUgsQ0FBQztJQUFFSSxPQUFPLEVBQUVIO0VBQUUsQ0FBQyxFQUFFTCxNQUFNLENBQ3BELENBQUM7RUFFRCxNQUFNUyxTQUFTLEdBQUk3RCxDQUFzQixJQUFLO0lBQzVDLElBQUksSUFBQThELGtDQUFjLEVBQUM5RCxDQUFDLEVBQUVjLFFBQVEsRUFBRXNDLE1BQU0sQ0FBQyxFQUFFO0lBQ3pDLElBQUlwRCxDQUFDLENBQUMrRCxHQUFHLEtBQUssT0FBTyxJQUFJL0QsQ0FBQyxDQUFDK0QsR0FBRyxLQUFLLEdBQUcsRUFBRTtNQUN0Qy9ELENBQUMsQ0FBQ2dFLGNBQWMsQ0FBQyxDQUFDO01BQ2xCbEQsUUFBUSxDQUFDbUQsVUFBVSxDQUFDM0QsSUFBSSxFQUFFRSxLQUFLLENBQUM7SUFDbEMsQ0FBQyxNQUFNLElBQUlSLENBQUMsQ0FBQytELEdBQUcsS0FBSyxZQUFZLElBQUl2RCxLQUFLLEVBQUU7TUFDMUM7TUFDQTtNQUNBLElBQUksQ0FBQ2EsSUFBSSxFQUFFO1FBQ1RSLEtBQUssQ0FBQ3FELE1BQU0sQ0FBQzVELElBQUksQ0FBQztNQUNwQixDQUFDLE1BQU07UUFDTCxJQUFBNkQsb0NBQW1CLEVBQUNuRSxDQUFDLENBQUNvRSxhQUE0QixDQUFDO01BQ3JEO0lBQ0YsQ0FBQyxNQUFNLElBQUlwRSxDQUFDLENBQUMrRCxHQUFHLEtBQUssV0FBVyxFQUFFO01BQ2hDO01BQ0EsSUFBSXZELEtBQUssSUFBSWEsSUFBSSxFQUFFO1FBQ2pCUixLQUFLLENBQUNxRCxNQUFNLENBQUM1RCxJQUFJLENBQUM7TUFDcEIsQ0FBQyxNQUFNO1FBQ0wsTUFBTStELEtBQUssR0FBR3JFLENBQUMsQ0FBQ29FLGFBQWEsQ0FBQ0UsT0FBTyxDQUFDLGtCQUFrQixDQUFDO1FBQ3hERCxLQUFLLEVBQUVFLHNCQUFzQixFQUF5QkMsS0FBSyxDQUFDLENBQUM7TUFDaEU7SUFDRjtFQUNGLENBQUM7O0VBRUQ7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU1DLFdBQVcsR0FBSXpFLENBQWtCLElBQUs7SUFDMUNBLENBQUMsQ0FBQzBFLFlBQVksQ0FBQ0MsT0FBTyxDQUFDQyxtQkFBUyxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUFFQyxJQUFJLEVBQUV6RSxJQUFJO01BQUVJLFFBQVE7TUFBRUY7SUFBTSxDQUFDLENBQUMsQ0FBQztJQUNsRlIsQ0FBQyxDQUFDMEUsWUFBWSxDQUFDTSxhQUFhLEdBQUcsVUFBVTtJQUN6Q2xFLFFBQVEsQ0FBQ21FLFlBQVksQ0FBQzNFLElBQUksRUFBRUUsS0FBSyxFQUFFRyxPQUFPLEVBQUVELFFBQVEsQ0FBQztFQUN2RCxDQUFDO0VBQ0QsTUFBTXdFLFNBQVMsR0FBR0EsQ0FBQSxLQUFNcEUsUUFBUSxDQUFDcUUsYUFBYSxDQUFDLENBQUM7O0VBRWhEO0VBQ0EsTUFBTUMsVUFBVSxHQUFJcEYsQ0FBa0IsSUFBSztJQUN6QyxJQUFJLENBQUNRLEtBQUssRUFBRTtJQUNaLE1BQU02RSxNQUFNLEdBQUdyRixDQUFDLENBQUMwRSxZQUFZLENBQUNZLEtBQUssQ0FBQ0MsUUFBUSxDQUFDWCxtQkFBUyxDQUFDO0lBQ3ZELE1BQU1ZLFFBQVEsR0FBR3hGLENBQUMsQ0FBQzBFLFlBQVksQ0FBQ1ksS0FBSyxDQUFDQyxRQUFRLENBQUMsT0FBTyxDQUFDO0lBQ3ZELElBQUksQ0FBQ0YsTUFBTSxJQUFJLENBQUNHLFFBQVEsRUFBRTtJQUMxQixJQUFJQSxRQUFRLElBQUksQ0FBQzVFLFFBQVEsRUFBRTtJQUMzQlosQ0FBQyxDQUFDZ0UsY0FBYyxDQUFDLENBQUM7SUFDbEJoRSxDQUFDLENBQUN5RixlQUFlLENBQUMsQ0FBQztJQUNuQnpGLENBQUMsQ0FBQzBFLFlBQVksQ0FBQ2dCLFVBQVUsR0FBR0wsTUFBTSxHQUFHLE1BQU0sR0FBRyxNQUFNO0lBQ3BEMUQsYUFBYSxDQUFDLElBQUksQ0FBQztFQUNyQixDQUFDO0VBQ0QsTUFBTWdFLFdBQVcsR0FBR0EsQ0FBQSxLQUFNaEUsYUFBYSxDQUFDLEtBQUssQ0FBQztFQUM5QyxNQUFNaUUsTUFBTSxHQUFJNUYsQ0FBa0IsSUFBSztJQUNyQyxJQUFJLENBQUNRLEtBQUssRUFBRTtJQUNaLE1BQU1xRixJQUFJLEdBQUc3RixDQUFDLENBQUMwRSxZQUFZLENBQUNvQixPQUFPLENBQUNsQixtQkFBUyxDQUFDO0lBQzlDLE1BQU1tQixLQUFLLEdBQUdDLEtBQUssQ0FBQ2pCLElBQUksQ0FBQy9FLENBQUMsQ0FBQzBFLFlBQVksQ0FBQ3FCLEtBQUssQ0FBQztJQUM5QyxJQUFJLENBQUNGLElBQUksSUFBSSxDQUFDRSxLQUFLLENBQUNFLE1BQU0sRUFBRTtJQUM1QmpHLENBQUMsQ0FBQ2dFLGNBQWMsQ0FBQyxDQUFDO0lBQ2xCaEUsQ0FBQyxDQUFDeUYsZUFBZSxDQUFDLENBQUM7SUFDbkI5RCxhQUFhLENBQUMsS0FBSyxDQUFDO0lBQ3BCYixRQUFRLENBQUNxRSxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDMUIsSUFBSVUsSUFBSSxFQUFFO01BQ1IsTUFBTTtRQUFFZCxJQUFJO1FBQUVyRSxRQUFRLEVBQUV3RixRQUFRO1FBQUUxRixLQUFLLEVBQUUyRjtNQUFVLENBQUMsR0FBR3RCLElBQUksQ0FBQ3VCLEtBQUssQ0FBQ1AsSUFBSSxDQUlyRTtNQUNEL0UsUUFBUSxDQUFDdUYsVUFBVSxDQUFDdEIsSUFBSSxFQUFFbUIsUUFBUSxFQUFFQyxTQUFTLEVBQUU3RixJQUFJLEVBQUVJLFFBQVEsQ0FBQztJQUNoRSxDQUFDLE1BQU0sSUFBSXFGLEtBQUssQ0FBQ0UsTUFBTSxFQUFFO01BQ3ZCbkYsUUFBUSxDQUFDd0YsWUFBWSxDQUFDUCxLQUFLLEVBQUV6RixJQUFJLEVBQUVNLFFBQVEsQ0FBQztJQUM5QztFQUNGLENBQUM7RUFFRCxNQUFNMkYsSUFBSSxHQUFHL0YsS0FBSyxHQUFJYSxJQUFJLEdBQUdtRix1QkFBVSxHQUFHQyxtQkFBTSxHQUFJQyxpQkFBUTtFQUU1RCxvQkFDRSxJQUFBL0csV0FBQSxDQUFBZ0gsSUFBQTtJQUFJQyxJQUFJLEVBQUMsTUFBTTtJQUFBQyxRQUFBLGdCQU9iLElBQUFsSCxXQUFBLENBQUFnSCxJQUFBO01BQ0VDLElBQUksRUFBQyxVQUFVO01BQ2YsYUFBV3BHLEtBQUssSUFBSWEsSUFBSSxHQUFHYSxPQUFPLEdBQUdYLFNBQVU7TUFDL0MsaUJBQWVmLEtBQUssR0FBR2EsSUFBSSxHQUFHRSxTQUFVO01BQ3hDLGlCQUFlTixRQUFTO01BQ3hCLGFBQVdPLE9BQU8sR0FBRyxJQUFJLEdBQUdELFNBQVU7TUFDdEMsY0FBWWhCLElBQUs7TUFDakJ1RyxTQUFTLEVBQ1AsT0FBTyxJQUNON0YsUUFBUSxHQUFHLGtCQUFrQixHQUFHLEVBQUUsQ0FBQyxJQUNuQ3lCLE1BQU0sR0FBRyxnQkFBZ0IsR0FBRyxFQUFFLENBQUMsSUFDL0JNLE1BQU0sR0FBRyxnQkFBZ0IsR0FBRyxFQUFFLENBQUMsSUFDL0J0QixVQUFVLEdBQUcsb0JBQW9CLEdBQUcsRUFBRSxDQUFDLElBQ3ZDRixPQUFPLEdBQUcsaUJBQWlCLEdBQUcsRUFBRSxDQUNsQztNQUNEdUYsS0FBSyxFQUFFO1FBQUVDLFdBQVcsRUFBRSxDQUFDLEdBQUd2RyxLQUFLLEdBQUc7TUFBRyxDQUFFO01BQ3ZDd0csUUFBUSxFQUFFaEYsT0FBTyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUU7TUFDM0JpRixTQUFTO01BQ1RDLE9BQU8sRUFBRUEsQ0FBQSxLQUFNdEcsS0FBSyxDQUFDdUcsUUFBUSxDQUFDOUcsSUFBSSxDQUFFO01BQ3BDK0csT0FBTyxFQUFFQSxDQUFBLEtBQU12RyxRQUFRLENBQUNtRCxVQUFVLENBQUMzRCxJQUFJLEVBQUVFLEtBQUssQ0FBRTtNQUNoRHFELFNBQVMsRUFBRUEsU0FBVTtNQUNyQnlELGFBQWEsRUFBR3RILENBQUMsSUFBSztRQUNwQkEsQ0FBQyxDQUFDZ0UsY0FBYyxDQUFDLENBQUM7UUFDbEJsRCxRQUFRLENBQUM0QyxNQUFNLENBQUMxRCxDQUFDLEVBQUVvRCxNQUFNLENBQUM7TUFDNUIsQ0FBRTtNQUNGcUIsV0FBVyxFQUFFQSxXQUFZO01BQ3pCUyxTQUFTLEVBQUVBLFNBQVU7TUFDckJFLFVBQVUsRUFBRUEsVUFBVztNQUN2Qk8sV0FBVyxFQUFFQSxXQUFZO01BQ3pCQyxNQUFNLEVBQUVBLE1BQU87TUFDZjJCLGFBQWEsRUFBRWpFLFNBQVMsQ0FBQ2lFLGFBQWM7TUFDdkNDLGFBQWEsRUFBRWxFLFNBQVMsQ0FBQ2tFLGFBQWM7TUFDdkNDLFdBQVcsRUFBRW5FLFNBQVMsQ0FBQ21FLFdBQVk7TUFDbkNDLGVBQWUsRUFBRXBFLFNBQVMsQ0FBQ29FLGVBQWdCO01BQzNDLFlBQVVsSCxLQUFLLEdBQUcsR0FBRyxHQUFHLEdBQUk7TUFDNUIsYUFBV0YsSUFBSztNQUNoQixnQkFBY29DLE1BQU0sR0FBRyxNQUFNLEdBQUduQixTQUFVO01BQUFzRixRQUFBLGdCQUUxQyxJQUFBbEgsV0FBQSxDQUFBZ0ksR0FBQTtRQUFNYixTQUFTLEVBQUMsYUFBYTtRQUFBRCxRQUFBLGVBQzNCLElBQUFsSCxXQUFBLENBQUFnSSxHQUFBLEVBQUNwQixJQUFJO1VBQUNxQixJQUFJLEVBQUUsRUFBRztVQUFDLGVBQVk7UUFBTSxDQUFFO01BQUMsQ0FDakMsQ0FBQyxlQUNQLElBQUFqSSxXQUFBLENBQUFnSSxHQUFBO1FBQU1iLFNBQVMsRUFBQyxhQUFhO1FBQUFELFFBQUEsRUFBRXRHO01BQUksQ0FBTyxDQUFDLEVBQzFDbUMsTUFBTSxpQkFDTCxJQUFBL0MsV0FBQSxDQUFBZ0ksR0FBQTtRQUNFYixTQUFTLEVBQUMsZUFBZTtRQUN6QkYsSUFBSSxFQUFDLEtBQUs7UUFDVixjQUFXLG9CQUFvQjtRQUMvQmlCLEtBQUssRUFBQyxvQkFBb0I7UUFBQWhCLFFBQUEsZUFFMUIsSUFBQWxILFdBQUEsQ0FBQWdJLEdBQUEsRUFBQ2hKLFlBQUEsQ0FBQW1KLE1BQU07VUFBQ0YsSUFBSSxFQUFFLEVBQUc7VUFBQyxlQUFZO1FBQU0sQ0FBRTtNQUFDLENBQ25DLENBQ1AsRUFDQS9FLGNBQWMsaUJBQ2IsSUFBQWxELFdBQUEsQ0FBQWdJLEdBQUE7UUFDRWIsU0FBUyxFQUFDLHVDQUF1QztRQUNqREYsSUFBSSxFQUFDLEtBQUs7UUFDVixjQUFXLHNDQUFzQztRQUNqRGlCLEtBQUssRUFBQyxzQ0FBc0M7UUFBQWhCLFFBQUEsZUFFNUMsSUFBQWxILFdBQUEsQ0FBQWdJLEdBQUEsRUFBQ2hKLFlBQUEsQ0FBQW1KLE1BQU07VUFBQ0YsSUFBSSxFQUFFLEVBQUc7VUFBQyxlQUFZO1FBQU0sQ0FBRTtNQUFDLENBQ25DLENBQ1AsRUFDQTVFLE1BQU0saUJBQ0wsSUFBQXJELFdBQUEsQ0FBQWdJLEdBQUE7UUFDRWIsU0FBUyxFQUFDLGVBQWU7UUFDekJGLElBQUksRUFBQyxLQUFLO1FBQ1YsY0FBVywwQkFBMEI7UUFDckNpQixLQUFLLEVBQUMsMEJBQTBCO1FBQUFoQixRQUFBLGVBRWhDLElBQUFsSCxXQUFBLENBQUFnSSxHQUFBLEVBQUNoSixZQUFBLENBQUFvSixJQUFJO1VBQUNILElBQUksRUFBRSxFQUFHO1VBQUMsZUFBWTtRQUFNLENBQUU7TUFBQyxDQUNqQyxDQUNQLEVBQ0F6RSxjQUFjLGlCQUNiLElBQUF4RCxXQUFBLENBQUFnSSxHQUFBO1FBQ0ViLFNBQVMsRUFBQyx1Q0FBdUM7UUFDakRGLElBQUksRUFBQyxLQUFLO1FBQ1YsY0FBVyw0Q0FBNEM7UUFDdkRpQixLQUFLLEVBQUMsNENBQTRDO1FBQUFoQixRQUFBLGVBRWxELElBQUFsSCxXQUFBLENBQUFnSSxHQUFBLEVBQUNoSixZQUFBLENBQUFvSixJQUFJO1VBQUNILElBQUksRUFBRSxFQUFHO1VBQUMsZUFBWTtRQUFNLENBQUU7TUFBQyxDQUNqQyxDQUNQLEVBQ0EsQ0FBQ3RHLE9BQU8sSUFBSUUsT0FBTyxrQkFDbEIsSUFBQTdCLFdBQUEsQ0FBQWdJLEdBQUE7UUFBTWIsU0FBUyxFQUFDLGFBQWE7UUFBQyxlQUFZLE1BQU07UUFBQUQsUUFBQSxlQUM5QyxJQUFBbEgsV0FBQSxDQUFBZ0ksR0FBQSxFQUFDaEosWUFBQSxDQUFBcUosT0FBTztVQUFDSixJQUFJLEVBQUU7UUFBRyxDQUFFO01BQUMsQ0FDakIsQ0FDUCxFQUNBN0csa0JBQWtCLEdBQUdxQyxNQUFNLENBQUM7SUFBQSxDQUMxQixDQUFDLEVBRUw1QyxLQUFLLElBQUlhLElBQUksaUJBQ1osSUFBQTFCLFdBQUEsQ0FBQWdILElBQUE7TUFBSUMsSUFBSSxFQUFDLE9BQU87TUFBQ3FCLEVBQUUsRUFBRS9GLE9BQVE7TUFBQzRFLFNBQVMsRUFBQyxhQUFhO01BQUFELFFBQUEsR0FDbEQzRixPQUFPLGlCQUNOLElBQUF2QixXQUFBLENBQUFnSSxHQUFBO1FBQ0ViLFNBQVMsRUFBQyxvQkFBb0I7UUFDOUJDLEtBQUssRUFBRTtVQUFFQyxXQUFXLEVBQUUsQ0FBQyxHQUFHLENBQUN2RyxLQUFLLEdBQUcsQ0FBQyxJQUFJO1FBQUcsQ0FBRTtRQUFBb0csUUFBQSxFQUM5QztNQUVELENBQUksQ0FDTCxFQUNBMUYsT0FBTyxFQUFFOEUsTUFBTSxLQUFLLENBQUMsaUJBQ3BCLElBQUF0RyxXQUFBLENBQUFnSSxHQUFBO1FBQ0ViLFNBQVMsRUFBQyxvQkFBb0I7UUFDOUJDLEtBQUssRUFBRTtVQUFFQyxXQUFXLEVBQUUsQ0FBQyxHQUFHLENBQUN2RyxLQUFLLEdBQUcsQ0FBQyxJQUFJO1FBQUcsQ0FBRTtRQUFBb0csUUFBQSxFQUM5QztNQUVELENBQUksQ0FDTCxFQUNBMUYsT0FBTyxFQUFFK0csR0FBRyxDQUFFQyxLQUFLLGlCQUNsQixJQUFBeEksV0FBQSxDQUFBZ0ksR0FBQSxFQUFDeEgsUUFBUTtRQUVQRyxJQUFJLEVBQUUsSUFBQThILGtCQUFRLEVBQUM5SCxJQUFJLEVBQUU2SCxLQUFLLENBQUM1SCxJQUFJLENBQUU7UUFDakNBLElBQUksRUFBRTRILEtBQUssQ0FBQzVILElBQUs7UUFDakJDLEtBQUssRUFBRTJILEtBQUssQ0FBQzNILEtBQU07UUFDbkJDLEtBQUssRUFBRUEsS0FBSyxHQUFHLENBQUU7UUFDakJDLFFBQVEsRUFBRUEsUUFBUztRQUNuQkMsT0FBTyxFQUFFQSxPQUFRO1FBQ2pCQyxRQUFRLEVBQUVBLFFBQVM7UUFDbkJDLEtBQUssRUFBRUEsS0FBTTtRQUNiQyxRQUFRLEVBQUVBLFFBQVM7UUFDbkJDLGtCQUFrQixFQUFFQTtNQUFtQixHQVZsQ29ILEtBQUssQ0FBQzVILElBV1osQ0FDRixDQUFDO0lBQUEsQ0FDQSxDQUNMO0VBQUEsQ0FDQyxDQUFDO0FBRVQsQ0FBQztFQUFBLFFBMVBrRGEsa0JBQU8sRUFLeENLLHFCQUFVLEVBSVBLLHdCQUFhLEVBQ1ZFLDJCQUFnQixFQVlsQlMsb0JBQVMsRUFLREcsNEJBQWlCLEVBR3pCRyxvQkFBUyxFQUtQRyw0QkFBaUIsRUFJckJLLDBCQUFZO0FBQUEsRUFtTi9CLENBQUM7RUFBQSxRQTFQaURuQyxPQUFPLEVBS3hDSyxVQUFVLEVBSVBLLGFBQWEsRUFDVkUsZ0JBQWdCLEVBWWxCUyxTQUFTLEVBS0RHLGlCQUFpQixFQUd6QkcsU0FBUyxFQUtQRyxpQkFBaUIsRUFJckJLLFlBQVk7QUFBQSxFQW1OOUI7O0FBRUY7QUFBQThFLEdBQUEsR0FuUk1sSSxRQUFRO0FBb1JkLE1BQU1tSSxVQUE0RCxHQUFHO0VBQ25FQyxRQUFRLEVBQUVDLHVCQUFVO0VBQ3BCQyxRQUFRLEVBQUVDLHFCQUFZO0VBQ3RCQyxLQUFLLEVBQUVDLGtCQUFLO0VBQ1pDLEtBQUssRUFBRXBDO0FBQ1QsQ0FBQzs7QUFFRDtBQUNBO0FBQ0EsTUFBTXFDLEtBQUssZ0JBQUFoSixHQUFBLGNBQUcsSUFBQU0sV0FBSSxFQUFBMkksR0FBQSxHQUFBakosR0FBQSxDQUFDLFNBQVNnSixLQUFLQSxDQUFDO0VBQ2hDRSxJQUFJO0VBQ0puSSxLQUFLO0VBQ0xDLFFBQVE7RUFDUm1JLE9BQU87RUFDUGxJO0FBT0YsQ0FBQyxFQUFFO0VBQUFqQixHQUFBO0VBQ0QsTUFBTWMsUUFBUSxHQUFHLElBQUFzSSx5QkFBZSxFQUFDRixJQUFJLENBQUM7RUFDdEMsTUFBTXJJLE9BQU8sR0FBR3FJLElBQUksQ0FBQ2YsRUFBRTtFQUN2QjtFQUNBO0VBQ0E7RUFDQSxNQUFNa0IsUUFBUSxHQUFHLElBQUFDLHFCQUFXLEVBQUNKLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQ0MsT0FBTztFQUMvQyxNQUFNLENBQUNJLFFBQVEsRUFBRUMsV0FBVyxDQUFDLEdBQUcsSUFBQTFILGVBQVEsRUFBQyxLQUFLLENBQUM7RUFDL0MsTUFBTTJILE9BQU8sR0FBRyxJQUFBQyxrQkFBVyxFQUFDLFlBQVk7SUFDdEMsSUFBSSxDQUFDUCxPQUFPLElBQUlJLFFBQVEsRUFBRTtJQUMxQkMsV0FBVyxDQUFDLElBQUksQ0FBQztJQUNqQixJQUFJO01BQ0YsTUFBTUwsT0FBTyxDQUFDRCxJQUFJLENBQUM7SUFDckIsQ0FBQyxDQUFDLE1BQU07TUFDTk0sV0FBVyxDQUFDLEtBQUssQ0FBQztJQUNwQjtFQUNGLENBQUMsRUFBRSxDQUFDTCxPQUFPLEVBQUVJLFFBQVEsRUFBRUwsSUFBSSxDQUFDLENBQUM7RUFDN0IsTUFBTVMsS0FBSyxHQUFHLElBQUFDLG9CQUFVLEVBQUNWLElBQUksQ0FBQztFQUM5QixNQUFNVyxNQUFNLEdBQUcsSUFBQUMscUJBQVcsRUFBQ1osSUFBSSxDQUFDO0VBQ2hDLE1BQU1hLFFBQVEsR0FBR3ZCLFVBQVUsQ0FBQyxJQUFBd0IsbUJBQVMsRUFBQ2QsSUFBSSxDQUFDLENBQUM7O0VBRTVDO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsTUFBTSxDQUFDZSxRQUFRLEVBQUVDLFdBQVcsQ0FBQyxHQUFHLElBQUFwSSxlQUFRLEVBQUMsS0FBSyxDQUFDO0VBQy9DLE1BQU1xSSxhQUFhLEdBQUlqSyxDQUFrQixJQUFLWSxRQUFRLElBQUlaLENBQUMsQ0FBQzBFLFlBQVksQ0FBQ1ksS0FBSyxDQUFDQyxRQUFRLENBQUMsT0FBTyxDQUFDO0VBQ2hHLE1BQU0yRSxlQUFlLEdBQUlsSyxDQUFrQixJQUFLO0lBQzlDLElBQUksQ0FBQ2lLLGFBQWEsQ0FBQ2pLLENBQUMsQ0FBQyxFQUFFO0lBQ3ZCQSxDQUFDLENBQUNnRSxjQUFjLENBQUMsQ0FBQztJQUNsQmhFLENBQUMsQ0FBQzBFLFlBQVksQ0FBQ2dCLFVBQVUsR0FBRyxNQUFNO0lBQ2xDc0UsV0FBVyxDQUFDLElBQUksQ0FBQztFQUNuQixDQUFDO0VBQ0QsTUFBTUcsZ0JBQWdCLEdBQUluSyxDQUFrQixJQUFLO0lBQy9DO0lBQ0E7SUFDQSxJQUFJLENBQUNBLENBQUMsQ0FBQ29FLGFBQWEsQ0FBQ2dHLFFBQVEsQ0FBQ3BLLENBQUMsQ0FBQ3FLLGFBQTRCLENBQUMsRUFBRUwsV0FBVyxDQUFDLEtBQUssQ0FBQztFQUNuRixDQUFDO0VBQ0QsTUFBTU0sV0FBVyxHQUFJdEssQ0FBa0IsSUFBSztJQUMxQyxJQUFJLENBQUNpSyxhQUFhLENBQUNqSyxDQUFDLENBQUMsRUFBRTtJQUN2QixNQUFNK0YsS0FBSyxHQUFHQyxLQUFLLENBQUNqQixJQUFJLENBQUMvRSxDQUFDLENBQUMwRSxZQUFZLENBQUNxQixLQUFLLENBQUM7SUFDOUMsSUFBSSxDQUFDQSxLQUFLLENBQUNFLE1BQU0sRUFBRTtJQUNuQmpHLENBQUMsQ0FBQ2dFLGNBQWMsQ0FBQyxDQUFDO0lBQ2xCZ0csV0FBVyxDQUFDLEtBQUssQ0FBQztJQUNsQmxKLFFBQVEsQ0FBQ3dGLFlBQVksQ0FBQ1AsS0FBSyxFQUFFLElBQUF3RSw0QkFBa0IsRUFBQ3ZLLENBQUMsRUFBRWdKLElBQUksQ0FBQzFJLElBQUksQ0FBQyxFQUFFTSxRQUFRLENBQUM7RUFDMUUsQ0FBQztFQUVELG9CQUNFLElBQUFqQixXQUFBLENBQUFnSCxJQUFBO0lBQ0VHLFNBQVMsRUFBQyxPQUFPO0lBQ2pCLGFBQVdpRCxRQUFRLEdBQUcsR0FBRyxHQUFHeEksU0FBVTtJQUN0QzZELFVBQVUsRUFBRThFLGVBQWdCO0lBQzVCdkUsV0FBVyxFQUFFd0UsZ0JBQWlCO0lBQzlCSyxhQUFhLEVBQUVBLENBQUEsS0FBTVIsV0FBVyxDQUFDLEtBQUssQ0FBRTtJQUN4Q3BFLE1BQU0sRUFBRTBFLFdBQVk7SUFBQXpELFFBQUEsZ0JBRXBCLElBQUFsSCxXQUFBLENBQUFnSCxJQUFBO01BQUtHLFNBQVMsRUFBQyxPQUFPO01BQUFELFFBQUEsZ0JBQ3BCLElBQUFsSCxXQUFBLENBQUFnSCxJQUFBO1FBQUtHLFNBQVMsRUFBQyxhQUFhO1FBQUFELFFBQUEsZ0JBQzFCLElBQUFsSCxXQUFBLENBQUFnSSxHQUFBLEVBQUNrQyxRQUFRO1VBQUMvQyxTQUFTLEVBQUMsYUFBYTtVQUFDYyxJQUFJLEVBQUUsRUFBRztVQUFDLGVBQVk7UUFBTSxDQUFFLENBQUMsZUFDakUsSUFBQWpJLFdBQUEsQ0FBQWdJLEdBQUE7VUFBTWIsU0FBUyxFQUFDLGFBQWE7VUFBQUQsUUFBQSxFQUFFNEM7UUFBSyxDQUFPLENBQUM7TUFBQSxDQUN6QyxDQUFDLGVBQ04sSUFBQTlKLFdBQUEsQ0FBQWdJLEdBQUE7UUFBS2IsU0FBUyxFQUFDLGNBQWM7UUFBQUQsUUFBQSxFQUMxQjhDLE1BQU0sQ0FBQ3pCLEdBQUcsQ0FBRXVDLENBQUMsSUFBSztVQUNqQixNQUFNQyxHQUFHLEdBQUdELENBQUMsQ0FBQ0UsSUFBSSxLQUFLLElBQUk7VUFDM0Isb0JBQ0UsSUFBQWhMLFdBQUEsQ0FBQWdILElBQUE7WUFBc0JHLFNBQVMsRUFBQyxhQUFhO1lBQUFELFFBQUEsR0FDMUM2RCxHQUFHLGlCQUFJLElBQUEvSyxXQUFBLENBQUFnSSxHQUFBLEVBQUNoSixZQUFBLENBQUFpTSxJQUFJO2NBQUNoRCxJQUFJLEVBQUUsRUFBRztjQUFDLGVBQVk7WUFBTSxDQUFFLENBQUMsRUFDNUM2QyxDQUFDLENBQUNJLE9BQU8sRUFBQyxRQUFHLEVBQUNILEdBQUcsR0FBRyxXQUFXLEdBQUcsWUFBWTtVQUFBLEdBRnRDRCxDQUFDLENBQUNJLE9BR1AsQ0FBQztRQUVYLENBQUM7TUFBQyxDQUNDLENBQUMsRUFDTDFCLFFBQVEsaUJBQ1AsSUFBQXhKLFdBQUEsQ0FBQWdJLEdBQUE7UUFDRW1ELElBQUksRUFBQyxRQUFRO1FBQ2JoRSxTQUFTLEVBQUMsY0FBYztRQUN4Qk8sT0FBTyxFQUFFa0MsT0FBUTtRQUNqQndCLFFBQVEsRUFBRTFCLFFBQVM7UUFDbkIsY0FBWSxTQUFTSSxLQUFLLEVBQUc7UUFDN0I1QixLQUFLLEVBQUUsU0FBUzRCLEtBQUssNkNBQThDO1FBQUE1QyxRQUFBLEVBRWxFd0MsUUFBUSxnQkFDUCxJQUFBMUosV0FBQSxDQUFBZ0ksR0FBQSxFQUFDaEosWUFBQSxDQUFBcUosT0FBTztVQUFDSixJQUFJLEVBQUUsRUFBRztVQUFDZCxTQUFTLEVBQUMsYUFBYTtVQUFDLGVBQVk7UUFBTSxDQUFFLENBQUMsZ0JBRWhFLElBQUFuSCxXQUFBLENBQUFnSSxHQUFBLEVBQUNoSixZQUFBLENBQUFxTSxhQUFhO1VBQUNwRCxJQUFJLEVBQUUsRUFBRztVQUFDLGVBQVk7UUFBTSxDQUFFO01BQzlDLENBQ0ssQ0FDVDtJQUFBLENBQ0UsQ0FBQyxlQUlOLElBQUFqSSxXQUFBLENBQUFnSSxHQUFBO01BQ0VmLElBQUksRUFBQyxNQUFNO01BQ1gsY0FBWTZDLEtBQU07TUFDbEIzQyxTQUFTLEVBQUMsTUFBTTtNQUNoQmpELFNBQVMsRUFBRzdELENBQUMsSUFBSztRQUNoQixJQUFJLElBQUFpTCxnQ0FBZSxFQUFDakwsQ0FBQyxDQUFDb0UsYUFBYSxFQUFFcEUsQ0FBQyxDQUFDK0QsR0FBRyxDQUFDLEVBQUUvRCxDQUFDLENBQUNnRSxjQUFjLENBQUMsQ0FBQztNQUNqRSxDQUFFO01BQUE2QyxRQUFBLGVBRUYsSUFBQWxILFdBQUEsQ0FBQWdJLEdBQUEsRUFBQ3hILFFBQVE7UUFFUEcsSUFBSSxFQUFFMEksSUFBSSxDQUFDMUksSUFBSztRQUNoQkMsSUFBSSxFQUFFa0osS0FBTTtRQUNaakosS0FBSztRQUNMQyxLQUFLLEVBQUUsQ0FBRTtRQUNUQyxRQUFRLEVBQUVzSSxJQUFJLENBQUMxSSxJQUFLO1FBQ3BCSyxPQUFPLEVBQUVBLE9BQVE7UUFDakJDLFFBQVEsRUFBRUEsUUFBUztRQUNuQkMsS0FBSyxFQUFFQSxLQUFNO1FBQ2JDLFFBQVEsRUFBRUEsUUFBUztRQUNuQkMsa0JBQWtCLEVBQUVBO01BQW1CLEdBVmxDaUksSUFBSSxDQUFDMUksSUFXWDtJQUFDLENBQ0EsQ0FBQztFQUFBLENBQ0YsQ0FBQztBQUVWLENBQUMsa0NBQUM7QUFBQzRLLEdBQUEsR0FuSUdwQyxLQUFLO0FBcUlYLFNBQVNxQyxnQkFBZ0JBLENBQUM7RUFDeEJDLEtBQUs7RUFDTEMsRUFBRTtFQUNGQyxPQUFPO0VBQ1BDLFVBQVUsR0FBRyxJQUFJO0VBQ2pCQyxVQUFVLEdBQUcsSUFBSTtFQUNqQkMsTUFBTSxHQUFHLElBQUk7RUFDYkMsYUFBYSxHQUFHLFFBQVE7RUFDeEJDLFFBQVE7RUFDUkMsaUJBQWlCO0VBQ2pCM0gsVUFBVTtFQUNWNEgsVUFBVTtFQUNWQyxHQUFHLEVBQUVDLE9BQU87RUFDWkMsTUFBTSxFQUFFQyxVQUFVO0VBQ2xCQyxjQUFjO0VBQ2RDLFVBQVU7RUFDVkMsY0FBYztFQUNkckwsa0JBQWtCO0VBQ2xCc0wsTUFBTTtFQUNOQztBQUNxQixDQUFDLEVBQUU7RUFBQXZNLEdBQUE7RUFDeEIsTUFBTSxDQUFDd00sS0FBSyxFQUFFQyxRQUFRLENBQUMsR0FBRyxJQUFBNUssZUFBUSxFQUFnQixJQUFJLENBQUM7RUFDdkQsTUFBTSxDQUFDNkssSUFBSSxFQUFFQyxPQUFPLENBQUMsR0FBRyxJQUFBOUssZUFBUSxFQUFvQixJQUFJLENBQUM7RUFDekQ7RUFDQSxNQUFNLENBQUMrSyxVQUFVLEVBQUVDLGFBQWEsQ0FBQyxHQUFHLElBQUFoTCxlQUFRLEVBQW9CLElBQUksQ0FBQztFQUNyRTtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU0sQ0FBQ2lMLFNBQVMsRUFBRUMsWUFBWSxDQUFDLEdBQUcsSUFBQWxMLGVBQVEsRUFBQyxFQUFFLENBQUM7RUFDOUMsSUFBQVEsZ0JBQVMsRUFBQyxNQUFNLElBQUEySyxrQ0FBd0IsRUFBQ0QsWUFBWSxDQUFDLEVBQUUsRUFBRSxDQUFDO0VBQzNEO0VBQ0EsTUFBTSxDQUFDRSxNQUFNLEVBQUVDLFNBQVMsQ0FBQyxHQUFHLElBQUFyTCxlQUFRLEVBY2xDLElBQUksQ0FBQztFQUNQLE1BQU0sQ0FBQ3NMLFdBQVcsRUFBRUMsY0FBYyxDQUFDLEdBQUcsSUFBQXZMLGVBQVEsRUFBQyxFQUFFLENBQUM7RUFDbEQ7RUFDQTtFQUNBO0VBQ0EsTUFBTXdMLGVBQWUsR0FBRyxJQUFBQyxhQUFNLEVBQXFCLElBQUksQ0FBQztFQUN4RDtFQUNBO0VBQ0E7RUFDQSxNQUFNQyxtQkFBbUIsR0FBRyxJQUFBRCxhQUFNLEVBQUMsS0FBSyxDQUFDO0VBQ3pDO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU1FLGNBQWMsR0FBRyxJQUFBRixhQUFNLEVBQW1CLElBQUksQ0FBQztFQUNyRCxJQUFBakwsZ0JBQVMsRUFBQyxNQUFNO0lBQ2QsSUFBSTRLLE1BQU0sRUFBRU8sY0FBYyxDQUFDQyxPQUFPLEVBQUVoSixLQUFLLENBQUMsQ0FBQztFQUM3QyxDQUFDLEVBQUUsQ0FBQ3dJLE1BQU0sQ0FBQyxDQUFDO0VBQ1osTUFBTVMsY0FBYyxHQUFHLElBQUFKLGFBQU0sRUFBbUIsSUFBSSxDQUFDO0VBQ3JELE1BQU1LLGVBQWUsR0FBRyxJQUFBTCxhQUFNLEVBQzVCLElBQ0YsQ0FBQzs7RUFFRDtFQUNBO0VBQ0EsTUFBTSxDQUFDeE0sS0FBSyxDQUFDLEdBQUcsSUFBQWUsZUFBUSxFQUFDLE1BQU0sSUFBSStMLG9CQUFTLENBQUN0QyxFQUFFLENBQUMsQ0FBQztFQUVqRCxNQUFNLENBQUN1QyxXQUFXLEVBQUVDLGNBQWMsQ0FBQyxHQUFHLElBQUFDLG9CQUFTLEVBQUMzQixVQUFVLENBQUM7RUFDM0QsTUFBTUgsTUFBTSxHQUFHQyxVQUFVLElBQUkyQixXQUFXO0VBQ3hDLE1BQU1HLFNBQVMsR0FBRyxJQUFBdkUsa0JBQVcsRUFDMUJ3RSxJQUFZLElBQUs7SUFDaEIsSUFBSTlCLGNBQWMsRUFBRUEsY0FBYyxDQUFDOEIsSUFBSSxDQUFDO0lBQ3hDLElBQUkvQixVQUFVLEtBQUsxSyxTQUFTLEVBQUVzTSxjQUFjLENBQUNHLElBQUksQ0FBQztFQUNwRCxDQUFDLEVBQ0QsQ0FBQzlCLGNBQWMsRUFBRUQsVUFBVSxFQUFFNEIsY0FBYyxDQUM3QyxDQUFDO0VBQ0QsTUFBTSxDQUFDL0IsR0FBRyxFQUFFbUMsTUFBTSxDQUFDLEdBQUcsSUFBQXJNLGVBQVEsRUFBZ0IsSUFBSSxDQUFDO0VBQ25ELE1BQU0sQ0FBQ3NNLE9BQU8sRUFBRUMsVUFBVSxDQUFDLEdBQUcsSUFBQXZNLGVBQVEsRUFBVyxFQUFFLENBQUM7RUFFcEQsTUFBTXdNLE9BQU8sR0FBRyxJQUFBQyxjQUFPLEVBQUMsTUFBTSxJQUFBQyxxQkFBVyxFQUFDbEQsS0FBSyxDQUFDLEVBQUUsQ0FBQ0EsS0FBSyxDQUFDLENBQUM7RUFDMUQsTUFBTW1ELFVBQVUsR0FBRyxJQUFBL0Usa0JBQVcsRUFDM0JnRixDQUFTLElBQ1JKLE9BQU8sQ0FBQ0ssSUFBSSxDQUFFQyxDQUFDLElBQUtGLENBQUMsS0FBS0UsQ0FBQyxDQUFDcE8sSUFBSSxJQUFJa08sQ0FBQyxDQUFDRyxVQUFVLENBQUNELENBQUMsQ0FBQ3BPLElBQUksR0FBRyxHQUFHLENBQUMsQ0FBQyxJQUFJLElBQUksRUFDekUsQ0FBQzhOLE9BQU8sQ0FDVixDQUFDO0VBQ0Q7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsTUFBTVEsVUFBVSxHQUFHLElBQUFQLGNBQU8sRUFDeEIsTUFBTUQsT0FBTyxDQUFDSyxJQUFJLENBQUVDLENBQUMsSUFBSyxJQUFBeEYseUJBQWUsRUFBQ3dGLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSSxFQUNyRCxDQUFDTixPQUFPLENBQ1YsQ0FBQztFQUNELE1BQU1TLFdBQVcsR0FBRyxJQUFBQyx5QkFBYyxFQUFDak8sS0FBSyxDQUFDO0VBQ3pDLE1BQU1rTyxlQUFlLEdBQUdGLFdBQVcsR0FBR04sVUFBVSxDQUFDTSxXQUFXLENBQUN2TyxJQUFJLENBQUMsR0FBRyxJQUFJO0VBQ3pFLE1BQU0wTyxpQkFBaUIsR0FDckJILFdBQVcsSUFBSUUsZUFBZSxFQUFFbk8sUUFBUSxHQUFHaU8sV0FBVyxHQUFHLElBQUk7RUFDL0Q7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU1JLFFBQVEsR0FBR0QsaUJBQWlCLElBQUlELGVBQWUsR0FBR0EsZUFBZSxHQUFHSCxVQUFVO0VBQ3BGLE1BQU1NLFlBQVksR0FBR0QsUUFBUSxHQUN6QixJQUFBMU0sb0JBQVUsRUFBQzBNLFFBQVEsQ0FBQzNPLElBQUksRUFBRSxJQUFBNk8seUJBQWUsRUFBQ0gsaUJBQWlCLEVBQUVDLFFBQVEsQ0FBQzNPLElBQUksQ0FBQyxDQUFDLEdBQzVFLElBQUk7RUFDUixNQUFNOE8sZUFBZSxHQUNuQixDQUFDSCxRQUFRLElBQUlDLFlBQVksS0FBSyxJQUFJLEdBQzlCLEVBQUUsR0FDRkEsWUFBWSxLQUFLLEdBQUcsR0FDbEJELFFBQVEsS0FBS0wsVUFBVSxHQUNyQixlQUFlLEdBQ2YsT0FBTyxJQUFBbEYsb0JBQVUsRUFBQ3VGLFFBQVEsQ0FBQyxPQUFPLEdBQ3BDQyxZQUFZO0VBQ3BCO0FBQ0Y7RUFDRSxNQUFNRyxnQkFBZ0IsR0FBR0EsQ0FBQSxLQUFNO0lBQzdCLElBQUksQ0FBQy9ELE9BQU8sRUFBRWdFLE1BQU0sSUFBSSxDQUFDTCxRQUFRLElBQUlDLFlBQVksS0FBSyxJQUFJLEVBQUU7SUFDNUR4QixlQUFlLENBQUNGLE9BQU8sR0FBRztNQUFFK0IsR0FBRyxFQUFFTCxZQUFZO01BQUV4TyxRQUFRLEVBQUV1TyxRQUFRLENBQUMzTztJQUFLLENBQUM7SUFDeEVtTixjQUFjLENBQUNELE9BQU8sRUFBRWdDLEtBQUssQ0FBQyxDQUFDO0VBQ2pDLENBQUM7RUFDRDtFQUNBM08sS0FBSyxDQUFDNE8sV0FBVyxDQUFDckIsT0FBTyxDQUFDbEcsR0FBRyxDQUFFd0csQ0FBQyxJQUFLQSxDQUFDLENBQUNwTyxJQUFJLENBQUMsQ0FBQzs7RUFFN0M7RUFDQTtFQUNBO0VBQ0EsSUFBQThCLGdCQUFTLEVBQUMsTUFBTTtJQUNkdkIsS0FBSyxDQUFDNk8sYUFBYSxDQUFDbkUsVUFBVSxDQUFDO0VBQ2pDLENBQUMsRUFBRSxDQUFDMUssS0FBSyxFQUFFMEssVUFBVSxDQUFDLENBQUM7RUFDdkI7RUFDQSxJQUFBbkosZ0JBQVMsRUFBQyxNQUFNO0lBQ2R2QixLQUFLLENBQUM4TyxhQUFhLENBQUNuRSxVQUFVLENBQUM7RUFDakMsQ0FBQyxFQUFFLENBQUMzSyxLQUFLLEVBQUUySyxVQUFVLENBQUMsQ0FBQzs7RUFFdkI7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU1vRSxPQUFPLEdBQUcsSUFBQXZCLGNBQU8sRUFDckIsTUFBTUQsT0FBTyxDQUFDbEcsR0FBRyxDQUFFd0csQ0FBQyxJQUFLQSxDQUFDLENBQUNwTyxJQUFJLENBQUMsQ0FBQ3VQLElBQUksQ0FBQyxRQUFRLENBQUMsRUFDL0MsQ0FBQ3pCLE9BQU8sQ0FDVixDQUFDO0VBQ0QsTUFBTTBCLFVBQVUsR0FBRyxJQUFBekMsYUFBTSxFQUFxQixJQUFJLENBQUM7RUFDbkQ7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNMEMsc0JBQXNCLEdBQUcsSUFBQTFDLGFBQU0sRUFBZ0IsSUFBSSxDQUFDO0VBQzFELElBQUFqTCxnQkFBUyxFQUFDLE1BQU07SUFDZCxJQUFJLENBQUNxSixNQUFNLEVBQUU7SUFDYjVLLEtBQUssQ0FBQ21QLFVBQVUsQ0FBQ3ZFLE1BQU0sQ0FBQ25MLElBQUksQ0FBQztJQUM3QixJQUFJeVAsc0JBQXNCLENBQUN2QyxPQUFPLEtBQUsvQixNQUFNLENBQUN3RSxLQUFLLEVBQUU7SUFDckQsSUFBSUMsS0FBSyxHQUFHLENBQUM7SUFDYixNQUFNQyxLQUFLLEdBQUdDLFdBQVcsQ0FBQyxNQUFNO01BQzlCLE1BQU1DLEVBQUUsR0FBR1AsVUFBVSxDQUFDdEMsT0FBTyxFQUFFOEMsYUFBYSxDQUFDLGdCQUFnQixDQUFDO01BQzlELElBQUlELEVBQUUsRUFBRTtRQUNOQSxFQUFFLENBQUNFLGNBQWMsQ0FBQztVQUFFQyxLQUFLLEVBQUU7UUFBVSxDQUFDLENBQUM7UUFDdkNULHNCQUFzQixDQUFDdkMsT0FBTyxHQUFHL0IsTUFBTSxDQUFDd0UsS0FBSztRQUM3Q1EsYUFBYSxDQUFDTixLQUFLLENBQUM7TUFDdEIsQ0FBQyxNQUFNLElBQUksRUFBRUQsS0FBSyxHQUFHLEVBQUUsRUFBRTtRQUN2Qk8sYUFBYSxDQUFDTixLQUFLLENBQUMsQ0FBQyxDQUFDO01BQ3hCO0lBQ0YsQ0FBQyxFQUFFLEdBQUcsQ0FBQztJQUNQLE9BQU8sTUFBTU0sYUFBYSxDQUFDTixLQUFLLENBQUM7RUFDbkMsQ0FBQyxFQUFFLENBQUMxRSxNQUFNLEVBQUU1SyxLQUFLLEVBQUUrTyxPQUFPLENBQUMsQ0FBQzs7RUFFNUI7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsSUFBQXhOLGdCQUFTLEVBQUMsTUFBTTtJQUNkLElBQUksQ0FBQ21KLFVBQVUsRUFBRTtJQUNqQjFLLEtBQUssQ0FBQ21QLFVBQVUsQ0FBQ3pFLFVBQVUsQ0FBQztJQUM1QixJQUFJMkUsS0FBSyxHQUFHLENBQUM7SUFDYixNQUFNQyxLQUFLLEdBQUdDLFdBQVcsQ0FBQyxNQUFNO01BQzlCLE1BQU1DLEVBQUUsR0FBR1AsVUFBVSxDQUFDdEMsT0FBTyxFQUFFOEMsYUFBYSxDQUFDLGdCQUFnQixDQUFDO01BQzlELElBQUlELEVBQUUsRUFBRTtRQUNOQSxFQUFFLENBQUNFLGNBQWMsQ0FBQztVQUFFQyxLQUFLLEVBQUU7UUFBVSxDQUFDLENBQUM7UUFDdkNDLGFBQWEsQ0FBQ04sS0FBSyxDQUFDO01BQ3RCLENBQUMsTUFBTSxJQUFJLEVBQUVELEtBQUssR0FBRyxFQUFFLEVBQUU7UUFDdkJPLGFBQWEsQ0FBQ04sS0FBSyxDQUFDLENBQUMsQ0FBQztNQUN4QjtJQUNGLENBQUMsRUFBRSxHQUFHLENBQUM7SUFDUCxPQUFPLE1BQU1NLGFBQWEsQ0FBQ04sS0FBSyxDQUFDO0VBQ25DLENBQUMsRUFBRSxDQUFDNUUsVUFBVSxFQUFFcUUsT0FBTyxFQUFFL08sS0FBSyxDQUFDLENBQUM7O0VBRWhDO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNNlAsWUFBWSxHQUFHLElBQUFDLDJCQUFvQixFQUN2QzlQLEtBQUssQ0FBQytQLFNBQVMsRUFDZi9QLEtBQUssQ0FBQ2dRLFlBQ1IsQ0FBQztFQUNELE1BQU1DLGdCQUFnQixHQUFHLElBQUF6RCxhQUFNLEVBQUNxRCxZQUFZLENBQUM7RUFDN0MsSUFBQXRPLGdCQUFTLEVBQUMsTUFBTTtJQUNkO0lBQ0EsTUFBTTJPLE9BQU8sR0FBR0QsZ0JBQWdCLENBQUN0RCxPQUFPLEtBQUtrRCxZQUFZO0lBQ3pESSxnQkFBZ0IsQ0FBQ3RELE9BQU8sR0FBR2tELFlBQVk7SUFDdkMsSUFBSSxDQUFDSyxPQUFPLEVBQUU7SUFDZCxJQUFJckYsYUFBYSxLQUFLLE9BQU8sSUFBSSxDQUFDRSxpQkFBaUIsRUFBRTtJQUNyRCxNQUFNNUMsSUFBSSxHQUFHMEgsWUFBWSxDQUFDekssTUFBTSxHQUFHc0ksVUFBVSxDQUFDbUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSTtJQUNyRSxNQUFNTSxLQUFLLEdBQUdoSSxJQUFJLElBQUlvRixPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSTtJQUN4QyxJQUFJLENBQUM0QyxLQUFLLEVBQUU7SUFDWnBGLGlCQUFpQixDQUNmb0YsS0FBSyxFQUNMTixZQUFZLENBQUN4SSxHQUFHLENBQUUrSSxHQUFHLElBQUssSUFBQTFPLG9CQUFVLEVBQUN5TyxLQUFLLENBQUMxUSxJQUFJLEVBQUUyUSxHQUFHLENBQUMsQ0FDdkQsQ0FBQztFQUNILENBQUMsRUFBRSxDQUFDUCxZQUFZLEVBQUVoRixhQUFhLEVBQUVFLGlCQUFpQixFQUFFMkMsVUFBVSxFQUFFSCxPQUFPLENBQUMsQ0FBQzs7RUFFekU7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU04QyxhQUFhLEdBQUduRixPQUFPLEtBQUt4SyxTQUFTO0VBQzNDLE1BQU00UCxTQUFTLEdBQUdELGFBQWEsR0FBR25GLE9BQU8sR0FBR0QsR0FBRztFQUMvQyxNQUFNc0YsTUFBTSxHQUNWRCxTQUFTLElBQ1QvQyxPQUFPLENBQUNpRCxJQUFJLENBQ1QzQyxDQUFDLElBQUt5QyxTQUFTLEtBQUt6QyxDQUFDLENBQUNwTyxJQUFJLElBQUk2USxTQUFTLENBQUN4QyxVQUFVLENBQUNELENBQUMsQ0FBQ3BPLElBQUksR0FBRyxHQUFHLENBQ2xFLENBQUMsR0FDRzZRLFNBQVMsR0FDVCxJQUFJO0VBQ1YsTUFBTUcsVUFBVSxHQUNkcEQsT0FBTyxDQUFDakksTUFBTSxJQUFJbUksT0FBTyxDQUFDaUQsSUFBSSxDQUFFM0MsQ0FBQyxJQUFLQSxDQUFDLENBQUNwTyxJQUFJLEtBQUs0TixPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBR0EsT0FBTyxHQUFHLEVBQUU7O0VBRTdFO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU1xRCxXQUFXLEdBQUcsSUFBQS9ILGtCQUFXLEVBQzVCbEosSUFBbUIsSUFBSztJQUN2QjtJQUNBO0lBQ0EsSUFBSSxDQUFDNFEsYUFBYSxFQUFFakQsTUFBTSxDQUFDM04sSUFBSSxDQUFDO0lBQ2hDLElBQUlBLElBQUksRUFBRTtNQUNSLElBQUlvTCxhQUFhLEtBQUssTUFBTSxFQUFFN0ssS0FBSyxDQUFDMlEsTUFBTSxDQUFDbFIsSUFBSSxFQUFFLElBQUksQ0FBQztNQUN0RCxNQUFNMEksSUFBSSxHQUFHdUYsVUFBVSxDQUFDak8sSUFBSSxDQUFDO01BQzdCLElBQUkwSSxJQUFJLEVBQUU2QyxVQUFVLEdBQUc3QyxJQUFJLEVBQUUsSUFBQXpHLG9CQUFVLEVBQUN5RyxJQUFJLENBQUMxSSxJQUFJLEVBQUVBLElBQUksQ0FBQyxDQUFDO0lBQzNEO0VBQ0YsQ0FBQyxFQUNELENBQUNPLEtBQUssRUFBRTBOLFVBQVUsRUFBRTFDLFVBQVUsRUFBRXFGLGFBQWEsRUFBRXhGLGFBQWEsQ0FDOUQsQ0FBQztFQUNEO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsTUFBTStGLFlBQVksR0FBRyxJQUFBakksa0JBQVcsRUFDN0JsSixJQUFjLElBQUs7SUFDbEI2TixVQUFVLENBQUM3TixJQUFJLENBQUM7SUFDaEIsTUFBTW9SLElBQUksR0FBR3BSLElBQUksQ0FBQ0EsSUFBSSxDQUFDMkYsTUFBTSxHQUFHLENBQUMsQ0FBQztJQUNsQyxJQUFJeUwsSUFBSSxFQUFFO01BQ1IsSUFBSWhHLGFBQWEsS0FBSyxNQUFNLEVBQUU3SyxLQUFLLENBQUMyUSxNQUFNLENBQUNFLElBQUksRUFBRSxJQUFJLENBQUM7TUFDdEQsTUFBTTFJLElBQUksR0FBR3VGLFVBQVUsQ0FBQ21ELElBQUksQ0FBQztNQUM3QixJQUFJMUksSUFBSSxFQUFFNkMsVUFBVSxHQUFHN0MsSUFBSSxFQUFFLElBQUF6RyxvQkFBVSxFQUFDeUcsSUFBSSxDQUFDMUksSUFBSSxFQUFFb1IsSUFBSSxDQUFDLENBQUM7SUFDM0Q7RUFDRixDQUFDLEVBQ0QsQ0FBQzdRLEtBQUssRUFBRTBOLFVBQVUsRUFBRTFDLFVBQVUsRUFBRUgsYUFBYSxDQUMvQyxDQUFDOztFQUVEO0VBQ0E7RUFDQSxNQUFNaUcsWUFBWSxHQUFHLElBQUFuSSxrQkFBVyxFQUM3QndFLElBQVksSUFBSztJQUNoQixJQUFJQSxJQUFJLEtBQUtoQyxNQUFNLEVBQUU7TUFDbkIsTUFBTTRGLEdBQUcsR0FBRy9RLEtBQUssQ0FBQ2dSLFdBQVcsQ0FBQyxDQUFDO01BQy9CLElBQUk3RCxJQUFJLEtBQUssTUFBTSxJQUFJQSxJQUFJLEtBQUssT0FBTyxFQUFFO1FBQ3ZDQyxNQUFNLENBQ0oyRCxHQUFHLEdBQUcsSUFBQUUsZUFBSyxFQUFDRixHQUFHLENBQUMsR0FBR3hELE9BQU8sQ0FBQ25JLE1BQU0sS0FBSyxDQUFDLEdBQUdtSSxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM5TixJQUFJLEdBQUcsSUFDOUQsQ0FBQztNQUNILENBQUMsTUFBTSxJQUFJME4sSUFBSSxLQUFLLFNBQVMsRUFBRTtRQUM3QixNQUFNK0QsS0FBSyxHQUFHSCxHQUFHLEdBQ2J4RCxPQUFPLENBQUNLLElBQUksQ0FDVEMsQ0FBQyxJQUFLa0QsR0FBRyxLQUFLbEQsQ0FBQyxDQUFDcE8sSUFBSSxJQUFJc1IsR0FBRyxDQUFDakQsVUFBVSxDQUFDRCxDQUFDLENBQUNwTyxJQUFJLEdBQUcsR0FBRyxDQUN0RCxDQUFDLEdBQ0Q4TixPQUFPLENBQUNuSSxNQUFNLEtBQUssQ0FBQyxHQUNsQm1JLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FDVjdNLFNBQVM7UUFDZixJQUFJLENBQUN3USxLQUFLLEVBQUU1RCxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsS0FDdEI7VUFDSCxNQUFNN04sSUFBSSxHQUFHLENBQUN5UixLQUFLLENBQUN6UixJQUFJLENBQUM7VUFDekIsTUFBTTBSLElBQUksR0FBRyxJQUFBelAsb0JBQVUsRUFBQ3dQLEtBQUssQ0FBQ3pSLElBQUksRUFBRXNSLEdBQUcsR0FBRyxJQUFBRSxlQUFLLEVBQUNGLEdBQUcsQ0FBQyxHQUFHRyxLQUFLLENBQUN6UixJQUFJLENBQUMsQ0FDL0QyUixLQUFLLENBQUMsR0FBRyxDQUFDLENBQ1ZDLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDO1VBQ2xCLElBQUlDLEdBQUcsR0FBR0wsS0FBSyxDQUFDelIsSUFBSTtVQUNwQixLQUFLLE1BQU1tSyxDQUFDLElBQUl1SCxJQUFJLEVBQUU7WUFDcEJJLEdBQUcsR0FBRyxJQUFBaEssa0JBQVEsRUFBQ2dLLEdBQUcsRUFBRTNILENBQUMsQ0FBQztZQUN0Qm5LLElBQUksQ0FBQytSLElBQUksQ0FBQ0QsR0FBRyxDQUFDO1VBQ2hCO1VBQ0FqRSxVQUFVLENBQUM3TixJQUFJLENBQUM7UUFDbEI7TUFDRjtJQUNGO0lBQ0F5TixTQUFTLENBQUNDLElBQUksQ0FBQztFQUNqQixDQUFDLEVBQ0QsQ0FBQ2hDLE1BQU0sRUFBRW9DLE9BQU8sRUFBRXZOLEtBQUssRUFBRWtOLFNBQVMsQ0FDcEMsQ0FBQzs7RUFFRDtFQUNBO0VBQ0E7RUFDQSxNQUFNdUUsVUFBVSxHQUFHLElBQUFqRSxjQUFPLEVBQ3hCLE9BQU87SUFDTHhOLEtBQUs7SUFDTHlLLE9BQU8sRUFBRUEsT0FBTyxJQUFLLENBQUMsQ0FBcUI7SUFDM0NpSCxRQUFRLEVBQUVDLGtCQUFlO0lBQ3pCQyxJQUFJLEVBQUdDLE9BQWUsSUFBS2xHLFFBQVEsQ0FBQ2tHLE9BQU8sQ0FBQztJQUM1Q0MsS0FBSyxFQUFFQSxDQUFBLEtBQU1uRyxRQUFRLENBQUMsSUFBSTtFQUM1QixDQUFDLENBQUMsRUFDRixDQUFDM0wsS0FBSyxFQUFFeUssT0FBTyxDQUNqQixDQUFDOztFQUVEO0VBQ0E7RUFDQTtFQUNBLE1BQU1zSCxZQUFZLEdBQUcsSUFBQXBKLGtCQUFXLEVBQzlCLENBQUNSLElBQWtCLEVBQUU2SixRQUFnQixLQUFLO0lBQ3hDckcsUUFBUSxDQUFDLElBQUksQ0FBQztJQUNkdkksVUFBVSxHQUFHK0UsSUFBSSxFQUFFNkosUUFBUSxFQUFFLEtBQUssQ0FBQztJQUNuQyxJQUFJLENBQUN2SCxPQUFPLEVBQUVqSyxJQUFJLEVBQUU7SUFDcEIsSUFBSTtNQUNGaUssT0FBTyxDQUFDakssSUFBSSxDQUFDMkgsSUFBSSxFQUFFNkosUUFBUSxDQUFDO0lBQzlCLENBQUMsQ0FBQyxNQUFNO01BQ05yRyxRQUFRLENBQUMsMEJBQTBCLENBQUM7SUFDdEM7RUFDRixDQUFDLEVBQ0QsQ0FBQ2xCLE9BQU8sRUFBRXJILFVBQVUsQ0FDdEIsQ0FBQztFQUVELE1BQU02TyxjQUFjLEdBQUcsSUFBQXRKLGtCQUFXLEVBQ2hDLENBQUNuRyxPQUFlLEVBQUU3QyxLQUFjLEtBQUs7SUFDbkMsTUFBTXdJLElBQUksR0FBR3VGLFVBQVUsQ0FBQ2xMLE9BQU8sQ0FBQztJQUNoQyxJQUFJN0MsS0FBSyxFQUFFO01BQ1RLLEtBQUssQ0FBQ3FELE1BQU0sQ0FBQ2IsT0FBTyxDQUFDO01BQ3JCO01BQ0E7TUFDQSxJQUFJcUksYUFBYSxLQUFLLE1BQU0sRUFBRTdLLEtBQUssQ0FBQzJRLE1BQU0sQ0FBQ25PLE9BQU8sRUFBRSxJQUFJLENBQUM7TUFDekQsSUFBSTJGLElBQUksRUFBRS9FLFVBQVUsR0FBRytFLElBQUksRUFBRSxJQUFBekcsb0JBQVUsRUFBQ3lHLElBQUksQ0FBQzFJLElBQUksRUFBRStDLE9BQU8sQ0FBQyxFQUFFLElBQUksQ0FBQztJQUNwRSxDQUFDLE1BQU07TUFDTCxJQUFJcUksYUFBYSxLQUFLLE1BQU0sRUFBRTdLLEtBQUssQ0FBQzJRLE1BQU0sQ0FBQ25PLE9BQU8sRUFBRSxLQUFLLENBQUM7TUFDMUQsSUFBSSxDQUFDMkYsSUFBSSxFQUFFLE9BQU8sQ0FBQztNQUNuQixNQUFNK0osR0FBRyxHQUFHLElBQUF4USxvQkFBVSxFQUFDeUcsSUFBSSxDQUFDMUksSUFBSSxFQUFFK0MsT0FBTyxDQUFDO01BQzFDc0ksUUFBUSxHQUFHM0MsSUFBSSxFQUFFK0osR0FBRyxDQUFDO01BQ3JCSCxZQUFZLENBQUM1SixJQUFJLEVBQUUrSixHQUFHLENBQUM7SUFDekI7RUFDRixDQUFDLEVBQ0QsQ0FBQ2xTLEtBQUssRUFBRTBOLFVBQVUsRUFBRXRLLFVBQVUsRUFBRTBILFFBQVEsRUFBRWlILFlBQVksRUFBRWxILGFBQWEsQ0FDdkUsQ0FBQztFQUVELE1BQU1yRixVQUFVLEdBQUcsSUFBQW1ELGtCQUFXLEVBQzVCLENBQ0V3SixPQUFlLEVBQ2Y5TSxRQUFnQixFQUNoQkMsU0FBa0IsRUFDbEI4TSxTQUFpQixFQUNqQkMsVUFBa0IsS0FDZjtJQUNILElBQUksQ0FBQzVILE9BQU8sRUFBRTZILE1BQU0sRUFBRTtJQUN0QixNQUFNQyxNQUFNLEdBQUcsSUFBQUMsdUJBQWEsRUFBQ0wsT0FBTyxFQUFFQyxTQUFTLEVBQUUvTSxRQUFRLEVBQUVnTixVQUFVLENBQUM7SUFDdEUsSUFBSUUsTUFBTSxFQUFFO01BQ1YsSUFBSUEsTUFBTSxLQUFLLGFBQWEsRUFBRTVHLFFBQVEsQ0FBQzhHLG1CQUFTLENBQUMsYUFBYSxDQUFDLENBQUM7TUFDaEUsT0FBTyxDQUFDO0lBQ1Y7SUFDQSxNQUFNdEssSUFBSSxHQUFHdUYsVUFBVSxDQUFDMEUsU0FBUyxDQUFDO0lBQ2xDLElBQUksQ0FBQ2pLLElBQUksRUFBRTtJQUNYLE1BQU11SyxFQUFFLEdBQUcsSUFBQWhSLG9CQUFVLEVBQUMyUSxVQUFVLEVBQUUsSUFBQTlLLGtCQUFRLEVBQUM2SyxTQUFTLEVBQUUsSUFBQU8sa0JBQVEsRUFBQ1IsT0FBTyxDQUFDLENBQUMsQ0FBQztJQUN6RTtJQUNBO0lBQ0EsTUFBTTdLLEtBQUssR0FDVHRILEtBQUssQ0FBQzRTLFVBQVUsQ0FBQyxJQUFBM0IsZUFBSyxFQUFDa0IsT0FBTyxDQUFDLENBQUMsRUFBRXZFLElBQUksQ0FBRWlGLEVBQUUsSUFBS0EsRUFBRSxDQUFDblQsSUFBSSxLQUFLLElBQUFpVCxrQkFBUSxFQUFDUixPQUFPLENBQUMsQ0FBQyxJQUM3RTtNQUFFelMsSUFBSSxFQUFFLElBQUFpVCxrQkFBUSxFQUFDUixPQUFPLENBQUM7TUFBRXhTLEtBQUssRUFBRTJGO0lBQVUsQ0FBQztJQUMvQyxJQUFBd04sb0JBQVMsRUFBQ3JCLFVBQVUsRUFBRXRKLElBQUksRUFBRWdLLE9BQU8sRUFBRTdLLEtBQUssRUFBRW9MLEVBQUUsQ0FBQztFQUNqRCxDQUFDLEVBQ0QsQ0FBQ2pJLE9BQU8sRUFBRWdILFVBQVUsRUFBRS9ELFVBQVUsRUFBRTFOLEtBQUssQ0FDekMsQ0FBQztFQUVELE1BQU15RixZQUFZLEdBQUcsSUFBQWtELGtCQUFXLEVBQzlCLENBQUN6RCxLQUFhLEVBQUU2TixZQUFvQixFQUFFaFQsUUFBaUIsS0FBSztJQUMxRCxJQUFJLENBQUMwSyxPQUFPLEVBQUVnRSxNQUFNLElBQUksQ0FBQzFPLFFBQVEsSUFBSSxDQUFDbUYsS0FBSyxDQUFDRSxNQUFNLEVBQUU7SUFDcEQsTUFBTStDLElBQUksR0FBR3VGLFVBQVUsQ0FBQ3FGLFlBQVksQ0FBQztJQUNyQyxJQUFJLENBQUM1SyxJQUFJLEVBQUU7SUFDWCxJQUFBNkssb0JBQVMsRUFBQ3ZCLFVBQVUsRUFBRXRKLElBQUksRUFBRTRLLFlBQVksRUFBRSxJQUFBclIsb0JBQVUsRUFBQ3lHLElBQUksQ0FBQzFJLElBQUksRUFBRXNULFlBQVksQ0FBQyxFQUFFN04sS0FBSyxDQUFDO0VBQ3ZGLENBQUMsRUFDRCxDQUFDdUYsT0FBTyxFQUFFZ0gsVUFBVSxFQUFFL0QsVUFBVSxDQUNsQyxDQUFDO0VBRUQsTUFBTXRKLFlBQVksR0FBRyxJQUFBdUUsa0JBQVcsRUFDOUIsQ0FBQ25HLE9BQWUsRUFBRTdDLEtBQWMsS0FBSztJQUNuQyxJQUFJLENBQUM4SyxPQUFPLEVBQUVyRyxZQUFZLEVBQUU7SUFDNUIsTUFBTStELElBQUksR0FBR3VGLFVBQVUsQ0FBQ2xMLE9BQU8sQ0FBQztJQUNoQyxJQUFJLENBQUMyRixJQUFJLEVBQUU7SUFDWHNDLE9BQU8sQ0FBQ3JHLFlBQVksQ0FBQytELElBQUksRUFBRSxJQUFBekcsb0JBQVUsRUFBQ3lHLElBQUksQ0FBQzFJLElBQUksRUFBRStDLE9BQU8sQ0FBQyxFQUFFN0MsS0FBSyxDQUFDO0VBQ25FLENBQUMsRUFDRCxDQUFDOEssT0FBTyxFQUFFaUQsVUFBVSxDQUN0QixDQUFDO0VBRUQsTUFBTXBKLGFBQWEsR0FBRyxJQUFBcUUsa0JBQVcsRUFBQyxNQUFNO0lBQ3RDOEIsT0FBTyxFQUFFbkcsYUFBYSxHQUFHLENBQUM7RUFDNUIsQ0FBQyxFQUFFLENBQUNtRyxPQUFPLENBQUMsQ0FBQztFQUViLE1BQU13SSxRQUFRLEdBQUcsSUFBQXRLLGtCQUFXLEVBQzFCLENBQUNuRyxPQUFlLEVBQUU3QyxLQUFjLEVBQUVFLFFBQWdCLEtBQUs7SUFDckQsSUFBSSxDQUFDNEssT0FBTyxFQUFFeUksTUFBTSxFQUFFO0lBQ3RCLE1BQU0vSyxJQUFJLEdBQUd1RixVQUFVLENBQUNsTCxPQUFPLENBQUM7SUFDaEMsSUFBSSxDQUFDMkYsSUFBSSxFQUFFO0lBQ1gsTUFBTTZKLFFBQVEsR0FBRyxJQUFBdFEsb0JBQVUsRUFBQzdCLFFBQVEsRUFBRTJDLE9BQU8sQ0FBQztJQUM5QyxJQUFJLENBQUMyUSxNQUFNLENBQUNDLE9BQU8sQ0FBQyxVQUFVelQsS0FBSyxHQUFHLFFBQVEsR0FBRyxNQUFNLElBQUlxUyxRQUFRLEdBQUcsQ0FBQyxFQUNyRTtJQUNGLE1BQU0xSyxLQUFLLEdBQ1R0SCxLQUFLLENBQUM0UyxVQUFVLENBQUMsSUFBQTNCLGVBQUssRUFBQ3pPLE9BQU8sQ0FBQyxDQUFDLEVBQUVvTCxJQUFJLENBQUVpRixFQUFFLElBQUtBLEVBQUUsQ0FBQ25ULElBQUksS0FBSyxJQUFBaVQsa0JBQVEsRUFBQ25RLE9BQU8sQ0FBQyxDQUFDLElBQzdFO01BQUU5QyxJQUFJLEVBQUUsSUFBQWlULGtCQUFRLEVBQUNuUSxPQUFPLENBQUM7TUFBRTdDO0lBQU0sQ0FBQztJQUNwQyxJQUFBMFQsb0JBQVMsRUFBQzVCLFVBQVUsRUFBRXRKLElBQUksRUFBRSxJQUFBOEksZUFBSyxFQUFDek8sT0FBTyxDQUFDLEVBQUU4RSxLQUFLLEVBQUUwSyxRQUFRLENBQUM7RUFDOUQsQ0FBQyxFQUNELENBQUN2SCxPQUFPLEVBQUVnSCxVQUFVLEVBQUUvRCxVQUFVLEVBQUUxTixLQUFLLENBQ3pDLENBQUM7O0VBRUQ7RUFDQSxNQUFNc1QsUUFBUSxHQUFHLElBQUEzSyxrQkFBVyxFQUMxQixDQUFDeEosQ0FBMkUsRUFBRW9VLEdBQVcsS0FBSztJQUM1RjtJQUNBO0lBQ0E7SUFDQWhILGVBQWUsQ0FBQ0ksT0FBTyxHQUNyQnhOLENBQUMsQ0FBQ29FLGFBQWEsWUFBWWlRLFdBQVcsR0FBR3JVLENBQUMsQ0FBQ29FLGFBQWEsR0FBRyxJQUFJO0lBQ2pFLE1BQU1rUSxLQUFpQixHQUFHLEVBQUU7SUFDNUIsTUFBTXRMLElBQUksR0FBR3VGLFVBQVUsQ0FBQzZGLEdBQUcsQ0FBQy9RLE9BQU8sQ0FBQztJQUNwQyxNQUFNd1AsUUFBUSxHQUFHLElBQUF0USxvQkFBVSxFQUFDNlIsR0FBRyxDQUFDMVQsUUFBUSxFQUFFMFQsR0FBRyxDQUFDL1EsT0FBTyxDQUFDO0lBQ3RELElBQUksQ0FBQytRLEdBQUcsQ0FBQzVULEtBQUssSUFBSThLLE9BQU8sRUFBRWpLLElBQUksSUFBSTJILElBQUksRUFBRTtNQUN2Q3NMLEtBQUssQ0FBQ2pDLElBQUksQ0FBQztRQUNUdE8sR0FBRyxFQUFFLE1BQU07UUFDWDBGLEtBQUssRUFBRSxNQUFNO1FBQ2I4SyxJQUFJLGVBQUUsSUFBQTVVLFdBQUEsQ0FBQWdJLEdBQUEsRUFBQ2hKLFlBQUEsQ0FBQTZWLFlBQVk7VUFBQzVNLElBQUksRUFBRTtRQUFHLENBQUUsQ0FBQztRQUNoQytELFFBQVEsRUFBRUEsQ0FBQSxLQUFNaUgsWUFBWSxDQUFDNUosSUFBSSxFQUFFNkosUUFBUTtNQUM3QyxDQUFDLENBQUM7SUFDSjtJQUNBLElBQUl1QixHQUFHLENBQUN4VCxRQUFRLEVBQUU7TUFDaEIsTUFBTTZULE9BQU8sR0FBR0wsR0FBRyxDQUFDNVQsS0FBSyxHQUFHNFQsR0FBRyxDQUFDL1EsT0FBTyxHQUFHLElBQUF5TyxlQUFLLEVBQUNzQyxHQUFHLENBQUMvUSxPQUFPLENBQUM7TUFDNUQsSUFBSWlJLE9BQU8sRUFBRW9KLFVBQVUsRUFBRTtRQUN2QkosS0FBSyxDQUFDakMsSUFBSSxDQUFDO1VBQ1R0TyxHQUFHLEVBQUUsVUFBVTtVQUNmMEYsS0FBSyxFQUFFLGVBQWU7VUFDdEI4SyxJQUFJLGVBQUUsSUFBQTVVLFdBQUEsQ0FBQWdJLEdBQUEsRUFBQ2hKLFlBQUEsQ0FBQWdXLFFBQVE7WUFBQy9NLElBQUksRUFBRTtVQUFHLENBQUUsQ0FBQztVQUM1QitELFFBQVEsRUFBRUEsQ0FBQSxLQUFNO1lBQ2RzQixTQUFTLENBQUM7Y0FDUnRDLElBQUksRUFBRSxhQUFhO2NBQ25COEosT0FBTztjQUNQL1QsUUFBUSxFQUFFMFQsR0FBRyxDQUFDMVQ7WUFDaEIsQ0FBQyxDQUFDO1lBQ0Z5TSxjQUFjLENBQUMsRUFBRSxDQUFDO1VBQ3BCO1FBQ0YsQ0FBQyxDQUFDO01BQ0o7TUFDQSxJQUFJN0IsT0FBTyxFQUFFc0osWUFBWSxFQUFFO1FBQ3pCTixLQUFLLENBQUNqQyxJQUFJLENBQUM7VUFDVHRPLEdBQUcsRUFBRSxZQUFZO1VBQ2pCMEYsS0FBSyxFQUFFLGlCQUFpQjtVQUN4QjhLLElBQUksZUFBRSxJQUFBNVUsV0FBQSxDQUFBZ0ksR0FBQSxFQUFDaEosWUFBQSxDQUFBa1csVUFBVTtZQUFDak4sSUFBSSxFQUFFO1VBQUcsQ0FBRSxDQUFDO1VBQzlCK0QsUUFBUSxFQUFFQSxDQUFBLEtBQU07WUFDZHNCLFNBQVMsQ0FBQztjQUNSdEMsSUFBSSxFQUFFLGVBQWU7Y0FDckI4SixPQUFPO2NBQ1AvVCxRQUFRLEVBQUUwVCxHQUFHLENBQUMxVDtZQUNoQixDQUFDLENBQUM7WUFDRnlNLGNBQWMsQ0FBQyxFQUFFLENBQUM7VUFDcEI7UUFDRixDQUFDLENBQUM7TUFDSjtNQUNBLElBQUk3QixPQUFPLEVBQUVnRSxNQUFNLEVBQUU7UUFDbkJnRixLQUFLLENBQUNqQyxJQUFJLENBQUM7VUFDVHRPLEdBQUcsRUFBRSxRQUFRO1VBQ2IwRixLQUFLLEVBQUUsY0FBYztVQUNyQjhLLElBQUksZUFBRSxJQUFBNVUsV0FBQSxDQUFBZ0ksR0FBQSxFQUFDaEosWUFBQSxDQUFBbVcsTUFBTTtZQUFDbE4sSUFBSSxFQUFFO1VBQUcsQ0FBRSxDQUFDO1VBQzFCK0QsUUFBUSxFQUFFQSxDQUFBLEtBQU07WUFDZCtCLGVBQWUsQ0FBQ0YsT0FBTyxHQUFHO2NBQ3hCK0IsR0FBRyxFQUFFLElBQUFoTixvQkFBVSxFQUFDNlIsR0FBRyxDQUFDMVQsUUFBUSxFQUFFK1QsT0FBTyxDQUFDO2NBQ3RDL1QsUUFBUSxFQUFFMFQsR0FBRyxDQUFDMVQ7WUFDaEIsQ0FBQztZQUNEK00sY0FBYyxDQUFDRCxPQUFPLEVBQUVnQyxLQUFLLENBQUMsQ0FBQztVQUNqQztRQUNGLENBQUMsQ0FBQztNQUNKO01BQ0EsSUFBSSxDQUFDLElBQUF1RixxQkFBVyxFQUFDbEMsUUFBUSxDQUFDLElBQUl1QixHQUFHLENBQUMvUSxPQUFPLEtBQUsrUSxHQUFHLENBQUMxVCxRQUFRLEVBQUU7UUFDMUQsSUFBSTRLLE9BQU8sRUFBRTZILE1BQU0sRUFBRTtVQUNuQjtVQUNBO1VBQ0FtQixLQUFLLENBQUNqQyxJQUFJLENBQUM7WUFDVHRPLEdBQUcsRUFBRSxTQUFTO1lBQ2QwRixLQUFLLEVBQUUsVUFBVTtZQUNqQjhLLElBQUksZUFBRSxJQUFBNVUsV0FBQSxDQUFBZ0ksR0FBQSxFQUFDaEosWUFBQSxDQUFBcVcsV0FBVztjQUFDcE4sSUFBSSxFQUFFO1lBQUcsQ0FBRSxDQUFDO1lBQy9CK0QsUUFBUSxFQUFFQSxDQUFBLEtBQ1JpQixhQUFhLENBQUM7Y0FDWnZKLE9BQU8sRUFBRStRLEdBQUcsQ0FBQy9RLE9BQU87Y0FDcEIzQyxRQUFRLEVBQUUwVCxHQUFHLENBQUMxVCxRQUFRO2NBQ3RCSCxJQUFJLEVBQUUsSUFBQWlULGtCQUFRLEVBQUNZLEdBQUcsQ0FBQy9RLE9BQU8sQ0FBQztjQUMzQjdDLEtBQUssRUFBRTRULEdBQUcsQ0FBQzVUO1lBQ2IsQ0FBQztVQUNMLENBQUMsQ0FBQztVQUNGOFQsS0FBSyxDQUFDakMsSUFBSSxDQUFDO1lBQ1R0TyxHQUFHLEVBQUUsUUFBUTtZQUNiMEYsS0FBSyxFQUFFLFNBQVM7WUFDaEI4SyxJQUFJLGVBQUUsSUFBQTVVLFdBQUEsQ0FBQWdJLEdBQUEsRUFBQ2hKLFlBQUEsQ0FBQW1KLE1BQU07Y0FBQ0YsSUFBSSxFQUFFO1lBQUcsQ0FBRSxDQUFDO1lBQzFCK0QsUUFBUSxFQUFFQSxDQUFBLEtBQU07Y0FDZHNCLFNBQVMsQ0FBQztnQkFDUnRDLElBQUksRUFBRSxRQUFRO2dCQUNkc0ssU0FBUyxFQUFFYixHQUFHLENBQUMvUSxPQUFPO2dCQUN0QjNDLFFBQVEsRUFBRTBULEdBQUcsQ0FBQzFULFFBQVE7Z0JBQ3RCd1UsT0FBTyxFQUFFLElBQUExQixrQkFBUSxFQUFDWSxHQUFHLENBQUMvUSxPQUFPLENBQUM7Z0JBQzlCN0MsS0FBSyxFQUFFNFQsR0FBRyxDQUFDNVQ7Y0FDYixDQUFDLENBQUM7Y0FDRjJNLGNBQWMsQ0FBQyxJQUFBcUcsa0JBQVEsRUFBQ1ksR0FBRyxDQUFDL1EsT0FBTyxDQUFDLENBQUM7WUFDdkM7VUFDRixDQUFDLENBQUM7UUFDSjtRQUNBLElBQUlpSSxPQUFPLEVBQUV5SSxNQUFNLEVBQUU7VUFDbkJPLEtBQUssQ0FBQ2pDLElBQUksQ0FBQztZQUNUdE8sR0FBRyxFQUFFLFFBQVE7WUFDYjBGLEtBQUssRUFBRSxRQUFRO1lBQ2Y4SyxJQUFJLGVBQUUsSUFBQTVVLFdBQUEsQ0FBQWdJLEdBQUEsRUFBQ2hKLFlBQUEsQ0FBQXdXLE1BQU07Y0FBQ3ZOLElBQUksRUFBRTtZQUFHLENBQUUsQ0FBQztZQUMxQndOLE1BQU0sRUFBRSxJQUFJO1lBQ1p6SixRQUFRLEVBQUVBLENBQUEsS0FBTW1JLFFBQVEsQ0FBQ00sR0FBRyxDQUFDL1EsT0FBTyxFQUFFK1EsR0FBRyxDQUFDNVQsS0FBSyxFQUFFNFQsR0FBRyxDQUFDMVQsUUFBUTtVQUMvRCxDQUFDLENBQUM7UUFDSjtNQUNGO0lBQ0Y7SUFDQTtJQUNBLElBQUkwTCxjQUFjLEVBQUVrSSxLQUFLLENBQUNqQyxJQUFJLENBQUMsR0FBR2pHLGNBQWMsQ0FBQ2dJLEdBQUcsQ0FBQyxDQUFDO0lBQ3RELElBQUksQ0FBQ0UsS0FBSyxDQUFDck8sTUFBTSxFQUFFO0lBQ25CeUcsT0FBTyxDQUFDO01BQUVsSixDQUFDLEVBQUV4RCxDQUFDLENBQUMyRCxPQUFPO01BQUVGLENBQUMsRUFBRXpELENBQUMsQ0FBQzRELE9BQU87TUFBRTBRLEtBQUs7TUFBRWUsT0FBTyxFQUFFakksZUFBZSxDQUFDSTtJQUFRLENBQUMsQ0FBQztFQUNsRixDQUFDLEVBQ0QsQ0FBQ2xDLE9BQU8sRUFBRWlELFVBQVUsRUFBRXFFLFlBQVksRUFBRWtCLFFBQVEsRUFBRTFILGNBQWMsQ0FDOUQsQ0FBQztFQUVELE1BQU10TCxRQUFzQixHQUFHLElBQUF1TixjQUFPLEVBQ3BDLE9BQU87SUFDTHBLLFVBQVUsRUFBRTZPLGNBQWM7SUFDMUJwUCxNQUFNLEVBQUV5USxRQUFRO0lBQ2hCOU4sVUFBVTtJQUNWQyxZQUFZO0lBQ1pyQixZQUFZLEVBQUVBLENBQUM1QixPQUFPLEVBQUU3QyxLQUFLLEtBQUt5RSxZQUFZLENBQUM1QixPQUFPLEVBQUU3QyxLQUFLLENBQUM7SUFDOUQyRSxhQUFhO0lBQ2IyTyxRQUFRLEVBQUV4SSxPQUFPLEVBQUV5SSxNQUFNLEdBQ3JCRCxRQUFRLEdBQ1B2UztFQUNQLENBQUMsQ0FBQyxFQUNGLENBQ0V1UixjQUFjLEVBQ2RxQixRQUFRLEVBQ1I5TixVQUFVLEVBQ1ZDLFlBQVksRUFDWnJCLFlBQVksRUFDWkUsYUFBYSxFQUNiMk8sUUFBUSxFQUNSeEksT0FBTyxDQUVYLENBQUM7RUFFRCxNQUFNZ0ssWUFBWSxHQUFHQSxDQUFBLEtBQU07SUFDekIsSUFBSWhJLG1CQUFtQixDQUFDRSxPQUFPLEVBQUUsT0FBTyxDQUFDO0lBQ3pDLE1BQU1nQixDQUFDLEdBQUd4QixNQUFNO0lBQ2hCQyxTQUFTLENBQUMsSUFBSSxDQUFDO0lBQ2YsSUFBSSxDQUFDdUIsQ0FBQyxFQUFFO0lBQ1IsTUFBTStHLEtBQUssR0FBR3JJLFdBQVcsQ0FBQ3NJLElBQUksQ0FBQyxDQUFDLENBQUNDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDO0lBQ3BEdEksY0FBYyxDQUFDLEVBQUUsQ0FBQztJQUNsQixJQUFJLENBQUNvSSxLQUFLLEVBQUU7SUFDWixNQUFNdk0sSUFBSSxHQUNSdUYsVUFBVSxDQUFDQyxDQUFDLENBQUM5TixRQUFRLEtBQUssRUFBRSxHQUFHLEVBQUUsR0FBRzhOLENBQUMsQ0FBQzlOLFFBQVEsQ0FBQyxJQUMvQzBOLE9BQU8sQ0FBQ0ssSUFBSSxDQUFFQyxDQUFDLElBQUtBLENBQUMsQ0FBQ3BPLElBQUksS0FBS2tPLENBQUMsQ0FBQzlOLFFBQVEsQ0FBQyxJQUMxQyxJQUFJO0lBQ04sSUFBSSxDQUFDc0ksSUFBSSxFQUFFO0lBQ1gsSUFBSXdGLENBQUMsQ0FBQzdELElBQUksS0FBSyxRQUFRLEVBQUU7TUFDdkIsSUFBSSxDQUFDVyxPQUFPLEVBQUU2SCxNQUFNLEVBQUU7TUFDdEIsTUFBTXVDLE9BQU8sR0FBRyxJQUFBblQsb0JBQVUsRUFBQ2lNLENBQUMsQ0FBQzlOLFFBQVEsRUFBRThOLENBQUMsQ0FBQ3lHLFNBQVMsQ0FBQztNQUNuRCxNQUFNVSxLQUFLLEdBQUcsSUFBQXZOLGtCQUFRLEVBQUMsSUFBQTBKLGVBQUssRUFBQzRELE9BQU8sQ0FBQyxFQUFFLElBQUFsQyxrQkFBUSxFQUFDK0IsS0FBSyxDQUFDLENBQUM7TUFDdkQsSUFBQTVCLG9CQUFTLEVBQUNyQixVQUFVLEVBQUV0SixJQUFJLEVBQUV3RixDQUFDLENBQUN5RyxTQUFTLEVBQUU7UUFBRTFVLElBQUksRUFBRWlPLENBQUMsQ0FBQzBHLE9BQU87UUFBRTFVLEtBQUssRUFBRWdPLENBQUMsQ0FBQ2hPO01BQU0sQ0FBQyxFQUFFbVYsS0FBSyxDQUFDO0lBQ3RGLENBQUMsTUFBTTtNQUNMLE1BQU01QyxHQUFHLEdBQUcsSUFBQTNLLGtCQUFRLEVBQUMsSUFBQTdGLG9CQUFVLEVBQUNpTSxDQUFDLENBQUM5TixRQUFRLEVBQUU4TixDQUFDLENBQUNpRyxPQUFPLENBQUMsRUFBRWMsS0FBSyxDQUFDO01BQzlELElBQUkvRyxDQUFDLENBQUM3RCxJQUFJLEtBQUssYUFBYSxFQUFFO1FBQzVCLElBQUksQ0FBQ1csT0FBTyxFQUFFb0osVUFBVSxFQUFFO1FBQzFCLElBQUFrQixvQkFBUyxFQUFDdEQsVUFBVSxFQUFFLE1BQU0sRUFBRXRKLElBQUksRUFBRXdGLENBQUMsQ0FBQ2lHLE9BQU8sRUFBRTFCLEdBQUcsQ0FBQztNQUNyRCxDQUFDLE1BQU07UUFDTCxJQUFJLENBQUN6SCxPQUFPLEVBQUVzSixZQUFZLEVBQUU7UUFDNUIsSUFBQWdCLG9CQUFTLEVBQUN0RCxVQUFVLEVBQUUsUUFBUSxFQUFFdEosSUFBSSxFQUFFd0YsQ0FBQyxDQUFDaUcsT0FBTyxFQUFFMUIsR0FBRyxDQUFDO01BQ3ZEO0lBQ0Y7RUFDRixDQUFDO0VBRUQsTUFBTThDLGFBQWEsR0FBSTdWLENBQXNDLElBQUs7SUFDaEUsTUFBTStGLEtBQUssR0FBR0MsS0FBSyxDQUFDakIsSUFBSSxDQUFDL0UsQ0FBQyxDQUFDOFYsTUFBTSxDQUFDL1AsS0FBSyxJQUFJLEVBQUUsQ0FBQztJQUM5QyxNQUFNK1AsTUFBTSxHQUFHcEksZUFBZSxDQUFDRixPQUFPO0lBQ3RDeE4sQ0FBQyxDQUFDOFYsTUFBTSxDQUFDUCxLQUFLLEdBQUcsRUFBRTtJQUNuQixJQUFJLENBQUN4UCxLQUFLLENBQUNFLE1BQU0sSUFBSSxDQUFDNlAsTUFBTSxJQUFJLENBQUN4SyxPQUFPLEVBQUVnRSxNQUFNLEVBQUU7SUFDbEQ7SUFDQSxNQUFNdEcsSUFBSSxHQUFHdUYsVUFBVSxDQUFDdUgsTUFBTSxDQUFDcFYsUUFBUSxDQUFDO0lBQ3hDLElBQUksQ0FBQ3NJLElBQUksRUFBRTtJQUNYLElBQUE2SyxvQkFBUyxFQUFDdkIsVUFBVSxFQUFFdEosSUFBSSxFQUFFLElBQUErTSxpQkFBTyxFQUFDL00sSUFBSSxDQUFDMUksSUFBSSxFQUFFd1YsTUFBTSxDQUFDdkcsR0FBRyxDQUFDLEVBQUV1RyxNQUFNLENBQUN2RyxHQUFHLEVBQUV4SixLQUFLLENBQUM7RUFDaEYsQ0FBQztFQUVELE1BQU1pUSxRQUFRLEdBQUc1SCxPQUFPLENBQUNuSSxNQUFNLEdBQUcsQ0FBQztFQUNuQyxNQUFNNEIsS0FBSyxHQUFHd0UsTUFBTSxFQUFFeEUsS0FBSyxJQUFJLE9BQU87RUFDdEMsTUFBTW9PLEtBQUssR0FBRzVKLE1BQU0sRUFBRTRKLEtBQUssaUJBQUksSUFBQXRXLFdBQUEsQ0FBQWdJLEdBQUEsRUFBQ2hKLFlBQUEsQ0FBQXVYLFVBQVU7SUFBQ3RPLElBQUksRUFBRSxFQUFHO0lBQUMsZUFBWTtFQUFNLENBQUUsQ0FBQztFQUUxRSxvQkFDRSxJQUFBakksV0FBQSxDQUFBZ0gsSUFBQTtJQUFTRyxTQUFTLEVBQUMsZUFBZTtJQUFDLGNBQVllLEtBQU07SUFBQ3NPLEdBQUcsRUFBRXJHLFVBQVc7SUFBQWpKLFFBQUEsZ0JBQ3BFLElBQUFsSCxXQUFBLENBQUFnSCxJQUFBO01BQVFHLFNBQVMsRUFBQyxhQUFhO01BQUFELFFBQUEsZ0JBQzdCLElBQUFsSCxXQUFBLENBQUFnSSxHQUFBO1FBQU1iLFNBQVMsRUFBQyxjQUFjO1FBQUFELFFBQUEsRUFBRW9QO01BQUssQ0FBTyxDQUFDLGVBQzdDLElBQUF0VyxXQUFBLENBQUFnSSxHQUFBO1FBQU1iLFNBQVMsRUFBQyxjQUFjO1FBQUFELFFBQUEsRUFBRWdCO01BQUssQ0FBTyxDQUFDLEVBTTVDLENBQUNtTyxRQUFRLElBQUkzSixNQUFNLEVBQUVmLE9BQU87TUFBQTtNQUMzQjtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0EsSUFBQTNMLFdBQUEsQ0FBQWdILElBQUE7UUFDRUcsU0FBUyxFQUNQLGdCQUFnQixJQUNmdUYsTUFBTSxFQUFFZixPQUFPLEdBQUcsd0JBQXdCLEdBQUcsRUFBRSxDQUNqRDtRQUFBekUsUUFBQSxHQUVBbVAsUUFBUSxpQkFDUCxJQUFBclcsV0FBQSxDQUFBZ0gsSUFBQSxFQUFBaEgsV0FBQSxDQUFBeVcsUUFBQTtVQUFBdlAsUUFBQSxHQUtHeUUsT0FBTyxFQUFFZ0UsTUFBTSxJQUFJVixVQUFVLGlCQUM1QixJQUFBalAsV0FBQSxDQUFBZ0ksR0FBQTtZQUNFbUQsSUFBSSxFQUFDLFFBQVE7WUFDYmhFLFNBQVMsRUFBQyxlQUFlO1lBQ3pCZSxLQUFLLEVBQUUsbUJBQW1CdUgsZUFBZSxFQUFHO1lBQzVDLGNBQVksbUJBQW1CQSxlQUFlLEVBQUc7WUFDakQvSCxPQUFPLEVBQUVnSSxnQkFBaUI7WUFBQXhJLFFBQUEsZUFFMUIsSUFBQWxILFdBQUEsQ0FBQWdJLEdBQUEsRUFBQ2hKLFlBQUEsQ0FBQW1XLE1BQU07Y0FBQ2xOLElBQUksRUFBRSxFQUFHO2NBQUMsZUFBWTtZQUFNLENBQUU7VUFBQyxDQUNqQyxDQUNULGVBQ0QsSUFBQWpJLFdBQUEsQ0FBQWdJLEdBQUEsRUFBQzVJLGVBQUEsQ0FBQW1CLE9BQWM7WUFBQ3FWLEtBQUssRUFBRXZKLE1BQU87WUFBQ3FLLFFBQVEsRUFBRTFFO1VBQWEsQ0FBRSxDQUFDLEVBQ3hEM0YsTUFBTSxLQUFLLE1BQU0saUJBQ2hCLElBQUFyTSxXQUFBLENBQUFnSSxHQUFBO1lBQ0VtRCxJQUFJLEVBQUMsUUFBUTtZQUNiaEUsU0FBUyxFQUFDLGVBQWU7WUFDekJlLEtBQUssRUFBQyxzQkFBc0I7WUFDNUIsY0FBVyxzQkFBc0I7WUFDakNSLE9BQU8sRUFBRUEsQ0FBQSxLQUFNeEcsS0FBSyxDQUFDeVYsV0FBVyxDQUFDLENBQUU7WUFBQXpQLFFBQUEsZUFFbkMsSUFBQWxILFdBQUEsQ0FBQWdJLEdBQUEsRUFBQ2hKLFlBQUEsQ0FBQTRYLGNBQWM7Y0FBQzNPLElBQUksRUFBRSxFQUFHO2NBQUMsZUFBWTtZQUFNLENBQUU7VUFBQyxDQUN6QyxDQUNUO1FBQUEsQ0FDRCxDQUNILEVBQ0F5RSxNQUFNLEVBQUVmLE9BQU87TUFBQSxDQUNiLENBQ047SUFBQSxDQUNLLENBQUMsRUFRUmUsTUFBTSxFQUFFbUssSUFBSSxpQkFBSSxJQUFBN1csV0FBQSxDQUFBZ0ksR0FBQTtNQUFLYixTQUFTLEVBQUMsYUFBYTtNQUFBRCxRQUFBLEVBQUV3RixNQUFNLENBQUNtSztJQUFJLENBQU0sQ0FBQyxFQUVoRWpLLEtBQUssaUJBQ0osSUFBQTVNLFdBQUEsQ0FBQWdILElBQUE7TUFBS0csU0FBUyxFQUFDLGNBQWM7TUFBQ0YsSUFBSSxFQUFDLE9BQU87TUFBQUMsUUFBQSxHQUN2QzBGLEtBQUssZUFDTixJQUFBNU0sV0FBQSxDQUFBZ0ksR0FBQTtRQUNFbUQsSUFBSSxFQUFDLFFBQVE7UUFDYmhFLFNBQVMsRUFBQyxzQkFBc0I7UUFDaENPLE9BQU8sRUFBRUEsQ0FBQSxLQUFNbUYsUUFBUSxDQUFDLElBQUksQ0FBRTtRQUFBM0YsUUFBQSxFQUMvQjtNQUVELENBQVEsQ0FBQztJQUFBLENBQ04sQ0FDTixlQUtELElBQUFsSCxXQUFBLENBQUFnSSxHQUFBO01BQUtiLFNBQVMsRUFBQyxXQUFXO01BQUNGLElBQUksRUFBQyxRQUFRO01BQUFDLFFBQUEsRUFDckNnRztJQUFTLENBQ1AsQ0FBQyxFQUVMRyxNQUFNLGlCQUNMLElBQUFyTixXQUFBLENBQUFnSSxHQUFBO01BQUtiLFNBQVMsRUFBQyxlQUFlO01BQUFELFFBQUEsZUFDNUIsSUFBQWxILFdBQUEsQ0FBQWdJLEdBQUE7UUFDRXdPLEdBQUcsRUFBRTVJLGNBQWU7UUFDcEJ6RyxTQUFTLEVBQUMscUJBQXFCO1FBQy9CMlAsVUFBVSxFQUFFLEtBQU07UUFDbEIsY0FDRXpKLE1BQU0sQ0FBQ3JDLElBQUksS0FBSyxRQUFRLEdBQ3BCLFVBQVVxQyxNQUFNLENBQUNrSSxPQUFPLEVBQUUsR0FDMUIsT0FBT2xJLE1BQU0sQ0FBQ3JDLElBQUksS0FBSyxlQUFlLEdBQUcsUUFBUSxHQUFHLE1BQU0sT0FBTyxJQUFBcEksb0JBQVUsRUFBQ3lLLE1BQU0sQ0FBQ3RNLFFBQVEsRUFBRXNNLE1BQU0sQ0FBQ3lILE9BQU8sQ0FBQyxFQUNqSDtRQUNEaUMsV0FBVyxFQUNUMUosTUFBTSxDQUFDckMsSUFBSSxLQUFLLFFBQVEsR0FDcEIsVUFBVSxHQUNWcUMsTUFBTSxDQUFDckMsSUFBSSxLQUFLLGVBQWUsR0FDN0IsYUFBYSxHQUNiLGVBQ1A7UUFDRDRLLEtBQUssRUFBRXJJLFdBQVk7UUFDbkJtSixRQUFRLEVBQUdyVyxDQUFDLElBQUttTixjQUFjLENBQUNuTixDQUFDLENBQUM4VixNQUFNLENBQUNQLEtBQUssQ0FBRTtRQUNoRDFSLFNBQVMsRUFBRzdELENBQUMsSUFBSztVQUNoQixJQUFJQSxDQUFDLENBQUMrRCxHQUFHLEtBQUssT0FBTyxFQUFFdVIsWUFBWSxDQUFDLENBQUMsQ0FBQyxLQUNqQyxJQUFJdFYsQ0FBQyxDQUFDK0QsR0FBRyxLQUFLLFFBQVEsRUFBRTtZQUMzQjtZQUNBO1lBQ0E7WUFDQTtZQUNBdUosbUJBQW1CLENBQUNFLE9BQU8sR0FBRyxJQUFJO1lBQ2xDUCxTQUFTLENBQUMsSUFBSSxDQUFDO1lBQ2ZFLGNBQWMsQ0FBQyxFQUFFLENBQUM7WUFDbEJDLGVBQWUsQ0FBQ0ksT0FBTyxFQUFFaEosS0FBSyxDQUFDLENBQUM7WUFDaEM4SSxtQkFBbUIsQ0FBQ0UsT0FBTyxHQUFHLEtBQUs7VUFDckM7UUFDRixDQUFFO1FBQ0ZtSixNQUFNLEVBQUVyQjtNQUFhLENBQ3RCO0lBQUMsQ0FDQyxDQUNOLGVBRUQsSUFBQTNWLFdBQUEsQ0FBQWdJLEdBQUE7TUFDRXdPLEdBQUcsRUFBRTFJLGNBQWU7TUFDcEIzQyxJQUFJLEVBQUMsTUFBTTtNQUNYOEwsUUFBUTtNQUNSQyxNQUFNO01BQ05SLFFBQVEsRUFBRVIsYUFBYztNQUN4QixlQUFZLE1BQU07TUFDbEI1TyxRQUFRLEVBQUUsQ0FBQztJQUFFLENBQ2QsQ0FBQyxlQUVGLElBQUF0SCxXQUFBLENBQUFnSSxHQUFBO01BQUtiLFNBQVMsRUFBQyxhQUFhO01BQUFELFFBQUEsRUFDekIsQ0FBQ21QLFFBQVEsR0FDUDFKLFVBQVUsaUJBQ1QsSUFBQTNNLFdBQUEsQ0FBQWdILElBQUE7UUFBS0csU0FBUyxFQUFDLE9BQU87UUFBQUQsUUFBQSxnQkFDcEIsSUFBQWxILFdBQUEsQ0FBQWdJLEdBQUE7VUFBTWIsU0FBUyxFQUFDLGFBQWE7VUFBQUQsUUFBQSxlQUMzQixJQUFBbEgsV0FBQSxDQUFBZ0ksR0FBQSxFQUFDaEosWUFBQSxDQUFBdVgsVUFBVTtZQUFDdE8sSUFBSSxFQUFFLEVBQUc7WUFBQyxlQUFZO1VBQU0sQ0FBRTtRQUFDLENBQ3ZDLENBQUMsZUFDUCxJQUFBakksV0FBQSxDQUFBZ0ksR0FBQTtVQUFBZCxRQUFBLEVBQUk7UUFBcUIsQ0FBSSxDQUFDLGVBQzlCLElBQUFsSCxXQUFBLENBQUFnSSxHQUFBO1VBQUFkLFFBQUEsRUFBRztRQUF3RCxDQUFHLENBQUM7TUFBQSxDQUM1RCxDQUNOLEdBQ0NtRixNQUFNLEtBQUssTUFBTSxnQkFDbkIsSUFBQXJNLFdBQUEsQ0FBQWdJLEdBQUEsRUFBQzNJLFNBQUEsQ0FBQWtCLE9BQVE7UUFDUFcsS0FBSyxFQUFFQSxLQUFNO1FBQ2J1TixPQUFPLEVBQUVBLE9BQVE7UUFDakJ0QyxHQUFHLEVBQUVzRixNQUFPO1FBQ1puRCxNQUFNLEVBQUVzRCxXQUFZO1FBQ3BCdUYsVUFBVSxFQUFFdkwsVUFBVztRQUN2QkcsYUFBYSxFQUFFQSxhQUFjO1FBQzdCNUssUUFBUSxFQUFFQTtNQUFTLENBQ3BCLENBQUMsR0FDQWtMLE1BQU0sS0FBSyxPQUFPLGdCQUNwQixJQUFBck0sV0FBQSxDQUFBZ0ksR0FBQSxFQUFDMUksU0FBQSxDQUFBaUIsT0FBUTtRQUNQVyxLQUFLLEVBQUVBLEtBQU07UUFDYnVOLE9BQU8sRUFBRUEsT0FBUTtRQUNqQnRDLEdBQUcsRUFBRXNGLE1BQU87UUFDWm5ELE1BQU0sRUFBRXNELFdBQVk7UUFDcEJ1RixVQUFVLEVBQUV2TCxVQUFXO1FBQ3ZCd0wsVUFBVSxFQUFFdkwsVUFBVztRQUN2QjFLLFFBQVEsRUFBRUE7TUFBUyxDQUNwQixDQUFDLEdBQ0FrTCxNQUFNLEtBQUssU0FBUyxnQkFDdEIsSUFBQXJNLFdBQUEsQ0FBQWdJLEdBQUEsRUFBQ3pJLFdBQUEsQ0FBQWdCLE9BQVU7UUFDVFcsS0FBSyxFQUFFQSxLQUFNO1FBQ2J1TixPQUFPLEVBQUVBLE9BQVE7UUFDakJGLE9BQU8sRUFBRW9ELFVBQVc7UUFDcEJuRCxVQUFVLEVBQUVzRCxZQUFhO1FBQ3pCcUYsVUFBVSxFQUFFdkwsVUFBVztRQUN2QndMLFVBQVUsRUFBRXZMLFVBQVc7UUFDdkIxSyxRQUFRLEVBQUVBO01BQVMsQ0FDcEIsQ0FBQyxHQUVGc04sT0FBTyxDQUFDbEcsR0FBRyxDQUFFd0csQ0FBQyxpQkFDWixJQUFBL08sV0FBQSxDQUFBZ0ksR0FBQSxFQUFDbUIsS0FBSztRQUVKRSxJQUFJLEVBQUUwRixDQUFFO1FBQ1I3TixLQUFLLEVBQUVBLEtBQU07UUFDYkMsUUFBUSxFQUFFQSxRQUFTO1FBQ25CbUksT0FBTyxFQUFFcUMsT0FBTyxFQUFFMEwsS0FBTTtRQUN4QmpXLGtCQUFrQixFQUFFQTtNQUFtQixHQUxsQzJOLENBQUMsQ0FBQ3BPLElBTVIsQ0FDRjtJQUNGLENBQ0UsQ0FBQyxFQUVMbU0sSUFBSSxpQkFBSSxJQUFBOU0sV0FBQSxDQUFBZ0ksR0FBQSxFQUFDOUksWUFBQSxDQUFBcUIsT0FBVztNQUFDK1csTUFBTSxFQUFFeEssSUFBSztNQUFDeUssT0FBTyxFQUFFQSxDQUFBLEtBQU14SyxPQUFPLENBQUMsSUFBSTtJQUFFLENBQUUsQ0FBQyxFQUVuRUMsVUFBVSxpQkFDVCxJQUFBaE4sV0FBQSxDQUFBZ0ksR0FBQSxFQUFDeEksV0FBQSxDQUFBZSxPQUFVO01BQ1Q0VixNQUFNLEVBQUVuSixVQUFXO01BQ25CdkIsS0FBSyxFQUFFZ0QsT0FBUTtNQUNmdk4sS0FBSyxFQUFFQSxLQUFNO01BQ2JzVyxNQUFNLEVBQUVBLENBQUNDLE1BQU0sRUFBRUMsV0FBVyxLQUFLO1FBQy9CaFIsVUFBVSxDQUFDc0csVUFBVSxDQUFDdEosT0FBTyxFQUFFc0osVUFBVSxDQUFDak0sUUFBUSxFQUFFaU0sVUFBVSxDQUFDbk0sS0FBSyxFQUFFNFcsTUFBTSxFQUFFQyxXQUFXLENBQUM7UUFDMUZ6SyxhQUFhLENBQUMsSUFBSSxDQUFDO01BQ3JCLENBQUU7TUFDRnNLLE9BQU8sRUFBRUEsQ0FBQSxLQUFNdEssYUFBYSxDQUFDLElBQUk7SUFBRSxDQUNwQyxDQUNGO0VBQUEsQ0FDTSxDQUFDO0FBRWQ7QUFBQzdNLEdBQUEsQ0F2MUJRb0wsZ0JBQWdCO0VBQUEsUUEyRWUyQyxvQkFBUyxFQStCM0JnQix5QkFBYztBQUFBO0FBQUF3SSxHQUFBLEdBMUczQm5NLGdCQUFnQjtBQUFBLElBQUFvTSxRQUFBLEdBQUFDLE9BQUEsQ0FBQXRYLE9BQUEsR0F5MUJWaUwsZ0JBQWdCO0FBQUEsSUFBQTlLLEVBQUEsRUFBQWdJLEdBQUEsRUFBQVUsR0FBQSxFQUFBbUMsR0FBQSxFQUFBb00sR0FBQTtBQUFBRyxZQUFBLENBQUFwWCxFQUFBO0FBQUFvWCxZQUFBLENBQUFwUCxHQUFBO0FBQUFvUCxZQUFBLENBQUExTyxHQUFBO0FBQUEwTyxZQUFBLENBQUF2TSxHQUFBO0FBQUF1TSxZQUFBLENBQUFILEdBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}