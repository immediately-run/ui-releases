"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.fsAvailable = fsAvailable;
exports.readFile = readFile;
exports.readdir = readdir;
exports.sdkFsSource = void 0;
// Read a mount's directory entries from the sandbox filesystem.
//
// Mounts (a space / a granted subtree / the working tree) are attached into the
// sandbox's own filesystem at their absolute `path` (e.g. `/spaces/{id}`,
// `/mnt/{hash}`) by ZenFS's global `mount()`. To LIST a directory we need a
// node-compatible fs (`promises.readdir`/`stat`) rooted at `/` so those absolute
// mount paths resolve.
//
// IMPORTANT: that is NOT `module.evaluation.module.bundler.fs` — despite the name
// that is the bundler's own layered `FileSystem` (memory + zenfs + node-modules
// layers) whose surface is only `readFile`/`isFile`/`writeFile`; it has no
// `readdir`/`promises`, so reading through it throws on every call. The
// node-compatible fs is the ZenFS bound context the sandbox creates at
// `globalThis.__sandpackSharedFs` (`bindContext({root:'/'})`), mirrored by the
// bundler's `zenFsLayer.boundContext.fs`. We read through its `promises` API and
// tolerate the two common `readdir` shapes (Dirent[] vs string[]).
//
// This helper only works inside the sandbox (where these globals exist); it is
// not exercised in local `vite` dev, so every access is guarded.

/* eslint-disable @typescript-eslint/no-explicit-any */
const hasReaddir = fs => typeof fs?.promises?.readdir === "function" || typeof fs?.readdir === "function";
function sandboxFs() {
  // 1. The sandbox publishes a '/'-rooted bound ZenFS on globalThis — the
  //    canonical node-compatible fs that sees every mount.
  try {
    const shared = globalThis.__sandpackSharedFs;
    if (hasReaddir(shared)) return shared;
  } catch {
    /* not in the sandbox */
  }
  // 2. Fall back to the bundler's ZenFS layer bound context (also '/'-rooted),
  //    reached the same way the SDK reaches other bundler services.
  try {
    // @ts-expect-error - `module` is injected by the sandbox runtime (see SDK mounts.ts)
    const layers = module?.evaluation?.module?.bundler?.fs?.layers;
    if (Array.isArray(layers)) {
      for (const layer of layers) {
        const fs = layer?.boundContext?.fs;
        if (hasReaddir(fs)) return fs;
      }
    }
  } catch {
    /* not in the sandbox */
  }
  return null;
}
const joinPath = (dir, name) => `${dir.replace(/\/+$/, "")}/${name}`;

/** Is the sandbox fs reachable at all? (false in local dev / before boot). */
function fsAvailable() {
  return sandboxFs() != null;
}

/** List `path`'s immediate entries, directories first then files, A→Z. */
async function readdir(path) {
  const fs = sandboxFs();
  if (!fs) throw new Error("sandbox filesystem unavailable");
  const p = fs.promises ?? fs;
  let raw;
  try {
    raw = await p.readdir(path, {
      withFileTypes: true
    });
  } catch {
    raw = await p.readdir(path);
  }
  const entries = [];
  for (const item of raw) {
    if (typeof item === "string") {
      // string[] shape — stat each to learn directory-ness.
      let isDir = false;
      try {
        const st = await p.stat(joinPath(path, item));
        isDir = typeof st?.isDirectory === "function" ? st.isDirectory() : !!st?.isDirectory;
      } catch {
        /* unreadable entry — treat as a file */
      }
      entries.push({
        name: item,
        isDir
      });
    } else {
      // Dirent shape.
      const isDir = typeof item?.isDirectory === "function" ? item.isDirectory() : !!item?.isDirectory;
      entries.push({
        name: String(item?.name ?? item),
        isDir
      });
    }
  }
  return entries.sort((a, b) => a.isDir === b.isDir ? a.name.localeCompare(b.name) : a.isDir ? -1 : 1);
}

/**
 * Read a file's raw bytes from a mount (R3-83 drag-out: the source inlines a small
 * file's content so the host can relay it to the previewed app — the source can only
 * ever hand over bytes it can already read). Throws if the sandbox fs is unavailable
 * or the read fails; callers fall back to a reference-only drag.
 */
async function readFile(path) {
  const fs = sandboxFs();
  if (!fs) throw new Error("sandbox filesystem unavailable");
  const p = fs.promises ?? fs;
  const data = await p.readFile(path);
  return data instanceof Uint8Array ? data : new Uint8Array(data);
}

/** The default {@link FsSource}: the ZenFS sandbox accessor. The headless view
 *  reads bytes/entries through this in the shipped app (a consumer with a
 *  different filesystem supplies its own `FsSource`). */
const sdkFsSource = exports.sdkFsSource = {
  readdir,
  readFile
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJoYXNSZWFkZGlyIiwiZnMiLCJwcm9taXNlcyIsInJlYWRkaXIiLCJzYW5kYm94RnMiLCJzaGFyZWQiLCJnbG9iYWxUaGlzIiwiX19zYW5kcGFja1NoYXJlZEZzIiwibGF5ZXJzIiwibW9kdWxlIiwiZXZhbHVhdGlvbiIsImJ1bmRsZXIiLCJBcnJheSIsImlzQXJyYXkiLCJsYXllciIsImJvdW5kQ29udGV4dCIsImpvaW5QYXRoIiwiZGlyIiwibmFtZSIsInJlcGxhY2UiLCJmc0F2YWlsYWJsZSIsInBhdGgiLCJFcnJvciIsInAiLCJyYXciLCJ3aXRoRmlsZVR5cGVzIiwiZW50cmllcyIsIml0ZW0iLCJpc0RpciIsInN0Iiwic3RhdCIsImlzRGlyZWN0b3J5IiwicHVzaCIsIlN0cmluZyIsInNvcnQiLCJhIiwiYiIsImxvY2FsZUNvbXBhcmUiLCJyZWFkRmlsZSIsImRhdGEiLCJVaW50OEFycmF5Iiwic2RrRnNTb3VyY2UiLCJleHBvcnRzIl0sInNvdXJjZXMiOlsibW91bnRGcy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBSZWFkIGEgbW91bnQncyBkaXJlY3RvcnkgZW50cmllcyBmcm9tIHRoZSBzYW5kYm94IGZpbGVzeXN0ZW0uXG4vL1xuLy8gTW91bnRzIChhIHNwYWNlIC8gYSBncmFudGVkIHN1YnRyZWUgLyB0aGUgd29ya2luZyB0cmVlKSBhcmUgYXR0YWNoZWQgaW50byB0aGVcbi8vIHNhbmRib3gncyBvd24gZmlsZXN5c3RlbSBhdCB0aGVpciBhYnNvbHV0ZSBgcGF0aGAgKGUuZy4gYC9zcGFjZXMve2lkfWAsXG4vLyBgL21udC97aGFzaH1gKSBieSBaZW5GUydzIGdsb2JhbCBgbW91bnQoKWAuIFRvIExJU1QgYSBkaXJlY3Rvcnkgd2UgbmVlZCBhXG4vLyBub2RlLWNvbXBhdGlibGUgZnMgKGBwcm9taXNlcy5yZWFkZGlyYC9gc3RhdGApIHJvb3RlZCBhdCBgL2Agc28gdGhvc2UgYWJzb2x1dGVcbi8vIG1vdW50IHBhdGhzIHJlc29sdmUuXG4vL1xuLy8gSU1QT1JUQU5UOiB0aGF0IGlzIE5PVCBgbW9kdWxlLmV2YWx1YXRpb24ubW9kdWxlLmJ1bmRsZXIuZnNgIOKAlCBkZXNwaXRlIHRoZSBuYW1lXG4vLyB0aGF0IGlzIHRoZSBidW5kbGVyJ3Mgb3duIGxheWVyZWQgYEZpbGVTeXN0ZW1gIChtZW1vcnkgKyB6ZW5mcyArIG5vZGUtbW9kdWxlc1xuLy8gbGF5ZXJzKSB3aG9zZSBzdXJmYWNlIGlzIG9ubHkgYHJlYWRGaWxlYC9gaXNGaWxlYC9gd3JpdGVGaWxlYDsgaXQgaGFzIG5vXG4vLyBgcmVhZGRpcmAvYHByb21pc2VzYCwgc28gcmVhZGluZyB0aHJvdWdoIGl0IHRocm93cyBvbiBldmVyeSBjYWxsLiBUaGVcbi8vIG5vZGUtY29tcGF0aWJsZSBmcyBpcyB0aGUgWmVuRlMgYm91bmQgY29udGV4dCB0aGUgc2FuZGJveCBjcmVhdGVzIGF0XG4vLyBgZ2xvYmFsVGhpcy5fX3NhbmRwYWNrU2hhcmVkRnNgIChgYmluZENvbnRleHQoe3Jvb3Q6Jy8nfSlgKSwgbWlycm9yZWQgYnkgdGhlXG4vLyBidW5kbGVyJ3MgYHplbkZzTGF5ZXIuYm91bmRDb250ZXh0LmZzYC4gV2UgcmVhZCB0aHJvdWdoIGl0cyBgcHJvbWlzZXNgIEFQSSBhbmRcbi8vIHRvbGVyYXRlIHRoZSB0d28gY29tbW9uIGByZWFkZGlyYCBzaGFwZXMgKERpcmVudFtdIHZzIHN0cmluZ1tdKS5cbi8vXG4vLyBUaGlzIGhlbHBlciBvbmx5IHdvcmtzIGluc2lkZSB0aGUgc2FuZGJveCAod2hlcmUgdGhlc2UgZ2xvYmFscyBleGlzdCk7IGl0IGlzXG4vLyBub3QgZXhlcmNpc2VkIGluIGxvY2FsIGB2aXRlYCBkZXYsIHNvIGV2ZXJ5IGFjY2VzcyBpcyBndWFyZGVkLlxuaW1wb3J0IHR5cGUgeyBEaXJFbnRyeSwgRnNTb3VyY2UgfSBmcm9tIFwiLi4vdHlwZXNcIjtcblxuLyogZXNsaW50LWRpc2FibGUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueSAqL1xuY29uc3QgaGFzUmVhZGRpciA9IChmczogYW55KTogYm9vbGVhbiA9PlxuICB0eXBlb2YgZnM/LnByb21pc2VzPy5yZWFkZGlyID09PSBcImZ1bmN0aW9uXCIgfHwgdHlwZW9mIGZzPy5yZWFkZGlyID09PSBcImZ1bmN0aW9uXCI7XG5cbmZ1bmN0aW9uIHNhbmRib3hGcygpOiBhbnkgfCBudWxsIHtcbiAgLy8gMS4gVGhlIHNhbmRib3ggcHVibGlzaGVzIGEgJy8nLXJvb3RlZCBib3VuZCBaZW5GUyBvbiBnbG9iYWxUaGlzIOKAlCB0aGVcbiAgLy8gICAgY2Fub25pY2FsIG5vZGUtY29tcGF0aWJsZSBmcyB0aGF0IHNlZXMgZXZlcnkgbW91bnQuXG4gIHRyeSB7XG4gICAgY29uc3Qgc2hhcmVkID0gKGdsb2JhbFRoaXMgYXMgYW55KS5fX3NhbmRwYWNrU2hhcmVkRnM7XG4gICAgaWYgKGhhc1JlYWRkaXIoc2hhcmVkKSkgcmV0dXJuIHNoYXJlZDtcbiAgfSBjYXRjaCB7XG4gICAgLyogbm90IGluIHRoZSBzYW5kYm94ICovXG4gIH1cbiAgLy8gMi4gRmFsbCBiYWNrIHRvIHRoZSBidW5kbGVyJ3MgWmVuRlMgbGF5ZXIgYm91bmQgY29udGV4dCAoYWxzbyAnLyctcm9vdGVkKSxcbiAgLy8gICAgcmVhY2hlZCB0aGUgc2FtZSB3YXkgdGhlIFNESyByZWFjaGVzIG90aGVyIGJ1bmRsZXIgc2VydmljZXMuXG4gIHRyeSB7XG4gICAgLy8gQHRzLWV4cGVjdC1lcnJvciAtIGBtb2R1bGVgIGlzIGluamVjdGVkIGJ5IHRoZSBzYW5kYm94IHJ1bnRpbWUgKHNlZSBTREsgbW91bnRzLnRzKVxuICAgIGNvbnN0IGxheWVycyA9IG1vZHVsZT8uZXZhbHVhdGlvbj8ubW9kdWxlPy5idW5kbGVyPy5mcz8ubGF5ZXJzO1xuICAgIGlmIChBcnJheS5pc0FycmF5KGxheWVycykpIHtcbiAgICAgIGZvciAoY29uc3QgbGF5ZXIgb2YgbGF5ZXJzKSB7XG4gICAgICAgIGNvbnN0IGZzID0gbGF5ZXI/LmJvdW5kQ29udGV4dD8uZnM7XG4gICAgICAgIGlmIChoYXNSZWFkZGlyKGZzKSkgcmV0dXJuIGZzO1xuICAgICAgfVxuICAgIH1cbiAgfSBjYXRjaCB7XG4gICAgLyogbm90IGluIHRoZSBzYW5kYm94ICovXG4gIH1cbiAgcmV0dXJuIG51bGw7XG59XG5cbmNvbnN0IGpvaW5QYXRoID0gKGRpcjogc3RyaW5nLCBuYW1lOiBzdHJpbmcpOiBzdHJpbmcgPT5cbiAgYCR7ZGlyLnJlcGxhY2UoL1xcLyskLywgXCJcIil9LyR7bmFtZX1gO1xuXG4vKiogSXMgdGhlIHNhbmRib3ggZnMgcmVhY2hhYmxlIGF0IGFsbD8gKGZhbHNlIGluIGxvY2FsIGRldiAvIGJlZm9yZSBib290KS4gKi9cbmV4cG9ydCBmdW5jdGlvbiBmc0F2YWlsYWJsZSgpOiBib29sZWFuIHtcbiAgcmV0dXJuIHNhbmRib3hGcygpICE9IG51bGw7XG59XG5cbi8qKiBMaXN0IGBwYXRoYCdzIGltbWVkaWF0ZSBlbnRyaWVzLCBkaXJlY3RvcmllcyBmaXJzdCB0aGVuIGZpbGVzLCBB4oaSWi4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiByZWFkZGlyKHBhdGg6IHN0cmluZyk6IFByb21pc2U8RGlyRW50cnlbXT4ge1xuICBjb25zdCBmcyA9IHNhbmRib3hGcygpO1xuICBpZiAoIWZzKSB0aHJvdyBuZXcgRXJyb3IoXCJzYW5kYm94IGZpbGVzeXN0ZW0gdW5hdmFpbGFibGVcIik7XG4gIGNvbnN0IHAgPSBmcy5wcm9taXNlcyA/PyBmcztcblxuICBsZXQgcmF3OiBhbnlbXTtcbiAgdHJ5IHtcbiAgICByYXcgPSBhd2FpdCBwLnJlYWRkaXIocGF0aCwgeyB3aXRoRmlsZVR5cGVzOiB0cnVlIH0pO1xuICB9IGNhdGNoIHtcbiAgICByYXcgPSBhd2FpdCBwLnJlYWRkaXIocGF0aCk7XG4gIH1cblxuICBjb25zdCBlbnRyaWVzOiBEaXJFbnRyeVtdID0gW107XG4gIGZvciAoY29uc3QgaXRlbSBvZiByYXcpIHtcbiAgICBpZiAodHlwZW9mIGl0ZW0gPT09IFwic3RyaW5nXCIpIHtcbiAgICAgIC8vIHN0cmluZ1tdIHNoYXBlIOKAlCBzdGF0IGVhY2ggdG8gbGVhcm4gZGlyZWN0b3J5LW5lc3MuXG4gICAgICBsZXQgaXNEaXIgPSBmYWxzZTtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHN0ID0gYXdhaXQgcC5zdGF0KGpvaW5QYXRoKHBhdGgsIGl0ZW0pKTtcbiAgICAgICAgaXNEaXIgPSB0eXBlb2Ygc3Q/LmlzRGlyZWN0b3J5ID09PSBcImZ1bmN0aW9uXCIgPyBzdC5pc0RpcmVjdG9yeSgpIDogISFzdD8uaXNEaXJlY3Rvcnk7XG4gICAgICB9IGNhdGNoIHtcbiAgICAgICAgLyogdW5yZWFkYWJsZSBlbnRyeSDigJQgdHJlYXQgYXMgYSBmaWxlICovXG4gICAgICB9XG4gICAgICBlbnRyaWVzLnB1c2goeyBuYW1lOiBpdGVtLCBpc0RpciB9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gRGlyZW50IHNoYXBlLlxuICAgICAgY29uc3QgaXNEaXIgPVxuICAgICAgICB0eXBlb2YgaXRlbT8uaXNEaXJlY3RvcnkgPT09IFwiZnVuY3Rpb25cIiA/IGl0ZW0uaXNEaXJlY3RvcnkoKSA6ICEhaXRlbT8uaXNEaXJlY3Rvcnk7XG4gICAgICBlbnRyaWVzLnB1c2goeyBuYW1lOiBTdHJpbmcoaXRlbT8ubmFtZSA/PyBpdGVtKSwgaXNEaXIgfSk7XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIGVudHJpZXMuc29ydCgoYSwgYikgPT5cbiAgICBhLmlzRGlyID09PSBiLmlzRGlyID8gYS5uYW1lLmxvY2FsZUNvbXBhcmUoYi5uYW1lKSA6IGEuaXNEaXIgPyAtMSA6IDEsXG4gICk7XG59XG5cbi8qKlxuICogUmVhZCBhIGZpbGUncyByYXcgYnl0ZXMgZnJvbSBhIG1vdW50IChSMy04MyBkcmFnLW91dDogdGhlIHNvdXJjZSBpbmxpbmVzIGEgc21hbGxcbiAqIGZpbGUncyBjb250ZW50IHNvIHRoZSBob3N0IGNhbiByZWxheSBpdCB0byB0aGUgcHJldmlld2VkIGFwcCDigJQgdGhlIHNvdXJjZSBjYW4gb25seVxuICogZXZlciBoYW5kIG92ZXIgYnl0ZXMgaXQgY2FuIGFscmVhZHkgcmVhZCkuIFRocm93cyBpZiB0aGUgc2FuZGJveCBmcyBpcyB1bmF2YWlsYWJsZVxuICogb3IgdGhlIHJlYWQgZmFpbHM7IGNhbGxlcnMgZmFsbCBiYWNrIHRvIGEgcmVmZXJlbmNlLW9ubHkgZHJhZy5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJlYWRGaWxlKHBhdGg6IHN0cmluZyk6IFByb21pc2U8VWludDhBcnJheT4ge1xuICBjb25zdCBmcyA9IHNhbmRib3hGcygpO1xuICBpZiAoIWZzKSB0aHJvdyBuZXcgRXJyb3IoXCJzYW5kYm94IGZpbGVzeXN0ZW0gdW5hdmFpbGFibGVcIik7XG4gIGNvbnN0IHAgPSBmcy5wcm9taXNlcyA/PyBmcztcbiAgY29uc3QgZGF0YSA9IGF3YWl0IHAucmVhZEZpbGUocGF0aCk7XG4gIHJldHVybiBkYXRhIGluc3RhbmNlb2YgVWludDhBcnJheSA/IGRhdGEgOiBuZXcgVWludDhBcnJheShkYXRhKTtcbn1cblxuLyoqIFRoZSBkZWZhdWx0IHtAbGluayBGc1NvdXJjZX06IHRoZSBaZW5GUyBzYW5kYm94IGFjY2Vzc29yLiBUaGUgaGVhZGxlc3Mgdmlld1xuICogIHJlYWRzIGJ5dGVzL2VudHJpZXMgdGhyb3VnaCB0aGlzIGluIHRoZSBzaGlwcGVkIGFwcCAoYSBjb25zdW1lciB3aXRoIGFcbiAqICBkaWZmZXJlbnQgZmlsZXN5c3RlbSBzdXBwbGllcyBpdHMgb3duIGBGc1NvdXJjZWApLiAqL1xuZXhwb3J0IGNvbnN0IHNka0ZzU291cmNlOiBGc1NvdXJjZSA9IHsgcmVhZGRpciwgcmVhZEZpbGUgfTtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBR0E7QUFDQSxNQUFNQSxVQUFVLEdBQUlDLEVBQU8sSUFDekIsT0FBT0EsRUFBRSxFQUFFQyxRQUFRLEVBQUVDLE9BQU8sS0FBSyxVQUFVLElBQUksT0FBT0YsRUFBRSxFQUFFRSxPQUFPLEtBQUssVUFBVTtBQUVsRixTQUFTQyxTQUFTQSxDQUFBLEVBQWU7RUFDL0I7RUFDQTtFQUNBLElBQUk7SUFDRixNQUFNQyxNQUFNLEdBQUlDLFVBQVUsQ0FBU0Msa0JBQWtCO0lBQ3JELElBQUlQLFVBQVUsQ0FBQ0ssTUFBTSxDQUFDLEVBQUUsT0FBT0EsTUFBTTtFQUN2QyxDQUFDLENBQUMsTUFBTTtJQUNOO0VBQUE7RUFFRjtFQUNBO0VBQ0EsSUFBSTtJQUNGO0lBQ0EsTUFBTUcsTUFBTSxHQUFHQyxNQUFNLEVBQUVDLFVBQVUsRUFBRUQsTUFBTSxFQUFFRSxPQUFPLEVBQUVWLEVBQUUsRUFBRU8sTUFBTTtJQUM5RCxJQUFJSSxLQUFLLENBQUNDLE9BQU8sQ0FBQ0wsTUFBTSxDQUFDLEVBQUU7TUFDekIsS0FBSyxNQUFNTSxLQUFLLElBQUlOLE1BQU0sRUFBRTtRQUMxQixNQUFNUCxFQUFFLEdBQUdhLEtBQUssRUFBRUMsWUFBWSxFQUFFZCxFQUFFO1FBQ2xDLElBQUlELFVBQVUsQ0FBQ0MsRUFBRSxDQUFDLEVBQUUsT0FBT0EsRUFBRTtNQUMvQjtJQUNGO0VBQ0YsQ0FBQyxDQUFDLE1BQU07SUFDTjtFQUFBO0VBRUYsT0FBTyxJQUFJO0FBQ2I7QUFFQSxNQUFNZSxRQUFRLEdBQUdBLENBQUNDLEdBQVcsRUFBRUMsSUFBWSxLQUN6QyxHQUFHRCxHQUFHLENBQUNFLE9BQU8sQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLElBQUlELElBQUksRUFBRTs7QUFFdEM7QUFDTyxTQUFTRSxXQUFXQSxDQUFBLEVBQVk7RUFDckMsT0FBT2hCLFNBQVMsQ0FBQyxDQUFDLElBQUksSUFBSTtBQUM1Qjs7QUFFQTtBQUNPLGVBQWVELE9BQU9BLENBQUNrQixJQUFZLEVBQXVCO0VBQy9ELE1BQU1wQixFQUFFLEdBQUdHLFNBQVMsQ0FBQyxDQUFDO0VBQ3RCLElBQUksQ0FBQ0gsRUFBRSxFQUFFLE1BQU0sSUFBSXFCLEtBQUssQ0FBQyxnQ0FBZ0MsQ0FBQztFQUMxRCxNQUFNQyxDQUFDLEdBQUd0QixFQUFFLENBQUNDLFFBQVEsSUFBSUQsRUFBRTtFQUUzQixJQUFJdUIsR0FBVTtFQUNkLElBQUk7SUFDRkEsR0FBRyxHQUFHLE1BQU1ELENBQUMsQ0FBQ3BCLE9BQU8sQ0FBQ2tCLElBQUksRUFBRTtNQUFFSSxhQUFhLEVBQUU7SUFBSyxDQUFDLENBQUM7RUFDdEQsQ0FBQyxDQUFDLE1BQU07SUFDTkQsR0FBRyxHQUFHLE1BQU1ELENBQUMsQ0FBQ3BCLE9BQU8sQ0FBQ2tCLElBQUksQ0FBQztFQUM3QjtFQUVBLE1BQU1LLE9BQW1CLEdBQUcsRUFBRTtFQUM5QixLQUFLLE1BQU1DLElBQUksSUFBSUgsR0FBRyxFQUFFO0lBQ3RCLElBQUksT0FBT0csSUFBSSxLQUFLLFFBQVEsRUFBRTtNQUM1QjtNQUNBLElBQUlDLEtBQUssR0FBRyxLQUFLO01BQ2pCLElBQUk7UUFDRixNQUFNQyxFQUFFLEdBQUcsTUFBTU4sQ0FBQyxDQUFDTyxJQUFJLENBQUNkLFFBQVEsQ0FBQ0ssSUFBSSxFQUFFTSxJQUFJLENBQUMsQ0FBQztRQUM3Q0MsS0FBSyxHQUFHLE9BQU9DLEVBQUUsRUFBRUUsV0FBVyxLQUFLLFVBQVUsR0FBR0YsRUFBRSxDQUFDRSxXQUFXLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQ0YsRUFBRSxFQUFFRSxXQUFXO01BQ3RGLENBQUMsQ0FBQyxNQUFNO1FBQ047TUFBQTtNQUVGTCxPQUFPLENBQUNNLElBQUksQ0FBQztRQUFFZCxJQUFJLEVBQUVTLElBQUk7UUFBRUM7TUFBTSxDQUFDLENBQUM7SUFDckMsQ0FBQyxNQUFNO01BQ0w7TUFDQSxNQUFNQSxLQUFLLEdBQ1QsT0FBT0QsSUFBSSxFQUFFSSxXQUFXLEtBQUssVUFBVSxHQUFHSixJQUFJLENBQUNJLFdBQVcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDSixJQUFJLEVBQUVJLFdBQVc7TUFDcEZMLE9BQU8sQ0FBQ00sSUFBSSxDQUFDO1FBQUVkLElBQUksRUFBRWUsTUFBTSxDQUFDTixJQUFJLEVBQUVULElBQUksSUFBSVMsSUFBSSxDQUFDO1FBQUVDO01BQU0sQ0FBQyxDQUFDO0lBQzNEO0VBQ0Y7RUFFQSxPQUFPRixPQUFPLENBQUNRLElBQUksQ0FBQyxDQUFDQyxDQUFDLEVBQUVDLENBQUMsS0FDdkJELENBQUMsQ0FBQ1AsS0FBSyxLQUFLUSxDQUFDLENBQUNSLEtBQUssR0FBR08sQ0FBQyxDQUFDakIsSUFBSSxDQUFDbUIsYUFBYSxDQUFDRCxDQUFDLENBQUNsQixJQUFJLENBQUMsR0FBR2lCLENBQUMsQ0FBQ1AsS0FBSyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQ3RFLENBQUM7QUFDSDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxlQUFlVSxRQUFRQSxDQUFDakIsSUFBWSxFQUF1QjtFQUNoRSxNQUFNcEIsRUFBRSxHQUFHRyxTQUFTLENBQUMsQ0FBQztFQUN0QixJQUFJLENBQUNILEVBQUUsRUFBRSxNQUFNLElBQUlxQixLQUFLLENBQUMsZ0NBQWdDLENBQUM7RUFDMUQsTUFBTUMsQ0FBQyxHQUFHdEIsRUFBRSxDQUFDQyxRQUFRLElBQUlELEVBQUU7RUFDM0IsTUFBTXNDLElBQUksR0FBRyxNQUFNaEIsQ0FBQyxDQUFDZSxRQUFRLENBQUNqQixJQUFJLENBQUM7RUFDbkMsT0FBT2tCLElBQUksWUFBWUMsVUFBVSxHQUFHRCxJQUFJLEdBQUcsSUFBSUMsVUFBVSxDQUFDRCxJQUFJLENBQUM7QUFDakU7O0FBRUE7QUFDQTtBQUNBO0FBQ08sTUFBTUUsV0FBcUIsR0FBQUMsT0FBQSxDQUFBRCxXQUFBLEdBQUc7RUFBRXRDLE9BQU87RUFBRW1DO0FBQVMsQ0FBQyIsImlnbm9yZUxpc3QiOltdfQ==