var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.find.js");
require("core-js/modules/esnext.iterator.for-each.js");
require("core-js/modules/esnext.iterator.map.js");
require("core-js/modules/esnext.iterator.some.js");
var _react = require("react");
var _lucideReact = require("lucide-react");
var _sdk = require("@immediately-run/sdk");
var _sandboxUtils = require("@immediately-run/sdk/sandboxUtils");
var _FileExplorerView = _interopRequireDefault(require("../FileExplorerView"));
var _LensSwitcher = _interopRequireDefault(require("../LensSwitcher"));
var _useShowAllFilesystems = require("../hooks/useShowAllFilesystems");
var _mounts = require("./mounts");
var _useSdkRoots = require("./useSdkRoots");
var _useSessionRoots = require("./useSessionRoots");
var _mountFs = require("./mountFs");
var _actions = require("./actions");
var _summarize = require("./summarize");
var _useOpensWith = require("./useOpensWith");
var _openWith = require("./openWith");
var _SummaryModal = _interopRequireDefault(require("./SummaryModal"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // `SdkFileExplorer` — the shipped file-explorer app, assembled from the headless
// library + the SDK adapter (Phase 02 §B.5). This IS the former app: it wires
// `useSdkRoots()` → roots, `sdkFsSource` → fs, `makeSdkActions()` → actions, the
// editor's active file (`useEditorContext`) → activePath, the per-app settings
// roots (`listSettingsApps`/`openSettingsOf`), and the "Summarize…" feature (an
// `extraMenuItems` contribution + the modal) into `<FileExplorerView/>`.
//
// The existing FileExplorer test suite renders THIS and keeps the same SDK mocks —
// the parity proof that the extraction is behavior-preserving.
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// The action bundle + fs are stable for the lifetime of the app.
const actions = (0, _actions.makeSdkActions)();

// The HOST origin, recovered from the iframe's `?href=` boot param (the sandbox URL
// carries the host page it renders for). Needed to open host routes (`/spaces`) in a
// new tab — a relative URL would resolve against the sandbox origin. Null when absent
// (plain `vite dev`), in which case host-route affordances are hidden, never broken.
const getHostOrigin = () => {
  try {
    const href = new URLSearchParams(window.location.search).get("href");
    return href ? new URL(href).origin : null;
  } catch {
    return null;
  }
};

/** The full-tab space-manager, at a space (R3-269 D4: entry point only — the
 *  membership/share/create VERBS stay in space-manager, R-SPACES-7). */
const openManageSharing = spaceId => {
  const hostOrigin = getHostOrigin();
  if (!hostOrigin) return;
  window.open(`${hostOrigin}/spaces?space=${encodeURIComponent(spaceId)}`, "_blank", "noopener,noreferrer");
};
function SdkFileExplorer() {
  _s();
  // R3-238: settings stores and the affordance that opens them are advanced plumbing,
  // hidden unless the user opts in. One flag governs BOTH halves — a session that shows
  // no `settings:` roots must not still advertise `settings · <app>` buttons.
  const [showAll, setShowAll] = (0, _useShowAllFilesystems.useShowAllFilesystems)();
  const roots = (0, _useSdkRoots.useSdkRoots)(showAll);
  const mounts = (0, _sdk.useMounts)();
  const editorContext = (0, _sdk.useEditorContext)();
  const {
    activeFile
  } = editorContext;
  // The stage's viewed-document hint (R3-268). Read defensively so this app
  // works against both SDK generations: an SDK without the field yields
  // `undefined` → no marker, never a crash.
  const viewedFile = editorContext.viewedFile ?? null;
  const [summary, setSummary] = (0, _react.useState)(null);
  // Gesture-gated reveal (R3-268 follow-up): the HOST sends a one-shot
  // `viewed-reveal` only for navigations that provably rode a real user click
  // (it samples its own transient activation — this frame cannot fake it) and
  // only to `editor:read` frames. The view expands ancestors + scrolls the row
  // into view; focus never moves. Everything else stays highlight-only.
  const [reveal, setReveal] = (0, _react.useState)(null);
  const revealNonceRef = (0, _react.useRef)(0);
  (0, _react.useEffect)(() => {
    let dispose;
    try {
      dispose = (0, _sandboxUtils.addListener)("viewed-reveal", m => {
        if (typeof m.path === "string") {
          revealNonceRef.current += 1;
          setReveal({
            path: m.path,
            nonce: revealNonceRef.current
          });
        }
      });
      // R3-440 (the R3-392 readiness contract, extended): report ready
      // IMMEDIATELY after subscribing — the host holds a gesture's pending
      // `viewed-reveal` until this report, and a raw dispatch sent before it
      // is silently dropped. A frame that never reports never receives.
      //
      // This deliberately overloads the SDK's skeleton-timing contract
      // (ready.ts: "not at mount"): this report is LISTENER readiness, and the
      // skeleton cost is nil because the mount effect commits with the root
      // render (max(commit, report) ≈ commit). The spend is permanent
      // (first-call-wins), and accepted: this app has no later usefully-
      // interactive moment to delay for. The boot race the report opens
      // (a reveal released before roots exist) is closed by the view's
      // rootKey retry, not by reporting later. TOOLS_ACTIVITY_SPEC §4.1.
      (0, _sdk.reportReady)();
    } catch {
      /* no host transport — a standalone dev-server render */
    }
    return () => dispose?.();
  }, []);

  // The first-party "App | Session" lens (PRINCIPALS §9 B2). `sessionAvailable` is
  // true only when the host delivered a session signal (first-party frame); a
  // URL-loaded fork gets none, so the toggle never renders and the app is App-only.
  const {
    roots: sessionRoots,
    available: sessionAvailable,
    hidden: sessionHidden
  } = (0, _useSessionRoots.useSessionRoots)(showAll);
  // PRINCIPALS §9 B4 (R3-96): as the standalone User-scope `page.commander` surface this
  // app IS the cross-app "everything you've ever opened" navigator, so it defaults to the
  // broad `mounts:registry` lens rather than the app's own mounts. In the workbench
  // `panel.files` projection it defaults to App as before. (A fork never holds
  // `mounts:registry`, so `sessionAvailable` is false there and it stays App-only anyway.)
  const isCommander = (0, _sdk.useRegion)() === "page.commander";
  const [lens, setLens] = (0, _react.useState)(isCommander ? "session" : "app");
  // Fall back to App if the session signal goes away (mounts revoked / not first-party).
  const effectiveLens = sessionAvailable ? lens : "app";
  const shownRoots = effectiveLens === "session" ? sessionRoots : roots;

  // The "file commander": every app that has per-user settings (elevated
  // `settings:all`). Empty for a fork/preview lacking the capability. Each opened
  // app's settings mount flows in as its own root via `useSdkRoots()`; this slice
  // only drives a "click to open" affordance for apps not yet mounted.
  const [settingsApps, setSettingsApps] = (0, _react.useState)([]);
  (0, _react.useEffect)(() => {
    let live = true;
    void (0, _sdk.listSettingsApps)().then(apps => live && setSettingsApps(apps)).catch(() => undefined);
    return () => {
      live = false;
    };
  }, []);
  const openAppSettings = (0, _react.useCallback)(appKey => {
    void (0, _sdk.openSettingsOf)(appKey).catch(() => undefined);
  }, []);

  // R3-269 D5: "Add a space…" asks the HOST powerbox to enumerate + grant
  // (R-SPACES-2: the explorer never lists spaces or mints mounts itself). The granted
  // mount then flows in through `useMounts()` like any other. `cancelled` is a normal
  // outcome, not an error.
  const addSpace = (0, _react.useCallback)(() => {
    void (0, _sdk.requestMount)().catch(() => undefined);
  }, []);

  // R3-267: the `opensWith` caller. The wrapped fs probes each listed directory for
  // its content marker, so a folder that declares what opens it can be offered one.
  // R3-159 adds the into-stage twin: a launchable contract also gets "Open in place".
  const {
    fs: opensWithFs,
    offerFor,
    inPlaceFor,
    withdraw,
    viewOffersFor
  } = (0, _useOpensWith.useOpensWith)(_mountFs.sdkFsSource);
  const rootByPath = (0, _react.useCallback)(absPath => shownRoots.find(r => absPath === r.path || absPath.startsWith(`${r.path}/`)) ?? null, [shownRoots]);
  const runOpenWith = (0, _react.useCallback)(
  // `chosen` — a declared view's offer (R3-789); absent ⇒ the marker's own offer.
  (absPath, chosen) => {
    const root = rootByPath(absPath);
    const offer = chosen ?? offerFor(absPath);
    if (!root || !offer) return;
    // Fire-and-forget: the host draws the viewer. Every refusal is handled inside
    // `openWith` — `cancelled` is the ordinary close, and a contract-level refusal
    // withdraws the affordance rather than putting a protocol code on screen.
    void (0, _openWith.openWith)(root, absPath, offer).then(outcome => {
      if (outcome.status === "withdraw") withdraw(outcome.task);
    });
  }, [rootByPath, offerFor, withdraw]);
  // R3-159: fire-and-forget like runOpenWith — the host draws the into-stage overlay
  // and the suspend/restore. A launch refusal just declines (invisibly): no launch
  // code is a session-permanent verdict, so the affordance always stays.
  const runOpenInPlace = (0, _react.useCallback)(absPath => {
    const root = rootByPath(absPath);
    const offer = inPlaceFor(absPath);
    if (!root || !offer) return;
    void (0, _openWith.openInPlace)(root, absPath, offer);
  }, [rootByPath, inPlaceFor]);
  const extraMenuItems = (0, _react.useCallback)(ctx => {
    const items = (0, _summarize.summarizeMenuItems)(ctx, setSummary);
    // The affordance is on the ITEM, offered by the marker's own `kind` — no task name
    // reaches this code, so a folder declaring a later contract works with no change
    // here (only a manifest entry, which the host enforces anyway).
    const offer = ctx.isDir ? offerFor(ctx.absPath) : null;
    const inPlace = ctx.isDir ? inPlaceFor(ctx.absPath) : null;
    const declaredViews = ctx.isDir ? viewOffersFor(ctx.absPath) : [];
    if (offer || inPlace || declaredViews.length > 0) {
      // Unshifted as a pair so the for-result offer leads and the into-stage twin
      // (R3-159) sits directly under it, above everything else the menu offers.
      const openItems = [];
      if (offer) {
        openItems.push({
          key: "open-with",
          label: offer.label,
          icon: /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.BookOpen, {
            size: 14,
            "aria-hidden": "true"
          }),
          onSelect: () => runOpenWith(ctx.absPath)
        });
      }
      // R3-789 (§4b.1a): one item per declared view, under the bundle's own offer.
      declaredViews.forEach((v, i) => {
        openItems.push({
          key: `open-view-${i}`,
          label: v.label,
          icon: /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.BookOpen, {
            size: 14,
            "aria-hidden": "true"
          }),
          onSelect: () => runOpenWith(ctx.absPath, v)
        });
      });
      if (inPlace) {
        openItems.push({
          key: "open-in-place",
          label: inPlace.label,
          icon: /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.Play, {
            size: 14,
            "aria-hidden": "true"
          }),
          onSelect: () => runOpenInPlace(ctx.absPath)
        });
      }
      items.unshift(...openItems);
    }
    // R3-269 D4: the per-space "Manage sharing →" entry point, on the space's ROOT row
    // only. Opens the full-tab space-manager AT that space — the verbs live there.
    const spaceId = ctx.mountId.startsWith("space:") ? ctx.mountId.slice("space:".length) : null;
    if (getHostOrigin() && spaceId && ctx.absPath === ctx.rootPath) {
      items.push({
        key: "manage-sharing",
        label: "Manage sharing →",
        icon: /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.Users, {
          size: 14,
          "aria-hidden": "true"
        }),
        onSelect: () => openManageSharing(spaceId)
      });
    }
    return items;
  }, [offerFor, inPlaceFor, viewOffersFor, runOpenWith, runOpenInPlace]);

  // Apps with per-user settings that aren't mounted yet — click to open
  // (`settings:all`). An already-opened settings mount renders as its own root
  // (via `useSdkRoots`), so filter those out. Surfaced in the header (the view is
  // settings-app-agnostic per Phase 02 §A.1).
  const unmountedSettingsApps = settingsApps.filter(ak => !mounts.some(m => m.id === `settings:${ak}`));
  const settingsButtons = showAll && unmountedSettingsApps.length > 0 ? unmountedSettingsApps.map(ak => /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
    type: "button",
    className: "settings-app",
    onClick: () => openAppSettings(ak),
    title: `Open ${ak} settings`,
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.FolderTree, {
      size: 14,
      "aria-hidden": "true"
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
      className: "settings-app__label",
      children: ["settings \xB7 ", ak]
    })]
  }, ak)) : null;

  // The reveal affordance is offered only when this session actually HAS something
  // hidden — otherwise every ordinary session pays for an advanced control it can
  // never use. Once the flag is on it stays offered, so the door swings both ways.
  const hasHidden = mounts.some(_mounts.isSettingsMount) || sessionHidden > 0 || unmountedSettingsApps.length > 0;
  const showAllToggle = showAll || hasHidden ? /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
    type: "button",
    className: "panel__action",
    "aria-pressed": showAll,
    title: showAll ? "Hide advanced filesystems" : "Show all filesystems",
    "aria-label": showAll ? "Hide advanced filesystems" : "Show all filesystems",
    onClick: () => setShowAll(!showAll),
    children: showAll ? /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.Eye, {
      size: 15,
      "aria-hidden": "true"
    }) : /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.EyeOff, {
      size: 15,
      "aria-hidden": "true"
    })
  }) : null;

  // R3-269 D5: the explorer is the add-a-space entry point — a header affordance
  // that invokes the host powerbox. Always offered (it may be the very control that
  // produces the first root).
  const addSpaceButton = /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
    type: "button",
    className: "panel__action",
    title: "Add a space\u2026",
    "aria-label": "Add a space\u2026",
    onClick: addSpace,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.Plus, {
      size: 15,
      "aria-hidden": "true"
    })
  });

  // The Session lens toggle leads the header actions, but only when the host
  // delivered a session signal (first-party). A fork never sees it.
  const headerActions = /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [sessionAvailable && /*#__PURE__*/(0, _jsxRuntime.jsx)(_LensSwitcher.default, {
      value: effectiveLens,
      onChange: setLens
    }), addSpaceButton, showAllToggle]
  });
  // NOT in `headerActions`: there is one of these per app with settings, so the count
  // grows with the session. Sharing a fixed row out among an unbounded N is what
  // squashed them into overlapping slivers on a phone; the tray is a row of their own.
  const headerTray = settingsButtons;
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_FileExplorerView.default, {
      roots: shownRoots,
      fs: opensWithFs,
      actions: actions,
      activePath: activeFile,
      viewedPath: viewedFile,
      extraMenuItems: extraMenuItems,
      reveal: reveal,
      header: {
        actions: headerActions,
        tray: headerTray
      },
      emptyState: /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "state",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "state__icon",
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.FolderTree, {
            size: 20,
            "aria-hidden": "true"
          })
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("h4", {
          children: "No files to show yet."
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
          children: "A space is a folder that lives in your account. You can share it with others and open it from any app."
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
          type: "button",
          className: "state__action",
          onClick: addSpace,
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.Plus, {
            size: 14,
            "aria-hidden": "true"
          }), "Add a space\u2026"]
        })]
      })
    }), summary && /*#__PURE__*/(0, _jsxRuntime.jsx)(_SummaryModal.default, {
      target: summary,
      onClose: () => setSummary(null)
    })]
  });
}
_s(SdkFileExplorer, "y28lT0vpUtFAnUUN+0mbteOeSs0=", false, function () {
  return [_useShowAllFilesystems.useShowAllFilesystems, _useSdkRoots.useSdkRoots, _sdk.useMounts, _sdk.useEditorContext, _useSessionRoots.useSessionRoots, _sdk.useRegion, _useOpensWith.useOpensWith];
});
_c = SdkFileExplorer;
var _default = exports.default = SdkFileExplorer;
var _c;
$RefreshReg$(_c, "SdkFileExplorer");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX2x1Y2lkZVJlYWN0IiwiX3NkayIsIl9zYW5kYm94VXRpbHMiLCJfRmlsZUV4cGxvcmVyVmlldyIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJfTGVuc1N3aXRjaGVyIiwiX3VzZVNob3dBbGxGaWxlc3lzdGVtcyIsIl9tb3VudHMiLCJfdXNlU2RrUm9vdHMiLCJfdXNlU2Vzc2lvblJvb3RzIiwiX21vdW50RnMiLCJfYWN0aW9ucyIsIl9zdW1tYXJpemUiLCJfdXNlT3BlbnNXaXRoIiwiX29wZW5XaXRoIiwiX1N1bW1hcnlNb2RhbCIsIl9qc3hSdW50aW1lIiwiX3MiLCIkUmVmcmVzaFNpZyQiLCJlIiwiX19lc01vZHVsZSIsImRlZmF1bHQiLCJhY3Rpb25zIiwibWFrZVNka0FjdGlvbnMiLCJnZXRIb3N0T3JpZ2luIiwiaHJlZiIsIlVSTFNlYXJjaFBhcmFtcyIsIndpbmRvdyIsImxvY2F0aW9uIiwic2VhcmNoIiwiZ2V0IiwiVVJMIiwib3JpZ2luIiwib3Blbk1hbmFnZVNoYXJpbmciLCJzcGFjZUlkIiwiaG9zdE9yaWdpbiIsIm9wZW4iLCJlbmNvZGVVUklDb21wb25lbnQiLCJTZGtGaWxlRXhwbG9yZXIiLCJzaG93QWxsIiwic2V0U2hvd0FsbCIsInVzZVNob3dBbGxGaWxlc3lzdGVtcyIsInJvb3RzIiwidXNlU2RrUm9vdHMiLCJtb3VudHMiLCJ1c2VNb3VudHMiLCJlZGl0b3JDb250ZXh0IiwidXNlRWRpdG9yQ29udGV4dCIsImFjdGl2ZUZpbGUiLCJ2aWV3ZWRGaWxlIiwic3VtbWFyeSIsInNldFN1bW1hcnkiLCJ1c2VTdGF0ZSIsInJldmVhbCIsInNldFJldmVhbCIsInJldmVhbE5vbmNlUmVmIiwidXNlUmVmIiwidXNlRWZmZWN0IiwiZGlzcG9zZSIsImFkZExpc3RlbmVyIiwibSIsInBhdGgiLCJjdXJyZW50Iiwibm9uY2UiLCJyZXBvcnRSZWFkeSIsInNlc3Npb25Sb290cyIsImF2YWlsYWJsZSIsInNlc3Npb25BdmFpbGFibGUiLCJoaWRkZW4iLCJzZXNzaW9uSGlkZGVuIiwidXNlU2Vzc2lvblJvb3RzIiwiaXNDb21tYW5kZXIiLCJ1c2VSZWdpb24iLCJsZW5zIiwic2V0TGVucyIsImVmZmVjdGl2ZUxlbnMiLCJzaG93blJvb3RzIiwic2V0dGluZ3NBcHBzIiwic2V0U2V0dGluZ3NBcHBzIiwibGl2ZSIsImxpc3RTZXR0aW5nc0FwcHMiLCJ0aGVuIiwiYXBwcyIsImNhdGNoIiwidW5kZWZpbmVkIiwib3BlbkFwcFNldHRpbmdzIiwidXNlQ2FsbGJhY2siLCJhcHBLZXkiLCJvcGVuU2V0dGluZ3NPZiIsImFkZFNwYWNlIiwicmVxdWVzdE1vdW50IiwiZnMiLCJvcGVuc1dpdGhGcyIsIm9mZmVyRm9yIiwiaW5QbGFjZUZvciIsIndpdGhkcmF3Iiwidmlld09mZmVyc0ZvciIsInVzZU9wZW5zV2l0aCIsInNka0ZzU291cmNlIiwicm9vdEJ5UGF0aCIsImFic1BhdGgiLCJmaW5kIiwiciIsInN0YXJ0c1dpdGgiLCJydW5PcGVuV2l0aCIsImNob3NlbiIsInJvb3QiLCJvZmZlciIsIm9wZW5XaXRoIiwib3V0Y29tZSIsInN0YXR1cyIsInRhc2siLCJydW5PcGVuSW5QbGFjZSIsIm9wZW5JblBsYWNlIiwiZXh0cmFNZW51SXRlbXMiLCJjdHgiLCJpdGVtcyIsInN1bW1hcml6ZU1lbnVJdGVtcyIsImlzRGlyIiwiaW5QbGFjZSIsImRlY2xhcmVkVmlld3MiLCJsZW5ndGgiLCJvcGVuSXRlbXMiLCJwdXNoIiwia2V5IiwibGFiZWwiLCJpY29uIiwianN4IiwiQm9va09wZW4iLCJzaXplIiwib25TZWxlY3QiLCJmb3JFYWNoIiwidiIsImkiLCJQbGF5IiwidW5zaGlmdCIsIm1vdW50SWQiLCJzbGljZSIsInJvb3RQYXRoIiwiVXNlcnMiLCJ1bm1vdW50ZWRTZXR0aW5nc0FwcHMiLCJmaWx0ZXIiLCJhayIsInNvbWUiLCJpZCIsInNldHRpbmdzQnV0dG9ucyIsIm1hcCIsImpzeHMiLCJ0eXBlIiwiY2xhc3NOYW1lIiwib25DbGljayIsInRpdGxlIiwiY2hpbGRyZW4iLCJGb2xkZXJUcmVlIiwiaGFzSGlkZGVuIiwiaXNTZXR0aW5nc01vdW50Iiwic2hvd0FsbFRvZ2dsZSIsIkV5ZSIsIkV5ZU9mZiIsImFkZFNwYWNlQnV0dG9uIiwiUGx1cyIsImhlYWRlckFjdGlvbnMiLCJGcmFnbWVudCIsInZhbHVlIiwib25DaGFuZ2UiLCJoZWFkZXJUcmF5IiwiYWN0aXZlUGF0aCIsInZpZXdlZFBhdGgiLCJoZWFkZXIiLCJ0cmF5IiwiZW1wdHlTdGF0ZSIsInRhcmdldCIsIm9uQ2xvc2UiLCJfYyIsIl9kZWZhdWx0IiwiZXhwb3J0cyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlNka0ZpbGVFeHBsb3Jlci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gYFNka0ZpbGVFeHBsb3JlcmAg4oCUIHRoZSBzaGlwcGVkIGZpbGUtZXhwbG9yZXIgYXBwLCBhc3NlbWJsZWQgZnJvbSB0aGUgaGVhZGxlc3Ncbi8vIGxpYnJhcnkgKyB0aGUgU0RLIGFkYXB0ZXIgKFBoYXNlIDAyIMKnQi41KS4gVGhpcyBJUyB0aGUgZm9ybWVyIGFwcDogaXQgd2lyZXNcbi8vIGB1c2VTZGtSb290cygpYCDihpIgcm9vdHMsIGBzZGtGc1NvdXJjZWAg4oaSIGZzLCBgbWFrZVNka0FjdGlvbnMoKWAg4oaSIGFjdGlvbnMsIHRoZVxuLy8gZWRpdG9yJ3MgYWN0aXZlIGZpbGUgKGB1c2VFZGl0b3JDb250ZXh0YCkg4oaSIGFjdGl2ZVBhdGgsIHRoZSBwZXItYXBwIHNldHRpbmdzXG4vLyByb290cyAoYGxpc3RTZXR0aW5nc0FwcHNgL2BvcGVuU2V0dGluZ3NPZmApLCBhbmQgdGhlIFwiU3VtbWFyaXpl4oCmXCIgZmVhdHVyZSAoYW5cbi8vIGBleHRyYU1lbnVJdGVtc2AgY29udHJpYnV0aW9uICsgdGhlIG1vZGFsKSBpbnRvIGA8RmlsZUV4cGxvcmVyVmlldy8+YC5cbi8vXG4vLyBUaGUgZXhpc3RpbmcgRmlsZUV4cGxvcmVyIHRlc3Qgc3VpdGUgcmVuZGVycyBUSElTIGFuZCBrZWVwcyB0aGUgc2FtZSBTREsgbW9ja3Mg4oCUXG4vLyB0aGUgcGFyaXR5IHByb29mIHRoYXQgdGhlIGV4dHJhY3Rpb24gaXMgYmVoYXZpb3ItcHJlc2VydmluZy5cbmltcG9ydCB7IHVzZUNhbGxiYWNrLCB1c2VFZmZlY3QsIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IEZvbGRlclRyZWUsIEV5ZSwgRXllT2ZmLCBQbHVzLCBVc2VycywgQm9va09wZW4sIFBsYXkgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQge1xuICB1c2VFZGl0b3JDb250ZXh0LFxuICBsaXN0U2V0dGluZ3NBcHBzLFxuICBvcGVuU2V0dGluZ3NPZixcbiAgcmVwb3J0UmVhZHksXG4gIHJlcXVlc3RNb3VudCxcbiAgdXNlTW91bnRzLFxuICB1c2VSZWdpb24sXG59IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nka1wiO1xuaW1wb3J0IHsgYWRkTGlzdGVuZXIgfSBmcm9tIFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGsvc2FuZGJveFV0aWxzXCI7XG5pbXBvcnQgRmlsZUV4cGxvcmVyVmlldyBmcm9tIFwiLi4vRmlsZUV4cGxvcmVyVmlld1wiO1xuaW1wb3J0IExlbnNTd2l0Y2hlciwgeyB0eXBlIExlbnMgfSBmcm9tIFwiLi4vTGVuc1N3aXRjaGVyXCI7XG5pbXBvcnQgeyB1c2VTaG93QWxsRmlsZXN5c3RlbXMgfSBmcm9tIFwiLi4vaG9va3MvdXNlU2hvd0FsbEZpbGVzeXN0ZW1zXCI7XG5pbXBvcnQgeyBpc1NldHRpbmdzTW91bnQgfSBmcm9tIFwiLi9tb3VudHNcIjtcbmltcG9ydCB7IHVzZVNka1Jvb3RzIH0gZnJvbSBcIi4vdXNlU2RrUm9vdHNcIjtcbmltcG9ydCB7IHVzZVNlc3Npb25Sb290cyB9IGZyb20gXCIuL3VzZVNlc3Npb25Sb290c1wiO1xuaW1wb3J0IHsgc2RrRnNTb3VyY2UgfSBmcm9tIFwiLi9tb3VudEZzXCI7XG5pbXBvcnQgeyBtYWtlU2RrQWN0aW9ucyB9IGZyb20gXCIuL2FjdGlvbnNcIjtcbmltcG9ydCB7IHN1bW1hcml6ZU1lbnVJdGVtcyB9IGZyb20gXCIuL3N1bW1hcml6ZVwiO1xuaW1wb3J0IHsgdXNlT3BlbnNXaXRoIH0gZnJvbSBcIi4vdXNlT3BlbnNXaXRoXCI7XG5pbXBvcnQgdHlwZSB7IE9wZW5zV2l0aE9mZmVyIH0gZnJvbSBcIi4uL29wZW5zV2l0aFwiO1xuaW1wb3J0IHsgb3BlbldpdGgsIG9wZW5JblBsYWNlIH0gZnJvbSBcIi4vb3BlbldpdGhcIjtcbmltcG9ydCBTdW1tYXJ5TW9kYWwsIHsgdHlwZSBTdW1tYXJ5VGFyZ2V0IH0gZnJvbSBcIi4vU3VtbWFyeU1vZGFsXCI7XG5pbXBvcnQgdHlwZSB7IEV4cGxvcmVyQWN0aW9ucywgTWVudUl0ZW0sIFJvd0N0eCB9IGZyb20gXCIuLi90eXBlc1wiO1xuXG4vLyBUaGUgYWN0aW9uIGJ1bmRsZSArIGZzIGFyZSBzdGFibGUgZm9yIHRoZSBsaWZldGltZSBvZiB0aGUgYXBwLlxuY29uc3QgYWN0aW9uczogRXhwbG9yZXJBY3Rpb25zID0gbWFrZVNka0FjdGlvbnMoKTtcblxuLy8gVGhlIEhPU1Qgb3JpZ2luLCByZWNvdmVyZWQgZnJvbSB0aGUgaWZyYW1lJ3MgYD9ocmVmPWAgYm9vdCBwYXJhbSAodGhlIHNhbmRib3ggVVJMXG4vLyBjYXJyaWVzIHRoZSBob3N0IHBhZ2UgaXQgcmVuZGVycyBmb3IpLiBOZWVkZWQgdG8gb3BlbiBob3N0IHJvdXRlcyAoYC9zcGFjZXNgKSBpbiBhXG4vLyBuZXcgdGFiIOKAlCBhIHJlbGF0aXZlIFVSTCB3b3VsZCByZXNvbHZlIGFnYWluc3QgdGhlIHNhbmRib3ggb3JpZ2luLiBOdWxsIHdoZW4gYWJzZW50XG4vLyAocGxhaW4gYHZpdGUgZGV2YCksIGluIHdoaWNoIGNhc2UgaG9zdC1yb3V0ZSBhZmZvcmRhbmNlcyBhcmUgaGlkZGVuLCBuZXZlciBicm9rZW4uXG5jb25zdCBnZXRIb3N0T3JpZ2luID0gKCk6IHN0cmluZyB8IG51bGwgPT4ge1xuICB0cnkge1xuICAgIGNvbnN0IGhyZWYgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKHdpbmRvdy5sb2NhdGlvbi5zZWFyY2gpLmdldChcImhyZWZcIik7XG4gICAgcmV0dXJuIGhyZWYgPyBuZXcgVVJMKGhyZWYpLm9yaWdpbiA6IG51bGw7XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiBudWxsO1xuICB9XG59O1xuXG4vKiogVGhlIGZ1bGwtdGFiIHNwYWNlLW1hbmFnZXIsIGF0IGEgc3BhY2UgKFIzLTI2OSBENDogZW50cnkgcG9pbnQgb25seSDigJQgdGhlXG4gKiAgbWVtYmVyc2hpcC9zaGFyZS9jcmVhdGUgVkVSQlMgc3RheSBpbiBzcGFjZS1tYW5hZ2VyLCBSLVNQQUNFUy03KS4gKi9cbmNvbnN0IG9wZW5NYW5hZ2VTaGFyaW5nID0gKHNwYWNlSWQ6IHN0cmluZykgPT4ge1xuICBjb25zdCBob3N0T3JpZ2luID0gZ2V0SG9zdE9yaWdpbigpO1xuICBpZiAoIWhvc3RPcmlnaW4pIHJldHVybjtcbiAgd2luZG93Lm9wZW4oXG4gICAgYCR7aG9zdE9yaWdpbn0vc3BhY2VzP3NwYWNlPSR7ZW5jb2RlVVJJQ29tcG9uZW50KHNwYWNlSWQpfWAsXG4gICAgXCJfYmxhbmtcIixcbiAgICBcIm5vb3BlbmVyLG5vcmVmZXJyZXJcIixcbiAgKTtcbn07XG5cbmZ1bmN0aW9uIFNka0ZpbGVFeHBsb3JlcigpIHtcbiAgLy8gUjMtMjM4OiBzZXR0aW5ncyBzdG9yZXMgYW5kIHRoZSBhZmZvcmRhbmNlIHRoYXQgb3BlbnMgdGhlbSBhcmUgYWR2YW5jZWQgcGx1bWJpbmcsXG4gIC8vIGhpZGRlbiB1bmxlc3MgdGhlIHVzZXIgb3B0cyBpbi4gT25lIGZsYWcgZ292ZXJucyBCT1RIIGhhbHZlcyDigJQgYSBzZXNzaW9uIHRoYXQgc2hvd3NcbiAgLy8gbm8gYHNldHRpbmdzOmAgcm9vdHMgbXVzdCBub3Qgc3RpbGwgYWR2ZXJ0aXNlIGBzZXR0aW5ncyDCtyA8YXBwPmAgYnV0dG9ucy5cbiAgY29uc3QgW3Nob3dBbGwsIHNldFNob3dBbGxdID0gdXNlU2hvd0FsbEZpbGVzeXN0ZW1zKCk7XG4gIGNvbnN0IHJvb3RzID0gdXNlU2RrUm9vdHMoc2hvd0FsbCk7XG4gIGNvbnN0IG1vdW50cyA9IHVzZU1vdW50cygpO1xuICBjb25zdCBlZGl0b3JDb250ZXh0ID0gdXNlRWRpdG9yQ29udGV4dCgpO1xuICBjb25zdCB7IGFjdGl2ZUZpbGUgfSA9IGVkaXRvckNvbnRleHQ7XG4gIC8vIFRoZSBzdGFnZSdzIHZpZXdlZC1kb2N1bWVudCBoaW50IChSMy0yNjgpLiBSZWFkIGRlZmVuc2l2ZWx5IHNvIHRoaXMgYXBwXG4gIC8vIHdvcmtzIGFnYWluc3QgYm90aCBTREsgZ2VuZXJhdGlvbnM6IGFuIFNESyB3aXRob3V0IHRoZSBmaWVsZCB5aWVsZHNcbiAgLy8gYHVuZGVmaW5lZGAg4oaSIG5vIG1hcmtlciwgbmV2ZXIgYSBjcmFzaC5cbiAgY29uc3Qgdmlld2VkRmlsZSA9XG4gICAgKGVkaXRvckNvbnRleHQgYXMgeyB2aWV3ZWRGaWxlPzogc3RyaW5nIHwgbnVsbCB9KS52aWV3ZWRGaWxlID8/IG51bGw7XG4gIGNvbnN0IFtzdW1tYXJ5LCBzZXRTdW1tYXJ5XSA9IHVzZVN0YXRlPFN1bW1hcnlUYXJnZXQgfCBudWxsPihudWxsKTtcbiAgLy8gR2VzdHVyZS1nYXRlZCByZXZlYWwgKFIzLTI2OCBmb2xsb3ctdXApOiB0aGUgSE9TVCBzZW5kcyBhIG9uZS1zaG90XG4gIC8vIGB2aWV3ZWQtcmV2ZWFsYCBvbmx5IGZvciBuYXZpZ2F0aW9ucyB0aGF0IHByb3ZhYmx5IHJvZGUgYSByZWFsIHVzZXIgY2xpY2tcbiAgLy8gKGl0IHNhbXBsZXMgaXRzIG93biB0cmFuc2llbnQgYWN0aXZhdGlvbiDigJQgdGhpcyBmcmFtZSBjYW5ub3QgZmFrZSBpdCkgYW5kXG4gIC8vIG9ubHkgdG8gYGVkaXRvcjpyZWFkYCBmcmFtZXMuIFRoZSB2aWV3IGV4cGFuZHMgYW5jZXN0b3JzICsgc2Nyb2xscyB0aGUgcm93XG4gIC8vIGludG8gdmlldzsgZm9jdXMgbmV2ZXIgbW92ZXMuIEV2ZXJ5dGhpbmcgZWxzZSBzdGF5cyBoaWdobGlnaHQtb25seS5cbiAgY29uc3QgW3JldmVhbCwgc2V0UmV2ZWFsXSA9IHVzZVN0YXRlPHsgcGF0aDogc3RyaW5nOyBub25jZTogbnVtYmVyIH0gfCBudWxsPihudWxsKTtcbiAgY29uc3QgcmV2ZWFsTm9uY2VSZWYgPSB1c2VSZWYoMCk7XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgbGV0IGRpc3Bvc2U6ICgoKSA9PiB2b2lkKSB8IHVuZGVmaW5lZDtcbiAgICB0cnkge1xuICAgICAgZGlzcG9zZSA9IGFkZExpc3RlbmVyKFwidmlld2VkLXJldmVhbFwiLCAobTogeyBwYXRoPzogdW5rbm93biB9KSA9PiB7XG4gICAgICAgIGlmICh0eXBlb2YgbS5wYXRoID09PSBcInN0cmluZ1wiKSB7XG4gICAgICAgICAgcmV2ZWFsTm9uY2VSZWYuY3VycmVudCArPSAxO1xuICAgICAgICAgIHNldFJldmVhbCh7IHBhdGg6IG0ucGF0aCwgbm9uY2U6IHJldmVhbE5vbmNlUmVmLmN1cnJlbnQgfSk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgICAgLy8gUjMtNDQwICh0aGUgUjMtMzkyIHJlYWRpbmVzcyBjb250cmFjdCwgZXh0ZW5kZWQpOiByZXBvcnQgcmVhZHlcbiAgICAgIC8vIElNTUVESUFURUxZIGFmdGVyIHN1YnNjcmliaW5nIOKAlCB0aGUgaG9zdCBob2xkcyBhIGdlc3R1cmUncyBwZW5kaW5nXG4gICAgICAvLyBgdmlld2VkLXJldmVhbGAgdW50aWwgdGhpcyByZXBvcnQsIGFuZCBhIHJhdyBkaXNwYXRjaCBzZW50IGJlZm9yZSBpdFxuICAgICAgLy8gaXMgc2lsZW50bHkgZHJvcHBlZC4gQSBmcmFtZSB0aGF0IG5ldmVyIHJlcG9ydHMgbmV2ZXIgcmVjZWl2ZXMuXG4gICAgICAvL1xuICAgICAgLy8gVGhpcyBkZWxpYmVyYXRlbHkgb3ZlcmxvYWRzIHRoZSBTREsncyBza2VsZXRvbi10aW1pbmcgY29udHJhY3RcbiAgICAgIC8vIChyZWFkeS50czogXCJub3QgYXQgbW91bnRcIik6IHRoaXMgcmVwb3J0IGlzIExJU1RFTkVSIHJlYWRpbmVzcywgYW5kIHRoZVxuICAgICAgLy8gc2tlbGV0b24gY29zdCBpcyBuaWwgYmVjYXVzZSB0aGUgbW91bnQgZWZmZWN0IGNvbW1pdHMgd2l0aCB0aGUgcm9vdFxuICAgICAgLy8gcmVuZGVyIChtYXgoY29tbWl0LCByZXBvcnQpIOKJiCBjb21taXQpLiBUaGUgc3BlbmQgaXMgcGVybWFuZW50XG4gICAgICAvLyAoZmlyc3QtY2FsbC13aW5zKSwgYW5kIGFjY2VwdGVkOiB0aGlzIGFwcCBoYXMgbm8gbGF0ZXIgdXNlZnVsbHktXG4gICAgICAvLyBpbnRlcmFjdGl2ZSBtb21lbnQgdG8gZGVsYXkgZm9yLiBUaGUgYm9vdCByYWNlIHRoZSByZXBvcnQgb3BlbnNcbiAgICAgIC8vIChhIHJldmVhbCByZWxlYXNlZCBiZWZvcmUgcm9vdHMgZXhpc3QpIGlzIGNsb3NlZCBieSB0aGUgdmlldydzXG4gICAgICAvLyByb290S2V5IHJldHJ5LCBub3QgYnkgcmVwb3J0aW5nIGxhdGVyLiBUT09MU19BQ1RJVklUWV9TUEVDIMKnNC4xLlxuICAgICAgcmVwb3J0UmVhZHkoKTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIC8qIG5vIGhvc3QgdHJhbnNwb3J0IOKAlCBhIHN0YW5kYWxvbmUgZGV2LXNlcnZlciByZW5kZXIgKi9cbiAgICB9XG4gICAgcmV0dXJuICgpID0+IGRpc3Bvc2U/LigpO1xuICB9LCBbXSk7XG5cbiAgLy8gVGhlIGZpcnN0LXBhcnR5IFwiQXBwIHwgU2Vzc2lvblwiIGxlbnMgKFBSSU5DSVBBTFMgwqc5IEIyKS4gYHNlc3Npb25BdmFpbGFibGVgIGlzXG4gIC8vIHRydWUgb25seSB3aGVuIHRoZSBob3N0IGRlbGl2ZXJlZCBhIHNlc3Npb24gc2lnbmFsIChmaXJzdC1wYXJ0eSBmcmFtZSk7IGFcbiAgLy8gVVJMLWxvYWRlZCBmb3JrIGdldHMgbm9uZSwgc28gdGhlIHRvZ2dsZSBuZXZlciByZW5kZXJzIGFuZCB0aGUgYXBwIGlzIEFwcC1vbmx5LlxuICBjb25zdCB7XG4gICAgcm9vdHM6IHNlc3Npb25Sb290cyxcbiAgICBhdmFpbGFibGU6IHNlc3Npb25BdmFpbGFibGUsXG4gICAgaGlkZGVuOiBzZXNzaW9uSGlkZGVuLFxuICB9ID0gdXNlU2Vzc2lvblJvb3RzKHNob3dBbGwpO1xuICAvLyBQUklOQ0lQQUxTIMKnOSBCNCAoUjMtOTYpOiBhcyB0aGUgc3RhbmRhbG9uZSBVc2VyLXNjb3BlIGBwYWdlLmNvbW1hbmRlcmAgc3VyZmFjZSB0aGlzXG4gIC8vIGFwcCBJUyB0aGUgY3Jvc3MtYXBwIFwiZXZlcnl0aGluZyB5b3UndmUgZXZlciBvcGVuZWRcIiBuYXZpZ2F0b3IsIHNvIGl0IGRlZmF1bHRzIHRvIHRoZVxuICAvLyBicm9hZCBgbW91bnRzOnJlZ2lzdHJ5YCBsZW5zIHJhdGhlciB0aGFuIHRoZSBhcHAncyBvd24gbW91bnRzLiBJbiB0aGUgd29ya2JlbmNoXG4gIC8vIGBwYW5lbC5maWxlc2AgcHJvamVjdGlvbiBpdCBkZWZhdWx0cyB0byBBcHAgYXMgYmVmb3JlLiAoQSBmb3JrIG5ldmVyIGhvbGRzXG4gIC8vIGBtb3VudHM6cmVnaXN0cnlgLCBzbyBgc2Vzc2lvbkF2YWlsYWJsZWAgaXMgZmFsc2UgdGhlcmUgYW5kIGl0IHN0YXlzIEFwcC1vbmx5IGFueXdheS4pXG4gIGNvbnN0IGlzQ29tbWFuZGVyID0gdXNlUmVnaW9uKCkgPT09IFwicGFnZS5jb21tYW5kZXJcIjtcbiAgY29uc3QgW2xlbnMsIHNldExlbnNdID0gdXNlU3RhdGU8TGVucz4oaXNDb21tYW5kZXIgPyBcInNlc3Npb25cIiA6IFwiYXBwXCIpO1xuICAvLyBGYWxsIGJhY2sgdG8gQXBwIGlmIHRoZSBzZXNzaW9uIHNpZ25hbCBnb2VzIGF3YXkgKG1vdW50cyByZXZva2VkIC8gbm90IGZpcnN0LXBhcnR5KS5cbiAgY29uc3QgZWZmZWN0aXZlTGVuczogTGVucyA9IHNlc3Npb25BdmFpbGFibGUgPyBsZW5zIDogXCJhcHBcIjtcbiAgY29uc3Qgc2hvd25Sb290cyA9IGVmZmVjdGl2ZUxlbnMgPT09IFwic2Vzc2lvblwiID8gc2Vzc2lvblJvb3RzIDogcm9vdHM7XG5cbiAgLy8gVGhlIFwiZmlsZSBjb21tYW5kZXJcIjogZXZlcnkgYXBwIHRoYXQgaGFzIHBlci11c2VyIHNldHRpbmdzIChlbGV2YXRlZFxuICAvLyBgc2V0dGluZ3M6YWxsYCkuIEVtcHR5IGZvciBhIGZvcmsvcHJldmlldyBsYWNraW5nIHRoZSBjYXBhYmlsaXR5LiBFYWNoIG9wZW5lZFxuICAvLyBhcHAncyBzZXR0aW5ncyBtb3VudCBmbG93cyBpbiBhcyBpdHMgb3duIHJvb3QgdmlhIGB1c2VTZGtSb290cygpYDsgdGhpcyBzbGljZVxuICAvLyBvbmx5IGRyaXZlcyBhIFwiY2xpY2sgdG8gb3BlblwiIGFmZm9yZGFuY2UgZm9yIGFwcHMgbm90IHlldCBtb3VudGVkLlxuICBjb25zdCBbc2V0dGluZ3NBcHBzLCBzZXRTZXR0aW5nc0FwcHNdID0gdXNlU3RhdGU8c3RyaW5nW10+KFtdKTtcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBsZXQgbGl2ZSA9IHRydWU7XG4gICAgdm9pZCBsaXN0U2V0dGluZ3NBcHBzKClcbiAgICAgIC50aGVuKChhcHBzKSA9PiBsaXZlICYmIHNldFNldHRpbmdzQXBwcyhhcHBzKSlcbiAgICAgIC5jYXRjaCgoKSA9PiB1bmRlZmluZWQpO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBsaXZlID0gZmFsc2U7XG4gICAgfTtcbiAgfSwgW10pO1xuICBjb25zdCBvcGVuQXBwU2V0dGluZ3MgPSB1c2VDYWxsYmFjaygoYXBwS2V5OiBzdHJpbmcpID0+IHtcbiAgICB2b2lkIG9wZW5TZXR0aW5nc09mKGFwcEtleSkuY2F0Y2goKCkgPT4gdW5kZWZpbmVkKTtcbiAgfSwgW10pO1xuXG4gIC8vIFIzLTI2OSBENTogXCJBZGQgYSBzcGFjZeKAplwiIGFza3MgdGhlIEhPU1QgcG93ZXJib3ggdG8gZW51bWVyYXRlICsgZ3JhbnRcbiAgLy8gKFItU1BBQ0VTLTI6IHRoZSBleHBsb3JlciBuZXZlciBsaXN0cyBzcGFjZXMgb3IgbWludHMgbW91bnRzIGl0c2VsZikuIFRoZSBncmFudGVkXG4gIC8vIG1vdW50IHRoZW4gZmxvd3MgaW4gdGhyb3VnaCBgdXNlTW91bnRzKClgIGxpa2UgYW55IG90aGVyLiBgY2FuY2VsbGVkYCBpcyBhIG5vcm1hbFxuICAvLyBvdXRjb21lLCBub3QgYW4gZXJyb3IuXG4gIGNvbnN0IGFkZFNwYWNlID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIHZvaWQgcmVxdWVzdE1vdW50KCkuY2F0Y2goKCkgPT4gdW5kZWZpbmVkKTtcbiAgfSwgW10pO1xuXG4gIC8vIFIzLTI2NzogdGhlIGBvcGVuc1dpdGhgIGNhbGxlci4gVGhlIHdyYXBwZWQgZnMgcHJvYmVzIGVhY2ggbGlzdGVkIGRpcmVjdG9yeSBmb3JcbiAgLy8gaXRzIGNvbnRlbnQgbWFya2VyLCBzbyBhIGZvbGRlciB0aGF0IGRlY2xhcmVzIHdoYXQgb3BlbnMgaXQgY2FuIGJlIG9mZmVyZWQgb25lLlxuICAvLyBSMy0xNTkgYWRkcyB0aGUgaW50by1zdGFnZSB0d2luOiBhIGxhdW5jaGFibGUgY29udHJhY3QgYWxzbyBnZXRzIFwiT3BlbiBpbiBwbGFjZVwiLlxuICBjb25zdCB7IGZzOiBvcGVuc1dpdGhGcywgb2ZmZXJGb3IsIGluUGxhY2VGb3IsIHdpdGhkcmF3LCB2aWV3T2ZmZXJzRm9yIH0gPSB1c2VPcGVuc1dpdGgoc2RrRnNTb3VyY2UpO1xuICBjb25zdCByb290QnlQYXRoID0gdXNlQ2FsbGJhY2soXG4gICAgKGFic1BhdGg6IHN0cmluZykgPT4gc2hvd25Sb290cy5maW5kKChyKSA9PiBhYnNQYXRoID09PSByLnBhdGggfHwgYWJzUGF0aC5zdGFydHNXaXRoKGAke3IucGF0aH0vYCkpID8/IG51bGwsXG4gICAgW3Nob3duUm9vdHNdLFxuICApO1xuICBjb25zdCBydW5PcGVuV2l0aCA9IHVzZUNhbGxiYWNrKFxuICAgIC8vIGBjaG9zZW5gIOKAlCBhIGRlY2xhcmVkIHZpZXcncyBvZmZlciAoUjMtNzg5KTsgYWJzZW50IOKHkiB0aGUgbWFya2VyJ3Mgb3duIG9mZmVyLlxuICAgIChhYnNQYXRoOiBzdHJpbmcsIGNob3Nlbj86IE9wZW5zV2l0aE9mZmVyKSA9PiB7XG4gICAgICBjb25zdCByb290ID0gcm9vdEJ5UGF0aChhYnNQYXRoKTtcbiAgICAgIGNvbnN0IG9mZmVyID0gY2hvc2VuID8/IG9mZmVyRm9yKGFic1BhdGgpO1xuICAgICAgaWYgKCFyb290IHx8ICFvZmZlcikgcmV0dXJuO1xuICAgICAgLy8gRmlyZS1hbmQtZm9yZ2V0OiB0aGUgaG9zdCBkcmF3cyB0aGUgdmlld2VyLiBFdmVyeSByZWZ1c2FsIGlzIGhhbmRsZWQgaW5zaWRlXG4gICAgICAvLyBgb3BlbldpdGhgIOKAlCBgY2FuY2VsbGVkYCBpcyB0aGUgb3JkaW5hcnkgY2xvc2UsIGFuZCBhIGNvbnRyYWN0LWxldmVsIHJlZnVzYWxcbiAgICAgIC8vIHdpdGhkcmF3cyB0aGUgYWZmb3JkYW5jZSByYXRoZXIgdGhhbiBwdXR0aW5nIGEgcHJvdG9jb2wgY29kZSBvbiBzY3JlZW4uXG4gICAgICB2b2lkIG9wZW5XaXRoKHJvb3QsIGFic1BhdGgsIG9mZmVyKS50aGVuKChvdXRjb21lKSA9PiB7XG4gICAgICAgIGlmIChvdXRjb21lLnN0YXR1cyA9PT0gXCJ3aXRoZHJhd1wiKSB3aXRoZHJhdyhvdXRjb21lLnRhc2spO1xuICAgICAgfSk7XG4gICAgfSxcbiAgICBbcm9vdEJ5UGF0aCwgb2ZmZXJGb3IsIHdpdGhkcmF3XSxcbiAgKTtcbiAgLy8gUjMtMTU5OiBmaXJlLWFuZC1mb3JnZXQgbGlrZSBydW5PcGVuV2l0aCDigJQgdGhlIGhvc3QgZHJhd3MgdGhlIGludG8tc3RhZ2Ugb3ZlcmxheVxuICAvLyBhbmQgdGhlIHN1c3BlbmQvcmVzdG9yZS4gQSBsYXVuY2ggcmVmdXNhbCBqdXN0IGRlY2xpbmVzIChpbnZpc2libHkpOiBubyBsYXVuY2hcbiAgLy8gY29kZSBpcyBhIHNlc3Npb24tcGVybWFuZW50IHZlcmRpY3QsIHNvIHRoZSBhZmZvcmRhbmNlIGFsd2F5cyBzdGF5cy5cbiAgY29uc3QgcnVuT3BlbkluUGxhY2UgPSB1c2VDYWxsYmFjayhcbiAgICAoYWJzUGF0aDogc3RyaW5nKSA9PiB7XG4gICAgICBjb25zdCByb290ID0gcm9vdEJ5UGF0aChhYnNQYXRoKTtcbiAgICAgIGNvbnN0IG9mZmVyID0gaW5QbGFjZUZvcihhYnNQYXRoKTtcbiAgICAgIGlmICghcm9vdCB8fCAhb2ZmZXIpIHJldHVybjtcbiAgICAgIHZvaWQgb3BlbkluUGxhY2Uocm9vdCwgYWJzUGF0aCwgb2ZmZXIpO1xuICAgIH0sXG4gICAgW3Jvb3RCeVBhdGgsIGluUGxhY2VGb3JdLFxuICApO1xuXG4gIGNvbnN0IGV4dHJhTWVudUl0ZW1zID0gdXNlQ2FsbGJhY2soKGN0eDogUm93Q3R4KTogTWVudUl0ZW1bXSA9PiB7XG4gICAgY29uc3QgaXRlbXMgPSBzdW1tYXJpemVNZW51SXRlbXMoY3R4LCBzZXRTdW1tYXJ5KTtcbiAgICAvLyBUaGUgYWZmb3JkYW5jZSBpcyBvbiB0aGUgSVRFTSwgb2ZmZXJlZCBieSB0aGUgbWFya2VyJ3Mgb3duIGBraW5kYCDigJQgbm8gdGFzayBuYW1lXG4gICAgLy8gcmVhY2hlcyB0aGlzIGNvZGUsIHNvIGEgZm9sZGVyIGRlY2xhcmluZyBhIGxhdGVyIGNvbnRyYWN0IHdvcmtzIHdpdGggbm8gY2hhbmdlXG4gICAgLy8gaGVyZSAob25seSBhIG1hbmlmZXN0IGVudHJ5LCB3aGljaCB0aGUgaG9zdCBlbmZvcmNlcyBhbnl3YXkpLlxuICAgIGNvbnN0IG9mZmVyID0gY3R4LmlzRGlyID8gb2ZmZXJGb3IoY3R4LmFic1BhdGgpIDogbnVsbDtcbiAgICBjb25zdCBpblBsYWNlID0gY3R4LmlzRGlyID8gaW5QbGFjZUZvcihjdHguYWJzUGF0aCkgOiBudWxsO1xuICAgIGNvbnN0IGRlY2xhcmVkVmlld3MgPSBjdHguaXNEaXIgPyB2aWV3T2ZmZXJzRm9yKGN0eC5hYnNQYXRoKSA6IFtdO1xuICAgIGlmIChvZmZlciB8fCBpblBsYWNlIHx8IGRlY2xhcmVkVmlld3MubGVuZ3RoID4gMCkge1xuICAgICAgLy8gVW5zaGlmdGVkIGFzIGEgcGFpciBzbyB0aGUgZm9yLXJlc3VsdCBvZmZlciBsZWFkcyBhbmQgdGhlIGludG8tc3RhZ2UgdHdpblxuICAgICAgLy8gKFIzLTE1OSkgc2l0cyBkaXJlY3RseSB1bmRlciBpdCwgYWJvdmUgZXZlcnl0aGluZyBlbHNlIHRoZSBtZW51IG9mZmVycy5cbiAgICAgIGNvbnN0IG9wZW5JdGVtczogTWVudUl0ZW1bXSA9IFtdO1xuICAgICAgaWYgKG9mZmVyKSB7XG4gICAgICAgIG9wZW5JdGVtcy5wdXNoKHtcbiAgICAgICAgICBrZXk6IFwib3Blbi13aXRoXCIsXG4gICAgICAgICAgbGFiZWw6IG9mZmVyLmxhYmVsLFxuICAgICAgICAgIGljb246IDxCb29rT3BlbiBzaXplPXsxNH0gYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz4sXG4gICAgICAgICAgb25TZWxlY3Q6ICgpID0+IHJ1bk9wZW5XaXRoKGN0eC5hYnNQYXRoKSxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICAvLyBSMy03ODkgKMKnNGIuMWEpOiBvbmUgaXRlbSBwZXIgZGVjbGFyZWQgdmlldywgdW5kZXIgdGhlIGJ1bmRsZSdzIG93biBvZmZlci5cbiAgICAgIGRlY2xhcmVkVmlld3MuZm9yRWFjaCgodiwgaSkgPT4ge1xuICAgICAgICBvcGVuSXRlbXMucHVzaCh7XG4gICAgICAgICAga2V5OiBgb3Blbi12aWV3LSR7aX1gLFxuICAgICAgICAgIGxhYmVsOiB2LmxhYmVsLFxuICAgICAgICAgIGljb246IDxCb29rT3BlbiBzaXplPXsxNH0gYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz4sXG4gICAgICAgICAgb25TZWxlY3Q6ICgpID0+IHJ1bk9wZW5XaXRoKGN0eC5hYnNQYXRoLCB2KSxcbiAgICAgICAgfSk7XG4gICAgICB9KTtcbiAgICAgIGlmIChpblBsYWNlKSB7XG4gICAgICAgIG9wZW5JdGVtcy5wdXNoKHtcbiAgICAgICAgICBrZXk6IFwib3Blbi1pbi1wbGFjZVwiLFxuICAgICAgICAgIGxhYmVsOiBpblBsYWNlLmxhYmVsLFxuICAgICAgICAgIGljb246IDxQbGF5IHNpemU9ezE0fSBhcmlhLWhpZGRlbj1cInRydWVcIiAvPixcbiAgICAgICAgICBvblNlbGVjdDogKCkgPT4gcnVuT3BlbkluUGxhY2UoY3R4LmFic1BhdGgpLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIGl0ZW1zLnVuc2hpZnQoLi4ub3Blbkl0ZW1zKTtcbiAgICB9XG4gICAgLy8gUjMtMjY5IEQ0OiB0aGUgcGVyLXNwYWNlIFwiTWFuYWdlIHNoYXJpbmcg4oaSXCIgZW50cnkgcG9pbnQsIG9uIHRoZSBzcGFjZSdzIFJPT1Qgcm93XG4gICAgLy8gb25seS4gT3BlbnMgdGhlIGZ1bGwtdGFiIHNwYWNlLW1hbmFnZXIgQVQgdGhhdCBzcGFjZSDigJQgdGhlIHZlcmJzIGxpdmUgdGhlcmUuXG4gICAgY29uc3Qgc3BhY2VJZCA9IGN0eC5tb3VudElkLnN0YXJ0c1dpdGgoXCJzcGFjZTpcIilcbiAgICAgID8gY3R4Lm1vdW50SWQuc2xpY2UoXCJzcGFjZTpcIi5sZW5ndGgpXG4gICAgICA6IG51bGw7XG4gICAgaWYgKGdldEhvc3RPcmlnaW4oKSAmJiBzcGFjZUlkICYmIGN0eC5hYnNQYXRoID09PSBjdHgucm9vdFBhdGgpIHtcbiAgICAgIGl0ZW1zLnB1c2goe1xuICAgICAgICBrZXk6IFwibWFuYWdlLXNoYXJpbmdcIixcbiAgICAgICAgbGFiZWw6IFwiTWFuYWdlIHNoYXJpbmcg4oaSXCIsXG4gICAgICAgIGljb246IDxVc2VycyBzaXplPXsxNH0gYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz4sXG4gICAgICAgIG9uU2VsZWN0OiAoKSA9PiBvcGVuTWFuYWdlU2hhcmluZyhzcGFjZUlkKSxcbiAgICAgIH0pO1xuICAgIH1cbiAgICByZXR1cm4gaXRlbXM7XG4gIH0sIFtvZmZlckZvciwgaW5QbGFjZUZvciwgdmlld09mZmVyc0ZvciwgcnVuT3BlbldpdGgsIHJ1bk9wZW5JblBsYWNlXSk7XG5cbiAgLy8gQXBwcyB3aXRoIHBlci11c2VyIHNldHRpbmdzIHRoYXQgYXJlbid0IG1vdW50ZWQgeWV0IOKAlCBjbGljayB0byBvcGVuXG4gIC8vIChgc2V0dGluZ3M6YWxsYCkuIEFuIGFscmVhZHktb3BlbmVkIHNldHRpbmdzIG1vdW50IHJlbmRlcnMgYXMgaXRzIG93biByb290XG4gIC8vICh2aWEgYHVzZVNka1Jvb3RzYCksIHNvIGZpbHRlciB0aG9zZSBvdXQuIFN1cmZhY2VkIGluIHRoZSBoZWFkZXIgKHRoZSB2aWV3IGlzXG4gIC8vIHNldHRpbmdzLWFwcC1hZ25vc3RpYyBwZXIgUGhhc2UgMDIgwqdBLjEpLlxuICBjb25zdCB1bm1vdW50ZWRTZXR0aW5nc0FwcHMgPSBzZXR0aW5nc0FwcHMuZmlsdGVyKFxuICAgIChhaykgPT4gIW1vdW50cy5zb21lKChtKSA9PiBtLmlkID09PSBgc2V0dGluZ3M6JHtha31gKSxcbiAgKTtcbiAgY29uc3Qgc2V0dGluZ3NCdXR0b25zID1cbiAgICBzaG93QWxsICYmIHVubW91bnRlZFNldHRpbmdzQXBwcy5sZW5ndGggPiAwXG4gICAgICA/IHVubW91bnRlZFNldHRpbmdzQXBwcy5tYXAoKGFrKSA9PiAoXG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAga2V5PXtha31cbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwic2V0dGluZ3MtYXBwXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9wZW5BcHBTZXR0aW5ncyhhayl9XG4gICAgICAgICAgICB0aXRsZT17YE9wZW4gJHtha30gc2V0dGluZ3NgfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxGb2xkZXJUcmVlIHNpemU9ezE0fSBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgICAgey8qIFRoZSBsYWJlbCBpcyBpdHMgb3duIGVsZW1lbnQgc28gaXQgY2FuIGVsbGlwc2lzLXRydW5jYXRlIChSMy0yMzkpOlxuICAgICAgICAgICAgICAgIGB0ZXh0LW92ZXJmbG93YCBuZWVkcyBhIGJsb2NrIGNvbnRhaW5lciwgYW5kIGEgYmFyZSB0ZXh0IG5vZGUgaW5zaWRlXG4gICAgICAgICAgICAgICAgYSBmbGV4IGJ1dHRvbiBpcyBhbiBhbm9ueW1vdXMgaXRlbSB0aGF0IGNhbiBvbmx5IG92ZXJmbG93LiAqL31cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNldHRpbmdzLWFwcF9fbGFiZWxcIj5zZXR0aW5ncyDCtyB7YWt9PC9zcGFuPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICApKVxuICAgICAgOiBudWxsO1xuXG4gIC8vIFRoZSByZXZlYWwgYWZmb3JkYW5jZSBpcyBvZmZlcmVkIG9ubHkgd2hlbiB0aGlzIHNlc3Npb24gYWN0dWFsbHkgSEFTIHNvbWV0aGluZ1xuICAvLyBoaWRkZW4g4oCUIG90aGVyd2lzZSBldmVyeSBvcmRpbmFyeSBzZXNzaW9uIHBheXMgZm9yIGFuIGFkdmFuY2VkIGNvbnRyb2wgaXQgY2FuXG4gIC8vIG5ldmVyIHVzZS4gT25jZSB0aGUgZmxhZyBpcyBvbiBpdCBzdGF5cyBvZmZlcmVkLCBzbyB0aGUgZG9vciBzd2luZ3MgYm90aCB3YXlzLlxuICBjb25zdCBoYXNIaWRkZW4gPVxuICAgIG1vdW50cy5zb21lKGlzU2V0dGluZ3NNb3VudCkgfHwgc2Vzc2lvbkhpZGRlbiA+IDAgfHwgdW5tb3VudGVkU2V0dGluZ3NBcHBzLmxlbmd0aCA+IDA7XG4gIGNvbnN0IHNob3dBbGxUb2dnbGUgPVxuICAgIHNob3dBbGwgfHwgaGFzSGlkZGVuID8gKFxuICAgICAgPGJ1dHRvblxuICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgY2xhc3NOYW1lPVwicGFuZWxfX2FjdGlvblwiXG4gICAgICAgIGFyaWEtcHJlc3NlZD17c2hvd0FsbH1cbiAgICAgICAgdGl0bGU9e3Nob3dBbGwgPyBcIkhpZGUgYWR2YW5jZWQgZmlsZXN5c3RlbXNcIiA6IFwiU2hvdyBhbGwgZmlsZXN5c3RlbXNcIn1cbiAgICAgICAgYXJpYS1sYWJlbD17c2hvd0FsbCA/IFwiSGlkZSBhZHZhbmNlZCBmaWxlc3lzdGVtc1wiIDogXCJTaG93IGFsbCBmaWxlc3lzdGVtc1wifVxuICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93QWxsKCFzaG93QWxsKX1cbiAgICAgID5cbiAgICAgICAge3Nob3dBbGwgPyA8RXllIHNpemU9ezE1fSBhcmlhLWhpZGRlbj1cInRydWVcIiAvPiA6IDxFeWVPZmYgc2l6ZT17MTV9IGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+fVxuICAgICAgPC9idXR0b24+XG4gICAgKSA6IG51bGw7XG5cbiAgLy8gUjMtMjY5IEQ1OiB0aGUgZXhwbG9yZXIgaXMgdGhlIGFkZC1hLXNwYWNlIGVudHJ5IHBvaW50IOKAlCBhIGhlYWRlciBhZmZvcmRhbmNlXG4gIC8vIHRoYXQgaW52b2tlcyB0aGUgaG9zdCBwb3dlcmJveC4gQWx3YXlzIG9mZmVyZWQgKGl0IG1heSBiZSB0aGUgdmVyeSBjb250cm9sIHRoYXRcbiAgLy8gcHJvZHVjZXMgdGhlIGZpcnN0IHJvb3QpLlxuICBjb25zdCBhZGRTcGFjZUJ1dHRvbiA9IChcbiAgICA8YnV0dG9uXG4gICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgIGNsYXNzTmFtZT1cInBhbmVsX19hY3Rpb25cIlxuICAgICAgdGl0bGU9XCJBZGQgYSBzcGFjZeKAplwiXG4gICAgICBhcmlhLWxhYmVsPVwiQWRkIGEgc3BhY2XigKZcIlxuICAgICAgb25DbGljaz17YWRkU3BhY2V9XG4gICAgPlxuICAgICAgPFBsdXMgc2l6ZT17MTV9IGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgPC9idXR0b24+XG4gICk7XG5cbiAgLy8gVGhlIFNlc3Npb24gbGVucyB0b2dnbGUgbGVhZHMgdGhlIGhlYWRlciBhY3Rpb25zLCBidXQgb25seSB3aGVuIHRoZSBob3N0XG4gIC8vIGRlbGl2ZXJlZCBhIHNlc3Npb24gc2lnbmFsIChmaXJzdC1wYXJ0eSkuIEEgZm9yayBuZXZlciBzZWVzIGl0LlxuICBjb25zdCBoZWFkZXJBY3Rpb25zID0gKFxuICAgIDw+XG4gICAgICB7c2Vzc2lvbkF2YWlsYWJsZSAmJiA8TGVuc1N3aXRjaGVyIHZhbHVlPXtlZmZlY3RpdmVMZW5zfSBvbkNoYW5nZT17c2V0TGVuc30gLz59XG4gICAgICB7YWRkU3BhY2VCdXR0b259XG4gICAgICB7c2hvd0FsbFRvZ2dsZX1cbiAgICA8Lz5cbiAgKTtcbiAgLy8gTk9UIGluIGBoZWFkZXJBY3Rpb25zYDogdGhlcmUgaXMgb25lIG9mIHRoZXNlIHBlciBhcHAgd2l0aCBzZXR0aW5ncywgc28gdGhlIGNvdW50XG4gIC8vIGdyb3dzIHdpdGggdGhlIHNlc3Npb24uIFNoYXJpbmcgYSBmaXhlZCByb3cgb3V0IGFtb25nIGFuIHVuYm91bmRlZCBOIGlzIHdoYXRcbiAgLy8gc3F1YXNoZWQgdGhlbSBpbnRvIG92ZXJsYXBwaW5nIHNsaXZlcnMgb24gYSBwaG9uZTsgdGhlIHRyYXkgaXMgYSByb3cgb2YgdGhlaXIgb3duLlxuICBjb25zdCBoZWFkZXJUcmF5ID0gc2V0dGluZ3NCdXR0b25zO1xuXG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIDxGaWxlRXhwbG9yZXJWaWV3XG4gICAgICAgIHJvb3RzPXtzaG93blJvb3RzfVxuICAgICAgICBmcz17b3BlbnNXaXRoRnN9XG4gICAgICAgIGFjdGlvbnM9e2FjdGlvbnN9XG4gICAgICAgIGFjdGl2ZVBhdGg9e2FjdGl2ZUZpbGV9XG4gICAgICAgIHZpZXdlZFBhdGg9e3ZpZXdlZEZpbGV9XG4gICAgICAgIGV4dHJhTWVudUl0ZW1zPXtleHRyYU1lbnVJdGVtc31cbiAgICAgICAgcmV2ZWFsPXtyZXZlYWx9XG4gICAgICAgIGhlYWRlcj17eyBhY3Rpb25zOiBoZWFkZXJBY3Rpb25zLCB0cmF5OiBoZWFkZXJUcmF5IH19XG4gICAgICAgIGVtcHR5U3RhdGU9e1xuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3RhdGVcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInN0YXRlX19pY29uXCI+XG4gICAgICAgICAgICAgIDxGb2xkZXJUcmVlIHNpemU9ezIwfSBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPGg0Pk5vIGZpbGVzIHRvIHNob3cgeWV0LjwvaDQ+XG4gICAgICAgICAgICB7LyogUjMtMjY5IEQ2IGZpcnN0LXRpbWVyIHNlbnRlbmNlLCBSLVNQQUNFUy0xIHZvY2FidWxhcnkuICovfVxuICAgICAgICAgICAgPHA+XG4gICAgICAgICAgICAgIEEgc3BhY2UgaXMgYSBmb2xkZXIgdGhhdCBsaXZlcyBpbiB5b3VyIGFjY291bnQuIFlvdSBjYW4gc2hhcmUgaXQgd2l0aFxuICAgICAgICAgICAgICBvdGhlcnMgYW5kIG9wZW4gaXQgZnJvbSBhbnkgYXBwLlxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwic3RhdGVfX2FjdGlvblwiIG9uQ2xpY2s9e2FkZFNwYWNlfT5cbiAgICAgICAgICAgICAgPFBsdXMgc2l6ZT17MTR9IGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgICAgIEFkZCBhIHNwYWNl4oCmXG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgfVxuICAgICAgLz5cbiAgICAgIHtzdW1tYXJ5ICYmIDxTdW1tYXJ5TW9kYWwgdGFyZ2V0PXtzdW1tYXJ5fSBvbkNsb3NlPXsoKSA9PiBzZXRTdW1tYXJ5KG51bGwpfSAvPn1cbiAgICA8Lz5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgU2RrRmlsZUV4cGxvcmVyO1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7QUFTQSxJQUFBQSxNQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxZQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxJQUFBLEdBQUFGLE9BQUE7QUFTQSxJQUFBRyxhQUFBLEdBQUFILE9BQUE7QUFDQSxJQUFBSSxpQkFBQSxHQUFBQyxzQkFBQSxDQUFBTCxPQUFBO0FBQ0EsSUFBQU0sYUFBQSxHQUFBRCxzQkFBQSxDQUFBTCxPQUFBO0FBQ0EsSUFBQU8sc0JBQUEsR0FBQVAsT0FBQTtBQUNBLElBQUFRLE9BQUEsR0FBQVIsT0FBQTtBQUNBLElBQUFTLFlBQUEsR0FBQVQsT0FBQTtBQUNBLElBQUFVLGdCQUFBLEdBQUFWLE9BQUE7QUFDQSxJQUFBVyxRQUFBLEdBQUFYLE9BQUE7QUFDQSxJQUFBWSxRQUFBLEdBQUFaLE9BQUE7QUFDQSxJQUFBYSxVQUFBLEdBQUFiLE9BQUE7QUFDQSxJQUFBYyxhQUFBLEdBQUFkLE9BQUE7QUFFQSxJQUFBZSxTQUFBLEdBQUFmLE9BQUE7QUFDQSxJQUFBZ0IsYUFBQSxHQUFBWCxzQkFBQSxDQUFBTCxPQUFBO0FBQWtFLElBQUFpQixXQUFBLEdBQUFqQixPQUFBO0FBQUEsSUFBQWtCLEVBQUEsR0FBQUMsWUFBQSxJQWpDbEU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQUEsU0FBQWQsdUJBQUFlLENBQUEsV0FBQUEsQ0FBQSxJQUFBQSxDQUFBLENBQUFDLFVBQUEsR0FBQUQsQ0FBQSxLQUFBRSxPQUFBLEVBQUFGLENBQUE7QUE0QkE7QUFDQSxNQUFNRyxPQUF3QixHQUFHLElBQUFDLHVCQUFjLEVBQUMsQ0FBQzs7QUFFakQ7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNQyxhQUFhLEdBQUdBLENBQUEsS0FBcUI7RUFDekMsSUFBSTtJQUNGLE1BQU1DLElBQUksR0FBRyxJQUFJQyxlQUFlLENBQUNDLE1BQU0sQ0FBQ0MsUUFBUSxDQUFDQyxNQUFNLENBQUMsQ0FBQ0MsR0FBRyxDQUFDLE1BQU0sQ0FBQztJQUNwRSxPQUFPTCxJQUFJLEdBQUcsSUFBSU0sR0FBRyxDQUFDTixJQUFJLENBQUMsQ0FBQ08sTUFBTSxHQUFHLElBQUk7RUFDM0MsQ0FBQyxDQUFDLE1BQU07SUFDTixPQUFPLElBQUk7RUFDYjtBQUNGLENBQUM7O0FBRUQ7QUFDQTtBQUNBLE1BQU1DLGlCQUFpQixHQUFJQyxPQUFlLElBQUs7RUFDN0MsTUFBTUMsVUFBVSxHQUFHWCxhQUFhLENBQUMsQ0FBQztFQUNsQyxJQUFJLENBQUNXLFVBQVUsRUFBRTtFQUNqQlIsTUFBTSxDQUFDUyxJQUFJLENBQ1QsR0FBR0QsVUFBVSxpQkFBaUJFLGtCQUFrQixDQUFDSCxPQUFPLENBQUMsRUFBRSxFQUMzRCxRQUFRLEVBQ1IscUJBQ0YsQ0FBQztBQUNILENBQUM7QUFFRCxTQUFTSSxlQUFlQSxDQUFBLEVBQUc7RUFBQXJCLEVBQUE7RUFDekI7RUFDQTtFQUNBO0VBQ0EsTUFBTSxDQUFDc0IsT0FBTyxFQUFFQyxVQUFVLENBQUMsR0FBRyxJQUFBQyw0Q0FBcUIsRUFBQyxDQUFDO0VBQ3JELE1BQU1DLEtBQUssR0FBRyxJQUFBQyx3QkFBVyxFQUFDSixPQUFPLENBQUM7RUFDbEMsTUFBTUssTUFBTSxHQUFHLElBQUFDLGNBQVMsRUFBQyxDQUFDO0VBQzFCLE1BQU1DLGFBQWEsR0FBRyxJQUFBQyxxQkFBZ0IsRUFBQyxDQUFDO0VBQ3hDLE1BQU07SUFBRUM7RUFBVyxDQUFDLEdBQUdGLGFBQWE7RUFDcEM7RUFDQTtFQUNBO0VBQ0EsTUFBTUcsVUFBVSxHQUNiSCxhQUFhLENBQW9DRyxVQUFVLElBQUksSUFBSTtFQUN0RSxNQUFNLENBQUNDLE9BQU8sRUFBRUMsVUFBVSxDQUFDLEdBQUcsSUFBQUMsZUFBUSxFQUF1QixJQUFJLENBQUM7RUFDbEU7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU0sQ0FBQ0MsTUFBTSxFQUFFQyxTQUFTLENBQUMsR0FBRyxJQUFBRixlQUFRLEVBQXlDLElBQUksQ0FBQztFQUNsRixNQUFNRyxjQUFjLEdBQUcsSUFBQUMsYUFBTSxFQUFDLENBQUMsQ0FBQztFQUNoQyxJQUFBQyxnQkFBUyxFQUFDLE1BQU07SUFDZCxJQUFJQyxPQUFpQztJQUNyQyxJQUFJO01BQ0ZBLE9BQU8sR0FBRyxJQUFBQyx5QkFBVyxFQUFDLGVBQWUsRUFBR0MsQ0FBcUIsSUFBSztRQUNoRSxJQUFJLE9BQU9BLENBQUMsQ0FBQ0MsSUFBSSxLQUFLLFFBQVEsRUFBRTtVQUM5Qk4sY0FBYyxDQUFDTyxPQUFPLElBQUksQ0FBQztVQUMzQlIsU0FBUyxDQUFDO1lBQUVPLElBQUksRUFBRUQsQ0FBQyxDQUFDQyxJQUFJO1lBQUVFLEtBQUssRUFBRVIsY0FBYyxDQUFDTztVQUFRLENBQUMsQ0FBQztRQUM1RDtNQUNGLENBQUMsQ0FBQztNQUNGO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0EsSUFBQUUsZ0JBQVcsRUFBQyxDQUFDO0lBQ2YsQ0FBQyxDQUFDLE1BQU07TUFDTjtJQUFBO0lBRUYsT0FBTyxNQUFNTixPQUFPLEdBQUcsQ0FBQztFQUMxQixDQUFDLEVBQUUsRUFBRSxDQUFDOztFQUVOO0VBQ0E7RUFDQTtFQUNBLE1BQU07SUFDSmhCLEtBQUssRUFBRXVCLFlBQVk7SUFDbkJDLFNBQVMsRUFBRUMsZ0JBQWdCO0lBQzNCQyxNQUFNLEVBQUVDO0VBQ1YsQ0FBQyxHQUFHLElBQUFDLGdDQUFlLEVBQUMvQixPQUFPLENBQUM7RUFDNUI7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU1nQyxXQUFXLEdBQUcsSUFBQUMsY0FBUyxFQUFDLENBQUMsS0FBSyxnQkFBZ0I7RUFDcEQsTUFBTSxDQUFDQyxJQUFJLEVBQUVDLE9BQU8sQ0FBQyxHQUFHLElBQUF0QixlQUFRLEVBQU9tQixXQUFXLEdBQUcsU0FBUyxHQUFHLEtBQUssQ0FBQztFQUN2RTtFQUNBLE1BQU1JLGFBQW1CLEdBQUdSLGdCQUFnQixHQUFHTSxJQUFJLEdBQUcsS0FBSztFQUMzRCxNQUFNRyxVQUFVLEdBQUdELGFBQWEsS0FBSyxTQUFTLEdBQUdWLFlBQVksR0FBR3ZCLEtBQUs7O0VBRXJFO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsTUFBTSxDQUFDbUMsWUFBWSxFQUFFQyxlQUFlLENBQUMsR0FBRyxJQUFBMUIsZUFBUSxFQUFXLEVBQUUsQ0FBQztFQUM5RCxJQUFBSyxnQkFBUyxFQUFDLE1BQU07SUFDZCxJQUFJc0IsSUFBSSxHQUFHLElBQUk7SUFDZixLQUFLLElBQUFDLHFCQUFnQixFQUFDLENBQUMsQ0FDcEJDLElBQUksQ0FBRUMsSUFBSSxJQUFLSCxJQUFJLElBQUlELGVBQWUsQ0FBQ0ksSUFBSSxDQUFDLENBQUMsQ0FDN0NDLEtBQUssQ0FBQyxNQUFNQyxTQUFTLENBQUM7SUFDekIsT0FBTyxNQUFNO01BQ1hMLElBQUksR0FBRyxLQUFLO0lBQ2QsQ0FBQztFQUNILENBQUMsRUFBRSxFQUFFLENBQUM7RUFDTixNQUFNTSxlQUFlLEdBQUcsSUFBQUMsa0JBQVcsRUFBRUMsTUFBYyxJQUFLO0lBQ3RELEtBQUssSUFBQUMsbUJBQWMsRUFBQ0QsTUFBTSxDQUFDLENBQUNKLEtBQUssQ0FBQyxNQUFNQyxTQUFTLENBQUM7RUFDcEQsQ0FBQyxFQUFFLEVBQUUsQ0FBQzs7RUFFTjtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU1LLFFBQVEsR0FBRyxJQUFBSCxrQkFBVyxFQUFDLE1BQU07SUFDakMsS0FBSyxJQUFBSSxpQkFBWSxFQUFDLENBQUMsQ0FBQ1AsS0FBSyxDQUFDLE1BQU1DLFNBQVMsQ0FBQztFQUM1QyxDQUFDLEVBQUUsRUFBRSxDQUFDOztFQUVOO0VBQ0E7RUFDQTtFQUNBLE1BQU07SUFBRU8sRUFBRSxFQUFFQyxXQUFXO0lBQUVDLFFBQVE7SUFBRUMsVUFBVTtJQUFFQyxRQUFRO0lBQUVDO0VBQWMsQ0FBQyxHQUFHLElBQUFDLDBCQUFZLEVBQUNDLG9CQUFXLENBQUM7RUFDcEcsTUFBTUMsVUFBVSxHQUFHLElBQUFiLGtCQUFXLEVBQzNCYyxPQUFlLElBQUt4QixVQUFVLENBQUN5QixJQUFJLENBQUVDLENBQUMsSUFBS0YsT0FBTyxLQUFLRSxDQUFDLENBQUN6QyxJQUFJLElBQUl1QyxPQUFPLENBQUNHLFVBQVUsQ0FBQyxHQUFHRCxDQUFDLENBQUN6QyxJQUFJLEdBQUcsQ0FBQyxDQUFDLElBQUksSUFBSSxFQUMzRyxDQUFDZSxVQUFVLENBQ2IsQ0FBQztFQUNELE1BQU00QixXQUFXLEdBQUcsSUFBQWxCLGtCQUFXO0VBQzdCO0VBQ0EsQ0FBQ2MsT0FBZSxFQUFFSyxNQUF1QixLQUFLO0lBQzVDLE1BQU1DLElBQUksR0FBR1AsVUFBVSxDQUFDQyxPQUFPLENBQUM7SUFDaEMsTUFBTU8sS0FBSyxHQUFHRixNQUFNLElBQUlaLFFBQVEsQ0FBQ08sT0FBTyxDQUFDO0lBQ3pDLElBQUksQ0FBQ00sSUFBSSxJQUFJLENBQUNDLEtBQUssRUFBRTtJQUNyQjtJQUNBO0lBQ0E7SUFDQSxLQUFLLElBQUFDLGtCQUFRLEVBQUNGLElBQUksRUFBRU4sT0FBTyxFQUFFTyxLQUFLLENBQUMsQ0FBQzFCLElBQUksQ0FBRTRCLE9BQU8sSUFBSztNQUNwRCxJQUFJQSxPQUFPLENBQUNDLE1BQU0sS0FBSyxVQUFVLEVBQUVmLFFBQVEsQ0FBQ2MsT0FBTyxDQUFDRSxJQUFJLENBQUM7SUFDM0QsQ0FBQyxDQUFDO0VBQ0osQ0FBQyxFQUNELENBQUNaLFVBQVUsRUFBRU4sUUFBUSxFQUFFRSxRQUFRLENBQ2pDLENBQUM7RUFDRDtFQUNBO0VBQ0E7RUFDQSxNQUFNaUIsY0FBYyxHQUFHLElBQUExQixrQkFBVyxFQUMvQmMsT0FBZSxJQUFLO0lBQ25CLE1BQU1NLElBQUksR0FBR1AsVUFBVSxDQUFDQyxPQUFPLENBQUM7SUFDaEMsTUFBTU8sS0FBSyxHQUFHYixVQUFVLENBQUNNLE9BQU8sQ0FBQztJQUNqQyxJQUFJLENBQUNNLElBQUksSUFBSSxDQUFDQyxLQUFLLEVBQUU7SUFDckIsS0FBSyxJQUFBTSxxQkFBVyxFQUFDUCxJQUFJLEVBQUVOLE9BQU8sRUFBRU8sS0FBSyxDQUFDO0VBQ3hDLENBQUMsRUFDRCxDQUFDUixVQUFVLEVBQUVMLFVBQVUsQ0FDekIsQ0FBQztFQUVELE1BQU1vQixjQUFjLEdBQUcsSUFBQTVCLGtCQUFXLEVBQUU2QixHQUFXLElBQWlCO0lBQzlELE1BQU1DLEtBQUssR0FBRyxJQUFBQyw2QkFBa0IsRUFBQ0YsR0FBRyxFQUFFaEUsVUFBVSxDQUFDO0lBQ2pEO0lBQ0E7SUFDQTtJQUNBLE1BQU13RCxLQUFLLEdBQUdRLEdBQUcsQ0FBQ0csS0FBSyxHQUFHekIsUUFBUSxDQUFDc0IsR0FBRyxDQUFDZixPQUFPLENBQUMsR0FBRyxJQUFJO0lBQ3RELE1BQU1tQixPQUFPLEdBQUdKLEdBQUcsQ0FBQ0csS0FBSyxHQUFHeEIsVUFBVSxDQUFDcUIsR0FBRyxDQUFDZixPQUFPLENBQUMsR0FBRyxJQUFJO0lBQzFELE1BQU1vQixhQUFhLEdBQUdMLEdBQUcsQ0FBQ0csS0FBSyxHQUFHdEIsYUFBYSxDQUFDbUIsR0FBRyxDQUFDZixPQUFPLENBQUMsR0FBRyxFQUFFO0lBQ2pFLElBQUlPLEtBQUssSUFBSVksT0FBTyxJQUFJQyxhQUFhLENBQUNDLE1BQU0sR0FBRyxDQUFDLEVBQUU7TUFDaEQ7TUFDQTtNQUNBLE1BQU1DLFNBQXFCLEdBQUcsRUFBRTtNQUNoQyxJQUFJZixLQUFLLEVBQUU7UUFDVGUsU0FBUyxDQUFDQyxJQUFJLENBQUM7VUFDYkMsR0FBRyxFQUFFLFdBQVc7VUFDaEJDLEtBQUssRUFBRWxCLEtBQUssQ0FBQ2tCLEtBQUs7VUFDbEJDLElBQUksZUFBRSxJQUFBOUcsV0FBQSxDQUFBK0csR0FBQSxFQUFDL0gsWUFBQSxDQUFBZ0ksUUFBUTtZQUFDQyxJQUFJLEVBQUUsRUFBRztZQUFDLGVBQVk7VUFBTSxDQUFFLENBQUM7VUFDL0NDLFFBQVEsRUFBRUEsQ0FBQSxLQUFNMUIsV0FBVyxDQUFDVyxHQUFHLENBQUNmLE9BQU87UUFDekMsQ0FBQyxDQUFDO01BQ0o7TUFDQTtNQUNBb0IsYUFBYSxDQUFDVyxPQUFPLENBQUMsQ0FBQ0MsQ0FBQyxFQUFFQyxDQUFDLEtBQUs7UUFDOUJYLFNBQVMsQ0FBQ0MsSUFBSSxDQUFDO1VBQ2JDLEdBQUcsRUFBRSxhQUFhUyxDQUFDLEVBQUU7VUFDckJSLEtBQUssRUFBRU8sQ0FBQyxDQUFDUCxLQUFLO1VBQ2RDLElBQUksZUFBRSxJQUFBOUcsV0FBQSxDQUFBK0csR0FBQSxFQUFDL0gsWUFBQSxDQUFBZ0ksUUFBUTtZQUFDQyxJQUFJLEVBQUUsRUFBRztZQUFDLGVBQVk7VUFBTSxDQUFFLENBQUM7VUFDL0NDLFFBQVEsRUFBRUEsQ0FBQSxLQUFNMUIsV0FBVyxDQUFDVyxHQUFHLENBQUNmLE9BQU8sRUFBRWdDLENBQUM7UUFDNUMsQ0FBQyxDQUFDO01BQ0osQ0FBQyxDQUFDO01BQ0YsSUFBSWIsT0FBTyxFQUFFO1FBQ1hHLFNBQVMsQ0FBQ0MsSUFBSSxDQUFDO1VBQ2JDLEdBQUcsRUFBRSxlQUFlO1VBQ3BCQyxLQUFLLEVBQUVOLE9BQU8sQ0FBQ00sS0FBSztVQUNwQkMsSUFBSSxlQUFFLElBQUE5RyxXQUFBLENBQUErRyxHQUFBLEVBQUMvSCxZQUFBLENBQUFzSSxJQUFJO1lBQUNMLElBQUksRUFBRSxFQUFHO1lBQUMsZUFBWTtVQUFNLENBQUUsQ0FBQztVQUMzQ0MsUUFBUSxFQUFFQSxDQUFBLEtBQU1sQixjQUFjLENBQUNHLEdBQUcsQ0FBQ2YsT0FBTztRQUM1QyxDQUFDLENBQUM7TUFDSjtNQUNBZ0IsS0FBSyxDQUFDbUIsT0FBTyxDQUFDLEdBQUdiLFNBQVMsQ0FBQztJQUM3QjtJQUNBO0lBQ0E7SUFDQSxNQUFNeEYsT0FBTyxHQUFHaUYsR0FBRyxDQUFDcUIsT0FBTyxDQUFDakMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxHQUM1Q1ksR0FBRyxDQUFDcUIsT0FBTyxDQUFDQyxLQUFLLENBQUMsUUFBUSxDQUFDaEIsTUFBTSxDQUFDLEdBQ2xDLElBQUk7SUFDUixJQUFJakcsYUFBYSxDQUFDLENBQUMsSUFBSVUsT0FBTyxJQUFJaUYsR0FBRyxDQUFDZixPQUFPLEtBQUtlLEdBQUcsQ0FBQ3VCLFFBQVEsRUFBRTtNQUM5RHRCLEtBQUssQ0FBQ08sSUFBSSxDQUFDO1FBQ1RDLEdBQUcsRUFBRSxnQkFBZ0I7UUFDckJDLEtBQUssRUFBRSxrQkFBa0I7UUFDekJDLElBQUksZUFBRSxJQUFBOUcsV0FBQSxDQUFBK0csR0FBQSxFQUFDL0gsWUFBQSxDQUFBMkksS0FBSztVQUFDVixJQUFJLEVBQUUsRUFBRztVQUFDLGVBQVk7UUFBTSxDQUFFLENBQUM7UUFDNUNDLFFBQVEsRUFBRUEsQ0FBQSxLQUFNakcsaUJBQWlCLENBQUNDLE9BQU87TUFDM0MsQ0FBQyxDQUFDO0lBQ0o7SUFDQSxPQUFPa0YsS0FBSztFQUNkLENBQUMsRUFBRSxDQUFDdkIsUUFBUSxFQUFFQyxVQUFVLEVBQUVFLGFBQWEsRUFBRVEsV0FBVyxFQUFFUSxjQUFjLENBQUMsQ0FBQzs7RUFFdEU7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNNEIscUJBQXFCLEdBQUcvRCxZQUFZLENBQUNnRSxNQUFNLENBQzlDQyxFQUFFLElBQUssQ0FBQ2xHLE1BQU0sQ0FBQ21HLElBQUksQ0FBRW5GLENBQUMsSUFBS0EsQ0FBQyxDQUFDb0YsRUFBRSxLQUFLLFlBQVlGLEVBQUUsRUFBRSxDQUN2RCxDQUFDO0VBQ0QsTUFBTUcsZUFBZSxHQUNuQjFHLE9BQU8sSUFBSXFHLHFCQUFxQixDQUFDbkIsTUFBTSxHQUFHLENBQUMsR0FDdkNtQixxQkFBcUIsQ0FBQ00sR0FBRyxDQUFFSixFQUFFLGlCQUMzQixJQUFBOUgsV0FBQSxDQUFBbUksSUFBQTtJQUVFQyxJQUFJLEVBQUMsUUFBUTtJQUNiQyxTQUFTLEVBQUMsY0FBYztJQUN4QkMsT0FBTyxFQUFFQSxDQUFBLEtBQU1qRSxlQUFlLENBQUN5RCxFQUFFLENBQUU7SUFDbkNTLEtBQUssRUFBRSxRQUFRVCxFQUFFLFdBQVk7SUFBQVUsUUFBQSxnQkFFN0IsSUFBQXhJLFdBQUEsQ0FBQStHLEdBQUEsRUFBQy9ILFlBQUEsQ0FBQXlKLFVBQVU7TUFBQ3hCLElBQUksRUFBRSxFQUFHO01BQUMsZUFBWTtJQUFNLENBQUUsQ0FBQyxlQUkzQyxJQUFBakgsV0FBQSxDQUFBbUksSUFBQTtNQUFNRSxTQUFTLEVBQUMscUJBQXFCO01BQUFHLFFBQUEsR0FBQyxnQkFBVyxFQUFDVixFQUFFO0lBQUEsQ0FBTyxDQUFDO0VBQUEsR0FWdkRBLEVBV0MsQ0FDVCxDQUFDLEdBQ0YsSUFBSTs7RUFFVjtFQUNBO0VBQ0E7RUFDQSxNQUFNWSxTQUFTLEdBQ2I5RyxNQUFNLENBQUNtRyxJQUFJLENBQUNZLHVCQUFlLENBQUMsSUFBSXRGLGFBQWEsR0FBRyxDQUFDLElBQUl1RSxxQkFBcUIsQ0FBQ25CLE1BQU0sR0FBRyxDQUFDO0VBQ3ZGLE1BQU1tQyxhQUFhLEdBQ2pCckgsT0FBTyxJQUFJbUgsU0FBUyxnQkFDbEIsSUFBQTFJLFdBQUEsQ0FBQStHLEdBQUE7SUFDRXFCLElBQUksRUFBQyxRQUFRO0lBQ2JDLFNBQVMsRUFBQyxlQUFlO0lBQ3pCLGdCQUFjOUcsT0FBUTtJQUN0QmdILEtBQUssRUFBRWhILE9BQU8sR0FBRywyQkFBMkIsR0FBRyxzQkFBdUI7SUFDdEUsY0FBWUEsT0FBTyxHQUFHLDJCQUEyQixHQUFHLHNCQUF1QjtJQUMzRStHLE9BQU8sRUFBRUEsQ0FBQSxLQUFNOUcsVUFBVSxDQUFDLENBQUNELE9BQU8sQ0FBRTtJQUFBaUgsUUFBQSxFQUVuQ2pILE9BQU8sZ0JBQUcsSUFBQXZCLFdBQUEsQ0FBQStHLEdBQUEsRUFBQy9ILFlBQUEsQ0FBQTZKLEdBQUc7TUFBQzVCLElBQUksRUFBRSxFQUFHO01BQUMsZUFBWTtJQUFNLENBQUUsQ0FBQyxnQkFBRyxJQUFBakgsV0FBQSxDQUFBK0csR0FBQSxFQUFDL0gsWUFBQSxDQUFBOEosTUFBTTtNQUFDN0IsSUFBSSxFQUFFLEVBQUc7TUFBQyxlQUFZO0lBQU0sQ0FBRTtFQUFDLENBQ25GLENBQUMsR0FDUCxJQUFJOztFQUVWO0VBQ0E7RUFDQTtFQUNBLE1BQU04QixjQUFjLGdCQUNsQixJQUFBL0ksV0FBQSxDQUFBK0csR0FBQTtJQUNFcUIsSUFBSSxFQUFDLFFBQVE7SUFDYkMsU0FBUyxFQUFDLGVBQWU7SUFDekJFLEtBQUssRUFBQyxtQkFBYztJQUNwQixjQUFXLG1CQUFjO0lBQ3pCRCxPQUFPLEVBQUU3RCxRQUFTO0lBQUErRCxRQUFBLGVBRWxCLElBQUF4SSxXQUFBLENBQUErRyxHQUFBLEVBQUMvSCxZQUFBLENBQUFnSyxJQUFJO01BQUMvQixJQUFJLEVBQUUsRUFBRztNQUFDLGVBQVk7SUFBTSxDQUFFO0VBQUMsQ0FDL0IsQ0FDVDs7RUFFRDtFQUNBO0VBQ0EsTUFBTWdDLGFBQWEsZ0JBQ2pCLElBQUFqSixXQUFBLENBQUFtSSxJQUFBLEVBQUFuSSxXQUFBLENBQUFrSixRQUFBO0lBQUFWLFFBQUEsR0FDR3JGLGdCQUFnQixpQkFBSSxJQUFBbkQsV0FBQSxDQUFBK0csR0FBQSxFQUFDMUgsYUFBQSxDQUFBZ0IsT0FBWTtNQUFDOEksS0FBSyxFQUFFeEYsYUFBYztNQUFDeUYsUUFBUSxFQUFFMUY7SUFBUSxDQUFFLENBQUMsRUFDN0VxRixjQUFjLEVBQ2RILGFBQWE7RUFBQSxDQUNkLENBQ0g7RUFDRDtFQUNBO0VBQ0E7RUFDQSxNQUFNUyxVQUFVLEdBQUdwQixlQUFlO0VBRWxDLG9CQUNFLElBQUFqSSxXQUFBLENBQUFtSSxJQUFBLEVBQUFuSSxXQUFBLENBQUFrSixRQUFBO0lBQUFWLFFBQUEsZ0JBQ0UsSUFBQXhJLFdBQUEsQ0FBQStHLEdBQUEsRUFBQzVILGlCQUFBLENBQUFrQixPQUFnQjtNQUNmcUIsS0FBSyxFQUFFa0MsVUFBVztNQUNsQmUsRUFBRSxFQUFFQyxXQUFZO01BQ2hCdEUsT0FBTyxFQUFFQSxPQUFRO01BQ2pCZ0osVUFBVSxFQUFFdEgsVUFBVztNQUN2QnVILFVBQVUsRUFBRXRILFVBQVc7TUFDdkJpRSxjQUFjLEVBQUVBLGNBQWU7TUFDL0I3RCxNQUFNLEVBQUVBLE1BQU87TUFDZm1ILE1BQU0sRUFBRTtRQUFFbEosT0FBTyxFQUFFMkksYUFBYTtRQUFFUSxJQUFJLEVBQUVKO01BQVcsQ0FBRTtNQUNyREssVUFBVSxlQUNSLElBQUExSixXQUFBLENBQUFtSSxJQUFBO1FBQUtFLFNBQVMsRUFBQyxPQUFPO1FBQUFHLFFBQUEsZ0JBQ3BCLElBQUF4SSxXQUFBLENBQUErRyxHQUFBO1VBQU1zQixTQUFTLEVBQUMsYUFBYTtVQUFBRyxRQUFBLGVBQzNCLElBQUF4SSxXQUFBLENBQUErRyxHQUFBLEVBQUMvSCxZQUFBLENBQUF5SixVQUFVO1lBQUN4QixJQUFJLEVBQUUsRUFBRztZQUFDLGVBQVk7VUFBTSxDQUFFO1FBQUMsQ0FDdkMsQ0FBQyxlQUNQLElBQUFqSCxXQUFBLENBQUErRyxHQUFBO1VBQUF5QixRQUFBLEVBQUk7UUFBcUIsQ0FBSSxDQUFDLGVBRTlCLElBQUF4SSxXQUFBLENBQUErRyxHQUFBO1VBQUF5QixRQUFBLEVBQUc7UUFHSCxDQUFHLENBQUMsZUFDSixJQUFBeEksV0FBQSxDQUFBbUksSUFBQTtVQUFRQyxJQUFJLEVBQUMsUUFBUTtVQUFDQyxTQUFTLEVBQUMsZUFBZTtVQUFDQyxPQUFPLEVBQUU3RCxRQUFTO1VBQUErRCxRQUFBLGdCQUNoRSxJQUFBeEksV0FBQSxDQUFBK0csR0FBQSxFQUFDL0gsWUFBQSxDQUFBZ0ssSUFBSTtZQUFDL0IsSUFBSSxFQUFFLEVBQUc7WUFBQyxlQUFZO1VBQU0sQ0FBRSxDQUFDLHFCQUV2QztRQUFBLENBQVEsQ0FBQztNQUFBLENBQ047SUFDTixDQUNGLENBQUMsRUFDRC9FLE9BQU8saUJBQUksSUFBQWxDLFdBQUEsQ0FBQStHLEdBQUEsRUFBQ2hILGFBQUEsQ0FBQU0sT0FBWTtNQUFDc0osTUFBTSxFQUFFekgsT0FBUTtNQUFDMEgsT0FBTyxFQUFFQSxDQUFBLEtBQU16SCxVQUFVLENBQUMsSUFBSTtJQUFFLENBQUUsQ0FBQztFQUFBLENBQzlFLENBQUM7QUFFUDtBQUFDbEMsRUFBQSxDQXJTUXFCLGVBQWU7RUFBQSxRQUlRRyw0Q0FBcUIsRUFDckNFLHdCQUFXLEVBQ1ZFLGNBQVMsRUFDRkUscUJBQWdCLEVBbURsQ3VCLGdDQUFlLEVBTUNFLGNBQVMsRUFtQzhDeUIsMEJBQVk7QUFBQTtBQUFBNEUsRUFBQSxHQW5HaEZ2SSxlQUFlO0FBQUEsSUFBQXdJLFFBQUEsR0FBQUMsT0FBQSxDQUFBMUosT0FBQSxHQXVTVGlCLGVBQWU7QUFBQSxJQUFBdUksRUFBQTtBQUFBRyxZQUFBLENBQUFILEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}