"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "DECLARED_LAUNCHES", {
  enumerable: true,
  get: function () {
    return _openWith.DECLARED_LAUNCHES;
  }
});
Object.defineProperty(exports, "DECLARED_TASKS", {
  enumerable: true,
  get: function () {
    return _openWith.DECLARED_TASKS;
  }
});
Object.defineProperty(exports, "MAX_MARKER_BYTES", {
  enumerable: true,
  get: function () {
    return _openWith.MAX_MARKER_BYTES;
  }
});
Object.defineProperty(exports, "MAX_PROBES_PER_LISTING", {
  enumerable: true,
  get: function () {
    return _useOpensWith.MAX_PROBES_PER_LISTING;
  }
});
Object.defineProperty(exports, "SdkFileExplorer", {
  enumerable: true,
  get: function () {
    return _SdkFileExplorer.default;
  }
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function () {
    return _SdkFileExplorer.default;
  }
});
Object.defineProperty(exports, "fsAvailable", {
  enumerable: true,
  get: function () {
    return _mountFs.fsAvailable;
  }
});
Object.defineProperty(exports, "makeSdkActions", {
  enumerable: true,
  get: function () {
    return _actions.makeSdkActions;
  }
});
Object.defineProperty(exports, "openInPlace", {
  enumerable: true,
  get: function () {
    return _openWith.openInPlace;
  }
});
Object.defineProperty(exports, "openWith", {
  enumerable: true,
  get: function () {
    return _openWith.openWith;
  }
});
Object.defineProperty(exports, "probeOffer", {
  enumerable: true,
  get: function () {
    return _openWith.probeOffer;
  }
});
Object.defineProperty(exports, "readFile", {
  enumerable: true,
  get: function () {
    return _mountFs.readFile;
  }
});
Object.defineProperty(exports, "readMarker", {
  enumerable: true,
  get: function () {
    return _openWith.readMarker;
  }
});
Object.defineProperty(exports, "readdir", {
  enumerable: true,
  get: function () {
    return _mountFs.readdir;
  }
});
Object.defineProperty(exports, "sdkFsSource", {
  enumerable: true,
  get: function () {
    return _mountFs.sdkFsSource;
  }
});
Object.defineProperty(exports, "toExplorerRoot", {
  enumerable: true,
  get: function () {
    return _mounts.toExplorerRoot;
  }
});
Object.defineProperty(exports, "useOpensWith", {
  enumerable: true,
  get: function () {
    return _useOpensWith.useOpensWith;
  }
});
Object.defineProperty(exports, "useSdkRoots", {
  enumerable: true,
  get: function () {
    return _useSdkRoots.useSdkRoots;
  }
});
Object.defineProperty(exports, "useSessionRoots", {
  enumerable: true,
  get: function () {
    return _useSessionRoots.useSessionRoots;
  }
});
var _SdkFileExplorer = _interopRequireDefault(require("./SdkFileExplorer"));
var _useSdkRoots = require("./useSdkRoots");
var _useSessionRoots = require("./useSessionRoots");
var _mountFs = require("./mountFs");
var _actions = require("./actions");
var _mounts = require("./mounts");
var _openWith = require("./openWith");
var _useOpensWith = require("./useOpensWith");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfU2RrRmlsZUV4cGxvcmVyIiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsInJlcXVpcmUiLCJfdXNlU2RrUm9vdHMiLCJfdXNlU2Vzc2lvblJvb3RzIiwiX21vdW50RnMiLCJfYWN0aW9ucyIsIl9tb3VudHMiLCJfb3BlbldpdGgiLCJfdXNlT3BlbnNXaXRoIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0Il0sInNvdXJjZXMiOlsiaW5kZXgudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gUHVibGljIHN1cmZhY2Ugb2YgdGhlIFNESyBhZGFwdGVyIChgQGltbWVkaWF0ZWx5LXJ1bi9maWxlLWV4cGxvcmVyLXVpL3Nka2ApLlxuLy8gV2lyZXMgdGhlIGhlYWRsZXNzIHZpZXcgdG8gYEBpbW1lZGlhdGVseS1ydW4vc2RrYDogcm9vdHMgZnJvbSBgdXNlTW91bnRzYCwgdGhlXG4vLyBaZW5GUyBgRnNTb3VyY2VgLCB0aGUgYWN0aW9uIGJ1bmRsZSwgYW5kIHRoZSBmdWxseS1hc3NlbWJsZWQgYXBwLlxuZXhwb3J0IHsgZGVmYXVsdCB9IGZyb20gXCIuL1Nka0ZpbGVFeHBsb3JlclwiOyAvLyBTZGtGaWxlRXhwbG9yZXIg4oCUIHRoZSB3aG9sZSBhcHBcbmV4cG9ydCB7IGRlZmF1bHQgYXMgU2RrRmlsZUV4cGxvcmVyIH0gZnJvbSBcIi4vU2RrRmlsZUV4cGxvcmVyXCI7XG5leHBvcnQgeyB1c2VTZGtSb290cyB9IGZyb20gXCIuL3VzZVNka1Jvb3RzXCI7XG5leHBvcnQgeyB1c2VTZXNzaW9uUm9vdHMsIHR5cGUgU2Vzc2lvblJvb3QsIHR5cGUgU2Vzc2lvblJvb3RzUmVzdWx0IH0gZnJvbSBcIi4vdXNlU2Vzc2lvblJvb3RzXCI7XG5leHBvcnQgeyBzZGtGc1NvdXJjZSwgcmVhZGRpciwgcmVhZEZpbGUsIGZzQXZhaWxhYmxlIH0gZnJvbSBcIi4vbW91bnRGc1wiO1xuZXhwb3J0IHsgbWFrZVNka0FjdGlvbnMgfSBmcm9tIFwiLi9hY3Rpb25zXCI7XG5leHBvcnQgeyB0b0V4cGxvcmVyUm9vdCB9IGZyb20gXCIuL21vdW50c1wiO1xuLy8gUjMtMjY3OiB0aGUgYG9wZW5zV2l0aGAgY2FsbGVyIOKAlCB0aGUgbWFya2VyIHByb2JlLCB0aGUgaW52b2tlLCBhbmQgdGhlIGhvb2sgdGhhdFxuLy8gd2lyZXMgYm90aCBpbnRvIGFuIGV4cGxvcmVyJ3MgZnMuIFIzLTE1OSBhZGRzIHRoZSBpbnRvLXN0YWdlIHR3aW4gKHRoZSBsYXVuY2hcbi8vIGFjdG9yICsgaXRzIGRlY2xhcmVkLWNvbnRyYWN0IGxpc3QpLCBzbyBhIGNvbnN1bWVyIG9mZmVyZWQgYGluUGxhY2VGb3JgIGNhbiBhY3Qgb24gaXQuXG5leHBvcnQgeyBERUNMQVJFRF9UQVNLUywgREVDTEFSRURfTEFVTkNIRVMsIE1BWF9NQVJLRVJfQllURVMsIG9wZW5JblBsYWNlLCBvcGVuV2l0aCwgcHJvYmVPZmZlciwgcmVhZE1hcmtlciB9IGZyb20gXCIuL29wZW5XaXRoXCI7XG5leHBvcnQgdHlwZSB7IE9wZW5XaXRoT3V0Y29tZSB9IGZyb20gXCIuL29wZW5XaXRoXCI7XG5leHBvcnQgeyB1c2VPcGVuc1dpdGgsIE1BWF9QUk9CRVNfUEVSX0xJU1RJTkcgfSBmcm9tIFwiLi91c2VPcGVuc1dpdGhcIjtcbmV4cG9ydCB0eXBlIHsgT3BlbnNXaXRoU3RhdGUgfSBmcm9tIFwiLi91c2VPcGVuc1dpdGhcIjtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFHQSxJQUFBQSxnQkFBQSxHQUFBQyxzQkFBQSxDQUFBQyxPQUFBO0FBRUEsSUFBQUMsWUFBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsZ0JBQUEsR0FBQUYsT0FBQTtBQUNBLElBQUFHLFFBQUEsR0FBQUgsT0FBQTtBQUNBLElBQUFJLFFBQUEsR0FBQUosT0FBQTtBQUNBLElBQUFLLE9BQUEsR0FBQUwsT0FBQTtBQUlBLElBQUFNLFNBQUEsR0FBQU4sT0FBQTtBQUVBLElBQUFPLGFBQUEsR0FBQVAsT0FBQTtBQUFzRSxTQUFBRCx1QkFBQVMsQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQSIsImlnbm9yZUxpc3QiOltdfQ==