"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.MAX_MARKER_BYTES = exports.DECLARED_TASKS = exports.DECLARED_LAUNCHES = void 0;
exports.openInPlace = openInPlace;
exports.openWith = openWith;
exports.probeOffer = probeOffer;
exports.readMarker = readMarker;
var _sdk = require("@immediately-run/sdk");
var _opensWith = require("../opensWith");
var _explorer = require("../explorer");
// R3-267 — the SDK half of the `opensWith` caller: what this app may offer, how it
// finds a folder's marker, and how it invokes the contract that marker names.
//
// The DECISION is in `../opensWith` (pure, host-free). This file is the wiring: the
// declared contract list, the probe that reads a directory's marker, and the invoke.

/**
 * The task contracts this app declares it invokes.
 *
 * **This list MUST mirror `immediately.run.invokes` in package.json**, and
 * `openWith.test.ts` fails if it drifts — the host enforces that declaration at invoke
 * time (§5.8 least authority), so a contract missing from the manifest would be offered
 * and then refused, and one missing from here would be silently unofferable.
 *
 * It is DATA, deliberately: the only contract the feature's code names is the app-form
 * door (`APP_FORM_CONTRACT`, `open-declared`), which is protocol, not a marker's choice.
 * Supporting a new contract is this line plus the manifest, and the marker's own `kind`
 * supplies the label.
 */
const DECLARED_TASKS = exports.DECLARED_TASKS = ["open-wiki", "open-project", "open-workbook", "open-declared"];

/**
 * The task contracts this app declares it LAUNCHES to-run into the stage (R3-159).
 *
 * **This list MUST mirror `immediately.run.launches` in package.json**, and the same
 * drift test pins it — the host refuses an undeclared launch target (R-SAL-3), so a
 * contract missing from the manifest would be offered and then refused.
 */
const DECLARED_LAUNCHES = exports.DECLARED_LAUNCHES = ["open-project"];

/** Read a directory's marker text, or null when it carries none / is unreadable. */
async function readMarker(fs, dirAbsPath) {
  if (!fs.readFile) return null;
  try {
    const bytes = await fs.readFile((0, _explorer.joinPath)(dirAbsPath, _opensWith.CONTENT_MARKER_FILE));
    // A marker is a small JSON file. Anything huge is not one, and decoding it would
    // be work done on behalf of whoever wrote the folder.
    if (bytes.byteLength > MAX_MARKER_BYTES) return null;
    return new TextDecoder().decode(bytes);
  } catch {
    // ENOENT is the overwhelmingly common answer — most folders are just folders.
    return null;
  }
}

/** A marker is a handful of keys; 64 KiB is already absurd for one. */
const MAX_MARKER_BYTES = exports.MAX_MARKER_BYTES = 64 * 1024;

/** Probe one directory: its offer under `policy`, or null for no affordance. */
async function probeOffer(fs, dirAbsPath, policy) {
  return (0, _opensWith.opensWithOffer)(await readMarker(fs, dirAbsPath), policy);
}

/** What an invoke did, so the caller can withdraw a structurally dead contract. */

/**
 * Invoke the contract a folder's marker names, delegating THAT folder and nothing else.
 *
 * The delegation is a `capDir` at the folder, at the mount's own granted mode — dispatch
 * changes the packaging, not the authority, so a viewer opened on an `rw` mount can edit
 * what it renders and one opened on `ro` cannot (R3-266). The host resolves the cap
 * against this app's OWN grants and mints an attenuated chroot, so this can only ever
 * hand over a directory the explorer already holds.
 *
 * Never throws and never surfaces a protocol code: `cancelled` is the ordinary way a
 * viewer closes, and a contract-level refusal comes back as `withdraw` so the affordance
 * removes itself rather than offering a second dead click.
 */
async function openWith(root, dirAbsPath, offer) {
  const relPath = (0, _explorer.toMountRel)(root.path, dirAbsPath);
  try {
    await (0, _sdk.invokeTask)(offer.task, {
      dir: (0, _sdk.capDir)({
        mountId: root.id,
        relPath
      }, {
        mode: (0, _explorer.grantedModeAt)(root, relPath)
      }),
      // R3-789: a declared view is selected by NAME; the host resolves its app.
      ...(offer.view !== undefined ? {
        view: offer.view
      } : {})
    });
    return {
      status: "opened"
    };
  } catch (e) {
    const code = e?.code;
    return (0, _opensWith.withdrawsOffer)(code) ? {
      status: "withdraw",
      task: offer.task
    } : {
      status: "declined"
    };
  }
}

/**
 * "Open in place" (R3-159) — LAUNCH the contract a folder's marker names TO-RUN in
 * the STAGE region (STANDING_APP_LIFECYCLE §7 into-stage), replacing the focal app,
 * via `launch` rather than the for-result `invokeTask`. This panel runs under an
 * `editor.*` principal, so the host admits `region: 'stage'` (R-SAL-5: a
 * stage-principal caller is refused `forbidden` — and so is a URL-loaded fork,
 * whose click simply declines).
 *
 * Unlike {@link openWith} the delegated `capDir` is ALWAYS `ro` (R-SAL-6): the
 * launched app RUNS on the folder, it does not edit it, and the rw-into-stage host
 * confirm (scope+mode) is a follow-on — the `ro` default ships.
 *
 * Same outcome shape as `openWith`, but a refusal NEVER withdraws: the launch
 * vocabulary (SDK §8 `LaunchErrorCode`) has no code that is a safe
 * session-permanent verdict — `unsupported`, the nearest thing to "nothing is
 * bound to this contract", is also resolved for transient host states (the launch
 * host not yet mounted, an absent launch context, a create failing before bind),
 * so withdrawing on it would strand the affordance for the rest of the session
 * over a state that clears. Every refusal — fork `forbidden`, `budget`, a user
 * dismiss, a transient `unsupported` — declines and leaves the affordance
 * standing; the decline is invisible (fire-and-forget, no error surface).
 */
async function openInPlace(root, dirAbsPath, offer) {
  const relPath = (0, _explorer.toMountRel)(root.path, dirAbsPath);
  try {
    // `launch` resolves `{ ok:false, code }` for an ordinary refusal instead of
    // throwing; off-host (plain `vite dev`) it REJECTS ("no host transport") —
    // ordinary too, so the catch below is the same shape as openWith's.
    const res = await (0, _sdk.launch)({
      task: offer.task
    }, {
      region: "stage",
      input: {
        dir: (0, _sdk.capDir)({
          mountId: root.id,
          relPath
        }, {
          mode: "ro"
        })
      }
    });
    if ("ok" in res && res.ok === false) return {
      status: "declined"
    };
    return {
      status: "opened"
    };
  } catch {
    return {
      status: "declined"
    };
  }
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfc2RrIiwicmVxdWlyZSIsIl9vcGVuc1dpdGgiLCJfZXhwbG9yZXIiLCJERUNMQVJFRF9UQVNLUyIsImV4cG9ydHMiLCJERUNMQVJFRF9MQVVOQ0hFUyIsInJlYWRNYXJrZXIiLCJmcyIsImRpckFic1BhdGgiLCJyZWFkRmlsZSIsImJ5dGVzIiwiam9pblBhdGgiLCJDT05URU5UX01BUktFUl9GSUxFIiwiYnl0ZUxlbmd0aCIsIk1BWF9NQVJLRVJfQllURVMiLCJUZXh0RGVjb2RlciIsImRlY29kZSIsInByb2JlT2ZmZXIiLCJwb2xpY3kiLCJvcGVuc1dpdGhPZmZlciIsIm9wZW5XaXRoIiwicm9vdCIsIm9mZmVyIiwicmVsUGF0aCIsInRvTW91bnRSZWwiLCJwYXRoIiwiaW52b2tlVGFzayIsInRhc2siLCJkaXIiLCJjYXBEaXIiLCJtb3VudElkIiwiaWQiLCJtb2RlIiwiZ3JhbnRlZE1vZGVBdCIsInZpZXciLCJ1bmRlZmluZWQiLCJzdGF0dXMiLCJlIiwiY29kZSIsIndpdGhkcmF3c09mZmVyIiwib3BlbkluUGxhY2UiLCJyZXMiLCJsYXVuY2giLCJyZWdpb24iLCJpbnB1dCIsIm9rIl0sInNvdXJjZXMiOlsib3BlbldpdGgudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gUjMtMjY3IOKAlCB0aGUgU0RLIGhhbGYgb2YgdGhlIGBvcGVuc1dpdGhgIGNhbGxlcjogd2hhdCB0aGlzIGFwcCBtYXkgb2ZmZXIsIGhvdyBpdFxuLy8gZmluZHMgYSBmb2xkZXIncyBtYXJrZXIsIGFuZCBob3cgaXQgaW52b2tlcyB0aGUgY29udHJhY3QgdGhhdCBtYXJrZXIgbmFtZXMuXG4vL1xuLy8gVGhlIERFQ0lTSU9OIGlzIGluIGAuLi9vcGVuc1dpdGhgIChwdXJlLCBob3N0LWZyZWUpLiBUaGlzIGZpbGUgaXMgdGhlIHdpcmluZzogdGhlXG4vLyBkZWNsYXJlZCBjb250cmFjdCBsaXN0LCB0aGUgcHJvYmUgdGhhdCByZWFkcyBhIGRpcmVjdG9yeSdzIG1hcmtlciwgYW5kIHRoZSBpbnZva2UuXG5pbXBvcnQgeyBpbnZva2VUYXNrLCBjYXBEaXIsIGxhdW5jaCB9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nka1wiO1xuaW1wb3J0IHsgQ09OVEVOVF9NQVJLRVJfRklMRSwgb3BlbnNXaXRoT2ZmZXIsIHdpdGhkcmF3c09mZmVyIH0gZnJvbSBcIi4uL29wZW5zV2l0aFwiO1xuaW1wb3J0IHR5cGUgeyBPcGVuc1dpdGhPZmZlciB9IGZyb20gXCIuLi9vcGVuc1dpdGhcIjtcbmltcG9ydCB7IGdyYW50ZWRNb2RlQXQsIGpvaW5QYXRoLCB0b01vdW50UmVsIH0gZnJvbSBcIi4uL2V4cGxvcmVyXCI7XG5pbXBvcnQgdHlwZSB7IEV4cGxvcmVyUm9vdCwgRnNTb3VyY2UgfSBmcm9tIFwiLi4vdHlwZXNcIjtcblxuLyoqXG4gKiBUaGUgdGFzayBjb250cmFjdHMgdGhpcyBhcHAgZGVjbGFyZXMgaXQgaW52b2tlcy5cbiAqXG4gKiAqKlRoaXMgbGlzdCBNVVNUIG1pcnJvciBgaW1tZWRpYXRlbHkucnVuLmludm9rZXNgIGluIHBhY2thZ2UuanNvbioqLCBhbmRcbiAqIGBvcGVuV2l0aC50ZXN0LnRzYCBmYWlscyBpZiBpdCBkcmlmdHMg4oCUIHRoZSBob3N0IGVuZm9yY2VzIHRoYXQgZGVjbGFyYXRpb24gYXQgaW52b2tlXG4gKiB0aW1lICjCpzUuOCBsZWFzdCBhdXRob3JpdHkpLCBzbyBhIGNvbnRyYWN0IG1pc3NpbmcgZnJvbSB0aGUgbWFuaWZlc3Qgd291bGQgYmUgb2ZmZXJlZFxuICogYW5kIHRoZW4gcmVmdXNlZCwgYW5kIG9uZSBtaXNzaW5nIGZyb20gaGVyZSB3b3VsZCBiZSBzaWxlbnRseSB1bm9mZmVyYWJsZS5cbiAqXG4gKiBJdCBpcyBEQVRBLCBkZWxpYmVyYXRlbHk6IHRoZSBvbmx5IGNvbnRyYWN0IHRoZSBmZWF0dXJlJ3MgY29kZSBuYW1lcyBpcyB0aGUgYXBwLWZvcm1cbiAqIGRvb3IgKGBBUFBfRk9STV9DT05UUkFDVGAsIGBvcGVuLWRlY2xhcmVkYCksIHdoaWNoIGlzIHByb3RvY29sLCBub3QgYSBtYXJrZXIncyBjaG9pY2UuXG4gKiBTdXBwb3J0aW5nIGEgbmV3IGNvbnRyYWN0IGlzIHRoaXMgbGluZSBwbHVzIHRoZSBtYW5pZmVzdCwgYW5kIHRoZSBtYXJrZXIncyBvd24gYGtpbmRgXG4gKiBzdXBwbGllcyB0aGUgbGFiZWwuXG4gKi9cbmV4cG9ydCBjb25zdCBERUNMQVJFRF9UQVNLUyA9IFtcIm9wZW4td2lraVwiLCBcIm9wZW4tcHJvamVjdFwiLCBcIm9wZW4td29ya2Jvb2tcIiwgXCJvcGVuLWRlY2xhcmVkXCJdIGFzIGNvbnN0O1xuXG4vKipcbiAqIFRoZSB0YXNrIGNvbnRyYWN0cyB0aGlzIGFwcCBkZWNsYXJlcyBpdCBMQVVOQ0hFUyB0by1ydW4gaW50byB0aGUgc3RhZ2UgKFIzLTE1OSkuXG4gKlxuICogKipUaGlzIGxpc3QgTVVTVCBtaXJyb3IgYGltbWVkaWF0ZWx5LnJ1bi5sYXVuY2hlc2AgaW4gcGFja2FnZS5qc29uKiosIGFuZCB0aGUgc2FtZVxuICogZHJpZnQgdGVzdCBwaW5zIGl0IOKAlCB0aGUgaG9zdCByZWZ1c2VzIGFuIHVuZGVjbGFyZWQgbGF1bmNoIHRhcmdldCAoUi1TQUwtMyksIHNvIGFcbiAqIGNvbnRyYWN0IG1pc3NpbmcgZnJvbSB0aGUgbWFuaWZlc3Qgd291bGQgYmUgb2ZmZXJlZCBhbmQgdGhlbiByZWZ1c2VkLlxuICovXG5leHBvcnQgY29uc3QgREVDTEFSRURfTEFVTkNIRVMgPSBbXCJvcGVuLXByb2plY3RcIl0gYXMgY29uc3Q7XG5cbi8qKiBSZWFkIGEgZGlyZWN0b3J5J3MgbWFya2VyIHRleHQsIG9yIG51bGwgd2hlbiBpdCBjYXJyaWVzIG5vbmUgLyBpcyB1bnJlYWRhYmxlLiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJlYWRNYXJrZXIoZnM6IEZzU291cmNlLCBkaXJBYnNQYXRoOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZyB8IG51bGw+IHtcbiAgaWYgKCFmcy5yZWFkRmlsZSkgcmV0dXJuIG51bGw7XG4gIHRyeSB7XG4gICAgY29uc3QgYnl0ZXMgPSBhd2FpdCBmcy5yZWFkRmlsZShqb2luUGF0aChkaXJBYnNQYXRoLCBDT05URU5UX01BUktFUl9GSUxFKSk7XG4gICAgLy8gQSBtYXJrZXIgaXMgYSBzbWFsbCBKU09OIGZpbGUuIEFueXRoaW5nIGh1Z2UgaXMgbm90IG9uZSwgYW5kIGRlY29kaW5nIGl0IHdvdWxkXG4gICAgLy8gYmUgd29yayBkb25lIG9uIGJlaGFsZiBvZiB3aG9ldmVyIHdyb3RlIHRoZSBmb2xkZXIuXG4gICAgaWYgKGJ5dGVzLmJ5dGVMZW5ndGggPiBNQVhfTUFSS0VSX0JZVEVTKSByZXR1cm4gbnVsbDtcbiAgICByZXR1cm4gbmV3IFRleHREZWNvZGVyKCkuZGVjb2RlKGJ5dGVzKTtcbiAgfSBjYXRjaCB7XG4gICAgLy8gRU5PRU5UIGlzIHRoZSBvdmVyd2hlbG1pbmdseSBjb21tb24gYW5zd2VyIOKAlCBtb3N0IGZvbGRlcnMgYXJlIGp1c3QgZm9sZGVycy5cbiAgICByZXR1cm4gbnVsbDtcbiAgfVxufVxuXG4vKiogQSBtYXJrZXIgaXMgYSBoYW5kZnVsIG9mIGtleXM7IDY0IEtpQiBpcyBhbHJlYWR5IGFic3VyZCBmb3Igb25lLiAqL1xuZXhwb3J0IGNvbnN0IE1BWF9NQVJLRVJfQllURVMgPSA2NCAqIDEwMjQ7XG5cbi8qKiBQcm9iZSBvbmUgZGlyZWN0b3J5OiBpdHMgb2ZmZXIgdW5kZXIgYHBvbGljeWAsIG9yIG51bGwgZm9yIG5vIGFmZm9yZGFuY2UuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcHJvYmVPZmZlcihcbiAgZnM6IEZzU291cmNlLFxuICBkaXJBYnNQYXRoOiBzdHJpbmcsXG4gIHBvbGljeTogeyBvZmZlcmFibGU6IHJlYWRvbmx5IHN0cmluZ1tdOyB1bmF2YWlsYWJsZT86IFJlYWRvbmx5U2V0PHN0cmluZz4gfSxcbik6IFByb21pc2U8T3BlbnNXaXRoT2ZmZXIgfCBudWxsPiB7XG4gIHJldHVybiBvcGVuc1dpdGhPZmZlcihhd2FpdCByZWFkTWFya2VyKGZzLCBkaXJBYnNQYXRoKSwgcG9saWN5KTtcbn1cblxuLyoqIFdoYXQgYW4gaW52b2tlIGRpZCwgc28gdGhlIGNhbGxlciBjYW4gd2l0aGRyYXcgYSBzdHJ1Y3R1cmFsbHkgZGVhZCBjb250cmFjdC4gKi9cbmV4cG9ydCB0eXBlIE9wZW5XaXRoT3V0Y29tZSA9XG4gIHwgeyBzdGF0dXM6IFwib3BlbmVkXCIgfVxuICAvKiogVGhlIHVzZXIgY2xvc2VkIHRoZSB2aWV3ZXIsIG9yIHRoZSBhdHRlbXB0IGZhaWxlZCBvbmNlIOKAlCBrZWVwIG9mZmVyaW5nLiAqL1xuICB8IHsgc3RhdHVzOiBcImRlY2xpbmVkXCIgfVxuICAvKiogTm90aGluZyBpcyBib3VuZCB0byB0aGlzIGNvbnRyYWN0IChvciB3ZSBtYXkgbm90IGNhbGwgaXQpIOKAlCBzdG9wIG9mZmVyaW5nIGl0LiAqL1xuICB8IHsgc3RhdHVzOiBcIndpdGhkcmF3XCI7IHRhc2s6IHN0cmluZyB9O1xuXG4vKipcbiAqIEludm9rZSB0aGUgY29udHJhY3QgYSBmb2xkZXIncyBtYXJrZXIgbmFtZXMsIGRlbGVnYXRpbmcgVEhBVCBmb2xkZXIgYW5kIG5vdGhpbmcgZWxzZS5cbiAqXG4gKiBUaGUgZGVsZWdhdGlvbiBpcyBhIGBjYXBEaXJgIGF0IHRoZSBmb2xkZXIsIGF0IHRoZSBtb3VudCdzIG93biBncmFudGVkIG1vZGUg4oCUIGRpc3BhdGNoXG4gKiBjaGFuZ2VzIHRoZSBwYWNrYWdpbmcsIG5vdCB0aGUgYXV0aG9yaXR5LCBzbyBhIHZpZXdlciBvcGVuZWQgb24gYW4gYHJ3YCBtb3VudCBjYW4gZWRpdFxuICogd2hhdCBpdCByZW5kZXJzIGFuZCBvbmUgb3BlbmVkIG9uIGByb2AgY2Fubm90IChSMy0yNjYpLiBUaGUgaG9zdCByZXNvbHZlcyB0aGUgY2FwXG4gKiBhZ2FpbnN0IHRoaXMgYXBwJ3MgT1dOIGdyYW50cyBhbmQgbWludHMgYW4gYXR0ZW51YXRlZCBjaHJvb3QsIHNvIHRoaXMgY2FuIG9ubHkgZXZlclxuICogaGFuZCBvdmVyIGEgZGlyZWN0b3J5IHRoZSBleHBsb3JlciBhbHJlYWR5IGhvbGRzLlxuICpcbiAqIE5ldmVyIHRocm93cyBhbmQgbmV2ZXIgc3VyZmFjZXMgYSBwcm90b2NvbCBjb2RlOiBgY2FuY2VsbGVkYCBpcyB0aGUgb3JkaW5hcnkgd2F5IGFcbiAqIHZpZXdlciBjbG9zZXMsIGFuZCBhIGNvbnRyYWN0LWxldmVsIHJlZnVzYWwgY29tZXMgYmFjayBhcyBgd2l0aGRyYXdgIHNvIHRoZSBhZmZvcmRhbmNlXG4gKiByZW1vdmVzIGl0c2VsZiByYXRoZXIgdGhhbiBvZmZlcmluZyBhIHNlY29uZCBkZWFkIGNsaWNrLlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gb3BlbldpdGgoXG4gIHJvb3Q6IEV4cGxvcmVyUm9vdCxcbiAgZGlyQWJzUGF0aDogc3RyaW5nLFxuICBvZmZlcjogT3BlbnNXaXRoT2ZmZXIsXG4pOiBQcm9taXNlPE9wZW5XaXRoT3V0Y29tZT4ge1xuICBjb25zdCByZWxQYXRoID0gdG9Nb3VudFJlbChyb290LnBhdGgsIGRpckFic1BhdGgpO1xuICB0cnkge1xuICAgIGF3YWl0IGludm9rZVRhc2sob2ZmZXIudGFzaywge1xuICAgICAgZGlyOiBjYXBEaXIoeyBtb3VudElkOiByb290LmlkLCByZWxQYXRoIH0sIHsgbW9kZTogZ3JhbnRlZE1vZGVBdChyb290LCByZWxQYXRoKSB9KSxcbiAgICAgIC8vIFIzLTc4OTogYSBkZWNsYXJlZCB2aWV3IGlzIHNlbGVjdGVkIGJ5IE5BTUU7IHRoZSBob3N0IHJlc29sdmVzIGl0cyBhcHAuXG4gICAgICAuLi4ob2ZmZXIudmlldyAhPT0gdW5kZWZpbmVkID8geyB2aWV3OiBvZmZlci52aWV3IH0gOiB7fSksXG4gICAgfSk7XG4gICAgcmV0dXJuIHsgc3RhdHVzOiBcIm9wZW5lZFwiIH07XG4gIH0gY2F0Y2ggKGUpIHtcbiAgICBjb25zdCBjb2RlID0gKGUgYXMgeyBjb2RlPzogc3RyaW5nIH0gfCBudWxsKT8uY29kZTtcbiAgICByZXR1cm4gd2l0aGRyYXdzT2ZmZXIoY29kZSkgPyB7IHN0YXR1czogXCJ3aXRoZHJhd1wiLCB0YXNrOiBvZmZlci50YXNrIH0gOiB7IHN0YXR1czogXCJkZWNsaW5lZFwiIH07XG4gIH1cbn1cblxuLyoqXG4gKiBcIk9wZW4gaW4gcGxhY2VcIiAoUjMtMTU5KSDigJQgTEFVTkNIIHRoZSBjb250cmFjdCBhIGZvbGRlcidzIG1hcmtlciBuYW1lcyBUTy1SVU4gaW5cbiAqIHRoZSBTVEFHRSByZWdpb24gKFNUQU5ESU5HX0FQUF9MSUZFQ1lDTEUgwqc3IGludG8tc3RhZ2UpLCByZXBsYWNpbmcgdGhlIGZvY2FsIGFwcCxcbiAqIHZpYSBgbGF1bmNoYCByYXRoZXIgdGhhbiB0aGUgZm9yLXJlc3VsdCBgaW52b2tlVGFza2AuIFRoaXMgcGFuZWwgcnVucyB1bmRlciBhblxuICogYGVkaXRvci4qYCBwcmluY2lwYWwsIHNvIHRoZSBob3N0IGFkbWl0cyBgcmVnaW9uOiAnc3RhZ2UnYCAoUi1TQUwtNTogYVxuICogc3RhZ2UtcHJpbmNpcGFsIGNhbGxlciBpcyByZWZ1c2VkIGBmb3JiaWRkZW5gIOKAlCBhbmQgc28gaXMgYSBVUkwtbG9hZGVkIGZvcmssXG4gKiB3aG9zZSBjbGljayBzaW1wbHkgZGVjbGluZXMpLlxuICpcbiAqIFVubGlrZSB7QGxpbmsgb3BlbldpdGh9IHRoZSBkZWxlZ2F0ZWQgYGNhcERpcmAgaXMgQUxXQVlTIGByb2AgKFItU0FMLTYpOiB0aGVcbiAqIGxhdW5jaGVkIGFwcCBSVU5TIG9uIHRoZSBmb2xkZXIsIGl0IGRvZXMgbm90IGVkaXQgaXQsIGFuZCB0aGUgcnctaW50by1zdGFnZSBob3N0XG4gKiBjb25maXJtIChzY29wZSttb2RlKSBpcyBhIGZvbGxvdy1vbiDigJQgdGhlIGByb2AgZGVmYXVsdCBzaGlwcy5cbiAqXG4gKiBTYW1lIG91dGNvbWUgc2hhcGUgYXMgYG9wZW5XaXRoYCwgYnV0IGEgcmVmdXNhbCBORVZFUiB3aXRoZHJhd3M6IHRoZSBsYXVuY2hcbiAqIHZvY2FidWxhcnkgKFNESyDCpzggYExhdW5jaEVycm9yQ29kZWApIGhhcyBubyBjb2RlIHRoYXQgaXMgYSBzYWZlXG4gKiBzZXNzaW9uLXBlcm1hbmVudCB2ZXJkaWN0IOKAlCBgdW5zdXBwb3J0ZWRgLCB0aGUgbmVhcmVzdCB0aGluZyB0byBcIm5vdGhpbmcgaXNcbiAqIGJvdW5kIHRvIHRoaXMgY29udHJhY3RcIiwgaXMgYWxzbyByZXNvbHZlZCBmb3IgdHJhbnNpZW50IGhvc3Qgc3RhdGVzICh0aGUgbGF1bmNoXG4gKiBob3N0IG5vdCB5ZXQgbW91bnRlZCwgYW4gYWJzZW50IGxhdW5jaCBjb250ZXh0LCBhIGNyZWF0ZSBmYWlsaW5nIGJlZm9yZSBiaW5kKSxcbiAqIHNvIHdpdGhkcmF3aW5nIG9uIGl0IHdvdWxkIHN0cmFuZCB0aGUgYWZmb3JkYW5jZSBmb3IgdGhlIHJlc3Qgb2YgdGhlIHNlc3Npb25cbiAqIG92ZXIgYSBzdGF0ZSB0aGF0IGNsZWFycy4gRXZlcnkgcmVmdXNhbCDigJQgZm9yayBgZm9yYmlkZGVuYCwgYGJ1ZGdldGAsIGEgdXNlclxuICogZGlzbWlzcywgYSB0cmFuc2llbnQgYHVuc3VwcG9ydGVkYCDigJQgZGVjbGluZXMgYW5kIGxlYXZlcyB0aGUgYWZmb3JkYW5jZVxuICogc3RhbmRpbmc7IHRoZSBkZWNsaW5lIGlzIGludmlzaWJsZSAoZmlyZS1hbmQtZm9yZ2V0LCBubyBlcnJvciBzdXJmYWNlKS5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG9wZW5JblBsYWNlKFxuICByb290OiBFeHBsb3JlclJvb3QsXG4gIGRpckFic1BhdGg6IHN0cmluZyxcbiAgb2ZmZXI6IE9wZW5zV2l0aE9mZmVyLFxuKTogUHJvbWlzZTxPcGVuV2l0aE91dGNvbWU+IHtcbiAgY29uc3QgcmVsUGF0aCA9IHRvTW91bnRSZWwocm9vdC5wYXRoLCBkaXJBYnNQYXRoKTtcbiAgdHJ5IHtcbiAgICAvLyBgbGF1bmNoYCByZXNvbHZlcyBgeyBvazpmYWxzZSwgY29kZSB9YCBmb3IgYW4gb3JkaW5hcnkgcmVmdXNhbCBpbnN0ZWFkIG9mXG4gICAgLy8gdGhyb3dpbmc7IG9mZi1ob3N0IChwbGFpbiBgdml0ZSBkZXZgKSBpdCBSRUpFQ1RTIChcIm5vIGhvc3QgdHJhbnNwb3J0XCIpIOKAlFxuICAgIC8vIG9yZGluYXJ5IHRvbywgc28gdGhlIGNhdGNoIGJlbG93IGlzIHRoZSBzYW1lIHNoYXBlIGFzIG9wZW5XaXRoJ3MuXG4gICAgY29uc3QgcmVzID0gYXdhaXQgbGF1bmNoKFxuICAgICAgeyB0YXNrOiBvZmZlci50YXNrIH0sXG4gICAgICB7XG4gICAgICAgIHJlZ2lvbjogXCJzdGFnZVwiLFxuICAgICAgICBpbnB1dDogeyBkaXI6IGNhcERpcih7IG1vdW50SWQ6IHJvb3QuaWQsIHJlbFBhdGggfSwgeyBtb2RlOiBcInJvXCIgfSkgfSxcbiAgICAgIH0sXG4gICAgKTtcbiAgICBpZiAoXCJva1wiIGluIHJlcyAmJiByZXMub2sgPT09IGZhbHNlKSByZXR1cm4geyBzdGF0dXM6IFwiZGVjbGluZWRcIiB9O1xuICAgIHJldHVybiB7IHN0YXR1czogXCJvcGVuZWRcIiB9O1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4geyBzdGF0dXM6IFwiZGVjbGluZWRcIiB9O1xuICB9XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFLQSxJQUFBQSxJQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxVQUFBLEdBQUFELE9BQUE7QUFFQSxJQUFBRSxTQUFBLEdBQUFGLE9BQUE7QUFSQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQU9BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sTUFBTUcsY0FBYyxHQUFBQyxPQUFBLENBQUFELGNBQUEsR0FBRyxDQUFDLFdBQVcsRUFBRSxjQUFjLEVBQUUsZUFBZSxFQUFFLGVBQWUsQ0FBVTs7QUFFdEc7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxNQUFNRSxpQkFBaUIsR0FBQUQsT0FBQSxDQUFBQyxpQkFBQSxHQUFHLENBQUMsY0FBYyxDQUFVOztBQUUxRDtBQUNPLGVBQWVDLFVBQVVBLENBQUNDLEVBQVksRUFBRUMsVUFBa0IsRUFBMEI7RUFDekYsSUFBSSxDQUFDRCxFQUFFLENBQUNFLFFBQVEsRUFBRSxPQUFPLElBQUk7RUFDN0IsSUFBSTtJQUNGLE1BQU1DLEtBQUssR0FBRyxNQUFNSCxFQUFFLENBQUNFLFFBQVEsQ0FBQyxJQUFBRSxrQkFBUSxFQUFDSCxVQUFVLEVBQUVJLDhCQUFtQixDQUFDLENBQUM7SUFDMUU7SUFDQTtJQUNBLElBQUlGLEtBQUssQ0FBQ0csVUFBVSxHQUFHQyxnQkFBZ0IsRUFBRSxPQUFPLElBQUk7SUFDcEQsT0FBTyxJQUFJQyxXQUFXLENBQUMsQ0FBQyxDQUFDQyxNQUFNLENBQUNOLEtBQUssQ0FBQztFQUN4QyxDQUFDLENBQUMsTUFBTTtJQUNOO0lBQ0EsT0FBTyxJQUFJO0VBQ2I7QUFDRjs7QUFFQTtBQUNPLE1BQU1JLGdCQUFnQixHQUFBVixPQUFBLENBQUFVLGdCQUFBLEdBQUcsRUFBRSxHQUFHLElBQUk7O0FBRXpDO0FBQ08sZUFBZUcsVUFBVUEsQ0FDOUJWLEVBQVksRUFDWkMsVUFBa0IsRUFDbEJVLE1BQTJFLEVBQzNDO0VBQ2hDLE9BQU8sSUFBQUMseUJBQWMsRUFBQyxNQUFNYixVQUFVLENBQUNDLEVBQUUsRUFBRUMsVUFBVSxDQUFDLEVBQUVVLE1BQU0sQ0FBQztBQUNqRTs7QUFFQTs7QUFRQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLGVBQWVFLFFBQVFBLENBQzVCQyxJQUFrQixFQUNsQmIsVUFBa0IsRUFDbEJjLEtBQXFCLEVBQ0s7RUFDMUIsTUFBTUMsT0FBTyxHQUFHLElBQUFDLG9CQUFVLEVBQUNILElBQUksQ0FBQ0ksSUFBSSxFQUFFakIsVUFBVSxDQUFDO0VBQ2pELElBQUk7SUFDRixNQUFNLElBQUFrQixlQUFVLEVBQUNKLEtBQUssQ0FBQ0ssSUFBSSxFQUFFO01BQzNCQyxHQUFHLEVBQUUsSUFBQUMsV0FBTSxFQUFDO1FBQUVDLE9BQU8sRUFBRVQsSUFBSSxDQUFDVSxFQUFFO1FBQUVSO01BQVEsQ0FBQyxFQUFFO1FBQUVTLElBQUksRUFBRSxJQUFBQyx1QkFBYSxFQUFDWixJQUFJLEVBQUVFLE9BQU87TUFBRSxDQUFDLENBQUM7TUFDbEY7TUFDQSxJQUFJRCxLQUFLLENBQUNZLElBQUksS0FBS0MsU0FBUyxHQUFHO1FBQUVELElBQUksRUFBRVosS0FBSyxDQUFDWTtNQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDMUQsQ0FBQyxDQUFDO0lBQ0YsT0FBTztNQUFFRSxNQUFNLEVBQUU7SUFBUyxDQUFDO0VBQzdCLENBQUMsQ0FBQyxPQUFPQyxDQUFDLEVBQUU7SUFDVixNQUFNQyxJQUFJLEdBQUlELENBQUMsRUFBK0JDLElBQUk7SUFDbEQsT0FBTyxJQUFBQyx5QkFBYyxFQUFDRCxJQUFJLENBQUMsR0FBRztNQUFFRixNQUFNLEVBQUUsVUFBVTtNQUFFVCxJQUFJLEVBQUVMLEtBQUssQ0FBQ0s7SUFBSyxDQUFDLEdBQUc7TUFBRVMsTUFBTSxFQUFFO0lBQVcsQ0FBQztFQUNqRztBQUNGOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sZUFBZUksV0FBV0EsQ0FDL0JuQixJQUFrQixFQUNsQmIsVUFBa0IsRUFDbEJjLEtBQXFCLEVBQ0s7RUFDMUIsTUFBTUMsT0FBTyxHQUFHLElBQUFDLG9CQUFVLEVBQUNILElBQUksQ0FBQ0ksSUFBSSxFQUFFakIsVUFBVSxDQUFDO0VBQ2pELElBQUk7SUFDRjtJQUNBO0lBQ0E7SUFDQSxNQUFNaUMsR0FBRyxHQUFHLE1BQU0sSUFBQUMsV0FBTSxFQUN0QjtNQUFFZixJQUFJLEVBQUVMLEtBQUssQ0FBQ0s7SUFBSyxDQUFDLEVBQ3BCO01BQ0VnQixNQUFNLEVBQUUsT0FBTztNQUNmQyxLQUFLLEVBQUU7UUFBRWhCLEdBQUcsRUFBRSxJQUFBQyxXQUFNLEVBQUM7VUFBRUMsT0FBTyxFQUFFVCxJQUFJLENBQUNVLEVBQUU7VUFBRVI7UUFBUSxDQUFDLEVBQUU7VUFBRVMsSUFBSSxFQUFFO1FBQUssQ0FBQztNQUFFO0lBQ3RFLENBQ0YsQ0FBQztJQUNELElBQUksSUFBSSxJQUFJUyxHQUFHLElBQUlBLEdBQUcsQ0FBQ0ksRUFBRSxLQUFLLEtBQUssRUFBRSxPQUFPO01BQUVULE1BQU0sRUFBRTtJQUFXLENBQUM7SUFDbEUsT0FBTztNQUFFQSxNQUFNLEVBQUU7SUFBUyxDQUFDO0VBQzdCLENBQUMsQ0FBQyxNQUFNO0lBQ04sT0FBTztNQUFFQSxNQUFNLEVBQUU7SUFBVyxDQUFDO0VBQy9CO0FBQ0YiLCJpZ25vcmVMaXN0IjpbXX0=