"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useOverlayFocusDismiss = useOverlayFocusDismiss;
var _react = require("react");
// The dialog/menu contract for this library's overlays (R-IX-1): focus moves
// IN on open, Tab is trapped while open (unless the surface is a menu — menus
// do not trap Tab; Tab is leave, and the menu closes behind the move), Escape
// closes only the TOP of a module-level stack, and focus RETURNS to the
// element that opened the overlay. The stack exists because the surfaces
// overlap (a picker opened from a row's context menu, a modal above either):
// one Escape closes one overlay.
//
// Same spelling as the sibling apps' hook (grove R3-608) — one contract, not
// a per-component invention. This port adds `returnTo`: a menu opened from a
// pointer event (right-click, long-press) may have nothing focused, so the
// caller names the invoker it captured when the menu was opened.

/** Elements that can hold focus inside the overlay. */
const FOCUSABLE = 'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])';

/** The open-overlay stack, newest last. Only the top entry answers Escape —
 *  a nested pair closes one per key, never both at once. */
const stack = [];
/**
 * Wire the contract to an overlay root. Attach the returned ref to the element
 * that bounds the overlay (its panel/menu box).
 *
 * @param open    the overlay's open state — the effect arms on true and cleans
 *                up (returning focus) on false/unmount.
 * @param onClose Escape's meaning: close without committing.
 */
function useOverlayFocusDismiss(open, onClose, opts = {}) {
  const rootRef = (0, _react.useRef)(null);
  // The latest close callback, kept current in an effect (never a render-time
  // ref write — the react-hooks compiler forbids it, correctly).
  const onCloseRef = (0, _react.useRef)(onClose);
  (0, _react.useEffect)(() => {
    onCloseRef.current = onClose;
  });
  const trapTab = opts.trapTab !== false;
  (0, _react.useEffect)(() => {
    if (!open) return;
    // The trigger to return to, captured BEFORE focus moves in.
    const trigger = opts.returnTo ?? document.activeElement;
    const entry = {
      close: () => onCloseRef.current()
    };
    stack.push(entry);
    // Set when a MENU surface closes because Tab left it: the browser's own
    // focus move must stand (APG Menu Button), so the cleanup below must NOT
    // yank focus back to the trigger.
    let closedViaTab = false;
    const root = rootRef.current;
    const focusables = root ? [...root.querySelectorAll(FOCUSABLE)] : [];
    // Focus IN: the first control; a panel with no focusable content takes
    // focus itself so Escape has a home.
    (focusables[0] ?? root)?.focus();
    const onKeyDown = e => {
      const isTop = stack[stack.length - 1] === entry;
      if (e.key === "Escape") {
        if (!isTop) return; // a nested overlay above owns this key
        e.preventDefault();
        e.stopPropagation();
        onCloseRef.current();
        return;
      }
      if (!trapTab && e.key === "Tab") {
        // APG Menu: Tab is LEAVE — the focus move proceeds (no preventDefault)
        // and the menu closes behind it, never stranded over a scrim. The
        // flag keeps the cleanup from pulling focus back to the trigger: the
        // move the browser just made is the contract.
        if (isTop) {
          closedViaTab = true;
          onCloseRef.current();
        }
        return;
      }
      if (!trapTab || e.key !== "Tab" || !root) return;
      const list = [...root.querySelectorAll(FOCUSABLE)].filter(el => !el.hasAttribute("disabled"));
      if (!list.length) {
        e.preventDefault();
        return;
      }
      const first = list[0];
      const last = list[list.length - 1];
      const active = document.activeElement;
      if (!root.contains(active)) {
        e.preventDefault();
        first.focus();
      } else if (e.shiftKey && active === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && active === last) {
        e.preventDefault();
        first.focus();
      }
    };
    // Capture phase: the contract runs before any app-level key handling.
    document.addEventListener("keydown", onKeyDown, true);
    return () => {
      document.removeEventListener("keydown", onKeyDown, true);
      const i = stack.indexOf(entry);
      if (i >= 0) stack.splice(i, 1);
      // Focus RETURNS to the trigger (R-IX-1) — unless the menu closed BECAUSE
      // Tab left it: that move is the contract and stands. Guarded: the
      // trigger may be gone.
      if (!closedViaTab && trigger && document.contains(trigger)) trigger.focus();
    };
    // `opts.returnTo` is read once at open on purpose: the invoker is whatever
    // it was when the overlay opened.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, trapTab]);
  return rootRef;
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiRk9DVVNBQkxFIiwic3RhY2siLCJ1c2VPdmVybGF5Rm9jdXNEaXNtaXNzIiwib3BlbiIsIm9uQ2xvc2UiLCJvcHRzIiwicm9vdFJlZiIsInVzZVJlZiIsIm9uQ2xvc2VSZWYiLCJ1c2VFZmZlY3QiLCJjdXJyZW50IiwidHJhcFRhYiIsInRyaWdnZXIiLCJyZXR1cm5UbyIsImRvY3VtZW50IiwiYWN0aXZlRWxlbWVudCIsImVudHJ5IiwiY2xvc2UiLCJwdXNoIiwiY2xvc2VkVmlhVGFiIiwicm9vdCIsImZvY3VzYWJsZXMiLCJxdWVyeVNlbGVjdG9yQWxsIiwiZm9jdXMiLCJvbktleURvd24iLCJlIiwiaXNUb3AiLCJsZW5ndGgiLCJrZXkiLCJwcmV2ZW50RGVmYXVsdCIsInN0b3BQcm9wYWdhdGlvbiIsImxpc3QiLCJmaWx0ZXIiLCJlbCIsImhhc0F0dHJpYnV0ZSIsImZpcnN0IiwibGFzdCIsImFjdGl2ZSIsImNvbnRhaW5zIiwic2hpZnRLZXkiLCJhZGRFdmVudExpc3RlbmVyIiwicmVtb3ZlRXZlbnRMaXN0ZW5lciIsImkiLCJpbmRleE9mIiwic3BsaWNlIl0sInNvdXJjZXMiOlsidXNlT3ZlcmxheUZvY3VzRGlzbWlzcy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBUaGUgZGlhbG9nL21lbnUgY29udHJhY3QgZm9yIHRoaXMgbGlicmFyeSdzIG92ZXJsYXlzIChSLUlYLTEpOiBmb2N1cyBtb3Zlc1xuLy8gSU4gb24gb3BlbiwgVGFiIGlzIHRyYXBwZWQgd2hpbGUgb3BlbiAodW5sZXNzIHRoZSBzdXJmYWNlIGlzIGEgbWVudSDigJQgbWVudXNcbi8vIGRvIG5vdCB0cmFwIFRhYjsgVGFiIGlzIGxlYXZlLCBhbmQgdGhlIG1lbnUgY2xvc2VzIGJlaGluZCB0aGUgbW92ZSksIEVzY2FwZVxuLy8gY2xvc2VzIG9ubHkgdGhlIFRPUCBvZiBhIG1vZHVsZS1sZXZlbCBzdGFjaywgYW5kIGZvY3VzIFJFVFVSTlMgdG8gdGhlXG4vLyBlbGVtZW50IHRoYXQgb3BlbmVkIHRoZSBvdmVybGF5LiBUaGUgc3RhY2sgZXhpc3RzIGJlY2F1c2UgdGhlIHN1cmZhY2VzXG4vLyBvdmVybGFwIChhIHBpY2tlciBvcGVuZWQgZnJvbSBhIHJvdydzIGNvbnRleHQgbWVudSwgYSBtb2RhbCBhYm92ZSBlaXRoZXIpOlxuLy8gb25lIEVzY2FwZSBjbG9zZXMgb25lIG92ZXJsYXkuXG4vL1xuLy8gU2FtZSBzcGVsbGluZyBhcyB0aGUgc2libGluZyBhcHBzJyBob29rIChncm92ZSBSMy02MDgpIOKAlCBvbmUgY29udHJhY3QsIG5vdFxuLy8gYSBwZXItY29tcG9uZW50IGludmVudGlvbi4gVGhpcyBwb3J0IGFkZHMgYHJldHVyblRvYDogYSBtZW51IG9wZW5lZCBmcm9tIGFcbi8vIHBvaW50ZXIgZXZlbnQgKHJpZ2h0LWNsaWNrLCBsb25nLXByZXNzKSBtYXkgaGF2ZSBub3RoaW5nIGZvY3VzZWQsIHNvIHRoZVxuLy8gY2FsbGVyIG5hbWVzIHRoZSBpbnZva2VyIGl0IGNhcHR1cmVkIHdoZW4gdGhlIG1lbnUgd2FzIG9wZW5lZC5cbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlUmVmIH0gZnJvbSBcInJlYWN0XCI7XG5cbi8qKiBFbGVtZW50cyB0aGF0IGNhbiBob2xkIGZvY3VzIGluc2lkZSB0aGUgb3ZlcmxheS4gKi9cbmNvbnN0IEZPQ1VTQUJMRSA9XG4gICdhW2hyZWZdLCBidXR0b246bm90KFtkaXNhYmxlZF0pLCBpbnB1dDpub3QoW2Rpc2FibGVkXSksIHNlbGVjdDpub3QoW2Rpc2FibGVkXSksIHRleHRhcmVhOm5vdChbZGlzYWJsZWRdKSwgW3RhYmluZGV4XTpub3QoW3RhYmluZGV4PVwiLTFcIl0pJztcblxuLyoqIFRoZSBvcGVuLW92ZXJsYXkgc3RhY2ssIG5ld2VzdCBsYXN0LiBPbmx5IHRoZSB0b3AgZW50cnkgYW5zd2VycyBFc2NhcGUg4oCUXG4gKiAgYSBuZXN0ZWQgcGFpciBjbG9zZXMgb25lIHBlciBrZXksIG5ldmVyIGJvdGggYXQgb25jZS4gKi9cbmNvbnN0IHN0YWNrOiB7IGNsb3NlOiAoKSA9PiB2b2lkIH1bXSA9IFtdO1xuXG5pbnRlcmZhY2UgT3ZlcmxheUZvY3VzRGlzbWlzc09wdGlvbnMge1xuICAvKiogTWVudXMgZG8gbm90IHRyYXAgVGFiICh0aGUgQVBHIG1lbnUgcGF0dGVybiBrZWVwcyBUYWIgYXMgbGVhdmUpOyBkaWFsb2dzXG4gICAqICBkby4gRGVmYXVsdCB0cnVlLiAqL1xuICB0cmFwVGFiPzogYm9vbGVhbjtcbiAgLyoqIFdoZXJlIGZvY3VzIHJldHVybnMgb24gY2xvc2UuIERlZmF1bHRzIHRvIHRoZSBlbGVtZW50IGZvY3VzZWQgd2hlbiB0aGVcbiAgICogIG92ZXJsYXkgb3BlbmVkIOKAlCByaWdodCBmb3Iga2V5Ym9hcmQtb3BlbmVkIG92ZXJsYXlzOyBhIHBvaW50ZXItb3BlbmVkXG4gICAqICBtZW51IHBhc3NlcyB0aGUgcm93IGl0IHdhcyBvcGVuZWQgZnJvbSBpbnN0ZWFkLiAqL1xuICByZXR1cm5Ubz86IEhUTUxFbGVtZW50IHwgbnVsbDtcbn1cblxuLyoqXG4gKiBXaXJlIHRoZSBjb250cmFjdCB0byBhbiBvdmVybGF5IHJvb3QuIEF0dGFjaCB0aGUgcmV0dXJuZWQgcmVmIHRvIHRoZSBlbGVtZW50XG4gKiB0aGF0IGJvdW5kcyB0aGUgb3ZlcmxheSAoaXRzIHBhbmVsL21lbnUgYm94KS5cbiAqXG4gKiBAcGFyYW0gb3BlbiAgICB0aGUgb3ZlcmxheSdzIG9wZW4gc3RhdGUg4oCUIHRoZSBlZmZlY3QgYXJtcyBvbiB0cnVlIGFuZCBjbGVhbnNcbiAqICAgICAgICAgICAgICAgIHVwIChyZXR1cm5pbmcgZm9jdXMpIG9uIGZhbHNlL3VubW91bnQuXG4gKiBAcGFyYW0gb25DbG9zZSBFc2NhcGUncyBtZWFuaW5nOiBjbG9zZSB3aXRob3V0IGNvbW1pdHRpbmcuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VPdmVybGF5Rm9jdXNEaXNtaXNzPFQgZXh0ZW5kcyBIVE1MRWxlbWVudD4oXG4gIG9wZW46IGJvb2xlYW4sXG4gIG9uQ2xvc2U6ICgpID0+IHZvaWQsXG4gIG9wdHM6IE92ZXJsYXlGb2N1c0Rpc21pc3NPcHRpb25zID0ge30sXG4pIHtcbiAgY29uc3Qgcm9vdFJlZiA9IHVzZVJlZjxUIHwgbnVsbD4obnVsbCk7XG4gIC8vIFRoZSBsYXRlc3QgY2xvc2UgY2FsbGJhY2ssIGtlcHQgY3VycmVudCBpbiBhbiBlZmZlY3QgKG5ldmVyIGEgcmVuZGVyLXRpbWVcbiAgLy8gcmVmIHdyaXRlIOKAlCB0aGUgcmVhY3QtaG9va3MgY29tcGlsZXIgZm9yYmlkcyBpdCwgY29ycmVjdGx5KS5cbiAgY29uc3Qgb25DbG9zZVJlZiA9IHVzZVJlZihvbkNsb3NlKTtcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBvbkNsb3NlUmVmLmN1cnJlbnQgPSBvbkNsb3NlO1xuICB9KTtcbiAgY29uc3QgdHJhcFRhYiA9IG9wdHMudHJhcFRhYiAhPT0gZmFsc2U7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIW9wZW4pIHJldHVybjtcbiAgICAvLyBUaGUgdHJpZ2dlciB0byByZXR1cm4gdG8sIGNhcHR1cmVkIEJFRk9SRSBmb2N1cyBtb3ZlcyBpbi5cbiAgICBjb25zdCB0cmlnZ2VyID0gb3B0cy5yZXR1cm5UbyA/PyAoZG9jdW1lbnQuYWN0aXZlRWxlbWVudCBhcyBIVE1MRWxlbWVudCB8IG51bGwpO1xuICAgIGNvbnN0IGVudHJ5ID0ge1xuICAgICAgY2xvc2U6ICgpID0+IG9uQ2xvc2VSZWYuY3VycmVudCgpLFxuICAgIH07XG4gICAgc3RhY2sucHVzaChlbnRyeSk7XG4gICAgLy8gU2V0IHdoZW4gYSBNRU5VIHN1cmZhY2UgY2xvc2VzIGJlY2F1c2UgVGFiIGxlZnQgaXQ6IHRoZSBicm93c2VyJ3Mgb3duXG4gICAgLy8gZm9jdXMgbW92ZSBtdXN0IHN0YW5kIChBUEcgTWVudSBCdXR0b24pLCBzbyB0aGUgY2xlYW51cCBiZWxvdyBtdXN0IE5PVFxuICAgIC8vIHlhbmsgZm9jdXMgYmFjayB0byB0aGUgdHJpZ2dlci5cbiAgICBsZXQgY2xvc2VkVmlhVGFiID0gZmFsc2U7XG4gICAgY29uc3Qgcm9vdCA9IHJvb3RSZWYuY3VycmVudDtcbiAgICBjb25zdCBmb2N1c2FibGVzID0gcm9vdCA/IFsuLi5yb290LnF1ZXJ5U2VsZWN0b3JBbGw8SFRNTEVsZW1lbnQ+KEZPQ1VTQUJMRSldIDogW107XG4gICAgLy8gRm9jdXMgSU46IHRoZSBmaXJzdCBjb250cm9sOyBhIHBhbmVsIHdpdGggbm8gZm9jdXNhYmxlIGNvbnRlbnQgdGFrZXNcbiAgICAvLyBmb2N1cyBpdHNlbGYgc28gRXNjYXBlIGhhcyBhIGhvbWUuXG4gICAgKGZvY3VzYWJsZXNbMF0gPz8gcm9vdCk/LmZvY3VzKCk7XG5cbiAgICBjb25zdCBvbktleURvd24gPSAoZTogS2V5Ym9hcmRFdmVudCkgPT4ge1xuICAgICAgY29uc3QgaXNUb3AgPSBzdGFja1tzdGFjay5sZW5ndGggLSAxXSA9PT0gZW50cnk7XG4gICAgICBpZiAoZS5rZXkgPT09IFwiRXNjYXBlXCIpIHtcbiAgICAgICAgaWYgKCFpc1RvcCkgcmV0dXJuOyAvLyBhIG5lc3RlZCBvdmVybGF5IGFib3ZlIG93bnMgdGhpcyBrZXlcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgICBvbkNsb3NlUmVmLmN1cnJlbnQoKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgaWYgKCF0cmFwVGFiICYmIGUua2V5ID09PSBcIlRhYlwiKSB7XG4gICAgICAgIC8vIEFQRyBNZW51OiBUYWIgaXMgTEVBVkUg4oCUIHRoZSBmb2N1cyBtb3ZlIHByb2NlZWRzIChubyBwcmV2ZW50RGVmYXVsdClcbiAgICAgICAgLy8gYW5kIHRoZSBtZW51IGNsb3NlcyBiZWhpbmQgaXQsIG5ldmVyIHN0cmFuZGVkIG92ZXIgYSBzY3JpbS4gVGhlXG4gICAgICAgIC8vIGZsYWcga2VlcHMgdGhlIGNsZWFudXAgZnJvbSBwdWxsaW5nIGZvY3VzIGJhY2sgdG8gdGhlIHRyaWdnZXI6IHRoZVxuICAgICAgICAvLyBtb3ZlIHRoZSBicm93c2VyIGp1c3QgbWFkZSBpcyB0aGUgY29udHJhY3QuXG4gICAgICAgIGlmIChpc1RvcCkge1xuICAgICAgICAgIGNsb3NlZFZpYVRhYiA9IHRydWU7XG4gICAgICAgICAgb25DbG9zZVJlZi5jdXJyZW50KCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgaWYgKCF0cmFwVGFiIHx8IGUua2V5ICE9PSBcIlRhYlwiIHx8ICFyb290KSByZXR1cm47XG4gICAgICBjb25zdCBsaXN0ID0gWy4uLnJvb3QucXVlcnlTZWxlY3RvckFsbDxIVE1MRWxlbWVudD4oRk9DVVNBQkxFKV0uZmlsdGVyKChlbCkgPT4gIWVsLmhhc0F0dHJpYnV0ZShcImRpc2FibGVkXCIpKTtcbiAgICAgIGlmICghbGlzdC5sZW5ndGgpIHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBjb25zdCBmaXJzdCA9IGxpc3RbMF07XG4gICAgICBjb25zdCBsYXN0ID0gbGlzdFtsaXN0Lmxlbmd0aCAtIDFdO1xuICAgICAgY29uc3QgYWN0aXZlID0gZG9jdW1lbnQuYWN0aXZlRWxlbWVudDtcbiAgICAgIGlmICghcm9vdC5jb250YWlucyhhY3RpdmUpKSB7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgZmlyc3QuZm9jdXMoKTtcbiAgICAgIH0gZWxzZSBpZiAoZS5zaGlmdEtleSAmJiBhY3RpdmUgPT09IGZpcnN0KSB7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgbGFzdC5mb2N1cygpO1xuICAgICAgfSBlbHNlIGlmICghZS5zaGlmdEtleSAmJiBhY3RpdmUgPT09IGxhc3QpIHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICBmaXJzdC5mb2N1cygpO1xuICAgICAgfVxuICAgIH07XG4gICAgLy8gQ2FwdHVyZSBwaGFzZTogdGhlIGNvbnRyYWN0IHJ1bnMgYmVmb3JlIGFueSBhcHAtbGV2ZWwga2V5IGhhbmRsaW5nLlxuICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJrZXlkb3duXCIsIG9uS2V5RG93biwgdHJ1ZSk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJrZXlkb3duXCIsIG9uS2V5RG93biwgdHJ1ZSk7XG4gICAgICBjb25zdCBpID0gc3RhY2suaW5kZXhPZihlbnRyeSk7XG4gICAgICBpZiAoaSA+PSAwKSBzdGFjay5zcGxpY2UoaSwgMSk7XG4gICAgICAvLyBGb2N1cyBSRVRVUk5TIHRvIHRoZSB0cmlnZ2VyIChSLUlYLTEpIOKAlCB1bmxlc3MgdGhlIG1lbnUgY2xvc2VkIEJFQ0FVU0VcbiAgICAgIC8vIFRhYiBsZWZ0IGl0OiB0aGF0IG1vdmUgaXMgdGhlIGNvbnRyYWN0IGFuZCBzdGFuZHMuIEd1YXJkZWQ6IHRoZVxuICAgICAgLy8gdHJpZ2dlciBtYXkgYmUgZ29uZS5cbiAgICAgIGlmICghY2xvc2VkVmlhVGFiICYmIHRyaWdnZXIgJiYgZG9jdW1lbnQuY29udGFpbnModHJpZ2dlcikpIHRyaWdnZXIuZm9jdXMoKTtcbiAgICB9O1xuICAgIC8vIGBvcHRzLnJldHVyblRvYCBpcyByZWFkIG9uY2UgYXQgb3BlbiBvbiBwdXJwb3NlOiB0aGUgaW52b2tlciBpcyB3aGF0ZXZlclxuICAgIC8vIGl0IHdhcyB3aGVuIHRoZSBvdmVybGF5IG9wZW5lZC5cbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgcmVhY3QtaG9va3MvZXhoYXVzdGl2ZS1kZXBzXG4gIH0sIFtvcGVuLCB0cmFwVGFiXSk7XG5cbiAgcmV0dXJuIHJvb3RSZWY7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQVlBLElBQUFBLE1BQUEsR0FBQUMsT0FBQTtBQVpBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFHQTtBQUNBLE1BQU1DLFNBQVMsR0FDYiwySUFBMkk7O0FBRTdJO0FBQ0E7QUFDQSxNQUFNQyxLQUE4QixHQUFHLEVBQUU7QUFZekM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVNDLHNCQUFzQkEsQ0FDcENDLElBQWEsRUFDYkMsT0FBbUIsRUFDbkJDLElBQWdDLEdBQUcsQ0FBQyxDQUFDLEVBQ3JDO0VBQ0EsTUFBTUMsT0FBTyxHQUFHLElBQUFDLGFBQU0sRUFBVyxJQUFJLENBQUM7RUFDdEM7RUFDQTtFQUNBLE1BQU1DLFVBQVUsR0FBRyxJQUFBRCxhQUFNLEVBQUNILE9BQU8sQ0FBQztFQUNsQyxJQUFBSyxnQkFBUyxFQUFDLE1BQU07SUFDZEQsVUFBVSxDQUFDRSxPQUFPLEdBQUdOLE9BQU87RUFDOUIsQ0FBQyxDQUFDO0VBQ0YsTUFBTU8sT0FBTyxHQUFHTixJQUFJLENBQUNNLE9BQU8sS0FBSyxLQUFLO0VBRXRDLElBQUFGLGdCQUFTLEVBQUMsTUFBTTtJQUNkLElBQUksQ0FBQ04sSUFBSSxFQUFFO0lBQ1g7SUFDQSxNQUFNUyxPQUFPLEdBQUdQLElBQUksQ0FBQ1EsUUFBUSxJQUFLQyxRQUFRLENBQUNDLGFBQW9DO0lBQy9FLE1BQU1DLEtBQUssR0FBRztNQUNaQyxLQUFLLEVBQUVBLENBQUEsS0FBTVQsVUFBVSxDQUFDRSxPQUFPLENBQUM7SUFDbEMsQ0FBQztJQUNEVCxLQUFLLENBQUNpQixJQUFJLENBQUNGLEtBQUssQ0FBQztJQUNqQjtJQUNBO0lBQ0E7SUFDQSxJQUFJRyxZQUFZLEdBQUcsS0FBSztJQUN4QixNQUFNQyxJQUFJLEdBQUdkLE9BQU8sQ0FBQ0ksT0FBTztJQUM1QixNQUFNVyxVQUFVLEdBQUdELElBQUksR0FBRyxDQUFDLEdBQUdBLElBQUksQ0FBQ0UsZ0JBQWdCLENBQWN0QixTQUFTLENBQUMsQ0FBQyxHQUFHLEVBQUU7SUFDakY7SUFDQTtJQUNBLENBQUNxQixVQUFVLENBQUMsQ0FBQyxDQUFDLElBQUlELElBQUksR0FBR0csS0FBSyxDQUFDLENBQUM7SUFFaEMsTUFBTUMsU0FBUyxHQUFJQyxDQUFnQixJQUFLO01BQ3RDLE1BQU1DLEtBQUssR0FBR3pCLEtBQUssQ0FBQ0EsS0FBSyxDQUFDMEIsTUFBTSxHQUFHLENBQUMsQ0FBQyxLQUFLWCxLQUFLO01BQy9DLElBQUlTLENBQUMsQ0FBQ0csR0FBRyxLQUFLLFFBQVEsRUFBRTtRQUN0QixJQUFJLENBQUNGLEtBQUssRUFBRSxPQUFPLENBQUM7UUFDcEJELENBQUMsQ0FBQ0ksY0FBYyxDQUFDLENBQUM7UUFDbEJKLENBQUMsQ0FBQ0ssZUFBZSxDQUFDLENBQUM7UUFDbkJ0QixVQUFVLENBQUNFLE9BQU8sQ0FBQyxDQUFDO1FBQ3BCO01BQ0Y7TUFDQSxJQUFJLENBQUNDLE9BQU8sSUFBSWMsQ0FBQyxDQUFDRyxHQUFHLEtBQUssS0FBSyxFQUFFO1FBQy9CO1FBQ0E7UUFDQTtRQUNBO1FBQ0EsSUFBSUYsS0FBSyxFQUFFO1VBQ1RQLFlBQVksR0FBRyxJQUFJO1VBQ25CWCxVQUFVLENBQUNFLE9BQU8sQ0FBQyxDQUFDO1FBQ3RCO1FBQ0E7TUFDRjtNQUNBLElBQUksQ0FBQ0MsT0FBTyxJQUFJYyxDQUFDLENBQUNHLEdBQUcsS0FBSyxLQUFLLElBQUksQ0FBQ1IsSUFBSSxFQUFFO01BQzFDLE1BQU1XLElBQUksR0FBRyxDQUFDLEdBQUdYLElBQUksQ0FBQ0UsZ0JBQWdCLENBQWN0QixTQUFTLENBQUMsQ0FBQyxDQUFDZ0MsTUFBTSxDQUFFQyxFQUFFLElBQUssQ0FBQ0EsRUFBRSxDQUFDQyxZQUFZLENBQUMsVUFBVSxDQUFDLENBQUM7TUFDNUcsSUFBSSxDQUFDSCxJQUFJLENBQUNKLE1BQU0sRUFBRTtRQUNoQkYsQ0FBQyxDQUFDSSxjQUFjLENBQUMsQ0FBQztRQUNsQjtNQUNGO01BQ0EsTUFBTU0sS0FBSyxHQUFHSixJQUFJLENBQUMsQ0FBQyxDQUFDO01BQ3JCLE1BQU1LLElBQUksR0FBR0wsSUFBSSxDQUFDQSxJQUFJLENBQUNKLE1BQU0sR0FBRyxDQUFDLENBQUM7TUFDbEMsTUFBTVUsTUFBTSxHQUFHdkIsUUFBUSxDQUFDQyxhQUFhO01BQ3JDLElBQUksQ0FBQ0ssSUFBSSxDQUFDa0IsUUFBUSxDQUFDRCxNQUFNLENBQUMsRUFBRTtRQUMxQlosQ0FBQyxDQUFDSSxjQUFjLENBQUMsQ0FBQztRQUNsQk0sS0FBSyxDQUFDWixLQUFLLENBQUMsQ0FBQztNQUNmLENBQUMsTUFBTSxJQUFJRSxDQUFDLENBQUNjLFFBQVEsSUFBSUYsTUFBTSxLQUFLRixLQUFLLEVBQUU7UUFDekNWLENBQUMsQ0FBQ0ksY0FBYyxDQUFDLENBQUM7UUFDbEJPLElBQUksQ0FBQ2IsS0FBSyxDQUFDLENBQUM7TUFDZCxDQUFDLE1BQU0sSUFBSSxDQUFDRSxDQUFDLENBQUNjLFFBQVEsSUFBSUYsTUFBTSxLQUFLRCxJQUFJLEVBQUU7UUFDekNYLENBQUMsQ0FBQ0ksY0FBYyxDQUFDLENBQUM7UUFDbEJNLEtBQUssQ0FBQ1osS0FBSyxDQUFDLENBQUM7TUFDZjtJQUNGLENBQUM7SUFDRDtJQUNBVCxRQUFRLENBQUMwQixnQkFBZ0IsQ0FBQyxTQUFTLEVBQUVoQixTQUFTLEVBQUUsSUFBSSxDQUFDO0lBQ3JELE9BQU8sTUFBTTtNQUNYVixRQUFRLENBQUMyQixtQkFBbUIsQ0FBQyxTQUFTLEVBQUVqQixTQUFTLEVBQUUsSUFBSSxDQUFDO01BQ3hELE1BQU1rQixDQUFDLEdBQUd6QyxLQUFLLENBQUMwQyxPQUFPLENBQUMzQixLQUFLLENBQUM7TUFDOUIsSUFBSTBCLENBQUMsSUFBSSxDQUFDLEVBQUV6QyxLQUFLLENBQUMyQyxNQUFNLENBQUNGLENBQUMsRUFBRSxDQUFDLENBQUM7TUFDOUI7TUFDQTtNQUNBO01BQ0EsSUFBSSxDQUFDdkIsWUFBWSxJQUFJUCxPQUFPLElBQUlFLFFBQVEsQ0FBQ3dCLFFBQVEsQ0FBQzFCLE9BQU8sQ0FBQyxFQUFFQSxPQUFPLENBQUNXLEtBQUssQ0FBQyxDQUFDO0lBQzdFLENBQUM7SUFDRDtJQUNBO0lBQ0E7RUFDRixDQUFDLEVBQUUsQ0FBQ3BCLElBQUksRUFBRVEsT0FBTyxDQUFDLENBQUM7RUFFbkIsT0FBT0wsT0FBTztBQUNoQiIsImlnbm9yZUxpc3QiOltdfQ==