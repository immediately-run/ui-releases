var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

var _react = require("@testing-library/react");
var _vitest = require("vitest");
var _useHostThemeAttribute = require("./useHostThemeAttribute");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // R3-827 — the hook drives `html[data-theme]` from the host polarity: set in
// light, removed in dark (dark is the stylesheet's attribute-less default).
const hostTheme = _vitest.vi.fn();
_vitest.vi.mock("@immediately-run/sdk/theme", () => ({
  useHostTheme: () => hostTheme()
}));
function Probe() {
  _s();
  (0, _useHostThemeAttribute.useHostThemeAttribute)();
  return null;
}
_s(Probe, "BgtyC7zTk0ng2Vs+JE7IY8K7HtE=", false, function () {
  return [_useHostThemeAttribute.useHostThemeAttribute];
});
_c = Probe;
(0, _vitest.describe)("useHostThemeAttribute", () => {
  (0, _vitest.beforeEach)(() => {
    hostTheme.mockReturnValue("dark");
    document.documentElement.removeAttribute("data-theme");
  });
  (0, _vitest.it)("sets data-theme='light' on documentElement when the host is light", () => {
    hostTheme.mockReturnValue("light");
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(Probe, {}));
    (0, _vitest.expect)(document.documentElement).toHaveAttribute("data-theme", "light");
  });
  (0, _vitest.it)("removes the attribute when the host is dark", () => {
    hostTheme.mockReturnValue("light");
    const {
      rerender
    } = (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(Probe, {}));
    (0, _vitest.expect)(document.documentElement).toHaveAttribute("data-theme", "light");
    hostTheme.mockReturnValue("dark");
    rerender(/*#__PURE__*/(0, _jsxRuntime.jsx)(Probe, {}));
    (0, _vitest.expect)(document.documentElement).not.toHaveAttribute("data-theme");
  });
  (0, _vitest.it)("never writes the attribute while the host value is dark (the default stays attribute-less)", () => {
    hostTheme.mockReturnValue("dark");
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(Probe, {}));
    (0, _vitest.expect)(document.documentElement).not.toHaveAttribute("data-theme");
  });
});
var _c;
$RefreshReg$(_c, "Probe");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3ZpdGVzdCIsIl91c2VIb3N0VGhlbWVBdHRyaWJ1dGUiLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiaG9zdFRoZW1lIiwidmkiLCJmbiIsIm1vY2siLCJ1c2VIb3N0VGhlbWUiLCJQcm9iZSIsInVzZUhvc3RUaGVtZUF0dHJpYnV0ZSIsIl9jIiwiZGVzY3JpYmUiLCJiZWZvcmVFYWNoIiwibW9ja1JldHVyblZhbHVlIiwiZG9jdW1lbnQiLCJkb2N1bWVudEVsZW1lbnQiLCJyZW1vdmVBdHRyaWJ1dGUiLCJpdCIsInJlbmRlciIsImpzeCIsImV4cGVjdCIsInRvSGF2ZUF0dHJpYnV0ZSIsInJlcmVuZGVyIiwibm90IiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsidXNlSG9zdFRoZW1lQXR0cmlidXRlLnRlc3QudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIFIzLTgyNyDigJQgdGhlIGhvb2sgZHJpdmVzIGBodG1sW2RhdGEtdGhlbWVdYCBmcm9tIHRoZSBob3N0IHBvbGFyaXR5OiBzZXQgaW5cbi8vIGxpZ2h0LCByZW1vdmVkIGluIGRhcmsgKGRhcmsgaXMgdGhlIHN0eWxlc2hlZXQncyBhdHRyaWJ1dGUtbGVzcyBkZWZhdWx0KS5cblxuaW1wb3J0IHsgcmVuZGVyIH0gZnJvbSBcIkB0ZXN0aW5nLWxpYnJhcnkvcmVhY3RcIjtcbmltcG9ydCB7IGJlZm9yZUVhY2gsIGRlc2NyaWJlLCBleHBlY3QsIGl0LCB2aSB9IGZyb20gXCJ2aXRlc3RcIjtcblxuY29uc3QgaG9zdFRoZW1lID0gdmkuZm48KCkgPT4gXCJsaWdodFwiIHwgXCJkYXJrXCI+KCk7XG52aS5tb2NrKFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGsvdGhlbWVcIiwgKCkgPT4gKHtcbiAgdXNlSG9zdFRoZW1lOiAoKSA9PiBob3N0VGhlbWUoKSxcbn0pKTtcblxuaW1wb3J0IHsgdXNlSG9zdFRoZW1lQXR0cmlidXRlIH0gZnJvbSBcIi4vdXNlSG9zdFRoZW1lQXR0cmlidXRlXCI7XG5cbmZ1bmN0aW9uIFByb2JlKCkge1xuICB1c2VIb3N0VGhlbWVBdHRyaWJ1dGUoKTtcbiAgcmV0dXJuIG51bGw7XG59XG5cbmRlc2NyaWJlKFwidXNlSG9zdFRoZW1lQXR0cmlidXRlXCIsICgpID0+IHtcbiAgYmVmb3JlRWFjaCgoKSA9PiB7XG4gICAgaG9zdFRoZW1lLm1vY2tSZXR1cm5WYWx1ZShcImRhcmtcIik7XG4gICAgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LnJlbW92ZUF0dHJpYnV0ZShcImRhdGEtdGhlbWVcIik7XG4gIH0pO1xuXG4gIGl0KFwic2V0cyBkYXRhLXRoZW1lPSdsaWdodCcgb24gZG9jdW1lbnRFbGVtZW50IHdoZW4gdGhlIGhvc3QgaXMgbGlnaHRcIiwgKCkgPT4ge1xuICAgIGhvc3RUaGVtZS5tb2NrUmV0dXJuVmFsdWUoXCJsaWdodFwiKTtcbiAgICByZW5kZXIoPFByb2JlIC8+KTtcbiAgICBleHBlY3QoZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50KS50b0hhdmVBdHRyaWJ1dGUoXCJkYXRhLXRoZW1lXCIsIFwibGlnaHRcIik7XG4gIH0pO1xuXG4gIGl0KFwicmVtb3ZlcyB0aGUgYXR0cmlidXRlIHdoZW4gdGhlIGhvc3QgaXMgZGFya1wiLCAoKSA9PiB7XG4gICAgaG9zdFRoZW1lLm1vY2tSZXR1cm5WYWx1ZShcImxpZ2h0XCIpO1xuICAgIGNvbnN0IHsgcmVyZW5kZXIgfSA9IHJlbmRlcig8UHJvYmUgLz4pO1xuICAgIGV4cGVjdChkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQpLnRvSGF2ZUF0dHJpYnV0ZShcImRhdGEtdGhlbWVcIiwgXCJsaWdodFwiKTtcbiAgICBob3N0VGhlbWUubW9ja1JldHVyblZhbHVlKFwiZGFya1wiKTtcbiAgICByZXJlbmRlcig8UHJvYmUgLz4pO1xuICAgIGV4cGVjdChkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQpLm5vdC50b0hhdmVBdHRyaWJ1dGUoXCJkYXRhLXRoZW1lXCIpO1xuICB9KTtcblxuICBpdChcIm5ldmVyIHdyaXRlcyB0aGUgYXR0cmlidXRlIHdoaWxlIHRoZSBob3N0IHZhbHVlIGlzIGRhcmsgKHRoZSBkZWZhdWx0IHN0YXlzIGF0dHJpYnV0ZS1sZXNzKVwiLCAoKSA9PiB7XG4gICAgaG9zdFRoZW1lLm1vY2tSZXR1cm5WYWx1ZShcImRhcmtcIik7XG4gICAgcmVuZGVyKDxQcm9iZSAvPik7XG4gICAgZXhwZWN0KGRvY3VtZW50LmRvY3VtZW50RWxlbWVudCkubm90LnRvSGF2ZUF0dHJpYnV0ZShcImRhdGEtdGhlbWVcIik7XG4gIH0pO1xufSk7XG4iXSwibWFwcGluZ3MiOiI7O0FBR0EsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsT0FBQSxHQUFBRCxPQUFBO0FBT0EsSUFBQUUsc0JBQUEsR0FBQUYsT0FBQTtBQUFnRSxJQUFBRyxXQUFBLEdBQUFILE9BQUE7QUFBQSxJQUFBSSxFQUFBLEdBQUFDLFlBQUEsSUFYaEU7QUFDQTtBQUtBLE1BQU1DLFNBQVMsR0FBR0MsVUFBRSxDQUFDQyxFQUFFLENBQXlCLENBQUM7QUFDakRELFVBQUUsQ0FBQ0UsSUFBSSxDQUFDLDRCQUE0QixFQUFFLE9BQU87RUFDM0NDLFlBQVksRUFBRUEsQ0FBQSxLQUFNSixTQUFTLENBQUM7QUFDaEMsQ0FBQyxDQUFDLENBQUM7QUFJSCxTQUFTSyxLQUFLQSxDQUFBLEVBQUc7RUFBQVAsRUFBQTtFQUNmLElBQUFRLDRDQUFxQixFQUFDLENBQUM7RUFDdkIsT0FBTyxJQUFJO0FBQ2I7QUFBQ1IsRUFBQSxDQUhRTyxLQUFLO0VBQUEsUUFDWkMsNENBQXFCO0FBQUE7QUFBQUMsRUFBQSxHQURkRixLQUFLO0FBS2QsSUFBQUcsZ0JBQVEsRUFBQyx1QkFBdUIsRUFBRSxNQUFNO0VBQ3RDLElBQUFDLGtCQUFVLEVBQUMsTUFBTTtJQUNmVCxTQUFTLENBQUNVLGVBQWUsQ0FBQyxNQUFNLENBQUM7SUFDakNDLFFBQVEsQ0FBQ0MsZUFBZSxDQUFDQyxlQUFlLENBQUMsWUFBWSxDQUFDO0VBQ3hELENBQUMsQ0FBQztFQUVGLElBQUFDLFVBQUUsRUFBQyxtRUFBbUUsRUFBRSxNQUFNO0lBQzVFZCxTQUFTLENBQUNVLGVBQWUsQ0FBQyxPQUFPLENBQUM7SUFDbEMsSUFBQUssYUFBTSxlQUFDLElBQUFsQixXQUFBLENBQUFtQixHQUFBLEVBQUNYLEtBQUssSUFBRSxDQUFDLENBQUM7SUFDakIsSUFBQVksY0FBTSxFQUFDTixRQUFRLENBQUNDLGVBQWUsQ0FBQyxDQUFDTSxlQUFlLENBQUMsWUFBWSxFQUFFLE9BQU8sQ0FBQztFQUN6RSxDQUFDLENBQUM7RUFFRixJQUFBSixVQUFFLEVBQUMsNkNBQTZDLEVBQUUsTUFBTTtJQUN0RGQsU0FBUyxDQUFDVSxlQUFlLENBQUMsT0FBTyxDQUFDO0lBQ2xDLE1BQU07TUFBRVM7SUFBUyxDQUFDLEdBQUcsSUFBQUosYUFBTSxlQUFDLElBQUFsQixXQUFBLENBQUFtQixHQUFBLEVBQUNYLEtBQUssSUFBRSxDQUFDLENBQUM7SUFDdEMsSUFBQVksY0FBTSxFQUFDTixRQUFRLENBQUNDLGVBQWUsQ0FBQyxDQUFDTSxlQUFlLENBQUMsWUFBWSxFQUFFLE9BQU8sQ0FBQztJQUN2RWxCLFNBQVMsQ0FBQ1UsZUFBZSxDQUFDLE1BQU0sQ0FBQztJQUNqQ1MsUUFBUSxjQUFDLElBQUF0QixXQUFBLENBQUFtQixHQUFBLEVBQUNYLEtBQUssSUFBRSxDQUFDLENBQUM7SUFDbkIsSUFBQVksY0FBTSxFQUFDTixRQUFRLENBQUNDLGVBQWUsQ0FBQyxDQUFDUSxHQUFHLENBQUNGLGVBQWUsQ0FBQyxZQUFZLENBQUM7RUFDcEUsQ0FBQyxDQUFDO0VBRUYsSUFBQUosVUFBRSxFQUFDLDRGQUE0RixFQUFFLE1BQU07SUFDckdkLFNBQVMsQ0FBQ1UsZUFBZSxDQUFDLE1BQU0sQ0FBQztJQUNqQyxJQUFBSyxhQUFNLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ1gsS0FBSyxJQUFFLENBQUMsQ0FBQztJQUNqQixJQUFBWSxjQUFNLEVBQUNOLFFBQVEsQ0FBQ0MsZUFBZSxDQUFDLENBQUNRLEdBQUcsQ0FBQ0YsZUFBZSxDQUFDLFlBQVksQ0FBQztFQUNwRSxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7QUFBQyxJQUFBWCxFQUFBO0FBQUFjLFlBQUEsQ0FBQWQsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}