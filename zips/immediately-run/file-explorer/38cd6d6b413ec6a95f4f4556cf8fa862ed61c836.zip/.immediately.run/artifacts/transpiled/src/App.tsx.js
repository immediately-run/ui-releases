var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
require("./index.css");
require("./lib-ui/styles.css");
var _sdk = _interopRequireDefault(require("./lib-ui/sdk"));
var _useHostThemeAttribute = require("./hooks/useHostThemeAttribute");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // Root component — immediately.run renders the default export of THIS file.
// Global CSS is imported here (not main.tsx). The shipped app is now assembled
// entirely from the headless library + its SDK adapter (`<SdkFileExplorer/>`) —
// the parity proof for the file-explorer-library extraction.
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function App() {
  _s();
  // R3-827 — drive `html[data-theme]` from the host's polarity so the light
  // palette (index.css) actually applies when the host goes light.
  (0, _useHostThemeAttribute.useHostThemeAttribute)();
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_sdk.default, {});
}
_s(App, "BgtyC7zTk0ng2Vs+JE7IY8K7HtE=", false, function () {
  return [_useHostThemeAttribute.useHostThemeAttribute];
});
_c = App;
var _default = exports.default = App;
var _c;
$RefreshReg$(_c, "App");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJyZXF1aXJlIiwiX3NkayIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJfdXNlSG9zdFRoZW1lQXR0cmlidXRlIiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsIkFwcCIsInVzZUhvc3RUaGVtZUF0dHJpYnV0ZSIsImpzeCIsIl9jIiwiX2RlZmF1bHQiLCJleHBvcnRzIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQXBwLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBSb290IGNvbXBvbmVudCDigJQgaW1tZWRpYXRlbHkucnVuIHJlbmRlcnMgdGhlIGRlZmF1bHQgZXhwb3J0IG9mIFRISVMgZmlsZS5cbi8vIEdsb2JhbCBDU1MgaXMgaW1wb3J0ZWQgaGVyZSAobm90IG1haW4udHN4KS4gVGhlIHNoaXBwZWQgYXBwIGlzIG5vdyBhc3NlbWJsZWRcbi8vIGVudGlyZWx5IGZyb20gdGhlIGhlYWRsZXNzIGxpYnJhcnkgKyBpdHMgU0RLIGFkYXB0ZXIgKGA8U2RrRmlsZUV4cGxvcmVyLz5gKSDigJRcbi8vIHRoZSBwYXJpdHkgcHJvb2YgZm9yIHRoZSBmaWxlLWV4cGxvcmVyLWxpYnJhcnkgZXh0cmFjdGlvbi5cbmltcG9ydCBcIi4vaW5kZXguY3NzXCI7XG5pbXBvcnQgXCIuL2xpYi11aS9zdHlsZXMuY3NzXCI7XG5pbXBvcnQgU2RrRmlsZUV4cGxvcmVyIGZyb20gXCIuL2xpYi11aS9zZGtcIjtcbmltcG9ydCB7IHVzZUhvc3RUaGVtZUF0dHJpYnV0ZSB9IGZyb20gXCIuL2hvb2tzL3VzZUhvc3RUaGVtZUF0dHJpYnV0ZVwiO1xuXG5mdW5jdGlvbiBBcHAoKSB7XG4gIC8vIFIzLTgyNyDigJQgZHJpdmUgYGh0bWxbZGF0YS10aGVtZV1gIGZyb20gdGhlIGhvc3QncyBwb2xhcml0eSBzbyB0aGUgbGlnaHRcbiAgLy8gcGFsZXR0ZSAoaW5kZXguY3NzKSBhY3R1YWxseSBhcHBsaWVzIHdoZW4gdGhlIGhvc3QgZ29lcyBsaWdodC5cbiAgdXNlSG9zdFRoZW1lQXR0cmlidXRlKCk7XG4gIHJldHVybiA8U2RrRmlsZUV4cGxvcmVyIC8+O1xufVxuXG5leHBvcnQgZGVmYXVsdCBBcHA7XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUlBQSxPQUFBO0FBQ0FBLE9BQUE7QUFDQSxJQUFBQyxJQUFBLEdBQUFDLHNCQUFBLENBQUFGLE9BQUE7QUFDQSxJQUFBRyxzQkFBQSxHQUFBSCxPQUFBO0FBQXNFLElBQUFJLFdBQUEsR0FBQUosT0FBQTtBQUFBLElBQUFLLEVBQUEsR0FBQUMsWUFBQSxJQVB0RTtBQUNBO0FBQ0E7QUFDQTtBQUFBLFNBQUFKLHVCQUFBSyxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBTUEsU0FBU0csR0FBR0EsQ0FBQSxFQUFHO0VBQUFMLEVBQUE7RUFDYjtFQUNBO0VBQ0EsSUFBQU0sNENBQXFCLEVBQUMsQ0FBQztFQUN2QixvQkFBTyxJQUFBUCxXQUFBLENBQUFRLEdBQUEsRUFBQ1gsSUFBQSxDQUFBUSxPQUFlLElBQUUsQ0FBQztBQUM1QjtBQUFDSixFQUFBLENBTFFLLEdBQUc7RUFBQSxRQUdWQyw0Q0FBcUI7QUFBQTtBQUFBRSxFQUFBLEdBSGRILEdBQUc7QUFBQSxJQUFBSSxRQUFBLEdBQUFDLE9BQUEsQ0FBQU4sT0FBQSxHQU9HQyxHQUFHO0FBQUEsSUFBQUcsRUFBQTtBQUFBRyxZQUFBLENBQUFILEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}