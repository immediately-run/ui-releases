var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.drop.js");
require("core-js/modules/esnext.iterator.filter.js");
var _react = require("@testing-library/react");
var _userEvent = _interopRequireDefault(require("@testing-library/user-event"));
var _vitest = require("vitest");
var _FileExplorerView = _interopRequireDefault(require("./FileExplorerView"));
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// Headless-view contract (Phase 02 §D): exercises `FileExplorerView` with a FAKE
// `FsSource` and SPY `actions` and NO SDK mock at all. This proves the view is
// fully decoupled from the host SDK — a non-SDK consumer (file-commander) drives
// it exactly this way.

// A two-level fixture tree the fake FsSource resolves from. Mutable: a write
// test can land its file in the tree before the action resolves, exactly as a
// real write lands it in the real fs, before the authority answers.
const TREE = {
  "/mnt/abc": [{
    name: "src",
    isDir: true
  }, {
    name: "README.md",
    isDir: false
  }],
  "/mnt/abc/src": [{
    name: "index.ts",
    isDir: false
  }, {
    name: "util.ts",
    isDir: false
  }],
  "/spaces/s1": [{
    name: "docs",
    isDir: true
  }, {
    name: "note.md",
    isDir: false
  }],
  "/spaces/s1/docs": [{
    name: "a.md",
    isDir: false
  }]
};
const readdir = _vitest.vi.fn(path => Promise.resolve(TREE[path] ?? []));
const fakeFs = {
  readdir,
  readFile: () => Promise.resolve(new Uint8Array([1, 2, 3]))
};
const SRC_ENTRIES = [{
  name: "index.ts",
  isDir: false
}, {
  name: "util.ts",
  isDir: false
}];
const worktree = {
  id: "repo",
  path: "/mnt/abc",
  label: "repo",
  kind: "worktree",
  writable: true,
  scopes: [{
    subtree: "/",
    mode: "rw"
  }],
  ejectable: false
};

// A read-only space mount — the §2 "affordances hidden on read-only scopes"
// case for the upload button's destination fallback.
const roSpace = {
  id: "space:s1",
  path: "/spaces/s1",
  label: "s1",
  kind: "space",
  writable: false,
  scopes: [{
    subtree: "/",
    mode: "ro"
  }],
  ejectable: false
};
(0, _vitest.beforeEach)(() => {
  readdir.mockClear();
  TREE["/mnt/abc/src"] = [...SRC_ENTRIES];
});
(0, _vitest.afterEach)(() => _vitest.vi.clearAllMocks());
(0, _vitest.describe)("FileExplorerView (headless, no SDK)", () => {
  (0, _vitest.it)("renders a scope per root and lazily reads a directory via fs.readdir on expand", async () => {
    const user = _userEvent.default.setup();
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_FileExplorerView.default, {
      roots: [worktree],
      fs: fakeFs
    }));

    // Root is open by default → its tree was read.
    (0, _vitest.expect)(await _react.screen.findByRole("tree", {
      name: "repo"
    })).toBeInTheDocument();
    await _react.screen.findByText("src");
    (0, _vitest.expect)(readdir).toHaveBeenCalledWith("/mnt/abc");

    // Expanding a subdirectory reads it through the injected fs.
    await user.click(_react.screen.getByText("src"));
    await _react.screen.findByText("index.ts");
    (0, _vitest.expect)(readdir).toHaveBeenCalledWith("/mnt/abc/src");
  });
  (0, _vitest.it)("R3-268: the viewed-document marker renders on its row, coexists with active, and never selects", async () => {
    const {
      rerender
    } = (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_FileExplorerView.default, {
      roots: [worktree],
      fs: fakeFs,
      activePath: "/README.md",
      viewedPath: "/README.md"
    }));
    // Both states on ONE row: active (aria-current) + the "on stage" marker.
    const marker = await _react.screen.findByLabelText("Shown in the running app");
    (0, _vitest.expect)(marker).toBeInTheDocument();
    const row = _react.screen.getByText("README.md").closest(".tnode");
    (0, _vitest.expect)(row.className).toContain("tnode--active");
    (0, _vitest.expect)(row.className).toContain("tnode--viewed");
    // Highlight-only: the marker confers no selection.
    (0, _vitest.expect)(row.className).not.toContain("tnode--selected");
    // The hint moving is just a marker move — the active row is untouched.
    rerender(/*#__PURE__*/(0, _jsxRuntime.jsx)(_FileExplorerView.default, {
      roots: [worktree],
      fs: fakeFs,
      activePath: "/README.md",
      viewedPath: null
    }));
    (0, _vitest.expect)(_react.screen.queryByLabelText("Shown in the running app")).toBeNull();
    (0, _vitest.expect)(row.className).toContain("tnode--active");
  });
  (0, _vitest.it)("activating a file calls actions.open with the mount-relative path + onActivate/onSelect", async () => {
    const user = _userEvent.default.setup();
    const open = _vitest.vi.fn();
    const onActivate = _vitest.vi.fn();
    const onSelect = _vitest.vi.fn();
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_FileExplorerView.default, {
      roots: [worktree],
      fs: fakeFs,
      actions: {
        open
      },
      onActivate: onActivate,
      onSelect: onSelect
    }));
    await _react.screen.findByText("src");
    await user.click(_react.screen.getByText("src"));
    await user.click(await _react.screen.findByText("index.ts"));
    (0, _vitest.expect)(open).toHaveBeenCalledWith(worktree, "/src/index.ts");
    (0, _vitest.expect)(onActivate).toHaveBeenCalledWith(worktree, "/src/index.ts", false);
    (0, _vitest.expect)(onSelect).toHaveBeenCalledWith(worktree, "/src/index.ts");
    // The clicked row is marked selected.
    (0, _vitest.expect)(_react.screen.getByRole("treeitem", {
      name: "index.ts"
    })).toHaveAttribute("aria-selected", "true");
  });
  (0, _vitest.it)("an absent action hides its affordance — no delete button when actions.delete is missing", async () => {
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_FileExplorerView.default, {
      roots: [worktree],
      fs: fakeFs,
      actions: {
        open: _vitest.vi.fn()
      }
    }));
    await _react.screen.findByText("README.md");
    // delete is NOT provided → no per-row delete button, even on a writable root.
    (0, _vitest.expect)(_react.screen.queryByLabelText(/^Delete /)).not.toBeInTheDocument();
    // upload is NOT provided either → no §5 upload button, even on a writable
    // root (the library's missing-action contract; review round 3's pin).
    (0, _vitest.expect)(_react.screen.queryByRole("button", {
      name: /^Upload files to/
    })).not.toBeInTheDocument();
    // …and the context menu offers no Delete / write items, only Open.
    _react.fireEvent.contextMenu(_react.screen.getByText("README.md"));
    const menu = await _react.screen.findByRole("menu");
    (0, _vitest.expect)((0, _react.within)(menu).getByRole("menuitem", {
      name: /Open/
    })).toBeInTheDocument();
    (0, _vitest.expect)((0, _react.within)(menu).queryByRole("menuitem", {
      name: /Delete/
    })).not.toBeInTheDocument();
    (0, _vitest.expect)((0, _react.within)(menu).queryByRole("menuitem", {
      name: /New file here/
    })).not.toBeInTheDocument();
  });
  (0, _vitest.it)("a provided action shows its affordance — Delete from the row's menu confirms then deletes, and the row disappears optimistically", async () => {
    // The action IS the write: it lands the delete in the fixture tree, exactly
    // as the host's delete lands it in the real fs, before resolving.
    const del = _vitest.vi.fn(() => {
      TREE["/mnt/abc/src"] = TREE["/mnt/abc/src"].filter(e => e.name !== "index.ts");
      return Promise.resolve("/src/index.ts");
    });
    const user = _userEvent.default.setup();
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_FileExplorerView.default, {
      roots: [worktree],
      fs: fakeFs,
      actions: {
        delete: del
      }
    }));
    await _react.screen.findByText("src");
    await user.click(_react.screen.getByText("src"));
    await _react.screen.findByText("index.ts");
    const confirm = _vitest.vi.spyOn(window, "confirm").mockReturnValue(true);
    _react.fireEvent.contextMenu(_react.screen.getByText("index.ts"));
    const menu = await _react.screen.findByRole("menu");
    await user.click((0, _react.within)(menu).getByRole("menuitem", {
      name: /^Delete/
    }));
    (0, _vitest.expect)(del).toHaveBeenCalledWith(worktree, "/src/index.ts");
    confirm.mockRestore();
    // The collection shows the change immediately (R-IX-3): the row is gone
    // before any refetch is granted a say.
    await _vitest.vi.waitFor(() => (0, _vitest.expect)(_react.screen.queryByRole("treeitem", {
      name: "index.ts"
    })).toBeNull());
  });
  (0, _vitest.it)("cancelling the delete confirm removes nothing and leaves the row in place", async () => {
    const del = _vitest.vi.fn(() => Promise.resolve("/src/index.ts"));
    const user = _userEvent.default.setup();
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_FileExplorerView.default, {
      roots: [worktree],
      fs: fakeFs,
      actions: {
        delete: del
      }
    }));
    await _react.screen.findByText("src");
    await user.click(_react.screen.getByText("src"));
    await _react.screen.findByText("index.ts");
    const confirm = _vitest.vi.spyOn(window, "confirm").mockReturnValue(false);
    _react.fireEvent.contextMenu(_react.screen.getByText("index.ts"));
    const menu = await _react.screen.findByRole("menu");
    await user.click((0, _react.within)(menu).getByRole("menuitem", {
      name: /^Delete/
    }));
    (0, _vitest.expect)(del).not.toHaveBeenCalled();
    (0, _vitest.expect)(_react.screen.getByRole("treeitem", {
      name: "index.ts"
    })).toBeInTheDocument();
    confirm.mockRestore();
  });
  (0, _vitest.it)("extraMenuItems are appended to the row context menu", async () => {
    const onSummarize = _vitest.vi.fn();
    const extraMenuItems = _vitest.vi.fn(() => [{
      key: "summarize",
      label: "Summarize…",
      onSelect: onSummarize
    }]);
    const user = _userEvent.default.setup();
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_FileExplorerView.default, {
      roots: [worktree],
      fs: fakeFs,
      actions: {
        open: _vitest.vi.fn()
      },
      extraMenuItems: extraMenuItems
    }));
    await _react.screen.findByText("README.md");
    _react.fireEvent.contextMenu(_react.screen.getByText("README.md"));
    const menu = await _react.screen.findByRole("menu");
    const item = (0, _react.within)(menu).getByRole("menuitem", {
      name: /Summarize/
    });
    (0, _vitest.expect)(item).toBeInTheDocument();
    await user.click(item);
    (0, _vitest.expect)(onSummarize).toHaveBeenCalled();
  });
  (0, _vitest.it)("renders the empty state when there are no roots", () => {
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_FileExplorerView.default, {
      roots: [],
      fs: fakeFs
    }));
    (0, _vitest.expect)(_react.screen.getByRole("heading", {
      name: /No files to show yet/i
    })).toBeInTheDocument();
  });
  (0, _vitest.it)("fires onNavigate with (root, relPath) when the list layout browses into a directory", async () => {
    const user = _userEvent.default.setup();
    const onNavigate = _vitest.vi.fn();
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_FileExplorerView.default, {
      roots: [worktree],
      fs: fakeFs,
      layout: "list",
      onNavigate: onNavigate
    }));
    // The list starts at the roots-root (the single root shown as a row). Enter it…
    await user.click(await _react.screen.findByText("repo"));
    // …then into `src`. onNavigate reports the destination directory per navigation.
    await user.click(await _react.screen.findByText("src"));
    (0, _vitest.expect)(onNavigate).toHaveBeenCalledWith(worktree, _vitest.expect.stringMatching(/(^|\/)src$/));
    // Always the owning root, never a foreign one.
    for (const call of onNavigate.mock.calls) (0, _vitest.expect)(call[0]).toBe(worktree);
  });
  (0, _vitest.it)("controlled cwd: renders the prop's directory; navigating fires onNavigate but does NOT change what's shown until the prop updates", async () => {
    const user = _userEvent.default.setup();
    const onNavigate = _vitest.vi.fn();
    const {
      rerender
    } = (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_FileExplorerView.default, {
      roots: [worktree],
      fs: fakeFs,
      layout: "list",
      cwd: "/mnt/abc",
      onNavigate: onNavigate
    }));
    // The controlled cwd (`/mnt/abc`) is shown — its entries, not the roots-root.
    (0, _vitest.expect)(await _react.screen.findByText("src")).toBeInTheDocument();
    (0, _vitest.expect)(_react.screen.getByText("README.md")).toBeInTheDocument();

    // Navigating into `src` reports via onNavigate but the view stays put (the
    // consumer owns cwd) — `src`'s children are NOT shown yet.
    await user.click(_react.screen.getByText("src"));
    (0, _vitest.expect)(onNavigate).toHaveBeenCalledWith(worktree, _vitest.expect.stringMatching(/(^|\/)src$/));
    (0, _vitest.expect)(_react.screen.queryByText("index.ts")).not.toBeInTheDocument();
    (0, _vitest.expect)(_react.screen.getByText("README.md")).toBeInTheDocument();

    // Feeding the new cwd prop back in shows that directory.
    rerender(/*#__PURE__*/(0, _jsxRuntime.jsx)(_FileExplorerView.default, {
      roots: [worktree],
      fs: fakeFs,
      layout: "list",
      cwd: "/mnt/abc/src",
      onNavigate: onNavigate
    }));
    (0, _vitest.expect)(await _react.screen.findByText("index.ts")).toBeInTheDocument();
    (0, _vitest.expect)(_react.screen.getByText("util.ts")).toBeInTheDocument();
    (0, _vitest.expect)(_react.screen.queryByText("README.md")).not.toBeInTheDocument();
  });
  (0, _vitest.it)("multi-select: clicking two files reports a 2-element set; clicking one again toggles it off; rows show selected styling", async () => {
    const user = _userEvent.default.setup();
    const onSelectionChange = _vitest.vi.fn();
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_FileExplorerView.default, {
      roots: [worktree],
      fs: fakeFs,
      layout: "list",
      cwd: "/mnt/abc/src",
      selectionMode: "multi",
      onSelectionChange: onSelectionChange
    }));
    const indexRow = (await _react.screen.findByText("index.ts")).closest('[role="option"]');
    const utilRow = _react.screen.getByText("util.ts").closest('[role="option"]');

    // Click two files → the set grows to two (mount-relative paths, owning root).
    await user.click(indexRow);
    (0, _vitest.expect)(onSelectionChange).toHaveBeenLastCalledWith(worktree, ["/src/index.ts"]);
    await user.click(utilRow);
    (0, _vitest.expect)(onSelectionChange).toHaveBeenLastCalledWith(worktree, _vitest.expect.arrayContaining(["/src/index.ts", "/src/util.ts"]));
    (0, _vitest.expect)(onSelectionChange.mock.calls.at(-1)[1]).toHaveLength(2);
    // Both marked rows carry the selected styling.
    (0, _vitest.expect)(indexRow).toHaveClass("lrow--selected");
    (0, _vitest.expect)(utilRow).toHaveClass("lrow--selected");

    // Clicking `index.ts` again toggles it OFF → back to a 1-element set.
    await user.click(indexRow);
    (0, _vitest.expect)(onSelectionChange).toHaveBeenLastCalledWith(worktree, ["/src/util.ts"]);
    (0, _vitest.expect)(indexRow).not.toHaveClass("lrow--selected");
    (0, _vitest.expect)(utilRow).toHaveClass("lrow--selected");
  });
  (0, _vitest.it)("the inline rename prompt is labelled with operation + target, and Escape cancels back to the triggering row without committing", async () => {
    const user = _userEvent.default.setup();
    const rename = _vitest.vi.fn(() => Promise.resolve());
    const createFile = _vitest.vi.fn(() => Promise.resolve());
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_FileExplorerView.default, {
      roots: [worktree],
      fs: fakeFs,
      actions: {
        rename,
        createFile
      }
    }));
    await _react.screen.findByText("src");
    await user.click(_react.screen.getByText("src"));
    await _react.screen.findByText("index.ts");

    // Rename… on index.ts → a labelled input (not placeholder-only naming).
    const row = _react.screen.getByText("index.ts").closest("div.tnode");
    _react.fireEvent.contextMenu(_react.screen.getByText("index.ts"));
    const menu = await _react.screen.findByRole("menu");
    await user.click((0, _react.within)(menu).getByRole("menuitem", {
      name: /Rename/
    }));
    const input = _react.screen.getByRole("textbox", {
      name: "Rename index.ts"
    });
    (0, _vitest.expect)(input).toHaveFocus();
    await user.type(input, "x");
    await user.keyboard("{Escape}");
    (0, _vitest.expect)(_react.screen.queryByRole("textbox")).toBeNull();
    (0, _vitest.expect)(rename).not.toHaveBeenCalled(); // a cancel is not a blur-commit
    (0, _vitest.expect)(row).toHaveFocus(); // focus returns to the row that opened it

    // The create prompt names its operation and directory the same way.
    _react.fireEvent.contextMenu(_react.screen.getByText("index.ts"));
    const menu2 = await _react.screen.findByRole("menu");
    await user.click((0, _react.within)(menu2).getByRole("menuitem", {
      name: /New file here/
    }));
    (0, _vitest.expect)(_react.screen.getByRole("textbox", {
      name: "New file in /src"
    })).toBeInTheDocument();
  });
  (0, _vitest.it)("the transient error banner is dismissed by a focusable Dismiss button", async () => {
    const user = _userEvent.default.setup();
    const rename = _vitest.vi.fn(() => Promise.resolve({
      name: "x",
      isDir: false
    }));
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_FileExplorerView.default, {
      roots: [worktree],
      fs: fakeFs,
      actions: {
        rename
      }
    }));
    await _react.screen.findByText("src");
    // A cross-root drop is rejected with the banner (the easiest headless path).
    const srcRow = _react.screen.getByText("src").closest("div.tnode");
    _react.fireEvent.drop(srcRow, {
      dataTransfer: {
        types: ["application/x-ir-file-move"],
        files: [],
        getData: t => t === "application/x-ir-file-move" ? JSON.stringify({
          from: "/spaces/s1/x.md",
          rootPath: "/spaces/s1",
          isDir: false
        }) : "",
        setData: () => {},
        dropEffect: "",
        effectAllowed: ""
      }
    });
    const banner = await _react.screen.findByRole("alert");
    (0, _vitest.expect)(banner).toHaveTextContent(/spaces/i);
    await user.click((0, _react.within)(banner).getByRole("button", {
      name: "Dismiss"
    }));
    (0, _vitest.expect)(_react.screen.queryByRole("alert")).toBeNull();
  });
});

// --- R-IX-3 / R-IX-4: a write renders its own result ---------------------------
(0, _vitest.describe)("FileExplorerView write path (optimistic rows, narrow refetch)", () => {
  async function renderSrcExpanded(ui) {
    const user = _userEvent.default.setup();
    const utils = (0, _react.render)(ui);
    await _react.screen.findByText("src");
    await user.click(_react.screen.getByText("src"));
    await _react.screen.findByText("index.ts");
    return {
      user,
      ...utils
    };
  }
  (0, _vitest.it)("a create renders its row immediately, pending, at final position; the return settles it; only the changed directory is refetched", async () => {
    let resolveCreate;
    const createFile = _vitest.vi.fn(() => new Promise(res => resolveCreate = res));
    const {
      user
    } = await renderSrcExpanded(/*#__PURE__*/(0, _jsxRuntime.jsx)(_FileExplorerView.default, {
      roots: [worktree],
      fs: fakeFs,
      actions: {
        createFile
      }
    }));
    const callsBefore = readdir.mock.calls.length;
    _react.fireEvent.contextMenu(_react.screen.getByText("index.ts"));
    const menu = await _react.screen.findByRole("menu");
    await user.click((0, _react.within)(menu).getByRole("menuitem", {
      name: /New file here/
    }));
    await user.type(_react.screen.getByRole("textbox", {
      name: "New file in /src"
    }), "aaa.ts{Enter}");

    // PENDING — the row is there between dispatch and settle, at its final
    // position (folders first, then names: aaa.ts < index.ts).
    const pending = _react.screen.getByRole("treeitem", {
      name: "aaa.ts"
    });
    (0, _vitest.expect)(pending).toHaveClass("tnode--pending");
    (0, _vitest.expect)(pending).toHaveAttribute("aria-busy", "true");
    (0, _vitest.expect)(pending.compareDocumentPosition(_react.screen.getByText("index.ts")) & Node.DOCUMENT_POSITION_FOLLOWING).toBeTruthy();
    (0, _vitest.expect)(_react.screen.getByRole("status")).toHaveTextContent("Creating aaa.ts…");
    (0, _vitest.expect)(createFile).toHaveBeenCalledWith(worktree, "/src/aaa.ts");

    // The write lands, then the return settles the row — no read yet.
    TREE["/mnt/abc/src"] = [{
      name: "aaa.ts",
      isDir: false
    }, ...SRC_ENTRIES];
    await (0, _react.act)(async () => resolveCreate({
      name: "aaa.ts",
      isDir: false
    }));
    const settled = await _react.screen.findByRole("treeitem", {
      name: "aaa.ts"
    });
    (0, _vitest.expect)(settled).not.toHaveClass("tnode--pending");
    (0, _vitest.expect)(settled).not.toHaveAttribute("aria-busy");
    (0, _vitest.expect)(_react.screen.getByRole("status")).toHaveTextContent("Created aaa.ts.");

    // The post-write authority refetch is NARROW: one call, for /mnt/abc/src —
    // never `refresh()`'s every-open-directory sweep (/mnt/abc is open too).
    await (0, _react.act)(async () => {});
    (0, _vitest.expect)(readdir.mock.calls.length).toBe(callsBefore + 1);
    (0, _vitest.expect)(readdir.mock.calls.at(-1)).toEqual(["/mnt/abc/src"]);
  });
  (0, _vitest.it)("a failed create restores the previous state and names the reason in text + announcement", async () => {
    let rejectCreate;
    const createFile = _vitest.vi.fn(() => new Promise((_, rej) => rejectCreate = rej));
    const {
      user
    } = await renderSrcExpanded(/*#__PURE__*/(0, _jsxRuntime.jsx)(_FileExplorerView.default, {
      roots: [worktree],
      fs: fakeFs,
      actions: {
        createFile
      }
    }));
    _react.fireEvent.contextMenu(_react.screen.getByText("index.ts"));
    const menu = await _react.screen.findByRole("menu");
    await user.click((0, _react.within)(menu).getByRole("menuitem", {
      name: /New file here/
    }));
    await user.type(_react.screen.getByRole("textbox", {
      name: "New file in /src"
    }), "zzz.ts{Enter}");
    (0, _vitest.expect)(_react.screen.getByRole("treeitem", {
      name: "zzz.ts"
    })).toBeInTheDocument();
    await (0, _react.act)(async () => rejectCreate(Object.assign(new Error("exists"), {
      code: "exists"
    })));
    // Restored: the row is gone, the reason is in the banner AND the region.
    await _vitest.vi.waitFor(() => (0, _vitest.expect)(_react.screen.queryByRole("treeitem", {
      name: "zzz.ts"
    })).toBeNull());
    (0, _vitest.expect)(_react.screen.getByRole("alert")).toHaveTextContent("Something with that name already exists.");
    (0, _vitest.expect)(_react.screen.getByRole("status")).toHaveTextContent(/Couldn’t create zzz\.ts/);
  });
  (0, _vitest.it)("a move via the 'Move to…' picker commits through the SAME action the drag takes", async () => {
    const rename = _vitest.vi.fn(() => Promise.resolve({
      name: "README.md",
      isDir: false
    }));

    // The drag path: drop README.md onto the src directory row.
    {
      const user = _userEvent.default.setup();
      const {
        unmount
      } = (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_FileExplorerView.default, {
        roots: [worktree],
        fs: fakeFs,
        actions: {
          rename
        }
      }));
      await _react.screen.findByText("src");
      await user.click(_react.screen.getByText("src"));
      await _react.screen.findByText("index.ts");
      const move = {
        from: "/mnt/abc/README.md",
        rootPath: "/mnt/abc",
        isDir: false
      };
      _react.fireEvent.drop(_react.screen.getByText("src").closest("div.tnode"), {
        dataTransfer: {
          types: ["application/x-ir-file-move"],
          files: [],
          getData: t => t === "application/x-ir-file-move" ? JSON.stringify(move) : "",
          setData: () => {},
          dropEffect: "",
          effectAllowed: ""
        }
      });
      (0, _vitest.expect)(rename).toHaveBeenCalledWith(worktree, "/README.md", "/src/README.md", false);
      unmount();
    }
    rename.mockClear();

    // The picker path, from a clean render: Move to… → choose src → Move here.
    {
      const user = _userEvent.default.setup();
      (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_FileExplorerView.default, {
        roots: [worktree],
        fs: fakeFs,
        actions: {
          rename
        }
      }));
      await _react.screen.findByText("src");
      _react.fireEvent.contextMenu(_react.screen.getByText("README.md"));
      const menu = await _react.screen.findByRole("menu");
      await user.click((0, _react.within)(menu).getByRole("menuitem", {
        name: /Move to/
      }));
      const dialog = await _react.screen.findByRole("dialog", {
        name: "Move README.md to a folder"
      });
      await user.click((0, _react.within)(dialog).getByRole("treeitem", {
        name: "src"
      }));
      await user.click((0, _react.within)(dialog).getByRole("button", {
        name: "Move here"
      }));

      // One action, two triggers — identical arguments.
      (0, _vitest.expect)(rename).toHaveBeenCalledWith(worktree, "/README.md", "/src/README.md", false);
      (0, _vitest.expect)(_react.screen.getByRole("status")).toHaveTextContent(/Moved README\.md to \/src/);
    }
  });
});

// --- APG Tree View: one tab stop, roving arrows, the row is the treeitem -------
(0, _vitest.describe)("FileExplorerView tree keyboard (APG)", () => {
  (0, _vitest.it)("exactly one tab stop; the focusable row itself is the treeitem carrying the filename (4.1.2)", async () => {
    const user = _userEvent.default.setup();
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_FileExplorerView.default, {
      roots: [worktree],
      fs: fakeFs
    }));
    await _react.screen.findByText("src");
    await user.click(_react.screen.getByText("src"));
    await _react.screen.findByText("util.ts");
    const items = _react.screen.getAllByRole("treeitem");
    (0, _vitest.expect)(items.length).toBeGreaterThan(1);
    (0, _vitest.expect)(items.filter(el => el.tabIndex === 0)).toHaveLength(1);
    const row = _react.screen.getByRole("treeitem", {
      name: "index.ts"
    });
    (0, _vitest.expect)(row).toHaveClass("tnode"); // the role is on the FOCUSABLE row element
    (0, _vitest.expect)(row.tabIndex).toBe(-1); // …and only the stop is tabbable
  });
  (0, _vitest.it)("Down/Home/End move focus across the visible rows", async () => {
    const user = _userEvent.default.setup();
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_FileExplorerView.default, {
      roots: [worktree],
      fs: fakeFs
    }));
    await _react.screen.findByText("src");
    await user.click(_react.screen.getByText("src"));
    await _react.screen.findByText("util.ts");
    _react.screen.getByRole("treeitem", {
      name: "repo"
    }).focus();
    await user.keyboard("{ArrowDown}");
    (0, _vitest.expect)(_react.screen.getByRole("treeitem", {
      name: "src"
    })).toHaveFocus();
    await user.keyboard("{ArrowDown}");
    (0, _vitest.expect)(_react.screen.getByRole("treeitem", {
      name: "index.ts"
    })).toHaveFocus();
    await user.keyboard("{Home}");
    (0, _vitest.expect)(_react.screen.getByRole("treeitem", {
      name: "repo"
    })).toHaveFocus();
    await user.keyboard("{End}");
    // Visible order is repo, src, index.ts, util.ts, README.md (folders first).
    (0, _vitest.expect)(_react.screen.getByRole("treeitem", {
      name: "README.md"
    })).toHaveFocus();
  });
  (0, _vitest.it)("the tab stop follows the focused row", async () => {
    const user = _userEvent.default.setup();
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_FileExplorerView.default, {
      roots: [worktree],
      fs: fakeFs
    }));
    await _react.screen.findByText("src");
    await user.click(_react.screen.getByText("src"));
    await _react.screen.findByText("util.ts");
    const util = _react.screen.getByRole("treeitem", {
      name: "util.ts"
    });
    await user.click(util);
    (0, _vitest.expect)(util.tabIndex).toBe(0);
    (0, _vitest.expect)(_react.screen.getAllByRole("treeitem").filter(el => el.tabIndex === 0)).toEqual([util]);
  });
});

// --- uploads: the batch write announces both halves and refetches narrowly ------
(0, _vitest.describe)("FileExplorerView upload path", () => {
  (0, _vitest.it)("announces Uploading…/Uploaded and refetches only the target directory", async () => {
    const callsBeforeBase = readdir.mock.calls.length;
    let resolveUpload;
    const upload = _vitest.vi.fn(() => new Promise(res => resolveUpload = res));
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_FileExplorerView.default, {
      roots: [worktree],
      fs: fakeFs,
      actions: {
        upload
      }
    }));
    await _react.screen.findByText("src");
    const callsBefore = readdir.mock.calls.length;
    const file = new File(["hello"], "note.txt", {
      type: "text/plain"
    });
    _react.fireEvent.drop(_react.screen.getByText("src").closest("div.tnode"), {
      dataTransfer: {
        types: ["Files"],
        files: [file],
        getData: () => "",
        setData: () => {},
        dropEffect: "",
        effectAllowed: ""
      }
    });
    (0, _vitest.expect)(upload).toHaveBeenCalledWith(worktree, "/src", [file]);
    (0, _vitest.expect)(_react.screen.getByRole("status")).toHaveTextContent("Uploading 1 file…");
    (0, _vitest.expect)(readdir.mock.calls.length).toBe(callsBefore); // no refetch before settle

    TREE["/mnt/abc/src"] = [...SRC_ENTRIES, {
      name: "note.txt",
      isDir: false
    }];
    await (0, _react.act)(async () => resolveUpload());
    (0, _vitest.expect)(_react.screen.getByRole("status")).toHaveTextContent("Uploaded 1 file.");
    await (0, _react.act)(async () => {});
    (0, _vitest.expect)(readdir.mock.calls.length).toBe(callsBefore + 1);
    (0, _vitest.expect)(readdir.mock.calls.at(-1)).toEqual(["/mnt/abc/src"]);
    (0, _vitest.expect)(callsBefore > callsBeforeBase).toBe(true); // the reads above were real
  });
  (0, _vitest.it)("a failed upload names the reason in banner + announcement, no refetch", async () => {
    let rejectUpload;
    const upload = _vitest.vi.fn(() => new Promise((_, rej) => rejectUpload = rej));
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_FileExplorerView.default, {
      roots: [worktree],
      fs: fakeFs,
      actions: {
        upload
      }
    }));
    await _react.screen.findByText("src");
    const callsBefore = readdir.mock.calls.length;
    _react.fireEvent.drop(_react.screen.getByText("src").closest("div.tnode"), {
      dataTransfer: {
        types: ["Files"],
        files: [new File(["hello"], "big.bin", {
          type: "text/plain"
        })],
        getData: () => "",
        setData: () => {},
        dropEffect: "",
        effectAllowed: ""
      }
    });
    await (0, _react.act)(async () => rejectUpload(Object.assign(new Error("too large"), {
      code: "too-large"
    })));
    (0, _vitest.expect)(_react.screen.getByRole("alert")).toHaveTextContent("That file is too large to upload.");
    (0, _vitest.expect)(_react.screen.getByRole("status")).toHaveTextContent(/Couldn’t upload/);
    (0, _vitest.expect)(readdir.mock.calls.length).toBe(callsBefore);
  });
});

// --- §5 upload button: the native-picker path and its destination rules ---------
(0, _vitest.describe)("FileExplorerView upload button (FILE_EXPLORER_SPEC §5)", () => {
  const picker = container => container.querySelector('input[type="file"]');
  (0, _vitest.it)("uploads to the repo root when nothing is selected", async () => {
    const upload = _vitest.vi.fn(() => Promise.resolve());
    const {
      container
    } = (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_FileExplorerView.default, {
      roots: [worktree],
      fs: fakeFs,
      actions: {
        upload
      }
    }));
    await _react.screen.findByText("README.md");
    _react.fireEvent.click(_react.screen.getByRole("button", {
      name: "Upload files to the repo root"
    }));
    const file = new File(["hello"], "note.txt", {
      type: "text/plain"
    });
    _react.fireEvent.change(picker(container), {
      target: {
        files: [file]
      }
    });
    (0, _vitest.expect)(upload).toHaveBeenCalledWith(worktree, "/", [file]);
  });
  (0, _vitest.it)("uploads into the selected directory (and the row exposes its selection)", async () => {
    const user = _userEvent.default.setup();
    const upload = _vitest.vi.fn(() => Promise.resolve());
    const {
      container
    } = (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_FileExplorerView.default, {
      roots: [worktree],
      fs: fakeFs,
      actions: {
        upload
      }
    }));
    await _react.screen.findByText("src");
    await user.click(_react.screen.getByText("src"));

    // The clicked folder is selected, and the button's label names it as the
    // destination — the rule is discoverable on the affordance itself.
    (0, _vitest.expect)(_react.screen.getByRole("treeitem", {
      name: "src"
    })).toHaveAttribute("aria-selected", "true");
    _react.fireEvent.click(_react.screen.getByRole("button", {
      name: "Upload files to /src"
    }));
    const file = new File(["hello"], "note.txt", {
      type: "text/plain"
    });
    _react.fireEvent.change(picker(container), {
      target: {
        files: [file]
      }
    });
    (0, _vitest.expect)(upload).toHaveBeenCalledWith(worktree, "/src", [file]);
  });
  (0, _vitest.it)("uploads into the selected file's parent, so it becomes a sibling", async () => {
    const user = _userEvent.default.setup();
    const upload = _vitest.vi.fn(() => Promise.resolve());
    const {
      container
    } = (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_FileExplorerView.default, {
      roots: [worktree],
      fs: fakeFs,
      actions: {
        upload
      }
    }));
    await user.click(await _react.screen.findByText("src"));
    await _react.screen.findByText("index.ts");
    await user.click(_react.screen.getByText("index.ts"));
    _react.fireEvent.click(_react.screen.getByRole("button", {
      name: "Upload files to /src"
    }));
    const file = new File(["hello"], "note.txt", {
      type: "text/plain"
    });
    _react.fireEvent.change(picker(container), {
      target: {
        files: [file]
      }
    });
    (0, _vitest.expect)(upload).toHaveBeenCalledWith(worktree, "/src", [file]);
  });
  (0, _vitest.it)("a selection inside a read-only scope falls back to the repo root", async () => {
    const user = _userEvent.default.setup();
    const upload = _vitest.vi.fn(() => Promise.resolve());
    const {
      container
    } = (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_FileExplorerView.default, {
      roots: [worktree, roSpace],
      fs: fakeFs,
      actions: {
        upload
      }
    }));
    await user.click(await _react.screen.findByText("note.md"));
    _react.fireEvent.click(_react.screen.getByRole("button", {
      name: "Upload files to the repo root"
    }));
    const file = new File(["hello"], "note.txt", {
      type: "text/plain"
    });
    _react.fireEvent.change(picker(container), {
      target: {
        files: [file]
      }
    });
    (0, _vitest.expect)(upload).toHaveBeenCalledWith(worktree, "/", [file]);
  });
  (0, _vitest.it)("hides the button when there is no writable root (no shown-then-EROFS)", async () => {
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_FileExplorerView.default, {
      roots: [roSpace],
      fs: fakeFs,
      actions: {
        upload: _vitest.vi.fn()
      }
    }));
    await _react.screen.findByText("note.md");
    (0, _vitest.expect)(_react.screen.queryByRole("button", {
      name: /^Upload files to/
    })).not.toBeInTheDocument();
  });
  (0, _vitest.it)("resolves the destination under the selection's OWN writable root, not just the first", async () => {
    // A second WRITABLE root: §5's "a directory → that directory" must hold in
    // any writable scope. The destination is relativized against the selection's
    // owning root — a blind slice against the repo root would corrupt both the
    // label and the upload path (review round 1, R1).
    const user = _userEvent.default.setup();
    const upload = _vitest.vi.fn(() => Promise.resolve());
    const rwSpace = {
      ...roSpace,
      writable: true,
      scopes: [{
        subtree: "/",
        mode: "rw"
      }]
    };
    const {
      container
    } = (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_FileExplorerView.default, {
      roots: [worktree, rwSpace],
      fs: fakeFs,
      actions: {
        upload
      }
    }));

    // A selected DIRECTORY in the space uploads into that dir under the space.
    await user.click(await _react.screen.findByText("docs"));
    _react.fireEvent.click(_react.screen.getByRole("button", {
      name: "Upload files to /docs"
    }));
    const file = new File(["hello"], "n.txt", {
      type: "text/plain"
    });
    _react.fireEvent.change(picker(container), {
      target: {
        files: [file]
      }
    });
    (0, _vitest.expect)(upload).toHaveBeenCalledWith(rwSpace, "/docs", [file]);

    // A selected FILE at the space's top level uploads next to it — the space's
    // own root, named honestly (not "the repo root").
    await user.click(await _react.screen.findByText("note.md"));
    _react.fireEvent.click(_react.screen.getByRole("button", {
      name: "Upload files to the s1 root"
    }));
    _react.fireEvent.change(picker(container), {
      target: {
        files: [file]
      }
    });
    (0, _vitest.expect)(upload).toHaveBeenLastCalledWith(rwSpace, "/", [file]);
  });
  (0, _vitest.it)("selectionMode=\"none\" navigation writes no selection — the destination stays the repo root", async () => {
    // Review round 2, R1: the tree's activation path gates selection on
    // `selectionMode !== "none"`; flat-layout navigation must not be the leak.
    const user = _userEvent.default.setup();
    const upload = _vitest.vi.fn(() => Promise.resolve());
    const {
      container
    } = (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_FileExplorerView.default, {
      roots: [worktree],
      fs: fakeFs,
      actions: {
        upload
      },
      layout: "list",
      selectionMode: "none"
    }));
    // Enter the single mount, then browse INTO src — navigation only.
    await user.click(await _react.screen.findByRole("option", {
      name: /^repo/
    }));
    await user.click(await _react.screen.findByRole("option", {
      name: /^src/
    }));
    _react.fireEvent.click(_react.screen.getByRole("button", {
      name: "Upload files to the repo root"
    }));
    _react.fireEvent.change(picker(container), {
      target: {
        files: [new File(["hello"], "n.txt", {
          type: "text/plain"
        })]
      }
    });
    (0, _vitest.expect)(upload).toHaveBeenCalledWith(worktree, "/", [_vitest.expect.objectContaining({
      name: "n.txt"
    })]);
  });
});

// --- every layout's rows expose the menu by keyboard (ContextMenu / Shift+F10) ---
(0, _vitest.describe)("row menu key (ContextMenu / Shift+F10) reaches every layout's rows", () => {
  (0, _vitest.it)("list layout: the menu key on an option opens the row's context menu", async () => {
    const del = _vitest.vi.fn(() => Promise.resolve("/README.md"));
    const user = _userEvent.default.setup();
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_FileExplorerView.default, {
      roots: [worktree],
      fs: fakeFs,
      layout: "list",
      actions: {
        delete: del
      }
    }));
    // The uncontrolled list starts at the roots-root; enter the single mount.
    await user.click(await _react.screen.findByRole("option", {
      name: /^repo/
    }));
    const readme = await _react.screen.findByRole("option", {
      name: /README\.md/
    });
    readme.focus();
    await user.keyboard("{Shift>}{F10}{/Shift}");
    const menu = await _react.screen.findByRole("menu");
    (0, _vitest.expect)((0, _react.within)(menu).getByRole("menuitem", {
      name: /^Delete/
    })).toBeInTheDocument();
  });
  (0, _vitest.it)("tree layout: the ContextMenu key opens the row's menu at the row", async () => {
    const user = _userEvent.default.setup();
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_FileExplorerView.default, {
      roots: [worktree],
      fs: fakeFs,
      actions: {
        open: _vitest.vi.fn()
      }
    }));
    const readme = await _react.screen.findByRole("treeitem", {
      name: "README.md"
    });
    readme.focus();
    await user.keyboard("{ContextMenu}");
    const menu = await _react.screen.findByRole("menu");
    (0, _vitest.expect)((0, _react.within)(menu).getByRole("menuitem", {
      name: /Open/
    })).toBeInTheDocument();
  });
});

// --- the picker is keyboard-operable end to end (the 2.5.7 path itself) --------
(0, _vitest.describe)("MoveDialog keyboard", () => {
  (0, _vitest.it)("Tab reaches the footer buttons (Move here / Cancel) from the tree", async () => {
    const rename = _vitest.vi.fn(() => Promise.resolve({
      name: "README.md",
      isDir: false
    }));
    const user = _userEvent.default.setup();
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_FileExplorerView.default, {
      roots: [worktree],
      fs: fakeFs,
      actions: {
        rename
      }
    }));
    await _react.screen.findByText("src");
    _react.fireEvent.contextMenu(_react.screen.getByText("README.md"));
    const menu = await _react.screen.findByRole("menu");
    await user.click((0, _react.within)(menu).getByRole("menuitem", {
      name: /Move to/
    }));
    const dialog = await _react.screen.findByRole("dialog", {
      name: "Move README.md to a folder"
    });

    // Choose a destination first — "Move here" is disabled (outside the trap)
    // until something is chosen.
    await user.click((0, _react.within)(dialog).getByRole("treeitem", {
      name: "src"
    }));

    // Focus starts in the tree (the dialog's first focusable). Tab walks the
    // tree's stop, then reaches the footer buttons — the trap bounds the PANEL.
    const lastTreeStop = [...dialog.querySelectorAll('[role="treeitem"][tabindex="0"]')].pop();
    lastTreeStop.focus();
    let reached = false;
    for (let i = 0; i < 6 && !reached; i++) {
      await user.keyboard("{Tab}");
      reached = document.activeElement?.textContent === "Move here";
    }
    (0, _vitest.expect)(reached).toBe(true);
    (0, _vitest.expect)(document.activeElement).toBe((0, _react.within)(dialog).getByRole("button", {
      name: "Move here"
    }));
  });
});

// --- ArrowRight steps into an open folder's first child (APG Tree View) --------
(0, _vitest.describe)("tree ArrowRight step-in", () => {
  (0, _vitest.it)("ArrowRight on an OPEN folder focuses its first child row", async () => {
    const user = _userEvent.default.setup();
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(_FileExplorerView.default, {
      roots: [worktree],
      fs: fakeFs
    }));
    await _react.screen.findByText("src");
    await user.click(_react.screen.getByText("src"));
    await _react.screen.findByText("index.ts");
    _react.screen.getByRole("treeitem", {
      name: "src"
    }).focus();
    await user.keyboard("{ArrowRight}");
    (0, _vitest.expect)(_react.screen.getByRole("treeitem", {
      name: "index.ts"
    })).toHaveFocus();
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3VzZXJFdmVudCIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJfdml0ZXN0IiwiX0ZpbGVFeHBsb3JlclZpZXciLCJfanN4UnVudGltZSIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsIlRSRUUiLCJuYW1lIiwiaXNEaXIiLCJyZWFkZGlyIiwidmkiLCJmbiIsInBhdGgiLCJQcm9taXNlIiwicmVzb2x2ZSIsImZha2VGcyIsInJlYWRGaWxlIiwiVWludDhBcnJheSIsIlNSQ19FTlRSSUVTIiwid29ya3RyZWUiLCJpZCIsImxhYmVsIiwia2luZCIsIndyaXRhYmxlIiwic2NvcGVzIiwic3VidHJlZSIsIm1vZGUiLCJlamVjdGFibGUiLCJyb1NwYWNlIiwiYmVmb3JlRWFjaCIsIm1vY2tDbGVhciIsImFmdGVyRWFjaCIsImNsZWFyQWxsTW9ja3MiLCJkZXNjcmliZSIsIml0IiwidXNlciIsInVzZXJFdmVudCIsInNldHVwIiwicmVuZGVyIiwianN4Iiwicm9vdHMiLCJmcyIsImV4cGVjdCIsInNjcmVlbiIsImZpbmRCeVJvbGUiLCJ0b0JlSW5UaGVEb2N1bWVudCIsImZpbmRCeVRleHQiLCJ0b0hhdmVCZWVuQ2FsbGVkV2l0aCIsImNsaWNrIiwiZ2V0QnlUZXh0IiwicmVyZW5kZXIiLCJhY3RpdmVQYXRoIiwidmlld2VkUGF0aCIsIm1hcmtlciIsImZpbmRCeUxhYmVsVGV4dCIsInJvdyIsImNsb3Nlc3QiLCJjbGFzc05hbWUiLCJ0b0NvbnRhaW4iLCJub3QiLCJxdWVyeUJ5TGFiZWxUZXh0IiwidG9CZU51bGwiLCJvcGVuIiwib25BY3RpdmF0ZSIsIm9uU2VsZWN0IiwiYWN0aW9ucyIsImdldEJ5Um9sZSIsInRvSGF2ZUF0dHJpYnV0ZSIsInF1ZXJ5QnlSb2xlIiwiZmlyZUV2ZW50IiwiY29udGV4dE1lbnUiLCJtZW51Iiwid2l0aGluIiwiZGVsIiwiZmlsdGVyIiwiZGVsZXRlIiwiY29uZmlybSIsInNweU9uIiwid2luZG93IiwibW9ja1JldHVyblZhbHVlIiwibW9ja1Jlc3RvcmUiLCJ3YWl0Rm9yIiwidG9IYXZlQmVlbkNhbGxlZCIsIm9uU3VtbWFyaXplIiwiZXh0cmFNZW51SXRlbXMiLCJrZXkiLCJpdGVtIiwib25OYXZpZ2F0ZSIsImxheW91dCIsInN0cmluZ01hdGNoaW5nIiwiY2FsbCIsIm1vY2siLCJjYWxscyIsInRvQmUiLCJjd2QiLCJxdWVyeUJ5VGV4dCIsIm9uU2VsZWN0aW9uQ2hhbmdlIiwic2VsZWN0aW9uTW9kZSIsImluZGV4Um93IiwidXRpbFJvdyIsInRvSGF2ZUJlZW5MYXN0Q2FsbGVkV2l0aCIsImFycmF5Q29udGFpbmluZyIsImF0IiwidG9IYXZlTGVuZ3RoIiwidG9IYXZlQ2xhc3MiLCJyZW5hbWUiLCJjcmVhdGVGaWxlIiwiaW5wdXQiLCJ0b0hhdmVGb2N1cyIsInR5cGUiLCJrZXlib2FyZCIsIm1lbnUyIiwic3JjUm93IiwiZHJvcCIsImRhdGFUcmFuc2ZlciIsInR5cGVzIiwiZmlsZXMiLCJnZXREYXRhIiwidCIsIkpTT04iLCJzdHJpbmdpZnkiLCJmcm9tIiwicm9vdFBhdGgiLCJzZXREYXRhIiwiZHJvcEVmZmVjdCIsImVmZmVjdEFsbG93ZWQiLCJiYW5uZXIiLCJ0b0hhdmVUZXh0Q29udGVudCIsInJlbmRlclNyY0V4cGFuZGVkIiwidWkiLCJ1dGlscyIsInJlc29sdmVDcmVhdGUiLCJyZXMiLCJjYWxsc0JlZm9yZSIsImxlbmd0aCIsInBlbmRpbmciLCJjb21wYXJlRG9jdW1lbnRQb3NpdGlvbiIsIk5vZGUiLCJET0NVTUVOVF9QT1NJVElPTl9GT0xMT1dJTkciLCJ0b0JlVHJ1dGh5IiwiYWN0Iiwic2V0dGxlZCIsInRvRXF1YWwiLCJyZWplY3RDcmVhdGUiLCJfIiwicmVqIiwiT2JqZWN0IiwiYXNzaWduIiwiRXJyb3IiLCJjb2RlIiwidW5tb3VudCIsIm1vdmUiLCJkaWFsb2ciLCJpdGVtcyIsImdldEFsbEJ5Um9sZSIsInRvQmVHcmVhdGVyVGhhbiIsImVsIiwidGFiSW5kZXgiLCJmb2N1cyIsInV0aWwiLCJjYWxsc0JlZm9yZUJhc2UiLCJyZXNvbHZlVXBsb2FkIiwidXBsb2FkIiwiZmlsZSIsIkZpbGUiLCJyZWplY3RVcGxvYWQiLCJwaWNrZXIiLCJjb250YWluZXIiLCJxdWVyeVNlbGVjdG9yIiwiY2hhbmdlIiwidGFyZ2V0IiwicndTcGFjZSIsIm9iamVjdENvbnRhaW5pbmciLCJyZWFkbWUiLCJsYXN0VHJlZVN0b3AiLCJxdWVyeVNlbGVjdG9yQWxsIiwicG9wIiwicmVhY2hlZCIsImkiLCJkb2N1bWVudCIsImFjdGl2ZUVsZW1lbnQiLCJ0ZXh0Q29udGVudCJdLCJzb3VyY2VzIjpbIkZpbGVFeHBsb3JlclZpZXcudGVzdC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gSGVhZGxlc3MtdmlldyBjb250cmFjdCAoUGhhc2UgMDIgwqdEKTogZXhlcmNpc2VzIGBGaWxlRXhwbG9yZXJWaWV3YCB3aXRoIGEgRkFLRVxuLy8gYEZzU291cmNlYCBhbmQgU1BZIGBhY3Rpb25zYCBhbmQgTk8gU0RLIG1vY2sgYXQgYWxsLiBUaGlzIHByb3ZlcyB0aGUgdmlldyBpc1xuLy8gZnVsbHkgZGVjb3VwbGVkIGZyb20gdGhlIGhvc3QgU0RLIOKAlCBhIG5vbi1TREsgY29uc3VtZXIgKGZpbGUtY29tbWFuZGVyKSBkcml2ZXNcbi8vIGl0IGV4YWN0bHkgdGhpcyB3YXkuXG5pbXBvcnQgeyBhY3QsIGZpcmVFdmVudCwgcmVuZGVyLCBzY3JlZW4sIHdpdGhpbiB9IGZyb20gXCJAdGVzdGluZy1saWJyYXJ5L3JlYWN0XCI7XG5pbXBvcnQgdXNlckV2ZW50IGZyb20gXCJAdGVzdGluZy1saWJyYXJ5L3VzZXItZXZlbnRcIjtcbmltcG9ydCB0eXBlIHsgUmVhY3RFbGVtZW50IH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBhZnRlckVhY2gsIGJlZm9yZUVhY2gsIGRlc2NyaWJlLCBleHBlY3QsIGl0LCB2aSB9IGZyb20gXCJ2aXRlc3RcIjtcbmltcG9ydCBGaWxlRXhwbG9yZXJWaWV3IGZyb20gXCIuL0ZpbGVFeHBsb3JlclZpZXdcIjtcbmltcG9ydCB0eXBlIHsgRGlyRW50cnksIEV4cGxvcmVyUm9vdCwgRnNTb3VyY2UgfSBmcm9tIFwiLi90eXBlc1wiO1xuXG4vLyBBIHR3by1sZXZlbCBmaXh0dXJlIHRyZWUgdGhlIGZha2UgRnNTb3VyY2UgcmVzb2x2ZXMgZnJvbS4gTXV0YWJsZTogYSB3cml0ZVxuLy8gdGVzdCBjYW4gbGFuZCBpdHMgZmlsZSBpbiB0aGUgdHJlZSBiZWZvcmUgdGhlIGFjdGlvbiByZXNvbHZlcywgZXhhY3RseSBhcyBhXG4vLyByZWFsIHdyaXRlIGxhbmRzIGl0IGluIHRoZSByZWFsIGZzLCBiZWZvcmUgdGhlIGF1dGhvcml0eSBhbnN3ZXJzLlxuY29uc3QgVFJFRTogUmVjb3JkPHN0cmluZywgRGlyRW50cnlbXT4gPSB7XG4gIFwiL21udC9hYmNcIjogW1xuICAgIHsgbmFtZTogXCJzcmNcIiwgaXNEaXI6IHRydWUgfSxcbiAgICB7IG5hbWU6IFwiUkVBRE1FLm1kXCIsIGlzRGlyOiBmYWxzZSB9LFxuICBdLFxuICBcIi9tbnQvYWJjL3NyY1wiOiBbXG4gICAgeyBuYW1lOiBcImluZGV4LnRzXCIsIGlzRGlyOiBmYWxzZSB9LFxuICAgIHsgbmFtZTogXCJ1dGlsLnRzXCIsIGlzRGlyOiBmYWxzZSB9LFxuICBdLFxuICBcIi9zcGFjZXMvczFcIjogW1xuICAgIHsgbmFtZTogXCJkb2NzXCIsIGlzRGlyOiB0cnVlIH0sXG4gICAgeyBuYW1lOiBcIm5vdGUubWRcIiwgaXNEaXI6IGZhbHNlIH0sXG4gIF0sXG4gIFwiL3NwYWNlcy9zMS9kb2NzXCI6IFt7IG5hbWU6IFwiYS5tZFwiLCBpc0RpcjogZmFsc2UgfV0sXG59O1xuXG5jb25zdCByZWFkZGlyID0gdmkuZm4oKHBhdGg6IHN0cmluZykgPT4gUHJvbWlzZS5yZXNvbHZlKFRSRUVbcGF0aF0gPz8gW10pKTtcbmNvbnN0IGZha2VGczogRnNTb3VyY2UgPSB7XG4gIHJlYWRkaXIsXG4gIHJlYWRGaWxlOiAoKSA9PiBQcm9taXNlLnJlc29sdmUobmV3IFVpbnQ4QXJyYXkoWzEsIDIsIDNdKSksXG59O1xuXG5jb25zdCBTUkNfRU5UUklFUyA9IFtcbiAgeyBuYW1lOiBcImluZGV4LnRzXCIsIGlzRGlyOiBmYWxzZSB9LFxuICB7IG5hbWU6IFwidXRpbC50c1wiLCBpc0RpcjogZmFsc2UgfSxcbl07XG5cbmNvbnN0IHdvcmt0cmVlOiBFeHBsb3JlclJvb3QgPSB7XG4gIGlkOiBcInJlcG9cIixcbiAgcGF0aDogXCIvbW50L2FiY1wiLFxuICBsYWJlbDogXCJyZXBvXCIsXG4gIGtpbmQ6IFwid29ya3RyZWVcIixcbiAgd3JpdGFibGU6IHRydWUsXG4gIHNjb3BlczogW3sgc3VidHJlZTogXCIvXCIsIG1vZGU6IFwicndcIiB9XSxcbiAgZWplY3RhYmxlOiBmYWxzZSxcbn07XG5cbi8vIEEgcmVhZC1vbmx5IHNwYWNlIG1vdW50IOKAlCB0aGUgwqcyIFwiYWZmb3JkYW5jZXMgaGlkZGVuIG9uIHJlYWQtb25seSBzY29wZXNcIlxuLy8gY2FzZSBmb3IgdGhlIHVwbG9hZCBidXR0b24ncyBkZXN0aW5hdGlvbiBmYWxsYmFjay5cbmNvbnN0IHJvU3BhY2U6IEV4cGxvcmVyUm9vdCA9IHtcbiAgaWQ6IFwic3BhY2U6czFcIixcbiAgcGF0aDogXCIvc3BhY2VzL3MxXCIsXG4gIGxhYmVsOiBcInMxXCIsXG4gIGtpbmQ6IFwic3BhY2VcIixcbiAgd3JpdGFibGU6IGZhbHNlLFxuICBzY29wZXM6IFt7IHN1YnRyZWU6IFwiL1wiLCBtb2RlOiBcInJvXCIgfV0sXG4gIGVqZWN0YWJsZTogZmFsc2UsXG59O1xuXG5iZWZvcmVFYWNoKCgpID0+IHtcbiAgcmVhZGRpci5tb2NrQ2xlYXIoKTtcbiAgVFJFRVtcIi9tbnQvYWJjL3NyY1wiXSA9IFsuLi5TUkNfRU5UUklFU107XG59KTtcbmFmdGVyRWFjaCgoKSA9PiB2aS5jbGVhckFsbE1vY2tzKCkpO1xuXG5kZXNjcmliZShcIkZpbGVFeHBsb3JlclZpZXcgKGhlYWRsZXNzLCBubyBTREspXCIsICgpID0+IHtcbiAgaXQoXCJyZW5kZXJzIGEgc2NvcGUgcGVyIHJvb3QgYW5kIGxhemlseSByZWFkcyBhIGRpcmVjdG9yeSB2aWEgZnMucmVhZGRpciBvbiBleHBhbmRcIiwgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHVzZXIgPSB1c2VyRXZlbnQuc2V0dXAoKTtcbiAgICByZW5kZXIoPEZpbGVFeHBsb3JlclZpZXcgcm9vdHM9e1t3b3JrdHJlZV19IGZzPXtmYWtlRnN9IC8+KTtcblxuICAgIC8vIFJvb3QgaXMgb3BlbiBieSBkZWZhdWx0IOKGkiBpdHMgdHJlZSB3YXMgcmVhZC5cbiAgICBleHBlY3QoYXdhaXQgc2NyZWVuLmZpbmRCeVJvbGUoXCJ0cmVlXCIsIHsgbmFtZTogXCJyZXBvXCIgfSkpLnRvQmVJblRoZURvY3VtZW50KCk7XG4gICAgYXdhaXQgc2NyZWVuLmZpbmRCeVRleHQoXCJzcmNcIik7XG4gICAgZXhwZWN0KHJlYWRkaXIpLnRvSGF2ZUJlZW5DYWxsZWRXaXRoKFwiL21udC9hYmNcIik7XG5cbiAgICAvLyBFeHBhbmRpbmcgYSBzdWJkaXJlY3RvcnkgcmVhZHMgaXQgdGhyb3VnaCB0aGUgaW5qZWN0ZWQgZnMuXG4gICAgYXdhaXQgdXNlci5jbGljayhzY3JlZW4uZ2V0QnlUZXh0KFwic3JjXCIpKTtcbiAgICBhd2FpdCBzY3JlZW4uZmluZEJ5VGV4dChcImluZGV4LnRzXCIpO1xuICAgIGV4cGVjdChyZWFkZGlyKS50b0hhdmVCZWVuQ2FsbGVkV2l0aChcIi9tbnQvYWJjL3NyY1wiKTtcbiAgfSk7XG5cbiAgaXQoXCJSMy0yNjg6IHRoZSB2aWV3ZWQtZG9jdW1lbnQgbWFya2VyIHJlbmRlcnMgb24gaXRzIHJvdywgY29leGlzdHMgd2l0aCBhY3RpdmUsIGFuZCBuZXZlciBzZWxlY3RzXCIsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCB7IHJlcmVuZGVyIH0gPSByZW5kZXIoXG4gICAgICA8RmlsZUV4cGxvcmVyVmlldyByb290cz17W3dvcmt0cmVlXX0gZnM9e2Zha2VGc30gYWN0aXZlUGF0aD1cIi9SRUFETUUubWRcIiB2aWV3ZWRQYXRoPVwiL1JFQURNRS5tZFwiIC8+LFxuICAgICk7XG4gICAgLy8gQm90aCBzdGF0ZXMgb24gT05FIHJvdzogYWN0aXZlIChhcmlhLWN1cnJlbnQpICsgdGhlIFwib24gc3RhZ2VcIiBtYXJrZXIuXG4gICAgY29uc3QgbWFya2VyID0gYXdhaXQgc2NyZWVuLmZpbmRCeUxhYmVsVGV4dChcIlNob3duIGluIHRoZSBydW5uaW5nIGFwcFwiKTtcbiAgICBleHBlY3QobWFya2VyKS50b0JlSW5UaGVEb2N1bWVudCgpO1xuICAgIGNvbnN0IHJvdyA9IHNjcmVlbi5nZXRCeVRleHQoXCJSRUFETUUubWRcIikuY2xvc2VzdChcIi50bm9kZVwiKSE7XG4gICAgZXhwZWN0KHJvdy5jbGFzc05hbWUpLnRvQ29udGFpbihcInRub2RlLS1hY3RpdmVcIik7XG4gICAgZXhwZWN0KHJvdy5jbGFzc05hbWUpLnRvQ29udGFpbihcInRub2RlLS12aWV3ZWRcIik7XG4gICAgLy8gSGlnaGxpZ2h0LW9ubHk6IHRoZSBtYXJrZXIgY29uZmVycyBubyBzZWxlY3Rpb24uXG4gICAgZXhwZWN0KHJvdy5jbGFzc05hbWUpLm5vdC50b0NvbnRhaW4oXCJ0bm9kZS0tc2VsZWN0ZWRcIik7XG4gICAgLy8gVGhlIGhpbnQgbW92aW5nIGlzIGp1c3QgYSBtYXJrZXIgbW92ZSDigJQgdGhlIGFjdGl2ZSByb3cgaXMgdW50b3VjaGVkLlxuICAgIHJlcmVuZGVyKFxuICAgICAgPEZpbGVFeHBsb3JlclZpZXcgcm9vdHM9e1t3b3JrdHJlZV19IGZzPXtmYWtlRnN9IGFjdGl2ZVBhdGg9XCIvUkVBRE1FLm1kXCIgdmlld2VkUGF0aD17bnVsbH0gLz4sXG4gICAgKTtcbiAgICBleHBlY3Qoc2NyZWVuLnF1ZXJ5QnlMYWJlbFRleHQoXCJTaG93biBpbiB0aGUgcnVubmluZyBhcHBcIikpLnRvQmVOdWxsKCk7XG4gICAgZXhwZWN0KHJvdy5jbGFzc05hbWUpLnRvQ29udGFpbihcInRub2RlLS1hY3RpdmVcIik7XG4gIH0pO1xuXG4gIGl0KFwiYWN0aXZhdGluZyBhIGZpbGUgY2FsbHMgYWN0aW9ucy5vcGVuIHdpdGggdGhlIG1vdW50LXJlbGF0aXZlIHBhdGggKyBvbkFjdGl2YXRlL29uU2VsZWN0XCIsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCB1c2VyID0gdXNlckV2ZW50LnNldHVwKCk7XG4gICAgY29uc3Qgb3BlbiA9IHZpLmZuKCk7XG4gICAgY29uc3Qgb25BY3RpdmF0ZSA9IHZpLmZuKCk7XG4gICAgY29uc3Qgb25TZWxlY3QgPSB2aS5mbigpO1xuICAgIHJlbmRlcihcbiAgICAgIDxGaWxlRXhwbG9yZXJWaWV3XG4gICAgICAgIHJvb3RzPXtbd29ya3RyZWVdfVxuICAgICAgICBmcz17ZmFrZUZzfVxuICAgICAgICBhY3Rpb25zPXt7IG9wZW4gfX1cbiAgICAgICAgb25BY3RpdmF0ZT17b25BY3RpdmF0ZX1cbiAgICAgICAgb25TZWxlY3Q9e29uU2VsZWN0fVxuICAgICAgLz4sXG4gICAgKTtcbiAgICBhd2FpdCBzY3JlZW4uZmluZEJ5VGV4dChcInNyY1wiKTtcbiAgICBhd2FpdCB1c2VyLmNsaWNrKHNjcmVlbi5nZXRCeVRleHQoXCJzcmNcIikpO1xuICAgIGF3YWl0IHVzZXIuY2xpY2soYXdhaXQgc2NyZWVuLmZpbmRCeVRleHQoXCJpbmRleC50c1wiKSk7XG5cbiAgICBleHBlY3Qob3BlbikudG9IYXZlQmVlbkNhbGxlZFdpdGgod29ya3RyZWUsIFwiL3NyYy9pbmRleC50c1wiKTtcbiAgICBleHBlY3Qob25BY3RpdmF0ZSkudG9IYXZlQmVlbkNhbGxlZFdpdGgod29ya3RyZWUsIFwiL3NyYy9pbmRleC50c1wiLCBmYWxzZSk7XG4gICAgZXhwZWN0KG9uU2VsZWN0KS50b0hhdmVCZWVuQ2FsbGVkV2l0aCh3b3JrdHJlZSwgXCIvc3JjL2luZGV4LnRzXCIpO1xuICAgIC8vIFRoZSBjbGlja2VkIHJvdyBpcyBtYXJrZWQgc2VsZWN0ZWQuXG4gICAgZXhwZWN0KHNjcmVlbi5nZXRCeVJvbGUoXCJ0cmVlaXRlbVwiLCB7IG5hbWU6IFwiaW5kZXgudHNcIiB9KSkudG9IYXZlQXR0cmlidXRlKFwiYXJpYS1zZWxlY3RlZFwiLCBcInRydWVcIik7XG4gIH0pO1xuXG4gIGl0KFwiYW4gYWJzZW50IGFjdGlvbiBoaWRlcyBpdHMgYWZmb3JkYW5jZSDigJQgbm8gZGVsZXRlIGJ1dHRvbiB3aGVuIGFjdGlvbnMuZGVsZXRlIGlzIG1pc3NpbmdcIiwgYXN5bmMgKCkgPT4ge1xuICAgIHJlbmRlcig8RmlsZUV4cGxvcmVyVmlldyByb290cz17W3dvcmt0cmVlXX0gZnM9e2Zha2VGc30gYWN0aW9ucz17eyBvcGVuOiB2aS5mbigpIH19IC8+KTtcbiAgICBhd2FpdCBzY3JlZW4uZmluZEJ5VGV4dChcIlJFQURNRS5tZFwiKTtcbiAgICAvLyBkZWxldGUgaXMgTk9UIHByb3ZpZGVkIOKGkiBubyBwZXItcm93IGRlbGV0ZSBidXR0b24sIGV2ZW4gb24gYSB3cml0YWJsZSByb290LlxuICAgIGV4cGVjdChzY3JlZW4ucXVlcnlCeUxhYmVsVGV4dCgvXkRlbGV0ZSAvKSkubm90LnRvQmVJblRoZURvY3VtZW50KCk7XG4gICAgLy8gdXBsb2FkIGlzIE5PVCBwcm92aWRlZCBlaXRoZXIg4oaSIG5vIMKnNSB1cGxvYWQgYnV0dG9uLCBldmVuIG9uIGEgd3JpdGFibGVcbiAgICAvLyByb290ICh0aGUgbGlicmFyeSdzIG1pc3NpbmctYWN0aW9uIGNvbnRyYWN0OyByZXZpZXcgcm91bmQgMydzIHBpbikuXG4gICAgZXhwZWN0KHNjcmVlbi5xdWVyeUJ5Um9sZShcImJ1dHRvblwiLCB7IG5hbWU6IC9eVXBsb2FkIGZpbGVzIHRvLyB9KSkubm90LnRvQmVJblRoZURvY3VtZW50KCk7XG4gICAgLy8g4oCmYW5kIHRoZSBjb250ZXh0IG1lbnUgb2ZmZXJzIG5vIERlbGV0ZSAvIHdyaXRlIGl0ZW1zLCBvbmx5IE9wZW4uXG4gICAgZmlyZUV2ZW50LmNvbnRleHRNZW51KHNjcmVlbi5nZXRCeVRleHQoXCJSRUFETUUubWRcIikpO1xuICAgIGNvbnN0IG1lbnUgPSBhd2FpdCBzY3JlZW4uZmluZEJ5Um9sZShcIm1lbnVcIik7XG4gICAgZXhwZWN0KHdpdGhpbihtZW51KS5nZXRCeVJvbGUoXCJtZW51aXRlbVwiLCB7IG5hbWU6IC9PcGVuLyB9KSkudG9CZUluVGhlRG9jdW1lbnQoKTtcbiAgICBleHBlY3Qod2l0aGluKG1lbnUpLnF1ZXJ5QnlSb2xlKFwibWVudWl0ZW1cIiwgeyBuYW1lOiAvRGVsZXRlLyB9KSkubm90LnRvQmVJblRoZURvY3VtZW50KCk7XG4gICAgZXhwZWN0KHdpdGhpbihtZW51KS5xdWVyeUJ5Um9sZShcIm1lbnVpdGVtXCIsIHsgbmFtZTogL05ldyBmaWxlIGhlcmUvIH0pKS5ub3QudG9CZUluVGhlRG9jdW1lbnQoKTtcbiAgfSk7XG5cbiAgaXQoXCJhIHByb3ZpZGVkIGFjdGlvbiBzaG93cyBpdHMgYWZmb3JkYW5jZSDigJQgRGVsZXRlIGZyb20gdGhlIHJvdydzIG1lbnUgY29uZmlybXMgdGhlbiBkZWxldGVzLCBhbmQgdGhlIHJvdyBkaXNhcHBlYXJzIG9wdGltaXN0aWNhbGx5XCIsIGFzeW5jICgpID0+IHtcbiAgICAvLyBUaGUgYWN0aW9uIElTIHRoZSB3cml0ZTogaXQgbGFuZHMgdGhlIGRlbGV0ZSBpbiB0aGUgZml4dHVyZSB0cmVlLCBleGFjdGx5XG4gICAgLy8gYXMgdGhlIGhvc3QncyBkZWxldGUgbGFuZHMgaXQgaW4gdGhlIHJlYWwgZnMsIGJlZm9yZSByZXNvbHZpbmcuXG4gICAgY29uc3QgZGVsID0gdmkuZm4oKCkgPT4ge1xuICAgICAgVFJFRVtcIi9tbnQvYWJjL3NyY1wiXSA9IFRSRUVbXCIvbW50L2FiYy9zcmNcIl0uZmlsdGVyKChlKSA9PiBlLm5hbWUgIT09IFwiaW5kZXgudHNcIik7XG4gICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKFwiL3NyYy9pbmRleC50c1wiKTtcbiAgICB9KTtcbiAgICBjb25zdCB1c2VyID0gdXNlckV2ZW50LnNldHVwKCk7XG4gICAgcmVuZGVyKDxGaWxlRXhwbG9yZXJWaWV3IHJvb3RzPXtbd29ya3RyZWVdfSBmcz17ZmFrZUZzfSBhY3Rpb25zPXt7IGRlbGV0ZTogZGVsIH19IC8+KTtcbiAgICBhd2FpdCBzY3JlZW4uZmluZEJ5VGV4dChcInNyY1wiKTtcbiAgICBhd2FpdCB1c2VyLmNsaWNrKHNjcmVlbi5nZXRCeVRleHQoXCJzcmNcIikpO1xuICAgIGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KFwiaW5kZXgudHNcIik7XG5cbiAgICBjb25zdCBjb25maXJtID0gdmkuc3B5T24od2luZG93LCBcImNvbmZpcm1cIikubW9ja1JldHVyblZhbHVlKHRydWUpO1xuICAgIGZpcmVFdmVudC5jb250ZXh0TWVudShzY3JlZW4uZ2V0QnlUZXh0KFwiaW5kZXgudHNcIikpO1xuICAgIGNvbnN0IG1lbnUgPSBhd2FpdCBzY3JlZW4uZmluZEJ5Um9sZShcIm1lbnVcIik7XG4gICAgYXdhaXQgdXNlci5jbGljayh3aXRoaW4obWVudSkuZ2V0QnlSb2xlKFwibWVudWl0ZW1cIiwgeyBuYW1lOiAvXkRlbGV0ZS8gfSkpO1xuICAgIGV4cGVjdChkZWwpLnRvSGF2ZUJlZW5DYWxsZWRXaXRoKHdvcmt0cmVlLCBcIi9zcmMvaW5kZXgudHNcIik7XG4gICAgY29uZmlybS5tb2NrUmVzdG9yZSgpO1xuICAgIC8vIFRoZSBjb2xsZWN0aW9uIHNob3dzIHRoZSBjaGFuZ2UgaW1tZWRpYXRlbHkgKFItSVgtMyk6IHRoZSByb3cgaXMgZ29uZVxuICAgIC8vIGJlZm9yZSBhbnkgcmVmZXRjaCBpcyBncmFudGVkIGEgc2F5LlxuICAgIGF3YWl0IHZpLndhaXRGb3IoKCkgPT5cbiAgICAgIGV4cGVjdChzY3JlZW4ucXVlcnlCeVJvbGUoXCJ0cmVlaXRlbVwiLCB7IG5hbWU6IFwiaW5kZXgudHNcIiB9KSkudG9CZU51bGwoKSxcbiAgICApO1xuICB9KTtcblxuICBpdChcImNhbmNlbGxpbmcgdGhlIGRlbGV0ZSBjb25maXJtIHJlbW92ZXMgbm90aGluZyBhbmQgbGVhdmVzIHRoZSByb3cgaW4gcGxhY2VcIiwgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IGRlbCA9IHZpLmZuKCgpID0+IFByb21pc2UucmVzb2x2ZShcIi9zcmMvaW5kZXgudHNcIikpO1xuICAgIGNvbnN0IHVzZXIgPSB1c2VyRXZlbnQuc2V0dXAoKTtcbiAgICByZW5kZXIoPEZpbGVFeHBsb3JlclZpZXcgcm9vdHM9e1t3b3JrdHJlZV19IGZzPXtmYWtlRnN9IGFjdGlvbnM9e3sgZGVsZXRlOiBkZWwgfX0gLz4pO1xuICAgIGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KFwic3JjXCIpO1xuICAgIGF3YWl0IHVzZXIuY2xpY2soc2NyZWVuLmdldEJ5VGV4dChcInNyY1wiKSk7XG4gICAgYXdhaXQgc2NyZWVuLmZpbmRCeVRleHQoXCJpbmRleC50c1wiKTtcblxuICAgIGNvbnN0IGNvbmZpcm0gPSB2aS5zcHlPbih3aW5kb3csIFwiY29uZmlybVwiKS5tb2NrUmV0dXJuVmFsdWUoZmFsc2UpO1xuICAgIGZpcmVFdmVudC5jb250ZXh0TWVudShzY3JlZW4uZ2V0QnlUZXh0KFwiaW5kZXgudHNcIikpO1xuICAgIGNvbnN0IG1lbnUgPSBhd2FpdCBzY3JlZW4uZmluZEJ5Um9sZShcIm1lbnVcIik7XG4gICAgYXdhaXQgdXNlci5jbGljayh3aXRoaW4obWVudSkuZ2V0QnlSb2xlKFwibWVudWl0ZW1cIiwgeyBuYW1lOiAvXkRlbGV0ZS8gfSkpO1xuICAgIGV4cGVjdChkZWwpLm5vdC50b0hhdmVCZWVuQ2FsbGVkKCk7XG4gICAgZXhwZWN0KHNjcmVlbi5nZXRCeVJvbGUoXCJ0cmVlaXRlbVwiLCB7IG5hbWU6IFwiaW5kZXgudHNcIiB9KSkudG9CZUluVGhlRG9jdW1lbnQoKTtcbiAgICBjb25maXJtLm1vY2tSZXN0b3JlKCk7XG4gIH0pO1xuXG4gIGl0KFwiZXh0cmFNZW51SXRlbXMgYXJlIGFwcGVuZGVkIHRvIHRoZSByb3cgY29udGV4dCBtZW51XCIsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCBvblN1bW1hcml6ZSA9IHZpLmZuKCk7XG4gICAgY29uc3QgZXh0cmFNZW51SXRlbXMgPSB2aS5mbigoKSA9PiBbXG4gICAgICB7IGtleTogXCJzdW1tYXJpemVcIiwgbGFiZWw6IFwiU3VtbWFyaXpl4oCmXCIsIG9uU2VsZWN0OiBvblN1bW1hcml6ZSB9LFxuICAgIF0pO1xuICAgIGNvbnN0IHVzZXIgPSB1c2VyRXZlbnQuc2V0dXAoKTtcbiAgICByZW5kZXIoXG4gICAgICA8RmlsZUV4cGxvcmVyVmlld1xuICAgICAgICByb290cz17W3dvcmt0cmVlXX1cbiAgICAgICAgZnM9e2Zha2VGc31cbiAgICAgICAgYWN0aW9ucz17eyBvcGVuOiB2aS5mbigpIH19XG4gICAgICAgIGV4dHJhTWVudUl0ZW1zPXtleHRyYU1lbnVJdGVtc31cbiAgICAgIC8+LFxuICAgICk7XG4gICAgYXdhaXQgc2NyZWVuLmZpbmRCeVRleHQoXCJSRUFETUUubWRcIik7XG4gICAgZmlyZUV2ZW50LmNvbnRleHRNZW51KHNjcmVlbi5nZXRCeVRleHQoXCJSRUFETUUubWRcIikpO1xuICAgIGNvbnN0IG1lbnUgPSBhd2FpdCBzY3JlZW4uZmluZEJ5Um9sZShcIm1lbnVcIik7XG4gICAgY29uc3QgaXRlbSA9IHdpdGhpbihtZW51KS5nZXRCeVJvbGUoXCJtZW51aXRlbVwiLCB7IG5hbWU6IC9TdW1tYXJpemUvIH0pO1xuICAgIGV4cGVjdChpdGVtKS50b0JlSW5UaGVEb2N1bWVudCgpO1xuICAgIGF3YWl0IHVzZXIuY2xpY2soaXRlbSk7XG4gICAgZXhwZWN0KG9uU3VtbWFyaXplKS50b0hhdmVCZWVuQ2FsbGVkKCk7XG4gIH0pO1xuXG4gIGl0KFwicmVuZGVycyB0aGUgZW1wdHkgc3RhdGUgd2hlbiB0aGVyZSBhcmUgbm8gcm9vdHNcIiwgKCkgPT4ge1xuICAgIHJlbmRlcig8RmlsZUV4cGxvcmVyVmlldyByb290cz17W119IGZzPXtmYWtlRnN9IC8+KTtcbiAgICBleHBlY3Qoc2NyZWVuLmdldEJ5Um9sZShcImhlYWRpbmdcIiwgeyBuYW1lOiAvTm8gZmlsZXMgdG8gc2hvdyB5ZXQvaSB9KSkudG9CZUluVGhlRG9jdW1lbnQoKTtcbiAgfSk7XG5cbiAgaXQoXCJmaXJlcyBvbk5hdmlnYXRlIHdpdGggKHJvb3QsIHJlbFBhdGgpIHdoZW4gdGhlIGxpc3QgbGF5b3V0IGJyb3dzZXMgaW50byBhIGRpcmVjdG9yeVwiLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgdXNlciA9IHVzZXJFdmVudC5zZXR1cCgpO1xuICAgIGNvbnN0IG9uTmF2aWdhdGUgPSB2aS5mbigpO1xuICAgIHJlbmRlcihcbiAgICAgIDxGaWxlRXhwbG9yZXJWaWV3IHJvb3RzPXtbd29ya3RyZWVdfSBmcz17ZmFrZUZzfSBsYXlvdXQ9XCJsaXN0XCIgb25OYXZpZ2F0ZT17b25OYXZpZ2F0ZX0gLz4sXG4gICAgKTtcbiAgICAvLyBUaGUgbGlzdCBzdGFydHMgYXQgdGhlIHJvb3RzLXJvb3QgKHRoZSBzaW5nbGUgcm9vdCBzaG93biBhcyBhIHJvdykuIEVudGVyIGl04oCmXG4gICAgYXdhaXQgdXNlci5jbGljayhhd2FpdCBzY3JlZW4uZmluZEJ5VGV4dChcInJlcG9cIikpO1xuICAgIC8vIOKApnRoZW4gaW50byBgc3JjYC4gb25OYXZpZ2F0ZSByZXBvcnRzIHRoZSBkZXN0aW5hdGlvbiBkaXJlY3RvcnkgcGVyIG5hdmlnYXRpb24uXG4gICAgYXdhaXQgdXNlci5jbGljayhhd2FpdCBzY3JlZW4uZmluZEJ5VGV4dChcInNyY1wiKSk7XG5cbiAgICBleHBlY3Qob25OYXZpZ2F0ZSkudG9IYXZlQmVlbkNhbGxlZFdpdGgod29ya3RyZWUsIGV4cGVjdC5zdHJpbmdNYXRjaGluZygvKF58XFwvKXNyYyQvKSk7XG4gICAgLy8gQWx3YXlzIHRoZSBvd25pbmcgcm9vdCwgbmV2ZXIgYSBmb3JlaWduIG9uZS5cbiAgICBmb3IgKGNvbnN0IGNhbGwgb2Ygb25OYXZpZ2F0ZS5tb2NrLmNhbGxzKSBleHBlY3QoY2FsbFswXSkudG9CZSh3b3JrdHJlZSk7XG4gIH0pO1xuXG4gIGl0KFwiY29udHJvbGxlZCBjd2Q6IHJlbmRlcnMgdGhlIHByb3AncyBkaXJlY3Rvcnk7IG5hdmlnYXRpbmcgZmlyZXMgb25OYXZpZ2F0ZSBidXQgZG9lcyBOT1QgY2hhbmdlIHdoYXQncyBzaG93biB1bnRpbCB0aGUgcHJvcCB1cGRhdGVzXCIsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCB1c2VyID0gdXNlckV2ZW50LnNldHVwKCk7XG4gICAgY29uc3Qgb25OYXZpZ2F0ZSA9IHZpLmZuKCk7XG4gICAgY29uc3QgeyByZXJlbmRlciB9ID0gcmVuZGVyKFxuICAgICAgPEZpbGVFeHBsb3JlclZpZXdcbiAgICAgICAgcm9vdHM9e1t3b3JrdHJlZV19XG4gICAgICAgIGZzPXtmYWtlRnN9XG4gICAgICAgIGxheW91dD1cImxpc3RcIlxuICAgICAgICBjd2Q9XCIvbW50L2FiY1wiXG4gICAgICAgIG9uTmF2aWdhdGU9e29uTmF2aWdhdGV9XG4gICAgICAvPixcbiAgICApO1xuICAgIC8vIFRoZSBjb250cm9sbGVkIGN3ZCAoYC9tbnQvYWJjYCkgaXMgc2hvd24g4oCUIGl0cyBlbnRyaWVzLCBub3QgdGhlIHJvb3RzLXJvb3QuXG4gICAgZXhwZWN0KGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KFwic3JjXCIpKS50b0JlSW5UaGVEb2N1bWVudCgpO1xuICAgIGV4cGVjdChzY3JlZW4uZ2V0QnlUZXh0KFwiUkVBRE1FLm1kXCIpKS50b0JlSW5UaGVEb2N1bWVudCgpO1xuXG4gICAgLy8gTmF2aWdhdGluZyBpbnRvIGBzcmNgIHJlcG9ydHMgdmlhIG9uTmF2aWdhdGUgYnV0IHRoZSB2aWV3IHN0YXlzIHB1dCAodGhlXG4gICAgLy8gY29uc3VtZXIgb3ducyBjd2QpIOKAlCBgc3JjYCdzIGNoaWxkcmVuIGFyZSBOT1Qgc2hvd24geWV0LlxuICAgIGF3YWl0IHVzZXIuY2xpY2soc2NyZWVuLmdldEJ5VGV4dChcInNyY1wiKSk7XG4gICAgZXhwZWN0KG9uTmF2aWdhdGUpLnRvSGF2ZUJlZW5DYWxsZWRXaXRoKHdvcmt0cmVlLCBleHBlY3Quc3RyaW5nTWF0Y2hpbmcoLyhefFxcLylzcmMkLykpO1xuICAgIGV4cGVjdChzY3JlZW4ucXVlcnlCeVRleHQoXCJpbmRleC50c1wiKSkubm90LnRvQmVJblRoZURvY3VtZW50KCk7XG4gICAgZXhwZWN0KHNjcmVlbi5nZXRCeVRleHQoXCJSRUFETUUubWRcIikpLnRvQmVJblRoZURvY3VtZW50KCk7XG5cbiAgICAvLyBGZWVkaW5nIHRoZSBuZXcgY3dkIHByb3AgYmFjayBpbiBzaG93cyB0aGF0IGRpcmVjdG9yeS5cbiAgICByZXJlbmRlcihcbiAgICAgIDxGaWxlRXhwbG9yZXJWaWV3XG4gICAgICAgIHJvb3RzPXtbd29ya3RyZWVdfVxuICAgICAgICBmcz17ZmFrZUZzfVxuICAgICAgICBsYXlvdXQ9XCJsaXN0XCJcbiAgICAgICAgY3dkPVwiL21udC9hYmMvc3JjXCJcbiAgICAgICAgb25OYXZpZ2F0ZT17b25OYXZpZ2F0ZX1cbiAgICAgIC8+LFxuICAgICk7XG4gICAgZXhwZWN0KGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KFwiaW5kZXgudHNcIikpLnRvQmVJblRoZURvY3VtZW50KCk7XG4gICAgZXhwZWN0KHNjcmVlbi5nZXRCeVRleHQoXCJ1dGlsLnRzXCIpKS50b0JlSW5UaGVEb2N1bWVudCgpO1xuICAgIGV4cGVjdChzY3JlZW4ucXVlcnlCeVRleHQoXCJSRUFETUUubWRcIikpLm5vdC50b0JlSW5UaGVEb2N1bWVudCgpO1xuICB9KTtcblxuICBpdChcIm11bHRpLXNlbGVjdDogY2xpY2tpbmcgdHdvIGZpbGVzIHJlcG9ydHMgYSAyLWVsZW1lbnQgc2V0OyBjbGlja2luZyBvbmUgYWdhaW4gdG9nZ2xlcyBpdCBvZmY7IHJvd3Mgc2hvdyBzZWxlY3RlZCBzdHlsaW5nXCIsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCB1c2VyID0gdXNlckV2ZW50LnNldHVwKCk7XG4gICAgY29uc3Qgb25TZWxlY3Rpb25DaGFuZ2UgPSB2aS5mbigpO1xuICAgIHJlbmRlcihcbiAgICAgIDxGaWxlRXhwbG9yZXJWaWV3XG4gICAgICAgIHJvb3RzPXtbd29ya3RyZWVdfVxuICAgICAgICBmcz17ZmFrZUZzfVxuICAgICAgICBsYXlvdXQ9XCJsaXN0XCJcbiAgICAgICAgY3dkPVwiL21udC9hYmMvc3JjXCJcbiAgICAgICAgc2VsZWN0aW9uTW9kZT1cIm11bHRpXCJcbiAgICAgICAgb25TZWxlY3Rpb25DaGFuZ2U9e29uU2VsZWN0aW9uQ2hhbmdlfVxuICAgICAgLz4sXG4gICAgKTtcbiAgICBjb25zdCBpbmRleFJvdyA9IChhd2FpdCBzY3JlZW4uZmluZEJ5VGV4dChcImluZGV4LnRzXCIpKS5jbG9zZXN0KCdbcm9sZT1cIm9wdGlvblwiXScpITtcbiAgICBjb25zdCB1dGlsUm93ID0gc2NyZWVuLmdldEJ5VGV4dChcInV0aWwudHNcIikuY2xvc2VzdCgnW3JvbGU9XCJvcHRpb25cIl0nKSE7XG5cbiAgICAvLyBDbGljayB0d28gZmlsZXMg4oaSIHRoZSBzZXQgZ3Jvd3MgdG8gdHdvIChtb3VudC1yZWxhdGl2ZSBwYXRocywgb3duaW5nIHJvb3QpLlxuICAgIGF3YWl0IHVzZXIuY2xpY2soaW5kZXhSb3cpO1xuICAgIGV4cGVjdChvblNlbGVjdGlvbkNoYW5nZSkudG9IYXZlQmVlbkxhc3RDYWxsZWRXaXRoKHdvcmt0cmVlLCBbXCIvc3JjL2luZGV4LnRzXCJdKTtcbiAgICBhd2FpdCB1c2VyLmNsaWNrKHV0aWxSb3cpO1xuICAgIGV4cGVjdChvblNlbGVjdGlvbkNoYW5nZSkudG9IYXZlQmVlbkxhc3RDYWxsZWRXaXRoKFxuICAgICAgd29ya3RyZWUsXG4gICAgICBleHBlY3QuYXJyYXlDb250YWluaW5nKFtcIi9zcmMvaW5kZXgudHNcIiwgXCIvc3JjL3V0aWwudHNcIl0pLFxuICAgICk7XG4gICAgZXhwZWN0KG9uU2VsZWN0aW9uQ2hhbmdlLm1vY2suY2FsbHMuYXQoLTEpIVsxXSkudG9IYXZlTGVuZ3RoKDIpO1xuICAgIC8vIEJvdGggbWFya2VkIHJvd3MgY2FycnkgdGhlIHNlbGVjdGVkIHN0eWxpbmcuXG4gICAgZXhwZWN0KGluZGV4Um93KS50b0hhdmVDbGFzcyhcImxyb3ctLXNlbGVjdGVkXCIpO1xuICAgIGV4cGVjdCh1dGlsUm93KS50b0hhdmVDbGFzcyhcImxyb3ctLXNlbGVjdGVkXCIpO1xuXG4gICAgLy8gQ2xpY2tpbmcgYGluZGV4LnRzYCBhZ2FpbiB0b2dnbGVzIGl0IE9GRiDihpIgYmFjayB0byBhIDEtZWxlbWVudCBzZXQuXG4gICAgYXdhaXQgdXNlci5jbGljayhpbmRleFJvdyk7XG4gICAgZXhwZWN0KG9uU2VsZWN0aW9uQ2hhbmdlKS50b0hhdmVCZWVuTGFzdENhbGxlZFdpdGgod29ya3RyZWUsIFtcIi9zcmMvdXRpbC50c1wiXSk7XG4gICAgZXhwZWN0KGluZGV4Um93KS5ub3QudG9IYXZlQ2xhc3MoXCJscm93LS1zZWxlY3RlZFwiKTtcbiAgICBleHBlY3QodXRpbFJvdykudG9IYXZlQ2xhc3MoXCJscm93LS1zZWxlY3RlZFwiKTtcbiAgfSk7XG5cbiAgaXQoXCJ0aGUgaW5saW5lIHJlbmFtZSBwcm9tcHQgaXMgbGFiZWxsZWQgd2l0aCBvcGVyYXRpb24gKyB0YXJnZXQsIGFuZCBFc2NhcGUgY2FuY2VscyBiYWNrIHRvIHRoZSB0cmlnZ2VyaW5nIHJvdyB3aXRob3V0IGNvbW1pdHRpbmdcIiwgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHVzZXIgPSB1c2VyRXZlbnQuc2V0dXAoKTtcbiAgICBjb25zdCByZW5hbWUgPSB2aS5mbigoKSA9PiBQcm9taXNlLnJlc29sdmUoKSk7XG4gICAgY29uc3QgY3JlYXRlRmlsZSA9IHZpLmZuKCgpID0+IFByb21pc2UucmVzb2x2ZSgpKTtcbiAgICByZW5kZXIoXG4gICAgICA8RmlsZUV4cGxvcmVyVmlldyByb290cz17W3dvcmt0cmVlXX0gZnM9e2Zha2VGc30gYWN0aW9ucz17eyByZW5hbWUsIGNyZWF0ZUZpbGUgfX0gLz4sXG4gICAgKTtcbiAgICBhd2FpdCBzY3JlZW4uZmluZEJ5VGV4dChcInNyY1wiKTtcbiAgICBhd2FpdCB1c2VyLmNsaWNrKHNjcmVlbi5nZXRCeVRleHQoXCJzcmNcIikpO1xuICAgIGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KFwiaW5kZXgudHNcIik7XG5cbiAgICAvLyBSZW5hbWXigKYgb24gaW5kZXgudHMg4oaSIGEgbGFiZWxsZWQgaW5wdXQgKG5vdCBwbGFjZWhvbGRlci1vbmx5IG5hbWluZykuXG4gICAgY29uc3Qgcm93ID0gc2NyZWVuLmdldEJ5VGV4dChcImluZGV4LnRzXCIpLmNsb3Nlc3QoXCJkaXYudG5vZGVcIikgYXMgSFRNTEVsZW1lbnQ7XG4gICAgZmlyZUV2ZW50LmNvbnRleHRNZW51KHNjcmVlbi5nZXRCeVRleHQoXCJpbmRleC50c1wiKSk7XG4gICAgY29uc3QgbWVudSA9IGF3YWl0IHNjcmVlbi5maW5kQnlSb2xlKFwibWVudVwiKTtcbiAgICBhd2FpdCB1c2VyLmNsaWNrKHdpdGhpbihtZW51KS5nZXRCeVJvbGUoXCJtZW51aXRlbVwiLCB7IG5hbWU6IC9SZW5hbWUvIH0pKTtcbiAgICBjb25zdCBpbnB1dCA9IHNjcmVlbi5nZXRCeVJvbGUoXCJ0ZXh0Ym94XCIsIHsgbmFtZTogXCJSZW5hbWUgaW5kZXgudHNcIiB9KTtcbiAgICBleHBlY3QoaW5wdXQpLnRvSGF2ZUZvY3VzKCk7XG4gICAgYXdhaXQgdXNlci50eXBlKGlucHV0LCBcInhcIik7XG5cbiAgICBhd2FpdCB1c2VyLmtleWJvYXJkKFwie0VzY2FwZX1cIik7XG4gICAgZXhwZWN0KHNjcmVlbi5xdWVyeUJ5Um9sZShcInRleHRib3hcIikpLnRvQmVOdWxsKCk7XG4gICAgZXhwZWN0KHJlbmFtZSkubm90LnRvSGF2ZUJlZW5DYWxsZWQoKTsgLy8gYSBjYW5jZWwgaXMgbm90IGEgYmx1ci1jb21taXRcbiAgICBleHBlY3Qocm93KS50b0hhdmVGb2N1cygpOyAvLyBmb2N1cyByZXR1cm5zIHRvIHRoZSByb3cgdGhhdCBvcGVuZWQgaXRcblxuICAgIC8vIFRoZSBjcmVhdGUgcHJvbXB0IG5hbWVzIGl0cyBvcGVyYXRpb24gYW5kIGRpcmVjdG9yeSB0aGUgc2FtZSB3YXkuXG4gICAgZmlyZUV2ZW50LmNvbnRleHRNZW51KHNjcmVlbi5nZXRCeVRleHQoXCJpbmRleC50c1wiKSk7XG4gICAgY29uc3QgbWVudTIgPSBhd2FpdCBzY3JlZW4uZmluZEJ5Um9sZShcIm1lbnVcIik7XG4gICAgYXdhaXQgdXNlci5jbGljayh3aXRoaW4obWVudTIpLmdldEJ5Um9sZShcIm1lbnVpdGVtXCIsIHsgbmFtZTogL05ldyBmaWxlIGhlcmUvIH0pKTtcbiAgICBleHBlY3Qoc2NyZWVuLmdldEJ5Um9sZShcInRleHRib3hcIiwgeyBuYW1lOiBcIk5ldyBmaWxlIGluIC9zcmNcIiB9KSkudG9CZUluVGhlRG9jdW1lbnQoKTtcbiAgfSk7XG5cbiAgaXQoXCJ0aGUgdHJhbnNpZW50IGVycm9yIGJhbm5lciBpcyBkaXNtaXNzZWQgYnkgYSBmb2N1c2FibGUgRGlzbWlzcyBidXR0b25cIiwgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHVzZXIgPSB1c2VyRXZlbnQuc2V0dXAoKTtcbiAgICBjb25zdCByZW5hbWUgPSB2aS5mbigoKSA9PiBQcm9taXNlLnJlc29sdmUoeyBuYW1lOiBcInhcIiwgaXNEaXI6IGZhbHNlIH0pKTtcbiAgICByZW5kZXIoPEZpbGVFeHBsb3JlclZpZXcgcm9vdHM9e1t3b3JrdHJlZV19IGZzPXtmYWtlRnN9IGFjdGlvbnM9e3sgcmVuYW1lIH19IC8+KTtcbiAgICBhd2FpdCBzY3JlZW4uZmluZEJ5VGV4dChcInNyY1wiKTtcbiAgICAvLyBBIGNyb3NzLXJvb3QgZHJvcCBpcyByZWplY3RlZCB3aXRoIHRoZSBiYW5uZXIgKHRoZSBlYXNpZXN0IGhlYWRsZXNzIHBhdGgpLlxuICAgIGNvbnN0IHNyY1JvdyA9IHNjcmVlbi5nZXRCeVRleHQoXCJzcmNcIikuY2xvc2VzdChcImRpdi50bm9kZVwiKSBhcyBIVE1MRWxlbWVudDtcbiAgICBmaXJlRXZlbnQuZHJvcChzcmNSb3csIHtcbiAgICAgIGRhdGFUcmFuc2Zlcjoge1xuICAgICAgICB0eXBlczogW1wiYXBwbGljYXRpb24veC1pci1maWxlLW1vdmVcIl0sXG4gICAgICAgIGZpbGVzOiBbXSxcbiAgICAgICAgZ2V0RGF0YTogKHQ6IHN0cmluZykgPT5cbiAgICAgICAgICB0ID09PSBcImFwcGxpY2F0aW9uL3gtaXItZmlsZS1tb3ZlXCJcbiAgICAgICAgICAgID8gSlNPTi5zdHJpbmdpZnkoeyBmcm9tOiBcIi9zcGFjZXMvczEveC5tZFwiLCByb290UGF0aDogXCIvc3BhY2VzL3MxXCIsIGlzRGlyOiBmYWxzZSB9KVxuICAgICAgICAgICAgOiBcIlwiLFxuICAgICAgICBzZXREYXRhOiAoKSA9PiB7fSxcbiAgICAgICAgZHJvcEVmZmVjdDogXCJcIixcbiAgICAgICAgZWZmZWN0QWxsb3dlZDogXCJcIixcbiAgICAgIH0sXG4gICAgfSk7XG4gICAgY29uc3QgYmFubmVyID0gYXdhaXQgc2NyZWVuLmZpbmRCeVJvbGUoXCJhbGVydFwiKTtcbiAgICBleHBlY3QoYmFubmVyKS50b0hhdmVUZXh0Q29udGVudCgvc3BhY2VzL2kpO1xuICAgIGF3YWl0IHVzZXIuY2xpY2sod2l0aGluKGJhbm5lcikuZ2V0QnlSb2xlKFwiYnV0dG9uXCIsIHsgbmFtZTogXCJEaXNtaXNzXCIgfSkpO1xuICAgIGV4cGVjdChzY3JlZW4ucXVlcnlCeVJvbGUoXCJhbGVydFwiKSkudG9CZU51bGwoKTtcbiAgfSk7XG59KTtcblxuLy8gLS0tIFItSVgtMyAvIFItSVgtNDogYSB3cml0ZSByZW5kZXJzIGl0cyBvd24gcmVzdWx0IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuZGVzY3JpYmUoXCJGaWxlRXhwbG9yZXJWaWV3IHdyaXRlIHBhdGggKG9wdGltaXN0aWMgcm93cywgbmFycm93IHJlZmV0Y2gpXCIsICgpID0+IHtcbiAgYXN5bmMgZnVuY3Rpb24gcmVuZGVyU3JjRXhwYW5kZWQodWk6IFJlYWN0RWxlbWVudCkge1xuICAgIGNvbnN0IHVzZXIgPSB1c2VyRXZlbnQuc2V0dXAoKTtcbiAgICBjb25zdCB1dGlscyA9IHJlbmRlcih1aSk7XG4gICAgYXdhaXQgc2NyZWVuLmZpbmRCeVRleHQoXCJzcmNcIik7XG4gICAgYXdhaXQgdXNlci5jbGljayhzY3JlZW4uZ2V0QnlUZXh0KFwic3JjXCIpKTtcbiAgICBhd2FpdCBzY3JlZW4uZmluZEJ5VGV4dChcImluZGV4LnRzXCIpO1xuICAgIHJldHVybiB7IHVzZXIsIC4uLnV0aWxzIH07XG4gIH1cblxuICBpdChcImEgY3JlYXRlIHJlbmRlcnMgaXRzIHJvdyBpbW1lZGlhdGVseSwgcGVuZGluZywgYXQgZmluYWwgcG9zaXRpb247IHRoZSByZXR1cm4gc2V0dGxlcyBpdDsgb25seSB0aGUgY2hhbmdlZCBkaXJlY3RvcnkgaXMgcmVmZXRjaGVkXCIsIGFzeW5jICgpID0+IHtcbiAgICBsZXQgcmVzb2x2ZUNyZWF0ZSE6ICh2OiB7IG5hbWU6IHN0cmluZzsgaXNEaXI6IGJvb2xlYW4gfSB8IG51bGwpID0+IHZvaWQ7XG4gICAgY29uc3QgY3JlYXRlRmlsZSA9IHZpLmZuKFxuICAgICAgKCkgPT4gbmV3IFByb21pc2U8eyBuYW1lOiBzdHJpbmc7IGlzRGlyOiBib29sZWFuIH0gfCBudWxsPigocmVzKSA9PiAocmVzb2x2ZUNyZWF0ZSA9IHJlcykpLFxuICAgICk7XG4gICAgY29uc3QgeyB1c2VyIH0gPSBhd2FpdCByZW5kZXJTcmNFeHBhbmRlZChcbiAgICAgIDxGaWxlRXhwbG9yZXJWaWV3IHJvb3RzPXtbd29ya3RyZWVdfSBmcz17ZmFrZUZzfSBhY3Rpb25zPXt7IGNyZWF0ZUZpbGUgfX0gLz4sXG4gICAgKTtcbiAgICBjb25zdCBjYWxsc0JlZm9yZSA9IHJlYWRkaXIubW9jay5jYWxscy5sZW5ndGg7XG5cbiAgICBmaXJlRXZlbnQuY29udGV4dE1lbnUoc2NyZWVuLmdldEJ5VGV4dChcImluZGV4LnRzXCIpKTtcbiAgICBjb25zdCBtZW51ID0gYXdhaXQgc2NyZWVuLmZpbmRCeVJvbGUoXCJtZW51XCIpO1xuICAgIGF3YWl0IHVzZXIuY2xpY2sod2l0aGluKG1lbnUpLmdldEJ5Um9sZShcIm1lbnVpdGVtXCIsIHsgbmFtZTogL05ldyBmaWxlIGhlcmUvIH0pKTtcbiAgICBhd2FpdCB1c2VyLnR5cGUoc2NyZWVuLmdldEJ5Um9sZShcInRleHRib3hcIiwgeyBuYW1lOiBcIk5ldyBmaWxlIGluIC9zcmNcIiB9KSwgXCJhYWEudHN7RW50ZXJ9XCIpO1xuXG4gICAgLy8gUEVORElORyDigJQgdGhlIHJvdyBpcyB0aGVyZSBiZXR3ZWVuIGRpc3BhdGNoIGFuZCBzZXR0bGUsIGF0IGl0cyBmaW5hbFxuICAgIC8vIHBvc2l0aW9uIChmb2xkZXJzIGZpcnN0LCB0aGVuIG5hbWVzOiBhYWEudHMgPCBpbmRleC50cykuXG4gICAgY29uc3QgcGVuZGluZyA9IHNjcmVlbi5nZXRCeVJvbGUoXCJ0cmVlaXRlbVwiLCB7IG5hbWU6IFwiYWFhLnRzXCIgfSk7XG4gICAgZXhwZWN0KHBlbmRpbmcpLnRvSGF2ZUNsYXNzKFwidG5vZGUtLXBlbmRpbmdcIik7XG4gICAgZXhwZWN0KHBlbmRpbmcpLnRvSGF2ZUF0dHJpYnV0ZShcImFyaWEtYnVzeVwiLCBcInRydWVcIik7XG4gICAgZXhwZWN0KFxuICAgICAgcGVuZGluZy5jb21wYXJlRG9jdW1lbnRQb3NpdGlvbihzY3JlZW4uZ2V0QnlUZXh0KFwiaW5kZXgudHNcIikpICZcbiAgICAgICAgTm9kZS5ET0NVTUVOVF9QT1NJVElPTl9GT0xMT1dJTkcsXG4gICAgKS50b0JlVHJ1dGh5KCk7XG4gICAgZXhwZWN0KHNjcmVlbi5nZXRCeVJvbGUoXCJzdGF0dXNcIikpLnRvSGF2ZVRleHRDb250ZW50KFwiQ3JlYXRpbmcgYWFhLnRz4oCmXCIpO1xuICAgIGV4cGVjdChjcmVhdGVGaWxlKS50b0hhdmVCZWVuQ2FsbGVkV2l0aCh3b3JrdHJlZSwgXCIvc3JjL2FhYS50c1wiKTtcblxuICAgIC8vIFRoZSB3cml0ZSBsYW5kcywgdGhlbiB0aGUgcmV0dXJuIHNldHRsZXMgdGhlIHJvdyDigJQgbm8gcmVhZCB5ZXQuXG4gICAgVFJFRVtcIi9tbnQvYWJjL3NyY1wiXSA9IFtcbiAgICAgIHsgbmFtZTogXCJhYWEudHNcIiwgaXNEaXI6IGZhbHNlIH0sXG4gICAgICAuLi5TUkNfRU5UUklFUyxcbiAgICBdO1xuICAgIGF3YWl0IGFjdChhc3luYyAoKSA9PiByZXNvbHZlQ3JlYXRlKHsgbmFtZTogXCJhYWEudHNcIiwgaXNEaXI6IGZhbHNlIH0pKTtcbiAgICBjb25zdCBzZXR0bGVkID0gYXdhaXQgc2NyZWVuLmZpbmRCeVJvbGUoXCJ0cmVlaXRlbVwiLCB7IG5hbWU6IFwiYWFhLnRzXCIgfSk7XG4gICAgZXhwZWN0KHNldHRsZWQpLm5vdC50b0hhdmVDbGFzcyhcInRub2RlLS1wZW5kaW5nXCIpO1xuICAgIGV4cGVjdChzZXR0bGVkKS5ub3QudG9IYXZlQXR0cmlidXRlKFwiYXJpYS1idXN5XCIpO1xuICAgIGV4cGVjdChzY3JlZW4uZ2V0QnlSb2xlKFwic3RhdHVzXCIpKS50b0hhdmVUZXh0Q29udGVudChcIkNyZWF0ZWQgYWFhLnRzLlwiKTtcblxuICAgIC8vIFRoZSBwb3N0LXdyaXRlIGF1dGhvcml0eSByZWZldGNoIGlzIE5BUlJPVzogb25lIGNhbGwsIGZvciAvbW50L2FiYy9zcmMg4oCUXG4gICAgLy8gbmV2ZXIgYHJlZnJlc2goKWAncyBldmVyeS1vcGVuLWRpcmVjdG9yeSBzd2VlcCAoL21udC9hYmMgaXMgb3BlbiB0b28pLlxuICAgIGF3YWl0IGFjdChhc3luYyAoKSA9PiB7fSk7XG4gICAgZXhwZWN0KHJlYWRkaXIubW9jay5jYWxscy5sZW5ndGgpLnRvQmUoY2FsbHNCZWZvcmUgKyAxKTtcbiAgICBleHBlY3QocmVhZGRpci5tb2NrLmNhbGxzLmF0KC0xKSkudG9FcXVhbChbXCIvbW50L2FiYy9zcmNcIl0pO1xuICB9KTtcblxuICBpdChcImEgZmFpbGVkIGNyZWF0ZSByZXN0b3JlcyB0aGUgcHJldmlvdXMgc3RhdGUgYW5kIG5hbWVzIHRoZSByZWFzb24gaW4gdGV4dCArIGFubm91bmNlbWVudFwiLCBhc3luYyAoKSA9PiB7XG4gICAgbGV0IHJlamVjdENyZWF0ZSE6IChlOiB1bmtub3duKSA9PiB2b2lkO1xuICAgIGNvbnN0IGNyZWF0ZUZpbGUgPSB2aS5mbihcbiAgICAgICgpID0+XG4gICAgICAgIG5ldyBQcm9taXNlPHsgbmFtZTogc3RyaW5nOyBpc0RpcjogYm9vbGVhbiB9IHwgbnVsbD4oKF8sIHJlaikgPT4gKHJlamVjdENyZWF0ZSA9IHJlaikpLFxuICAgICk7XG4gICAgY29uc3QgeyB1c2VyIH0gPSBhd2FpdCByZW5kZXJTcmNFeHBhbmRlZChcbiAgICAgIDxGaWxlRXhwbG9yZXJWaWV3IHJvb3RzPXtbd29ya3RyZWVdfSBmcz17ZmFrZUZzfSBhY3Rpb25zPXt7IGNyZWF0ZUZpbGUgfX0gLz4sXG4gICAgKTtcblxuICAgIGZpcmVFdmVudC5jb250ZXh0TWVudShzY3JlZW4uZ2V0QnlUZXh0KFwiaW5kZXgudHNcIikpO1xuICAgIGNvbnN0IG1lbnUgPSBhd2FpdCBzY3JlZW4uZmluZEJ5Um9sZShcIm1lbnVcIik7XG4gICAgYXdhaXQgdXNlci5jbGljayh3aXRoaW4obWVudSkuZ2V0QnlSb2xlKFwibWVudWl0ZW1cIiwgeyBuYW1lOiAvTmV3IGZpbGUgaGVyZS8gfSkpO1xuICAgIGF3YWl0IHVzZXIudHlwZShzY3JlZW4uZ2V0QnlSb2xlKFwidGV4dGJveFwiLCB7IG5hbWU6IFwiTmV3IGZpbGUgaW4gL3NyY1wiIH0pLCBcInp6ei50c3tFbnRlcn1cIik7XG4gICAgZXhwZWN0KHNjcmVlbi5nZXRCeVJvbGUoXCJ0cmVlaXRlbVwiLCB7IG5hbWU6IFwienp6LnRzXCIgfSkpLnRvQmVJblRoZURvY3VtZW50KCk7XG5cbiAgICBhd2FpdCBhY3QoYXN5bmMgKCkgPT5cbiAgICAgIHJlamVjdENyZWF0ZShPYmplY3QuYXNzaWduKG5ldyBFcnJvcihcImV4aXN0c1wiKSwgeyBjb2RlOiBcImV4aXN0c1wiIH0pKSxcbiAgICApO1xuICAgIC8vIFJlc3RvcmVkOiB0aGUgcm93IGlzIGdvbmUsIHRoZSByZWFzb24gaXMgaW4gdGhlIGJhbm5lciBBTkQgdGhlIHJlZ2lvbi5cbiAgICBhd2FpdCB2aS53YWl0Rm9yKCgpID0+XG4gICAgICBleHBlY3Qoc2NyZWVuLnF1ZXJ5QnlSb2xlKFwidHJlZWl0ZW1cIiwgeyBuYW1lOiBcInp6ei50c1wiIH0pKS50b0JlTnVsbCgpLFxuICAgICk7XG4gICAgZXhwZWN0KHNjcmVlbi5nZXRCeVJvbGUoXCJhbGVydFwiKSkudG9IYXZlVGV4dENvbnRlbnQoXG4gICAgICBcIlNvbWV0aGluZyB3aXRoIHRoYXQgbmFtZSBhbHJlYWR5IGV4aXN0cy5cIixcbiAgICApO1xuICAgIGV4cGVjdChzY3JlZW4uZ2V0QnlSb2xlKFwic3RhdHVzXCIpKS50b0hhdmVUZXh0Q29udGVudCgvQ291bGRu4oCZdCBjcmVhdGUgenp6XFwudHMvKTtcbiAgfSk7XG5cbiAgaXQoXCJhIG1vdmUgdmlhIHRoZSAnTW92ZSB0b+KApicgcGlja2VyIGNvbW1pdHMgdGhyb3VnaCB0aGUgU0FNRSBhY3Rpb24gdGhlIGRyYWcgdGFrZXNcIiwgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHJlbmFtZSA9IHZpLmZuKCgpID0+IFByb21pc2UucmVzb2x2ZSh7IG5hbWU6IFwiUkVBRE1FLm1kXCIsIGlzRGlyOiBmYWxzZSB9KSk7XG5cbiAgICAvLyBUaGUgZHJhZyBwYXRoOiBkcm9wIFJFQURNRS5tZCBvbnRvIHRoZSBzcmMgZGlyZWN0b3J5IHJvdy5cbiAgICB7XG4gICAgICBjb25zdCB1c2VyID0gdXNlckV2ZW50LnNldHVwKCk7XG4gICAgICBjb25zdCB7IHVubW91bnQgfSA9IHJlbmRlcihcbiAgICAgICAgPEZpbGVFeHBsb3JlclZpZXcgcm9vdHM9e1t3b3JrdHJlZV19IGZzPXtmYWtlRnN9IGFjdGlvbnM9e3sgcmVuYW1lIH19IC8+LFxuICAgICAgKTtcbiAgICAgIGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KFwic3JjXCIpO1xuICAgICAgYXdhaXQgdXNlci5jbGljayhzY3JlZW4uZ2V0QnlUZXh0KFwic3JjXCIpKTtcbiAgICAgIGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KFwiaW5kZXgudHNcIik7XG4gICAgICBjb25zdCBtb3ZlID0geyBmcm9tOiBcIi9tbnQvYWJjL1JFQURNRS5tZFwiLCByb290UGF0aDogXCIvbW50L2FiY1wiLCBpc0RpcjogZmFsc2UgfTtcbiAgICAgIGZpcmVFdmVudC5kcm9wKHNjcmVlbi5nZXRCeVRleHQoXCJzcmNcIikuY2xvc2VzdChcImRpdi50bm9kZVwiKSBhcyBIVE1MRWxlbWVudCwge1xuICAgICAgICBkYXRhVHJhbnNmZXI6IHtcbiAgICAgICAgICB0eXBlczogW1wiYXBwbGljYXRpb24veC1pci1maWxlLW1vdmVcIl0sXG4gICAgICAgICAgZmlsZXM6IFtdLFxuICAgICAgICAgIGdldERhdGE6ICh0OiBzdHJpbmcpID0+XG4gICAgICAgICAgICB0ID09PSBcImFwcGxpY2F0aW9uL3gtaXItZmlsZS1tb3ZlXCIgPyBKU09OLnN0cmluZ2lmeShtb3ZlKSA6IFwiXCIsXG4gICAgICAgICAgc2V0RGF0YTogKCkgPT4ge30sXG4gICAgICAgICAgZHJvcEVmZmVjdDogXCJcIixcbiAgICAgICAgICBlZmZlY3RBbGxvd2VkOiBcIlwiLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgICBleHBlY3QocmVuYW1lKS50b0hhdmVCZWVuQ2FsbGVkV2l0aCh3b3JrdHJlZSwgXCIvUkVBRE1FLm1kXCIsIFwiL3NyYy9SRUFETUUubWRcIiwgZmFsc2UpO1xuICAgICAgdW5tb3VudCgpO1xuICAgIH1cbiAgICByZW5hbWUubW9ja0NsZWFyKCk7XG5cbiAgICAvLyBUaGUgcGlja2VyIHBhdGgsIGZyb20gYSBjbGVhbiByZW5kZXI6IE1vdmUgdG/igKYg4oaSIGNob29zZSBzcmMg4oaSIE1vdmUgaGVyZS5cbiAgICB7XG4gICAgICBjb25zdCB1c2VyID0gdXNlckV2ZW50LnNldHVwKCk7XG4gICAgICByZW5kZXIoPEZpbGVFeHBsb3JlclZpZXcgcm9vdHM9e1t3b3JrdHJlZV19IGZzPXtmYWtlRnN9IGFjdGlvbnM9e3sgcmVuYW1lIH19IC8+KTtcbiAgICAgIGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KFwic3JjXCIpO1xuICAgICAgZmlyZUV2ZW50LmNvbnRleHRNZW51KHNjcmVlbi5nZXRCeVRleHQoXCJSRUFETUUubWRcIikpO1xuICAgICAgY29uc3QgbWVudSA9IGF3YWl0IHNjcmVlbi5maW5kQnlSb2xlKFwibWVudVwiKTtcbiAgICAgIGF3YWl0IHVzZXIuY2xpY2sod2l0aGluKG1lbnUpLmdldEJ5Um9sZShcIm1lbnVpdGVtXCIsIHsgbmFtZTogL01vdmUgdG8vIH0pKTtcbiAgICAgIGNvbnN0IGRpYWxvZyA9IGF3YWl0IHNjcmVlbi5maW5kQnlSb2xlKFwiZGlhbG9nXCIsIHtcbiAgICAgICAgbmFtZTogXCJNb3ZlIFJFQURNRS5tZCB0byBhIGZvbGRlclwiLFxuICAgICAgfSk7XG4gICAgICBhd2FpdCB1c2VyLmNsaWNrKHdpdGhpbihkaWFsb2cpLmdldEJ5Um9sZShcInRyZWVpdGVtXCIsIHsgbmFtZTogXCJzcmNcIiB9KSk7XG4gICAgICBhd2FpdCB1c2VyLmNsaWNrKHdpdGhpbihkaWFsb2cpLmdldEJ5Um9sZShcImJ1dHRvblwiLCB7IG5hbWU6IFwiTW92ZSBoZXJlXCIgfSkpO1xuXG4gICAgICAvLyBPbmUgYWN0aW9uLCB0d28gdHJpZ2dlcnMg4oCUIGlkZW50aWNhbCBhcmd1bWVudHMuXG4gICAgICBleHBlY3QocmVuYW1lKS50b0hhdmVCZWVuQ2FsbGVkV2l0aCh3b3JrdHJlZSwgXCIvUkVBRE1FLm1kXCIsIFwiL3NyYy9SRUFETUUubWRcIiwgZmFsc2UpO1xuICAgICAgZXhwZWN0KHNjcmVlbi5nZXRCeVJvbGUoXCJzdGF0dXNcIikpLnRvSGF2ZVRleHRDb250ZW50KC9Nb3ZlZCBSRUFETUVcXC5tZCB0byBcXC9zcmMvKTtcbiAgICB9XG4gIH0pO1xufSk7XG5cbi8vIC0tLSBBUEcgVHJlZSBWaWV3OiBvbmUgdGFiIHN0b3AsIHJvdmluZyBhcnJvd3MsIHRoZSByb3cgaXMgdGhlIHRyZWVpdGVtIC0tLS0tLS1cbmRlc2NyaWJlKFwiRmlsZUV4cGxvcmVyVmlldyB0cmVlIGtleWJvYXJkIChBUEcpXCIsICgpID0+IHtcbiAgaXQoXCJleGFjdGx5IG9uZSB0YWIgc3RvcDsgdGhlIGZvY3VzYWJsZSByb3cgaXRzZWxmIGlzIHRoZSB0cmVlaXRlbSBjYXJyeWluZyB0aGUgZmlsZW5hbWUgKDQuMS4yKVwiLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgdXNlciA9IHVzZXJFdmVudC5zZXR1cCgpO1xuICAgIHJlbmRlcig8RmlsZUV4cGxvcmVyVmlldyByb290cz17W3dvcmt0cmVlXX0gZnM9e2Zha2VGc30gLz4pO1xuICAgIGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KFwic3JjXCIpO1xuICAgIGF3YWl0IHVzZXIuY2xpY2soc2NyZWVuLmdldEJ5VGV4dChcInNyY1wiKSk7XG4gICAgYXdhaXQgc2NyZWVuLmZpbmRCeVRleHQoXCJ1dGlsLnRzXCIpO1xuXG4gICAgY29uc3QgaXRlbXMgPSBzY3JlZW4uZ2V0QWxsQnlSb2xlKFwidHJlZWl0ZW1cIik7XG4gICAgZXhwZWN0KGl0ZW1zLmxlbmd0aCkudG9CZUdyZWF0ZXJUaGFuKDEpO1xuICAgIGV4cGVjdChpdGVtcy5maWx0ZXIoKGVsKSA9PiBlbC50YWJJbmRleCA9PT0gMCkpLnRvSGF2ZUxlbmd0aCgxKTtcblxuICAgIGNvbnN0IHJvdyA9IHNjcmVlbi5nZXRCeVJvbGUoXCJ0cmVlaXRlbVwiLCB7IG5hbWU6IFwiaW5kZXgudHNcIiB9KTtcbiAgICBleHBlY3Qocm93KS50b0hhdmVDbGFzcyhcInRub2RlXCIpOyAvLyB0aGUgcm9sZSBpcyBvbiB0aGUgRk9DVVNBQkxFIHJvdyBlbGVtZW50XG4gICAgZXhwZWN0KHJvdy50YWJJbmRleCkudG9CZSgtMSk7IC8vIOKApmFuZCBvbmx5IHRoZSBzdG9wIGlzIHRhYmJhYmxlXG4gIH0pO1xuXG4gIGl0KFwiRG93bi9Ib21lL0VuZCBtb3ZlIGZvY3VzIGFjcm9zcyB0aGUgdmlzaWJsZSByb3dzXCIsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCB1c2VyID0gdXNlckV2ZW50LnNldHVwKCk7XG4gICAgcmVuZGVyKDxGaWxlRXhwbG9yZXJWaWV3IHJvb3RzPXtbd29ya3RyZWVdfSBmcz17ZmFrZUZzfSAvPik7XG4gICAgYXdhaXQgc2NyZWVuLmZpbmRCeVRleHQoXCJzcmNcIik7XG4gICAgYXdhaXQgdXNlci5jbGljayhzY3JlZW4uZ2V0QnlUZXh0KFwic3JjXCIpKTtcbiAgICBhd2FpdCBzY3JlZW4uZmluZEJ5VGV4dChcInV0aWwudHNcIik7XG5cbiAgICBzY3JlZW4uZ2V0QnlSb2xlKFwidHJlZWl0ZW1cIiwgeyBuYW1lOiBcInJlcG9cIiB9KS5mb2N1cygpO1xuICAgIGF3YWl0IHVzZXIua2V5Ym9hcmQoXCJ7QXJyb3dEb3dufVwiKTtcbiAgICBleHBlY3Qoc2NyZWVuLmdldEJ5Um9sZShcInRyZWVpdGVtXCIsIHsgbmFtZTogXCJzcmNcIiB9KSkudG9IYXZlRm9jdXMoKTtcbiAgICBhd2FpdCB1c2VyLmtleWJvYXJkKFwie0Fycm93RG93bn1cIik7XG4gICAgZXhwZWN0KHNjcmVlbi5nZXRCeVJvbGUoXCJ0cmVlaXRlbVwiLCB7IG5hbWU6IFwiaW5kZXgudHNcIiB9KSkudG9IYXZlRm9jdXMoKTtcbiAgICBhd2FpdCB1c2VyLmtleWJvYXJkKFwie0hvbWV9XCIpO1xuICAgIGV4cGVjdChzY3JlZW4uZ2V0QnlSb2xlKFwidHJlZWl0ZW1cIiwgeyBuYW1lOiBcInJlcG9cIiB9KSkudG9IYXZlRm9jdXMoKTtcbiAgICBhd2FpdCB1c2VyLmtleWJvYXJkKFwie0VuZH1cIik7XG4gICAgLy8gVmlzaWJsZSBvcmRlciBpcyByZXBvLCBzcmMsIGluZGV4LnRzLCB1dGlsLnRzLCBSRUFETUUubWQgKGZvbGRlcnMgZmlyc3QpLlxuICAgIGV4cGVjdChzY3JlZW4uZ2V0QnlSb2xlKFwidHJlZWl0ZW1cIiwgeyBuYW1lOiBcIlJFQURNRS5tZFwiIH0pKS50b0hhdmVGb2N1cygpO1xuICB9KTtcblxuICBpdChcInRoZSB0YWIgc3RvcCBmb2xsb3dzIHRoZSBmb2N1c2VkIHJvd1wiLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgdXNlciA9IHVzZXJFdmVudC5zZXR1cCgpO1xuICAgIHJlbmRlcig8RmlsZUV4cGxvcmVyVmlldyByb290cz17W3dvcmt0cmVlXX0gZnM9e2Zha2VGc30gLz4pO1xuICAgIGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KFwic3JjXCIpO1xuICAgIGF3YWl0IHVzZXIuY2xpY2soc2NyZWVuLmdldEJ5VGV4dChcInNyY1wiKSk7XG4gICAgYXdhaXQgc2NyZWVuLmZpbmRCeVRleHQoXCJ1dGlsLnRzXCIpO1xuXG4gICAgY29uc3QgdXRpbCA9IHNjcmVlbi5nZXRCeVJvbGUoXCJ0cmVlaXRlbVwiLCB7IG5hbWU6IFwidXRpbC50c1wiIH0pO1xuICAgIGF3YWl0IHVzZXIuY2xpY2sodXRpbCk7XG4gICAgZXhwZWN0KHV0aWwudGFiSW5kZXgpLnRvQmUoMCk7XG4gICAgZXhwZWN0KFxuICAgICAgc2NyZWVuLmdldEFsbEJ5Um9sZShcInRyZWVpdGVtXCIpLmZpbHRlcigoZWwpID0+IGVsLnRhYkluZGV4ID09PSAwKSxcbiAgICApLnRvRXF1YWwoW3V0aWxdKTtcbiAgfSk7XG59KTtcblxuLy8gLS0tIHVwbG9hZHM6IHRoZSBiYXRjaCB3cml0ZSBhbm5vdW5jZXMgYm90aCBoYWx2ZXMgYW5kIHJlZmV0Y2hlcyBuYXJyb3dseSAtLS0tLS1cbmRlc2NyaWJlKFwiRmlsZUV4cGxvcmVyVmlldyB1cGxvYWQgcGF0aFwiLCAoKSA9PiB7XG4gIGl0KFwiYW5ub3VuY2VzIFVwbG9hZGluZ+KApi9VcGxvYWRlZCBhbmQgcmVmZXRjaGVzIG9ubHkgdGhlIHRhcmdldCBkaXJlY3RvcnlcIiwgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IGNhbGxzQmVmb3JlQmFzZSA9IHJlYWRkaXIubW9jay5jYWxscy5sZW5ndGg7XG4gICAgbGV0IHJlc29sdmVVcGxvYWQhOiAoKSA9PiB2b2lkO1xuICAgIGNvbnN0IHVwbG9hZCA9IHZpLmZuKFxuICAgICAgKCkgPT4gbmV3IFByb21pc2U8dm9pZD4oKHJlcykgPT4gKHJlc29sdmVVcGxvYWQgPSByZXMpKSxcbiAgICApO1xuICAgIHJlbmRlcig8RmlsZUV4cGxvcmVyVmlldyByb290cz17W3dvcmt0cmVlXX0gZnM9e2Zha2VGc30gYWN0aW9ucz17eyB1cGxvYWQgfX0gLz4pO1xuICAgIGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KFwic3JjXCIpO1xuICAgIGNvbnN0IGNhbGxzQmVmb3JlID0gcmVhZGRpci5tb2NrLmNhbGxzLmxlbmd0aDtcblxuICAgIGNvbnN0IGZpbGUgPSBuZXcgRmlsZShbXCJoZWxsb1wiXSwgXCJub3RlLnR4dFwiLCB7IHR5cGU6IFwidGV4dC9wbGFpblwiIH0pO1xuICAgIGZpcmVFdmVudC5kcm9wKHNjcmVlbi5nZXRCeVRleHQoXCJzcmNcIikuY2xvc2VzdChcImRpdi50bm9kZVwiKSBhcyBIVE1MRWxlbWVudCwge1xuICAgICAgZGF0YVRyYW5zZmVyOiB7XG4gICAgICAgIHR5cGVzOiBbXCJGaWxlc1wiXSxcbiAgICAgICAgZmlsZXM6IFtmaWxlXSxcbiAgICAgICAgZ2V0RGF0YTogKCkgPT4gXCJcIixcbiAgICAgICAgc2V0RGF0YTogKCkgPT4ge30sXG4gICAgICAgIGRyb3BFZmZlY3Q6IFwiXCIsXG4gICAgICAgIGVmZmVjdEFsbG93ZWQ6IFwiXCIsXG4gICAgICB9LFxuICAgIH0pO1xuICAgIGV4cGVjdCh1cGxvYWQpLnRvSGF2ZUJlZW5DYWxsZWRXaXRoKHdvcmt0cmVlLCBcIi9zcmNcIiwgW2ZpbGVdKTtcbiAgICBleHBlY3Qoc2NyZWVuLmdldEJ5Um9sZShcInN0YXR1c1wiKSkudG9IYXZlVGV4dENvbnRlbnQoXCJVcGxvYWRpbmcgMSBmaWxl4oCmXCIpO1xuICAgIGV4cGVjdChyZWFkZGlyLm1vY2suY2FsbHMubGVuZ3RoKS50b0JlKGNhbGxzQmVmb3JlKTsgLy8gbm8gcmVmZXRjaCBiZWZvcmUgc2V0dGxlXG5cbiAgICBUUkVFW1wiL21udC9hYmMvc3JjXCJdID0gWy4uLlNSQ19FTlRSSUVTLCB7IG5hbWU6IFwibm90ZS50eHRcIiwgaXNEaXI6IGZhbHNlIH1dO1xuICAgIGF3YWl0IGFjdChhc3luYyAoKSA9PiByZXNvbHZlVXBsb2FkKCkpO1xuICAgIGV4cGVjdChzY3JlZW4uZ2V0QnlSb2xlKFwic3RhdHVzXCIpKS50b0hhdmVUZXh0Q29udGVudChcIlVwbG9hZGVkIDEgZmlsZS5cIik7XG4gICAgYXdhaXQgYWN0KGFzeW5jICgpID0+IHt9KTtcbiAgICBleHBlY3QocmVhZGRpci5tb2NrLmNhbGxzLmxlbmd0aCkudG9CZShjYWxsc0JlZm9yZSArIDEpO1xuICAgIGV4cGVjdChyZWFkZGlyLm1vY2suY2FsbHMuYXQoLTEpKS50b0VxdWFsKFtcIi9tbnQvYWJjL3NyY1wiXSk7XG4gICAgZXhwZWN0KGNhbGxzQmVmb3JlID4gY2FsbHNCZWZvcmVCYXNlKS50b0JlKHRydWUpOyAvLyB0aGUgcmVhZHMgYWJvdmUgd2VyZSByZWFsXG4gIH0pO1xuXG4gIGl0KFwiYSBmYWlsZWQgdXBsb2FkIG5hbWVzIHRoZSByZWFzb24gaW4gYmFubmVyICsgYW5ub3VuY2VtZW50LCBubyByZWZldGNoXCIsIGFzeW5jICgpID0+IHtcbiAgICBsZXQgcmVqZWN0VXBsb2FkITogKGU6IHVua25vd24pID0+IHZvaWQ7XG4gICAgY29uc3QgdXBsb2FkID0gdmkuZm4oXG4gICAgICAoKSA9PlxuICAgICAgICBuZXcgUHJvbWlzZTx2b2lkPigoXywgcmVqKSA9PiAocmVqZWN0VXBsb2FkID0gcmVqKSksXG4gICAgKTtcbiAgICByZW5kZXIoPEZpbGVFeHBsb3JlclZpZXcgcm9vdHM9e1t3b3JrdHJlZV19IGZzPXtmYWtlRnN9IGFjdGlvbnM9e3sgdXBsb2FkIH19IC8+KTtcbiAgICBhd2FpdCBzY3JlZW4uZmluZEJ5VGV4dChcInNyY1wiKTtcbiAgICBjb25zdCBjYWxsc0JlZm9yZSA9IHJlYWRkaXIubW9jay5jYWxscy5sZW5ndGg7XG5cbiAgICBmaXJlRXZlbnQuZHJvcChzY3JlZW4uZ2V0QnlUZXh0KFwic3JjXCIpLmNsb3Nlc3QoXCJkaXYudG5vZGVcIikgYXMgSFRNTEVsZW1lbnQsIHtcbiAgICAgIGRhdGFUcmFuc2Zlcjoge1xuICAgICAgICB0eXBlczogW1wiRmlsZXNcIl0sXG4gICAgICAgIGZpbGVzOiBbbmV3IEZpbGUoW1wiaGVsbG9cIl0sIFwiYmlnLmJpblwiLCB7IHR5cGU6IFwidGV4dC9wbGFpblwiIH0pXSxcbiAgICAgICAgZ2V0RGF0YTogKCkgPT4gXCJcIixcbiAgICAgICAgc2V0RGF0YTogKCkgPT4ge30sXG4gICAgICAgIGRyb3BFZmZlY3Q6IFwiXCIsXG4gICAgICAgIGVmZmVjdEFsbG93ZWQ6IFwiXCIsXG4gICAgICB9LFxuICAgIH0pO1xuICAgIGF3YWl0IGFjdChhc3luYyAoKSA9PlxuICAgICAgcmVqZWN0VXBsb2FkKE9iamVjdC5hc3NpZ24obmV3IEVycm9yKFwidG9vIGxhcmdlXCIpLCB7IGNvZGU6IFwidG9vLWxhcmdlXCIgfSkpLFxuICAgICk7XG4gICAgZXhwZWN0KHNjcmVlbi5nZXRCeVJvbGUoXCJhbGVydFwiKSkudG9IYXZlVGV4dENvbnRlbnQoXCJUaGF0IGZpbGUgaXMgdG9vIGxhcmdlIHRvIHVwbG9hZC5cIik7XG4gICAgZXhwZWN0KHNjcmVlbi5nZXRCeVJvbGUoXCJzdGF0dXNcIikpLnRvSGF2ZVRleHRDb250ZW50KC9Db3VsZG7igJl0IHVwbG9hZC8pO1xuICAgIGV4cGVjdChyZWFkZGlyLm1vY2suY2FsbHMubGVuZ3RoKS50b0JlKGNhbGxzQmVmb3JlKTtcbiAgfSk7XG59KTtcblxuLy8gLS0tIMKnNSB1cGxvYWQgYnV0dG9uOiB0aGUgbmF0aXZlLXBpY2tlciBwYXRoIGFuZCBpdHMgZGVzdGluYXRpb24gcnVsZXMgLS0tLS0tLS0tXG5kZXNjcmliZShcIkZpbGVFeHBsb3JlclZpZXcgdXBsb2FkIGJ1dHRvbiAoRklMRV9FWFBMT1JFUl9TUEVDIMKnNSlcIiwgKCkgPT4ge1xuICBjb25zdCBwaWNrZXIgPSAoY29udGFpbmVyOiBIVE1MRWxlbWVudCkgPT5cbiAgICBjb250YWluZXIucXVlcnlTZWxlY3RvcjxIVE1MSW5wdXRFbGVtZW50PignaW5wdXRbdHlwZT1cImZpbGVcIl0nKSE7XG5cbiAgaXQoXCJ1cGxvYWRzIHRvIHRoZSByZXBvIHJvb3Qgd2hlbiBub3RoaW5nIGlzIHNlbGVjdGVkXCIsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCB1cGxvYWQgPSB2aS5mbigoKSA9PiBQcm9taXNlLnJlc29sdmUoKSk7XG4gICAgY29uc3QgeyBjb250YWluZXIgfSA9IHJlbmRlcihcbiAgICAgIDxGaWxlRXhwbG9yZXJWaWV3IHJvb3RzPXtbd29ya3RyZWVdfSBmcz17ZmFrZUZzfSBhY3Rpb25zPXt7IHVwbG9hZCB9fSAvPixcbiAgICApO1xuICAgIGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KFwiUkVBRE1FLm1kXCIpO1xuXG4gICAgZmlyZUV2ZW50LmNsaWNrKHNjcmVlbi5nZXRCeVJvbGUoXCJidXR0b25cIiwgeyBuYW1lOiBcIlVwbG9hZCBmaWxlcyB0byB0aGUgcmVwbyByb290XCIgfSkpO1xuICAgIGNvbnN0IGZpbGUgPSBuZXcgRmlsZShbXCJoZWxsb1wiXSwgXCJub3RlLnR4dFwiLCB7IHR5cGU6IFwidGV4dC9wbGFpblwiIH0pO1xuICAgIGZpcmVFdmVudC5jaGFuZ2UocGlja2VyKGNvbnRhaW5lciksIHsgdGFyZ2V0OiB7IGZpbGVzOiBbZmlsZV0gfSB9KTtcblxuICAgIGV4cGVjdCh1cGxvYWQpLnRvSGF2ZUJlZW5DYWxsZWRXaXRoKHdvcmt0cmVlLCBcIi9cIiwgW2ZpbGVdKTtcbiAgfSk7XG5cbiAgaXQoXCJ1cGxvYWRzIGludG8gdGhlIHNlbGVjdGVkIGRpcmVjdG9yeSAoYW5kIHRoZSByb3cgZXhwb3NlcyBpdHMgc2VsZWN0aW9uKVwiLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgdXNlciA9IHVzZXJFdmVudC5zZXR1cCgpO1xuICAgIGNvbnN0IHVwbG9hZCA9IHZpLmZuKCgpID0+IFByb21pc2UucmVzb2x2ZSgpKTtcbiAgICBjb25zdCB7IGNvbnRhaW5lciB9ID0gcmVuZGVyKFxuICAgICAgPEZpbGVFeHBsb3JlclZpZXcgcm9vdHM9e1t3b3JrdHJlZV19IGZzPXtmYWtlRnN9IGFjdGlvbnM9e3sgdXBsb2FkIH19IC8+LFxuICAgICk7XG4gICAgYXdhaXQgc2NyZWVuLmZpbmRCeVRleHQoXCJzcmNcIik7XG4gICAgYXdhaXQgdXNlci5jbGljayhzY3JlZW4uZ2V0QnlUZXh0KFwic3JjXCIpKTtcblxuICAgIC8vIFRoZSBjbGlja2VkIGZvbGRlciBpcyBzZWxlY3RlZCwgYW5kIHRoZSBidXR0b24ncyBsYWJlbCBuYW1lcyBpdCBhcyB0aGVcbiAgICAvLyBkZXN0aW5hdGlvbiDigJQgdGhlIHJ1bGUgaXMgZGlzY292ZXJhYmxlIG9uIHRoZSBhZmZvcmRhbmNlIGl0c2VsZi5cbiAgICBleHBlY3Qoc2NyZWVuLmdldEJ5Um9sZShcInRyZWVpdGVtXCIsIHsgbmFtZTogXCJzcmNcIiB9KSkudG9IYXZlQXR0cmlidXRlKFxuICAgICAgXCJhcmlhLXNlbGVjdGVkXCIsXG4gICAgICBcInRydWVcIixcbiAgICApO1xuICAgIGZpcmVFdmVudC5jbGljayhzY3JlZW4uZ2V0QnlSb2xlKFwiYnV0dG9uXCIsIHsgbmFtZTogXCJVcGxvYWQgZmlsZXMgdG8gL3NyY1wiIH0pKTtcbiAgICBjb25zdCBmaWxlID0gbmV3IEZpbGUoW1wiaGVsbG9cIl0sIFwibm90ZS50eHRcIiwgeyB0eXBlOiBcInRleHQvcGxhaW5cIiB9KTtcbiAgICBmaXJlRXZlbnQuY2hhbmdlKHBpY2tlcihjb250YWluZXIpLCB7IHRhcmdldDogeyBmaWxlczogW2ZpbGVdIH0gfSk7XG5cbiAgICBleHBlY3QodXBsb2FkKS50b0hhdmVCZWVuQ2FsbGVkV2l0aCh3b3JrdHJlZSwgXCIvc3JjXCIsIFtmaWxlXSk7XG4gIH0pO1xuXG4gIGl0KFwidXBsb2FkcyBpbnRvIHRoZSBzZWxlY3RlZCBmaWxlJ3MgcGFyZW50LCBzbyBpdCBiZWNvbWVzIGEgc2libGluZ1wiLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgdXNlciA9IHVzZXJFdmVudC5zZXR1cCgpO1xuICAgIGNvbnN0IHVwbG9hZCA9IHZpLmZuKCgpID0+IFByb21pc2UucmVzb2x2ZSgpKTtcbiAgICBjb25zdCB7IGNvbnRhaW5lciB9ID0gcmVuZGVyKFxuICAgICAgPEZpbGVFeHBsb3JlclZpZXcgcm9vdHM9e1t3b3JrdHJlZV19IGZzPXtmYWtlRnN9IGFjdGlvbnM9e3sgdXBsb2FkIH19IC8+LFxuICAgICk7XG4gICAgYXdhaXQgdXNlci5jbGljayhhd2FpdCBzY3JlZW4uZmluZEJ5VGV4dChcInNyY1wiKSk7XG4gICAgYXdhaXQgc2NyZWVuLmZpbmRCeVRleHQoXCJpbmRleC50c1wiKTtcbiAgICBhd2FpdCB1c2VyLmNsaWNrKHNjcmVlbi5nZXRCeVRleHQoXCJpbmRleC50c1wiKSk7XG5cbiAgICBmaXJlRXZlbnQuY2xpY2soc2NyZWVuLmdldEJ5Um9sZShcImJ1dHRvblwiLCB7IG5hbWU6IFwiVXBsb2FkIGZpbGVzIHRvIC9zcmNcIiB9KSk7XG4gICAgY29uc3QgZmlsZSA9IG5ldyBGaWxlKFtcImhlbGxvXCJdLCBcIm5vdGUudHh0XCIsIHsgdHlwZTogXCJ0ZXh0L3BsYWluXCIgfSk7XG4gICAgZmlyZUV2ZW50LmNoYW5nZShwaWNrZXIoY29udGFpbmVyKSwgeyB0YXJnZXQ6IHsgZmlsZXM6IFtmaWxlXSB9IH0pO1xuXG4gICAgZXhwZWN0KHVwbG9hZCkudG9IYXZlQmVlbkNhbGxlZFdpdGgod29ya3RyZWUsIFwiL3NyY1wiLCBbZmlsZV0pO1xuICB9KTtcblxuICBpdChcImEgc2VsZWN0aW9uIGluc2lkZSBhIHJlYWQtb25seSBzY29wZSBmYWxscyBiYWNrIHRvIHRoZSByZXBvIHJvb3RcIiwgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHVzZXIgPSB1c2VyRXZlbnQuc2V0dXAoKTtcbiAgICBjb25zdCB1cGxvYWQgPSB2aS5mbigoKSA9PiBQcm9taXNlLnJlc29sdmUoKSk7XG4gICAgY29uc3QgeyBjb250YWluZXIgfSA9IHJlbmRlcihcbiAgICAgIDxGaWxlRXhwbG9yZXJWaWV3XG4gICAgICAgIHJvb3RzPXtbd29ya3RyZWUsIHJvU3BhY2VdfVxuICAgICAgICBmcz17ZmFrZUZzfVxuICAgICAgICBhY3Rpb25zPXt7IHVwbG9hZCB9fVxuICAgICAgLz4sXG4gICAgKTtcbiAgICBhd2FpdCB1c2VyLmNsaWNrKGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KFwibm90ZS5tZFwiKSk7XG5cbiAgICBmaXJlRXZlbnQuY2xpY2soc2NyZWVuLmdldEJ5Um9sZShcImJ1dHRvblwiLCB7IG5hbWU6IFwiVXBsb2FkIGZpbGVzIHRvIHRoZSByZXBvIHJvb3RcIiB9KSk7XG4gICAgY29uc3QgZmlsZSA9IG5ldyBGaWxlKFtcImhlbGxvXCJdLCBcIm5vdGUudHh0XCIsIHsgdHlwZTogXCJ0ZXh0L3BsYWluXCIgfSk7XG4gICAgZmlyZUV2ZW50LmNoYW5nZShwaWNrZXIoY29udGFpbmVyKSwgeyB0YXJnZXQ6IHsgZmlsZXM6IFtmaWxlXSB9IH0pO1xuXG4gICAgZXhwZWN0KHVwbG9hZCkudG9IYXZlQmVlbkNhbGxlZFdpdGgod29ya3RyZWUsIFwiL1wiLCBbZmlsZV0pO1xuICB9KTtcblxuICBpdChcImhpZGVzIHRoZSBidXR0b24gd2hlbiB0aGVyZSBpcyBubyB3cml0YWJsZSByb290IChubyBzaG93bi10aGVuLUVST0ZTKVwiLCBhc3luYyAoKSA9PiB7XG4gICAgcmVuZGVyKFxuICAgICAgPEZpbGVFeHBsb3JlclZpZXcgcm9vdHM9e1tyb1NwYWNlXX0gZnM9e2Zha2VGc30gYWN0aW9ucz17eyB1cGxvYWQ6IHZpLmZuKCkgfX0gLz4sXG4gICAgKTtcbiAgICBhd2FpdCBzY3JlZW4uZmluZEJ5VGV4dChcIm5vdGUubWRcIik7XG4gICAgZXhwZWN0KHNjcmVlbi5xdWVyeUJ5Um9sZShcImJ1dHRvblwiLCB7IG5hbWU6IC9eVXBsb2FkIGZpbGVzIHRvLyB9KSkubm90LnRvQmVJblRoZURvY3VtZW50KCk7XG4gIH0pO1xuXG4gIGl0KFwicmVzb2x2ZXMgdGhlIGRlc3RpbmF0aW9uIHVuZGVyIHRoZSBzZWxlY3Rpb24ncyBPV04gd3JpdGFibGUgcm9vdCwgbm90IGp1c3QgdGhlIGZpcnN0XCIsIGFzeW5jICgpID0+IHtcbiAgICAvLyBBIHNlY29uZCBXUklUQUJMRSByb290OiDCpzUncyBcImEgZGlyZWN0b3J5IOKGkiB0aGF0IGRpcmVjdG9yeVwiIG11c3QgaG9sZCBpblxuICAgIC8vIGFueSB3cml0YWJsZSBzY29wZS4gVGhlIGRlc3RpbmF0aW9uIGlzIHJlbGF0aXZpemVkIGFnYWluc3QgdGhlIHNlbGVjdGlvbidzXG4gICAgLy8gb3duaW5nIHJvb3Qg4oCUIGEgYmxpbmQgc2xpY2UgYWdhaW5zdCB0aGUgcmVwbyByb290IHdvdWxkIGNvcnJ1cHQgYm90aCB0aGVcbiAgICAvLyBsYWJlbCBhbmQgdGhlIHVwbG9hZCBwYXRoIChyZXZpZXcgcm91bmQgMSwgUjEpLlxuICAgIGNvbnN0IHVzZXIgPSB1c2VyRXZlbnQuc2V0dXAoKTtcbiAgICBjb25zdCB1cGxvYWQgPSB2aS5mbigoKSA9PiBQcm9taXNlLnJlc29sdmUoKSk7XG4gICAgY29uc3QgcndTcGFjZTogRXhwbG9yZXJSb290ID0ge1xuICAgICAgLi4ucm9TcGFjZSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgc2NvcGVzOiBbeyBzdWJ0cmVlOiBcIi9cIiwgbW9kZTogXCJyd1wiIH1dLFxuICAgIH07XG4gICAgY29uc3QgeyBjb250YWluZXIgfSA9IHJlbmRlcihcbiAgICAgIDxGaWxlRXhwbG9yZXJWaWV3IHJvb3RzPXtbd29ya3RyZWUsIHJ3U3BhY2VdfSBmcz17ZmFrZUZzfSBhY3Rpb25zPXt7IHVwbG9hZCB9fSAvPixcbiAgICApO1xuXG4gICAgLy8gQSBzZWxlY3RlZCBESVJFQ1RPUlkgaW4gdGhlIHNwYWNlIHVwbG9hZHMgaW50byB0aGF0IGRpciB1bmRlciB0aGUgc3BhY2UuXG4gICAgYXdhaXQgdXNlci5jbGljayhhd2FpdCBzY3JlZW4uZmluZEJ5VGV4dChcImRvY3NcIikpO1xuICAgIGZpcmVFdmVudC5jbGljayhzY3JlZW4uZ2V0QnlSb2xlKFwiYnV0dG9uXCIsIHsgbmFtZTogXCJVcGxvYWQgZmlsZXMgdG8gL2RvY3NcIiB9KSk7XG4gICAgY29uc3QgZmlsZSA9IG5ldyBGaWxlKFtcImhlbGxvXCJdLCBcIm4udHh0XCIsIHsgdHlwZTogXCJ0ZXh0L3BsYWluXCIgfSk7XG4gICAgZmlyZUV2ZW50LmNoYW5nZShwaWNrZXIoY29udGFpbmVyKSwgeyB0YXJnZXQ6IHsgZmlsZXM6IFtmaWxlXSB9IH0pO1xuICAgIGV4cGVjdCh1cGxvYWQpLnRvSGF2ZUJlZW5DYWxsZWRXaXRoKHJ3U3BhY2UsIFwiL2RvY3NcIiwgW2ZpbGVdKTtcblxuICAgIC8vIEEgc2VsZWN0ZWQgRklMRSBhdCB0aGUgc3BhY2UncyB0b3AgbGV2ZWwgdXBsb2FkcyBuZXh0IHRvIGl0IOKAlCB0aGUgc3BhY2Unc1xuICAgIC8vIG93biByb290LCBuYW1lZCBob25lc3RseSAobm90IFwidGhlIHJlcG8gcm9vdFwiKS5cbiAgICBhd2FpdCB1c2VyLmNsaWNrKGF3YWl0IHNjcmVlbi5maW5kQnlUZXh0KFwibm90ZS5tZFwiKSk7XG4gICAgZmlyZUV2ZW50LmNsaWNrKHNjcmVlbi5nZXRCeVJvbGUoXCJidXR0b25cIiwgeyBuYW1lOiBcIlVwbG9hZCBmaWxlcyB0byB0aGUgczEgcm9vdFwiIH0pKTtcbiAgICBmaXJlRXZlbnQuY2hhbmdlKHBpY2tlcihjb250YWluZXIpLCB7IHRhcmdldDogeyBmaWxlczogW2ZpbGVdIH0gfSk7XG4gICAgZXhwZWN0KHVwbG9hZCkudG9IYXZlQmVlbkxhc3RDYWxsZWRXaXRoKHJ3U3BhY2UsIFwiL1wiLCBbZmlsZV0pO1xuICB9KTtcblxuICBpdChcInNlbGVjdGlvbk1vZGU9XFxcIm5vbmVcXFwiIG5hdmlnYXRpb24gd3JpdGVzIG5vIHNlbGVjdGlvbiDigJQgdGhlIGRlc3RpbmF0aW9uIHN0YXlzIHRoZSByZXBvIHJvb3RcIiwgYXN5bmMgKCkgPT4ge1xuICAgIC8vIFJldmlldyByb3VuZCAyLCBSMTogdGhlIHRyZWUncyBhY3RpdmF0aW9uIHBhdGggZ2F0ZXMgc2VsZWN0aW9uIG9uXG4gICAgLy8gYHNlbGVjdGlvbk1vZGUgIT09IFwibm9uZVwiYDsgZmxhdC1sYXlvdXQgbmF2aWdhdGlvbiBtdXN0IG5vdCBiZSB0aGUgbGVhay5cbiAgICBjb25zdCB1c2VyID0gdXNlckV2ZW50LnNldHVwKCk7XG4gICAgY29uc3QgdXBsb2FkID0gdmkuZm4oKCkgPT4gUHJvbWlzZS5yZXNvbHZlKCkpO1xuICAgIGNvbnN0IHsgY29udGFpbmVyIH0gPSByZW5kZXIoXG4gICAgICA8RmlsZUV4cGxvcmVyVmlld1xuICAgICAgICByb290cz17W3dvcmt0cmVlXX1cbiAgICAgICAgZnM9e2Zha2VGc31cbiAgICAgICAgYWN0aW9ucz17eyB1cGxvYWQgfX1cbiAgICAgICAgbGF5b3V0PVwibGlzdFwiXG4gICAgICAgIHNlbGVjdGlvbk1vZGU9XCJub25lXCJcbiAgICAgIC8+LFxuICAgICk7XG4gICAgLy8gRW50ZXIgdGhlIHNpbmdsZSBtb3VudCwgdGhlbiBicm93c2UgSU5UTyBzcmMg4oCUIG5hdmlnYXRpb24gb25seS5cbiAgICBhd2FpdCB1c2VyLmNsaWNrKGF3YWl0IHNjcmVlbi5maW5kQnlSb2xlKFwib3B0aW9uXCIsIHsgbmFtZTogL15yZXBvLyB9KSk7XG4gICAgYXdhaXQgdXNlci5jbGljayhhd2FpdCBzY3JlZW4uZmluZEJ5Um9sZShcIm9wdGlvblwiLCB7IG5hbWU6IC9ec3JjLyB9KSk7XG5cbiAgICBmaXJlRXZlbnQuY2xpY2soc2NyZWVuLmdldEJ5Um9sZShcImJ1dHRvblwiLCB7IG5hbWU6IFwiVXBsb2FkIGZpbGVzIHRvIHRoZSByZXBvIHJvb3RcIiB9KSk7XG4gICAgZmlyZUV2ZW50LmNoYW5nZShwaWNrZXIoY29udGFpbmVyKSwge1xuICAgICAgdGFyZ2V0OiB7IGZpbGVzOiBbbmV3IEZpbGUoW1wiaGVsbG9cIl0sIFwibi50eHRcIiwgeyB0eXBlOiBcInRleHQvcGxhaW5cIiB9KV0gfSxcbiAgICB9KTtcbiAgICBleHBlY3QodXBsb2FkKS50b0hhdmVCZWVuQ2FsbGVkV2l0aCh3b3JrdHJlZSwgXCIvXCIsIFtcbiAgICAgIGV4cGVjdC5vYmplY3RDb250YWluaW5nKHsgbmFtZTogXCJuLnR4dFwiIH0pLFxuICAgIF0pO1xuICB9KTtcbn0pO1xuXG4vLyAtLS0gZXZlcnkgbGF5b3V0J3Mgcm93cyBleHBvc2UgdGhlIG1lbnUgYnkga2V5Ym9hcmQgKENvbnRleHRNZW51IC8gU2hpZnQrRjEwKSAtLS1cbmRlc2NyaWJlKFwicm93IG1lbnUga2V5IChDb250ZXh0TWVudSAvIFNoaWZ0K0YxMCkgcmVhY2hlcyBldmVyeSBsYXlvdXQncyByb3dzXCIsICgpID0+IHtcbiAgaXQoXCJsaXN0IGxheW91dDogdGhlIG1lbnUga2V5IG9uIGFuIG9wdGlvbiBvcGVucyB0aGUgcm93J3MgY29udGV4dCBtZW51XCIsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCBkZWwgPSB2aS5mbigoKSA9PiBQcm9taXNlLnJlc29sdmUoXCIvUkVBRE1FLm1kXCIpKTtcbiAgICBjb25zdCB1c2VyID0gdXNlckV2ZW50LnNldHVwKCk7XG4gICAgcmVuZGVyKFxuICAgICAgPEZpbGVFeHBsb3JlclZpZXdcbiAgICAgICAgcm9vdHM9e1t3b3JrdHJlZV19XG4gICAgICAgIGZzPXtmYWtlRnN9XG4gICAgICAgIGxheW91dD1cImxpc3RcIlxuICAgICAgICBhY3Rpb25zPXt7IGRlbGV0ZTogZGVsIH19XG4gICAgICAvPixcbiAgICApO1xuICAgIC8vIFRoZSB1bmNvbnRyb2xsZWQgbGlzdCBzdGFydHMgYXQgdGhlIHJvb3RzLXJvb3Q7IGVudGVyIHRoZSBzaW5nbGUgbW91bnQuXG4gICAgYXdhaXQgdXNlci5jbGljayhhd2FpdCBzY3JlZW4uZmluZEJ5Um9sZShcIm9wdGlvblwiLCB7IG5hbWU6IC9ecmVwby8gfSkpO1xuICAgIGNvbnN0IHJlYWRtZSA9IGF3YWl0IHNjcmVlbi5maW5kQnlSb2xlKFwib3B0aW9uXCIsIHsgbmFtZTogL1JFQURNRVxcLm1kLyB9KTtcbiAgICByZWFkbWUuZm9jdXMoKTtcbiAgICBhd2FpdCB1c2VyLmtleWJvYXJkKFwie1NoaWZ0Pn17RjEwfXsvU2hpZnR9XCIpO1xuICAgIGNvbnN0IG1lbnUgPSBhd2FpdCBzY3JlZW4uZmluZEJ5Um9sZShcIm1lbnVcIik7XG4gICAgZXhwZWN0KHdpdGhpbihtZW51KS5nZXRCeVJvbGUoXCJtZW51aXRlbVwiLCB7IG5hbWU6IC9eRGVsZXRlLyB9KSkudG9CZUluVGhlRG9jdW1lbnQoKTtcbiAgfSk7XG5cbiAgaXQoXCJ0cmVlIGxheW91dDogdGhlIENvbnRleHRNZW51IGtleSBvcGVucyB0aGUgcm93J3MgbWVudSBhdCB0aGUgcm93XCIsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCB1c2VyID0gdXNlckV2ZW50LnNldHVwKCk7XG4gICAgcmVuZGVyKDxGaWxlRXhwbG9yZXJWaWV3IHJvb3RzPXtbd29ya3RyZWVdfSBmcz17ZmFrZUZzfSBhY3Rpb25zPXt7IG9wZW46IHZpLmZuKCkgfX0gLz4pO1xuICAgIGNvbnN0IHJlYWRtZSA9IGF3YWl0IHNjcmVlbi5maW5kQnlSb2xlKFwidHJlZWl0ZW1cIiwgeyBuYW1lOiBcIlJFQURNRS5tZFwiIH0pO1xuICAgIHJlYWRtZS5mb2N1cygpO1xuICAgIGF3YWl0IHVzZXIua2V5Ym9hcmQoXCJ7Q29udGV4dE1lbnV9XCIpO1xuICAgIGNvbnN0IG1lbnUgPSBhd2FpdCBzY3JlZW4uZmluZEJ5Um9sZShcIm1lbnVcIik7XG4gICAgZXhwZWN0KHdpdGhpbihtZW51KS5nZXRCeVJvbGUoXCJtZW51aXRlbVwiLCB7IG5hbWU6IC9PcGVuLyB9KSkudG9CZUluVGhlRG9jdW1lbnQoKTtcbiAgfSk7XG59KTtcblxuLy8gLS0tIHRoZSBwaWNrZXIgaXMga2V5Ym9hcmQtb3BlcmFibGUgZW5kIHRvIGVuZCAodGhlIDIuNS43IHBhdGggaXRzZWxmKSAtLS0tLS0tLVxuZGVzY3JpYmUoXCJNb3ZlRGlhbG9nIGtleWJvYXJkXCIsICgpID0+IHtcbiAgaXQoXCJUYWIgcmVhY2hlcyB0aGUgZm9vdGVyIGJ1dHRvbnMgKE1vdmUgaGVyZSAvIENhbmNlbCkgZnJvbSB0aGUgdHJlZVwiLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgcmVuYW1lID0gdmkuZm4oKCkgPT4gUHJvbWlzZS5yZXNvbHZlKHsgbmFtZTogXCJSRUFETUUubWRcIiwgaXNEaXI6IGZhbHNlIH0pKTtcbiAgICBjb25zdCB1c2VyID0gdXNlckV2ZW50LnNldHVwKCk7XG4gICAgcmVuZGVyKDxGaWxlRXhwbG9yZXJWaWV3IHJvb3RzPXtbd29ya3RyZWVdfSBmcz17ZmFrZUZzfSBhY3Rpb25zPXt7IHJlbmFtZSB9fSAvPik7XG4gICAgYXdhaXQgc2NyZWVuLmZpbmRCeVRleHQoXCJzcmNcIik7XG4gICAgZmlyZUV2ZW50LmNvbnRleHRNZW51KHNjcmVlbi5nZXRCeVRleHQoXCJSRUFETUUubWRcIikpO1xuICAgIGNvbnN0IG1lbnUgPSBhd2FpdCBzY3JlZW4uZmluZEJ5Um9sZShcIm1lbnVcIik7XG4gICAgYXdhaXQgdXNlci5jbGljayh3aXRoaW4obWVudSkuZ2V0QnlSb2xlKFwibWVudWl0ZW1cIiwgeyBuYW1lOiAvTW92ZSB0by8gfSkpO1xuICAgIGNvbnN0IGRpYWxvZyA9IGF3YWl0IHNjcmVlbi5maW5kQnlSb2xlKFwiZGlhbG9nXCIsIHsgbmFtZTogXCJNb3ZlIFJFQURNRS5tZCB0byBhIGZvbGRlclwiIH0pO1xuXG4gICAgLy8gQ2hvb3NlIGEgZGVzdGluYXRpb24gZmlyc3Qg4oCUIFwiTW92ZSBoZXJlXCIgaXMgZGlzYWJsZWQgKG91dHNpZGUgdGhlIHRyYXApXG4gICAgLy8gdW50aWwgc29tZXRoaW5nIGlzIGNob3Nlbi5cbiAgICBhd2FpdCB1c2VyLmNsaWNrKHdpdGhpbihkaWFsb2cpLmdldEJ5Um9sZShcInRyZWVpdGVtXCIsIHsgbmFtZTogXCJzcmNcIiB9KSk7XG5cbiAgICAvLyBGb2N1cyBzdGFydHMgaW4gdGhlIHRyZWUgKHRoZSBkaWFsb2cncyBmaXJzdCBmb2N1c2FibGUpLiBUYWIgd2Fsa3MgdGhlXG4gICAgLy8gdHJlZSdzIHN0b3AsIHRoZW4gcmVhY2hlcyB0aGUgZm9vdGVyIGJ1dHRvbnMg4oCUIHRoZSB0cmFwIGJvdW5kcyB0aGUgUEFORUwuXG4gICAgY29uc3QgbGFzdFRyZWVTdG9wID0gW1xuICAgICAgLi4uZGlhbG9nLnF1ZXJ5U2VsZWN0b3JBbGw8SFRNTEVsZW1lbnQ+KCdbcm9sZT1cInRyZWVpdGVtXCJdW3RhYmluZGV4PVwiMFwiXScpLFxuICAgIF0ucG9wKCkhO1xuICAgIGxhc3RUcmVlU3RvcC5mb2N1cygpO1xuICAgIGxldCByZWFjaGVkID0gZmFsc2U7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCA2ICYmICFyZWFjaGVkOyBpKyspIHtcbiAgICAgIGF3YWl0IHVzZXIua2V5Ym9hcmQoXCJ7VGFifVwiKTtcbiAgICAgIHJlYWNoZWQgPSBkb2N1bWVudC5hY3RpdmVFbGVtZW50Py50ZXh0Q29udGVudCA9PT0gXCJNb3ZlIGhlcmVcIjtcbiAgICB9XG4gICAgZXhwZWN0KHJlYWNoZWQpLnRvQmUodHJ1ZSk7XG4gICAgZXhwZWN0KGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQpLnRvQmUoXG4gICAgICB3aXRoaW4oZGlhbG9nKS5nZXRCeVJvbGUoXCJidXR0b25cIiwgeyBuYW1lOiBcIk1vdmUgaGVyZVwiIH0pLFxuICAgICk7XG4gIH0pO1xufSk7XG5cbi8vIC0tLSBBcnJvd1JpZ2h0IHN0ZXBzIGludG8gYW4gb3BlbiBmb2xkZXIncyBmaXJzdCBjaGlsZCAoQVBHIFRyZWUgVmlldykgLS0tLS0tLS1cbmRlc2NyaWJlKFwidHJlZSBBcnJvd1JpZ2h0IHN0ZXAtaW5cIiwgKCkgPT4ge1xuICBpdChcIkFycm93UmlnaHQgb24gYW4gT1BFTiBmb2xkZXIgZm9jdXNlcyBpdHMgZmlyc3QgY2hpbGQgcm93XCIsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCB1c2VyID0gdXNlckV2ZW50LnNldHVwKCk7XG4gICAgcmVuZGVyKDxGaWxlRXhwbG9yZXJWaWV3IHJvb3RzPXtbd29ya3RyZWVdfSBmcz17ZmFrZUZzfSAvPik7XG4gICAgYXdhaXQgc2NyZWVuLmZpbmRCeVRleHQoXCJzcmNcIik7XG4gICAgYXdhaXQgdXNlci5jbGljayhzY3JlZW4uZ2V0QnlUZXh0KFwic3JjXCIpKTtcbiAgICBhd2FpdCBzY3JlZW4uZmluZEJ5VGV4dChcImluZGV4LnRzXCIpO1xuXG4gICAgc2NyZWVuLmdldEJ5Um9sZShcInRyZWVpdGVtXCIsIHsgbmFtZTogXCJzcmNcIiB9KS5mb2N1cygpO1xuICAgIGF3YWl0IHVzZXIua2V5Ym9hcmQoXCJ7QXJyb3dSaWdodH1cIik7XG4gICAgZXhwZWN0KHNjcmVlbi5nZXRCeVJvbGUoXCJ0cmVlaXRlbVwiLCB7IG5hbWU6IFwiaW5kZXgudHNcIiB9KSkudG9IYXZlRm9jdXMoKTtcbiAgfSk7XG59KTtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7QUFJQSxJQUFBQSxNQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxVQUFBLEdBQUFDLHNCQUFBLENBQUFGLE9BQUE7QUFFQSxJQUFBRyxPQUFBLEdBQUFILE9BQUE7QUFDQSxJQUFBSSxpQkFBQSxHQUFBRixzQkFBQSxDQUFBRixPQUFBO0FBQWtELElBQUFLLFdBQUEsR0FBQUwsT0FBQTtBQUFBLFNBQUFFLHVCQUFBSSxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBUmxEO0FBQ0E7QUFDQTtBQUNBOztBQVFBO0FBQ0E7QUFDQTtBQUNBLE1BQU1HLElBQWdDLEdBQUc7RUFDdkMsVUFBVSxFQUFFLENBQ1Y7SUFBRUMsSUFBSSxFQUFFLEtBQUs7SUFBRUMsS0FBSyxFQUFFO0VBQUssQ0FBQyxFQUM1QjtJQUFFRCxJQUFJLEVBQUUsV0FBVztJQUFFQyxLQUFLLEVBQUU7RUFBTSxDQUFDLENBQ3BDO0VBQ0QsY0FBYyxFQUFFLENBQ2Q7SUFBRUQsSUFBSSxFQUFFLFVBQVU7SUFBRUMsS0FBSyxFQUFFO0VBQU0sQ0FBQyxFQUNsQztJQUFFRCxJQUFJLEVBQUUsU0FBUztJQUFFQyxLQUFLLEVBQUU7RUFBTSxDQUFDLENBQ2xDO0VBQ0QsWUFBWSxFQUFFLENBQ1o7SUFBRUQsSUFBSSxFQUFFLE1BQU07SUFBRUMsS0FBSyxFQUFFO0VBQUssQ0FBQyxFQUM3QjtJQUFFRCxJQUFJLEVBQUUsU0FBUztJQUFFQyxLQUFLLEVBQUU7RUFBTSxDQUFDLENBQ2xDO0VBQ0QsaUJBQWlCLEVBQUUsQ0FBQztJQUFFRCxJQUFJLEVBQUUsTUFBTTtJQUFFQyxLQUFLLEVBQUU7RUFBTSxDQUFDO0FBQ3BELENBQUM7QUFFRCxNQUFNQyxPQUFPLEdBQUdDLFVBQUUsQ0FBQ0MsRUFBRSxDQUFFQyxJQUFZLElBQUtDLE9BQU8sQ0FBQ0MsT0FBTyxDQUFDUixJQUFJLENBQUNNLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDO0FBQzFFLE1BQU1HLE1BQWdCLEdBQUc7RUFDdkJOLE9BQU87RUFDUE8sUUFBUSxFQUFFQSxDQUFBLEtBQU1ILE9BQU8sQ0FBQ0MsT0FBTyxDQUFDLElBQUlHLFVBQVUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDM0QsQ0FBQztBQUVELE1BQU1DLFdBQVcsR0FBRyxDQUNsQjtFQUFFWCxJQUFJLEVBQUUsVUFBVTtFQUFFQyxLQUFLLEVBQUU7QUFBTSxDQUFDLEVBQ2xDO0VBQUVELElBQUksRUFBRSxTQUFTO0VBQUVDLEtBQUssRUFBRTtBQUFNLENBQUMsQ0FDbEM7QUFFRCxNQUFNVyxRQUFzQixHQUFHO0VBQzdCQyxFQUFFLEVBQUUsTUFBTTtFQUNWUixJQUFJLEVBQUUsVUFBVTtFQUNoQlMsS0FBSyxFQUFFLE1BQU07RUFDYkMsSUFBSSxFQUFFLFVBQVU7RUFDaEJDLFFBQVEsRUFBRSxJQUFJO0VBQ2RDLE1BQU0sRUFBRSxDQUFDO0lBQUVDLE9BQU8sRUFBRSxHQUFHO0lBQUVDLElBQUksRUFBRTtFQUFLLENBQUMsQ0FBQztFQUN0Q0MsU0FBUyxFQUFFO0FBQ2IsQ0FBQzs7QUFFRDtBQUNBO0FBQ0EsTUFBTUMsT0FBcUIsR0FBRztFQUM1QlIsRUFBRSxFQUFFLFVBQVU7RUFDZFIsSUFBSSxFQUFFLFlBQVk7RUFDbEJTLEtBQUssRUFBRSxJQUFJO0VBQ1hDLElBQUksRUFBRSxPQUFPO0VBQ2JDLFFBQVEsRUFBRSxLQUFLO0VBQ2ZDLE1BQU0sRUFBRSxDQUFDO0lBQUVDLE9BQU8sRUFBRSxHQUFHO0lBQUVDLElBQUksRUFBRTtFQUFLLENBQUMsQ0FBQztFQUN0Q0MsU0FBUyxFQUFFO0FBQ2IsQ0FBQztBQUVELElBQUFFLGtCQUFVLEVBQUMsTUFBTTtFQUNmcEIsT0FBTyxDQUFDcUIsU0FBUyxDQUFDLENBQUM7RUFDbkJ4QixJQUFJLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxHQUFHWSxXQUFXLENBQUM7QUFDekMsQ0FBQyxDQUFDO0FBQ0YsSUFBQWEsaUJBQVMsRUFBQyxNQUFNckIsVUFBRSxDQUFDc0IsYUFBYSxDQUFDLENBQUMsQ0FBQztBQUVuQyxJQUFBQyxnQkFBUSxFQUFDLHFDQUFxQyxFQUFFLE1BQU07RUFDcEQsSUFBQUMsVUFBRSxFQUFDLGdGQUFnRixFQUFFLFlBQVk7SUFDL0YsTUFBTUMsSUFBSSxHQUFHQyxrQkFBUyxDQUFDQyxLQUFLLENBQUMsQ0FBQztJQUM5QixJQUFBQyxhQUFNLGVBQUMsSUFBQXBDLFdBQUEsQ0FBQXFDLEdBQUEsRUFBQ3RDLGlCQUFBLENBQUFJLE9BQWdCO01BQUNtQyxLQUFLLEVBQUUsQ0FBQ3JCLFFBQVEsQ0FBRTtNQUFDc0IsRUFBRSxFQUFFMUI7SUFBTyxDQUFFLENBQUMsQ0FBQzs7SUFFM0Q7SUFDQSxJQUFBMkIsY0FBTSxFQUFDLE1BQU1DLGFBQU0sQ0FBQ0MsVUFBVSxDQUFDLE1BQU0sRUFBRTtNQUFFckMsSUFBSSxFQUFFO0lBQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQ3NDLGlCQUFpQixDQUFDLENBQUM7SUFDN0UsTUFBTUYsYUFBTSxDQUFDRyxVQUFVLENBQUMsS0FBSyxDQUFDO0lBQzlCLElBQUFKLGNBQU0sRUFBQ2pDLE9BQU8sQ0FBQyxDQUFDc0Msb0JBQW9CLENBQUMsVUFBVSxDQUFDOztJQUVoRDtJQUNBLE1BQU1aLElBQUksQ0FBQ2EsS0FBSyxDQUFDTCxhQUFNLENBQUNNLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUN6QyxNQUFNTixhQUFNLENBQUNHLFVBQVUsQ0FBQyxVQUFVLENBQUM7SUFDbkMsSUFBQUosY0FBTSxFQUFDakMsT0FBTyxDQUFDLENBQUNzQyxvQkFBb0IsQ0FBQyxjQUFjLENBQUM7RUFDdEQsQ0FBQyxDQUFDO0VBRUYsSUFBQWIsVUFBRSxFQUFDLGdHQUFnRyxFQUFFLFlBQVk7SUFDL0csTUFBTTtNQUFFZ0I7SUFBUyxDQUFDLEdBQUcsSUFBQVosYUFBTSxlQUN6QixJQUFBcEMsV0FBQSxDQUFBcUMsR0FBQSxFQUFDdEMsaUJBQUEsQ0FBQUksT0FBZ0I7TUFBQ21DLEtBQUssRUFBRSxDQUFDckIsUUFBUSxDQUFFO01BQUNzQixFQUFFLEVBQUUxQixNQUFPO01BQUNvQyxVQUFVLEVBQUMsWUFBWTtNQUFDQyxVQUFVLEVBQUM7SUFBWSxDQUFFLENBQ3BHLENBQUM7SUFDRDtJQUNBLE1BQU1DLE1BQU0sR0FBRyxNQUFNVixhQUFNLENBQUNXLGVBQWUsQ0FBQywwQkFBMEIsQ0FBQztJQUN2RSxJQUFBWixjQUFNLEVBQUNXLE1BQU0sQ0FBQyxDQUFDUixpQkFBaUIsQ0FBQyxDQUFDO0lBQ2xDLE1BQU1VLEdBQUcsR0FBR1osYUFBTSxDQUFDTSxTQUFTLENBQUMsV0FBVyxDQUFDLENBQUNPLE9BQU8sQ0FBQyxRQUFRLENBQUU7SUFDNUQsSUFBQWQsY0FBTSxFQUFDYSxHQUFHLENBQUNFLFNBQVMsQ0FBQyxDQUFDQyxTQUFTLENBQUMsZUFBZSxDQUFDO0lBQ2hELElBQUFoQixjQUFNLEVBQUNhLEdBQUcsQ0FBQ0UsU0FBUyxDQUFDLENBQUNDLFNBQVMsQ0FBQyxlQUFlLENBQUM7SUFDaEQ7SUFDQSxJQUFBaEIsY0FBTSxFQUFDYSxHQUFHLENBQUNFLFNBQVMsQ0FBQyxDQUFDRSxHQUFHLENBQUNELFNBQVMsQ0FBQyxpQkFBaUIsQ0FBQztJQUN0RDtJQUNBUixRQUFRLGNBQ04sSUFBQWhELFdBQUEsQ0FBQXFDLEdBQUEsRUFBQ3RDLGlCQUFBLENBQUFJLE9BQWdCO01BQUNtQyxLQUFLLEVBQUUsQ0FBQ3JCLFFBQVEsQ0FBRTtNQUFDc0IsRUFBRSxFQUFFMUIsTUFBTztNQUFDb0MsVUFBVSxFQUFDLFlBQVk7TUFBQ0MsVUFBVSxFQUFFO0lBQUssQ0FBRSxDQUM5RixDQUFDO0lBQ0QsSUFBQVYsY0FBTSxFQUFDQyxhQUFNLENBQUNpQixnQkFBZ0IsQ0FBQywwQkFBMEIsQ0FBQyxDQUFDLENBQUNDLFFBQVEsQ0FBQyxDQUFDO0lBQ3RFLElBQUFuQixjQUFNLEVBQUNhLEdBQUcsQ0FBQ0UsU0FBUyxDQUFDLENBQUNDLFNBQVMsQ0FBQyxlQUFlLENBQUM7RUFDbEQsQ0FBQyxDQUFDO0VBRUYsSUFBQXhCLFVBQUUsRUFBQyx5RkFBeUYsRUFBRSxZQUFZO0lBQ3hHLE1BQU1DLElBQUksR0FBR0Msa0JBQVMsQ0FBQ0MsS0FBSyxDQUFDLENBQUM7SUFDOUIsTUFBTXlCLElBQUksR0FBR3BELFVBQUUsQ0FBQ0MsRUFBRSxDQUFDLENBQUM7SUFDcEIsTUFBTW9ELFVBQVUsR0FBR3JELFVBQUUsQ0FBQ0MsRUFBRSxDQUFDLENBQUM7SUFDMUIsTUFBTXFELFFBQVEsR0FBR3RELFVBQUUsQ0FBQ0MsRUFBRSxDQUFDLENBQUM7SUFDeEIsSUFBQTJCLGFBQU0sZUFDSixJQUFBcEMsV0FBQSxDQUFBcUMsR0FBQSxFQUFDdEMsaUJBQUEsQ0FBQUksT0FBZ0I7TUFDZm1DLEtBQUssRUFBRSxDQUFDckIsUUFBUSxDQUFFO01BQ2xCc0IsRUFBRSxFQUFFMUIsTUFBTztNQUNYa0QsT0FBTyxFQUFFO1FBQUVIO01BQUssQ0FBRTtNQUNsQkMsVUFBVSxFQUFFQSxVQUFXO01BQ3ZCQyxRQUFRLEVBQUVBO0lBQVMsQ0FDcEIsQ0FDSCxDQUFDO0lBQ0QsTUFBTXJCLGFBQU0sQ0FBQ0csVUFBVSxDQUFDLEtBQUssQ0FBQztJQUM5QixNQUFNWCxJQUFJLENBQUNhLEtBQUssQ0FBQ0wsYUFBTSxDQUFDTSxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDekMsTUFBTWQsSUFBSSxDQUFDYSxLQUFLLENBQUMsTUFBTUwsYUFBTSxDQUFDRyxVQUFVLENBQUMsVUFBVSxDQUFDLENBQUM7SUFFckQsSUFBQUosY0FBTSxFQUFDb0IsSUFBSSxDQUFDLENBQUNmLG9CQUFvQixDQUFDNUIsUUFBUSxFQUFFLGVBQWUsQ0FBQztJQUM1RCxJQUFBdUIsY0FBTSxFQUFDcUIsVUFBVSxDQUFDLENBQUNoQixvQkFBb0IsQ0FBQzVCLFFBQVEsRUFBRSxlQUFlLEVBQUUsS0FBSyxDQUFDO0lBQ3pFLElBQUF1QixjQUFNLEVBQUNzQixRQUFRLENBQUMsQ0FBQ2pCLG9CQUFvQixDQUFDNUIsUUFBUSxFQUFFLGVBQWUsQ0FBQztJQUNoRTtJQUNBLElBQUF1QixjQUFNLEVBQUNDLGFBQU0sQ0FBQ3VCLFNBQVMsQ0FBQyxVQUFVLEVBQUU7TUFBRTNELElBQUksRUFBRTtJQUFXLENBQUMsQ0FBQyxDQUFDLENBQUM0RCxlQUFlLENBQUMsZUFBZSxFQUFFLE1BQU0sQ0FBQztFQUNyRyxDQUFDLENBQUM7RUFFRixJQUFBakMsVUFBRSxFQUFDLHlGQUF5RixFQUFFLFlBQVk7SUFDeEcsSUFBQUksYUFBTSxlQUFDLElBQUFwQyxXQUFBLENBQUFxQyxHQUFBLEVBQUN0QyxpQkFBQSxDQUFBSSxPQUFnQjtNQUFDbUMsS0FBSyxFQUFFLENBQUNyQixRQUFRLENBQUU7TUFBQ3NCLEVBQUUsRUFBRTFCLE1BQU87TUFBQ2tELE9BQU8sRUFBRTtRQUFFSCxJQUFJLEVBQUVwRCxVQUFFLENBQUNDLEVBQUUsQ0FBQztNQUFFO0lBQUUsQ0FBRSxDQUFDLENBQUM7SUFDdkYsTUFBTWdDLGFBQU0sQ0FBQ0csVUFBVSxDQUFDLFdBQVcsQ0FBQztJQUNwQztJQUNBLElBQUFKLGNBQU0sRUFBQ0MsYUFBTSxDQUFDaUIsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQ0QsR0FBRyxDQUFDZCxpQkFBaUIsQ0FBQyxDQUFDO0lBQ25FO0lBQ0E7SUFDQSxJQUFBSCxjQUFNLEVBQUNDLGFBQU0sQ0FBQ3lCLFdBQVcsQ0FBQyxRQUFRLEVBQUU7TUFBRTdELElBQUksRUFBRTtJQUFtQixDQUFDLENBQUMsQ0FBQyxDQUFDb0QsR0FBRyxDQUFDZCxpQkFBaUIsQ0FBQyxDQUFDO0lBQzFGO0lBQ0F3QixnQkFBUyxDQUFDQyxXQUFXLENBQUMzQixhQUFNLENBQUNNLFNBQVMsQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUNwRCxNQUFNc0IsSUFBSSxHQUFHLE1BQU01QixhQUFNLENBQUNDLFVBQVUsQ0FBQyxNQUFNLENBQUM7SUFDNUMsSUFBQUYsY0FBTSxFQUFDLElBQUE4QixhQUFNLEVBQUNELElBQUksQ0FBQyxDQUFDTCxTQUFTLENBQUMsVUFBVSxFQUFFO01BQUUzRCxJQUFJLEVBQUU7SUFBTyxDQUFDLENBQUMsQ0FBQyxDQUFDc0MsaUJBQWlCLENBQUMsQ0FBQztJQUNoRixJQUFBSCxjQUFNLEVBQUMsSUFBQThCLGFBQU0sRUFBQ0QsSUFBSSxDQUFDLENBQUNILFdBQVcsQ0FBQyxVQUFVLEVBQUU7TUFBRTdELElBQUksRUFBRTtJQUFTLENBQUMsQ0FBQyxDQUFDLENBQUNvRCxHQUFHLENBQUNkLGlCQUFpQixDQUFDLENBQUM7SUFDeEYsSUFBQUgsY0FBTSxFQUFDLElBQUE4QixhQUFNLEVBQUNELElBQUksQ0FBQyxDQUFDSCxXQUFXLENBQUMsVUFBVSxFQUFFO01BQUU3RCxJQUFJLEVBQUU7SUFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQ29ELEdBQUcsQ0FBQ2QsaUJBQWlCLENBQUMsQ0FBQztFQUNqRyxDQUFDLENBQUM7RUFFRixJQUFBWCxVQUFFLEVBQUMsa0lBQWtJLEVBQUUsWUFBWTtJQUNqSjtJQUNBO0lBQ0EsTUFBTXVDLEdBQUcsR0FBRy9ELFVBQUUsQ0FBQ0MsRUFBRSxDQUFDLE1BQU07TUFDdEJMLElBQUksQ0FBQyxjQUFjLENBQUMsR0FBR0EsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDb0UsTUFBTSxDQUFFdkUsQ0FBQyxJQUFLQSxDQUFDLENBQUNJLElBQUksS0FBSyxVQUFVLENBQUM7TUFDaEYsT0FBT00sT0FBTyxDQUFDQyxPQUFPLENBQUMsZUFBZSxDQUFDO0lBQ3pDLENBQUMsQ0FBQztJQUNGLE1BQU1xQixJQUFJLEdBQUdDLGtCQUFTLENBQUNDLEtBQUssQ0FBQyxDQUFDO0lBQzlCLElBQUFDLGFBQU0sZUFBQyxJQUFBcEMsV0FBQSxDQUFBcUMsR0FBQSxFQUFDdEMsaUJBQUEsQ0FBQUksT0FBZ0I7TUFBQ21DLEtBQUssRUFBRSxDQUFDckIsUUFBUSxDQUFFO01BQUNzQixFQUFFLEVBQUUxQixNQUFPO01BQUNrRCxPQUFPLEVBQUU7UUFBRVUsTUFBTSxFQUFFRjtNQUFJO0lBQUUsQ0FBRSxDQUFDLENBQUM7SUFDckYsTUFBTTlCLGFBQU0sQ0FBQ0csVUFBVSxDQUFDLEtBQUssQ0FBQztJQUM5QixNQUFNWCxJQUFJLENBQUNhLEtBQUssQ0FBQ0wsYUFBTSxDQUFDTSxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDekMsTUFBTU4sYUFBTSxDQUFDRyxVQUFVLENBQUMsVUFBVSxDQUFDO0lBRW5DLE1BQU04QixPQUFPLEdBQUdsRSxVQUFFLENBQUNtRSxLQUFLLENBQUNDLE1BQU0sRUFBRSxTQUFTLENBQUMsQ0FBQ0MsZUFBZSxDQUFDLElBQUksQ0FBQztJQUNqRVYsZ0JBQVMsQ0FBQ0MsV0FBVyxDQUFDM0IsYUFBTSxDQUFDTSxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDbkQsTUFBTXNCLElBQUksR0FBRyxNQUFNNUIsYUFBTSxDQUFDQyxVQUFVLENBQUMsTUFBTSxDQUFDO0lBQzVDLE1BQU1ULElBQUksQ0FBQ2EsS0FBSyxDQUFDLElBQUF3QixhQUFNLEVBQUNELElBQUksQ0FBQyxDQUFDTCxTQUFTLENBQUMsVUFBVSxFQUFFO01BQUUzRCxJQUFJLEVBQUU7SUFBVSxDQUFDLENBQUMsQ0FBQztJQUN6RSxJQUFBbUMsY0FBTSxFQUFDK0IsR0FBRyxDQUFDLENBQUMxQixvQkFBb0IsQ0FBQzVCLFFBQVEsRUFBRSxlQUFlLENBQUM7SUFDM0R5RCxPQUFPLENBQUNJLFdBQVcsQ0FBQyxDQUFDO0lBQ3JCO0lBQ0E7SUFDQSxNQUFNdEUsVUFBRSxDQUFDdUUsT0FBTyxDQUFDLE1BQ2YsSUFBQXZDLGNBQU0sRUFBQ0MsYUFBTSxDQUFDeUIsV0FBVyxDQUFDLFVBQVUsRUFBRTtNQUFFN0QsSUFBSSxFQUFFO0lBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQ3NELFFBQVEsQ0FBQyxDQUN4RSxDQUFDO0VBQ0gsQ0FBQyxDQUFDO0VBRUYsSUFBQTNCLFVBQUUsRUFBQywyRUFBMkUsRUFBRSxZQUFZO0lBQzFGLE1BQU11QyxHQUFHLEdBQUcvRCxVQUFFLENBQUNDLEVBQUUsQ0FBQyxNQUFNRSxPQUFPLENBQUNDLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQztJQUN6RCxNQUFNcUIsSUFBSSxHQUFHQyxrQkFBUyxDQUFDQyxLQUFLLENBQUMsQ0FBQztJQUM5QixJQUFBQyxhQUFNLGVBQUMsSUFBQXBDLFdBQUEsQ0FBQXFDLEdBQUEsRUFBQ3RDLGlCQUFBLENBQUFJLE9BQWdCO01BQUNtQyxLQUFLLEVBQUUsQ0FBQ3JCLFFBQVEsQ0FBRTtNQUFDc0IsRUFBRSxFQUFFMUIsTUFBTztNQUFDa0QsT0FBTyxFQUFFO1FBQUVVLE1BQU0sRUFBRUY7TUFBSTtJQUFFLENBQUUsQ0FBQyxDQUFDO0lBQ3JGLE1BQU05QixhQUFNLENBQUNHLFVBQVUsQ0FBQyxLQUFLLENBQUM7SUFDOUIsTUFBTVgsSUFBSSxDQUFDYSxLQUFLLENBQUNMLGFBQU0sQ0FBQ00sU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3pDLE1BQU1OLGFBQU0sQ0FBQ0csVUFBVSxDQUFDLFVBQVUsQ0FBQztJQUVuQyxNQUFNOEIsT0FBTyxHQUFHbEUsVUFBRSxDQUFDbUUsS0FBSyxDQUFDQyxNQUFNLEVBQUUsU0FBUyxDQUFDLENBQUNDLGVBQWUsQ0FBQyxLQUFLLENBQUM7SUFDbEVWLGdCQUFTLENBQUNDLFdBQVcsQ0FBQzNCLGFBQU0sQ0FBQ00sU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQ25ELE1BQU1zQixJQUFJLEdBQUcsTUFBTTVCLGFBQU0sQ0FBQ0MsVUFBVSxDQUFDLE1BQU0sQ0FBQztJQUM1QyxNQUFNVCxJQUFJLENBQUNhLEtBQUssQ0FBQyxJQUFBd0IsYUFBTSxFQUFDRCxJQUFJLENBQUMsQ0FBQ0wsU0FBUyxDQUFDLFVBQVUsRUFBRTtNQUFFM0QsSUFBSSxFQUFFO0lBQVUsQ0FBQyxDQUFDLENBQUM7SUFDekUsSUFBQW1DLGNBQU0sRUFBQytCLEdBQUcsQ0FBQyxDQUFDZCxHQUFHLENBQUN1QixnQkFBZ0IsQ0FBQyxDQUFDO0lBQ2xDLElBQUF4QyxjQUFNLEVBQUNDLGFBQU0sQ0FBQ3VCLFNBQVMsQ0FBQyxVQUFVLEVBQUU7TUFBRTNELElBQUksRUFBRTtJQUFXLENBQUMsQ0FBQyxDQUFDLENBQUNzQyxpQkFBaUIsQ0FBQyxDQUFDO0lBQzlFK0IsT0FBTyxDQUFDSSxXQUFXLENBQUMsQ0FBQztFQUN2QixDQUFDLENBQUM7RUFFRixJQUFBOUMsVUFBRSxFQUFDLHFEQUFxRCxFQUFFLFlBQVk7SUFDcEUsTUFBTWlELFdBQVcsR0FBR3pFLFVBQUUsQ0FBQ0MsRUFBRSxDQUFDLENBQUM7SUFDM0IsTUFBTXlFLGNBQWMsR0FBRzFFLFVBQUUsQ0FBQ0MsRUFBRSxDQUFDLE1BQU0sQ0FDakM7TUFBRTBFLEdBQUcsRUFBRSxXQUFXO01BQUVoRSxLQUFLLEVBQUUsWUFBWTtNQUFFMkMsUUFBUSxFQUFFbUI7SUFBWSxDQUFDLENBQ2pFLENBQUM7SUFDRixNQUFNaEQsSUFBSSxHQUFHQyxrQkFBUyxDQUFDQyxLQUFLLENBQUMsQ0FBQztJQUM5QixJQUFBQyxhQUFNLGVBQ0osSUFBQXBDLFdBQUEsQ0FBQXFDLEdBQUEsRUFBQ3RDLGlCQUFBLENBQUFJLE9BQWdCO01BQ2ZtQyxLQUFLLEVBQUUsQ0FBQ3JCLFFBQVEsQ0FBRTtNQUNsQnNCLEVBQUUsRUFBRTFCLE1BQU87TUFDWGtELE9BQU8sRUFBRTtRQUFFSCxJQUFJLEVBQUVwRCxVQUFFLENBQUNDLEVBQUUsQ0FBQztNQUFFLENBQUU7TUFDM0J5RSxjQUFjLEVBQUVBO0lBQWUsQ0FDaEMsQ0FDSCxDQUFDO0lBQ0QsTUFBTXpDLGFBQU0sQ0FBQ0csVUFBVSxDQUFDLFdBQVcsQ0FBQztJQUNwQ3VCLGdCQUFTLENBQUNDLFdBQVcsQ0FBQzNCLGFBQU0sQ0FBQ00sU0FBUyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQ3BELE1BQU1zQixJQUFJLEdBQUcsTUFBTTVCLGFBQU0sQ0FBQ0MsVUFBVSxDQUFDLE1BQU0sQ0FBQztJQUM1QyxNQUFNMEMsSUFBSSxHQUFHLElBQUFkLGFBQU0sRUFBQ0QsSUFBSSxDQUFDLENBQUNMLFNBQVMsQ0FBQyxVQUFVLEVBQUU7TUFBRTNELElBQUksRUFBRTtJQUFZLENBQUMsQ0FBQztJQUN0RSxJQUFBbUMsY0FBTSxFQUFDNEMsSUFBSSxDQUFDLENBQUN6QyxpQkFBaUIsQ0FBQyxDQUFDO0lBQ2hDLE1BQU1WLElBQUksQ0FBQ2EsS0FBSyxDQUFDc0MsSUFBSSxDQUFDO0lBQ3RCLElBQUE1QyxjQUFNLEVBQUN5QyxXQUFXLENBQUMsQ0FBQ0QsZ0JBQWdCLENBQUMsQ0FBQztFQUN4QyxDQUFDLENBQUM7RUFFRixJQUFBaEQsVUFBRSxFQUFDLGlEQUFpRCxFQUFFLE1BQU07SUFDMUQsSUFBQUksYUFBTSxlQUFDLElBQUFwQyxXQUFBLENBQUFxQyxHQUFBLEVBQUN0QyxpQkFBQSxDQUFBSSxPQUFnQjtNQUFDbUMsS0FBSyxFQUFFLEVBQUc7TUFBQ0MsRUFBRSxFQUFFMUI7SUFBTyxDQUFFLENBQUMsQ0FBQztJQUNuRCxJQUFBMkIsY0FBTSxFQUFDQyxhQUFNLENBQUN1QixTQUFTLENBQUMsU0FBUyxFQUFFO01BQUUzRCxJQUFJLEVBQUU7SUFBd0IsQ0FBQyxDQUFDLENBQUMsQ0FBQ3NDLGlCQUFpQixDQUFDLENBQUM7RUFDNUYsQ0FBQyxDQUFDO0VBRUYsSUFBQVgsVUFBRSxFQUFDLHFGQUFxRixFQUFFLFlBQVk7SUFDcEcsTUFBTUMsSUFBSSxHQUFHQyxrQkFBUyxDQUFDQyxLQUFLLENBQUMsQ0FBQztJQUM5QixNQUFNa0QsVUFBVSxHQUFHN0UsVUFBRSxDQUFDQyxFQUFFLENBQUMsQ0FBQztJQUMxQixJQUFBMkIsYUFBTSxlQUNKLElBQUFwQyxXQUFBLENBQUFxQyxHQUFBLEVBQUN0QyxpQkFBQSxDQUFBSSxPQUFnQjtNQUFDbUMsS0FBSyxFQUFFLENBQUNyQixRQUFRLENBQUU7TUFBQ3NCLEVBQUUsRUFBRTFCLE1BQU87TUFBQ3lFLE1BQU0sRUFBQyxNQUFNO01BQUNELFVBQVUsRUFBRUE7SUFBVyxDQUFFLENBQzFGLENBQUM7SUFDRDtJQUNBLE1BQU1wRCxJQUFJLENBQUNhLEtBQUssQ0FBQyxNQUFNTCxhQUFNLENBQUNHLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUNqRDtJQUNBLE1BQU1YLElBQUksQ0FBQ2EsS0FBSyxDQUFDLE1BQU1MLGFBQU0sQ0FBQ0csVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBRWhELElBQUFKLGNBQU0sRUFBQzZDLFVBQVUsQ0FBQyxDQUFDeEMsb0JBQW9CLENBQUM1QixRQUFRLEVBQUV1QixjQUFNLENBQUMrQyxjQUFjLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDdEY7SUFDQSxLQUFLLE1BQU1DLElBQUksSUFBSUgsVUFBVSxDQUFDSSxJQUFJLENBQUNDLEtBQUssRUFBRSxJQUFBbEQsY0FBTSxFQUFDZ0QsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUNHLElBQUksQ0FBQzFFLFFBQVEsQ0FBQztFQUMxRSxDQUFDLENBQUM7RUFFRixJQUFBZSxVQUFFLEVBQUMsbUlBQW1JLEVBQUUsWUFBWTtJQUNsSixNQUFNQyxJQUFJLEdBQUdDLGtCQUFTLENBQUNDLEtBQUssQ0FBQyxDQUFDO0lBQzlCLE1BQU1rRCxVQUFVLEdBQUc3RSxVQUFFLENBQUNDLEVBQUUsQ0FBQyxDQUFDO0lBQzFCLE1BQU07TUFBRXVDO0lBQVMsQ0FBQyxHQUFHLElBQUFaLGFBQU0sZUFDekIsSUFBQXBDLFdBQUEsQ0FBQXFDLEdBQUEsRUFBQ3RDLGlCQUFBLENBQUFJLE9BQWdCO01BQ2ZtQyxLQUFLLEVBQUUsQ0FBQ3JCLFFBQVEsQ0FBRTtNQUNsQnNCLEVBQUUsRUFBRTFCLE1BQU87TUFDWHlFLE1BQU0sRUFBQyxNQUFNO01BQ2JNLEdBQUcsRUFBQyxVQUFVO01BQ2RQLFVBQVUsRUFBRUE7SUFBVyxDQUN4QixDQUNILENBQUM7SUFDRDtJQUNBLElBQUE3QyxjQUFNLEVBQUMsTUFBTUMsYUFBTSxDQUFDRyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQ0QsaUJBQWlCLENBQUMsQ0FBQztJQUMxRCxJQUFBSCxjQUFNLEVBQUNDLGFBQU0sQ0FBQ00sU0FBUyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUNKLGlCQUFpQixDQUFDLENBQUM7O0lBRXpEO0lBQ0E7SUFDQSxNQUFNVixJQUFJLENBQUNhLEtBQUssQ0FBQ0wsYUFBTSxDQUFDTSxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDekMsSUFBQVAsY0FBTSxFQUFDNkMsVUFBVSxDQUFDLENBQUN4QyxvQkFBb0IsQ0FBQzVCLFFBQVEsRUFBRXVCLGNBQU0sQ0FBQytDLGNBQWMsQ0FBQyxZQUFZLENBQUMsQ0FBQztJQUN0RixJQUFBL0MsY0FBTSxFQUFDQyxhQUFNLENBQUNvRCxXQUFXLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQ3BDLEdBQUcsQ0FBQ2QsaUJBQWlCLENBQUMsQ0FBQztJQUM5RCxJQUFBSCxjQUFNLEVBQUNDLGFBQU0sQ0FBQ00sU0FBUyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUNKLGlCQUFpQixDQUFDLENBQUM7O0lBRXpEO0lBQ0FLLFFBQVEsY0FDTixJQUFBaEQsV0FBQSxDQUFBcUMsR0FBQSxFQUFDdEMsaUJBQUEsQ0FBQUksT0FBZ0I7TUFDZm1DLEtBQUssRUFBRSxDQUFDckIsUUFBUSxDQUFFO01BQ2xCc0IsRUFBRSxFQUFFMUIsTUFBTztNQUNYeUUsTUFBTSxFQUFDLE1BQU07TUFDYk0sR0FBRyxFQUFDLGNBQWM7TUFDbEJQLFVBQVUsRUFBRUE7SUFBVyxDQUN4QixDQUNILENBQUM7SUFDRCxJQUFBN0MsY0FBTSxFQUFDLE1BQU1DLGFBQU0sQ0FBQ0csVUFBVSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUNELGlCQUFpQixDQUFDLENBQUM7SUFDL0QsSUFBQUgsY0FBTSxFQUFDQyxhQUFNLENBQUNNLFNBQVMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDSixpQkFBaUIsQ0FBQyxDQUFDO0lBQ3ZELElBQUFILGNBQU0sRUFBQ0MsYUFBTSxDQUFDb0QsV0FBVyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUNwQyxHQUFHLENBQUNkLGlCQUFpQixDQUFDLENBQUM7RUFDakUsQ0FBQyxDQUFDO0VBRUYsSUFBQVgsVUFBRSxFQUFDLHlIQUF5SCxFQUFFLFlBQVk7SUFDeEksTUFBTUMsSUFBSSxHQUFHQyxrQkFBUyxDQUFDQyxLQUFLLENBQUMsQ0FBQztJQUM5QixNQUFNMkQsaUJBQWlCLEdBQUd0RixVQUFFLENBQUNDLEVBQUUsQ0FBQyxDQUFDO0lBQ2pDLElBQUEyQixhQUFNLGVBQ0osSUFBQXBDLFdBQUEsQ0FBQXFDLEdBQUEsRUFBQ3RDLGlCQUFBLENBQUFJLE9BQWdCO01BQ2ZtQyxLQUFLLEVBQUUsQ0FBQ3JCLFFBQVEsQ0FBRTtNQUNsQnNCLEVBQUUsRUFBRTFCLE1BQU87TUFDWHlFLE1BQU0sRUFBQyxNQUFNO01BQ2JNLEdBQUcsRUFBQyxjQUFjO01BQ2xCRyxhQUFhLEVBQUMsT0FBTztNQUNyQkQsaUJBQWlCLEVBQUVBO0lBQWtCLENBQ3RDLENBQ0gsQ0FBQztJQUNELE1BQU1FLFFBQVEsR0FBRyxDQUFDLE1BQU12RCxhQUFNLENBQUNHLFVBQVUsQ0FBQyxVQUFVLENBQUMsRUFBRVUsT0FBTyxDQUFDLGlCQUFpQixDQUFFO0lBQ2xGLE1BQU0yQyxPQUFPLEdBQUd4RCxhQUFNLENBQUNNLFNBQVMsQ0FBQyxTQUFTLENBQUMsQ0FBQ08sT0FBTyxDQUFDLGlCQUFpQixDQUFFOztJQUV2RTtJQUNBLE1BQU1yQixJQUFJLENBQUNhLEtBQUssQ0FBQ2tELFFBQVEsQ0FBQztJQUMxQixJQUFBeEQsY0FBTSxFQUFDc0QsaUJBQWlCLENBQUMsQ0FBQ0ksd0JBQXdCLENBQUNqRixRQUFRLEVBQUUsQ0FBQyxlQUFlLENBQUMsQ0FBQztJQUMvRSxNQUFNZ0IsSUFBSSxDQUFDYSxLQUFLLENBQUNtRCxPQUFPLENBQUM7SUFDekIsSUFBQXpELGNBQU0sRUFBQ3NELGlCQUFpQixDQUFDLENBQUNJLHdCQUF3QixDQUNoRGpGLFFBQVEsRUFDUnVCLGNBQU0sQ0FBQzJELGVBQWUsQ0FBQyxDQUFDLGVBQWUsRUFBRSxjQUFjLENBQUMsQ0FDMUQsQ0FBQztJQUNELElBQUEzRCxjQUFNLEVBQUNzRCxpQkFBaUIsQ0FBQ0wsSUFBSSxDQUFDQyxLQUFLLENBQUNVLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFFLENBQUMsQ0FBQyxDQUFDLENBQUNDLFlBQVksQ0FBQyxDQUFDLENBQUM7SUFDL0Q7SUFDQSxJQUFBN0QsY0FBTSxFQUFDd0QsUUFBUSxDQUFDLENBQUNNLFdBQVcsQ0FBQyxnQkFBZ0IsQ0FBQztJQUM5QyxJQUFBOUQsY0FBTSxFQUFDeUQsT0FBTyxDQUFDLENBQUNLLFdBQVcsQ0FBQyxnQkFBZ0IsQ0FBQzs7SUFFN0M7SUFDQSxNQUFNckUsSUFBSSxDQUFDYSxLQUFLLENBQUNrRCxRQUFRLENBQUM7SUFDMUIsSUFBQXhELGNBQU0sRUFBQ3NELGlCQUFpQixDQUFDLENBQUNJLHdCQUF3QixDQUFDakYsUUFBUSxFQUFFLENBQUMsY0FBYyxDQUFDLENBQUM7SUFDOUUsSUFBQXVCLGNBQU0sRUFBQ3dELFFBQVEsQ0FBQyxDQUFDdkMsR0FBRyxDQUFDNkMsV0FBVyxDQUFDLGdCQUFnQixDQUFDO0lBQ2xELElBQUE5RCxjQUFNLEVBQUN5RCxPQUFPLENBQUMsQ0FBQ0ssV0FBVyxDQUFDLGdCQUFnQixDQUFDO0VBQy9DLENBQUMsQ0FBQztFQUVGLElBQUF0RSxVQUFFLEVBQUMsZ0lBQWdJLEVBQUUsWUFBWTtJQUMvSSxNQUFNQyxJQUFJLEdBQUdDLGtCQUFTLENBQUNDLEtBQUssQ0FBQyxDQUFDO0lBQzlCLE1BQU1vRSxNQUFNLEdBQUcvRixVQUFFLENBQUNDLEVBQUUsQ0FBQyxNQUFNRSxPQUFPLENBQUNDLE9BQU8sQ0FBQyxDQUFDLENBQUM7SUFDN0MsTUFBTTRGLFVBQVUsR0FBR2hHLFVBQUUsQ0FBQ0MsRUFBRSxDQUFDLE1BQU1FLE9BQU8sQ0FBQ0MsT0FBTyxDQUFDLENBQUMsQ0FBQztJQUNqRCxJQUFBd0IsYUFBTSxlQUNKLElBQUFwQyxXQUFBLENBQUFxQyxHQUFBLEVBQUN0QyxpQkFBQSxDQUFBSSxPQUFnQjtNQUFDbUMsS0FBSyxFQUFFLENBQUNyQixRQUFRLENBQUU7TUFBQ3NCLEVBQUUsRUFBRTFCLE1BQU87TUFBQ2tELE9BQU8sRUFBRTtRQUFFd0MsTUFBTTtRQUFFQztNQUFXO0lBQUUsQ0FBRSxDQUNyRixDQUFDO0lBQ0QsTUFBTS9ELGFBQU0sQ0FBQ0csVUFBVSxDQUFDLEtBQUssQ0FBQztJQUM5QixNQUFNWCxJQUFJLENBQUNhLEtBQUssQ0FBQ0wsYUFBTSxDQUFDTSxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDekMsTUFBTU4sYUFBTSxDQUFDRyxVQUFVLENBQUMsVUFBVSxDQUFDOztJQUVuQztJQUNBLE1BQU1TLEdBQUcsR0FBR1osYUFBTSxDQUFDTSxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUNPLE9BQU8sQ0FBQyxXQUFXLENBQWdCO0lBQzVFYSxnQkFBUyxDQUFDQyxXQUFXLENBQUMzQixhQUFNLENBQUNNLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUNuRCxNQUFNc0IsSUFBSSxHQUFHLE1BQU01QixhQUFNLENBQUNDLFVBQVUsQ0FBQyxNQUFNLENBQUM7SUFDNUMsTUFBTVQsSUFBSSxDQUFDYSxLQUFLLENBQUMsSUFBQXdCLGFBQU0sRUFBQ0QsSUFBSSxDQUFDLENBQUNMLFNBQVMsQ0FBQyxVQUFVLEVBQUU7TUFBRTNELElBQUksRUFBRTtJQUFTLENBQUMsQ0FBQyxDQUFDO0lBQ3hFLE1BQU1vRyxLQUFLLEdBQUdoRSxhQUFNLENBQUN1QixTQUFTLENBQUMsU0FBUyxFQUFFO01BQUUzRCxJQUFJLEVBQUU7SUFBa0IsQ0FBQyxDQUFDO0lBQ3RFLElBQUFtQyxjQUFNLEVBQUNpRSxLQUFLLENBQUMsQ0FBQ0MsV0FBVyxDQUFDLENBQUM7SUFDM0IsTUFBTXpFLElBQUksQ0FBQzBFLElBQUksQ0FBQ0YsS0FBSyxFQUFFLEdBQUcsQ0FBQztJQUUzQixNQUFNeEUsSUFBSSxDQUFDMkUsUUFBUSxDQUFDLFVBQVUsQ0FBQztJQUMvQixJQUFBcEUsY0FBTSxFQUFDQyxhQUFNLENBQUN5QixXQUFXLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQ1AsUUFBUSxDQUFDLENBQUM7SUFDaEQsSUFBQW5CLGNBQU0sRUFBQytELE1BQU0sQ0FBQyxDQUFDOUMsR0FBRyxDQUFDdUIsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDdkMsSUFBQXhDLGNBQU0sRUFBQ2EsR0FBRyxDQUFDLENBQUNxRCxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUM7O0lBRTNCO0lBQ0F2QyxnQkFBUyxDQUFDQyxXQUFXLENBQUMzQixhQUFNLENBQUNNLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUNuRCxNQUFNOEQsS0FBSyxHQUFHLE1BQU1wRSxhQUFNLENBQUNDLFVBQVUsQ0FBQyxNQUFNLENBQUM7SUFDN0MsTUFBTVQsSUFBSSxDQUFDYSxLQUFLLENBQUMsSUFBQXdCLGFBQU0sRUFBQ3VDLEtBQUssQ0FBQyxDQUFDN0MsU0FBUyxDQUFDLFVBQVUsRUFBRTtNQUFFM0QsSUFBSSxFQUFFO0lBQWdCLENBQUMsQ0FBQyxDQUFDO0lBQ2hGLElBQUFtQyxjQUFNLEVBQUNDLGFBQU0sQ0FBQ3VCLFNBQVMsQ0FBQyxTQUFTLEVBQUU7TUFBRTNELElBQUksRUFBRTtJQUFtQixDQUFDLENBQUMsQ0FBQyxDQUFDc0MsaUJBQWlCLENBQUMsQ0FBQztFQUN2RixDQUFDLENBQUM7RUFFRixJQUFBWCxVQUFFLEVBQUMsdUVBQXVFLEVBQUUsWUFBWTtJQUN0RixNQUFNQyxJQUFJLEdBQUdDLGtCQUFTLENBQUNDLEtBQUssQ0FBQyxDQUFDO0lBQzlCLE1BQU1vRSxNQUFNLEdBQUcvRixVQUFFLENBQUNDLEVBQUUsQ0FBQyxNQUFNRSxPQUFPLENBQUNDLE9BQU8sQ0FBQztNQUFFUCxJQUFJLEVBQUUsR0FBRztNQUFFQyxLQUFLLEVBQUU7SUFBTSxDQUFDLENBQUMsQ0FBQztJQUN4RSxJQUFBOEIsYUFBTSxlQUFDLElBQUFwQyxXQUFBLENBQUFxQyxHQUFBLEVBQUN0QyxpQkFBQSxDQUFBSSxPQUFnQjtNQUFDbUMsS0FBSyxFQUFFLENBQUNyQixRQUFRLENBQUU7TUFBQ3NCLEVBQUUsRUFBRTFCLE1BQU87TUFBQ2tELE9BQU8sRUFBRTtRQUFFd0M7TUFBTztJQUFFLENBQUUsQ0FBQyxDQUFDO0lBQ2hGLE1BQU05RCxhQUFNLENBQUNHLFVBQVUsQ0FBQyxLQUFLLENBQUM7SUFDOUI7SUFDQSxNQUFNa0UsTUFBTSxHQUFHckUsYUFBTSxDQUFDTSxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUNPLE9BQU8sQ0FBQyxXQUFXLENBQWdCO0lBQzFFYSxnQkFBUyxDQUFDNEMsSUFBSSxDQUFDRCxNQUFNLEVBQUU7TUFDckJFLFlBQVksRUFBRTtRQUNaQyxLQUFLLEVBQUUsQ0FBQyw0QkFBNEIsQ0FBQztRQUNyQ0MsS0FBSyxFQUFFLEVBQUU7UUFDVEMsT0FBTyxFQUFHQyxDQUFTLElBQ2pCQSxDQUFDLEtBQUssNEJBQTRCLEdBQzlCQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztVQUFFQyxJQUFJLEVBQUUsaUJBQWlCO1VBQUVDLFFBQVEsRUFBRSxZQUFZO1VBQUVsSCxLQUFLLEVBQUU7UUFBTSxDQUFDLENBQUMsR0FDakYsRUFBRTtRQUNSbUgsT0FBTyxFQUFFQSxDQUFBLEtBQU0sQ0FBQyxDQUFDO1FBQ2pCQyxVQUFVLEVBQUUsRUFBRTtRQUNkQyxhQUFhLEVBQUU7TUFDakI7SUFDRixDQUFDLENBQUM7SUFDRixNQUFNQyxNQUFNLEdBQUcsTUFBTW5GLGFBQU0sQ0FBQ0MsVUFBVSxDQUFDLE9BQU8sQ0FBQztJQUMvQyxJQUFBRixjQUFNLEVBQUNvRixNQUFNLENBQUMsQ0FBQ0MsaUJBQWlCLENBQUMsU0FBUyxDQUFDO0lBQzNDLE1BQU01RixJQUFJLENBQUNhLEtBQUssQ0FBQyxJQUFBd0IsYUFBTSxFQUFDc0QsTUFBTSxDQUFDLENBQUM1RCxTQUFTLENBQUMsUUFBUSxFQUFFO01BQUUzRCxJQUFJLEVBQUU7SUFBVSxDQUFDLENBQUMsQ0FBQztJQUN6RSxJQUFBbUMsY0FBTSxFQUFDQyxhQUFNLENBQUN5QixXQUFXLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQ1AsUUFBUSxDQUFDLENBQUM7RUFDaEQsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDOztBQUVGO0FBQ0EsSUFBQTVCLGdCQUFRLEVBQUMsK0RBQStELEVBQUUsTUFBTTtFQUM5RSxlQUFlK0YsaUJBQWlCQSxDQUFDQyxFQUFnQixFQUFFO0lBQ2pELE1BQU05RixJQUFJLEdBQUdDLGtCQUFTLENBQUNDLEtBQUssQ0FBQyxDQUFDO0lBQzlCLE1BQU02RixLQUFLLEdBQUcsSUFBQTVGLGFBQU0sRUFBQzJGLEVBQUUsQ0FBQztJQUN4QixNQUFNdEYsYUFBTSxDQUFDRyxVQUFVLENBQUMsS0FBSyxDQUFDO0lBQzlCLE1BQU1YLElBQUksQ0FBQ2EsS0FBSyxDQUFDTCxhQUFNLENBQUNNLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUN6QyxNQUFNTixhQUFNLENBQUNHLFVBQVUsQ0FBQyxVQUFVLENBQUM7SUFDbkMsT0FBTztNQUFFWCxJQUFJO01BQUUsR0FBRytGO0lBQU0sQ0FBQztFQUMzQjtFQUVBLElBQUFoRyxVQUFFLEVBQUMsa0lBQWtJLEVBQUUsWUFBWTtJQUNqSixJQUFJaUcsYUFBb0U7SUFDeEUsTUFBTXpCLFVBQVUsR0FBR2hHLFVBQUUsQ0FBQ0MsRUFBRSxDQUN0QixNQUFNLElBQUlFLE9BQU8sQ0FBMkN1SCxHQUFHLElBQU1ELGFBQWEsR0FBR0MsR0FBSSxDQUMzRixDQUFDO0lBQ0QsTUFBTTtNQUFFakc7SUFBSyxDQUFDLEdBQUcsTUFBTTZGLGlCQUFpQixjQUN0QyxJQUFBOUgsV0FBQSxDQUFBcUMsR0FBQSxFQUFDdEMsaUJBQUEsQ0FBQUksT0FBZ0I7TUFBQ21DLEtBQUssRUFBRSxDQUFDckIsUUFBUSxDQUFFO01BQUNzQixFQUFFLEVBQUUxQixNQUFPO01BQUNrRCxPQUFPLEVBQUU7UUFBRXlDO01BQVc7SUFBRSxDQUFFLENBQzdFLENBQUM7SUFDRCxNQUFNMkIsV0FBVyxHQUFHNUgsT0FBTyxDQUFDa0YsSUFBSSxDQUFDQyxLQUFLLENBQUMwQyxNQUFNO0lBRTdDakUsZ0JBQVMsQ0FBQ0MsV0FBVyxDQUFDM0IsYUFBTSxDQUFDTSxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDbkQsTUFBTXNCLElBQUksR0FBRyxNQUFNNUIsYUFBTSxDQUFDQyxVQUFVLENBQUMsTUFBTSxDQUFDO0lBQzVDLE1BQU1ULElBQUksQ0FBQ2EsS0FBSyxDQUFDLElBQUF3QixhQUFNLEVBQUNELElBQUksQ0FBQyxDQUFDTCxTQUFTLENBQUMsVUFBVSxFQUFFO01BQUUzRCxJQUFJLEVBQUU7SUFBZ0IsQ0FBQyxDQUFDLENBQUM7SUFDL0UsTUFBTTRCLElBQUksQ0FBQzBFLElBQUksQ0FBQ2xFLGFBQU0sQ0FBQ3VCLFNBQVMsQ0FBQyxTQUFTLEVBQUU7TUFBRTNELElBQUksRUFBRTtJQUFtQixDQUFDLENBQUMsRUFBRSxlQUFlLENBQUM7O0lBRTNGO0lBQ0E7SUFDQSxNQUFNZ0ksT0FBTyxHQUFHNUYsYUFBTSxDQUFDdUIsU0FBUyxDQUFDLFVBQVUsRUFBRTtNQUFFM0QsSUFBSSxFQUFFO0lBQVMsQ0FBQyxDQUFDO0lBQ2hFLElBQUFtQyxjQUFNLEVBQUM2RixPQUFPLENBQUMsQ0FBQy9CLFdBQVcsQ0FBQyxnQkFBZ0IsQ0FBQztJQUM3QyxJQUFBOUQsY0FBTSxFQUFDNkYsT0FBTyxDQUFDLENBQUNwRSxlQUFlLENBQUMsV0FBVyxFQUFFLE1BQU0sQ0FBQztJQUNwRCxJQUFBekIsY0FBTSxFQUNKNkYsT0FBTyxDQUFDQyx1QkFBdUIsQ0FBQzdGLGFBQU0sQ0FBQ00sU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDLEdBQzNEd0YsSUFBSSxDQUFDQywyQkFDVCxDQUFDLENBQUNDLFVBQVUsQ0FBQyxDQUFDO0lBQ2QsSUFBQWpHLGNBQU0sRUFBQ0MsYUFBTSxDQUFDdUIsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM2RCxpQkFBaUIsQ0FBQyxrQkFBa0IsQ0FBQztJQUN4RSxJQUFBckYsY0FBTSxFQUFDZ0UsVUFBVSxDQUFDLENBQUMzRCxvQkFBb0IsQ0FBQzVCLFFBQVEsRUFBRSxhQUFhLENBQUM7O0lBRWhFO0lBQ0FiLElBQUksQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUNyQjtNQUFFQyxJQUFJLEVBQUUsUUFBUTtNQUFFQyxLQUFLLEVBQUU7SUFBTSxDQUFDLEVBQ2hDLEdBQUdVLFdBQVcsQ0FDZjtJQUNELE1BQU0sSUFBQTBILFVBQUcsRUFBQyxZQUFZVCxhQUFhLENBQUM7TUFBRTVILElBQUksRUFBRSxRQUFRO01BQUVDLEtBQUssRUFBRTtJQUFNLENBQUMsQ0FBQyxDQUFDO0lBQ3RFLE1BQU1xSSxPQUFPLEdBQUcsTUFBTWxHLGFBQU0sQ0FBQ0MsVUFBVSxDQUFDLFVBQVUsRUFBRTtNQUFFckMsSUFBSSxFQUFFO0lBQVMsQ0FBQyxDQUFDO0lBQ3ZFLElBQUFtQyxjQUFNLEVBQUNtRyxPQUFPLENBQUMsQ0FBQ2xGLEdBQUcsQ0FBQzZDLFdBQVcsQ0FBQyxnQkFBZ0IsQ0FBQztJQUNqRCxJQUFBOUQsY0FBTSxFQUFDbUcsT0FBTyxDQUFDLENBQUNsRixHQUFHLENBQUNRLGVBQWUsQ0FBQyxXQUFXLENBQUM7SUFDaEQsSUFBQXpCLGNBQU0sRUFBQ0MsYUFBTSxDQUFDdUIsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM2RCxpQkFBaUIsQ0FBQyxpQkFBaUIsQ0FBQzs7SUFFdkU7SUFDQTtJQUNBLE1BQU0sSUFBQWEsVUFBRyxFQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7SUFDekIsSUFBQWxHLGNBQU0sRUFBQ2pDLE9BQU8sQ0FBQ2tGLElBQUksQ0FBQ0MsS0FBSyxDQUFDMEMsTUFBTSxDQUFDLENBQUN6QyxJQUFJLENBQUN3QyxXQUFXLEdBQUcsQ0FBQyxDQUFDO0lBQ3ZELElBQUEzRixjQUFNLEVBQUNqQyxPQUFPLENBQUNrRixJQUFJLENBQUNDLEtBQUssQ0FBQ1UsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ3dDLE9BQU8sQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDO0VBQzdELENBQUMsQ0FBQztFQUVGLElBQUE1RyxVQUFFLEVBQUMseUZBQXlGLEVBQUUsWUFBWTtJQUN4RyxJQUFJNkcsWUFBbUM7SUFDdkMsTUFBTXJDLFVBQVUsR0FBR2hHLFVBQUUsQ0FBQ0MsRUFBRSxDQUN0QixNQUNFLElBQUlFLE9BQU8sQ0FBMEMsQ0FBQ21JLENBQUMsRUFBRUMsR0FBRyxLQUFNRixZQUFZLEdBQUdFLEdBQUksQ0FDekYsQ0FBQztJQUNELE1BQU07TUFBRTlHO0lBQUssQ0FBQyxHQUFHLE1BQU02RixpQkFBaUIsY0FDdEMsSUFBQTlILFdBQUEsQ0FBQXFDLEdBQUEsRUFBQ3RDLGlCQUFBLENBQUFJLE9BQWdCO01BQUNtQyxLQUFLLEVBQUUsQ0FBQ3JCLFFBQVEsQ0FBRTtNQUFDc0IsRUFBRSxFQUFFMUIsTUFBTztNQUFDa0QsT0FBTyxFQUFFO1FBQUV5QztNQUFXO0lBQUUsQ0FBRSxDQUM3RSxDQUFDO0lBRURyQyxnQkFBUyxDQUFDQyxXQUFXLENBQUMzQixhQUFNLENBQUNNLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUNuRCxNQUFNc0IsSUFBSSxHQUFHLE1BQU01QixhQUFNLENBQUNDLFVBQVUsQ0FBQyxNQUFNLENBQUM7SUFDNUMsTUFBTVQsSUFBSSxDQUFDYSxLQUFLLENBQUMsSUFBQXdCLGFBQU0sRUFBQ0QsSUFBSSxDQUFDLENBQUNMLFNBQVMsQ0FBQyxVQUFVLEVBQUU7TUFBRTNELElBQUksRUFBRTtJQUFnQixDQUFDLENBQUMsQ0FBQztJQUMvRSxNQUFNNEIsSUFBSSxDQUFDMEUsSUFBSSxDQUFDbEUsYUFBTSxDQUFDdUIsU0FBUyxDQUFDLFNBQVMsRUFBRTtNQUFFM0QsSUFBSSxFQUFFO0lBQW1CLENBQUMsQ0FBQyxFQUFFLGVBQWUsQ0FBQztJQUMzRixJQUFBbUMsY0FBTSxFQUFDQyxhQUFNLENBQUN1QixTQUFTLENBQUMsVUFBVSxFQUFFO01BQUUzRCxJQUFJLEVBQUU7SUFBUyxDQUFDLENBQUMsQ0FBQyxDQUFDc0MsaUJBQWlCLENBQUMsQ0FBQztJQUU1RSxNQUFNLElBQUErRixVQUFHLEVBQUMsWUFDUkcsWUFBWSxDQUFDRyxNQUFNLENBQUNDLE1BQU0sQ0FBQyxJQUFJQyxLQUFLLENBQUMsUUFBUSxDQUFDLEVBQUU7TUFBRUMsSUFBSSxFQUFFO0lBQVMsQ0FBQyxDQUFDLENBQ3JFLENBQUM7SUFDRDtJQUNBLE1BQU0zSSxVQUFFLENBQUN1RSxPQUFPLENBQUMsTUFDZixJQUFBdkMsY0FBTSxFQUFDQyxhQUFNLENBQUN5QixXQUFXLENBQUMsVUFBVSxFQUFFO01BQUU3RCxJQUFJLEVBQUU7SUFBUyxDQUFDLENBQUMsQ0FBQyxDQUFDc0QsUUFBUSxDQUFDLENBQ3RFLENBQUM7SUFDRCxJQUFBbkIsY0FBTSxFQUFDQyxhQUFNLENBQUN1QixTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQzZELGlCQUFpQixDQUNqRCwwQ0FDRixDQUFDO0lBQ0QsSUFBQXJGLGNBQU0sRUFBQ0MsYUFBTSxDQUFDdUIsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM2RCxpQkFBaUIsQ0FBQyx5QkFBeUIsQ0FBQztFQUNqRixDQUFDLENBQUM7RUFFRixJQUFBN0YsVUFBRSxFQUFDLGlGQUFpRixFQUFFLFlBQVk7SUFDaEcsTUFBTXVFLE1BQU0sR0FBRy9GLFVBQUUsQ0FBQ0MsRUFBRSxDQUFDLE1BQU1FLE9BQU8sQ0FBQ0MsT0FBTyxDQUFDO01BQUVQLElBQUksRUFBRSxXQUFXO01BQUVDLEtBQUssRUFBRTtJQUFNLENBQUMsQ0FBQyxDQUFDOztJQUVoRjtJQUNBO01BQ0UsTUFBTTJCLElBQUksR0FBR0Msa0JBQVMsQ0FBQ0MsS0FBSyxDQUFDLENBQUM7TUFDOUIsTUFBTTtRQUFFaUg7TUFBUSxDQUFDLEdBQUcsSUFBQWhILGFBQU0sZUFDeEIsSUFBQXBDLFdBQUEsQ0FBQXFDLEdBQUEsRUFBQ3RDLGlCQUFBLENBQUFJLE9BQWdCO1FBQUNtQyxLQUFLLEVBQUUsQ0FBQ3JCLFFBQVEsQ0FBRTtRQUFDc0IsRUFBRSxFQUFFMUIsTUFBTztRQUFDa0QsT0FBTyxFQUFFO1VBQUV3QztRQUFPO01BQUUsQ0FBRSxDQUN6RSxDQUFDO01BQ0QsTUFBTTlELGFBQU0sQ0FBQ0csVUFBVSxDQUFDLEtBQUssQ0FBQztNQUM5QixNQUFNWCxJQUFJLENBQUNhLEtBQUssQ0FBQ0wsYUFBTSxDQUFDTSxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUM7TUFDekMsTUFBTU4sYUFBTSxDQUFDRyxVQUFVLENBQUMsVUFBVSxDQUFDO01BQ25DLE1BQU15RyxJQUFJLEdBQUc7UUFBRTlCLElBQUksRUFBRSxvQkFBb0I7UUFBRUMsUUFBUSxFQUFFLFVBQVU7UUFBRWxILEtBQUssRUFBRTtNQUFNLENBQUM7TUFDL0U2RCxnQkFBUyxDQUFDNEMsSUFBSSxDQUFDdEUsYUFBTSxDQUFDTSxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUNPLE9BQU8sQ0FBQyxXQUFXLENBQUMsRUFBaUI7UUFDMUUwRCxZQUFZLEVBQUU7VUFDWkMsS0FBSyxFQUFFLENBQUMsNEJBQTRCLENBQUM7VUFDckNDLEtBQUssRUFBRSxFQUFFO1VBQ1RDLE9BQU8sRUFBR0MsQ0FBUyxJQUNqQkEsQ0FBQyxLQUFLLDRCQUE0QixHQUFHQyxJQUFJLENBQUNDLFNBQVMsQ0FBQytCLElBQUksQ0FBQyxHQUFHLEVBQUU7VUFDaEU1QixPQUFPLEVBQUVBLENBQUEsS0FBTSxDQUFDLENBQUM7VUFDakJDLFVBQVUsRUFBRSxFQUFFO1VBQ2RDLGFBQWEsRUFBRTtRQUNqQjtNQUNGLENBQUMsQ0FBQztNQUNGLElBQUFuRixjQUFNLEVBQUMrRCxNQUFNLENBQUMsQ0FBQzFELG9CQUFvQixDQUFDNUIsUUFBUSxFQUFFLFlBQVksRUFBRSxnQkFBZ0IsRUFBRSxLQUFLLENBQUM7TUFDcEZtSSxPQUFPLENBQUMsQ0FBQztJQUNYO0lBQ0E3QyxNQUFNLENBQUMzRSxTQUFTLENBQUMsQ0FBQzs7SUFFbEI7SUFDQTtNQUNFLE1BQU1LLElBQUksR0FBR0Msa0JBQVMsQ0FBQ0MsS0FBSyxDQUFDLENBQUM7TUFDOUIsSUFBQUMsYUFBTSxlQUFDLElBQUFwQyxXQUFBLENBQUFxQyxHQUFBLEVBQUN0QyxpQkFBQSxDQUFBSSxPQUFnQjtRQUFDbUMsS0FBSyxFQUFFLENBQUNyQixRQUFRLENBQUU7UUFBQ3NCLEVBQUUsRUFBRTFCLE1BQU87UUFBQ2tELE9BQU8sRUFBRTtVQUFFd0M7UUFBTztNQUFFLENBQUUsQ0FBQyxDQUFDO01BQ2hGLE1BQU05RCxhQUFNLENBQUNHLFVBQVUsQ0FBQyxLQUFLLENBQUM7TUFDOUJ1QixnQkFBUyxDQUFDQyxXQUFXLENBQUMzQixhQUFNLENBQUNNLFNBQVMsQ0FBQyxXQUFXLENBQUMsQ0FBQztNQUNwRCxNQUFNc0IsSUFBSSxHQUFHLE1BQU01QixhQUFNLENBQUNDLFVBQVUsQ0FBQyxNQUFNLENBQUM7TUFDNUMsTUFBTVQsSUFBSSxDQUFDYSxLQUFLLENBQUMsSUFBQXdCLGFBQU0sRUFBQ0QsSUFBSSxDQUFDLENBQUNMLFNBQVMsQ0FBQyxVQUFVLEVBQUU7UUFBRTNELElBQUksRUFBRTtNQUFVLENBQUMsQ0FBQyxDQUFDO01BQ3pFLE1BQU1pSixNQUFNLEdBQUcsTUFBTTdHLGFBQU0sQ0FBQ0MsVUFBVSxDQUFDLFFBQVEsRUFBRTtRQUMvQ3JDLElBQUksRUFBRTtNQUNSLENBQUMsQ0FBQztNQUNGLE1BQU00QixJQUFJLENBQUNhLEtBQUssQ0FBQyxJQUFBd0IsYUFBTSxFQUFDZ0YsTUFBTSxDQUFDLENBQUN0RixTQUFTLENBQUMsVUFBVSxFQUFFO1FBQUUzRCxJQUFJLEVBQUU7TUFBTSxDQUFDLENBQUMsQ0FBQztNQUN2RSxNQUFNNEIsSUFBSSxDQUFDYSxLQUFLLENBQUMsSUFBQXdCLGFBQU0sRUFBQ2dGLE1BQU0sQ0FBQyxDQUFDdEYsU0FBUyxDQUFDLFFBQVEsRUFBRTtRQUFFM0QsSUFBSSxFQUFFO01BQVksQ0FBQyxDQUFDLENBQUM7O01BRTNFO01BQ0EsSUFBQW1DLGNBQU0sRUFBQytELE1BQU0sQ0FBQyxDQUFDMUQsb0JBQW9CLENBQUM1QixRQUFRLEVBQUUsWUFBWSxFQUFFLGdCQUFnQixFQUFFLEtBQUssQ0FBQztNQUNwRixJQUFBdUIsY0FBTSxFQUFDQyxhQUFNLENBQUN1QixTQUFTLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQzZELGlCQUFpQixDQUFDLDJCQUEyQixDQUFDO0lBQ25GO0VBQ0YsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDOztBQUVGO0FBQ0EsSUFBQTlGLGdCQUFRLEVBQUMsc0NBQXNDLEVBQUUsTUFBTTtFQUNyRCxJQUFBQyxVQUFFLEVBQUMsOEZBQThGLEVBQUUsWUFBWTtJQUM3RyxNQUFNQyxJQUFJLEdBQUdDLGtCQUFTLENBQUNDLEtBQUssQ0FBQyxDQUFDO0lBQzlCLElBQUFDLGFBQU0sZUFBQyxJQUFBcEMsV0FBQSxDQUFBcUMsR0FBQSxFQUFDdEMsaUJBQUEsQ0FBQUksT0FBZ0I7TUFBQ21DLEtBQUssRUFBRSxDQUFDckIsUUFBUSxDQUFFO01BQUNzQixFQUFFLEVBQUUxQjtJQUFPLENBQUUsQ0FBQyxDQUFDO0lBQzNELE1BQU00QixhQUFNLENBQUNHLFVBQVUsQ0FBQyxLQUFLLENBQUM7SUFDOUIsTUFBTVgsSUFBSSxDQUFDYSxLQUFLLENBQUNMLGFBQU0sQ0FBQ00sU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3pDLE1BQU1OLGFBQU0sQ0FBQ0csVUFBVSxDQUFDLFNBQVMsQ0FBQztJQUVsQyxNQUFNMkcsS0FBSyxHQUFHOUcsYUFBTSxDQUFDK0csWUFBWSxDQUFDLFVBQVUsQ0FBQztJQUM3QyxJQUFBaEgsY0FBTSxFQUFDK0csS0FBSyxDQUFDbkIsTUFBTSxDQUFDLENBQUNxQixlQUFlLENBQUMsQ0FBQyxDQUFDO0lBQ3ZDLElBQUFqSCxjQUFNLEVBQUMrRyxLQUFLLENBQUMvRSxNQUFNLENBQUVrRixFQUFFLElBQUtBLEVBQUUsQ0FBQ0MsUUFBUSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUN0RCxZQUFZLENBQUMsQ0FBQyxDQUFDO0lBRS9ELE1BQU1oRCxHQUFHLEdBQUdaLGFBQU0sQ0FBQ3VCLFNBQVMsQ0FBQyxVQUFVLEVBQUU7TUFBRTNELElBQUksRUFBRTtJQUFXLENBQUMsQ0FBQztJQUM5RCxJQUFBbUMsY0FBTSxFQUFDYSxHQUFHLENBQUMsQ0FBQ2lELFdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0lBQ2xDLElBQUE5RCxjQUFNLEVBQUNhLEdBQUcsQ0FBQ3NHLFFBQVEsQ0FBQyxDQUFDaEUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUNqQyxDQUFDLENBQUM7RUFFRixJQUFBM0QsVUFBRSxFQUFDLGtEQUFrRCxFQUFFLFlBQVk7SUFDakUsTUFBTUMsSUFBSSxHQUFHQyxrQkFBUyxDQUFDQyxLQUFLLENBQUMsQ0FBQztJQUM5QixJQUFBQyxhQUFNLGVBQUMsSUFBQXBDLFdBQUEsQ0FBQXFDLEdBQUEsRUFBQ3RDLGlCQUFBLENBQUFJLE9BQWdCO01BQUNtQyxLQUFLLEVBQUUsQ0FBQ3JCLFFBQVEsQ0FBRTtNQUFDc0IsRUFBRSxFQUFFMUI7SUFBTyxDQUFFLENBQUMsQ0FBQztJQUMzRCxNQUFNNEIsYUFBTSxDQUFDRyxVQUFVLENBQUMsS0FBSyxDQUFDO0lBQzlCLE1BQU1YLElBQUksQ0FBQ2EsS0FBSyxDQUFDTCxhQUFNLENBQUNNLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUN6QyxNQUFNTixhQUFNLENBQUNHLFVBQVUsQ0FBQyxTQUFTLENBQUM7SUFFbENILGFBQU0sQ0FBQ3VCLFNBQVMsQ0FBQyxVQUFVLEVBQUU7TUFBRTNELElBQUksRUFBRTtJQUFPLENBQUMsQ0FBQyxDQUFDdUosS0FBSyxDQUFDLENBQUM7SUFDdEQsTUFBTTNILElBQUksQ0FBQzJFLFFBQVEsQ0FBQyxhQUFhLENBQUM7SUFDbEMsSUFBQXBFLGNBQU0sRUFBQ0MsYUFBTSxDQUFDdUIsU0FBUyxDQUFDLFVBQVUsRUFBRTtNQUFFM0QsSUFBSSxFQUFFO0lBQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQ3FHLFdBQVcsQ0FBQyxDQUFDO0lBQ25FLE1BQU16RSxJQUFJLENBQUMyRSxRQUFRLENBQUMsYUFBYSxDQUFDO0lBQ2xDLElBQUFwRSxjQUFNLEVBQUNDLGFBQU0sQ0FBQ3VCLFNBQVMsQ0FBQyxVQUFVLEVBQUU7TUFBRTNELElBQUksRUFBRTtJQUFXLENBQUMsQ0FBQyxDQUFDLENBQUNxRyxXQUFXLENBQUMsQ0FBQztJQUN4RSxNQUFNekUsSUFBSSxDQUFDMkUsUUFBUSxDQUFDLFFBQVEsQ0FBQztJQUM3QixJQUFBcEUsY0FBTSxFQUFDQyxhQUFNLENBQUN1QixTQUFTLENBQUMsVUFBVSxFQUFFO01BQUUzRCxJQUFJLEVBQUU7SUFBTyxDQUFDLENBQUMsQ0FBQyxDQUFDcUcsV0FBVyxDQUFDLENBQUM7SUFDcEUsTUFBTXpFLElBQUksQ0FBQzJFLFFBQVEsQ0FBQyxPQUFPLENBQUM7SUFDNUI7SUFDQSxJQUFBcEUsY0FBTSxFQUFDQyxhQUFNLENBQUN1QixTQUFTLENBQUMsVUFBVSxFQUFFO01BQUUzRCxJQUFJLEVBQUU7SUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDcUcsV0FBVyxDQUFDLENBQUM7RUFDM0UsQ0FBQyxDQUFDO0VBRUYsSUFBQTFFLFVBQUUsRUFBQyxzQ0FBc0MsRUFBRSxZQUFZO0lBQ3JELE1BQU1DLElBQUksR0FBR0Msa0JBQVMsQ0FBQ0MsS0FBSyxDQUFDLENBQUM7SUFDOUIsSUFBQUMsYUFBTSxlQUFDLElBQUFwQyxXQUFBLENBQUFxQyxHQUFBLEVBQUN0QyxpQkFBQSxDQUFBSSxPQUFnQjtNQUFDbUMsS0FBSyxFQUFFLENBQUNyQixRQUFRLENBQUU7TUFBQ3NCLEVBQUUsRUFBRTFCO0lBQU8sQ0FBRSxDQUFDLENBQUM7SUFDM0QsTUFBTTRCLGFBQU0sQ0FBQ0csVUFBVSxDQUFDLEtBQUssQ0FBQztJQUM5QixNQUFNWCxJQUFJLENBQUNhLEtBQUssQ0FBQ0wsYUFBTSxDQUFDTSxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDekMsTUFBTU4sYUFBTSxDQUFDRyxVQUFVLENBQUMsU0FBUyxDQUFDO0lBRWxDLE1BQU1pSCxJQUFJLEdBQUdwSCxhQUFNLENBQUN1QixTQUFTLENBQUMsVUFBVSxFQUFFO01BQUUzRCxJQUFJLEVBQUU7SUFBVSxDQUFDLENBQUM7SUFDOUQsTUFBTTRCLElBQUksQ0FBQ2EsS0FBSyxDQUFDK0csSUFBSSxDQUFDO0lBQ3RCLElBQUFySCxjQUFNLEVBQUNxSCxJQUFJLENBQUNGLFFBQVEsQ0FBQyxDQUFDaEUsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUM3QixJQUFBbkQsY0FBTSxFQUNKQyxhQUFNLENBQUMrRyxZQUFZLENBQUMsVUFBVSxDQUFDLENBQUNoRixNQUFNLENBQUVrRixFQUFFLElBQUtBLEVBQUUsQ0FBQ0MsUUFBUSxLQUFLLENBQUMsQ0FDbEUsQ0FBQyxDQUFDZixPQUFPLENBQUMsQ0FBQ2lCLElBQUksQ0FBQyxDQUFDO0VBQ25CLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQzs7QUFFRjtBQUNBLElBQUE5SCxnQkFBUSxFQUFDLDhCQUE4QixFQUFFLE1BQU07RUFDN0MsSUFBQUMsVUFBRSxFQUFDLHVFQUF1RSxFQUFFLFlBQVk7SUFDdEYsTUFBTThILGVBQWUsR0FBR3ZKLE9BQU8sQ0FBQ2tGLElBQUksQ0FBQ0MsS0FBSyxDQUFDMEMsTUFBTTtJQUNqRCxJQUFJMkIsYUFBMEI7SUFDOUIsTUFBTUMsTUFBTSxHQUFHeEosVUFBRSxDQUFDQyxFQUFFLENBQ2xCLE1BQU0sSUFBSUUsT0FBTyxDQUFRdUgsR0FBRyxJQUFNNkIsYUFBYSxHQUFHN0IsR0FBSSxDQUN4RCxDQUFDO0lBQ0QsSUFBQTlGLGFBQU0sZUFBQyxJQUFBcEMsV0FBQSxDQUFBcUMsR0FBQSxFQUFDdEMsaUJBQUEsQ0FBQUksT0FBZ0I7TUFBQ21DLEtBQUssRUFBRSxDQUFDckIsUUFBUSxDQUFFO01BQUNzQixFQUFFLEVBQUUxQixNQUFPO01BQUNrRCxPQUFPLEVBQUU7UUFBRWlHO01BQU87SUFBRSxDQUFFLENBQUMsQ0FBQztJQUNoRixNQUFNdkgsYUFBTSxDQUFDRyxVQUFVLENBQUMsS0FBSyxDQUFDO0lBQzlCLE1BQU11RixXQUFXLEdBQUc1SCxPQUFPLENBQUNrRixJQUFJLENBQUNDLEtBQUssQ0FBQzBDLE1BQU07SUFFN0MsTUFBTTZCLElBQUksR0FBRyxJQUFJQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBRSxVQUFVLEVBQUU7TUFBRXZELElBQUksRUFBRTtJQUFhLENBQUMsQ0FBQztJQUNwRXhDLGdCQUFTLENBQUM0QyxJQUFJLENBQUN0RSxhQUFNLENBQUNNLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQ08sT0FBTyxDQUFDLFdBQVcsQ0FBQyxFQUFpQjtNQUMxRTBELFlBQVksRUFBRTtRQUNaQyxLQUFLLEVBQUUsQ0FBQyxPQUFPLENBQUM7UUFDaEJDLEtBQUssRUFBRSxDQUFDK0MsSUFBSSxDQUFDO1FBQ2I5QyxPQUFPLEVBQUVBLENBQUEsS0FBTSxFQUFFO1FBQ2pCTSxPQUFPLEVBQUVBLENBQUEsS0FBTSxDQUFDLENBQUM7UUFDakJDLFVBQVUsRUFBRSxFQUFFO1FBQ2RDLGFBQWEsRUFBRTtNQUNqQjtJQUNGLENBQUMsQ0FBQztJQUNGLElBQUFuRixjQUFNLEVBQUN3SCxNQUFNLENBQUMsQ0FBQ25ILG9CQUFvQixDQUFDNUIsUUFBUSxFQUFFLE1BQU0sRUFBRSxDQUFDZ0osSUFBSSxDQUFDLENBQUM7SUFDN0QsSUFBQXpILGNBQU0sRUFBQ0MsYUFBTSxDQUFDdUIsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM2RCxpQkFBaUIsQ0FBQyxtQkFBbUIsQ0FBQztJQUN6RSxJQUFBckYsY0FBTSxFQUFDakMsT0FBTyxDQUFDa0YsSUFBSSxDQUFDQyxLQUFLLENBQUMwQyxNQUFNLENBQUMsQ0FBQ3pDLElBQUksQ0FBQ3dDLFdBQVcsQ0FBQyxDQUFDLENBQUM7O0lBRXJEL0gsSUFBSSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsR0FBR1ksV0FBVyxFQUFFO01BQUVYLElBQUksRUFBRSxVQUFVO01BQUVDLEtBQUssRUFBRTtJQUFNLENBQUMsQ0FBQztJQUMzRSxNQUFNLElBQUFvSSxVQUFHLEVBQUMsWUFBWXFCLGFBQWEsQ0FBQyxDQUFDLENBQUM7SUFDdEMsSUFBQXZILGNBQU0sRUFBQ0MsYUFBTSxDQUFDdUIsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM2RCxpQkFBaUIsQ0FBQyxrQkFBa0IsQ0FBQztJQUN4RSxNQUFNLElBQUFhLFVBQUcsRUFBQyxZQUFZLENBQUMsQ0FBQyxDQUFDO0lBQ3pCLElBQUFsRyxjQUFNLEVBQUNqQyxPQUFPLENBQUNrRixJQUFJLENBQUNDLEtBQUssQ0FBQzBDLE1BQU0sQ0FBQyxDQUFDekMsSUFBSSxDQUFDd0MsV0FBVyxHQUFHLENBQUMsQ0FBQztJQUN2RCxJQUFBM0YsY0FBTSxFQUFDakMsT0FBTyxDQUFDa0YsSUFBSSxDQUFDQyxLQUFLLENBQUNVLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUN3QyxPQUFPLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQztJQUMzRCxJQUFBcEcsY0FBTSxFQUFDMkYsV0FBVyxHQUFHMkIsZUFBZSxDQUFDLENBQUNuRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztFQUNwRCxDQUFDLENBQUM7RUFFRixJQUFBM0QsVUFBRSxFQUFDLHVFQUF1RSxFQUFFLFlBQVk7SUFDdEYsSUFBSW1JLFlBQW1DO0lBQ3ZDLE1BQU1ILE1BQU0sR0FBR3hKLFVBQUUsQ0FBQ0MsRUFBRSxDQUNsQixNQUNFLElBQUlFLE9BQU8sQ0FBTyxDQUFDbUksQ0FBQyxFQUFFQyxHQUFHLEtBQU1vQixZQUFZLEdBQUdwQixHQUFJLENBQ3RELENBQUM7SUFDRCxJQUFBM0csYUFBTSxlQUFDLElBQUFwQyxXQUFBLENBQUFxQyxHQUFBLEVBQUN0QyxpQkFBQSxDQUFBSSxPQUFnQjtNQUFDbUMsS0FBSyxFQUFFLENBQUNyQixRQUFRLENBQUU7TUFBQ3NCLEVBQUUsRUFBRTFCLE1BQU87TUFBQ2tELE9BQU8sRUFBRTtRQUFFaUc7TUFBTztJQUFFLENBQUUsQ0FBQyxDQUFDO0lBQ2hGLE1BQU12SCxhQUFNLENBQUNHLFVBQVUsQ0FBQyxLQUFLLENBQUM7SUFDOUIsTUFBTXVGLFdBQVcsR0FBRzVILE9BQU8sQ0FBQ2tGLElBQUksQ0FBQ0MsS0FBSyxDQUFDMEMsTUFBTTtJQUU3Q2pFLGdCQUFTLENBQUM0QyxJQUFJLENBQUN0RSxhQUFNLENBQUNNLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQ08sT0FBTyxDQUFDLFdBQVcsQ0FBQyxFQUFpQjtNQUMxRTBELFlBQVksRUFBRTtRQUNaQyxLQUFLLEVBQUUsQ0FBQyxPQUFPLENBQUM7UUFDaEJDLEtBQUssRUFBRSxDQUFDLElBQUlnRCxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBRSxTQUFTLEVBQUU7VUFBRXZELElBQUksRUFBRTtRQUFhLENBQUMsQ0FBQyxDQUFDO1FBQy9EUSxPQUFPLEVBQUVBLENBQUEsS0FBTSxFQUFFO1FBQ2pCTSxPQUFPLEVBQUVBLENBQUEsS0FBTSxDQUFDLENBQUM7UUFDakJDLFVBQVUsRUFBRSxFQUFFO1FBQ2RDLGFBQWEsRUFBRTtNQUNqQjtJQUNGLENBQUMsQ0FBQztJQUNGLE1BQU0sSUFBQWUsVUFBRyxFQUFDLFlBQ1J5QixZQUFZLENBQUNuQixNQUFNLENBQUNDLE1BQU0sQ0FBQyxJQUFJQyxLQUFLLENBQUMsV0FBVyxDQUFDLEVBQUU7TUFBRUMsSUFBSSxFQUFFO0lBQVksQ0FBQyxDQUFDLENBQzNFLENBQUM7SUFDRCxJQUFBM0csY0FBTSxFQUFDQyxhQUFNLENBQUN1QixTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQzZELGlCQUFpQixDQUFDLG1DQUFtQyxDQUFDO0lBQ3hGLElBQUFyRixjQUFNLEVBQUNDLGFBQU0sQ0FBQ3VCLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDNkQsaUJBQWlCLENBQUMsaUJBQWlCLENBQUM7SUFDdkUsSUFBQXJGLGNBQU0sRUFBQ2pDLE9BQU8sQ0FBQ2tGLElBQUksQ0FBQ0MsS0FBSyxDQUFDMEMsTUFBTSxDQUFDLENBQUN6QyxJQUFJLENBQUN3QyxXQUFXLENBQUM7RUFDckQsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDOztBQUVGO0FBQ0EsSUFBQXBHLGdCQUFRLEVBQUMsd0RBQXdELEVBQUUsTUFBTTtFQUN2RSxNQUFNcUksTUFBTSxHQUFJQyxTQUFzQixJQUNwQ0EsU0FBUyxDQUFDQyxhQUFhLENBQW1CLG9CQUFvQixDQUFFO0VBRWxFLElBQUF0SSxVQUFFLEVBQUMsbURBQW1ELEVBQUUsWUFBWTtJQUNsRSxNQUFNZ0ksTUFBTSxHQUFHeEosVUFBRSxDQUFDQyxFQUFFLENBQUMsTUFBTUUsT0FBTyxDQUFDQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0lBQzdDLE1BQU07TUFBRXlKO0lBQVUsQ0FBQyxHQUFHLElBQUFqSSxhQUFNLGVBQzFCLElBQUFwQyxXQUFBLENBQUFxQyxHQUFBLEVBQUN0QyxpQkFBQSxDQUFBSSxPQUFnQjtNQUFDbUMsS0FBSyxFQUFFLENBQUNyQixRQUFRLENBQUU7TUFBQ3NCLEVBQUUsRUFBRTFCLE1BQU87TUFBQ2tELE9BQU8sRUFBRTtRQUFFaUc7TUFBTztJQUFFLENBQUUsQ0FDekUsQ0FBQztJQUNELE1BQU12SCxhQUFNLENBQUNHLFVBQVUsQ0FBQyxXQUFXLENBQUM7SUFFcEN1QixnQkFBUyxDQUFDckIsS0FBSyxDQUFDTCxhQUFNLENBQUN1QixTQUFTLENBQUMsUUFBUSxFQUFFO01BQUUzRCxJQUFJLEVBQUU7SUFBZ0MsQ0FBQyxDQUFDLENBQUM7SUFDdEYsTUFBTTRKLElBQUksR0FBRyxJQUFJQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBRSxVQUFVLEVBQUU7TUFBRXZELElBQUksRUFBRTtJQUFhLENBQUMsQ0FBQztJQUNwRXhDLGdCQUFTLENBQUNvRyxNQUFNLENBQUNILE1BQU0sQ0FBQ0MsU0FBUyxDQUFDLEVBQUU7TUFBRUcsTUFBTSxFQUFFO1FBQUV0RCxLQUFLLEVBQUUsQ0FBQytDLElBQUk7TUFBRTtJQUFFLENBQUMsQ0FBQztJQUVsRSxJQUFBekgsY0FBTSxFQUFDd0gsTUFBTSxDQUFDLENBQUNuSCxvQkFBb0IsQ0FBQzVCLFFBQVEsRUFBRSxHQUFHLEVBQUUsQ0FBQ2dKLElBQUksQ0FBQyxDQUFDO0VBQzVELENBQUMsQ0FBQztFQUVGLElBQUFqSSxVQUFFLEVBQUMseUVBQXlFLEVBQUUsWUFBWTtJQUN4RixNQUFNQyxJQUFJLEdBQUdDLGtCQUFTLENBQUNDLEtBQUssQ0FBQyxDQUFDO0lBQzlCLE1BQU02SCxNQUFNLEdBQUd4SixVQUFFLENBQUNDLEVBQUUsQ0FBQyxNQUFNRSxPQUFPLENBQUNDLE9BQU8sQ0FBQyxDQUFDLENBQUM7SUFDN0MsTUFBTTtNQUFFeUo7SUFBVSxDQUFDLEdBQUcsSUFBQWpJLGFBQU0sZUFDMUIsSUFBQXBDLFdBQUEsQ0FBQXFDLEdBQUEsRUFBQ3RDLGlCQUFBLENBQUFJLE9BQWdCO01BQUNtQyxLQUFLLEVBQUUsQ0FBQ3JCLFFBQVEsQ0FBRTtNQUFDc0IsRUFBRSxFQUFFMUIsTUFBTztNQUFDa0QsT0FBTyxFQUFFO1FBQUVpRztNQUFPO0lBQUUsQ0FBRSxDQUN6RSxDQUFDO0lBQ0QsTUFBTXZILGFBQU0sQ0FBQ0csVUFBVSxDQUFDLEtBQUssQ0FBQztJQUM5QixNQUFNWCxJQUFJLENBQUNhLEtBQUssQ0FBQ0wsYUFBTSxDQUFDTSxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUM7O0lBRXpDO0lBQ0E7SUFDQSxJQUFBUCxjQUFNLEVBQUNDLGFBQU0sQ0FBQ3VCLFNBQVMsQ0FBQyxVQUFVLEVBQUU7TUFBRTNELElBQUksRUFBRTtJQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM0RCxlQUFlLENBQ25FLGVBQWUsRUFDZixNQUNGLENBQUM7SUFDREUsZ0JBQVMsQ0FBQ3JCLEtBQUssQ0FBQ0wsYUFBTSxDQUFDdUIsU0FBUyxDQUFDLFFBQVEsRUFBRTtNQUFFM0QsSUFBSSxFQUFFO0lBQXVCLENBQUMsQ0FBQyxDQUFDO0lBQzdFLE1BQU00SixJQUFJLEdBQUcsSUFBSUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLEVBQUUsVUFBVSxFQUFFO01BQUV2RCxJQUFJLEVBQUU7SUFBYSxDQUFDLENBQUM7SUFDcEV4QyxnQkFBUyxDQUFDb0csTUFBTSxDQUFDSCxNQUFNLENBQUNDLFNBQVMsQ0FBQyxFQUFFO01BQUVHLE1BQU0sRUFBRTtRQUFFdEQsS0FBSyxFQUFFLENBQUMrQyxJQUFJO01BQUU7SUFBRSxDQUFDLENBQUM7SUFFbEUsSUFBQXpILGNBQU0sRUFBQ3dILE1BQU0sQ0FBQyxDQUFDbkgsb0JBQW9CLENBQUM1QixRQUFRLEVBQUUsTUFBTSxFQUFFLENBQUNnSixJQUFJLENBQUMsQ0FBQztFQUMvRCxDQUFDLENBQUM7RUFFRixJQUFBakksVUFBRSxFQUFDLGtFQUFrRSxFQUFFLFlBQVk7SUFDakYsTUFBTUMsSUFBSSxHQUFHQyxrQkFBUyxDQUFDQyxLQUFLLENBQUMsQ0FBQztJQUM5QixNQUFNNkgsTUFBTSxHQUFHeEosVUFBRSxDQUFDQyxFQUFFLENBQUMsTUFBTUUsT0FBTyxDQUFDQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0lBQzdDLE1BQU07TUFBRXlKO0lBQVUsQ0FBQyxHQUFHLElBQUFqSSxhQUFNLGVBQzFCLElBQUFwQyxXQUFBLENBQUFxQyxHQUFBLEVBQUN0QyxpQkFBQSxDQUFBSSxPQUFnQjtNQUFDbUMsS0FBSyxFQUFFLENBQUNyQixRQUFRLENBQUU7TUFBQ3NCLEVBQUUsRUFBRTFCLE1BQU87TUFBQ2tELE9BQU8sRUFBRTtRQUFFaUc7TUFBTztJQUFFLENBQUUsQ0FDekUsQ0FBQztJQUNELE1BQU0vSCxJQUFJLENBQUNhLEtBQUssQ0FBQyxNQUFNTCxhQUFNLENBQUNHLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNoRCxNQUFNSCxhQUFNLENBQUNHLFVBQVUsQ0FBQyxVQUFVLENBQUM7SUFDbkMsTUFBTVgsSUFBSSxDQUFDYSxLQUFLLENBQUNMLGFBQU0sQ0FBQ00sU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBRTlDb0IsZ0JBQVMsQ0FBQ3JCLEtBQUssQ0FBQ0wsYUFBTSxDQUFDdUIsU0FBUyxDQUFDLFFBQVEsRUFBRTtNQUFFM0QsSUFBSSxFQUFFO0lBQXVCLENBQUMsQ0FBQyxDQUFDO0lBQzdFLE1BQU00SixJQUFJLEdBQUcsSUFBSUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLEVBQUUsVUFBVSxFQUFFO01BQUV2RCxJQUFJLEVBQUU7SUFBYSxDQUFDLENBQUM7SUFDcEV4QyxnQkFBUyxDQUFDb0csTUFBTSxDQUFDSCxNQUFNLENBQUNDLFNBQVMsQ0FBQyxFQUFFO01BQUVHLE1BQU0sRUFBRTtRQUFFdEQsS0FBSyxFQUFFLENBQUMrQyxJQUFJO01BQUU7SUFBRSxDQUFDLENBQUM7SUFFbEUsSUFBQXpILGNBQU0sRUFBQ3dILE1BQU0sQ0FBQyxDQUFDbkgsb0JBQW9CLENBQUM1QixRQUFRLEVBQUUsTUFBTSxFQUFFLENBQUNnSixJQUFJLENBQUMsQ0FBQztFQUMvRCxDQUFDLENBQUM7RUFFRixJQUFBakksVUFBRSxFQUFDLGtFQUFrRSxFQUFFLFlBQVk7SUFDakYsTUFBTUMsSUFBSSxHQUFHQyxrQkFBUyxDQUFDQyxLQUFLLENBQUMsQ0FBQztJQUM5QixNQUFNNkgsTUFBTSxHQUFHeEosVUFBRSxDQUFDQyxFQUFFLENBQUMsTUFBTUUsT0FBTyxDQUFDQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0lBQzdDLE1BQU07TUFBRXlKO0lBQVUsQ0FBQyxHQUFHLElBQUFqSSxhQUFNLGVBQzFCLElBQUFwQyxXQUFBLENBQUFxQyxHQUFBLEVBQUN0QyxpQkFBQSxDQUFBSSxPQUFnQjtNQUNmbUMsS0FBSyxFQUFFLENBQUNyQixRQUFRLEVBQUVTLE9BQU8sQ0FBRTtNQUMzQmEsRUFBRSxFQUFFMUIsTUFBTztNQUNYa0QsT0FBTyxFQUFFO1FBQUVpRztNQUFPO0lBQUUsQ0FDckIsQ0FDSCxDQUFDO0lBQ0QsTUFBTS9ILElBQUksQ0FBQ2EsS0FBSyxDQUFDLE1BQU1MLGFBQU0sQ0FBQ0csVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBRXBEdUIsZ0JBQVMsQ0FBQ3JCLEtBQUssQ0FBQ0wsYUFBTSxDQUFDdUIsU0FBUyxDQUFDLFFBQVEsRUFBRTtNQUFFM0QsSUFBSSxFQUFFO0lBQWdDLENBQUMsQ0FBQyxDQUFDO0lBQ3RGLE1BQU00SixJQUFJLEdBQUcsSUFBSUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLEVBQUUsVUFBVSxFQUFFO01BQUV2RCxJQUFJLEVBQUU7SUFBYSxDQUFDLENBQUM7SUFDcEV4QyxnQkFBUyxDQUFDb0csTUFBTSxDQUFDSCxNQUFNLENBQUNDLFNBQVMsQ0FBQyxFQUFFO01BQUVHLE1BQU0sRUFBRTtRQUFFdEQsS0FBSyxFQUFFLENBQUMrQyxJQUFJO01BQUU7SUFBRSxDQUFDLENBQUM7SUFFbEUsSUFBQXpILGNBQU0sRUFBQ3dILE1BQU0sQ0FBQyxDQUFDbkgsb0JBQW9CLENBQUM1QixRQUFRLEVBQUUsR0FBRyxFQUFFLENBQUNnSixJQUFJLENBQUMsQ0FBQztFQUM1RCxDQUFDLENBQUM7RUFFRixJQUFBakksVUFBRSxFQUFDLHVFQUF1RSxFQUFFLFlBQVk7SUFDdEYsSUFBQUksYUFBTSxlQUNKLElBQUFwQyxXQUFBLENBQUFxQyxHQUFBLEVBQUN0QyxpQkFBQSxDQUFBSSxPQUFnQjtNQUFDbUMsS0FBSyxFQUFFLENBQUNaLE9BQU8sQ0FBRTtNQUFDYSxFQUFFLEVBQUUxQixNQUFPO01BQUNrRCxPQUFPLEVBQUU7UUFBRWlHLE1BQU0sRUFBRXhKLFVBQUUsQ0FBQ0MsRUFBRSxDQUFDO01BQUU7SUFBRSxDQUFFLENBQ2pGLENBQUM7SUFDRCxNQUFNZ0MsYUFBTSxDQUFDRyxVQUFVLENBQUMsU0FBUyxDQUFDO0lBQ2xDLElBQUFKLGNBQU0sRUFBQ0MsYUFBTSxDQUFDeUIsV0FBVyxDQUFDLFFBQVEsRUFBRTtNQUFFN0QsSUFBSSxFQUFFO0lBQW1CLENBQUMsQ0FBQyxDQUFDLENBQUNvRCxHQUFHLENBQUNkLGlCQUFpQixDQUFDLENBQUM7RUFDNUYsQ0FBQyxDQUFDO0VBRUYsSUFBQVgsVUFBRSxFQUFDLHNGQUFzRixFQUFFLFlBQVk7SUFDckc7SUFDQTtJQUNBO0lBQ0E7SUFDQSxNQUFNQyxJQUFJLEdBQUdDLGtCQUFTLENBQUNDLEtBQUssQ0FBQyxDQUFDO0lBQzlCLE1BQU02SCxNQUFNLEdBQUd4SixVQUFFLENBQUNDLEVBQUUsQ0FBQyxNQUFNRSxPQUFPLENBQUNDLE9BQU8sQ0FBQyxDQUFDLENBQUM7SUFDN0MsTUFBTTZKLE9BQXFCLEdBQUc7TUFDNUIsR0FBRy9JLE9BQU87TUFDVkwsUUFBUSxFQUFFLElBQUk7TUFDZEMsTUFBTSxFQUFFLENBQUM7UUFBRUMsT0FBTyxFQUFFLEdBQUc7UUFBRUMsSUFBSSxFQUFFO01BQUssQ0FBQztJQUN2QyxDQUFDO0lBQ0QsTUFBTTtNQUFFNkk7SUFBVSxDQUFDLEdBQUcsSUFBQWpJLGFBQU0sZUFDMUIsSUFBQXBDLFdBQUEsQ0FBQXFDLEdBQUEsRUFBQ3RDLGlCQUFBLENBQUFJLE9BQWdCO01BQUNtQyxLQUFLLEVBQUUsQ0FBQ3JCLFFBQVEsRUFBRXdKLE9BQU8sQ0FBRTtNQUFDbEksRUFBRSxFQUFFMUIsTUFBTztNQUFDa0QsT0FBTyxFQUFFO1FBQUVpRztNQUFPO0lBQUUsQ0FBRSxDQUNsRixDQUFDOztJQUVEO0lBQ0EsTUFBTS9ILElBQUksQ0FBQ2EsS0FBSyxDQUFDLE1BQU1MLGFBQU0sQ0FBQ0csVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ2pEdUIsZ0JBQVMsQ0FBQ3JCLEtBQUssQ0FBQ0wsYUFBTSxDQUFDdUIsU0FBUyxDQUFDLFFBQVEsRUFBRTtNQUFFM0QsSUFBSSxFQUFFO0lBQXdCLENBQUMsQ0FBQyxDQUFDO0lBQzlFLE1BQU00SixJQUFJLEdBQUcsSUFBSUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLEVBQUUsT0FBTyxFQUFFO01BQUV2RCxJQUFJLEVBQUU7SUFBYSxDQUFDLENBQUM7SUFDakV4QyxnQkFBUyxDQUFDb0csTUFBTSxDQUFDSCxNQUFNLENBQUNDLFNBQVMsQ0FBQyxFQUFFO01BQUVHLE1BQU0sRUFBRTtRQUFFdEQsS0FBSyxFQUFFLENBQUMrQyxJQUFJO01BQUU7SUFBRSxDQUFDLENBQUM7SUFDbEUsSUFBQXpILGNBQU0sRUFBQ3dILE1BQU0sQ0FBQyxDQUFDbkgsb0JBQW9CLENBQUM0SCxPQUFPLEVBQUUsT0FBTyxFQUFFLENBQUNSLElBQUksQ0FBQyxDQUFDOztJQUU3RDtJQUNBO0lBQ0EsTUFBTWhJLElBQUksQ0FBQ2EsS0FBSyxDQUFDLE1BQU1MLGFBQU0sQ0FBQ0csVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQ3BEdUIsZ0JBQVMsQ0FBQ3JCLEtBQUssQ0FBQ0wsYUFBTSxDQUFDdUIsU0FBUyxDQUFDLFFBQVEsRUFBRTtNQUFFM0QsSUFBSSxFQUFFO0lBQThCLENBQUMsQ0FBQyxDQUFDO0lBQ3BGOEQsZ0JBQVMsQ0FBQ29HLE1BQU0sQ0FBQ0gsTUFBTSxDQUFDQyxTQUFTLENBQUMsRUFBRTtNQUFFRyxNQUFNLEVBQUU7UUFBRXRELEtBQUssRUFBRSxDQUFDK0MsSUFBSTtNQUFFO0lBQUUsQ0FBQyxDQUFDO0lBQ2xFLElBQUF6SCxjQUFNLEVBQUN3SCxNQUFNLENBQUMsQ0FBQzlELHdCQUF3QixDQUFDdUUsT0FBTyxFQUFFLEdBQUcsRUFBRSxDQUFDUixJQUFJLENBQUMsQ0FBQztFQUMvRCxDQUFDLENBQUM7RUFFRixJQUFBakksVUFBRSxFQUFDLDZGQUE2RixFQUFFLFlBQVk7SUFDNUc7SUFDQTtJQUNBLE1BQU1DLElBQUksR0FBR0Msa0JBQVMsQ0FBQ0MsS0FBSyxDQUFDLENBQUM7SUFDOUIsTUFBTTZILE1BQU0sR0FBR3hKLFVBQUUsQ0FBQ0MsRUFBRSxDQUFDLE1BQU1FLE9BQU8sQ0FBQ0MsT0FBTyxDQUFDLENBQUMsQ0FBQztJQUM3QyxNQUFNO01BQUV5SjtJQUFVLENBQUMsR0FBRyxJQUFBakksYUFBTSxlQUMxQixJQUFBcEMsV0FBQSxDQUFBcUMsR0FBQSxFQUFDdEMsaUJBQUEsQ0FBQUksT0FBZ0I7TUFDZm1DLEtBQUssRUFBRSxDQUFDckIsUUFBUSxDQUFFO01BQ2xCc0IsRUFBRSxFQUFFMUIsTUFBTztNQUNYa0QsT0FBTyxFQUFFO1FBQUVpRztNQUFPLENBQUU7TUFDcEIxRSxNQUFNLEVBQUMsTUFBTTtNQUNiUyxhQUFhLEVBQUM7SUFBTSxDQUNyQixDQUNILENBQUM7SUFDRDtJQUNBLE1BQU05RCxJQUFJLENBQUNhLEtBQUssQ0FBQyxNQUFNTCxhQUFNLENBQUNDLFVBQVUsQ0FBQyxRQUFRLEVBQUU7TUFBRXJDLElBQUksRUFBRTtJQUFRLENBQUMsQ0FBQyxDQUFDO0lBQ3RFLE1BQU00QixJQUFJLENBQUNhLEtBQUssQ0FBQyxNQUFNTCxhQUFNLENBQUNDLFVBQVUsQ0FBQyxRQUFRLEVBQUU7TUFBRXJDLElBQUksRUFBRTtJQUFPLENBQUMsQ0FBQyxDQUFDO0lBRXJFOEQsZ0JBQVMsQ0FBQ3JCLEtBQUssQ0FBQ0wsYUFBTSxDQUFDdUIsU0FBUyxDQUFDLFFBQVEsRUFBRTtNQUFFM0QsSUFBSSxFQUFFO0lBQWdDLENBQUMsQ0FBQyxDQUFDO0lBQ3RGOEQsZ0JBQVMsQ0FBQ29HLE1BQU0sQ0FBQ0gsTUFBTSxDQUFDQyxTQUFTLENBQUMsRUFBRTtNQUNsQ0csTUFBTSxFQUFFO1FBQUV0RCxLQUFLLEVBQUUsQ0FBQyxJQUFJZ0QsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLEVBQUUsT0FBTyxFQUFFO1VBQUV2RCxJQUFJLEVBQUU7UUFBYSxDQUFDLENBQUM7TUFBRTtJQUMxRSxDQUFDLENBQUM7SUFDRixJQUFBbkUsY0FBTSxFQUFDd0gsTUFBTSxDQUFDLENBQUNuSCxvQkFBb0IsQ0FBQzVCLFFBQVEsRUFBRSxHQUFHLEVBQUUsQ0FDakR1QixjQUFNLENBQUNrSSxnQkFBZ0IsQ0FBQztNQUFFckssSUFBSSxFQUFFO0lBQVEsQ0FBQyxDQUFDLENBQzNDLENBQUM7RUFDSixDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7O0FBRUY7QUFDQSxJQUFBMEIsZ0JBQVEsRUFBQyxvRUFBb0UsRUFBRSxNQUFNO0VBQ25GLElBQUFDLFVBQUUsRUFBQyxxRUFBcUUsRUFBRSxZQUFZO0lBQ3BGLE1BQU11QyxHQUFHLEdBQUcvRCxVQUFFLENBQUNDLEVBQUUsQ0FBQyxNQUFNRSxPQUFPLENBQUNDLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQztJQUN0RCxNQUFNcUIsSUFBSSxHQUFHQyxrQkFBUyxDQUFDQyxLQUFLLENBQUMsQ0FBQztJQUM5QixJQUFBQyxhQUFNLGVBQ0osSUFBQXBDLFdBQUEsQ0FBQXFDLEdBQUEsRUFBQ3RDLGlCQUFBLENBQUFJLE9BQWdCO01BQ2ZtQyxLQUFLLEVBQUUsQ0FBQ3JCLFFBQVEsQ0FBRTtNQUNsQnNCLEVBQUUsRUFBRTFCLE1BQU87TUFDWHlFLE1BQU0sRUFBQyxNQUFNO01BQ2J2QixPQUFPLEVBQUU7UUFBRVUsTUFBTSxFQUFFRjtNQUFJO0lBQUUsQ0FDMUIsQ0FDSCxDQUFDO0lBQ0Q7SUFDQSxNQUFNdEMsSUFBSSxDQUFDYSxLQUFLLENBQUMsTUFBTUwsYUFBTSxDQUFDQyxVQUFVLENBQUMsUUFBUSxFQUFFO01BQUVyQyxJQUFJLEVBQUU7SUFBUSxDQUFDLENBQUMsQ0FBQztJQUN0RSxNQUFNc0ssTUFBTSxHQUFHLE1BQU1sSSxhQUFNLENBQUNDLFVBQVUsQ0FBQyxRQUFRLEVBQUU7TUFBRXJDLElBQUksRUFBRTtJQUFhLENBQUMsQ0FBQztJQUN4RXNLLE1BQU0sQ0FBQ2YsS0FBSyxDQUFDLENBQUM7SUFDZCxNQUFNM0gsSUFBSSxDQUFDMkUsUUFBUSxDQUFDLHVCQUF1QixDQUFDO0lBQzVDLE1BQU12QyxJQUFJLEdBQUcsTUFBTTVCLGFBQU0sQ0FBQ0MsVUFBVSxDQUFDLE1BQU0sQ0FBQztJQUM1QyxJQUFBRixjQUFNLEVBQUMsSUFBQThCLGFBQU0sRUFBQ0QsSUFBSSxDQUFDLENBQUNMLFNBQVMsQ0FBQyxVQUFVLEVBQUU7TUFBRTNELElBQUksRUFBRTtJQUFVLENBQUMsQ0FBQyxDQUFDLENBQUNzQyxpQkFBaUIsQ0FBQyxDQUFDO0VBQ3JGLENBQUMsQ0FBQztFQUVGLElBQUFYLFVBQUUsRUFBQyxrRUFBa0UsRUFBRSxZQUFZO0lBQ2pGLE1BQU1DLElBQUksR0FBR0Msa0JBQVMsQ0FBQ0MsS0FBSyxDQUFDLENBQUM7SUFDOUIsSUFBQUMsYUFBTSxlQUFDLElBQUFwQyxXQUFBLENBQUFxQyxHQUFBLEVBQUN0QyxpQkFBQSxDQUFBSSxPQUFnQjtNQUFDbUMsS0FBSyxFQUFFLENBQUNyQixRQUFRLENBQUU7TUFBQ3NCLEVBQUUsRUFBRTFCLE1BQU87TUFBQ2tELE9BQU8sRUFBRTtRQUFFSCxJQUFJLEVBQUVwRCxVQUFFLENBQUNDLEVBQUUsQ0FBQztNQUFFO0lBQUUsQ0FBRSxDQUFDLENBQUM7SUFDdkYsTUFBTWtLLE1BQU0sR0FBRyxNQUFNbEksYUFBTSxDQUFDQyxVQUFVLENBQUMsVUFBVSxFQUFFO01BQUVyQyxJQUFJLEVBQUU7SUFBWSxDQUFDLENBQUM7SUFDekVzSyxNQUFNLENBQUNmLEtBQUssQ0FBQyxDQUFDO0lBQ2QsTUFBTTNILElBQUksQ0FBQzJFLFFBQVEsQ0FBQyxlQUFlLENBQUM7SUFDcEMsTUFBTXZDLElBQUksR0FBRyxNQUFNNUIsYUFBTSxDQUFDQyxVQUFVLENBQUMsTUFBTSxDQUFDO0lBQzVDLElBQUFGLGNBQU0sRUFBQyxJQUFBOEIsYUFBTSxFQUFDRCxJQUFJLENBQUMsQ0FBQ0wsU0FBUyxDQUFDLFVBQVUsRUFBRTtNQUFFM0QsSUFBSSxFQUFFO0lBQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQ3NDLGlCQUFpQixDQUFDLENBQUM7RUFDbEYsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDOztBQUVGO0FBQ0EsSUFBQVosZ0JBQVEsRUFBQyxxQkFBcUIsRUFBRSxNQUFNO0VBQ3BDLElBQUFDLFVBQUUsRUFBQyxtRUFBbUUsRUFBRSxZQUFZO0lBQ2xGLE1BQU11RSxNQUFNLEdBQUcvRixVQUFFLENBQUNDLEVBQUUsQ0FBQyxNQUFNRSxPQUFPLENBQUNDLE9BQU8sQ0FBQztNQUFFUCxJQUFJLEVBQUUsV0FBVztNQUFFQyxLQUFLLEVBQUU7SUFBTSxDQUFDLENBQUMsQ0FBQztJQUNoRixNQUFNMkIsSUFBSSxHQUFHQyxrQkFBUyxDQUFDQyxLQUFLLENBQUMsQ0FBQztJQUM5QixJQUFBQyxhQUFNLGVBQUMsSUFBQXBDLFdBQUEsQ0FBQXFDLEdBQUEsRUFBQ3RDLGlCQUFBLENBQUFJLE9BQWdCO01BQUNtQyxLQUFLLEVBQUUsQ0FBQ3JCLFFBQVEsQ0FBRTtNQUFDc0IsRUFBRSxFQUFFMUIsTUFBTztNQUFDa0QsT0FBTyxFQUFFO1FBQUV3QztNQUFPO0lBQUUsQ0FBRSxDQUFDLENBQUM7SUFDaEYsTUFBTTlELGFBQU0sQ0FBQ0csVUFBVSxDQUFDLEtBQUssQ0FBQztJQUM5QnVCLGdCQUFTLENBQUNDLFdBQVcsQ0FBQzNCLGFBQU0sQ0FBQ00sU0FBUyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQ3BELE1BQU1zQixJQUFJLEdBQUcsTUFBTTVCLGFBQU0sQ0FBQ0MsVUFBVSxDQUFDLE1BQU0sQ0FBQztJQUM1QyxNQUFNVCxJQUFJLENBQUNhLEtBQUssQ0FBQyxJQUFBd0IsYUFBTSxFQUFDRCxJQUFJLENBQUMsQ0FBQ0wsU0FBUyxDQUFDLFVBQVUsRUFBRTtNQUFFM0QsSUFBSSxFQUFFO0lBQVUsQ0FBQyxDQUFDLENBQUM7SUFDekUsTUFBTWlKLE1BQU0sR0FBRyxNQUFNN0csYUFBTSxDQUFDQyxVQUFVLENBQUMsUUFBUSxFQUFFO01BQUVyQyxJQUFJLEVBQUU7SUFBNkIsQ0FBQyxDQUFDOztJQUV4RjtJQUNBO0lBQ0EsTUFBTTRCLElBQUksQ0FBQ2EsS0FBSyxDQUFDLElBQUF3QixhQUFNLEVBQUNnRixNQUFNLENBQUMsQ0FBQ3RGLFNBQVMsQ0FBQyxVQUFVLEVBQUU7TUFBRTNELElBQUksRUFBRTtJQUFNLENBQUMsQ0FBQyxDQUFDOztJQUV2RTtJQUNBO0lBQ0EsTUFBTXVLLFlBQVksR0FBRyxDQUNuQixHQUFHdEIsTUFBTSxDQUFDdUIsZ0JBQWdCLENBQWMsaUNBQWlDLENBQUMsQ0FDM0UsQ0FBQ0MsR0FBRyxDQUFDLENBQUU7SUFDUkYsWUFBWSxDQUFDaEIsS0FBSyxDQUFDLENBQUM7SUFDcEIsSUFBSW1CLE9BQU8sR0FBRyxLQUFLO0lBQ25CLEtBQUssSUFBSUMsQ0FBQyxHQUFHLENBQUMsRUFBRUEsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDRCxPQUFPLEVBQUVDLENBQUMsRUFBRSxFQUFFO01BQ3RDLE1BQU0vSSxJQUFJLENBQUMyRSxRQUFRLENBQUMsT0FBTyxDQUFDO01BQzVCbUUsT0FBTyxHQUFHRSxRQUFRLENBQUNDLGFBQWEsRUFBRUMsV0FBVyxLQUFLLFdBQVc7SUFDL0Q7SUFDQSxJQUFBM0ksY0FBTSxFQUFDdUksT0FBTyxDQUFDLENBQUNwRixJQUFJLENBQUMsSUFBSSxDQUFDO0lBQzFCLElBQUFuRCxjQUFNLEVBQUN5SSxRQUFRLENBQUNDLGFBQWEsQ0FBQyxDQUFDdkYsSUFBSSxDQUNqQyxJQUFBckIsYUFBTSxFQUFDZ0YsTUFBTSxDQUFDLENBQUN0RixTQUFTLENBQUMsUUFBUSxFQUFFO01BQUUzRCxJQUFJLEVBQUU7SUFBWSxDQUFDLENBQzFELENBQUM7RUFDSCxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7O0FBRUY7QUFDQSxJQUFBMEIsZ0JBQVEsRUFBQyx5QkFBeUIsRUFBRSxNQUFNO0VBQ3hDLElBQUFDLFVBQUUsRUFBQywwREFBMEQsRUFBRSxZQUFZO0lBQ3pFLE1BQU1DLElBQUksR0FBR0Msa0JBQVMsQ0FBQ0MsS0FBSyxDQUFDLENBQUM7SUFDOUIsSUFBQUMsYUFBTSxlQUFDLElBQUFwQyxXQUFBLENBQUFxQyxHQUFBLEVBQUN0QyxpQkFBQSxDQUFBSSxPQUFnQjtNQUFDbUMsS0FBSyxFQUFFLENBQUNyQixRQUFRLENBQUU7TUFBQ3NCLEVBQUUsRUFBRTFCO0lBQU8sQ0FBRSxDQUFDLENBQUM7SUFDM0QsTUFBTTRCLGFBQU0sQ0FBQ0csVUFBVSxDQUFDLEtBQUssQ0FBQztJQUM5QixNQUFNWCxJQUFJLENBQUNhLEtBQUssQ0FBQ0wsYUFBTSxDQUFDTSxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDekMsTUFBTU4sYUFBTSxDQUFDRyxVQUFVLENBQUMsVUFBVSxDQUFDO0lBRW5DSCxhQUFNLENBQUN1QixTQUFTLENBQUMsVUFBVSxFQUFFO01BQUUzRCxJQUFJLEVBQUU7SUFBTSxDQUFDLENBQUMsQ0FBQ3VKLEtBQUssQ0FBQyxDQUFDO0lBQ3JELE1BQU0zSCxJQUFJLENBQUMyRSxRQUFRLENBQUMsY0FBYyxDQUFDO0lBQ25DLElBQUFwRSxjQUFNLEVBQUNDLGFBQU0sQ0FBQ3VCLFNBQVMsQ0FBQyxVQUFVLEVBQUU7TUFBRTNELElBQUksRUFBRTtJQUFXLENBQUMsQ0FBQyxDQUFDLENBQUNxRyxXQUFXLENBQUMsQ0FBQztFQUMxRSxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}