"use strict";

require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
var _nodeFs = require("node:fs");
var _nodePath = require("node:path");
var _vitest = require("vitest");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; } // R3-267 — the SDK half: the manifest↔code parity that keeps the declared contract
// list honest, the marker probe, and the invoke's delegation + refusal handling.
const invokeTask = _vitest.vi.fn();
const launch = _vitest.vi.fn();
const capDir = _vitest.vi.fn((ref, opts) => ({
  $cap: "dir",
  ...ref,
  ...opts
}));
_vitest.vi.mock("@immediately-run/sdk", () => ({
  invokeTask: (...a) => invokeTask(...a),
  launch: (...a) => launch(...a),
  capDir: (...a) => capDir(...a)
}));
const {
  DECLARED_TASKS,
  DECLARED_LAUNCHES,
  MAX_MARKER_BYTES,
  openInPlace,
  openWith,
  probeOffer,
  readMarker
} = await Promise.resolve().then(() => _interopRequireWildcard(require("./openWith")));
const enc = s => new TextEncoder().encode(s);
const fsWith = files => ({
  readdir: async () => [],
  readFile: async p => {
    const v = files[p];
    if (v === undefined) throw Object.assign(new Error("ENOENT"), {
      code: "ENOENT"
    });
    return typeof v === "string" ? enc(v) : v;
  }
});
const root = (over = {}) => ({
  id: "space:abc",
  path: "/spaces/abc",
  label: "Notes",
  kind: "space",
  writable: false,
  grants: [{
    subtree: "/",
    mode: "rw"
  }],
  ...over
});
(0, _vitest.beforeEach)(() => {
  invokeTask.mockReset();
  launch.mockReset();
  capDir.mockClear();
  invokeTask.mockResolvedValue({
    opened: true
  });
  launch.mockResolvedValue({
    launchId: "launch-1",
    onDismiss: () => () => {}
  });
});
(0, _vitest.describe)("DECLARED_TASKS mirrors the manifest — §5.8 least authority, pinned", () => {
  // Read from the repo root (vitest's cwd) rather than a module URL: the shipped app is
  // transpiled to CommonJS, where that token is a parse-time SyntaxError.
  const manifest = JSON.parse((0, _nodeFs.readFileSync)((0, _nodePath.join)(process.cwd(), "package.json"), "utf8"));
  const declared = manifest["immediately.run"]?.invokes ?? [];
  (0, _vitest.it)("declares in package.json exactly the contracts the code will offer", () => {
    (0, _vitest.expect)([...declared.map(d => d.task)].sort()).toEqual([...DECLARED_TASKS].sort());
  });
  (0, _vitest.it)("requests the capability those invocations need", () => {
    (0, _vitest.expect)(manifest["immediately.run"]?.requests).toHaveProperty("task:invoke");
  });
});
(0, _vitest.describe)("DECLARED_LAUNCHES mirrors the manifest (R3-159) — R-SAL-3, pinned", () => {
  const manifest = JSON.parse((0, _nodeFs.readFileSync)((0, _nodePath.join)(process.cwd(), "package.json"), "utf8"));
  (0, _vitest.it)("declares in package.json exactly the contracts the code will launch in place", () => {
    const declared = manifest["immediately.run"]?.launches ?? [];
    (0, _vitest.expect)([...declared.map(d => d.task)].sort()).toEqual([...DECLARED_LAUNCHES].sort());
  });
  (0, _vitest.it)("launches a SUBSET of the invocable contracts — launch never exceeds invoke", () => {
    for (const task of DECLARED_LAUNCHES) (0, _vitest.expect)(DECLARED_TASKS).toContain(task);
  });
});
(0, _vitest.describe)("readMarker", () => {
  (0, _vitest.it)("reads the marker file beside the directory", async () => {
    const fs = fsWith({
      "/spaces/abc/wiki/immediately.run.json": '{"opensWith":{"task":"open-wiki"}}'
    });
    await (0, _vitest.expect)(readMarker(fs, "/spaces/abc/wiki")).resolves.toContain("open-wiki");
  });
  (0, _vitest.it)("returns null when the folder carries none (the common case)", async () => {
    await (0, _vitest.expect)(readMarker(fsWith({}), "/spaces/abc/src")).resolves.toBeNull();
  });
  (0, _vitest.it)("returns null when the fs cannot read bytes at all", async () => {
    await (0, _vitest.expect)(readMarker({
      readdir: async () => []
    }, "/spaces/abc")).resolves.toBeNull();
  });
  (0, _vitest.it)("refuses to decode an absurdly large 'marker' rather than doing that work", async () => {
    const fs = fsWith({
      "/spaces/abc/x/immediately.run.json": new Uint8Array(MAX_MARKER_BYTES + 1)
    });
    await (0, _vitest.expect)(readMarker(fs, "/spaces/abc/x")).resolves.toBeNull();
  });
});
(0, _vitest.describe)("probeOffer", () => {
  (0, _vitest.it)("offers a declared contract, labelled from the marker's kind", async () => {
    const fs = fsWith({
      "/spaces/abc/wiki/immediately.run.json": '{"opensWith":{"task":"open-wiki"},"kind":"wiki"}'
    });
    await (0, _vitest.expect)(probeOffer(fs, "/spaces/abc/wiki", {
      offerable: DECLARED_TASKS
    })).resolves.toEqual({
      task: "open-wiki",
      version: "1.0",
      label: "Open as wiki"
    });
  });
  (0, _vitest.it)("offers open-workbook — the workbook corpus's door (R3-754)", async () => {
    const fs = fsWith({
      "/content/wb/immediately.run.json": '{"opensWith":{"task":"open-workbook"},"kind":"workbook"}'
    });
    await (0, _vitest.expect)(probeOffer(fs, "/content/wb", {
      offerable: DECLARED_TASKS
    })).resolves.toEqual({
      task: "open-workbook",
      version: "1.0",
      label: "Open as workbook"
    });
  });
  (0, _vitest.it)("offers the roadmap board's app-form marker through open-declared, and invokes it with the folder alone (R3-547)", async () => {
    // The marker docs/content/roadmap/board/ actually carries.
    const fs = fsWith({
      "/docs/content/roadmap/board/immediately.run.json": JSON.stringify({
        opensWith: {
          app: "github:immediately-run/kanban-board",
          version: "1.0"
        },
        kind: "board"
      })
    });
    const offer = await probeOffer(fs, "/docs/content/roadmap/board", {
      offerable: DECLARED_TASKS
    });
    (0, _vitest.expect)(offer).toEqual({
      task: "open-declared",
      version: "1.0",
      label: "Open as board"
    });
    await openWith(root({
      id: "space:docs",
      path: "/docs"
    }), "/docs/content/roadmap/board", offer);
    (0, _vitest.expect)(invokeTask.mock.calls[0][0]).toBe("open-declared");
    // `dir` and nothing else — an `app` key is the retired open-with shape the host refuses.
    (0, _vitest.expect)(Object.keys(invokeTask.mock.calls[0][1])).toEqual(["dir"]);
    (0, _vitest.expect)(JSON.stringify(invokeTask.mock.calls[0])).not.toContain("kanban-board");
  });
  (0, _vitest.it)("a declared view is invoked through open-declared with dir AND the view's name — never its app (R3-789)", async () => {
    const offer = {
      task: "open-declared",
      version: "1.0",
      label: "Open as Roadmap board",
      view: "Roadmap board"
    };
    await openWith(root({
      id: "space:docs",
      path: "/docs"
    }), "/docs/content", offer);
    (0, _vitest.expect)(invokeTask.mock.calls[0][0]).toBe("open-declared");
    (0, _vitest.expect)(Object.keys(invokeTask.mock.calls[0][1]).sort()).toEqual(["dir", "view"]);
    (0, _vitest.expect)(invokeTask.mock.calls[0][1].view).toBe("Roadmap board");
  });
  (0, _vitest.it)("offers nothing for a marker naming a contract this app does not invoke", async () => {
    const fs = fsWith({
      "/spaces/abc/x/immediately.run.json": '{"opensWith":{"task":"open-hologram"}}'
    });
    await (0, _vitest.expect)(probeOffer(fs, "/spaces/abc/x", {
      offerable: DECLARED_TASKS
    })).resolves.toBeNull();
  });
});
(0, _vitest.describe)("openWith — delegates the folder, and only the folder", () => {
  const offer = {
    task: "open-wiki",
    version: "1.0",
    label: "Open as wiki"
  };
  (0, _vitest.it)("invokes the marker's contract with a capDir for that directory", async () => {
    await (0, _vitest.expect)(openWith(root(), "/spaces/abc/wiki", offer)).resolves.toEqual({
      status: "opened"
    });
    (0, _vitest.expect)(invokeTask).toHaveBeenCalledTimes(1);
    (0, _vitest.expect)(invokeTask.mock.calls[0][0]).toBe("open-wiki");
    (0, _vitest.expect)(capDir).toHaveBeenCalledWith({
      mountId: "space:abc",
      relPath: "/wiki"
    }, {
      mode: "rw"
    });
  });
  (0, _vitest.it)("delegates at the mount's OWN mode — a ro grant opens a ro corpus (R3-266)", async () => {
    await openWith(root({
      grants: [{
        subtree: "/",
        mode: "ro"
      }]
    }), "/spaces/abc/wiki", offer);
    (0, _vitest.expect)(capDir).toHaveBeenCalledWith({
      mountId: "space:abc",
      relPath: "/wiki"
    }, {
      mode: "ro"
    });
  });
  (0, _vitest.it)("honours the longest matching grant rule, not the mount-wide one", async () => {
    const r = root({
      grants: [{
        subtree: "/",
        mode: "ro"
      }, {
        subtree: "/wiki",
        mode: "rw"
      }]
    });
    await openWith(r, "/spaces/abc/wiki", offer);
    (0, _vitest.expect)(capDir).toHaveBeenCalledWith({
      mountId: "space:abc",
      relPath: "/wiki"
    }, {
      mode: "rw"
    });
  });
  (0, _vitest.it)("asks for ro when the grant rule-set is unknown (never over-asks)", async () => {
    await openWith(root({
      grants: undefined
    }), "/spaces/abc/wiki", offer);
    (0, _vitest.expect)(capDir).toHaveBeenCalledWith({
      mountId: "space:abc",
      relPath: "/wiki"
    }, {
      mode: "ro"
    });
  });
  (0, _vitest.it)("treats a user-closed viewer as ordinary — the affordance stays", async () => {
    invokeTask.mockRejectedValue(Object.assign(new Error("no"), {
      code: "cancelled"
    }));
    await (0, _vitest.expect)(openWith(root(), "/spaces/abc/wiki", offer)).resolves.toEqual({
      status: "declined"
    });
  });
  (0, _vitest.it)("withdraws a contract nothing is bound to, instead of surfacing no-such-task", async () => {
    invokeTask.mockRejectedValue(Object.assign(new Error("no"), {
      code: "no-such-task"
    }));
    await (0, _vitest.expect)(openWith(root(), "/spaces/abc/wiki", offer)).resolves.toEqual({
      status: "withdraw",
      task: "open-wiki"
    });
  });
  (0, _vitest.it)("never rethrows a protocol error at the caller, whatever the code", async () => {
    invokeTask.mockRejectedValue(Object.assign(new Error("boom"), {
      code: "forbidden"
    }));
    await (0, _vitest.expect)(openWith(root(), "/spaces/abc/wiki", offer)).resolves.toEqual({
      status: "declined"
    });
    invokeTask.mockRejectedValue(new Error("no code at all"));
    await (0, _vitest.expect)(openWith(root(), "/spaces/abc/wiki", offer)).resolves.toEqual({
      status: "declined"
    });
  });
});
(0, _vitest.describe)("openInPlace — run the folder's project TO-RUN in the stage (R3-159)", () => {
  const offer = {
    task: "open-project",
    version: "1.0",
    label: "Open in place"
  };
  (0, _vitest.it)("launches the marker's contract into the stage with a capDir for that directory", async () => {
    await (0, _vitest.expect)(openInPlace(root(), "/spaces/abc/proj", offer)).resolves.toEqual({
      status: "opened"
    });
    (0, _vitest.expect)(launch).toHaveBeenCalledTimes(1);
    const [target, opts] = launch.mock.calls[0];
    (0, _vitest.expect)(target).toEqual({
      task: "open-project"
    });
    (0, _vitest.expect)(opts.region).toBe("stage");
    (0, _vitest.expect)(capDir).toHaveBeenCalledWith({
      mountId: "space:abc",
      relPath: "/proj"
    }, {
      mode: "ro"
    });
  });
  (0, _vitest.it)("delegates ro even on an rw mount — the R-SAL-6 default, unlike openWith", async () => {
    // The rw-into-stage host confirm is a follow-on; the into-stage capDir ships ro.
    await openInPlace(root({
      grants: [{
        subtree: "/",
        mode: "rw"
      }]
    }), "/spaces/abc/proj", offer);
    (0, _vitest.expect)(capDir).toHaveBeenCalledWith({
      mountId: "space:abc",
      relPath: "/proj"
    }, {
      mode: "ro"
    });
  });
  (0, _vitest.it)("pins the whole LaunchErrorCode union — EVERY refusal declines, none withdraws", async () => {
    // The host resolves `unsupported` for transient states too (launch host not yet
    // mounted, absent launch context, create failing before bind), so no launch code
    // is a safe session-permanent verdict — a fork's `forbidden` and a full stage's
    // `budget` included, the affordance always stays.
    for (const code of ["forbidden", "unsupported", "budget", "revoked", "cancelled", "invalid-params", "unknown"]) {
      launch.mockResolvedValue({
        ok: false,
        code
      });
      await (0, _vitest.expect)(openInPlace(root(), "/spaces/abc/proj", offer)).resolves.toEqual({
        status: "declined"
      });
    }
  });
  (0, _vitest.it)("never throws — an off-host rejection is ordinary too", async () => {
    launch.mockRejectedValue(new Error("no host transport"));
    await (0, _vitest.expect)(openInPlace(root(), "/spaces/abc/proj", offer)).resolves.toEqual({
      status: "declined"
    });
    launch.mockRejectedValue(Object.assign(new Error("nope"), {
      code: "unsupported"
    }));
    await (0, _vitest.expect)(openInPlace(root(), "/spaces/abc/proj", offer)).resolves.toEqual({
      status: "declined"
    });
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfbm9kZUZzIiwicmVxdWlyZSIsIl9ub2RlUGF0aCIsIl92aXRlc3QiLCJfZ2V0UmVxdWlyZVdpbGRjYXJkQ2FjaGUiLCJlIiwiV2Vha01hcCIsInIiLCJ0IiwiX2ludGVyb3BSZXF1aXJlV2lsZGNhcmQiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsImhhcyIsImdldCIsIm4iLCJfX3Byb3RvX18iLCJhIiwiT2JqZWN0IiwiZGVmaW5lUHJvcGVydHkiLCJnZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IiLCJ1IiwiaGFzT3duUHJvcGVydHkiLCJjYWxsIiwiaSIsInNldCIsImludm9rZVRhc2siLCJ2aSIsImZuIiwibGF1bmNoIiwiY2FwRGlyIiwicmVmIiwib3B0cyIsIiRjYXAiLCJtb2NrIiwiREVDTEFSRURfVEFTS1MiLCJERUNMQVJFRF9MQVVOQ0hFUyIsIk1BWF9NQVJLRVJfQllURVMiLCJvcGVuSW5QbGFjZSIsIm9wZW5XaXRoIiwicHJvYmVPZmZlciIsInJlYWRNYXJrZXIiLCJQcm9taXNlIiwicmVzb2x2ZSIsInRoZW4iLCJlbmMiLCJzIiwiVGV4dEVuY29kZXIiLCJlbmNvZGUiLCJmc1dpdGgiLCJmaWxlcyIsInJlYWRkaXIiLCJyZWFkRmlsZSIsInAiLCJ2IiwidW5kZWZpbmVkIiwiYXNzaWduIiwiRXJyb3IiLCJjb2RlIiwicm9vdCIsIm92ZXIiLCJpZCIsInBhdGgiLCJsYWJlbCIsImtpbmQiLCJ3cml0YWJsZSIsImdyYW50cyIsInN1YnRyZWUiLCJtb2RlIiwiYmVmb3JlRWFjaCIsIm1vY2tSZXNldCIsIm1vY2tDbGVhciIsIm1vY2tSZXNvbHZlZFZhbHVlIiwib3BlbmVkIiwibGF1bmNoSWQiLCJvbkRpc21pc3MiLCJkZXNjcmliZSIsIm1hbmlmZXN0IiwiSlNPTiIsInBhcnNlIiwicmVhZEZpbGVTeW5jIiwiam9pbiIsInByb2Nlc3MiLCJjd2QiLCJkZWNsYXJlZCIsImludm9rZXMiLCJpdCIsImV4cGVjdCIsIm1hcCIsImQiLCJ0YXNrIiwic29ydCIsInRvRXF1YWwiLCJyZXF1ZXN0cyIsInRvSGF2ZVByb3BlcnR5IiwibGF1bmNoZXMiLCJ0b0NvbnRhaW4iLCJmcyIsInJlc29sdmVzIiwidG9CZU51bGwiLCJVaW50OEFycmF5Iiwib2ZmZXJhYmxlIiwidmVyc2lvbiIsInN0cmluZ2lmeSIsIm9wZW5zV2l0aCIsImFwcCIsIm9mZmVyIiwiY2FsbHMiLCJ0b0JlIiwia2V5cyIsIm5vdCIsInZpZXciLCJzdGF0dXMiLCJ0b0hhdmVCZWVuQ2FsbGVkVGltZXMiLCJ0b0hhdmVCZWVuQ2FsbGVkV2l0aCIsIm1vdW50SWQiLCJyZWxQYXRoIiwibW9ja1JlamVjdGVkVmFsdWUiLCJ0YXJnZXQiLCJyZWdpb24iLCJvayJdLCJzb3VyY2VzIjpbIm9wZW5XaXRoLnRlc3QudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gUjMtMjY3IOKAlCB0aGUgU0RLIGhhbGY6IHRoZSBtYW5pZmVzdOKGlGNvZGUgcGFyaXR5IHRoYXQga2VlcHMgdGhlIGRlY2xhcmVkIGNvbnRyYWN0XG4vLyBsaXN0IGhvbmVzdCwgdGhlIG1hcmtlciBwcm9iZSwgYW5kIHRoZSBpbnZva2UncyBkZWxlZ2F0aW9uICsgcmVmdXNhbCBoYW5kbGluZy5cbmltcG9ydCB7IHJlYWRGaWxlU3luYyB9IGZyb20gXCJub2RlOmZzXCI7XG5pbXBvcnQgeyBqb2luIH0gZnJvbSBcIm5vZGU6cGF0aFwiO1xuaW1wb3J0IHsgYmVmb3JlRWFjaCwgZGVzY3JpYmUsIGV4cGVjdCwgaXQsIHZpIH0gZnJvbSBcInZpdGVzdFwiO1xuaW1wb3J0IHR5cGUgeyBFeHBsb3JlclJvb3QsIEZzU291cmNlIH0gZnJvbSBcIi4uL3R5cGVzXCI7XG5cbmNvbnN0IGludm9rZVRhc2sgPSB2aS5mbigpO1xuY29uc3QgbGF1bmNoID0gdmkuZm4oKTtcbmNvbnN0IGNhcERpciA9IHZpLmZuKChyZWY6IHVua25vd24sIG9wdHM6IHVua25vd24pID0+ICh7ICRjYXA6IFwiZGlyXCIsIC4uLihyZWYgYXMgb2JqZWN0KSwgLi4uKG9wdHMgYXMgb2JqZWN0KSB9KSk7XG5cbnZpLm1vY2soXCJAaW1tZWRpYXRlbHktcnVuL3Nka1wiLCAoKSA9PiAoe1xuICBpbnZva2VUYXNrOiAoLi4uYTogdW5rbm93bltdKSA9PiBpbnZva2VUYXNrKC4uLmEpLFxuICBsYXVuY2g6ICguLi5hOiB1bmtub3duW10pID0+IGxhdW5jaCguLi5hKSxcbiAgY2FwRGlyOiAoLi4uYTogdW5rbm93bltdKSA9PiBjYXBEaXIoLi4uKGEgYXMgW3Vua25vd24sIHVua25vd25dKSksXG59KSk7XG5cbmNvbnN0IHsgREVDTEFSRURfVEFTS1MsIERFQ0xBUkVEX0xBVU5DSEVTLCBNQVhfTUFSS0VSX0JZVEVTLCBvcGVuSW5QbGFjZSwgb3BlbldpdGgsIHByb2JlT2ZmZXIsIHJlYWRNYXJrZXIgfSA9XG4gIGF3YWl0IGltcG9ydChcIi4vb3BlbldpdGhcIik7XG5cbmNvbnN0IGVuYyA9IChzOiBzdHJpbmcpID0+IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShzKTtcblxuY29uc3QgZnNXaXRoID0gKGZpbGVzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmcgfCBVaW50OEFycmF5Pik6IEZzU291cmNlID0+ICh7XG4gIHJlYWRkaXI6IGFzeW5jICgpID0+IFtdLFxuICByZWFkRmlsZTogYXN5bmMgKHA6IHN0cmluZykgPT4ge1xuICAgIGNvbnN0IHYgPSBmaWxlc1twXTtcbiAgICBpZiAodiA9PT0gdW5kZWZpbmVkKSB0aHJvdyBPYmplY3QuYXNzaWduKG5ldyBFcnJvcihcIkVOT0VOVFwiKSwgeyBjb2RlOiBcIkVOT0VOVFwiIH0pO1xuICAgIHJldHVybiB0eXBlb2YgdiA9PT0gXCJzdHJpbmdcIiA/IGVuYyh2KSA6IHY7XG4gIH0sXG59KTtcblxuY29uc3Qgcm9vdCA9IChvdmVyOiBQYXJ0aWFsPEV4cGxvcmVyUm9vdD4gPSB7fSk6IEV4cGxvcmVyUm9vdCA9PiAoe1xuICBpZDogXCJzcGFjZTphYmNcIixcbiAgcGF0aDogXCIvc3BhY2VzL2FiY1wiLFxuICBsYWJlbDogXCJOb3Rlc1wiLFxuICBraW5kOiBcInNwYWNlXCIsXG4gIHdyaXRhYmxlOiBmYWxzZSxcbiAgZ3JhbnRzOiBbeyBzdWJ0cmVlOiBcIi9cIiwgbW9kZTogXCJyd1wiIH1dLFxuICAuLi5vdmVyLFxufSk7XG5cbmJlZm9yZUVhY2goKCkgPT4ge1xuICBpbnZva2VUYXNrLm1vY2tSZXNldCgpO1xuICBsYXVuY2gubW9ja1Jlc2V0KCk7XG4gIGNhcERpci5tb2NrQ2xlYXIoKTtcbiAgaW52b2tlVGFzay5tb2NrUmVzb2x2ZWRWYWx1ZSh7IG9wZW5lZDogdHJ1ZSB9KTtcbiAgbGF1bmNoLm1vY2tSZXNvbHZlZFZhbHVlKHsgbGF1bmNoSWQ6IFwibGF1bmNoLTFcIiwgb25EaXNtaXNzOiAoKSA9PiAoKSA9PiB7fSB9KTtcbn0pO1xuXG5kZXNjcmliZShcIkRFQ0xBUkVEX1RBU0tTIG1pcnJvcnMgdGhlIG1hbmlmZXN0IOKAlCDCpzUuOCBsZWFzdCBhdXRob3JpdHksIHBpbm5lZFwiLCAoKSA9PiB7XG4gIC8vIFJlYWQgZnJvbSB0aGUgcmVwbyByb290ICh2aXRlc3QncyBjd2QpIHJhdGhlciB0aGFuIGEgbW9kdWxlIFVSTDogdGhlIHNoaXBwZWQgYXBwIGlzXG4gIC8vIHRyYW5zcGlsZWQgdG8gQ29tbW9uSlMsIHdoZXJlIHRoYXQgdG9rZW4gaXMgYSBwYXJzZS10aW1lIFN5bnRheEVycm9yLlxuICBjb25zdCBtYW5pZmVzdCA9IEpTT04ucGFyc2UocmVhZEZpbGVTeW5jKGpvaW4ocHJvY2Vzcy5jd2QoKSwgXCJwYWNrYWdlLmpzb25cIiksIFwidXRmOFwiKSk7XG4gIGNvbnN0IGRlY2xhcmVkOiB7IHRhc2s6IHN0cmluZyB9W10gPSBtYW5pZmVzdFtcImltbWVkaWF0ZWx5LnJ1blwiXT8uaW52b2tlcyA/PyBbXTtcblxuICBpdChcImRlY2xhcmVzIGluIHBhY2thZ2UuanNvbiBleGFjdGx5IHRoZSBjb250cmFjdHMgdGhlIGNvZGUgd2lsbCBvZmZlclwiLCAoKSA9PiB7XG4gICAgZXhwZWN0KFsuLi5kZWNsYXJlZC5tYXAoKGQpID0+IGQudGFzayldLnNvcnQoKSkudG9FcXVhbChbLi4uREVDTEFSRURfVEFTS1NdLnNvcnQoKSk7XG4gIH0pO1xuXG4gIGl0KFwicmVxdWVzdHMgdGhlIGNhcGFiaWxpdHkgdGhvc2UgaW52b2NhdGlvbnMgbmVlZFwiLCAoKSA9PiB7XG4gICAgZXhwZWN0KG1hbmlmZXN0W1wiaW1tZWRpYXRlbHkucnVuXCJdPy5yZXF1ZXN0cykudG9IYXZlUHJvcGVydHkoXCJ0YXNrOmludm9rZVwiKTtcbiAgfSk7XG59KTtcblxuZGVzY3JpYmUoXCJERUNMQVJFRF9MQVVOQ0hFUyBtaXJyb3JzIHRoZSBtYW5pZmVzdCAoUjMtMTU5KSDigJQgUi1TQUwtMywgcGlubmVkXCIsICgpID0+IHtcbiAgY29uc3QgbWFuaWZlc3QgPSBKU09OLnBhcnNlKHJlYWRGaWxlU3luYyhqb2luKHByb2Nlc3MuY3dkKCksIFwicGFja2FnZS5qc29uXCIpLCBcInV0ZjhcIikpO1xuXG4gIGl0KFwiZGVjbGFyZXMgaW4gcGFja2FnZS5qc29uIGV4YWN0bHkgdGhlIGNvbnRyYWN0cyB0aGUgY29kZSB3aWxsIGxhdW5jaCBpbiBwbGFjZVwiLCAoKSA9PiB7XG4gICAgY29uc3QgZGVjbGFyZWQ6IHsgdGFzazogc3RyaW5nIH1bXSA9IG1hbmlmZXN0W1wiaW1tZWRpYXRlbHkucnVuXCJdPy5sYXVuY2hlcyA/PyBbXTtcbiAgICBleHBlY3QoWy4uLmRlY2xhcmVkLm1hcCgoZCkgPT4gZC50YXNrKV0uc29ydCgpKS50b0VxdWFsKFsuLi5ERUNMQVJFRF9MQVVOQ0hFU10uc29ydCgpKTtcbiAgfSk7XG5cbiAgaXQoXCJsYXVuY2hlcyBhIFNVQlNFVCBvZiB0aGUgaW52b2NhYmxlIGNvbnRyYWN0cyDigJQgbGF1bmNoIG5ldmVyIGV4Y2VlZHMgaW52b2tlXCIsICgpID0+IHtcbiAgICBmb3IgKGNvbnN0IHRhc2sgb2YgREVDTEFSRURfTEFVTkNIRVMpIGV4cGVjdChERUNMQVJFRF9UQVNLUykudG9Db250YWluKHRhc2spO1xuICB9KTtcbn0pO1xuXG5kZXNjcmliZShcInJlYWRNYXJrZXJcIiwgKCkgPT4ge1xuICBpdChcInJlYWRzIHRoZSBtYXJrZXIgZmlsZSBiZXNpZGUgdGhlIGRpcmVjdG9yeVwiLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgZnMgPSBmc1dpdGgoeyBcIi9zcGFjZXMvYWJjL3dpa2kvaW1tZWRpYXRlbHkucnVuLmpzb25cIjogJ3tcIm9wZW5zV2l0aFwiOntcInRhc2tcIjpcIm9wZW4td2lraVwifX0nIH0pO1xuICAgIGF3YWl0IGV4cGVjdChyZWFkTWFya2VyKGZzLCBcIi9zcGFjZXMvYWJjL3dpa2lcIikpLnJlc29sdmVzLnRvQ29udGFpbihcIm9wZW4td2lraVwiKTtcbiAgfSk7XG5cbiAgaXQoXCJyZXR1cm5zIG51bGwgd2hlbiB0aGUgZm9sZGVyIGNhcnJpZXMgbm9uZSAodGhlIGNvbW1vbiBjYXNlKVwiLCBhc3luYyAoKSA9PiB7XG4gICAgYXdhaXQgZXhwZWN0KHJlYWRNYXJrZXIoZnNXaXRoKHt9KSwgXCIvc3BhY2VzL2FiYy9zcmNcIikpLnJlc29sdmVzLnRvQmVOdWxsKCk7XG4gIH0pO1xuXG4gIGl0KFwicmV0dXJucyBudWxsIHdoZW4gdGhlIGZzIGNhbm5vdCByZWFkIGJ5dGVzIGF0IGFsbFwiLCBhc3luYyAoKSA9PiB7XG4gICAgYXdhaXQgZXhwZWN0KHJlYWRNYXJrZXIoeyByZWFkZGlyOiBhc3luYyAoKSA9PiBbXSB9LCBcIi9zcGFjZXMvYWJjXCIpKS5yZXNvbHZlcy50b0JlTnVsbCgpO1xuICB9KTtcblxuICBpdChcInJlZnVzZXMgdG8gZGVjb2RlIGFuIGFic3VyZGx5IGxhcmdlICdtYXJrZXInIHJhdGhlciB0aGFuIGRvaW5nIHRoYXQgd29ya1wiLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgZnMgPSBmc1dpdGgoeyBcIi9zcGFjZXMvYWJjL3gvaW1tZWRpYXRlbHkucnVuLmpzb25cIjogbmV3IFVpbnQ4QXJyYXkoTUFYX01BUktFUl9CWVRFUyArIDEpIH0pO1xuICAgIGF3YWl0IGV4cGVjdChyZWFkTWFya2VyKGZzLCBcIi9zcGFjZXMvYWJjL3hcIikpLnJlc29sdmVzLnRvQmVOdWxsKCk7XG4gIH0pO1xufSk7XG5cbmRlc2NyaWJlKFwicHJvYmVPZmZlclwiLCAoKSA9PiB7XG4gIGl0KFwib2ZmZXJzIGEgZGVjbGFyZWQgY29udHJhY3QsIGxhYmVsbGVkIGZyb20gdGhlIG1hcmtlcidzIGtpbmRcIiwgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IGZzID0gZnNXaXRoKHtcbiAgICAgIFwiL3NwYWNlcy9hYmMvd2lraS9pbW1lZGlhdGVseS5ydW4uanNvblwiOiAne1wib3BlbnNXaXRoXCI6e1widGFza1wiOlwib3Blbi13aWtpXCJ9LFwia2luZFwiOlwid2lraVwifScsXG4gICAgfSk7XG4gICAgYXdhaXQgZXhwZWN0KHByb2JlT2ZmZXIoZnMsIFwiL3NwYWNlcy9hYmMvd2lraVwiLCB7IG9mZmVyYWJsZTogREVDTEFSRURfVEFTS1MgfSkpLnJlc29sdmVzLnRvRXF1YWwoe1xuICAgICAgdGFzazogXCJvcGVuLXdpa2lcIixcbiAgICAgIHZlcnNpb246IFwiMS4wXCIsXG4gICAgICBsYWJlbDogXCJPcGVuIGFzIHdpa2lcIixcbiAgICB9KTtcbiAgfSk7XG5cbiAgaXQoXCJvZmZlcnMgb3Blbi13b3JrYm9vayDigJQgdGhlIHdvcmtib29rIGNvcnB1cydzIGRvb3IgKFIzLTc1NClcIiwgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IGZzID0gZnNXaXRoKHtcbiAgICAgIFwiL2NvbnRlbnQvd2IvaW1tZWRpYXRlbHkucnVuLmpzb25cIjogJ3tcIm9wZW5zV2l0aFwiOntcInRhc2tcIjpcIm9wZW4td29ya2Jvb2tcIn0sXCJraW5kXCI6XCJ3b3JrYm9va1wifScsXG4gICAgfSk7XG4gICAgYXdhaXQgZXhwZWN0KHByb2JlT2ZmZXIoZnMsIFwiL2NvbnRlbnQvd2JcIiwgeyBvZmZlcmFibGU6IERFQ0xBUkVEX1RBU0tTIH0pKS5yZXNvbHZlcy50b0VxdWFsKHtcbiAgICAgIHRhc2s6IFwib3Blbi13b3JrYm9va1wiLFxuICAgICAgdmVyc2lvbjogXCIxLjBcIixcbiAgICAgIGxhYmVsOiBcIk9wZW4gYXMgd29ya2Jvb2tcIixcbiAgICB9KTtcbiAgfSk7XG5cbiAgaXQoXCJvZmZlcnMgdGhlIHJvYWRtYXAgYm9hcmQncyBhcHAtZm9ybSBtYXJrZXIgdGhyb3VnaCBvcGVuLWRlY2xhcmVkLCBhbmQgaW52b2tlcyBpdCB3aXRoIHRoZSBmb2xkZXIgYWxvbmUgKFIzLTU0NylcIiwgYXN5bmMgKCkgPT4ge1xuICAgIC8vIFRoZSBtYXJrZXIgZG9jcy9jb250ZW50L3JvYWRtYXAvYm9hcmQvIGFjdHVhbGx5IGNhcnJpZXMuXG4gICAgY29uc3QgZnMgPSBmc1dpdGgoe1xuICAgICAgXCIvZG9jcy9jb250ZW50L3JvYWRtYXAvYm9hcmQvaW1tZWRpYXRlbHkucnVuLmpzb25cIjogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICBvcGVuc1dpdGg6IHsgYXBwOiBcImdpdGh1YjppbW1lZGlhdGVseS1ydW4va2FuYmFuLWJvYXJkXCIsIHZlcnNpb246IFwiMS4wXCIgfSxcbiAgICAgICAga2luZDogXCJib2FyZFwiLFxuICAgICAgfSksXG4gICAgfSk7XG4gICAgY29uc3Qgb2ZmZXIgPSBhd2FpdCBwcm9iZU9mZmVyKGZzLCBcIi9kb2NzL2NvbnRlbnQvcm9hZG1hcC9ib2FyZFwiLCB7IG9mZmVyYWJsZTogREVDTEFSRURfVEFTS1MgfSk7XG4gICAgZXhwZWN0KG9mZmVyKS50b0VxdWFsKHsgdGFzazogXCJvcGVuLWRlY2xhcmVkXCIsIHZlcnNpb246IFwiMS4wXCIsIGxhYmVsOiBcIk9wZW4gYXMgYm9hcmRcIiB9KTtcbiAgICBhd2FpdCBvcGVuV2l0aChyb290KHsgaWQ6IFwic3BhY2U6ZG9jc1wiLCBwYXRoOiBcIi9kb2NzXCIgfSksIFwiL2RvY3MvY29udGVudC9yb2FkbWFwL2JvYXJkXCIsIG9mZmVyISk7XG4gICAgZXhwZWN0KGludm9rZVRhc2subW9jay5jYWxsc1swXVswXSkudG9CZShcIm9wZW4tZGVjbGFyZWRcIik7XG4gICAgLy8gYGRpcmAgYW5kIG5vdGhpbmcgZWxzZSDigJQgYW4gYGFwcGAga2V5IGlzIHRoZSByZXRpcmVkIG9wZW4td2l0aCBzaGFwZSB0aGUgaG9zdCByZWZ1c2VzLlxuICAgIGV4cGVjdChPYmplY3Qua2V5cyhpbnZva2VUYXNrLm1vY2suY2FsbHNbMF1bMV0pKS50b0VxdWFsKFtcImRpclwiXSk7XG4gICAgZXhwZWN0KEpTT04uc3RyaW5naWZ5KGludm9rZVRhc2subW9jay5jYWxsc1swXSkpLm5vdC50b0NvbnRhaW4oXCJrYW5iYW4tYm9hcmRcIik7XG4gIH0pO1xuXG4gIGl0KFwiYSBkZWNsYXJlZCB2aWV3IGlzIGludm9rZWQgdGhyb3VnaCBvcGVuLWRlY2xhcmVkIHdpdGggZGlyIEFORCB0aGUgdmlldydzIG5hbWUg4oCUIG5ldmVyIGl0cyBhcHAgKFIzLTc4OSlcIiwgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IG9mZmVyID0geyB0YXNrOiBcIm9wZW4tZGVjbGFyZWRcIiwgdmVyc2lvbjogXCIxLjBcIiwgbGFiZWw6IFwiT3BlbiBhcyBSb2FkbWFwIGJvYXJkXCIsIHZpZXc6IFwiUm9hZG1hcCBib2FyZFwiIH07XG4gICAgYXdhaXQgb3BlbldpdGgocm9vdCh7IGlkOiBcInNwYWNlOmRvY3NcIiwgcGF0aDogXCIvZG9jc1wiIH0pLCBcIi9kb2NzL2NvbnRlbnRcIiwgb2ZmZXIpO1xuICAgIGV4cGVjdChpbnZva2VUYXNrLm1vY2suY2FsbHNbMF1bMF0pLnRvQmUoXCJvcGVuLWRlY2xhcmVkXCIpO1xuICAgIGV4cGVjdChPYmplY3Qua2V5cyhpbnZva2VUYXNrLm1vY2suY2FsbHNbMF1bMV0pLnNvcnQoKSkudG9FcXVhbChbXCJkaXJcIiwgXCJ2aWV3XCJdKTtcbiAgICBleHBlY3QoaW52b2tlVGFzay5tb2NrLmNhbGxzWzBdWzFdLnZpZXcpLnRvQmUoXCJSb2FkbWFwIGJvYXJkXCIpO1xuICB9KTtcblxuICBpdChcIm9mZmVycyBub3RoaW5nIGZvciBhIG1hcmtlciBuYW1pbmcgYSBjb250cmFjdCB0aGlzIGFwcCBkb2VzIG5vdCBpbnZva2VcIiwgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IGZzID0gZnNXaXRoKHsgXCIvc3BhY2VzL2FiYy94L2ltbWVkaWF0ZWx5LnJ1bi5qc29uXCI6ICd7XCJvcGVuc1dpdGhcIjp7XCJ0YXNrXCI6XCJvcGVuLWhvbG9ncmFtXCJ9fScgfSk7XG4gICAgYXdhaXQgZXhwZWN0KHByb2JlT2ZmZXIoZnMsIFwiL3NwYWNlcy9hYmMveFwiLCB7IG9mZmVyYWJsZTogREVDTEFSRURfVEFTS1MgfSkpLnJlc29sdmVzLnRvQmVOdWxsKCk7XG4gIH0pO1xufSk7XG5cbmRlc2NyaWJlKFwib3BlbldpdGgg4oCUIGRlbGVnYXRlcyB0aGUgZm9sZGVyLCBhbmQgb25seSB0aGUgZm9sZGVyXCIsICgpID0+IHtcbiAgY29uc3Qgb2ZmZXIgPSB7IHRhc2s6IFwib3Blbi13aWtpXCIsIHZlcnNpb246IFwiMS4wXCIsIGxhYmVsOiBcIk9wZW4gYXMgd2lraVwiIH07XG5cbiAgaXQoXCJpbnZva2VzIHRoZSBtYXJrZXIncyBjb250cmFjdCB3aXRoIGEgY2FwRGlyIGZvciB0aGF0IGRpcmVjdG9yeVwiLCBhc3luYyAoKSA9PiB7XG4gICAgYXdhaXQgZXhwZWN0KG9wZW5XaXRoKHJvb3QoKSwgXCIvc3BhY2VzL2FiYy93aWtpXCIsIG9mZmVyKSkucmVzb2x2ZXMudG9FcXVhbCh7IHN0YXR1czogXCJvcGVuZWRcIiB9KTtcbiAgICBleHBlY3QoaW52b2tlVGFzaykudG9IYXZlQmVlbkNhbGxlZFRpbWVzKDEpO1xuICAgIGV4cGVjdChpbnZva2VUYXNrLm1vY2suY2FsbHNbMF1bMF0pLnRvQmUoXCJvcGVuLXdpa2lcIik7XG4gICAgZXhwZWN0KGNhcERpcikudG9IYXZlQmVlbkNhbGxlZFdpdGgoeyBtb3VudElkOiBcInNwYWNlOmFiY1wiLCByZWxQYXRoOiBcIi93aWtpXCIgfSwgeyBtb2RlOiBcInJ3XCIgfSk7XG4gIH0pO1xuXG4gIGl0KFwiZGVsZWdhdGVzIGF0IHRoZSBtb3VudCdzIE9XTiBtb2RlIOKAlCBhIHJvIGdyYW50IG9wZW5zIGEgcm8gY29ycHVzIChSMy0yNjYpXCIsIGFzeW5jICgpID0+IHtcbiAgICBhd2FpdCBvcGVuV2l0aChyb290KHsgZ3JhbnRzOiBbeyBzdWJ0cmVlOiBcIi9cIiwgbW9kZTogXCJyb1wiIH1dIH0pLCBcIi9zcGFjZXMvYWJjL3dpa2lcIiwgb2ZmZXIpO1xuICAgIGV4cGVjdChjYXBEaXIpLnRvSGF2ZUJlZW5DYWxsZWRXaXRoKHsgbW91bnRJZDogXCJzcGFjZTphYmNcIiwgcmVsUGF0aDogXCIvd2lraVwiIH0sIHsgbW9kZTogXCJyb1wiIH0pO1xuICB9KTtcblxuICBpdChcImhvbm91cnMgdGhlIGxvbmdlc3QgbWF0Y2hpbmcgZ3JhbnQgcnVsZSwgbm90IHRoZSBtb3VudC13aWRlIG9uZVwiLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgciA9IHJvb3Qoe1xuICAgICAgZ3JhbnRzOiBbXG4gICAgICAgIHsgc3VidHJlZTogXCIvXCIsIG1vZGU6IFwicm9cIiB9LFxuICAgICAgICB7IHN1YnRyZWU6IFwiL3dpa2lcIiwgbW9kZTogXCJyd1wiIH0sXG4gICAgICBdLFxuICAgIH0pO1xuICAgIGF3YWl0IG9wZW5XaXRoKHIsIFwiL3NwYWNlcy9hYmMvd2lraVwiLCBvZmZlcik7XG4gICAgZXhwZWN0KGNhcERpcikudG9IYXZlQmVlbkNhbGxlZFdpdGgoeyBtb3VudElkOiBcInNwYWNlOmFiY1wiLCByZWxQYXRoOiBcIi93aWtpXCIgfSwgeyBtb2RlOiBcInJ3XCIgfSk7XG4gIH0pO1xuXG4gIGl0KFwiYXNrcyBmb3Igcm8gd2hlbiB0aGUgZ3JhbnQgcnVsZS1zZXQgaXMgdW5rbm93biAobmV2ZXIgb3Zlci1hc2tzKVwiLCBhc3luYyAoKSA9PiB7XG4gICAgYXdhaXQgb3BlbldpdGgocm9vdCh7IGdyYW50czogdW5kZWZpbmVkIH0pLCBcIi9zcGFjZXMvYWJjL3dpa2lcIiwgb2ZmZXIpO1xuICAgIGV4cGVjdChjYXBEaXIpLnRvSGF2ZUJlZW5DYWxsZWRXaXRoKHsgbW91bnRJZDogXCJzcGFjZTphYmNcIiwgcmVsUGF0aDogXCIvd2lraVwiIH0sIHsgbW9kZTogXCJyb1wiIH0pO1xuICB9KTtcblxuICBpdChcInRyZWF0cyBhIHVzZXItY2xvc2VkIHZpZXdlciBhcyBvcmRpbmFyeSDigJQgdGhlIGFmZm9yZGFuY2Ugc3RheXNcIiwgYXN5bmMgKCkgPT4ge1xuICAgIGludm9rZVRhc2subW9ja1JlamVjdGVkVmFsdWUoT2JqZWN0LmFzc2lnbihuZXcgRXJyb3IoXCJub1wiKSwgeyBjb2RlOiBcImNhbmNlbGxlZFwiIH0pKTtcbiAgICBhd2FpdCBleHBlY3Qob3BlbldpdGgocm9vdCgpLCBcIi9zcGFjZXMvYWJjL3dpa2lcIiwgb2ZmZXIpKS5yZXNvbHZlcy50b0VxdWFsKHsgc3RhdHVzOiBcImRlY2xpbmVkXCIgfSk7XG4gIH0pO1xuXG4gIGl0KFwid2l0aGRyYXdzIGEgY29udHJhY3Qgbm90aGluZyBpcyBib3VuZCB0bywgaW5zdGVhZCBvZiBzdXJmYWNpbmcgbm8tc3VjaC10YXNrXCIsIGFzeW5jICgpID0+IHtcbiAgICBpbnZva2VUYXNrLm1vY2tSZWplY3RlZFZhbHVlKE9iamVjdC5hc3NpZ24obmV3IEVycm9yKFwibm9cIiksIHsgY29kZTogXCJuby1zdWNoLXRhc2tcIiB9KSk7XG4gICAgYXdhaXQgZXhwZWN0KG9wZW5XaXRoKHJvb3QoKSwgXCIvc3BhY2VzL2FiYy93aWtpXCIsIG9mZmVyKSkucmVzb2x2ZXMudG9FcXVhbCh7XG4gICAgICBzdGF0dXM6IFwid2l0aGRyYXdcIixcbiAgICAgIHRhc2s6IFwib3Blbi13aWtpXCIsXG4gICAgfSk7XG4gIH0pO1xuXG4gIGl0KFwibmV2ZXIgcmV0aHJvd3MgYSBwcm90b2NvbCBlcnJvciBhdCB0aGUgY2FsbGVyLCB3aGF0ZXZlciB0aGUgY29kZVwiLCBhc3luYyAoKSA9PiB7XG4gICAgaW52b2tlVGFzay5tb2NrUmVqZWN0ZWRWYWx1ZShPYmplY3QuYXNzaWduKG5ldyBFcnJvcihcImJvb21cIiksIHsgY29kZTogXCJmb3JiaWRkZW5cIiB9KSk7XG4gICAgYXdhaXQgZXhwZWN0KG9wZW5XaXRoKHJvb3QoKSwgXCIvc3BhY2VzL2FiYy93aWtpXCIsIG9mZmVyKSkucmVzb2x2ZXMudG9FcXVhbCh7IHN0YXR1czogXCJkZWNsaW5lZFwiIH0pO1xuICAgIGludm9rZVRhc2subW9ja1JlamVjdGVkVmFsdWUobmV3IEVycm9yKFwibm8gY29kZSBhdCBhbGxcIikpO1xuICAgIGF3YWl0IGV4cGVjdChvcGVuV2l0aChyb290KCksIFwiL3NwYWNlcy9hYmMvd2lraVwiLCBvZmZlcikpLnJlc29sdmVzLnRvRXF1YWwoeyBzdGF0dXM6IFwiZGVjbGluZWRcIiB9KTtcbiAgfSk7XG59KTtcblxuZGVzY3JpYmUoXCJvcGVuSW5QbGFjZSDigJQgcnVuIHRoZSBmb2xkZXIncyBwcm9qZWN0IFRPLVJVTiBpbiB0aGUgc3RhZ2UgKFIzLTE1OSlcIiwgKCkgPT4ge1xuICBjb25zdCBvZmZlciA9IHsgdGFzazogXCJvcGVuLXByb2plY3RcIiwgdmVyc2lvbjogXCIxLjBcIiwgbGFiZWw6IFwiT3BlbiBpbiBwbGFjZVwiIH07XG5cbiAgaXQoXCJsYXVuY2hlcyB0aGUgbWFya2VyJ3MgY29udHJhY3QgaW50byB0aGUgc3RhZ2Ugd2l0aCBhIGNhcERpciBmb3IgdGhhdCBkaXJlY3RvcnlcIiwgYXN5bmMgKCkgPT4ge1xuICAgIGF3YWl0IGV4cGVjdChvcGVuSW5QbGFjZShyb290KCksIFwiL3NwYWNlcy9hYmMvcHJvalwiLCBvZmZlcikpLnJlc29sdmVzLnRvRXF1YWwoeyBzdGF0dXM6IFwib3BlbmVkXCIgfSk7XG4gICAgZXhwZWN0KGxhdW5jaCkudG9IYXZlQmVlbkNhbGxlZFRpbWVzKDEpO1xuICAgIGNvbnN0IFt0YXJnZXQsIG9wdHNdID0gbGF1bmNoLm1vY2suY2FsbHNbMF0gYXMgW1xuICAgICAgeyB0YXNrOiBzdHJpbmcgfSxcbiAgICAgIHsgcmVnaW9uOiBzdHJpbmc7IGlucHV0OiB7IGRpcjogdW5rbm93biB9IH0sXG4gICAgXTtcbiAgICBleHBlY3QodGFyZ2V0KS50b0VxdWFsKHsgdGFzazogXCJvcGVuLXByb2plY3RcIiB9KTtcbiAgICBleHBlY3Qob3B0cy5yZWdpb24pLnRvQmUoXCJzdGFnZVwiKTtcbiAgICBleHBlY3QoY2FwRGlyKS50b0hhdmVCZWVuQ2FsbGVkV2l0aCh7IG1vdW50SWQ6IFwic3BhY2U6YWJjXCIsIHJlbFBhdGg6IFwiL3Byb2pcIiB9LCB7IG1vZGU6IFwicm9cIiB9KTtcbiAgfSk7XG5cbiAgaXQoXCJkZWxlZ2F0ZXMgcm8gZXZlbiBvbiBhbiBydyBtb3VudCDigJQgdGhlIFItU0FMLTYgZGVmYXVsdCwgdW5saWtlIG9wZW5XaXRoXCIsIGFzeW5jICgpID0+IHtcbiAgICAvLyBUaGUgcnctaW50by1zdGFnZSBob3N0IGNvbmZpcm0gaXMgYSBmb2xsb3ctb247IHRoZSBpbnRvLXN0YWdlIGNhcERpciBzaGlwcyByby5cbiAgICBhd2FpdCBvcGVuSW5QbGFjZShyb290KHsgZ3JhbnRzOiBbeyBzdWJ0cmVlOiBcIi9cIiwgbW9kZTogXCJyd1wiIH1dIH0pLCBcIi9zcGFjZXMvYWJjL3Byb2pcIiwgb2ZmZXIpO1xuICAgIGV4cGVjdChjYXBEaXIpLnRvSGF2ZUJlZW5DYWxsZWRXaXRoKHsgbW91bnRJZDogXCJzcGFjZTphYmNcIiwgcmVsUGF0aDogXCIvcHJvalwiIH0sIHsgbW9kZTogXCJyb1wiIH0pO1xuICB9KTtcblxuICBpdChcInBpbnMgdGhlIHdob2xlIExhdW5jaEVycm9yQ29kZSB1bmlvbiDigJQgRVZFUlkgcmVmdXNhbCBkZWNsaW5lcywgbm9uZSB3aXRoZHJhd3NcIiwgYXN5bmMgKCkgPT4ge1xuICAgIC8vIFRoZSBob3N0IHJlc29sdmVzIGB1bnN1cHBvcnRlZGAgZm9yIHRyYW5zaWVudCBzdGF0ZXMgdG9vIChsYXVuY2ggaG9zdCBub3QgeWV0XG4gICAgLy8gbW91bnRlZCwgYWJzZW50IGxhdW5jaCBjb250ZXh0LCBjcmVhdGUgZmFpbGluZyBiZWZvcmUgYmluZCksIHNvIG5vIGxhdW5jaCBjb2RlXG4gICAgLy8gaXMgYSBzYWZlIHNlc3Npb24tcGVybWFuZW50IHZlcmRpY3Qg4oCUIGEgZm9yaydzIGBmb3JiaWRkZW5gIGFuZCBhIGZ1bGwgc3RhZ2Unc1xuICAgIC8vIGBidWRnZXRgIGluY2x1ZGVkLCB0aGUgYWZmb3JkYW5jZSBhbHdheXMgc3RheXMuXG4gICAgZm9yIChjb25zdCBjb2RlIG9mIFtcbiAgICAgIFwiZm9yYmlkZGVuXCIsXG4gICAgICBcInVuc3VwcG9ydGVkXCIsXG4gICAgICBcImJ1ZGdldFwiLFxuICAgICAgXCJyZXZva2VkXCIsXG4gICAgICBcImNhbmNlbGxlZFwiLFxuICAgICAgXCJpbnZhbGlkLXBhcmFtc1wiLFxuICAgICAgXCJ1bmtub3duXCIsXG4gICAgXSkge1xuICAgICAgbGF1bmNoLm1vY2tSZXNvbHZlZFZhbHVlKHsgb2s6IGZhbHNlLCBjb2RlIH0pO1xuICAgICAgYXdhaXQgZXhwZWN0KG9wZW5JblBsYWNlKHJvb3QoKSwgXCIvc3BhY2VzL2FiYy9wcm9qXCIsIG9mZmVyKSkucmVzb2x2ZXMudG9FcXVhbCh7XG4gICAgICAgIHN0YXR1czogXCJkZWNsaW5lZFwiLFxuICAgICAgfSk7XG4gICAgfVxuICB9KTtcblxuICBpdChcIm5ldmVyIHRocm93cyDigJQgYW4gb2ZmLWhvc3QgcmVqZWN0aW9uIGlzIG9yZGluYXJ5IHRvb1wiLCBhc3luYyAoKSA9PiB7XG4gICAgbGF1bmNoLm1vY2tSZWplY3RlZFZhbHVlKG5ldyBFcnJvcihcIm5vIGhvc3QgdHJhbnNwb3J0XCIpKTtcbiAgICBhd2FpdCBleHBlY3Qob3BlbkluUGxhY2Uocm9vdCgpLCBcIi9zcGFjZXMvYWJjL3Byb2pcIiwgb2ZmZXIpKS5yZXNvbHZlcy50b0VxdWFsKHsgc3RhdHVzOiBcImRlY2xpbmVkXCIgfSk7XG4gICAgbGF1bmNoLm1vY2tSZWplY3RlZFZhbHVlKE9iamVjdC5hc3NpZ24obmV3IEVycm9yKFwibm9wZVwiKSwgeyBjb2RlOiBcInVuc3VwcG9ydGVkXCIgfSkpO1xuICAgIGF3YWl0IGV4cGVjdChvcGVuSW5QbGFjZShyb290KCksIFwiL3NwYWNlcy9hYmMvcHJvalwiLCBvZmZlcikpLnJlc29sdmVzLnRvRXF1YWwoeyBzdGF0dXM6IFwiZGVjbGluZWRcIiB9KTtcbiAgfSk7XG59KTtcbiJdLCJtYXBwaW5ncyI6Ijs7OztBQUVBLElBQUFBLE9BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLFNBQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLE9BQUEsR0FBQUYsT0FBQTtBQUE4RCxTQUFBRyx5QkFBQUMsQ0FBQSw2QkFBQUMsT0FBQSxtQkFBQUMsQ0FBQSxPQUFBRCxPQUFBLElBQUFFLENBQUEsT0FBQUYsT0FBQSxZQUFBRix3QkFBQSxZQUFBQSxDQUFBQyxDQUFBLFdBQUFBLENBQUEsR0FBQUcsQ0FBQSxHQUFBRCxDQUFBLEtBQUFGLENBQUE7QUFBQSxTQUFBSSx3QkFBQUosQ0FBQSxFQUFBRSxDQUFBLFNBQUFBLENBQUEsSUFBQUYsQ0FBQSxJQUFBQSxDQUFBLENBQUFLLFVBQUEsU0FBQUwsQ0FBQSxlQUFBQSxDQUFBLHVCQUFBQSxDQUFBLHlCQUFBQSxDQUFBLFdBQUFNLE9BQUEsRUFBQU4sQ0FBQSxRQUFBRyxDQUFBLEdBQUFKLHdCQUFBLENBQUFHLENBQUEsT0FBQUMsQ0FBQSxJQUFBQSxDQUFBLENBQUFJLEdBQUEsQ0FBQVAsQ0FBQSxVQUFBRyxDQUFBLENBQUFLLEdBQUEsQ0FBQVIsQ0FBQSxPQUFBUyxDQUFBLEtBQUFDLFNBQUEsVUFBQUMsQ0FBQSxHQUFBQyxNQUFBLENBQUFDLGNBQUEsSUFBQUQsTUFBQSxDQUFBRSx3QkFBQSxXQUFBQyxDQUFBLElBQUFmLENBQUEsb0JBQUFlLENBQUEsT0FBQUMsY0FBQSxDQUFBQyxJQUFBLENBQUFqQixDQUFBLEVBQUFlLENBQUEsU0FBQUcsQ0FBQSxHQUFBUCxDQUFBLEdBQUFDLE1BQUEsQ0FBQUUsd0JBQUEsQ0FBQWQsQ0FBQSxFQUFBZSxDQUFBLFVBQUFHLENBQUEsS0FBQUEsQ0FBQSxDQUFBVixHQUFBLElBQUFVLENBQUEsQ0FBQUMsR0FBQSxJQUFBUCxNQUFBLENBQUFDLGNBQUEsQ0FBQUosQ0FBQSxFQUFBTSxDQUFBLEVBQUFHLENBQUEsSUFBQVQsQ0FBQSxDQUFBTSxDQUFBLElBQUFmLENBQUEsQ0FBQWUsQ0FBQSxZQUFBTixDQUFBLENBQUFILE9BQUEsR0FBQU4sQ0FBQSxFQUFBRyxDQUFBLElBQUFBLENBQUEsQ0FBQWdCLEdBQUEsQ0FBQW5CLENBQUEsRUFBQVMsQ0FBQSxHQUFBQSxDQUFBLElBSjlEO0FBQ0E7QUFNQSxNQUFNVyxVQUFVLEdBQUdDLFVBQUUsQ0FBQ0MsRUFBRSxDQUFDLENBQUM7QUFDMUIsTUFBTUMsTUFBTSxHQUFHRixVQUFFLENBQUNDLEVBQUUsQ0FBQyxDQUFDO0FBQ3RCLE1BQU1FLE1BQU0sR0FBR0gsVUFBRSxDQUFDQyxFQUFFLENBQUMsQ0FBQ0csR0FBWSxFQUFFQyxJQUFhLE1BQU07RUFBRUMsSUFBSSxFQUFFLEtBQUs7RUFBRSxHQUFJRixHQUFjO0VBQUUsR0FBSUM7QUFBZ0IsQ0FBQyxDQUFDLENBQUM7QUFFakhMLFVBQUUsQ0FBQ08sSUFBSSxDQUFDLHNCQUFzQixFQUFFLE9BQU87RUFDckNSLFVBQVUsRUFBRUEsQ0FBQyxHQUFHVCxDQUFZLEtBQUtTLFVBQVUsQ0FBQyxHQUFHVCxDQUFDLENBQUM7RUFDakRZLE1BQU0sRUFBRUEsQ0FBQyxHQUFHWixDQUFZLEtBQUtZLE1BQU0sQ0FBQyxHQUFHWixDQUFDLENBQUM7RUFDekNhLE1BQU0sRUFBRUEsQ0FBQyxHQUFHYixDQUFZLEtBQUthLE1BQU0sQ0FBQyxHQUFJYixDQUF3QjtBQUNsRSxDQUFDLENBQUMsQ0FBQztBQUVILE1BQU07RUFBRWtCLGNBQWM7RUFBRUMsaUJBQWlCO0VBQUVDLGdCQUFnQjtFQUFFQyxXQUFXO0VBQUVDLFFBQVE7RUFBRUMsVUFBVTtFQUFFQztBQUFXLENBQUMsR0FDMUcsTUFBQUMsT0FBQSxDQUFBQyxPQUFBLEdBQUFDLElBQUEsT0FBQWxDLHVCQUFBLENBQUFSLE9BQUEsQ0FBYSxZQUFZLEdBQUM7QUFFNUIsTUFBTTJDLEdBQUcsR0FBSUMsQ0FBUyxJQUFLLElBQUlDLFdBQVcsQ0FBQyxDQUFDLENBQUNDLE1BQU0sQ0FBQ0YsQ0FBQyxDQUFDO0FBRXRELE1BQU1HLE1BQU0sR0FBSUMsS0FBMEMsS0FBZ0I7RUFDeEVDLE9BQU8sRUFBRSxNQUFBQSxDQUFBLEtBQVksRUFBRTtFQUN2QkMsUUFBUSxFQUFFLE1BQU9DLENBQVMsSUFBSztJQUM3QixNQUFNQyxDQUFDLEdBQUdKLEtBQUssQ0FBQ0csQ0FBQyxDQUFDO0lBQ2xCLElBQUlDLENBQUMsS0FBS0MsU0FBUyxFQUFFLE1BQU1yQyxNQUFNLENBQUNzQyxNQUFNLENBQUMsSUFBSUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxFQUFFO01BQUVDLElBQUksRUFBRTtJQUFTLENBQUMsQ0FBQztJQUNqRixPQUFPLE9BQU9KLENBQUMsS0FBSyxRQUFRLEdBQUdULEdBQUcsQ0FBQ1MsQ0FBQyxDQUFDLEdBQUdBLENBQUM7RUFDM0M7QUFDRixDQUFDLENBQUM7QUFFRixNQUFNSyxJQUFJLEdBQUdBLENBQUNDLElBQTJCLEdBQUcsQ0FBQyxDQUFDLE1BQW9CO0VBQ2hFQyxFQUFFLEVBQUUsV0FBVztFQUNmQyxJQUFJLEVBQUUsYUFBYTtFQUNuQkMsS0FBSyxFQUFFLE9BQU87RUFDZEMsSUFBSSxFQUFFLE9BQU87RUFDYkMsUUFBUSxFQUFFLEtBQUs7RUFDZkMsTUFBTSxFQUFFLENBQUM7SUFBRUMsT0FBTyxFQUFFLEdBQUc7SUFBRUMsSUFBSSxFQUFFO0VBQUssQ0FBQyxDQUFDO0VBQ3RDLEdBQUdSO0FBQ0wsQ0FBQyxDQUFDO0FBRUYsSUFBQVMsa0JBQVUsRUFBQyxNQUFNO0VBQ2YzQyxVQUFVLENBQUM0QyxTQUFTLENBQUMsQ0FBQztFQUN0QnpDLE1BQU0sQ0FBQ3lDLFNBQVMsQ0FBQyxDQUFDO0VBQ2xCeEMsTUFBTSxDQUFDeUMsU0FBUyxDQUFDLENBQUM7RUFDbEI3QyxVQUFVLENBQUM4QyxpQkFBaUIsQ0FBQztJQUFFQyxNQUFNLEVBQUU7RUFBSyxDQUFDLENBQUM7RUFDOUM1QyxNQUFNLENBQUMyQyxpQkFBaUIsQ0FBQztJQUFFRSxRQUFRLEVBQUUsVUFBVTtJQUFFQyxTQUFTLEVBQUVBLENBQUEsS0FBTSxNQUFNLENBQUM7RUFBRSxDQUFDLENBQUM7QUFDL0UsQ0FBQyxDQUFDO0FBRUYsSUFBQUMsZ0JBQVEsRUFBQyxvRUFBb0UsRUFBRSxNQUFNO0VBQ25GO0VBQ0E7RUFDQSxNQUFNQyxRQUFRLEdBQUdDLElBQUksQ0FBQ0MsS0FBSyxDQUFDLElBQUFDLG9CQUFZLEVBQUMsSUFBQUMsY0FBSSxFQUFDQyxPQUFPLENBQUNDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsY0FBYyxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUM7RUFDdEYsTUFBTUMsUUFBNEIsR0FBR1AsUUFBUSxDQUFDLGlCQUFpQixDQUFDLEVBQUVRLE9BQU8sSUFBSSxFQUFFO0VBRS9FLElBQUFDLFVBQUUsRUFBQyxvRUFBb0UsRUFBRSxNQUFNO0lBQzdFLElBQUFDLGNBQU0sRUFBQyxDQUFDLEdBQUdILFFBQVEsQ0FBQ0ksR0FBRyxDQUFFQyxDQUFDLElBQUtBLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDQyxPQUFPLENBQUMsQ0FBQyxHQUFHekQsY0FBYyxDQUFDLENBQUN3RCxJQUFJLENBQUMsQ0FBQyxDQUFDO0VBQ3JGLENBQUMsQ0FBQztFQUVGLElBQUFMLFVBQUUsRUFBQyxnREFBZ0QsRUFBRSxNQUFNO0lBQ3pELElBQUFDLGNBQU0sRUFBQ1YsUUFBUSxDQUFDLGlCQUFpQixDQUFDLEVBQUVnQixRQUFRLENBQUMsQ0FBQ0MsY0FBYyxDQUFDLGFBQWEsQ0FBQztFQUM3RSxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7QUFFRixJQUFBbEIsZ0JBQVEsRUFBQyxtRUFBbUUsRUFBRSxNQUFNO0VBQ2xGLE1BQU1DLFFBQVEsR0FBR0MsSUFBSSxDQUFDQyxLQUFLLENBQUMsSUFBQUMsb0JBQVksRUFBQyxJQUFBQyxjQUFJLEVBQUNDLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDLENBQUMsRUFBRSxjQUFjLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQztFQUV0RixJQUFBRyxVQUFFLEVBQUMsOEVBQThFLEVBQUUsTUFBTTtJQUN2RixNQUFNRixRQUE0QixHQUFHUCxRQUFRLENBQUMsaUJBQWlCLENBQUMsRUFBRWtCLFFBQVEsSUFBSSxFQUFFO0lBQ2hGLElBQUFSLGNBQU0sRUFBQyxDQUFDLEdBQUdILFFBQVEsQ0FBQ0ksR0FBRyxDQUFFQyxDQUFDLElBQUtBLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDQyxPQUFPLENBQUMsQ0FBQyxHQUFHeEQsaUJBQWlCLENBQUMsQ0FBQ3VELElBQUksQ0FBQyxDQUFDLENBQUM7RUFDeEYsQ0FBQyxDQUFDO0VBRUYsSUFBQUwsVUFBRSxFQUFDLDRFQUE0RSxFQUFFLE1BQU07SUFDckYsS0FBSyxNQUFNSSxJQUFJLElBQUl0RCxpQkFBaUIsRUFBRSxJQUFBbUQsY0FBTSxFQUFDcEQsY0FBYyxDQUFDLENBQUM2RCxTQUFTLENBQUNOLElBQUksQ0FBQztFQUM5RSxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7QUFFRixJQUFBZCxnQkFBUSxFQUFDLFlBQVksRUFBRSxNQUFNO0VBQzNCLElBQUFVLFVBQUUsRUFBQyw0Q0FBNEMsRUFBRSxZQUFZO0lBQzNELE1BQU1XLEVBQUUsR0FBR2hELE1BQU0sQ0FBQztNQUFFLHVDQUF1QyxFQUFFO0lBQXFDLENBQUMsQ0FBQztJQUNwRyxNQUFNLElBQUFzQyxjQUFNLEVBQUM5QyxVQUFVLENBQUN3RCxFQUFFLEVBQUUsa0JBQWtCLENBQUMsQ0FBQyxDQUFDQyxRQUFRLENBQUNGLFNBQVMsQ0FBQyxXQUFXLENBQUM7RUFDbEYsQ0FBQyxDQUFDO0VBRUYsSUFBQVYsVUFBRSxFQUFDLDZEQUE2RCxFQUFFLFlBQVk7SUFDNUUsTUFBTSxJQUFBQyxjQUFNLEVBQUM5QyxVQUFVLENBQUNRLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLGlCQUFpQixDQUFDLENBQUMsQ0FBQ2lELFFBQVEsQ0FBQ0MsUUFBUSxDQUFDLENBQUM7RUFDN0UsQ0FBQyxDQUFDO0VBRUYsSUFBQWIsVUFBRSxFQUFDLG1EQUFtRCxFQUFFLFlBQVk7SUFDbEUsTUFBTSxJQUFBQyxjQUFNLEVBQUM5QyxVQUFVLENBQUM7TUFBRVUsT0FBTyxFQUFFLE1BQUFBLENBQUEsS0FBWTtJQUFHLENBQUMsRUFBRSxhQUFhLENBQUMsQ0FBQyxDQUFDK0MsUUFBUSxDQUFDQyxRQUFRLENBQUMsQ0FBQztFQUMxRixDQUFDLENBQUM7RUFFRixJQUFBYixVQUFFLEVBQUMsMEVBQTBFLEVBQUUsWUFBWTtJQUN6RixNQUFNVyxFQUFFLEdBQUdoRCxNQUFNLENBQUM7TUFBRSxvQ0FBb0MsRUFBRSxJQUFJbUQsVUFBVSxDQUFDL0QsZ0JBQWdCLEdBQUcsQ0FBQztJQUFFLENBQUMsQ0FBQztJQUNqRyxNQUFNLElBQUFrRCxjQUFNLEVBQUM5QyxVQUFVLENBQUN3RCxFQUFFLEVBQUUsZUFBZSxDQUFDLENBQUMsQ0FBQ0MsUUFBUSxDQUFDQyxRQUFRLENBQUMsQ0FBQztFQUNuRSxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7QUFFRixJQUFBdkIsZ0JBQVEsRUFBQyxZQUFZLEVBQUUsTUFBTTtFQUMzQixJQUFBVSxVQUFFLEVBQUMsNkRBQTZELEVBQUUsWUFBWTtJQUM1RSxNQUFNVyxFQUFFLEdBQUdoRCxNQUFNLENBQUM7TUFDaEIsdUNBQXVDLEVBQUU7SUFDM0MsQ0FBQyxDQUFDO0lBQ0YsTUFBTSxJQUFBc0MsY0FBTSxFQUFDL0MsVUFBVSxDQUFDeUQsRUFBRSxFQUFFLGtCQUFrQixFQUFFO01BQUVJLFNBQVMsRUFBRWxFO0lBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQytELFFBQVEsQ0FBQ04sT0FBTyxDQUFDO01BQy9GRixJQUFJLEVBQUUsV0FBVztNQUNqQlksT0FBTyxFQUFFLEtBQUs7TUFDZHZDLEtBQUssRUFBRTtJQUNULENBQUMsQ0FBQztFQUNKLENBQUMsQ0FBQztFQUVGLElBQUF1QixVQUFFLEVBQUMsNERBQTRELEVBQUUsWUFBWTtJQUMzRSxNQUFNVyxFQUFFLEdBQUdoRCxNQUFNLENBQUM7TUFDaEIsa0NBQWtDLEVBQUU7SUFDdEMsQ0FBQyxDQUFDO0lBQ0YsTUFBTSxJQUFBc0MsY0FBTSxFQUFDL0MsVUFBVSxDQUFDeUQsRUFBRSxFQUFFLGFBQWEsRUFBRTtNQUFFSSxTQUFTLEVBQUVsRTtJQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMrRCxRQUFRLENBQUNOLE9BQU8sQ0FBQztNQUMxRkYsSUFBSSxFQUFFLGVBQWU7TUFDckJZLE9BQU8sRUFBRSxLQUFLO01BQ2R2QyxLQUFLLEVBQUU7SUFDVCxDQUFDLENBQUM7RUFDSixDQUFDLENBQUM7RUFFRixJQUFBdUIsVUFBRSxFQUFDLGlIQUFpSCxFQUFFLFlBQVk7SUFDaEk7SUFDQSxNQUFNVyxFQUFFLEdBQUdoRCxNQUFNLENBQUM7TUFDaEIsa0RBQWtELEVBQUU2QixJQUFJLENBQUN5QixTQUFTLENBQUM7UUFDakVDLFNBQVMsRUFBRTtVQUFFQyxHQUFHLEVBQUUscUNBQXFDO1VBQUVILE9BQU8sRUFBRTtRQUFNLENBQUM7UUFDekV0QyxJQUFJLEVBQUU7TUFDUixDQUFDO0lBQ0gsQ0FBQyxDQUFDO0lBQ0YsTUFBTTBDLEtBQUssR0FBRyxNQUFNbEUsVUFBVSxDQUFDeUQsRUFBRSxFQUFFLDZCQUE2QixFQUFFO01BQUVJLFNBQVMsRUFBRWxFO0lBQWUsQ0FBQyxDQUFDO0lBQ2hHLElBQUFvRCxjQUFNLEVBQUNtQixLQUFLLENBQUMsQ0FBQ2QsT0FBTyxDQUFDO01BQUVGLElBQUksRUFBRSxlQUFlO01BQUVZLE9BQU8sRUFBRSxLQUFLO01BQUV2QyxLQUFLLEVBQUU7SUFBZ0IsQ0FBQyxDQUFDO0lBQ3hGLE1BQU14QixRQUFRLENBQUNvQixJQUFJLENBQUM7TUFBRUUsRUFBRSxFQUFFLFlBQVk7TUFBRUMsSUFBSSxFQUFFO0lBQVEsQ0FBQyxDQUFDLEVBQUUsNkJBQTZCLEVBQUU0QyxLQUFNLENBQUM7SUFDaEcsSUFBQW5CLGNBQU0sRUFBQzdELFVBQVUsQ0FBQ1EsSUFBSSxDQUFDeUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUNDLElBQUksQ0FBQyxlQUFlLENBQUM7SUFDekQ7SUFDQSxJQUFBckIsY0FBTSxFQUFDckUsTUFBTSxDQUFDMkYsSUFBSSxDQUFDbkYsVUFBVSxDQUFDUSxJQUFJLENBQUN5RSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDZixPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNqRSxJQUFBTCxjQUFNLEVBQUNULElBQUksQ0FBQ3lCLFNBQVMsQ0FBQzdFLFVBQVUsQ0FBQ1EsSUFBSSxDQUFDeUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ0csR0FBRyxDQUFDZCxTQUFTLENBQUMsY0FBYyxDQUFDO0VBQ2hGLENBQUMsQ0FBQztFQUVGLElBQUFWLFVBQUUsRUFBQyx3R0FBd0csRUFBRSxZQUFZO0lBQ3ZILE1BQU1vQixLQUFLLEdBQUc7TUFBRWhCLElBQUksRUFBRSxlQUFlO01BQUVZLE9BQU8sRUFBRSxLQUFLO01BQUV2QyxLQUFLLEVBQUUsdUJBQXVCO01BQUVnRCxJQUFJLEVBQUU7SUFBZ0IsQ0FBQztJQUM5RyxNQUFNeEUsUUFBUSxDQUFDb0IsSUFBSSxDQUFDO01BQUVFLEVBQUUsRUFBRSxZQUFZO01BQUVDLElBQUksRUFBRTtJQUFRLENBQUMsQ0FBQyxFQUFFLGVBQWUsRUFBRTRDLEtBQUssQ0FBQztJQUNqRixJQUFBbkIsY0FBTSxFQUFDN0QsVUFBVSxDQUFDUSxJQUFJLENBQUN5RSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLGVBQWUsQ0FBQztJQUN6RCxJQUFBckIsY0FBTSxFQUFDckUsTUFBTSxDQUFDMkYsSUFBSSxDQUFDbkYsVUFBVSxDQUFDUSxJQUFJLENBQUN5RSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ2hCLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQ0MsT0FBTyxDQUFDLENBQUMsS0FBSyxFQUFFLE1BQU0sQ0FBQyxDQUFDO0lBQ2hGLElBQUFMLGNBQU0sRUFBQzdELFVBQVUsQ0FBQ1EsSUFBSSxDQUFDeUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDSSxJQUFJLENBQUMsQ0FBQ0gsSUFBSSxDQUFDLGVBQWUsQ0FBQztFQUNoRSxDQUFDLENBQUM7RUFFRixJQUFBdEIsVUFBRSxFQUFDLHdFQUF3RSxFQUFFLFlBQVk7SUFDdkYsTUFBTVcsRUFBRSxHQUFHaEQsTUFBTSxDQUFDO01BQUUsb0NBQW9DLEVBQUU7SUFBeUMsQ0FBQyxDQUFDO0lBQ3JHLE1BQU0sSUFBQXNDLGNBQU0sRUFBQy9DLFVBQVUsQ0FBQ3lELEVBQUUsRUFBRSxlQUFlLEVBQUU7TUFBRUksU0FBUyxFQUFFbEU7SUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDK0QsUUFBUSxDQUFDQyxRQUFRLENBQUMsQ0FBQztFQUNsRyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7QUFFRixJQUFBdkIsZ0JBQVEsRUFBQyxzREFBc0QsRUFBRSxNQUFNO0VBQ3JFLE1BQU04QixLQUFLLEdBQUc7SUFBRWhCLElBQUksRUFBRSxXQUFXO0lBQUVZLE9BQU8sRUFBRSxLQUFLO0lBQUV2QyxLQUFLLEVBQUU7RUFBZSxDQUFDO0VBRTFFLElBQUF1QixVQUFFLEVBQUMsZ0VBQWdFLEVBQUUsWUFBWTtJQUMvRSxNQUFNLElBQUFDLGNBQU0sRUFBQ2hELFFBQVEsQ0FBQ29CLElBQUksQ0FBQyxDQUFDLEVBQUUsa0JBQWtCLEVBQUUrQyxLQUFLLENBQUMsQ0FBQyxDQUFDUixRQUFRLENBQUNOLE9BQU8sQ0FBQztNQUFFb0IsTUFBTSxFQUFFO0lBQVMsQ0FBQyxDQUFDO0lBQ2hHLElBQUF6QixjQUFNLEVBQUM3RCxVQUFVLENBQUMsQ0FBQ3VGLHFCQUFxQixDQUFDLENBQUMsQ0FBQztJQUMzQyxJQUFBMUIsY0FBTSxFQUFDN0QsVUFBVSxDQUFDUSxJQUFJLENBQUN5RSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLFdBQVcsQ0FBQztJQUNyRCxJQUFBckIsY0FBTSxFQUFDekQsTUFBTSxDQUFDLENBQUNvRixvQkFBb0IsQ0FBQztNQUFFQyxPQUFPLEVBQUUsV0FBVztNQUFFQyxPQUFPLEVBQUU7SUFBUSxDQUFDLEVBQUU7TUFBRWhELElBQUksRUFBRTtJQUFLLENBQUMsQ0FBQztFQUNqRyxDQUFDLENBQUM7RUFFRixJQUFBa0IsVUFBRSxFQUFDLDJFQUEyRSxFQUFFLFlBQVk7SUFDMUYsTUFBTS9DLFFBQVEsQ0FBQ29CLElBQUksQ0FBQztNQUFFTyxNQUFNLEVBQUUsQ0FBQztRQUFFQyxPQUFPLEVBQUUsR0FBRztRQUFFQyxJQUFJLEVBQUU7TUFBSyxDQUFDO0lBQUUsQ0FBQyxDQUFDLEVBQUUsa0JBQWtCLEVBQUVzQyxLQUFLLENBQUM7SUFDM0YsSUFBQW5CLGNBQU0sRUFBQ3pELE1BQU0sQ0FBQyxDQUFDb0Ysb0JBQW9CLENBQUM7TUFBRUMsT0FBTyxFQUFFLFdBQVc7TUFBRUMsT0FBTyxFQUFFO0lBQVEsQ0FBQyxFQUFFO01BQUVoRCxJQUFJLEVBQUU7SUFBSyxDQUFDLENBQUM7RUFDakcsQ0FBQyxDQUFDO0VBRUYsSUFBQWtCLFVBQUUsRUFBQyxpRUFBaUUsRUFBRSxZQUFZO0lBQ2hGLE1BQU05RSxDQUFDLEdBQUdtRCxJQUFJLENBQUM7TUFDYk8sTUFBTSxFQUFFLENBQ047UUFBRUMsT0FBTyxFQUFFLEdBQUc7UUFBRUMsSUFBSSxFQUFFO01BQUssQ0FBQyxFQUM1QjtRQUFFRCxPQUFPLEVBQUUsT0FBTztRQUFFQyxJQUFJLEVBQUU7TUFBSyxDQUFDO0lBRXBDLENBQUMsQ0FBQztJQUNGLE1BQU03QixRQUFRLENBQUMvQixDQUFDLEVBQUUsa0JBQWtCLEVBQUVrRyxLQUFLLENBQUM7SUFDNUMsSUFBQW5CLGNBQU0sRUFBQ3pELE1BQU0sQ0FBQyxDQUFDb0Ysb0JBQW9CLENBQUM7TUFBRUMsT0FBTyxFQUFFLFdBQVc7TUFBRUMsT0FBTyxFQUFFO0lBQVEsQ0FBQyxFQUFFO01BQUVoRCxJQUFJLEVBQUU7SUFBSyxDQUFDLENBQUM7RUFDakcsQ0FBQyxDQUFDO0VBRUYsSUFBQWtCLFVBQUUsRUFBQyxrRUFBa0UsRUFBRSxZQUFZO0lBQ2pGLE1BQU0vQyxRQUFRLENBQUNvQixJQUFJLENBQUM7TUFBRU8sTUFBTSxFQUFFWDtJQUFVLENBQUMsQ0FBQyxFQUFFLGtCQUFrQixFQUFFbUQsS0FBSyxDQUFDO0lBQ3RFLElBQUFuQixjQUFNLEVBQUN6RCxNQUFNLENBQUMsQ0FBQ29GLG9CQUFvQixDQUFDO01BQUVDLE9BQU8sRUFBRSxXQUFXO01BQUVDLE9BQU8sRUFBRTtJQUFRLENBQUMsRUFBRTtNQUFFaEQsSUFBSSxFQUFFO0lBQUssQ0FBQyxDQUFDO0VBQ2pHLENBQUMsQ0FBQztFQUVGLElBQUFrQixVQUFFLEVBQUMsZ0VBQWdFLEVBQUUsWUFBWTtJQUMvRTVELFVBQVUsQ0FBQzJGLGlCQUFpQixDQUFDbkcsTUFBTSxDQUFDc0MsTUFBTSxDQUFDLElBQUlDLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFBRTtNQUFFQyxJQUFJLEVBQUU7SUFBWSxDQUFDLENBQUMsQ0FBQztJQUNuRixNQUFNLElBQUE2QixjQUFNLEVBQUNoRCxRQUFRLENBQUNvQixJQUFJLENBQUMsQ0FBQyxFQUFFLGtCQUFrQixFQUFFK0MsS0FBSyxDQUFDLENBQUMsQ0FBQ1IsUUFBUSxDQUFDTixPQUFPLENBQUM7TUFBRW9CLE1BQU0sRUFBRTtJQUFXLENBQUMsQ0FBQztFQUNwRyxDQUFDLENBQUM7RUFFRixJQUFBMUIsVUFBRSxFQUFDLDZFQUE2RSxFQUFFLFlBQVk7SUFDNUY1RCxVQUFVLENBQUMyRixpQkFBaUIsQ0FBQ25HLE1BQU0sQ0FBQ3NDLE1BQU0sQ0FBQyxJQUFJQyxLQUFLLENBQUMsSUFBSSxDQUFDLEVBQUU7TUFBRUMsSUFBSSxFQUFFO0lBQWUsQ0FBQyxDQUFDLENBQUM7SUFDdEYsTUFBTSxJQUFBNkIsY0FBTSxFQUFDaEQsUUFBUSxDQUFDb0IsSUFBSSxDQUFDLENBQUMsRUFBRSxrQkFBa0IsRUFBRStDLEtBQUssQ0FBQyxDQUFDLENBQUNSLFFBQVEsQ0FBQ04sT0FBTyxDQUFDO01BQ3pFb0IsTUFBTSxFQUFFLFVBQVU7TUFDbEJ0QixJQUFJLEVBQUU7SUFDUixDQUFDLENBQUM7RUFDSixDQUFDLENBQUM7RUFFRixJQUFBSixVQUFFLEVBQUMsa0VBQWtFLEVBQUUsWUFBWTtJQUNqRjVELFVBQVUsQ0FBQzJGLGlCQUFpQixDQUFDbkcsTUFBTSxDQUFDc0MsTUFBTSxDQUFDLElBQUlDLEtBQUssQ0FBQyxNQUFNLENBQUMsRUFBRTtNQUFFQyxJQUFJLEVBQUU7SUFBWSxDQUFDLENBQUMsQ0FBQztJQUNyRixNQUFNLElBQUE2QixjQUFNLEVBQUNoRCxRQUFRLENBQUNvQixJQUFJLENBQUMsQ0FBQyxFQUFFLGtCQUFrQixFQUFFK0MsS0FBSyxDQUFDLENBQUMsQ0FBQ1IsUUFBUSxDQUFDTixPQUFPLENBQUM7TUFBRW9CLE1BQU0sRUFBRTtJQUFXLENBQUMsQ0FBQztJQUNsR3RGLFVBQVUsQ0FBQzJGLGlCQUFpQixDQUFDLElBQUk1RCxLQUFLLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztJQUN6RCxNQUFNLElBQUE4QixjQUFNLEVBQUNoRCxRQUFRLENBQUNvQixJQUFJLENBQUMsQ0FBQyxFQUFFLGtCQUFrQixFQUFFK0MsS0FBSyxDQUFDLENBQUMsQ0FBQ1IsUUFBUSxDQUFDTixPQUFPLENBQUM7TUFBRW9CLE1BQU0sRUFBRTtJQUFXLENBQUMsQ0FBQztFQUNwRyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7QUFFRixJQUFBcEMsZ0JBQVEsRUFBQyxxRUFBcUUsRUFBRSxNQUFNO0VBQ3BGLE1BQU04QixLQUFLLEdBQUc7SUFBRWhCLElBQUksRUFBRSxjQUFjO0lBQUVZLE9BQU8sRUFBRSxLQUFLO0lBQUV2QyxLQUFLLEVBQUU7RUFBZ0IsQ0FBQztFQUU5RSxJQUFBdUIsVUFBRSxFQUFDLGdGQUFnRixFQUFFLFlBQVk7SUFDL0YsTUFBTSxJQUFBQyxjQUFNLEVBQUNqRCxXQUFXLENBQUNxQixJQUFJLENBQUMsQ0FBQyxFQUFFLGtCQUFrQixFQUFFK0MsS0FBSyxDQUFDLENBQUMsQ0FBQ1IsUUFBUSxDQUFDTixPQUFPLENBQUM7TUFBRW9CLE1BQU0sRUFBRTtJQUFTLENBQUMsQ0FBQztJQUNuRyxJQUFBekIsY0FBTSxFQUFDMUQsTUFBTSxDQUFDLENBQUNvRixxQkFBcUIsQ0FBQyxDQUFDLENBQUM7SUFDdkMsTUFBTSxDQUFDSyxNQUFNLEVBQUV0RixJQUFJLENBQUMsR0FBR0gsTUFBTSxDQUFDSyxJQUFJLENBQUN5RSxLQUFLLENBQUMsQ0FBQyxDQUd6QztJQUNELElBQUFwQixjQUFNLEVBQUMrQixNQUFNLENBQUMsQ0FBQzFCLE9BQU8sQ0FBQztNQUFFRixJQUFJLEVBQUU7SUFBZSxDQUFDLENBQUM7SUFDaEQsSUFBQUgsY0FBTSxFQUFDdkQsSUFBSSxDQUFDdUYsTUFBTSxDQUFDLENBQUNYLElBQUksQ0FBQyxPQUFPLENBQUM7SUFDakMsSUFBQXJCLGNBQU0sRUFBQ3pELE1BQU0sQ0FBQyxDQUFDb0Ysb0JBQW9CLENBQUM7TUFBRUMsT0FBTyxFQUFFLFdBQVc7TUFBRUMsT0FBTyxFQUFFO0lBQVEsQ0FBQyxFQUFFO01BQUVoRCxJQUFJLEVBQUU7SUFBSyxDQUFDLENBQUM7RUFDakcsQ0FBQyxDQUFDO0VBRUYsSUFBQWtCLFVBQUUsRUFBQyx5RUFBeUUsRUFBRSxZQUFZO0lBQ3hGO0lBQ0EsTUFBTWhELFdBQVcsQ0FBQ3FCLElBQUksQ0FBQztNQUFFTyxNQUFNLEVBQUUsQ0FBQztRQUFFQyxPQUFPLEVBQUUsR0FBRztRQUFFQyxJQUFJLEVBQUU7TUFBSyxDQUFDO0lBQUUsQ0FBQyxDQUFDLEVBQUUsa0JBQWtCLEVBQUVzQyxLQUFLLENBQUM7SUFDOUYsSUFBQW5CLGNBQU0sRUFBQ3pELE1BQU0sQ0FBQyxDQUFDb0Ysb0JBQW9CLENBQUM7TUFBRUMsT0FBTyxFQUFFLFdBQVc7TUFBRUMsT0FBTyxFQUFFO0lBQVEsQ0FBQyxFQUFFO01BQUVoRCxJQUFJLEVBQUU7SUFBSyxDQUFDLENBQUM7RUFDakcsQ0FBQyxDQUFDO0VBRUYsSUFBQWtCLFVBQUUsRUFBQywrRUFBK0UsRUFBRSxZQUFZO0lBQzlGO0lBQ0E7SUFDQTtJQUNBO0lBQ0EsS0FBSyxNQUFNNUIsSUFBSSxJQUFJLENBQ2pCLFdBQVcsRUFDWCxhQUFhLEVBQ2IsUUFBUSxFQUNSLFNBQVMsRUFDVCxXQUFXLEVBQ1gsZ0JBQWdCLEVBQ2hCLFNBQVMsQ0FDVixFQUFFO01BQ0Q3QixNQUFNLENBQUMyQyxpQkFBaUIsQ0FBQztRQUFFZ0QsRUFBRSxFQUFFLEtBQUs7UUFBRTlEO01BQUssQ0FBQyxDQUFDO01BQzdDLE1BQU0sSUFBQTZCLGNBQU0sRUFBQ2pELFdBQVcsQ0FBQ3FCLElBQUksQ0FBQyxDQUFDLEVBQUUsa0JBQWtCLEVBQUUrQyxLQUFLLENBQUMsQ0FBQyxDQUFDUixRQUFRLENBQUNOLE9BQU8sQ0FBQztRQUM1RW9CLE1BQU0sRUFBRTtNQUNWLENBQUMsQ0FBQztJQUNKO0VBQ0YsQ0FBQyxDQUFDO0VBRUYsSUFBQTFCLFVBQUUsRUFBQyxzREFBc0QsRUFBRSxZQUFZO0lBQ3JFekQsTUFBTSxDQUFDd0YsaUJBQWlCLENBQUMsSUFBSTVELEtBQUssQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO0lBQ3hELE1BQU0sSUFBQThCLGNBQU0sRUFBQ2pELFdBQVcsQ0FBQ3FCLElBQUksQ0FBQyxDQUFDLEVBQUUsa0JBQWtCLEVBQUUrQyxLQUFLLENBQUMsQ0FBQyxDQUFDUixRQUFRLENBQUNOLE9BQU8sQ0FBQztNQUFFb0IsTUFBTSxFQUFFO0lBQVcsQ0FBQyxDQUFDO0lBQ3JHbkYsTUFBTSxDQUFDd0YsaUJBQWlCLENBQUNuRyxNQUFNLENBQUNzQyxNQUFNLENBQUMsSUFBSUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxFQUFFO01BQUVDLElBQUksRUFBRTtJQUFjLENBQUMsQ0FBQyxDQUFDO0lBQ25GLE1BQU0sSUFBQTZCLGNBQU0sRUFBQ2pELFdBQVcsQ0FBQ3FCLElBQUksQ0FBQyxDQUFDLEVBQUUsa0JBQWtCLEVBQUUrQyxLQUFLLENBQUMsQ0FBQyxDQUFDUixRQUFRLENBQUNOLE9BQU8sQ0FBQztNQUFFb0IsTUFBTSxFQUFFO0lBQVcsQ0FBQyxDQUFDO0VBQ3ZHLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyIsImlnbm9yZUxpc3QiOltdfQ==