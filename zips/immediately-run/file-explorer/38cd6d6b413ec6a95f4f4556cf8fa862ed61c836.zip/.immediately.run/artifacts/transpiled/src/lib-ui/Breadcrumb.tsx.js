var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
var _lucideReact = require("lucide-react");
var _explorer = require("./explorer");
var _jsxRuntime = require("react/jsx-runtime");
// The breadcrumb + scope chip shown above the list and icon layouts (R3-84). It
// keeps the grant scope VISIBLE in every layout (brief 13 trust constraints): the
// owning mount's name and its `subtree · mode` chip travel with the current
// directory, and read-only vs writable reads the same as the tree's scope header.
// Segments are buttons that navigate up; the last (current) segment is inert.

function Breadcrumb({
  crumbs,
  mount,
  onNavigate
}) {
  const parent = crumbs.length > 1 ? crumbs[crumbs.length - 2] : null;
  const ro = mount ? !(0, _explorer.isWritableMount)(mount) : false;
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "crumbs",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
      type: "button",
      className: "crumbs__back",
      title: "Go up one level",
      "aria-label": "Go up one level",
      disabled: !parent,
      onClick: () => parent && onNavigate(parent.path),
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.ChevronLeft, {
        size: 15,
        "aria-hidden": "true"
      })
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("nav", {
      className: "crumbs__trail",
      "aria-label": "Location",
      children: crumbs.map((c, i) => {
        const last = i === crumbs.length - 1;
        return /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
          className: "crumbs__seg",
          children: [i > 0 && /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.ChevronRight, {
            size: 12,
            className: "crumbs__sep",
            "aria-hidden": "true"
          }), last ? /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
            className: "crumbs__cur",
            "aria-current": "page",
            children: c.label
          }) : /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
            type: "button",
            className: "crumbs__link",
            onClick: () => onNavigate(c.path),
            children: c.label
          })]
        }, c.path ?? "__root");
      })
    }), mount && /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
      className: "scope__chip crumbs__chip",
      children: [ro && /*#__PURE__*/(0, _jsxRuntime.jsx)(_lucideReact.Lock, {
        size: 11,
        "aria-hidden": "true"
      }), (0, _explorer.subtreeLabel)(mount), " \xB7 ", ro ? "read-only" : "read-write"]
    })]
  });
}
_c = Breadcrumb;
var _default = exports.default = Breadcrumb;
var _c;
$RefreshReg$(_c, "Breadcrumb");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfbHVjaWRlUmVhY3QiLCJyZXF1aXJlIiwiX2V4cGxvcmVyIiwiX2pzeFJ1bnRpbWUiLCJCcmVhZGNydW1iIiwiY3J1bWJzIiwibW91bnQiLCJvbk5hdmlnYXRlIiwicGFyZW50IiwibGVuZ3RoIiwicm8iLCJpc1dyaXRhYmxlTW91bnQiLCJqc3hzIiwiY2xhc3NOYW1lIiwiY2hpbGRyZW4iLCJqc3giLCJ0eXBlIiwidGl0bGUiLCJkaXNhYmxlZCIsIm9uQ2xpY2siLCJwYXRoIiwiQ2hldnJvbkxlZnQiLCJzaXplIiwibWFwIiwiYyIsImkiLCJsYXN0IiwiQ2hldnJvblJpZ2h0IiwibGFiZWwiLCJMb2NrIiwic3VidHJlZUxhYmVsIiwiX2MiLCJfZGVmYXVsdCIsImV4cG9ydHMiLCJkZWZhdWx0IiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQnJlYWRjcnVtYi50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gVGhlIGJyZWFkY3J1bWIgKyBzY29wZSBjaGlwIHNob3duIGFib3ZlIHRoZSBsaXN0IGFuZCBpY29uIGxheW91dHMgKFIzLTg0KS4gSXRcbi8vIGtlZXBzIHRoZSBncmFudCBzY29wZSBWSVNJQkxFIGluIGV2ZXJ5IGxheW91dCAoYnJpZWYgMTMgdHJ1c3QgY29uc3RyYWludHMpOiB0aGVcbi8vIG93bmluZyBtb3VudCdzIG5hbWUgYW5kIGl0cyBgc3VidHJlZSDCtyBtb2RlYCBjaGlwIHRyYXZlbCB3aXRoIHRoZSBjdXJyZW50XG4vLyBkaXJlY3RvcnksIGFuZCByZWFkLW9ubHkgdnMgd3JpdGFibGUgcmVhZHMgdGhlIHNhbWUgYXMgdGhlIHRyZWUncyBzY29wZSBoZWFkZXIuXG4vLyBTZWdtZW50cyBhcmUgYnV0dG9ucyB0aGF0IG5hdmlnYXRlIHVwOyB0aGUgbGFzdCAoY3VycmVudCkgc2VnbWVudCBpcyBpbmVydC5cbmltcG9ydCB7IENoZXZyb25MZWZ0LCBDaGV2cm9uUmlnaHQsIExvY2sgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQgeyBzdWJ0cmVlTGFiZWwsIGlzV3JpdGFibGVNb3VudCwgdHlwZSBDcnVtYiB9IGZyb20gXCIuL2V4cGxvcmVyXCI7XG5pbXBvcnQgdHlwZSB7IEV4cGxvcmVyUm9vdCB9IGZyb20gXCIuL3R5cGVzXCI7XG5cbmZ1bmN0aW9uIEJyZWFkY3J1bWIoe1xuICBjcnVtYnMsXG4gIG1vdW50LFxuICBvbk5hdmlnYXRlLFxufToge1xuICBjcnVtYnM6IENydW1iW107XG4gIG1vdW50OiBFeHBsb3JlclJvb3QgfCBudWxsO1xuICBvbk5hdmlnYXRlOiAocGF0aDogc3RyaW5nIHwgbnVsbCkgPT4gdm9pZDtcbn0pIHtcbiAgY29uc3QgcGFyZW50ID0gY3J1bWJzLmxlbmd0aCA+IDEgPyBjcnVtYnNbY3J1bWJzLmxlbmd0aCAtIDJdIDogbnVsbDtcbiAgY29uc3Qgcm8gPSBtb3VudCA/ICFpc1dyaXRhYmxlTW91bnQobW91bnQpIDogZmFsc2U7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImNydW1ic1wiPlxuICAgICAgPGJ1dHRvblxuICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgY2xhc3NOYW1lPVwiY3J1bWJzX19iYWNrXCJcbiAgICAgICAgdGl0bGU9XCJHbyB1cCBvbmUgbGV2ZWxcIlxuICAgICAgICBhcmlhLWxhYmVsPVwiR28gdXAgb25lIGxldmVsXCJcbiAgICAgICAgZGlzYWJsZWQ9eyFwYXJlbnR9XG4gICAgICAgIG9uQ2xpY2s9eygpID0+IHBhcmVudCAmJiBvbk5hdmlnYXRlKHBhcmVudC5wYXRoKX1cbiAgICAgID5cbiAgICAgICAgPENoZXZyb25MZWZ0IHNpemU9ezE1fSBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgPC9idXR0b24+XG4gICAgICA8bmF2IGNsYXNzTmFtZT1cImNydW1ic19fdHJhaWxcIiBhcmlhLWxhYmVsPVwiTG9jYXRpb25cIj5cbiAgICAgICAge2NydW1icy5tYXAoKGMsIGkpID0+IHtcbiAgICAgICAgICBjb25zdCBsYXN0ID0gaSA9PT0gY3J1bWJzLmxlbmd0aCAtIDE7XG4gICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIDxzcGFuIGtleT17Yy5wYXRoID8/IFwiX19yb290XCJ9IGNsYXNzTmFtZT1cImNydW1ic19fc2VnXCI+XG4gICAgICAgICAgICAgIHtpID4gMCAmJiA8Q2hldnJvblJpZ2h0IHNpemU9ezEyfSBjbGFzc05hbWU9XCJjcnVtYnNfX3NlcFwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+fVxuICAgICAgICAgICAgICB7bGFzdCA/IChcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjcnVtYnNfX2N1clwiIGFyaWEtY3VycmVudD1cInBhZ2VcIj5cbiAgICAgICAgICAgICAgICAgIHtjLmxhYmVsfVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJjcnVtYnNfX2xpbmtcIiBvbkNsaWNrPXsoKSA9PiBvbk5hdmlnYXRlKGMucGF0aCl9PlxuICAgICAgICAgICAgICAgICAge2MubGFiZWx9XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgKTtcbiAgICAgICAgfSl9XG4gICAgICA8L25hdj5cbiAgICAgIHttb3VudCAmJiAoXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNjb3BlX19jaGlwIGNydW1ic19fY2hpcFwiPlxuICAgICAgICAgIHtybyAmJiA8TG9jayBzaXplPXsxMX0gYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz59XG4gICAgICAgICAge3N1YnRyZWVMYWJlbChtb3VudCl9IMK3IHtybyA/IFwicmVhZC1vbmx5XCIgOiBcInJlYWQtd3JpdGVcIn1cbiAgICAgICAgPC9zcGFuPlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgQnJlYWRjcnVtYjtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFLQSxJQUFBQSxZQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxTQUFBLEdBQUFELE9BQUE7QUFBdUUsSUFBQUUsV0FBQSxHQUFBRixPQUFBO0FBTnZFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBS0EsU0FBU0csVUFBVUEsQ0FBQztFQUNsQkMsTUFBTTtFQUNOQyxLQUFLO0VBQ0xDO0FBS0YsQ0FBQyxFQUFFO0VBQ0QsTUFBTUMsTUFBTSxHQUFHSCxNQUFNLENBQUNJLE1BQU0sR0FBRyxDQUFDLEdBQUdKLE1BQU0sQ0FBQ0EsTUFBTSxDQUFDSSxNQUFNLEdBQUcsQ0FBQyxDQUFDLEdBQUcsSUFBSTtFQUNuRSxNQUFNQyxFQUFFLEdBQUdKLEtBQUssR0FBRyxDQUFDLElBQUFLLHlCQUFlLEVBQUNMLEtBQUssQ0FBQyxHQUFHLEtBQUs7RUFFbEQsb0JBQ0UsSUFBQUgsV0FBQSxDQUFBUyxJQUFBO0lBQUtDLFNBQVMsRUFBQyxRQUFRO0lBQUFDLFFBQUEsZ0JBQ3JCLElBQUFYLFdBQUEsQ0FBQVksR0FBQTtNQUNFQyxJQUFJLEVBQUMsUUFBUTtNQUNiSCxTQUFTLEVBQUMsY0FBYztNQUN4QkksS0FBSyxFQUFDLGlCQUFpQjtNQUN2QixjQUFXLGlCQUFpQjtNQUM1QkMsUUFBUSxFQUFFLENBQUNWLE1BQU87TUFDbEJXLE9BQU8sRUFBRUEsQ0FBQSxLQUFNWCxNQUFNLElBQUlELFVBQVUsQ0FBQ0MsTUFBTSxDQUFDWSxJQUFJLENBQUU7TUFBQU4sUUFBQSxlQUVqRCxJQUFBWCxXQUFBLENBQUFZLEdBQUEsRUFBQ2YsWUFBQSxDQUFBcUIsV0FBVztRQUFDQyxJQUFJLEVBQUUsRUFBRztRQUFDLGVBQVk7TUFBTSxDQUFFO0lBQUMsQ0FDdEMsQ0FBQyxlQUNULElBQUFuQixXQUFBLENBQUFZLEdBQUE7TUFBS0YsU0FBUyxFQUFDLGVBQWU7TUFBQyxjQUFXLFVBQVU7TUFBQUMsUUFBQSxFQUNqRFQsTUFBTSxDQUFDa0IsR0FBRyxDQUFDLENBQUNDLENBQUMsRUFBRUMsQ0FBQyxLQUFLO1FBQ3BCLE1BQU1DLElBQUksR0FBR0QsQ0FBQyxLQUFLcEIsTUFBTSxDQUFDSSxNQUFNLEdBQUcsQ0FBQztRQUNwQyxvQkFDRSxJQUFBTixXQUFBLENBQUFTLElBQUE7VUFBK0JDLFNBQVMsRUFBQyxhQUFhO1VBQUFDLFFBQUEsR0FDbkRXLENBQUMsR0FBRyxDQUFDLGlCQUFJLElBQUF0QixXQUFBLENBQUFZLEdBQUEsRUFBQ2YsWUFBQSxDQUFBMkIsWUFBWTtZQUFDTCxJQUFJLEVBQUUsRUFBRztZQUFDVCxTQUFTLEVBQUMsYUFBYTtZQUFDLGVBQVk7VUFBTSxDQUFFLENBQUMsRUFDOUVhLElBQUksZ0JBQ0gsSUFBQXZCLFdBQUEsQ0FBQVksR0FBQTtZQUFNRixTQUFTLEVBQUMsYUFBYTtZQUFDLGdCQUFhLE1BQU07WUFBQUMsUUFBQSxFQUM5Q1UsQ0FBQyxDQUFDSTtVQUFLLENBQ0osQ0FBQyxnQkFFUCxJQUFBekIsV0FBQSxDQUFBWSxHQUFBO1lBQVFDLElBQUksRUFBQyxRQUFRO1lBQUNILFNBQVMsRUFBQyxjQUFjO1lBQUNNLE9BQU8sRUFBRUEsQ0FBQSxLQUFNWixVQUFVLENBQUNpQixDQUFDLENBQUNKLElBQUksQ0FBRTtZQUFBTixRQUFBLEVBQzlFVSxDQUFDLENBQUNJO1VBQUssQ0FDRixDQUNUO1FBQUEsR0FWUUosQ0FBQyxDQUFDSixJQUFJLElBQUksUUFXZixDQUFDO01BRVgsQ0FBQztJQUFDLENBQ0MsQ0FBQyxFQUNMZCxLQUFLLGlCQUNKLElBQUFILFdBQUEsQ0FBQVMsSUFBQTtNQUFNQyxTQUFTLEVBQUMsMEJBQTBCO01BQUFDLFFBQUEsR0FDdkNKLEVBQUUsaUJBQUksSUFBQVAsV0FBQSxDQUFBWSxHQUFBLEVBQUNmLFlBQUEsQ0FBQTZCLElBQUk7UUFBQ1AsSUFBSSxFQUFFLEVBQUc7UUFBQyxlQUFZO01BQU0sQ0FBRSxDQUFDLEVBQzNDLElBQUFRLHNCQUFZLEVBQUN4QixLQUFLLENBQUMsRUFBQyxRQUFHLEVBQUNJLEVBQUUsR0FBRyxXQUFXLEdBQUcsWUFBWTtJQUFBLENBQ3BELENBQ1A7RUFBQSxDQUNFLENBQUM7QUFFVjtBQUFDcUIsRUFBQSxHQW5EUTNCLFVBQVU7QUFBQSxJQUFBNEIsUUFBQSxHQUFBQyxPQUFBLENBQUFDLE9BQUEsR0FxREo5QixVQUFVO0FBQUEsSUFBQTJCLEVBQUE7QUFBQUksWUFBQSxDQUFBSixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}