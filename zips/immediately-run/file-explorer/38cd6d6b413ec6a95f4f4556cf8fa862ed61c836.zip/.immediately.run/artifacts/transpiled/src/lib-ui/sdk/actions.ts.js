"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.makeSdkActions = makeSdkActions;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.find.js");
var _sdk = require("@immediately-run/sdk");
var _explorer = require("../explorer");
var _mountFs = require("./mountFs");
// `makeSdkActions()` — the SDK adapter's `ExplorerActions` (Phase 02 §B.3). Each
// method wraps the matching host-gated intent (`editor:open` / `editor:write`) or
// the cross-app drag-out, carrying over the exact path conversion the original
// `FileExplorer.tsx` used. The view passes mount-relative paths (it already
// trimmed the owning root), so these forward them straight to the SDK; rejections
// (`{ code }`) propagate to the view's write flow, whose `writeError`
// (writeFlow.ts) maps them through `WRITE_ERR` — a `too-large` refusal carrying
// the host's `limitBytes` renders the REAL limit, not a client-side guess
// (R3-853: there is deliberately no per-file cap here anymore).

/** Build the SDK-backed action bundle for the shipped file-explorer app. */
function makeSdkActions() {
  return {
    // R3-79/§4: open a file in the neighboring editor (`editor:open`). `not-found`
    // is swallowed (the file may have just been deleted); the call is best-effort.
    open: (_root, relPath) => {
      void (0, _sdk.openInEditor)(relPath).catch(() => undefined);
    },
    // Create / rename / delete: the app NAMES a mount-relative path; the host
    // performs the COW write behind `editor:write`. Each write resolves the
    // entry it produced (the caller renders and settles the write's own
    // result — R-IX-4); rejections flow to the view's write flow. `rename`
    // derives the settled entry from the destination listing — the authority's
    // own answer, including whether the moved thing is a folder — and degrades
    // to the name it asked for if the listing can't be read.
    createFile: async (_root, relPath) => {
      await (0, _sdk.createFile)(relPath);
      return {
        name: (0, _explorer.basename)(relPath),
        isDir: false
      };
    },
    createFolder: async (_root, relPath) => {
      await (0, _sdk.createFolder)(relPath);
      return {
        name: (0, _explorer.basename)(relPath),
        isDir: true
      };
    },
    rename: async (root, fromRel, toRel, isDir) => {
      await (0, _sdk.renameEntry)(fromRel, toRel);
      const name = (0, _explorer.basename)(toRel);
      const parentAbs = (0, _explorer.joinRel)(root.path, (0, _explorer.dirOf)(toRel));
      try {
        const list = await _mountFs.sdkFsSource.readdir(parentAbs);
        const hit = list.find(e => e.name === name);
        if (hit) return hit;
      } catch {
        /* unreadable listing — the narrow refetch is still the authority */
      }
      // Degraded settle: the name it asked for, and the caller's own fact
      // about the row (never a fabricated file).
      return {
        name,
        isDir: isDir ?? false
      };
    },
    delete: async (_root, relPath) => {
      await (0, _sdk.deleteEntry)(relPath);
      return relPath;
    },
    // R3-82 upload: inline each file's bytes. R3-853: NO client-side cap — the
    // host enforces the real limit and names it (`err.limitBytes`), so a refusal
    // here is the host's answer, not a guess that could drift from it.
    upload: async (_root, dirRel, files) => {
      for (const f of files) {
        const bytes = new Uint8Array(await f.arrayBuffer());
        await (0, _sdk.uploadFile)((0, _explorer.joinPath)(dirRel, (0, _explorer.basename)(f.name)), bytes);
      }
    },
    // R3-83 drag-out: ask the host to begin a cross-app drag. Reference-only for
    // dirs / large files; inline bytes for a small file (best-effort — the source
    // can only relay bytes it can already read). `forbidden`/no host is swallowed:
    // the internal move still works.
    beginDragOut: (root, relPath, isDir) => {
      void (async () => {
        const item = {
          kind: isDir ? "dir" : "file",
          name: (0, _explorer.basename)(relPath),
          mountId: root.id,
          relPath
        };
        if (!isDir) {
          try {
            const abs = (0, _explorer.joinPath)(root.path, relPath.replace(/^\/+/, ""));
            const bytes = await _mountFs.sdkFsSource.readFile(abs);
            if (bytes.byteLength <= _explorer.INLINE_DRAG_OUT_BYTES) item.bytes = bytes;
          } catch {
            /* unreadable → reference-only */
          }
        }
        try {
          await (0, _sdk.startItemDrag)(item);
        } catch {
          /* no dnd:source / no host → drag-out unavailable, internal move unaffected */
        }
      })();
    },
    cancelDragOut: () => (0, _sdk.cancelItemDrag)(),
    // R-SPACES-3 eject: detach a space for this session (`unmountSpace`). The mount
    // disappears via the `useMounts()` subscription; typed errors degrade quietly.
    eject: async root => {
      if (!root.spaceId) return;
      await (0, _sdk.unmountSpace)({
        spaceId: root.spaceId
      });
    }
  };
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfc2RrIiwicmVxdWlyZSIsIl9leHBsb3JlciIsIl9tb3VudEZzIiwibWFrZVNka0FjdGlvbnMiLCJvcGVuIiwiX3Jvb3QiLCJyZWxQYXRoIiwib3BlbkluRWRpdG9yIiwiY2F0Y2giLCJ1bmRlZmluZWQiLCJjcmVhdGVGaWxlIiwibmFtZSIsImJhc2VuYW1lIiwiaXNEaXIiLCJjcmVhdGVGb2xkZXIiLCJyZW5hbWUiLCJyb290IiwiZnJvbVJlbCIsInRvUmVsIiwicmVuYW1lRW50cnkiLCJwYXJlbnRBYnMiLCJqb2luUmVsIiwicGF0aCIsImRpck9mIiwibGlzdCIsInNka0ZzU291cmNlIiwicmVhZGRpciIsImhpdCIsImZpbmQiLCJlIiwiZGVsZXRlIiwiZGVsZXRlRW50cnkiLCJ1cGxvYWQiLCJkaXJSZWwiLCJmaWxlcyIsImYiLCJieXRlcyIsIlVpbnQ4QXJyYXkiLCJhcnJheUJ1ZmZlciIsInVwbG9hZEZpbGUiLCJqb2luUGF0aCIsImJlZ2luRHJhZ091dCIsIml0ZW0iLCJraW5kIiwibW91bnRJZCIsImlkIiwiYWJzIiwicmVwbGFjZSIsInJlYWRGaWxlIiwiYnl0ZUxlbmd0aCIsIklOTElORV9EUkFHX09VVF9CWVRFUyIsInN0YXJ0SXRlbURyYWciLCJjYW5jZWxEcmFnT3V0IiwiY2FuY2VsSXRlbURyYWciLCJlamVjdCIsInNwYWNlSWQiLCJ1bm1vdW50U3BhY2UiXSwic291cmNlcyI6WyJhY3Rpb25zLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIGBtYWtlU2RrQWN0aW9ucygpYCDigJQgdGhlIFNESyBhZGFwdGVyJ3MgYEV4cGxvcmVyQWN0aW9uc2AgKFBoYXNlIDAyIMKnQi4zKS4gRWFjaFxuLy8gbWV0aG9kIHdyYXBzIHRoZSBtYXRjaGluZyBob3N0LWdhdGVkIGludGVudCAoYGVkaXRvcjpvcGVuYCAvIGBlZGl0b3I6d3JpdGVgKSBvclxuLy8gdGhlIGNyb3NzLWFwcCBkcmFnLW91dCwgY2Fycnlpbmcgb3ZlciB0aGUgZXhhY3QgcGF0aCBjb252ZXJzaW9uIHRoZSBvcmlnaW5hbFxuLy8gYEZpbGVFeHBsb3Jlci50c3hgIHVzZWQuIFRoZSB2aWV3IHBhc3NlcyBtb3VudC1yZWxhdGl2ZSBwYXRocyAoaXQgYWxyZWFkeVxuLy8gdHJpbW1lZCB0aGUgb3duaW5nIHJvb3QpLCBzbyB0aGVzZSBmb3J3YXJkIHRoZW0gc3RyYWlnaHQgdG8gdGhlIFNESzsgcmVqZWN0aW9uc1xuLy8gKGB7IGNvZGUgfWApIHByb3BhZ2F0ZSB0byB0aGUgdmlldydzIHdyaXRlIGZsb3csIHdob3NlIGB3cml0ZUVycm9yYFxuLy8gKHdyaXRlRmxvdy50cykgbWFwcyB0aGVtIHRocm91Z2ggYFdSSVRFX0VSUmAg4oCUIGEgYHRvby1sYXJnZWAgcmVmdXNhbCBjYXJyeWluZ1xuLy8gdGhlIGhvc3QncyBgbGltaXRCeXRlc2AgcmVuZGVycyB0aGUgUkVBTCBsaW1pdCwgbm90IGEgY2xpZW50LXNpZGUgZ3Vlc3Ncbi8vIChSMy04NTM6IHRoZXJlIGlzIGRlbGliZXJhdGVseSBubyBwZXItZmlsZSBjYXAgaGVyZSBhbnltb3JlKS5cbmltcG9ydCB7XG4gIG9wZW5JbkVkaXRvcixcbiAgY3JlYXRlRmlsZSxcbiAgY3JlYXRlRm9sZGVyLFxuICBkZWxldGVFbnRyeSxcbiAgcmVuYW1lRW50cnksXG4gIHVwbG9hZEZpbGUsXG4gIHN0YXJ0SXRlbURyYWcsXG4gIGNhbmNlbEl0ZW1EcmFnLFxuICB1bm1vdW50U3BhY2UsXG59IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nka1wiO1xuaW1wb3J0IHsgYmFzZW5hbWUsIGRpck9mLCBJTkxJTkVfRFJBR19PVVRfQllURVMsIGpvaW5QYXRoLCBqb2luUmVsIH0gZnJvbSBcIi4uL2V4cGxvcmVyXCI7XG5pbXBvcnQgeyBzZGtGc1NvdXJjZSB9IGZyb20gXCIuL21vdW50RnNcIjtcbmltcG9ydCB0eXBlIHsgRW50cnksIEV4cGxvcmVyQWN0aW9ucyB9IGZyb20gXCIuLi90eXBlc1wiO1xuXG4vKiogQnVpbGQgdGhlIFNESy1iYWNrZWQgYWN0aW9uIGJ1bmRsZSBmb3IgdGhlIHNoaXBwZWQgZmlsZS1leHBsb3JlciBhcHAuICovXG5leHBvcnQgZnVuY3Rpb24gbWFrZVNka0FjdGlvbnMoKTogRXhwbG9yZXJBY3Rpb25zIHtcbiAgcmV0dXJuIHtcbiAgICAvLyBSMy03OS/CpzQ6IG9wZW4gYSBmaWxlIGluIHRoZSBuZWlnaGJvcmluZyBlZGl0b3IgKGBlZGl0b3I6b3BlbmApLiBgbm90LWZvdW5kYFxuICAgIC8vIGlzIHN3YWxsb3dlZCAodGhlIGZpbGUgbWF5IGhhdmUganVzdCBiZWVuIGRlbGV0ZWQpOyB0aGUgY2FsbCBpcyBiZXN0LWVmZm9ydC5cbiAgICBvcGVuOiAoX3Jvb3QsIHJlbFBhdGgpID0+IHtcbiAgICAgIHZvaWQgb3BlbkluRWRpdG9yKHJlbFBhdGgpLmNhdGNoKCgpID0+IHVuZGVmaW5lZCk7XG4gICAgfSxcblxuICAgIC8vIENyZWF0ZSAvIHJlbmFtZSAvIGRlbGV0ZTogdGhlIGFwcCBOQU1FUyBhIG1vdW50LXJlbGF0aXZlIHBhdGg7IHRoZSBob3N0XG4gICAgLy8gcGVyZm9ybXMgdGhlIENPVyB3cml0ZSBiZWhpbmQgYGVkaXRvcjp3cml0ZWAuIEVhY2ggd3JpdGUgcmVzb2x2ZXMgdGhlXG4gICAgLy8gZW50cnkgaXQgcHJvZHVjZWQgKHRoZSBjYWxsZXIgcmVuZGVycyBhbmQgc2V0dGxlcyB0aGUgd3JpdGUncyBvd25cbiAgICAvLyByZXN1bHQg4oCUIFItSVgtNCk7IHJlamVjdGlvbnMgZmxvdyB0byB0aGUgdmlldydzIHdyaXRlIGZsb3cuIGByZW5hbWVgXG4gICAgLy8gZGVyaXZlcyB0aGUgc2V0dGxlZCBlbnRyeSBmcm9tIHRoZSBkZXN0aW5hdGlvbiBsaXN0aW5nIOKAlCB0aGUgYXV0aG9yaXR5J3NcbiAgICAvLyBvd24gYW5zd2VyLCBpbmNsdWRpbmcgd2hldGhlciB0aGUgbW92ZWQgdGhpbmcgaXMgYSBmb2xkZXIg4oCUIGFuZCBkZWdyYWRlc1xuICAgIC8vIHRvIHRoZSBuYW1lIGl0IGFza2VkIGZvciBpZiB0aGUgbGlzdGluZyBjYW4ndCBiZSByZWFkLlxuICAgIGNyZWF0ZUZpbGU6IGFzeW5jIChfcm9vdCwgcmVsUGF0aCkgPT4ge1xuICAgICAgYXdhaXQgY3JlYXRlRmlsZShyZWxQYXRoKTtcbiAgICAgIHJldHVybiB7IG5hbWU6IGJhc2VuYW1lKHJlbFBhdGgpLCBpc0RpcjogZmFsc2UgfSBzYXRpc2ZpZXMgRW50cnk7XG4gICAgfSxcbiAgICBjcmVhdGVGb2xkZXI6IGFzeW5jIChfcm9vdCwgcmVsUGF0aCkgPT4ge1xuICAgICAgYXdhaXQgY3JlYXRlRm9sZGVyKHJlbFBhdGgpO1xuICAgICAgcmV0dXJuIHsgbmFtZTogYmFzZW5hbWUocmVsUGF0aCksIGlzRGlyOiB0cnVlIH0gc2F0aXNmaWVzIEVudHJ5O1xuICAgIH0sXG4gICAgcmVuYW1lOiBhc3luYyAocm9vdCwgZnJvbVJlbCwgdG9SZWwsIGlzRGlyKSA9PiB7XG4gICAgICBhd2FpdCByZW5hbWVFbnRyeShmcm9tUmVsLCB0b1JlbCk7XG4gICAgICBjb25zdCBuYW1lID0gYmFzZW5hbWUodG9SZWwpO1xuICAgICAgY29uc3QgcGFyZW50QWJzID0gam9pblJlbChyb290LnBhdGgsIGRpck9mKHRvUmVsKSk7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBsaXN0ID0gYXdhaXQgc2RrRnNTb3VyY2UucmVhZGRpcihwYXJlbnRBYnMpO1xuICAgICAgICBjb25zdCBoaXQgPSBsaXN0LmZpbmQoKGUpID0+IGUubmFtZSA9PT0gbmFtZSk7XG4gICAgICAgIGlmIChoaXQpIHJldHVybiBoaXQ7XG4gICAgICB9IGNhdGNoIHtcbiAgICAgICAgLyogdW5yZWFkYWJsZSBsaXN0aW5nIOKAlCB0aGUgbmFycm93IHJlZmV0Y2ggaXMgc3RpbGwgdGhlIGF1dGhvcml0eSAqL1xuICAgICAgfVxuICAgICAgLy8gRGVncmFkZWQgc2V0dGxlOiB0aGUgbmFtZSBpdCBhc2tlZCBmb3IsIGFuZCB0aGUgY2FsbGVyJ3Mgb3duIGZhY3RcbiAgICAgIC8vIGFib3V0IHRoZSByb3cgKG5ldmVyIGEgZmFicmljYXRlZCBmaWxlKS5cbiAgICAgIHJldHVybiB7IG5hbWUsIGlzRGlyOiBpc0RpciA/PyBmYWxzZSB9IHNhdGlzZmllcyBFbnRyeTtcbiAgICB9LFxuICAgIGRlbGV0ZTogYXN5bmMgKF9yb290LCByZWxQYXRoKSA9PiB7XG4gICAgICBhd2FpdCBkZWxldGVFbnRyeShyZWxQYXRoKTtcbiAgICAgIHJldHVybiByZWxQYXRoO1xuICAgIH0sXG5cbiAgICAvLyBSMy04MiB1cGxvYWQ6IGlubGluZSBlYWNoIGZpbGUncyBieXRlcy4gUjMtODUzOiBOTyBjbGllbnQtc2lkZSBjYXAg4oCUIHRoZVxuICAgIC8vIGhvc3QgZW5mb3JjZXMgdGhlIHJlYWwgbGltaXQgYW5kIG5hbWVzIGl0IChgZXJyLmxpbWl0Qnl0ZXNgKSwgc28gYSByZWZ1c2FsXG4gICAgLy8gaGVyZSBpcyB0aGUgaG9zdCdzIGFuc3dlciwgbm90IGEgZ3Vlc3MgdGhhdCBjb3VsZCBkcmlmdCBmcm9tIGl0LlxuICAgIHVwbG9hZDogYXN5bmMgKF9yb290LCBkaXJSZWwsIGZpbGVzKSA9PiB7XG4gICAgICBmb3IgKGNvbnN0IGYgb2YgZmlsZXMpIHtcbiAgICAgICAgY29uc3QgYnl0ZXMgPSBuZXcgVWludDhBcnJheShhd2FpdCBmLmFycmF5QnVmZmVyKCkpO1xuICAgICAgICBhd2FpdCB1cGxvYWRGaWxlKGpvaW5QYXRoKGRpclJlbCwgYmFzZW5hbWUoZi5uYW1lKSksIGJ5dGVzKTtcbiAgICAgIH1cbiAgICB9LFxuXG4gICAgLy8gUjMtODMgZHJhZy1vdXQ6IGFzayB0aGUgaG9zdCB0byBiZWdpbiBhIGNyb3NzLWFwcCBkcmFnLiBSZWZlcmVuY2Utb25seSBmb3JcbiAgICAvLyBkaXJzIC8gbGFyZ2UgZmlsZXM7IGlubGluZSBieXRlcyBmb3IgYSBzbWFsbCBmaWxlIChiZXN0LWVmZm9ydCDigJQgdGhlIHNvdXJjZVxuICAgIC8vIGNhbiBvbmx5IHJlbGF5IGJ5dGVzIGl0IGNhbiBhbHJlYWR5IHJlYWQpLiBgZm9yYmlkZGVuYC9ubyBob3N0IGlzIHN3YWxsb3dlZDpcbiAgICAvLyB0aGUgaW50ZXJuYWwgbW92ZSBzdGlsbCB3b3Jrcy5cbiAgICBiZWdpbkRyYWdPdXQ6IChyb290LCByZWxQYXRoLCBpc0RpcikgPT4ge1xuICAgICAgdm9pZCAoYXN5bmMgKCkgPT4ge1xuICAgICAgICBjb25zdCBpdGVtID0ge1xuICAgICAgICAgIGtpbmQ6IChpc0RpciA/IFwiZGlyXCIgOiBcImZpbGVcIikgYXMgXCJkaXJcIiB8IFwiZmlsZVwiLFxuICAgICAgICAgIG5hbWU6IGJhc2VuYW1lKHJlbFBhdGgpLFxuICAgICAgICAgIG1vdW50SWQ6IHJvb3QuaWQsXG4gICAgICAgICAgcmVsUGF0aCxcbiAgICAgICAgfSBhcyBQYXJhbWV0ZXJzPHR5cGVvZiBzdGFydEl0ZW1EcmFnPlswXTtcbiAgICAgICAgaWYgKCFpc0Rpcikge1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCBhYnMgPSBqb2luUGF0aChyb290LnBhdGgsIHJlbFBhdGgucmVwbGFjZSgvXlxcLysvLCBcIlwiKSk7XG4gICAgICAgICAgICBjb25zdCBieXRlcyA9IGF3YWl0IHNka0ZzU291cmNlLnJlYWRGaWxlIShhYnMpO1xuICAgICAgICAgICAgaWYgKGJ5dGVzLmJ5dGVMZW5ndGggPD0gSU5MSU5FX0RSQUdfT1VUX0JZVEVTKSBpdGVtLmJ5dGVzID0gYnl0ZXM7XG4gICAgICAgICAgfSBjYXRjaCB7XG4gICAgICAgICAgICAvKiB1bnJlYWRhYmxlIOKGkiByZWZlcmVuY2Utb25seSAqL1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICB0cnkge1xuICAgICAgICAgIGF3YWl0IHN0YXJ0SXRlbURyYWcoaXRlbSk7XG4gICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgIC8qIG5vIGRuZDpzb3VyY2UgLyBubyBob3N0IOKGkiBkcmFnLW91dCB1bmF2YWlsYWJsZSwgaW50ZXJuYWwgbW92ZSB1bmFmZmVjdGVkICovXG4gICAgICAgIH1cbiAgICAgIH0pKCk7XG4gICAgfSxcbiAgICBjYW5jZWxEcmFnT3V0OiAoKSA9PiBjYW5jZWxJdGVtRHJhZygpLFxuXG4gICAgLy8gUi1TUEFDRVMtMyBlamVjdDogZGV0YWNoIGEgc3BhY2UgZm9yIHRoaXMgc2Vzc2lvbiAoYHVubW91bnRTcGFjZWApLiBUaGUgbW91bnRcbiAgICAvLyBkaXNhcHBlYXJzIHZpYSB0aGUgYHVzZU1vdW50cygpYCBzdWJzY3JpcHRpb247IHR5cGVkIGVycm9ycyBkZWdyYWRlIHF1aWV0bHkuXG4gICAgZWplY3Q6IGFzeW5jIChyb290KSA9PiB7XG4gICAgICBpZiAoIXJvb3Quc3BhY2VJZCkgcmV0dXJuO1xuICAgICAgYXdhaXQgdW5tb3VudFNwYWNlKHsgc3BhY2VJZDogcm9vdC5zcGFjZUlkIH0pO1xuICAgIH0sXG4gIH07XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBU0EsSUFBQUEsSUFBQSxHQUFBQyxPQUFBO0FBV0EsSUFBQUMsU0FBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsUUFBQSxHQUFBRixPQUFBO0FBckJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFnQkE7QUFDTyxTQUFTRyxjQUFjQSxDQUFBLEVBQW9CO0VBQ2hELE9BQU87SUFDTDtJQUNBO0lBQ0FDLElBQUksRUFBRUEsQ0FBQ0MsS0FBSyxFQUFFQyxPQUFPLEtBQUs7TUFDeEIsS0FBSyxJQUFBQyxpQkFBWSxFQUFDRCxPQUFPLENBQUMsQ0FBQ0UsS0FBSyxDQUFDLE1BQU1DLFNBQVMsQ0FBQztJQUNuRCxDQUFDO0lBRUQ7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQUMsVUFBVSxFQUFFLE1BQUFBLENBQU9MLEtBQUssRUFBRUMsT0FBTyxLQUFLO01BQ3BDLE1BQU0sSUFBQUksZUFBVSxFQUFDSixPQUFPLENBQUM7TUFDekIsT0FBTztRQUFFSyxJQUFJLEVBQUUsSUFBQUMsa0JBQVEsRUFBQ04sT0FBTyxDQUFDO1FBQUVPLEtBQUssRUFBRTtNQUFNLENBQUM7SUFDbEQsQ0FBQztJQUNEQyxZQUFZLEVBQUUsTUFBQUEsQ0FBT1QsS0FBSyxFQUFFQyxPQUFPLEtBQUs7TUFDdEMsTUFBTSxJQUFBUSxpQkFBWSxFQUFDUixPQUFPLENBQUM7TUFDM0IsT0FBTztRQUFFSyxJQUFJLEVBQUUsSUFBQUMsa0JBQVEsRUFBQ04sT0FBTyxDQUFDO1FBQUVPLEtBQUssRUFBRTtNQUFLLENBQUM7SUFDakQsQ0FBQztJQUNERSxNQUFNLEVBQUUsTUFBQUEsQ0FBT0MsSUFBSSxFQUFFQyxPQUFPLEVBQUVDLEtBQUssRUFBRUwsS0FBSyxLQUFLO01BQzdDLE1BQU0sSUFBQU0sZ0JBQVcsRUFBQ0YsT0FBTyxFQUFFQyxLQUFLLENBQUM7TUFDakMsTUFBTVAsSUFBSSxHQUFHLElBQUFDLGtCQUFRLEVBQUNNLEtBQUssQ0FBQztNQUM1QixNQUFNRSxTQUFTLEdBQUcsSUFBQUMsaUJBQU8sRUFBQ0wsSUFBSSxDQUFDTSxJQUFJLEVBQUUsSUFBQUMsZUFBSyxFQUFDTCxLQUFLLENBQUMsQ0FBQztNQUNsRCxJQUFJO1FBQ0YsTUFBTU0sSUFBSSxHQUFHLE1BQU1DLG9CQUFXLENBQUNDLE9BQU8sQ0FBQ04sU0FBUyxDQUFDO1FBQ2pELE1BQU1PLEdBQUcsR0FBR0gsSUFBSSxDQUFDSSxJQUFJLENBQUVDLENBQUMsSUFBS0EsQ0FBQyxDQUFDbEIsSUFBSSxLQUFLQSxJQUFJLENBQUM7UUFDN0MsSUFBSWdCLEdBQUcsRUFBRSxPQUFPQSxHQUFHO01BQ3JCLENBQUMsQ0FBQyxNQUFNO1FBQ047TUFBQTtNQUVGO01BQ0E7TUFDQSxPQUFPO1FBQUVoQixJQUFJO1FBQUVFLEtBQUssRUFBRUEsS0FBSyxJQUFJO01BQU0sQ0FBQztJQUN4QyxDQUFDO0lBQ0RpQixNQUFNLEVBQUUsTUFBQUEsQ0FBT3pCLEtBQUssRUFBRUMsT0FBTyxLQUFLO01BQ2hDLE1BQU0sSUFBQXlCLGdCQUFXLEVBQUN6QixPQUFPLENBQUM7TUFDMUIsT0FBT0EsT0FBTztJQUNoQixDQUFDO0lBRUQ7SUFDQTtJQUNBO0lBQ0EwQixNQUFNLEVBQUUsTUFBQUEsQ0FBTzNCLEtBQUssRUFBRTRCLE1BQU0sRUFBRUMsS0FBSyxLQUFLO01BQ3RDLEtBQUssTUFBTUMsQ0FBQyxJQUFJRCxLQUFLLEVBQUU7UUFDckIsTUFBTUUsS0FBSyxHQUFHLElBQUlDLFVBQVUsQ0FBQyxNQUFNRixDQUFDLENBQUNHLFdBQVcsQ0FBQyxDQUFDLENBQUM7UUFDbkQsTUFBTSxJQUFBQyxlQUFVLEVBQUMsSUFBQUMsa0JBQVEsRUFBQ1AsTUFBTSxFQUFFLElBQUFyQixrQkFBUSxFQUFDdUIsQ0FBQyxDQUFDeEIsSUFBSSxDQUFDLENBQUMsRUFBRXlCLEtBQUssQ0FBQztNQUM3RDtJQUNGLENBQUM7SUFFRDtJQUNBO0lBQ0E7SUFDQTtJQUNBSyxZQUFZLEVBQUVBLENBQUN6QixJQUFJLEVBQUVWLE9BQU8sRUFBRU8sS0FBSyxLQUFLO01BQ3RDLEtBQUssQ0FBQyxZQUFZO1FBQ2hCLE1BQU02QixJQUFJLEdBQUc7VUFDWEMsSUFBSSxFQUFHOUIsS0FBSyxHQUFHLEtBQUssR0FBRyxNQUF5QjtVQUNoREYsSUFBSSxFQUFFLElBQUFDLGtCQUFRLEVBQUNOLE9BQU8sQ0FBQztVQUN2QnNDLE9BQU8sRUFBRTVCLElBQUksQ0FBQzZCLEVBQUU7VUFDaEJ2QztRQUNGLENBQXdDO1FBQ3hDLElBQUksQ0FBQ08sS0FBSyxFQUFFO1VBQ1YsSUFBSTtZQUNGLE1BQU1pQyxHQUFHLEdBQUcsSUFBQU4sa0JBQVEsRUFBQ3hCLElBQUksQ0FBQ00sSUFBSSxFQUFFaEIsT0FBTyxDQUFDeUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsQ0FBQztZQUM1RCxNQUFNWCxLQUFLLEdBQUcsTUFBTVgsb0JBQVcsQ0FBQ3VCLFFBQVEsQ0FBRUYsR0FBRyxDQUFDO1lBQzlDLElBQUlWLEtBQUssQ0FBQ2EsVUFBVSxJQUFJQywrQkFBcUIsRUFBRVIsSUFBSSxDQUFDTixLQUFLLEdBQUdBLEtBQUs7VUFDbkUsQ0FBQyxDQUFDLE1BQU07WUFDTjtVQUFBO1FBRUo7UUFDQSxJQUFJO1VBQ0YsTUFBTSxJQUFBZSxrQkFBYSxFQUFDVCxJQUFJLENBQUM7UUFDM0IsQ0FBQyxDQUFDLE1BQU07VUFDTjtRQUFBO01BRUosQ0FBQyxFQUFFLENBQUM7SUFDTixDQUFDO0lBQ0RVLGFBQWEsRUFBRUEsQ0FBQSxLQUFNLElBQUFDLG1CQUFjLEVBQUMsQ0FBQztJQUVyQztJQUNBO0lBQ0FDLEtBQUssRUFBRSxNQUFPdEMsSUFBSSxJQUFLO01BQ3JCLElBQUksQ0FBQ0EsSUFBSSxDQUFDdUMsT0FBTyxFQUFFO01BQ25CLE1BQU0sSUFBQUMsaUJBQVksRUFBQztRQUFFRCxPQUFPLEVBQUV2QyxJQUFJLENBQUN1QztNQUFRLENBQUMsQ0FBQztJQUMvQztFQUNGLENBQUM7QUFDSCIsImlnbm9yZUxpc3QiOltdfQ==