var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _lucideReact = require("lucide-react");
var _useRadiogroupNav = require("./hooks/useRadiogroupNav");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The view switcher (R3-84, design brief 13 §1): a compact segmented control in
// the panel header that swaps the explorer between tree / list / columns / icons.
// App-local view state only. Lucide icons (no emoji); sentence-case tooltips; the
// label sits beside the icon when the header is wide and collapses to icon-only
// under a width threshold (CSS). ARIA radiogroup so it announces as one control
// with four mutually-exclusive options — with the full APG Radio Group keyboard
// contract (roving tabindex + arrow keys) via `useRadiogroupNav`.
const OPTIONS = [{
  value: "tree",
  label: "Tree",
  tip: "Tree view",
  Icon: _lucideReact.FolderTree
}, {
  value: "list",
  label: "List",
  tip: "List view",
  Icon: _lucideReact.List
}, {
  value: "columns",
  label: "Columns",
  tip: "Column view",
  Icon: _lucideReact.Columns3
}, {
  value: "icons",
  label: "Icons",
  tip: "Icon view",
  Icon: _lucideReact.LayoutGrid
}];
function LayoutSwitcher({
  value,
  onChange
}) {
  _s();
  const {
    ref,
    onKeyDown
  } = (0, _useRadiogroupNav.useRadiogroupNav)(OPTIONS.map(o => o.value), value, onChange);
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    ref: ref,
    className: "viewswitch",
    role: "radiogroup",
    "aria-label": "Layout",
    onKeyDown: onKeyDown,
    children: OPTIONS.map(({
      value: v,
      label,
      tip,
      Icon
    }) => {
      const active = v === value;
      return /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
        type: "button",
        role: "radio",
        "aria-checked": active,
        tabIndex: active ? 0 : -1,
        className: "viewswitch__btn" + (active ? " viewswitch__btn--active" : ""),
        title: tip,
        "aria-label": tip,
        onClick: () => onChange(v),
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(Icon, {
          size: 15,
          "aria-hidden": "true"
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "viewswitch__label",
          children: label
        })]
      }, v);
    })
  });
}
_s(LayoutSwitcher, "j+gNN3KwaQoaiWtxQ+lkKdwZEBg=", false, function () {
  return [_useRadiogroupNav.useRadiogroupNav];
});
_c = LayoutSwitcher;
var _default = exports.default = LayoutSwitcher;
var _c;
$RefreshReg$(_c, "LayoutSwitcher");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfbHVjaWRlUmVhY3QiLCJyZXF1aXJlIiwiX3VzZVJhZGlvZ3JvdXBOYXYiLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiT1BUSU9OUyIsInZhbHVlIiwibGFiZWwiLCJ0aXAiLCJJY29uIiwiRm9sZGVyVHJlZSIsIkxpc3RJY29uIiwiQ29sdW1uczMiLCJMYXlvdXRHcmlkIiwiTGF5b3V0U3dpdGNoZXIiLCJvbkNoYW5nZSIsInJlZiIsIm9uS2V5RG93biIsInVzZVJhZGlvZ3JvdXBOYXYiLCJtYXAiLCJvIiwianN4IiwiY2xhc3NOYW1lIiwicm9sZSIsImNoaWxkcmVuIiwidiIsImFjdGl2ZSIsImpzeHMiLCJ0eXBlIiwidGFiSW5kZXgiLCJ0aXRsZSIsIm9uQ2xpY2siLCJzaXplIiwiX2MiLCJfZGVmYXVsdCIsImV4cG9ydHMiLCJkZWZhdWx0IiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiTGF5b3V0U3dpdGNoZXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIFRoZSB2aWV3IHN3aXRjaGVyIChSMy04NCwgZGVzaWduIGJyaWVmIDEzIMKnMSk6IGEgY29tcGFjdCBzZWdtZW50ZWQgY29udHJvbCBpblxuLy8gdGhlIHBhbmVsIGhlYWRlciB0aGF0IHN3YXBzIHRoZSBleHBsb3JlciBiZXR3ZWVuIHRyZWUgLyBsaXN0IC8gY29sdW1ucyAvIGljb25zLlxuLy8gQXBwLWxvY2FsIHZpZXcgc3RhdGUgb25seS4gTHVjaWRlIGljb25zIChubyBlbW9qaSk7IHNlbnRlbmNlLWNhc2UgdG9vbHRpcHM7IHRoZVxuLy8gbGFiZWwgc2l0cyBiZXNpZGUgdGhlIGljb24gd2hlbiB0aGUgaGVhZGVyIGlzIHdpZGUgYW5kIGNvbGxhcHNlcyB0byBpY29uLW9ubHlcbi8vIHVuZGVyIGEgd2lkdGggdGhyZXNob2xkIChDU1MpLiBBUklBIHJhZGlvZ3JvdXAgc28gaXQgYW5ub3VuY2VzIGFzIG9uZSBjb250cm9sXG4vLyB3aXRoIGZvdXIgbXV0dWFsbHktZXhjbHVzaXZlIG9wdGlvbnMg4oCUIHdpdGggdGhlIGZ1bGwgQVBHIFJhZGlvIEdyb3VwIGtleWJvYXJkXG4vLyBjb250cmFjdCAocm92aW5nIHRhYmluZGV4ICsgYXJyb3cga2V5cykgdmlhIGB1c2VSYWRpb2dyb3VwTmF2YC5cbmltcG9ydCB7IEZvbGRlclRyZWUsIExpc3QgYXMgTGlzdEljb24sIENvbHVtbnMzLCBMYXlvdXRHcmlkLCB0eXBlIEx1Y2lkZUljb24gfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQgeyB1c2VSYWRpb2dyb3VwTmF2IH0gZnJvbSBcIi4vaG9va3MvdXNlUmFkaW9ncm91cE5hdlwiO1xuaW1wb3J0IHR5cGUgeyBMYXlvdXQgfSBmcm9tIFwiLi90eXBlc1wiO1xuXG5jb25zdCBPUFRJT05TOiB7IHZhbHVlOiBMYXlvdXQ7IGxhYmVsOiBzdHJpbmc7IHRpcDogc3RyaW5nOyBJY29uOiBMdWNpZGVJY29uIH1bXSA9IFtcbiAgeyB2YWx1ZTogXCJ0cmVlXCIsIGxhYmVsOiBcIlRyZWVcIiwgdGlwOiBcIlRyZWUgdmlld1wiLCBJY29uOiBGb2xkZXJUcmVlIH0sXG4gIHsgdmFsdWU6IFwibGlzdFwiLCBsYWJlbDogXCJMaXN0XCIsIHRpcDogXCJMaXN0IHZpZXdcIiwgSWNvbjogTGlzdEljb24gfSxcbiAgeyB2YWx1ZTogXCJjb2x1bW5zXCIsIGxhYmVsOiBcIkNvbHVtbnNcIiwgdGlwOiBcIkNvbHVtbiB2aWV3XCIsIEljb246IENvbHVtbnMzIH0sXG4gIHsgdmFsdWU6IFwiaWNvbnNcIiwgbGFiZWw6IFwiSWNvbnNcIiwgdGlwOiBcIkljb24gdmlld1wiLCBJY29uOiBMYXlvdXRHcmlkIH0sXG5dO1xuXG5mdW5jdGlvbiBMYXlvdXRTd2l0Y2hlcih7XG4gIHZhbHVlLFxuICBvbkNoYW5nZSxcbn06IHtcbiAgdmFsdWU6IExheW91dDtcbiAgb25DaGFuZ2U6IChuZXh0OiBMYXlvdXQpID0+IHZvaWQ7XG59KSB7XG4gIGNvbnN0IHsgcmVmLCBvbktleURvd24gfSA9IHVzZVJhZGlvZ3JvdXBOYXYoXG4gICAgT1BUSU9OUy5tYXAoKG8pID0+IG8udmFsdWUpLFxuICAgIHZhbHVlLFxuICAgIG9uQ2hhbmdlLFxuICApO1xuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIHJlZj17cmVmfVxuICAgICAgY2xhc3NOYW1lPVwidmlld3N3aXRjaFwiXG4gICAgICByb2xlPVwicmFkaW9ncm91cFwiXG4gICAgICBhcmlhLWxhYmVsPVwiTGF5b3V0XCJcbiAgICAgIG9uS2V5RG93bj17b25LZXlEb3dufVxuICAgID5cbiAgICAgIHtPUFRJT05TLm1hcCgoeyB2YWx1ZTogdiwgbGFiZWwsIHRpcCwgSWNvbiB9KSA9PiB7XG4gICAgICAgIGNvbnN0IGFjdGl2ZSA9IHYgPT09IHZhbHVlO1xuICAgICAgICByZXR1cm4gKFxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIGtleT17dn1cbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgcm9sZT1cInJhZGlvXCJcbiAgICAgICAgICAgIGFyaWEtY2hlY2tlZD17YWN0aXZlfVxuICAgICAgICAgICAgdGFiSW5kZXg9e2FjdGl2ZSA/IDAgOiAtMX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT17XCJ2aWV3c3dpdGNoX19idG5cIiArIChhY3RpdmUgPyBcIiB2aWV3c3dpdGNoX19idG4tLWFjdGl2ZVwiIDogXCJcIil9XG4gICAgICAgICAgICB0aXRsZT17dGlwfVxuICAgICAgICAgICAgYXJpYS1sYWJlbD17dGlwfVxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25DaGFuZ2Uodil9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPEljb24gc2l6ZT17MTV9IGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ2aWV3c3dpdGNoX19sYWJlbFwiPntsYWJlbH08L3NwYW4+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICk7XG4gICAgICB9KX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgTGF5b3V0U3dpdGNoZXI7XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQU9BLElBQUFBLFlBQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLGlCQUFBLEdBQUFELE9BQUE7QUFBNEQsSUFBQUUsV0FBQSxHQUFBRixPQUFBO0FBQUEsSUFBQUcsRUFBQSxHQUFBQyxZQUFBLElBUjVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBS0EsTUFBTUMsT0FBMEUsR0FBRyxDQUNqRjtFQUFFQyxLQUFLLEVBQUUsTUFBTTtFQUFFQyxLQUFLLEVBQUUsTUFBTTtFQUFFQyxHQUFHLEVBQUUsV0FBVztFQUFFQyxJQUFJLEVBQUVDO0FBQVcsQ0FBQyxFQUNwRTtFQUFFSixLQUFLLEVBQUUsTUFBTTtFQUFFQyxLQUFLLEVBQUUsTUFBTTtFQUFFQyxHQUFHLEVBQUUsV0FBVztFQUFFQyxJQUFJLEVBQUVFO0FBQVMsQ0FBQyxFQUNsRTtFQUFFTCxLQUFLLEVBQUUsU0FBUztFQUFFQyxLQUFLLEVBQUUsU0FBUztFQUFFQyxHQUFHLEVBQUUsYUFBYTtFQUFFQyxJQUFJLEVBQUVHO0FBQVMsQ0FBQyxFQUMxRTtFQUFFTixLQUFLLEVBQUUsT0FBTztFQUFFQyxLQUFLLEVBQUUsT0FBTztFQUFFQyxHQUFHLEVBQUUsV0FBVztFQUFFQyxJQUFJLEVBQUVJO0FBQVcsQ0FBQyxDQUN2RTtBQUVELFNBQVNDLGNBQWNBLENBQUM7RUFDdEJSLEtBQUs7RUFDTFM7QUFJRixDQUFDLEVBQUU7RUFBQVosRUFBQTtFQUNELE1BQU07SUFBRWEsR0FBRztJQUFFQztFQUFVLENBQUMsR0FBRyxJQUFBQyxrQ0FBZ0IsRUFDekNiLE9BQU8sQ0FBQ2MsR0FBRyxDQUFFQyxDQUFDLElBQUtBLENBQUMsQ0FBQ2QsS0FBSyxDQUFDLEVBQzNCQSxLQUFLLEVBQ0xTLFFBQ0YsQ0FBQztFQUNELG9CQUNFLElBQUFiLFdBQUEsQ0FBQW1CLEdBQUE7SUFDRUwsR0FBRyxFQUFFQSxHQUFJO0lBQ1RNLFNBQVMsRUFBQyxZQUFZO0lBQ3RCQyxJQUFJLEVBQUMsWUFBWTtJQUNqQixjQUFXLFFBQVE7SUFDbkJOLFNBQVMsRUFBRUEsU0FBVTtJQUFBTyxRQUFBLEVBRXBCbkIsT0FBTyxDQUFDYyxHQUFHLENBQUMsQ0FBQztNQUFFYixLQUFLLEVBQUVtQixDQUFDO01BQUVsQixLQUFLO01BQUVDLEdBQUc7TUFBRUM7SUFBSyxDQUFDLEtBQUs7TUFDL0MsTUFBTWlCLE1BQU0sR0FBR0QsQ0FBQyxLQUFLbkIsS0FBSztNQUMxQixvQkFDRSxJQUFBSixXQUFBLENBQUF5QixJQUFBO1FBRUVDLElBQUksRUFBQyxRQUFRO1FBQ2JMLElBQUksRUFBQyxPQUFPO1FBQ1osZ0JBQWNHLE1BQU87UUFDckJHLFFBQVEsRUFBRUgsTUFBTSxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUU7UUFDMUJKLFNBQVMsRUFBRSxpQkFBaUIsSUFBSUksTUFBTSxHQUFHLDBCQUEwQixHQUFHLEVBQUUsQ0FBRTtRQUMxRUksS0FBSyxFQUFFdEIsR0FBSTtRQUNYLGNBQVlBLEdBQUk7UUFDaEJ1QixPQUFPLEVBQUVBLENBQUEsS0FBTWhCLFFBQVEsQ0FBQ1UsQ0FBQyxDQUFFO1FBQUFELFFBQUEsZ0JBRTNCLElBQUF0QixXQUFBLENBQUFtQixHQUFBLEVBQUNaLElBQUk7VUFBQ3VCLElBQUksRUFBRSxFQUFHO1VBQUMsZUFBWTtRQUFNLENBQUUsQ0FBQyxlQUNyQyxJQUFBOUIsV0FBQSxDQUFBbUIsR0FBQTtVQUFNQyxTQUFTLEVBQUMsbUJBQW1CO1VBQUFFLFFBQUEsRUFBRWpCO1FBQUssQ0FBTyxDQUFDO01BQUEsR0FYN0NrQixDQVlDLENBQUM7SUFFYixDQUFDO0VBQUMsQ0FDQyxDQUFDO0FBRVY7QUFBQ3RCLEVBQUEsQ0F6Q1FXLGNBQWM7RUFBQSxRQU9NSSxrQ0FBZ0I7QUFBQTtBQUFBZSxFQUFBLEdBUHBDbkIsY0FBYztBQUFBLElBQUFvQixRQUFBLEdBQUFDLE9BQUEsQ0FBQUMsT0FBQSxHQTJDUnRCLGNBQWM7QUFBQSxJQUFBbUIsRUFBQTtBQUFBSSxZQUFBLENBQUFKLEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}