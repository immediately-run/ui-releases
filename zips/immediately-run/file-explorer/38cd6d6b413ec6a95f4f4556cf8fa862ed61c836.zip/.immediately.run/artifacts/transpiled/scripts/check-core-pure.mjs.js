var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

var _nodeFs = require("node:fs");
var _nodePath = require("node:path");
// Purity guard (00-overview §5; Phase 01 step 6): the headless core under
// `src/lib-ui/` must NOT depend on `@immediately-run/sdk`. Only the SDK adapter
// under `src/lib-ui/sdk/` may import it. Run via `npm run check:core`; wire into
// CI alongside lint/build.
//
// Fails (exit 1) if any file under src/lib-ui EXCEPT src/lib-ui/sdk imports
// `@immediately-run/sdk`.

// npm runs scripts from the package root, so cwd is the repo root. (Uses cwd
// rather than a module-URL token, which the immediately.run CommonJS transpile
// parse-errors on — that token is kept out of the repo entirely.)
const ROOT = process.cwd();
const CORE_DIR = (0, _nodePath.join)(ROOT, "src", "lib-ui");
_c = CORE_DIR;
const ADAPTER_DIR = (0, _nodePath.join)(CORE_DIR, "sdk");
_c2 = ADAPTER_DIR;
const NEEDLE = "@immediately-run/sdk";
// Match a real module reference (import/from/require/vi.mock), not a comment
// that merely names the package.
//
// The optional `/…` tail matters and was missing until R3-653: the package's exports map
// is `{".": …, "./*": …}`, and this repo's own adapter reaches for a SUBPATH —
// `src/lib-ui/sdk/SdkFileExplorer.tsx:20` imports `@immediately-run/sdk/sandboxUtils`. A
// pattern anchored on a closing quote right after `sdk` therefore refused only the bare
// specifier, so a core file importing `@immediately-run/sdk/fs` passed this check green.
// Nothing under `src/lib-ui/` outside `sdk/` used the subpath form when this was widened,
// so the widening changed no verdict — it closed a door nobody had walked through yet.
const IMPORT_RE = /(?:from|import|require|vi\.mock)\s*\(?\s*["']@immediately-run\/sdk(?:\/[^"']*)?["']/;

/** All .ts/.tsx files under a dir, recursively. */
function walk(dir) {
  const out = [];
  for (const name of (0, _nodeFs.readdirSync)(dir)) {
    const p = (0, _nodePath.join)(dir, name);
    if ((0, _nodeFs.statSync)(p).isDirectory()) out.push(...walk(p));else if (/\.(ts|tsx)$/.test(name)) out.push(p);
  }
  return out;
}
const offenders = [];
for (const file of walk(CORE_DIR)) {
  // The SDK adapter is allowed to import the SDK.
  if (file === ADAPTER_DIR || file.startsWith(ADAPTER_DIR + _nodePath.sep)) continue;
  const src = (0, _nodeFs.readFileSync)(file, "utf8");
  if (IMPORT_RE.test(src)) offenders.push((0, _nodePath.relative)(ROOT, file));
}
if (offenders.length) {
  console.error(`check:core FAILED — the headless core must not import ${NEEDLE}.\n` + `Move the SDK-coupled code into src/lib-ui/sdk/. Offenders:\n` + offenders.map(f => `  - ${f}`).join("\n"));
  process.exit(1);
}
console.log(`check:core OK — no ${NEEDLE} imports outside src/lib-ui/sdk/.`);
var _c, _c2;
$RefreshReg$(_c, "CORE_DIR");
$RefreshReg$(_c2, "ADAPTER_DIR");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfbm9kZUZzIiwicmVxdWlyZSIsIl9ub2RlUGF0aCIsIlJPT1QiLCJwcm9jZXNzIiwiY3dkIiwiQ09SRV9ESVIiLCJqb2luIiwiX2MiLCJBREFQVEVSX0RJUiIsIl9jMiIsIk5FRURMRSIsIklNUE9SVF9SRSIsIndhbGsiLCJkaXIiLCJvdXQiLCJuYW1lIiwicmVhZGRpclN5bmMiLCJwIiwic3RhdFN5bmMiLCJpc0RpcmVjdG9yeSIsInB1c2giLCJ0ZXN0Iiwib2ZmZW5kZXJzIiwiZmlsZSIsInN0YXJ0c1dpdGgiLCJzZXAiLCJzcmMiLCJyZWFkRmlsZVN5bmMiLCJyZWxhdGl2ZSIsImxlbmd0aCIsImNvbnNvbGUiLCJlcnJvciIsIm1hcCIsImYiLCJleGl0IiwibG9nIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiY2hlY2stY29yZS1wdXJlLm1qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBQdXJpdHkgZ3VhcmQgKDAwLW92ZXJ2aWV3IMKnNTsgUGhhc2UgMDEgc3RlcCA2KTogdGhlIGhlYWRsZXNzIGNvcmUgdW5kZXJcbi8vIGBzcmMvbGliLXVpL2AgbXVzdCBOT1QgZGVwZW5kIG9uIGBAaW1tZWRpYXRlbHktcnVuL3Nka2AuIE9ubHkgdGhlIFNESyBhZGFwdGVyXG4vLyB1bmRlciBgc3JjL2xpYi11aS9zZGsvYCBtYXkgaW1wb3J0IGl0LiBSdW4gdmlhIGBucG0gcnVuIGNoZWNrOmNvcmVgOyB3aXJlIGludG9cbi8vIENJIGFsb25nc2lkZSBsaW50L2J1aWxkLlxuLy9cbi8vIEZhaWxzIChleGl0IDEpIGlmIGFueSBmaWxlIHVuZGVyIHNyYy9saWItdWkgRVhDRVBUIHNyYy9saWItdWkvc2RrIGltcG9ydHNcbi8vIGBAaW1tZWRpYXRlbHktcnVuL3Nka2AuXG5pbXBvcnQgeyByZWFkZGlyU3luYywgcmVhZEZpbGVTeW5jLCBzdGF0U3luYyB9IGZyb20gXCJub2RlOmZzXCI7XG5pbXBvcnQgeyBqb2luLCByZWxhdGl2ZSwgc2VwIH0gZnJvbSBcIm5vZGU6cGF0aFwiO1xuXG4vLyBucG0gcnVucyBzY3JpcHRzIGZyb20gdGhlIHBhY2thZ2Ugcm9vdCwgc28gY3dkIGlzIHRoZSByZXBvIHJvb3QuIChVc2VzIGN3ZFxuLy8gcmF0aGVyIHRoYW4gYSBtb2R1bGUtVVJMIHRva2VuLCB3aGljaCB0aGUgaW1tZWRpYXRlbHkucnVuIENvbW1vbkpTIHRyYW5zcGlsZVxuLy8gcGFyc2UtZXJyb3JzIG9uIOKAlCB0aGF0IHRva2VuIGlzIGtlcHQgb3V0IG9mIHRoZSByZXBvIGVudGlyZWx5LilcbmNvbnN0IFJPT1QgPSBwcm9jZXNzLmN3ZCgpO1xuY29uc3QgQ09SRV9ESVIgPSBqb2luKFJPT1QsIFwic3JjXCIsIFwibGliLXVpXCIpO1xuY29uc3QgQURBUFRFUl9ESVIgPSBqb2luKENPUkVfRElSLCBcInNka1wiKTtcbmNvbnN0IE5FRURMRSA9IFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGtcIjtcbi8vIE1hdGNoIGEgcmVhbCBtb2R1bGUgcmVmZXJlbmNlIChpbXBvcnQvZnJvbS9yZXF1aXJlL3ZpLm1vY2spLCBub3QgYSBjb21tZW50XG4vLyB0aGF0IG1lcmVseSBuYW1lcyB0aGUgcGFja2FnZS5cbi8vXG4vLyBUaGUgb3B0aW9uYWwgYC/igKZgIHRhaWwgbWF0dGVycyBhbmQgd2FzIG1pc3NpbmcgdW50aWwgUjMtNjUzOiB0aGUgcGFja2FnZSdzIGV4cG9ydHMgbWFwXG4vLyBpcyBge1wiLlwiOiDigKYsIFwiLi8qXCI6IOKApn1gLCBhbmQgdGhpcyByZXBvJ3Mgb3duIGFkYXB0ZXIgcmVhY2hlcyBmb3IgYSBTVUJQQVRIIOKAlFxuLy8gYHNyYy9saWItdWkvc2RrL1Nka0ZpbGVFeHBsb3Jlci50c3g6MjBgIGltcG9ydHMgYEBpbW1lZGlhdGVseS1ydW4vc2RrL3NhbmRib3hVdGlsc2AuIEFcbi8vIHBhdHRlcm4gYW5jaG9yZWQgb24gYSBjbG9zaW5nIHF1b3RlIHJpZ2h0IGFmdGVyIGBzZGtgIHRoZXJlZm9yZSByZWZ1c2VkIG9ubHkgdGhlIGJhcmVcbi8vIHNwZWNpZmllciwgc28gYSBjb3JlIGZpbGUgaW1wb3J0aW5nIGBAaW1tZWRpYXRlbHktcnVuL3Nkay9mc2AgcGFzc2VkIHRoaXMgY2hlY2sgZ3JlZW4uXG4vLyBOb3RoaW5nIHVuZGVyIGBzcmMvbGliLXVpL2Agb3V0c2lkZSBgc2RrL2AgdXNlZCB0aGUgc3VicGF0aCBmb3JtIHdoZW4gdGhpcyB3YXMgd2lkZW5lZCxcbi8vIHNvIHRoZSB3aWRlbmluZyBjaGFuZ2VkIG5vIHZlcmRpY3Qg4oCUIGl0IGNsb3NlZCBhIGRvb3Igbm9ib2R5IGhhZCB3YWxrZWQgdGhyb3VnaCB5ZXQuXG5jb25zdCBJTVBPUlRfUkUgPSAvKD86ZnJvbXxpbXBvcnR8cmVxdWlyZXx2aVxcLm1vY2spXFxzKlxcKD9cXHMqW1wiJ11AaW1tZWRpYXRlbHktcnVuXFwvc2RrKD86XFwvW15cIiddKik/W1wiJ10vO1xuXG4vKiogQWxsIC50cy8udHN4IGZpbGVzIHVuZGVyIGEgZGlyLCByZWN1cnNpdmVseS4gKi9cbmZ1bmN0aW9uIHdhbGsoZGlyKSB7XG4gIGNvbnN0IG91dCA9IFtdO1xuICBmb3IgKGNvbnN0IG5hbWUgb2YgcmVhZGRpclN5bmMoZGlyKSkge1xuICAgIGNvbnN0IHAgPSBqb2luKGRpciwgbmFtZSk7XG4gICAgaWYgKHN0YXRTeW5jKHApLmlzRGlyZWN0b3J5KCkpIG91dC5wdXNoKC4uLndhbGsocCkpO1xuICAgIGVsc2UgaWYgKC9cXC4odHN8dHN4KSQvLnRlc3QobmFtZSkpIG91dC5wdXNoKHApO1xuICB9XG4gIHJldHVybiBvdXQ7XG59XG5cbmNvbnN0IG9mZmVuZGVycyA9IFtdO1xuZm9yIChjb25zdCBmaWxlIG9mIHdhbGsoQ09SRV9ESVIpKSB7XG4gIC8vIFRoZSBTREsgYWRhcHRlciBpcyBhbGxvd2VkIHRvIGltcG9ydCB0aGUgU0RLLlxuICBpZiAoZmlsZSA9PT0gQURBUFRFUl9ESVIgfHwgZmlsZS5zdGFydHNXaXRoKEFEQVBURVJfRElSICsgc2VwKSkgY29udGludWU7XG4gIGNvbnN0IHNyYyA9IHJlYWRGaWxlU3luYyhmaWxlLCBcInV0ZjhcIik7XG4gIGlmIChJTVBPUlRfUkUudGVzdChzcmMpKSBvZmZlbmRlcnMucHVzaChyZWxhdGl2ZShST09ULCBmaWxlKSk7XG59XG5cbmlmIChvZmZlbmRlcnMubGVuZ3RoKSB7XG4gIGNvbnNvbGUuZXJyb3IoXG4gICAgYGNoZWNrOmNvcmUgRkFJTEVEIOKAlCB0aGUgaGVhZGxlc3MgY29yZSBtdXN0IG5vdCBpbXBvcnQgJHtORUVETEV9LlxcbmAgK1xuICAgICAgYE1vdmUgdGhlIFNESy1jb3VwbGVkIGNvZGUgaW50byBzcmMvbGliLXVpL3Nkay8uIE9mZmVuZGVyczpcXG5gICtcbiAgICAgIG9mZmVuZGVycy5tYXAoKGYpID0+IGAgIC0gJHtmfWApLmpvaW4oXCJcXG5cIiksXG4gICk7XG4gIHByb2Nlc3MuZXhpdCgxKTtcbn1cblxuY29uc29sZS5sb2coYGNoZWNrOmNvcmUgT0sg4oCUIG5vICR7TkVFRExFfSBpbXBvcnRzIG91dHNpZGUgc3JjL2xpYi11aS9zZGsvLmApO1xuIl0sIm1hcHBpbmdzIjoiOztBQU9BLElBQUFBLE9BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLFNBQUEsR0FBQUQsT0FBQTtBQVJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUlBO0FBQ0E7QUFDQTtBQUNBLE1BQU1FLElBQUksR0FBR0MsT0FBTyxDQUFDQyxHQUFHLENBQUMsQ0FBQztBQUMxQixNQUFNQyxRQUFRLEdBQUcsSUFBQUMsY0FBSSxFQUFDSixJQUFJLEVBQUUsS0FBSyxFQUFFLFFBQVEsQ0FBQztBQUFDSyxFQUFBLEdBQXZDRixRQUFRO0FBQ2QsTUFBTUcsV0FBVyxHQUFHLElBQUFGLGNBQUksRUFBQ0QsUUFBUSxFQUFFLEtBQUssQ0FBQztBQUFDSSxHQUFBLEdBQXBDRCxXQUFXO0FBQ2pCLE1BQU1FLE1BQU0sR0FBRyxzQkFBc0I7QUFDckM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNQyxTQUFTLEdBQUcscUZBQXFGOztBQUV2RztBQUNBLFNBQVNDLElBQUlBLENBQUNDLEdBQUcsRUFBRTtFQUNqQixNQUFNQyxHQUFHLEdBQUcsRUFBRTtFQUNkLEtBQUssTUFBTUMsSUFBSSxJQUFJLElBQUFDLG1CQUFXLEVBQUNILEdBQUcsQ0FBQyxFQUFFO0lBQ25DLE1BQU1JLENBQUMsR0FBRyxJQUFBWCxjQUFJLEVBQUNPLEdBQUcsRUFBRUUsSUFBSSxDQUFDO0lBQ3pCLElBQUksSUFBQUcsZ0JBQVEsRUFBQ0QsQ0FBQyxDQUFDLENBQUNFLFdBQVcsQ0FBQyxDQUFDLEVBQUVMLEdBQUcsQ0FBQ00sSUFBSSxDQUFDLEdBQUdSLElBQUksQ0FBQ0ssQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUMvQyxJQUFJLGFBQWEsQ0FBQ0ksSUFBSSxDQUFDTixJQUFJLENBQUMsRUFBRUQsR0FBRyxDQUFDTSxJQUFJLENBQUNILENBQUMsQ0FBQztFQUNoRDtFQUNBLE9BQU9ILEdBQUc7QUFDWjtBQUVBLE1BQU1RLFNBQVMsR0FBRyxFQUFFO0FBQ3BCLEtBQUssTUFBTUMsSUFBSSxJQUFJWCxJQUFJLENBQUNQLFFBQVEsQ0FBQyxFQUFFO0VBQ2pDO0VBQ0EsSUFBSWtCLElBQUksS0FBS2YsV0FBVyxJQUFJZSxJQUFJLENBQUNDLFVBQVUsQ0FBQ2hCLFdBQVcsR0FBR2lCLGFBQUcsQ0FBQyxFQUFFO0VBQ2hFLE1BQU1DLEdBQUcsR0FBRyxJQUFBQyxvQkFBWSxFQUFDSixJQUFJLEVBQUUsTUFBTSxDQUFDO0VBQ3RDLElBQUlaLFNBQVMsQ0FBQ1UsSUFBSSxDQUFDSyxHQUFHLENBQUMsRUFBRUosU0FBUyxDQUFDRixJQUFJLENBQUMsSUFBQVEsa0JBQVEsRUFBQzFCLElBQUksRUFBRXFCLElBQUksQ0FBQyxDQUFDO0FBQy9EO0FBRUEsSUFBSUQsU0FBUyxDQUFDTyxNQUFNLEVBQUU7RUFDcEJDLE9BQU8sQ0FBQ0MsS0FBSyxDQUNYLHlEQUF5RHJCLE1BQU0sS0FBSyxHQUNsRSw4REFBOEQsR0FDOURZLFNBQVMsQ0FBQ1UsR0FBRyxDQUFFQyxDQUFDLElBQUssT0FBT0EsQ0FBQyxFQUFFLENBQUMsQ0FBQzNCLElBQUksQ0FBQyxJQUFJLENBQzlDLENBQUM7RUFDREgsT0FBTyxDQUFDK0IsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUNqQjtBQUVBSixPQUFPLENBQUNLLEdBQUcsQ0FBQyxzQkFBc0J6QixNQUFNLG1DQUFtQyxDQUFDO0FBQUMsSUFBQUgsRUFBQSxFQUFBRSxHQUFBO0FBQUEyQixZQUFBLENBQUE3QixFQUFBO0FBQUE2QixZQUFBLENBQUEzQixHQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}