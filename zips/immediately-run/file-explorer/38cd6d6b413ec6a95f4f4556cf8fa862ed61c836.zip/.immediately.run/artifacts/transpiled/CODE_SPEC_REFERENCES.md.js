var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      blockquote: "blockquote",
      code: "code",
      del: "del",
      em: "em",
      h1: "h1",
      h2: "h2",
      hr: "hr",
      li: "li",
      p: "p",
      strong: "strong",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "code_spec_references-file-explorer",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "code_spec_references-file-explorer"
      }), "CODE_SPEC_REFERENCES — file-explorer"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Durable index of ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "non-trivial"
      }), " code↔spec mappings a reader wouldn't rediscover\nquickly. Trivial mappings live as inline ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "// <SPEC> §X"
      }), " comments. Seeded by the\n2026-06 code-verification pass (R3-124; plan ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "08-system-apps.md"
      }), ")."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "the-write-intent-indirection-the-load-bearing-one",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-write-intent-indirection-the-load-bearing-one"
      }), "The write-intent indirection (the load-bearing one)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Spec:"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "FILE_EXPLORER_SPEC §4"
      }), " (write actions) + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "UI_AS_APPS_SPEC §4"
      }), " (one app,\ntwo slots / host-gated intents) + the host's copy-on-write layer."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Mapping:"
      }), " the app holds ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "no write port"
      }), ". Create / rename / delete / upload /\nmove are ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "not"
      }), " direct filesystem writes — the app ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "names a path"
      }), " and the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "host"
      }), "\nperforms the copy-on-write write behind the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "editor:write"
      }), " intent. The COW/journal\nlives in the host (core_concepts §2), never in this app. This is why the affordances\nappear only on a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "writable"
      }), " mount (v1: the worktree) and never surface ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "EROFS"
      }), " as\nUX — the host adjudicates writability, the app reflects it."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/lib-ui/sdk/actions.ts"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "makeSdkActions"
        }), ") — the §4 ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "editor:open"
        }), " /\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "editor:write"
        }), " intent indirection. (The headless ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/lib-ui/FileExplorerView.tsx"
        }), "\nonly NAMES the path through injected ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "actions"
        }), "; the SDK calls live in the adapter.)"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["SDK calls ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "deleteEntry"
        }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "renameEntry"
        }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "uploadFile"
        }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "createFile"
        }), " (in\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/lib-ui/sdk/actions.ts"
        }), ") are host-gated intents, not local writes."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "the-llmchat1-summarize-fork-feature",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-llmchat1-summarize-fork-feature"
      }), "The ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "llm.chat@1"
      }), " \"Summarize\" fork feature"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Spec:"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "SERVICE_PROVIDERS_SPEC"
      }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "llm:chat"
      }), " capability) + the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "llm.chat@1"
      }), " service\nslot. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ui:overlay"
      }), " self-overlay is the richer follow-up (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "SERVICE_PROVIDERS_SPEC §6.3"
      }), ",\nproposed) — today the modal is drawn in-iframe."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Mapping:"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/lib-ui/sdk/SummaryModal.tsx"
      }), " calls ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "chat()"
      }), " (needs only the\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "llm:chat"
      }), " capability the fork consented), streams the summary, and can save it next\nto the source file (gated on a writable mount). The \"provider-agnostic LLM\" wording\nmeans the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "LLM service provider"
      }), " (Anthropic/OpenAI), core_concepts §6 sense — not\nthe app-identity source host."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "multi-root-tree-store",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "multi-root-tree-store"
      }), "Multi-root tree store"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Spec:"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "FILE_EXPLORER_SPEC §2"
      }), " (multiple mounts) — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/lib-ui/treeStore.ts"
      }), "\nkeeps one scope-headed tree per root (worktree + spaces + granted subtrees). It\nreads entries through an injected ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "FsSource"
      }), " (the SDK adapter's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "sdkFsSource"
      }), "), so\nthe store is pure of any concrete fs."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "the-5-upload-buttons-selection-derived-destination",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-5-upload-buttons-selection-derived-destination"
      }), "The §5 upload button's selection-derived destination"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Spec:"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "FILE_EXPLORER_SPEC §5"
      }), " (amended 2026-09-14 — the picker path)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Mapping:"
      }), " the header Upload button in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/lib-ui/FileExplorerView.tsx"
      }), " reuses\nthe ONE hidden ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "<input type=\"file\" multiple>"
      }), " the §3 \"Upload here…\" menu item\nopens (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "uploadTargetRef"
      }), " + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "onUploadInput"
      }), "), so both ingestion paths share the\nupload write flow. The destination cannot be pointed at (a drop can), so it is\nderived from the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "selection"
      }), " — which is why ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "TreeStore.select"
      }), " now records the\nrow's KIND (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "select(path, isDir)"
      }), ", read via ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "getSelectedRow()"
      }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "useSelectedRow"
      }), ")\nand why directory activation/navigation selects the entered folder in every\nlayout (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "handleActivate"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "navigateCwd"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "navigateCols"
      }), "). The dir/file/none →\ndir/parent/repo-root resolution itself is the pure ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "uploadTargetDir"
      }), "\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/lib-ui/explorer.ts"
      }), "), shared with the drag-drop target computation; the\nwritable-root fallback (read-only selection → repo root; no writable scope → the\nbutton hides) lives in the view beside ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "uploadRoot"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "recorded-findings-code-verification-pass-2026-06",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "recorded-findings-code-verification-pass-2026-06"
      }), "Recorded findings (code-verification pass, 2026-06)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "CLOSED, verified on 2026-09-16 (R3-653)."
        }), " The two SDK entries below — ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.em, {
          children: ["DONE-BUT-DIVERGENT\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "chat"
          }), " not exported)"]
        }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "SDK-version skew"
        }), " — are stale and are kept as the record rather\nthan deleted; the third bullet, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Comment vocab fixes applied"
        }), ", is untouched by this note.\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "package.json"
        }), " now pins ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "@immediately-run/sdk"
        }), " at ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "^0.43.0"
        }), ", the installed\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "dist/index.d.ts:24"
        }), " exports ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "chat"
        }), ", and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npm run build"
        }), " exits 0 on this PR's head — a\nbranch whose only source change is the CI workflow (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "git diff origin/main...HEAD --stat"
        }), "\nis three files: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".github/workflows/ci.yml"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "package.json"
        }), "'s ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "lint"
        }), " script, and this file).\nSo the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "TS2305"
        }), " failure is gone and the \"newest among the bound apps at 0.11.0\" skew\nreading is obsolete. Found while adding CI to this repo: the PR asserted the build passes\non ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "main"
        }), ", which is the direct negation of the first entry, so leaving it open would have\nbeen a claim this repo's own gate contradicts."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "[CLOSED 2026-09-16]"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.del, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
            children: ["DONE-BUT-DIVERGENT (CRIT, pre-existing on origin/main) —\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "chat"
            }), " not exported by the pinned SDK."]
          })
        }), " The shipped \"Summarize\" feature (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/lib-ui/sdk/SummaryModal.tsx:2"
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "import { chat } from \"@immediately-run/sdk\""
        }), ", added in PR #9) does ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "not"
        }), "\ntype-check against the repo's own pinned ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "@immediately-run/sdk@0.11.0"
        }), ", which has\nno ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "chat"
        }), " export → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npm run build"
        }), " fails with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "TS2305"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "on a clean origin/main\ncheckout"
        }), " (verified by stashing this pass's comment-only edits and rebuilding).\nThis is a real Done-but-divergent gap: the feature shipped against a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "chat"
        }), "/\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "llm.chat@1"
        }), " SDK surface newer than the pinned version (an instance of the\nSDK-version skew below). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Not introduced by this pass"
        }), " — this pass made only\ncomment-level edits (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "kernel"
        }), "→", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "host"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "PR #84 §6.3"
        }), "→", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "SERVICE_PROVIDERS_SPEC §6.3"
        }), ")\nand seeded this file; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npm run lint"
        }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npm test"
        }), " (36 tests) are green. Fix is a\ncoordinated SDK bump to a version exporting ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "chat"
        }), " (out of scope for this\nverify/record pass — filed as a roadmap child of R3-124)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "[CLOSED 2026-09-16]"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.del, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "SDK-version skew (record only, do not bump):"
          })
        }), " file-explorer pins\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "@immediately-run/sdk"
        }), " at ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "0.11.0"
          })
        }), " — the newest among the bound apps (others on\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "0.2.8"
        }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "0.8.1"
        }), "; agent-demo ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "^0.12.0"
        }), "). Recorded as fleet maintenance debt; a\ncoordinated bump is its own gated change."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Comment vocab fixes applied:"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "kernel"
        }), " → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "host"
        }), " (FileExplorer.tsx docstring);\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "PR #84 §6.3"
        }), " → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "SERVICE_PROVIDERS_SPEC §6.3"
        }), " (SummaryModal.tsx — the unstable PR\npointer cited the right § but the wrong source)."]
      }), "\n"]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/CODE_SPEC_REFERENCES.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJibG9ja3F1b3RlIiwiY29kZSIsImRlbCIsImVtIiwiaDEiLCJoMiIsImhyIiwibGkiLCJwIiwic3Ryb25nIiwidWwiLCJfcHJvdmlkZUNvbXBvbmVudHMiLCJjb21wb25lbnRzIiwiSGVhZGluZ0FuY2hvciIsIl9taXNzaW5nTWR4UmVmZXJlbmNlIiwianN4cyIsIkZyYWdtZW50IiwiY2hpbGRyZW4iLCJpZCIsImpzeCIsIk1EWENvbnRlbnQiLCJ3cmFwcGVyIiwiTURYTGF5b3V0IiwiX2MiLCJjb21wb25lbnQiLCJwbGFjZSIsIkVycm9yIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQ09ERV9TUEVDX1JFRkVSRU5DRVMubWQiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgYmxvY2txdW90ZTogXCJibG9ja3F1b3RlXCIsXG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgZGVsOiBcImRlbFwiLFxuICAgIGVtOiBcImVtXCIsXG4gICAgaDE6IFwiaDFcIixcbiAgICBoMjogXCJoMlwiLFxuICAgIGhyOiBcImhyXCIsXG4gICAgbGk6IFwibGlcIixcbiAgICBwOiBcInBcIixcbiAgICBzdHJvbmc6IFwic3Ryb25nXCIsXG4gICAgdWw6IFwidWxcIixcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH0sIHtIZWFkaW5nQW5jaG9yfSA9IF9jb21wb25lbnRzO1xuICBpZiAoIUhlYWRpbmdBbmNob3IpIF9taXNzaW5nTWR4UmVmZXJlbmNlKFwiSGVhZGluZ0FuY2hvclwiLCB0cnVlKTtcbiAgcmV0dXJuIDw+PF9jb21wb25lbnRzLmgxIGlkPVwiY29kZV9zcGVjX3JlZmVyZW5jZXMtZmlsZS1leHBsb3JlclwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiY29kZV9zcGVjX3JlZmVyZW5jZXMtZmlsZS1leHBsb3JlclwiIC8+e1wiQ09ERV9TUEVDX1JFRkVSRU5DRVMg4oCUIGZpbGUtZXhwbG9yZXJcIn08L19jb21wb25lbnRzLmgxPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkR1cmFibGUgaW5kZXggb2YgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJub24tdHJpdmlhbFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBjb2Rl4oaUc3BlYyBtYXBwaW5ncyBhIHJlYWRlciB3b3VsZG4ndCByZWRpc2NvdmVyXFxucXVpY2tseS4gVHJpdmlhbCBtYXBwaW5ncyBsaXZlIGFzIGlubGluZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCIvLyA8U1BFQz4gwqdYXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjb21tZW50cy4gU2VlZGVkIGJ5IHRoZVxcbjIwMjYtMDYgY29kZS12ZXJpZmljYXRpb24gcGFzcyAoUjMtMTI0OyBwbGFuIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjA4LXN5c3RlbS1hcHBzLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInRoZS13cml0ZS1pbnRlbnQtaW5kaXJlY3Rpb24tdGhlLWxvYWQtYmVhcmluZy1vbmVcIj48SGVhZGluZ0FuY2hvciBpZD1cInRoZS13cml0ZS1pbnRlbnQtaW5kaXJlY3Rpb24tdGhlLWxvYWQtYmVhcmluZy1vbmVcIiAvPntcIlRoZSB3cml0ZS1pbnRlbnQgaW5kaXJlY3Rpb24gKHRoZSBsb2FkLWJlYXJpbmcgb25lKVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJTcGVjOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJGSUxFX0VYUExPUkVSX1NQRUMgwqc0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAod3JpdGUgYWN0aW9ucykgKyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJVSV9BU19BUFBTX1NQRUMgwqc0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAob25lIGFwcCxcXG50d28gc2xvdHMgLyBob3N0LWdhdGVkIGludGVudHMpICsgdGhlIGhvc3QncyBjb3B5LW9uLXdyaXRlIGxheWVyLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIk1hcHBpbmc6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHRoZSBhcHAgaG9sZHMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJubyB3cml0ZSBwb3J0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLiBDcmVhdGUgLyByZW5hbWUgLyBkZWxldGUgLyB1cGxvYWQgL1xcbm1vdmUgYXJlIFwifTxfY29tcG9uZW50cy5lbT57XCJub3RcIn08L19jb21wb25lbnRzLmVtPntcIiBkaXJlY3QgZmlsZXN5c3RlbSB3cml0ZXMg4oCUIHRoZSBhcHAgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJuYW1lcyBhIHBhdGhcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYW5kIHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImhvc3RcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCJcXG5wZXJmb3JtcyB0aGUgY29weS1vbi13cml0ZSB3cml0ZSBiZWhpbmQgdGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcImVkaXRvcjp3cml0ZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaW50ZW50LiBUaGUgQ09XL2pvdXJuYWxcXG5saXZlcyBpbiB0aGUgaG9zdCAoY29yZV9jb25jZXB0cyDCpzIpLCBuZXZlciBpbiB0aGlzIGFwcC4gVGhpcyBpcyB3aHkgdGhlIGFmZm9yZGFuY2VzXFxuYXBwZWFyIG9ubHkgb24gYSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIndyaXRhYmxlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIG1vdW50ICh2MTogdGhlIHdvcmt0cmVlKSBhbmQgbmV2ZXIgc3VyZmFjZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJFUk9GU1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYXNcXG5VWCDigJQgdGhlIGhvc3QgYWRqdWRpY2F0ZXMgd3JpdGFiaWxpdHksIHRoZSBhcHAgcmVmbGVjdHMgaXQuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2xpYi11aS9zZGsvYWN0aW9ucy50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1ha2VTZGtBY3Rpb25zXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikg4oCUIHRoZSDCpzQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZWRpdG9yOm9wZW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIC9cXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJlZGl0b3I6d3JpdGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGludGVudCBpbmRpcmVjdGlvbi4gKFRoZSBoZWFkbGVzcyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvbGliLXVpL0ZpbGVFeHBsb3JlclZpZXcudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIlxcbm9ubHkgTkFNRVMgdGhlIHBhdGggdGhyb3VnaCBpbmplY3RlZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJhY3Rpb25zXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjsgdGhlIFNESyBjYWxscyBsaXZlIGluIHRoZSBhZGFwdGVyLilcIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJTREsgY2FsbHMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZGVsZXRlRW50cnlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIC8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicmVuYW1lRW50cnlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIC8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widXBsb2FkRmlsZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgLyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjcmVhdGVGaWxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoaW5cXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvbGliLXVpL3Nkay9hY3Rpb25zLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikgYXJlIGhvc3QtZ2F0ZWQgaW50ZW50cywgbm90IGxvY2FsIHdyaXRlcy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwidGhlLWxsbWNoYXQxLXN1bW1hcml6ZS1mb3JrLWZlYXR1cmVcIj48SGVhZGluZ0FuY2hvciBpZD1cInRoZS1sbG1jaGF0MS1zdW1tYXJpemUtZm9yay1mZWF0dXJlXCIgLz57XCJUaGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibGxtLmNoYXRAMVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgXFxcIlN1bW1hcml6ZVxcXCIgZm9yayBmZWF0dXJlXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlNwZWM6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlNFUlZJQ0VfUFJPVklERVJTX1NQRUNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJsbG06Y2hhdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgY2FwYWJpbGl0eSkgKyB0aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibGxtLmNoYXRAMVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgc2VydmljZVxcbnNsb3QuIFwifTxfY29tcG9uZW50cy5jb2RlPntcInVpOm92ZXJsYXlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHNlbGYtb3ZlcmxheSBpcyB0aGUgcmljaGVyIGZvbGxvdy11cCAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiU0VSVklDRV9QUk9WSURFUlNfU1BFQyDCpzYuM1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsXFxucHJvcG9zZWQpIOKAlCB0b2RheSB0aGUgbW9kYWwgaXMgZHJhd24gaW4taWZyYW1lLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIk1hcHBpbmc6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9saWItdWkvc2RrL1N1bW1hcnlNb2RhbC50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNhbGxzIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNoYXQoKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKG5lZWRzIG9ubHkgdGhlXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibGxtOmNoYXRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNhcGFiaWxpdHkgdGhlIGZvcmsgY29uc2VudGVkKSwgc3RyZWFtcyB0aGUgc3VtbWFyeSwgYW5kIGNhbiBzYXZlIGl0IG5leHRcXG50byB0aGUgc291cmNlIGZpbGUgKGdhdGVkIG9uIGEgd3JpdGFibGUgbW91bnQpLiBUaGUgXFxcInByb3ZpZGVyLWFnbm9zdGljIExMTVxcXCIgd29yZGluZ1xcbm1lYW5zIHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIkxMTSBzZXJ2aWNlIHByb3ZpZGVyXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChBbnRocm9waWMvT3BlbkFJKSwgY29yZV9jb25jZXB0cyDCpzYgc2Vuc2Ug4oCUIG5vdFxcbnRoZSBhcHAtaWRlbnRpdHkgc291cmNlIGhvc3QuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cIm11bHRpLXJvb3QtdHJlZS1zdG9yZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwibXVsdGktcm9vdC10cmVlLXN0b3JlXCIgLz57XCJNdWx0aS1yb290IHRyZWUgc3RvcmVcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiU3BlYzpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRklMRV9FWFBMT1JFUl9TUEVDIMKnMlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKG11bHRpcGxlIG1vdW50cykg4oCUIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9saWItdWkvdHJlZVN0b3JlLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIlxcbmtlZXBzIG9uZSBzY29wZS1oZWFkZWQgdHJlZSBwZXIgcm9vdCAod29ya3RyZWUgKyBzcGFjZXMgKyBncmFudGVkIHN1YnRyZWVzKS4gSXRcXG5yZWFkcyBlbnRyaWVzIHRocm91Z2ggYW4gaW5qZWN0ZWQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRnNTb3VyY2VcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICh0aGUgU0RLIGFkYXB0ZXIncyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzZGtGc1NvdXJjZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLCBzb1xcbnRoZSBzdG9yZSBpcyBwdXJlIG9mIGFueSBjb25jcmV0ZSBmcy5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwidGhlLTUtdXBsb2FkLWJ1dHRvbnMtc2VsZWN0aW9uLWRlcml2ZWQtZGVzdGluYXRpb25cIj48SGVhZGluZ0FuY2hvciBpZD1cInRoZS01LXVwbG9hZC1idXR0b25zLXNlbGVjdGlvbi1kZXJpdmVkLWRlc3RpbmF0aW9uXCIgLz57XCJUaGUgwqc1IHVwbG9hZCBidXR0b24ncyBzZWxlY3Rpb24tZGVyaXZlZCBkZXN0aW5hdGlvblwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJTcGVjOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJGSUxFX0VYUExPUkVSX1NQRUMgwqc1XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoYW1lbmRlZCAyMDI2LTA5LTE0IOKAlCB0aGUgcGlja2VyIHBhdGgpLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIk1hcHBpbmc6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHRoZSBoZWFkZXIgVXBsb2FkIGJ1dHRvbiBpbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvbGliLXVpL0ZpbGVFeHBsb3JlclZpZXcudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiByZXVzZXNcXG50aGUgT05FIGhpZGRlbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCI8aW5wdXQgdHlwZT1cXFwiZmlsZVxcXCIgbXVsdGlwbGU+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB0aGUgwqczIFxcXCJVcGxvYWQgaGVyZeKAplxcXCIgbWVudSBpdGVtXFxub3BlbnMgKFwifTxfY29tcG9uZW50cy5jb2RlPntcInVwbG9hZFRhcmdldFJlZlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJvblVwbG9hZElucHV0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiksIHNvIGJvdGggaW5nZXN0aW9uIHBhdGhzIHNoYXJlIHRoZVxcbnVwbG9hZCB3cml0ZSBmbG93LiBUaGUgZGVzdGluYXRpb24gY2Fubm90IGJlIHBvaW50ZWQgYXQgKGEgZHJvcCBjYW4pLCBzbyBpdCBpc1xcbmRlcml2ZWQgZnJvbSB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJzZWxlY3Rpb25cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHdoaWNoIGlzIHdoeSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJUcmVlU3RvcmUuc2VsZWN0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBub3cgcmVjb3JkcyB0aGVcXG5yb3cncyBLSU5EIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJzZWxlY3QocGF0aCwgaXNEaXIpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgcmVhZCB2aWEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZ2V0U2VsZWN0ZWRSb3coKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widXNlU2VsZWN0ZWRSb3dcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKVxcbmFuZCB3aHkgZGlyZWN0b3J5IGFjdGl2YXRpb24vbmF2aWdhdGlvbiBzZWxlY3RzIHRoZSBlbnRlcmVkIGZvbGRlciBpbiBldmVyeVxcbmxheW91dCAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaGFuZGxlQWN0aXZhdGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJuYXZpZ2F0ZUN3ZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm5hdmlnYXRlQ29sc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLiBUaGUgZGlyL2ZpbGUvbm9uZSDihpJcXG5kaXIvcGFyZW50L3JlcG8tcm9vdCByZXNvbHV0aW9uIGl0c2VsZiBpcyB0aGUgcHVyZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ1cGxvYWRUYXJnZXREaXJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxuKFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9saWItdWkvZXhwbG9yZXIudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSwgc2hhcmVkIHdpdGggdGhlIGRyYWctZHJvcCB0YXJnZXQgY29tcHV0YXRpb247IHRoZVxcbndyaXRhYmxlLXJvb3QgZmFsbGJhY2sgKHJlYWQtb25seSBzZWxlY3Rpb24g4oaSIHJlcG8gcm9vdDsgbm8gd3JpdGFibGUgc2NvcGUg4oaSIHRoZVxcbmJ1dHRvbiBoaWRlcykgbGl2ZXMgaW4gdGhlIHZpZXcgYmVzaWRlIFwifTxfY29tcG9uZW50cy5jb2RlPntcInVwbG9hZFJvb3RcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaHIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJyZWNvcmRlZC1maW5kaW5ncy1jb2RlLXZlcmlmaWNhdGlvbi1wYXNzLTIwMjYtMDZcIj48SGVhZGluZ0FuY2hvciBpZD1cInJlY29yZGVkLWZpbmRpbmdzLWNvZGUtdmVyaWZpY2F0aW9uLXBhc3MtMjAyNi0wNlwiIC8+e1wiUmVjb3JkZWQgZmluZGluZ3MgKGNvZGUtdmVyaWZpY2F0aW9uIHBhc3MsIDIwMjYtMDYpXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMuYmxvY2txdW90ZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkNMT1NFRCwgdmVyaWZpZWQgb24gMjAyNi0wOS0xNiAoUjMtNjUzKS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhlIHR3byBTREsgZW50cmllcyBiZWxvdyDigJQgXCJ9PF9jb21wb25lbnRzLmVtPntcIkRPTkUtQlVULURJVkVSR0VOVFxcbihcIn08X2NvbXBvbmVudHMuY29kZT57XCJjaGF0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBub3QgZXhwb3J0ZWQpXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgYW5kIFwifTxfY29tcG9uZW50cy5lbT57XCJTREstdmVyc2lvbiBza2V3XCJ9PC9fY29tcG9uZW50cy5lbT57XCIg4oCUIGFyZSBzdGFsZSBhbmQgYXJlIGtlcHQgYXMgdGhlIHJlY29yZCByYXRoZXJcXG50aGFuIGRlbGV0ZWQ7IHRoZSB0aGlyZCBidWxsZXQsIFwifTxfY29tcG9uZW50cy5lbT57XCJDb21tZW50IHZvY2FiIGZpeGVzIGFwcGxpZWRcIn08L19jb21wb25lbnRzLmVtPntcIiwgaXMgdW50b3VjaGVkIGJ5IHRoaXMgbm90ZS5cXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJwYWNrYWdlLmpzb25cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG5vdyBwaW5zIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkBpbW1lZGlhdGVseS1ydW4vc2RrXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhdCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJeMC40My4wXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgdGhlIGluc3RhbGxlZFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcImRpc3QvaW5kZXguZC50czoyNFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZXhwb3J0cyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjaGF0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgYW5kIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm5wbSBydW4gYnVpbGRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGV4aXRzIDAgb24gdGhpcyBQUidzIGhlYWQg4oCUIGFcXG5icmFuY2ggd2hvc2Ugb25seSBzb3VyY2UgY2hhbmdlIGlzIHRoZSBDSSB3b3JrZmxvdyAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZ2l0IGRpZmYgb3JpZ2luL21haW4uLi5IRUFEIC0tc3RhdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG5pcyB0aHJlZSBmaWxlczogXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLmdpdGh1Yi93b3JrZmxvd3MvY2kueW1sXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicGFja2FnZS5qc29uXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIidzIFwifTxfY29tcG9uZW50cy5jb2RlPntcImxpbnRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHNjcmlwdCwgYW5kIHRoaXMgZmlsZSkuXFxuU28gdGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlRTMjMwNVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZmFpbHVyZSBpcyBnb25lIGFuZCB0aGUgXFxcIm5ld2VzdCBhbW9uZyB0aGUgYm91bmQgYXBwcyBhdCAwLjExLjBcXFwiIHNrZXdcXG5yZWFkaW5nIGlzIG9ic29sZXRlLiBGb3VuZCB3aGlsZSBhZGRpbmcgQ0kgdG8gdGhpcyByZXBvOiB0aGUgUFIgYXNzZXJ0ZWQgdGhlIGJ1aWxkIHBhc3Nlc1xcbm9uIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1haW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCB3aGljaCBpcyB0aGUgZGlyZWN0IG5lZ2F0aW9uIG9mIHRoZSBmaXJzdCBlbnRyeSwgc28gbGVhdmluZyBpdCBvcGVuIHdvdWxkIGhhdmVcXG5iZWVuIGEgY2xhaW0gdGhpcyByZXBvJ3Mgb3duIGdhdGUgY29udHJhZGljdHMuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTwvX2NvbXBvbmVudHMuYmxvY2txdW90ZT57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiW0NMT1NFRCAyMDI2LTA5LTE2XVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuZGVsPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRE9ORS1CVVQtRElWRVJHRU5UIChDUklULCBwcmUtZXhpc3Rpbmcgb24gb3JpZ2luL21haW4pIOKAlFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcImNoYXRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG5vdCBleHBvcnRlZCBieSB0aGUgcGlubmVkIFNESy5cIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLmRlbD57XCIgVGhlIHNoaXBwZWQgXFxcIlN1bW1hcml6ZVxcXCIgZmVhdHVyZSAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2xpYi11aS9zZGsvU3VtbWFyeU1vZGFsLnRzeDoyXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIlxcblwifTxfY29tcG9uZW50cy5jb2RlPntcImltcG9ydCB7IGNoYXQgfSBmcm9tIFxcXCJAaW1tZWRpYXRlbHktcnVuL3Nka1xcXCJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBhZGRlZCBpbiBQUiAjOSkgZG9lcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIlxcbnR5cGUtY2hlY2sgYWdhaW5zdCB0aGUgcmVwbydzIG93biBwaW5uZWQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQGltbWVkaWF0ZWx5LXJ1bi9zZGtAMC4xMS4wXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgd2hpY2ggaGFzXFxubm8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2hhdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZXhwb3J0IOKGkiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJucG0gcnVuIGJ1aWxkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBmYWlscyB3aXRoIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlRTMjMwNVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJvbiBhIGNsZWFuIG9yaWdpbi9tYWluXFxuY2hlY2tvdXRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHZlcmlmaWVkIGJ5IHN0YXNoaW5nIHRoaXMgcGFzcydzIGNvbW1lbnQtb25seSBlZGl0cyBhbmQgcmVidWlsZGluZykuXFxuVGhpcyBpcyBhIHJlYWwgRG9uZS1idXQtZGl2ZXJnZW50IGdhcDogdGhlIGZlYXR1cmUgc2hpcHBlZCBhZ2FpbnN0IGEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2hhdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibGxtLmNoYXRAMVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgU0RLIHN1cmZhY2UgbmV3ZXIgdGhhbiB0aGUgcGlubmVkIHZlcnNpb24gKGFuIGluc3RhbmNlIG9mIHRoZVxcblNESy12ZXJzaW9uIHNrZXcgYmVsb3cpLiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIk5vdCBpbnRyb2R1Y2VkIGJ5IHRoaXMgcGFzc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgdGhpcyBwYXNzIG1hZGUgb25seVxcbmNvbW1lbnQtbGV2ZWwgZWRpdHMgKFwifTxfY29tcG9uZW50cy5jb2RlPntcImtlcm5lbFwifTwvX2NvbXBvbmVudHMuY29kZT57XCLihpJcIn08X2NvbXBvbmVudHMuY29kZT57XCJob3N0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiUFIgIzg0IMKnNi4zXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIuKGklwifTxfY29tcG9uZW50cy5jb2RlPntcIlNFUlZJQ0VfUFJPVklERVJTX1NQRUMgwqc2LjNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKVxcbmFuZCBzZWVkZWQgdGhpcyBmaWxlOyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJucG0gcnVuIGxpbnRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFuZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJucG0gdGVzdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKDM2IHRlc3RzKSBhcmUgZ3JlZW4uIEZpeCBpcyBhXFxuY29vcmRpbmF0ZWQgU0RLIGJ1bXAgdG8gYSB2ZXJzaW9uIGV4cG9ydGluZyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjaGF0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAob3V0IG9mIHNjb3BlIGZvciB0aGlzXFxudmVyaWZ5L3JlY29yZCBwYXNzIOKAlCBmaWxlZCBhcyBhIHJvYWRtYXAgY2hpbGQgb2YgUjMtMTI0KS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIltDTE9TRUQgMjAyNi0wOS0xNl1cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXCJ9PF9jb21wb25lbnRzLmRlbD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlNESy12ZXJzaW9uIHNrZXcgKHJlY29yZCBvbmx5LCBkbyBub3QgYnVtcCk6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy5kZWw+e1wiIGZpbGUtZXhwbG9yZXIgcGluc1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcIkBpbW1lZGlhdGVseS1ydW4vc2RrXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhdCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPjxfY29tcG9uZW50cy5jb2RlPntcIjAuMTEuMFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHRoZSBuZXdlc3QgYW1vbmcgdGhlIGJvdW5kIGFwcHMgKG90aGVycyBvblxcblwifTxfY29tcG9uZW50cy5jb2RlPntcIjAuMi44XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAvIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjAuOC4xXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjsgYWdlbnQtZGVtbyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJeMC4xMi4wXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikuIFJlY29yZGVkIGFzIGZsZWV0IG1haW50ZW5hbmNlIGRlYnQ7IGFcXG5jb29yZGluYXRlZCBidW1wIGlzIGl0cyBvd24gZ2F0ZWQgY2hhbmdlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQ29tbWVudCB2b2NhYiBmaXhlcyBhcHBsaWVkOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJrZXJuZWxcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKGkiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJob3N0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoRmlsZUV4cGxvcmVyLnRzeCBkb2NzdHJpbmcpO1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcIlBSICM4NCDCpzYuM1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oaSIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlNFUlZJQ0VfUFJPVklERVJTX1NQRUMgwqc2LjNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChTdW1tYXJ5TW9kYWwudHN4IOKAlCB0aGUgdW5zdGFibGUgUFJcXG5wb2ludGVyIGNpdGVkIHRoZSByaWdodCDCpyBidXQgdGhlIHdyb25nIHNvdXJjZSkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPjwvPjtcbn1cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE1EWENvbnRlbnQocHJvcHMgPSB7fSkge1xuICBjb25zdCB7d3JhcHBlcjogTURYTGF5b3V0fSA9IHtcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH07XG4gIHJldHVybiBNRFhMYXlvdXQgPyA8TURYTGF5b3V0IHsuLi5wcm9wc30+PF9jcmVhdGVNZHhDb250ZW50IHsuLi5wcm9wc30gLz48L01EWExheW91dD4gOiBfY3JlYXRlTWR4Q29udGVudChwcm9wcyk7XG59XG5mdW5jdGlvbiBfbWlzc2luZ01keFJlZmVyZW5jZShpZCwgY29tcG9uZW50LCBwbGFjZSkge1xuICB0aHJvdyBuZXcgRXJyb3IoXCJFeHBlY3RlZCBcIiArIChjb21wb25lbnQgPyBcImNvbXBvbmVudFwiIDogXCJvYmplY3RcIikgKyBcIiBgXCIgKyBpZCArIFwiYCB0byBiZSBkZWZpbmVkOiB5b3UgbGlrZWx5IGZvcmdvdCB0byBpbXBvcnQsIHBhc3MsIG9yIHByb3ZpZGUgaXQuXCIgKyAocGxhY2UgPyBcIlxcbkl04oCZcyByZWZlcmVuY2VkIGluIHlvdXIgY29kZSBhdCBgXCIgKyBwbGFjZSArIFwiYCBpbiBgL2FwcC9DT0RFX1NQRUNfUkVGRVJFTkNFUy5tZGBcIiA6IFwiXCIpKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQXdGLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUZ4RjtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU1DLFdBQVcsR0FBRztNQUNsQkMsVUFBVSxFQUFFLFlBQVk7TUFDeEJDLElBQUksRUFBRSxNQUFNO01BQ1pDLEdBQUcsRUFBRSxLQUFLO01BQ1ZDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLENBQUMsRUFBRSxHQUFHO01BQ05DLE1BQU0sRUFBRSxRQUFRO01BQ2hCQyxFQUFFLEVBQUUsSUFBSTtNQUNSLEdBQUcsSUFBQUMsNkJBQWtCLEVBQUMsQ0FBQztNQUN2QixHQUFHYixLQUFLLENBQUNjO0lBQ1gsQ0FBQztJQUFFO01BQUNDO0lBQWEsQ0FBQyxHQUFHZCxXQUFXO0VBQ2hDLElBQUksQ0FBQ2MsYUFBYSxFQUFFQyxvQkFBb0IsQ0FBQyxlQUFlLEVBQUUsSUFBSSxDQUFDO0VBQy9ELG9CQUFPLElBQUFsQixXQUFBLENBQUFtQixJQUFBLEVBQUFuQixXQUFBLENBQUFvQixRQUFBO0lBQUFDLFFBQUEsZ0JBQUUsSUFBQXJCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDYyxFQUFFLEVBQUMsb0NBQW9DO01BQUFELFFBQUEsZ0JBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBb0MsQ0FBRSxDQUFDLEVBQUMsc0NBQXNDO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBbUIsSUFBQSxFQUFDaEIsV0FBVyxDQUFDUyxDQUFDO01BQUFTLFFBQUEsR0FBRSxtQkFBbUIsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDVSxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFhLENBQXFCLENBQUMsRUFBQyw2RkFBNkYsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBYyxDQUFtQixDQUFDLEVBQUMseUVBQXlFLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQW1CLENBQW1CLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBbUIsSUFBQSxFQUFDaEIsV0FBVyxDQUFDTSxFQUFFO01BQUNhLEVBQUUsRUFBQyxtREFBbUQ7TUFBQUQsUUFBQSxnQkFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFtRCxDQUFFLENBQUMsRUFBQyxxREFBcUQ7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNTLENBQUM7TUFBQVMsUUFBQSxnQkFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDVSxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFPLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQXVCLENBQW1CLENBQUMsRUFBQyxxQkFBcUIsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBb0IsQ0FBbUIsQ0FBQyxFQUFDLCtFQUErRTtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBUyxRQUFBLGdCQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNVLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQVUsQ0FBcUIsQ0FBQyxFQUFDLGlCQUFpQixlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNVLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQWUsQ0FBcUIsQ0FBQyxFQUFDLGtEQUFrRCxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNJLEVBQUU7UUFBQWMsUUFBQSxFQUFFO01BQUssQ0FBaUIsQ0FBQyxFQUFDLHNDQUFzQyxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNVLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQWMsQ0FBcUIsQ0FBQyxFQUFDLFdBQVcsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDVSxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFNLENBQXFCLENBQUMsRUFBQyxnREFBZ0QsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBYyxDQUFtQixDQUFDLEVBQUMsbUlBQW1JLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1UsTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBVSxDQUFxQixDQUFDLEVBQUMsOENBQThDLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQU8sQ0FBbUIsQ0FBQyxFQUFDLGtFQUFrRTtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ1csRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNRLEVBQUU7UUFBQVUsUUFBQSxnQkFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBMkIsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLGFBQWEsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBYSxDQUFtQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUMsRUFBQyxxQ0FBcUMsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBaUMsQ0FBbUIsQ0FBQyxFQUFDLHlDQUF5QyxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFTLENBQW1CLENBQUMsRUFBQyx1Q0FBdUM7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNRLEVBQUU7UUFBQVUsUUFBQSxHQUFFLFlBQVksZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBYSxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVksQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBWSxDQUFtQixDQUFDLEVBQUMsUUFBUSxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUEyQixDQUFtQixDQUFDLEVBQUMsNkNBQTZDO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNNLEVBQUU7TUFBQ2EsRUFBRSxFQUFDLHFDQUFxQztNQUFBRCxRQUFBLGdCQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQXFDLENBQUUsQ0FBQyxFQUFDLE1BQU0sZUFBQyxJQUFBdEIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBWSxDQUFtQixDQUFDLEVBQUMsNkJBQTZCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBbUIsSUFBQSxFQUFDaEIsV0FBVyxDQUFDUyxDQUFDO01BQUFTLFFBQUEsZ0JBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1UsTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBTyxDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUF3QixDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFVLENBQW1CLENBQUMsRUFBQyxxQkFBcUIsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBWSxDQUFtQixDQUFDLEVBQUMsa0JBQWtCLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQVksQ0FBbUIsQ0FBQyxFQUFDLHlDQUF5QyxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUE2QixDQUFtQixDQUFDLEVBQUMsb0RBQW9EO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBbUIsSUFBQSxFQUFDaEIsV0FBVyxDQUFDUyxDQUFDO01BQUFTLFFBQUEsZ0JBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1UsTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBVSxDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFpQyxDQUFtQixDQUFDLEVBQUMsU0FBUyxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFRLENBQW1CLENBQUMsRUFBQyxvQkFBb0IsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBVSxDQUFtQixDQUFDLEVBQUMsK0tBQStLLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1UsTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBc0IsQ0FBcUIsQ0FBQyxFQUFDLGtGQUFrRjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDYSxFQUFFLEVBQUMsdUJBQXVCO01BQUFELFFBQUEsZ0JBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBdUIsQ0FBRSxDQUFDLEVBQUMsdUJBQXVCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBbUIsSUFBQSxFQUFDaEIsV0FBVyxDQUFDUyxDQUFDO01BQUFTLFFBQUEsZ0JBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1UsTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBTyxDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUF1QixDQUFtQixDQUFDLEVBQUMsdUJBQXVCLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQXlCLENBQW1CLENBQUMsRUFBQyx1SEFBdUgsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBVSxDQUFtQixDQUFDLEVBQUMsc0JBQXNCLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQWEsQ0FBbUIsQ0FBQyxFQUFDLDhDQUE4QztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDYSxFQUFFLEVBQUMsb0RBQW9EO01BQUFELFFBQUEsZ0JBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBb0QsQ0FBRSxDQUFDLEVBQUMsc0RBQXNEO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBbUIsSUFBQSxFQUFDaEIsV0FBVyxDQUFDUyxDQUFDO01BQUFTLFFBQUEsZ0JBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1UsTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBTyxDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUF1QixDQUFtQixDQUFDLEVBQUMsMENBQTBDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBbUIsSUFBQSxFQUFDaEIsV0FBVyxDQUFDUyxDQUFDO01BQUFTLFFBQUEsZ0JBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1UsTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBVSxDQUFxQixDQUFDLEVBQUMsK0JBQStCLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQWlDLENBQW1CLENBQUMsRUFBQywwQkFBMEIsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBZ0MsQ0FBbUIsQ0FBQyxFQUFDLDZDQUE2QyxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFpQixDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFlLENBQW1CLENBQUMsRUFBQyx5SUFBeUksZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDVSxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFXLENBQXFCLENBQUMsRUFBQyxrQkFBa0IsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBa0IsQ0FBbUIsQ0FBQyxFQUFDLGdDQUFnQyxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFxQixDQUFtQixDQUFDLEVBQUMsYUFBYSxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFrQixDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFnQixDQUFtQixDQUFDLEVBQUMsMEZBQTBGLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQWdCLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQWEsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBYyxDQUFtQixDQUFDLEVBQUMsNkVBQTZFLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQWlCLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQXdCLENBQW1CLENBQUMsRUFBQyxpTEFBaUwsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBWSxDQUFtQixDQUFDLEVBQUMsR0FBRztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ08sRUFBRSxJQUFFLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQVYsV0FBQSxDQUFBbUIsSUFBQSxFQUFDaEIsV0FBVyxDQUFDTSxFQUFFO01BQUNhLEVBQUUsRUFBQyxrREFBa0Q7TUFBQUQsUUFBQSxnQkFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFrRCxDQUFFLENBQUMsRUFBQyxxREFBcUQ7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNDLFVBQVU7TUFBQWlCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ1MsQ0FBQztRQUFBUyxRQUFBLGdCQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNVLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQTBDLENBQXFCLENBQUMsRUFBQywrQkFBK0IsZUFBQyxJQUFBckIsV0FBQSxDQUFBbUIsSUFBQSxFQUFDaEIsV0FBVyxDQUFDSSxFQUFFO1VBQUFjLFFBQUEsR0FBRSx1QkFBdUIsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1lBQUFnQixRQUFBLEVBQUU7VUFBTSxDQUFtQixDQUFDLEVBQUMsZ0JBQWdCO1FBQUEsQ0FBaUIsQ0FBQyxFQUFDLE9BQU8sZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDSSxFQUFFO1VBQUFjLFFBQUEsRUFBRTtRQUFrQixDQUFpQixDQUFDLEVBQUMsa0ZBQWtGLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0ksRUFBRTtVQUFBYyxRQUFBLEVBQUU7UUFBNkIsQ0FBaUIsQ0FBQyxFQUFDLGdDQUFnQyxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUMsRUFBQyxZQUFZLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQXNCLENBQW1CLENBQUMsRUFBQyxNQUFNLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVMsQ0FBbUIsQ0FBQyxFQUFDLG1CQUFtQixlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFvQixDQUFtQixDQUFDLEVBQUMsV0FBVyxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFNLENBQW1CLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWUsQ0FBbUIsQ0FBQyxFQUFDLHNGQUFzRixlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFvQyxDQUFtQixDQUFDLEVBQUMsb0JBQW9CLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQTBCLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBTSxDQUFtQixDQUFDLEVBQUMsbUNBQW1DLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVEsQ0FBbUIsQ0FBQyxFQUFDLHlLQUF5SyxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFNLENBQW1CLENBQUMsRUFBQyxrSUFBa0k7TUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQXlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ1csRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNRLEVBQUU7UUFBQVUsUUFBQSxnQkFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDVSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFxQixDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNHLEdBQUc7VUFBQWUsUUFBQSxlQUFDLElBQUFyQixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNVLE1BQU07WUFBQVEsUUFBQSxHQUFFLDREQUE0RCxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7Y0FBQWdCLFFBQUEsRUFBRTtZQUFNLENBQW1CLENBQUMsRUFBQyxrQ0FBa0M7VUFBQSxDQUFxQjtRQUFDLENBQWlCLENBQUMsRUFBQyxzQ0FBc0MsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBbUMsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBK0MsQ0FBbUIsQ0FBQyxFQUFDLHlCQUF5QixlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNVLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQUssQ0FBcUIsQ0FBQyxFQUFDLDZDQUE2QyxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUE2QixDQUFtQixDQUFDLEVBQUMsa0JBQWtCLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQU0sQ0FBbUIsQ0FBQyxFQUFDLFlBQVksZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBZSxDQUFtQixDQUFDLEVBQUMsY0FBYyxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFRLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBa0MsQ0FBcUIsQ0FBQyxFQUFDLCtJQUErSSxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFNLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVksQ0FBbUIsQ0FBQyxFQUFDLDJGQUEyRixlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNVLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQTZCLENBQXFCLENBQUMsRUFBQywrQ0FBK0MsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFNLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBNkIsQ0FBbUIsQ0FBQyxFQUFDLDJCQUEyQixlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUMsRUFBQyxPQUFPLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVUsQ0FBbUIsQ0FBQyxFQUFDLCtFQUErRSxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFNLENBQW1CLENBQUMsRUFBQyxvRkFBb0Y7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNRLEVBQUU7UUFBQVUsUUFBQSxnQkFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDVSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFxQixDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNHLEdBQUc7VUFBQWUsUUFBQSxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNVLE1BQU07WUFBQVEsUUFBQSxFQUFFO1VBQThDLENBQXFCO1FBQUMsQ0FBaUIsQ0FBQyxFQUFDLHVCQUF1QixlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFzQixDQUFtQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNVLE1BQU07VUFBQVEsUUFBQSxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7WUFBQWdCLFFBQUEsRUFBRTtVQUFRLENBQW1CO1FBQUMsQ0FBb0IsQ0FBQyxFQUFDLGlEQUFpRCxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFPLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQU8sQ0FBbUIsQ0FBQyxFQUFDLGVBQWUsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBUyxDQUFtQixDQUFDLEVBQUMscUZBQXFGO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBbUIsSUFBQSxFQUFDaEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFVLFFBQUEsZ0JBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBOEIsQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFNLENBQW1CLENBQUMsRUFBQyxrQ0FBa0MsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBYSxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUE2QixDQUFtQixDQUFDLEVBQUMsd0ZBQXdGO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDO0VBQUEsQ0FBRSxDQUFDO0FBQ3ZsWTtBQUNlLFNBQVNHLFVBQVVBLENBQUN0QixLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUU7RUFDN0MsTUFBTTtJQUFDdUIsT0FBTyxFQUFFQztFQUFTLENBQUMsR0FBRztJQUMzQixHQUFHLElBQUFYLDZCQUFrQixFQUFDLENBQUM7SUFDdkIsR0FBR2IsS0FBSyxDQUFDYztFQUNYLENBQUM7RUFDRCxPQUFPVSxTQUFTLGdCQUFHLElBQUExQixXQUFBLENBQUF1QixHQUFBLEVBQUNHLFNBQVM7SUFBQSxHQUFLeEIsS0FBSztJQUFBbUIsUUFBQSxlQUFFLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUN0QixpQkFBaUI7TUFBQSxHQUFLQztJQUFLLENBQUc7RUFBQyxDQUFXLENBQUMsR0FBR0QsaUJBQWlCLENBQUNDLEtBQUssQ0FBQztBQUNsSDtBQUFDeUIsRUFBQSxHQU51QkgsVUFBVTtBQU9sQyxTQUFTTixvQkFBb0JBLENBQUNJLEVBQUUsRUFBRU0sU0FBUyxFQUFFQyxLQUFLLEVBQUU7RUFDbEQsTUFBTSxJQUFJQyxLQUFLLENBQUMsV0FBVyxJQUFJRixTQUFTLEdBQUcsV0FBVyxHQUFHLFFBQVEsQ0FBQyxHQUFHLElBQUksR0FBR04sRUFBRSxHQUFHLG9FQUFvRSxJQUFJTyxLQUFLLEdBQUcscUNBQXFDLEdBQUdBLEtBQUssR0FBRyxxQ0FBcUMsR0FBRyxFQUFFLENBQUMsQ0FBQztBQUMvUDtBQUFDLElBQUFGLEVBQUE7QUFBQUksWUFBQSxDQUFBSixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}