"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _config = require("vitest/config");
var _pluginReact = _interopRequireDefault(require("@vitejs/plugin-react"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// Vitest config for the file-explorer app's unit tests (FX-3 regression guard).
// jsdom DOM + Testing Library; the SDK and the sandbox `readdir` are mocked per
// test so the tree renders without a live sandbox.
var _default = exports.default = (0, _config.defineConfig)({
  plugins: [(0, _pluginReact.default)()],
  test: {
    environment: "jsdom",
    globals: true,
    setupFiles: ["./src/test/setup.ts"],
    include: ["src/**/*.test.{ts,tsx}"]
  }
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY29uZmlnIiwicmVxdWlyZSIsIl9wbHVnaW5SZWFjdCIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJlIiwiX19lc01vZHVsZSIsImRlZmF1bHQiLCJfZGVmYXVsdCIsImV4cG9ydHMiLCJkZWZpbmVDb25maWciLCJwbHVnaW5zIiwicmVhY3QiLCJ0ZXN0IiwiZW52aXJvbm1lbnQiLCJnbG9iYWxzIiwic2V0dXBGaWxlcyIsImluY2x1ZGUiXSwic291cmNlcyI6WyJ2aXRlc3QuY29uZmlnLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGRlZmluZUNvbmZpZyB9IGZyb20gXCJ2aXRlc3QvY29uZmlnXCI7XG5pbXBvcnQgcmVhY3QgZnJvbSBcIkB2aXRlanMvcGx1Z2luLXJlYWN0XCI7XG5cbi8vIFZpdGVzdCBjb25maWcgZm9yIHRoZSBmaWxlLWV4cGxvcmVyIGFwcCdzIHVuaXQgdGVzdHMgKEZYLTMgcmVncmVzc2lvbiBndWFyZCkuXG4vLyBqc2RvbSBET00gKyBUZXN0aW5nIExpYnJhcnk7IHRoZSBTREsgYW5kIHRoZSBzYW5kYm94IGByZWFkZGlyYCBhcmUgbW9ja2VkIHBlclxuLy8gdGVzdCBzbyB0aGUgdHJlZSByZW5kZXJzIHdpdGhvdXQgYSBsaXZlIHNhbmRib3guXG5leHBvcnQgZGVmYXVsdCBkZWZpbmVDb25maWcoe1xuICBwbHVnaW5zOiBbcmVhY3QoKV0sXG4gIHRlc3Q6IHtcbiAgICBlbnZpcm9ubWVudDogXCJqc2RvbVwiLFxuICAgIGdsb2JhbHM6IHRydWUsXG4gICAgc2V0dXBGaWxlczogW1wiLi9zcmMvdGVzdC9zZXR1cC50c1wiXSxcbiAgICBpbmNsdWRlOiBbXCJzcmMvKiovKi50ZXN0Lnt0cyx0c3h9XCJdLFxuICB9LFxufSk7XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUFBLElBQUFBLE9BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLFlBQUEsR0FBQUMsc0JBQUEsQ0FBQUYsT0FBQTtBQUF5QyxTQUFBRSx1QkFBQUMsQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQUV6QztBQUNBO0FBQ0E7QUFBQSxJQUFBRyxRQUFBLEdBQUFDLE9BQUEsQ0FBQUYsT0FBQSxHQUNlLElBQUFHLG9CQUFZLEVBQUM7RUFDMUJDLE9BQU8sRUFBRSxDQUFDLElBQUFDLG9CQUFLLEVBQUMsQ0FBQyxDQUFDO0VBQ2xCQyxJQUFJLEVBQUU7SUFDSkMsV0FBVyxFQUFFLE9BQU87SUFDcEJDLE9BQU8sRUFBRSxJQUFJO0lBQ2JDLFVBQVUsRUFBRSxDQUFDLHFCQUFxQixDQUFDO0lBQ25DQyxPQUFPLEVBQUUsQ0FBQyx3QkFBd0I7RUFDcEM7QUFDRixDQUFDLENBQUMiLCJpZ25vcmVMaXN0IjpbXX0=