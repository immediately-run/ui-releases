"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _vite = require("vite");
var _pluginReact = _interopRequireDefault(require("@vitejs/plugin-react"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// The contribute dialog — a first-party immediately.run system app
// (UI_AS_APPS_SPEC §5.1). It streams a save of the user's edits (PR or direct
// commit) via the elevated `contribute()` SDK call. https://vite.dev/config/
var _default = exports.default = (0, _vite.defineConfig)({
  plugins: [(0, _pluginReact.default)()]
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZSIsInJlcXVpcmUiLCJfcGx1Z2luUmVhY3QiLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiX2RlZmF1bHQiLCJleHBvcnRzIiwiZGVmaW5lQ29uZmlnIiwicGx1Z2lucyIsInJlYWN0Il0sInNvdXJjZXMiOlsidml0ZS5jb25maWcudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgZGVmaW5lQ29uZmlnIH0gZnJvbSAndml0ZSc7XG5pbXBvcnQgcmVhY3QgZnJvbSAnQHZpdGVqcy9wbHVnaW4tcmVhY3QnO1xuXG4vLyBUaGUgY29udHJpYnV0ZSBkaWFsb2cg4oCUIGEgZmlyc3QtcGFydHkgaW1tZWRpYXRlbHkucnVuIHN5c3RlbSBhcHBcbi8vIChVSV9BU19BUFBTX1NQRUMgwqc1LjEpLiBJdCBzdHJlYW1zIGEgc2F2ZSBvZiB0aGUgdXNlcidzIGVkaXRzIChQUiBvciBkaXJlY3Rcbi8vIGNvbW1pdCkgdmlhIHRoZSBlbGV2YXRlZCBgY29udHJpYnV0ZSgpYCBTREsgY2FsbC4gaHR0cHM6Ly92aXRlLmRldi9jb25maWcvXG5leHBvcnQgZGVmYXVsdCBkZWZpbmVDb25maWcoe1xuICBwbHVnaW5zOiBbcmVhY3QoKV0sXG59KTtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQUEsSUFBQUEsS0FBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsWUFBQSxHQUFBQyxzQkFBQSxDQUFBRixPQUFBO0FBQXlDLFNBQUFFLHVCQUFBQyxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBRXpDO0FBQ0E7QUFDQTtBQUFBLElBQUFHLFFBQUEsR0FBQUMsT0FBQSxDQUFBRixPQUFBLEdBQ2UsSUFBQUcsa0JBQVksRUFBQztFQUMxQkMsT0FBTyxFQUFFLENBQUMsSUFBQUMsb0JBQUssRUFBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyIsImlnbm9yZUxpc3QiOltdfQ==