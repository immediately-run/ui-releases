var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
require("./index.css");
var _Contribute = _interopRequireDefault(require("./components/Contribute"));
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// Root component — immediately.run renders the default export of THIS file.
// The contribute dialog as an app (UI_AS_APPS_SPEC §5.1): it shows the unsaved
// files (editor:read), lets the user pick PR vs direct commit, then streams the
// save via the elevated `contribute()` SDK call. The OAuth token never reaches
// this app — the host holds it and only relays the contribution's stages.

function App() {
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_Contribute.default, {});
}
_c = App;
var _default = exports.default = App;
var _c;
$RefreshReg$(_c, "App");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJyZXF1aXJlIiwiX0NvbnRyaWJ1dGUiLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX2pzeFJ1bnRpbWUiLCJlIiwiX19lc01vZHVsZSIsImRlZmF1bHQiLCJBcHAiLCJqc3giLCJfYyIsIl9kZWZhdWx0IiwiZXhwb3J0cyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkFwcC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gUm9vdCBjb21wb25lbnQg4oCUIGltbWVkaWF0ZWx5LnJ1biByZW5kZXJzIHRoZSBkZWZhdWx0IGV4cG9ydCBvZiBUSElTIGZpbGUuXG4vLyBUaGUgY29udHJpYnV0ZSBkaWFsb2cgYXMgYW4gYXBwIChVSV9BU19BUFBTX1NQRUMgwqc1LjEpOiBpdCBzaG93cyB0aGUgdW5zYXZlZFxuLy8gZmlsZXMgKGVkaXRvcjpyZWFkKSwgbGV0cyB0aGUgdXNlciBwaWNrIFBSIHZzIGRpcmVjdCBjb21taXQsIHRoZW4gc3RyZWFtcyB0aGVcbi8vIHNhdmUgdmlhIHRoZSBlbGV2YXRlZCBgY29udHJpYnV0ZSgpYCBTREsgY2FsbC4gVGhlIE9BdXRoIHRva2VuIG5ldmVyIHJlYWNoZXNcbi8vIHRoaXMgYXBwIOKAlCB0aGUgaG9zdCBob2xkcyBpdCBhbmQgb25seSByZWxheXMgdGhlIGNvbnRyaWJ1dGlvbidzIHN0YWdlcy5cbmltcG9ydCBcIi4vaW5kZXguY3NzXCI7XG5pbXBvcnQgQ29udHJpYnV0ZSBmcm9tIFwiLi9jb21wb25lbnRzL0NvbnRyaWJ1dGVcIjtcblxuZnVuY3Rpb24gQXBwKCkge1xuICByZXR1cm4gPENvbnRyaWJ1dGUgLz47XG59XG5cbmV4cG9ydCBkZWZhdWx0IEFwcDtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBS0FBLE9BQUE7QUFDQSxJQUFBQyxXQUFBLEdBQUFDLHNCQUFBLENBQUFGLE9BQUE7QUFBaUQsSUFBQUcsV0FBQSxHQUFBSCxPQUFBO0FBQUEsU0FBQUUsdUJBQUFFLENBQUEsV0FBQUEsQ0FBQSxJQUFBQSxDQUFBLENBQUFDLFVBQUEsR0FBQUQsQ0FBQSxLQUFBRSxPQUFBLEVBQUFGLENBQUE7QUFOakQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFJQSxTQUFTRyxHQUFHQSxDQUFBLEVBQUc7RUFDYixvQkFBTyxJQUFBSixXQUFBLENBQUFLLEdBQUEsRUFBQ1AsV0FBQSxDQUFBSyxPQUFVLElBQUUsQ0FBQztBQUN2QjtBQUFDRyxFQUFBLEdBRlFGLEdBQUc7QUFBQSxJQUFBRyxRQUFBLEdBQUFDLE9BQUEsQ0FBQUwsT0FBQSxHQUlHQyxHQUFHO0FBQUEsSUFBQUUsRUFBQTtBQUFBRyxZQUFBLENBQUFILEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}