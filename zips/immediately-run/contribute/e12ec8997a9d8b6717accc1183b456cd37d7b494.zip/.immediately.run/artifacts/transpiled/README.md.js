var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      code: "code",
      h1: "h1",
      h2: "h2",
      p: "p",
      pre: "pre",
      strong: "strong",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "contribute",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "contribute"
      }), "contribute"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "contribute dialog"
      }), " as an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "https://immediately.run",
        children: "immediately.run"
      }), " app —\nthe first-party system app bound to the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "modal.contribute"
      }), " chrome region\n(UI_AS_APPS_SPEC §5.1)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["It shows which files you've changed but not saved (the elevated ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "editor:read"
      }), "\nchannel), lets you write a message and choose ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "pull request"
      }), " or ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "direct\ncommit"
      }), ", then streams the save through the host's contribution orchestrator via\nthe SDK's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "contribute()"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "The OAuth token never reaches this app."
      }), " The host holds it and performs every\nprivileged step (the GitHub API, the fork, the PR); this app only renders the\nstreamed progress. Direct commit requires the first-party-only ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "contribute:direct"
      }), "\ncapability — a fork that holds only ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "contribute:any"
      }), " is limited to pull requests\n(threat T11)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "capabilities",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "capabilities"
      }), "Capabilities"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "theme:read"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "formFactor:read"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "route:read"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "auth:status"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "mounts:read"
      }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "editor:read"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "contribute:any"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "contribute:direct"
      }), " — declared in the host's\nbuild-default registry (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "immediately-run-site-main/src/registry/defaults.ts"
      }), ")."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "develop",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "develop"
      }), "Develop"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-sh",
        children: "npm install\nnpm run dev      # standalone (no host chrome / no real save)\nnpm run build\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Pop the hood: fork it, rebind the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "modal.contribute"
      }), " region to your fork, and the\nsave dialog becomes yours."]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/README.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiY29kZSIsImgxIiwiaDIiLCJwIiwicHJlIiwic3Ryb25nIiwiX3Byb3ZpZGVDb21wb25lbnRzIiwiY29tcG9uZW50cyIsIkhlYWRpbmdBbmNob3IiLCJfbWlzc2luZ01keFJlZmVyZW5jZSIsImpzeHMiLCJGcmFnbWVudCIsImNoaWxkcmVuIiwiaWQiLCJqc3giLCJocmVmIiwiY2xhc3NOYW1lIiwiTURYQ29udGVudCIsIndyYXBwZXIiLCJNRFhMYXlvdXQiLCJfYyIsImNvbXBvbmVudCIsInBsYWNlIiwiRXJyb3IiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJSRUFETUUubWQiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgYTogXCJhXCIsXG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgaDE6IFwiaDFcIixcbiAgICBoMjogXCJoMlwiLFxuICAgIHA6IFwicFwiLFxuICAgIHByZTogXCJwcmVcIixcbiAgICBzdHJvbmc6IFwic3Ryb25nXCIsXG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9LCB7SGVhZGluZ0FuY2hvcn0gPSBfY29tcG9uZW50cztcbiAgaWYgKCFIZWFkaW5nQW5jaG9yKSBfbWlzc2luZ01keFJlZmVyZW5jZShcIkhlYWRpbmdBbmNob3JcIiwgdHJ1ZSk7XG4gIHJldHVybiA8PjxfY29tcG9uZW50cy5oMSBpZD1cImNvbnRyaWJ1dGVcIj48SGVhZGluZ0FuY2hvciBpZD1cImNvbnRyaWJ1dGVcIiAvPntcImNvbnRyaWJ1dGVcIn08L19jb21wb25lbnRzLmgxPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImNvbnRyaWJ1dGUgZGlhbG9nXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGFzIGFuIFwifTxfY29tcG9uZW50cy5hIGhyZWY9XCJodHRwczovL2ltbWVkaWF0ZWx5LnJ1blwiPntcImltbWVkaWF0ZWx5LnJ1blwifTwvX2NvbXBvbmVudHMuYT57XCIgYXBwIOKAlFxcbnRoZSBmaXJzdC1wYXJ0eSBzeXN0ZW0gYXBwIGJvdW5kIHRvIHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJtb2RhbC5jb250cmlidXRlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjaHJvbWUgcmVnaW9uXFxuKFVJX0FTX0FQUFNfU1BFQyDCpzUuMSkuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkl0IHNob3dzIHdoaWNoIGZpbGVzIHlvdSd2ZSBjaGFuZ2VkIGJ1dCBub3Qgc2F2ZWQgKHRoZSBlbGV2YXRlZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJlZGl0b3I6cmVhZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG5jaGFubmVsKSwgbGV0cyB5b3Ugd3JpdGUgYSBtZXNzYWdlIGFuZCBjaG9vc2UgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJwdWxsIHJlcXVlc3RcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgb3IgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJkaXJlY3RcXG5jb21taXRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIsIHRoZW4gc3RyZWFtcyB0aGUgc2F2ZSB0aHJvdWdoIHRoZSBob3N0J3MgY29udHJpYnV0aW9uIG9yY2hlc3RyYXRvciB2aWFcXG50aGUgU0RLJ3MgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY29udHJpYnV0ZSgpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgT0F1dGggdG9rZW4gbmV2ZXIgcmVhY2hlcyB0aGlzIGFwcC5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhlIGhvc3QgaG9sZHMgaXQgYW5kIHBlcmZvcm1zIGV2ZXJ5XFxucHJpdmlsZWdlZCBzdGVwICh0aGUgR2l0SHViIEFQSSwgdGhlIGZvcmssIHRoZSBQUik7IHRoaXMgYXBwIG9ubHkgcmVuZGVycyB0aGVcXG5zdHJlYW1lZCBwcm9ncmVzcy4gRGlyZWN0IGNvbW1pdCByZXF1aXJlcyB0aGUgZmlyc3QtcGFydHktb25seSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjb250cmlidXRlOmRpcmVjdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG5jYXBhYmlsaXR5IOKAlCBhIGZvcmsgdGhhdCBob2xkcyBvbmx5IFwifTxfY29tcG9uZW50cy5jb2RlPntcImNvbnRyaWJ1dGU6YW55XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpcyBsaW1pdGVkIHRvIHB1bGwgcmVxdWVzdHNcXG4odGhyZWF0IFQxMSkuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cImNhcGFiaWxpdGllc1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwiY2FwYWJpbGl0aWVzXCIgLz57XCJDYXBhYmlsaXRpZXNcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5jb2RlPntcInRoZW1lOnJlYWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmb3JtRmFjdG9yOnJlYWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyb3V0ZTpyZWFkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYXV0aDpzdGF0dXNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJtb3VudHM6cmVhZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZWRpdG9yOnJlYWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjb250cmlidXRlOmFueVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNvbnRyaWJ1dGU6ZGlyZWN0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgZGVjbGFyZWQgaW4gdGhlIGhvc3Qnc1xcbmJ1aWxkLWRlZmF1bHQgcmVnaXN0cnkgKFwifTxfY29tcG9uZW50cy5jb2RlPntcImltbWVkaWF0ZWx5LXJ1bi1zaXRlLW1haW4vc3JjL3JlZ2lzdHJ5L2RlZmF1bHRzLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cImRldmVsb3BcIj48SGVhZGluZ0FuY2hvciBpZD1cImRldmVsb3BcIiAvPntcIkRldmVsb3BcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wcmU+PF9jb21wb25lbnRzLmNvZGUgY2xhc3NOYW1lPVwibGFuZ3VhZ2Utc2hcIj57XCJucG0gaW5zdGFsbFxcbm5wbSBydW4gZGV2ICAgICAgIyBzdGFuZGFsb25lIChubyBob3N0IGNocm9tZSAvIG5vIHJlYWwgc2F2ZSlcXG5ucG0gcnVuIGJ1aWxkXFxuXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMucHJlPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlBvcCB0aGUgaG9vZDogZm9yayBpdCwgcmViaW5kIHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJtb2RhbC5jb250cmlidXRlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiByZWdpb24gdG8geW91ciBmb3JrLCBhbmQgdGhlXFxuc2F2ZSBkaWFsb2cgYmVjb21lcyB5b3Vycy5cIn08L19jb21wb25lbnRzLnA+PC8+O1xufVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTURYQ29udGVudChwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHt3cmFwcGVyOiBNRFhMYXlvdXR9ID0ge1xuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfTtcbiAgcmV0dXJuIE1EWExheW91dCA/IDxNRFhMYXlvdXQgey4uLnByb3BzfT48X2NyZWF0ZU1keENvbnRlbnQgey4uLnByb3BzfSAvPjwvTURYTGF5b3V0PiA6IF9jcmVhdGVNZHhDb250ZW50KHByb3BzKTtcbn1cbmZ1bmN0aW9uIF9taXNzaW5nTWR4UmVmZXJlbmNlKGlkLCBjb21wb25lbnQsIHBsYWNlKSB7XG4gIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIFwiICsgKGNvbXBvbmVudCA/IFwiY29tcG9uZW50XCIgOiBcIm9iamVjdFwiKSArIFwiIGBcIiArIGlkICsgXCJgIHRvIGJlIGRlZmluZWQ6IHlvdSBsaWtlbHkgZm9yZ290IHRvIGltcG9ydCwgcGFzcywgb3IgcHJvdmlkZSBpdC5cIiArIChwbGFjZSA/IFwiXFxuSXTigJlzIHJlZmVyZW5jZWQgaW4geW91ciBjb2RlIGF0IGBcIiArIHBsYWNlICsgXCJgIGluIGAvYXBwL1JFQURNRS5tZGBcIiA6IFwiXCIpKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQXdGLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUZ4RjtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU1DLFdBQVcsR0FBRztNQUNsQkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsSUFBSSxFQUFFLE1BQU07TUFDWkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsR0FBRyxFQUFFLEtBQUs7TUFDVkMsTUFBTSxFQUFFLFFBQVE7TUFDaEIsR0FBRyxJQUFBQyw2QkFBa0IsRUFBQyxDQUFDO01BQ3ZCLEdBQUdULEtBQUssQ0FBQ1U7SUFDWCxDQUFDO0lBQUU7TUFBQ0M7SUFBYSxDQUFDLEdBQUdWLFdBQVc7RUFDaEMsSUFBSSxDQUFDVSxhQUFhLEVBQUVDLG9CQUFvQixDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUM7RUFDL0Qsb0JBQU8sSUFBQWQsV0FBQSxDQUFBZSxJQUFBLEVBQUFmLFdBQUEsQ0FBQWdCLFFBQUE7SUFBQUMsUUFBQSxnQkFBRSxJQUFBakIsV0FBQSxDQUFBZSxJQUFBLEVBQUNaLFdBQVcsQ0FBQ0csRUFBRTtNQUFDWSxFQUFFLEVBQUMsWUFBWTtNQUFBRCxRQUFBLGdCQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVksQ0FBRSxDQUFDLEVBQUMsWUFBWTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQWUsSUFBQSxFQUFDWixXQUFXLENBQUNLLENBQUM7TUFBQVMsUUFBQSxHQUFFLE1BQU0sZUFBQyxJQUFBakIsV0FBQSxDQUFBbUIsR0FBQSxFQUFDaEIsV0FBVyxDQUFDTyxNQUFNO1FBQUFPLFFBQUEsRUFBRTtNQUFtQixDQUFxQixDQUFDLEVBQUMsU0FBUyxlQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNoQixXQUFXLENBQUNDLENBQUM7UUFBQ2dCLElBQUksRUFBQyx5QkFBeUI7UUFBQUgsUUFBQSxFQUFFO01BQWlCLENBQWdCLENBQUMsRUFBQyxrREFBa0QsZUFBQyxJQUFBakIsV0FBQSxDQUFBbUIsR0FBQSxFQUFDaEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFZLFFBQUEsRUFBRTtNQUFrQixDQUFtQixDQUFDLEVBQUMseUNBQXlDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBakIsV0FBQSxDQUFBZSxJQUFBLEVBQUNaLFdBQVcsQ0FBQ0ssQ0FBQztNQUFBUyxRQUFBLEdBQUUsa0VBQWtFLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2hCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBWSxRQUFBLEVBQUU7TUFBYSxDQUFtQixDQUFDLEVBQUMsa0RBQWtELGVBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2hCLFdBQVcsQ0FBQ08sTUFBTTtRQUFBTyxRQUFBLEVBQUU7TUFBYyxDQUFxQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNoQixXQUFXLENBQUNPLE1BQU07UUFBQU8sUUFBQSxFQUFFO01BQWdCLENBQXFCLENBQUMsRUFBQyxzRkFBc0YsZUFBQyxJQUFBakIsV0FBQSxDQUFBbUIsR0FBQSxFQUFDaEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFZLFFBQUEsRUFBRTtNQUFjLENBQW1CLENBQUMsRUFBQyxHQUFHO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBakIsV0FBQSxDQUFBZSxJQUFBLEVBQUNaLFdBQVcsQ0FBQ0ssQ0FBQztNQUFBUyxRQUFBLGdCQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNoQixXQUFXLENBQUNPLE1BQU07UUFBQU8sUUFBQSxFQUFFO01BQXlDLENBQXFCLENBQUMsRUFBQyx1TEFBdUwsZUFBQyxJQUFBakIsV0FBQSxDQUFBbUIsR0FBQSxFQUFDaEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFZLFFBQUEsRUFBRTtNQUFtQixDQUFtQixDQUFDLEVBQUMsd0NBQXdDLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2hCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBWSxRQUFBLEVBQUU7TUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLDZDQUE2QztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQWUsSUFBQSxFQUFDWixXQUFXLENBQUNJLEVBQUU7TUFBQ1csRUFBRSxFQUFDLGNBQWM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBakIsV0FBQSxDQUFBbUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFjLENBQUUsQ0FBQyxFQUFDLGNBQWM7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFsQixXQUFBLENBQUFlLElBQUEsRUFBQ1osV0FBVyxDQUFDSyxDQUFDO01BQUFTLFFBQUEsZ0JBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2hCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBWSxRQUFBLEVBQUU7TUFBWSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNoQixXQUFXLENBQUNFLElBQUk7UUFBQVksUUFBQSxFQUFFO01BQWlCLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2hCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBWSxRQUFBLEVBQUU7TUFBWSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNoQixXQUFXLENBQUNFLElBQUk7UUFBQVksUUFBQSxFQUFFO01BQWEsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBakIsV0FBQSxDQUFBbUIsR0FBQSxFQUFDaEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFZLFFBQUEsRUFBRTtNQUFhLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2hCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBWSxRQUFBLEVBQUU7TUFBYSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNoQixXQUFXLENBQUNFLElBQUk7UUFBQVksUUFBQSxFQUFFO01BQWdCLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2hCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBWSxRQUFBLEVBQUU7TUFBbUIsQ0FBbUIsQ0FBQyxFQUFDLHFEQUFxRCxlQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNoQixXQUFXLENBQUNFLElBQUk7UUFBQVksUUFBQSxFQUFFO01BQW9ELENBQW1CLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBakIsV0FBQSxDQUFBZSxJQUFBLEVBQUNaLFdBQVcsQ0FBQ0ksRUFBRTtNQUFDVyxFQUFFLEVBQUMsU0FBUztNQUFBRCxRQUFBLGdCQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVMsQ0FBRSxDQUFDLEVBQUMsU0FBUztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2hCLFdBQVcsQ0FBQ00sR0FBRztNQUFBUSxRQUFBLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2hCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFDZ0IsU0FBUyxFQUFDLGFBQWE7UUFBQUosUUFBQSxFQUFFO01BQTZGLENBQW1CO0lBQUMsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBakIsV0FBQSxDQUFBZSxJQUFBLEVBQUNaLFdBQVcsQ0FBQ0ssQ0FBQztNQUFBUyxRQUFBLEdBQUUsb0NBQW9DLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2hCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBWSxRQUFBLEVBQUU7TUFBa0IsQ0FBbUIsQ0FBQyxFQUFDLDJEQUEyRDtJQUFBLENBQWdCLENBQUM7RUFBQSxDQUFFLENBQUM7QUFDMW9GO0FBQ2UsU0FBU0ssVUFBVUEsQ0FBQ3BCLEtBQUssR0FBRyxDQUFDLENBQUMsRUFBRTtFQUM3QyxNQUFNO0lBQUNxQixPQUFPLEVBQUVDO0VBQVMsQ0FBQyxHQUFHO0lBQzNCLEdBQUcsSUFBQWIsNkJBQWtCLEVBQUMsQ0FBQztJQUN2QixHQUFHVCxLQUFLLENBQUNVO0VBQ1gsQ0FBQztFQUNELE9BQU9ZLFNBQVMsZ0JBQUcsSUFBQXhCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ0ssU0FBUztJQUFBLEdBQUt0QixLQUFLO0lBQUFlLFFBQUEsZUFBRSxJQUFBakIsV0FBQSxDQUFBbUIsR0FBQSxFQUFDbEIsaUJBQWlCO01BQUEsR0FBS0M7SUFBSyxDQUFHO0VBQUMsQ0FBVyxDQUFDLEdBQUdELGlCQUFpQixDQUFDQyxLQUFLLENBQUM7QUFDbEg7QUFBQ3VCLEVBQUEsR0FOdUJILFVBQVU7QUFPbEMsU0FBU1Isb0JBQW9CQSxDQUFDSSxFQUFFLEVBQUVRLFNBQVMsRUFBRUMsS0FBSyxFQUFFO0VBQ2xELE1BQU0sSUFBSUMsS0FBSyxDQUFDLFdBQVcsSUFBSUYsU0FBUyxHQUFHLFdBQVcsR0FBRyxRQUFRLENBQUMsR0FBRyxJQUFJLEdBQUdSLEVBQUUsR0FBRyxvRUFBb0UsSUFBSVMsS0FBSyxHQUFHLHFDQUFxQyxHQUFHQSxLQUFLLEdBQUcsdUJBQXVCLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDalA7QUFBQyxJQUFBRixFQUFBO0FBQUFJLFlBQUEsQ0FBQUosRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}