var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      code: "code",
      del: "del",
      h1: "h1",
      h2: "h2",
      li: "li",
      p: "p",
      strong: "strong",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "findings-edit-file",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "findings-edit-file"
      }), "FINDINGS — edit-file"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Recorded by the 2026-06 code-verification pass (R3-124; plan ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "08-system-apps.md"
      }), ").\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Record / verify only."
      }), " Gates green (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "npm run build"
      }), " + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "npm run lint"
      }), ")."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "spec-refs-phase-1-verified-current",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "spec-refs-phase-1-verified-current"
      }), "Spec-refs (Phase 1 — verified current)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "provides: edit-file@1.0"
      }), ". Citations resolve correctly:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "EditFile.tsx:1"
        }), " → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "UI_AS_APPS_SPEC §5.7"
        }), " (Task invocation) / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "§8.7"
        }), "\n(Permissions as file access — scoped mounts). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Both § exist and match"
        }), " (§5.7\n\"Task invocation\", §8.7 \"Permissions as file access (scoped mounts)\")."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "App.tsx:2,6"
        }), " → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "§5.7/§8.7"
        }), "; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "fs.ts:12"
        }), " → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "§8.7"
        }), " (a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ro"
        }), " delegation makes\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "writeFile"
        }), " throw ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "EROFS"
        }), " host-side). Re-verified 2026-10-01 (the fs.ts header\nrewrite moved the citation off line 5). Current."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The app receives a chrooted single-file cap (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "/task/<slot>/file/<name>"
      }), ") and uses\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "useTaskInput"
      }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "completeTask"
      }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "cancelTask"
      }), " — the Done-spec ↔ code mapping checks\nout. Mapping is trivial enough to live in inline comments; no separate\nCODE_SPEC_REFERENCES.md needed."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sdk-version-skew-resolved-2026-10-01",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sdk-version-skew-resolved-2026-10-01"
      }), "SDK-version skew (resolved 2026-10-01)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.del, {
        children: ["Pins ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "@immediately-run/sdk"
        }), " at ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "0.2.8"
          })
        }), " … Coordinated bump owed; do not bump here."]
      }), "\nResolved by the R3-447 fix (#10): the pin is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "0.75.0"
        })
      }), " (exact, per the fleet's\npost-2026-08 convention that each app pins its own current SDK — ways_of_working §6;\nthe June \"coordinated bump\" concern is obsolete: the listed tiers ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "0.2.8"
      }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "0.8.1"
      }), "/\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "0.11.0"
      }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "^0.12.0"
      }), " predate it, and the entry was already stale at ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "^0.13.0"
      }), "). The bump\nwas FORCED, not discretionary: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "^0.13.0"
      }), " predates the SDK's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "/fs"
      }), " subpath the fs\naccessor now delegates to."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "vocabulary-phase-2",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "vocabulary-phase-2"
      }), "Vocabulary (Phase 2)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["No ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "kernel"
      }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "principal"
      }), "-as-grantee in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/"
      }), ". ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "main.tsx"
      }), " carries no app\nlogic/CSS. Conformant."]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/REFACTOR_CANDIDATES.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJjb2RlIiwiZGVsIiwiaDEiLCJoMiIsImxpIiwicCIsInN0cm9uZyIsInVsIiwiX3Byb3ZpZGVDb21wb25lbnRzIiwiY29tcG9uZW50cyIsIkhlYWRpbmdBbmNob3IiLCJfbWlzc2luZ01keFJlZmVyZW5jZSIsImpzeHMiLCJGcmFnbWVudCIsImNoaWxkcmVuIiwiaWQiLCJqc3giLCJNRFhDb250ZW50Iiwid3JhcHBlciIsIk1EWExheW91dCIsIl9jIiwiY29tcG9uZW50IiwicGxhY2UiLCJFcnJvciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlJFRkFDVE9SX0NBTkRJREFURVMubWQiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgZGVsOiBcImRlbFwiLFxuICAgIGgxOiBcImgxXCIsXG4gICAgaDI6IFwiaDJcIixcbiAgICBsaTogXCJsaVwiLFxuICAgIHA6IFwicFwiLFxuICAgIHN0cm9uZzogXCJzdHJvbmdcIixcbiAgICB1bDogXCJ1bFwiLFxuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfSwge0hlYWRpbmdBbmNob3J9ID0gX2NvbXBvbmVudHM7XG4gIGlmICghSGVhZGluZ0FuY2hvcikgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJIZWFkaW5nQW5jaG9yXCIsIHRydWUpO1xuICByZXR1cm4gPD48X2NvbXBvbmVudHMuaDEgaWQ9XCJmaW5kaW5ncy1lZGl0LWZpbGVcIj48SGVhZGluZ0FuY2hvciBpZD1cImZpbmRpbmdzLWVkaXQtZmlsZVwiIC8+e1wiRklORElOR1Mg4oCUIGVkaXQtZmlsZVwifTwvX2NvbXBvbmVudHMuaDE+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiUmVjb3JkZWQgYnkgdGhlIDIwMjYtMDYgY29kZS12ZXJpZmljYXRpb24gcGFzcyAoUjMtMTI0OyBwbGFuIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjA4LXN5c3RlbS1hcHBzLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikuXFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJSZWNvcmQgLyB2ZXJpZnkgb25seS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgR2F0ZXMgZ3JlZW4gKFwifTxfY29tcG9uZW50cy5jb2RlPntcIm5wbSBydW4gYnVpbGRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibnBtIHJ1biBsaW50XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInNwZWMtcmVmcy1waGFzZS0xLXZlcmlmaWVkLWN1cnJlbnRcIj48SGVhZGluZ0FuY2hvciBpZD1cInNwZWMtcmVmcy1waGFzZS0xLXZlcmlmaWVkLWN1cnJlbnRcIiAvPntcIlNwZWMtcmVmcyAoUGhhc2UgMSDigJQgdmVyaWZpZWQgY3VycmVudClcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5jb2RlPntcInByb3ZpZGVzOiBlZGl0LWZpbGVAMS4wXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi4gQ2l0YXRpb25zIHJlc29sdmUgY29ycmVjdGx5OlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5jb2RlPntcIkVkaXRGaWxlLnRzeDoxXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDihpIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiVUlfQVNfQVBQU19TUEVDIMKnNS43XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoVGFzayBpbnZvY2F0aW9uKSAvIFwifTxfY29tcG9uZW50cy5jb2RlPntcIsKnOC43XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIlxcbihQZXJtaXNzaW9ucyBhcyBmaWxlIGFjY2VzcyDigJQgc2NvcGVkIG1vdW50cykuIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiQm90aCDCpyBleGlzdCBhbmQgbWF0Y2hcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKMKnNS43XFxuXFxcIlRhc2sgaW52b2NhdGlvblxcXCIsIMKnOC43IFxcXCJQZXJtaXNzaW9ucyBhcyBmaWxlIGFjY2VzcyAoc2NvcGVkIG1vdW50cylcXFwiKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuY29kZT57XCJBcHAudHN4OjIsNlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oaSIFwifTxfY29tcG9uZW50cy5jb2RlPntcIsKnNS43L8KnOC43XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZnMudHM6MTJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKGkiBcIn08X2NvbXBvbmVudHMuY29kZT57XCLCpzguN1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKGEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicm9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGRlbGVnYXRpb24gbWFrZXNcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJ3cml0ZUZpbGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHRocm93IFwifTxfY29tcG9uZW50cy5jb2RlPntcIkVST0ZTXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBob3N0LXNpZGUpLiBSZS12ZXJpZmllZCAyMDI2LTEwLTAxICh0aGUgZnMudHMgaGVhZGVyXFxucmV3cml0ZSBtb3ZlZCB0aGUgY2l0YXRpb24gb2ZmIGxpbmUgNSkuIEN1cnJlbnQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSBhcHAgcmVjZWl2ZXMgYSBjaHJvb3RlZCBzaW5nbGUtZmlsZSBjYXAgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIi90YXNrLzxzbG90Pi9maWxlLzxuYW1lPlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpIGFuZCB1c2VzXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widXNlVGFza0lucHV0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJjb21wbGV0ZVRhc2tcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcImNhbmNlbFRhc2tcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCB0aGUgRG9uZS1zcGVjIOKGlCBjb2RlIG1hcHBpbmcgY2hlY2tzXFxub3V0LiBNYXBwaW5nIGlzIHRyaXZpYWwgZW5vdWdoIHRvIGxpdmUgaW4gaW5saW5lIGNvbW1lbnRzOyBubyBzZXBhcmF0ZVxcbkNPREVfU1BFQ19SRUZFUkVOQ0VTLm1kIG5lZWRlZC5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2RrLXZlcnNpb24tc2tldy1yZXNvbHZlZC0yMDI2LTEwLTAxXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZGstdmVyc2lvbi1za2V3LXJlc29sdmVkLTIwMjYtMTAtMDFcIiAvPntcIlNESy12ZXJzaW9uIHNrZXcgKHJlc29sdmVkIDIwMjYtMTAtMDEpXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuZGVsPntcIlBpbnMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQGltbWVkaWF0ZWx5LXJ1bi9zZGtcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGF0IFwifTxfY29tcG9uZW50cy5zdHJvbmc+PF9jb21wb25lbnRzLmNvZGU+e1wiMC4yLjhcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKApiBDb29yZGluYXRlZCBidW1wIG93ZWQ7IGRvIG5vdCBidW1wIGhlcmUuXCJ9PC9fY29tcG9uZW50cy5kZWw+e1wiXFxuUmVzb2x2ZWQgYnkgdGhlIFIzLTQ0NyBmaXggKCMxMCk6IHRoZSBwaW4gaXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz48X2NvbXBvbmVudHMuY29kZT57XCIwLjc1LjBcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChleGFjdCwgcGVyIHRoZSBmbGVldCdzXFxucG9zdC0yMDI2LTA4IGNvbnZlbnRpb24gdGhhdCBlYWNoIGFwcCBwaW5zIGl0cyBvd24gY3VycmVudCBTREsg4oCUIHdheXNfb2Zfd29ya2luZyDCpzY7XFxudGhlIEp1bmUgXFxcImNvb3JkaW5hdGVkIGJ1bXBcXFwiIGNvbmNlcm4gaXMgb2Jzb2xldGU6IHRoZSBsaXN0ZWQgdGllcnMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiMC4yLjhcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcIjAuOC4xXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCIwLjExLjBcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcIl4wLjEyLjBcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHByZWRhdGUgaXQsIGFuZCB0aGUgZW50cnkgd2FzIGFscmVhZHkgc3RhbGUgYXQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiXjAuMTMuMFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLiBUaGUgYnVtcFxcbndhcyBGT1JDRUQsIG5vdCBkaXNjcmV0aW9uYXJ5OiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJeMC4xMy4wXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBwcmVkYXRlcyB0aGUgU0RLJ3MgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiL2ZzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBzdWJwYXRoIHRoZSBmc1xcbmFjY2Vzc29yIG5vdyBkZWxlZ2F0ZXMgdG8uXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInZvY2FidWxhcnktcGhhc2UtMlwiPjxIZWFkaW5nQW5jaG9yIGlkPVwidm9jYWJ1bGFyeS1waGFzZS0yXCIgLz57XCJWb2NhYnVsYXJ5IChQaGFzZSAyKVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiTm8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wia2VybmVsXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAvIFwifTxfY29tcG9uZW50cy5jb2RlPntcInByaW5jaXBhbFwifTwvX2NvbXBvbmVudHMuY29kZT57XCItYXMtZ3JhbnRlZSBpbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibWFpbi50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNhcnJpZXMgbm8gYXBwXFxubG9naWMvQ1NTLiBDb25mb3JtYW50LlwifTwvX2NvbXBvbmVudHMucD48Lz47XG59XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNRFhDb250ZW50KHByb3BzID0ge30pIHtcbiAgY29uc3Qge3dyYXBwZXI6IE1EWExheW91dH0gPSB7XG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9O1xuICByZXR1cm4gTURYTGF5b3V0ID8gPE1EWExheW91dCB7Li4ucHJvcHN9PjxfY3JlYXRlTWR4Q29udGVudCB7Li4ucHJvcHN9IC8+PC9NRFhMYXlvdXQ+IDogX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpO1xufVxuZnVuY3Rpb24gX21pc3NpbmdNZHhSZWZlcmVuY2UoaWQsIGNvbXBvbmVudCwgcGxhY2UpIHtcbiAgdGhyb3cgbmV3IEVycm9yKFwiRXhwZWN0ZWQgXCIgKyAoY29tcG9uZW50ID8gXCJjb21wb25lbnRcIiA6IFwib2JqZWN0XCIpICsgXCIgYFwiICsgaWQgKyBcImAgdG8gYmUgZGVmaW5lZDogeW91IGxpa2VseSBmb3Jnb3QgdG8gaW1wb3J0LCBwYXNzLCBvciBwcm92aWRlIGl0LlwiICsgKHBsYWNlID8gXCJcXG5JdOKAmXMgcmVmZXJlbmNlZCBpbiB5b3VyIGNvZGUgYXQgYFwiICsgcGxhY2UgKyBcImAgaW4gYC9hcHAvUkVGQUNUT1JfQ0FORElEQVRFUy5tZGBcIiA6IFwiXCIpKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQXdGLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUZ4RjtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU1DLFdBQVcsR0FBRztNQUNsQkMsSUFBSSxFQUFFLE1BQU07TUFDWkMsR0FBRyxFQUFFLEtBQUs7TUFDVkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsTUFBTSxFQUFFLFFBQVE7TUFDaEJDLEVBQUUsRUFBRSxJQUFJO01BQ1IsR0FBRyxJQUFBQyw2QkFBa0IsRUFBQyxDQUFDO01BQ3ZCLEdBQUdWLEtBQUssQ0FBQ1c7SUFDWCxDQUFDO0lBQUU7TUFBQ0M7SUFBYSxDQUFDLEdBQUdYLFdBQVc7RUFDaEMsSUFBSSxDQUFDVyxhQUFhLEVBQUVDLG9CQUFvQixDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUM7RUFDL0Qsb0JBQU8sSUFBQWYsV0FBQSxDQUFBZ0IsSUFBQSxFQUFBaEIsV0FBQSxDQUFBaUIsUUFBQTtJQUFBQyxRQUFBLGdCQUFFLElBQUFsQixXQUFBLENBQUFnQixJQUFBLEVBQUNiLFdBQVcsQ0FBQ0csRUFBRTtNQUFDYSxFQUFFLEVBQUMsb0JBQW9CO01BQUFELFFBQUEsZ0JBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBb0IsQ0FBRSxDQUFDLEVBQUMsc0JBQXNCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBZ0IsSUFBQSxFQUFDYixXQUFXLENBQUNNLENBQUM7TUFBQVMsUUFBQSxHQUFFLCtEQUErRCxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7UUFBQWMsUUFBQSxFQUFFO01BQW1CLENBQW1CLENBQUMsRUFBQyxNQUFNLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBdUIsQ0FBcUIsQ0FBQyxFQUFDLGdCQUFnQixlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7UUFBQWMsUUFBQSxFQUFFO01BQWUsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDQyxJQUFJO1FBQUFjLFFBQUEsRUFBRTtNQUFjLENBQW1CLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbEIsV0FBQSxDQUFBZ0IsSUFBQSxFQUFDYixXQUFXLENBQUNJLEVBQUU7TUFBQ1ksRUFBRSxFQUFDLG9DQUFvQztNQUFBRCxRQUFBLGdCQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQW9DLENBQUUsQ0FBQyxFQUFDLHdDQUF3QztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQWdCLElBQUEsRUFBQ2IsV0FBVyxDQUFDTSxDQUFDO01BQUFTLFFBQUEsZ0JBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBYyxRQUFBLEVBQUU7TUFBeUIsQ0FBbUIsQ0FBQyxFQUFDLGdDQUFnQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQWdCLElBQUEsRUFBQ2IsV0FBVyxDQUFDUSxFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQWdCLElBQUEsRUFBQ2IsV0FBVyxDQUFDSyxFQUFFO1FBQUFVLFFBQUEsZ0JBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDQyxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUFzQixDQUFtQixDQUFDLEVBQUMsdUJBQXVCLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBTSxDQUFtQixDQUFDLEVBQUMsa0RBQWtELGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBd0IsQ0FBcUIsQ0FBQyxFQUFDLG9GQUFvRjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQWdCLElBQUEsRUFBQ2IsV0FBVyxDQUFDSyxFQUFFO1FBQUFVLFFBQUEsZ0JBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBYSxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7VUFBQWMsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDQyxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBTSxDQUFtQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7VUFBQWMsUUFBQSxFQUFFO1FBQUksQ0FBbUIsQ0FBQyxFQUFDLHFCQUFxQixlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7VUFBQWMsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLFNBQVMsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDQyxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUFPLENBQW1CLENBQUMsRUFBQyx5R0FBeUc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQWdCLElBQUEsRUFBQ2IsV0FBVyxDQUFDTSxDQUFDO01BQUFTLFFBQUEsR0FBRSwrQ0FBK0MsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDQyxJQUFJO1FBQUFjLFFBQUEsRUFBRTtNQUEwQixDQUFtQixDQUFDLEVBQUMsY0FBYyxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7UUFBQWMsUUFBQSxFQUFFO01BQWMsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDQyxJQUFJO1FBQUFjLFFBQUEsRUFBRTtNQUFjLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBYyxRQUFBLEVBQUU7TUFBWSxDQUFtQixDQUFDLEVBQUMsaUpBQWlKO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbEIsV0FBQSxDQUFBZ0IsSUFBQSxFQUFDYixXQUFXLENBQUNJLEVBQUU7TUFBQ1ksRUFBRSxFQUFDLHNDQUFzQztNQUFBRCxRQUFBLGdCQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQXNDLENBQUUsQ0FBQyxFQUFDLHdDQUF3QztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQWdCLElBQUEsRUFBQ2IsV0FBVyxDQUFDTSxDQUFDO01BQUFTLFFBQUEsZ0JBQUMsSUFBQWxCLFdBQUEsQ0FBQWdCLElBQUEsRUFBQ2IsV0FBVyxDQUFDRSxHQUFHO1FBQUFhLFFBQUEsR0FBRSxPQUFPLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBc0IsQ0FBbUIsQ0FBQyxFQUFDLE1BQU0sZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDTyxNQUFNO1VBQUFRLFFBQUEsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDQyxJQUFJO1lBQUFjLFFBQUEsRUFBRTtVQUFPLENBQW1CO1FBQUMsQ0FBb0IsQ0FBQyxFQUFDLDZDQUE2QztNQUFBLENBQWtCLENBQUMsRUFBQyxpREFBaUQsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDTyxNQUFNO1FBQUFRLFFBQUEsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDQyxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUFRLENBQW1CO01BQUMsQ0FBb0IsQ0FBQyxFQUFDLHNMQUFzTCxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7UUFBQWMsUUFBQSxFQUFFO01BQU8sQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDQyxJQUFJO1FBQUFjLFFBQUEsRUFBRTtNQUFPLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBYyxRQUFBLEVBQUU7TUFBUSxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7UUFBQWMsUUFBQSxFQUFFO01BQVMsQ0FBbUIsQ0FBQyxFQUFDLGtEQUFrRCxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7UUFBQWMsUUFBQSxFQUFFO01BQVMsQ0FBbUIsQ0FBQyxFQUFDLDhDQUE4QyxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7UUFBQWMsUUFBQSxFQUFFO01BQVMsQ0FBbUIsQ0FBQyxFQUFDLHNCQUFzQixlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7UUFBQWMsUUFBQSxFQUFFO01BQUssQ0FBbUIsQ0FBQyxFQUFDLDZDQUE2QztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQWdCLElBQUEsRUFBQ2IsV0FBVyxDQUFDSSxFQUFFO01BQUNZLEVBQUUsRUFBQyxvQkFBb0I7TUFBQUQsUUFBQSxnQkFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFvQixDQUFFLENBQUMsRUFBQyxzQkFBc0I7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFnQixJQUFBLEVBQUNiLFdBQVcsQ0FBQ00sQ0FBQztNQUFBUyxRQUFBLEdBQUUsS0FBSyxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7UUFBQWMsUUFBQSxFQUFFO01BQVEsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDQyxJQUFJO1FBQUFjLFFBQUEsRUFBRTtNQUFXLENBQW1CLENBQUMsRUFBQyxpQkFBaUIsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDQyxJQUFJO1FBQUFjLFFBQUEsRUFBRTtNQUFNLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBYyxRQUFBLEVBQUU7TUFBVSxDQUFtQixDQUFDLEVBQUMseUNBQXlDO0lBQUEsQ0FBZ0IsQ0FBQztFQUFBLENBQUUsQ0FBQztBQUNyK0g7QUFDZSxTQUFTRyxVQUFVQSxDQUFDbkIsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFO0VBQzdDLE1BQU07SUFBQ29CLE9BQU8sRUFBRUM7RUFBUyxDQUFDLEdBQUc7SUFDM0IsR0FBRyxJQUFBWCw2QkFBa0IsRUFBQyxDQUFDO0lBQ3ZCLEdBQUdWLEtBQUssQ0FBQ1c7RUFDWCxDQUFDO0VBQ0QsT0FBT1UsU0FBUyxnQkFBRyxJQUFBdkIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDRyxTQUFTO0lBQUEsR0FBS3JCLEtBQUs7SUFBQWdCLFFBQUEsZUFBRSxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDbkIsaUJBQWlCO01BQUEsR0FBS0M7SUFBSyxDQUFHO0VBQUMsQ0FBVyxDQUFDLEdBQUdELGlCQUFpQixDQUFDQyxLQUFLLENBQUM7QUFDbEg7QUFBQ3NCLEVBQUEsR0FOdUJILFVBQVU7QUFPbEMsU0FBU04sb0JBQW9CQSxDQUFDSSxFQUFFLEVBQUVNLFNBQVMsRUFBRUMsS0FBSyxFQUFFO0VBQ2xELE1BQU0sSUFBSUMsS0FBSyxDQUFDLFdBQVcsSUFBSUYsU0FBUyxHQUFHLFdBQVcsR0FBRyxRQUFRLENBQUMsR0FBRyxJQUFJLEdBQUdOLEVBQUUsR0FBRyxvRUFBb0UsSUFBSU8sS0FBSyxHQUFHLHFDQUFxQyxHQUFHQSxLQUFLLEdBQUcsb0NBQW9DLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDOVA7QUFBQyxJQUFBRixFQUFBO0FBQUFJLFlBQUEsQ0FBQUosRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}