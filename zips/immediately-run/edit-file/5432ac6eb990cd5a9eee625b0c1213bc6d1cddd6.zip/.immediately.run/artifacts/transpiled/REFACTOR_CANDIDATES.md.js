var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      code: "code",
      h1: "h1",
      h2: "h2",
      li: "li",
      p: "p",
      strong: "strong",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "findings-edit-file",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "findings-edit-file"
      }), "FINDINGS — edit-file"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Recorded by the 2026-06 code-verification pass (R3-124; plan ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "08-system-apps.md"
      }), ").\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Record / verify only."
      }), " Gates green (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "npm run build"
      }), " + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "npm run lint"
      }), ")."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "spec-refs-phase-1-verified-current",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "spec-refs-phase-1-verified-current"
      }), "Spec-refs (Phase 1 — verified current)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "provides: edit-file@1.0"
      }), ". Citations resolve correctly:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "EditFile.tsx:1"
        }), " → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "UI_AS_APPS_SPEC §5.7"
        }), " (Task invocation) / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "§8.7"
        }), "\n(Permissions as file access — scoped mounts). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Both § exist and match"
        }), " (§5.7\n\"Task invocation\", §8.7 \"Permissions as file access (scoped mounts)\")."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "App.tsx:2,6"
        }), " → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "§5.7/§8.7"
        }), "; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "fs.ts:5"
        }), " → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "§8.7"
        }), " (a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ro"
        }), " delegation makes\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "writeFile"
        }), " throw ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "EROFS"
        }), " host-side). Current."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The app receives a chrooted single-file cap (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "/task/<slot>/file/<name>"
      }), ") and uses\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "useTaskInput"
      }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "completeTask"
      }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "cancelTask"
      }), " — the Done-spec ↔ code mapping checks\nout. Mapping is trivial enough to live in inline comments; no separate\nCODE_SPEC_REFERENCES.md needed."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sdk-version-skew-record-only",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sdk-version-skew-record-only"
      }), "SDK-version skew (record only)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Pins ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "@immediately-run/sdk"
      }), " at ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "0.2.8"
        })
      }), " (oldest fleet tier: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "0.2.8"
      }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "0.8.1"
      }), " /\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "0.11.0"
      }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "^0.12.0"
      }), "). Coordinated bump owed; do not bump here."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "vocabulary-phase-2",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "vocabulary-phase-2"
      }), "Vocabulary (Phase 2)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["No ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "kernel"
      }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "principal"
      }), "-as-grantee in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/"
      }), ". ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "main.tsx"
      }), " carries no app\nlogic/CSS. Conformant."]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/REFACTOR_CANDIDATES.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJjb2RlIiwiaDEiLCJoMiIsImxpIiwicCIsInN0cm9uZyIsInVsIiwiX3Byb3ZpZGVDb21wb25lbnRzIiwiY29tcG9uZW50cyIsIkhlYWRpbmdBbmNob3IiLCJfbWlzc2luZ01keFJlZmVyZW5jZSIsImpzeHMiLCJGcmFnbWVudCIsImNoaWxkcmVuIiwiaWQiLCJqc3giLCJNRFhDb250ZW50Iiwid3JhcHBlciIsIk1EWExheW91dCIsIl9jIiwiY29tcG9uZW50IiwicGxhY2UiLCJFcnJvciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlJFRkFDVE9SX0NBTkRJREFURVMubWQiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgaDE6IFwiaDFcIixcbiAgICBoMjogXCJoMlwiLFxuICAgIGxpOiBcImxpXCIsXG4gICAgcDogXCJwXCIsXG4gICAgc3Ryb25nOiBcInN0cm9uZ1wiLFxuICAgIHVsOiBcInVsXCIsXG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9LCB7SGVhZGluZ0FuY2hvcn0gPSBfY29tcG9uZW50cztcbiAgaWYgKCFIZWFkaW5nQW5jaG9yKSBfbWlzc2luZ01keFJlZmVyZW5jZShcIkhlYWRpbmdBbmNob3JcIiwgdHJ1ZSk7XG4gIHJldHVybiA8PjxfY29tcG9uZW50cy5oMSBpZD1cImZpbmRpbmdzLWVkaXQtZmlsZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiZmluZGluZ3MtZWRpdC1maWxlXCIgLz57XCJGSU5ESU5HUyDigJQgZWRpdC1maWxlXCJ9PC9fY29tcG9uZW50cy5oMT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJSZWNvcmRlZCBieSB0aGUgMjAyNi0wNiBjb2RlLXZlcmlmaWNhdGlvbiBwYXNzIChSMy0xMjQ7IHBsYW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiMDgtc3lzdGVtLWFwcHMubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKS5cXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlJlY29yZCAvIHZlcmlmeSBvbmx5LlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBHYXRlcyBncmVlbiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibnBtIHJ1biBidWlsZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJucG0gcnVuIGxpbnRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic3BlYy1yZWZzLXBoYXNlLTEtdmVyaWZpZWQtY3VycmVudFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic3BlYy1yZWZzLXBoYXNlLTEtdmVyaWZpZWQtY3VycmVudFwiIC8+e1wiU3BlYy1yZWZzIChQaGFzZSAxIOKAlCB2ZXJpZmllZCBjdXJyZW50KVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLmNvZGU+e1wicHJvdmlkZXM6IGVkaXQtZmlsZUAxLjBcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLiBDaXRhdGlvbnMgcmVzb2x2ZSBjb3JyZWN0bHk6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLmNvZGU+e1wiRWRpdEZpbGUudHN4OjFcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKGkiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJVSV9BU19BUFBTX1NQRUMgwqc1LjdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChUYXNrIGludm9jYXRpb24pIC8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiwqc4LjdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxuKFBlcm1pc3Npb25zIGFzIGZpbGUgYWNjZXNzIOKAlCBzY29wZWQgbW91bnRzKS4gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJCb3RoIMKnIGV4aXN0IGFuZCBtYXRjaFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAowqc1LjdcXG5cXFwiVGFzayBpbnZvY2F0aW9uXFxcIiwgwqc4LjcgXFxcIlBlcm1pc3Npb25zIGFzIGZpbGUgYWNjZXNzIChzY29wZWQgbW91bnRzKVxcXCIpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5jb2RlPntcIkFwcC50c3g6Miw2XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDihpIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiwqc1Ljcvwqc4LjdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiOyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmcy50czo1XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDihpIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiwqc4LjdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChhIFwifTxfY29tcG9uZW50cy5jb2RlPntcInJvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBkZWxlZ2F0aW9uIG1ha2VzXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wid3JpdGVGaWxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB0aHJvdyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJFUk9GU1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaG9zdC1zaWRlKS4gQ3VycmVudC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIGFwcCByZWNlaXZlcyBhIGNocm9vdGVkIHNpbmdsZS1maWxlIGNhcCAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiL3Rhc2svPHNsb3Q+L2ZpbGUvPG5hbWU+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikgYW5kIHVzZXNcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJ1c2VUYXNrSW5wdXRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcImNvbXBsZXRlVGFza1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2FuY2VsVGFza1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIHRoZSBEb25lLXNwZWMg4oaUIGNvZGUgbWFwcGluZyBjaGVja3NcXG5vdXQuIE1hcHBpbmcgaXMgdHJpdmlhbCBlbm91Z2ggdG8gbGl2ZSBpbiBpbmxpbmUgY29tbWVudHM7IG5vIHNlcGFyYXRlXFxuQ09ERV9TUEVDX1JFRkVSRU5DRVMubWQgbmVlZGVkLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZGstdmVyc2lvbi1za2V3LXJlY29yZC1vbmx5XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZGstdmVyc2lvbi1za2V3LXJlY29yZC1vbmx5XCIgLz57XCJTREstdmVyc2lvbiBza2V3IChyZWNvcmQgb25seSlcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlBpbnMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQGltbWVkaWF0ZWx5LXJ1bi9zZGtcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGF0IFwifTxfY29tcG9uZW50cy5zdHJvbmc+PF9jb21wb25lbnRzLmNvZGU+e1wiMC4yLjhcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChvbGRlc3QgZmxlZXQgdGllcjogXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiMC4yLjhcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIC8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiMC44LjFcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIC9cXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCIwLjExLjBcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIC8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiXjAuMTIuMFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLiBDb29yZGluYXRlZCBidW1wIG93ZWQ7IGRvIG5vdCBidW1wIGhlcmUuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInZvY2FidWxhcnktcGhhc2UtMlwiPjxIZWFkaW5nQW5jaG9yIGlkPVwidm9jYWJ1bGFyeS1waGFzZS0yXCIgLz57XCJWb2NhYnVsYXJ5IChQaGFzZSAyKVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiTm8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wia2VybmVsXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAvIFwifTxfY29tcG9uZW50cy5jb2RlPntcInByaW5jaXBhbFwifTwvX2NvbXBvbmVudHMuY29kZT57XCItYXMtZ3JhbnRlZSBpbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibWFpbi50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNhcnJpZXMgbm8gYXBwXFxubG9naWMvQ1NTLiBDb25mb3JtYW50LlwifTwvX2NvbXBvbmVudHMucD48Lz47XG59XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNRFhDb250ZW50KHByb3BzID0ge30pIHtcbiAgY29uc3Qge3dyYXBwZXI6IE1EWExheW91dH0gPSB7XG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9O1xuICByZXR1cm4gTURYTGF5b3V0ID8gPE1EWExheW91dCB7Li4ucHJvcHN9PjxfY3JlYXRlTWR4Q29udGVudCB7Li4ucHJvcHN9IC8+PC9NRFhMYXlvdXQ+IDogX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpO1xufVxuZnVuY3Rpb24gX21pc3NpbmdNZHhSZWZlcmVuY2UoaWQsIGNvbXBvbmVudCwgcGxhY2UpIHtcbiAgdGhyb3cgbmV3IEVycm9yKFwiRXhwZWN0ZWQgXCIgKyAoY29tcG9uZW50ID8gXCJjb21wb25lbnRcIiA6IFwib2JqZWN0XCIpICsgXCIgYFwiICsgaWQgKyBcImAgdG8gYmUgZGVmaW5lZDogeW91IGxpa2VseSBmb3Jnb3QgdG8gaW1wb3J0LCBwYXNzLCBvciBwcm92aWRlIGl0LlwiICsgKHBsYWNlID8gXCJcXG5JdOKAmXMgcmVmZXJlbmNlZCBpbiB5b3VyIGNvZGUgYXQgYFwiICsgcGxhY2UgKyBcImAgaW4gYC9hcHAvUkVGQUNUT1JfQ0FORElEQVRFUy5tZGBcIiA6IFwiXCIpKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQXdGLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUZ4RjtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU1DLFdBQVcsR0FBRztNQUNsQkMsSUFBSSxFQUFFLE1BQU07TUFDWkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsTUFBTSxFQUFFLFFBQVE7TUFDaEJDLEVBQUUsRUFBRSxJQUFJO01BQ1IsR0FBRyxJQUFBQyw2QkFBa0IsRUFBQyxDQUFDO01BQ3ZCLEdBQUdULEtBQUssQ0FBQ1U7SUFDWCxDQUFDO0lBQUU7TUFBQ0M7SUFBYSxDQUFDLEdBQUdWLFdBQVc7RUFDaEMsSUFBSSxDQUFDVSxhQUFhLEVBQUVDLG9CQUFvQixDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUM7RUFDL0Qsb0JBQU8sSUFBQWQsV0FBQSxDQUFBZSxJQUFBLEVBQUFmLFdBQUEsQ0FBQWdCLFFBQUE7SUFBQUMsUUFBQSxnQkFBRSxJQUFBakIsV0FBQSxDQUFBZSxJQUFBLEVBQUNaLFdBQVcsQ0FBQ0UsRUFBRTtNQUFDYSxFQUFFLEVBQUMsb0JBQW9CO01BQUFELFFBQUEsZ0JBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBb0IsQ0FBRSxDQUFDLEVBQUMsc0JBQXNCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbEIsV0FBQSxDQUFBZSxJQUFBLEVBQUNaLFdBQVcsQ0FBQ0ssQ0FBQztNQUFBUyxRQUFBLEdBQUUsK0RBQStELGVBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBYSxRQUFBLEVBQUU7TUFBbUIsQ0FBbUIsQ0FBQyxFQUFDLE1BQU0sZUFBQyxJQUFBakIsV0FBQSxDQUFBbUIsR0FBQSxFQUFDaEIsV0FBVyxDQUFDTSxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUF1QixDQUFxQixDQUFDLEVBQUMsZ0JBQWdCLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBYSxRQUFBLEVBQUU7TUFBZSxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNoQixXQUFXLENBQUNDLElBQUk7UUFBQWEsUUFBQSxFQUFFO01BQWMsQ0FBbUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFqQixXQUFBLENBQUFlLElBQUEsRUFBQ1osV0FBVyxDQUFDRyxFQUFFO01BQUNZLEVBQUUsRUFBQyxvQ0FBb0M7TUFBQUQsUUFBQSxnQkFBQyxJQUFBakIsV0FBQSxDQUFBbUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFvQyxDQUFFLENBQUMsRUFBQyx3Q0FBd0M7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFsQixXQUFBLENBQUFlLElBQUEsRUFBQ1osV0FBVyxDQUFDSyxDQUFDO01BQUFTLFFBQUEsZ0JBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBYSxRQUFBLEVBQUU7TUFBeUIsQ0FBbUIsQ0FBQyxFQUFDLGdDQUFnQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQWUsSUFBQSxFQUFDWixXQUFXLENBQUNPLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBakIsV0FBQSxDQUFBZSxJQUFBLEVBQUNaLFdBQVcsQ0FBQ0ksRUFBRTtRQUFBVSxRQUFBLGdCQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNoQixXQUFXLENBQUNDLElBQUk7VUFBQWEsUUFBQSxFQUFFO1FBQWdCLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2hCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBYSxRQUFBLEVBQUU7UUFBc0IsQ0FBbUIsQ0FBQyxFQUFDLHVCQUF1QixlQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNoQixXQUFXLENBQUNDLElBQUk7VUFBQWEsUUFBQSxFQUFFO1FBQU0sQ0FBbUIsQ0FBQyxFQUFDLGtEQUFrRCxlQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNoQixXQUFXLENBQUNNLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQXdCLENBQXFCLENBQUMsRUFBQyxvRkFBb0Y7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFqQixXQUFBLENBQUFlLElBQUEsRUFBQ1osV0FBVyxDQUFDSSxFQUFFO1FBQUFVLFFBQUEsZ0JBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2hCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBYSxRQUFBLEVBQUU7UUFBYSxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNoQixXQUFXLENBQUNDLElBQUk7VUFBQWEsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBakIsV0FBQSxDQUFBbUIsR0FBQSxFQUFDaEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFhLFFBQUEsRUFBRTtRQUFTLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2hCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBYSxRQUFBLEVBQUU7UUFBTSxDQUFtQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNoQixXQUFXLENBQUNDLElBQUk7VUFBQWEsUUFBQSxFQUFFO1FBQUksQ0FBbUIsQ0FBQyxFQUFDLHFCQUFxQixlQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNoQixXQUFXLENBQUNDLElBQUk7VUFBQWEsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLFNBQVMsZUFBQyxJQUFBakIsV0FBQSxDQUFBbUIsR0FBQSxFQUFDaEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFhLFFBQUEsRUFBRTtRQUFPLENBQW1CLENBQUMsRUFBQyx1QkFBdUI7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQWUsSUFBQSxFQUFDWixXQUFXLENBQUNLLENBQUM7TUFBQVMsUUFBQSxHQUFFLCtDQUErQyxlQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNoQixXQUFXLENBQUNDLElBQUk7UUFBQWEsUUFBQSxFQUFFO01BQTBCLENBQW1CLENBQUMsRUFBQyxjQUFjLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBYSxRQUFBLEVBQUU7TUFBYyxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNoQixXQUFXLENBQUNDLElBQUk7UUFBQWEsUUFBQSxFQUFFO01BQWMsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBakIsV0FBQSxDQUFBbUIsR0FBQSxFQUFDaEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFhLFFBQUEsRUFBRTtNQUFZLENBQW1CLENBQUMsRUFBQyxpSkFBaUo7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFqQixXQUFBLENBQUFlLElBQUEsRUFBQ1osV0FBVyxDQUFDRyxFQUFFO01BQUNZLEVBQUUsRUFBQyw4QkFBOEI7TUFBQUQsUUFBQSxnQkFBQyxJQUFBakIsV0FBQSxDQUFBbUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUE4QixDQUFFLENBQUMsRUFBQyxnQ0FBZ0M7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFsQixXQUFBLENBQUFlLElBQUEsRUFBQ1osV0FBVyxDQUFDSyxDQUFDO01BQUFTLFFBQUEsR0FBRSxPQUFPLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBYSxRQUFBLEVBQUU7TUFBc0IsQ0FBbUIsQ0FBQyxFQUFDLE1BQU0sZUFBQyxJQUFBakIsV0FBQSxDQUFBbUIsR0FBQSxFQUFDaEIsV0FBVyxDQUFDTSxNQUFNO1FBQUFRLFFBQUEsZUFBQyxJQUFBakIsV0FBQSxDQUFBbUIsR0FBQSxFQUFDaEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFhLFFBQUEsRUFBRTtRQUFPLENBQW1CO01BQUMsQ0FBb0IsQ0FBQyxFQUFDLHVCQUF1QixlQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNoQixXQUFXLENBQUNDLElBQUk7UUFBQWEsUUFBQSxFQUFFO01BQU8sQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBakIsV0FBQSxDQUFBbUIsR0FBQSxFQUFDaEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFhLFFBQUEsRUFBRTtNQUFPLENBQW1CLENBQUMsRUFBQyxNQUFNLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBYSxRQUFBLEVBQUU7TUFBUSxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNoQixXQUFXLENBQUNDLElBQUk7UUFBQWEsUUFBQSxFQUFFO01BQVMsQ0FBbUIsQ0FBQyxFQUFDLDZDQUE2QztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQWUsSUFBQSxFQUFDWixXQUFXLENBQUNHLEVBQUU7TUFBQ1ksRUFBRSxFQUFDLG9CQUFvQjtNQUFBRCxRQUFBLGdCQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQW9CLENBQUUsQ0FBQyxFQUFDLHNCQUFzQjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQWUsSUFBQSxFQUFDWixXQUFXLENBQUNLLENBQUM7TUFBQVMsUUFBQSxHQUFFLEtBQUssZUFBQyxJQUFBakIsV0FBQSxDQUFBbUIsR0FBQSxFQUFDaEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFhLFFBQUEsRUFBRTtNQUFRLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBYSxRQUFBLEVBQUU7TUFBVyxDQUFtQixDQUFDLEVBQUMsaUJBQWlCLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBYSxRQUFBLEVBQUU7TUFBTSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNoQixXQUFXLENBQUNDLElBQUk7UUFBQWEsUUFBQSxFQUFFO01BQVUsQ0FBbUIsQ0FBQyxFQUFDLHlDQUF5QztJQUFBLENBQWdCLENBQUM7RUFBQSxDQUFFLENBQUM7QUFDM3ZHO0FBQ2UsU0FBU0csVUFBVUEsQ0FBQ2xCLEtBQUssR0FBRyxDQUFDLENBQUMsRUFBRTtFQUM3QyxNQUFNO0lBQUNtQixPQUFPLEVBQUVDO0VBQVMsQ0FBQyxHQUFHO0lBQzNCLEdBQUcsSUFBQVgsNkJBQWtCLEVBQUMsQ0FBQztJQUN2QixHQUFHVCxLQUFLLENBQUNVO0VBQ1gsQ0FBQztFQUNELE9BQU9VLFNBQVMsZ0JBQUcsSUFBQXRCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ0csU0FBUztJQUFBLEdBQUtwQixLQUFLO0lBQUFlLFFBQUEsZUFBRSxJQUFBakIsV0FBQSxDQUFBbUIsR0FBQSxFQUFDbEIsaUJBQWlCO01BQUEsR0FBS0M7SUFBSyxDQUFHO0VBQUMsQ0FBVyxDQUFDLEdBQUdELGlCQUFpQixDQUFDQyxLQUFLLENBQUM7QUFDbEg7QUFBQ3FCLEVBQUEsR0FOdUJILFVBQVU7QUFPbEMsU0FBU04sb0JBQW9CQSxDQUFDSSxFQUFFLEVBQUVNLFNBQVMsRUFBRUMsS0FBSyxFQUFFO0VBQ2xELE1BQU0sSUFBSUMsS0FBSyxDQUFDLFdBQVcsSUFBSUYsU0FBUyxHQUFHLFdBQVcsR0FBRyxRQUFRLENBQUMsR0FBRyxJQUFJLEdBQUdOLEVBQUUsR0FBRyxvRUFBb0UsSUFBSU8sS0FBSyxHQUFHLHFDQUFxQyxHQUFHQSxLQUFLLEdBQUcsb0NBQW9DLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDOVA7QUFBQyxJQUFBRixFQUFBO0FBQUFJLFlBQUEsQ0FBQUosRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}