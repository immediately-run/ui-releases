var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = EditFile;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
var _fs = require("../fs");
require("./EditFile.css");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The edit-file task callee (UI_AS_APPS_SPEC §5.7/§8.7). Reads the delegated file
// path from `useTaskInput()` (the host rewrote the caller's `capFile` to a concrete
// `/task/<slot>/file/<name>` chroot path), lets the user edit it, and writes it back
// — then `completeTask({ saved })`. A `ro` delegation makes the save throw `EROFS`
// (the host-enforced read-only wall), which this surfaces. The host always owns
// dismiss (T28), so Escape/close work even if this never calls `cancelTask`.
const basename = p => p.split("/").filter(Boolean).pop() ?? p;
function EditFile() {
  _s();
  const input = (0, _sdk.useTaskInput)();
  const path = typeof input?.params.file === "string" ? input.params.file : null;
  const [content, setContent] = (0, _react.useState)(null);
  const [note, setNote] = (0, _react.useState)(null);
  const [saving, setSaving] = (0, _react.useState)(false);
  (0, _react.useEffect)(() => {
    if (!path) return;
    let live = true;
    (0, _fs.readFile)(path).then(c => live && setContent(c)).catch(() => {
      // A new/unreadable file → start empty; the save still proves write access.
      if (live) {
        setContent("");
        setNote("New or unreadable file — starting empty.");
      }
    });
    return () => {
      live = false;
    };
  }, [path]);
  const save = async () => {
    if (path == null || content == null) return;
    setSaving(true);
    setNote(null);
    try {
      await (0, _fs.writeFile)(path, content);
      (0, _sdk.completeTask)({
        saved: true
      });
    } catch (e) {
      // The host `ro`-attenuated the delegation → EROFS, never a silent failure.
      setNote(`Couldn't save: ${e?.message ?? "read-only"}.`);
      setSaving(false);
    }
  };
  if (!path) {
    return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "ef ef--empty",
      children: ["Open this by invoking the ", /*#__PURE__*/(0, _jsxRuntime.jsx)("code", {
        children: "edit-file"
      }), " task with a file capability."]
    });
  }
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "ef",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("header", {
      className: "ef-hd",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "ef-title",
        children: "Editing"
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("code", {
        className: "ef-path",
        title: path,
        children: basename(path)
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("textarea", {
      className: "ef-area",
      value: content ?? "",
      spellCheck: false,
      disabled: content === null,
      onChange: e => setContent(e.target.value),
      "aria-label": `Contents of ${basename(path)}`,
      placeholder: content === null ? "Loading…" : ""
    }), note && /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
      className: "ef-note",
      children: note
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("footer", {
      className: "ef-foot",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        type: "button",
        className: "ef-btn",
        onClick: () => (0, _sdk.cancelTask)(),
        children: "Cancel"
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        type: "button",
        className: "ef-btn ef-save",
        disabled: saving || content === null,
        onClick: save,
        children: saving ? "Saving…" : "Save"
      })]
    })]
  });
}
_s(EditFile, "1hBLAH1h3cdOlQNZJHCSXl/PgrM=", false, function () {
  return [_sdk.useTaskInput];
});
_c = EditFile;
var _c;
$RefreshReg$(_c, "EditFile");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NkayIsIl9mcyIsIl9qc3hSdW50aW1lIiwiX3MiLCIkUmVmcmVzaFNpZyQiLCJiYXNlbmFtZSIsInAiLCJzcGxpdCIsImZpbHRlciIsIkJvb2xlYW4iLCJwb3AiLCJFZGl0RmlsZSIsImlucHV0IiwidXNlVGFza0lucHV0IiwicGF0aCIsInBhcmFtcyIsImZpbGUiLCJjb250ZW50Iiwic2V0Q29udGVudCIsInVzZVN0YXRlIiwibm90ZSIsInNldE5vdGUiLCJzYXZpbmciLCJzZXRTYXZpbmciLCJ1c2VFZmZlY3QiLCJsaXZlIiwicmVhZEZpbGUiLCJ0aGVuIiwiYyIsImNhdGNoIiwic2F2ZSIsIndyaXRlRmlsZSIsImNvbXBsZXRlVGFzayIsInNhdmVkIiwiZSIsIm1lc3NhZ2UiLCJqc3hzIiwiY2xhc3NOYW1lIiwiY2hpbGRyZW4iLCJqc3giLCJ0aXRsZSIsInZhbHVlIiwic3BlbGxDaGVjayIsImRpc2FibGVkIiwib25DaGFuZ2UiLCJ0YXJnZXQiLCJwbGFjZWhvbGRlciIsInR5cGUiLCJvbkNsaWNrIiwiY2FuY2VsVGFzayIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiRWRpdEZpbGUudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIFRoZSBlZGl0LWZpbGUgdGFzayBjYWxsZWUgKFVJX0FTX0FQUFNfU1BFQyDCpzUuNy/CpzguNykuIFJlYWRzIHRoZSBkZWxlZ2F0ZWQgZmlsZVxuLy8gcGF0aCBmcm9tIGB1c2VUYXNrSW5wdXQoKWAgKHRoZSBob3N0IHJld3JvdGUgdGhlIGNhbGxlcidzIGBjYXBGaWxlYCB0byBhIGNvbmNyZXRlXG4vLyBgL3Rhc2svPHNsb3Q+L2ZpbGUvPG5hbWU+YCBjaHJvb3QgcGF0aCksIGxldHMgdGhlIHVzZXIgZWRpdCBpdCwgYW5kIHdyaXRlcyBpdCBiYWNrXG4vLyDigJQgdGhlbiBgY29tcGxldGVUYXNrKHsgc2F2ZWQgfSlgLiBBIGByb2AgZGVsZWdhdGlvbiBtYWtlcyB0aGUgc2F2ZSB0aHJvdyBgRVJPRlNgXG4vLyAodGhlIGhvc3QtZW5mb3JjZWQgcmVhZC1vbmx5IHdhbGwpLCB3aGljaCB0aGlzIHN1cmZhY2VzLiBUaGUgaG9zdCBhbHdheXMgb3duc1xuLy8gZGlzbWlzcyAoVDI4KSwgc28gRXNjYXBlL2Nsb3NlIHdvcmsgZXZlbiBpZiB0aGlzIG5ldmVyIGNhbGxzIGBjYW5jZWxUYXNrYC5cbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHVzZVRhc2tJbnB1dCwgY29tcGxldGVUYXNrLCBjYW5jZWxUYXNrIH0gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrXCI7XG5pbXBvcnQgeyByZWFkRmlsZSwgd3JpdGVGaWxlIH0gZnJvbSBcIi4uL2ZzXCI7XG5pbXBvcnQgXCIuL0VkaXRGaWxlLmNzc1wiO1xuXG5jb25zdCBiYXNlbmFtZSA9IChwOiBzdHJpbmcpOiBzdHJpbmcgPT4gcC5zcGxpdChcIi9cIikuZmlsdGVyKEJvb2xlYW4pLnBvcCgpID8/IHA7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEVkaXRGaWxlKCkge1xuICBjb25zdCBpbnB1dCA9IHVzZVRhc2tJbnB1dCgpO1xuICBjb25zdCBwYXRoID0gdHlwZW9mIGlucHV0Py5wYXJhbXMuZmlsZSA9PT0gXCJzdHJpbmdcIiA/IGlucHV0LnBhcmFtcy5maWxlIDogbnVsbDtcblxuICBjb25zdCBbY29udGVudCwgc2V0Q29udGVudF0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW25vdGUsIHNldE5vdGVdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtzYXZpbmcsIHNldFNhdmluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIXBhdGgpIHJldHVybjtcbiAgICBsZXQgbGl2ZSA9IHRydWU7XG4gICAgcmVhZEZpbGUocGF0aClcbiAgICAgIC50aGVuKChjKSA9PiBsaXZlICYmIHNldENvbnRlbnQoYykpXG4gICAgICAuY2F0Y2goKCkgPT4ge1xuICAgICAgICAvLyBBIG5ldy91bnJlYWRhYmxlIGZpbGUg4oaSIHN0YXJ0IGVtcHR5OyB0aGUgc2F2ZSBzdGlsbCBwcm92ZXMgd3JpdGUgYWNjZXNzLlxuICAgICAgICBpZiAobGl2ZSkge1xuICAgICAgICAgIHNldENvbnRlbnQoXCJcIik7XG4gICAgICAgICAgc2V0Tm90ZShcIk5ldyBvciB1bnJlYWRhYmxlIGZpbGUg4oCUIHN0YXJ0aW5nIGVtcHR5LlwiKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGxpdmUgPSBmYWxzZTtcbiAgICB9O1xuICB9LCBbcGF0aF0pO1xuXG4gIGNvbnN0IHNhdmUgPSBhc3luYyAoKSA9PiB7XG4gICAgaWYgKHBhdGggPT0gbnVsbCB8fCBjb250ZW50ID09IG51bGwpIHJldHVybjtcbiAgICBzZXRTYXZpbmcodHJ1ZSk7XG4gICAgc2V0Tm90ZShudWxsKTtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgd3JpdGVGaWxlKHBhdGgsIGNvbnRlbnQpO1xuICAgICAgY29tcGxldGVUYXNrKHsgc2F2ZWQ6IHRydWUgfSk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgLy8gVGhlIGhvc3QgYHJvYC1hdHRlbnVhdGVkIHRoZSBkZWxlZ2F0aW9uIOKGkiBFUk9GUywgbmV2ZXIgYSBzaWxlbnQgZmFpbHVyZS5cbiAgICAgIHNldE5vdGUoYENvdWxkbid0IHNhdmU6ICR7KGUgYXMgRXJyb3IpPy5tZXNzYWdlID8/IFwicmVhZC1vbmx5XCJ9LmApO1xuICAgICAgc2V0U2F2aW5nKGZhbHNlKTtcbiAgICB9XG4gIH07XG5cbiAgaWYgKCFwYXRoKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZWYgZWYtLWVtcHR5XCI+XG4gICAgICAgIE9wZW4gdGhpcyBieSBpbnZva2luZyB0aGUgPGNvZGU+ZWRpdC1maWxlPC9jb2RlPiB0YXNrIHdpdGggYSBmaWxlIGNhcGFiaWxpdHkuXG4gICAgICA8L2Rpdj5cbiAgICApO1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImVmXCI+XG4gICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImVmLWhkXCI+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImVmLXRpdGxlXCI+RWRpdGluZzwvc3Bhbj5cbiAgICAgICAgPGNvZGUgY2xhc3NOYW1lPVwiZWYtcGF0aFwiIHRpdGxlPXtwYXRofT5cbiAgICAgICAgICB7YmFzZW5hbWUocGF0aCl9XG4gICAgICAgIDwvY29kZT5cbiAgICAgIDwvaGVhZGVyPlxuICAgICAgPHRleHRhcmVhXG4gICAgICAgIGNsYXNzTmFtZT1cImVmLWFyZWFcIlxuICAgICAgICB2YWx1ZT17Y29udGVudCA/PyBcIlwifVxuICAgICAgICBzcGVsbENoZWNrPXtmYWxzZX1cbiAgICAgICAgZGlzYWJsZWQ9e2NvbnRlbnQgPT09IG51bGx9XG4gICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q29udGVudChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgIGFyaWEtbGFiZWw9e2BDb250ZW50cyBvZiAke2Jhc2VuYW1lKHBhdGgpfWB9XG4gICAgICAgIHBsYWNlaG9sZGVyPXtjb250ZW50ID09PSBudWxsID8gXCJMb2FkaW5n4oCmXCIgOiBcIlwifVxuICAgICAgLz5cbiAgICAgIHtub3RlICYmIDxwIGNsYXNzTmFtZT1cImVmLW5vdGVcIj57bm90ZX08L3A+fVxuICAgICAgPGZvb3RlciBjbGFzc05hbWU9XCJlZi1mb290XCI+XG4gICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImVmLWJ0blwiIG9uQ2xpY2s9eygpID0+IGNhbmNlbFRhc2soKX0+XG4gICAgICAgICAgQ2FuY2VsXG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgY2xhc3NOYW1lPVwiZWYtYnRuIGVmLXNhdmVcIlxuICAgICAgICAgIGRpc2FibGVkPXtzYXZpbmcgfHwgY29udGVudCA9PT0gbnVsbH1cbiAgICAgICAgICBvbkNsaWNrPXtzYXZlfVxuICAgICAgICA+XG4gICAgICAgICAge3NhdmluZyA/IFwiU2F2aW5n4oCmXCIgOiBcIlNhdmVcIn1cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Zvb3Rlcj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFNQSxJQUFBQSxNQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxJQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxHQUFBLEdBQUFGLE9BQUE7QUFDQUEsT0FBQTtBQUF3QixJQUFBRyxXQUFBLEdBQUFILE9BQUE7QUFBQSxJQUFBSSxFQUFBLEdBQUFDLFlBQUEsSUFUeEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTUEsTUFBTUMsUUFBUSxHQUFJQyxDQUFTLElBQWFBLENBQUMsQ0FBQ0MsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDQyxNQUFNLENBQUNDLE9BQU8sQ0FBQyxDQUFDQyxHQUFHLENBQUMsQ0FBQyxJQUFJSixDQUFDO0FBRWhFLFNBQVNLLFFBQVFBLENBQUEsRUFBRztFQUFBUixFQUFBO0VBQ2pDLE1BQU1TLEtBQUssR0FBRyxJQUFBQyxpQkFBWSxFQUFDLENBQUM7RUFDNUIsTUFBTUMsSUFBSSxHQUFHLE9BQU9GLEtBQUssRUFBRUcsTUFBTSxDQUFDQyxJQUFJLEtBQUssUUFBUSxHQUFHSixLQUFLLENBQUNHLE1BQU0sQ0FBQ0MsSUFBSSxHQUFHLElBQUk7RUFFOUUsTUFBTSxDQUFDQyxPQUFPLEVBQUVDLFVBQVUsQ0FBQyxHQUFHLElBQUFDLGVBQVEsRUFBZ0IsSUFBSSxDQUFDO0VBQzNELE1BQU0sQ0FBQ0MsSUFBSSxFQUFFQyxPQUFPLENBQUMsR0FBRyxJQUFBRixlQUFRLEVBQWdCLElBQUksQ0FBQztFQUNyRCxNQUFNLENBQUNHLE1BQU0sRUFBRUMsU0FBUyxDQUFDLEdBQUcsSUFBQUosZUFBUSxFQUFDLEtBQUssQ0FBQztFQUUzQyxJQUFBSyxnQkFBUyxFQUFDLE1BQU07SUFDZCxJQUFJLENBQUNWLElBQUksRUFBRTtJQUNYLElBQUlXLElBQUksR0FBRyxJQUFJO0lBQ2YsSUFBQUMsWUFBUSxFQUFDWixJQUFJLENBQUMsQ0FDWGEsSUFBSSxDQUFFQyxDQUFDLElBQUtILElBQUksSUFBSVAsVUFBVSxDQUFDVSxDQUFDLENBQUMsQ0FBQyxDQUNsQ0MsS0FBSyxDQUFDLE1BQU07TUFDWDtNQUNBLElBQUlKLElBQUksRUFBRTtRQUNSUCxVQUFVLENBQUMsRUFBRSxDQUFDO1FBQ2RHLE9BQU8sQ0FBQywwQ0FBMEMsQ0FBQztNQUNyRDtJQUNGLENBQUMsQ0FBQztJQUNKLE9BQU8sTUFBTTtNQUNYSSxJQUFJLEdBQUcsS0FBSztJQUNkLENBQUM7RUFDSCxDQUFDLEVBQUUsQ0FBQ1gsSUFBSSxDQUFDLENBQUM7RUFFVixNQUFNZ0IsSUFBSSxHQUFHLE1BQUFBLENBQUEsS0FBWTtJQUN2QixJQUFJaEIsSUFBSSxJQUFJLElBQUksSUFBSUcsT0FBTyxJQUFJLElBQUksRUFBRTtJQUNyQ00sU0FBUyxDQUFDLElBQUksQ0FBQztJQUNmRixPQUFPLENBQUMsSUFBSSxDQUFDO0lBQ2IsSUFBSTtNQUNGLE1BQU0sSUFBQVUsYUFBUyxFQUFDakIsSUFBSSxFQUFFRyxPQUFPLENBQUM7TUFDOUIsSUFBQWUsaUJBQVksRUFBQztRQUFFQyxLQUFLLEVBQUU7TUFBSyxDQUFDLENBQUM7SUFDL0IsQ0FBQyxDQUFDLE9BQU9DLENBQUMsRUFBRTtNQUNWO01BQ0FiLE9BQU8sQ0FBQyxrQkFBbUJhLENBQUMsRUFBWUMsT0FBTyxJQUFJLFdBQVcsR0FBRyxDQUFDO01BQ2xFWixTQUFTLENBQUMsS0FBSyxDQUFDO0lBQ2xCO0VBQ0YsQ0FBQztFQUVELElBQUksQ0FBQ1QsSUFBSSxFQUFFO0lBQ1Qsb0JBQ0UsSUFBQVosV0FBQSxDQUFBa0MsSUFBQTtNQUFLQyxTQUFTLEVBQUMsY0FBYztNQUFBQyxRQUFBLEdBQUMsNEJBQ0YsbUJBQUFwQyxXQUFBLENBQUFxQyxHQUFBO1FBQUFELFFBQUEsRUFBTTtNQUFTLENBQU0sQ0FBQyxpQ0FDbEQ7SUFBQSxDQUFLLENBQUM7RUFFVjtFQUVBLG9CQUNFLElBQUFwQyxXQUFBLENBQUFrQyxJQUFBO0lBQUtDLFNBQVMsRUFBQyxJQUFJO0lBQUFDLFFBQUEsZ0JBQ2pCLElBQUFwQyxXQUFBLENBQUFrQyxJQUFBO01BQVFDLFNBQVMsRUFBQyxPQUFPO01BQUFDLFFBQUEsZ0JBQ3ZCLElBQUFwQyxXQUFBLENBQUFxQyxHQUFBO1FBQU1GLFNBQVMsRUFBQyxVQUFVO1FBQUFDLFFBQUEsRUFBQztNQUFPLENBQU0sQ0FBQyxlQUN6QyxJQUFBcEMsV0FBQSxDQUFBcUMsR0FBQTtRQUFNRixTQUFTLEVBQUMsU0FBUztRQUFDRyxLQUFLLEVBQUUxQixJQUFLO1FBQUF3QixRQUFBLEVBQ25DakMsUUFBUSxDQUFDUyxJQUFJO01BQUMsQ0FDWCxDQUFDO0lBQUEsQ0FDRCxDQUFDLGVBQ1QsSUFBQVosV0FBQSxDQUFBcUMsR0FBQTtNQUNFRixTQUFTLEVBQUMsU0FBUztNQUNuQkksS0FBSyxFQUFFeEIsT0FBTyxJQUFJLEVBQUc7TUFDckJ5QixVQUFVLEVBQUUsS0FBTTtNQUNsQkMsUUFBUSxFQUFFMUIsT0FBTyxLQUFLLElBQUs7TUFDM0IyQixRQUFRLEVBQUdWLENBQUMsSUFBS2hCLFVBQVUsQ0FBQ2dCLENBQUMsQ0FBQ1csTUFBTSxDQUFDSixLQUFLLENBQUU7TUFDNUMsY0FBWSxlQUFlcEMsUUFBUSxDQUFDUyxJQUFJLENBQUMsRUFBRztNQUM1Q2dDLFdBQVcsRUFBRTdCLE9BQU8sS0FBSyxJQUFJLEdBQUcsVUFBVSxHQUFHO0lBQUcsQ0FDakQsQ0FBQyxFQUNERyxJQUFJLGlCQUFJLElBQUFsQixXQUFBLENBQUFxQyxHQUFBO01BQUdGLFNBQVMsRUFBQyxTQUFTO01BQUFDLFFBQUEsRUFBRWxCO0lBQUksQ0FBSSxDQUFDLGVBQzFDLElBQUFsQixXQUFBLENBQUFrQyxJQUFBO01BQVFDLFNBQVMsRUFBQyxTQUFTO01BQUFDLFFBQUEsZ0JBQ3pCLElBQUFwQyxXQUFBLENBQUFxQyxHQUFBO1FBQVFRLElBQUksRUFBQyxRQUFRO1FBQUNWLFNBQVMsRUFBQyxRQUFRO1FBQUNXLE9BQU8sRUFBRUEsQ0FBQSxLQUFNLElBQUFDLGVBQVUsRUFBQyxDQUFFO1FBQUFYLFFBQUEsRUFBQztNQUV0RSxDQUFRLENBQUMsZUFDVCxJQUFBcEMsV0FBQSxDQUFBcUMsR0FBQTtRQUNFUSxJQUFJLEVBQUMsUUFBUTtRQUNiVixTQUFTLEVBQUMsZ0JBQWdCO1FBQzFCTSxRQUFRLEVBQUVyQixNQUFNLElBQUlMLE9BQU8sS0FBSyxJQUFLO1FBQ3JDK0IsT0FBTyxFQUFFbEIsSUFBSztRQUFBUSxRQUFBLEVBRWJoQixNQUFNLEdBQUcsU0FBUyxHQUFHO01BQU0sQ0FDdEIsQ0FBQztJQUFBLENBQ0gsQ0FBQztFQUFBLENBQ04sQ0FBQztBQUVWO0FBQUNuQixFQUFBLENBaEZ1QlEsUUFBUTtFQUFBLFFBQ2hCRSxpQkFBWTtBQUFBO0FBQUFxQyxFQUFBLEdBREp2QyxRQUFRO0FBQUEsSUFBQXVDLEVBQUE7QUFBQUMsWUFBQSxDQUFBRCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}