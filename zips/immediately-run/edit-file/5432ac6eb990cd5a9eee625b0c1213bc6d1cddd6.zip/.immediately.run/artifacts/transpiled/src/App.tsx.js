var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
require("./index.css");
require("./App.css");
var _EditFile = _interopRequireDefault(require("./components/EditFile"));
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// Root component — immediately.run renders the default export of THIS file.
// The Phase-09 FILE-DELEGATION task app (§5.7/§8.7): the caller delegates a file
// (`capFile`); the host mints an attenuated, task-scoped chroot and hands this app
// the path. It reads/edits/saves that ONE file and returns `{ saved }` — it holds
// no standing authority; the chroot IS its grant (data crosses, ambient authority
// does not, §5.7).

function App() {
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_EditFile.default, {});
}
_c = App;
var _default = exports.default = App;
var _c;
$RefreshReg$(_c, "App");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJyZXF1aXJlIiwiX0VkaXRGaWxlIiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsIl9qc3hSdW50aW1lIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiQXBwIiwianN4IiwiX2MiLCJfZGVmYXVsdCIsImV4cG9ydHMiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBcHAudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIFJvb3QgY29tcG9uZW50IOKAlCBpbW1lZGlhdGVseS5ydW4gcmVuZGVycyB0aGUgZGVmYXVsdCBleHBvcnQgb2YgVEhJUyBmaWxlLlxuLy8gVGhlIFBoYXNlLTA5IEZJTEUtREVMRUdBVElPTiB0YXNrIGFwcCAowqc1Ljcvwqc4LjcpOiB0aGUgY2FsbGVyIGRlbGVnYXRlcyBhIGZpbGVcbi8vIChgY2FwRmlsZWApOyB0aGUgaG9zdCBtaW50cyBhbiBhdHRlbnVhdGVkLCB0YXNrLXNjb3BlZCBjaHJvb3QgYW5kIGhhbmRzIHRoaXMgYXBwXG4vLyB0aGUgcGF0aC4gSXQgcmVhZHMvZWRpdHMvc2F2ZXMgdGhhdCBPTkUgZmlsZSBhbmQgcmV0dXJucyBgeyBzYXZlZCB9YCDigJQgaXQgaG9sZHNcbi8vIG5vIHN0YW5kaW5nIGF1dGhvcml0eTsgdGhlIGNocm9vdCBJUyBpdHMgZ3JhbnQgKGRhdGEgY3Jvc3NlcywgYW1iaWVudCBhdXRob3JpdHlcbi8vIGRvZXMgbm90LCDCpzUuNykuXG5pbXBvcnQgXCIuL2luZGV4LmNzc1wiO1xuaW1wb3J0IFwiLi9BcHAuY3NzXCI7XG5pbXBvcnQgRWRpdEZpbGUgZnJvbSBcIi4vY29tcG9uZW50cy9FZGl0RmlsZVwiO1xuXG5mdW5jdGlvbiBBcHAoKSB7XG4gIHJldHVybiA8RWRpdEZpbGUgLz47XG59XG5cbmV4cG9ydCBkZWZhdWx0IEFwcDtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBTUFBLE9BQUE7QUFDQUEsT0FBQTtBQUNBLElBQUFDLFNBQUEsR0FBQUMsc0JBQUEsQ0FBQUYsT0FBQTtBQUE2QyxJQUFBRyxXQUFBLEdBQUFILE9BQUE7QUFBQSxTQUFBRSx1QkFBQUUsQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQVI3QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBS0EsU0FBU0csR0FBR0EsQ0FBQSxFQUFHO0VBQ2Isb0JBQU8sSUFBQUosV0FBQSxDQUFBSyxHQUFBLEVBQUNQLFNBQUEsQ0FBQUssT0FBUSxJQUFFLENBQUM7QUFDckI7QUFBQ0csRUFBQSxHQUZRRixHQUFHO0FBQUEsSUFBQUcsUUFBQSxHQUFBQyxPQUFBLENBQUFMLE9BQUEsR0FJR0MsR0FBRztBQUFBLElBQUFFLEVBQUE7QUFBQUcsWUFBQSxDQUFBSCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}