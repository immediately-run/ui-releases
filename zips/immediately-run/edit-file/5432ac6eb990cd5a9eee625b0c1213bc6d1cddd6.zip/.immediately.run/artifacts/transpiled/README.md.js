var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      code: "code",
      em: "em",
      h1: "h1",
      p: "p",
      pre: "pre",
      strong: "strong",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "edit-file",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "edit-file"
      }), "edit-file"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The Phase-09 ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "file-delegation"
      }), " task app for ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "https://immediately.run",
        children: "immediately.run"
      }), "\n(UI_AS_APPS_SPEC §5.7 / §8.7). It ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "provides"
      }), " the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "edit-file"
      }), " contract: a caller\ndelegates a file with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "capFile({ mountId, relPath }, { mode })"
      }), ", the host mints an\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "attenuated, task-scoped chroot"
      }), " for it, and this app reads/edits/saves ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "only"
      }), "\nthat file at the host-given path — returning ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "{ saved }"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["It holds ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "no standing authority"
      }), " — the chroot ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "is"
      }), " its grant (data + a bounded\nfile capability cross; ambient authority does not, §5.7). A ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ro"
      }), " delegation makes\nthe save fail with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "EROFS"
      }), " (the host-enforced read-only wall), surfaced in the UI;\noutside the delegated path is unnameable."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-jsonc",
        children: "// package.json\n\"immediately.run\": { \"provides\": [{ \"task\": \"edit-file\", \"version\": \"1.0\" }] }\n"
      })
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/README.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiY29kZSIsImVtIiwiaDEiLCJwIiwicHJlIiwic3Ryb25nIiwiX3Byb3ZpZGVDb21wb25lbnRzIiwiY29tcG9uZW50cyIsIkhlYWRpbmdBbmNob3IiLCJfbWlzc2luZ01keFJlZmVyZW5jZSIsImpzeHMiLCJGcmFnbWVudCIsImNoaWxkcmVuIiwiaWQiLCJqc3giLCJocmVmIiwiY2xhc3NOYW1lIiwiTURYQ29udGVudCIsIndyYXBwZXIiLCJNRFhMYXlvdXQiLCJfYyIsImNvbXBvbmVudCIsInBsYWNlIiwiRXJyb3IiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJSRUFETUUubWQiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgYTogXCJhXCIsXG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgZW06IFwiZW1cIixcbiAgICBoMTogXCJoMVwiLFxuICAgIHA6IFwicFwiLFxuICAgIHByZTogXCJwcmVcIixcbiAgICBzdHJvbmc6IFwic3Ryb25nXCIsXG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9LCB7SGVhZGluZ0FuY2hvcn0gPSBfY29tcG9uZW50cztcbiAgaWYgKCFIZWFkaW5nQW5jaG9yKSBfbWlzc2luZ01keFJlZmVyZW5jZShcIkhlYWRpbmdBbmNob3JcIiwgdHJ1ZSk7XG4gIHJldHVybiA8PjxfY29tcG9uZW50cy5oMSBpZD1cImVkaXQtZmlsZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiZWRpdC1maWxlXCIgLz57XCJlZGl0LWZpbGVcIn08L19jb21wb25lbnRzLmgxPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSBQaGFzZS0wOSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImZpbGUtZGVsZWdhdGlvblwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB0YXNrIGFwcCBmb3IgXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cImh0dHBzOi8vaW1tZWRpYXRlbHkucnVuXCI+e1wiaW1tZWRpYXRlbHkucnVuXCJ9PC9fY29tcG9uZW50cy5hPntcIlxcbihVSV9BU19BUFBTX1NQRUMgwqc1LjcgLyDCpzguNykuIEl0IFwifTxfY29tcG9uZW50cy5jb2RlPntcInByb3ZpZGVzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB0aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZWRpdC1maWxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjb250cmFjdDogYSBjYWxsZXJcXG5kZWxlZ2F0ZXMgYSBmaWxlIHdpdGggXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2FwRmlsZSh7IG1vdW50SWQsIHJlbFBhdGggfSwgeyBtb2RlIH0pXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgdGhlIGhvc3QgbWludHMgYW5cXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImF0dGVudWF0ZWQsIHRhc2stc2NvcGVkIGNocm9vdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBmb3IgaXQsIGFuZCB0aGlzIGFwcCByZWFkcy9lZGl0cy9zYXZlcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm9ubHlcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCJcXG50aGF0IGZpbGUgYXQgdGhlIGhvc3QtZ2l2ZW4gcGF0aCDigJQgcmV0dXJuaW5nIFwifTxfY29tcG9uZW50cy5jb2RlPntcInsgc2F2ZWQgfVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkl0IGhvbGRzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibm8gc3RhbmRpbmcgYXV0aG9yaXR5XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCB0aGUgY2hyb290IFwifTxfY29tcG9uZW50cy5lbT57XCJpc1wifTwvX2NvbXBvbmVudHMuZW0+e1wiIGl0cyBncmFudCAoZGF0YSArIGEgYm91bmRlZFxcbmZpbGUgY2FwYWJpbGl0eSBjcm9zczsgYW1iaWVudCBhdXRob3JpdHkgZG9lcyBub3QsIMKnNS43KS4gQSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyb1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZGVsZWdhdGlvbiBtYWtlc1xcbnRoZSBzYXZlIGZhaWwgd2l0aCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJFUk9GU1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKHRoZSBob3N0LWVuZm9yY2VkIHJlYWQtb25seSB3YWxsKSwgc3VyZmFjZWQgaW4gdGhlIFVJO1xcbm91dHNpZGUgdGhlIGRlbGVnYXRlZCBwYXRoIGlzIHVubmFtZWFibGUuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wcmU+PF9jb21wb25lbnRzLmNvZGUgY2xhc3NOYW1lPVwibGFuZ3VhZ2UtanNvbmNcIj57XCIvLyBwYWNrYWdlLmpzb25cXG5cXFwiaW1tZWRpYXRlbHkucnVuXFxcIjogeyBcXFwicHJvdmlkZXNcXFwiOiBbeyBcXFwidGFza1xcXCI6IFxcXCJlZGl0LWZpbGVcXFwiLCBcXFwidmVyc2lvblxcXCI6IFxcXCIxLjBcXFwiIH1dIH1cXG5cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5wcmU+PC8+O1xufVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTURYQ29udGVudChwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHt3cmFwcGVyOiBNRFhMYXlvdXR9ID0ge1xuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfTtcbiAgcmV0dXJuIE1EWExheW91dCA/IDxNRFhMYXlvdXQgey4uLnByb3BzfT48X2NyZWF0ZU1keENvbnRlbnQgey4uLnByb3BzfSAvPjwvTURYTGF5b3V0PiA6IF9jcmVhdGVNZHhDb250ZW50KHByb3BzKTtcbn1cbmZ1bmN0aW9uIF9taXNzaW5nTWR4UmVmZXJlbmNlKGlkLCBjb21wb25lbnQsIHBsYWNlKSB7XG4gIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIFwiICsgKGNvbXBvbmVudCA/IFwiY29tcG9uZW50XCIgOiBcIm9iamVjdFwiKSArIFwiIGBcIiArIGlkICsgXCJgIHRvIGJlIGRlZmluZWQ6IHlvdSBsaWtlbHkgZm9yZ290IHRvIGltcG9ydCwgcGFzcywgb3IgcHJvdmlkZSBpdC5cIiArIChwbGFjZSA/IFwiXFxuSXTigJlzIHJlZmVyZW5jZWQgaW4geW91ciBjb2RlIGF0IGBcIiArIHBsYWNlICsgXCJgIGluIGAvYXBwL1JFQURNRS5tZGBcIiA6IFwiXCIpKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQXdGLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUZ4RjtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU1DLFdBQVcsR0FBRztNQUNsQkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsSUFBSSxFQUFFLE1BQU07TUFDWkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsR0FBRyxFQUFFLEtBQUs7TUFDVkMsTUFBTSxFQUFFLFFBQVE7TUFDaEIsR0FBRyxJQUFBQyw2QkFBa0IsRUFBQyxDQUFDO01BQ3ZCLEdBQUdULEtBQUssQ0FBQ1U7SUFDWCxDQUFDO0lBQUU7TUFBQ0M7SUFBYSxDQUFDLEdBQUdWLFdBQVc7RUFDaEMsSUFBSSxDQUFDVSxhQUFhLEVBQUVDLG9CQUFvQixDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUM7RUFDL0Qsb0JBQU8sSUFBQWQsV0FBQSxDQUFBZSxJQUFBLEVBQUFmLFdBQUEsQ0FBQWdCLFFBQUE7SUFBQUMsUUFBQSxnQkFBRSxJQUFBakIsV0FBQSxDQUFBZSxJQUFBLEVBQUNaLFdBQVcsQ0FBQ0ksRUFBRTtNQUFDVyxFQUFFLEVBQUMsV0FBVztNQUFBRCxRQUFBLGdCQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVcsQ0FBRSxDQUFDLEVBQUMsV0FBVztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQWUsSUFBQSxFQUFDWixXQUFXLENBQUNLLENBQUM7TUFBQVMsUUFBQSxHQUFFLGVBQWUsZUFBQyxJQUFBakIsV0FBQSxDQUFBbUIsR0FBQSxFQUFDaEIsV0FBVyxDQUFDTyxNQUFNO1FBQUFPLFFBQUEsRUFBRTtNQUFpQixDQUFxQixDQUFDLEVBQUMsZ0JBQWdCLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2hCLFdBQVcsQ0FBQ0MsQ0FBQztRQUFDZ0IsSUFBSSxFQUFDLHlCQUF5QjtRQUFBSCxRQUFBLEVBQUU7TUFBaUIsQ0FBZ0IsQ0FBQyxFQUFDLHNDQUFzQyxlQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNoQixXQUFXLENBQUNFLElBQUk7UUFBQVksUUFBQSxFQUFFO01BQVUsQ0FBbUIsQ0FBQyxFQUFDLE9BQU8sZUFBQyxJQUFBakIsV0FBQSxDQUFBbUIsR0FBQSxFQUFDaEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFZLFFBQUEsRUFBRTtNQUFXLENBQW1CLENBQUMsRUFBQyw2Q0FBNkMsZUFBQyxJQUFBakIsV0FBQSxDQUFBbUIsR0FBQSxFQUFDaEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFZLFFBQUEsRUFBRTtNQUF5QyxDQUFtQixDQUFDLEVBQUMsdUJBQXVCLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2hCLFdBQVcsQ0FBQ08sTUFBTTtRQUFBTyxRQUFBLEVBQUU7TUFBZ0MsQ0FBcUIsQ0FBQyxFQUFDLDBDQUEwQyxlQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNoQixXQUFXLENBQUNPLE1BQU07UUFBQU8sUUFBQSxFQUFFO01BQU0sQ0FBcUIsQ0FBQyxFQUFDLGlEQUFpRCxlQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNoQixXQUFXLENBQUNFLElBQUk7UUFBQVksUUFBQSxFQUFFO01BQVcsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFqQixXQUFBLENBQUFlLElBQUEsRUFBQ1osV0FBVyxDQUFDSyxDQUFDO01BQUFTLFFBQUEsR0FBRSxXQUFXLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2hCLFdBQVcsQ0FBQ08sTUFBTTtRQUFBTyxRQUFBLEVBQUU7TUFBdUIsQ0FBcUIsQ0FBQyxFQUFDLGdCQUFnQixlQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNoQixXQUFXLENBQUNHLEVBQUU7UUFBQVcsUUFBQSxFQUFFO01BQUksQ0FBaUIsQ0FBQyxFQUFDLDRGQUE0RixlQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNoQixXQUFXLENBQUNFLElBQUk7UUFBQVksUUFBQSxFQUFFO01BQUksQ0FBbUIsQ0FBQyxFQUFDLHdDQUF3QyxlQUFDLElBQUFqQixXQUFBLENBQUFtQixHQUFBLEVBQUNoQixXQUFXLENBQUNFLElBQUk7UUFBQVksUUFBQSxFQUFFO01BQU8sQ0FBbUIsQ0FBQyxFQUFDLHFHQUFxRztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2hCLFdBQVcsQ0FBQ00sR0FBRztNQUFBUSxRQUFBLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2hCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFDZ0IsU0FBUyxFQUFDLGdCQUFnQjtRQUFBSixRQUFBLEVBQUU7TUFBK0csQ0FBbUI7SUFBQyxDQUFpQixDQUFDO0VBQUEsQ0FBRSxDQUFDO0FBQzdrRDtBQUNlLFNBQVNLLFVBQVVBLENBQUNwQixLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUU7RUFDN0MsTUFBTTtJQUFDcUIsT0FBTyxFQUFFQztFQUFTLENBQUMsR0FBRztJQUMzQixHQUFHLElBQUFiLDZCQUFrQixFQUFDLENBQUM7SUFDdkIsR0FBR1QsS0FBSyxDQUFDVTtFQUNYLENBQUM7RUFDRCxPQUFPWSxTQUFTLGdCQUFHLElBQUF4QixXQUFBLENBQUFtQixHQUFBLEVBQUNLLFNBQVM7SUFBQSxHQUFLdEIsS0FBSztJQUFBZSxRQUFBLGVBQUUsSUFBQWpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2xCLGlCQUFpQjtNQUFBLEdBQUtDO0lBQUssQ0FBRztFQUFDLENBQVcsQ0FBQyxHQUFHRCxpQkFBaUIsQ0FBQ0MsS0FBSyxDQUFDO0FBQ2xIO0FBQUN1QixFQUFBLEdBTnVCSCxVQUFVO0FBT2xDLFNBQVNSLG9CQUFvQkEsQ0FBQ0ksRUFBRSxFQUFFUSxTQUFTLEVBQUVDLEtBQUssRUFBRTtFQUNsRCxNQUFNLElBQUlDLEtBQUssQ0FBQyxXQUFXLElBQUlGLFNBQVMsR0FBRyxXQUFXLEdBQUcsUUFBUSxDQUFDLEdBQUcsSUFBSSxHQUFHUixFQUFFLEdBQUcsb0VBQW9FLElBQUlTLEtBQUssR0FBRyxxQ0FBcUMsR0FBR0EsS0FBSyxHQUFHLHVCQUF1QixHQUFHLEVBQUUsQ0FBQyxDQUFDO0FBQ2pQO0FBQUMsSUFBQUYsRUFBQTtBQUFBSSxZQUFBLENBQUFKLEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}