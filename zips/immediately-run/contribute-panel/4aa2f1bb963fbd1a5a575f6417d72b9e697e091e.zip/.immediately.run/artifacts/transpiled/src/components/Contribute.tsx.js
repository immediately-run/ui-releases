var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Contribute;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
var _externalLink = require("../lib/externalLink");
require("./Contribute.css");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The contribute dialog (UI_AS_APPS_SPEC §5.1). Reads the unsaved files via the
// elevated `editor:read` channel, lets the user write a message and pick PR vs
// direct commit, then drives the host's contribution orchestrator over the
// streamed `contribute()` call. Every privileged step — the GitHub API, the
// OAuth token, the fork/PR — stays on the host; this app only shows progress.
/** The dialog's state machine. Exported (type-only) so the externalLink test
 *  reads its href from the same prop the component passes, never a retyped
 *  string (the item's Tests section). */
// Friendly one-liners for the orchestrator stages (CONTRIBUTE_SPEC §15.7).
const STAGE_LABEL = {
  "auth-check": "Checking sign-in…",
  "diff-compute": "Computing your changes…",
  "permission-check": "Checking permissions…",
  "conflict-check": "Checking for conflicts…",
  "fork-prepare": "Preparing your fork…",
  "upload-blob": "Uploading files…",
  "create-tree": "Building the commit…",
  "create-commit": "Creating the commit…",
  "create-branch": "Creating the branch…",
  "create-pr": "Opening the pull request…",
  "commit-pushed": "Pushing the commit…",
  starting: "Starting…"
};
function Contribute() {
  _s();
  const {
    dirtyPaths
  } = (0, _sdk.useEditorContext)();
  const [message, setMessage] = (0, _react.useState)("");
  const [mode, setMode] = (0, _react.useState)("pr");
  const [phase, setPhase] = (0, _react.useState)({
    kind: "idle"
  });
  // A refused outward link (the install/PR anchors) renders here — BESIDE the
  // current phase, never instead of it: an error phase would unmount the very
  // link + retry the user needs.
  const [linkError, setLinkError] = (0, _react.useState)(null);
  const busy = phase.kind === "running";
  const nothingToSave = dirtyPaths.length === 0;
  const run = (0, _react.useCallback)(async () => {
    setPhase({
      kind: "running",
      stage: "starting"
    });
    try {
      const stream = (0, _sdk.contribute)({
        commitMessage: message.trim() || "Update",
        mode
      });
      let result;
      for await (const ev of stream) {
        if (ev.stage === "install-required") {
          // Forward-only v1 (§5.1): the GitHub App must be installed on the target.
          // Show the link; after installing, the user retries (a fresh stream).
          setPhase({
            kind: "needs-install",
            installUrl: ev.installUrl,
            targetOwner: ev.targetOwner,
            targetRepo: ev.targetRepo
          });
          return;
        }
        if (ev.stage === "error") {
          setPhase({
            kind: "error",
            code: "failed",
            message: ev.message
          });
          return;
        }
        if (ev.stage === "done") {
          result = ev;
        }
        setPhase({
          kind: "running",
          stage: ev.stage
        });
      }
      // The generator's RETURN value is the settled result; prefer it.
      setPhase({
        kind: "done",
        result: result ?? {
          commitSha: "",
          treeSha: "",
          branchName: "",
          mode: "new-branch-pr"
        }
      });
    } catch (e) {
      const code = e?.code ?? "unknown";
      setPhase({
        kind: "error",
        code,
        message: e?.message ?? "Save failed"
      });
    }
  }, [message, mode]);
  const errorHint = (0, _react.useMemo)(() => {
    if (phase.kind !== "error") return null;
    switch (phase.code) {
      case "auth-required":
        return "Sign in to save your changes.";
      case "forbidden":
        return mode === "direct" ? "This app can't commit directly. Switch to a pull request." : "You don't have permission to save here.";
      case "no-target":
        return "There's nothing here that can be saved to GitHub.";
      case "conflict":
        return "Someone changed these files upstream — refresh and try again.";
      case "gone":
        return "The branch was deleted upstream.";
      default:
        return phase.message;
    }
  }, [phase, mode]);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "contribute",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("header", {
      className: "ct-hd",
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "ct-title",
        children: "Save your changes"
      })
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("section", {
      className: "ct-changes",
      children: nothingToSave ? /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
        className: "ct-empty",
        children: "No unsaved changes."
      }) : /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("p", {
          className: "ct-changes-h",
          children: [dirtyPaths.length, " file", dirtyPaths.length === 1 ? "" : "s", " will be saved"]
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("ul", {
          className: "ct-filelist",
          children: dirtyPaths.map(p => /*#__PURE__*/(0, _jsxRuntime.jsx)("li", {
            className: "ct-file",
            title: p,
            children: p
          }, p))
        })]
      })
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("label", {
      className: "ct-field",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "ct-label",
        children: "Message"
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("input", {
        className: "ct-input",
        value: message,
        placeholder: "Describe your change",
        onChange: e => setMessage(e.target.value),
        disabled: busy
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "ct-mode",
      role: "radiogroup",
      "aria-label": "Save mode",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("label", {
        className: "ct-radio",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("input", {
          type: "radio",
          name: "mode",
          checked: mode === "pr",
          onChange: () => setMode("pr"),
          disabled: busy
        }), "Pull request"]
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("label", {
        className: "ct-radio",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("input", {
          type: "radio",
          name: "mode",
          checked: mode === "direct",
          onChange: () => setMode("direct"),
          disabled: busy
        }), "Commit directly"]
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
      type: "button",
      className: "ct-save",
      onClick: run,
      disabled: busy || nothingToSave,
      children: busy ? STAGE_LABEL[phase.stage] ?? "Saving…" : mode === "direct" ? "Commit" : "Open pull request"
    }), phase.kind === "needs-install" && /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "ct-status ct-install",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("p", {
        children: ["Install the immediately.run GitHub App on", " ", /*#__PURE__*/(0, _jsxRuntime.jsxs)("strong", {
          children: [phase.targetOwner, "/", phase.targetRepo]
        }), " ", "to save here."]
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("a", {
        className: "ct-link",
        href: phase.installUrl,
        target: "_blank",
        rel: "noreferrer",
        onClick: ev => {
          setLinkError(null);
          (0, _externalLink.openExternalLink)(phase.installUrl, ev, setLinkError);
        },
        children: "Install\u2026"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        type: "button",
        className: "ct-retry",
        onClick: run,
        children: "I've installed \u2014 retry"
      })]
    }), phase.kind === "done" && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "ct-status ct-done",
      children: phase.result.prUrl ? /*#__PURE__*/(0, _jsxRuntime.jsxs)("p", {
        children: ["Pull request opened \u2014", " ", /*#__PURE__*/(0, _jsxRuntime.jsxs)("a", {
          className: "ct-link",
          href: phase.result.prUrl,
          target: "_blank",
          rel: "noreferrer",
          onClick: ev => {
            setLinkError(null);
            if (phase.result.prUrl) (0, _externalLink.openExternalLink)(phase.result.prUrl, ev, setLinkError);
          },
          children: ["#", phase.result.prNumber]
        })]
      }) : /*#__PURE__*/(0, _jsxRuntime.jsxs)("p", {
        children: ["Committed ", phase.result.commitSha.slice(0, 7), " to ", phase.result.branchName, "."]
      })
    }), phase.kind === "error" && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "ct-status ct-error",
      children: errorHint
    }), linkError && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "ct-status ct-error",
      role: "alert",
      children: linkError
    })]
  });
}
_s(Contribute, "3aC1/qCCpKwKPQveq82WUN9Rd2A=", false, function () {
  return [_sdk.useEditorContext];
});
_c = Contribute;
var _c;
$RefreshReg$(_c, "Contribute");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NkayIsIl9leHRlcm5hbExpbmsiLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiU1RBR0VfTEFCRUwiLCJzdGFydGluZyIsIkNvbnRyaWJ1dGUiLCJkaXJ0eVBhdGhzIiwidXNlRWRpdG9yQ29udGV4dCIsIm1lc3NhZ2UiLCJzZXRNZXNzYWdlIiwidXNlU3RhdGUiLCJtb2RlIiwic2V0TW9kZSIsInBoYXNlIiwic2V0UGhhc2UiLCJraW5kIiwibGlua0Vycm9yIiwic2V0TGlua0Vycm9yIiwiYnVzeSIsIm5vdGhpbmdUb1NhdmUiLCJsZW5ndGgiLCJydW4iLCJ1c2VDYWxsYmFjayIsInN0YWdlIiwic3RyZWFtIiwiY29udHJpYnV0ZSIsImNvbW1pdE1lc3NhZ2UiLCJ0cmltIiwicmVzdWx0IiwiZXYiLCJpbnN0YWxsVXJsIiwidGFyZ2V0T3duZXIiLCJ0YXJnZXRSZXBvIiwiY29kZSIsImNvbW1pdFNoYSIsInRyZWVTaGEiLCJicmFuY2hOYW1lIiwiZSIsImVycm9ySGludCIsInVzZU1lbW8iLCJqc3hzIiwiY2xhc3NOYW1lIiwiY2hpbGRyZW4iLCJqc3giLCJGcmFnbWVudCIsIm1hcCIsInAiLCJ0aXRsZSIsInZhbHVlIiwicGxhY2Vob2xkZXIiLCJvbkNoYW5nZSIsInRhcmdldCIsImRpc2FibGVkIiwicm9sZSIsInR5cGUiLCJuYW1lIiwiY2hlY2tlZCIsIm9uQ2xpY2siLCJocmVmIiwicmVsIiwib3BlbkV4dGVybmFsTGluayIsInByVXJsIiwicHJOdW1iZXIiLCJzbGljZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQ29udHJpYnV0ZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gVGhlIGNvbnRyaWJ1dGUgZGlhbG9nIChVSV9BU19BUFBTX1NQRUMgwqc1LjEpLiBSZWFkcyB0aGUgdW5zYXZlZCBmaWxlcyB2aWEgdGhlXG4vLyBlbGV2YXRlZCBgZWRpdG9yOnJlYWRgIGNoYW5uZWwsIGxldHMgdGhlIHVzZXIgd3JpdGUgYSBtZXNzYWdlIGFuZCBwaWNrIFBSIHZzXG4vLyBkaXJlY3QgY29tbWl0LCB0aGVuIGRyaXZlcyB0aGUgaG9zdCdzIGNvbnRyaWJ1dGlvbiBvcmNoZXN0cmF0b3Igb3ZlciB0aGVcbi8vIHN0cmVhbWVkIGBjb250cmlidXRlKClgIGNhbGwuIEV2ZXJ5IHByaXZpbGVnZWQgc3RlcCDigJQgdGhlIEdpdEh1YiBBUEksIHRoZVxuLy8gT0F1dGggdG9rZW4sIHRoZSBmb3JrL1BSIOKAlCBzdGF5cyBvbiB0aGUgaG9zdDsgdGhpcyBhcHAgb25seSBzaG93cyBwcm9ncmVzcy5cbmltcG9ydCB7IHVzZUNhbGxiYWNrLCB1c2VNZW1vLCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHtcbiAgY29udHJpYnV0ZSxcbiAgdXNlRWRpdG9yQ29udGV4dCxcbiAgdHlwZSBDb250cmlidXRlTW9kZSxcbiAgdHlwZSBDb250cmlidXRpb25FdmVudCxcbiAgdHlwZSBDb250cmlidXRpb25SZXN1bHQsXG59IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nka1wiO1xuaW1wb3J0IHsgb3BlbkV4dGVybmFsTGluayB9IGZyb20gXCIuLi9saWIvZXh0ZXJuYWxMaW5rXCI7XG5pbXBvcnQgXCIuL0NvbnRyaWJ1dGUuY3NzXCI7XG5cbi8qKiBUaGUgZGlhbG9nJ3Mgc3RhdGUgbWFjaGluZS4gRXhwb3J0ZWQgKHR5cGUtb25seSkgc28gdGhlIGV4dGVybmFsTGluayB0ZXN0XG4gKiAgcmVhZHMgaXRzIGhyZWYgZnJvbSB0aGUgc2FtZSBwcm9wIHRoZSBjb21wb25lbnQgcGFzc2VzLCBuZXZlciBhIHJldHlwZWRcbiAqICBzdHJpbmcgKHRoZSBpdGVtJ3MgVGVzdHMgc2VjdGlvbikuICovXG5leHBvcnQgdHlwZSBQaGFzZSA9XG4gIHwgeyBraW5kOiBcImlkbGVcIiB9XG4gIHwgeyBraW5kOiBcInJ1bm5pbmdcIjsgc3RhZ2U6IHN0cmluZyB9XG4gIHwgeyBraW5kOiBcIm5lZWRzLWluc3RhbGxcIjsgaW5zdGFsbFVybDogc3RyaW5nOyB0YXJnZXRPd25lcjogc3RyaW5nOyB0YXJnZXRSZXBvOiBzdHJpbmcgfVxuICB8IHsga2luZDogXCJkb25lXCI7IHJlc3VsdDogQ29udHJpYnV0aW9uUmVzdWx0IH1cbiAgfCB7IGtpbmQ6IFwiZXJyb3JcIjsgY29kZTogc3RyaW5nOyBtZXNzYWdlOiBzdHJpbmcgfTtcblxuLy8gRnJpZW5kbHkgb25lLWxpbmVycyBmb3IgdGhlIG9yY2hlc3RyYXRvciBzdGFnZXMgKENPTlRSSUJVVEVfU1BFQyDCpzE1LjcpLlxuY29uc3QgU1RBR0VfTEFCRUw6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7XG4gIFwiYXV0aC1jaGVja1wiOiBcIkNoZWNraW5nIHNpZ24taW7igKZcIixcbiAgXCJkaWZmLWNvbXB1dGVcIjogXCJDb21wdXRpbmcgeW91ciBjaGFuZ2Vz4oCmXCIsXG4gIFwicGVybWlzc2lvbi1jaGVja1wiOiBcIkNoZWNraW5nIHBlcm1pc3Npb25z4oCmXCIsXG4gIFwiY29uZmxpY3QtY2hlY2tcIjogXCJDaGVja2luZyBmb3IgY29uZmxpY3Rz4oCmXCIsXG4gIFwiZm9yay1wcmVwYXJlXCI6IFwiUHJlcGFyaW5nIHlvdXIgZm9ya+KAplwiLFxuICBcInVwbG9hZC1ibG9iXCI6IFwiVXBsb2FkaW5nIGZpbGVz4oCmXCIsXG4gIFwiY3JlYXRlLXRyZWVcIjogXCJCdWlsZGluZyB0aGUgY29tbWl04oCmXCIsXG4gIFwiY3JlYXRlLWNvbW1pdFwiOiBcIkNyZWF0aW5nIHRoZSBjb21taXTigKZcIixcbiAgXCJjcmVhdGUtYnJhbmNoXCI6IFwiQ3JlYXRpbmcgdGhlIGJyYW5jaOKAplwiLFxuICBcImNyZWF0ZS1wclwiOiBcIk9wZW5pbmcgdGhlIHB1bGwgcmVxdWVzdOKAplwiLFxuICBcImNvbW1pdC1wdXNoZWRcIjogXCJQdXNoaW5nIHRoZSBjb21taXTigKZcIixcbiAgc3RhcnRpbmc6IFwiU3RhcnRpbmfigKZcIixcbn07XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIENvbnRyaWJ1dGUoKSB7XG4gIGNvbnN0IHsgZGlydHlQYXRocyB9ID0gdXNlRWRpdG9yQ29udGV4dCgpO1xuICBjb25zdCBbbWVzc2FnZSwgc2V0TWVzc2FnZV0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW21vZGUsIHNldE1vZGVdID0gdXNlU3RhdGU8Q29udHJpYnV0ZU1vZGU+KFwicHJcIik7XG4gIGNvbnN0IFtwaGFzZSwgc2V0UGhhc2VdID0gdXNlU3RhdGU8UGhhc2U+KHsga2luZDogXCJpZGxlXCIgfSk7XG4gIC8vIEEgcmVmdXNlZCBvdXR3YXJkIGxpbmsgKHRoZSBpbnN0YWxsL1BSIGFuY2hvcnMpIHJlbmRlcnMgaGVyZSDigJQgQkVTSURFIHRoZVxuICAvLyBjdXJyZW50IHBoYXNlLCBuZXZlciBpbnN0ZWFkIG9mIGl0OiBhbiBlcnJvciBwaGFzZSB3b3VsZCB1bm1vdW50IHRoZSB2ZXJ5XG4gIC8vIGxpbmsgKyByZXRyeSB0aGUgdXNlciBuZWVkcy5cbiAgY29uc3QgW2xpbmtFcnJvciwgc2V0TGlua0Vycm9yXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuXG4gIGNvbnN0IGJ1c3kgPSBwaGFzZS5raW5kID09PSBcInJ1bm5pbmdcIjtcbiAgY29uc3Qgbm90aGluZ1RvU2F2ZSA9IGRpcnR5UGF0aHMubGVuZ3RoID09PSAwO1xuXG4gIGNvbnN0IHJ1biA9IHVzZUNhbGxiYWNrKGFzeW5jICgpID0+IHtcbiAgICBzZXRQaGFzZSh7IGtpbmQ6IFwicnVubmluZ1wiLCBzdGFnZTogXCJzdGFydGluZ1wiIH0pO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBzdHJlYW0gPSBjb250cmlidXRlKHsgY29tbWl0TWVzc2FnZTogbWVzc2FnZS50cmltKCkgfHwgXCJVcGRhdGVcIiwgbW9kZSB9KTtcbiAgICAgIGxldCByZXN1bHQ6IENvbnRyaWJ1dGlvblJlc3VsdCB8IHVuZGVmaW5lZDtcbiAgICAgIGZvciBhd2FpdCAoY29uc3QgZXYgb2Ygc3RyZWFtIGFzIEFzeW5jR2VuZXJhdG9yPENvbnRyaWJ1dGlvbkV2ZW50LCBDb250cmlidXRpb25SZXN1bHQ+KSB7XG4gICAgICAgIGlmIChldi5zdGFnZSA9PT0gXCJpbnN0YWxsLXJlcXVpcmVkXCIpIHtcbiAgICAgICAgICAvLyBGb3J3YXJkLW9ubHkgdjEgKMKnNS4xKTogdGhlIEdpdEh1YiBBcHAgbXVzdCBiZSBpbnN0YWxsZWQgb24gdGhlIHRhcmdldC5cbiAgICAgICAgICAvLyBTaG93IHRoZSBsaW5rOyBhZnRlciBpbnN0YWxsaW5nLCB0aGUgdXNlciByZXRyaWVzIChhIGZyZXNoIHN0cmVhbSkuXG4gICAgICAgICAgc2V0UGhhc2Uoe1xuICAgICAgICAgICAga2luZDogXCJuZWVkcy1pbnN0YWxsXCIsXG4gICAgICAgICAgICBpbnN0YWxsVXJsOiBldi5pbnN0YWxsVXJsLFxuICAgICAgICAgICAgdGFyZ2V0T3duZXI6IGV2LnRhcmdldE93bmVyLFxuICAgICAgICAgICAgdGFyZ2V0UmVwbzogZXYudGFyZ2V0UmVwbyxcbiAgICAgICAgICB9KTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGV2LnN0YWdlID09PSBcImVycm9yXCIpIHtcbiAgICAgICAgICBzZXRQaGFzZSh7IGtpbmQ6IFwiZXJyb3JcIiwgY29kZTogXCJmYWlsZWRcIiwgbWVzc2FnZTogZXYubWVzc2FnZSB9KTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGV2LnN0YWdlID09PSBcImRvbmVcIikge1xuICAgICAgICAgIHJlc3VsdCA9IGV2IGFzIHVua25vd24gYXMgQ29udHJpYnV0aW9uUmVzdWx0O1xuICAgICAgICB9XG4gICAgICAgIHNldFBoYXNlKHsga2luZDogXCJydW5uaW5nXCIsIHN0YWdlOiBldi5zdGFnZSB9KTtcbiAgICAgIH1cbiAgICAgIC8vIFRoZSBnZW5lcmF0b3IncyBSRVRVUk4gdmFsdWUgaXMgdGhlIHNldHRsZWQgcmVzdWx0OyBwcmVmZXIgaXQuXG4gICAgICBzZXRQaGFzZSh7IGtpbmQ6IFwiZG9uZVwiLCByZXN1bHQ6IHJlc3VsdCA/PyAoeyBjb21taXRTaGE6IFwiXCIsIHRyZWVTaGE6IFwiXCIsIGJyYW5jaE5hbWU6IFwiXCIsIG1vZGU6IFwibmV3LWJyYW5jaC1wclwiIH0gYXMgQ29udHJpYnV0aW9uUmVzdWx0KSB9KTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBjb25zdCBjb2RlID0gKGUgYXMgeyBjb2RlPzogc3RyaW5nIH0pPy5jb2RlID8/IFwidW5rbm93blwiO1xuICAgICAgc2V0UGhhc2UoeyBraW5kOiBcImVycm9yXCIsIGNvZGUsIG1lc3NhZ2U6IChlIGFzIEVycm9yKT8ubWVzc2FnZSA/PyBcIlNhdmUgZmFpbGVkXCIgfSk7XG4gICAgfVxuICB9LCBbbWVzc2FnZSwgbW9kZV0pO1xuXG4gIGNvbnN0IGVycm9ySGludCA9IHVzZU1lbW8oKCkgPT4ge1xuICAgIGlmIChwaGFzZS5raW5kICE9PSBcImVycm9yXCIpIHJldHVybiBudWxsO1xuICAgIHN3aXRjaCAocGhhc2UuY29kZSkge1xuICAgICAgY2FzZSBcImF1dGgtcmVxdWlyZWRcIjpcbiAgICAgICAgcmV0dXJuIFwiU2lnbiBpbiB0byBzYXZlIHlvdXIgY2hhbmdlcy5cIjtcbiAgICAgIGNhc2UgXCJmb3JiaWRkZW5cIjpcbiAgICAgICAgcmV0dXJuIG1vZGUgPT09IFwiZGlyZWN0XCJcbiAgICAgICAgICA/IFwiVGhpcyBhcHAgY2FuJ3QgY29tbWl0IGRpcmVjdGx5LiBTd2l0Y2ggdG8gYSBwdWxsIHJlcXVlc3QuXCJcbiAgICAgICAgICA6IFwiWW91IGRvbid0IGhhdmUgcGVybWlzc2lvbiB0byBzYXZlIGhlcmUuXCI7XG4gICAgICBjYXNlIFwibm8tdGFyZ2V0XCI6XG4gICAgICAgIHJldHVybiBcIlRoZXJlJ3Mgbm90aGluZyBoZXJlIHRoYXQgY2FuIGJlIHNhdmVkIHRvIEdpdEh1Yi5cIjtcbiAgICAgIGNhc2UgXCJjb25mbGljdFwiOlxuICAgICAgICByZXR1cm4gXCJTb21lb25lIGNoYW5nZWQgdGhlc2UgZmlsZXMgdXBzdHJlYW0g4oCUIHJlZnJlc2ggYW5kIHRyeSBhZ2Fpbi5cIjtcbiAgICAgIGNhc2UgXCJnb25lXCI6XG4gICAgICAgIHJldHVybiBcIlRoZSBicmFuY2ggd2FzIGRlbGV0ZWQgdXBzdHJlYW0uXCI7XG4gICAgICBkZWZhdWx0OlxuICAgICAgICByZXR1cm4gcGhhc2UubWVzc2FnZTtcbiAgICB9XG4gIH0sIFtwaGFzZSwgbW9kZV0pO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJjb250cmlidXRlXCI+XG4gICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImN0LWhkXCI+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImN0LXRpdGxlXCI+U2F2ZSB5b3VyIGNoYW5nZXM8L3NwYW4+XG4gICAgICA8L2hlYWRlcj5cblxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiY3QtY2hhbmdlc1wiPlxuICAgICAgICB7bm90aGluZ1RvU2F2ZSA/IChcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJjdC1lbXB0eVwiPk5vIHVuc2F2ZWQgY2hhbmdlcy48L3A+XG4gICAgICAgICkgOiAoXG4gICAgICAgICAgPD5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImN0LWNoYW5nZXMtaFwiPlxuICAgICAgICAgICAgICB7ZGlydHlQYXRocy5sZW5ndGh9IGZpbGV7ZGlydHlQYXRocy5sZW5ndGggPT09IDEgPyBcIlwiIDogXCJzXCJ9IHdpbGwgYmUgc2F2ZWRcbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJjdC1maWxlbGlzdFwiPlxuICAgICAgICAgICAgICB7ZGlydHlQYXRocy5tYXAoKHApID0+IChcbiAgICAgICAgICAgICAgICA8bGkga2V5PXtwfSBjbGFzc05hbWU9XCJjdC1maWxlXCIgdGl0bGU9e3B9PlxuICAgICAgICAgICAgICAgICAge3B9XG4gICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L3VsPlxuICAgICAgICAgIDwvPlxuICAgICAgICApfVxuICAgICAgPC9zZWN0aW9uPlxuXG4gICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiY3QtZmllbGRcIj5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY3QtbGFiZWxcIj5NZXNzYWdlPC9zcGFuPlxuICAgICAgICA8aW5wdXRcbiAgICAgICAgICBjbGFzc05hbWU9XCJjdC1pbnB1dFwiXG4gICAgICAgICAgdmFsdWU9e21lc3NhZ2V9XG4gICAgICAgICAgcGxhY2Vob2xkZXI9XCJEZXNjcmliZSB5b3VyIGNoYW5nZVwiXG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRNZXNzYWdlKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICBkaXNhYmxlZD17YnVzeX1cbiAgICAgICAgLz5cbiAgICAgIDwvbGFiZWw+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY3QtbW9kZVwiIHJvbGU9XCJyYWRpb2dyb3VwXCIgYXJpYS1sYWJlbD1cIlNhdmUgbW9kZVwiPlxuICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiY3QtcmFkaW9cIj5cbiAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIHR5cGU9XCJyYWRpb1wiXG4gICAgICAgICAgICBuYW1lPVwibW9kZVwiXG4gICAgICAgICAgICBjaGVja2VkPXttb2RlID09PSBcInByXCJ9XG4gICAgICAgICAgICBvbkNoYW5nZT17KCkgPT4gc2V0TW9kZShcInByXCIpfVxuICAgICAgICAgICAgZGlzYWJsZWQ9e2J1c3l9XG4gICAgICAgICAgLz5cbiAgICAgICAgICBQdWxsIHJlcXVlc3RcbiAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImN0LXJhZGlvXCI+XG4gICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICB0eXBlPVwicmFkaW9cIlxuICAgICAgICAgICAgbmFtZT1cIm1vZGVcIlxuICAgICAgICAgICAgY2hlY2tlZD17bW9kZSA9PT0gXCJkaXJlY3RcIn1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoKSA9PiBzZXRNb2RlKFwiZGlyZWN0XCIpfVxuICAgICAgICAgICAgZGlzYWJsZWQ9e2J1c3l9XG4gICAgICAgICAgLz5cbiAgICAgICAgICBDb21taXQgZGlyZWN0bHlcbiAgICAgICAgPC9sYWJlbD5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8YnV0dG9uXG4gICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICBjbGFzc05hbWU9XCJjdC1zYXZlXCJcbiAgICAgICAgb25DbGljaz17cnVufVxuICAgICAgICBkaXNhYmxlZD17YnVzeSB8fCBub3RoaW5nVG9TYXZlfVxuICAgICAgPlxuICAgICAgICB7YnVzeSA/IFNUQUdFX0xBQkVMW3BoYXNlLnN0YWdlXSA/PyBcIlNhdmluZ+KAplwiIDogbW9kZSA9PT0gXCJkaXJlY3RcIiA/IFwiQ29tbWl0XCIgOiBcIk9wZW4gcHVsbCByZXF1ZXN0XCJ9XG4gICAgICA8L2J1dHRvbj5cblxuICAgICAge3BoYXNlLmtpbmQgPT09IFwibmVlZHMtaW5zdGFsbFwiICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjdC1zdGF0dXMgY3QtaW5zdGFsbFwiPlxuICAgICAgICAgIDxwPlxuICAgICAgICAgICAgSW5zdGFsbCB0aGUgaW1tZWRpYXRlbHkucnVuIEdpdEh1YiBBcHAgb257XCIgXCJ9XG4gICAgICAgICAgICA8c3Ryb25nPlxuICAgICAgICAgICAgICB7cGhhc2UudGFyZ2V0T3duZXJ9L3twaGFzZS50YXJnZXRSZXBvfVxuICAgICAgICAgICAgPC9zdHJvbmc+e1wiIFwifVxuICAgICAgICAgICAgdG8gc2F2ZSBoZXJlLlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8YVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiY3QtbGlua1wiXG4gICAgICAgICAgICBocmVmPXtwaGFzZS5pbnN0YWxsVXJsfVxuICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcbiAgICAgICAgICAgIHJlbD1cIm5vcmVmZXJyZXJcIlxuICAgICAgICAgICAgb25DbGljaz17KGV2KSA9PiB7XG4gICAgICAgICAgICAgIHNldExpbmtFcnJvcihudWxsKTtcbiAgICAgICAgICAgICAgb3BlbkV4dGVybmFsTGluayhwaGFzZS5pbnN0YWxsVXJsLCBldiwgc2V0TGlua0Vycm9yKTtcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgPlxuICAgICAgICAgICAgSW5zdGFsbOKAplxuICAgICAgICAgIDwvYT57XCIgXCJ9XG4gICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwiY3QtcmV0cnlcIiBvbkNsaWNrPXtydW59PlxuICAgICAgICAgICAgSSd2ZSBpbnN0YWxsZWQg4oCUIHJldHJ5XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAge3BoYXNlLmtpbmQgPT09IFwiZG9uZVwiICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjdC1zdGF0dXMgY3QtZG9uZVwiPlxuICAgICAgICAgIHtwaGFzZS5yZXN1bHQucHJVcmwgPyAoXG4gICAgICAgICAgICA8cD5cbiAgICAgICAgICAgICAgUHVsbCByZXF1ZXN0IG9wZW5lZCDigJR7XCIgXCJ9XG4gICAgICAgICAgICAgIDxhXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiY3QtbGlua1wiXG4gICAgICAgICAgICAgICAgaHJlZj17cGhhc2UucmVzdWx0LnByVXJsfVxuICAgICAgICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXG4gICAgICAgICAgICAgICAgcmVsPVwibm9yZWZlcnJlclwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KGV2KSA9PiB7XG4gICAgICAgICAgICAgICAgICBzZXRMaW5rRXJyb3IobnVsbCk7XG4gICAgICAgICAgICAgICAgICBpZiAocGhhc2UucmVzdWx0LnByVXJsKSBvcGVuRXh0ZXJuYWxMaW5rKHBoYXNlLnJlc3VsdC5wclVybCwgZXYsIHNldExpbmtFcnJvcik7XG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICN7cGhhc2UucmVzdWx0LnByTnVtYmVyfVxuICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDxwPkNvbW1pdHRlZCB7cGhhc2UucmVzdWx0LmNvbW1pdFNoYS5zbGljZSgwLCA3KX0gdG8ge3BoYXNlLnJlc3VsdC5icmFuY2hOYW1lfS48L3A+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7cGhhc2Uua2luZCA9PT0gXCJlcnJvclwiICYmIDxkaXYgY2xhc3NOYW1lPVwiY3Qtc3RhdHVzIGN0LWVycm9yXCI+e2Vycm9ySGludH08L2Rpdj59XG4gICAgICB7bGlua0Vycm9yICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjdC1zdGF0dXMgY3QtZXJyb3JcIiByb2xlPVwiYWxlcnRcIj5cbiAgICAgICAgICB7bGlua0Vycm9yfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBS0EsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsSUFBQSxHQUFBRCxPQUFBO0FBT0EsSUFBQUUsYUFBQSxHQUFBRixPQUFBO0FBQ0FBLE9BQUE7QUFBMEIsSUFBQUcsV0FBQSxHQUFBSCxPQUFBO0FBQUEsSUFBQUksRUFBQSxHQUFBQyxZQUFBLElBZDFCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFZQTtBQUNBO0FBQ0E7QUFRQTtBQUNBLE1BQU1DLFdBQW1DLEdBQUc7RUFDMUMsWUFBWSxFQUFFLG1CQUFtQjtFQUNqQyxjQUFjLEVBQUUseUJBQXlCO0VBQ3pDLGtCQUFrQixFQUFFLHVCQUF1QjtFQUMzQyxnQkFBZ0IsRUFBRSx5QkFBeUI7RUFDM0MsY0FBYyxFQUFFLHNCQUFzQjtFQUN0QyxhQUFhLEVBQUUsa0JBQWtCO0VBQ2pDLGFBQWEsRUFBRSxzQkFBc0I7RUFDckMsZUFBZSxFQUFFLHNCQUFzQjtFQUN2QyxlQUFlLEVBQUUsc0JBQXNCO0VBQ3ZDLFdBQVcsRUFBRSwyQkFBMkI7RUFDeEMsZUFBZSxFQUFFLHFCQUFxQjtFQUN0Q0MsUUFBUSxFQUFFO0FBQ1osQ0FBQztBQUVjLFNBQVNDLFVBQVVBLENBQUEsRUFBRztFQUFBSixFQUFBO0VBQ25DLE1BQU07SUFBRUs7RUFBVyxDQUFDLEdBQUcsSUFBQUMscUJBQWdCLEVBQUMsQ0FBQztFQUN6QyxNQUFNLENBQUNDLE9BQU8sRUFBRUMsVUFBVSxDQUFDLEdBQUcsSUFBQUMsZUFBUSxFQUFDLEVBQUUsQ0FBQztFQUMxQyxNQUFNLENBQUNDLElBQUksRUFBRUMsT0FBTyxDQUFDLEdBQUcsSUFBQUYsZUFBUSxFQUFpQixJQUFJLENBQUM7RUFDdEQsTUFBTSxDQUFDRyxLQUFLLEVBQUVDLFFBQVEsQ0FBQyxHQUFHLElBQUFKLGVBQVEsRUFBUTtJQUFFSyxJQUFJLEVBQUU7RUFBTyxDQUFDLENBQUM7RUFDM0Q7RUFDQTtFQUNBO0VBQ0EsTUFBTSxDQUFDQyxTQUFTLEVBQUVDLFlBQVksQ0FBQyxHQUFHLElBQUFQLGVBQVEsRUFBZ0IsSUFBSSxDQUFDO0VBRS9ELE1BQU1RLElBQUksR0FBR0wsS0FBSyxDQUFDRSxJQUFJLEtBQUssU0FBUztFQUNyQyxNQUFNSSxhQUFhLEdBQUdiLFVBQVUsQ0FBQ2MsTUFBTSxLQUFLLENBQUM7RUFFN0MsTUFBTUMsR0FBRyxHQUFHLElBQUFDLGtCQUFXLEVBQUMsWUFBWTtJQUNsQ1IsUUFBUSxDQUFDO01BQUVDLElBQUksRUFBRSxTQUFTO01BQUVRLEtBQUssRUFBRTtJQUFXLENBQUMsQ0FBQztJQUNoRCxJQUFJO01BQ0YsTUFBTUMsTUFBTSxHQUFHLElBQUFDLGVBQVUsRUFBQztRQUFFQyxhQUFhLEVBQUVsQixPQUFPLENBQUNtQixJQUFJLENBQUMsQ0FBQyxJQUFJLFFBQVE7UUFBRWhCO01BQUssQ0FBQyxDQUFDO01BQzlFLElBQUlpQixNQUFzQztNQUMxQyxXQUFXLE1BQU1DLEVBQUUsSUFBSUwsTUFBTSxFQUEyRDtRQUN0RixJQUFJSyxFQUFFLENBQUNOLEtBQUssS0FBSyxrQkFBa0IsRUFBRTtVQUNuQztVQUNBO1VBQ0FULFFBQVEsQ0FBQztZQUNQQyxJQUFJLEVBQUUsZUFBZTtZQUNyQmUsVUFBVSxFQUFFRCxFQUFFLENBQUNDLFVBQVU7WUFDekJDLFdBQVcsRUFBRUYsRUFBRSxDQUFDRSxXQUFXO1lBQzNCQyxVQUFVLEVBQUVILEVBQUUsQ0FBQ0c7VUFDakIsQ0FBQyxDQUFDO1VBQ0Y7UUFDRjtRQUNBLElBQUlILEVBQUUsQ0FBQ04sS0FBSyxLQUFLLE9BQU8sRUFBRTtVQUN4QlQsUUFBUSxDQUFDO1lBQUVDLElBQUksRUFBRSxPQUFPO1lBQUVrQixJQUFJLEVBQUUsUUFBUTtZQUFFekIsT0FBTyxFQUFFcUIsRUFBRSxDQUFDckI7VUFBUSxDQUFDLENBQUM7VUFDaEU7UUFDRjtRQUNBLElBQUlxQixFQUFFLENBQUNOLEtBQUssS0FBSyxNQUFNLEVBQUU7VUFDdkJLLE1BQU0sR0FBR0MsRUFBbUM7UUFDOUM7UUFDQWYsUUFBUSxDQUFDO1VBQUVDLElBQUksRUFBRSxTQUFTO1VBQUVRLEtBQUssRUFBRU0sRUFBRSxDQUFDTjtRQUFNLENBQUMsQ0FBQztNQUNoRDtNQUNBO01BQ0FULFFBQVEsQ0FBQztRQUFFQyxJQUFJLEVBQUUsTUFBTTtRQUFFYSxNQUFNLEVBQUVBLE1BQU0sSUFBSztVQUFFTSxTQUFTLEVBQUUsRUFBRTtVQUFFQyxPQUFPLEVBQUUsRUFBRTtVQUFFQyxVQUFVLEVBQUUsRUFBRTtVQUFFekIsSUFBSSxFQUFFO1FBQWdCO01BQXlCLENBQUMsQ0FBQztJQUM3SSxDQUFDLENBQUMsT0FBTzBCLENBQUMsRUFBRTtNQUNWLE1BQU1KLElBQUksR0FBSUksQ0FBQyxFQUF3QkosSUFBSSxJQUFJLFNBQVM7TUFDeERuQixRQUFRLENBQUM7UUFBRUMsSUFBSSxFQUFFLE9BQU87UUFBRWtCLElBQUk7UUFBRXpCLE9BQU8sRUFBRzZCLENBQUMsRUFBWTdCLE9BQU8sSUFBSTtNQUFjLENBQUMsQ0FBQztJQUNwRjtFQUNGLENBQUMsRUFBRSxDQUFDQSxPQUFPLEVBQUVHLElBQUksQ0FBQyxDQUFDO0VBRW5CLE1BQU0yQixTQUFTLEdBQUcsSUFBQUMsY0FBTyxFQUFDLE1BQU07SUFDOUIsSUFBSTFCLEtBQUssQ0FBQ0UsSUFBSSxLQUFLLE9BQU8sRUFBRSxPQUFPLElBQUk7SUFDdkMsUUFBUUYsS0FBSyxDQUFDb0IsSUFBSTtNQUNoQixLQUFLLGVBQWU7UUFDbEIsT0FBTywrQkFBK0I7TUFDeEMsS0FBSyxXQUFXO1FBQ2QsT0FBT3RCLElBQUksS0FBSyxRQUFRLEdBQ3BCLDJEQUEyRCxHQUMzRCx5Q0FBeUM7TUFDL0MsS0FBSyxXQUFXO1FBQ2QsT0FBTyxtREFBbUQ7TUFDNUQsS0FBSyxVQUFVO1FBQ2IsT0FBTywrREFBK0Q7TUFDeEUsS0FBSyxNQUFNO1FBQ1QsT0FBTyxrQ0FBa0M7TUFDM0M7UUFDRSxPQUFPRSxLQUFLLENBQUNMLE9BQU87SUFDeEI7RUFDRixDQUFDLEVBQUUsQ0FBQ0ssS0FBSyxFQUFFRixJQUFJLENBQUMsQ0FBQztFQUVqQixvQkFDRSxJQUFBWCxXQUFBLENBQUF3QyxJQUFBO0lBQUtDLFNBQVMsRUFBQyxZQUFZO0lBQUFDLFFBQUEsZ0JBQ3pCLElBQUExQyxXQUFBLENBQUEyQyxHQUFBO01BQVFGLFNBQVMsRUFBQyxPQUFPO01BQUFDLFFBQUEsZUFDdkIsSUFBQTFDLFdBQUEsQ0FBQTJDLEdBQUE7UUFBTUYsU0FBUyxFQUFDLFVBQVU7UUFBQUMsUUFBQSxFQUFDO01BQWlCLENBQU07SUFBQyxDQUM3QyxDQUFDLGVBRVQsSUFBQTFDLFdBQUEsQ0FBQTJDLEdBQUE7TUFBU0YsU0FBUyxFQUFDLFlBQVk7TUFBQUMsUUFBQSxFQUM1QnZCLGFBQWEsZ0JBQ1osSUFBQW5CLFdBQUEsQ0FBQTJDLEdBQUE7UUFBR0YsU0FBUyxFQUFDLFVBQVU7UUFBQUMsUUFBQSxFQUFDO01BQW1CLENBQUcsQ0FBQyxnQkFFL0MsSUFBQTFDLFdBQUEsQ0FBQXdDLElBQUEsRUFBQXhDLFdBQUEsQ0FBQTRDLFFBQUE7UUFBQUYsUUFBQSxnQkFDRSxJQUFBMUMsV0FBQSxDQUFBd0MsSUFBQTtVQUFHQyxTQUFTLEVBQUMsY0FBYztVQUFBQyxRQUFBLEdBQ3hCcEMsVUFBVSxDQUFDYyxNQUFNLEVBQUMsT0FBSyxFQUFDZCxVQUFVLENBQUNjLE1BQU0sS0FBSyxDQUFDLEdBQUcsRUFBRSxHQUFHLEdBQUcsRUFBQyxnQkFDOUQ7UUFBQSxDQUFHLENBQUMsZUFDSixJQUFBcEIsV0FBQSxDQUFBMkMsR0FBQTtVQUFJRixTQUFTLEVBQUMsYUFBYTtVQUFBQyxRQUFBLEVBQ3hCcEMsVUFBVSxDQUFDdUMsR0FBRyxDQUFFQyxDQUFDLGlCQUNoQixJQUFBOUMsV0FBQSxDQUFBMkMsR0FBQTtZQUFZRixTQUFTLEVBQUMsU0FBUztZQUFDTSxLQUFLLEVBQUVELENBQUU7WUFBQUosUUFBQSxFQUN0Q0k7VUFBQyxHQURLQSxDQUVMLENBQ0w7UUFBQyxDQUNBLENBQUM7TUFBQSxDQUNMO0lBQ0gsQ0FDTSxDQUFDLGVBRVYsSUFBQTlDLFdBQUEsQ0FBQXdDLElBQUE7TUFBT0MsU0FBUyxFQUFDLFVBQVU7TUFBQUMsUUFBQSxnQkFDekIsSUFBQTFDLFdBQUEsQ0FBQTJDLEdBQUE7UUFBTUYsU0FBUyxFQUFDLFVBQVU7UUFBQUMsUUFBQSxFQUFDO01BQU8sQ0FBTSxDQUFDLGVBQ3pDLElBQUExQyxXQUFBLENBQUEyQyxHQUFBO1FBQ0VGLFNBQVMsRUFBQyxVQUFVO1FBQ3BCTyxLQUFLLEVBQUV4QyxPQUFRO1FBQ2Z5QyxXQUFXLEVBQUMsc0JBQXNCO1FBQ2xDQyxRQUFRLEVBQUdiLENBQUMsSUFBSzVCLFVBQVUsQ0FBQzRCLENBQUMsQ0FBQ2MsTUFBTSxDQUFDSCxLQUFLLENBQUU7UUFDNUNJLFFBQVEsRUFBRWxDO01BQUssQ0FDaEIsQ0FBQztJQUFBLENBQ0csQ0FBQyxlQUVSLElBQUFsQixXQUFBLENBQUF3QyxJQUFBO01BQUtDLFNBQVMsRUFBQyxTQUFTO01BQUNZLElBQUksRUFBQyxZQUFZO01BQUMsY0FBVyxXQUFXO01BQUFYLFFBQUEsZ0JBQy9ELElBQUExQyxXQUFBLENBQUF3QyxJQUFBO1FBQU9DLFNBQVMsRUFBQyxVQUFVO1FBQUFDLFFBQUEsZ0JBQ3pCLElBQUExQyxXQUFBLENBQUEyQyxHQUFBO1VBQ0VXLElBQUksRUFBQyxPQUFPO1VBQ1pDLElBQUksRUFBQyxNQUFNO1VBQ1hDLE9BQU8sRUFBRTdDLElBQUksS0FBSyxJQUFLO1VBQ3ZCdUMsUUFBUSxFQUFFQSxDQUFBLEtBQU10QyxPQUFPLENBQUMsSUFBSSxDQUFFO1VBQzlCd0MsUUFBUSxFQUFFbEM7UUFBSyxDQUNoQixDQUFDLGdCQUVKO01BQUEsQ0FBTyxDQUFDLGVBQ1IsSUFBQWxCLFdBQUEsQ0FBQXdDLElBQUE7UUFBT0MsU0FBUyxFQUFDLFVBQVU7UUFBQUMsUUFBQSxnQkFDekIsSUFBQTFDLFdBQUEsQ0FBQTJDLEdBQUE7VUFDRVcsSUFBSSxFQUFDLE9BQU87VUFDWkMsSUFBSSxFQUFDLE1BQU07VUFDWEMsT0FBTyxFQUFFN0MsSUFBSSxLQUFLLFFBQVM7VUFDM0J1QyxRQUFRLEVBQUVBLENBQUEsS0FBTXRDLE9BQU8sQ0FBQyxRQUFRLENBQUU7VUFDbEN3QyxRQUFRLEVBQUVsQztRQUFLLENBQ2hCLENBQUMsbUJBRUo7TUFBQSxDQUFPLENBQUM7SUFBQSxDQUNMLENBQUMsZUFFTixJQUFBbEIsV0FBQSxDQUFBMkMsR0FBQTtNQUNFVyxJQUFJLEVBQUMsUUFBUTtNQUNiYixTQUFTLEVBQUMsU0FBUztNQUNuQmdCLE9BQU8sRUFBRXBDLEdBQUk7TUFDYitCLFFBQVEsRUFBRWxDLElBQUksSUFBSUMsYUFBYztNQUFBdUIsUUFBQSxFQUUvQnhCLElBQUksR0FBR2YsV0FBVyxDQUFDVSxLQUFLLENBQUNVLEtBQUssQ0FBQyxJQUFJLFNBQVMsR0FBR1osSUFBSSxLQUFLLFFBQVEsR0FBRyxRQUFRLEdBQUc7SUFBbUIsQ0FDNUYsQ0FBQyxFQUVSRSxLQUFLLENBQUNFLElBQUksS0FBSyxlQUFlLGlCQUM3QixJQUFBZixXQUFBLENBQUF3QyxJQUFBO01BQUtDLFNBQVMsRUFBQyxzQkFBc0I7TUFBQUMsUUFBQSxnQkFDbkMsSUFBQTFDLFdBQUEsQ0FBQXdDLElBQUE7UUFBQUUsUUFBQSxHQUFHLDJDQUN3QyxFQUFDLEdBQUcsZUFDN0MsSUFBQTFDLFdBQUEsQ0FBQXdDLElBQUE7VUFBQUUsUUFBQSxHQUNHN0IsS0FBSyxDQUFDa0IsV0FBVyxFQUFDLEdBQUMsRUFBQ2xCLEtBQUssQ0FBQ21CLFVBQVU7UUFBQSxDQUMvQixDQUFDLEVBQUMsR0FBRyxFQUFDLGVBRWhCO01BQUEsQ0FBRyxDQUFDLGVBQ0osSUFBQWhDLFdBQUEsQ0FBQTJDLEdBQUE7UUFDRUYsU0FBUyxFQUFDLFNBQVM7UUFDbkJpQixJQUFJLEVBQUU3QyxLQUFLLENBQUNpQixVQUFXO1FBQ3ZCcUIsTUFBTSxFQUFDLFFBQVE7UUFDZlEsR0FBRyxFQUFDLFlBQVk7UUFDaEJGLE9BQU8sRUFBRzVCLEVBQUUsSUFBSztVQUNmWixZQUFZLENBQUMsSUFBSSxDQUFDO1VBQ2xCLElBQUEyQyw4QkFBZ0IsRUFBQy9DLEtBQUssQ0FBQ2lCLFVBQVUsRUFBRUQsRUFBRSxFQUFFWixZQUFZLENBQUM7UUFDdEQsQ0FBRTtRQUFBeUIsUUFBQSxFQUNIO01BRUQsQ0FBRyxDQUFDLEVBQUMsR0FBRyxlQUNSLElBQUExQyxXQUFBLENBQUEyQyxHQUFBO1FBQVFXLElBQUksRUFBQyxRQUFRO1FBQUNiLFNBQVMsRUFBQyxVQUFVO1FBQUNnQixPQUFPLEVBQUVwQyxHQUFJO1FBQUFxQixRQUFBLEVBQUM7TUFFekQsQ0FBUSxDQUFDO0lBQUEsQ0FDTixDQUNOLEVBRUE3QixLQUFLLENBQUNFLElBQUksS0FBSyxNQUFNLGlCQUNwQixJQUFBZixXQUFBLENBQUEyQyxHQUFBO01BQUtGLFNBQVMsRUFBQyxtQkFBbUI7TUFBQUMsUUFBQSxFQUMvQjdCLEtBQUssQ0FBQ2UsTUFBTSxDQUFDaUMsS0FBSyxnQkFDakIsSUFBQTdELFdBQUEsQ0FBQXdDLElBQUE7UUFBQUUsUUFBQSxHQUFHLDRCQUNvQixFQUFDLEdBQUcsZUFDekIsSUFBQTFDLFdBQUEsQ0FBQXdDLElBQUE7VUFDRUMsU0FBUyxFQUFDLFNBQVM7VUFDbkJpQixJQUFJLEVBQUU3QyxLQUFLLENBQUNlLE1BQU0sQ0FBQ2lDLEtBQU07VUFDekJWLE1BQU0sRUFBQyxRQUFRO1VBQ2ZRLEdBQUcsRUFBQyxZQUFZO1VBQ2hCRixPQUFPLEVBQUc1QixFQUFFLElBQUs7WUFDZlosWUFBWSxDQUFDLElBQUksQ0FBQztZQUNsQixJQUFJSixLQUFLLENBQUNlLE1BQU0sQ0FBQ2lDLEtBQUssRUFBRSxJQUFBRCw4QkFBZ0IsRUFBQy9DLEtBQUssQ0FBQ2UsTUFBTSxDQUFDaUMsS0FBSyxFQUFFaEMsRUFBRSxFQUFFWixZQUFZLENBQUM7VUFDaEYsQ0FBRTtVQUFBeUIsUUFBQSxHQUNILEdBQ0UsRUFBQzdCLEtBQUssQ0FBQ2UsTUFBTSxDQUFDa0MsUUFBUTtRQUFBLENBQ3RCLENBQUM7TUFBQSxDQUNILENBQUMsZ0JBRUosSUFBQTlELFdBQUEsQ0FBQXdDLElBQUE7UUFBQUUsUUFBQSxHQUFHLFlBQVUsRUFBQzdCLEtBQUssQ0FBQ2UsTUFBTSxDQUFDTSxTQUFTLENBQUM2QixLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFDLE1BQUksRUFBQ2xELEtBQUssQ0FBQ2UsTUFBTSxDQUFDUSxVQUFVLEVBQUMsR0FBQztNQUFBLENBQUc7SUFDbkYsQ0FDRSxDQUNOLEVBRUF2QixLQUFLLENBQUNFLElBQUksS0FBSyxPQUFPLGlCQUFJLElBQUFmLFdBQUEsQ0FBQTJDLEdBQUE7TUFBS0YsU0FBUyxFQUFDLG9CQUFvQjtNQUFBQyxRQUFBLEVBQUVKO0lBQVMsQ0FBTSxDQUFDLEVBQy9FdEIsU0FBUyxpQkFDUixJQUFBaEIsV0FBQSxDQUFBMkMsR0FBQTtNQUFLRixTQUFTLEVBQUMsb0JBQW9CO01BQUNZLElBQUksRUFBQyxPQUFPO01BQUFYLFFBQUEsRUFDN0MxQjtJQUFTLENBQ1AsQ0FDTjtFQUFBLENBQ0UsQ0FBQztBQUVWO0FBQUNmLEVBQUEsQ0FsTXVCSSxVQUFVO0VBQUEsUUFDVEUscUJBQWdCO0FBQUE7QUFBQXlELEVBQUEsR0FEakIzRCxVQUFVO0FBQUEsSUFBQTJELEVBQUE7QUFBQUMsWUFBQSxDQUFBRCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}