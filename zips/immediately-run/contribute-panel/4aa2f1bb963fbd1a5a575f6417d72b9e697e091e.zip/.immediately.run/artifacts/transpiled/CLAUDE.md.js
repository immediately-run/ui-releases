var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      li: "li",
      p: "p",
      strong: "strong",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "contribute-panel-agent-notes",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "contribute-panel-agent-notes"
      }), "contribute-panel — agent notes"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "source-control sidebar"
      }), " immediately.run system app, bound to the\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "panel.contribute"
      }), " chrome region (UI_AS_APPS_SPEC §5.3; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "migrate-sidebars-to-apps"
      }), "\nPhase 06; roadmap R3-52). It replaces the host-native ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "SourceControlPanel"
      }), ".\nSince R3-478 the same program also serves the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "mainpane.contribute-diff"
      }), " region\n(the Source activity's main-pane half — see below)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "architecture",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "architecture"
      }), "Architecture"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/App.tsx"
        }), " — the default export immediately.run renders; branches on\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "useRegion()"
        }), ": the sidebar half (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "panel.contribute"
        }), ") or the diff half\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "mainpane.contribute-diff"
        }), "), the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "panel.tools"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "mainpane.tools"
        }), " idiom."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/components/SourceControlPanel.tsx"
        }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "container"
        }), ": wires the SDK ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "vcs"
        }), "\nsurface (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "useVcsState"
        }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "refreshDiff"
        }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "refreshPRs"
        }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "resetWorkingTree"
        }), "),\nfollows the host theme (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "useHostTheme"
        }), " → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "data-theme"
        }), "), polls the diff (1.5s) and\nPRs (15s), embeds the save flow, and posts file selections to the diff half."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/components/SourceControlView.tsx"
        }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "the view"
        }), ": takes ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "VcsState"
        }), " +\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "onRefresh"
        }), " + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "onReset"
        }), " + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "onSelectFile"
        }), ", renders the diff / branch / PR list,\nand owns presentation state (the reset arm-then-confirm toggle, the link-error\nline). One SDK-adjacent call is wired in the view itself: the PR rows' outward\nlinks go through ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/lib/externalLink.ts"
        }), " (R3-621 — the host must open them).\nUnit-tested in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "SourceControlView.test.tsx"
        }), " (no SDK/host needed)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/components/Contribute.tsx"
        }), " — the save flow, reused verbatim from the\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "immediately-run/contribute"
        }), " dialog pilot (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "contribute()"
        }), " stream + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "useEditorContext"
        }), ")."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/components/DiffPane.tsx"
        }), " — the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "main-pane half"
        }), " (R3-478): renders the\nselected changed file's diff from the host's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "vcs:diff"
        }), " catalog method\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "invoke('vcs:diff', {path, offset, limit})"
        }), ", R3-332 — unified-diff text the\nhost computes; paged by line). Selections arrive over the §5.6 IPC edge and are\nre-validated in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/lib/diffSelection.ts"
        }), " (sender + shape + the path must be in\nthe CURRENT changeset) before any fetch."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/lib/diffSelection.ts"
        }), " — the sibling protocol (pure): the one ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "select"
        }), "\nmessage, its bounds/validators, the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "vcs:diff"
        }), " reply parser, and line\nclassification. Unit-tested without the SDK."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "invariants-do-not-break",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "invariants-do-not-break"
      }), "Invariants (do not break)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["The OAuth token / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "DiffResult"
          }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "FileSystem"
          }), " never cross the boundary."]
        }), " The\napp only sees the plain-JSON ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "VcsState"
        }), " the host projects (path + status) and\nthe paged unified-diff TEXT ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "vcs:diff"
        }), " returns — never file bytes, never the\ntoken. The app ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "names"
        }), " intents; the host performs them."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The diff half is read-only."
        }), " It holds ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "vcs:read"
        }), " + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ipc"
        }), " and nothing that\nwrites (asserted host-side in site-main ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "defaults.test.ts"
        }), "); it renders, never acts."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The IPC edge is exactly the two halves of this app."
        }), " The selection message is\nthe only thing that crosses; its payload is untrusted on arrival and validated\nin ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "diffSelection.ts"
        }), " before use."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Reset needs BOTH gates"
        }), ": the first-party-only ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "vcs:reset"
        }), " authority (host) AND\nthe in-app two-click confirm. Keep the arm-then-confirm; the host also requires\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "confirm: true"
        }), " on the wire."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["Capabilities are declared in the HOST registry, not this repo's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "package.json"
        }), "."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "develop-verify",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "develop-verify"
      }), "Develop / verify"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "npm install"
      }), " · ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "npm run dev"
      }), " (standalone: empty ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "VcsState"
      }), ", no real save) ·\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "npm run build"
      }), " · ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "npm test"
      }), " (vitest)."]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/CLAUDE.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJjb2RlIiwiZW0iLCJoMSIsImgyIiwibGkiLCJwIiwic3Ryb25nIiwidWwiLCJfcHJvdmlkZUNvbXBvbmVudHMiLCJjb21wb25lbnRzIiwiSGVhZGluZ0FuY2hvciIsIl9taXNzaW5nTWR4UmVmZXJlbmNlIiwianN4cyIsIkZyYWdtZW50IiwiY2hpbGRyZW4iLCJpZCIsImpzeCIsIk1EWENvbnRlbnQiLCJ3cmFwcGVyIiwiTURYTGF5b3V0IiwiX2MiLCJjb21wb25lbnQiLCJwbGFjZSIsIkVycm9yIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQ0xBVURFLm1kIl0sInNvdXJjZXNDb250ZW50IjpbIi8qQGpzeFJ1bnRpbWUgYXV0b21hdGljKi9cbi8qQGpzeEltcG9ydFNvdXJjZSByZWFjdCovXG5pbXBvcnQge3VzZU1EWENvbXBvbmVudHMgYXMgX3Byb3ZpZGVDb21wb25lbnRzfSBmcm9tIFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGsvTURYUHJvdmlkZXJcIjtcbmZ1bmN0aW9uIF9jcmVhdGVNZHhDb250ZW50KHByb3BzKSB7XG4gIGNvbnN0IF9jb21wb25lbnRzID0ge1xuICAgIGNvZGU6IFwiY29kZVwiLFxuICAgIGVtOiBcImVtXCIsXG4gICAgaDE6IFwiaDFcIixcbiAgICBoMjogXCJoMlwiLFxuICAgIGxpOiBcImxpXCIsXG4gICAgcDogXCJwXCIsXG4gICAgc3Ryb25nOiBcInN0cm9uZ1wiLFxuICAgIHVsOiBcInVsXCIsXG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9LCB7SGVhZGluZ0FuY2hvcn0gPSBfY29tcG9uZW50cztcbiAgaWYgKCFIZWFkaW5nQW5jaG9yKSBfbWlzc2luZ01keFJlZmVyZW5jZShcIkhlYWRpbmdBbmNob3JcIiwgdHJ1ZSk7XG4gIHJldHVybiA8PjxfY29tcG9uZW50cy5oMSBpZD1cImNvbnRyaWJ1dGUtcGFuZWwtYWdlbnQtbm90ZXNcIj48SGVhZGluZ0FuY2hvciBpZD1cImNvbnRyaWJ1dGUtcGFuZWwtYWdlbnQtbm90ZXNcIiAvPntcImNvbnRyaWJ1dGUtcGFuZWwg4oCUIGFnZW50IG5vdGVzXCJ9PC9fY29tcG9uZW50cy5oMT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJzb3VyY2UtY29udHJvbCBzaWRlYmFyXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGltbWVkaWF0ZWx5LnJ1biBzeXN0ZW0gYXBwLCBib3VuZCB0byB0aGVcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJwYW5lbC5jb250cmlidXRlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjaHJvbWUgcmVnaW9uIChVSV9BU19BUFBTX1NQRUMgwqc1LjM7IFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1pZ3JhdGUtc2lkZWJhcnMtdG8tYXBwc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG5QaGFzZSAwNjsgcm9hZG1hcCBSMy01MikuIEl0IHJlcGxhY2VzIHRoZSBob3N0LW5hdGl2ZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJTb3VyY2VDb250cm9sUGFuZWxcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLlxcblNpbmNlIFIzLTQ3OCB0aGUgc2FtZSBwcm9ncmFtIGFsc28gc2VydmVzIHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJtYWlucGFuZS5jb250cmlidXRlLWRpZmZcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHJlZ2lvblxcbih0aGUgU291cmNlIGFjdGl2aXR5J3MgbWFpbi1wYW5lIGhhbGYg4oCUIHNlZSBiZWxvdykuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cImFyY2hpdGVjdHVyZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiYXJjaGl0ZWN0dXJlXCIgLz57XCJBcmNoaXRlY3R1cmVcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL0FwcC50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCB0aGUgZGVmYXVsdCBleHBvcnQgaW1tZWRpYXRlbHkucnVuIHJlbmRlcnM7IGJyYW5jaGVzIG9uXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widXNlUmVnaW9uKClcIn08L19jb21wb25lbnRzLmNvZGU+e1wiOiB0aGUgc2lkZWJhciBoYWxmIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJwYW5lbC5jb250cmlidXRlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikgb3IgdGhlIGRpZmYgaGFsZlxcbihcIn08X2NvbXBvbmVudHMuY29kZT57XCJtYWlucGFuZS5jb250cmlidXRlLWRpZmZcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSwgdGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcInBhbmVsLnRvb2xzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJtYWlucGFuZS50b29sc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaWRpb20uXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2NvbXBvbmVudHMvU291cmNlQ29udHJvbFBhbmVsLnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiY29udGFpbmVyXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiOiB3aXJlcyB0aGUgU0RLIFwifTxfY29tcG9uZW50cy5jb2RlPntcInZjc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG5zdXJmYWNlIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJ1c2VWY3NTdGF0ZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgLyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyZWZyZXNoRGlmZlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgLyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyZWZyZXNoUFJzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAvIFwifTxfY29tcG9uZW50cy5jb2RlPntcInJlc2V0V29ya2luZ1RyZWVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSxcXG5mb2xsb3dzIHRoZSBob3N0IHRoZW1lIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJ1c2VIb3N0VGhlbWVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKGkiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJkYXRhLXRoZW1lXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiksIHBvbGxzIHRoZSBkaWZmICgxLjVzKSBhbmRcXG5QUnMgKDE1cyksIGVtYmVkcyB0aGUgc2F2ZSBmbG93LCBhbmQgcG9zdHMgZmlsZSBzZWxlY3Rpb25zIHRvIHRoZSBkaWZmIGhhbGYuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2NvbXBvbmVudHMvU291cmNlQ29udHJvbFZpZXcudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ0aGUgdmlld1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIjogdGFrZXMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiVmNzU3RhdGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICtcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJvblJlZnJlc2hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wib25SZXNldFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJvblNlbGVjdEZpbGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCByZW5kZXJzIHRoZSBkaWZmIC8gYnJhbmNoIC8gUFIgbGlzdCxcXG5hbmQgb3ducyBwcmVzZW50YXRpb24gc3RhdGUgKHRoZSByZXNldCBhcm0tdGhlbi1jb25maXJtIHRvZ2dsZSwgdGhlIGxpbmstZXJyb3JcXG5saW5lKS4gT25lIFNESy1hZGphY2VudCBjYWxsIGlzIHdpcmVkIGluIHRoZSB2aWV3IGl0c2VsZjogdGhlIFBSIHJvd3MnIG91dHdhcmRcXG5saW5rcyBnbyB0aHJvdWdoIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9saWIvZXh0ZXJuYWxMaW5rLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoUjMtNjIxIOKAlCB0aGUgaG9zdCBtdXN0IG9wZW4gdGhlbSkuXFxuVW5pdC10ZXN0ZWQgaW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiU291cmNlQ29udHJvbFZpZXcudGVzdC50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChubyBTREsvaG9zdCBuZWVkZWQpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5jb2RlPntcInNyYy9jb21wb25lbnRzL0NvbnRyaWJ1dGUudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgdGhlIHNhdmUgZmxvdywgcmV1c2VkIHZlcmJhdGltIGZyb20gdGhlXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW1tZWRpYXRlbHktcnVuL2NvbnRyaWJ1dGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGRpYWxvZyBwaWxvdCAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY29udHJpYnV0ZSgpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBzdHJlYW0gKyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ1c2VFZGl0b3JDb250ZXh0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2NvbXBvbmVudHMvRGlmZlBhbmUudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibWFpbi1wYW5lIGhhbGZcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKFIzLTQ3OCk6IHJlbmRlcnMgdGhlXFxuc2VsZWN0ZWQgY2hhbmdlZCBmaWxlJ3MgZGlmZiBmcm9tIHRoZSBob3N0J3MgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widmNzOmRpZmZcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNhdGFsb2cgbWV0aG9kXFxuKFwifTxfY29tcG9uZW50cy5jb2RlPntcImludm9rZSgndmNzOmRpZmYnLCB7cGF0aCwgb2Zmc2V0LCBsaW1pdH0pXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgUjMtMzMyIOKAlCB1bmlmaWVkLWRpZmYgdGV4dCB0aGVcXG5ob3N0IGNvbXB1dGVzOyBwYWdlZCBieSBsaW5lKS4gU2VsZWN0aW9ucyBhcnJpdmUgb3ZlciB0aGUgwqc1LjYgSVBDIGVkZ2UgYW5kIGFyZVxcbnJlLXZhbGlkYXRlZCBpbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvbGliL2RpZmZTZWxlY3Rpb24udHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChzZW5kZXIgKyBzaGFwZSArIHRoZSBwYXRoIG11c3QgYmUgaW5cXG50aGUgQ1VSUkVOVCBjaGFuZ2VzZXQpIGJlZm9yZSBhbnkgZmV0Y2guXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2xpYi9kaWZmU2VsZWN0aW9uLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgdGhlIHNpYmxpbmcgcHJvdG9jb2wgKHB1cmUpOiB0aGUgb25lIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNlbGVjdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG5tZXNzYWdlLCBpdHMgYm91bmRzL3ZhbGlkYXRvcnMsIHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ2Y3M6ZGlmZlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcmVwbHkgcGFyc2VyLCBhbmQgbGluZVxcbmNsYXNzaWZpY2F0aW9uLiBVbml0LXRlc3RlZCB3aXRob3V0IHRoZSBTREsuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cImludmFyaWFudHMtZG8tbm90LWJyZWFrXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJpbnZhcmlhbnRzLWRvLW5vdC1icmVha1wiIC8+e1wiSW52YXJpYW50cyAoZG8gbm90IGJyZWFrKVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlRoZSBPQXV0aCB0b2tlbiAvIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkRpZmZSZXN1bHRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIC8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRmlsZVN5c3RlbVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgbmV2ZXIgY3Jvc3MgdGhlIGJvdW5kYXJ5LlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGVcXG5hcHAgb25seSBzZWVzIHRoZSBwbGFpbi1KU09OIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlZjc1N0YXRlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB0aGUgaG9zdCBwcm9qZWN0cyAocGF0aCArIHN0YXR1cykgYW5kXFxudGhlIHBhZ2VkIHVuaWZpZWQtZGlmZiBURVhUIFwifTxfY29tcG9uZW50cy5jb2RlPntcInZjczpkaWZmXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiByZXR1cm5zIOKAlCBuZXZlciBmaWxlIGJ5dGVzLCBuZXZlciB0aGVcXG50b2tlbi4gVGhlIGFwcCBcIn08X2NvbXBvbmVudHMuZW0+e1wibmFtZXNcIn08L19jb21wb25lbnRzLmVtPntcIiBpbnRlbnRzOyB0aGUgaG9zdCBwZXJmb3JtcyB0aGVtLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVGhlIGRpZmYgaGFsZiBpcyByZWFkLW9ubHkuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIEl0IGhvbGRzIFwifTxfY29tcG9uZW50cy5jb2RlPntcInZjczpyZWFkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiArIFwifTxfY29tcG9uZW50cy5jb2RlPntcImlwY1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYW5kIG5vdGhpbmcgdGhhdFxcbndyaXRlcyAoYXNzZXJ0ZWQgaG9zdC1zaWRlIGluIHNpdGUtbWFpbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJkZWZhdWx0cy50ZXN0LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIik7IGl0IHJlbmRlcnMsIG5ldmVyIGFjdHMuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgSVBDIGVkZ2UgaXMgZXhhY3RseSB0aGUgdHdvIGhhbHZlcyBvZiB0aGlzIGFwcC5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhlIHNlbGVjdGlvbiBtZXNzYWdlIGlzXFxudGhlIG9ubHkgdGhpbmcgdGhhdCBjcm9zc2VzOyBpdHMgcGF5bG9hZCBpcyB1bnRydXN0ZWQgb24gYXJyaXZhbCBhbmQgdmFsaWRhdGVkXFxuaW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZGlmZlNlbGVjdGlvbi50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYmVmb3JlIHVzZS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlJlc2V0IG5lZWRzIEJPVEggZ2F0ZXNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCI6IHRoZSBmaXJzdC1wYXJ0eS1vbmx5IFwifTxfY29tcG9uZW50cy5jb2RlPntcInZjczpyZXNldFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYXV0aG9yaXR5IChob3N0KSBBTkRcXG50aGUgaW4tYXBwIHR3by1jbGljayBjb25maXJtLiBLZWVwIHRoZSBhcm0tdGhlbi1jb25maXJtOyB0aGUgaG9zdCBhbHNvIHJlcXVpcmVzXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY29uZmlybTogdHJ1ZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgb24gdGhlIHdpcmUuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiQ2FwYWJpbGl0aWVzIGFyZSBkZWNsYXJlZCBpbiB0aGUgSE9TVCByZWdpc3RyeSwgbm90IHRoaXMgcmVwbydzIFwifTxfY29tcG9uZW50cy5jb2RlPntcInBhY2thZ2UuanNvblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cImRldmVsb3AtdmVyaWZ5XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJkZXZlbG9wLXZlcmlmeVwiIC8+e1wiRGV2ZWxvcCAvIHZlcmlmeVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLmNvZGU+e1wibnBtIGluc3RhbGxcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIMK3IFwifTxfY29tcG9uZW50cy5jb2RlPntcIm5wbSBydW4gZGV2XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoc3RhbmRhbG9uZTogZW1wdHkgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiVmNzU3RhdGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBubyByZWFsIHNhdmUpIMK3XFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibnBtIHJ1biBidWlsZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgwrcgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibnBtIHRlc3RcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICh2aXRlc3QpLlwifTwvX2NvbXBvbmVudHMucD48Lz47XG59XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNRFhDb250ZW50KHByb3BzID0ge30pIHtcbiAgY29uc3Qge3dyYXBwZXI6IE1EWExheW91dH0gPSB7XG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9O1xuICByZXR1cm4gTURYTGF5b3V0ID8gPE1EWExheW91dCB7Li4ucHJvcHN9PjxfY3JlYXRlTWR4Q29udGVudCB7Li4ucHJvcHN9IC8+PC9NRFhMYXlvdXQ+IDogX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpO1xufVxuZnVuY3Rpb24gX21pc3NpbmdNZHhSZWZlcmVuY2UoaWQsIGNvbXBvbmVudCwgcGxhY2UpIHtcbiAgdGhyb3cgbmV3IEVycm9yKFwiRXhwZWN0ZWQgXCIgKyAoY29tcG9uZW50ID8gXCJjb21wb25lbnRcIiA6IFwib2JqZWN0XCIpICsgXCIgYFwiICsgaWQgKyBcImAgdG8gYmUgZGVmaW5lZDogeW91IGxpa2VseSBmb3Jnb3QgdG8gaW1wb3J0LCBwYXNzLCBvciBwcm92aWRlIGl0LlwiICsgKHBsYWNlID8gXCJcXG5JdOKAmXMgcmVmZXJlbmNlZCBpbiB5b3VyIGNvZGUgYXQgYFwiICsgcGxhY2UgKyBcImAgaW4gYC9hcHAvQ0xBVURFLm1kYFwiIDogXCJcIikpO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFFQSxJQUFBQSxZQUFBLEdBQUFDLE9BQUE7QUFBd0YsSUFBQUMsV0FBQSxHQUFBRCxPQUFBO0FBRnhGO0FBQ0E7O0FBRUEsU0FBU0UsaUJBQWlCQSxDQUFDQyxLQUFLLEVBQUU7RUFDaEMsTUFBTUMsV0FBVyxHQUFHO01BQ2xCQyxJQUFJLEVBQUUsTUFBTTtNQUNaQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxDQUFDLEVBQUUsR0FBRztNQUNOQyxNQUFNLEVBQUUsUUFBUTtNQUNoQkMsRUFBRSxFQUFFLElBQUk7TUFDUixHQUFHLElBQUFDLDZCQUFrQixFQUFDLENBQUM7TUFDdkIsR0FBR1YsS0FBSyxDQUFDVztJQUNYLENBQUM7SUFBRTtNQUFDQztJQUFhLENBQUMsR0FBR1gsV0FBVztFQUNoQyxJQUFJLENBQUNXLGFBQWEsRUFBRUMsb0JBQW9CLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQztFQUMvRCxvQkFBTyxJQUFBZixXQUFBLENBQUFnQixJQUFBLEVBQUFoQixXQUFBLENBQUFpQixRQUFBO0lBQUFDLFFBQUEsZ0JBQUUsSUFBQWxCLFdBQUEsQ0FBQWdCLElBQUEsRUFBQ2IsV0FBVyxDQUFDRyxFQUFFO01BQUNhLEVBQUUsRUFBQyw4QkFBOEI7TUFBQUQsUUFBQSxnQkFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUE4QixDQUFFLENBQUMsRUFBQyxnQ0FBZ0M7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFnQixJQUFBLEVBQUNiLFdBQVcsQ0FBQ00sQ0FBQztNQUFBUyxRQUFBLEdBQUUsTUFBTSxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNPLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQXdCLENBQXFCLENBQUMsRUFBQyw2Q0FBNkMsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDQyxJQUFJO1FBQUFjLFFBQUEsRUFBRTtNQUFrQixDQUFtQixDQUFDLEVBQUMsd0NBQXdDLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBYyxRQUFBLEVBQUU7TUFBMEIsQ0FBbUIsQ0FBQyxFQUFDLDBEQUEwRCxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7UUFBQWMsUUFBQSxFQUFFO01BQW9CLENBQW1CLENBQUMsRUFBQyxtREFBbUQsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDQyxJQUFJO1FBQUFjLFFBQUEsRUFBRTtNQUEwQixDQUFtQixDQUFDLEVBQUMsOERBQThEO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbEIsV0FBQSxDQUFBZ0IsSUFBQSxFQUFDYixXQUFXLENBQUNJLEVBQUU7TUFBQ1ksRUFBRSxFQUFDLGNBQWM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFjLENBQUUsQ0FBQyxFQUFDLGNBQWM7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFnQixJQUFBLEVBQUNiLFdBQVcsQ0FBQ1EsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUFsQixXQUFBLENBQUFnQixJQUFBLEVBQUNiLFdBQVcsQ0FBQ0ssRUFBRTtRQUFBVSxRQUFBLGdCQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7VUFBQWMsUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQyxFQUFDLDhEQUE4RCxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7VUFBQWMsUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQyxFQUFDLHNCQUFzQixlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7VUFBQWMsUUFBQSxFQUFFO1FBQWtCLENBQW1CLENBQUMsRUFBQyx1QkFBdUIsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDQyxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUEwQixDQUFtQixDQUFDLEVBQUMsU0FBUyxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7VUFBQWMsUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDQyxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUFnQixDQUFtQixDQUFDLEVBQUMsU0FBUztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQWdCLElBQUEsRUFBQ2IsV0FBVyxDQUFDSyxFQUFFO1FBQUFVLFFBQUEsZ0JBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBdUMsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDTyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFXLENBQXFCLENBQUMsRUFBQyxrQkFBa0IsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDQyxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUFLLENBQW1CLENBQUMsRUFBQyxhQUFhLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBYSxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7VUFBQWMsUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDQyxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUFZLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBa0IsQ0FBbUIsQ0FBQyxFQUFDLDhCQUE4QixlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7VUFBQWMsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDQyxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUFZLENBQW1CLENBQUMsRUFBQyw0R0FBNEc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFsQixXQUFBLENBQUFnQixJQUFBLEVBQUNiLFdBQVcsQ0FBQ0ssRUFBRTtRQUFBVSxRQUFBLGdCQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7VUFBQWMsUUFBQSxFQUFFO1FBQXNDLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBVSxDQUFxQixDQUFDLEVBQUMsVUFBVSxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7VUFBQWMsUUFBQSxFQUFFO1FBQVUsQ0FBbUIsQ0FBQyxFQUFDLE1BQU0sZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDQyxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBUyxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7VUFBQWMsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLDJOQUEyTixlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7VUFBQWMsUUFBQSxFQUFFO1FBQXlCLENBQW1CLENBQUMsRUFBQyx1REFBdUQsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDQyxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUE0QixDQUFtQixDQUFDLEVBQUMsd0JBQXdCO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbEIsV0FBQSxDQUFBZ0IsSUFBQSxFQUFDYixXQUFXLENBQUNLLEVBQUU7UUFBQVUsUUFBQSxnQkFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDQyxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUErQixDQUFtQixDQUFDLEVBQUMsOENBQThDLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBNEIsQ0FBbUIsQ0FBQyxFQUFDLGlCQUFpQixlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7VUFBQWMsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLFlBQVksZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDQyxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUFrQixDQUFtQixDQUFDLEVBQUMsSUFBSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQWdCLElBQUEsRUFBQ2IsV0FBVyxDQUFDSyxFQUFFO1FBQUFVLFFBQUEsZ0JBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBNkIsQ0FBbUIsQ0FBQyxFQUFDLFNBQVMsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDTyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFnQixDQUFxQixDQUFDLEVBQUMsdUVBQXVFLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBVSxDQUFtQixDQUFDLEVBQUMsb0JBQW9CLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBMkMsQ0FBbUIsQ0FBQyxFQUFDLHFJQUFxSSxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7VUFBQWMsUUFBQSxFQUFFO1FBQTBCLENBQW1CLENBQUMsRUFBQyxrRkFBa0Y7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFsQixXQUFBLENBQUFnQixJQUFBLEVBQUNiLFdBQVcsQ0FBQ0ssRUFBRTtRQUFBVSxRQUFBLGdCQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7VUFBQWMsUUFBQSxFQUFFO1FBQTBCLENBQW1CLENBQUMsRUFBQywwQ0FBMEMsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDQyxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUFRLENBQW1CLENBQUMsRUFBQyx3Q0FBd0MsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDQyxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQyx1RUFBdUU7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQWdCLElBQUEsRUFBQ2IsV0FBVyxDQUFDSSxFQUFFO01BQUNZLEVBQUUsRUFBQyx5QkFBeUI7TUFBQUQsUUFBQSxnQkFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUF5QixDQUFFLENBQUMsRUFBQywyQkFBMkI7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFnQixJQUFBLEVBQUNiLFdBQVcsQ0FBQ1EsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUFsQixXQUFBLENBQUFnQixJQUFBLEVBQUNiLFdBQVcsQ0FBQ0ssRUFBRTtRQUFBVSxRQUFBLGdCQUFDLElBQUFsQixXQUFBLENBQUFnQixJQUFBLEVBQUNiLFdBQVcsQ0FBQ08sTUFBTTtVQUFBUSxRQUFBLEdBQUUsb0JBQW9CLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0MsSUFBSTtZQUFBYyxRQUFBLEVBQUU7VUFBWSxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7WUFBQWMsUUFBQSxFQUFFO1VBQVksQ0FBbUIsQ0FBQyxFQUFDLDRCQUE0QjtRQUFBLENBQXFCLENBQUMsRUFBQyxxQ0FBcUMsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDQyxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQyxzRUFBc0UsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDQyxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQyx5REFBeUQsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDRSxFQUFFO1VBQUFhLFFBQUEsRUFBRTtRQUFPLENBQWlCLENBQUMsRUFBQyxtQ0FBbUM7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFsQixXQUFBLENBQUFnQixJQUFBLEVBQUNiLFdBQVcsQ0FBQ0ssRUFBRTtRQUFBVSxRQUFBLGdCQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNPLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQTZCLENBQXFCLENBQUMsRUFBQyxZQUFZLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBVSxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7VUFBQWMsUUFBQSxFQUFFO1FBQUssQ0FBbUIsQ0FBQyxFQUFDLDZEQUE2RCxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7VUFBQWMsUUFBQSxFQUFFO1FBQWtCLENBQW1CLENBQUMsRUFBQyw0QkFBNEI7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFsQixXQUFBLENBQUFnQixJQUFBLEVBQUNiLFdBQVcsQ0FBQ0ssRUFBRTtRQUFBVSxRQUFBLGdCQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNPLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQXFELENBQXFCLENBQUMsRUFBQyxnSEFBZ0gsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDQyxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUFrQixDQUFtQixDQUFDLEVBQUMsY0FBYztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQWdCLElBQUEsRUFBQ2IsV0FBVyxDQUFDSyxFQUFFO1FBQUFVLFFBQUEsZ0JBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBd0IsQ0FBcUIsQ0FBQyxFQUFDLHlCQUF5QixlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7VUFBQWMsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLDBHQUEwRyxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7VUFBQWMsUUFBQSxFQUFFO1FBQWUsQ0FBbUIsQ0FBQyxFQUFDLGVBQWU7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFsQixXQUFBLENBQUFnQixJQUFBLEVBQUNiLFdBQVcsQ0FBQ0ssRUFBRTtRQUFBVSxRQUFBLEdBQUUsa0VBQWtFLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBYyxDQUFtQixDQUFDLEVBQUMsR0FBRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbEIsV0FBQSxDQUFBZ0IsSUFBQSxFQUFDYixXQUFXLENBQUNJLEVBQUU7TUFBQ1ksRUFBRSxFQUFDLGdCQUFnQjtNQUFBRCxRQUFBLGdCQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQWdCLENBQUUsQ0FBQyxFQUFDLGtCQUFrQjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQWdCLElBQUEsRUFBQ2IsV0FBVyxDQUFDTSxDQUFDO01BQUFTLFFBQUEsZ0JBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBYyxRQUFBLEVBQUU7TUFBYSxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7UUFBQWMsUUFBQSxFQUFFO01BQWEsQ0FBbUIsQ0FBQyxFQUFDLHNCQUFzQixlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7UUFBQWMsUUFBQSxFQUFFO01BQVUsQ0FBbUIsQ0FBQyxFQUFDLHFCQUFxQixlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7UUFBQWMsUUFBQSxFQUFFO01BQWUsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDQyxJQUFJO1FBQUFjLFFBQUEsRUFBRTtNQUFVLENBQW1CLENBQUMsRUFBQyxZQUFZO0lBQUEsQ0FBZ0IsQ0FBQztFQUFBLENBQUUsQ0FBQztBQUNseU47QUFDZSxTQUFTRyxVQUFVQSxDQUFDbkIsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFO0VBQzdDLE1BQU07SUFBQ29CLE9BQU8sRUFBRUM7RUFBUyxDQUFDLEdBQUc7SUFDM0IsR0FBRyxJQUFBWCw2QkFBa0IsRUFBQyxDQUFDO0lBQ3ZCLEdBQUdWLEtBQUssQ0FBQ1c7RUFDWCxDQUFDO0VBQ0QsT0FBT1UsU0FBUyxnQkFBRyxJQUFBdkIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDRyxTQUFTO0lBQUEsR0FBS3JCLEtBQUs7SUFBQWdCLFFBQUEsZUFBRSxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDbkIsaUJBQWlCO01BQUEsR0FBS0M7SUFBSyxDQUFHO0VBQUMsQ0FBVyxDQUFDLEdBQUdELGlCQUFpQixDQUFDQyxLQUFLLENBQUM7QUFDbEg7QUFBQ3NCLEVBQUEsR0FOdUJILFVBQVU7QUFPbEMsU0FBU04sb0JBQW9CQSxDQUFDSSxFQUFFLEVBQUVNLFNBQVMsRUFBRUMsS0FBSyxFQUFFO0VBQ2xELE1BQU0sSUFBSUMsS0FBSyxDQUFDLFdBQVcsSUFBSUYsU0FBUyxHQUFHLFdBQVcsR0FBRyxRQUFRLENBQUMsR0FBRyxJQUFJLEdBQUdOLEVBQUUsR0FBRyxvRUFBb0UsSUFBSU8sS0FBSyxHQUFHLHFDQUFxQyxHQUFHQSxLQUFLLEdBQUcsdUJBQXVCLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDalA7QUFBQyxJQUFBRixFQUFBO0FBQUFJLFlBQUEsQ0FBQUosRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}