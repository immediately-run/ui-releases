"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _config = require("vitest/config");
// Test config for the pure `SourceControlView` unit tests. Kept separate from
// vite.config.ts so the production build config stays plugin-clean and free of
// the vite-8 (rolldown) ⇄ vitest-bundled-vite plugin-type skew. No React plugin
// is needed here — esbuild's automatic JSX runtime handles the tsx transform, so
// `React` need not be in scope.
var _default = exports.default = (0, _config.defineConfig)({
  esbuild: {
    jsx: 'automatic'
  },
  test: {
    environment: 'jsdom',
    globals: true
  }
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY29uZmlnIiwicmVxdWlyZSIsIl9kZWZhdWx0IiwiZXhwb3J0cyIsImRlZmF1bHQiLCJkZWZpbmVDb25maWciLCJlc2J1aWxkIiwianN4IiwidGVzdCIsImVudmlyb25tZW50IiwiZ2xvYmFscyJdLCJzb3VyY2VzIjpbInZpdGVzdC5jb25maWcudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgZGVmaW5lQ29uZmlnIH0gZnJvbSAndml0ZXN0L2NvbmZpZyc7XG5cbi8vIFRlc3QgY29uZmlnIGZvciB0aGUgcHVyZSBgU291cmNlQ29udHJvbFZpZXdgIHVuaXQgdGVzdHMuIEtlcHQgc2VwYXJhdGUgZnJvbVxuLy8gdml0ZS5jb25maWcudHMgc28gdGhlIHByb2R1Y3Rpb24gYnVpbGQgY29uZmlnIHN0YXlzIHBsdWdpbi1jbGVhbiBhbmQgZnJlZSBvZlxuLy8gdGhlIHZpdGUtOCAocm9sbGRvd24pIOKHhCB2aXRlc3QtYnVuZGxlZC12aXRlIHBsdWdpbi10eXBlIHNrZXcuIE5vIFJlYWN0IHBsdWdpblxuLy8gaXMgbmVlZGVkIGhlcmUg4oCUIGVzYnVpbGQncyBhdXRvbWF0aWMgSlNYIHJ1bnRpbWUgaGFuZGxlcyB0aGUgdHN4IHRyYW5zZm9ybSwgc29cbi8vIGBSZWFjdGAgbmVlZCBub3QgYmUgaW4gc2NvcGUuXG5leHBvcnQgZGVmYXVsdCBkZWZpbmVDb25maWcoe1xuICBlc2J1aWxkOiB7IGpzeDogJ2F1dG9tYXRpYycgfSxcbiAgdGVzdDoge1xuICAgIGVudmlyb25tZW50OiAnanNkb20nLFxuICAgIGdsb2JhbHM6IHRydWUsXG4gIH0sXG59KTtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQUEsSUFBQUEsT0FBQSxHQUFBQyxPQUFBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUFBLElBQUFDLFFBQUEsR0FBQUMsT0FBQSxDQUFBQyxPQUFBLEdBQ2UsSUFBQUMsb0JBQVksRUFBQztFQUMxQkMsT0FBTyxFQUFFO0lBQUVDLEdBQUcsRUFBRTtFQUFZLENBQUM7RUFDN0JDLElBQUksRUFBRTtJQUNKQyxXQUFXLEVBQUUsT0FBTztJQUNwQkMsT0FBTyxFQUFFO0VBQ1g7QUFDRixDQUFDLENBQUMiLCJpZ25vcmVMaXN0IjpbXX0=