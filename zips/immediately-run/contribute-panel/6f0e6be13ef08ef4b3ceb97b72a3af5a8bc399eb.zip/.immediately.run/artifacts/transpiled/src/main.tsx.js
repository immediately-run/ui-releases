var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

var _react = require("react");
var _client = require("react-dom/client");
var _App = _interopRequireDefault(require("./App.tsx"));
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// Local-dev / production entry. immediately.run renders the default export of
// src/App.tsx directly and never loads this file.
(0, _client.createRoot)(document.getElementById('root')).render(/*#__PURE__*/(0, _jsxRuntime.jsx)(_react.StrictMode, {
  children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_App.default, {})
}));
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX2NsaWVudCIsIl9BcHAiLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX2pzeFJ1bnRpbWUiLCJlIiwiX19lc01vZHVsZSIsImRlZmF1bHQiLCJjcmVhdGVSb290IiwiZG9jdW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsInJlbmRlciIsImpzeCIsIlN0cmljdE1vZGUiLCJjaGlsZHJlbiJdLCJzb3VyY2VzIjpbIm1haW4udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFN0cmljdE1vZGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBjcmVhdGVSb290IH0gZnJvbSAncmVhY3QtZG9tL2NsaWVudCc7XG5pbXBvcnQgQXBwIGZyb20gJy4vQXBwLnRzeCc7XG5cbi8vIExvY2FsLWRldiAvIHByb2R1Y3Rpb24gZW50cnkuIGltbWVkaWF0ZWx5LnJ1biByZW5kZXJzIHRoZSBkZWZhdWx0IGV4cG9ydCBvZlxuLy8gc3JjL0FwcC50c3ggZGlyZWN0bHkgYW5kIG5ldmVyIGxvYWRzIHRoaXMgZmlsZS5cbmNyZWF0ZVJvb3QoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3Jvb3QnKSEpLnJlbmRlcihcbiAgPFN0cmljdE1vZGU+XG4gICAgPEFwcCAvPlxuICA8L1N0cmljdE1vZGU+LFxuKTtcbiJdLCJtYXBwaW5ncyI6Ijs7QUFBQSxJQUFBQSxNQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxPQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxJQUFBLEdBQUFDLHNCQUFBLENBQUFILE9BQUE7QUFBNEIsSUFBQUksV0FBQSxHQUFBSixPQUFBO0FBQUEsU0FBQUcsdUJBQUFFLENBQUEsV0FBQUEsQ0FBQSxJQUFBQSxDQUFBLENBQUFDLFVBQUEsR0FBQUQsQ0FBQSxLQUFBRSxPQUFBLEVBQUFGLENBQUE7QUFFNUI7QUFDQTtBQUNBLElBQUFHLGtCQUFVLEVBQUNDLFFBQVEsQ0FBQ0MsY0FBYyxDQUFDLE1BQU0sQ0FBRSxDQUFDLENBQUNDLE1BQU0sY0FDakQsSUFBQVAsV0FBQSxDQUFBUSxHQUFBLEVBQUNiLE1BQUEsQ0FBQWMsVUFBVTtFQUFBQyxRQUFBLGVBQ1QsSUFBQVYsV0FBQSxDQUFBUSxHQUFBLEVBQUNWLElBQUEsQ0FBQUssT0FBRyxJQUFFO0FBQUMsQ0FDRyxDQUNkLENBQUMiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}