var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.SourceControlPanel = void 0;
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
var _SourceControlView = _interopRequireDefault(require("./SourceControlView"));
var _Contribute = _interopRequireDefault(require("./Contribute"));
var _diffSelection = require("../lib/diffSelection");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // Container for the source-control sidebar. Wires the pure `SourceControlView`
// and the embedded `Contribute` save flow to the SDK's `vcs` surface
// (UI_AS_APPS_SPEC §5.3; migrate-sidebars Phase 06):
//   • `useVcsState()`      — the host-projected diff / branch / PR snapshot
//                            (elevated `vcs:read`; empty until the host answers)
//   • `refreshDiff()` /
//     `refreshPRs()`       — ask the host to recompute + re-push (gated `vcs:read`)
//   • `resetWorkingTree()` — discard the working tree (first-party `vcs:reset`)
// The COW/journal + OAuth token never cross; this frame only reacts to the pushed
// state and NAMES intents the host performs.
// The host recomputes the diff only when asked, so the panel polls a refresh to
// keep the change list live as the user edits (mirrors the native panel's cadence).
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
const DIFF_REFRESH_MS = 1500;
// PR polling hits the network on the host — a slower cadence keeps rate-limit
// budget for the actual save.
const PR_REFRESH_MS = 15000;
const SourceControlPanel = () => {
  _s();
  const state = (0, _sdk.useVcsState)();
  const theme = (0, _sdk.useHostTheme)();

  // Follow the host chrome theme (the design tokens key off `data-theme`).
  (0, _react.useEffect)(() => {
    document.documentElement.dataset.theme = theme;
  }, [theme]);

  // A refresh action can reject (`no-target` when there is no host contribute
  // session — e.g. not in edit mode). Swallow it: the panel simply shows the
  // empty snapshot the SDK already holds.
  const swallow = p => {
    void p.catch(() => {});
  };
  const onRefresh = (0, _react.useCallback)(() => {
    swallow((0, _sdk.refreshDiff)());
    swallow((0, _sdk.refreshPRs)());
  }, []);
  const onReset = (0, _react.useCallback)(async () => {
    try {
      await (0, _sdk.resetWorkingTree)();
    } catch {
      // The confirmed reset failed (e.g. `no-target`). The subsequent diff push
      // reflects the true state; nothing destructive happened on our side.
    }
  }, []);

  // Poll the diff (fast) and PRs (slow) on their own intervals, guarding against
  // overlapping in-flight requests so a slow host doesn't queue a backlog.
  const diffInflight = (0, _react.useRef)(false);
  (0, _react.useEffect)(() => {
    const tick = async () => {
      if (diffInflight.current) return;
      diffInflight.current = true;
      try {
        await (0, _sdk.refreshDiff)();
      } catch {
        /* no host session yet — ignore */
      } finally {
        diffInflight.current = false;
      }
    };
    void tick();
    const id = setInterval(() => void tick(), DIFF_REFRESH_MS);
    return () => clearInterval(id);
  }, []);
  const prInflight = (0, _react.useRef)(false);
  (0, _react.useEffect)(() => {
    const tick = async () => {
      if (prInflight.current) return;
      prInflight.current = true;
      try {
        await (0, _sdk.refreshPRs)();
      } catch {
        /* no host session yet — ignore */
      } finally {
        prInflight.current = false;
      }
    };
    void tick();
    const id = setInterval(() => void tick(), PR_REFRESH_MS);
    return () => clearInterval(id);
  }, []);

  // R3-478 — a row tap selects the file whose diff the main-pane half shows.
  // The post crosses the panel's ONLY IPC edge; the reveal (a column transition
  // on mobile, a focus move on desktop) must ride the same user gesture — the
  // host reads transient activation and refuses a programmatic flip. Both may
  // reject when the edge/mount isn't there (e.g. a standalone dev boot); the
  // selection highlight still updates so the panel stays self-consistent.
  const [selectedPath, setSelectedPath] = (0, _react.useState)(null);
  const onSelectFile = (0, _react.useCallback)(path => {
    setSelectedPath(path);
    const msg = {
      v: 1,
      kind: "select",
      path
    };
    void (0, _sdk.postToRegion)(_diffSelection.DIFF_PANE_REGION, msg).catch(() => {});
    void (0, _sdk.revealRegion)(_diffSelection.DIFF_PANE_REGION).catch(() => {});
  }, []);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "scp-shell",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_SourceControlView.default, {
      state: state,
      onRefresh: onRefresh,
      onReset: onReset,
      onSelectFile: onSelectFile,
      selectedPath: selectedPath
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "scp-save-region",
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Contribute.default, {})
    })]
  });
};
exports.SourceControlPanel = SourceControlPanel;
_s(SourceControlPanel, "b4qfRBc9o49NgTPwEc2xu5e5xjo=", false, function () {
  return [_sdk.useVcsState, _sdk.useHostTheme];
});
_c = SourceControlPanel;
var _default = exports.default = SourceControlPanel;
var _c;
$RefreshReg$(_c, "SourceControlPanel");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NkayIsIl9Tb3VyY2VDb250cm9sVmlldyIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJfQ29udHJpYnV0ZSIsIl9kaWZmU2VsZWN0aW9uIiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsIkRJRkZfUkVGUkVTSF9NUyIsIlBSX1JFRlJFU0hfTVMiLCJTb3VyY2VDb250cm9sUGFuZWwiLCJzdGF0ZSIsInVzZVZjc1N0YXRlIiwidGhlbWUiLCJ1c2VIb3N0VGhlbWUiLCJ1c2VFZmZlY3QiLCJkb2N1bWVudCIsImRvY3VtZW50RWxlbWVudCIsImRhdGFzZXQiLCJzd2FsbG93IiwicCIsImNhdGNoIiwib25SZWZyZXNoIiwidXNlQ2FsbGJhY2siLCJyZWZyZXNoRGlmZiIsInJlZnJlc2hQUnMiLCJvblJlc2V0IiwicmVzZXRXb3JraW5nVHJlZSIsImRpZmZJbmZsaWdodCIsInVzZVJlZiIsInRpY2siLCJjdXJyZW50IiwiaWQiLCJzZXRJbnRlcnZhbCIsImNsZWFySW50ZXJ2YWwiLCJwckluZmxpZ2h0Iiwic2VsZWN0ZWRQYXRoIiwic2V0U2VsZWN0ZWRQYXRoIiwidXNlU3RhdGUiLCJvblNlbGVjdEZpbGUiLCJwYXRoIiwibXNnIiwidiIsImtpbmQiLCJwb3N0VG9SZWdpb24iLCJESUZGX1BBTkVfUkVHSU9OIiwicmV2ZWFsUmVnaW9uIiwianN4cyIsImNsYXNzTmFtZSIsImNoaWxkcmVuIiwianN4IiwiZXhwb3J0cyIsIl9jIiwiX2RlZmF1bHQiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJTb3VyY2VDb250cm9sUGFuZWwudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIENvbnRhaW5lciBmb3IgdGhlIHNvdXJjZS1jb250cm9sIHNpZGViYXIuIFdpcmVzIHRoZSBwdXJlIGBTb3VyY2VDb250cm9sVmlld2Bcbi8vIGFuZCB0aGUgZW1iZWRkZWQgYENvbnRyaWJ1dGVgIHNhdmUgZmxvdyB0byB0aGUgU0RLJ3MgYHZjc2Agc3VyZmFjZVxuLy8gKFVJX0FTX0FQUFNfU1BFQyDCpzUuMzsgbWlncmF0ZS1zaWRlYmFycyBQaGFzZSAwNik6XG4vLyAgIOKAoiBgdXNlVmNzU3RhdGUoKWAgICAgICDigJQgdGhlIGhvc3QtcHJvamVjdGVkIGRpZmYgLyBicmFuY2ggLyBQUiBzbmFwc2hvdFxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgKGVsZXZhdGVkIGB2Y3M6cmVhZGA7IGVtcHR5IHVudGlsIHRoZSBob3N0IGFuc3dlcnMpXG4vLyAgIOKAoiBgcmVmcmVzaERpZmYoKWAgL1xuLy8gICAgIGByZWZyZXNoUFJzKClgICAgICAgIOKAlCBhc2sgdGhlIGhvc3QgdG8gcmVjb21wdXRlICsgcmUtcHVzaCAoZ2F0ZWQgYHZjczpyZWFkYClcbi8vICAg4oCiIGByZXNldFdvcmtpbmdUcmVlKClgIOKAlCBkaXNjYXJkIHRoZSB3b3JraW5nIHRyZWUgKGZpcnN0LXBhcnR5IGB2Y3M6cmVzZXRgKVxuLy8gVGhlIENPVy9qb3VybmFsICsgT0F1dGggdG9rZW4gbmV2ZXIgY3Jvc3M7IHRoaXMgZnJhbWUgb25seSByZWFjdHMgdG8gdGhlIHB1c2hlZFxuLy8gc3RhdGUgYW5kIE5BTUVTIGludGVudHMgdGhlIGhvc3QgcGVyZm9ybXMuXG5pbXBvcnQgeyB1c2VDYWxsYmFjaywgdXNlRWZmZWN0LCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQge1xuICBwb3N0VG9SZWdpb24sXG4gIHJlZnJlc2hEaWZmLFxuICByZWZyZXNoUFJzLFxuICByZXNldFdvcmtpbmdUcmVlLFxuICByZXZlYWxSZWdpb24sXG4gIHVzZUhvc3RUaGVtZSxcbiAgdXNlVmNzU3RhdGUsXG59IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nka1wiO1xuaW1wb3J0IFNvdXJjZUNvbnRyb2xWaWV3IGZyb20gXCIuL1NvdXJjZUNvbnRyb2xWaWV3XCI7XG5pbXBvcnQgQ29udHJpYnV0ZSBmcm9tIFwiLi9Db250cmlidXRlXCI7XG5pbXBvcnQgeyBESUZGX1BBTkVfUkVHSU9OLCB0eXBlIFNlbGVjdE1lc3NhZ2UgfSBmcm9tIFwiLi4vbGliL2RpZmZTZWxlY3Rpb25cIjtcblxuLy8gVGhlIGhvc3QgcmVjb21wdXRlcyB0aGUgZGlmZiBvbmx5IHdoZW4gYXNrZWQsIHNvIHRoZSBwYW5lbCBwb2xscyBhIHJlZnJlc2ggdG9cbi8vIGtlZXAgdGhlIGNoYW5nZSBsaXN0IGxpdmUgYXMgdGhlIHVzZXIgZWRpdHMgKG1pcnJvcnMgdGhlIG5hdGl2ZSBwYW5lbCdzIGNhZGVuY2UpLlxuY29uc3QgRElGRl9SRUZSRVNIX01TID0gMTUwMDtcbi8vIFBSIHBvbGxpbmcgaGl0cyB0aGUgbmV0d29yayBvbiB0aGUgaG9zdCDigJQgYSBzbG93ZXIgY2FkZW5jZSBrZWVwcyByYXRlLWxpbWl0XG4vLyBidWRnZXQgZm9yIHRoZSBhY3R1YWwgc2F2ZS5cbmNvbnN0IFBSX1JFRlJFU0hfTVMgPSAxNTAwMDtcblxuZXhwb3J0IGNvbnN0IFNvdXJjZUNvbnRyb2xQYW5lbDogUmVhY3QuRkMgPSAoKSA9PiB7XG4gIGNvbnN0IHN0YXRlID0gdXNlVmNzU3RhdGUoKTtcbiAgY29uc3QgdGhlbWUgPSB1c2VIb3N0VGhlbWUoKTtcblxuICAvLyBGb2xsb3cgdGhlIGhvc3QgY2hyb21lIHRoZW1lICh0aGUgZGVzaWduIHRva2VucyBrZXkgb2ZmIGBkYXRhLXRoZW1lYCkuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LmRhdGFzZXQudGhlbWUgPSB0aGVtZTtcbiAgfSwgW3RoZW1lXSk7XG5cbiAgLy8gQSByZWZyZXNoIGFjdGlvbiBjYW4gcmVqZWN0IChgbm8tdGFyZ2V0YCB3aGVuIHRoZXJlIGlzIG5vIGhvc3QgY29udHJpYnV0ZVxuICAvLyBzZXNzaW9uIOKAlCBlLmcuIG5vdCBpbiBlZGl0IG1vZGUpLiBTd2FsbG93IGl0OiB0aGUgcGFuZWwgc2ltcGx5IHNob3dzIHRoZVxuICAvLyBlbXB0eSBzbmFwc2hvdCB0aGUgU0RLIGFscmVhZHkgaG9sZHMuXG4gIGNvbnN0IHN3YWxsb3cgPSAocDogUHJvbWlzZTx2b2lkPikgPT4ge1xuICAgIHZvaWQgcC5jYXRjaCgoKSA9PiB7fSk7XG4gIH07XG5cbiAgY29uc3Qgb25SZWZyZXNoID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIHN3YWxsb3cocmVmcmVzaERpZmYoKSk7XG4gICAgc3dhbGxvdyhyZWZyZXNoUFJzKCkpO1xuICB9LCBbXSk7XG5cbiAgY29uc3Qgb25SZXNldCA9IHVzZUNhbGxiYWNrKGFzeW5jICgpID0+IHtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgcmVzZXRXb3JraW5nVHJlZSgpO1xuICAgIH0gY2F0Y2gge1xuICAgICAgLy8gVGhlIGNvbmZpcm1lZCByZXNldCBmYWlsZWQgKGUuZy4gYG5vLXRhcmdldGApLiBUaGUgc3Vic2VxdWVudCBkaWZmIHB1c2hcbiAgICAgIC8vIHJlZmxlY3RzIHRoZSB0cnVlIHN0YXRlOyBub3RoaW5nIGRlc3RydWN0aXZlIGhhcHBlbmVkIG9uIG91ciBzaWRlLlxuICAgIH1cbiAgfSwgW10pO1xuXG4gIC8vIFBvbGwgdGhlIGRpZmYgKGZhc3QpIGFuZCBQUnMgKHNsb3cpIG9uIHRoZWlyIG93biBpbnRlcnZhbHMsIGd1YXJkaW5nIGFnYWluc3RcbiAgLy8gb3ZlcmxhcHBpbmcgaW4tZmxpZ2h0IHJlcXVlc3RzIHNvIGEgc2xvdyBob3N0IGRvZXNuJ3QgcXVldWUgYSBiYWNrbG9nLlxuICBjb25zdCBkaWZmSW5mbGlnaHQgPSB1c2VSZWYoZmFsc2UpO1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IHRpY2sgPSBhc3luYyAoKSA9PiB7XG4gICAgICBpZiAoZGlmZkluZmxpZ2h0LmN1cnJlbnQpIHJldHVybjtcbiAgICAgIGRpZmZJbmZsaWdodC5jdXJyZW50ID0gdHJ1ZTtcbiAgICAgIHRyeSB7XG4gICAgICAgIGF3YWl0IHJlZnJlc2hEaWZmKCk7XG4gICAgICB9IGNhdGNoIHtcbiAgICAgICAgLyogbm8gaG9zdCBzZXNzaW9uIHlldCDigJQgaWdub3JlICovXG4gICAgICB9IGZpbmFsbHkge1xuICAgICAgICBkaWZmSW5mbGlnaHQuY3VycmVudCA9IGZhbHNlO1xuICAgICAgfVxuICAgIH07XG4gICAgdm9pZCB0aWNrKCk7XG4gICAgY29uc3QgaWQgPSBzZXRJbnRlcnZhbCgoKSA9PiB2b2lkIHRpY2soKSwgRElGRl9SRUZSRVNIX01TKTtcbiAgICByZXR1cm4gKCkgPT4gY2xlYXJJbnRlcnZhbChpZCk7XG4gIH0sIFtdKTtcblxuICBjb25zdCBwckluZmxpZ2h0ID0gdXNlUmVmKGZhbHNlKTtcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCB0aWNrID0gYXN5bmMgKCkgPT4ge1xuICAgICAgaWYgKHBySW5mbGlnaHQuY3VycmVudCkgcmV0dXJuO1xuICAgICAgcHJJbmZsaWdodC5jdXJyZW50ID0gdHJ1ZTtcbiAgICAgIHRyeSB7XG4gICAgICAgIGF3YWl0IHJlZnJlc2hQUnMoKTtcbiAgICAgIH0gY2F0Y2gge1xuICAgICAgICAvKiBubyBob3N0IHNlc3Npb24geWV0IOKAlCBpZ25vcmUgKi9cbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIHBySW5mbGlnaHQuY3VycmVudCA9IGZhbHNlO1xuICAgICAgfVxuICAgIH07XG4gICAgdm9pZCB0aWNrKCk7XG4gICAgY29uc3QgaWQgPSBzZXRJbnRlcnZhbCgoKSA9PiB2b2lkIHRpY2soKSwgUFJfUkVGUkVTSF9NUyk7XG4gICAgcmV0dXJuICgpID0+IGNsZWFySW50ZXJ2YWwoaWQpO1xuICB9LCBbXSk7XG5cbiAgLy8gUjMtNDc4IOKAlCBhIHJvdyB0YXAgc2VsZWN0cyB0aGUgZmlsZSB3aG9zZSBkaWZmIHRoZSBtYWluLXBhbmUgaGFsZiBzaG93cy5cbiAgLy8gVGhlIHBvc3QgY3Jvc3NlcyB0aGUgcGFuZWwncyBPTkxZIElQQyBlZGdlOyB0aGUgcmV2ZWFsIChhIGNvbHVtbiB0cmFuc2l0aW9uXG4gIC8vIG9uIG1vYmlsZSwgYSBmb2N1cyBtb3ZlIG9uIGRlc2t0b3ApIG11c3QgcmlkZSB0aGUgc2FtZSB1c2VyIGdlc3R1cmUg4oCUIHRoZVxuICAvLyBob3N0IHJlYWRzIHRyYW5zaWVudCBhY3RpdmF0aW9uIGFuZCByZWZ1c2VzIGEgcHJvZ3JhbW1hdGljIGZsaXAuIEJvdGggbWF5XG4gIC8vIHJlamVjdCB3aGVuIHRoZSBlZGdlL21vdW50IGlzbid0IHRoZXJlIChlLmcuIGEgc3RhbmRhbG9uZSBkZXYgYm9vdCk7IHRoZVxuICAvLyBzZWxlY3Rpb24gaGlnaGxpZ2h0IHN0aWxsIHVwZGF0ZXMgc28gdGhlIHBhbmVsIHN0YXlzIHNlbGYtY29uc2lzdGVudC5cbiAgY29uc3QgW3NlbGVjdGVkUGF0aCwgc2V0U2VsZWN0ZWRQYXRoXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICBjb25zdCBvblNlbGVjdEZpbGUgPSB1c2VDYWxsYmFjaygocGF0aDogc3RyaW5nKSA9PiB7XG4gICAgc2V0U2VsZWN0ZWRQYXRoKHBhdGgpO1xuICAgIGNvbnN0IG1zZzogU2VsZWN0TWVzc2FnZSA9IHsgdjogMSwga2luZDogXCJzZWxlY3RcIiwgcGF0aCB9O1xuICAgIHZvaWQgcG9zdFRvUmVnaW9uKERJRkZfUEFORV9SRUdJT04sIG1zZykuY2F0Y2goKCkgPT4ge30pO1xuICAgIHZvaWQgcmV2ZWFsUmVnaW9uKERJRkZfUEFORV9SRUdJT04pLmNhdGNoKCgpID0+IHt9KTtcbiAgfSwgW10pO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzY3Atc2hlbGxcIj5cbiAgICAgIDxTb3VyY2VDb250cm9sVmlld1xuICAgICAgICBzdGF0ZT17c3RhdGV9XG4gICAgICAgIG9uUmVmcmVzaD17b25SZWZyZXNofVxuICAgICAgICBvblJlc2V0PXtvblJlc2V0fVxuICAgICAgICBvblNlbGVjdEZpbGU9e29uU2VsZWN0RmlsZX1cbiAgICAgICAgc2VsZWN0ZWRQYXRoPXtzZWxlY3RlZFBhdGh9XG4gICAgICAvPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJzY3Atc2F2ZS1yZWdpb25cIj5cbiAgICAgICAgPENvbnRyaWJ1dGUgLz5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgU291cmNlQ29udHJvbFBhbmVsO1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFVQSxJQUFBQSxNQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxJQUFBLEdBQUFELE9BQUE7QUFTQSxJQUFBRSxrQkFBQSxHQUFBQyxzQkFBQSxDQUFBSCxPQUFBO0FBQ0EsSUFBQUksV0FBQSxHQUFBRCxzQkFBQSxDQUFBSCxPQUFBO0FBQ0EsSUFBQUssY0FBQSxHQUFBTCxPQUFBO0FBQTRFLElBQUFNLFdBQUEsR0FBQU4sT0FBQTtBQUFBLElBQUFPLEVBQUEsR0FBQUMsWUFBQSxJQXRCNUU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFlQTtBQUNBO0FBQUEsU0FBQUwsdUJBQUFNLENBQUEsV0FBQUEsQ0FBQSxJQUFBQSxDQUFBLENBQUFDLFVBQUEsR0FBQUQsQ0FBQSxLQUFBRSxPQUFBLEVBQUFGLENBQUE7QUFDQSxNQUFNRyxlQUFlLEdBQUcsSUFBSTtBQUM1QjtBQUNBO0FBQ0EsTUFBTUMsYUFBYSxHQUFHLEtBQUs7QUFFcEIsTUFBTUMsa0JBQTRCLEdBQUdBLENBQUEsS0FBTTtFQUFBUCxFQUFBO0VBQ2hELE1BQU1RLEtBQUssR0FBRyxJQUFBQyxnQkFBVyxFQUFDLENBQUM7RUFDM0IsTUFBTUMsS0FBSyxHQUFHLElBQUFDLGlCQUFZLEVBQUMsQ0FBQzs7RUFFNUI7RUFDQSxJQUFBQyxnQkFBUyxFQUFDLE1BQU07SUFDZEMsUUFBUSxDQUFDQyxlQUFlLENBQUNDLE9BQU8sQ0FBQ0wsS0FBSyxHQUFHQSxLQUFLO0VBQ2hELENBQUMsRUFBRSxDQUFDQSxLQUFLLENBQUMsQ0FBQzs7RUFFWDtFQUNBO0VBQ0E7RUFDQSxNQUFNTSxPQUFPLEdBQUlDLENBQWdCLElBQUs7SUFDcEMsS0FBS0EsQ0FBQyxDQUFDQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztFQUN4QixDQUFDO0VBRUQsTUFBTUMsU0FBUyxHQUFHLElBQUFDLGtCQUFXLEVBQUMsTUFBTTtJQUNsQ0osT0FBTyxDQUFDLElBQUFLLGdCQUFXLEVBQUMsQ0FBQyxDQUFDO0lBQ3RCTCxPQUFPLENBQUMsSUFBQU0sZUFBVSxFQUFDLENBQUMsQ0FBQztFQUN2QixDQUFDLEVBQUUsRUFBRSxDQUFDO0VBRU4sTUFBTUMsT0FBTyxHQUFHLElBQUFILGtCQUFXLEVBQUMsWUFBWTtJQUN0QyxJQUFJO01BQ0YsTUFBTSxJQUFBSSxxQkFBZ0IsRUFBQyxDQUFDO0lBQzFCLENBQUMsQ0FBQyxNQUFNO01BQ047TUFDQTtJQUFBO0VBRUosQ0FBQyxFQUFFLEVBQUUsQ0FBQzs7RUFFTjtFQUNBO0VBQ0EsTUFBTUMsWUFBWSxHQUFHLElBQUFDLGFBQU0sRUFBQyxLQUFLLENBQUM7RUFDbEMsSUFBQWQsZ0JBQVMsRUFBQyxNQUFNO0lBQ2QsTUFBTWUsSUFBSSxHQUFHLE1BQUFBLENBQUEsS0FBWTtNQUN2QixJQUFJRixZQUFZLENBQUNHLE9BQU8sRUFBRTtNQUMxQkgsWUFBWSxDQUFDRyxPQUFPLEdBQUcsSUFBSTtNQUMzQixJQUFJO1FBQ0YsTUFBTSxJQUFBUCxnQkFBVyxFQUFDLENBQUM7TUFDckIsQ0FBQyxDQUFDLE1BQU07UUFDTjtNQUFBLENBQ0QsU0FBUztRQUNSSSxZQUFZLENBQUNHLE9BQU8sR0FBRyxLQUFLO01BQzlCO0lBQ0YsQ0FBQztJQUNELEtBQUtELElBQUksQ0FBQyxDQUFDO0lBQ1gsTUFBTUUsRUFBRSxHQUFHQyxXQUFXLENBQUMsTUFBTSxLQUFLSCxJQUFJLENBQUMsQ0FBQyxFQUFFdEIsZUFBZSxDQUFDO0lBQzFELE9BQU8sTUFBTTBCLGFBQWEsQ0FBQ0YsRUFBRSxDQUFDO0VBQ2hDLENBQUMsRUFBRSxFQUFFLENBQUM7RUFFTixNQUFNRyxVQUFVLEdBQUcsSUFBQU4sYUFBTSxFQUFDLEtBQUssQ0FBQztFQUNoQyxJQUFBZCxnQkFBUyxFQUFDLE1BQU07SUFDZCxNQUFNZSxJQUFJLEdBQUcsTUFBQUEsQ0FBQSxLQUFZO01BQ3ZCLElBQUlLLFVBQVUsQ0FBQ0osT0FBTyxFQUFFO01BQ3hCSSxVQUFVLENBQUNKLE9BQU8sR0FBRyxJQUFJO01BQ3pCLElBQUk7UUFDRixNQUFNLElBQUFOLGVBQVUsRUFBQyxDQUFDO01BQ3BCLENBQUMsQ0FBQyxNQUFNO1FBQ047TUFBQSxDQUNELFNBQVM7UUFDUlUsVUFBVSxDQUFDSixPQUFPLEdBQUcsS0FBSztNQUM1QjtJQUNGLENBQUM7SUFDRCxLQUFLRCxJQUFJLENBQUMsQ0FBQztJQUNYLE1BQU1FLEVBQUUsR0FBR0MsV0FBVyxDQUFDLE1BQU0sS0FBS0gsSUFBSSxDQUFDLENBQUMsRUFBRXJCLGFBQWEsQ0FBQztJQUN4RCxPQUFPLE1BQU15QixhQUFhLENBQUNGLEVBQUUsQ0FBQztFQUNoQyxDQUFDLEVBQUUsRUFBRSxDQUFDOztFQUVOO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU0sQ0FBQ0ksWUFBWSxFQUFFQyxlQUFlLENBQUMsR0FBRyxJQUFBQyxlQUFRLEVBQWdCLElBQUksQ0FBQztFQUNyRSxNQUFNQyxZQUFZLEdBQUcsSUFBQWhCLGtCQUFXLEVBQUVpQixJQUFZLElBQUs7SUFDakRILGVBQWUsQ0FBQ0csSUFBSSxDQUFDO0lBQ3JCLE1BQU1DLEdBQWtCLEdBQUc7TUFBRUMsQ0FBQyxFQUFFLENBQUM7TUFBRUMsSUFBSSxFQUFFLFFBQVE7TUFBRUg7SUFBSyxDQUFDO0lBQ3pELEtBQUssSUFBQUksaUJBQVksRUFBQ0MsK0JBQWdCLEVBQUVKLEdBQUcsQ0FBQyxDQUFDcEIsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7SUFDeEQsS0FBSyxJQUFBeUIsaUJBQVksRUFBQ0QsK0JBQWdCLENBQUMsQ0FBQ3hCLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0VBQ3JELENBQUMsRUFBRSxFQUFFLENBQUM7RUFFTixvQkFDRSxJQUFBbkIsV0FBQSxDQUFBNkMsSUFBQTtJQUFLQyxTQUFTLEVBQUMsV0FBVztJQUFBQyxRQUFBLGdCQUN4QixJQUFBL0MsV0FBQSxDQUFBZ0QsR0FBQSxFQUFDcEQsa0JBQUEsQ0FBQVMsT0FBaUI7TUFDaEJJLEtBQUssRUFBRUEsS0FBTTtNQUNiVyxTQUFTLEVBQUVBLFNBQVU7TUFDckJJLE9BQU8sRUFBRUEsT0FBUTtNQUNqQmEsWUFBWSxFQUFFQSxZQUFhO01BQzNCSCxZQUFZLEVBQUVBO0lBQWEsQ0FDNUIsQ0FBQyxlQUNGLElBQUFsQyxXQUFBLENBQUFnRCxHQUFBO01BQUtGLFNBQVMsRUFBQyxpQkFBaUI7TUFBQUMsUUFBQSxlQUM5QixJQUFBL0MsV0FBQSxDQUFBZ0QsR0FBQSxFQUFDbEQsV0FBQSxDQUFBTyxPQUFVLElBQUU7SUFBQyxDQUNYLENBQUM7RUFBQSxDQUNILENBQUM7QUFFVixDQUFDO0FBQUM0QyxPQUFBLENBQUF6QyxrQkFBQSxHQUFBQSxrQkFBQTtBQUFBUCxFQUFBLENBaEdXTyxrQkFBNEI7RUFBQSxRQUN6QkUsZ0JBQVcsRUFDWEUsaUJBQVk7QUFBQTtBQUFBc0MsRUFBQSxHQUZmMUMsa0JBQTRCO0FBQUEsSUFBQTJDLFFBQUEsR0FBQUYsT0FBQSxDQUFBNUMsT0FBQSxHQWtHMUJHLGtCQUFrQjtBQUFBLElBQUEwQyxFQUFBO0FBQUFFLFlBQUEsQ0FBQUYsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}