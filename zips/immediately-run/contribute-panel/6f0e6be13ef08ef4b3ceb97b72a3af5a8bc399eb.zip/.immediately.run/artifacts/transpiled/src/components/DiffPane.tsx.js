var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.DiffPane = void 0;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.find.js");
require("core-js/modules/esnext.iterator.flat-map.js");
require("core-js/modules/esnext.iterator.map.js");
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
var _diffSelection = require("../lib/diffSelection");
require("./DiffPane.css");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The Source activity's MAIN-PANE half (R3-478): renders the selected changed
// file's diff. Same repo as the panel, different region — `App.tsx` branches on
// `useRegion()` (the devtools one-repo-many-bindings idiom). The two halves are
// two frames with no shared memory; the selection arrives over their single
// §5.6 IPC edge and is re-validated here (`parseSelectMessage` + the current
// changeset) before it becomes a diff fetch.
//
// The diff itself comes from the host's `vcs:diff` catalog method (R3-332,
// `vcs:read`): unified-diff text the host computes from the COW layers, paged
// by line. No `DiffResult`, no raw bytes, no token ever crosses — this frame
// renders a projection and names no write intent at all.
/** A load is only rendered while its key matches the live selection+changeset —
 *  a stale load (selection moved, tree changed) reads as "loading", never as a
 *  wrong diff. Windows are the appended `vcs:diff` pages. */
/** The render note for the currently shown file, or "ok". */
const noteFor = (reply, path) => {
  const note = reply.files.find(f => f.path === path);
  return note?.rendered ?? "ok";
};
const NOTE_TEXT = {
  binary: "Binary file — diff not shown.",
  "too-large": "File too large to diff inline.",
  unreadable: "The prior version of this file could not be read."
};
const DiffPane = () => {
  _s();
  const region = (0, _sdk.useRegion)();
  const theme = (0, _sdk.useHostTheme)();
  const state = (0, _sdk.useVcsState)();
  (0, _react.useEffect)(() => {
    document.documentElement.dataset.theme = theme;
  }, [theme]);

  // The selected path: set by a panel row tap, defaulted to the first change so
  // the pane never idles empty next to a dirty tree, and dropped the moment the
  // path leaves the changeset (the change was saved/reverted — showing a stale
  // diff would be a lie).
  const [selected, setSelected] = (0, _react.useState)(null);
  const valid = (0, _react.useMemo)(() => (0, _diffSelection.changedPaths)(state), [state]);
  const effective = selected !== null && valid.has(selected) ? selected : (0, _diffSelection.defaultSelection)(state);

  // The listener validates the arriving path against the LIVE changeset, but the
  // subscription must not churn on every state push — so it reads through a ref
  // kept current by an effect (never written during render).
  const stateRef = (0, _react.useRef)(state);
  (0, _react.useEffect)(() => {
    stateRef.current = state;
  }, [state]);
  (0, _react.useEffect)(() => {
    return (0, _sdk.onRegionMessage)(({
      from,
      data
    }) => {
      const path = (0, _diffSelection.parseSelectMessage)(from, data);
      if (path === null) return;
      if ((0, _diffSelection.changedPaths)(stateRef.current).has(path)) setSelected(path);
    });
  }, []);

  // Fetch the diff for the effective selection; re-fetch when the selection
  // changes OR the changeset's shape changes (a save/reflow produces new hunks
  // for the same path). All state writes happen in async callbacks, keyed by
  // what they were fetched FOR, so a superseded reply can never render.
  const changesKey = (0, _react.useMemo)(() => state.changes.map(c => `${c.status}:${c.path}`).join("|"), [state.changes]);
  const key = `${effective ?? ""}#${changesKey}`;
  const [loaded, setLoaded] = (0, _react.useState)(null);
  (0, _react.useEffect)(() => {
    if (effective === null) return;
    let cancelled = false;
    (0, _sdk.invoke)("vcs:diff", {
      path: effective,
      offset: 1,
      limit: _diffSelection.DIFF_PAGE_LINES
    }).then(v => {
      if (cancelled) return;
      const reply = (0, _diffSelection.parseDiffReply)(v);
      if (!reply) {
        setLoaded({
          key,
          windows: [],
          error: "The host returned a malformed diff."
        });
        return;
      }
      setLoaded({
        key,
        windows: [reply],
        error: null
      });
    }).catch(e => {
      if (cancelled) return;
      setLoaded({
        key,
        windows: [],
        error: e instanceof Error ? e.message : "The diff could not be loaded."
      });
    });
    return () => {
      cancelled = true;
    };
  }, [effective, changesKey, key]);
  const current = loaded !== null && loaded.key === key ? loaded : null;
  const first = current?.windows[0];
  const last = current?.windows[current.windows.length - 1];
  const loadMore = (0, _react.useCallback)(() => {
    if (!current || current.error !== null || effective === null) return;
    const last = current.windows[current.windows.length - 1];
    if (!last || last.nextOffset === null) return;
    const offset = last.nextOffset;
    (0, _sdk.invoke)("vcs:diff", {
      path: effective,
      offset,
      limit: _diffSelection.DIFF_PAGE_LINES
    }).then(v => {
      const reply = (0, _diffSelection.parseDiffReply)(v);
      if (!reply) return;
      setLoaded(cur => cur && cur.key === key ? {
        ...cur,
        windows: [...cur.windows, reply]
      } : cur);
    }).catch(() => {
      /* keep what we have; the paging affordance stays on the last window */
    });
  }, [current, key, effective]);
  const shownLines = (0, _react.useMemo)(() => first ? current.windows.flatMap(w => (0, _diffSelection.diffLines)(w.text)) : [], [current, first]);
  const note = first && effective !== null ? noteFor(first, effective) : "ok";
  const statusOf = p => state.changes.find(c => c.path === p)?.status;
  if (region !== "mainpane.contribute-diff") {
    // Guard: never render the pane half outside its own region.
    return null;
  }
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "dp",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "dp-hd",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "dp-title",
        children: effective !== null ? /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
            className: "dp-badge",
            "data-kind": statusOf(effective),
            children: statusOf(effective) === "created" ? "A" : statusOf(effective) === "deleted" ? "D" : "M"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
            className: "dp-path",
            title: effective,
            children: effective
          })]
        }) : "Changes"
      }), first && effective !== null && note === "ok" && current?.error === null && /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
        className: "dp-muted",
        children: [first.totalLines, " line", first.totalLines === 1 ? "" : "s"]
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "dp-body",
      children: [effective === null && /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "dp-empty",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
          className: "dp-empty-msg",
          children: "Nothing to show."
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
          className: "dp-empty-sub",
          children: "Edit files in the editor \u2014 select a change in the Source panel to see its diff here."
        })]
      }), effective !== null && !current && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "dp-status",
        children: "Loading diff\u2026"
      }), effective !== null && current && current.error !== null && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "dp-status dp-error",
        children: current.error
      }), effective !== null && current && current.error === null && note !== "ok" && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "dp-status",
        children: NOTE_TEXT[note] ?? "Diff unavailable."
      }), effective !== null && current && current.error === null && note === "ok" && shownLines.length === 0 && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "dp-status",
        children: "No textual changes."
      }), effective !== null && current && current.error === null && note === "ok" && shownLines.length > 0 && /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
          className: "dp-diff",
          role: "table",
          "aria-label": `Diff of ${effective}`,
          children: shownLines.map((line, i) => /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
            className: "dp-row",
            "data-kind": (0, _diffSelection.classifyDiffLine)(line),
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
              className: "dp-text",
              children: line || " "
            })
          }, i))
        }), last && last.nextOffset !== null && /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
          type: "button",
          className: "dp-more",
          onClick: loadMore,
          children: ["Show more (", last.endLine, " of ", last.totalLines, " lines)"]
        })]
      })]
    })]
  });
};
exports.DiffPane = DiffPane;
_s(DiffPane, "UYgcC4Lm9zLFFIg5+TYnCvoiQ8M=", false, function () {
  return [_sdk.useRegion, _sdk.useHostTheme, _sdk.useVcsState];
});
_c = DiffPane;
var _default = exports.default = DiffPane;
var _c;
$RefreshReg$(_c, "DiffPane");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NkayIsIl9kaWZmU2VsZWN0aW9uIiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsIm5vdGVGb3IiLCJyZXBseSIsInBhdGgiLCJub3RlIiwiZmlsZXMiLCJmaW5kIiwiZiIsInJlbmRlcmVkIiwiTk9URV9URVhUIiwiYmluYXJ5IiwidW5yZWFkYWJsZSIsIkRpZmZQYW5lIiwicmVnaW9uIiwidXNlUmVnaW9uIiwidGhlbWUiLCJ1c2VIb3N0VGhlbWUiLCJzdGF0ZSIsInVzZVZjc1N0YXRlIiwidXNlRWZmZWN0IiwiZG9jdW1lbnQiLCJkb2N1bWVudEVsZW1lbnQiLCJkYXRhc2V0Iiwic2VsZWN0ZWQiLCJzZXRTZWxlY3RlZCIsInVzZVN0YXRlIiwidmFsaWQiLCJ1c2VNZW1vIiwiY2hhbmdlZFBhdGhzIiwiZWZmZWN0aXZlIiwiaGFzIiwiZGVmYXVsdFNlbGVjdGlvbiIsInN0YXRlUmVmIiwidXNlUmVmIiwiY3VycmVudCIsIm9uUmVnaW9uTWVzc2FnZSIsImZyb20iLCJkYXRhIiwicGFyc2VTZWxlY3RNZXNzYWdlIiwiY2hhbmdlc0tleSIsImNoYW5nZXMiLCJtYXAiLCJjIiwic3RhdHVzIiwiam9pbiIsImtleSIsImxvYWRlZCIsInNldExvYWRlZCIsImNhbmNlbGxlZCIsImludm9rZSIsIm9mZnNldCIsImxpbWl0IiwiRElGRl9QQUdFX0xJTkVTIiwidGhlbiIsInYiLCJwYXJzZURpZmZSZXBseSIsIndpbmRvd3MiLCJlcnJvciIsImNhdGNoIiwiZSIsIkVycm9yIiwibWVzc2FnZSIsImZpcnN0IiwibGFzdCIsImxlbmd0aCIsImxvYWRNb3JlIiwidXNlQ2FsbGJhY2siLCJuZXh0T2Zmc2V0IiwiY3VyIiwic2hvd25MaW5lcyIsImZsYXRNYXAiLCJ3IiwiZGlmZkxpbmVzIiwidGV4dCIsInN0YXR1c09mIiwicCIsImpzeHMiLCJjbGFzc05hbWUiLCJjaGlsZHJlbiIsImpzeCIsIkZyYWdtZW50IiwidGl0bGUiLCJ0b3RhbExpbmVzIiwicm9sZSIsImxpbmUiLCJpIiwiY2xhc3NpZnlEaWZmTGluZSIsInR5cGUiLCJvbkNsaWNrIiwiZW5kTGluZSIsImV4cG9ydHMiLCJfYyIsIl9kZWZhdWx0IiwiZGVmYXVsdCIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkRpZmZQYW5lLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBUaGUgU291cmNlIGFjdGl2aXR5J3MgTUFJTi1QQU5FIGhhbGYgKFIzLTQ3OCk6IHJlbmRlcnMgdGhlIHNlbGVjdGVkIGNoYW5nZWRcbi8vIGZpbGUncyBkaWZmLiBTYW1lIHJlcG8gYXMgdGhlIHBhbmVsLCBkaWZmZXJlbnQgcmVnaW9uIOKAlCBgQXBwLnRzeGAgYnJhbmNoZXMgb25cbi8vIGB1c2VSZWdpb24oKWAgKHRoZSBkZXZ0b29scyBvbmUtcmVwby1tYW55LWJpbmRpbmdzIGlkaW9tKS4gVGhlIHR3byBoYWx2ZXMgYXJlXG4vLyB0d28gZnJhbWVzIHdpdGggbm8gc2hhcmVkIG1lbW9yeTsgdGhlIHNlbGVjdGlvbiBhcnJpdmVzIG92ZXIgdGhlaXIgc2luZ2xlXG4vLyDCpzUuNiBJUEMgZWRnZSBhbmQgaXMgcmUtdmFsaWRhdGVkIGhlcmUgKGBwYXJzZVNlbGVjdE1lc3NhZ2VgICsgdGhlIGN1cnJlbnRcbi8vIGNoYW5nZXNldCkgYmVmb3JlIGl0IGJlY29tZXMgYSBkaWZmIGZldGNoLlxuLy9cbi8vIFRoZSBkaWZmIGl0c2VsZiBjb21lcyBmcm9tIHRoZSBob3N0J3MgYHZjczpkaWZmYCBjYXRhbG9nIG1ldGhvZCAoUjMtMzMyLFxuLy8gYHZjczpyZWFkYCk6IHVuaWZpZWQtZGlmZiB0ZXh0IHRoZSBob3N0IGNvbXB1dGVzIGZyb20gdGhlIENPVyBsYXllcnMsIHBhZ2VkXG4vLyBieSBsaW5lLiBObyBgRGlmZlJlc3VsdGAsIG5vIHJhdyBieXRlcywgbm8gdG9rZW4gZXZlciBjcm9zc2VzIOKAlCB0aGlzIGZyYW1lXG4vLyByZW5kZXJzIGEgcHJvamVjdGlvbiBhbmQgbmFtZXMgbm8gd3JpdGUgaW50ZW50IGF0IGFsbC5cbmltcG9ydCB7IHVzZUNhbGxiYWNrLCB1c2VFZmZlY3QsIHVzZU1lbW8sIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGludm9rZSwgb25SZWdpb25NZXNzYWdlLCB1c2VIb3N0VGhlbWUsIHVzZVJlZ2lvbiwgdXNlVmNzU3RhdGUgfSBmcm9tIFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGtcIjtcbmltcG9ydCB7XG4gIERJRkZfUEFHRV9MSU5FUyxcbiAgdHlwZSBWY3NEaWZmUmVwbHksXG4gIGNoYW5nZWRQYXRocyxcbiAgY2xhc3NpZnlEaWZmTGluZSxcbiAgZGVmYXVsdFNlbGVjdGlvbixcbiAgZGlmZkxpbmVzLFxuICBwYXJzZURpZmZSZXBseSxcbiAgcGFyc2VTZWxlY3RNZXNzYWdlLFxufSBmcm9tIFwiLi4vbGliL2RpZmZTZWxlY3Rpb25cIjtcbmltcG9ydCBcIi4vRGlmZlBhbmUuY3NzXCI7XG5cbi8qKiBBIGxvYWQgaXMgb25seSByZW5kZXJlZCB3aGlsZSBpdHMga2V5IG1hdGNoZXMgdGhlIGxpdmUgc2VsZWN0aW9uK2NoYW5nZXNldCDigJRcbiAqICBhIHN0YWxlIGxvYWQgKHNlbGVjdGlvbiBtb3ZlZCwgdHJlZSBjaGFuZ2VkKSByZWFkcyBhcyBcImxvYWRpbmdcIiwgbmV2ZXIgYXMgYVxuICogIHdyb25nIGRpZmYuIFdpbmRvd3MgYXJlIHRoZSBhcHBlbmRlZCBgdmNzOmRpZmZgIHBhZ2VzLiAqL1xuaW50ZXJmYWNlIExvYWRlZCB7XG4gIGtleTogc3RyaW5nO1xuICB3aW5kb3dzOiBWY3NEaWZmUmVwbHlbXTtcbiAgZXJyb3I6IHN0cmluZyB8IG51bGw7XG59XG5cbi8qKiBUaGUgcmVuZGVyIG5vdGUgZm9yIHRoZSBjdXJyZW50bHkgc2hvd24gZmlsZSwgb3IgXCJva1wiLiAqL1xuY29uc3Qgbm90ZUZvciA9IChyZXBseTogVmNzRGlmZlJlcGx5LCBwYXRoOiBzdHJpbmcpOiBzdHJpbmcgPT4ge1xuICBjb25zdCBub3RlID0gcmVwbHkuZmlsZXMuZmluZCgoZikgPT4gZi5wYXRoID09PSBwYXRoKTtcbiAgcmV0dXJuIG5vdGU/LnJlbmRlcmVkID8/IFwib2tcIjtcbn07XG5cbmNvbnN0IE5PVEVfVEVYVDogUmVjb3JkPHN0cmluZywgc3RyaW5nPiA9IHtcbiAgYmluYXJ5OiBcIkJpbmFyeSBmaWxlIOKAlCBkaWZmIG5vdCBzaG93bi5cIixcbiAgXCJ0b28tbGFyZ2VcIjogXCJGaWxlIHRvbyBsYXJnZSB0byBkaWZmIGlubGluZS5cIixcbiAgdW5yZWFkYWJsZTogXCJUaGUgcHJpb3IgdmVyc2lvbiBvZiB0aGlzIGZpbGUgY291bGQgbm90IGJlIHJlYWQuXCIsXG59O1xuXG5leHBvcnQgY29uc3QgRGlmZlBhbmU6IFJlYWN0LkZDID0gKCkgPT4ge1xuICBjb25zdCByZWdpb24gPSB1c2VSZWdpb24oKTtcbiAgY29uc3QgdGhlbWUgPSB1c2VIb3N0VGhlbWUoKTtcbiAgY29uc3Qgc3RhdGUgPSB1c2VWY3NTdGF0ZSgpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LmRhdGFzZXQudGhlbWUgPSB0aGVtZTtcbiAgfSwgW3RoZW1lXSk7XG5cbiAgLy8gVGhlIHNlbGVjdGVkIHBhdGg6IHNldCBieSBhIHBhbmVsIHJvdyB0YXAsIGRlZmF1bHRlZCB0byB0aGUgZmlyc3QgY2hhbmdlIHNvXG4gIC8vIHRoZSBwYW5lIG5ldmVyIGlkbGVzIGVtcHR5IG5leHQgdG8gYSBkaXJ0eSB0cmVlLCBhbmQgZHJvcHBlZCB0aGUgbW9tZW50IHRoZVxuICAvLyBwYXRoIGxlYXZlcyB0aGUgY2hhbmdlc2V0ICh0aGUgY2hhbmdlIHdhcyBzYXZlZC9yZXZlcnRlZCDigJQgc2hvd2luZyBhIHN0YWxlXG4gIC8vIGRpZmYgd291bGQgYmUgYSBsaWUpLlxuICBjb25zdCBbc2VsZWN0ZWQsIHNldFNlbGVjdGVkXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICBjb25zdCB2YWxpZCA9IHVzZU1lbW8oKCkgPT4gY2hhbmdlZFBhdGhzKHN0YXRlKSwgW3N0YXRlXSk7XG4gIGNvbnN0IGVmZmVjdGl2ZSA9IHNlbGVjdGVkICE9PSBudWxsICYmIHZhbGlkLmhhcyhzZWxlY3RlZCkgPyBzZWxlY3RlZCA6IGRlZmF1bHRTZWxlY3Rpb24oc3RhdGUpO1xuXG4gIC8vIFRoZSBsaXN0ZW5lciB2YWxpZGF0ZXMgdGhlIGFycml2aW5nIHBhdGggYWdhaW5zdCB0aGUgTElWRSBjaGFuZ2VzZXQsIGJ1dCB0aGVcbiAgLy8gc3Vic2NyaXB0aW9uIG11c3Qgbm90IGNodXJuIG9uIGV2ZXJ5IHN0YXRlIHB1c2gg4oCUIHNvIGl0IHJlYWRzIHRocm91Z2ggYSByZWZcbiAgLy8ga2VwdCBjdXJyZW50IGJ5IGFuIGVmZmVjdCAobmV2ZXIgd3JpdHRlbiBkdXJpbmcgcmVuZGVyKS5cbiAgY29uc3Qgc3RhdGVSZWYgPSB1c2VSZWYoc3RhdGUpO1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHN0YXRlUmVmLmN1cnJlbnQgPSBzdGF0ZTtcbiAgfSwgW3N0YXRlXSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICByZXR1cm4gb25SZWdpb25NZXNzYWdlKCh7IGZyb20sIGRhdGEgfSkgPT4ge1xuICAgICAgY29uc3QgcGF0aCA9IHBhcnNlU2VsZWN0TWVzc2FnZShmcm9tLCBkYXRhKTtcbiAgICAgIGlmIChwYXRoID09PSBudWxsKSByZXR1cm47XG4gICAgICBpZiAoY2hhbmdlZFBhdGhzKHN0YXRlUmVmLmN1cnJlbnQpLmhhcyhwYXRoKSkgc2V0U2VsZWN0ZWQocGF0aCk7XG4gICAgfSk7XG4gIH0sIFtdKTtcblxuICAvLyBGZXRjaCB0aGUgZGlmZiBmb3IgdGhlIGVmZmVjdGl2ZSBzZWxlY3Rpb247IHJlLWZldGNoIHdoZW4gdGhlIHNlbGVjdGlvblxuICAvLyBjaGFuZ2VzIE9SIHRoZSBjaGFuZ2VzZXQncyBzaGFwZSBjaGFuZ2VzIChhIHNhdmUvcmVmbG93IHByb2R1Y2VzIG5ldyBodW5rc1xuICAvLyBmb3IgdGhlIHNhbWUgcGF0aCkuIEFsbCBzdGF0ZSB3cml0ZXMgaGFwcGVuIGluIGFzeW5jIGNhbGxiYWNrcywga2V5ZWQgYnlcbiAgLy8gd2hhdCB0aGV5IHdlcmUgZmV0Y2hlZCBGT1IsIHNvIGEgc3VwZXJzZWRlZCByZXBseSBjYW4gbmV2ZXIgcmVuZGVyLlxuICBjb25zdCBjaGFuZ2VzS2V5ID0gdXNlTWVtbygoKSA9PiBzdGF0ZS5jaGFuZ2VzLm1hcCgoYykgPT4gYCR7Yy5zdGF0dXN9OiR7Yy5wYXRofWApLmpvaW4oXCJ8XCIpLCBbc3RhdGUuY2hhbmdlc10pO1xuICBjb25zdCBrZXkgPSBgJHtlZmZlY3RpdmUgPz8gXCJcIn0jJHtjaGFuZ2VzS2V5fWA7XG4gIGNvbnN0IFtsb2FkZWQsIHNldExvYWRlZF0gPSB1c2VTdGF0ZTxMb2FkZWQgfCBudWxsPihudWxsKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChlZmZlY3RpdmUgPT09IG51bGwpIHJldHVybjtcbiAgICBsZXQgY2FuY2VsbGVkID0gZmFsc2U7XG4gICAgaW52b2tlPHVua25vd24+KFwidmNzOmRpZmZcIiwgeyBwYXRoOiBlZmZlY3RpdmUsIG9mZnNldDogMSwgbGltaXQ6IERJRkZfUEFHRV9MSU5FUyB9KVxuICAgICAgLnRoZW4oKHYpID0+IHtcbiAgICAgICAgaWYgKGNhbmNlbGxlZCkgcmV0dXJuO1xuICAgICAgICBjb25zdCByZXBseSA9IHBhcnNlRGlmZlJlcGx5KHYpO1xuICAgICAgICBpZiAoIXJlcGx5KSB7XG4gICAgICAgICAgc2V0TG9hZGVkKHsga2V5LCB3aW5kb3dzOiBbXSwgZXJyb3I6IFwiVGhlIGhvc3QgcmV0dXJuZWQgYSBtYWxmb3JtZWQgZGlmZi5cIiB9KTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgc2V0TG9hZGVkKHsga2V5LCB3aW5kb3dzOiBbcmVwbHldLCBlcnJvcjogbnVsbCB9KTtcbiAgICAgIH0pXG4gICAgICAuY2F0Y2goKGU6IHVua25vd24pID0+IHtcbiAgICAgICAgaWYgKGNhbmNlbGxlZCkgcmV0dXJuO1xuICAgICAgICBzZXRMb2FkZWQoeyBrZXksIHdpbmRvd3M6IFtdLCBlcnJvcjogZSBpbnN0YW5jZW9mIEVycm9yID8gZS5tZXNzYWdlIDogXCJUaGUgZGlmZiBjb3VsZCBub3QgYmUgbG9hZGVkLlwiIH0pO1xuICAgICAgfSk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGNhbmNlbGxlZCA9IHRydWU7XG4gICAgfTtcbiAgfSwgW2VmZmVjdGl2ZSwgY2hhbmdlc0tleSwga2V5XSk7XG5cbiAgY29uc3QgY3VycmVudCA9IGxvYWRlZCAhPT0gbnVsbCAmJiBsb2FkZWQua2V5ID09PSBrZXkgPyBsb2FkZWQgOiBudWxsO1xuICBjb25zdCBmaXJzdCA9IGN1cnJlbnQ/LndpbmRvd3NbMF07XG4gIGNvbnN0IGxhc3QgPSBjdXJyZW50Py53aW5kb3dzW2N1cnJlbnQud2luZG93cy5sZW5ndGggLSAxXTtcblxuICBjb25zdCBsb2FkTW9yZSA9IHVzZUNhbGxiYWNrKCgpID0+IHtcbiAgICBpZiAoIWN1cnJlbnQgfHwgY3VycmVudC5lcnJvciAhPT0gbnVsbCB8fCBlZmZlY3RpdmUgPT09IG51bGwpIHJldHVybjtcbiAgICBjb25zdCBsYXN0ID0gY3VycmVudC53aW5kb3dzW2N1cnJlbnQud2luZG93cy5sZW5ndGggLSAxXTtcbiAgICBpZiAoIWxhc3QgfHwgbGFzdC5uZXh0T2Zmc2V0ID09PSBudWxsKSByZXR1cm47XG4gICAgY29uc3Qgb2Zmc2V0ID0gbGFzdC5uZXh0T2Zmc2V0O1xuICAgIGludm9rZTx1bmtub3duPihcInZjczpkaWZmXCIsIHsgcGF0aDogZWZmZWN0aXZlLCBvZmZzZXQsIGxpbWl0OiBESUZGX1BBR0VfTElORVMgfSlcbiAgICAgIC50aGVuKCh2KSA9PiB7XG4gICAgICAgIGNvbnN0IHJlcGx5ID0gcGFyc2VEaWZmUmVwbHkodik7XG4gICAgICAgIGlmICghcmVwbHkpIHJldHVybjtcbiAgICAgICAgc2V0TG9hZGVkKChjdXIpID0+IChjdXIgJiYgY3VyLmtleSA9PT0ga2V5ID8geyAuLi5jdXIsIHdpbmRvd3M6IFsuLi5jdXIud2luZG93cywgcmVwbHldIH0gOiBjdXIpKTtcbiAgICAgIH0pXG4gICAgICAuY2F0Y2goKCkgPT4ge1xuICAgICAgICAvKiBrZWVwIHdoYXQgd2UgaGF2ZTsgdGhlIHBhZ2luZyBhZmZvcmRhbmNlIHN0YXlzIG9uIHRoZSBsYXN0IHdpbmRvdyAqL1xuICAgICAgfSk7XG4gIH0sIFtjdXJyZW50LCBrZXksIGVmZmVjdGl2ZV0pO1xuXG4gIGNvbnN0IHNob3duTGluZXMgPSB1c2VNZW1vKFxuICAgICgpID0+IChmaXJzdCA/IGN1cnJlbnQhLndpbmRvd3MuZmxhdE1hcCgodykgPT4gZGlmZkxpbmVzKHcudGV4dCkpIDogW10pLFxuICAgIFtjdXJyZW50LCBmaXJzdF0sXG4gICk7XG4gIGNvbnN0IG5vdGUgPSBmaXJzdCAmJiBlZmZlY3RpdmUgIT09IG51bGwgPyBub3RlRm9yKGZpcnN0LCBlZmZlY3RpdmUpIDogXCJva1wiO1xuICBjb25zdCBzdGF0dXNPZiA9IChwOiBzdHJpbmcpID0+IHN0YXRlLmNoYW5nZXMuZmluZCgoYykgPT4gYy5wYXRoID09PSBwKT8uc3RhdHVzO1xuXG4gIGlmIChyZWdpb24gIT09IFwibWFpbnBhbmUuY29udHJpYnV0ZS1kaWZmXCIpIHtcbiAgICAvLyBHdWFyZDogbmV2ZXIgcmVuZGVyIHRoZSBwYW5lIGhhbGYgb3V0c2lkZSBpdHMgb3duIHJlZ2lvbi5cbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJkcFwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJkcC1oZFwiPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJkcC10aXRsZVwiPlxuICAgICAgICAgIHtlZmZlY3RpdmUgIT09IG51bGwgPyAoXG4gICAgICAgICAgICA8PlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJkcC1iYWRnZVwiIGRhdGEta2luZD17c3RhdHVzT2YoZWZmZWN0aXZlKX0+XG4gICAgICAgICAgICAgICAge3N0YXR1c09mKGVmZmVjdGl2ZSkgPT09IFwiY3JlYXRlZFwiID8gXCJBXCIgOiBzdGF0dXNPZihlZmZlY3RpdmUpID09PSBcImRlbGV0ZWRcIiA/IFwiRFwiIDogXCJNXCJ9XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZHAtcGF0aFwiIHRpdGxlPXtlZmZlY3RpdmV9PlxuICAgICAgICAgICAgICAgIHtlZmZlY3RpdmV9XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDwvPlxuICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICBcIkNoYW5nZXNcIlxuICAgICAgICAgICl9XG4gICAgICAgIDwvc3Bhbj5cbiAgICAgICAge2ZpcnN0ICYmIGVmZmVjdGl2ZSAhPT0gbnVsbCAmJiBub3RlID09PSBcIm9rXCIgJiYgY3VycmVudD8uZXJyb3IgPT09IG51bGwgJiYgKFxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImRwLW11dGVkXCI+XG4gICAgICAgICAgICB7Zmlyc3QudG90YWxMaW5lc30gbGluZXtmaXJzdC50b3RhbExpbmVzID09PSAxID8gXCJcIiA6IFwic1wifVxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImRwLWJvZHlcIj5cbiAgICAgICAge2VmZmVjdGl2ZSA9PT0gbnVsbCAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkcC1lbXB0eVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkcC1lbXB0eS1tc2dcIj5Ob3RoaW5nIHRvIHNob3cuPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRwLWVtcHR5LXN1YlwiPlxuICAgICAgICAgICAgICBFZGl0IGZpbGVzIGluIHRoZSBlZGl0b3Ig4oCUIHNlbGVjdCBhIGNoYW5nZSBpbiB0aGUgU291cmNlIHBhbmVsIHRvIHNlZSBpdHMgZGlmZiBoZXJlLlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAge2VmZmVjdGl2ZSAhPT0gbnVsbCAmJiAhY3VycmVudCAmJiA8ZGl2IGNsYXNzTmFtZT1cImRwLXN0YXR1c1wiPkxvYWRpbmcgZGlmZuKApjwvZGl2Pn1cbiAgICAgICAge2VmZmVjdGl2ZSAhPT0gbnVsbCAmJiBjdXJyZW50ICYmIGN1cnJlbnQuZXJyb3IgIT09IG51bGwgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZHAtc3RhdHVzIGRwLWVycm9yXCI+e2N1cnJlbnQuZXJyb3J9PC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAge2VmZmVjdGl2ZSAhPT0gbnVsbCAmJiBjdXJyZW50ICYmIGN1cnJlbnQuZXJyb3IgPT09IG51bGwgJiYgbm90ZSAhPT0gXCJva1wiICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRwLXN0YXR1c1wiPntOT1RFX1RFWFRbbm90ZV0gPz8gXCJEaWZmIHVuYXZhaWxhYmxlLlwifTwvZGl2PlxuICAgICAgICApfVxuXG4gICAgICAgIHtlZmZlY3RpdmUgIT09IG51bGwgJiYgY3VycmVudCAmJiBjdXJyZW50LmVycm9yID09PSBudWxsICYmIG5vdGUgPT09IFwib2tcIiAmJiBzaG93bkxpbmVzLmxlbmd0aCA9PT0gMCAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkcC1zdGF0dXNcIj5ObyB0ZXh0dWFsIGNoYW5nZXMuPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAge2VmZmVjdGl2ZSAhPT0gbnVsbCAmJiBjdXJyZW50ICYmIGN1cnJlbnQuZXJyb3IgPT09IG51bGwgJiYgbm90ZSA9PT0gXCJva1wiICYmIHNob3duTGluZXMubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgPD5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZHAtZGlmZlwiIHJvbGU9XCJ0YWJsZVwiIGFyaWEtbGFiZWw9e2BEaWZmIG9mICR7ZWZmZWN0aXZlfWB9PlxuICAgICAgICAgICAgICB7c2hvd25MaW5lcy5tYXAoKGxpbmUsIGkpID0+IChcbiAgICAgICAgICAgICAgICA8ZGl2IGtleT17aX0gY2xhc3NOYW1lPVwiZHAtcm93XCIgZGF0YS1raW5kPXtjbGFzc2lmeURpZmZMaW5lKGxpbmUpfT5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImRwLXRleHRcIj57bGluZSB8fCBcIiBcIn08L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICB7bGFzdCAmJiBsYXN0Lm5leHRPZmZzZXQgIT09IG51bGwgJiYgKFxuICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJkcC1tb3JlXCIgb25DbGljaz17bG9hZE1vcmV9PlxuICAgICAgICAgICAgICAgIFNob3cgbW9yZSAoe2xhc3QuZW5kTGluZX0gb2Yge2xhc3QudG90YWxMaW5lc30gbGluZXMpXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8Lz5cbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgRGlmZlBhbmU7XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFXQSxJQUFBQSxNQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxJQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxjQUFBLEdBQUFGLE9BQUE7QUFVQUEsT0FBQTtBQUF3QixJQUFBRyxXQUFBLEdBQUFILE9BQUE7QUFBQSxJQUFBSSxFQUFBLEdBQUFDLFlBQUEsSUF2QnhCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFlQTtBQUNBO0FBQ0E7QUFPQTtBQUNBLE1BQU1DLE9BQU8sR0FBR0EsQ0FBQ0MsS0FBbUIsRUFBRUMsSUFBWSxLQUFhO0VBQzdELE1BQU1DLElBQUksR0FBR0YsS0FBSyxDQUFDRyxLQUFLLENBQUNDLElBQUksQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUNKLElBQUksS0FBS0EsSUFBSSxDQUFDO0VBQ3JELE9BQU9DLElBQUksRUFBRUksUUFBUSxJQUFJLElBQUk7QUFDL0IsQ0FBQztBQUVELE1BQU1DLFNBQWlDLEdBQUc7RUFDeENDLE1BQU0sRUFBRSwrQkFBK0I7RUFDdkMsV0FBVyxFQUFFLGdDQUFnQztFQUM3Q0MsVUFBVSxFQUFFO0FBQ2QsQ0FBQztBQUVNLE1BQU1DLFFBQWtCLEdBQUdBLENBQUEsS0FBTTtFQUFBYixFQUFBO0VBQ3RDLE1BQU1jLE1BQU0sR0FBRyxJQUFBQyxjQUFTLEVBQUMsQ0FBQztFQUMxQixNQUFNQyxLQUFLLEdBQUcsSUFBQUMsaUJBQVksRUFBQyxDQUFDO0VBQzVCLE1BQU1DLEtBQUssR0FBRyxJQUFBQyxnQkFBVyxFQUFDLENBQUM7RUFFM0IsSUFBQUMsZ0JBQVMsRUFBQyxNQUFNO0lBQ2RDLFFBQVEsQ0FBQ0MsZUFBZSxDQUFDQyxPQUFPLENBQUNQLEtBQUssR0FBR0EsS0FBSztFQUNoRCxDQUFDLEVBQUUsQ0FBQ0EsS0FBSyxDQUFDLENBQUM7O0VBRVg7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNLENBQUNRLFFBQVEsRUFBRUMsV0FBVyxDQUFDLEdBQUcsSUFBQUMsZUFBUSxFQUFnQixJQUFJLENBQUM7RUFDN0QsTUFBTUMsS0FBSyxHQUFHLElBQUFDLGNBQU8sRUFBQyxNQUFNLElBQUFDLDJCQUFZLEVBQUNYLEtBQUssQ0FBQyxFQUFFLENBQUNBLEtBQUssQ0FBQyxDQUFDO0VBQ3pELE1BQU1ZLFNBQVMsR0FBR04sUUFBUSxLQUFLLElBQUksSUFBSUcsS0FBSyxDQUFDSSxHQUFHLENBQUNQLFFBQVEsQ0FBQyxHQUFHQSxRQUFRLEdBQUcsSUFBQVEsK0JBQWdCLEVBQUNkLEtBQUssQ0FBQzs7RUFFL0Y7RUFDQTtFQUNBO0VBQ0EsTUFBTWUsUUFBUSxHQUFHLElBQUFDLGFBQU0sRUFBQ2hCLEtBQUssQ0FBQztFQUM5QixJQUFBRSxnQkFBUyxFQUFDLE1BQU07SUFDZGEsUUFBUSxDQUFDRSxPQUFPLEdBQUdqQixLQUFLO0VBQzFCLENBQUMsRUFBRSxDQUFDQSxLQUFLLENBQUMsQ0FBQztFQUVYLElBQUFFLGdCQUFTLEVBQUMsTUFBTTtJQUNkLE9BQU8sSUFBQWdCLG9CQUFlLEVBQUMsQ0FBQztNQUFFQyxJQUFJO01BQUVDO0lBQUssQ0FBQyxLQUFLO01BQ3pDLE1BQU1sQyxJQUFJLEdBQUcsSUFBQW1DLGlDQUFrQixFQUFDRixJQUFJLEVBQUVDLElBQUksQ0FBQztNQUMzQyxJQUFJbEMsSUFBSSxLQUFLLElBQUksRUFBRTtNQUNuQixJQUFJLElBQUF5QiwyQkFBWSxFQUFDSSxRQUFRLENBQUNFLE9BQU8sQ0FBQyxDQUFDSixHQUFHLENBQUMzQixJQUFJLENBQUMsRUFBRXFCLFdBQVcsQ0FBQ3JCLElBQUksQ0FBQztJQUNqRSxDQUFDLENBQUM7RUFDSixDQUFDLEVBQUUsRUFBRSxDQUFDOztFQUVOO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsTUFBTW9DLFVBQVUsR0FBRyxJQUFBWixjQUFPLEVBQUMsTUFBTVYsS0FBSyxDQUFDdUIsT0FBTyxDQUFDQyxHQUFHLENBQUVDLENBQUMsSUFBSyxHQUFHQSxDQUFDLENBQUNDLE1BQU0sSUFBSUQsQ0FBQyxDQUFDdkMsSUFBSSxFQUFFLENBQUMsQ0FBQ3lDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDM0IsS0FBSyxDQUFDdUIsT0FBTyxDQUFDLENBQUM7RUFDOUcsTUFBTUssR0FBRyxHQUFHLEdBQUdoQixTQUFTLElBQUksRUFBRSxJQUFJVSxVQUFVLEVBQUU7RUFDOUMsTUFBTSxDQUFDTyxNQUFNLEVBQUVDLFNBQVMsQ0FBQyxHQUFHLElBQUF0QixlQUFRLEVBQWdCLElBQUksQ0FBQztFQUV6RCxJQUFBTixnQkFBUyxFQUFDLE1BQU07SUFDZCxJQUFJVSxTQUFTLEtBQUssSUFBSSxFQUFFO0lBQ3hCLElBQUltQixTQUFTLEdBQUcsS0FBSztJQUNyQixJQUFBQyxXQUFNLEVBQVUsVUFBVSxFQUFFO01BQUU5QyxJQUFJLEVBQUUwQixTQUFTO01BQUVxQixNQUFNLEVBQUUsQ0FBQztNQUFFQyxLQUFLLEVBQUVDO0lBQWdCLENBQUMsQ0FBQyxDQUNoRkMsSUFBSSxDQUFFQyxDQUFDLElBQUs7TUFDWCxJQUFJTixTQUFTLEVBQUU7TUFDZixNQUFNOUMsS0FBSyxHQUFHLElBQUFxRCw2QkFBYyxFQUFDRCxDQUFDLENBQUM7TUFDL0IsSUFBSSxDQUFDcEQsS0FBSyxFQUFFO1FBQ1Y2QyxTQUFTLENBQUM7VUFBRUYsR0FBRztVQUFFVyxPQUFPLEVBQUUsRUFBRTtVQUFFQyxLQUFLLEVBQUU7UUFBc0MsQ0FBQyxDQUFDO1FBQzdFO01BQ0Y7TUFDQVYsU0FBUyxDQUFDO1FBQUVGLEdBQUc7UUFBRVcsT0FBTyxFQUFFLENBQUN0RCxLQUFLLENBQUM7UUFBRXVELEtBQUssRUFBRTtNQUFLLENBQUMsQ0FBQztJQUNuRCxDQUFDLENBQUMsQ0FDREMsS0FBSyxDQUFFQyxDQUFVLElBQUs7TUFDckIsSUFBSVgsU0FBUyxFQUFFO01BQ2ZELFNBQVMsQ0FBQztRQUFFRixHQUFHO1FBQUVXLE9BQU8sRUFBRSxFQUFFO1FBQUVDLEtBQUssRUFBRUUsQ0FBQyxZQUFZQyxLQUFLLEdBQUdELENBQUMsQ0FBQ0UsT0FBTyxHQUFHO01BQWdDLENBQUMsQ0FBQztJQUMxRyxDQUFDLENBQUM7SUFDSixPQUFPLE1BQU07TUFDWGIsU0FBUyxHQUFHLElBQUk7SUFDbEIsQ0FBQztFQUNILENBQUMsRUFBRSxDQUFDbkIsU0FBUyxFQUFFVSxVQUFVLEVBQUVNLEdBQUcsQ0FBQyxDQUFDO0VBRWhDLE1BQU1YLE9BQU8sR0FBR1ksTUFBTSxLQUFLLElBQUksSUFBSUEsTUFBTSxDQUFDRCxHQUFHLEtBQUtBLEdBQUcsR0FBR0MsTUFBTSxHQUFHLElBQUk7RUFDckUsTUFBTWdCLEtBQUssR0FBRzVCLE9BQU8sRUFBRXNCLE9BQU8sQ0FBQyxDQUFDLENBQUM7RUFDakMsTUFBTU8sSUFBSSxHQUFHN0IsT0FBTyxFQUFFc0IsT0FBTyxDQUFDdEIsT0FBTyxDQUFDc0IsT0FBTyxDQUFDUSxNQUFNLEdBQUcsQ0FBQyxDQUFDO0VBRXpELE1BQU1DLFFBQVEsR0FBRyxJQUFBQyxrQkFBVyxFQUFDLE1BQU07SUFDakMsSUFBSSxDQUFDaEMsT0FBTyxJQUFJQSxPQUFPLENBQUN1QixLQUFLLEtBQUssSUFBSSxJQUFJNUIsU0FBUyxLQUFLLElBQUksRUFBRTtJQUM5RCxNQUFNa0MsSUFBSSxHQUFHN0IsT0FBTyxDQUFDc0IsT0FBTyxDQUFDdEIsT0FBTyxDQUFDc0IsT0FBTyxDQUFDUSxNQUFNLEdBQUcsQ0FBQyxDQUFDO0lBQ3hELElBQUksQ0FBQ0QsSUFBSSxJQUFJQSxJQUFJLENBQUNJLFVBQVUsS0FBSyxJQUFJLEVBQUU7SUFDdkMsTUFBTWpCLE1BQU0sR0FBR2EsSUFBSSxDQUFDSSxVQUFVO0lBQzlCLElBQUFsQixXQUFNLEVBQVUsVUFBVSxFQUFFO01BQUU5QyxJQUFJLEVBQUUwQixTQUFTO01BQUVxQixNQUFNO01BQUVDLEtBQUssRUFBRUM7SUFBZ0IsQ0FBQyxDQUFDLENBQzdFQyxJQUFJLENBQUVDLENBQUMsSUFBSztNQUNYLE1BQU1wRCxLQUFLLEdBQUcsSUFBQXFELDZCQUFjLEVBQUNELENBQUMsQ0FBQztNQUMvQixJQUFJLENBQUNwRCxLQUFLLEVBQUU7TUFDWjZDLFNBQVMsQ0FBRXFCLEdBQUcsSUFBTUEsR0FBRyxJQUFJQSxHQUFHLENBQUN2QixHQUFHLEtBQUtBLEdBQUcsR0FBRztRQUFFLEdBQUd1QixHQUFHO1FBQUVaLE9BQU8sRUFBRSxDQUFDLEdBQUdZLEdBQUcsQ0FBQ1osT0FBTyxFQUFFdEQsS0FBSztNQUFFLENBQUMsR0FBR2tFLEdBQUksQ0FBQztJQUNuRyxDQUFDLENBQUMsQ0FDRFYsS0FBSyxDQUFDLE1BQU07TUFDWDtJQUFBLENBQ0QsQ0FBQztFQUNOLENBQUMsRUFBRSxDQUFDeEIsT0FBTyxFQUFFVyxHQUFHLEVBQUVoQixTQUFTLENBQUMsQ0FBQztFQUU3QixNQUFNd0MsVUFBVSxHQUFHLElBQUExQyxjQUFPLEVBQ3hCLE1BQU9tQyxLQUFLLEdBQUc1QixPQUFPLENBQUVzQixPQUFPLENBQUNjLE9BQU8sQ0FBRUMsQ0FBQyxJQUFLLElBQUFDLHdCQUFTLEVBQUNELENBQUMsQ0FBQ0UsSUFBSSxDQUFDLENBQUMsR0FBRyxFQUFHLEVBQ3ZFLENBQUN2QyxPQUFPLEVBQUU0QixLQUFLLENBQ2pCLENBQUM7RUFDRCxNQUFNMUQsSUFBSSxHQUFHMEQsS0FBSyxJQUFJakMsU0FBUyxLQUFLLElBQUksR0FBRzVCLE9BQU8sQ0FBQzZELEtBQUssRUFBRWpDLFNBQVMsQ0FBQyxHQUFHLElBQUk7RUFDM0UsTUFBTTZDLFFBQVEsR0FBSUMsQ0FBUyxJQUFLMUQsS0FBSyxDQUFDdUIsT0FBTyxDQUFDbEMsSUFBSSxDQUFFb0MsQ0FBQyxJQUFLQSxDQUFDLENBQUN2QyxJQUFJLEtBQUt3RSxDQUFDLENBQUMsRUFBRWhDLE1BQU07RUFFL0UsSUFBSTlCLE1BQU0sS0FBSywwQkFBMEIsRUFBRTtJQUN6QztJQUNBLE9BQU8sSUFBSTtFQUNiO0VBRUEsb0JBQ0UsSUFBQWYsV0FBQSxDQUFBOEUsSUFBQTtJQUFLQyxTQUFTLEVBQUMsSUFBSTtJQUFBQyxRQUFBLGdCQUNqQixJQUFBaEYsV0FBQSxDQUFBOEUsSUFBQTtNQUFLQyxTQUFTLEVBQUMsT0FBTztNQUFBQyxRQUFBLGdCQUNwQixJQUFBaEYsV0FBQSxDQUFBaUYsR0FBQTtRQUFNRixTQUFTLEVBQUMsVUFBVTtRQUFBQyxRQUFBLEVBQ3ZCakQsU0FBUyxLQUFLLElBQUksZ0JBQ2pCLElBQUEvQixXQUFBLENBQUE4RSxJQUFBLEVBQUE5RSxXQUFBLENBQUFrRixRQUFBO1VBQUFGLFFBQUEsZ0JBQ0UsSUFBQWhGLFdBQUEsQ0FBQWlGLEdBQUE7WUFBTUYsU0FBUyxFQUFDLFVBQVU7WUFBQyxhQUFXSCxRQUFRLENBQUM3QyxTQUFTLENBQUU7WUFBQWlELFFBQUEsRUFDdkRKLFFBQVEsQ0FBQzdDLFNBQVMsQ0FBQyxLQUFLLFNBQVMsR0FBRyxHQUFHLEdBQUc2QyxRQUFRLENBQUM3QyxTQUFTLENBQUMsS0FBSyxTQUFTLEdBQUcsR0FBRyxHQUFHO1VBQUcsQ0FDcEYsQ0FBQyxlQUNQLElBQUEvQixXQUFBLENBQUFpRixHQUFBO1lBQU1GLFNBQVMsRUFBQyxTQUFTO1lBQUNJLEtBQUssRUFBRXBELFNBQVU7WUFBQWlELFFBQUEsRUFDeENqRDtVQUFTLENBQ04sQ0FBQztRQUFBLENBQ1AsQ0FBQyxHQUVIO01BQ0QsQ0FDRyxDQUFDLEVBQ05pQyxLQUFLLElBQUlqQyxTQUFTLEtBQUssSUFBSSxJQUFJekIsSUFBSSxLQUFLLElBQUksSUFBSThCLE9BQU8sRUFBRXVCLEtBQUssS0FBSyxJQUFJLGlCQUN0RSxJQUFBM0QsV0FBQSxDQUFBOEUsSUFBQTtRQUFNQyxTQUFTLEVBQUMsVUFBVTtRQUFBQyxRQUFBLEdBQ3ZCaEIsS0FBSyxDQUFDb0IsVUFBVSxFQUFDLE9BQUssRUFBQ3BCLEtBQUssQ0FBQ29CLFVBQVUsS0FBSyxDQUFDLEdBQUcsRUFBRSxHQUFHLEdBQUc7TUFBQSxDQUNyRCxDQUNQO0lBQUEsQ0FDRSxDQUFDLGVBRU4sSUFBQXBGLFdBQUEsQ0FBQThFLElBQUE7TUFBS0MsU0FBUyxFQUFDLFNBQVM7TUFBQUMsUUFBQSxHQUNyQmpELFNBQVMsS0FBSyxJQUFJLGlCQUNqQixJQUFBL0IsV0FBQSxDQUFBOEUsSUFBQTtRQUFLQyxTQUFTLEVBQUMsVUFBVTtRQUFBQyxRQUFBLGdCQUN2QixJQUFBaEYsV0FBQSxDQUFBaUYsR0FBQTtVQUFLRixTQUFTLEVBQUMsY0FBYztVQUFBQyxRQUFBLEVBQUM7UUFBZ0IsQ0FBSyxDQUFDLGVBQ3BELElBQUFoRixXQUFBLENBQUFpRixHQUFBO1VBQUtGLFNBQVMsRUFBQyxjQUFjO1VBQUFDLFFBQUEsRUFBQztRQUU5QixDQUFLLENBQUM7TUFBQSxDQUNILENBQ04sRUFFQWpELFNBQVMsS0FBSyxJQUFJLElBQUksQ0FBQ0ssT0FBTyxpQkFBSSxJQUFBcEMsV0FBQSxDQUFBaUYsR0FBQTtRQUFLRixTQUFTLEVBQUMsV0FBVztRQUFBQyxRQUFBLEVBQUM7TUFBYSxDQUFLLENBQUMsRUFDaEZqRCxTQUFTLEtBQUssSUFBSSxJQUFJSyxPQUFPLElBQUlBLE9BQU8sQ0FBQ3VCLEtBQUssS0FBSyxJQUFJLGlCQUN0RCxJQUFBM0QsV0FBQSxDQUFBaUYsR0FBQTtRQUFLRixTQUFTLEVBQUMsb0JBQW9CO1FBQUFDLFFBQUEsRUFBRTVDLE9BQU8sQ0FBQ3VCO01BQUssQ0FBTSxDQUN6RCxFQUVBNUIsU0FBUyxLQUFLLElBQUksSUFBSUssT0FBTyxJQUFJQSxPQUFPLENBQUN1QixLQUFLLEtBQUssSUFBSSxJQUFJckQsSUFBSSxLQUFLLElBQUksaUJBQ3ZFLElBQUFOLFdBQUEsQ0FBQWlGLEdBQUE7UUFBS0YsU0FBUyxFQUFDLFdBQVc7UUFBQUMsUUFBQSxFQUFFckUsU0FBUyxDQUFDTCxJQUFJLENBQUMsSUFBSTtNQUFtQixDQUFNLENBQ3pFLEVBRUF5QixTQUFTLEtBQUssSUFBSSxJQUFJSyxPQUFPLElBQUlBLE9BQU8sQ0FBQ3VCLEtBQUssS0FBSyxJQUFJLElBQUlyRCxJQUFJLEtBQUssSUFBSSxJQUFJaUUsVUFBVSxDQUFDTCxNQUFNLEtBQUssQ0FBQyxpQkFDbEcsSUFBQWxFLFdBQUEsQ0FBQWlGLEdBQUE7UUFBS0YsU0FBUyxFQUFDLFdBQVc7UUFBQUMsUUFBQSxFQUFDO01BQW1CLENBQUssQ0FDcEQsRUFFQWpELFNBQVMsS0FBSyxJQUFJLElBQUlLLE9BQU8sSUFBSUEsT0FBTyxDQUFDdUIsS0FBSyxLQUFLLElBQUksSUFBSXJELElBQUksS0FBSyxJQUFJLElBQUlpRSxVQUFVLENBQUNMLE1BQU0sR0FBRyxDQUFDLGlCQUNoRyxJQUFBbEUsV0FBQSxDQUFBOEUsSUFBQSxFQUFBOUUsV0FBQSxDQUFBa0YsUUFBQTtRQUFBRixRQUFBLGdCQUNFLElBQUFoRixXQUFBLENBQUFpRixHQUFBO1VBQUtGLFNBQVMsRUFBQyxTQUFTO1VBQUNNLElBQUksRUFBQyxPQUFPO1VBQUMsY0FBWSxXQUFXdEQsU0FBUyxFQUFHO1VBQUFpRCxRQUFBLEVBQ3RFVCxVQUFVLENBQUM1QixHQUFHLENBQUMsQ0FBQzJDLElBQUksRUFBRUMsQ0FBQyxrQkFDdEIsSUFBQXZGLFdBQUEsQ0FBQWlGLEdBQUE7WUFBYUYsU0FBUyxFQUFDLFFBQVE7WUFBQyxhQUFXLElBQUFTLCtCQUFnQixFQUFDRixJQUFJLENBQUU7WUFBQU4sUUFBQSxlQUNoRSxJQUFBaEYsV0FBQSxDQUFBaUYsR0FBQTtjQUFNRixTQUFTLEVBQUMsU0FBUztjQUFBQyxRQUFBLEVBQUVNLElBQUksSUFBSTtZQUFHLENBQU87VUFBQyxHQUR0Q0MsQ0FFTCxDQUNOO1FBQUMsQ0FDQyxDQUFDLEVBQ0x0QixJQUFJLElBQUlBLElBQUksQ0FBQ0ksVUFBVSxLQUFLLElBQUksaUJBQy9CLElBQUFyRSxXQUFBLENBQUE4RSxJQUFBO1VBQVFXLElBQUksRUFBQyxRQUFRO1VBQUNWLFNBQVMsRUFBQyxTQUFTO1VBQUNXLE9BQU8sRUFBRXZCLFFBQVM7VUFBQWEsUUFBQSxHQUFDLGFBQ2hELEVBQUNmLElBQUksQ0FBQzBCLE9BQU8sRUFBQyxNQUFJLEVBQUMxQixJQUFJLENBQUNtQixVQUFVLEVBQUMsU0FDaEQ7UUFBQSxDQUFRLENBQ1Q7TUFBQSxDQUNELENBQ0g7SUFBQSxDQUNFLENBQUM7RUFBQSxDQUNILENBQUM7QUFFVixDQUFDO0FBQUNRLE9BQUEsQ0FBQTlFLFFBQUEsR0FBQUEsUUFBQTtBQUFBYixFQUFBLENBaktXYSxRQUFrQjtFQUFBLFFBQ2RFLGNBQVMsRUFDVkUsaUJBQVksRUFDWkUsZ0JBQVc7QUFBQTtBQUFBeUUsRUFBQSxHQUhkL0UsUUFBa0I7QUFBQSxJQUFBZ0YsUUFBQSxHQUFBRixPQUFBLENBQUFHLE9BQUEsR0FtS2hCakYsUUFBUTtBQUFBLElBQUErRSxFQUFBO0FBQUFHLFlBQUEsQ0FBQUgsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}