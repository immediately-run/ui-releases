var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Contribute;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
require("./Contribute.css");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The contribute dialog (UI_AS_APPS_SPEC §5.1). Reads the unsaved files via the
// elevated `editor:read` channel, lets the user write a message and pick PR vs
// direct commit, then drives the host's contribution orchestrator over the
// streamed `contribute()` call. Every privileged step — the GitHub API, the
// OAuth token, the fork/PR — stays on the host; this app only shows progress.
// Friendly one-liners for the orchestrator stages (CONTRIBUTE_SPEC §15.7).
const STAGE_LABEL = {
  "auth-check": "Checking sign-in…",
  "diff-compute": "Computing your changes…",
  "permission-check": "Checking permissions…",
  "conflict-check": "Checking for conflicts…",
  "fork-prepare": "Preparing your fork…",
  "upload-blob": "Uploading files…",
  "create-tree": "Building the commit…",
  "create-commit": "Creating the commit…",
  "create-branch": "Creating the branch…",
  "create-pr": "Opening the pull request…",
  "commit-pushed": "Pushing the commit…",
  starting: "Starting…"
};
function Contribute() {
  _s();
  const {
    dirtyPaths
  } = (0, _sdk.useEditorContext)();
  const [message, setMessage] = (0, _react.useState)("");
  const [mode, setMode] = (0, _react.useState)("pr");
  const [phase, setPhase] = (0, _react.useState)({
    kind: "idle"
  });
  const busy = phase.kind === "running";
  const nothingToSave = dirtyPaths.length === 0;
  const run = (0, _react.useCallback)(async () => {
    setPhase({
      kind: "running",
      stage: "starting"
    });
    try {
      const stream = (0, _sdk.contribute)({
        commitMessage: message.trim() || "Update",
        mode
      });
      let result;
      for await (const ev of stream) {
        if (ev.stage === "install-required") {
          // Forward-only v1 (§5.1): the GitHub App must be installed on the target.
          // Show the link; after installing, the user retries (a fresh stream).
          setPhase({
            kind: "needs-install",
            installUrl: ev.installUrl,
            targetOwner: ev.targetOwner,
            targetRepo: ev.targetRepo
          });
          return;
        }
        if (ev.stage === "error") {
          setPhase({
            kind: "error",
            code: "failed",
            message: ev.message
          });
          return;
        }
        if (ev.stage === "done") {
          result = ev;
        }
        setPhase({
          kind: "running",
          stage: ev.stage
        });
      }
      // The generator's RETURN value is the settled result; prefer it.
      setPhase({
        kind: "done",
        result: result ?? {
          commitSha: "",
          treeSha: "",
          branchName: "",
          mode: "new-branch-pr"
        }
      });
    } catch (e) {
      const code = e?.code ?? "unknown";
      setPhase({
        kind: "error",
        code,
        message: e?.message ?? "Save failed"
      });
    }
  }, [message, mode]);
  const errorHint = (0, _react.useMemo)(() => {
    if (phase.kind !== "error") return null;
    switch (phase.code) {
      case "auth-required":
        return "Sign in to save your changes.";
      case "forbidden":
        return mode === "direct" ? "This app can't commit directly. Switch to a pull request." : "You don't have permission to save here.";
      case "no-target":
        return "There's nothing here that can be saved to GitHub.";
      case "conflict":
        return "Someone changed these files upstream — refresh and try again.";
      case "gone":
        return "The branch was deleted upstream.";
      default:
        return phase.message;
    }
  }, [phase, mode]);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "contribute",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("header", {
      className: "ct-hd",
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "ct-title",
        children: "Save your changes"
      })
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("section", {
      className: "ct-changes",
      children: nothingToSave ? /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
        className: "ct-empty",
        children: "No unsaved changes."
      }) : /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("p", {
          className: "ct-changes-h",
          children: [dirtyPaths.length, " file", dirtyPaths.length === 1 ? "" : "s", " will be saved"]
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("ul", {
          className: "ct-filelist",
          children: dirtyPaths.map(p => /*#__PURE__*/(0, _jsxRuntime.jsx)("li", {
            className: "ct-file",
            title: p,
            children: p
          }, p))
        })]
      })
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("label", {
      className: "ct-field",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "ct-label",
        children: "Message"
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("input", {
        className: "ct-input",
        value: message,
        placeholder: "Describe your change",
        onChange: e => setMessage(e.target.value),
        disabled: busy
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "ct-mode",
      role: "radiogroup",
      "aria-label": "Save mode",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("label", {
        className: "ct-radio",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("input", {
          type: "radio",
          name: "mode",
          checked: mode === "pr",
          onChange: () => setMode("pr"),
          disabled: busy
        }), "Pull request"]
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("label", {
        className: "ct-radio",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("input", {
          type: "radio",
          name: "mode",
          checked: mode === "direct",
          onChange: () => setMode("direct"),
          disabled: busy
        }), "Commit directly"]
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
      type: "button",
      className: "ct-save",
      onClick: run,
      disabled: busy || nothingToSave,
      children: busy ? STAGE_LABEL[phase.stage] ?? "Saving…" : mode === "direct" ? "Commit" : "Open pull request"
    }), phase.kind === "needs-install" && /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "ct-status ct-install",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("p", {
        children: ["Install the immediately.run GitHub App on", " ", /*#__PURE__*/(0, _jsxRuntime.jsxs)("strong", {
          children: [phase.targetOwner, "/", phase.targetRepo]
        }), " ", "to save here."]
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("a", {
        className: "ct-link",
        href: phase.installUrl,
        target: "_blank",
        rel: "noreferrer",
        children: "Install\u2026"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        type: "button",
        className: "ct-retry",
        onClick: run,
        children: "I've installed \u2014 retry"
      })]
    }), phase.kind === "done" && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "ct-status ct-done",
      children: phase.result.prUrl ? /*#__PURE__*/(0, _jsxRuntime.jsxs)("p", {
        children: ["Pull request opened \u2014", " ", /*#__PURE__*/(0, _jsxRuntime.jsxs)("a", {
          className: "ct-link",
          href: phase.result.prUrl,
          target: "_blank",
          rel: "noreferrer",
          children: ["#", phase.result.prNumber]
        })]
      }) : /*#__PURE__*/(0, _jsxRuntime.jsxs)("p", {
        children: ["Committed ", phase.result.commitSha.slice(0, 7), " to ", phase.result.branchName, "."]
      })
    }), phase.kind === "error" && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "ct-status ct-error",
      children: errorHint
    })]
  });
}
_s(Contribute, "FJWIufGuax9vCOnJ0mF17L07LcQ=", false, function () {
  return [_sdk.useEditorContext];
});
_c = Contribute;
var _c;
$RefreshReg$(_c, "Contribute");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NkayIsIl9qc3hSdW50aW1lIiwiX3MiLCIkUmVmcmVzaFNpZyQiLCJTVEFHRV9MQUJFTCIsInN0YXJ0aW5nIiwiQ29udHJpYnV0ZSIsImRpcnR5UGF0aHMiLCJ1c2VFZGl0b3JDb250ZXh0IiwibWVzc2FnZSIsInNldE1lc3NhZ2UiLCJ1c2VTdGF0ZSIsIm1vZGUiLCJzZXRNb2RlIiwicGhhc2UiLCJzZXRQaGFzZSIsImtpbmQiLCJidXN5Iiwibm90aGluZ1RvU2F2ZSIsImxlbmd0aCIsInJ1biIsInVzZUNhbGxiYWNrIiwic3RhZ2UiLCJzdHJlYW0iLCJjb250cmlidXRlIiwiY29tbWl0TWVzc2FnZSIsInRyaW0iLCJyZXN1bHQiLCJldiIsImluc3RhbGxVcmwiLCJ0YXJnZXRPd25lciIsInRhcmdldFJlcG8iLCJjb2RlIiwiY29tbWl0U2hhIiwidHJlZVNoYSIsImJyYW5jaE5hbWUiLCJlIiwiZXJyb3JIaW50IiwidXNlTWVtbyIsImpzeHMiLCJjbGFzc05hbWUiLCJjaGlsZHJlbiIsImpzeCIsIkZyYWdtZW50IiwibWFwIiwicCIsInRpdGxlIiwidmFsdWUiLCJwbGFjZWhvbGRlciIsIm9uQ2hhbmdlIiwidGFyZ2V0IiwiZGlzYWJsZWQiLCJyb2xlIiwidHlwZSIsIm5hbWUiLCJjaGVja2VkIiwib25DbGljayIsImhyZWYiLCJyZWwiLCJwclVybCIsInByTnVtYmVyIiwic2xpY2UiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkNvbnRyaWJ1dGUudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIFRoZSBjb250cmlidXRlIGRpYWxvZyAoVUlfQVNfQVBQU19TUEVDIMKnNS4xKS4gUmVhZHMgdGhlIHVuc2F2ZWQgZmlsZXMgdmlhIHRoZVxuLy8gZWxldmF0ZWQgYGVkaXRvcjpyZWFkYCBjaGFubmVsLCBsZXRzIHRoZSB1c2VyIHdyaXRlIGEgbWVzc2FnZSBhbmQgcGljayBQUiB2c1xuLy8gZGlyZWN0IGNvbW1pdCwgdGhlbiBkcml2ZXMgdGhlIGhvc3QncyBjb250cmlidXRpb24gb3JjaGVzdHJhdG9yIG92ZXIgdGhlXG4vLyBzdHJlYW1lZCBgY29udHJpYnV0ZSgpYCBjYWxsLiBFdmVyeSBwcml2aWxlZ2VkIHN0ZXAg4oCUIHRoZSBHaXRIdWIgQVBJLCB0aGVcbi8vIE9BdXRoIHRva2VuLCB0aGUgZm9yay9QUiDigJQgc3RheXMgb24gdGhlIGhvc3Q7IHRoaXMgYXBwIG9ubHkgc2hvd3MgcHJvZ3Jlc3MuXG5pbXBvcnQgeyB1c2VDYWxsYmFjaywgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7XG4gIGNvbnRyaWJ1dGUsXG4gIHVzZUVkaXRvckNvbnRleHQsXG4gIHR5cGUgQ29udHJpYnV0ZU1vZGUsXG4gIHR5cGUgQ29udHJpYnV0aW9uRXZlbnQsXG4gIHR5cGUgQ29udHJpYnV0aW9uUmVzdWx0LFxufSBmcm9tIFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGtcIjtcbmltcG9ydCBcIi4vQ29udHJpYnV0ZS5jc3NcIjtcblxudHlwZSBQaGFzZSA9XG4gIHwgeyBraW5kOiBcImlkbGVcIiB9XG4gIHwgeyBraW5kOiBcInJ1bm5pbmdcIjsgc3RhZ2U6IHN0cmluZyB9XG4gIHwgeyBraW5kOiBcIm5lZWRzLWluc3RhbGxcIjsgaW5zdGFsbFVybDogc3RyaW5nOyB0YXJnZXRPd25lcjogc3RyaW5nOyB0YXJnZXRSZXBvOiBzdHJpbmcgfVxuICB8IHsga2luZDogXCJkb25lXCI7IHJlc3VsdDogQ29udHJpYnV0aW9uUmVzdWx0IH1cbiAgfCB7IGtpbmQ6IFwiZXJyb3JcIjsgY29kZTogc3RyaW5nOyBtZXNzYWdlOiBzdHJpbmcgfTtcblxuLy8gRnJpZW5kbHkgb25lLWxpbmVycyBmb3IgdGhlIG9yY2hlc3RyYXRvciBzdGFnZXMgKENPTlRSSUJVVEVfU1BFQyDCpzE1LjcpLlxuY29uc3QgU1RBR0VfTEFCRUw6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7XG4gIFwiYXV0aC1jaGVja1wiOiBcIkNoZWNraW5nIHNpZ24taW7igKZcIixcbiAgXCJkaWZmLWNvbXB1dGVcIjogXCJDb21wdXRpbmcgeW91ciBjaGFuZ2Vz4oCmXCIsXG4gIFwicGVybWlzc2lvbi1jaGVja1wiOiBcIkNoZWNraW5nIHBlcm1pc3Npb25z4oCmXCIsXG4gIFwiY29uZmxpY3QtY2hlY2tcIjogXCJDaGVja2luZyBmb3IgY29uZmxpY3Rz4oCmXCIsXG4gIFwiZm9yay1wcmVwYXJlXCI6IFwiUHJlcGFyaW5nIHlvdXIgZm9ya+KAplwiLFxuICBcInVwbG9hZC1ibG9iXCI6IFwiVXBsb2FkaW5nIGZpbGVz4oCmXCIsXG4gIFwiY3JlYXRlLXRyZWVcIjogXCJCdWlsZGluZyB0aGUgY29tbWl04oCmXCIsXG4gIFwiY3JlYXRlLWNvbW1pdFwiOiBcIkNyZWF0aW5nIHRoZSBjb21taXTigKZcIixcbiAgXCJjcmVhdGUtYnJhbmNoXCI6IFwiQ3JlYXRpbmcgdGhlIGJyYW5jaOKAplwiLFxuICBcImNyZWF0ZS1wclwiOiBcIk9wZW5pbmcgdGhlIHB1bGwgcmVxdWVzdOKAplwiLFxuICBcImNvbW1pdC1wdXNoZWRcIjogXCJQdXNoaW5nIHRoZSBjb21taXTigKZcIixcbiAgc3RhcnRpbmc6IFwiU3RhcnRpbmfigKZcIixcbn07XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIENvbnRyaWJ1dGUoKSB7XG4gIGNvbnN0IHsgZGlydHlQYXRocyB9ID0gdXNlRWRpdG9yQ29udGV4dCgpO1xuICBjb25zdCBbbWVzc2FnZSwgc2V0TWVzc2FnZV0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW21vZGUsIHNldE1vZGVdID0gdXNlU3RhdGU8Q29udHJpYnV0ZU1vZGU+KFwicHJcIik7XG4gIGNvbnN0IFtwaGFzZSwgc2V0UGhhc2VdID0gdXNlU3RhdGU8UGhhc2U+KHsga2luZDogXCJpZGxlXCIgfSk7XG5cbiAgY29uc3QgYnVzeSA9IHBoYXNlLmtpbmQgPT09IFwicnVubmluZ1wiO1xuICBjb25zdCBub3RoaW5nVG9TYXZlID0gZGlydHlQYXRocy5sZW5ndGggPT09IDA7XG5cbiAgY29uc3QgcnVuID0gdXNlQ2FsbGJhY2soYXN5bmMgKCkgPT4ge1xuICAgIHNldFBoYXNlKHsga2luZDogXCJydW5uaW5nXCIsIHN0YWdlOiBcInN0YXJ0aW5nXCIgfSk7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHN0cmVhbSA9IGNvbnRyaWJ1dGUoeyBjb21taXRNZXNzYWdlOiBtZXNzYWdlLnRyaW0oKSB8fCBcIlVwZGF0ZVwiLCBtb2RlIH0pO1xuICAgICAgbGV0IHJlc3VsdDogQ29udHJpYnV0aW9uUmVzdWx0IHwgdW5kZWZpbmVkO1xuICAgICAgZm9yIGF3YWl0IChjb25zdCBldiBvZiBzdHJlYW0gYXMgQXN5bmNHZW5lcmF0b3I8Q29udHJpYnV0aW9uRXZlbnQsIENvbnRyaWJ1dGlvblJlc3VsdD4pIHtcbiAgICAgICAgaWYgKGV2LnN0YWdlID09PSBcImluc3RhbGwtcmVxdWlyZWRcIikge1xuICAgICAgICAgIC8vIEZvcndhcmQtb25seSB2MSAowqc1LjEpOiB0aGUgR2l0SHViIEFwcCBtdXN0IGJlIGluc3RhbGxlZCBvbiB0aGUgdGFyZ2V0LlxuICAgICAgICAgIC8vIFNob3cgdGhlIGxpbms7IGFmdGVyIGluc3RhbGxpbmcsIHRoZSB1c2VyIHJldHJpZXMgKGEgZnJlc2ggc3RyZWFtKS5cbiAgICAgICAgICBzZXRQaGFzZSh7XG4gICAgICAgICAgICBraW5kOiBcIm5lZWRzLWluc3RhbGxcIixcbiAgICAgICAgICAgIGluc3RhbGxVcmw6IGV2Lmluc3RhbGxVcmwsXG4gICAgICAgICAgICB0YXJnZXRPd25lcjogZXYudGFyZ2V0T3duZXIsXG4gICAgICAgICAgICB0YXJnZXRSZXBvOiBldi50YXJnZXRSZXBvLFxuICAgICAgICAgIH0pO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoZXYuc3RhZ2UgPT09IFwiZXJyb3JcIikge1xuICAgICAgICAgIHNldFBoYXNlKHsga2luZDogXCJlcnJvclwiLCBjb2RlOiBcImZhaWxlZFwiLCBtZXNzYWdlOiBldi5tZXNzYWdlIH0pO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoZXYuc3RhZ2UgPT09IFwiZG9uZVwiKSB7XG4gICAgICAgICAgcmVzdWx0ID0gZXYgYXMgdW5rbm93biBhcyBDb250cmlidXRpb25SZXN1bHQ7XG4gICAgICAgIH1cbiAgICAgICAgc2V0UGhhc2UoeyBraW5kOiBcInJ1bm5pbmdcIiwgc3RhZ2U6IGV2LnN0YWdlIH0pO1xuICAgICAgfVxuICAgICAgLy8gVGhlIGdlbmVyYXRvcidzIFJFVFVSTiB2YWx1ZSBpcyB0aGUgc2V0dGxlZCByZXN1bHQ7IHByZWZlciBpdC5cbiAgICAgIHNldFBoYXNlKHsga2luZDogXCJkb25lXCIsIHJlc3VsdDogcmVzdWx0ID8/ICh7IGNvbW1pdFNoYTogXCJcIiwgdHJlZVNoYTogXCJcIiwgYnJhbmNoTmFtZTogXCJcIiwgbW9kZTogXCJuZXctYnJhbmNoLXByXCIgfSBhcyBDb250cmlidXRpb25SZXN1bHQpIH0pO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGNvbnN0IGNvZGUgPSAoZSBhcyB7IGNvZGU/OiBzdHJpbmcgfSk/LmNvZGUgPz8gXCJ1bmtub3duXCI7XG4gICAgICBzZXRQaGFzZSh7IGtpbmQ6IFwiZXJyb3JcIiwgY29kZSwgbWVzc2FnZTogKGUgYXMgRXJyb3IpPy5tZXNzYWdlID8/IFwiU2F2ZSBmYWlsZWRcIiB9KTtcbiAgICB9XG4gIH0sIFttZXNzYWdlLCBtb2RlXSk7XG5cbiAgY29uc3QgZXJyb3JIaW50ID0gdXNlTWVtbygoKSA9PiB7XG4gICAgaWYgKHBoYXNlLmtpbmQgIT09IFwiZXJyb3JcIikgcmV0dXJuIG51bGw7XG4gICAgc3dpdGNoIChwaGFzZS5jb2RlKSB7XG4gICAgICBjYXNlIFwiYXV0aC1yZXF1aXJlZFwiOlxuICAgICAgICByZXR1cm4gXCJTaWduIGluIHRvIHNhdmUgeW91ciBjaGFuZ2VzLlwiO1xuICAgICAgY2FzZSBcImZvcmJpZGRlblwiOlxuICAgICAgICByZXR1cm4gbW9kZSA9PT0gXCJkaXJlY3RcIlxuICAgICAgICAgID8gXCJUaGlzIGFwcCBjYW4ndCBjb21taXQgZGlyZWN0bHkuIFN3aXRjaCB0byBhIHB1bGwgcmVxdWVzdC5cIlxuICAgICAgICAgIDogXCJZb3UgZG9uJ3QgaGF2ZSBwZXJtaXNzaW9uIHRvIHNhdmUgaGVyZS5cIjtcbiAgICAgIGNhc2UgXCJuby10YXJnZXRcIjpcbiAgICAgICAgcmV0dXJuIFwiVGhlcmUncyBub3RoaW5nIGhlcmUgdGhhdCBjYW4gYmUgc2F2ZWQgdG8gR2l0SHViLlwiO1xuICAgICAgY2FzZSBcImNvbmZsaWN0XCI6XG4gICAgICAgIHJldHVybiBcIlNvbWVvbmUgY2hhbmdlZCB0aGVzZSBmaWxlcyB1cHN0cmVhbSDigJQgcmVmcmVzaCBhbmQgdHJ5IGFnYWluLlwiO1xuICAgICAgY2FzZSBcImdvbmVcIjpcbiAgICAgICAgcmV0dXJuIFwiVGhlIGJyYW5jaCB3YXMgZGVsZXRlZCB1cHN0cmVhbS5cIjtcbiAgICAgIGRlZmF1bHQ6XG4gICAgICAgIHJldHVybiBwaGFzZS5tZXNzYWdlO1xuICAgIH1cbiAgfSwgW3BoYXNlLCBtb2RlXSk7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRyaWJ1dGVcIj5cbiAgICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwiY3QtaGRcIj5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY3QtdGl0bGVcIj5TYXZlIHlvdXIgY2hhbmdlczwvc3Bhbj5cbiAgICAgIDwvaGVhZGVyPlxuXG4gICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJjdC1jaGFuZ2VzXCI+XG4gICAgICAgIHtub3RoaW5nVG9TYXZlID8gKFxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImN0LWVtcHR5XCI+Tm8gdW5zYXZlZCBjaGFuZ2VzLjwvcD5cbiAgICAgICAgKSA6IChcbiAgICAgICAgICA8PlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiY3QtY2hhbmdlcy1oXCI+XG4gICAgICAgICAgICAgIHtkaXJ0eVBhdGhzLmxlbmd0aH0gZmlsZXtkaXJ0eVBhdGhzLmxlbmd0aCA9PT0gMSA/IFwiXCIgOiBcInNcIn0gd2lsbCBiZSBzYXZlZFxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cImN0LWZpbGVsaXN0XCI+XG4gICAgICAgICAgICAgIHtkaXJ0eVBhdGhzLm1hcCgocCkgPT4gKFxuICAgICAgICAgICAgICAgIDxsaSBrZXk9e3B9IGNsYXNzTmFtZT1cImN0LWZpbGVcIiB0aXRsZT17cH0+XG4gICAgICAgICAgICAgICAgICB7cH1cbiAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgPC8+XG4gICAgICAgICl9XG4gICAgICA8L3NlY3Rpb24+XG5cbiAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJjdC1maWVsZFwiPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjdC1sYWJlbFwiPk1lc3NhZ2U8L3NwYW4+XG4gICAgICAgIDxpbnB1dFxuICAgICAgICAgIGNsYXNzTmFtZT1cImN0LWlucHV0XCJcbiAgICAgICAgICB2YWx1ZT17bWVzc2FnZX1cbiAgICAgICAgICBwbGFjZWhvbGRlcj1cIkRlc2NyaWJlIHlvdXIgY2hhbmdlXCJcbiAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE1lc3NhZ2UoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgIGRpc2FibGVkPXtidXN5fVxuICAgICAgICAvPlxuICAgICAgPC9sYWJlbD5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjdC1tb2RlXCIgcm9sZT1cInJhZGlvZ3JvdXBcIiBhcmlhLWxhYmVsPVwiU2F2ZSBtb2RlXCI+XG4gICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJjdC1yYWRpb1wiPlxuICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgdHlwZT1cInJhZGlvXCJcbiAgICAgICAgICAgIG5hbWU9XCJtb2RlXCJcbiAgICAgICAgICAgIGNoZWNrZWQ9e21vZGUgPT09IFwicHJcIn1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoKSA9PiBzZXRNb2RlKFwicHJcIil9XG4gICAgICAgICAgICBkaXNhYmxlZD17YnVzeX1cbiAgICAgICAgICAvPlxuICAgICAgICAgIFB1bGwgcmVxdWVzdFxuICAgICAgICA8L2xhYmVsPlxuICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiY3QtcmFkaW9cIj5cbiAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIHR5cGU9XCJyYWRpb1wiXG4gICAgICAgICAgICBuYW1lPVwibW9kZVwiXG4gICAgICAgICAgICBjaGVja2VkPXttb2RlID09PSBcImRpcmVjdFwifVxuICAgICAgICAgICAgb25DaGFuZ2U9eygpID0+IHNldE1vZGUoXCJkaXJlY3RcIil9XG4gICAgICAgICAgICBkaXNhYmxlZD17YnVzeX1cbiAgICAgICAgICAvPlxuICAgICAgICAgIENvbW1pdCBkaXJlY3RseVxuICAgICAgICA8L2xhYmVsPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxidXR0b25cbiAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgIGNsYXNzTmFtZT1cImN0LXNhdmVcIlxuICAgICAgICBvbkNsaWNrPXtydW59XG4gICAgICAgIGRpc2FibGVkPXtidXN5IHx8IG5vdGhpbmdUb1NhdmV9XG4gICAgICA+XG4gICAgICAgIHtidXN5ID8gU1RBR0VfTEFCRUxbcGhhc2Uuc3RhZ2VdID8/IFwiU2F2aW5n4oCmXCIgOiBtb2RlID09PSBcImRpcmVjdFwiID8gXCJDb21taXRcIiA6IFwiT3BlbiBwdWxsIHJlcXVlc3RcIn1cbiAgICAgIDwvYnV0dG9uPlxuXG4gICAgICB7cGhhc2Uua2luZCA9PT0gXCJuZWVkcy1pbnN0YWxsXCIgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImN0LXN0YXR1cyBjdC1pbnN0YWxsXCI+XG4gICAgICAgICAgPHA+XG4gICAgICAgICAgICBJbnN0YWxsIHRoZSBpbW1lZGlhdGVseS5ydW4gR2l0SHViIEFwcCBvbntcIiBcIn1cbiAgICAgICAgICAgIDxzdHJvbmc+XG4gICAgICAgICAgICAgIHtwaGFzZS50YXJnZXRPd25lcn0ve3BoYXNlLnRhcmdldFJlcG99XG4gICAgICAgICAgICA8L3N0cm9uZz57XCIgXCJ9XG4gICAgICAgICAgICB0byBzYXZlIGhlcmUuXG4gICAgICAgICAgPC9wPlxuICAgICAgICAgIDxhIGNsYXNzTmFtZT1cImN0LWxpbmtcIiBocmVmPXtwaGFzZS5pbnN0YWxsVXJsfSB0YXJnZXQ9XCJfYmxhbmtcIiByZWw9XCJub3JlZmVycmVyXCI+XG4gICAgICAgICAgICBJbnN0YWxs4oCmXG4gICAgICAgICAgPC9hPntcIiBcIn1cbiAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJjdC1yZXRyeVwiIG9uQ2xpY2s9e3J1bn0+XG4gICAgICAgICAgICBJJ3ZlIGluc3RhbGxlZCDigJQgcmV0cnlcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7cGhhc2Uua2luZCA9PT0gXCJkb25lXCIgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImN0LXN0YXR1cyBjdC1kb25lXCI+XG4gICAgICAgICAge3BoYXNlLnJlc3VsdC5wclVybCA/IChcbiAgICAgICAgICAgIDxwPlxuICAgICAgICAgICAgICBQdWxsIHJlcXVlc3Qgb3BlbmVkIOKAlHtcIiBcIn1cbiAgICAgICAgICAgICAgPGEgY2xhc3NOYW1lPVwiY3QtbGlua1wiIGhyZWY9e3BoYXNlLnJlc3VsdC5wclVybH0gdGFyZ2V0PVwiX2JsYW5rXCIgcmVsPVwibm9yZWZlcnJlclwiPlxuICAgICAgICAgICAgICAgICN7cGhhc2UucmVzdWx0LnByTnVtYmVyfVxuICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDxwPkNvbW1pdHRlZCB7cGhhc2UucmVzdWx0LmNvbW1pdFNoYS5zbGljZSgwLCA3KX0gdG8ge3BoYXNlLnJlc3VsdC5icmFuY2hOYW1lfS48L3A+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7cGhhc2Uua2luZCA9PT0gXCJlcnJvclwiICYmIDxkaXYgY2xhc3NOYW1lPVwiY3Qtc3RhdHVzIGN0LWVycm9yXCI+e2Vycm9ySGludH08L2Rpdj59XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBS0EsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsSUFBQSxHQUFBRCxPQUFBO0FBT0FBLE9BQUE7QUFBMEIsSUFBQUUsV0FBQSxHQUFBRixPQUFBO0FBQUEsSUFBQUcsRUFBQSxHQUFBQyxZQUFBLElBYjFCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFrQkE7QUFDQSxNQUFNQyxXQUFtQyxHQUFHO0VBQzFDLFlBQVksRUFBRSxtQkFBbUI7RUFDakMsY0FBYyxFQUFFLHlCQUF5QjtFQUN6QyxrQkFBa0IsRUFBRSx1QkFBdUI7RUFDM0MsZ0JBQWdCLEVBQUUseUJBQXlCO0VBQzNDLGNBQWMsRUFBRSxzQkFBc0I7RUFDdEMsYUFBYSxFQUFFLGtCQUFrQjtFQUNqQyxhQUFhLEVBQUUsc0JBQXNCO0VBQ3JDLGVBQWUsRUFBRSxzQkFBc0I7RUFDdkMsZUFBZSxFQUFFLHNCQUFzQjtFQUN2QyxXQUFXLEVBQUUsMkJBQTJCO0VBQ3hDLGVBQWUsRUFBRSxxQkFBcUI7RUFDdENDLFFBQVEsRUFBRTtBQUNaLENBQUM7QUFFYyxTQUFTQyxVQUFVQSxDQUFBLEVBQUc7RUFBQUosRUFBQTtFQUNuQyxNQUFNO0lBQUVLO0VBQVcsQ0FBQyxHQUFHLElBQUFDLHFCQUFnQixFQUFDLENBQUM7RUFDekMsTUFBTSxDQUFDQyxPQUFPLEVBQUVDLFVBQVUsQ0FBQyxHQUFHLElBQUFDLGVBQVEsRUFBQyxFQUFFLENBQUM7RUFDMUMsTUFBTSxDQUFDQyxJQUFJLEVBQUVDLE9BQU8sQ0FBQyxHQUFHLElBQUFGLGVBQVEsRUFBaUIsSUFBSSxDQUFDO0VBQ3RELE1BQU0sQ0FBQ0csS0FBSyxFQUFFQyxRQUFRLENBQUMsR0FBRyxJQUFBSixlQUFRLEVBQVE7SUFBRUssSUFBSSxFQUFFO0VBQU8sQ0FBQyxDQUFDO0VBRTNELE1BQU1DLElBQUksR0FBR0gsS0FBSyxDQUFDRSxJQUFJLEtBQUssU0FBUztFQUNyQyxNQUFNRSxhQUFhLEdBQUdYLFVBQVUsQ0FBQ1ksTUFBTSxLQUFLLENBQUM7RUFFN0MsTUFBTUMsR0FBRyxHQUFHLElBQUFDLGtCQUFXLEVBQUMsWUFBWTtJQUNsQ04sUUFBUSxDQUFDO01BQUVDLElBQUksRUFBRSxTQUFTO01BQUVNLEtBQUssRUFBRTtJQUFXLENBQUMsQ0FBQztJQUNoRCxJQUFJO01BQ0YsTUFBTUMsTUFBTSxHQUFHLElBQUFDLGVBQVUsRUFBQztRQUFFQyxhQUFhLEVBQUVoQixPQUFPLENBQUNpQixJQUFJLENBQUMsQ0FBQyxJQUFJLFFBQVE7UUFBRWQ7TUFBSyxDQUFDLENBQUM7TUFDOUUsSUFBSWUsTUFBc0M7TUFDMUMsV0FBVyxNQUFNQyxFQUFFLElBQUlMLE1BQU0sRUFBMkQ7UUFDdEYsSUFBSUssRUFBRSxDQUFDTixLQUFLLEtBQUssa0JBQWtCLEVBQUU7VUFDbkM7VUFDQTtVQUNBUCxRQUFRLENBQUM7WUFDUEMsSUFBSSxFQUFFLGVBQWU7WUFDckJhLFVBQVUsRUFBRUQsRUFBRSxDQUFDQyxVQUFVO1lBQ3pCQyxXQUFXLEVBQUVGLEVBQUUsQ0FBQ0UsV0FBVztZQUMzQkMsVUFBVSxFQUFFSCxFQUFFLENBQUNHO1VBQ2pCLENBQUMsQ0FBQztVQUNGO1FBQ0Y7UUFDQSxJQUFJSCxFQUFFLENBQUNOLEtBQUssS0FBSyxPQUFPLEVBQUU7VUFDeEJQLFFBQVEsQ0FBQztZQUFFQyxJQUFJLEVBQUUsT0FBTztZQUFFZ0IsSUFBSSxFQUFFLFFBQVE7WUFBRXZCLE9BQU8sRUFBRW1CLEVBQUUsQ0FBQ25CO1VBQVEsQ0FBQyxDQUFDO1VBQ2hFO1FBQ0Y7UUFDQSxJQUFJbUIsRUFBRSxDQUFDTixLQUFLLEtBQUssTUFBTSxFQUFFO1VBQ3ZCSyxNQUFNLEdBQUdDLEVBQW1DO1FBQzlDO1FBQ0FiLFFBQVEsQ0FBQztVQUFFQyxJQUFJLEVBQUUsU0FBUztVQUFFTSxLQUFLLEVBQUVNLEVBQUUsQ0FBQ047UUFBTSxDQUFDLENBQUM7TUFDaEQ7TUFDQTtNQUNBUCxRQUFRLENBQUM7UUFBRUMsSUFBSSxFQUFFLE1BQU07UUFBRVcsTUFBTSxFQUFFQSxNQUFNLElBQUs7VUFBRU0sU0FBUyxFQUFFLEVBQUU7VUFBRUMsT0FBTyxFQUFFLEVBQUU7VUFBRUMsVUFBVSxFQUFFLEVBQUU7VUFBRXZCLElBQUksRUFBRTtRQUFnQjtNQUF5QixDQUFDLENBQUM7SUFDN0ksQ0FBQyxDQUFDLE9BQU93QixDQUFDLEVBQUU7TUFDVixNQUFNSixJQUFJLEdBQUlJLENBQUMsRUFBd0JKLElBQUksSUFBSSxTQUFTO01BQ3hEakIsUUFBUSxDQUFDO1FBQUVDLElBQUksRUFBRSxPQUFPO1FBQUVnQixJQUFJO1FBQUV2QixPQUFPLEVBQUcyQixDQUFDLEVBQVkzQixPQUFPLElBQUk7TUFBYyxDQUFDLENBQUM7SUFDcEY7RUFDRixDQUFDLEVBQUUsQ0FBQ0EsT0FBTyxFQUFFRyxJQUFJLENBQUMsQ0FBQztFQUVuQixNQUFNeUIsU0FBUyxHQUFHLElBQUFDLGNBQU8sRUFBQyxNQUFNO0lBQzlCLElBQUl4QixLQUFLLENBQUNFLElBQUksS0FBSyxPQUFPLEVBQUUsT0FBTyxJQUFJO0lBQ3ZDLFFBQVFGLEtBQUssQ0FBQ2tCLElBQUk7TUFDaEIsS0FBSyxlQUFlO1FBQ2xCLE9BQU8sK0JBQStCO01BQ3hDLEtBQUssV0FBVztRQUNkLE9BQU9wQixJQUFJLEtBQUssUUFBUSxHQUNwQiwyREFBMkQsR0FDM0QseUNBQXlDO01BQy9DLEtBQUssV0FBVztRQUNkLE9BQU8sbURBQW1EO01BQzVELEtBQUssVUFBVTtRQUNiLE9BQU8sK0RBQStEO01BQ3hFLEtBQUssTUFBTTtRQUNULE9BQU8sa0NBQWtDO01BQzNDO1FBQ0UsT0FBT0UsS0FBSyxDQUFDTCxPQUFPO0lBQ3hCO0VBQ0YsQ0FBQyxFQUFFLENBQUNLLEtBQUssRUFBRUYsSUFBSSxDQUFDLENBQUM7RUFFakIsb0JBQ0UsSUFBQVgsV0FBQSxDQUFBc0MsSUFBQTtJQUFLQyxTQUFTLEVBQUMsWUFBWTtJQUFBQyxRQUFBLGdCQUN6QixJQUFBeEMsV0FBQSxDQUFBeUMsR0FBQTtNQUFRRixTQUFTLEVBQUMsT0FBTztNQUFBQyxRQUFBLGVBQ3ZCLElBQUF4QyxXQUFBLENBQUF5QyxHQUFBO1FBQU1GLFNBQVMsRUFBQyxVQUFVO1FBQUFDLFFBQUEsRUFBQztNQUFpQixDQUFNO0lBQUMsQ0FDN0MsQ0FBQyxlQUVULElBQUF4QyxXQUFBLENBQUF5QyxHQUFBO01BQVNGLFNBQVMsRUFBQyxZQUFZO01BQUFDLFFBQUEsRUFDNUJ2QixhQUFhLGdCQUNaLElBQUFqQixXQUFBLENBQUF5QyxHQUFBO1FBQUdGLFNBQVMsRUFBQyxVQUFVO1FBQUFDLFFBQUEsRUFBQztNQUFtQixDQUFHLENBQUMsZ0JBRS9DLElBQUF4QyxXQUFBLENBQUFzQyxJQUFBLEVBQUF0QyxXQUFBLENBQUEwQyxRQUFBO1FBQUFGLFFBQUEsZ0JBQ0UsSUFBQXhDLFdBQUEsQ0FBQXNDLElBQUE7VUFBR0MsU0FBUyxFQUFDLGNBQWM7VUFBQUMsUUFBQSxHQUN4QmxDLFVBQVUsQ0FBQ1ksTUFBTSxFQUFDLE9BQUssRUFBQ1osVUFBVSxDQUFDWSxNQUFNLEtBQUssQ0FBQyxHQUFHLEVBQUUsR0FBRyxHQUFHLEVBQUMsZ0JBQzlEO1FBQUEsQ0FBRyxDQUFDLGVBQ0osSUFBQWxCLFdBQUEsQ0FBQXlDLEdBQUE7VUFBSUYsU0FBUyxFQUFDLGFBQWE7VUFBQUMsUUFBQSxFQUN4QmxDLFVBQVUsQ0FBQ3FDLEdBQUcsQ0FBRUMsQ0FBQyxpQkFDaEIsSUFBQTVDLFdBQUEsQ0FBQXlDLEdBQUE7WUFBWUYsU0FBUyxFQUFDLFNBQVM7WUFBQ00sS0FBSyxFQUFFRCxDQUFFO1lBQUFKLFFBQUEsRUFDdENJO1VBQUMsR0FES0EsQ0FFTCxDQUNMO1FBQUMsQ0FDQSxDQUFDO01BQUEsQ0FDTDtJQUNILENBQ00sQ0FBQyxlQUVWLElBQUE1QyxXQUFBLENBQUFzQyxJQUFBO01BQU9DLFNBQVMsRUFBQyxVQUFVO01BQUFDLFFBQUEsZ0JBQ3pCLElBQUF4QyxXQUFBLENBQUF5QyxHQUFBO1FBQU1GLFNBQVMsRUFBQyxVQUFVO1FBQUFDLFFBQUEsRUFBQztNQUFPLENBQU0sQ0FBQyxlQUN6QyxJQUFBeEMsV0FBQSxDQUFBeUMsR0FBQTtRQUNFRixTQUFTLEVBQUMsVUFBVTtRQUNwQk8sS0FBSyxFQUFFdEMsT0FBUTtRQUNmdUMsV0FBVyxFQUFDLHNCQUFzQjtRQUNsQ0MsUUFBUSxFQUFHYixDQUFDLElBQUsxQixVQUFVLENBQUMwQixDQUFDLENBQUNjLE1BQU0sQ0FBQ0gsS0FBSyxDQUFFO1FBQzVDSSxRQUFRLEVBQUVsQztNQUFLLENBQ2hCLENBQUM7SUFBQSxDQUNHLENBQUMsZUFFUixJQUFBaEIsV0FBQSxDQUFBc0MsSUFBQTtNQUFLQyxTQUFTLEVBQUMsU0FBUztNQUFDWSxJQUFJLEVBQUMsWUFBWTtNQUFDLGNBQVcsV0FBVztNQUFBWCxRQUFBLGdCQUMvRCxJQUFBeEMsV0FBQSxDQUFBc0MsSUFBQTtRQUFPQyxTQUFTLEVBQUMsVUFBVTtRQUFBQyxRQUFBLGdCQUN6QixJQUFBeEMsV0FBQSxDQUFBeUMsR0FBQTtVQUNFVyxJQUFJLEVBQUMsT0FBTztVQUNaQyxJQUFJLEVBQUMsTUFBTTtVQUNYQyxPQUFPLEVBQUUzQyxJQUFJLEtBQUssSUFBSztVQUN2QnFDLFFBQVEsRUFBRUEsQ0FBQSxLQUFNcEMsT0FBTyxDQUFDLElBQUksQ0FBRTtVQUM5QnNDLFFBQVEsRUFBRWxDO1FBQUssQ0FDaEIsQ0FBQyxnQkFFSjtNQUFBLENBQU8sQ0FBQyxlQUNSLElBQUFoQixXQUFBLENBQUFzQyxJQUFBO1FBQU9DLFNBQVMsRUFBQyxVQUFVO1FBQUFDLFFBQUEsZ0JBQ3pCLElBQUF4QyxXQUFBLENBQUF5QyxHQUFBO1VBQ0VXLElBQUksRUFBQyxPQUFPO1VBQ1pDLElBQUksRUFBQyxNQUFNO1VBQ1hDLE9BQU8sRUFBRTNDLElBQUksS0FBSyxRQUFTO1VBQzNCcUMsUUFBUSxFQUFFQSxDQUFBLEtBQU1wQyxPQUFPLENBQUMsUUFBUSxDQUFFO1VBQ2xDc0MsUUFBUSxFQUFFbEM7UUFBSyxDQUNoQixDQUFDLG1CQUVKO01BQUEsQ0FBTyxDQUFDO0lBQUEsQ0FDTCxDQUFDLGVBRU4sSUFBQWhCLFdBQUEsQ0FBQXlDLEdBQUE7TUFDRVcsSUFBSSxFQUFDLFFBQVE7TUFDYmIsU0FBUyxFQUFDLFNBQVM7TUFDbkJnQixPQUFPLEVBQUVwQyxHQUFJO01BQ2IrQixRQUFRLEVBQUVsQyxJQUFJLElBQUlDLGFBQWM7TUFBQXVCLFFBQUEsRUFFL0J4QixJQUFJLEdBQUdiLFdBQVcsQ0FBQ1UsS0FBSyxDQUFDUSxLQUFLLENBQUMsSUFBSSxTQUFTLEdBQUdWLElBQUksS0FBSyxRQUFRLEdBQUcsUUFBUSxHQUFHO0lBQW1CLENBQzVGLENBQUMsRUFFUkUsS0FBSyxDQUFDRSxJQUFJLEtBQUssZUFBZSxpQkFDN0IsSUFBQWYsV0FBQSxDQUFBc0MsSUFBQTtNQUFLQyxTQUFTLEVBQUMsc0JBQXNCO01BQUFDLFFBQUEsZ0JBQ25DLElBQUF4QyxXQUFBLENBQUFzQyxJQUFBO1FBQUFFLFFBQUEsR0FBRywyQ0FDd0MsRUFBQyxHQUFHLGVBQzdDLElBQUF4QyxXQUFBLENBQUFzQyxJQUFBO1VBQUFFLFFBQUEsR0FDRzNCLEtBQUssQ0FBQ2dCLFdBQVcsRUFBQyxHQUFDLEVBQUNoQixLQUFLLENBQUNpQixVQUFVO1FBQUEsQ0FDL0IsQ0FBQyxFQUFDLEdBQUcsRUFBQyxlQUVoQjtNQUFBLENBQUcsQ0FBQyxlQUNKLElBQUE5QixXQUFBLENBQUF5QyxHQUFBO1FBQUdGLFNBQVMsRUFBQyxTQUFTO1FBQUNpQixJQUFJLEVBQUUzQyxLQUFLLENBQUNlLFVBQVc7UUFBQ3FCLE1BQU0sRUFBQyxRQUFRO1FBQUNRLEdBQUcsRUFBQyxZQUFZO1FBQUFqQixRQUFBLEVBQUM7TUFFaEYsQ0FBRyxDQUFDLEVBQUMsR0FBRyxlQUNSLElBQUF4QyxXQUFBLENBQUF5QyxHQUFBO1FBQVFXLElBQUksRUFBQyxRQUFRO1FBQUNiLFNBQVMsRUFBQyxVQUFVO1FBQUNnQixPQUFPLEVBQUVwQyxHQUFJO1FBQUFxQixRQUFBLEVBQUM7TUFFekQsQ0FBUSxDQUFDO0lBQUEsQ0FDTixDQUNOLEVBRUEzQixLQUFLLENBQUNFLElBQUksS0FBSyxNQUFNLGlCQUNwQixJQUFBZixXQUFBLENBQUF5QyxHQUFBO01BQUtGLFNBQVMsRUFBQyxtQkFBbUI7TUFBQUMsUUFBQSxFQUMvQjNCLEtBQUssQ0FBQ2EsTUFBTSxDQUFDZ0MsS0FBSyxnQkFDakIsSUFBQTFELFdBQUEsQ0FBQXNDLElBQUE7UUFBQUUsUUFBQSxHQUFHLDRCQUNvQixFQUFDLEdBQUcsZUFDekIsSUFBQXhDLFdBQUEsQ0FBQXNDLElBQUE7VUFBR0MsU0FBUyxFQUFDLFNBQVM7VUFBQ2lCLElBQUksRUFBRTNDLEtBQUssQ0FBQ2EsTUFBTSxDQUFDZ0MsS0FBTTtVQUFDVCxNQUFNLEVBQUMsUUFBUTtVQUFDUSxHQUFHLEVBQUMsWUFBWTtVQUFBakIsUUFBQSxHQUFDLEdBQy9FLEVBQUMzQixLQUFLLENBQUNhLE1BQU0sQ0FBQ2lDLFFBQVE7UUFBQSxDQUN0QixDQUFDO01BQUEsQ0FDSCxDQUFDLGdCQUVKLElBQUEzRCxXQUFBLENBQUFzQyxJQUFBO1FBQUFFLFFBQUEsR0FBRyxZQUFVLEVBQUMzQixLQUFLLENBQUNhLE1BQU0sQ0FBQ00sU0FBUyxDQUFDNEIsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBQyxNQUFJLEVBQUMvQyxLQUFLLENBQUNhLE1BQU0sQ0FBQ1EsVUFBVSxFQUFDLEdBQUM7TUFBQSxDQUFHO0lBQ25GLENBQ0UsQ0FDTixFQUVBckIsS0FBSyxDQUFDRSxJQUFJLEtBQUssT0FBTyxpQkFBSSxJQUFBZixXQUFBLENBQUF5QyxHQUFBO01BQUtGLFNBQVMsRUFBQyxvQkFBb0I7TUFBQUMsUUFBQSxFQUFFSjtJQUFTLENBQU0sQ0FBQztFQUFBLENBQzdFLENBQUM7QUFFVjtBQUFDbkMsRUFBQSxDQXZLdUJJLFVBQVU7RUFBQSxRQUNURSxxQkFBZ0I7QUFBQTtBQUFBc0QsRUFBQSxHQURqQnhELFVBQVU7QUFBQSxJQUFBd0QsRUFBQTtBQUFBQyxZQUFBLENBQUFELEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}