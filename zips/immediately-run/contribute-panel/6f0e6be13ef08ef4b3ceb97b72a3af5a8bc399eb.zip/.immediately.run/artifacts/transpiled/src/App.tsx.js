var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
require("./index.css");
var _sdk = require("@immediately-run/sdk");
var _SourceControlPanel = _interopRequireDefault(require("./components/SourceControlPanel"));
var _DiffPane = _interopRequireDefault(require("./components/DiffPane"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // Root component — immediately.run renders the default export of THIS file.
// The source-control sidebar as an app (UI_AS_APPS_SPEC §5.3; migrate-sidebars
// Phase 06): it shows the working-tree diff, the branch lineage, and the open
// PRs (elevated `vcs:read`), arms-then-confirms a working-tree reset (first-party
// `vcs:reset`), and drives the save flow via the streamed `contribute()` call.
// The COW/journal + OAuth token never reach this app — the host derives every
// projection and performs every privileged step; this frame only reacts.
//
// R3-478 — this one program now serves TWO regions and branches on `useRegion()`
// (the devtools `panel.tools`/`mainpane.tools` idiom): the sidebar half, plus
// `mainpane.contribute-diff`, the main-pane surface that renders the selected
// changed file's diff. The two halves are two frames with no shared memory; the
// selection flows over their single §5.6 IPC edge (lib/diffSelection.ts).
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function App() {
  _s();
  const region = (0, _sdk.useRegion)();
  if (region === "mainpane.contribute-diff") return /*#__PURE__*/(0, _jsxRuntime.jsx)(_DiffPane.default, {});
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_SourceControlPanel.default, {});
}
_s(App, "Ppkt00pAC6N/60HFSwQrnIuv9kM=", false, function () {
  return [_sdk.useRegion];
});
_c = App;
var _default = exports.default = App;
var _c;
$RefreshReg$(_c, "App");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJyZXF1aXJlIiwiX3NkayIsIl9Tb3VyY2VDb250cm9sUGFuZWwiLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX0RpZmZQYW5lIiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsIkFwcCIsInJlZ2lvbiIsInVzZVJlZ2lvbiIsImpzeCIsIl9jIiwiX2RlZmF1bHQiLCJleHBvcnRzIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQXBwLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBSb290IGNvbXBvbmVudCDigJQgaW1tZWRpYXRlbHkucnVuIHJlbmRlcnMgdGhlIGRlZmF1bHQgZXhwb3J0IG9mIFRISVMgZmlsZS5cbi8vIFRoZSBzb3VyY2UtY29udHJvbCBzaWRlYmFyIGFzIGFuIGFwcCAoVUlfQVNfQVBQU19TUEVDIMKnNS4zOyBtaWdyYXRlLXNpZGViYXJzXG4vLyBQaGFzZSAwNik6IGl0IHNob3dzIHRoZSB3b3JraW5nLXRyZWUgZGlmZiwgdGhlIGJyYW5jaCBsaW5lYWdlLCBhbmQgdGhlIG9wZW5cbi8vIFBScyAoZWxldmF0ZWQgYHZjczpyZWFkYCksIGFybXMtdGhlbi1jb25maXJtcyBhIHdvcmtpbmctdHJlZSByZXNldCAoZmlyc3QtcGFydHlcbi8vIGB2Y3M6cmVzZXRgKSwgYW5kIGRyaXZlcyB0aGUgc2F2ZSBmbG93IHZpYSB0aGUgc3RyZWFtZWQgYGNvbnRyaWJ1dGUoKWAgY2FsbC5cbi8vIFRoZSBDT1cvam91cm5hbCArIE9BdXRoIHRva2VuIG5ldmVyIHJlYWNoIHRoaXMgYXBwIOKAlCB0aGUgaG9zdCBkZXJpdmVzIGV2ZXJ5XG4vLyBwcm9qZWN0aW9uIGFuZCBwZXJmb3JtcyBldmVyeSBwcml2aWxlZ2VkIHN0ZXA7IHRoaXMgZnJhbWUgb25seSByZWFjdHMuXG4vL1xuLy8gUjMtNDc4IOKAlCB0aGlzIG9uZSBwcm9ncmFtIG5vdyBzZXJ2ZXMgVFdPIHJlZ2lvbnMgYW5kIGJyYW5jaGVzIG9uIGB1c2VSZWdpb24oKWBcbi8vICh0aGUgZGV2dG9vbHMgYHBhbmVsLnRvb2xzYC9gbWFpbnBhbmUudG9vbHNgIGlkaW9tKTogdGhlIHNpZGViYXIgaGFsZiwgcGx1c1xuLy8gYG1haW5wYW5lLmNvbnRyaWJ1dGUtZGlmZmAsIHRoZSBtYWluLXBhbmUgc3VyZmFjZSB0aGF0IHJlbmRlcnMgdGhlIHNlbGVjdGVkXG4vLyBjaGFuZ2VkIGZpbGUncyBkaWZmLiBUaGUgdHdvIGhhbHZlcyBhcmUgdHdvIGZyYW1lcyB3aXRoIG5vIHNoYXJlZCBtZW1vcnk7IHRoZVxuLy8gc2VsZWN0aW9uIGZsb3dzIG92ZXIgdGhlaXIgc2luZ2xlIMKnNS42IElQQyBlZGdlIChsaWIvZGlmZlNlbGVjdGlvbi50cykuXG5pbXBvcnQgXCIuL2luZGV4LmNzc1wiO1xuaW1wb3J0IHsgdXNlUmVnaW9uIH0gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrXCI7XG5pbXBvcnQgU291cmNlQ29udHJvbFBhbmVsIGZyb20gXCIuL2NvbXBvbmVudHMvU291cmNlQ29udHJvbFBhbmVsXCI7XG5pbXBvcnQgRGlmZlBhbmUgZnJvbSBcIi4vY29tcG9uZW50cy9EaWZmUGFuZVwiO1xuXG5mdW5jdGlvbiBBcHAoKSB7XG4gIGNvbnN0IHJlZ2lvbiA9IHVzZVJlZ2lvbigpO1xuICBpZiAocmVnaW9uID09PSBcIm1haW5wYW5lLmNvbnRyaWJ1dGUtZGlmZlwiKSByZXR1cm4gPERpZmZQYW5lIC8+O1xuICByZXR1cm4gPFNvdXJjZUNvbnRyb2xQYW5lbCAvPjtcbn1cblxuZXhwb3J0IGRlZmF1bHQgQXBwO1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFhQUEsT0FBQTtBQUNBLElBQUFDLElBQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLG1CQUFBLEdBQUFDLHNCQUFBLENBQUFILE9BQUE7QUFDQSxJQUFBSSxTQUFBLEdBQUFELHNCQUFBLENBQUFILE9BQUE7QUFBNkMsSUFBQUssV0FBQSxHQUFBTCxPQUFBO0FBQUEsSUFBQU0sRUFBQSxHQUFBQyxZQUFBLElBaEI3QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUFBLFNBQUFKLHVCQUFBSyxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBTUEsU0FBU0csR0FBR0EsQ0FBQSxFQUFHO0VBQUFMLEVBQUE7RUFDYixNQUFNTSxNQUFNLEdBQUcsSUFBQUMsY0FBUyxFQUFDLENBQUM7RUFDMUIsSUFBSUQsTUFBTSxLQUFLLDBCQUEwQixFQUFFLG9CQUFPLElBQUFQLFdBQUEsQ0FBQVMsR0FBQSxFQUFDVixTQUFBLENBQUFNLE9BQVEsSUFBRSxDQUFDO0VBQzlELG9CQUFPLElBQUFMLFdBQUEsQ0FBQVMsR0FBQSxFQUFDWixtQkFBQSxDQUFBUSxPQUFrQixJQUFFLENBQUM7QUFDL0I7QUFBQ0osRUFBQSxDQUpRSyxHQUFHO0VBQUEsUUFDS0UsY0FBUztBQUFBO0FBQUFFLEVBQUEsR0FEakJKLEdBQUc7QUFBQSxJQUFBSyxRQUFBLEdBQUFDLE9BQUEsQ0FBQVAsT0FBQSxHQU1HQyxHQUFHO0FBQUEsSUFBQUksRUFBQTtBQUFBRyxZQUFBLENBQUFILEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}