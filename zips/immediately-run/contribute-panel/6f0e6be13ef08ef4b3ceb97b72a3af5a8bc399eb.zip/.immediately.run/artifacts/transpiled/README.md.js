var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      li: "li",
      p: "p",
      pre: "pre",
      strong: "strong",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "contribute-panel",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "contribute-panel"
      }), "contribute-panel"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "source-control sidebar"
      }), " as an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "https://immediately.run",
        children: "immediately.run"
      }), "\napp — the first-party system app bound to the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "panel.contribute"
      }), " chrome region\n(UI_AS_APPS_SPEC §5.3; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "migrate-sidebars-to-apps"
      }), " Phase 06)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["It is the app replacement for the native ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "SourceControlPanel"
      }), ": it shows the\nworking-tree ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "diff"
      }), " (changed files grouped by added / modified / deleted), the\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "branch lineage"
      }), " it was branched from, the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "open PRs"
      }), " for the current branch,\nan ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "arm-then-confirm reset"
      }), ", and an inline ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "save"
      }), " (pull request or direct\ncommit) driven by the streamed ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "contribute()"
      }), " call."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["No ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "DiffResult"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "FileSystem"
        }), ", or OAuth token ever reaches this app."]
      }), " The host\nderives every projection from authenticated GitHub calls + the COW layers and\nperforms every privileged step (the diff compute, the fork, the PR, the reset);\nthis app only observes the plain-JSON ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "VcsState"
      }), " the host pushes and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "names"
      }), "\nintents the host performs."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "the-vcs-surface-it-consumes",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-vcs-surface-it-consumes"
      }), "The ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "vcs"
      }), " surface it consumes"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "useVcsState()"
        }), " — the host-projected ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "{ changes, branch, prs, diffLoading }"
        }), "\nsnapshot (elevated ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "vcs:read"
        }), "; empty until the host answers, and for any frame\nwithout the capability)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "refreshDiff()"
        }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "refreshPRs()"
        }), " — ask the host to recompute / re-poll and push\na fresh snapshot (gated ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "vcs:read"
        }), ")."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "resetWorkingTree()"
        }), " — DISCARD the working tree (COW writable wipe + journal\nclear). First-party-only ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "vcs:reset"
        }), "; a fork/preview is refused at the gate. The\narm-then-confirm UX lives here; the authority is gated host-side."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "contribute()"
        }), " — the unchanged save stream (PR / direct commit), reused from the\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "immediately-run/contribute"
        }), " dialog pilot."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "capabilities",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "capabilities"
      }), "Capabilities"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "theme:read"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "formFactor:read"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "route:read"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "catalog:read"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "auth:status"
      }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "mounts:read"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "editor:read"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "vcs:read"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "vcs:reset"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "contribute:any"
      }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "contribute:direct"
      }), " — declared in the host's build-default registry\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "immediately-run-site-main/src/registry/defaults.ts"
      }), "). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "vcs:reset"
      }), " and\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "contribute:direct"
      }), " are first-party-only."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "develop",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "develop"
      }), "Develop"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-sh",
        children: "npm install\nnpm run dev      # standalone (no host chrome / empty VcsState / no real save)\nnpm run build\nnpm test         # unit tests for the pure SourceControlView (reset UX, rendering)\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Pop the hood: fork it, rebind the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "panel.contribute"
      }), " region to your fork, and the\nsource-control sidebar becomes yours."]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/README.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiY29kZSIsImVtIiwiaDEiLCJoMiIsImxpIiwicCIsInByZSIsInN0cm9uZyIsInVsIiwiX3Byb3ZpZGVDb21wb25lbnRzIiwiY29tcG9uZW50cyIsIkhlYWRpbmdBbmNob3IiLCJfbWlzc2luZ01keFJlZmVyZW5jZSIsImpzeHMiLCJGcmFnbWVudCIsImNoaWxkcmVuIiwiaWQiLCJqc3giLCJocmVmIiwiY2xhc3NOYW1lIiwiTURYQ29udGVudCIsIndyYXBwZXIiLCJNRFhMYXlvdXQiLCJfYyIsImNvbXBvbmVudCIsInBsYWNlIiwiRXJyb3IiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJSRUFETUUubWQiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgYTogXCJhXCIsXG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgZW06IFwiZW1cIixcbiAgICBoMTogXCJoMVwiLFxuICAgIGgyOiBcImgyXCIsXG4gICAgbGk6IFwibGlcIixcbiAgICBwOiBcInBcIixcbiAgICBwcmU6IFwicHJlXCIsXG4gICAgc3Ryb25nOiBcInN0cm9uZ1wiLFxuICAgIHVsOiBcInVsXCIsXG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9LCB7SGVhZGluZ0FuY2hvcn0gPSBfY29tcG9uZW50cztcbiAgaWYgKCFIZWFkaW5nQW5jaG9yKSBfbWlzc2luZ01keFJlZmVyZW5jZShcIkhlYWRpbmdBbmNob3JcIiwgdHJ1ZSk7XG4gIHJldHVybiA8PjxfY29tcG9uZW50cy5oMSBpZD1cImNvbnRyaWJ1dGUtcGFuZWxcIj48SGVhZGluZ0FuY2hvciBpZD1cImNvbnRyaWJ1dGUtcGFuZWxcIiAvPntcImNvbnRyaWJ1dGUtcGFuZWxcIn08L19jb21wb25lbnRzLmgxPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInNvdXJjZS1jb250cm9sIHNpZGViYXJcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYXMgYW4gXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cImh0dHBzOi8vaW1tZWRpYXRlbHkucnVuXCI+e1wiaW1tZWRpYXRlbHkucnVuXCJ9PC9fY29tcG9uZW50cy5hPntcIlxcbmFwcCDigJQgdGhlIGZpcnN0LXBhcnR5IHN5c3RlbSBhcHAgYm91bmQgdG8gdGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcInBhbmVsLmNvbnRyaWJ1dGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNocm9tZSByZWdpb25cXG4oVUlfQVNfQVBQU19TUEVDIMKnNS4zOyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJtaWdyYXRlLXNpZGViYXJzLXRvLWFwcHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIFBoYXNlIDA2KS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiSXQgaXMgdGhlIGFwcCByZXBsYWNlbWVudCBmb3IgdGhlIG5hdGl2ZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJTb3VyY2VDb250cm9sUGFuZWxcIn08L19jb21wb25lbnRzLmNvZGU+e1wiOiBpdCBzaG93cyB0aGVcXG53b3JraW5nLXRyZWUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJkaWZmXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChjaGFuZ2VkIGZpbGVzIGdyb3VwZWQgYnkgYWRkZWQgLyBtb2RpZmllZCAvIGRlbGV0ZWQpLCB0aGVcXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImJyYW5jaCBsaW5lYWdlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGl0IHdhcyBicmFuY2hlZCBmcm9tLCB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJvcGVuIFBSc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBmb3IgdGhlIGN1cnJlbnQgYnJhbmNoLFxcbmFuIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiYXJtLXRoZW4tY29uZmlybSByZXNldFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgYW5kIGFuIGlubGluZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInNhdmVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHB1bGwgcmVxdWVzdCBvciBkaXJlY3RcXG5jb21taXQpIGRyaXZlbiBieSB0aGUgc3RyZWFtZWQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY29udHJpYnV0ZSgpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjYWxsLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIk5vIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkRpZmZSZXN1bHRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJGaWxlU3lzdGVtXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgb3IgT0F1dGggdG9rZW4gZXZlciByZWFjaGVzIHRoaXMgYXBwLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGUgaG9zdFxcbmRlcml2ZXMgZXZlcnkgcHJvamVjdGlvbiBmcm9tIGF1dGhlbnRpY2F0ZWQgR2l0SHViIGNhbGxzICsgdGhlIENPVyBsYXllcnMgYW5kXFxucGVyZm9ybXMgZXZlcnkgcHJpdmlsZWdlZCBzdGVwICh0aGUgZGlmZiBjb21wdXRlLCB0aGUgZm9yaywgdGhlIFBSLCB0aGUgcmVzZXQpO1xcbnRoaXMgYXBwIG9ubHkgb2JzZXJ2ZXMgdGhlIHBsYWluLUpTT04gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiVmNzU3RhdGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHRoZSBob3N0IHB1c2hlcyBhbmQgXCJ9PF9jb21wb25lbnRzLmVtPntcIm5hbWVzXCJ9PC9fY29tcG9uZW50cy5lbT57XCJcXG5pbnRlbnRzIHRoZSBob3N0IHBlcmZvcm1zLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJ0aGUtdmNzLXN1cmZhY2UtaXQtY29uc3VtZXNcIj48SGVhZGluZ0FuY2hvciBpZD1cInRoZS12Y3Mtc3VyZmFjZS1pdC1jb25zdW1lc1wiIC8+e1wiVGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcInZjc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgc3VyZmFjZSBpdCBjb25zdW1lc1wifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuY29kZT57XCJ1c2VWY3NTdGF0ZSgpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgdGhlIGhvc3QtcHJvamVjdGVkIFwifTxfY29tcG9uZW50cy5jb2RlPntcInsgY2hhbmdlcywgYnJhbmNoLCBwcnMsIGRpZmZMb2FkaW5nIH1cIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxuc25hcHNob3QgKGVsZXZhdGVkIFwifTxfY29tcG9uZW50cy5jb2RlPntcInZjczpyZWFkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjsgZW1wdHkgdW50aWwgdGhlIGhvc3QgYW5zd2VycywgYW5kIGZvciBhbnkgZnJhbWVcXG53aXRob3V0IHRoZSBjYXBhYmlsaXR5KS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuY29kZT57XCJyZWZyZXNoRGlmZigpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAvIFwifTxfY29tcG9uZW50cy5jb2RlPntcInJlZnJlc2hQUnMoKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIGFzayB0aGUgaG9zdCB0byByZWNvbXB1dGUgLyByZS1wb2xsIGFuZCBwdXNoXFxuYSBmcmVzaCBzbmFwc2hvdCAoZ2F0ZWQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widmNzOnJlYWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuY29kZT57XCJyZXNldFdvcmtpbmdUcmVlKClcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCBESVNDQVJEIHRoZSB3b3JraW5nIHRyZWUgKENPVyB3cml0YWJsZSB3aXBlICsgam91cm5hbFxcbmNsZWFyKS4gRmlyc3QtcGFydHktb25seSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ2Y3M6cmVzZXRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiOyBhIGZvcmsvcHJldmlldyBpcyByZWZ1c2VkIGF0IHRoZSBnYXRlLiBUaGVcXG5hcm0tdGhlbi1jb25maXJtIFVYIGxpdmVzIGhlcmU7IHRoZSBhdXRob3JpdHkgaXMgZ2F0ZWQgaG9zdC1zaWRlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5jb2RlPntcImNvbnRyaWJ1dGUoKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIHRoZSB1bmNoYW5nZWQgc2F2ZSBzdHJlYW0gKFBSIC8gZGlyZWN0IGNvbW1pdCksIHJldXNlZCBmcm9tIHRoZVxcblwifTxfY29tcG9uZW50cy5jb2RlPntcImltbWVkaWF0ZWx5LXJ1bi9jb250cmlidXRlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBkaWFsb2cgcGlsb3QuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cImNhcGFiaWxpdGllc1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwiY2FwYWJpbGl0aWVzXCIgLz57XCJDYXBhYmlsaXRpZXNcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5jb2RlPntcInRoZW1lOnJlYWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmb3JtRmFjdG9yOnJlYWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyb3V0ZTpyZWFkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2F0YWxvZzpyZWFkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYXV0aDpzdGF0dXNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcIm1vdW50czpyZWFkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZWRpdG9yOnJlYWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ2Y3M6cmVhZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcInZjczpyZXNldFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNvbnRyaWJ1dGU6YW55XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIixcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJjb250cmlidXRlOmRpcmVjdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIGRlY2xhcmVkIGluIHRoZSBob3N0J3MgYnVpbGQtZGVmYXVsdCByZWdpc3RyeVxcbihcIn08X2NvbXBvbmVudHMuY29kZT57XCJpbW1lZGlhdGVseS1ydW4tc2l0ZS1tYWluL3NyYy9yZWdpc3RyeS9kZWZhdWx0cy50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ2Y3M6cmVzZXRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFuZFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcImNvbnRyaWJ1dGU6ZGlyZWN0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhcmUgZmlyc3QtcGFydHktb25seS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwiZGV2ZWxvcFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiZGV2ZWxvcFwiIC8+e1wiRGV2ZWxvcFwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnByZT48X2NvbXBvbmVudHMuY29kZSBjbGFzc05hbWU9XCJsYW5ndWFnZS1zaFwiPntcIm5wbSBpbnN0YWxsXFxubnBtIHJ1biBkZXYgICAgICAjIHN0YW5kYWxvbmUgKG5vIGhvc3QgY2hyb21lIC8gZW1wdHkgVmNzU3RhdGUgLyBubyByZWFsIHNhdmUpXFxubnBtIHJ1biBidWlsZFxcbm5wbSB0ZXN0ICAgICAgICAgIyB1bml0IHRlc3RzIGZvciB0aGUgcHVyZSBTb3VyY2VDb250cm9sVmlldyAocmVzZXQgVVgsIHJlbmRlcmluZylcXG5cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5wcmU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiUG9wIHRoZSBob29kOiBmb3JrIGl0LCByZWJpbmQgdGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcInBhbmVsLmNvbnRyaWJ1dGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHJlZ2lvbiB0byB5b3VyIGZvcmssIGFuZCB0aGVcXG5zb3VyY2UtY29udHJvbCBzaWRlYmFyIGJlY29tZXMgeW91cnMuXCJ9PC9fY29tcG9uZW50cy5wPjwvPjtcbn1cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE1EWENvbnRlbnQocHJvcHMgPSB7fSkge1xuICBjb25zdCB7d3JhcHBlcjogTURYTGF5b3V0fSA9IHtcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH07XG4gIHJldHVybiBNRFhMYXlvdXQgPyA8TURYTGF5b3V0IHsuLi5wcm9wc30+PF9jcmVhdGVNZHhDb250ZW50IHsuLi5wcm9wc30gLz48L01EWExheW91dD4gOiBfY3JlYXRlTWR4Q29udGVudChwcm9wcyk7XG59XG5mdW5jdGlvbiBfbWlzc2luZ01keFJlZmVyZW5jZShpZCwgY29tcG9uZW50LCBwbGFjZSkge1xuICB0aHJvdyBuZXcgRXJyb3IoXCJFeHBlY3RlZCBcIiArIChjb21wb25lbnQgPyBcImNvbXBvbmVudFwiIDogXCJvYmplY3RcIikgKyBcIiBgXCIgKyBpZCArIFwiYCB0byBiZSBkZWZpbmVkOiB5b3UgbGlrZWx5IGZvcmdvdCB0byBpbXBvcnQsIHBhc3MsIG9yIHByb3ZpZGUgaXQuXCIgKyAocGxhY2UgPyBcIlxcbkl04oCZcyByZWZlcmVuY2VkIGluIHlvdXIgY29kZSBhdCBgXCIgKyBwbGFjZSArIFwiYCBpbiBgL2FwcC9SRUFETUUubWRgXCIgOiBcIlwiKSk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUVBLElBQUFBLFlBQUEsR0FBQUMsT0FBQTtBQUF3RixJQUFBQyxXQUFBLEdBQUFELE9BQUE7QUFGeEY7QUFDQTs7QUFFQSxTQUFTRSxpQkFBaUJBLENBQUNDLEtBQUssRUFBRTtFQUNoQyxNQUFNQyxXQUFXLEdBQUc7TUFDbEJDLENBQUMsRUFBRSxHQUFHO01BQ05DLElBQUksRUFBRSxNQUFNO01BQ1pDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLENBQUMsRUFBRSxHQUFHO01BQ05DLEdBQUcsRUFBRSxLQUFLO01BQ1ZDLE1BQU0sRUFBRSxRQUFRO01BQ2hCQyxFQUFFLEVBQUUsSUFBSTtNQUNSLEdBQUcsSUFBQUMsNkJBQWtCLEVBQUMsQ0FBQztNQUN2QixHQUFHWixLQUFLLENBQUNhO0lBQ1gsQ0FBQztJQUFFO01BQUNDO0lBQWEsQ0FBQyxHQUFHYixXQUFXO0VBQ2hDLElBQUksQ0FBQ2EsYUFBYSxFQUFFQyxvQkFBb0IsQ0FBQyxlQUFlLEVBQUUsSUFBSSxDQUFDO0VBQy9ELG9CQUFPLElBQUFqQixXQUFBLENBQUFrQixJQUFBLEVBQUFsQixXQUFBLENBQUFtQixRQUFBO0lBQUFDLFFBQUEsZ0JBQUUsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDSSxFQUFFO01BQUNjLEVBQUUsRUFBQyxrQkFBa0I7TUFBQUQsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFrQixDQUFFLENBQUMsRUFBQyxrQkFBa0I7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ08sQ0FBQztNQUFBVSxRQUFBLEdBQUUsTUFBTSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQXdCLENBQXFCLENBQUMsRUFBQyxTQUFTLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsQ0FBQztRQUFDbUIsSUFBSSxFQUFDLHlCQUF5QjtRQUFBSCxRQUFBLEVBQUU7TUFBaUIsQ0FBZ0IsQ0FBQyxFQUFDLGtEQUFrRCxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNFLElBQUk7UUFBQWUsUUFBQSxFQUFFO01BQWtCLENBQW1CLENBQUMsRUFBQyx5Q0FBeUMsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRSxJQUFJO1FBQUFlLFFBQUEsRUFBRTtNQUEwQixDQUFtQixDQUFDLEVBQUMsYUFBYTtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTyxDQUFDO01BQUFVLFFBQUEsR0FBRSwyQ0FBMkMsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRSxJQUFJO1FBQUFlLFFBQUEsRUFBRTtNQUFvQixDQUFtQixDQUFDLEVBQUMsK0JBQStCLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBTSxDQUFxQixDQUFDLEVBQUMsK0RBQStELGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBZ0IsQ0FBcUIsQ0FBQyxFQUFDLDZCQUE2QixlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQVUsQ0FBcUIsQ0FBQyxFQUFDLCtCQUErQixlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQXdCLENBQXFCLENBQUMsRUFBQyxrQkFBa0IsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDUyxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFNLENBQXFCLENBQUMsRUFBQywyREFBMkQsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRSxJQUFJO1FBQUFlLFFBQUEsRUFBRTtNQUFjLENBQW1CLENBQUMsRUFBQyxRQUFRO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNPLENBQUM7TUFBQVUsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNTLE1BQU07UUFBQVEsUUFBQSxHQUFFLEtBQUssZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRSxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFZLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBWSxDQUFtQixDQUFDLEVBQUMseUNBQXlDO01BQUEsQ0FBcUIsQ0FBQyxFQUFDLG1OQUFtTixlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNFLElBQUk7UUFBQWUsUUFBQSxFQUFFO01BQVUsQ0FBbUIsQ0FBQyxFQUFDLHVCQUF1QixlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNHLEVBQUU7UUFBQWMsUUFBQSxFQUFFO01BQU8sQ0FBaUIsQ0FBQyxFQUFDLDhCQUE4QjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDSyxFQUFFO01BQUNhLEVBQUUsRUFBQyw2QkFBNkI7TUFBQUQsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUE2QixDQUFFLENBQUMsRUFBQyxNQUFNLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBZSxRQUFBLEVBQUU7TUFBSyxDQUFtQixDQUFDLEVBQUMsc0JBQXNCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNVLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7UUFBQVcsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRSxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFlLENBQW1CLENBQUMsRUFBQyx3QkFBd0IsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRSxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUF1QyxDQUFtQixDQUFDLEVBQUMsdUJBQXVCLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBVSxDQUFtQixDQUFDLEVBQUMsNkVBQTZFO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7UUFBQVcsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRSxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFlLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBYyxDQUFtQixDQUFDLEVBQUMsMkVBQTJFLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBVSxDQUFtQixDQUFDLEVBQUMsSUFBSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTSxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBb0IsQ0FBbUIsQ0FBQyxFQUFDLHFGQUFxRixlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNFLElBQUk7VUFBQWUsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLGlIQUFpSDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTSxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBYyxDQUFtQixDQUFDLEVBQUMsc0VBQXNFLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBNEIsQ0FBbUIsQ0FBQyxFQUFDLGdCQUFnQjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNLLEVBQUU7TUFBQ2EsRUFBRSxFQUFDLGNBQWM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFjLENBQUUsQ0FBQyxFQUFDLGNBQWM7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ08sQ0FBQztNQUFBVSxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNFLElBQUk7UUFBQWUsUUFBQSxFQUFFO01BQVksQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRSxJQUFJO1FBQUFlLFFBQUEsRUFBRTtNQUFpQixDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNFLElBQUk7UUFBQWUsUUFBQSxFQUFFO01BQVksQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRSxJQUFJO1FBQUFlLFFBQUEsRUFBRTtNQUFjLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBZSxRQUFBLEVBQUU7TUFBYSxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNFLElBQUk7UUFBQWUsUUFBQSxFQUFFO01BQWEsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRSxJQUFJO1FBQUFlLFFBQUEsRUFBRTtNQUFhLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBZSxRQUFBLEVBQUU7TUFBVSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNFLElBQUk7UUFBQWUsUUFBQSxFQUFFO01BQVcsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRSxJQUFJO1FBQUFlLFFBQUEsRUFBRTtNQUFnQixDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNFLElBQUk7UUFBQWUsUUFBQSxFQUFFO01BQW1CLENBQW1CLENBQUMsRUFBQyxxREFBcUQsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRSxJQUFJO1FBQUFlLFFBQUEsRUFBRTtNQUFvRCxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNFLElBQUk7UUFBQWUsUUFBQSxFQUFFO01BQVcsQ0FBbUIsQ0FBQyxFQUFDLFFBQVEsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRSxJQUFJO1FBQUFlLFFBQUEsRUFBRTtNQUFtQixDQUFtQixDQUFDLEVBQUMsd0JBQXdCO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNLLEVBQUU7TUFBQ2EsRUFBRSxFQUFDLFNBQVM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFTLENBQUUsQ0FBQyxFQUFDLFNBQVM7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNRLEdBQUc7TUFBQVMsUUFBQSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNFLElBQUk7UUFBQ21CLFNBQVMsRUFBQyxhQUFhO1FBQUFKLFFBQUEsRUFBRTtNQUFrTSxDQUFtQjtJQUFDLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTyxDQUFDO01BQUFVLFFBQUEsR0FBRSxvQ0FBb0MsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRSxJQUFJO1FBQUFlLFFBQUEsRUFBRTtNQUFrQixDQUFtQixDQUFDLEVBQUMsc0VBQXNFO0lBQUEsQ0FBZ0IsQ0FBQztFQUFBLENBQUUsQ0FBQztBQUNoN0o7QUFDZSxTQUFTSyxVQUFVQSxDQUFDdkIsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFO0VBQzdDLE1BQU07SUFBQ3dCLE9BQU8sRUFBRUM7RUFBUyxDQUFDLEdBQUc7SUFDM0IsR0FBRyxJQUFBYiw2QkFBa0IsRUFBQyxDQUFDO0lBQ3ZCLEdBQUdaLEtBQUssQ0FBQ2E7RUFDWCxDQUFDO0VBQ0QsT0FBT1ksU0FBUyxnQkFBRyxJQUFBM0IsV0FBQSxDQUFBc0IsR0FBQSxFQUFDSyxTQUFTO0lBQUEsR0FBS3pCLEtBQUs7SUFBQWtCLFFBQUEsZUFBRSxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDckIsaUJBQWlCO01BQUEsR0FBS0M7SUFBSyxDQUFHO0VBQUMsQ0FBVyxDQUFDLEdBQUdELGlCQUFpQixDQUFDQyxLQUFLLENBQUM7QUFDbEg7QUFBQzBCLEVBQUEsR0FOdUJILFVBQVU7QUFPbEMsU0FBU1Isb0JBQW9CQSxDQUFDSSxFQUFFLEVBQUVRLFNBQVMsRUFBRUMsS0FBSyxFQUFFO0VBQ2xELE1BQU0sSUFBSUMsS0FBSyxDQUFDLFdBQVcsSUFBSUYsU0FBUyxHQUFHLFdBQVcsR0FBRyxRQUFRLENBQUMsR0FBRyxJQUFJLEdBQUdSLEVBQUUsR0FBRyxvRUFBb0UsSUFBSVMsS0FBSyxHQUFHLHFDQUFxQyxHQUFHQSxLQUFLLEdBQUcsdUJBQXVCLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDalA7QUFBQyxJQUFBRixFQUFBO0FBQUFJLFlBQUEsQ0FBQUosRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}