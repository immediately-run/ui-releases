"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _vite = require("vite");
var _pluginReact = _interopRequireDefault(require("@vitejs/plugin-react"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// The source-control sidebar — a first-party immediately.run system app bound to
// the `panel.contribute` chrome region (UI_AS_APPS_SPEC §5.3; migrate-sidebars
// Phase 06). It reads the working-tree diff / branch / open-PR state over the
// elevated `vcs:read` SDK channel and drives `refreshDiff`/`refreshPRs`/
// `resetWorkingTree` (first-party `vcs:reset`) — the COW/journal + OAuth token
// stay host-side. Tests are configured in vitest.config.ts. https://vite.dev/config/
var _default = exports.default = (0, _vite.defineConfig)({
  plugins: [(0, _pluginReact.default)()]
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZSIsInJlcXVpcmUiLCJfcGx1Z2luUmVhY3QiLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiX2RlZmF1bHQiLCJleHBvcnRzIiwiZGVmaW5lQ29uZmlnIiwicGx1Z2lucyIsInJlYWN0Il0sInNvdXJjZXMiOlsidml0ZS5jb25maWcudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgZGVmaW5lQ29uZmlnIH0gZnJvbSAndml0ZSc7XG5pbXBvcnQgcmVhY3QgZnJvbSAnQHZpdGVqcy9wbHVnaW4tcmVhY3QnO1xuXG4vLyBUaGUgc291cmNlLWNvbnRyb2wgc2lkZWJhciDigJQgYSBmaXJzdC1wYXJ0eSBpbW1lZGlhdGVseS5ydW4gc3lzdGVtIGFwcCBib3VuZCB0b1xuLy8gdGhlIGBwYW5lbC5jb250cmlidXRlYCBjaHJvbWUgcmVnaW9uIChVSV9BU19BUFBTX1NQRUMgwqc1LjM7IG1pZ3JhdGUtc2lkZWJhcnNcbi8vIFBoYXNlIDA2KS4gSXQgcmVhZHMgdGhlIHdvcmtpbmctdHJlZSBkaWZmIC8gYnJhbmNoIC8gb3Blbi1QUiBzdGF0ZSBvdmVyIHRoZVxuLy8gZWxldmF0ZWQgYHZjczpyZWFkYCBTREsgY2hhbm5lbCBhbmQgZHJpdmVzIGByZWZyZXNoRGlmZmAvYHJlZnJlc2hQUnNgL1xuLy8gYHJlc2V0V29ya2luZ1RyZWVgIChmaXJzdC1wYXJ0eSBgdmNzOnJlc2V0YCkg4oCUIHRoZSBDT1cvam91cm5hbCArIE9BdXRoIHRva2VuXG4vLyBzdGF5IGhvc3Qtc2lkZS4gVGVzdHMgYXJlIGNvbmZpZ3VyZWQgaW4gdml0ZXN0LmNvbmZpZy50cy4gaHR0cHM6Ly92aXRlLmRldi9jb25maWcvXG5leHBvcnQgZGVmYXVsdCBkZWZpbmVDb25maWcoe1xuICBwbHVnaW5zOiBbcmVhY3QoKV0sXG59KTtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQUEsSUFBQUEsS0FBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsWUFBQSxHQUFBQyxzQkFBQSxDQUFBRixPQUFBO0FBQXlDLFNBQUFFLHVCQUFBQyxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBRXpDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUFBLElBQUFHLFFBQUEsR0FBQUMsT0FBQSxDQUFBRixPQUFBLEdBQ2UsSUFBQUcsa0JBQVksRUFBQztFQUMxQkMsT0FBTyxFQUFFLENBQUMsSUFBQUMsb0JBQUssRUFBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyIsImlnbm9yZUxpc3QiOltdfQ==