var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = App;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.find.js");
require("core-js/modules/esnext.iterator.map.js");
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The M2 attenuated-delegation SUB-APP (R3-43 drill 2 / M2_DELEGATION_STATUS step 4).
//
// This is the *callee* half of the live two-app fixture. It exists to prove one thing
// end to end that unit tests can only prove in pieces: that when an app invokes a task,
// the host mints the callee a **delegated** grant that is the INTERSECTION of what the
// callee requests and what the caller already holds — never more.
//
// Why the app has to actually spend the capability. It would be easy to write a fixture
// that only *declares* `net:fetch` and reports what the host told it. That proves the
// paperwork, not the authority: a delegated grant that was minted but not honoured, or
// honoured but not scoped, would both look identical. So this app performs a REAL
// `hostFetch` to the one host it declared, and reports the outcome. The three cases are
// then distinguishable from the outside:
//
//   delegated + honoured   → the fetch returns a status
//   not delegated          → the invocation never gets here (caller sees consent-required)
//   delegated but mis-scoped → a fetch to the OTHER host below fails while the first
//                              succeeds, which is what "attenuated" has to mean
//
// It holds NO standing authority of its own: everything it can reach, it can reach only
// because the caller held it first and the host narrowed it (§5.7 — data crosses, ambient
// authority does not). Its manifest asks for `net:fetch` as `required: true`, so an
// invocation by a caller lacking it must be refused BEFORE this code ever loads.
/** The host this app declares in `immediately.run.requests` — the one it may reach. */
const DECLARED_HOST = "https://example.com/";

/**
 * A host this app deliberately does NOT declare. Fetching it must fail even when the
 * caller itself holds a broader grant — that is the difference between "delegated" and
 * "inherited", and it is the whole point of attenuation. A fixture that only probed the
 * allowed host could not tell the two apart.
 */
const UNDECLARED_HOST = "https://example.org/";
const probe = async url => {
  try {
    const res = await (0, _sdk.hostFetch)(url, {
      method: "GET"
    });
    return {
      url,
      ok: true,
      detail: `HTTP ${res.status}`
    };
  } catch (e) {
    const code = e?.code;
    return {
      url,
      ok: false,
      detail: code ?? e?.message ?? "error"
    };
  }
};
function App() {
  _s();
  const input = (0, _sdk.useTaskInput)();
  const [probes, setProbes] = (0, _react.useState)(null);
  (0, _react.useEffect)(() => {
    let live = true;
    // Both probes run on mount so the result is a MEASUREMENT, not a button someone
    // forgot to press during a drill.
    Promise.all([probe(DECLARED_HOST), probe(UNDECLARED_HOST)]).then(rs => {
      if (live) setProbes(rs);
    });
    return () => {
      live = false;
    };
  }, []);
  const finish = (0, _react.useCallback)(() => {
    const declared = probes?.find(p => p.url === DECLARED_HOST);
    const undeclared = probes?.find(p => p.url === UNDECLARED_HOST);
    // The result is DATA the caller can render — never authority. The host re-validates
    // it against the `probe` contract before the caller's promise resolves.
    (0, _sdk.completeTask)({
      probed: true,
      declaredHostOk: !!declared?.ok,
      declaredDetail: declared?.detail ?? "not run",
      // `false` here is the PASS condition: reaching an undeclared host would mean the
      // delegated grant was not attenuated.
      undeclaredHostOk: !!undeclared?.ok,
      undeclaredDetail: undeclared?.detail ?? "not run"
    });
  }, [probes]);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("main", {
    style: {
      font: "14px/1.5 system-ui, sans-serif",
      padding: 24,
      maxWidth: 620
    },
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("h1", {
      style: {
        fontSize: 18,
        margin: "0 0 4px"
      },
      children: "M2 delegation probe"
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("p", {
      style: {
        opacity: 0.7,
        margin: "0 0 16px"
      },
      children: ["The callee half of the M2 live fixture", input?.label ? ` — ${input.label}` : "", ". It spends the ", /*#__PURE__*/(0, _jsxRuntime.jsx)("code", {
        children: "net:fetch"
      }), " the host delegated to it, and reports what it could and could not reach."]
    }), probes === null ? /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
      children: "probing\u2026"
    }) : /*#__PURE__*/(0, _jsxRuntime.jsx)("ul", {
      style: {
        listStyle: "none",
        padding: 0,
        margin: "0 0 16px"
      },
      children: probes.map(p => /*#__PURE__*/(0, _jsxRuntime.jsxs)("li", {
        style: {
          margin: "0 0 8px"
        },
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("code", {
          children: p.url
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("br", {}), /*#__PURE__*/(0, _jsxRuntime.jsx)("strong", {
          style: {
            color: p.ok ? "#16a34a" : "#dc2626"
          },
          children: p.ok ? "reachable" : "blocked"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
          style: {
            opacity: 0.7
          },
          children: ["(", p.detail, ")"]
        }), p.url === UNDECLARED_HOST && /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
          style: {
            opacity: 0.7
          },
          children: [" ", "\u2014 undeclared; ", /*#__PURE__*/(0, _jsxRuntime.jsx)("em", {
            children: "blocked"
          }), " is the expected result"]
        })]
      }, p.url))
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
      type: "button",
      onClick: finish,
      disabled: probes === null,
      children: "Return result to caller"
    }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
      type: "button",
      onClick: () => (0, _sdk.cancelTask)(),
      children: "Cancel"
    })]
  });
}
_s(App, "h4FAQvISIUskg95UWEFp6A+H10Q=", false, function () {
  return [_sdk.useTaskInput];
});
_c = App;
var _c;
$RefreshReg$(_c, "App");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NkayIsIl9qc3hSdW50aW1lIiwiX3MiLCIkUmVmcmVzaFNpZyQiLCJERUNMQVJFRF9IT1NUIiwiVU5ERUNMQVJFRF9IT1NUIiwicHJvYmUiLCJ1cmwiLCJyZXMiLCJob3N0RmV0Y2giLCJtZXRob2QiLCJvayIsImRldGFpbCIsInN0YXR1cyIsImUiLCJjb2RlIiwibWVzc2FnZSIsIkFwcCIsImlucHV0IiwidXNlVGFza0lucHV0IiwicHJvYmVzIiwic2V0UHJvYmVzIiwidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJsaXZlIiwiUHJvbWlzZSIsImFsbCIsInRoZW4iLCJycyIsImZpbmlzaCIsInVzZUNhbGxiYWNrIiwiZGVjbGFyZWQiLCJmaW5kIiwicCIsInVuZGVjbGFyZWQiLCJjb21wbGV0ZVRhc2siLCJwcm9iZWQiLCJkZWNsYXJlZEhvc3RPayIsImRlY2xhcmVkRGV0YWlsIiwidW5kZWNsYXJlZEhvc3RPayIsInVuZGVjbGFyZWREZXRhaWwiLCJqc3hzIiwic3R5bGUiLCJmb250IiwicGFkZGluZyIsIm1heFdpZHRoIiwiY2hpbGRyZW4iLCJqc3giLCJmb250U2l6ZSIsIm1hcmdpbiIsIm9wYWNpdHkiLCJsYWJlbCIsImxpc3RTdHlsZSIsIm1hcCIsImNvbG9yIiwidHlwZSIsIm9uQ2xpY2siLCJkaXNhYmxlZCIsImNhbmNlbFRhc2siLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkFwcC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gVGhlIE0yIGF0dGVudWF0ZWQtZGVsZWdhdGlvbiBTVUItQVBQIChSMy00MyBkcmlsbCAyIC8gTTJfREVMRUdBVElPTl9TVEFUVVMgc3RlcCA0KS5cbi8vXG4vLyBUaGlzIGlzIHRoZSAqY2FsbGVlKiBoYWxmIG9mIHRoZSBsaXZlIHR3by1hcHAgZml4dHVyZS4gSXQgZXhpc3RzIHRvIHByb3ZlIG9uZSB0aGluZ1xuLy8gZW5kIHRvIGVuZCB0aGF0IHVuaXQgdGVzdHMgY2FuIG9ubHkgcHJvdmUgaW4gcGllY2VzOiB0aGF0IHdoZW4gYW4gYXBwIGludm9rZXMgYSB0YXNrLFxuLy8gdGhlIGhvc3QgbWludHMgdGhlIGNhbGxlZSBhICoqZGVsZWdhdGVkKiogZ3JhbnQgdGhhdCBpcyB0aGUgSU5URVJTRUNUSU9OIG9mIHdoYXQgdGhlXG4vLyBjYWxsZWUgcmVxdWVzdHMgYW5kIHdoYXQgdGhlIGNhbGxlciBhbHJlYWR5IGhvbGRzIOKAlCBuZXZlciBtb3JlLlxuLy9cbi8vIFdoeSB0aGUgYXBwIGhhcyB0byBhY3R1YWxseSBzcGVuZCB0aGUgY2FwYWJpbGl0eS4gSXQgd291bGQgYmUgZWFzeSB0byB3cml0ZSBhIGZpeHR1cmVcbi8vIHRoYXQgb25seSAqZGVjbGFyZXMqIGBuZXQ6ZmV0Y2hgIGFuZCByZXBvcnRzIHdoYXQgdGhlIGhvc3QgdG9sZCBpdC4gVGhhdCBwcm92ZXMgdGhlXG4vLyBwYXBlcndvcmssIG5vdCB0aGUgYXV0aG9yaXR5OiBhIGRlbGVnYXRlZCBncmFudCB0aGF0IHdhcyBtaW50ZWQgYnV0IG5vdCBob25vdXJlZCwgb3Jcbi8vIGhvbm91cmVkIGJ1dCBub3Qgc2NvcGVkLCB3b3VsZCBib3RoIGxvb2sgaWRlbnRpY2FsLiBTbyB0aGlzIGFwcCBwZXJmb3JtcyBhIFJFQUxcbi8vIGBob3N0RmV0Y2hgIHRvIHRoZSBvbmUgaG9zdCBpdCBkZWNsYXJlZCwgYW5kIHJlcG9ydHMgdGhlIG91dGNvbWUuIFRoZSB0aHJlZSBjYXNlcyBhcmVcbi8vIHRoZW4gZGlzdGluZ3Vpc2hhYmxlIGZyb20gdGhlIG91dHNpZGU6XG4vL1xuLy8gICBkZWxlZ2F0ZWQgKyBob25vdXJlZCAgIOKGkiB0aGUgZmV0Y2ggcmV0dXJucyBhIHN0YXR1c1xuLy8gICBub3QgZGVsZWdhdGVkICAgICAgICAgIOKGkiB0aGUgaW52b2NhdGlvbiBuZXZlciBnZXRzIGhlcmUgKGNhbGxlciBzZWVzIGNvbnNlbnQtcmVxdWlyZWQpXG4vLyAgIGRlbGVnYXRlZCBidXQgbWlzLXNjb3BlZCDihpIgYSBmZXRjaCB0byB0aGUgT1RIRVIgaG9zdCBiZWxvdyBmYWlscyB3aGlsZSB0aGUgZmlyc3Rcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3VjY2VlZHMsIHdoaWNoIGlzIHdoYXQgXCJhdHRlbnVhdGVkXCIgaGFzIHRvIG1lYW5cbi8vXG4vLyBJdCBob2xkcyBOTyBzdGFuZGluZyBhdXRob3JpdHkgb2YgaXRzIG93bjogZXZlcnl0aGluZyBpdCBjYW4gcmVhY2gsIGl0IGNhbiByZWFjaCBvbmx5XG4vLyBiZWNhdXNlIHRoZSBjYWxsZXIgaGVsZCBpdCBmaXJzdCBhbmQgdGhlIGhvc3QgbmFycm93ZWQgaXQgKMKnNS43IOKAlCBkYXRhIGNyb3NzZXMsIGFtYmllbnRcbi8vIGF1dGhvcml0eSBkb2VzIG5vdCkuIEl0cyBtYW5pZmVzdCBhc2tzIGZvciBgbmV0OmZldGNoYCBhcyBgcmVxdWlyZWQ6IHRydWVgLCBzbyBhblxuLy8gaW52b2NhdGlvbiBieSBhIGNhbGxlciBsYWNraW5nIGl0IG11c3QgYmUgcmVmdXNlZCBCRUZPUkUgdGhpcyBjb2RlIGV2ZXIgbG9hZHMuXG5pbXBvcnQgeyB1c2VDYWxsYmFjaywgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgY29tcGxldGVUYXNrLCBjYW5jZWxUYXNrLCBob3N0RmV0Y2gsIHVzZVRhc2tJbnB1dCB9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nka1wiO1xuXG4vKiogVGhlIGhvc3QgdGhpcyBhcHAgZGVjbGFyZXMgaW4gYGltbWVkaWF0ZWx5LnJ1bi5yZXF1ZXN0c2Ag4oCUIHRoZSBvbmUgaXQgbWF5IHJlYWNoLiAqL1xuY29uc3QgREVDTEFSRURfSE9TVCA9IFwiaHR0cHM6Ly9leGFtcGxlLmNvbS9cIjtcblxuLyoqXG4gKiBBIGhvc3QgdGhpcyBhcHAgZGVsaWJlcmF0ZWx5IGRvZXMgTk9UIGRlY2xhcmUuIEZldGNoaW5nIGl0IG11c3QgZmFpbCBldmVuIHdoZW4gdGhlXG4gKiBjYWxsZXIgaXRzZWxmIGhvbGRzIGEgYnJvYWRlciBncmFudCDigJQgdGhhdCBpcyB0aGUgZGlmZmVyZW5jZSBiZXR3ZWVuIFwiZGVsZWdhdGVkXCIgYW5kXG4gKiBcImluaGVyaXRlZFwiLCBhbmQgaXQgaXMgdGhlIHdob2xlIHBvaW50IG9mIGF0dGVudWF0aW9uLiBBIGZpeHR1cmUgdGhhdCBvbmx5IHByb2JlZCB0aGVcbiAqIGFsbG93ZWQgaG9zdCBjb3VsZCBub3QgdGVsbCB0aGUgdHdvIGFwYXJ0LlxuICovXG5jb25zdCBVTkRFQ0xBUkVEX0hPU1QgPSBcImh0dHBzOi8vZXhhbXBsZS5vcmcvXCI7XG5cbnR5cGUgUHJvYmUgPSB7IHVybDogc3RyaW5nOyBvazogYm9vbGVhbjsgZGV0YWlsOiBzdHJpbmcgfTtcblxuY29uc3QgcHJvYmUgPSBhc3luYyAodXJsOiBzdHJpbmcpOiBQcm9taXNlPFByb2JlPiA9PiB7XG4gIHRyeSB7XG4gICAgY29uc3QgcmVzID0gYXdhaXQgaG9zdEZldGNoKHVybCwgeyBtZXRob2Q6IFwiR0VUXCIgfSk7XG4gICAgcmV0dXJuIHsgdXJsLCBvazogdHJ1ZSwgZGV0YWlsOiBgSFRUUCAke3Jlcy5zdGF0dXN9YCB9O1xuICB9IGNhdGNoIChlKSB7XG4gICAgY29uc3QgY29kZSA9IChlIGFzIHsgY29kZT86IHN0cmluZyB9KT8uY29kZTtcbiAgICByZXR1cm4geyB1cmwsIG9rOiBmYWxzZSwgZGV0YWlsOiBjb2RlID8/IChlIGFzIEVycm9yKT8ubWVzc2FnZSA/PyBcImVycm9yXCIgfTtcbiAgfVxufTtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQXBwKCkge1xuICBjb25zdCBpbnB1dCA9IHVzZVRhc2tJbnB1dCgpIGFzIHsgbGFiZWw/OiBzdHJpbmcgfSB8IG51bGw7XG4gIGNvbnN0IFtwcm9iZXMsIHNldFByb2Jlc10gPSB1c2VTdGF0ZTxQcm9iZVtdIHwgbnVsbD4obnVsbCk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBsZXQgbGl2ZSA9IHRydWU7XG4gICAgLy8gQm90aCBwcm9iZXMgcnVuIG9uIG1vdW50IHNvIHRoZSByZXN1bHQgaXMgYSBNRUFTVVJFTUVOVCwgbm90IGEgYnV0dG9uIHNvbWVvbmVcbiAgICAvLyBmb3Jnb3QgdG8gcHJlc3MgZHVyaW5nIGEgZHJpbGwuXG4gICAgUHJvbWlzZS5hbGwoW3Byb2JlKERFQ0xBUkVEX0hPU1QpLCBwcm9iZShVTkRFQ0xBUkVEX0hPU1QpXSkudGhlbigocnMpID0+IHtcbiAgICAgIGlmIChsaXZlKSBzZXRQcm9iZXMocnMpO1xuICAgIH0pO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBsaXZlID0gZmFsc2U7XG4gICAgfTtcbiAgfSwgW10pO1xuXG4gIGNvbnN0IGZpbmlzaCA9IHVzZUNhbGxiYWNrKCgpID0+IHtcbiAgICBjb25zdCBkZWNsYXJlZCA9IHByb2Jlcz8uZmluZCgocCkgPT4gcC51cmwgPT09IERFQ0xBUkVEX0hPU1QpO1xuICAgIGNvbnN0IHVuZGVjbGFyZWQgPSBwcm9iZXM/LmZpbmQoKHApID0+IHAudXJsID09PSBVTkRFQ0xBUkVEX0hPU1QpO1xuICAgIC8vIFRoZSByZXN1bHQgaXMgREFUQSB0aGUgY2FsbGVyIGNhbiByZW5kZXIg4oCUIG5ldmVyIGF1dGhvcml0eS4gVGhlIGhvc3QgcmUtdmFsaWRhdGVzXG4gICAgLy8gaXQgYWdhaW5zdCB0aGUgYHByb2JlYCBjb250cmFjdCBiZWZvcmUgdGhlIGNhbGxlcidzIHByb21pc2UgcmVzb2x2ZXMuXG4gICAgY29tcGxldGVUYXNrKHtcbiAgICAgIHByb2JlZDogdHJ1ZSxcbiAgICAgIGRlY2xhcmVkSG9zdE9rOiAhIWRlY2xhcmVkPy5vayxcbiAgICAgIGRlY2xhcmVkRGV0YWlsOiBkZWNsYXJlZD8uZGV0YWlsID8/IFwibm90IHJ1blwiLFxuICAgICAgLy8gYGZhbHNlYCBoZXJlIGlzIHRoZSBQQVNTIGNvbmRpdGlvbjogcmVhY2hpbmcgYW4gdW5kZWNsYXJlZCBob3N0IHdvdWxkIG1lYW4gdGhlXG4gICAgICAvLyBkZWxlZ2F0ZWQgZ3JhbnQgd2FzIG5vdCBhdHRlbnVhdGVkLlxuICAgICAgdW5kZWNsYXJlZEhvc3RPazogISF1bmRlY2xhcmVkPy5vayxcbiAgICAgIHVuZGVjbGFyZWREZXRhaWw6IHVuZGVjbGFyZWQ/LmRldGFpbCA/PyBcIm5vdCBydW5cIixcbiAgICB9KTtcbiAgfSwgW3Byb2Jlc10pO1xuXG4gIHJldHVybiAoXG4gICAgPG1haW4gc3R5bGU9e3sgZm9udDogXCIxNHB4LzEuNSBzeXN0ZW0tdWksIHNhbnMtc2VyaWZcIiwgcGFkZGluZzogMjQsIG1heFdpZHRoOiA2MjAgfX0+XG4gICAgICA8aDEgc3R5bGU9e3sgZm9udFNpemU6IDE4LCBtYXJnaW46IFwiMCAwIDRweFwiIH19Pk0yIGRlbGVnYXRpb24gcHJvYmU8L2gxPlxuICAgICAgPHAgc3R5bGU9e3sgb3BhY2l0eTogMC43LCBtYXJnaW46IFwiMCAwIDE2cHhcIiB9fT5cbiAgICAgICAgVGhlIGNhbGxlZSBoYWxmIG9mIHRoZSBNMiBsaXZlIGZpeHR1cmV7aW5wdXQ/LmxhYmVsID8gYCDigJQgJHtpbnB1dC5sYWJlbH1gIDogXCJcIn0uIEl0XG4gICAgICAgIHNwZW5kcyB0aGUgPGNvZGU+bmV0OmZldGNoPC9jb2RlPiB0aGUgaG9zdCBkZWxlZ2F0ZWQgdG8gaXQsIGFuZCByZXBvcnRzIHdoYXQgaXRcbiAgICAgICAgY291bGQgYW5kIGNvdWxkIG5vdCByZWFjaC5cbiAgICAgIDwvcD5cblxuICAgICAge3Byb2JlcyA9PT0gbnVsbCA/IChcbiAgICAgICAgPHA+cHJvYmluZ+KApjwvcD5cbiAgICAgICkgOiAoXG4gICAgICAgIDx1bCBzdHlsZT17eyBsaXN0U3R5bGU6IFwibm9uZVwiLCBwYWRkaW5nOiAwLCBtYXJnaW46IFwiMCAwIDE2cHhcIiB9fT5cbiAgICAgICAgICB7cHJvYmVzLm1hcCgocCkgPT4gKFxuICAgICAgICAgICAgPGxpIGtleT17cC51cmx9IHN0eWxlPXt7IG1hcmdpbjogXCIwIDAgOHB4XCIgfX0+XG4gICAgICAgICAgICAgIDxjb2RlPntwLnVybH08L2NvZGU+XG4gICAgICAgICAgICAgIDxiciAvPlxuICAgICAgICAgICAgICA8c3Ryb25nIHN0eWxlPXt7IGNvbG9yOiBwLm9rID8gXCIjMTZhMzRhXCIgOiBcIiNkYzI2MjZcIiB9fT5cbiAgICAgICAgICAgICAgICB7cC5vayA/IFwicmVhY2hhYmxlXCIgOiBcImJsb2NrZWRcIn1cbiAgICAgICAgICAgICAgPC9zdHJvbmc+e1wiIFwifVxuICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBvcGFjaXR5OiAwLjcgfX0+KHtwLmRldGFpbH0pPC9zcGFuPlxuICAgICAgICAgICAgICB7cC51cmwgPT09IFVOREVDTEFSRURfSE9TVCAmJiAoXG4gICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgb3BhY2l0eTogMC43IH19PlxuICAgICAgICAgICAgICAgICAge1wiIFwifVxuICAgICAgICAgICAgICAgICAg4oCUIHVuZGVjbGFyZWQ7IDxlbT5ibG9ja2VkPC9lbT4gaXMgdGhlIGV4cGVjdGVkIHJlc3VsdFxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvdWw+XG4gICAgICApfVxuXG4gICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXtmaW5pc2h9IGRpc2FibGVkPXtwcm9iZXMgPT09IG51bGx9PlxuICAgICAgICBSZXR1cm4gcmVzdWx0IHRvIGNhbGxlclxuICAgICAgPC9idXR0b24+e1wiIFwifVxuICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gY2FuY2VsVGFzaygpfT5cbiAgICAgICAgQ2FuY2VsXG4gICAgICA8L2J1dHRvbj5cbiAgICA8L21haW4+XG4gICk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQXVCQSxJQUFBQSxNQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxJQUFBLEdBQUFELE9BQUE7QUFBeUYsSUFBQUUsV0FBQSxHQUFBRixPQUFBO0FBQUEsSUFBQUcsRUFBQSxHQUFBQyxZQUFBLElBeEJ6RjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSUE7QUFDQSxNQUFNQyxhQUFhLEdBQUcsc0JBQXNCOztBQUU1QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNQyxlQUFlLEdBQUcsc0JBQXNCO0FBSTlDLE1BQU1DLEtBQUssR0FBRyxNQUFPQyxHQUFXLElBQXFCO0VBQ25ELElBQUk7SUFDRixNQUFNQyxHQUFHLEdBQUcsTUFBTSxJQUFBQyxjQUFTLEVBQUNGLEdBQUcsRUFBRTtNQUFFRyxNQUFNLEVBQUU7SUFBTSxDQUFDLENBQUM7SUFDbkQsT0FBTztNQUFFSCxHQUFHO01BQUVJLEVBQUUsRUFBRSxJQUFJO01BQUVDLE1BQU0sRUFBRSxRQUFRSixHQUFHLENBQUNLLE1BQU07SUFBRyxDQUFDO0VBQ3hELENBQUMsQ0FBQyxPQUFPQyxDQUFDLEVBQUU7SUFDVixNQUFNQyxJQUFJLEdBQUlELENBQUMsRUFBd0JDLElBQUk7SUFDM0MsT0FBTztNQUFFUixHQUFHO01BQUVJLEVBQUUsRUFBRSxLQUFLO01BQUVDLE1BQU0sRUFBRUcsSUFBSSxJQUFLRCxDQUFDLEVBQVlFLE9BQU8sSUFBSTtJQUFRLENBQUM7RUFDN0U7QUFDRixDQUFDO0FBRWMsU0FBU0MsR0FBR0EsQ0FBQSxFQUFHO0VBQUFmLEVBQUE7RUFDNUIsTUFBTWdCLEtBQUssR0FBRyxJQUFBQyxpQkFBWSxFQUFDLENBQThCO0VBQ3pELE1BQU0sQ0FBQ0MsTUFBTSxFQUFFQyxTQUFTLENBQUMsR0FBRyxJQUFBQyxlQUFRLEVBQWlCLElBQUksQ0FBQztFQUUxRCxJQUFBQyxnQkFBUyxFQUFDLE1BQU07SUFDZCxJQUFJQyxJQUFJLEdBQUcsSUFBSTtJQUNmO0lBQ0E7SUFDQUMsT0FBTyxDQUFDQyxHQUFHLENBQUMsQ0FBQ3BCLEtBQUssQ0FBQ0YsYUFBYSxDQUFDLEVBQUVFLEtBQUssQ0FBQ0QsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDc0IsSUFBSSxDQUFFQyxFQUFFLElBQUs7TUFDdkUsSUFBSUosSUFBSSxFQUFFSCxTQUFTLENBQUNPLEVBQUUsQ0FBQztJQUN6QixDQUFDLENBQUM7SUFDRixPQUFPLE1BQU07TUFDWEosSUFBSSxHQUFHLEtBQUs7SUFDZCxDQUFDO0VBQ0gsQ0FBQyxFQUFFLEVBQUUsQ0FBQztFQUVOLE1BQU1LLE1BQU0sR0FBRyxJQUFBQyxrQkFBVyxFQUFDLE1BQU07SUFDL0IsTUFBTUMsUUFBUSxHQUFHWCxNQUFNLEVBQUVZLElBQUksQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUMxQixHQUFHLEtBQUtILGFBQWEsQ0FBQztJQUM3RCxNQUFNOEIsVUFBVSxHQUFHZCxNQUFNLEVBQUVZLElBQUksQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUMxQixHQUFHLEtBQUtGLGVBQWUsQ0FBQztJQUNqRTtJQUNBO0lBQ0EsSUFBQThCLGlCQUFZLEVBQUM7TUFDWEMsTUFBTSxFQUFFLElBQUk7TUFDWkMsY0FBYyxFQUFFLENBQUMsQ0FBQ04sUUFBUSxFQUFFcEIsRUFBRTtNQUM5QjJCLGNBQWMsRUFBRVAsUUFBUSxFQUFFbkIsTUFBTSxJQUFJLFNBQVM7TUFDN0M7TUFDQTtNQUNBMkIsZ0JBQWdCLEVBQUUsQ0FBQyxDQUFDTCxVQUFVLEVBQUV2QixFQUFFO01BQ2xDNkIsZ0JBQWdCLEVBQUVOLFVBQVUsRUFBRXRCLE1BQU0sSUFBSTtJQUMxQyxDQUFDLENBQUM7RUFDSixDQUFDLEVBQUUsQ0FBQ1EsTUFBTSxDQUFDLENBQUM7RUFFWixvQkFDRSxJQUFBbkIsV0FBQSxDQUFBd0MsSUFBQTtJQUFNQyxLQUFLLEVBQUU7TUFBRUMsSUFBSSxFQUFFLGdDQUFnQztNQUFFQyxPQUFPLEVBQUUsRUFBRTtNQUFFQyxRQUFRLEVBQUU7SUFBSSxDQUFFO0lBQUFDLFFBQUEsZ0JBQ2xGLElBQUE3QyxXQUFBLENBQUE4QyxHQUFBO01BQUlMLEtBQUssRUFBRTtRQUFFTSxRQUFRLEVBQUUsRUFBRTtRQUFFQyxNQUFNLEVBQUU7TUFBVSxDQUFFO01BQUFILFFBQUEsRUFBQztJQUFtQixDQUFJLENBQUMsZUFDeEUsSUFBQTdDLFdBQUEsQ0FBQXdDLElBQUE7TUFBR0MsS0FBSyxFQUFFO1FBQUVRLE9BQU8sRUFBRSxHQUFHO1FBQUVELE1BQU0sRUFBRTtNQUFXLENBQUU7TUFBQUgsUUFBQSxHQUFDLHdDQUNSLEVBQUM1QixLQUFLLEVBQUVpQyxLQUFLLEdBQUcsTUFBTWpDLEtBQUssQ0FBQ2lDLEtBQUssRUFBRSxHQUFHLEVBQUUsRUFBQyxrQkFDcEUsbUJBQUFsRCxXQUFBLENBQUE4QyxHQUFBO1FBQUFELFFBQUEsRUFBTTtNQUFTLENBQU0sQ0FBQyw2RUFFbkM7SUFBQSxDQUFHLENBQUMsRUFFSDFCLE1BQU0sS0FBSyxJQUFJLGdCQUNkLElBQUFuQixXQUFBLENBQUE4QyxHQUFBO01BQUFELFFBQUEsRUFBRztJQUFRLENBQUcsQ0FBQyxnQkFFZixJQUFBN0MsV0FBQSxDQUFBOEMsR0FBQTtNQUFJTCxLQUFLLEVBQUU7UUFBRVUsU0FBUyxFQUFFLE1BQU07UUFBRVIsT0FBTyxFQUFFLENBQUM7UUFBRUssTUFBTSxFQUFFO01BQVcsQ0FBRTtNQUFBSCxRQUFBLEVBQzlEMUIsTUFBTSxDQUFDaUMsR0FBRyxDQUFFcEIsQ0FBQyxpQkFDWixJQUFBaEMsV0FBQSxDQUFBd0MsSUFBQTtRQUFnQkMsS0FBSyxFQUFFO1VBQUVPLE1BQU0sRUFBRTtRQUFVLENBQUU7UUFBQUgsUUFBQSxnQkFDM0MsSUFBQTdDLFdBQUEsQ0FBQThDLEdBQUE7VUFBQUQsUUFBQSxFQUFPYixDQUFDLENBQUMxQjtRQUFHLENBQU8sQ0FBQyxlQUNwQixJQUFBTixXQUFBLENBQUE4QyxHQUFBLFVBQUssQ0FBQyxlQUNOLElBQUE5QyxXQUFBLENBQUE4QyxHQUFBO1VBQVFMLEtBQUssRUFBRTtZQUFFWSxLQUFLLEVBQUVyQixDQUFDLENBQUN0QixFQUFFLEdBQUcsU0FBUyxHQUFHO1VBQVUsQ0FBRTtVQUFBbUMsUUFBQSxFQUNwRGIsQ0FBQyxDQUFDdEIsRUFBRSxHQUFHLFdBQVcsR0FBRztRQUFTLENBQ3pCLENBQUMsRUFBQyxHQUFHLGVBQ2IsSUFBQVYsV0FBQSxDQUFBd0MsSUFBQTtVQUFNQyxLQUFLLEVBQUU7WUFBRVEsT0FBTyxFQUFFO1VBQUksQ0FBRTtVQUFBSixRQUFBLEdBQUMsR0FBQyxFQUFDYixDQUFDLENBQUNyQixNQUFNLEVBQUMsR0FBQztRQUFBLENBQU0sQ0FBQyxFQUNqRHFCLENBQUMsQ0FBQzFCLEdBQUcsS0FBS0YsZUFBZSxpQkFDeEIsSUFBQUosV0FBQSxDQUFBd0MsSUFBQTtVQUFNQyxLQUFLLEVBQUU7WUFBRVEsT0FBTyxFQUFFO1VBQUksQ0FBRTtVQUFBSixRQUFBLEdBQzNCLEdBQUcsRUFBQyxxQkFDUyxtQkFBQTdDLFdBQUEsQ0FBQThDLEdBQUE7WUFBQUQsUUFBQSxFQUFJO1VBQU8sQ0FBSSxDQUFDLDJCQUNoQztRQUFBLENBQU0sQ0FDUDtNQUFBLEdBWk1iLENBQUMsQ0FBQzFCLEdBYVAsQ0FDTDtJQUFDLENBQ0EsQ0FDTCxlQUVELElBQUFOLFdBQUEsQ0FBQThDLEdBQUE7TUFBUVEsSUFBSSxFQUFDLFFBQVE7TUFBQ0MsT0FBTyxFQUFFM0IsTUFBTztNQUFDNEIsUUFBUSxFQUFFckMsTUFBTSxLQUFLLElBQUs7TUFBQTBCLFFBQUEsRUFBQztJQUVsRSxDQUFRLENBQUMsRUFBQyxHQUFHLGVBQ2IsSUFBQTdDLFdBQUEsQ0FBQThDLEdBQUE7TUFBUVEsSUFBSSxFQUFDLFFBQVE7TUFBQ0MsT0FBTyxFQUFFQSxDQUFBLEtBQU0sSUFBQUUsZUFBVSxFQUFDLENBQUU7TUFBQVosUUFBQSxFQUFDO0lBRW5ELENBQVEsQ0FBQztFQUFBLENBQ0wsQ0FBQztBQUVYO0FBQUM1QyxFQUFBLENBeEV1QmUsR0FBRztFQUFBLFFBQ1hFLGlCQUFZO0FBQUE7QUFBQXdDLEVBQUEsR0FESjFDLEdBQUc7QUFBQSxJQUFBMEMsRUFBQTtBQUFBQyxZQUFBLENBQUFELEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}