var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      code: "code",
      h1: "h1",
      p: "p",
      strong: "strong",
      table: "table",
      tbody: "tbody",
      td: "td",
      th: "th",
      thead: "thead",
      tr: "tr",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "sec-m2",
      "data-slug": "m2-subapp-the-callee-half-of-the-m2-delegation-fixture",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-m2"
      }), "m2-subapp — the callee half of the M2 delegation fixture"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["This branch is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "not"
      }), " the greeting library. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "greeting-lib@main"
      }), " is a tiny library used by\nthe R3-146 host-mediated library-mount check and is untouched; this branch reuses the repo\nto host a second, unrelated fixture so no new repository had to be created."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["It is the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "callee"
      }), " in the M2 attenuated-delegation live fixture\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "M2_DELEGATION_STATUS"
      }), " step 4, driven by roadmap item R3-43 drill 2). Another app\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "agent-demo"
      }), ") invokes it with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "invokeTask(\"probe\", …)"
      }), "; the host mints this app a\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "delegated"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "net:fetch"
      }), " grant that is the intersection of what this app declares and\nwhat the caller already holds."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["It then ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "spends"
      }), " that capability rather than just reporting it, because a grant that was\nminted but not honoured and one that was honoured but not scoped look identical from the\noutside. It fetches:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "host"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "declared?"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "expected"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "https://example.com"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "yes"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "reachable"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "https://example.org"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "no"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "blocked"
            }), " — this is the attenuation check"]
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Reaching the undeclared host would mean the delegated grant was inherited rather than\nattenuated, which is the failure this fixture exists to catch."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "requests.\"net:fetch\""
      }), " is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "required: true"
      }), ", so an invocation by a caller that does not\nitself hold a covering grant must be refused with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "consent-required"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "before this code\nloads at all"
      }), " — the negative leg of the drill."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Durable fixture: do not delete this branch."
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/README.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJjb2RlIiwiaDEiLCJwIiwic3Ryb25nIiwidGFibGUiLCJ0Ym9keSIsInRkIiwidGgiLCJ0aGVhZCIsInRyIiwiX3Byb3ZpZGVDb21wb25lbnRzIiwiY29tcG9uZW50cyIsIkhlYWRpbmdBbmNob3IiLCJfbWlzc2luZ01keFJlZmVyZW5jZSIsImpzeHMiLCJGcmFnbWVudCIsImNoaWxkcmVuIiwiaWQiLCJqc3giLCJNRFhDb250ZW50Iiwid3JhcHBlciIsIk1EWExheW91dCIsIl9jIiwiY29tcG9uZW50IiwicGxhY2UiLCJFcnJvciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlJFQURNRS5tZCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKkBqc3hSdW50aW1lIGF1dG9tYXRpYyovXG4vKkBqc3hJbXBvcnRTb3VyY2UgcmVhY3QqL1xuaW1wb3J0IHt1c2VNRFhDb21wb25lbnRzIGFzIF9wcm92aWRlQ29tcG9uZW50c30gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrL01EWFByb3ZpZGVyXCI7XG5mdW5jdGlvbiBfY3JlYXRlTWR4Q29udGVudChwcm9wcykge1xuICBjb25zdCBfY29tcG9uZW50cyA9IHtcbiAgICBjb2RlOiBcImNvZGVcIixcbiAgICBoMTogXCJoMVwiLFxuICAgIHA6IFwicFwiLFxuICAgIHN0cm9uZzogXCJzdHJvbmdcIixcbiAgICB0YWJsZTogXCJ0YWJsZVwiLFxuICAgIHRib2R5OiBcInRib2R5XCIsXG4gICAgdGQ6IFwidGRcIixcbiAgICB0aDogXCJ0aFwiLFxuICAgIHRoZWFkOiBcInRoZWFkXCIsXG4gICAgdHI6IFwidHJcIixcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH0sIHtIZWFkaW5nQW5jaG9yfSA9IF9jb21wb25lbnRzO1xuICBpZiAoIUhlYWRpbmdBbmNob3IpIF9taXNzaW5nTWR4UmVmZXJlbmNlKFwiSGVhZGluZ0FuY2hvclwiLCB0cnVlKTtcbiAgcmV0dXJuIDw+PF9jb21wb25lbnRzLmgxIGlkPVwic2VjLW0yXCIgZGF0YS1zbHVnPVwibTItc3ViYXBwLXRoZS1jYWxsZWUtaGFsZi1vZi10aGUtbTItZGVsZWdhdGlvbi1maXh0dXJlXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtbTJcIiAvPntcIm0yLXN1YmFwcCDigJQgdGhlIGNhbGxlZSBoYWxmIG9mIHRoZSBNMiBkZWxlZ2F0aW9uIGZpeHR1cmVcIn08L19jb21wb25lbnRzLmgxPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoaXMgYnJhbmNoIGlzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibm90XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHRoZSBncmVldGluZyBsaWJyYXJ5LiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJncmVldGluZy1saWJAbWFpblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaXMgYSB0aW55IGxpYnJhcnkgdXNlZCBieVxcbnRoZSBSMy0xNDYgaG9zdC1tZWRpYXRlZCBsaWJyYXJ5LW1vdW50IGNoZWNrIGFuZCBpcyB1bnRvdWNoZWQ7IHRoaXMgYnJhbmNoIHJldXNlcyB0aGUgcmVwb1xcbnRvIGhvc3QgYSBzZWNvbmQsIHVucmVsYXRlZCBmaXh0dXJlIHNvIG5vIG5ldyByZXBvc2l0b3J5IGhhZCB0byBiZSBjcmVhdGVkLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJJdCBpcyB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJjYWxsZWVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgaW4gdGhlIE0yIGF0dGVudWF0ZWQtZGVsZWdhdGlvbiBsaXZlIGZpeHR1cmVcXG4oXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiTTJfREVMRUdBVElPTl9TVEFUVVNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHN0ZXAgNCwgZHJpdmVuIGJ5IHJvYWRtYXAgaXRlbSBSMy00MyBkcmlsbCAyKS4gQW5vdGhlciBhcHBcXG4oXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYWdlbnQtZGVtb1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpIGludm9rZXMgaXQgd2l0aCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJpbnZva2VUYXNrKFxcXCJwcm9iZVxcXCIsIOKApilcIn08L19jb21wb25lbnRzLmNvZGU+e1wiOyB0aGUgaG9zdCBtaW50cyB0aGlzIGFwcCBhXFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJkZWxlZ2F0ZWRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibmV0OmZldGNoXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBncmFudCB0aGF0IGlzIHRoZSBpbnRlcnNlY3Rpb24gb2Ygd2hhdCB0aGlzIGFwcCBkZWNsYXJlcyBhbmRcXG53aGF0IHRoZSBjYWxsZXIgYWxyZWFkeSBob2xkcy5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiSXQgdGhlbiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInNwZW5kc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB0aGF0IGNhcGFiaWxpdHkgcmF0aGVyIHRoYW4ganVzdCByZXBvcnRpbmcgaXQsIGJlY2F1c2UgYSBncmFudCB0aGF0IHdhc1xcbm1pbnRlZCBidXQgbm90IGhvbm91cmVkIGFuZCBvbmUgdGhhdCB3YXMgaG9ub3VyZWQgYnV0IG5vdCBzY29wZWQgbG9vayBpZGVudGljYWwgZnJvbSB0aGVcXG5vdXRzaWRlLiBJdCBmZXRjaGVzOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudGFibGU+PF9jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGg+e1wiaG9zdFwifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcImRlY2xhcmVkP1wifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcImV4cGVjdGVkXCJ9PC9fY29tcG9uZW50cy50aD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGhlYWQ+PF9jb21wb25lbnRzLnRib2R5PjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiaHR0cHM6Ly9leGFtcGxlLmNvbVwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJ5ZXNcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJyZWFjaGFibGVcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJodHRwczovL2V4YW1wbGUub3JnXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wibm9cIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcImJsb2NrZWRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHRoaXMgaXMgdGhlIGF0dGVudWF0aW9uIGNoZWNrXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGJvZHk+PC9fY29tcG9uZW50cy50YWJsZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJSZWFjaGluZyB0aGUgdW5kZWNsYXJlZCBob3N0IHdvdWxkIG1lYW4gdGhlIGRlbGVnYXRlZCBncmFudCB3YXMgaW5oZXJpdGVkIHJhdGhlciB0aGFuXFxuYXR0ZW51YXRlZCwgd2hpY2ggaXMgdGhlIGZhaWx1cmUgdGhpcyBmaXh0dXJlIGV4aXN0cyB0byBjYXRjaC5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLmNvZGU+e1wicmVxdWVzdHMuXFxcIm5ldDpmZXRjaFxcXCJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGlzIFwifTxfY29tcG9uZW50cy5jb2RlPntcInJlcXVpcmVkOiB0cnVlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgc28gYW4gaW52b2NhdGlvbiBieSBhIGNhbGxlciB0aGF0IGRvZXMgbm90XFxuaXRzZWxmIGhvbGQgYSBjb3ZlcmluZyBncmFudCBtdXN0IGJlIHJlZnVzZWQgd2l0aCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjb25zZW50LXJlcXVpcmVkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImJlZm9yZSB0aGlzIGNvZGVcXG5sb2FkcyBhdCBhbGxcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHRoZSBuZWdhdGl2ZSBsZWcgb2YgdGhlIGRyaWxsLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJEdXJhYmxlIGZpeHR1cmU6IGRvIG5vdCBkZWxldGUgdGhpcyBicmFuY2guXCJ9PC9fY29tcG9uZW50cy5wPjwvPjtcbn1cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE1EWENvbnRlbnQocHJvcHMgPSB7fSkge1xuICBjb25zdCB7d3JhcHBlcjogTURYTGF5b3V0fSA9IHtcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH07XG4gIHJldHVybiBNRFhMYXlvdXQgPyA8TURYTGF5b3V0IHsuLi5wcm9wc30+PF9jcmVhdGVNZHhDb250ZW50IHsuLi5wcm9wc30gLz48L01EWExheW91dD4gOiBfY3JlYXRlTWR4Q29udGVudChwcm9wcyk7XG59XG5mdW5jdGlvbiBfbWlzc2luZ01keFJlZmVyZW5jZShpZCwgY29tcG9uZW50LCBwbGFjZSkge1xuICB0aHJvdyBuZXcgRXJyb3IoXCJFeHBlY3RlZCBcIiArIChjb21wb25lbnQgPyBcImNvbXBvbmVudFwiIDogXCJvYmplY3RcIikgKyBcIiBgXCIgKyBpZCArIFwiYCB0byBiZSBkZWZpbmVkOiB5b3UgbGlrZWx5IGZvcmdvdCB0byBpbXBvcnQsIHBhc3MsIG9yIHByb3ZpZGUgaXQuXCIgKyAocGxhY2UgPyBcIlxcbkl04oCZcyByZWZlcmVuY2VkIGluIHlvdXIgY29kZSBhdCBgXCIgKyBwbGFjZSArIFwiYCBpbiBgL2FwcC9SRUFETUUubWRgXCIgOiBcIlwiKSk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUVBLElBQUFBLFlBQUEsR0FBQUMsT0FBQTtBQUF3RixJQUFBQyxXQUFBLEdBQUFELE9BQUE7QUFGeEY7QUFDQTs7QUFFQSxTQUFTRSxpQkFBaUJBLENBQUNDLEtBQUssRUFBRTtFQUNoQyxNQUFNQyxXQUFXLEdBQUc7TUFDbEJDLElBQUksRUFBRSxNQUFNO01BQ1pDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLENBQUMsRUFBRSxHQUFHO01BQ05DLE1BQU0sRUFBRSxRQUFRO01BQ2hCQyxLQUFLLEVBQUUsT0FBTztNQUNkQyxLQUFLLEVBQUUsT0FBTztNQUNkQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxLQUFLLEVBQUUsT0FBTztNQUNkQyxFQUFFLEVBQUUsSUFBSTtNQUNSLEdBQUcsSUFBQUMsNkJBQWtCLEVBQUMsQ0FBQztNQUN2QixHQUFHWixLQUFLLENBQUNhO0lBQ1gsQ0FBQztJQUFFO01BQUNDO0lBQWEsQ0FBQyxHQUFHYixXQUFXO0VBQ2hDLElBQUksQ0FBQ2EsYUFBYSxFQUFFQyxvQkFBb0IsQ0FBQyxlQUFlLEVBQUUsSUFBSSxDQUFDO0VBQy9ELG9CQUFPLElBQUFqQixXQUFBLENBQUFrQixJQUFBLEVBQUFsQixXQUFBLENBQUFtQixRQUFBO0lBQUFDLFFBQUEsZ0JBQUUsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDRSxFQUFFO01BQUNnQixFQUFFLEVBQUMsUUFBUTtNQUFDLGFBQVUsd0RBQXdEO01BQUFELFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBUSxDQUFFLENBQUMsRUFBQywwREFBMEQ7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ0csQ0FBQztNQUFBYyxRQUFBLEdBQUUsaUJBQWlCLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0ksTUFBTTtRQUFBYSxRQUFBLEVBQUU7TUFBSyxDQUFxQixDQUFDLEVBQUMseUJBQXlCLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQW1CLENBQW1CLENBQUMsRUFBQyxxTUFBcU07SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ0csQ0FBQztNQUFBYyxRQUFBLEdBQUUsWUFBWSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNJLE1BQU07UUFBQWEsUUFBQSxFQUFFO01BQVEsQ0FBcUIsQ0FBQyxFQUFDLGtEQUFrRCxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFzQixDQUFtQixDQUFDLEVBQUMsZ0VBQWdFLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQVksQ0FBbUIsQ0FBQyxFQUFDLG9CQUFvQixlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUEwQixDQUFtQixDQUFDLEVBQUMsK0JBQStCLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0ksTUFBTTtRQUFBYSxRQUFBLEVBQUU7TUFBVyxDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFXLENBQW1CLENBQUMsRUFBQywrRkFBK0Y7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ0csQ0FBQztNQUFBYyxRQUFBLEdBQUUsVUFBVSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNJLE1BQU07UUFBQWEsUUFBQSxFQUFFO01BQVEsQ0FBcUIsQ0FBQyxFQUFDLDBMQUEwTDtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDSyxLQUFLO01BQUFZLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsS0FBSztRQUFBUSxRQUFBLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDVSxFQUFFO1VBQUFPLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1EsRUFBRTtZQUFBUyxRQUFBLEVBQUU7VUFBTSxDQUFpQixDQUFDLG1CQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDUSxFQUFFO1lBQUFTLFFBQUEsRUFBRTtVQUFXLENBQWlCLENBQUMsbUJBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNRLEVBQUU7WUFBQVMsUUFBQSxFQUFFO1VBQVUsQ0FBaUIsQ0FBQztRQUFBLENBQWdCO01BQUMsQ0FBbUIsQ0FBQyxtQkFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTSxLQUFLO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDVSxFQUFFO1VBQUFPLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ08sRUFBRTtZQUFBVSxRQUFBLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBZ0IsUUFBQSxFQUFFO1lBQXFCLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ08sRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBSyxDQUFpQixDQUFDLG1CQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDTyxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFXLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNVLEVBQUU7VUFBQU8sUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDTyxFQUFFO1lBQUFVLFFBQUEsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxJQUFJO2NBQUFnQixRQUFBLEVBQUU7WUFBcUIsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDTyxFQUFFO1lBQUFVLFFBQUEsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDSSxNQUFNO2NBQUFhLFFBQUEsRUFBRTtZQUFJLENBQXFCO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTyxFQUFFO1lBQUFVLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0ksTUFBTTtjQUFBYSxRQUFBLEVBQUU7WUFBUyxDQUFxQixDQUFDLEVBQUMsa0NBQWtDO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUM7TUFBQSxDQUFtQixDQUFDO0lBQUEsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRyxDQUFDO01BQUFjLFFBQUEsRUFBRTtJQUF1SixDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ0csQ0FBQztNQUFBYyxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUF3QixDQUFtQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFnQixDQUFtQixDQUFDLEVBQUMsa0dBQWtHLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQWtCLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0ksTUFBTTtRQUFBYSxRQUFBLEVBQUU7TUFBZ0MsQ0FBcUIsQ0FBQyxFQUFDLG1DQUFtQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0csQ0FBQztNQUFBYyxRQUFBLEVBQUU7SUFBNkMsQ0FBZ0IsQ0FBQztFQUFBLENBQUUsQ0FBQztBQUMvZ0c7QUFDZSxTQUFTRyxVQUFVQSxDQUFDckIsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFO0VBQzdDLE1BQU07SUFBQ3NCLE9BQU8sRUFBRUM7RUFBUyxDQUFDLEdBQUc7SUFDM0IsR0FBRyxJQUFBWCw2QkFBa0IsRUFBQyxDQUFDO0lBQ3ZCLEdBQUdaLEtBQUssQ0FBQ2E7RUFDWCxDQUFDO0VBQ0QsT0FBT1UsU0FBUyxnQkFBRyxJQUFBekIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDRyxTQUFTO0lBQUEsR0FBS3ZCLEtBQUs7SUFBQWtCLFFBQUEsZUFBRSxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDckIsaUJBQWlCO01BQUEsR0FBS0M7SUFBSyxDQUFHO0VBQUMsQ0FBVyxDQUFDLEdBQUdELGlCQUFpQixDQUFDQyxLQUFLLENBQUM7QUFDbEg7QUFBQ3dCLEVBQUEsR0FOdUJILFVBQVU7QUFPbEMsU0FBU04sb0JBQW9CQSxDQUFDSSxFQUFFLEVBQUVNLFNBQVMsRUFBRUMsS0FBSyxFQUFFO0VBQ2xELE1BQU0sSUFBSUMsS0FBSyxDQUFDLFdBQVcsSUFBSUYsU0FBUyxHQUFHLFdBQVcsR0FBRyxRQUFRLENBQUMsR0FBRyxJQUFJLEdBQUdOLEVBQUUsR0FBRyxvRUFBb0UsSUFBSU8sS0FBSyxHQUFHLHFDQUFxQyxHQUFHQSxLQUFLLEdBQUcsdUJBQXVCLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDalA7QUFBQyxJQUFBRixFQUFBO0FBQUFJLFlBQUEsQ0FBQUosRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}