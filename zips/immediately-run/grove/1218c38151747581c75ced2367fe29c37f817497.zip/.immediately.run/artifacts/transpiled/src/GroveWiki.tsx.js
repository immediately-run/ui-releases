var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = GroveWiki;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.map.js");
var _react = require("react");
var _fs = _interopRequireDefault(require("fs"));
var _sdk = require("@immediately-run/sdk");
var _TinkerableContext = require("@immediately-run/sdk/TinkerableContext");
var _linkSpace = require("@immediately-run/sdk/linkSpace");
var _bundle = require("@immediately-run/sdk/bundle");
var _content = require("./lib/content");
var _wiki = require("./lib/wiki");
var _queries = require("./lib/queries");
var _layout = require("./lib/layout");
var _renderMode = require("./lib/renderMode");
var _directory = require("./lib/directory");
var _GroveEntry = _interopRequireDefault(require("./components/GroveEntry"));
var _themeSelection = require("./lib/themeSelection");
var _themes = require("./data/themes");
var _useDirectoryListing = require("./hooks/useDirectoryListing");
var _useScrollReset = require("./hooks/useScrollReset");
var _useEditAffordance = require("./hooks/useEditAffordance");
var _contentRoot = require("./lib/contentRoot");
var _shell = require("./lib/shell");
var _Search = _interopRequireDefault(require("./components/Search"));
var _Drawer = _interopRequireDefault(require("./components/Drawer"));
var _GroveAgent = _interopRequireDefault(require("./components/GroveAgent"));
var _ThemeAssets = _interopRequireDefault(require("./components/ThemeAssets"));
var _ContentTheme = _interopRequireDefault(require("./components/ContentTheme"));
var _themeFonts = require("./data/themeFonts");
var _useContentStylesheets = require("./hooks/useContentStylesheets");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$();
/* eslint-disable @typescript-eslint/no-explicit-any */
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function readPref(k) {
  try {
    return localStorage.getItem(k);
  } catch {
    return null;
  }
}
function writePref(k, v) {
  try {
    localStorage.setItem(k, v);
  } catch {
    /* ignore */
  }
}

// Bundle-absolute path → the href that navigates to it, for CONTENT (R3-174).
//
// Module scope, and that is load-bearing rather than tidiness: this function is handed to
// content through `BundleContext`, and the SDK's `useBundleEntries` memoizes on its
// identity. A closure rebuilt each render would make that memo never hold, so the hook the
// SDK documents as "safe in a dependency array" would quietly stop being one — from the
// PROVIDER's side, where nobody using it would think to look. Nothing here is reactive:
// `contentDir()` is boot-settled module state and `keyToHref` is a pure function of it.
function bundleHref(bundlePath) {
  const absolute = (0, _bundle.fromBundlePath)(bundlePath, (0, _content.contentDir)().replace(/\/+$/, ''));
  return absolute === null ? bundlePath : (0, _content.keyToHref)(absolute);
}

/**
 * The wiki itself: routing, chrome, and the entry render. Everything here reads the
 * content root, so it may only mount once that root is settled — which is why the
 * default export of `App.tsx` is a gate in front of it rather than this component
 * (R3-169: under dispatch the root is a runtime value, not `/app/content/`).
 */
function GroveWiki({
  readOnly = false,
  rejectedComponents = []
}) {
  _s();
  const ctx = (0, _react.useContext)(_TinkerableContext.TinkerableContext);
  const sandboxPath = ctx?.navigationState?.sandboxPath || '/';
  const hash = ctx?.navigationState?.hash ?? '';

  // ── Theme selection (R3-308, 02-theme-contract §4) ─────────────────────────
  //
  // Two INDEPENDENT axes with three sources, resolved through ONE module
  // (lib/themeSelection) so no surface re-derives the precedence:
  //
  //   palette  = reader override, else the author's `theme:` on the home entry, else default
  //   polarity = reader override, else the host's theme, else the palette's preferred
  //
  // The stored prefs are OVERRIDES, nullable by nature: absent until the reader
  // acts, which is what gives the author's declaration its turn. They are written
  // by the user actions (chooseTheme/choosePolarity), NEVER by an effect on mount
  // — the old effects promoted the initial value to a reader choice on first
  // visit, which is exactly why a `theme:` declaration could never have won.
  // (Visitors from before this change carry a mount-written pref; it stands —
  // they are Grove readers, and a reader outranks an author.)
  const [readerTheme, setReaderTheme] = (0, _react.useState)(() => readPref('grove:theme'));
  const [readerAppearance, setReaderAppearance] = (0, _react.useState)(() => {
    const p = readPref('grove:appearance');
    return p === 'light' || p === 'dark' ? p : null;
  });
  const chooseTheme = id => {
    setReaderTheme(id);
    writePref('grove:theme', id);
  };
  const choosePolarity = wantLight => {
    const p = wantLight ? 'light' : 'dark';
    setReaderAppearance(p);
    writePref('grove:appearance', p);
  };
  // The host drives POLARITY ONLY (`theme:read` is the one theme capability the
  // open-wiki binding holds) — and only when there IS a host. `useHostTheme`'s
  // channel reports an `initial: 'dark'` before any host speaks, so an unframed
  // standalone `vite dev` render would otherwise carry a phantom host opinion
  // and flip light-preferred themes. Framed === a host exists to have one.
  const framed = typeof window !== 'undefined' && window.parent !== window;
  const hostTheme = (0, _sdk.useHostTheme)();
  const hostPolarity = framed ? hostTheme : null;
  const [menuOpen, setMenuOpen] = (0, _react.useState)(false);
  const [searchOpen, setSearchOpen] = (0, _react.useState)(false);
  const [drawerOpen, setDrawerOpen] = (0, _react.useState)(false);
  const [mins, setMins] = (0, _react.useState)(0);
  const [vw, setVw] = (0, _react.useState)(() => typeof window !== 'undefined' && window.matchMedia('(max-width: 720px)').matches ? 'mobile' : 'desktop');
  (0, _react.useEffect)(() => {
    const mq = window.matchMedia('(max-width: 720px)');
    const on = () => setVw(mq.matches ? 'mobile' : 'desktop');
    mq.addEventListener('change', on);
    return () => mq.removeEventListener('change', on);
  }, []);

  // ⌘K / Ctrl-K opens search.
  (0, _react.useEffect)(() => {
    const on = e => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setSearchOpen(o => !o);
      }
    };
    window.addEventListener('keydown', on);
    return () => window.removeEventListener('keydown', on);
  }, []);

  // R3-266 — dispatched content IS writable, and the MOUNT decides.
  //
  // This used to read `!isDispatched() && …`, withholding every edit affordance from a
  // dispatched viewer. The reason was real but the conclusion was not: `requestEdit` is
  // **self-scoped by contract**, so under dispatch it names a path in GROVE's repo rather
  // than in the corpus on screen. The fix is a verb swap, not a withheld capability — see
  // `lib/editTarget` — and the gate is the corpus mount's CURRENT mode, re-read on every
  // mount change so a live role downgrade hides the affordance instead of producing
  // `EROFS` on click.
  const {
    writable,
    busy: editBusy,
    refused: editRefused,
    openEditor,
    editHint
  } = (0, _useEditAffordance.useEditAffordance)(readOnly);
  const routeKey = (0, _content.sandboxPathToKey)(sandboxPath) || (0, _content.homeKey)();
  // The site brand is a wiki-wide constant, so read it from the home entry's
  // `site` frontmatter — not the current entry's (which only home would carry),
  // else the brand flips to the 'Grove' fallback on every sub-page.
  const homeMeta = (0, _sdk.useFileMetadata)((0, _content.homeKey)());
  // R3-308: the author's palette declaration — `theme:` on the home entry, the
  // wiki-wide sibling of `site:`. Like `site`, it is read from HOME and not the
  // current entry, so a sub-page never flips the wiki's look back to `default`.
  const authorTheme = typeof homeMeta?.theme === 'string' && homeMeta.theme ? homeMeta.theme : null;
  // The two axes, resolved through the one module that owns the precedence. `theme`
  // and `light` below are the RESOLVED values every surface renders from — the raw
  // reader overrides live only in state and in the menu handlers.
  const theme = (0, _themeSelection.resolvePalette)({
    reader: readerTheme,
    author: authorTheme
  });
  const polarity = (0, _themeSelection.resolvePolarity)({
    reader: readerAppearance,
    host: hostPolarity,
    preferred: (0, _themes.preferredPolarity)(theme)
  });
  const light = polarity === 'light';
  // Existence / 404: the whole index tells us if a followed link is dead. Layout
  // files are structure, not entries, so they're excluded here (and everywhere).
  const allKeysQuery = (0, _react.useCallback)(fm => Object.keys(fm).filter(_content.isContentEntry), []);
  const idx = (0, _sdk.useMetadataQuery)(allKeysQuery);
  const keys = (0, _wiki.queryPaths)(idx);
  const indexLoaded = keys.length > 0;

  // A URL that names a FOLDER is a legitimate address, and there are two right answers
  // to it — in this order:
  //
  //   1. the folder's own `index.mdx`, if the author wrote one. Curation beats
  //      generation, and it is how a corpus overrides the listing per folder without
  //      touching the engine;
  //   2. otherwise the generated <DirectoryView> — the entries and assets that are
  //      actually there.
  //
  // Both used to be "No entry at …", which is the one answer that is false.
  const folderIndex = indexLoaded && !keys.includes(routeKey) ? (0, _directory.folderIndexKey)(routeKey, keys) : null;
  const entryKey = folderIndex ?? routeKey;
  const includePath = (0, _content.keyToInclude)(entryKey);
  const meta = (0, _sdk.useFileMetadata)(entryKey);
  const layout = (0, _layout.resolvePageLayout)(meta);
  const siteTitle = meta?.site || homeMeta?.site || 'Grove';
  // Interpreter mode (TRUST_MODES §5 / R3-213): render this entry's body through the
  // non-executable safe renderer instead of the compiled `<Include>` path.
  //
  // Read from the HOME entry (wiki-wide) OR this entry (per-entry), because the two
  // answer different questions. Wiki-wide is the interpreter declaration — a Grove
  // rendering foreign content sets it there. Per-entry exists because this corpus has
  // one document, the non-executable proof page, whose whole point is planted code that
  // must NOT execute: on the compiled path that page doesn't just look wrong, it runs
  // (R3-252). A document that is only correct as data says so itself.
  const safe = (0, _renderMode.resolveSafeRender)(homeMeta, meta);
  const showRails = layout === 'doc' && !meta?.view;

  // Ask the filesystem only about a key the ENTRY index already missed: an ordinary page
  // render performs no extra I/O, and this readdir replaces a 404 that was about to
  // render anyway. The index cannot answer it — it holds `.md`/`.mdx` only, so a folder
  // of assets is invisible to it.
  const unresolved = indexLoaded && !keys.includes(entryKey);
  const directory = (0, _useDirectoryListing.useDirectoryListing)(unresolved ? entryKey : null);
  const missing = unresolved && directory.status === 'none';

  // The layout chain wrapping this entry (outermost first). Needs the full
  // frontmatter map (folder convention + `frame` override), so it reads the whole
  // metadata store and re-derives when the content set or the entry changes.
  const allMeta = (0, _sdk.useAllMetadata)();

  // ── Content-carried themes (R3-316; MDX_FROM_MOUNT_SPEC D7) ─────────────────
  // The stylesheets the home entry declares (`stylesheets:`); bodies are raw CSS
  // behind frontmatter, gated by the grammar inside ContentTheme and admitted only
  // into the lowest cascade layer. A declaration that names no entry, a sheet that
  // will not read, and a sheet the grammar rejects all degrade to a status line
  // naming it — never a silent drop, never a crash.
  const stylesheets = (0, _useContentStylesheets.useContentStylesheets)(homeMeta?.stylesheets, (0, _content.homeKey)());
  const [rejectedSheet, setRejectedSheet] = (0, _react.useState)(null);
  const sheetErrors = rejectedSheet ? [...stylesheets.errors, rejectedSheet] : stylesheets.errors;

  // ── The entry gate (MDX_FROM_MOUNT_SPEC D8) ─────────────────────────────────
  // Under dispatch the index fills in while the wiki is already on screen. The files
  // that decide how THIS entry renders — itself, home, its layouts, its `frame:` — are
  // read ahead of the rest, and the body waits for them: an unread row reads as
  // `render` unset, which is the executing path. The chrome around it stays mounted.
  // R3-872: the entry gate (prioritize/pending/failure) and the safe derivation
  // moved into GroveEntry's chain frame — GroveWiki keeps only what the chrome
  // reads (navMode's root-layout lookup needs the chain's outermost key).
  const chain = (0, _layout.layoutChainForKey)(entryKey, allMeta);
  const frameNone = meta?.frame === 'none' || meta?.frame === false;

  // R3-309 — the nav arrangement is the ROOT layout's to choose (`nav: top` in the
  // outermost _layout.mdx's frontmatter; the default shell and the starters read the
  // same value through the shell). Undeclared or unknown → 'side', the arrangement
  // Grove has always shipped — never an unstyled page.
  const navMode = (0, _layout.resolveNavMode)(chain.length ? allMeta[chain[0]] : undefined);
  // Every navigation starts at the top of the entry, except one aimed at a section. The
  // ref goes on `.device__scroll` below — the only thing on the page that scrolls.
  const scrollRef = (0, _useScrollReset.useScrollReset)(entryKey, hash);

  // Reading time: read the entry body once per entry.
  (0, _react.useEffect)(() => {
    let active = true;
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setMins(0);
    _fs.default.promises.readFile((0, _content.keyToFsPath)(entryKey), 'utf8').then(b => {
      if (active) setMins((0, _wiki.readingTime)((0, _wiki.stripFrontmatter)(String(b))));
    }).catch(() => undefined);
    return () => {
      active = false;
    };
  }, [entryKey]);

  // Records, not tab-encoded paths (R3-276a): the query selects `{ path, label }`
  // and the hook returns them as-is — no fake-path encoding round-trip.
  const navResult = (0, _sdk.useMetadataQuery)(_queries.navQuery);
  const navItems = (0, _wiki.queryRecords)(navResult).map(({
    path,
    label
  }) => ({
    key: path,
    href: (0, _content.keyToHref)(path),
    label
  }));

  // Closest-match suggestion for a 404 (shared namespace or name overlap).
  const suggestion = missing ? keys.map(k => ({
    k,
    score: overlap(k, entryKey)
  })).sort((a, b) => b.score - a.score)[0]?.k : undefined;
  const shell = {
    theme,
    setTheme: chooseTheme,
    light,
    setLight: choosePolarity,
    menuOpen,
    setMenuOpen,
    searchOpen,
    setSearchOpen,
    drawerOpen,
    setDrawerOpen,
    vw,
    navMode,
    writable,
    openEditor,
    editBusy,
    editRefused,
    editHint,
    siteTitle,
    safe,
    navItems,
    entryKey,
    includePath,
    layout,
    showRails,
    mins,
    missing,
    suggestion,
    directory,
    stylesheetsStatus: stylesheets.status
  };

  // The bundle scope handed to CONTENT (R3-174; MDX_FROM_MOUNT_SPEC §2, §7 1a).
  //
  // A component the bundle ships cannot import this engine — it would resolve a second
  // copy from the registry, with its own `contentRoot` module state, and answer about the
  // wrong bundle — so everything it needs about the bundle arrives through the SDK, which
  // both sides genuinely share (one `/node_modules` per frame). Three facts, and each is
  // one a content component cannot derive for itself:
  //
  //  • `root` — so metadata keys can be rebased off the mount prefix. Content must never
  //    see `/mnt/<hash>/…`: it is host knowledge the viewer reads THROUGH but does not
  //    publish (the property `DirectoryList.test.tsx` pins), and it is not stable across
  //    loads, so anything content stored or linked with it would rot.
  //  • `entry` — the entry being READ, not the file the component sits in. A component in
  //    a `_layout.mdx` wraps the entry, so `<Include>`'s own module identity would name
  //    the layout; furniture in the layout chain (a status line, a dependency rail) needs
  //    the page it is describing.
  //  • `toHref` — because bundle-path→URL is this VIEWER's policy and the two packagings
  //    genuinely disagree (`urlAnchor`). Content that computed its own hrefs would be
  //    correct in exactly one packaging, which is the mode-invariance rule
  //    (PLATFORM_LAYERING §1.1) broken in the least visible possible way.
  // `contentRoot` is module state settled at boot, so it is read here — into a local the
  // memo can list as a dependency — rather than inside the factory. Calling it inside
  // would close over a value the dependency list does not name, which the React Compiler
  // correctly refuses to preserve memoization across.
  // Built fresh each render, like everything else in this component — no hand-memoization
  // (the rest of the file has none either; `react-hooks/preserve-manual-memoization`
  // rejects one here because `entryKey` derives from the metadata query's array).
  //
  // That is safe because the EXPENSIVE half does not key on this object's identity: the
  // SDK's `useBundleEntries` destructures `{root, toHref}` and memoizes on those, and both
  // are stable — `root` is a string compared by value, `toHref` is the module-scope
  // `bundleHref` above. A new wrapper re-renders consumers (cheap); it does not re-derive
  // 800-odd entries. Making `toHref` a closure would silently undo that, which is the
  // whole reason it is not one.
  const bundleRoot = (0, _content.contentDir)().replace(/\/+$/, '');
  const bundleEntry = (0, _bundle.toBundlePath)(entryKey, bundleRoot);
  const bundleScope = {
    root: bundleRoot,
    entry: bundleEntry,
    toHref: bundleHref
  };
  return (
    /*#__PURE__*/
    // R3-277b: declare the enclosing bundle for the platform's link-space consumers
    // (the shared resolver's bundle-anchored absolute + `$fs:` handling read this).
    // R3-482: the SDK pin (since ^0.72.0, #75) reads `bundleRoot` new-then-old, so the
    // new spelling is stated alone — the deprecated `corpusRoot` stays in the type for
    // older consumers (mdx-plugins' forever-compat) but no longer here.
    (0, _jsxRuntime.jsx)(_linkSpace.LinkSpaceContext.Provider, {
      value: {
        bundleRoot: (0, _contentRoot.getContentRoot)(),
        // R3-184 S2 (PERSISTENCE_SPEC §8.3) — the `$fs:` clamp, on this render path.
        // The clamp that is IN FORCE lives in `lib/content.ts` (`linkSpaceOpts`):
        // `hrefTargetKey` is where a corpus document's link targets actually
        // resolve (grove's own WikiLink override routes there), and it passes
        // `bundleChrooted: isDispatched()` to the shared resolver (R3-319's
        // chroot), so a dispatched corpus document's `$fs:/mnt/{hash}/…` cannot
        // name a federated mount materialised beside it — the app-level mount
        // point is not a corpus path — and the fork's `$fs:` stays
        // mount-absolute. This field carries the same flag for the SDK's generic
        // component consumers (WikiLink/MDXComponents) — consumed since the
        // 0.79.0 pin (R3-783): those components forward it to the shared
        // resolver, so the clamp is load-bearing on the generic path too.
        bundleChrooted: (0, _contentRoot.isDispatched)()
      },
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_bundle.BundleContext, {
        value: bundleScope,
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_shell.GroveShellContext.Provider, {
          value: shell,
          children: /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
            className: "grove-root",
            "data-vw": vw,
            "data-nav": navMode,
            "data-grove-theme": theme === 'default' ? undefined : theme,
            "data-theme": polarity,
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_ThemeAssets.default, {
              declarations: (0, _themeFonts.themeAssetsFor)(theme)
            }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_ContentTheme.default, {
              sheets: stylesheets.sheets,
              onRejected: (path, v) => setRejectedSheet(`${path}:${v.line} — ${v.reason}`)
            }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_sdk.ScrollRestoration, {
              scroller: scrollRef
            }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
              className: "device__scroll",
              ref: scrollRef,
              children: [sheetErrors.length > 0 ? /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
                className: "grove-decl-error",
                role: "status",
                children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("strong", {
                  children: "A stylesheet this corpus declares could not be applied."
                }), /*#__PURE__*/(0, _jsxRuntime.jsx)("ul", {
                  children: sheetErrors.map((e, i) => /*#__PURE__*/(0, _jsxRuntime.jsx)("li", {
                    children: e
                  }, i))
                })]
              }) : null, rejectedComponents.length > 0 ? /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
                className: "grove-decl-error",
                role: "status",
                children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("strong", {
                  children: "This corpus declares components that could not be loaded."
                }), /*#__PURE__*/(0, _jsxRuntime.jsx)("ul", {
                  children: rejectedComponents.map(r => /*#__PURE__*/(0, _jsxRuntime.jsxs)("li", {
                    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("code", {
                      children: r.name
                    }), " \u2014 ", r.reason]
                  }, r.name))
                })]
              }) : null, /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
                className: "grove-shell",
                "data-nav": frameNone ? undefined : navMode,
                children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_GroveEntry.default, {
                  entryKey: entryKey,
                  frame: frameNone ? 'none' : 'chain'
                })
              })]
            }), searchOpen ? /*#__PURE__*/(0, _jsxRuntime.jsx)(_Search.default, {
              onClose: () => setSearchOpen(false)
            }) : null, drawerOpen ? /*#__PURE__*/(0, _jsxRuntime.jsx)(_Drawer.default, {
              siteTitle: siteTitle,
              nav: navItems.map(n => ({
                key: n.key,
                href: n.href,
                label: n.label,
                cur: n.key === entryKey
              })),
              onClose: () => setDrawerOpen(false)
            }) : null, /*#__PURE__*/(0, _jsxRuntime.jsx)(_GroveAgent.default, {
              writable: writable,
              entryKey: entryKey,
              entryTitle: (0, _queries.plainLabel)(meta?.title || 'this entry')
            })]
          })
        })
      })
    })
  );
}

// Crude closest-match score for the 404 suggestion: shared namespace + name chars.
_s(GroveWiki, "KZIp1+pTehkIrKZJwGmn1p19zRU=", false, function () {
  return [_sdk.useHostTheme, _useEditAffordance.useEditAffordance, _sdk.useFileMetadata, _sdk.useMetadataQuery, _sdk.useFileMetadata, _useDirectoryListing.useDirectoryListing, _sdk.useAllMetadata, _useContentStylesheets.useContentStylesheets, _useScrollReset.useScrollReset, _sdk.useMetadataQuery];
});
_c = GroveWiki;
function overlap(a, b) {
  const an = a.replace((0, _content.contentDir)(), '').replace(/\.mdx?$/, '');
  const bn = b.replace((0, _content.contentDir)(), '').replace(/\.mdx?$/, '');
  const aNs = an.split('/').slice(0, -1).join('/');
  const bNs = bn.split('/').slice(0, -1).join('/');
  let score = aNs && aNs === bNs ? 5 : 0;
  const aName = an.split('/').pop() || '';
  const bName = bn.split('/').pop() || '';
  for (const ch of new Set(aName)) if (bName.includes(ch)) score++;
  return score;
}
var _c;
$RefreshReg$(_c, "GroveWiki");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX2ZzIiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsIl9zZGsiLCJfVGlua2VyYWJsZUNvbnRleHQiLCJfbGlua1NwYWNlIiwiX2J1bmRsZSIsIl9jb250ZW50IiwiX3dpa2kiLCJfcXVlcmllcyIsIl9sYXlvdXQiLCJfcmVuZGVyTW9kZSIsIl9kaXJlY3RvcnkiLCJfR3JvdmVFbnRyeSIsIl90aGVtZVNlbGVjdGlvbiIsIl90aGVtZXMiLCJfdXNlRGlyZWN0b3J5TGlzdGluZyIsIl91c2VTY3JvbGxSZXNldCIsIl91c2VFZGl0QWZmb3JkYW5jZSIsIl9jb250ZW50Um9vdCIsIl9zaGVsbCIsIl9TZWFyY2giLCJfRHJhd2VyIiwiX0dyb3ZlQWdlbnQiLCJfVGhlbWVBc3NldHMiLCJfQ29udGVudFRoZW1lIiwiX3RoZW1lRm9udHMiLCJfdXNlQ29udGVudFN0eWxlc2hlZXRzIiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsInJlYWRQcmVmIiwiayIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJ3cml0ZVByZWYiLCJ2Iiwic2V0SXRlbSIsImJ1bmRsZUhyZWYiLCJidW5kbGVQYXRoIiwiYWJzb2x1dGUiLCJmcm9tQnVuZGxlUGF0aCIsImNvbnRlbnREaXIiLCJyZXBsYWNlIiwia2V5VG9IcmVmIiwiR3JvdmVXaWtpIiwicmVhZE9ubHkiLCJyZWplY3RlZENvbXBvbmVudHMiLCJjdHgiLCJ1c2VDb250ZXh0IiwiVGlua2VyYWJsZUNvbnRleHQiLCJzYW5kYm94UGF0aCIsIm5hdmlnYXRpb25TdGF0ZSIsImhhc2giLCJyZWFkZXJUaGVtZSIsInNldFJlYWRlclRoZW1lIiwidXNlU3RhdGUiLCJyZWFkZXJBcHBlYXJhbmNlIiwic2V0UmVhZGVyQXBwZWFyYW5jZSIsInAiLCJjaG9vc2VUaGVtZSIsImlkIiwiY2hvb3NlUG9sYXJpdHkiLCJ3YW50TGlnaHQiLCJmcmFtZWQiLCJ3aW5kb3ciLCJwYXJlbnQiLCJob3N0VGhlbWUiLCJ1c2VIb3N0VGhlbWUiLCJob3N0UG9sYXJpdHkiLCJtZW51T3BlbiIsInNldE1lbnVPcGVuIiwic2VhcmNoT3BlbiIsInNldFNlYXJjaE9wZW4iLCJkcmF3ZXJPcGVuIiwic2V0RHJhd2VyT3BlbiIsIm1pbnMiLCJzZXRNaW5zIiwidnciLCJzZXRWdyIsIm1hdGNoTWVkaWEiLCJtYXRjaGVzIiwidXNlRWZmZWN0IiwibXEiLCJvbiIsImFkZEV2ZW50TGlzdGVuZXIiLCJyZW1vdmVFdmVudExpc3RlbmVyIiwibWV0YUtleSIsImN0cmxLZXkiLCJrZXkiLCJ0b0xvd2VyQ2FzZSIsInByZXZlbnREZWZhdWx0IiwibyIsIndyaXRhYmxlIiwiYnVzeSIsImVkaXRCdXN5IiwicmVmdXNlZCIsImVkaXRSZWZ1c2VkIiwib3BlbkVkaXRvciIsImVkaXRIaW50IiwidXNlRWRpdEFmZm9yZGFuY2UiLCJyb3V0ZUtleSIsInNhbmRib3hQYXRoVG9LZXkiLCJob21lS2V5IiwiaG9tZU1ldGEiLCJ1c2VGaWxlTWV0YWRhdGEiLCJhdXRob3JUaGVtZSIsInRoZW1lIiwicmVzb2x2ZVBhbGV0dGUiLCJyZWFkZXIiLCJhdXRob3IiLCJwb2xhcml0eSIsInJlc29sdmVQb2xhcml0eSIsImhvc3QiLCJwcmVmZXJyZWQiLCJwcmVmZXJyZWRQb2xhcml0eSIsImxpZ2h0IiwiYWxsS2V5c1F1ZXJ5IiwidXNlQ2FsbGJhY2siLCJmbSIsIk9iamVjdCIsImtleXMiLCJmaWx0ZXIiLCJpc0NvbnRlbnRFbnRyeSIsImlkeCIsInVzZU1ldGFkYXRhUXVlcnkiLCJxdWVyeVBhdGhzIiwiaW5kZXhMb2FkZWQiLCJsZW5ndGgiLCJmb2xkZXJJbmRleCIsImluY2x1ZGVzIiwiZm9sZGVySW5kZXhLZXkiLCJlbnRyeUtleSIsImluY2x1ZGVQYXRoIiwia2V5VG9JbmNsdWRlIiwibWV0YSIsImxheW91dCIsInJlc29sdmVQYWdlTGF5b3V0Iiwic2l0ZVRpdGxlIiwic2l0ZSIsInNhZmUiLCJyZXNvbHZlU2FmZVJlbmRlciIsInNob3dSYWlscyIsInZpZXciLCJ1bnJlc29sdmVkIiwiZGlyZWN0b3J5IiwidXNlRGlyZWN0b3J5TGlzdGluZyIsIm1pc3NpbmciLCJzdGF0dXMiLCJhbGxNZXRhIiwidXNlQWxsTWV0YWRhdGEiLCJzdHlsZXNoZWV0cyIsInVzZUNvbnRlbnRTdHlsZXNoZWV0cyIsInJlamVjdGVkU2hlZXQiLCJzZXRSZWplY3RlZFNoZWV0Iiwic2hlZXRFcnJvcnMiLCJlcnJvcnMiLCJjaGFpbiIsImxheW91dENoYWluRm9yS2V5IiwiZnJhbWVOb25lIiwiZnJhbWUiLCJuYXZNb2RlIiwicmVzb2x2ZU5hdk1vZGUiLCJ1bmRlZmluZWQiLCJzY3JvbGxSZWYiLCJ1c2VTY3JvbGxSZXNldCIsImFjdGl2ZSIsImZzIiwicHJvbWlzZXMiLCJyZWFkRmlsZSIsImtleVRvRnNQYXRoIiwidGhlbiIsImIiLCJyZWFkaW5nVGltZSIsInN0cmlwRnJvbnRtYXR0ZXIiLCJTdHJpbmciLCJjYXRjaCIsIm5hdlJlc3VsdCIsIm5hdlF1ZXJ5IiwibmF2SXRlbXMiLCJxdWVyeVJlY29yZHMiLCJtYXAiLCJwYXRoIiwibGFiZWwiLCJocmVmIiwic3VnZ2VzdGlvbiIsInNjb3JlIiwib3ZlcmxhcCIsInNvcnQiLCJhIiwic2hlbGwiLCJzZXRUaGVtZSIsInNldExpZ2h0Iiwic3R5bGVzaGVldHNTdGF0dXMiLCJidW5kbGVSb290IiwiYnVuZGxlRW50cnkiLCJ0b0J1bmRsZVBhdGgiLCJidW5kbGVTY29wZSIsInJvb3QiLCJlbnRyeSIsInRvSHJlZiIsImpzeCIsIkxpbmtTcGFjZUNvbnRleHQiLCJQcm92aWRlciIsInZhbHVlIiwiZ2V0Q29udGVudFJvb3QiLCJidW5kbGVDaHJvb3RlZCIsImlzRGlzcGF0Y2hlZCIsImNoaWxkcmVuIiwiQnVuZGxlQ29udGV4dCIsIkdyb3ZlU2hlbGxDb250ZXh0IiwianN4cyIsImNsYXNzTmFtZSIsImRlY2xhcmF0aW9ucyIsInRoZW1lQXNzZXRzRm9yIiwic2hlZXRzIiwib25SZWplY3RlZCIsImxpbmUiLCJyZWFzb24iLCJTY3JvbGxSZXN0b3JhdGlvbiIsInNjcm9sbGVyIiwicmVmIiwicm9sZSIsImkiLCJyIiwibmFtZSIsIm9uQ2xvc2UiLCJuYXYiLCJuIiwiY3VyIiwiZW50cnlUaXRsZSIsInBsYWluTGFiZWwiLCJ0aXRsZSIsIl9jIiwiYW4iLCJibiIsImFOcyIsInNwbGl0Iiwic2xpY2UiLCJqb2luIiwiYk5zIiwiYU5hbWUiLCJwb3AiLCJiTmFtZSIsImNoIiwiU2V0IiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiR3JvdmVXaWtpLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55ICovXG5pbXBvcnQgeyB1c2VDYWxsYmFjaywgdXNlQ29udGV4dCwgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCBmcyBmcm9tICdmcyc7XG5pbXBvcnQgdHlwZSB7IE1ldGFkYXRhIH0gZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9zZGsnO1xuaW1wb3J0IHtcbiAgU2Nyb2xsUmVzdG9yYXRpb24sXG4gIHVzZUFsbE1ldGFkYXRhLFxuICB1c2VGaWxlTWV0YWRhdGEsXG4gIHVzZUhvc3RUaGVtZSxcbiAgdXNlTWV0YWRhdGFRdWVyeSxcbn0gZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9zZGsnO1xuaW1wb3J0IHsgVGlua2VyYWJsZUNvbnRleHQgfSBmcm9tICdAaW1tZWRpYXRlbHktcnVuL3Nkay9UaW5rZXJhYmxlQ29udGV4dCc7XG5pbXBvcnQgeyBMaW5rU3BhY2VDb250ZXh0IH0gZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9zZGsvbGlua1NwYWNlJztcbmltcG9ydCB7IEJ1bmRsZUNvbnRleHQsIHRvQnVuZGxlUGF0aCwgZnJvbUJ1bmRsZVBhdGggfSBmcm9tICdAaW1tZWRpYXRlbHktcnVuL3Nkay9idW5kbGUnO1xuaW1wb3J0IHtcbiAgY29udGVudERpcixcbiAgaG9tZUtleSxcbiAgaXNDb250ZW50RW50cnksXG4gIGtleVRvRnNQYXRoLFxuICBrZXlUb0hyZWYsXG4gIGtleVRvSW5jbHVkZSxcbiAgc2FuZGJveFBhdGhUb0tleSxcbn0gZnJvbSAnLi9saWIvY29udGVudCc7XG5pbXBvcnQgeyBxdWVyeVBhdGhzLCBxdWVyeVJlY29yZHMsIHJlYWRpbmdUaW1lLCBzdHJpcEZyb250bWF0dGVyIH0gZnJvbSAnLi9saWIvd2lraSc7XG5pbXBvcnQgeyBuYXZRdWVyeSwgcGxhaW5MYWJlbCB9IGZyb20gJy4vbGliL3F1ZXJpZXMnO1xuaW1wb3J0IHR5cGUgeyBOYXZSZWNvcmQgfSBmcm9tICcuL2xpYi9xdWVyaWVzJztcbmltcG9ydCB7IGxheW91dENoYWluRm9yS2V5LCByZXNvbHZlTmF2TW9kZSwgcmVzb2x2ZVBhZ2VMYXlvdXQgfSBmcm9tICcuL2xpYi9sYXlvdXQnO1xuaW1wb3J0IHsgcmVzb2x2ZVNhZmVSZW5kZXIgfSBmcm9tICcuL2xpYi9yZW5kZXJNb2RlJztcbmltcG9ydCB7IGZvbGRlckluZGV4S2V5IH0gZnJvbSAnLi9saWIvZGlyZWN0b3J5JztcbmltcG9ydCBHcm92ZUVudHJ5IGZyb20gJy4vY29tcG9uZW50cy9Hcm92ZUVudHJ5JztcbmltcG9ydCB7IHJlc29sdmVQYWxldHRlLCByZXNvbHZlUG9sYXJpdHksIHR5cGUgUG9sYXJpdHkgfSBmcm9tICcuL2xpYi90aGVtZVNlbGVjdGlvbic7XG5pbXBvcnQgeyBwcmVmZXJyZWRQb2xhcml0eSB9IGZyb20gJy4vZGF0YS90aGVtZXMnO1xuaW1wb3J0IHsgdXNlRGlyZWN0b3J5TGlzdGluZyB9IGZyb20gJy4vaG9va3MvdXNlRGlyZWN0b3J5TGlzdGluZyc7XG5pbXBvcnQgeyB1c2VTY3JvbGxSZXNldCB9IGZyb20gJy4vaG9va3MvdXNlU2Nyb2xsUmVzZXQnO1xuaW1wb3J0IHsgdXNlRWRpdEFmZm9yZGFuY2UgfSBmcm9tICcuL2hvb2tzL3VzZUVkaXRBZmZvcmRhbmNlJztcbmltcG9ydCB7IGdldENvbnRlbnRSb290LCBpc0Rpc3BhdGNoZWQgfSBmcm9tICcuL2xpYi9jb250ZW50Um9vdCc7XG5pbXBvcnQgdHlwZSB7IFJlamVjdGVkQ29tcG9uZW50IH0gZnJvbSAnLi9saWIvY29ycHVzQ29tcG9uZW50cyc7XG5pbXBvcnQgeyBHcm92ZVNoZWxsQ29udGV4dCB9IGZyb20gJy4vbGliL3NoZWxsJztcbmltcG9ydCB0eXBlIHsgR3JvdmVTaGVsbCwgTmF2SXRlbSB9IGZyb20gJy4vbGliL3NoZWxsJztcbmltcG9ydCBTZWFyY2ggZnJvbSAnLi9jb21wb25lbnRzL1NlYXJjaCc7XG5pbXBvcnQgRHJhd2VyIGZyb20gJy4vY29tcG9uZW50cy9EcmF3ZXInO1xuaW1wb3J0IEdyb3ZlQWdlbnQgZnJvbSAnLi9jb21wb25lbnRzL0dyb3ZlQWdlbnQnO1xuaW1wb3J0IFRoZW1lQXNzZXRzIGZyb20gJy4vY29tcG9uZW50cy9UaGVtZUFzc2V0cyc7XG5pbXBvcnQgQ29udGVudFRoZW1lIGZyb20gJy4vY29tcG9uZW50cy9Db250ZW50VGhlbWUnO1xuaW1wb3J0IHsgdGhlbWVBc3NldHNGb3IgfSBmcm9tICcuL2RhdGEvdGhlbWVGb250cyc7XG5pbXBvcnQgeyB1c2VDb250ZW50U3R5bGVzaGVldHMgfSBmcm9tICcuL2hvb2tzL3VzZUNvbnRlbnRTdHlsZXNoZWV0cyc7XG5cbmZ1bmN0aW9uIHJlYWRQcmVmKGs6IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xuICB0cnkge1xuICAgIHJldHVybiBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShrKTtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbn1cbmZ1bmN0aW9uIHdyaXRlUHJlZihrOiBzdHJpbmcsIHY6IHN0cmluZyk6IHZvaWQge1xuICB0cnkge1xuICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKGssIHYpO1xuICB9IGNhdGNoIHtcbiAgICAvKiBpZ25vcmUgKi9cbiAgfVxufVxuXG4vLyBCdW5kbGUtYWJzb2x1dGUgcGF0aCDihpIgdGhlIGhyZWYgdGhhdCBuYXZpZ2F0ZXMgdG8gaXQsIGZvciBDT05URU5UIChSMy0xNzQpLlxuLy9cbi8vIE1vZHVsZSBzY29wZSwgYW5kIHRoYXQgaXMgbG9hZC1iZWFyaW5nIHJhdGhlciB0aGFuIHRpZGluZXNzOiB0aGlzIGZ1bmN0aW9uIGlzIGhhbmRlZCB0b1xuLy8gY29udGVudCB0aHJvdWdoIGBCdW5kbGVDb250ZXh0YCwgYW5kIHRoZSBTREsncyBgdXNlQnVuZGxlRW50cmllc2AgbWVtb2l6ZXMgb24gaXRzXG4vLyBpZGVudGl0eS4gQSBjbG9zdXJlIHJlYnVpbHQgZWFjaCByZW5kZXIgd291bGQgbWFrZSB0aGF0IG1lbW8gbmV2ZXIgaG9sZCwgc28gdGhlIGhvb2sgdGhlXG4vLyBTREsgZG9jdW1lbnRzIGFzIFwic2FmZSBpbiBhIGRlcGVuZGVuY3kgYXJyYXlcIiB3b3VsZCBxdWlldGx5IHN0b3AgYmVpbmcgb25lIOKAlCBmcm9tIHRoZVxuLy8gUFJPVklERVIncyBzaWRlLCB3aGVyZSBub2JvZHkgdXNpbmcgaXQgd291bGQgdGhpbmsgdG8gbG9vay4gTm90aGluZyBoZXJlIGlzIHJlYWN0aXZlOlxuLy8gYGNvbnRlbnREaXIoKWAgaXMgYm9vdC1zZXR0bGVkIG1vZHVsZSBzdGF0ZSBhbmQgYGtleVRvSHJlZmAgaXMgYSBwdXJlIGZ1bmN0aW9uIG9mIGl0LlxuZnVuY3Rpb24gYnVuZGxlSHJlZihidW5kbGVQYXRoOiBzdHJpbmcpOiBzdHJpbmcge1xuICBjb25zdCBhYnNvbHV0ZSA9IGZyb21CdW5kbGVQYXRoKGJ1bmRsZVBhdGgsIGNvbnRlbnREaXIoKS5yZXBsYWNlKC9cXC8rJC8sICcnKSk7XG4gIHJldHVybiBhYnNvbHV0ZSA9PT0gbnVsbCA/IGJ1bmRsZVBhdGggOiBrZXlUb0hyZWYoYWJzb2x1dGUpO1xufVxuXG4vKipcbiAqIFRoZSB3aWtpIGl0c2VsZjogcm91dGluZywgY2hyb21lLCBhbmQgdGhlIGVudHJ5IHJlbmRlci4gRXZlcnl0aGluZyBoZXJlIHJlYWRzIHRoZVxuICogY29udGVudCByb290LCBzbyBpdCBtYXkgb25seSBtb3VudCBvbmNlIHRoYXQgcm9vdCBpcyBzZXR0bGVkIOKAlCB3aGljaCBpcyB3aHkgdGhlXG4gKiBkZWZhdWx0IGV4cG9ydCBvZiBgQXBwLnRzeGAgaXMgYSBnYXRlIGluIGZyb250IG9mIGl0IHJhdGhlciB0aGFuIHRoaXMgY29tcG9uZW50XG4gKiAoUjMtMTY5OiB1bmRlciBkaXNwYXRjaCB0aGUgcm9vdCBpcyBhIHJ1bnRpbWUgdmFsdWUsIG5vdCBgL2FwcC9jb250ZW50L2ApLlxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBHcm92ZVdpa2koe1xuICByZWFkT25seSA9IGZhbHNlLFxuICByZWplY3RlZENvbXBvbmVudHMgPSBbXSxcbn06IHtcbiAgcmVhZE9ubHk/OiBib29sZWFuO1xuICAvKiogQ29ycHVzIGNvbXBvbmVudCBkZWNsYXJhdGlvbnMgdGhhdCBjb3VsZCBub3QgYmUgbG9hZGVkIChSMy0xNzQpLiBTaG93biwgbm90XG4gICAqICBzd2FsbG93ZWQ6IGEgYDxSb2FkbWFwQm9hcmQvPmAgdGhhdCBzaWxlbnRseSBuZXZlciBhcHBlYXJzIGlzIGluZGlzdGluZ3Vpc2hhYmxlIGZyb21cbiAgICogIG9uZSBub2JvZHkgd3JvdGUsIGFuZCB0aGUgYXV0aG9yIGhhcyBubyBvdGhlciBjaGFubmVsIHRvIGxlYXJuIHdoaWNoIGl0IHdhcy4gKi9cbiAgcmVqZWN0ZWRDb21wb25lbnRzPzogUmVqZWN0ZWRDb21wb25lbnRbXTtcbn0pIHtcbiAgY29uc3QgY3R4ID0gdXNlQ29udGV4dChUaW5rZXJhYmxlQ29udGV4dCkgYXMgYW55O1xuICBjb25zdCBzYW5kYm94UGF0aDogc3RyaW5nID0gY3R4Py5uYXZpZ2F0aW9uU3RhdGU/LnNhbmRib3hQYXRoIHx8ICcvJztcbiAgY29uc3QgaGFzaDogc3RyaW5nID0gY3R4Py5uYXZpZ2F0aW9uU3RhdGU/Lmhhc2ggPz8gJyc7XG5cbiAgLy8g4pSA4pSAIFRoZW1lIHNlbGVjdGlvbiAoUjMtMzA4LCAwMi10aGVtZS1jb250cmFjdCDCpzQpIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAvL1xuICAvLyBUd28gSU5ERVBFTkRFTlQgYXhlcyB3aXRoIHRocmVlIHNvdXJjZXMsIHJlc29sdmVkIHRocm91Z2ggT05FIG1vZHVsZVxuICAvLyAobGliL3RoZW1lU2VsZWN0aW9uKSBzbyBubyBzdXJmYWNlIHJlLWRlcml2ZXMgdGhlIHByZWNlZGVuY2U6XG4gIC8vXG4gIC8vICAgcGFsZXR0ZSAgPSByZWFkZXIgb3ZlcnJpZGUsIGVsc2UgdGhlIGF1dGhvcidzIGB0aGVtZTpgIG9uIHRoZSBob21lIGVudHJ5LCBlbHNlIGRlZmF1bHRcbiAgLy8gICBwb2xhcml0eSA9IHJlYWRlciBvdmVycmlkZSwgZWxzZSB0aGUgaG9zdCdzIHRoZW1lLCBlbHNlIHRoZSBwYWxldHRlJ3MgcHJlZmVycmVkXG4gIC8vXG4gIC8vIFRoZSBzdG9yZWQgcHJlZnMgYXJlIE9WRVJSSURFUywgbnVsbGFibGUgYnkgbmF0dXJlOiBhYnNlbnQgdW50aWwgdGhlIHJlYWRlclxuICAvLyBhY3RzLCB3aGljaCBpcyB3aGF0IGdpdmVzIHRoZSBhdXRob3IncyBkZWNsYXJhdGlvbiBpdHMgdHVybi4gVGhleSBhcmUgd3JpdHRlblxuICAvLyBieSB0aGUgdXNlciBhY3Rpb25zIChjaG9vc2VUaGVtZS9jaG9vc2VQb2xhcml0eSksIE5FVkVSIGJ5IGFuIGVmZmVjdCBvbiBtb3VudFxuICAvLyDigJQgdGhlIG9sZCBlZmZlY3RzIHByb21vdGVkIHRoZSBpbml0aWFsIHZhbHVlIHRvIGEgcmVhZGVyIGNob2ljZSBvbiBmaXJzdFxuICAvLyB2aXNpdCwgd2hpY2ggaXMgZXhhY3RseSB3aHkgYSBgdGhlbWU6YCBkZWNsYXJhdGlvbiBjb3VsZCBuZXZlciBoYXZlIHdvbi5cbiAgLy8gKFZpc2l0b3JzIGZyb20gYmVmb3JlIHRoaXMgY2hhbmdlIGNhcnJ5IGEgbW91bnQtd3JpdHRlbiBwcmVmOyBpdCBzdGFuZHMg4oCUXG4gIC8vIHRoZXkgYXJlIEdyb3ZlIHJlYWRlcnMsIGFuZCBhIHJlYWRlciBvdXRyYW5rcyBhbiBhdXRob3IuKVxuICBjb25zdCBbcmVhZGVyVGhlbWUsIHNldFJlYWRlclRoZW1lXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KCgpID0+IHJlYWRQcmVmKCdncm92ZTp0aGVtZScpKTtcbiAgY29uc3QgW3JlYWRlckFwcGVhcmFuY2UsIHNldFJlYWRlckFwcGVhcmFuY2VdID0gdXNlU3RhdGU8UG9sYXJpdHkgfCBudWxsPigoKSA9PiB7XG4gICAgY29uc3QgcCA9IHJlYWRQcmVmKCdncm92ZTphcHBlYXJhbmNlJyk7XG4gICAgcmV0dXJuIHAgPT09ICdsaWdodCcgfHwgcCA9PT0gJ2RhcmsnID8gcCA6IG51bGw7XG4gIH0pO1xuICBjb25zdCBjaG9vc2VUaGVtZSA9IChpZDogc3RyaW5nKSA9PiB7XG4gICAgc2V0UmVhZGVyVGhlbWUoaWQpO1xuICAgIHdyaXRlUHJlZignZ3JvdmU6dGhlbWUnLCBpZCk7XG4gIH07XG4gIGNvbnN0IGNob29zZVBvbGFyaXR5ID0gKHdhbnRMaWdodDogYm9vbGVhbikgPT4ge1xuICAgIGNvbnN0IHA6IFBvbGFyaXR5ID0gd2FudExpZ2h0ID8gJ2xpZ2h0JyA6ICdkYXJrJztcbiAgICBzZXRSZWFkZXJBcHBlYXJhbmNlKHApO1xuICAgIHdyaXRlUHJlZignZ3JvdmU6YXBwZWFyYW5jZScsIHApO1xuICB9O1xuICAvLyBUaGUgaG9zdCBkcml2ZXMgUE9MQVJJVFkgT05MWSAoYHRoZW1lOnJlYWRgIGlzIHRoZSBvbmUgdGhlbWUgY2FwYWJpbGl0eSB0aGVcbiAgLy8gb3Blbi13aWtpIGJpbmRpbmcgaG9sZHMpIOKAlCBhbmQgb25seSB3aGVuIHRoZXJlIElTIGEgaG9zdC4gYHVzZUhvc3RUaGVtZWAnc1xuICAvLyBjaGFubmVsIHJlcG9ydHMgYW4gYGluaXRpYWw6ICdkYXJrJ2AgYmVmb3JlIGFueSBob3N0IHNwZWFrcywgc28gYW4gdW5mcmFtZWRcbiAgLy8gc3RhbmRhbG9uZSBgdml0ZSBkZXZgIHJlbmRlciB3b3VsZCBvdGhlcndpc2UgY2FycnkgYSBwaGFudG9tIGhvc3Qgb3BpbmlvblxuICAvLyBhbmQgZmxpcCBsaWdodC1wcmVmZXJyZWQgdGhlbWVzLiBGcmFtZWQgPT09IGEgaG9zdCBleGlzdHMgdG8gaGF2ZSBvbmUuXG4gIGNvbnN0IGZyYW1lZCA9IHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnICYmIHdpbmRvdy5wYXJlbnQgIT09IHdpbmRvdztcbiAgY29uc3QgaG9zdFRoZW1lID0gdXNlSG9zdFRoZW1lKCk7XG4gIGNvbnN0IGhvc3RQb2xhcml0eTogUG9sYXJpdHkgfCBudWxsID0gZnJhbWVkID8gaG9zdFRoZW1lIDogbnVsbDtcbiAgY29uc3QgW21lbnVPcGVuLCBzZXRNZW51T3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtzZWFyY2hPcGVuLCBzZXRTZWFyY2hPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2RyYXdlck9wZW4sIHNldERyYXdlck9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbbWlucywgc2V0TWluc10gPSB1c2VTdGF0ZSgwKTtcbiAgY29uc3QgW3Z3LCBzZXRWd10gPSB1c2VTdGF0ZTwnbW9iaWxlJyB8ICdkZXNrdG9wJz4oKCkgPT5cbiAgICB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyAmJiB3aW5kb3cubWF0Y2hNZWRpYSgnKG1heC13aWR0aDogNzIwcHgpJykubWF0Y2hlcyA/ICdtb2JpbGUnIDogJ2Rlc2t0b3AnXG4gICk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBtcSA9IHdpbmRvdy5tYXRjaE1lZGlhKCcobWF4LXdpZHRoOiA3MjBweCknKTtcbiAgICBjb25zdCBvbiA9ICgpID0+IHNldFZ3KG1xLm1hdGNoZXMgPyAnbW9iaWxlJyA6ICdkZXNrdG9wJyk7XG4gICAgbXEuYWRkRXZlbnRMaXN0ZW5lcignY2hhbmdlJywgb24pO1xuICAgIHJldHVybiAoKSA9PiBtcS5yZW1vdmVFdmVudExpc3RlbmVyKCdjaGFuZ2UnLCBvbik7XG4gIH0sIFtdKTtcblxuICAvLyDijJhLIC8gQ3RybC1LIG9wZW5zIHNlYXJjaC5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBvbiA9IChlOiBLZXlib2FyZEV2ZW50KSA9PiB7XG4gICAgICBpZiAoKGUubWV0YUtleSB8fCBlLmN0cmxLZXkpICYmIGUua2V5LnRvTG93ZXJDYXNlKCkgPT09ICdrJykge1xuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIHNldFNlYXJjaE9wZW4oKG8pID0+ICFvKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdrZXlkb3duJywgb24pO1xuICAgIHJldHVybiAoKSA9PiB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcigna2V5ZG93bicsIG9uKTtcbiAgfSwgW10pO1xuXG4gIC8vIFIzLTI2NiDigJQgZGlzcGF0Y2hlZCBjb250ZW50IElTIHdyaXRhYmxlLCBhbmQgdGhlIE1PVU5UIGRlY2lkZXMuXG4gIC8vXG4gIC8vIFRoaXMgdXNlZCB0byByZWFkIGAhaXNEaXNwYXRjaGVkKCkgJiYg4oCmYCwgd2l0aGhvbGRpbmcgZXZlcnkgZWRpdCBhZmZvcmRhbmNlIGZyb20gYVxuICAvLyBkaXNwYXRjaGVkIHZpZXdlci4gVGhlIHJlYXNvbiB3YXMgcmVhbCBidXQgdGhlIGNvbmNsdXNpb24gd2FzIG5vdDogYHJlcXVlc3RFZGl0YCBpc1xuICAvLyAqKnNlbGYtc2NvcGVkIGJ5IGNvbnRyYWN0KiosIHNvIHVuZGVyIGRpc3BhdGNoIGl0IG5hbWVzIGEgcGF0aCBpbiBHUk9WRSdzIHJlcG8gcmF0aGVyXG4gIC8vIHRoYW4gaW4gdGhlIGNvcnB1cyBvbiBzY3JlZW4uIFRoZSBmaXggaXMgYSB2ZXJiIHN3YXAsIG5vdCBhIHdpdGhoZWxkIGNhcGFiaWxpdHkg4oCUIHNlZVxuICAvLyBgbGliL2VkaXRUYXJnZXRgIOKAlCBhbmQgdGhlIGdhdGUgaXMgdGhlIGNvcnB1cyBtb3VudCdzIENVUlJFTlQgbW9kZSwgcmUtcmVhZCBvbiBldmVyeVxuICAvLyBtb3VudCBjaGFuZ2Ugc28gYSBsaXZlIHJvbGUgZG93bmdyYWRlIGhpZGVzIHRoZSBhZmZvcmRhbmNlIGluc3RlYWQgb2YgcHJvZHVjaW5nXG4gIC8vIGBFUk9GU2Agb24gY2xpY2suXG4gIGNvbnN0IHsgd3JpdGFibGUsIGJ1c3k6IGVkaXRCdXN5LCByZWZ1c2VkOiBlZGl0UmVmdXNlZCwgb3BlbkVkaXRvciwgZWRpdEhpbnQgfSA9IHVzZUVkaXRBZmZvcmRhbmNlKHJlYWRPbmx5KTtcblxuICBjb25zdCByb3V0ZUtleSA9IHNhbmRib3hQYXRoVG9LZXkoc2FuZGJveFBhdGgpIHx8IGhvbWVLZXkoKTtcbiAgLy8gVGhlIHNpdGUgYnJhbmQgaXMgYSB3aWtpLXdpZGUgY29uc3RhbnQsIHNvIHJlYWQgaXQgZnJvbSB0aGUgaG9tZSBlbnRyeSdzXG4gIC8vIGBzaXRlYCBmcm9udG1hdHRlciDigJQgbm90IHRoZSBjdXJyZW50IGVudHJ5J3MgKHdoaWNoIG9ubHkgaG9tZSB3b3VsZCBjYXJyeSksXG4gIC8vIGVsc2UgdGhlIGJyYW5kIGZsaXBzIHRvIHRoZSAnR3JvdmUnIGZhbGxiYWNrIG9uIGV2ZXJ5IHN1Yi1wYWdlLlxuICBjb25zdCBob21lTWV0YSA9IHVzZUZpbGVNZXRhZGF0YShob21lS2V5KCkpIGFzIGFueTtcbiAgLy8gUjMtMzA4OiB0aGUgYXV0aG9yJ3MgcGFsZXR0ZSBkZWNsYXJhdGlvbiDigJQgYHRoZW1lOmAgb24gdGhlIGhvbWUgZW50cnksIHRoZVxuICAvLyB3aWtpLXdpZGUgc2libGluZyBvZiBgc2l0ZTpgLiBMaWtlIGBzaXRlYCwgaXQgaXMgcmVhZCBmcm9tIEhPTUUgYW5kIG5vdCB0aGVcbiAgLy8gY3VycmVudCBlbnRyeSwgc28gYSBzdWItcGFnZSBuZXZlciBmbGlwcyB0aGUgd2lraSdzIGxvb2sgYmFjayB0byBgZGVmYXVsdGAuXG4gIGNvbnN0IGF1dGhvclRoZW1lOiBzdHJpbmcgfCBudWxsID1cbiAgICB0eXBlb2YgaG9tZU1ldGE/LnRoZW1lID09PSAnc3RyaW5nJyAmJiBob21lTWV0YS50aGVtZSA/IGhvbWVNZXRhLnRoZW1lIDogbnVsbDtcbiAgLy8gVGhlIHR3byBheGVzLCByZXNvbHZlZCB0aHJvdWdoIHRoZSBvbmUgbW9kdWxlIHRoYXQgb3ducyB0aGUgcHJlY2VkZW5jZS4gYHRoZW1lYFxuICAvLyBhbmQgYGxpZ2h0YCBiZWxvdyBhcmUgdGhlIFJFU09MVkVEIHZhbHVlcyBldmVyeSBzdXJmYWNlIHJlbmRlcnMgZnJvbSDigJQgdGhlIHJhd1xuICAvLyByZWFkZXIgb3ZlcnJpZGVzIGxpdmUgb25seSBpbiBzdGF0ZSBhbmQgaW4gdGhlIG1lbnUgaGFuZGxlcnMuXG4gIGNvbnN0IHRoZW1lID0gcmVzb2x2ZVBhbGV0dGUoeyByZWFkZXI6IHJlYWRlclRoZW1lLCBhdXRob3I6IGF1dGhvclRoZW1lIH0pO1xuICBjb25zdCBwb2xhcml0eTogUG9sYXJpdHkgPSByZXNvbHZlUG9sYXJpdHkoe1xuICAgIHJlYWRlcjogcmVhZGVyQXBwZWFyYW5jZSxcbiAgICBob3N0OiBob3N0UG9sYXJpdHksXG4gICAgcHJlZmVycmVkOiBwcmVmZXJyZWRQb2xhcml0eSh0aGVtZSksXG4gIH0pO1xuICBjb25zdCBsaWdodCA9IHBvbGFyaXR5ID09PSAnbGlnaHQnO1xuICAvLyBFeGlzdGVuY2UgLyA0MDQ6IHRoZSB3aG9sZSBpbmRleCB0ZWxscyB1cyBpZiBhIGZvbGxvd2VkIGxpbmsgaXMgZGVhZC4gTGF5b3V0XG4gIC8vIGZpbGVzIGFyZSBzdHJ1Y3R1cmUsIG5vdCBlbnRyaWVzLCBzbyB0aGV5J3JlIGV4Y2x1ZGVkIGhlcmUgKGFuZCBldmVyeXdoZXJlKS5cbiAgY29uc3QgYWxsS2V5c1F1ZXJ5ID0gdXNlQ2FsbGJhY2soKGZtOiBSZWNvcmQ8c3RyaW5nLCBhbnk+KSA9PiBPYmplY3Qua2V5cyhmbSkuZmlsdGVyKGlzQ29udGVudEVudHJ5KSwgW10pO1xuICBjb25zdCBpZHggPSB1c2VNZXRhZGF0YVF1ZXJ5KGFsbEtleXNRdWVyeSk7XG4gIGNvbnN0IGtleXM6IHN0cmluZ1tdID0gcXVlcnlQYXRocyhpZHgpO1xuICBjb25zdCBpbmRleExvYWRlZCA9IGtleXMubGVuZ3RoID4gMDtcblxuICAvLyBBIFVSTCB0aGF0IG5hbWVzIGEgRk9MREVSIGlzIGEgbGVnaXRpbWF0ZSBhZGRyZXNzLCBhbmQgdGhlcmUgYXJlIHR3byByaWdodCBhbnN3ZXJzXG4gIC8vIHRvIGl0IOKAlCBpbiB0aGlzIG9yZGVyOlxuICAvL1xuICAvLyAgIDEuIHRoZSBmb2xkZXIncyBvd24gYGluZGV4Lm1keGAsIGlmIHRoZSBhdXRob3Igd3JvdGUgb25lLiBDdXJhdGlvbiBiZWF0c1xuICAvLyAgICAgIGdlbmVyYXRpb24sIGFuZCBpdCBpcyBob3cgYSBjb3JwdXMgb3ZlcnJpZGVzIHRoZSBsaXN0aW5nIHBlciBmb2xkZXIgd2l0aG91dFxuICAvLyAgICAgIHRvdWNoaW5nIHRoZSBlbmdpbmU7XG4gIC8vICAgMi4gb3RoZXJ3aXNlIHRoZSBnZW5lcmF0ZWQgPERpcmVjdG9yeVZpZXc+IOKAlCB0aGUgZW50cmllcyBhbmQgYXNzZXRzIHRoYXQgYXJlXG4gIC8vICAgICAgYWN0dWFsbHkgdGhlcmUuXG4gIC8vXG4gIC8vIEJvdGggdXNlZCB0byBiZSBcIk5vIGVudHJ5IGF0IOKAplwiLCB3aGljaCBpcyB0aGUgb25lIGFuc3dlciB0aGF0IGlzIGZhbHNlLlxuICBjb25zdCBmb2xkZXJJbmRleCA9IGluZGV4TG9hZGVkICYmICFrZXlzLmluY2x1ZGVzKHJvdXRlS2V5KSA/IGZvbGRlckluZGV4S2V5KHJvdXRlS2V5LCBrZXlzKSA6IG51bGw7XG4gIGNvbnN0IGVudHJ5S2V5ID0gZm9sZGVySW5kZXggPz8gcm91dGVLZXk7XG4gIGNvbnN0IGluY2x1ZGVQYXRoID0ga2V5VG9JbmNsdWRlKGVudHJ5S2V5KTtcbiAgY29uc3QgbWV0YSA9IHVzZUZpbGVNZXRhZGF0YShlbnRyeUtleSkgYXMgYW55O1xuXG4gIGNvbnN0IGxheW91dCA9IHJlc29sdmVQYWdlTGF5b3V0KG1ldGEpO1xuICBjb25zdCBzaXRlVGl0bGU6IHN0cmluZyA9IG1ldGE/LnNpdGUgfHwgaG9tZU1ldGE/LnNpdGUgfHwgJ0dyb3ZlJztcbiAgLy8gSW50ZXJwcmV0ZXIgbW9kZSAoVFJVU1RfTU9ERVMgwqc1IC8gUjMtMjEzKTogcmVuZGVyIHRoaXMgZW50cnkncyBib2R5IHRocm91Z2ggdGhlXG4gIC8vIG5vbi1leGVjdXRhYmxlIHNhZmUgcmVuZGVyZXIgaW5zdGVhZCBvZiB0aGUgY29tcGlsZWQgYDxJbmNsdWRlPmAgcGF0aC5cbiAgLy9cbiAgLy8gUmVhZCBmcm9tIHRoZSBIT01FIGVudHJ5ICh3aWtpLXdpZGUpIE9SIHRoaXMgZW50cnkgKHBlci1lbnRyeSksIGJlY2F1c2UgdGhlIHR3b1xuICAvLyBhbnN3ZXIgZGlmZmVyZW50IHF1ZXN0aW9ucy4gV2lraS13aWRlIGlzIHRoZSBpbnRlcnByZXRlciBkZWNsYXJhdGlvbiDigJQgYSBHcm92ZVxuICAvLyByZW5kZXJpbmcgZm9yZWlnbiBjb250ZW50IHNldHMgaXQgdGhlcmUuIFBlci1lbnRyeSBleGlzdHMgYmVjYXVzZSB0aGlzIGNvcnB1cyBoYXNcbiAgLy8gb25lIGRvY3VtZW50LCB0aGUgbm9uLWV4ZWN1dGFibGUgcHJvb2YgcGFnZSwgd2hvc2Ugd2hvbGUgcG9pbnQgaXMgcGxhbnRlZCBjb2RlIHRoYXRcbiAgLy8gbXVzdCBOT1QgZXhlY3V0ZTogb24gdGhlIGNvbXBpbGVkIHBhdGggdGhhdCBwYWdlIGRvZXNuJ3QganVzdCBsb29rIHdyb25nLCBpdCBydW5zXG4gIC8vIChSMy0yNTIpLiBBIGRvY3VtZW50IHRoYXQgaXMgb25seSBjb3JyZWN0IGFzIGRhdGEgc2F5cyBzbyBpdHNlbGYuXG4gIGNvbnN0IHNhZmU6IGJvb2xlYW4gPSByZXNvbHZlU2FmZVJlbmRlcihob21lTWV0YSwgbWV0YSk7XG4gIGNvbnN0IHNob3dSYWlscyA9IGxheW91dCA9PT0gJ2RvYycgJiYgIW1ldGE/LnZpZXc7XG5cblxuICAvLyBBc2sgdGhlIGZpbGVzeXN0ZW0gb25seSBhYm91dCBhIGtleSB0aGUgRU5UUlkgaW5kZXggYWxyZWFkeSBtaXNzZWQ6IGFuIG9yZGluYXJ5IHBhZ2VcbiAgLy8gcmVuZGVyIHBlcmZvcm1zIG5vIGV4dHJhIEkvTywgYW5kIHRoaXMgcmVhZGRpciByZXBsYWNlcyBhIDQwNCB0aGF0IHdhcyBhYm91dCB0b1xuICAvLyByZW5kZXIgYW55d2F5LiBUaGUgaW5kZXggY2Fubm90IGFuc3dlciBpdCDigJQgaXQgaG9sZHMgYC5tZGAvYC5tZHhgIG9ubHksIHNvIGEgZm9sZGVyXG4gIC8vIG9mIGFzc2V0cyBpcyBpbnZpc2libGUgdG8gaXQuXG4gIGNvbnN0IHVucmVzb2x2ZWQgPSBpbmRleExvYWRlZCAmJiAha2V5cy5pbmNsdWRlcyhlbnRyeUtleSk7XG4gIGNvbnN0IGRpcmVjdG9yeSA9IHVzZURpcmVjdG9yeUxpc3RpbmcodW5yZXNvbHZlZCA/IGVudHJ5S2V5IDogbnVsbCk7XG4gIGNvbnN0IG1pc3NpbmcgPSB1bnJlc29sdmVkICYmIGRpcmVjdG9yeS5zdGF0dXMgPT09ICdub25lJztcblxuICAvLyBUaGUgbGF5b3V0IGNoYWluIHdyYXBwaW5nIHRoaXMgZW50cnkgKG91dGVybW9zdCBmaXJzdCkuIE5lZWRzIHRoZSBmdWxsXG4gIC8vIGZyb250bWF0dGVyIG1hcCAoZm9sZGVyIGNvbnZlbnRpb24gKyBgZnJhbWVgIG92ZXJyaWRlKSwgc28gaXQgcmVhZHMgdGhlIHdob2xlXG4gIC8vIG1ldGFkYXRhIHN0b3JlIGFuZCByZS1kZXJpdmVzIHdoZW4gdGhlIGNvbnRlbnQgc2V0IG9yIHRoZSBlbnRyeSBjaGFuZ2VzLlxuICBjb25zdCBhbGxNZXRhID0gdXNlQWxsTWV0YWRhdGEoKSBhcyBSZWNvcmQ8c3RyaW5nLCBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPj47XG5cbiAgLy8g4pSA4pSAIENvbnRlbnQtY2FycmllZCB0aGVtZXMgKFIzLTMxNjsgTURYX0ZST01fTU9VTlRfU1BFQyBENykg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIC8vIFRoZSBzdHlsZXNoZWV0cyB0aGUgaG9tZSBlbnRyeSBkZWNsYXJlcyAoYHN0eWxlc2hlZXRzOmApOyBib2RpZXMgYXJlIHJhdyBDU1NcbiAgLy8gYmVoaW5kIGZyb250bWF0dGVyLCBnYXRlZCBieSB0aGUgZ3JhbW1hciBpbnNpZGUgQ29udGVudFRoZW1lIGFuZCBhZG1pdHRlZCBvbmx5XG4gIC8vIGludG8gdGhlIGxvd2VzdCBjYXNjYWRlIGxheWVyLiBBIGRlY2xhcmF0aW9uIHRoYXQgbmFtZXMgbm8gZW50cnksIGEgc2hlZXQgdGhhdFxuICAvLyB3aWxsIG5vdCByZWFkLCBhbmQgYSBzaGVldCB0aGUgZ3JhbW1hciByZWplY3RzIGFsbCBkZWdyYWRlIHRvIGEgc3RhdHVzIGxpbmVcbiAgLy8gbmFtaW5nIGl0IOKAlCBuZXZlciBhIHNpbGVudCBkcm9wLCBuZXZlciBhIGNyYXNoLlxuICBjb25zdCBzdHlsZXNoZWV0cyA9IHVzZUNvbnRlbnRTdHlsZXNoZWV0cyhob21lTWV0YT8uc3R5bGVzaGVldHMsIGhvbWVLZXkoKSk7XG4gIGNvbnN0IFtyZWplY3RlZFNoZWV0LCBzZXRSZWplY3RlZFNoZWV0XSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICBjb25zdCBzaGVldEVycm9ycyA9IHJlamVjdGVkU2hlZXQgPyBbLi4uc3R5bGVzaGVldHMuZXJyb3JzLCByZWplY3RlZFNoZWV0XSA6IHN0eWxlc2hlZXRzLmVycm9ycztcblxuICAvLyDilIDilIAgVGhlIGVudHJ5IGdhdGUgKE1EWF9GUk9NX01PVU5UX1NQRUMgRDgpIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAvLyBVbmRlciBkaXNwYXRjaCB0aGUgaW5kZXggZmlsbHMgaW4gd2hpbGUgdGhlIHdpa2kgaXMgYWxyZWFkeSBvbiBzY3JlZW4uIFRoZSBmaWxlc1xuICAvLyB0aGF0IGRlY2lkZSBob3cgVEhJUyBlbnRyeSByZW5kZXJzIOKAlCBpdHNlbGYsIGhvbWUsIGl0cyBsYXlvdXRzLCBpdHMgYGZyYW1lOmAg4oCUIGFyZVxuICAvLyByZWFkIGFoZWFkIG9mIHRoZSByZXN0LCBhbmQgdGhlIGJvZHkgd2FpdHMgZm9yIHRoZW06IGFuIHVucmVhZCByb3cgcmVhZHMgYXNcbiAgLy8gYHJlbmRlcmAgdW5zZXQsIHdoaWNoIGlzIHRoZSBleGVjdXRpbmcgcGF0aC4gVGhlIGNocm9tZSBhcm91bmQgaXQgc3RheXMgbW91bnRlZC5cbiAgLy8gUjMtODcyOiB0aGUgZW50cnkgZ2F0ZSAocHJpb3JpdGl6ZS9wZW5kaW5nL2ZhaWx1cmUpIGFuZCB0aGUgc2FmZSBkZXJpdmF0aW9uXG4gIC8vIG1vdmVkIGludG8gR3JvdmVFbnRyeSdzIGNoYWluIGZyYW1lIOKAlCBHcm92ZVdpa2kga2VlcHMgb25seSB3aGF0IHRoZSBjaHJvbWVcbiAgLy8gcmVhZHMgKG5hdk1vZGUncyByb290LWxheW91dCBsb29rdXAgbmVlZHMgdGhlIGNoYWluJ3Mgb3V0ZXJtb3N0IGtleSkuXG4gIGNvbnN0IGNoYWluOiBzdHJpbmdbXSA9IGxheW91dENoYWluRm9yS2V5KGVudHJ5S2V5LCBhbGxNZXRhKTtcbiAgY29uc3QgZnJhbWVOb25lID0gbWV0YT8uZnJhbWUgPT09ICdub25lJyB8fCBtZXRhPy5mcmFtZSA9PT0gZmFsc2U7XG5cbiAgLy8gUjMtMzA5IOKAlCB0aGUgbmF2IGFycmFuZ2VtZW50IGlzIHRoZSBST09UIGxheW91dCdzIHRvIGNob29zZSAoYG5hdjogdG9wYCBpbiB0aGVcbiAgLy8gb3V0ZXJtb3N0IF9sYXlvdXQubWR4J3MgZnJvbnRtYXR0ZXI7IHRoZSBkZWZhdWx0IHNoZWxsIGFuZCB0aGUgc3RhcnRlcnMgcmVhZCB0aGVcbiAgLy8gc2FtZSB2YWx1ZSB0aHJvdWdoIHRoZSBzaGVsbCkuIFVuZGVjbGFyZWQgb3IgdW5rbm93biDihpIgJ3NpZGUnLCB0aGUgYXJyYW5nZW1lbnRcbiAgLy8gR3JvdmUgaGFzIGFsd2F5cyBzaGlwcGVkIOKAlCBuZXZlciBhbiB1bnN0eWxlZCBwYWdlLlxuICBjb25zdCBuYXZNb2RlID0gcmVzb2x2ZU5hdk1vZGUoY2hhaW4ubGVuZ3RoID8gKGFsbE1ldGFbY2hhaW5bMF0hXSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikgOiB1bmRlZmluZWQpO1xuICAvLyBFdmVyeSBuYXZpZ2F0aW9uIHN0YXJ0cyBhdCB0aGUgdG9wIG9mIHRoZSBlbnRyeSwgZXhjZXB0IG9uZSBhaW1lZCBhdCBhIHNlY3Rpb24uIFRoZVxuICAvLyByZWYgZ29lcyBvbiBgLmRldmljZV9fc2Nyb2xsYCBiZWxvdyDigJQgdGhlIG9ubHkgdGhpbmcgb24gdGhlIHBhZ2UgdGhhdCBzY3JvbGxzLlxuICBjb25zdCBzY3JvbGxSZWYgPSB1c2VTY3JvbGxSZXNldChlbnRyeUtleSwgaGFzaCk7XG5cbiAgLy8gUmVhZGluZyB0aW1lOiByZWFkIHRoZSBlbnRyeSBib2R5IG9uY2UgcGVyIGVudHJ5LlxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGxldCBhY3RpdmUgPSB0cnVlO1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9zZXQtc3RhdGUtaW4tZWZmZWN0XG4gICAgc2V0TWlucygwKTtcbiAgICBmcy5wcm9taXNlc1xuICAgICAgLnJlYWRGaWxlKGtleVRvRnNQYXRoKGVudHJ5S2V5KSwgJ3V0ZjgnKVxuICAgICAgLnRoZW4oKGI6IHVua25vd24pID0+IHtcbiAgICAgICAgaWYgKGFjdGl2ZSkgc2V0TWlucyhyZWFkaW5nVGltZShzdHJpcEZyb250bWF0dGVyKFN0cmluZyhiKSkpKTtcbiAgICAgIH0pXG4gICAgICAuY2F0Y2goKCkgPT4gdW5kZWZpbmVkKTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgYWN0aXZlID0gZmFsc2U7XG4gICAgfTtcbiAgfSwgW2VudHJ5S2V5XSk7XG5cbiAgLy8gUmVjb3Jkcywgbm90IHRhYi1lbmNvZGVkIHBhdGhzIChSMy0yNzZhKTogdGhlIHF1ZXJ5IHNlbGVjdHMgYHsgcGF0aCwgbGFiZWwgfWBcbiAgLy8gYW5kIHRoZSBob29rIHJldHVybnMgdGhlbSBhcy1pcyDigJQgbm8gZmFrZS1wYXRoIGVuY29kaW5nIHJvdW5kLXRyaXAuXG4gIGNvbnN0IG5hdlJlc3VsdCA9IHVzZU1ldGFkYXRhUXVlcnk8TWV0YWRhdGEsIE5hdlJlY29yZD4obmF2UXVlcnkpO1xuICBjb25zdCBuYXZJdGVtczogTmF2SXRlbVtdID0gcXVlcnlSZWNvcmRzPE5hdlJlY29yZD4obmF2UmVzdWx0KS5tYXAoKHsgcGF0aCwgbGFiZWwgfSkgPT4gKHtcbiAgICBrZXk6IHBhdGgsXG4gICAgaHJlZjoga2V5VG9IcmVmKHBhdGgpLFxuICAgIGxhYmVsLFxuICB9KSk7XG5cbiAgLy8gQ2xvc2VzdC1tYXRjaCBzdWdnZXN0aW9uIGZvciBhIDQwNCAoc2hhcmVkIG5hbWVzcGFjZSBvciBuYW1lIG92ZXJsYXApLlxuICBjb25zdCBzdWdnZXN0aW9uID0gbWlzc2luZ1xuICAgID8ga2V5c1xuICAgICAgICAubWFwKChrKSA9PiAoeyBrLCBzY29yZTogb3ZlcmxhcChrLCBlbnRyeUtleSkgfSkpXG4gICAgICAgIC5zb3J0KChhLCBiKSA9PiBiLnNjb3JlIC0gYS5zY29yZSlbMF0/LmtcbiAgICA6IHVuZGVmaW5lZDtcblxuICBjb25zdCBzaGVsbDogR3JvdmVTaGVsbCA9IHtcbiAgICB0aGVtZSxcbiAgICBzZXRUaGVtZTogY2hvb3NlVGhlbWUsXG4gICAgbGlnaHQsXG4gICAgc2V0TGlnaHQ6IGNob29zZVBvbGFyaXR5LFxuICAgIG1lbnVPcGVuLFxuICAgIHNldE1lbnVPcGVuLFxuICAgIHNlYXJjaE9wZW4sXG4gICAgc2V0U2VhcmNoT3BlbixcbiAgICBkcmF3ZXJPcGVuLFxuICAgIHNldERyYXdlck9wZW4sXG4gICAgdncsXG4gICAgbmF2TW9kZSxcbiAgICB3cml0YWJsZSxcbiAgICBvcGVuRWRpdG9yLFxuICAgIGVkaXRCdXN5LFxuICAgIGVkaXRSZWZ1c2VkLFxuICAgIGVkaXRIaW50LFxuICAgIHNpdGVUaXRsZSxcbiAgICBzYWZlLFxuICAgIG5hdkl0ZW1zLFxuICAgIGVudHJ5S2V5LFxuICAgIGluY2x1ZGVQYXRoLFxuICAgIGxheW91dCxcbiAgICBzaG93UmFpbHMsXG4gICAgbWlucyxcbiAgICBtaXNzaW5nLFxuICAgIHN1Z2dlc3Rpb24sXG4gICAgZGlyZWN0b3J5LFxuICAgIHN0eWxlc2hlZXRzU3RhdHVzOiBzdHlsZXNoZWV0cy5zdGF0dXMsXG4gIH07XG5cbiAgLy8gVGhlIGJ1bmRsZSBzY29wZSBoYW5kZWQgdG8gQ09OVEVOVCAoUjMtMTc0OyBNRFhfRlJPTV9NT1VOVF9TUEVDIMKnMiwgwqc3IDFhKS5cbiAgLy9cbiAgLy8gQSBjb21wb25lbnQgdGhlIGJ1bmRsZSBzaGlwcyBjYW5ub3QgaW1wb3J0IHRoaXMgZW5naW5lIOKAlCBpdCB3b3VsZCByZXNvbHZlIGEgc2Vjb25kXG4gIC8vIGNvcHkgZnJvbSB0aGUgcmVnaXN0cnksIHdpdGggaXRzIG93biBgY29udGVudFJvb3RgIG1vZHVsZSBzdGF0ZSwgYW5kIGFuc3dlciBhYm91dCB0aGVcbiAgLy8gd3JvbmcgYnVuZGxlIOKAlCBzbyBldmVyeXRoaW5nIGl0IG5lZWRzIGFib3V0IHRoZSBidW5kbGUgYXJyaXZlcyB0aHJvdWdoIHRoZSBTREssIHdoaWNoXG4gIC8vIGJvdGggc2lkZXMgZ2VudWluZWx5IHNoYXJlIChvbmUgYC9ub2RlX21vZHVsZXNgIHBlciBmcmFtZSkuIFRocmVlIGZhY3RzLCBhbmQgZWFjaCBpc1xuICAvLyBvbmUgYSBjb250ZW50IGNvbXBvbmVudCBjYW5ub3QgZGVyaXZlIGZvciBpdHNlbGY6XG4gIC8vXG4gIC8vICDigKIgYHJvb3RgIOKAlCBzbyBtZXRhZGF0YSBrZXlzIGNhbiBiZSByZWJhc2VkIG9mZiB0aGUgbW91bnQgcHJlZml4LiBDb250ZW50IG11c3QgbmV2ZXJcbiAgLy8gICAgc2VlIGAvbW50LzxoYXNoPi/igKZgOiBpdCBpcyBob3N0IGtub3dsZWRnZSB0aGUgdmlld2VyIHJlYWRzIFRIUk9VR0ggYnV0IGRvZXMgbm90XG4gIC8vICAgIHB1Ymxpc2ggKHRoZSBwcm9wZXJ0eSBgRGlyZWN0b3J5TGlzdC50ZXN0LnRzeGAgcGlucyksIGFuZCBpdCBpcyBub3Qgc3RhYmxlIGFjcm9zc1xuICAvLyAgICBsb2Fkcywgc28gYW55dGhpbmcgY29udGVudCBzdG9yZWQgb3IgbGlua2VkIHdpdGggaXQgd291bGQgcm90LlxuICAvLyAg4oCiIGBlbnRyeWAg4oCUIHRoZSBlbnRyeSBiZWluZyBSRUFELCBub3QgdGhlIGZpbGUgdGhlIGNvbXBvbmVudCBzaXRzIGluLiBBIGNvbXBvbmVudCBpblxuICAvLyAgICBhIGBfbGF5b3V0Lm1keGAgd3JhcHMgdGhlIGVudHJ5LCBzbyBgPEluY2x1ZGU+YCdzIG93biBtb2R1bGUgaWRlbnRpdHkgd291bGQgbmFtZVxuICAvLyAgICB0aGUgbGF5b3V0OyBmdXJuaXR1cmUgaW4gdGhlIGxheW91dCBjaGFpbiAoYSBzdGF0dXMgbGluZSwgYSBkZXBlbmRlbmN5IHJhaWwpIG5lZWRzXG4gIC8vICAgIHRoZSBwYWdlIGl0IGlzIGRlc2NyaWJpbmcuXG4gIC8vICDigKIgYHRvSHJlZmAg4oCUIGJlY2F1c2UgYnVuZGxlLXBhdGjihpJVUkwgaXMgdGhpcyBWSUVXRVIncyBwb2xpY3kgYW5kIHRoZSB0d28gcGFja2FnaW5nc1xuICAvLyAgICBnZW51aW5lbHkgZGlzYWdyZWUgKGB1cmxBbmNob3JgKS4gQ29udGVudCB0aGF0IGNvbXB1dGVkIGl0cyBvd24gaHJlZnMgd291bGQgYmVcbiAgLy8gICAgY29ycmVjdCBpbiBleGFjdGx5IG9uZSBwYWNrYWdpbmcsIHdoaWNoIGlzIHRoZSBtb2RlLWludmFyaWFuY2UgcnVsZVxuICAvLyAgICAoUExBVEZPUk1fTEFZRVJJTkcgwqcxLjEpIGJyb2tlbiBpbiB0aGUgbGVhc3QgdmlzaWJsZSBwb3NzaWJsZSB3YXkuXG4gIC8vIGBjb250ZW50Um9vdGAgaXMgbW9kdWxlIHN0YXRlIHNldHRsZWQgYXQgYm9vdCwgc28gaXQgaXMgcmVhZCBoZXJlIOKAlCBpbnRvIGEgbG9jYWwgdGhlXG4gIC8vIG1lbW8gY2FuIGxpc3QgYXMgYSBkZXBlbmRlbmN5IOKAlCByYXRoZXIgdGhhbiBpbnNpZGUgdGhlIGZhY3RvcnkuIENhbGxpbmcgaXQgaW5zaWRlXG4gIC8vIHdvdWxkIGNsb3NlIG92ZXIgYSB2YWx1ZSB0aGUgZGVwZW5kZW5jeSBsaXN0IGRvZXMgbm90IG5hbWUsIHdoaWNoIHRoZSBSZWFjdCBDb21waWxlclxuICAvLyBjb3JyZWN0bHkgcmVmdXNlcyB0byBwcmVzZXJ2ZSBtZW1vaXphdGlvbiBhY3Jvc3MuXG4gIC8vIEJ1aWx0IGZyZXNoIGVhY2ggcmVuZGVyLCBsaWtlIGV2ZXJ5dGhpbmcgZWxzZSBpbiB0aGlzIGNvbXBvbmVudCDigJQgbm8gaGFuZC1tZW1vaXphdGlvblxuICAvLyAodGhlIHJlc3Qgb2YgdGhlIGZpbGUgaGFzIG5vbmUgZWl0aGVyOyBgcmVhY3QtaG9va3MvcHJlc2VydmUtbWFudWFsLW1lbW9pemF0aW9uYFxuICAvLyByZWplY3RzIG9uZSBoZXJlIGJlY2F1c2UgYGVudHJ5S2V5YCBkZXJpdmVzIGZyb20gdGhlIG1ldGFkYXRhIHF1ZXJ5J3MgYXJyYXkpLlxuICAvL1xuICAvLyBUaGF0IGlzIHNhZmUgYmVjYXVzZSB0aGUgRVhQRU5TSVZFIGhhbGYgZG9lcyBub3Qga2V5IG9uIHRoaXMgb2JqZWN0J3MgaWRlbnRpdHk6IHRoZVxuICAvLyBTREsncyBgdXNlQnVuZGxlRW50cmllc2AgZGVzdHJ1Y3R1cmVzIGB7cm9vdCwgdG9IcmVmfWAgYW5kIG1lbW9pemVzIG9uIHRob3NlLCBhbmQgYm90aFxuICAvLyBhcmUgc3RhYmxlIOKAlCBgcm9vdGAgaXMgYSBzdHJpbmcgY29tcGFyZWQgYnkgdmFsdWUsIGB0b0hyZWZgIGlzIHRoZSBtb2R1bGUtc2NvcGVcbiAgLy8gYGJ1bmRsZUhyZWZgIGFib3ZlLiBBIG5ldyB3cmFwcGVyIHJlLXJlbmRlcnMgY29uc3VtZXJzIChjaGVhcCk7IGl0IGRvZXMgbm90IHJlLWRlcml2ZVxuICAvLyA4MDAtb2RkIGVudHJpZXMuIE1ha2luZyBgdG9IcmVmYCBhIGNsb3N1cmUgd291bGQgc2lsZW50bHkgdW5kbyB0aGF0LCB3aGljaCBpcyB0aGVcbiAgLy8gd2hvbGUgcmVhc29uIGl0IGlzIG5vdCBvbmUuXG4gIGNvbnN0IGJ1bmRsZVJvb3QgPSBjb250ZW50RGlyKCkucmVwbGFjZSgvXFwvKyQvLCAnJyk7XG4gIGNvbnN0IGJ1bmRsZUVudHJ5ID0gdG9CdW5kbGVQYXRoKGVudHJ5S2V5LCBidW5kbGVSb290KTtcbiAgY29uc3QgYnVuZGxlU2NvcGUgPSB7IHJvb3Q6IGJ1bmRsZVJvb3QsIGVudHJ5OiBidW5kbGVFbnRyeSwgdG9IcmVmOiBidW5kbGVIcmVmIH07XG5cbiAgcmV0dXJuIChcbiAgICAvLyBSMy0yNzdiOiBkZWNsYXJlIHRoZSBlbmNsb3NpbmcgYnVuZGxlIGZvciB0aGUgcGxhdGZvcm0ncyBsaW5rLXNwYWNlIGNvbnN1bWVyc1xuICAgIC8vICh0aGUgc2hhcmVkIHJlc29sdmVyJ3MgYnVuZGxlLWFuY2hvcmVkIGFic29sdXRlICsgYCRmczpgIGhhbmRsaW5nIHJlYWQgdGhpcykuXG4gICAgLy8gUjMtNDgyOiB0aGUgU0RLIHBpbiAoc2luY2UgXjAuNzIuMCwgIzc1KSByZWFkcyBgYnVuZGxlUm9vdGAgbmV3LXRoZW4tb2xkLCBzbyB0aGVcbiAgICAvLyBuZXcgc3BlbGxpbmcgaXMgc3RhdGVkIGFsb25lIOKAlCB0aGUgZGVwcmVjYXRlZCBgY29ycHVzUm9vdGAgc3RheXMgaW4gdGhlIHR5cGUgZm9yXG4gICAgLy8gb2xkZXIgY29uc3VtZXJzIChtZHgtcGx1Z2lucycgZm9yZXZlci1jb21wYXQpIGJ1dCBubyBsb25nZXIgaGVyZS5cbiAgICA8TGlua1NwYWNlQ29udGV4dC5Qcm92aWRlclxuICAgICAgdmFsdWU9e3tcbiAgICAgICAgYnVuZGxlUm9vdDogZ2V0Q29udGVudFJvb3QoKSxcbiAgICAgICAgLy8gUjMtMTg0IFMyIChQRVJTSVNURU5DRV9TUEVDIMKnOC4zKSDigJQgdGhlIGAkZnM6YCBjbGFtcCwgb24gdGhpcyByZW5kZXIgcGF0aC5cbiAgICAgICAgLy8gVGhlIGNsYW1wIHRoYXQgaXMgSU4gRk9SQ0UgbGl2ZXMgaW4gYGxpYi9jb250ZW50LnRzYCAoYGxpbmtTcGFjZU9wdHNgKTpcbiAgICAgICAgLy8gYGhyZWZUYXJnZXRLZXlgIGlzIHdoZXJlIGEgY29ycHVzIGRvY3VtZW50J3MgbGluayB0YXJnZXRzIGFjdHVhbGx5XG4gICAgICAgIC8vIHJlc29sdmUgKGdyb3ZlJ3Mgb3duIFdpa2lMaW5rIG92ZXJyaWRlIHJvdXRlcyB0aGVyZSksIGFuZCBpdCBwYXNzZXNcbiAgICAgICAgLy8gYGJ1bmRsZUNocm9vdGVkOiBpc0Rpc3BhdGNoZWQoKWAgdG8gdGhlIHNoYXJlZCByZXNvbHZlciAoUjMtMzE5J3NcbiAgICAgICAgLy8gY2hyb290KSwgc28gYSBkaXNwYXRjaGVkIGNvcnB1cyBkb2N1bWVudCdzIGAkZnM6L21udC97aGFzaH0v4oCmYCBjYW5ub3RcbiAgICAgICAgLy8gbmFtZSBhIGZlZGVyYXRlZCBtb3VudCBtYXRlcmlhbGlzZWQgYmVzaWRlIGl0IOKAlCB0aGUgYXBwLWxldmVsIG1vdW50XG4gICAgICAgIC8vIHBvaW50IGlzIG5vdCBhIGNvcnB1cyBwYXRoIOKAlCBhbmQgdGhlIGZvcmsncyBgJGZzOmAgc3RheXNcbiAgICAgICAgLy8gbW91bnQtYWJzb2x1dGUuIFRoaXMgZmllbGQgY2FycmllcyB0aGUgc2FtZSBmbGFnIGZvciB0aGUgU0RLJ3MgZ2VuZXJpY1xuICAgICAgICAvLyBjb21wb25lbnQgY29uc3VtZXJzIChXaWtpTGluay9NRFhDb21wb25lbnRzKSDigJQgY29uc3VtZWQgc2luY2UgdGhlXG4gICAgICAgIC8vIDAuNzkuMCBwaW4gKFIzLTc4Myk6IHRob3NlIGNvbXBvbmVudHMgZm9yd2FyZCBpdCB0byB0aGUgc2hhcmVkXG4gICAgICAgIC8vIHJlc29sdmVyLCBzbyB0aGUgY2xhbXAgaXMgbG9hZC1iZWFyaW5nIG9uIHRoZSBnZW5lcmljIHBhdGggdG9vLlxuICAgICAgICBidW5kbGVDaHJvb3RlZDogaXNEaXNwYXRjaGVkKCksXG4gICAgICB9fVxuICAgID5cbiAgICB7LyogUjMtMTc0OiB0aGUgYnVuZGxlIHNjb3BlIENPTlRFTlQgcmVhZHMg4oCUIHNpYmxpbmcgdG8gdGhlIGxpbmsgc3BhY2UsIG5vdCBhXG4gICAgICAgIHJlcGxhY2VtZW50IGZvciBpdC4gVGhlIHR3byBhbnN3ZXIgZGlmZmVyZW50IHF1ZXN0aW9uczogYExpbmtTcGFjZUNvbnRleHRgIHRlbGxzXG4gICAgICAgIHRoZSBwbGF0Zm9ybSdzIGxpbmsgcmVzb2x2ZXIgd2hlcmUgYWJzb2x1dGUgaHJlZnMgYXJlIGFuY2hvcmVkOyBgQnVuZGxlQ29udGV4dGBcbiAgICAgICAgdGVsbHMgYSBjb21wb25lbnQgdGhlIGJ1bmRsZSBzaGlwcyB3aGljaCBlbnRyaWVzIGV4aXN0LCB3aGljaCBvbmUgaXMgYmVpbmcgcmVhZCxcbiAgICAgICAgYW5kIGhvdyB0byB0dXJuIGEgYnVuZGxlIHBhdGggaW50byBhIFVSTC4gKi99XG4gICAgPEJ1bmRsZUNvbnRleHQgdmFsdWU9e2J1bmRsZVNjb3BlfT5cbiAgICA8R3JvdmVTaGVsbENvbnRleHQuUHJvdmlkZXIgdmFsdWU9e3NoZWxsfT5cbiAgICAgIDxkaXZcbiAgICAgICAgY2xhc3NOYW1lPVwiZ3JvdmUtcm9vdFwiXG4gICAgICAgIGRhdGEtdnc9e3Z3fVxuICAgICAgICBkYXRhLW5hdj17bmF2TW9kZX1cbiAgICAgICAgZGF0YS1ncm92ZS10aGVtZT17dGhlbWUgPT09ICdkZWZhdWx0JyA/IHVuZGVmaW5lZCA6IHRoZW1lfVxuICAgICAgICBkYXRhLXRoZW1lPXtwb2xhcml0eX1cbiAgICAgID5cbiAgICAgICAgey8qIFIzLTMxMDogdGhlIEFDVElWRSB0aGVtZSdzIGRlY2xhcmVkIGZhY2VzIOKAlCB0aGUgZW5naW5lIG1pbnRzIGJsb2I6XG4gICAgICAgICAgICBAZm9udC1mYWNlIHJ1bGVzIChSMy0zMTUncyBtZWNoYW5pc20pOyBzd2l0Y2hpbmcgdGhlbWVzIHJldm9rZXMgdGhlXG4gICAgICAgICAgICBvdXRnb2luZyBzZXQgYW5kIHJlLW1pbnRzLiAqL31cbiAgICAgICAgPFRoZW1lQXNzZXRzIGRlY2xhcmF0aW9ucz17dGhlbWVBc3NldHNGb3IodGhlbWUpfSAvPlxuICAgICAgICA8Q29udGVudFRoZW1lIHNoZWV0cz17c3R5bGVzaGVldHMuc2hlZXRzfSBvblJlamVjdGVkPXsocGF0aCwgdikgPT4gc2V0UmVqZWN0ZWRTaGVldChgJHtwYXRofToke3YubGluZX0g4oCUICR7di5yZWFzb259YCl9IC8+XG4gICAgICAgIHsvKiBSMy02Mjc6IHJlbWVtYmVyIHdoZXJlIHRoZSByZWFkZXIgd2FzIG9uIHRoZSBlbnRyeSB0aGV5IGxlYXZlLCBhbmQgcHV0XG4gICAgICAgICAgICB0aGVtIGJhY2sgdGhlcmUgb24gQmFjay4gR3JvdmUncyBzY3JvbGxlciBpcyBpdHMgb3duIGNvbnRhaW5lciwgc28gdGhlXG4gICAgICAgICAgICByZWYgZ29lcyBhY3Jvc3M7IGB1c2VTY3JvbGxSZXNldGAgYWJvdmUgc3RhbmRzIGRvd24gb24gdGhlIHNhbWVcbiAgICAgICAgICAgIHRyYXZlcnNhbCBzbyB0aGUgdHdvIGRvIG5vdCBmaWdodC4gKi99XG4gICAgICAgIDxTY3JvbGxSZXN0b3JhdGlvbiBzY3JvbGxlcj17c2Nyb2xsUmVmfSAvPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRldmljZV9fc2Nyb2xsXCIgcmVmPXtzY3JvbGxSZWZ9PlxuICAgICAgICAgIHtzaGVldEVycm9ycy5sZW5ndGggPiAwID8gKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncm92ZS1kZWNsLWVycm9yXCIgcm9sZT1cInN0YXR1c1wiPlxuICAgICAgICAgICAgICA8c3Ryb25nPkEgc3R5bGVzaGVldCB0aGlzIGNvcnB1cyBkZWNsYXJlcyBjb3VsZCBub3QgYmUgYXBwbGllZC48L3N0cm9uZz5cbiAgICAgICAgICAgICAgPHVsPlxuICAgICAgICAgICAgICAgIHtzaGVldEVycm9ycy5tYXAoKGUsIGkpID0+IChcbiAgICAgICAgICAgICAgICAgIDxsaSBrZXk9e2l9PntlfTwvbGk+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApIDogbnVsbH1cbiAgICAgICAgICB7cmVqZWN0ZWRDb21wb25lbnRzLmxlbmd0aCA+IDAgPyAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyb3ZlLWRlY2wtZXJyb3JcIiByb2xlPVwic3RhdHVzXCI+XG4gICAgICAgICAgICAgIDxzdHJvbmc+VGhpcyBjb3JwdXMgZGVjbGFyZXMgY29tcG9uZW50cyB0aGF0IGNvdWxkIG5vdCBiZSBsb2FkZWQuPC9zdHJvbmc+XG4gICAgICAgICAgICAgIDx1bD5cbiAgICAgICAgICAgICAgICB7cmVqZWN0ZWRDb21wb25lbnRzLm1hcCgocikgPT4gKFxuICAgICAgICAgICAgICAgICAgPGxpIGtleT17ci5uYW1lfT5cbiAgICAgICAgICAgICAgICAgICAgPGNvZGU+e3IubmFtZX08L2NvZGU+IOKAlCB7ci5yZWFzb259XG4gICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L3VsPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSA6IG51bGx9XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncm92ZS1zaGVsbFwiIGRhdGEtbmF2PXtmcmFtZU5vbmUgPyB1bmRlZmluZWQgOiBuYXZNb2RlfT5cbiAgICAgICAgICAgIHsvKiBSMy04NzI6IHRoZSBlbnRyeSByZWdpb24gaXMgR3JvdmVFbnRyeSDigJQgdGhlIGNoYWluLCB0aGUgZ2F0ZSBhbmQgdGhlXG4gICAgICAgICAgICAgICAgZW50cnkgY29udGV4dCAoUjMtODcxKSBsaXZlIGluc2lkZSBpdCwgc28gYSBzaGVsbCBjb21wb3NpbmcgZW50cmllc1xuICAgICAgICAgICAgICAgIGRpcmVjdGx5IHJlbmRlcnMgdGhlIHNhbWUgdGhpbmcgKEFQUF9DVVNUT01JWkFUSU9OIMKnNC4xKS4gKi99XG4gICAgICAgICAgICA8R3JvdmVFbnRyeSBlbnRyeUtleT17ZW50cnlLZXl9IGZyYW1lPXtmcmFtZU5vbmUgPyAnbm9uZScgOiAnY2hhaW4nfSAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7c2VhcmNoT3BlbiA/IDxTZWFyY2ggb25DbG9zZT17KCkgPT4gc2V0U2VhcmNoT3BlbihmYWxzZSl9IC8+IDogbnVsbH1cbiAgICAgICAge2RyYXdlck9wZW4gPyAoXG4gICAgICAgICAgPERyYXdlclxuICAgICAgICAgICAgc2l0ZVRpdGxlPXtzaXRlVGl0bGV9XG4gICAgICAgICAgICBuYXY9e25hdkl0ZW1zLm1hcCgobikgPT4gKHsga2V5OiBuLmtleSwgaHJlZjogbi5ocmVmLCBsYWJlbDogbi5sYWJlbCwgY3VyOiBuLmtleSA9PT0gZW50cnlLZXkgfSkpfVxuICAgICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0RHJhd2VyT3BlbihmYWxzZSl9XG4gICAgICAgICAgLz5cbiAgICAgICAgKSA6IG51bGx9XG4gICAgICAgIDxHcm92ZUFnZW50IHdyaXRhYmxlPXt3cml0YWJsZX0gZW50cnlLZXk9e2VudHJ5S2V5fSBlbnRyeVRpdGxlPXtwbGFpbkxhYmVsKG1ldGE/LnRpdGxlIHx8ICd0aGlzIGVudHJ5Jyl9IC8+XG4gICAgICA8L2Rpdj5cbiAgICA8L0dyb3ZlU2hlbGxDb250ZXh0LlByb3ZpZGVyPlxuICAgIDwvQnVuZGxlQ29udGV4dD5cbiAgICA8L0xpbmtTcGFjZUNvbnRleHQuUHJvdmlkZXI+XG4gICk7XG59XG5cbi8vIENydWRlIGNsb3Nlc3QtbWF0Y2ggc2NvcmUgZm9yIHRoZSA0MDQgc3VnZ2VzdGlvbjogc2hhcmVkIG5hbWVzcGFjZSArIG5hbWUgY2hhcnMuXG5mdW5jdGlvbiBvdmVybGFwKGE6IHN0cmluZywgYjogc3RyaW5nKTogbnVtYmVyIHtcbiAgY29uc3QgYW4gPSBhLnJlcGxhY2UoY29udGVudERpcigpLCAnJykucmVwbGFjZSgvXFwubWR4PyQvLCAnJyk7XG4gIGNvbnN0IGJuID0gYi5yZXBsYWNlKGNvbnRlbnREaXIoKSwgJycpLnJlcGxhY2UoL1xcLm1keD8kLywgJycpO1xuICBjb25zdCBhTnMgPSBhbi5zcGxpdCgnLycpLnNsaWNlKDAsIC0xKS5qb2luKCcvJyk7XG4gIGNvbnN0IGJOcyA9IGJuLnNwbGl0KCcvJykuc2xpY2UoMCwgLTEpLmpvaW4oJy8nKTtcbiAgbGV0IHNjb3JlID0gYU5zICYmIGFOcyA9PT0gYk5zID8gNSA6IDA7XG4gIGNvbnN0IGFOYW1lID0gYW4uc3BsaXQoJy8nKS5wb3AoKSB8fCAnJztcbiAgY29uc3QgYk5hbWUgPSBibi5zcGxpdCgnLycpLnBvcCgpIHx8ICcnO1xuICBmb3IgKGNvbnN0IGNoIG9mIG5ldyBTZXQoYU5hbWUpKSBpZiAoYk5hbWUuaW5jbHVkZXMoY2gpKSBzY29yZSsrO1xuICByZXR1cm4gc2NvcmU7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUNBLElBQUFBLE1BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLEdBQUEsR0FBQUMsc0JBQUEsQ0FBQUYsT0FBQTtBQUVBLElBQUFHLElBQUEsR0FBQUgsT0FBQTtBQU9BLElBQUFJLGtCQUFBLEdBQUFKLE9BQUE7QUFDQSxJQUFBSyxVQUFBLEdBQUFMLE9BQUE7QUFDQSxJQUFBTSxPQUFBLEdBQUFOLE9BQUE7QUFDQSxJQUFBTyxRQUFBLEdBQUFQLE9BQUE7QUFTQSxJQUFBUSxLQUFBLEdBQUFSLE9BQUE7QUFDQSxJQUFBUyxRQUFBLEdBQUFULE9BQUE7QUFFQSxJQUFBVSxPQUFBLEdBQUFWLE9BQUE7QUFDQSxJQUFBVyxXQUFBLEdBQUFYLE9BQUE7QUFDQSxJQUFBWSxVQUFBLEdBQUFaLE9BQUE7QUFDQSxJQUFBYSxXQUFBLEdBQUFYLHNCQUFBLENBQUFGLE9BQUE7QUFDQSxJQUFBYyxlQUFBLEdBQUFkLE9BQUE7QUFDQSxJQUFBZSxPQUFBLEdBQUFmLE9BQUE7QUFDQSxJQUFBZ0Isb0JBQUEsR0FBQWhCLE9BQUE7QUFDQSxJQUFBaUIsZUFBQSxHQUFBakIsT0FBQTtBQUNBLElBQUFrQixrQkFBQSxHQUFBbEIsT0FBQTtBQUNBLElBQUFtQixZQUFBLEdBQUFuQixPQUFBO0FBRUEsSUFBQW9CLE1BQUEsR0FBQXBCLE9BQUE7QUFFQSxJQUFBcUIsT0FBQSxHQUFBbkIsc0JBQUEsQ0FBQUYsT0FBQTtBQUNBLElBQUFzQixPQUFBLEdBQUFwQixzQkFBQSxDQUFBRixPQUFBO0FBQ0EsSUFBQXVCLFdBQUEsR0FBQXJCLHNCQUFBLENBQUFGLE9BQUE7QUFDQSxJQUFBd0IsWUFBQSxHQUFBdEIsc0JBQUEsQ0FBQUYsT0FBQTtBQUNBLElBQUF5QixhQUFBLEdBQUF2QixzQkFBQSxDQUFBRixPQUFBO0FBQ0EsSUFBQTBCLFdBQUEsR0FBQTFCLE9BQUE7QUFDQSxJQUFBMkIsc0JBQUEsR0FBQTNCLE9BQUE7QUFBc0UsSUFBQTRCLFdBQUEsR0FBQTVCLE9BQUE7QUFBQSxJQUFBNkIsRUFBQSxHQUFBQyxZQUFBO0FBN0N0RTtBQUFBLFNBQUE1Qix1QkFBQTZCLENBQUEsV0FBQUEsQ0FBQSxJQUFBQSxDQUFBLENBQUFDLFVBQUEsR0FBQUQsQ0FBQSxLQUFBRSxPQUFBLEVBQUFGLENBQUE7QUErQ0EsU0FBU0csUUFBUUEsQ0FBQ0MsQ0FBUyxFQUFpQjtFQUMxQyxJQUFJO0lBQ0YsT0FBT0MsWUFBWSxDQUFDQyxPQUFPLENBQUNGLENBQUMsQ0FBQztFQUNoQyxDQUFDLENBQUMsTUFBTTtJQUNOLE9BQU8sSUFBSTtFQUNiO0FBQ0Y7QUFDQSxTQUFTRyxTQUFTQSxDQUFDSCxDQUFTLEVBQUVJLENBQVMsRUFBUTtFQUM3QyxJQUFJO0lBQ0ZILFlBQVksQ0FBQ0ksT0FBTyxDQUFDTCxDQUFDLEVBQUVJLENBQUMsQ0FBQztFQUM1QixDQUFDLENBQUMsTUFBTTtJQUNOO0VBQUE7QUFFSjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBU0UsVUFBVUEsQ0FBQ0MsVUFBa0IsRUFBVTtFQUM5QyxNQUFNQyxRQUFRLEdBQUcsSUFBQUMsc0JBQWMsRUFBQ0YsVUFBVSxFQUFFLElBQUFHLG1CQUFVLEVBQUMsQ0FBQyxDQUFDQyxPQUFPLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxDQUFDO0VBQzdFLE9BQU9ILFFBQVEsS0FBSyxJQUFJLEdBQUdELFVBQVUsR0FBRyxJQUFBSyxrQkFBUyxFQUFDSixRQUFRLENBQUM7QUFDN0Q7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ2UsU0FBU0ssU0FBU0EsQ0FBQztFQUNoQ0MsUUFBUSxHQUFHLEtBQUs7RUFDaEJDLGtCQUFrQixHQUFHO0FBT3ZCLENBQUMsRUFBRTtFQUFBckIsRUFBQTtFQUNELE1BQU1zQixHQUFHLEdBQUcsSUFBQUMsaUJBQVUsRUFBQ0Msb0NBQWlCLENBQVE7RUFDaEQsTUFBTUMsV0FBbUIsR0FBR0gsR0FBRyxFQUFFSSxlQUFlLEVBQUVELFdBQVcsSUFBSSxHQUFHO0VBQ3BFLE1BQU1FLElBQVksR0FBR0wsR0FBRyxFQUFFSSxlQUFlLEVBQUVDLElBQUksSUFBSSxFQUFFOztFQUVyRDtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNLENBQUNDLFdBQVcsRUFBRUMsY0FBYyxDQUFDLEdBQUcsSUFBQUMsZUFBUSxFQUFnQixNQUFNekIsUUFBUSxDQUFDLGFBQWEsQ0FBQyxDQUFDO0VBQzVGLE1BQU0sQ0FBQzBCLGdCQUFnQixFQUFFQyxtQkFBbUIsQ0FBQyxHQUFHLElBQUFGLGVBQVEsRUFBa0IsTUFBTTtJQUM5RSxNQUFNRyxDQUFDLEdBQUc1QixRQUFRLENBQUMsa0JBQWtCLENBQUM7SUFDdEMsT0FBTzRCLENBQUMsS0FBSyxPQUFPLElBQUlBLENBQUMsS0FBSyxNQUFNLEdBQUdBLENBQUMsR0FBRyxJQUFJO0VBQ2pELENBQUMsQ0FBQztFQUNGLE1BQU1DLFdBQVcsR0FBSUMsRUFBVSxJQUFLO0lBQ2xDTixjQUFjLENBQUNNLEVBQUUsQ0FBQztJQUNsQjFCLFNBQVMsQ0FBQyxhQUFhLEVBQUUwQixFQUFFLENBQUM7RUFDOUIsQ0FBQztFQUNELE1BQU1DLGNBQWMsR0FBSUMsU0FBa0IsSUFBSztJQUM3QyxNQUFNSixDQUFXLEdBQUdJLFNBQVMsR0FBRyxPQUFPLEdBQUcsTUFBTTtJQUNoREwsbUJBQW1CLENBQUNDLENBQUMsQ0FBQztJQUN0QnhCLFNBQVMsQ0FBQyxrQkFBa0IsRUFBRXdCLENBQUMsQ0FBQztFQUNsQyxDQUFDO0VBQ0Q7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU1LLE1BQU0sR0FBRyxPQUFPQyxNQUFNLEtBQUssV0FBVyxJQUFJQSxNQUFNLENBQUNDLE1BQU0sS0FBS0QsTUFBTTtFQUN4RSxNQUFNRSxTQUFTLEdBQUcsSUFBQUMsaUJBQVksRUFBQyxDQUFDO0VBQ2hDLE1BQU1DLFlBQTZCLEdBQUdMLE1BQU0sR0FBR0csU0FBUyxHQUFHLElBQUk7RUFDL0QsTUFBTSxDQUFDRyxRQUFRLEVBQUVDLFdBQVcsQ0FBQyxHQUFHLElBQUFmLGVBQVEsRUFBQyxLQUFLLENBQUM7RUFDL0MsTUFBTSxDQUFDZ0IsVUFBVSxFQUFFQyxhQUFhLENBQUMsR0FBRyxJQUFBakIsZUFBUSxFQUFDLEtBQUssQ0FBQztFQUNuRCxNQUFNLENBQUNrQixVQUFVLEVBQUVDLGFBQWEsQ0FBQyxHQUFHLElBQUFuQixlQUFRLEVBQUMsS0FBSyxDQUFDO0VBQ25ELE1BQU0sQ0FBQ29CLElBQUksRUFBRUMsT0FBTyxDQUFDLEdBQUcsSUFBQXJCLGVBQVEsRUFBQyxDQUFDLENBQUM7RUFDbkMsTUFBTSxDQUFDc0IsRUFBRSxFQUFFQyxLQUFLLENBQUMsR0FBRyxJQUFBdkIsZUFBUSxFQUF1QixNQUNqRCxPQUFPUyxNQUFNLEtBQUssV0FBVyxJQUFJQSxNQUFNLENBQUNlLFVBQVUsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDQyxPQUFPLEdBQUcsUUFBUSxHQUFHLFNBQ2hHLENBQUM7RUFFRCxJQUFBQyxnQkFBUyxFQUFDLE1BQU07SUFDZCxNQUFNQyxFQUFFLEdBQUdsQixNQUFNLENBQUNlLFVBQVUsQ0FBQyxvQkFBb0IsQ0FBQztJQUNsRCxNQUFNSSxFQUFFLEdBQUdBLENBQUEsS0FBTUwsS0FBSyxDQUFDSSxFQUFFLENBQUNGLE9BQU8sR0FBRyxRQUFRLEdBQUcsU0FBUyxDQUFDO0lBQ3pERSxFQUFFLENBQUNFLGdCQUFnQixDQUFDLFFBQVEsRUFBRUQsRUFBRSxDQUFDO0lBQ2pDLE9BQU8sTUFBTUQsRUFBRSxDQUFDRyxtQkFBbUIsQ0FBQyxRQUFRLEVBQUVGLEVBQUUsQ0FBQztFQUNuRCxDQUFDLEVBQUUsRUFBRSxDQUFDOztFQUVOO0VBQ0EsSUFBQUYsZ0JBQVMsRUFBQyxNQUFNO0lBQ2QsTUFBTUUsRUFBRSxHQUFJeEQsQ0FBZ0IsSUFBSztNQUMvQixJQUFJLENBQUNBLENBQUMsQ0FBQzJELE9BQU8sSUFBSTNELENBQUMsQ0FBQzRELE9BQU8sS0FBSzVELENBQUMsQ0FBQzZELEdBQUcsQ0FBQ0MsV0FBVyxDQUFDLENBQUMsS0FBSyxHQUFHLEVBQUU7UUFDM0Q5RCxDQUFDLENBQUMrRCxjQUFjLENBQUMsQ0FBQztRQUNsQmxCLGFBQWEsQ0FBRW1CLENBQUMsSUFBSyxDQUFDQSxDQUFDLENBQUM7TUFDMUI7SUFDRixDQUFDO0lBQ0QzQixNQUFNLENBQUNvQixnQkFBZ0IsQ0FBQyxTQUFTLEVBQUVELEVBQUUsQ0FBQztJQUN0QyxPQUFPLE1BQU1uQixNQUFNLENBQUNxQixtQkFBbUIsQ0FBQyxTQUFTLEVBQUVGLEVBQUUsQ0FBQztFQUN4RCxDQUFDLEVBQUUsRUFBRSxDQUFDOztFQUVOO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU07SUFBRVMsUUFBUTtJQUFFQyxJQUFJLEVBQUVDLFFBQVE7SUFBRUMsT0FBTyxFQUFFQyxXQUFXO0lBQUVDLFVBQVU7SUFBRUM7RUFBUyxDQUFDLEdBQUcsSUFBQUMsb0NBQWlCLEVBQUN0RCxRQUFRLENBQUM7RUFFNUcsTUFBTXVELFFBQVEsR0FBRyxJQUFBQyx5QkFBZ0IsRUFBQ25ELFdBQVcsQ0FBQyxJQUFJLElBQUFvRCxnQkFBTyxFQUFDLENBQUM7RUFDM0Q7RUFDQTtFQUNBO0VBQ0EsTUFBTUMsUUFBUSxHQUFHLElBQUFDLG9CQUFlLEVBQUMsSUFBQUYsZ0JBQU8sRUFBQyxDQUFDLENBQVE7RUFDbEQ7RUFDQTtFQUNBO0VBQ0EsTUFBTUcsV0FBMEIsR0FDOUIsT0FBT0YsUUFBUSxFQUFFRyxLQUFLLEtBQUssUUFBUSxJQUFJSCxRQUFRLENBQUNHLEtBQUssR0FBR0gsUUFBUSxDQUFDRyxLQUFLLEdBQUcsSUFBSTtFQUMvRTtFQUNBO0VBQ0E7RUFDQSxNQUFNQSxLQUFLLEdBQUcsSUFBQUMsOEJBQWMsRUFBQztJQUFFQyxNQUFNLEVBQUV2RCxXQUFXO0lBQUV3RCxNQUFNLEVBQUVKO0VBQVksQ0FBQyxDQUFDO0VBQzFFLE1BQU1LLFFBQWtCLEdBQUcsSUFBQUMsK0JBQWUsRUFBQztJQUN6Q0gsTUFBTSxFQUFFcEQsZ0JBQWdCO0lBQ3hCd0QsSUFBSSxFQUFFNUMsWUFBWTtJQUNsQjZDLFNBQVMsRUFBRSxJQUFBQyx5QkFBaUIsRUFBQ1IsS0FBSztFQUNwQyxDQUFDLENBQUM7RUFDRixNQUFNUyxLQUFLLEdBQUdMLFFBQVEsS0FBSyxPQUFPO0VBQ2xDO0VBQ0E7RUFDQSxNQUFNTSxZQUFZLEdBQUcsSUFBQUMsa0JBQVcsRUFBRUMsRUFBdUIsSUFBS0MsTUFBTSxDQUFDQyxJQUFJLENBQUNGLEVBQUUsQ0FBQyxDQUFDRyxNQUFNLENBQUNDLHVCQUFjLENBQUMsRUFBRSxFQUFFLENBQUM7RUFDekcsTUFBTUMsR0FBRyxHQUFHLElBQUFDLHFCQUFnQixFQUFDUixZQUFZLENBQUM7RUFDMUMsTUFBTUksSUFBYyxHQUFHLElBQUFLLGdCQUFVLEVBQUNGLEdBQUcsQ0FBQztFQUN0QyxNQUFNRyxXQUFXLEdBQUdOLElBQUksQ0FBQ08sTUFBTSxHQUFHLENBQUM7O0VBRW5DO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsTUFBTUMsV0FBVyxHQUFHRixXQUFXLElBQUksQ0FBQ04sSUFBSSxDQUFDUyxRQUFRLENBQUM3QixRQUFRLENBQUMsR0FBRyxJQUFBOEIseUJBQWMsRUFBQzlCLFFBQVEsRUFBRW9CLElBQUksQ0FBQyxHQUFHLElBQUk7RUFDbkcsTUFBTVcsUUFBUSxHQUFHSCxXQUFXLElBQUk1QixRQUFRO0VBQ3hDLE1BQU1nQyxXQUFXLEdBQUcsSUFBQUMscUJBQVksRUFBQ0YsUUFBUSxDQUFDO0VBQzFDLE1BQU1HLElBQUksR0FBRyxJQUFBOUIsb0JBQWUsRUFBQzJCLFFBQVEsQ0FBUTtFQUU3QyxNQUFNSSxNQUFNLEdBQUcsSUFBQUMseUJBQWlCLEVBQUNGLElBQUksQ0FBQztFQUN0QyxNQUFNRyxTQUFpQixHQUFHSCxJQUFJLEVBQUVJLElBQUksSUFBSW5DLFFBQVEsRUFBRW1DLElBQUksSUFBSSxPQUFPO0VBQ2pFO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU1DLElBQWEsR0FBRyxJQUFBQyw2QkFBaUIsRUFBQ3JDLFFBQVEsRUFBRStCLElBQUksQ0FBQztFQUN2RCxNQUFNTyxTQUFTLEdBQUdOLE1BQU0sS0FBSyxLQUFLLElBQUksQ0FBQ0QsSUFBSSxFQUFFUSxJQUFJOztFQUdqRDtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU1DLFVBQVUsR0FBR2pCLFdBQVcsSUFBSSxDQUFDTixJQUFJLENBQUNTLFFBQVEsQ0FBQ0UsUUFBUSxDQUFDO0VBQzFELE1BQU1hLFNBQVMsR0FBRyxJQUFBQyx3Q0FBbUIsRUFBQ0YsVUFBVSxHQUFHWixRQUFRLEdBQUcsSUFBSSxDQUFDO0VBQ25FLE1BQU1lLE9BQU8sR0FBR0gsVUFBVSxJQUFJQyxTQUFTLENBQUNHLE1BQU0sS0FBSyxNQUFNOztFQUV6RDtFQUNBO0VBQ0E7RUFDQSxNQUFNQyxPQUFPLEdBQUcsSUFBQUMsbUJBQWMsRUFBQyxDQUE0Qzs7RUFFM0U7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsTUFBTUMsV0FBVyxHQUFHLElBQUFDLDRDQUFxQixFQUFDaEQsUUFBUSxFQUFFK0MsV0FBVyxFQUFFLElBQUFoRCxnQkFBTyxFQUFDLENBQUMsQ0FBQztFQUMzRSxNQUFNLENBQUNrRCxhQUFhLEVBQUVDLGdCQUFnQixDQUFDLEdBQUcsSUFBQWxHLGVBQVEsRUFBZ0IsSUFBSSxDQUFDO0VBQ3ZFLE1BQU1tRyxXQUFXLEdBQUdGLGFBQWEsR0FBRyxDQUFDLEdBQUdGLFdBQVcsQ0FBQ0ssTUFBTSxFQUFFSCxhQUFhLENBQUMsR0FBR0YsV0FBVyxDQUFDSyxNQUFNOztFQUUvRjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsTUFBTUMsS0FBZSxHQUFHLElBQUFDLHlCQUFpQixFQUFDMUIsUUFBUSxFQUFFaUIsT0FBTyxDQUFDO0VBQzVELE1BQU1VLFNBQVMsR0FBR3hCLElBQUksRUFBRXlCLEtBQUssS0FBSyxNQUFNLElBQUl6QixJQUFJLEVBQUV5QixLQUFLLEtBQUssS0FBSzs7RUFFakU7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNQyxPQUFPLEdBQUcsSUFBQUMsc0JBQWMsRUFBQ0wsS0FBSyxDQUFDN0IsTUFBTSxHQUFJcUIsT0FBTyxDQUFDUSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUUsR0FBK0JNLFNBQVMsQ0FBQztFQUMxRztFQUNBO0VBQ0EsTUFBTUMsU0FBUyxHQUFHLElBQUFDLDhCQUFjLEVBQUNqQyxRQUFRLEVBQUUvRSxJQUFJLENBQUM7O0VBRWhEO0VBQ0EsSUFBQTZCLGdCQUFTLEVBQUMsTUFBTTtJQUNkLElBQUlvRixNQUFNLEdBQUcsSUFBSTtJQUNqQjtJQUNBekYsT0FBTyxDQUFDLENBQUMsQ0FBQztJQUNWMEYsV0FBRSxDQUFDQyxRQUFRLENBQ1JDLFFBQVEsQ0FBQyxJQUFBQyxvQkFBVyxFQUFDdEMsUUFBUSxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQ3ZDdUMsSUFBSSxDQUFFQyxDQUFVLElBQUs7TUFDcEIsSUFBSU4sTUFBTSxFQUFFekYsT0FBTyxDQUFDLElBQUFnRyxpQkFBVyxFQUFDLElBQUFDLHNCQUFnQixFQUFDQyxNQUFNLENBQUNILENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUMvRCxDQUFDLENBQUMsQ0FDREksS0FBSyxDQUFDLE1BQU1iLFNBQVMsQ0FBQztJQUN6QixPQUFPLE1BQU07TUFDWEcsTUFBTSxHQUFHLEtBQUs7SUFDaEIsQ0FBQztFQUNILENBQUMsRUFBRSxDQUFDbEMsUUFBUSxDQUFDLENBQUM7O0VBRWQ7RUFDQTtFQUNBLE1BQU02QyxTQUFTLEdBQUcsSUFBQXBELHFCQUFnQixFQUFzQnFELGlCQUFRLENBQUM7RUFDakUsTUFBTUMsUUFBbUIsR0FBRyxJQUFBQyxrQkFBWSxFQUFZSCxTQUFTLENBQUMsQ0FBQ0ksR0FBRyxDQUFDLENBQUM7SUFBRUMsSUFBSTtJQUFFQztFQUFNLENBQUMsTUFBTTtJQUN2RjlGLEdBQUcsRUFBRTZGLElBQUk7SUFDVEUsSUFBSSxFQUFFLElBQUE1SSxrQkFBUyxFQUFDMEksSUFBSSxDQUFDO0lBQ3JCQztFQUNGLENBQUMsQ0FBQyxDQUFDOztFQUVIO0VBQ0EsTUFBTUUsVUFBVSxHQUFHdEMsT0FBTyxHQUN0QjFCLElBQUksQ0FDRDRELEdBQUcsQ0FBRXJKLENBQUMsS0FBTTtJQUFFQSxDQUFDO0lBQUUwSixLQUFLLEVBQUVDLE9BQU8sQ0FBQzNKLENBQUMsRUFBRW9HLFFBQVE7RUFBRSxDQUFDLENBQUMsQ0FBQyxDQUNoRHdELElBQUksQ0FBQyxDQUFDQyxDQUFDLEVBQUVqQixDQUFDLEtBQUtBLENBQUMsQ0FBQ2MsS0FBSyxHQUFHRyxDQUFDLENBQUNILEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFMUosQ0FBQyxHQUMxQ21JLFNBQVM7RUFFYixNQUFNMkIsS0FBaUIsR0FBRztJQUN4Qm5GLEtBQUs7SUFDTG9GLFFBQVEsRUFBRW5JLFdBQVc7SUFDckJ3RCxLQUFLO0lBQ0w0RSxRQUFRLEVBQUVsSSxjQUFjO0lBQ3hCUSxRQUFRO0lBQ1JDLFdBQVc7SUFDWEMsVUFBVTtJQUNWQyxhQUFhO0lBQ2JDLFVBQVU7SUFDVkMsYUFBYTtJQUNiRyxFQUFFO0lBQ0ZtRixPQUFPO0lBQ1BwRSxRQUFRO0lBQ1JLLFVBQVU7SUFDVkgsUUFBUTtJQUNSRSxXQUFXO0lBQ1hFLFFBQVE7SUFDUnVDLFNBQVM7SUFDVEUsSUFBSTtJQUNKdUMsUUFBUTtJQUNSL0MsUUFBUTtJQUNSQyxXQUFXO0lBQ1hHLE1BQU07SUFDTk0sU0FBUztJQUNUbEUsSUFBSTtJQUNKdUUsT0FBTztJQUNQc0MsVUFBVTtJQUNWeEMsU0FBUztJQUNUZ0QsaUJBQWlCLEVBQUUxQyxXQUFXLENBQUNIO0VBQ2pDLENBQUM7O0VBRUQ7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNOEMsVUFBVSxHQUFHLElBQUF4SixtQkFBVSxFQUFDLENBQUMsQ0FBQ0MsT0FBTyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUM7RUFDbkQsTUFBTXdKLFdBQVcsR0FBRyxJQUFBQyxvQkFBWSxFQUFDaEUsUUFBUSxFQUFFOEQsVUFBVSxDQUFDO0VBQ3RELE1BQU1HLFdBQVcsR0FBRztJQUFFQyxJQUFJLEVBQUVKLFVBQVU7SUFBRUssS0FBSyxFQUFFSixXQUFXO0lBQUVLLE1BQU0sRUFBRWxLO0VBQVcsQ0FBQztFQUVoRjtJQUFBO0lBQ0U7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBLElBQUFiLFdBQUEsQ0FBQWdMLEdBQUEsRUFBQ3ZNLFVBQUEsQ0FBQXdNLGdCQUFnQixDQUFDQyxRQUFRO01BQ3hCQyxLQUFLLEVBQUU7UUFDTFYsVUFBVSxFQUFFLElBQUFXLDJCQUFjLEVBQUMsQ0FBQztRQUM1QjtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQUMsY0FBYyxFQUFFLElBQUFDLHlCQUFZLEVBQUM7TUFDL0IsQ0FBRTtNQUFBQyxRQUFBLGVBT0osSUFBQXZMLFdBQUEsQ0FBQWdMLEdBQUEsRUFBQ3RNLE9BQUEsQ0FBQThNLGFBQWE7UUFBQ0wsS0FBSyxFQUFFUCxXQUFZO1FBQUFXLFFBQUEsZUFDbEMsSUFBQXZMLFdBQUEsQ0FBQWdMLEdBQUEsRUFBQ3hMLE1BQUEsQ0FBQWlNLGlCQUFpQixDQUFDUCxRQUFRO1VBQUNDLEtBQUssRUFBRWQsS0FBTTtVQUFBa0IsUUFBQSxlQUN2QyxJQUFBdkwsV0FBQSxDQUFBMEwsSUFBQTtZQUNFQyxTQUFTLEVBQUMsWUFBWTtZQUN0QixXQUFTdEksRUFBRztZQUNaLFlBQVVtRixPQUFRO1lBQ2xCLG9CQUFrQnRELEtBQUssS0FBSyxTQUFTLEdBQUd3RCxTQUFTLEdBQUd4RCxLQUFNO1lBQzFELGNBQVlJLFFBQVM7WUFBQWlHLFFBQUEsZ0JBS3JCLElBQUF2TCxXQUFBLENBQUFnTCxHQUFBLEVBQUNwTCxZQUFBLENBQUFTLE9BQVc7Y0FBQ3VMLFlBQVksRUFBRSxJQUFBQywwQkFBYyxFQUFDM0csS0FBSztZQUFFLENBQUUsQ0FBQyxlQUNwRCxJQUFBbEYsV0FBQSxDQUFBZ0wsR0FBQSxFQUFDbkwsYUFBQSxDQUFBUSxPQUFZO2NBQUN5TCxNQUFNLEVBQUVoRSxXQUFXLENBQUNnRSxNQUFPO2NBQUNDLFVBQVUsRUFBRUEsQ0FBQ2xDLElBQUksRUFBRWxKLENBQUMsS0FBS3NILGdCQUFnQixDQUFDLEdBQUc0QixJQUFJLElBQUlsSixDQUFDLENBQUNxTCxJQUFJLE1BQU1yTCxDQUFDLENBQUNzTCxNQUFNLEVBQUU7WUFBRSxDQUFFLENBQUMsZUFLMUgsSUFBQWpNLFdBQUEsQ0FBQWdMLEdBQUEsRUFBQ3pNLElBQUEsQ0FBQTJOLGlCQUFpQjtjQUFDQyxRQUFRLEVBQUV4RDtZQUFVLENBQUUsQ0FBQyxlQUMxQyxJQUFBM0ksV0FBQSxDQUFBMEwsSUFBQTtjQUFLQyxTQUFTLEVBQUMsZ0JBQWdCO2NBQUNTLEdBQUcsRUFBRXpELFNBQVU7Y0FBQTRDLFFBQUEsR0FDNUNyRCxXQUFXLENBQUMzQixNQUFNLEdBQUcsQ0FBQyxnQkFDckIsSUFBQXZHLFdBQUEsQ0FBQTBMLElBQUE7Z0JBQUtDLFNBQVMsRUFBQyxrQkFBa0I7Z0JBQUNVLElBQUksRUFBQyxRQUFRO2dCQUFBZCxRQUFBLGdCQUM3QyxJQUFBdkwsV0FBQSxDQUFBZ0wsR0FBQTtrQkFBQU8sUUFBQSxFQUFRO2dCQUF1RCxDQUFRLENBQUMsZUFDeEUsSUFBQXZMLFdBQUEsQ0FBQWdMLEdBQUE7a0JBQUFPLFFBQUEsRUFDR3JELFdBQVcsQ0FBQzBCLEdBQUcsQ0FBQyxDQUFDekosQ0FBQyxFQUFFbU0sQ0FBQyxrQkFDcEIsSUFBQXRNLFdBQUEsQ0FBQWdMLEdBQUE7b0JBQUFPLFFBQUEsRUFBYXBMO2tCQUFDLEdBQUxtTSxDQUFVLENBQ3BCO2dCQUFDLENBQ0EsQ0FBQztjQUFBLENBQ0YsQ0FBQyxHQUNKLElBQUksRUFDUGhMLGtCQUFrQixDQUFDaUYsTUFBTSxHQUFHLENBQUMsZ0JBQzVCLElBQUF2RyxXQUFBLENBQUEwTCxJQUFBO2dCQUFLQyxTQUFTLEVBQUMsa0JBQWtCO2dCQUFDVSxJQUFJLEVBQUMsUUFBUTtnQkFBQWQsUUFBQSxnQkFDN0MsSUFBQXZMLFdBQUEsQ0FBQWdMLEdBQUE7a0JBQUFPLFFBQUEsRUFBUTtnQkFBeUQsQ0FBUSxDQUFDLGVBQzFFLElBQUF2TCxXQUFBLENBQUFnTCxHQUFBO2tCQUFBTyxRQUFBLEVBQ0dqSyxrQkFBa0IsQ0FBQ3NJLEdBQUcsQ0FBRTJDLENBQUMsaUJBQ3hCLElBQUF2TSxXQUFBLENBQUEwTCxJQUFBO29CQUFBSCxRQUFBLGdCQUNFLElBQUF2TCxXQUFBLENBQUFnTCxHQUFBO3NCQUFBTyxRQUFBLEVBQU9nQixDQUFDLENBQUNDO29CQUFJLENBQU8sQ0FBQyxZQUFHLEVBQUNELENBQUMsQ0FBQ04sTUFBTTtrQkFBQSxHQUQxQk0sQ0FBQyxDQUFDQyxJQUVQLENBQ0w7Z0JBQUMsQ0FDQSxDQUFDO2NBQUEsQ0FDRixDQUFDLEdBQ0osSUFBSSxlQUNSLElBQUF4TSxXQUFBLENBQUFnTCxHQUFBO2dCQUFLVyxTQUFTLEVBQUMsYUFBYTtnQkFBQyxZQUFVckQsU0FBUyxHQUFHSSxTQUFTLEdBQUdGLE9BQVE7Z0JBQUErQyxRQUFBLGVBSXJFLElBQUF2TCxXQUFBLENBQUFnTCxHQUFBLEVBQUMvTCxXQUFBLENBQUFvQixPQUFVO2tCQUFDc0csUUFBUSxFQUFFQSxRQUFTO2tCQUFDNEIsS0FBSyxFQUFFRCxTQUFTLEdBQUcsTUFBTSxHQUFHO2dCQUFRLENBQUU7Y0FBQyxDQUNwRSxDQUFDO1lBQUEsQ0FDSCxDQUFDLEVBRUx2RixVQUFVLGdCQUFHLElBQUEvQyxXQUFBLENBQUFnTCxHQUFBLEVBQUN2TCxPQUFBLENBQUFZLE9BQU07Y0FBQ29NLE9BQU8sRUFBRUEsQ0FBQSxLQUFNekosYUFBYSxDQUFDLEtBQUs7WUFBRSxDQUFFLENBQUMsR0FBRyxJQUFJLEVBQ25FQyxVQUFVLGdCQUNULElBQUFqRCxXQUFBLENBQUFnTCxHQUFBLEVBQUN0TCxPQUFBLENBQUFXLE9BQU07Y0FDTDRHLFNBQVMsRUFBRUEsU0FBVTtjQUNyQnlGLEdBQUcsRUFBRWhELFFBQVEsQ0FBQ0UsR0FBRyxDQUFFK0MsQ0FBQyxLQUFNO2dCQUFFM0ksR0FBRyxFQUFFMkksQ0FBQyxDQUFDM0ksR0FBRztnQkFBRStGLElBQUksRUFBRTRDLENBQUMsQ0FBQzVDLElBQUk7Z0JBQUVELEtBQUssRUFBRTZDLENBQUMsQ0FBQzdDLEtBQUs7Z0JBQUU4QyxHQUFHLEVBQUVELENBQUMsQ0FBQzNJLEdBQUcsS0FBSzJDO2NBQVMsQ0FBQyxDQUFDLENBQUU7Y0FDbEc4RixPQUFPLEVBQUVBLENBQUEsS0FBTXZKLGFBQWEsQ0FBQyxLQUFLO1lBQUUsQ0FDckMsQ0FBQyxHQUNBLElBQUksZUFDUixJQUFBbEQsV0FBQSxDQUFBZ0wsR0FBQSxFQUFDckwsV0FBQSxDQUFBVSxPQUFVO2NBQUMrRCxRQUFRLEVBQUVBLFFBQVM7Y0FBQ3VDLFFBQVEsRUFBRUEsUUFBUztjQUFDa0csVUFBVSxFQUFFLElBQUFDLG1CQUFVLEVBQUNoRyxJQUFJLEVBQUVpRyxLQUFLLElBQUksWUFBWTtZQUFFLENBQUUsQ0FBQztVQUFBLENBQ3hHO1FBQUMsQ0FDb0I7TUFBQyxDQUNkO0lBQUMsQ0FDVztFQUFDO0FBRWhDOztBQUVBO0FBQUE5TSxFQUFBLENBbFl3Qm1CLFNBQVM7RUFBQSxRQWlEYnVCLGlCQUFZLEVBc0NtRGdDLG9DQUFpQixFQU1qRkssb0JBQWUsRUFtQnBCb0IscUJBQWdCLEVBaUJmcEIsb0JBQWUsRUFzQlZ5Qyx3Q0FBbUIsRUFNckJJLG1CQUFjLEVBUVZFLDRDQUFxQixFQXNCdkJhLDhCQUFjLEVBb0JkeEMscUJBQWdCO0FBQUE7QUFBQTRHLEVBQUEsR0EvTVo1TCxTQUFTO0FBbVlqQyxTQUFTOEksT0FBT0EsQ0FBQ0UsQ0FBUyxFQUFFakIsQ0FBUyxFQUFVO0VBQzdDLE1BQU04RCxFQUFFLEdBQUc3QyxDQUFDLENBQUNsSixPQUFPLENBQUMsSUFBQUQsbUJBQVUsRUFBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUNDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsRUFBRSxDQUFDO0VBQzdELE1BQU1nTSxFQUFFLEdBQUcvRCxDQUFDLENBQUNqSSxPQUFPLENBQUMsSUFBQUQsbUJBQVUsRUFBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUNDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsRUFBRSxDQUFDO0VBQzdELE1BQU1pTSxHQUFHLEdBQUdGLEVBQUUsQ0FBQ0csS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUNDLElBQUksQ0FBQyxHQUFHLENBQUM7RUFDaEQsTUFBTUMsR0FBRyxHQUFHTCxFQUFFLENBQUNFLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQ0MsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDQyxJQUFJLENBQUMsR0FBRyxDQUFDO0VBQ2hELElBQUlyRCxLQUFLLEdBQUdrRCxHQUFHLElBQUlBLEdBQUcsS0FBS0ksR0FBRyxHQUFHLENBQUMsR0FBRyxDQUFDO0VBQ3RDLE1BQU1DLEtBQUssR0FBR1AsRUFBRSxDQUFDRyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUNLLEdBQUcsQ0FBQyxDQUFDLElBQUksRUFBRTtFQUN2QyxNQUFNQyxLQUFLLEdBQUdSLEVBQUUsQ0FBQ0UsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDSyxHQUFHLENBQUMsQ0FBQyxJQUFJLEVBQUU7RUFDdkMsS0FBSyxNQUFNRSxFQUFFLElBQUksSUFBSUMsR0FBRyxDQUFDSixLQUFLLENBQUMsRUFBRSxJQUFJRSxLQUFLLENBQUNqSCxRQUFRLENBQUNrSCxFQUFFLENBQUMsRUFBRTFELEtBQUssRUFBRTtFQUNoRSxPQUFPQSxLQUFLO0FBQ2Q7QUFBQyxJQUFBK0MsRUFBQTtBQUFBYSxZQUFBLENBQUFiLEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}