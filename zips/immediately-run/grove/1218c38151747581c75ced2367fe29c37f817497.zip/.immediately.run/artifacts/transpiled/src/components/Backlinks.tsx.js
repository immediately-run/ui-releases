var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Backlinks;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.map.js");
var _react = require("react");
var _fs = _interopRequireDefault(require("fs"));
var _sdk = require("@immediately-run/sdk");
var _content = require("../lib/content");
var _useEntryKey = require("../hooks/useEntryKey");
var _useFollowLink = require("../hooks/useFollowLink");
var _navigationPolicy = require("../lib/navigationPolicy");
var _wiki = require("../lib/wiki");
var _InlineProse = _interopRequireDefault(require("./InlineProse"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(),
  _s2 = $RefreshSig$();
/* eslint-disable @typescript-eslint/no-explicit-any */
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// One linking entry: title + namespace crumb + the snippet around the link.
function Row({
  hit
}) {
  _s();
  const meta = (0, _sdk.useFileMetadata)(hit.key);
  const from = (0, _useEntryKey.useEntryKey)();
  const follow = (0, _useFollowLink.useFollowLink)();
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_sdk.Link, {
    href: (0, _content.keyToHref)(hit.key),
    className: "grove-bl",
    onClick: (0, _navigationPolicy.followLinkOnClick)(follow, {
      key: hit.key,
      href: (0, _content.keyToHref)(hit.key),
      from
    }),
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "grove-bl__t",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_InlineProse.default, {
        text: meta?.title || (0, _wiki.crumb)(hit.key),
        trimPeriod: true
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
        className: "crumb",
        children: ["/", (0, _wiki.crumb)(hit.key)]
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "grove-bl__snip",
      dangerouslySetInnerHTML: {
        __html: hit.snippet
      }
    })]
  });
}

// `<Backlinks/>` — the signature wiki affordance: who links here. Reads sibling
// entry bodies off the fs and scans for a link to the current entry.
_s(Row, "yi8fnzd+K/oLOUJ+RPzis+vLmXc=", false, function () {
  return [_sdk.useFileMetadata, _useEntryKey.useEntryKey, _useFollowLink.useFollowLink];
});
_c = Row;
function Backlinks() {
  _s2();
  const currentKey = (0, _useEntryKey.useEntryKey)();
  const allKeys = (0, _react.useCallback)(fm => Object.keys(fm).filter(_content.isContentEntry), []);
  const q = (0, _sdk.useMetadataQuery)(allKeys);
  const keys = (0, _wiki.queryPaths)(q);
  const keysKey = keys.join('|');
  const [hits, setHits] = (0, _react.useState)(null);
  (0, _react.useEffect)(() => {
    let active = true;
    if (!keys.length) return; // index not loaded yet → keep the skeleton
    const others = keys.filter(k => k !== currentKey);
    Promise.all(others.map(k => _fs.default.promises.readFile((0, _content.keyToFsPath)(k), 'utf8').then(body => ({
      key: k,
      body: String(body)
    })).catch(() => null))).then(rows => {
      if (!active) return;
      const found = [];
      for (const r of rows) {
        // R3-283: the linking entry's own key is part of the question — corpus links
        // are RELATIVE to the file they are written in, so `r.key` is what resolves them.
        if (r && (0, _wiki.bodyLinksTo)(r.body, currentKey, r.key)) {
          found.push({
            key: r.key,
            snippet: (0, _wiki.backlinkSnippet)(r.body, currentKey, r.key)
          });
        }
      }
      setHits(found.sort((a, b) => a.key < b.key ? -1 : 1));
    });
    return () => {
      active = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentKey, keysKey]);

  // Skeleton while the bodies resolve.
  if (hits === null) {
    return /*#__PURE__*/(0, _jsxRuntime.jsxs)("section", {
      className: "grove-backlinks",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "grove-backlinks__h",
        children: "Backlinks"
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "grove-backlinks__list",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
          className: "sk sk-line",
          style: {
            width: '60%'
          }
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
          className: "sk sk-line",
          style: {
            width: '40%'
          }
        })]
      })]
    });
  }
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("section", {
    className: "grove-backlinks",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("h2", {
      className: "grove-backlinks__h",
      children: ["Linked from", /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
        className: "n",
        children: [hits.length, " ", hits.length === 1 ? 'entry' : 'entries']
      })]
    }), hits.length ? /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "grove-backlinks__list",
      children: hits.map(h => /*#__PURE__*/(0, _jsxRuntime.jsx)(Row, {
        hit: h
      }, h.key))
    }) : /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
      className: "grove-bl__snip",
      children: "Nothing links here yet."
    })]
  });
}
_s2(Backlinks, "k3fAq7aettbXAUM9+1hM+yIrbOw=", false, function () {
  return [_useEntryKey.useEntryKey, _sdk.useMetadataQuery];
});
_c2 = Backlinks;
var _c, _c2;
$RefreshReg$(_c, "Row");
$RefreshReg$(_c2, "Backlinks");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX2ZzIiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsIl9zZGsiLCJfY29udGVudCIsIl91c2VFbnRyeUtleSIsIl91c2VGb2xsb3dMaW5rIiwiX25hdmlnYXRpb25Qb2xpY3kiLCJfd2lraSIsIl9JbmxpbmVQcm9zZSIsIl9qc3hSdW50aW1lIiwiX3MiLCIkUmVmcmVzaFNpZyQiLCJfczIiLCJlIiwiX19lc01vZHVsZSIsImRlZmF1bHQiLCJSb3ciLCJoaXQiLCJtZXRhIiwidXNlRmlsZU1ldGFkYXRhIiwia2V5IiwiZnJvbSIsInVzZUVudHJ5S2V5IiwiZm9sbG93IiwidXNlRm9sbG93TGluayIsImpzeHMiLCJMaW5rIiwiaHJlZiIsImtleVRvSHJlZiIsImNsYXNzTmFtZSIsIm9uQ2xpY2siLCJmb2xsb3dMaW5rT25DbGljayIsImNoaWxkcmVuIiwianN4IiwidGV4dCIsInRpdGxlIiwiY3J1bWIiLCJ0cmltUGVyaW9kIiwiZGFuZ2Vyb3VzbHlTZXRJbm5lckhUTUwiLCJfX2h0bWwiLCJzbmlwcGV0IiwiX2MiLCJCYWNrbGlua3MiLCJjdXJyZW50S2V5IiwiYWxsS2V5cyIsInVzZUNhbGxiYWNrIiwiZm0iLCJPYmplY3QiLCJrZXlzIiwiZmlsdGVyIiwiaXNDb250ZW50RW50cnkiLCJxIiwidXNlTWV0YWRhdGFRdWVyeSIsInF1ZXJ5UGF0aHMiLCJrZXlzS2V5Iiwiam9pbiIsImhpdHMiLCJzZXRIaXRzIiwidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJhY3RpdmUiLCJsZW5ndGgiLCJvdGhlcnMiLCJrIiwiUHJvbWlzZSIsImFsbCIsIm1hcCIsImZzIiwicHJvbWlzZXMiLCJyZWFkRmlsZSIsImtleVRvRnNQYXRoIiwidGhlbiIsImJvZHkiLCJTdHJpbmciLCJjYXRjaCIsInJvd3MiLCJmb3VuZCIsInIiLCJib2R5TGlua3NUbyIsInB1c2giLCJiYWNrbGlua1NuaXBwZXQiLCJzb3J0IiwiYSIsImIiLCJzdHlsZSIsIndpZHRoIiwiaCIsIl9jMiIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkJhY2tsaW5rcy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueSAqL1xuaW1wb3J0IHsgdXNlQ2FsbGJhY2ssIHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgZnMgZnJvbSAnZnMnO1xuaW1wb3J0IHsgTGluaywgdXNlRmlsZU1ldGFkYXRhLCB1c2VNZXRhZGF0YVF1ZXJ5IH0gZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9zZGsnO1xuaW1wb3J0IHsgaXNDb250ZW50RW50cnksIGtleVRvRnNQYXRoLCBrZXlUb0hyZWYgfSBmcm9tICcuLi9saWIvY29udGVudCc7XG5pbXBvcnQgeyB1c2VFbnRyeUtleSB9IGZyb20gJy4uL2hvb2tzL3VzZUVudHJ5S2V5JztcbmltcG9ydCB7IHVzZUZvbGxvd0xpbmsgfSBmcm9tICcuLi9ob29rcy91c2VGb2xsb3dMaW5rJztcbmltcG9ydCB7IGZvbGxvd0xpbmtPbkNsaWNrIH0gZnJvbSAnLi4vbGliL25hdmlnYXRpb25Qb2xpY3knO1xuaW1wb3J0IHsgYmFja2xpbmtTbmlwcGV0LCBib2R5TGlua3NUbywgY3J1bWIsIHF1ZXJ5UGF0aHMgfSBmcm9tICcuLi9saWIvd2lraSc7XG5pbXBvcnQgSW5saW5lUHJvc2UgZnJvbSAnLi9JbmxpbmVQcm9zZSc7XG5cbmludGVyZmFjZSBIaXQge1xuICBrZXk6IHN0cmluZztcbiAgc25pcHBldDogc3RyaW5nO1xufVxuXG4vLyBPbmUgbGlua2luZyBlbnRyeTogdGl0bGUgKyBuYW1lc3BhY2UgY3J1bWIgKyB0aGUgc25pcHBldCBhcm91bmQgdGhlIGxpbmsuXG5mdW5jdGlvbiBSb3coeyBoaXQgfTogeyBoaXQ6IEhpdCB9KSB7XG4gIGNvbnN0IG1ldGEgPSB1c2VGaWxlTWV0YWRhdGEoaGl0LmtleSkgYXMgYW55O1xuICBjb25zdCBmcm9tID0gdXNlRW50cnlLZXkoKTtcbiAgY29uc3QgZm9sbG93ID0gdXNlRm9sbG93TGluaygpO1xuICByZXR1cm4gKFxuICAgIDxMaW5rXG4gICAgICBocmVmPXtrZXlUb0hyZWYoaGl0LmtleSl9XG4gICAgICBjbGFzc05hbWU9XCJncm92ZS1ibFwiXG4gICAgICBvbkNsaWNrPXtmb2xsb3dMaW5rT25DbGljayhmb2xsb3csIHsga2V5OiBoaXQua2V5LCBocmVmOiBrZXlUb0hyZWYoaGl0LmtleSksIGZyb20gfSl9XG4gICAgPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncm92ZS1ibF9fdFwiPlxuICAgICAgICA8SW5saW5lUHJvc2UgdGV4dD17bWV0YT8udGl0bGUgfHwgY3J1bWIoaGl0LmtleSl9IHRyaW1QZXJpb2QgLz5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY3J1bWJcIj4ve2NydW1iKGhpdC5rZXkpfTwvc3Bhbj5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncm92ZS1ibF9fc25pcFwiIGRhbmdlcm91c2x5U2V0SW5uZXJIVE1MPXt7IF9faHRtbDogaGl0LnNuaXBwZXQgfX0gLz5cbiAgICA8L0xpbms+XG4gICk7XG59XG5cbi8vIGA8QmFja2xpbmtzLz5gIOKAlCB0aGUgc2lnbmF0dXJlIHdpa2kgYWZmb3JkYW5jZTogd2hvIGxpbmtzIGhlcmUuIFJlYWRzIHNpYmxpbmdcbi8vIGVudHJ5IGJvZGllcyBvZmYgdGhlIGZzIGFuZCBzY2FucyBmb3IgYSBsaW5rIHRvIHRoZSBjdXJyZW50IGVudHJ5LlxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQmFja2xpbmtzKCkge1xuICBjb25zdCBjdXJyZW50S2V5ID0gdXNlRW50cnlLZXkoKTtcblxuICBjb25zdCBhbGxLZXlzID0gdXNlQ2FsbGJhY2soXG4gICAgKGZtOiBSZWNvcmQ8c3RyaW5nLCBhbnk+KSA9PiBPYmplY3Qua2V5cyhmbSkuZmlsdGVyKGlzQ29udGVudEVudHJ5KSxcbiAgICBbXVxuICApO1xuICBjb25zdCBxID0gdXNlTWV0YWRhdGFRdWVyeShhbGxLZXlzKTtcbiAgY29uc3Qga2V5czogc3RyaW5nW10gPSBxdWVyeVBhdGhzKHEpO1xuICBjb25zdCBrZXlzS2V5ID0ga2V5cy5qb2luKCd8Jyk7XG5cbiAgY29uc3QgW2hpdHMsIHNldEhpdHNdID0gdXNlU3RhdGU8SGl0W10gfCBudWxsPihudWxsKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGxldCBhY3RpdmUgPSB0cnVlO1xuICAgIGlmICgha2V5cy5sZW5ndGgpIHJldHVybjsgLy8gaW5kZXggbm90IGxvYWRlZCB5ZXQg4oaSIGtlZXAgdGhlIHNrZWxldG9uXG4gICAgY29uc3Qgb3RoZXJzID0ga2V5cy5maWx0ZXIoKGspID0+IGsgIT09IGN1cnJlbnRLZXkpO1xuICAgIFByb21pc2UuYWxsKFxuICAgICAgb3RoZXJzLm1hcCgoaykgPT5cbiAgICAgICAgZnMucHJvbWlzZXNcbiAgICAgICAgICAucmVhZEZpbGUoa2V5VG9Gc1BhdGgoayksICd1dGY4JylcbiAgICAgICAgICAudGhlbigoYm9keTogdW5rbm93bikgPT4gKHsga2V5OiBrLCBib2R5OiBTdHJpbmcoYm9keSkgfSkpXG4gICAgICAgICAgLmNhdGNoKCgpID0+IG51bGwpXG4gICAgICApXG4gICAgKS50aGVuKChyb3dzKSA9PiB7XG4gICAgICBpZiAoIWFjdGl2ZSkgcmV0dXJuO1xuICAgICAgY29uc3QgZm91bmQ6IEhpdFtdID0gW107XG4gICAgICBmb3IgKGNvbnN0IHIgb2Ygcm93cykge1xuICAgICAgICAvLyBSMy0yODM6IHRoZSBsaW5raW5nIGVudHJ5J3Mgb3duIGtleSBpcyBwYXJ0IG9mIHRoZSBxdWVzdGlvbiDigJQgY29ycHVzIGxpbmtzXG4gICAgICAgIC8vIGFyZSBSRUxBVElWRSB0byB0aGUgZmlsZSB0aGV5IGFyZSB3cml0dGVuIGluLCBzbyBgci5rZXlgIGlzIHdoYXQgcmVzb2x2ZXMgdGhlbS5cbiAgICAgICAgaWYgKHIgJiYgYm9keUxpbmtzVG8oci5ib2R5LCBjdXJyZW50S2V5LCByLmtleSkpIHtcbiAgICAgICAgICBmb3VuZC5wdXNoKHsga2V5OiByLmtleSwgc25pcHBldDogYmFja2xpbmtTbmlwcGV0KHIuYm9keSwgY3VycmVudEtleSwgci5rZXkpIH0pO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBzZXRIaXRzKGZvdW5kLnNvcnQoKGEsIGIpID0+IChhLmtleSA8IGIua2V5ID8gLTEgOiAxKSkpO1xuICAgIH0pO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBhY3RpdmUgPSBmYWxzZTtcbiAgICB9O1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9leGhhdXN0aXZlLWRlcHNcbiAgfSwgW2N1cnJlbnRLZXksIGtleXNLZXldKTtcblxuICAvLyBTa2VsZXRvbiB3aGlsZSB0aGUgYm9kaWVzIHJlc29sdmUuXG4gIGlmIChoaXRzID09PSBudWxsKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImdyb3ZlLWJhY2tsaW5rc1wiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyb3ZlLWJhY2tsaW5rc19faFwiPkJhY2tsaW5rczwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyb3ZlLWJhY2tsaW5rc19fbGlzdFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2sgc2stbGluZVwiIHN0eWxlPXt7IHdpZHRoOiAnNjAlJyB9fSAvPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2sgc2stbGluZVwiIHN0eWxlPXt7IHdpZHRoOiAnNDAlJyB9fSAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvc2VjdGlvbj5cbiAgICApO1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJncm92ZS1iYWNrbGlua3NcIj5cbiAgICAgIDxoMiBjbGFzc05hbWU9XCJncm92ZS1iYWNrbGlua3NfX2hcIj5cbiAgICAgICAgTGlua2VkIGZyb21cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiblwiPntoaXRzLmxlbmd0aH0ge2hpdHMubGVuZ3RoID09PSAxID8gJ2VudHJ5JyA6ICdlbnRyaWVzJ308L3NwYW4+XG4gICAgICA8L2gyPlxuICAgICAge2hpdHMubGVuZ3RoID8gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyb3ZlLWJhY2tsaW5rc19fbGlzdFwiPlxuICAgICAgICAgIHtoaXRzLm1hcCgoaCkgPT4gKFxuICAgICAgICAgICAgPFJvdyBrZXk9e2gua2V5fSBoaXQ9e2h9IC8+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgKSA6IChcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiZ3JvdmUtYmxfX3NuaXBcIj5Ob3RoaW5nIGxpbmtzIGhlcmUgeWV0LjwvcD5cbiAgICAgICl9XG4gICAgPC9zZWN0aW9uPlxuICApO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFDQSxJQUFBQSxNQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxHQUFBLEdBQUFDLHNCQUFBLENBQUFGLE9BQUE7QUFDQSxJQUFBRyxJQUFBLEdBQUFILE9BQUE7QUFDQSxJQUFBSSxRQUFBLEdBQUFKLE9BQUE7QUFDQSxJQUFBSyxZQUFBLEdBQUFMLE9BQUE7QUFDQSxJQUFBTSxjQUFBLEdBQUFOLE9BQUE7QUFDQSxJQUFBTyxpQkFBQSxHQUFBUCxPQUFBO0FBQ0EsSUFBQVEsS0FBQSxHQUFBUixPQUFBO0FBQ0EsSUFBQVMsWUFBQSxHQUFBUCxzQkFBQSxDQUFBRixPQUFBO0FBQXdDLElBQUFVLFdBQUEsR0FBQVYsT0FBQTtBQUFBLElBQUFXLEVBQUEsR0FBQUMsWUFBQTtFQUFBQyxHQUFBLEdBQUFELFlBQUE7QUFUeEM7QUFBQSxTQUFBVix1QkFBQVksQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQWdCQTtBQUNBLFNBQVNHLEdBQUdBLENBQUM7RUFBRUM7QUFBa0IsQ0FBQyxFQUFFO0VBQUFQLEVBQUE7RUFDbEMsTUFBTVEsSUFBSSxHQUFHLElBQUFDLG9CQUFlLEVBQUNGLEdBQUcsQ0FBQ0csR0FBRyxDQUFRO0VBQzVDLE1BQU1DLElBQUksR0FBRyxJQUFBQyx3QkFBVyxFQUFDLENBQUM7RUFDMUIsTUFBTUMsTUFBTSxHQUFHLElBQUFDLDRCQUFhLEVBQUMsQ0FBQztFQUM5QixvQkFDRSxJQUFBZixXQUFBLENBQUFnQixJQUFBLEVBQUN2QixJQUFBLENBQUF3QixJQUFJO0lBQ0hDLElBQUksRUFBRSxJQUFBQyxrQkFBUyxFQUFDWCxHQUFHLENBQUNHLEdBQUcsQ0FBRTtJQUN6QlMsU0FBUyxFQUFDLFVBQVU7SUFDcEJDLE9BQU8sRUFBRSxJQUFBQyxtQ0FBaUIsRUFBQ1IsTUFBTSxFQUFFO01BQUVILEdBQUcsRUFBRUgsR0FBRyxDQUFDRyxHQUFHO01BQUVPLElBQUksRUFBRSxJQUFBQyxrQkFBUyxFQUFDWCxHQUFHLENBQUNHLEdBQUcsQ0FBQztNQUFFQztJQUFLLENBQUMsQ0FBRTtJQUFBVyxRQUFBLGdCQUVyRixJQUFBdkIsV0FBQSxDQUFBZ0IsSUFBQTtNQUFLSSxTQUFTLEVBQUMsYUFBYTtNQUFBRyxRQUFBLGdCQUMxQixJQUFBdkIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDekIsWUFBQSxDQUFBTyxPQUFXO1FBQUNtQixJQUFJLEVBQUVoQixJQUFJLEVBQUVpQixLQUFLLElBQUksSUFBQUMsV0FBSyxFQUFDbkIsR0FBRyxDQUFDRyxHQUFHLENBQUU7UUFBQ2lCLFVBQVU7TUFBQSxDQUFFLENBQUMsZUFDL0QsSUFBQTVCLFdBQUEsQ0FBQWdCLElBQUE7UUFBTUksU0FBUyxFQUFDLE9BQU87UUFBQUcsUUFBQSxHQUFDLEdBQUMsRUFBQyxJQUFBSSxXQUFLLEVBQUNuQixHQUFHLENBQUNHLEdBQUcsQ0FBQztNQUFBLENBQU8sQ0FBQztJQUFBLENBQzdDLENBQUMsZUFDTixJQUFBWCxXQUFBLENBQUF3QixHQUFBO01BQUtKLFNBQVMsRUFBQyxnQkFBZ0I7TUFBQ1MsdUJBQXVCLEVBQUU7UUFBRUMsTUFBTSxFQUFFdEIsR0FBRyxDQUFDdUI7TUFBUTtJQUFFLENBQUUsQ0FBQztFQUFBLENBQ2hGLENBQUM7QUFFWDs7QUFFQTtBQUNBO0FBQUE5QixFQUFBLENBcEJTTSxHQUFHO0VBQUEsUUFDR0csb0JBQWUsRUFDZkcsd0JBQVcsRUFDVEUsNEJBQWE7QUFBQTtBQUFBaUIsRUFBQSxHQUhyQnpCLEdBQUc7QUFxQkcsU0FBUzBCLFNBQVNBLENBQUEsRUFBRztFQUFBOUIsR0FBQTtFQUNsQyxNQUFNK0IsVUFBVSxHQUFHLElBQUFyQix3QkFBVyxFQUFDLENBQUM7RUFFaEMsTUFBTXNCLE9BQU8sR0FBRyxJQUFBQyxrQkFBVyxFQUN4QkMsRUFBdUIsSUFBS0MsTUFBTSxDQUFDQyxJQUFJLENBQUNGLEVBQUUsQ0FBQyxDQUFDRyxNQUFNLENBQUNDLHVCQUFjLENBQUMsRUFDbkUsRUFDRixDQUFDO0VBQ0QsTUFBTUMsQ0FBQyxHQUFHLElBQUFDLHFCQUFnQixFQUFDUixPQUFPLENBQUM7RUFDbkMsTUFBTUksSUFBYyxHQUFHLElBQUFLLGdCQUFVLEVBQUNGLENBQUMsQ0FBQztFQUNwQyxNQUFNRyxPQUFPLEdBQUdOLElBQUksQ0FBQ08sSUFBSSxDQUFDLEdBQUcsQ0FBQztFQUU5QixNQUFNLENBQUNDLElBQUksRUFBRUMsT0FBTyxDQUFDLEdBQUcsSUFBQUMsZUFBUSxFQUFlLElBQUksQ0FBQztFQUVwRCxJQUFBQyxnQkFBUyxFQUFDLE1BQU07SUFDZCxJQUFJQyxNQUFNLEdBQUcsSUFBSTtJQUNqQixJQUFJLENBQUNaLElBQUksQ0FBQ2EsTUFBTSxFQUFFLE9BQU8sQ0FBQztJQUMxQixNQUFNQyxNQUFNLEdBQUdkLElBQUksQ0FBQ0MsTUFBTSxDQUFFYyxDQUFDLElBQUtBLENBQUMsS0FBS3BCLFVBQVUsQ0FBQztJQUNuRHFCLE9BQU8sQ0FBQ0MsR0FBRyxDQUNUSCxNQUFNLENBQUNJLEdBQUcsQ0FBRUgsQ0FBQyxJQUNYSSxXQUFFLENBQUNDLFFBQVEsQ0FDUkMsUUFBUSxDQUFDLElBQUFDLG9CQUFXLEVBQUNQLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUNoQ1EsSUFBSSxDQUFFQyxJQUFhLEtBQU07TUFBRXBELEdBQUcsRUFBRTJDLENBQUM7TUFBRVMsSUFBSSxFQUFFQyxNQUFNLENBQUNELElBQUk7SUFBRSxDQUFDLENBQUMsQ0FBQyxDQUN6REUsS0FBSyxDQUFDLE1BQU0sSUFBSSxDQUNyQixDQUNGLENBQUMsQ0FBQ0gsSUFBSSxDQUFFSSxJQUFJLElBQUs7TUFDZixJQUFJLENBQUNmLE1BQU0sRUFBRTtNQUNiLE1BQU1nQixLQUFZLEdBQUcsRUFBRTtNQUN2QixLQUFLLE1BQU1DLENBQUMsSUFBSUYsSUFBSSxFQUFFO1FBQ3BCO1FBQ0E7UUFDQSxJQUFJRSxDQUFDLElBQUksSUFBQUMsaUJBQVcsRUFBQ0QsQ0FBQyxDQUFDTCxJQUFJLEVBQUU3QixVQUFVLEVBQUVrQyxDQUFDLENBQUN6RCxHQUFHLENBQUMsRUFBRTtVQUMvQ3dELEtBQUssQ0FBQ0csSUFBSSxDQUFDO1lBQUUzRCxHQUFHLEVBQUV5RCxDQUFDLENBQUN6RCxHQUFHO1lBQUVvQixPQUFPLEVBQUUsSUFBQXdDLHFCQUFlLEVBQUNILENBQUMsQ0FBQ0wsSUFBSSxFQUFFN0IsVUFBVSxFQUFFa0MsQ0FBQyxDQUFDekQsR0FBRztVQUFFLENBQUMsQ0FBQztRQUNqRjtNQUNGO01BQ0FxQyxPQUFPLENBQUNtQixLQUFLLENBQUNLLElBQUksQ0FBQyxDQUFDQyxDQUFDLEVBQUVDLENBQUMsS0FBTUQsQ0FBQyxDQUFDOUQsR0FBRyxHQUFHK0QsQ0FBQyxDQUFDL0QsR0FBRyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUUsQ0FBQyxDQUFDO0lBQ3pELENBQUMsQ0FBQztJQUNGLE9BQU8sTUFBTTtNQUNYd0MsTUFBTSxHQUFHLEtBQUs7SUFDaEIsQ0FBQztJQUNEO0VBQ0YsQ0FBQyxFQUFFLENBQUNqQixVQUFVLEVBQUVXLE9BQU8sQ0FBQyxDQUFDOztFQUV6QjtFQUNBLElBQUlFLElBQUksS0FBSyxJQUFJLEVBQUU7SUFDakIsb0JBQ0UsSUFBQS9DLFdBQUEsQ0FBQWdCLElBQUE7TUFBU0ksU0FBUyxFQUFDLGlCQUFpQjtNQUFBRyxRQUFBLGdCQUNsQyxJQUFBdkIsV0FBQSxDQUFBd0IsR0FBQTtRQUFLSixTQUFTLEVBQUMsb0JBQW9CO1FBQUFHLFFBQUEsRUFBQztNQUFTLENBQUssQ0FBQyxlQUNuRCxJQUFBdkIsV0FBQSxDQUFBZ0IsSUFBQTtRQUFLSSxTQUFTLEVBQUMsdUJBQXVCO1FBQUFHLFFBQUEsZ0JBQ3BDLElBQUF2QixXQUFBLENBQUF3QixHQUFBO1VBQUtKLFNBQVMsRUFBQyxZQUFZO1VBQUN1RCxLQUFLLEVBQUU7WUFBRUMsS0FBSyxFQUFFO1VBQU07UUFBRSxDQUFFLENBQUMsZUFDdkQsSUFBQTVFLFdBQUEsQ0FBQXdCLEdBQUE7VUFBS0osU0FBUyxFQUFDLFlBQVk7VUFBQ3VELEtBQUssRUFBRTtZQUFFQyxLQUFLLEVBQUU7VUFBTTtRQUFFLENBQUUsQ0FBQztNQUFBLENBQ3BELENBQUM7SUFBQSxDQUNDLENBQUM7RUFFZDtFQUVBLG9CQUNFLElBQUE1RSxXQUFBLENBQUFnQixJQUFBO0lBQVNJLFNBQVMsRUFBQyxpQkFBaUI7SUFBQUcsUUFBQSxnQkFDbEMsSUFBQXZCLFdBQUEsQ0FBQWdCLElBQUE7TUFBSUksU0FBUyxFQUFDLG9CQUFvQjtNQUFBRyxRQUFBLEdBQUMsYUFFakMsbUJBQUF2QixXQUFBLENBQUFnQixJQUFBO1FBQU1JLFNBQVMsRUFBQyxHQUFHO1FBQUFHLFFBQUEsR0FBRXdCLElBQUksQ0FBQ0ssTUFBTSxFQUFDLEdBQUMsRUFBQ0wsSUFBSSxDQUFDSyxNQUFNLEtBQUssQ0FBQyxHQUFHLE9BQU8sR0FBRyxTQUFTO01BQUEsQ0FBTyxDQUFDO0lBQUEsQ0FDaEYsQ0FBQyxFQUNKTCxJQUFJLENBQUNLLE1BQU0sZ0JBQ1YsSUFBQXBELFdBQUEsQ0FBQXdCLEdBQUE7TUFBS0osU0FBUyxFQUFDLHVCQUF1QjtNQUFBRyxRQUFBLEVBQ25Dd0IsSUFBSSxDQUFDVSxHQUFHLENBQUVvQixDQUFDLGlCQUNWLElBQUE3RSxXQUFBLENBQUF3QixHQUFBLEVBQUNqQixHQUFHO1FBQWFDLEdBQUcsRUFBRXFFO01BQUUsR0FBZEEsQ0FBQyxDQUFDbEUsR0FBYyxDQUMzQjtJQUFDLENBQ0MsQ0FBQyxnQkFFTixJQUFBWCxXQUFBLENBQUF3QixHQUFBO01BQUdKLFNBQVMsRUFBQyxnQkFBZ0I7TUFBQUcsUUFBQSxFQUFDO0lBQXVCLENBQUcsQ0FDekQ7RUFBQSxDQUNNLENBQUM7QUFFZDtBQUFDcEIsR0FBQSxDQXhFdUI4QixTQUFTO0VBQUEsUUFDWnBCLHdCQUFXLEVBTXBCOEIscUJBQWdCO0FBQUE7QUFBQW1DLEdBQUEsR0FQSjdDLFNBQVM7QUFBQSxJQUFBRCxFQUFBLEVBQUE4QyxHQUFBO0FBQUFDLFlBQUEsQ0FBQS9DLEVBQUE7QUFBQStDLFlBQUEsQ0FBQUQsR0FBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}