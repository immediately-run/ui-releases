var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = ChildPages;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.map.js");
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
var _content = require("../lib/content");
var _useEntryKey = require("../hooks/useEntryKey");
var _useFollowLink = require("../hooks/useFollowLink");
var _navigationPolicy = require("../lib/navigationPolicy");
var _wiki = require("../lib/wiki");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$();
/* eslint-disable @typescript-eslint/no-explicit-any */
// `<ChildPages/>` — the entries that live under the current entry's namespace, as
// a compact nested list (e.g. everything in `handbook/` from the handbook index).
function ChildPages() {
  _s();
  const currentKey = (0, _useEntryKey.useEntryKey)();
  const rel = currentKey.replace((0, _content.contentDir)(), '').replace(/\.mdx?$/, '');
  // The folder this entry indexes: its own slug if it's a section index, else its namespace.
  const scope = rel.replace(/\/?(index|home)$/, '');
  const queryFn = (0, _react.useCallback)(fm => Object.keys(fm).filter(p => {
    if (!(0, _content.isContentEntry)(p) || p === currentKey) return false;
    return (0, _wiki.namespaceOf)(p) === scope;
  }).sort(), [currentKey, scope]);
  const q = (0, _sdk.useMetadataQuery)(queryFn);
  const paths = (0, _wiki.queryPaths)(q);
  const follow = (0, _useFollowLink.useFollowLink)();
  if (!paths.length) return null;
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    className: "grove-doclist",
    "data-shape": "feed",
    children: paths.map(p => /*#__PURE__*/(0, _jsxRuntime.jsx)(_sdk.Link, {
      href: (0, _content.keyToHref)(p),
      className: "gdl-row",
      onClick: (0, _navigationPolicy.followLinkOnClick)(follow, {
        key: p,
        href: (0, _content.keyToHref)(p),
        from: currentKey
      }),
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "gdl-row__t",
        children: p.replace((0, _content.contentDir)(), '').replace(/\.mdx?$/, '').split('/').pop()
      })
    }, p))
  });
}
_s(ChildPages, "T16artb9GCHpsZdG1RG/sZb2mBs=", false, function () {
  return [_useEntryKey.useEntryKey, _sdk.useMetadataQuery, _useFollowLink.useFollowLink];
});
_c = ChildPages;
var _c;
$RefreshReg$(_c, "ChildPages");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NkayIsIl9jb250ZW50IiwiX3VzZUVudHJ5S2V5IiwiX3VzZUZvbGxvd0xpbmsiLCJfbmF2aWdhdGlvblBvbGljeSIsIl93aWtpIiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsIkNoaWxkUGFnZXMiLCJjdXJyZW50S2V5IiwidXNlRW50cnlLZXkiLCJyZWwiLCJyZXBsYWNlIiwiY29udGVudERpciIsInNjb3BlIiwicXVlcnlGbiIsInVzZUNhbGxiYWNrIiwiZm0iLCJPYmplY3QiLCJrZXlzIiwiZmlsdGVyIiwicCIsImlzQ29udGVudEVudHJ5IiwibmFtZXNwYWNlT2YiLCJzb3J0IiwicSIsInVzZU1ldGFkYXRhUXVlcnkiLCJwYXRocyIsInF1ZXJ5UGF0aHMiLCJmb2xsb3ciLCJ1c2VGb2xsb3dMaW5rIiwibGVuZ3RoIiwianN4IiwiY2xhc3NOYW1lIiwiY2hpbGRyZW4iLCJtYXAiLCJMaW5rIiwiaHJlZiIsImtleVRvSHJlZiIsIm9uQ2xpY2siLCJmb2xsb3dMaW5rT25DbGljayIsImtleSIsImZyb20iLCJzcGxpdCIsInBvcCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQ2hpbGRQYWdlcy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueSAqL1xuaW1wb3J0IHsgdXNlQ2FsbGJhY2sgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBMaW5rLCB1c2VNZXRhZGF0YVF1ZXJ5IH0gZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9zZGsnO1xuaW1wb3J0IHsgY29udGVudERpciwgaXNDb250ZW50RW50cnksIGtleVRvSHJlZiB9IGZyb20gJy4uL2xpYi9jb250ZW50JztcbmltcG9ydCB7IHVzZUVudHJ5S2V5IH0gZnJvbSAnLi4vaG9va3MvdXNlRW50cnlLZXknO1xuaW1wb3J0IHsgdXNlRm9sbG93TGluayB9IGZyb20gJy4uL2hvb2tzL3VzZUZvbGxvd0xpbmsnO1xuaW1wb3J0IHsgZm9sbG93TGlua09uQ2xpY2sgfSBmcm9tICcuLi9saWIvbmF2aWdhdGlvblBvbGljeSc7XG5pbXBvcnQgeyBuYW1lc3BhY2VPZiwgcXVlcnlQYXRocyB9IGZyb20gJy4uL2xpYi93aWtpJztcblxuLy8gYDxDaGlsZFBhZ2VzLz5gIOKAlCB0aGUgZW50cmllcyB0aGF0IGxpdmUgdW5kZXIgdGhlIGN1cnJlbnQgZW50cnkncyBuYW1lc3BhY2UsIGFzXG4vLyBhIGNvbXBhY3QgbmVzdGVkIGxpc3QgKGUuZy4gZXZlcnl0aGluZyBpbiBgaGFuZGJvb2svYCBmcm9tIHRoZSBoYW5kYm9vayBpbmRleCkuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBDaGlsZFBhZ2VzKCkge1xuICBjb25zdCBjdXJyZW50S2V5ID0gdXNlRW50cnlLZXkoKTtcbiAgY29uc3QgcmVsID0gY3VycmVudEtleS5yZXBsYWNlKGNvbnRlbnREaXIoKSwgJycpLnJlcGxhY2UoL1xcLm1keD8kLywgJycpO1xuICAvLyBUaGUgZm9sZGVyIHRoaXMgZW50cnkgaW5kZXhlczogaXRzIG93biBzbHVnIGlmIGl0J3MgYSBzZWN0aW9uIGluZGV4LCBlbHNlIGl0cyBuYW1lc3BhY2UuXG4gIGNvbnN0IHNjb3BlID0gcmVsLnJlcGxhY2UoL1xcLz8oaW5kZXh8aG9tZSkkLywgJycpO1xuXG4gIGNvbnN0IHF1ZXJ5Rm4gPSB1c2VDYWxsYmFjayhcbiAgICAoZm06IFJlY29yZDxzdHJpbmcsIGFueT4pID0+XG4gICAgICBPYmplY3Qua2V5cyhmbSlcbiAgICAgICAgLmZpbHRlcigocCkgPT4ge1xuICAgICAgICAgIGlmICghaXNDb250ZW50RW50cnkocCkgfHwgcCA9PT0gY3VycmVudEtleSkgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgIHJldHVybiBuYW1lc3BhY2VPZihwKSA9PT0gc2NvcGU7XG4gICAgICAgIH0pXG4gICAgICAgIC5zb3J0KCksXG4gICAgW2N1cnJlbnRLZXksIHNjb3BlXVxuICApO1xuICBjb25zdCBxID0gdXNlTWV0YWRhdGFRdWVyeShxdWVyeUZuKTtcbiAgY29uc3QgcGF0aHM6IHN0cmluZ1tdID0gcXVlcnlQYXRocyhxKTtcbiAgY29uc3QgZm9sbG93ID0gdXNlRm9sbG93TGluaygpO1xuXG4gIGlmICghcGF0aHMubGVuZ3RoKSByZXR1cm4gbnVsbDtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImdyb3ZlLWRvY2xpc3RcIiBkYXRhLXNoYXBlPVwiZmVlZFwiPlxuICAgICAge3BhdGhzLm1hcCgocCkgPT4gKFxuICAgICAgICA8TGluayBrZXk9e3B9IGhyZWY9e2tleVRvSHJlZihwKX0gY2xhc3NOYW1lPVwiZ2RsLXJvd1wiIG9uQ2xpY2s9e2ZvbGxvd0xpbmtPbkNsaWNrKGZvbGxvdywgeyBrZXk6IHAsIGhyZWY6IGtleVRvSHJlZihwKSwgZnJvbTogY3VycmVudEtleSB9KX0+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJnZGwtcm93X190XCI+e3AucmVwbGFjZShjb250ZW50RGlyKCksICcnKS5yZXBsYWNlKC9cXC5tZHg/JC8sICcnKS5zcGxpdCgnLycpLnBvcCgpfTwvZGl2PlxuICAgICAgICA8L0xpbms+XG4gICAgICApKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQ0EsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsSUFBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsUUFBQSxHQUFBRixPQUFBO0FBQ0EsSUFBQUcsWUFBQSxHQUFBSCxPQUFBO0FBQ0EsSUFBQUksY0FBQSxHQUFBSixPQUFBO0FBQ0EsSUFBQUssaUJBQUEsR0FBQUwsT0FBQTtBQUNBLElBQUFNLEtBQUEsR0FBQU4sT0FBQTtBQUFzRCxJQUFBTyxXQUFBLEdBQUFQLE9BQUE7QUFBQSxJQUFBUSxFQUFBLEdBQUFDLFlBQUE7QUFQdEQ7QUFTQTtBQUNBO0FBQ2UsU0FBU0MsVUFBVUEsQ0FBQSxFQUFHO0VBQUFGLEVBQUE7RUFDbkMsTUFBTUcsVUFBVSxHQUFHLElBQUFDLHdCQUFXLEVBQUMsQ0FBQztFQUNoQyxNQUFNQyxHQUFHLEdBQUdGLFVBQVUsQ0FBQ0csT0FBTyxDQUFDLElBQUFDLG1CQUFVLEVBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDRCxPQUFPLENBQUMsU0FBUyxFQUFFLEVBQUUsQ0FBQztFQUN2RTtFQUNBLE1BQU1FLEtBQUssR0FBR0gsR0FBRyxDQUFDQyxPQUFPLENBQUMsa0JBQWtCLEVBQUUsRUFBRSxDQUFDO0VBRWpELE1BQU1HLE9BQU8sR0FBRyxJQUFBQyxrQkFBVyxFQUN4QkMsRUFBdUIsSUFDdEJDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDRixFQUFFLENBQUMsQ0FDWkcsTUFBTSxDQUFFQyxDQUFDLElBQUs7SUFDYixJQUFJLENBQUMsSUFBQUMsdUJBQWMsRUFBQ0QsQ0FBQyxDQUFDLElBQUlBLENBQUMsS0FBS1osVUFBVSxFQUFFLE9BQU8sS0FBSztJQUN4RCxPQUFPLElBQUFjLGlCQUFXLEVBQUNGLENBQUMsQ0FBQyxLQUFLUCxLQUFLO0VBQ2pDLENBQUMsQ0FBQyxDQUNEVSxJQUFJLENBQUMsQ0FBQyxFQUNYLENBQUNmLFVBQVUsRUFBRUssS0FBSyxDQUNwQixDQUFDO0VBQ0QsTUFBTVcsQ0FBQyxHQUFHLElBQUFDLHFCQUFnQixFQUFDWCxPQUFPLENBQUM7RUFDbkMsTUFBTVksS0FBZSxHQUFHLElBQUFDLGdCQUFVLEVBQUNILENBQUMsQ0FBQztFQUNyQyxNQUFNSSxNQUFNLEdBQUcsSUFBQUMsNEJBQWEsRUFBQyxDQUFDO0VBRTlCLElBQUksQ0FBQ0gsS0FBSyxDQUFDSSxNQUFNLEVBQUUsT0FBTyxJQUFJO0VBQzlCLG9CQUNFLElBQUExQixXQUFBLENBQUEyQixHQUFBO0lBQUtDLFNBQVMsRUFBQyxlQUFlO0lBQUMsY0FBVyxNQUFNO0lBQUFDLFFBQUEsRUFDN0NQLEtBQUssQ0FBQ1EsR0FBRyxDQUFFZCxDQUFDLGlCQUNYLElBQUFoQixXQUFBLENBQUEyQixHQUFBLEVBQUNqQyxJQUFBLENBQUFxQyxJQUFJO01BQVNDLElBQUksRUFBRSxJQUFBQyxrQkFBUyxFQUFDakIsQ0FBQyxDQUFFO01BQUNZLFNBQVMsRUFBQyxTQUFTO01BQUNNLE9BQU8sRUFBRSxJQUFBQyxtQ0FBaUIsRUFBQ1gsTUFBTSxFQUFFO1FBQUVZLEdBQUcsRUFBRXBCLENBQUM7UUFBRWdCLElBQUksRUFBRSxJQUFBQyxrQkFBUyxFQUFDakIsQ0FBQyxDQUFDO1FBQUVxQixJQUFJLEVBQUVqQztNQUFXLENBQUMsQ0FBRTtNQUFBeUIsUUFBQSxlQUN6SSxJQUFBN0IsV0FBQSxDQUFBMkIsR0FBQTtRQUFLQyxTQUFTLEVBQUMsWUFBWTtRQUFBQyxRQUFBLEVBQUViLENBQUMsQ0FBQ1QsT0FBTyxDQUFDLElBQUFDLG1CQUFVLEVBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDRCxPQUFPLENBQUMsU0FBUyxFQUFFLEVBQUUsQ0FBQyxDQUFDK0IsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDQyxHQUFHLENBQUM7TUFBQyxDQUFNO0lBQUMsR0FEOUZ2QixDQUVMLENBQ1A7RUFBQyxDQUNDLENBQUM7QUFFVjtBQUFDZixFQUFBLENBOUJ1QkUsVUFBVTtFQUFBLFFBQ2JFLHdCQUFXLEVBZXBCZ0IscUJBQWdCLEVBRVhJLDRCQUFhO0FBQUE7QUFBQWUsRUFBQSxHQWxCTnJDLFVBQVU7QUFBQSxJQUFBcUMsRUFBQTtBQUFBQyxZQUFBLENBQUFELEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}