var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = GroveNav;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
var _sdk = require("@immediately-run/sdk");
var _shell = require("../lib/shell");
var _contentRoot = require("../lib/contentRoot");
var _content = require("../lib/content");
var _useFollowLink = require("../hooks/useFollowLink");
var _navigationPolicy = require("../lib/navigationPolicy");
var _useOverlayFocusDismiss = require("../hooks/useOverlayFocusDismiss");
var _themes = require("../data/themes");
var _Icon = _interopRequireDefault(require("./Icon"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // `<GroveNav/>` — the top navigation bar. Import-free in MDX, so a layout places
// it with `<GroveNav/>`. Its interactive state (drawer / search / theme menu)
// lives in the shell context; this component only arranges and drives it.
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function GroveNav() {
  _s();
  const {
    siteTitle,
    navItems,
    entryKey,
    writable,
    openEditor,
    editBusy,
    editRefused,
    editHint,
    theme,
    setTheme,
    light,
    setLight,
    menuOpen,
    setMenuOpen,
    setSearchOpen,
    setDrawerOpen
  } = (0, _shell.useShell)();
  const follow = (0, _useFollowLink.useFollowLink)();
  const askGrove = () => {
    const el = document.querySelector('.ga-foot input') || document.querySelector('.ga-line input');
    el?.focus();
  };
  // The new entry belongs to whichever corpus is mounted, so it is named from the
  // content ROOT rather than the fork's `content/` literal — under dispatch the latter
  // would create a file in Grove's own repo (R3-266).
  const newEntry = () => openEditor(`${(0, _contentRoot.getContentRoot)()}untitled.mdx`);

  // The theme menu's contract (R3-608): the shared overlay hook with Tab-trap
  // OFF (menus do not trap Tab), plus the menu keydown map — arrows walk the
  // menuitems, Escape closes (the hook), focus returns to the theme button.
  const menuRef = (0, _useOverlayFocusDismiss.useOverlayFocusDismiss)(menuOpen, () => setMenuOpen(false), {
    trapTab: false
  });
  const onMenuKeyDown = e => {
    const items = [...(menuRef.current?.querySelectorAll('[role^="menuitem"]') ?? [])];
    if (!items.length) return;
    const idx = items.indexOf(document.activeElement);
    const move = i => {
      e.preventDefault();
      const next = items[(i + items.length) % items.length];
      next.focus();
      // APG menu radios: arrows MOVE focus AND activate — the radio the arrow
      // lands on is selected, so the keyboard alone can change the theme.
      if (next.getAttribute('role') === 'menuitemradio' && next.getAttribute('aria-checked') !== 'true') next.click();
    };
    if (e.key === 'ArrowDown') move(idx + 1);else if (e.key === 'ArrowUp') move(idx - 1);else if (e.key === 'Home') move(0);else if (e.key === 'End') move(items.length - 1);
  };
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("nav", {
    className: "grove-nav",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
      className: "grove-hamburger icbtn",
      "aria-label": "Menu",
      onClick: () => setDrawerOpen(true),
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
        name: "list"
      })
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_sdk.Link, {
      href: "/",
      className: "grove-brand",
      onClick: (0, _navigationPolicy.followLinkOnClick)(follow, {
        key: (0, _content.homeKey)(),
        href: '/',
        from: entryKey
      }),
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "tile",
        style: {
          background: 'var(--grad)'
        }
      }), siteTitle]
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "grove-nav__links",
      children: navItems.map(n => /*#__PURE__*/(0, _jsxRuntime.jsx)(_sdk.Link, {
        href: n.href,
        "data-cur": n.key === entryKey ? '1' : '0',
        onClick: (0, _navigationPolicy.followLinkOnClick)(follow, {
          key: n.key,
          href: n.href,
          from: entryKey
        }),
        children: n.label
      }, n.key))
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "grove-nav__cluster",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        className: "icbtn",
        "aria-label": "Search",
        onClick: () => setSearchOpen(true),
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
          name: "search"
        })
      }), writable && /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          className: "icbtn",
          "aria-label": editBusy ? 'Opening editor…' : 'New entry',
          title: editHint,
          "data-busy": editBusy ? '1' : '0',
          disabled: editBusy,
          onClick: newEntry,
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
            name: "plus"
          })
        }), editRefused && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "grove-edit-refused",
          role: "status",
          title: _shell.EDIT_REFUSED_NOTICE,
          children: _shell.EDIT_REFUSED_NOTICE
        })]
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        className: "icbtn",
        "aria-label": "Ask Grove",
        onClick: askGrove,
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
          name: "message"
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "grove-nav__more",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          className: "icbtn grove-theme-control",
          title: "Theme",
          "aria-expanded": menuOpen,
          "aria-haspopup": "menu",
          onClick: () => setMenuOpen(o => !o),
          children: "\u2600"
        }), menuOpen ? /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
            className: "gtm__scrim",
            onClick: () => setMenuOpen(false)
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
            className: "grove-theme-menu",
            role: "menu",
            "aria-label": "Theme",
            ref: menuRef,
            tabIndex: -1,
            onKeyDown: onMenuKeyDown,
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
              className: "gtm__h",
              children: "Theme"
            }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
              className: "gtm__list",
              children: _themes.THEMES.map(t => /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
                className: "gtm__row",
                "data-cur": theme === t.id ? '1' : '0',
                role: "menuitemradio",
                "aria-checked": theme === t.id,
                tabIndex: -1,
                onClick: () => setTheme(t.id),
                children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
                  className: "gtm__sw",
                  style: {
                    background: t.swatch
                  }
                }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
                  className: "gtm__name",
                  children: t.label
                }), theme === t.id ? /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
                  className: "gtm__ck",
                  children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
                    name: "check"
                  })
                }) : null]
              }, t.id))
            }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
              className: "gtm__appearance",
              children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
                className: "gtm__sub",
                children: "Appearance"
              }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
                className: "gtm__seg",
                children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
                  "data-on": !light ? '1' : '0',
                  role: "menuitemradio",
                  "aria-checked": !light,
                  tabIndex: -1,
                  onClick: () => setLight(false),
                  children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
                    name: "moon"
                  }), " Dark"]
                }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
                  "data-on": light ? '1' : '0',
                  role: "menuitemradio",
                  "aria-checked": light,
                  tabIndex: -1,
                  onClick: () => setLight(true),
                  children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
                    name: "sun"
                  }), " Light"]
                })]
              })]
            })]
          })]
        }) : null]
      })]
    })]
  });
}
_s(GroveNav, "o5APnlbEeKEtDEDxLRtpsIFByl4=", false, function () {
  return [_shell.useShell, _useFollowLink.useFollowLink, _useOverlayFocusDismiss.useOverlayFocusDismiss];
});
_c = GroveNav;
var _c;
$RefreshReg$(_c, "GroveNav");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfc2RrIiwicmVxdWlyZSIsIl9zaGVsbCIsIl9jb250ZW50Um9vdCIsIl9jb250ZW50IiwiX3VzZUZvbGxvd0xpbmsiLCJfbmF2aWdhdGlvblBvbGljeSIsIl91c2VPdmVybGF5Rm9jdXNEaXNtaXNzIiwiX3RoZW1lcyIsIl9JY29uIiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsIl9qc3hSdW50aW1lIiwiX3MiLCIkUmVmcmVzaFNpZyQiLCJlIiwiX19lc01vZHVsZSIsImRlZmF1bHQiLCJHcm92ZU5hdiIsInNpdGVUaXRsZSIsIm5hdkl0ZW1zIiwiZW50cnlLZXkiLCJ3cml0YWJsZSIsIm9wZW5FZGl0b3IiLCJlZGl0QnVzeSIsImVkaXRSZWZ1c2VkIiwiZWRpdEhpbnQiLCJ0aGVtZSIsInNldFRoZW1lIiwibGlnaHQiLCJzZXRMaWdodCIsIm1lbnVPcGVuIiwic2V0TWVudU9wZW4iLCJzZXRTZWFyY2hPcGVuIiwic2V0RHJhd2VyT3BlbiIsInVzZVNoZWxsIiwiZm9sbG93IiwidXNlRm9sbG93TGluayIsImFza0dyb3ZlIiwiZWwiLCJkb2N1bWVudCIsInF1ZXJ5U2VsZWN0b3IiLCJmb2N1cyIsIm5ld0VudHJ5IiwiZ2V0Q29udGVudFJvb3QiLCJtZW51UmVmIiwidXNlT3ZlcmxheUZvY3VzRGlzbWlzcyIsInRyYXBUYWIiLCJvbk1lbnVLZXlEb3duIiwiaXRlbXMiLCJjdXJyZW50IiwicXVlcnlTZWxlY3RvckFsbCIsImxlbmd0aCIsImlkeCIsImluZGV4T2YiLCJhY3RpdmVFbGVtZW50IiwibW92ZSIsImkiLCJwcmV2ZW50RGVmYXVsdCIsIm5leHQiLCJnZXRBdHRyaWJ1dGUiLCJjbGljayIsImtleSIsImpzeHMiLCJjbGFzc05hbWUiLCJjaGlsZHJlbiIsImpzeCIsIm9uQ2xpY2siLCJuYW1lIiwiTGluayIsImhyZWYiLCJmb2xsb3dMaW5rT25DbGljayIsImhvbWVLZXkiLCJmcm9tIiwic3R5bGUiLCJiYWNrZ3JvdW5kIiwibWFwIiwibiIsImxhYmVsIiwiRnJhZ21lbnQiLCJ0aXRsZSIsImRpc2FibGVkIiwicm9sZSIsIkVESVRfUkVGVVNFRF9OT1RJQ0UiLCJvIiwicmVmIiwidGFiSW5kZXgiLCJvbktleURvd24iLCJUSEVNRVMiLCJ0IiwiaWQiLCJzd2F0Y2giLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkdyb3ZlTmF2LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBMaW5rIH0gZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9zZGsnO1xuaW1wb3J0IHsgdXNlU2hlbGwsIEVESVRfUkVGVVNFRF9OT1RJQ0UgfSBmcm9tICcuLi9saWIvc2hlbGwnO1xuaW1wb3J0IHsgZ2V0Q29udGVudFJvb3QgfSBmcm9tICcuLi9saWIvY29udGVudFJvb3QnO1xuaW1wb3J0IHsgaG9tZUtleSB9IGZyb20gJy4uL2xpYi9jb250ZW50JztcbmltcG9ydCB7IHVzZUZvbGxvd0xpbmsgfSBmcm9tICcuLi9ob29rcy91c2VGb2xsb3dMaW5rJztcbmltcG9ydCB7IGZvbGxvd0xpbmtPbkNsaWNrIH0gZnJvbSAnLi4vbGliL25hdmlnYXRpb25Qb2xpY3knO1xuaW1wb3J0IHsgdXNlT3ZlcmxheUZvY3VzRGlzbWlzcyB9IGZyb20gJy4uL2hvb2tzL3VzZU92ZXJsYXlGb2N1c0Rpc21pc3MnO1xuaW1wb3J0IHsgVEhFTUVTIH0gZnJvbSAnLi4vZGF0YS90aGVtZXMnO1xuaW1wb3J0IEljb24gZnJvbSAnLi9JY29uJztcblxuLy8gYDxHcm92ZU5hdi8+YCDigJQgdGhlIHRvcCBuYXZpZ2F0aW9uIGJhci4gSW1wb3J0LWZyZWUgaW4gTURYLCBzbyBhIGxheW91dCBwbGFjZXNcbi8vIGl0IHdpdGggYDxHcm92ZU5hdi8+YC4gSXRzIGludGVyYWN0aXZlIHN0YXRlIChkcmF3ZXIgLyBzZWFyY2ggLyB0aGVtZSBtZW51KVxuLy8gbGl2ZXMgaW4gdGhlIHNoZWxsIGNvbnRleHQ7IHRoaXMgY29tcG9uZW50IG9ubHkgYXJyYW5nZXMgYW5kIGRyaXZlcyBpdC5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEdyb3ZlTmF2KCkge1xuICBjb25zdCB7XG4gICAgc2l0ZVRpdGxlLFxuICAgIG5hdkl0ZW1zLFxuICAgIGVudHJ5S2V5LFxuICAgIHdyaXRhYmxlLFxuICAgIG9wZW5FZGl0b3IsXG4gICAgZWRpdEJ1c3ksXG4gICAgZWRpdFJlZnVzZWQsXG4gICAgZWRpdEhpbnQsXG4gICAgdGhlbWUsXG4gICAgc2V0VGhlbWUsXG4gICAgbGlnaHQsXG4gICAgc2V0TGlnaHQsXG4gICAgbWVudU9wZW4sXG4gICAgc2V0TWVudU9wZW4sXG4gICAgc2V0U2VhcmNoT3BlbixcbiAgICBzZXREcmF3ZXJPcGVuLFxuICB9ID0gdXNlU2hlbGwoKTtcbiAgY29uc3QgZm9sbG93ID0gdXNlRm9sbG93TGluaygpO1xuXG4gIGNvbnN0IGFza0dyb3ZlID0gKCkgPT4ge1xuICAgIGNvbnN0IGVsID0gKGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJy5nYS1mb290IGlucHV0JykgfHwgZG9jdW1lbnQucXVlcnlTZWxlY3RvcignLmdhLWxpbmUgaW5wdXQnKSkgYXMgSFRNTEVsZW1lbnQgfCBudWxsO1xuICAgIGVsPy5mb2N1cygpO1xuICB9O1xuICAvLyBUaGUgbmV3IGVudHJ5IGJlbG9uZ3MgdG8gd2hpY2hldmVyIGNvcnB1cyBpcyBtb3VudGVkLCBzbyBpdCBpcyBuYW1lZCBmcm9tIHRoZVxuICAvLyBjb250ZW50IFJPT1QgcmF0aGVyIHRoYW4gdGhlIGZvcmsncyBgY29udGVudC9gIGxpdGVyYWwg4oCUIHVuZGVyIGRpc3BhdGNoIHRoZSBsYXR0ZXJcbiAgLy8gd291bGQgY3JlYXRlIGEgZmlsZSBpbiBHcm92ZSdzIG93biByZXBvIChSMy0yNjYpLlxuICBjb25zdCBuZXdFbnRyeSA9ICgpID0+IG9wZW5FZGl0b3IoYCR7Z2V0Q29udGVudFJvb3QoKX11bnRpdGxlZC5tZHhgKTtcblxuICAvLyBUaGUgdGhlbWUgbWVudSdzIGNvbnRyYWN0IChSMy02MDgpOiB0aGUgc2hhcmVkIG92ZXJsYXkgaG9vayB3aXRoIFRhYi10cmFwXG4gIC8vIE9GRiAobWVudXMgZG8gbm90IHRyYXAgVGFiKSwgcGx1cyB0aGUgbWVudSBrZXlkb3duIG1hcCDigJQgYXJyb3dzIHdhbGsgdGhlXG4gIC8vIG1lbnVpdGVtcywgRXNjYXBlIGNsb3NlcyAodGhlIGhvb2spLCBmb2N1cyByZXR1cm5zIHRvIHRoZSB0aGVtZSBidXR0b24uXG4gIGNvbnN0IG1lbnVSZWYgPSB1c2VPdmVybGF5Rm9jdXNEaXNtaXNzKG1lbnVPcGVuLCAoKSA9PiBzZXRNZW51T3BlbihmYWxzZSksIHsgdHJhcFRhYjogZmFsc2UgfSk7XG4gIGNvbnN0IG9uTWVudUtleURvd24gPSAoZTogUmVhY3QuS2V5Ym9hcmRFdmVudCkgPT4ge1xuICAgIGNvbnN0IGl0ZW1zID0gWy4uLihtZW51UmVmLmN1cnJlbnQ/LnF1ZXJ5U2VsZWN0b3JBbGw8SFRNTEVsZW1lbnQ+KCdbcm9sZV49XCJtZW51aXRlbVwiXScpID8/IFtdKV07XG4gICAgaWYgKCFpdGVtcy5sZW5ndGgpIHJldHVybjtcbiAgICBjb25zdCBpZHggPSBpdGVtcy5pbmRleE9mKGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQgYXMgSFRNTEVsZW1lbnQpO1xuICAgIGNvbnN0IG1vdmUgPSAoaTogbnVtYmVyKSA9PiB7XG4gICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICBjb25zdCBuZXh0ID0gaXRlbXNbKGkgKyBpdGVtcy5sZW5ndGgpICUgaXRlbXMubGVuZ3RoXTtcbiAgICAgIG5leHQuZm9jdXMoKTtcbiAgICAgIC8vIEFQRyBtZW51IHJhZGlvczogYXJyb3dzIE1PVkUgZm9jdXMgQU5EIGFjdGl2YXRlIOKAlCB0aGUgcmFkaW8gdGhlIGFycm93XG4gICAgICAvLyBsYW5kcyBvbiBpcyBzZWxlY3RlZCwgc28gdGhlIGtleWJvYXJkIGFsb25lIGNhbiBjaGFuZ2UgdGhlIHRoZW1lLlxuICAgICAgaWYgKG5leHQuZ2V0QXR0cmlidXRlKCdyb2xlJykgPT09ICdtZW51aXRlbXJhZGlvJyAmJiBuZXh0LmdldEF0dHJpYnV0ZSgnYXJpYS1jaGVja2VkJykgIT09ICd0cnVlJykgbmV4dC5jbGljaygpO1xuICAgIH07XG4gICAgaWYgKGUua2V5ID09PSAnQXJyb3dEb3duJykgbW92ZShpZHggKyAxKTtcbiAgICBlbHNlIGlmIChlLmtleSA9PT0gJ0Fycm93VXAnKSBtb3ZlKGlkeCAtIDEpO1xuICAgIGVsc2UgaWYgKGUua2V5ID09PSAnSG9tZScpIG1vdmUoMCk7XG4gICAgZWxzZSBpZiAoZS5rZXkgPT09ICdFbmQnKSBtb3ZlKGl0ZW1zLmxlbmd0aCAtIDEpO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPG5hdiBjbGFzc05hbWU9XCJncm92ZS1uYXZcIj5cbiAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiZ3JvdmUtaGFtYnVyZ2VyIGljYnRuXCIgYXJpYS1sYWJlbD1cIk1lbnVcIiBvbkNsaWNrPXsoKSA9PiBzZXREcmF3ZXJPcGVuKHRydWUpfT5cbiAgICAgICAgPEljb24gbmFtZT1cImxpc3RcIiAvPlxuICAgICAgPC9idXR0b24+XG4gICAgICA8TGluayBocmVmPVwiL1wiIGNsYXNzTmFtZT1cImdyb3ZlLWJyYW5kXCIgb25DbGljaz17Zm9sbG93TGlua09uQ2xpY2soZm9sbG93LCB7IGtleTogaG9tZUtleSgpLCBocmVmOiAnLycsIGZyb206IGVudHJ5S2V5IH0pfT5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGlsZVwiIHN0eWxlPXt7IGJhY2tncm91bmQ6ICd2YXIoLS1ncmFkKScgfX0gLz5cbiAgICAgICAge3NpdGVUaXRsZX1cbiAgICAgIDwvTGluaz5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JvdmUtbmF2X19saW5rc1wiPlxuICAgICAgICB7bmF2SXRlbXMubWFwKChuKSA9PiAoXG4gICAgICAgICAgPExpbmtcbiAgICAgICAgICAgIGtleT17bi5rZXl9XG4gICAgICAgICAgICBocmVmPXtuLmhyZWZ9XG4gICAgICAgICAgICBkYXRhLWN1cj17bi5rZXkgPT09IGVudHJ5S2V5ID8gJzEnIDogJzAnfVxuICAgICAgICAgICAgb25DbGljaz17Zm9sbG93TGlua09uQ2xpY2soZm9sbG93LCB7IGtleTogbi5rZXksIGhyZWY6IG4uaHJlZiwgZnJvbTogZW50cnlLZXkgfSl9XG4gICAgICAgICAgPlxuICAgICAgICAgICAge24ubGFiZWx9XG4gICAgICAgICAgPC9MaW5rPlxuICAgICAgICApKX1cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncm92ZS1uYXZfX2NsdXN0ZXJcIj5cbiAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJpY2J0blwiIGFyaWEtbGFiZWw9XCJTZWFyY2hcIiBvbkNsaWNrPXsoKSA9PiBzZXRTZWFyY2hPcGVuKHRydWUpfT5cbiAgICAgICAgICA8SWNvbiBuYW1lPVwic2VhcmNoXCIgLz5cbiAgICAgICAgPC9idXR0b24+XG4gICAgICAgIHt3cml0YWJsZSAmJiAoXG4gICAgICAgICAgPD5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaWNidG5cIlxuICAgICAgICAgICAgICBhcmlhLWxhYmVsPXtlZGl0QnVzeSA/ICdPcGVuaW5nIGVkaXRvcuKApicgOiAnTmV3IGVudHJ5J31cbiAgICAgICAgICAgICAgdGl0bGU9e2VkaXRIaW50fVxuICAgICAgICAgICAgICBkYXRhLWJ1c3k9e2VkaXRCdXN5ID8gJzEnIDogJzAnfVxuICAgICAgICAgICAgICBkaXNhYmxlZD17ZWRpdEJ1c3l9XG4gICAgICAgICAgICAgIG9uQ2xpY2s9e25ld0VudHJ5fVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwicGx1c1wiIC8+XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIHtlZGl0UmVmdXNlZCAmJiAoXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImdyb3ZlLWVkaXQtcmVmdXNlZFwiIHJvbGU9XCJzdGF0dXNcIiB0aXRsZT17RURJVF9SRUZVU0VEX05PVElDRX0+XG4gICAgICAgICAgICAgICAge0VESVRfUkVGVVNFRF9OT1RJQ0V9XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC8+XG4gICAgICAgICl9XG4gICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiaWNidG5cIiBhcmlhLWxhYmVsPVwiQXNrIEdyb3ZlXCIgb25DbGljaz17YXNrR3JvdmV9PlxuICAgICAgICAgIDxJY29uIG5hbWU9XCJtZXNzYWdlXCIgLz5cbiAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JvdmUtbmF2X19tb3JlXCI+XG4gICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJpY2J0biBncm92ZS10aGVtZS1jb250cm9sXCIgdGl0bGU9XCJUaGVtZVwiIGFyaWEtZXhwYW5kZWQ9e21lbnVPcGVufSBhcmlhLWhhc3BvcHVwPVwibWVudVwiIG9uQ2xpY2s9eygpID0+IHNldE1lbnVPcGVuKChvKSA9PiAhbyl9PlxuICAgICAgICAgICAg4piAXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAge21lbnVPcGVuID8gKFxuICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJndG1fX3NjcmltXCIgb25DbGljaz17KCkgPT4gc2V0TWVudU9wZW4oZmFsc2UpfSAvPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyb3ZlLXRoZW1lLW1lbnVcIiByb2xlPVwibWVudVwiIGFyaWEtbGFiZWw9XCJUaGVtZVwiIHJlZj17bWVudVJlZn0gdGFiSW5kZXg9ey0xfSBvbktleURvd249e29uTWVudUtleURvd259PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3RtX19oXCI+VGhlbWU8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImd0bV9fbGlzdFwiPlxuICAgICAgICAgICAgICAgICAge1RIRU1FUy5tYXAoKHQpID0+IChcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIGtleT17dC5pZH1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJndG1fX3Jvd1wiXG4gICAgICAgICAgICAgICAgICAgICAgZGF0YS1jdXI9e3RoZW1lID09PSB0LmlkID8gJzEnIDogJzAnfVxuICAgICAgICAgICAgICAgICAgICAgIHJvbGU9XCJtZW51aXRlbXJhZGlvXCJcbiAgICAgICAgICAgICAgICAgICAgICBhcmlhLWNoZWNrZWQ9e3RoZW1lID09PSB0LmlkfVxuICAgICAgICAgICAgICAgICAgICAgIHRhYkluZGV4PXstMX1cbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRUaGVtZSh0LmlkKX1cbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImd0bV9fc3dcIiBzdHlsZT17eyBiYWNrZ3JvdW5kOiB0LnN3YXRjaCB9fSAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImd0bV9fbmFtZVwiPnt0LmxhYmVsfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICB7dGhlbWUgPT09IHQuaWQgPyA8c3BhbiBjbGFzc05hbWU9XCJndG1fX2NrXCI+PEljb24gbmFtZT1cImNoZWNrXCIgLz48L3NwYW4+IDogbnVsbH1cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICB7LyogUjMtMzA4OiB0aGUgYXBwZWFyYW5jZSBjb250cm9sIGlzIG9mZmVyZWQgZm9yIEVWRVJZIHRoZW1lIOKAlCBlYWNoXG4gICAgICAgICAgICAgICAgICAgIGNhdGFsb2d1ZSBlbnRyeSBzaGlwcyBib3RoIHBvbGFyaXRpZXMsIHNvIGdhdGluZyBpdCBvblxuICAgICAgICAgICAgICAgICAgICBgZGVmYXVsdGAgd291bGQgYmUgc2luZ2xlLXBvbGFyaXR5IGJ5IGNvbnN0cnVjdGlvbiBhZ2Fpbi4gKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJndG1fX2FwcGVhcmFuY2VcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3RtX19zdWJcIj5BcHBlYXJhbmNlPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImd0bV9fc2VnXCI+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gZGF0YS1vbj17IWxpZ2h0ID8gJzEnIDogJzAnfSByb2xlPVwibWVudWl0ZW1yYWRpb1wiIGFyaWEtY2hlY2tlZD17IWxpZ2h0fSB0YWJJbmRleD17LTF9IG9uQ2xpY2s9eygpID0+IHNldExpZ2h0KGZhbHNlKX0+XG4gICAgICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cIm1vb25cIiAvPiBEYXJrXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGRhdGEtb249e2xpZ2h0ID8gJzEnIDogJzAnfSByb2xlPVwibWVudWl0ZW1yYWRpb1wiIGFyaWEtY2hlY2tlZD17bGlnaHR9IHRhYkluZGV4PXstMX0gb25DbGljaz17KCkgPT4gc2V0TGlnaHQodHJ1ZSl9PlxuICAgICAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJzdW5cIiAvPiBMaWdodFxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvPlxuICAgICAgICAgICkgOiBudWxsfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvbmF2PlxuICApO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBLElBQUFBLElBQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLE1BQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLFlBQUEsR0FBQUYsT0FBQTtBQUNBLElBQUFHLFFBQUEsR0FBQUgsT0FBQTtBQUNBLElBQUFJLGNBQUEsR0FBQUosT0FBQTtBQUNBLElBQUFLLGlCQUFBLEdBQUFMLE9BQUE7QUFDQSxJQUFBTSx1QkFBQSxHQUFBTixPQUFBO0FBQ0EsSUFBQU8sT0FBQSxHQUFBUCxPQUFBO0FBQ0EsSUFBQVEsS0FBQSxHQUFBQyxzQkFBQSxDQUFBVCxPQUFBO0FBQTBCLElBQUFVLFdBQUEsR0FBQVYsT0FBQTtBQUFBLElBQUFXLEVBQUEsR0FBQUMsWUFBQSxJQUUxQjtBQUNBO0FBQ0E7QUFBQSxTQUFBSCx1QkFBQUksQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQUNlLFNBQVNHLFFBQVFBLENBQUEsRUFBRztFQUFBTCxFQUFBO0VBQ2pDLE1BQU07SUFDSk0sU0FBUztJQUNUQyxRQUFRO0lBQ1JDLFFBQVE7SUFDUkMsUUFBUTtJQUNSQyxVQUFVO0lBQ1ZDLFFBQVE7SUFDUkMsV0FBVztJQUNYQyxRQUFRO0lBQ1JDLEtBQUs7SUFDTEMsUUFBUTtJQUNSQyxLQUFLO0lBQ0xDLFFBQVE7SUFDUkMsUUFBUTtJQUNSQyxXQUFXO0lBQ1hDLGFBQWE7SUFDYkM7RUFDRixDQUFDLEdBQUcsSUFBQUMsZUFBUSxFQUFDLENBQUM7RUFDZCxNQUFNQyxNQUFNLEdBQUcsSUFBQUMsNEJBQWEsRUFBQyxDQUFDO0VBRTlCLE1BQU1DLFFBQVEsR0FBR0EsQ0FBQSxLQUFNO0lBQ3JCLE1BQU1DLEVBQUUsR0FBSUMsUUFBUSxDQUFDQyxhQUFhLENBQUMsZ0JBQWdCLENBQUMsSUFBSUQsUUFBUSxDQUFDQyxhQUFhLENBQUMsZ0JBQWdCLENBQXdCO0lBQ3ZIRixFQUFFLEVBQUVHLEtBQUssQ0FBQyxDQUFDO0VBQ2IsQ0FBQztFQUNEO0VBQ0E7RUFDQTtFQUNBLE1BQU1DLFFBQVEsR0FBR0EsQ0FBQSxLQUFNcEIsVUFBVSxDQUFDLEdBQUcsSUFBQXFCLDJCQUFjLEVBQUMsQ0FBQyxjQUFjLENBQUM7O0VBRXBFO0VBQ0E7RUFDQTtFQUNBLE1BQU1DLE9BQU8sR0FBRyxJQUFBQyw4Q0FBc0IsRUFBQ2YsUUFBUSxFQUFFLE1BQU1DLFdBQVcsQ0FBQyxLQUFLLENBQUMsRUFBRTtJQUFFZSxPQUFPLEVBQUU7RUFBTSxDQUFDLENBQUM7RUFDOUYsTUFBTUMsYUFBYSxHQUFJakMsQ0FBc0IsSUFBSztJQUNoRCxNQUFNa0MsS0FBSyxHQUFHLENBQUMsSUFBSUosT0FBTyxDQUFDSyxPQUFPLEVBQUVDLGdCQUFnQixDQUFjLG9CQUFvQixDQUFDLElBQUksRUFBRSxDQUFDLENBQUM7SUFDL0YsSUFBSSxDQUFDRixLQUFLLENBQUNHLE1BQU0sRUFBRTtJQUNuQixNQUFNQyxHQUFHLEdBQUdKLEtBQUssQ0FBQ0ssT0FBTyxDQUFDZCxRQUFRLENBQUNlLGFBQTRCLENBQUM7SUFDaEUsTUFBTUMsSUFBSSxHQUFJQyxDQUFTLElBQUs7TUFDMUIxQyxDQUFDLENBQUMyQyxjQUFjLENBQUMsQ0FBQztNQUNsQixNQUFNQyxJQUFJLEdBQUdWLEtBQUssQ0FBQyxDQUFDUSxDQUFDLEdBQUdSLEtBQUssQ0FBQ0csTUFBTSxJQUFJSCxLQUFLLENBQUNHLE1BQU0sQ0FBQztNQUNyRE8sSUFBSSxDQUFDakIsS0FBSyxDQUFDLENBQUM7TUFDWjtNQUNBO01BQ0EsSUFBSWlCLElBQUksQ0FBQ0MsWUFBWSxDQUFDLE1BQU0sQ0FBQyxLQUFLLGVBQWUsSUFBSUQsSUFBSSxDQUFDQyxZQUFZLENBQUMsY0FBYyxDQUFDLEtBQUssTUFBTSxFQUFFRCxJQUFJLENBQUNFLEtBQUssQ0FBQyxDQUFDO0lBQ2pILENBQUM7SUFDRCxJQUFJOUMsQ0FBQyxDQUFDK0MsR0FBRyxLQUFLLFdBQVcsRUFBRU4sSUFBSSxDQUFDSCxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FDcEMsSUFBSXRDLENBQUMsQ0FBQytDLEdBQUcsS0FBSyxTQUFTLEVBQUVOLElBQUksQ0FBQ0gsR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDLEtBQ3ZDLElBQUl0QyxDQUFDLENBQUMrQyxHQUFHLEtBQUssTUFBTSxFQUFFTixJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FDOUIsSUFBSXpDLENBQUMsQ0FBQytDLEdBQUcsS0FBSyxLQUFLLEVBQUVOLElBQUksQ0FBQ1AsS0FBSyxDQUFDRyxNQUFNLEdBQUcsQ0FBQyxDQUFDO0VBQ2xELENBQUM7RUFFRCxvQkFDRSxJQUFBeEMsV0FBQSxDQUFBbUQsSUFBQTtJQUFLQyxTQUFTLEVBQUMsV0FBVztJQUFBQyxRQUFBLGdCQUN4QixJQUFBckQsV0FBQSxDQUFBc0QsR0FBQTtNQUFRRixTQUFTLEVBQUMsdUJBQXVCO01BQUMsY0FBVyxNQUFNO01BQUNHLE9BQU8sRUFBRUEsQ0FBQSxLQUFNakMsYUFBYSxDQUFDLElBQUksQ0FBRTtNQUFBK0IsUUFBQSxlQUM3RixJQUFBckQsV0FBQSxDQUFBc0QsR0FBQSxFQUFDeEQsS0FBQSxDQUFBTyxPQUFJO1FBQUNtRCxJQUFJLEVBQUM7TUFBTSxDQUFFO0lBQUMsQ0FDZCxDQUFDLGVBQ1QsSUFBQXhELFdBQUEsQ0FBQW1ELElBQUEsRUFBQzlELElBQUEsQ0FBQW9FLElBQUk7TUFBQ0MsSUFBSSxFQUFDLEdBQUc7TUFBQ04sU0FBUyxFQUFDLGFBQWE7TUFBQ0csT0FBTyxFQUFFLElBQUFJLG1DQUFpQixFQUFDbkMsTUFBTSxFQUFFO1FBQUUwQixHQUFHLEVBQUUsSUFBQVUsZ0JBQU8sRUFBQyxDQUFDO1FBQUVGLElBQUksRUFBRSxHQUFHO1FBQUVHLElBQUksRUFBRXBEO01BQVMsQ0FBQyxDQUFFO01BQUE0QyxRQUFBLGdCQUN2SCxJQUFBckQsV0FBQSxDQUFBc0QsR0FBQTtRQUFNRixTQUFTLEVBQUMsTUFBTTtRQUFDVSxLQUFLLEVBQUU7VUFBRUMsVUFBVSxFQUFFO1FBQWM7TUFBRSxDQUFFLENBQUMsRUFDOUR4RCxTQUFTO0lBQUEsQ0FDTixDQUFDLGVBQ1AsSUFBQVAsV0FBQSxDQUFBc0QsR0FBQTtNQUFLRixTQUFTLEVBQUMsa0JBQWtCO01BQUFDLFFBQUEsRUFDOUI3QyxRQUFRLENBQUN3RCxHQUFHLENBQUVDLENBQUMsaUJBQ2QsSUFBQWpFLFdBQUEsQ0FBQXNELEdBQUEsRUFBQ2pFLElBQUEsQ0FBQW9FLElBQUk7UUFFSEMsSUFBSSxFQUFFTyxDQUFDLENBQUNQLElBQUs7UUFDYixZQUFVTyxDQUFDLENBQUNmLEdBQUcsS0FBS3pDLFFBQVEsR0FBRyxHQUFHLEdBQUcsR0FBSTtRQUN6QzhDLE9BQU8sRUFBRSxJQUFBSSxtQ0FBaUIsRUFBQ25DLE1BQU0sRUFBRTtVQUFFMEIsR0FBRyxFQUFFZSxDQUFDLENBQUNmLEdBQUc7VUFBRVEsSUFBSSxFQUFFTyxDQUFDLENBQUNQLElBQUk7VUFBRUcsSUFBSSxFQUFFcEQ7UUFBUyxDQUFDLENBQUU7UUFBQTRDLFFBQUEsRUFFaEZZLENBQUMsQ0FBQ0M7TUFBSyxHQUxIRCxDQUFDLENBQUNmLEdBTUgsQ0FDUDtJQUFDLENBQ0MsQ0FBQyxlQUNOLElBQUFsRCxXQUFBLENBQUFtRCxJQUFBO01BQUtDLFNBQVMsRUFBQyxvQkFBb0I7TUFBQUMsUUFBQSxnQkFDakMsSUFBQXJELFdBQUEsQ0FBQXNELEdBQUE7UUFBUUYsU0FBUyxFQUFDLE9BQU87UUFBQyxjQUFXLFFBQVE7UUFBQ0csT0FBTyxFQUFFQSxDQUFBLEtBQU1sQyxhQUFhLENBQUMsSUFBSSxDQUFFO1FBQUFnQyxRQUFBLGVBQy9FLElBQUFyRCxXQUFBLENBQUFzRCxHQUFBLEVBQUN4RCxLQUFBLENBQUFPLE9BQUk7VUFBQ21ELElBQUksRUFBQztRQUFRLENBQUU7TUFBQyxDQUNoQixDQUFDLEVBQ1I5QyxRQUFRLGlCQUNQLElBQUFWLFdBQUEsQ0FBQW1ELElBQUEsRUFBQW5ELFdBQUEsQ0FBQW1FLFFBQUE7UUFBQWQsUUFBQSxnQkFDRSxJQUFBckQsV0FBQSxDQUFBc0QsR0FBQTtVQUNFRixTQUFTLEVBQUMsT0FBTztVQUNqQixjQUFZeEMsUUFBUSxHQUFHLGlCQUFpQixHQUFHLFdBQVk7VUFDdkR3RCxLQUFLLEVBQUV0RCxRQUFTO1VBQ2hCLGFBQVdGLFFBQVEsR0FBRyxHQUFHLEdBQUcsR0FBSTtVQUNoQ3lELFFBQVEsRUFBRXpELFFBQVM7VUFDbkIyQyxPQUFPLEVBQUV4QixRQUFTO1VBQUFzQixRQUFBLGVBRWxCLElBQUFyRCxXQUFBLENBQUFzRCxHQUFBLEVBQUN4RCxLQUFBLENBQUFPLE9BQUk7WUFBQ21ELElBQUksRUFBQztVQUFNLENBQUU7UUFBQyxDQUNkLENBQUMsRUFDUjNDLFdBQVcsaUJBQ1YsSUFBQWIsV0FBQSxDQUFBc0QsR0FBQTtVQUFNRixTQUFTLEVBQUMsb0JBQW9CO1VBQUNrQixJQUFJLEVBQUMsUUFBUTtVQUFDRixLQUFLLEVBQUVHLDBCQUFvQjtVQUFBbEIsUUFBQSxFQUMzRWtCO1FBQW1CLENBQ2hCLENBQ1A7TUFBQSxDQUNELENBQ0gsZUFDRCxJQUFBdkUsV0FBQSxDQUFBc0QsR0FBQTtRQUFRRixTQUFTLEVBQUMsT0FBTztRQUFDLGNBQVcsV0FBVztRQUFDRyxPQUFPLEVBQUU3QixRQUFTO1FBQUEyQixRQUFBLGVBQ2pFLElBQUFyRCxXQUFBLENBQUFzRCxHQUFBLEVBQUN4RCxLQUFBLENBQUFPLE9BQUk7VUFBQ21ELElBQUksRUFBQztRQUFTLENBQUU7TUFBQyxDQUNqQixDQUFDLGVBQ1QsSUFBQXhELFdBQUEsQ0FBQW1ELElBQUE7UUFBS0MsU0FBUyxFQUFDLGlCQUFpQjtRQUFBQyxRQUFBLGdCQUM5QixJQUFBckQsV0FBQSxDQUFBc0QsR0FBQTtVQUFRRixTQUFTLEVBQUMsMkJBQTJCO1VBQUNnQixLQUFLLEVBQUMsT0FBTztVQUFDLGlCQUFlakQsUUFBUztVQUFDLGlCQUFjLE1BQU07VUFBQ29DLE9BQU8sRUFBRUEsQ0FBQSxLQUFNbkMsV0FBVyxDQUFFb0QsQ0FBQyxJQUFLLENBQUNBLENBQUMsQ0FBRTtVQUFBbkIsUUFBQSxFQUFDO1FBRWpKLENBQVEsQ0FBQyxFQUNSbEMsUUFBUSxnQkFDUCxJQUFBbkIsV0FBQSxDQUFBbUQsSUFBQSxFQUFBbkQsV0FBQSxDQUFBbUUsUUFBQTtVQUFBZCxRQUFBLGdCQUNFLElBQUFyRCxXQUFBLENBQUFzRCxHQUFBO1lBQUtGLFNBQVMsRUFBQyxZQUFZO1lBQUNHLE9BQU8sRUFBRUEsQ0FBQSxLQUFNbkMsV0FBVyxDQUFDLEtBQUs7VUFBRSxDQUFFLENBQUMsZUFDakUsSUFBQXBCLFdBQUEsQ0FBQW1ELElBQUE7WUFBS0MsU0FBUyxFQUFDLGtCQUFrQjtZQUFDa0IsSUFBSSxFQUFDLE1BQU07WUFBQyxjQUFXLE9BQU87WUFBQ0csR0FBRyxFQUFFeEMsT0FBUTtZQUFDeUMsUUFBUSxFQUFFLENBQUMsQ0FBRTtZQUFDQyxTQUFTLEVBQUV2QyxhQUFjO1lBQUFpQixRQUFBLGdCQUNwSCxJQUFBckQsV0FBQSxDQUFBc0QsR0FBQTtjQUFLRixTQUFTLEVBQUMsUUFBUTtjQUFBQyxRQUFBLEVBQUM7WUFBSyxDQUFLLENBQUMsZUFDbkMsSUFBQXJELFdBQUEsQ0FBQXNELEdBQUE7Y0FBS0YsU0FBUyxFQUFDLFdBQVc7Y0FBQUMsUUFBQSxFQUN2QnVCLGNBQU0sQ0FBQ1osR0FBRyxDQUFFYSxDQUFDLGlCQUNaLElBQUE3RSxXQUFBLENBQUFtRCxJQUFBO2dCQUVFQyxTQUFTLEVBQUMsVUFBVTtnQkFDcEIsWUFBVXJDLEtBQUssS0FBSzhELENBQUMsQ0FBQ0MsRUFBRSxHQUFHLEdBQUcsR0FBRyxHQUFJO2dCQUNyQ1IsSUFBSSxFQUFDLGVBQWU7Z0JBQ3BCLGdCQUFjdkQsS0FBSyxLQUFLOEQsQ0FBQyxDQUFDQyxFQUFHO2dCQUM3QkosUUFBUSxFQUFFLENBQUMsQ0FBRTtnQkFDYm5CLE9BQU8sRUFBRUEsQ0FBQSxLQUFNdkMsUUFBUSxDQUFDNkQsQ0FBQyxDQUFDQyxFQUFFLENBQUU7Z0JBQUF6QixRQUFBLGdCQUU5QixJQUFBckQsV0FBQSxDQUFBc0QsR0FBQTtrQkFBTUYsU0FBUyxFQUFDLFNBQVM7a0JBQUNVLEtBQUssRUFBRTtvQkFBRUMsVUFBVSxFQUFFYyxDQUFDLENBQUNFO2tCQUFPO2dCQUFFLENBQUUsQ0FBQyxlQUM3RCxJQUFBL0UsV0FBQSxDQUFBc0QsR0FBQTtrQkFBTUYsU0FBUyxFQUFDLFdBQVc7a0JBQUFDLFFBQUEsRUFBRXdCLENBQUMsQ0FBQ1g7Z0JBQUssQ0FBTyxDQUFDLEVBQzNDbkQsS0FBSyxLQUFLOEQsQ0FBQyxDQUFDQyxFQUFFLGdCQUFHLElBQUE5RSxXQUFBLENBQUFzRCxHQUFBO2tCQUFNRixTQUFTLEVBQUMsU0FBUztrQkFBQUMsUUFBQSxlQUFDLElBQUFyRCxXQUFBLENBQUFzRCxHQUFBLEVBQUN4RCxLQUFBLENBQUFPLE9BQUk7b0JBQUNtRCxJQUFJLEVBQUM7a0JBQU8sQ0FBRTtnQkFBQyxDQUFNLENBQUMsR0FBRyxJQUFJO2NBQUEsR0FWMUVxQixDQUFDLENBQUNDLEVBV0QsQ0FDVDtZQUFDLENBQ0MsQ0FBQyxlQUlOLElBQUE5RSxXQUFBLENBQUFtRCxJQUFBO2NBQUtDLFNBQVMsRUFBQyxpQkFBaUI7Y0FBQUMsUUFBQSxnQkFDOUIsSUFBQXJELFdBQUEsQ0FBQXNELEdBQUE7Z0JBQUtGLFNBQVMsRUFBQyxVQUFVO2dCQUFBQyxRQUFBLEVBQUM7Y0FBVSxDQUFLLENBQUMsZUFDMUMsSUFBQXJELFdBQUEsQ0FBQW1ELElBQUE7Z0JBQUtDLFNBQVMsRUFBQyxVQUFVO2dCQUFBQyxRQUFBLGdCQUN2QixJQUFBckQsV0FBQSxDQUFBbUQsSUFBQTtrQkFBUSxXQUFTLENBQUNsQyxLQUFLLEdBQUcsR0FBRyxHQUFHLEdBQUk7a0JBQUNxRCxJQUFJLEVBQUMsZUFBZTtrQkFBQyxnQkFBYyxDQUFDckQsS0FBTTtrQkFBQ3lELFFBQVEsRUFBRSxDQUFDLENBQUU7a0JBQUNuQixPQUFPLEVBQUVBLENBQUEsS0FBTXJDLFFBQVEsQ0FBQyxLQUFLLENBQUU7a0JBQUFtQyxRQUFBLGdCQUMzSCxJQUFBckQsV0FBQSxDQUFBc0QsR0FBQSxFQUFDeEQsS0FBQSxDQUFBTyxPQUFJO29CQUFDbUQsSUFBSSxFQUFDO2tCQUFNLENBQUUsQ0FBQyxTQUN0QjtnQkFBQSxDQUFRLENBQUMsZUFDVCxJQUFBeEQsV0FBQSxDQUFBbUQsSUFBQTtrQkFBUSxXQUFTbEMsS0FBSyxHQUFHLEdBQUcsR0FBRyxHQUFJO2tCQUFDcUQsSUFBSSxFQUFDLGVBQWU7a0JBQUMsZ0JBQWNyRCxLQUFNO2tCQUFDeUQsUUFBUSxFQUFFLENBQUMsQ0FBRTtrQkFBQ25CLE9BQU8sRUFBRUEsQ0FBQSxLQUFNckMsUUFBUSxDQUFDLElBQUksQ0FBRTtrQkFBQW1DLFFBQUEsZ0JBQ3hILElBQUFyRCxXQUFBLENBQUFzRCxHQUFBLEVBQUN4RCxLQUFBLENBQUFPLE9BQUk7b0JBQUNtRCxJQUFJLEVBQUM7a0JBQUssQ0FBRSxDQUFDLFVBQ3JCO2dCQUFBLENBQVEsQ0FBQztjQUFBLENBQ04sQ0FBQztZQUFBLENBQ0gsQ0FBQztVQUFBLENBQ0gsQ0FBQztRQUFBLENBQ04sQ0FBQyxHQUNELElBQUk7TUFBQSxDQUNMLENBQUM7SUFBQSxDQUNILENBQUM7RUFBQSxDQUNILENBQUM7QUFFVjtBQUFDdkQsRUFBQSxDQWxKdUJLLFFBQVE7RUFBQSxRQWtCMUJpQixlQUFRLEVBQ0dFLDRCQUFhLEVBY1pTLDhDQUFzQjtBQUFBO0FBQUE4QyxFQUFBLEdBakNoQjFFLFFBQVE7QUFBQSxJQUFBMEUsRUFBQTtBQUFBQyxZQUFBLENBQUFELEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}