var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = GroveAgent;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
require("core-js/modules/esnext.iterator.some.js");
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
var _shell = require("../lib/shell");
var _useHeadings = require("../hooks/useHeadings");
var _useOverlayFocusDismiss = require("../hooks/useOverlayFocusDismiss");
var _contentRoot = require("../lib/contentRoot");
var _agentTools = require("../lib/agentTools");
var _agentPrompt = require("../lib/agentPrompt");
var _reachCard = require("../lib/reachCard");
var _agentTranscript = require("../lib/agentTranscript");
var _useCatalogAnswered = require("../hooks/useCatalogAnswered");
var _safeSources = require("../lib/safeSources");
var _Icon = _interopRequireDefault(require("./Icon"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // `.grove-agent` — Grove's own embedded agent (GROVE_AGENT_SPEC).
//
// The surface is a FUNCTION of the session's envelope (R-GA-1): the reach card in
// the expanded header is computed from the provider four-state (R3-688 added the
// host-marked `ungranted` — the distinct not-granted cause), the `llm:chat`
// grant (the grant-filtered catalog), mount writability, the corpus packaging,
// tools support, and source trust — never hand-written copy. The loop rides the
// workbench's seam — SDK `runAgent` over the host `llm.chat` slot — and its two
// tools are the mount-chrooted `read_entry` and
// the index query (R-GA-2). The widget never writes (R-GA-3): every change is a
// hand-off to the editor / workbench. Read-only never blocks Q&A (R-GA-5). When a
// provider is bound the egress line is shown unconditionally (R-GA-6). Every
// corpus-derived byte entering the loop is fenced (R-GA-7).
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function GroveAgent({
  writable,
  entryKey,
  entryTitle
}) {
  _s();
  const providerState = (0, _sdk.useChatProviderState)();
  const catalog = (0, _sdk.useCatalog)();
  const index = (0, _sdk.useAllMetadata)();
  const headings = (0, _useHeadings.useHeadings)(entryKey);
  const activeHeading = (0, _useHeadings.useActiveHeading)(headings, entryKey);
  const {
    openEditor,
    editRefused
  } = (0, _shell.useShell)();
  const [open, setOpen] = (0, _react.useState)(false);
  const [detent, setDetent] = (0, _react.useState)('half');
  const [resting, setResting] = (0, _react.useState)('');
  const [draft, setDraft] = (0, _react.useState)('');
  const [rows, setRows] = (0, _react.useState)([]);
  const [streaming, setStreaming] = (0, _react.useState)(false);
  const [errorToast, setErrorToast] = (0, _react.useState)(null);
  const bodyRef = (0, _react.useRef)(null);
  const footRef = (0, _react.useRef)(null);
  // One AbortController per run (R3-608): the composer's stop control aborts the
  // in-flight run through the SDK signal the loop already honours.
  const abortRef = (0, _react.useRef)(null);
  // The panel carries the dialog contract (R3-608): focus in, Tab trapped,
  // Escape, focus return — the shared hook, stack-aware.
  const dialogRef = (0, _useOverlayFocusDismiss.useOverlayFocusDismiss)(open, () => setOpen(false));

  // The envelope, computed (R-GA-1). `llm:chat` appears in the grant-filtered
  // catalog iff this app holds the consent — an ungranted fork reads a DISTINCT
  // cause from a user without a key (G-GA-10).
  const chatGranted = catalog.some(m => m.name === 'llm:chat');
  // Distinguishes "granted nothing" from "has not replied yet" — `catalog` alone cannot,
  // because an empty catalog is a legitimate answer. See the hook for how it is derived.
  const catalogAnswered = (0, _useCatalogAnswered.useCatalogAnswered)();
  const context = (0, _sdk.useAgentContext)({
    entryPath: entryKey,
    entryTitle,
    heading: activeHeading || undefined
  });
  // G-GA-8: a provider without `features.tools` degrades to context-stuffing.
  // Computed ONCE at render scope — the reach card's Q&A qualifier (R3-752) and the
  // ask() path below read the same fact, never two computations of it.
  const toolsSupported = providerState.status === 'configured' && providerState.provider.features.tools === true;
  const reachRows = (0, _react.useMemo)(() => (0, _reachCard.computeReachRows)({
    providerState,
    chatGranted,
    catalogAnswered,
    writable,
    sourceShared: context.sourceShared,
    mountId: (0, _contentRoot.getCorpusMountId)(),
    toolsSupported
  }), [providerState, chatGranted, catalogAnswered, writable, context.sourceShared, toolsSupported]);
  const chips = (0, _react.useMemo)(() => (0, _reachCard.reachChips)(reachRows), [reachRows]);
  const trustLine = (0, _react.useMemo)(() => (0, _reachCard.sourceTrustLine)(context.sourceShared, context.sourceSharedBasis), [context.sourceShared, context.sourceSharedBasis]);
  // R-IX-7 (R3-752): a state flip is ANNOUNCED, not only re-rendered — one standing
  // polite live region whose text is the card's computed summary. A grant flip
  // changes the text, which is what a status region announces; the visually hidden
  // per-row words are static text and announce nothing.
  const reachAnnouncement = (0, _react.useMemo)(() => `What the agent can do here: ${reachRows.map(r => `${r.label} — ${(0, _reachCard.stateWord)(r.state)}`).join('; ')}`, [reachRows]);
  const canAsk = providerState.status === 'configured' && chatGranted;

  // Read at CALL time (a scan may land, the reader may navigate) — refs kept fresh
  // in an effect, never written during render (the react-hooks compiler rejects that).
  const indexRef = (0, _react.useRef)(index);
  const contextRef = (0, _react.useRef)(context);
  const entryRef = (0, _react.useRef)(entryKey);
  const headingRef = (0, _react.useRef)(activeHeading);
  (0, _react.useEffect)(() => {
    indexRef.current = index;
    contextRef.current = context;
    entryRef.current = entryKey;
    headingRef.current = activeHeading;
  }, [index, context, entryKey, activeHeading]);

  // The loop's transcript, kept so follow-up questions replay the tool-use chain.
  const transcriptRef = (0, _react.useRef)([]);
  (0, _react.useEffect)(() => {
    if (open) requestAnimationFrame(() => footRef.current?.focus());
  }, [open]);
  // The panel's only trigger (the resting input) UNMOUNTS when it opens, and
  // its onFocus IS the open action — returning focus to it would reopen the
  // panel. So the close path returns focus to the resting line's SUBMIT
  // control (R-IX-1): a real stop in the same surface that never reopens
  // anything, so Escape never strands the keyboard on <body>. On mount the
  // effect stays quiet (was-open gate) or the panel would open itself.
  const restingGoRef = (0, _react.useRef)(null);
  const wasOpenRef = (0, _react.useRef)(false);
  (0, _react.useEffect)(() => {
    if (wasOpenRef.current && !open) requestAnimationFrame(() => restingGoRef.current?.focus());
    wasOpenRef.current = open;
  }, [open]);
  (0, _react.useEffect)(() => {
    bodyRef.current?.scrollTo({
      top: bodyRef.current.scrollHeight
    });
  }, [rows, streaming]);
  async function ask(question) {
    const q = question.trim();
    if (!q || streaming) return;
    setOpen(true);
    setDraft('');
    setResting('');
    setErrorToast(null);
    setRows(prev => [...prev, {
      kind: 'user',
      text: q
    }]);
    setStreaming(true);

    // G-GA-8: a provider without `features.tools` degrades to context-stuffing —
    // the deixis block, an index summary, and the current entry body ride the
    // prompt; the request carries ZERO tools. The same hoisted fact the reach
    // card's Q&A qualifier reads (R3-752) — computed once at render scope.
    const chroot = (0, _contentRoot.getContentRoot)();
    const currentKey = entryRef.current;
    const contextBlock = (0, _sdk.renderAgentContext)({
      ...contextRef.current,
      entryPath: currentKey,
      heading: headingRef.current || undefined
    });
    let stuffedBody;
    if (!toolsSupported) {
      stuffedBody = await _safeSources.safeSources.read(currentKey).catch(() => undefined);
    }
    const system = (0, _agentPrompt.buildSystemPrompt)({
      contextBlock,
      toolsSupported,
      ...(toolsSupported ? {} : {
        entryBody: stuffedBody,
        entryPath: currentKey,
        index: indexRef.current,
        chroot
      })
    });
    const entryTool = (0, _agentTools.createReadEntryTool)(chroot);
    const metaTool = (0, _agentTools.createGroveMetadataTool)(chroot, () => indexRef.current);
    const execute = (0, _agentTools.toolExecutor)([entryTool, metaTool]);
    const tools = toolsSupported ? (0, _agentTools.groveAgentTools)(chroot, () => indexRef.current) : [];
    let acc = '';
    const pushAssistant = text => setRows(prev => {
      const next = prev.slice();
      if (next.length && next[next.length - 1].kind === 'assistant') next[next.length - 1] = {
        kind: 'assistant',
        text
      };else next.push({
        kind: 'assistant',
        text
      });
      return next;
    });
    const controller = new AbortController();
    abortRef.current = controller;
    try {
      const final = await (0, _sdk.runAgent)({
        client: (0, _sdk.createChatModelClient)(),
        tools,
        execute,
        system,
        prompt: q,
        history: transcriptRef.current,
        maxTurns: 8,
        signal: controller.signal,
        events: {
          onAssistantDelta: t => {
            acc += t;
            pushAssistant(acc);
          },
          onToolUse: (name, input) => {
            acc = '';
            setRows(prev => {
              const next = prev.slice();
              if (next.length && next[next.length - 1].kind === 'assistant' && !next[next.length - 1].text) next.pop();
              next.push({
                kind: 'activity',
                text: (0, _agentTranscript.toolActivityLine)(name, input)
              });
              return next;
            });
          }
        }
      });
      const rendered = (0, _agentTranscript.transcriptToRows)(final);
      // The real loop RESOLVES an aborted run with the partial transcript (a
      // clean stop, never a thrown error) — so the abort check lives here too,
      // not only in the catch: a stopped run keeps what streamed and appends a
      // named Stopped row (R3-608).
      if (controller.signal.aborted) {
        setRows(prev => [...prev, {
          kind: 'activity',
          text: 'Stopped'
        }]);
        return;
      }
      if (!rendered.some(r => r.kind === 'assistant')) throw new Error('empty');
      transcriptRef.current = final.slice();
      setRows(rendered);
    } catch (e) {
      // A stop is not an error (R3-608): the aborted run settles with a named
      // "Stopped" row, and the transcript keeps what streamed so far.
      if (controller.signal.aborted) {
        setRows(prev => [...prev, {
          kind: 'activity',
          text: 'Stopped'
        }]);
        return;
      }
      const code = e?.code || e.message;
      setErrorToast(code === 'auth-required' ? 'no model key connected — add one in Settings' : code === 'forbidden' ? _reachCard.UNGRANTED_CHAT_CAUSE : code === 'cancelled' ? `chat didn't start — ${_reachCard.READING_WORKS_NORMAL}; you can try again anytime` : 'the model or backend errored — try again in a moment');
      setRows(prev => prev.length && prev[prev.length - 1].kind === 'assistant' && !prev[prev.length - 1].text ? prev.slice(0, -1) : prev);
    } finally {
      setStreaming(false);
      if (abortRef.current === controller) abortRef.current = null;
    }
  }
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "grove-agent",
    children: [!open && /*#__PURE__*/(0, _jsxRuntime.jsxs)("form", {
      className: "ga-line",
      onSubmit: e => {
        e.preventDefault();
        if (canAsk) void ask(resting);else setOpen(true);
      },
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "mk"
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("input", {
        value: resting,
        placeholder: `Ask Grove about “${entryTitle}”…`,
        onChange: e => setResting(e.target.value),
        onFocus: () => setOpen(true),
        "aria-label": "Ask Grove"
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        ref: restingGoRef,
        className: "go",
        type: "submit",
        "aria-label": "Ask Grove",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
          name: "send"
        })
      })]
    }), open && /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "ga-scrim",
        onClick: () => setOpen(false)
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "ga-panel",
        "data-detent": detent,
        ref: dialogRef,
        tabIndex: -1,
        role: "dialog",
        "aria-modal": "true",
        "aria-label": "Ask Grove",
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
          className: "ga-panel-inner",
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
            className: "ga-head",
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
              className: "grip",
              onClick: () => setDetent(d => d === 'half' ? 'full' : 'half')
            }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
              className: "mk"
            }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
              className: "id",
              children: "Grove"
            }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
              className: "grow",
              children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
                className: "ic",
                "aria-label": detent === 'half' ? 'Expand' : 'Collapse',
                onClick: () => setDetent(d => d === 'half' ? 'full' : 'half'),
                children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
                  name: detent === 'half' ? 'chevron-down' : 'chevron-right'
                })
              }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
                className: "ic",
                "aria-label": "Close",
                onClick: () => setOpen(false),
                children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
                  name: "x"
                })
              })]
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
            className: "ga-reach",
            role: "list",
            "aria-label": "What the agent can do here",
            children: reachRows.map(r => /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
              className: `ga-reach__row ga-reach__row--${r.state}`,
              role: "listitem",
              children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
                className: "ga-reach__mark",
                "aria-hidden": true,
                children: r.state === 'ok' ? '✓' : r.state === 'blocked' ? '✗' : r.state === 'elsewhere' ? '→' : '·'
              }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
                className: "ga-reach__stateword",
                children: (0, _reachCard.stateWord)(r.state)
              }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
                className: "ga-reach__label",
                children: r.label
              }), r.cause && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
                className: "ga-reach__cause",
                children: r.cause
              }), r.destination && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
                className: "ga-reach__cause",
                children: `→ ${r.destination}`
              }), r.action === 'enable-chat' &&
              /*#__PURE__*/
              // R3-790: the earning affordance. Its click invokes ask() — the
              // ungranted llm:chat invoke fires the HOST's consent dialog on this
              // same activation (site-main#612), Allow mints + lifts, and the
              // same ask proceeds to stream. A decline answers 'cancelled' (the
              // catch below) and the row stays honestly ✗.
              (0, _jsxRuntime.jsx)("button", {
                type: "button",
                className: "ga-reach__enable",
                onClick: () => void ask(draft.trim() || 'Answer in one sentence: what can you tell me about this wiki?'),
                children: "Enable chat"
              })]
            }, r.key))
          }), trustLine && /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
            className: "ga-egress",
            children: trustLine
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
            className: "ga-reach__stateword",
            role: "status",
            children: reachAnnouncement
          }), (0, _reachCard.showEgressDisclosure)(providerState) && /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
            className: "ga-egress",
            children: _reachCard.EGRESS_DISCLOSURE
          }), errorToast && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
            className: "ga-toast",
            role: "status",
            children: errorToast
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
            className: "ga-body",
            ref: bodyRef,
            children: rows.length === 0 ? /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
              children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
                className: "ga-explain",
                children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("b", {
                  children: "Grove's agent"
                }), " answers questions about this wiki \u2014 its entries, tags, and structure \u2014 from the page you're on."]
              }), chips.length > 0 && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
                className: "ga-chips",
                children: chips.map(c => /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
                  className: "ga-chip",
                  onClick: () => void ask(c),
                  children: c
                }, c))
              })]
            }) : rows.map((r, i) => r.kind === 'activity' ? /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
              className: "ga-activity",
              children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
                name: "file"
              }), r.text]
            }, i) : /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
              className: `ga-msg ${r.kind}`,
              children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
                className: `ga-msg__av ${r.kind === 'assistant' ? 'grove' : 'user'}`,
                children: r.kind === 'assistant' ? '' : 'you'
              }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
                className: "ga-msg__b",
                children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
                  className: "ga-msg__who",
                  children: r.kind === 'assistant' ? 'Grove' : 'You'
                }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
                  className: "ga-msg__txt",
                  children: [r.text, streaming && i === rows.length - 1 && r.kind === 'assistant' ? /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
                    className: "ga-cursor"
                  }) : null]
                })]
              })]
            }, i))
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
            className: "ga-foot",
            children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("form", {
              className: "ga-foot__row",
              onSubmit: e => {
                e.preventDefault();
                void ask(draft);
              },
              children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("input", {
                ref: footRef,
                value: draft,
                placeholder: "Ask Grove\u2026",
                disabled: streaming || !canAsk,
                onChange: e => setDraft(e.target.value)
              }), streaming ? /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
                className: "stop",
                type: "button",
                "aria-label": "Stop",
                title: "Stop",
                onClick: () => abortRef.current?.abort(),
                children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
                  name: "x"
                })
              }) : null, /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
                className: "go",
                type: "submit",
                disabled: streaming || !canAsk || !draft.trim(),
                "aria-label": streaming ? 'Answering…' : 'Send',
                title: streaming ? 'Answering…' : 'Send',
                children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
                  name: "send"
                })
              })]
            }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
              className: "ga-foot__hand",
              children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
                children: _reachCard.EGRESS_DISCLOSURE
              }), editRefused && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
                className: "ga-edit-refused",
                role: "status",
                children: _shell.EDIT_REFUSED_NOTICE
              }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
                type: "button",
                onClick: () => openEditor(entryKey),
                children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
                  name: "external"
                }), "Open in the editor"]
              })]
            })]
          })]
        })
      })]
    })]
  });
}
_s(GroveAgent, "A9H/aJwB7+/1wRj1lKl+fWpL/So=", false, function () {
  return [_sdk.useChatProviderState, _sdk.useCatalog, _sdk.useAllMetadata, _useHeadings.useHeadings, _useHeadings.useActiveHeading, _shell.useShell, _useOverlayFocusDismiss.useOverlayFocusDismiss, _useCatalogAnswered.useCatalogAnswered, _sdk.useAgentContext];
});
_c = GroveAgent;
var _c;
$RefreshReg$(_c, "GroveAgent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NkayIsIl9zaGVsbCIsIl91c2VIZWFkaW5ncyIsIl91c2VPdmVybGF5Rm9jdXNEaXNtaXNzIiwiX2NvbnRlbnRSb290IiwiX2FnZW50VG9vbHMiLCJfYWdlbnRQcm9tcHQiLCJfcmVhY2hDYXJkIiwiX2FnZW50VHJhbnNjcmlwdCIsIl91c2VDYXRhbG9nQW5zd2VyZWQiLCJfc2FmZVNvdXJjZXMiLCJfSWNvbiIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiR3JvdmVBZ2VudCIsIndyaXRhYmxlIiwiZW50cnlLZXkiLCJlbnRyeVRpdGxlIiwicHJvdmlkZXJTdGF0ZSIsInVzZUNoYXRQcm92aWRlclN0YXRlIiwiY2F0YWxvZyIsInVzZUNhdGFsb2ciLCJpbmRleCIsInVzZUFsbE1ldGFkYXRhIiwiaGVhZGluZ3MiLCJ1c2VIZWFkaW5ncyIsImFjdGl2ZUhlYWRpbmciLCJ1c2VBY3RpdmVIZWFkaW5nIiwib3BlbkVkaXRvciIsImVkaXRSZWZ1c2VkIiwidXNlU2hlbGwiLCJvcGVuIiwic2V0T3BlbiIsInVzZVN0YXRlIiwiZGV0ZW50Iiwic2V0RGV0ZW50IiwicmVzdGluZyIsInNldFJlc3RpbmciLCJkcmFmdCIsInNldERyYWZ0Iiwicm93cyIsInNldFJvd3MiLCJzdHJlYW1pbmciLCJzZXRTdHJlYW1pbmciLCJlcnJvclRvYXN0Iiwic2V0RXJyb3JUb2FzdCIsImJvZHlSZWYiLCJ1c2VSZWYiLCJmb290UmVmIiwiYWJvcnRSZWYiLCJkaWFsb2dSZWYiLCJ1c2VPdmVybGF5Rm9jdXNEaXNtaXNzIiwiY2hhdEdyYW50ZWQiLCJzb21lIiwibSIsIm5hbWUiLCJjYXRhbG9nQW5zd2VyZWQiLCJ1c2VDYXRhbG9nQW5zd2VyZWQiLCJjb250ZXh0IiwidXNlQWdlbnRDb250ZXh0IiwiZW50cnlQYXRoIiwiaGVhZGluZyIsInVuZGVmaW5lZCIsInRvb2xzU3VwcG9ydGVkIiwic3RhdHVzIiwicHJvdmlkZXIiLCJmZWF0dXJlcyIsInRvb2xzIiwicmVhY2hSb3dzIiwidXNlTWVtbyIsImNvbXB1dGVSZWFjaFJvd3MiLCJzb3VyY2VTaGFyZWQiLCJtb3VudElkIiwiZ2V0Q29ycHVzTW91bnRJZCIsImNoaXBzIiwicmVhY2hDaGlwcyIsInRydXN0TGluZSIsInNvdXJjZVRydXN0TGluZSIsInNvdXJjZVNoYXJlZEJhc2lzIiwicmVhY2hBbm5vdW5jZW1lbnQiLCJtYXAiLCJyIiwibGFiZWwiLCJzdGF0ZVdvcmQiLCJzdGF0ZSIsImpvaW4iLCJjYW5Bc2siLCJpbmRleFJlZiIsImNvbnRleHRSZWYiLCJlbnRyeVJlZiIsImhlYWRpbmdSZWYiLCJ1c2VFZmZlY3QiLCJjdXJyZW50IiwidHJhbnNjcmlwdFJlZiIsInJlcXVlc3RBbmltYXRpb25GcmFtZSIsImZvY3VzIiwicmVzdGluZ0dvUmVmIiwid2FzT3BlblJlZiIsInNjcm9sbFRvIiwidG9wIiwic2Nyb2xsSGVpZ2h0IiwiYXNrIiwicXVlc3Rpb24iLCJxIiwidHJpbSIsInByZXYiLCJraW5kIiwidGV4dCIsImNocm9vdCIsImdldENvbnRlbnRSb290IiwiY3VycmVudEtleSIsImNvbnRleHRCbG9jayIsInJlbmRlckFnZW50Q29udGV4dCIsInN0dWZmZWRCb2R5Iiwic2FmZVNvdXJjZXMiLCJyZWFkIiwiY2F0Y2giLCJzeXN0ZW0iLCJidWlsZFN5c3RlbVByb21wdCIsImVudHJ5Qm9keSIsImVudHJ5VG9vbCIsImNyZWF0ZVJlYWRFbnRyeVRvb2wiLCJtZXRhVG9vbCIsImNyZWF0ZUdyb3ZlTWV0YWRhdGFUb29sIiwiZXhlY3V0ZSIsInRvb2xFeGVjdXRvciIsImdyb3ZlQWdlbnRUb29scyIsImFjYyIsInB1c2hBc3Npc3RhbnQiLCJuZXh0Iiwic2xpY2UiLCJsZW5ndGgiLCJwdXNoIiwiY29udHJvbGxlciIsIkFib3J0Q29udHJvbGxlciIsImZpbmFsIiwicnVuQWdlbnQiLCJjbGllbnQiLCJjcmVhdGVDaGF0TW9kZWxDbGllbnQiLCJwcm9tcHQiLCJoaXN0b3J5IiwibWF4VHVybnMiLCJzaWduYWwiLCJldmVudHMiLCJvbkFzc2lzdGFudERlbHRhIiwidCIsIm9uVG9vbFVzZSIsImlucHV0IiwicG9wIiwidG9vbEFjdGl2aXR5TGluZSIsInJlbmRlcmVkIiwidHJhbnNjcmlwdFRvUm93cyIsImFib3J0ZWQiLCJFcnJvciIsImNvZGUiLCJtZXNzYWdlIiwiVU5HUkFOVEVEX0NIQVRfQ0FVU0UiLCJSRUFESU5HX1dPUktTX05PUk1BTCIsImpzeHMiLCJjbGFzc05hbWUiLCJjaGlsZHJlbiIsIm9uU3VibWl0IiwicHJldmVudERlZmF1bHQiLCJqc3giLCJ2YWx1ZSIsInBsYWNlaG9sZGVyIiwib25DaGFuZ2UiLCJ0YXJnZXQiLCJvbkZvY3VzIiwicmVmIiwidHlwZSIsIkZyYWdtZW50Iiwib25DbGljayIsInRhYkluZGV4Iiwicm9sZSIsImQiLCJjYXVzZSIsImRlc3RpbmF0aW9uIiwiYWN0aW9uIiwia2V5Iiwic2hvd0VncmVzc0Rpc2Nsb3N1cmUiLCJFR1JFU1NfRElTQ0xPU1VSRSIsImMiLCJpIiwiZGlzYWJsZWQiLCJ0aXRsZSIsImFib3J0IiwiRURJVF9SRUZVU0VEX05PVElDRSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiR3JvdmVBZ2VudC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VNZW1vLCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHtcbiAgcnVuQWdlbnQsXG4gIGNyZWF0ZUNoYXRNb2RlbENsaWVudCxcbiAgdXNlQ2hhdFByb3ZpZGVyU3RhdGUsXG4gIHVzZUNhdGFsb2csXG4gIHVzZUFsbE1ldGFkYXRhLFxuICB1c2VBZ2VudENvbnRleHQsXG4gIHJlbmRlckFnZW50Q29udGV4dCxcbiAgdHlwZSBBZ2VudE1lc3NhZ2UsXG59IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrJztcbmltcG9ydCB7IHVzZVNoZWxsLCBFRElUX1JFRlVTRURfTk9USUNFIH0gZnJvbSAnLi4vbGliL3NoZWxsJztcbmltcG9ydCB7IHVzZUhlYWRpbmdzLCB1c2VBY3RpdmVIZWFkaW5nIH0gZnJvbSAnLi4vaG9va3MvdXNlSGVhZGluZ3MnO1xuaW1wb3J0IHsgdXNlT3ZlcmxheUZvY3VzRGlzbWlzcyB9IGZyb20gJy4uL2hvb2tzL3VzZU92ZXJsYXlGb2N1c0Rpc21pc3MnO1xuaW1wb3J0IHsgZ2V0Q29udGVudFJvb3QgfSBmcm9tICcuLi9saWIvY29udGVudFJvb3QnO1xuaW1wb3J0IHsgY3JlYXRlUmVhZEVudHJ5VG9vbCwgY3JlYXRlR3JvdmVNZXRhZGF0YVRvb2wsIGdyb3ZlQWdlbnRUb29scywgdG9vbEV4ZWN1dG9yIH0gZnJvbSAnLi4vbGliL2FnZW50VG9vbHMnO1xuaW1wb3J0IHsgYnVpbGRTeXN0ZW1Qcm9tcHQgfSBmcm9tICcuLi9saWIvYWdlbnRQcm9tcHQnO1xuaW1wb3J0IHsgY29tcHV0ZVJlYWNoUm93cywgcmVhY2hDaGlwcywgc291cmNlVHJ1c3RMaW5lLCBzdGF0ZVdvcmQsIHNob3dFZ3Jlc3NEaXNjbG9zdXJlLCBFR1JFU1NfRElTQ0xPU1VSRSwgVU5HUkFOVEVEX0NIQVRfQ0FVU0UsIFJFQURJTkdfV09SS1NfTk9STUFMIH0gZnJvbSAnLi4vbGliL3JlYWNoQ2FyZCc7XG5pbXBvcnQgeyBnZXRDb3JwdXNNb3VudElkIH0gZnJvbSAnLi4vbGliL2NvbnRlbnRSb290JztcbmltcG9ydCB7IHRyYW5zY3JpcHRUb1Jvd3MsIHRvb2xBY3Rpdml0eUxpbmUsIHR5cGUgQWdlbnRSb3cgfSBmcm9tICcuLi9saWIvYWdlbnRUcmFuc2NyaXB0JztcbmltcG9ydCB7IHVzZUNhdGFsb2dBbnN3ZXJlZCB9IGZyb20gJy4uL2hvb2tzL3VzZUNhdGFsb2dBbnN3ZXJlZCc7XG5pbXBvcnQgeyBzYWZlU291cmNlcyB9IGZyb20gJy4uL2xpYi9zYWZlU291cmNlcyc7XG5pbXBvcnQgSWNvbiBmcm9tICcuL0ljb24nO1xuXG4vLyBgLmdyb3ZlLWFnZW50YCDigJQgR3JvdmUncyBvd24gZW1iZWRkZWQgYWdlbnQgKEdST1ZFX0FHRU5UX1NQRUMpLlxuLy9cbi8vIFRoZSBzdXJmYWNlIGlzIGEgRlVOQ1RJT04gb2YgdGhlIHNlc3Npb24ncyBlbnZlbG9wZSAoUi1HQS0xKTogdGhlIHJlYWNoIGNhcmQgaW5cbi8vIHRoZSBleHBhbmRlZCBoZWFkZXIgaXMgY29tcHV0ZWQgZnJvbSB0aGUgcHJvdmlkZXIgZm91ci1zdGF0ZSAoUjMtNjg4IGFkZGVkIHRoZVxuLy8gaG9zdC1tYXJrZWQgYHVuZ3JhbnRlZGAg4oCUIHRoZSBkaXN0aW5jdCBub3QtZ3JhbnRlZCBjYXVzZSksIHRoZSBgbGxtOmNoYXRgXG4vLyBncmFudCAodGhlIGdyYW50LWZpbHRlcmVkIGNhdGFsb2cpLCBtb3VudCB3cml0YWJpbGl0eSwgdGhlIGNvcnB1cyBwYWNrYWdpbmcsXG4vLyB0b29scyBzdXBwb3J0LCBhbmQgc291cmNlIHRydXN0IOKAlCBuZXZlciBoYW5kLXdyaXR0ZW4gY29weS4gVGhlIGxvb3AgcmlkZXMgdGhlXG4vLyB3b3JrYmVuY2gncyBzZWFtIOKAlCBTREsgYHJ1bkFnZW50YCBvdmVyIHRoZSBob3N0IGBsbG0uY2hhdGAgc2xvdCDigJQgYW5kIGl0cyB0d29cbi8vIHRvb2xzIGFyZSB0aGUgbW91bnQtY2hyb290ZWQgYHJlYWRfZW50cnlgIGFuZFxuLy8gdGhlIGluZGV4IHF1ZXJ5IChSLUdBLTIpLiBUaGUgd2lkZ2V0IG5ldmVyIHdyaXRlcyAoUi1HQS0zKTogZXZlcnkgY2hhbmdlIGlzIGFcbi8vIGhhbmQtb2ZmIHRvIHRoZSBlZGl0b3IgLyB3b3JrYmVuY2guIFJlYWQtb25seSBuZXZlciBibG9ja3MgUSZBIChSLUdBLTUpLiBXaGVuIGFcbi8vIHByb3ZpZGVyIGlzIGJvdW5kIHRoZSBlZ3Jlc3MgbGluZSBpcyBzaG93biB1bmNvbmRpdGlvbmFsbHkgKFItR0EtNikuIEV2ZXJ5XG4vLyBjb3JwdXMtZGVyaXZlZCBieXRlIGVudGVyaW5nIHRoZSBsb29wIGlzIGZlbmNlZCAoUi1HQS03KS5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEdyb3ZlQWdlbnQoe1xuICB3cml0YWJsZSxcbiAgZW50cnlLZXksXG4gIGVudHJ5VGl0bGUsXG59OiB7XG4gIHdyaXRhYmxlOiBib29sZWFuO1xuICBlbnRyeUtleTogc3RyaW5nO1xuICBlbnRyeVRpdGxlOiBzdHJpbmc7XG59KSB7XG4gIGNvbnN0IHByb3ZpZGVyU3RhdGUgPSB1c2VDaGF0UHJvdmlkZXJTdGF0ZSgpO1xuICBjb25zdCBjYXRhbG9nID0gdXNlQ2F0YWxvZygpO1xuICBjb25zdCBpbmRleCA9IHVzZUFsbE1ldGFkYXRhKCk7XG4gIGNvbnN0IGhlYWRpbmdzID0gdXNlSGVhZGluZ3MoZW50cnlLZXkpO1xuICBjb25zdCBhY3RpdmVIZWFkaW5nID0gdXNlQWN0aXZlSGVhZGluZyhoZWFkaW5ncywgZW50cnlLZXkpO1xuICBjb25zdCB7IG9wZW5FZGl0b3IsIGVkaXRSZWZ1c2VkIH0gPSB1c2VTaGVsbCgpO1xuICBjb25zdCBbb3Blbiwgc2V0T3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtkZXRlbnQsIHNldERldGVudF0gPSB1c2VTdGF0ZTwnaGFsZicgfCAnZnVsbCc+KCdoYWxmJyk7XG4gIGNvbnN0IFtyZXN0aW5nLCBzZXRSZXN0aW5nXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2RyYWZ0LCBzZXREcmFmdF0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtyb3dzLCBzZXRSb3dzXSA9IHVzZVN0YXRlPEFnZW50Um93W10+KFtdKTtcbiAgY29uc3QgW3N0cmVhbWluZywgc2V0U3RyZWFtaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2Vycm9yVG9hc3QsIHNldEVycm9yVG9hc3RdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IGJvZHlSZWYgPSB1c2VSZWY8SFRNTERpdkVsZW1lbnQ+KG51bGwpO1xuICBjb25zdCBmb290UmVmID0gdXNlUmVmPEhUTUxJbnB1dEVsZW1lbnQ+KG51bGwpO1xuICAvLyBPbmUgQWJvcnRDb250cm9sbGVyIHBlciBydW4gKFIzLTYwOCk6IHRoZSBjb21wb3NlcidzIHN0b3AgY29udHJvbCBhYm9ydHMgdGhlXG4gIC8vIGluLWZsaWdodCBydW4gdGhyb3VnaCB0aGUgU0RLIHNpZ25hbCB0aGUgbG9vcCBhbHJlYWR5IGhvbm91cnMuXG4gIGNvbnN0IGFib3J0UmVmID0gdXNlUmVmPEFib3J0Q29udHJvbGxlciB8IG51bGw+KG51bGwpO1xuICAvLyBUaGUgcGFuZWwgY2FycmllcyB0aGUgZGlhbG9nIGNvbnRyYWN0IChSMy02MDgpOiBmb2N1cyBpbiwgVGFiIHRyYXBwZWQsXG4gIC8vIEVzY2FwZSwgZm9jdXMgcmV0dXJuIOKAlCB0aGUgc2hhcmVkIGhvb2ssIHN0YWNrLWF3YXJlLlxuICBjb25zdCBkaWFsb2dSZWYgPSB1c2VPdmVybGF5Rm9jdXNEaXNtaXNzKG9wZW4sICgpID0+IHNldE9wZW4oZmFsc2UpKTtcblxuICAvLyBUaGUgZW52ZWxvcGUsIGNvbXB1dGVkIChSLUdBLTEpLiBgbGxtOmNoYXRgIGFwcGVhcnMgaW4gdGhlIGdyYW50LWZpbHRlcmVkXG4gIC8vIGNhdGFsb2cgaWZmIHRoaXMgYXBwIGhvbGRzIHRoZSBjb25zZW50IOKAlCBhbiB1bmdyYW50ZWQgZm9yayByZWFkcyBhIERJU1RJTkNUXG4gIC8vIGNhdXNlIGZyb20gYSB1c2VyIHdpdGhvdXQgYSBrZXkgKEctR0EtMTApLlxuICBjb25zdCBjaGF0R3JhbnRlZCA9IGNhdGFsb2cuc29tZSgobSkgPT4gbS5uYW1lID09PSAnbGxtOmNoYXQnKTtcbiAgLy8gRGlzdGluZ3Vpc2hlcyBcImdyYW50ZWQgbm90aGluZ1wiIGZyb20gXCJoYXMgbm90IHJlcGxpZWQgeWV0XCIg4oCUIGBjYXRhbG9nYCBhbG9uZSBjYW5ub3QsXG4gIC8vIGJlY2F1c2UgYW4gZW1wdHkgY2F0YWxvZyBpcyBhIGxlZ2l0aW1hdGUgYW5zd2VyLiBTZWUgdGhlIGhvb2sgZm9yIGhvdyBpdCBpcyBkZXJpdmVkLlxuICBjb25zdCBjYXRhbG9nQW5zd2VyZWQgPSB1c2VDYXRhbG9nQW5zd2VyZWQoKTtcbiAgY29uc3QgY29udGV4dCA9IHVzZUFnZW50Q29udGV4dCh7IGVudHJ5UGF0aDogZW50cnlLZXksIGVudHJ5VGl0bGUsIGhlYWRpbmc6IGFjdGl2ZUhlYWRpbmcgfHwgdW5kZWZpbmVkIH0pO1xuICAvLyBHLUdBLTg6IGEgcHJvdmlkZXIgd2l0aG91dCBgZmVhdHVyZXMudG9vbHNgIGRlZ3JhZGVzIHRvIGNvbnRleHQtc3R1ZmZpbmcuXG4gIC8vIENvbXB1dGVkIE9OQ0UgYXQgcmVuZGVyIHNjb3BlIOKAlCB0aGUgcmVhY2ggY2FyZCdzIFEmQSBxdWFsaWZpZXIgKFIzLTc1MikgYW5kIHRoZVxuICAvLyBhc2soKSBwYXRoIGJlbG93IHJlYWQgdGhlIHNhbWUgZmFjdCwgbmV2ZXIgdHdvIGNvbXB1dGF0aW9ucyBvZiBpdC5cbiAgY29uc3QgdG9vbHNTdXBwb3J0ZWQgPSBwcm92aWRlclN0YXRlLnN0YXR1cyA9PT0gJ2NvbmZpZ3VyZWQnICYmIHByb3ZpZGVyU3RhdGUucHJvdmlkZXIuZmVhdHVyZXMudG9vbHMgPT09IHRydWU7XG4gIGNvbnN0IHJlYWNoUm93cyA9IHVzZU1lbW8oXG4gICAgKCkgPT5cbiAgICAgIGNvbXB1dGVSZWFjaFJvd3Moe1xuICAgICAgICBwcm92aWRlclN0YXRlLFxuICAgICAgICBjaGF0R3JhbnRlZCxcbiAgICAgICAgY2F0YWxvZ0Fuc3dlcmVkLFxuICAgICAgICB3cml0YWJsZSxcbiAgICAgICAgc291cmNlU2hhcmVkOiBjb250ZXh0LnNvdXJjZVNoYXJlZCxcbiAgICAgICAgbW91bnRJZDogZ2V0Q29ycHVzTW91bnRJZCgpLFxuICAgICAgICB0b29sc1N1cHBvcnRlZCxcbiAgICAgIH0pLFxuICAgIFtwcm92aWRlclN0YXRlLCBjaGF0R3JhbnRlZCwgY2F0YWxvZ0Fuc3dlcmVkLCB3cml0YWJsZSwgY29udGV4dC5zb3VyY2VTaGFyZWQsIHRvb2xzU3VwcG9ydGVkXSxcbiAgKTtcbiAgY29uc3QgY2hpcHMgPSB1c2VNZW1vKCgpID0+IHJlYWNoQ2hpcHMocmVhY2hSb3dzKSwgW3JlYWNoUm93c10pO1xuICBjb25zdCB0cnVzdExpbmUgPSB1c2VNZW1vKFxuICAgICgpID0+IHNvdXJjZVRydXN0TGluZShjb250ZXh0LnNvdXJjZVNoYXJlZCwgY29udGV4dC5zb3VyY2VTaGFyZWRCYXNpcyksXG4gICAgW2NvbnRleHQuc291cmNlU2hhcmVkLCBjb250ZXh0LnNvdXJjZVNoYXJlZEJhc2lzXSxcbiAgKTtcbiAgLy8gUi1JWC03IChSMy03NTIpOiBhIHN0YXRlIGZsaXAgaXMgQU5OT1VOQ0VELCBub3Qgb25seSByZS1yZW5kZXJlZCDigJQgb25lIHN0YW5kaW5nXG4gIC8vIHBvbGl0ZSBsaXZlIHJlZ2lvbiB3aG9zZSB0ZXh0IGlzIHRoZSBjYXJkJ3MgY29tcHV0ZWQgc3VtbWFyeS4gQSBncmFudCBmbGlwXG4gIC8vIGNoYW5nZXMgdGhlIHRleHQsIHdoaWNoIGlzIHdoYXQgYSBzdGF0dXMgcmVnaW9uIGFubm91bmNlczsgdGhlIHZpc3VhbGx5IGhpZGRlblxuICAvLyBwZXItcm93IHdvcmRzIGFyZSBzdGF0aWMgdGV4dCBhbmQgYW5ub3VuY2Ugbm90aGluZy5cbiAgY29uc3QgcmVhY2hBbm5vdW5jZW1lbnQgPSB1c2VNZW1vKFxuICAgICgpID0+IGBXaGF0IHRoZSBhZ2VudCBjYW4gZG8gaGVyZTogJHtyZWFjaFJvd3MubWFwKChyKSA9PiBgJHtyLmxhYmVsfSDigJQgJHtzdGF0ZVdvcmQoci5zdGF0ZSl9YCkuam9pbignOyAnKX1gLFxuICAgIFtyZWFjaFJvd3NdLFxuICApO1xuICBjb25zdCBjYW5Bc2sgPSBwcm92aWRlclN0YXRlLnN0YXR1cyA9PT0gJ2NvbmZpZ3VyZWQnICYmIGNoYXRHcmFudGVkO1xuXG4gIC8vIFJlYWQgYXQgQ0FMTCB0aW1lIChhIHNjYW4gbWF5IGxhbmQsIHRoZSByZWFkZXIgbWF5IG5hdmlnYXRlKSDigJQgcmVmcyBrZXB0IGZyZXNoXG4gIC8vIGluIGFuIGVmZmVjdCwgbmV2ZXIgd3JpdHRlbiBkdXJpbmcgcmVuZGVyICh0aGUgcmVhY3QtaG9va3MgY29tcGlsZXIgcmVqZWN0cyB0aGF0KS5cbiAgY29uc3QgaW5kZXhSZWYgPSB1c2VSZWYoaW5kZXgpO1xuICBjb25zdCBjb250ZXh0UmVmID0gdXNlUmVmKGNvbnRleHQpO1xuICBjb25zdCBlbnRyeVJlZiA9IHVzZVJlZihlbnRyeUtleSk7XG4gIGNvbnN0IGhlYWRpbmdSZWYgPSB1c2VSZWYoYWN0aXZlSGVhZGluZyk7XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaW5kZXhSZWYuY3VycmVudCA9IGluZGV4O1xuICAgIGNvbnRleHRSZWYuY3VycmVudCA9IGNvbnRleHQ7XG4gICAgZW50cnlSZWYuY3VycmVudCA9IGVudHJ5S2V5O1xuICAgIGhlYWRpbmdSZWYuY3VycmVudCA9IGFjdGl2ZUhlYWRpbmc7XG4gIH0sIFtpbmRleCwgY29udGV4dCwgZW50cnlLZXksIGFjdGl2ZUhlYWRpbmddKTtcblxuICAvLyBUaGUgbG9vcCdzIHRyYW5zY3JpcHQsIGtlcHQgc28gZm9sbG93LXVwIHF1ZXN0aW9ucyByZXBsYXkgdGhlIHRvb2wtdXNlIGNoYWluLlxuICBjb25zdCB0cmFuc2NyaXB0UmVmID0gdXNlUmVmPEFnZW50TWVzc2FnZVtdPihbXSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAob3BlbikgcmVxdWVzdEFuaW1hdGlvbkZyYW1lKCgpID0+IGZvb3RSZWYuY3VycmVudD8uZm9jdXMoKSk7XG4gIH0sIFtvcGVuXSk7XG4gIC8vIFRoZSBwYW5lbCdzIG9ubHkgdHJpZ2dlciAodGhlIHJlc3RpbmcgaW5wdXQpIFVOTU9VTlRTIHdoZW4gaXQgb3BlbnMsIGFuZFxuICAvLyBpdHMgb25Gb2N1cyBJUyB0aGUgb3BlbiBhY3Rpb24g4oCUIHJldHVybmluZyBmb2N1cyB0byBpdCB3b3VsZCByZW9wZW4gdGhlXG4gIC8vIHBhbmVsLiBTbyB0aGUgY2xvc2UgcGF0aCByZXR1cm5zIGZvY3VzIHRvIHRoZSByZXN0aW5nIGxpbmUncyBTVUJNSVRcbiAgLy8gY29udHJvbCAoUi1JWC0xKTogYSByZWFsIHN0b3AgaW4gdGhlIHNhbWUgc3VyZmFjZSB0aGF0IG5ldmVyIHJlb3BlbnNcbiAgLy8gYW55dGhpbmcsIHNvIEVzY2FwZSBuZXZlciBzdHJhbmRzIHRoZSBrZXlib2FyZCBvbiA8Ym9keT4uIE9uIG1vdW50IHRoZVxuICAvLyBlZmZlY3Qgc3RheXMgcXVpZXQgKHdhcy1vcGVuIGdhdGUpIG9yIHRoZSBwYW5lbCB3b3VsZCBvcGVuIGl0c2VsZi5cbiAgY29uc3QgcmVzdGluZ0dvUmVmID0gdXNlUmVmPEhUTUxCdXR0b25FbGVtZW50PihudWxsKTtcbiAgY29uc3Qgd2FzT3BlblJlZiA9IHVzZVJlZihmYWxzZSk7XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKHdhc09wZW5SZWYuY3VycmVudCAmJiAhb3BlbikgcmVxdWVzdEFuaW1hdGlvbkZyYW1lKCgpID0+IHJlc3RpbmdHb1JlZi5jdXJyZW50Py5mb2N1cygpKTtcbiAgICB3YXNPcGVuUmVmLmN1cnJlbnQgPSBvcGVuO1xuICB9LCBbb3Blbl0pO1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGJvZHlSZWYuY3VycmVudD8uc2Nyb2xsVG8oeyB0b3A6IGJvZHlSZWYuY3VycmVudC5zY3JvbGxIZWlnaHQgfSk7XG4gIH0sIFtyb3dzLCBzdHJlYW1pbmddKTtcblxuICBhc3luYyBmdW5jdGlvbiBhc2socXVlc3Rpb246IHN0cmluZykge1xuICAgIGNvbnN0IHEgPSBxdWVzdGlvbi50cmltKCk7XG4gICAgaWYgKCFxIHx8IHN0cmVhbWluZykgcmV0dXJuO1xuICAgIHNldE9wZW4odHJ1ZSk7XG4gICAgc2V0RHJhZnQoJycpO1xuICAgIHNldFJlc3RpbmcoJycpO1xuICAgIHNldEVycm9yVG9hc3QobnVsbCk7XG4gICAgc2V0Um93cygocHJldikgPT4gWy4uLnByZXYsIHsga2luZDogJ3VzZXInLCB0ZXh0OiBxIH1dKTtcbiAgICBzZXRTdHJlYW1pbmcodHJ1ZSk7XG5cbiAgICAvLyBHLUdBLTg6IGEgcHJvdmlkZXIgd2l0aG91dCBgZmVhdHVyZXMudG9vbHNgIGRlZ3JhZGVzIHRvIGNvbnRleHQtc3R1ZmZpbmcg4oCUXG4gICAgLy8gdGhlIGRlaXhpcyBibG9jaywgYW4gaW5kZXggc3VtbWFyeSwgYW5kIHRoZSBjdXJyZW50IGVudHJ5IGJvZHkgcmlkZSB0aGVcbiAgICAvLyBwcm9tcHQ7IHRoZSByZXF1ZXN0IGNhcnJpZXMgWkVSTyB0b29scy4gVGhlIHNhbWUgaG9pc3RlZCBmYWN0IHRoZSByZWFjaFxuICAgIC8vIGNhcmQncyBRJkEgcXVhbGlmaWVyIHJlYWRzIChSMy03NTIpIOKAlCBjb21wdXRlZCBvbmNlIGF0IHJlbmRlciBzY29wZS5cbiAgICBjb25zdCBjaHJvb3QgPSBnZXRDb250ZW50Um9vdCgpO1xuICAgIGNvbnN0IGN1cnJlbnRLZXkgPSBlbnRyeVJlZi5jdXJyZW50O1xuICAgIGNvbnN0IGNvbnRleHRCbG9jayA9IHJlbmRlckFnZW50Q29udGV4dCh7XG4gICAgICAuLi5jb250ZXh0UmVmLmN1cnJlbnQsXG4gICAgICBlbnRyeVBhdGg6IGN1cnJlbnRLZXksXG4gICAgICBoZWFkaW5nOiBoZWFkaW5nUmVmLmN1cnJlbnQgfHwgdW5kZWZpbmVkLFxuICAgIH0pO1xuICAgIGxldCBzdHVmZmVkQm9keTogc3RyaW5nIHwgdW5kZWZpbmVkO1xuICAgIGlmICghdG9vbHNTdXBwb3J0ZWQpIHtcbiAgICAgIHN0dWZmZWRCb2R5ID0gYXdhaXQgc2FmZVNvdXJjZXMucmVhZChjdXJyZW50S2V5KS5jYXRjaCgoKSA9PiB1bmRlZmluZWQpO1xuICAgIH1cbiAgICBjb25zdCBzeXN0ZW0gPSBidWlsZFN5c3RlbVByb21wdCh7XG4gICAgICBjb250ZXh0QmxvY2ssXG4gICAgICB0b29sc1N1cHBvcnRlZCxcbiAgICAgIC4uLih0b29sc1N1cHBvcnRlZCA/IHt9IDogeyBlbnRyeUJvZHk6IHN0dWZmZWRCb2R5LCBlbnRyeVBhdGg6IGN1cnJlbnRLZXksIGluZGV4OiBpbmRleFJlZi5jdXJyZW50LCBjaHJvb3QgfSksXG4gICAgfSk7XG4gICAgY29uc3QgZW50cnlUb29sID0gY3JlYXRlUmVhZEVudHJ5VG9vbChjaHJvb3QpO1xuICAgIGNvbnN0IG1ldGFUb29sID0gY3JlYXRlR3JvdmVNZXRhZGF0YVRvb2woY2hyb290LCAoKSA9PiBpbmRleFJlZi5jdXJyZW50KTtcbiAgICBjb25zdCBleGVjdXRlID0gdG9vbEV4ZWN1dG9yKFtlbnRyeVRvb2wsIG1ldGFUb29sXSk7XG4gICAgY29uc3QgdG9vbHMgPSB0b29sc1N1cHBvcnRlZCA/IGdyb3ZlQWdlbnRUb29scyhjaHJvb3QsICgpID0+IGluZGV4UmVmLmN1cnJlbnQpIDogW107XG5cbiAgICBsZXQgYWNjID0gJyc7XG4gICAgY29uc3QgcHVzaEFzc2lzdGFudCA9ICh0ZXh0OiBzdHJpbmcpID0+XG4gICAgICBzZXRSb3dzKChwcmV2KSA9PiB7XG4gICAgICAgIGNvbnN0IG5leHQgPSBwcmV2LnNsaWNlKCk7XG4gICAgICAgIGlmIChuZXh0Lmxlbmd0aCAmJiBuZXh0W25leHQubGVuZ3RoIC0gMV0ua2luZCA9PT0gJ2Fzc2lzdGFudCcpIG5leHRbbmV4dC5sZW5ndGggLSAxXSA9IHsga2luZDogJ2Fzc2lzdGFudCcsIHRleHQgfTtcbiAgICAgICAgZWxzZSBuZXh0LnB1c2goeyBraW5kOiAnYXNzaXN0YW50JywgdGV4dCB9KTtcbiAgICAgICAgcmV0dXJuIG5leHQ7XG4gICAgICB9KTtcbiAgICBjb25zdCBjb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xuICAgIGFib3J0UmVmLmN1cnJlbnQgPSBjb250cm9sbGVyO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBmaW5hbCA9IGF3YWl0IHJ1bkFnZW50KHtcbiAgICAgICAgY2xpZW50OiBjcmVhdGVDaGF0TW9kZWxDbGllbnQoKSxcbiAgICAgICAgdG9vbHMsXG4gICAgICAgIGV4ZWN1dGUsXG4gICAgICAgIHN5c3RlbSxcbiAgICAgICAgcHJvbXB0OiBxLFxuICAgICAgICBoaXN0b3J5OiB0cmFuc2NyaXB0UmVmLmN1cnJlbnQsXG4gICAgICAgIG1heFR1cm5zOiA4LFxuICAgICAgICBzaWduYWw6IGNvbnRyb2xsZXIuc2lnbmFsLFxuICAgICAgICBldmVudHM6IHtcbiAgICAgICAgICBvbkFzc2lzdGFudERlbHRhOiAodCkgPT4ge1xuICAgICAgICAgICAgYWNjICs9IHQ7XG4gICAgICAgICAgICBwdXNoQXNzaXN0YW50KGFjYyk7XG4gICAgICAgICAgfSxcbiAgICAgICAgICBvblRvb2xVc2U6IChuYW1lLCBpbnB1dCkgPT4ge1xuICAgICAgICAgICAgYWNjID0gJyc7XG4gICAgICAgICAgICBzZXRSb3dzKChwcmV2KSA9PiB7XG4gICAgICAgICAgICAgIGNvbnN0IG5leHQgPSBwcmV2LnNsaWNlKCk7XG4gICAgICAgICAgICAgIGlmIChuZXh0Lmxlbmd0aCAmJiBuZXh0W25leHQubGVuZ3RoIC0gMV0ua2luZCA9PT0gJ2Fzc2lzdGFudCcgJiYgIW5leHRbbmV4dC5sZW5ndGggLSAxXS50ZXh0KSBuZXh0LnBvcCgpO1xuICAgICAgICAgICAgICBuZXh0LnB1c2goeyBraW5kOiAnYWN0aXZpdHknLCB0ZXh0OiB0b29sQWN0aXZpdHlMaW5lKG5hbWUsIGlucHV0KSB9KTtcbiAgICAgICAgICAgICAgcmV0dXJuIG5leHQ7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgICBjb25zdCByZW5kZXJlZCA9IHRyYW5zY3JpcHRUb1Jvd3MoZmluYWwpO1xuICAgICAgLy8gVGhlIHJlYWwgbG9vcCBSRVNPTFZFUyBhbiBhYm9ydGVkIHJ1biB3aXRoIHRoZSBwYXJ0aWFsIHRyYW5zY3JpcHQgKGFcbiAgICAgIC8vIGNsZWFuIHN0b3AsIG5ldmVyIGEgdGhyb3duIGVycm9yKSDigJQgc28gdGhlIGFib3J0IGNoZWNrIGxpdmVzIGhlcmUgdG9vLFxuICAgICAgLy8gbm90IG9ubHkgaW4gdGhlIGNhdGNoOiBhIHN0b3BwZWQgcnVuIGtlZXBzIHdoYXQgc3RyZWFtZWQgYW5kIGFwcGVuZHMgYVxuICAgICAgLy8gbmFtZWQgU3RvcHBlZCByb3cgKFIzLTYwOCkuXG4gICAgICBpZiAoY29udHJvbGxlci5zaWduYWwuYWJvcnRlZCkge1xuICAgICAgICBzZXRSb3dzKChwcmV2KSA9PiBbLi4ucHJldiwgeyBraW5kOiAnYWN0aXZpdHknLCB0ZXh0OiAnU3RvcHBlZCcgfV0pO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAoIXJlbmRlcmVkLnNvbWUoKHIpID0+IHIua2luZCA9PT0gJ2Fzc2lzdGFudCcpKSB0aHJvdyBuZXcgRXJyb3IoJ2VtcHR5Jyk7XG4gICAgICB0cmFuc2NyaXB0UmVmLmN1cnJlbnQgPSBmaW5hbC5zbGljZSgpO1xuICAgICAgc2V0Um93cyhyZW5kZXJlZCk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgLy8gQSBzdG9wIGlzIG5vdCBhbiBlcnJvciAoUjMtNjA4KTogdGhlIGFib3J0ZWQgcnVuIHNldHRsZXMgd2l0aCBhIG5hbWVkXG4gICAgICAvLyBcIlN0b3BwZWRcIiByb3csIGFuZCB0aGUgdHJhbnNjcmlwdCBrZWVwcyB3aGF0IHN0cmVhbWVkIHNvIGZhci5cbiAgICAgIGlmIChjb250cm9sbGVyLnNpZ25hbC5hYm9ydGVkKSB7XG4gICAgICAgIHNldFJvd3MoKHByZXYpID0+IFsuLi5wcmV2LCB7IGtpbmQ6ICdhY3Rpdml0eScsIHRleHQ6ICdTdG9wcGVkJyB9XSk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGNvZGUgPSAoZSBhcyB7IGNvZGU/OiBzdHJpbmcgfSk/LmNvZGUgfHwgKGUgYXMgRXJyb3IpLm1lc3NhZ2U7XG4gICAgICBzZXRFcnJvclRvYXN0KFxuICAgICAgICBjb2RlID09PSAnYXV0aC1yZXF1aXJlZCdcbiAgICAgICAgICA/ICdubyBtb2RlbCBrZXkgY29ubmVjdGVkIOKAlCBhZGQgb25lIGluIFNldHRpbmdzJ1xuICAgICAgICAgIDogY29kZSA9PT0gJ2ZvcmJpZGRlbidcbiAgICAgICAgICAgID8gVU5HUkFOVEVEX0NIQVRfQ0FVU0VcbiAgICAgICAgICAgIDogY29kZSA9PT0gJ2NhbmNlbGxlZCdcbiAgICAgICAgICAgICAgPyBgY2hhdCBkaWRuJ3Qgc3RhcnQg4oCUICR7UkVBRElOR19XT1JLU19OT1JNQUx9OyB5b3UgY2FuIHRyeSBhZ2FpbiBhbnl0aW1lYFxuICAgICAgICAgICAgICA6ICd0aGUgbW9kZWwgb3IgYmFja2VuZCBlcnJvcmVkIOKAlCB0cnkgYWdhaW4gaW4gYSBtb21lbnQnLFxuICAgICAgKTtcbiAgICAgIHNldFJvd3MoKHByZXYpID0+XG4gICAgICAgIHByZXYubGVuZ3RoICYmIHByZXZbcHJldi5sZW5ndGggLSAxXS5raW5kID09PSAnYXNzaXN0YW50JyAmJiAhcHJldltwcmV2Lmxlbmd0aCAtIDFdLnRleHQgPyBwcmV2LnNsaWNlKDAsIC0xKSA6IHByZXYsXG4gICAgICApO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRTdHJlYW1pbmcoZmFsc2UpO1xuICAgICAgaWYgKGFib3J0UmVmLmN1cnJlbnQgPT09IGNvbnRyb2xsZXIpIGFib3J0UmVmLmN1cnJlbnQgPSBudWxsO1xuICAgIH1cbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJncm92ZS1hZ2VudFwiPlxuICAgICAgey8qIFJlc3Rpbmc6IHRoZSBhbHdheXMtcHJlc2VudCB0aGluIGlucHV0IGxpbmUuIFEmQSBpcyBuZXZlciBkaXNhYmxlZCBieVxuICAgICAgICAgIHJlYWQtb25seSAoUi1HQS01KSDigJQgb25seSBieSB0aGUgZW52ZWxvcGUgZ2VudWluZWx5IGxhY2tpbmcgYSBwcm92aWRlci4gKi99XG4gICAgICB7IW9wZW4gJiYgKFxuICAgICAgICA8Zm9ybVxuICAgICAgICAgIGNsYXNzTmFtZT1cImdhLWxpbmVcIlxuICAgICAgICAgIG9uU3VibWl0PXsoZSkgPT4ge1xuICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgICAgaWYgKGNhbkFzaykgdm9pZCBhc2socmVzdGluZyk7XG4gICAgICAgICAgICBlbHNlIHNldE9wZW4odHJ1ZSk7XG4gICAgICAgICAgfX1cbiAgICAgICAgPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1rXCIgLz5cbiAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIHZhbHVlPXtyZXN0aW5nfVxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9e2BBc2sgR3JvdmUgYWJvdXQg4oCcJHtlbnRyeVRpdGxlfeKAneKApmB9XG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFJlc3RpbmcoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgb25Gb2N1cz17KCkgPT4gc2V0T3Blbih0cnVlKX1cbiAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJBc2sgR3JvdmVcIlxuICAgICAgICAgIC8+XG4gICAgICAgICAgPGJ1dHRvbiByZWY9e3Jlc3RpbmdHb1JlZn0gY2xhc3NOYW1lPVwiZ29cIiB0eXBlPVwic3VibWl0XCIgYXJpYS1sYWJlbD1cIkFzayBHcm92ZVwiPlxuICAgICAgICAgICAgPEljb24gbmFtZT1cInNlbmRcIiAvPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Zvcm0+XG4gICAgICApfVxuXG4gICAgICB7LyogRXhwYW5kZWQ6IGRvY2sgKGRlc2t0b3ApIC8gc2hlZXQgKG1vYmlsZSkuICovfVxuICAgICAge29wZW4gJiYgKFxuICAgICAgICA8PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ2Etc2NyaW1cIiBvbkNsaWNrPXsoKSA9PiBzZXRPcGVuKGZhbHNlKX0gLz5cbiAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJnYS1wYW5lbFwiXG4gICAgICAgICAgICBkYXRhLWRldGVudD17ZGV0ZW50fVxuICAgICAgICAgICAgcmVmPXtkaWFsb2dSZWZ9XG4gICAgICAgICAgICB0YWJJbmRleD17LTF9XG4gICAgICAgICAgICByb2xlPVwiZGlhbG9nXCJcbiAgICAgICAgICAgIGFyaWEtbW9kYWw9XCJ0cnVlXCJcbiAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJBc2sgR3JvdmVcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ2EtcGFuZWwtaW5uZXJcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJnYS1oZWFkXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZ3JpcFwiIG9uQ2xpY2s9eygpID0+IHNldERldGVudCgoZCkgPT4gKGQgPT09ICdoYWxmJyA/ICdmdWxsJyA6ICdoYWxmJykpfSAvPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1rXCIgLz5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpZFwiPkdyb3ZlPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImdyb3dcIj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiaWNcIiBhcmlhLWxhYmVsPXtkZXRlbnQgPT09ICdoYWxmJyA/ICdFeHBhbmQnIDogJ0NvbGxhcHNlJ30gb25DbGljaz17KCkgPT4gc2V0RGV0ZW50KChkKSA9PiAoZCA9PT0gJ2hhbGYnID8gJ2Z1bGwnIDogJ2hhbGYnKSl9PlxuICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPXtkZXRlbnQgPT09ICdoYWxmJyA/ICdjaGV2cm9uLWRvd24nIDogJ2NoZXZyb24tcmlnaHQnfSAvPlxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImljXCIgYXJpYS1sYWJlbD1cIkNsb3NlXCIgb25DbGljaz17KCkgPT4gc2V0T3BlbihmYWxzZSl9PlxuICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwieFwiIC8+XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBUaGUgcmVhY2ggY2FyZCDigJQgdGhlIGVudmVsb3BlLCBjb21wdXRlZCAoUi1HQS0xKS4gU3RhdGUgaXMgdGV4dCBhc1xuICAgICAgICAgICAgICAgICAgd2VsbCBhcyBnbHlwaCAoUjMtNzUyKTogdGhlIGhpZGRlbiB3b3JkIGJlc2lkZSB0aGUgbWFyayBrZWVwcyB0aGVcbiAgICAgICAgICAgICAgICAgIGNhcmQgZnJvbSByZWFkaW5nIGFzIGZvdXIgaWRlbnRpY2FsIGxpbmVzIHRvIGEgc2NyZWVuIHJlYWRlci4gKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ2EtcmVhY2hcIiByb2xlPVwibGlzdFwiIGFyaWEtbGFiZWw9XCJXaGF0IHRoZSBhZ2VudCBjYW4gZG8gaGVyZVwiPlxuICAgICAgICAgICAgICAgIHtyZWFjaFJvd3MubWFwKChyKSA9PiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YGdhLXJlYWNoX19yb3cgZ2EtcmVhY2hfX3Jvdy0tJHtyLnN0YXRlfWB9IHJvbGU9XCJsaXN0aXRlbVwiIGtleT17ci5rZXl9PlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJnYS1yZWFjaF9fbWFya1wiIGFyaWEtaGlkZGVuPlxuICAgICAgICAgICAgICAgICAgICAgIHtyLnN0YXRlID09PSAnb2snID8gJ+KckycgOiByLnN0YXRlID09PSAnYmxvY2tlZCcgPyAn4pyXJyA6IHIuc3RhdGUgPT09ICdlbHNld2hlcmUnID8gJ+KGkicgOiAnwrcnfVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImdhLXJlYWNoX19zdGF0ZXdvcmRcIj57c3RhdGVXb3JkKHIuc3RhdGUpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZ2EtcmVhY2hfX2xhYmVsXCI+e3IubGFiZWx9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICB7ci5jYXVzZSAmJiA8c3BhbiBjbGFzc05hbWU9XCJnYS1yZWFjaF9fY2F1c2VcIj57ci5jYXVzZX08L3NwYW4+fVxuICAgICAgICAgICAgICAgICAgICB7ci5kZXN0aW5hdGlvbiAmJiA8c3BhbiBjbGFzc05hbWU9XCJnYS1yZWFjaF9fY2F1c2VcIj57YOKGkiAke3IuZGVzdGluYXRpb259YH08L3NwYW4+fVxuICAgICAgICAgICAgICAgICAgICB7ci5hY3Rpb24gPT09ICdlbmFibGUtY2hhdCcgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgIC8vIFIzLTc5MDogdGhlIGVhcm5pbmcgYWZmb3JkYW5jZS4gSXRzIGNsaWNrIGludm9rZXMgYXNrKCkg4oCUIHRoZVxuICAgICAgICAgICAgICAgICAgICAgIC8vIHVuZ3JhbnRlZCBsbG06Y2hhdCBpbnZva2UgZmlyZXMgdGhlIEhPU1QncyBjb25zZW50IGRpYWxvZyBvbiB0aGlzXG4gICAgICAgICAgICAgICAgICAgICAgLy8gc2FtZSBhY3RpdmF0aW9uIChzaXRlLW1haW4jNjEyKSwgQWxsb3cgbWludHMgKyBsaWZ0cywgYW5kIHRoZVxuICAgICAgICAgICAgICAgICAgICAgIC8vIHNhbWUgYXNrIHByb2NlZWRzIHRvIHN0cmVhbS4gQSBkZWNsaW5lIGFuc3dlcnMgJ2NhbmNlbGxlZCcgKHRoZVxuICAgICAgICAgICAgICAgICAgICAgIC8vIGNhdGNoIGJlbG93KSBhbmQgdGhlIHJvdyBzdGF5cyBob25lc3RseSDinJcuXG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJnYS1yZWFjaF9fZW5hYmxlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZvaWQgYXNrKGRyYWZ0LnRyaW0oKSB8fCAnQW5zd2VyIGluIG9uZSBzZW50ZW5jZTogd2hhdCBjYW4geW91IHRlbGwgbWUgYWJvdXQgdGhpcyB3aWtpPycpXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgRW5hYmxlIGNoYXRcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAge3RydXN0TGluZSAmJiA8cCBjbGFzc05hbWU9XCJnYS1lZ3Jlc3NcIj57dHJ1c3RMaW5lfTwvcD59XG4gICAgICAgICAgICAgIHsvKiBUaGUgc3RhbmRpbmcgbGl2ZSByZWdpb24gKFItSVgtNyk6IHRoZSBjb21wdXRlZCBjYXJkIHN1bW1hcnksIHNvIGFcbiAgICAgICAgICAgICAgICAgIHN0YXRlIGZsaXAgaXMgYW5ub3VuY2VkIHBvbGl0ZWx5IGFuZCBub3Qgb25seSByZS1yZW5kZXJlZC4gKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ2EtcmVhY2hfX3N0YXRld29yZFwiIHJvbGU9XCJzdGF0dXNcIj5cbiAgICAgICAgICAgICAgICB7cmVhY2hBbm5vdW5jZW1lbnR9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICB7c2hvd0VncmVzc0Rpc2Nsb3N1cmUocHJvdmlkZXJTdGF0ZSkgJiYgPHAgY2xhc3NOYW1lPVwiZ2EtZWdyZXNzXCI+e0VHUkVTU19ESVNDTE9TVVJFfTwvcD59XG4gICAgICAgICAgICAgIHtlcnJvclRvYXN0ICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdhLXRvYXN0XCIgcm9sZT1cInN0YXR1c1wiPlxuICAgICAgICAgICAgICAgICAge2Vycm9yVG9hc3R9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJnYS1ib2R5XCIgcmVmPXtib2R5UmVmfT5cbiAgICAgICAgICAgICAgICB7cm93cy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdhLWV4cGxhaW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICA8Yj5Hcm92ZSdzIGFnZW50PC9iPiBhbnN3ZXJzIHF1ZXN0aW9ucyBhYm91dCB0aGlzIHdpa2kg4oCUIGl0cyBlbnRyaWVzLCB0YWdzLCBhbmQgc3RydWN0dXJlIOKAlCBmcm9tIHRoZVxuICAgICAgICAgICAgICAgICAgICAgIHBhZ2UgeW91J3JlIG9uLlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAge2NoaXBzLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ2EtY2hpcHNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtjaGlwcy5tYXAoKGMpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBrZXk9e2N9IGNsYXNzTmFtZT1cImdhLWNoaXBcIiBvbkNsaWNrPXsoKSA9PiB2b2lkIGFzayhjKX0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2N9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgcm93cy5tYXAoKHIsIGkpID0+XG4gICAgICAgICAgICAgICAgICAgIHIua2luZCA9PT0gJ2FjdGl2aXR5JyA/IChcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17aX0gY2xhc3NOYW1lPVwiZ2EtYWN0aXZpdHlcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJmaWxlXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtyLnRleHR9XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2l9IGNsYXNzTmFtZT17YGdhLW1zZyAke3Iua2luZH1gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YGdhLW1zZ19fYXYgJHtyLmtpbmQgPT09ICdhc3Npc3RhbnQnID8gJ2dyb3ZlJyA6ICd1c2VyJ31gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge3Iua2luZCA9PT0gJ2Fzc2lzdGFudCcgPyAnJyA6ICd5b3UnfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJnYS1tc2dfX2JcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJnYS1tc2dfX3dob1wiPntyLmtpbmQgPT09ICdhc3Npc3RhbnQnID8gJ0dyb3ZlJyA6ICdZb3UnfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdhLW1zZ19fdHh0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3IudGV4dH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c3RyZWFtaW5nICYmIGkgPT09IHJvd3MubGVuZ3RoIC0gMSAmJiByLmtpbmQgPT09ICdhc3Npc3RhbnQnID8gPHNwYW4gY2xhc3NOYW1lPVwiZ2EtY3Vyc29yXCIgLz4gOiBudWxsfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApLFxuICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ2EtZm9vdFwiPlxuICAgICAgICAgICAgICAgIDxmb3JtXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJnYS1mb290X19yb3dcIlxuICAgICAgICAgICAgICAgICAgb25TdWJtaXQ9eyhlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICAgICAgICAgICAgdm9pZCBhc2soZHJhZnQpO1xuICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgcmVmPXtmb290UmVmfVxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZHJhZnR9XG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQXNrIEdyb3Zl4oCmXCJcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3N0cmVhbWluZyB8fCAhY2FuQXNrfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldERyYWZ0KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICB7c3RyZWFtaW5nID8gKFxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3RvcFwiXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIlN0b3BcIlxuICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiU3RvcFwiXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gYWJvcnRSZWYuY3VycmVudD8uYWJvcnQoKX1cbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJ4XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICApIDogbnVsbH1cbiAgICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiZ29cIiB0eXBlPVwic3VibWl0XCIgZGlzYWJsZWQ9e3N0cmVhbWluZyB8fCAhY2FuQXNrIHx8ICFkcmFmdC50cmltKCl9IGFyaWEtbGFiZWw9e3N0cmVhbWluZyA/ICdBbnN3ZXJpbmfigKYnIDogJ1NlbmQnfSB0aXRsZT17c3RyZWFtaW5nID8gJ0Fuc3dlcmluZ+KApicgOiAnU2VuZCd9PlxuICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwic2VuZFwiIC8+XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJnYS1mb290X19oYW5kXCI+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj57RUdSRVNTX0RJU0NMT1NVUkV9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAge2VkaXRSZWZ1c2VkICYmIChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZ2EtZWRpdC1yZWZ1c2VkXCIgcm9sZT1cInN0YXR1c1wiPlxuICAgICAgICAgICAgICAgICAgICAgIHtFRElUX1JFRlVTRURfTk9USUNFfVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gb3BlbkVkaXRvcihlbnRyeUtleSl9PlxuICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiZXh0ZXJuYWxcIiAvPlxuICAgICAgICAgICAgICAgICAgICBPcGVuIGluIHRoZSBlZGl0b3JcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8Lz5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFBLElBQUFBLE1BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLElBQUEsR0FBQUQsT0FBQTtBQVVBLElBQUFFLE1BQUEsR0FBQUYsT0FBQTtBQUNBLElBQUFHLFlBQUEsR0FBQUgsT0FBQTtBQUNBLElBQUFJLHVCQUFBLEdBQUFKLE9BQUE7QUFDQSxJQUFBSyxZQUFBLEdBQUFMLE9BQUE7QUFDQSxJQUFBTSxXQUFBLEdBQUFOLE9BQUE7QUFDQSxJQUFBTyxZQUFBLEdBQUFQLE9BQUE7QUFDQSxJQUFBUSxVQUFBLEdBQUFSLE9BQUE7QUFFQSxJQUFBUyxnQkFBQSxHQUFBVCxPQUFBO0FBQ0EsSUFBQVUsbUJBQUEsR0FBQVYsT0FBQTtBQUNBLElBQUFXLFlBQUEsR0FBQVgsT0FBQTtBQUNBLElBQUFZLEtBQUEsR0FBQUMsc0JBQUEsQ0FBQWIsT0FBQTtBQUEwQixJQUFBYyxXQUFBLEdBQUFkLE9BQUE7QUFBQSxJQUFBZSxFQUFBLEdBQUFDLFlBQUEsSUFFMUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFBQSxTQUFBSCx1QkFBQUksQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQUNlLFNBQVNHLFVBQVVBLENBQUM7RUFDakNDLFFBQVE7RUFDUkMsUUFBUTtFQUNSQztBQUtGLENBQUMsRUFBRTtFQUFBUixFQUFBO0VBQ0QsTUFBTVMsYUFBYSxHQUFHLElBQUFDLHlCQUFvQixFQUFDLENBQUM7RUFDNUMsTUFBTUMsT0FBTyxHQUFHLElBQUFDLGVBQVUsRUFBQyxDQUFDO0VBQzVCLE1BQU1DLEtBQUssR0FBRyxJQUFBQyxtQkFBYyxFQUFDLENBQUM7RUFDOUIsTUFBTUMsUUFBUSxHQUFHLElBQUFDLHdCQUFXLEVBQUNULFFBQVEsQ0FBQztFQUN0QyxNQUFNVSxhQUFhLEdBQUcsSUFBQUMsNkJBQWdCLEVBQUNILFFBQVEsRUFBRVIsUUFBUSxDQUFDO0VBQzFELE1BQU07SUFBRVksVUFBVTtJQUFFQztFQUFZLENBQUMsR0FBRyxJQUFBQyxlQUFRLEVBQUMsQ0FBQztFQUM5QyxNQUFNLENBQUNDLElBQUksRUFBRUMsT0FBTyxDQUFDLEdBQUcsSUFBQUMsZUFBUSxFQUFDLEtBQUssQ0FBQztFQUN2QyxNQUFNLENBQUNDLE1BQU0sRUFBRUMsU0FBUyxDQUFDLEdBQUcsSUFBQUYsZUFBUSxFQUFrQixNQUFNLENBQUM7RUFDN0QsTUFBTSxDQUFDRyxPQUFPLEVBQUVDLFVBQVUsQ0FBQyxHQUFHLElBQUFKLGVBQVEsRUFBQyxFQUFFLENBQUM7RUFDMUMsTUFBTSxDQUFDSyxLQUFLLEVBQUVDLFFBQVEsQ0FBQyxHQUFHLElBQUFOLGVBQVEsRUFBQyxFQUFFLENBQUM7RUFDdEMsTUFBTSxDQUFDTyxJQUFJLEVBQUVDLE9BQU8sQ0FBQyxHQUFHLElBQUFSLGVBQVEsRUFBYSxFQUFFLENBQUM7RUFDaEQsTUFBTSxDQUFDUyxTQUFTLEVBQUVDLFlBQVksQ0FBQyxHQUFHLElBQUFWLGVBQVEsRUFBQyxLQUFLLENBQUM7RUFDakQsTUFBTSxDQUFDVyxVQUFVLEVBQUVDLGFBQWEsQ0FBQyxHQUFHLElBQUFaLGVBQVEsRUFBZ0IsSUFBSSxDQUFDO0VBQ2pFLE1BQU1hLE9BQU8sR0FBRyxJQUFBQyxhQUFNLEVBQWlCLElBQUksQ0FBQztFQUM1QyxNQUFNQyxPQUFPLEdBQUcsSUFBQUQsYUFBTSxFQUFtQixJQUFJLENBQUM7RUFDOUM7RUFDQTtFQUNBLE1BQU1FLFFBQVEsR0FBRyxJQUFBRixhQUFNLEVBQXlCLElBQUksQ0FBQztFQUNyRDtFQUNBO0VBQ0EsTUFBTUcsU0FBUyxHQUFHLElBQUFDLDhDQUFzQixFQUFDcEIsSUFBSSxFQUFFLE1BQU1DLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQzs7RUFFcEU7RUFDQTtFQUNBO0VBQ0EsTUFBTW9CLFdBQVcsR0FBR2hDLE9BQU8sQ0FBQ2lDLElBQUksQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUNDLElBQUksS0FBSyxVQUFVLENBQUM7RUFDOUQ7RUFDQTtFQUNBLE1BQU1DLGVBQWUsR0FBRyxJQUFBQyxzQ0FBa0IsRUFBQyxDQUFDO0VBQzVDLE1BQU1DLE9BQU8sR0FBRyxJQUFBQyxvQkFBZSxFQUFDO0lBQUVDLFNBQVMsRUFBRTVDLFFBQVE7SUFBRUMsVUFBVTtJQUFFNEMsT0FBTyxFQUFFbkMsYUFBYSxJQUFJb0M7RUFBVSxDQUFDLENBQUM7RUFDekc7RUFDQTtFQUNBO0VBQ0EsTUFBTUMsY0FBYyxHQUFHN0MsYUFBYSxDQUFDOEMsTUFBTSxLQUFLLFlBQVksSUFBSTlDLGFBQWEsQ0FBQytDLFFBQVEsQ0FBQ0MsUUFBUSxDQUFDQyxLQUFLLEtBQUssSUFBSTtFQUM5RyxNQUFNQyxTQUFTLEdBQUcsSUFBQUMsY0FBTyxFQUN2QixNQUNFLElBQUFDLDJCQUFnQixFQUFDO0lBQ2ZwRCxhQUFhO0lBQ2JrQyxXQUFXO0lBQ1hJLGVBQWU7SUFDZnpDLFFBQVE7SUFDUndELFlBQVksRUFBRWIsT0FBTyxDQUFDYSxZQUFZO0lBQ2xDQyxPQUFPLEVBQUUsSUFBQUMsNkJBQWdCLEVBQUMsQ0FBQztJQUMzQlY7RUFDRixDQUFDLENBQUMsRUFDSixDQUFDN0MsYUFBYSxFQUFFa0MsV0FBVyxFQUFFSSxlQUFlLEVBQUV6QyxRQUFRLEVBQUUyQyxPQUFPLENBQUNhLFlBQVksRUFBRVIsY0FBYyxDQUM5RixDQUFDO0VBQ0QsTUFBTVcsS0FBSyxHQUFHLElBQUFMLGNBQU8sRUFBQyxNQUFNLElBQUFNLHFCQUFVLEVBQUNQLFNBQVMsQ0FBQyxFQUFFLENBQUNBLFNBQVMsQ0FBQyxDQUFDO0VBQy9ELE1BQU1RLFNBQVMsR0FBRyxJQUFBUCxjQUFPLEVBQ3ZCLE1BQU0sSUFBQVEsMEJBQWUsRUFBQ25CLE9BQU8sQ0FBQ2EsWUFBWSxFQUFFYixPQUFPLENBQUNvQixpQkFBaUIsQ0FBQyxFQUN0RSxDQUFDcEIsT0FBTyxDQUFDYSxZQUFZLEVBQUViLE9BQU8sQ0FBQ29CLGlCQUFpQixDQUNsRCxDQUFDO0VBQ0Q7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNQyxpQkFBaUIsR0FBRyxJQUFBVixjQUFPLEVBQy9CLE1BQU0sK0JBQStCRCxTQUFTLENBQUNZLEdBQUcsQ0FBRUMsQ0FBQyxJQUFLLEdBQUdBLENBQUMsQ0FBQ0MsS0FBSyxNQUFNLElBQUFDLG9CQUFTLEVBQUNGLENBQUMsQ0FBQ0csS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFDNUcsQ0FBQ2pCLFNBQVMsQ0FDWixDQUFDO0VBQ0QsTUFBTWtCLE1BQU0sR0FBR3BFLGFBQWEsQ0FBQzhDLE1BQU0sS0FBSyxZQUFZLElBQUlaLFdBQVc7O0VBRW5FO0VBQ0E7RUFDQSxNQUFNbUMsUUFBUSxHQUFHLElBQUF4QyxhQUFNLEVBQUN6QixLQUFLLENBQUM7RUFDOUIsTUFBTWtFLFVBQVUsR0FBRyxJQUFBekMsYUFBTSxFQUFDVyxPQUFPLENBQUM7RUFDbEMsTUFBTStCLFFBQVEsR0FBRyxJQUFBMUMsYUFBTSxFQUFDL0IsUUFBUSxDQUFDO0VBQ2pDLE1BQU0wRSxVQUFVLEdBQUcsSUFBQTNDLGFBQU0sRUFBQ3JCLGFBQWEsQ0FBQztFQUN4QyxJQUFBaUUsZ0JBQVMsRUFBQyxNQUFNO0lBQ2RKLFFBQVEsQ0FBQ0ssT0FBTyxHQUFHdEUsS0FBSztJQUN4QmtFLFVBQVUsQ0FBQ0ksT0FBTyxHQUFHbEMsT0FBTztJQUM1QitCLFFBQVEsQ0FBQ0csT0FBTyxHQUFHNUUsUUFBUTtJQUMzQjBFLFVBQVUsQ0FBQ0UsT0FBTyxHQUFHbEUsYUFBYTtFQUNwQyxDQUFDLEVBQUUsQ0FBQ0osS0FBSyxFQUFFb0MsT0FBTyxFQUFFMUMsUUFBUSxFQUFFVSxhQUFhLENBQUMsQ0FBQzs7RUFFN0M7RUFDQSxNQUFNbUUsYUFBYSxHQUFHLElBQUE5QyxhQUFNLEVBQWlCLEVBQUUsQ0FBQztFQUVoRCxJQUFBNEMsZ0JBQVMsRUFBQyxNQUFNO0lBQ2QsSUFBSTVELElBQUksRUFBRStELHFCQUFxQixDQUFDLE1BQU05QyxPQUFPLENBQUM0QyxPQUFPLEVBQUVHLEtBQUssQ0FBQyxDQUFDLENBQUM7RUFDakUsQ0FBQyxFQUFFLENBQUNoRSxJQUFJLENBQUMsQ0FBQztFQUNWO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU1pRSxZQUFZLEdBQUcsSUFBQWpELGFBQU0sRUFBb0IsSUFBSSxDQUFDO0VBQ3BELE1BQU1rRCxVQUFVLEdBQUcsSUFBQWxELGFBQU0sRUFBQyxLQUFLLENBQUM7RUFDaEMsSUFBQTRDLGdCQUFTLEVBQUMsTUFBTTtJQUNkLElBQUlNLFVBQVUsQ0FBQ0wsT0FBTyxJQUFJLENBQUM3RCxJQUFJLEVBQUUrRCxxQkFBcUIsQ0FBQyxNQUFNRSxZQUFZLENBQUNKLE9BQU8sRUFBRUcsS0FBSyxDQUFDLENBQUMsQ0FBQztJQUMzRkUsVUFBVSxDQUFDTCxPQUFPLEdBQUc3RCxJQUFJO0VBQzNCLENBQUMsRUFBRSxDQUFDQSxJQUFJLENBQUMsQ0FBQztFQUNWLElBQUE0RCxnQkFBUyxFQUFDLE1BQU07SUFDZDdDLE9BQU8sQ0FBQzhDLE9BQU8sRUFBRU0sUUFBUSxDQUFDO01BQUVDLEdBQUcsRUFBRXJELE9BQU8sQ0FBQzhDLE9BQU8sQ0FBQ1E7SUFBYSxDQUFDLENBQUM7RUFDbEUsQ0FBQyxFQUFFLENBQUM1RCxJQUFJLEVBQUVFLFNBQVMsQ0FBQyxDQUFDO0VBRXJCLGVBQWUyRCxHQUFHQSxDQUFDQyxRQUFnQixFQUFFO0lBQ25DLE1BQU1DLENBQUMsR0FBR0QsUUFBUSxDQUFDRSxJQUFJLENBQUMsQ0FBQztJQUN6QixJQUFJLENBQUNELENBQUMsSUFBSTdELFNBQVMsRUFBRTtJQUNyQlYsT0FBTyxDQUFDLElBQUksQ0FBQztJQUNiTyxRQUFRLENBQUMsRUFBRSxDQUFDO0lBQ1pGLFVBQVUsQ0FBQyxFQUFFLENBQUM7SUFDZFEsYUFBYSxDQUFDLElBQUksQ0FBQztJQUNuQkosT0FBTyxDQUFFZ0UsSUFBSSxJQUFLLENBQUMsR0FBR0EsSUFBSSxFQUFFO01BQUVDLElBQUksRUFBRSxNQUFNO01BQUVDLElBQUksRUFBRUo7SUFBRSxDQUFDLENBQUMsQ0FBQztJQUN2RDVELFlBQVksQ0FBQyxJQUFJLENBQUM7O0lBRWxCO0lBQ0E7SUFDQTtJQUNBO0lBQ0EsTUFBTWlFLE1BQU0sR0FBRyxJQUFBQywyQkFBYyxFQUFDLENBQUM7SUFDL0IsTUFBTUMsVUFBVSxHQUFHckIsUUFBUSxDQUFDRyxPQUFPO0lBQ25DLE1BQU1tQixZQUFZLEdBQUcsSUFBQUMsdUJBQWtCLEVBQUM7TUFDdEMsR0FBR3hCLFVBQVUsQ0FBQ0ksT0FBTztNQUNyQmhDLFNBQVMsRUFBRWtELFVBQVU7TUFDckJqRCxPQUFPLEVBQUU2QixVQUFVLENBQUNFLE9BQU8sSUFBSTlCO0lBQ2pDLENBQUMsQ0FBQztJQUNGLElBQUltRCxXQUErQjtJQUNuQyxJQUFJLENBQUNsRCxjQUFjLEVBQUU7TUFDbkJrRCxXQUFXLEdBQUcsTUFBTUMsd0JBQVcsQ0FBQ0MsSUFBSSxDQUFDTCxVQUFVLENBQUMsQ0FBQ00sS0FBSyxDQUFDLE1BQU10RCxTQUFTLENBQUM7SUFDekU7SUFDQSxNQUFNdUQsTUFBTSxHQUFHLElBQUFDLDhCQUFpQixFQUFDO01BQy9CUCxZQUFZO01BQ1poRCxjQUFjO01BQ2QsSUFBSUEsY0FBYyxHQUFHLENBQUMsQ0FBQyxHQUFHO1FBQUV3RCxTQUFTLEVBQUVOLFdBQVc7UUFBRXJELFNBQVMsRUFBRWtELFVBQVU7UUFBRXhGLEtBQUssRUFBRWlFLFFBQVEsQ0FBQ0ssT0FBTztRQUFFZ0I7TUFBTyxDQUFDO0lBQzlHLENBQUMsQ0FBQztJQUNGLE1BQU1ZLFNBQVMsR0FBRyxJQUFBQywrQkFBbUIsRUFBQ2IsTUFBTSxDQUFDO0lBQzdDLE1BQU1jLFFBQVEsR0FBRyxJQUFBQyxtQ0FBdUIsRUFBQ2YsTUFBTSxFQUFFLE1BQU1yQixRQUFRLENBQUNLLE9BQU8sQ0FBQztJQUN4RSxNQUFNZ0MsT0FBTyxHQUFHLElBQUFDLHdCQUFZLEVBQUMsQ0FBQ0wsU0FBUyxFQUFFRSxRQUFRLENBQUMsQ0FBQztJQUNuRCxNQUFNdkQsS0FBSyxHQUFHSixjQUFjLEdBQUcsSUFBQStELDJCQUFlLEVBQUNsQixNQUFNLEVBQUUsTUFBTXJCLFFBQVEsQ0FBQ0ssT0FBTyxDQUFDLEdBQUcsRUFBRTtJQUVuRixJQUFJbUMsR0FBRyxHQUFHLEVBQUU7SUFDWixNQUFNQyxhQUFhLEdBQUlyQixJQUFZLElBQ2pDbEUsT0FBTyxDQUFFZ0UsSUFBSSxJQUFLO01BQ2hCLE1BQU13QixJQUFJLEdBQUd4QixJQUFJLENBQUN5QixLQUFLLENBQUMsQ0FBQztNQUN6QixJQUFJRCxJQUFJLENBQUNFLE1BQU0sSUFBSUYsSUFBSSxDQUFDQSxJQUFJLENBQUNFLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQ3pCLElBQUksS0FBSyxXQUFXLEVBQUV1QixJQUFJLENBQUNBLElBQUksQ0FBQ0UsTUFBTSxHQUFHLENBQUMsQ0FBQyxHQUFHO1FBQUV6QixJQUFJLEVBQUUsV0FBVztRQUFFQztNQUFLLENBQUMsQ0FBQyxLQUM5R3NCLElBQUksQ0FBQ0csSUFBSSxDQUFDO1FBQUUxQixJQUFJLEVBQUUsV0FBVztRQUFFQztNQUFLLENBQUMsQ0FBQztNQUMzQyxPQUFPc0IsSUFBSTtJQUNiLENBQUMsQ0FBQztJQUNKLE1BQU1JLFVBQVUsR0FBRyxJQUFJQyxlQUFlLENBQUMsQ0FBQztJQUN4Q3JGLFFBQVEsQ0FBQzJDLE9BQU8sR0FBR3lDLFVBQVU7SUFDN0IsSUFBSTtNQUNGLE1BQU1FLEtBQUssR0FBRyxNQUFNLElBQUFDLGFBQVEsRUFBQztRQUMzQkMsTUFBTSxFQUFFLElBQUFDLDBCQUFxQixFQUFDLENBQUM7UUFDL0J2RSxLQUFLO1FBQ0x5RCxPQUFPO1FBQ1BQLE1BQU07UUFDTnNCLE1BQU0sRUFBRXBDLENBQUM7UUFDVHFDLE9BQU8sRUFBRS9DLGFBQWEsQ0FBQ0QsT0FBTztRQUM5QmlELFFBQVEsRUFBRSxDQUFDO1FBQ1hDLE1BQU0sRUFBRVQsVUFBVSxDQUFDUyxNQUFNO1FBQ3pCQyxNQUFNLEVBQUU7VUFDTkMsZ0JBQWdCLEVBQUdDLENBQUMsSUFBSztZQUN2QmxCLEdBQUcsSUFBSWtCLENBQUM7WUFDUmpCLGFBQWEsQ0FBQ0QsR0FBRyxDQUFDO1VBQ3BCLENBQUM7VUFDRG1CLFNBQVMsRUFBRUEsQ0FBQzNGLElBQUksRUFBRTRGLEtBQUssS0FBSztZQUMxQnBCLEdBQUcsR0FBRyxFQUFFO1lBQ1J0RixPQUFPLENBQUVnRSxJQUFJLElBQUs7Y0FDaEIsTUFBTXdCLElBQUksR0FBR3hCLElBQUksQ0FBQ3lCLEtBQUssQ0FBQyxDQUFDO2NBQ3pCLElBQUlELElBQUksQ0FBQ0UsTUFBTSxJQUFJRixJQUFJLENBQUNBLElBQUksQ0FBQ0UsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDekIsSUFBSSxLQUFLLFdBQVcsSUFBSSxDQUFDdUIsSUFBSSxDQUFDQSxJQUFJLENBQUNFLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQ3hCLElBQUksRUFBRXNCLElBQUksQ0FBQ21CLEdBQUcsQ0FBQyxDQUFDO2NBQ3hHbkIsSUFBSSxDQUFDRyxJQUFJLENBQUM7Z0JBQUUxQixJQUFJLEVBQUUsVUFBVTtnQkFBRUMsSUFBSSxFQUFFLElBQUEwQyxpQ0FBZ0IsRUFBQzlGLElBQUksRUFBRTRGLEtBQUs7Y0FBRSxDQUFDLENBQUM7Y0FDcEUsT0FBT2xCLElBQUk7WUFDYixDQUFDLENBQUM7VUFDSjtRQUNGO01BQ0YsQ0FBQyxDQUFDO01BQ0YsTUFBTXFCLFFBQVEsR0FBRyxJQUFBQyxpQ0FBZ0IsRUFBQ2hCLEtBQUssQ0FBQztNQUN4QztNQUNBO01BQ0E7TUFDQTtNQUNBLElBQUlGLFVBQVUsQ0FBQ1MsTUFBTSxDQUFDVSxPQUFPLEVBQUU7UUFDN0IvRyxPQUFPLENBQUVnRSxJQUFJLElBQUssQ0FBQyxHQUFHQSxJQUFJLEVBQUU7VUFBRUMsSUFBSSxFQUFFLFVBQVU7VUFBRUMsSUFBSSxFQUFFO1FBQVUsQ0FBQyxDQUFDLENBQUM7UUFDbkU7TUFDRjtNQUNBLElBQUksQ0FBQzJDLFFBQVEsQ0FBQ2pHLElBQUksQ0FBRTRCLENBQUMsSUFBS0EsQ0FBQyxDQUFDeUIsSUFBSSxLQUFLLFdBQVcsQ0FBQyxFQUFFLE1BQU0sSUFBSStDLEtBQUssQ0FBQyxPQUFPLENBQUM7TUFDM0U1RCxhQUFhLENBQUNELE9BQU8sR0FBRzJDLEtBQUssQ0FBQ0wsS0FBSyxDQUFDLENBQUM7TUFDckN6RixPQUFPLENBQUM2RyxRQUFRLENBQUM7SUFDbkIsQ0FBQyxDQUFDLE9BQU8zSSxDQUFDLEVBQUU7TUFDVjtNQUNBO01BQ0EsSUFBSTBILFVBQVUsQ0FBQ1MsTUFBTSxDQUFDVSxPQUFPLEVBQUU7UUFDN0IvRyxPQUFPLENBQUVnRSxJQUFJLElBQUssQ0FBQyxHQUFHQSxJQUFJLEVBQUU7VUFBRUMsSUFBSSxFQUFFLFVBQVU7VUFBRUMsSUFBSSxFQUFFO1FBQVUsQ0FBQyxDQUFDLENBQUM7UUFDbkU7TUFDRjtNQUNBLE1BQU0rQyxJQUFJLEdBQUkvSSxDQUFDLEVBQXdCK0ksSUFBSSxJQUFLL0ksQ0FBQyxDQUFXZ0osT0FBTztNQUNuRTlHLGFBQWEsQ0FDWDZHLElBQUksS0FBSyxlQUFlLEdBQ3BCLDhDQUE4QyxHQUM5Q0EsSUFBSSxLQUFLLFdBQVcsR0FDbEJFLCtCQUFvQixHQUNwQkYsSUFBSSxLQUFLLFdBQVcsR0FDbEIsdUJBQXVCRywrQkFBb0IsNkJBQTZCLEdBQ3hFLHNEQUNWLENBQUM7TUFDRHBILE9BQU8sQ0FBRWdFLElBQUksSUFDWEEsSUFBSSxDQUFDMEIsTUFBTSxJQUFJMUIsSUFBSSxDQUFDQSxJQUFJLENBQUMwQixNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUN6QixJQUFJLEtBQUssV0FBVyxJQUFJLENBQUNELElBQUksQ0FBQ0EsSUFBSSxDQUFDMEIsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDeEIsSUFBSSxHQUFHRixJQUFJLENBQUN5QixLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUd6QixJQUNqSCxDQUFDO0lBQ0gsQ0FBQyxTQUFTO01BQ1I5RCxZQUFZLENBQUMsS0FBSyxDQUFDO01BQ25CLElBQUlNLFFBQVEsQ0FBQzJDLE9BQU8sS0FBS3lDLFVBQVUsRUFBRXBGLFFBQVEsQ0FBQzJDLE9BQU8sR0FBRyxJQUFJO0lBQzlEO0VBQ0Y7RUFFQSxvQkFDRSxJQUFBcEYsV0FBQSxDQUFBc0osSUFBQTtJQUFLQyxTQUFTLEVBQUMsYUFBYTtJQUFBQyxRQUFBLEdBR3pCLENBQUNqSSxJQUFJLGlCQUNKLElBQUF2QixXQUFBLENBQUFzSixJQUFBO01BQ0VDLFNBQVMsRUFBQyxTQUFTO01BQ25CRSxRQUFRLEVBQUd0SixDQUFDLElBQUs7UUFDZkEsQ0FBQyxDQUFDdUosY0FBYyxDQUFDLENBQUM7UUFDbEIsSUFBSTVFLE1BQU0sRUFBRSxLQUFLZSxHQUFHLENBQUNqRSxPQUFPLENBQUMsQ0FBQyxLQUN6QkosT0FBTyxDQUFDLElBQUksQ0FBQztNQUNwQixDQUFFO01BQUFnSSxRQUFBLGdCQUVGLElBQUF4SixXQUFBLENBQUEySixHQUFBO1FBQU1KLFNBQVMsRUFBQztNQUFJLENBQUUsQ0FBQyxlQUN2QixJQUFBdkosV0FBQSxDQUFBMkosR0FBQTtRQUNFQyxLQUFLLEVBQUVoSSxPQUFRO1FBQ2ZpSSxXQUFXLEVBQUUsb0JBQW9CcEosVUFBVSxJQUFLO1FBQ2hEcUosUUFBUSxFQUFHM0osQ0FBQyxJQUFLMEIsVUFBVSxDQUFDMUIsQ0FBQyxDQUFDNEosTUFBTSxDQUFDSCxLQUFLLENBQUU7UUFDNUNJLE9BQU8sRUFBRUEsQ0FBQSxLQUFNeEksT0FBTyxDQUFDLElBQUksQ0FBRTtRQUM3QixjQUFXO01BQVcsQ0FDdkIsQ0FBQyxlQUNGLElBQUF4QixXQUFBLENBQUEySixHQUFBO1FBQVFNLEdBQUcsRUFBRXpFLFlBQWE7UUFBQytELFNBQVMsRUFBQyxJQUFJO1FBQUNXLElBQUksRUFBQyxRQUFRO1FBQUMsY0FBVyxXQUFXO1FBQUFWLFFBQUEsZUFDNUUsSUFBQXhKLFdBQUEsQ0FBQTJKLEdBQUEsRUFBQzdKLEtBQUEsQ0FBQU8sT0FBSTtVQUFDMEMsSUFBSSxFQUFDO1FBQU0sQ0FBRTtNQUFDLENBQ2QsQ0FBQztJQUFBLENBQ0wsQ0FDUCxFQUdBeEIsSUFBSSxpQkFDSCxJQUFBdkIsV0FBQSxDQUFBc0osSUFBQSxFQUFBdEosV0FBQSxDQUFBbUssUUFBQTtNQUFBWCxRQUFBLGdCQUNFLElBQUF4SixXQUFBLENBQUEySixHQUFBO1FBQUtKLFNBQVMsRUFBQyxVQUFVO1FBQUNhLE9BQU8sRUFBRUEsQ0FBQSxLQUFNNUksT0FBTyxDQUFDLEtBQUs7TUFBRSxDQUFFLENBQUMsZUFDM0QsSUFBQXhCLFdBQUEsQ0FBQTJKLEdBQUE7UUFDRUosU0FBUyxFQUFDLFVBQVU7UUFDcEIsZUFBYTdILE1BQU87UUFDcEJ1SSxHQUFHLEVBQUV2SCxTQUFVO1FBQ2YySCxRQUFRLEVBQUUsQ0FBQyxDQUFFO1FBQ2JDLElBQUksRUFBQyxRQUFRO1FBQ2IsY0FBVyxNQUFNO1FBQ2pCLGNBQVcsV0FBVztRQUFBZCxRQUFBLGVBRXRCLElBQUF4SixXQUFBLENBQUFzSixJQUFBO1VBQUtDLFNBQVMsRUFBQyxnQkFBZ0I7VUFBQUMsUUFBQSxnQkFDN0IsSUFBQXhKLFdBQUEsQ0FBQXNKLElBQUE7WUFBS0MsU0FBUyxFQUFDLFNBQVM7WUFBQUMsUUFBQSxnQkFDdEIsSUFBQXhKLFdBQUEsQ0FBQTJKLEdBQUE7Y0FBTUosU0FBUyxFQUFDLE1BQU07Y0FBQ2EsT0FBTyxFQUFFQSxDQUFBLEtBQU16SSxTQUFTLENBQUU0SSxDQUFDLElBQU1BLENBQUMsS0FBSyxNQUFNLEdBQUcsTUFBTSxHQUFHLE1BQU87WUFBRSxDQUFFLENBQUMsZUFDNUYsSUFBQXZLLFdBQUEsQ0FBQTJKLEdBQUE7Y0FBTUosU0FBUyxFQUFDO1lBQUksQ0FBRSxDQUFDLGVBQ3ZCLElBQUF2SixXQUFBLENBQUEySixHQUFBO2NBQU1KLFNBQVMsRUFBQyxJQUFJO2NBQUFDLFFBQUEsRUFBQztZQUFLLENBQU0sQ0FBQyxlQUNqQyxJQUFBeEosV0FBQSxDQUFBc0osSUFBQTtjQUFNQyxTQUFTLEVBQUMsTUFBTTtjQUFBQyxRQUFBLGdCQUNwQixJQUFBeEosV0FBQSxDQUFBMkosR0FBQTtnQkFBUUosU0FBUyxFQUFDLElBQUk7Z0JBQUMsY0FBWTdILE1BQU0sS0FBSyxNQUFNLEdBQUcsUUFBUSxHQUFHLFVBQVc7Z0JBQUMwSSxPQUFPLEVBQUVBLENBQUEsS0FBTXpJLFNBQVMsQ0FBRTRJLENBQUMsSUFBTUEsQ0FBQyxLQUFLLE1BQU0sR0FBRyxNQUFNLEdBQUcsTUFBTyxDQUFFO2dCQUFBZixRQUFBLGVBQzlJLElBQUF4SixXQUFBLENBQUEySixHQUFBLEVBQUM3SixLQUFBLENBQUFPLE9BQUk7a0JBQUMwQyxJQUFJLEVBQUVyQixNQUFNLEtBQUssTUFBTSxHQUFHLGNBQWMsR0FBRztnQkFBZ0IsQ0FBRTtjQUFDLENBQzlELENBQUMsZUFDVCxJQUFBMUIsV0FBQSxDQUFBMkosR0FBQTtnQkFBUUosU0FBUyxFQUFDLElBQUk7Z0JBQUMsY0FBVyxPQUFPO2dCQUFDYSxPQUFPLEVBQUVBLENBQUEsS0FBTTVJLE9BQU8sQ0FBQyxLQUFLLENBQUU7Z0JBQUFnSSxRQUFBLGVBQ3RFLElBQUF4SixXQUFBLENBQUEySixHQUFBLEVBQUM3SixLQUFBLENBQUFPLE9BQUk7a0JBQUMwQyxJQUFJLEVBQUM7Z0JBQUcsQ0FBRTtjQUFDLENBQ1gsQ0FBQztZQUFBLENBQ0wsQ0FBQztVQUFBLENBQ0osQ0FBQyxlQUtOLElBQUEvQyxXQUFBLENBQUEySixHQUFBO1lBQUtKLFNBQVMsRUFBQyxVQUFVO1lBQUNlLElBQUksRUFBQyxNQUFNO1lBQUMsY0FBVyw0QkFBNEI7WUFBQWQsUUFBQSxFQUMxRTVGLFNBQVMsQ0FBQ1ksR0FBRyxDQUFFQyxDQUFDLGlCQUNmLElBQUF6RSxXQUFBLENBQUFzSixJQUFBO2NBQUtDLFNBQVMsRUFBRSxnQ0FBZ0M5RSxDQUFDLENBQUNHLEtBQUssRUFBRztjQUFDMEYsSUFBSSxFQUFDLFVBQVU7Y0FBQWQsUUFBQSxnQkFDeEUsSUFBQXhKLFdBQUEsQ0FBQTJKLEdBQUE7Z0JBQU1KLFNBQVMsRUFBQyxnQkFBZ0I7Z0JBQUMsbUJBQVc7Z0JBQUFDLFFBQUEsRUFDekMvRSxDQUFDLENBQUNHLEtBQUssS0FBSyxJQUFJLEdBQUcsR0FBRyxHQUFHSCxDQUFDLENBQUNHLEtBQUssS0FBSyxTQUFTLEdBQUcsR0FBRyxHQUFHSCxDQUFDLENBQUNHLEtBQUssS0FBSyxXQUFXLEdBQUcsR0FBRyxHQUFHO2NBQUcsQ0FDdkYsQ0FBQyxlQUNQLElBQUE1RSxXQUFBLENBQUEySixHQUFBO2dCQUFNSixTQUFTLEVBQUMscUJBQXFCO2dCQUFBQyxRQUFBLEVBQUUsSUFBQTdFLG9CQUFTLEVBQUNGLENBQUMsQ0FBQ0csS0FBSztjQUFDLENBQU8sQ0FBQyxlQUNqRSxJQUFBNUUsV0FBQSxDQUFBMkosR0FBQTtnQkFBTUosU0FBUyxFQUFDLGlCQUFpQjtnQkFBQUMsUUFBQSxFQUFFL0UsQ0FBQyxDQUFDQztjQUFLLENBQU8sQ0FBQyxFQUNqREQsQ0FBQyxDQUFDK0YsS0FBSyxpQkFBSSxJQUFBeEssV0FBQSxDQUFBMkosR0FBQTtnQkFBTUosU0FBUyxFQUFDLGlCQUFpQjtnQkFBQUMsUUFBQSxFQUFFL0UsQ0FBQyxDQUFDK0Y7Y0FBSyxDQUFPLENBQUMsRUFDN0QvRixDQUFDLENBQUNnRyxXQUFXLGlCQUFJLElBQUF6SyxXQUFBLENBQUEySixHQUFBO2dCQUFNSixTQUFTLEVBQUMsaUJBQWlCO2dCQUFBQyxRQUFBLEVBQUUsS0FBSy9FLENBQUMsQ0FBQ2dHLFdBQVc7Y0FBRSxDQUFPLENBQUMsRUFDaEZoRyxDQUFDLENBQUNpRyxNQUFNLEtBQUssYUFBYTtjQUFBO2NBQ3pCO2NBQ0E7Y0FDQTtjQUNBO2NBQ0E7Y0FDQSxJQUFBMUssV0FBQSxDQUFBMkosR0FBQTtnQkFDRU8sSUFBSSxFQUFDLFFBQVE7Z0JBQ2JYLFNBQVMsRUFBQyxrQkFBa0I7Z0JBQzVCYSxPQUFPLEVBQUVBLENBQUEsS0FDUCxLQUFLdkUsR0FBRyxDQUFDL0QsS0FBSyxDQUFDa0UsSUFBSSxDQUFDLENBQUMsSUFBSSwrREFBK0QsQ0FDekY7Z0JBQUF3RCxRQUFBLEVBQ0Y7Y0FFRCxDQUFRLENBQ1Q7WUFBQSxHQXZCNkUvRSxDQUFDLENBQUNrRyxHQXdCN0UsQ0FDTjtVQUFDLENBQ0MsQ0FBQyxFQUNMdkcsU0FBUyxpQkFBSSxJQUFBcEUsV0FBQSxDQUFBMkosR0FBQTtZQUFHSixTQUFTLEVBQUMsV0FBVztZQUFBQyxRQUFBLEVBQUVwRjtVQUFTLENBQUksQ0FBQyxlQUd0RCxJQUFBcEUsV0FBQSxDQUFBMkosR0FBQTtZQUFLSixTQUFTLEVBQUMscUJBQXFCO1lBQUNlLElBQUksRUFBQyxRQUFRO1lBQUFkLFFBQUEsRUFDL0NqRjtVQUFpQixDQUNmLENBQUMsRUFDTCxJQUFBcUcsK0JBQW9CLEVBQUNsSyxhQUFhLENBQUMsaUJBQUksSUFBQVYsV0FBQSxDQUFBMkosR0FBQTtZQUFHSixTQUFTLEVBQUMsV0FBVztZQUFBQyxRQUFBLEVBQUVxQjtVQUFpQixDQUFJLENBQUMsRUFDdkZ6SSxVQUFVLGlCQUNULElBQUFwQyxXQUFBLENBQUEySixHQUFBO1lBQUtKLFNBQVMsRUFBQyxVQUFVO1lBQUNlLElBQUksRUFBQyxRQUFRO1lBQUFkLFFBQUEsRUFDcENwSDtVQUFVLENBQ1IsQ0FDTixlQUVELElBQUFwQyxXQUFBLENBQUEySixHQUFBO1lBQUtKLFNBQVMsRUFBQyxTQUFTO1lBQUNVLEdBQUcsRUFBRTNILE9BQVE7WUFBQWtILFFBQUEsRUFDbkN4SCxJQUFJLENBQUMyRixNQUFNLEtBQUssQ0FBQyxnQkFDaEIsSUFBQTNILFdBQUEsQ0FBQXNKLElBQUEsRUFBQXRKLFdBQUEsQ0FBQW1LLFFBQUE7Y0FBQVgsUUFBQSxnQkFDRSxJQUFBeEosV0FBQSxDQUFBc0osSUFBQTtnQkFBS0MsU0FBUyxFQUFDLFlBQVk7Z0JBQUFDLFFBQUEsZ0JBQ3pCLElBQUF4SixXQUFBLENBQUEySixHQUFBO2tCQUFBSCxRQUFBLEVBQUc7Z0JBQWEsQ0FBRyxDQUFDLDhHQUV0QjtjQUFBLENBQUssQ0FBQyxFQUNMdEYsS0FBSyxDQUFDeUQsTUFBTSxHQUFHLENBQUMsaUJBQ2YsSUFBQTNILFdBQUEsQ0FBQTJKLEdBQUE7Z0JBQUtKLFNBQVMsRUFBQyxVQUFVO2dCQUFBQyxRQUFBLEVBQ3RCdEYsS0FBSyxDQUFDTSxHQUFHLENBQUVzRyxDQUFDLGlCQUNYLElBQUE5SyxXQUFBLENBQUEySixHQUFBO2tCQUFnQkosU0FBUyxFQUFDLFNBQVM7a0JBQUNhLE9BQU8sRUFBRUEsQ0FBQSxLQUFNLEtBQUt2RSxHQUFHLENBQUNpRixDQUFDLENBQUU7a0JBQUF0QixRQUFBLEVBQzVEc0I7Z0JBQUMsR0FEU0EsQ0FFTCxDQUNUO2NBQUMsQ0FDQyxDQUNOO1lBQUEsQ0FDRCxDQUFDLEdBRUg5SSxJQUFJLENBQUN3QyxHQUFHLENBQUMsQ0FBQ0MsQ0FBQyxFQUFFc0csQ0FBQyxLQUNadEcsQ0FBQyxDQUFDeUIsSUFBSSxLQUFLLFVBQVUsZ0JBQ25CLElBQUFsRyxXQUFBLENBQUFzSixJQUFBO2NBQWFDLFNBQVMsRUFBQyxhQUFhO2NBQUFDLFFBQUEsZ0JBQ2xDLElBQUF4SixXQUFBLENBQUEySixHQUFBLEVBQUM3SixLQUFBLENBQUFPLE9BQUk7Z0JBQUMwQyxJQUFJLEVBQUM7Y0FBTSxDQUFFLENBQUMsRUFDbkIwQixDQUFDLENBQUMwQixJQUFJO1lBQUEsR0FGQzRFLENBR0wsQ0FBQyxnQkFFTixJQUFBL0ssV0FBQSxDQUFBc0osSUFBQTtjQUFhQyxTQUFTLEVBQUUsVUFBVTlFLENBQUMsQ0FBQ3lCLElBQUksRUFBRztjQUFBc0QsUUFBQSxnQkFDekMsSUFBQXhKLFdBQUEsQ0FBQTJKLEdBQUE7Z0JBQU1KLFNBQVMsRUFBRSxjQUFjOUUsQ0FBQyxDQUFDeUIsSUFBSSxLQUFLLFdBQVcsR0FBRyxPQUFPLEdBQUcsTUFBTSxFQUFHO2dCQUFBc0QsUUFBQSxFQUN4RS9FLENBQUMsQ0FBQ3lCLElBQUksS0FBSyxXQUFXLEdBQUcsRUFBRSxHQUFHO2NBQUssQ0FDaEMsQ0FBQyxlQUNQLElBQUFsRyxXQUFBLENBQUFzSixJQUFBO2dCQUFLQyxTQUFTLEVBQUMsV0FBVztnQkFBQUMsUUFBQSxnQkFDeEIsSUFBQXhKLFdBQUEsQ0FBQTJKLEdBQUE7a0JBQUtKLFNBQVMsRUFBQyxhQUFhO2tCQUFBQyxRQUFBLEVBQUUvRSxDQUFDLENBQUN5QixJQUFJLEtBQUssV0FBVyxHQUFHLE9BQU8sR0FBRztnQkFBSyxDQUFNLENBQUMsZUFDN0UsSUFBQWxHLFdBQUEsQ0FBQXNKLElBQUE7a0JBQUtDLFNBQVMsRUFBQyxhQUFhO2tCQUFBQyxRQUFBLEdBQ3pCL0UsQ0FBQyxDQUFDMEIsSUFBSSxFQUNOakUsU0FBUyxJQUFJNkksQ0FBQyxLQUFLL0ksSUFBSSxDQUFDMkYsTUFBTSxHQUFHLENBQUMsSUFBSWxELENBQUMsQ0FBQ3lCLElBQUksS0FBSyxXQUFXLGdCQUFHLElBQUFsRyxXQUFBLENBQUEySixHQUFBO29CQUFNSixTQUFTLEVBQUM7a0JBQVcsQ0FBRSxDQUFDLEdBQUcsSUFBSTtnQkFBQSxDQUNsRyxDQUFDO2NBQUEsQ0FDSCxDQUFDO1lBQUEsR0FWRXdCLENBV0wsQ0FFVDtVQUNELENBQ0UsQ0FBQyxlQUVOLElBQUEvSyxXQUFBLENBQUFzSixJQUFBO1lBQUtDLFNBQVMsRUFBQyxTQUFTO1lBQUFDLFFBQUEsZ0JBQ3RCLElBQUF4SixXQUFBLENBQUFzSixJQUFBO2NBQ0VDLFNBQVMsRUFBQyxjQUFjO2NBQ3hCRSxRQUFRLEVBQUd0SixDQUFDLElBQUs7Z0JBQ2ZBLENBQUMsQ0FBQ3VKLGNBQWMsQ0FBQyxDQUFDO2dCQUNsQixLQUFLN0QsR0FBRyxDQUFDL0QsS0FBSyxDQUFDO2NBQ2pCLENBQUU7Y0FBQTBILFFBQUEsZ0JBRUYsSUFBQXhKLFdBQUEsQ0FBQTJKLEdBQUE7Z0JBQ0VNLEdBQUcsRUFBRXpILE9BQVE7Z0JBQ2JvSCxLQUFLLEVBQUU5SCxLQUFNO2dCQUNiK0gsV0FBVyxFQUFDLGlCQUFZO2dCQUN4Qm1CLFFBQVEsRUFBRTlJLFNBQVMsSUFBSSxDQUFDNEMsTUFBTztnQkFDL0JnRixRQUFRLEVBQUczSixDQUFDLElBQUs0QixRQUFRLENBQUM1QixDQUFDLENBQUM0SixNQUFNLENBQUNILEtBQUs7Y0FBRSxDQUMzQyxDQUFDLEVBQ0QxSCxTQUFTLGdCQUNSLElBQUFsQyxXQUFBLENBQUEySixHQUFBO2dCQUNFSixTQUFTLEVBQUMsTUFBTTtnQkFDaEJXLElBQUksRUFBQyxRQUFRO2dCQUNiLGNBQVcsTUFBTTtnQkFDakJlLEtBQUssRUFBQyxNQUFNO2dCQUNaYixPQUFPLEVBQUVBLENBQUEsS0FBTTNILFFBQVEsQ0FBQzJDLE9BQU8sRUFBRThGLEtBQUssQ0FBQyxDQUFFO2dCQUFBMUIsUUFBQSxlQUV6QyxJQUFBeEosV0FBQSxDQUFBMkosR0FBQSxFQUFDN0osS0FBQSxDQUFBTyxPQUFJO2tCQUFDMEMsSUFBSSxFQUFDO2dCQUFHLENBQUU7Y0FBQyxDQUNYLENBQUMsR0FDUCxJQUFJLGVBQ1IsSUFBQS9DLFdBQUEsQ0FBQTJKLEdBQUE7Z0JBQVFKLFNBQVMsRUFBQyxJQUFJO2dCQUFDVyxJQUFJLEVBQUMsUUFBUTtnQkFBQ2MsUUFBUSxFQUFFOUksU0FBUyxJQUFJLENBQUM0QyxNQUFNLElBQUksQ0FBQ2hELEtBQUssQ0FBQ2tFLElBQUksQ0FBQyxDQUFFO2dCQUFDLGNBQVk5RCxTQUFTLEdBQUcsWUFBWSxHQUFHLE1BQU87Z0JBQUMrSSxLQUFLLEVBQUUvSSxTQUFTLEdBQUcsWUFBWSxHQUFHLE1BQU87Z0JBQUFzSCxRQUFBLGVBQzVLLElBQUF4SixXQUFBLENBQUEySixHQUFBLEVBQUM3SixLQUFBLENBQUFPLE9BQUk7a0JBQUMwQyxJQUFJLEVBQUM7Z0JBQU0sQ0FBRTtjQUFDLENBQ2QsQ0FBQztZQUFBLENBQ0wsQ0FBQyxlQUNQLElBQUEvQyxXQUFBLENBQUFzSixJQUFBO2NBQUtDLFNBQVMsRUFBQyxlQUFlO2NBQUFDLFFBQUEsZ0JBQzVCLElBQUF4SixXQUFBLENBQUEySixHQUFBO2dCQUFBSCxRQUFBLEVBQU9xQjtjQUFpQixDQUFPLENBQUMsRUFDL0J4SixXQUFXLGlCQUNWLElBQUFyQixXQUFBLENBQUEySixHQUFBO2dCQUFNSixTQUFTLEVBQUMsaUJBQWlCO2dCQUFDZSxJQUFJLEVBQUMsUUFBUTtnQkFBQWQsUUFBQSxFQUM1QzJCO2NBQW1CLENBQ2hCLENBQ1AsZUFDRCxJQUFBbkwsV0FBQSxDQUFBc0osSUFBQTtnQkFBUVksSUFBSSxFQUFDLFFBQVE7Z0JBQUNFLE9BQU8sRUFBRUEsQ0FBQSxLQUFNaEosVUFBVSxDQUFDWixRQUFRLENBQUU7Z0JBQUFnSixRQUFBLGdCQUN4RCxJQUFBeEosV0FBQSxDQUFBMkosR0FBQSxFQUFDN0osS0FBQSxDQUFBTyxPQUFJO2tCQUFDMEMsSUFBSSxFQUFDO2dCQUFVLENBQUUsQ0FBQyxzQkFFMUI7Y0FBQSxDQUFRLENBQUM7WUFBQSxDQUNOLENBQUM7VUFBQSxDQUNILENBQUM7UUFBQSxDQUNIO01BQUMsQ0FDSCxDQUFDO0lBQUEsQ0FDTixDQUNIO0VBQUEsQ0FDRSxDQUFDO0FBRVY7QUFBQzlDLEVBQUEsQ0F0WnVCSyxVQUFVO0VBQUEsUUFTVksseUJBQW9CLEVBQzFCRSxlQUFVLEVBQ1pFLG1CQUFjLEVBQ1hFLHdCQUFXLEVBQ05FLDZCQUFnQixFQUNGRyxlQUFRLEVBZTFCcUIsOENBQXNCLEVBUWhCTSxzQ0FBa0IsRUFDMUJFLG9CQUFlO0FBQUE7QUFBQWlJLEVBQUEsR0F0Q1Q5SyxVQUFVO0FBQUEsSUFBQThLLEVBQUE7QUFBQUMsWUFBQSxDQUFBRCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}