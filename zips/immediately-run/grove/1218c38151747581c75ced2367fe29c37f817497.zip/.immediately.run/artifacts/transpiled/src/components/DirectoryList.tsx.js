var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = DirectoryList;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
var _sdk = require("@immediately-run/sdk");
var _useEntryKey = require("../hooks/useEntryKey");
var _useFollowLink = require("../hooks/useFollowLink");
var _navigationPolicy = require("../lib/navigationPolicy");
var _directory = require("../lib/directory");
var _useDirectoryListing = require("../hooks/useDirectoryListing");
var _Icon = _interopRequireDefault(require("./Icon"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(),
  _s2 = $RefreshSig$();
/* eslint-disable @typescript-eslint/no-explicit-any */
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
const HEADINGS = {
  name: 'Name',
  description: 'Description',
  tags: 'Tags',
  updated: 'Updated',
  status: 'Status'
};

// `hidden="false"` is a string in MDX, and under the safe renderer EVERY attribute is a
// literal string — so a boolean prop that trusted truthiness would read `"false"` as on.
function flag(v) {
  return v === true || v === '' || v === 'true';
}
function Cell({
  row,
  col
}) {
  const value = (0, _directory.columnValue)(row, col);
  if (col === 'tags') {
    const tags = Array.isArray(value) ? value : [];
    return /*#__PURE__*/(0, _jsxRuntime.jsx)("td", {
      className: "gdir__tags",
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "gdir__tagbox",
        children: tags.slice(0, 4).map(t => /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
          className: "grove-tag",
          children: ["#", t]
        }, t))
      })
    });
  }
  if (col === 'updated' || col === 'status') {
    return /*#__PURE__*/(0, _jsxRuntime.jsx)("td", {
      className: `mono gdir__${col}`,
      children: typeof value === 'string' ? value : null
    });
  }
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("td", {
    className: "gdir__desc",
    children: typeof value === 'string' ? value : null
  });
}
_c = Cell;
function Row({
  row,
  cols
}) {
  _s();
  const label = (0, _directory.rowLabel)(row);
  const from = (0, _useEntryKey.useEntryKey)();
  const follow = (0, _useFollowLink.useFollowLink)();
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("tr", {
    "data-kind": row.kind,
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("td", {
      className: "gdir__name",
      children: /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "gdir__namebox",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "gdir__icon",
          "aria-hidden": "true",
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
            name: row.kind === 'dir' ? 'folder' : 'file'
          })
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
          className: "gdir__labels",
          children: [row.href ? /*#__PURE__*/(0, _jsxRuntime.jsx)(_sdk.Link, {
            href: row.href,
            className: "gdir__link",
            onClick: (0, _navigationPolicy.followLinkOnClick)(follow, {
              key: row.key,
              href: row.href,
              from
            }),
            children: label
          }) :
          /*#__PURE__*/
          // An asset is listed but not linked: Grove's route space renders entries,
          // so a link here would resolve to the 404 it was meant to replace.
          (0, _jsxRuntime.jsx)("span", {
            className: "gdir__plain",
            children: label
          }), label !== row.name ? /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
            className: "gdir__file",
            children: row.name
          }) : null]
        })]
      })
    }), cols.slice(1).map(c => /*#__PURE__*/(0, _jsxRuntime.jsx)(Cell, {
      row: row,
      col: c
    }, c))]
  });
}

/**
 * `<DirectoryList/>` — every file in a folder as a table, enriched with whatever Grove
 * frontmatter its entries carry.
 *
 * Two callers, one component. Content uses it as ordinary import-free vocabulary
 * (`<DirectoryList path="/handbook"/>`); the router renders it for a URL that names a
 * FOLDER rather than an entry — the case that used to 404. Both go through the MDX
 * component map, so a fork or a content-provided `DirectoryList` (R3-174) replaces the
 * built-in on *both* surfaces at once. That is the point of resolving it by name rather
 * than importing it in the router: an override that only reached MDX bodies and left the
 * folder route rendering the stock table would be a half-override nobody could see.
 */
_s(Row, "3St0C/EkmrmYwAGnO93SahbOJ+o=", false, function () {
  return [_useEntryKey.useEntryKey, _useFollowLink.useFollowLink];
});
_c2 = Row;
function DirectoryList({
  path,
  title,
  columns,
  sort = 'name',
  hidden
}) {
  _s2();
  const entryKey = (0, _useEntryKey.useEntryKey)();
  // The entry this listing renders inside (an entry-context key, so an included
  // fragment or a layout anchors where it renders, not where the URL points).
  // It is a FILE when it names an entry; a listing anchored at an entry means
  // "the folder that entry lives in", which is what an author writing `<DirectoryList/>`
  // inside a page means by "here".
  const fromDir = /\.mdx?$/.test(entryKey) ? entryKey.slice(0, entryKey.lastIndexOf('/')) : entryKey;
  const dirKey = (0, _directory.resolveDirKey)(path, fromDir);
  const listing = (0, _useDirectoryListing.useDirectoryListing)(dirKey);
  const metadata = (0, _sdk.useAllMetadata)();
  if (listing.status !== 'ready') {
    return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "grove-dirlist",
      "data-state": listing.status,
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "sk sk-line",
        style: {
          width: '60%'
        }
      })
    });
  }
  const rows = (0, _directory.buildDirectoryRows)(dirKey, listing.entries, metadata, {
    hidden: flag(hidden),
    sort
  });
  const cols = (0, _directory.visibleColumns)(rows, (0, _directory.parseColumns)(columns));
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "grove-dirlist",
    children: [title ? /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "grove-doclist__head",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("h2", {
        children: title
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
        className: "n",
        children: [rows.length, " ", rows.length === 1 ? 'item' : 'items']
      })]
    }) : null, rows.length === 0 ?
    /*#__PURE__*/
    // Two different facts, said differently. A folder with nothing in it and a folder
    // whose every child is structural (`_layout.mdx`) both produce zero rows, and
    // "This folder is empty." is false for the second — the reader goes looking for
    // the file they know is there. Say which it is.
    (0, _jsxRuntime.jsxs)("div", {
      className: "grove-dirlist__empty",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "gdir__icon",
        "aria-hidden": "true",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
          name: "folder"
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
        className: "grove-dirlist__empty-t",
        children: listing.entries.length === 0 ? 'This folder is empty.' : 'Nothing to show in this folder.'
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
        className: "grove-dirlist__empty-d",
        children: listing.entries.length === 0 ? 'No entries, subfolders or files here yet.' : `Everything here is hidden or structural — ${listing.entries.length} ${listing.entries.length === 1 ? 'file' : 'files'} skipped.`
      })]
    }) : /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "grove-table-wrap",
      children: /*#__PURE__*/(0, _jsxRuntime.jsxs)("table", {
        className: "grove-table grove-dirlist__table",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("thead", {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)("tr", {
            children: cols.map(c => /*#__PURE__*/(0, _jsxRuntime.jsx)("th", {
              scope: "col",
              className: `gdir__th gdir__th--${c}`,
              children: HEADINGS[c]
            }, c))
          })
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("tbody", {
          children: rows.map(r => /*#__PURE__*/(0, _jsxRuntime.jsx)(Row, {
            row: r,
            cols: cols
          }, r.key))
        })]
      })
    })]
  });
}
_s2(DirectoryList, "ps9An8T2BfC9sZ5FRsdXNLzypSo=", false, function () {
  return [_useEntryKey.useEntryKey, _useDirectoryListing.useDirectoryListing, _sdk.useAllMetadata];
});
_c3 = DirectoryList;
var _c, _c2, _c3;
$RefreshReg$(_c, "Cell");
$RefreshReg$(_c2, "Row");
$RefreshReg$(_c3, "DirectoryList");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfc2RrIiwicmVxdWlyZSIsIl91c2VFbnRyeUtleSIsIl91c2VGb2xsb3dMaW5rIiwiX25hdmlnYXRpb25Qb2xpY3kiLCJfZGlyZWN0b3J5IiwiX3VzZURpcmVjdG9yeUxpc3RpbmciLCJfSWNvbiIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiX3MyIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiSEVBRElOR1MiLCJuYW1lIiwiZGVzY3JpcHRpb24iLCJ0YWdzIiwidXBkYXRlZCIsInN0YXR1cyIsImZsYWciLCJ2IiwiQ2VsbCIsInJvdyIsImNvbCIsInZhbHVlIiwiY29sdW1uVmFsdWUiLCJBcnJheSIsImlzQXJyYXkiLCJqc3giLCJjbGFzc05hbWUiLCJjaGlsZHJlbiIsInNsaWNlIiwibWFwIiwidCIsImpzeHMiLCJfYyIsIlJvdyIsImNvbHMiLCJsYWJlbCIsInJvd0xhYmVsIiwiZnJvbSIsInVzZUVudHJ5S2V5IiwiZm9sbG93IiwidXNlRm9sbG93TGluayIsImtpbmQiLCJocmVmIiwiTGluayIsIm9uQ2xpY2siLCJmb2xsb3dMaW5rT25DbGljayIsImtleSIsImMiLCJfYzIiLCJEaXJlY3RvcnlMaXN0IiwicGF0aCIsInRpdGxlIiwiY29sdW1ucyIsInNvcnQiLCJoaWRkZW4iLCJlbnRyeUtleSIsImZyb21EaXIiLCJ0ZXN0IiwibGFzdEluZGV4T2YiLCJkaXJLZXkiLCJyZXNvbHZlRGlyS2V5IiwibGlzdGluZyIsInVzZURpcmVjdG9yeUxpc3RpbmciLCJtZXRhZGF0YSIsInVzZUFsbE1ldGFkYXRhIiwic3R5bGUiLCJ3aWR0aCIsInJvd3MiLCJidWlsZERpcmVjdG9yeVJvd3MiLCJlbnRyaWVzIiwidmlzaWJsZUNvbHVtbnMiLCJwYXJzZUNvbHVtbnMiLCJsZW5ndGgiLCJzY29wZSIsInIiLCJfYzMiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJEaXJlY3RvcnlMaXN0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55ICovXG5pbXBvcnQgeyBMaW5rLCB1c2VBbGxNZXRhZGF0YSB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrJztcblxuaW1wb3J0IHsgdXNlRW50cnlLZXkgfSBmcm9tICcuLi9ob29rcy91c2VFbnRyeUtleSc7XG5pbXBvcnQgeyB1c2VGb2xsb3dMaW5rIH0gZnJvbSAnLi4vaG9va3MvdXNlRm9sbG93TGluayc7XG5pbXBvcnQgeyBmb2xsb3dMaW5rT25DbGljayB9IGZyb20gJy4uL2xpYi9uYXZpZ2F0aW9uUG9saWN5JztcbmltcG9ydCB7XG4gIGJ1aWxkRGlyZWN0b3J5Um93cyxcbiAgY29sdW1uVmFsdWUsXG4gIHBhcnNlQ29sdW1ucyxcbiAgcmVzb2x2ZURpcktleSxcbiAgcm93TGFiZWwsXG4gIHZpc2libGVDb2x1bW5zLFxuICB0eXBlIERpckNvbHVtbixcbiAgdHlwZSBEaXJSb3csXG59IGZyb20gJy4uL2xpYi9kaXJlY3RvcnknO1xuaW1wb3J0IHsgdXNlRGlyZWN0b3J5TGlzdGluZyB9IGZyb20gJy4uL2hvb2tzL3VzZURpcmVjdG9yeUxpc3RpbmcnO1xuaW1wb3J0IEljb24gZnJvbSAnLi9JY29uJztcblxuaW50ZXJmYWNlIFByb3BzIHtcbiAgLyoqIFRoZSBmb2xkZXIgdG8gbGlzdC4gQ29ycHVzLXJlbGF0aXZlIHdpdGggYSBsZWFkaW5nIGAvYCAoYC9oYW5kYm9va2ApLCBvdGhlcndpc2VcbiAgICogIHJlbGF0aXZlIHRvIHRoZSBjdXJyZW50IGVudHJ5J3MgZm9sZGVyLiBPbWl0IGl0IHRvIGxpc3QgdGhlIGN1cnJlbnQgZm9sZGVyLiAqL1xuICBwYXRoPzogc3RyaW5nO1xuICAvKiogSGVhZGluZyBhYm92ZSB0aGUgdGFibGUuIGBudWxsYC9gXCJcImAgcmVuZGVycyBubyBoZWFkaW5nLiAqL1xuICB0aXRsZT86IHN0cmluZyB8IG51bGw7XG4gIC8qKiBgZGVzY3JpcHRpb24sdGFncyx1cGRhdGVkLHN0YXR1c2Ag4oCUIHdoaWNoIG1ldGFkYXRhIGNvbHVtbnMgdG8gY29uc2lkZXIuIEEgY29sdW1uXG4gICAqICBubyByb3cgY2FycmllcyBpcyBkcm9wcGVkIHJlZ2FyZGxlc3MsIHNvIHRoaXMgbmFycm93cywgbmV2ZXIgcGFkcy4gKi9cbiAgY29sdW1ucz86IHN0cmluZztcbiAgc29ydD86ICduYW1lJyB8ICd0aXRsZScgfCAndXBkYXRlZCc7XG4gIC8qKiBJbmNsdWRlIGRvdC0gYW5kIGBfYC1wcmVmaXhlZCBuYW1lcy4gKi9cbiAgaGlkZGVuPzogYm9vbGVhbiB8IHN0cmluZztcbn1cblxuY29uc3QgSEVBRElOR1M6IFJlY29yZDxEaXJDb2x1bW4sIHN0cmluZz4gPSB7XG4gIG5hbWU6ICdOYW1lJyxcbiAgZGVzY3JpcHRpb246ICdEZXNjcmlwdGlvbicsXG4gIHRhZ3M6ICdUYWdzJyxcbiAgdXBkYXRlZDogJ1VwZGF0ZWQnLFxuICBzdGF0dXM6ICdTdGF0dXMnLFxufTtcblxuLy8gYGhpZGRlbj1cImZhbHNlXCJgIGlzIGEgc3RyaW5nIGluIE1EWCwgYW5kIHVuZGVyIHRoZSBzYWZlIHJlbmRlcmVyIEVWRVJZIGF0dHJpYnV0ZSBpcyBhXG4vLyBsaXRlcmFsIHN0cmluZyDigJQgc28gYSBib29sZWFuIHByb3AgdGhhdCB0cnVzdGVkIHRydXRoaW5lc3Mgd291bGQgcmVhZCBgXCJmYWxzZVwiYCBhcyBvbi5cbmZ1bmN0aW9uIGZsYWcodjogYm9vbGVhbiB8IHN0cmluZyB8IHVuZGVmaW5lZCk6IGJvb2xlYW4ge1xuICByZXR1cm4gdiA9PT0gdHJ1ZSB8fCB2ID09PSAnJyB8fCB2ID09PSAndHJ1ZSc7XG59XG5cbmZ1bmN0aW9uIENlbGwoeyByb3csIGNvbCB9OiB7IHJvdzogRGlyUm93OyBjb2w6IERpckNvbHVtbiB9KSB7XG4gIGNvbnN0IHZhbHVlID0gY29sdW1uVmFsdWUocm93LCBjb2wpO1xuICBpZiAoY29sID09PSAndGFncycpIHtcbiAgICBjb25zdCB0YWdzID0gQXJyYXkuaXNBcnJheSh2YWx1ZSkgPyB2YWx1ZSA6IFtdO1xuICAgIHJldHVybiAoXG4gICAgICA8dGQgY2xhc3NOYW1lPVwiZ2Rpcl9fdGFnc1wiPlxuICAgICAgICB7LyogU2FtZSByZWFzb24gYXMgdGhlIG5hbWUgY2VsbDogdGhlIGZsZXggYm94IGdvZXMgSU5TSURFIHRoZSBgPHRkPmAuICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdkaXJfX3RhZ2JveFwiPlxuICAgICAgICAgIHt0YWdzLnNsaWNlKDAsIDQpLm1hcCgodCkgPT4gKFxuICAgICAgICAgICAgPHNwYW4ga2V5PXt0fSBjbGFzc05hbWU9XCJncm92ZS10YWdcIj4je3R9PC9zcGFuPlxuICAgICAgICAgICkpfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvdGQ+XG4gICAgKTtcbiAgfVxuICBpZiAoY29sID09PSAndXBkYXRlZCcgfHwgY29sID09PSAnc3RhdHVzJykge1xuICAgIHJldHVybiA8dGQgY2xhc3NOYW1lPXtgbW9ubyBnZGlyX18ke2NvbH1gfT57dHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJyA/IHZhbHVlIDogbnVsbH08L3RkPjtcbiAgfVxuICByZXR1cm4gPHRkIGNsYXNzTmFtZT1cImdkaXJfX2Rlc2NcIj57dHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJyA/IHZhbHVlIDogbnVsbH08L3RkPjtcbn1cblxuZnVuY3Rpb24gUm93KHsgcm93LCBjb2xzIH06IHsgcm93OiBEaXJSb3c7IGNvbHM6IERpckNvbHVtbltdIH0pIHtcbiAgY29uc3QgbGFiZWwgPSByb3dMYWJlbChyb3cpO1xuICBjb25zdCBmcm9tID0gdXNlRW50cnlLZXkoKTtcbiAgY29uc3QgZm9sbG93ID0gdXNlRm9sbG93TGluaygpO1xuICByZXR1cm4gKFxuICAgIDx0ciBkYXRhLWtpbmQ9e3Jvdy5raW5kfT5cbiAgICAgIDx0ZCBjbGFzc05hbWU9XCJnZGlyX19uYW1lXCI+XG4gICAgICAgIHsvKiBUaGUgZmxleCBib3ggaXMgSU5TSURFIHRoZSBjZWxsLiBgZGlzcGxheTpmbGV4YCBvbiBhIGA8dGQ+YCB0YWtlcyBpdCBvdXQgb2ZcbiAgICAgICAgICAgIHRoZSB0YWJsZSBsYXlvdXQgYWxnb3JpdGhtLCBhbmQgdGhlIGNvbHVtbiBzdG9wcyBzaGFyaW5nIGEgd2lkdGggd2l0aCBpdHNcbiAgICAgICAgICAgIGhlYWRlciDigJQgdGhlIHN5bXB0b20gaXMgcGVyLXJvdyBib3JkZXJzIHRoYXQgZG9uJ3QgbGluZSB1cC4gKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ2Rpcl9fbmFtZWJveFwiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImdkaXJfX2ljb25cIiBhcmlhLWhpZGRlbj1cInRydWVcIj5cbiAgICAgICAgICAgIDxJY29uIG5hbWU9e3Jvdy5raW5kID09PSAnZGlyJyA/ICdmb2xkZXInIDogJ2ZpbGUnfSAvPlxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJnZGlyX19sYWJlbHNcIj5cbiAgICAgICAgICAgIHtyb3cuaHJlZiA/IChcbiAgICAgICAgICAgICAgPExpbmtcbiAgICAgICAgICAgICAgICBocmVmPXtyb3cuaHJlZn1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJnZGlyX19saW5rXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtmb2xsb3dMaW5rT25DbGljayhmb2xsb3csIHsga2V5OiByb3cua2V5LCBocmVmOiByb3cuaHJlZiwgZnJvbSB9KX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHtsYWJlbH1cbiAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgLy8gQW4gYXNzZXQgaXMgbGlzdGVkIGJ1dCBub3QgbGlua2VkOiBHcm92ZSdzIHJvdXRlIHNwYWNlIHJlbmRlcnMgZW50cmllcyxcbiAgICAgICAgICAgICAgLy8gc28gYSBsaW5rIGhlcmUgd291bGQgcmVzb2x2ZSB0byB0aGUgNDA0IGl0IHdhcyBtZWFudCB0byByZXBsYWNlLlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJnZGlyX19wbGFpblwiPntsYWJlbH08L3NwYW4+XG4gICAgICAgICAgICApfVxuICAgICAgICAgICAge2xhYmVsICE9PSByb3cubmFtZSA/IDxzcGFuIGNsYXNzTmFtZT1cImdkaXJfX2ZpbGVcIj57cm93Lm5hbWV9PC9zcGFuPiA6IG51bGx9XG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvdGQ+XG4gICAgICB7Y29scy5zbGljZSgxKS5tYXAoKGMpID0+IChcbiAgICAgICAgPENlbGwga2V5PXtjfSByb3c9e3Jvd30gY29sPXtjfSAvPlxuICAgICAgKSl9XG4gICAgPC90cj5cbiAgKTtcbn1cblxuLyoqXG4gKiBgPERpcmVjdG9yeUxpc3QvPmAg4oCUIGV2ZXJ5IGZpbGUgaW4gYSBmb2xkZXIgYXMgYSB0YWJsZSwgZW5yaWNoZWQgd2l0aCB3aGF0ZXZlciBHcm92ZVxuICogZnJvbnRtYXR0ZXIgaXRzIGVudHJpZXMgY2FycnkuXG4gKlxuICogVHdvIGNhbGxlcnMsIG9uZSBjb21wb25lbnQuIENvbnRlbnQgdXNlcyBpdCBhcyBvcmRpbmFyeSBpbXBvcnQtZnJlZSB2b2NhYnVsYXJ5XG4gKiAoYDxEaXJlY3RvcnlMaXN0IHBhdGg9XCIvaGFuZGJvb2tcIi8+YCk7IHRoZSByb3V0ZXIgcmVuZGVycyBpdCBmb3IgYSBVUkwgdGhhdCBuYW1lcyBhXG4gKiBGT0xERVIgcmF0aGVyIHRoYW4gYW4gZW50cnkg4oCUIHRoZSBjYXNlIHRoYXQgdXNlZCB0byA0MDQuIEJvdGggZ28gdGhyb3VnaCB0aGUgTURYXG4gKiBjb21wb25lbnQgbWFwLCBzbyBhIGZvcmsgb3IgYSBjb250ZW50LXByb3ZpZGVkIGBEaXJlY3RvcnlMaXN0YCAoUjMtMTc0KSByZXBsYWNlcyB0aGVcbiAqIGJ1aWx0LWluIG9uICpib3RoKiBzdXJmYWNlcyBhdCBvbmNlLiBUaGF0IGlzIHRoZSBwb2ludCBvZiByZXNvbHZpbmcgaXQgYnkgbmFtZSByYXRoZXJcbiAqIHRoYW4gaW1wb3J0aW5nIGl0IGluIHRoZSByb3V0ZXI6IGFuIG92ZXJyaWRlIHRoYXQgb25seSByZWFjaGVkIE1EWCBib2RpZXMgYW5kIGxlZnQgdGhlXG4gKiBmb2xkZXIgcm91dGUgcmVuZGVyaW5nIHRoZSBzdG9jayB0YWJsZSB3b3VsZCBiZSBhIGhhbGYtb3ZlcnJpZGUgbm9ib2R5IGNvdWxkIHNlZS5cbiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gRGlyZWN0b3J5TGlzdCh7IHBhdGgsIHRpdGxlLCBjb2x1bW5zLCBzb3J0ID0gJ25hbWUnLCBoaWRkZW4gfTogUHJvcHMpIHtcbiAgY29uc3QgZW50cnlLZXkgPSB1c2VFbnRyeUtleSgpO1xuICAvLyBUaGUgZW50cnkgdGhpcyBsaXN0aW5nIHJlbmRlcnMgaW5zaWRlIChhbiBlbnRyeS1jb250ZXh0IGtleSwgc28gYW4gaW5jbHVkZWRcbiAgLy8gZnJhZ21lbnQgb3IgYSBsYXlvdXQgYW5jaG9ycyB3aGVyZSBpdCByZW5kZXJzLCBub3Qgd2hlcmUgdGhlIFVSTCBwb2ludHMpLlxuICAvLyBJdCBpcyBhIEZJTEUgd2hlbiBpdCBuYW1lcyBhbiBlbnRyeTsgYSBsaXN0aW5nIGFuY2hvcmVkIGF0IGFuIGVudHJ5IG1lYW5zXG4gIC8vIFwidGhlIGZvbGRlciB0aGF0IGVudHJ5IGxpdmVzIGluXCIsIHdoaWNoIGlzIHdoYXQgYW4gYXV0aG9yIHdyaXRpbmcgYDxEaXJlY3RvcnlMaXN0Lz5gXG4gIC8vIGluc2lkZSBhIHBhZ2UgbWVhbnMgYnkgXCJoZXJlXCIuXG4gIGNvbnN0IGZyb21EaXIgPSAvXFwubWR4PyQvLnRlc3QoZW50cnlLZXkpID8gZW50cnlLZXkuc2xpY2UoMCwgZW50cnlLZXkubGFzdEluZGV4T2YoJy8nKSkgOiBlbnRyeUtleTtcbiAgY29uc3QgZGlyS2V5ID0gcmVzb2x2ZURpcktleShwYXRoLCBmcm9tRGlyKTtcblxuICBjb25zdCBsaXN0aW5nID0gdXNlRGlyZWN0b3J5TGlzdGluZyhkaXJLZXkpO1xuICBjb25zdCBtZXRhZGF0YSA9IHVzZUFsbE1ldGFkYXRhKCkgYXMgUmVjb3JkPHN0cmluZywgYW55PjtcblxuICBpZiAobGlzdGluZy5zdGF0dXMgIT09ICdyZWFkeScpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncm92ZS1kaXJsaXN0XCIgZGF0YS1zdGF0ZT17bGlzdGluZy5zdGF0dXN9PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNrIHNrLWxpbmVcIiBzdHlsZT17eyB3aWR0aDogJzYwJScgfX0gLz5cbiAgICAgIDwvZGl2PlxuICAgICk7XG4gIH1cblxuICBjb25zdCByb3dzID0gYnVpbGREaXJlY3RvcnlSb3dzKGRpcktleSwgbGlzdGluZy5lbnRyaWVzLCBtZXRhZGF0YSwge1xuICAgIGhpZGRlbjogZmxhZyhoaWRkZW4pLFxuICAgIHNvcnQsXG4gIH0pO1xuICBjb25zdCBjb2xzID0gdmlzaWJsZUNvbHVtbnMocm93cywgcGFyc2VDb2x1bW5zKGNvbHVtbnMpKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JvdmUtZGlybGlzdFwiPlxuICAgICAge3RpdGxlID8gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyb3ZlLWRvY2xpc3RfX2hlYWRcIj5cbiAgICAgICAgICA8aDI+e3RpdGxlfTwvaDI+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiblwiPlxuICAgICAgICAgICAge3Jvd3MubGVuZ3RofSB7cm93cy5sZW5ndGggPT09IDEgPyAnaXRlbScgOiAnaXRlbXMnfVxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApIDogbnVsbH1cbiAgICAgIHtyb3dzLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgLy8gVHdvIGRpZmZlcmVudCBmYWN0cywgc2FpZCBkaWZmZXJlbnRseS4gQSBmb2xkZXIgd2l0aCBub3RoaW5nIGluIGl0IGFuZCBhIGZvbGRlclxuICAgICAgICAvLyB3aG9zZSBldmVyeSBjaGlsZCBpcyBzdHJ1Y3R1cmFsIChgX2xheW91dC5tZHhgKSBib3RoIHByb2R1Y2UgemVybyByb3dzLCBhbmRcbiAgICAgICAgLy8gXCJUaGlzIGZvbGRlciBpcyBlbXB0eS5cIiBpcyBmYWxzZSBmb3IgdGhlIHNlY29uZCDigJQgdGhlIHJlYWRlciBnb2VzIGxvb2tpbmcgZm9yXG4gICAgICAgIC8vIHRoZSBmaWxlIHRoZXkga25vdyBpcyB0aGVyZS4gU2F5IHdoaWNoIGl0IGlzLlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyb3ZlLWRpcmxpc3RfX2VtcHR5XCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZ2Rpcl9faWNvblwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPlxuICAgICAgICAgICAgPEljb24gbmFtZT1cImZvbGRlclwiIC8+XG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImdyb3ZlLWRpcmxpc3RfX2VtcHR5LXRcIj5cbiAgICAgICAgICAgIHtsaXN0aW5nLmVudHJpZXMubGVuZ3RoID09PSAwID8gJ1RoaXMgZm9sZGVyIGlzIGVtcHR5LicgOiAnTm90aGluZyB0byBzaG93IGluIHRoaXMgZm9sZGVyLid9XG4gICAgICAgICAgPC9wPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImdyb3ZlLWRpcmxpc3RfX2VtcHR5LWRcIj5cbiAgICAgICAgICAgIHtsaXN0aW5nLmVudHJpZXMubGVuZ3RoID09PSAwXG4gICAgICAgICAgICAgID8gJ05vIGVudHJpZXMsIHN1YmZvbGRlcnMgb3IgZmlsZXMgaGVyZSB5ZXQuJ1xuICAgICAgICAgICAgICA6IGBFdmVyeXRoaW5nIGhlcmUgaXMgaGlkZGVuIG9yIHN0cnVjdHVyYWwg4oCUICR7bGlzdGluZy5lbnRyaWVzLmxlbmd0aH0gJHtsaXN0aW5nLmVudHJpZXMubGVuZ3RoID09PSAxID8gJ2ZpbGUnIDogJ2ZpbGVzJ30gc2tpcHBlZC5gfVxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICApIDogKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyb3ZlLXRhYmxlLXdyYXBcIj5cbiAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwiZ3JvdmUtdGFibGUgZ3JvdmUtZGlybGlzdF9fdGFibGVcIj5cbiAgICAgICAgICAgIDx0aGVhZD5cbiAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgIHtjb2xzLm1hcCgoYykgPT4gKFxuICAgICAgICAgICAgICAgICAgPHRoIGtleT17Y30gc2NvcGU9XCJjb2xcIiBjbGFzc05hbWU9e2BnZGlyX190aCBnZGlyX190aC0tJHtjfWB9PlxuICAgICAgICAgICAgICAgICAgICB7SEVBRElOR1NbY119XG4gICAgICAgICAgICAgICAgICA8L3RoPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgIDx0Ym9keT5cbiAgICAgICAgICAgICAge3Jvd3MubWFwKChyKSA9PiAoXG4gICAgICAgICAgICAgICAgPFJvdyBrZXk9e3Iua2V5fSByb3c9e3J9IGNvbHM9e2NvbHN9IC8+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQ0EsSUFBQUEsSUFBQSxHQUFBQyxPQUFBO0FBRUEsSUFBQUMsWUFBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsY0FBQSxHQUFBRixPQUFBO0FBQ0EsSUFBQUcsaUJBQUEsR0FBQUgsT0FBQTtBQUNBLElBQUFJLFVBQUEsR0FBQUosT0FBQTtBQVVBLElBQUFLLG9CQUFBLEdBQUFMLE9BQUE7QUFDQSxJQUFBTSxLQUFBLEdBQUFDLHNCQUFBLENBQUFQLE9BQUE7QUFBMEIsSUFBQVEsV0FBQSxHQUFBUixPQUFBO0FBQUEsSUFBQVMsRUFBQSxHQUFBQyxZQUFBO0VBQUFDLEdBQUEsR0FBQUQsWUFBQTtBQWpCMUI7QUFBQSxTQUFBSCx1QkFBQUssQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQWlDQSxNQUFNRyxRQUFtQyxHQUFHO0VBQzFDQyxJQUFJLEVBQUUsTUFBTTtFQUNaQyxXQUFXLEVBQUUsYUFBYTtFQUMxQkMsSUFBSSxFQUFFLE1BQU07RUFDWkMsT0FBTyxFQUFFLFNBQVM7RUFDbEJDLE1BQU0sRUFBRTtBQUNWLENBQUM7O0FBRUQ7QUFDQTtBQUNBLFNBQVNDLElBQUlBLENBQUNDLENBQStCLEVBQVc7RUFDdEQsT0FBT0EsQ0FBQyxLQUFLLElBQUksSUFBSUEsQ0FBQyxLQUFLLEVBQUUsSUFBSUEsQ0FBQyxLQUFLLE1BQU07QUFDL0M7QUFFQSxTQUFTQyxJQUFJQSxDQUFDO0VBQUVDLEdBQUc7RUFBRUM7QUFBcUMsQ0FBQyxFQUFFO0VBQzNELE1BQU1DLEtBQUssR0FBRyxJQUFBQyxzQkFBVyxFQUFDSCxHQUFHLEVBQUVDLEdBQUcsQ0FBQztFQUNuQyxJQUFJQSxHQUFHLEtBQUssTUFBTSxFQUFFO0lBQ2xCLE1BQU1QLElBQUksR0FBR1UsS0FBSyxDQUFDQyxPQUFPLENBQUNILEtBQUssQ0FBQyxHQUFHQSxLQUFLLEdBQUcsRUFBRTtJQUM5QyxvQkFDRSxJQUFBbEIsV0FBQSxDQUFBc0IsR0FBQTtNQUFJQyxTQUFTLEVBQUMsWUFBWTtNQUFBQyxRQUFBLGVBRXhCLElBQUF4QixXQUFBLENBQUFzQixHQUFBO1FBQUtDLFNBQVMsRUFBQyxjQUFjO1FBQUFDLFFBQUEsRUFDMUJkLElBQUksQ0FBQ2UsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQ0MsR0FBRyxDQUFFQyxDQUFDLGlCQUN0QixJQUFBM0IsV0FBQSxDQUFBNEIsSUFBQTtVQUFjTCxTQUFTLEVBQUMsV0FBVztVQUFBQyxRQUFBLEdBQUMsR0FBQyxFQUFDRyxDQUFDO1FBQUEsR0FBNUJBLENBQW1DLENBQy9DO01BQUMsQ0FDQztJQUFDLENBQ0osQ0FBQztFQUVUO0VBQ0EsSUFBSVYsR0FBRyxLQUFLLFNBQVMsSUFBSUEsR0FBRyxLQUFLLFFBQVEsRUFBRTtJQUN6QyxvQkFBTyxJQUFBakIsV0FBQSxDQUFBc0IsR0FBQTtNQUFJQyxTQUFTLEVBQUUsY0FBY04sR0FBRyxFQUFHO01BQUFPLFFBQUEsRUFBRSxPQUFPTixLQUFLLEtBQUssUUFBUSxHQUFHQSxLQUFLLEdBQUc7SUFBSSxDQUFLLENBQUM7RUFDNUY7RUFDQSxvQkFBTyxJQUFBbEIsV0FBQSxDQUFBc0IsR0FBQTtJQUFJQyxTQUFTLEVBQUMsWUFBWTtJQUFBQyxRQUFBLEVBQUUsT0FBT04sS0FBSyxLQUFLLFFBQVEsR0FBR0EsS0FBSyxHQUFHO0VBQUksQ0FBSyxDQUFDO0FBQ25GO0FBQUNXLEVBQUEsR0FuQlFkLElBQUk7QUFxQmIsU0FBU2UsR0FBR0EsQ0FBQztFQUFFZCxHQUFHO0VBQUVlO0FBQXlDLENBQUMsRUFBRTtFQUFBOUIsRUFBQTtFQUM5RCxNQUFNK0IsS0FBSyxHQUFHLElBQUFDLG1CQUFRLEVBQUNqQixHQUFHLENBQUM7RUFDM0IsTUFBTWtCLElBQUksR0FBRyxJQUFBQyx3QkFBVyxFQUFDLENBQUM7RUFDMUIsTUFBTUMsTUFBTSxHQUFHLElBQUFDLDRCQUFhLEVBQUMsQ0FBQztFQUM5QixvQkFDRSxJQUFBckMsV0FBQSxDQUFBNEIsSUFBQTtJQUFJLGFBQVdaLEdBQUcsQ0FBQ3NCLElBQUs7SUFBQWQsUUFBQSxnQkFDdEIsSUFBQXhCLFdBQUEsQ0FBQXNCLEdBQUE7TUFBSUMsU0FBUyxFQUFDLFlBQVk7TUFBQUMsUUFBQSxlQUl4QixJQUFBeEIsV0FBQSxDQUFBNEIsSUFBQTtRQUFLTCxTQUFTLEVBQUMsZUFBZTtRQUFBQyxRQUFBLGdCQUM1QixJQUFBeEIsV0FBQSxDQUFBc0IsR0FBQTtVQUFNQyxTQUFTLEVBQUMsWUFBWTtVQUFDLGVBQVksTUFBTTtVQUFBQyxRQUFBLGVBQzdDLElBQUF4QixXQUFBLENBQUFzQixHQUFBLEVBQUN4QixLQUFBLENBQUFRLE9BQUk7WUFBQ0UsSUFBSSxFQUFFUSxHQUFHLENBQUNzQixJQUFJLEtBQUssS0FBSyxHQUFHLFFBQVEsR0FBRztVQUFPLENBQUU7UUFBQyxDQUNsRCxDQUFDLGVBQ1AsSUFBQXRDLFdBQUEsQ0FBQTRCLElBQUE7VUFBTUwsU0FBUyxFQUFDLGNBQWM7VUFBQUMsUUFBQSxHQUMzQlIsR0FBRyxDQUFDdUIsSUFBSSxnQkFDUCxJQUFBdkMsV0FBQSxDQUFBc0IsR0FBQSxFQUFDL0IsSUFBQSxDQUFBaUQsSUFBSTtZQUNIRCxJQUFJLEVBQUV2QixHQUFHLENBQUN1QixJQUFLO1lBQ2ZoQixTQUFTLEVBQUMsWUFBWTtZQUN0QmtCLE9BQU8sRUFBRSxJQUFBQyxtQ0FBaUIsRUFBQ04sTUFBTSxFQUFFO2NBQUVPLEdBQUcsRUFBRTNCLEdBQUcsQ0FBQzJCLEdBQUc7Y0FBRUosSUFBSSxFQUFFdkIsR0FBRyxDQUFDdUIsSUFBSTtjQUFFTDtZQUFLLENBQUMsQ0FBRTtZQUFBVixRQUFBLEVBRTFFUTtVQUFLLENBQ0YsQ0FBQztVQUFBO1VBRVA7VUFDQTtVQUNBLElBQUFoQyxXQUFBLENBQUFzQixHQUFBO1lBQU1DLFNBQVMsRUFBQyxhQUFhO1lBQUFDLFFBQUEsRUFBRVE7VUFBSyxDQUFPLENBQzVDLEVBQ0FBLEtBQUssS0FBS2hCLEdBQUcsQ0FBQ1IsSUFBSSxnQkFBRyxJQUFBUixXQUFBLENBQUFzQixHQUFBO1lBQU1DLFNBQVMsRUFBQyxZQUFZO1lBQUFDLFFBQUEsRUFBRVIsR0FBRyxDQUFDUjtVQUFJLENBQU8sQ0FBQyxHQUFHLElBQUk7UUFBQSxDQUN2RSxDQUFDO01BQUEsQ0FDSjtJQUFDLENBQ0osQ0FBQyxFQUNKdUIsSUFBSSxDQUFDTixLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUNDLEdBQUcsQ0FBRWtCLENBQUMsaUJBQ25CLElBQUE1QyxXQUFBLENBQUFzQixHQUFBLEVBQUNQLElBQUk7TUFBU0MsR0FBRyxFQUFFQSxHQUFJO01BQUNDLEdBQUcsRUFBRTJCO0lBQUUsR0FBcEJBLENBQXNCLENBQ2xDLENBQUM7RUFBQSxDQUNBLENBQUM7QUFFVDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFYQTNDLEVBQUEsQ0F2Q1M2QixHQUFHO0VBQUEsUUFFR0ssd0JBQVcsRUFDVEUsNEJBQWE7QUFBQTtBQUFBUSxHQUFBLEdBSHJCZixHQUFHO0FBbURHLFNBQVNnQixhQUFhQSxDQUFDO0VBQUVDLElBQUk7RUFBRUMsS0FBSztFQUFFQyxPQUFPO0VBQUVDLElBQUksR0FBRyxNQUFNO0VBQUVDO0FBQWMsQ0FBQyxFQUFFO0VBQUFoRCxHQUFBO0VBQzVGLE1BQU1pRCxRQUFRLEdBQUcsSUFBQWpCLHdCQUFXLEVBQUMsQ0FBQztFQUM5QjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsTUFBTWtCLE9BQU8sR0FBRyxTQUFTLENBQUNDLElBQUksQ0FBQ0YsUUFBUSxDQUFDLEdBQUdBLFFBQVEsQ0FBQzNCLEtBQUssQ0FBQyxDQUFDLEVBQUUyQixRQUFRLENBQUNHLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHSCxRQUFRO0VBQ2xHLE1BQU1JLE1BQU0sR0FBRyxJQUFBQyx3QkFBYSxFQUFDVixJQUFJLEVBQUVNLE9BQU8sQ0FBQztFQUUzQyxNQUFNSyxPQUFPLEdBQUcsSUFBQUMsd0NBQW1CLEVBQUNILE1BQU0sQ0FBQztFQUMzQyxNQUFNSSxRQUFRLEdBQUcsSUFBQUMsbUJBQWMsRUFBQyxDQUF3QjtFQUV4RCxJQUFJSCxPQUFPLENBQUM5QyxNQUFNLEtBQUssT0FBTyxFQUFFO0lBQzlCLG9CQUNFLElBQUFaLFdBQUEsQ0FBQXNCLEdBQUE7TUFBS0MsU0FBUyxFQUFDLGVBQWU7TUFBQyxjQUFZbUMsT0FBTyxDQUFDOUMsTUFBTztNQUFBWSxRQUFBLGVBQ3hELElBQUF4QixXQUFBLENBQUFzQixHQUFBO1FBQUtDLFNBQVMsRUFBQyxZQUFZO1FBQUN1QyxLQUFLLEVBQUU7VUFBRUMsS0FBSyxFQUFFO1FBQU07TUFBRSxDQUFFO0lBQUMsQ0FDcEQsQ0FBQztFQUVWO0VBRUEsTUFBTUMsSUFBSSxHQUFHLElBQUFDLDZCQUFrQixFQUFDVCxNQUFNLEVBQUVFLE9BQU8sQ0FBQ1EsT0FBTyxFQUFFTixRQUFRLEVBQUU7SUFDakVULE1BQU0sRUFBRXRDLElBQUksQ0FBQ3NDLE1BQU0sQ0FBQztJQUNwQkQ7RUFDRixDQUFDLENBQUM7RUFDRixNQUFNbkIsSUFBSSxHQUFHLElBQUFvQyx5QkFBYyxFQUFDSCxJQUFJLEVBQUUsSUFBQUksdUJBQVksRUFBQ25CLE9BQU8sQ0FBQyxDQUFDO0VBRXhELG9CQUNFLElBQUFqRCxXQUFBLENBQUE0QixJQUFBO0lBQUtMLFNBQVMsRUFBQyxlQUFlO0lBQUFDLFFBQUEsR0FDM0J3QixLQUFLLGdCQUNKLElBQUFoRCxXQUFBLENBQUE0QixJQUFBO01BQUtMLFNBQVMsRUFBQyxxQkFBcUI7TUFBQUMsUUFBQSxnQkFDbEMsSUFBQXhCLFdBQUEsQ0FBQXNCLEdBQUE7UUFBQUUsUUFBQSxFQUFLd0I7TUFBSyxDQUFLLENBQUMsZUFDaEIsSUFBQWhELFdBQUEsQ0FBQTRCLElBQUE7UUFBTUwsU0FBUyxFQUFDLEdBQUc7UUFBQUMsUUFBQSxHQUNoQndDLElBQUksQ0FBQ0ssTUFBTSxFQUFDLEdBQUMsRUFBQ0wsSUFBSSxDQUFDSyxNQUFNLEtBQUssQ0FBQyxHQUFHLE1BQU0sR0FBRyxPQUFPO01BQUEsQ0FDL0MsQ0FBQztJQUFBLENBQ0osQ0FBQyxHQUNKLElBQUksRUFDUEwsSUFBSSxDQUFDSyxNQUFNLEtBQUssQ0FBQztJQUFBO0lBQ2hCO0lBQ0E7SUFDQTtJQUNBO0lBQ0EsSUFBQXJFLFdBQUEsQ0FBQTRCLElBQUE7TUFBS0wsU0FBUyxFQUFDLHNCQUFzQjtNQUFBQyxRQUFBLGdCQUNuQyxJQUFBeEIsV0FBQSxDQUFBc0IsR0FBQTtRQUFNQyxTQUFTLEVBQUMsWUFBWTtRQUFDLGVBQVksTUFBTTtRQUFBQyxRQUFBLGVBQzdDLElBQUF4QixXQUFBLENBQUFzQixHQUFBLEVBQUN4QixLQUFBLENBQUFRLE9BQUk7VUFBQ0UsSUFBSSxFQUFDO1FBQVEsQ0FBRTtNQUFDLENBQ2xCLENBQUMsZUFDUCxJQUFBUixXQUFBLENBQUFzQixHQUFBO1FBQUdDLFNBQVMsRUFBQyx3QkFBd0I7UUFBQUMsUUFBQSxFQUNsQ2tDLE9BQU8sQ0FBQ1EsT0FBTyxDQUFDRyxNQUFNLEtBQUssQ0FBQyxHQUFHLHVCQUF1QixHQUFHO01BQWlDLENBQzFGLENBQUMsZUFDSixJQUFBckUsV0FBQSxDQUFBc0IsR0FBQTtRQUFHQyxTQUFTLEVBQUMsd0JBQXdCO1FBQUFDLFFBQUEsRUFDbENrQyxPQUFPLENBQUNRLE9BQU8sQ0FBQ0csTUFBTSxLQUFLLENBQUMsR0FDekIsMkNBQTJDLEdBQzNDLDZDQUE2Q1gsT0FBTyxDQUFDUSxPQUFPLENBQUNHLE1BQU0sSUFBSVgsT0FBTyxDQUFDUSxPQUFPLENBQUNHLE1BQU0sS0FBSyxDQUFDLEdBQUcsTUFBTSxHQUFHLE9BQU87TUFBVyxDQUNwSSxDQUFDO0lBQUEsQ0FDRCxDQUFDLGdCQUVOLElBQUFyRSxXQUFBLENBQUFzQixHQUFBO01BQUtDLFNBQVMsRUFBQyxrQkFBa0I7TUFBQUMsUUFBQSxlQUMvQixJQUFBeEIsV0FBQSxDQUFBNEIsSUFBQTtRQUFPTCxTQUFTLEVBQUMsa0NBQWtDO1FBQUFDLFFBQUEsZ0JBQ2pELElBQUF4QixXQUFBLENBQUFzQixHQUFBO1VBQUFFLFFBQUEsZUFDRSxJQUFBeEIsV0FBQSxDQUFBc0IsR0FBQTtZQUFBRSxRQUFBLEVBQ0dPLElBQUksQ0FBQ0wsR0FBRyxDQUFFa0IsQ0FBQyxpQkFDVixJQUFBNUMsV0FBQSxDQUFBc0IsR0FBQTtjQUFZZ0QsS0FBSyxFQUFDLEtBQUs7Y0FBQy9DLFNBQVMsRUFBRSxzQkFBc0JxQixDQUFDLEVBQUc7Y0FBQXBCLFFBQUEsRUFDMURqQixRQUFRLENBQUNxQyxDQUFDO1lBQUMsR0FETEEsQ0FFTCxDQUNMO1VBQUMsQ0FDQTtRQUFDLENBQ0EsQ0FBQyxlQUNSLElBQUE1QyxXQUFBLENBQUFzQixHQUFBO1VBQUFFLFFBQUEsRUFDR3dDLElBQUksQ0FBQ3RDLEdBQUcsQ0FBRTZDLENBQUMsaUJBQ1YsSUFBQXZFLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ1EsR0FBRztZQUFhZCxHQUFHLEVBQUV1RCxDQUFFO1lBQUN4QyxJQUFJLEVBQUVBO1VBQUssR0FBMUJ3QyxDQUFDLENBQUM1QixHQUEwQixDQUN2QztRQUFDLENBQ0csQ0FBQztNQUFBLENBQ0g7SUFBQyxDQUNMLENBQ047RUFBQSxDQUNFLENBQUM7QUFFVjtBQUFDeEMsR0FBQSxDQTdFdUIyQyxhQUFhO0VBQUEsUUFDbEJYLHdCQUFXLEVBU1p3Qix3Q0FBbUIsRUFDbEJFLG1CQUFjO0FBQUE7QUFBQVcsR0FBQSxHQVhUMUIsYUFBYTtBQUFBLElBQUFqQixFQUFBLEVBQUFnQixHQUFBLEVBQUEyQixHQUFBO0FBQUFDLFlBQUEsQ0FBQTVDLEVBQUE7QUFBQTRDLFlBQUEsQ0FBQTVCLEdBQUE7QUFBQTRCLFlBQUEsQ0FBQUQsR0FBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}