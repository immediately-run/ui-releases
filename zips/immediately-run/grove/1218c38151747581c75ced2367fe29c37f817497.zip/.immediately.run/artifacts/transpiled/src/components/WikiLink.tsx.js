var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = WikiLink;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.find.js");
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
var _content = require("../lib/content");
var _directory = require("../lib/directory");
var _wiki = require("../lib/wiki");
var _useEntryKey = require("../hooks/useEntryKey");
var _useFollowLink = require("../hooks/useFollowLink");
var _navigationPolicy = require("../lib/navigationPolicy");
var _Icon = _interopRequireDefault(require("./Icon"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$();
/* eslint-disable @typescript-eslint/no-explicit-any */
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// The MDX `a` override. A link into the content space renders as a wiki-link with one of
// three states (brief 00) — resolved / broken / self; an external scheme or a bare
// `#anchor` renders as an ordinary markdown link, so the two are distinguishable at a
// glance. Those are the ONLY two shapes: an in-app href that resolves to nothing renders
// broken, never as a bare `<a>` (see `linkKind` — R3-252).
function WikiLink({
  href = '',
  children,
  ...rest
}) {
  _s();
  // R3-871: the entry this link renders inside, not whatever the URL says.
  const currentKey = (0, _useEntryKey.useEntryKey)();
  // R3-872: plain clicks ride the navigation policy; the href stays real.
  const follow = (0, _useFollowLink.useFollowLink)();

  // Resolve existence against the whole in-memory index (so a missing target is
  // *definitively* broken, not a load-time flash).
  const allKeysQuery = (0, _react.useCallback)(fm => Object.keys(fm).filter(_content.isContentEntry), []);
  const q = (0, _sdk.useMetadataQuery)(allKeysQuery);
  const keys = (0, _wiki.queryPaths)(q);
  const loaded = keys.length > 0;

  // Normalize an in-app content href to its canonical metadata key; null for
  // external/anchor links. Handles the ABSOLUTE forms (`/content/x.mdx`,
  // `/files/content/x.mdx`) and the RELATIVE form an author actually writes
  // (`roadmap/index.mdx`, `../specs/FOO.mdx`), which is resolved against the current
  // entry the same way `check-docs-wiki` resolves `[[…]]` links. A relative href used
  // to land here as `null` and render as a bare `<a>`, so clicking it made the sandbox
  // perform a real navigation instead of routing — the "Failed to construct 'URL'"
  // crash. Candidates are tried in order so a pre-cutover `foo.md` still finds `foo.mdx`
  // even though the corpus itself no longer carries those names.
  const candidates = (0, _content.hrefKeyCandidates)(href, currentKey);
  const targetKey = candidates.find(k => keys.includes(k)) ?? candidates[0] ?? null;
  // Route on the RESOLVED key, not the author's text: handing `<Link>` a relative href
  // would make it resolve against the outer page URL rather than the content tree.
  const [, fragmentRaw] = (0, _content.splitFragment)(href);
  // `fragmentRaw` keeps the '#' for the hrefs (they concatenate it); the policy
  // target carries the bare id (the FollowLinkTarget shape and
  // resolveFragmentTarget's convention agree — never '#' + id).
  const fragment = fragmentRaw || '';
  const policyFragment = fragmentRaw ? fragmentRaw.replace(/^#/, '') : undefined;
  const resolvedHref = targetKey ? (0, _content.keyToHref)(targetKey) + fragment : href;

  // Only an href that MEANS to leave the document becomes a real `<a>` — see `linkKind`.
  // An unresolvable in-app href renders broken rather than falling through to an anchor
  // that would navigate the sandboxed frame away and kill the app (R3-252).
  if (!targetKey) {
    const kind = (0, _content.linkKind)(href);
    // A FOLDER is a destination too, since directory listings landed: `[the
    // handbook](handbook)` names something real, and the extension test that decides
    // what an *entry* is would otherwise call it broken. Judged from the index (no fs
    // call per link) — see `isFolderKey` for what that trades away.
    const dirKey = kind === 'content' ? (0, _content.hrefTargetKey)(href, currentKey) : null;
    if (dirKey && loaded && (0, _directory.isFolderKey)(dirKey, keys)) {
      return /*#__PURE__*/(0, _jsxRuntime.jsx)(_sdk.Link, {
        href: (0, _content.keyToHref)(dirKey) + fragment,
        className: "grove-wikilink",
        "data-state": "ok",
        onClick: (0, _navigationPolicy.followLinkOnClick)(follow, {
          key: dirKey,
          fragment: policyFragment,
          href: (0, _content.keyToHref)(dirKey) + fragment,
          from: currentKey
        }),
        ...rest,
        children: children
      });
    }
    if (kind !== 'content') {
      const web = /^https?:/i.test(href);
      return /*#__PURE__*/(0, _jsxRuntime.jsx)("a", {
        className: "mdlink",
        href: href,
        ...(web ? {
          target: '_blank',
          rel: 'noreferrer'
        } : {}),
        ...rest,
        children: children
      });
    }
    return /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
      className: "grove-wikilink",
      "data-state": "broken",
      title: `No entry at ${href}`,
      "aria-label": `No entry at ${href}`,
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
        name: "unlink"
      }), children]
    });
  }
  if (targetKey === currentKey) {
    return /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
      className: "grove-wikilink",
      "data-state": "self",
      children: children
    });
  }
  const exists = !loaded || keys.includes(targetKey); // optimistic until loaded
  if (!exists) {
    return /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
      className: "grove-wikilink",
      "data-state": "broken",
      title: `No entry at ${href}`,
      "aria-label": `No entry at ${href}`,
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
        name: "unlink"
      }), children]
    });
  }
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_sdk.Link, {
    href: resolvedHref,
    className: "grove-wikilink",
    "data-state": "ok",
    onClick: (0, _navigationPolicy.followLinkOnClick)(follow, {
      key: targetKey,
      fragment: policyFragment,
      href: resolvedHref,
      from: currentKey
    }),
    ...rest,
    children: children
  });
}
_s(WikiLink, "LT6DKPoHrrJPgsCyP/1CQXscNUU=", false, function () {
  return [_useEntryKey.useEntryKey, _useFollowLink.useFollowLink, _sdk.useMetadataQuery];
});
_c = WikiLink;
var _c;
$RefreshReg$(_c, "WikiLink");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NkayIsIl9jb250ZW50IiwiX2RpcmVjdG9yeSIsIl93aWtpIiwiX3VzZUVudHJ5S2V5IiwiX3VzZUZvbGxvd0xpbmsiLCJfbmF2aWdhdGlvblBvbGljeSIsIl9JY29uIiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsIl9qc3hSdW50aW1lIiwiX3MiLCIkUmVmcmVzaFNpZyQiLCJlIiwiX19lc01vZHVsZSIsImRlZmF1bHQiLCJXaWtpTGluayIsImhyZWYiLCJjaGlsZHJlbiIsInJlc3QiLCJjdXJyZW50S2V5IiwidXNlRW50cnlLZXkiLCJmb2xsb3ciLCJ1c2VGb2xsb3dMaW5rIiwiYWxsS2V5c1F1ZXJ5IiwidXNlQ2FsbGJhY2siLCJmbSIsIk9iamVjdCIsImtleXMiLCJmaWx0ZXIiLCJpc0NvbnRlbnRFbnRyeSIsInEiLCJ1c2VNZXRhZGF0YVF1ZXJ5IiwicXVlcnlQYXRocyIsImxvYWRlZCIsImxlbmd0aCIsImNhbmRpZGF0ZXMiLCJocmVmS2V5Q2FuZGlkYXRlcyIsInRhcmdldEtleSIsImZpbmQiLCJrIiwiaW5jbHVkZXMiLCJmcmFnbWVudFJhdyIsInNwbGl0RnJhZ21lbnQiLCJmcmFnbWVudCIsInBvbGljeUZyYWdtZW50IiwicmVwbGFjZSIsInVuZGVmaW5lZCIsInJlc29sdmVkSHJlZiIsImtleVRvSHJlZiIsImtpbmQiLCJsaW5rS2luZCIsImRpcktleSIsImhyZWZUYXJnZXRLZXkiLCJpc0ZvbGRlcktleSIsImpzeCIsIkxpbmsiLCJjbGFzc05hbWUiLCJvbkNsaWNrIiwiZm9sbG93TGlua09uQ2xpY2siLCJrZXkiLCJmcm9tIiwid2ViIiwidGVzdCIsInRhcmdldCIsInJlbCIsImpzeHMiLCJ0aXRsZSIsIm5hbWUiLCJleGlzdHMiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIldpa2lMaW5rLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55ICovXG5pbXBvcnQgeyB1c2VDYWxsYmFjayB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IExpbmssIHVzZU1ldGFkYXRhUXVlcnkgfSBmcm9tICdAaW1tZWRpYXRlbHktcnVuL3Nkayc7XG5pbXBvcnQgeyBocmVmS2V5Q2FuZGlkYXRlcywgaHJlZlRhcmdldEtleSwgaXNDb250ZW50RW50cnksIGtleVRvSHJlZiwgbGlua0tpbmQsIHNwbGl0RnJhZ21lbnQgfSBmcm9tICcuLi9saWIvY29udGVudCc7XG5pbXBvcnQgeyBpc0ZvbGRlcktleSB9IGZyb20gJy4uL2xpYi9kaXJlY3RvcnknO1xuaW1wb3J0IHsgcXVlcnlQYXRocyB9IGZyb20gJy4uL2xpYi93aWtpJztcbmltcG9ydCB7IHVzZUVudHJ5S2V5IH0gZnJvbSAnLi4vaG9va3MvdXNlRW50cnlLZXknO1xuaW1wb3J0IHsgdXNlRm9sbG93TGluayB9IGZyb20gJy4uL2hvb2tzL3VzZUZvbGxvd0xpbmsnO1xuaW1wb3J0IHsgZm9sbG93TGlua09uQ2xpY2sgfSBmcm9tICcuLi9saWIvbmF2aWdhdGlvblBvbGljeSc7XG5pbXBvcnQgSWNvbiBmcm9tICcuL0ljb24nO1xuXG5pbnRlcmZhY2UgUHJvcHMge1xuICBocmVmPzogc3RyaW5nO1xuICBjaGlsZHJlbj86IFJlYWN0LlJlYWN0Tm9kZTtcbiAgY2xhc3NOYW1lPzogc3RyaW5nO1xufVxuXG4vLyBUaGUgTURYIGBhYCBvdmVycmlkZS4gQSBsaW5rIGludG8gdGhlIGNvbnRlbnQgc3BhY2UgcmVuZGVycyBhcyBhIHdpa2ktbGluayB3aXRoIG9uZSBvZlxuLy8gdGhyZWUgc3RhdGVzIChicmllZiAwMCkg4oCUIHJlc29sdmVkIC8gYnJva2VuIC8gc2VsZjsgYW4gZXh0ZXJuYWwgc2NoZW1lIG9yIGEgYmFyZVxuLy8gYCNhbmNob3JgIHJlbmRlcnMgYXMgYW4gb3JkaW5hcnkgbWFya2Rvd24gbGluaywgc28gdGhlIHR3byBhcmUgZGlzdGluZ3Vpc2hhYmxlIGF0IGFcbi8vIGdsYW5jZS4gVGhvc2UgYXJlIHRoZSBPTkxZIHR3byBzaGFwZXM6IGFuIGluLWFwcCBocmVmIHRoYXQgcmVzb2x2ZXMgdG8gbm90aGluZyByZW5kZXJzXG4vLyBicm9rZW4sIG5ldmVyIGFzIGEgYmFyZSBgPGE+YCAoc2VlIGBsaW5rS2luZGAg4oCUIFIzLTI1MikuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBXaWtpTGluayh7IGhyZWYgPSAnJywgY2hpbGRyZW4sIC4uLnJlc3QgfTogUHJvcHMpIHtcbiAgLy8gUjMtODcxOiB0aGUgZW50cnkgdGhpcyBsaW5rIHJlbmRlcnMgaW5zaWRlLCBub3Qgd2hhdGV2ZXIgdGhlIFVSTCBzYXlzLlxuICBjb25zdCBjdXJyZW50S2V5ID0gdXNlRW50cnlLZXkoKTtcbiAgLy8gUjMtODcyOiBwbGFpbiBjbGlja3MgcmlkZSB0aGUgbmF2aWdhdGlvbiBwb2xpY3k7IHRoZSBocmVmIHN0YXlzIHJlYWwuXG4gIGNvbnN0IGZvbGxvdyA9IHVzZUZvbGxvd0xpbmsoKTtcblxuICAvLyBSZXNvbHZlIGV4aXN0ZW5jZSBhZ2FpbnN0IHRoZSB3aG9sZSBpbi1tZW1vcnkgaW5kZXggKHNvIGEgbWlzc2luZyB0YXJnZXQgaXNcbiAgLy8gKmRlZmluaXRpdmVseSogYnJva2VuLCBub3QgYSBsb2FkLXRpbWUgZmxhc2gpLlxuICBjb25zdCBhbGxLZXlzUXVlcnkgPSB1c2VDYWxsYmFjayhcbiAgICAoZm06IFJlY29yZDxzdHJpbmcsIGFueT4pID0+IE9iamVjdC5rZXlzKGZtKS5maWx0ZXIoaXNDb250ZW50RW50cnkpLFxuICAgIFtdXG4gICk7XG4gIGNvbnN0IHEgPSB1c2VNZXRhZGF0YVF1ZXJ5KGFsbEtleXNRdWVyeSk7XG4gIGNvbnN0IGtleXM6IHN0cmluZ1tdID0gcXVlcnlQYXRocyhxKTtcbiAgY29uc3QgbG9hZGVkID0ga2V5cy5sZW5ndGggPiAwO1xuXG4gIC8vIE5vcm1hbGl6ZSBhbiBpbi1hcHAgY29udGVudCBocmVmIHRvIGl0cyBjYW5vbmljYWwgbWV0YWRhdGEga2V5OyBudWxsIGZvclxuICAvLyBleHRlcm5hbC9hbmNob3IgbGlua3MuIEhhbmRsZXMgdGhlIEFCU09MVVRFIGZvcm1zIChgL2NvbnRlbnQveC5tZHhgLFxuICAvLyBgL2ZpbGVzL2NvbnRlbnQveC5tZHhgKSBhbmQgdGhlIFJFTEFUSVZFIGZvcm0gYW4gYXV0aG9yIGFjdHVhbGx5IHdyaXRlc1xuICAvLyAoYHJvYWRtYXAvaW5kZXgubWR4YCwgYC4uL3NwZWNzL0ZPTy5tZHhgKSwgd2hpY2ggaXMgcmVzb2x2ZWQgYWdhaW5zdCB0aGUgY3VycmVudFxuICAvLyBlbnRyeSB0aGUgc2FtZSB3YXkgYGNoZWNrLWRvY3Mtd2lraWAgcmVzb2x2ZXMgYFtb4oCmXV1gIGxpbmtzLiBBIHJlbGF0aXZlIGhyZWYgdXNlZFxuICAvLyB0byBsYW5kIGhlcmUgYXMgYG51bGxgIGFuZCByZW5kZXIgYXMgYSBiYXJlIGA8YT5gLCBzbyBjbGlja2luZyBpdCBtYWRlIHRoZSBzYW5kYm94XG4gIC8vIHBlcmZvcm0gYSByZWFsIG5hdmlnYXRpb24gaW5zdGVhZCBvZiByb3V0aW5nIOKAlCB0aGUgXCJGYWlsZWQgdG8gY29uc3RydWN0ICdVUkwnXCJcbiAgLy8gY3Jhc2guIENhbmRpZGF0ZXMgYXJlIHRyaWVkIGluIG9yZGVyIHNvIGEgcHJlLWN1dG92ZXIgYGZvby5tZGAgc3RpbGwgZmluZHMgYGZvby5tZHhgXG4gIC8vIGV2ZW4gdGhvdWdoIHRoZSBjb3JwdXMgaXRzZWxmIG5vIGxvbmdlciBjYXJyaWVzIHRob3NlIG5hbWVzLlxuICBjb25zdCBjYW5kaWRhdGVzID0gaHJlZktleUNhbmRpZGF0ZXMoaHJlZiwgY3VycmVudEtleSk7XG4gIGNvbnN0IHRhcmdldEtleSA9IGNhbmRpZGF0ZXMuZmluZCgoaykgPT4ga2V5cy5pbmNsdWRlcyhrKSkgPz8gY2FuZGlkYXRlc1swXSA/PyBudWxsO1xuICAvLyBSb3V0ZSBvbiB0aGUgUkVTT0xWRUQga2V5LCBub3QgdGhlIGF1dGhvcidzIHRleHQ6IGhhbmRpbmcgYDxMaW5rPmAgYSByZWxhdGl2ZSBocmVmXG4gIC8vIHdvdWxkIG1ha2UgaXQgcmVzb2x2ZSBhZ2FpbnN0IHRoZSBvdXRlciBwYWdlIFVSTCByYXRoZXIgdGhhbiB0aGUgY29udGVudCB0cmVlLlxuICBjb25zdCBbLCBmcmFnbWVudFJhd10gPSBzcGxpdEZyYWdtZW50KGhyZWYpO1xuICAvLyBgZnJhZ21lbnRSYXdgIGtlZXBzIHRoZSAnIycgZm9yIHRoZSBocmVmcyAodGhleSBjb25jYXRlbmF0ZSBpdCk7IHRoZSBwb2xpY3lcbiAgLy8gdGFyZ2V0IGNhcnJpZXMgdGhlIGJhcmUgaWQgKHRoZSBGb2xsb3dMaW5rVGFyZ2V0IHNoYXBlIGFuZFxuICAvLyByZXNvbHZlRnJhZ21lbnRUYXJnZXQncyBjb252ZW50aW9uIGFncmVlIOKAlCBuZXZlciAnIycgKyBpZCkuXG4gIGNvbnN0IGZyYWdtZW50ID0gZnJhZ21lbnRSYXcgfHwgJyc7XG4gIGNvbnN0IHBvbGljeUZyYWdtZW50ID0gZnJhZ21lbnRSYXcgPyBmcmFnbWVudFJhdy5yZXBsYWNlKC9eIy8sICcnKSA6IHVuZGVmaW5lZDtcbiAgY29uc3QgcmVzb2x2ZWRIcmVmID0gdGFyZ2V0S2V5ID8ga2V5VG9IcmVmKHRhcmdldEtleSkgKyBmcmFnbWVudCA6IGhyZWY7XG5cbiAgLy8gT25seSBhbiBocmVmIHRoYXQgTUVBTlMgdG8gbGVhdmUgdGhlIGRvY3VtZW50IGJlY29tZXMgYSByZWFsIGA8YT5gIOKAlCBzZWUgYGxpbmtLaW5kYC5cbiAgLy8gQW4gdW5yZXNvbHZhYmxlIGluLWFwcCBocmVmIHJlbmRlcnMgYnJva2VuIHJhdGhlciB0aGFuIGZhbGxpbmcgdGhyb3VnaCB0byBhbiBhbmNob3JcbiAgLy8gdGhhdCB3b3VsZCBuYXZpZ2F0ZSB0aGUgc2FuZGJveGVkIGZyYW1lIGF3YXkgYW5kIGtpbGwgdGhlIGFwcCAoUjMtMjUyKS5cbiAgaWYgKCF0YXJnZXRLZXkpIHtcbiAgICBjb25zdCBraW5kID0gbGlua0tpbmQoaHJlZik7XG4gICAgLy8gQSBGT0xERVIgaXMgYSBkZXN0aW5hdGlvbiB0b28sIHNpbmNlIGRpcmVjdG9yeSBsaXN0aW5ncyBsYW5kZWQ6IGBbdGhlXG4gICAgLy8gaGFuZGJvb2tdKGhhbmRib29rKWAgbmFtZXMgc29tZXRoaW5nIHJlYWwsIGFuZCB0aGUgZXh0ZW5zaW9uIHRlc3QgdGhhdCBkZWNpZGVzXG4gICAgLy8gd2hhdCBhbiAqZW50cnkqIGlzIHdvdWxkIG90aGVyd2lzZSBjYWxsIGl0IGJyb2tlbi4gSnVkZ2VkIGZyb20gdGhlIGluZGV4IChubyBmc1xuICAgIC8vIGNhbGwgcGVyIGxpbmspIOKAlCBzZWUgYGlzRm9sZGVyS2V5YCBmb3Igd2hhdCB0aGF0IHRyYWRlcyBhd2F5LlxuICAgIGNvbnN0IGRpcktleSA9IGtpbmQgPT09ICdjb250ZW50JyA/IGhyZWZUYXJnZXRLZXkoaHJlZiwgY3VycmVudEtleSkgOiBudWxsO1xuICAgIGlmIChkaXJLZXkgJiYgbG9hZGVkICYmIGlzRm9sZGVyS2V5KGRpcktleSwga2V5cykpIHtcbiAgICAgIHJldHVybiAoXG4gICAgICAgIDxMaW5rXG4gICAgICAgICAgaHJlZj17a2V5VG9IcmVmKGRpcktleSkgKyBmcmFnbWVudH1cbiAgICAgICAgICBjbGFzc05hbWU9XCJncm92ZS13aWtpbGlua1wiXG4gICAgICAgICAgZGF0YS1zdGF0ZT1cIm9rXCJcbiAgICAgICAgICBvbkNsaWNrPXtmb2xsb3dMaW5rT25DbGljayhmb2xsb3csIHsga2V5OiBkaXJLZXksIGZyYWdtZW50OiBwb2xpY3lGcmFnbWVudCwgaHJlZjoga2V5VG9IcmVmKGRpcktleSkgKyBmcmFnbWVudCwgZnJvbTogY3VycmVudEtleSB9KX1cbiAgICAgICAgICB7Li4ucmVzdH1cbiAgICAgICAgPlxuICAgICAgICAgIHtjaGlsZHJlbn1cbiAgICAgICAgPC9MaW5rPlxuICAgICAgKTtcbiAgICB9XG4gICAgaWYgKGtpbmQgIT09ICdjb250ZW50Jykge1xuICAgICAgY29uc3Qgd2ViID0gL15odHRwcz86L2kudGVzdChocmVmKTtcbiAgICAgIHJldHVybiAoXG4gICAgICAgIDxhXG4gICAgICAgICAgY2xhc3NOYW1lPVwibWRsaW5rXCJcbiAgICAgICAgICBocmVmPXtocmVmfVxuICAgICAgICAgIHsuLi4od2ViID8geyB0YXJnZXQ6ICdfYmxhbmsnLCByZWw6ICdub3JlZmVycmVyJyB9IDoge30pfVxuICAgICAgICAgIHsuLi5yZXN0fVxuICAgICAgICA+XG4gICAgICAgICAge2NoaWxkcmVufVxuICAgICAgICA8L2E+XG4gICAgICApO1xuICAgIH1cbiAgICByZXR1cm4gKFxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZ3JvdmUtd2lraWxpbmtcIiBkYXRhLXN0YXRlPVwiYnJva2VuXCIgdGl0bGU9e2BObyBlbnRyeSBhdCAke2hyZWZ9YH0gYXJpYS1sYWJlbD17YE5vIGVudHJ5IGF0ICR7aHJlZn1gfT5cbiAgICAgICAgPEljb24gbmFtZT1cInVubGlua1wiIC8+XG4gICAgICAgIHtjaGlsZHJlbn1cbiAgICAgIDwvc3Bhbj5cbiAgICApO1xuICB9XG5cbiAgaWYgKHRhcmdldEtleSA9PT0gY3VycmVudEtleSkge1xuICAgIHJldHVybiAoXG4gICAgICA8c3BhbiBjbGFzc05hbWU9XCJncm92ZS13aWtpbGlua1wiIGRhdGEtc3RhdGU9XCJzZWxmXCI+XG4gICAgICAgIHtjaGlsZHJlbn1cbiAgICAgIDwvc3Bhbj5cbiAgICApO1xuICB9XG5cbiAgY29uc3QgZXhpc3RzID0gIWxvYWRlZCB8fCBrZXlzLmluY2x1ZGVzKHRhcmdldEtleSk7IC8vIG9wdGltaXN0aWMgdW50aWwgbG9hZGVkXG4gIGlmICghZXhpc3RzKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImdyb3ZlLXdpa2lsaW5rXCIgZGF0YS1zdGF0ZT1cImJyb2tlblwiIHRpdGxlPXtgTm8gZW50cnkgYXQgJHtocmVmfWB9IGFyaWEtbGFiZWw9e2BObyBlbnRyeSBhdCAke2hyZWZ9YH0+XG4gICAgICAgIDxJY29uIG5hbWU9XCJ1bmxpbmtcIiAvPlxuICAgICAgICB7Y2hpbGRyZW59XG4gICAgICA8L3NwYW4+XG4gICAgKTtcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPExpbmtcbiAgICAgIGhyZWY9e3Jlc29sdmVkSHJlZn1cbiAgICAgIGNsYXNzTmFtZT1cImdyb3ZlLXdpa2lsaW5rXCJcbiAgICAgIGRhdGEtc3RhdGU9XCJva1wiXG4gICAgICBvbkNsaWNrPXtmb2xsb3dMaW5rT25DbGljayhmb2xsb3csIHsga2V5OiB0YXJnZXRLZXksIGZyYWdtZW50OiBwb2xpY3lGcmFnbWVudCwgaHJlZjogcmVzb2x2ZWRIcmVmLCBmcm9tOiBjdXJyZW50S2V5IH0pfVxuICAgICAgey4uLnJlc3R9XG4gICAgPlxuICAgICAge2NoaWxkcmVufVxuICAgIDwvTGluaz5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQ0EsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsSUFBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsUUFBQSxHQUFBRixPQUFBO0FBQ0EsSUFBQUcsVUFBQSxHQUFBSCxPQUFBO0FBQ0EsSUFBQUksS0FBQSxHQUFBSixPQUFBO0FBQ0EsSUFBQUssWUFBQSxHQUFBTCxPQUFBO0FBQ0EsSUFBQU0sY0FBQSxHQUFBTixPQUFBO0FBQ0EsSUFBQU8saUJBQUEsR0FBQVAsT0FBQTtBQUNBLElBQUFRLEtBQUEsR0FBQUMsc0JBQUEsQ0FBQVQsT0FBQTtBQUEwQixJQUFBVSxXQUFBLEdBQUFWLE9BQUE7QUFBQSxJQUFBVyxFQUFBLEdBQUFDLFlBQUE7QUFUMUI7QUFBQSxTQUFBSCx1QkFBQUksQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQWlCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ2UsU0FBU0csUUFBUUEsQ0FBQztFQUFFQyxJQUFJLEdBQUcsRUFBRTtFQUFFQyxRQUFRO0VBQUUsR0FBR0M7QUFBWSxDQUFDLEVBQUU7RUFBQVIsRUFBQTtFQUN4RTtFQUNBLE1BQU1TLFVBQVUsR0FBRyxJQUFBQyx3QkFBVyxFQUFDLENBQUM7RUFDaEM7RUFDQSxNQUFNQyxNQUFNLEdBQUcsSUFBQUMsNEJBQWEsRUFBQyxDQUFDOztFQUU5QjtFQUNBO0VBQ0EsTUFBTUMsWUFBWSxHQUFHLElBQUFDLGtCQUFXLEVBQzdCQyxFQUF1QixJQUFLQyxNQUFNLENBQUNDLElBQUksQ0FBQ0YsRUFBRSxDQUFDLENBQUNHLE1BQU0sQ0FBQ0MsdUJBQWMsQ0FBQyxFQUNuRSxFQUNGLENBQUM7RUFDRCxNQUFNQyxDQUFDLEdBQUcsSUFBQUMscUJBQWdCLEVBQUNSLFlBQVksQ0FBQztFQUN4QyxNQUFNSSxJQUFjLEdBQUcsSUFBQUssZ0JBQVUsRUFBQ0YsQ0FBQyxDQUFDO0VBQ3BDLE1BQU1HLE1BQU0sR0FBR04sSUFBSSxDQUFDTyxNQUFNLEdBQUcsQ0FBQzs7RUFFOUI7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsTUFBTUMsVUFBVSxHQUFHLElBQUFDLDBCQUFpQixFQUFDcEIsSUFBSSxFQUFFRyxVQUFVLENBQUM7RUFDdEQsTUFBTWtCLFNBQVMsR0FBR0YsVUFBVSxDQUFDRyxJQUFJLENBQUVDLENBQUMsSUFBS1osSUFBSSxDQUFDYSxRQUFRLENBQUNELENBQUMsQ0FBQyxDQUFDLElBQUlKLFVBQVUsQ0FBQyxDQUFDLENBQUMsSUFBSSxJQUFJO0VBQ25GO0VBQ0E7RUFDQSxNQUFNLEdBQUdNLFdBQVcsQ0FBQyxHQUFHLElBQUFDLHNCQUFhLEVBQUMxQixJQUFJLENBQUM7RUFDM0M7RUFDQTtFQUNBO0VBQ0EsTUFBTTJCLFFBQVEsR0FBR0YsV0FBVyxJQUFJLEVBQUU7RUFDbEMsTUFBTUcsY0FBYyxHQUFHSCxXQUFXLEdBQUdBLFdBQVcsQ0FBQ0ksT0FBTyxDQUFDLElBQUksRUFBRSxFQUFFLENBQUMsR0FBR0MsU0FBUztFQUM5RSxNQUFNQyxZQUFZLEdBQUdWLFNBQVMsR0FBRyxJQUFBVyxrQkFBUyxFQUFDWCxTQUFTLENBQUMsR0FBR00sUUFBUSxHQUFHM0IsSUFBSTs7RUFFdkU7RUFDQTtFQUNBO0VBQ0EsSUFBSSxDQUFDcUIsU0FBUyxFQUFFO0lBQ2QsTUFBTVksSUFBSSxHQUFHLElBQUFDLGlCQUFRLEVBQUNsQyxJQUFJLENBQUM7SUFDM0I7SUFDQTtJQUNBO0lBQ0E7SUFDQSxNQUFNbUMsTUFBTSxHQUFHRixJQUFJLEtBQUssU0FBUyxHQUFHLElBQUFHLHNCQUFhLEVBQUNwQyxJQUFJLEVBQUVHLFVBQVUsQ0FBQyxHQUFHLElBQUk7SUFDMUUsSUFBSWdDLE1BQU0sSUFBSWxCLE1BQU0sSUFBSSxJQUFBb0Isc0JBQVcsRUFBQ0YsTUFBTSxFQUFFeEIsSUFBSSxDQUFDLEVBQUU7TUFDakQsb0JBQ0UsSUFBQWxCLFdBQUEsQ0FBQTZDLEdBQUEsRUFBQ3RELElBQUEsQ0FBQXVELElBQUk7UUFDSHZDLElBQUksRUFBRSxJQUFBZ0Msa0JBQVMsRUFBQ0csTUFBTSxDQUFDLEdBQUdSLFFBQVM7UUFDbkNhLFNBQVMsRUFBQyxnQkFBZ0I7UUFDMUIsY0FBVyxJQUFJO1FBQ2ZDLE9BQU8sRUFBRSxJQUFBQyxtQ0FBaUIsRUFBQ3JDLE1BQU0sRUFBRTtVQUFFc0MsR0FBRyxFQUFFUixNQUFNO1VBQUVSLFFBQVEsRUFBRUMsY0FBYztVQUFFNUIsSUFBSSxFQUFFLElBQUFnQyxrQkFBUyxFQUFDRyxNQUFNLENBQUMsR0FBR1IsUUFBUTtVQUFFaUIsSUFBSSxFQUFFekM7UUFBVyxDQUFDLENBQUU7UUFBQSxHQUNoSUQsSUFBSTtRQUFBRCxRQUFBLEVBRVBBO01BQVEsQ0FDTCxDQUFDO0lBRVg7SUFDQSxJQUFJZ0MsSUFBSSxLQUFLLFNBQVMsRUFBRTtNQUN0QixNQUFNWSxHQUFHLEdBQUcsV0FBVyxDQUFDQyxJQUFJLENBQUM5QyxJQUFJLENBQUM7TUFDbEMsb0JBQ0UsSUFBQVAsV0FBQSxDQUFBNkMsR0FBQTtRQUNFRSxTQUFTLEVBQUMsUUFBUTtRQUNsQnhDLElBQUksRUFBRUEsSUFBSztRQUFBLElBQ042QyxHQUFHLEdBQUc7VUFBRUUsTUFBTSxFQUFFLFFBQVE7VUFBRUMsR0FBRyxFQUFFO1FBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUFBLEdBQ25EOUMsSUFBSTtRQUFBRCxRQUFBLEVBRVBBO01BQVEsQ0FDUixDQUFDO0lBRVI7SUFDQSxvQkFDRSxJQUFBUixXQUFBLENBQUF3RCxJQUFBO01BQU1ULFNBQVMsRUFBQyxnQkFBZ0I7TUFBQyxjQUFXLFFBQVE7TUFBQ1UsS0FBSyxFQUFFLGVBQWVsRCxJQUFJLEVBQUc7TUFBQyxjQUFZLGVBQWVBLElBQUksRUFBRztNQUFBQyxRQUFBLGdCQUNuSCxJQUFBUixXQUFBLENBQUE2QyxHQUFBLEVBQUMvQyxLQUFBLENBQUFPLE9BQUk7UUFBQ3FELElBQUksRUFBQztNQUFRLENBQUUsQ0FBQyxFQUNyQmxELFFBQVE7SUFBQSxDQUNMLENBQUM7RUFFWDtFQUVBLElBQUlvQixTQUFTLEtBQUtsQixVQUFVLEVBQUU7SUFDNUIsb0JBQ0UsSUFBQVYsV0FBQSxDQUFBNkMsR0FBQTtNQUFNRSxTQUFTLEVBQUMsZ0JBQWdCO01BQUMsY0FBVyxNQUFNO01BQUF2QyxRQUFBLEVBQy9DQTtJQUFRLENBQ0wsQ0FBQztFQUVYO0VBRUEsTUFBTW1ELE1BQU0sR0FBRyxDQUFDbkMsTUFBTSxJQUFJTixJQUFJLENBQUNhLFFBQVEsQ0FBQ0gsU0FBUyxDQUFDLENBQUMsQ0FBQztFQUNwRCxJQUFJLENBQUMrQixNQUFNLEVBQUU7SUFDWCxvQkFDRSxJQUFBM0QsV0FBQSxDQUFBd0QsSUFBQTtNQUFNVCxTQUFTLEVBQUMsZ0JBQWdCO01BQUMsY0FBVyxRQUFRO01BQUNVLEtBQUssRUFBRSxlQUFlbEQsSUFBSSxFQUFHO01BQUMsY0FBWSxlQUFlQSxJQUFJLEVBQUc7TUFBQUMsUUFBQSxnQkFDbkgsSUFBQVIsV0FBQSxDQUFBNkMsR0FBQSxFQUFDL0MsS0FBQSxDQUFBTyxPQUFJO1FBQUNxRCxJQUFJLEVBQUM7TUFBUSxDQUFFLENBQUMsRUFDckJsRCxRQUFRO0lBQUEsQ0FDTCxDQUFDO0VBRVg7RUFFQSxvQkFDRSxJQUFBUixXQUFBLENBQUE2QyxHQUFBLEVBQUN0RCxJQUFBLENBQUF1RCxJQUFJO0lBQ0h2QyxJQUFJLEVBQUUrQixZQUFhO0lBQ25CUyxTQUFTLEVBQUMsZ0JBQWdCO0lBQzFCLGNBQVcsSUFBSTtJQUNmQyxPQUFPLEVBQUUsSUFBQUMsbUNBQWlCLEVBQUNyQyxNQUFNLEVBQUU7TUFBRXNDLEdBQUcsRUFBRXRCLFNBQVM7TUFBRU0sUUFBUSxFQUFFQyxjQUFjO01BQUU1QixJQUFJLEVBQUUrQixZQUFZO01BQUVhLElBQUksRUFBRXpDO0lBQVcsQ0FBQyxDQUFFO0lBQUEsR0FDbkhELElBQUk7SUFBQUQsUUFBQSxFQUVQQTtFQUFRLENBQ0wsQ0FBQztBQUVYO0FBQUNQLEVBQUEsQ0E5R3VCSyxRQUFRO0VBQUEsUUFFWEssd0JBQVcsRUFFZkUsNEJBQWEsRUFRbEJTLHFCQUFnQjtBQUFBO0FBQUFzQyxFQUFBLEdBWkp0RCxRQUFRO0FBQUEsSUFBQXNELEVBQUE7QUFBQUMsWUFBQSxDQUFBRCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}