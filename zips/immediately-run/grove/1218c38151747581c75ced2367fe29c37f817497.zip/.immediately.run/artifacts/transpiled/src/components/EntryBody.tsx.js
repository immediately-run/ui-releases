var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = EntryBody;
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
var _shell = require("../lib/shell");
var _content = require("../lib/content");
var _layout = require("../lib/layout");
var _wiki = require("../lib/wiki");
var _renderMode = require("../lib/renderMode");
var _useEditAffordance = require("../hooks/useEditAffordance");
var _fs = _interopRequireDefault(require("fs"));
var _EntryHeader = _interopRequireDefault(require("./EntryHeader"));
var _SafeEntryBody = _interopRequireDefault(require("./SafeEntryBody"));
var _ScrollToFragment = _interopRequireDefault(require("./ScrollToFragment"));
var _Toc = _interopRequireDefault(require("./Toc"));
var _Backlinks = _interopRequireDefault(require("./Backlinks"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(),
  _s2 = $RefreshSig$(),
  _s3 = $RefreshSig$();
/* eslint-disable @typescript-eslint/no-explicit-any */
// `<EntryBody/>` — ONE entry's content region (R3-872, APP_CUSTOMIZATION §4.1):
// the header (with its edit affordance), the body on the safe or compiled path
// exactly as the stock page renders it, the metadata line and the tags. Carved
// out of PageView so `GroveEntry` (and any shell composing several entries on one
// page) renders the same thing the stock page does — there is one entry renderer.
//
// Reads the shell context NON-throwing (the stock page provides it; a bare
// library-mode composition does not) and derives anything missing from the
// entryKey itself — one derivation, two possible readers.
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
/** The reading-time minutes for one entry — read the body once per entry.
 *  `enabled` gates the read (hooks may not be conditional): the stock page's shell
 *  computes `mins` once already, and a second read per navigation is the
 *  double-read this flag exists to prevent (review round 1). */
function useReadingTimeMins(entryKey, enabled) {
  _s();
  const [mins, setMins] = (0, _react.useState)(0);
  (0, _react.useEffect)(() => {
    if (!enabled) return;
    let active = true;
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setMins(0);
    _fs.default.promises.readFile((0, _content.keyToFsPath)(entryKey), 'utf8').then(b => {
      if (active) setMins((0, _wiki.readingTime)((0, _wiki.stripFrontmatter)(String(b))));
    }).catch(() => undefined);
    return () => {
      active = false;
    };
  }, [entryKey, enabled]);
  return mins;
}
_s(useReadingTimeMins, "68cHGJb5xOCfvhGuaLrG+S5B34o=");
function EntryBody({
  entryKey
}) {
  _s2();
  const sh = (0, _react.useContext)(_shell.GroveShellContext);
  const meta = (0, _sdk.useFileMetadata)(entryKey);
  const homeMeta = (0, _sdk.useFileMetadata)((0, _content.homeKey)());
  // The shell's values win when present (the stock page derives them once);
  // standalone, the same expressions run here.
  const includePath = sh?.includePath ?? (0, _content.keyToInclude)(entryKey);
  const layout = sh?.layout ?? (0, _layout.resolvePageLayout)(meta);
  const showRails = sh?.showRails ?? (layout === 'doc' && !meta?.view);
  const safe = sh?.safe ?? (0, _renderMode.resolveSafeRender)(homeMeta, meta);
  const vw = sh?.vw ?? 'desktop';
  const localMins = useReadingTimeMins(entryKey, !sh); // the shell computes it on the stock page
  const mins = sh?.mins ?? localMins;
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("article", {
    className: "grove-page",
    "data-layout": layout,
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "gp-main",
      children: [sh ? /*#__PURE__*/(0, _jsxRuntime.jsx)(_EntryHeader.default, {
        entryKey: entryKey,
        writable: sh.writable,
        mins: mins,
        affordance: {
          busy: sh.editBusy,
          refused: sh.editRefused,
          openEditor: sh.openEditor,
          hint: sh.editHint
        }
      }) :
      /*#__PURE__*/
      // Standalone (library mode): the header's affordance derives itself —
      // the mount's live answer, exactly what the shell would have carried.
      (0, _jsxRuntime.jsx)(StandaloneHeader, {
        entryKey: entryKey,
        mins: mins
      }), showRails && vw === 'mobile' ? /*#__PURE__*/(0, _jsxRuntime.jsxs)("details", {
        className: "grove-toc__disclosure",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("summary", {
          children: "On this page"
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_Toc.default, {
          entryKey: entryKey
        })]
      }) : null, /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "grove-prose",
        children: safe ? /*#__PURE__*/(0, _jsxRuntime.jsx)(_SafeEntryBody.default, {
          entryKey: entryKey
        }) : /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
          className: "grove-entry-body",
          "data-entry": entryKey,
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_sdk.Include, {
            filename: includePath,
            baseModule: module
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_ScrollToFragment.default, {
            entryKey: entryKey
          })]
        }, entryKey)
      }), showRails ? /*#__PURE__*/(0, _jsxRuntime.jsx)(_Backlinks.default, {}) : null]
    }), showRails && vw === 'desktop' ? /*#__PURE__*/(0, _jsxRuntime.jsx)(_Toc.default, {
      entryKey: entryKey
    }) : null]
  });
}

/** The header for a shell-less composition: the edit affordance derives itself
 *  from the live mount set (the hook only runs on this path — no double
 *  subscription on the stock page). */
_s2(EntryBody, "Qp7GT/fxSu1DxJyJpyhXX/Ew3VA=", false, function () {
  return [_sdk.useFileMetadata, _sdk.useFileMetadata, useReadingTimeMins];
});
_c = EntryBody;
function StandaloneHeader({
  entryKey,
  mins
}) {
  _s3();
  const local = (0, _useEditAffordance.useEditAffordance)(false);
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_EntryHeader.default, {
    entryKey: entryKey,
    writable: local.writable,
    mins: mins,
    affordance: {
      busy: local.busy,
      refused: local.refused,
      openEditor: local.openEditor,
      hint: local.editHint
    }
  });
}
_s3(StandaloneHeader, "sTySOfixBm7a9KrM3Nhz827TRF8=", false, function () {
  return [_useEditAffordance.useEditAffordance];
});
_c2 = StandaloneHeader;
var _c, _c2;
$RefreshReg$(_c, "EntryBody");
$RefreshReg$(_c2, "StandaloneHeader");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NkayIsIl9zaGVsbCIsIl9jb250ZW50IiwiX2xheW91dCIsIl93aWtpIiwiX3JlbmRlck1vZGUiLCJfdXNlRWRpdEFmZm9yZGFuY2UiLCJfZnMiLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX0VudHJ5SGVhZGVyIiwiX1NhZmVFbnRyeUJvZHkiLCJfU2Nyb2xsVG9GcmFnbWVudCIsIl9Ub2MiLCJfQmFja2xpbmtzIiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsIl9zMiIsIl9zMyIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsInVzZVJlYWRpbmdUaW1lTWlucyIsImVudHJ5S2V5IiwiZW5hYmxlZCIsIm1pbnMiLCJzZXRNaW5zIiwidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJhY3RpdmUiLCJmcyIsInByb21pc2VzIiwicmVhZEZpbGUiLCJrZXlUb0ZzUGF0aCIsInRoZW4iLCJiIiwicmVhZGluZ1RpbWUiLCJzdHJpcEZyb250bWF0dGVyIiwiU3RyaW5nIiwiY2F0Y2giLCJ1bmRlZmluZWQiLCJFbnRyeUJvZHkiLCJzaCIsInVzZUNvbnRleHQiLCJHcm92ZVNoZWxsQ29udGV4dCIsIm1ldGEiLCJ1c2VGaWxlTWV0YWRhdGEiLCJob21lTWV0YSIsImhvbWVLZXkiLCJpbmNsdWRlUGF0aCIsImtleVRvSW5jbHVkZSIsImxheW91dCIsInJlc29sdmVQYWdlTGF5b3V0Iiwic2hvd1JhaWxzIiwidmlldyIsInNhZmUiLCJyZXNvbHZlU2FmZVJlbmRlciIsInZ3IiwibG9jYWxNaW5zIiwianN4cyIsImNsYXNzTmFtZSIsImNoaWxkcmVuIiwianN4Iiwid3JpdGFibGUiLCJhZmZvcmRhbmNlIiwiYnVzeSIsImVkaXRCdXN5IiwicmVmdXNlZCIsImVkaXRSZWZ1c2VkIiwib3BlbkVkaXRvciIsImhpbnQiLCJlZGl0SGludCIsIlN0YW5kYWxvbmVIZWFkZXIiLCJJbmNsdWRlIiwiZmlsZW5hbWUiLCJiYXNlTW9kdWxlIiwibW9kdWxlIiwiX2MiLCJsb2NhbCIsInVzZUVkaXRBZmZvcmRhbmNlIiwiX2MyIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiRW50cnlCb2R5LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55ICovXG4vLyBgPEVudHJ5Qm9keS8+YCDigJQgT05FIGVudHJ5J3MgY29udGVudCByZWdpb24gKFIzLTg3MiwgQVBQX0NVU1RPTUlaQVRJT04gwqc0LjEpOlxuLy8gdGhlIGhlYWRlciAod2l0aCBpdHMgZWRpdCBhZmZvcmRhbmNlKSwgdGhlIGJvZHkgb24gdGhlIHNhZmUgb3IgY29tcGlsZWQgcGF0aFxuLy8gZXhhY3RseSBhcyB0aGUgc3RvY2sgcGFnZSByZW5kZXJzIGl0LCB0aGUgbWV0YWRhdGEgbGluZSBhbmQgdGhlIHRhZ3MuIENhcnZlZFxuLy8gb3V0IG9mIFBhZ2VWaWV3IHNvIGBHcm92ZUVudHJ5YCAoYW5kIGFueSBzaGVsbCBjb21wb3Npbmcgc2V2ZXJhbCBlbnRyaWVzIG9uIG9uZVxuLy8gcGFnZSkgcmVuZGVycyB0aGUgc2FtZSB0aGluZyB0aGUgc3RvY2sgcGFnZSBkb2VzIOKAlCB0aGVyZSBpcyBvbmUgZW50cnkgcmVuZGVyZXIuXG4vL1xuLy8gUmVhZHMgdGhlIHNoZWxsIGNvbnRleHQgTk9OLXRocm93aW5nICh0aGUgc3RvY2sgcGFnZSBwcm92aWRlcyBpdDsgYSBiYXJlXG4vLyBsaWJyYXJ5LW1vZGUgY29tcG9zaXRpb24gZG9lcyBub3QpIGFuZCBkZXJpdmVzIGFueXRoaW5nIG1pc3NpbmcgZnJvbSB0aGVcbi8vIGVudHJ5S2V5IGl0c2VsZiDigJQgb25lIGRlcml2YXRpb24sIHR3byBwb3NzaWJsZSByZWFkZXJzLlxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZUNvbnRleHQgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBJbmNsdWRlLCB1c2VGaWxlTWV0YWRhdGEgfSBmcm9tICdAaW1tZWRpYXRlbHktcnVuL3Nkayc7XG5pbXBvcnQgeyBHcm92ZVNoZWxsQ29udGV4dCB9IGZyb20gJy4uL2xpYi9zaGVsbCc7XG5pbXBvcnQgeyBrZXlUb0luY2x1ZGUsIGhvbWVLZXkgfSBmcm9tICcuLi9saWIvY29udGVudCc7XG5pbXBvcnQgeyByZXNvbHZlUGFnZUxheW91dCB9IGZyb20gJy4uL2xpYi9sYXlvdXQnO1xuaW1wb3J0IHsgcmVhZGluZ1RpbWUsIHN0cmlwRnJvbnRtYXR0ZXIgfSBmcm9tICcuLi9saWIvd2lraSc7XG5pbXBvcnQgeyBrZXlUb0ZzUGF0aCB9IGZyb20gJy4uL2xpYi9jb250ZW50JztcbmltcG9ydCB7IHJlc29sdmVTYWZlUmVuZGVyIH0gZnJvbSAnLi4vbGliL3JlbmRlck1vZGUnO1xuaW1wb3J0IHsgdXNlRWRpdEFmZm9yZGFuY2UgfSBmcm9tICcuLi9ob29rcy91c2VFZGl0QWZmb3JkYW5jZSc7XG5pbXBvcnQgZnMgZnJvbSAnZnMnO1xuaW1wb3J0IEVudHJ5SGVhZGVyIGZyb20gJy4vRW50cnlIZWFkZXInO1xuaW1wb3J0IFNhZmVFbnRyeUJvZHkgZnJvbSAnLi9TYWZlRW50cnlCb2R5JztcbmltcG9ydCBTY3JvbGxUb0ZyYWdtZW50IGZyb20gJy4vU2Nyb2xsVG9GcmFnbWVudCc7XG5pbXBvcnQgVG9jIGZyb20gJy4vVG9jJztcbmltcG9ydCBCYWNrbGlua3MgZnJvbSAnLi9CYWNrbGlua3MnO1xuXG5kZWNsYXJlIGNvbnN0IG1vZHVsZTogYW55O1xuXG4vKiogVGhlIHJlYWRpbmctdGltZSBtaW51dGVzIGZvciBvbmUgZW50cnkg4oCUIHJlYWQgdGhlIGJvZHkgb25jZSBwZXIgZW50cnkuXG4gKiAgYGVuYWJsZWRgIGdhdGVzIHRoZSByZWFkIChob29rcyBtYXkgbm90IGJlIGNvbmRpdGlvbmFsKTogdGhlIHN0b2NrIHBhZ2UncyBzaGVsbFxuICogIGNvbXB1dGVzIGBtaW5zYCBvbmNlIGFscmVhZHksIGFuZCBhIHNlY29uZCByZWFkIHBlciBuYXZpZ2F0aW9uIGlzIHRoZVxuICogIGRvdWJsZS1yZWFkIHRoaXMgZmxhZyBleGlzdHMgdG8gcHJldmVudCAocmV2aWV3IHJvdW5kIDEpLiAqL1xuZnVuY3Rpb24gdXNlUmVhZGluZ1RpbWVNaW5zKGVudHJ5S2V5OiBzdHJpbmcsIGVuYWJsZWQ6IGJvb2xlYW4pOiBudW1iZXIge1xuICBjb25zdCBbbWlucywgc2V0TWluc10gPSB1c2VTdGF0ZSgwKTtcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIWVuYWJsZWQpIHJldHVybjtcbiAgICBsZXQgYWN0aXZlID0gdHJ1ZTtcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgcmVhY3QtaG9va3Mvc2V0LXN0YXRlLWluLWVmZmVjdFxuICAgIHNldE1pbnMoMCk7XG4gICAgZnMucHJvbWlzZXNcbiAgICAgIC5yZWFkRmlsZShrZXlUb0ZzUGF0aChlbnRyeUtleSksICd1dGY4JylcbiAgICAgIC50aGVuKChiOiB1bmtub3duKSA9PiB7XG4gICAgICAgIGlmIChhY3RpdmUpIHNldE1pbnMocmVhZGluZ1RpbWUoc3RyaXBGcm9udG1hdHRlcihTdHJpbmcoYikpKSk7XG4gICAgICB9KVxuICAgICAgLmNhdGNoKCgpID0+IHVuZGVmaW5lZCk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGFjdGl2ZSA9IGZhbHNlO1xuICAgIH07XG4gIH0sIFtlbnRyeUtleSwgZW5hYmxlZF0pO1xuICByZXR1cm4gbWlucztcbn1cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gRW50cnlCb2R5KHsgZW50cnlLZXkgfTogeyBlbnRyeUtleTogc3RyaW5nIH0pIHtcbiAgY29uc3Qgc2ggPSB1c2VDb250ZXh0KEdyb3ZlU2hlbGxDb250ZXh0KTtcbiAgY29uc3QgbWV0YSA9IHVzZUZpbGVNZXRhZGF0YShlbnRyeUtleSkgYXMgYW55O1xuICBjb25zdCBob21lTWV0YSA9IHVzZUZpbGVNZXRhZGF0YShob21lS2V5KCkpIGFzIGFueTtcbiAgLy8gVGhlIHNoZWxsJ3MgdmFsdWVzIHdpbiB3aGVuIHByZXNlbnQgKHRoZSBzdG9jayBwYWdlIGRlcml2ZXMgdGhlbSBvbmNlKTtcbiAgLy8gc3RhbmRhbG9uZSwgdGhlIHNhbWUgZXhwcmVzc2lvbnMgcnVuIGhlcmUuXG4gIGNvbnN0IGluY2x1ZGVQYXRoID0gc2g/LmluY2x1ZGVQYXRoID8/IGtleVRvSW5jbHVkZShlbnRyeUtleSk7XG4gIGNvbnN0IGxheW91dCA9IHNoPy5sYXlvdXQgPz8gcmVzb2x2ZVBhZ2VMYXlvdXQobWV0YSk7XG4gIGNvbnN0IHNob3dSYWlscyA9IHNoPy5zaG93UmFpbHMgPz8gKGxheW91dCA9PT0gJ2RvYycgJiYgIW1ldGE/LnZpZXcpO1xuICBjb25zdCBzYWZlID0gc2g/LnNhZmUgPz8gcmVzb2x2ZVNhZmVSZW5kZXIoaG9tZU1ldGEsIG1ldGEpO1xuICBjb25zdCB2dyA9IHNoPy52dyA/PyAnZGVza3RvcCc7XG4gIGNvbnN0IGxvY2FsTWlucyA9IHVzZVJlYWRpbmdUaW1lTWlucyhlbnRyeUtleSwgIXNoKTsgLy8gdGhlIHNoZWxsIGNvbXB1dGVzIGl0IG9uIHRoZSBzdG9jayBwYWdlXG4gIGNvbnN0IG1pbnMgPSBzaD8ubWlucyA/PyBsb2NhbE1pbnM7XG5cbiAgcmV0dXJuIChcbiAgICA8YXJ0aWNsZSBjbGFzc05hbWU9XCJncm92ZS1wYWdlXCIgZGF0YS1sYXlvdXQ9e2xheW91dH0+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdwLW1haW5cIj5cbiAgICAgICAge3NoID8gKFxuICAgICAgICAgIDxFbnRyeUhlYWRlclxuICAgICAgICAgICAgZW50cnlLZXk9e2VudHJ5S2V5fVxuICAgICAgICAgICAgd3JpdGFibGU9e3NoLndyaXRhYmxlfVxuICAgICAgICAgICAgbWlucz17bWluc31cbiAgICAgICAgICAgIGFmZm9yZGFuY2U9e3sgYnVzeTogc2guZWRpdEJ1c3ksIHJlZnVzZWQ6IHNoLmVkaXRSZWZ1c2VkLCBvcGVuRWRpdG9yOiBzaC5vcGVuRWRpdG9yLCBoaW50OiBzaC5lZGl0SGludCB9fVxuICAgICAgICAgIC8+XG4gICAgICAgICkgOiAoXG4gICAgICAgICAgLy8gU3RhbmRhbG9uZSAobGlicmFyeSBtb2RlKTogdGhlIGhlYWRlcidzIGFmZm9yZGFuY2UgZGVyaXZlcyBpdHNlbGYg4oCUXG4gICAgICAgICAgLy8gdGhlIG1vdW50J3MgbGl2ZSBhbnN3ZXIsIGV4YWN0bHkgd2hhdCB0aGUgc2hlbGwgd291bGQgaGF2ZSBjYXJyaWVkLlxuICAgICAgICAgIDxTdGFuZGFsb25lSGVhZGVyIGVudHJ5S2V5PXtlbnRyeUtleX0gbWlucz17bWluc30gLz5cbiAgICAgICAgKX1cbiAgICAgICAge3Nob3dSYWlscyAmJiB2dyA9PT0gJ21vYmlsZScgPyAoXG4gICAgICAgICAgPGRldGFpbHMgY2xhc3NOYW1lPVwiZ3JvdmUtdG9jX19kaXNjbG9zdXJlXCI+XG4gICAgICAgICAgICA8c3VtbWFyeT5PbiB0aGlzIHBhZ2U8L3N1bW1hcnk+XG4gICAgICAgICAgICA8VG9jIGVudHJ5S2V5PXtlbnRyeUtleX0gLz5cbiAgICAgICAgICA8L2RldGFpbHM+XG4gICAgICAgICkgOiBudWxsfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyb3ZlLXByb3NlXCI+XG4gICAgICAgICAgey8qIEludGVycHJldGVyIG1vZGUgKFIzLTIxMykgcmVuZGVycyB0aGUgcmF3IGVudHJ5IGFzIGRhdGEg4oCUIG5vIGF1dGhvciBKUyBydW5zO1xuICAgICAgICAgICAgICBleGVjdXRhYmxlIG1vZGUgY29tcGlsZXMgKyBydW5zIHRoZSBNRFggdmlhIDxJbmNsdWRlPi4gQm90aCBhcmUgc3VwcG9ydGVkLFxuICAgICAgICAgICAgICBhbmQgc2luY2UgUjMtMjUyIHRoZSBjaG9pY2UgaXMgcGVyLWVudHJ5IGFzIHdlbGwgYXMgd2lraS13aWRlLlxuXG4gICAgICAgICAgICAgIGBrZXk9e2VudHJ5S2V5fWAgZm9yY2VzIGFuIHVubW91bnQgYWNyb3NzIGEgY2xpZW50LXNpZGUgbmF2aWdhdGlvbi4gV2l0aG91dFxuICAgICAgICAgICAgICBpdCBSZWFjdCByZXVzZXMgdGhpcyBzdWJ0cmVlIGFuZCBrZWVwcyB0aGUgUFJFVklPVVMgZG9jdW1lbnQgbW91bnRlZCB3aGlsZVxuICAgICAgICAgICAgICB0aGUgbmV3IG9uZSBjb21waWxlcywgc28gYCNzZWMtNGAgcmVzb2x2ZXMgYWdhaW5zdCB0aGUgd3JvbmcgZW50cnkg4oCUIGV2ZXJ5XG4gICAgICAgICAgICAgIGVudHJ5IGhlcmUgbnVtYmVycyBpdHMgc2VjdGlvbnMgZnJvbSAxLCBzbyB0aGF0IGxvb2t1cCBhbHdheXMgc3VjY2VlZHMgYW5kXG4gICAgICAgICAgICAgIGFsd2F5cyBsYW5kcyB3cm9uZy4gTWVhc3VyZWQgb24gdGhlIGhvc3Q6IGEgY2l0YXRpb24gdG8gY29yZV9jb25jZXB0cyDCpzRcbiAgICAgICAgICAgICAgKFwiNCDigJQgUHJpbmNpcGFsXCIpIHNjcm9sbGVkIHRvIGEgZGlmZmVyZW50IGRvY3VtZW50J3MgXCI0LiBUaGUgcHJvdmlkZXItZmFjaW5nXG4gICAgICAgICAgICAgIGNvbnRyYWN0XCIgKFIzLTI0OSdzIGhhemFyZCwgcmVpbnRyb2R1Y2VkKS5cblxuICAgICAgICAgICAgICBSMy04NzI6IEJPVEggcGF0aHMgbm93IGNhcnJ5IHRoZSBgZGF0YS1lbnRyeWAgbWFya2VyICh0aGUgY29tcGlsZWQgcGF0aCdzXG4gICAgICAgICAgICAgIG9taXNzaW9uIHByZWRhdGVzIGVudHJ5LXNjb3BlZCBmcmFnbWVudCByZXNvbHV0aW9uKS4gT24gdGhlIGNvbXBpbGVkIHBhdGhcbiAgICAgICAgICAgICAgdGhlIG1hcmtlciBpcyBwcmVzZW50IHdoaWxlIHRoZSBib2R5IGNvbXBpbGVzIOKAlCB0aGF0IHJlYWRzIGFzIFwic2NvcGVkLCBub3RcbiAgICAgICAgICAgICAgeWV0IGZvdW5kXCIsIGFuZCBgcmVzb2x2ZUZyYWdtZW50VGFyZ2V0YCdzIG51bGwtdW50aWwtZm91bmQgaXMgZXhhY3RseSB0aGVcbiAgICAgICAgICAgICAgd2FpdCB0aGUgY2FsbGVyIG5lZWRzOyB0aGUgbWFya2VyIG1lYW5zIFwidGhpcyBzdWJ0cmVlIGlzIGVudHJ5IFgncyByZWdpb25cIixcbiAgICAgICAgICAgICAgYW5kIGFuIHVuY29tbWl0dGVkIGJvZHkgY29udGFpbnMgbm8gZnJhZ21lbnQgdGFyZ2V0IHRvIGZpbmQsIHNvIHRoZSBvbGRcbiAgICAgICAgICAgICAgY2xhaW0tdG9vLWVhcmx5IGZhaWx1cmUgaGFzIG5vIHBhdGggdG8gZmlyZS4gKi99XG4gICAgICAgICAge3NhZmUgPyAoXG4gICAgICAgICAgICA8U2FmZUVudHJ5Qm9keSBlbnRyeUtleT17ZW50cnlLZXl9IC8+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JvdmUtZW50cnktYm9keVwiIGtleT17ZW50cnlLZXl9IGRhdGEtZW50cnk9e2VudHJ5S2V5fT5cbiAgICAgICAgICAgICAgPEluY2x1ZGUgZmlsZW5hbWU9e2luY2x1ZGVQYXRofSBiYXNlTW9kdWxlPXttb2R1bGV9IC8+XG4gICAgICAgICAgICAgIDxTY3JvbGxUb0ZyYWdtZW50IGVudHJ5S2V5PXtlbnRyeUtleX0gLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgICB7c2hvd1JhaWxzID8gPEJhY2tsaW5rcyAvPiA6IG51bGx9XG4gICAgICA8L2Rpdj5cbiAgICAgIHtzaG93UmFpbHMgJiYgdncgPT09ICdkZXNrdG9wJyA/IDxUb2MgZW50cnlLZXk9e2VudHJ5S2V5fSAvPiA6IG51bGx9XG4gICAgPC9hcnRpY2xlPlxuICApO1xufVxuXG4vKiogVGhlIGhlYWRlciBmb3IgYSBzaGVsbC1sZXNzIGNvbXBvc2l0aW9uOiB0aGUgZWRpdCBhZmZvcmRhbmNlIGRlcml2ZXMgaXRzZWxmXG4gKiAgZnJvbSB0aGUgbGl2ZSBtb3VudCBzZXQgKHRoZSBob29rIG9ubHkgcnVucyBvbiB0aGlzIHBhdGgg4oCUIG5vIGRvdWJsZVxuICogIHN1YnNjcmlwdGlvbiBvbiB0aGUgc3RvY2sgcGFnZSkuICovXG5mdW5jdGlvbiBTdGFuZGFsb25lSGVhZGVyKHsgZW50cnlLZXksIG1pbnMgfTogeyBlbnRyeUtleTogc3RyaW5nOyBtaW5zOiBudW1iZXIgfSkge1xuICBjb25zdCBsb2NhbCA9IHVzZUVkaXRBZmZvcmRhbmNlKGZhbHNlKTtcbiAgcmV0dXJuIChcbiAgICA8RW50cnlIZWFkZXJcbiAgICAgIGVudHJ5S2V5PXtlbnRyeUtleX1cbiAgICAgIHdyaXRhYmxlPXtsb2NhbC53cml0YWJsZX1cbiAgICAgIG1pbnM9e21pbnN9XG4gICAgICBhZmZvcmRhbmNlPXt7IGJ1c3k6IGxvY2FsLmJ1c3ksIHJlZnVzZWQ6IGxvY2FsLnJlZnVzZWQsIG9wZW5FZGl0b3I6IGxvY2FsLm9wZW5FZGl0b3IsIGhpbnQ6IGxvY2FsLmVkaXRIaW50IH19XG4gICAgLz5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBVUEsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBRUEsSUFBQUMsSUFBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsTUFBQSxHQUFBRixPQUFBO0FBQ0EsSUFBQUcsUUFBQSxHQUFBSCxPQUFBO0FBQ0EsSUFBQUksT0FBQSxHQUFBSixPQUFBO0FBQ0EsSUFBQUssS0FBQSxHQUFBTCxPQUFBO0FBRUEsSUFBQU0sV0FBQSxHQUFBTixPQUFBO0FBQ0EsSUFBQU8sa0JBQUEsR0FBQVAsT0FBQTtBQUNBLElBQUFRLEdBQUEsR0FBQUMsc0JBQUEsQ0FBQVQsT0FBQTtBQUNBLElBQUFVLFlBQUEsR0FBQUQsc0JBQUEsQ0FBQVQsT0FBQTtBQUNBLElBQUFXLGNBQUEsR0FBQUYsc0JBQUEsQ0FBQVQsT0FBQTtBQUNBLElBQUFZLGlCQUFBLEdBQUFILHNCQUFBLENBQUFULE9BQUE7QUFDQSxJQUFBYSxJQUFBLEdBQUFKLHNCQUFBLENBQUFULE9BQUE7QUFDQSxJQUFBYyxVQUFBLEdBQUFMLHNCQUFBLENBQUFULE9BQUE7QUFBb0MsSUFBQWUsV0FBQSxHQUFBZixPQUFBO0FBQUEsSUFBQWdCLEVBQUEsR0FBQUMsWUFBQTtFQUFBQyxHQUFBLEdBQUFELFlBQUE7RUFBQUUsR0FBQSxHQUFBRixZQUFBO0FBekJwQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUFBLFNBQUFSLHVCQUFBVyxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBb0JBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBU0csa0JBQWtCQSxDQUFDQyxRQUFnQixFQUFFQyxPQUFnQixFQUFVO0VBQUFULEVBQUE7RUFDdEUsTUFBTSxDQUFDVSxJQUFJLEVBQUVDLE9BQU8sQ0FBQyxHQUFHLElBQUFDLGVBQVEsRUFBQyxDQUFDLENBQUM7RUFDbkMsSUFBQUMsZ0JBQVMsRUFBQyxNQUFNO0lBQ2QsSUFBSSxDQUFDSixPQUFPLEVBQUU7SUFDZCxJQUFJSyxNQUFNLEdBQUcsSUFBSTtJQUNqQjtJQUNBSCxPQUFPLENBQUMsQ0FBQyxDQUFDO0lBQ1ZJLFdBQUUsQ0FBQ0MsUUFBUSxDQUNSQyxRQUFRLENBQUMsSUFBQUMsb0JBQVcsRUFBQ1YsUUFBUSxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQ3ZDVyxJQUFJLENBQUVDLENBQVUsSUFBSztNQUNwQixJQUFJTixNQUFNLEVBQUVILE9BQU8sQ0FBQyxJQUFBVSxpQkFBVyxFQUFDLElBQUFDLHNCQUFnQixFQUFDQyxNQUFNLENBQUNILENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUMvRCxDQUFDLENBQUMsQ0FDREksS0FBSyxDQUFDLE1BQU1DLFNBQVMsQ0FBQztJQUN6QixPQUFPLE1BQU07TUFDWFgsTUFBTSxHQUFHLEtBQUs7SUFDaEIsQ0FBQztFQUNILENBQUMsRUFBRSxDQUFDTixRQUFRLEVBQUVDLE9BQU8sQ0FBQyxDQUFDO0VBQ3ZCLE9BQU9DLElBQUk7QUFDYjtBQUFDVixFQUFBLENBbEJRTyxrQkFBa0I7QUFvQlosU0FBU21CLFNBQVNBLENBQUM7RUFBRWxCO0FBQStCLENBQUMsRUFBRTtFQUFBTixHQUFBO0VBQ3BFLE1BQU15QixFQUFFLEdBQUcsSUFBQUMsaUJBQVUsRUFBQ0Msd0JBQWlCLENBQUM7RUFDeEMsTUFBTUMsSUFBSSxHQUFHLElBQUFDLG9CQUFlLEVBQUN2QixRQUFRLENBQVE7RUFDN0MsTUFBTXdCLFFBQVEsR0FBRyxJQUFBRCxvQkFBZSxFQUFDLElBQUFFLGdCQUFPLEVBQUMsQ0FBQyxDQUFRO0VBQ2xEO0VBQ0E7RUFDQSxNQUFNQyxXQUFXLEdBQUdQLEVBQUUsRUFBRU8sV0FBVyxJQUFJLElBQUFDLHFCQUFZLEVBQUMzQixRQUFRLENBQUM7RUFDN0QsTUFBTTRCLE1BQU0sR0FBR1QsRUFBRSxFQUFFUyxNQUFNLElBQUksSUFBQUMseUJBQWlCLEVBQUNQLElBQUksQ0FBQztFQUNwRCxNQUFNUSxTQUFTLEdBQUdYLEVBQUUsRUFBRVcsU0FBUyxLQUFLRixNQUFNLEtBQUssS0FBSyxJQUFJLENBQUNOLElBQUksRUFBRVMsSUFBSSxDQUFDO0VBQ3BFLE1BQU1DLElBQUksR0FBR2IsRUFBRSxFQUFFYSxJQUFJLElBQUksSUFBQUMsNkJBQWlCLEVBQUNULFFBQVEsRUFBRUYsSUFBSSxDQUFDO0VBQzFELE1BQU1ZLEVBQUUsR0FBR2YsRUFBRSxFQUFFZSxFQUFFLElBQUksU0FBUztFQUM5QixNQUFNQyxTQUFTLEdBQUdwQyxrQkFBa0IsQ0FBQ0MsUUFBUSxFQUFFLENBQUNtQixFQUFFLENBQUMsQ0FBQyxDQUFDO0VBQ3JELE1BQU1qQixJQUFJLEdBQUdpQixFQUFFLEVBQUVqQixJQUFJLElBQUlpQyxTQUFTO0VBRWxDLG9CQUNFLElBQUE1QyxXQUFBLENBQUE2QyxJQUFBO0lBQVNDLFNBQVMsRUFBQyxZQUFZO0lBQUMsZUFBYVQsTUFBTztJQUFBVSxRQUFBLGdCQUNsRCxJQUFBL0MsV0FBQSxDQUFBNkMsSUFBQTtNQUFLQyxTQUFTLEVBQUMsU0FBUztNQUFBQyxRQUFBLEdBQ3JCbkIsRUFBRSxnQkFDRCxJQUFBNUIsV0FBQSxDQUFBZ0QsR0FBQSxFQUFDckQsWUFBQSxDQUFBWSxPQUFXO1FBQ1ZFLFFBQVEsRUFBRUEsUUFBUztRQUNuQndDLFFBQVEsRUFBRXJCLEVBQUUsQ0FBQ3FCLFFBQVM7UUFDdEJ0QyxJQUFJLEVBQUVBLElBQUs7UUFDWHVDLFVBQVUsRUFBRTtVQUFFQyxJQUFJLEVBQUV2QixFQUFFLENBQUN3QixRQUFRO1VBQUVDLE9BQU8sRUFBRXpCLEVBQUUsQ0FBQzBCLFdBQVc7VUFBRUMsVUFBVSxFQUFFM0IsRUFBRSxDQUFDMkIsVUFBVTtVQUFFQyxJQUFJLEVBQUU1QixFQUFFLENBQUM2QjtRQUFTO01BQUUsQ0FDMUcsQ0FBQztNQUFBO01BRUY7TUFDQTtNQUNBLElBQUF6RCxXQUFBLENBQUFnRCxHQUFBLEVBQUNVLGdCQUFnQjtRQUFDakQsUUFBUSxFQUFFQSxRQUFTO1FBQUNFLElBQUksRUFBRUE7TUFBSyxDQUFFLENBQ3BELEVBQ0E0QixTQUFTLElBQUlJLEVBQUUsS0FBSyxRQUFRLGdCQUMzQixJQUFBM0MsV0FBQSxDQUFBNkMsSUFBQTtRQUFTQyxTQUFTLEVBQUMsdUJBQXVCO1FBQUFDLFFBQUEsZ0JBQ3hDLElBQUEvQyxXQUFBLENBQUFnRCxHQUFBO1VBQUFELFFBQUEsRUFBUztRQUFZLENBQVMsQ0FBQyxlQUMvQixJQUFBL0MsV0FBQSxDQUFBZ0QsR0FBQSxFQUFDbEQsSUFBQSxDQUFBUyxPQUFHO1VBQUNFLFFBQVEsRUFBRUE7UUFBUyxDQUFFLENBQUM7TUFBQSxDQUNwQixDQUFDLEdBQ1IsSUFBSSxlQUNSLElBQUFULFdBQUEsQ0FBQWdELEdBQUE7UUFBS0YsU0FBUyxFQUFDLGFBQWE7UUFBQUMsUUFBQSxFQW9CekJOLElBQUksZ0JBQ0gsSUFBQXpDLFdBQUEsQ0FBQWdELEdBQUEsRUFBQ3BELGNBQUEsQ0FBQVcsT0FBYTtVQUFDRSxRQUFRLEVBQUVBO1FBQVMsQ0FBRSxDQUFDLGdCQUVyQyxJQUFBVCxXQUFBLENBQUE2QyxJQUFBO1VBQUtDLFNBQVMsRUFBQyxrQkFBa0I7VUFBZ0IsY0FBWXJDLFFBQVM7VUFBQXNDLFFBQUEsZ0JBQ3BFLElBQUEvQyxXQUFBLENBQUFnRCxHQUFBLEVBQUM5RCxJQUFBLENBQUF5RSxPQUFPO1lBQUNDLFFBQVEsRUFBRXpCLFdBQVk7WUFBQzBCLFVBQVUsRUFBRUM7VUFBTyxDQUFFLENBQUMsZUFDdEQsSUFBQTlELFdBQUEsQ0FBQWdELEdBQUEsRUFBQ25ELGlCQUFBLENBQUFVLE9BQWdCO1lBQUNFLFFBQVEsRUFBRUE7VUFBUyxDQUFFLENBQUM7UUFBQSxHQUZIQSxRQUdsQztNQUNOLENBQ0UsQ0FBQyxFQUNMOEIsU0FBUyxnQkFBRyxJQUFBdkMsV0FBQSxDQUFBZ0QsR0FBQSxFQUFDakQsVUFBQSxDQUFBUSxPQUFTLElBQUUsQ0FBQyxHQUFHLElBQUk7SUFBQSxDQUM5QixDQUFDLEVBQ0xnQyxTQUFTLElBQUlJLEVBQUUsS0FBSyxTQUFTLGdCQUFHLElBQUEzQyxXQUFBLENBQUFnRCxHQUFBLEVBQUNsRCxJQUFBLENBQUFTLE9BQUc7TUFBQ0UsUUFBUSxFQUFFQTtJQUFTLENBQUUsQ0FBQyxHQUFHLElBQUk7RUFBQSxDQUM1RCxDQUFDO0FBRWQ7O0FBRUE7QUFDQTtBQUNBO0FBRkFOLEdBQUEsQ0F2RXdCd0IsU0FBUztFQUFBLFFBRWxCSyxvQkFBZSxFQUNYQSxvQkFBZSxFQVFkeEIsa0JBQWtCO0FBQUE7QUFBQXVELEVBQUEsR0FYZHBDLFNBQVM7QUEwRWpDLFNBQVMrQixnQkFBZ0JBLENBQUM7RUFBRWpELFFBQVE7RUFBRUU7QUFBeUMsQ0FBQyxFQUFFO0VBQUFQLEdBQUE7RUFDaEYsTUFBTTRELEtBQUssR0FBRyxJQUFBQyxvQ0FBaUIsRUFBQyxLQUFLLENBQUM7RUFDdEMsb0JBQ0UsSUFBQWpFLFdBQUEsQ0FBQWdELEdBQUEsRUFBQ3JELFlBQUEsQ0FBQVksT0FBVztJQUNWRSxRQUFRLEVBQUVBLFFBQVM7SUFDbkJ3QyxRQUFRLEVBQUVlLEtBQUssQ0FBQ2YsUUFBUztJQUN6QnRDLElBQUksRUFBRUEsSUFBSztJQUNYdUMsVUFBVSxFQUFFO01BQUVDLElBQUksRUFBRWEsS0FBSyxDQUFDYixJQUFJO01BQUVFLE9BQU8sRUFBRVcsS0FBSyxDQUFDWCxPQUFPO01BQUVFLFVBQVUsRUFBRVMsS0FBSyxDQUFDVCxVQUFVO01BQUVDLElBQUksRUFBRVEsS0FBSyxDQUFDUDtJQUFTO0VBQUUsQ0FDOUcsQ0FBQztBQUVOO0FBQUNyRCxHQUFBLENBVlFzRCxnQkFBZ0I7RUFBQSxRQUNUTyxvQ0FBaUI7QUFBQTtBQUFBQyxHQUFBLEdBRHhCUixnQkFBZ0I7QUFBQSxJQUFBSyxFQUFBLEVBQUFHLEdBQUE7QUFBQUMsWUFBQSxDQUFBSixFQUFBO0FBQUFJLFlBQUEsQ0FBQUQsR0FBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}