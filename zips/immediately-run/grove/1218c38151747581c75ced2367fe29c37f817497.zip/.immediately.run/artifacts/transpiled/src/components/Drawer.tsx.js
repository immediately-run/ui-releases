var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Drawer;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
var _sdk = require("@immediately-run/sdk");
var _useOverlayFocusDismiss = require("../hooks/useOverlayFocusDismiss");
var _useFollowLink = require("../hooks/useFollowLink");
var _navigationPolicy = require("../lib/navigationPolicy");
var _Sidebar = _interopRequireDefault(require("./Sidebar"));
var _Icon = _interopRequireDefault(require("./Icon"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$();
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// `.grove-drawer` — the mobile nav drawer: site mark + nav items + the full
// namespace tree, over a dismiss scrim. The panel carries the dialog contract
// (R3-608): focus in, Tab trapped, Escape, focus return — via the shared
// overlay hook, whose stack makes nested overlays close one per Escape.
function Drawer({
  siteTitle,
  nav,
  onClose
}) {
  _s();
  const dialogRef = (0, _useOverlayFocusDismiss.useOverlayFocusDismiss)(true, onClose);
  const follow = (0, _useFollowLink.useFollowLink)();
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    className: "grove-drawer",
    onClick: onClose,
    children: /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "grove-drawer__panel",
      ref: dialogRef,
      tabIndex: -1,
      role: "dialog",
      "aria-modal": "true",
      "aria-label": "Site menu",
      onClick: e => e.stopPropagation(),
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "grove-drawer__h",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "mk"
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "t",
          children: siteTitle
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          className: "x",
          "aria-label": "Close menu",
          onClick: onClose,
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
            name: "x"
          })
        })]
      }), nav.length ? /*#__PURE__*/(0, _jsxRuntime.jsx)("nav", {
        className: "grove-drawer__nav",
        children: nav.map(n => /*#__PURE__*/(0, _jsxRuntime.jsx)(_sdk.Link, {
          href: n.href,
          "data-cur": n.cur ? '1' : '0',
          onClick: e => {
            (0, _navigationPolicy.followLinkOnClick)(follow, {
              key: n.key,
              href: n.href
            })(e);
            onClose();
          },
          children: n.label
        }, n.href))
      }) : null, /*#__PURE__*/(0, _jsxRuntime.jsx)(_Sidebar.default, {})]
    })
  });
}
_s(Drawer, "4oOK2DBhaSoGGja4mHCS3kAge1c=", false, function () {
  return [_useOverlayFocusDismiss.useOverlayFocusDismiss, _useFollowLink.useFollowLink];
});
_c = Drawer;
var _c;
$RefreshReg$(_c, "Drawer");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfc2RrIiwicmVxdWlyZSIsIl91c2VPdmVybGF5Rm9jdXNEaXNtaXNzIiwiX3VzZUZvbGxvd0xpbmsiLCJfbmF2aWdhdGlvblBvbGljeSIsIl9TaWRlYmFyIiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsIl9JY29uIiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsIkRyYXdlciIsInNpdGVUaXRsZSIsIm5hdiIsIm9uQ2xvc2UiLCJkaWFsb2dSZWYiLCJ1c2VPdmVybGF5Rm9jdXNEaXNtaXNzIiwiZm9sbG93IiwidXNlRm9sbG93TGluayIsImpzeCIsImNsYXNzTmFtZSIsIm9uQ2xpY2siLCJjaGlsZHJlbiIsImpzeHMiLCJyZWYiLCJ0YWJJbmRleCIsInJvbGUiLCJzdG9wUHJvcGFnYXRpb24iLCJuYW1lIiwibGVuZ3RoIiwibWFwIiwibiIsIkxpbmsiLCJocmVmIiwiY3VyIiwiZm9sbG93TGlua09uQ2xpY2siLCJrZXkiLCJsYWJlbCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiRHJhd2VyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBMaW5rIH0gZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9zZGsnO1xuaW1wb3J0IHsgdXNlT3ZlcmxheUZvY3VzRGlzbWlzcyB9IGZyb20gJy4uL2hvb2tzL3VzZU92ZXJsYXlGb2N1c0Rpc21pc3MnO1xuaW1wb3J0IHsgdXNlRm9sbG93TGluayB9IGZyb20gJy4uL2hvb2tzL3VzZUZvbGxvd0xpbmsnO1xuaW1wb3J0IHsgZm9sbG93TGlua09uQ2xpY2sgfSBmcm9tICcuLi9saWIvbmF2aWdhdGlvblBvbGljeSc7XG5pbXBvcnQgU2lkZWJhciBmcm9tICcuL1NpZGViYXInO1xuaW1wb3J0IEljb24gZnJvbSAnLi9JY29uJztcblxuaW50ZXJmYWNlIE5hdkl0ZW0ge1xuICAvKiogVGhlIGNvcnB1cyBrZXkgKFIzLTg3MiDigJQgdGhlIG5hdmlnYXRpb24gcG9saWN5J3MgdGFyZ2V0IG5hbWVzIGl0KS4gKi9cbiAga2V5OiBzdHJpbmc7XG4gIGhyZWY6IHN0cmluZztcbiAgbGFiZWw6IHN0cmluZztcbiAgY3VyOiBib29sZWFuO1xufVxuXG4vLyBgLmdyb3ZlLWRyYXdlcmAg4oCUIHRoZSBtb2JpbGUgbmF2IGRyYXdlcjogc2l0ZSBtYXJrICsgbmF2IGl0ZW1zICsgdGhlIGZ1bGxcbi8vIG5hbWVzcGFjZSB0cmVlLCBvdmVyIGEgZGlzbWlzcyBzY3JpbS4gVGhlIHBhbmVsIGNhcnJpZXMgdGhlIGRpYWxvZyBjb250cmFjdFxuLy8gKFIzLTYwOCk6IGZvY3VzIGluLCBUYWIgdHJhcHBlZCwgRXNjYXBlLCBmb2N1cyByZXR1cm4g4oCUIHZpYSB0aGUgc2hhcmVkXG4vLyBvdmVybGF5IGhvb2ssIHdob3NlIHN0YWNrIG1ha2VzIG5lc3RlZCBvdmVybGF5cyBjbG9zZSBvbmUgcGVyIEVzY2FwZS5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIERyYXdlcih7XG4gIHNpdGVUaXRsZSxcbiAgbmF2LFxuICBvbkNsb3NlLFxufToge1xuICBzaXRlVGl0bGU6IHN0cmluZztcbiAgbmF2OiBOYXZJdGVtW107XG4gIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XG59KSB7XG4gIGNvbnN0IGRpYWxvZ1JlZiA9IHVzZU92ZXJsYXlGb2N1c0Rpc21pc3ModHJ1ZSwgb25DbG9zZSk7XG4gIGNvbnN0IGZvbGxvdyA9IHVzZUZvbGxvd0xpbmsoKTtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImdyb3ZlLWRyYXdlclwiIG9uQ2xpY2s9e29uQ2xvc2V9PlxuICAgICAgPGRpdlxuICAgICAgICBjbGFzc05hbWU9XCJncm92ZS1kcmF3ZXJfX3BhbmVsXCJcbiAgICAgICAgcmVmPXtkaWFsb2dSZWZ9XG4gICAgICAgIHRhYkluZGV4PXstMX1cbiAgICAgICAgcm9sZT1cImRpYWxvZ1wiXG4gICAgICAgIGFyaWEtbW9kYWw9XCJ0cnVlXCJcbiAgICAgICAgYXJpYS1sYWJlbD1cIlNpdGUgbWVudVwiXG4gICAgICAgIG9uQ2xpY2s9eyhlKSA9PiBlLnN0b3BQcm9wYWdhdGlvbigpfVxuICAgICAgPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyb3ZlLWRyYXdlcl9faFwiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1rXCIgLz5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0XCI+e3NpdGVUaXRsZX08L3NwYW4+XG4gICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJ4XCIgYXJpYS1sYWJlbD1cIkNsb3NlIG1lbnVcIiBvbkNsaWNrPXtvbkNsb3NlfT5cbiAgICAgICAgICAgIDxJY29uIG5hbWU9XCJ4XCIgLz5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIHtuYXYubGVuZ3RoID8gKFxuICAgICAgICAgIDxuYXYgY2xhc3NOYW1lPVwiZ3JvdmUtZHJhd2VyX19uYXZcIj5cbiAgICAgICAgICAgIHtuYXYubWFwKChuKSA9PiAoXG4gICAgICAgICAgICAgIDxMaW5rXG4gICAgICAgICAgICAgICAga2V5PXtuLmhyZWZ9XG4gICAgICAgICAgICAgICAgaHJlZj17bi5ocmVmfVxuICAgICAgICAgICAgICAgIGRhdGEtY3VyPXtuLmN1ciA/ICcxJyA6ICcwJ31cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgZm9sbG93TGlua09uQ2xpY2soZm9sbG93LCB7IGtleTogbi5rZXksIGhyZWY6IG4uaHJlZiB9KShlKTtcbiAgICAgICAgICAgICAgICAgIG9uQ2xvc2UoKTtcbiAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAge24ubGFiZWx9XG4gICAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvbmF2PlxuICAgICAgICApIDogbnVsbH1cbiAgICAgICAgPFNpZGViYXIgLz5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBLElBQUFBLElBQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLHVCQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxjQUFBLEdBQUFGLE9BQUE7QUFDQSxJQUFBRyxpQkFBQSxHQUFBSCxPQUFBO0FBQ0EsSUFBQUksUUFBQSxHQUFBQyxzQkFBQSxDQUFBTCxPQUFBO0FBQ0EsSUFBQU0sS0FBQSxHQUFBRCxzQkFBQSxDQUFBTCxPQUFBO0FBQTBCLElBQUFPLFdBQUEsR0FBQVAsT0FBQTtBQUFBLElBQUFRLEVBQUEsR0FBQUMsWUFBQTtBQUFBLFNBQUFKLHVCQUFBSyxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBVTFCO0FBQ0E7QUFDQTtBQUNBO0FBQ2UsU0FBU0csTUFBTUEsQ0FBQztFQUM3QkMsU0FBUztFQUNUQyxHQUFHO0VBQ0hDO0FBS0YsQ0FBQyxFQUFFO0VBQUFSLEVBQUE7RUFDRCxNQUFNUyxTQUFTLEdBQUcsSUFBQUMsOENBQXNCLEVBQUMsSUFBSSxFQUFFRixPQUFPLENBQUM7RUFDdkQsTUFBTUcsTUFBTSxHQUFHLElBQUFDLDRCQUFhLEVBQUMsQ0FBQztFQUM5QixvQkFDRSxJQUFBYixXQUFBLENBQUFjLEdBQUE7SUFBS0MsU0FBUyxFQUFDLGNBQWM7SUFBQ0MsT0FBTyxFQUFFUCxPQUFRO0lBQUFRLFFBQUEsZUFDN0MsSUFBQWpCLFdBQUEsQ0FBQWtCLElBQUE7TUFDRUgsU0FBUyxFQUFDLHFCQUFxQjtNQUMvQkksR0FBRyxFQUFFVCxTQUFVO01BQ2ZVLFFBQVEsRUFBRSxDQUFDLENBQUU7TUFDYkMsSUFBSSxFQUFDLFFBQVE7TUFDYixjQUFXLE1BQU07TUFDakIsY0FBVyxXQUFXO01BQ3RCTCxPQUFPLEVBQUdiLENBQUMsSUFBS0EsQ0FBQyxDQUFDbUIsZUFBZSxDQUFDLENBQUU7TUFBQUwsUUFBQSxnQkFFcEMsSUFBQWpCLFdBQUEsQ0FBQWtCLElBQUE7UUFBS0gsU0FBUyxFQUFDLGlCQUFpQjtRQUFBRSxRQUFBLGdCQUM5QixJQUFBakIsV0FBQSxDQUFBYyxHQUFBO1VBQU1DLFNBQVMsRUFBQztRQUFJLENBQUUsQ0FBQyxlQUN2QixJQUFBZixXQUFBLENBQUFjLEdBQUE7VUFBTUMsU0FBUyxFQUFDLEdBQUc7VUFBQUUsUUFBQSxFQUFFVjtRQUFTLENBQU8sQ0FBQyxlQUN0QyxJQUFBUCxXQUFBLENBQUFjLEdBQUE7VUFBUUMsU0FBUyxFQUFDLEdBQUc7VUFBQyxjQUFXLFlBQVk7VUFBQ0MsT0FBTyxFQUFFUCxPQUFRO1VBQUFRLFFBQUEsZUFDN0QsSUFBQWpCLFdBQUEsQ0FBQWMsR0FBQSxFQUFDZixLQUFBLENBQUFNLE9BQUk7WUFBQ2tCLElBQUksRUFBQztVQUFHLENBQUU7UUFBQyxDQUNYLENBQUM7TUFBQSxDQUNOLENBQUMsRUFDTGYsR0FBRyxDQUFDZ0IsTUFBTSxnQkFDVCxJQUFBeEIsV0FBQSxDQUFBYyxHQUFBO1FBQUtDLFNBQVMsRUFBQyxtQkFBbUI7UUFBQUUsUUFBQSxFQUMvQlQsR0FBRyxDQUFDaUIsR0FBRyxDQUFFQyxDQUFDLGlCQUNULElBQUExQixXQUFBLENBQUFjLEdBQUEsRUFBQ3RCLElBQUEsQ0FBQW1DLElBQUk7VUFFSEMsSUFBSSxFQUFFRixDQUFDLENBQUNFLElBQUs7VUFDYixZQUFVRixDQUFDLENBQUNHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBSTtVQUM1QmIsT0FBTyxFQUFHYixDQUFDLElBQUs7WUFDZCxJQUFBMkIsbUNBQWlCLEVBQUNsQixNQUFNLEVBQUU7Y0FBRW1CLEdBQUcsRUFBRUwsQ0FBQyxDQUFDSyxHQUFHO2NBQUVILElBQUksRUFBRUYsQ0FBQyxDQUFDRTtZQUFLLENBQUMsQ0FBQyxDQUFDekIsQ0FBQyxDQUFDO1lBQzFETSxPQUFPLENBQUMsQ0FBQztVQUNYLENBQUU7VUFBQVEsUUFBQSxFQUVEUyxDQUFDLENBQUNNO1FBQUssR0FSSE4sQ0FBQyxDQUFDRSxJQVNILENBQ1A7TUFBQyxDQUNDLENBQUMsR0FDSixJQUFJLGVBQ1IsSUFBQTVCLFdBQUEsQ0FBQWMsR0FBQSxFQUFDakIsUUFBQSxDQUFBUSxPQUFPLElBQUUsQ0FBQztJQUFBLENBQ1I7RUFBQyxDQUNILENBQUM7QUFFVjtBQUFDSixFQUFBLENBbER1QkssTUFBTTtFQUFBLFFBU1ZLLDhDQUFzQixFQUN6QkUsNEJBQWE7QUFBQTtBQUFBb0IsRUFBQSxHQVZOM0IsTUFBTTtBQUFBLElBQUEyQixFQUFBO0FBQUFDLFlBQUEsQ0FBQUQsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}