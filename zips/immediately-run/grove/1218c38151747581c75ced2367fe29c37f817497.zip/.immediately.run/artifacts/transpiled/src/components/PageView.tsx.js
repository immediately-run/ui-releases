var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = PageView;
var _sdk = require("@immediately-run/sdk");
var _shell = require("../lib/shell");
var _content = require("../lib/content");
var _wiki = require("../lib/wiki");
var _useHeadingFragmentUrl = require("../hooks/useHeadingFragmentUrl");
var _useFollowLink = require("../hooks/useFollowLink");
var _navigationPolicy = require("../lib/navigationPolicy");
var _DirectoryView = _interopRequireDefault(require("./DirectoryView"));
var _EntryBody = _interopRequireDefault(require("./EntryBody"));
var _Icon = _interopRequireDefault(require("./Icon"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // `<PageView/>` — the reading view for the current entry: the 404/missing state,
// or the entry header + prose body (+ ToC / backlinks rails). This is what the
// INNERMOST `<Outlet/>` renders at the bottom of the layout chain. It carries no
// site chrome (nav / sidebar / footer) — that's the layout's job — so the page
// stays free of shell concerns.
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function PageView() {
  _s();
  // R3-872: the entry content lives in EntryBody (one renderer, shared with
  // GroveEntry); the page keeps only the page-level states (checking /
  // directory / missing) and the deep-link half it owns.
  const {
    entryKey,
    missing,
    suggestion,
    writable,
    openEditor,
    editBusy,
    editRefused,
    editHint,
    directory
  } = (0, _shell.useShell)();
  const follow = (0, _useFollowLink.useFollowLink)();

  // The reading view owns the headings, so it owns the outgoing half of deep
  // linking: same-page heading navigation writes the fragment into the host's
  // address bar (`useHeadingFragmentUrl` for the whole story).
  (0, _useHeadingFragmentUrl.useHeadingFragmentUrl)();

  // A folder URL. `checking` renders nothing rather than the 404: the readdir that
  // decides between them is one RPC away, and a 404 that appears and then turns into a
  // listing reads as a broken link that healed itself.
  if (directory.status === 'checking') return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    className: "grove-state",
    "data-state": "checking"
  });
  if (directory.status === 'ready') return /*#__PURE__*/(0, _jsxRuntime.jsx)(_DirectoryView.default, {});
  if (missing) {
    return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "grove-state",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "grove-state__art"
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("h2", {
        children: ["No entry at ", /*#__PURE__*/(0, _jsxRuntime.jsx)("code", {
          children: (0, _content.keyToRepoRel)(entryKey).replace(/^content/, '')
        }), "."]
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("p", {
        children: ["That link points to an entry that doesn\u2019t exist yet.", suggestion ? /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
          children: [" Did you mean ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_sdk.Link, {
            className: "grove-wikilink",
            "data-state": "ok",
            href: (0, _content.keyToHref)(suggestion),
            onClick: (0, _navigationPolicy.followLinkOnClick)(follow, {
              key: suggestion,
              href: (0, _content.keyToHref)(suggestion),
              from: entryKey
            }),
            children: (0, _wiki.crumb)(suggestion)
          }), "?"]
        }) : null]
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "grove-state__actions",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_sdk.Link, {
          className: "btn-ghost",
          href: "/",
          onClick: (0, _navigationPolicy.followLinkOnClick)(follow, {
            key: (0, _content.homeKey)(),
            href: '/',
            from: entryKey
          }),
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
            name: "chevron-right"
          }), " Back to home"]
        }), writable ? /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
            className: "btn-primary",
            "data-busy": editBusy ? '1' : '0',
            title: editHint,
            disabled: editBusy,
            onClick: () => openEditor(entryKey),
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
              name: "file-plus"
            }), editBusy ? 'Opening editor…' : 'Create it']
          }), editRefused && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
            className: "grove-edit-refused",
            role: "status",
            children: _shell.EDIT_REFUSED_NOTICE
          })]
        }) : null]
      })]
    });
  }
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_EntryBody.default, {
    entryKey: entryKey
  });
}
_s(PageView, "8Fc2cbevgXeGCcYMMtKOssx4tXc=", false, function () {
  return [_shell.useShell, _useFollowLink.useFollowLink, _useHeadingFragmentUrl.useHeadingFragmentUrl];
});
_c = PageView;
var _c;
$RefreshReg$(_c, "PageView");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfc2RrIiwicmVxdWlyZSIsIl9zaGVsbCIsIl9jb250ZW50IiwiX3dpa2kiLCJfdXNlSGVhZGluZ0ZyYWdtZW50VXJsIiwiX3VzZUZvbGxvd0xpbmsiLCJfbmF2aWdhdGlvblBvbGljeSIsIl9EaXJlY3RvcnlWaWV3IiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsIl9FbnRyeUJvZHkiLCJfSWNvbiIsIl9qc3hSdW50aW1lIiwiX3MiLCIkUmVmcmVzaFNpZyQiLCJlIiwiX19lc01vZHVsZSIsImRlZmF1bHQiLCJQYWdlVmlldyIsImVudHJ5S2V5IiwibWlzc2luZyIsInN1Z2dlc3Rpb24iLCJ3cml0YWJsZSIsIm9wZW5FZGl0b3IiLCJlZGl0QnVzeSIsImVkaXRSZWZ1c2VkIiwiZWRpdEhpbnQiLCJkaXJlY3RvcnkiLCJ1c2VTaGVsbCIsImZvbGxvdyIsInVzZUZvbGxvd0xpbmsiLCJ1c2VIZWFkaW5nRnJhZ21lbnRVcmwiLCJzdGF0dXMiLCJqc3giLCJjbGFzc05hbWUiLCJqc3hzIiwiY2hpbGRyZW4iLCJrZXlUb1JlcG9SZWwiLCJyZXBsYWNlIiwiRnJhZ21lbnQiLCJMaW5rIiwiaHJlZiIsImtleVRvSHJlZiIsIm9uQ2xpY2siLCJmb2xsb3dMaW5rT25DbGljayIsImtleSIsImZyb20iLCJjcnVtYiIsImhvbWVLZXkiLCJuYW1lIiwidGl0bGUiLCJkaXNhYmxlZCIsInJvbGUiLCJFRElUX1JFRlVTRURfTk9USUNFIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJQYWdlVmlldy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTGluayB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrJztcbmltcG9ydCB7IHVzZVNoZWxsLCBFRElUX1JFRlVTRURfTk9USUNFIH0gZnJvbSAnLi4vbGliL3NoZWxsJztcbmltcG9ydCB7IGtleVRvSHJlZiwga2V5VG9SZXBvUmVsLCBob21lS2V5IH0gZnJvbSAnLi4vbGliL2NvbnRlbnQnO1xuaW1wb3J0IHsgY3J1bWIgfSBmcm9tICcuLi9saWIvd2lraSc7XG5pbXBvcnQgeyB1c2VIZWFkaW5nRnJhZ21lbnRVcmwgfSBmcm9tICcuLi9ob29rcy91c2VIZWFkaW5nRnJhZ21lbnRVcmwnO1xuaW1wb3J0IHsgdXNlRm9sbG93TGluayB9IGZyb20gJy4uL2hvb2tzL3VzZUZvbGxvd0xpbmsnO1xuaW1wb3J0IHsgZm9sbG93TGlua09uQ2xpY2sgfSBmcm9tICcuLi9saWIvbmF2aWdhdGlvblBvbGljeSc7XG5pbXBvcnQgRGlyZWN0b3J5VmlldyBmcm9tICcuL0RpcmVjdG9yeVZpZXcnO1xuaW1wb3J0IEVudHJ5Qm9keSBmcm9tICcuL0VudHJ5Qm9keSc7XG5pbXBvcnQgSWNvbiBmcm9tICcuL0ljb24nO1xuXG4vLyBgPFBhZ2VWaWV3Lz5gIOKAlCB0aGUgcmVhZGluZyB2aWV3IGZvciB0aGUgY3VycmVudCBlbnRyeTogdGhlIDQwNC9taXNzaW5nIHN0YXRlLFxuLy8gb3IgdGhlIGVudHJ5IGhlYWRlciArIHByb3NlIGJvZHkgKCsgVG9DIC8gYmFja2xpbmtzIHJhaWxzKS4gVGhpcyBpcyB3aGF0IHRoZVxuLy8gSU5ORVJNT1NUIGA8T3V0bGV0Lz5gIHJlbmRlcnMgYXQgdGhlIGJvdHRvbSBvZiB0aGUgbGF5b3V0IGNoYWluLiBJdCBjYXJyaWVzIG5vXG4vLyBzaXRlIGNocm9tZSAobmF2IC8gc2lkZWJhciAvIGZvb3Rlcikg4oCUIHRoYXQncyB0aGUgbGF5b3V0J3Mgam9iIOKAlCBzbyB0aGUgcGFnZVxuLy8gc3RheXMgZnJlZSBvZiBzaGVsbCBjb25jZXJucy5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFBhZ2VWaWV3KCkge1xuICAvLyBSMy04NzI6IHRoZSBlbnRyeSBjb250ZW50IGxpdmVzIGluIEVudHJ5Qm9keSAob25lIHJlbmRlcmVyLCBzaGFyZWQgd2l0aFxuICAvLyBHcm92ZUVudHJ5KTsgdGhlIHBhZ2Uga2VlcHMgb25seSB0aGUgcGFnZS1sZXZlbCBzdGF0ZXMgKGNoZWNraW5nIC9cbiAgLy8gZGlyZWN0b3J5IC8gbWlzc2luZykgYW5kIHRoZSBkZWVwLWxpbmsgaGFsZiBpdCBvd25zLlxuICBjb25zdCB7IGVudHJ5S2V5LCBtaXNzaW5nLCBzdWdnZXN0aW9uLCB3cml0YWJsZSwgb3BlbkVkaXRvciwgZWRpdEJ1c3ksIGVkaXRSZWZ1c2VkLCBlZGl0SGludCwgZGlyZWN0b3J5IH0gPVxuICAgIHVzZVNoZWxsKCk7XG4gIGNvbnN0IGZvbGxvdyA9IHVzZUZvbGxvd0xpbmsoKTtcblxuICAvLyBUaGUgcmVhZGluZyB2aWV3IG93bnMgdGhlIGhlYWRpbmdzLCBzbyBpdCBvd25zIHRoZSBvdXRnb2luZyBoYWxmIG9mIGRlZXBcbiAgLy8gbGlua2luZzogc2FtZS1wYWdlIGhlYWRpbmcgbmF2aWdhdGlvbiB3cml0ZXMgdGhlIGZyYWdtZW50IGludG8gdGhlIGhvc3Qnc1xuICAvLyBhZGRyZXNzIGJhciAoYHVzZUhlYWRpbmdGcmFnbWVudFVybGAgZm9yIHRoZSB3aG9sZSBzdG9yeSkuXG4gIHVzZUhlYWRpbmdGcmFnbWVudFVybCgpO1xuXG4gIC8vIEEgZm9sZGVyIFVSTC4gYGNoZWNraW5nYCByZW5kZXJzIG5vdGhpbmcgcmF0aGVyIHRoYW4gdGhlIDQwNDogdGhlIHJlYWRkaXIgdGhhdFxuICAvLyBkZWNpZGVzIGJldHdlZW4gdGhlbSBpcyBvbmUgUlBDIGF3YXksIGFuZCBhIDQwNCB0aGF0IGFwcGVhcnMgYW5kIHRoZW4gdHVybnMgaW50byBhXG4gIC8vIGxpc3RpbmcgcmVhZHMgYXMgYSBicm9rZW4gbGluayB0aGF0IGhlYWxlZCBpdHNlbGYuXG4gIGlmIChkaXJlY3Rvcnkuc3RhdHVzID09PSAnY2hlY2tpbmcnKSByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJncm92ZS1zdGF0ZVwiIGRhdGEtc3RhdGU9XCJjaGVja2luZ1wiIC8+O1xuICBpZiAoZGlyZWN0b3J5LnN0YXR1cyA9PT0gJ3JlYWR5JykgcmV0dXJuIDxEaXJlY3RvcnlWaWV3IC8+O1xuXG4gIGlmIChtaXNzaW5nKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JvdmUtc3RhdGVcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncm92ZS1zdGF0ZV9fYXJ0XCIgLz5cbiAgICAgICAgPGgyPk5vIGVudHJ5IGF0IDxjb2RlPntrZXlUb1JlcG9SZWwoZW50cnlLZXkpLnJlcGxhY2UoL15jb250ZW50LywgJycpfTwvY29kZT4uPC9oMj5cbiAgICAgICAgPHA+XG4gICAgICAgICAgVGhhdCBsaW5rIHBvaW50cyB0byBhbiBlbnRyeSB0aGF0IGRvZXNu4oCZdCBleGlzdCB5ZXQuXG4gICAgICAgICAge3N1Z2dlc3Rpb24gPyA8PiBEaWQgeW91IG1lYW4gPExpbmsgY2xhc3NOYW1lPVwiZ3JvdmUtd2lraWxpbmtcIiBkYXRhLXN0YXRlPVwib2tcIiBocmVmPXtrZXlUb0hyZWYoc3VnZ2VzdGlvbil9IG9uQ2xpY2s9e2ZvbGxvd0xpbmtPbkNsaWNrKGZvbGxvdywgeyBrZXk6IHN1Z2dlc3Rpb24sIGhyZWY6IGtleVRvSHJlZihzdWdnZXN0aW9uKSwgZnJvbTogZW50cnlLZXkgfSl9PntjcnVtYihzdWdnZXN0aW9uKX08L0xpbms+PzwvPiA6IG51bGx9XG4gICAgICAgIDwvcD5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncm92ZS1zdGF0ZV9fYWN0aW9uc1wiPlxuICAgICAgICAgIDxMaW5rIGNsYXNzTmFtZT1cImJ0bi1naG9zdFwiIGhyZWY9XCIvXCIgb25DbGljaz17Zm9sbG93TGlua09uQ2xpY2soZm9sbG93LCB7IGtleTogaG9tZUtleSgpLCBocmVmOiAnLycsIGZyb206IGVudHJ5S2V5IH0pfT48SWNvbiBuYW1lPVwiY2hldnJvbi1yaWdodFwiIC8+IEJhY2sgdG8gaG9tZTwvTGluaz5cbiAgICAgICAgICB7d3JpdGFibGUgPyAoXG4gICAgICAgICAgICA8PlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJidG4tcHJpbWFyeVwiXG4gICAgICAgICAgICAgIGRhdGEtYnVzeT17ZWRpdEJ1c3kgPyAnMScgOiAnMCd9XG4gICAgICAgICAgICAgIHRpdGxlPXtlZGl0SGludH1cbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e2VkaXRCdXN5fVxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvcGVuRWRpdG9yKGVudHJ5S2V5KX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPEljb24gbmFtZT1cImZpbGUtcGx1c1wiIC8+e2VkaXRCdXN5ID8gJ09wZW5pbmcgZWRpdG9y4oCmJyA6ICdDcmVhdGUgaXQnfVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIHtlZGl0UmVmdXNlZCAmJiAoXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZ3JvdmUtZWRpdC1yZWZ1c2VkXCIgcm9sZT1cInN0YXR1c1wiPntFRElUX1JFRlVTRURfTk9USUNFfTwvc3Bhbj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvPlxuICAgICAgICAgICkgOiBudWxsfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgICk7XG4gIH1cblxuICByZXR1cm4gPEVudHJ5Qm9keSBlbnRyeUtleT17ZW50cnlLZXl9IC8+O1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFBQSxJQUFBQSxJQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxNQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxRQUFBLEdBQUFGLE9BQUE7QUFDQSxJQUFBRyxLQUFBLEdBQUFILE9BQUE7QUFDQSxJQUFBSSxzQkFBQSxHQUFBSixPQUFBO0FBQ0EsSUFBQUssY0FBQSxHQUFBTCxPQUFBO0FBQ0EsSUFBQU0saUJBQUEsR0FBQU4sT0FBQTtBQUNBLElBQUFPLGNBQUEsR0FBQUMsc0JBQUEsQ0FBQVIsT0FBQTtBQUNBLElBQUFTLFVBQUEsR0FBQUQsc0JBQUEsQ0FBQVIsT0FBQTtBQUNBLElBQUFVLEtBQUEsR0FBQUYsc0JBQUEsQ0FBQVIsT0FBQTtBQUEwQixJQUFBVyxXQUFBLEdBQUFYLE9BQUE7QUFBQSxJQUFBWSxFQUFBLEdBQUFDLFlBQUEsSUFFMUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUFBLFNBQUFMLHVCQUFBTSxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBQ2UsU0FBU0csUUFBUUEsQ0FBQSxFQUFHO0VBQUFMLEVBQUE7RUFDakM7RUFDQTtFQUNBO0VBQ0EsTUFBTTtJQUFFTSxRQUFRO0lBQUVDLE9BQU87SUFBRUMsVUFBVTtJQUFFQyxRQUFRO0lBQUVDLFVBQVU7SUFBRUMsUUFBUTtJQUFFQyxXQUFXO0lBQUVDLFFBQVE7SUFBRUM7RUFBVSxDQUFDLEdBQ3ZHLElBQUFDLGVBQVEsRUFBQyxDQUFDO0VBQ1osTUFBTUMsTUFBTSxHQUFHLElBQUFDLDRCQUFhLEVBQUMsQ0FBQzs7RUFFOUI7RUFDQTtFQUNBO0VBQ0EsSUFBQUMsNENBQXFCLEVBQUMsQ0FBQzs7RUFFdkI7RUFDQTtFQUNBO0VBQ0EsSUFBSUosU0FBUyxDQUFDSyxNQUFNLEtBQUssVUFBVSxFQUFFLG9CQUFPLElBQUFwQixXQUFBLENBQUFxQixHQUFBO0lBQUtDLFNBQVMsRUFBQyxhQUFhO0lBQUMsY0FBVztFQUFVLENBQUUsQ0FBQztFQUNqRyxJQUFJUCxTQUFTLENBQUNLLE1BQU0sS0FBSyxPQUFPLEVBQUUsb0JBQU8sSUFBQXBCLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ3pCLGNBQUEsQ0FBQVMsT0FBYSxJQUFFLENBQUM7RUFFMUQsSUFBSUcsT0FBTyxFQUFFO0lBQ1gsb0JBQ0UsSUFBQVIsV0FBQSxDQUFBdUIsSUFBQTtNQUFLRCxTQUFTLEVBQUMsYUFBYTtNQUFBRSxRQUFBLGdCQUMxQixJQUFBeEIsV0FBQSxDQUFBcUIsR0FBQTtRQUFLQyxTQUFTLEVBQUM7TUFBa0IsQ0FBRSxDQUFDLGVBQ3BDLElBQUF0QixXQUFBLENBQUF1QixJQUFBO1FBQUFDLFFBQUEsR0FBSSxjQUFZLG1CQUFBeEIsV0FBQSxDQUFBcUIsR0FBQTtVQUFBRyxRQUFBLEVBQU8sSUFBQUMscUJBQVksRUFBQ2xCLFFBQVEsQ0FBQyxDQUFDbUIsT0FBTyxDQUFDLFVBQVUsRUFBRSxFQUFFO1FBQUMsQ0FBTyxDQUFDLEtBQUM7TUFBQSxDQUFJLENBQUMsZUFDbkYsSUFBQTFCLFdBQUEsQ0FBQXVCLElBQUE7UUFBQUMsUUFBQSxHQUFHLDJEQUVELEVBQUNmLFVBQVUsZ0JBQUcsSUFBQVQsV0FBQSxDQUFBdUIsSUFBQSxFQUFBdkIsV0FBQSxDQUFBMkIsUUFBQTtVQUFBSCxRQUFBLEdBQUUsZ0JBQWMsbUJBQUF4QixXQUFBLENBQUFxQixHQUFBLEVBQUNqQyxJQUFBLENBQUF3QyxJQUFJO1lBQUNOLFNBQVMsRUFBQyxnQkFBZ0I7WUFBQyxjQUFXLElBQUk7WUFBQ08sSUFBSSxFQUFFLElBQUFDLGtCQUFTLEVBQUNyQixVQUFVLENBQUU7WUFBQ3NCLE9BQU8sRUFBRSxJQUFBQyxtQ0FBaUIsRUFBQ2YsTUFBTSxFQUFFO2NBQUVnQixHQUFHLEVBQUV4QixVQUFVO2NBQUVvQixJQUFJLEVBQUUsSUFBQUMsa0JBQVMsRUFBQ3JCLFVBQVUsQ0FBQztjQUFFeUIsSUFBSSxFQUFFM0I7WUFBUyxDQUFDLENBQUU7WUFBQWlCLFFBQUEsRUFBRSxJQUFBVyxXQUFLLEVBQUMxQixVQUFVO1VBQUMsQ0FBTyxDQUFDLEtBQUM7UUFBQSxDQUFFLENBQUMsR0FBRyxJQUFJO01BQUEsQ0FDdFAsQ0FBQyxlQUNKLElBQUFULFdBQUEsQ0FBQXVCLElBQUE7UUFBS0QsU0FBUyxFQUFDLHNCQUFzQjtRQUFBRSxRQUFBLGdCQUNuQyxJQUFBeEIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDbkMsSUFBQSxDQUFBd0MsSUFBSTtVQUFDTixTQUFTLEVBQUMsV0FBVztVQUFDTyxJQUFJLEVBQUMsR0FBRztVQUFDRSxPQUFPLEVBQUUsSUFBQUMsbUNBQWlCLEVBQUNmLE1BQU0sRUFBRTtZQUFFZ0IsR0FBRyxFQUFFLElBQUFHLGdCQUFPLEVBQUMsQ0FBQztZQUFFUCxJQUFJLEVBQUUsR0FBRztZQUFFSyxJQUFJLEVBQUUzQjtVQUFTLENBQUMsQ0FBRTtVQUFBaUIsUUFBQSxnQkFBQyxJQUFBeEIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDdEIsS0FBQSxDQUFBTSxPQUFJO1lBQUNnQyxJQUFJLEVBQUM7VUFBZSxDQUFFLENBQUMsaUJBQWE7UUFBQSxDQUFNLENBQUMsRUFDeEszQixRQUFRLGdCQUNQLElBQUFWLFdBQUEsQ0FBQXVCLElBQUEsRUFBQXZCLFdBQUEsQ0FBQTJCLFFBQUE7VUFBQUgsUUFBQSxnQkFDQSxJQUFBeEIsV0FBQSxDQUFBdUIsSUFBQTtZQUNFRCxTQUFTLEVBQUMsYUFBYTtZQUN2QixhQUFXVixRQUFRLEdBQUcsR0FBRyxHQUFHLEdBQUk7WUFDaEMwQixLQUFLLEVBQUV4QixRQUFTO1lBQ2hCeUIsUUFBUSxFQUFFM0IsUUFBUztZQUNuQm1CLE9BQU8sRUFBRUEsQ0FBQSxLQUFNcEIsVUFBVSxDQUFDSixRQUFRLENBQUU7WUFBQWlCLFFBQUEsZ0JBRXBDLElBQUF4QixXQUFBLENBQUFxQixHQUFBLEVBQUN0QixLQUFBLENBQUFNLE9BQUk7Y0FBQ2dDLElBQUksRUFBQztZQUFXLENBQUUsQ0FBQyxFQUFDekIsUUFBUSxHQUFHLGlCQUFpQixHQUFHLFdBQVc7VUFBQSxDQUM5RCxDQUFDLEVBQ05DLFdBQVcsaUJBQ1YsSUFBQWIsV0FBQSxDQUFBcUIsR0FBQTtZQUFNQyxTQUFTLEVBQUMsb0JBQW9CO1lBQUNrQixJQUFJLEVBQUMsUUFBUTtZQUFBaEIsUUFBQSxFQUFFaUI7VUFBbUIsQ0FBTyxDQUMvRTtRQUFBLENBQ0QsQ0FBQyxHQUNELElBQUk7TUFBQSxDQUNMLENBQUM7SUFBQSxDQUNILENBQUM7RUFFVjtFQUVBLG9CQUFPLElBQUF6QyxXQUFBLENBQUFxQixHQUFBLEVBQUN2QixVQUFBLENBQUFPLE9BQVM7SUFBQ0UsUUFBUSxFQUFFQTtFQUFTLENBQUUsQ0FBQztBQUMxQztBQUFDTixFQUFBLENBcER1QkssUUFBUTtFQUFBLFFBSzVCVSxlQUFRLEVBQ0tFLDRCQUFhLEVBSzVCQyw0Q0FBcUI7QUFBQTtBQUFBdUIsRUFBQSxHQVhDcEMsUUFBUTtBQUFBLElBQUFvQyxFQUFBO0FBQUFDLFlBQUEsQ0FBQUQsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}