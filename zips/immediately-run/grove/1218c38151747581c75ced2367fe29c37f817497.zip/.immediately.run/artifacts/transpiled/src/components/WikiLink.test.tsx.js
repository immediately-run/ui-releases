var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

var _vitest = require("vitest");
var _react = require("react");
var _client = require("react-dom/client");
var _TinkerableContext = require("@immediately-run/sdk/TinkerableContext");
var _contentRoot = require("../lib/contentRoot");
var _jsxRuntime = require("react/jsx-runtime");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; } // @vitest-environment jsdom
// R3-871 — WikiLink resolves against the entry it renders inside, not the URL.
// The URL routes to content/home.mdx while an EntryContext provider says this
// subtree renders content/teams/engineering.mdx: a relative link must resolve
// from engineering's directory, and "self" must be judged against engineering.
// Keys come from the real key grammar (sandboxPathToKey/hrefKeyCandidates), the
// same fixtures shape the other component tests use.
const {
  default: WikiLink
} = await Promise.resolve().then(() => _interopRequireWildcard(require('./WikiLink')));
const {
  EntryContext
} = await Promise.resolve().then(() => _interopRequireWildcard(require('../hooks/useEntryKey')));
const METADATA = {
  '/app/content/home.mdx': {
    title: 'Home'
  },
  '/app/content/teams/engineering.mdx': {
    title: 'Engineering'
  },
  '/app/content/people/ada-lovelace.mdx': {
    title: 'Ada Lovelace'
  }
};

/** The URL routes HOME; the provider (when given) says which entry we render. */
function host(children, entryKey, sandboxPath = '/files/content/home.mdx') {
  const value = {
    outerHref: 'https://immediately.run/present/github/o/r/main/files/content/home.mdx',
    navigationState: {
      mode: 'present',
      namespace: 'github',
      provider: 'github',
      repository: 'o/r',
      ref: 'main',
      sandboxPath,
      hash: '',
      search: ''
    },
    routingSpec: {
      routes: []
    },
    filesMetadata: METADATA
  };
  const inner = /*#__PURE__*/(0, _jsxRuntime.jsx)(_TinkerableContext.TinkerableContext.Provider, {
    value: value,
    children: children
  });
  return entryKey === undefined ? inner : /*#__PURE__*/(0, _jsxRuntime.jsx)(EntryContext.Provider, {
    value: {
      entryKey
    },
    children: inner
  });
}
async function render(node) {
  const container = document.createElement('div');
  document.body.appendChild(container);
  await (0, _react.act)(async () => {
    (0, _client.createRoot)(container).render(node);
  });
  return container;
}
(0, _vitest.describe)('WikiLink — the entry context decides the base (R3-871)', () => {
  (0, _vitest.beforeEach)(() => {
    (0, _contentRoot.setContentRoot)('/app/content/');
    return () => (0, _contentRoot.resetContentRoot)();
  });
  (0, _vitest.it)('a relative link inside a non-routed entry resolves against that entry', async () => {
    // the URL routes home; the subtree renders engineering (teams/engineering.mdx).
    const el = await render(host(/*#__PURE__*/(0, _jsxRuntime.jsx)(WikiLink, {
      href: "../people/ada-lovelace.mdx",
      children: "Ada"
    }), '/app/content/teams/engineering.mdx'));
    const link = el.querySelector('.grove-wikilink');
    (0, _vitest.expect)(link).not.toBeNull();
    (0, _vitest.expect)(link.getAttribute('data-state')).toBe('ok');
    (0, _vitest.expect)(link.getAttribute('href')).toContain('people/ada-lovelace.mdx');
  });
  (0, _vitest.it)('the same relative link with no provider resolves against the routed entry (home)', async () => {
    // From home/, ../people/ada-lovelace.mdx lands outside the corpus → broken.
    // This is the default-preserving seam: same input, different base, by design.
    const el = await render(host(/*#__PURE__*/(0, _jsxRuntime.jsx)(WikiLink, {
      href: "../people/ada-lovelace.mdx",
      children: "Ada"
    })));
    const link = el.querySelector('.grove-wikilink');
    (0, _vitest.expect)(link.getAttribute('data-state')).toBe('broken');
  });
  (0, _vitest.it)('a link to the context entry\'s own entry is self — judged against the entry, not the URL', async () => {
    const el = await render(host(/*#__PURE__*/(0, _jsxRuntime.jsx)(WikiLink, {
      href: "engineering.mdx",
      children: "this very page"
    }), '/app/content/teams/engineering.mdx'));
    const link = el.querySelector('.grove-wikilink');
    (0, _vitest.expect)(link.getAttribute('data-state')).toBe('self');
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZXN0IiwicmVxdWlyZSIsIl9yZWFjdCIsIl9jbGllbnQiLCJfVGlua2VyYWJsZUNvbnRleHQiLCJfY29udGVudFJvb3QiLCJfanN4UnVudGltZSIsIl9nZXRSZXF1aXJlV2lsZGNhcmRDYWNoZSIsImUiLCJXZWFrTWFwIiwiciIsInQiLCJfaW50ZXJvcFJlcXVpcmVXaWxkY2FyZCIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiaGFzIiwiZ2V0IiwibiIsIl9fcHJvdG9fXyIsImEiLCJPYmplY3QiLCJkZWZpbmVQcm9wZXJ0eSIsImdldE93blByb3BlcnR5RGVzY3JpcHRvciIsInUiLCJoYXNPd25Qcm9wZXJ0eSIsImNhbGwiLCJpIiwic2V0IiwiV2lraUxpbmsiLCJQcm9taXNlIiwicmVzb2x2ZSIsInRoZW4iLCJFbnRyeUNvbnRleHQiLCJNRVRBREFUQSIsInRpdGxlIiwiaG9zdCIsImNoaWxkcmVuIiwiZW50cnlLZXkiLCJzYW5kYm94UGF0aCIsInZhbHVlIiwib3V0ZXJIcmVmIiwibmF2aWdhdGlvblN0YXRlIiwibW9kZSIsIm5hbWVzcGFjZSIsInByb3ZpZGVyIiwicmVwb3NpdG9yeSIsInJlZiIsImhhc2giLCJzZWFyY2giLCJyb3V0aW5nU3BlYyIsInJvdXRlcyIsImZpbGVzTWV0YWRhdGEiLCJpbm5lciIsImpzeCIsIlRpbmtlcmFibGVDb250ZXh0IiwiUHJvdmlkZXIiLCJ1bmRlZmluZWQiLCJyZW5kZXIiLCJub2RlIiwiY29udGFpbmVyIiwiZG9jdW1lbnQiLCJjcmVhdGVFbGVtZW50IiwiYm9keSIsImFwcGVuZENoaWxkIiwiYWN0IiwiY3JlYXRlUm9vdCIsImRlc2NyaWJlIiwiYmVmb3JlRWFjaCIsInNldENvbnRlbnRSb290IiwicmVzZXRDb250ZW50Um9vdCIsIml0IiwiZWwiLCJocmVmIiwibGluayIsInF1ZXJ5U2VsZWN0b3IiLCJleHBlY3QiLCJub3QiLCJ0b0JlTnVsbCIsImdldEF0dHJpYnV0ZSIsInRvQmUiLCJ0b0NvbnRhaW4iXSwic291cmNlcyI6WyJXaWtpTGluay50ZXN0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBAdml0ZXN0LWVudmlyb25tZW50IGpzZG9tXG4vLyBSMy04NzEg4oCUIFdpa2lMaW5rIHJlc29sdmVzIGFnYWluc3QgdGhlIGVudHJ5IGl0IHJlbmRlcnMgaW5zaWRlLCBub3QgdGhlIFVSTC5cbi8vIFRoZSBVUkwgcm91dGVzIHRvIGNvbnRlbnQvaG9tZS5tZHggd2hpbGUgYW4gRW50cnlDb250ZXh0IHByb3ZpZGVyIHNheXMgdGhpc1xuLy8gc3VidHJlZSByZW5kZXJzIGNvbnRlbnQvdGVhbXMvZW5naW5lZXJpbmcubWR4OiBhIHJlbGF0aXZlIGxpbmsgbXVzdCByZXNvbHZlXG4vLyBmcm9tIGVuZ2luZWVyaW5nJ3MgZGlyZWN0b3J5LCBhbmQgXCJzZWxmXCIgbXVzdCBiZSBqdWRnZWQgYWdhaW5zdCBlbmdpbmVlcmluZy5cbi8vIEtleXMgY29tZSBmcm9tIHRoZSByZWFsIGtleSBncmFtbWFyIChzYW5kYm94UGF0aFRvS2V5L2hyZWZLZXlDYW5kaWRhdGVzKSwgdGhlXG4vLyBzYW1lIGZpeHR1cmVzIHNoYXBlIHRoZSBvdGhlciBjb21wb25lbnQgdGVzdHMgdXNlLlxuaW1wb3J0IHsgZGVzY3JpYmUsIGl0LCBleHBlY3QsIGJlZm9yZUVhY2ggfSBmcm9tICd2aXRlc3QnO1xuaW1wb3J0IHsgYWN0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgY3JlYXRlUm9vdCB9IGZyb20gJ3JlYWN0LWRvbS9jbGllbnQnO1xuaW1wb3J0IHR5cGUgeyBSZWFjdE5vZGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBUaW5rZXJhYmxlQ29udGV4dCB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrL1RpbmtlcmFibGVDb250ZXh0JztcbmltcG9ydCB7IHJlc2V0Q29udGVudFJvb3QsIHNldENvbnRlbnRSb290IH0gZnJvbSAnLi4vbGliL2NvbnRlbnRSb290JztcblxuY29uc3QgeyBkZWZhdWx0OiBXaWtpTGluayB9ID0gYXdhaXQgaW1wb3J0KCcuL1dpa2lMaW5rJyk7XG5jb25zdCB7IEVudHJ5Q29udGV4dCB9ID0gYXdhaXQgaW1wb3J0KCcuLi9ob29rcy91c2VFbnRyeUtleScpO1xuXG5jb25zdCBNRVRBREFUQSA9IHtcbiAgJy9hcHAvY29udGVudC9ob21lLm1keCc6IHsgdGl0bGU6ICdIb21lJyB9LFxuICAnL2FwcC9jb250ZW50L3RlYW1zL2VuZ2luZWVyaW5nLm1keCc6IHsgdGl0bGU6ICdFbmdpbmVlcmluZycgfSxcbiAgJy9hcHAvY29udGVudC9wZW9wbGUvYWRhLWxvdmVsYWNlLm1keCc6IHsgdGl0bGU6ICdBZGEgTG92ZWxhY2UnIH0sXG59O1xuXG4vKiogVGhlIFVSTCByb3V0ZXMgSE9NRTsgdGhlIHByb3ZpZGVyICh3aGVuIGdpdmVuKSBzYXlzIHdoaWNoIGVudHJ5IHdlIHJlbmRlci4gKi9cbmZ1bmN0aW9uIGhvc3QoY2hpbGRyZW46IFJlYWN0Tm9kZSwgZW50cnlLZXk/OiBzdHJpbmcsIHNhbmRib3hQYXRoID0gJy9maWxlcy9jb250ZW50L2hvbWUubWR4Jykge1xuICBjb25zdCB2YWx1ZSA9IHtcbiAgICBvdXRlckhyZWY6ICdodHRwczovL2ltbWVkaWF0ZWx5LnJ1bi9wcmVzZW50L2dpdGh1Yi9vL3IvbWFpbi9maWxlcy9jb250ZW50L2hvbWUubWR4JyxcbiAgICBuYXZpZ2F0aW9uU3RhdGU6IHsgbW9kZTogJ3ByZXNlbnQnLCBuYW1lc3BhY2U6ICdnaXRodWInLCBwcm92aWRlcjogJ2dpdGh1YicsIHJlcG9zaXRvcnk6ICdvL3InLCByZWY6ICdtYWluJywgc2FuZGJveFBhdGgsIGhhc2g6ICcnLCBzZWFyY2g6ICcnIH0sXG4gICAgcm91dGluZ1NwZWM6IHsgcm91dGVzOiBbXSB9LFxuICAgIGZpbGVzTWV0YWRhdGE6IE1FVEFEQVRBLFxuICB9O1xuICBjb25zdCBpbm5lciA9IDxUaW5rZXJhYmxlQ29udGV4dC5Qcm92aWRlciB2YWx1ZT17dmFsdWUgYXMgbmV2ZXJ9PntjaGlsZHJlbn08L1RpbmtlcmFibGVDb250ZXh0LlByb3ZpZGVyPjtcbiAgcmV0dXJuIGVudHJ5S2V5ID09PSB1bmRlZmluZWQgPyBpbm5lciA6IDxFbnRyeUNvbnRleHQuUHJvdmlkZXIgdmFsdWU9e3sgZW50cnlLZXkgfX0+e2lubmVyfTwvRW50cnlDb250ZXh0LlByb3ZpZGVyPjtcbn1cblxuYXN5bmMgZnVuY3Rpb24gcmVuZGVyKG5vZGU6IFJlYWN0Tm9kZSk6IFByb21pc2U8SFRNTEVsZW1lbnQ+IHtcbiAgY29uc3QgY29udGFpbmVyID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoY29udGFpbmVyKTtcbiAgYXdhaXQgYWN0KGFzeW5jICgpID0+IHtcbiAgICBjcmVhdGVSb290KGNvbnRhaW5lcikucmVuZGVyKG5vZGUpO1xuICB9KTtcbiAgcmV0dXJuIGNvbnRhaW5lcjtcbn1cblxuZGVzY3JpYmUoJ1dpa2lMaW5rIOKAlCB0aGUgZW50cnkgY29udGV4dCBkZWNpZGVzIHRoZSBiYXNlIChSMy04NzEpJywgKCkgPT4ge1xuICBiZWZvcmVFYWNoKCgpID0+IHtcbiAgICBzZXRDb250ZW50Um9vdCgnL2FwcC9jb250ZW50LycpO1xuICAgIHJldHVybiAoKSA9PiByZXNldENvbnRlbnRSb290KCk7XG4gIH0pO1xuXG4gIGl0KCdhIHJlbGF0aXZlIGxpbmsgaW5zaWRlIGEgbm9uLXJvdXRlZCBlbnRyeSByZXNvbHZlcyBhZ2FpbnN0IHRoYXQgZW50cnknLCBhc3luYyAoKSA9PiB7XG4gICAgLy8gdGhlIFVSTCByb3V0ZXMgaG9tZTsgdGhlIHN1YnRyZWUgcmVuZGVycyBlbmdpbmVlcmluZyAodGVhbXMvZW5naW5lZXJpbmcubWR4KS5cbiAgICBjb25zdCBlbCA9IGF3YWl0IHJlbmRlcihcbiAgICAgIGhvc3QoXG4gICAgICAgIDxXaWtpTGluayBocmVmPVwiLi4vcGVvcGxlL2FkYS1sb3ZlbGFjZS5tZHhcIj5BZGE8L1dpa2lMaW5rPixcbiAgICAgICAgJy9hcHAvY29udGVudC90ZWFtcy9lbmdpbmVlcmluZy5tZHgnLFxuICAgICAgKSxcbiAgICApO1xuICAgIGNvbnN0IGxpbmsgPSBlbC5xdWVyeVNlbGVjdG9yKCcuZ3JvdmUtd2lraWxpbmsnKSBhcyBIVE1MRWxlbWVudDtcbiAgICBleHBlY3QobGluaykubm90LnRvQmVOdWxsKCk7XG4gICAgZXhwZWN0KGxpbmsuZ2V0QXR0cmlidXRlKCdkYXRhLXN0YXRlJykpLnRvQmUoJ29rJyk7XG4gICAgZXhwZWN0KGxpbmsuZ2V0QXR0cmlidXRlKCdocmVmJykpLnRvQ29udGFpbigncGVvcGxlL2FkYS1sb3ZlbGFjZS5tZHgnKTtcbiAgfSk7XG5cbiAgaXQoJ3RoZSBzYW1lIHJlbGF0aXZlIGxpbmsgd2l0aCBubyBwcm92aWRlciByZXNvbHZlcyBhZ2FpbnN0IHRoZSByb3V0ZWQgZW50cnkgKGhvbWUpJywgYXN5bmMgKCkgPT4ge1xuICAgIC8vIEZyb20gaG9tZS8sIC4uL3Blb3BsZS9hZGEtbG92ZWxhY2UubWR4IGxhbmRzIG91dHNpZGUgdGhlIGNvcnB1cyDihpIgYnJva2VuLlxuICAgIC8vIFRoaXMgaXMgdGhlIGRlZmF1bHQtcHJlc2VydmluZyBzZWFtOiBzYW1lIGlucHV0LCBkaWZmZXJlbnQgYmFzZSwgYnkgZGVzaWduLlxuICAgIGNvbnN0IGVsID0gYXdhaXQgcmVuZGVyKGhvc3QoPFdpa2lMaW5rIGhyZWY9XCIuLi9wZW9wbGUvYWRhLWxvdmVsYWNlLm1keFwiPkFkYTwvV2lraUxpbms+KSk7XG4gICAgY29uc3QgbGluayA9IGVsLnF1ZXJ5U2VsZWN0b3IoJy5ncm92ZS13aWtpbGluaycpIGFzIEhUTUxFbGVtZW50O1xuICAgIGV4cGVjdChsaW5rLmdldEF0dHJpYnV0ZSgnZGF0YS1zdGF0ZScpKS50b0JlKCdicm9rZW4nKTtcbiAgfSk7XG5cbiAgaXQoJ2EgbGluayB0byB0aGUgY29udGV4dCBlbnRyeVxcJ3Mgb3duIGVudHJ5IGlzIHNlbGYg4oCUIGp1ZGdlZCBhZ2FpbnN0IHRoZSBlbnRyeSwgbm90IHRoZSBVUkwnLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgZWwgPSBhd2FpdCByZW5kZXIoXG4gICAgICBob3N0KFxuICAgICAgICA8V2lraUxpbmsgaHJlZj1cImVuZ2luZWVyaW5nLm1keFwiPnRoaXMgdmVyeSBwYWdlPC9XaWtpTGluaz4sXG4gICAgICAgICcvYXBwL2NvbnRlbnQvdGVhbXMvZW5naW5lZXJpbmcubWR4JyxcbiAgICAgICksXG4gICAgKTtcbiAgICBjb25zdCBsaW5rID0gZWwucXVlcnlTZWxlY3RvcignLmdyb3ZlLXdpa2lsaW5rJykgYXMgSFRNTEVsZW1lbnQ7XG4gICAgZXhwZWN0KGxpbmsuZ2V0QXR0cmlidXRlKCdkYXRhLXN0YXRlJykpLnRvQmUoJ3NlbGYnKTtcbiAgfSk7XG59KTtcbiJdLCJtYXBwaW5ncyI6Ijs7QUFPQSxJQUFBQSxPQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxNQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxPQUFBLEdBQUFGLE9BQUE7QUFFQSxJQUFBRyxrQkFBQSxHQUFBSCxPQUFBO0FBQ0EsSUFBQUksWUFBQSxHQUFBSixPQUFBO0FBQXNFLElBQUFLLFdBQUEsR0FBQUwsT0FBQTtBQUFBLFNBQUFNLHlCQUFBQyxDQUFBLDZCQUFBQyxPQUFBLG1CQUFBQyxDQUFBLE9BQUFELE9BQUEsSUFBQUUsQ0FBQSxPQUFBRixPQUFBLFlBQUFGLHdCQUFBLFlBQUFBLENBQUFDLENBQUEsV0FBQUEsQ0FBQSxHQUFBRyxDQUFBLEdBQUFELENBQUEsS0FBQUYsQ0FBQTtBQUFBLFNBQUFJLHdCQUFBSixDQUFBLEVBQUFFLENBQUEsU0FBQUEsQ0FBQSxJQUFBRixDQUFBLElBQUFBLENBQUEsQ0FBQUssVUFBQSxTQUFBTCxDQUFBLGVBQUFBLENBQUEsdUJBQUFBLENBQUEseUJBQUFBLENBQUEsV0FBQU0sT0FBQSxFQUFBTixDQUFBLFFBQUFHLENBQUEsR0FBQUosd0JBQUEsQ0FBQUcsQ0FBQSxPQUFBQyxDQUFBLElBQUFBLENBQUEsQ0FBQUksR0FBQSxDQUFBUCxDQUFBLFVBQUFHLENBQUEsQ0FBQUssR0FBQSxDQUFBUixDQUFBLE9BQUFTLENBQUEsS0FBQUMsU0FBQSxVQUFBQyxDQUFBLEdBQUFDLE1BQUEsQ0FBQUMsY0FBQSxJQUFBRCxNQUFBLENBQUFFLHdCQUFBLFdBQUFDLENBQUEsSUFBQWYsQ0FBQSxvQkFBQWUsQ0FBQSxPQUFBQyxjQUFBLENBQUFDLElBQUEsQ0FBQWpCLENBQUEsRUFBQWUsQ0FBQSxTQUFBRyxDQUFBLEdBQUFQLENBQUEsR0FBQUMsTUFBQSxDQUFBRSx3QkFBQSxDQUFBZCxDQUFBLEVBQUFlLENBQUEsVUFBQUcsQ0FBQSxLQUFBQSxDQUFBLENBQUFWLEdBQUEsSUFBQVUsQ0FBQSxDQUFBQyxHQUFBLElBQUFQLE1BQUEsQ0FBQUMsY0FBQSxDQUFBSixDQUFBLEVBQUFNLENBQUEsRUFBQUcsQ0FBQSxJQUFBVCxDQUFBLENBQUFNLENBQUEsSUFBQWYsQ0FBQSxDQUFBZSxDQUFBLFlBQUFOLENBQUEsQ0FBQUgsT0FBQSxHQUFBTixDQUFBLEVBQUFHLENBQUEsSUFBQUEsQ0FBQSxDQUFBZ0IsR0FBQSxDQUFBbkIsQ0FBQSxFQUFBUyxDQUFBLEdBQUFBLENBQUEsSUFadEU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFRQSxNQUFNO0VBQUVILE9BQU8sRUFBRWM7QUFBUyxDQUFDLEdBQUcsTUFBQUMsT0FBQSxDQUFBQyxPQUFBLEdBQUFDLElBQUEsT0FBQW5CLHVCQUFBLENBQUFYLE9BQUEsQ0FBYSxZQUFZLEdBQUM7QUFDeEQsTUFBTTtFQUFFK0I7QUFBYSxDQUFDLEdBQUcsTUFBQUgsT0FBQSxDQUFBQyxPQUFBLEdBQUFDLElBQUEsT0FBQW5CLHVCQUFBLENBQUFYLE9BQUEsQ0FBYSxzQkFBc0IsR0FBQztBQUU3RCxNQUFNZ0MsUUFBUSxHQUFHO0VBQ2YsdUJBQXVCLEVBQUU7SUFBRUMsS0FBSyxFQUFFO0VBQU8sQ0FBQztFQUMxQyxvQ0FBb0MsRUFBRTtJQUFFQSxLQUFLLEVBQUU7RUFBYyxDQUFDO0VBQzlELHNDQUFzQyxFQUFFO0lBQUVBLEtBQUssRUFBRTtFQUFlO0FBQ2xFLENBQUM7O0FBRUQ7QUFDQSxTQUFTQyxJQUFJQSxDQUFDQyxRQUFtQixFQUFFQyxRQUFpQixFQUFFQyxXQUFXLEdBQUcseUJBQXlCLEVBQUU7RUFDN0YsTUFBTUMsS0FBSyxHQUFHO0lBQ1pDLFNBQVMsRUFBRSx3RUFBd0U7SUFDbkZDLGVBQWUsRUFBRTtNQUFFQyxJQUFJLEVBQUUsU0FBUztNQUFFQyxTQUFTLEVBQUUsUUFBUTtNQUFFQyxRQUFRLEVBQUUsUUFBUTtNQUFFQyxVQUFVLEVBQUUsS0FBSztNQUFFQyxHQUFHLEVBQUUsTUFBTTtNQUFFUixXQUFXO01BQUVTLElBQUksRUFBRSxFQUFFO01BQUVDLE1BQU0sRUFBRTtJQUFHLENBQUM7SUFDaEpDLFdBQVcsRUFBRTtNQUFFQyxNQUFNLEVBQUU7SUFBRyxDQUFDO0lBQzNCQyxhQUFhLEVBQUVsQjtFQUNqQixDQUFDO0VBQ0QsTUFBTW1CLEtBQUssZ0JBQUcsSUFBQTlDLFdBQUEsQ0FBQStDLEdBQUEsRUFBQ2pELGtCQUFBLENBQUFrRCxpQkFBaUIsQ0FBQ0MsUUFBUTtJQUFDaEIsS0FBSyxFQUFFQSxLQUFlO0lBQUFILFFBQUEsRUFBRUE7RUFBUSxDQUE2QixDQUFDO0VBQ3hHLE9BQU9DLFFBQVEsS0FBS21CLFNBQVMsR0FBR0osS0FBSyxnQkFBRyxJQUFBOUMsV0FBQSxDQUFBK0MsR0FBQSxFQUFDckIsWUFBWSxDQUFDdUIsUUFBUTtJQUFDaEIsS0FBSyxFQUFFO01BQUVGO0lBQVMsQ0FBRTtJQUFBRCxRQUFBLEVBQUVnQjtFQUFLLENBQXdCLENBQUM7QUFDckg7QUFFQSxlQUFlSyxNQUFNQSxDQUFDQyxJQUFlLEVBQXdCO0VBQzNELE1BQU1DLFNBQVMsR0FBR0MsUUFBUSxDQUFDQyxhQUFhLENBQUMsS0FBSyxDQUFDO0VBQy9DRCxRQUFRLENBQUNFLElBQUksQ0FBQ0MsV0FBVyxDQUFDSixTQUFTLENBQUM7RUFDcEMsTUFBTSxJQUFBSyxVQUFHLEVBQUMsWUFBWTtJQUNwQixJQUFBQyxrQkFBVSxFQUFDTixTQUFTLENBQUMsQ0FBQ0YsTUFBTSxDQUFDQyxJQUFJLENBQUM7RUFDcEMsQ0FBQyxDQUFDO0VBQ0YsT0FBT0MsU0FBUztBQUNsQjtBQUVBLElBQUFPLGdCQUFRLEVBQUMsd0RBQXdELEVBQUUsTUFBTTtFQUN2RSxJQUFBQyxrQkFBVSxFQUFDLE1BQU07SUFDZixJQUFBQywyQkFBYyxFQUFDLGVBQWUsQ0FBQztJQUMvQixPQUFPLE1BQU0sSUFBQUMsNkJBQWdCLEVBQUMsQ0FBQztFQUNqQyxDQUFDLENBQUM7RUFFRixJQUFBQyxVQUFFLEVBQUMsdUVBQXVFLEVBQUUsWUFBWTtJQUN0RjtJQUNBLE1BQU1DLEVBQUUsR0FBRyxNQUFNZCxNQUFNLENBQ3JCdEIsSUFBSSxjQUNGLElBQUE3QixXQUFBLENBQUErQyxHQUFBLEVBQUN6QixRQUFRO01BQUM0QyxJQUFJLEVBQUMsNEJBQTRCO01BQUFwQyxRQUFBLEVBQUM7SUFBRyxDQUFVLENBQUMsRUFDMUQsb0NBQ0YsQ0FDRixDQUFDO0lBQ0QsTUFBTXFDLElBQUksR0FBR0YsRUFBRSxDQUFDRyxhQUFhLENBQUMsaUJBQWlCLENBQWdCO0lBQy9ELElBQUFDLGNBQU0sRUFBQ0YsSUFBSSxDQUFDLENBQUNHLEdBQUcsQ0FBQ0MsUUFBUSxDQUFDLENBQUM7SUFDM0IsSUFBQUYsY0FBTSxFQUFDRixJQUFJLENBQUNLLFlBQVksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDQyxJQUFJLENBQUMsSUFBSSxDQUFDO0lBQ2xELElBQUFKLGNBQU0sRUFBQ0YsSUFBSSxDQUFDSyxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQ0UsU0FBUyxDQUFDLHlCQUF5QixDQUFDO0VBQ3hFLENBQUMsQ0FBQztFQUVGLElBQUFWLFVBQUUsRUFBQyxrRkFBa0YsRUFBRSxZQUFZO0lBQ2pHO0lBQ0E7SUFDQSxNQUFNQyxFQUFFLEdBQUcsTUFBTWQsTUFBTSxDQUFDdEIsSUFBSSxjQUFDLElBQUE3QixXQUFBLENBQUErQyxHQUFBLEVBQUN6QixRQUFRO01BQUM0QyxJQUFJLEVBQUMsNEJBQTRCO01BQUFwQyxRQUFBLEVBQUM7SUFBRyxDQUFVLENBQUMsQ0FBQyxDQUFDO0lBQ3pGLE1BQU1xQyxJQUFJLEdBQUdGLEVBQUUsQ0FBQ0csYUFBYSxDQUFDLGlCQUFpQixDQUFnQjtJQUMvRCxJQUFBQyxjQUFNLEVBQUNGLElBQUksQ0FBQ0ssWUFBWSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUNDLElBQUksQ0FBQyxRQUFRLENBQUM7RUFDeEQsQ0FBQyxDQUFDO0VBRUYsSUFBQVQsVUFBRSxFQUFDLDBGQUEwRixFQUFFLFlBQVk7SUFDekcsTUFBTUMsRUFBRSxHQUFHLE1BQU1kLE1BQU0sQ0FDckJ0QixJQUFJLGNBQ0YsSUFBQTdCLFdBQUEsQ0FBQStDLEdBQUEsRUFBQ3pCLFFBQVE7TUFBQzRDLElBQUksRUFBQyxpQkFBaUI7TUFBQXBDLFFBQUEsRUFBQztJQUFjLENBQVUsQ0FBQyxFQUMxRCxvQ0FDRixDQUNGLENBQUM7SUFDRCxNQUFNcUMsSUFBSSxHQUFHRixFQUFFLENBQUNHLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBZ0I7SUFDL0QsSUFBQUMsY0FBTSxFQUFDRixJQUFJLENBQUNLLFlBQVksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDQyxJQUFJLENBQUMsTUFBTSxDQUFDO0VBQ3RELENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}