var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = DocList;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.map.js");
require("core-js/modules/esnext.iterator.some.js");
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
var _content = require("../lib/content");
var _InlineProse = _interopRequireDefault(require("./InlineProse"));
var _wiki = require("../lib/wiki");
var _EntryImage = _interopRequireDefault(require("./EntryImage"));
var _useEntryKey = require("../hooks/useEntryKey");
var _useFollowLink = require("../hooks/useFollowLink");
var _navigationPolicy = require("../lib/navigationPolicy");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(),
  _s2 = $RefreshSig$(),
  _s3 = $RefreshSig$();
/* eslint-disable @typescript-eslint/no-explicit-any */
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function tagsOf(meta) {
  return Array.isArray(meta?.tags) ? meta.tags.filter(t => !t.startsWith('ui/')) : [];
}

// One entry as a feed row — reads its own frontmatter so the hook count is stable.
function Row({
  path
}) {
  _s();
  const meta = (0, _sdk.useFileMetadata)(path);
  const from = (0, _useEntryKey.useEntryKey)();
  const follow = (0, _useFollowLink.useFollowLink)();
  if (!meta) return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    className: "gdl-row",
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "sk sk-line",
      style: {
        width: '50%'
      }
    })
  });
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_sdk.Link, {
    href: (0, _content.keyToHref)(path),
    className: "gdl-row",
    onClick: (0, _navigationPolicy.followLinkOnClick)(follow, {
      key: path,
      href: (0, _content.keyToHref)(path),
      from
    }),
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "gdl-row__t",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_InlineProse.default, {
          text: meta.title || path,
          trimPeriod: true
        })
      }), meta.description && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "gdl-row__d",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_InlineProse.default, {
          text: meta.description
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "gdl-row__tags",
        children: tagsOf(meta).slice(0, 3).map(t => /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
          className: "grove-tag",
          children: ["#", t]
        }, t))
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "gdl-row__meta",
      children: meta.date
    })]
  });
}

// One entry as a grid card — the entry's `cover:` when it declares one (resolved
// against the OWNING entry, R3-313 — a card must show its own picture, not the
// rendered entry's), the link-graph lattice when it does not or the asset is
// unreadable. Degrade, never break.
_s(Row, "yi8fnzd+K/oLOUJ+RPzis+vLmXc=", false, function () {
  return [_sdk.useFileMetadata, _useEntryKey.useEntryKey, _useFollowLink.useFollowLink];
});
_c = Row;
function CardTile({
  path
}) {
  _s2();
  const meta = (0, _sdk.useFileMetadata)(path);
  const from = (0, _useEntryKey.useEntryKey)();
  const follow = (0, _useFollowLink.useFollowLink)();
  if (!meta) return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    className: "gdl-card",
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "gdl-card__pic"
    })
  });
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_sdk.Link, {
    href: (0, _content.keyToHref)(path),
    className: "gdl-card",
    onClick: (0, _navigationPolicy.followLinkOnClick)(follow, {
      key: path,
      href: (0, _content.keyToHref)(path),
      from
    }),
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "gdl-card__pic",
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_EntryImage.default, {
        entryPath: path,
        src: meta.cover,
        alt: "",
        className: "gdl-card__cover",
        degrade: /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "gdl-card__lattice"
        })
      })
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "gdl-card__foot",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "gdl-card__t",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_InlineProse.default, {
          text: meta.title || path,
          trimPeriod: true
        })
      }), meta.description && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "gdl-card__d",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_InlineProse.default, {
          text: meta.description
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "gdl-card__tags",
        children: tagsOf(meta).slice(0, 3).map(t => /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
          className: "grove-tag",
          children: ["#", t]
        }, t))
      })]
    })]
  });
}

// Import-free engine component: a frontmatter-driven index of entries, in a feed
// or grid shape. `slugs` pins an explicit ordered set; otherwise it queries the
// whole content space (optionally filtered by `tag`), excluding view/index pages.
//
// `paginate="infinite"` (R3-314): a windowed feed with an IntersectionObserver
// sentinel — the repo's other observer (useHeadings, the contents rail) is the
// pattern, and this one reuses its shape rather than inventing machinery. Three
// states beyond "rows": a skeleton batch (rows render `.sk` until their metadata
// resolves, occupying the real box so nothing shifts), a sentinel that is a
// BUTTON — reachable and actionable by keyboard alone, not only by scrolling —
// and an explicit end ("that is all N entries") rather than a list that merely
// stops. No IntersectionObserver in the environment → the full list renders;
// that degradation is the honest fallback, not an error.
_s2(CardTile, "yi8fnzd+K/oLOUJ+RPzis+vLmXc=", false, function () {
  return [_sdk.useFileMetadata, _useEntryKey.useEntryKey, _useFollowLink.useFollowLink];
});
_c2 = CardTile;
function DocList({
  shape = 'feed',
  title,
  slugs,
  tag,
  limit,
  sort = 'date',
  paginate,
  batch
}) {
  _s3();
  const queryFn = (0, _react.useCallback)(fm => {
    const keys = Object.keys(fm).filter(p => {
      if (!(0, _content.isContentEntry)(p)) return false;
      const m = fm[p] || {};
      if (m.view) return false;
      if (tag && !(Array.isArray(m.tags) && m.tags.includes(tag))) return false;
      return true;
    });
    keys.sort((a, b) => {
      if (sort === 'title') return (fm[a].title || a) < (fm[b].title || b) ? -1 : 1;
      return String(fm[b].date || '').localeCompare(String(fm[a].date || ''));
    });
    return keys;
  }, [tag, sort]);
  const queried = (0, _sdk.useMetadataQuery)(queryFn);
  const loaded = Array.isArray(queried);
  let paths = slugs ? slugs.split(',').map(s => (0, _content.slugToKey)(s.trim())).filter(Boolean) : (0, _wiki.queryPaths)(queried);
  const n = limit ? Number(limit) : undefined;
  if (n && paths.length > n) paths = paths.slice(0, n);

  // ── the windowed feed (R3-314) ─────────────────────────────────────────────
  const windowed = paginate === 'infinite' && typeof IntersectionObserver !== 'undefined';
  const batchSize = Math.max(1, Number(batch) || 20);
  const [visible, setVisible] = (0, _react.useState)(batchSize);
  const sentinelRef = (0, _react.useRef)(null);
  const more = windowed && visible < paths.length;
  const shown = windowed ? paths.slice(0, visible) : paths;
  (0, _react.useEffect)(() => {
    if (!more) return;
    const el = sentinelRef.current;
    if (!el) return;
    // Load a little BEFORE the sentinel is fully reached, so a slow scroll never
    // sees the end of the list — same observer shape as useHeadings' scroll-spy.
    const obs = new IntersectionObserver(entries => {
      if (entries.some(e => e.isIntersecting)) setVisible(v => v + batchSize);
    }, {
      rootMargin: '0px 0px 240px 0px',
      threshold: 0
    });
    obs.observe(el);
    return () => obs.disconnect();
  }, [more, batchSize]);
  const loadMore = () => setVisible(v => v + batchSize);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "grove-doclist-wrap",
    children: [title ? /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "grove-doclist__head",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("h2", {
        children: title
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
        className: "n",
        children: [paths.length, " ", paths.length === 1 ? 'entry' : 'entries']
      })]
    }) : null, !slugs && loaded && paths.length === 0 ? /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
      className: "grove-search__empty",
      children: "No entries yet."
    }) : /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "grove-doclist",
      "data-shape": shape,
      children: [shown.map(p => shape === 'grid' ? /*#__PURE__*/(0, _jsxRuntime.jsx)(CardTile, {
        path: p
      }, p) : /*#__PURE__*/(0, _jsxRuntime.jsx)(Row, {
        path: p
      }, p)), more ? /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
        ref: sentinelRef,
        className: "gdl-sentinel",
        onClick: loadMore,
        "aria-label": `Load the next ${Math.min(batchSize, paths.length - shown.length)} entries`,
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "sk sk-line",
          style: {
            width: '42%'
          }
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "sk sk-line",
          style: {
            width: '68%'
          }
        })]
      }) : null, windowed && !more && paths.length > batchSize ? /*#__PURE__*/(0, _jsxRuntime.jsxs)("p", {
        className: "gdl-end",
        role: "status",
        children: ["That is all ", paths.length, " entries."]
      }) : null]
    })]
  });
}
_s3(DocList, "dd/jFHozdc61jKhVw+mMFPliBTY=", false, function () {
  return [_sdk.useMetadataQuery];
});
_c3 = DocList;
var _c, _c2, _c3;
$RefreshReg$(_c, "Row");
$RefreshReg$(_c2, "CardTile");
$RefreshReg$(_c3, "DocList");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NkayIsIl9jb250ZW50IiwiX0lubGluZVByb3NlIiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsIl93aWtpIiwiX0VudHJ5SW1hZ2UiLCJfdXNlRW50cnlLZXkiLCJfdXNlRm9sbG93TGluayIsIl9uYXZpZ2F0aW9uUG9saWN5IiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsIl9zMiIsIl9zMyIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsInRhZ3NPZiIsIm1ldGEiLCJBcnJheSIsImlzQXJyYXkiLCJ0YWdzIiwiZmlsdGVyIiwidCIsInN0YXJ0c1dpdGgiLCJSb3ciLCJwYXRoIiwidXNlRmlsZU1ldGFkYXRhIiwiZnJvbSIsInVzZUVudHJ5S2V5IiwiZm9sbG93IiwidXNlRm9sbG93TGluayIsImpzeCIsImNsYXNzTmFtZSIsImNoaWxkcmVuIiwic3R5bGUiLCJ3aWR0aCIsImpzeHMiLCJMaW5rIiwiaHJlZiIsImtleVRvSHJlZiIsIm9uQ2xpY2siLCJmb2xsb3dMaW5rT25DbGljayIsImtleSIsInRleHQiLCJ0aXRsZSIsInRyaW1QZXJpb2QiLCJkZXNjcmlwdGlvbiIsInNsaWNlIiwibWFwIiwiZGF0ZSIsIl9jIiwiQ2FyZFRpbGUiLCJlbnRyeVBhdGgiLCJzcmMiLCJjb3ZlciIsImFsdCIsImRlZ3JhZGUiLCJfYzIiLCJEb2NMaXN0Iiwic2hhcGUiLCJzbHVncyIsInRhZyIsImxpbWl0Iiwic29ydCIsInBhZ2luYXRlIiwiYmF0Y2giLCJxdWVyeUZuIiwidXNlQ2FsbGJhY2siLCJmbSIsImtleXMiLCJPYmplY3QiLCJwIiwiaXNDb250ZW50RW50cnkiLCJtIiwidmlldyIsImluY2x1ZGVzIiwiYSIsImIiLCJTdHJpbmciLCJsb2NhbGVDb21wYXJlIiwicXVlcmllZCIsInVzZU1ldGFkYXRhUXVlcnkiLCJsb2FkZWQiLCJwYXRocyIsInNwbGl0IiwicyIsInNsdWdUb0tleSIsInRyaW0iLCJCb29sZWFuIiwicXVlcnlQYXRocyIsIm4iLCJOdW1iZXIiLCJ1bmRlZmluZWQiLCJsZW5ndGgiLCJ3aW5kb3dlZCIsIkludGVyc2VjdGlvbk9ic2VydmVyIiwiYmF0Y2hTaXplIiwiTWF0aCIsIm1heCIsInZpc2libGUiLCJzZXRWaXNpYmxlIiwidXNlU3RhdGUiLCJzZW50aW5lbFJlZiIsInVzZVJlZiIsIm1vcmUiLCJzaG93biIsInVzZUVmZmVjdCIsImVsIiwiY3VycmVudCIsIm9icyIsImVudHJpZXMiLCJzb21lIiwiaXNJbnRlcnNlY3RpbmciLCJ2Iiwicm9vdE1hcmdpbiIsInRocmVzaG9sZCIsIm9ic2VydmUiLCJkaXNjb25uZWN0IiwibG9hZE1vcmUiLCJyZWYiLCJtaW4iLCJyb2xlIiwiX2MzIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiRG9jTGlzdC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueSAqL1xuaW1wb3J0IHsgdXNlQ2FsbGJhY2ssIHVzZUVmZmVjdCwgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IExpbmssIHVzZUZpbGVNZXRhZGF0YSwgdXNlTWV0YWRhdGFRdWVyeSB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrJztcbmltcG9ydCB7IGlzQ29udGVudEVudHJ5LCBrZXlUb0hyZWYsIHNsdWdUb0tleSB9IGZyb20gJy4uL2xpYi9jb250ZW50JztcbmltcG9ydCBJbmxpbmVQcm9zZSBmcm9tICcuL0lubGluZVByb3NlJztcbmltcG9ydCB7IHF1ZXJ5UGF0aHMgfSBmcm9tICcuLi9saWIvd2lraSc7XG5pbXBvcnQgRW50cnlJbWFnZSBmcm9tICcuL0VudHJ5SW1hZ2UnO1xuaW1wb3J0IHsgdXNlRW50cnlLZXkgfSBmcm9tICcuLi9ob29rcy91c2VFbnRyeUtleSc7XG5pbXBvcnQgeyB1c2VGb2xsb3dMaW5rIH0gZnJvbSAnLi4vaG9va3MvdXNlRm9sbG93TGluayc7XG5pbXBvcnQgeyBmb2xsb3dMaW5rT25DbGljayB9IGZyb20gJy4uL2xpYi9uYXZpZ2F0aW9uUG9saWN5JztcblxuaW50ZXJmYWNlIFByb3BzIHtcbiAgc2hhcGU/OiAnZmVlZCcgfCAnZ3JpZCc7XG4gIHRpdGxlPzogc3RyaW5nIHwgbnVsbDtcbiAgc2x1Z3M/OiBzdHJpbmc7XG4gIHRhZz86IHN0cmluZztcbiAgbGltaXQ/OiBzdHJpbmcgfCBudW1iZXI7XG4gIHNvcnQ/OiAnZGF0ZScgfCAndGl0bGUnO1xuICAvKiogXCJpbmZpbml0ZVwiIOKAlCBhIHdpbmRvd2VkIGZlZWQgdGhhdCBncm93cyBvbiBzY3JvbGwgKFIzLTMxNCkuIEEgTElURVJBTFxuICAgKiAgYXR0cmlidXRlOiB0aGUgc2FmZSByZW5kZXJlciBjb3BpZXMgYHBhZ2luYXRlPVwiaW5maW5pdGVcImAgdmVyYmF0aW0gYnV0IGRyb3BzXG4gICAqICBgcGFnaW5hdGU9e21vZGV9YCBzaWxlbnRseSwgYW5kIHRoZSBsaXN0IHRoZW4gcmVuZGVycyB3aG9sZSB3aXRoIG5vdGhpbmdcbiAgICogIHNheWluZyB3aHkuICovXG4gIHBhZ2luYXRlPzogc3RyaW5nO1xuICAvKiogSG93IG1hbnkgZW50cmllcyBhIHdpbmRvd2VkIGJhdGNoIGFkZHMgKGxpdGVyYWwgc3RyaW5nIG9yIG51bWJlcikuICovXG4gIGJhdGNoPzogc3RyaW5nIHwgbnVtYmVyO1xufVxuXG5mdW5jdGlvbiB0YWdzT2YobWV0YTogYW55KTogc3RyaW5nW10ge1xuICByZXR1cm4gQXJyYXkuaXNBcnJheShtZXRhPy50YWdzKSA/IG1ldGEudGFncy5maWx0ZXIoKHQ6IHN0cmluZykgPT4gIXQuc3RhcnRzV2l0aCgndWkvJykpIDogW107XG59XG5cbi8vIE9uZSBlbnRyeSBhcyBhIGZlZWQgcm93IOKAlCByZWFkcyBpdHMgb3duIGZyb250bWF0dGVyIHNvIHRoZSBob29rIGNvdW50IGlzIHN0YWJsZS5cbmZ1bmN0aW9uIFJvdyh7IHBhdGggfTogeyBwYXRoOiBzdHJpbmcgfSkge1xuICBjb25zdCBtZXRhID0gdXNlRmlsZU1ldGFkYXRhKHBhdGgpIGFzIGFueTtcbiAgY29uc3QgZnJvbSA9IHVzZUVudHJ5S2V5KCk7XG4gIGNvbnN0IGZvbGxvdyA9IHVzZUZvbGxvd0xpbmsoKTtcbiAgaWYgKCFtZXRhKSByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJnZGwtcm93XCI+PGRpdiBjbGFzc05hbWU9XCJzayBzay1saW5lXCIgc3R5bGU9e3sgd2lkdGg6ICc1MCUnIH19IC8+PC9kaXY+O1xuICByZXR1cm4gKFxuICAgIDxMaW5rIGhyZWY9e2tleVRvSHJlZihwYXRoKX0gY2xhc3NOYW1lPVwiZ2RsLXJvd1wiIG9uQ2xpY2s9e2ZvbGxvd0xpbmtPbkNsaWNrKGZvbGxvdywgeyBrZXk6IHBhdGgsIGhyZWY6IGtleVRvSHJlZihwYXRoKSwgZnJvbSB9KX0+XG4gICAgICA8ZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdkbC1yb3dfX3RcIj48SW5saW5lUHJvc2UgdGV4dD17bWV0YS50aXRsZSB8fCBwYXRofSB0cmltUGVyaW9kIC8+PC9kaXY+XG4gICAgICAgIHttZXRhLmRlc2NyaXB0aW9uICYmIDxkaXYgY2xhc3NOYW1lPVwiZ2RsLXJvd19fZFwiPjxJbmxpbmVQcm9zZSB0ZXh0PXttZXRhLmRlc2NyaXB0aW9ufSAvPjwvZGl2Pn1cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJnZGwtcm93X190YWdzXCI+XG4gICAgICAgICAge3RhZ3NPZihtZXRhKS5zbGljZSgwLCAzKS5tYXAoKHQpID0+IChcbiAgICAgICAgICAgIDxzcGFuIGtleT17dH0gY2xhc3NOYW1lPVwiZ3JvdmUtdGFnXCI+I3t0fTwvc3Bhbj5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ2RsLXJvd19fbWV0YVwiPnttZXRhLmRhdGV9PC9kaXY+XG4gICAgPC9MaW5rPlxuICApO1xufVxuXG4vLyBPbmUgZW50cnkgYXMgYSBncmlkIGNhcmQg4oCUIHRoZSBlbnRyeSdzIGBjb3ZlcjpgIHdoZW4gaXQgZGVjbGFyZXMgb25lIChyZXNvbHZlZFxuLy8gYWdhaW5zdCB0aGUgT1dOSU5HIGVudHJ5LCBSMy0zMTMg4oCUIGEgY2FyZCBtdXN0IHNob3cgaXRzIG93biBwaWN0dXJlLCBub3QgdGhlXG4vLyByZW5kZXJlZCBlbnRyeSdzKSwgdGhlIGxpbmstZ3JhcGggbGF0dGljZSB3aGVuIGl0IGRvZXMgbm90IG9yIHRoZSBhc3NldCBpc1xuLy8gdW5yZWFkYWJsZS4gRGVncmFkZSwgbmV2ZXIgYnJlYWsuXG5mdW5jdGlvbiBDYXJkVGlsZSh7IHBhdGggfTogeyBwYXRoOiBzdHJpbmcgfSkge1xuICBjb25zdCBtZXRhID0gdXNlRmlsZU1ldGFkYXRhKHBhdGgpIGFzIGFueTtcbiAgY29uc3QgZnJvbSA9IHVzZUVudHJ5S2V5KCk7XG4gIGNvbnN0IGZvbGxvdyA9IHVzZUZvbGxvd0xpbmsoKTtcbiAgaWYgKCFtZXRhKSByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJnZGwtY2FyZFwiPjxkaXYgY2xhc3NOYW1lPVwiZ2RsLWNhcmRfX3BpY1wiIC8+PC9kaXY+O1xuICByZXR1cm4gKFxuICAgIDxMaW5rIGhyZWY9e2tleVRvSHJlZihwYXRoKX0gY2xhc3NOYW1lPVwiZ2RsLWNhcmRcIiBvbkNsaWNrPXtmb2xsb3dMaW5rT25DbGljayhmb2xsb3csIHsga2V5OiBwYXRoLCBocmVmOiBrZXlUb0hyZWYocGF0aCksIGZyb20gfSl9PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJnZGwtY2FyZF9fcGljXCI+XG4gICAgICAgIDxFbnRyeUltYWdlIGVudHJ5UGF0aD17cGF0aH0gc3JjPXttZXRhLmNvdmVyfSBhbHQ9XCJcIiBjbGFzc05hbWU9XCJnZGwtY2FyZF9fY292ZXJcIiBkZWdyYWRlPXs8c3BhbiBjbGFzc05hbWU9XCJnZGwtY2FyZF9fbGF0dGljZVwiIC8+fSAvPlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdkbC1jYXJkX19mb290XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ2RsLWNhcmRfX3RcIj48SW5saW5lUHJvc2UgdGV4dD17bWV0YS50aXRsZSB8fCBwYXRofSB0cmltUGVyaW9kIC8+PC9kaXY+XG4gICAgICAgIHttZXRhLmRlc2NyaXB0aW9uICYmIDxkaXYgY2xhc3NOYW1lPVwiZ2RsLWNhcmRfX2RcIj48SW5saW5lUHJvc2UgdGV4dD17bWV0YS5kZXNjcmlwdGlvbn0gLz48L2Rpdj59XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ2RsLWNhcmRfX3RhZ3NcIj5cbiAgICAgICAgICB7dGFnc09mKG1ldGEpLnNsaWNlKDAsIDMpLm1hcCgodCkgPT4gKFxuICAgICAgICAgICAgPHNwYW4ga2V5PXt0fSBjbGFzc05hbWU9XCJncm92ZS10YWdcIj4je3R9PC9zcGFuPlxuICAgICAgICAgICkpfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvTGluaz5cbiAgKTtcbn1cblxuLy8gSW1wb3J0LWZyZWUgZW5naW5lIGNvbXBvbmVudDogYSBmcm9udG1hdHRlci1kcml2ZW4gaW5kZXggb2YgZW50cmllcywgaW4gYSBmZWVkXG4vLyBvciBncmlkIHNoYXBlLiBgc2x1Z3NgIHBpbnMgYW4gZXhwbGljaXQgb3JkZXJlZCBzZXQ7IG90aGVyd2lzZSBpdCBxdWVyaWVzIHRoZVxuLy8gd2hvbGUgY29udGVudCBzcGFjZSAob3B0aW9uYWxseSBmaWx0ZXJlZCBieSBgdGFnYCksIGV4Y2x1ZGluZyB2aWV3L2luZGV4IHBhZ2VzLlxuLy9cbi8vIGBwYWdpbmF0ZT1cImluZmluaXRlXCJgIChSMy0zMTQpOiBhIHdpbmRvd2VkIGZlZWQgd2l0aCBhbiBJbnRlcnNlY3Rpb25PYnNlcnZlclxuLy8gc2VudGluZWwg4oCUIHRoZSByZXBvJ3Mgb3RoZXIgb2JzZXJ2ZXIgKHVzZUhlYWRpbmdzLCB0aGUgY29udGVudHMgcmFpbCkgaXMgdGhlXG4vLyBwYXR0ZXJuLCBhbmQgdGhpcyBvbmUgcmV1c2VzIGl0cyBzaGFwZSByYXRoZXIgdGhhbiBpbnZlbnRpbmcgbWFjaGluZXJ5LiBUaHJlZVxuLy8gc3RhdGVzIGJleW9uZCBcInJvd3NcIjogYSBza2VsZXRvbiBiYXRjaCAocm93cyByZW5kZXIgYC5za2AgdW50aWwgdGhlaXIgbWV0YWRhdGFcbi8vIHJlc29sdmVzLCBvY2N1cHlpbmcgdGhlIHJlYWwgYm94IHNvIG5vdGhpbmcgc2hpZnRzKSwgYSBzZW50aW5lbCB0aGF0IGlzIGFcbi8vIEJVVFRPTiDigJQgcmVhY2hhYmxlIGFuZCBhY3Rpb25hYmxlIGJ5IGtleWJvYXJkIGFsb25lLCBub3Qgb25seSBieSBzY3JvbGxpbmcg4oCUXG4vLyBhbmQgYW4gZXhwbGljaXQgZW5kIChcInRoYXQgaXMgYWxsIE4gZW50cmllc1wiKSByYXRoZXIgdGhhbiBhIGxpc3QgdGhhdCBtZXJlbHlcbi8vIHN0b3BzLiBObyBJbnRlcnNlY3Rpb25PYnNlcnZlciBpbiB0aGUgZW52aXJvbm1lbnQg4oaSIHRoZSBmdWxsIGxpc3QgcmVuZGVycztcbi8vIHRoYXQgZGVncmFkYXRpb24gaXMgdGhlIGhvbmVzdCBmYWxsYmFjaywgbm90IGFuIGVycm9yLlxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gRG9jTGlzdCh7XG4gIHNoYXBlID0gJ2ZlZWQnLFxuICB0aXRsZSxcbiAgc2x1Z3MsXG4gIHRhZyxcbiAgbGltaXQsXG4gIHNvcnQgPSAnZGF0ZScsXG4gIHBhZ2luYXRlLFxuICBiYXRjaCxcbn06IFByb3BzKSB7XG4gIGNvbnN0IHF1ZXJ5Rm4gPSB1c2VDYWxsYmFjayhcbiAgICAoZm06IFJlY29yZDxzdHJpbmcsIGFueT4pID0+IHtcbiAgICAgIGNvbnN0IGtleXMgPSBPYmplY3Qua2V5cyhmbSkuZmlsdGVyKChwKSA9PiB7XG4gICAgICAgIGlmICghaXNDb250ZW50RW50cnkocCkpIHJldHVybiBmYWxzZTtcbiAgICAgICAgY29uc3QgbSA9IGZtW3BdIHx8IHt9O1xuICAgICAgICBpZiAobS52aWV3KSByZXR1cm4gZmFsc2U7XG4gICAgICAgIGlmICh0YWcgJiYgIShBcnJheS5pc0FycmF5KG0udGFncykgJiYgbS50YWdzLmluY2x1ZGVzKHRhZykpKSByZXR1cm4gZmFsc2U7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgfSk7XG4gICAgICBrZXlzLnNvcnQoKGEsIGIpID0+IHtcbiAgICAgICAgaWYgKHNvcnQgPT09ICd0aXRsZScpIHJldHVybiAoZm1bYV0udGl0bGUgfHwgYSkgPCAoZm1bYl0udGl0bGUgfHwgYikgPyAtMSA6IDE7XG4gICAgICAgIHJldHVybiBTdHJpbmcoZm1bYl0uZGF0ZSB8fCAnJykubG9jYWxlQ29tcGFyZShTdHJpbmcoZm1bYV0uZGF0ZSB8fCAnJykpO1xuICAgICAgfSk7XG4gICAgICByZXR1cm4ga2V5cztcbiAgICB9LFxuICAgIFt0YWcsIHNvcnRdXG4gICk7XG4gIGNvbnN0IHF1ZXJpZWQgPSB1c2VNZXRhZGF0YVF1ZXJ5KHF1ZXJ5Rm4pO1xuICBjb25zdCBsb2FkZWQgPSBBcnJheS5pc0FycmF5KHF1ZXJpZWQpO1xuXG4gIGxldCBwYXRoczogc3RyaW5nW10gPSBzbHVnc1xuICAgID8gc2x1Z3Muc3BsaXQoJywnKS5tYXAoKHMpID0+IHNsdWdUb0tleShzLnRyaW0oKSkpLmZpbHRlcihCb29sZWFuKVxuICAgIDogcXVlcnlQYXRocyhxdWVyaWVkKTtcbiAgY29uc3QgbiA9IGxpbWl0ID8gTnVtYmVyKGxpbWl0KSA6IHVuZGVmaW5lZDtcbiAgaWYgKG4gJiYgcGF0aHMubGVuZ3RoID4gbikgcGF0aHMgPSBwYXRocy5zbGljZSgwLCBuKTtcblxuICAvLyDilIDilIAgdGhlIHdpbmRvd2VkIGZlZWQgKFIzLTMxNCkg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIGNvbnN0IHdpbmRvd2VkID0gcGFnaW5hdGUgPT09ICdpbmZpbml0ZScgJiYgdHlwZW9mIEludGVyc2VjdGlvbk9ic2VydmVyICE9PSAndW5kZWZpbmVkJztcbiAgY29uc3QgYmF0Y2hTaXplID0gTWF0aC5tYXgoMSwgTnVtYmVyKGJhdGNoKSB8fCAyMCk7XG4gIGNvbnN0IFt2aXNpYmxlLCBzZXRWaXNpYmxlXSA9IHVzZVN0YXRlKGJhdGNoU2l6ZSk7XG4gIGNvbnN0IHNlbnRpbmVsUmVmID0gdXNlUmVmPEhUTUxCdXR0b25FbGVtZW50IHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IG1vcmUgPSB3aW5kb3dlZCAmJiB2aXNpYmxlIDwgcGF0aHMubGVuZ3RoO1xuICBjb25zdCBzaG93biA9IHdpbmRvd2VkID8gcGF0aHMuc2xpY2UoMCwgdmlzaWJsZSkgOiBwYXRocztcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghbW9yZSkgcmV0dXJuO1xuICAgIGNvbnN0IGVsID0gc2VudGluZWxSZWYuY3VycmVudDtcbiAgICBpZiAoIWVsKSByZXR1cm47XG4gICAgLy8gTG9hZCBhIGxpdHRsZSBCRUZPUkUgdGhlIHNlbnRpbmVsIGlzIGZ1bGx5IHJlYWNoZWQsIHNvIGEgc2xvdyBzY3JvbGwgbmV2ZXJcbiAgICAvLyBzZWVzIHRoZSBlbmQgb2YgdGhlIGxpc3Qg4oCUIHNhbWUgb2JzZXJ2ZXIgc2hhcGUgYXMgdXNlSGVhZGluZ3MnIHNjcm9sbC1zcHkuXG4gICAgY29uc3Qgb2JzID0gbmV3IEludGVyc2VjdGlvbk9ic2VydmVyKFxuICAgICAgKGVudHJpZXMpID0+IHtcbiAgICAgICAgaWYgKGVudHJpZXMuc29tZSgoZSkgPT4gZS5pc0ludGVyc2VjdGluZykpIHNldFZpc2libGUoKHYpID0+IHYgKyBiYXRjaFNpemUpO1xuICAgICAgfSxcbiAgICAgIHsgcm9vdE1hcmdpbjogJzBweCAwcHggMjQwcHggMHB4JywgdGhyZXNob2xkOiAwIH1cbiAgICApO1xuICAgIG9icy5vYnNlcnZlKGVsKTtcbiAgICByZXR1cm4gKCkgPT4gb2JzLmRpc2Nvbm5lY3QoKTtcbiAgfSwgW21vcmUsIGJhdGNoU2l6ZV0pO1xuXG4gIGNvbnN0IGxvYWRNb3JlID0gKCkgPT4gc2V0VmlzaWJsZSgodikgPT4gdiArIGJhdGNoU2l6ZSk7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImdyb3ZlLWRvY2xpc3Qtd3JhcFwiPlxuICAgICAge3RpdGxlID8gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyb3ZlLWRvY2xpc3RfX2hlYWRcIj5cbiAgICAgICAgICA8aDI+e3RpdGxlfTwvaDI+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiblwiPntwYXRocy5sZW5ndGh9IHtwYXRocy5sZW5ndGggPT09IDEgPyAnZW50cnknIDogJ2VudHJpZXMnfTwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApIDogbnVsbH1cbiAgICAgIHshc2x1Z3MgJiYgbG9hZGVkICYmIHBhdGhzLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiZ3JvdmUtc2VhcmNoX19lbXB0eVwiPk5vIGVudHJpZXMgeWV0LjwvcD5cbiAgICAgICkgOiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JvdmUtZG9jbGlzdFwiIGRhdGEtc2hhcGU9e3NoYXBlfT5cbiAgICAgICAgICB7c2hvd24ubWFwKChwOiBzdHJpbmcpID0+XG4gICAgICAgICAgICBzaGFwZSA9PT0gJ2dyaWQnID8gPENhcmRUaWxlIGtleT17cH0gcGF0aD17cH0gLz4gOiA8Um93IGtleT17cH0gcGF0aD17cH0gLz5cbiAgICAgICAgICApfVxuICAgICAgICAgIHttb3JlID8gKFxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICByZWY9e3NlbnRpbmVsUmVmfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJnZGwtc2VudGluZWxcIlxuICAgICAgICAgICAgICBvbkNsaWNrPXtsb2FkTW9yZX1cbiAgICAgICAgICAgICAgYXJpYS1sYWJlbD17YExvYWQgdGhlIG5leHQgJHtNYXRoLm1pbihiYXRjaFNpemUsIHBhdGhzLmxlbmd0aCAtIHNob3duLmxlbmd0aCl9IGVudHJpZXNgfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzayBzay1saW5lXCIgc3R5bGU9e3sgd2lkdGg6ICc0MiUnIH19IC8+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNrIHNrLWxpbmVcIiBzdHlsZT17eyB3aWR0aDogJzY4JScgfX0gLz5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICkgOiBudWxsfVxuICAgICAgICAgIHt3aW5kb3dlZCAmJiAhbW9yZSAmJiBwYXRocy5sZW5ndGggPiBiYXRjaFNpemUgPyAoXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJnZGwtZW5kXCIgcm9sZT1cInN0YXR1c1wiPlRoYXQgaXMgYWxsIHtwYXRocy5sZW5ndGh9IGVudHJpZXMuPC9wPlxuICAgICAgICAgICkgOiBudWxsfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFDQSxJQUFBQSxNQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxJQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxRQUFBLEdBQUFGLE9BQUE7QUFDQSxJQUFBRyxZQUFBLEdBQUFDLHNCQUFBLENBQUFKLE9BQUE7QUFDQSxJQUFBSyxLQUFBLEdBQUFMLE9BQUE7QUFDQSxJQUFBTSxXQUFBLEdBQUFGLHNCQUFBLENBQUFKLE9BQUE7QUFDQSxJQUFBTyxZQUFBLEdBQUFQLE9BQUE7QUFDQSxJQUFBUSxjQUFBLEdBQUFSLE9BQUE7QUFDQSxJQUFBUyxpQkFBQSxHQUFBVCxPQUFBO0FBQTRELElBQUFVLFdBQUEsR0FBQVYsT0FBQTtBQUFBLElBQUFXLEVBQUEsR0FBQUMsWUFBQTtFQUFBQyxHQUFBLEdBQUFELFlBQUE7RUFBQUUsR0FBQSxHQUFBRixZQUFBO0FBVDVEO0FBQUEsU0FBQVIsdUJBQUFXLENBQUEsV0FBQUEsQ0FBQSxJQUFBQSxDQUFBLENBQUFDLFVBQUEsR0FBQUQsQ0FBQSxLQUFBRSxPQUFBLEVBQUFGLENBQUE7QUEyQkEsU0FBU0csTUFBTUEsQ0FBQ0MsSUFBUyxFQUFZO0VBQ25DLE9BQU9DLEtBQUssQ0FBQ0MsT0FBTyxDQUFDRixJQUFJLEVBQUVHLElBQUksQ0FBQyxHQUFHSCxJQUFJLENBQUNHLElBQUksQ0FBQ0MsTUFBTSxDQUFFQyxDQUFTLElBQUssQ0FBQ0EsQ0FBQyxDQUFDQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxFQUFFO0FBQy9GOztBQUVBO0FBQ0EsU0FBU0MsR0FBR0EsQ0FBQztFQUFFQztBQUF1QixDQUFDLEVBQUU7RUFBQWhCLEVBQUE7RUFDdkMsTUFBTVEsSUFBSSxHQUFHLElBQUFTLG9CQUFlLEVBQUNELElBQUksQ0FBUTtFQUN6QyxNQUFNRSxJQUFJLEdBQUcsSUFBQUMsd0JBQVcsRUFBQyxDQUFDO0VBQzFCLE1BQU1DLE1BQU0sR0FBRyxJQUFBQyw0QkFBYSxFQUFDLENBQUM7RUFDOUIsSUFBSSxDQUFDYixJQUFJLEVBQUUsb0JBQU8sSUFBQVQsV0FBQSxDQUFBdUIsR0FBQTtJQUFLQyxTQUFTLEVBQUMsU0FBUztJQUFBQyxRQUFBLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLEdBQUE7TUFBS0MsU0FBUyxFQUFDLFlBQVk7TUFBQ0UsS0FBSyxFQUFFO1FBQUVDLEtBQUssRUFBRTtNQUFNO0lBQUUsQ0FBRTtFQUFDLENBQUssQ0FBQztFQUN4RyxvQkFDRSxJQUFBM0IsV0FBQSxDQUFBNEIsSUFBQSxFQUFDckMsSUFBQSxDQUFBc0MsSUFBSTtJQUFDQyxJQUFJLEVBQUUsSUFBQUMsa0JBQVMsRUFBQ2QsSUFBSSxDQUFFO0lBQUNPLFNBQVMsRUFBQyxTQUFTO0lBQUNRLE9BQU8sRUFBRSxJQUFBQyxtQ0FBaUIsRUFBQ1osTUFBTSxFQUFFO01BQUVhLEdBQUcsRUFBRWpCLElBQUk7TUFBRWEsSUFBSSxFQUFFLElBQUFDLGtCQUFTLEVBQUNkLElBQUksQ0FBQztNQUFFRTtJQUFLLENBQUMsQ0FBRTtJQUFBTSxRQUFBLGdCQUM5SCxJQUFBekIsV0FBQSxDQUFBNEIsSUFBQTtNQUFBSCxRQUFBLGdCQUNFLElBQUF6QixXQUFBLENBQUF1QixHQUFBO1FBQUtDLFNBQVMsRUFBQyxZQUFZO1FBQUFDLFFBQUEsZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDOUIsWUFBQSxDQUFBYyxPQUFXO1VBQUM0QixJQUFJLEVBQUUxQixJQUFJLENBQUMyQixLQUFLLElBQUluQixJQUFLO1VBQUNvQixVQUFVO1FBQUEsQ0FBRTtNQUFDLENBQUssQ0FBQyxFQUNyRjVCLElBQUksQ0FBQzZCLFdBQVcsaUJBQUksSUFBQXRDLFdBQUEsQ0FBQXVCLEdBQUE7UUFBS0MsU0FBUyxFQUFDLFlBQVk7UUFBQUMsUUFBQSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixHQUFBLEVBQUM5QixZQUFBLENBQUFjLE9BQVc7VUFBQzRCLElBQUksRUFBRTFCLElBQUksQ0FBQzZCO1FBQVksQ0FBRTtNQUFDLENBQUssQ0FBQyxlQUM5RixJQUFBdEMsV0FBQSxDQUFBdUIsR0FBQTtRQUFLQyxTQUFTLEVBQUMsZUFBZTtRQUFBQyxRQUFBLEVBQzNCakIsTUFBTSxDQUFDQyxJQUFJLENBQUMsQ0FBQzhCLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUNDLEdBQUcsQ0FBRTFCLENBQUMsaUJBQzlCLElBQUFkLFdBQUEsQ0FBQTRCLElBQUE7VUFBY0osU0FBUyxFQUFDLFdBQVc7VUFBQUMsUUFBQSxHQUFDLEdBQUMsRUFBQ1gsQ0FBQztRQUFBLEdBQTVCQSxDQUFtQyxDQUMvQztNQUFDLENBQ0MsQ0FBQztJQUFBLENBQ0gsQ0FBQyxlQUNOLElBQUFkLFdBQUEsQ0FBQXVCLEdBQUE7TUFBS0MsU0FBUyxFQUFDLGVBQWU7TUFBQUMsUUFBQSxFQUFFaEIsSUFBSSxDQUFDZ0M7SUFBSSxDQUFNLENBQUM7RUFBQSxDQUM1QyxDQUFDO0FBRVg7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFBQXhDLEVBQUEsQ0F4QlNlLEdBQUc7RUFBQSxRQUNHRSxvQkFBZSxFQUNmRSx3QkFBVyxFQUNURSw0QkFBYTtBQUFBO0FBQUFvQixFQUFBLEdBSHJCMUIsR0FBRztBQXlCWixTQUFTMkIsUUFBUUEsQ0FBQztFQUFFMUI7QUFBdUIsQ0FBQyxFQUFFO0VBQUFkLEdBQUE7RUFDNUMsTUFBTU0sSUFBSSxHQUFHLElBQUFTLG9CQUFlLEVBQUNELElBQUksQ0FBUTtFQUN6QyxNQUFNRSxJQUFJLEdBQUcsSUFBQUMsd0JBQVcsRUFBQyxDQUFDO0VBQzFCLE1BQU1DLE1BQU0sR0FBRyxJQUFBQyw0QkFBYSxFQUFDLENBQUM7RUFDOUIsSUFBSSxDQUFDYixJQUFJLEVBQUUsb0JBQU8sSUFBQVQsV0FBQSxDQUFBdUIsR0FBQTtJQUFLQyxTQUFTLEVBQUMsVUFBVTtJQUFBQyxRQUFBLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLEdBQUE7TUFBS0MsU0FBUyxFQUFDO0lBQWUsQ0FBRTtFQUFDLENBQUssQ0FBQztFQUNuRixvQkFDRSxJQUFBeEIsV0FBQSxDQUFBNEIsSUFBQSxFQUFDckMsSUFBQSxDQUFBc0MsSUFBSTtJQUFDQyxJQUFJLEVBQUUsSUFBQUMsa0JBQVMsRUFBQ2QsSUFBSSxDQUFFO0lBQUNPLFNBQVMsRUFBQyxVQUFVO0lBQUNRLE9BQU8sRUFBRSxJQUFBQyxtQ0FBaUIsRUFBQ1osTUFBTSxFQUFFO01BQUVhLEdBQUcsRUFBRWpCLElBQUk7TUFBRWEsSUFBSSxFQUFFLElBQUFDLGtCQUFTLEVBQUNkLElBQUksQ0FBQztNQUFFRTtJQUFLLENBQUMsQ0FBRTtJQUFBTSxRQUFBLGdCQUMvSCxJQUFBekIsV0FBQSxDQUFBdUIsR0FBQTtNQUFLQyxTQUFTLEVBQUMsZUFBZTtNQUFBQyxRQUFBLGVBQzVCLElBQUF6QixXQUFBLENBQUF1QixHQUFBLEVBQUMzQixXQUFBLENBQUFXLE9BQVU7UUFBQ3FDLFNBQVMsRUFBRTNCLElBQUs7UUFBQzRCLEdBQUcsRUFBRXBDLElBQUksQ0FBQ3FDLEtBQU07UUFBQ0MsR0FBRyxFQUFDLEVBQUU7UUFBQ3ZCLFNBQVMsRUFBQyxpQkFBaUI7UUFBQ3dCLE9BQU8sZUFBRSxJQUFBaEQsV0FBQSxDQUFBdUIsR0FBQTtVQUFNQyxTQUFTLEVBQUM7UUFBbUIsQ0FBRTtNQUFFLENBQUU7SUFBQyxDQUNqSSxDQUFDLGVBQ04sSUFBQXhCLFdBQUEsQ0FBQTRCLElBQUE7TUFBS0osU0FBUyxFQUFDLGdCQUFnQjtNQUFBQyxRQUFBLGdCQUM3QixJQUFBekIsV0FBQSxDQUFBdUIsR0FBQTtRQUFLQyxTQUFTLEVBQUMsYUFBYTtRQUFBQyxRQUFBLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQzlCLFlBQUEsQ0FBQWMsT0FBVztVQUFDNEIsSUFBSSxFQUFFMUIsSUFBSSxDQUFDMkIsS0FBSyxJQUFJbkIsSUFBSztVQUFDb0IsVUFBVTtRQUFBLENBQUU7TUFBQyxDQUFLLENBQUMsRUFDdEY1QixJQUFJLENBQUM2QixXQUFXLGlCQUFJLElBQUF0QyxXQUFBLENBQUF1QixHQUFBO1FBQUtDLFNBQVMsRUFBQyxhQUFhO1FBQUFDLFFBQUEsZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDOUIsWUFBQSxDQUFBYyxPQUFXO1VBQUM0QixJQUFJLEVBQUUxQixJQUFJLENBQUM2QjtRQUFZLENBQUU7TUFBQyxDQUFLLENBQUMsZUFDL0YsSUFBQXRDLFdBQUEsQ0FBQXVCLEdBQUE7UUFBS0MsU0FBUyxFQUFDLGdCQUFnQjtRQUFBQyxRQUFBLEVBQzVCakIsTUFBTSxDQUFDQyxJQUFJLENBQUMsQ0FBQzhCLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUNDLEdBQUcsQ0FBRTFCLENBQUMsaUJBQzlCLElBQUFkLFdBQUEsQ0FBQTRCLElBQUE7VUFBY0osU0FBUyxFQUFDLFdBQVc7VUFBQUMsUUFBQSxHQUFDLEdBQUMsRUFBQ1gsQ0FBQztRQUFBLEdBQTVCQSxDQUFtQyxDQUMvQztNQUFDLENBQ0MsQ0FBQztJQUFBLENBQ0gsQ0FBQztFQUFBLENBQ0YsQ0FBQztBQUVYOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQUFYLEdBQUEsQ0FuQ1N3QyxRQUFRO0VBQUEsUUFDRnpCLG9CQUFlLEVBQ2ZFLHdCQUFXLEVBQ1RFLDRCQUFhO0FBQUE7QUFBQTJCLEdBQUEsR0FIckJOLFFBQVE7QUFvQ0YsU0FBU08sT0FBT0EsQ0FBQztFQUM5QkMsS0FBSyxHQUFHLE1BQU07RUFDZGYsS0FBSztFQUNMZ0IsS0FBSztFQUNMQyxHQUFHO0VBQ0hDLEtBQUs7RUFDTEMsSUFBSSxHQUFHLE1BQU07RUFDYkMsUUFBUTtFQUNSQztBQUNLLENBQUMsRUFBRTtFQUFBckQsR0FBQTtFQUNSLE1BQU1zRCxPQUFPLEdBQUcsSUFBQUMsa0JBQVcsRUFDeEJDLEVBQXVCLElBQUs7SUFDM0IsTUFBTUMsSUFBSSxHQUFHQyxNQUFNLENBQUNELElBQUksQ0FBQ0QsRUFBRSxDQUFDLENBQUMvQyxNQUFNLENBQUVrRCxDQUFDLElBQUs7TUFDekMsSUFBSSxDQUFDLElBQUFDLHVCQUFjLEVBQUNELENBQUMsQ0FBQyxFQUFFLE9BQU8sS0FBSztNQUNwQyxNQUFNRSxDQUFDLEdBQUdMLEVBQUUsQ0FBQ0csQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO01BQ3JCLElBQUlFLENBQUMsQ0FBQ0MsSUFBSSxFQUFFLE9BQU8sS0FBSztNQUN4QixJQUFJYixHQUFHLElBQUksRUFBRTNDLEtBQUssQ0FBQ0MsT0FBTyxDQUFDc0QsQ0FBQyxDQUFDckQsSUFBSSxDQUFDLElBQUlxRCxDQUFDLENBQUNyRCxJQUFJLENBQUN1RCxRQUFRLENBQUNkLEdBQUcsQ0FBQyxDQUFDLEVBQUUsT0FBTyxLQUFLO01BQ3pFLE9BQU8sSUFBSTtJQUNiLENBQUMsQ0FBQztJQUNGUSxJQUFJLENBQUNOLElBQUksQ0FBQyxDQUFDYSxDQUFDLEVBQUVDLENBQUMsS0FBSztNQUNsQixJQUFJZCxJQUFJLEtBQUssT0FBTyxFQUFFLE9BQU8sQ0FBQ0ssRUFBRSxDQUFDUSxDQUFDLENBQUMsQ0FBQ2hDLEtBQUssSUFBSWdDLENBQUMsS0FBS1IsRUFBRSxDQUFDUyxDQUFDLENBQUMsQ0FBQ2pDLEtBQUssSUFBSWlDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUM7TUFDN0UsT0FBT0MsTUFBTSxDQUFDVixFQUFFLENBQUNTLENBQUMsQ0FBQyxDQUFDNUIsSUFBSSxJQUFJLEVBQUUsQ0FBQyxDQUFDOEIsYUFBYSxDQUFDRCxNQUFNLENBQUNWLEVBQUUsQ0FBQ1EsQ0FBQyxDQUFDLENBQUMzQixJQUFJLElBQUksRUFBRSxDQUFDLENBQUM7SUFDekUsQ0FBQyxDQUFDO0lBQ0YsT0FBT29CLElBQUk7RUFDYixDQUFDLEVBQ0QsQ0FBQ1IsR0FBRyxFQUFFRSxJQUFJLENBQ1osQ0FBQztFQUNELE1BQU1pQixPQUFPLEdBQUcsSUFBQUMscUJBQWdCLEVBQUNmLE9BQU8sQ0FBQztFQUN6QyxNQUFNZ0IsTUFBTSxHQUFHaEUsS0FBSyxDQUFDQyxPQUFPLENBQUM2RCxPQUFPLENBQUM7RUFFckMsSUFBSUcsS0FBZSxHQUFHdkIsS0FBSyxHQUN2QkEsS0FBSyxDQUFDd0IsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDcEMsR0FBRyxDQUFFcUMsQ0FBQyxJQUFLLElBQUFDLGtCQUFTLEVBQUNELENBQUMsQ0FBQ0UsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUNsRSxNQUFNLENBQUNtRSxPQUFPLENBQUMsR0FDaEUsSUFBQUMsZ0JBQVUsRUFBQ1QsT0FBTyxDQUFDO0VBQ3ZCLE1BQU1VLENBQUMsR0FBRzVCLEtBQUssR0FBRzZCLE1BQU0sQ0FBQzdCLEtBQUssQ0FBQyxHQUFHOEIsU0FBUztFQUMzQyxJQUFJRixDQUFDLElBQUlQLEtBQUssQ0FBQ1UsTUFBTSxHQUFHSCxDQUFDLEVBQUVQLEtBQUssR0FBR0EsS0FBSyxDQUFDcEMsS0FBSyxDQUFDLENBQUMsRUFBRTJDLENBQUMsQ0FBQzs7RUFFcEQ7RUFDQSxNQUFNSSxRQUFRLEdBQUc5QixRQUFRLEtBQUssVUFBVSxJQUFJLE9BQU8rQixvQkFBb0IsS0FBSyxXQUFXO0VBQ3ZGLE1BQU1DLFNBQVMsR0FBR0MsSUFBSSxDQUFDQyxHQUFHLENBQUMsQ0FBQyxFQUFFUCxNQUFNLENBQUMxQixLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7RUFDbEQsTUFBTSxDQUFDa0MsT0FBTyxFQUFFQyxVQUFVLENBQUMsR0FBRyxJQUFBQyxlQUFRLEVBQUNMLFNBQVMsQ0FBQztFQUNqRCxNQUFNTSxXQUFXLEdBQUcsSUFBQUMsYUFBTSxFQUEyQixJQUFJLENBQUM7RUFDMUQsTUFBTUMsSUFBSSxHQUFHVixRQUFRLElBQUlLLE9BQU8sR0FBR2hCLEtBQUssQ0FBQ1UsTUFBTTtFQUMvQyxNQUFNWSxLQUFLLEdBQUdYLFFBQVEsR0FBR1gsS0FBSyxDQUFDcEMsS0FBSyxDQUFDLENBQUMsRUFBRW9ELE9BQU8sQ0FBQyxHQUFHaEIsS0FBSztFQUV4RCxJQUFBdUIsZ0JBQVMsRUFBQyxNQUFNO0lBQ2QsSUFBSSxDQUFDRixJQUFJLEVBQUU7SUFDWCxNQUFNRyxFQUFFLEdBQUdMLFdBQVcsQ0FBQ00sT0FBTztJQUM5QixJQUFJLENBQUNELEVBQUUsRUFBRTtJQUNUO0lBQ0E7SUFDQSxNQUFNRSxHQUFHLEdBQUcsSUFBSWQsb0JBQW9CLENBQ2pDZSxPQUFPLElBQUs7TUFDWCxJQUFJQSxPQUFPLENBQUNDLElBQUksQ0FBRWxHLENBQUMsSUFBS0EsQ0FBQyxDQUFDbUcsY0FBYyxDQUFDLEVBQUVaLFVBQVUsQ0FBRWEsQ0FBQyxJQUFLQSxDQUFDLEdBQUdqQixTQUFTLENBQUM7SUFDN0UsQ0FBQyxFQUNEO01BQUVrQixVQUFVLEVBQUUsbUJBQW1CO01BQUVDLFNBQVMsRUFBRTtJQUFFLENBQ2xELENBQUM7SUFDRE4sR0FBRyxDQUFDTyxPQUFPLENBQUNULEVBQUUsQ0FBQztJQUNmLE9BQU8sTUFBTUUsR0FBRyxDQUFDUSxVQUFVLENBQUMsQ0FBQztFQUMvQixDQUFDLEVBQUUsQ0FBQ2IsSUFBSSxFQUFFUixTQUFTLENBQUMsQ0FBQztFQUVyQixNQUFNc0IsUUFBUSxHQUFHQSxDQUFBLEtBQU1sQixVQUFVLENBQUVhLENBQUMsSUFBS0EsQ0FBQyxHQUFHakIsU0FBUyxDQUFDO0VBRXZELG9CQUNFLElBQUF4RixXQUFBLENBQUE0QixJQUFBO0lBQUtKLFNBQVMsRUFBQyxvQkFBb0I7SUFBQUMsUUFBQSxHQUNoQ1csS0FBSyxnQkFDSixJQUFBcEMsV0FBQSxDQUFBNEIsSUFBQTtNQUFLSixTQUFTLEVBQUMscUJBQXFCO01BQUFDLFFBQUEsZ0JBQ2xDLElBQUF6QixXQUFBLENBQUF1QixHQUFBO1FBQUFFLFFBQUEsRUFBS1c7TUFBSyxDQUFLLENBQUMsZUFDaEIsSUFBQXBDLFdBQUEsQ0FBQTRCLElBQUE7UUFBTUosU0FBUyxFQUFDLEdBQUc7UUFBQUMsUUFBQSxHQUFFa0QsS0FBSyxDQUFDVSxNQUFNLEVBQUMsR0FBQyxFQUFDVixLQUFLLENBQUNVLE1BQU0sS0FBSyxDQUFDLEdBQUcsT0FBTyxHQUFHLFNBQVM7TUFBQSxDQUFPLENBQUM7SUFBQSxDQUNqRixDQUFDLEdBQ0osSUFBSSxFQUNQLENBQUNqQyxLQUFLLElBQUlzQixNQUFNLElBQUlDLEtBQUssQ0FBQ1UsTUFBTSxLQUFLLENBQUMsZ0JBQ3JDLElBQUFyRixXQUFBLENBQUF1QixHQUFBO01BQUdDLFNBQVMsRUFBQyxxQkFBcUI7TUFBQUMsUUFBQSxFQUFDO0lBQWUsQ0FBRyxDQUFDLGdCQUV0RCxJQUFBekIsV0FBQSxDQUFBNEIsSUFBQTtNQUFLSixTQUFTLEVBQUMsZUFBZTtNQUFDLGNBQVkyQixLQUFNO01BQUExQixRQUFBLEdBQzlDd0UsS0FBSyxDQUFDekQsR0FBRyxDQUFFdUIsQ0FBUyxJQUNuQlosS0FBSyxLQUFLLE1BQU0sZ0JBQUcsSUFBQW5ELFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ29CLFFBQVE7UUFBUzFCLElBQUksRUFBRThDO01BQUUsR0FBWEEsQ0FBYSxDQUFDLGdCQUFHLElBQUEvRCxXQUFBLENBQUF1QixHQUFBLEVBQUNQLEdBQUc7UUFBU0MsSUFBSSxFQUFFOEM7TUFBRSxHQUFYQSxDQUFhLENBQzVFLENBQUMsRUFDQWlDLElBQUksZ0JBQ0gsSUFBQWhHLFdBQUEsQ0FBQTRCLElBQUE7UUFDRW1GLEdBQUcsRUFBRWpCLFdBQVk7UUFDakJ0RSxTQUFTLEVBQUMsY0FBYztRQUN4QlEsT0FBTyxFQUFFOEUsUUFBUztRQUNsQixjQUFZLGlCQUFpQnJCLElBQUksQ0FBQ3VCLEdBQUcsQ0FBQ3hCLFNBQVMsRUFBRWIsS0FBSyxDQUFDVSxNQUFNLEdBQUdZLEtBQUssQ0FBQ1osTUFBTSxDQUFDLFVBQVc7UUFBQTVELFFBQUEsZ0JBRXhGLElBQUF6QixXQUFBLENBQUF1QixHQUFBO1VBQU1DLFNBQVMsRUFBQyxZQUFZO1VBQUNFLEtBQUssRUFBRTtZQUFFQyxLQUFLLEVBQUU7VUFBTTtRQUFFLENBQUUsQ0FBQyxlQUN4RCxJQUFBM0IsV0FBQSxDQUFBdUIsR0FBQTtVQUFNQyxTQUFTLEVBQUMsWUFBWTtVQUFDRSxLQUFLLEVBQUU7WUFBRUMsS0FBSyxFQUFFO1VBQU07UUFBRSxDQUFFLENBQUM7TUFBQSxDQUNsRCxDQUFDLEdBQ1AsSUFBSSxFQUNQMkQsUUFBUSxJQUFJLENBQUNVLElBQUksSUFBSXJCLEtBQUssQ0FBQ1UsTUFBTSxHQUFHRyxTQUFTLGdCQUM1QyxJQUFBeEYsV0FBQSxDQUFBNEIsSUFBQTtRQUFHSixTQUFTLEVBQUMsU0FBUztRQUFDeUYsSUFBSSxFQUFDLFFBQVE7UUFBQXhGLFFBQUEsR0FBQyxjQUFZLEVBQUNrRCxLQUFLLENBQUNVLE1BQU0sRUFBQyxXQUFTO01BQUEsQ0FBRyxDQUFDLEdBQzFFLElBQUk7SUFBQSxDQUNMLENBQ047RUFBQSxDQUNFLENBQUM7QUFFVjtBQUFDakYsR0FBQSxDQS9GdUI4QyxPQUFPO0VBQUEsUUEyQmJ1QixxQkFBZ0I7QUFBQTtBQUFBeUMsR0FBQSxHQTNCVmhFLE9BQU87QUFBQSxJQUFBUixFQUFBLEVBQUFPLEdBQUEsRUFBQWlFLEdBQUE7QUFBQUMsWUFBQSxDQUFBekUsRUFBQTtBQUFBeUUsWUFBQSxDQUFBbEUsR0FBQTtBQUFBa0UsWUFBQSxDQUFBRCxHQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}