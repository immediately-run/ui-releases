var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.map.js");
var _vitest = require("vitest");
var _react = require("react");
var _client = require("react-dom/client");
var _nodeModule = require("node:module");
var _nodePath = require("node:path");
var _TinkerableContext = require("@immediately-run/sdk/TinkerableContext");
var _shell = require("../lib/shell");
var _navigationPolicy = require("../lib/navigationPolicy");
var _content = require("../lib/content");
var _contentRoot = require("../lib/contentRoot");
var _jsxRuntime = require("react/jsx-runtime");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; } // @vitest-environment jsdom
// G-CUST-3 (APP_CUSTOMIZATION_SPEC §4.3, R3-872) — the sweep: EVERY component under
// src/components/ that renders the SDK `<Link>` (or calls `navigate(`) is
// enumerated FROM DISK (never a hand-list — a new component that skips the policy
// fails this suite on arrival), rendered with a recording policy over a real
// corpus entry, and plain-clicked: the policy must receive the resolved target
// `{ key, href, fragment?, from? }` and the browser default must be prevented.
// The enumeration reads the components directory through a DIRECT require of
// node:fs (createRequire), not the test graph's `fs` — the file mocks `fs` for
// the components under test, and the enumeration must not eat its own mock.
const {
  readFileSync,
  readdirSync
} = (0, _nodeModule.createRequire)($ir_import_meta.url)('node:fs');
(0, _vitest.beforeAll)(() => {
  Object.defineProperty(window, 'matchMedia', {
    writable: true,
    value: q => ({
      matches: false,
      media: q,
      addEventListener: () => {},
      removeEventListener: () => {},
      addListener: () => {},
      removeListener: () => {},
      dispatchEvent: () => false,
      onchange: null
    })
  });
  (0, _contentRoot.setContentRoot)('/app/content/');
});

// ── The corpus fixture (a real two-entry shape) ──────────────────────────────
const ENTRY = '/app/content/wiki/a.mdx';
const OTHER = '/app/content/wiki/b.mdx';
const PERSON = '/app/content/people/ada.mdx';
const INDEX = '/app/content/wiki/index.mdx';
const WIKI_C = '/app/content/wiki/c.mdx';
const META = {
  [ENTRY]: {
    title: 'Reference entry.',
    render: 'safe',
    date: '2026-06-22'
  },
  [INDEX]: {
    title: 'The wiki index.',
    render: 'safe'
  },
  [WIKI_C]: {
    title: 'A third entry.',
    render: 'safe'
  },
  [OTHER]: {
    title: 'The other entry.',
    render: 'safe',
    date: '2026-06-22'
  },
  [PERSON]: {
    name: 'Ada',
    role: 'eng',
    team: 'core',
    phone: '555-1',
    email: 'a@b.c'
  },
  '/app/content/home.mdx': {
    title: 'Home',
    render: 'safe'
  }
};
const {
  readFile,
  readdirFs
} = _vitest.vi.hoisted(() => ({
  readFile: _vitest.vi.fn(),
  readdirFs: _vitest.vi.fn()
}));
_vitest.vi.mock('fs', async importOriginal => {
  const actual = await importOriginal();
  return {
    ...actual,
    default: {
      ...actual.default,
      promises: {
        ...actual.default.promises,
        readFile: (...a) => readFile(...a),
        readdir: (...a) => readdirFs(...a)
      }
    }
  };
});
globalThis.__sandpackSharedFs = {
  promises: {
    readFile: (...a) => readFile(...a)
  }
};
const NAV = {
  mode: 'github',
  namespace: 'immediately-run',
  provider: 'github',
  repository: 'corpus',
  ref: 'main',
  sandboxPath: ENTRY,
  hash: '',
  search: ''
};

/** The shell slice the chrome components read (DirectoryView/PageView read the page
 *  states; GroveNav/Footer read nav; every entry link's `from` reads the route key). */
const shell = {
  siteTitle: 'Fixture',
  navItems: [{
    key: OTHER,
    href: (0, _content.keyToHref)(OTHER),
    label: 'The other entry.'
  }],
  entryKey: ENTRY,
  vw: 'desktop',
  navMode: 'top',
  writable: false,
  openEditor: () => {},
  editBusy: false,
  editRefused: false,
  editHint: '',
  directory: {
    status: 'none'
  },
  missing: true,
  suggestion: OTHER,
  mins: 0,
  safe: true,
  includePath: ENTRY,
  layout: 'doc',
  showRails: false
};

// ── The disk enumeration (G-CUST-3's "never a hand-list") ────────────────────
const COMPONENTS_DIR = (0, _nodePath.join)(__dirname);
const linkComponents = readdirSync(COMPONENTS_DIR).filter(f => f.endsWith('.tsx') && !f.includes('.test.')).filter(f => /<Link\b|navigate\(/.test(readFileSync((0, _nodePath.join)(COMPONENTS_DIR, f), 'utf8'))).map(f => f.replace(/\.tsx$/, ''));

// Per-component minimal render context (props, and a sandboxPath when the
// component's content depends on which entry it renders inside).
const FIXTURES = {
  WikiLink: {
    props: {
      href: '/wiki/b.mdx#sec-4',
      children: 'the other'
    }
  },
  Search: {
    props: {
      onClose: () => {}
    }
  },
  Drawer: {
    props: {
      siteTitle: 'Fixture',
      nav: [{
        key: OTHER,
        href: (0, _content.keyToHref)(OTHER),
        label: 'Other',
        cur: false
      }],
      onClose: () => {}
    }
  },
  // ChildPages lists the current entry's INDEX siblings — the current entry must
  // be the namespace's index for the listing to have rows.
  ChildPages: {
    sandboxPath: '/app/content/wiki/index.mdx'
  },
  // DirectoryList reads the current entry's folder — the readdir mock answers it
  // (see beforeEach), and the rows link to entries the index knows.
  DirectoryList: {
    sandboxPath: '/app/content/wiki/index.mdx'
  }
};

// ── Harness ──────────────────────────────────────────────────────────────────

function Harness({
  children,
  record,
  sandboxPath
}) {
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_TinkerableContext.TinkerableContext.Provider, {
    value: {
      outerHref: 'https://immediately.run/x',
      navigationState: {
        ...NAV,
        sandboxPath: sandboxPath ?? NAV.sandboxPath
      },
      routingSpec: {
        routes: []
      },
      filesMetadata: META
    },
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_shell.GroveShellContext.Provider, {
      value: shell,
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_navigationPolicy.NavigationPolicyContext.Provider, {
        value: record,
        children: children
      })
    })
  });
}

/** Render once and read the anchor hrefs on screen (each href re-rendered + clicked
 *  on its own mount — overlay components unmount after their first click). */
_c = Harness;
async function renderAndClickAll(name, build) {
  // first pass: which hrefs does it render?
  const probe = document.createElement('div');
  document.body.appendChild(probe);
  const probeRoot = (0, _client.createRoot)(probe);
  await (0, _react.act)(async () => {
    probeRoot.render(/*#__PURE__*/(0, _jsxRuntime.jsx)(Harness, {
      record: () => {},
      sandboxPath: FIXTURES[name]?.sandboxPath,
      children: build()
    }));
  });
  for (let i = 0; i < 8; i++) await (0, _react.act)(async () => {});
  // Every anchor OCCURRENCE, not every distinct href (round 2 nit): a second
  // same-href anchor reverted to direct navigation must fail too.
  const hrefs = [...probe.querySelectorAll('a[href]')].map(a => a.getAttribute('href'));
  (0, _vitest.expect)(hrefs.length, `${name} renders at least one link`).toBeGreaterThan(0);
  await (0, _react.act)(async () => {
    probeRoot.unmount();
  });
  probe.remove();
  const perHref = [];
  for (let occurrence = 0; occurrence < hrefs.length; occurrence++) {
    const href = hrefs[occurrence];
    const ordinal = hrefs.slice(0, occurrence).filter(h => h === href).length;
    const calls = [];
    const container = document.createElement('div');
    document.body.appendChild(container);
    const root = (0, _client.createRoot)(container);
    await (0, _react.act)(async () => {
      root.render(/*#__PURE__*/(0, _jsxRuntime.jsx)(Harness, {
        record: t => {
          calls.push(t);
        },
        sandboxPath: FIXTURES[name]?.sandboxPath,
        children: build()
      }));
    });
    for (let i = 0; i < 8; i++) await (0, _react.act)(async () => {});
    const anchor = container.querySelectorAll(`a[href="${href.replace(/"/g, '\\"')}"]`)[ordinal];
    (0, _vitest.expect)(anchor, `${name}: the ${href} link still renders`).toBeTruthy();
    let prevented = false;
    const event = new MouseEvent('click', {
      bubbles: true,
      cancelable: true,
      button: 0
    });
    const origPrevent = event.preventDefault.bind(event);
    event.preventDefault = () => {
      prevented = true;
      origPrevent();
    };
    await (0, _react.act)(async () => {
      anchor.dispatchEvent(event);
    });
    await (0, _react.act)(async () => {
      root.unmount();
    });
    container.remove();
    perHref.push({
      href,
      calls,
      prevented
    });
  }
  return {
    perHref
  };
}
(0, _vitest.beforeEach)(() => {
  readFile.mockReset();
  readFile.mockImplementation(async p =>
  // Backlinks scans bodies for links TO the rendered entry: b's body links a.
  String(p).endsWith('/b.mdx') ? '---\ntitle: B\nrender: safe\n---\n\n[the first](/wiki/a.mdx)\n' : '---\ntitle: T\nrender: safe\n---\n\nplain body\n');
  readdirFs.mockReset();
  const dirent = (name, isDir = false) => ({
    name,
    isDirectory: () => isDir
  });
  readdirFs.mockImplementation(async () => [dirent('c.mdx'), dirent('assets', true)]);
  void readdirFs;
});
(0, _vitest.describe)('G-CUST-3 — every entry link rides the navigation policy', () => {
  (0, _vitest.it)('the enumeration covers the known link components (non-vacuity)', () => {
    for (const name of ['WikiLink', 'Backlinks', 'ChildPages', 'Directory', 'DirectoryList', 'DirectoryView', 'DocList', 'Drawer', 'GroveFooter', 'GroveNav', 'PageView', 'Search', 'Sidebar', 'Timeline']) {
      (0, _vitest.expect)(linkComponents, `${name} is enumerated`).toContain(name);
    }
  });
  _vitest.it.each(linkComponents)('%s: a plain click reaches the policy with a resolved target', async name => {
    const mod = await (specifier => new Promise(r => r(specifier)).then(s => _interopRequireWildcard(require(s))))(`./${name}`);
    const Component = mod.default;
    const props = FIXTURES[name]?.props ?? {};
    // EVERY anchor the component renders, each clicked on its own mount (an
    // overlay's first click closes it) — the item's do-not carve-out is a second
    // link navigating directly 'because it's chrome', and only probing the first
    // anchor would miss exactly that.
    const {
      perHref
    } = await renderAndClickAll(name, () => /*#__PURE__*/(0, _jsxRuntime.jsx)(Component, {
      ...props
    }));
    for (const {
      href,
      calls,
      prevented
    } of perHref) {
      (0, _vitest.expect)(calls.length, `${name}: the plain click on ${href} reaches the policy`).toBeGreaterThan(0);
      const t = calls[0];
      (0, _vitest.expect)(typeof t.href, 'the target carries the concrete href').toBe('string');
      (0, _vitest.expect)(t.href.length).toBeGreaterThan(0);
      // the DOM anchor carries the SDK's outer-URL resolution of the href the
      // component passed; the policy receives the component-level one
      (0, _vitest.expect)(href === t.href || href.endsWith(t.href), `${name}: the DOM href ${href} resolves the policy's ${t.href}`).toBe(true);
      (0, _vitest.expect)(typeof t.key, 'the target carries the resolved key').toBe('string');
      (0, _vitest.expect)(t.key.length).toBeGreaterThan(0);
      // §4.3's shape: fragment is absent or a bare id, never '#'-prefixed
      if (t.fragment !== undefined) (0, _vitest.expect)(t.fragment.startsWith('#'), `fragment carries no '#' (${t.fragment})`).toBe(false);
      // `from` is the entry key when the link renders inside one (content
      // components), absent for the chrome (nav/footer/drawer/sidebar render
      // outside an entry) — the shape pinned, not the value guessed.
      if (t.from !== undefined) (0, _vitest.expect)(typeof t.from).toBe('string');
      // the WikiLink fixture is fragment-bearing: the rendered href KEEPS the
      // '#sec-4' (round 2's regression — the '#' strip corrupted hrefs), and the
      // policy's fragment is the bare id
      if (name === 'WikiLink') {
        (0, _vitest.expect)(href).toContain('#sec-4');
        (0, _vitest.expect)(t.fragment).toBe('sec-4');
      }
      (0, _vitest.expect)(prevented, `${name}: the plain click on ${href} prevents the browser default`).toBe(true);
    }
  });
});
var _c;
$RefreshReg$(_c, "Harness");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZXN0IiwicmVxdWlyZSIsIl9yZWFjdCIsIl9jbGllbnQiLCJfbm9kZU1vZHVsZSIsIl9ub2RlUGF0aCIsIl9UaW5rZXJhYmxlQ29udGV4dCIsIl9zaGVsbCIsIl9uYXZpZ2F0aW9uUG9saWN5IiwiX2NvbnRlbnQiLCJfY29udGVudFJvb3QiLCJfanN4UnVudGltZSIsIl9nZXRSZXF1aXJlV2lsZGNhcmRDYWNoZSIsImUiLCJXZWFrTWFwIiwiciIsInQiLCJfaW50ZXJvcFJlcXVpcmVXaWxkY2FyZCIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiaGFzIiwiZ2V0IiwibiIsIl9fcHJvdG9fXyIsImEiLCJPYmplY3QiLCJkZWZpbmVQcm9wZXJ0eSIsImdldE93blByb3BlcnR5RGVzY3JpcHRvciIsInUiLCJoYXNPd25Qcm9wZXJ0eSIsImNhbGwiLCJpIiwic2V0IiwicmVhZEZpbGVTeW5jIiwicmVhZGRpclN5bmMiLCJjcmVhdGVSZXF1aXJlIiwiJGlyX2ltcG9ydF9tZXRhIiwidXJsIiwiYmVmb3JlQWxsIiwid2luZG93Iiwid3JpdGFibGUiLCJ2YWx1ZSIsInEiLCJtYXRjaGVzIiwibWVkaWEiLCJhZGRFdmVudExpc3RlbmVyIiwicmVtb3ZlRXZlbnRMaXN0ZW5lciIsImFkZExpc3RlbmVyIiwicmVtb3ZlTGlzdGVuZXIiLCJkaXNwYXRjaEV2ZW50Iiwib25jaGFuZ2UiLCJzZXRDb250ZW50Um9vdCIsIkVOVFJZIiwiT1RIRVIiLCJQRVJTT04iLCJJTkRFWCIsIldJS0lfQyIsIk1FVEEiLCJ0aXRsZSIsInJlbmRlciIsImRhdGUiLCJuYW1lIiwicm9sZSIsInRlYW0iLCJwaG9uZSIsImVtYWlsIiwicmVhZEZpbGUiLCJyZWFkZGlyRnMiLCJ2aSIsImhvaXN0ZWQiLCJmbiIsIm1vY2siLCJpbXBvcnRPcmlnaW5hbCIsImFjdHVhbCIsInByb21pc2VzIiwicmVhZGRpciIsImdsb2JhbFRoaXMiLCJfX3NhbmRwYWNrU2hhcmVkRnMiLCJOQVYiLCJtb2RlIiwibmFtZXNwYWNlIiwicHJvdmlkZXIiLCJyZXBvc2l0b3J5IiwicmVmIiwic2FuZGJveFBhdGgiLCJoYXNoIiwic2VhcmNoIiwic2hlbGwiLCJzaXRlVGl0bGUiLCJuYXZJdGVtcyIsImtleSIsImhyZWYiLCJrZXlUb0hyZWYiLCJsYWJlbCIsImVudHJ5S2V5IiwidnciLCJuYXZNb2RlIiwib3BlbkVkaXRvciIsImVkaXRCdXN5IiwiZWRpdFJlZnVzZWQiLCJlZGl0SGludCIsImRpcmVjdG9yeSIsInN0YXR1cyIsIm1pc3NpbmciLCJzdWdnZXN0aW9uIiwibWlucyIsInNhZmUiLCJpbmNsdWRlUGF0aCIsImxheW91dCIsInNob3dSYWlscyIsIkNPTVBPTkVOVFNfRElSIiwiam9pbiIsIl9fZGlybmFtZSIsImxpbmtDb21wb25lbnRzIiwiZmlsdGVyIiwiZiIsImVuZHNXaXRoIiwiaW5jbHVkZXMiLCJ0ZXN0IiwibWFwIiwicmVwbGFjZSIsIkZJWFRVUkVTIiwiV2lraUxpbmsiLCJwcm9wcyIsImNoaWxkcmVuIiwiU2VhcmNoIiwib25DbG9zZSIsIkRyYXdlciIsIm5hdiIsImN1ciIsIkNoaWxkUGFnZXMiLCJEaXJlY3RvcnlMaXN0IiwiSGFybmVzcyIsInJlY29yZCIsImpzeCIsIlRpbmtlcmFibGVDb250ZXh0IiwiUHJvdmlkZXIiLCJvdXRlckhyZWYiLCJuYXZpZ2F0aW9uU3RhdGUiLCJyb3V0aW5nU3BlYyIsInJvdXRlcyIsImZpbGVzTWV0YWRhdGEiLCJHcm92ZVNoZWxsQ29udGV4dCIsIk5hdmlnYXRpb25Qb2xpY3lDb250ZXh0IiwiX2MiLCJyZW5kZXJBbmRDbGlja0FsbCIsImJ1aWxkIiwicHJvYmUiLCJkb2N1bWVudCIsImNyZWF0ZUVsZW1lbnQiLCJib2R5IiwiYXBwZW5kQ2hpbGQiLCJwcm9iZVJvb3QiLCJjcmVhdGVSb290IiwiYWN0IiwiaHJlZnMiLCJxdWVyeVNlbGVjdG9yQWxsIiwiZ2V0QXR0cmlidXRlIiwiZXhwZWN0IiwibGVuZ3RoIiwidG9CZUdyZWF0ZXJUaGFuIiwidW5tb3VudCIsInJlbW92ZSIsInBlckhyZWYiLCJvY2N1cnJlbmNlIiwib3JkaW5hbCIsInNsaWNlIiwiaCIsImNhbGxzIiwiY29udGFpbmVyIiwicm9vdCIsInB1c2giLCJhbmNob3IiLCJ0b0JlVHJ1dGh5IiwicHJldmVudGVkIiwiZXZlbnQiLCJNb3VzZUV2ZW50IiwiYnViYmxlcyIsImNhbmNlbGFibGUiLCJidXR0b24iLCJvcmlnUHJldmVudCIsInByZXZlbnREZWZhdWx0IiwiYmluZCIsImJlZm9yZUVhY2giLCJtb2NrUmVzZXQiLCJtb2NrSW1wbGVtZW50YXRpb24iLCJwIiwiU3RyaW5nIiwiZGlyZW50IiwiaXNEaXIiLCJpc0RpcmVjdG9yeSIsImRlc2NyaWJlIiwiaXQiLCJ0b0NvbnRhaW4iLCJlYWNoIiwibW9kIiwic3BlY2lmaWVyIiwiUHJvbWlzZSIsInRoZW4iLCJzIiwiQ29tcG9uZW50IiwidG9CZSIsImZyYWdtZW50IiwidW5kZWZpbmVkIiwic3RhcnRzV2l0aCIsImZyb20iLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJuYXZpZ2F0aW9uUG9saWN5LnN3ZWVwLnRlc3QudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIEB2aXRlc3QtZW52aXJvbm1lbnQganNkb21cbi8vIEctQ1VTVC0zIChBUFBfQ1VTVE9NSVpBVElPTl9TUEVDIMKnNC4zLCBSMy04NzIpIOKAlCB0aGUgc3dlZXA6IEVWRVJZIGNvbXBvbmVudCB1bmRlclxuLy8gc3JjL2NvbXBvbmVudHMvIHRoYXQgcmVuZGVycyB0aGUgU0RLIGA8TGluaz5gIChvciBjYWxscyBgbmF2aWdhdGUoYCkgaXNcbi8vIGVudW1lcmF0ZWQgRlJPTSBESVNLIChuZXZlciBhIGhhbmQtbGlzdCDigJQgYSBuZXcgY29tcG9uZW50IHRoYXQgc2tpcHMgdGhlIHBvbGljeVxuLy8gZmFpbHMgdGhpcyBzdWl0ZSBvbiBhcnJpdmFsKSwgcmVuZGVyZWQgd2l0aCBhIHJlY29yZGluZyBwb2xpY3kgb3ZlciBhIHJlYWxcbi8vIGNvcnB1cyBlbnRyeSwgYW5kIHBsYWluLWNsaWNrZWQ6IHRoZSBwb2xpY3kgbXVzdCByZWNlaXZlIHRoZSByZXNvbHZlZCB0YXJnZXRcbi8vIGB7IGtleSwgaHJlZiwgZnJhZ21lbnQ/LCBmcm9tPyB9YCBhbmQgdGhlIGJyb3dzZXIgZGVmYXVsdCBtdXN0IGJlIHByZXZlbnRlZC5cbmltcG9ydCB7IGRlc2NyaWJlLCBpdCwgZXhwZWN0LCB2aSwgYmVmb3JlQWxsLCBiZWZvcmVFYWNoIH0gZnJvbSAndml0ZXN0JztcbmltcG9ydCB7IGFjdCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IGNyZWF0ZVJvb3QsIHR5cGUgUm9vdCB9IGZyb20gJ3JlYWN0LWRvbS9jbGllbnQnO1xuaW1wb3J0IHR5cGUgeyBSZWFjdE5vZGUgfSBmcm9tICdyZWFjdCc7XG4vLyBUaGUgZW51bWVyYXRpb24gcmVhZHMgdGhlIGNvbXBvbmVudHMgZGlyZWN0b3J5IHRocm91Z2ggYSBESVJFQ1QgcmVxdWlyZSBvZlxuLy8gbm9kZTpmcyAoY3JlYXRlUmVxdWlyZSksIG5vdCB0aGUgdGVzdCBncmFwaCdzIGBmc2Ag4oCUIHRoZSBmaWxlIG1vY2tzIGBmc2AgZm9yXG4vLyB0aGUgY29tcG9uZW50cyB1bmRlciB0ZXN0LCBhbmQgdGhlIGVudW1lcmF0aW9uIG11c3Qgbm90IGVhdCBpdHMgb3duIG1vY2suXG5pbXBvcnQgeyBjcmVhdGVSZXF1aXJlIH0gZnJvbSAnbm9kZTptb2R1bGUnO1xuaW1wb3J0IHsgam9pbiB9IGZyb20gJ25vZGU6cGF0aCc7XG5jb25zdCB7IHJlYWRGaWxlU3luYywgcmVhZGRpclN5bmMgfSA9IGNyZWF0ZVJlcXVpcmUoaW1wb3J0Lm1ldGEudXJsKSgnbm9kZTpmcycpIGFzIHR5cGVvZiBpbXBvcnQoJ25vZGU6ZnMnKTtcbmltcG9ydCB7IFRpbmtlcmFibGVDb250ZXh0IH0gZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9zZGsvVGlua2VyYWJsZUNvbnRleHQnO1xuaW1wb3J0IHsgR3JvdmVTaGVsbENvbnRleHQsIHR5cGUgR3JvdmVTaGVsbCB9IGZyb20gJy4uL2xpYi9zaGVsbCc7XG5pbXBvcnQgeyBOYXZpZ2F0aW9uUG9saWN5Q29udGV4dCwgdHlwZSBGb2xsb3dMaW5rVGFyZ2V0IH0gZnJvbSAnLi4vbGliL25hdmlnYXRpb25Qb2xpY3knO1xuaW1wb3J0IHsga2V5VG9IcmVmIH0gZnJvbSAnLi4vbGliL2NvbnRlbnQnO1xuaW1wb3J0IHsgc2V0Q29udGVudFJvb3QgfSBmcm9tICcuLi9saWIvY29udGVudFJvb3QnO1xuXG5iZWZvcmVBbGwoKCkgPT4ge1xuICBPYmplY3QuZGVmaW5lUHJvcGVydHkod2luZG93LCAnbWF0Y2hNZWRpYScsIHtcbiAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICB2YWx1ZTogKHE6IHN0cmluZykgPT4gKHsgbWF0Y2hlczogZmFsc2UsIG1lZGlhOiBxLCBhZGRFdmVudExpc3RlbmVyOiAoKSA9PiB7fSwgcmVtb3ZlRXZlbnRMaXN0ZW5lcjogKCkgPT4ge30sIGFkZExpc3RlbmVyOiAoKSA9PiB7fSwgcmVtb3ZlTGlzdGVuZXI6ICgpID0+IHt9LCBkaXNwYXRjaEV2ZW50OiAoKSA9PiBmYWxzZSwgb25jaGFuZ2U6IG51bGwgfSksXG4gIH0pO1xuICBzZXRDb250ZW50Um9vdCgnL2FwcC9jb250ZW50LycpO1xufSk7XG5cbi8vIOKUgOKUgCBUaGUgY29ycHVzIGZpeHR1cmUgKGEgcmVhbCB0d28tZW50cnkgc2hhcGUpIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuY29uc3QgRU5UUlkgPSAnL2FwcC9jb250ZW50L3dpa2kvYS5tZHgnO1xuY29uc3QgT1RIRVIgPSAnL2FwcC9jb250ZW50L3dpa2kvYi5tZHgnO1xuY29uc3QgUEVSU09OID0gJy9hcHAvY29udGVudC9wZW9wbGUvYWRhLm1keCc7XG5jb25zdCBJTkRFWCA9ICcvYXBwL2NvbnRlbnQvd2lraS9pbmRleC5tZHgnO1xuY29uc3QgV0lLSV9DID0gJy9hcHAvY29udGVudC93aWtpL2MubWR4JztcbmNvbnN0IE1FVEE6IFJlY29yZDxzdHJpbmcsIFJlY29yZDxzdHJpbmcsIHVua25vd24+PiA9IHtcbiAgW0VOVFJZXTogeyB0aXRsZTogJ1JlZmVyZW5jZSBlbnRyeS4nLCByZW5kZXI6ICdzYWZlJywgZGF0ZTogJzIwMjYtMDYtMjInIH0sXG4gIFtJTkRFWF06IHsgdGl0bGU6ICdUaGUgd2lraSBpbmRleC4nLCByZW5kZXI6ICdzYWZlJyB9LFxuICBbV0lLSV9DXTogeyB0aXRsZTogJ0EgdGhpcmQgZW50cnkuJywgcmVuZGVyOiAnc2FmZScgfSxcbiAgW09USEVSXTogeyB0aXRsZTogJ1RoZSBvdGhlciBlbnRyeS4nLCByZW5kZXI6ICdzYWZlJywgZGF0ZTogJzIwMjYtMDYtMjInIH0sXG4gIFtQRVJTT05dOiB7IG5hbWU6ICdBZGEnLCByb2xlOiAnZW5nJywgdGVhbTogJ2NvcmUnLCBwaG9uZTogJzU1NS0xJywgZW1haWw6ICdhQGIuYycgfSxcbiAgJy9hcHAvY29udGVudC9ob21lLm1keCc6IHsgdGl0bGU6ICdIb21lJywgcmVuZGVyOiAnc2FmZScgfSxcbn07XG5cbmNvbnN0IHsgcmVhZEZpbGUsIHJlYWRkaXJGcyB9ID0gdmkuaG9pc3RlZCgoKSA9PiAoeyByZWFkRmlsZTogdmkuZm4oKSwgcmVhZGRpckZzOiB2aS5mbigpIH0pKTtcbnZpLm1vY2soJ2ZzJywgYXN5bmMgKGltcG9ydE9yaWdpbmFsKSA9PiB7XG4gIGNvbnN0IGFjdHVhbCA9IChhd2FpdCBpbXBvcnRPcmlnaW5hbCgpKSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgcmV0dXJuIHtcbiAgICAuLi5hY3R1YWwsXG4gICAgZGVmYXVsdDoge1xuICAgICAgLi4uKGFjdHVhbC5kZWZhdWx0IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KSxcbiAgICAgIHByb21pc2VzOiB7XG4gICAgICAgIC4uLigoYWN0dWFsLmRlZmF1bHQgYXMgeyBwcm9taXNlczogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gfSkucHJvbWlzZXMpLFxuICAgICAgICByZWFkRmlsZTogKC4uLmE6IHVua25vd25bXSkgPT4gcmVhZEZpbGUoLi4uKGEgYXMgW10pKSxcbiAgICAgICAgcmVhZGRpcjogKC4uLmE6IHVua25vd25bXSkgPT4gcmVhZGRpckZzKC4uLihhIGFzIFtdKSksXG4gICAgICB9LFxuICAgIH0sXG4gIH07XG59KTtcbihnbG9iYWxUaGlzIGFzIHsgX19zYW5kcGFja1NoYXJlZEZzPzogdW5rbm93biB9KS5fX3NhbmRwYWNrU2hhcmVkRnMgPSB7XG4gIHByb21pc2VzOiB7IHJlYWRGaWxlOiAoLi4uYTogdW5rbm93bltdKSA9PiByZWFkRmlsZSguLi4oYSBhcyBbXSkpIH0sXG59O1xuXG5jb25zdCBOQVYgPSB7XG4gIG1vZGU6ICdnaXRodWInLFxuICBuYW1lc3BhY2U6ICdpbW1lZGlhdGVseS1ydW4nLFxuICBwcm92aWRlcjogJ2dpdGh1YicsXG4gIHJlcG9zaXRvcnk6ICdjb3JwdXMnLFxuICByZWY6ICdtYWluJyxcbiAgc2FuZGJveFBhdGg6IEVOVFJZLFxuICBoYXNoOiAnJyxcbiAgc2VhcmNoOiAnJyxcbn07XG5cbi8qKiBUaGUgc2hlbGwgc2xpY2UgdGhlIGNocm9tZSBjb21wb25lbnRzIHJlYWQgKERpcmVjdG9yeVZpZXcvUGFnZVZpZXcgcmVhZCB0aGUgcGFnZVxuICogIHN0YXRlczsgR3JvdmVOYXYvRm9vdGVyIHJlYWQgbmF2OyBldmVyeSBlbnRyeSBsaW5rJ3MgYGZyb21gIHJlYWRzIHRoZSByb3V0ZSBrZXkpLiAqL1xuY29uc3Qgc2hlbGw6IEdyb3ZlU2hlbGwgPSB7XG4gIHNpdGVUaXRsZTogJ0ZpeHR1cmUnLFxuICBuYXZJdGVtczogW3sga2V5OiBPVEhFUiwgaHJlZjoga2V5VG9IcmVmKE9USEVSKSwgbGFiZWw6ICdUaGUgb3RoZXIgZW50cnkuJyB9XSxcbiAgZW50cnlLZXk6IEVOVFJZLFxuICB2dzogJ2Rlc2t0b3AnLFxuICBuYXZNb2RlOiAndG9wJyxcbiAgd3JpdGFibGU6IGZhbHNlLFxuICBvcGVuRWRpdG9yOiAoKSA9PiB7fSxcbiAgZWRpdEJ1c3k6IGZhbHNlLFxuICBlZGl0UmVmdXNlZDogZmFsc2UsXG4gIGVkaXRIaW50OiAnJyxcbiAgZGlyZWN0b3J5OiB7IHN0YXR1czogJ25vbmUnIH0sXG4gIG1pc3Npbmc6IHRydWUsXG4gIHN1Z2dlc3Rpb246IE9USEVSLFxuICBtaW5zOiAwLFxuICBzYWZlOiB0cnVlLFxuICBpbmNsdWRlUGF0aDogRU5UUlksXG4gIGxheW91dDogJ2RvYycsXG4gIHNob3dSYWlsczogZmFsc2UsXG59IGFzIHVua25vd24gYXMgR3JvdmVTaGVsbDtcblxuLy8g4pSA4pSAIFRoZSBkaXNrIGVudW1lcmF0aW9uIChHLUNVU1QtMydzIFwibmV2ZXIgYSBoYW5kLWxpc3RcIikg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5jb25zdCBDT01QT05FTlRTX0RJUiA9IGpvaW4oX19kaXJuYW1lKTtcbmNvbnN0IGxpbmtDb21wb25lbnRzID0gcmVhZGRpclN5bmMoQ09NUE9ORU5UU19ESVIpXG4gIC5maWx0ZXIoKGYpID0+IGYuZW5kc1dpdGgoJy50c3gnKSAmJiAhZi5pbmNsdWRlcygnLnRlc3QuJykpXG4gIC5maWx0ZXIoKGYpID0+IC88TGlua1xcYnxuYXZpZ2F0ZVxcKC8udGVzdChyZWFkRmlsZVN5bmMoam9pbihDT01QT05FTlRTX0RJUiwgZiksICd1dGY4JykpKVxuICAubWFwKChmKSA9PiBmLnJlcGxhY2UoL1xcLnRzeCQvLCAnJykpO1xuXG4vLyBQZXItY29tcG9uZW50IG1pbmltYWwgcmVuZGVyIGNvbnRleHQgKHByb3BzLCBhbmQgYSBzYW5kYm94UGF0aCB3aGVuIHRoZVxuLy8gY29tcG9uZW50J3MgY29udGVudCBkZXBlbmRzIG9uIHdoaWNoIGVudHJ5IGl0IHJlbmRlcnMgaW5zaWRlKS5cbmNvbnN0IEZJWFRVUkVTOiBSZWNvcmQ8c3RyaW5nLCB7IHByb3BzPzogUmVjb3JkPHN0cmluZywgdW5rbm93bj47IHNhbmRib3hQYXRoPzogc3RyaW5nIH0+ID0ge1xuICBXaWtpTGluazogeyBwcm9wczogeyBocmVmOiAnL3dpa2kvYi5tZHgjc2VjLTQnLCBjaGlsZHJlbjogJ3RoZSBvdGhlcicgfSB9LFxuICBTZWFyY2g6IHsgcHJvcHM6IHsgb25DbG9zZTogKCkgPT4ge30gfSB9LFxuICBEcmF3ZXI6IHsgcHJvcHM6IHsgc2l0ZVRpdGxlOiAnRml4dHVyZScsIG5hdjogW3sga2V5OiBPVEhFUiwgaHJlZjoga2V5VG9IcmVmKE9USEVSKSwgbGFiZWw6ICdPdGhlcicsIGN1cjogZmFsc2UgfV0sIG9uQ2xvc2U6ICgpID0+IHt9IH0gfSxcbiAgLy8gQ2hpbGRQYWdlcyBsaXN0cyB0aGUgY3VycmVudCBlbnRyeSdzIElOREVYIHNpYmxpbmdzIOKAlCB0aGUgY3VycmVudCBlbnRyeSBtdXN0XG4gIC8vIGJlIHRoZSBuYW1lc3BhY2UncyBpbmRleCBmb3IgdGhlIGxpc3RpbmcgdG8gaGF2ZSByb3dzLlxuICBDaGlsZFBhZ2VzOiB7IHNhbmRib3hQYXRoOiAnL2FwcC9jb250ZW50L3dpa2kvaW5kZXgubWR4JyB9LFxuICAvLyBEaXJlY3RvcnlMaXN0IHJlYWRzIHRoZSBjdXJyZW50IGVudHJ5J3MgZm9sZGVyIOKAlCB0aGUgcmVhZGRpciBtb2NrIGFuc3dlcnMgaXRcbiAgLy8gKHNlZSBiZWZvcmVFYWNoKSwgYW5kIHRoZSByb3dzIGxpbmsgdG8gZW50cmllcyB0aGUgaW5kZXgga25vd3MuXG4gIERpcmVjdG9yeUxpc3Q6IHsgc2FuZGJveFBhdGg6ICcvYXBwL2NvbnRlbnQvd2lraS9pbmRleC5tZHgnIH0sXG59O1xuXG4vLyDilIDilIAgSGFybmVzcyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuZnVuY3Rpb24gSGFybmVzcyh7IGNoaWxkcmVuLCByZWNvcmQsIHNhbmRib3hQYXRoIH06IHsgY2hpbGRyZW46IFJlYWN0Tm9kZTsgcmVjb3JkOiAodDogRm9sbG93TGlua1RhcmdldCkgPT4gdm9pZDsgc2FuZGJveFBhdGg/OiBzdHJpbmcgfSkge1xuICByZXR1cm4gKFxuICAgIDxUaW5rZXJhYmxlQ29udGV4dC5Qcm92aWRlclxuICAgICAgdmFsdWU9e3tcbiAgICAgICAgb3V0ZXJIcmVmOiAnaHR0cHM6Ly9pbW1lZGlhdGVseS5ydW4veCcsXG4gICAgICAgIG5hdmlnYXRpb25TdGF0ZTogeyAuLi5OQVYsIHNhbmRib3hQYXRoOiBzYW5kYm94UGF0aCA/PyBOQVYuc2FuZGJveFBhdGggfSxcbiAgICAgICAgcm91dGluZ1NwZWM6IHsgcm91dGVzOiBbXSB9IGFzIG5ldmVyLFxuICAgICAgICBmaWxlc01ldGFkYXRhOiBNRVRBLFxuICAgICAgfSBhcyBuZXZlcn1cbiAgICA+XG4gICAgICA8R3JvdmVTaGVsbENvbnRleHQuUHJvdmlkZXIgdmFsdWU9e3NoZWxsfT5cbiAgICAgICAgPE5hdmlnYXRpb25Qb2xpY3lDb250ZXh0LlByb3ZpZGVyIHZhbHVlPXtyZWNvcmR9PntjaGlsZHJlbn08L05hdmlnYXRpb25Qb2xpY3lDb250ZXh0LlByb3ZpZGVyPlxuICAgICAgPC9Hcm92ZVNoZWxsQ29udGV4dC5Qcm92aWRlcj5cbiAgICA8L1RpbmtlcmFibGVDb250ZXh0LlByb3ZpZGVyPlxuICApO1xufVxuXG4vKiogUmVuZGVyIG9uY2UgYW5kIHJlYWQgdGhlIGFuY2hvciBocmVmcyBvbiBzY3JlZW4gKGVhY2ggaHJlZiByZS1yZW5kZXJlZCArIGNsaWNrZWRcbiAqICBvbiBpdHMgb3duIG1vdW50IOKAlCBvdmVybGF5IGNvbXBvbmVudHMgdW5tb3VudCBhZnRlciB0aGVpciBmaXJzdCBjbGljaykuICovXG5hc3luYyBmdW5jdGlvbiByZW5kZXJBbmRDbGlja0FsbChcbiAgbmFtZTogc3RyaW5nLFxuICBidWlsZDogKCkgPT4gUmVhY3ROb2RlLFxuKTogUHJvbWlzZTx7IHBlckhyZWY6IEFycmF5PHsgaHJlZjogc3RyaW5nOyBjYWxsczogRm9sbG93TGlua1RhcmdldFtdOyBwcmV2ZW50ZWQ6IGJvb2xlYW4gfT4gfT4ge1xuICAvLyBmaXJzdCBwYXNzOiB3aGljaCBocmVmcyBkb2VzIGl0IHJlbmRlcj9cbiAgY29uc3QgcHJvYmUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChwcm9iZSk7XG4gIGNvbnN0IHByb2JlUm9vdDogUm9vdCA9IGNyZWF0ZVJvb3QocHJvYmUpO1xuICBhd2FpdCBhY3QoYXN5bmMgKCkgPT4ge1xuICAgIHByb2JlUm9vdC5yZW5kZXIoPEhhcm5lc3MgcmVjb3JkPXsoKSA9PiB7fX0gc2FuZGJveFBhdGg9e0ZJWFRVUkVTW25hbWVdPy5zYW5kYm94UGF0aH0+e2J1aWxkKCl9PC9IYXJuZXNzPik7XG4gIH0pO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IDg7IGkrKykgYXdhaXQgYWN0KGFzeW5jICgpID0+IHt9KTtcbiAgLy8gRXZlcnkgYW5jaG9yIE9DQ1VSUkVOQ0UsIG5vdCBldmVyeSBkaXN0aW5jdCBocmVmIChyb3VuZCAyIG5pdCk6IGEgc2Vjb25kXG4gIC8vIHNhbWUtaHJlZiBhbmNob3IgcmV2ZXJ0ZWQgdG8gZGlyZWN0IG5hdmlnYXRpb24gbXVzdCBmYWlsIHRvby5cbiAgY29uc3QgaHJlZnMgPSBbLi4ucHJvYmUucXVlcnlTZWxlY3RvckFsbCgnYVtocmVmXScpXS5tYXAoKGEpID0+IGEuZ2V0QXR0cmlidXRlKCdocmVmJykhKTtcbiAgZXhwZWN0KGhyZWZzLmxlbmd0aCwgYCR7bmFtZX0gcmVuZGVycyBhdCBsZWFzdCBvbmUgbGlua2ApLnRvQmVHcmVhdGVyVGhhbigwKTtcbiAgYXdhaXQgYWN0KGFzeW5jICgpID0+IHtcbiAgICBwcm9iZVJvb3QudW5tb3VudCgpO1xuICB9KTtcbiAgcHJvYmUucmVtb3ZlKCk7XG5cbiAgY29uc3QgcGVySHJlZjogQXJyYXk8eyBocmVmOiBzdHJpbmc7IGNhbGxzOiBGb2xsb3dMaW5rVGFyZ2V0W107IHByZXZlbnRlZDogYm9vbGVhbiB9PiA9IFtdO1xuICBmb3IgKGxldCBvY2N1cnJlbmNlID0gMDsgb2NjdXJyZW5jZSA8IGhyZWZzLmxlbmd0aDsgb2NjdXJyZW5jZSsrKSB7XG4gICAgY29uc3QgaHJlZiA9IGhyZWZzW29jY3VycmVuY2VdO1xuICAgIGNvbnN0IG9yZGluYWwgPSBocmVmcy5zbGljZSgwLCBvY2N1cnJlbmNlKS5maWx0ZXIoKGgpID0+IGggPT09IGhyZWYpLmxlbmd0aDtcbiAgICBjb25zdCBjYWxsczogRm9sbG93TGlua1RhcmdldFtdID0gW107XG4gICAgY29uc3QgY29udGFpbmVyID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChjb250YWluZXIpO1xuICAgIGNvbnN0IHJvb3Q6IFJvb3QgPSBjcmVhdGVSb290KGNvbnRhaW5lcik7XG4gICAgYXdhaXQgYWN0KGFzeW5jICgpID0+IHtcbiAgICAgIHJvb3QucmVuZGVyKFxuICAgICAgICA8SGFybmVzc1xuICAgICAgICAgIHJlY29yZD17KHQpID0+IHtcbiAgICAgICAgICAgIGNhbGxzLnB1c2godCk7XG4gICAgICAgICAgfX1cbiAgICAgICAgICBzYW5kYm94UGF0aD17RklYVFVSRVNbbmFtZV0/LnNhbmRib3hQYXRofVxuICAgICAgICA+XG4gICAgICAgICAge2J1aWxkKCl9XG4gICAgICAgIDwvSGFybmVzcz4sXG4gICAgICApO1xuICAgIH0pO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgODsgaSsrKSBhd2FpdCBhY3QoYXN5bmMgKCkgPT4ge30pO1xuICAgIGNvbnN0IGFuY2hvciA9IGNvbnRhaW5lci5xdWVyeVNlbGVjdG9yQWxsKGBhW2hyZWY9XCIke2hyZWYucmVwbGFjZSgvXCIvZywgJ1xcXFxcIicpfVwiXWApW29yZGluYWxdO1xuICAgIGV4cGVjdChhbmNob3IsIGAke25hbWV9OiB0aGUgJHtocmVmfSBsaW5rIHN0aWxsIHJlbmRlcnNgKS50b0JlVHJ1dGh5KCk7XG4gICAgbGV0IHByZXZlbnRlZCA9IGZhbHNlO1xuICAgIGNvbnN0IGV2ZW50ID0gbmV3IE1vdXNlRXZlbnQoJ2NsaWNrJywgeyBidWJibGVzOiB0cnVlLCBjYW5jZWxhYmxlOiB0cnVlLCBidXR0b246IDAgfSk7XG4gICAgY29uc3Qgb3JpZ1ByZXZlbnQgPSBldmVudC5wcmV2ZW50RGVmYXVsdC5iaW5kKGV2ZW50KTtcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCA9ICgpID0+IHtcbiAgICAgIHByZXZlbnRlZCA9IHRydWU7XG4gICAgICBvcmlnUHJldmVudCgpO1xuICAgIH07XG4gICAgYXdhaXQgYWN0KGFzeW5jICgpID0+IHtcbiAgICAgIGFuY2hvciEuZGlzcGF0Y2hFdmVudChldmVudCk7XG4gICAgfSk7XG4gICAgYXdhaXQgYWN0KGFzeW5jICgpID0+IHtcbiAgICAgIHJvb3QudW5tb3VudCgpO1xuICAgIH0pO1xuICAgIGNvbnRhaW5lci5yZW1vdmUoKTtcbiAgICBwZXJIcmVmLnB1c2goeyBocmVmLCBjYWxscywgcHJldmVudGVkIH0pO1xuICB9XG4gIHJldHVybiB7IHBlckhyZWYgfTtcbn1cblxuYmVmb3JlRWFjaCgoKSA9PiB7XG4gIHJlYWRGaWxlLm1vY2tSZXNldCgpO1xuICByZWFkRmlsZS5tb2NrSW1wbGVtZW50YXRpb24oYXN5bmMgKHA6IHVua25vd24pID0+XG4gICAgLy8gQmFja2xpbmtzIHNjYW5zIGJvZGllcyBmb3IgbGlua3MgVE8gdGhlIHJlbmRlcmVkIGVudHJ5OiBiJ3MgYm9keSBsaW5rcyBhLlxuICAgIFN0cmluZyhwKS5lbmRzV2l0aCgnL2IubWR4JylcbiAgICAgID8gJy0tLVxcbnRpdGxlOiBCXFxucmVuZGVyOiBzYWZlXFxuLS0tXFxuXFxuW3RoZSBmaXJzdF0oL3dpa2kvYS5tZHgpXFxuJ1xuICAgICAgOiAnLS0tXFxudGl0bGU6IFRcXG5yZW5kZXI6IHNhZmVcXG4tLS1cXG5cXG5wbGFpbiBib2R5XFxuJyxcbiAgKTtcbiAgcmVhZGRpckZzLm1vY2tSZXNldCgpO1xuICBjb25zdCBkaXJlbnQgPSAobmFtZTogc3RyaW5nLCBpc0RpciA9IGZhbHNlKSA9PiAoeyBuYW1lLCBpc0RpcmVjdG9yeTogKCkgPT4gaXNEaXIgfSk7XG4gIHJlYWRkaXJGcy5tb2NrSW1wbGVtZW50YXRpb24oYXN5bmMgKCkgPT4gW2RpcmVudCgnYy5tZHgnKSwgZGlyZW50KCdhc3NldHMnLCB0cnVlKV0pO1xuICB2b2lkIHJlYWRkaXJGcztcbn0pO1xuXG5kZXNjcmliZSgnRy1DVVNULTMg4oCUIGV2ZXJ5IGVudHJ5IGxpbmsgcmlkZXMgdGhlIG5hdmlnYXRpb24gcG9saWN5JywgKCkgPT4ge1xuICBpdCgndGhlIGVudW1lcmF0aW9uIGNvdmVycyB0aGUga25vd24gbGluayBjb21wb25lbnRzIChub24tdmFjdWl0eSknLCAoKSA9PiB7XG4gICAgZm9yIChjb25zdCBuYW1lIG9mIFsnV2lraUxpbmsnLCAnQmFja2xpbmtzJywgJ0NoaWxkUGFnZXMnLCAnRGlyZWN0b3J5JywgJ0RpcmVjdG9yeUxpc3QnLCAnRGlyZWN0b3J5VmlldycsICdEb2NMaXN0JywgJ0RyYXdlcicsICdHcm92ZUZvb3RlcicsICdHcm92ZU5hdicsICdQYWdlVmlldycsICdTZWFyY2gnLCAnU2lkZWJhcicsICdUaW1lbGluZSddKSB7XG4gICAgICBleHBlY3QobGlua0NvbXBvbmVudHMsIGAke25hbWV9IGlzIGVudW1lcmF0ZWRgKS50b0NvbnRhaW4obmFtZSk7XG4gICAgfVxuICB9KTtcblxuICBpdC5lYWNoKGxpbmtDb21wb25lbnRzKSgnJXM6IGEgcGxhaW4gY2xpY2sgcmVhY2hlcyB0aGUgcG9saWN5IHdpdGggYSByZXNvbHZlZCB0YXJnZXQnLCBhc3luYyAobmFtZSkgPT4ge1xuICAgIGNvbnN0IG1vZCA9IGF3YWl0IGltcG9ydChgLi8ke25hbWV9YCk7XG4gICAgY29uc3QgQ29tcG9uZW50ID0gbW9kLmRlZmF1bHQ7XG4gICAgY29uc3QgcHJvcHMgPSBGSVhUVVJFU1tuYW1lXT8ucHJvcHMgPz8ge307XG4gICAgLy8gRVZFUlkgYW5jaG9yIHRoZSBjb21wb25lbnQgcmVuZGVycywgZWFjaCBjbGlja2VkIG9uIGl0cyBvd24gbW91bnQgKGFuXG4gICAgLy8gb3ZlcmxheSdzIGZpcnN0IGNsaWNrIGNsb3NlcyBpdCkg4oCUIHRoZSBpdGVtJ3MgZG8tbm90IGNhcnZlLW91dCBpcyBhIHNlY29uZFxuICAgIC8vIGxpbmsgbmF2aWdhdGluZyBkaXJlY3RseSAnYmVjYXVzZSBpdCdzIGNocm9tZScsIGFuZCBvbmx5IHByb2JpbmcgdGhlIGZpcnN0XG4gICAgLy8gYW5jaG9yIHdvdWxkIG1pc3MgZXhhY3RseSB0aGF0LlxuICAgIGNvbnN0IHsgcGVySHJlZiB9ID0gYXdhaXQgcmVuZGVyQW5kQ2xpY2tBbGwobmFtZSwgKCkgPT4gPENvbXBvbmVudCB7Li4ucHJvcHN9IC8+KTtcbiAgICBmb3IgKGNvbnN0IHsgaHJlZiwgY2FsbHMsIHByZXZlbnRlZCB9IG9mIHBlckhyZWYpIHtcbiAgICAgIGV4cGVjdChjYWxscy5sZW5ndGgsIGAke25hbWV9OiB0aGUgcGxhaW4gY2xpY2sgb24gJHtocmVmfSByZWFjaGVzIHRoZSBwb2xpY3lgKS50b0JlR3JlYXRlclRoYW4oMCk7XG4gICAgICBjb25zdCB0ID0gY2FsbHNbMF07XG4gICAgICBleHBlY3QodHlwZW9mIHQuaHJlZiwgJ3RoZSB0YXJnZXQgY2FycmllcyB0aGUgY29uY3JldGUgaHJlZicpLnRvQmUoJ3N0cmluZycpO1xuICAgICAgZXhwZWN0KHQuaHJlZi5sZW5ndGgpLnRvQmVHcmVhdGVyVGhhbigwKTtcbiAgICAgIC8vIHRoZSBET00gYW5jaG9yIGNhcnJpZXMgdGhlIFNESydzIG91dGVyLVVSTCByZXNvbHV0aW9uIG9mIHRoZSBocmVmIHRoZVxuICAgICAgLy8gY29tcG9uZW50IHBhc3NlZDsgdGhlIHBvbGljeSByZWNlaXZlcyB0aGUgY29tcG9uZW50LWxldmVsIG9uZVxuICAgICAgZXhwZWN0KGhyZWYgPT09IHQuaHJlZiB8fCBocmVmLmVuZHNXaXRoKHQuaHJlZiksIGAke25hbWV9OiB0aGUgRE9NIGhyZWYgJHtocmVmfSByZXNvbHZlcyB0aGUgcG9saWN5J3MgJHt0LmhyZWZ9YCkudG9CZSh0cnVlKTtcbiAgICAgIGV4cGVjdCh0eXBlb2YgdC5rZXksICd0aGUgdGFyZ2V0IGNhcnJpZXMgdGhlIHJlc29sdmVkIGtleScpLnRvQmUoJ3N0cmluZycpO1xuICAgICAgZXhwZWN0KHQua2V5Lmxlbmd0aCkudG9CZUdyZWF0ZXJUaGFuKDApO1xuICAgICAgLy8gwqc0LjMncyBzaGFwZTogZnJhZ21lbnQgaXMgYWJzZW50IG9yIGEgYmFyZSBpZCwgbmV2ZXIgJyMnLXByZWZpeGVkXG4gICAgICBpZiAodC5mcmFnbWVudCAhPT0gdW5kZWZpbmVkKSBleHBlY3QodC5mcmFnbWVudC5zdGFydHNXaXRoKCcjJyksIGBmcmFnbWVudCBjYXJyaWVzIG5vICcjJyAoJHt0LmZyYWdtZW50fSlgKS50b0JlKGZhbHNlKTtcbiAgICAgIC8vIGBmcm9tYCBpcyB0aGUgZW50cnkga2V5IHdoZW4gdGhlIGxpbmsgcmVuZGVycyBpbnNpZGUgb25lIChjb250ZW50XG4gICAgICAvLyBjb21wb25lbnRzKSwgYWJzZW50IGZvciB0aGUgY2hyb21lIChuYXYvZm9vdGVyL2RyYXdlci9zaWRlYmFyIHJlbmRlclxuICAgICAgLy8gb3V0c2lkZSBhbiBlbnRyeSkg4oCUIHRoZSBzaGFwZSBwaW5uZWQsIG5vdCB0aGUgdmFsdWUgZ3Vlc3NlZC5cbiAgICAgIGlmICh0LmZyb20gIT09IHVuZGVmaW5lZCkgZXhwZWN0KHR5cGVvZiB0LmZyb20pLnRvQmUoJ3N0cmluZycpO1xuICAgICAgLy8gdGhlIFdpa2lMaW5rIGZpeHR1cmUgaXMgZnJhZ21lbnQtYmVhcmluZzogdGhlIHJlbmRlcmVkIGhyZWYgS0VFUFMgdGhlXG4gICAgICAvLyAnI3NlYy00JyAocm91bmQgMidzIHJlZ3Jlc3Npb24g4oCUIHRoZSAnIycgc3RyaXAgY29ycnVwdGVkIGhyZWZzKSwgYW5kIHRoZVxuICAgICAgLy8gcG9saWN5J3MgZnJhZ21lbnQgaXMgdGhlIGJhcmUgaWRcbiAgICAgIGlmIChuYW1lID09PSAnV2lraUxpbmsnKSB7XG4gICAgICAgIGV4cGVjdChocmVmKS50b0NvbnRhaW4oJyNzZWMtNCcpO1xuICAgICAgICBleHBlY3QodC5mcmFnbWVudCkudG9CZSgnc2VjLTQnKTtcbiAgICAgIH1cbiAgICAgIGV4cGVjdChwcmV2ZW50ZWQsIGAke25hbWV9OiB0aGUgcGxhaW4gY2xpY2sgb24gJHtocmVmfSBwcmV2ZW50cyB0aGUgYnJvd3NlciBkZWZhdWx0YCkudG9CZSh0cnVlKTtcbiAgICB9XG4gIH0pO1xufSk7XG4iXSwibWFwcGluZ3MiOiI7Ozs7O0FBT0EsSUFBQUEsT0FBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsTUFBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsT0FBQSxHQUFBRixPQUFBO0FBS0EsSUFBQUcsV0FBQSxHQUFBSCxPQUFBO0FBQ0EsSUFBQUksU0FBQSxHQUFBSixPQUFBO0FBRUEsSUFBQUssa0JBQUEsR0FBQUwsT0FBQTtBQUNBLElBQUFNLE1BQUEsR0FBQU4sT0FBQTtBQUNBLElBQUFPLGlCQUFBLEdBQUFQLE9BQUE7QUFDQSxJQUFBUSxRQUFBLEdBQUFSLE9BQUE7QUFDQSxJQUFBUyxZQUFBLEdBQUFULE9BQUE7QUFBb0QsSUFBQVUsV0FBQSxHQUFBVixPQUFBO0FBQUEsU0FBQVcseUJBQUFDLENBQUEsNkJBQUFDLE9BQUEsbUJBQUFDLENBQUEsT0FBQUQsT0FBQSxJQUFBRSxDQUFBLE9BQUFGLE9BQUEsWUFBQUYsd0JBQUEsWUFBQUEsQ0FBQUMsQ0FBQSxXQUFBQSxDQUFBLEdBQUFHLENBQUEsR0FBQUQsQ0FBQSxLQUFBRixDQUFBO0FBQUEsU0FBQUksd0JBQUFKLENBQUEsRUFBQUUsQ0FBQSxTQUFBQSxDQUFBLElBQUFGLENBQUEsSUFBQUEsQ0FBQSxDQUFBSyxVQUFBLFNBQUFMLENBQUEsZUFBQUEsQ0FBQSx1QkFBQUEsQ0FBQSx5QkFBQUEsQ0FBQSxXQUFBTSxPQUFBLEVBQUFOLENBQUEsUUFBQUcsQ0FBQSxHQUFBSix3QkFBQSxDQUFBRyxDQUFBLE9BQUFDLENBQUEsSUFBQUEsQ0FBQSxDQUFBSSxHQUFBLENBQUFQLENBQUEsVUFBQUcsQ0FBQSxDQUFBSyxHQUFBLENBQUFSLENBQUEsT0FBQVMsQ0FBQSxLQUFBQyxTQUFBLFVBQUFDLENBQUEsR0FBQUMsTUFBQSxDQUFBQyxjQUFBLElBQUFELE1BQUEsQ0FBQUUsd0JBQUEsV0FBQUMsQ0FBQSxJQUFBZixDQUFBLG9CQUFBZSxDQUFBLE9BQUFDLGNBQUEsQ0FBQUMsSUFBQSxDQUFBakIsQ0FBQSxFQUFBZSxDQUFBLFNBQUFHLENBQUEsR0FBQVAsQ0FBQSxHQUFBQyxNQUFBLENBQUFFLHdCQUFBLENBQUFkLENBQUEsRUFBQWUsQ0FBQSxVQUFBRyxDQUFBLEtBQUFBLENBQUEsQ0FBQVYsR0FBQSxJQUFBVSxDQUFBLENBQUFDLEdBQUEsSUFBQVAsTUFBQSxDQUFBQyxjQUFBLENBQUFKLENBQUEsRUFBQU0sQ0FBQSxFQUFBRyxDQUFBLElBQUFULENBQUEsQ0FBQU0sQ0FBQSxJQUFBZixDQUFBLENBQUFlLENBQUEsWUFBQU4sQ0FBQSxDQUFBSCxPQUFBLEdBQUFOLENBQUEsRUFBQUcsQ0FBQSxJQUFBQSxDQUFBLENBQUFnQixHQUFBLENBQUFuQixDQUFBLEVBQUFTLENBQUEsR0FBQUEsQ0FBQSxJQXJCcEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFLQTtBQUNBO0FBQ0E7QUFHQSxNQUFNO0VBQUVXLFlBQVk7RUFBRUM7QUFBWSxDQUFDLEdBQUcsSUFBQUMseUJBQWEsRUFBQ0MsZUFBQSxDQUFZQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQTZCO0FBTzNHLElBQUFDLGlCQUFTLEVBQUMsTUFBTTtFQUNkYixNQUFNLENBQUNDLGNBQWMsQ0FBQ2EsTUFBTSxFQUFFLFlBQVksRUFBRTtJQUMxQ0MsUUFBUSxFQUFFLElBQUk7SUFDZEMsS0FBSyxFQUFHQyxDQUFTLEtBQU07TUFBRUMsT0FBTyxFQUFFLEtBQUs7TUFBRUMsS0FBSyxFQUFFRixDQUFDO01BQUVHLGdCQUFnQixFQUFFQSxDQUFBLEtBQU0sQ0FBQyxDQUFDO01BQUVDLG1CQUFtQixFQUFFQSxDQUFBLEtBQU0sQ0FBQyxDQUFDO01BQUVDLFdBQVcsRUFBRUEsQ0FBQSxLQUFNLENBQUMsQ0FBQztNQUFFQyxjQUFjLEVBQUVBLENBQUEsS0FBTSxDQUFDLENBQUM7TUFBRUMsYUFBYSxFQUFFQSxDQUFBLEtBQU0sS0FBSztNQUFFQyxRQUFRLEVBQUU7SUFBSyxDQUFDO0VBQzdNLENBQUMsQ0FBQztFQUNGLElBQUFDLDJCQUFjLEVBQUMsZUFBZSxDQUFDO0FBQ2pDLENBQUMsQ0FBQzs7QUFFRjtBQUNBLE1BQU1DLEtBQUssR0FBRyx5QkFBeUI7QUFDdkMsTUFBTUMsS0FBSyxHQUFHLHlCQUF5QjtBQUN2QyxNQUFNQyxNQUFNLEdBQUcsNkJBQTZCO0FBQzVDLE1BQU1DLEtBQUssR0FBRyw2QkFBNkI7QUFDM0MsTUFBTUMsTUFBTSxHQUFHLHlCQUF5QjtBQUN4QyxNQUFNQyxJQUE2QyxHQUFHO0VBQ3BELENBQUNMLEtBQUssR0FBRztJQUFFTSxLQUFLLEVBQUUsa0JBQWtCO0lBQUVDLE1BQU0sRUFBRSxNQUFNO0lBQUVDLElBQUksRUFBRTtFQUFhLENBQUM7RUFDMUUsQ0FBQ0wsS0FBSyxHQUFHO0lBQUVHLEtBQUssRUFBRSxpQkFBaUI7SUFBRUMsTUFBTSxFQUFFO0VBQU8sQ0FBQztFQUNyRCxDQUFDSCxNQUFNLEdBQUc7SUFBRUUsS0FBSyxFQUFFLGdCQUFnQjtJQUFFQyxNQUFNLEVBQUU7RUFBTyxDQUFDO0VBQ3JELENBQUNOLEtBQUssR0FBRztJQUFFSyxLQUFLLEVBQUUsa0JBQWtCO0lBQUVDLE1BQU0sRUFBRSxNQUFNO0lBQUVDLElBQUksRUFBRTtFQUFhLENBQUM7RUFDMUUsQ0FBQ04sTUFBTSxHQUFHO0lBQUVPLElBQUksRUFBRSxLQUFLO0lBQUVDLElBQUksRUFBRSxLQUFLO0lBQUVDLElBQUksRUFBRSxNQUFNO0lBQUVDLEtBQUssRUFBRSxPQUFPO0lBQUVDLEtBQUssRUFBRTtFQUFRLENBQUM7RUFDcEYsdUJBQXVCLEVBQUU7SUFBRVAsS0FBSyxFQUFFLE1BQU07SUFBRUMsTUFBTSxFQUFFO0VBQU87QUFDM0QsQ0FBQztBQUVELE1BQU07RUFBRU8sUUFBUTtFQUFFQztBQUFVLENBQUMsR0FBR0MsVUFBRSxDQUFDQyxPQUFPLENBQUMsT0FBTztFQUFFSCxRQUFRLEVBQUVFLFVBQUUsQ0FBQ0UsRUFBRSxDQUFDLENBQUM7RUFBRUgsU0FBUyxFQUFFQyxVQUFFLENBQUNFLEVBQUUsQ0FBQztBQUFFLENBQUMsQ0FBQyxDQUFDO0FBQzdGRixVQUFFLENBQUNHLElBQUksQ0FBQyxJQUFJLEVBQUUsTUFBT0MsY0FBYyxJQUFLO0VBQ3RDLE1BQU1DLE1BQU0sR0FBSSxNQUFNRCxjQUFjLENBQUMsQ0FBNkI7RUFDbEUsT0FBTztJQUNMLEdBQUdDLE1BQU07SUFDVHRELE9BQU8sRUFBRTtNQUNQLEdBQUlzRCxNQUFNLENBQUN0RCxPQUFtQztNQUM5Q3VELFFBQVEsRUFBRTtRQUNSLEdBQUtELE1BQU0sQ0FBQ3RELE9BQU8sQ0FBMkN1RCxRQUFTO1FBQ3ZFUixRQUFRLEVBQUVBLENBQUMsR0FBRzFDLENBQVksS0FBSzBDLFFBQVEsQ0FBQyxHQUFJMUMsQ0FBUSxDQUFDO1FBQ3JEbUQsT0FBTyxFQUFFQSxDQUFDLEdBQUduRCxDQUFZLEtBQUsyQyxTQUFTLENBQUMsR0FBSTNDLENBQVE7TUFDdEQ7SUFDRjtFQUNGLENBQUM7QUFDSCxDQUFDLENBQUM7QUFDRG9ELFVBQVUsQ0FBc0NDLGtCQUFrQixHQUFHO0VBQ3BFSCxRQUFRLEVBQUU7SUFBRVIsUUFBUSxFQUFFQSxDQUFDLEdBQUcxQyxDQUFZLEtBQUswQyxRQUFRLENBQUMsR0FBSTFDLENBQVE7RUFBRTtBQUNwRSxDQUFDO0FBRUQsTUFBTXNELEdBQUcsR0FBRztFQUNWQyxJQUFJLEVBQUUsUUFBUTtFQUNkQyxTQUFTLEVBQUUsaUJBQWlCO0VBQzVCQyxRQUFRLEVBQUUsUUFBUTtFQUNsQkMsVUFBVSxFQUFFLFFBQVE7RUFDcEJDLEdBQUcsRUFBRSxNQUFNO0VBQ1hDLFdBQVcsRUFBRWhDLEtBQUs7RUFDbEJpQyxJQUFJLEVBQUUsRUFBRTtFQUNSQyxNQUFNLEVBQUU7QUFDVixDQUFDOztBQUVEO0FBQ0E7QUFDQSxNQUFNQyxLQUFpQixHQUFHO0VBQ3hCQyxTQUFTLEVBQUUsU0FBUztFQUNwQkMsUUFBUSxFQUFFLENBQUM7SUFBRUMsR0FBRyxFQUFFckMsS0FBSztJQUFFc0MsSUFBSSxFQUFFLElBQUFDLGtCQUFTLEVBQUN2QyxLQUFLLENBQUM7SUFBRXdDLEtBQUssRUFBRTtFQUFtQixDQUFDLENBQUM7RUFDN0VDLFFBQVEsRUFBRTFDLEtBQUs7RUFDZjJDLEVBQUUsRUFBRSxTQUFTO0VBQ2JDLE9BQU8sRUFBRSxLQUFLO0VBQ2R4RCxRQUFRLEVBQUUsS0FBSztFQUNmeUQsVUFBVSxFQUFFQSxDQUFBLEtBQU0sQ0FBQyxDQUFDO0VBQ3BCQyxRQUFRLEVBQUUsS0FBSztFQUNmQyxXQUFXLEVBQUUsS0FBSztFQUNsQkMsUUFBUSxFQUFFLEVBQUU7RUFDWkMsU0FBUyxFQUFFO0lBQUVDLE1BQU0sRUFBRTtFQUFPLENBQUM7RUFDN0JDLE9BQU8sRUFBRSxJQUFJO0VBQ2JDLFVBQVUsRUFBRW5ELEtBQUs7RUFDakJvRCxJQUFJLEVBQUUsQ0FBQztFQUNQQyxJQUFJLEVBQUUsSUFBSTtFQUNWQyxXQUFXLEVBQUV2RCxLQUFLO0VBQ2xCd0QsTUFBTSxFQUFFLEtBQUs7RUFDYkMsU0FBUyxFQUFFO0FBQ2IsQ0FBMEI7O0FBRTFCO0FBQ0EsTUFBTUMsY0FBYyxHQUFHLElBQUFDLGNBQUksRUFBQ0MsU0FBUyxDQUFDO0FBQ3RDLE1BQU1DLGNBQWMsR0FBRy9FLFdBQVcsQ0FBQzRFLGNBQWMsQ0FBQyxDQUMvQ0ksTUFBTSxDQUFFQyxDQUFDLElBQUtBLENBQUMsQ0FBQ0MsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUNELENBQUMsQ0FBQ0UsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQzFESCxNQUFNLENBQUVDLENBQUMsSUFBSyxvQkFBb0IsQ0FBQ0csSUFBSSxDQUFDckYsWUFBWSxDQUFDLElBQUE4RSxjQUFJLEVBQUNELGNBQWMsRUFBRUssQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUN2RkksR0FBRyxDQUFFSixDQUFDLElBQUtBLENBQUMsQ0FBQ0ssT0FBTyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FBQzs7QUFFdEM7QUFDQTtBQUNBLE1BQU1DLFFBQW1GLEdBQUc7RUFDMUZDLFFBQVEsRUFBRTtJQUFFQyxLQUFLLEVBQUU7TUFBRWhDLElBQUksRUFBRSxtQkFBbUI7TUFBRWlDLFFBQVEsRUFBRTtJQUFZO0VBQUUsQ0FBQztFQUN6RUMsTUFBTSxFQUFFO0lBQUVGLEtBQUssRUFBRTtNQUFFRyxPQUFPLEVBQUVBLENBQUEsS0FBTSxDQUFDO0lBQUU7RUFBRSxDQUFDO0VBQ3hDQyxNQUFNLEVBQUU7SUFBRUosS0FBSyxFQUFFO01BQUVuQyxTQUFTLEVBQUUsU0FBUztNQUFFd0MsR0FBRyxFQUFFLENBQUM7UUFBRXRDLEdBQUcsRUFBRXJDLEtBQUs7UUFBRXNDLElBQUksRUFBRSxJQUFBQyxrQkFBUyxFQUFDdkMsS0FBSyxDQUFDO1FBQUV3QyxLQUFLLEVBQUUsT0FBTztRQUFFb0MsR0FBRyxFQUFFO01BQU0sQ0FBQyxDQUFDO01BQUVILE9BQU8sRUFBRUEsQ0FBQSxLQUFNLENBQUM7SUFBRTtFQUFFLENBQUM7RUFDekk7RUFDQTtFQUNBSSxVQUFVLEVBQUU7SUFBRTlDLFdBQVcsRUFBRTtFQUE4QixDQUFDO0VBQzFEO0VBQ0E7RUFDQStDLGFBQWEsRUFBRTtJQUFFL0MsV0FBVyxFQUFFO0VBQThCO0FBQzlELENBQUM7O0FBRUQ7O0FBRUEsU0FBU2dELE9BQU9BLENBQUM7RUFBRVIsUUFBUTtFQUFFUyxNQUFNO0VBQUVqRDtBQUFrRyxDQUFDLEVBQUU7RUFDeEksb0JBQ0UsSUFBQXpFLFdBQUEsQ0FBQTJILEdBQUEsRUFBQ2hJLGtCQUFBLENBQUFpSSxpQkFBaUIsQ0FBQ0MsUUFBUTtJQUN6Qi9GLEtBQUssRUFBRTtNQUNMZ0csU0FBUyxFQUFFLDJCQUEyQjtNQUN0Q0MsZUFBZSxFQUFFO1FBQUUsR0FBRzVELEdBQUc7UUFBRU0sV0FBVyxFQUFFQSxXQUFXLElBQUlOLEdBQUcsQ0FBQ007TUFBWSxDQUFDO01BQ3hFdUQsV0FBVyxFQUFFO1FBQUVDLE1BQU0sRUFBRTtNQUFHLENBQVU7TUFDcENDLGFBQWEsRUFBRXBGO0lBQ2pCLENBQVc7SUFBQW1FLFFBQUEsZUFFWCxJQUFBakgsV0FBQSxDQUFBMkgsR0FBQSxFQUFDL0gsTUFBQSxDQUFBdUksaUJBQWlCLENBQUNOLFFBQVE7TUFBQy9GLEtBQUssRUFBRThDLEtBQU07TUFBQXFDLFFBQUEsZUFDdkMsSUFBQWpILFdBQUEsQ0FBQTJILEdBQUEsRUFBQzlILGlCQUFBLENBQUF1SSx1QkFBdUIsQ0FBQ1AsUUFBUTtRQUFDL0YsS0FBSyxFQUFFNEYsTUFBTztRQUFBVCxRQUFBLEVBQUVBO01BQVEsQ0FBbUM7SUFBQyxDQUNwRTtFQUFDLENBQ0gsQ0FBQztBQUVqQzs7QUFFQTtBQUNBO0FBREFvQixFQUFBLEdBakJTWixPQUFPO0FBbUJoQixlQUFlYSxpQkFBaUJBLENBQzlCcEYsSUFBWSxFQUNacUYsS0FBc0IsRUFDd0U7RUFDOUY7RUFDQSxNQUFNQyxLQUFLLEdBQUdDLFFBQVEsQ0FBQ0MsYUFBYSxDQUFDLEtBQUssQ0FBQztFQUMzQ0QsUUFBUSxDQUFDRSxJQUFJLENBQUNDLFdBQVcsQ0FBQ0osS0FBSyxDQUFDO0VBQ2hDLE1BQU1LLFNBQWUsR0FBRyxJQUFBQyxrQkFBVSxFQUFDTixLQUFLLENBQUM7RUFDekMsTUFBTSxJQUFBTyxVQUFHLEVBQUMsWUFBWTtJQUNwQkYsU0FBUyxDQUFDN0YsTUFBTSxjQUFDLElBQUFoRCxXQUFBLENBQUEySCxHQUFBLEVBQUNGLE9BQU87TUFBQ0MsTUFBTSxFQUFFQSxDQUFBLEtBQU0sQ0FBQyxDQUFFO01BQUNqRCxXQUFXLEVBQUVxQyxRQUFRLENBQUM1RCxJQUFJLENBQUMsRUFBRXVCLFdBQVk7TUFBQXdDLFFBQUEsRUFBRXNCLEtBQUssQ0FBQztJQUFDLENBQVUsQ0FBQyxDQUFDO0VBQzVHLENBQUMsQ0FBQztFQUNGLEtBQUssSUFBSW5ILENBQUMsR0FBRyxDQUFDLEVBQUVBLENBQUMsR0FBRyxDQUFDLEVBQUVBLENBQUMsRUFBRSxFQUFFLE1BQU0sSUFBQTJILFVBQUcsRUFBQyxZQUFZLENBQUMsQ0FBQyxDQUFDO0VBQ3JEO0VBQ0E7RUFDQSxNQUFNQyxLQUFLLEdBQUcsQ0FBQyxHQUFHUixLQUFLLENBQUNTLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUNyQyxHQUFHLENBQUUvRixDQUFDLElBQUtBLENBQUMsQ0FBQ3FJLFlBQVksQ0FBQyxNQUFNLENBQUUsQ0FBQztFQUN4RixJQUFBQyxjQUFNLEVBQUNILEtBQUssQ0FBQ0ksTUFBTSxFQUFFLEdBQUdsRyxJQUFJLDRCQUE0QixDQUFDLENBQUNtRyxlQUFlLENBQUMsQ0FBQyxDQUFDO0VBQzVFLE1BQU0sSUFBQU4sVUFBRyxFQUFDLFlBQVk7SUFDcEJGLFNBQVMsQ0FBQ1MsT0FBTyxDQUFDLENBQUM7RUFDckIsQ0FBQyxDQUFDO0VBQ0ZkLEtBQUssQ0FBQ2UsTUFBTSxDQUFDLENBQUM7RUFFZCxNQUFNQyxPQUErRSxHQUFHLEVBQUU7RUFDMUYsS0FBSyxJQUFJQyxVQUFVLEdBQUcsQ0FBQyxFQUFFQSxVQUFVLEdBQUdULEtBQUssQ0FBQ0ksTUFBTSxFQUFFSyxVQUFVLEVBQUUsRUFBRTtJQUNoRSxNQUFNekUsSUFBSSxHQUFHZ0UsS0FBSyxDQUFDUyxVQUFVLENBQUM7SUFDOUIsTUFBTUMsT0FBTyxHQUFHVixLQUFLLENBQUNXLEtBQUssQ0FBQyxDQUFDLEVBQUVGLFVBQVUsQ0FBQyxDQUFDbEQsTUFBTSxDQUFFcUQsQ0FBQyxJQUFLQSxDQUFDLEtBQUs1RSxJQUFJLENBQUMsQ0FBQ29FLE1BQU07SUFDM0UsTUFBTVMsS0FBeUIsR0FBRyxFQUFFO0lBQ3BDLE1BQU1DLFNBQVMsR0FBR3JCLFFBQVEsQ0FBQ0MsYUFBYSxDQUFDLEtBQUssQ0FBQztJQUMvQ0QsUUFBUSxDQUFDRSxJQUFJLENBQUNDLFdBQVcsQ0FBQ2tCLFNBQVMsQ0FBQztJQUNwQyxNQUFNQyxJQUFVLEdBQUcsSUFBQWpCLGtCQUFVLEVBQUNnQixTQUFTLENBQUM7SUFDeEMsTUFBTSxJQUFBZixVQUFHLEVBQUMsWUFBWTtNQUNwQmdCLElBQUksQ0FBQy9HLE1BQU0sY0FDVCxJQUFBaEQsV0FBQSxDQUFBMkgsR0FBQSxFQUFDRixPQUFPO1FBQ05DLE1BQU0sRUFBR3JILENBQUMsSUFBSztVQUNid0osS0FBSyxDQUFDRyxJQUFJLENBQUMzSixDQUFDLENBQUM7UUFDZixDQUFFO1FBQ0ZvRSxXQUFXLEVBQUVxQyxRQUFRLENBQUM1RCxJQUFJLENBQUMsRUFBRXVCLFdBQVk7UUFBQXdDLFFBQUEsRUFFeENzQixLQUFLLENBQUM7TUFBQyxDQUNELENBQ1gsQ0FBQztJQUNILENBQUMsQ0FBQztJQUNGLEtBQUssSUFBSW5ILENBQUMsR0FBRyxDQUFDLEVBQUVBLENBQUMsR0FBRyxDQUFDLEVBQUVBLENBQUMsRUFBRSxFQUFFLE1BQU0sSUFBQTJILFVBQUcsRUFBQyxZQUFZLENBQUMsQ0FBQyxDQUFDO0lBQ3JELE1BQU1rQixNQUFNLEdBQUdILFNBQVMsQ0FBQ2IsZ0JBQWdCLENBQUMsV0FBV2pFLElBQUksQ0FBQzZCLE9BQU8sQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDNkMsT0FBTyxDQUFDO0lBQzVGLElBQUFQLGNBQU0sRUFBQ2MsTUFBTSxFQUFFLEdBQUcvRyxJQUFJLFNBQVM4QixJQUFJLHFCQUFxQixDQUFDLENBQUNrRixVQUFVLENBQUMsQ0FBQztJQUN0RSxJQUFJQyxTQUFTLEdBQUcsS0FBSztJQUNyQixNQUFNQyxLQUFLLEdBQUcsSUFBSUMsVUFBVSxDQUFDLE9BQU8sRUFBRTtNQUFFQyxPQUFPLEVBQUUsSUFBSTtNQUFFQyxVQUFVLEVBQUUsSUFBSTtNQUFFQyxNQUFNLEVBQUU7SUFBRSxDQUFDLENBQUM7SUFDckYsTUFBTUMsV0FBVyxHQUFHTCxLQUFLLENBQUNNLGNBQWMsQ0FBQ0MsSUFBSSxDQUFDUCxLQUFLLENBQUM7SUFDcERBLEtBQUssQ0FBQ00sY0FBYyxHQUFHLE1BQU07TUFDM0JQLFNBQVMsR0FBRyxJQUFJO01BQ2hCTSxXQUFXLENBQUMsQ0FBQztJQUNmLENBQUM7SUFDRCxNQUFNLElBQUExQixVQUFHLEVBQUMsWUFBWTtNQUNwQmtCLE1BQU0sQ0FBRTNILGFBQWEsQ0FBQzhILEtBQUssQ0FBQztJQUM5QixDQUFDLENBQUM7SUFDRixNQUFNLElBQUFyQixVQUFHLEVBQUMsWUFBWTtNQUNwQmdCLElBQUksQ0FBQ1QsT0FBTyxDQUFDLENBQUM7SUFDaEIsQ0FBQyxDQUFDO0lBQ0ZRLFNBQVMsQ0FBQ1AsTUFBTSxDQUFDLENBQUM7SUFDbEJDLE9BQU8sQ0FBQ1EsSUFBSSxDQUFDO01BQUVoRixJQUFJO01BQUU2RSxLQUFLO01BQUVNO0lBQVUsQ0FBQyxDQUFDO0VBQzFDO0VBQ0EsT0FBTztJQUFFWDtFQUFRLENBQUM7QUFDcEI7QUFFQSxJQUFBb0Isa0JBQVUsRUFBQyxNQUFNO0VBQ2ZySCxRQUFRLENBQUNzSCxTQUFTLENBQUMsQ0FBQztFQUNwQnRILFFBQVEsQ0FBQ3VILGtCQUFrQixDQUFDLE1BQU9DLENBQVU7RUFDM0M7RUFDQUMsTUFBTSxDQUFDRCxDQUFDLENBQUMsQ0FBQ3RFLFFBQVEsQ0FBQyxRQUFRLENBQUMsR0FDeEIsZ0VBQWdFLEdBQ2hFLGtEQUNOLENBQUM7RUFDRGpELFNBQVMsQ0FBQ3FILFNBQVMsQ0FBQyxDQUFDO0VBQ3JCLE1BQU1JLE1BQU0sR0FBR0EsQ0FBQy9ILElBQVksRUFBRWdJLEtBQUssR0FBRyxLQUFLLE1BQU07SUFBRWhJLElBQUk7SUFBRWlJLFdBQVcsRUFBRUEsQ0FBQSxLQUFNRDtFQUFNLENBQUMsQ0FBQztFQUNwRjFILFNBQVMsQ0FBQ3NILGtCQUFrQixDQUFDLFlBQVksQ0FBQ0csTUFBTSxDQUFDLE9BQU8sQ0FBQyxFQUFFQSxNQUFNLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUM7RUFDbkYsS0FBS3pILFNBQVM7QUFDaEIsQ0FBQyxDQUFDO0FBRUYsSUFBQTRILGdCQUFRLEVBQUMseURBQXlELEVBQUUsTUFBTTtFQUN4RSxJQUFBQyxVQUFFLEVBQUMsZ0VBQWdFLEVBQUUsTUFBTTtJQUN6RSxLQUFLLE1BQU1uSSxJQUFJLElBQUksQ0FBQyxVQUFVLEVBQUUsV0FBVyxFQUFFLFlBQVksRUFBRSxXQUFXLEVBQUUsZUFBZSxFQUFFLGVBQWUsRUFBRSxTQUFTLEVBQUUsUUFBUSxFQUFFLGFBQWEsRUFBRSxVQUFVLEVBQUUsVUFBVSxFQUFFLFFBQVEsRUFBRSxTQUFTLEVBQUUsVUFBVSxDQUFDLEVBQUU7TUFDdE0sSUFBQWlHLGNBQU0sRUFBQzdDLGNBQWMsRUFBRSxHQUFHcEQsSUFBSSxnQkFBZ0IsQ0FBQyxDQUFDb0ksU0FBUyxDQUFDcEksSUFBSSxDQUFDO0lBQ2pFO0VBQ0YsQ0FBQyxDQUFDO0VBRUZtSSxVQUFFLENBQUNFLElBQUksQ0FBQ2pGLGNBQWMsQ0FBQyxDQUFDLDZEQUE2RCxFQUFFLE1BQU9wRCxJQUFJLElBQUs7SUFDckcsTUFBTXNJLEdBQUcsR0FBRyxPQUFBQyxTQUFBLFFBQUFDLE9BQUEsQ0FBQXRMLENBQUEsSUFBQUEsQ0FBQSxDQUFBcUwsU0FBQSxHQUFBRSxJQUFBLENBQUFDLENBQUEsSUFBQXRMLHVCQUFBLENBQUFoQixPQUFBLENBQUFzTSxDQUFBLEtBQWEsS0FBSzFJLElBQUksRUFBRSxDQUFDO0lBQ3JDLE1BQU0ySSxTQUFTLEdBQUdMLEdBQUcsQ0FBQ2hMLE9BQU87SUFDN0IsTUFBTXdHLEtBQUssR0FBR0YsUUFBUSxDQUFDNUQsSUFBSSxDQUFDLEVBQUU4RCxLQUFLLElBQUksQ0FBQyxDQUFDO0lBQ3pDO0lBQ0E7SUFDQTtJQUNBO0lBQ0EsTUFBTTtNQUFFd0M7SUFBUSxDQUFDLEdBQUcsTUFBTWxCLGlCQUFpQixDQUFDcEYsSUFBSSxFQUFFLG1CQUFNLElBQUFsRCxXQUFBLENBQUEySCxHQUFBLEVBQUNrRSxTQUFTO01BQUEsR0FBSzdFO0lBQUssQ0FBRyxDQUFDLENBQUM7SUFDakYsS0FBSyxNQUFNO01BQUVoQyxJQUFJO01BQUU2RSxLQUFLO01BQUVNO0lBQVUsQ0FBQyxJQUFJWCxPQUFPLEVBQUU7TUFDaEQsSUFBQUwsY0FBTSxFQUFDVSxLQUFLLENBQUNULE1BQU0sRUFBRSxHQUFHbEcsSUFBSSx3QkFBd0I4QixJQUFJLHFCQUFxQixDQUFDLENBQUNxRSxlQUFlLENBQUMsQ0FBQyxDQUFDO01BQ2pHLE1BQU1oSixDQUFDLEdBQUd3SixLQUFLLENBQUMsQ0FBQyxDQUFDO01BQ2xCLElBQUFWLGNBQU0sRUFBQyxPQUFPOUksQ0FBQyxDQUFDMkUsSUFBSSxFQUFFLHNDQUFzQyxDQUFDLENBQUM4RyxJQUFJLENBQUMsUUFBUSxDQUFDO01BQzVFLElBQUEzQyxjQUFNLEVBQUM5SSxDQUFDLENBQUMyRSxJQUFJLENBQUNvRSxNQUFNLENBQUMsQ0FBQ0MsZUFBZSxDQUFDLENBQUMsQ0FBQztNQUN4QztNQUNBO01BQ0EsSUFBQUYsY0FBTSxFQUFDbkUsSUFBSSxLQUFLM0UsQ0FBQyxDQUFDMkUsSUFBSSxJQUFJQSxJQUFJLENBQUN5QixRQUFRLENBQUNwRyxDQUFDLENBQUMyRSxJQUFJLENBQUMsRUFBRSxHQUFHOUIsSUFBSSxrQkFBa0I4QixJQUFJLDBCQUEwQjNFLENBQUMsQ0FBQzJFLElBQUksRUFBRSxDQUFDLENBQUM4RyxJQUFJLENBQUMsSUFBSSxDQUFDO01BQzVILElBQUEzQyxjQUFNLEVBQUMsT0FBTzlJLENBQUMsQ0FBQzBFLEdBQUcsRUFBRSxxQ0FBcUMsQ0FBQyxDQUFDK0csSUFBSSxDQUFDLFFBQVEsQ0FBQztNQUMxRSxJQUFBM0MsY0FBTSxFQUFDOUksQ0FBQyxDQUFDMEUsR0FBRyxDQUFDcUUsTUFBTSxDQUFDLENBQUNDLGVBQWUsQ0FBQyxDQUFDLENBQUM7TUFDdkM7TUFDQSxJQUFJaEosQ0FBQyxDQUFDMEwsUUFBUSxLQUFLQyxTQUFTLEVBQUUsSUFBQTdDLGNBQU0sRUFBQzlJLENBQUMsQ0FBQzBMLFFBQVEsQ0FBQ0UsVUFBVSxDQUFDLEdBQUcsQ0FBQyxFQUFFLDRCQUE0QjVMLENBQUMsQ0FBQzBMLFFBQVEsR0FBRyxDQUFDLENBQUNELElBQUksQ0FBQyxLQUFLLENBQUM7TUFDdkg7TUFDQTtNQUNBO01BQ0EsSUFBSXpMLENBQUMsQ0FBQzZMLElBQUksS0FBS0YsU0FBUyxFQUFFLElBQUE3QyxjQUFNLEVBQUMsT0FBTzlJLENBQUMsQ0FBQzZMLElBQUksQ0FBQyxDQUFDSixJQUFJLENBQUMsUUFBUSxDQUFDO01BQzlEO01BQ0E7TUFDQTtNQUNBLElBQUk1SSxJQUFJLEtBQUssVUFBVSxFQUFFO1FBQ3ZCLElBQUFpRyxjQUFNLEVBQUNuRSxJQUFJLENBQUMsQ0FBQ3NHLFNBQVMsQ0FBQyxRQUFRLENBQUM7UUFDaEMsSUFBQW5DLGNBQU0sRUFBQzlJLENBQUMsQ0FBQzBMLFFBQVEsQ0FBQyxDQUFDRCxJQUFJLENBQUMsT0FBTyxDQUFDO01BQ2xDO01BQ0EsSUFBQTNDLGNBQU0sRUFBQ2dCLFNBQVMsRUFBRSxHQUFHakgsSUFBSSx3QkFBd0I4QixJQUFJLCtCQUErQixDQUFDLENBQUM4RyxJQUFJLENBQUMsSUFBSSxDQUFDO0lBQ2xHO0VBQ0YsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDO0FBQUMsSUFBQXpELEVBQUE7QUFBQThELFlBQUEsQ0FBQTlELEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}