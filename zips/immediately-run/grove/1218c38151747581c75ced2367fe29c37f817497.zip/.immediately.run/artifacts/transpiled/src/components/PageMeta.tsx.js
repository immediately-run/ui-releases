var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = PageMeta;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.map.js");
var _sdk = require("@immediately-run/sdk");
var _useEntryKey = require("../hooks/useEntryKey");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$();
/* eslint-disable @typescript-eslint/no-explicit-any */
// `<PageMeta/>` — the current entry's date + tags as a styled strip, for authors
// who want the meta inside the body (the entry header already renders one).
function PageMeta() {
  _s();
  const key = (0, _useEntryKey.useEntryKey)();
  const meta = (0, _sdk.useFileMetadata)(key);
  if (!meta) return null;
  const tags = Array.isArray(meta.tags) ? meta.tags.filter(t => !t.startsWith('ui/')) : [];
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "grove-meta",
    children: [meta.date && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
      children: meta.date
    }), tags.length ? /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
      className: "dot",
      children: "\xB7"
    }) : null, tags.map(t => /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
      className: "grove-tag",
      children: ["#", t]
    }, t))]
  });
}
_s(PageMeta, "RkU1IV6y+CJHxBn2wESjvctU4/8=", false, function () {
  return [_useEntryKey.useEntryKey, _sdk.useFileMetadata];
});
_c = PageMeta;
var _c;
$RefreshReg$(_c, "PageMeta");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfc2RrIiwicmVxdWlyZSIsIl91c2VFbnRyeUtleSIsIl9qc3hSdW50aW1lIiwiX3MiLCIkUmVmcmVzaFNpZyQiLCJQYWdlTWV0YSIsImtleSIsInVzZUVudHJ5S2V5IiwibWV0YSIsInVzZUZpbGVNZXRhZGF0YSIsInRhZ3MiLCJBcnJheSIsImlzQXJyYXkiLCJmaWx0ZXIiLCJ0Iiwic3RhcnRzV2l0aCIsImpzeHMiLCJjbGFzc05hbWUiLCJjaGlsZHJlbiIsImRhdGUiLCJqc3giLCJsZW5ndGgiLCJtYXAiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlBhZ2VNZXRhLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55ICovXG5pbXBvcnQgeyB1c2VGaWxlTWV0YWRhdGEgfSBmcm9tICdAaW1tZWRpYXRlbHktcnVuL3Nkayc7XG5cbmltcG9ydCB7IHVzZUVudHJ5S2V5IH0gZnJvbSAnLi4vaG9va3MvdXNlRW50cnlLZXknO1xuXG4vLyBgPFBhZ2VNZXRhLz5gIOKAlCB0aGUgY3VycmVudCBlbnRyeSdzIGRhdGUgKyB0YWdzIGFzIGEgc3R5bGVkIHN0cmlwLCBmb3IgYXV0aG9yc1xuLy8gd2hvIHdhbnQgdGhlIG1ldGEgaW5zaWRlIHRoZSBib2R5ICh0aGUgZW50cnkgaGVhZGVyIGFscmVhZHkgcmVuZGVycyBvbmUpLlxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUGFnZU1ldGEoKSB7XG4gIGNvbnN0IGtleSA9IHVzZUVudHJ5S2V5KCk7XG4gIGNvbnN0IG1ldGEgPSB1c2VGaWxlTWV0YWRhdGEoa2V5KSBhcyBhbnk7XG4gIGlmICghbWV0YSkgcmV0dXJuIG51bGw7XG4gIGNvbnN0IHRhZ3M6IHN0cmluZ1tdID0gQXJyYXkuaXNBcnJheShtZXRhLnRhZ3MpID8gbWV0YS50YWdzLmZpbHRlcigodDogc3RyaW5nKSA9PiAhdC5zdGFydHNXaXRoKCd1aS8nKSkgOiBbXTtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImdyb3ZlLW1ldGFcIj5cbiAgICAgIHttZXRhLmRhdGUgJiYgPHNwYW4+e21ldGEuZGF0ZX08L3NwYW4+fVxuICAgICAge3RhZ3MubGVuZ3RoID8gPHNwYW4gY2xhc3NOYW1lPVwiZG90XCI+wrc8L3NwYW4+IDogbnVsbH1cbiAgICAgIHt0YWdzLm1hcCgodCkgPT4gKFxuICAgICAgICA8c3BhbiBrZXk9e3R9IGNsYXNzTmFtZT1cImdyb3ZlLXRhZ1wiPiN7dH08L3NwYW4+XG4gICAgICApKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQ0EsSUFBQUEsSUFBQSxHQUFBQyxPQUFBO0FBRUEsSUFBQUMsWUFBQSxHQUFBRCxPQUFBO0FBQW1ELElBQUFFLFdBQUEsR0FBQUYsT0FBQTtBQUFBLElBQUFHLEVBQUEsR0FBQUMsWUFBQTtBQUhuRDtBQUtBO0FBQ0E7QUFDZSxTQUFTQyxRQUFRQSxDQUFBLEVBQUc7RUFBQUYsRUFBQTtFQUNqQyxNQUFNRyxHQUFHLEdBQUcsSUFBQUMsd0JBQVcsRUFBQyxDQUFDO0VBQ3pCLE1BQU1DLElBQUksR0FBRyxJQUFBQyxvQkFBZSxFQUFDSCxHQUFHLENBQVE7RUFDeEMsSUFBSSxDQUFDRSxJQUFJLEVBQUUsT0FBTyxJQUFJO0VBQ3RCLE1BQU1FLElBQWMsR0FBR0MsS0FBSyxDQUFDQyxPQUFPLENBQUNKLElBQUksQ0FBQ0UsSUFBSSxDQUFDLEdBQUdGLElBQUksQ0FBQ0UsSUFBSSxDQUFDRyxNQUFNLENBQUVDLENBQVMsSUFBSyxDQUFDQSxDQUFDLENBQUNDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLEVBQUU7RUFDNUcsb0JBQ0UsSUFBQWIsV0FBQSxDQUFBYyxJQUFBO0lBQUtDLFNBQVMsRUFBQyxZQUFZO0lBQUFDLFFBQUEsR0FDeEJWLElBQUksQ0FBQ1csSUFBSSxpQkFBSSxJQUFBakIsV0FBQSxDQUFBa0IsR0FBQTtNQUFBRixRQUFBLEVBQU9WLElBQUksQ0FBQ1c7SUFBSSxDQUFPLENBQUMsRUFDckNULElBQUksQ0FBQ1csTUFBTSxnQkFBRyxJQUFBbkIsV0FBQSxDQUFBa0IsR0FBQTtNQUFNSCxTQUFTLEVBQUMsS0FBSztNQUFBQyxRQUFBLEVBQUM7SUFBQyxDQUFNLENBQUMsR0FBRyxJQUFJLEVBQ25EUixJQUFJLENBQUNZLEdBQUcsQ0FBRVIsQ0FBQyxpQkFDVixJQUFBWixXQUFBLENBQUFjLElBQUE7TUFBY0MsU0FBUyxFQUFDLFdBQVc7TUFBQUMsUUFBQSxHQUFDLEdBQUMsRUFBQ0osQ0FBQztJQUFBLEdBQTVCQSxDQUFtQyxDQUMvQyxDQUFDO0VBQUEsQ0FDQyxDQUFDO0FBRVY7QUFBQ1gsRUFBQSxDQWR1QkUsUUFBUTtFQUFBLFFBQ2xCRSx3QkFBVyxFQUNWRSxvQkFBZTtBQUFBO0FBQUFjLEVBQUEsR0FGTmxCLFFBQVE7QUFBQSxJQUFBa0IsRUFBQTtBQUFBQyxZQUFBLENBQUFELEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}