var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = AssetImage;
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
var _content = require("../lib/content");
var _assetPath = require("../lib/assetPath");
var _useEntryKey = require("../hooks/useEntryKey");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // MDX `img` override: display a mount-relative image by reading its bytes off the
// sandbox fs (the opaque-origin iframe can't fetch a relative path). Resolves the
// src relative to the entry currently being rendered — the entry context's entry,
// not the URL (R3-871: inside an included fragment or a layout, the URL names the
// wrong base) — then hands the file to the SDK's `MountImage`, which owns the
// read → object URL → revoke lifecycle we used to hand-roll here.
// The whole sandbox fs, `/`-rooted. The resolved asset path is already absolute
// (`/app/content/…`), so anchor at root and pass it as the mount-relative path
// (leading slash stripped) — preserving the exact paths the old `fs.readFile` read.
const ROOT_MOUNT = {
  path: '/',
  type: 'repo'
};
function AssetImage({
  src = '',
  alt = '',
  className
}) {
  _s();
  const entryKey = (0, _useEntryKey.useEntryKey)();
  const relPath = (0, _react.useMemo)(() => {
    // The entry's absolute fs path (/app/content/...) is the base for relative assets.
    const base = (0, _content.keyToFsPath)(entryKey);
    return (0, _assetPath.resolvePath)(base, src).replace(/^\/+/, '');
  }, [entryKey, src]);
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_sdk.MountImage, {
    mount: ROOT_MOUNT,
    relPath: relPath,
    alt: alt,
    className: className || 'grove-img__el',
    placeholder: /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
      className: "grove-img__box",
      style: {
        display: 'block',
        minHeight: 80
      }
    }),
    fallback: /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
      className: "grove-img__cap",
      children: ["missing asset: ", src]
    })
  });
}
_s(AssetImage, "D85NhxIOM5AjTchk7BliSP3fmfI=", false, function () {
  return [_useEntryKey.useEntryKey];
});
_c = AssetImage;
var _c;
$RefreshReg$(_c, "AssetImage");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NkayIsIl9jb250ZW50IiwiX2Fzc2V0UGF0aCIsIl91c2VFbnRyeUtleSIsIl9qc3hSdW50aW1lIiwiX3MiLCIkUmVmcmVzaFNpZyQiLCJST09UX01PVU5UIiwicGF0aCIsInR5cGUiLCJBc3NldEltYWdlIiwic3JjIiwiYWx0IiwiY2xhc3NOYW1lIiwiZW50cnlLZXkiLCJ1c2VFbnRyeUtleSIsInJlbFBhdGgiLCJ1c2VNZW1vIiwiYmFzZSIsImtleVRvRnNQYXRoIiwicmVzb2x2ZVBhdGgiLCJyZXBsYWNlIiwianN4IiwiTW91bnRJbWFnZSIsIm1vdW50IiwicGxhY2Vob2xkZXIiLCJzdHlsZSIsImRpc3BsYXkiLCJtaW5IZWlnaHQiLCJmYWxsYmFjayIsImpzeHMiLCJjaGlsZHJlbiIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQXNzZXRJbWFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlTWVtbyB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IE1vdW50SW1hZ2UgfSBmcm9tICdAaW1tZWRpYXRlbHktcnVuL3Nkayc7XG5pbXBvcnQgdHlwZSB7IFNhbmRib3hNb3VudCB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrJztcbmltcG9ydCB7IGtleVRvRnNQYXRoIH0gZnJvbSAnLi4vbGliL2NvbnRlbnQnO1xuaW1wb3J0IHsgcmVzb2x2ZVBhdGggfSBmcm9tICcuLi9saWIvYXNzZXRQYXRoJztcbmltcG9ydCB7IHVzZUVudHJ5S2V5IH0gZnJvbSAnLi4vaG9va3MvdXNlRW50cnlLZXknO1xuXG4vLyBNRFggYGltZ2Agb3ZlcnJpZGU6IGRpc3BsYXkgYSBtb3VudC1yZWxhdGl2ZSBpbWFnZSBieSByZWFkaW5nIGl0cyBieXRlcyBvZmYgdGhlXG4vLyBzYW5kYm94IGZzICh0aGUgb3BhcXVlLW9yaWdpbiBpZnJhbWUgY2FuJ3QgZmV0Y2ggYSByZWxhdGl2ZSBwYXRoKS4gUmVzb2x2ZXMgdGhlXG4vLyBzcmMgcmVsYXRpdmUgdG8gdGhlIGVudHJ5IGN1cnJlbnRseSBiZWluZyByZW5kZXJlZCDigJQgdGhlIGVudHJ5IGNvbnRleHQncyBlbnRyeSxcbi8vIG5vdCB0aGUgVVJMIChSMy04NzE6IGluc2lkZSBhbiBpbmNsdWRlZCBmcmFnbWVudCBvciBhIGxheW91dCwgdGhlIFVSTCBuYW1lcyB0aGVcbi8vIHdyb25nIGJhc2UpIOKAlCB0aGVuIGhhbmRzIHRoZSBmaWxlIHRvIHRoZSBTREsncyBgTW91bnRJbWFnZWAsIHdoaWNoIG93bnMgdGhlXG4vLyByZWFkIOKGkiBvYmplY3QgVVJMIOKGkiByZXZva2UgbGlmZWN5Y2xlIHdlIHVzZWQgdG8gaGFuZC1yb2xsIGhlcmUuXG5cbi8vIFRoZSB3aG9sZSBzYW5kYm94IGZzLCBgL2Atcm9vdGVkLiBUaGUgcmVzb2x2ZWQgYXNzZXQgcGF0aCBpcyBhbHJlYWR5IGFic29sdXRlXG4vLyAoYC9hcHAvY29udGVudC/igKZgKSwgc28gYW5jaG9yIGF0IHJvb3QgYW5kIHBhc3MgaXQgYXMgdGhlIG1vdW50LXJlbGF0aXZlIHBhdGhcbi8vIChsZWFkaW5nIHNsYXNoIHN0cmlwcGVkKSDigJQgcHJlc2VydmluZyB0aGUgZXhhY3QgcGF0aHMgdGhlIG9sZCBgZnMucmVhZEZpbGVgIHJlYWQuXG5jb25zdCBST09UX01PVU5UOiBTYW5kYm94TW91bnQgPSB7IHBhdGg6ICcvJywgdHlwZTogJ3JlcG8nIH07XG5cbmludGVyZmFjZSBQcm9wcyB7XG4gIHNyYz86IHN0cmluZztcbiAgYWx0Pzogc3RyaW5nO1xuICBjbGFzc05hbWU/OiBzdHJpbmc7XG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFzc2V0SW1hZ2UoeyBzcmMgPSAnJywgYWx0ID0gJycsIGNsYXNzTmFtZSB9OiBQcm9wcykge1xuICBjb25zdCBlbnRyeUtleSA9IHVzZUVudHJ5S2V5KCk7XG5cbiAgY29uc3QgcmVsUGF0aCA9IHVzZU1lbW8oKCkgPT4ge1xuICAgIC8vIFRoZSBlbnRyeSdzIGFic29sdXRlIGZzIHBhdGggKC9hcHAvY29udGVudC8uLi4pIGlzIHRoZSBiYXNlIGZvciByZWxhdGl2ZSBhc3NldHMuXG4gICAgY29uc3QgYmFzZSA9IGtleVRvRnNQYXRoKGVudHJ5S2V5KTtcbiAgICByZXR1cm4gcmVzb2x2ZVBhdGgoYmFzZSwgc3JjKS5yZXBsYWNlKC9eXFwvKy8sICcnKTtcbiAgfSwgW2VudHJ5S2V5LCBzcmNdKTtcblxuICByZXR1cm4gKFxuICAgIDxNb3VudEltYWdlXG4gICAgICBtb3VudD17Uk9PVF9NT1VOVH1cbiAgICAgIHJlbFBhdGg9e3JlbFBhdGh9XG4gICAgICBhbHQ9e2FsdH1cbiAgICAgIGNsYXNzTmFtZT17Y2xhc3NOYW1lIHx8ICdncm92ZS1pbWdfX2VsJ31cbiAgICAgIHBsYWNlaG9sZGVyPXtcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZ3JvdmUtaW1nX19ib3hcIiBzdHlsZT17eyBkaXNwbGF5OiAnYmxvY2snLCBtaW5IZWlnaHQ6IDgwIH19IC8+XG4gICAgICB9XG4gICAgICBmYWxsYmFjaz17PHNwYW4gY2xhc3NOYW1lPVwiZ3JvdmUtaW1nX19jYXBcIj5taXNzaW5nIGFzc2V0OiB7c3JjfTwvc3Bhbj59XG4gICAgLz5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQUEsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsSUFBQSxHQUFBRCxPQUFBO0FBRUEsSUFBQUUsUUFBQSxHQUFBRixPQUFBO0FBQ0EsSUFBQUcsVUFBQSxHQUFBSCxPQUFBO0FBQ0EsSUFBQUksWUFBQSxHQUFBSixPQUFBO0FBQW1ELElBQUFLLFdBQUEsR0FBQUwsT0FBQTtBQUFBLElBQUFNLEVBQUEsR0FBQUMsWUFBQSxJQUVuRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQSxNQUFNQyxVQUF3QixHQUFHO0VBQUVDLElBQUksRUFBRSxHQUFHO0VBQUVDLElBQUksRUFBRTtBQUFPLENBQUM7QUFRN0MsU0FBU0MsVUFBVUEsQ0FBQztFQUFFQyxHQUFHLEdBQUcsRUFBRTtFQUFFQyxHQUFHLEdBQUcsRUFBRTtFQUFFQztBQUFpQixDQUFDLEVBQUU7RUFBQVIsRUFBQTtFQUMzRSxNQUFNUyxRQUFRLEdBQUcsSUFBQUMsd0JBQVcsRUFBQyxDQUFDO0VBRTlCLE1BQU1DLE9BQU8sR0FBRyxJQUFBQyxjQUFPLEVBQUMsTUFBTTtJQUM1QjtJQUNBLE1BQU1DLElBQUksR0FBRyxJQUFBQyxvQkFBVyxFQUFDTCxRQUFRLENBQUM7SUFDbEMsT0FBTyxJQUFBTSxzQkFBVyxFQUFDRixJQUFJLEVBQUVQLEdBQUcsQ0FBQyxDQUFDVSxPQUFPLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQztFQUNuRCxDQUFDLEVBQUUsQ0FBQ1AsUUFBUSxFQUFFSCxHQUFHLENBQUMsQ0FBQztFQUVuQixvQkFDRSxJQUFBUCxXQUFBLENBQUFrQixHQUFBLEVBQUN0QixJQUFBLENBQUF1QixVQUFVO0lBQ1RDLEtBQUssRUFBRWpCLFVBQVc7SUFDbEJTLE9BQU8sRUFBRUEsT0FBUTtJQUNqQkosR0FBRyxFQUFFQSxHQUFJO0lBQ1RDLFNBQVMsRUFBRUEsU0FBUyxJQUFJLGVBQWdCO0lBQ3hDWSxXQUFXLGVBQ1QsSUFBQXJCLFdBQUEsQ0FBQWtCLEdBQUE7TUFBTVQsU0FBUyxFQUFDLGdCQUFnQjtNQUFDYSxLQUFLLEVBQUU7UUFBRUMsT0FBTyxFQUFFLE9BQU87UUFBRUMsU0FBUyxFQUFFO01BQUc7SUFBRSxDQUFFLENBQy9FO0lBQ0RDLFFBQVEsZUFBRSxJQUFBekIsV0FBQSxDQUFBMEIsSUFBQTtNQUFNakIsU0FBUyxFQUFDLGdCQUFnQjtNQUFBa0IsUUFBQSxHQUFDLGlCQUFlLEVBQUNwQixHQUFHO0lBQUEsQ0FBTztFQUFFLENBQ3hFLENBQUM7QUFFTjtBQUFDTixFQUFBLENBckJ1QkssVUFBVTtFQUFBLFFBQ2ZLLHdCQUFXO0FBQUE7QUFBQWlCLEVBQUEsR0FETnRCLFVBQVU7QUFBQSxJQUFBc0IsRUFBQTtBQUFBQyxZQUFBLENBQUFELEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}