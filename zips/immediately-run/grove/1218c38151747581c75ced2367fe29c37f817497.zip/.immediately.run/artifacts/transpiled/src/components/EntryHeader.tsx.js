var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = EntryHeader;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.map.js");
var _sdk = require("@immediately-run/sdk");
var _shell = require("../lib/shell");
var _wiki = require("../lib/wiki");
var _Icon = _interopRequireDefault(require("./Icon"));
var _InlineProse = _interopRequireDefault(require("./InlineProse"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$();
/* eslint-disable @typescript-eslint/no-explicit-any */
// The entry's header block: breadcrumb, title (optional gradient), meta row
// (date · reading time · tags) and the unobtrusive edit affordance. Rendered by
// <EntryBody> at the top of every entry (R3-872) — on the stock page (inside
// PageView inside the chain) and standalone, identically.
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function EntryHeader({
  entryKey,
  writable,
  mins,
  affordance
}) {
  _s();
  const {
    openEditor,
    busy: editBusy,
    refused: editRefused,
    hint: editHint
  } = affordance;
  const meta = (0, _sdk.useFileMetadata)(entryKey);
  if (!meta) return null;
  const tags = Array.isArray(meta.tags) ? meta.tags.filter(t => !t.startsWith('ui/')) : [];
  const cr = (0, _wiki.crumb)(entryKey);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("header", {
    className: "grove-entry-header",
    children: [cr.includes('/') ? /*#__PURE__*/(0, _jsxRuntime.jsx)("nav", {
      className: "crumb",
      children: cr
    }) : null, /*#__PURE__*/(0, _jsxRuntime.jsx)("h1", {
      className: meta.grad ? 'grad' : '',
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_InlineProse.default, {
        text: meta.title || cr
      })
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "grove-meta",
      children: [meta.date && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        children: meta.date
      }), mins ? /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
        children: ["\u2192 ", mins, " min read"]
      }) : null, tags.length ? /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "dot",
        children: "\xB7"
      }) : null, tags.map(t => /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
        className: "grove-tag",
        children: ["#", t]
      }, t)), writable && /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
          className: "grove-edit-affordance",
          "data-busy": editBusy ? '1' : '0',
          title: editHint,
          onClick: () => openEditor(entryKey),
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
            name: "pencil"
          }), editBusy ? 'Opening editor…' : 'Edit']
        }), editRefused && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "grove-edit-refused",
          role: "status",
          children: _shell.EDIT_REFUSED_NOTICE
        })]
      })]
    })]
  });
}
_s(EntryHeader, "HCQWmXfXYtrNQZ9MFtiZso5O/l0=", false, function () {
  return [_sdk.useFileMetadata];
});
_c = EntryHeader;
var _c;
$RefreshReg$(_c, "EntryHeader");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfc2RrIiwicmVxdWlyZSIsIl9zaGVsbCIsIl93aWtpIiwiX0ljb24iLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX0lubGluZVByb3NlIiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsIkVudHJ5SGVhZGVyIiwiZW50cnlLZXkiLCJ3cml0YWJsZSIsIm1pbnMiLCJhZmZvcmRhbmNlIiwib3BlbkVkaXRvciIsImJ1c3kiLCJlZGl0QnVzeSIsInJlZnVzZWQiLCJlZGl0UmVmdXNlZCIsImhpbnQiLCJlZGl0SGludCIsIm1ldGEiLCJ1c2VGaWxlTWV0YWRhdGEiLCJ0YWdzIiwiQXJyYXkiLCJpc0FycmF5IiwiZmlsdGVyIiwidCIsInN0YXJ0c1dpdGgiLCJjciIsImNydW1iIiwianN4cyIsImNsYXNzTmFtZSIsImNoaWxkcmVuIiwiaW5jbHVkZXMiLCJqc3giLCJncmFkIiwidGV4dCIsInRpdGxlIiwiZGF0ZSIsImxlbmd0aCIsIm1hcCIsIkZyYWdtZW50Iiwib25DbGljayIsIm5hbWUiLCJyb2xlIiwiRURJVF9SRUZVU0VEX05PVElDRSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiRW50cnlIZWFkZXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHBsaWNpdC1hbnkgKi9cbmltcG9ydCB7IHVzZUZpbGVNZXRhZGF0YSB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrJztcbmltcG9ydCB7IEVESVRfUkVGVVNFRF9OT1RJQ0UgfSBmcm9tICcuLi9saWIvc2hlbGwnO1xuaW1wb3J0IHsgY3J1bWIgfSBmcm9tICcuLi9saWIvd2lraSc7XG5pbXBvcnQgSWNvbiBmcm9tICcuL0ljb24nO1xuaW1wb3J0IElubGluZVByb3NlIGZyb20gJy4vSW5saW5lUHJvc2UnO1xuXG4vLyBUaGUgZW50cnkncyBoZWFkZXIgYmxvY2s6IGJyZWFkY3J1bWIsIHRpdGxlIChvcHRpb25hbCBncmFkaWVudCksIG1ldGEgcm93XG4vLyAoZGF0ZSDCtyByZWFkaW5nIHRpbWUgwrcgdGFncykgYW5kIHRoZSB1bm9idHJ1c2l2ZSBlZGl0IGFmZm9yZGFuY2UuIFJlbmRlcmVkIGJ5XG4vLyA8RW50cnlCb2R5PiBhdCB0aGUgdG9wIG9mIGV2ZXJ5IGVudHJ5IChSMy04NzIpIOKAlCBvbiB0aGUgc3RvY2sgcGFnZSAoaW5zaWRlXG4vLyBQYWdlVmlldyBpbnNpZGUgdGhlIGNoYWluKSBhbmQgc3RhbmRhbG9uZSwgaWRlbnRpY2FsbHkuXG5leHBvcnQgaW50ZXJmYWNlIEVudHJ5SGVhZGVyQWZmb3JkYW5jZSB7XG4gIGJ1c3k6IGJvb2xlYW47XG4gIHJlZnVzZWQ6IGJvb2xlYW47XG4gIG9wZW5FZGl0b3I6IChlbnRyeUtleTogc3RyaW5nKSA9PiB2b2lkO1xuICBoaW50OiBzdHJpbmc7XG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEVudHJ5SGVhZGVyKHtcbiAgZW50cnlLZXksXG4gIHdyaXRhYmxlLFxuICBtaW5zLFxuICBhZmZvcmRhbmNlLFxufToge1xuICBlbnRyeUtleTogc3RyaW5nO1xuICB3cml0YWJsZTogYm9vbGVhbjtcbiAgbWluczogbnVtYmVyO1xuICAvKiogVGhlIGVkaXQgYWZmb3JkYW5jZSdzIGxpdmUgc3RhdGUg4oCUIFIzLTg3MjogcGFzc2VkIGluICh0aGUgc2hlbGwncyBvbiB0aGVcbiAgICogIHN0b2NrIHBhZ2UsIHNlbGYtZGVyaXZlZCBzdGFuZGFsb25lKSwgbmV2ZXIgcmVhZCBvZmYgYSBjb250ZXh0IGhlcmUsIHNvIHRoZVxuICAgKiAgaGVhZGVyIHJlbmRlcnMgaW5zaWRlIGFueSBlbnRyeSBjb21wb3NpdGlvbi4gKi9cbiAgYWZmb3JkYW5jZTogRW50cnlIZWFkZXJBZmZvcmRhbmNlO1xufSkge1xuICBjb25zdCB7IG9wZW5FZGl0b3IsIGJ1c3k6IGVkaXRCdXN5LCByZWZ1c2VkOiBlZGl0UmVmdXNlZCwgaGludDogZWRpdEhpbnQgfSA9IGFmZm9yZGFuY2U7XG4gIGNvbnN0IG1ldGEgPSB1c2VGaWxlTWV0YWRhdGEoZW50cnlLZXkpIGFzIGFueTtcbiAgaWYgKCFtZXRhKSByZXR1cm4gbnVsbDtcbiAgY29uc3QgdGFnczogc3RyaW5nW10gPSBBcnJheS5pc0FycmF5KG1ldGEudGFncykgPyBtZXRhLnRhZ3MuZmlsdGVyKCh0OiBzdHJpbmcpID0+ICF0LnN0YXJ0c1dpdGgoJ3VpLycpKSA6IFtdO1xuICBjb25zdCBjciA9IGNydW1iKGVudHJ5S2V5KTtcbiAgcmV0dXJuIChcbiAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImdyb3ZlLWVudHJ5LWhlYWRlclwiPlxuICAgICAge2NyLmluY2x1ZGVzKCcvJykgPyA8bmF2IGNsYXNzTmFtZT1cImNydW1iXCI+e2NyfTwvbmF2PiA6IG51bGx9XG4gICAgICA8aDEgY2xhc3NOYW1lPXttZXRhLmdyYWQgPyAnZ3JhZCcgOiAnJ30+XG4gICAgICAgIHsvKiBSMy01MzEg4oCUIHRoZSB0aXRsZSBpcyBmcm9udG1hdHRlciBwcm9zZTogY29kZSBzcGFucyByZW5kZXIgYXMgY29kZS4gKi99XG4gICAgICAgIDxJbmxpbmVQcm9zZSB0ZXh0PXttZXRhLnRpdGxlIHx8IGNyfSAvPlxuICAgICAgPC9oMT5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JvdmUtbWV0YVwiPlxuICAgICAgICB7bWV0YS5kYXRlICYmIDxzcGFuPnttZXRhLmRhdGV9PC9zcGFuPn1cbiAgICAgICAge21pbnMgPyA8c3Bhbj7ihpIge21pbnN9IG1pbiByZWFkPC9zcGFuPiA6IG51bGx9XG4gICAgICAgIHt0YWdzLmxlbmd0aCA/IDxzcGFuIGNsYXNzTmFtZT1cImRvdFwiPsK3PC9zcGFuPiA6IG51bGx9XG4gICAgICAgIHt0YWdzLm1hcCgodCkgPT4gKFxuICAgICAgICAgIDxzcGFuIGtleT17dH0gY2xhc3NOYW1lPVwiZ3JvdmUtdGFnXCI+I3t0fTwvc3Bhbj5cbiAgICAgICAgKSl9XG4gICAgICAgIHt3cml0YWJsZSAmJiAoXG4gICAgICAgICAgPD5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ3JvdmUtZWRpdC1hZmZvcmRhbmNlXCJcbiAgICAgICAgICAgICAgZGF0YS1idXN5PXtlZGl0QnVzeSA/ICcxJyA6ICcwJ31cbiAgICAgICAgICAgICAgdGl0bGU9e2VkaXRIaW50fVxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvcGVuRWRpdG9yKGVudHJ5S2V5KX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPEljb24gbmFtZT1cInBlbmNpbFwiIC8+XG4gICAgICAgICAgICAgIHtlZGl0QnVzeSA/ICdPcGVuaW5nIGVkaXRvcuKApicgOiAnRWRpdCd9XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIHtlZGl0UmVmdXNlZCAmJiAoXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImdyb3ZlLWVkaXQtcmVmdXNlZFwiIHJvbGU9XCJzdGF0dXNcIj5cbiAgICAgICAgICAgICAgICB7RURJVF9SRUZVU0VEX05PVElDRX1cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8Lz5cbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuICAgIDwvaGVhZGVyPlxuICApO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFDQSxJQUFBQSxJQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxNQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxLQUFBLEdBQUFGLE9BQUE7QUFDQSxJQUFBRyxLQUFBLEdBQUFDLHNCQUFBLENBQUFKLE9BQUE7QUFDQSxJQUFBSyxZQUFBLEdBQUFELHNCQUFBLENBQUFKLE9BQUE7QUFBd0MsSUFBQU0sV0FBQSxHQUFBTixPQUFBO0FBQUEsSUFBQU8sRUFBQSxHQUFBQyxZQUFBO0FBTHhDO0FBT0E7QUFDQTtBQUNBO0FBQ0E7QUFBQSxTQUFBSix1QkFBQUssQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQVFlLFNBQVNHLFdBQVdBLENBQUM7RUFDbENDLFFBQVE7RUFDUkMsUUFBUTtFQUNSQyxJQUFJO0VBQ0pDO0FBU0YsQ0FBQyxFQUFFO0VBQUFULEVBQUE7RUFDRCxNQUFNO0lBQUVVLFVBQVU7SUFBRUMsSUFBSSxFQUFFQyxRQUFRO0lBQUVDLE9BQU8sRUFBRUMsV0FBVztJQUFFQyxJQUFJLEVBQUVDO0VBQVMsQ0FBQyxHQUFHUCxVQUFVO0VBQ3ZGLE1BQU1RLElBQUksR0FBRyxJQUFBQyxvQkFBZSxFQUFDWixRQUFRLENBQVE7RUFDN0MsSUFBSSxDQUFDVyxJQUFJLEVBQUUsT0FBTyxJQUFJO0VBQ3RCLE1BQU1FLElBQWMsR0FBR0MsS0FBSyxDQUFDQyxPQUFPLENBQUNKLElBQUksQ0FBQ0UsSUFBSSxDQUFDLEdBQUdGLElBQUksQ0FBQ0UsSUFBSSxDQUFDRyxNQUFNLENBQUVDLENBQVMsSUFBSyxDQUFDQSxDQUFDLENBQUNDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLEVBQUU7RUFDNUcsTUFBTUMsRUFBRSxHQUFHLElBQUFDLFdBQUssRUFBQ3BCLFFBQVEsQ0FBQztFQUMxQixvQkFDRSxJQUFBUCxXQUFBLENBQUE0QixJQUFBO0lBQVFDLFNBQVMsRUFBQyxvQkFBb0I7SUFBQUMsUUFBQSxHQUNuQ0osRUFBRSxDQUFDSyxRQUFRLENBQUMsR0FBRyxDQUFDLGdCQUFHLElBQUEvQixXQUFBLENBQUFnQyxHQUFBO01BQUtILFNBQVMsRUFBQyxPQUFPO01BQUFDLFFBQUEsRUFBRUo7SUFBRSxDQUFNLENBQUMsR0FBRyxJQUFJLGVBQzVELElBQUExQixXQUFBLENBQUFnQyxHQUFBO01BQUlILFNBQVMsRUFBRVgsSUFBSSxDQUFDZSxJQUFJLEdBQUcsTUFBTSxHQUFHLEVBQUc7TUFBQUgsUUFBQSxlQUVyQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDakMsWUFBQSxDQUFBTSxPQUFXO1FBQUM2QixJQUFJLEVBQUVoQixJQUFJLENBQUNpQixLQUFLLElBQUlUO01BQUcsQ0FBRTtJQUFDLENBQ3JDLENBQUMsZUFDTCxJQUFBMUIsV0FBQSxDQUFBNEIsSUFBQTtNQUFLQyxTQUFTLEVBQUMsWUFBWTtNQUFBQyxRQUFBLEdBQ3hCWixJQUFJLENBQUNrQixJQUFJLGlCQUFJLElBQUFwQyxXQUFBLENBQUFnQyxHQUFBO1FBQUFGLFFBQUEsRUFBT1osSUFBSSxDQUFDa0I7TUFBSSxDQUFPLENBQUMsRUFDckMzQixJQUFJLGdCQUFHLElBQUFULFdBQUEsQ0FBQTRCLElBQUE7UUFBQUUsUUFBQSxHQUFNLFNBQUUsRUFBQ3JCLElBQUksRUFBQyxXQUFTO01BQUEsQ0FBTSxDQUFDLEdBQUcsSUFBSSxFQUM1Q1csSUFBSSxDQUFDaUIsTUFBTSxnQkFBRyxJQUFBckMsV0FBQSxDQUFBZ0MsR0FBQTtRQUFNSCxTQUFTLEVBQUMsS0FBSztRQUFBQyxRQUFBLEVBQUM7TUFBQyxDQUFNLENBQUMsR0FBRyxJQUFJLEVBQ25EVixJQUFJLENBQUNrQixHQUFHLENBQUVkLENBQUMsaUJBQ1YsSUFBQXhCLFdBQUEsQ0FBQTRCLElBQUE7UUFBY0MsU0FBUyxFQUFDLFdBQVc7UUFBQUMsUUFBQSxHQUFDLEdBQUMsRUFBQ04sQ0FBQztNQUFBLEdBQTVCQSxDQUFtQyxDQUMvQyxDQUFDLEVBQ0RoQixRQUFRLGlCQUNQLElBQUFSLFdBQUEsQ0FBQTRCLElBQUEsRUFBQTVCLFdBQUEsQ0FBQXVDLFFBQUE7UUFBQVQsUUFBQSxnQkFDRSxJQUFBOUIsV0FBQSxDQUFBNEIsSUFBQTtVQUNFQyxTQUFTLEVBQUMsdUJBQXVCO1VBQ2pDLGFBQVdoQixRQUFRLEdBQUcsR0FBRyxHQUFHLEdBQUk7VUFDaENzQixLQUFLLEVBQUVsQixRQUFTO1VBQ2hCdUIsT0FBTyxFQUFFQSxDQUFBLEtBQU03QixVQUFVLENBQUNKLFFBQVEsQ0FBRTtVQUFBdUIsUUFBQSxnQkFFcEMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQ25DLEtBQUEsQ0FBQVEsT0FBSTtZQUFDb0MsSUFBSSxFQUFDO1VBQVEsQ0FBRSxDQUFDLEVBQ3JCNUIsUUFBUSxHQUFHLGlCQUFpQixHQUFHLE1BQU07UUFBQSxDQUNoQyxDQUFDLEVBQ1JFLFdBQVcsaUJBQ1YsSUFBQWYsV0FBQSxDQUFBZ0MsR0FBQTtVQUFNSCxTQUFTLEVBQUMsb0JBQW9CO1VBQUNhLElBQUksRUFBQyxRQUFRO1VBQUFaLFFBQUEsRUFDL0NhO1FBQW1CLENBQ2hCLENBQ1A7TUFBQSxDQUNELENBQ0g7SUFBQSxDQUNFLENBQUM7RUFBQSxDQUNBLENBQUM7QUFFYjtBQUFDMUMsRUFBQSxDQXREdUJLLFdBQVc7RUFBQSxRQWVwQmEsb0JBQWU7QUFBQTtBQUFBeUIsRUFBQSxHQWZOdEMsV0FBVztBQUFBLElBQUFzQyxFQUFBO0FBQUFDLFlBQUEsQ0FBQUQsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}