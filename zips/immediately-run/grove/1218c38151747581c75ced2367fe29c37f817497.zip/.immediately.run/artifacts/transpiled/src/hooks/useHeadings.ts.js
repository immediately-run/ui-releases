"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useActiveHeading = useActiveHeading;
exports.useHeadings = useHeadings;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.every.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.find.js");
require("core-js/modules/esnext.iterator.for-each.js");
require("core-js/modules/esnext.iterator.map.js");
var _react = require("react");
var _wiki = require("../lib/wiki");
// The rendered entry's headings, and which one the reader is in.
//
// Extracted from `<Toc>` when `<TableOfContents>` arrived, so the two surfaces cannot
// disagree about what a heading is — the drift ENGINE_BOUNDARY §4 exists to prevent. The
// scan reads the DOM rather than the source because an entry is rendered through
// `<Include>` (compiled MDX) or the safe renderer; neither hands back a heading list, and
// the ids a citation lands on are the ones actually in the document.

/** Heading text WITHOUT the kernel's autolink anchor. The SDK's HeadingAnchor (§15.4)
 *  prepends `<a class="ir-heading-anchor">#</a>` as the first child, so `textContent`
 *  alone would put a stray `#` in every label and in the id fallback. */
function headingText(node) {
  const anchor = node.querySelector('.ir-heading-anchor');
  if (!anchor) return (node.textContent || '').trim();
  return Array.from(node.childNodes).filter(c => c !== anchor).map(c => c.textContent ?? '').join('').trim();
}

/**
 * Scan the entry's body for `h2`/`h3`, assigning the canonical id to any heading the
 * kernel did not emit one for, and re-scan as the prose mounts or swaps on navigation.
 *
 * R3-872 (APP_CUSTOMIZATION §4.5): the scan is scoped to the ENTRY's marked body
 * (`[data-entry="<entryKey>"]` — emitted on both render paths), never the whole
 * document: on a multi-entry page the first `.grove-prose` is whichever entry mounted
 * first, and its headings are the wrong entry's. Unscoped (no key, or no marked body
 * anywhere) falls back to the document — the pre-marker behavior, for content that
 * never renders through the marked paths.
 */
function useHeadings(entryKey) {
  const [heads, setHeads] = (0, _react.useState)([]);
  (0, _react.useEffect)(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setHeads([]);
    // The scan root: this entry's marked body when markers exist; the document only
    // when NO body is marked at all (the pre-marker world). A page with markers but
    // none for this key (the body is still compiling) scans nothing — the observer
    // watches the DOCUMENT until this entry's marker lands, then re-scopes (a
    // late-committing entry's ToC must not stay empty for the mount's lifetime).
    // NOTE: the marker sits INSIDE `.grove-prose` (both render paths), so the
    // scoped query runs over the marker's own subtree — searching the marker FOR
    // '.grove-prose' would find nothing (review round 1, G-CUST-2 regression).
    const markedRoot = () => entryKey === undefined ? null : Array.from(document.querySelectorAll('[data-entry]')).find(n => n.getAttribute('data-entry') === entryKey) ?? null;
    const anyMarked = () => document.querySelectorAll('[data-entry]').length > 0;
    const root = () => {
      const marked = markedRoot();
      if (marked) return marked;
      if (entryKey === undefined) return document;
      return anyMarked() ? null : document;
    };
    const scan = () => {
      const r = root();
      // Scoped: the marker's subtree holds the entry's headings. Unscoped (no
      // markers anywhere): the document's `.grove-prose`, as before.
      const nodes = !r ? [] : r === document ? (() => {
        const prose = document.querySelector('.grove-prose');
        return prose ? Array.from(prose.querySelectorAll('h2, h3')) : [];
      })() : Array.from(r.querySelectorAll('h2, h3'));
      const found = nodes.map(n => {
        const text = headingText(n);
        // Prefer the kernel-emitted id (§15.5); `headingId` reproduces the same canon
        // (`@immediately-run/mdx-plugins`) for a heading that has none.
        const id = n.id || (0, _wiki.headingId)(text);
        n.id = id;
        return {
          id,
          text,
          level: n.tagName === 'H3' ? 3 : 2
        };
      });
      // Identity-stable when nothing changed: this runs from a MutationObserver, and a
      // fresh array every mutation would re-run every downstream effect (the spy, the
      // scroll) on each keystroke of an editor-driven re-render.
      setHeads(prev => prev.length === found.length && prev.every((h, i) => h.id === found[i].id) ? prev : found);
    };
    // Observe the SCOPED root when it exists; while our marker is absent (the
    // body still compiling), observe the DOCUMENT so the marker's arrival
    // triggers the rescan that re-scopes — then move the observer onto the
    // marker (a whole-document watch would re-scan on every mutation anywhere,
    // the churn the identity guard exists to absorb).
    let observing = null;
    const obs = new MutationObserver(() => {
      const wanted = root() ?? document;
      if (wanted !== observing) {
        obs.disconnect();
        obs.observe(wanted, {
          childList: true,
          subtree: true
        });
        observing = wanted;
      }
      scan();
    });
    observing = root() ?? document;
    obs.observe(observing, {
      childList: true,
      subtree: true
    });
    scan();
    // `<Include>` resolves asynchronously, and the observer only fires if `.grove-prose`
    // already existed — these catch the window where it did not.
    const timers = [120, 300, 600].map(d => setTimeout(scan, d));
    return () => {
      obs.disconnect();
      timers.forEach(clearTimeout);
    };
  }, [entryKey]);
  return heads;
}

/** Which heading the reader is currently in — scroll-spied. R3-872: scoped to the
 *  entry's marked body when a key is given — duplicate section ids across entries on
 *  one page are the norm (every spec numbers from 1), and `document.getElementById`
 *  would return the FIRST entry's heading, spying on the wrong entry. */
function useActiveHeading(heads, entryKey) {
  const [cur, setCur] = (0, _react.useState)('');
  (0, _react.useEffect)(() => {
    if (!heads.length) return;
    const scope = entryKey === undefined ? document : Array.from(document.querySelectorAll('[data-entry]')).find(n => n.getAttribute('data-entry') === entryKey) ?? document;
    const obs = new IntersectionObserver(entries => {
      const visible = entries.filter(e => e.isIntersecting);
      if (visible.length) setCur(visible[0].target.id);
    }, {
      rootMargin: '-64px 0px -70% 0px',
      threshold: 0
    });
    heads.forEach(h => {
      // find the element INSIDE the scope (a heading id is only unique per entry)
      const el = scope === document ? document.getElementById(h.id) : scope.querySelector(`#${CSS.escape(h.id)}`);
      if (el) obs.observe(el);
    });
    return () => obs.disconnect();
  }, [heads, entryKey]);
  return cur;
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3dpa2kiLCJoZWFkaW5nVGV4dCIsIm5vZGUiLCJhbmNob3IiLCJxdWVyeVNlbGVjdG9yIiwidGV4dENvbnRlbnQiLCJ0cmltIiwiQXJyYXkiLCJmcm9tIiwiY2hpbGROb2RlcyIsImZpbHRlciIsImMiLCJtYXAiLCJqb2luIiwidXNlSGVhZGluZ3MiLCJlbnRyeUtleSIsImhlYWRzIiwic2V0SGVhZHMiLCJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsIm1hcmtlZFJvb3QiLCJ1bmRlZmluZWQiLCJkb2N1bWVudCIsInF1ZXJ5U2VsZWN0b3JBbGwiLCJmaW5kIiwibiIsImdldEF0dHJpYnV0ZSIsImFueU1hcmtlZCIsImxlbmd0aCIsInJvb3QiLCJtYXJrZWQiLCJzY2FuIiwiciIsIm5vZGVzIiwicHJvc2UiLCJmb3VuZCIsInRleHQiLCJpZCIsImhlYWRpbmdJZCIsImxldmVsIiwidGFnTmFtZSIsInByZXYiLCJldmVyeSIsImgiLCJpIiwib2JzZXJ2aW5nIiwib2JzIiwiTXV0YXRpb25PYnNlcnZlciIsIndhbnRlZCIsImRpc2Nvbm5lY3QiLCJvYnNlcnZlIiwiY2hpbGRMaXN0Iiwic3VidHJlZSIsInRpbWVycyIsImQiLCJzZXRUaW1lb3V0IiwiZm9yRWFjaCIsImNsZWFyVGltZW91dCIsInVzZUFjdGl2ZUhlYWRpbmciLCJjdXIiLCJzZXRDdXIiLCJzY29wZSIsIkludGVyc2VjdGlvbk9ic2VydmVyIiwiZW50cmllcyIsInZpc2libGUiLCJlIiwiaXNJbnRlcnNlY3RpbmciLCJ0YXJnZXQiLCJyb290TWFyZ2luIiwidGhyZXNob2xkIiwiZWwiLCJnZXRFbGVtZW50QnlJZCIsIkNTUyIsImVzY2FwZSJdLCJzb3VyY2VzIjpbInVzZUhlYWRpbmdzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIFRoZSByZW5kZXJlZCBlbnRyeSdzIGhlYWRpbmdzLCBhbmQgd2hpY2ggb25lIHRoZSByZWFkZXIgaXMgaW4uXG4vL1xuLy8gRXh0cmFjdGVkIGZyb20gYDxUb2M+YCB3aGVuIGA8VGFibGVPZkNvbnRlbnRzPmAgYXJyaXZlZCwgc28gdGhlIHR3byBzdXJmYWNlcyBjYW5ub3Rcbi8vIGRpc2FncmVlIGFib3V0IHdoYXQgYSBoZWFkaW5nIGlzIOKAlCB0aGUgZHJpZnQgRU5HSU5FX0JPVU5EQVJZIMKnNCBleGlzdHMgdG8gcHJldmVudC4gVGhlXG4vLyBzY2FuIHJlYWRzIHRoZSBET00gcmF0aGVyIHRoYW4gdGhlIHNvdXJjZSBiZWNhdXNlIGFuIGVudHJ5IGlzIHJlbmRlcmVkIHRocm91Z2hcbi8vIGA8SW5jbHVkZT5gIChjb21waWxlZCBNRFgpIG9yIHRoZSBzYWZlIHJlbmRlcmVyOyBuZWl0aGVyIGhhbmRzIGJhY2sgYSBoZWFkaW5nIGxpc3QsIGFuZFxuLy8gdGhlIGlkcyBhIGNpdGF0aW9uIGxhbmRzIG9uIGFyZSB0aGUgb25lcyBhY3R1YWxseSBpbiB0aGUgZG9jdW1lbnQuXG5cbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBoZWFkaW5nSWQgfSBmcm9tICcuLi9saWIvd2lraSc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgSGVhZGluZyB7XG4gIGlkOiBzdHJpbmc7XG4gIHRleHQ6IHN0cmluZztcbiAgbGV2ZWw6IG51bWJlcjtcbn1cblxuLyoqIEhlYWRpbmcgdGV4dCBXSVRIT1VUIHRoZSBrZXJuZWwncyBhdXRvbGluayBhbmNob3IuIFRoZSBTREsncyBIZWFkaW5nQW5jaG9yICjCpzE1LjQpXG4gKiAgcHJlcGVuZHMgYDxhIGNsYXNzPVwiaXItaGVhZGluZy1hbmNob3JcIj4jPC9hPmAgYXMgdGhlIGZpcnN0IGNoaWxkLCBzbyBgdGV4dENvbnRlbnRgXG4gKiAgYWxvbmUgd291bGQgcHV0IGEgc3RyYXkgYCNgIGluIGV2ZXJ5IGxhYmVsIGFuZCBpbiB0aGUgaWQgZmFsbGJhY2suICovXG5mdW5jdGlvbiBoZWFkaW5nVGV4dChub2RlOiBFbGVtZW50KTogc3RyaW5nIHtcbiAgY29uc3QgYW5jaG9yID0gbm9kZS5xdWVyeVNlbGVjdG9yKCcuaXItaGVhZGluZy1hbmNob3InKTtcbiAgaWYgKCFhbmNob3IpIHJldHVybiAobm9kZS50ZXh0Q29udGVudCB8fCAnJykudHJpbSgpO1xuICByZXR1cm4gQXJyYXkuZnJvbShub2RlLmNoaWxkTm9kZXMpXG4gICAgLmZpbHRlcigoYykgPT4gYyAhPT0gYW5jaG9yKVxuICAgIC5tYXAoKGMpID0+IGMudGV4dENvbnRlbnQgPz8gJycpXG4gICAgLmpvaW4oJycpXG4gICAgLnRyaW0oKTtcbn1cblxuLyoqXG4gKiBTY2FuIHRoZSBlbnRyeSdzIGJvZHkgZm9yIGBoMmAvYGgzYCwgYXNzaWduaW5nIHRoZSBjYW5vbmljYWwgaWQgdG8gYW55IGhlYWRpbmcgdGhlXG4gKiBrZXJuZWwgZGlkIG5vdCBlbWl0IG9uZSBmb3IsIGFuZCByZS1zY2FuIGFzIHRoZSBwcm9zZSBtb3VudHMgb3Igc3dhcHMgb24gbmF2aWdhdGlvbi5cbiAqXG4gKiBSMy04NzIgKEFQUF9DVVNUT01JWkFUSU9OIMKnNC41KTogdGhlIHNjYW4gaXMgc2NvcGVkIHRvIHRoZSBFTlRSWSdzIG1hcmtlZCBib2R5XG4gKiAoYFtkYXRhLWVudHJ5PVwiPGVudHJ5S2V5PlwiXWAg4oCUIGVtaXR0ZWQgb24gYm90aCByZW5kZXIgcGF0aHMpLCBuZXZlciB0aGUgd2hvbGVcbiAqIGRvY3VtZW50OiBvbiBhIG11bHRpLWVudHJ5IHBhZ2UgdGhlIGZpcnN0IGAuZ3JvdmUtcHJvc2VgIGlzIHdoaWNoZXZlciBlbnRyeSBtb3VudGVkXG4gKiBmaXJzdCwgYW5kIGl0cyBoZWFkaW5ncyBhcmUgdGhlIHdyb25nIGVudHJ5J3MuIFVuc2NvcGVkIChubyBrZXksIG9yIG5vIG1hcmtlZCBib2R5XG4gKiBhbnl3aGVyZSkgZmFsbHMgYmFjayB0byB0aGUgZG9jdW1lbnQg4oCUIHRoZSBwcmUtbWFya2VyIGJlaGF2aW9yLCBmb3IgY29udGVudCB0aGF0XG4gKiBuZXZlciByZW5kZXJzIHRocm91Z2ggdGhlIG1hcmtlZCBwYXRocy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVzZUhlYWRpbmdzKGVudHJ5S2V5Pzogc3RyaW5nKTogSGVhZGluZ1tdIHtcbiAgY29uc3QgW2hlYWRzLCBzZXRIZWFkc10gPSB1c2VTdGF0ZTxIZWFkaW5nW10+KFtdKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9zZXQtc3RhdGUtaW4tZWZmZWN0XG4gICAgc2V0SGVhZHMoW10pO1xuICAgIC8vIFRoZSBzY2FuIHJvb3Q6IHRoaXMgZW50cnkncyBtYXJrZWQgYm9keSB3aGVuIG1hcmtlcnMgZXhpc3Q7IHRoZSBkb2N1bWVudCBvbmx5XG4gICAgLy8gd2hlbiBOTyBib2R5IGlzIG1hcmtlZCBhdCBhbGwgKHRoZSBwcmUtbWFya2VyIHdvcmxkKS4gQSBwYWdlIHdpdGggbWFya2VycyBidXRcbiAgICAvLyBub25lIGZvciB0aGlzIGtleSAodGhlIGJvZHkgaXMgc3RpbGwgY29tcGlsaW5nKSBzY2FucyBub3RoaW5nIOKAlCB0aGUgb2JzZXJ2ZXJcbiAgICAvLyB3YXRjaGVzIHRoZSBET0NVTUVOVCB1bnRpbCB0aGlzIGVudHJ5J3MgbWFya2VyIGxhbmRzLCB0aGVuIHJlLXNjb3BlcyAoYVxuICAgIC8vIGxhdGUtY29tbWl0dGluZyBlbnRyeSdzIFRvQyBtdXN0IG5vdCBzdGF5IGVtcHR5IGZvciB0aGUgbW91bnQncyBsaWZldGltZSkuXG4gICAgLy8gTk9URTogdGhlIG1hcmtlciBzaXRzIElOU0lERSBgLmdyb3ZlLXByb3NlYCAoYm90aCByZW5kZXIgcGF0aHMpLCBzbyB0aGVcbiAgICAvLyBzY29wZWQgcXVlcnkgcnVucyBvdmVyIHRoZSBtYXJrZXIncyBvd24gc3VidHJlZSDigJQgc2VhcmNoaW5nIHRoZSBtYXJrZXIgRk9SXG4gICAgLy8gJy5ncm92ZS1wcm9zZScgd291bGQgZmluZCBub3RoaW5nIChyZXZpZXcgcm91bmQgMSwgRy1DVVNULTIgcmVncmVzc2lvbikuXG4gICAgY29uc3QgbWFya2VkUm9vdCA9ICgpOiBIVE1MRWxlbWVudCB8IG51bGwgPT5cbiAgICAgIGVudHJ5S2V5ID09PSB1bmRlZmluZWRcbiAgICAgICAgPyBudWxsXG4gICAgICAgIDogQXJyYXkuZnJvbShkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsPEhUTUxFbGVtZW50PignW2RhdGEtZW50cnldJykpLmZpbmQoXG4gICAgICAgICAgICAobikgPT4gbi5nZXRBdHRyaWJ1dGUoJ2RhdGEtZW50cnknKSA9PT0gZW50cnlLZXksXG4gICAgICAgICAgKSA/PyBudWxsO1xuICAgIGNvbnN0IGFueU1hcmtlZCA9ICgpID0+IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJ1tkYXRhLWVudHJ5XScpLmxlbmd0aCA+IDA7XG4gICAgY29uc3Qgcm9vdCA9ICgpOiBQYXJlbnROb2RlIHwgbnVsbCA9PiB7XG4gICAgICBjb25zdCBtYXJrZWQgPSBtYXJrZWRSb290KCk7XG4gICAgICBpZiAobWFya2VkKSByZXR1cm4gbWFya2VkO1xuICAgICAgaWYgKGVudHJ5S2V5ID09PSB1bmRlZmluZWQpIHJldHVybiBkb2N1bWVudDtcbiAgICAgIHJldHVybiBhbnlNYXJrZWQoKSA/IG51bGwgOiBkb2N1bWVudDtcbiAgICB9O1xuICAgIGNvbnN0IHNjYW4gPSAoKSA9PiB7XG4gICAgICBjb25zdCByID0gcm9vdCgpO1xuICAgICAgLy8gU2NvcGVkOiB0aGUgbWFya2VyJ3Mgc3VidHJlZSBob2xkcyB0aGUgZW50cnkncyBoZWFkaW5ncy4gVW5zY29wZWQgKG5vXG4gICAgICAvLyBtYXJrZXJzIGFueXdoZXJlKTogdGhlIGRvY3VtZW50J3MgYC5ncm92ZS1wcm9zZWAsIGFzIGJlZm9yZS5cbiAgICAgIGNvbnN0IG5vZGVzID0gIXJcbiAgICAgICAgPyBbXVxuICAgICAgICA6IHIgPT09IGRvY3VtZW50XG4gICAgICAgICAgPyAoKCkgPT4ge1xuICAgICAgICAgICAgICBjb25zdCBwcm9zZSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJy5ncm92ZS1wcm9zZScpO1xuICAgICAgICAgICAgICByZXR1cm4gcHJvc2UgPyBBcnJheS5mcm9tKHByb3NlLnF1ZXJ5U2VsZWN0b3JBbGwoJ2gyLCBoMycpKSA6IFtdO1xuICAgICAgICAgICAgfSkoKVxuICAgICAgICAgIDogQXJyYXkuZnJvbShyLnF1ZXJ5U2VsZWN0b3JBbGwoJ2gyLCBoMycpKTtcbiAgICAgIGNvbnN0IGZvdW5kOiBIZWFkaW5nW10gPSBub2Rlcy5tYXAoKG4pID0+IHtcbiAgICAgICAgY29uc3QgdGV4dCA9IGhlYWRpbmdUZXh0KG4pO1xuICAgICAgICAvLyBQcmVmZXIgdGhlIGtlcm5lbC1lbWl0dGVkIGlkICjCpzE1LjUpOyBgaGVhZGluZ0lkYCByZXByb2R1Y2VzIHRoZSBzYW1lIGNhbm9uXG4gICAgICAgIC8vIChgQGltbWVkaWF0ZWx5LXJ1bi9tZHgtcGx1Z2luc2ApIGZvciBhIGhlYWRpbmcgdGhhdCBoYXMgbm9uZS5cbiAgICAgICAgY29uc3QgaWQgPSBuLmlkIHx8IGhlYWRpbmdJZCh0ZXh0KTtcbiAgICAgICAgbi5pZCA9IGlkO1xuICAgICAgICByZXR1cm4geyBpZCwgdGV4dCwgbGV2ZWw6IG4udGFnTmFtZSA9PT0gJ0gzJyA/IDMgOiAyIH07XG4gICAgICB9KTtcbiAgICAgIC8vIElkZW50aXR5LXN0YWJsZSB3aGVuIG5vdGhpbmcgY2hhbmdlZDogdGhpcyBydW5zIGZyb20gYSBNdXRhdGlvbk9ic2VydmVyLCBhbmQgYVxuICAgICAgLy8gZnJlc2ggYXJyYXkgZXZlcnkgbXV0YXRpb24gd291bGQgcmUtcnVuIGV2ZXJ5IGRvd25zdHJlYW0gZWZmZWN0ICh0aGUgc3B5LCB0aGVcbiAgICAgIC8vIHNjcm9sbCkgb24gZWFjaCBrZXlzdHJva2Ugb2YgYW4gZWRpdG9yLWRyaXZlbiByZS1yZW5kZXIuXG4gICAgICBzZXRIZWFkcygocHJldikgPT5cbiAgICAgICAgcHJldi5sZW5ndGggPT09IGZvdW5kLmxlbmd0aCAmJiBwcmV2LmV2ZXJ5KChoLCBpKSA9PiBoLmlkID09PSBmb3VuZFtpXS5pZCkgPyBwcmV2IDogZm91bmRcbiAgICAgICk7XG4gICAgfTtcbiAgICAvLyBPYnNlcnZlIHRoZSBTQ09QRUQgcm9vdCB3aGVuIGl0IGV4aXN0czsgd2hpbGUgb3VyIG1hcmtlciBpcyBhYnNlbnQgKHRoZVxuICAgIC8vIGJvZHkgc3RpbGwgY29tcGlsaW5nKSwgb2JzZXJ2ZSB0aGUgRE9DVU1FTlQgc28gdGhlIG1hcmtlcidzIGFycml2YWxcbiAgICAvLyB0cmlnZ2VycyB0aGUgcmVzY2FuIHRoYXQgcmUtc2NvcGVzIOKAlCB0aGVuIG1vdmUgdGhlIG9ic2VydmVyIG9udG8gdGhlXG4gICAgLy8gbWFya2VyIChhIHdob2xlLWRvY3VtZW50IHdhdGNoIHdvdWxkIHJlLXNjYW4gb24gZXZlcnkgbXV0YXRpb24gYW55d2hlcmUsXG4gICAgLy8gdGhlIGNodXJuIHRoZSBpZGVudGl0eSBndWFyZCBleGlzdHMgdG8gYWJzb3JiKS5cbiAgICBsZXQgb2JzZXJ2aW5nOiBQYXJlbnROb2RlIHwgbnVsbCA9IG51bGw7XG4gICAgY29uc3Qgb2JzID0gbmV3IE11dGF0aW9uT2JzZXJ2ZXIoKCkgPT4ge1xuICAgICAgY29uc3Qgd2FudGVkID0gcm9vdCgpID8/IGRvY3VtZW50O1xuICAgICAgaWYgKHdhbnRlZCAhPT0gb2JzZXJ2aW5nKSB7XG4gICAgICAgIG9icy5kaXNjb25uZWN0KCk7XG4gICAgICAgIG9icy5vYnNlcnZlKHdhbnRlZCwgeyBjaGlsZExpc3Q6IHRydWUsIHN1YnRyZWU6IHRydWUgfSk7XG4gICAgICAgIG9ic2VydmluZyA9IHdhbnRlZDtcbiAgICAgIH1cbiAgICAgIHNjYW4oKTtcbiAgICB9KTtcbiAgICBvYnNlcnZpbmcgPSByb290KCkgPz8gZG9jdW1lbnQ7XG4gICAgb2JzLm9ic2VydmUob2JzZXJ2aW5nLCB7IGNoaWxkTGlzdDogdHJ1ZSwgc3VidHJlZTogdHJ1ZSB9KTtcbiAgICBzY2FuKCk7XG4gICAgLy8gYDxJbmNsdWRlPmAgcmVzb2x2ZXMgYXN5bmNocm9ub3VzbHksIGFuZCB0aGUgb2JzZXJ2ZXIgb25seSBmaXJlcyBpZiBgLmdyb3ZlLXByb3NlYFxuICAgIC8vIGFscmVhZHkgZXhpc3RlZCDigJQgdGhlc2UgY2F0Y2ggdGhlIHdpbmRvdyB3aGVyZSBpdCBkaWQgbm90LlxuICAgIGNvbnN0IHRpbWVycyA9IFsxMjAsIDMwMCwgNjAwXS5tYXAoKGQpID0+IHNldFRpbWVvdXQoc2NhbiwgZCkpO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBvYnMuZGlzY29ubmVjdCgpO1xuICAgICAgdGltZXJzLmZvckVhY2goY2xlYXJUaW1lb3V0KTtcbiAgICB9O1xuICB9LCBbZW50cnlLZXldKTtcblxuICByZXR1cm4gaGVhZHM7XG59XG5cbi8qKiBXaGljaCBoZWFkaW5nIHRoZSByZWFkZXIgaXMgY3VycmVudGx5IGluIOKAlCBzY3JvbGwtc3BpZWQuIFIzLTg3Mjogc2NvcGVkIHRvIHRoZVxuICogIGVudHJ5J3MgbWFya2VkIGJvZHkgd2hlbiBhIGtleSBpcyBnaXZlbiDigJQgZHVwbGljYXRlIHNlY3Rpb24gaWRzIGFjcm9zcyBlbnRyaWVzIG9uXG4gKiAgb25lIHBhZ2UgYXJlIHRoZSBub3JtIChldmVyeSBzcGVjIG51bWJlcnMgZnJvbSAxKSwgYW5kIGBkb2N1bWVudC5nZXRFbGVtZW50QnlJZGBcbiAqICB3b3VsZCByZXR1cm4gdGhlIEZJUlNUIGVudHJ5J3MgaGVhZGluZywgc3B5aW5nIG9uIHRoZSB3cm9uZyBlbnRyeS4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VBY3RpdmVIZWFkaW5nKGhlYWRzOiBIZWFkaW5nW10sIGVudHJ5S2V5Pzogc3RyaW5nKTogc3RyaW5nIHtcbiAgY29uc3QgW2N1ciwgc2V0Q3VyXSA9IHVzZVN0YXRlPHN0cmluZz4oJycpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFoZWFkcy5sZW5ndGgpIHJldHVybjtcbiAgICBjb25zdCBzY29wZTogUGFyZW50Tm9kZSA9XG4gICAgICBlbnRyeUtleSA9PT0gdW5kZWZpbmVkXG4gICAgICAgID8gZG9jdW1lbnRcbiAgICAgICAgOiBBcnJheS5mcm9tKGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGw8SFRNTEVsZW1lbnQ+KCdbZGF0YS1lbnRyeV0nKSkuZmluZChcbiAgICAgICAgICAgIChuKSA9PiBuLmdldEF0dHJpYnV0ZSgnZGF0YS1lbnRyeScpID09PSBlbnRyeUtleSxcbiAgICAgICAgICApID8/IGRvY3VtZW50O1xuICAgIGNvbnN0IG9icyA9IG5ldyBJbnRlcnNlY3Rpb25PYnNlcnZlcihcbiAgICAgIChlbnRyaWVzKSA9PiB7XG4gICAgICAgIGNvbnN0IHZpc2libGUgPSBlbnRyaWVzLmZpbHRlcigoZSkgPT4gZS5pc0ludGVyc2VjdGluZyk7XG4gICAgICAgIGlmICh2aXNpYmxlLmxlbmd0aCkgc2V0Q3VyKCh2aXNpYmxlWzBdLnRhcmdldCBhcyBIVE1MRWxlbWVudCkuaWQpO1xuICAgICAgfSxcbiAgICAgIHsgcm9vdE1hcmdpbjogJy02NHB4IDBweCAtNzAlIDBweCcsIHRocmVzaG9sZDogMCB9XG4gICAgKTtcbiAgICBoZWFkcy5mb3JFYWNoKChoKSA9PiB7XG4gICAgICAvLyBmaW5kIHRoZSBlbGVtZW50IElOU0lERSB0aGUgc2NvcGUgKGEgaGVhZGluZyBpZCBpcyBvbmx5IHVuaXF1ZSBwZXIgZW50cnkpXG4gICAgICBjb25zdCBlbCA9IHNjb3BlID09PSBkb2N1bWVudCA/IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGguaWQpIDogc2NvcGUucXVlcnlTZWxlY3RvcihgIyR7Q1NTLmVzY2FwZShoLmlkKX1gKTtcbiAgICAgIGlmIChlbCkgb2JzLm9ic2VydmUoZWwpO1xuICAgIH0pO1xuICAgIHJldHVybiAoKSA9PiBvYnMuZGlzY29ubmVjdCgpO1xuICB9LCBbaGVhZHMsIGVudHJ5S2V5XSk7XG5cbiAgcmV0dXJuIGN1cjtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7OztBQVFBLElBQUFBLE1BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLEtBQUEsR0FBQUQsT0FBQTtBQVRBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQVdBO0FBQ0E7QUFDQTtBQUNBLFNBQVNFLFdBQVdBLENBQUNDLElBQWEsRUFBVTtFQUMxQyxNQUFNQyxNQUFNLEdBQUdELElBQUksQ0FBQ0UsYUFBYSxDQUFDLG9CQUFvQixDQUFDO0VBQ3ZELElBQUksQ0FBQ0QsTUFBTSxFQUFFLE9BQU8sQ0FBQ0QsSUFBSSxDQUFDRyxXQUFXLElBQUksRUFBRSxFQUFFQyxJQUFJLENBQUMsQ0FBQztFQUNuRCxPQUFPQyxLQUFLLENBQUNDLElBQUksQ0FBQ04sSUFBSSxDQUFDTyxVQUFVLENBQUMsQ0FDL0JDLE1BQU0sQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLEtBQUtSLE1BQU0sQ0FBQyxDQUMzQlMsR0FBRyxDQUFFRCxDQUFDLElBQUtBLENBQUMsQ0FBQ04sV0FBVyxJQUFJLEVBQUUsQ0FBQyxDQUMvQlEsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUNSUCxJQUFJLENBQUMsQ0FBQztBQUNYOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxTQUFTUSxXQUFXQSxDQUFDQyxRQUFpQixFQUFhO0VBQ3hELE1BQU0sQ0FBQ0MsS0FBSyxFQUFFQyxRQUFRLENBQUMsR0FBRyxJQUFBQyxlQUFRLEVBQVksRUFBRSxDQUFDO0VBRWpELElBQUFDLGdCQUFTLEVBQUMsTUFBTTtJQUNkO0lBQ0FGLFFBQVEsQ0FBQyxFQUFFLENBQUM7SUFDWjtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0EsTUFBTUcsVUFBVSxHQUFHQSxDQUFBLEtBQ2pCTCxRQUFRLEtBQUtNLFNBQVMsR0FDbEIsSUFBSSxHQUNKZCxLQUFLLENBQUNDLElBQUksQ0FBQ2MsUUFBUSxDQUFDQyxnQkFBZ0IsQ0FBYyxjQUFjLENBQUMsQ0FBQyxDQUFDQyxJQUFJLENBQ3BFQyxDQUFDLElBQUtBLENBQUMsQ0FBQ0MsWUFBWSxDQUFDLFlBQVksQ0FBQyxLQUFLWCxRQUMxQyxDQUFDLElBQUksSUFBSTtJQUNmLE1BQU1ZLFNBQVMsR0FBR0EsQ0FBQSxLQUFNTCxRQUFRLENBQUNDLGdCQUFnQixDQUFDLGNBQWMsQ0FBQyxDQUFDSyxNQUFNLEdBQUcsQ0FBQztJQUM1RSxNQUFNQyxJQUFJLEdBQUdBLENBQUEsS0FBeUI7TUFDcEMsTUFBTUMsTUFBTSxHQUFHVixVQUFVLENBQUMsQ0FBQztNQUMzQixJQUFJVSxNQUFNLEVBQUUsT0FBT0EsTUFBTTtNQUN6QixJQUFJZixRQUFRLEtBQUtNLFNBQVMsRUFBRSxPQUFPQyxRQUFRO01BQzNDLE9BQU9LLFNBQVMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxHQUFHTCxRQUFRO0lBQ3RDLENBQUM7SUFDRCxNQUFNUyxJQUFJLEdBQUdBLENBQUEsS0FBTTtNQUNqQixNQUFNQyxDQUFDLEdBQUdILElBQUksQ0FBQyxDQUFDO01BQ2hCO01BQ0E7TUFDQSxNQUFNSSxLQUFLLEdBQUcsQ0FBQ0QsQ0FBQyxHQUNaLEVBQUUsR0FDRkEsQ0FBQyxLQUFLVixRQUFRLEdBQ1osQ0FBQyxNQUFNO1FBQ0wsTUFBTVksS0FBSyxHQUFHWixRQUFRLENBQUNsQixhQUFhLENBQUMsY0FBYyxDQUFDO1FBQ3BELE9BQU84QixLQUFLLEdBQUczQixLQUFLLENBQUNDLElBQUksQ0FBQzBCLEtBQUssQ0FBQ1gsZ0JBQWdCLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBRyxFQUFFO01BQ2xFLENBQUMsRUFBRSxDQUFDLEdBQ0poQixLQUFLLENBQUNDLElBQUksQ0FBQ3dCLENBQUMsQ0FBQ1QsZ0JBQWdCLENBQUMsUUFBUSxDQUFDLENBQUM7TUFDOUMsTUFBTVksS0FBZ0IsR0FBR0YsS0FBSyxDQUFDckIsR0FBRyxDQUFFYSxDQUFDLElBQUs7UUFDeEMsTUFBTVcsSUFBSSxHQUFHbkMsV0FBVyxDQUFDd0IsQ0FBQyxDQUFDO1FBQzNCO1FBQ0E7UUFDQSxNQUFNWSxFQUFFLEdBQUdaLENBQUMsQ0FBQ1ksRUFBRSxJQUFJLElBQUFDLGVBQVMsRUFBQ0YsSUFBSSxDQUFDO1FBQ2xDWCxDQUFDLENBQUNZLEVBQUUsR0FBR0EsRUFBRTtRQUNULE9BQU87VUFBRUEsRUFBRTtVQUFFRCxJQUFJO1VBQUVHLEtBQUssRUFBRWQsQ0FBQyxDQUFDZSxPQUFPLEtBQUssSUFBSSxHQUFHLENBQUMsR0FBRztRQUFFLENBQUM7TUFDeEQsQ0FBQyxDQUFDO01BQ0Y7TUFDQTtNQUNBO01BQ0F2QixRQUFRLENBQUV3QixJQUFJLElBQ1pBLElBQUksQ0FBQ2IsTUFBTSxLQUFLTyxLQUFLLENBQUNQLE1BQU0sSUFBSWEsSUFBSSxDQUFDQyxLQUFLLENBQUMsQ0FBQ0MsQ0FBQyxFQUFFQyxDQUFDLEtBQUtELENBQUMsQ0FBQ04sRUFBRSxLQUFLRixLQUFLLENBQUNTLENBQUMsQ0FBQyxDQUFDUCxFQUFFLENBQUMsR0FBR0ksSUFBSSxHQUFHTixLQUN0RixDQUFDO0lBQ0gsQ0FBQztJQUNEO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQSxJQUFJVSxTQUE0QixHQUFHLElBQUk7SUFDdkMsTUFBTUMsR0FBRyxHQUFHLElBQUlDLGdCQUFnQixDQUFDLE1BQU07TUFDckMsTUFBTUMsTUFBTSxHQUFHbkIsSUFBSSxDQUFDLENBQUMsSUFBSVAsUUFBUTtNQUNqQyxJQUFJMEIsTUFBTSxLQUFLSCxTQUFTLEVBQUU7UUFDeEJDLEdBQUcsQ0FBQ0csVUFBVSxDQUFDLENBQUM7UUFDaEJILEdBQUcsQ0FBQ0ksT0FBTyxDQUFDRixNQUFNLEVBQUU7VUFBRUcsU0FBUyxFQUFFLElBQUk7VUFBRUMsT0FBTyxFQUFFO1FBQUssQ0FBQyxDQUFDO1FBQ3ZEUCxTQUFTLEdBQUdHLE1BQU07TUFDcEI7TUFDQWpCLElBQUksQ0FBQyxDQUFDO0lBQ1IsQ0FBQyxDQUFDO0lBQ0ZjLFNBQVMsR0FBR2hCLElBQUksQ0FBQyxDQUFDLElBQUlQLFFBQVE7SUFDOUJ3QixHQUFHLENBQUNJLE9BQU8sQ0FBQ0wsU0FBUyxFQUFFO01BQUVNLFNBQVMsRUFBRSxJQUFJO01BQUVDLE9BQU8sRUFBRTtJQUFLLENBQUMsQ0FBQztJQUMxRHJCLElBQUksQ0FBQyxDQUFDO0lBQ047SUFDQTtJQUNBLE1BQU1zQixNQUFNLEdBQUcsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDekMsR0FBRyxDQUFFMEMsQ0FBQyxJQUFLQyxVQUFVLENBQUN4QixJQUFJLEVBQUV1QixDQUFDLENBQUMsQ0FBQztJQUM5RCxPQUFPLE1BQU07TUFDWFIsR0FBRyxDQUFDRyxVQUFVLENBQUMsQ0FBQztNQUNoQkksTUFBTSxDQUFDRyxPQUFPLENBQUNDLFlBQVksQ0FBQztJQUM5QixDQUFDO0VBQ0gsQ0FBQyxFQUFFLENBQUMxQyxRQUFRLENBQUMsQ0FBQztFQUVkLE9BQU9DLEtBQUs7QUFDZDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVMwQyxnQkFBZ0JBLENBQUMxQyxLQUFnQixFQUFFRCxRQUFpQixFQUFVO0VBQzVFLE1BQU0sQ0FBQzRDLEdBQUcsRUFBRUMsTUFBTSxDQUFDLEdBQUcsSUFBQTFDLGVBQVEsRUFBUyxFQUFFLENBQUM7RUFFMUMsSUFBQUMsZ0JBQVMsRUFBQyxNQUFNO0lBQ2QsSUFBSSxDQUFDSCxLQUFLLENBQUNZLE1BQU0sRUFBRTtJQUNuQixNQUFNaUMsS0FBaUIsR0FDckI5QyxRQUFRLEtBQUtNLFNBQVMsR0FDbEJDLFFBQVEsR0FDUmYsS0FBSyxDQUFDQyxJQUFJLENBQUNjLFFBQVEsQ0FBQ0MsZ0JBQWdCLENBQWMsY0FBYyxDQUFDLENBQUMsQ0FBQ0MsSUFBSSxDQUNwRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUNDLFlBQVksQ0FBQyxZQUFZLENBQUMsS0FBS1gsUUFDMUMsQ0FBQyxJQUFJTyxRQUFRO0lBQ25CLE1BQU13QixHQUFHLEdBQUcsSUFBSWdCLG9CQUFvQixDQUNqQ0MsT0FBTyxJQUFLO01BQ1gsTUFBTUMsT0FBTyxHQUFHRCxPQUFPLENBQUNyRCxNQUFNLENBQUV1RCxDQUFDLElBQUtBLENBQUMsQ0FBQ0MsY0FBYyxDQUFDO01BQ3ZELElBQUlGLE9BQU8sQ0FBQ3BDLE1BQU0sRUFBRWdDLE1BQU0sQ0FBRUksT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDRyxNQUFNLENBQWlCOUIsRUFBRSxDQUFDO0lBQ25FLENBQUMsRUFDRDtNQUFFK0IsVUFBVSxFQUFFLG9CQUFvQjtNQUFFQyxTQUFTLEVBQUU7SUFBRSxDQUNuRCxDQUFDO0lBQ0RyRCxLQUFLLENBQUN3QyxPQUFPLENBQUViLENBQUMsSUFBSztNQUNuQjtNQUNBLE1BQU0yQixFQUFFLEdBQUdULEtBQUssS0FBS3ZDLFFBQVEsR0FBR0EsUUFBUSxDQUFDaUQsY0FBYyxDQUFDNUIsQ0FBQyxDQUFDTixFQUFFLENBQUMsR0FBR3dCLEtBQUssQ0FBQ3pELGFBQWEsQ0FBQyxJQUFJb0UsR0FBRyxDQUFDQyxNQUFNLENBQUM5QixDQUFDLENBQUNOLEVBQUUsQ0FBQyxFQUFFLENBQUM7TUFDM0csSUFBSWlDLEVBQUUsRUFBRXhCLEdBQUcsQ0FBQ0ksT0FBTyxDQUFDb0IsRUFBRSxDQUFDO0lBQ3pCLENBQUMsQ0FBQztJQUNGLE9BQU8sTUFBTXhCLEdBQUcsQ0FBQ0csVUFBVSxDQUFDLENBQUM7RUFDL0IsQ0FBQyxFQUFFLENBQUNqQyxLQUFLLEVBQUVELFFBQVEsQ0FBQyxDQUFDO0VBRXJCLE9BQU80QyxHQUFHO0FBQ1oiLCJpZ25vcmVMaXN0IjpbXX0=