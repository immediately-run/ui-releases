var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
var _vitest = require("vitest");
var _react = require("react");
var _client = require("react-dom/client");
var _useHeadings = require("./useHeadings");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // @vitest-environment jsdom
// R3-872 (APP_CUSTOMIZATION §4.5) — the scoped branch of useHeadings, the one
// that shipped broken at the first review (the marker sits INSIDE .grove-prose,
// so a scoped `.grove-prose` lookup found nothing). These cases plant MARKED
// bodies — the shape the stock DOM always has — and assert the scoped read.
(0, _vitest.beforeAll)(() => {
  Object.defineProperty(window, 'matchMedia', {
    writable: true,
    value: q => ({
      matches: false,
      media: q,
      addEventListener: () => {},
      removeEventListener: () => {},
      addListener: () => {},
      removeListener: () => {},
      dispatchEvent: () => false,
      onchange: null
    })
  });
});
const A = '/app/content/specs/a.mdx';
const B = '/app/content/specs/b.mdx';

/** Two marked bodies, each with its own headings — the multi-entry page shape
 *  (both paths carry the marker since R3-872, and the safe path's marker wraps
 *  the body inside .grove-prose, as EntryBody renders it). */
function plantTwoBodies() {
  // A carries one ID-LESS heading (the kernel assigns none sometimes) — B's scan
  // must never write an id onto it (the side effect is scoped, not just the read).
  document.body.innerHTML = `
    <div class="grove-prose"><div data-entry="${A}"><h2 id="sec-1">A one</h2><h2>A two (no id)</h2></div></div>
    <div class="grove-prose"><div data-entry="${B}"><h2 id="sec-1">B one</h2><h3 id="sec-2-1">B two-one</h3></div></div>
  `;
}
function Probe({
  entryKey,
  seen
}) {
  _s();
  const heads = (0, _useHeadings.useHeadings)(entryKey);
  seen(heads);
  return null;
}
_s(Probe, "1CdGk/mya62AIZ8o31ELURBt9Vo=", false, function () {
  return [_useHeadings.useHeadings];
});
_c = Probe;
(0, _vitest.describe)('useHeadings — entry-scoped (R3-872)', () => {
  (0, _vitest.it)("reads only the named entry's headings when both bodies are marked", async () => {
    plantTwoBodies();
    let latest = [];
    const container = document.createElement('div');
    document.body.appendChild(container);
    const root = (0, _client.createRoot)(container);
    await (0, _react.act)(async () => {
      root.render(/*#__PURE__*/(0, _jsxRuntime.jsx)(Probe, {
        entryKey: B,
        seen: h => latest = h
      }));
    });
    (0, _vitest.expect)(latest.map(h => h.id)).toEqual(['sec-1', 'sec-2-1']);
    // the OTHER entry's id-less heading stays id-less — the scan's id-assignment
    // side effect is scoped, not just the read
    (0, _vitest.expect)(document.querySelector(`[data-entry="${A}"] h2:nth-of-type(2)`)?.id ?? '').toBe('');
    await (0, _react.act)(async () => root.unmount());
    container.remove();
  });
  (0, _vitest.it)('a late-committing marked body is found by the document observer (no empty ToC for life)', async () => {
    document.body.innerHTML = '';
    let latest = [];
    const container = document.createElement('div');
    document.body.appendChild(container);
    const root = (0, _client.createRoot)(container);
    await (0, _react.act)(async () => {
      root.render(/*#__PURE__*/(0, _jsxRuntime.jsx)(Probe, {
        entryKey: B,
        seen: h => latest = h
      }));
    });
    (0, _vitest.expect)(latest).toEqual([]); // no marker yet — nothing found, not a wrong read
    // the body lands late (the compile window)
    await (0, _react.act)(async () => {
      plantTwoBodies();
    });
    // the observer's mutation callback is async — flush it
    await (0, _react.act)(async () => {
      await new Promise(r => setTimeout(r, 20));
    });
    (0, _vitest.expect)(latest.map(h => h.id)).toEqual(['sec-1', 'sec-2-1']);
    await (0, _react.act)(async () => root.unmount());
    container.remove();
  });
  (0, _vitest.it)('no marked bodies anywhere → the document fallback (the pre-marker world)', async () => {
    document.body.innerHTML = '<div class="grove-prose"><h2 id="sec-1">Only one</h2></div>';
    let latest = [];
    const container = document.createElement('div');
    document.body.appendChild(container);
    const root = (0, _client.createRoot)(container);
    await (0, _react.act)(async () => {
      root.render(/*#__PURE__*/(0, _jsxRuntime.jsx)(Probe, {
        entryKey: B,
        seen: h => latest = h
      }));
    });
    (0, _vitest.expect)(latest.map(h => h.id)).toEqual(['sec-1']);
    await (0, _react.act)(async () => root.unmount());
    container.remove();
  });
});
var _c;
$RefreshReg$(_c, "Probe");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZXN0IiwicmVxdWlyZSIsIl9yZWFjdCIsIl9jbGllbnQiLCJfdXNlSGVhZGluZ3MiLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiYmVmb3JlQWxsIiwiT2JqZWN0IiwiZGVmaW5lUHJvcGVydHkiLCJ3aW5kb3ciLCJ3cml0YWJsZSIsInZhbHVlIiwicSIsIm1hdGNoZXMiLCJtZWRpYSIsImFkZEV2ZW50TGlzdGVuZXIiLCJyZW1vdmVFdmVudExpc3RlbmVyIiwiYWRkTGlzdGVuZXIiLCJyZW1vdmVMaXN0ZW5lciIsImRpc3BhdGNoRXZlbnQiLCJvbmNoYW5nZSIsIkEiLCJCIiwicGxhbnRUd29Cb2RpZXMiLCJkb2N1bWVudCIsImJvZHkiLCJpbm5lckhUTUwiLCJQcm9iZSIsImVudHJ5S2V5Iiwic2VlbiIsImhlYWRzIiwidXNlSGVhZGluZ3MiLCJfYyIsImRlc2NyaWJlIiwiaXQiLCJsYXRlc3QiLCJjb250YWluZXIiLCJjcmVhdGVFbGVtZW50IiwiYXBwZW5kQ2hpbGQiLCJyb290IiwiY3JlYXRlUm9vdCIsImFjdCIsInJlbmRlciIsImpzeCIsImgiLCJleHBlY3QiLCJtYXAiLCJpZCIsInRvRXF1YWwiLCJxdWVyeVNlbGVjdG9yIiwidG9CZSIsInVubW91bnQiLCJyZW1vdmUiLCJQcm9taXNlIiwiciIsInNldFRpbWVvdXQiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJ1c2VIZWFkaW5ncy50ZXN0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBAdml0ZXN0LWVudmlyb25tZW50IGpzZG9tXG4vLyBSMy04NzIgKEFQUF9DVVNUT01JWkFUSU9OIMKnNC41KSDigJQgdGhlIHNjb3BlZCBicmFuY2ggb2YgdXNlSGVhZGluZ3MsIHRoZSBvbmVcbi8vIHRoYXQgc2hpcHBlZCBicm9rZW4gYXQgdGhlIGZpcnN0IHJldmlldyAodGhlIG1hcmtlciBzaXRzIElOU0lERSAuZ3JvdmUtcHJvc2UsXG4vLyBzbyBhIHNjb3BlZCBgLmdyb3ZlLXByb3NlYCBsb29rdXAgZm91bmQgbm90aGluZykuIFRoZXNlIGNhc2VzIHBsYW50IE1BUktFRFxuLy8gYm9kaWVzIOKAlCB0aGUgc2hhcGUgdGhlIHN0b2NrIERPTSBhbHdheXMgaGFzIOKAlCBhbmQgYXNzZXJ0IHRoZSBzY29wZWQgcmVhZC5cbmltcG9ydCB7IGRlc2NyaWJlLCBpdCwgZXhwZWN0LCBiZWZvcmVBbGwgfSBmcm9tICd2aXRlc3QnO1xuaW1wb3J0IHsgYWN0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgY3JlYXRlUm9vdCB9IGZyb20gJ3JlYWN0LWRvbS9jbGllbnQnO1xuaW1wb3J0IHsgdXNlSGVhZGluZ3MgfSBmcm9tICcuL3VzZUhlYWRpbmdzJztcblxuYmVmb3JlQWxsKCgpID0+IHtcbiAgT2JqZWN0LmRlZmluZVByb3BlcnR5KHdpbmRvdywgJ21hdGNoTWVkaWEnLCB7XG4gICAgd3JpdGFibGU6IHRydWUsXG4gICAgdmFsdWU6IChxOiBzdHJpbmcpID0+ICh7IG1hdGNoZXM6IGZhbHNlLCBtZWRpYTogcSwgYWRkRXZlbnRMaXN0ZW5lcjogKCkgPT4ge30sIHJlbW92ZUV2ZW50TGlzdGVuZXI6ICgpID0+IHt9LCBhZGRMaXN0ZW5lcjogKCkgPT4ge30sIHJlbW92ZUxpc3RlbmVyOiAoKSA9PiB7fSwgZGlzcGF0Y2hFdmVudDogKCkgPT4gZmFsc2UsIG9uY2hhbmdlOiBudWxsIH0pLFxuICB9KTtcbn0pO1xuXG5jb25zdCBBID0gJy9hcHAvY29udGVudC9zcGVjcy9hLm1keCc7XG5jb25zdCBCID0gJy9hcHAvY29udGVudC9zcGVjcy9iLm1keCc7XG5cbi8qKiBUd28gbWFya2VkIGJvZGllcywgZWFjaCB3aXRoIGl0cyBvd24gaGVhZGluZ3Mg4oCUIHRoZSBtdWx0aS1lbnRyeSBwYWdlIHNoYXBlXG4gKiAgKGJvdGggcGF0aHMgY2FycnkgdGhlIG1hcmtlciBzaW5jZSBSMy04NzIsIGFuZCB0aGUgc2FmZSBwYXRoJ3MgbWFya2VyIHdyYXBzXG4gKiAgdGhlIGJvZHkgaW5zaWRlIC5ncm92ZS1wcm9zZSwgYXMgRW50cnlCb2R5IHJlbmRlcnMgaXQpLiAqL1xuZnVuY3Rpb24gcGxhbnRUd29Cb2RpZXMoKSB7XG4gIC8vIEEgY2FycmllcyBvbmUgSUQtTEVTUyBoZWFkaW5nICh0aGUga2VybmVsIGFzc2lnbnMgbm9uZSBzb21ldGltZXMpIOKAlCBCJ3Mgc2NhblxuICAvLyBtdXN0IG5ldmVyIHdyaXRlIGFuIGlkIG9udG8gaXQgKHRoZSBzaWRlIGVmZmVjdCBpcyBzY29wZWQsIG5vdCBqdXN0IHRoZSByZWFkKS5cbiAgZG9jdW1lbnQuYm9keS5pbm5lckhUTUwgPSBgXG4gICAgPGRpdiBjbGFzcz1cImdyb3ZlLXByb3NlXCI+PGRpdiBkYXRhLWVudHJ5PVwiJHtBfVwiPjxoMiBpZD1cInNlYy0xXCI+QSBvbmU8L2gyPjxoMj5BIHR3byAobm8gaWQpPC9oMj48L2Rpdj48L2Rpdj5cbiAgICA8ZGl2IGNsYXNzPVwiZ3JvdmUtcHJvc2VcIj48ZGl2IGRhdGEtZW50cnk9XCIke0J9XCI+PGgyIGlkPVwic2VjLTFcIj5CIG9uZTwvaDI+PGgzIGlkPVwic2VjLTItMVwiPkIgdHdvLW9uZTwvaDM+PC9kaXY+PC9kaXY+XG4gIGA7XG59XG5cbmZ1bmN0aW9uIFByb2JlKHsgZW50cnlLZXksIHNlZW4gfTogeyBlbnRyeUtleTogc3RyaW5nOyBzZWVuOiAoaDogeyBpZDogc3RyaW5nIH1bXSkgPT4gdm9pZCB9KSB7XG4gIGNvbnN0IGhlYWRzID0gdXNlSGVhZGluZ3MoZW50cnlLZXkpO1xuICBzZWVuKGhlYWRzKTtcbiAgcmV0dXJuIG51bGw7XG59XG5cbmRlc2NyaWJlKCd1c2VIZWFkaW5ncyDigJQgZW50cnktc2NvcGVkIChSMy04NzIpJywgKCkgPT4ge1xuICBpdChcInJlYWRzIG9ubHkgdGhlIG5hbWVkIGVudHJ5J3MgaGVhZGluZ3Mgd2hlbiBib3RoIGJvZGllcyBhcmUgbWFya2VkXCIsIGFzeW5jICgpID0+IHtcbiAgICBwbGFudFR3b0JvZGllcygpO1xuICAgIGxldCBsYXRlc3Q6IHsgaWQ6IHN0cmluZyB9W10gPSBbXTtcbiAgICBjb25zdCBjb250YWluZXIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGNvbnRhaW5lcik7XG4gICAgY29uc3Qgcm9vdCA9IGNyZWF0ZVJvb3QoY29udGFpbmVyKTtcbiAgICBhd2FpdCBhY3QoYXN5bmMgKCkgPT4ge1xuICAgICAgcm9vdC5yZW5kZXIoPFByb2JlIGVudHJ5S2V5PXtCfSBzZWVuPXsoaCkgPT4gKGxhdGVzdCA9IGgpfSAvPik7XG4gICAgfSk7XG4gICAgZXhwZWN0KGxhdGVzdC5tYXAoKGgpID0+IGguaWQpKS50b0VxdWFsKFsnc2VjLTEnLCAnc2VjLTItMSddKTtcbiAgICAvLyB0aGUgT1RIRVIgZW50cnkncyBpZC1sZXNzIGhlYWRpbmcgc3RheXMgaWQtbGVzcyDigJQgdGhlIHNjYW4ncyBpZC1hc3NpZ25tZW50XG4gICAgLy8gc2lkZSBlZmZlY3QgaXMgc2NvcGVkLCBub3QganVzdCB0aGUgcmVhZFxuICAgIGV4cGVjdChkb2N1bWVudC5xdWVyeVNlbGVjdG9yKGBbZGF0YS1lbnRyeT1cIiR7QX1cIl0gaDI6bnRoLW9mLXR5cGUoMilgKT8uaWQgPz8gJycpLnRvQmUoJycpO1xuICAgIGF3YWl0IGFjdChhc3luYyAoKSA9PiByb290LnVubW91bnQoKSk7XG4gICAgY29udGFpbmVyLnJlbW92ZSgpO1xuICB9KTtcblxuICBpdCgnYSBsYXRlLWNvbW1pdHRpbmcgbWFya2VkIGJvZHkgaXMgZm91bmQgYnkgdGhlIGRvY3VtZW50IG9ic2VydmVyIChubyBlbXB0eSBUb0MgZm9yIGxpZmUpJywgYXN5bmMgKCkgPT4ge1xuICAgIGRvY3VtZW50LmJvZHkuaW5uZXJIVE1MID0gJyc7XG4gICAgbGV0IGxhdGVzdDogeyBpZDogc3RyaW5nIH1bXSA9IFtdO1xuICAgIGNvbnN0IGNvbnRhaW5lciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoY29udGFpbmVyKTtcbiAgICBjb25zdCByb290ID0gY3JlYXRlUm9vdChjb250YWluZXIpO1xuICAgIGF3YWl0IGFjdChhc3luYyAoKSA9PiB7XG4gICAgICByb290LnJlbmRlcig8UHJvYmUgZW50cnlLZXk9e0J9IHNlZW49eyhoKSA9PiAobGF0ZXN0ID0gaCl9IC8+KTtcbiAgICB9KTtcbiAgICBleHBlY3QobGF0ZXN0KS50b0VxdWFsKFtdKTsgLy8gbm8gbWFya2VyIHlldCDigJQgbm90aGluZyBmb3VuZCwgbm90IGEgd3JvbmcgcmVhZFxuICAgIC8vIHRoZSBib2R5IGxhbmRzIGxhdGUgKHRoZSBjb21waWxlIHdpbmRvdylcbiAgICBhd2FpdCBhY3QoYXN5bmMgKCkgPT4ge1xuICAgICAgcGxhbnRUd29Cb2RpZXMoKTtcbiAgICB9KTtcbiAgICAvLyB0aGUgb2JzZXJ2ZXIncyBtdXRhdGlvbiBjYWxsYmFjayBpcyBhc3luYyDigJQgZmx1c2ggaXRcbiAgICBhd2FpdCBhY3QoYXN5bmMgKCkgPT4ge1xuICAgICAgYXdhaXQgbmV3IFByb21pc2UoKHIpID0+IHNldFRpbWVvdXQociwgMjApKTtcbiAgICB9KTtcbiAgICBleHBlY3QobGF0ZXN0Lm1hcCgoaCkgPT4gaC5pZCkpLnRvRXF1YWwoWydzZWMtMScsICdzZWMtMi0xJ10pO1xuICAgIGF3YWl0IGFjdChhc3luYyAoKSA9PiByb290LnVubW91bnQoKSk7XG4gICAgY29udGFpbmVyLnJlbW92ZSgpO1xuICB9KTtcblxuICBpdCgnbm8gbWFya2VkIGJvZGllcyBhbnl3aGVyZSDihpIgdGhlIGRvY3VtZW50IGZhbGxiYWNrICh0aGUgcHJlLW1hcmtlciB3b3JsZCknLCBhc3luYyAoKSA9PiB7XG4gICAgZG9jdW1lbnQuYm9keS5pbm5lckhUTUwgPSAnPGRpdiBjbGFzcz1cImdyb3ZlLXByb3NlXCI+PGgyIGlkPVwic2VjLTFcIj5Pbmx5IG9uZTwvaDI+PC9kaXY+JztcbiAgICBsZXQgbGF0ZXN0OiB7IGlkOiBzdHJpbmcgfVtdID0gW107XG4gICAgY29uc3QgY29udGFpbmVyID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChjb250YWluZXIpO1xuICAgIGNvbnN0IHJvb3QgPSBjcmVhdGVSb290KGNvbnRhaW5lcik7XG4gICAgYXdhaXQgYWN0KGFzeW5jICgpID0+IHtcbiAgICAgIHJvb3QucmVuZGVyKDxQcm9iZSBlbnRyeUtleT17Qn0gc2Vlbj17KGgpID0+IChsYXRlc3QgPSBoKX0gLz4pO1xuICAgIH0pO1xuICAgIGV4cGVjdChsYXRlc3QubWFwKChoKSA9PiBoLmlkKSkudG9FcXVhbChbJ3NlYy0xJ10pO1xuICAgIGF3YWl0IGFjdChhc3luYyAoKSA9PiByb290LnVubW91bnQoKSk7XG4gICAgY29udGFpbmVyLnJlbW92ZSgpO1xuICB9KTtcbn0pO1xuIl0sIm1hcHBpbmdzIjoiOzs7O0FBS0EsSUFBQUEsT0FBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsTUFBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsT0FBQSxHQUFBRixPQUFBO0FBQ0EsSUFBQUcsWUFBQSxHQUFBSCxPQUFBO0FBQTRDLElBQUFJLFdBQUEsR0FBQUosT0FBQTtBQUFBLElBQUFLLEVBQUEsR0FBQUMsWUFBQSxJQVI1QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTUEsSUFBQUMsaUJBQVMsRUFBQyxNQUFNO0VBQ2RDLE1BQU0sQ0FBQ0MsY0FBYyxDQUFDQyxNQUFNLEVBQUUsWUFBWSxFQUFFO0lBQzFDQyxRQUFRLEVBQUUsSUFBSTtJQUNkQyxLQUFLLEVBQUdDLENBQVMsS0FBTTtNQUFFQyxPQUFPLEVBQUUsS0FBSztNQUFFQyxLQUFLLEVBQUVGLENBQUM7TUFBRUcsZ0JBQWdCLEVBQUVBLENBQUEsS0FBTSxDQUFDLENBQUM7TUFBRUMsbUJBQW1CLEVBQUVBLENBQUEsS0FBTSxDQUFDLENBQUM7TUFBRUMsV0FBVyxFQUFFQSxDQUFBLEtBQU0sQ0FBQyxDQUFDO01BQUVDLGNBQWMsRUFBRUEsQ0FBQSxLQUFNLENBQUMsQ0FBQztNQUFFQyxhQUFhLEVBQUVBLENBQUEsS0FBTSxLQUFLO01BQUVDLFFBQVEsRUFBRTtJQUFLLENBQUM7RUFDN00sQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDO0FBRUYsTUFBTUMsQ0FBQyxHQUFHLDBCQUEwQjtBQUNwQyxNQUFNQyxDQUFDLEdBQUcsMEJBQTBCOztBQUVwQztBQUNBO0FBQ0E7QUFDQSxTQUFTQyxjQUFjQSxDQUFBLEVBQUc7RUFDeEI7RUFDQTtFQUNBQyxRQUFRLENBQUNDLElBQUksQ0FBQ0MsU0FBUyxHQUFHO0FBQzVCLGdEQUFnREwsQ0FBQztBQUNqRCxnREFBZ0RDLENBQUM7QUFDakQsR0FBRztBQUNIO0FBRUEsU0FBU0ssS0FBS0EsQ0FBQztFQUFFQyxRQUFRO0VBQUVDO0FBQWdFLENBQUMsRUFBRTtFQUFBekIsRUFBQTtFQUM1RixNQUFNMEIsS0FBSyxHQUFHLElBQUFDLHdCQUFXLEVBQUNILFFBQVEsQ0FBQztFQUNuQ0MsSUFBSSxDQUFDQyxLQUFLLENBQUM7RUFDWCxPQUFPLElBQUk7QUFDYjtBQUFDMUIsRUFBQSxDQUpRdUIsS0FBSztFQUFBLFFBQ0VJLHdCQUFXO0FBQUE7QUFBQUMsRUFBQSxHQURsQkwsS0FBSztBQU1kLElBQUFNLGdCQUFRLEVBQUMscUNBQXFDLEVBQUUsTUFBTTtFQUNwRCxJQUFBQyxVQUFFLEVBQUMsbUVBQW1FLEVBQUUsWUFBWTtJQUNsRlgsY0FBYyxDQUFDLENBQUM7SUFDaEIsSUFBSVksTUFBd0IsR0FBRyxFQUFFO0lBQ2pDLE1BQU1DLFNBQVMsR0FBR1osUUFBUSxDQUFDYSxhQUFhLENBQUMsS0FBSyxDQUFDO0lBQy9DYixRQUFRLENBQUNDLElBQUksQ0FBQ2EsV0FBVyxDQUFDRixTQUFTLENBQUM7SUFDcEMsTUFBTUcsSUFBSSxHQUFHLElBQUFDLGtCQUFVLEVBQUNKLFNBQVMsQ0FBQztJQUNsQyxNQUFNLElBQUFLLFVBQUcsRUFBQyxZQUFZO01BQ3BCRixJQUFJLENBQUNHLE1BQU0sY0FBQyxJQUFBdkMsV0FBQSxDQUFBd0MsR0FBQSxFQUFDaEIsS0FBSztRQUFDQyxRQUFRLEVBQUVOLENBQUU7UUFBQ08sSUFBSSxFQUFHZSxDQUFDLElBQU1ULE1BQU0sR0FBR1M7TUFBRyxDQUFFLENBQUMsQ0FBQztJQUNoRSxDQUFDLENBQUM7SUFDRixJQUFBQyxjQUFNLEVBQUNWLE1BQU0sQ0FBQ1csR0FBRyxDQUFFRixDQUFDLElBQUtBLENBQUMsQ0FBQ0csRUFBRSxDQUFDLENBQUMsQ0FBQ0MsT0FBTyxDQUFDLENBQUMsT0FBTyxFQUFFLFNBQVMsQ0FBQyxDQUFDO0lBQzdEO0lBQ0E7SUFDQSxJQUFBSCxjQUFNLEVBQUNyQixRQUFRLENBQUN5QixhQUFhLENBQUMsZ0JBQWdCNUIsQ0FBQyxzQkFBc0IsQ0FBQyxFQUFFMEIsRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDRyxJQUFJLENBQUMsRUFBRSxDQUFDO0lBQzFGLE1BQU0sSUFBQVQsVUFBRyxFQUFDLFlBQVlGLElBQUksQ0FBQ1ksT0FBTyxDQUFDLENBQUMsQ0FBQztJQUNyQ2YsU0FBUyxDQUFDZ0IsTUFBTSxDQUFDLENBQUM7RUFDcEIsQ0FBQyxDQUFDO0VBRUYsSUFBQWxCLFVBQUUsRUFBQyx5RkFBeUYsRUFBRSxZQUFZO0lBQ3hHVixRQUFRLENBQUNDLElBQUksQ0FBQ0MsU0FBUyxHQUFHLEVBQUU7SUFDNUIsSUFBSVMsTUFBd0IsR0FBRyxFQUFFO0lBQ2pDLE1BQU1DLFNBQVMsR0FBR1osUUFBUSxDQUFDYSxhQUFhLENBQUMsS0FBSyxDQUFDO0lBQy9DYixRQUFRLENBQUNDLElBQUksQ0FBQ2EsV0FBVyxDQUFDRixTQUFTLENBQUM7SUFDcEMsTUFBTUcsSUFBSSxHQUFHLElBQUFDLGtCQUFVLEVBQUNKLFNBQVMsQ0FBQztJQUNsQyxNQUFNLElBQUFLLFVBQUcsRUFBQyxZQUFZO01BQ3BCRixJQUFJLENBQUNHLE1BQU0sY0FBQyxJQUFBdkMsV0FBQSxDQUFBd0MsR0FBQSxFQUFDaEIsS0FBSztRQUFDQyxRQUFRLEVBQUVOLENBQUU7UUFBQ08sSUFBSSxFQUFHZSxDQUFDLElBQU1ULE1BQU0sR0FBR1M7TUFBRyxDQUFFLENBQUMsQ0FBQztJQUNoRSxDQUFDLENBQUM7SUFDRixJQUFBQyxjQUFNLEVBQUNWLE1BQU0sQ0FBQyxDQUFDYSxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztJQUM1QjtJQUNBLE1BQU0sSUFBQVAsVUFBRyxFQUFDLFlBQVk7TUFDcEJsQixjQUFjLENBQUMsQ0FBQztJQUNsQixDQUFDLENBQUM7SUFDRjtJQUNBLE1BQU0sSUFBQWtCLFVBQUcsRUFBQyxZQUFZO01BQ3BCLE1BQU0sSUFBSVksT0FBTyxDQUFFQyxDQUFDLElBQUtDLFVBQVUsQ0FBQ0QsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0lBQzdDLENBQUMsQ0FBQztJQUNGLElBQUFULGNBQU0sRUFBQ1YsTUFBTSxDQUFDVyxHQUFHLENBQUVGLENBQUMsSUFBS0EsQ0FBQyxDQUFDRyxFQUFFLENBQUMsQ0FBQyxDQUFDQyxPQUFPLENBQUMsQ0FBQyxPQUFPLEVBQUUsU0FBUyxDQUFDLENBQUM7SUFDN0QsTUFBTSxJQUFBUCxVQUFHLEVBQUMsWUFBWUYsSUFBSSxDQUFDWSxPQUFPLENBQUMsQ0FBQyxDQUFDO0lBQ3JDZixTQUFTLENBQUNnQixNQUFNLENBQUMsQ0FBQztFQUNwQixDQUFDLENBQUM7RUFFRixJQUFBbEIsVUFBRSxFQUFDLDBFQUEwRSxFQUFFLFlBQVk7SUFDekZWLFFBQVEsQ0FBQ0MsSUFBSSxDQUFDQyxTQUFTLEdBQUcsNkRBQTZEO0lBQ3ZGLElBQUlTLE1BQXdCLEdBQUcsRUFBRTtJQUNqQyxNQUFNQyxTQUFTLEdBQUdaLFFBQVEsQ0FBQ2EsYUFBYSxDQUFDLEtBQUssQ0FBQztJQUMvQ2IsUUFBUSxDQUFDQyxJQUFJLENBQUNhLFdBQVcsQ0FBQ0YsU0FBUyxDQUFDO0lBQ3BDLE1BQU1HLElBQUksR0FBRyxJQUFBQyxrQkFBVSxFQUFDSixTQUFTLENBQUM7SUFDbEMsTUFBTSxJQUFBSyxVQUFHLEVBQUMsWUFBWTtNQUNwQkYsSUFBSSxDQUFDRyxNQUFNLGNBQUMsSUFBQXZDLFdBQUEsQ0FBQXdDLEdBQUEsRUFBQ2hCLEtBQUs7UUFBQ0MsUUFBUSxFQUFFTixDQUFFO1FBQUNPLElBQUksRUFBR2UsQ0FBQyxJQUFNVCxNQUFNLEdBQUdTO01BQUcsQ0FBRSxDQUFDLENBQUM7SUFDaEUsQ0FBQyxDQUFDO0lBQ0YsSUFBQUMsY0FBTSxFQUFDVixNQUFNLENBQUNXLEdBQUcsQ0FBRUYsQ0FBQyxJQUFLQSxDQUFDLENBQUNHLEVBQUUsQ0FBQyxDQUFDLENBQUNDLE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQ2xELE1BQU0sSUFBQVAsVUFBRyxFQUFDLFlBQVlGLElBQUksQ0FBQ1ksT0FBTyxDQUFDLENBQUMsQ0FBQztJQUNyQ2YsU0FBUyxDQUFDZ0IsTUFBTSxDQUFDLENBQUM7RUFDcEIsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDO0FBQUMsSUFBQXBCLEVBQUE7QUFBQXdCLFlBQUEsQ0FBQXhCLEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}