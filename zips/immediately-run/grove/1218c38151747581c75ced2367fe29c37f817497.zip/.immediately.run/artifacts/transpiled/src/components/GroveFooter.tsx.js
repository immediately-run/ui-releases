var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = GroveFooter;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
var _sdk = require("@immediately-run/sdk");
var _shell = require("../lib/shell");
var _useFollowLink = require("../hooks/useFollowLink");
var _navigationPolicy = require("../lib/navigationPolicy");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // `<GroveFooter/>` — the site footer. Import-free in MDX; reads the nav items from
// the shell context so a layout just places `<GroveFooter/>`.
function GroveFooter() {
  _s();
  const {
    navItems,
    entryKey
  } = (0, _shell.useShell)();
  const follow = (0, _useFollowLink.useFollowLink)();
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("footer", {
    className: "grove-footer",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "grove-footer__links",
      children: navItems.slice(0, 4).map(n => /*#__PURE__*/(0, _jsxRuntime.jsx)(_sdk.Link, {
        href: n.href,
        onClick: (0, _navigationPolicy.followLinkOnClick)(follow, {
          key: n.key,
          href: n.href,
          from: entryKey
        }),
        children: n.label
      }, n.key))
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "grove-footer__meta",
      children: "built with grove"
    })]
  });
}
_s(GroveFooter, "qqrtPHwsBB9DT89tMeoCt4LOKG0=", false, function () {
  return [_shell.useShell, _useFollowLink.useFollowLink];
});
_c = GroveFooter;
var _c;
$RefreshReg$(_c, "GroveFooter");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfc2RrIiwicmVxdWlyZSIsIl9zaGVsbCIsIl91c2VGb2xsb3dMaW5rIiwiX25hdmlnYXRpb25Qb2xpY3kiLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiR3JvdmVGb290ZXIiLCJuYXZJdGVtcyIsImVudHJ5S2V5IiwidXNlU2hlbGwiLCJmb2xsb3ciLCJ1c2VGb2xsb3dMaW5rIiwianN4cyIsImNsYXNzTmFtZSIsImNoaWxkcmVuIiwianN4Iiwic2xpY2UiLCJtYXAiLCJuIiwiTGluayIsImhyZWYiLCJvbkNsaWNrIiwiZm9sbG93TGlua09uQ2xpY2siLCJrZXkiLCJmcm9tIiwibGFiZWwiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkdyb3ZlRm9vdGVyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBMaW5rIH0gZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9zZGsnO1xuaW1wb3J0IHsgdXNlU2hlbGwgfSBmcm9tICcuLi9saWIvc2hlbGwnO1xuaW1wb3J0IHsgdXNlRm9sbG93TGluayB9IGZyb20gJy4uL2hvb2tzL3VzZUZvbGxvd0xpbmsnO1xuaW1wb3J0IHsgZm9sbG93TGlua09uQ2xpY2sgfSBmcm9tICcuLi9saWIvbmF2aWdhdGlvblBvbGljeSc7XG5cbi8vIGA8R3JvdmVGb290ZXIvPmAg4oCUIHRoZSBzaXRlIGZvb3Rlci4gSW1wb3J0LWZyZWUgaW4gTURYOyByZWFkcyB0aGUgbmF2IGl0ZW1zIGZyb21cbi8vIHRoZSBzaGVsbCBjb250ZXh0IHNvIGEgbGF5b3V0IGp1c3QgcGxhY2VzIGA8R3JvdmVGb290ZXIvPmAuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBHcm92ZUZvb3RlcigpIHtcbiAgY29uc3QgeyBuYXZJdGVtcywgZW50cnlLZXkgfSA9IHVzZVNoZWxsKCk7XG4gIGNvbnN0IGZvbGxvdyA9IHVzZUZvbGxvd0xpbmsoKTtcbiAgcmV0dXJuIChcbiAgICA8Zm9vdGVyIGNsYXNzTmFtZT1cImdyb3ZlLWZvb3RlclwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncm92ZS1mb290ZXJfX2xpbmtzXCI+XG4gICAgICAgIHtuYXZJdGVtcy5zbGljZSgwLCA0KS5tYXAoKG4pID0+IChcbiAgICAgICAgICA8TGluayBrZXk9e24ua2V5fSBocmVmPXtuLmhyZWZ9IG9uQ2xpY2s9e2ZvbGxvd0xpbmtPbkNsaWNrKGZvbGxvdywgeyBrZXk6IG4ua2V5LCBocmVmOiBuLmhyZWYsIGZyb206IGVudHJ5S2V5IH0pfT5cbiAgICAgICAgICAgIHtuLmxhYmVsfVxuICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgKSl9XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JvdmUtZm9vdGVyX19tZXRhXCI+YnVpbHQgd2l0aCBncm92ZTwvZGl2PlxuICAgIDwvZm9vdGVyPlxuICApO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBLElBQUFBLElBQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLE1BQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLGNBQUEsR0FBQUYsT0FBQTtBQUNBLElBQUFHLGlCQUFBLEdBQUFILE9BQUE7QUFBNEQsSUFBQUksV0FBQSxHQUFBSixPQUFBO0FBQUEsSUFBQUssRUFBQSxHQUFBQyxZQUFBLElBRTVEO0FBQ0E7QUFDZSxTQUFTQyxXQUFXQSxDQUFBLEVBQUc7RUFBQUYsRUFBQTtFQUNwQyxNQUFNO0lBQUVHLFFBQVE7SUFBRUM7RUFBUyxDQUFDLEdBQUcsSUFBQUMsZUFBUSxFQUFDLENBQUM7RUFDekMsTUFBTUMsTUFBTSxHQUFHLElBQUFDLDRCQUFhLEVBQUMsQ0FBQztFQUM5QixvQkFDRSxJQUFBUixXQUFBLENBQUFTLElBQUE7SUFBUUMsU0FBUyxFQUFDLGNBQWM7SUFBQUMsUUFBQSxnQkFDOUIsSUFBQVgsV0FBQSxDQUFBWSxHQUFBO01BQUtGLFNBQVMsRUFBQyxxQkFBcUI7TUFBQUMsUUFBQSxFQUNqQ1AsUUFBUSxDQUFDUyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDQyxHQUFHLENBQUVDLENBQUMsaUJBQzFCLElBQUFmLFdBQUEsQ0FBQVksR0FBQSxFQUFDakIsSUFBQSxDQUFBcUIsSUFBSTtRQUFhQyxJQUFJLEVBQUVGLENBQUMsQ0FBQ0UsSUFBSztRQUFDQyxPQUFPLEVBQUUsSUFBQUMsbUNBQWlCLEVBQUNaLE1BQU0sRUFBRTtVQUFFYSxHQUFHLEVBQUVMLENBQUMsQ0FBQ0ssR0FBRztVQUFFSCxJQUFJLEVBQUVGLENBQUMsQ0FBQ0UsSUFBSTtVQUFFSSxJQUFJLEVBQUVoQjtRQUFTLENBQUMsQ0FBRTtRQUFBTSxRQUFBLEVBQzlHSSxDQUFDLENBQUNPO01BQUssR0FEQ1AsQ0FBQyxDQUFDSyxHQUVQLENBQ1A7SUFBQyxDQUNDLENBQUMsZUFDTixJQUFBcEIsV0FBQSxDQUFBWSxHQUFBO01BQUtGLFNBQVMsRUFBQyxvQkFBb0I7TUFBQUMsUUFBQSxFQUFDO0lBQWdCLENBQUssQ0FBQztFQUFBLENBQ3BELENBQUM7QUFFYjtBQUFDVixFQUFBLENBZnVCRSxXQUFXO0VBQUEsUUFDRkcsZUFBUSxFQUN4QkUsNEJBQWE7QUFBQTtBQUFBZSxFQUFBLEdBRk5wQixXQUFXO0FBQUEsSUFBQW9CLEVBQUE7QUFBQUMsWUFBQSxDQUFBRCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}