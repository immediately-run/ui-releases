var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Directory;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.map.js");
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
var _content = require("../lib/content");
var _wiki = require("../lib/wiki");
var _useEntryKey = require("../hooks/useEntryKey");
var _useFollowLink = require("../hooks/useFollowLink");
var _navigationPolicy = require("../lib/navigationPolicy");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(),
  _s2 = $RefreshSig$();
/* eslint-disable @typescript-eslint/no-explicit-any */
function isPerson(m) {
  return m && m.name && m.role && m.team && m.phone;
}
function Row({
  path,
  compact
}) {
  _s();
  const m = (0, _sdk.useFileMetadata)(path);
  const from = (0, _useEntryKey.useEntryKey)();
  const follow = (0, _useFollowLink.useFollowLink)();
  if (!m) return null;
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("tr", {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("td", {
      style: {
        fontWeight: 600
      },
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_sdk.Link, {
        href: (0, _content.keyToHref)(path),
        onClick: (0, _navigationPolicy.followLinkOnClick)(follow, {
          key: path,
          href: (0, _content.keyToHref)(path),
          from
        }),
        children: m.name
      })
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("td", {
      children: m.role
    }), !compact && /*#__PURE__*/(0, _jsxRuntime.jsx)("td", {
      children: m.team
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("td", {
      className: "mono",
      children: m.phone
    }), !compact && /*#__PURE__*/(0, _jsxRuntime.jsx)("td", {
      className: "mono",
      children: m.email
    })]
  });
}

// Import-free engine component: the phone book, built from per-person entries.
_s(Row, "yi8fnzd+K/oLOUJ+RPzis+vLmXc=", false, function () {
  return [_sdk.useFileMetadata, _useEntryKey.useEntryKey, _useFollowLink.useFollowLink];
});
_c = Row;
function Directory({
  team,
  compact
}) {
  _s2();
  const queryFn = (0, _react.useCallback)(filesMetadata => Object.keys(filesMetadata).filter(p => p.startsWith((0, _content.contentDir)()) && isPerson(filesMetadata[p])).filter(p => !team || filesMetadata[p].team === team).sort((a, b) => filesMetadata[a].name < filesMetadata[b].name ? -1 : 1), [team]);
  const result = (0, _sdk.useMetadataQuery)(queryFn);
  const paths = (0, _wiki.queryPaths)(result);
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    className: "grove-table-wrap",
    children: /*#__PURE__*/(0, _jsxRuntime.jsxs)("table", {
      className: "grove-table",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("thead", {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)("tr", {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("th", {
            children: "Name"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)("th", {
            children: "Role"
          }), !compact && /*#__PURE__*/(0, _jsxRuntime.jsx)("th", {
            children: "Team"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)("th", {
            children: "Phone"
          }), !compact && /*#__PURE__*/(0, _jsxRuntime.jsx)("th", {
            children: "Email"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("tbody", {
        children: paths.map(p => /*#__PURE__*/(0, _jsxRuntime.jsx)(Row, {
          path: p,
          compact: compact
        }, p))
      })]
    })
  });
}
_s2(Directory, "92XDcBEKcr0huS9xFVJPNEOy7oY=", false, function () {
  return [_sdk.useMetadataQuery];
});
_c2 = Directory;
var _c, _c2;
$RefreshReg$(_c, "Row");
$RefreshReg$(_c2, "Directory");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NkayIsIl9jb250ZW50IiwiX3dpa2kiLCJfdXNlRW50cnlLZXkiLCJfdXNlRm9sbG93TGluayIsIl9uYXZpZ2F0aW9uUG9saWN5IiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsIl9zMiIsImlzUGVyc29uIiwibSIsIm5hbWUiLCJyb2xlIiwidGVhbSIsInBob25lIiwiUm93IiwicGF0aCIsImNvbXBhY3QiLCJ1c2VGaWxlTWV0YWRhdGEiLCJmcm9tIiwidXNlRW50cnlLZXkiLCJmb2xsb3ciLCJ1c2VGb2xsb3dMaW5rIiwianN4cyIsImNoaWxkcmVuIiwianN4Iiwic3R5bGUiLCJmb250V2VpZ2h0IiwiTGluayIsImhyZWYiLCJrZXlUb0hyZWYiLCJvbkNsaWNrIiwiZm9sbG93TGlua09uQ2xpY2siLCJrZXkiLCJjbGFzc05hbWUiLCJlbWFpbCIsIl9jIiwiRGlyZWN0b3J5IiwicXVlcnlGbiIsInVzZUNhbGxiYWNrIiwiZmlsZXNNZXRhZGF0YSIsIk9iamVjdCIsImtleXMiLCJmaWx0ZXIiLCJwIiwic3RhcnRzV2l0aCIsImNvbnRlbnREaXIiLCJzb3J0IiwiYSIsImIiLCJyZXN1bHQiLCJ1c2VNZXRhZGF0YVF1ZXJ5IiwicGF0aHMiLCJxdWVyeVBhdGhzIiwibWFwIiwiX2MyIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiRGlyZWN0b3J5LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55ICovXG5pbXBvcnQgeyB1c2VDYWxsYmFjayB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IExpbmssIHVzZUZpbGVNZXRhZGF0YSwgdXNlTWV0YWRhdGFRdWVyeSB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrJztcbmltcG9ydCB7IGNvbnRlbnREaXIsIGtleVRvSHJlZiB9IGZyb20gJy4uL2xpYi9jb250ZW50JztcbmltcG9ydCB7IHF1ZXJ5UGF0aHMgfSBmcm9tICcuLi9saWIvd2lraSc7XG5pbXBvcnQgeyB1c2VFbnRyeUtleSB9IGZyb20gJy4uL2hvb2tzL3VzZUVudHJ5S2V5JztcbmltcG9ydCB7IHVzZUZvbGxvd0xpbmsgfSBmcm9tICcuLi9ob29rcy91c2VGb2xsb3dMaW5rJztcbmltcG9ydCB7IGZvbGxvd0xpbmtPbkNsaWNrIH0gZnJvbSAnLi4vbGliL25hdmlnYXRpb25Qb2xpY3knO1xuXG5pbnRlcmZhY2UgUHJvcHMge1xuICB0ZWFtPzogc3RyaW5nO1xuICBjb21wYWN0PzogYm9vbGVhbjtcbn1cblxuZnVuY3Rpb24gaXNQZXJzb24obTogYW55KTogYm9vbGVhbiB7XG4gIHJldHVybiBtICYmIG0ubmFtZSAmJiBtLnJvbGUgJiYgbS50ZWFtICYmIG0ucGhvbmU7XG59XG5cbmZ1bmN0aW9uIFJvdyh7IHBhdGgsIGNvbXBhY3QgfTogeyBwYXRoOiBzdHJpbmc7IGNvbXBhY3Q/OiBib29sZWFuIH0pIHtcbiAgY29uc3QgbSA9IHVzZUZpbGVNZXRhZGF0YShwYXRoKSBhcyBhbnk7XG4gIGNvbnN0IGZyb20gPSB1c2VFbnRyeUtleSgpO1xuICBjb25zdCBmb2xsb3cgPSB1c2VGb2xsb3dMaW5rKCk7XG4gIGlmICghbSkgcmV0dXJuIG51bGw7XG4gIHJldHVybiAoXG4gICAgPHRyPlxuICAgICAgPHRkIHN0eWxlPXt7IGZvbnRXZWlnaHQ6IDYwMCB9fT5cbiAgICAgICAgPExpbmsgaHJlZj17a2V5VG9IcmVmKHBhdGgpfSBvbkNsaWNrPXtmb2xsb3dMaW5rT25DbGljayhmb2xsb3csIHsga2V5OiBwYXRoLCBocmVmOiBrZXlUb0hyZWYocGF0aCksIGZyb20gfSl9PnttLm5hbWV9PC9MaW5rPlxuICAgICAgPC90ZD5cbiAgICAgIDx0ZD57bS5yb2xlfTwvdGQ+XG4gICAgICB7IWNvbXBhY3QgJiYgPHRkPnttLnRlYW19PC90ZD59XG4gICAgICA8dGQgY2xhc3NOYW1lPVwibW9ub1wiPnttLnBob25lfTwvdGQ+XG4gICAgICB7IWNvbXBhY3QgJiYgPHRkIGNsYXNzTmFtZT1cIm1vbm9cIj57bS5lbWFpbH08L3RkPn1cbiAgICA8L3RyPlxuICApO1xufVxuXG4vLyBJbXBvcnQtZnJlZSBlbmdpbmUgY29tcG9uZW50OiB0aGUgcGhvbmUgYm9vaywgYnVpbHQgZnJvbSBwZXItcGVyc29uIGVudHJpZXMuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBEaXJlY3RvcnkoeyB0ZWFtLCBjb21wYWN0IH06IFByb3BzKSB7XG4gIGNvbnN0IHF1ZXJ5Rm4gPSB1c2VDYWxsYmFjayhcbiAgICAoZmlsZXNNZXRhZGF0YTogUmVjb3JkPHN0cmluZywgYW55PikgPT5cbiAgICAgIE9iamVjdC5rZXlzKGZpbGVzTWV0YWRhdGEpXG4gICAgICAgIC5maWx0ZXIoKHApID0+IHAuc3RhcnRzV2l0aChjb250ZW50RGlyKCkpICYmIGlzUGVyc29uKGZpbGVzTWV0YWRhdGFbcF0pKVxuICAgICAgICAuZmlsdGVyKChwKSA9PiAhdGVhbSB8fCBmaWxlc01ldGFkYXRhW3BdLnRlYW0gPT09IHRlYW0pXG4gICAgICAgIC5zb3J0KChhLCBiKSA9PiAoZmlsZXNNZXRhZGF0YVthXS5uYW1lIDwgZmlsZXNNZXRhZGF0YVtiXS5uYW1lID8gLTEgOiAxKSksXG4gICAgW3RlYW1dXG4gICk7XG4gIGNvbnN0IHJlc3VsdCA9IHVzZU1ldGFkYXRhUXVlcnkocXVlcnlGbik7XG4gIGNvbnN0IHBhdGhzOiBzdHJpbmdbXSA9IHF1ZXJ5UGF0aHMocmVzdWx0KTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JvdmUtdGFibGUtd3JhcFwiPlxuICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cImdyb3ZlLXRhYmxlXCI+XG4gICAgICAgIDx0aGVhZD5cbiAgICAgICAgICA8dHI+XG4gICAgICAgICAgICA8dGg+TmFtZTwvdGg+XG4gICAgICAgICAgICA8dGg+Um9sZTwvdGg+XG4gICAgICAgICAgICB7IWNvbXBhY3QgJiYgPHRoPlRlYW08L3RoPn1cbiAgICAgICAgICAgIDx0aD5QaG9uZTwvdGg+XG4gICAgICAgICAgICB7IWNvbXBhY3QgJiYgPHRoPkVtYWlsPC90aD59XG4gICAgICAgICAgPC90cj5cbiAgICAgICAgPC90aGVhZD5cbiAgICAgICAgPHRib2R5PlxuICAgICAgICAgIHtwYXRocy5tYXAoKHApID0+IChcbiAgICAgICAgICAgIDxSb3cga2V5PXtwfSBwYXRoPXtwfSBjb21wYWN0PXtjb21wYWN0fSAvPlxuICAgICAgICAgICkpfVxuICAgICAgICA8L3Rib2R5PlxuICAgICAgPC90YWJsZT5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQ0EsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsSUFBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsUUFBQSxHQUFBRixPQUFBO0FBQ0EsSUFBQUcsS0FBQSxHQUFBSCxPQUFBO0FBQ0EsSUFBQUksWUFBQSxHQUFBSixPQUFBO0FBQ0EsSUFBQUssY0FBQSxHQUFBTCxPQUFBO0FBQ0EsSUFBQU0saUJBQUEsR0FBQU4sT0FBQTtBQUE0RCxJQUFBTyxXQUFBLEdBQUFQLE9BQUE7QUFBQSxJQUFBUSxFQUFBLEdBQUFDLFlBQUE7RUFBQUMsR0FBQSxHQUFBRCxZQUFBO0FBUDVEO0FBY0EsU0FBU0UsUUFBUUEsQ0FBQ0MsQ0FBTSxFQUFXO0VBQ2pDLE9BQU9BLENBQUMsSUFBSUEsQ0FBQyxDQUFDQyxJQUFJLElBQUlELENBQUMsQ0FBQ0UsSUFBSSxJQUFJRixDQUFDLENBQUNHLElBQUksSUFBSUgsQ0FBQyxDQUFDSSxLQUFLO0FBQ25EO0FBRUEsU0FBU0MsR0FBR0EsQ0FBQztFQUFFQyxJQUFJO0VBQUVDO0FBQTZDLENBQUMsRUFBRTtFQUFBWCxFQUFBO0VBQ25FLE1BQU1JLENBQUMsR0FBRyxJQUFBUSxvQkFBZSxFQUFDRixJQUFJLENBQVE7RUFDdEMsTUFBTUcsSUFBSSxHQUFHLElBQUFDLHdCQUFXLEVBQUMsQ0FBQztFQUMxQixNQUFNQyxNQUFNLEdBQUcsSUFBQUMsNEJBQWEsRUFBQyxDQUFDO0VBQzlCLElBQUksQ0FBQ1osQ0FBQyxFQUFFLE9BQU8sSUFBSTtFQUNuQixvQkFDRSxJQUFBTCxXQUFBLENBQUFrQixJQUFBO0lBQUFDLFFBQUEsZ0JBQ0UsSUFBQW5CLFdBQUEsQ0FBQW9CLEdBQUE7TUFBSUMsS0FBSyxFQUFFO1FBQUVDLFVBQVUsRUFBRTtNQUFJLENBQUU7TUFBQUgsUUFBQSxlQUM3QixJQUFBbkIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDMUIsSUFBQSxDQUFBNkIsSUFBSTtRQUFDQyxJQUFJLEVBQUUsSUFBQUMsa0JBQVMsRUFBQ2QsSUFBSSxDQUFFO1FBQUNlLE9BQU8sRUFBRSxJQUFBQyxtQ0FBaUIsRUFBQ1gsTUFBTSxFQUFFO1VBQUVZLEdBQUcsRUFBRWpCLElBQUk7VUFBRWEsSUFBSSxFQUFFLElBQUFDLGtCQUFTLEVBQUNkLElBQUksQ0FBQztVQUFFRztRQUFLLENBQUMsQ0FBRTtRQUFBSyxRQUFBLEVBQUVkLENBQUMsQ0FBQ0M7TUFBSSxDQUFPO0lBQUMsQ0FDMUgsQ0FBQyxlQUNMLElBQUFOLFdBQUEsQ0FBQW9CLEdBQUE7TUFBQUQsUUFBQSxFQUFLZCxDQUFDLENBQUNFO0lBQUksQ0FBSyxDQUFDLEVBQ2hCLENBQUNLLE9BQU8saUJBQUksSUFBQVosV0FBQSxDQUFBb0IsR0FBQTtNQUFBRCxRQUFBLEVBQUtkLENBQUMsQ0FBQ0c7SUFBSSxDQUFLLENBQUMsZUFDOUIsSUFBQVIsV0FBQSxDQUFBb0IsR0FBQTtNQUFJUyxTQUFTLEVBQUMsTUFBTTtNQUFBVixRQUFBLEVBQUVkLENBQUMsQ0FBQ0k7SUFBSyxDQUFLLENBQUMsRUFDbEMsQ0FBQ0csT0FBTyxpQkFBSSxJQUFBWixXQUFBLENBQUFvQixHQUFBO01BQUlTLFNBQVMsRUFBQyxNQUFNO01BQUFWLFFBQUEsRUFBRWQsQ0FBQyxDQUFDeUI7SUFBSyxDQUFLLENBQUM7RUFBQSxDQUM5QyxDQUFDO0FBRVQ7O0FBRUE7QUFBQTdCLEVBQUEsQ0FsQlNTLEdBQUc7RUFBQSxRQUNBRyxvQkFBZSxFQUNaRSx3QkFBVyxFQUNURSw0QkFBYTtBQUFBO0FBQUFjLEVBQUEsR0FIckJyQixHQUFHO0FBbUJHLFNBQVNzQixTQUFTQSxDQUFDO0VBQUV4QixJQUFJO0VBQUVJO0FBQWUsQ0FBQyxFQUFFO0VBQUFULEdBQUE7RUFDMUQsTUFBTThCLE9BQU8sR0FBRyxJQUFBQyxrQkFBVyxFQUN4QkMsYUFBa0MsSUFDakNDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDRixhQUFhLENBQUMsQ0FDdkJHLE1BQU0sQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUNDLFVBQVUsQ0FBQyxJQUFBQyxtQkFBVSxFQUFDLENBQUMsQ0FBQyxJQUFJckMsUUFBUSxDQUFDK0IsYUFBYSxDQUFDSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQ3ZFRCxNQUFNLENBQUVDLENBQUMsSUFBSyxDQUFDL0IsSUFBSSxJQUFJMkIsYUFBYSxDQUFDSSxDQUFDLENBQUMsQ0FBQy9CLElBQUksS0FBS0EsSUFBSSxDQUFDLENBQ3REa0MsSUFBSSxDQUFDLENBQUNDLENBQUMsRUFBRUMsQ0FBQyxLQUFNVCxhQUFhLENBQUNRLENBQUMsQ0FBQyxDQUFDckMsSUFBSSxHQUFHNkIsYUFBYSxDQUFDUyxDQUFDLENBQUMsQ0FBQ3RDLElBQUksR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFFLENBQUMsRUFDN0UsQ0FBQ0UsSUFBSSxDQUNQLENBQUM7RUFDRCxNQUFNcUMsTUFBTSxHQUFHLElBQUFDLHFCQUFnQixFQUFDYixPQUFPLENBQUM7RUFDeEMsTUFBTWMsS0FBZSxHQUFHLElBQUFDLGdCQUFVLEVBQUNILE1BQU0sQ0FBQztFQUUxQyxvQkFDRSxJQUFBN0MsV0FBQSxDQUFBb0IsR0FBQTtJQUFLUyxTQUFTLEVBQUMsa0JBQWtCO0lBQUFWLFFBQUEsZUFDL0IsSUFBQW5CLFdBQUEsQ0FBQWtCLElBQUE7TUFBT1csU0FBUyxFQUFDLGFBQWE7TUFBQVYsUUFBQSxnQkFDNUIsSUFBQW5CLFdBQUEsQ0FBQW9CLEdBQUE7UUFBQUQsUUFBQSxlQUNFLElBQUFuQixXQUFBLENBQUFrQixJQUFBO1VBQUFDLFFBQUEsZ0JBQ0UsSUFBQW5CLFdBQUEsQ0FBQW9CLEdBQUE7WUFBQUQsUUFBQSxFQUFJO1VBQUksQ0FBSSxDQUFDLGVBQ2IsSUFBQW5CLFdBQUEsQ0FBQW9CLEdBQUE7WUFBQUQsUUFBQSxFQUFJO1VBQUksQ0FBSSxDQUFDLEVBQ1osQ0FBQ1AsT0FBTyxpQkFBSSxJQUFBWixXQUFBLENBQUFvQixHQUFBO1lBQUFELFFBQUEsRUFBSTtVQUFJLENBQUksQ0FBQyxlQUMxQixJQUFBbkIsV0FBQSxDQUFBb0IsR0FBQTtZQUFBRCxRQUFBLEVBQUk7VUFBSyxDQUFJLENBQUMsRUFDYixDQUFDUCxPQUFPLGlCQUFJLElBQUFaLFdBQUEsQ0FBQW9CLEdBQUE7WUFBQUQsUUFBQSxFQUFJO1VBQUssQ0FBSSxDQUFDO1FBQUEsQ0FDekI7TUFBQyxDQUNBLENBQUMsZUFDUixJQUFBbkIsV0FBQSxDQUFBb0IsR0FBQTtRQUFBRCxRQUFBLEVBQ0c0QixLQUFLLENBQUNFLEdBQUcsQ0FBRVYsQ0FBQyxpQkFDWCxJQUFBdkMsV0FBQSxDQUFBb0IsR0FBQSxFQUFDVixHQUFHO1VBQVNDLElBQUksRUFBRTRCLENBQUU7VUFBQzNCLE9BQU8sRUFBRUE7UUFBUSxHQUE3QjJCLENBQStCLENBQzFDO01BQUMsQ0FDRyxDQUFDO0lBQUEsQ0FDSDtFQUFDLENBQ0wsQ0FBQztBQUVWO0FBQUNwQyxHQUFBLENBaEN1QjZCLFNBQVM7RUFBQSxRQVNoQmMscUJBQWdCO0FBQUE7QUFBQUksR0FBQSxHQVRUbEIsU0FBUztBQUFBLElBQUFELEVBQUEsRUFBQW1CLEdBQUE7QUFBQUMsWUFBQSxDQUFBcEIsRUFBQTtBQUFBb0IsWUFBQSxDQUFBRCxHQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}