var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {#!/usr/bin/env node
// check-lock-version.mjs — R3-868: package.json's `version` must equal BOTH of
// package-lock.json's version fields (the root and `packages[""]`).
//
// The failure this exists for. A version bump that rides a feature PR touches
// only package.json; npm does not rewrite the lock's own version fields unless
// an install runs, and `npm ci` tolerates the mismatch (probed on npm 11: exit
// 0). The lock then lies about what the tree claims to be, with no failure
// mode anywhere: this happened in platform-constants (manifest 0.13.0, lock
// 0.12.1), grove (0.1.8/0.1.7, the bump in #79) and dev-fs (0.5.0/0.4.0), each
// found by hand by the R3-678 review gate rather than by any check — because
// `check:publish-version` (where it exists) compares the manifest against the
// npm registry, never against the lock.
//
// The fix command is always the same: `npm install --package-lock-only`, which
// rewrites the lock's version fields from the manifest without touching
// node_modules.
//
// Copied, not shared — the rule is ~30 lines, and a shared package for it
// would itself be a cross-repo dependency to coordinate (the
// check-dependency-pins.mjs precedent).
//
// Run: `node scripts/check-lock-version.mjs`           → exit 1 on a mismatch
//      `node scripts/check-lock-version.mjs --self-test` → prove it can fail
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.checkLockVersion = checkLockVersion;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.some.js");
var _nodeFs = require("node:fs");
var _nodeChild_process = require("node:child_process");
var _nodeOs = require("node:os");
var _nodePath = require("node:path");
var _nodeUrl = require("node:url");
function checkLockVersion({
  pkg,
  lock,
  cwd = '.'
}) {
  const problems = [];
  const manifestVersion = pkg?.version;
  if (typeof manifestVersion !== 'string' || manifestVersion.length === 0) {
    problems.push(`${cwd}/package.json has no version field — nothing to sync the lock against.`);
    return problems;
  }
  if (lock?.version !== manifestVersion) {
    problems.push(`${cwd}/package-lock.json's root version is ${JSON.stringify(lock?.version)} but package.json says ` + `${JSON.stringify(manifestVersion)} — run \`npm install --package-lock-only\` to resync the lock.`);
  }
  const lockRootPkg = lock?.packages?.[''];
  if (lockRootPkg?.version !== manifestVersion) {
    problems.push(`${cwd}/package-lock.json's packages[""].version is ${JSON.stringify(lockRootPkg?.version)} but ` + `package.json says ${JSON.stringify(manifestVersion)} — the same \`npm install --package-lock-only\` fixes both fields.`);
  }
  return problems;
}
const readJson = p => {
  if (!(0, _nodeFs.existsSync)(p)) {
    console.error(`check-lock-version: ${p} does not exist — the check needs both files in the repo root. ` + `A missing lock means nothing pins the tree; run \`npm install --package-lock-only\` to write one.`);
    process.exit(1);
  }
  return JSON.parse((0, _nodeFs.readFileSync)(p, 'utf8'));
};
if (process.argv.includes('--self-test')) {
  // The SUBPROCESS cases: the pure cases below cannot see the main mode's
  // readJson/exit wiring, so a defanged exit code kept them green (the round-1
  // finding). These run the real script over real fixtures and assert the exit
  // code — the guard cannot stop guarding silently, and a missing input file
  // fails loudly too (the branch no pure case can reach).
  {
    let failed = 0;
    const here = (0, _nodePath.dirname)((0, _nodeUrl.fileURLToPath)($ir_import_meta.url));
    const runOver = (name, write) => {
      const dir = (0, _nodeFs.mkdtempSync)((0, _nodePath.join)((0, _nodeOs.tmpdir)(), 'check-lock-version-'));
      let verdict;
      try {
        write(dir);
        const run = (0, _nodeChild_process.spawnSync)(process.execPath, [(0, _nodePath.join)(here, 'check-lock-version.mjs')], {
          cwd: dir,
          encoding: 'utf8'
        });
        verdict = {
          status: run.status,
          stderr: run.stderr
        };
      } finally {
        (0, _nodeFs.rmSync)(dir, {
          recursive: true,
          force: true
        });
      }
      return {
        name,
        ...verdict
      };
    };
    const subprocessCases = [runOver('the real run over a desynced fixture exits 1 with both problems', dir => {
      (0, _nodeFs.writeFileSync)((0, _nodePath.join)(dir, 'package.json'), JSON.stringify({
        version: '2.0.0'
      }));
      (0, _nodeFs.writeFileSync)((0, _nodePath.join)(dir, 'package-lock.json'), JSON.stringify({
        version: '1.9.0',
        packages: {
          '': {
            version: '1.9.0'
          }
        }
      }));
    }), runOver('a missing lock file fails with the check message, not a stack', dir => {
      (0, _nodeFs.writeFileSync)((0, _nodePath.join)(dir, 'package.json'), JSON.stringify({
        version: '2.0.0'
      }));
    })];
    const wants = [/root version/, /does not exist/];
    for (let i = 0; i < subprocessCases.length; i++) {
      const c = subprocessCases[i];
      const ok = c.status === 1 && wants[i].test(c.stderr);
      console.log(`  ${ok ? 'ok  ' : 'FAIL'}  ${c.name}`);
      if (!ok) {
        console.error(c.stderr);
        failed += 1;
      }
    }
    // Exit AFTER the fixtures are cleaned (the finally above): process.exit
    // inside the loop would skip later cleanups.
    if (failed > 0) process.exit(1);
  }
  const cases = [{
    name: 'in sync passes',
    pkg: {
      version: '1.0.0'
    },
    lock: {
      version: '1.0.0',
      packages: {
        '': {
          version: '1.0.0'
        }
      }
    },
    want: 0
  }, {
    name: 'a root-only mismatch fails with the fix command',
    pkg: {
      version: '1.0.1'
    },
    lock: {
      version: '1.0.0',
      packages: {
        '': {
          version: '1.0.0'
        }
      }
    },
    want: /package-lock\.json's root version.*npm install --package-lock-only/
  }, {
    name: 'a packages[""] mismatch fails too',
    pkg: {
      version: '1.0.1'
    },
    lock: {
      version: '1.0.1',
      packages: {
        '': {
          version: '1.0.0'
        }
      }
    },
    want: /packages\[""\]\.version/
  }, {
    name: 'a missing manifest version is its own failure',
    pkg: {},
    lock: {
      version: '1.0.0'
    },
    want: /no version field/
  }];
  let failed = 0;
  for (const c of cases) {
    const problems = checkLockVersion({
      pkg: c.pkg,
      lock: c.lock
    });
    const ok = c.want === 0 && problems.length === 0 || c.want instanceof RegExp && problems.some(p => c.want.test(p));
    console.log(`  ${ok ? 'ok  ' : 'FAIL'}  ${c.name}`);
    if (!ok) failed += 1;
  }
  console.log(`${failed === 0 ? 'OK' : 'FAILED'}: ${cases.length - failed}/${cases.length} self-test cases (+ the subprocess cases above).`);
  process.exit(failed === 0 ? 0 : 1);
}
const pkg = readJson('package.json');
const lock = readJson('package-lock.json');
const problems = checkLockVersion({
  pkg,
  lock
});
for (const p of problems) console.error(`check-lock-version: ${p}`);
if (problems.length > 0) process.exit(1);
console.log(`OK: package.json ${pkg.version} = package-lock.json ${lock.version} (root and packages[""]) — manifest and lock agree.`);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJPYmplY3QiLCJkZWZpbmVQcm9wZXJ0eSIsImV4cG9ydHMiLCJ2YWx1ZSIsImNoZWNrTG9ja1ZlcnNpb24iLCJyZXF1aXJlIiwiX25vZGVGcyIsIl9ub2RlQ2hpbGRfcHJvY2VzcyIsIl9ub2RlT3MiLCJfbm9kZVBhdGgiLCJfbm9kZVVybCIsInBrZyIsImxvY2siLCJjd2QiLCJwcm9ibGVtcyIsIm1hbmlmZXN0VmVyc2lvbiIsInZlcnNpb24iLCJsZW5ndGgiLCJwdXNoIiwiSlNPTiIsInN0cmluZ2lmeSIsImxvY2tSb290UGtnIiwicGFja2FnZXMiLCJyZWFkSnNvbiIsInAiLCJleGlzdHNTeW5jIiwiY29uc29sZSIsImVycm9yIiwicHJvY2VzcyIsImV4aXQiLCJwYXJzZSIsInJlYWRGaWxlU3luYyIsImFyZ3YiLCJpbmNsdWRlcyIsImZhaWxlZCIsImhlcmUiLCJkaXJuYW1lIiwiZmlsZVVSTFRvUGF0aCIsIiRpcl9pbXBvcnRfbWV0YSIsInVybCIsInJ1bk92ZXIiLCJuYW1lIiwid3JpdGUiLCJkaXIiLCJta2R0ZW1wU3luYyIsImpvaW4iLCJ0bXBkaXIiLCJ2ZXJkaWN0IiwicnVuIiwic3Bhd25TeW5jIiwiZXhlY1BhdGgiLCJlbmNvZGluZyIsInN0YXR1cyIsInN0ZGVyciIsInJtU3luYyIsInJlY3Vyc2l2ZSIsImZvcmNlIiwic3VicHJvY2Vzc0Nhc2VzIiwid3JpdGVGaWxlU3luYyIsIndhbnRzIiwiaSIsImMiLCJvayIsInRlc3QiLCJsb2ciLCJjYXNlcyIsIndhbnQiLCJSZWdFeHAiLCJzb21lIl0sInNvdXJjZXMiOlsiY2hlY2stbG9jay12ZXJzaW9uLm1qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIjIS91c3IvYmluL2VudiBub2RlXG4vLyBjaGVjay1sb2NrLXZlcnNpb24ubWpzIOKAlCBSMy04Njg6IHBhY2thZ2UuanNvbidzIGB2ZXJzaW9uYCBtdXN0IGVxdWFsIEJPVEggb2Zcbi8vIHBhY2thZ2UtbG9jay5qc29uJ3MgdmVyc2lvbiBmaWVsZHMgKHRoZSByb290IGFuZCBgcGFja2FnZXNbXCJcIl1gKS5cbi8vXG4vLyBUaGUgZmFpbHVyZSB0aGlzIGV4aXN0cyBmb3IuIEEgdmVyc2lvbiBidW1wIHRoYXQgcmlkZXMgYSBmZWF0dXJlIFBSIHRvdWNoZXNcbi8vIG9ubHkgcGFja2FnZS5qc29uOyBucG0gZG9lcyBub3QgcmV3cml0ZSB0aGUgbG9jaydzIG93biB2ZXJzaW9uIGZpZWxkcyB1bmxlc3Ncbi8vIGFuIGluc3RhbGwgcnVucywgYW5kIGBucG0gY2lgIHRvbGVyYXRlcyB0aGUgbWlzbWF0Y2ggKHByb2JlZCBvbiBucG0gMTE6IGV4aXRcbi8vIDApLiBUaGUgbG9jayB0aGVuIGxpZXMgYWJvdXQgd2hhdCB0aGUgdHJlZSBjbGFpbXMgdG8gYmUsIHdpdGggbm8gZmFpbHVyZVxuLy8gbW9kZSBhbnl3aGVyZTogdGhpcyBoYXBwZW5lZCBpbiBwbGF0Zm9ybS1jb25zdGFudHMgKG1hbmlmZXN0IDAuMTMuMCwgbG9ja1xuLy8gMC4xMi4xKSwgZ3JvdmUgKDAuMS44LzAuMS43LCB0aGUgYnVtcCBpbiAjNzkpIGFuZCBkZXYtZnMgKDAuNS4wLzAuNC4wKSwgZWFjaFxuLy8gZm91bmQgYnkgaGFuZCBieSB0aGUgUjMtNjc4IHJldmlldyBnYXRlIHJhdGhlciB0aGFuIGJ5IGFueSBjaGVjayDigJQgYmVjYXVzZVxuLy8gYGNoZWNrOnB1Ymxpc2gtdmVyc2lvbmAgKHdoZXJlIGl0IGV4aXN0cykgY29tcGFyZXMgdGhlIG1hbmlmZXN0IGFnYWluc3QgdGhlXG4vLyBucG0gcmVnaXN0cnksIG5ldmVyIGFnYWluc3QgdGhlIGxvY2suXG4vL1xuLy8gVGhlIGZpeCBjb21tYW5kIGlzIGFsd2F5cyB0aGUgc2FtZTogYG5wbSBpbnN0YWxsIC0tcGFja2FnZS1sb2NrLW9ubHlgLCB3aGljaFxuLy8gcmV3cml0ZXMgdGhlIGxvY2sncyB2ZXJzaW9uIGZpZWxkcyBmcm9tIHRoZSBtYW5pZmVzdCB3aXRob3V0IHRvdWNoaW5nXG4vLyBub2RlX21vZHVsZXMuXG4vL1xuLy8gQ29waWVkLCBub3Qgc2hhcmVkIOKAlCB0aGUgcnVsZSBpcyB+MzAgbGluZXMsIGFuZCBhIHNoYXJlZCBwYWNrYWdlIGZvciBpdFxuLy8gd291bGQgaXRzZWxmIGJlIGEgY3Jvc3MtcmVwbyBkZXBlbmRlbmN5IHRvIGNvb3JkaW5hdGUgKHRoZVxuLy8gY2hlY2stZGVwZW5kZW5jeS1waW5zLm1qcyBwcmVjZWRlbnQpLlxuLy9cbi8vIFJ1bjogYG5vZGUgc2NyaXB0cy9jaGVjay1sb2NrLXZlcnNpb24ubWpzYCAgICAgICAgICAg4oaSIGV4aXQgMSBvbiBhIG1pc21hdGNoXG4vLyAgICAgIGBub2RlIHNjcmlwdHMvY2hlY2stbG9jay12ZXJzaW9uLm1qcyAtLXNlbGYtdGVzdGAg4oaSIHByb3ZlIGl0IGNhbiBmYWlsXG5pbXBvcnQgeyBleGlzdHNTeW5jLCByZWFkRmlsZVN5bmMsIHJtU3luYywgd3JpdGVGaWxlU3luYyB9IGZyb20gJ25vZGU6ZnMnO1xuaW1wb3J0IHsgc3Bhd25TeW5jIH0gZnJvbSAnbm9kZTpjaGlsZF9wcm9jZXNzJztcbmltcG9ydCB7IG1rZHRlbXBTeW5jIH0gZnJvbSAnbm9kZTpmcyc7XG5pbXBvcnQgeyB0bXBkaXIgfSBmcm9tICdub2RlOm9zJztcbmltcG9ydCB7IGRpcm5hbWUsIGpvaW4gfSBmcm9tICdub2RlOnBhdGgnO1xuaW1wb3J0IHsgZmlsZVVSTFRvUGF0aCB9IGZyb20gJ25vZGU6dXJsJztcblxuZXhwb3J0IGZ1bmN0aW9uIGNoZWNrTG9ja1ZlcnNpb24oeyBwa2csIGxvY2ssIGN3ZCA9ICcuJyB9KSB7XG4gIGNvbnN0IHByb2JsZW1zID0gW107XG4gIGNvbnN0IG1hbmlmZXN0VmVyc2lvbiA9IHBrZz8udmVyc2lvbjtcbiAgaWYgKHR5cGVvZiBtYW5pZmVzdFZlcnNpb24gIT09ICdzdHJpbmcnIHx8IG1hbmlmZXN0VmVyc2lvbi5sZW5ndGggPT09IDApIHtcbiAgICBwcm9ibGVtcy5wdXNoKGAke2N3ZH0vcGFja2FnZS5qc29uIGhhcyBubyB2ZXJzaW9uIGZpZWxkIOKAlCBub3RoaW5nIHRvIHN5bmMgdGhlIGxvY2sgYWdhaW5zdC5gKTtcbiAgICByZXR1cm4gcHJvYmxlbXM7XG4gIH1cbiAgaWYgKGxvY2s/LnZlcnNpb24gIT09IG1hbmlmZXN0VmVyc2lvbikge1xuICAgIHByb2JsZW1zLnB1c2goXG4gICAgICBgJHtjd2R9L3BhY2thZ2UtbG9jay5qc29uJ3Mgcm9vdCB2ZXJzaW9uIGlzICR7SlNPTi5zdHJpbmdpZnkobG9jaz8udmVyc2lvbil9IGJ1dCBwYWNrYWdlLmpzb24gc2F5cyBgICtcbiAgICAgICAgYCR7SlNPTi5zdHJpbmdpZnkobWFuaWZlc3RWZXJzaW9uKX0g4oCUIHJ1biBcXGBucG0gaW5zdGFsbCAtLXBhY2thZ2UtbG9jay1vbmx5XFxgIHRvIHJlc3luYyB0aGUgbG9jay5gLFxuICAgICk7XG4gIH1cbiAgY29uc3QgbG9ja1Jvb3RQa2cgPSBsb2NrPy5wYWNrYWdlcz8uWycnXTtcbiAgaWYgKGxvY2tSb290UGtnPy52ZXJzaW9uICE9PSBtYW5pZmVzdFZlcnNpb24pIHtcbiAgICBwcm9ibGVtcy5wdXNoKFxuICAgICAgYCR7Y3dkfS9wYWNrYWdlLWxvY2suanNvbidzIHBhY2thZ2VzW1wiXCJdLnZlcnNpb24gaXMgJHtKU09OLnN0cmluZ2lmeShsb2NrUm9vdFBrZz8udmVyc2lvbil9IGJ1dCBgICtcbiAgICAgICAgYHBhY2thZ2UuanNvbiBzYXlzICR7SlNPTi5zdHJpbmdpZnkobWFuaWZlc3RWZXJzaW9uKX0g4oCUIHRoZSBzYW1lIFxcYG5wbSBpbnN0YWxsIC0tcGFja2FnZS1sb2NrLW9ubHlcXGAgZml4ZXMgYm90aCBmaWVsZHMuYCxcbiAgICApO1xuICB9XG4gIHJldHVybiBwcm9ibGVtcztcbn1cblxuY29uc3QgcmVhZEpzb24gPSAocCkgPT4ge1xuICBpZiAoIWV4aXN0c1N5bmMocCkpIHtcbiAgICBjb25zb2xlLmVycm9yKFxuICAgICAgYGNoZWNrLWxvY2stdmVyc2lvbjogJHtwfSBkb2VzIG5vdCBleGlzdCDigJQgdGhlIGNoZWNrIG5lZWRzIGJvdGggZmlsZXMgaW4gdGhlIHJlcG8gcm9vdC4gYCArXG4gICAgICAgIGBBIG1pc3NpbmcgbG9jayBtZWFucyBub3RoaW5nIHBpbnMgdGhlIHRyZWU7IHJ1biBcXGBucG0gaW5zdGFsbCAtLXBhY2thZ2UtbG9jay1vbmx5XFxgIHRvIHdyaXRlIG9uZS5gLFxuICAgICk7XG4gICAgcHJvY2Vzcy5leGl0KDEpO1xuICB9XG4gIHJldHVybiBKU09OLnBhcnNlKHJlYWRGaWxlU3luYyhwLCAndXRmOCcpKTtcbn07XG5cbmlmIChwcm9jZXNzLmFyZ3YuaW5jbHVkZXMoJy0tc2VsZi10ZXN0JykpIHtcbiAgLy8gVGhlIFNVQlBST0NFU1MgY2FzZXM6IHRoZSBwdXJlIGNhc2VzIGJlbG93IGNhbm5vdCBzZWUgdGhlIG1haW4gbW9kZSdzXG4gIC8vIHJlYWRKc29uL2V4aXQgd2lyaW5nLCBzbyBhIGRlZmFuZ2VkIGV4aXQgY29kZSBrZXB0IHRoZW0gZ3JlZW4gKHRoZSByb3VuZC0xXG4gIC8vIGZpbmRpbmcpLiBUaGVzZSBydW4gdGhlIHJlYWwgc2NyaXB0IG92ZXIgcmVhbCBmaXh0dXJlcyBhbmQgYXNzZXJ0IHRoZSBleGl0XG4gIC8vIGNvZGUg4oCUIHRoZSBndWFyZCBjYW5ub3Qgc3RvcCBndWFyZGluZyBzaWxlbnRseSwgYW5kIGEgbWlzc2luZyBpbnB1dCBmaWxlXG4gIC8vIGZhaWxzIGxvdWRseSB0b28gKHRoZSBicmFuY2ggbm8gcHVyZSBjYXNlIGNhbiByZWFjaCkuXG4gIHtcbiAgICBsZXQgZmFpbGVkID0gMDtcbiAgICBjb25zdCBoZXJlID0gZGlybmFtZShmaWxlVVJMVG9QYXRoKGltcG9ydC5tZXRhLnVybCkpO1xuICAgIGNvbnN0IHJ1bk92ZXIgPSAobmFtZSwgd3JpdGUpID0+IHtcbiAgICAgIGNvbnN0IGRpciA9IG1rZHRlbXBTeW5jKGpvaW4odG1wZGlyKCksICdjaGVjay1sb2NrLXZlcnNpb24tJykpO1xuICAgICAgbGV0IHZlcmRpY3Q7XG4gICAgICB0cnkge1xuICAgICAgICB3cml0ZShkaXIpO1xuICAgICAgICBjb25zdCBydW4gPSBzcGF3blN5bmMocHJvY2Vzcy5leGVjUGF0aCwgW2pvaW4oaGVyZSwgJ2NoZWNrLWxvY2stdmVyc2lvbi5tanMnKV0sIHtcbiAgICAgICAgICBjd2Q6IGRpcixcbiAgICAgICAgICBlbmNvZGluZzogJ3V0ZjgnLFxuICAgICAgICB9KTtcbiAgICAgICAgdmVyZGljdCA9IHsgc3RhdHVzOiBydW4uc3RhdHVzLCBzdGRlcnI6IHJ1bi5zdGRlcnIgfTtcbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIHJtU3luYyhkaXIsIHsgcmVjdXJzaXZlOiB0cnVlLCBmb3JjZTogdHJ1ZSB9KTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB7IG5hbWUsIC4uLnZlcmRpY3QgfTtcbiAgICB9O1xuICAgIGNvbnN0IHN1YnByb2Nlc3NDYXNlcyA9IFtcbiAgICAgIHJ1bk92ZXIoJ3RoZSByZWFsIHJ1biBvdmVyIGEgZGVzeW5jZWQgZml4dHVyZSBleGl0cyAxIHdpdGggYm90aCBwcm9ibGVtcycsIChkaXIpID0+IHtcbiAgICAgICAgd3JpdGVGaWxlU3luYyhqb2luKGRpciwgJ3BhY2thZ2UuanNvbicpLCBKU09OLnN0cmluZ2lmeSh7IHZlcnNpb246ICcyLjAuMCcgfSkpO1xuICAgICAgICB3cml0ZUZpbGVTeW5jKFxuICAgICAgICAgIGpvaW4oZGlyLCAncGFja2FnZS1sb2NrLmpzb24nKSxcbiAgICAgICAgICBKU09OLnN0cmluZ2lmeSh7IHZlcnNpb246ICcxLjkuMCcsIHBhY2thZ2VzOiB7ICcnOiB7IHZlcnNpb246ICcxLjkuMCcgfSB9IH0pLFxuICAgICAgICApO1xuICAgICAgfSksXG4gICAgICBydW5PdmVyKCdhIG1pc3NpbmcgbG9jayBmaWxlIGZhaWxzIHdpdGggdGhlIGNoZWNrIG1lc3NhZ2UsIG5vdCBhIHN0YWNrJywgKGRpcikgPT4ge1xuICAgICAgICB3cml0ZUZpbGVTeW5jKGpvaW4oZGlyLCAncGFja2FnZS5qc29uJyksIEpTT04uc3RyaW5naWZ5KHsgdmVyc2lvbjogJzIuMC4wJyB9KSk7XG4gICAgICB9KSxcbiAgICBdO1xuICAgIGNvbnN0IHdhbnRzID0gWy9yb290IHZlcnNpb24vLCAvZG9lcyBub3QgZXhpc3QvXTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHN1YnByb2Nlc3NDYXNlcy5sZW5ndGg7IGkrKykge1xuICAgICAgY29uc3QgYyA9IHN1YnByb2Nlc3NDYXNlc1tpXTtcbiAgICAgIGNvbnN0IG9rID0gYy5zdGF0dXMgPT09IDEgJiYgd2FudHNbaV0udGVzdChjLnN0ZGVycik7XG4gICAgICBjb25zb2xlLmxvZyhgICAke29rID8gJ29rICAnIDogJ0ZBSUwnfSAgJHtjLm5hbWV9YCk7XG4gICAgICBpZiAoIW9rKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYy5zdGRlcnIpO1xuICAgICAgICBmYWlsZWQgKz0gMTtcbiAgICAgIH1cbiAgICB9XG4gICAgLy8gRXhpdCBBRlRFUiB0aGUgZml4dHVyZXMgYXJlIGNsZWFuZWQgKHRoZSBmaW5hbGx5IGFib3ZlKTogcHJvY2Vzcy5leGl0XG4gICAgLy8gaW5zaWRlIHRoZSBsb29wIHdvdWxkIHNraXAgbGF0ZXIgY2xlYW51cHMuXG4gICAgaWYgKGZhaWxlZCA+IDApIHByb2Nlc3MuZXhpdCgxKTtcbiAgfVxuICBjb25zdCBjYXNlcyA9IFtcbiAgICB7IG5hbWU6ICdpbiBzeW5jIHBhc3NlcycsIHBrZzogeyB2ZXJzaW9uOiAnMS4wLjAnIH0sIGxvY2s6IHsgdmVyc2lvbjogJzEuMC4wJywgcGFja2FnZXM6IHsgJyc6IHsgdmVyc2lvbjogJzEuMC4wJyB9IH0gfSwgd2FudDogMCB9LFxuICAgIHtcbiAgICAgIG5hbWU6ICdhIHJvb3Qtb25seSBtaXNtYXRjaCBmYWlscyB3aXRoIHRoZSBmaXggY29tbWFuZCcsXG4gICAgICBwa2c6IHsgdmVyc2lvbjogJzEuMC4xJyB9LFxuICAgICAgbG9jazogeyB2ZXJzaW9uOiAnMS4wLjAnLCBwYWNrYWdlczogeyAnJzogeyB2ZXJzaW9uOiAnMS4wLjAnIH0gfSB9LFxuICAgICAgd2FudDogL3BhY2thZ2UtbG9ja1xcLmpzb24ncyByb290IHZlcnNpb24uKm5wbSBpbnN0YWxsIC0tcGFja2FnZS1sb2NrLW9ubHkvLFxuICAgIH0sXG4gICAge1xuICAgICAgbmFtZTogJ2EgcGFja2FnZXNbXCJcIl0gbWlzbWF0Y2ggZmFpbHMgdG9vJyxcbiAgICAgIHBrZzogeyB2ZXJzaW9uOiAnMS4wLjEnIH0sXG4gICAgICBsb2NrOiB7IHZlcnNpb246ICcxLjAuMScsIHBhY2thZ2VzOiB7ICcnOiB7IHZlcnNpb246ICcxLjAuMCcgfSB9IH0sXG4gICAgICB3YW50OiAvcGFja2FnZXNcXFtcIlwiXFxdXFwudmVyc2lvbi8sXG4gICAgfSxcbiAgICB7IG5hbWU6ICdhIG1pc3NpbmcgbWFuaWZlc3QgdmVyc2lvbiBpcyBpdHMgb3duIGZhaWx1cmUnLCBwa2c6IHt9LCBsb2NrOiB7IHZlcnNpb246ICcxLjAuMCcgfSwgd2FudDogL25vIHZlcnNpb24gZmllbGQvIH0sXG4gIF07XG4gIGxldCBmYWlsZWQgPSAwO1xuICBmb3IgKGNvbnN0IGMgb2YgY2FzZXMpIHtcbiAgICBjb25zdCBwcm9ibGVtcyA9IGNoZWNrTG9ja1ZlcnNpb24oeyBwa2c6IGMucGtnLCBsb2NrOiBjLmxvY2sgfSk7XG4gICAgY29uc3Qgb2sgPVxuICAgICAgKGMud2FudCA9PT0gMCAmJiBwcm9ibGVtcy5sZW5ndGggPT09IDApIHx8XG4gICAgICAoYy53YW50IGluc3RhbmNlb2YgUmVnRXhwICYmIHByb2JsZW1zLnNvbWUoKHApID0+IGMud2FudC50ZXN0KHApKSk7XG4gICAgY29uc29sZS5sb2coYCAgJHtvayA/ICdvayAgJyA6ICdGQUlMJ30gICR7Yy5uYW1lfWApO1xuICAgIGlmICghb2spIGZhaWxlZCArPSAxO1xuICB9XG4gIGNvbnNvbGUubG9nKFxuICAgIGAke2ZhaWxlZCA9PT0gMCA/ICdPSycgOiAnRkFJTEVEJ306ICR7Y2FzZXMubGVuZ3RoIC0gZmFpbGVkfS8ke2Nhc2VzLmxlbmd0aH0gc2VsZi10ZXN0IGNhc2VzICgrIHRoZSBzdWJwcm9jZXNzIGNhc2VzIGFib3ZlKS5gLFxuICApO1xuICBwcm9jZXNzLmV4aXQoZmFpbGVkID09PSAwID8gMCA6IDEpO1xufVxuXG5jb25zdCBwa2cgPSByZWFkSnNvbigncGFja2FnZS5qc29uJyk7XG5jb25zdCBsb2NrID0gcmVhZEpzb24oJ3BhY2thZ2UtbG9jay5qc29uJyk7XG5jb25zdCBwcm9ibGVtcyA9IGNoZWNrTG9ja1ZlcnNpb24oeyBwa2csIGxvY2sgfSk7XG5mb3IgKGNvbnN0IHAgb2YgcHJvYmxlbXMpIGNvbnNvbGUuZXJyb3IoYGNoZWNrLWxvY2stdmVyc2lvbjogJHtwfWApO1xuaWYgKHByb2JsZW1zLmxlbmd0aCA+IDApIHByb2Nlc3MuZXhpdCgxKTtcbmNvbnNvbGUubG9nKFxuICBgT0s6IHBhY2thZ2UuanNvbiAke3BrZy52ZXJzaW9ufSA9IHBhY2thZ2UtbG9jay5qc29uICR7bG9jay52ZXJzaW9ufSAocm9vdCBhbmQgcGFja2FnZXNbXCJcIl0pIOKAlCBtYW5pZmVzdCBhbmQgbG9jayBhZ3JlZS5gLFxuKTtcbiJdLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQUE7O0FBQUFBLE1BQUEsQ0FBQUMsY0FBQSxDQUFBQyxPQUFBO0VBQUFDLEtBQUE7QUFBQTtBQUFBRCxPQUFBLENBQUFFLGdCQUFBLEdBQUFBLGdCQUFBO0FBQUFDLE9BQUE7QUFBQUEsT0FBQTtBQUNBLElBQUFDLE9BQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLGtCQUFBLEdBQUFGLE9BQUE7QUFFQSxJQUFBRyxPQUFBLEdBQUFILE9BQUE7QUFDQSxJQUFBSSxTQUFBLEdBQUFKLE9BQUE7QUFDQSxJQUFBSyxRQUFBLEdBQUFMLE9BQUE7QUFFTyxTQUFTRCxnQkFBZ0JBLENBQUM7RUFBRU8sR0FBRztFQUFFQyxJQUFJO0VBQUVDLEdBQUcsR0FBRztBQUFJLENBQUMsRUFBRTtFQUN6RCxNQUFNQyxRQUFRLEdBQUcsRUFBRTtFQUNuQixNQUFNQyxlQUFlLEdBQUdKLEdBQUcsRUFBRUssT0FBTztFQUNwQyxJQUFJLE9BQU9ELGVBQWUsS0FBSyxRQUFRLElBQUlBLGVBQWUsQ0FBQ0UsTUFBTSxLQUFLLENBQUMsRUFBRTtJQUN2RUgsUUFBUSxDQUFDSSxJQUFJLENBQUMsR0FBR0wsR0FBRyx3RUFBd0UsQ0FBQztJQUM3RixPQUFPQyxRQUFRO0VBQ2pCO0VBQ0EsSUFBSUYsSUFBSSxFQUFFSSxPQUFPLEtBQUtELGVBQWUsRUFBRTtJQUNyQ0QsUUFBUSxDQUFDSSxJQUFJLENBQ1gsR0FBR0wsR0FBRyx3Q0FBd0NNLElBQUksQ0FBQ0MsU0FBUyxDQUFDUixJQUFJLEVBQUVJLE9BQU8sQ0FBQyx5QkFBeUIsR0FDbEcsR0FBR0csSUFBSSxDQUFDQyxTQUFTLENBQUNMLGVBQWUsQ0FBQyxnRUFDdEMsQ0FBQztFQUNIO0VBQ0EsTUFBTU0sV0FBVyxHQUFHVCxJQUFJLEVBQUVVLFFBQVEsR0FBRyxFQUFFLENBQUM7RUFDeEMsSUFBSUQsV0FBVyxFQUFFTCxPQUFPLEtBQUtELGVBQWUsRUFBRTtJQUM1Q0QsUUFBUSxDQUFDSSxJQUFJLENBQ1gsR0FBR0wsR0FBRyxnREFBZ0RNLElBQUksQ0FBQ0MsU0FBUyxDQUFDQyxXQUFXLEVBQUVMLE9BQU8sQ0FBQyxPQUFPLEdBQy9GLHFCQUFxQkcsSUFBSSxDQUFDQyxTQUFTLENBQUNMLGVBQWUsQ0FBQyxvRUFDeEQsQ0FBQztFQUNIO0VBQ0EsT0FBT0QsUUFBUTtBQUNqQjtBQUVBLE1BQU1TLFFBQVEsR0FBSUMsQ0FBQyxJQUFLO0VBQ3RCLElBQUksQ0FBQyxJQUFBQyxrQkFBVSxFQUFDRCxDQUFDLENBQUMsRUFBRTtJQUNsQkUsT0FBTyxDQUFDQyxLQUFLLENBQ1gsdUJBQXVCSCxDQUFDLGlFQUFpRSxHQUN2RixtR0FDSixDQUFDO0lBQ0RJLE9BQU8sQ0FBQ0MsSUFBSSxDQUFDLENBQUMsQ0FBQztFQUNqQjtFQUNBLE9BQU9WLElBQUksQ0FBQ1csS0FBSyxDQUFDLElBQUFDLG9CQUFZLEVBQUNQLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQztBQUM1QyxDQUFDO0FBRUQsSUFBSUksT0FBTyxDQUFDSSxJQUFJLENBQUNDLFFBQVEsQ0FBQyxhQUFhLENBQUMsRUFBRTtFQUN4QztFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7SUFDRSxJQUFJQyxNQUFNLEdBQUcsQ0FBQztJQUNkLE1BQU1DLElBQUksR0FBRyxJQUFBQyxpQkFBTyxFQUFDLElBQUFDLHNCQUFhLEVBQUNDLGVBQUEsQ0FBWUMsR0FBRyxDQUFDLENBQUM7SUFDcEQsTUFBTUMsT0FBTyxHQUFHQSxDQUFDQyxJQUFJLEVBQUVDLEtBQUssS0FBSztNQUMvQixNQUFNQyxHQUFHLEdBQUcsSUFBQUMsbUJBQVcsRUFBQyxJQUFBQyxjQUFJLEVBQUMsSUFBQUMsY0FBTSxFQUFDLENBQUMsRUFBRSxxQkFBcUIsQ0FBQyxDQUFDO01BQzlELElBQUlDLE9BQU87TUFDWCxJQUFJO1FBQ0ZMLEtBQUssQ0FBQ0MsR0FBRyxDQUFDO1FBQ1YsTUFBTUssR0FBRyxHQUFHLElBQUFDLDRCQUFTLEVBQUNyQixPQUFPLENBQUNzQixRQUFRLEVBQUUsQ0FBQyxJQUFBTCxjQUFJLEVBQUNWLElBQUksRUFBRSx3QkFBd0IsQ0FBQyxDQUFDLEVBQUU7VUFDOUV0QixHQUFHLEVBQUU4QixHQUFHO1VBQ1JRLFFBQVEsRUFBRTtRQUNaLENBQUMsQ0FBQztRQUNGSixPQUFPLEdBQUc7VUFBRUssTUFBTSxFQUFFSixHQUFHLENBQUNJLE1BQU07VUFBRUMsTUFBTSxFQUFFTCxHQUFHLENBQUNLO1FBQU8sQ0FBQztNQUN0RCxDQUFDLFNBQVM7UUFDUixJQUFBQyxjQUFNLEVBQUNYLEdBQUcsRUFBRTtVQUFFWSxTQUFTLEVBQUUsSUFBSTtVQUFFQyxLQUFLLEVBQUU7UUFBSyxDQUFDLENBQUM7TUFDL0M7TUFDQSxPQUFPO1FBQUVmLElBQUk7UUFBRSxHQUFHTTtNQUFRLENBQUM7SUFDN0IsQ0FBQztJQUNELE1BQU1VLGVBQWUsR0FBRyxDQUN0QmpCLE9BQU8sQ0FBQyxpRUFBaUUsRUFBR0csR0FBRyxJQUFLO01BQ2xGLElBQUFlLHFCQUFhLEVBQUMsSUFBQWIsY0FBSSxFQUFDRixHQUFHLEVBQUUsY0FBYyxDQUFDLEVBQUV4QixJQUFJLENBQUNDLFNBQVMsQ0FBQztRQUFFSixPQUFPLEVBQUU7TUFBUSxDQUFDLENBQUMsQ0FBQztNQUM5RSxJQUFBMEMscUJBQWEsRUFDWCxJQUFBYixjQUFJLEVBQUNGLEdBQUcsRUFBRSxtQkFBbUIsQ0FBQyxFQUM5QnhCLElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQUVKLE9BQU8sRUFBRSxPQUFPO1FBQUVNLFFBQVEsRUFBRTtVQUFFLEVBQUUsRUFBRTtZQUFFTixPQUFPLEVBQUU7VUFBUTtRQUFFO01BQUUsQ0FBQyxDQUM3RSxDQUFDO0lBQ0gsQ0FBQyxDQUFDLEVBQ0Z3QixPQUFPLENBQUMsK0RBQStELEVBQUdHLEdBQUcsSUFBSztNQUNoRixJQUFBZSxxQkFBYSxFQUFDLElBQUFiLGNBQUksRUFBQ0YsR0FBRyxFQUFFLGNBQWMsQ0FBQyxFQUFFeEIsSUFBSSxDQUFDQyxTQUFTLENBQUM7UUFBRUosT0FBTyxFQUFFO01BQVEsQ0FBQyxDQUFDLENBQUM7SUFDaEYsQ0FBQyxDQUFDLENBQ0g7SUFDRCxNQUFNMkMsS0FBSyxHQUFHLENBQUMsY0FBYyxFQUFFLGdCQUFnQixDQUFDO0lBQ2hELEtBQUssSUFBSUMsQ0FBQyxHQUFHLENBQUMsRUFBRUEsQ0FBQyxHQUFHSCxlQUFlLENBQUN4QyxNQUFNLEVBQUUyQyxDQUFDLEVBQUUsRUFBRTtNQUMvQyxNQUFNQyxDQUFDLEdBQUdKLGVBQWUsQ0FBQ0csQ0FBQyxDQUFDO01BQzVCLE1BQU1FLEVBQUUsR0FBR0QsQ0FBQyxDQUFDVCxNQUFNLEtBQUssQ0FBQyxJQUFJTyxLQUFLLENBQUNDLENBQUMsQ0FBQyxDQUFDRyxJQUFJLENBQUNGLENBQUMsQ0FBQ1IsTUFBTSxDQUFDO01BQ3BEM0IsT0FBTyxDQUFDc0MsR0FBRyxDQUFDLEtBQUtGLEVBQUUsR0FBRyxNQUFNLEdBQUcsTUFBTSxLQUFLRCxDQUFDLENBQUNwQixJQUFJLEVBQUUsQ0FBQztNQUNuRCxJQUFJLENBQUNxQixFQUFFLEVBQUU7UUFDUHBDLE9BQU8sQ0FBQ0MsS0FBSyxDQUFDa0MsQ0FBQyxDQUFDUixNQUFNLENBQUM7UUFDdkJuQixNQUFNLElBQUksQ0FBQztNQUNiO0lBQ0Y7SUFDQTtJQUNBO0lBQ0EsSUFBSUEsTUFBTSxHQUFHLENBQUMsRUFBRU4sT0FBTyxDQUFDQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0VBQ2pDO0VBQ0EsTUFBTW9DLEtBQUssR0FBRyxDQUNaO0lBQUV4QixJQUFJLEVBQUUsZ0JBQWdCO0lBQUU5QixHQUFHLEVBQUU7TUFBRUssT0FBTyxFQUFFO0lBQVEsQ0FBQztJQUFFSixJQUFJLEVBQUU7TUFBRUksT0FBTyxFQUFFLE9BQU87TUFBRU0sUUFBUSxFQUFFO1FBQUUsRUFBRSxFQUFFO1VBQUVOLE9BQU8sRUFBRTtRQUFRO01BQUU7SUFBRSxDQUFDO0lBQUVrRCxJQUFJLEVBQUU7RUFBRSxDQUFDLEVBQ2xJO0lBQ0V6QixJQUFJLEVBQUUsaURBQWlEO0lBQ3ZEOUIsR0FBRyxFQUFFO01BQUVLLE9BQU8sRUFBRTtJQUFRLENBQUM7SUFDekJKLElBQUksRUFBRTtNQUFFSSxPQUFPLEVBQUUsT0FBTztNQUFFTSxRQUFRLEVBQUU7UUFBRSxFQUFFLEVBQUU7VUFBRU4sT0FBTyxFQUFFO1FBQVE7TUFBRTtJQUFFLENBQUM7SUFDbEVrRCxJQUFJLEVBQUU7RUFDUixDQUFDLEVBQ0Q7SUFDRXpCLElBQUksRUFBRSxtQ0FBbUM7SUFDekM5QixHQUFHLEVBQUU7TUFBRUssT0FBTyxFQUFFO0lBQVEsQ0FBQztJQUN6QkosSUFBSSxFQUFFO01BQUVJLE9BQU8sRUFBRSxPQUFPO01BQUVNLFFBQVEsRUFBRTtRQUFFLEVBQUUsRUFBRTtVQUFFTixPQUFPLEVBQUU7UUFBUTtNQUFFO0lBQUUsQ0FBQztJQUNsRWtELElBQUksRUFBRTtFQUNSLENBQUMsRUFDRDtJQUFFekIsSUFBSSxFQUFFLCtDQUErQztJQUFFOUIsR0FBRyxFQUFFLENBQUMsQ0FBQztJQUFFQyxJQUFJLEVBQUU7TUFBRUksT0FBTyxFQUFFO0lBQVEsQ0FBQztJQUFFa0QsSUFBSSxFQUFFO0VBQW1CLENBQUMsQ0FDekg7RUFDRCxJQUFJaEMsTUFBTSxHQUFHLENBQUM7RUFDZCxLQUFLLE1BQU0yQixDQUFDLElBQUlJLEtBQUssRUFBRTtJQUNyQixNQUFNbkQsUUFBUSxHQUFHVixnQkFBZ0IsQ0FBQztNQUFFTyxHQUFHLEVBQUVrRCxDQUFDLENBQUNsRCxHQUFHO01BQUVDLElBQUksRUFBRWlELENBQUMsQ0FBQ2pEO0lBQUssQ0FBQyxDQUFDO0lBQy9ELE1BQU1rRCxFQUFFLEdBQ0xELENBQUMsQ0FBQ0ssSUFBSSxLQUFLLENBQUMsSUFBSXBELFFBQVEsQ0FBQ0csTUFBTSxLQUFLLENBQUMsSUFDckM0QyxDQUFDLENBQUNLLElBQUksWUFBWUMsTUFBTSxJQUFJckQsUUFBUSxDQUFDc0QsSUFBSSxDQUFFNUMsQ0FBQyxJQUFLcUMsQ0FBQyxDQUFDSyxJQUFJLENBQUNILElBQUksQ0FBQ3ZDLENBQUMsQ0FBQyxDQUFFO0lBQ3BFRSxPQUFPLENBQUNzQyxHQUFHLENBQUMsS0FBS0YsRUFBRSxHQUFHLE1BQU0sR0FBRyxNQUFNLEtBQUtELENBQUMsQ0FBQ3BCLElBQUksRUFBRSxDQUFDO0lBQ25ELElBQUksQ0FBQ3FCLEVBQUUsRUFBRTVCLE1BQU0sSUFBSSxDQUFDO0VBQ3RCO0VBQ0FSLE9BQU8sQ0FBQ3NDLEdBQUcsQ0FDVCxHQUFHOUIsTUFBTSxLQUFLLENBQUMsR0FBRyxJQUFJLEdBQUcsUUFBUSxLQUFLK0IsS0FBSyxDQUFDaEQsTUFBTSxHQUFHaUIsTUFBTSxJQUFJK0IsS0FBSyxDQUFDaEQsTUFBTSxrREFDN0UsQ0FBQztFQUNEVyxPQUFPLENBQUNDLElBQUksQ0FBQ0ssTUFBTSxLQUFLLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3BDO0FBRUEsTUFBTXZCLEdBQUcsR0FBR1ksUUFBUSxDQUFDLGNBQWMsQ0FBQztBQUNwQyxNQUFNWCxJQUFJLEdBQUdXLFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQztBQUMxQyxNQUFNVCxRQUFRLEdBQUdWLGdCQUFnQixDQUFDO0VBQUVPLEdBQUc7RUFBRUM7QUFBSyxDQUFDLENBQUM7QUFDaEQsS0FBSyxNQUFNWSxDQUFDLElBQUlWLFFBQVEsRUFBRVksT0FBTyxDQUFDQyxLQUFLLENBQUMsdUJBQXVCSCxDQUFDLEVBQUUsQ0FBQztBQUNuRSxJQUFJVixRQUFRLENBQUNHLE1BQU0sR0FBRyxDQUFDLEVBQUVXLE9BQU8sQ0FBQ0MsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUN4Q0gsT0FBTyxDQUFDc0MsR0FBRyxDQUNULG9CQUFvQnJELEdBQUcsQ0FBQ0ssT0FBTyx3QkFBd0JKLElBQUksQ0FBQ0ksT0FBTyxxREFDckUsQ0FBQyIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}