var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {#!/usr/bin/env node
// The manifest ↔ reality gate (R3-277c: "the manifest is validated against reality — a
// component exported but missing from the manifest, or vice versa, fails the engine's own
// `npm run verify`").
//
// A manifest that drifts from the code is worse than no manifest: a corpus checker would
// flag a component that works, or pass one that does not, and a composing shell would be
// told it may override something that no longer exists. So this runs in `verify`, before
// lint and build, because it is the cheapest of the three and the one whose failure is
// most confusing to debug later.
//
// It reads GROVE_MDX's keys by parsing the module rather than importing it (the module
// pulls in TSX, CSS and the SDK — not loadable from plain node), but it parses the OBJECT
// LITERAL's keys, not a regex over the whole file. That is the distinction R3-277c asks
// for: reformatting `mdxComponents.ts` must not change the outcome.
"use strict";

require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
var _nodeFs = require("node:fs");
var _nodeOs = require("node:os");
var _nodeUrl = require("node:url");
var _nodePath = require("node:path");
var _nodeModule = require("node:module");
const root = (0, _nodePath.join)((0, _nodePath.dirname)((0, _nodeUrl.fileURLToPath)($ir_import_meta.url)), '..');
// ajv arrives transitively with eslint (the same arrangement docs' scripts rely on);
// say so when it is absent rather than dying on a bare module-not-found.
const _require = (0, _nodeModule.createRequire)((0, _nodePath.join)(root, 'package.json'));
const Ajv = (() => {
  try {
    return _require('ajv');
  } catch {
    console.error('check-manifest: ajv is not resolvable — it rides with eslint; run npm install.');
    process.exit(1);
  }
})();
const manifest = JSON.parse((0, _nodeFs.readFileSync)((0, _nodePath.join)(root, 'viewer.manifest.json'), 'utf8'));
const source = (0, _nodeFs.readFileSync)((0, _nodePath.join)(root, 'src/mdxComponents.ts'), 'utf8');

/**
 * Strip comments and string literals, replacing each with equivalent-length whitespace so
 * every offset in the result still lines up with the original. Brace-matching MUST run
 * over this and not the raw source: a `}` inside a comment or a string would otherwise end
 * the object literal early, and the failure mode is the worst kind — the gate reports the
 * whole manifest as drifted, which reads as "the manifest is broken" rather than "the
 * scanner is". (Found by planting a `}`-bearing comment; see the reformatting test.)
 */
function blankNonCode(src) {
  const out = src.split('');
  let i = 0;
  const blankTo = end => {
    for (; i < end && i < out.length; i++) if (out[i] !== '\n') out[i] = ' ';
  };
  while (i < src.length) {
    const two = src.slice(i, i + 2);
    if (two === '//') {
      const nl = src.indexOf('\n', i);
      blankTo(nl === -1 ? src.length : nl);
    } else if (two === '/*') {
      const close = src.indexOf('*/', i + 2);
      blankTo(close === -1 ? src.length : close + 2);
    } else if (src[i] === "'" || src[i] === '"' || src[i] === '`') {
      const quote = src[i];
      let j = i + 1;
      while (j < src.length && src[j] !== quote) j += src[j] === '\\' ? 2 : 1;
      blankTo(Math.min(j + 1, src.length));
    } else {
      i++;
    }
  }
  return out.join('');
}

/** The keys of the `export const GROVE_MDX = { … }` object literal, brace-matched over the
 *  comment- and string-blanked source so reformatting cannot change the outcome. */
function groveMdxKeys(rawSrc) {
  const src = blankNonCode(rawSrc);
  const start = src.indexOf('export const GROVE_MDX = {');
  if (start === -1) throw new Error('GROVE_MDX object literal not found in src/mdxComponents.ts');
  const open = src.indexOf('{', start);
  let depth = 0;
  let end = -1;
  for (let j = open; j < src.length; j++) {
    if (src[j] === '{') depth++;else if (src[j] === '}') {
      depth--;
      if (depth === 0) {
        end = j;
        break;
      }
    }
  }
  if (end === -1) throw new Error('GROVE_MDX object literal is unterminated');
  const keys = [];
  let nesting = 0;
  for (const line of src.slice(open + 1, end).split('\n')) {
    // Only TOP-level keys are the vocabulary; a nested object's keys are props, not
    // components.
    const before = nesting;
    for (const ch of line) {
      if (ch === '{' || ch === '[') nesting++;else if (ch === '}' || ch === ']') nesting--;
    }
    if (before !== 0) continue;
    const m = line.match(/^\s*([A-Za-z_$][\w$]*)\s*[,:]/);
    if (m) keys.push(m[1]);
  }
  return keys;
}

// Rule 0 — the manifest validates against the FORMAT schema. This pair lived
// un-checked here for a year (the validation rule existed only in the docs fork's
// port), which is how the schema could lack the `themes`/`pageVariants` blocks the
// manifest already shipped (R3-661): nothing on this side ever read the two together.
// The schema is viewer-generic by contract — a Lodestar-shaped manifest must validate
// through it — so a drift here is a broken promise to every second viewer.
//
// It runs FIRST, and it HALTS: every later rule assumes the shape this one enforces,
// so a rejected manifest reports the schema verdict and stops — never a raw TypeError
// from a rule that trusted the shape (a missing `components`, a null entry, …).
// Extracted pure so the self-test can drive planted manifests through it.
const schema = JSON.parse((0, _nodeFs.readFileSync)((0, _nodePath.join)(root, 'viewer-manifest.schema.json'), 'utf8'));
function schemaErrors(m) {
  const ajv = new Ajv({
    logger: false
  });
  const validate = ajv.compile(schema);
  return validate(m) ? [] : [ajv.errorsText(validate.errors)];
}
{
  const rule0 = schemaErrors(manifest);
  if (rule0.length) {
    console.error(`FAIL manifest ↔ reality (${rule0.length}):\n  manifest fails viewer-manifest.schema.json: ${rule0.join('\n  ')}`);
    process.exit(1);
  }
}
const errors = [];
const exported = new Set(groveMdxKeys(source));
const declared = new Set(Object.keys(manifest.components));
for (const name of exported) {
  if (!declared.has(name)) {
    errors.push(`  ${name} — registered in GROVE_MDX but NOT in the manifest. A corpus can use it and ` + `a checker will flag it; a shell cannot override it. Declare it, or make it internal ` + `by removing it from GROVE_MDX.`);
  }
}
for (const name of declared) {
  if (manifest.components[name].tier === 'corpus') continue; // declared by a corpus, not here
  if (!exported.has(name)) {
    errors.push(`  ${name} — declared in the manifest but NOT registered in GROVE_MDX. A corpus using ` + `it renders nothing, and a shell overriding it overrides a component that never runs.`);
  }
}

// The viewer identity must match the package it ships in, or a shell resolving the
// manifest by package name gets someone else's contract.
const pkg = JSON.parse((0, _nodeFs.readFileSync)((0, _nodePath.join)(root, 'package.json'), 'utf8'));
if (manifest.viewer.name !== pkg.name) {
  errors.push(`  viewer.name "${manifest.viewer.name}" ≠ package.json name "${pkg.name}".`);
}
const provides = (pkg['immediately.run']?.provides ?? []).map(p => p.task);
if (manifest.viewer.task && !provides.includes(manifest.viewer.task)) {
  errors.push(`  viewer.task "${manifest.viewer.task}" is not in package.json immediately.run.provides ` + `(${provides.join(', ') || 'none'}).`);
}

// Every export must be reachable, or a shell's import fails at compose time rather than here.
for (const [subpath, target] of Object.entries(pkg.exports ?? {})) {
  try {
    (0, _nodeFs.readFileSync)((0, _nodePath.join)(root, target));
  } catch {
    errors.push(`  exports["${subpath}"] → ${target} does not exist.`);
  }
}

// ── R3-309 — the layout-catalogue gates ─────────────────────────────────────
//
// The manifest's `layouts` entries and the files under content/_layouts/ must agree
// in BOTH directions (the same two-way rule the components section enforces), and a
// shipping starter's OWN frontmatter must carry the `layoutRole` its entry declares.
// That is the job the field was given: it sat unread in the sample layouts for a
// year, and "an inert field in a file people copy is a field people will copy".

const LAYOUTS_DIR = (0, _nodePath.join)(root, 'content', '_layouts');

/** The frontmatter block of a starter file, as key → value (scalars only — that is all a
 *  starter declares). */
function frontmatterOf(file) {
  const src = (0, _nodeFs.readFileSync)(file, 'utf8');
  const m = src.match(/^---\n([\s\S]*?)\n---/);
  const fm = {};
  if (m) for (const line of m[1].split('\n')) {
    const kv = line.match(/^(\w+):\s*(.+)$/);
    if (kv) fm[kv[1]] = kv[2].trim().replace(/^['"]|['"]$/g, '');
  }
  return fm;
}

/** The layouts rule, extracted so the self-test can drive planted corpora through it
 *  (R3-662). `starters` is the id → on-disk file map — kept, never re-derived, so a
 *  `.md` starter is read back as `.md`. A `ships: true` entry whose file is missing
 *  is RECORDED and skipped — the collected verdict, never an ENOENT stack. */
function layoutRuleErrors(declaredLayouts, starters) {
  const ruleErrors = [];
  for (const [id, entry] of Object.entries(declaredLayouts)) {
    if (entry.ships && !starters.has(id)) {
      ruleErrors.push(`  layouts.${id} — declared ships:true but content/_layouts/${id} starter does not exist.`);
      continue; // recorded; do not read a file that does not exist
    }
    if (entry.ships) {
      const starter = starters.get(id);
      // Unreadable/ambiguous starters are reported by the caller (the recorded
      // verdict, never a stack) — the rule reads only what readStarters parsed.
      if (starter.error) continue;
      const fm = starter.frontmatter;
      if (fm.layoutRole !== entry.layoutRole) {
        ruleErrors.push(`  layouts.${id} — manifest says layoutRole:${entry.layoutRole}, the starter's frontmatter says ` + `${JSON.stringify(fm.layoutRole)}. The two must agree.`);
      }
      if (fm.nav && fm.nav !== 'top' && fm.nav !== 'side') {
        ruleErrors.push(`  layouts.${id} — nav:${fm.nav} is neither 'top' nor 'side'; resolveNavMode would silently fall back.`);
      }
    }
  }
  for (const [id, starter] of starters) {
    // An unreadable/ambiguous starter already has its recorded verdict — and
    // the orphan verdict cannot claim an unreadable file 'renders'.
    if (starter.error) continue;
    if (!declaredLayouts[id]) {
      ruleErrors.push(`  ${starter.displayPath} — a starter on disk with NO manifest entry. It renders (when ` + `copied) but nothing declares it: a corpus checker cannot find it and an agent cannot discover it.`);
    }
  }
  return ruleErrors;
}

/** Read content/_layouts/ once, keeping the id → on-disk filename mapping.
 *  Per-file read failures are RECORDED on the entry (the verdict is the point —
 *  never a raw stack), and a same-stem .md/.mdx pair records an ambiguous
 *  entry: which frontmatter would be judged must never depend on readdir order. */
function readStarters(layoutsDir) {
  const starters = new Map();
  if (!(0, _nodeFs.existsSync)(layoutsDir)) return starters;
  for (const e of (0, _nodeFs.readdirSync)(layoutsDir, {
    withFileTypes: true
  })) {
    if (e.isFile() && /\.mdx?$/.test(e.name)) {
      const file = (0, _nodePath.join)(layoutsDir, e.name);
      const id = e.name.replace(/\.mdx?$/, '');
      const displayPath = `content/_layouts/${e.name}`;
      if (starters.has(id)) {
        starters.set(id, {
          displayPath: `${starters.get(id).displayPath} + ${displayPath}`,
          error: `ambiguous starter id '${id}' — both ${starters.get(id).displayPath} and ${displayPath} exist`,
          ambiguous: true
        });
        continue;
      }
      try {
        starters.set(id, {
          displayPath,
          frontmatter: frontmatterOf(file)
        });
      } catch (err) {
        starters.set(id, {
          displayPath,
          error: err.code ?? err.message
        });
      }
    }
  }
  return starters;
}
const declaredLayouts = manifest.layouts ?? {};
const starters = readStarters(LAYOUTS_DIR);
for (const [id, starter] of starters) {
  if (starter.error) {
    errors.push(`  ${starter.displayPath} — ${starter.error}.`);
  }
}
errors.push(...layoutRuleErrors(declaredLayouts, starters));

// Collection shapes ride on engine components; a declared component that is not in the
// vocabulary is the same lie as an undeclared one in the components section.
const collections = manifest.collections ?? {};
for (const [id, entry] of Object.entries(collections)) {
  if (entry.component && !exported.has(entry.component)) {
    errors.push(`  collections.${id} — rides on "${entry.component}", which is not registered in GROVE_MDX. ` + `A corpus writing the documented call renders nothing.`);
  }
  for (const [prop, value] of Object.entries(entry.props ?? {})) {
    if (/^\{.*\}$/.test(value)) {
      errors.push(`  collections.${id} — props.${prop} is an EXPRESSION (${value}). The interpreter drops it silently.`);
    }
  }
}
if (errors.length) {
  console.error(`FAIL manifest ↔ reality (${errors.length}):\n${errors.join('\n')}`);
  process.exit(1);
}
console.log(`OK ${manifest.viewer.name}: ${declared.size} components declared, ` + `${[...declared].filter(n => manifest.components[n].overridable).length} overridable, ` + `${Object.keys(pkg.exports ?? {}).length} export subpaths resolve, ` + `${starters.size} layout starter(s), ${Object.keys(collections).length} collection shape(s).`);

// ── self-test ─────────────────────────────────────────────────────────────────
// Rule 0's teeth, planted rather than asserted (the reviewer was right to demand the
// committed form of the manual fault injection): a gate nothing has watched reject
// anything is an assumption. Driven through `schemaErrors` — the same function the
// gate runs — so the cases move when the rule does.
const selfTest = () => {
  const cases = [];
  cases.push(['the shipped pair validates', () => schemaErrors(manifest).length === 0]);
  cases.push(['a planted top-level key fails', () => schemaErrors({
    ...manifest,
    bogusKey: 'x'
  }).length > 0]);
  cases.push(['a manifest missing components fails with the schema verdict, not a crash', () => {
    const {
      components,
      ...rest
    } = manifest;
    return schemaErrors(rest).length > 0;
  }]);
  // The viewer-generic contract (spec §5.1): a Lodestar-shaped manifest — node/edge
  // vocabulary, its own themes — validates through the same schema.
  const lodestar = {
    schemaVersion: 1,
    viewer: {
      name: '@fictional/lodestar',
      kind: 'mindmap',
      task: 'open-mindmap'
    },
    components: {
      MindNode: {
        tier: 'engine',
        overridable: true,
        sanitizing: false,
        props: {
          label: 'string?',
          depth: 'number?'
        },
        summary: 'A node.'
      },
      MindEdge: {
        tier: 'engine',
        overridable: true,
        sanitizing: false,
        props: {
          from: 'string',
          to: 'string'
        },
        summary: 'An edge.'
      },
      Legend: {
        tier: 'chrome',
        overridable: true,
        sanitizing: false,
        props: {},
        summary: 'Map chrome.'
      },
      RiskBadge: {
        tier: 'corpus',
        overridable: true,
        sanitizing: false,
        props: {},
        summary: 'One corpus convention.'
      }
    },
    frontmatter: {
      engine: ['view', 'collapsed'],
      corpusTooling: ['risk'],
      passThrough: true
    }
  };
  cases.push(['a Lodestar manifest validates through the same schema', () => schemaErrors(lodestar).length === 0]);
  cases.push(['a manifest with an unknown tier is rejected', () => schemaErrors({
    ...lodestar,
    components: {
      X: {
        tier: 'galaxy',
        overridable: true
      }
    }
  }).length > 0]);

  // R3-662 — the layouts rule's two crash triggers, planted and driven through the
  // REAL read path (readStarters over a tmp corpus). Before the fix both died on a
  // raw ENOENT after the rule had already recorded its verdict; the verdict is the
  // whole point, so these prove "the collected verdict, never a stack".
  const plantCorpus = files => {
    const dir = (0, _nodeFs.mkdtempSync)((0, _nodePath.join)((0, _nodeOs.tmpdir)(), 'grove-layouts-'));
    for (const [name, text] of Object.entries(files)) (0, _nodeFs.writeFileSync)((0, _nodePath.join)(dir, name), text);
    return dir;
  };
  cases.push(['a ships:true entry with a missing starter records the verdict and does NOT crash', () => {
    const dir = plantCorpus({});
    try {
      const errors = layoutRuleErrors({
        ghost: {
          ships: true,
          layoutRole: 'page'
        }
      }, readStarters(dir));
      return errors.length === 1 && errors[0].includes('layouts.ghost') && errors[0].includes('does not exist');
    } finally {
      (0, _nodeFs.rmSync)(dir, {
        recursive: true,
        force: true
      });
    }
  }]);
  cases.push(['a .md starter is read back with its own extension (no fabricated .mdx)', () => {
    // note.md declares layoutRole:page but the manifest says layoutRole:article —
    // the mismatch verdict proves the .md file's own frontmatter was read.
    const dir = plantCorpus({
      'note.md': '---\nlayoutRole: page\n---\n# Note\n'
    });
    try {
      const errors = layoutRuleErrors({
        note: {
          ships: true,
          layoutRole: 'article'
        }
      }, readStarters(dir));
      return errors.length === 1 && errors[0].includes('"page"') && errors[0].includes('layouts.note');
    } finally {
      (0, _nodeFs.rmSync)(dir, {
        recursive: true,
        force: true
      });
    }
  }]);
  cases.push(['an unreadable starter is recorded, never a stack (the EACCES trigger)', () => {
    const dir = plantCorpus({
      'sealed.mdx': '---\nlayoutRole: page\n---\n'
    });
    try {
      (0, _nodeFs.chmodSync)((0, _nodePath.join)(dir, 'sealed.mdx'), 0o000);
      const starters = readStarters(dir);
      const entry = starters.get('sealed');
      return entry && entry.error !== undefined && entry.frontmatter === undefined;
    } finally {
      (0, _nodeFs.chmodSync)((0, _nodePath.join)(dir, 'sealed.mdx'), 0o644);
      (0, _nodeFs.rmSync)(dir, {
        recursive: true,
        force: true
      });
    }
  }]);
  cases.push(['a same-stem .md + .mdx pair records an ambiguous verdict (never readdir roulette)', () => {
    const dir = plantCorpus({
      'twin.md': '---\nlayoutRole: page\n---\n',
      'twin.mdx': '---\nlayoutRole: page\n---\n'
    });
    try {
      const entry = readStarters(dir).get('twin');
      return entry && /ambiguous starter id 'twin'/.test(entry.error ?? '') && entry.error.includes('.md') && entry.error.includes('.mdx');
    } finally {
      (0, _nodeFs.rmSync)(dir, {
        recursive: true,
        force: true
      });
    }
  }]);
  cases.push(['a shipping .md starter whose frontmatter agrees passes', () => {
    const dir = plantCorpus({
      'note.md': '---\nlayoutRole: page\n---\n# Note\n'
    });
    try {
      return layoutRuleErrors({
        note: {
          ships: true,
          layoutRole: 'page'
        }
      }, readStarters(dir)).length === 0;
    } finally {
      (0, _nodeFs.rmSync)(dir, {
        recursive: true,
        force: true
      });
    }
  }]);
  let failed = 0;
  for (const [name, fn] of cases) {
    let pass = false;
    try {
      pass = fn();
    } catch {
      pass = false;
    }
    console.log(`${pass ? '✓' : '✗'} ${name}`);
    if (!pass) failed++;
  }
  console.log(`\n${cases.length - failed}/${cases.length} self-test cases.`);
  return failed === 0;
};
if (process.argv.includes('--self-test')) process.exit(selfTest() ? 0 : 1);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJyZXF1aXJlIiwiX25vZGVGcyIsIl9ub2RlT3MiLCJfbm9kZVVybCIsIl9ub2RlUGF0aCIsIl9ub2RlTW9kdWxlIiwicm9vdCIsImpvaW4iLCJkaXJuYW1lIiwiZmlsZVVSTFRvUGF0aCIsIiRpcl9pbXBvcnRfbWV0YSIsInVybCIsImNyZWF0ZVJlcXVpcmUiLCJBanYiLCJjb25zb2xlIiwiZXJyb3IiLCJwcm9jZXNzIiwiZXhpdCIsIm1hbmlmZXN0IiwiSlNPTiIsInBhcnNlIiwicmVhZEZpbGVTeW5jIiwic291cmNlIiwiYmxhbmtOb25Db2RlIiwic3JjIiwib3V0Iiwic3BsaXQiLCJpIiwiYmxhbmtUbyIsImVuZCIsImxlbmd0aCIsInR3byIsInNsaWNlIiwibmwiLCJpbmRleE9mIiwiY2xvc2UiLCJxdW90ZSIsImoiLCJNYXRoIiwibWluIiwiZ3JvdmVNZHhLZXlzIiwicmF3U3JjIiwic3RhcnQiLCJFcnJvciIsIm9wZW4iLCJkZXB0aCIsImtleXMiLCJuZXN0aW5nIiwibGluZSIsImJlZm9yZSIsImNoIiwibSIsIm1hdGNoIiwicHVzaCIsInNjaGVtYSIsInNjaGVtYUVycm9ycyIsImFqdiIsImxvZ2dlciIsInZhbGlkYXRlIiwiY29tcGlsZSIsImVycm9yc1RleHQiLCJlcnJvcnMiLCJydWxlMCIsImV4cG9ydGVkIiwiU2V0IiwiZGVjbGFyZWQiLCJPYmplY3QiLCJjb21wb25lbnRzIiwibmFtZSIsImhhcyIsInRpZXIiLCJwa2ciLCJ2aWV3ZXIiLCJwcm92aWRlcyIsIm1hcCIsInAiLCJ0YXNrIiwiaW5jbHVkZXMiLCJzdWJwYXRoIiwidGFyZ2V0IiwiZW50cmllcyIsImV4cG9ydHMiLCJMQVlPVVRTX0RJUiIsImZyb250bWF0dGVyT2YiLCJmaWxlIiwiZm0iLCJrdiIsInRyaW0iLCJyZXBsYWNlIiwibGF5b3V0UnVsZUVycm9ycyIsImRlY2xhcmVkTGF5b3V0cyIsInN0YXJ0ZXJzIiwicnVsZUVycm9ycyIsImlkIiwiZW50cnkiLCJzaGlwcyIsInN0YXJ0ZXIiLCJnZXQiLCJmcm9udG1hdHRlciIsImxheW91dFJvbGUiLCJzdHJpbmdpZnkiLCJuYXYiLCJkaXNwbGF5UGF0aCIsInJlYWRTdGFydGVycyIsImxheW91dHNEaXIiLCJNYXAiLCJleGlzdHNTeW5jIiwiZSIsInJlYWRkaXJTeW5jIiwid2l0aEZpbGVUeXBlcyIsImlzRmlsZSIsInRlc3QiLCJzZXQiLCJhbWJpZ3VvdXMiLCJlcnIiLCJjb2RlIiwibWVzc2FnZSIsImxheW91dHMiLCJjb2xsZWN0aW9ucyIsImNvbXBvbmVudCIsInByb3AiLCJ2YWx1ZSIsInByb3BzIiwibG9nIiwic2l6ZSIsImZpbHRlciIsIm4iLCJvdmVycmlkYWJsZSIsInNlbGZUZXN0IiwiY2FzZXMiLCJib2d1c0tleSIsInJlc3QiLCJsb2Rlc3RhciIsInNjaGVtYVZlcnNpb24iLCJraW5kIiwiTWluZE5vZGUiLCJzYW5pdGl6aW5nIiwibGFiZWwiLCJzdW1tYXJ5IiwiTWluZEVkZ2UiLCJmcm9tIiwidG8iLCJMZWdlbmQiLCJSaXNrQmFkZ2UiLCJlbmdpbmUiLCJjb3JwdXNUb29saW5nIiwicGFzc1Rocm91Z2giLCJYIiwicGxhbnRDb3JwdXMiLCJmaWxlcyIsImRpciIsIm1rZHRlbXBTeW5jIiwidG1wZGlyIiwidGV4dCIsIndyaXRlRmlsZVN5bmMiLCJnaG9zdCIsInJtU3luYyIsInJlY3Vyc2l2ZSIsImZvcmNlIiwibm90ZSIsImNobW9kU3luYyIsInVuZGVmaW5lZCIsImZhaWxlZCIsImZuIiwicGFzcyIsImFyZ3YiXSwic291cmNlcyI6WyJjaGVjay1tYW5pZmVzdC5tanMiXSwic291cmNlc0NvbnRlbnQiOlsiIyEvdXNyL2Jpbi9lbnYgbm9kZVxuLy8gVGhlIG1hbmlmZXN0IOKGlCByZWFsaXR5IGdhdGUgKFIzLTI3N2M6IFwidGhlIG1hbmlmZXN0IGlzIHZhbGlkYXRlZCBhZ2FpbnN0IHJlYWxpdHkg4oCUIGFcbi8vIGNvbXBvbmVudCBleHBvcnRlZCBidXQgbWlzc2luZyBmcm9tIHRoZSBtYW5pZmVzdCwgb3IgdmljZSB2ZXJzYSwgZmFpbHMgdGhlIGVuZ2luZSdzIG93blxuLy8gYG5wbSBydW4gdmVyaWZ5YFwiKS5cbi8vXG4vLyBBIG1hbmlmZXN0IHRoYXQgZHJpZnRzIGZyb20gdGhlIGNvZGUgaXMgd29yc2UgdGhhbiBubyBtYW5pZmVzdDogYSBjb3JwdXMgY2hlY2tlciB3b3VsZFxuLy8gZmxhZyBhIGNvbXBvbmVudCB0aGF0IHdvcmtzLCBvciBwYXNzIG9uZSB0aGF0IGRvZXMgbm90LCBhbmQgYSBjb21wb3Npbmcgc2hlbGwgd291bGQgYmVcbi8vIHRvbGQgaXQgbWF5IG92ZXJyaWRlIHNvbWV0aGluZyB0aGF0IG5vIGxvbmdlciBleGlzdHMuIFNvIHRoaXMgcnVucyBpbiBgdmVyaWZ5YCwgYmVmb3JlXG4vLyBsaW50IGFuZCBidWlsZCwgYmVjYXVzZSBpdCBpcyB0aGUgY2hlYXBlc3Qgb2YgdGhlIHRocmVlIGFuZCB0aGUgb25lIHdob3NlIGZhaWx1cmUgaXNcbi8vIG1vc3QgY29uZnVzaW5nIHRvIGRlYnVnIGxhdGVyLlxuLy9cbi8vIEl0IHJlYWRzIEdST1ZFX01EWCdzIGtleXMgYnkgcGFyc2luZyB0aGUgbW9kdWxlIHJhdGhlciB0aGFuIGltcG9ydGluZyBpdCAodGhlIG1vZHVsZVxuLy8gcHVsbHMgaW4gVFNYLCBDU1MgYW5kIHRoZSBTREsg4oCUIG5vdCBsb2FkYWJsZSBmcm9tIHBsYWluIG5vZGUpLCBidXQgaXQgcGFyc2VzIHRoZSBPQkpFQ1Rcbi8vIExJVEVSQUwncyBrZXlzLCBub3QgYSByZWdleCBvdmVyIHRoZSB3aG9sZSBmaWxlLiBUaGF0IGlzIHRoZSBkaXN0aW5jdGlvbiBSMy0yNzdjIGFza3Ncbi8vIGZvcjogcmVmb3JtYXR0aW5nIGBtZHhDb21wb25lbnRzLnRzYCBtdXN0IG5vdCBjaGFuZ2UgdGhlIG91dGNvbWUuXG5cbmltcG9ydCB7IHJlYWRGaWxlU3luYywgcmVhZGRpclN5bmMsIGV4aXN0c1N5bmMsIG1rZHRlbXBTeW5jLCBybVN5bmMsIHdyaXRlRmlsZVN5bmMsIGNobW9kU3luYyB9IGZyb20gJ25vZGU6ZnMnO1xuaW1wb3J0IHsgdG1wZGlyIH0gZnJvbSAnbm9kZTpvcyc7XG5pbXBvcnQgeyBmaWxlVVJMVG9QYXRoIH0gZnJvbSAnbm9kZTp1cmwnO1xuaW1wb3J0IHsgZGlybmFtZSwgam9pbiB9IGZyb20gJ25vZGU6cGF0aCc7XG5pbXBvcnQgeyBjcmVhdGVSZXF1aXJlIH0gZnJvbSAnbm9kZTptb2R1bGUnO1xuXG5jb25zdCByb290ID0gam9pbihkaXJuYW1lKGZpbGVVUkxUb1BhdGgoaW1wb3J0Lm1ldGEudXJsKSksICcuLicpO1xuLy8gYWp2IGFycml2ZXMgdHJhbnNpdGl2ZWx5IHdpdGggZXNsaW50ICh0aGUgc2FtZSBhcnJhbmdlbWVudCBkb2NzJyBzY3JpcHRzIHJlbHkgb24pO1xuLy8gc2F5IHNvIHdoZW4gaXQgaXMgYWJzZW50IHJhdGhlciB0aGFuIGR5aW5nIG9uIGEgYmFyZSBtb2R1bGUtbm90LWZvdW5kLlxuY29uc3QgcmVxdWlyZSA9IGNyZWF0ZVJlcXVpcmUoam9pbihyb290LCAncGFja2FnZS5qc29uJykpO1xuY29uc3QgQWp2ID0gKCgpID0+IHtcbiAgdHJ5IHtcbiAgICByZXR1cm4gcmVxdWlyZSgnYWp2Jyk7XG4gIH0gY2F0Y2gge1xuICAgIGNvbnNvbGUuZXJyb3IoJ2NoZWNrLW1hbmlmZXN0OiBhanYgaXMgbm90IHJlc29sdmFibGUg4oCUIGl0IHJpZGVzIHdpdGggZXNsaW50OyBydW4gbnBtIGluc3RhbGwuJyk7XG4gICAgcHJvY2Vzcy5leGl0KDEpO1xuICB9XG59KSgpO1xuY29uc3QgbWFuaWZlc3QgPSBKU09OLnBhcnNlKHJlYWRGaWxlU3luYyhqb2luKHJvb3QsICd2aWV3ZXIubWFuaWZlc3QuanNvbicpLCAndXRmOCcpKTtcbmNvbnN0IHNvdXJjZSA9IHJlYWRGaWxlU3luYyhqb2luKHJvb3QsICdzcmMvbWR4Q29tcG9uZW50cy50cycpLCAndXRmOCcpO1xuXG4vKipcbiAqIFN0cmlwIGNvbW1lbnRzIGFuZCBzdHJpbmcgbGl0ZXJhbHMsIHJlcGxhY2luZyBlYWNoIHdpdGggZXF1aXZhbGVudC1sZW5ndGggd2hpdGVzcGFjZSBzb1xuICogZXZlcnkgb2Zmc2V0IGluIHRoZSByZXN1bHQgc3RpbGwgbGluZXMgdXAgd2l0aCB0aGUgb3JpZ2luYWwuIEJyYWNlLW1hdGNoaW5nIE1VU1QgcnVuXG4gKiBvdmVyIHRoaXMgYW5kIG5vdCB0aGUgcmF3IHNvdXJjZTogYSBgfWAgaW5zaWRlIGEgY29tbWVudCBvciBhIHN0cmluZyB3b3VsZCBvdGhlcndpc2UgZW5kXG4gKiB0aGUgb2JqZWN0IGxpdGVyYWwgZWFybHksIGFuZCB0aGUgZmFpbHVyZSBtb2RlIGlzIHRoZSB3b3JzdCBraW5kIOKAlCB0aGUgZ2F0ZSByZXBvcnRzIHRoZVxuICogd2hvbGUgbWFuaWZlc3QgYXMgZHJpZnRlZCwgd2hpY2ggcmVhZHMgYXMgXCJ0aGUgbWFuaWZlc3QgaXMgYnJva2VuXCIgcmF0aGVyIHRoYW4gXCJ0aGVcbiAqIHNjYW5uZXIgaXNcIi4gKEZvdW5kIGJ5IHBsYW50aW5nIGEgYH1gLWJlYXJpbmcgY29tbWVudDsgc2VlIHRoZSByZWZvcm1hdHRpbmcgdGVzdC4pXG4gKi9cbmZ1bmN0aW9uIGJsYW5rTm9uQ29kZShzcmMpIHtcbiAgY29uc3Qgb3V0ID0gc3JjLnNwbGl0KCcnKTtcbiAgbGV0IGkgPSAwO1xuICBjb25zdCBibGFua1RvID0gKGVuZCkgPT4ge1xuICAgIGZvciAoOyBpIDwgZW5kICYmIGkgPCBvdXQubGVuZ3RoOyBpKyspIGlmIChvdXRbaV0gIT09ICdcXG4nKSBvdXRbaV0gPSAnICc7XG4gIH07XG4gIHdoaWxlIChpIDwgc3JjLmxlbmd0aCkge1xuICAgIGNvbnN0IHR3byA9IHNyYy5zbGljZShpLCBpICsgMik7XG4gICAgaWYgKHR3byA9PT0gJy8vJykge1xuICAgICAgY29uc3QgbmwgPSBzcmMuaW5kZXhPZignXFxuJywgaSk7XG4gICAgICBibGFua1RvKG5sID09PSAtMSA/IHNyYy5sZW5ndGggOiBubCk7XG4gICAgfSBlbHNlIGlmICh0d28gPT09ICcvKicpIHtcbiAgICAgIGNvbnN0IGNsb3NlID0gc3JjLmluZGV4T2YoJyovJywgaSArIDIpO1xuICAgICAgYmxhbmtUbyhjbG9zZSA9PT0gLTEgPyBzcmMubGVuZ3RoIDogY2xvc2UgKyAyKTtcbiAgICB9IGVsc2UgaWYgKHNyY1tpXSA9PT0gXCInXCIgfHwgc3JjW2ldID09PSAnXCInIHx8IHNyY1tpXSA9PT0gJ2AnKSB7XG4gICAgICBjb25zdCBxdW90ZSA9IHNyY1tpXTtcbiAgICAgIGxldCBqID0gaSArIDE7XG4gICAgICB3aGlsZSAoaiA8IHNyYy5sZW5ndGggJiYgc3JjW2pdICE9PSBxdW90ZSkgaiArPSBzcmNbal0gPT09ICdcXFxcJyA/IDIgOiAxO1xuICAgICAgYmxhbmtUbyhNYXRoLm1pbihqICsgMSwgc3JjLmxlbmd0aCkpO1xuICAgIH0gZWxzZSB7XG4gICAgICBpKys7XG4gICAgfVxuICB9XG4gIHJldHVybiBvdXQuam9pbignJyk7XG59XG5cbi8qKiBUaGUga2V5cyBvZiB0aGUgYGV4cG9ydCBjb25zdCBHUk9WRV9NRFggPSB7IOKApiB9YCBvYmplY3QgbGl0ZXJhbCwgYnJhY2UtbWF0Y2hlZCBvdmVyIHRoZVxuICogIGNvbW1lbnQtIGFuZCBzdHJpbmctYmxhbmtlZCBzb3VyY2Ugc28gcmVmb3JtYXR0aW5nIGNhbm5vdCBjaGFuZ2UgdGhlIG91dGNvbWUuICovXG5mdW5jdGlvbiBncm92ZU1keEtleXMocmF3U3JjKSB7XG4gIGNvbnN0IHNyYyA9IGJsYW5rTm9uQ29kZShyYXdTcmMpO1xuICBjb25zdCBzdGFydCA9IHNyYy5pbmRleE9mKCdleHBvcnQgY29uc3QgR1JPVkVfTURYID0geycpO1xuICBpZiAoc3RhcnQgPT09IC0xKSB0aHJvdyBuZXcgRXJyb3IoJ0dST1ZFX01EWCBvYmplY3QgbGl0ZXJhbCBub3QgZm91bmQgaW4gc3JjL21keENvbXBvbmVudHMudHMnKTtcbiAgY29uc3Qgb3BlbiA9IHNyYy5pbmRleE9mKCd7Jywgc3RhcnQpO1xuICBsZXQgZGVwdGggPSAwO1xuICBsZXQgZW5kID0gLTE7XG4gIGZvciAobGV0IGogPSBvcGVuOyBqIDwgc3JjLmxlbmd0aDsgaisrKSB7XG4gICAgaWYgKHNyY1tqXSA9PT0gJ3snKSBkZXB0aCsrO1xuICAgIGVsc2UgaWYgKHNyY1tqXSA9PT0gJ30nKSB7XG4gICAgICBkZXB0aC0tO1xuICAgICAgaWYgKGRlcHRoID09PSAwKSB7XG4gICAgICAgIGVuZCA9IGo7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICBpZiAoZW5kID09PSAtMSkgdGhyb3cgbmV3IEVycm9yKCdHUk9WRV9NRFggb2JqZWN0IGxpdGVyYWwgaXMgdW50ZXJtaW5hdGVkJyk7XG4gIGNvbnN0IGtleXMgPSBbXTtcbiAgbGV0IG5lc3RpbmcgPSAwO1xuICBmb3IgKGNvbnN0IGxpbmUgb2Ygc3JjLnNsaWNlKG9wZW4gKyAxLCBlbmQpLnNwbGl0KCdcXG4nKSkge1xuICAgIC8vIE9ubHkgVE9QLWxldmVsIGtleXMgYXJlIHRoZSB2b2NhYnVsYXJ5OyBhIG5lc3RlZCBvYmplY3QncyBrZXlzIGFyZSBwcm9wcywgbm90XG4gICAgLy8gY29tcG9uZW50cy5cbiAgICBjb25zdCBiZWZvcmUgPSBuZXN0aW5nO1xuICAgIGZvciAoY29uc3QgY2ggb2YgbGluZSkge1xuICAgICAgaWYgKGNoID09PSAneycgfHwgY2ggPT09ICdbJykgbmVzdGluZysrO1xuICAgICAgZWxzZSBpZiAoY2ggPT09ICd9JyB8fCBjaCA9PT0gJ10nKSBuZXN0aW5nLS07XG4gICAgfVxuICAgIGlmIChiZWZvcmUgIT09IDApIGNvbnRpbnVlO1xuICAgIGNvbnN0IG0gPSBsaW5lLm1hdGNoKC9eXFxzKihbQS1aYS16XyRdW1xcdyRdKilcXHMqWyw6XS8pO1xuICAgIGlmIChtKSBrZXlzLnB1c2gobVsxXSk7XG4gIH1cbiAgcmV0dXJuIGtleXM7XG59XG5cbi8vIFJ1bGUgMCDigJQgdGhlIG1hbmlmZXN0IHZhbGlkYXRlcyBhZ2FpbnN0IHRoZSBGT1JNQVQgc2NoZW1hLiBUaGlzIHBhaXIgbGl2ZWRcbi8vIHVuLWNoZWNrZWQgaGVyZSBmb3IgYSB5ZWFyICh0aGUgdmFsaWRhdGlvbiBydWxlIGV4aXN0ZWQgb25seSBpbiB0aGUgZG9jcyBmb3JrJ3Ncbi8vIHBvcnQpLCB3aGljaCBpcyBob3cgdGhlIHNjaGVtYSBjb3VsZCBsYWNrIHRoZSBgdGhlbWVzYC9gcGFnZVZhcmlhbnRzYCBibG9ja3MgdGhlXG4vLyBtYW5pZmVzdCBhbHJlYWR5IHNoaXBwZWQgKFIzLTY2MSk6IG5vdGhpbmcgb24gdGhpcyBzaWRlIGV2ZXIgcmVhZCB0aGUgdHdvIHRvZ2V0aGVyLlxuLy8gVGhlIHNjaGVtYSBpcyB2aWV3ZXItZ2VuZXJpYyBieSBjb250cmFjdCDigJQgYSBMb2Rlc3Rhci1zaGFwZWQgbWFuaWZlc3QgbXVzdCB2YWxpZGF0ZVxuLy8gdGhyb3VnaCBpdCDigJQgc28gYSBkcmlmdCBoZXJlIGlzIGEgYnJva2VuIHByb21pc2UgdG8gZXZlcnkgc2Vjb25kIHZpZXdlci5cbi8vXG4vLyBJdCBydW5zIEZJUlNULCBhbmQgaXQgSEFMVFM6IGV2ZXJ5IGxhdGVyIHJ1bGUgYXNzdW1lcyB0aGUgc2hhcGUgdGhpcyBvbmUgZW5mb3JjZXMsXG4vLyBzbyBhIHJlamVjdGVkIG1hbmlmZXN0IHJlcG9ydHMgdGhlIHNjaGVtYSB2ZXJkaWN0IGFuZCBzdG9wcyDigJQgbmV2ZXIgYSByYXcgVHlwZUVycm9yXG4vLyBmcm9tIGEgcnVsZSB0aGF0IHRydXN0ZWQgdGhlIHNoYXBlIChhIG1pc3NpbmcgYGNvbXBvbmVudHNgLCBhIG51bGwgZW50cnksIOKApikuXG4vLyBFeHRyYWN0ZWQgcHVyZSBzbyB0aGUgc2VsZi10ZXN0IGNhbiBkcml2ZSBwbGFudGVkIG1hbmlmZXN0cyB0aHJvdWdoIGl0LlxuY29uc3Qgc2NoZW1hID0gSlNPTi5wYXJzZShyZWFkRmlsZVN5bmMoam9pbihyb290LCAndmlld2VyLW1hbmlmZXN0LnNjaGVtYS5qc29uJyksICd1dGY4JykpO1xuZnVuY3Rpb24gc2NoZW1hRXJyb3JzKG0pIHtcbiAgY29uc3QgYWp2ID0gbmV3IEFqdih7IGxvZ2dlcjogZmFsc2UgfSk7XG4gIGNvbnN0IHZhbGlkYXRlID0gYWp2LmNvbXBpbGUoc2NoZW1hKTtcbiAgcmV0dXJuIHZhbGlkYXRlKG0pID8gW10gOiBbYWp2LmVycm9yc1RleHQodmFsaWRhdGUuZXJyb3JzKV07XG59XG57XG4gIGNvbnN0IHJ1bGUwID0gc2NoZW1hRXJyb3JzKG1hbmlmZXN0KTtcbiAgaWYgKHJ1bGUwLmxlbmd0aCkge1xuICAgIGNvbnNvbGUuZXJyb3IoYEZBSUwgbWFuaWZlc3Qg4oaUIHJlYWxpdHkgKCR7cnVsZTAubGVuZ3RofSk6XFxuICBtYW5pZmVzdCBmYWlscyB2aWV3ZXItbWFuaWZlc3Quc2NoZW1hLmpzb246ICR7cnVsZTAuam9pbignXFxuICAnKX1gKTtcbiAgICBwcm9jZXNzLmV4aXQoMSk7XG4gIH1cbn1cblxuY29uc3QgZXJyb3JzID0gW107XG5cbmNvbnN0IGV4cG9ydGVkID0gbmV3IFNldChncm92ZU1keEtleXMoc291cmNlKSk7XG5jb25zdCBkZWNsYXJlZCA9IG5ldyBTZXQoT2JqZWN0LmtleXMobWFuaWZlc3QuY29tcG9uZW50cykpO1xuXG5mb3IgKGNvbnN0IG5hbWUgb2YgZXhwb3J0ZWQpIHtcbiAgaWYgKCFkZWNsYXJlZC5oYXMobmFtZSkpIHtcbiAgICBlcnJvcnMucHVzaChcbiAgICAgIGAgICR7bmFtZX0g4oCUIHJlZ2lzdGVyZWQgaW4gR1JPVkVfTURYIGJ1dCBOT1QgaW4gdGhlIG1hbmlmZXN0LiBBIGNvcnB1cyBjYW4gdXNlIGl0IGFuZCBgICtcbiAgICAgICAgYGEgY2hlY2tlciB3aWxsIGZsYWcgaXQ7IGEgc2hlbGwgY2Fubm90IG92ZXJyaWRlIGl0LiBEZWNsYXJlIGl0LCBvciBtYWtlIGl0IGludGVybmFsIGAgK1xuICAgICAgICBgYnkgcmVtb3ZpbmcgaXQgZnJvbSBHUk9WRV9NRFguYCxcbiAgICApO1xuICB9XG59XG5mb3IgKGNvbnN0IG5hbWUgb2YgZGVjbGFyZWQpIHtcbiAgaWYgKG1hbmlmZXN0LmNvbXBvbmVudHNbbmFtZV0udGllciA9PT0gJ2NvcnB1cycpIGNvbnRpbnVlOyAvLyBkZWNsYXJlZCBieSBhIGNvcnB1cywgbm90IGhlcmVcbiAgaWYgKCFleHBvcnRlZC5oYXMobmFtZSkpIHtcbiAgICBlcnJvcnMucHVzaChcbiAgICAgIGAgICR7bmFtZX0g4oCUIGRlY2xhcmVkIGluIHRoZSBtYW5pZmVzdCBidXQgTk9UIHJlZ2lzdGVyZWQgaW4gR1JPVkVfTURYLiBBIGNvcnB1cyB1c2luZyBgICtcbiAgICAgICAgYGl0IHJlbmRlcnMgbm90aGluZywgYW5kIGEgc2hlbGwgb3ZlcnJpZGluZyBpdCBvdmVycmlkZXMgYSBjb21wb25lbnQgdGhhdCBuZXZlciBydW5zLmAsXG4gICAgKTtcbiAgfVxufVxuXG4vLyBUaGUgdmlld2VyIGlkZW50aXR5IG11c3QgbWF0Y2ggdGhlIHBhY2thZ2UgaXQgc2hpcHMgaW4sIG9yIGEgc2hlbGwgcmVzb2x2aW5nIHRoZVxuLy8gbWFuaWZlc3QgYnkgcGFja2FnZSBuYW1lIGdldHMgc29tZW9uZSBlbHNlJ3MgY29udHJhY3QuXG5jb25zdCBwa2cgPSBKU09OLnBhcnNlKHJlYWRGaWxlU3luYyhqb2luKHJvb3QsICdwYWNrYWdlLmpzb24nKSwgJ3V0ZjgnKSk7XG5pZiAobWFuaWZlc3Qudmlld2VyLm5hbWUgIT09IHBrZy5uYW1lKSB7XG4gIGVycm9ycy5wdXNoKGAgIHZpZXdlci5uYW1lIFwiJHttYW5pZmVzdC52aWV3ZXIubmFtZX1cIiDiiaAgcGFja2FnZS5qc29uIG5hbWUgXCIke3BrZy5uYW1lfVwiLmApO1xufVxuY29uc3QgcHJvdmlkZXMgPSAocGtnWydpbW1lZGlhdGVseS5ydW4nXT8ucHJvdmlkZXMgPz8gW10pLm1hcCgocCkgPT4gcC50YXNrKTtcbmlmIChtYW5pZmVzdC52aWV3ZXIudGFzayAmJiAhcHJvdmlkZXMuaW5jbHVkZXMobWFuaWZlc3Qudmlld2VyLnRhc2spKSB7XG4gIGVycm9ycy5wdXNoKFxuICAgIGAgIHZpZXdlci50YXNrIFwiJHttYW5pZmVzdC52aWV3ZXIudGFza31cIiBpcyBub3QgaW4gcGFja2FnZS5qc29uIGltbWVkaWF0ZWx5LnJ1bi5wcm92aWRlcyBgICtcbiAgICAgIGAoJHtwcm92aWRlcy5qb2luKCcsICcpIHx8ICdub25lJ30pLmAsXG4gICk7XG59XG5cbi8vIEV2ZXJ5IGV4cG9ydCBtdXN0IGJlIHJlYWNoYWJsZSwgb3IgYSBzaGVsbCdzIGltcG9ydCBmYWlscyBhdCBjb21wb3NlIHRpbWUgcmF0aGVyIHRoYW4gaGVyZS5cbmZvciAoY29uc3QgW3N1YnBhdGgsIHRhcmdldF0gb2YgT2JqZWN0LmVudHJpZXMocGtnLmV4cG9ydHMgPz8ge30pKSB7XG4gIHRyeSB7XG4gICAgcmVhZEZpbGVTeW5jKGpvaW4ocm9vdCwgdGFyZ2V0KSk7XG4gIH0gY2F0Y2gge1xuICAgIGVycm9ycy5wdXNoKGAgIGV4cG9ydHNbXCIke3N1YnBhdGh9XCJdIOKGkiAke3RhcmdldH0gZG9lcyBub3QgZXhpc3QuYCk7XG4gIH1cbn1cblxuLy8g4pSA4pSAIFIzLTMwOSDigJQgdGhlIGxheW91dC1jYXRhbG9ndWUgZ2F0ZXMg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4vL1xuLy8gVGhlIG1hbmlmZXN0J3MgYGxheW91dHNgIGVudHJpZXMgYW5kIHRoZSBmaWxlcyB1bmRlciBjb250ZW50L19sYXlvdXRzLyBtdXN0IGFncmVlXG4vLyBpbiBCT1RIIGRpcmVjdGlvbnMgKHRoZSBzYW1lIHR3by13YXkgcnVsZSB0aGUgY29tcG9uZW50cyBzZWN0aW9uIGVuZm9yY2VzKSwgYW5kIGFcbi8vIHNoaXBwaW5nIHN0YXJ0ZXIncyBPV04gZnJvbnRtYXR0ZXIgbXVzdCBjYXJyeSB0aGUgYGxheW91dFJvbGVgIGl0cyBlbnRyeSBkZWNsYXJlcy5cbi8vIFRoYXQgaXMgdGhlIGpvYiB0aGUgZmllbGQgd2FzIGdpdmVuOiBpdCBzYXQgdW5yZWFkIGluIHRoZSBzYW1wbGUgbGF5b3V0cyBmb3IgYVxuLy8geWVhciwgYW5kIFwiYW4gaW5lcnQgZmllbGQgaW4gYSBmaWxlIHBlb3BsZSBjb3B5IGlzIGEgZmllbGQgcGVvcGxlIHdpbGwgY29weVwiLlxuXG5jb25zdCBMQVlPVVRTX0RJUiA9IGpvaW4ocm9vdCwgJ2NvbnRlbnQnLCAnX2xheW91dHMnKTtcblxuLyoqIFRoZSBmcm9udG1hdHRlciBibG9jayBvZiBhIHN0YXJ0ZXIgZmlsZSwgYXMga2V5IOKGkiB2YWx1ZSAoc2NhbGFycyBvbmx5IOKAlCB0aGF0IGlzIGFsbCBhXG4gKiAgc3RhcnRlciBkZWNsYXJlcykuICovXG5mdW5jdGlvbiBmcm9udG1hdHRlck9mKGZpbGUpIHtcbiAgY29uc3Qgc3JjID0gcmVhZEZpbGVTeW5jKGZpbGUsICd1dGY4Jyk7XG4gIGNvbnN0IG0gPSBzcmMubWF0Y2goL14tLS1cXG4oW1xcc1xcU10qPylcXG4tLS0vKTtcbiAgY29uc3QgZm0gPSB7fTtcbiAgaWYgKG0pIGZvciAoY29uc3QgbGluZSBvZiBtWzFdLnNwbGl0KCdcXG4nKSkge1xuICAgIGNvbnN0IGt2ID0gbGluZS5tYXRjaCgvXihcXHcrKTpcXHMqKC4rKSQvKTtcbiAgICBpZiAoa3YpIGZtW2t2WzFdXSA9IGt2WzJdLnRyaW0oKS5yZXBsYWNlKC9eWydcIl18WydcIl0kL2csICcnKTtcbiAgfVxuICByZXR1cm4gZm07XG59XG5cbi8qKiBUaGUgbGF5b3V0cyBydWxlLCBleHRyYWN0ZWQgc28gdGhlIHNlbGYtdGVzdCBjYW4gZHJpdmUgcGxhbnRlZCBjb3Jwb3JhIHRocm91Z2ggaXRcbiAqICAoUjMtNjYyKS4gYHN0YXJ0ZXJzYCBpcyB0aGUgaWQg4oaSIG9uLWRpc2sgZmlsZSBtYXAg4oCUIGtlcHQsIG5ldmVyIHJlLWRlcml2ZWQsIHNvIGFcbiAqICBgLm1kYCBzdGFydGVyIGlzIHJlYWQgYmFjayBhcyBgLm1kYC4gQSBgc2hpcHM6IHRydWVgIGVudHJ5IHdob3NlIGZpbGUgaXMgbWlzc2luZ1xuICogIGlzIFJFQ09SREVEIGFuZCBza2lwcGVkIOKAlCB0aGUgY29sbGVjdGVkIHZlcmRpY3QsIG5ldmVyIGFuIEVOT0VOVCBzdGFjay4gKi9cbmZ1bmN0aW9uIGxheW91dFJ1bGVFcnJvcnMoZGVjbGFyZWRMYXlvdXRzLCBzdGFydGVycykge1xuICBjb25zdCBydWxlRXJyb3JzID0gW107XG4gIGZvciAoY29uc3QgW2lkLCBlbnRyeV0gb2YgT2JqZWN0LmVudHJpZXMoZGVjbGFyZWRMYXlvdXRzKSkge1xuICAgIGlmIChlbnRyeS5zaGlwcyAmJiAhc3RhcnRlcnMuaGFzKGlkKSkge1xuICAgICAgcnVsZUVycm9ycy5wdXNoKGAgIGxheW91dHMuJHtpZH0g4oCUIGRlY2xhcmVkIHNoaXBzOnRydWUgYnV0IGNvbnRlbnQvX2xheW91dHMvJHtpZH0gc3RhcnRlciBkb2VzIG5vdCBleGlzdC5gKTtcbiAgICAgIGNvbnRpbnVlOyAvLyByZWNvcmRlZDsgZG8gbm90IHJlYWQgYSBmaWxlIHRoYXQgZG9lcyBub3QgZXhpc3RcbiAgICB9XG4gICAgaWYgKGVudHJ5LnNoaXBzKSB7XG4gICAgICBjb25zdCBzdGFydGVyID0gc3RhcnRlcnMuZ2V0KGlkKTtcbiAgICAgIC8vIFVucmVhZGFibGUvYW1iaWd1b3VzIHN0YXJ0ZXJzIGFyZSByZXBvcnRlZCBieSB0aGUgY2FsbGVyICh0aGUgcmVjb3JkZWRcbiAgICAgIC8vIHZlcmRpY3QsIG5ldmVyIGEgc3RhY2spIOKAlCB0aGUgcnVsZSByZWFkcyBvbmx5IHdoYXQgcmVhZFN0YXJ0ZXJzIHBhcnNlZC5cbiAgICAgIGlmIChzdGFydGVyLmVycm9yKSBjb250aW51ZTtcbiAgICAgIGNvbnN0IGZtID0gc3RhcnRlci5mcm9udG1hdHRlcjtcbiAgICAgIGlmIChmbS5sYXlvdXRSb2xlICE9PSBlbnRyeS5sYXlvdXRSb2xlKSB7XG4gICAgICAgIHJ1bGVFcnJvcnMucHVzaChcbiAgICAgICAgICBgICBsYXlvdXRzLiR7aWR9IOKAlCBtYW5pZmVzdCBzYXlzIGxheW91dFJvbGU6JHtlbnRyeS5sYXlvdXRSb2xlfSwgdGhlIHN0YXJ0ZXIncyBmcm9udG1hdHRlciBzYXlzIGAgK1xuICAgICAgICAgICAgYCR7SlNPTi5zdHJpbmdpZnkoZm0ubGF5b3V0Um9sZSl9LiBUaGUgdHdvIG11c3QgYWdyZWUuYCxcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIGlmIChmbS5uYXYgJiYgZm0ubmF2ICE9PSAndG9wJyAmJiBmbS5uYXYgIT09ICdzaWRlJykge1xuICAgICAgICBydWxlRXJyb3JzLnB1c2goYCAgbGF5b3V0cy4ke2lkfSDigJQgbmF2OiR7Zm0ubmF2fSBpcyBuZWl0aGVyICd0b3AnIG5vciAnc2lkZSc7IHJlc29sdmVOYXZNb2RlIHdvdWxkIHNpbGVudGx5IGZhbGwgYmFjay5gKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgZm9yIChjb25zdCBbaWQsIHN0YXJ0ZXJdIG9mIHN0YXJ0ZXJzKSB7XG4gICAgLy8gQW4gdW5yZWFkYWJsZS9hbWJpZ3VvdXMgc3RhcnRlciBhbHJlYWR5IGhhcyBpdHMgcmVjb3JkZWQgdmVyZGljdCDigJQgYW5kXG4gICAgLy8gdGhlIG9ycGhhbiB2ZXJkaWN0IGNhbm5vdCBjbGFpbSBhbiB1bnJlYWRhYmxlIGZpbGUgJ3JlbmRlcnMnLlxuICAgIGlmIChzdGFydGVyLmVycm9yKSBjb250aW51ZTtcbiAgICBpZiAoIWRlY2xhcmVkTGF5b3V0c1tpZF0pIHtcbiAgICAgIHJ1bGVFcnJvcnMucHVzaChcbiAgICAgICAgYCAgJHtzdGFydGVyLmRpc3BsYXlQYXRofSDigJQgYSBzdGFydGVyIG9uIGRpc2sgd2l0aCBOTyBtYW5pZmVzdCBlbnRyeS4gSXQgcmVuZGVycyAod2hlbiBgICtcbiAgICAgICAgICBgY29waWVkKSBidXQgbm90aGluZyBkZWNsYXJlcyBpdDogYSBjb3JwdXMgY2hlY2tlciBjYW5ub3QgZmluZCBpdCBhbmQgYW4gYWdlbnQgY2Fubm90IGRpc2NvdmVyIGl0LmAsXG4gICAgICApO1xuICAgIH1cbiAgfVxuICByZXR1cm4gcnVsZUVycm9ycztcbn1cblxuLyoqIFJlYWQgY29udGVudC9fbGF5b3V0cy8gb25jZSwga2VlcGluZyB0aGUgaWQg4oaSIG9uLWRpc2sgZmlsZW5hbWUgbWFwcGluZy5cbiAqICBQZXItZmlsZSByZWFkIGZhaWx1cmVzIGFyZSBSRUNPUkRFRCBvbiB0aGUgZW50cnkgKHRoZSB2ZXJkaWN0IGlzIHRoZSBwb2ludCDigJRcbiAqICBuZXZlciBhIHJhdyBzdGFjayksIGFuZCBhIHNhbWUtc3RlbSAubWQvLm1keCBwYWlyIHJlY29yZHMgYW4gYW1iaWd1b3VzXG4gKiAgZW50cnk6IHdoaWNoIGZyb250bWF0dGVyIHdvdWxkIGJlIGp1ZGdlZCBtdXN0IG5ldmVyIGRlcGVuZCBvbiByZWFkZGlyIG9yZGVyLiAqL1xuZnVuY3Rpb24gcmVhZFN0YXJ0ZXJzKGxheW91dHNEaXIpIHtcbiAgY29uc3Qgc3RhcnRlcnMgPSBuZXcgTWFwKCk7XG4gIGlmICghZXhpc3RzU3luYyhsYXlvdXRzRGlyKSkgcmV0dXJuIHN0YXJ0ZXJzO1xuICBmb3IgKGNvbnN0IGUgb2YgcmVhZGRpclN5bmMobGF5b3V0c0RpciwgeyB3aXRoRmlsZVR5cGVzOiB0cnVlIH0pKSB7XG4gICAgaWYgKGUuaXNGaWxlKCkgJiYgL1xcLm1keD8kLy50ZXN0KGUubmFtZSkpIHtcbiAgICAgIGNvbnN0IGZpbGUgPSBqb2luKGxheW91dHNEaXIsIGUubmFtZSk7XG4gICAgICBjb25zdCBpZCA9IGUubmFtZS5yZXBsYWNlKC9cXC5tZHg/JC8sICcnKTtcbiAgICAgIGNvbnN0IGRpc3BsYXlQYXRoID0gYGNvbnRlbnQvX2xheW91dHMvJHtlLm5hbWV9YDtcbiAgICAgIGlmIChzdGFydGVycy5oYXMoaWQpKSB7XG4gICAgICAgIHN0YXJ0ZXJzLnNldChpZCwge1xuICAgICAgICAgIGRpc3BsYXlQYXRoOiBgJHtzdGFydGVycy5nZXQoaWQpLmRpc3BsYXlQYXRofSArICR7ZGlzcGxheVBhdGh9YCxcbiAgICAgICAgICBlcnJvcjogYGFtYmlndW91cyBzdGFydGVyIGlkICcke2lkfScg4oCUIGJvdGggJHtzdGFydGVycy5nZXQoaWQpLmRpc3BsYXlQYXRofSBhbmQgJHtkaXNwbGF5UGF0aH0gZXhpc3RgLFxuICAgICAgICAgIGFtYmlndW91czogdHJ1ZSxcbiAgICAgICAgfSk7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuICAgICAgdHJ5IHtcbiAgICAgICAgc3RhcnRlcnMuc2V0KGlkLCB7IGRpc3BsYXlQYXRoLCBmcm9udG1hdHRlcjogZnJvbnRtYXR0ZXJPZihmaWxlKSB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICBzdGFydGVycy5zZXQoaWQsIHsgZGlzcGxheVBhdGgsIGVycm9yOiBlcnIuY29kZSA/PyBlcnIubWVzc2FnZSB9KTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgcmV0dXJuIHN0YXJ0ZXJzO1xufVxuXG5jb25zdCBkZWNsYXJlZExheW91dHMgPSBtYW5pZmVzdC5sYXlvdXRzID8/IHt9O1xuY29uc3Qgc3RhcnRlcnMgPSByZWFkU3RhcnRlcnMoTEFZT1VUU19ESVIpO1xuZm9yIChjb25zdCBbaWQsIHN0YXJ0ZXJdIG9mIHN0YXJ0ZXJzKSB7XG4gIGlmIChzdGFydGVyLmVycm9yKSB7XG4gICAgZXJyb3JzLnB1c2goYCAgJHtzdGFydGVyLmRpc3BsYXlQYXRofSDigJQgJHtzdGFydGVyLmVycm9yfS5gKTtcbiAgfVxufVxuZXJyb3JzLnB1c2goLi4ubGF5b3V0UnVsZUVycm9ycyhkZWNsYXJlZExheW91dHMsIHN0YXJ0ZXJzKSk7XG5cbi8vIENvbGxlY3Rpb24gc2hhcGVzIHJpZGUgb24gZW5naW5lIGNvbXBvbmVudHM7IGEgZGVjbGFyZWQgY29tcG9uZW50IHRoYXQgaXMgbm90IGluIHRoZVxuLy8gdm9jYWJ1bGFyeSBpcyB0aGUgc2FtZSBsaWUgYXMgYW4gdW5kZWNsYXJlZCBvbmUgaW4gdGhlIGNvbXBvbmVudHMgc2VjdGlvbi5cbmNvbnN0IGNvbGxlY3Rpb25zID0gbWFuaWZlc3QuY29sbGVjdGlvbnMgPz8ge307XG5mb3IgKGNvbnN0IFtpZCwgZW50cnldIG9mIE9iamVjdC5lbnRyaWVzKGNvbGxlY3Rpb25zKSkge1xuICBpZiAoZW50cnkuY29tcG9uZW50ICYmICFleHBvcnRlZC5oYXMoZW50cnkuY29tcG9uZW50KSkge1xuICAgIGVycm9ycy5wdXNoKFxuICAgICAgYCAgY29sbGVjdGlvbnMuJHtpZH0g4oCUIHJpZGVzIG9uIFwiJHtlbnRyeS5jb21wb25lbnR9XCIsIHdoaWNoIGlzIG5vdCByZWdpc3RlcmVkIGluIEdST1ZFX01EWC4gYCArXG4gICAgICAgIGBBIGNvcnB1cyB3cml0aW5nIHRoZSBkb2N1bWVudGVkIGNhbGwgcmVuZGVycyBub3RoaW5nLmAsXG4gICAgKTtcbiAgfVxuICBmb3IgKGNvbnN0IFtwcm9wLCB2YWx1ZV0gb2YgT2JqZWN0LmVudHJpZXMoZW50cnkucHJvcHMgPz8ge30pKSB7XG4gICAgaWYgKC9eXFx7LipcXH0kLy50ZXN0KHZhbHVlKSkge1xuICAgICAgZXJyb3JzLnB1c2goYCAgY29sbGVjdGlvbnMuJHtpZH0g4oCUIHByb3BzLiR7cHJvcH0gaXMgYW4gRVhQUkVTU0lPTiAoJHt2YWx1ZX0pLiBUaGUgaW50ZXJwcmV0ZXIgZHJvcHMgaXQgc2lsZW50bHkuYCk7XG4gICAgfVxuICB9XG59XG5cbmlmIChlcnJvcnMubGVuZ3RoKSB7XG4gIGNvbnNvbGUuZXJyb3IoYEZBSUwgbWFuaWZlc3Qg4oaUIHJlYWxpdHkgKCR7ZXJyb3JzLmxlbmd0aH0pOlxcbiR7ZXJyb3JzLmpvaW4oJ1xcbicpfWApO1xuICBwcm9jZXNzLmV4aXQoMSk7XG59XG5jb25zb2xlLmxvZyhcbiAgYE9LICR7bWFuaWZlc3Qudmlld2VyLm5hbWV9OiAke2RlY2xhcmVkLnNpemV9IGNvbXBvbmVudHMgZGVjbGFyZWQsIGAgK1xuICAgIGAke1suLi5kZWNsYXJlZF0uZmlsdGVyKChuKSA9PiBtYW5pZmVzdC5jb21wb25lbnRzW25dLm92ZXJyaWRhYmxlKS5sZW5ndGh9IG92ZXJyaWRhYmxlLCBgICtcbiAgICBgJHtPYmplY3Qua2V5cyhwa2cuZXhwb3J0cyA/PyB7fSkubGVuZ3RofSBleHBvcnQgc3VicGF0aHMgcmVzb2x2ZSwgYCArXG4gICAgYCR7c3RhcnRlcnMuc2l6ZX0gbGF5b3V0IHN0YXJ0ZXIocyksICR7T2JqZWN0LmtleXMoY29sbGVjdGlvbnMpLmxlbmd0aH0gY29sbGVjdGlvbiBzaGFwZShzKS5gLFxuKTtcblxuLy8g4pSA4pSAIHNlbGYtdGVzdCDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbi8vIFJ1bGUgMCdzIHRlZXRoLCBwbGFudGVkIHJhdGhlciB0aGFuIGFzc2VydGVkICh0aGUgcmV2aWV3ZXIgd2FzIHJpZ2h0IHRvIGRlbWFuZCB0aGVcbi8vIGNvbW1pdHRlZCBmb3JtIG9mIHRoZSBtYW51YWwgZmF1bHQgaW5qZWN0aW9uKTogYSBnYXRlIG5vdGhpbmcgaGFzIHdhdGNoZWQgcmVqZWN0XG4vLyBhbnl0aGluZyBpcyBhbiBhc3N1bXB0aW9uLiBEcml2ZW4gdGhyb3VnaCBgc2NoZW1hRXJyb3JzYCDigJQgdGhlIHNhbWUgZnVuY3Rpb24gdGhlXG4vLyBnYXRlIHJ1bnMg4oCUIHNvIHRoZSBjYXNlcyBtb3ZlIHdoZW4gdGhlIHJ1bGUgZG9lcy5cbmNvbnN0IHNlbGZUZXN0ID0gKCkgPT4ge1xuICBjb25zdCBjYXNlcyA9IFtdO1xuICBjYXNlcy5wdXNoKFsndGhlIHNoaXBwZWQgcGFpciB2YWxpZGF0ZXMnLCAoKSA9PiBzY2hlbWFFcnJvcnMobWFuaWZlc3QpLmxlbmd0aCA9PT0gMF0pO1xuICBjYXNlcy5wdXNoKFsnYSBwbGFudGVkIHRvcC1sZXZlbCBrZXkgZmFpbHMnLCAoKSA9PlxuICAgIHNjaGVtYUVycm9ycyh7IC4uLm1hbmlmZXN0LCBib2d1c0tleTogJ3gnIH0pLmxlbmd0aCA+IDBdKTtcbiAgY2FzZXMucHVzaChbJ2EgbWFuaWZlc3QgbWlzc2luZyBjb21wb25lbnRzIGZhaWxzIHdpdGggdGhlIHNjaGVtYSB2ZXJkaWN0LCBub3QgYSBjcmFzaCcsICgpID0+IHtcbiAgICBjb25zdCB7IGNvbXBvbmVudHMsIC4uLnJlc3QgfSA9IG1hbmlmZXN0O1xuICAgIHJldHVybiBzY2hlbWFFcnJvcnMocmVzdCkubGVuZ3RoID4gMDtcbiAgfV0pO1xuICAvLyBUaGUgdmlld2VyLWdlbmVyaWMgY29udHJhY3QgKHNwZWMgwqc1LjEpOiBhIExvZGVzdGFyLXNoYXBlZCBtYW5pZmVzdCDigJQgbm9kZS9lZGdlXG4gIC8vIHZvY2FidWxhcnksIGl0cyBvd24gdGhlbWVzIOKAlCB2YWxpZGF0ZXMgdGhyb3VnaCB0aGUgc2FtZSBzY2hlbWEuXG4gIGNvbnN0IGxvZGVzdGFyID0ge1xuICAgIHNjaGVtYVZlcnNpb246IDEsXG4gICAgdmlld2VyOiB7IG5hbWU6ICdAZmljdGlvbmFsL2xvZGVzdGFyJywga2luZDogJ21pbmRtYXAnLCB0YXNrOiAnb3Blbi1taW5kbWFwJyB9LFxuICAgIGNvbXBvbmVudHM6IHtcbiAgICAgIE1pbmROb2RlOiB7IHRpZXI6ICdlbmdpbmUnLCBvdmVycmlkYWJsZTogdHJ1ZSwgc2FuaXRpemluZzogZmFsc2UsIHByb3BzOiB7IGxhYmVsOiAnc3RyaW5nPycsIGRlcHRoOiAnbnVtYmVyPycgfSwgc3VtbWFyeTogJ0Egbm9kZS4nIH0sXG4gICAgICBNaW5kRWRnZTogeyB0aWVyOiAnZW5naW5lJywgb3ZlcnJpZGFibGU6IHRydWUsIHNhbml0aXppbmc6IGZhbHNlLCBwcm9wczogeyBmcm9tOiAnc3RyaW5nJywgdG86ICdzdHJpbmcnIH0sIHN1bW1hcnk6ICdBbiBlZGdlLicgfSxcbiAgICAgIExlZ2VuZDogeyB0aWVyOiAnY2hyb21lJywgb3ZlcnJpZGFibGU6IHRydWUsIHNhbml0aXppbmc6IGZhbHNlLCBwcm9wczoge30sIHN1bW1hcnk6ICdNYXAgY2hyb21lLicgfSxcbiAgICAgIFJpc2tCYWRnZTogeyB0aWVyOiAnY29ycHVzJywgb3ZlcnJpZGFibGU6IHRydWUsIHNhbml0aXppbmc6IGZhbHNlLCBwcm9wczoge30sIHN1bW1hcnk6ICdPbmUgY29ycHVzIGNvbnZlbnRpb24uJyB9LFxuICAgIH0sXG4gICAgZnJvbnRtYXR0ZXI6IHsgZW5naW5lOiBbJ3ZpZXcnLCAnY29sbGFwc2VkJ10sIGNvcnB1c1Rvb2xpbmc6IFsncmlzayddLCBwYXNzVGhyb3VnaDogdHJ1ZSB9LFxuICB9O1xuICBjYXNlcy5wdXNoKFsnYSBMb2Rlc3RhciBtYW5pZmVzdCB2YWxpZGF0ZXMgdGhyb3VnaCB0aGUgc2FtZSBzY2hlbWEnLCAoKSA9PiBzY2hlbWFFcnJvcnMobG9kZXN0YXIpLmxlbmd0aCA9PT0gMF0pO1xuICBjYXNlcy5wdXNoKFsnYSBtYW5pZmVzdCB3aXRoIGFuIHVua25vd24gdGllciBpcyByZWplY3RlZCcsICgpID0+XG4gICAgc2NoZW1hRXJyb3JzKHsgLi4ubG9kZXN0YXIsIGNvbXBvbmVudHM6IHsgWDogeyB0aWVyOiAnZ2FsYXh5Jywgb3ZlcnJpZGFibGU6IHRydWUgfSB9IH0pLmxlbmd0aCA+IDBdKTtcblxuICAvLyBSMy02NjIg4oCUIHRoZSBsYXlvdXRzIHJ1bGUncyB0d28gY3Jhc2ggdHJpZ2dlcnMsIHBsYW50ZWQgYW5kIGRyaXZlbiB0aHJvdWdoIHRoZVxuICAvLyBSRUFMIHJlYWQgcGF0aCAocmVhZFN0YXJ0ZXJzIG92ZXIgYSB0bXAgY29ycHVzKS4gQmVmb3JlIHRoZSBmaXggYm90aCBkaWVkIG9uIGFcbiAgLy8gcmF3IEVOT0VOVCBhZnRlciB0aGUgcnVsZSBoYWQgYWxyZWFkeSByZWNvcmRlZCBpdHMgdmVyZGljdDsgdGhlIHZlcmRpY3QgaXMgdGhlXG4gIC8vIHdob2xlIHBvaW50LCBzbyB0aGVzZSBwcm92ZSBcInRoZSBjb2xsZWN0ZWQgdmVyZGljdCwgbmV2ZXIgYSBzdGFja1wiLlxuICBjb25zdCBwbGFudENvcnB1cyA9IChmaWxlcykgPT4ge1xuICAgIGNvbnN0IGRpciA9IG1rZHRlbXBTeW5jKGpvaW4odG1wZGlyKCksICdncm92ZS1sYXlvdXRzLScpKTtcbiAgICBmb3IgKGNvbnN0IFtuYW1lLCB0ZXh0XSBvZiBPYmplY3QuZW50cmllcyhmaWxlcykpIHdyaXRlRmlsZVN5bmMoam9pbihkaXIsIG5hbWUpLCB0ZXh0KTtcbiAgICByZXR1cm4gZGlyO1xuICB9O1xuICBjYXNlcy5wdXNoKFsnYSBzaGlwczp0cnVlIGVudHJ5IHdpdGggYSBtaXNzaW5nIHN0YXJ0ZXIgcmVjb3JkcyB0aGUgdmVyZGljdCBhbmQgZG9lcyBOT1QgY3Jhc2gnLCAoKSA9PiB7XG4gICAgY29uc3QgZGlyID0gcGxhbnRDb3JwdXMoe30pO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBlcnJvcnMgPSBsYXlvdXRSdWxlRXJyb3JzKHsgZ2hvc3Q6IHsgc2hpcHM6IHRydWUsIGxheW91dFJvbGU6ICdwYWdlJyB9IH0sIHJlYWRTdGFydGVycyhkaXIpKTtcbiAgICAgIHJldHVybiBlcnJvcnMubGVuZ3RoID09PSAxICYmIGVycm9yc1swXS5pbmNsdWRlcygnbGF5b3V0cy5naG9zdCcpICYmIGVycm9yc1swXS5pbmNsdWRlcygnZG9lcyBub3QgZXhpc3QnKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgcm1TeW5jKGRpciwgeyByZWN1cnNpdmU6IHRydWUsIGZvcmNlOiB0cnVlIH0pO1xuICAgIH1cbiAgfV0pO1xuICBjYXNlcy5wdXNoKFsnYSAubWQgc3RhcnRlciBpcyByZWFkIGJhY2sgd2l0aCBpdHMgb3duIGV4dGVuc2lvbiAobm8gZmFicmljYXRlZCAubWR4KScsICgpID0+IHtcbiAgICAvLyBub3RlLm1kIGRlY2xhcmVzIGxheW91dFJvbGU6cGFnZSBidXQgdGhlIG1hbmlmZXN0IHNheXMgbGF5b3V0Um9sZTphcnRpY2xlIOKAlFxuICAgIC8vIHRoZSBtaXNtYXRjaCB2ZXJkaWN0IHByb3ZlcyB0aGUgLm1kIGZpbGUncyBvd24gZnJvbnRtYXR0ZXIgd2FzIHJlYWQuXG4gICAgY29uc3QgZGlyID0gcGxhbnRDb3JwdXMoeyAnbm90ZS5tZCc6ICctLS1cXG5sYXlvdXRSb2xlOiBwYWdlXFxuLS0tXFxuIyBOb3RlXFxuJyB9KTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgZXJyb3JzID0gbGF5b3V0UnVsZUVycm9ycyh7IG5vdGU6IHsgc2hpcHM6IHRydWUsIGxheW91dFJvbGU6ICdhcnRpY2xlJyB9IH0sIHJlYWRTdGFydGVycyhkaXIpKTtcbiAgICAgIHJldHVybiBlcnJvcnMubGVuZ3RoID09PSAxICYmIGVycm9yc1swXS5pbmNsdWRlcygnXCJwYWdlXCInKSAmJiBlcnJvcnNbMF0uaW5jbHVkZXMoJ2xheW91dHMubm90ZScpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBybVN5bmMoZGlyLCB7IHJlY3Vyc2l2ZTogdHJ1ZSwgZm9yY2U6IHRydWUgfSk7XG4gICAgfVxuICB9XSk7XG4gIGNhc2VzLnB1c2goWydhbiB1bnJlYWRhYmxlIHN0YXJ0ZXIgaXMgcmVjb3JkZWQsIG5ldmVyIGEgc3RhY2sgKHRoZSBFQUNDRVMgdHJpZ2dlciknLCAoKSA9PiB7XG4gICAgY29uc3QgZGlyID0gcGxhbnRDb3JwdXMoeyAnc2VhbGVkLm1keCc6ICctLS1cXG5sYXlvdXRSb2xlOiBwYWdlXFxuLS0tXFxuJyB9KTtcbiAgICB0cnkge1xuICAgICAgY2htb2RTeW5jKGpvaW4oZGlyLCAnc2VhbGVkLm1keCcpLCAwbzAwMCk7XG4gICAgICBjb25zdCBzdGFydGVycyA9IHJlYWRTdGFydGVycyhkaXIpO1xuICAgICAgY29uc3QgZW50cnkgPSBzdGFydGVycy5nZXQoJ3NlYWxlZCcpO1xuICAgICAgcmV0dXJuIGVudHJ5ICYmIGVudHJ5LmVycm9yICE9PSB1bmRlZmluZWQgJiYgZW50cnkuZnJvbnRtYXR0ZXIgPT09IHVuZGVmaW5lZDtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgY2htb2RTeW5jKGpvaW4oZGlyLCAnc2VhbGVkLm1keCcpLCAwbzY0NCk7XG4gICAgICBybVN5bmMoZGlyLCB7IHJlY3Vyc2l2ZTogdHJ1ZSwgZm9yY2U6IHRydWUgfSk7XG4gICAgfVxuICB9XSk7XG4gIGNhc2VzLnB1c2goWydhIHNhbWUtc3RlbSAubWQgKyAubWR4IHBhaXIgcmVjb3JkcyBhbiBhbWJpZ3VvdXMgdmVyZGljdCAobmV2ZXIgcmVhZGRpciByb3VsZXR0ZSknLCAoKSA9PiB7XG4gICAgY29uc3QgZGlyID0gcGxhbnRDb3JwdXMoe1xuICAgICAgJ3R3aW4ubWQnOiAnLS0tXFxubGF5b3V0Um9sZTogcGFnZVxcbi0tLVxcbicsXG4gICAgICAndHdpbi5tZHgnOiAnLS0tXFxubGF5b3V0Um9sZTogcGFnZVxcbi0tLVxcbicsXG4gICAgfSk7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGVudHJ5ID0gcmVhZFN0YXJ0ZXJzKGRpcikuZ2V0KCd0d2luJyk7XG4gICAgICByZXR1cm4gZW50cnkgJiYgL2FtYmlndW91cyBzdGFydGVyIGlkICd0d2luJy8udGVzdChlbnRyeS5lcnJvciA/PyAnJykgJiYgZW50cnkuZXJyb3IuaW5jbHVkZXMoJy5tZCcpICYmIGVudHJ5LmVycm9yLmluY2x1ZGVzKCcubWR4Jyk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHJtU3luYyhkaXIsIHsgcmVjdXJzaXZlOiB0cnVlLCBmb3JjZTogdHJ1ZSB9KTtcbiAgICB9XG4gIH1dKTtcbiAgY2FzZXMucHVzaChbJ2Egc2hpcHBpbmcgLm1kIHN0YXJ0ZXIgd2hvc2UgZnJvbnRtYXR0ZXIgYWdyZWVzIHBhc3NlcycsICgpID0+IHtcbiAgICBjb25zdCBkaXIgPSBwbGFudENvcnB1cyh7ICdub3RlLm1kJzogJy0tLVxcbmxheW91dFJvbGU6IHBhZ2VcXG4tLS1cXG4jIE5vdGVcXG4nIH0pO1xuICAgIHRyeSB7XG4gICAgICByZXR1cm4gbGF5b3V0UnVsZUVycm9ycyh7IG5vdGU6IHsgc2hpcHM6IHRydWUsIGxheW91dFJvbGU6ICdwYWdlJyB9IH0sIHJlYWRTdGFydGVycyhkaXIpKS5sZW5ndGggPT09IDA7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHJtU3luYyhkaXIsIHsgcmVjdXJzaXZlOiB0cnVlLCBmb3JjZTogdHJ1ZSB9KTtcbiAgICB9XG4gIH1dKTtcblxuICBsZXQgZmFpbGVkID0gMDtcbiAgZm9yIChjb25zdCBbbmFtZSwgZm5dIG9mIGNhc2VzKSB7XG4gICAgbGV0IHBhc3MgPSBmYWxzZTtcbiAgICB0cnkge1xuICAgICAgcGFzcyA9IGZuKCk7XG4gICAgfSBjYXRjaCB7XG4gICAgICBwYXNzID0gZmFsc2U7XG4gICAgfVxuICAgIGNvbnNvbGUubG9nKGAke3Bhc3MgPyAn4pyTJyA6ICfinJcnfSAke25hbWV9YCk7XG4gICAgaWYgKCFwYXNzKSBmYWlsZWQrKztcbiAgfVxuICBjb25zb2xlLmxvZyhgXFxuJHtjYXNlcy5sZW5ndGggLSBmYWlsZWR9LyR7Y2FzZXMubGVuZ3RofSBzZWxmLXRlc3QgY2FzZXMuYCk7XG4gIHJldHVybiBmYWlsZWQgPT09IDA7XG59O1xuXG5pZiAocHJvY2Vzcy5hcmd2LmluY2x1ZGVzKCctLXNlbGYtdGVzdCcpKSBwcm9jZXNzLmV4aXQoc2VsZlRlc3QoKSA/IDAgOiAxKTtcbiJdLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQUE7O0FBQUFBLE9BQUE7QUFBQUEsT0FBQTtBQUVBLElBQUFDLE9BQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLE9BQUEsR0FBQUYsT0FBQTtBQUNBLElBQUFHLFFBQUEsR0FBQUgsT0FBQTtBQUNBLElBQUFJLFNBQUEsR0FBQUosT0FBQTtBQUNBLElBQUFLLFdBQUEsR0FBQUwsT0FBQTtBQUVBLE1BQU1NLElBQUksR0FBRyxJQUFBQyxjQUFJLEVBQUMsSUFBQUMsaUJBQU8sRUFBQyxJQUFBQyxzQkFBYSxFQUFDQyxlQUFBLENBQVlDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDO0FBQ2hFO0FBQ0E7QUFDQSxNQUFNWCxRQUFPLEdBQUcsSUFBQVkseUJBQWEsRUFBQyxJQUFBTCxjQUFJLEVBQUNELElBQUksRUFBRSxjQUFjLENBQUMsQ0FBQztBQUN6RCxNQUFNTyxHQUFHLEdBQUcsQ0FBQyxNQUFNO0VBQ2pCLElBQUk7SUFDRixPQUFPYixRQUFPLENBQUMsS0FBSyxDQUFDO0VBQ3ZCLENBQUMsQ0FBQyxNQUFNO0lBQ05jLE9BQU8sQ0FBQ0MsS0FBSyxDQUFDLGdGQUFnRixDQUFDO0lBQy9GQyxPQUFPLENBQUNDLElBQUksQ0FBQyxDQUFDLENBQUM7RUFDakI7QUFDRixDQUFDLEVBQUUsQ0FBQztBQUNKLE1BQU1DLFFBQVEsR0FBR0MsSUFBSSxDQUFDQyxLQUFLLENBQUMsSUFBQUMsb0JBQVksRUFBQyxJQUFBZCxjQUFJLEVBQUNELElBQUksRUFBRSxzQkFBc0IsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDO0FBQ3JGLE1BQU1nQixNQUFNLEdBQUcsSUFBQUQsb0JBQVksRUFBQyxJQUFBZCxjQUFJLEVBQUNELElBQUksRUFBRSxzQkFBc0IsQ0FBQyxFQUFFLE1BQU0sQ0FBQzs7QUFFdkU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVNpQixZQUFZQSxDQUFDQyxHQUFHLEVBQUU7RUFDekIsTUFBTUMsR0FBRyxHQUFHRCxHQUFHLENBQUNFLEtBQUssQ0FBQyxFQUFFLENBQUM7RUFDekIsSUFBSUMsQ0FBQyxHQUFHLENBQUM7RUFDVCxNQUFNQyxPQUFPLEdBQUlDLEdBQUcsSUFBSztJQUN2QixPQUFPRixDQUFDLEdBQUdFLEdBQUcsSUFBSUYsQ0FBQyxHQUFHRixHQUFHLENBQUNLLE1BQU0sRUFBRUgsQ0FBQyxFQUFFLEVBQUUsSUFBSUYsR0FBRyxDQUFDRSxDQUFDLENBQUMsS0FBSyxJQUFJLEVBQUVGLEdBQUcsQ0FBQ0UsQ0FBQyxDQUFDLEdBQUcsR0FBRztFQUMxRSxDQUFDO0VBQ0QsT0FBT0EsQ0FBQyxHQUFHSCxHQUFHLENBQUNNLE1BQU0sRUFBRTtJQUNyQixNQUFNQyxHQUFHLEdBQUdQLEdBQUcsQ0FBQ1EsS0FBSyxDQUFDTCxDQUFDLEVBQUVBLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDL0IsSUFBSUksR0FBRyxLQUFLLElBQUksRUFBRTtNQUNoQixNQUFNRSxFQUFFLEdBQUdULEdBQUcsQ0FBQ1UsT0FBTyxDQUFDLElBQUksRUFBRVAsQ0FBQyxDQUFDO01BQy9CQyxPQUFPLENBQUNLLEVBQUUsS0FBSyxDQUFDLENBQUMsR0FBR1QsR0FBRyxDQUFDTSxNQUFNLEdBQUdHLEVBQUUsQ0FBQztJQUN0QyxDQUFDLE1BQU0sSUFBSUYsR0FBRyxLQUFLLElBQUksRUFBRTtNQUN2QixNQUFNSSxLQUFLLEdBQUdYLEdBQUcsQ0FBQ1UsT0FBTyxDQUFDLElBQUksRUFBRVAsQ0FBQyxHQUFHLENBQUMsQ0FBQztNQUN0Q0MsT0FBTyxDQUFDTyxLQUFLLEtBQUssQ0FBQyxDQUFDLEdBQUdYLEdBQUcsQ0FBQ00sTUFBTSxHQUFHSyxLQUFLLEdBQUcsQ0FBQyxDQUFDO0lBQ2hELENBQUMsTUFBTSxJQUFJWCxHQUFHLENBQUNHLENBQUMsQ0FBQyxLQUFLLEdBQUcsSUFBSUgsR0FBRyxDQUFDRyxDQUFDLENBQUMsS0FBSyxHQUFHLElBQUlILEdBQUcsQ0FBQ0csQ0FBQyxDQUFDLEtBQUssR0FBRyxFQUFFO01BQzdELE1BQU1TLEtBQUssR0FBR1osR0FBRyxDQUFDRyxDQUFDLENBQUM7TUFDcEIsSUFBSVUsQ0FBQyxHQUFHVixDQUFDLEdBQUcsQ0FBQztNQUNiLE9BQU9VLENBQUMsR0FBR2IsR0FBRyxDQUFDTSxNQUFNLElBQUlOLEdBQUcsQ0FBQ2EsQ0FBQyxDQUFDLEtBQUtELEtBQUssRUFBRUMsQ0FBQyxJQUFJYixHQUFHLENBQUNhLENBQUMsQ0FBQyxLQUFLLElBQUksR0FBRyxDQUFDLEdBQUcsQ0FBQztNQUN2RVQsT0FBTyxDQUFDVSxJQUFJLENBQUNDLEdBQUcsQ0FBQ0YsQ0FBQyxHQUFHLENBQUMsRUFBRWIsR0FBRyxDQUFDTSxNQUFNLENBQUMsQ0FBQztJQUN0QyxDQUFDLE1BQU07TUFDTEgsQ0FBQyxFQUFFO0lBQ0w7RUFDRjtFQUNBLE9BQU9GLEdBQUcsQ0FBQ2xCLElBQUksQ0FBQyxFQUFFLENBQUM7QUFDckI7O0FBRUE7QUFDQTtBQUNBLFNBQVNpQyxZQUFZQSxDQUFDQyxNQUFNLEVBQUU7RUFDNUIsTUFBTWpCLEdBQUcsR0FBR0QsWUFBWSxDQUFDa0IsTUFBTSxDQUFDO0VBQ2hDLE1BQU1DLEtBQUssR0FBR2xCLEdBQUcsQ0FBQ1UsT0FBTyxDQUFDLDRCQUE0QixDQUFDO0VBQ3ZELElBQUlRLEtBQUssS0FBSyxDQUFDLENBQUMsRUFBRSxNQUFNLElBQUlDLEtBQUssQ0FBQyw0REFBNEQsQ0FBQztFQUMvRixNQUFNQyxJQUFJLEdBQUdwQixHQUFHLENBQUNVLE9BQU8sQ0FBQyxHQUFHLEVBQUVRLEtBQUssQ0FBQztFQUNwQyxJQUFJRyxLQUFLLEdBQUcsQ0FBQztFQUNiLElBQUloQixHQUFHLEdBQUcsQ0FBQyxDQUFDO0VBQ1osS0FBSyxJQUFJUSxDQUFDLEdBQUdPLElBQUksRUFBRVAsQ0FBQyxHQUFHYixHQUFHLENBQUNNLE1BQU0sRUFBRU8sQ0FBQyxFQUFFLEVBQUU7SUFDdEMsSUFBSWIsR0FBRyxDQUFDYSxDQUFDLENBQUMsS0FBSyxHQUFHLEVBQUVRLEtBQUssRUFBRSxDQUFDLEtBQ3ZCLElBQUlyQixHQUFHLENBQUNhLENBQUMsQ0FBQyxLQUFLLEdBQUcsRUFBRTtNQUN2QlEsS0FBSyxFQUFFO01BQ1AsSUFBSUEsS0FBSyxLQUFLLENBQUMsRUFBRTtRQUNmaEIsR0FBRyxHQUFHUSxDQUFDO1FBQ1A7TUFDRjtJQUNGO0VBQ0Y7RUFDQSxJQUFJUixHQUFHLEtBQUssQ0FBQyxDQUFDLEVBQUUsTUFBTSxJQUFJYyxLQUFLLENBQUMsMENBQTBDLENBQUM7RUFDM0UsTUFBTUcsSUFBSSxHQUFHLEVBQUU7RUFDZixJQUFJQyxPQUFPLEdBQUcsQ0FBQztFQUNmLEtBQUssTUFBTUMsSUFBSSxJQUFJeEIsR0FBRyxDQUFDUSxLQUFLLENBQUNZLElBQUksR0FBRyxDQUFDLEVBQUVmLEdBQUcsQ0FBQyxDQUFDSCxLQUFLLENBQUMsSUFBSSxDQUFDLEVBQUU7SUFDdkQ7SUFDQTtJQUNBLE1BQU11QixNQUFNLEdBQUdGLE9BQU87SUFDdEIsS0FBSyxNQUFNRyxFQUFFLElBQUlGLElBQUksRUFBRTtNQUNyQixJQUFJRSxFQUFFLEtBQUssR0FBRyxJQUFJQSxFQUFFLEtBQUssR0FBRyxFQUFFSCxPQUFPLEVBQUUsQ0FBQyxLQUNuQyxJQUFJRyxFQUFFLEtBQUssR0FBRyxJQUFJQSxFQUFFLEtBQUssR0FBRyxFQUFFSCxPQUFPLEVBQUU7SUFDOUM7SUFDQSxJQUFJRSxNQUFNLEtBQUssQ0FBQyxFQUFFO0lBQ2xCLE1BQU1FLENBQUMsR0FBR0gsSUFBSSxDQUFDSSxLQUFLLENBQUMsK0JBQStCLENBQUM7SUFDckQsSUFBSUQsQ0FBQyxFQUFFTCxJQUFJLENBQUNPLElBQUksQ0FBQ0YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQ3hCO0VBQ0EsT0FBT0wsSUFBSTtBQUNiOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNUSxNQUFNLEdBQUduQyxJQUFJLENBQUNDLEtBQUssQ0FBQyxJQUFBQyxvQkFBWSxFQUFDLElBQUFkLGNBQUksRUFBQ0QsSUFBSSxFQUFFLDZCQUE2QixDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUM7QUFDMUYsU0FBU2lELFlBQVlBLENBQUNKLENBQUMsRUFBRTtFQUN2QixNQUFNSyxHQUFHLEdBQUcsSUFBSTNDLEdBQUcsQ0FBQztJQUFFNEMsTUFBTSxFQUFFO0VBQU0sQ0FBQyxDQUFDO0VBQ3RDLE1BQU1DLFFBQVEsR0FBR0YsR0FBRyxDQUFDRyxPQUFPLENBQUNMLE1BQU0sQ0FBQztFQUNwQyxPQUFPSSxRQUFRLENBQUNQLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDSyxHQUFHLENBQUNJLFVBQVUsQ0FBQ0YsUUFBUSxDQUFDRyxNQUFNLENBQUMsQ0FBQztBQUM3RDtBQUNBO0VBQ0UsTUFBTUMsS0FBSyxHQUFHUCxZQUFZLENBQUNyQyxRQUFRLENBQUM7RUFDcEMsSUFBSTRDLEtBQUssQ0FBQ2hDLE1BQU0sRUFBRTtJQUNoQmhCLE9BQU8sQ0FBQ0MsS0FBSyxDQUFDLDRCQUE0QitDLEtBQUssQ0FBQ2hDLE1BQU0scURBQXFEZ0MsS0FBSyxDQUFDdkQsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7SUFDaElTLE9BQU8sQ0FBQ0MsSUFBSSxDQUFDLENBQUMsQ0FBQztFQUNqQjtBQUNGO0FBRUEsTUFBTTRDLE1BQU0sR0FBRyxFQUFFO0FBRWpCLE1BQU1FLFFBQVEsR0FBRyxJQUFJQyxHQUFHLENBQUN4QixZQUFZLENBQUNsQixNQUFNLENBQUMsQ0FBQztBQUM5QyxNQUFNMkMsUUFBUSxHQUFHLElBQUlELEdBQUcsQ0FBQ0UsTUFBTSxDQUFDcEIsSUFBSSxDQUFDNUIsUUFBUSxDQUFDaUQsVUFBVSxDQUFDLENBQUM7QUFFMUQsS0FBSyxNQUFNQyxJQUFJLElBQUlMLFFBQVEsRUFBRTtFQUMzQixJQUFJLENBQUNFLFFBQVEsQ0FBQ0ksR0FBRyxDQUFDRCxJQUFJLENBQUMsRUFBRTtJQUN2QlAsTUFBTSxDQUFDUixJQUFJLENBQ1QsS0FBS2UsSUFBSSw4RUFBOEUsR0FDckYsc0ZBQXNGLEdBQ3RGLGdDQUNKLENBQUM7RUFDSDtBQUNGO0FBQ0EsS0FBSyxNQUFNQSxJQUFJLElBQUlILFFBQVEsRUFBRTtFQUMzQixJQUFJL0MsUUFBUSxDQUFDaUQsVUFBVSxDQUFDQyxJQUFJLENBQUMsQ0FBQ0UsSUFBSSxLQUFLLFFBQVEsRUFBRSxTQUFTLENBQUM7RUFDM0QsSUFBSSxDQUFDUCxRQUFRLENBQUNNLEdBQUcsQ0FBQ0QsSUFBSSxDQUFDLEVBQUU7SUFDdkJQLE1BQU0sQ0FBQ1IsSUFBSSxDQUNULEtBQUtlLElBQUksOEVBQThFLEdBQ3JGLHNGQUNKLENBQUM7RUFDSDtBQUNGOztBQUVBO0FBQ0E7QUFDQSxNQUFNRyxHQUFHLEdBQUdwRCxJQUFJLENBQUNDLEtBQUssQ0FBQyxJQUFBQyxvQkFBWSxFQUFDLElBQUFkLGNBQUksRUFBQ0QsSUFBSSxFQUFFLGNBQWMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDO0FBQ3hFLElBQUlZLFFBQVEsQ0FBQ3NELE1BQU0sQ0FBQ0osSUFBSSxLQUFLRyxHQUFHLENBQUNILElBQUksRUFBRTtFQUNyQ1AsTUFBTSxDQUFDUixJQUFJLENBQUMsa0JBQWtCbkMsUUFBUSxDQUFDc0QsTUFBTSxDQUFDSixJQUFJLDBCQUEwQkcsR0FBRyxDQUFDSCxJQUFJLElBQUksQ0FBQztBQUMzRjtBQUNBLE1BQU1LLFFBQVEsR0FBRyxDQUFDRixHQUFHLENBQUMsaUJBQWlCLENBQUMsRUFBRUUsUUFBUSxJQUFJLEVBQUUsRUFBRUMsR0FBRyxDQUFFQyxDQUFDLElBQUtBLENBQUMsQ0FBQ0MsSUFBSSxDQUFDO0FBQzVFLElBQUkxRCxRQUFRLENBQUNzRCxNQUFNLENBQUNJLElBQUksSUFBSSxDQUFDSCxRQUFRLENBQUNJLFFBQVEsQ0FBQzNELFFBQVEsQ0FBQ3NELE1BQU0sQ0FBQ0ksSUFBSSxDQUFDLEVBQUU7RUFDcEVmLE1BQU0sQ0FBQ1IsSUFBSSxDQUNULGtCQUFrQm5DLFFBQVEsQ0FBQ3NELE1BQU0sQ0FBQ0ksSUFBSSxvREFBb0QsR0FDeEYsSUFBSUgsUUFBUSxDQUFDbEUsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLE1BQU0sSUFDckMsQ0FBQztBQUNIOztBQUVBO0FBQ0EsS0FBSyxNQUFNLENBQUN1RSxPQUFPLEVBQUVDLE1BQU0sQ0FBQyxJQUFJYixNQUFNLENBQUNjLE9BQU8sQ0FBQ1QsR0FBRyxDQUFDVSxPQUFPLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRTtFQUNqRSxJQUFJO0lBQ0YsSUFBQTVELG9CQUFZLEVBQUMsSUFBQWQsY0FBSSxFQUFDRCxJQUFJLEVBQUV5RSxNQUFNLENBQUMsQ0FBQztFQUNsQyxDQUFDLENBQUMsTUFBTTtJQUNObEIsTUFBTSxDQUFDUixJQUFJLENBQUMsY0FBY3lCLE9BQU8sUUFBUUMsTUFBTSxrQkFBa0IsQ0FBQztFQUNwRTtBQUNGOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLE1BQU1HLFdBQVcsR0FBRyxJQUFBM0UsY0FBSSxFQUFDRCxJQUFJLEVBQUUsU0FBUyxFQUFFLFVBQVUsQ0FBQzs7QUFFckQ7QUFDQTtBQUNBLFNBQVM2RSxhQUFhQSxDQUFDQyxJQUFJLEVBQUU7RUFDM0IsTUFBTTVELEdBQUcsR0FBRyxJQUFBSCxvQkFBWSxFQUFDK0QsSUFBSSxFQUFFLE1BQU0sQ0FBQztFQUN0QyxNQUFNakMsQ0FBQyxHQUFHM0IsR0FBRyxDQUFDNEIsS0FBSyxDQUFDLHVCQUF1QixDQUFDO0VBQzVDLE1BQU1pQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0VBQ2IsSUFBSWxDLENBQUMsRUFBRSxLQUFLLE1BQU1ILElBQUksSUFBSUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDekIsS0FBSyxDQUFDLElBQUksQ0FBQyxFQUFFO0lBQzFDLE1BQU00RCxFQUFFLEdBQUd0QyxJQUFJLENBQUNJLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQztJQUN4QyxJQUFJa0MsRUFBRSxFQUFFRCxFQUFFLENBQUNDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHQSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUNDLElBQUksQ0FBQyxDQUFDLENBQUNDLE9BQU8sQ0FBQyxjQUFjLEVBQUUsRUFBRSxDQUFDO0VBQzlEO0VBQ0EsT0FBT0gsRUFBRTtBQUNYOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBU0ksZ0JBQWdCQSxDQUFDQyxlQUFlLEVBQUVDLFFBQVEsRUFBRTtFQUNuRCxNQUFNQyxVQUFVLEdBQUcsRUFBRTtFQUNyQixLQUFLLE1BQU0sQ0FBQ0MsRUFBRSxFQUFFQyxLQUFLLENBQUMsSUFBSTVCLE1BQU0sQ0FBQ2MsT0FBTyxDQUFDVSxlQUFlLENBQUMsRUFBRTtJQUN6RCxJQUFJSSxLQUFLLENBQUNDLEtBQUssSUFBSSxDQUFDSixRQUFRLENBQUN0QixHQUFHLENBQUN3QixFQUFFLENBQUMsRUFBRTtNQUNwQ0QsVUFBVSxDQUFDdkMsSUFBSSxDQUFDLGFBQWF3QyxFQUFFLCtDQUErQ0EsRUFBRSwwQkFBMEIsQ0FBQztNQUMzRyxTQUFTLENBQUM7SUFDWjtJQUNBLElBQUlDLEtBQUssQ0FBQ0MsS0FBSyxFQUFFO01BQ2YsTUFBTUMsT0FBTyxHQUFHTCxRQUFRLENBQUNNLEdBQUcsQ0FBQ0osRUFBRSxDQUFDO01BQ2hDO01BQ0E7TUFDQSxJQUFJRyxPQUFPLENBQUNqRixLQUFLLEVBQUU7TUFDbkIsTUFBTXNFLEVBQUUsR0FBR1csT0FBTyxDQUFDRSxXQUFXO01BQzlCLElBQUliLEVBQUUsQ0FBQ2MsVUFBVSxLQUFLTCxLQUFLLENBQUNLLFVBQVUsRUFBRTtRQUN0Q1AsVUFBVSxDQUFDdkMsSUFBSSxDQUNiLGFBQWF3QyxFQUFFLCtCQUErQkMsS0FBSyxDQUFDSyxVQUFVLG1DQUFtQyxHQUMvRixHQUFHaEYsSUFBSSxDQUFDaUYsU0FBUyxDQUFDZixFQUFFLENBQUNjLFVBQVUsQ0FBQyx1QkFDcEMsQ0FBQztNQUNIO01BQ0EsSUFBSWQsRUFBRSxDQUFDZ0IsR0FBRyxJQUFJaEIsRUFBRSxDQUFDZ0IsR0FBRyxLQUFLLEtBQUssSUFBSWhCLEVBQUUsQ0FBQ2dCLEdBQUcsS0FBSyxNQUFNLEVBQUU7UUFDbkRULFVBQVUsQ0FBQ3ZDLElBQUksQ0FBQyxhQUFhd0MsRUFBRSxVQUFVUixFQUFFLENBQUNnQixHQUFHLHdFQUF3RSxDQUFDO01BQzFIO0lBQ0Y7RUFDRjtFQUNBLEtBQUssTUFBTSxDQUFDUixFQUFFLEVBQUVHLE9BQU8sQ0FBQyxJQUFJTCxRQUFRLEVBQUU7SUFDcEM7SUFDQTtJQUNBLElBQUlLLE9BQU8sQ0FBQ2pGLEtBQUssRUFBRTtJQUNuQixJQUFJLENBQUMyRSxlQUFlLENBQUNHLEVBQUUsQ0FBQyxFQUFFO01BQ3hCRCxVQUFVLENBQUN2QyxJQUFJLENBQ2IsS0FBSzJDLE9BQU8sQ0FBQ00sV0FBVyxnRUFBZ0UsR0FDdEYsbUdBQ0osQ0FBQztJQUNIO0VBQ0Y7RUFDQSxPQUFPVixVQUFVO0FBQ25COztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBU1csWUFBWUEsQ0FBQ0MsVUFBVSxFQUFFO0VBQ2hDLE1BQU1iLFFBQVEsR0FBRyxJQUFJYyxHQUFHLENBQUMsQ0FBQztFQUMxQixJQUFJLENBQUMsSUFBQUMsa0JBQVUsRUFBQ0YsVUFBVSxDQUFDLEVBQUUsT0FBT2IsUUFBUTtFQUM1QyxLQUFLLE1BQU1nQixDQUFDLElBQUksSUFBQUMsbUJBQVcsRUFBQ0osVUFBVSxFQUFFO0lBQUVLLGFBQWEsRUFBRTtFQUFLLENBQUMsQ0FBQyxFQUFFO0lBQ2hFLElBQUlGLENBQUMsQ0FBQ0csTUFBTSxDQUFDLENBQUMsSUFBSSxTQUFTLENBQUNDLElBQUksQ0FBQ0osQ0FBQyxDQUFDdkMsSUFBSSxDQUFDLEVBQUU7TUFDeEMsTUFBTWdCLElBQUksR0FBRyxJQUFBN0UsY0FBSSxFQUFDaUcsVUFBVSxFQUFFRyxDQUFDLENBQUN2QyxJQUFJLENBQUM7TUFDckMsTUFBTXlCLEVBQUUsR0FBR2MsQ0FBQyxDQUFDdkMsSUFBSSxDQUFDb0IsT0FBTyxDQUFDLFNBQVMsRUFBRSxFQUFFLENBQUM7TUFDeEMsTUFBTWMsV0FBVyxHQUFHLG9CQUFvQkssQ0FBQyxDQUFDdkMsSUFBSSxFQUFFO01BQ2hELElBQUl1QixRQUFRLENBQUN0QixHQUFHLENBQUN3QixFQUFFLENBQUMsRUFBRTtRQUNwQkYsUUFBUSxDQUFDcUIsR0FBRyxDQUFDbkIsRUFBRSxFQUFFO1VBQ2ZTLFdBQVcsRUFBRSxHQUFHWCxRQUFRLENBQUNNLEdBQUcsQ0FBQ0osRUFBRSxDQUFDLENBQUNTLFdBQVcsTUFBTUEsV0FBVyxFQUFFO1VBQy9EdkYsS0FBSyxFQUFFLHlCQUF5QjhFLEVBQUUsWUFBWUYsUUFBUSxDQUFDTSxHQUFHLENBQUNKLEVBQUUsQ0FBQyxDQUFDUyxXQUFXLFFBQVFBLFdBQVcsUUFBUTtVQUNyR1csU0FBUyxFQUFFO1FBQ2IsQ0FBQyxDQUFDO1FBQ0Y7TUFDRjtNQUNBLElBQUk7UUFDRnRCLFFBQVEsQ0FBQ3FCLEdBQUcsQ0FBQ25CLEVBQUUsRUFBRTtVQUFFUyxXQUFXO1VBQUVKLFdBQVcsRUFBRWYsYUFBYSxDQUFDQyxJQUFJO1FBQUUsQ0FBQyxDQUFDO01BQ3JFLENBQUMsQ0FBQyxPQUFPOEIsR0FBRyxFQUFFO1FBQ1p2QixRQUFRLENBQUNxQixHQUFHLENBQUNuQixFQUFFLEVBQUU7VUFBRVMsV0FBVztVQUFFdkYsS0FBSyxFQUFFbUcsR0FBRyxDQUFDQyxJQUFJLElBQUlELEdBQUcsQ0FBQ0U7UUFBUSxDQUFDLENBQUM7TUFDbkU7SUFDRjtFQUNGO0VBQ0EsT0FBT3pCLFFBQVE7QUFDakI7QUFFQSxNQUFNRCxlQUFlLEdBQUd4RSxRQUFRLENBQUNtRyxPQUFPLElBQUksQ0FBQyxDQUFDO0FBQzlDLE1BQU0xQixRQUFRLEdBQUdZLFlBQVksQ0FBQ3JCLFdBQVcsQ0FBQztBQUMxQyxLQUFLLE1BQU0sQ0FBQ1csRUFBRSxFQUFFRyxPQUFPLENBQUMsSUFBSUwsUUFBUSxFQUFFO0VBQ3BDLElBQUlLLE9BQU8sQ0FBQ2pGLEtBQUssRUFBRTtJQUNqQjhDLE1BQU0sQ0FBQ1IsSUFBSSxDQUFDLEtBQUsyQyxPQUFPLENBQUNNLFdBQVcsTUFBTU4sT0FBTyxDQUFDakYsS0FBSyxHQUFHLENBQUM7RUFDN0Q7QUFDRjtBQUNBOEMsTUFBTSxDQUFDUixJQUFJLENBQUMsR0FBR29DLGdCQUFnQixDQUFDQyxlQUFlLEVBQUVDLFFBQVEsQ0FBQyxDQUFDOztBQUUzRDtBQUNBO0FBQ0EsTUFBTTJCLFdBQVcsR0FBR3BHLFFBQVEsQ0FBQ29HLFdBQVcsSUFBSSxDQUFDLENBQUM7QUFDOUMsS0FBSyxNQUFNLENBQUN6QixFQUFFLEVBQUVDLEtBQUssQ0FBQyxJQUFJNUIsTUFBTSxDQUFDYyxPQUFPLENBQUNzQyxXQUFXLENBQUMsRUFBRTtFQUNyRCxJQUFJeEIsS0FBSyxDQUFDeUIsU0FBUyxJQUFJLENBQUN4RCxRQUFRLENBQUNNLEdBQUcsQ0FBQ3lCLEtBQUssQ0FBQ3lCLFNBQVMsQ0FBQyxFQUFFO0lBQ3JEMUQsTUFBTSxDQUFDUixJQUFJLENBQ1QsaUJBQWlCd0MsRUFBRSxnQkFBZ0JDLEtBQUssQ0FBQ3lCLFNBQVMsMkNBQTJDLEdBQzNGLHVEQUNKLENBQUM7RUFDSDtFQUNBLEtBQUssTUFBTSxDQUFDQyxJQUFJLEVBQUVDLEtBQUssQ0FBQyxJQUFJdkQsTUFBTSxDQUFDYyxPQUFPLENBQUNjLEtBQUssQ0FBQzRCLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFO0lBQzdELElBQUksVUFBVSxDQUFDWCxJQUFJLENBQUNVLEtBQUssQ0FBQyxFQUFFO01BQzFCNUQsTUFBTSxDQUFDUixJQUFJLENBQUMsaUJBQWlCd0MsRUFBRSxZQUFZMkIsSUFBSSxzQkFBc0JDLEtBQUssdUNBQXVDLENBQUM7SUFDcEg7RUFDRjtBQUNGO0FBRUEsSUFBSTVELE1BQU0sQ0FBQy9CLE1BQU0sRUFBRTtFQUNqQmhCLE9BQU8sQ0FBQ0MsS0FBSyxDQUFDLDRCQUE0QjhDLE1BQU0sQ0FBQy9CLE1BQU0sT0FBTytCLE1BQU0sQ0FBQ3RELElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDO0VBQ2xGUyxPQUFPLENBQUNDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDakI7QUFDQUgsT0FBTyxDQUFDNkcsR0FBRyxDQUNULE1BQU16RyxRQUFRLENBQUNzRCxNQUFNLENBQUNKLElBQUksS0FBS0gsUUFBUSxDQUFDMkQsSUFBSSx3QkFBd0IsR0FDbEUsR0FBRyxDQUFDLEdBQUczRCxRQUFRLENBQUMsQ0FBQzRELE1BQU0sQ0FBRUMsQ0FBQyxJQUFLNUcsUUFBUSxDQUFDaUQsVUFBVSxDQUFDMkQsQ0FBQyxDQUFDLENBQUNDLFdBQVcsQ0FBQyxDQUFDakcsTUFBTSxnQkFBZ0IsR0FDekYsR0FBR29DLE1BQU0sQ0FBQ3BCLElBQUksQ0FBQ3lCLEdBQUcsQ0FBQ1UsT0FBTyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUNuRCxNQUFNLDRCQUE0QixHQUNwRSxHQUFHNkQsUUFBUSxDQUFDaUMsSUFBSSx1QkFBdUIxRCxNQUFNLENBQUNwQixJQUFJLENBQUN3RSxXQUFXLENBQUMsQ0FBQ3hGLE1BQU0sdUJBQzFFLENBQUM7O0FBRUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU1rRyxRQUFRLEdBQUdBLENBQUEsS0FBTTtFQUNyQixNQUFNQyxLQUFLLEdBQUcsRUFBRTtFQUNoQkEsS0FBSyxDQUFDNUUsSUFBSSxDQUFDLENBQUMsNEJBQTRCLEVBQUUsTUFBTUUsWUFBWSxDQUFDckMsUUFBUSxDQUFDLENBQUNZLE1BQU0sS0FBSyxDQUFDLENBQUMsQ0FBQztFQUNyRm1HLEtBQUssQ0FBQzVFLElBQUksQ0FBQyxDQUFDLCtCQUErQixFQUFFLE1BQzNDRSxZQUFZLENBQUM7SUFBRSxHQUFHckMsUUFBUTtJQUFFZ0gsUUFBUSxFQUFFO0VBQUksQ0FBQyxDQUFDLENBQUNwRyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7RUFDM0RtRyxLQUFLLENBQUM1RSxJQUFJLENBQUMsQ0FBQywwRUFBMEUsRUFBRSxNQUFNO0lBQzVGLE1BQU07TUFBRWMsVUFBVTtNQUFFLEdBQUdnRTtJQUFLLENBQUMsR0FBR2pILFFBQVE7SUFDeEMsT0FBT3FDLFlBQVksQ0FBQzRFLElBQUksQ0FBQyxDQUFDckcsTUFBTSxHQUFHLENBQUM7RUFDdEMsQ0FBQyxDQUFDLENBQUM7RUFDSDtFQUNBO0VBQ0EsTUFBTXNHLFFBQVEsR0FBRztJQUNmQyxhQUFhLEVBQUUsQ0FBQztJQUNoQjdELE1BQU0sRUFBRTtNQUFFSixJQUFJLEVBQUUscUJBQXFCO01BQUVrRSxJQUFJLEVBQUUsU0FBUztNQUFFMUQsSUFBSSxFQUFFO0lBQWUsQ0FBQztJQUM5RVQsVUFBVSxFQUFFO01BQ1ZvRSxRQUFRLEVBQUU7UUFBRWpFLElBQUksRUFBRSxRQUFRO1FBQUV5RCxXQUFXLEVBQUUsSUFBSTtRQUFFUyxVQUFVLEVBQUUsS0FBSztRQUFFZCxLQUFLLEVBQUU7VUFBRWUsS0FBSyxFQUFFLFNBQVM7VUFBRTVGLEtBQUssRUFBRTtRQUFVLENBQUM7UUFBRTZGLE9BQU8sRUFBRTtNQUFVLENBQUM7TUFDcklDLFFBQVEsRUFBRTtRQUFFckUsSUFBSSxFQUFFLFFBQVE7UUFBRXlELFdBQVcsRUFBRSxJQUFJO1FBQUVTLFVBQVUsRUFBRSxLQUFLO1FBQUVkLEtBQUssRUFBRTtVQUFFa0IsSUFBSSxFQUFFLFFBQVE7VUFBRUMsRUFBRSxFQUFFO1FBQVMsQ0FBQztRQUFFSCxPQUFPLEVBQUU7TUFBVyxDQUFDO01BQ2hJSSxNQUFNLEVBQUU7UUFBRXhFLElBQUksRUFBRSxRQUFRO1FBQUV5RCxXQUFXLEVBQUUsSUFBSTtRQUFFUyxVQUFVLEVBQUUsS0FBSztRQUFFZCxLQUFLLEVBQUUsQ0FBQyxDQUFDO1FBQUVnQixPQUFPLEVBQUU7TUFBYyxDQUFDO01BQ25HSyxTQUFTLEVBQUU7UUFBRXpFLElBQUksRUFBRSxRQUFRO1FBQUV5RCxXQUFXLEVBQUUsSUFBSTtRQUFFUyxVQUFVLEVBQUUsS0FBSztRQUFFZCxLQUFLLEVBQUUsQ0FBQyxDQUFDO1FBQUVnQixPQUFPLEVBQUU7TUFBeUI7SUFDbEgsQ0FBQztJQUNEeEMsV0FBVyxFQUFFO01BQUU4QyxNQUFNLEVBQUUsQ0FBQyxNQUFNLEVBQUUsV0FBVyxDQUFDO01BQUVDLGFBQWEsRUFBRSxDQUFDLE1BQU0sQ0FBQztNQUFFQyxXQUFXLEVBQUU7SUFBSztFQUMzRixDQUFDO0VBQ0RqQixLQUFLLENBQUM1RSxJQUFJLENBQUMsQ0FBQyx1REFBdUQsRUFBRSxNQUFNRSxZQUFZLENBQUM2RSxRQUFRLENBQUMsQ0FBQ3RHLE1BQU0sS0FBSyxDQUFDLENBQUMsQ0FBQztFQUNoSG1HLEtBQUssQ0FBQzVFLElBQUksQ0FBQyxDQUFDLDZDQUE2QyxFQUFFLE1BQ3pERSxZQUFZLENBQUM7SUFBRSxHQUFHNkUsUUFBUTtJQUFFakUsVUFBVSxFQUFFO01BQUVnRixDQUFDLEVBQUU7UUFBRTdFLElBQUksRUFBRSxRQUFRO1FBQUV5RCxXQUFXLEVBQUU7TUFBSztJQUFFO0VBQUUsQ0FBQyxDQUFDLENBQUNqRyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7O0VBRXRHO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsTUFBTXNILFdBQVcsR0FBSUMsS0FBSyxJQUFLO0lBQzdCLE1BQU1DLEdBQUcsR0FBRyxJQUFBQyxtQkFBVyxFQUFDLElBQUFoSixjQUFJLEVBQUMsSUFBQWlKLGNBQU0sRUFBQyxDQUFDLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQztJQUN6RCxLQUFLLE1BQU0sQ0FBQ3BGLElBQUksRUFBRXFGLElBQUksQ0FBQyxJQUFJdkYsTUFBTSxDQUFDYyxPQUFPLENBQUNxRSxLQUFLLENBQUMsRUFBRSxJQUFBSyxxQkFBYSxFQUFDLElBQUFuSixjQUFJLEVBQUMrSSxHQUFHLEVBQUVsRixJQUFJLENBQUMsRUFBRXFGLElBQUksQ0FBQztJQUN0RixPQUFPSCxHQUFHO0VBQ1osQ0FBQztFQUNEckIsS0FBSyxDQUFDNUUsSUFBSSxDQUFDLENBQUMsa0ZBQWtGLEVBQUUsTUFBTTtJQUNwRyxNQUFNaUcsR0FBRyxHQUFHRixXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDM0IsSUFBSTtNQUNGLE1BQU12RixNQUFNLEdBQUc0QixnQkFBZ0IsQ0FBQztRQUFFa0UsS0FBSyxFQUFFO1VBQUU1RCxLQUFLLEVBQUUsSUFBSTtVQUFFSSxVQUFVLEVBQUU7UUFBTztNQUFFLENBQUMsRUFBRUksWUFBWSxDQUFDK0MsR0FBRyxDQUFDLENBQUM7TUFDbEcsT0FBT3pGLE1BQU0sQ0FBQy9CLE1BQU0sS0FBSyxDQUFDLElBQUkrQixNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUNnQixRQUFRLENBQUMsZUFBZSxDQUFDLElBQUloQixNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUNnQixRQUFRLENBQUMsZ0JBQWdCLENBQUM7SUFDM0csQ0FBQyxTQUFTO01BQ1IsSUFBQStFLGNBQU0sRUFBQ04sR0FBRyxFQUFFO1FBQUVPLFNBQVMsRUFBRSxJQUFJO1FBQUVDLEtBQUssRUFBRTtNQUFLLENBQUMsQ0FBQztJQUMvQztFQUNGLENBQUMsQ0FBQyxDQUFDO0VBQ0g3QixLQUFLLENBQUM1RSxJQUFJLENBQUMsQ0FBQyx3RUFBd0UsRUFBRSxNQUFNO0lBQzFGO0lBQ0E7SUFDQSxNQUFNaUcsR0FBRyxHQUFHRixXQUFXLENBQUM7TUFBRSxTQUFTLEVBQUU7SUFBdUMsQ0FBQyxDQUFDO0lBQzlFLElBQUk7TUFDRixNQUFNdkYsTUFBTSxHQUFHNEIsZ0JBQWdCLENBQUM7UUFBRXNFLElBQUksRUFBRTtVQUFFaEUsS0FBSyxFQUFFLElBQUk7VUFBRUksVUFBVSxFQUFFO1FBQVU7TUFBRSxDQUFDLEVBQUVJLFlBQVksQ0FBQytDLEdBQUcsQ0FBQyxDQUFDO01BQ3BHLE9BQU96RixNQUFNLENBQUMvQixNQUFNLEtBQUssQ0FBQyxJQUFJK0IsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDZ0IsUUFBUSxDQUFDLFFBQVEsQ0FBQyxJQUFJaEIsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDZ0IsUUFBUSxDQUFDLGNBQWMsQ0FBQztJQUNsRyxDQUFDLFNBQVM7TUFDUixJQUFBK0UsY0FBTSxFQUFDTixHQUFHLEVBQUU7UUFBRU8sU0FBUyxFQUFFLElBQUk7UUFBRUMsS0FBSyxFQUFFO01BQUssQ0FBQyxDQUFDO0lBQy9DO0VBQ0YsQ0FBQyxDQUFDLENBQUM7RUFDSDdCLEtBQUssQ0FBQzVFLElBQUksQ0FBQyxDQUFDLHVFQUF1RSxFQUFFLE1BQU07SUFDekYsTUFBTWlHLEdBQUcsR0FBR0YsV0FBVyxDQUFDO01BQUUsWUFBWSxFQUFFO0lBQStCLENBQUMsQ0FBQztJQUN6RSxJQUFJO01BQ0YsSUFBQVksaUJBQVMsRUFBQyxJQUFBekosY0FBSSxFQUFDK0ksR0FBRyxFQUFFLFlBQVksQ0FBQyxFQUFFLEtBQUssQ0FBQztNQUN6QyxNQUFNM0QsUUFBUSxHQUFHWSxZQUFZLENBQUMrQyxHQUFHLENBQUM7TUFDbEMsTUFBTXhELEtBQUssR0FBR0gsUUFBUSxDQUFDTSxHQUFHLENBQUMsUUFBUSxDQUFDO01BQ3BDLE9BQU9ILEtBQUssSUFBSUEsS0FBSyxDQUFDL0UsS0FBSyxLQUFLa0osU0FBUyxJQUFJbkUsS0FBSyxDQUFDSSxXQUFXLEtBQUsrRCxTQUFTO0lBQzlFLENBQUMsU0FBUztNQUNSLElBQUFELGlCQUFTLEVBQUMsSUFBQXpKLGNBQUksRUFBQytJLEdBQUcsRUFBRSxZQUFZLENBQUMsRUFBRSxLQUFLLENBQUM7TUFDekMsSUFBQU0sY0FBTSxFQUFDTixHQUFHLEVBQUU7UUFBRU8sU0FBUyxFQUFFLElBQUk7UUFBRUMsS0FBSyxFQUFFO01BQUssQ0FBQyxDQUFDO0lBQy9DO0VBQ0YsQ0FBQyxDQUFDLENBQUM7RUFDSDdCLEtBQUssQ0FBQzVFLElBQUksQ0FBQyxDQUFDLG1GQUFtRixFQUFFLE1BQU07SUFDckcsTUFBTWlHLEdBQUcsR0FBR0YsV0FBVyxDQUFDO01BQ3RCLFNBQVMsRUFBRSw4QkFBOEI7TUFDekMsVUFBVSxFQUFFO0lBQ2QsQ0FBQyxDQUFDO0lBQ0YsSUFBSTtNQUNGLE1BQU10RCxLQUFLLEdBQUdTLFlBQVksQ0FBQytDLEdBQUcsQ0FBQyxDQUFDckQsR0FBRyxDQUFDLE1BQU0sQ0FBQztNQUMzQyxPQUFPSCxLQUFLLElBQUksNkJBQTZCLENBQUNpQixJQUFJLENBQUNqQixLQUFLLENBQUMvRSxLQUFLLElBQUksRUFBRSxDQUFDLElBQUkrRSxLQUFLLENBQUMvRSxLQUFLLENBQUM4RCxRQUFRLENBQUMsS0FBSyxDQUFDLElBQUlpQixLQUFLLENBQUMvRSxLQUFLLENBQUM4RCxRQUFRLENBQUMsTUFBTSxDQUFDO0lBQ3RJLENBQUMsU0FBUztNQUNSLElBQUErRSxjQUFNLEVBQUNOLEdBQUcsRUFBRTtRQUFFTyxTQUFTLEVBQUUsSUFBSTtRQUFFQyxLQUFLLEVBQUU7TUFBSyxDQUFDLENBQUM7SUFDL0M7RUFDRixDQUFDLENBQUMsQ0FBQztFQUNIN0IsS0FBSyxDQUFDNUUsSUFBSSxDQUFDLENBQUMsd0RBQXdELEVBQUUsTUFBTTtJQUMxRSxNQUFNaUcsR0FBRyxHQUFHRixXQUFXLENBQUM7TUFBRSxTQUFTLEVBQUU7SUFBdUMsQ0FBQyxDQUFDO0lBQzlFLElBQUk7TUFDRixPQUFPM0QsZ0JBQWdCLENBQUM7UUFBRXNFLElBQUksRUFBRTtVQUFFaEUsS0FBSyxFQUFFLElBQUk7VUFBRUksVUFBVSxFQUFFO1FBQU87TUFBRSxDQUFDLEVBQUVJLFlBQVksQ0FBQytDLEdBQUcsQ0FBQyxDQUFDLENBQUN4SCxNQUFNLEtBQUssQ0FBQztJQUN4RyxDQUFDLFNBQVM7TUFDUixJQUFBOEgsY0FBTSxFQUFDTixHQUFHLEVBQUU7UUFBRU8sU0FBUyxFQUFFLElBQUk7UUFBRUMsS0FBSyxFQUFFO01BQUssQ0FBQyxDQUFDO0lBQy9DO0VBQ0YsQ0FBQyxDQUFDLENBQUM7RUFFSCxJQUFJSSxNQUFNLEdBQUcsQ0FBQztFQUNkLEtBQUssTUFBTSxDQUFDOUYsSUFBSSxFQUFFK0YsRUFBRSxDQUFDLElBQUlsQyxLQUFLLEVBQUU7SUFDOUIsSUFBSW1DLElBQUksR0FBRyxLQUFLO0lBQ2hCLElBQUk7TUFDRkEsSUFBSSxHQUFHRCxFQUFFLENBQUMsQ0FBQztJQUNiLENBQUMsQ0FBQyxNQUFNO01BQ05DLElBQUksR0FBRyxLQUFLO0lBQ2Q7SUFDQXRKLE9BQU8sQ0FBQzZHLEdBQUcsQ0FBQyxHQUFHeUMsSUFBSSxHQUFHLEdBQUcsR0FBRyxHQUFHLElBQUloRyxJQUFJLEVBQUUsQ0FBQztJQUMxQyxJQUFJLENBQUNnRyxJQUFJLEVBQUVGLE1BQU0sRUFBRTtFQUNyQjtFQUNBcEosT0FBTyxDQUFDNkcsR0FBRyxDQUFDLEtBQUtNLEtBQUssQ0FBQ25HLE1BQU0sR0FBR29JLE1BQU0sSUFBSWpDLEtBQUssQ0FBQ25HLE1BQU0sbUJBQW1CLENBQUM7RUFDMUUsT0FBT29JLE1BQU0sS0FBSyxDQUFDO0FBQ3JCLENBQUM7QUFFRCxJQUFJbEosT0FBTyxDQUFDcUosSUFBSSxDQUFDeEYsUUFBUSxDQUFDLGFBQWEsQ0FBQyxFQUFFN0QsT0FBTyxDQUFDQyxJQUFJLENBQUMrRyxRQUFRLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}