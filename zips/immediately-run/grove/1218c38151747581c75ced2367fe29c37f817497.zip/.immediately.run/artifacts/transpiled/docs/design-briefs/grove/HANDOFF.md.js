var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      li: "li",
      ol: "ol",
      p: "p",
      strong: "strong",
      table: "table",
      tbody: "tbody",
      td: "td",
      th: "th",
      thead: "thead",
      tr: "tr",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "design-handoff-grove-an-mdx-wiki-engine",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "design-handoff-grove-an-mdx-wiki-engine"
      }), "Design handoff — Grove, an MDX wiki engine"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Read this first."
      }), " It's the self-contained on-ramp for designing the visual assets\nneeded to build ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Grove"
      }), ". With this doc plus the briefs in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "./briefs/",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "briefs/"
        })
      }), ", you\nhave everything you need to produce the layouts, components, states, and brand assets."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "For:"
      }), " Claude Design (or any designer, human or agent) generating Grove's UI.\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Source of truth:"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "docs/product-defs/grove.md"
        }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "the product"
        }), " (what Grove is, every feature named\nbelow traces to a section there). Read it before the briefs."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/index.css"
        }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "the tokens"
        }), " (the contract; pull every colour, font, radius,\nshadow from here — don't eyeball)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "CLAUDE.md"
        }), " \"Design system\" — voice + visual foundations for the immediately.run\nbrand Grove lives inside."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "what-youre-designing-in-one-paragraph",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "what-youre-designing-in-one-paragraph"
      }), "What you're designing, in one paragraph"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Grove is a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "wiki / knowledge-garden engine"
      }), " that runs as one immediately.run app: every\nentry is a single MDX file, entries interlink with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "[[wiki-links]]"
      }), ", and the whole site\nrenders in the browser. You are designing ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "the reading experience, the run-mode chrome,\nand Grove's own embedded agent conversation"
      }), " — the entry page, the navigation, the\nindex/collection surfaces, the built-in components, the extensibility views, ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["the embedded\nGrove agent conversation (Grove's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "primary"
        }), " authoring surface)"]
      }), ", every\nempty/loading/error state, a small Grove brand mark, and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "the default theme plus two or\nthree alternate themes"
      }), " that prove Grove can be re-skinned by editing CSS alone. You are\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "not"
      }), " designing a code ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "editor"
      }), " or any sign-in — those stay ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "host"
      }), " surfaces Grove\ndelegates to. You ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "are"
      }), " designing Grove's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "embedded agent conversation"
      }), ": the app's own\ncapability-scoped agent (each ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "CLAUDE.md"
      }), " security model §8), which is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "distinct from, and\nnever a spoof of,"
      }), " the host's agent pane (see ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "Hard constraints"
      }), ")."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "grove-is-an-app-in-the-immediatelyrun-design-system-not-a-new-brand",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "grove-is-an-app-in-the-immediatelyrun-design-system-not-a-new-brand"
      }), "Grove is an app ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "in"
      }), " the immediately.run design system — not a new brand"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Inherit the brand wholesale: cool near-black canvas, the magenta↔violet signature\ngradient, Gabarito display / Public Sans body / Space Mono details, hairline borders, the\nhard-offset hover shadow, sentence case, headlines that end on a period, no emoji. Pull\nall of it from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/index.css"
      }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "CLAUDE.md"
      }), " \"Design system\". The ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "default Grove\ntheme"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "is"
      }), " the immediately.run brand applied to a wiki. (Brief ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "00-foundation"
      }), " lists the\nfew Grove-specific motifs layered on top.)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "audience-rule-every-surface-in-priority-order",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "audience-rule-every-surface-in-priority-order"
      }), "Audience rule (every surface, in priority order)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The platform's audience priority (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "product_values"
      }), " §2/§5/§8), specialised for Grove:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Readers"
        }), " — mobile-first; the reading surface is the product. Typography, link\nintegrity, fast first paint. Most visits never edit."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Authors, including non-technical ones"
        }), " — they mostly ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "ask the agent"
        }), "; the manual\nediting affordance is a fallback. Design clean, discoverable affordances, not an\nauthor console."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Coding agents"
        }), " — semantic landmarks, stable structure, clean headings; agents read\nthe same DOM screen readers do."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "A desktop-human-only design is wrong here."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "the-two-themes-problem-a-core-deliverable-not-a-flourish",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-two-themes-problem-a-core-deliverable-not-a-flourish"
      }), "The two themes problem (a core deliverable, not a flourish)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Grove's product promise is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "CSS-only theming"
      }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "grove.md"
      }), " \"Theming & layout\"). That has\na concrete design consequence: every surface must be built from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "stable, semantic class\nnames + design tokens"
      }), ", never bespoke one-off styling, so a fork can re-skin by editing\nCSS. To prove it, you deliver:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The default theme"
        }), " — on the immediately.run brand."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Two–three alternate themes"
        }), " keyed to the real use cases (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "grove.md"
        }), " \"Representative\nuse cases\"): e.g. a saturated ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Pixies"
        }), " music theme, a soft ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "family-journal"
        }), " theme, a\nparchment-ish ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Lord of the Rings"
        }), " theme — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "same components and DOM, different CSS."
        }), "\nShow the same entry rendered under each, side by side, to make the claim visible."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "the-asset-screen-inventory-what-the-briefs-cover",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-asset-screen-inventory-what-the-briefs-cover"
      }), "The asset / screen inventory (what the briefs cover)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Brief"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Surface"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Why it matters"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "00-foundation"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Grove-specific motifs, the class-name/token contract, the app mark"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "the shared base every other brief assumes"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "01-reading-view"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "the entry page: MDX prose, entry header, backlinks, ToC, wiki-link styling, layout variants"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "the hero surface — readers live here"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "02-shell-navigation-and-authoring"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["top nav, sidebar (tag-driven + namespace tree), footer, search, theme toggle, mobile chrome, the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "edit / new-entry / ask-the-agent affordances"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "how you move through a Grove and hand off to the host"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "03-indexes-and-component-library"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["home/index, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "<DocList>"
            }), " feeds, tag pages, tag cloud, recently-updated, and each built-in component's appearance + an author ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "<Infobox>"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "discovery + the component vocabulary"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "04-extensibility-views"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["the agent-built views: animated ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "timeline"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "family tree"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "directory/table"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "proves the extension surface is designable"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "05-states-and-theming"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["loading skeletons, empty, error/404/broken-link, read-only viewer; the default + alternate ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "theme showcase"
            }), "; the Grove app icon"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "the unglamorous surfaces + the themeability proof"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "06-agent-conversation"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Grove's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "embedded coding-agent conversation"
            }), " — an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "integral, always-present"
            }), " surface with a minimal non-obscuring resting affordance (Safari-URL-bar style; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "iterate"
            }), " the form), proposed-change previews, all states, mobile, the workbench hand-off"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Grove's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "primary authoring surface"
            }), ", baked in front and center"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "08-story-river"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "story river"
            }), ": a TiddlyWiki-style reading mode, built as a separate app on Grove, where links open entries as cards in one column — the river page, the card and its states, open / focus / close motion, the focus-following rail, mobile"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["the pressure test of customizable navigation (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "APP_CUSTOMIZATION_SPEC"
            }), " §6 in the docs repo)"]
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "groves-foundation-is-the-agent-contract-and-its-mostly-invisible-to-you",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "groves-foundation-is-the-agent-contract-and-its-mostly-invisible-to-you"
      }), "Grove's foundation is the agent contract — and it's mostly invisible to you"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Grove's single most important property is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "agent legibility"
      }), ": every instance carries a\nself-describing ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "contract"
      }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "grove.md"
      }), " \"The agent contract\") so a future coding-agent\nsession re-derives how ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "this"
      }), " wiki works. That contract is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "agent-facing infrastructure,\nnot a surface you style"
      }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "GROVE.md"
      }), " and the generated ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: ".grove/manifest.json"
      }), " are read by\nagents, and validation/drift ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "diagnostics surface through the host edit experience"
      }), ",\nwhich Grove must not imitate (see constraint 1). So it changes little about what you draw —\nbut you should know it's the product's centre of gravity, and it has these visual\ntouchpoints to get right:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Make conventions legible ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "in the content itself"
          })]
        }), " — this is why wiki-link states\n(resolved / broken / ambiguous), tag chips, and the namespace tree must read clearly\n(briefs 00–02). The structure a reader sees is the same structure an agent reads."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The embedded Grove agent (brief 06) is the contract's working interface"
        }), " — it's the\ncontract-aware agent that reads and updates ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "GROVE.md"
        }), ". Designing that conversation well\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "is"
        }), " designing how most users touch the contract, even though the contract files\nthemselves stay unstyled."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "An optional \"about this wiki\" / colophon entry"
        }), " — a human-readable rendering of the\ninstance's conventions (what tags mean, what custom components exist) is just a normal\nMDX entry rendered in the reading view; design no special chrome for it, but a tasteful\ncolophon/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "/about"
        }), " pattern is a welcome example. Never render a fake \"diagnostics panel\"\nor host editor chrome."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "hard-constraints-read-before-drawing-anything",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "hard-constraints-read-before-drawing-anything"
      }), "Hard constraints (read before drawing anything)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Don't imitate host chrome — but Grove's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "own"
          }), " agent is allowed"]
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "grove.md"
        }), " security\nmodel + \"Authoring\"; each ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "CLAUDE.md"
        }), " §8). Grove must ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "never"
        }), " render a fake code\neditor, a fake ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "host"
        }), " agent pane, a fake consent dialog, a fake validation/diagnostics\npanel, or a sign-in. When the user edits ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "text"
        }), ", Grove shows an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "edit affordance"
        }), "\nthat ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "hands off"
        }), " to the platform editor — design the affordance, not the editor; contract\nvalidation/drift ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "diagnostics are a host surface"
        }), " too. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The one exception is the\nagent conversation:"
        }), " Grove deliberately ships its ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "own"
        }), " embedded agent (brief 06),\nscoped to Grove's grants via the SDK catalog — so you ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "do"
        }), " design that surface. It must\nbe clearly ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Grove's own"
        }), " (its own placement/identity within the app), never styled to\npass as the host's trusted agent pane, and privileged actions (writes, contribute) still\nroute through the host. Spoofing host surfaces reads as hostile; building your own\ncapability-scoped agent does not."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Reading-first, with the agent as the deliberate always-present exception."
        }), " Run-mode\nUI stays free of ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "editor"
        }), " chrome; the edit affordance is unobtrusive and writable-only;\nthe ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "read-only viewer"
        }), " has no edit affordance at all. But the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "agent communication is\nbaked in, front and center"
        }), " — always present and one gesture away (brief 06). Reconcile\nthe two the way the iOS Safari URL bar does: a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "minimal persistent affordance"
        }), " (thin\nbottom input line / pull tab / icon) that ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "never obscures content on mobile"
        }), " and\nexpands only on demand. Front-and-center, not in-the-way."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Tokens are the contract."
        }), " Colours/fonts/radii/shadows come from\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/index.css"
        }), ". No hard-coded hexes in mockups you'd want a dev to copy."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "No emoji, ever."
        }), " Icons are ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Lucide"
        }), " (16–24px, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "currentColor"
        }), ", ~1.75 stroke) plus\nthe unicode micro-set (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "★ → ● ☀ ☾"
        }), "). Mono micro-labels are the one UPPERCASE-tracked\nexception."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Every dynamic surface needs four states:"
        }), " loading (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "skeleton"
        }), ", not spinner;\n~150ms budget), content, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "empty"
        }), " (designed, never broken), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "error/404"
        }), " (incl. a\nbroken/ambiguous ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "[[wiki-link]]"
        }), " target)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Accessibility AA on both themes"
        }), ", full keyboard operability, visible focus rings\n(the glow ring), semantic landmarks/headings, never state-by-gradient-alone."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "deliverable-per-brief",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "deliverable-per-brief"
      }), "Deliverable per brief"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Layouts at ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "mobile + desktop"
      }), ", all four states, interaction/transition notes (restrained\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "~.14s"
      }), ", no bounce/spring; respect ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "prefers-reduced-motion"
      }), "), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "drafted on-brand copy"
      }), " for\nthe key strings (sentence case, period-terminated headlines, mono ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "/slug"
      }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "#tag"
      }), "\nlabels), a ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["component inventory mapped to the tokens and to the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".grove-*"
        }), " class names"]
      }), "\nin brief ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "00"
      }), ", and — where relevant — the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "routes"
      }), " affordances point at (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "#/slug"
      }), " hash\nroutes within the app; the host hand-off for editing). Call out any forkability/theming\nnote specific to that surface."]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/design-briefs/grove/HANDOFF.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiY29kZSIsImVtIiwiaDEiLCJoMiIsImxpIiwib2wiLCJwIiwic3Ryb25nIiwidGFibGUiLCJ0Ym9keSIsInRkIiwidGgiLCJ0aGVhZCIsInRyIiwidWwiLCJfcHJvdmlkZUNvbXBvbmVudHMiLCJjb21wb25lbnRzIiwiSGVhZGluZ0FuY2hvciIsIl9taXNzaW5nTWR4UmVmZXJlbmNlIiwianN4cyIsIkZyYWdtZW50IiwiY2hpbGRyZW4iLCJpZCIsImpzeCIsImhyZWYiLCJNRFhDb250ZW50Iiwid3JhcHBlciIsIk1EWExheW91dCIsIl9jIiwiY29tcG9uZW50IiwicGxhY2UiLCJFcnJvciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkhBTkRPRkYubWQiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgYTogXCJhXCIsXG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgZW06IFwiZW1cIixcbiAgICBoMTogXCJoMVwiLFxuICAgIGgyOiBcImgyXCIsXG4gICAgbGk6IFwibGlcIixcbiAgICBvbDogXCJvbFwiLFxuICAgIHA6IFwicFwiLFxuICAgIHN0cm9uZzogXCJzdHJvbmdcIixcbiAgICB0YWJsZTogXCJ0YWJsZVwiLFxuICAgIHRib2R5OiBcInRib2R5XCIsXG4gICAgdGQ6IFwidGRcIixcbiAgICB0aDogXCJ0aFwiLFxuICAgIHRoZWFkOiBcInRoZWFkXCIsXG4gICAgdHI6IFwidHJcIixcbiAgICB1bDogXCJ1bFwiLFxuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfSwge0hlYWRpbmdBbmNob3J9ID0gX2NvbXBvbmVudHM7XG4gIGlmICghSGVhZGluZ0FuY2hvcikgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJIZWFkaW5nQW5jaG9yXCIsIHRydWUpO1xuICByZXR1cm4gPD48X2NvbXBvbmVudHMuaDEgaWQ9XCJkZXNpZ24taGFuZG9mZi1ncm92ZS1hbi1tZHgtd2lraS1lbmdpbmVcIj48SGVhZGluZ0FuY2hvciBpZD1cImRlc2lnbi1oYW5kb2ZmLWdyb3ZlLWFuLW1keC13aWtpLWVuZ2luZVwiIC8+e1wiRGVzaWduIGhhbmRvZmYg4oCUIEdyb3ZlLCBhbiBNRFggd2lraSBlbmdpbmVcIn08L19jb21wb25lbnRzLmgxPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUmVhZCB0aGlzIGZpcnN0LlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBJdCdzIHRoZSBzZWxmLWNvbnRhaW5lZCBvbi1yYW1wIGZvciBkZXNpZ25pbmcgdGhlIHZpc3VhbCBhc3NldHNcXG5uZWVkZWQgdG8gYnVpbGQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJHcm92ZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIi4gV2l0aCB0aGlzIGRvYyBwbHVzIHRoZSBicmllZnMgaW4gXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cIi4vYnJpZWZzL1wiPjxfY29tcG9uZW50cy5jb2RlPntcImJyaWVmcy9cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5hPntcIiwgeW91XFxuaGF2ZSBldmVyeXRoaW5nIHlvdSBuZWVkIHRvIHByb2R1Y2UgdGhlIGxheW91dHMsIGNvbXBvbmVudHMsIHN0YXRlcywgYW5kIGJyYW5kIGFzc2V0cy5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJGb3I6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIENsYXVkZSBEZXNpZ24gKG9yIGFueSBkZXNpZ25lciwgaHVtYW4gb3IgYWdlbnQpIGdlbmVyYXRpbmcgR3JvdmUncyBVSS5cXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlNvdXJjZSBvZiB0cnV0aDpcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuY29kZT57XCJkb2NzL3Byb2R1Y3QtZGVmcy9ncm92ZS5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1widGhlIHByb2R1Y3RcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHdoYXQgR3JvdmUgaXMsIGV2ZXJ5IGZlYXR1cmUgbmFtZWRcXG5iZWxvdyB0cmFjZXMgdG8gYSBzZWN0aW9uIHRoZXJlKS4gUmVhZCBpdCBiZWZvcmUgdGhlIGJyaWVmcy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuY29kZT57XCJzcmMvaW5kZXguY3NzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ0aGUgdG9rZW5zXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICh0aGUgY29udHJhY3Q7IHB1bGwgZXZlcnkgY29sb3VyLCBmb250LCByYWRpdXMsXFxuc2hhZG93IGZyb20gaGVyZSDigJQgZG9uJ3QgZXllYmFsbCkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLmNvZGU+e1wiQ0xBVURFLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBcXFwiRGVzaWduIHN5c3RlbVxcXCIg4oCUIHZvaWNlICsgdmlzdWFsIGZvdW5kYXRpb25zIGZvciB0aGUgaW1tZWRpYXRlbHkucnVuXFxuYnJhbmQgR3JvdmUgbGl2ZXMgaW5zaWRlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJ3aGF0LXlvdXJlLWRlc2lnbmluZy1pbi1vbmUtcGFyYWdyYXBoXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJ3aGF0LXlvdXJlLWRlc2lnbmluZy1pbi1vbmUtcGFyYWdyYXBoXCIgLz57XCJXaGF0IHlvdSdyZSBkZXNpZ25pbmcsIGluIG9uZSBwYXJhZ3JhcGhcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkdyb3ZlIGlzIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ3aWtpIC8ga25vd2xlZGdlLWdhcmRlbiBlbmdpbmVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdGhhdCBydW5zIGFzIG9uZSBpbW1lZGlhdGVseS5ydW4gYXBwOiBldmVyeVxcbmVudHJ5IGlzIGEgc2luZ2xlIE1EWCBmaWxlLCBlbnRyaWVzIGludGVybGluayB3aXRoIFwifTxfY29tcG9uZW50cy5jb2RlPntcIltbd2lraS1saW5rc11dXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgYW5kIHRoZSB3aG9sZSBzaXRlXFxucmVuZGVycyBpbiB0aGUgYnJvd3Nlci4gWW91IGFyZSBkZXNpZ25pbmcgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ0aGUgcmVhZGluZyBleHBlcmllbmNlLCB0aGUgcnVuLW1vZGUgY2hyb21lLFxcbmFuZCBHcm92ZSdzIG93biBlbWJlZGRlZCBhZ2VudCBjb252ZXJzYXRpb25cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHRoZSBlbnRyeSBwYWdlLCB0aGUgbmF2aWdhdGlvbiwgdGhlXFxuaW5kZXgvY29sbGVjdGlvbiBzdXJmYWNlcywgdGhlIGJ1aWx0LWluIGNvbXBvbmVudHMsIHRoZSBleHRlbnNpYmlsaXR5IHZpZXdzLCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInRoZSBlbWJlZGRlZFxcbkdyb3ZlIGFnZW50IGNvbnZlcnNhdGlvbiAoR3JvdmUncyBcIn08X2NvbXBvbmVudHMuZW0+e1wicHJpbWFyeVwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGF1dGhvcmluZyBzdXJmYWNlKVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgZXZlcnlcXG5lbXB0eS9sb2FkaW5nL2Vycm9yIHN0YXRlLCBhIHNtYWxsIEdyb3ZlIGJyYW5kIG1hcmssIGFuZCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInRoZSBkZWZhdWx0IHRoZW1lIHBsdXMgdHdvIG9yXFxudGhyZWUgYWx0ZXJuYXRlIHRoZW1lc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB0aGF0IHByb3ZlIEdyb3ZlIGNhbiBiZSByZS1za2lubmVkIGJ5IGVkaXRpbmcgQ1NTIGFsb25lLiBZb3UgYXJlXFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJub3RcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgZGVzaWduaW5nIGEgY29kZSBcIn08X2NvbXBvbmVudHMuZW0+e1wiZWRpdG9yXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgb3IgYW55IHNpZ24taW4g4oCUIHRob3NlIHN0YXkgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJob3N0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHN1cmZhY2VzIEdyb3ZlXFxuZGVsZWdhdGVzIHRvLiBZb3UgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJhcmVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgZGVzaWduaW5nIEdyb3ZlJ3MgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJlbWJlZGRlZCBhZ2VudCBjb252ZXJzYXRpb25cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCI6IHRoZSBhcHAncyBvd25cXG5jYXBhYmlsaXR5LXNjb3BlZCBhZ2VudCAoZWFjaCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJDTEFVREUubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHNlY3VyaXR5IG1vZGVsIMKnOCksIHdoaWNoIGlzIFwifTxfY29tcG9uZW50cy5lbT57XCJkaXN0aW5jdCBmcm9tLCBhbmRcXG5uZXZlciBhIHNwb29mIG9mLFwifTwvX2NvbXBvbmVudHMuZW0+e1wiIHRoZSBob3N0J3MgYWdlbnQgcGFuZSAoc2VlIFwifTxfY29tcG9uZW50cy5lbT57XCJIYXJkIGNvbnN0cmFpbnRzXCJ9PC9fY29tcG9uZW50cy5lbT57XCIpLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJncm92ZS1pcy1hbi1hcHAtaW4tdGhlLWltbWVkaWF0ZWx5cnVuLWRlc2lnbi1zeXN0ZW0tbm90LWEtbmV3LWJyYW5kXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJncm92ZS1pcy1hbi1hcHAtaW4tdGhlLWltbWVkaWF0ZWx5cnVuLWRlc2lnbi1zeXN0ZW0tbm90LWEtbmV3LWJyYW5kXCIgLz57XCJHcm92ZSBpcyBhbiBhcHAgXCJ9PF9jb21wb25lbnRzLmVtPntcImluXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgdGhlIGltbWVkaWF0ZWx5LnJ1biBkZXNpZ24gc3lzdGVtIOKAlCBub3QgYSBuZXcgYnJhbmRcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkluaGVyaXQgdGhlIGJyYW5kIHdob2xlc2FsZTogY29vbCBuZWFyLWJsYWNrIGNhbnZhcywgdGhlIG1hZ2VudGHihpR2aW9sZXQgc2lnbmF0dXJlXFxuZ3JhZGllbnQsIEdhYmFyaXRvIGRpc3BsYXkgLyBQdWJsaWMgU2FucyBib2R5IC8gU3BhY2UgTW9ubyBkZXRhaWxzLCBoYWlybGluZSBib3JkZXJzLCB0aGVcXG5oYXJkLW9mZnNldCBob3ZlciBzaGFkb3csIHNlbnRlbmNlIGNhc2UsIGhlYWRsaW5lcyB0aGF0IGVuZCBvbiBhIHBlcmlvZCwgbm8gZW1vamkuIFB1bGxcXG5hbGwgb2YgaXQgZnJvbSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvaW5kZXguY3NzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhbmQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQ0xBVURFLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBcXFwiRGVzaWduIHN5c3RlbVxcXCIuIFRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImRlZmF1bHQgR3JvdmVcXG50aGVtZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuZW0+e1wiaXNcIn08L19jb21wb25lbnRzLmVtPntcIiB0aGUgaW1tZWRpYXRlbHkucnVuIGJyYW5kIGFwcGxpZWQgdG8gYSB3aWtpLiAoQnJpZWYgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiMDAtZm91bmRhdGlvblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgbGlzdHMgdGhlXFxuZmV3IEdyb3ZlLXNwZWNpZmljIG1vdGlmcyBsYXllcmVkIG9uIHRvcC4pXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cImF1ZGllbmNlLXJ1bGUtZXZlcnktc3VyZmFjZS1pbi1wcmlvcml0eS1vcmRlclwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiYXVkaWVuY2UtcnVsZS1ldmVyeS1zdXJmYWNlLWluLXByaW9yaXR5LW9yZGVyXCIgLz57XCJBdWRpZW5jZSBydWxlIChldmVyeSBzdXJmYWNlLCBpbiBwcmlvcml0eSBvcmRlcilcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSBwbGF0Zm9ybSdzIGF1ZGllbmNlIHByaW9yaXR5IChcIn08X2NvbXBvbmVudHMuY29kZT57XCJwcm9kdWN0X3ZhbHVlc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgwqcyL8KnNS/CpzgpLCBzcGVjaWFsaXNlZCBmb3IgR3JvdmU6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJSZWFkZXJzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBtb2JpbGUtZmlyc3Q7IHRoZSByZWFkaW5nIHN1cmZhY2UgaXMgdGhlIHByb2R1Y3QuIFR5cG9ncmFwaHksIGxpbmtcXG5pbnRlZ3JpdHksIGZhc3QgZmlyc3QgcGFpbnQuIE1vc3QgdmlzaXRzIG5ldmVyIGVkaXQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJBdXRob3JzLCBpbmNsdWRpbmcgbm9uLXRlY2huaWNhbCBvbmVzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCB0aGV5IG1vc3RseSBcIn08X2NvbXBvbmVudHMuZW0+e1wiYXNrIHRoZSBhZ2VudFwifTwvX2NvbXBvbmVudHMuZW0+e1wiOyB0aGUgbWFudWFsXFxuZWRpdGluZyBhZmZvcmRhbmNlIGlzIGEgZmFsbGJhY2suIERlc2lnbiBjbGVhbiwgZGlzY292ZXJhYmxlIGFmZm9yZGFuY2VzLCBub3QgYW5cXG5hdXRob3IgY29uc29sZS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkNvZGluZyBhZ2VudHNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHNlbWFudGljIGxhbmRtYXJrcywgc3RhYmxlIHN0cnVjdHVyZSwgY2xlYW4gaGVhZGluZ3M7IGFnZW50cyByZWFkXFxudGhlIHNhbWUgRE9NIHNjcmVlbiByZWFkZXJzIGRvLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJBIGRlc2t0b3AtaHVtYW4tb25seSBkZXNpZ24gaXMgd3JvbmcgaGVyZS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwidGhlLXR3by10aGVtZXMtcHJvYmxlbS1hLWNvcmUtZGVsaXZlcmFibGUtbm90LWEtZmxvdXJpc2hcIj48SGVhZGluZ0FuY2hvciBpZD1cInRoZS10d28tdGhlbWVzLXByb2JsZW0tYS1jb3JlLWRlbGl2ZXJhYmxlLW5vdC1hLWZsb3VyaXNoXCIgLz57XCJUaGUgdHdvIHRoZW1lcyBwcm9ibGVtIChhIGNvcmUgZGVsaXZlcmFibGUsIG5vdCBhIGZsb3VyaXNoKVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiR3JvdmUncyBwcm9kdWN0IHByb21pc2UgaXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJDU1Mtb25seSB0aGVtaW5nXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJncm92ZS5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgXFxcIlRoZW1pbmcgJiBsYXlvdXRcXFwiKS4gVGhhdCBoYXNcXG5hIGNvbmNyZXRlIGRlc2lnbiBjb25zZXF1ZW5jZTogZXZlcnkgc3VyZmFjZSBtdXN0IGJlIGJ1aWx0IGZyb20gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJzdGFibGUsIHNlbWFudGljIGNsYXNzXFxubmFtZXMgKyBkZXNpZ24gdG9rZW5zXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBuZXZlciBiZXNwb2tlIG9uZS1vZmYgc3R5bGluZywgc28gYSBmb3JrIGNhbiByZS1za2luIGJ5IGVkaXRpbmdcXG5DU1MuIFRvIHByb3ZlIGl0LCB5b3UgZGVsaXZlcjpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlRoZSBkZWZhdWx0IHRoZW1lXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBvbiB0aGUgaW1tZWRpYXRlbHkucnVuIGJyYW5kLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVHdv4oCTdGhyZWUgYWx0ZXJuYXRlIHRoZW1lc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBrZXllZCB0byB0aGUgcmVhbCB1c2UgY2FzZXMgKFwifTxfY29tcG9uZW50cy5jb2RlPntcImdyb3ZlLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBcXFwiUmVwcmVzZW50YXRpdmVcXG51c2UgY2FzZXNcXFwiKTogZS5nLiBhIHNhdHVyYXRlZCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlBpeGllc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBtdXNpYyB0aGVtZSwgYSBzb2Z0IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZmFtaWx5LWpvdXJuYWxcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdGhlbWUsIGFcXG5wYXJjaG1lbnQtaXNoIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiTG9yZCBvZiB0aGUgUmluZ3NcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdGhlbWUg4oCUIFwifTxfY29tcG9uZW50cy5lbT57XCJzYW1lIGNvbXBvbmVudHMgYW5kIERPTSwgZGlmZmVyZW50IENTUy5cIn08L19jb21wb25lbnRzLmVtPntcIlxcblNob3cgdGhlIHNhbWUgZW50cnkgcmVuZGVyZWQgdW5kZXIgZWFjaCwgc2lkZSBieSBzaWRlLCB0byBtYWtlIHRoZSBjbGFpbSB2aXNpYmxlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJ0aGUtYXNzZXQtc2NyZWVuLWludmVudG9yeS13aGF0LXRoZS1icmllZnMtY292ZXJcIj48SGVhZGluZ0FuY2hvciBpZD1cInRoZS1hc3NldC1zY3JlZW4taW52ZW50b3J5LXdoYXQtdGhlLWJyaWVmcy1jb3ZlclwiIC8+e1wiVGhlIGFzc2V0IC8gc2NyZWVuIGludmVudG9yeSAod2hhdCB0aGUgYnJpZWZzIGNvdmVyKVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnRhYmxlPjxfY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRoPntcIkJyaWVmXCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGg+e1wiU3VyZmFjZVwifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIldoeSBpdCBtYXR0ZXJzXCJ9PC9fY29tcG9uZW50cy50aD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGhlYWQ+PF9jb21wb25lbnRzLnRib2R5PjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiMDAtZm91bmRhdGlvblwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJHcm92ZS1zcGVjaWZpYyBtb3RpZnMsIHRoZSBjbGFzcy1uYW1lL3Rva2VuIGNvbnRyYWN0LCB0aGUgYXBwIG1hcmtcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJ0aGUgc2hhcmVkIGJhc2UgZXZlcnkgb3RoZXIgYnJpZWYgYXNzdW1lc1wifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcIjAxLXJlYWRpbmctdmlld1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJ0aGUgZW50cnkgcGFnZTogTURYIHByb3NlLCBlbnRyeSBoZWFkZXIsIGJhY2tsaW5rcywgVG9DLCB3aWtpLWxpbmsgc3R5bGluZywgbGF5b3V0IHZhcmlhbnRzXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1widGhlIGhlcm8gc3VyZmFjZSDigJQgcmVhZGVycyBsaXZlIGhlcmVcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCIwMi1zaGVsbC1uYXZpZ2F0aW9uLWFuZC1hdXRob3JpbmdcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1widG9wIG5hdiwgc2lkZWJhciAodGFnLWRyaXZlbiArIG5hbWVzcGFjZSB0cmVlKSwgZm9vdGVyLCBzZWFyY2gsIHRoZW1lIHRvZ2dsZSwgbW9iaWxlIGNocm9tZSwgdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZWRpdCAvIG5ldy1lbnRyeSAvIGFzay10aGUtYWdlbnQgYWZmb3JkYW5jZXNcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJob3cgeW91IG1vdmUgdGhyb3VnaCBhIEdyb3ZlIGFuZCBoYW5kIG9mZiB0byB0aGUgaG9zdFwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcIjAzLWluZGV4ZXMtYW5kLWNvbXBvbmVudC1saWJyYXJ5XCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcImhvbWUvaW5kZXgsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjxEb2NMaXN0PlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZmVlZHMsIHRhZyBwYWdlcywgdGFnIGNsb3VkLCByZWNlbnRseS11cGRhdGVkLCBhbmQgZWFjaCBidWlsdC1pbiBjb21wb25lbnQncyBhcHBlYXJhbmNlICsgYW4gYXV0aG9yIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjxJbmZvYm94PlwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJkaXNjb3ZlcnkgKyB0aGUgY29tcG9uZW50IHZvY2FidWxhcnlcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCIwNC1leHRlbnNpYmlsaXR5LXZpZXdzXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcInRoZSBhZ2VudC1idWlsdCB2aWV3czogYW5pbWF0ZWQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ0aW1lbGluZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJmYW1pbHkgdHJlZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJkaXJlY3RvcnkvdGFibGVcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJwcm92ZXMgdGhlIGV4dGVuc2lvbiBzdXJmYWNlIGlzIGRlc2lnbmFibGVcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCIwNS1zdGF0ZXMtYW5kLXRoZW1pbmdcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wibG9hZGluZyBza2VsZXRvbnMsIGVtcHR5LCBlcnJvci80MDQvYnJva2VuLWxpbmssIHJlYWQtb25seSB2aWV3ZXI7IHRoZSBkZWZhdWx0ICsgYWx0ZXJuYXRlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1widGhlbWUgc2hvd2Nhc2VcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCI7IHRoZSBHcm92ZSBhcHAgaWNvblwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcInRoZSB1bmdsYW1vcm91cyBzdXJmYWNlcyArIHRoZSB0aGVtZWFiaWxpdHkgcHJvb2ZcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCIwNi1hZ2VudC1jb252ZXJzYXRpb25cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiR3JvdmUncyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImVtYmVkZGVkIGNvZGluZy1hZ2VudCBjb252ZXJzYXRpb25cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIGFuIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiaW50ZWdyYWwsIGFsd2F5cy1wcmVzZW50XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHN1cmZhY2Ugd2l0aCBhIG1pbmltYWwgbm9uLW9ic2N1cmluZyByZXN0aW5nIGFmZm9yZGFuY2UgKFNhZmFyaS1VUkwtYmFyIHN0eWxlOyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIml0ZXJhdGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdGhlIGZvcm0pLCBwcm9wb3NlZC1jaGFuZ2UgcHJldmlld3MsIGFsbCBzdGF0ZXMsIG1vYmlsZSwgdGhlIHdvcmtiZW5jaCBoYW5kLW9mZlwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIkdyb3ZlJ3MgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJwcmltYXJ5IGF1dGhvcmluZyBzdXJmYWNlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBiYWtlZCBpbiBmcm9udCBhbmQgY2VudGVyXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiMDgtc3Rvcnktcml2ZXJcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1widGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wic3Rvcnkgcml2ZXJcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCI6IGEgVGlkZGx5V2lraS1zdHlsZSByZWFkaW5nIG1vZGUsIGJ1aWx0IGFzIGEgc2VwYXJhdGUgYXBwIG9uIEdyb3ZlLCB3aGVyZSBsaW5rcyBvcGVuIGVudHJpZXMgYXMgY2FyZHMgaW4gb25lIGNvbHVtbiDigJQgdGhlIHJpdmVyIHBhZ2UsIHRoZSBjYXJkIGFuZCBpdHMgc3RhdGVzLCBvcGVuIC8gZm9jdXMgLyBjbG9zZSBtb3Rpb24sIHRoZSBmb2N1cy1mb2xsb3dpbmcgcmFpbCwgbW9iaWxlXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1widGhlIHByZXNzdXJlIHRlc3Qgb2YgY3VzdG9taXphYmxlIG5hdmlnYXRpb24gKFwifTxfY29tcG9uZW50cy5jb2RlPntcIkFQUF9DVVNUT01JWkFUSU9OX1NQRUNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIMKnNiBpbiB0aGUgZG9jcyByZXBvKVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRib2R5PjwvX2NvbXBvbmVudHMudGFibGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwiZ3JvdmVzLWZvdW5kYXRpb24taXMtdGhlLWFnZW50LWNvbnRyYWN0LWFuZC1pdHMtbW9zdGx5LWludmlzaWJsZS10by15b3VcIj48SGVhZGluZ0FuY2hvciBpZD1cImdyb3Zlcy1mb3VuZGF0aW9uLWlzLXRoZS1hZ2VudC1jb250cmFjdC1hbmQtaXRzLW1vc3RseS1pbnZpc2libGUtdG8teW91XCIgLz57XCJHcm92ZSdzIGZvdW5kYXRpb24gaXMgdGhlIGFnZW50IGNvbnRyYWN0IOKAlCBhbmQgaXQncyBtb3N0bHkgaW52aXNpYmxlIHRvIHlvdVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiR3JvdmUncyBzaW5nbGUgbW9zdCBpbXBvcnRhbnQgcHJvcGVydHkgaXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJhZ2VudCBsZWdpYmlsaXR5XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiOiBldmVyeSBpbnN0YW5jZSBjYXJyaWVzIGFcXG5zZWxmLWRlc2NyaWJpbmcgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJjb250cmFjdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZ3JvdmUubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIFxcXCJUaGUgYWdlbnQgY29udHJhY3RcXFwiKSBzbyBhIGZ1dHVyZSBjb2RpbmctYWdlbnRcXG5zZXNzaW9uIHJlLWRlcml2ZXMgaG93IFwifTxfY29tcG9uZW50cy5lbT57XCJ0aGlzXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgd2lraSB3b3Jrcy4gVGhhdCBjb250cmFjdCBpcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImFnZW50LWZhY2luZyBpbmZyYXN0cnVjdHVyZSxcXG5ub3QgYSBzdXJmYWNlIHlvdSBzdHlsZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiR1JPVkUubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFuZCB0aGUgZ2VuZXJhdGVkIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi5ncm92ZS9tYW5pZmVzdC5qc29uXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhcmUgcmVhZCBieVxcbmFnZW50cywgYW5kIHZhbGlkYXRpb24vZHJpZnQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJkaWFnbm9zdGljcyBzdXJmYWNlIHRocm91Z2ggdGhlIGhvc3QgZWRpdCBleHBlcmllbmNlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLFxcbndoaWNoIEdyb3ZlIG11c3Qgbm90IGltaXRhdGUgKHNlZSBjb25zdHJhaW50IDEpLiBTbyBpdCBjaGFuZ2VzIGxpdHRsZSBhYm91dCB3aGF0IHlvdSBkcmF3IOKAlFxcbmJ1dCB5b3Ugc2hvdWxkIGtub3cgaXQncyB0aGUgcHJvZHVjdCdzIGNlbnRyZSBvZiBncmF2aXR5LCBhbmQgaXQgaGFzIHRoZXNlIHZpc3VhbFxcbnRvdWNocG9pbnRzIHRvIGdldCByaWdodDpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIk1ha2UgY29udmVudGlvbnMgbGVnaWJsZSBcIn08X2NvbXBvbmVudHMuZW0+e1wiaW4gdGhlIGNvbnRlbnQgaXRzZWxmXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHRoaXMgaXMgd2h5IHdpa2ktbGluayBzdGF0ZXNcXG4ocmVzb2x2ZWQgLyBicm9rZW4gLyBhbWJpZ3VvdXMpLCB0YWcgY2hpcHMsIGFuZCB0aGUgbmFtZXNwYWNlIHRyZWUgbXVzdCByZWFkIGNsZWFybHlcXG4oYnJpZWZzIDAw4oCTMDIpLiBUaGUgc3RydWN0dXJlIGEgcmVhZGVyIHNlZXMgaXMgdGhlIHNhbWUgc3RydWN0dXJlIGFuIGFnZW50IHJlYWRzLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVGhlIGVtYmVkZGVkIEdyb3ZlIGFnZW50IChicmllZiAwNikgaXMgdGhlIGNvbnRyYWN0J3Mgd29ya2luZyBpbnRlcmZhY2VcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIGl0J3MgdGhlXFxuY29udHJhY3QtYXdhcmUgYWdlbnQgdGhhdCByZWFkcyBhbmQgdXBkYXRlcyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJHUk9WRS5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuIERlc2lnbmluZyB0aGF0IGNvbnZlcnNhdGlvbiB3ZWxsXFxuXCJ9PF9jb21wb25lbnRzLmVtPntcImlzXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgZGVzaWduaW5nIGhvdyBtb3N0IHVzZXJzIHRvdWNoIHRoZSBjb250cmFjdCwgZXZlbiB0aG91Z2ggdGhlIGNvbnRyYWN0IGZpbGVzXFxudGhlbXNlbHZlcyBzdGF5IHVuc3R5bGVkLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQW4gb3B0aW9uYWwgXFxcImFib3V0IHRoaXMgd2lraVxcXCIgLyBjb2xvcGhvbiBlbnRyeVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgYSBodW1hbi1yZWFkYWJsZSByZW5kZXJpbmcgb2YgdGhlXFxuaW5zdGFuY2UncyBjb252ZW50aW9ucyAod2hhdCB0YWdzIG1lYW4sIHdoYXQgY3VzdG9tIGNvbXBvbmVudHMgZXhpc3QpIGlzIGp1c3QgYSBub3JtYWxcXG5NRFggZW50cnkgcmVuZGVyZWQgaW4gdGhlIHJlYWRpbmcgdmlldzsgZGVzaWduIG5vIHNwZWNpYWwgY2hyb21lIGZvciBpdCwgYnV0IGEgdGFzdGVmdWxcXG5jb2xvcGhvbi9cIn08X2NvbXBvbmVudHMuY29kZT57XCIvYWJvdXRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHBhdHRlcm4gaXMgYSB3ZWxjb21lIGV4YW1wbGUuIE5ldmVyIHJlbmRlciBhIGZha2UgXFxcImRpYWdub3N0aWNzIHBhbmVsXFxcIlxcbm9yIGhvc3QgZWRpdG9yIGNocm9tZS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMub2w+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwiaGFyZC1jb25zdHJhaW50cy1yZWFkLWJlZm9yZS1kcmF3aW5nLWFueXRoaW5nXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJoYXJkLWNvbnN0cmFpbnRzLXJlYWQtYmVmb3JlLWRyYXdpbmctYW55dGhpbmdcIiAvPntcIkhhcmQgY29uc3RyYWludHMgKHJlYWQgYmVmb3JlIGRyYXdpbmcgYW55dGhpbmcpXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMub2w+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRG9uJ3QgaW1pdGF0ZSBob3N0IGNocm9tZSDigJQgYnV0IEdyb3ZlJ3MgXCJ9PF9jb21wb25lbnRzLmVtPntcIm93blwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGFnZW50IGlzIGFsbG93ZWRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcImdyb3ZlLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBzZWN1cml0eVxcbm1vZGVsICsgXFxcIkF1dGhvcmluZ1xcXCI7IGVhY2ggXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQ0xBVURFLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDCpzgpLiBHcm92ZSBtdXN0IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibmV2ZXJcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgcmVuZGVyIGEgZmFrZSBjb2RlXFxuZWRpdG9yLCBhIGZha2UgXCJ9PF9jb21wb25lbnRzLmVtPntcImhvc3RcIn08L19jb21wb25lbnRzLmVtPntcIiBhZ2VudCBwYW5lLCBhIGZha2UgY29uc2VudCBkaWFsb2csIGEgZmFrZSB2YWxpZGF0aW9uL2RpYWdub3N0aWNzXFxucGFuZWwsIG9yIGEgc2lnbi1pbi4gV2hlbiB0aGUgdXNlciBlZGl0cyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInRleHRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIsIEdyb3ZlIHNob3dzIGFuIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZWRpdCBhZmZvcmRhbmNlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiXFxudGhhdCBcIn08X2NvbXBvbmVudHMuZW0+e1wiaGFuZHMgb2ZmXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgdG8gdGhlIHBsYXRmb3JtIGVkaXRvciDigJQgZGVzaWduIHRoZSBhZmZvcmRhbmNlLCBub3QgdGhlIGVkaXRvcjsgY29udHJhY3RcXG52YWxpZGF0aW9uL2RyaWZ0IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZGlhZ25vc3RpY3MgYXJlIGEgaG9zdCBzdXJmYWNlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHRvby4gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgb25lIGV4Y2VwdGlvbiBpcyB0aGVcXG5hZ2VudCBjb252ZXJzYXRpb246XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIEdyb3ZlIGRlbGliZXJhdGVseSBzaGlwcyBpdHMgXCJ9PF9jb21wb25lbnRzLmVtPntcIm93blwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGVtYmVkZGVkIGFnZW50IChicmllZiAwNiksXFxuc2NvcGVkIHRvIEdyb3ZlJ3MgZ3JhbnRzIHZpYSB0aGUgU0RLIGNhdGFsb2cg4oCUIHNvIHlvdSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImRvXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGRlc2lnbiB0aGF0IHN1cmZhY2UuIEl0IG11c3RcXG5iZSBjbGVhcmx5IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiR3JvdmUncyBvd25cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKGl0cyBvd24gcGxhY2VtZW50L2lkZW50aXR5IHdpdGhpbiB0aGUgYXBwKSwgbmV2ZXIgc3R5bGVkIHRvXFxucGFzcyBhcyB0aGUgaG9zdCdzIHRydXN0ZWQgYWdlbnQgcGFuZSwgYW5kIHByaXZpbGVnZWQgYWN0aW9ucyAod3JpdGVzLCBjb250cmlidXRlKSBzdGlsbFxcbnJvdXRlIHRocm91Z2ggdGhlIGhvc3QuIFNwb29maW5nIGhvc3Qgc3VyZmFjZXMgcmVhZHMgYXMgaG9zdGlsZTsgYnVpbGRpbmcgeW91ciBvd25cXG5jYXBhYmlsaXR5LXNjb3BlZCBhZ2VudCBkb2VzIG5vdC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlJlYWRpbmctZmlyc3QsIHdpdGggdGhlIGFnZW50IGFzIHRoZSBkZWxpYmVyYXRlIGFsd2F5cy1wcmVzZW50IGV4Y2VwdGlvbi5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgUnVuLW1vZGVcXG5VSSBzdGF5cyBmcmVlIG9mIFwifTxfY29tcG9uZW50cy5lbT57XCJlZGl0b3JcIn08L19jb21wb25lbnRzLmVtPntcIiBjaHJvbWU7IHRoZSBlZGl0IGFmZm9yZGFuY2UgaXMgdW5vYnRydXNpdmUgYW5kIHdyaXRhYmxlLW9ubHk7XFxudGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicmVhZC1vbmx5IHZpZXdlclwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBoYXMgbm8gZWRpdCBhZmZvcmRhbmNlIGF0IGFsbC4gQnV0IHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImFnZW50IGNvbW11bmljYXRpb24gaXNcXG5iYWtlZCBpbiwgZnJvbnQgYW5kIGNlbnRlclwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgYWx3YXlzIHByZXNlbnQgYW5kIG9uZSBnZXN0dXJlIGF3YXkgKGJyaWVmIDA2KS4gUmVjb25jaWxlXFxudGhlIHR3byB0aGUgd2F5IHRoZSBpT1MgU2FmYXJpIFVSTCBiYXIgZG9lczogYSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm1pbmltYWwgcGVyc2lzdGVudCBhZmZvcmRhbmNlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICh0aGluXFxuYm90dG9tIGlucHV0IGxpbmUgLyBwdWxsIHRhYiAvIGljb24pIHRoYXQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJuZXZlciBvYnNjdXJlcyBjb250ZW50IG9uIG1vYmlsZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBhbmRcXG5leHBhbmRzIG9ubHkgb24gZGVtYW5kLiBGcm9udC1hbmQtY2VudGVyLCBub3QgaW4tdGhlLXdheS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlRva2VucyBhcmUgdGhlIGNvbnRyYWN0LlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBDb2xvdXJzL2ZvbnRzL3JhZGlpL3NoYWRvd3MgY29tZSBmcm9tXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2luZGV4LmNzc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIuIE5vIGhhcmQtY29kZWQgaGV4ZXMgaW4gbW9ja3VwcyB5b3UnZCB3YW50IGEgZGV2IHRvIGNvcHkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJObyBlbW9qaSwgZXZlci5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgSWNvbnMgYXJlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiTHVjaWRlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICgxNuKAkzI0cHgsIFwifTxfY29tcG9uZW50cy5jb2RlPntcImN1cnJlbnRDb2xvclwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIH4xLjc1IHN0cm9rZSkgcGx1c1xcbnRoZSB1bmljb2RlIG1pY3JvLXNldCAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wi4piFIOKGkiDil48g4piAIOKYvlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLiBNb25vIG1pY3JvLWxhYmVscyBhcmUgdGhlIG9uZSBVUFBFUkNBU0UtdHJhY2tlZFxcbmV4Y2VwdGlvbi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkV2ZXJ5IGR5bmFtaWMgc3VyZmFjZSBuZWVkcyBmb3VyIHN0YXRlczpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgbG9hZGluZyAoXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJza2VsZXRvblwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgbm90IHNwaW5uZXI7XFxufjE1MG1zIGJ1ZGdldCksIGNvbnRlbnQsIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZW1wdHlcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKGRlc2lnbmVkLCBuZXZlciBicm9rZW4pLCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImVycm9yLzQwNFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoaW5jbC4gYVxcbmJyb2tlbi9hbWJpZ3VvdXMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiW1t3aWtpLWxpbmtdXVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdGFyZ2V0KS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkFjY2Vzc2liaWxpdHkgQUEgb24gYm90aCB0aGVtZXNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIsIGZ1bGwga2V5Ym9hcmQgb3BlcmFiaWxpdHksIHZpc2libGUgZm9jdXMgcmluZ3NcXG4odGhlIGdsb3cgcmluZyksIHNlbWFudGljIGxhbmRtYXJrcy9oZWFkaW5ncywgbmV2ZXIgc3RhdGUtYnktZ3JhZGllbnQtYWxvbmUuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cImRlbGl2ZXJhYmxlLXBlci1icmllZlwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiZGVsaXZlcmFibGUtcGVyLWJyaWVmXCIgLz57XCJEZWxpdmVyYWJsZSBwZXIgYnJpZWZcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkxheW91dHMgYXQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJtb2JpbGUgKyBkZXNrdG9wXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBhbGwgZm91ciBzdGF0ZXMsIGludGVyYWN0aW9uL3RyYW5zaXRpb24gbm90ZXMgKHJlc3RyYWluZWRcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJ+LjE0c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIG5vIGJvdW5jZS9zcHJpbmc7IHJlc3BlY3QgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicHJlZmVycy1yZWR1Y2VkLW1vdGlvblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImRyYWZ0ZWQgb24tYnJhbmQgY29weVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBmb3JcXG50aGUga2V5IHN0cmluZ3MgKHNlbnRlbmNlIGNhc2UsIHBlcmlvZC10ZXJtaW5hdGVkIGhlYWRsaW5lcywgbW9ubyBcIn08X2NvbXBvbmVudHMuY29kZT57XCIvc2x1Z1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYW5kIFwifTxfY29tcG9uZW50cy5jb2RlPntcIiN0YWdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxubGFiZWxzKSwgYSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImNvbXBvbmVudCBpbnZlbnRvcnkgbWFwcGVkIHRvIHRoZSB0b2tlbnMgYW5kIHRvIHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCIuZ3JvdmUtKlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgY2xhc3MgbmFtZXNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCJcXG5pbiBicmllZiBcIn08X2NvbXBvbmVudHMuY29kZT57XCIwMFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGFuZCDigJQgd2hlcmUgcmVsZXZhbnQg4oCUIHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInJvdXRlc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBhZmZvcmRhbmNlcyBwb2ludCBhdCAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiIy9zbHVnXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBoYXNoXFxucm91dGVzIHdpdGhpbiB0aGUgYXBwOyB0aGUgaG9zdCBoYW5kLW9mZiBmb3IgZWRpdGluZykuIENhbGwgb3V0IGFueSBmb3JrYWJpbGl0eS90aGVtaW5nXFxubm90ZSBzcGVjaWZpYyB0byB0aGF0IHN1cmZhY2UuXCJ9PC9fY29tcG9uZW50cy5wPjwvPjtcbn1cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE1EWENvbnRlbnQocHJvcHMgPSB7fSkge1xuICBjb25zdCB7d3JhcHBlcjogTURYTGF5b3V0fSA9IHtcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH07XG4gIHJldHVybiBNRFhMYXlvdXQgPyA8TURYTGF5b3V0IHsuLi5wcm9wc30+PF9jcmVhdGVNZHhDb250ZW50IHsuLi5wcm9wc30gLz48L01EWExheW91dD4gOiBfY3JlYXRlTWR4Q29udGVudChwcm9wcyk7XG59XG5mdW5jdGlvbiBfbWlzc2luZ01keFJlZmVyZW5jZShpZCwgY29tcG9uZW50LCBwbGFjZSkge1xuICB0aHJvdyBuZXcgRXJyb3IoXCJFeHBlY3RlZCBcIiArIChjb21wb25lbnQgPyBcImNvbXBvbmVudFwiIDogXCJvYmplY3RcIikgKyBcIiBgXCIgKyBpZCArIFwiYCB0byBiZSBkZWZpbmVkOiB5b3UgbGlrZWx5IGZvcmdvdCB0byBpbXBvcnQsIHBhc3MsIG9yIHByb3ZpZGUgaXQuXCIgKyAocGxhY2UgPyBcIlxcbkl04oCZcyByZWZlcmVuY2VkIGluIHlvdXIgY29kZSBhdCBgXCIgKyBwbGFjZSArIFwiYCBpbiBgL2FwcC9kb2NzL2Rlc2lnbi1icmllZnMvZ3JvdmUvSEFORE9GRi5tZGBcIiA6IFwiXCIpKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQXdGLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUZ4RjtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU1DLFdBQVcsR0FBRztNQUNsQkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsSUFBSSxFQUFFLE1BQU07TUFDWkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsTUFBTSxFQUFFLFFBQVE7TUFDaEJDLEtBQUssRUFBRSxPQUFPO01BQ2RDLEtBQUssRUFBRSxPQUFPO01BQ2RDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEtBQUssRUFBRSxPQUFPO01BQ2RDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1IsR0FBRyxJQUFBQyw2QkFBa0IsRUFBQyxDQUFDO01BQ3ZCLEdBQUdsQixLQUFLLENBQUNtQjtJQUNYLENBQUM7SUFBRTtNQUFDQztJQUFhLENBQUMsR0FBR25CLFdBQVc7RUFDaEMsSUFBSSxDQUFDbUIsYUFBYSxFQUFFQyxvQkFBb0IsQ0FBQyxlQUFlLEVBQUUsSUFBSSxDQUFDO0VBQy9ELG9CQUFPLElBQUF2QixXQUFBLENBQUF3QixJQUFBLEVBQUF4QixXQUFBLENBQUF5QixRQUFBO0lBQUFDLFFBQUEsZ0JBQUUsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0ksRUFBRTtNQUFDb0IsRUFBRSxFQUFDLHlDQUF5QztNQUFBRCxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQXlDLENBQUUsQ0FBQyxFQUFDLDRDQUE0QztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1EsQ0FBQztNQUFBZSxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQWtCLENBQXFCLENBQUMsRUFBQyxvRkFBb0YsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFPLENBQXFCLENBQUMsRUFBQyxxQ0FBcUMsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDQyxDQUFDO1FBQUN5QixJQUFJLEVBQUMsV0FBVztRQUFBSCxRQUFBLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQVMsQ0FBbUI7TUFBQyxDQUFlLENBQUMsRUFBQywrRkFBK0Y7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNRLENBQUM7TUFBQWUsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFNLENBQXFCLENBQUMsRUFBQywyRUFBMkUsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFrQixDQUFxQixDQUFDO0lBQUEsQ0FBZSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNnQixFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ00sRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBNEIsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFhLENBQXFCLENBQUMsRUFBQyxvR0FBb0c7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNNLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQWUsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFZLENBQXFCLENBQUMsRUFBQyxzRkFBc0Y7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNNLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLG9HQUFvRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDSyxFQUFFO01BQUNtQixFQUFFLEVBQUMsdUNBQXVDO01BQUFELFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBdUMsQ0FBRSxDQUFDLEVBQUMseUNBQXlDO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDUSxDQUFDO01BQUFlLFFBQUEsR0FBRSxhQUFhLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBZ0MsQ0FBcUIsQ0FBQyxFQUFDLG1HQUFtRyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFnQixDQUFtQixDQUFDLEVBQUMsa0VBQWtFLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBMkYsQ0FBcUIsQ0FBQyxFQUFDLHVIQUF1SCxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNTLE1BQU07UUFBQWMsUUFBQSxHQUFFLGtEQUFrRCxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNHLEVBQUU7VUFBQW9CLFFBQUEsRUFBRTtRQUFTLENBQWlCLENBQUMsRUFBQyxxQkFBcUI7TUFBQSxDQUFxQixDQUFDLEVBQUMsb0VBQW9FLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBdUQsQ0FBcUIsQ0FBQyxFQUFDLHFFQUFxRSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQUssQ0FBcUIsQ0FBQyxFQUFDLG9CQUFvQixlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNHLEVBQUU7UUFBQW9CLFFBQUEsRUFBRTtNQUFRLENBQWlCLENBQUMsRUFBQywrQkFBK0IsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFNLENBQXFCLENBQUMsRUFBQyxxQ0FBcUMsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFLLENBQXFCLENBQUMsRUFBQyxxQkFBcUIsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUE2QixDQUFxQixDQUFDLEVBQUMsaURBQWlELGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQVcsQ0FBbUIsQ0FBQyxFQUFDLGdDQUFnQyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNHLEVBQUU7UUFBQW9CLFFBQUEsRUFBRTtNQUF1QyxDQUFpQixDQUFDLEVBQUMsOEJBQThCLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBb0IsUUFBQSxFQUFFO01BQWtCLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDSyxFQUFFO01BQUNtQixFQUFFLEVBQUMscUVBQXFFO01BQUFELFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBcUUsQ0FBRSxDQUFDLEVBQUMsa0JBQWtCLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBb0IsUUFBQSxFQUFFO01BQUksQ0FBaUIsQ0FBQyxFQUFDLHNEQUFzRDtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1EsQ0FBQztNQUFBZSxRQUFBLEdBQUUsd1JBQXdSLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQWUsQ0FBbUIsQ0FBQyxFQUFDLE9BQU8sZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBVyxDQUFtQixDQUFDLEVBQUMsMEJBQTBCLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBc0IsQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRyxFQUFFO1FBQUFvQixRQUFBLEVBQUU7TUFBSSxDQUFpQixDQUFDLEVBQUMsdURBQXVELGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQWUsQ0FBbUIsQ0FBQyxFQUFDLHdEQUF3RDtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDbUIsRUFBRSxFQUFDLCtDQUErQztNQUFBRCxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQStDLENBQUUsQ0FBQyxFQUFDLGtEQUFrRDtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1EsQ0FBQztNQUFBZSxRQUFBLEdBQUUsb0NBQW9DLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQWdCLENBQW1CLENBQUMsRUFBQyxvQ0FBb0M7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNPLEVBQUU7TUFBQWdCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ00sRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFTLENBQXFCLENBQUMsRUFBQyw2SEFBNkg7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNNLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBdUMsQ0FBcUIsQ0FBQyxFQUFDLGlCQUFpQixlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNHLEVBQUU7VUFBQW9CLFFBQUEsRUFBRTtRQUFlLENBQWlCLENBQUMsRUFBQyxpSEFBaUg7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNNLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBZSxDQUFxQixDQUFDLEVBQUMsdUdBQXVHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNRLENBQUM7TUFBQWUsUUFBQSxFQUFFO0lBQTRDLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDbUIsRUFBRSxFQUFDLDBEQUEwRDtNQUFBRCxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQTBELENBQUUsQ0FBQyxFQUFDLDZEQUE2RDtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1EsQ0FBQztNQUFBZSxRQUFBLEdBQUUsNkJBQTZCLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBa0IsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBVSxDQUFtQixDQUFDLEVBQUMsb0dBQW9HLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBK0MsQ0FBcUIsQ0FBQyxFQUFDLG1HQUFtRztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ2dCLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDTSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQW1CLENBQXFCLENBQUMsRUFBQyxrQ0FBa0M7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNNLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBNEIsQ0FBcUIsQ0FBQyxFQUFDLGdDQUFnQyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQyxvREFBb0QsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFRLENBQXFCLENBQUMsRUFBQyx1QkFBdUIsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFnQixDQUFxQixDQUFDLEVBQUMsMkJBQTJCLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBbUIsQ0FBcUIsQ0FBQyxFQUFDLFdBQVcsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRyxFQUFFO1VBQUFvQixRQUFBLEVBQUU7UUFBeUMsQ0FBaUIsQ0FBQyxFQUFDLHFGQUFxRjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDSyxFQUFFO01BQUNtQixFQUFFLEVBQUMsa0RBQWtEO01BQUFELFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBa0QsQ0FBRSxDQUFDLEVBQUMsc0RBQXNEO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDVSxLQUFLO01BQUFhLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ2MsS0FBSztRQUFBUyxRQUFBLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ2UsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNhLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQU8sQ0FBaUIsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBUyxDQUFpQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDYSxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFnQixDQUFpQixDQUFDO1FBQUEsQ0FBZ0I7TUFBQyxDQUFtQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDVyxLQUFLO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ2UsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUFlLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBb0UsQ0FBaUIsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBMkMsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNlLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBaUIsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUE2RixDQUFpQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFzQyxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ2UsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUFtQyxDQUFtQjtVQUFDLENBQWdCLENBQUMsbUJBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxHQUFFLG1HQUFtRyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQThDLENBQXFCLENBQUM7VUFBQSxDQUFnQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUF1RCxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ2UsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUFrQyxDQUFtQjtVQUFDLENBQWdCLENBQUMsbUJBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxHQUFFLGNBQWMsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBVyxDQUFtQixDQUFDLEVBQUMsdUdBQXVHLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQVcsQ0FBbUIsQ0FBQztVQUFBLENBQWdCLENBQUMsbUJBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQXNDLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDZSxFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQXdCLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLEdBQUUsa0NBQWtDLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBVSxDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQWEsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFpQixDQUFxQixDQUFDO1VBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBNEMsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNlLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBdUIsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsR0FBRSw2RkFBNkYsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFnQixDQUFxQixDQUFDLEVBQUMsc0JBQXNCO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBbUQsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNlLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBdUIsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsR0FBRSxVQUFVLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBb0MsQ0FBcUIsQ0FBQyxFQUFDLFFBQVEsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUEwQixDQUFxQixDQUFDLEVBQUMsa0ZBQWtGLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBUyxDQUFxQixDQUFDLEVBQUMsa0ZBQWtGO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLEdBQUUsVUFBVSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQTJCLENBQXFCLENBQUMsRUFBQyw2QkFBNkI7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ2UsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUFnQixDQUFtQjtVQUFDLENBQWdCLENBQUMsbUJBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxHQUFFLE1BQU0sZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFhLENBQXFCLENBQUMsRUFBQywrTkFBK047VUFBQSxDQUFpQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsR0FBRSxnREFBZ0QsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBd0IsQ0FBbUIsQ0FBQyxFQUFDLHVCQUF1QjtVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDO01BQUEsQ0FBbUIsQ0FBQztJQUFBLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDbUIsRUFBRSxFQUFDLHlFQUF5RTtNQUFBRCxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQXlFLENBQUUsQ0FBQyxFQUFDLDZFQUE2RTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1EsQ0FBQztNQUFBZSxRQUFBLEdBQUUsNENBQTRDLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBa0IsQ0FBcUIsQ0FBQyxFQUFDLDhDQUE4QyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVUsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBVSxDQUFtQixDQUFDLEVBQUMsNEVBQTRFLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBb0IsUUFBQSxFQUFFO01BQU0sQ0FBaUIsQ0FBQyxFQUFDLGdDQUFnQyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQXVELENBQXFCLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQVUsQ0FBbUIsQ0FBQyxFQUFDLHFCQUFxQixlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFzQixDQUFtQixDQUFDLEVBQUMsNkNBQTZDLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBc0QsQ0FBcUIsQ0FBQyxFQUFDLDhNQUE4TTtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ08sRUFBRTtNQUFBZ0IsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDTSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNTLE1BQU07VUFBQWMsUUFBQSxHQUFFLDJCQUEyQixlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNHLEVBQUU7WUFBQW9CLFFBQUEsRUFBRTtVQUF1QixDQUFpQixDQUFDO1FBQUEsQ0FBb0IsQ0FBQyxFQUFDLDBNQUEwTTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ00sRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUF5RSxDQUFxQixDQUFDLEVBQUMsMkRBQTJELGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQVUsQ0FBbUIsQ0FBQyxFQUFDLHNDQUFzQyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNHLEVBQUU7VUFBQW9CLFFBQUEsRUFBRTtRQUFJLENBQWlCLENBQUMsRUFBQyx5R0FBeUc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNNLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBa0QsQ0FBcUIsQ0FBQyxFQUFDLGtPQUFrTyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFRLENBQW1CLENBQUMsRUFBQyxrR0FBa0c7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDbUIsRUFBRSxFQUFDLCtDQUErQztNQUFBRCxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQStDLENBQUUsQ0FBQyxFQUFDLGlEQUFpRDtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ08sRUFBRTtNQUFBZ0IsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDTSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNTLE1BQU07VUFBQWMsUUFBQSxHQUFFLDBDQUEwQyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNHLEVBQUU7WUFBQW9CLFFBQUEsRUFBRTtVQUFLLENBQWlCLENBQUMsRUFBQyxtQkFBbUI7UUFBQSxDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQyx5Q0FBeUMsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsbUJBQW1CLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBTyxDQUFxQixDQUFDLEVBQUMsc0NBQXNDLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBb0IsUUFBQSxFQUFFO1FBQU0sQ0FBaUIsQ0FBQyxFQUFDLDhHQUE4RyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQU0sQ0FBcUIsQ0FBQyxFQUFDLG1CQUFtQixlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWlCLENBQXFCLENBQUMsRUFBQyxTQUFTLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBb0IsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLDhGQUE4RixlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWdDLENBQXFCLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBK0MsQ0FBcUIsQ0FBQyxFQUFDLGdDQUFnQyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNHLEVBQUU7VUFBQW9CLFFBQUEsRUFBRTtRQUFLLENBQWlCLENBQUMsRUFBQyxxRkFBcUYsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFJLENBQXFCLENBQUMsRUFBQyw0Q0FBNEMsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFhLENBQXFCLENBQUMsRUFBQyxnUkFBZ1I7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNNLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBMkUsQ0FBcUIsQ0FBQyxFQUFDLDhCQUE4QixlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNHLEVBQUU7VUFBQW9CLFFBQUEsRUFBRTtRQUFRLENBQWlCLENBQUMsRUFBQyxzRUFBc0UsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFrQixDQUFxQixDQUFDLEVBQUMsMENBQTBDLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBb0QsQ0FBcUIsQ0FBQyxFQUFDLCtHQUErRyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQStCLENBQXFCLENBQUMsRUFBQyxvREFBb0QsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFrQyxDQUFxQixDQUFDLEVBQUMsaUVBQWlFO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDTSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTBCLENBQXFCLENBQUMsRUFBQywwQ0FBMEMsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBZSxDQUFtQixDQUFDLEVBQUMsNERBQTREO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDTSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWlCLENBQXFCLENBQUMsRUFBQyxhQUFhLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBUSxDQUFxQixDQUFDLEVBQUMsYUFBYSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUMsRUFBQywrQ0FBK0MsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsZ0VBQWdFO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDTSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTBDLENBQXFCLENBQUMsRUFBQyxZQUFZLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBVSxDQUFxQixDQUFDLEVBQUMsMkNBQTJDLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBTyxDQUFxQixDQUFDLEVBQUMsNkJBQTZCLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBVyxDQUFxQixDQUFDLEVBQUMsOEJBQThCLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQWUsQ0FBbUIsQ0FBQyxFQUFDLFdBQVc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNNLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBaUMsQ0FBcUIsQ0FBQyxFQUFDLGdJQUFnSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDSyxFQUFFO01BQUNtQixFQUFFLEVBQUMsdUJBQXVCO01BQUFELFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBdUIsQ0FBRSxDQUFDLEVBQUMsdUJBQXVCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDUSxDQUFDO01BQUFlLFFBQUEsR0FBRSxhQUFhLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBa0IsQ0FBcUIsQ0FBQyxFQUFDLCtEQUErRCxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFPLENBQW1CLENBQUMsRUFBQyw4QkFBOEIsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBd0IsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUF1QixDQUFxQixDQUFDLEVBQUMsMEVBQTBFLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQU8sQ0FBbUIsQ0FBQyxFQUFDLE9BQU8sZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBTSxDQUFtQixDQUFDLEVBQUMsZUFBZSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNTLE1BQU07UUFBQWMsUUFBQSxHQUFFLHNEQUFzRCxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQyxjQUFjO01BQUEsQ0FBcUIsQ0FBQyxFQUFDLGFBQWEsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBSSxDQUFtQixDQUFDLEVBQUMsK0JBQStCLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBUSxDQUFxQixDQUFDLEVBQUMseUJBQXlCLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQVEsQ0FBbUIsQ0FBQyxFQUFDLGdJQUFnSTtJQUFBLENBQWdCLENBQUM7RUFBQSxDQUFFLENBQUM7QUFDM3VtQjtBQUNlLFNBQVNJLFVBQVVBLENBQUM1QixLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUU7RUFDN0MsTUFBTTtJQUFDNkIsT0FBTyxFQUFFQztFQUFTLENBQUMsR0FBRztJQUMzQixHQUFHLElBQUFaLDZCQUFrQixFQUFDLENBQUM7SUFDdkIsR0FBR2xCLEtBQUssQ0FBQ21CO0VBQ1gsQ0FBQztFQUNELE9BQU9XLFNBQVMsZ0JBQUcsSUFBQWhDLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ0ksU0FBUztJQUFBLEdBQUs5QixLQUFLO0lBQUF3QixRQUFBLGVBQUUsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQzNCLGlCQUFpQjtNQUFBLEdBQUtDO0lBQUssQ0FBRztFQUFDLENBQVcsQ0FBQyxHQUFHRCxpQkFBaUIsQ0FBQ0MsS0FBSyxDQUFDO0FBQ2xIO0FBQUMrQixFQUFBLEdBTnVCSCxVQUFVO0FBT2xDLFNBQVNQLG9CQUFvQkEsQ0FBQ0ksRUFBRSxFQUFFTyxTQUFTLEVBQUVDLEtBQUssRUFBRTtFQUNsRCxNQUFNLElBQUlDLEtBQUssQ0FBQyxXQUFXLElBQUlGLFNBQVMsR0FBRyxXQUFXLEdBQUcsUUFBUSxDQUFDLEdBQUcsSUFBSSxHQUFHUCxFQUFFLEdBQUcsb0VBQW9FLElBQUlRLEtBQUssR0FBRyxxQ0FBcUMsR0FBR0EsS0FBSyxHQUFHLGlEQUFpRCxHQUFHLEVBQUUsQ0FBQyxDQUFDO0FBQzNRO0FBQUMsSUFBQUYsRUFBQTtBQUFBSSxZQUFBLENBQUFKLEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}