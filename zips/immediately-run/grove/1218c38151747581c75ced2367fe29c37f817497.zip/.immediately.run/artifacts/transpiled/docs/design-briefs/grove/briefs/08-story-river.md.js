var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      hr: "hr",
      li: "li",
      ol: "ol",
      p: "p",
      strong: "strong",
      table: "table",
      tbody: "tbody",
      td: "td",
      th: "th",
      thead: "thead",
      tr: "tr",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "brief-08-the-story-river-a-tiddlywiki-style-reading-mode",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "brief-08-the-story-river-a-tiddlywiki-style-reading-mode"
      }), "Brief 08 — The story river (a TiddlyWiki-style reading mode)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["A second way to read a Grove: instead of one entry per page, the reader keeps a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "single\ncolumn of open entries — the story river"
      }), " — and following a link opens the target as a\nnew card in that column. This is an homage to TiddlyWiki, one of immediately.run's\ninspirations. It is built as a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "separate app on top of Grove"
      }), ", so every surface here is\nGrove's existing vocabulary rearranged, not a new visual language."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "For:"
      }), " Claude Design (or any designer, human or agent).\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Read with:"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "../HANDOFF.md",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "../HANDOFF.md"
        })
      }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "./00-foundation.md",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "00-foundation"
        })
      }), "\n(the brand, tokens, wiki-link states and motifs — all hold here unchanged),\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "./01-reading-view.md",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "01-reading-view"
        })
      }), " (the entry you are now putting in a card),\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "./02-shell-navigation-and-authoring.md",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "02-shell-navigation-and-authoring"
        })
      }), " (the chrome\naround the river). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "The behaviour contract"
      }), " is the docs repo's\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "content/specs/APP_CUSTOMIZATION_SPEC.mdx"
      }), " §6. Where this brief and §6 disagree, §6 wins;\nflag the disagreement rather than designing around it."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "how-a-reader-gets-here",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "how-a-reader-gets-here"
      }), "How a reader gets here"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "A wiki's author chooses the river in one of two ways. They can make it the wiki's only way\nto open, or offer it beside the normal page view as \"Open as Story river\". The river is a\nseparate app on top of Grove, and the host opens it on the wiki's files. That choice happens\noutside your surfaces, but it explains two things you'll see: the river can't write to the\nwiki itself (Edit asks the host), and the same wiki may also exist as ordinary Grove pages."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "what-youre-designing-in-one-paragraph",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "what-youre-designing-in-one-paragraph"
      }), "What you're designing, in one paragraph"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["A reading surface where entries ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "accumulate"
      }), " instead of replacing each other. The reader\nstarts with one card (say, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "Engineering"
      }), "). They click ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "Ada Lovelace"
      }), " inside it, and an\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "Ada Lovelace"
      }), " card slides in directly below. They click ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "Engineering"
      }), " again from Ada's\ncard: nothing new opens; the view scrolls back up to the Engineering card and briefly marks\nit. They close Ada's card with its ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "×"
      }), ". The URL always describes the river, so a shared\nlink or a reload reproduces it exactly. Design the river page, the card, every state a card\ncan be in, the motion for open / focus / close, and the chrome around the river, at\ndesktop and mobile widths, in dark and light."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "the-six-interactions-design-each-one-as-a-sequence-not-a-still",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-six-interactions-design-each-one-as-a-sequence-not-a-still"
      }), "The six interactions (design each one as a sequence, not a still)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "#"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Reader does"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "What must be visible"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "1"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Clicks a link, inside a card, to an entry that is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "not open"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["A new card appears ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "directly below"
            }), " the card containing the link, scrolls into view, takes focus. The reader must see where it came from."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "2"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Clicks a link in the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "sidebar, nav or search"
            }), " to an entry that is not open"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["A new card appears ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "at the top"
            }), " of the river and takes focus."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "3"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Clicks a link to an entry that is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "already open"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["No new card. The view scrolls to the existing card, which gets a brief ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "\"here it is\""
            }), " highlight, then settles. The order doesn't change."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "4"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Closes a card"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "It leaves; the cards below close the gap; focus lands on the heading of the card that took its place."
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "5"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Presses Back"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "The previous river comes back exactly: the last-opened card is gone again. No special UI — but the transition must not look like a crash."
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "6"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Clicks ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Edit"
            }), " on a card"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "The control shows it is asking; the host opens the workbench editor on that entry (not yours to draw — show it as a labelled placeholder region). The river stays exactly where it was, and the edited card is marked. If the host declines, the note appears in the card header and the river is otherwise untouched."
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Interaction 3 is the one most likely to feel broken if under-designed: the reader clicked a\nlink and \"nothing opened\". The highlight has to read as a deliberate answer (\"it's this\none, already open\"), not a glitch."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "the-card",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-card"
      }), "The card"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "A card is one Grove entry, reading exactly as in brief 01, inside a river-owned frame."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Header"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".river-card__header"
        }), ")", "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
          children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
            children: "The entry title: Gabarito, ends on a period, may take the gradient clip like any entry\ntitle. This is the card's focus target and accessible name."
          }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Close"
            }), " — Lucide ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "x"
            }), ", 16–20px, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "currentColor"
            }), ", a 44×44 touch target on mobile.\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Absent"
            }), " on the only card in the river (the river is never empty)."]
          }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Copy link to this entry"
            }), " — Lucide ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "link"
            }), ". Copies a link that opens a river of just\nthis card. Needs a quiet confirmation state (\"Link copied.\")."]
          }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Edit"
            }), " — Lucide ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "pencil"
            }), ", the TiddlyWiki-style call to action on every card. It\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "asks the workbench to open this entry in its main editor pane"
            }), "; the editor itself is\nthe host's, beside or around the app, and is not yours to draw. The request can be\ndeclined, so the control needs four looks: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "ready"
            }), "; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "asking"
            }), " (a brief busy state\nwhile the host responds); ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "declined"
            }), " (a short inline note in the card header, e.g.\n\"Editing isn't available here.\", never a dialog); and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "absent"
            }), " when the host says the\nreader can't edit this wiki. When the reader simply closes the editor, the card shows\nnothing."]
          }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: ["Optional: a mono micro-label with the entry's path or section (Space Mono,\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "--ink-3"
            }), "), if it helps the reader tell cards apart in a long river. Your call — show\nwith and without."]
          }), "\n"]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Body"
        }), " — the entry's prose and components, as brief 01. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "No section layout"
        }), " (no\nhero band, no \"more people\" rail): a card is just the entry."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Footer"
        }), " — the entry's metadata line and tags, as stock."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Card separation is the central visual question."
      }), " Options to explore, not a\nprescription: hairline-bordered ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "--panel"
      }), " cards with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "--r-lg"
      }), ", versus borderless prose\ndivided by a hairline rule with the header as the only frame. Long cards must still read\nas ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "one entry each"
      }), " at a glance, and the brand's hard-offset hover shadow must not make a\nwhole card look clickable."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "card-states-each-one-needs-a-frame",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "card-states-each-one-needs-a-frame"
      }), "Card states (each one needs a frame)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Resting"
        }), " — open, not focused."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Focused"
        }), " — the card the reader is on. Subtle: an accent hairline on the leading\nedge, or a header tint. It changes as the reader scrolls, so it must never be loud."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Just opened"
        }), " — the entrance (interaction 1 / 2)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Found"
        }), " — the \"here it is\" highlight (interaction 3). Short, decays to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "focused"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Loading"
        }), " — cards render lazily and a large entry takes seconds. A skeleton at a\nplausible height, with the title already shown (the river knows it before the body\nloads). Reuse brief 05's skeleton language."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Closing"
        }), " — the exit, and the gap closing behind it."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Could not open"
        }), " — a key in a shared link no longer exists. Don't draw a broken card:\nthe river shows a single dismissible notice at the top (\"1 entry in this link no longer\nexists.\") and opens the rest."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Read-only"
        }), " — the host says this reader can't edit: no Edit control; nothing else\nchanges."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Edit requested"
        }), " — the header while the workbench editor is opening this entry, and\nafter: which card is being edited should be visible at a glance (a quiet marker on the\nheader), so the reader can find their place when they come back from the editor."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "the-page-around-the-river",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-page-around-the-river"
      }), "The page around the river"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Desktop:"
        }), " the stock Grove chrome (brief 02: nav, sidebar, search, theme control,\nfooter) around a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "single river column"
        }), " at the reading measure (brief 00's ~68–72ch).\nA ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "rail"
        }), " beside the river shows the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "focused card's"
        }), " table of contents and backlinks;\nit updates as focus moves. Design the moment the rail changes its content: it should be\ncalm, not flicker on every scroll."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Sidebar and open cards:"
        }), " the sidebar highlights the focused entry as it does today.\nExplore whether it should also ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "mark the other open entries"
        }), " (a dot, a tick, a weight\nchange) — that marker is how interaction 3 becomes predictable before the click."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Mobile (value 8 — not an afterthought):"
        }), " one column, no rail. The card header may\nstick while its card is in view, so close and edit stay reachable in a long entry; show\nwhether that helps or crowds the screen. The sidebar lives in the existing drawer.\nInteraction 1 on a phone scrolls the reader away from the link they tapped — show how\nthey understand what happened and how they get back (Back, or scrolling up to the\nsource card)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "A long river:"
        }), " show one with 8–10 cards, most collapsed out of view, to prove the\npage still has a shape and the focused card is findable."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "motion",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "motion"
      }), "Motion"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Restrained, as the brand requires (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: ".14s"
      }), "-scale transitions). Open, close, and the found\nhighlight are the only animations. Everything has a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "reduced-motion"
      }), " variant: no slide,\nno scroll animation — the card simply appears, and the highlight is a static outline that\nfades."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sample-content-use-the-real-grove-corpus",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sample-content-use-the-real-grove-corpus"
      }), "Sample content (use the real Grove corpus)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Grove's own sample wiki (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "grove/content/"
      }), ") is a fictional company, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "Meridian"
      }), ". Build the\nmockup from it so the river looks like a real reading session:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["Start on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Home"
        }), ". Open ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Engineering"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "teams/engineering.mdx"
        }), ") from the nav\n(interaction 2, top insert). In the Engineering card, open ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Incident response"
        }), "\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "processes/incident-response.mdx"
        }), ") from its prose, and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Ada Lovelace"
        }), "\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "people/ada-lovelace.mdx"
        }), ") from its people directory (interaction 1, each directly\nbelow Engineering). In Ada's card, click \"engineering\" — Engineering is already open\n(interaction 3)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["Every sample entry is short (the longest is ~45 lines). For the long-card frames, extend\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Onboarding"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "handbook/onboarding.mdx"
        }), ") with plausible extra sections, and label the\nframe as padded sample content."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "hard-constraints",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "hard-constraints"
      }), "Hard constraints"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Tokens only."
        }), " Every colour, radius, shadow and font comes from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/index.css"
        }), "\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--bg"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--panel"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--panel-2"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--ink"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--ink-2"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--ink-3"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--line"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--line-2"
        }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--accent"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--accent-2"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--grad"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--r-*"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--shadow-card"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--disp"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--sans"
        }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--mono"
        }), "). New classes follow Grove's naming (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".river-*"
        }), " beside the existing\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".grove-*"
        }), "), so a CSS-only theme can re-skin the river like everything else."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Dark default, light via ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "data-theme=\"light\""
          })]
        }), " — deliver both for the river page and\nthe card states."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Sentence case, headlines end on a period, no emoji."
        }), " Icons are Lucide at 16–24px in\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "currentColor"
        }), ": ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "x"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "link"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "pencil"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "chevron-*"
        }), " as needed."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Don't draw host chrome."
        }), " The immediately.run host frame, sign-in, consent prompts, its\nseam or header UI, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "the workbench editor"
        }), " that Edit opens, and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "the first-use prompt"
        }), "\nthat asks a reader to allow the river to open a wiki are all the host's. The river is inside\nthe app's frame. Imitating host chrome is treated as spoofing."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The body vocabulary is Grove's safe set."
        }), " The river renders entries with Grove's safe\nrenderer, so a card shows Grove's built-in components (brief 03) and nothing a wiki ships\nas its own code. Don't design wiki-specific widgets into cards."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "One theme across the river."
        }), " Cards don't carry their own themes; the river takes the\nhome entry's. Don't design per-card theming."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Accessibility:"
        }), " each card is an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "article"
        }), " labelled by its title heading;\nclose and copy are real buttons with labels; focus moves visibly on open and close; the\nfound highlight isn't colour-only."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "out-of-scope-dont-design-these",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "out-of-scope-dont-design-these"
      }), "Out of scope (don't design these)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Drag-to-reorder cards, editing inside a card (Edit hands off to the workbench), close-all /\nclose-others, a\npermalink-versus-permaview toggle, and any server or sync indicator. The river exists only\nin the URL."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "deliverables",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "deliverables"
      }), "Deliverables"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["The river page at ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "desktop and mobile"
        }), ", dark and light, with the sample session above."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["The ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "card"
        }), " in all nine states, plus the Edit control's four looks."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Sequences"
        }), " (storyboards or prototype) for the six interactions, plus reduced-motion\nvariants of 1, 3 and 4."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["The ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "rail"
        }), " (desktop) following focus, and the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "sidebar"
        }), " with the open-entry marker\nexplored."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["A ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "long river"
        }), " (8–10 cards)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["The river under ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "one alternate Grove theme"
        }), " (brief 05's showcase) — same DOM, CSS\nonly — to prove the new classes are themeable."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: "A short note on the open design questions below, with your recommendation."
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "open-design-questions-answer-with-a-recommendation",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "open-design-questions-answer-with-a-recommendation"
      }), "Open design questions (answer with a recommendation)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Card frame:"
        }), " bordered panel or ruled prose (see ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "The card"
        }), ")?"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Focused-card indicator:"
        }), " how quiet can it be and still be findable in a long river?"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Chrome-link insertion:"
        }), " the spec defaults sidebar/nav/search opens to the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "top"
        }), " of\nthe river (TiddlyWiki's rule). If, deep in a long river, a top insert disorients more\nthan it helps, say so and propose \"below the focused card\" instead."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Sticky card header on mobile:"
        }), " does it earn its space?"]
      }), "\n"]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/design-briefs/grove/briefs/08-story-river.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiY29kZSIsImVtIiwiaDEiLCJoMiIsImhyIiwibGkiLCJvbCIsInAiLCJzdHJvbmciLCJ0YWJsZSIsInRib2R5IiwidGQiLCJ0aCIsInRoZWFkIiwidHIiLCJ1bCIsIl9wcm92aWRlQ29tcG9uZW50cyIsImNvbXBvbmVudHMiLCJIZWFkaW5nQW5jaG9yIiwiX21pc3NpbmdNZHhSZWZlcmVuY2UiLCJqc3hzIiwiRnJhZ21lbnQiLCJjaGlsZHJlbiIsImlkIiwianN4IiwiaHJlZiIsIk1EWENvbnRlbnQiLCJ3cmFwcGVyIiwiTURYTGF5b3V0IiwiX2MiLCJjb21wb25lbnQiLCJwbGFjZSIsIkVycm9yIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiMDgtc3Rvcnktcml2ZXIubWQiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgYTogXCJhXCIsXG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgZW06IFwiZW1cIixcbiAgICBoMTogXCJoMVwiLFxuICAgIGgyOiBcImgyXCIsXG4gICAgaHI6IFwiaHJcIixcbiAgICBsaTogXCJsaVwiLFxuICAgIG9sOiBcIm9sXCIsXG4gICAgcDogXCJwXCIsXG4gICAgc3Ryb25nOiBcInN0cm9uZ1wiLFxuICAgIHRhYmxlOiBcInRhYmxlXCIsXG4gICAgdGJvZHk6IFwidGJvZHlcIixcbiAgICB0ZDogXCJ0ZFwiLFxuICAgIHRoOiBcInRoXCIsXG4gICAgdGhlYWQ6IFwidGhlYWRcIixcbiAgICB0cjogXCJ0clwiLFxuICAgIHVsOiBcInVsXCIsXG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9LCB7SGVhZGluZ0FuY2hvcn0gPSBfY29tcG9uZW50cztcbiAgaWYgKCFIZWFkaW5nQW5jaG9yKSBfbWlzc2luZ01keFJlZmVyZW5jZShcIkhlYWRpbmdBbmNob3JcIiwgdHJ1ZSk7XG4gIHJldHVybiA8PjxfY29tcG9uZW50cy5oMSBpZD1cImJyaWVmLTA4LXRoZS1zdG9yeS1yaXZlci1hLXRpZGRseXdpa2ktc3R5bGUtcmVhZGluZy1tb2RlXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJicmllZi0wOC10aGUtc3Rvcnktcml2ZXItYS10aWRkbHl3aWtpLXN0eWxlLXJlYWRpbmctbW9kZVwiIC8+e1wiQnJpZWYgMDgg4oCUIFRoZSBzdG9yeSByaXZlciAoYSBUaWRkbHlXaWtpLXN0eWxlIHJlYWRpbmcgbW9kZSlcIn08L19jb21wb25lbnRzLmgxPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkEgc2Vjb25kIHdheSB0byByZWFkIGEgR3JvdmU6IGluc3RlYWQgb2Ygb25lIGVudHJ5IHBlciBwYWdlLCB0aGUgcmVhZGVyIGtlZXBzIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJzaW5nbGVcXG5jb2x1bW4gb2Ygb3BlbiBlbnRyaWVzIOKAlCB0aGUgc3Rvcnkgcml2ZXJcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIGFuZCBmb2xsb3dpbmcgYSBsaW5rIG9wZW5zIHRoZSB0YXJnZXQgYXMgYVxcbm5ldyBjYXJkIGluIHRoYXQgY29sdW1uLiBUaGlzIGlzIGFuIGhvbWFnZSB0byBUaWRkbHlXaWtpLCBvbmUgb2YgaW1tZWRpYXRlbHkucnVuJ3NcXG5pbnNwaXJhdGlvbnMuIEl0IGlzIGJ1aWx0IGFzIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJzZXBhcmF0ZSBhcHAgb24gdG9wIG9mIEdyb3ZlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBzbyBldmVyeSBzdXJmYWNlIGhlcmUgaXNcXG5Hcm92ZSdzIGV4aXN0aW5nIHZvY2FidWxhcnkgcmVhcnJhbmdlZCwgbm90IGEgbmV3IHZpc3VhbCBsYW5ndWFnZS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJGb3I6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIENsYXVkZSBEZXNpZ24gKG9yIGFueSBkZXNpZ25lciwgaHVtYW4gb3IgYWdlbnQpLlxcblwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiUmVhZCB3aXRoOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuYSBocmVmPVwiLi4vSEFORE9GRi5tZFwiPjxfY29tcG9uZW50cy5jb2RlPntcIi4uL0hBTkRPRkYubWRcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5hPntcIiBhbmQgXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cIi4vMDAtZm91bmRhdGlvbi5tZFwiPjxfY29tcG9uZW50cy5jb2RlPntcIjAwLWZvdW5kYXRpb25cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5hPntcIlxcbih0aGUgYnJhbmQsIHRva2Vucywgd2lraS1saW5rIHN0YXRlcyBhbmQgbW90aWZzIOKAlCBhbGwgaG9sZCBoZXJlIHVuY2hhbmdlZCksXFxuXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cIi4vMDEtcmVhZGluZy12aWV3Lm1kXCI+PF9jb21wb25lbnRzLmNvZGU+e1wiMDEtcmVhZGluZy12aWV3XCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuYT57XCIgKHRoZSBlbnRyeSB5b3UgYXJlIG5vdyBwdXR0aW5nIGluIGEgY2FyZCksXFxuXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cIi4vMDItc2hlbGwtbmF2aWdhdGlvbi1hbmQtYXV0aG9yaW5nLm1kXCI+PF9jb21wb25lbnRzLmNvZGU+e1wiMDItc2hlbGwtbmF2aWdhdGlvbi1hbmQtYXV0aG9yaW5nXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuYT57XCIgKHRoZSBjaHJvbWVcXG5hcm91bmQgdGhlIHJpdmVyKS4gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgYmVoYXZpb3VyIGNvbnRyYWN0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGlzIHRoZSBkb2NzIHJlcG8nc1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcImNvbnRlbnQvc3BlY3MvQVBQX0NVU1RPTUlaQVRJT05fU1BFQy5tZHhcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIMKnNi4gV2hlcmUgdGhpcyBicmllZiBhbmQgwqc2IGRpc2FncmVlLCDCpzYgd2lucztcXG5mbGFnIHRoZSBkaXNhZ3JlZW1lbnQgcmF0aGVyIHRoYW4gZGVzaWduaW5nIGFyb3VuZCBpdC5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmhyIC8+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwiaG93LWEtcmVhZGVyLWdldHMtaGVyZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiaG93LWEtcmVhZGVyLWdldHMtaGVyZVwiIC8+e1wiSG93IGEgcmVhZGVyIGdldHMgaGVyZVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiQSB3aWtpJ3MgYXV0aG9yIGNob29zZXMgdGhlIHJpdmVyIGluIG9uZSBvZiB0d28gd2F5cy4gVGhleSBjYW4gbWFrZSBpdCB0aGUgd2lraSdzIG9ubHkgd2F5XFxudG8gb3Blbiwgb3Igb2ZmZXIgaXQgYmVzaWRlIHRoZSBub3JtYWwgcGFnZSB2aWV3IGFzIFxcXCJPcGVuIGFzIFN0b3J5IHJpdmVyXFxcIi4gVGhlIHJpdmVyIGlzIGFcXG5zZXBhcmF0ZSBhcHAgb24gdG9wIG9mIEdyb3ZlLCBhbmQgdGhlIGhvc3Qgb3BlbnMgaXQgb24gdGhlIHdpa2kncyBmaWxlcy4gVGhhdCBjaG9pY2UgaGFwcGVuc1xcbm91dHNpZGUgeW91ciBzdXJmYWNlcywgYnV0IGl0IGV4cGxhaW5zIHR3byB0aGluZ3MgeW91J2xsIHNlZTogdGhlIHJpdmVyIGNhbid0IHdyaXRlIHRvIHRoZVxcbndpa2kgaXRzZWxmIChFZGl0IGFza3MgdGhlIGhvc3QpLCBhbmQgdGhlIHNhbWUgd2lraSBtYXkgYWxzbyBleGlzdCBhcyBvcmRpbmFyeSBHcm92ZSBwYWdlcy5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwid2hhdC15b3VyZS1kZXNpZ25pbmctaW4tb25lLXBhcmFncmFwaFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwid2hhdC15b3VyZS1kZXNpZ25pbmctaW4tb25lLXBhcmFncmFwaFwiIC8+e1wiV2hhdCB5b3UncmUgZGVzaWduaW5nLCBpbiBvbmUgcGFyYWdyYXBoXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJBIHJlYWRpbmcgc3VyZmFjZSB3aGVyZSBlbnRyaWVzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiYWNjdW11bGF0ZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBpbnN0ZWFkIG9mIHJlcGxhY2luZyBlYWNoIG90aGVyLiBUaGUgcmVhZGVyXFxuc3RhcnRzIHdpdGggb25lIGNhcmQgKHNheSwgXCJ9PF9jb21wb25lbnRzLmVtPntcIkVuZ2luZWVyaW5nXCJ9PC9fY29tcG9uZW50cy5lbT57XCIpLiBUaGV5IGNsaWNrIFwifTxfY29tcG9uZW50cy5lbT57XCJBZGEgTG92ZWxhY2VcIn08L19jb21wb25lbnRzLmVtPntcIiBpbnNpZGUgaXQsIGFuZCBhblxcblwifTxfY29tcG9uZW50cy5lbT57XCJBZGEgTG92ZWxhY2VcIn08L19jb21wb25lbnRzLmVtPntcIiBjYXJkIHNsaWRlcyBpbiBkaXJlY3RseSBiZWxvdy4gVGhleSBjbGljayBcIn08X2NvbXBvbmVudHMuZW0+e1wiRW5naW5lZXJpbmdcIn08L19jb21wb25lbnRzLmVtPntcIiBhZ2FpbiBmcm9tIEFkYSdzXFxuY2FyZDogbm90aGluZyBuZXcgb3BlbnM7IHRoZSB2aWV3IHNjcm9sbHMgYmFjayB1cCB0byB0aGUgRW5naW5lZXJpbmcgY2FyZCBhbmQgYnJpZWZseSBtYXJrc1xcbml0LiBUaGV5IGNsb3NlIEFkYSdzIGNhcmQgd2l0aCBpdHMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCLDl1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIi4gVGhlIFVSTCBhbHdheXMgZGVzY3JpYmVzIHRoZSByaXZlciwgc28gYSBzaGFyZWRcXG5saW5rIG9yIGEgcmVsb2FkIHJlcHJvZHVjZXMgaXQgZXhhY3RseS4gRGVzaWduIHRoZSByaXZlciBwYWdlLCB0aGUgY2FyZCwgZXZlcnkgc3RhdGUgYSBjYXJkXFxuY2FuIGJlIGluLCB0aGUgbW90aW9uIGZvciBvcGVuIC8gZm9jdXMgLyBjbG9zZSwgYW5kIHRoZSBjaHJvbWUgYXJvdW5kIHRoZSByaXZlciwgYXRcXG5kZXNrdG9wIGFuZCBtb2JpbGUgd2lkdGhzLCBpbiBkYXJrIGFuZCBsaWdodC5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwidGhlLXNpeC1pbnRlcmFjdGlvbnMtZGVzaWduLWVhY2gtb25lLWFzLWEtc2VxdWVuY2Utbm90LWEtc3RpbGxcIj48SGVhZGluZ0FuY2hvciBpZD1cInRoZS1zaXgtaW50ZXJhY3Rpb25zLWRlc2lnbi1lYWNoLW9uZS1hcy1hLXNlcXVlbmNlLW5vdC1hLXN0aWxsXCIgLz57XCJUaGUgc2l4IGludGVyYWN0aW9ucyAoZGVzaWduIGVhY2ggb25lIGFzIGEgc2VxdWVuY2UsIG5vdCBhIHN0aWxsKVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnRhYmxlPjxfY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRoPntcIiNcIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aD57XCJSZWFkZXIgZG9lc1wifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIldoYXQgbXVzdCBiZSB2aXNpYmxlXCJ9PC9fY29tcG9uZW50cy50aD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGhlYWQ+PF9jb21wb25lbnRzLnRib2R5PjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiMVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIkNsaWNrcyBhIGxpbmssIGluc2lkZSBhIGNhcmQsIHRvIGFuIGVudHJ5IHRoYXQgaXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJub3Qgb3BlblwifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIkEgbmV3IGNhcmQgYXBwZWFycyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImRpcmVjdGx5IGJlbG93XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHRoZSBjYXJkIGNvbnRhaW5pbmcgdGhlIGxpbmssIHNjcm9sbHMgaW50byB2aWV3LCB0YWtlcyBmb2N1cy4gVGhlIHJlYWRlciBtdXN0IHNlZSB3aGVyZSBpdCBjYW1lIGZyb20uXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiMlwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIkNsaWNrcyBhIGxpbmsgaW4gdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wic2lkZWJhciwgbmF2IG9yIHNlYXJjaFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB0byBhbiBlbnRyeSB0aGF0IGlzIG5vdCBvcGVuXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiQSBuZXcgY2FyZCBhcHBlYXJzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiYXQgdGhlIHRvcFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBvZiB0aGUgcml2ZXIgYW5kIHRha2VzIGZvY3VzLlwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIjNcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJDbGlja3MgYSBsaW5rIHRvIGFuIGVudHJ5IHRoYXQgaXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJhbHJlYWR5IG9wZW5cIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJObyBuZXcgY2FyZC4gVGhlIHZpZXcgc2Nyb2xscyB0byB0aGUgZXhpc3RpbmcgY2FyZCwgd2hpY2ggZ2V0cyBhIGJyaWVmIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiXFxcImhlcmUgaXQgaXNcXFwiXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGhpZ2hsaWdodCwgdGhlbiBzZXR0bGVzLiBUaGUgb3JkZXIgZG9lc24ndCBjaGFuZ2UuXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiNFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIkNsb3NlcyBhIGNhcmRcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJJdCBsZWF2ZXM7IHRoZSBjYXJkcyBiZWxvdyBjbG9zZSB0aGUgZ2FwOyBmb2N1cyBsYW5kcyBvbiB0aGUgaGVhZGluZyBvZiB0aGUgY2FyZCB0aGF0IHRvb2sgaXRzIHBsYWNlLlwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIjVcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJQcmVzc2VzIEJhY2tcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJUaGUgcHJldmlvdXMgcml2ZXIgY29tZXMgYmFjayBleGFjdGx5OiB0aGUgbGFzdC1vcGVuZWQgY2FyZCBpcyBnb25lIGFnYWluLiBObyBzcGVjaWFsIFVJIOKAlCBidXQgdGhlIHRyYW5zaXRpb24gbXVzdCBub3QgbG9vayBsaWtlIGEgY3Jhc2guXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiNlwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIkNsaWNrcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIkVkaXRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgb24gYSBjYXJkXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiVGhlIGNvbnRyb2wgc2hvd3MgaXQgaXMgYXNraW5nOyB0aGUgaG9zdCBvcGVucyB0aGUgd29ya2JlbmNoIGVkaXRvciBvbiB0aGF0IGVudHJ5IChub3QgeW91cnMgdG8gZHJhdyDigJQgc2hvdyBpdCBhcyBhIGxhYmVsbGVkIHBsYWNlaG9sZGVyIHJlZ2lvbikuIFRoZSByaXZlciBzdGF5cyBleGFjdGx5IHdoZXJlIGl0IHdhcywgYW5kIHRoZSBlZGl0ZWQgY2FyZCBpcyBtYXJrZWQuIElmIHRoZSBob3N0IGRlY2xpbmVzLCB0aGUgbm90ZSBhcHBlYXJzIGluIHRoZSBjYXJkIGhlYWRlciBhbmQgdGhlIHJpdmVyIGlzIG90aGVyd2lzZSB1bnRvdWNoZWQuXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGJvZHk+PC9fY29tcG9uZW50cy50YWJsZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJJbnRlcmFjdGlvbiAzIGlzIHRoZSBvbmUgbW9zdCBsaWtlbHkgdG8gZmVlbCBicm9rZW4gaWYgdW5kZXItZGVzaWduZWQ6IHRoZSByZWFkZXIgY2xpY2tlZCBhXFxubGluayBhbmQgXFxcIm5vdGhpbmcgb3BlbmVkXFxcIi4gVGhlIGhpZ2hsaWdodCBoYXMgdG8gcmVhZCBhcyBhIGRlbGliZXJhdGUgYW5zd2VyIChcXFwiaXQncyB0aGlzXFxub25lLCBhbHJlYWR5IG9wZW5cXFwiKSwgbm90IGEgZ2xpdGNoLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJ0aGUtY2FyZFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwidGhlLWNhcmRcIiAvPntcIlRoZSBjYXJkXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJBIGNhcmQgaXMgb25lIEdyb3ZlIGVudHJ5LCByZWFkaW5nIGV4YWN0bHkgYXMgaW4gYnJpZWYgMDEsIGluc2lkZSBhIHJpdmVyLW93bmVkIGZyYW1lLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiSGVhZGVyXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChcIn08X2NvbXBvbmVudHMuY29kZT57XCIucml2ZXItY2FyZF9faGVhZGVyXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIilcIn17XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIlRoZSBlbnRyeSB0aXRsZTogR2FiYXJpdG8sIGVuZHMgb24gYSBwZXJpb2QsIG1heSB0YWtlIHRoZSBncmFkaWVudCBjbGlwIGxpa2UgYW55IGVudHJ5XFxudGl0bGUuIFRoaXMgaXMgdGhlIGNhcmQncyBmb2N1cyB0YXJnZXQgYW5kIGFjY2Vzc2libGUgbmFtZS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkNsb3NlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBMdWNpZGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wieFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIDE24oCTMjBweCwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY3VycmVudENvbG9yXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgYSA0NMOXNDQgdG91Y2ggdGFyZ2V0IG9uIG1vYmlsZS5cXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIkFic2VudFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBvbiB0aGUgb25seSBjYXJkIGluIHRoZSByaXZlciAodGhlIHJpdmVyIGlzIG5ldmVyIGVtcHR5KS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkNvcHkgbGluayB0byB0aGlzIGVudHJ5XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBMdWNpZGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibGlua1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIuIENvcGllcyBhIGxpbmsgdGhhdCBvcGVucyBhIHJpdmVyIG9mIGp1c3RcXG50aGlzIGNhcmQuIE5lZWRzIGEgcXVpZXQgY29uZmlybWF0aW9uIHN0YXRlIChcXFwiTGluayBjb3BpZWQuXFxcIikuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJFZGl0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBMdWNpZGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicGVuY2lsXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgdGhlIFRpZGRseVdpa2ktc3R5bGUgY2FsbCB0byBhY3Rpb24gb24gZXZlcnkgY2FyZC4gSXRcXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImFza3MgdGhlIHdvcmtiZW5jaCB0byBvcGVuIHRoaXMgZW50cnkgaW4gaXRzIG1haW4gZWRpdG9yIHBhbmVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCI7IHRoZSBlZGl0b3IgaXRzZWxmIGlzXFxudGhlIGhvc3QncywgYmVzaWRlIG9yIGFyb3VuZCB0aGUgYXBwLCBhbmQgaXMgbm90IHlvdXJzIHRvIGRyYXcuIFRoZSByZXF1ZXN0IGNhbiBiZVxcbmRlY2xpbmVkLCBzbyB0aGUgY29udHJvbCBuZWVkcyBmb3VyIGxvb2tzOiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInJlYWR5XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiOyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImFza2luZ1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoYSBicmllZiBidXN5IHN0YXRlXFxud2hpbGUgdGhlIGhvc3QgcmVzcG9uZHMpOyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImRlY2xpbmVkXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChhIHNob3J0IGlubGluZSBub3RlIGluIHRoZSBjYXJkIGhlYWRlciwgZS5nLlxcblxcXCJFZGl0aW5nIGlzbid0IGF2YWlsYWJsZSBoZXJlLlxcXCIsIG5ldmVyIGEgZGlhbG9nKTsgYW5kIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiYWJzZW50XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHdoZW4gdGhlIGhvc3Qgc2F5cyB0aGVcXG5yZWFkZXIgY2FuJ3QgZWRpdCB0aGlzIHdpa2kuIFdoZW4gdGhlIHJlYWRlciBzaW1wbHkgY2xvc2VzIHRoZSBlZGl0b3IsIHRoZSBjYXJkIHNob3dzXFxubm90aGluZy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJPcHRpb25hbDogYSBtb25vIG1pY3JvLWxhYmVsIHdpdGggdGhlIGVudHJ5J3MgcGF0aCBvciBzZWN0aW9uIChTcGFjZSBNb25vLFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcIi0taW5rLTNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSwgaWYgaXQgaGVscHMgdGhlIHJlYWRlciB0ZWxsIGNhcmRzIGFwYXJ0IGluIGEgbG9uZyByaXZlci4gWW91ciBjYWxsIOKAlCBzaG93XFxud2l0aCBhbmQgd2l0aG91dC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJCb2R5XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCB0aGUgZW50cnkncyBwcm9zZSBhbmQgY29tcG9uZW50cywgYXMgYnJpZWYgMDEuIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiTm8gc2VjdGlvbiBsYXlvdXRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKG5vXFxuaGVybyBiYW5kLCBubyBcXFwibW9yZSBwZW9wbGVcXFwiIHJhaWwpOiBhIGNhcmQgaXMganVzdCB0aGUgZW50cnkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJGb290ZXJcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHRoZSBlbnRyeSdzIG1ldGFkYXRhIGxpbmUgYW5kIHRhZ3MsIGFzIHN0b2NrLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkNhcmQgc2VwYXJhdGlvbiBpcyB0aGUgY2VudHJhbCB2aXN1YWwgcXVlc3Rpb24uXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIE9wdGlvbnMgdG8gZXhwbG9yZSwgbm90IGFcXG5wcmVzY3JpcHRpb246IGhhaXJsaW5lLWJvcmRlcmVkIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi0tcGFuZWxcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNhcmRzIHdpdGggXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1yLWxnXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgdmVyc3VzIGJvcmRlcmxlc3MgcHJvc2VcXG5kaXZpZGVkIGJ5IGEgaGFpcmxpbmUgcnVsZSB3aXRoIHRoZSBoZWFkZXIgYXMgdGhlIG9ubHkgZnJhbWUuIExvbmcgY2FyZHMgbXVzdCBzdGlsbCByZWFkXFxuYXMgXCJ9PF9jb21wb25lbnRzLmVtPntcIm9uZSBlbnRyeSBlYWNoXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgYXQgYSBnbGFuY2UsIGFuZCB0aGUgYnJhbmQncyBoYXJkLW9mZnNldCBob3ZlciBzaGFkb3cgbXVzdCBub3QgbWFrZSBhXFxud2hvbGUgY2FyZCBsb29rIGNsaWNrYWJsZS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwiY2FyZC1zdGF0ZXMtZWFjaC1vbmUtbmVlZHMtYS1mcmFtZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiY2FyZC1zdGF0ZXMtZWFjaC1vbmUtbmVlZHMtYS1mcmFtZVwiIC8+e1wiQ2FyZCBzdGF0ZXMgKGVhY2ggb25lIG5lZWRzIGEgZnJhbWUpXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMub2w+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUmVzdGluZ1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgb3Blbiwgbm90IGZvY3VzZWQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJGb2N1c2VkXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCB0aGUgY2FyZCB0aGUgcmVhZGVyIGlzIG9uLiBTdWJ0bGU6IGFuIGFjY2VudCBoYWlybGluZSBvbiB0aGUgbGVhZGluZ1xcbmVkZ2UsIG9yIGEgaGVhZGVyIHRpbnQuIEl0IGNoYW5nZXMgYXMgdGhlIHJlYWRlciBzY3JvbGxzLCBzbyBpdCBtdXN0IG5ldmVyIGJlIGxvdWQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJKdXN0IG9wZW5lZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgdGhlIGVudHJhbmNlIChpbnRlcmFjdGlvbiAxIC8gMikuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJGb3VuZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgdGhlIFxcXCJoZXJlIGl0IGlzXFxcIiBoaWdobGlnaHQgKGludGVyYWN0aW9uIDMpLiBTaG9ydCwgZGVjYXlzIHRvIFwifTxfY29tcG9uZW50cy5lbT57XCJmb2N1c2VkXCJ9PC9fY29tcG9uZW50cy5lbT57XCIuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJMb2FkaW5nXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBjYXJkcyByZW5kZXIgbGF6aWx5IGFuZCBhIGxhcmdlIGVudHJ5IHRha2VzIHNlY29uZHMuIEEgc2tlbGV0b24gYXQgYVxcbnBsYXVzaWJsZSBoZWlnaHQsIHdpdGggdGhlIHRpdGxlIGFscmVhZHkgc2hvd24gKHRoZSByaXZlciBrbm93cyBpdCBiZWZvcmUgdGhlIGJvZHlcXG5sb2FkcykuIFJldXNlIGJyaWVmIDA1J3Mgc2tlbGV0b24gbGFuZ3VhZ2UuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJDbG9zaW5nXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCB0aGUgZXhpdCwgYW5kIHRoZSBnYXAgY2xvc2luZyBiZWhpbmQgaXQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJDb3VsZCBub3Qgb3BlblwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgYSBrZXkgaW4gYSBzaGFyZWQgbGluayBubyBsb25nZXIgZXhpc3RzLiBEb24ndCBkcmF3IGEgYnJva2VuIGNhcmQ6XFxudGhlIHJpdmVyIHNob3dzIGEgc2luZ2xlIGRpc21pc3NpYmxlIG5vdGljZSBhdCB0aGUgdG9wIChcXFwiMSBlbnRyeSBpbiB0aGlzIGxpbmsgbm8gbG9uZ2VyXFxuZXhpc3RzLlxcXCIpIGFuZCBvcGVucyB0aGUgcmVzdC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlJlYWQtb25seVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgdGhlIGhvc3Qgc2F5cyB0aGlzIHJlYWRlciBjYW4ndCBlZGl0OiBubyBFZGl0IGNvbnRyb2w7IG5vdGhpbmcgZWxzZVxcbmNoYW5nZXMuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJFZGl0IHJlcXVlc3RlZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgdGhlIGhlYWRlciB3aGlsZSB0aGUgd29ya2JlbmNoIGVkaXRvciBpcyBvcGVuaW5nIHRoaXMgZW50cnksIGFuZFxcbmFmdGVyOiB3aGljaCBjYXJkIGlzIGJlaW5nIGVkaXRlZCBzaG91bGQgYmUgdmlzaWJsZSBhdCBhIGdsYW5jZSAoYSBxdWlldCBtYXJrZXIgb24gdGhlXFxuaGVhZGVyKSwgc28gdGhlIHJlYWRlciBjYW4gZmluZCB0aGVpciBwbGFjZSB3aGVuIHRoZXkgY29tZSBiYWNrIGZyb20gdGhlIGVkaXRvci5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMub2w+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwidGhlLXBhZ2UtYXJvdW5kLXRoZS1yaXZlclwiPjxIZWFkaW5nQW5jaG9yIGlkPVwidGhlLXBhZ2UtYXJvdW5kLXRoZS1yaXZlclwiIC8+e1wiVGhlIHBhZ2UgYXJvdW5kIHRoZSByaXZlclwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkRlc2t0b3A6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHRoZSBzdG9jayBHcm92ZSBjaHJvbWUgKGJyaWVmIDAyOiBuYXYsIHNpZGViYXIsIHNlYXJjaCwgdGhlbWUgY29udHJvbCxcXG5mb290ZXIpIGFyb3VuZCBhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wic2luZ2xlIHJpdmVyIGNvbHVtblwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBhdCB0aGUgcmVhZGluZyBtZWFzdXJlIChicmllZiAwMCdzIH42OOKAkzcyY2gpLlxcbkEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJyYWlsXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGJlc2lkZSB0aGUgcml2ZXIgc2hvd3MgdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZm9jdXNlZCBjYXJkJ3NcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdGFibGUgb2YgY29udGVudHMgYW5kIGJhY2tsaW5rcztcXG5pdCB1cGRhdGVzIGFzIGZvY3VzIG1vdmVzLiBEZXNpZ24gdGhlIG1vbWVudCB0aGUgcmFpbCBjaGFuZ2VzIGl0cyBjb250ZW50OiBpdCBzaG91bGQgYmVcXG5jYWxtLCBub3QgZmxpY2tlciBvbiBldmVyeSBzY3JvbGwuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJTaWRlYmFyIGFuZCBvcGVuIGNhcmRzOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB0aGUgc2lkZWJhciBoaWdobGlnaHRzIHRoZSBmb2N1c2VkIGVudHJ5IGFzIGl0IGRvZXMgdG9kYXkuXFxuRXhwbG9yZSB3aGV0aGVyIGl0IHNob3VsZCBhbHNvIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibWFyayB0aGUgb3RoZXIgb3BlbiBlbnRyaWVzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChhIGRvdCwgYSB0aWNrLCBhIHdlaWdodFxcbmNoYW5nZSkg4oCUIHRoYXQgbWFya2VyIGlzIGhvdyBpbnRlcmFjdGlvbiAzIGJlY29tZXMgcHJlZGljdGFibGUgYmVmb3JlIHRoZSBjbGljay5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIk1vYmlsZSAodmFsdWUgOCDigJQgbm90IGFuIGFmdGVydGhvdWdodCk6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIG9uZSBjb2x1bW4sIG5vIHJhaWwuIFRoZSBjYXJkIGhlYWRlciBtYXlcXG5zdGljayB3aGlsZSBpdHMgY2FyZCBpcyBpbiB2aWV3LCBzbyBjbG9zZSBhbmQgZWRpdCBzdGF5IHJlYWNoYWJsZSBpbiBhIGxvbmcgZW50cnk7IHNob3dcXG53aGV0aGVyIHRoYXQgaGVscHMgb3IgY3Jvd2RzIHRoZSBzY3JlZW4uIFRoZSBzaWRlYmFyIGxpdmVzIGluIHRoZSBleGlzdGluZyBkcmF3ZXIuXFxuSW50ZXJhY3Rpb24gMSBvbiBhIHBob25lIHNjcm9sbHMgdGhlIHJlYWRlciBhd2F5IGZyb20gdGhlIGxpbmsgdGhleSB0YXBwZWQg4oCUIHNob3cgaG93XFxudGhleSB1bmRlcnN0YW5kIHdoYXQgaGFwcGVuZWQgYW5kIGhvdyB0aGV5IGdldCBiYWNrIChCYWNrLCBvciBzY3JvbGxpbmcgdXAgdG8gdGhlXFxuc291cmNlIGNhcmQpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQSBsb25nIHJpdmVyOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBzaG93IG9uZSB3aXRoIDjigJMxMCBjYXJkcywgbW9zdCBjb2xsYXBzZWQgb3V0IG9mIHZpZXcsIHRvIHByb3ZlIHRoZVxcbnBhZ2Ugc3RpbGwgaGFzIGEgc2hhcGUgYW5kIHRoZSBmb2N1c2VkIGNhcmQgaXMgZmluZGFibGUuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cIm1vdGlvblwiPjxIZWFkaW5nQW5jaG9yIGlkPVwibW90aW9uXCIgLz57XCJNb3Rpb25cIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlJlc3RyYWluZWQsIGFzIHRoZSBicmFuZCByZXF1aXJlcyAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLjE0c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCItc2NhbGUgdHJhbnNpdGlvbnMpLiBPcGVuLCBjbG9zZSwgYW5kIHRoZSBmb3VuZFxcbmhpZ2hsaWdodCBhcmUgdGhlIG9ubHkgYW5pbWF0aW9ucy4gRXZlcnl0aGluZyBoYXMgYSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInJlZHVjZWQtbW90aW9uXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHZhcmlhbnQ6IG5vIHNsaWRlLFxcbm5vIHNjcm9sbCBhbmltYXRpb24g4oCUIHRoZSBjYXJkIHNpbXBseSBhcHBlYXJzLCBhbmQgdGhlIGhpZ2hsaWdodCBpcyBhIHN0YXRpYyBvdXRsaW5lIHRoYXRcXG5mYWRlcy5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2FtcGxlLWNvbnRlbnQtdXNlLXRoZS1yZWFsLWdyb3ZlLWNvcnB1c1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2FtcGxlLWNvbnRlbnQtdXNlLXRoZS1yZWFsLWdyb3ZlLWNvcnB1c1wiIC8+e1wiU2FtcGxlIGNvbnRlbnQgKHVzZSB0aGUgcmVhbCBHcm92ZSBjb3JwdXMpXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJHcm92ZSdzIG93biBzYW1wbGUgd2lraSAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZ3JvdmUvY29udGVudC9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSBpcyBhIGZpY3Rpb25hbCBjb21wYW55LCBcIn08X2NvbXBvbmVudHMuZW0+e1wiTWVyaWRpYW5cIn08L19jb21wb25lbnRzLmVtPntcIi4gQnVpbGQgdGhlXFxubW9ja3VwIGZyb20gaXQgc28gdGhlIHJpdmVyIGxvb2tzIGxpa2UgYSByZWFsIHJlYWRpbmcgc2Vzc2lvbjpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJTdGFydCBvbiBcIn08X2NvbXBvbmVudHMuZW0+e1wiSG9tZVwifTwvX2NvbXBvbmVudHMuZW0+e1wiLiBPcGVuIFwifTxfY29tcG9uZW50cy5lbT57XCJFbmdpbmVlcmluZ1wifTwvX2NvbXBvbmVudHMuZW0+e1wiIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJ0ZWFtcy9lbmdpbmVlcmluZy5tZHhcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSBmcm9tIHRoZSBuYXZcXG4oaW50ZXJhY3Rpb24gMiwgdG9wIGluc2VydCkuIEluIHRoZSBFbmdpbmVlcmluZyBjYXJkLCBvcGVuIFwifTxfY29tcG9uZW50cy5lbT57XCJJbmNpZGVudCByZXNwb25zZVwifTwvX2NvbXBvbmVudHMuZW0+e1wiXFxuKFwifTxfY29tcG9uZW50cy5jb2RlPntcInByb2Nlc3Nlcy9pbmNpZGVudC1yZXNwb25zZS5tZHhcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSBmcm9tIGl0cyBwcm9zZSwgYW5kIFwifTxfY29tcG9uZW50cy5lbT57XCJBZGEgTG92ZWxhY2VcIn08L19jb21wb25lbnRzLmVtPntcIlxcbihcIn08X2NvbXBvbmVudHMuY29kZT57XCJwZW9wbGUvYWRhLWxvdmVsYWNlLm1keFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpIGZyb20gaXRzIHBlb3BsZSBkaXJlY3RvcnkgKGludGVyYWN0aW9uIDEsIGVhY2ggZGlyZWN0bHlcXG5iZWxvdyBFbmdpbmVlcmluZykuIEluIEFkYSdzIGNhcmQsIGNsaWNrIFxcXCJlbmdpbmVlcmluZ1xcXCIg4oCUIEVuZ2luZWVyaW5nIGlzIGFscmVhZHkgb3BlblxcbihpbnRlcmFjdGlvbiAzKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJFdmVyeSBzYW1wbGUgZW50cnkgaXMgc2hvcnQgKHRoZSBsb25nZXN0IGlzIH40NSBsaW5lcykuIEZvciB0aGUgbG9uZy1jYXJkIGZyYW1lcywgZXh0ZW5kXFxuXCJ9PF9jb21wb25lbnRzLmVtPntcIk9uYm9hcmRpbmdcIn08L19jb21wb25lbnRzLmVtPntcIiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaGFuZGJvb2svb25ib2FyZGluZy5tZHhcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSB3aXRoIHBsYXVzaWJsZSBleHRyYSBzZWN0aW9ucywgYW5kIGxhYmVsIHRoZVxcbmZyYW1lIGFzIHBhZGRlZCBzYW1wbGUgY29udGVudC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwiaGFyZC1jb25zdHJhaW50c1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwiaGFyZC1jb25zdHJhaW50c1wiIC8+e1wiSGFyZCBjb25zdHJhaW50c1wifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlRva2VucyBvbmx5LlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBFdmVyeSBjb2xvdXIsIHJhZGl1cywgc2hhZG93IGFuZCBmb250IGNvbWVzIGZyb20gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2luZGV4LmNzc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG4oXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1iZ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi0tcGFuZWxcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCItLXBhbmVsLTJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCItLWlua1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi0taW5rLTJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCItLWluay0zXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1saW5lXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1saW5lLTJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcIi0tYWNjZW50XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1hY2NlbnQtMlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi0tZ3JhZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi0tci0qXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1zaGFkb3ctY2FyZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi0tZGlzcFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi0tc2Fuc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1tb25vXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikuIE5ldyBjbGFzc2VzIGZvbGxvdyBHcm92ZSdzIG5hbWluZyAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLnJpdmVyLSpcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGJlc2lkZSB0aGUgZXhpc3RpbmdcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCIuZ3JvdmUtKlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLCBzbyBhIENTUy1vbmx5IHRoZW1lIGNhbiByZS1za2luIHRoZSByaXZlciBsaWtlIGV2ZXJ5dGhpbmcgZWxzZS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkRhcmsgZGVmYXVsdCwgbGlnaHQgdmlhIFwifTxfY29tcG9uZW50cy5jb2RlPntcImRhdGEtdGhlbWU9XFxcImxpZ2h0XFxcIlwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIGRlbGl2ZXIgYm90aCBmb3IgdGhlIHJpdmVyIHBhZ2UgYW5kXFxudGhlIGNhcmQgc3RhdGVzLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiU2VudGVuY2UgY2FzZSwgaGVhZGxpbmVzIGVuZCBvbiBhIHBlcmlvZCwgbm8gZW1vamkuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIEljb25zIGFyZSBMdWNpZGUgYXQgMTbigJMyNHB4IGluXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY3VycmVudENvbG9yXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjogXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wieFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcImxpbmtcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJwZW5jaWxcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjaGV2cm9uLSpcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFzIG5lZWRlZC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkRvbid0IGRyYXcgaG9zdCBjaHJvbWUuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRoZSBpbW1lZGlhdGVseS5ydW4gaG9zdCBmcmFtZSwgc2lnbi1pbiwgY29uc2VudCBwcm9tcHRzLCBpdHNcXG5zZWFtIG9yIGhlYWRlciBVSSwgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ0aGUgd29ya2JlbmNoIGVkaXRvclwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB0aGF0IEVkaXQgb3BlbnMsIGFuZCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInRoZSBmaXJzdC11c2UgcHJvbXB0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiXFxudGhhdCBhc2tzIGEgcmVhZGVyIHRvIGFsbG93IHRoZSByaXZlciB0byBvcGVuIGEgd2lraSBhcmUgYWxsIHRoZSBob3N0J3MuIFRoZSByaXZlciBpcyBpbnNpZGVcXG50aGUgYXBwJ3MgZnJhbWUuIEltaXRhdGluZyBob3N0IGNocm9tZSBpcyB0cmVhdGVkIGFzIHNwb29maW5nLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVGhlIGJvZHkgdm9jYWJ1bGFyeSBpcyBHcm92ZSdzIHNhZmUgc2V0LlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGUgcml2ZXIgcmVuZGVycyBlbnRyaWVzIHdpdGggR3JvdmUncyBzYWZlXFxucmVuZGVyZXIsIHNvIGEgY2FyZCBzaG93cyBHcm92ZSdzIGJ1aWx0LWluIGNvbXBvbmVudHMgKGJyaWVmIDAzKSBhbmQgbm90aGluZyBhIHdpa2kgc2hpcHNcXG5hcyBpdHMgb3duIGNvZGUuIERvbid0IGRlc2lnbiB3aWtpLXNwZWNpZmljIHdpZGdldHMgaW50byBjYXJkcy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIk9uZSB0aGVtZSBhY3Jvc3MgdGhlIHJpdmVyLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBDYXJkcyBkb24ndCBjYXJyeSB0aGVpciBvd24gdGhlbWVzOyB0aGUgcml2ZXIgdGFrZXMgdGhlXFxuaG9tZSBlbnRyeSdzLiBEb24ndCBkZXNpZ24gcGVyLWNhcmQgdGhlbWluZy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkFjY2Vzc2liaWxpdHk6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGVhY2ggY2FyZCBpcyBhbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJhcnRpY2xlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBsYWJlbGxlZCBieSBpdHMgdGl0bGUgaGVhZGluZztcXG5jbG9zZSBhbmQgY29weSBhcmUgcmVhbCBidXR0b25zIHdpdGggbGFiZWxzOyBmb2N1cyBtb3ZlcyB2aXNpYmx5IG9uIG9wZW4gYW5kIGNsb3NlOyB0aGVcXG5mb3VuZCBoaWdobGlnaHQgaXNuJ3QgY29sb3VyLW9ubHkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cIm91dC1vZi1zY29wZS1kb250LWRlc2lnbi10aGVzZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwib3V0LW9mLXNjb3BlLWRvbnQtZGVzaWduLXRoZXNlXCIgLz57XCJPdXQgb2Ygc2NvcGUgKGRvbid0IGRlc2lnbiB0aGVzZSlcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkRyYWctdG8tcmVvcmRlciBjYXJkcywgZWRpdGluZyBpbnNpZGUgYSBjYXJkIChFZGl0IGhhbmRzIG9mZiB0byB0aGUgd29ya2JlbmNoKSwgY2xvc2UtYWxsIC9cXG5jbG9zZS1vdGhlcnMsIGFcXG5wZXJtYWxpbmstdmVyc3VzLXBlcm1hdmlldyB0b2dnbGUsIGFuZCBhbnkgc2VydmVyIG9yIHN5bmMgaW5kaWNhdG9yLiBUaGUgcml2ZXIgZXhpc3RzIG9ubHlcXG5pbiB0aGUgVVJMLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJkZWxpdmVyYWJsZXNcIj48SGVhZGluZ0FuY2hvciBpZD1cImRlbGl2ZXJhYmxlc1wiIC8+e1wiRGVsaXZlcmFibGVzXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMub2w+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIlRoZSByaXZlciBwYWdlIGF0IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZGVza3RvcCBhbmQgbW9iaWxlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBkYXJrIGFuZCBsaWdodCwgd2l0aCB0aGUgc2FtcGxlIHNlc3Npb24gYWJvdmUuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiVGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiY2FyZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBpbiBhbGwgbmluZSBzdGF0ZXMsIHBsdXMgdGhlIEVkaXQgY29udHJvbCdzIGZvdXIgbG9va3MuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJTZXF1ZW5jZXNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHN0b3J5Ym9hcmRzIG9yIHByb3RvdHlwZSkgZm9yIHRoZSBzaXggaW50ZXJhY3Rpb25zLCBwbHVzIHJlZHVjZWQtbW90aW9uXFxudmFyaWFudHMgb2YgMSwgMyBhbmQgNC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJUaGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJyYWlsXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChkZXNrdG9wKSBmb2xsb3dpbmcgZm9jdXMsIGFuZCB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJzaWRlYmFyXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHdpdGggdGhlIG9wZW4tZW50cnkgbWFya2VyXFxuZXhwbG9yZWQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiQSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImxvbmcgcml2ZXJcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKDjigJMxMCBjYXJkcykuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiVGhlIHJpdmVyIHVuZGVyIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wib25lIGFsdGVybmF0ZSBHcm92ZSB0aGVtZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoYnJpZWYgMDUncyBzaG93Y2FzZSkg4oCUIHNhbWUgRE9NLCBDU1NcXG5vbmx5IOKAlCB0byBwcm92ZSB0aGUgbmV3IGNsYXNzZXMgYXJlIHRoZW1lYWJsZS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJBIHNob3J0IG5vdGUgb24gdGhlIG9wZW4gZGVzaWduIHF1ZXN0aW9ucyBiZWxvdywgd2l0aCB5b3VyIHJlY29tbWVuZGF0aW9uLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJvcGVuLWRlc2lnbi1xdWVzdGlvbnMtYW5zd2VyLXdpdGgtYS1yZWNvbW1lbmRhdGlvblwiPjxIZWFkaW5nQW5jaG9yIGlkPVwib3Blbi1kZXNpZ24tcXVlc3Rpb25zLWFuc3dlci13aXRoLWEtcmVjb21tZW5kYXRpb25cIiAvPntcIk9wZW4gZGVzaWduIHF1ZXN0aW9ucyAoYW5zd2VyIHdpdGggYSByZWNvbW1lbmRhdGlvbilcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJDYXJkIGZyYW1lOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBib3JkZXJlZCBwYW5lbCBvciBydWxlZCBwcm9zZSAoc2VlIFwifTxfY29tcG9uZW50cy5lbT57XCJUaGUgY2FyZFwifTwvX2NvbXBvbmVudHMuZW0+e1wiKT9cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkZvY3VzZWQtY2FyZCBpbmRpY2F0b3I6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGhvdyBxdWlldCBjYW4gaXQgYmUgYW5kIHN0aWxsIGJlIGZpbmRhYmxlIGluIGEgbG9uZyByaXZlcj9cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkNocm9tZS1saW5rIGluc2VydGlvbjpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdGhlIHNwZWMgZGVmYXVsdHMgc2lkZWJhci9uYXYvc2VhcmNoIG9wZW5zIHRvIHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInRvcFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBvZlxcbnRoZSByaXZlciAoVGlkZGx5V2lraSdzIHJ1bGUpLiBJZiwgZGVlcCBpbiBhIGxvbmcgcml2ZXIsIGEgdG9wIGluc2VydCBkaXNvcmllbnRzIG1vcmVcXG50aGFuIGl0IGhlbHBzLCBzYXkgc28gYW5kIHByb3Bvc2UgXFxcImJlbG93IHRoZSBmb2N1c2VkIGNhcmRcXFwiIGluc3RlYWQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJTdGlja3kgY2FyZCBoZWFkZXIgb24gbW9iaWxlOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBkb2VzIGl0IGVhcm4gaXRzIHNwYWNlP1wifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD48Lz47XG59XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNRFhDb250ZW50KHByb3BzID0ge30pIHtcbiAgY29uc3Qge3dyYXBwZXI6IE1EWExheW91dH0gPSB7XG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9O1xuICByZXR1cm4gTURYTGF5b3V0ID8gPE1EWExheW91dCB7Li4ucHJvcHN9PjxfY3JlYXRlTWR4Q29udGVudCB7Li4ucHJvcHN9IC8+PC9NRFhMYXlvdXQ+IDogX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpO1xufVxuZnVuY3Rpb24gX21pc3NpbmdNZHhSZWZlcmVuY2UoaWQsIGNvbXBvbmVudCwgcGxhY2UpIHtcbiAgdGhyb3cgbmV3IEVycm9yKFwiRXhwZWN0ZWQgXCIgKyAoY29tcG9uZW50ID8gXCJjb21wb25lbnRcIiA6IFwib2JqZWN0XCIpICsgXCIgYFwiICsgaWQgKyBcImAgdG8gYmUgZGVmaW5lZDogeW91IGxpa2VseSBmb3Jnb3QgdG8gaW1wb3J0LCBwYXNzLCBvciBwcm92aWRlIGl0LlwiICsgKHBsYWNlID8gXCJcXG5JdOKAmXMgcmVmZXJlbmNlZCBpbiB5b3VyIGNvZGUgYXQgYFwiICsgcGxhY2UgKyBcImAgaW4gYC9hcHAvZG9jcy9kZXNpZ24tYnJpZWZzL2dyb3ZlL2JyaWVmcy8wOC1zdG9yeS1yaXZlci5tZGBcIiA6IFwiXCIpKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQXdGLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUZ4RjtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU1DLFdBQVcsR0FBRztNQUNsQkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsSUFBSSxFQUFFLE1BQU07TUFDWkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsTUFBTSxFQUFFLFFBQVE7TUFDaEJDLEtBQUssRUFBRSxPQUFPO01BQ2RDLEtBQUssRUFBRSxPQUFPO01BQ2RDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEtBQUssRUFBRSxPQUFPO01BQ2RDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1IsR0FBRyxJQUFBQyw2QkFBa0IsRUFBQyxDQUFDO01BQ3ZCLEdBQUduQixLQUFLLENBQUNvQjtJQUNYLENBQUM7SUFBRTtNQUFDQztJQUFhLENBQUMsR0FBR3BCLFdBQVc7RUFDaEMsSUFBSSxDQUFDb0IsYUFBYSxFQUFFQyxvQkFBb0IsQ0FBQyxlQUFlLEVBQUUsSUFBSSxDQUFDO0VBQy9ELG9CQUFPLElBQUF4QixXQUFBLENBQUF5QixJQUFBLEVBQUF6QixXQUFBLENBQUEwQixRQUFBO0lBQUFDLFFBQUEsZ0JBQUUsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0ksRUFBRTtNQUFDcUIsRUFBRSxFQUFDLDBEQUEwRDtNQUFBRCxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQTBELENBQUUsQ0FBQyxFQUFDLDhEQUE4RDtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBZSxRQUFBLEdBQUUsa0ZBQWtGLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBa0QsQ0FBcUIsQ0FBQyxFQUFDLG9LQUFvSyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQThCLENBQXFCLENBQUMsRUFBQyxnR0FBZ0c7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNTLENBQUM7TUFBQWUsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFNLENBQXFCLENBQUMsRUFBQyxxREFBcUQsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFZLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsQ0FBQztRQUFDMEIsSUFBSSxFQUFDLGVBQWU7UUFBQUgsUUFBQSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNFLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFlLENBQW1CO01BQUMsQ0FBZSxDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLENBQUM7UUFBQzBCLElBQUksRUFBQyxvQkFBb0I7UUFBQUgsUUFBQSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNFLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFlLENBQW1CO01BQUMsQ0FBZSxDQUFDLEVBQUMsaUZBQWlGLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsQ0FBQztRQUFDMEIsSUFBSSxFQUFDLHNCQUFzQjtRQUFBSCxRQUFBLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQWlCLENBQW1CO01BQUMsQ0FBZSxDQUFDLEVBQUMsK0NBQStDLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsQ0FBQztRQUFDMEIsSUFBSSxFQUFDLHdDQUF3QztRQUFBSCxRQUFBLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQW1DLENBQW1CO01BQUMsQ0FBZSxDQUFDLEVBQUMsbUNBQW1DLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBd0IsQ0FBcUIsQ0FBQyxFQUFDLHVCQUF1QixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNFLElBQUk7UUFBQXNCLFFBQUEsRUFBRTtNQUEwQyxDQUFtQixDQUFDLEVBQUMseUdBQXlHO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDTSxFQUFFLElBQUUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBVCxXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNLLEVBQUU7TUFBQ29CLEVBQUUsRUFBQyx3QkFBd0I7TUFBQUQsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUF3QixDQUFFLENBQUMsRUFBQyx3QkFBd0I7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNTLENBQUM7TUFBQWUsUUFBQSxFQUFFO0lBQWdkLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDb0IsRUFBRSxFQUFDLHVDQUF1QztNQUFBRCxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQXVDLENBQUUsQ0FBQyxFQUFDLHlDQUF5QztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBZSxRQUFBLEdBQUUsa0NBQWtDLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBWSxDQUFxQixDQUFDLEVBQUMsMkVBQTJFLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBcUIsUUFBQSxFQUFFO01BQWEsQ0FBaUIsQ0FBQyxFQUFDLGdCQUFnQixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNHLEVBQUU7UUFBQXFCLFFBQUEsRUFBRTtNQUFjLENBQWlCLENBQUMsRUFBQyxzQkFBc0IsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRyxFQUFFO1FBQUFxQixRQUFBLEVBQUU7TUFBYyxDQUFpQixDQUFDLEVBQUMsNkNBQTZDLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBcUIsUUFBQSxFQUFFO01BQWEsQ0FBaUIsQ0FBQyxFQUFDLHFKQUFxSixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQUcsQ0FBcUIsQ0FBQyxFQUFDLG9SQUFvUjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDb0IsRUFBRSxFQUFDLGdFQUFnRTtNQUFBRCxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQWdFLENBQUUsQ0FBQyxFQUFDLG1FQUFtRTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1csS0FBSztNQUFBYSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNlLEtBQUs7UUFBQVMsUUFBQSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNnQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBRyxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDYyxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFhLENBQWlCLENBQUMsbUJBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNjLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQXNCLENBQWlCLENBQUM7UUFBQSxDQUFnQjtNQUFDLENBQW1CLENBQUMsbUJBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNZLEtBQUs7UUFBQVksUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDZ0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQUcsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEdBQUUsb0RBQW9ELGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBVSxDQUFxQixDQUFDO1VBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEdBQUUscUJBQXFCLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBZ0IsQ0FBcUIsQ0FBQyxFQUFDLHdHQUF3RztVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDZ0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQUcsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEdBQUUsdUJBQXVCLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBd0IsQ0FBcUIsQ0FBQyxFQUFDLCtCQUErQjtVQUFBLENBQWlCLENBQUMsbUJBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxHQUFFLHFCQUFxQixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQVksQ0FBcUIsQ0FBQyxFQUFDLGdDQUFnQztVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDZ0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQUcsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEdBQUUsb0NBQW9DLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBYyxDQUFxQixDQUFDO1VBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEdBQUUseUVBQXlFLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBZ0IsQ0FBcUIsQ0FBQyxFQUFDLHFEQUFxRDtVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDZ0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQUcsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBZSxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUF1RyxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2dCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFHLENBQWlCLENBQUMsbUJBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQWMsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBMkksQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNnQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBRyxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsR0FBRSxTQUFTLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBTSxDQUFxQixDQUFDLEVBQUMsWUFBWTtVQUFBLENBQWlCLENBQUMsbUJBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQXdULENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDO01BQUEsQ0FBbUIsQ0FBQztJQUFBLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBZSxRQUFBLEVBQUU7SUFBOE4sQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDSyxFQUFFO01BQUNvQixFQUFFLEVBQUMsVUFBVTtNQUFBRCxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVUsQ0FBRSxDQUFDLEVBQUMsVUFBVTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBZSxRQUFBLEVBQUU7SUFBd0YsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDaUIsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNPLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBUSxDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNFLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFxQixDQUFtQixDQUFDLEVBQUMsR0FBRyxFQUFFLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDaUIsRUFBRTtVQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNPLEVBQUU7WUFBQWlCLFFBQUEsRUFBRTtVQUFxSixDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNPLEVBQUU7WUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBTyxDQUFxQixDQUFDLEVBQUMsWUFBWSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNFLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFHLENBQW1CLENBQUMsRUFBQyxhQUFhLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQWMsQ0FBbUIsQ0FBQyxFQUFDLHFDQUFxQyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQVEsQ0FBcUIsQ0FBQyxFQUFDLDREQUE0RDtVQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ08sRUFBRTtZQUFBaUIsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUF5QixDQUFxQixDQUFDLEVBQUMsWUFBWSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNFLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFNLENBQW1CLENBQUMsRUFBQyw2R0FBNkc7VUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNPLEVBQUU7WUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBTSxDQUFxQixDQUFDLEVBQUMsWUFBWSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNFLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFRLENBQW1CLENBQUMsRUFBQywyREFBMkQsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUErRCxDQUFxQixDQUFDLEVBQUMseUpBQXlKLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBTyxDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQVEsQ0FBcUIsQ0FBQyxFQUFDLGtEQUFrRCxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQVUsQ0FBcUIsQ0FBQyxFQUFDLDBHQUEwRyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQVEsQ0FBcUIsQ0FBQyxFQUFDLDBIQUEwSDtVQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ08sRUFBRTtZQUFBaUIsUUFBQSxHQUFFLDhFQUE4RSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNFLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFTLENBQW1CLENBQUMsRUFBQyxpR0FBaUc7VUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtRQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDTyxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQU0sQ0FBcUIsQ0FBQyxFQUFDLG9EQUFvRCxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQW1CLENBQXFCLENBQUMsRUFBQyxzRUFBc0U7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNPLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBUSxDQUFxQixDQUFDLEVBQUMsa0RBQWtEO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNTLENBQUM7TUFBQWUsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFpRCxDQUFxQixDQUFDLEVBQUMsOERBQThELGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBc0IsUUFBQSxFQUFFO01BQVMsQ0FBbUIsQ0FBQyxFQUFDLGNBQWMsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRSxJQUFJO1FBQUFzQixRQUFBLEVBQUU7TUFBUSxDQUFtQixDQUFDLEVBQUMsMEhBQTBILGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBcUIsUUFBQSxFQUFFO01BQWdCLENBQWlCLENBQUMsRUFBQyxvR0FBb0c7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNLLEVBQUU7TUFBQ29CLEVBQUUsRUFBQyxvQ0FBb0M7TUFBQUQsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFvQyxDQUFFLENBQUMsRUFBQyxzQ0FBc0M7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNRLEVBQUU7TUFBQWdCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFTLENBQXFCLENBQUMsRUFBQyx1QkFBdUI7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNPLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBUyxDQUFxQixDQUFDLEVBQUMsOEpBQThKO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDTyxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWEsQ0FBcUIsQ0FBQyxFQUFDLHNDQUFzQztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFPLENBQXFCLENBQUMsRUFBQyxvRUFBb0UsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRyxFQUFFO1VBQUFxQixRQUFBLEVBQUU7UUFBUyxDQUFpQixDQUFDLEVBQUMsR0FBRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFTLENBQXFCLENBQUMsRUFBQywwTUFBME07TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNPLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBUyxDQUFxQixDQUFDLEVBQUMsNkNBQTZDO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDTyxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWdCLENBQXFCLENBQUMsRUFBQyxpTUFBaU07TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNPLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBVyxDQUFxQixDQUFDLEVBQUMsa0ZBQWtGO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDTyxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWdCLENBQXFCLENBQUMsRUFBQywrT0FBK087TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDb0IsRUFBRSxFQUFDLDJCQUEyQjtNQUFBRCxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQTJCLENBQUUsQ0FBQyxFQUFDLDJCQUEyQjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2lCLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDTyxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQVUsQ0FBcUIsQ0FBQyxFQUFDLDRGQUE0RixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXFCLENBQXFCLENBQUMsRUFBQyxvREFBb0QsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFNLENBQXFCLENBQUMsRUFBQyw4QkFBOEIsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFnQixDQUFxQixDQUFDLEVBQUMsZ0tBQWdLO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDTyxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXlCLENBQXFCLENBQUMsRUFBQyw4RkFBOEYsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUE2QixDQUFxQixDQUFDLEVBQUMsNkdBQTZHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDTyxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXlDLENBQXFCLENBQUMsRUFBQyxpWkFBaVo7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNPLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBZSxDQUFxQixDQUFDLEVBQUMsK0hBQStIO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNLLEVBQUU7TUFBQ29CLEVBQUUsRUFBQyxRQUFRO01BQUFELFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBUSxDQUFFLENBQUMsRUFBQyxRQUFRO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDUyxDQUFDO01BQUFlLFFBQUEsR0FBRSxxQ0FBcUMsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRSxJQUFJO1FBQUFzQixRQUFBLEVBQUU7TUFBTSxDQUFtQixDQUFDLEVBQUMsdUdBQXVHLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBZ0IsQ0FBcUIsQ0FBQyxFQUFDLHdIQUF3SDtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDb0IsRUFBRSxFQUFDLDBDQUEwQztNQUFBRCxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQTBDLENBQUUsQ0FBQyxFQUFDLDRDQUE0QztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBZSxRQUFBLEdBQUUsMkJBQTJCLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBc0IsUUFBQSxFQUFFO01BQWdCLENBQW1CLENBQUMsRUFBQyw0QkFBNEIsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRyxFQUFFO1FBQUFxQixRQUFBLEVBQUU7TUFBVSxDQUFpQixDQUFDLEVBQUMsNkVBQTZFO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDaUIsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNPLEVBQUU7UUFBQWlCLFFBQUEsR0FBRSxXQUFXLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBcUIsUUFBQSxFQUFFO1FBQU0sQ0FBaUIsQ0FBQyxFQUFDLFNBQVMsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRyxFQUFFO1VBQUFxQixRQUFBLEVBQUU7UUFBYSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNFLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUF1QixDQUFtQixDQUFDLEVBQUMsNkVBQTZFLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBcUIsUUFBQSxFQUFFO1FBQW1CLENBQWlCLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQWlDLENBQW1CLENBQUMsRUFBQyx3QkFBd0IsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRyxFQUFFO1VBQUFxQixRQUFBLEVBQUU7UUFBYyxDQUFpQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNFLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUF5QixDQUFtQixDQUFDLEVBQUMscUtBQXFLO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDTyxFQUFFO1FBQUFpQixRQUFBLEdBQUUsNEZBQTRGLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBcUIsUUFBQSxFQUFFO1FBQVksQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRSxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBeUIsQ0FBbUIsQ0FBQyxFQUFDLGlGQUFpRjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDSyxFQUFFO01BQUNvQixFQUFFLEVBQUMsa0JBQWtCO01BQUFELFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBa0IsQ0FBRSxDQUFDLEVBQUMsa0JBQWtCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDaUIsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNPLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBYyxDQUFxQixDQUFDLEVBQUMsb0RBQW9ELGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQWUsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRSxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBTSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNFLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFTLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRSxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBTyxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNFLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFTLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQVMsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRSxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNFLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQVUsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRSxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBWSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNFLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFRLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQU8sQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRSxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBZSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNFLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFRLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQVEsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRSxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsd0NBQXdDLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQVUsQ0FBbUIsQ0FBQyxFQUFDLHdCQUF3QixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNFLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQyxvRUFBb0U7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNPLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBYyxRQUFBLEdBQUUsMEJBQTBCLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBc0IsUUFBQSxFQUFFO1VBQXNCLENBQW1CLENBQUM7UUFBQSxDQUFvQixDQUFDLEVBQUMsMERBQTBEO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDTyxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXFELENBQXFCLENBQUMsRUFBQyxtQ0FBbUMsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRSxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBYyxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNFLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFHLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQU0sQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRSxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNFLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyxhQUFhO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDTyxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXlCLENBQXFCLENBQUMsRUFBQyxxRkFBcUYsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFzQixDQUFxQixDQUFDLEVBQUMsd0JBQXdCLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBc0IsQ0FBcUIsQ0FBQyxFQUFDLGdLQUFnSztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUEwQyxDQUFxQixDQUFDLEVBQUMsME1BQTBNO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDTyxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTZCLENBQXFCLENBQUMsRUFBQyx3R0FBd0c7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNPLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBZ0IsQ0FBcUIsQ0FBQyxFQUFDLG1CQUFtQixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNFLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFTLENBQW1CLENBQUMsRUFBQyw4SkFBOEo7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDb0IsRUFBRSxFQUFDLGdDQUFnQztNQUFBRCxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQWdDLENBQUUsQ0FBQyxFQUFDLG1DQUFtQztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBZSxRQUFBLEVBQUU7SUFBdU4sQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDSyxFQUFFO01BQUNvQixFQUFFLEVBQUMsY0FBYztNQUFBRCxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQWMsQ0FBRSxDQUFDLEVBQUMsY0FBYztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1EsRUFBRTtNQUFBZ0IsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDTyxFQUFFO1FBQUFpQixRQUFBLEdBQUUsb0JBQW9CLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBb0IsQ0FBcUIsQ0FBQyxFQUFDLGtEQUFrRDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBaUIsUUFBQSxHQUFFLE1BQU0sZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFNLENBQXFCLENBQUMsRUFBQywwREFBMEQ7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNPLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBVyxDQUFxQixDQUFDLEVBQUMsb0dBQW9HO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDTyxFQUFFO1FBQUFpQixRQUFBLEdBQUUsTUFBTSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQU0sQ0FBcUIsQ0FBQyxFQUFDLHNDQUFzQyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQVMsQ0FBcUIsQ0FBQyxFQUFDLHdDQUF3QztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBaUIsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFZLENBQXFCLENBQUMsRUFBQyxnQkFBZ0I7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNPLEVBQUU7UUFBQWlCLFFBQUEsR0FBRSxrQkFBa0IsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUEyQixDQUFxQixDQUFDLEVBQUMsd0ZBQXdGO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDTyxFQUFFO1FBQUFpQixRQUFBLEVBQUU7TUFBNEUsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNLLEVBQUU7TUFBQ29CLEVBQUUsRUFBQyxvREFBb0Q7TUFBQUQsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFvRCxDQUFFLENBQUMsRUFBQyxzREFBc0Q7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNpQixFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFhLENBQXFCLENBQUMsRUFBQyxzQ0FBc0MsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRyxFQUFFO1VBQUFxQixRQUFBLEVBQUU7UUFBVSxDQUFpQixDQUFDLEVBQUMsSUFBSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUF5QixDQUFxQixDQUFDLEVBQUMsNkRBQTZEO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDTyxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXdCLENBQXFCLENBQUMsRUFBQyxxREFBcUQsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFLLENBQXFCLENBQUMsRUFBQyxtS0FBbUs7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNPLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBK0IsQ0FBcUIsQ0FBQyxFQUFDLDBCQUEwQjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQztFQUFBLENBQUUsQ0FBQztBQUMxaXRCO0FBQ2UsU0FBU0ksVUFBVUEsQ0FBQzdCLEtBQUssR0FBRyxDQUFDLENBQUMsRUFBRTtFQUM3QyxNQUFNO0lBQUM4QixPQUFPLEVBQUVDO0VBQVMsQ0FBQyxHQUFHO0lBQzNCLEdBQUcsSUFBQVosNkJBQWtCLEVBQUMsQ0FBQztJQUN2QixHQUFHbkIsS0FBSyxDQUFDb0I7RUFDWCxDQUFDO0VBQ0QsT0FBT1csU0FBUyxnQkFBRyxJQUFBakMsV0FBQSxDQUFBNkIsR0FBQSxFQUFDSSxTQUFTO0lBQUEsR0FBSy9CLEtBQUs7SUFBQXlCLFFBQUEsZUFBRSxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDNUIsaUJBQWlCO01BQUEsR0FBS0M7SUFBSyxDQUFHO0VBQUMsQ0FBVyxDQUFDLEdBQUdELGlCQUFpQixDQUFDQyxLQUFLLENBQUM7QUFDbEg7QUFBQ2dDLEVBQUEsR0FOdUJILFVBQVU7QUFPbEMsU0FBU1Asb0JBQW9CQSxDQUFDSSxFQUFFLEVBQUVPLFNBQVMsRUFBRUMsS0FBSyxFQUFFO0VBQ2xELE1BQU0sSUFBSUMsS0FBSyxDQUFDLFdBQVcsSUFBSUYsU0FBUyxHQUFHLFdBQVcsR0FBRyxRQUFRLENBQUMsR0FBRyxJQUFJLEdBQUdQLEVBQUUsR0FBRyxvRUFBb0UsSUFBSVEsS0FBSyxHQUFHLHFDQUFxQyxHQUFHQSxLQUFLLEdBQUcsK0RBQStELEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDelI7QUFBQyxJQUFBRixFQUFBO0FBQUFJLFlBQUEsQ0FBQUosRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}