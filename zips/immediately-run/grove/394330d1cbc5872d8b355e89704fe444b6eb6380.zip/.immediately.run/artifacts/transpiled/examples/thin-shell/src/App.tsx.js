var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = App;
var _grove = require("@immediately-run/grove");
require("@immediately-run/grove/styles.css");
require("./shell.css");
var _jsxRuntime = require("react/jsx-runtime");
// The M3 proof shell (PLATFORM_LAYERING_SPEC §1.1, R3-280).
//
// This is an ORDINARY immediately.run app — the default export the platform renders. It
// does not fork the engine and it is not dispatched to; it imports the engine as a pinned
// git dependency (`package.json` → `github:immediately-run/grove#<ref>`), which the
// LIBRARY_MOUNTS rail mounts at `/node_modules/@immediately-run/grove` before the first
// compile, and arranges it.
//
// Two things this shell exists to demonstrate, both of them R3-280 exit criteria:
//
//   1. **Composition without forking.** The whole wiki arrives as one component and the
//      shell keeps ownership of what wraps it.
//   2. **Overriding through the manifest, and only through it.** See `./components` — the
//      commented lines there are what a mistake looks like: a throw at module load naming
//      the offending component and the surface that WAS available, never a silent fall
//      back to stock.
//
// Note what the package.json declares: `content: ["content"]` with `render: "app"`. A repo
// holding corpora stays an app by default, but saying so explicitly is what makes the
// intent readable to the next person.

function App() {
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_grove.GroveApp, {});
}
_c = App;
var _c;
$RefreshReg$(_c, "App");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfZ3JvdmUiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJBcHAiLCJqc3giLCJHcm92ZUFwcCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQXBwLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBUaGUgTTMgcHJvb2Ygc2hlbGwgKFBMQVRGT1JNX0xBWUVSSU5HX1NQRUMgwqcxLjEsIFIzLTI4MCkuXG4vL1xuLy8gVGhpcyBpcyBhbiBPUkRJTkFSWSBpbW1lZGlhdGVseS5ydW4gYXBwIOKAlCB0aGUgZGVmYXVsdCBleHBvcnQgdGhlIHBsYXRmb3JtIHJlbmRlcnMuIEl0XG4vLyBkb2VzIG5vdCBmb3JrIHRoZSBlbmdpbmUgYW5kIGl0IGlzIG5vdCBkaXNwYXRjaGVkIHRvOyBpdCBpbXBvcnRzIHRoZSBlbmdpbmUgYXMgYSBwaW5uZWRcbi8vIGdpdCBkZXBlbmRlbmN5IChgcGFja2FnZS5qc29uYCDihpIgYGdpdGh1YjppbW1lZGlhdGVseS1ydW4vZ3JvdmUjPHJlZj5gKSwgd2hpY2ggdGhlXG4vLyBMSUJSQVJZX01PVU5UUyByYWlsIG1vdW50cyBhdCBgL25vZGVfbW9kdWxlcy9AaW1tZWRpYXRlbHktcnVuL2dyb3ZlYCBiZWZvcmUgdGhlIGZpcnN0XG4vLyBjb21waWxlLCBhbmQgYXJyYW5nZXMgaXQuXG4vL1xuLy8gVHdvIHRoaW5ncyB0aGlzIHNoZWxsIGV4aXN0cyB0byBkZW1vbnN0cmF0ZSwgYm90aCBvZiB0aGVtIFIzLTI4MCBleGl0IGNyaXRlcmlhOlxuLy9cbi8vICAgMS4gKipDb21wb3NpdGlvbiB3aXRob3V0IGZvcmtpbmcuKiogVGhlIHdob2xlIHdpa2kgYXJyaXZlcyBhcyBvbmUgY29tcG9uZW50IGFuZCB0aGVcbi8vICAgICAgc2hlbGwga2VlcHMgb3duZXJzaGlwIG9mIHdoYXQgd3JhcHMgaXQuXG4vLyAgIDIuICoqT3ZlcnJpZGluZyB0aHJvdWdoIHRoZSBtYW5pZmVzdCwgYW5kIG9ubHkgdGhyb3VnaCBpdC4qKiBTZWUgYC4vY29tcG9uZW50c2Ag4oCUIHRoZVxuLy8gICAgICBjb21tZW50ZWQgbGluZXMgdGhlcmUgYXJlIHdoYXQgYSBtaXN0YWtlIGxvb2tzIGxpa2U6IGEgdGhyb3cgYXQgbW9kdWxlIGxvYWQgbmFtaW5nXG4vLyAgICAgIHRoZSBvZmZlbmRpbmcgY29tcG9uZW50IGFuZCB0aGUgc3VyZmFjZSB0aGF0IFdBUyBhdmFpbGFibGUsIG5ldmVyIGEgc2lsZW50IGZhbGxcbi8vICAgICAgYmFjayB0byBzdG9jay5cbi8vXG4vLyBOb3RlIHdoYXQgdGhlIHBhY2thZ2UuanNvbiBkZWNsYXJlczogYGNvbnRlbnQ6IFtcImNvbnRlbnRcIl1gIHdpdGggYHJlbmRlcjogXCJhcHBcImAuIEEgcmVwb1xuLy8gaG9sZGluZyBjb3Jwb3JhIHN0YXlzIGFuIGFwcCBieSBkZWZhdWx0LCBidXQgc2F5aW5nIHNvIGV4cGxpY2l0bHkgaXMgd2hhdCBtYWtlcyB0aGVcbi8vIGludGVudCByZWFkYWJsZSB0byB0aGUgbmV4dCBwZXJzb24uXG5cbmltcG9ydCB7IEdyb3ZlQXBwIH0gZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9ncm92ZSc7XG5pbXBvcnQgJ0BpbW1lZGlhdGVseS1ydW4vZ3JvdmUvc3R5bGVzLmNzcyc7XG5pbXBvcnQgJy4vc2hlbGwuY3NzJztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQXBwKCkge1xuICByZXR1cm4gPEdyb3ZlQXBwIC8+O1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFxQkEsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBQ0FBLE9BQUE7QUFDQUEsT0FBQTtBQUFxQixJQUFBQyxXQUFBLEdBQUFELE9BQUE7QUF2QnJCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBTWUsU0FBU0UsR0FBR0EsQ0FBQSxFQUFHO0VBQzVCLG9CQUFPLElBQUFELFdBQUEsQ0FBQUUsR0FBQSxFQUFDSixNQUFBLENBQUFLLFFBQVEsSUFBRSxDQUFDO0FBQ3JCO0FBQUNDLEVBQUEsR0FGdUJILEdBQUc7QUFBQSxJQUFBRyxFQUFBO0FBQUFDLFlBQUEsQ0FBQUQsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}