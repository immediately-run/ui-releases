var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = ShellCallout;
var _jsxRuntime = require("react/jsx-runtime");
// A shell's replacement for a manifest component. Same props contract the manifest
// declares for `Callout` (`kind?`, `title?`, `children?`) — the manifest is where a shell
// author reads that from, which is the point of putting props in it.

function ShellCallout({
  kind = 'note',
  title,
  children
}) {
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("aside", {
    className: "shell-callout",
    "data-kind": kind,
    children: [title ? /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
      className: "shell-callout__title",
      children: title
    }) : null, children]
  });
}
_c = ShellCallout;
var _c;
$RefreshReg$(_c, "ShellCallout");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJTaGVsbENhbGxvdXQiLCJraW5kIiwidGl0bGUiLCJjaGlsZHJlbiIsIl9qc3hSdW50aW1lIiwianN4cyIsImNsYXNzTmFtZSIsImpzeCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiU2hlbGxDYWxsb3V0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBBIHNoZWxsJ3MgcmVwbGFjZW1lbnQgZm9yIGEgbWFuaWZlc3QgY29tcG9uZW50LiBTYW1lIHByb3BzIGNvbnRyYWN0IHRoZSBtYW5pZmVzdFxuLy8gZGVjbGFyZXMgZm9yIGBDYWxsb3V0YCAoYGtpbmQ/YCwgYHRpdGxlP2AsIGBjaGlsZHJlbj9gKSDigJQgdGhlIG1hbmlmZXN0IGlzIHdoZXJlIGEgc2hlbGxcbi8vIGF1dGhvciByZWFkcyB0aGF0IGZyb20sIHdoaWNoIGlzIHRoZSBwb2ludCBvZiBwdXR0aW5nIHByb3BzIGluIGl0LlxuXG5pbXBvcnQgdHlwZSB7IFJlYWN0Tm9kZSB9IGZyb20gJ3JlYWN0JztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gU2hlbGxDYWxsb3V0KHtcbiAga2luZCA9ICdub3RlJyxcbiAgdGl0bGUsXG4gIGNoaWxkcmVuLFxufToge1xuICBraW5kPzogc3RyaW5nO1xuICB0aXRsZT86IHN0cmluZztcbiAgY2hpbGRyZW4/OiBSZWFjdE5vZGU7XG59KSB7XG4gIHJldHVybiAoXG4gICAgPGFzaWRlIGNsYXNzTmFtZT1cInNoZWxsLWNhbGxvdXRcIiBkYXRhLWtpbmQ9e2tpbmR9PlxuICAgICAge3RpdGxlID8gPHAgY2xhc3NOYW1lPVwic2hlbGwtY2FsbG91dF9fdGl0bGVcIj57dGl0bGV9PC9wPiA6IG51bGx9XG4gICAgICB7Y2hpbGRyZW59XG4gICAgPC9hc2lkZT5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUFBO0FBQ0E7QUFDQTs7QUFJZSxTQUFTQSxZQUFZQSxDQUFDO0VBQ25DQyxJQUFJLEdBQUcsTUFBTTtFQUNiQyxLQUFLO0VBQ0xDO0FBS0YsQ0FBQyxFQUFFO0VBQ0Qsb0JBQ0UsSUFBQUMsV0FBQSxDQUFBQyxJQUFBO0lBQU9DLFNBQVMsRUFBQyxlQUFlO0lBQUMsYUFBV0wsSUFBSztJQUFBRSxRQUFBLEdBQzlDRCxLQUFLLGdCQUFHLElBQUFFLFdBQUEsQ0FBQUcsR0FBQTtNQUFHRCxTQUFTLEVBQUMsc0JBQXNCO01BQUFILFFBQUEsRUFBRUQ7SUFBSyxDQUFJLENBQUMsR0FBRyxJQUFJLEVBQzlEQyxRQUFRO0VBQUEsQ0FDSixDQUFDO0FBRVo7QUFBQ0ssRUFBQSxHQWZ1QlIsWUFBWTtBQUFBLElBQUFRLEVBQUE7QUFBQUMsWUFBQSxDQUFBRCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}