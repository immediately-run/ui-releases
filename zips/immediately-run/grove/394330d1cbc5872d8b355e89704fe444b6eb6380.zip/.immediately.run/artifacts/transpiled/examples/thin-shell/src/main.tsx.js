var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

var _boot = require("@immediately-run/sdk/boot");
var _App = _interopRequireDefault(require("./App"));
var _components = require("./components");
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// The entry immediately.run runs (`package.json` → `main`), and the reason this shell can
// prove anything about composition.
//
// Without it the platform falls back to the SDK's default route table, which renders
// `src/App.tsx`'s default export through the file router. The shell then renders — but
// `boot()` is never called with the shell's OWN component map, so `./components` is dead
// code and the `Callout` override in it silently does nothing. That is exactly the failure
// R3-280's Drill 3 exists to catch, and it was hiding in the fixture itself.
//
// `mdxComponents: COMPONENTS` is the whole point of the M3 mode: the engine arrives as a
// dependency and the SHELL decides what its vocabulary renders as. `children` rather than a
// `routingSpec` because the SDK installs a catch-all for children, and Grove's own gate
// (`GroveApp`) owns dispatch from there — the same arrangement grove's `src/main.tsx` uses
// for the fork mode, which is what makes the two modes comparable.

(0, _boot.boot)({
  mdxComponents: _components.COMPONENTS,
  children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_App.default, {})
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfYm9vdCIsInJlcXVpcmUiLCJfQXBwIiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsIl9jb21wb25lbnRzIiwiX2pzeFJ1bnRpbWUiLCJlIiwiX19lc01vZHVsZSIsImRlZmF1bHQiLCJib290IiwibWR4Q29tcG9uZW50cyIsIkNPTVBPTkVOVFMiLCJjaGlsZHJlbiIsImpzeCJdLCJzb3VyY2VzIjpbIm1haW4udHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIFRoZSBlbnRyeSBpbW1lZGlhdGVseS5ydW4gcnVucyAoYHBhY2thZ2UuanNvbmAg4oaSIGBtYWluYCksIGFuZCB0aGUgcmVhc29uIHRoaXMgc2hlbGwgY2FuXG4vLyBwcm92ZSBhbnl0aGluZyBhYm91dCBjb21wb3NpdGlvbi5cbi8vXG4vLyBXaXRob3V0IGl0IHRoZSBwbGF0Zm9ybSBmYWxscyBiYWNrIHRvIHRoZSBTREsncyBkZWZhdWx0IHJvdXRlIHRhYmxlLCB3aGljaCByZW5kZXJzXG4vLyBgc3JjL0FwcC50c3hgJ3MgZGVmYXVsdCBleHBvcnQgdGhyb3VnaCB0aGUgZmlsZSByb3V0ZXIuIFRoZSBzaGVsbCB0aGVuIHJlbmRlcnMg4oCUIGJ1dFxuLy8gYGJvb3QoKWAgaXMgbmV2ZXIgY2FsbGVkIHdpdGggdGhlIHNoZWxsJ3MgT1dOIGNvbXBvbmVudCBtYXAsIHNvIGAuL2NvbXBvbmVudHNgIGlzIGRlYWRcbi8vIGNvZGUgYW5kIHRoZSBgQ2FsbG91dGAgb3ZlcnJpZGUgaW4gaXQgc2lsZW50bHkgZG9lcyBub3RoaW5nLiBUaGF0IGlzIGV4YWN0bHkgdGhlIGZhaWx1cmVcbi8vIFIzLTI4MCdzIERyaWxsIDMgZXhpc3RzIHRvIGNhdGNoLCBhbmQgaXQgd2FzIGhpZGluZyBpbiB0aGUgZml4dHVyZSBpdHNlbGYuXG4vL1xuLy8gYG1keENvbXBvbmVudHM6IENPTVBPTkVOVFNgIGlzIHRoZSB3aG9sZSBwb2ludCBvZiB0aGUgTTMgbW9kZTogdGhlIGVuZ2luZSBhcnJpdmVzIGFzIGFcbi8vIGRlcGVuZGVuY3kgYW5kIHRoZSBTSEVMTCBkZWNpZGVzIHdoYXQgaXRzIHZvY2FidWxhcnkgcmVuZGVycyBhcy4gYGNoaWxkcmVuYCByYXRoZXIgdGhhbiBhXG4vLyBgcm91dGluZ1NwZWNgIGJlY2F1c2UgdGhlIFNESyBpbnN0YWxscyBhIGNhdGNoLWFsbCBmb3IgY2hpbGRyZW4sIGFuZCBHcm92ZSdzIG93biBnYXRlXG4vLyAoYEdyb3ZlQXBwYCkgb3ducyBkaXNwYXRjaCBmcm9tIHRoZXJlIOKAlCB0aGUgc2FtZSBhcnJhbmdlbWVudCBncm92ZSdzIGBzcmMvbWFpbi50c3hgIHVzZXNcbi8vIGZvciB0aGUgZm9yayBtb2RlLCB3aGljaCBpcyB3aGF0IG1ha2VzIHRoZSB0d28gbW9kZXMgY29tcGFyYWJsZS5cbmltcG9ydCB7IGJvb3QgfSBmcm9tICdAaW1tZWRpYXRlbHktcnVuL3Nkay9ib290JztcbmltcG9ydCBBcHAgZnJvbSAnLi9BcHAnO1xuaW1wb3J0IHsgQ09NUE9ORU5UUyB9IGZyb20gJy4vY29tcG9uZW50cyc7XG5cbmJvb3QoeyBtZHhDb21wb25lbnRzOiBDT01QT05FTlRTLCBjaGlsZHJlbjogPEFwcCAvPiB9KTtcbiJdLCJtYXBwaW5ncyI6Ijs7QUFjQSxJQUFBQSxLQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxJQUFBLEdBQUFDLHNCQUFBLENBQUFGLE9BQUE7QUFDQSxJQUFBRyxXQUFBLEdBQUFILE9BQUE7QUFBMEMsSUFBQUksV0FBQSxHQUFBSixPQUFBO0FBQUEsU0FBQUUsdUJBQUFHLENBQUEsV0FBQUEsQ0FBQSxJQUFBQSxDQUFBLENBQUFDLFVBQUEsR0FBQUQsQ0FBQSxLQUFBRSxPQUFBLEVBQUFGLENBQUE7QUFoQjFDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBS0EsSUFBQUcsVUFBSSxFQUFDO0VBQUVDLGFBQWEsRUFBRUMsc0JBQVU7RUFBRUMsUUFBUSxlQUFFLElBQUFQLFdBQUEsQ0FBQVEsR0FBQSxFQUFDWCxJQUFBLENBQUFNLE9BQUcsSUFBRTtBQUFFLENBQUMsQ0FBQyIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}