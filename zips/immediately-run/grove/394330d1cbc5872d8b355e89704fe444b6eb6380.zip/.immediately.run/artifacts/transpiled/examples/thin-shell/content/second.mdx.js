var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      code: "code",
      h2: "h2",
      p: "p",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      Callout,
      HeadingAnchor
    } = _components;
  if (!Callout) _missingMdxReference("Callout", true, "10:1-15:11");
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "A second entry, so the nav has something to navigate and backlinks have something to\nresolve."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "headings-get-anchors",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "headings-get-anchors"
      }), "Headings get anchors"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The heading above is anchored by the same ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "remarkHeadingAnchors"
      }), " pass the fork uses — the\nengine is the same code either way."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(Callout, {
      kind: "note",
      title: "This box is the override.",
      children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Callout"
        }), " is a manifest component, so a shell may replace it. This one is rendered by\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/ShellCallout.tsx"
        }), ", not by the engine's stock component — the visible difference is\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "data-kind"
        }), " on an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "aside.shell-callout"
        }), ". Swap ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "components.ts"
        }), " back to stock and this box\nchanges shape."]
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Back to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "/content/home.mdx",
        children: "home"
      }), "."]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/examples/thin-shell/content/second.mdx`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiY29kZSIsImgyIiwicCIsIl9wcm92aWRlQ29tcG9uZW50cyIsImNvbXBvbmVudHMiLCJDYWxsb3V0IiwiSGVhZGluZ0FuY2hvciIsIl9taXNzaW5nTWR4UmVmZXJlbmNlIiwianN4cyIsIkZyYWdtZW50IiwiY2hpbGRyZW4iLCJqc3giLCJpZCIsImtpbmQiLCJ0aXRsZSIsImhyZWYiLCJNRFhDb250ZW50Iiwid3JhcHBlciIsIk1EWExheW91dCIsIl9jIiwiY29tcG9uZW50IiwicGxhY2UiLCJFcnJvciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbInNlY29uZC5tZHgiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgYTogXCJhXCIsXG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgaDI6IFwiaDJcIixcbiAgICBwOiBcInBcIixcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH0sIHtDYWxsb3V0LCBIZWFkaW5nQW5jaG9yfSA9IF9jb21wb25lbnRzO1xuICBpZiAoIUNhbGxvdXQpIF9taXNzaW5nTWR4UmVmZXJlbmNlKFwiQ2FsbG91dFwiLCB0cnVlLCBcIjEwOjEtMTU6MTFcIik7XG4gIGlmICghSGVhZGluZ0FuY2hvcikgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJIZWFkaW5nQW5jaG9yXCIsIHRydWUpO1xuICByZXR1cm4gPD48X2NvbXBvbmVudHMucD57XCJBIHNlY29uZCBlbnRyeSwgc28gdGhlIG5hdiBoYXMgc29tZXRoaW5nIHRvIG5hdmlnYXRlIGFuZCBiYWNrbGlua3MgaGF2ZSBzb21ldGhpbmcgdG9cXG5yZXNvbHZlLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJoZWFkaW5ncy1nZXQtYW5jaG9yc1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwiaGVhZGluZ3MtZ2V0LWFuY2hvcnNcIiAvPntcIkhlYWRpbmdzIGdldCBhbmNob3JzXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgaGVhZGluZyBhYm92ZSBpcyBhbmNob3JlZCBieSB0aGUgc2FtZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyZW1hcmtIZWFkaW5nQW5jaG9yc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcGFzcyB0aGUgZm9yayB1c2VzIOKAlCB0aGVcXG5lbmdpbmUgaXMgdGhlIHNhbWUgY29kZSBlaXRoZXIgd2F5LlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08Q2FsbG91dCBraW5kPVwibm90ZVwiIHRpdGxlPVwiVGhpcyBib3ggaXMgdGhlIG92ZXJyaWRlLlwiPjxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5jb2RlPntcIkNhbGxvdXRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGlzIGEgbWFuaWZlc3QgY29tcG9uZW50LCBzbyBhIHNoZWxsIG1heSByZXBsYWNlIGl0LiBUaGlzIG9uZSBpcyByZW5kZXJlZCBieVxcblwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9TaGVsbENhbGxvdXQudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgbm90IGJ5IHRoZSBlbmdpbmUncyBzdG9jayBjb21wb25lbnQg4oCUIHRoZSB2aXNpYmxlIGRpZmZlcmVuY2UgaXNcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJkYXRhLWtpbmRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG9uIGFuIFwifTxfY29tcG9uZW50cy5jb2RlPntcImFzaWRlLnNoZWxsLWNhbGxvdXRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLiBTd2FwIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNvbXBvbmVudHMudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGJhY2sgdG8gc3RvY2sgYW5kIHRoaXMgYm94XFxuY2hhbmdlcyBzaGFwZS5cIn08L19jb21wb25lbnRzLnA+PC9DYWxsb3V0PntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkJhY2sgdG8gXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cIi9jb250ZW50L2hvbWUubWR4XCI+e1wiaG9tZVwifTwvX2NvbXBvbmVudHMuYT57XCIuXCJ9PC9fY29tcG9uZW50cy5wPjwvPjtcbn1cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE1EWENvbnRlbnQocHJvcHMgPSB7fSkge1xuICBjb25zdCB7d3JhcHBlcjogTURYTGF5b3V0fSA9IHtcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH07XG4gIHJldHVybiBNRFhMYXlvdXQgPyA8TURYTGF5b3V0IHsuLi5wcm9wc30+PF9jcmVhdGVNZHhDb250ZW50IHsuLi5wcm9wc30gLz48L01EWExheW91dD4gOiBfY3JlYXRlTWR4Q29udGVudChwcm9wcyk7XG59XG5mdW5jdGlvbiBfbWlzc2luZ01keFJlZmVyZW5jZShpZCwgY29tcG9uZW50LCBwbGFjZSkge1xuICB0aHJvdyBuZXcgRXJyb3IoXCJFeHBlY3RlZCBcIiArIChjb21wb25lbnQgPyBcImNvbXBvbmVudFwiIDogXCJvYmplY3RcIikgKyBcIiBgXCIgKyBpZCArIFwiYCB0byBiZSBkZWZpbmVkOiB5b3UgbGlrZWx5IGZvcmdvdCB0byBpbXBvcnQsIHBhc3MsIG9yIHByb3ZpZGUgaXQuXCIgKyAocGxhY2UgPyBcIlxcbkl04oCZcyByZWZlcmVuY2VkIGluIHlvdXIgY29kZSBhdCBgXCIgKyBwbGFjZSArIFwiYCBpbiBgL2FwcC9leGFtcGxlcy90aGluLXNoZWxsL2NvbnRlbnQvc2Vjb25kLm1keGBcIiA6IFwiXCIpKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQXdGLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUZ4RjtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU1DLFdBQVcsR0FBRztNQUNsQkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsSUFBSSxFQUFFLE1BQU07TUFDWkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsQ0FBQyxFQUFFLEdBQUc7TUFDTixHQUFHLElBQUFDLDZCQUFrQixFQUFDLENBQUM7TUFDdkIsR0FBR04sS0FBSyxDQUFDTztJQUNYLENBQUM7SUFBRTtNQUFDQyxPQUFPO01BQUVDO0lBQWEsQ0FBQyxHQUFHUixXQUFXO0VBQ3pDLElBQUksQ0FBQ08sT0FBTyxFQUFFRSxvQkFBb0IsQ0FBQyxTQUFTLEVBQUUsSUFBSSxFQUFFLFlBQVksQ0FBQztFQUNqRSxJQUFJLENBQUNELGFBQWEsRUFBRUMsb0JBQW9CLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQztFQUMvRCxvQkFBTyxJQUFBWixXQUFBLENBQUFhLElBQUEsRUFBQWIsV0FBQSxDQUFBYyxRQUFBO0lBQUFDLFFBQUEsZ0JBQUUsSUFBQWYsV0FBQSxDQUFBZ0IsR0FBQSxFQUFDYixXQUFXLENBQUNJLENBQUM7TUFBQVEsUUFBQSxFQUFFO0lBQWdHLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWYsV0FBQSxDQUFBYSxJQUFBLEVBQUNWLFdBQVcsQ0FBQ0csRUFBRTtNQUFDVyxFQUFFLEVBQUMsc0JBQXNCO01BQUFGLFFBQUEsZ0JBQUMsSUFBQWYsV0FBQSxDQUFBZ0IsR0FBQSxFQUFDTCxhQUFhO1FBQUNNLEVBQUUsRUFBQztNQUFzQixDQUFFLENBQUMsRUFBQyxzQkFBc0I7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFqQixXQUFBLENBQUFhLElBQUEsRUFBQ1YsV0FBVyxDQUFDSSxDQUFDO01BQUFRLFFBQUEsR0FBRSw0Q0FBNEMsZUFBQyxJQUFBZixXQUFBLENBQUFnQixHQUFBLEVBQUNiLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBVSxRQUFBLEVBQUU7TUFBc0IsQ0FBbUIsQ0FBQyxFQUFDLGdFQUFnRTtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWYsV0FBQSxDQUFBZ0IsR0FBQSxFQUFDTixPQUFPO01BQUNRLElBQUksRUFBQyxNQUFNO01BQUNDLEtBQUssRUFBQywyQkFBMkI7TUFBQUosUUFBQSxlQUFDLElBQUFmLFdBQUEsQ0FBQWEsSUFBQSxFQUFDVixXQUFXLENBQUNJLENBQUM7UUFBQVEsUUFBQSxnQkFBQyxJQUFBZixXQUFBLENBQUFnQixHQUFBLEVBQUNiLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBVSxRQUFBLEVBQUU7UUFBUyxDQUFtQixDQUFDLEVBQUMsZ0ZBQWdGLGVBQUMsSUFBQWYsV0FBQSxDQUFBZ0IsR0FBQSxFQUFDYixXQUFXLENBQUNFLElBQUk7VUFBQVUsUUFBQSxFQUFFO1FBQXNCLENBQW1CLENBQUMsRUFBQyxxRUFBcUUsZUFBQyxJQUFBZixXQUFBLENBQUFnQixHQUFBLEVBQUNiLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBVSxRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsU0FBUyxlQUFDLElBQUFmLFdBQUEsQ0FBQWdCLEdBQUEsRUFBQ2IsV0FBVyxDQUFDRSxJQUFJO1VBQUFVLFFBQUEsRUFBRTtRQUFxQixDQUFtQixDQUFDLEVBQUMsU0FBUyxlQUFDLElBQUFmLFdBQUEsQ0FBQWdCLEdBQUEsRUFBQ2IsV0FBVyxDQUFDRSxJQUFJO1VBQUFVLFFBQUEsRUFBRTtRQUFlLENBQW1CLENBQUMsRUFBQyw2Q0FBNkM7TUFBQSxDQUFnQjtJQUFDLENBQVMsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBZixXQUFBLENBQUFhLElBQUEsRUFBQ1YsV0FBVyxDQUFDSSxDQUFDO01BQUFRLFFBQUEsR0FBRSxVQUFVLGVBQUMsSUFBQWYsV0FBQSxDQUFBZ0IsR0FBQSxFQUFDYixXQUFXLENBQUNDLENBQUM7UUFBQ2dCLElBQUksRUFBQyxtQkFBbUI7UUFBQUwsUUFBQSxFQUFFO01BQU0sQ0FBZ0IsQ0FBQyxFQUFDLEdBQUc7SUFBQSxDQUFnQixDQUFDO0VBQUEsQ0FBRSxDQUFDO0FBQ2hyQztBQUNlLFNBQVNNLFVBQVVBLENBQUNuQixLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUU7RUFDN0MsTUFBTTtJQUFDb0IsT0FBTyxFQUFFQztFQUFTLENBQUMsR0FBRztJQUMzQixHQUFHLElBQUFmLDZCQUFrQixFQUFDLENBQUM7SUFDdkIsR0FBR04sS0FBSyxDQUFDTztFQUNYLENBQUM7RUFDRCxPQUFPYyxTQUFTLGdCQUFHLElBQUF2QixXQUFBLENBQUFnQixHQUFBLEVBQUNPLFNBQVM7SUFBQSxHQUFLckIsS0FBSztJQUFBYSxRQUFBLGVBQUUsSUFBQWYsV0FBQSxDQUFBZ0IsR0FBQSxFQUFDZixpQkFBaUI7TUFBQSxHQUFLQztJQUFLLENBQUc7RUFBQyxDQUFXLENBQUMsR0FBR0QsaUJBQWlCLENBQUNDLEtBQUssQ0FBQztBQUNsSDtBQUFDc0IsRUFBQSxHQU51QkgsVUFBVTtBQU9sQyxTQUFTVCxvQkFBb0JBLENBQUNLLEVBQUUsRUFBRVEsU0FBUyxFQUFFQyxLQUFLLEVBQUU7RUFDbEQsTUFBTSxJQUFJQyxLQUFLLENBQUMsV0FBVyxJQUFJRixTQUFTLEdBQUcsV0FBVyxHQUFHLFFBQVEsQ0FBQyxHQUFHLElBQUksR0FBR1IsRUFBRSxHQUFHLG9FQUFvRSxJQUFJUyxLQUFLLEdBQUcscUNBQXFDLEdBQUdBLEtBQUssR0FBRyxvREFBb0QsR0FBRyxFQUFFLENBQUMsQ0FBQztBQUM5UTtBQUFDLElBQUFGLEVBQUE7QUFBQUksWUFBQSxDQUFBSixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}