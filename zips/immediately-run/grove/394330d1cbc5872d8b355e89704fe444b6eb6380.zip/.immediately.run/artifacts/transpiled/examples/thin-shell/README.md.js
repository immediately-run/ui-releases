var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      code: "code",
      h1: "h1",
      h2: "h2",
      li: "li",
      p: "p",
      pre: "pre",
      strong: "strong",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "the-thin-shell-grove-composed-as-a-library-m3",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-thin-shell-grove-composed-as-a-library-m3"
      }), "The thin shell — Grove composed as a library (M3)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The third of ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "PLATFORM_LAYERING_SPEC §1.1"
      }), "'s composition modes, as a runnable example."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "M1 dispatch"
        }), " — a content repo's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "immediately.run.json"
        }), " marker resolves to Grove through\nthe binding registry. No shell; the host mounts the corpus on stock Grove."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "M2 fork"
        }), " — engine and corpus in one repo (the docs wiki). Total ownership, at the cost\nof re-merging the engine."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "M3 library — this"
        }), " — an ordinary ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "App.tsx"
        }), " imports the engine pinned and arranges it.\nOwnership of composition without forking engine source."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "what-to-look-at",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "what-to-look-at"
      }), "What to look at"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/App.tsx"
      }), " is the whole shell. It imports ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "GroveApp"
      }), ", overrides one component through\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "composeComponents"
      }), ", and renders. The two commented-out lines are the failure cases: an\noverride of a locked component (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "Outlet"
      }), ") and of an engine internal (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "SafeEntryBody"
      }), ") both\nthrow at module load, naming what went wrong and what the available surface is."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "the-dependency",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-dependency"
      }), "The dependency"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-json",
        children: "\"@immediately-run/grove\": \"0.1.3\",\n\"@immediately-run/sdk\": \"^0.67.0\"\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The published package is the shape to copy, and the SDK line is not optional decoration.\nGrove declares the SDK and React in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "both"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "dependencies"
      }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "peerDependencies"
      }), " — the\nsandbox resolves an app's modules from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "dependencies"
      }), " alone, so the engine cannot drop\nthem (its own ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "check:deps"
      }), " gate enforces that), and the peer entry is what states the\nrange a shell must agree with."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The consequence for a shell: a range that does not satisfy the engine's peer does ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "not"
      }), "\nraise ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ERESOLVE"
      }), ". npm quietly satisfies the engine privately, and the shell ends up with\ntwo SDK copies — one at the top level and one nested under ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "@immediately-run/grove"
      }), " —\nwhose ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "TinkerableContext"
      }), " objects are not the same object, which is the failure R3-556 is\nabout. So keep the two ranges satisfiable together and check with\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "npm ls @immediately-run/sdk"
      }), " that exactly one copy resolves. Nothing will tell you if you\ndo not look."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "github:immediately-run/grove#<commit-sha>"
      }), " is the other form, for when you are iterating\non the engine and the shell together. Pin a commit sha rather than ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "#main"
      }), " for anything\nreal — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "LIBRARY_MOUNTS_SPEC §7"
      }), " makes a commit-pinned ref immutable and cache-first, which\nis both reproducible and the fast path. A branch ref works and picks up new commits on\nreload, which is the right trade only while you are iterating."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The engine's bytes arrive from its own GitHub Pages cache zip, and since the library-mount\nartifact work its ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "pre-transpiled artifacts arrive with them"
      }), " — the shell consumes the\nengine's compiled output instead of re-transpiling ~5k lines of TSX on every cold boot."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "mode-invariance",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "mode-invariance"
      }), "Mode invariance"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The same corpus under ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "content/"
      }), " renders identically here and under a fork or a dispatch.\nThat is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "§1.1"
      }), "'s mode-invariance rule, and it is a rule about the CORPUS: anything true of a\ncorpus in only one mode is a contract bug, not a feature."]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/examples/thin-shell/README.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJjb2RlIiwiaDEiLCJoMiIsImxpIiwicCIsInByZSIsInN0cm9uZyIsInVsIiwiX3Byb3ZpZGVDb21wb25lbnRzIiwiY29tcG9uZW50cyIsIkhlYWRpbmdBbmNob3IiLCJfbWlzc2luZ01keFJlZmVyZW5jZSIsImpzeHMiLCJGcmFnbWVudCIsImNoaWxkcmVuIiwiaWQiLCJqc3giLCJjbGFzc05hbWUiLCJNRFhDb250ZW50Iiwid3JhcHBlciIsIk1EWExheW91dCIsIl9jIiwiY29tcG9uZW50IiwicGxhY2UiLCJFcnJvciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlJFQURNRS5tZCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKkBqc3hSdW50aW1lIGF1dG9tYXRpYyovXG4vKkBqc3hJbXBvcnRTb3VyY2UgcmVhY3QqL1xuaW1wb3J0IHt1c2VNRFhDb21wb25lbnRzIGFzIF9wcm92aWRlQ29tcG9uZW50c30gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrL01EWFByb3ZpZGVyXCI7XG5mdW5jdGlvbiBfY3JlYXRlTWR4Q29udGVudChwcm9wcykge1xuICBjb25zdCBfY29tcG9uZW50cyA9IHtcbiAgICBjb2RlOiBcImNvZGVcIixcbiAgICBoMTogXCJoMVwiLFxuICAgIGgyOiBcImgyXCIsXG4gICAgbGk6IFwibGlcIixcbiAgICBwOiBcInBcIixcbiAgICBwcmU6IFwicHJlXCIsXG4gICAgc3Ryb25nOiBcInN0cm9uZ1wiLFxuICAgIHVsOiBcInVsXCIsXG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9LCB7SGVhZGluZ0FuY2hvcn0gPSBfY29tcG9uZW50cztcbiAgaWYgKCFIZWFkaW5nQW5jaG9yKSBfbWlzc2luZ01keFJlZmVyZW5jZShcIkhlYWRpbmdBbmNob3JcIiwgdHJ1ZSk7XG4gIHJldHVybiA8PjxfY29tcG9uZW50cy5oMSBpZD1cInRoZS10aGluLXNoZWxsLWdyb3ZlLWNvbXBvc2VkLWFzLWEtbGlicmFyeS1tM1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwidGhlLXRoaW4tc2hlbGwtZ3JvdmUtY29tcG9zZWQtYXMtYS1saWJyYXJ5LW0zXCIgLz57XCJUaGUgdGhpbiBzaGVsbCDigJQgR3JvdmUgY29tcG9zZWQgYXMgYSBsaWJyYXJ5IChNMylcIn08L19jb21wb25lbnRzLmgxPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSB0aGlyZCBvZiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJQTEFURk9STV9MQVlFUklOR19TUEVDIMKnMS4xXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIidzIGNvbXBvc2l0aW9uIG1vZGVzLCBhcyBhIHJ1bm5hYmxlIGV4YW1wbGUuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJNMSBkaXNwYXRjaFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgYSBjb250ZW50IHJlcG8ncyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJpbW1lZGlhdGVseS5ydW4uanNvblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgbWFya2VyIHJlc29sdmVzIHRvIEdyb3ZlIHRocm91Z2hcXG50aGUgYmluZGluZyByZWdpc3RyeS4gTm8gc2hlbGw7IHRoZSBob3N0IG1vdW50cyB0aGUgY29ycHVzIG9uIHN0b2NrIEdyb3ZlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiTTIgZm9ya1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgZW5naW5lIGFuZCBjb3JwdXMgaW4gb25lIHJlcG8gKHRoZSBkb2NzIHdpa2kpLiBUb3RhbCBvd25lcnNoaXAsIGF0IHRoZSBjb3N0XFxub2YgcmUtbWVyZ2luZyB0aGUgZW5naW5lLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiTTMgbGlicmFyeSDigJQgdGhpc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgYW4gb3JkaW5hcnkgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQXBwLnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaW1wb3J0cyB0aGUgZW5naW5lIHBpbm5lZCBhbmQgYXJyYW5nZXMgaXQuXFxuT3duZXJzaGlwIG9mIGNvbXBvc2l0aW9uIHdpdGhvdXQgZm9ya2luZyBlbmdpbmUgc291cmNlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJ3aGF0LXRvLWxvb2stYXRcIj48SGVhZGluZ0FuY2hvciBpZD1cIndoYXQtdG8tbG9vay1hdFwiIC8+e1wiV2hhdCB0byBsb29rIGF0XCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuY29kZT57XCJzcmMvQXBwLnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaXMgdGhlIHdob2xlIHNoZWxsLiBJdCBpbXBvcnRzIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkdyb3ZlQXBwXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgb3ZlcnJpZGVzIG9uZSBjb21wb25lbnQgdGhyb3VnaFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcImNvbXBvc2VDb21wb25lbnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgYW5kIHJlbmRlcnMuIFRoZSB0d28gY29tbWVudGVkLW91dCBsaW5lcyBhcmUgdGhlIGZhaWx1cmUgY2FzZXM6IGFuXFxub3ZlcnJpZGUgb2YgYSBsb2NrZWQgY29tcG9uZW50IChcIn08X2NvbXBvbmVudHMuY29kZT57XCJPdXRsZXRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSBhbmQgb2YgYW4gZW5naW5lIGludGVybmFsIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJTYWZlRW50cnlCb2R5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikgYm90aFxcbnRocm93IGF0IG1vZHVsZSBsb2FkLCBuYW1pbmcgd2hhdCB3ZW50IHdyb25nIGFuZCB3aGF0IHRoZSBhdmFpbGFibGUgc3VyZmFjZSBpcy5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwidGhlLWRlcGVuZGVuY3lcIj48SGVhZGluZ0FuY2hvciBpZD1cInRoZS1kZXBlbmRlbmN5XCIgLz57XCJUaGUgZGVwZW5kZW5jeVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnByZT48X2NvbXBvbmVudHMuY29kZSBjbGFzc05hbWU9XCJsYW5ndWFnZS1qc29uXCI+e1wiXFxcIkBpbW1lZGlhdGVseS1ydW4vZ3JvdmVcXFwiOiBcXFwiMC4xLjNcXFwiLFxcblxcXCJAaW1tZWRpYXRlbHktcnVuL3Nka1xcXCI6IFxcXCJeMC42Ny4wXFxcIlxcblwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnByZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgcHVibGlzaGVkIHBhY2thZ2UgaXMgdGhlIHNoYXBlIHRvIGNvcHksIGFuZCB0aGUgU0RLIGxpbmUgaXMgbm90IG9wdGlvbmFsIGRlY29yYXRpb24uXFxuR3JvdmUgZGVjbGFyZXMgdGhlIFNESyBhbmQgUmVhY3QgaW4gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJib3RoXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5jb2RlPntcImRlcGVuZGVuY2llc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYW5kIFwifTxfY29tcG9uZW50cy5jb2RlPntcInBlZXJEZXBlbmRlbmNpZXNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCB0aGVcXG5zYW5kYm94IHJlc29sdmVzIGFuIGFwcCdzIG1vZHVsZXMgZnJvbSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJkZXBlbmRlbmNpZXNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFsb25lLCBzbyB0aGUgZW5naW5lIGNhbm5vdCBkcm9wXFxudGhlbSAoaXRzIG93biBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjaGVjazpkZXBzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBnYXRlIGVuZm9yY2VzIHRoYXQpLCBhbmQgdGhlIHBlZXIgZW50cnkgaXMgd2hhdCBzdGF0ZXMgdGhlXFxucmFuZ2UgYSBzaGVsbCBtdXN0IGFncmVlIHdpdGguXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSBjb25zZXF1ZW5jZSBmb3IgYSBzaGVsbDogYSByYW5nZSB0aGF0IGRvZXMgbm90IHNhdGlzZnkgdGhlIGVuZ2luZSdzIHBlZXIgZG9lcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIlxcbnJhaXNlIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkVSRVNPTFZFXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi4gbnBtIHF1aWV0bHkgc2F0aXNmaWVzIHRoZSBlbmdpbmUgcHJpdmF0ZWx5LCBhbmQgdGhlIHNoZWxsIGVuZHMgdXAgd2l0aFxcbnR3byBTREsgY29waWVzIOKAlCBvbmUgYXQgdGhlIHRvcCBsZXZlbCBhbmQgb25lIG5lc3RlZCB1bmRlciBcIn08X2NvbXBvbmVudHMuY29kZT57XCJAaW1tZWRpYXRlbHktcnVuL2dyb3ZlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJRcXG53aG9zZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJUaW5rZXJhYmxlQ29udGV4dFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgb2JqZWN0cyBhcmUgbm90IHRoZSBzYW1lIG9iamVjdCwgd2hpY2ggaXMgdGhlIGZhaWx1cmUgUjMtNTU2IGlzXFxuYWJvdXQuIFNvIGtlZXAgdGhlIHR3byByYW5nZXMgc2F0aXNmaWFibGUgdG9nZXRoZXIgYW5kIGNoZWNrIHdpdGhcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJucG0gbHMgQGltbWVkaWF0ZWx5LXJ1bi9zZGtcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHRoYXQgZXhhY3RseSBvbmUgY29weSByZXNvbHZlcy4gTm90aGluZyB3aWxsIHRlbGwgeW91IGlmIHlvdVxcbmRvIG5vdCBsb29rLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuY29kZT57XCJnaXRodWI6aW1tZWRpYXRlbHktcnVuL2dyb3ZlIzxjb21taXQtc2hhPlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaXMgdGhlIG90aGVyIGZvcm0sIGZvciB3aGVuIHlvdSBhcmUgaXRlcmF0aW5nXFxub24gdGhlIGVuZ2luZSBhbmQgdGhlIHNoZWxsIHRvZ2V0aGVyLiBQaW4gYSBjb21taXQgc2hhIHJhdGhlciB0aGFuIFwifTxfY29tcG9uZW50cy5jb2RlPntcIiNtYWluXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBmb3IgYW55dGhpbmdcXG5yZWFsIOKAlCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJMSUJSQVJZX01PVU5UU19TUEVDIMKnN1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgbWFrZXMgYSBjb21taXQtcGlubmVkIHJlZiBpbW11dGFibGUgYW5kIGNhY2hlLWZpcnN0LCB3aGljaFxcbmlzIGJvdGggcmVwcm9kdWNpYmxlIGFuZCB0aGUgZmFzdCBwYXRoLiBBIGJyYW5jaCByZWYgd29ya3MgYW5kIHBpY2tzIHVwIG5ldyBjb21taXRzIG9uXFxucmVsb2FkLCB3aGljaCBpcyB0aGUgcmlnaHQgdHJhZGUgb25seSB3aGlsZSB5b3UgYXJlIGl0ZXJhdGluZy5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIGVuZ2luZSdzIGJ5dGVzIGFycml2ZSBmcm9tIGl0cyBvd24gR2l0SHViIFBhZ2VzIGNhY2hlIHppcCwgYW5kIHNpbmNlIHRoZSBsaWJyYXJ5LW1vdW50XFxuYXJ0aWZhY3Qgd29yayBpdHMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJwcmUtdHJhbnNwaWxlZCBhcnRpZmFjdHMgYXJyaXZlIHdpdGggdGhlbVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgdGhlIHNoZWxsIGNvbnN1bWVzIHRoZVxcbmVuZ2luZSdzIGNvbXBpbGVkIG91dHB1dCBpbnN0ZWFkIG9mIHJlLXRyYW5zcGlsaW5nIH41ayBsaW5lcyBvZiBUU1ggb24gZXZlcnkgY29sZCBib290LlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJtb2RlLWludmFyaWFuY2VcIj48SGVhZGluZ0FuY2hvciBpZD1cIm1vZGUtaW52YXJpYW5jZVwiIC8+e1wiTW9kZSBpbnZhcmlhbmNlXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgc2FtZSBjb3JwdXMgdW5kZXIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY29udGVudC9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHJlbmRlcnMgaWRlbnRpY2FsbHkgaGVyZSBhbmQgdW5kZXIgYSBmb3JrIG9yIGEgZGlzcGF0Y2guXFxuVGhhdCBpcyBcIn08X2NvbXBvbmVudHMuY29kZT57XCLCpzEuMVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIncyBtb2RlLWludmFyaWFuY2UgcnVsZSwgYW5kIGl0IGlzIGEgcnVsZSBhYm91dCB0aGUgQ09SUFVTOiBhbnl0aGluZyB0cnVlIG9mIGFcXG5jb3JwdXMgaW4gb25seSBvbmUgbW9kZSBpcyBhIGNvbnRyYWN0IGJ1Zywgbm90IGEgZmVhdHVyZS5cIn08L19jb21wb25lbnRzLnA+PC8+O1xufVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTURYQ29udGVudChwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHt3cmFwcGVyOiBNRFhMYXlvdXR9ID0ge1xuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfTtcbiAgcmV0dXJuIE1EWExheW91dCA/IDxNRFhMYXlvdXQgey4uLnByb3BzfT48X2NyZWF0ZU1keENvbnRlbnQgey4uLnByb3BzfSAvPjwvTURYTGF5b3V0PiA6IF9jcmVhdGVNZHhDb250ZW50KHByb3BzKTtcbn1cbmZ1bmN0aW9uIF9taXNzaW5nTWR4UmVmZXJlbmNlKGlkLCBjb21wb25lbnQsIHBsYWNlKSB7XG4gIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIFwiICsgKGNvbXBvbmVudCA/IFwiY29tcG9uZW50XCIgOiBcIm9iamVjdFwiKSArIFwiIGBcIiArIGlkICsgXCJgIHRvIGJlIGRlZmluZWQ6IHlvdSBsaWtlbHkgZm9yZ290IHRvIGltcG9ydCwgcGFzcywgb3IgcHJvdmlkZSBpdC5cIiArIChwbGFjZSA/IFwiXFxuSXTigJlzIHJlZmVyZW5jZWQgaW4geW91ciBjb2RlIGF0IGBcIiArIHBsYWNlICsgXCJgIGluIGAvYXBwL2V4YW1wbGVzL3RoaW4tc2hlbGwvUkVBRE1FLm1kYFwiIDogXCJcIikpO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFFQSxJQUFBQSxZQUFBLEdBQUFDLE9BQUE7QUFBd0YsSUFBQUMsV0FBQSxHQUFBRCxPQUFBO0FBRnhGO0FBQ0E7O0FBRUEsU0FBU0UsaUJBQWlCQSxDQUFDQyxLQUFLLEVBQUU7RUFDaEMsTUFBTUMsV0FBVyxHQUFHO01BQ2xCQyxJQUFJLEVBQUUsTUFBTTtNQUNaQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxDQUFDLEVBQUUsR0FBRztNQUNOQyxHQUFHLEVBQUUsS0FBSztNQUNWQyxNQUFNLEVBQUUsUUFBUTtNQUNoQkMsRUFBRSxFQUFFLElBQUk7TUFDUixHQUFHLElBQUFDLDZCQUFrQixFQUFDLENBQUM7TUFDdkIsR0FBR1YsS0FBSyxDQUFDVztJQUNYLENBQUM7SUFBRTtNQUFDQztJQUFhLENBQUMsR0FBR1gsV0FBVztFQUNoQyxJQUFJLENBQUNXLGFBQWEsRUFBRUMsb0JBQW9CLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQztFQUMvRCxvQkFBTyxJQUFBZixXQUFBLENBQUFnQixJQUFBLEVBQUFoQixXQUFBLENBQUFpQixRQUFBO0lBQUFDLFFBQUEsZ0JBQUUsSUFBQWxCLFdBQUEsQ0FBQWdCLElBQUEsRUFBQ2IsV0FBVyxDQUFDRSxFQUFFO01BQUNjLEVBQUUsRUFBQywrQ0FBK0M7TUFBQUQsUUFBQSxnQkFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUErQyxDQUFFLENBQUMsRUFBQyxtREFBbUQ7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFnQixJQUFBLEVBQUNiLFdBQVcsQ0FBQ0ssQ0FBQztNQUFBVSxRQUFBLEdBQUUsZUFBZSxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7UUFBQWMsUUFBQSxFQUFFO01BQTZCLENBQW1CLENBQUMsRUFBQyw4Q0FBOEM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFsQixXQUFBLENBQUFnQixJQUFBLEVBQUNiLFdBQVcsQ0FBQ1EsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUFsQixXQUFBLENBQUFnQixJQUFBLEVBQUNiLFdBQVcsQ0FBQ0ksRUFBRTtRQUFBVyxRQUFBLGdCQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNPLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQWEsQ0FBcUIsQ0FBQyxFQUFDLHNCQUFzQixlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7VUFBQWMsUUFBQSxFQUFFO1FBQXNCLENBQW1CLENBQUMsRUFBQywrR0FBK0c7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFsQixXQUFBLENBQUFnQixJQUFBLEVBQUNiLFdBQVcsQ0FBQ0ksRUFBRTtRQUFBVyxRQUFBLGdCQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNPLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQVMsQ0FBcUIsQ0FBQyxFQUFDLDJHQUEyRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQWdCLElBQUEsRUFBQ2IsV0FBVyxDQUFDSSxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBbUIsQ0FBcUIsQ0FBQyxFQUFDLGlCQUFpQixlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7VUFBQWMsUUFBQSxFQUFFO1FBQVMsQ0FBbUIsQ0FBQyxFQUFDLHNHQUFzRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbEIsV0FBQSxDQUFBZ0IsSUFBQSxFQUFDYixXQUFXLENBQUNHLEVBQUU7TUFBQ2EsRUFBRSxFQUFDLGlCQUFpQjtNQUFBRCxRQUFBLGdCQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQWlCLENBQUUsQ0FBQyxFQUFDLGlCQUFpQjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQWdCLElBQUEsRUFBQ2IsV0FBVyxDQUFDSyxDQUFDO01BQUFVLFFBQUEsZ0JBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBYyxRQUFBLEVBQUU7TUFBYSxDQUFtQixDQUFDLEVBQUMsa0NBQWtDLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBYyxRQUFBLEVBQUU7TUFBVSxDQUFtQixDQUFDLEVBQUMscUNBQXFDLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBYyxRQUFBLEVBQUU7TUFBbUIsQ0FBbUIsQ0FBQyxFQUFDLHdHQUF3RyxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7UUFBQWMsUUFBQSxFQUFFO01BQVEsQ0FBbUIsQ0FBQyxFQUFDLCtCQUErQixlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7UUFBQWMsUUFBQSxFQUFFO01BQWUsQ0FBbUIsQ0FBQyxFQUFDLHlGQUF5RjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQWdCLElBQUEsRUFBQ2IsV0FBVyxDQUFDRyxFQUFFO01BQUNhLEVBQUUsRUFBQyxnQkFBZ0I7TUFBQUQsUUFBQSxnQkFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFnQixDQUFFLENBQUMsRUFBQyxnQkFBZ0I7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNNLEdBQUc7TUFBQVMsUUFBQSxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7UUFBQ2lCLFNBQVMsRUFBQyxlQUFlO1FBQUFILFFBQUEsRUFBRTtNQUFpRixDQUFtQjtJQUFDLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQWdCLElBQUEsRUFBQ2IsV0FBVyxDQUFDSyxDQUFDO01BQUFVLFFBQUEsR0FBRSxnSUFBZ0ksZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDTyxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFNLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBYyxRQUFBLEVBQUU7TUFBYyxDQUFtQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7UUFBQWMsUUFBQSxFQUFFO01BQWtCLENBQW1CLENBQUMsRUFBQyxpREFBaUQsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDQyxJQUFJO1FBQUFjLFFBQUEsRUFBRTtNQUFjLENBQW1CLENBQUMsRUFBQyxtREFBbUQsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDQyxJQUFJO1FBQUFjLFFBQUEsRUFBRTtNQUFZLENBQW1CLENBQUMsRUFBQyw2RkFBNkY7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFsQixXQUFBLENBQUFnQixJQUFBLEVBQUNiLFdBQVcsQ0FBQ0ssQ0FBQztNQUFBVSxRQUFBLEdBQUUsb0ZBQW9GLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBSyxDQUFxQixDQUFDLEVBQUMsVUFBVSxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7UUFBQWMsUUFBQSxFQUFFO01BQVUsQ0FBbUIsQ0FBQyxFQUFDLHVJQUF1SSxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7UUFBQWMsUUFBQSxFQUFFO01BQXdCLENBQW1CLENBQUMsRUFBQyxZQUFZLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBYyxRQUFBLEVBQUU7TUFBbUIsQ0FBbUIsQ0FBQyxFQUFDLHVJQUF1SSxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7UUFBQWMsUUFBQSxFQUFFO01BQTZCLENBQW1CLENBQUMsRUFBQyw2RUFBNkU7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFsQixXQUFBLENBQUFnQixJQUFBLEVBQUNiLFdBQVcsQ0FBQ0ssQ0FBQztNQUFBVSxRQUFBLGdCQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7UUFBQWMsUUFBQSxFQUFFO01BQTJDLENBQW1CLENBQUMsRUFBQyxxSEFBcUgsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDQyxJQUFJO1FBQUFjLFFBQUEsRUFBRTtNQUFPLENBQW1CLENBQUMsRUFBQyx3QkFBd0IsZUFBQyxJQUFBbEIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDQyxJQUFJO1FBQUFjLFFBQUEsRUFBRTtNQUF3QixDQUFtQixDQUFDLEVBQUMscU5BQXFOO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbEIsV0FBQSxDQUFBZ0IsSUFBQSxFQUFDYixXQUFXLENBQUNLLENBQUM7TUFBQVUsUUFBQSxHQUFFLGdIQUFnSCxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNPLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQTJDLENBQXFCLENBQUMsRUFBQyxvSEFBb0g7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFsQixXQUFBLENBQUFnQixJQUFBLEVBQUNiLFdBQVcsQ0FBQ0csRUFBRTtNQUFDYSxFQUFFLEVBQUMsaUJBQWlCO01BQUFELFFBQUEsZ0JBQUMsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBaUIsQ0FBRSxDQUFDLEVBQUMsaUJBQWlCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBZ0IsSUFBQSxFQUFDYixXQUFXLENBQUNLLENBQUM7TUFBQVUsUUFBQSxHQUFFLHdCQUF3QixlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7UUFBQWMsUUFBQSxFQUFFO01BQVUsQ0FBbUIsQ0FBQyxFQUFDLHFFQUFxRSxlQUFDLElBQUFsQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNDLElBQUk7UUFBQWMsUUFBQSxFQUFFO01BQU0sQ0FBbUIsQ0FBQyxFQUFDLDJJQUEySTtJQUFBLENBQWdCLENBQUM7RUFBQSxDQUFFLENBQUM7QUFDdjlKO0FBQ2UsU0FBU0ksVUFBVUEsQ0FBQ3BCLEtBQUssR0FBRyxDQUFDLENBQUMsRUFBRTtFQUM3QyxNQUFNO0lBQUNxQixPQUFPLEVBQUVDO0VBQVMsQ0FBQyxHQUFHO0lBQzNCLEdBQUcsSUFBQVosNkJBQWtCLEVBQUMsQ0FBQztJQUN2QixHQUFHVixLQUFLLENBQUNXO0VBQ1gsQ0FBQztFQUNELE9BQU9XLFNBQVMsZ0JBQUcsSUFBQXhCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ0ksU0FBUztJQUFBLEdBQUt0QixLQUFLO0lBQUFnQixRQUFBLGVBQUUsSUFBQWxCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ25CLGlCQUFpQjtNQUFBLEdBQUtDO0lBQUssQ0FBRztFQUFDLENBQVcsQ0FBQyxHQUFHRCxpQkFBaUIsQ0FBQ0MsS0FBSyxDQUFDO0FBQ2xIO0FBQUN1QixFQUFBLEdBTnVCSCxVQUFVO0FBT2xDLFNBQVNQLG9CQUFvQkEsQ0FBQ0ksRUFBRSxFQUFFTyxTQUFTLEVBQUVDLEtBQUssRUFBRTtFQUNsRCxNQUFNLElBQUlDLEtBQUssQ0FBQyxXQUFXLElBQUlGLFNBQVMsR0FBRyxXQUFXLEdBQUcsUUFBUSxDQUFDLEdBQUcsSUFBSSxHQUFHUCxFQUFFLEdBQUcsb0VBQW9FLElBQUlRLEtBQUssR0FBRyxxQ0FBcUMsR0FBR0EsS0FBSyxHQUFHLDJDQUEyQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO0FBQ3JRO0FBQUMsSUFBQUYsRUFBQTtBQUFBSSxZQUFBLENBQUFKLEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}