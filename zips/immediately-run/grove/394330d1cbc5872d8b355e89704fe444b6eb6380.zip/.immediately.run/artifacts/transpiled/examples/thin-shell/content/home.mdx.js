var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      code: "code",
      h2: "h2",
      p: "p",
      strong: "strong",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["This page is rendered by the Grove engine arriving as a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "library mount"
      }), " at\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "/node_modules/@immediately-run/grove"
      }), ", not by a fork of it. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/App.tsx"
      }), " is the whole\nshell: it imports ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "GroveApp"
      }), " and renders it."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The corpus exists so mode invariance is testable at all. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "PLATFORM_LAYERING_SPEC §1.1"
      }), " says\nthe same corpus renders identically under dispatch, fork and library composition — a claim\nthat needs a corpus in each mode to compare. This is the library one."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "what-to-look-at",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "what-to-look-at"
      }), "What to look at"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Nothing here is special to library composition, and that is the point: no frontmatter key,\nno component and no link form is written differently because the engine arrived as a\ndependency. Anything that IS different in only one mode is a contract bug."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["See ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "/content/second.mdx",
        children: "the second page"
      }), " for the override in action."]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/examples/thin-shell/content/home.mdx`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiY29kZSIsImgyIiwicCIsInN0cm9uZyIsIl9wcm92aWRlQ29tcG9uZW50cyIsImNvbXBvbmVudHMiLCJIZWFkaW5nQW5jaG9yIiwiX21pc3NpbmdNZHhSZWZlcmVuY2UiLCJqc3hzIiwiRnJhZ21lbnQiLCJjaGlsZHJlbiIsImpzeCIsImlkIiwiaHJlZiIsIk1EWENvbnRlbnQiLCJ3cmFwcGVyIiwiTURYTGF5b3V0IiwiX2MiLCJjb21wb25lbnQiLCJwbGFjZSIsIkVycm9yIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiaG9tZS5tZHgiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgYTogXCJhXCIsXG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgaDI6IFwiaDJcIixcbiAgICBwOiBcInBcIixcbiAgICBzdHJvbmc6IFwic3Ryb25nXCIsXG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9LCB7SGVhZGluZ0FuY2hvcn0gPSBfY29tcG9uZW50cztcbiAgaWYgKCFIZWFkaW5nQW5jaG9yKSBfbWlzc2luZ01keFJlZmVyZW5jZShcIkhlYWRpbmdBbmNob3JcIiwgdHJ1ZSk7XG4gIHJldHVybiA8PjxfY29tcG9uZW50cy5wPntcIlRoaXMgcGFnZSBpcyByZW5kZXJlZCBieSB0aGUgR3JvdmUgZW5naW5lIGFycml2aW5nIGFzIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJsaWJyYXJ5IG1vdW50XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGF0XFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiL25vZGVfbW9kdWxlcy9AaW1tZWRpYXRlbHktcnVuL2dyb3ZlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgbm90IGJ5IGEgZm9yayBvZiBpdC4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL0FwcC50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGlzIHRoZSB3aG9sZVxcbnNoZWxsOiBpdCBpbXBvcnRzIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkdyb3ZlQXBwXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhbmQgcmVuZGVycyBpdC5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIGNvcnB1cyBleGlzdHMgc28gbW9kZSBpbnZhcmlhbmNlIGlzIHRlc3RhYmxlIGF0IGFsbC4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiUExBVEZPUk1fTEFZRVJJTkdfU1BFQyDCpzEuMVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgc2F5c1xcbnRoZSBzYW1lIGNvcnB1cyByZW5kZXJzIGlkZW50aWNhbGx5IHVuZGVyIGRpc3BhdGNoLCBmb3JrIGFuZCBsaWJyYXJ5IGNvbXBvc2l0aW9uIOKAlCBhIGNsYWltXFxudGhhdCBuZWVkcyBhIGNvcnB1cyBpbiBlYWNoIG1vZGUgdG8gY29tcGFyZS4gVGhpcyBpcyB0aGUgbGlicmFyeSBvbmUuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cIndoYXQtdG8tbG9vay1hdFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwid2hhdC10by1sb29rLWF0XCIgLz57XCJXaGF0IHRvIGxvb2sgYXRcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIk5vdGhpbmcgaGVyZSBpcyBzcGVjaWFsIHRvIGxpYnJhcnkgY29tcG9zaXRpb24sIGFuZCB0aGF0IGlzIHRoZSBwb2ludDogbm8gZnJvbnRtYXR0ZXIga2V5LFxcbm5vIGNvbXBvbmVudCBhbmQgbm8gbGluayBmb3JtIGlzIHdyaXR0ZW4gZGlmZmVyZW50bHkgYmVjYXVzZSB0aGUgZW5naW5lIGFycml2ZWQgYXMgYVxcbmRlcGVuZGVuY3kuIEFueXRoaW5nIHRoYXQgSVMgZGlmZmVyZW50IGluIG9ubHkgb25lIG1vZGUgaXMgYSBjb250cmFjdCBidWcuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlNlZSBcIn08X2NvbXBvbmVudHMuYSBocmVmPVwiL2NvbnRlbnQvc2Vjb25kLm1keFwiPntcInRoZSBzZWNvbmQgcGFnZVwifTwvX2NvbXBvbmVudHMuYT57XCIgZm9yIHRoZSBvdmVycmlkZSBpbiBhY3Rpb24uXCJ9PC9fY29tcG9uZW50cy5wPjwvPjtcbn1cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE1EWENvbnRlbnQocHJvcHMgPSB7fSkge1xuICBjb25zdCB7d3JhcHBlcjogTURYTGF5b3V0fSA9IHtcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH07XG4gIHJldHVybiBNRFhMYXlvdXQgPyA8TURYTGF5b3V0IHsuLi5wcm9wc30+PF9jcmVhdGVNZHhDb250ZW50IHsuLi5wcm9wc30gLz48L01EWExheW91dD4gOiBfY3JlYXRlTWR4Q29udGVudChwcm9wcyk7XG59XG5mdW5jdGlvbiBfbWlzc2luZ01keFJlZmVyZW5jZShpZCwgY29tcG9uZW50LCBwbGFjZSkge1xuICB0aHJvdyBuZXcgRXJyb3IoXCJFeHBlY3RlZCBcIiArIChjb21wb25lbnQgPyBcImNvbXBvbmVudFwiIDogXCJvYmplY3RcIikgKyBcIiBgXCIgKyBpZCArIFwiYCB0byBiZSBkZWZpbmVkOiB5b3UgbGlrZWx5IGZvcmdvdCB0byBpbXBvcnQsIHBhc3MsIG9yIHByb3ZpZGUgaXQuXCIgKyAocGxhY2UgPyBcIlxcbkl04oCZcyByZWZlcmVuY2VkIGluIHlvdXIgY29kZSBhdCBgXCIgKyBwbGFjZSArIFwiYCBpbiBgL2FwcC9leGFtcGxlcy90aGluLXNoZWxsL2NvbnRlbnQvaG9tZS5tZHhgXCIgOiBcIlwiKSk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUVBLElBQUFBLFlBQUEsR0FBQUMsT0FBQTtBQUF3RixJQUFBQyxXQUFBLEdBQUFELE9BQUE7QUFGeEY7QUFDQTs7QUFFQSxTQUFTRSxpQkFBaUJBLENBQUNDLEtBQUssRUFBRTtFQUNoQyxNQUFNQyxXQUFXLEdBQUc7TUFDbEJDLENBQUMsRUFBRSxHQUFHO01BQ05DLElBQUksRUFBRSxNQUFNO01BQ1pDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLENBQUMsRUFBRSxHQUFHO01BQ05DLE1BQU0sRUFBRSxRQUFRO01BQ2hCLEdBQUcsSUFBQUMsNkJBQWtCLEVBQUMsQ0FBQztNQUN2QixHQUFHUCxLQUFLLENBQUNRO0lBQ1gsQ0FBQztJQUFFO01BQUNDO0lBQWEsQ0FBQyxHQUFHUixXQUFXO0VBQ2hDLElBQUksQ0FBQ1EsYUFBYSxFQUFFQyxvQkFBb0IsQ0FBQyxlQUFlLEVBQUUsSUFBSSxDQUFDO0VBQy9ELG9CQUFPLElBQUFaLFdBQUEsQ0FBQWEsSUFBQSxFQUFBYixXQUFBLENBQUFjLFFBQUE7SUFBQUMsUUFBQSxnQkFBRSxJQUFBZixXQUFBLENBQUFhLElBQUEsRUFBQ1YsV0FBVyxDQUFDSSxDQUFDO01BQUFRLFFBQUEsR0FBRSwwREFBMEQsZUFBQyxJQUFBZixXQUFBLENBQUFnQixHQUFBLEVBQUNiLFdBQVcsQ0FBQ0ssTUFBTTtRQUFBTyxRQUFBLEVBQUU7TUFBZSxDQUFxQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUFmLFdBQUEsQ0FBQWdCLEdBQUEsRUFBQ2IsV0FBVyxDQUFDRSxJQUFJO1FBQUFVLFFBQUEsRUFBRTtNQUFzQyxDQUFtQixDQUFDLEVBQUMseUJBQXlCLGVBQUMsSUFBQWYsV0FBQSxDQUFBZ0IsR0FBQSxFQUFDYixXQUFXLENBQUNFLElBQUk7UUFBQVUsUUFBQSxFQUFFO01BQWEsQ0FBbUIsQ0FBQyxFQUFDLG1DQUFtQyxlQUFDLElBQUFmLFdBQUEsQ0FBQWdCLEdBQUEsRUFBQ2IsV0FBVyxDQUFDRSxJQUFJO1FBQUFVLFFBQUEsRUFBRTtNQUFVLENBQW1CLENBQUMsRUFBQyxrQkFBa0I7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFmLFdBQUEsQ0FBQWEsSUFBQSxFQUFDVixXQUFXLENBQUNJLENBQUM7TUFBQVEsUUFBQSxHQUFFLDJEQUEyRCxlQUFDLElBQUFmLFdBQUEsQ0FBQWdCLEdBQUEsRUFBQ2IsV0FBVyxDQUFDRSxJQUFJO1FBQUFVLFFBQUEsRUFBRTtNQUE2QixDQUFtQixDQUFDLEVBQUMsMEtBQTBLO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBZixXQUFBLENBQUFhLElBQUEsRUFBQ1YsV0FBVyxDQUFDRyxFQUFFO01BQUNXLEVBQUUsRUFBQyxpQkFBaUI7TUFBQUYsUUFBQSxnQkFBQyxJQUFBZixXQUFBLENBQUFnQixHQUFBLEVBQUNMLGFBQWE7UUFBQ00sRUFBRSxFQUFDO01BQWlCLENBQUUsQ0FBQyxFQUFDLGlCQUFpQjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQWdCLEdBQUEsRUFBQ2IsV0FBVyxDQUFDSSxDQUFDO01BQUFRLFFBQUEsRUFBRTtJQUE4UCxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFmLFdBQUEsQ0FBQWEsSUFBQSxFQUFDVixXQUFXLENBQUNJLENBQUM7TUFBQVEsUUFBQSxHQUFFLE1BQU0sZUFBQyxJQUFBZixXQUFBLENBQUFnQixHQUFBLEVBQUNiLFdBQVcsQ0FBQ0MsQ0FBQztRQUFDYyxJQUFJLEVBQUMscUJBQXFCO1FBQUFILFFBQUEsRUFBRTtNQUFpQixDQUFnQixDQUFDLEVBQUMsOEJBQThCO0lBQUEsQ0FBZ0IsQ0FBQztFQUFBLENBQUUsQ0FBQztBQUN4ekM7QUFDZSxTQUFTSSxVQUFVQSxDQUFDakIsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFO0VBQzdDLE1BQU07SUFBQ2tCLE9BQU8sRUFBRUM7RUFBUyxDQUFDLEdBQUc7SUFDM0IsR0FBRyxJQUFBWiw2QkFBa0IsRUFBQyxDQUFDO0lBQ3ZCLEdBQUdQLEtBQUssQ0FBQ1E7RUFDWCxDQUFDO0VBQ0QsT0FBT1csU0FBUyxnQkFBRyxJQUFBckIsV0FBQSxDQUFBZ0IsR0FBQSxFQUFDSyxTQUFTO0lBQUEsR0FBS25CLEtBQUs7SUFBQWEsUUFBQSxlQUFFLElBQUFmLFdBQUEsQ0FBQWdCLEdBQUEsRUFBQ2YsaUJBQWlCO01BQUEsR0FBS0M7SUFBSyxDQUFHO0VBQUMsQ0FBVyxDQUFDLEdBQUdELGlCQUFpQixDQUFDQyxLQUFLLENBQUM7QUFDbEg7QUFBQ29CLEVBQUEsR0FOdUJILFVBQVU7QUFPbEMsU0FBU1Asb0JBQW9CQSxDQUFDSyxFQUFFLEVBQUVNLFNBQVMsRUFBRUMsS0FBSyxFQUFFO0VBQ2xELE1BQU0sSUFBSUMsS0FBSyxDQUFDLFdBQVcsSUFBSUYsU0FBUyxHQUFHLFdBQVcsR0FBRyxRQUFRLENBQUMsR0FBRyxJQUFJLEdBQUdOLEVBQUUsR0FBRyxvRUFBb0UsSUFBSU8sS0FBSyxHQUFHLHFDQUFxQyxHQUFHQSxLQUFLLEdBQUcsa0RBQWtELEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDNVE7QUFBQyxJQUFBRixFQUFBO0FBQUFJLFlBQUEsQ0FBQUosRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}