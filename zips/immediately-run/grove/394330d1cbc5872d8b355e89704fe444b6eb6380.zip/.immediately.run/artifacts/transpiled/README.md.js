var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      code: "code",
      h1: "h1",
      h2: "h2",
      li: "li",
      ol: "ol",
      p: "p",
      pre: "pre",
      strong: "strong",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "grove-the-wiki-viewer-for-immediatelyrun",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "grove-the-wiki-viewer-for-immediatelyrun"
      }), "Grove — the wiki viewer for ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "https://immediately.run",
        children: "immediately.run"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Grove renders an MDX corpus as a wiki: plain interlinked entries with frontmatter,\na sidebar, search, backlinks, tags, timelines — transpiled in the browser, no\nserver, no build step at runtime. It ships three ways:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "As a fork"
        }), " — copy this repo, replace ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "content/"
        }), " with your entries, push,\nopen it on immediately.run. Your corpus, your code, one repo."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "As the dispatched viewer"
        }), " — a corpus mounted into a running Grove via the\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "open-wiki"
        }), " task; the wiki is somebody else's directory and Grove reads it\nthrough the mount (the engine never assumes it owns the corpus)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "As a pinned library"
        }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "@immediately-run/grove"
        }), " as an ordinary npm\ndependency: compose ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/lib.ts"
        }), "'s helpers and the component vocabulary into\nyour own viewer."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The composition surface — every component, its tier and overridability, the\nfrontmatter keys the engine reads — is declared in\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "./viewer.manifest.json",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "viewer.manifest.json"
        })
      }), " and summarized in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "./llms.txt",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "llms.txt"
        })
      }), ".\nThe themes and layouts are compared live by the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "Themes"
      }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "Layouts"
      }), " entries of\nthe sample corpus; the theming contract (token-only themes, declared faces,\nchecked contrast) is stated in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "./THEMING.md",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "THEMING.md"
        })
      }), ". What the engine owns\nversus what content may reach is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "./docs/ENGINE_BOUNDARY.md",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "docs/ENGINE_BOUNDARY.md"
        })
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "running-locally",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "running-locally"
      }), "Running locally"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-bash",
        children: "npm install\nnpm run dev        # vite dev server — the sample handbook\nnpm run verify     # lint + build + tests + the manifest/contrast/token gates\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["On immediately.run, open\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "https://immediately.run/present/github/<owner>/grove/main/files/content/home.mdx"
      }), "\n(fork) — or dispatch it at any wiki directory with the platform's file picker.\nA GitHub Action (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: ".github/workflows/cache.yml"
      }), ") publishes a pre-cached zip to\nthis repo's own Pages on every push to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "main"
      }), ", so anonymous loads are fast."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "authoring-entries",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "authoring-entries"
      }), "Authoring entries"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Entries are ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: ".mdx"
      }), " files under ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "content/"
      }), " with YAML frontmatter (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "title"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "tags"
      }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "date"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "nav"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "order"
      }), ", plus the engine keys in the manifest: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "site"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "theme"
      }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "layout"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "view"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "frame"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "render"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "cover"
      }), ", …). Interlink with wiki links;\ndeclare a picture per entry with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "cover:"
      }), "; group a folder with a\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "content/<dir>/_layout.mdx"
      }), " starter. The built-in agent answers questions about\nthe corpus over the host's chat slot — ask it where things are before editing."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "license",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "license"
      }), "License"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Apache-2.0. Bundled fonts in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "assets/fonts/"
      }), " carry their own notices\n(OFL / USWDS) alongside."]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/README.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiY29kZSIsImgxIiwiaDIiLCJsaSIsIm9sIiwicCIsInByZSIsInN0cm9uZyIsIl9wcm92aWRlQ29tcG9uZW50cyIsImNvbXBvbmVudHMiLCJIZWFkaW5nQW5jaG9yIiwiX21pc3NpbmdNZHhSZWZlcmVuY2UiLCJqc3hzIiwiRnJhZ21lbnQiLCJjaGlsZHJlbiIsImlkIiwianN4IiwiaHJlZiIsImNsYXNzTmFtZSIsIk1EWENvbnRlbnQiLCJ3cmFwcGVyIiwiTURYTGF5b3V0IiwiX2MiLCJjb21wb25lbnQiLCJwbGFjZSIsIkVycm9yIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUkVBRE1FLm1kIl0sInNvdXJjZXNDb250ZW50IjpbIi8qQGpzeFJ1bnRpbWUgYXV0b21hdGljKi9cbi8qQGpzeEltcG9ydFNvdXJjZSByZWFjdCovXG5pbXBvcnQge3VzZU1EWENvbXBvbmVudHMgYXMgX3Byb3ZpZGVDb21wb25lbnRzfSBmcm9tIFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGsvTURYUHJvdmlkZXJcIjtcbmZ1bmN0aW9uIF9jcmVhdGVNZHhDb250ZW50KHByb3BzKSB7XG4gIGNvbnN0IF9jb21wb25lbnRzID0ge1xuICAgIGE6IFwiYVwiLFxuICAgIGNvZGU6IFwiY29kZVwiLFxuICAgIGgxOiBcImgxXCIsXG4gICAgaDI6IFwiaDJcIixcbiAgICBsaTogXCJsaVwiLFxuICAgIG9sOiBcIm9sXCIsXG4gICAgcDogXCJwXCIsXG4gICAgcHJlOiBcInByZVwiLFxuICAgIHN0cm9uZzogXCJzdHJvbmdcIixcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH0sIHtIZWFkaW5nQW5jaG9yfSA9IF9jb21wb25lbnRzO1xuICBpZiAoIUhlYWRpbmdBbmNob3IpIF9taXNzaW5nTWR4UmVmZXJlbmNlKFwiSGVhZGluZ0FuY2hvclwiLCB0cnVlKTtcbiAgcmV0dXJuIDw+PF9jb21wb25lbnRzLmgxIGlkPVwiZ3JvdmUtdGhlLXdpa2ktdmlld2VyLWZvci1pbW1lZGlhdGVseXJ1blwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiZ3JvdmUtdGhlLXdpa2ktdmlld2VyLWZvci1pbW1lZGlhdGVseXJ1blwiIC8+e1wiR3JvdmUg4oCUIHRoZSB3aWtpIHZpZXdlciBmb3IgXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cImh0dHBzOi8vaW1tZWRpYXRlbHkucnVuXCI+e1wiaW1tZWRpYXRlbHkucnVuXCJ9PC9fY29tcG9uZW50cy5hPjwvX2NvbXBvbmVudHMuaDE+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiR3JvdmUgcmVuZGVycyBhbiBNRFggY29ycHVzIGFzIGEgd2lraTogcGxhaW4gaW50ZXJsaW5rZWQgZW50cmllcyB3aXRoIGZyb250bWF0dGVyLFxcbmEgc2lkZWJhciwgc2VhcmNoLCBiYWNrbGlua3MsIHRhZ3MsIHRpbWVsaW5lcyDigJQgdHJhbnNwaWxlZCBpbiB0aGUgYnJvd3Nlciwgbm9cXG5zZXJ2ZXIsIG5vIGJ1aWxkIHN0ZXAgYXQgcnVudGltZS4gSXQgc2hpcHMgdGhyZWUgd2F5czpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkFzIGEgZm9ya1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgY29weSB0aGlzIHJlcG8sIHJlcGxhY2UgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY29udGVudC9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHdpdGggeW91ciBlbnRyaWVzLCBwdXNoLFxcbm9wZW4gaXQgb24gaW1tZWRpYXRlbHkucnVuLiBZb3VyIGNvcnB1cywgeW91ciBjb2RlLCBvbmUgcmVwby5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkFzIHRoZSBkaXNwYXRjaGVkIHZpZXdlclwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgYSBjb3JwdXMgbW91bnRlZCBpbnRvIGEgcnVubmluZyBHcm92ZSB2aWEgdGhlXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wib3Blbi13aWtpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB0YXNrOyB0aGUgd2lraSBpcyBzb21lYm9keSBlbHNlJ3MgZGlyZWN0b3J5IGFuZCBHcm92ZSByZWFkcyBpdFxcbnRocm91Z2ggdGhlIG1vdW50ICh0aGUgZW5naW5lIG5ldmVyIGFzc3VtZXMgaXQgb3ducyB0aGUgY29ycHVzKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkFzIGEgcGlubmVkIGxpYnJhcnlcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkBpbW1lZGlhdGVseS1ydW4vZ3JvdmVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFzIGFuIG9yZGluYXJ5IG5wbVxcbmRlcGVuZGVuY3k6IGNvbXBvc2UgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2xpYi50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIncyBoZWxwZXJzIGFuZCB0aGUgY29tcG9uZW50IHZvY2FidWxhcnkgaW50b1xcbnlvdXIgb3duIHZpZXdlci5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMub2w+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIGNvbXBvc2l0aW9uIHN1cmZhY2Ug4oCUIGV2ZXJ5IGNvbXBvbmVudCwgaXRzIHRpZXIgYW5kIG92ZXJyaWRhYmlsaXR5LCB0aGVcXG5mcm9udG1hdHRlciBrZXlzIHRoZSBlbmdpbmUgcmVhZHMg4oCUIGlzIGRlY2xhcmVkIGluXFxuXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cIi4vdmlld2VyLm1hbmlmZXN0Lmpzb25cIj48X2NvbXBvbmVudHMuY29kZT57XCJ2aWV3ZXIubWFuaWZlc3QuanNvblwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLmE+e1wiIGFuZCBzdW1tYXJpemVkIGluIFwifTxfY29tcG9uZW50cy5hIGhyZWY9XCIuL2xsbXMudHh0XCI+PF9jb21wb25lbnRzLmNvZGU+e1wibGxtcy50eHRcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5hPntcIi5cXG5UaGUgdGhlbWVzIGFuZCBsYXlvdXRzIGFyZSBjb21wYXJlZCBsaXZlIGJ5IHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJUaGVtZXNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFuZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJMYXlvdXRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBlbnRyaWVzIG9mXFxudGhlIHNhbXBsZSBjb3JwdXM7IHRoZSB0aGVtaW5nIGNvbnRyYWN0ICh0b2tlbi1vbmx5IHRoZW1lcywgZGVjbGFyZWQgZmFjZXMsXFxuY2hlY2tlZCBjb250cmFzdCkgaXMgc3RhdGVkIGluIFwifTxfY29tcG9uZW50cy5hIGhyZWY9XCIuL1RIRU1JTkcubWRcIj48X2NvbXBvbmVudHMuY29kZT57XCJUSEVNSU5HLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuYT57XCIuIFdoYXQgdGhlIGVuZ2luZSBvd25zXFxudmVyc3VzIHdoYXQgY29udGVudCBtYXkgcmVhY2ggaXMgXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cIi4vZG9jcy9FTkdJTkVfQk9VTkRBUlkubWRcIj48X2NvbXBvbmVudHMuY29kZT57XCJkb2NzL0VOR0lORV9CT1VOREFSWS5tZFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLmE+e1wiLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJydW5uaW5nLWxvY2FsbHlcIj48SGVhZGluZ0FuY2hvciBpZD1cInJ1bm5pbmctbG9jYWxseVwiIC8+e1wiUnVubmluZyBsb2NhbGx5XCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucHJlPjxfY29tcG9uZW50cy5jb2RlIGNsYXNzTmFtZT1cImxhbmd1YWdlLWJhc2hcIj57XCJucG0gaW5zdGFsbFxcbm5wbSBydW4gZGV2ICAgICAgICAjIHZpdGUgZGV2IHNlcnZlciDigJQgdGhlIHNhbXBsZSBoYW5kYm9va1xcbm5wbSBydW4gdmVyaWZ5ICAgICAjIGxpbnQgKyBidWlsZCArIHRlc3RzICsgdGhlIG1hbmlmZXN0L2NvbnRyYXN0L3Rva2VuIGdhdGVzXFxuXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMucHJlPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIk9uIGltbWVkaWF0ZWx5LnJ1biwgb3BlblxcblwifTxfY29tcG9uZW50cy5jb2RlPntcImh0dHBzOi8vaW1tZWRpYXRlbHkucnVuL3ByZXNlbnQvZ2l0aHViLzxvd25lcj4vZ3JvdmUvbWFpbi9maWxlcy9jb250ZW50L2hvbWUubWR4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIlxcbihmb3JrKSDigJQgb3IgZGlzcGF0Y2ggaXQgYXQgYW55IHdpa2kgZGlyZWN0b3J5IHdpdGggdGhlIHBsYXRmb3JtJ3MgZmlsZSBwaWNrZXIuXFxuQSBHaXRIdWIgQWN0aW9uIChcIn08X2NvbXBvbmVudHMuY29kZT57XCIuZ2l0aHViL3dvcmtmbG93cy9jYWNoZS55bWxcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSBwdWJsaXNoZXMgYSBwcmUtY2FjaGVkIHppcCB0b1xcbnRoaXMgcmVwbydzIG93biBQYWdlcyBvbiBldmVyeSBwdXNoIHRvIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1haW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBzbyBhbm9ueW1vdXMgbG9hZHMgYXJlIGZhc3QuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cImF1dGhvcmluZy1lbnRyaWVzXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJhdXRob3JpbmctZW50cmllc1wiIC8+e1wiQXV0aG9yaW5nIGVudHJpZXNcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkVudHJpZXMgYXJlIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi5tZHhcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGZpbGVzIHVuZGVyIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNvbnRlbnQvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB3aXRoIFlBTUwgZnJvbnRtYXR0ZXIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcInRpdGxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widGFnc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZGF0ZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm5hdlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm9yZGVyXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgcGx1cyB0aGUgZW5naW5lIGtleXMgaW4gdGhlIG1hbmlmZXN0OiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzaXRlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widGhlbWVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcImxheW91dFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcInZpZXdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmcmFtZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcInJlbmRlclwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNvdmVyXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwg4oCmKS4gSW50ZXJsaW5rIHdpdGggd2lraSBsaW5rcztcXG5kZWNsYXJlIGEgcGljdHVyZSBwZXIgZW50cnkgd2l0aCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjb3ZlcjpcIn08L19jb21wb25lbnRzLmNvZGU+e1wiOyBncm91cCBhIGZvbGRlciB3aXRoIGFcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJjb250ZW50LzxkaXI+L19sYXlvdXQubWR4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBzdGFydGVyLiBUaGUgYnVpbHQtaW4gYWdlbnQgYW5zd2VycyBxdWVzdGlvbnMgYWJvdXRcXG50aGUgY29ycHVzIG92ZXIgdGhlIGhvc3QncyBjaGF0IHNsb3Qg4oCUIGFzayBpdCB3aGVyZSB0aGluZ3MgYXJlIGJlZm9yZSBlZGl0aW5nLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJsaWNlbnNlXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJsaWNlbnNlXCIgLz57XCJMaWNlbnNlXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJBcGFjaGUtMi4wLiBCdW5kbGVkIGZvbnRzIGluIFwifTxfY29tcG9uZW50cy5jb2RlPntcImFzc2V0cy9mb250cy9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNhcnJ5IHRoZWlyIG93biBub3RpY2VzXFxuKE9GTCAvIFVTV0RTKSBhbG9uZ3NpZGUuXCJ9PC9fY29tcG9uZW50cy5wPjwvPjtcbn1cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE1EWENvbnRlbnQocHJvcHMgPSB7fSkge1xuICBjb25zdCB7d3JhcHBlcjogTURYTGF5b3V0fSA9IHtcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH07XG4gIHJldHVybiBNRFhMYXlvdXQgPyA8TURYTGF5b3V0IHsuLi5wcm9wc30+PF9jcmVhdGVNZHhDb250ZW50IHsuLi5wcm9wc30gLz48L01EWExheW91dD4gOiBfY3JlYXRlTWR4Q29udGVudChwcm9wcyk7XG59XG5mdW5jdGlvbiBfbWlzc2luZ01keFJlZmVyZW5jZShpZCwgY29tcG9uZW50LCBwbGFjZSkge1xuICB0aHJvdyBuZXcgRXJyb3IoXCJFeHBlY3RlZCBcIiArIChjb21wb25lbnQgPyBcImNvbXBvbmVudFwiIDogXCJvYmplY3RcIikgKyBcIiBgXCIgKyBpZCArIFwiYCB0byBiZSBkZWZpbmVkOiB5b3UgbGlrZWx5IGZvcmdvdCB0byBpbXBvcnQsIHBhc3MsIG9yIHByb3ZpZGUgaXQuXCIgKyAocGxhY2UgPyBcIlxcbkl04oCZcyByZWZlcmVuY2VkIGluIHlvdXIgY29kZSBhdCBgXCIgKyBwbGFjZSArIFwiYCBpbiBgL2FwcC9SRUFETUUubWRgXCIgOiBcIlwiKSk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUVBLElBQUFBLFlBQUEsR0FBQUMsT0FBQTtBQUF3RixJQUFBQyxXQUFBLEdBQUFELE9BQUE7QUFGeEY7QUFDQTs7QUFFQSxTQUFTRSxpQkFBaUJBLENBQUNDLEtBQUssRUFBRTtFQUNoQyxNQUFNQyxXQUFXLEdBQUc7TUFDbEJDLENBQUMsRUFBRSxHQUFHO01BQ05DLElBQUksRUFBRSxNQUFNO01BQ1pDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLENBQUMsRUFBRSxHQUFHO01BQ05DLEdBQUcsRUFBRSxLQUFLO01BQ1ZDLE1BQU0sRUFBRSxRQUFRO01BQ2hCLEdBQUcsSUFBQUMsNkJBQWtCLEVBQUMsQ0FBQztNQUN2QixHQUFHWCxLQUFLLENBQUNZO0lBQ1gsQ0FBQztJQUFFO01BQUNDO0lBQWEsQ0FBQyxHQUFHWixXQUFXO0VBQ2hDLElBQUksQ0FBQ1ksYUFBYSxFQUFFQyxvQkFBb0IsQ0FBQyxlQUFlLEVBQUUsSUFBSSxDQUFDO0VBQy9ELG9CQUFPLElBQUFoQixXQUFBLENBQUFpQixJQUFBLEVBQUFqQixXQUFBLENBQUFrQixRQUFBO0lBQUFDLFFBQUEsZ0JBQUUsSUFBQW5CLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDRyxFQUFFO01BQUNjLEVBQUUsRUFBQywwQ0FBMEM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUEwQyxDQUFFLENBQUMsRUFBQyw4QkFBOEIsZUFBQyxJQUFBcEIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxDQUFDO1FBQUNrQixJQUFJLEVBQUMseUJBQXlCO1FBQUFILFFBQUEsRUFBRTtNQUFpQixDQUFnQixDQUFDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDTyxDQUFDO01BQUFTLFFBQUEsRUFBRTtJQUEyTixDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ00sRUFBRTtNQUFBVSxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ0ssRUFBRTtRQUFBVyxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNTLE1BQU07VUFBQU8sUUFBQSxFQUFFO1FBQVcsQ0FBcUIsQ0FBQyxFQUFDLDZCQUE2QixlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNFLElBQUk7VUFBQWMsUUFBQSxFQUFFO1FBQVUsQ0FBbUIsQ0FBQyxFQUFDLDBGQUEwRjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDSyxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBTyxRQUFBLEVBQUU7UUFBMEIsQ0FBcUIsQ0FBQyxFQUFDLG9EQUFvRCxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNFLElBQUk7VUFBQWMsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLG1JQUFtSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDSyxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBTyxRQUFBLEVBQUU7UUFBcUIsQ0FBcUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUF3QixDQUFtQixDQUFDLEVBQUMsMkNBQTJDLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBWSxDQUFtQixDQUFDLEVBQUMsZ0VBQWdFO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ08sQ0FBQztNQUFBUyxRQUFBLEdBQUUsbUlBQW1JLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsQ0FBQztRQUFDa0IsSUFBSSxFQUFDLHdCQUF3QjtRQUFBSCxRQUFBLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBc0IsQ0FBbUI7TUFBQyxDQUFlLENBQUMsRUFBQyxxQkFBcUIsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxDQUFDO1FBQUNrQixJQUFJLEVBQUMsWUFBWTtRQUFBSCxRQUFBLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBVSxDQUFtQjtNQUFDLENBQWUsQ0FBQyxFQUFDLHFEQUFxRCxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNFLElBQUk7UUFBQWMsUUFBQSxFQUFFO01BQVEsQ0FBbUIsQ0FBQyxFQUFDLE9BQU8sZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFjLFFBQUEsRUFBRTtNQUFTLENBQW1CLENBQUMsRUFBQywySEFBMkgsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxDQUFDO1FBQUNrQixJQUFJLEVBQUMsY0FBYztRQUFBSCxRQUFBLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBWSxDQUFtQjtNQUFDLENBQWUsQ0FBQyxFQUFDLDJEQUEyRCxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLENBQUM7UUFBQ2tCLElBQUksRUFBQywyQkFBMkI7UUFBQUgsUUFBQSxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNFLElBQUk7VUFBQWMsUUFBQSxFQUFFO1FBQXlCLENBQW1CO01BQUMsQ0FBZSxDQUFDLEVBQUMsR0FBRztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDSSxFQUFFO01BQUNhLEVBQUUsRUFBQyxpQkFBaUI7TUFBQUQsUUFBQSxnQkFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFpQixDQUFFLENBQUMsRUFBQyxpQkFBaUI7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNRLEdBQUc7TUFBQVEsUUFBQSxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNFLElBQUk7UUFBQ2tCLFNBQVMsRUFBQyxlQUFlO1FBQUFKLFFBQUEsRUFBRTtNQUEwSixDQUFtQjtJQUFDLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDTyxDQUFDO01BQUFTLFFBQUEsR0FBRSw0QkFBNEIsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFjLFFBQUEsRUFBRTtNQUFrRixDQUFtQixDQUFDLEVBQUMscUdBQXFHLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBYyxRQUFBLEVBQUU7TUFBNkIsQ0FBbUIsQ0FBQyxFQUFDLDBFQUEwRSxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNFLElBQUk7UUFBQWMsUUFBQSxFQUFFO01BQU0sQ0FBbUIsQ0FBQyxFQUFDLGdDQUFnQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDSSxFQUFFO01BQUNhLEVBQUUsRUFBQyxtQkFBbUI7TUFBQUQsUUFBQSxnQkFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFtQixDQUFFLENBQUMsRUFBQyxtQkFBbUI7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ08sQ0FBQztNQUFBUyxRQUFBLEdBQUUsY0FBYyxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNFLElBQUk7UUFBQWMsUUFBQSxFQUFFO01BQU0sQ0FBbUIsQ0FBQyxFQUFDLGVBQWUsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFjLFFBQUEsRUFBRTtNQUFVLENBQW1CLENBQUMsRUFBQywwQkFBMEIsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFjLFFBQUEsRUFBRTtNQUFPLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBYyxRQUFBLEVBQUU7TUFBTSxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNFLElBQUk7UUFBQWMsUUFBQSxFQUFFO01BQU0sQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFjLFFBQUEsRUFBRTtNQUFLLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBYyxRQUFBLEVBQUU7TUFBTyxDQUFtQixDQUFDLEVBQUMsMENBQTBDLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBYyxRQUFBLEVBQUU7TUFBTSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNFLElBQUk7UUFBQWMsUUFBQSxFQUFFO01BQU8sQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFjLFFBQUEsRUFBRTtNQUFRLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBYyxRQUFBLEVBQUU7TUFBTSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNFLElBQUk7UUFBQWMsUUFBQSxFQUFFO01BQU8sQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFjLFFBQUEsRUFBRTtNQUFRLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBYyxRQUFBLEVBQUU7TUFBTyxDQUFtQixDQUFDLEVBQUMscUVBQXFFLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBYyxRQUFBLEVBQUU7TUFBUSxDQUFtQixDQUFDLEVBQUMsMkJBQTJCLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBYyxRQUFBLEVBQUU7TUFBMkIsQ0FBbUIsQ0FBQyxFQUFDLHNJQUFzSTtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDSSxFQUFFO01BQUNhLEVBQUUsRUFBQyxTQUFTO01BQUFELFFBQUEsZ0JBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBUyxDQUFFLENBQUMsRUFBQyxTQUFTO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNPLENBQUM7TUFBQVMsUUFBQSxHQUFFLCtCQUErQixlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNFLElBQUk7UUFBQWMsUUFBQSxFQUFFO01BQWUsQ0FBbUIsQ0FBQyxFQUFDLG9EQUFvRDtJQUFBLENBQWdCLENBQUM7RUFBQSxDQUFFLENBQUM7QUFDOTNKO0FBQ2UsU0FBU0ssVUFBVUEsQ0FBQ3RCLEtBQUssR0FBRyxDQUFDLENBQUMsRUFBRTtFQUM3QyxNQUFNO0lBQUN1QixPQUFPLEVBQUVDO0VBQVMsQ0FBQyxHQUFHO0lBQzNCLEdBQUcsSUFBQWIsNkJBQWtCLEVBQUMsQ0FBQztJQUN2QixHQUFHWCxLQUFLLENBQUNZO0VBQ1gsQ0FBQztFQUNELE9BQU9ZLFNBQVMsZ0JBQUcsSUFBQTFCLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ0ssU0FBUztJQUFBLEdBQUt4QixLQUFLO0lBQUFpQixRQUFBLGVBQUUsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ3BCLGlCQUFpQjtNQUFBLEdBQUtDO0lBQUssQ0FBRztFQUFDLENBQVcsQ0FBQyxHQUFHRCxpQkFBaUIsQ0FBQ0MsS0FBSyxDQUFDO0FBQ2xIO0FBQUN5QixFQUFBLEdBTnVCSCxVQUFVO0FBT2xDLFNBQVNSLG9CQUFvQkEsQ0FBQ0ksRUFBRSxFQUFFUSxTQUFTLEVBQUVDLEtBQUssRUFBRTtFQUNsRCxNQUFNLElBQUlDLEtBQUssQ0FBQyxXQUFXLElBQUlGLFNBQVMsR0FBRyxXQUFXLEdBQUcsUUFBUSxDQUFDLEdBQUcsSUFBSSxHQUFHUixFQUFFLEdBQUcsb0VBQW9FLElBQUlTLEtBQUssR0FBRyxxQ0FBcUMsR0FBR0EsS0FBSyxHQUFHLHVCQUF1QixHQUFHLEVBQUUsQ0FBQyxDQUFDO0FBQ2pQO0FBQUMsSUFBQUYsRUFBQTtBQUFBSSxZQUFBLENBQUFKLEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}