var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/
/*
A SECTION layout, nested under the root shell. It wraps every entry in
`content/people/` — each profile renders at `<Outlet/>` below the shared hero,
so no individual bio has to carry the section header or the "more people" rail.
This is the nesting the URL never sees: the address bar still names the profile
file (e.g. /content/people/ada-lovelace.mdx), and this frame is resolved around
it by folder convention. Drop a `frame: none` in a profile's frontmatter to opt
it out.
*/

function _createMdxContent(props) {
  const {
    ChildPages,
    Outlet
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  if (!ChildPages) _missingMdxReference("ChildPages", true, "23:5-23:19");
  if (!Outlet) _missingMdxReference("Outlet", true, "19:3-19:13");
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)("section", {
      className: "grove-section",
      "data-section": "people",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("header", {
        className: "grove-section__hero",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
          className: "grove-section__eyebrow",
          children: "Meridian people"
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("h2", {
          className: "grad",
          children: "The people directory."
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
          className: "grove-section__lede",
          children: "Every teammate has an entry. This header is shared by every profile — not one of them includes it."
        })]
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)(Outlet, {}), /*#__PURE__*/(0, _jsxRuntime.jsxs)("nav", {
        className: "grove-section__more",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
          className: "grove-section__more-h",
          children: "More people"
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)(ChildPages, {})]
      })]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/content/people/_layout.mdx`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiQ2hpbGRQYWdlcyIsIk91dGxldCIsIl9wcm92aWRlQ29tcG9uZW50cyIsImNvbXBvbmVudHMiLCJfbWlzc2luZ01keFJlZmVyZW5jZSIsImpzeHMiLCJGcmFnbWVudCIsImNoaWxkcmVuIiwiY2xhc3NOYW1lIiwianN4IiwiTURYQ29udGVudCIsIndyYXBwZXIiLCJNRFhMYXlvdXQiLCJfYyIsImlkIiwiY29tcG9uZW50IiwicGxhY2UiLCJFcnJvciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIl9sYXlvdXQubWR4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qQGpzeFJ1bnRpbWUgYXV0b21hdGljKi9cbi8qQGpzeEltcG9ydFNvdXJjZSByZWFjdCovXG4vKlxuQSBTRUNUSU9OIGxheW91dCwgbmVzdGVkIHVuZGVyIHRoZSByb290IHNoZWxsLiBJdCB3cmFwcyBldmVyeSBlbnRyeSBpblxuYGNvbnRlbnQvcGVvcGxlL2Ag4oCUIGVhY2ggcHJvZmlsZSByZW5kZXJzIGF0IGA8T3V0bGV0Lz5gIGJlbG93IHRoZSBzaGFyZWQgaGVybyxcbnNvIG5vIGluZGl2aWR1YWwgYmlvIGhhcyB0byBjYXJyeSB0aGUgc2VjdGlvbiBoZWFkZXIgb3IgdGhlIFwibW9yZSBwZW9wbGVcIiByYWlsLlxuVGhpcyBpcyB0aGUgbmVzdGluZyB0aGUgVVJMIG5ldmVyIHNlZXM6IHRoZSBhZGRyZXNzIGJhciBzdGlsbCBuYW1lcyB0aGUgcHJvZmlsZVxuZmlsZSAoZS5nLiAvY29udGVudC9wZW9wbGUvYWRhLWxvdmVsYWNlLm1keCksIGFuZCB0aGlzIGZyYW1lIGlzIHJlc29sdmVkIGFyb3VuZFxuaXQgYnkgZm9sZGVyIGNvbnZlbnRpb24uIERyb3AgYSBgZnJhbWU6IG5vbmVgIGluIGEgcHJvZmlsZSdzIGZyb250bWF0dGVyIHRvIG9wdFxuaXQgb3V0LlxuKi9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3Qge0NoaWxkUGFnZXMsIE91dGxldH0gPSB7XG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9O1xuICBpZiAoIUNoaWxkUGFnZXMpIF9taXNzaW5nTWR4UmVmZXJlbmNlKFwiQ2hpbGRQYWdlc1wiLCB0cnVlLCBcIjIzOjUtMjM6MTlcIik7XG4gIGlmICghT3V0bGV0KSBfbWlzc2luZ01keFJlZmVyZW5jZShcIk91dGxldFwiLCB0cnVlLCBcIjE5OjMtMTk6MTNcIik7XG4gIHJldHVybiA8Pnt9e1wiXFxuXCJ9PHNlY3Rpb24gY2xhc3NOYW1lPVwiZ3JvdmUtc2VjdGlvblwiIGRhdGEtc2VjdGlvbj1cInBlb3BsZVwiPjxoZWFkZXIgY2xhc3NOYW1lPVwiZ3JvdmUtc2VjdGlvbl9faGVyb1wiPjxwIGNsYXNzTmFtZT1cImdyb3ZlLXNlY3Rpb25fX2V5ZWJyb3dcIj57XCJNZXJpZGlhbiBwZW9wbGVcIn08L3A+PGgyIGNsYXNzTmFtZT1cImdyYWRcIj57XCJUaGUgcGVvcGxlIGRpcmVjdG9yeS5cIn08L2gyPjxwIGNsYXNzTmFtZT1cImdyb3ZlLXNlY3Rpb25fX2xlZGVcIj57XCJFdmVyeSB0ZWFtbWF0ZSBoYXMgYW4gZW50cnkuIFRoaXMgaGVhZGVyIGlzIHNoYXJlZCBieSBldmVyeSBwcm9maWxlIOKAlCBub3Qgb25lIG9mIHRoZW0gaW5jbHVkZXMgaXQuXCJ9PC9wPjwvaGVhZGVyPjxPdXRsZXQgLz48bmF2IGNsYXNzTmFtZT1cImdyb3ZlLXNlY3Rpb25fX21vcmVcIj48cCBjbGFzc05hbWU9XCJncm92ZS1zZWN0aW9uX19tb3JlLWhcIj57XCJNb3JlIHBlb3BsZVwifTwvcD48Q2hpbGRQYWdlcyAvPjwvbmF2Pjwvc2VjdGlvbj48Lz47XG59XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNRFhDb250ZW50KHByb3BzID0ge30pIHtcbiAgY29uc3Qge3dyYXBwZXI6IE1EWExheW91dH0gPSB7XG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9O1xuICByZXR1cm4gTURYTGF5b3V0ID8gPE1EWExheW91dCB7Li4ucHJvcHN9PjxfY3JlYXRlTWR4Q29udGVudCB7Li4ucHJvcHN9IC8+PC9NRFhMYXlvdXQ+IDogX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpO1xufVxuZnVuY3Rpb24gX21pc3NpbmdNZHhSZWZlcmVuY2UoaWQsIGNvbXBvbmVudCwgcGxhY2UpIHtcbiAgdGhyb3cgbmV3IEVycm9yKFwiRXhwZWN0ZWQgXCIgKyAoY29tcG9uZW50ID8gXCJjb21wb25lbnRcIiA6IFwib2JqZWN0XCIpICsgXCIgYFwiICsgaWQgKyBcImAgdG8gYmUgZGVmaW5lZDogeW91IGxpa2VseSBmb3Jnb3QgdG8gaW1wb3J0LCBwYXNzLCBvciBwcm92aWRlIGl0LlwiICsgKHBsYWNlID8gXCJcXG5JdOKAmXMgcmVmZXJlbmNlZCBpbiB5b3VyIGNvZGUgYXQgYFwiICsgcGxhY2UgKyBcImAgaW4gYC9hcHAvY29udGVudC9wZW9wbGUvX2xheW91dC5tZHhgXCIgOiBcIlwiKSk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQVdBLElBQUFBLFlBQUEsR0FBQUMsT0FBQTtBQUF3RixJQUFBQyxXQUFBLEdBQUFELE9BQUE7QUFYeEY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxTQUFTRSxpQkFBaUJBLENBQUNDLEtBQUssRUFBRTtFQUNoQyxNQUFNO0lBQUNDLFVBQVU7SUFBRUM7RUFBTSxDQUFDLEdBQUc7SUFDM0IsR0FBRyxJQUFBQyw2QkFBa0IsRUFBQyxDQUFDO0lBQ3ZCLEdBQUdILEtBQUssQ0FBQ0k7RUFDWCxDQUFDO0VBQ0QsSUFBSSxDQUFDSCxVQUFVLEVBQUVJLG9CQUFvQixDQUFDLFlBQVksRUFBRSxJQUFJLEVBQUUsWUFBWSxDQUFDO0VBQ3ZFLElBQUksQ0FBQ0gsTUFBTSxFQUFFRyxvQkFBb0IsQ0FBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLFlBQVksQ0FBQztFQUMvRCxvQkFBTyxJQUFBUCxXQUFBLENBQUFRLElBQUEsRUFBQVIsV0FBQSxDQUFBUyxRQUFBO0lBQUFDLFFBQUEsR0FBSyxJQUFJLGVBQUMsSUFBQVYsV0FBQSxDQUFBUSxJQUFBO01BQVNHLFNBQVMsRUFBQyxlQUFlO01BQUMsZ0JBQWEsUUFBUTtNQUFBRCxRQUFBLGdCQUFDLElBQUFWLFdBQUEsQ0FBQVEsSUFBQTtRQUFRRyxTQUFTLEVBQUMscUJBQXFCO1FBQUFELFFBQUEsZ0JBQUMsSUFBQVYsV0FBQSxDQUFBWSxHQUFBO1VBQUdELFNBQVMsRUFBQyx3QkFBd0I7VUFBQUQsUUFBQSxFQUFFO1FBQWlCLENBQUksQ0FBQyxtQkFBQVYsV0FBQSxDQUFBWSxHQUFBO1VBQUlELFNBQVMsRUFBQyxNQUFNO1VBQUFELFFBQUEsRUFBRTtRQUF1QixDQUFLLENBQUMsbUJBQUFWLFdBQUEsQ0FBQVksR0FBQTtVQUFHRCxTQUFTLEVBQUMscUJBQXFCO1VBQUFELFFBQUEsRUFBRTtRQUFvRyxDQUFJLENBQUM7TUFBQSxDQUFRLENBQUMsbUJBQUFWLFdBQUEsQ0FBQVksR0FBQSxFQUFDUixNQUFNLElBQUUsQ0FBQyxtQkFBQUosV0FBQSxDQUFBUSxJQUFBO1FBQUtHLFNBQVMsRUFBQyxxQkFBcUI7UUFBQUQsUUFBQSxnQkFBQyxJQUFBVixXQUFBLENBQUFZLEdBQUE7VUFBR0QsU0FBUyxFQUFDLHVCQUF1QjtVQUFBRCxRQUFBLEVBQUU7UUFBYSxDQUFJLENBQUMsbUJBQUFWLFdBQUEsQ0FBQVksR0FBQSxFQUFDVCxVQUFVLElBQUUsQ0FBQztNQUFBLENBQUssQ0FBQztJQUFBLENBQVMsQ0FBQztFQUFBLENBQUUsQ0FBQztBQUNsZ0I7QUFDZSxTQUFTVSxVQUFVQSxDQUFDWCxLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUU7RUFDN0MsTUFBTTtJQUFDWSxPQUFPLEVBQUVDO0VBQVMsQ0FBQyxHQUFHO0lBQzNCLEdBQUcsSUFBQVYsNkJBQWtCLEVBQUMsQ0FBQztJQUN2QixHQUFHSCxLQUFLLENBQUNJO0VBQ1gsQ0FBQztFQUNELE9BQU9TLFNBQVMsZ0JBQUcsSUFBQWYsV0FBQSxDQUFBWSxHQUFBLEVBQUNHLFNBQVM7SUFBQSxHQUFLYixLQUFLO0lBQUFRLFFBQUEsZUFBRSxJQUFBVixXQUFBLENBQUFZLEdBQUEsRUFBQ1gsaUJBQWlCO01BQUEsR0FBS0M7SUFBSyxDQUFHO0VBQUMsQ0FBVyxDQUFDLEdBQUdELGlCQUFpQixDQUFDQyxLQUFLLENBQUM7QUFDbEg7QUFBQ2MsRUFBQSxHQU51QkgsVUFBVTtBQU9sQyxTQUFTTixvQkFBb0JBLENBQUNVLEVBQUUsRUFBRUMsU0FBUyxFQUFFQyxLQUFLLEVBQUU7RUFDbEQsTUFBTSxJQUFJQyxLQUFLLENBQUMsV0FBVyxJQUFJRixTQUFTLEdBQUcsV0FBVyxHQUFHLFFBQVEsQ0FBQyxHQUFHLElBQUksR0FBR0QsRUFBRSxHQUFHLG9FQUFvRSxJQUFJRSxLQUFLLEdBQUcscUNBQXFDLEdBQUdBLEtBQUssR0FBRyx3Q0FBd0MsR0FBRyxFQUFFLENBQUMsQ0FBQztBQUNsUTtBQUFDLElBQUFILEVBQUE7QUFBQUssWUFBQSxDQUFBTCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}