var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      code: "code",
      h2: "h2",
      li: "li",
      p: "p",
      table: "table",
      tbody: "tbody",
      td: "td",
      th: "th",
      thead: "thead",
      tr: "tr",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      Callout,
      HeadingAnchor
    } = _components;
  if (!Callout) _missingMdxReference("Callout", true, "19:1-19:167");
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["What Meridian reimburses, the limits, and the approval path. New hires reach this from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "/content/handbook/onboarding.mdx",
        children: "onboarding"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "limits",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "limits"
      }), "Limits"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Category"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Limit"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Approval"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Meals (travel)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "$75 / day"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "auto"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Lodging"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "$240 / night"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "manager"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Software"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "$500 / yr"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "manager"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Equipment"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "—"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "finance"
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "how-to-file",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "how-to-file"
      }), "How to file"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["Submit within ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "30 days"
        }), " of the expense"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["Attach a receipt for anything over ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "$25"
        })]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: "Tag the project so finance can allocate it"
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(Callout, {
      variant: "warning",
      title: "Out-of-policy spend",
      children: "Anything above the limits needs finance sign-off in advance. Filing after the fact risks a rejection."
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/content/handbook/expenses.mdx`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiY29kZSIsImgyIiwibGkiLCJwIiwidGFibGUiLCJ0Ym9keSIsInRkIiwidGgiLCJ0aGVhZCIsInRyIiwidWwiLCJfcHJvdmlkZUNvbXBvbmVudHMiLCJjb21wb25lbnRzIiwiQ2FsbG91dCIsIkhlYWRpbmdBbmNob3IiLCJfbWlzc2luZ01keFJlZmVyZW5jZSIsImpzeHMiLCJGcmFnbWVudCIsImNoaWxkcmVuIiwianN4IiwiaHJlZiIsImlkIiwidmFyaWFudCIsInRpdGxlIiwiTURYQ29udGVudCIsIndyYXBwZXIiLCJNRFhMYXlvdXQiLCJfYyIsImNvbXBvbmVudCIsInBsYWNlIiwiRXJyb3IiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJleHBlbnNlcy5tZHgiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgYTogXCJhXCIsXG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgaDI6IFwiaDJcIixcbiAgICBsaTogXCJsaVwiLFxuICAgIHA6IFwicFwiLFxuICAgIHRhYmxlOiBcInRhYmxlXCIsXG4gICAgdGJvZHk6IFwidGJvZHlcIixcbiAgICB0ZDogXCJ0ZFwiLFxuICAgIHRoOiBcInRoXCIsXG4gICAgdGhlYWQ6IFwidGhlYWRcIixcbiAgICB0cjogXCJ0clwiLFxuICAgIHVsOiBcInVsXCIsXG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9LCB7Q2FsbG91dCwgSGVhZGluZ0FuY2hvcn0gPSBfY29tcG9uZW50cztcbiAgaWYgKCFDYWxsb3V0KSBfbWlzc2luZ01keFJlZmVyZW5jZShcIkNhbGxvdXRcIiwgdHJ1ZSwgXCIxOToxLTE5OjE2N1wiKTtcbiAgaWYgKCFIZWFkaW5nQW5jaG9yKSBfbWlzc2luZ01keFJlZmVyZW5jZShcIkhlYWRpbmdBbmNob3JcIiwgdHJ1ZSk7XG4gIHJldHVybiA8PjxfY29tcG9uZW50cy5wPntcIldoYXQgTWVyaWRpYW4gcmVpbWJ1cnNlcywgdGhlIGxpbWl0cywgYW5kIHRoZSBhcHByb3ZhbCBwYXRoLiBOZXcgaGlyZXMgcmVhY2ggdGhpcyBmcm9tIFwifTxfY29tcG9uZW50cy5hIGhyZWY9XCIvY29udGVudC9oYW5kYm9vay9vbmJvYXJkaW5nLm1keFwiPntcIm9uYm9hcmRpbmdcIn08L19jb21wb25lbnRzLmE+e1wiLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJsaW1pdHNcIj48SGVhZGluZ0FuY2hvciBpZD1cImxpbWl0c1wiIC8+e1wiTGltaXRzXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMudGFibGU+PF9jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGg+e1wiQ2F0ZWdvcnlcIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aD57XCJMaW1pdFwifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIkFwcHJvdmFsXCJ9PC9fY29tcG9uZW50cy50aD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGhlYWQ+PF9jb21wb25lbnRzLnRib2R5PjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiTWVhbHMgKHRyYXZlbClcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCIkNzUgLyBkYXlcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJhdXRvXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiTG9kZ2luZ1wifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIiQyNDAgLyBuaWdodFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIm1hbmFnZXJcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJTb2Z0d2FyZVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIiQ1MDAgLyB5clwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIm1hbmFnZXJcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJFcXVpcG1lbnRcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCLigJRcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJmaW5hbmNlXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGJvZHk+PC9fY29tcG9uZW50cy50YWJsZT57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJob3ctdG8tZmlsZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiaG93LXRvLWZpbGVcIiAvPntcIkhvdyB0byBmaWxlXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIlN1Ym1pdCB3aXRoaW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiMzAgZGF5c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgb2YgdGhlIGV4cGVuc2VcIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJBdHRhY2ggYSByZWNlaXB0IGZvciBhbnl0aGluZyBvdmVyIFwifTxfY29tcG9uZW50cy5jb2RlPntcIiQyNVwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJUYWcgdGhlIHByb2plY3Qgc28gZmluYW5jZSBjYW4gYWxsb2NhdGUgaXRcIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PENhbGxvdXQgdmFyaWFudD1cIndhcm5pbmdcIiB0aXRsZT1cIk91dC1vZi1wb2xpY3kgc3BlbmRcIj57XCJBbnl0aGluZyBhYm92ZSB0aGUgbGltaXRzIG5lZWRzIGZpbmFuY2Ugc2lnbi1vZmYgaW4gYWR2YW5jZS4gRmlsaW5nIGFmdGVyIHRoZSBmYWN0IHJpc2tzIGEgcmVqZWN0aW9uLlwifTwvQ2FsbG91dD48Lz47XG59XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNRFhDb250ZW50KHByb3BzID0ge30pIHtcbiAgY29uc3Qge3dyYXBwZXI6IE1EWExheW91dH0gPSB7XG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9O1xuICByZXR1cm4gTURYTGF5b3V0ID8gPE1EWExheW91dCB7Li4ucHJvcHN9PjxfY3JlYXRlTWR4Q29udGVudCB7Li4ucHJvcHN9IC8+PC9NRFhMYXlvdXQ+IDogX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpO1xufVxuZnVuY3Rpb24gX21pc3NpbmdNZHhSZWZlcmVuY2UoaWQsIGNvbXBvbmVudCwgcGxhY2UpIHtcbiAgdGhyb3cgbmV3IEVycm9yKFwiRXhwZWN0ZWQgXCIgKyAoY29tcG9uZW50ID8gXCJjb21wb25lbnRcIiA6IFwib2JqZWN0XCIpICsgXCIgYFwiICsgaWQgKyBcImAgdG8gYmUgZGVmaW5lZDogeW91IGxpa2VseSBmb3Jnb3QgdG8gaW1wb3J0LCBwYXNzLCBvciBwcm92aWRlIGl0LlwiICsgKHBsYWNlID8gXCJcXG5JdOKAmXMgcmVmZXJlbmNlZCBpbiB5b3VyIGNvZGUgYXQgYFwiICsgcGxhY2UgKyBcImAgaW4gYC9hcHAvY29udGVudC9oYW5kYm9vay9leHBlbnNlcy5tZHhgXCIgOiBcIlwiKSk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUVBLElBQUFBLFlBQUEsR0FBQUMsT0FBQTtBQUF3RixJQUFBQyxXQUFBLEdBQUFELE9BQUE7QUFGeEY7QUFDQTs7QUFFQSxTQUFTRSxpQkFBaUJBLENBQUNDLEtBQUssRUFBRTtFQUNoQyxNQUFNQyxXQUFXLEdBQUc7TUFDbEJDLENBQUMsRUFBRSxHQUFHO01BQ05DLElBQUksRUFBRSxNQUFNO01BQ1pDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLENBQUMsRUFBRSxHQUFHO01BQ05DLEtBQUssRUFBRSxPQUFPO01BQ2RDLEtBQUssRUFBRSxPQUFPO01BQ2RDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEtBQUssRUFBRSxPQUFPO01BQ2RDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1IsR0FBRyxJQUFBQyw2QkFBa0IsRUFBQyxDQUFDO01BQ3ZCLEdBQUdkLEtBQUssQ0FBQ2U7SUFDWCxDQUFDO0lBQUU7TUFBQ0MsT0FBTztNQUFFQztJQUFhLENBQUMsR0FBR2hCLFdBQVc7RUFDekMsSUFBSSxDQUFDZSxPQUFPLEVBQUVFLG9CQUFvQixDQUFDLFNBQVMsRUFBRSxJQUFJLEVBQUUsYUFBYSxDQUFDO0VBQ2xFLElBQUksQ0FBQ0QsYUFBYSxFQUFFQyxvQkFBb0IsQ0FBQyxlQUFlLEVBQUUsSUFBSSxDQUFDO0VBQy9ELG9CQUFPLElBQUFwQixXQUFBLENBQUFxQixJQUFBLEVBQUFyQixXQUFBLENBQUFzQixRQUFBO0lBQUFDLFFBQUEsZ0JBQUUsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0ssQ0FBQztNQUFBZSxRQUFBLEdBQUUseUZBQXlGLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0MsQ0FBQztRQUFDcUIsSUFBSSxFQUFDLGtDQUFrQztRQUFBRixRQUFBLEVBQUU7TUFBWSxDQUFnQixDQUFDLEVBQUMsR0FBRztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0csRUFBRTtNQUFDb0IsRUFBRSxFQUFDLFFBQVE7TUFBQUgsUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDTCxhQUFhO1FBQUNPLEVBQUUsRUFBQztNQUFRLENBQUUsQ0FBQyxFQUFDLFFBQVE7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNNLEtBQUs7TUFBQWMsUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVSxLQUFLO1FBQUFVLFFBQUEsZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDVyxFQUFFO1VBQUFTLFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1MsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBVSxDQUFpQixDQUFDLG1CQUFBdkIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDUyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFPLENBQWlCLENBQUMsbUJBQUF2QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNTLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQVUsQ0FBaUIsQ0FBQztRQUFBLENBQWdCO01BQUMsQ0FBbUIsQ0FBQyxtQkFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ08sS0FBSztRQUFBYSxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNXLEVBQUU7VUFBQVMsUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDUSxFQUFFO1lBQUFZLFFBQUEsRUFBRTtVQUFnQixDQUFpQixDQUFDLG1CQUFBdkIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDUSxFQUFFO1lBQUFZLFFBQUEsRUFBRTtVQUFXLENBQWlCLENBQUMsbUJBQUF2QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNRLEVBQUU7WUFBQVksUUFBQSxFQUFFO1VBQU0sQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNXLEVBQUU7VUFBQVMsUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDUSxFQUFFO1lBQUFZLFFBQUEsRUFBRTtVQUFTLENBQWlCLENBQUMsbUJBQUF2QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNRLEVBQUU7WUFBQVksUUFBQSxFQUFFO1VBQWMsQ0FBaUIsQ0FBQyxtQkFBQXZCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1EsRUFBRTtZQUFBWSxRQUFBLEVBQUU7VUFBUyxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1csRUFBRTtVQUFBUyxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNRLEVBQUU7WUFBQVksUUFBQSxFQUFFO1VBQVUsQ0FBaUIsQ0FBQyxtQkFBQXZCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1EsRUFBRTtZQUFBWSxRQUFBLEVBQUU7VUFBVyxDQUFpQixDQUFDLG1CQUFBdkIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDUSxFQUFFO1lBQUFZLFFBQUEsRUFBRTtVQUFTLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDVyxFQUFFO1VBQUFTLFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1EsRUFBRTtZQUFBWSxRQUFBLEVBQUU7VUFBVyxDQUFpQixDQUFDLG1CQUFBdkIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDUSxFQUFFO1lBQUFZLFFBQUEsRUFBRTtVQUFHLENBQWlCLENBQUMsbUJBQUF2QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNRLEVBQUU7WUFBQVksUUFBQSxFQUFFO1VBQVMsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUM7TUFBQSxDQUFtQixDQUFDO0lBQUEsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDRyxFQUFFO01BQUNvQixFQUFFLEVBQUMsYUFBYTtNQUFBSCxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF3QixHQUFBLEVBQUNMLGFBQWE7UUFBQ08sRUFBRSxFQUFDO01BQWEsQ0FBRSxDQUFDLEVBQUMsYUFBYTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1ksRUFBRTtNQUFBUSxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNJLEVBQUU7UUFBQWdCLFFBQUEsR0FBRSxnQkFBZ0IsZUFBQyxJQUFBdkIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1VBQUFrQixRQUFBLEVBQUU7UUFBUyxDQUFtQixDQUFDLEVBQUMsaUJBQWlCO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDSSxFQUFFO1FBQUFnQixRQUFBLEdBQUUscUNBQXFDLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBa0IsUUFBQSxFQUFFO1FBQUssQ0FBbUIsQ0FBQztNQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0ksRUFBRTtRQUFBZ0IsUUFBQSxFQUFFO01BQTRDLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDTixPQUFPO01BQUNTLE9BQU8sRUFBQyxTQUFTO01BQUNDLEtBQUssRUFBQyxxQkFBcUI7TUFBQUwsUUFBQSxFQUFFO0lBQXVHLENBQVUsQ0FBQztFQUFBLENBQUUsQ0FBQztBQUMzNEQ7QUFDZSxTQUFTTSxVQUFVQSxDQUFDM0IsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFO0VBQzdDLE1BQU07SUFBQzRCLE9BQU8sRUFBRUM7RUFBUyxDQUFDLEdBQUc7SUFDM0IsR0FBRyxJQUFBZiw2QkFBa0IsRUFBQyxDQUFDO0lBQ3ZCLEdBQUdkLEtBQUssQ0FBQ2U7RUFDWCxDQUFDO0VBQ0QsT0FBT2MsU0FBUyxnQkFBRyxJQUFBL0IsV0FBQSxDQUFBd0IsR0FBQSxFQUFDTyxTQUFTO0lBQUEsR0FBSzdCLEtBQUs7SUFBQXFCLFFBQUEsZUFBRSxJQUFBdkIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDdkIsaUJBQWlCO01BQUEsR0FBS0M7SUFBSyxDQUFHO0VBQUMsQ0FBVyxDQUFDLEdBQUdELGlCQUFpQixDQUFDQyxLQUFLLENBQUM7QUFDbEg7QUFBQzhCLEVBQUEsR0FOdUJILFVBQVU7QUFPbEMsU0FBU1Qsb0JBQW9CQSxDQUFDTSxFQUFFLEVBQUVPLFNBQVMsRUFBRUMsS0FBSyxFQUFFO0VBQ2xELE1BQU0sSUFBSUMsS0FBSyxDQUFDLFdBQVcsSUFBSUYsU0FBUyxHQUFHLFdBQVcsR0FBRyxRQUFRLENBQUMsR0FBRyxJQUFJLEdBQUdQLEVBQUUsR0FBRyxvRUFBb0UsSUFBSVEsS0FBSyxHQUFHLHFDQUFxQyxHQUFHQSxLQUFLLEdBQUcsMkNBQTJDLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDclE7QUFBQyxJQUFBRixFQUFBO0FBQUFJLFlBQUEsQ0FBQUosRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}