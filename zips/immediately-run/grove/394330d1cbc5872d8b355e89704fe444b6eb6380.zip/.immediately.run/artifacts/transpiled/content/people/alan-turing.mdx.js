var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
    a: "a",
    code: "code",
    p: "p",
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
    children: ["Alan Turing is platform engineer on the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
      href: "/content/teams/engineering.mdx",
      children: "engineering"
    }), " team. Reach them at ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
      children: "x2208"
    }), "."]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiY29kZSIsInAiLCJfcHJvdmlkZUNvbXBvbmVudHMiLCJjb21wb25lbnRzIiwianN4cyIsImNoaWxkcmVuIiwianN4IiwiaHJlZiIsIk1EWENvbnRlbnQiLCJ3cmFwcGVyIiwiTURYTGF5b3V0IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJhbGFuLXR1cmluZy5tZHgiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgYTogXCJhXCIsXG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgcDogXCJwXCIsXG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9O1xuICByZXR1cm4gPF9jb21wb25lbnRzLnA+e1wiQWxhbiBUdXJpbmcgaXMgcGxhdGZvcm0gZW5naW5lZXIgb24gdGhlIFwifTxfY29tcG9uZW50cy5hIGhyZWY9XCIvY29udGVudC90ZWFtcy9lbmdpbmVlcmluZy5tZHhcIj57XCJlbmdpbmVlcmluZ1wifTwvX2NvbXBvbmVudHMuYT57XCIgdGVhbS4gUmVhY2ggdGhlbSBhdCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ4MjIwOFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuXCJ9PC9fY29tcG9uZW50cy5wPjtcbn1cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE1EWENvbnRlbnQocHJvcHMgPSB7fSkge1xuICBjb25zdCB7d3JhcHBlcjogTURYTGF5b3V0fSA9IHtcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH07XG4gIHJldHVybiBNRFhMYXlvdXQgPyA8TURYTGF5b3V0IHsuLi5wcm9wc30+PF9jcmVhdGVNZHhDb250ZW50IHsuLi5wcm9wc30gLz48L01EWExheW91dD4gOiBfY3JlYXRlTWR4Q29udGVudChwcm9wcyk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUVBLElBQUFBLFlBQUEsR0FBQUMsT0FBQTtBQUF3RixJQUFBQyxXQUFBLEdBQUFELE9BQUE7QUFGeEY7QUFDQTs7QUFFQSxTQUFTRSxpQkFBaUJBLENBQUNDLEtBQUssRUFBRTtFQUNoQyxNQUFNQyxXQUFXLEdBQUc7SUFDbEJDLENBQUMsRUFBRSxHQUFHO0lBQ05DLElBQUksRUFBRSxNQUFNO0lBQ1pDLENBQUMsRUFBRSxHQUFHO0lBQ04sR0FBRyxJQUFBQyw2QkFBa0IsRUFBQyxDQUFDO0lBQ3ZCLEdBQUdMLEtBQUssQ0FBQ007RUFDWCxDQUFDO0VBQ0Qsb0JBQU8sSUFBQVIsV0FBQSxDQUFBUyxJQUFBLEVBQUNOLFdBQVcsQ0FBQ0csQ0FBQztJQUFBSSxRQUFBLEdBQUUsMENBQTBDLGVBQUMsSUFBQVYsV0FBQSxDQUFBVyxHQUFBLEVBQUNSLFdBQVcsQ0FBQ0MsQ0FBQztNQUFDUSxJQUFJLEVBQUMsZ0NBQWdDO01BQUFGLFFBQUEsRUFBRTtJQUFhLENBQWdCLENBQUMsRUFBQyx1QkFBdUIsZUFBQyxJQUFBVixXQUFBLENBQUFXLEdBQUEsRUFBQ1IsV0FBVyxDQUFDRSxJQUFJO01BQUFLLFFBQUEsRUFBRTtJQUFPLENBQW1CLENBQUMsRUFBQyxHQUFHO0VBQUEsQ0FBZ0IsQ0FBQztBQUNwUDtBQUNlLFNBQVNHLFVBQVVBLENBQUNYLEtBQUssR0FBRyxDQUFDLENBQUMsRUFBRTtFQUM3QyxNQUFNO0lBQUNZLE9BQU8sRUFBRUM7RUFBUyxDQUFDLEdBQUc7SUFDM0IsR0FBRyxJQUFBUiw2QkFBa0IsRUFBQyxDQUFDO0lBQ3ZCLEdBQUdMLEtBQUssQ0FBQ007RUFDWCxDQUFDO0VBQ0QsT0FBT08sU0FBUyxnQkFBRyxJQUFBZixXQUFBLENBQUFXLEdBQUEsRUFBQ0ksU0FBUztJQUFBLEdBQUtiLEtBQUs7SUFBQVEsUUFBQSxlQUFFLElBQUFWLFdBQUEsQ0FBQVcsR0FBQSxFQUFDVixpQkFBaUI7TUFBQSxHQUFLQztJQUFLLENBQUc7RUFBQyxDQUFXLENBQUMsR0FBR0QsaUJBQWlCLENBQUNDLEtBQUssQ0FBQztBQUNsSDtBQUFDYyxFQUFBLEdBTnVCSCxVQUFVO0FBQUEsSUFBQUcsRUFBQTtBQUFBQyxZQUFBLENBQUFELEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}