var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      code: "code",
      h2: "h2",
      h3: "h3",
      li: "li",
      p: "p",
      table: "table",
      tbody: "tbody",
      td: "td",
      th: "th",
      thead: "thead",
      tr: "tr",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      Callout,
      HeadingAnchor
    } = _components;
  if (!Callout) _missingMdxReference("Callout", true, "4:1-4:172");
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Welcome to Meridian. This entry is the canonical first-week checklist. It links out to the policies and people you will need — follow the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "/content/handbook/expenses.mdx",
        children: "expense policy"
      }), " before your first trip, and find your team in the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "/content/directory.mdx",
        children: "phone book"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(Callout, {
      variant: "tip",
      title: "Start here",
      children: "Your manager will have tagged the entries relevant to your team. Open the sidebar and look under your team's namespace."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "day-one",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "day-one"
      }), "Day one"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Collect your laptop from IT, sign the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "/content/handbook/security.mdx",
        children: "security policy"
      }), ", and set up your accounts. If a link looks dim and dotted — like ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "/content/travel-policy.mdx",
        children: "travel-policy"
      }), " — that entry doesn't exist yet; ask Grove to create it."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: "Pick up hardware and badge"
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["Read and acknowledge ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "/content/handbook/security.mdx",
          children: "the security policy"
        })]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["Add yourself to the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "/content/directory.mdx",
          children: "directory"
        }), " with your ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "role"
        }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "phone"
        })]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "week-one",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "week-one"
      }), "Week one"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Shadow an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "/content/teams/engineering.mdx",
        children: "engineering"
      }), " standup, file your first expense, and read the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "/content/processes/incident-response.mdx",
        children: "incident-response runbook"
      }), ". The runbook matters even if you are not on-call."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "filing-your-first-expense",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "filing-your-first-expense"
      }), "Filing your first expense"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Expenses are submitted through the portal. The categories and limits live in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "/content/handbook/expenses.mdx",
        children: "the expense policy"
      }), "; a quick reference:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Category"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Limit"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Approval"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Meals (travel)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "$75 / day"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "auto"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Lodging"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "$240 / night"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "manager"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Software"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "$500 / yr"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "manager"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Equipment"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "—"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "finance"
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "conventions",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "conventions"
      }), "Conventions"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["This wiki follows a few rules so agents and people read it the same way. Tags drive the menus; frontmatter drives ordering. See ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "/content/about.mdx",
        children: "about this wiki"
      }), " for the full colophon."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(Callout, {
      variant: "note",
      title: "A note on editing",
      children: "You rarely edit MDX by hand here. Ask Grove (\"add my desk phone to the directory\") and it writes the frontmatter for you."
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/content/handbook/onboarding.mdx`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiY29kZSIsImgyIiwiaDMiLCJsaSIsInAiLCJ0YWJsZSIsInRib2R5IiwidGQiLCJ0aCIsInRoZWFkIiwidHIiLCJ1bCIsIl9wcm92aWRlQ29tcG9uZW50cyIsImNvbXBvbmVudHMiLCJDYWxsb3V0IiwiSGVhZGluZ0FuY2hvciIsIl9taXNzaW5nTWR4UmVmZXJlbmNlIiwianN4cyIsIkZyYWdtZW50IiwiY2hpbGRyZW4iLCJqc3giLCJocmVmIiwidmFyaWFudCIsInRpdGxlIiwiaWQiLCJNRFhDb250ZW50Iiwid3JhcHBlciIsIk1EWExheW91dCIsIl9jIiwiY29tcG9uZW50IiwicGxhY2UiLCJFcnJvciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIm9uYm9hcmRpbmcubWR4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qQGpzeFJ1bnRpbWUgYXV0b21hdGljKi9cbi8qQGpzeEltcG9ydFNvdXJjZSByZWFjdCovXG5pbXBvcnQge3VzZU1EWENvbXBvbmVudHMgYXMgX3Byb3ZpZGVDb21wb25lbnRzfSBmcm9tIFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGsvTURYUHJvdmlkZXJcIjtcbmZ1bmN0aW9uIF9jcmVhdGVNZHhDb250ZW50KHByb3BzKSB7XG4gIGNvbnN0IF9jb21wb25lbnRzID0ge1xuICAgIGE6IFwiYVwiLFxuICAgIGNvZGU6IFwiY29kZVwiLFxuICAgIGgyOiBcImgyXCIsXG4gICAgaDM6IFwiaDNcIixcbiAgICBsaTogXCJsaVwiLFxuICAgIHA6IFwicFwiLFxuICAgIHRhYmxlOiBcInRhYmxlXCIsXG4gICAgdGJvZHk6IFwidGJvZHlcIixcbiAgICB0ZDogXCJ0ZFwiLFxuICAgIHRoOiBcInRoXCIsXG4gICAgdGhlYWQ6IFwidGhlYWRcIixcbiAgICB0cjogXCJ0clwiLFxuICAgIHVsOiBcInVsXCIsXG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9LCB7Q2FsbG91dCwgSGVhZGluZ0FuY2hvcn0gPSBfY29tcG9uZW50cztcbiAgaWYgKCFDYWxsb3V0KSBfbWlzc2luZ01keFJlZmVyZW5jZShcIkNhbGxvdXRcIiwgdHJ1ZSwgXCI0OjEtNDoxNzJcIik7XG4gIGlmICghSGVhZGluZ0FuY2hvcikgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJIZWFkaW5nQW5jaG9yXCIsIHRydWUpO1xuICByZXR1cm4gPD48X2NvbXBvbmVudHMucD57XCJXZWxjb21lIHRvIE1lcmlkaWFuLiBUaGlzIGVudHJ5IGlzIHRoZSBjYW5vbmljYWwgZmlyc3Qtd2VlayBjaGVja2xpc3QuIEl0IGxpbmtzIG91dCB0byB0aGUgcG9saWNpZXMgYW5kIHBlb3BsZSB5b3Ugd2lsbCBuZWVkIOKAlCBmb2xsb3cgdGhlIFwifTxfY29tcG9uZW50cy5hIGhyZWY9XCIvY29udGVudC9oYW5kYm9vay9leHBlbnNlcy5tZHhcIj57XCJleHBlbnNlIHBvbGljeVwifTwvX2NvbXBvbmVudHMuYT57XCIgYmVmb3JlIHlvdXIgZmlyc3QgdHJpcCwgYW5kIGZpbmQgeW91ciB0ZWFtIGluIHRoZSBcIn08X2NvbXBvbmVudHMuYSBocmVmPVwiL2NvbnRlbnQvZGlyZWN0b3J5Lm1keFwiPntcInBob25lIGJvb2tcIn08L19jb21wb25lbnRzLmE+e1wiLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08Q2FsbG91dCB2YXJpYW50PVwidGlwXCIgdGl0bGU9XCJTdGFydCBoZXJlXCI+e1wiWW91ciBtYW5hZ2VyIHdpbGwgaGF2ZSB0YWdnZWQgdGhlIGVudHJpZXMgcmVsZXZhbnQgdG8geW91ciB0ZWFtLiBPcGVuIHRoZSBzaWRlYmFyIGFuZCBsb29rIHVuZGVyIHlvdXIgdGVhbSdzIG5hbWVzcGFjZS5cIn08L0NhbGxvdXQ+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwiZGF5LW9uZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiZGF5LW9uZVwiIC8+e1wiRGF5IG9uZVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiQ29sbGVjdCB5b3VyIGxhcHRvcCBmcm9tIElULCBzaWduIHRoZSBcIn08X2NvbXBvbmVudHMuYSBocmVmPVwiL2NvbnRlbnQvaGFuZGJvb2svc2VjdXJpdHkubWR4XCI+e1wic2VjdXJpdHkgcG9saWN5XCJ9PC9fY29tcG9uZW50cy5hPntcIiwgYW5kIHNldCB1cCB5b3VyIGFjY291bnRzLiBJZiBhIGxpbmsgbG9va3MgZGltIGFuZCBkb3R0ZWQg4oCUIGxpa2UgXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cIi9jb250ZW50L3RyYXZlbC1wb2xpY3kubWR4XCI+e1widHJhdmVsLXBvbGljeVwifTwvX2NvbXBvbmVudHMuYT57XCIg4oCUIHRoYXQgZW50cnkgZG9lc24ndCBleGlzdCB5ZXQ7IGFzayBHcm92ZSB0byBjcmVhdGUgaXQuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiUGljayB1cCBoYXJkd2FyZSBhbmQgYmFkZ2VcIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJSZWFkIGFuZCBhY2tub3dsZWRnZSBcIn08X2NvbXBvbmVudHMuYSBocmVmPVwiL2NvbnRlbnQvaGFuZGJvb2svc2VjdXJpdHkubWR4XCI+e1widGhlIHNlY3VyaXR5IHBvbGljeVwifTwvX2NvbXBvbmVudHMuYT48L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJBZGQgeW91cnNlbGYgdG8gdGhlIFwifTxfY29tcG9uZW50cy5hIGhyZWY9XCIvY29udGVudC9kaXJlY3RvcnkubWR4XCI+e1wiZGlyZWN0b3J5XCJ9PC9fY29tcG9uZW50cy5hPntcIiB3aXRoIHlvdXIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicm9sZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYW5kIFwifTxfY29tcG9uZW50cy5jb2RlPntcInBob25lXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJ3ZWVrLW9uZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwid2Vlay1vbmVcIiAvPntcIldlZWsgb25lXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJTaGFkb3cgYW4gXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cIi9jb250ZW50L3RlYW1zL2VuZ2luZWVyaW5nLm1keFwiPntcImVuZ2luZWVyaW5nXCJ9PC9fY29tcG9uZW50cy5hPntcIiBzdGFuZHVwLCBmaWxlIHlvdXIgZmlyc3QgZXhwZW5zZSwgYW5kIHJlYWQgdGhlIFwifTxfY29tcG9uZW50cy5hIGhyZWY9XCIvY29udGVudC9wcm9jZXNzZXMvaW5jaWRlbnQtcmVzcG9uc2UubWR4XCI+e1wiaW5jaWRlbnQtcmVzcG9uc2UgcnVuYm9va1wifTwvX2NvbXBvbmVudHMuYT57XCIuIFRoZSBydW5ib29rIG1hdHRlcnMgZXZlbiBpZiB5b3UgYXJlIG5vdCBvbi1jYWxsLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCJmaWxpbmcteW91ci1maXJzdC1leHBlbnNlXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJmaWxpbmcteW91ci1maXJzdC1leHBlbnNlXCIgLz57XCJGaWxpbmcgeW91ciBmaXJzdCBleHBlbnNlXCJ9PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJFeHBlbnNlcyBhcmUgc3VibWl0dGVkIHRocm91Z2ggdGhlIHBvcnRhbC4gVGhlIGNhdGVnb3JpZXMgYW5kIGxpbWl0cyBsaXZlIGluIFwifTxfY29tcG9uZW50cy5hIGhyZWY9XCIvY29udGVudC9oYW5kYm9vay9leHBlbnNlcy5tZHhcIj57XCJ0aGUgZXhwZW5zZSBwb2xpY3lcIn08L19jb21wb25lbnRzLmE+e1wiOyBhIHF1aWNrIHJlZmVyZW5jZTpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnRhYmxlPjxfY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRoPntcIkNhdGVnb3J5XCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGg+e1wiTGltaXRcIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aD57XCJBcHByb3ZhbFwifTwvX2NvbXBvbmVudHMudGg+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50Ym9keT48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIk1lYWxzICh0cmF2ZWwpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiJDc1IC8gZGF5XCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiYXV0b1wifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkxvZGdpbmdcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCIkMjQwIC8gbmlnaHRcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJtYW5hZ2VyXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiU29mdHdhcmVcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCIkNTAwIC8geXJcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJtYW5hZ2VyXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiRXF1aXBtZW50XCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wi4oCUXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiZmluYW5jZVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRib2R5PjwvX2NvbXBvbmVudHMudGFibGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwiY29udmVudGlvbnNcIj48SGVhZGluZ0FuY2hvciBpZD1cImNvbnZlbnRpb25zXCIgLz57XCJDb252ZW50aW9uc1wifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhpcyB3aWtpIGZvbGxvd3MgYSBmZXcgcnVsZXMgc28gYWdlbnRzIGFuZCBwZW9wbGUgcmVhZCBpdCB0aGUgc2FtZSB3YXkuIFRhZ3MgZHJpdmUgdGhlIG1lbnVzOyBmcm9udG1hdHRlciBkcml2ZXMgb3JkZXJpbmcuIFNlZSBcIn08X2NvbXBvbmVudHMuYSBocmVmPVwiL2NvbnRlbnQvYWJvdXQubWR4XCI+e1wiYWJvdXQgdGhpcyB3aWtpXCJ9PC9fY29tcG9uZW50cy5hPntcIiBmb3IgdGhlIGZ1bGwgY29sb3Bob24uXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxDYWxsb3V0IHZhcmlhbnQ9XCJub3RlXCIgdGl0bGU9XCJBIG5vdGUgb24gZWRpdGluZ1wiPntcIllvdSByYXJlbHkgZWRpdCBNRFggYnkgaGFuZCBoZXJlLiBBc2sgR3JvdmUgKFxcXCJhZGQgbXkgZGVzayBwaG9uZSB0byB0aGUgZGlyZWN0b3J5XFxcIikgYW5kIGl0IHdyaXRlcyB0aGUgZnJvbnRtYXR0ZXIgZm9yIHlvdS5cIn08L0NhbGxvdXQ+PC8+O1xufVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTURYQ29udGVudChwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHt3cmFwcGVyOiBNRFhMYXlvdXR9ID0ge1xuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfTtcbiAgcmV0dXJuIE1EWExheW91dCA/IDxNRFhMYXlvdXQgey4uLnByb3BzfT48X2NyZWF0ZU1keENvbnRlbnQgey4uLnByb3BzfSAvPjwvTURYTGF5b3V0PiA6IF9jcmVhdGVNZHhDb250ZW50KHByb3BzKTtcbn1cbmZ1bmN0aW9uIF9taXNzaW5nTWR4UmVmZXJlbmNlKGlkLCBjb21wb25lbnQsIHBsYWNlKSB7XG4gIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIFwiICsgKGNvbXBvbmVudCA/IFwiY29tcG9uZW50XCIgOiBcIm9iamVjdFwiKSArIFwiIGBcIiArIGlkICsgXCJgIHRvIGJlIGRlZmluZWQ6IHlvdSBsaWtlbHkgZm9yZ290IHRvIGltcG9ydCwgcGFzcywgb3IgcHJvdmlkZSBpdC5cIiArIChwbGFjZSA/IFwiXFxuSXTigJlzIHJlZmVyZW5jZWQgaW4geW91ciBjb2RlIGF0IGBcIiArIHBsYWNlICsgXCJgIGluIGAvYXBwL2NvbnRlbnQvaGFuZGJvb2svb25ib2FyZGluZy5tZHhgXCIgOiBcIlwiKSk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUVBLElBQUFBLFlBQUEsR0FBQUMsT0FBQTtBQUF3RixJQUFBQyxXQUFBLEdBQUFELE9BQUE7QUFGeEY7QUFDQTs7QUFFQSxTQUFTRSxpQkFBaUJBLENBQUNDLEtBQUssRUFBRTtFQUNoQyxNQUFNQyxXQUFXLEdBQUc7TUFDbEJDLENBQUMsRUFBRSxHQUFHO01BQ05DLElBQUksRUFBRSxNQUFNO01BQ1pDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLENBQUMsRUFBRSxHQUFHO01BQ05DLEtBQUssRUFBRSxPQUFPO01BQ2RDLEtBQUssRUFBRSxPQUFPO01BQ2RDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEtBQUssRUFBRSxPQUFPO01BQ2RDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1IsR0FBRyxJQUFBQyw2QkFBa0IsRUFBQyxDQUFDO01BQ3ZCLEdBQUdmLEtBQUssQ0FBQ2dCO0lBQ1gsQ0FBQztJQUFFO01BQUNDLE9BQU87TUFBRUM7SUFBYSxDQUFDLEdBQUdqQixXQUFXO0VBQ3pDLElBQUksQ0FBQ2dCLE9BQU8sRUFBRUUsb0JBQW9CLENBQUMsU0FBUyxFQUFFLElBQUksRUFBRSxXQUFXLENBQUM7RUFDaEUsSUFBSSxDQUFDRCxhQUFhLEVBQUVDLG9CQUFvQixDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUM7RUFDL0Qsb0JBQU8sSUFBQXJCLFdBQUEsQ0FBQXNCLElBQUEsRUFBQXRCLFdBQUEsQ0FBQXVCLFFBQUE7SUFBQUMsUUFBQSxnQkFBRSxJQUFBeEIsV0FBQSxDQUFBc0IsSUFBQSxFQUFDbkIsV0FBVyxDQUFDTSxDQUFDO01BQUFlLFFBQUEsR0FBRSw0SUFBNEksZUFBQyxJQUFBeEIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDQyxDQUFDO1FBQUNzQixJQUFJLEVBQUMsZ0NBQWdDO1FBQUFGLFFBQUEsRUFBRTtNQUFnQixDQUFnQixDQUFDLEVBQUMscURBQXFELGVBQUMsSUFBQXhCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0MsQ0FBQztRQUFDc0IsSUFBSSxFQUFDLHdCQUF3QjtRQUFBRixRQUFBLEVBQUU7TUFBWSxDQUFnQixDQUFDLEVBQUMsR0FBRztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ04sT0FBTztNQUFDUSxPQUFPLEVBQUMsS0FBSztNQUFDQyxLQUFLLEVBQUMsWUFBWTtNQUFBSixRQUFBLEVBQUU7SUFBeUgsQ0FBVSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF4QixXQUFBLENBQUFzQixJQUFBLEVBQUNuQixXQUFXLENBQUNHLEVBQUU7TUFBQ3VCLEVBQUUsRUFBQyxTQUFTO01BQUFMLFFBQUEsZ0JBQUMsSUFBQXhCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ0wsYUFBYTtRQUFDUyxFQUFFLEVBQUM7TUFBUyxDQUFFLENBQUMsRUFBQyxTQUFTO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBc0IsSUFBQSxFQUFDbkIsV0FBVyxDQUFDTSxDQUFDO01BQUFlLFFBQUEsR0FBRSx3Q0FBd0MsZUFBQyxJQUFBeEIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDQyxDQUFDO1FBQUNzQixJQUFJLEVBQUMsZ0NBQWdDO1FBQUFGLFFBQUEsRUFBRTtNQUFpQixDQUFnQixDQUFDLEVBQUMsb0VBQW9FLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0MsQ0FBQztRQUFDc0IsSUFBSSxFQUFDLDRCQUE0QjtRQUFBRixRQUFBLEVBQUU7TUFBZSxDQUFnQixDQUFDLEVBQUMsMERBQTBEO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBeEIsV0FBQSxDQUFBc0IsSUFBQSxFQUFDbkIsV0FBVyxDQUFDYSxFQUFFO01BQUFRLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0ssRUFBRTtRQUFBZ0IsUUFBQSxFQUFFO01BQTRCLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQXNCLElBQUEsRUFBQ25CLFdBQVcsQ0FBQ0ssRUFBRTtRQUFBZ0IsUUFBQSxHQUFFLHVCQUF1QixlQUFDLElBQUF4QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNDLENBQUM7VUFBQ3NCLElBQUksRUFBQyxnQ0FBZ0M7VUFBQUYsUUFBQSxFQUFFO1FBQXFCLENBQWdCLENBQUM7TUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF4QixXQUFBLENBQUFzQixJQUFBLEVBQUNuQixXQUFXLENBQUNLLEVBQUU7UUFBQWdCLFFBQUEsR0FBRSxzQkFBc0IsZUFBQyxJQUFBeEIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDQyxDQUFDO1VBQUNzQixJQUFJLEVBQUMsd0JBQXdCO1VBQUFGLFFBQUEsRUFBRTtRQUFXLENBQWdCLENBQUMsRUFBQyxhQUFhLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBbUIsUUFBQSxFQUFFO1FBQU0sQ0FBbUIsQ0FBQyxFQUFDLE9BQU8sZUFBQyxJQUFBeEIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFtQixRQUFBLEVBQUU7UUFBTyxDQUFtQixDQUFDO01BQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF4QixXQUFBLENBQUFzQixJQUFBLEVBQUNuQixXQUFXLENBQUNHLEVBQUU7TUFBQ3VCLEVBQUUsRUFBQyxVQUFVO01BQUFMLFFBQUEsZ0JBQUMsSUFBQXhCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ0wsYUFBYTtRQUFDUyxFQUFFLEVBQUM7TUFBVSxDQUFFLENBQUMsRUFBQyxVQUFVO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBc0IsSUFBQSxFQUFDbkIsV0FBVyxDQUFDTSxDQUFDO01BQUFlLFFBQUEsR0FBRSxZQUFZLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0MsQ0FBQztRQUFDc0IsSUFBSSxFQUFDLGdDQUFnQztRQUFBRixRQUFBLEVBQUU7TUFBYSxDQUFnQixDQUFDLEVBQUMsa0RBQWtELGVBQUMsSUFBQXhCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0MsQ0FBQztRQUFDc0IsSUFBSSxFQUFDLDBDQUEwQztRQUFBRixRQUFBLEVBQUU7TUFBMkIsQ0FBZ0IsQ0FBQyxFQUFDLG9EQUFvRDtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQXNCLElBQUEsRUFBQ25CLFdBQVcsQ0FBQ0ksRUFBRTtNQUFDc0IsRUFBRSxFQUFDLDJCQUEyQjtNQUFBTCxRQUFBLGdCQUFDLElBQUF4QixXQUFBLENBQUF5QixHQUFBLEVBQUNMLGFBQWE7UUFBQ1MsRUFBRSxFQUFDO01BQTJCLENBQUUsQ0FBQyxFQUFDLDJCQUEyQjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQXNCLElBQUEsRUFBQ25CLFdBQVcsQ0FBQ00sQ0FBQztNQUFBZSxRQUFBLEdBQUUsK0VBQStFLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0MsQ0FBQztRQUFDc0IsSUFBSSxFQUFDLGdDQUFnQztRQUFBRixRQUFBLEVBQUU7TUFBb0IsQ0FBZ0IsQ0FBQyxFQUFDLHNCQUFzQjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQXNCLElBQUEsRUFBQ25CLFdBQVcsQ0FBQ08sS0FBSztNQUFBYyxRQUFBLGdCQUFDLElBQUF4QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNXLEtBQUs7UUFBQVUsUUFBQSxlQUFDLElBQUF4QixXQUFBLENBQUFzQixJQUFBLEVBQUNuQixXQUFXLENBQUNZLEVBQUU7VUFBQVMsUUFBQSxnQkFBQyxJQUFBeEIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDVSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFVLENBQWlCLENBQUMsbUJBQUF4QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNVLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQU8sQ0FBaUIsQ0FBQyxtQkFBQXhCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBVSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0I7TUFBQyxDQUFtQixDQUFDLG1CQUFBeEIsV0FBQSxDQUFBc0IsSUFBQSxFQUFDbkIsV0FBVyxDQUFDUSxLQUFLO1FBQUFhLFFBQUEsZ0JBQUMsSUFBQXhCLFdBQUEsQ0FBQXNCLElBQUEsRUFBQ25CLFdBQVcsQ0FBQ1ksRUFBRTtVQUFBUyxRQUFBLGdCQUFDLElBQUF4QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNTLEVBQUU7WUFBQVksUUFBQSxFQUFFO1VBQWdCLENBQWlCLENBQUMsbUJBQUF4QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNTLEVBQUU7WUFBQVksUUFBQSxFQUFFO1VBQVcsQ0FBaUIsQ0FBQyxtQkFBQXhCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1MsRUFBRTtZQUFBWSxRQUFBLEVBQUU7VUFBTSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQXhCLFdBQUEsQ0FBQXNCLElBQUEsRUFBQ25CLFdBQVcsQ0FBQ1ksRUFBRTtVQUFBUyxRQUFBLGdCQUFDLElBQUF4QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNTLEVBQUU7WUFBQVksUUFBQSxFQUFFO1VBQVMsQ0FBaUIsQ0FBQyxtQkFBQXhCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1MsRUFBRTtZQUFBWSxRQUFBLEVBQUU7VUFBYyxDQUFpQixDQUFDLG1CQUFBeEIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDUyxFQUFFO1lBQUFZLFFBQUEsRUFBRTtVQUFTLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBeEIsV0FBQSxDQUFBc0IsSUFBQSxFQUFDbkIsV0FBVyxDQUFDWSxFQUFFO1VBQUFTLFFBQUEsZ0JBQUMsSUFBQXhCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1MsRUFBRTtZQUFBWSxRQUFBLEVBQUU7VUFBVSxDQUFpQixDQUFDLG1CQUFBeEIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDUyxFQUFFO1lBQUFZLFFBQUEsRUFBRTtVQUFXLENBQWlCLENBQUMsbUJBQUF4QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNTLEVBQUU7WUFBQVksUUFBQSxFQUFFO1VBQVMsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUF4QixXQUFBLENBQUFzQixJQUFBLEVBQUNuQixXQUFXLENBQUNZLEVBQUU7VUFBQVMsUUFBQSxnQkFBQyxJQUFBeEIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDUyxFQUFFO1lBQUFZLFFBQUEsRUFBRTtVQUFXLENBQWlCLENBQUMsbUJBQUF4QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNTLEVBQUU7WUFBQVksUUFBQSxFQUFFO1VBQUcsQ0FBaUIsQ0FBQyxtQkFBQXhCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1MsRUFBRTtZQUFBWSxRQUFBLEVBQUU7VUFBUyxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQztNQUFBLENBQW1CLENBQUM7SUFBQSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF4QixXQUFBLENBQUFzQixJQUFBLEVBQUNuQixXQUFXLENBQUNHLEVBQUU7TUFBQ3VCLEVBQUUsRUFBQyxhQUFhO01BQUFMLFFBQUEsZ0JBQUMsSUFBQXhCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ0wsYUFBYTtRQUFDUyxFQUFFLEVBQUM7TUFBYSxDQUFFLENBQUMsRUFBQyxhQUFhO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBc0IsSUFBQSxFQUFDbkIsV0FBVyxDQUFDTSxDQUFDO01BQUFlLFFBQUEsR0FBRSxrSUFBa0ksZUFBQyxJQUFBeEIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDQyxDQUFDO1FBQUNzQixJQUFJLEVBQUMsb0JBQW9CO1FBQUFGLFFBQUEsRUFBRTtNQUFpQixDQUFnQixDQUFDLEVBQUMseUJBQXlCO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBeEIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDTixPQUFPO01BQUNRLE9BQU8sRUFBQyxNQUFNO01BQUNDLEtBQUssRUFBQyxtQkFBbUI7TUFBQUosUUFBQSxFQUFFO0lBQTZILENBQVUsQ0FBQztFQUFBLENBQUUsQ0FBQztBQUNqMkg7QUFDZSxTQUFTTSxVQUFVQSxDQUFDNUIsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFO0VBQzdDLE1BQU07SUFBQzZCLE9BQU8sRUFBRUM7RUFBUyxDQUFDLEdBQUc7SUFDM0IsR0FBRyxJQUFBZiw2QkFBa0IsRUFBQyxDQUFDO0lBQ3ZCLEdBQUdmLEtBQUssQ0FBQ2dCO0VBQ1gsQ0FBQztFQUNELE9BQU9jLFNBQVMsZ0JBQUcsSUFBQWhDLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ08sU0FBUztJQUFBLEdBQUs5QixLQUFLO0lBQUFzQixRQUFBLGVBQUUsSUFBQXhCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3hCLGlCQUFpQjtNQUFBLEdBQUtDO0lBQUssQ0FBRztFQUFDLENBQVcsQ0FBQyxHQUFHRCxpQkFBaUIsQ0FBQ0MsS0FBSyxDQUFDO0FBQ2xIO0FBQUMrQixFQUFBLEdBTnVCSCxVQUFVO0FBT2xDLFNBQVNULG9CQUFvQkEsQ0FBQ1EsRUFBRSxFQUFFSyxTQUFTLEVBQUVDLEtBQUssRUFBRTtFQUNsRCxNQUFNLElBQUlDLEtBQUssQ0FBQyxXQUFXLElBQUlGLFNBQVMsR0FBRyxXQUFXLEdBQUcsUUFBUSxDQUFDLEdBQUcsSUFBSSxHQUFHTCxFQUFFLEdBQUcsb0VBQW9FLElBQUlNLEtBQUssR0FBRyxxQ0FBcUMsR0FBR0EsS0FBSyxHQUFHLDZDQUE2QyxHQUFHLEVBQUUsQ0FBQyxDQUFDO0FBQ3ZRO0FBQUMsSUFBQUYsRUFBQTtBQUFBSSxZQUFBLENBQUFKLEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}