var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const {
    LayoutGallery,
    Lede
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  if (!LayoutGallery) _missingMdxReference("LayoutGallery", true, "4:1-4:17");
  if (!Lede) _missingMdxReference("Lede", true, "2:1-2:195");
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(Lede, {
      children: "Twelve shapes, three mechanisms — which one you reach for is decided by what carries it: a file you copy, a key you set, or a component you call. Generated from the viewer manifest."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(LayoutGallery, {})]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/content/layouts.mdx`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiTGF5b3V0R2FsbGVyeSIsIkxlZGUiLCJfcHJvdmlkZUNvbXBvbmVudHMiLCJjb21wb25lbnRzIiwiX21pc3NpbmdNZHhSZWZlcmVuY2UiLCJqc3hzIiwiRnJhZ21lbnQiLCJjaGlsZHJlbiIsImpzeCIsIk1EWENvbnRlbnQiLCJ3cmFwcGVyIiwiTURYTGF5b3V0IiwiX2MiLCJpZCIsImNvbXBvbmVudCIsInBsYWNlIiwiRXJyb3IiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJsYXlvdXRzLm1keCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKkBqc3hSdW50aW1lIGF1dG9tYXRpYyovXG4vKkBqc3hJbXBvcnRTb3VyY2UgcmVhY3QqL1xuaW1wb3J0IHt1c2VNRFhDb21wb25lbnRzIGFzIF9wcm92aWRlQ29tcG9uZW50c30gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrL01EWFByb3ZpZGVyXCI7XG5mdW5jdGlvbiBfY3JlYXRlTWR4Q29udGVudChwcm9wcykge1xuICBjb25zdCB7TGF5b3V0R2FsbGVyeSwgTGVkZX0gPSB7XG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9O1xuICBpZiAoIUxheW91dEdhbGxlcnkpIF9taXNzaW5nTWR4UmVmZXJlbmNlKFwiTGF5b3V0R2FsbGVyeVwiLCB0cnVlLCBcIjQ6MS00OjE3XCIpO1xuICBpZiAoIUxlZGUpIF9taXNzaW5nTWR4UmVmZXJlbmNlKFwiTGVkZVwiLCB0cnVlLCBcIjI6MS0yOjE5NVwiKTtcbiAgcmV0dXJuIDw+PExlZGU+e1wiVHdlbHZlIHNoYXBlcywgdGhyZWUgbWVjaGFuaXNtcyDigJQgd2hpY2ggb25lIHlvdSByZWFjaCBmb3IgaXMgZGVjaWRlZCBieSB3aGF0IGNhcnJpZXMgaXQ6IGEgZmlsZSB5b3UgY29weSwgYSBrZXkgeW91IHNldCwgb3IgYSBjb21wb25lbnQgeW91IGNhbGwuIEdlbmVyYXRlZCBmcm9tIHRoZSB2aWV3ZXIgbWFuaWZlc3QuXCJ9PC9MZWRlPntcIlxcblwifTxMYXlvdXRHYWxsZXJ5IC8+PC8+O1xufVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTURYQ29udGVudChwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHt3cmFwcGVyOiBNRFhMYXlvdXR9ID0ge1xuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfTtcbiAgcmV0dXJuIE1EWExheW91dCA/IDxNRFhMYXlvdXQgey4uLnByb3BzfT48X2NyZWF0ZU1keENvbnRlbnQgey4uLnByb3BzfSAvPjwvTURYTGF5b3V0PiA6IF9jcmVhdGVNZHhDb250ZW50KHByb3BzKTtcbn1cbmZ1bmN0aW9uIF9taXNzaW5nTWR4UmVmZXJlbmNlKGlkLCBjb21wb25lbnQsIHBsYWNlKSB7XG4gIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIFwiICsgKGNvbXBvbmVudCA/IFwiY29tcG9uZW50XCIgOiBcIm9iamVjdFwiKSArIFwiIGBcIiArIGlkICsgXCJgIHRvIGJlIGRlZmluZWQ6IHlvdSBsaWtlbHkgZm9yZ290IHRvIGltcG9ydCwgcGFzcywgb3IgcHJvdmlkZSBpdC5cIiArIChwbGFjZSA/IFwiXFxuSXTigJlzIHJlZmVyZW5jZWQgaW4geW91ciBjb2RlIGF0IGBcIiArIHBsYWNlICsgXCJgIGluIGAvYXBwL2NvbnRlbnQvbGF5b3V0cy5tZHhgXCIgOiBcIlwiKSk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUVBLElBQUFBLFlBQUEsR0FBQUMsT0FBQTtBQUF3RixJQUFBQyxXQUFBLEdBQUFELE9BQUE7QUFGeEY7QUFDQTs7QUFFQSxTQUFTRSxpQkFBaUJBLENBQUNDLEtBQUssRUFBRTtFQUNoQyxNQUFNO0lBQUNDLGFBQWE7SUFBRUM7RUFBSSxDQUFDLEdBQUc7SUFDNUIsR0FBRyxJQUFBQyw2QkFBa0IsRUFBQyxDQUFDO0lBQ3ZCLEdBQUdILEtBQUssQ0FBQ0k7RUFDWCxDQUFDO0VBQ0QsSUFBSSxDQUFDSCxhQUFhLEVBQUVJLG9CQUFvQixDQUFDLGVBQWUsRUFBRSxJQUFJLEVBQUUsVUFBVSxDQUFDO0VBQzNFLElBQUksQ0FBQ0gsSUFBSSxFQUFFRyxvQkFBb0IsQ0FBQyxNQUFNLEVBQUUsSUFBSSxFQUFFLFdBQVcsQ0FBQztFQUMxRCxvQkFBTyxJQUFBUCxXQUFBLENBQUFRLElBQUEsRUFBQVIsV0FBQSxDQUFBUyxRQUFBO0lBQUFDLFFBQUEsZ0JBQUUsSUFBQVYsV0FBQSxDQUFBVyxHQUFBLEVBQUNQLElBQUk7TUFBQU0sUUFBQSxFQUFFO0lBQXVMLENBQU8sQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBVixXQUFBLENBQUFXLEdBQUEsRUFBQ1IsYUFBYSxJQUFFLENBQUM7RUFBQSxDQUFFLENBQUM7QUFDM087QUFDZSxTQUFTUyxVQUFVQSxDQUFDVixLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUU7RUFDN0MsTUFBTTtJQUFDVyxPQUFPLEVBQUVDO0VBQVMsQ0FBQyxHQUFHO0lBQzNCLEdBQUcsSUFBQVQsNkJBQWtCLEVBQUMsQ0FBQztJQUN2QixHQUFHSCxLQUFLLENBQUNJO0VBQ1gsQ0FBQztFQUNELE9BQU9RLFNBQVMsZ0JBQUcsSUFBQWQsV0FBQSxDQUFBVyxHQUFBLEVBQUNHLFNBQVM7SUFBQSxHQUFLWixLQUFLO0lBQUFRLFFBQUEsZUFBRSxJQUFBVixXQUFBLENBQUFXLEdBQUEsRUFBQ1YsaUJBQWlCO01BQUEsR0FBS0M7SUFBSyxDQUFHO0VBQUMsQ0FBVyxDQUFDLEdBQUdELGlCQUFpQixDQUFDQyxLQUFLLENBQUM7QUFDbEg7QUFBQ2EsRUFBQSxHQU51QkgsVUFBVTtBQU9sQyxTQUFTTCxvQkFBb0JBLENBQUNTLEVBQUUsRUFBRUMsU0FBUyxFQUFFQyxLQUFLLEVBQUU7RUFDbEQsTUFBTSxJQUFJQyxLQUFLLENBQUMsV0FBVyxJQUFJRixTQUFTLEdBQUcsV0FBVyxHQUFHLFFBQVEsQ0FBQyxHQUFHLElBQUksR0FBR0QsRUFBRSxHQUFHLG9FQUFvRSxJQUFJRSxLQUFLLEdBQUcscUNBQXFDLEdBQUdBLEtBQUssR0FBRyxpQ0FBaUMsR0FBRyxFQUFFLENBQUMsQ0FBQztBQUMzUDtBQUFDLElBQUFILEVBQUE7QUFBQUssWUFBQSxDQUFBTCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}