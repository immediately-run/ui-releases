var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      code: "code",
      p: "p",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      Lede,
      ThemeGallery
    } = _components;
  if (!Lede) _missingMdxReference("Lede", true, "2:1-2:182");
  if (!ThemeGallery) _missingMdxReference("ThemeGallery", true, "4:1-4:16");
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(Lede, {
      children: "Four looks, both polarities each, compared on the page they will render. This list is generated from the viewer manifest — a new theme appears here the moment it ships."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(ThemeGallery, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Switch themes from the reader menu (top right); every look follows you into light or dark, and a wiki can declare its own with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "theme:"
      }), " on the home entry."]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/content/themes.mdx`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJjb2RlIiwicCIsIl9wcm92aWRlQ29tcG9uZW50cyIsImNvbXBvbmVudHMiLCJMZWRlIiwiVGhlbWVHYWxsZXJ5IiwiX21pc3NpbmdNZHhSZWZlcmVuY2UiLCJqc3hzIiwiRnJhZ21lbnQiLCJjaGlsZHJlbiIsImpzeCIsIk1EWENvbnRlbnQiLCJ3cmFwcGVyIiwiTURYTGF5b3V0IiwiX2MiLCJpZCIsImNvbXBvbmVudCIsInBsYWNlIiwiRXJyb3IiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJ0aGVtZXMubWR4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qQGpzeFJ1bnRpbWUgYXV0b21hdGljKi9cbi8qQGpzeEltcG9ydFNvdXJjZSByZWFjdCovXG5pbXBvcnQge3VzZU1EWENvbXBvbmVudHMgYXMgX3Byb3ZpZGVDb21wb25lbnRzfSBmcm9tIFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGsvTURYUHJvdmlkZXJcIjtcbmZ1bmN0aW9uIF9jcmVhdGVNZHhDb250ZW50KHByb3BzKSB7XG4gIGNvbnN0IF9jb21wb25lbnRzID0ge1xuICAgIGNvZGU6IFwiY29kZVwiLFxuICAgIHA6IFwicFwiLFxuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfSwge0xlZGUsIFRoZW1lR2FsbGVyeX0gPSBfY29tcG9uZW50cztcbiAgaWYgKCFMZWRlKSBfbWlzc2luZ01keFJlZmVyZW5jZShcIkxlZGVcIiwgdHJ1ZSwgXCIyOjEtMjoxODJcIik7XG4gIGlmICghVGhlbWVHYWxsZXJ5KSBfbWlzc2luZ01keFJlZmVyZW5jZShcIlRoZW1lR2FsbGVyeVwiLCB0cnVlLCBcIjQ6MS00OjE2XCIpO1xuICByZXR1cm4gPD48TGVkZT57XCJGb3VyIGxvb2tzLCBib3RoIHBvbGFyaXRpZXMgZWFjaCwgY29tcGFyZWQgb24gdGhlIHBhZ2UgdGhleSB3aWxsIHJlbmRlci4gVGhpcyBsaXN0IGlzIGdlbmVyYXRlZCBmcm9tIHRoZSB2aWV3ZXIgbWFuaWZlc3Qg4oCUIGEgbmV3IHRoZW1lIGFwcGVhcnMgaGVyZSB0aGUgbW9tZW50IGl0IHNoaXBzLlwifTwvTGVkZT57XCJcXG5cIn08VGhlbWVHYWxsZXJ5IC8+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiU3dpdGNoIHRoZW1lcyBmcm9tIHRoZSByZWFkZXIgbWVudSAodG9wIHJpZ2h0KTsgZXZlcnkgbG9vayBmb2xsb3dzIHlvdSBpbnRvIGxpZ2h0IG9yIGRhcmssIGFuZCBhIHdpa2kgY2FuIGRlY2xhcmUgaXRzIG93biB3aXRoIFwifTxfY29tcG9uZW50cy5jb2RlPntcInRoZW1lOlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgb24gdGhlIGhvbWUgZW50cnkuXCJ9PC9fY29tcG9uZW50cy5wPjwvPjtcbn1cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE1EWENvbnRlbnQocHJvcHMgPSB7fSkge1xuICBjb25zdCB7d3JhcHBlcjogTURYTGF5b3V0fSA9IHtcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH07XG4gIHJldHVybiBNRFhMYXlvdXQgPyA8TURYTGF5b3V0IHsuLi5wcm9wc30+PF9jcmVhdGVNZHhDb250ZW50IHsuLi5wcm9wc30gLz48L01EWExheW91dD4gOiBfY3JlYXRlTWR4Q29udGVudChwcm9wcyk7XG59XG5mdW5jdGlvbiBfbWlzc2luZ01keFJlZmVyZW5jZShpZCwgY29tcG9uZW50LCBwbGFjZSkge1xuICB0aHJvdyBuZXcgRXJyb3IoXCJFeHBlY3RlZCBcIiArIChjb21wb25lbnQgPyBcImNvbXBvbmVudFwiIDogXCJvYmplY3RcIikgKyBcIiBgXCIgKyBpZCArIFwiYCB0byBiZSBkZWZpbmVkOiB5b3UgbGlrZWx5IGZvcmdvdCB0byBpbXBvcnQsIHBhc3MsIG9yIHByb3ZpZGUgaXQuXCIgKyAocGxhY2UgPyBcIlxcbkl04oCZcyByZWZlcmVuY2VkIGluIHlvdXIgY29kZSBhdCBgXCIgKyBwbGFjZSArIFwiYCBpbiBgL2FwcC9jb250ZW50L3RoZW1lcy5tZHhgXCIgOiBcIlwiKSk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUVBLElBQUFBLFlBQUEsR0FBQUMsT0FBQTtBQUF3RixJQUFBQyxXQUFBLEdBQUFELE9BQUE7QUFGeEY7QUFDQTs7QUFFQSxTQUFTRSxpQkFBaUJBLENBQUNDLEtBQUssRUFBRTtFQUNoQyxNQUFNQyxXQUFXLEdBQUc7TUFDbEJDLElBQUksRUFBRSxNQUFNO01BQ1pDLENBQUMsRUFBRSxHQUFHO01BQ04sR0FBRyxJQUFBQyw2QkFBa0IsRUFBQyxDQUFDO01BQ3ZCLEdBQUdKLEtBQUssQ0FBQ0s7SUFDWCxDQUFDO0lBQUU7TUFBQ0MsSUFBSTtNQUFFQztJQUFZLENBQUMsR0FBR04sV0FBVztFQUNyQyxJQUFJLENBQUNLLElBQUksRUFBRUUsb0JBQW9CLENBQUMsTUFBTSxFQUFFLElBQUksRUFBRSxXQUFXLENBQUM7RUFDMUQsSUFBSSxDQUFDRCxZQUFZLEVBQUVDLG9CQUFvQixDQUFDLGNBQWMsRUFBRSxJQUFJLEVBQUUsVUFBVSxDQUFDO0VBQ3pFLG9CQUFPLElBQUFWLFdBQUEsQ0FBQVcsSUFBQSxFQUFBWCxXQUFBLENBQUFZLFFBQUE7SUFBQUMsUUFBQSxnQkFBRSxJQUFBYixXQUFBLENBQUFjLEdBQUEsRUFBQ04sSUFBSTtNQUFBSyxRQUFBLEVBQUU7SUFBMEssQ0FBTyxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFiLFdBQUEsQ0FBQWMsR0FBQSxFQUFDTCxZQUFZLElBQUUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBVCxXQUFBLENBQUFXLElBQUEsRUFBQ1IsV0FBVyxDQUFDRSxDQUFDO01BQUFRLFFBQUEsR0FBRSxpSUFBaUksZUFBQyxJQUFBYixXQUFBLENBQUFjLEdBQUEsRUFBQ1gsV0FBVyxDQUFDQyxJQUFJO1FBQUFTLFFBQUEsRUFBRTtNQUFRLENBQW1CLENBQUMsRUFBQyxxQkFBcUI7SUFBQSxDQUFnQixDQUFDO0VBQUEsQ0FBRSxDQUFDO0FBQzNjO0FBQ2UsU0FBU0UsVUFBVUEsQ0FBQ2IsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFO0VBQzdDLE1BQU07SUFBQ2MsT0FBTyxFQUFFQztFQUFTLENBQUMsR0FBRztJQUMzQixHQUFHLElBQUFYLDZCQUFrQixFQUFDLENBQUM7SUFDdkIsR0FBR0osS0FBSyxDQUFDSztFQUNYLENBQUM7RUFDRCxPQUFPVSxTQUFTLGdCQUFHLElBQUFqQixXQUFBLENBQUFjLEdBQUEsRUFBQ0csU0FBUztJQUFBLEdBQUtmLEtBQUs7SUFBQVcsUUFBQSxlQUFFLElBQUFiLFdBQUEsQ0FBQWMsR0FBQSxFQUFDYixpQkFBaUI7TUFBQSxHQUFLQztJQUFLLENBQUc7RUFBQyxDQUFXLENBQUMsR0FBR0QsaUJBQWlCLENBQUNDLEtBQUssQ0FBQztBQUNsSDtBQUFDZ0IsRUFBQSxHQU51QkgsVUFBVTtBQU9sQyxTQUFTTCxvQkFBb0JBLENBQUNTLEVBQUUsRUFBRUMsU0FBUyxFQUFFQyxLQUFLLEVBQUU7RUFDbEQsTUFBTSxJQUFJQyxLQUFLLENBQUMsV0FBVyxJQUFJRixTQUFTLEdBQUcsV0FBVyxHQUFHLFFBQVEsQ0FBQyxHQUFHLElBQUksR0FBR0QsRUFBRSxHQUFHLG9FQUFvRSxJQUFJRSxLQUFLLEdBQUcscUNBQXFDLEdBQUdBLEtBQUssR0FBRyxnQ0FBZ0MsR0FBRyxFQUFFLENBQUMsQ0FBQztBQUMxUDtBQUFDLElBQUFILEVBQUE7QUFBQUssWUFBQSxDQUFBTCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}