var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      code: "code",
      h2: "h2",
      li: "li",
      p: "p",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      Callout,
      HeadingAnchor
    } = _components;
  if (!Callout) _missingMdxReference("Callout", true, "12:1-12:216");
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Every new hire acknowledges this on day one (see ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "/content/handbook/onboarding.mdx",
        children: "onboarding"
      }), "). It is also the first reference when an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "/content/processes/incident-response.mdx",
        children: "incident"
      }), " is declared."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "accounts",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "accounts"
      }), "Accounts"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: "Hardware keys for anything production-adjacent"
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["No shared logins — ask Grove to add a person to the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "/content/directory.mdx",
          children: "directory"
        }), " instead"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["Rotate API tokens every ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "90 days"
        })]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "if-something-looks-wrong",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "if-something-looks-wrong"
      }), "If something looks wrong"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(Callout, {
      variant: "warning",
      title: "Report first, fix second",
      children: ["Page the on-call security lead before you touch anything. The ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "/content/processes/incident-response.mdx",
        children: "incident runbook"
      }), " takes over from there."]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/content/handbook/security.mdx`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiY29kZSIsImgyIiwibGkiLCJwIiwidWwiLCJfcHJvdmlkZUNvbXBvbmVudHMiLCJjb21wb25lbnRzIiwiQ2FsbG91dCIsIkhlYWRpbmdBbmNob3IiLCJfbWlzc2luZ01keFJlZmVyZW5jZSIsImpzeHMiLCJGcmFnbWVudCIsImNoaWxkcmVuIiwianN4IiwiaHJlZiIsImlkIiwidmFyaWFudCIsInRpdGxlIiwiTURYQ29udGVudCIsIndyYXBwZXIiLCJNRFhMYXlvdXQiLCJfYyIsImNvbXBvbmVudCIsInBsYWNlIiwiRXJyb3IiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJzZWN1cml0eS5tZHgiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgYTogXCJhXCIsXG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgaDI6IFwiaDJcIixcbiAgICBsaTogXCJsaVwiLFxuICAgIHA6IFwicFwiLFxuICAgIHVsOiBcInVsXCIsXG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9LCB7Q2FsbG91dCwgSGVhZGluZ0FuY2hvcn0gPSBfY29tcG9uZW50cztcbiAgaWYgKCFDYWxsb3V0KSBfbWlzc2luZ01keFJlZmVyZW5jZShcIkNhbGxvdXRcIiwgdHJ1ZSwgXCIxMjoxLTEyOjIxNlwiKTtcbiAgaWYgKCFIZWFkaW5nQW5jaG9yKSBfbWlzc2luZ01keFJlZmVyZW5jZShcIkhlYWRpbmdBbmNob3JcIiwgdHJ1ZSk7XG4gIHJldHVybiA8PjxfY29tcG9uZW50cy5wPntcIkV2ZXJ5IG5ldyBoaXJlIGFja25vd2xlZGdlcyB0aGlzIG9uIGRheSBvbmUgKHNlZSBcIn08X2NvbXBvbmVudHMuYSBocmVmPVwiL2NvbnRlbnQvaGFuZGJvb2svb25ib2FyZGluZy5tZHhcIj57XCJvbmJvYXJkaW5nXCJ9PC9fY29tcG9uZW50cy5hPntcIikuIEl0IGlzIGFsc28gdGhlIGZpcnN0IHJlZmVyZW5jZSB3aGVuIGFuIFwifTxfY29tcG9uZW50cy5hIGhyZWY9XCIvY29udGVudC9wcm9jZXNzZXMvaW5jaWRlbnQtcmVzcG9uc2UubWR4XCI+e1wiaW5jaWRlbnRcIn08L19jb21wb25lbnRzLmE+e1wiIGlzIGRlY2xhcmVkLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJhY2NvdW50c1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwiYWNjb3VudHNcIiAvPntcIkFjY291bnRzXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIkhhcmR3YXJlIGtleXMgZm9yIGFueXRoaW5nIHByb2R1Y3Rpb24tYWRqYWNlbnRcIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJObyBzaGFyZWQgbG9naW5zIOKAlCBhc2sgR3JvdmUgdG8gYWRkIGEgcGVyc29uIHRvIHRoZSBcIn08X2NvbXBvbmVudHMuYSBocmVmPVwiL2NvbnRlbnQvZGlyZWN0b3J5Lm1keFwiPntcImRpcmVjdG9yeVwifTwvX2NvbXBvbmVudHMuYT57XCIgaW5zdGVhZFwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIlJvdGF0ZSBBUEkgdG9rZW5zIGV2ZXJ5IFwifTxfY29tcG9uZW50cy5jb2RlPntcIjkwIGRheXNcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cImlmLXNvbWV0aGluZy1sb29rcy13cm9uZ1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwiaWYtc29tZXRoaW5nLWxvb2tzLXdyb25nXCIgLz57XCJJZiBzb21ldGhpbmcgbG9va3Mgd3JvbmdcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxDYWxsb3V0IHZhcmlhbnQ9XCJ3YXJuaW5nXCIgdGl0bGU9XCJSZXBvcnQgZmlyc3QsIGZpeCBzZWNvbmRcIj57XCJQYWdlIHRoZSBvbi1jYWxsIHNlY3VyaXR5IGxlYWQgYmVmb3JlIHlvdSB0b3VjaCBhbnl0aGluZy4gVGhlIFwifTxfY29tcG9uZW50cy5hIGhyZWY9XCIvY29udGVudC9wcm9jZXNzZXMvaW5jaWRlbnQtcmVzcG9uc2UubWR4XCI+e1wiaW5jaWRlbnQgcnVuYm9va1wifTwvX2NvbXBvbmVudHMuYT57XCIgdGFrZXMgb3ZlciBmcm9tIHRoZXJlLlwifTwvQ2FsbG91dD48Lz47XG59XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNRFhDb250ZW50KHByb3BzID0ge30pIHtcbiAgY29uc3Qge3dyYXBwZXI6IE1EWExheW91dH0gPSB7XG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9O1xuICByZXR1cm4gTURYTGF5b3V0ID8gPE1EWExheW91dCB7Li4ucHJvcHN9PjxfY3JlYXRlTWR4Q29udGVudCB7Li4ucHJvcHN9IC8+PC9NRFhMYXlvdXQ+IDogX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpO1xufVxuZnVuY3Rpb24gX21pc3NpbmdNZHhSZWZlcmVuY2UoaWQsIGNvbXBvbmVudCwgcGxhY2UpIHtcbiAgdGhyb3cgbmV3IEVycm9yKFwiRXhwZWN0ZWQgXCIgKyAoY29tcG9uZW50ID8gXCJjb21wb25lbnRcIiA6IFwib2JqZWN0XCIpICsgXCIgYFwiICsgaWQgKyBcImAgdG8gYmUgZGVmaW5lZDogeW91IGxpa2VseSBmb3Jnb3QgdG8gaW1wb3J0LCBwYXNzLCBvciBwcm92aWRlIGl0LlwiICsgKHBsYWNlID8gXCJcXG5JdOKAmXMgcmVmZXJlbmNlZCBpbiB5b3VyIGNvZGUgYXQgYFwiICsgcGxhY2UgKyBcImAgaW4gYC9hcHAvY29udGVudC9oYW5kYm9vay9zZWN1cml0eS5tZHhgXCIgOiBcIlwiKSk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUVBLElBQUFBLFlBQUEsR0FBQUMsT0FBQTtBQUF3RixJQUFBQyxXQUFBLEdBQUFELE9BQUE7QUFGeEY7QUFDQTs7QUFFQSxTQUFTRSxpQkFBaUJBLENBQUNDLEtBQUssRUFBRTtFQUNoQyxNQUFNQyxXQUFXLEdBQUc7TUFDbEJDLENBQUMsRUFBRSxHQUFHO01BQ05DLElBQUksRUFBRSxNQUFNO01BQ1pDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLENBQUMsRUFBRSxHQUFHO01BQ05DLEVBQUUsRUFBRSxJQUFJO01BQ1IsR0FBRyxJQUFBQyw2QkFBa0IsRUFBQyxDQUFDO01BQ3ZCLEdBQUdSLEtBQUssQ0FBQ1M7SUFDWCxDQUFDO0lBQUU7TUFBQ0MsT0FBTztNQUFFQztJQUFhLENBQUMsR0FBR1YsV0FBVztFQUN6QyxJQUFJLENBQUNTLE9BQU8sRUFBRUUsb0JBQW9CLENBQUMsU0FBUyxFQUFFLElBQUksRUFBRSxhQUFhLENBQUM7RUFDbEUsSUFBSSxDQUFDRCxhQUFhLEVBQUVDLG9CQUFvQixDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUM7RUFDL0Qsb0JBQU8sSUFBQWQsV0FBQSxDQUFBZSxJQUFBLEVBQUFmLFdBQUEsQ0FBQWdCLFFBQUE7SUFBQUMsUUFBQSxnQkFBRSxJQUFBakIsV0FBQSxDQUFBZSxJQUFBLEVBQUNaLFdBQVcsQ0FBQ0ssQ0FBQztNQUFBUyxRQUFBLEdBQUUsbURBQW1ELGVBQUMsSUFBQWpCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ2YsV0FBVyxDQUFDQyxDQUFDO1FBQUNlLElBQUksRUFBQyxrQ0FBa0M7UUFBQUYsUUFBQSxFQUFFO01BQVksQ0FBZ0IsQ0FBQyxFQUFDLDRDQUE0QyxlQUFDLElBQUFqQixXQUFBLENBQUFrQixHQUFBLEVBQUNmLFdBQVcsQ0FBQ0MsQ0FBQztRQUFDZSxJQUFJLEVBQUMsMENBQTBDO1FBQUFGLFFBQUEsRUFBRTtNQUFVLENBQWdCLENBQUMsRUFBQyxlQUFlO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBakIsV0FBQSxDQUFBZSxJQUFBLEVBQUNaLFdBQVcsQ0FBQ0csRUFBRTtNQUFDYyxFQUFFLEVBQUMsVUFBVTtNQUFBSCxRQUFBLGdCQUFDLElBQUFqQixXQUFBLENBQUFrQixHQUFBLEVBQUNMLGFBQWE7UUFBQ08sRUFBRSxFQUFDO01BQVUsQ0FBRSxDQUFDLEVBQUMsVUFBVTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWUsSUFBQSxFQUFDWixXQUFXLENBQUNNLEVBQUU7TUFBQVEsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBakIsV0FBQSxDQUFBa0IsR0FBQSxFQUFDZixXQUFXLENBQUNJLEVBQUU7UUFBQVUsUUFBQSxFQUFFO01BQWdELENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQWUsSUFBQSxFQUFDWixXQUFXLENBQUNJLEVBQUU7UUFBQVUsUUFBQSxHQUFFLHNEQUFzRCxlQUFDLElBQUFqQixXQUFBLENBQUFrQixHQUFBLEVBQUNmLFdBQVcsQ0FBQ0MsQ0FBQztVQUFDZSxJQUFJLEVBQUMsd0JBQXdCO1VBQUFGLFFBQUEsRUFBRTtRQUFXLENBQWdCLENBQUMsRUFBQyxVQUFVO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBakIsV0FBQSxDQUFBZSxJQUFBLEVBQUNaLFdBQVcsQ0FBQ0ksRUFBRTtRQUFBVSxRQUFBLEdBQUUsMEJBQTBCLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ2YsV0FBVyxDQUFDRSxJQUFJO1VBQUFZLFFBQUEsRUFBRTtRQUFTLENBQW1CLENBQUM7TUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQWUsSUFBQSxFQUFDWixXQUFXLENBQUNHLEVBQUU7TUFBQ2MsRUFBRSxFQUFDLDBCQUEwQjtNQUFBSCxRQUFBLGdCQUFDLElBQUFqQixXQUFBLENBQUFrQixHQUFBLEVBQUNMLGFBQWE7UUFBQ08sRUFBRSxFQUFDO01BQTBCLENBQUUsQ0FBQyxFQUFDLDBCQUEwQjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWUsSUFBQSxFQUFDSCxPQUFPO01BQUNTLE9BQU8sRUFBQyxTQUFTO01BQUNDLEtBQUssRUFBQywwQkFBMEI7TUFBQUwsUUFBQSxHQUFFLGdFQUFnRSxlQUFDLElBQUFqQixXQUFBLENBQUFrQixHQUFBLEVBQUNmLFdBQVcsQ0FBQ0MsQ0FBQztRQUFDZSxJQUFJLEVBQUMsMENBQTBDO1FBQUFGLFFBQUEsRUFBRTtNQUFrQixDQUFnQixDQUFDLEVBQUMseUJBQXlCO0lBQUEsQ0FBVSxDQUFDO0VBQUEsQ0FBRSxDQUFDO0FBQzN2QztBQUNlLFNBQVNNLFVBQVVBLENBQUNyQixLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUU7RUFDN0MsTUFBTTtJQUFDc0IsT0FBTyxFQUFFQztFQUFTLENBQUMsR0FBRztJQUMzQixHQUFHLElBQUFmLDZCQUFrQixFQUFDLENBQUM7SUFDdkIsR0FBR1IsS0FBSyxDQUFDUztFQUNYLENBQUM7RUFDRCxPQUFPYyxTQUFTLGdCQUFHLElBQUF6QixXQUFBLENBQUFrQixHQUFBLEVBQUNPLFNBQVM7SUFBQSxHQUFLdkIsS0FBSztJQUFBZSxRQUFBLGVBQUUsSUFBQWpCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ2pCLGlCQUFpQjtNQUFBLEdBQUtDO0lBQUssQ0FBRztFQUFDLENBQVcsQ0FBQyxHQUFHRCxpQkFBaUIsQ0FBQ0MsS0FBSyxDQUFDO0FBQ2xIO0FBQUN3QixFQUFBLEdBTnVCSCxVQUFVO0FBT2xDLFNBQVNULG9CQUFvQkEsQ0FBQ00sRUFBRSxFQUFFTyxTQUFTLEVBQUVDLEtBQUssRUFBRTtFQUNsRCxNQUFNLElBQUlDLEtBQUssQ0FBQyxXQUFXLElBQUlGLFNBQVMsR0FBRyxXQUFXLEdBQUcsUUFBUSxDQUFDLEdBQUcsSUFBSSxHQUFHUCxFQUFFLEdBQUcsb0VBQW9FLElBQUlRLEtBQUssR0FBRyxxQ0FBcUMsR0FBR0EsS0FBSyxHQUFHLDJDQUEyQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO0FBQ3JRO0FBQUMsSUFBQUYsRUFBQTtBQUFBSSxZQUFBLENBQUFKLEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}