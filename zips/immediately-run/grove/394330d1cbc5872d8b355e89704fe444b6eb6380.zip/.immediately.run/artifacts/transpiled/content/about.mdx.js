var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      code: "code",
      h2: "h2",
      li: "li",
      p: "p",
      strong: "strong",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      Callout,
      DirectoryList,
      HeadingAnchor
    } = _components;
  if (!Callout) _missingMdxReference("Callout", true, "35:1-35:190");
  if (!DirectoryList) _missingMdxReference("DirectoryList", true, "33:1-33:66");
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "This is a Grove — a wiki where every entry is one MDX file and the chrome is composed from tagged entries. This page is an ordinary entry, not special chrome."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "conventions",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "conventions"
      }), "Conventions"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ui/nav"
        }), " tags become top-nav items, ordered by ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "order"
        })]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ui/sidebar"
        }), " tags become sidebar panels"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["Person entries carry ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "role"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "phone"
        }), ", and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "team"
        }), " — read by the directory view"]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "components-in-use",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "components-in-use"
      }), "Components in use"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<DocList>"
        }), " — the index feed and grid"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<Backlinks>"
        }), " — who links here"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<Directory>"
        }), " — the phone book (agent-added view)"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<DirectoryList>"
        }), " — the files in a folder, with their frontmatter"]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "folder-urls",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "folder-urls"
      }), "Folder URLs"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Every folder in the corpus is an address of its own. Open ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "handbook",
        children: "handbook"
      }), " and Grove\nlists what is in it — entries with their title, description, tags and date, subfolders,\nand any assets that live alongside them. Columns appear only for frontmatter the entries\nactually carry, so a folder of plain markdown gets a plain table."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Two ways to change what a folder URL shows:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Write ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "index.mdx"
          }), " in the folder."]
        }), " Grove renders your page instead of the generated\nlisting — curation beats generation, no engine change needed."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Replace ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "<DirectoryList>"
          }), " in the MDX component map."]
        }), " The folder route resolves the\ntable by name, so an override reaches the route as well as the tag."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "You can also drop the table into any entry:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(DirectoryList, {
      path: "/handbook",
      title: "Everything in handbook/"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(Callout, {
      variant: "note",
      title: "For the next agent",
      children: ["These conventions also live in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "GROVE.md"
      }), " at the content root, kept in sync by Grove's agent. Read it before changing structure."]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/content/about.mdx`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiY29kZSIsImgyIiwibGkiLCJwIiwic3Ryb25nIiwidWwiLCJfcHJvdmlkZUNvbXBvbmVudHMiLCJjb21wb25lbnRzIiwiQ2FsbG91dCIsIkRpcmVjdG9yeUxpc3QiLCJIZWFkaW5nQW5jaG9yIiwiX21pc3NpbmdNZHhSZWZlcmVuY2UiLCJqc3hzIiwiRnJhZ21lbnQiLCJjaGlsZHJlbiIsImpzeCIsImlkIiwiaHJlZiIsInBhdGgiLCJ0aXRsZSIsInZhcmlhbnQiLCJNRFhDb250ZW50Iiwid3JhcHBlciIsIk1EWExheW91dCIsIl9jIiwiY29tcG9uZW50IiwicGxhY2UiLCJFcnJvciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbImFib3V0Lm1keCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKkBqc3hSdW50aW1lIGF1dG9tYXRpYyovXG4vKkBqc3hJbXBvcnRTb3VyY2UgcmVhY3QqL1xuaW1wb3J0IHt1c2VNRFhDb21wb25lbnRzIGFzIF9wcm92aWRlQ29tcG9uZW50c30gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrL01EWFByb3ZpZGVyXCI7XG5mdW5jdGlvbiBfY3JlYXRlTWR4Q29udGVudChwcm9wcykge1xuICBjb25zdCBfY29tcG9uZW50cyA9IHtcbiAgICBhOiBcImFcIixcbiAgICBjb2RlOiBcImNvZGVcIixcbiAgICBoMjogXCJoMlwiLFxuICAgIGxpOiBcImxpXCIsXG4gICAgcDogXCJwXCIsXG4gICAgc3Ryb25nOiBcInN0cm9uZ1wiLFxuICAgIHVsOiBcInVsXCIsXG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9LCB7Q2FsbG91dCwgRGlyZWN0b3J5TGlzdCwgSGVhZGluZ0FuY2hvcn0gPSBfY29tcG9uZW50cztcbiAgaWYgKCFDYWxsb3V0KSBfbWlzc2luZ01keFJlZmVyZW5jZShcIkNhbGxvdXRcIiwgdHJ1ZSwgXCIzNToxLTM1OjE5MFwiKTtcbiAgaWYgKCFEaXJlY3RvcnlMaXN0KSBfbWlzc2luZ01keFJlZmVyZW5jZShcIkRpcmVjdG9yeUxpc3RcIiwgdHJ1ZSwgXCIzMzoxLTMzOjY2XCIpO1xuICBpZiAoIUhlYWRpbmdBbmNob3IpIF9taXNzaW5nTWR4UmVmZXJlbmNlKFwiSGVhZGluZ0FuY2hvclwiLCB0cnVlKTtcbiAgcmV0dXJuIDw+PF9jb21wb25lbnRzLnA+e1wiVGhpcyBpcyBhIEdyb3ZlIOKAlCBhIHdpa2kgd2hlcmUgZXZlcnkgZW50cnkgaXMgb25lIE1EWCBmaWxlIGFuZCB0aGUgY2hyb21lIGlzIGNvbXBvc2VkIGZyb20gdGFnZ2VkIGVudHJpZXMuIFRoaXMgcGFnZSBpcyBhbiBvcmRpbmFyeSBlbnRyeSwgbm90IHNwZWNpYWwgY2hyb21lLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJjb252ZW50aW9uc1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwiY29udmVudGlvbnNcIiAvPntcIkNvbnZlbnRpb25zXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5jb2RlPntcInVpL25hdlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdGFncyBiZWNvbWUgdG9wLW5hdiBpdGVtcywgb3JkZXJlZCBieSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJvcmRlclwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuY29kZT57XCJ1aS9zaWRlYmFyXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB0YWdzIGJlY29tZSBzaWRlYmFyIHBhbmVsc1wifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIlBlcnNvbiBlbnRyaWVzIGNhcnJ5IFwifTxfY29tcG9uZW50cy5jb2RlPntcInJvbGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJwaG9uZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGFuZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ0ZWFtXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgcmVhZCBieSB0aGUgZGlyZWN0b3J5IHZpZXdcIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwiY29tcG9uZW50cy1pbi11c2VcIj48SGVhZGluZ0FuY2hvciBpZD1cImNvbXBvbmVudHMtaW4tdXNlXCIgLz57XCJDb21wb25lbnRzIGluIHVzZVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuY29kZT57XCI8RG9jTGlzdD5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCB0aGUgaW5kZXggZmVlZCBhbmQgZ3JpZFwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5jb2RlPntcIjxCYWNrbGlua3M+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgd2hvIGxpbmtzIGhlcmVcIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuY29kZT57XCI8RGlyZWN0b3J5PlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIHRoZSBwaG9uZSBib29rIChhZ2VudC1hZGRlZCB2aWV3KVwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5jb2RlPntcIjxEaXJlY3RvcnlMaXN0PlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIHRoZSBmaWxlcyBpbiBhIGZvbGRlciwgd2l0aCB0aGVpciBmcm9udG1hdHRlclwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJmb2xkZXItdXJsc1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwiZm9sZGVyLXVybHNcIiAvPntcIkZvbGRlciBVUkxzXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJFdmVyeSBmb2xkZXIgaW4gdGhlIGNvcnB1cyBpcyBhbiBhZGRyZXNzIG9mIGl0cyBvd24uIE9wZW4gXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cImhhbmRib29rXCI+e1wiaGFuZGJvb2tcIn08L19jb21wb25lbnRzLmE+e1wiIGFuZCBHcm92ZVxcbmxpc3RzIHdoYXQgaXMgaW4gaXQg4oCUIGVudHJpZXMgd2l0aCB0aGVpciB0aXRsZSwgZGVzY3JpcHRpb24sIHRhZ3MgYW5kIGRhdGUsIHN1YmZvbGRlcnMsXFxuYW5kIGFueSBhc3NldHMgdGhhdCBsaXZlIGFsb25nc2lkZSB0aGVtLiBDb2x1bW5zIGFwcGVhciBvbmx5IGZvciBmcm9udG1hdHRlciB0aGUgZW50cmllc1xcbmFjdHVhbGx5IGNhcnJ5LCBzbyBhIGZvbGRlciBvZiBwbGFpbiBtYXJrZG93biBnZXRzIGEgcGxhaW4gdGFibGUuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlR3byB3YXlzIHRvIGNoYW5nZSB3aGF0IGEgZm9sZGVyIFVSTCBzaG93czpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIldyaXRlIFwifTxfY29tcG9uZW50cy5jb2RlPntcImluZGV4Lm1keFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaW4gdGhlIGZvbGRlci5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgR3JvdmUgcmVuZGVycyB5b3VyIHBhZ2UgaW5zdGVhZCBvZiB0aGUgZ2VuZXJhdGVkXFxubGlzdGluZyDigJQgY3VyYXRpb24gYmVhdHMgZ2VuZXJhdGlvbiwgbm8gZW5naW5lIGNoYW5nZSBuZWVkZWQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJSZXBsYWNlIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjxEaXJlY3RvcnlMaXN0PlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaW4gdGhlIE1EWCBjb21wb25lbnQgbWFwLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGUgZm9sZGVyIHJvdXRlIHJlc29sdmVzIHRoZVxcbnRhYmxlIGJ5IG5hbWUsIHNvIGFuIG92ZXJyaWRlIHJlYWNoZXMgdGhlIHJvdXRlIGFzIHdlbGwgYXMgdGhlIHRhZy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiWW91IGNhbiBhbHNvIGRyb3AgdGhlIHRhYmxlIGludG8gYW55IGVudHJ5OlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08RGlyZWN0b3J5TGlzdCBwYXRoPVwiL2hhbmRib29rXCIgdGl0bGU9XCJFdmVyeXRoaW5nIGluIGhhbmRib29rL1wiIC8+e1wiXFxuXCJ9PENhbGxvdXQgdmFyaWFudD1cIm5vdGVcIiB0aXRsZT1cIkZvciB0aGUgbmV4dCBhZ2VudFwiPntcIlRoZXNlIGNvbnZlbnRpb25zIGFsc28gbGl2ZSBpbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJHUk9WRS5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYXQgdGhlIGNvbnRlbnQgcm9vdCwga2VwdCBpbiBzeW5jIGJ5IEdyb3ZlJ3MgYWdlbnQuIFJlYWQgaXQgYmVmb3JlIGNoYW5naW5nIHN0cnVjdHVyZS5cIn08L0NhbGxvdXQ+PC8+O1xufVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTURYQ29udGVudChwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHt3cmFwcGVyOiBNRFhMYXlvdXR9ID0ge1xuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfTtcbiAgcmV0dXJuIE1EWExheW91dCA/IDxNRFhMYXlvdXQgey4uLnByb3BzfT48X2NyZWF0ZU1keENvbnRlbnQgey4uLnByb3BzfSAvPjwvTURYTGF5b3V0PiA6IF9jcmVhdGVNZHhDb250ZW50KHByb3BzKTtcbn1cbmZ1bmN0aW9uIF9taXNzaW5nTWR4UmVmZXJlbmNlKGlkLCBjb21wb25lbnQsIHBsYWNlKSB7XG4gIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIFwiICsgKGNvbXBvbmVudCA/IFwiY29tcG9uZW50XCIgOiBcIm9iamVjdFwiKSArIFwiIGBcIiArIGlkICsgXCJgIHRvIGJlIGRlZmluZWQ6IHlvdSBsaWtlbHkgZm9yZ290IHRvIGltcG9ydCwgcGFzcywgb3IgcHJvdmlkZSBpdC5cIiArIChwbGFjZSA/IFwiXFxuSXTigJlzIHJlZmVyZW5jZWQgaW4geW91ciBjb2RlIGF0IGBcIiArIHBsYWNlICsgXCJgIGluIGAvYXBwL2NvbnRlbnQvYWJvdXQubWR4YFwiIDogXCJcIikpO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFFQSxJQUFBQSxZQUFBLEdBQUFDLE9BQUE7QUFBd0YsSUFBQUMsV0FBQSxHQUFBRCxPQUFBO0FBRnhGO0FBQ0E7O0FBRUEsU0FBU0UsaUJBQWlCQSxDQUFDQyxLQUFLLEVBQUU7RUFDaEMsTUFBTUMsV0FBVyxHQUFHO01BQ2xCQyxDQUFDLEVBQUUsR0FBRztNQUNOQyxJQUFJLEVBQUUsTUFBTTtNQUNaQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxDQUFDLEVBQUUsR0FBRztNQUNOQyxNQUFNLEVBQUUsUUFBUTtNQUNoQkMsRUFBRSxFQUFFLElBQUk7TUFDUixHQUFHLElBQUFDLDZCQUFrQixFQUFDLENBQUM7TUFDdkIsR0FBR1QsS0FBSyxDQUFDVTtJQUNYLENBQUM7SUFBRTtNQUFDQyxPQUFPO01BQUVDLGFBQWE7TUFBRUM7SUFBYSxDQUFDLEdBQUdaLFdBQVc7RUFDeEQsSUFBSSxDQUFDVSxPQUFPLEVBQUVHLG9CQUFvQixDQUFDLFNBQVMsRUFBRSxJQUFJLEVBQUUsYUFBYSxDQUFDO0VBQ2xFLElBQUksQ0FBQ0YsYUFBYSxFQUFFRSxvQkFBb0IsQ0FBQyxlQUFlLEVBQUUsSUFBSSxFQUFFLFlBQVksQ0FBQztFQUM3RSxJQUFJLENBQUNELGFBQWEsRUFBRUMsb0JBQW9CLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQztFQUMvRCxvQkFBTyxJQUFBaEIsV0FBQSxDQUFBaUIsSUFBQSxFQUFBakIsV0FBQSxDQUFBa0IsUUFBQTtJQUFBQyxRQUFBLGdCQUFFLElBQUFuQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNLLENBQUM7TUFBQVcsUUFBQSxFQUFFO0lBQWdLLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDRyxFQUFFO01BQUNlLEVBQUUsRUFBQyxhQUFhO01BQUFGLFFBQUEsZ0JBQUMsSUFBQW5CLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ0wsYUFBYTtRQUFDTSxFQUFFLEVBQUM7TUFBYSxDQUFFLENBQUMsRUFBQyxhQUFhO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNPLEVBQUU7TUFBQVMsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNJLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBbkIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDRSxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUFRLENBQW1CLENBQUMsRUFBQyx5Q0FBeUMsZUFBQyxJQUFBbkIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDRSxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUFPLENBQW1CLENBQUM7TUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ0ksRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNFLElBQUk7VUFBQWMsUUFBQSxFQUFFO1FBQVksQ0FBbUIsQ0FBQyxFQUFDLDZCQUE2QjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDSSxFQUFFO1FBQUFZLFFBQUEsR0FBRSx1QkFBdUIsZUFBQyxJQUFBbkIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDRSxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUFNLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBTyxDQUFtQixDQUFDLEVBQUMsUUFBUSxlQUFDLElBQUFuQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNFLElBQUk7VUFBQWMsUUFBQSxFQUFFO1FBQU0sQ0FBbUIsQ0FBQyxFQUFDLCtCQUErQjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNHLEVBQUU7TUFBQ2UsRUFBRSxFQUFDLG1CQUFtQjtNQUFBRixRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFvQixHQUFBLEVBQUNMLGFBQWE7UUFBQ00sRUFBRSxFQUFDO01BQW1CLENBQUUsQ0FBQyxFQUFDLG1CQUFtQjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDTyxFQUFFO01BQUFTLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDSSxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQW5CLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsNEJBQTRCO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNJLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBbkIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDRSxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyxtQkFBbUI7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ0ksRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNFLElBQUk7VUFBQWMsUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQyxFQUFDLHNDQUFzQztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDSSxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQW5CLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBaUIsQ0FBbUIsQ0FBQyxFQUFDLGtEQUFrRDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNHLEVBQUU7TUFBQ2UsRUFBRSxFQUFDLGFBQWE7TUFBQUYsUUFBQSxnQkFBQyxJQUFBbkIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDTCxhQUFhO1FBQUNNLEVBQUUsRUFBQztNQUFhLENBQUUsQ0FBQyxFQUFDLGFBQWE7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ0ssQ0FBQztNQUFBVyxRQUFBLEdBQUUsNERBQTRELGVBQUMsSUFBQW5CLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0MsQ0FBQztRQUFDa0IsSUFBSSxFQUFDLFVBQVU7UUFBQUgsUUFBQSxFQUFFO01BQVUsQ0FBZ0IsQ0FBQyxFQUFDLGtRQUFrUTtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0ssQ0FBQztNQUFBVyxRQUFBLEVBQUU7SUFBNkMsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNPLEVBQUU7TUFBQVMsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNJLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNNLE1BQU07VUFBQVUsUUFBQSxHQUFFLFFBQVEsZUFBQyxJQUFBbkIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDRSxJQUFJO1lBQUFjLFFBQUEsRUFBRTtVQUFXLENBQW1CLENBQUMsRUFBQyxpQkFBaUI7UUFBQSxDQUFxQixDQUFDLEVBQUMsa0hBQWtIO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNJLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNNLE1BQU07VUFBQVUsUUFBQSxHQUFFLFVBQVUsZUFBQyxJQUFBbkIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDRSxJQUFJO1lBQUFjLFFBQUEsRUFBRTtVQUFpQixDQUFtQixDQUFDLEVBQUMsNEJBQTRCO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLHFHQUFxRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBb0IsR0FBQSxFQUFDakIsV0FBVyxDQUFDSyxDQUFDO01BQUFXLFFBQUEsRUFBRTtJQUE2QyxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFvQixHQUFBLEVBQUNOLGFBQWE7TUFBQ1MsSUFBSSxFQUFDLFdBQVc7TUFBQ0MsS0FBSyxFQUFDO0lBQXlCLENBQUUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBeEIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDSixPQUFPO01BQUNZLE9BQU8sRUFBQyxNQUFNO01BQUNELEtBQUssRUFBQyxvQkFBb0I7TUFBQUwsUUFBQSxHQUFFLGlDQUFpQyxlQUFDLElBQUFuQixXQUFBLENBQUFvQixHQUFBLEVBQUNqQixXQUFXLENBQUNFLElBQUk7UUFBQWMsUUFBQSxFQUFFO01BQVUsQ0FBbUIsQ0FBQyxFQUFDLHlGQUF5RjtJQUFBLENBQVUsQ0FBQztFQUFBLENBQUUsQ0FBQztBQUNqbkc7QUFDZSxTQUFTTyxVQUFVQSxDQUFDeEIsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFO0VBQzdDLE1BQU07SUFBQ3lCLE9BQU8sRUFBRUM7RUFBUyxDQUFDLEdBQUc7SUFDM0IsR0FBRyxJQUFBakIsNkJBQWtCLEVBQUMsQ0FBQztJQUN2QixHQUFHVCxLQUFLLENBQUNVO0VBQ1gsQ0FBQztFQUNELE9BQU9nQixTQUFTLGdCQUFHLElBQUE1QixXQUFBLENBQUFvQixHQUFBLEVBQUNRLFNBQVM7SUFBQSxHQUFLMUIsS0FBSztJQUFBaUIsUUFBQSxlQUFFLElBQUFuQixXQUFBLENBQUFvQixHQUFBLEVBQUNuQixpQkFBaUI7TUFBQSxHQUFLQztJQUFLLENBQUc7RUFBQyxDQUFXLENBQUMsR0FBR0QsaUJBQWlCLENBQUNDLEtBQUssQ0FBQztBQUNsSDtBQUFDMkIsRUFBQSxHQU51QkgsVUFBVTtBQU9sQyxTQUFTVixvQkFBb0JBLENBQUNLLEVBQUUsRUFBRVMsU0FBUyxFQUFFQyxLQUFLLEVBQUU7RUFDbEQsTUFBTSxJQUFJQyxLQUFLLENBQUMsV0FBVyxJQUFJRixTQUFTLEdBQUcsV0FBVyxHQUFHLFFBQVEsQ0FBQyxHQUFHLElBQUksR0FBR1QsRUFBRSxHQUFHLG9FQUFvRSxJQUFJVSxLQUFLLEdBQUcscUNBQXFDLEdBQUdBLEtBQUssR0FBRywrQkFBK0IsR0FBRyxFQUFFLENBQUMsQ0FBQztBQUN6UDtBQUFDLElBQUFGLEVBQUE7QUFBQUksWUFBQSxDQUFBSixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}