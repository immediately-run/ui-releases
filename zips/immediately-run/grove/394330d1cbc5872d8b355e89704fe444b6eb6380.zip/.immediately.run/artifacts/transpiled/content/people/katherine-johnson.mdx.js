var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
    code: "code",
    p: "p",
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
    children: ["Katherine Johnson is data lead on the the data team. Reach them at ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
      children: "x3110"
    }), "."]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJjb2RlIiwicCIsIl9wcm92aWRlQ29tcG9uZW50cyIsImNvbXBvbmVudHMiLCJqc3hzIiwiY2hpbGRyZW4iLCJqc3giLCJNRFhDb250ZW50Iiwid3JhcHBlciIsIk1EWExheW91dCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsia2F0aGVyaW5lLWpvaG5zb24ubWR4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qQGpzeFJ1bnRpbWUgYXV0b21hdGljKi9cbi8qQGpzeEltcG9ydFNvdXJjZSByZWFjdCovXG5pbXBvcnQge3VzZU1EWENvbXBvbmVudHMgYXMgX3Byb3ZpZGVDb21wb25lbnRzfSBmcm9tIFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGsvTURYUHJvdmlkZXJcIjtcbmZ1bmN0aW9uIF9jcmVhdGVNZHhDb250ZW50KHByb3BzKSB7XG4gIGNvbnN0IF9jb21wb25lbnRzID0ge1xuICAgIGNvZGU6IFwiY29kZVwiLFxuICAgIHA6IFwicFwiLFxuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfTtcbiAgcmV0dXJuIDxfY29tcG9uZW50cy5wPntcIkthdGhlcmluZSBKb2huc29uIGlzIGRhdGEgbGVhZCBvbiB0aGUgdGhlIGRhdGEgdGVhbS4gUmVhY2ggdGhlbSBhdCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ4MzExMFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuXCJ9PC9fY29tcG9uZW50cy5wPjtcbn1cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE1EWENvbnRlbnQocHJvcHMgPSB7fSkge1xuICBjb25zdCB7d3JhcHBlcjogTURYTGF5b3V0fSA9IHtcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH07XG4gIHJldHVybiBNRFhMYXlvdXQgPyA8TURYTGF5b3V0IHsuLi5wcm9wc30+PF9jcmVhdGVNZHhDb250ZW50IHsuLi5wcm9wc30gLz48L01EWExheW91dD4gOiBfY3JlYXRlTWR4Q29udGVudChwcm9wcyk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUVBLElBQUFBLFlBQUEsR0FBQUMsT0FBQTtBQUF3RixJQUFBQyxXQUFBLEdBQUFELE9BQUE7QUFGeEY7QUFDQTs7QUFFQSxTQUFTRSxpQkFBaUJBLENBQUNDLEtBQUssRUFBRTtFQUNoQyxNQUFNQyxXQUFXLEdBQUc7SUFDbEJDLElBQUksRUFBRSxNQUFNO0lBQ1pDLENBQUMsRUFBRSxHQUFHO0lBQ04sR0FBRyxJQUFBQyw2QkFBa0IsRUFBQyxDQUFDO0lBQ3ZCLEdBQUdKLEtBQUssQ0FBQ0s7RUFDWCxDQUFDO0VBQ0Qsb0JBQU8sSUFBQVAsV0FBQSxDQUFBUSxJQUFBLEVBQUNMLFdBQVcsQ0FBQ0UsQ0FBQztJQUFBSSxRQUFBLEdBQUUscUVBQXFFLGVBQUMsSUFBQVQsV0FBQSxDQUFBVSxHQUFBLEVBQUNQLFdBQVcsQ0FBQ0MsSUFBSTtNQUFBSyxRQUFBLEVBQUU7SUFBTyxDQUFtQixDQUFDLEVBQUMsR0FBRztFQUFBLENBQWdCLENBQUM7QUFDbEs7QUFDZSxTQUFTRSxVQUFVQSxDQUFDVCxLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUU7RUFDN0MsTUFBTTtJQUFDVSxPQUFPLEVBQUVDO0VBQVMsQ0FBQyxHQUFHO0lBQzNCLEdBQUcsSUFBQVAsNkJBQWtCLEVBQUMsQ0FBQztJQUN2QixHQUFHSixLQUFLLENBQUNLO0VBQ1gsQ0FBQztFQUNELE9BQU9NLFNBQVMsZ0JBQUcsSUFBQWIsV0FBQSxDQUFBVSxHQUFBLEVBQUNHLFNBQVM7SUFBQSxHQUFLWCxLQUFLO0lBQUFPLFFBQUEsZUFBRSxJQUFBVCxXQUFBLENBQUFVLEdBQUEsRUFBQ1QsaUJBQWlCO01BQUEsR0FBS0M7SUFBSyxDQUFHO0VBQUMsQ0FBVyxDQUFDLEdBQUdELGlCQUFpQixDQUFDQyxLQUFLLENBQUM7QUFDbEg7QUFBQ1ksRUFBQSxHQU51QkgsVUFBVTtBQUFBLElBQUFHLEVBQUE7QUFBQUMsWUFBQSxDQUFBRCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}