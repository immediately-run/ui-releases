var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/
/*
The site shell, as content. This `_layout.mdx` at the content root wraps EVERY
entry (the outermost link in the layout chain), so no entry has to include the
nav, sidebar, or footer itself — it renders the page at `<Outlet/>`.

It's plain MDX using the import-free layout primitives (`GroveNav`,
`GroveSidebar`, `GroveFooter`, `Outlet`). Rearranging the shell — dropping the
sidebar, moving the footer, adding a banner — is editing THIS file, not the
engine. Delete this file and the engine falls back to the same built-in shell.
*/

function _createMdxContent(props) {
  const {
    GroveFooter,
    GroveNav,
    GroveSidebar,
    Outlet
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  if (!GroveFooter) _missingMdxReference("GroveFooter", true, "20:1-20:16");
  if (!GroveNav) _missingMdxReference("GroveNav", true, "13:1-13:13");
  if (!GroveSidebar) _missingMdxReference("GroveSidebar", true, "14:1-14:17");
  if (!Outlet) _missingMdxReference("Outlet", true, "17:3-17:13");
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(GroveNav, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(GroveSidebar, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)("main", {
      className: "grove-content",
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(Outlet, {})
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(GroveFooter, {})]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/content/_layout.mdx`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiR3JvdmVGb290ZXIiLCJHcm92ZU5hdiIsIkdyb3ZlU2lkZWJhciIsIk91dGxldCIsIl9wcm92aWRlQ29tcG9uZW50cyIsImNvbXBvbmVudHMiLCJfbWlzc2luZ01keFJlZmVyZW5jZSIsImpzeHMiLCJGcmFnbWVudCIsImNoaWxkcmVuIiwianN4IiwiY2xhc3NOYW1lIiwiTURYQ29udGVudCIsIndyYXBwZXIiLCJNRFhMYXlvdXQiLCJfYyIsImlkIiwiY29tcG9uZW50IiwicGxhY2UiLCJFcnJvciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIl9sYXlvdXQubWR4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qQGpzeFJ1bnRpbWUgYXV0b21hdGljKi9cbi8qQGpzeEltcG9ydFNvdXJjZSByZWFjdCovXG4vKlxuVGhlIHNpdGUgc2hlbGwsIGFzIGNvbnRlbnQuIFRoaXMgYF9sYXlvdXQubWR4YCBhdCB0aGUgY29udGVudCByb290IHdyYXBzIEVWRVJZXG5lbnRyeSAodGhlIG91dGVybW9zdCBsaW5rIGluIHRoZSBsYXlvdXQgY2hhaW4pLCBzbyBubyBlbnRyeSBoYXMgdG8gaW5jbHVkZSB0aGVcbm5hdiwgc2lkZWJhciwgb3IgZm9vdGVyIGl0c2VsZiDigJQgaXQgcmVuZGVycyB0aGUgcGFnZSBhdCBgPE91dGxldC8+YC5cblxuSXQncyBwbGFpbiBNRFggdXNpbmcgdGhlIGltcG9ydC1mcmVlIGxheW91dCBwcmltaXRpdmVzIChgR3JvdmVOYXZgLFxuYEdyb3ZlU2lkZWJhcmAsIGBHcm92ZUZvb3RlcmAsIGBPdXRsZXRgKS4gUmVhcnJhbmdpbmcgdGhlIHNoZWxsIOKAlCBkcm9wcGluZyB0aGVcbnNpZGViYXIsIG1vdmluZyB0aGUgZm9vdGVyLCBhZGRpbmcgYSBiYW5uZXIg4oCUIGlzIGVkaXRpbmcgVEhJUyBmaWxlLCBub3QgdGhlXG5lbmdpbmUuIERlbGV0ZSB0aGlzIGZpbGUgYW5kIHRoZSBlbmdpbmUgZmFsbHMgYmFjayB0byB0aGUgc2FtZSBidWlsdC1pbiBzaGVsbC5cbiovXG5pbXBvcnQge3VzZU1EWENvbXBvbmVudHMgYXMgX3Byb3ZpZGVDb21wb25lbnRzfSBmcm9tIFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGsvTURYUHJvdmlkZXJcIjtcbmZ1bmN0aW9uIF9jcmVhdGVNZHhDb250ZW50KHByb3BzKSB7XG4gIGNvbnN0IHtHcm92ZUZvb3RlciwgR3JvdmVOYXYsIEdyb3ZlU2lkZWJhciwgT3V0bGV0fSA9IHtcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH07XG4gIGlmICghR3JvdmVGb290ZXIpIF9taXNzaW5nTWR4UmVmZXJlbmNlKFwiR3JvdmVGb290ZXJcIiwgdHJ1ZSwgXCIyMDoxLTIwOjE2XCIpO1xuICBpZiAoIUdyb3ZlTmF2KSBfbWlzc2luZ01keFJlZmVyZW5jZShcIkdyb3ZlTmF2XCIsIHRydWUsIFwiMTM6MS0xMzoxM1wiKTtcbiAgaWYgKCFHcm92ZVNpZGViYXIpIF9taXNzaW5nTWR4UmVmZXJlbmNlKFwiR3JvdmVTaWRlYmFyXCIsIHRydWUsIFwiMTQ6MS0xNDoxN1wiKTtcbiAgaWYgKCFPdXRsZXQpIF9taXNzaW5nTWR4UmVmZXJlbmNlKFwiT3V0bGV0XCIsIHRydWUsIFwiMTc6My0xNzoxM1wiKTtcbiAgcmV0dXJuIDw+e317XCJcXG5cIn08R3JvdmVOYXYgLz57XCJcXG5cIn08R3JvdmVTaWRlYmFyIC8+e1wiXFxuXCJ9PG1haW4gY2xhc3NOYW1lPVwiZ3JvdmUtY29udGVudFwiPjxPdXRsZXQgLz48L21haW4+e1wiXFxuXCJ9PEdyb3ZlRm9vdGVyIC8+PC8+O1xufVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTURYQ29udGVudChwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHt3cmFwcGVyOiBNRFhMYXlvdXR9ID0ge1xuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfTtcbiAgcmV0dXJuIE1EWExheW91dCA/IDxNRFhMYXlvdXQgey4uLnByb3BzfT48X2NyZWF0ZU1keENvbnRlbnQgey4uLnByb3BzfSAvPjwvTURYTGF5b3V0PiA6IF9jcmVhdGVNZHhDb250ZW50KHByb3BzKTtcbn1cbmZ1bmN0aW9uIF9taXNzaW5nTWR4UmVmZXJlbmNlKGlkLCBjb21wb25lbnQsIHBsYWNlKSB7XG4gIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIFwiICsgKGNvbXBvbmVudCA/IFwiY29tcG9uZW50XCIgOiBcIm9iamVjdFwiKSArIFwiIGBcIiArIGlkICsgXCJgIHRvIGJlIGRlZmluZWQ6IHlvdSBsaWtlbHkgZm9yZ290IHRvIGltcG9ydCwgcGFzcywgb3IgcHJvdmlkZSBpdC5cIiArIChwbGFjZSA/IFwiXFxuSXTigJlzIHJlZmVyZW5jZWQgaW4geW91ciBjb2RlIGF0IGBcIiArIHBsYWNlICsgXCJgIGluIGAvYXBwL2NvbnRlbnQvX2xheW91dC5tZHhgXCIgOiBcIlwiKSk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQVlBLElBQUFBLFlBQUEsR0FBQUMsT0FBQTtBQUF3RixJQUFBQyxXQUFBLEdBQUFELE9BQUE7QUFaeEY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU07SUFBQ0MsV0FBVztJQUFFQyxRQUFRO0lBQUVDLFlBQVk7SUFBRUM7RUFBTSxDQUFDLEdBQUc7SUFDcEQsR0FBRyxJQUFBQyw2QkFBa0IsRUFBQyxDQUFDO0lBQ3ZCLEdBQUdMLEtBQUssQ0FBQ007RUFDWCxDQUFDO0VBQ0QsSUFBSSxDQUFDTCxXQUFXLEVBQUVNLG9CQUFvQixDQUFDLGFBQWEsRUFBRSxJQUFJLEVBQUUsWUFBWSxDQUFDO0VBQ3pFLElBQUksQ0FBQ0wsUUFBUSxFQUFFSyxvQkFBb0IsQ0FBQyxVQUFVLEVBQUUsSUFBSSxFQUFFLFlBQVksQ0FBQztFQUNuRSxJQUFJLENBQUNKLFlBQVksRUFBRUksb0JBQW9CLENBQUMsY0FBYyxFQUFFLElBQUksRUFBRSxZQUFZLENBQUM7RUFDM0UsSUFBSSxDQUFDSCxNQUFNLEVBQUVHLG9CQUFvQixDQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsWUFBWSxDQUFDO0VBQy9ELG9CQUFPLElBQUFULFdBQUEsQ0FBQVUsSUFBQSxFQUFBVixXQUFBLENBQUFXLFFBQUE7SUFBQUMsUUFBQSxHQUFLLElBQUksZUFBQyxJQUFBWixXQUFBLENBQUFhLEdBQUEsRUFBQ1QsUUFBUSxJQUFFLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQUosV0FBQSxDQUFBYSxHQUFBLEVBQUNSLFlBQVksSUFBRSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFMLFdBQUEsQ0FBQWEsR0FBQTtNQUFNQyxTQUFTLEVBQUMsZUFBZTtNQUFBRixRQUFBLGVBQUMsSUFBQVosV0FBQSxDQUFBYSxHQUFBLEVBQUNQLE1BQU0sSUFBRTtJQUFDLENBQU0sQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBTixXQUFBLENBQUFhLEdBQUEsRUFBQ1YsV0FBVyxJQUFFLENBQUM7RUFBQSxDQUFFLENBQUM7QUFDcEk7QUFDZSxTQUFTWSxVQUFVQSxDQUFDYixLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUU7RUFDN0MsTUFBTTtJQUFDYyxPQUFPLEVBQUVDO0VBQVMsQ0FBQyxHQUFHO0lBQzNCLEdBQUcsSUFBQVYsNkJBQWtCLEVBQUMsQ0FBQztJQUN2QixHQUFHTCxLQUFLLENBQUNNO0VBQ1gsQ0FBQztFQUNELE9BQU9TLFNBQVMsZ0JBQUcsSUFBQWpCLFdBQUEsQ0FBQWEsR0FBQSxFQUFDSSxTQUFTO0lBQUEsR0FBS2YsS0FBSztJQUFBVSxRQUFBLGVBQUUsSUFBQVosV0FBQSxDQUFBYSxHQUFBLEVBQUNaLGlCQUFpQjtNQUFBLEdBQUtDO0lBQUssQ0FBRztFQUFDLENBQVcsQ0FBQyxHQUFHRCxpQkFBaUIsQ0FBQ0MsS0FBSyxDQUFDO0FBQ2xIO0FBQUNnQixFQUFBLEdBTnVCSCxVQUFVO0FBT2xDLFNBQVNOLG9CQUFvQkEsQ0FBQ1UsRUFBRSxFQUFFQyxTQUFTLEVBQUVDLEtBQUssRUFBRTtFQUNsRCxNQUFNLElBQUlDLEtBQUssQ0FBQyxXQUFXLElBQUlGLFNBQVMsR0FBRyxXQUFXLEdBQUcsUUFBUSxDQUFDLEdBQUcsSUFBSSxHQUFHRCxFQUFFLEdBQUcsb0VBQW9FLElBQUlFLEtBQUssR0FBRyxxQ0FBcUMsR0FBR0EsS0FBSyxHQUFHLGlDQUFpQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO0FBQzNQO0FBQUMsSUFBQUgsRUFBQTtBQUFBSyxZQUFBLENBQUFMLEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}