var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      h2: "h2",
      p: "p",
      strong: "strong",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      DocList,
      HeadingAnchor,
      Kbd,
      Lede,
      Quote,
      TagCloud
    } = _components;
  if (!DocList) _missingMdxReference("DocList", true, "8:1-8:139");
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  if (!Kbd) _missingMdxReference("Kbd", true, "18:7-18:20");
  if (!Lede) _missingMdxReference("Lede", true, "2:1-2:185");
  if (!Quote) _missingMdxReference("Quote", true, "4:1-6:9");
  if (!TagCloud) _missingMdxReference("TagCloud", true, "16:1-16:12");
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(Lede, {
      children: ["The company wiki — processes, policies, teams, and the phone book — as plain MDX entries that interlink. Most of this you change by ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "asking Grove"
      }), ", not by editing files."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(Quote, {
      cite: "Meridian onboarding guide",
      source: "content/handbook/onboarding.mdx",
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
        children: "Your first week is about meeting people and shipping one small thing — not reading every page of the handbook."
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(DocList, {
      shape: "feed",
      title: "Recently updated",
      slugs: "handbook/onboarding,processes/incident-response,reports/q2-2026,handbook/expenses"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "browse-by-area",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "browse-by-area"
      }), "Browse by area"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(DocList, {
      shape: "grid",
      slugs: "handbook/onboarding,teams/engineering,processes/incident-response,reports/q2-2026"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "tags",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "tags"
      }), "Tags"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(TagCloud, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Press ", /*#__PURE__*/(0, _jsxRuntime.jsx)(Kbd, {
        children: "⌘K"
      }), " to jump anywhere."]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/content/home.mdx`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJoMiIsInAiLCJzdHJvbmciLCJfcHJvdmlkZUNvbXBvbmVudHMiLCJjb21wb25lbnRzIiwiRG9jTGlzdCIsIkhlYWRpbmdBbmNob3IiLCJLYmQiLCJMZWRlIiwiUXVvdGUiLCJUYWdDbG91ZCIsIl9taXNzaW5nTWR4UmVmZXJlbmNlIiwianN4cyIsIkZyYWdtZW50IiwiY2hpbGRyZW4iLCJqc3giLCJjaXRlIiwic291cmNlIiwic2hhcGUiLCJ0aXRsZSIsInNsdWdzIiwiaWQiLCJNRFhDb250ZW50Iiwid3JhcHBlciIsIk1EWExheW91dCIsIl9jIiwiY29tcG9uZW50IiwicGxhY2UiLCJFcnJvciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbImhvbWUubWR4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qQGpzeFJ1bnRpbWUgYXV0b21hdGljKi9cbi8qQGpzeEltcG9ydFNvdXJjZSByZWFjdCovXG5pbXBvcnQge3VzZU1EWENvbXBvbmVudHMgYXMgX3Byb3ZpZGVDb21wb25lbnRzfSBmcm9tIFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGsvTURYUHJvdmlkZXJcIjtcbmZ1bmN0aW9uIF9jcmVhdGVNZHhDb250ZW50KHByb3BzKSB7XG4gIGNvbnN0IF9jb21wb25lbnRzID0ge1xuICAgIGgyOiBcImgyXCIsXG4gICAgcDogXCJwXCIsXG4gICAgc3Ryb25nOiBcInN0cm9uZ1wiLFxuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfSwge0RvY0xpc3QsIEhlYWRpbmdBbmNob3IsIEtiZCwgTGVkZSwgUXVvdGUsIFRhZ0Nsb3VkfSA9IF9jb21wb25lbnRzO1xuICBpZiAoIURvY0xpc3QpIF9taXNzaW5nTWR4UmVmZXJlbmNlKFwiRG9jTGlzdFwiLCB0cnVlLCBcIjg6MS04OjEzOVwiKTtcbiAgaWYgKCFIZWFkaW5nQW5jaG9yKSBfbWlzc2luZ01keFJlZmVyZW5jZShcIkhlYWRpbmdBbmNob3JcIiwgdHJ1ZSk7XG4gIGlmICghS2JkKSBfbWlzc2luZ01keFJlZmVyZW5jZShcIktiZFwiLCB0cnVlLCBcIjE4OjctMTg6MjBcIik7XG4gIGlmICghTGVkZSkgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJMZWRlXCIsIHRydWUsIFwiMjoxLTI6MTg1XCIpO1xuICBpZiAoIVF1b3RlKSBfbWlzc2luZ01keFJlZmVyZW5jZShcIlF1b3RlXCIsIHRydWUsIFwiNDoxLTY6OVwiKTtcbiAgaWYgKCFUYWdDbG91ZCkgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJUYWdDbG91ZFwiLCB0cnVlLCBcIjE2OjEtMTY6MTJcIik7XG4gIHJldHVybiA8PjxMZWRlPntcIlRoZSBjb21wYW55IHdpa2kg4oCUIHByb2Nlc3NlcywgcG9saWNpZXMsIHRlYW1zLCBhbmQgdGhlIHBob25lIGJvb2sg4oCUIGFzIHBsYWluIE1EWCBlbnRyaWVzIHRoYXQgaW50ZXJsaW5rLiBNb3N0IG9mIHRoaXMgeW91IGNoYW5nZSBieSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImFza2luZyBHcm92ZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgbm90IGJ5IGVkaXRpbmcgZmlsZXMuXCJ9PC9MZWRlPntcIlxcblwifTxRdW90ZSBjaXRlPVwiTWVyaWRpYW4gb25ib2FyZGluZyBndWlkZVwiIHNvdXJjZT1cImNvbnRlbnQvaGFuZGJvb2svb25ib2FyZGluZy5tZHhcIj48X2NvbXBvbmVudHMucD57XCJZb3VyIGZpcnN0IHdlZWsgaXMgYWJvdXQgbWVldGluZyBwZW9wbGUgYW5kIHNoaXBwaW5nIG9uZSBzbWFsbCB0aGluZyDigJQgbm90IHJlYWRpbmcgZXZlcnkgcGFnZSBvZiB0aGUgaGFuZGJvb2suXCJ9PC9fY29tcG9uZW50cy5wPjwvUXVvdGU+e1wiXFxuXCJ9PERvY0xpc3Qgc2hhcGU9XCJmZWVkXCIgdGl0bGU9XCJSZWNlbnRseSB1cGRhdGVkXCIgc2x1Z3M9XCJoYW5kYm9vay9vbmJvYXJkaW5nLHByb2Nlc3Nlcy9pbmNpZGVudC1yZXNwb25zZSxyZXBvcnRzL3EyLTIwMjYsaGFuZGJvb2svZXhwZW5zZXNcIiAvPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cImJyb3dzZS1ieS1hcmVhXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJicm93c2UtYnktYXJlYVwiIC8+e1wiQnJvd3NlIGJ5IGFyZWFcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxEb2NMaXN0IHNoYXBlPVwiZ3JpZFwiIHNsdWdzPVwiaGFuZGJvb2svb25ib2FyZGluZyx0ZWFtcy9lbmdpbmVlcmluZyxwcm9jZXNzZXMvaW5jaWRlbnQtcmVzcG9uc2UscmVwb3J0cy9xMi0yMDI2XCIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJ0YWdzXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJ0YWdzXCIgLz57XCJUYWdzXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08VGFnQ2xvdWQgLz57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJQcmVzcyBcIn08S2JkPntcIuKMmEtcIn08L0tiZD57XCIgdG8ganVtcCBhbnl3aGVyZS5cIn08L19jb21wb25lbnRzLnA+PC8+O1xufVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTURYQ29udGVudChwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHt3cmFwcGVyOiBNRFhMYXlvdXR9ID0ge1xuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfTtcbiAgcmV0dXJuIE1EWExheW91dCA/IDxNRFhMYXlvdXQgey4uLnByb3BzfT48X2NyZWF0ZU1keENvbnRlbnQgey4uLnByb3BzfSAvPjwvTURYTGF5b3V0PiA6IF9jcmVhdGVNZHhDb250ZW50KHByb3BzKTtcbn1cbmZ1bmN0aW9uIF9taXNzaW5nTWR4UmVmZXJlbmNlKGlkLCBjb21wb25lbnQsIHBsYWNlKSB7XG4gIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIFwiICsgKGNvbXBvbmVudCA/IFwiY29tcG9uZW50XCIgOiBcIm9iamVjdFwiKSArIFwiIGBcIiArIGlkICsgXCJgIHRvIGJlIGRlZmluZWQ6IHlvdSBsaWtlbHkgZm9yZ290IHRvIGltcG9ydCwgcGFzcywgb3IgcHJvdmlkZSBpdC5cIiArIChwbGFjZSA/IFwiXFxuSXTigJlzIHJlZmVyZW5jZWQgaW4geW91ciBjb2RlIGF0IGBcIiArIHBsYWNlICsgXCJgIGluIGAvYXBwL2NvbnRlbnQvaG9tZS5tZHhgXCIgOiBcIlwiKSk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUVBLElBQUFBLFlBQUEsR0FBQUMsT0FBQTtBQUF3RixJQUFBQyxXQUFBLEdBQUFELE9BQUE7QUFGeEY7QUFDQTs7QUFFQSxTQUFTRSxpQkFBaUJBLENBQUNDLEtBQUssRUFBRTtFQUNoQyxNQUFNQyxXQUFXLEdBQUc7TUFDbEJDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLENBQUMsRUFBRSxHQUFHO01BQ05DLE1BQU0sRUFBRSxRQUFRO01BQ2hCLEdBQUcsSUFBQUMsNkJBQWtCLEVBQUMsQ0FBQztNQUN2QixHQUFHTCxLQUFLLENBQUNNO0lBQ1gsQ0FBQztJQUFFO01BQUNDLE9BQU87TUFBRUMsYUFBYTtNQUFFQyxHQUFHO01BQUVDLElBQUk7TUFBRUMsS0FBSztNQUFFQztJQUFRLENBQUMsR0FBR1gsV0FBVztFQUNyRSxJQUFJLENBQUNNLE9BQU8sRUFBRU0sb0JBQW9CLENBQUMsU0FBUyxFQUFFLElBQUksRUFBRSxXQUFXLENBQUM7RUFDaEUsSUFBSSxDQUFDTCxhQUFhLEVBQUVLLG9CQUFvQixDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUM7RUFDL0QsSUFBSSxDQUFDSixHQUFHLEVBQUVJLG9CQUFvQixDQUFDLEtBQUssRUFBRSxJQUFJLEVBQUUsWUFBWSxDQUFDO0VBQ3pELElBQUksQ0FBQ0gsSUFBSSxFQUFFRyxvQkFBb0IsQ0FBQyxNQUFNLEVBQUUsSUFBSSxFQUFFLFdBQVcsQ0FBQztFQUMxRCxJQUFJLENBQUNGLEtBQUssRUFBRUUsb0JBQW9CLENBQUMsT0FBTyxFQUFFLElBQUksRUFBRSxTQUFTLENBQUM7RUFDMUQsSUFBSSxDQUFDRCxRQUFRLEVBQUVDLG9CQUFvQixDQUFDLFVBQVUsRUFBRSxJQUFJLEVBQUUsWUFBWSxDQUFDO0VBQ25FLG9CQUFPLElBQUFmLFdBQUEsQ0FBQWdCLElBQUEsRUFBQWhCLFdBQUEsQ0FBQWlCLFFBQUE7SUFBQUMsUUFBQSxnQkFBRSxJQUFBbEIsV0FBQSxDQUFBZ0IsSUFBQSxFQUFDSixJQUFJO01BQUFNLFFBQUEsR0FBRSxzSUFBc0ksZUFBQyxJQUFBbEIsV0FBQSxDQUFBbUIsR0FBQSxFQUFDaEIsV0FBVyxDQUFDRyxNQUFNO1FBQUFZLFFBQUEsRUFBRTtNQUFjLENBQXFCLENBQUMsRUFBQyx5QkFBeUI7SUFBQSxDQUFPLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ04sS0FBSztNQUFDTyxJQUFJLEVBQUMsMkJBQTJCO01BQUNDLE1BQU0sRUFBQyxpQ0FBaUM7TUFBQUgsUUFBQSxlQUFDLElBQUFsQixXQUFBLENBQUFtQixHQUFBLEVBQUNoQixXQUFXLENBQUNFLENBQUM7UUFBQWEsUUFBQSxFQUFFO01BQWdILENBQWdCO0lBQUMsQ0FBTyxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFsQixXQUFBLENBQUFtQixHQUFBLEVBQUNWLE9BQU87TUFBQ2EsS0FBSyxFQUFDLE1BQU07TUFBQ0MsS0FBSyxFQUFDLGtCQUFrQjtNQUFDQyxLQUFLLEVBQUM7SUFBbUYsQ0FBRSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF4QixXQUFBLENBQUFnQixJQUFBLEVBQUNiLFdBQVcsQ0FBQ0MsRUFBRTtNQUFDcUIsRUFBRSxFQUFDLGdCQUFnQjtNQUFBUCxRQUFBLGdCQUFDLElBQUFsQixXQUFBLENBQUFtQixHQUFBLEVBQUNULGFBQWE7UUFBQ2UsRUFBRSxFQUFDO01BQWdCLENBQUUsQ0FBQyxFQUFDLGdCQUFnQjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ1YsT0FBTztNQUFDYSxLQUFLLEVBQUMsTUFBTTtNQUFDRSxLQUFLLEVBQUM7SUFBbUYsQ0FBRSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF4QixXQUFBLENBQUFnQixJQUFBLEVBQUNiLFdBQVcsQ0FBQ0MsRUFBRTtNQUFDcUIsRUFBRSxFQUFDLE1BQU07TUFBQVAsUUFBQSxnQkFBQyxJQUFBbEIsV0FBQSxDQUFBbUIsR0FBQSxFQUFDVCxhQUFhO1FBQUNlLEVBQUUsRUFBQztNQUFNLENBQUUsQ0FBQyxFQUFDLE1BQU07SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUFtQixHQUFBLEVBQUNMLFFBQVEsSUFBRSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFkLFdBQUEsQ0FBQWdCLElBQUEsRUFBQ2IsV0FBVyxDQUFDRSxDQUFDO01BQUFhLFFBQUEsR0FBRSxRQUFRLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ1IsR0FBRztRQUFBTyxRQUFBLEVBQUU7TUFBSSxDQUFNLENBQUMsRUFBQyxvQkFBb0I7SUFBQSxDQUFnQixDQUFDO0VBQUEsQ0FBRSxDQUFDO0FBQzloQztBQUNlLFNBQVNRLFVBQVVBLENBQUN4QixLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUU7RUFDN0MsTUFBTTtJQUFDeUIsT0FBTyxFQUFFQztFQUFTLENBQUMsR0FBRztJQUMzQixHQUFHLElBQUFyQiw2QkFBa0IsRUFBQyxDQUFDO0lBQ3ZCLEdBQUdMLEtBQUssQ0FBQ007RUFDWCxDQUFDO0VBQ0QsT0FBT29CLFNBQVMsZ0JBQUcsSUFBQTVCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ1MsU0FBUztJQUFBLEdBQUsxQixLQUFLO0lBQUFnQixRQUFBLGVBQUUsSUFBQWxCLFdBQUEsQ0FBQW1CLEdBQUEsRUFBQ2xCLGlCQUFpQjtNQUFBLEdBQUtDO0lBQUssQ0FBRztFQUFDLENBQVcsQ0FBQyxHQUFHRCxpQkFBaUIsQ0FBQ0MsS0FBSyxDQUFDO0FBQ2xIO0FBQUMyQixFQUFBLEdBTnVCSCxVQUFVO0FBT2xDLFNBQVNYLG9CQUFvQkEsQ0FBQ1UsRUFBRSxFQUFFSyxTQUFTLEVBQUVDLEtBQUssRUFBRTtFQUNsRCxNQUFNLElBQUlDLEtBQUssQ0FBQyxXQUFXLElBQUlGLFNBQVMsR0FBRyxXQUFXLEdBQUcsUUFBUSxDQUFDLEdBQUcsSUFBSSxHQUFHTCxFQUFFLEdBQUcsb0VBQW9FLElBQUlNLEtBQUssR0FBRyxxQ0FBcUMsR0FBR0EsS0FBSyxHQUFHLDhCQUE4QixHQUFHLEVBQUUsQ0FBQyxDQUFDO0FBQ3hQO0FBQUMsSUFBQUYsRUFBQTtBQUFBSSxZQUFBLENBQUFKLEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}