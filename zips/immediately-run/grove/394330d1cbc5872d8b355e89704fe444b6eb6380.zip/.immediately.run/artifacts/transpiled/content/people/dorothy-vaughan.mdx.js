var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
    code: "code",
    p: "p",
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
    children: ["Dorothy Vaughan is ops manager on the the operations team. Reach them at ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
      children: "x4001"
    }), "."]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJjb2RlIiwicCIsIl9wcm92aWRlQ29tcG9uZW50cyIsImNvbXBvbmVudHMiLCJqc3hzIiwiY2hpbGRyZW4iLCJqc3giLCJNRFhDb250ZW50Iiwid3JhcHBlciIsIk1EWExheW91dCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiZG9yb3RoeS12YXVnaGFuLm1keCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKkBqc3hSdW50aW1lIGF1dG9tYXRpYyovXG4vKkBqc3hJbXBvcnRTb3VyY2UgcmVhY3QqL1xuaW1wb3J0IHt1c2VNRFhDb21wb25lbnRzIGFzIF9wcm92aWRlQ29tcG9uZW50c30gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrL01EWFByb3ZpZGVyXCI7XG5mdW5jdGlvbiBfY3JlYXRlTWR4Q29udGVudChwcm9wcykge1xuICBjb25zdCBfY29tcG9uZW50cyA9IHtcbiAgICBjb2RlOiBcImNvZGVcIixcbiAgICBwOiBcInBcIixcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH07XG4gIHJldHVybiA8X2NvbXBvbmVudHMucD57XCJEb3JvdGh5IFZhdWdoYW4gaXMgb3BzIG1hbmFnZXIgb24gdGhlIHRoZSBvcGVyYXRpb25zIHRlYW0uIFJlYWNoIHRoZW0gYXQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wieDQwMDFcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLlwifTwvX2NvbXBvbmVudHMucD47XG59XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNRFhDb250ZW50KHByb3BzID0ge30pIHtcbiAgY29uc3Qge3dyYXBwZXI6IE1EWExheW91dH0gPSB7XG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9O1xuICByZXR1cm4gTURYTGF5b3V0ID8gPE1EWExheW91dCB7Li4ucHJvcHN9PjxfY3JlYXRlTWR4Q29udGVudCB7Li4ucHJvcHN9IC8+PC9NRFhMYXlvdXQ+IDogX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFFQSxJQUFBQSxZQUFBLEdBQUFDLE9BQUE7QUFBd0YsSUFBQUMsV0FBQSxHQUFBRCxPQUFBO0FBRnhGO0FBQ0E7O0FBRUEsU0FBU0UsaUJBQWlCQSxDQUFDQyxLQUFLLEVBQUU7RUFDaEMsTUFBTUMsV0FBVyxHQUFHO0lBQ2xCQyxJQUFJLEVBQUUsTUFBTTtJQUNaQyxDQUFDLEVBQUUsR0FBRztJQUNOLEdBQUcsSUFBQUMsNkJBQWtCLEVBQUMsQ0FBQztJQUN2QixHQUFHSixLQUFLLENBQUNLO0VBQ1gsQ0FBQztFQUNELG9CQUFPLElBQUFQLFdBQUEsQ0FBQVEsSUFBQSxFQUFDTCxXQUFXLENBQUNFLENBQUM7SUFBQUksUUFBQSxHQUFFLDJFQUEyRSxlQUFDLElBQUFULFdBQUEsQ0FBQVUsR0FBQSxFQUFDUCxXQUFXLENBQUNDLElBQUk7TUFBQUssUUFBQSxFQUFFO0lBQU8sQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7RUFBQSxDQUFnQixDQUFDO0FBQ3hLO0FBQ2UsU0FBU0UsVUFBVUEsQ0FBQ1QsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFO0VBQzdDLE1BQU07SUFBQ1UsT0FBTyxFQUFFQztFQUFTLENBQUMsR0FBRztJQUMzQixHQUFHLElBQUFQLDZCQUFrQixFQUFDLENBQUM7SUFDdkIsR0FBR0osS0FBSyxDQUFDSztFQUNYLENBQUM7RUFDRCxPQUFPTSxTQUFTLGdCQUFHLElBQUFiLFdBQUEsQ0FBQVUsR0FBQSxFQUFDRyxTQUFTO0lBQUEsR0FBS1gsS0FBSztJQUFBTyxRQUFBLGVBQUUsSUFBQVQsV0FBQSxDQUFBVSxHQUFBLEVBQUNULGlCQUFpQjtNQUFBLEdBQUtDO0lBQUssQ0FBRztFQUFDLENBQVcsQ0FBQyxHQUFHRCxpQkFBaUIsQ0FBQ0MsS0FBSyxDQUFDO0FBQ2xIO0FBQUNZLEVBQUEsR0FOdUJILFVBQVU7QUFBQSxJQUFBRyxFQUFBO0FBQUFDLFlBQUEsQ0FBQUQsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}