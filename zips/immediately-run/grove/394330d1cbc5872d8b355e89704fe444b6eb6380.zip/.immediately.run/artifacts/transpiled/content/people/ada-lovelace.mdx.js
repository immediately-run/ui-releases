var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
    a: "a",
    code: "code",
    p: "p",
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
    children: ["Ada Lovelace is staff engineer on the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
      href: "/content/teams/engineering.mdx",
      children: "engineering"
    }), " team. Reach them at ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
      children: "x2204"
    }), "."]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiY29kZSIsInAiLCJfcHJvdmlkZUNvbXBvbmVudHMiLCJjb21wb25lbnRzIiwianN4cyIsImNoaWxkcmVuIiwianN4IiwiaHJlZiIsIk1EWENvbnRlbnQiLCJ3cmFwcGVyIiwiTURYTGF5b3V0IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJhZGEtbG92ZWxhY2UubWR4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qQGpzeFJ1bnRpbWUgYXV0b21hdGljKi9cbi8qQGpzeEltcG9ydFNvdXJjZSByZWFjdCovXG5pbXBvcnQge3VzZU1EWENvbXBvbmVudHMgYXMgX3Byb3ZpZGVDb21wb25lbnRzfSBmcm9tIFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGsvTURYUHJvdmlkZXJcIjtcbmZ1bmN0aW9uIF9jcmVhdGVNZHhDb250ZW50KHByb3BzKSB7XG4gIGNvbnN0IF9jb21wb25lbnRzID0ge1xuICAgIGE6IFwiYVwiLFxuICAgIGNvZGU6IFwiY29kZVwiLFxuICAgIHA6IFwicFwiLFxuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfTtcbiAgcmV0dXJuIDxfY29tcG9uZW50cy5wPntcIkFkYSBMb3ZlbGFjZSBpcyBzdGFmZiBlbmdpbmVlciBvbiB0aGUgXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cIi9jb250ZW50L3RlYW1zL2VuZ2luZWVyaW5nLm1keFwiPntcImVuZ2luZWVyaW5nXCJ9PC9fY29tcG9uZW50cy5hPntcIiB0ZWFtLiBSZWFjaCB0aGVtIGF0IFwifTxfY29tcG9uZW50cy5jb2RlPntcIngyMjA0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi5cIn08L19jb21wb25lbnRzLnA+O1xufVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTURYQ29udGVudChwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHt3cmFwcGVyOiBNRFhMYXlvdXR9ID0ge1xuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfTtcbiAgcmV0dXJuIE1EWExheW91dCA/IDxNRFhMYXlvdXQgey4uLnByb3BzfT48X2NyZWF0ZU1keENvbnRlbnQgey4uLnByb3BzfSAvPjwvTURYTGF5b3V0PiA6IF9jcmVhdGVNZHhDb250ZW50KHByb3BzKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQXdGLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUZ4RjtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU1DLFdBQVcsR0FBRztJQUNsQkMsQ0FBQyxFQUFFLEdBQUc7SUFDTkMsSUFBSSxFQUFFLE1BQU07SUFDWkMsQ0FBQyxFQUFFLEdBQUc7SUFDTixHQUFHLElBQUFDLDZCQUFrQixFQUFDLENBQUM7SUFDdkIsR0FBR0wsS0FBSyxDQUFDTTtFQUNYLENBQUM7RUFDRCxvQkFBTyxJQUFBUixXQUFBLENBQUFTLElBQUEsRUFBQ04sV0FBVyxDQUFDRyxDQUFDO0lBQUFJLFFBQUEsR0FBRSx3Q0FBd0MsZUFBQyxJQUFBVixXQUFBLENBQUFXLEdBQUEsRUFBQ1IsV0FBVyxDQUFDQyxDQUFDO01BQUNRLElBQUksRUFBQyxnQ0FBZ0M7TUFBQUYsUUFBQSxFQUFFO0lBQWEsQ0FBZ0IsQ0FBQyxFQUFDLHVCQUF1QixlQUFDLElBQUFWLFdBQUEsQ0FBQVcsR0FBQSxFQUFDUixXQUFXLENBQUNFLElBQUk7TUFBQUssUUFBQSxFQUFFO0lBQU8sQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7RUFBQSxDQUFnQixDQUFDO0FBQ2xQO0FBQ2UsU0FBU0csVUFBVUEsQ0FBQ1gsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFO0VBQzdDLE1BQU07SUFBQ1ksT0FBTyxFQUFFQztFQUFTLENBQUMsR0FBRztJQUMzQixHQUFHLElBQUFSLDZCQUFrQixFQUFDLENBQUM7SUFDdkIsR0FBR0wsS0FBSyxDQUFDTTtFQUNYLENBQUM7RUFDRCxPQUFPTyxTQUFTLGdCQUFHLElBQUFmLFdBQUEsQ0FBQVcsR0FBQSxFQUFDSSxTQUFTO0lBQUEsR0FBS2IsS0FBSztJQUFBUSxRQUFBLGVBQUUsSUFBQVYsV0FBQSxDQUFBVyxHQUFBLEVBQUNWLGlCQUFpQjtNQUFBLEdBQUtDO0lBQUssQ0FBRztFQUFDLENBQVcsQ0FBQyxHQUFHRCxpQkFBaUIsQ0FBQ0MsS0FBSyxDQUFDO0FBQ2xIO0FBQUNjLEVBQUEsR0FOdUJILFVBQVU7QUFBQSxJQUFBRyxFQUFBO0FBQUFDLFlBQUEsQ0FBQUQsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}