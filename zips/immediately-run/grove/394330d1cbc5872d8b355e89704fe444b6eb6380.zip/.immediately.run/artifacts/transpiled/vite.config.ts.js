"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _config = require("vitest/config");
var _pluginReact = _interopRequireDefault(require("@vitejs/plugin-react"));
var _rollup = _interopRequireDefault(require("@mdx-js/rollup"));
var _devFs = require("@immediately-run/dev-fs");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// MDX must run before @vitejs/plugin-react so the JSX it emits is handled by
// React's transform (Fast Refresh included). immediately.run processes .mdx
// natively; this wiring keeps the local `vite dev`/`build` in sync.
//
// devFs() (@immediately-run/dev-fs) makes `import ... from 'fs'` work during
// local `vite dev`, bridging the same async ZenFS surface immediately.run
// provides to your real disk. It is dev-only and absent from production builds.
// https://vite.dev/config/
var _default = exports.default = (0, _config.defineConfig)({
  plugins: [(0, _devFs.devFs)(), {
    enforce: 'pre',
    ...(0, _rollup.default)()
  }, (0, _pluginReact.default)()],
  // `fs` is provided by the dev-fs bridge in `vite dev` and by the immediately.run
  // host at runtime. immediately.run transpiles source directly (it never runs
  // this dist), so leave `fs` external in the production build rather than trying
  // to bundle a node builtin for the browser.
  build: {
    rollupOptions: {
      external: ['fs', 'node:fs']
    }
  },
  test: {
    include: ['src/**/*.test.{ts,tsx}'],
    // Installs the stub host transport the SDK's root module needs at import time —
    // see src/test/setup.ts. Without it a component test dies before it runs.
    setupFiles: ['src/test/setup.ts'],
    server: {
      // The SDK's own dist uses extensionless relative imports (`./SafeContent`),
      // which a bundler resolves and raw node ESM does not. Inlining it makes the
      // safe-renderer tests exercise the REAL published package — the same bytes the
      // sandbox resolves on immediately.run — instead of a stub. Without this the
      // suite fails at import with "Cannot find module …/safeContent/SafeContent".
      deps: {
        inline: ['@immediately-run/sdk']
      }
    }
  }
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY29uZmlnIiwicmVxdWlyZSIsIl9wbHVnaW5SZWFjdCIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJfcm9sbHVwIiwiX2RldkZzIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiX2RlZmF1bHQiLCJleHBvcnRzIiwiZGVmaW5lQ29uZmlnIiwicGx1Z2lucyIsImRldkZzIiwiZW5mb3JjZSIsIm1keCIsInJlYWN0IiwiYnVpbGQiLCJyb2xsdXBPcHRpb25zIiwiZXh0ZXJuYWwiLCJ0ZXN0IiwiaW5jbHVkZSIsInNldHVwRmlsZXMiLCJzZXJ2ZXIiLCJkZXBzIiwiaW5saW5lIl0sInNvdXJjZXMiOlsidml0ZS5jb25maWcudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgZGVmaW5lQ29uZmlnIH0gZnJvbSAndml0ZXN0L2NvbmZpZydcbmltcG9ydCByZWFjdCBmcm9tICdAdml0ZWpzL3BsdWdpbi1yZWFjdCdcbmltcG9ydCBtZHggZnJvbSAnQG1keC1qcy9yb2xsdXAnXG5pbXBvcnQgeyBkZXZGcyB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vZGV2LWZzJ1xuXG4vLyBNRFggbXVzdCBydW4gYmVmb3JlIEB2aXRlanMvcGx1Z2luLXJlYWN0IHNvIHRoZSBKU1ggaXQgZW1pdHMgaXMgaGFuZGxlZCBieVxuLy8gUmVhY3QncyB0cmFuc2Zvcm0gKEZhc3QgUmVmcmVzaCBpbmNsdWRlZCkuIGltbWVkaWF0ZWx5LnJ1biBwcm9jZXNzZXMgLm1keFxuLy8gbmF0aXZlbHk7IHRoaXMgd2lyaW5nIGtlZXBzIHRoZSBsb2NhbCBgdml0ZSBkZXZgL2BidWlsZGAgaW4gc3luYy5cbi8vXG4vLyBkZXZGcygpIChAaW1tZWRpYXRlbHktcnVuL2Rldi1mcykgbWFrZXMgYGltcG9ydCAuLi4gZnJvbSAnZnMnYCB3b3JrIGR1cmluZ1xuLy8gbG9jYWwgYHZpdGUgZGV2YCwgYnJpZGdpbmcgdGhlIHNhbWUgYXN5bmMgWmVuRlMgc3VyZmFjZSBpbW1lZGlhdGVseS5ydW5cbi8vIHByb3ZpZGVzIHRvIHlvdXIgcmVhbCBkaXNrLiBJdCBpcyBkZXYtb25seSBhbmQgYWJzZW50IGZyb20gcHJvZHVjdGlvbiBidWlsZHMuXG4vLyBodHRwczovL3ZpdGUuZGV2L2NvbmZpZy9cbmV4cG9ydCBkZWZhdWx0IGRlZmluZUNvbmZpZyh7XG4gIHBsdWdpbnM6IFtcbiAgICBkZXZGcygpLFxuICAgIHsgZW5mb3JjZTogJ3ByZScsIC4uLm1keCgpIH0sXG4gICAgcmVhY3QoKSxcbiAgXSxcbiAgLy8gYGZzYCBpcyBwcm92aWRlZCBieSB0aGUgZGV2LWZzIGJyaWRnZSBpbiBgdml0ZSBkZXZgIGFuZCBieSB0aGUgaW1tZWRpYXRlbHkucnVuXG4gIC8vIGhvc3QgYXQgcnVudGltZS4gaW1tZWRpYXRlbHkucnVuIHRyYW5zcGlsZXMgc291cmNlIGRpcmVjdGx5IChpdCBuZXZlciBydW5zXG4gIC8vIHRoaXMgZGlzdCksIHNvIGxlYXZlIGBmc2AgZXh0ZXJuYWwgaW4gdGhlIHByb2R1Y3Rpb24gYnVpbGQgcmF0aGVyIHRoYW4gdHJ5aW5nXG4gIC8vIHRvIGJ1bmRsZSBhIG5vZGUgYnVpbHRpbiBmb3IgdGhlIGJyb3dzZXIuXG4gIGJ1aWxkOiB7XG4gICAgcm9sbHVwT3B0aW9uczoge1xuICAgICAgZXh0ZXJuYWw6IFsnZnMnLCAnbm9kZTpmcyddLFxuICAgIH0sXG4gIH0sXG4gIHRlc3Q6IHtcbiAgICBpbmNsdWRlOiBbJ3NyYy8qKi8qLnRlc3Que3RzLHRzeH0nXSxcbiAgICAvLyBJbnN0YWxscyB0aGUgc3R1YiBob3N0IHRyYW5zcG9ydCB0aGUgU0RLJ3Mgcm9vdCBtb2R1bGUgbmVlZHMgYXQgaW1wb3J0IHRpbWUg4oCUXG4gICAgLy8gc2VlIHNyYy90ZXN0L3NldHVwLnRzLiBXaXRob3V0IGl0IGEgY29tcG9uZW50IHRlc3QgZGllcyBiZWZvcmUgaXQgcnVucy5cbiAgICBzZXR1cEZpbGVzOiBbJ3NyYy90ZXN0L3NldHVwLnRzJ10sXG4gICAgc2VydmVyOiB7XG4gICAgICAvLyBUaGUgU0RLJ3Mgb3duIGRpc3QgdXNlcyBleHRlbnNpb25sZXNzIHJlbGF0aXZlIGltcG9ydHMgKGAuL1NhZmVDb250ZW50YCksXG4gICAgICAvLyB3aGljaCBhIGJ1bmRsZXIgcmVzb2x2ZXMgYW5kIHJhdyBub2RlIEVTTSBkb2VzIG5vdC4gSW5saW5pbmcgaXQgbWFrZXMgdGhlXG4gICAgICAvLyBzYWZlLXJlbmRlcmVyIHRlc3RzIGV4ZXJjaXNlIHRoZSBSRUFMIHB1Ymxpc2hlZCBwYWNrYWdlIOKAlCB0aGUgc2FtZSBieXRlcyB0aGVcbiAgICAgIC8vIHNhbmRib3ggcmVzb2x2ZXMgb24gaW1tZWRpYXRlbHkucnVuIOKAlCBpbnN0ZWFkIG9mIGEgc3R1Yi4gV2l0aG91dCB0aGlzIHRoZVxuICAgICAgLy8gc3VpdGUgZmFpbHMgYXQgaW1wb3J0IHdpdGggXCJDYW5ub3QgZmluZCBtb2R1bGUg4oCmL3NhZmVDb250ZW50L1NhZmVDb250ZW50XCIuXG4gICAgICBkZXBzOiB7IGlubGluZTogWydAaW1tZWRpYXRlbHktcnVuL3NkayddIH0sXG4gICAgfSxcbiAgfSxcbn0pXG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUFBLElBQUFBLE9BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLFlBQUEsR0FBQUMsc0JBQUEsQ0FBQUYsT0FBQTtBQUNBLElBQUFHLE9BQUEsR0FBQUQsc0JBQUEsQ0FBQUYsT0FBQTtBQUNBLElBQUFJLE1BQUEsR0FBQUosT0FBQTtBQUErQyxTQUFBRSx1QkFBQUcsQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQUUvQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQUEsSUFBQUcsUUFBQSxHQUFBQyxPQUFBLENBQUFGLE9BQUEsR0FDZSxJQUFBRyxvQkFBWSxFQUFDO0VBQzFCQyxPQUFPLEVBQUUsQ0FDUCxJQUFBQyxZQUFLLEVBQUMsQ0FBQyxFQUNQO0lBQUVDLE9BQU8sRUFBRSxLQUFLO0lBQUUsR0FBRyxJQUFBQyxlQUFHLEVBQUM7RUFBRSxDQUFDLEVBQzVCLElBQUFDLG9CQUFLLEVBQUMsQ0FBQyxDQUNSO0VBQ0Q7RUFDQTtFQUNBO0VBQ0E7RUFDQUMsS0FBSyxFQUFFO0lBQ0xDLGFBQWEsRUFBRTtNQUNiQyxRQUFRLEVBQUUsQ0FBQyxJQUFJLEVBQUUsU0FBUztJQUM1QjtFQUNGLENBQUM7RUFDREMsSUFBSSxFQUFFO0lBQ0pDLE9BQU8sRUFBRSxDQUFDLHdCQUF3QixDQUFDO0lBQ25DO0lBQ0E7SUFDQUMsVUFBVSxFQUFFLENBQUMsbUJBQW1CLENBQUM7SUFDakNDLE1BQU0sRUFBRTtNQUNOO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQUMsSUFBSSxFQUFFO1FBQUVDLE1BQU0sRUFBRSxDQUFDLHNCQUFzQjtNQUFFO0lBQzNDO0VBQ0Y7QUFDRixDQUFDLENBQUMiLCJpZ25vcmVMaXN0IjpbXX0=