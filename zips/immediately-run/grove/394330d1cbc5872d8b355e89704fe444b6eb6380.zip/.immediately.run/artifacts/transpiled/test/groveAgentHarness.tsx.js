var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.push = exports.protocolRequest = exports.openPanel = exports.emit = void 0;
exports.renderAgent = renderAgent;
var _vitest = require("vitest");
var _react = require("react");
var _client = require("react-dom/client");
var _jsxRuntime = require("react/jsx-runtime");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; } // The shared harness for GroveAgent's wire-level tests.
//
// It lives OUTSIDE `src/` deliberately. `check:deps` walks `src/` for runtime imports and
// excludes only `*.test.*`, so a test helper under `src/` reads as app code and its
// `vitest` import as a missing runtime dependency — which is the gate working correctly,
// since the sandbox resolves an app's modules from `dependencies` alone.
//
// It was inline in `GroveAgent.test.tsx` until grove#75 round 3 needed a SECOND file: the
// `useCatalogAnswered` flag is module-global and never resets, so a case that must run
// with the catalog UNANSWERED cannot share a module registry with cases that answer it.
// Vitest isolates by file, so a separate file is the isolation — and copying sixty lines
// of harness to get it would be the duplication R6 forbids.
//
// Import this BEFORE anything that reads the SDK: installing the transport is a module
// side effect, and the SDK's channels resolve it lazily on first read.
const handlers = new Set();

/** Emit a host→app message to every channel subscriber. */
const emit = msg => {
  for (const h of handlers) h(msg);
};

/** Controllable per-case; the default resolves like a permissive host. */
exports.emit = emit;
const protocolRequest = exports.protocolRequest = _vitest.vi.fn(async () => ({}));

// An EMITTING stub transport. The transport contract (`hostTransport.ts`):
// `onMessage(handler)` receives EVERY host→app message; the SDK's addListener filters by
// `msg.type` itself.
globalThis.__immediatelyRun__ = {
  transport: {
    sendMessage: _vitest.vi.fn(),
    protocolRequest,
    onMessage: handler => {
      handlers.add(handler);
      return {
        dispose: () => handlers.delete(handler)
      };
    }
  }
};
const NAV = {
  mode: 'github',
  namespace: 'immediately-run',
  provider: 'github',
  repository: 'docs',
  ref: 'main',
  sandboxPath: '/app',
  hash: '',
  search: ''
};

/**
 * Render GroveAgent against the stub host.
 *
 * The SDK modules are imported HERE rather than at this module's top level so the
 * transport above is installed first.
 */
async function renderAgent(props, opts = {}) {
  const {
    default: GroveAgent
  } = await Promise.resolve().then(() => _interopRequireWildcard(require('../src/components/GroveAgent')));
  const {
    GroveShellContext
  } = await Promise.resolve().then(() => _interopRequireWildcard(require('../src/lib/shell')));
  const {
    TinkerableContext
  } = await Promise.resolve().then(() => _interopRequireWildcard(require('@immediately-run/sdk/TinkerableContext')));
  // `opts.shell` overrides fields for cases that need a shell that refuses (the edit
  // affordance probes); everything else takes the permissive default.
  const shell = {
    openEditor: _vitest.vi.fn(),
    ...opts.shell
  };
  const container = document.createElement('div');
  document.body.appendChild(container);
  const root = (0, _client.createRoot)(container);
  await (0, _react.act)(async () => {
    root.render(/*#__PURE__*/(0, _jsxRuntime.jsx)(GroveShellContext.Provider, {
      value: shell,
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(TinkerableContext.Provider, {
        value: {
          outerHref: '',
          navigationState: NAV,
          routingSpec: {},
          filesMetadata: {}
        },
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(GroveAgent, {
          ...props,
          entryKey: "/app/content/wiki/security.mdx",
          entryTitle: "Security"
        })
      })
    }));
  });
  return {
    root,
    container
  };
}
const openPanel = async container => {
  await (0, _react.act)(async () => {
    container.querySelector('.ga-line input')?.focus();
  });
};

/** Drive host→app pushes the way the host would: after the app subscribed. */
exports.openPanel = openPanel;
const push = async msg => {
  await (0, _react.act)(async () => {
    emit(msg);
  });
};
exports.push = push;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZXN0IiwicmVxdWlyZSIsIl9yZWFjdCIsIl9jbGllbnQiLCJfanN4UnVudGltZSIsIl9nZXRSZXF1aXJlV2lsZGNhcmRDYWNoZSIsImUiLCJXZWFrTWFwIiwiciIsInQiLCJfaW50ZXJvcFJlcXVpcmVXaWxkY2FyZCIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiaGFzIiwiZ2V0IiwibiIsIl9fcHJvdG9fXyIsImEiLCJPYmplY3QiLCJkZWZpbmVQcm9wZXJ0eSIsImdldE93blByb3BlcnR5RGVzY3JpcHRvciIsInUiLCJoYXNPd25Qcm9wZXJ0eSIsImNhbGwiLCJpIiwic2V0IiwiaGFuZGxlcnMiLCJTZXQiLCJlbWl0IiwibXNnIiwiaCIsImV4cG9ydHMiLCJwcm90b2NvbFJlcXVlc3QiLCJ2aSIsImZuIiwiZ2xvYmFsVGhpcyIsIl9faW1tZWRpYXRlbHlSdW5fXyIsInRyYW5zcG9ydCIsInNlbmRNZXNzYWdlIiwib25NZXNzYWdlIiwiaGFuZGxlciIsImFkZCIsImRpc3Bvc2UiLCJkZWxldGUiLCJOQVYiLCJtb2RlIiwibmFtZXNwYWNlIiwicHJvdmlkZXIiLCJyZXBvc2l0b3J5IiwicmVmIiwic2FuZGJveFBhdGgiLCJoYXNoIiwic2VhcmNoIiwicmVuZGVyQWdlbnQiLCJwcm9wcyIsIm9wdHMiLCJHcm92ZUFnZW50IiwiUHJvbWlzZSIsInJlc29sdmUiLCJ0aGVuIiwiR3JvdmVTaGVsbENvbnRleHQiLCJUaW5rZXJhYmxlQ29udGV4dCIsInNoZWxsIiwib3BlbkVkaXRvciIsImNvbnRhaW5lciIsImRvY3VtZW50IiwiY3JlYXRlRWxlbWVudCIsImJvZHkiLCJhcHBlbmRDaGlsZCIsInJvb3QiLCJjcmVhdGVSb290IiwiYWN0IiwicmVuZGVyIiwianN4IiwiUHJvdmlkZXIiLCJ2YWx1ZSIsImNoaWxkcmVuIiwib3V0ZXJIcmVmIiwibmF2aWdhdGlvblN0YXRlIiwicm91dGluZ1NwZWMiLCJmaWxlc01ldGFkYXRhIiwiZW50cnlLZXkiLCJlbnRyeVRpdGxlIiwib3BlblBhbmVsIiwicXVlcnlTZWxlY3RvciIsImZvY3VzIiwicHVzaCJdLCJzb3VyY2VzIjpbImdyb3ZlQWdlbnRIYXJuZXNzLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBUaGUgc2hhcmVkIGhhcm5lc3MgZm9yIEdyb3ZlQWdlbnQncyB3aXJlLWxldmVsIHRlc3RzLlxuLy9cbi8vIEl0IGxpdmVzIE9VVFNJREUgYHNyYy9gIGRlbGliZXJhdGVseS4gYGNoZWNrOmRlcHNgIHdhbGtzIGBzcmMvYCBmb3IgcnVudGltZSBpbXBvcnRzIGFuZFxuLy8gZXhjbHVkZXMgb25seSBgKi50ZXN0LipgLCBzbyBhIHRlc3QgaGVscGVyIHVuZGVyIGBzcmMvYCByZWFkcyBhcyBhcHAgY29kZSBhbmQgaXRzXG4vLyBgdml0ZXN0YCBpbXBvcnQgYXMgYSBtaXNzaW5nIHJ1bnRpbWUgZGVwZW5kZW5jeSDigJQgd2hpY2ggaXMgdGhlIGdhdGUgd29ya2luZyBjb3JyZWN0bHksXG4vLyBzaW5jZSB0aGUgc2FuZGJveCByZXNvbHZlcyBhbiBhcHAncyBtb2R1bGVzIGZyb20gYGRlcGVuZGVuY2llc2AgYWxvbmUuXG4vL1xuLy8gSXQgd2FzIGlubGluZSBpbiBgR3JvdmVBZ2VudC50ZXN0LnRzeGAgdW50aWwgZ3JvdmUjNzUgcm91bmQgMyBuZWVkZWQgYSBTRUNPTkQgZmlsZTogdGhlXG4vLyBgdXNlQ2F0YWxvZ0Fuc3dlcmVkYCBmbGFnIGlzIG1vZHVsZS1nbG9iYWwgYW5kIG5ldmVyIHJlc2V0cywgc28gYSBjYXNlIHRoYXQgbXVzdCBydW5cbi8vIHdpdGggdGhlIGNhdGFsb2cgVU5BTlNXRVJFRCBjYW5ub3Qgc2hhcmUgYSBtb2R1bGUgcmVnaXN0cnkgd2l0aCBjYXNlcyB0aGF0IGFuc3dlciBpdC5cbi8vIFZpdGVzdCBpc29sYXRlcyBieSBmaWxlLCBzbyBhIHNlcGFyYXRlIGZpbGUgaXMgdGhlIGlzb2xhdGlvbiDigJQgYW5kIGNvcHlpbmcgc2l4dHkgbGluZXNcbi8vIG9mIGhhcm5lc3MgdG8gZ2V0IGl0IHdvdWxkIGJlIHRoZSBkdXBsaWNhdGlvbiBSNiBmb3JiaWRzLlxuLy9cbi8vIEltcG9ydCB0aGlzIEJFRk9SRSBhbnl0aGluZyB0aGF0IHJlYWRzIHRoZSBTREs6IGluc3RhbGxpbmcgdGhlIHRyYW5zcG9ydCBpcyBhIG1vZHVsZVxuLy8gc2lkZSBlZmZlY3QsIGFuZCB0aGUgU0RLJ3MgY2hhbm5lbHMgcmVzb2x2ZSBpdCBsYXppbHkgb24gZmlyc3QgcmVhZC5cbmltcG9ydCB7IHZpIH0gZnJvbSAndml0ZXN0JztcbmltcG9ydCB7IGFjdCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IGNyZWF0ZVJvb3QsIHR5cGUgUm9vdCB9IGZyb20gJ3JlYWN0LWRvbS9jbGllbnQnO1xuXG50eXBlIEhhbmRsZXIgPSAobXNnOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikgPT4gdm9pZDtcblxuY29uc3QgaGFuZGxlcnMgPSBuZXcgU2V0PEhhbmRsZXI+KCk7XG5cbi8qKiBFbWl0IGEgaG9zdOKGkmFwcCBtZXNzYWdlIHRvIGV2ZXJ5IGNoYW5uZWwgc3Vic2NyaWJlci4gKi9cbmV4cG9ydCBjb25zdCBlbWl0ID0gKG1zZzogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiB2b2lkID0+IHtcbiAgZm9yIChjb25zdCBoIG9mIGhhbmRsZXJzKSBoKG1zZyk7XG59O1xuXG4vKiogQ29udHJvbGxhYmxlIHBlci1jYXNlOyB0aGUgZGVmYXVsdCByZXNvbHZlcyBsaWtlIGEgcGVybWlzc2l2ZSBob3N0LiAqL1xuZXhwb3J0IGNvbnN0IHByb3RvY29sUmVxdWVzdCA9IHZpLmZuKGFzeW5jICgpID0+ICh7fSkgYXMgdW5rbm93bik7XG5cbi8vIEFuIEVNSVRUSU5HIHN0dWIgdHJhbnNwb3J0LiBUaGUgdHJhbnNwb3J0IGNvbnRyYWN0IChgaG9zdFRyYW5zcG9ydC50c2ApOlxuLy8gYG9uTWVzc2FnZShoYW5kbGVyKWAgcmVjZWl2ZXMgRVZFUlkgaG9zdOKGkmFwcCBtZXNzYWdlOyB0aGUgU0RLJ3MgYWRkTGlzdGVuZXIgZmlsdGVycyBieVxuLy8gYG1zZy50eXBlYCBpdHNlbGYuXG4oZ2xvYmFsVGhpcyBhcyB7IF9faW1tZWRpYXRlbHlSdW5fXz86IHVua25vd24gfSkuX19pbW1lZGlhdGVseVJ1bl9fID0ge1xuICB0cmFuc3BvcnQ6IHtcbiAgICBzZW5kTWVzc2FnZTogdmkuZm4oKSxcbiAgICBwcm90b2NvbFJlcXVlc3QsXG4gICAgb25NZXNzYWdlOiAoaGFuZGxlcjogSGFuZGxlcikgPT4ge1xuICAgICAgaGFuZGxlcnMuYWRkKGhhbmRsZXIpO1xuICAgICAgcmV0dXJuIHsgZGlzcG9zZTogKCkgPT4gaGFuZGxlcnMuZGVsZXRlKGhhbmRsZXIpIH07XG4gICAgfSxcbiAgfSxcbn07XG5cbmNvbnN0IE5BViA9IHtcbiAgbW9kZTogJ2dpdGh1YicsXG4gIG5hbWVzcGFjZTogJ2ltbWVkaWF0ZWx5LXJ1bicsXG4gIHByb3ZpZGVyOiAnZ2l0aHViJyxcbiAgcmVwb3NpdG9yeTogJ2RvY3MnLFxuICByZWY6ICdtYWluJyxcbiAgc2FuZGJveFBhdGg6ICcvYXBwJyxcbiAgaGFzaDogJycsXG4gIHNlYXJjaDogJycsXG59O1xuXG4vKipcbiAqIFJlbmRlciBHcm92ZUFnZW50IGFnYWluc3QgdGhlIHN0dWIgaG9zdC5cbiAqXG4gKiBUaGUgU0RLIG1vZHVsZXMgYXJlIGltcG9ydGVkIEhFUkUgcmF0aGVyIHRoYW4gYXQgdGhpcyBtb2R1bGUncyB0b3AgbGV2ZWwgc28gdGhlXG4gKiB0cmFuc3BvcnQgYWJvdmUgaXMgaW5zdGFsbGVkIGZpcnN0LlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcmVuZGVyQWdlbnQoXG4gIHByb3BzOiB7IHdyaXRhYmxlOiBib29sZWFuIH0sXG4gIG9wdHM6IHsgc2hlbGw/OiBQYXJ0aWFsPGltcG9ydCgnLi4vc3JjL2xpYi9zaGVsbCcpLkdyb3ZlU2hlbGw+IH0gPSB7fSxcbik6IFByb21pc2U8eyByb290OiBSb290OyBjb250YWluZXI6IEhUTUxFbGVtZW50IH0+IHtcbiAgY29uc3QgeyBkZWZhdWx0OiBHcm92ZUFnZW50IH0gPSBhd2FpdCBpbXBvcnQoJy4uL3NyYy9jb21wb25lbnRzL0dyb3ZlQWdlbnQnKTtcbiAgY29uc3QgeyBHcm92ZVNoZWxsQ29udGV4dCB9ID0gYXdhaXQgaW1wb3J0KCcuLi9zcmMvbGliL3NoZWxsJyk7XG4gIGNvbnN0IHsgVGlua2VyYWJsZUNvbnRleHQgfSA9IGF3YWl0IGltcG9ydCgnQGltbWVkaWF0ZWx5LXJ1bi9zZGsvVGlua2VyYWJsZUNvbnRleHQnKTtcbiAgLy8gYG9wdHMuc2hlbGxgIG92ZXJyaWRlcyBmaWVsZHMgZm9yIGNhc2VzIHRoYXQgbmVlZCBhIHNoZWxsIHRoYXQgcmVmdXNlcyAodGhlIGVkaXRcbiAgLy8gYWZmb3JkYW5jZSBwcm9iZXMpOyBldmVyeXRoaW5nIGVsc2UgdGFrZXMgdGhlIHBlcm1pc3NpdmUgZGVmYXVsdC5cbiAgY29uc3Qgc2hlbGwgPSB7IG9wZW5FZGl0b3I6IHZpLmZuKCksIC4uLm9wdHMuc2hlbGwgfSBhcyB1bmtub3duIGFzIGltcG9ydCgnLi4vc3JjL2xpYi9zaGVsbCcpLkdyb3ZlU2hlbGw7XG5cbiAgY29uc3QgY29udGFpbmVyID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoY29udGFpbmVyKTtcbiAgY29uc3Qgcm9vdCA9IGNyZWF0ZVJvb3QoY29udGFpbmVyKTtcbiAgYXdhaXQgYWN0KGFzeW5jICgpID0+IHtcbiAgICByb290LnJlbmRlcihcbiAgICAgIDxHcm92ZVNoZWxsQ29udGV4dC5Qcm92aWRlciB2YWx1ZT17c2hlbGx9PlxuICAgICAgICA8VGlua2VyYWJsZUNvbnRleHQuUHJvdmlkZXJcbiAgICAgICAgICB2YWx1ZT17eyBvdXRlckhyZWY6ICcnLCBuYXZpZ2F0aW9uU3RhdGU6IE5BViwgcm91dGluZ1NwZWM6IHt9IGFzIG5ldmVyLCBmaWxlc01ldGFkYXRhOiB7fSB9fVxuICAgICAgICA+XG4gICAgICAgICAgPEdyb3ZlQWdlbnQgey4uLnByb3BzfSBlbnRyeUtleT1cIi9hcHAvY29udGVudC93aWtpL3NlY3VyaXR5Lm1keFwiIGVudHJ5VGl0bGU9XCJTZWN1cml0eVwiIC8+XG4gICAgICAgIDwvVGlua2VyYWJsZUNvbnRleHQuUHJvdmlkZXI+XG4gICAgICA8L0dyb3ZlU2hlbGxDb250ZXh0LlByb3ZpZGVyPixcbiAgICApO1xuICB9KTtcbiAgcmV0dXJuIHsgcm9vdCwgY29udGFpbmVyIH07XG59XG5cbmV4cG9ydCBjb25zdCBvcGVuUGFuZWwgPSBhc3luYyAoY29udGFpbmVyOiBIVE1MRWxlbWVudCk6IFByb21pc2U8dm9pZD4gPT4ge1xuICBhd2FpdCBhY3QoYXN5bmMgKCkgPT4ge1xuICAgIChjb250YWluZXIucXVlcnlTZWxlY3RvcignLmdhLWxpbmUgaW5wdXQnKSBhcyBIVE1MSW5wdXRFbGVtZW50KT8uZm9jdXMoKTtcbiAgfSk7XG59O1xuXG4vKiogRHJpdmUgaG9zdOKGkmFwcCBwdXNoZXMgdGhlIHdheSB0aGUgaG9zdCB3b3VsZDogYWZ0ZXIgdGhlIGFwcCBzdWJzY3JpYmVkLiAqL1xuZXhwb3J0IGNvbnN0IHB1c2ggPSBhc3luYyAobXNnOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IFByb21pc2U8dm9pZD4gPT4ge1xuICBhd2FpdCBhY3QoYXN5bmMgKCkgPT4ge1xuICAgIGVtaXQobXNnKTtcbiAgfSk7XG59O1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBZUEsSUFBQUEsT0FBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsTUFBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsT0FBQSxHQUFBRixPQUFBO0FBQXlELElBQUFHLFdBQUEsR0FBQUgsT0FBQTtBQUFBLFNBQUFJLHlCQUFBQyxDQUFBLDZCQUFBQyxPQUFBLG1CQUFBQyxDQUFBLE9BQUFELE9BQUEsSUFBQUUsQ0FBQSxPQUFBRixPQUFBLFlBQUFGLHdCQUFBLFlBQUFBLENBQUFDLENBQUEsV0FBQUEsQ0FBQSxHQUFBRyxDQUFBLEdBQUFELENBQUEsS0FBQUYsQ0FBQTtBQUFBLFNBQUFJLHdCQUFBSixDQUFBLEVBQUFFLENBQUEsU0FBQUEsQ0FBQSxJQUFBRixDQUFBLElBQUFBLENBQUEsQ0FBQUssVUFBQSxTQUFBTCxDQUFBLGVBQUFBLENBQUEsdUJBQUFBLENBQUEseUJBQUFBLENBQUEsV0FBQU0sT0FBQSxFQUFBTixDQUFBLFFBQUFHLENBQUEsR0FBQUosd0JBQUEsQ0FBQUcsQ0FBQSxPQUFBQyxDQUFBLElBQUFBLENBQUEsQ0FBQUksR0FBQSxDQUFBUCxDQUFBLFVBQUFHLENBQUEsQ0FBQUssR0FBQSxDQUFBUixDQUFBLE9BQUFTLENBQUEsS0FBQUMsU0FBQSxVQUFBQyxDQUFBLEdBQUFDLE1BQUEsQ0FBQUMsY0FBQSxJQUFBRCxNQUFBLENBQUFFLHdCQUFBLFdBQUFDLENBQUEsSUFBQWYsQ0FBQSxvQkFBQWUsQ0FBQSxPQUFBQyxjQUFBLENBQUFDLElBQUEsQ0FBQWpCLENBQUEsRUFBQWUsQ0FBQSxTQUFBRyxDQUFBLEdBQUFQLENBQUEsR0FBQUMsTUFBQSxDQUFBRSx3QkFBQSxDQUFBZCxDQUFBLEVBQUFlLENBQUEsVUFBQUcsQ0FBQSxLQUFBQSxDQUFBLENBQUFWLEdBQUEsSUFBQVUsQ0FBQSxDQUFBQyxHQUFBLElBQUFQLE1BQUEsQ0FBQUMsY0FBQSxDQUFBSixDQUFBLEVBQUFNLENBQUEsRUFBQUcsQ0FBQSxJQUFBVCxDQUFBLENBQUFNLENBQUEsSUFBQWYsQ0FBQSxDQUFBZSxDQUFBLFlBQUFOLENBQUEsQ0FBQUgsT0FBQSxHQUFBTixDQUFBLEVBQUFHLENBQUEsSUFBQUEsQ0FBQSxDQUFBZ0IsR0FBQSxDQUFBbkIsQ0FBQSxFQUFBUyxDQUFBLEdBQUFBLENBQUEsSUFqQnpEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQU9BLE1BQU1XLFFBQVEsR0FBRyxJQUFJQyxHQUFHLENBQVUsQ0FBQzs7QUFFbkM7QUFDTyxNQUFNQyxJQUFJLEdBQUlDLEdBQTRCLElBQVc7RUFDMUQsS0FBSyxNQUFNQyxDQUFDLElBQUlKLFFBQVEsRUFBRUksQ0FBQyxDQUFDRCxHQUFHLENBQUM7QUFDbEMsQ0FBQzs7QUFFRDtBQUFBRSxPQUFBLENBQUFILElBQUEsR0FBQUEsSUFBQTtBQUNPLE1BQU1JLGVBQWUsR0FBQUQsT0FBQSxDQUFBQyxlQUFBLEdBQUdDLFVBQUUsQ0FBQ0MsRUFBRSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQVksQ0FBQzs7QUFFakU7QUFDQTtBQUNBO0FBQ0NDLFVBQVUsQ0FBc0NDLGtCQUFrQixHQUFHO0VBQ3BFQyxTQUFTLEVBQUU7SUFDVEMsV0FBVyxFQUFFTCxVQUFFLENBQUNDLEVBQUUsQ0FBQyxDQUFDO0lBQ3BCRixlQUFlO0lBQ2ZPLFNBQVMsRUFBR0MsT0FBZ0IsSUFBSztNQUMvQmQsUUFBUSxDQUFDZSxHQUFHLENBQUNELE9BQU8sQ0FBQztNQUNyQixPQUFPO1FBQUVFLE9BQU8sRUFBRUEsQ0FBQSxLQUFNaEIsUUFBUSxDQUFDaUIsTUFBTSxDQUFDSCxPQUFPO01BQUUsQ0FBQztJQUNwRDtFQUNGO0FBQ0YsQ0FBQztBQUVELE1BQU1JLEdBQUcsR0FBRztFQUNWQyxJQUFJLEVBQUUsUUFBUTtFQUNkQyxTQUFTLEVBQUUsaUJBQWlCO0VBQzVCQyxRQUFRLEVBQUUsUUFBUTtFQUNsQkMsVUFBVSxFQUFFLE1BQU07RUFDbEJDLEdBQUcsRUFBRSxNQUFNO0VBQ1hDLFdBQVcsRUFBRSxNQUFNO0VBQ25CQyxJQUFJLEVBQUUsRUFBRTtFQUNSQyxNQUFNLEVBQUU7QUFDVixDQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLGVBQWVDLFdBQVdBLENBQy9CQyxLQUE0QixFQUM1QkMsSUFBZ0UsR0FBRyxDQUFDLENBQUMsRUFDcEI7RUFDakQsTUFBTTtJQUFFM0MsT0FBTyxFQUFFNEM7RUFBVyxDQUFDLEdBQUcsTUFBQUMsT0FBQSxDQUFBQyxPQUFBLEdBQUFDLElBQUEsT0FBQWpELHVCQUFBLENBQUFULE9BQUEsQ0FBYSw4QkFBOEIsR0FBQztFQUM1RSxNQUFNO0lBQUUyRDtFQUFrQixDQUFDLEdBQUcsTUFBQUgsT0FBQSxDQUFBQyxPQUFBLEdBQUFDLElBQUEsT0FBQWpELHVCQUFBLENBQUFULE9BQUEsQ0FBYSxrQkFBa0IsR0FBQztFQUM5RCxNQUFNO0lBQUU0RDtFQUFrQixDQUFDLEdBQUcsTUFBQUosT0FBQSxDQUFBQyxPQUFBLEdBQUFDLElBQUEsT0FBQWpELHVCQUFBLENBQUFULE9BQUEsQ0FBYSx3Q0FBd0MsR0FBQztFQUNwRjtFQUNBO0VBQ0EsTUFBTTZELEtBQUssR0FBRztJQUFFQyxVQUFVLEVBQUU5QixVQUFFLENBQUNDLEVBQUUsQ0FBQyxDQUFDO0lBQUUsR0FBR3FCLElBQUksQ0FBQ087RUFBTSxDQUFxRDtFQUV4RyxNQUFNRSxTQUFTLEdBQUdDLFFBQVEsQ0FBQ0MsYUFBYSxDQUFDLEtBQUssQ0FBQztFQUMvQ0QsUUFBUSxDQUFDRSxJQUFJLENBQUNDLFdBQVcsQ0FBQ0osU0FBUyxDQUFDO0VBQ3BDLE1BQU1LLElBQUksR0FBRyxJQUFBQyxrQkFBVSxFQUFDTixTQUFTLENBQUM7RUFDbEMsTUFBTSxJQUFBTyxVQUFHLEVBQUMsWUFBWTtJQUNwQkYsSUFBSSxDQUFDRyxNQUFNLGNBQ1QsSUFBQXBFLFdBQUEsQ0FBQXFFLEdBQUEsRUFBQ2IsaUJBQWlCLENBQUNjLFFBQVE7TUFBQ0MsS0FBSyxFQUFFYixLQUFNO01BQUFjLFFBQUEsZUFDdkMsSUFBQXhFLFdBQUEsQ0FBQXFFLEdBQUEsRUFBQ1osaUJBQWlCLENBQUNhLFFBQVE7UUFDekJDLEtBQUssRUFBRTtVQUFFRSxTQUFTLEVBQUUsRUFBRTtVQUFFQyxlQUFlLEVBQUVsQyxHQUFHO1VBQUVtQyxXQUFXLEVBQUUsQ0FBQyxDQUFVO1VBQUVDLGFBQWEsRUFBRSxDQUFDO1FBQUUsQ0FBRTtRQUFBSixRQUFBLGVBRTVGLElBQUF4RSxXQUFBLENBQUFxRSxHQUFBLEVBQUNqQixVQUFVO1VBQUEsR0FBS0YsS0FBSztVQUFFMkIsUUFBUSxFQUFDLGdDQUFnQztVQUFDQyxVQUFVLEVBQUM7UUFBVSxDQUFFO01BQUMsQ0FDL0Q7SUFBQyxDQUNILENBQzlCLENBQUM7RUFDSCxDQUFDLENBQUM7RUFDRixPQUFPO0lBQUViLElBQUk7SUFBRUw7RUFBVSxDQUFDO0FBQzVCO0FBRU8sTUFBTW1CLFNBQVMsR0FBRyxNQUFPbkIsU0FBc0IsSUFBb0I7RUFDeEUsTUFBTSxJQUFBTyxVQUFHLEVBQUMsWUFBWTtJQUNuQlAsU0FBUyxDQUFDb0IsYUFBYSxDQUFDLGdCQUFnQixDQUFDLEVBQXVCQyxLQUFLLENBQUMsQ0FBQztFQUMxRSxDQUFDLENBQUM7QUFDSixDQUFDOztBQUVEO0FBQUF0RCxPQUFBLENBQUFvRCxTQUFBLEdBQUFBLFNBQUE7QUFDTyxNQUFNRyxJQUFJLEdBQUcsTUFBT3pELEdBQTRCLElBQW9CO0VBQ3pFLE1BQU0sSUFBQTBDLFVBQUcsRUFBQyxZQUFZO0lBQ3BCM0MsSUFBSSxDQUFDQyxHQUFHLENBQUM7RUFDWCxDQUFDLENBQUM7QUFDSixDQUFDO0FBQUNFLE9BQUEsQ0FBQXVELElBQUEsR0FBQUEsSUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}