var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      p: "p",
      pre: "pre",
      strong: "strong",
      table: "table",
      tbody: "tbody",
      td: "td",
      th: "th",
      thead: "thead",
      tr: "tr",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "theming-grove",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "theming-grove"
      }), "Theming Grove"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["A Grove theme is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "token-only"
      }), ": one block of custom properties, no selectors, no\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "url()"
      }), ", no ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "@font-face"
      }), " — nothing but declarations. This file is the single place\nthe contract is stated; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "scripts/check-theme-token-only.mjs"
      }), " enforces it in\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "npm run verify"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "the-four-looks",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-four-looks"
      }), "The four looks"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "id"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "opens in"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "reading face"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "default"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "dark"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Public Sans (Gabarito display, Space Mono details)"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "archive"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "light"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Source Serif 4 — dense, contents-forward"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "journal"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "light"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Lora — warm, short measure"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "editorial"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "dark"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Public Sans — loud through weight and colour"
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Every look ships ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "both polarities"
      }), "; the reader (or the host's own light/dark)\npicks within it, and a corpus declares its own with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "theme: <id>"
      }), " on the home\nentry (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "frontmatter.engine"
      }), " owns the key). Precedence: reader override → author\ndeclaration → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "default"
      }), "; polarity: reader → host → the theme's preferred."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "the-token-surface",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-token-surface"
      }), "The token surface"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The palette (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "--bg --panel --panel-2 --line --line-2 --ink --ink-2 --ink-3 --accent --accent-2 --accent-3 --grad --glow --wash"
      }), "), the type roles\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "--disp --sans --mono"
      }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "--sans"
      }), " is the body face ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "whatever face that is"
      }), ";\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "archive"
      }), " puts a serif in it), and the shape/reading knobs (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "--disp-weight --prose-measure --prose-leading --radius-shape"
      }), ")."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Two structural sets are ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "engine-owned"
      }), ", never a theme's: the radii ladder\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "--r-xs … --r-pill"
      }), ") and the shadow set — a theme reaches the visual radius\nthrough ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "--radius-shape"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "faces-and-images-are-declared-never-named",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "faces-and-images-are-declared-never-named"
      }), "Faces and images are declared, never named"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["A theme that changes the reading face declares it (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/data/themeFonts.ts"
      }), ":"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-ts",
        children: "fonts: [{ family: 'Lora', src: '/app/assets/fonts/lora-latin-400-normal.woff2', weight: '400' }]\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [") and the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "engine"
      }), " reads the bytes and mints a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "blob:"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "@font-face"
      }), " in the\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "grove.engine"
      }), " cascade layer. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "blob:"
      }), " passes ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "img-src"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "font-src"
      }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "style-src"
      }), "\nin every composition mode, and nothing breaks offline. A remote ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "@import"
      }), " is the\nwithdrawn exception — it fails both of those properties. Named image assets work\nthe same way (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "assets:"
      }), " → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "--asset-<name>"
      }), ")."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "contrast-is-checked-not-eyeballed",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "contrast-is-checked-not-eyeballed"
      }), "Contrast is checked, not eyeballed"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "scripts/check-theme-contrast.mjs"
      }), " asserts AA floors (body ink tiers 4.5:1 on\nevery ground; accent 3:1) for every catalogue theme in both polarities, from the\ndeclared tokens, on every ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "npm run verify"
      }), ". A palette that misses the floor fails\nthe build."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "where-themes-live",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "where-themes-live"
      }), "Where themes live"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The catalogue (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/data/themes.ts"
      }), ") and the token blocks\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/GroveApp.css"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "[data-grove-theme=\"<id>\"]"
      }), " + its polarity pair) must agree —\nthe contrast check reads both and fails if they drift. The composition modes\n(fork · dispatch · pinned library) are described in the\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "./README.md",
        children: "README"
      }), "; the engine/content boundary in\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "./docs/ENGINE_BOUNDARY.md",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "docs/ENGINE_BOUNDARY.md"
        })
      }), "."]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/THEMING.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiY29kZSIsImVtIiwiaDEiLCJoMiIsInAiLCJwcmUiLCJzdHJvbmciLCJ0YWJsZSIsInRib2R5IiwidGQiLCJ0aCIsInRoZWFkIiwidHIiLCJfcHJvdmlkZUNvbXBvbmVudHMiLCJjb21wb25lbnRzIiwiSGVhZGluZ0FuY2hvciIsIl9taXNzaW5nTWR4UmVmZXJlbmNlIiwianN4cyIsIkZyYWdtZW50IiwiY2hpbGRyZW4iLCJpZCIsImpzeCIsImNsYXNzTmFtZSIsImhyZWYiLCJNRFhDb250ZW50Iiwid3JhcHBlciIsIk1EWExheW91dCIsIl9jIiwiY29tcG9uZW50IiwicGxhY2UiLCJFcnJvciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlRIRU1JTkcubWQiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgYTogXCJhXCIsXG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgZW06IFwiZW1cIixcbiAgICBoMTogXCJoMVwiLFxuICAgIGgyOiBcImgyXCIsXG4gICAgcDogXCJwXCIsXG4gICAgcHJlOiBcInByZVwiLFxuICAgIHN0cm9uZzogXCJzdHJvbmdcIixcbiAgICB0YWJsZTogXCJ0YWJsZVwiLFxuICAgIHRib2R5OiBcInRib2R5XCIsXG4gICAgdGQ6IFwidGRcIixcbiAgICB0aDogXCJ0aFwiLFxuICAgIHRoZWFkOiBcInRoZWFkXCIsXG4gICAgdHI6IFwidHJcIixcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH0sIHtIZWFkaW5nQW5jaG9yfSA9IF9jb21wb25lbnRzO1xuICBpZiAoIUhlYWRpbmdBbmNob3IpIF9taXNzaW5nTWR4UmVmZXJlbmNlKFwiSGVhZGluZ0FuY2hvclwiLCB0cnVlKTtcbiAgcmV0dXJuIDw+PF9jb21wb25lbnRzLmgxIGlkPVwidGhlbWluZy1ncm92ZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwidGhlbWluZy1ncm92ZVwiIC8+e1wiVGhlbWluZyBHcm92ZVwifTwvX2NvbXBvbmVudHMuaDE+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiQSBHcm92ZSB0aGVtZSBpcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInRva2VuLW9ubHlcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCI6IG9uZSBibG9jayBvZiBjdXN0b20gcHJvcGVydGllcywgbm8gc2VsZWN0b3JzLCBub1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcInVybCgpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgbm8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQGZvbnQtZmFjZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIG5vdGhpbmcgYnV0IGRlY2xhcmF0aW9ucy4gVGhpcyBmaWxlIGlzIHRoZSBzaW5nbGUgcGxhY2VcXG50aGUgY29udHJhY3QgaXMgc3RhdGVkOyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzY3JpcHRzL2NoZWNrLXRoZW1lLXRva2VuLW9ubHkubWpzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBlbmZvcmNlcyBpdCBpblxcblwifTxfY29tcG9uZW50cy5jb2RlPntcIm5wbSBydW4gdmVyaWZ5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwidGhlLWZvdXItbG9va3NcIj48SGVhZGluZ0FuY2hvciBpZD1cInRoZS1mb3VyLWxvb2tzXCIgLz57XCJUaGUgZm91ciBsb29rc1wifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnRhYmxlPjxfY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRoPntcImlkXCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGg+e1wib3BlbnMgaW5cIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aD57XCJyZWFkaW5nIGZhY2VcIn08L19jb21wb25lbnRzLnRoPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudGJvZHk+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJkZWZhdWx0XCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcImRhcmtcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJQdWJsaWMgU2FucyAoR2FiYXJpdG8gZGlzcGxheSwgU3BhY2UgTW9ubyBkZXRhaWxzKVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcImFyY2hpdmVcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wibGlnaHRcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJTb3VyY2UgU2VyaWYgNCDigJQgZGVuc2UsIGNvbnRlbnRzLWZvcndhcmRcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJqb3VybmFsXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcImxpZ2h0XCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiTG9yYSDigJQgd2FybSwgc2hvcnQgbWVhc3VyZVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcImVkaXRvcmlhbFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJkYXJrXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiUHVibGljIFNhbnMg4oCUIGxvdWQgdGhyb3VnaCB3ZWlnaHQgYW5kIGNvbG91clwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRib2R5PjwvX2NvbXBvbmVudHMudGFibGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiRXZlcnkgbG9vayBzaGlwcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImJvdGggcG9sYXJpdGllc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIjsgdGhlIHJlYWRlciAob3IgdGhlIGhvc3QncyBvd24gbGlnaHQvZGFyaylcXG5waWNrcyB3aXRoaW4gaXQsIGFuZCBhIGNvcnB1cyBkZWNsYXJlcyBpdHMgb3duIHdpdGggXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widGhlbWU6IDxpZD5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG9uIHRoZSBob21lXFxuZW50cnkgKFwifTxfY29tcG9uZW50cy5jb2RlPntcImZyb250bWF0dGVyLmVuZ2luZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgb3ducyB0aGUga2V5KS4gUHJlY2VkZW5jZTogcmVhZGVyIG92ZXJyaWRlIOKGkiBhdXRob3JcXG5kZWNsYXJhdGlvbiDihpIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZGVmYXVsdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCI7IHBvbGFyaXR5OiByZWFkZXIg4oaSIGhvc3Qg4oaSIHRoZSB0aGVtZSdzIHByZWZlcnJlZC5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwidGhlLXRva2VuLXN1cmZhY2VcIj48SGVhZGluZ0FuY2hvciBpZD1cInRoZS10b2tlbi1zdXJmYWNlXCIgLz57XCJUaGUgdG9rZW4gc3VyZmFjZVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIHBhbGV0dGUgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIi0tYmcgLS1wYW5lbCAtLXBhbmVsLTIgLS1saW5lIC0tbGluZS0yIC0taW5rIC0taW5rLTIgLS1pbmstMyAtLWFjY2VudCAtLWFjY2VudC0yIC0tYWNjZW50LTMgLS1ncmFkIC0tZ2xvdyAtLXdhc2hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSwgdGhlIHR5cGUgcm9sZXNcXG4oXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1kaXNwIC0tc2FucyAtLW1vbm9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCBcIn08X2NvbXBvbmVudHMuY29kZT57XCItLXNhbnNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGlzIHRoZSBib2R5IGZhY2UgXCJ9PF9jb21wb25lbnRzLmVtPntcIndoYXRldmVyIGZhY2UgdGhhdCBpc1wifTwvX2NvbXBvbmVudHMuZW0+e1wiO1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcImFyY2hpdmVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHB1dHMgYSBzZXJpZiBpbiBpdCksIGFuZCB0aGUgc2hhcGUvcmVhZGluZyBrbm9icyAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1kaXNwLXdlaWdodCAtLXByb3NlLW1lYXN1cmUgLS1wcm9zZS1sZWFkaW5nIC0tcmFkaXVzLXNoYXBlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlR3byBzdHJ1Y3R1cmFsIHNldHMgYXJlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZW5naW5lLW93bmVkXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBuZXZlciBhIHRoZW1lJ3M6IHRoZSByYWRpaSBsYWRkZXJcXG4oXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1yLXhzIOKApiAtLXItcGlsbFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpIGFuZCB0aGUgc2hhZG93IHNldCDigJQgYSB0aGVtZSByZWFjaGVzIHRoZSB2aXN1YWwgcmFkaXVzXFxudGhyb3VnaCBcIn08X2NvbXBvbmVudHMuY29kZT57XCItLXJhZGl1cy1zaGFwZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cImZhY2VzLWFuZC1pbWFnZXMtYXJlLWRlY2xhcmVkLW5ldmVyLW5hbWVkXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJmYWNlcy1hbmQtaW1hZ2VzLWFyZS1kZWNsYXJlZC1uZXZlci1uYW1lZFwiIC8+e1wiRmFjZXMgYW5kIGltYWdlcyBhcmUgZGVjbGFyZWQsIG5ldmVyIG5hbWVkXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJBIHRoZW1lIHRoYXQgY2hhbmdlcyB0aGUgcmVhZGluZyBmYWNlIGRlY2xhcmVzIGl0IChcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvZGF0YS90aGVtZUZvbnRzLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnByZT48X2NvbXBvbmVudHMuY29kZSBjbGFzc05hbWU9XCJsYW5ndWFnZS10c1wiPntcImZvbnRzOiBbeyBmYW1pbHk6ICdMb3JhJywgc3JjOiAnL2FwcC9hc3NldHMvZm9udHMvbG9yYS1sYXRpbi00MDAtbm9ybWFsLndvZmYyJywgd2VpZ2h0OiAnNDAwJyB9XVxcblwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnByZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCIpIGFuZCB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJlbmdpbmVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgcmVhZHMgdGhlIGJ5dGVzIGFuZCBtaW50cyBhIFwifTxfY29tcG9uZW50cy5jb2RlPntcImJsb2I6XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJAZm9udC1mYWNlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpbiB0aGVcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJncm92ZS5lbmdpbmVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNhc2NhZGUgbGF5ZXIuIFwifTxfY29tcG9uZW50cy5jb2RlPntcImJsb2I6XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBwYXNzZXMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW1nLXNyY1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcImZvbnQtc3JjXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhbmQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3R5bGUtc3JjXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIlxcbmluIGV2ZXJ5IGNvbXBvc2l0aW9uIG1vZGUsIGFuZCBub3RoaW5nIGJyZWFrcyBvZmZsaW5lLiBBIHJlbW90ZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJAaW1wb3J0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpcyB0aGVcXG53aXRoZHJhd24gZXhjZXB0aW9uIOKAlCBpdCBmYWlscyBib3RoIG9mIHRob3NlIHByb3BlcnRpZXMuIE5hbWVkIGltYWdlIGFzc2V0cyB3b3JrXFxudGhlIHNhbWUgd2F5IChcIn08X2NvbXBvbmVudHMuY29kZT57XCJhc3NldHM6XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDihpIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1hc3NldC08bmFtZT5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiKS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwiY29udHJhc3QtaXMtY2hlY2tlZC1ub3QtZXllYmFsbGVkXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJjb250cmFzdC1pcy1jaGVja2VkLW5vdC1leWViYWxsZWRcIiAvPntcIkNvbnRyYXN0IGlzIGNoZWNrZWQsIG5vdCBleWViYWxsZWRcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5jb2RlPntcInNjcmlwdHMvY2hlY2stdGhlbWUtY29udHJhc3QubWpzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhc3NlcnRzIEFBIGZsb29ycyAoYm9keSBpbmsgdGllcnMgNC41OjEgb25cXG5ldmVyeSBncm91bmQ7IGFjY2VudCAzOjEpIGZvciBldmVyeSBjYXRhbG9ndWUgdGhlbWUgaW4gYm90aCBwb2xhcml0aWVzLCBmcm9tIHRoZVxcbmRlY2xhcmVkIHRva2Vucywgb24gZXZlcnkgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibnBtIHJ1biB2ZXJpZnlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLiBBIHBhbGV0dGUgdGhhdCBtaXNzZXMgdGhlIGZsb29yIGZhaWxzXFxudGhlIGJ1aWxkLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJ3aGVyZS10aGVtZXMtbGl2ZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwid2hlcmUtdGhlbWVzLWxpdmVcIiAvPntcIldoZXJlIHRoZW1lcyBsaXZlXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgY2F0YWxvZ3VlIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvZGF0YS90aGVtZXMudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSBhbmQgdGhlIHRva2VuIGJsb2Nrc1xcbihcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvR3JvdmVBcHAuY3NzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiW2RhdGEtZ3JvdmUtdGhlbWU9XFxcIjxpZD5cXFwiXVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKyBpdHMgcG9sYXJpdHkgcGFpcikgbXVzdCBhZ3JlZSDigJRcXG50aGUgY29udHJhc3QgY2hlY2sgcmVhZHMgYm90aCBhbmQgZmFpbHMgaWYgdGhleSBkcmlmdC4gVGhlIGNvbXBvc2l0aW9uIG1vZGVzXFxuKGZvcmsgwrcgZGlzcGF0Y2ggwrcgcGlubmVkIGxpYnJhcnkpIGFyZSBkZXNjcmliZWQgaW4gdGhlXFxuXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cIi4vUkVBRE1FLm1kXCI+e1wiUkVBRE1FXCJ9PC9fY29tcG9uZW50cy5hPntcIjsgdGhlIGVuZ2luZS9jb250ZW50IGJvdW5kYXJ5IGluXFxuXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cIi4vZG9jcy9FTkdJTkVfQk9VTkRBUlkubWRcIj48X2NvbXBvbmVudHMuY29kZT57XCJkb2NzL0VOR0lORV9CT1VOREFSWS5tZFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLmE+e1wiLlwifTwvX2NvbXBvbmVudHMucD48Lz47XG59XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNRFhDb250ZW50KHByb3BzID0ge30pIHtcbiAgY29uc3Qge3dyYXBwZXI6IE1EWExheW91dH0gPSB7XG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9O1xuICByZXR1cm4gTURYTGF5b3V0ID8gPE1EWExheW91dCB7Li4ucHJvcHN9PjxfY3JlYXRlTWR4Q29udGVudCB7Li4ucHJvcHN9IC8+PC9NRFhMYXlvdXQ+IDogX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpO1xufVxuZnVuY3Rpb24gX21pc3NpbmdNZHhSZWZlcmVuY2UoaWQsIGNvbXBvbmVudCwgcGxhY2UpIHtcbiAgdGhyb3cgbmV3IEVycm9yKFwiRXhwZWN0ZWQgXCIgKyAoY29tcG9uZW50ID8gXCJjb21wb25lbnRcIiA6IFwib2JqZWN0XCIpICsgXCIgYFwiICsgaWQgKyBcImAgdG8gYmUgZGVmaW5lZDogeW91IGxpa2VseSBmb3Jnb3QgdG8gaW1wb3J0LCBwYXNzLCBvciBwcm92aWRlIGl0LlwiICsgKHBsYWNlID8gXCJcXG5JdOKAmXMgcmVmZXJlbmNlZCBpbiB5b3VyIGNvZGUgYXQgYFwiICsgcGxhY2UgKyBcImAgaW4gYC9hcHAvVEhFTUlORy5tZGBcIiA6IFwiXCIpKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQXdGLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUZ4RjtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU1DLFdBQVcsR0FBRztNQUNsQkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsSUFBSSxFQUFFLE1BQU07TUFDWkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsR0FBRyxFQUFFLEtBQUs7TUFDVkMsTUFBTSxFQUFFLFFBQVE7TUFDaEJDLEtBQUssRUFBRSxPQUFPO01BQ2RDLEtBQUssRUFBRSxPQUFPO01BQ2RDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEtBQUssRUFBRSxPQUFPO01BQ2RDLEVBQUUsRUFBRSxJQUFJO01BQ1IsR0FBRyxJQUFBQyw2QkFBa0IsRUFBQyxDQUFDO01BQ3ZCLEdBQUdoQixLQUFLLENBQUNpQjtJQUNYLENBQUM7SUFBRTtNQUFDQztJQUFhLENBQUMsR0FBR2pCLFdBQVc7RUFDaEMsSUFBSSxDQUFDaUIsYUFBYSxFQUFFQyxvQkFBb0IsQ0FBQyxlQUFlLEVBQUUsSUFBSSxDQUFDO0VBQy9ELG9CQUFPLElBQUFyQixXQUFBLENBQUFzQixJQUFBLEVBQUF0QixXQUFBLENBQUF1QixRQUFBO0lBQUFDLFFBQUEsZ0JBQUUsSUFBQXhCLFdBQUEsQ0FBQXNCLElBQUEsRUFBQ25CLFdBQVcsQ0FBQ0ksRUFBRTtNQUFDa0IsRUFBRSxFQUFDLGVBQWU7TUFBQUQsUUFBQSxnQkFBQyxJQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFlLENBQUUsQ0FBQyxFQUFDLGVBQWU7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUFzQixJQUFBLEVBQUNuQixXQUFXLENBQUNNLENBQUM7TUFBQWUsUUFBQSxHQUFFLG1CQUFtQixlQUFDLElBQUF4QixXQUFBLENBQUEwQixHQUFBLEVBQUN2QixXQUFXLENBQUNRLE1BQU07UUFBQWEsUUFBQSxFQUFFO01BQVksQ0FBcUIsQ0FBQyxFQUFDLHNEQUFzRCxlQUFDLElBQUF4QixXQUFBLENBQUEwQixHQUFBLEVBQUN2QixXQUFXLENBQUNFLElBQUk7UUFBQW1CLFFBQUEsRUFBRTtNQUFPLENBQW1CLENBQUMsRUFBQyxPQUFPLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQTBCLEdBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBbUIsUUFBQSxFQUFFO01BQVksQ0FBbUIsQ0FBQyxFQUFDLHNGQUFzRixlQUFDLElBQUF4QixXQUFBLENBQUEwQixHQUFBLEVBQUN2QixXQUFXLENBQUNFLElBQUk7UUFBQW1CLFFBQUEsRUFBRTtNQUFvQyxDQUFtQixDQUFDLEVBQUMsbUJBQW1CLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQTBCLEdBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBbUIsUUFBQSxFQUFFO01BQWdCLENBQW1CLENBQUMsRUFBQyxHQUFHO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBeEIsV0FBQSxDQUFBc0IsSUFBQSxFQUFDbkIsV0FBVyxDQUFDSyxFQUFFO01BQUNpQixFQUFFLEVBQUMsZ0JBQWdCO01BQUFELFFBQUEsZ0JBQUMsSUFBQXhCLFdBQUEsQ0FBQTBCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBZ0IsQ0FBRSxDQUFDLEVBQUMsZ0JBQWdCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBc0IsSUFBQSxFQUFDbkIsV0FBVyxDQUFDUyxLQUFLO01BQUFZLFFBQUEsZ0JBQUMsSUFBQXhCLFdBQUEsQ0FBQTBCLEdBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2EsS0FBSztRQUFBUSxRQUFBLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQXNCLElBQUEsRUFBQ25CLFdBQVcsQ0FBQ2MsRUFBRTtVQUFBTyxRQUFBLGdCQUFDLElBQUF4QixXQUFBLENBQUEwQixHQUFBLEVBQUN2QixXQUFXLENBQUNZLEVBQUU7WUFBQVMsUUFBQSxFQUFFO1VBQUksQ0FBaUIsQ0FBQyxtQkFBQXhCLFdBQUEsQ0FBQTBCLEdBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBUyxRQUFBLEVBQUU7VUFBVSxDQUFpQixDQUFDLG1CQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDdkIsV0FBVyxDQUFDWSxFQUFFO1lBQUFTLFFBQUEsRUFBRTtVQUFjLENBQWlCLENBQUM7UUFBQSxDQUFnQjtNQUFDLENBQW1CLENBQUMsbUJBQUF4QixXQUFBLENBQUFzQixJQUFBLEVBQUNuQixXQUFXLENBQUNVLEtBQUs7UUFBQVcsUUFBQSxnQkFBQyxJQUFBeEIsV0FBQSxDQUFBc0IsSUFBQSxFQUFDbkIsV0FBVyxDQUFDYyxFQUFFO1VBQUFPLFFBQUEsZ0JBQUMsSUFBQXhCLFdBQUEsQ0FBQTBCLEdBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1csRUFBRTtZQUFBVSxRQUFBLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQTBCLEdBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBbUIsUUFBQSxFQUFFO1lBQVMsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDdkIsV0FBVyxDQUFDVyxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFNLENBQWlCLENBQUMsbUJBQUF4QixXQUFBLENBQUEwQixHQUFBLEVBQUN2QixXQUFXLENBQUNXLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQW9ELENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBeEIsV0FBQSxDQUFBc0IsSUFBQSxFQUFDbkIsV0FBVyxDQUFDYyxFQUFFO1VBQUFPLFFBQUEsZ0JBQUMsSUFBQXhCLFdBQUEsQ0FBQTBCLEdBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1csRUFBRTtZQUFBVSxRQUFBLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQTBCLEdBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBbUIsUUFBQSxFQUFFO1lBQVMsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDdkIsV0FBVyxDQUFDVyxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFPLENBQWlCLENBQUMsbUJBQUF4QixXQUFBLENBQUEwQixHQUFBLEVBQUN2QixXQUFXLENBQUNXLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQTBDLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBeEIsV0FBQSxDQUFBc0IsSUFBQSxFQUFDbkIsV0FBVyxDQUFDYyxFQUFFO1VBQUFPLFFBQUEsZ0JBQUMsSUFBQXhCLFdBQUEsQ0FBQTBCLEdBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1csRUFBRTtZQUFBVSxRQUFBLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQTBCLEdBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBbUIsUUFBQSxFQUFFO1lBQVMsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDdkIsV0FBVyxDQUFDVyxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFPLENBQWlCLENBQUMsbUJBQUF4QixXQUFBLENBQUEwQixHQUFBLEVBQUN2QixXQUFXLENBQUNXLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQTRCLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBeEIsV0FBQSxDQUFBc0IsSUFBQSxFQUFDbkIsV0FBVyxDQUFDYyxFQUFFO1VBQUFPLFFBQUEsZ0JBQUMsSUFBQXhCLFdBQUEsQ0FBQTBCLEdBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1csRUFBRTtZQUFBVSxRQUFBLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQTBCLEdBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBbUIsUUFBQSxFQUFFO1lBQVcsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDdkIsV0FBVyxDQUFDVyxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFNLENBQWlCLENBQUMsbUJBQUF4QixXQUFBLENBQUEwQixHQUFBLEVBQUN2QixXQUFXLENBQUNXLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQThDLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDO01BQUEsQ0FBbUIsQ0FBQztJQUFBLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQXNCLElBQUEsRUFBQ25CLFdBQVcsQ0FBQ00sQ0FBQztNQUFBZSxRQUFBLEdBQUUsbUJBQW1CLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQTBCLEdBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsTUFBTTtRQUFBYSxRQUFBLEVBQUU7TUFBaUIsQ0FBcUIsQ0FBQyxFQUFDLG1HQUFtRyxlQUFDLElBQUF4QixXQUFBLENBQUEwQixHQUFBLEVBQUN2QixXQUFXLENBQUNFLElBQUk7UUFBQW1CLFFBQUEsRUFBRTtNQUFhLENBQW1CLENBQUMsRUFBQyx1QkFBdUIsZUFBQyxJQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDdkIsV0FBVyxDQUFDRSxJQUFJO1FBQUFtQixRQUFBLEVBQUU7TUFBb0IsQ0FBbUIsQ0FBQyxFQUFDLHNFQUFzRSxlQUFDLElBQUF4QixXQUFBLENBQUEwQixHQUFBLEVBQUN2QixXQUFXLENBQUNFLElBQUk7UUFBQW1CLFFBQUEsRUFBRTtNQUFTLENBQW1CLENBQUMsRUFBQyxvREFBb0Q7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF4QixXQUFBLENBQUFzQixJQUFBLEVBQUNuQixXQUFXLENBQUNLLEVBQUU7TUFBQ2lCLEVBQUUsRUFBQyxtQkFBbUI7TUFBQUQsUUFBQSxnQkFBQyxJQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFtQixDQUFFLENBQUMsRUFBQyxtQkFBbUI7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUFzQixJQUFBLEVBQUNuQixXQUFXLENBQUNNLENBQUM7TUFBQWUsUUFBQSxHQUFFLGVBQWUsZUFBQyxJQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDdkIsV0FBVyxDQUFDRSxJQUFJO1FBQUFtQixRQUFBLEVBQUU7TUFBa0gsQ0FBbUIsQ0FBQyxFQUFDLHNCQUFzQixlQUFDLElBQUF4QixXQUFBLENBQUEwQixHQUFBLEVBQUN2QixXQUFXLENBQUNFLElBQUk7UUFBQW1CLFFBQUEsRUFBRTtNQUFzQixDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUF4QixXQUFBLENBQUEwQixHQUFBLEVBQUN2QixXQUFXLENBQUNFLElBQUk7UUFBQW1CLFFBQUEsRUFBRTtNQUFRLENBQW1CLENBQUMsRUFBQyxvQkFBb0IsZUFBQyxJQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDdkIsV0FBVyxDQUFDRyxFQUFFO1FBQUFrQixRQUFBLEVBQUU7TUFBdUIsQ0FBaUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDdkIsV0FBVyxDQUFDRSxJQUFJO1FBQUFtQixRQUFBLEVBQUU7TUFBUyxDQUFtQixDQUFDLEVBQUMscURBQXFELGVBQUMsSUFBQXhCLFdBQUEsQ0FBQTBCLEdBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBbUIsUUFBQSxFQUFFO01BQThELENBQW1CLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBeEIsV0FBQSxDQUFBc0IsSUFBQSxFQUFDbkIsV0FBVyxDQUFDTSxDQUFDO01BQUFlLFFBQUEsR0FBRSwwQkFBMEIsZUFBQyxJQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDdkIsV0FBVyxDQUFDUSxNQUFNO1FBQUFhLFFBQUEsRUFBRTtNQUFjLENBQXFCLENBQUMsRUFBQyx3Q0FBd0MsZUFBQyxJQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDdkIsV0FBVyxDQUFDRSxJQUFJO1FBQUFtQixRQUFBLEVBQUU7TUFBbUIsQ0FBbUIsQ0FBQyxFQUFDLG9FQUFvRSxlQUFDLElBQUF4QixXQUFBLENBQUEwQixHQUFBLEVBQUN2QixXQUFXLENBQUNFLElBQUk7UUFBQW1CLFFBQUEsRUFBRTtNQUFnQixDQUFtQixDQUFDLEVBQUMsR0FBRztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQXNCLElBQUEsRUFBQ25CLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDaUIsRUFBRSxFQUFDLDJDQUEyQztNQUFBRCxRQUFBLGdCQUFDLElBQUF4QixXQUFBLENBQUEwQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQTJDLENBQUUsQ0FBQyxFQUFDLDRDQUE0QztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXNCLElBQUEsRUFBQ25CLFdBQVcsQ0FBQ00sQ0FBQztNQUFBZSxRQUFBLEdBQUUscURBQXFELGVBQUMsSUFBQXhCLFdBQUEsQ0FBQTBCLEdBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBbUIsUUFBQSxFQUFFO01BQXdCLENBQW1CLENBQUMsRUFBQyxHQUFHO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDdkIsV0FBVyxDQUFDTyxHQUFHO01BQUFjLFFBQUEsZUFBQyxJQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDdkIsV0FBVyxDQUFDRSxJQUFJO1FBQUNzQixTQUFTLEVBQUMsYUFBYTtRQUFBSCxRQUFBLEVBQUU7TUFBb0csQ0FBbUI7SUFBQyxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF4QixXQUFBLENBQUFzQixJQUFBLEVBQUNuQixXQUFXLENBQUNNLENBQUM7TUFBQWUsUUFBQSxHQUFFLFlBQVksZUFBQyxJQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDdkIsV0FBVyxDQUFDUSxNQUFNO1FBQUFhLFFBQUEsRUFBRTtNQUFRLENBQXFCLENBQUMsRUFBQywrQkFBK0IsZUFBQyxJQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDdkIsV0FBVyxDQUFDRSxJQUFJO1FBQUFtQixRQUFBLEVBQUU7TUFBTyxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUF4QixXQUFBLENBQUEwQixHQUFBLEVBQUN2QixXQUFXLENBQUNFLElBQUk7UUFBQW1CLFFBQUEsRUFBRTtNQUFZLENBQW1CLENBQUMsRUFBQyxXQUFXLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQTBCLEdBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBbUIsUUFBQSxFQUFFO01BQWMsQ0FBbUIsQ0FBQyxFQUFDLGtCQUFrQixlQUFDLElBQUF4QixXQUFBLENBQUEwQixHQUFBLEVBQUN2QixXQUFXLENBQUNFLElBQUk7UUFBQW1CLFFBQUEsRUFBRTtNQUFPLENBQW1CLENBQUMsRUFBQyxVQUFVLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQTBCLEdBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBbUIsUUFBQSxFQUFFO01BQVMsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDdkIsV0FBVyxDQUFDRSxJQUFJO1FBQUFtQixRQUFBLEVBQUU7TUFBVSxDQUFtQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUF4QixXQUFBLENBQUEwQixHQUFBLEVBQUN2QixXQUFXLENBQUNFLElBQUk7UUFBQW1CLFFBQUEsRUFBRTtNQUFXLENBQW1CLENBQUMsRUFBQyxvRUFBb0UsZUFBQyxJQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDdkIsV0FBVyxDQUFDRSxJQUFJO1FBQUFtQixRQUFBLEVBQUU7TUFBUyxDQUFtQixDQUFDLEVBQUMsMkdBQTJHLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQTBCLEdBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBbUIsUUFBQSxFQUFFO01BQVMsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDdkIsV0FBVyxDQUFDRSxJQUFJO1FBQUFtQixRQUFBLEVBQUU7TUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF4QixXQUFBLENBQUFzQixJQUFBLEVBQUNuQixXQUFXLENBQUNLLEVBQUU7TUFBQ2lCLEVBQUUsRUFBQyxtQ0FBbUM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFtQyxDQUFFLENBQUMsRUFBQyxvQ0FBb0M7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUFzQixJQUFBLEVBQUNuQixXQUFXLENBQUNNLENBQUM7TUFBQWUsUUFBQSxnQkFBQyxJQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDdkIsV0FBVyxDQUFDRSxJQUFJO1FBQUFtQixRQUFBLEVBQUU7TUFBa0MsQ0FBbUIsQ0FBQyxFQUFDLDJKQUEySixlQUFDLElBQUF4QixXQUFBLENBQUEwQixHQUFBLEVBQUN2QixXQUFXLENBQUNFLElBQUk7UUFBQW1CLFFBQUEsRUFBRTtNQUFnQixDQUFtQixDQUFDLEVBQUMscURBQXFEO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBeEIsV0FBQSxDQUFBc0IsSUFBQSxFQUFDbkIsV0FBVyxDQUFDSyxFQUFFO01BQUNpQixFQUFFLEVBQUMsbUJBQW1CO01BQUFELFFBQUEsZ0JBQUMsSUFBQXhCLFdBQUEsQ0FBQTBCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBbUIsQ0FBRSxDQUFDLEVBQUMsbUJBQW1CO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBc0IsSUFBQSxFQUFDbkIsV0FBVyxDQUFDTSxDQUFDO01BQUFlLFFBQUEsR0FBRSxpQkFBaUIsZUFBQyxJQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDdkIsV0FBVyxDQUFDRSxJQUFJO1FBQUFtQixRQUFBLEVBQUU7TUFBb0IsQ0FBbUIsQ0FBQyxFQUFDLDJCQUEyQixlQUFDLElBQUF4QixXQUFBLENBQUEwQixHQUFBLEVBQUN2QixXQUFXLENBQUNFLElBQUk7UUFBQW1CLFFBQUEsRUFBRTtNQUFrQixDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF4QixXQUFBLENBQUEwQixHQUFBLEVBQUN2QixXQUFXLENBQUNFLElBQUk7UUFBQW1CLFFBQUEsRUFBRTtNQUE2QixDQUFtQixDQUFDLEVBQUMsNktBQTZLLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQTBCLEdBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ0MsQ0FBQztRQUFDd0IsSUFBSSxFQUFDLGFBQWE7UUFBQUosUUFBQSxFQUFFO01BQVEsQ0FBZ0IsQ0FBQyxFQUFDLG9DQUFvQyxlQUFDLElBQUF4QixXQUFBLENBQUEwQixHQUFBLEVBQUN2QixXQUFXLENBQUNDLENBQUM7UUFBQ3dCLElBQUksRUFBQywyQkFBMkI7UUFBQUosUUFBQSxlQUFDLElBQUF4QixXQUFBLENBQUEwQixHQUFBLEVBQUN2QixXQUFXLENBQUNFLElBQUk7VUFBQW1CLFFBQUEsRUFBRTtRQUF5QixDQUFtQjtNQUFDLENBQWUsQ0FBQyxFQUFDLEdBQUc7SUFBQSxDQUFnQixDQUFDO0VBQUEsQ0FBRSxDQUFDO0FBQ254TTtBQUNlLFNBQVNLLFVBQVVBLENBQUMzQixLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUU7RUFDN0MsTUFBTTtJQUFDNEIsT0FBTyxFQUFFQztFQUFTLENBQUMsR0FBRztJQUMzQixHQUFHLElBQUFiLDZCQUFrQixFQUFDLENBQUM7SUFDdkIsR0FBR2hCLEtBQUssQ0FBQ2lCO0VBQ1gsQ0FBQztFQUNELE9BQU9ZLFNBQVMsZ0JBQUcsSUFBQS9CLFdBQUEsQ0FBQTBCLEdBQUEsRUFBQ0ssU0FBUztJQUFBLEdBQUs3QixLQUFLO0lBQUFzQixRQUFBLGVBQUUsSUFBQXhCLFdBQUEsQ0FBQTBCLEdBQUEsRUFBQ3pCLGlCQUFpQjtNQUFBLEdBQUtDO0lBQUssQ0FBRztFQUFDLENBQVcsQ0FBQyxHQUFHRCxpQkFBaUIsQ0FBQ0MsS0FBSyxDQUFDO0FBQ2xIO0FBQUM4QixFQUFBLEdBTnVCSCxVQUFVO0FBT2xDLFNBQVNSLG9CQUFvQkEsQ0FBQ0ksRUFBRSxFQUFFUSxTQUFTLEVBQUVDLEtBQUssRUFBRTtFQUNsRCxNQUFNLElBQUlDLEtBQUssQ0FBQyxXQUFXLElBQUlGLFNBQVMsR0FBRyxXQUFXLEdBQUcsUUFBUSxDQUFDLEdBQUcsSUFBSSxHQUFHUixFQUFFLEdBQUcsb0VBQW9FLElBQUlTLEtBQUssR0FBRyxxQ0FBcUMsR0FBR0EsS0FBSyxHQUFHLHdCQUF3QixHQUFHLEVBQUUsQ0FBQyxDQUFDO0FBQ2xQO0FBQUMsSUFBQUYsRUFBQTtBQUFBSSxZQUFBLENBQUFKLEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}