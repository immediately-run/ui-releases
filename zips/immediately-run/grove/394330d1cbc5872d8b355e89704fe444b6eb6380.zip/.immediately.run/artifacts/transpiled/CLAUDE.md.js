var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      blockquote: "blockquote",
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      li: "li",
      ol: "ol",
      p: "p",
      pre: "pre",
      strong: "strong",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "working-in-this-repo",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "working-in-this-repo"
      }), "Working in this repo"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["This is an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "immediately.run app"
      }), ": React + TypeScript that loads from GitHub and\ntranspiles in the browser (no server, no build step at runtime). Keep the rules\nbelow or the app breaks ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "only"
      }), " on immediately.run while still looking fine in\nlocal ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "vite dev"
      }), " — the most common silent failure."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "hard-rules-these-break-immediatelyrun-if-violated",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "hard-rules-these-break-immediatelyrun-if-violated"
      }), "Hard rules (these break immediately.run if violated)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "src/App.tsx"
          }), " is the entry point."]
        }), " immediately.run renders its ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "default\nexport"
        }), ". ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/main.tsx"
        }), " is for local dev/build only and is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "ignored"
        }), " at\nruntime — never put CSS imports, providers, or app logic there."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Import global CSS from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "App.tsx"
          })]
        }), ", not from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "main.tsx"
        }), ". Anything the\nrendered tree needs (CSS, context providers) must be reachable from\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "App.tsx"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "A file that exports a React component exports ONLY components."
        }), " No mixing a\ncomponent with named exports of data/constants/helpers. (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "interface"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "type"
        }), "\nare erased at compile time and are fine.) This is the React Fast Refresh rule;\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npm run lint"
        }), " enforces it. Put data in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/data/"
        }), ", hooks in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/hooks/"
        }), ",\nutilities in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/lib/"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "One component per file, default-exported"
        }), ", named for what it renders."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["CSS lives in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: ".css"
          }), " files imported from TypeScript"]
        }), " — not in giant\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<style>"
        }), " blocks or inline ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "style={{}}"
        }), " for the bulk of styling."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Fonts as declared assets"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "data/themeFonts.ts"
        }), " → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ThemeAssets"
        }), "): the\nengine reads the bytes from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "assets/fonts/"
        }), " and mints ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "blob:"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "@font-face"
        }), "\nrules. No remote ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "@import"
        }), " — it breaks offline in every stance and is blocked\nunder compiled dispatch (R3-315). Not ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<link>"
        }), " tags in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "index.html"
        }), " either."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Import local assets"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "import logo from './assets/logo.png'"
        }), "); don't\nreference server paths that won't exist in the sandbox."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "No Node / build-time-only APIs"
        }), " in the rendered tree — it runs in a browser\niframe. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "document"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "window"
        }), ", and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "fetch"
        }), " are available. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Web storage is\nnot"
        }), ": ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "localStorage"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "sessionStorage"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "indexedDB"
        }), " and the Cache API are\nall unavailable — apps run at an opaque origin (a sandboxed iframe without\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "allow-same-origin"
        }), "; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "BROWSER_CAPABILITIES_SPEC"
        }), " §1 in the docs repo), where\neven ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "reading"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "localStorage"
        }), " throws ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "SecurityError"
        }), ", so a\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "typeof localStorage === 'undefined'"
        }), " guard does NOT work (the throw is on\naccess, not on the value). State goes to the mounts instead:", "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
          children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Device-local, rebuildable state"
            }), " (caches, drafts, scroll positions,\ncheckpoints): the mount from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "await openLocalStore()"
            }), " in\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "@immediately-run/sdk"
            }), " — per device, never synced, evictable by the\nbrowser under storage pressure."]
          }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Synced state"
            }), ": ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "openSettings()"
            }), "."]
          }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: ["Both need a signed-in user: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "openLocalStore()"
            }), " rejects ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "auth-required"
            }), "\nwhen signed out, so the app degrades to in-memory state rather than\ncrashing (platform security model rule 9). Treat persistence as optional\nand keep the app fully usable without it."]
          }), "\n"]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "MDX is only for long-form prose"
        }), " (articles, guides). Structured/repeated\ndata stays as typed arrays in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/data/"
        }), ". If you add ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".mdx"
        }), ", the Vite plugin\nand ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/mdx.d.ts"
        }), " shim are already wired up."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "loading-caching-on-immediatelyrun",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "loading-caching-on-immediatelyrun"
      }), "Loading & caching on immediately.run"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: ".github/workflows/cache.yml"
      }), " publishes a pre-cached zip of this repo to its own\nGitHub Pages on each push to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "main"
      }), ", so immediately.run loads fast and within\nanonymous rate limits. Pages is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "self-provisioned"
      }), " on the first run when the org's\ndeploy GitHub App (Pages + Administration: write) and its ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "DEPLOY_APP_ID"
      }), " /\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "DEPLOY_APP_PRIVATE_KEY"
      }), " org secrets are set; otherwise enable it once via Pages\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Source: GitHub Actions"
      }), " in repo settings. Don't move the cache to a different path or hostname — the client\ndiscovers it by convention at\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "https://<owner>.github.io/<repo>/cached_repositories/main.zip"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "\"immediately.run\": { \"requireLatest\": \"...\" }"
      }), " in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "package.json"
      }), " controls\nfreshness. It is a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "string enum"
      }), ", not a boolean: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "\"stale_ok\""
      }), " (always serve\nthe cache, fastest, offline-friendly), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "\"optimistic\""
      }), " (the default — serve\ncache, check in background), or ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "\"strict\""
      }), " (always run the newest commit, at\nthe cost of a freshness check on launch). Leave it unset unless\nto-the-commit freshness matters; the default is fast and works offline."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "design-system",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "design-system"
      }), "Design system"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["This brand is: cool near-black canvas · magenta↔violet signature gradient ·\nGabarito display type · Space Mono details · hairline borders · hard-offset hover\nshadows · sentence case · headlines end on a period · ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "no emoji"
      }), ". Dark is the\ndefault; a light theme is wired via ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "data-theme=\"light\""
      }), " on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "<html>"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Pull tokens from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "src/index.css"
          })]
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--bg"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--panel"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--ink"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--accent"
        }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--grad"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--r-lg"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--shadow-card"
        }), ", the type families, etc.) instead of\nhard-coding colors, radii, or fonts."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["Apply the signature gradient to text with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "className=\"grad-text\""
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["For icons beyond the unicode set (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "→ ★ ● ☀ ☾"
        }), "), use\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "https://lucide.dev",
          children: "Lucide"
        }), " at 16–24px, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "currentColor"
        }), ". No emoji."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "finding-the-platform-apis-read-this-before-guessing-imports",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "finding-the-platform-apis-read-this-before-guessing-imports"
      }), "Finding the platform APIs (read this before guessing imports)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Don't guess export names or signatures — look them up. Every published platform\npackage ships an agent-facing ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "llms.txt"
      }), " (a concise map of every export with its\nimport path and a one-liner), generated from the same sources the release gates\ncheck, so it cannot rot:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "@immediately-run/sdk"
          })
        }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "https://immediately-run.github.io/immediately-run-sdk/llms.txt",
          children: "https://immediately-run.github.io/immediately-run-sdk/llms.txt"
        }), "\n(also ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "api.json"
        }), " — the full TypeDoc model — and an HTML reference at the same\norigin). The platform client: RPC, capabilities, mounts, fs, editor, LLM,\nmetadata queries, link spaces, the safe renderer re-exports."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "@immediately-run/grove"
          })
        }), " — this repo's own ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "llms.txt"
        }), " (repo root, and shipped\nin the package tarball): the composition surface, the component vocabulary with\ntiers/props/overridability, and the frontmatter keys the engine reads."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "@immediately-run/mdx-plugins"
          })
        }), " — the grammar canon: heading-id/slug rules,\nfrontmatter parsing, the entry rule, the link-space resolver + its parity fixture."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "@immediately-run/safe-content"
          })
        }), " — the non-executable MDX renderer."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Installed packages also ship ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: ".d.ts"
      }), " with the same JSDoc, so your editor reads the\ntyped API inline with no network; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "node_modules/@immediately-run/<pkg>/llms.txt"
      }), " is\nthe version-matched map when you want it in one read. The one-page index of which\nlayer answers which need is the platform surfaces map in the docs wiki\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "content/context/platform_surfaces.mdx"
      }), ")."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "platform-security-model-what-your-app-can-and-cant-do",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "platform-security-model-what-your-app-can-and-cant-do"
      }), "Platform security model (what your app can and can't do)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Your app runs in a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "sandboxed iframe with an opaque origin"
      }), ". The rules below\nfollow from that and from the platform capability model\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "docs/specs/UI_AS_APPS_SPEC.md"
      }), " §8 in the docs repo). Violations don't just\nbreak your app — calls fail with typed errors, and trying to work around them\nreads as hostile. (Enforcement is rolling out per the spec's §10 ladder —\nitems 4, 6 and 8 describe machinery that is specified but not yet live; write\nnew code as if they're enforced and it will keep working as they land.)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["All platform interaction goes through ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "@immediately-run/sdk"
          }), "."]
        }), " There is\nno other channel: no shared storage with other apps, no reaching sibling\niframes, no postMessage of your own to the parent."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Never handle user credentials."
        }), " You will never see the user's GitHub\ntoken, API keys, or any secret — sign-in and privileged actions are\nhost-driven. Call protocol methods reactively, gated on\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "getAuthState().status === 'signed-in'"
        }), "; never store or request tokens."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The filesystem you see is the filesystem you got."
        }), " Mounts the host gives\nyou (your app's spaces, granted folders) are your whole world — outside\npaths don't exist, and a grant may be read-only. Don't probe for escapes\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".."
        }), ", absolute paths); writes to read-only mounts fail with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "EROFS"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Access to more data is asked for, not taken."
        }), " Need another space or\nfolder? Call the SDK request method and the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "user"
        }), " picks in host UI. Expect\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "{ ok: false, code: 'cancelled' | 'forbidden' }"
        }), " and handle it gracefully."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Handle typed errors everywhere."
        }), " Platform calls reply\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "{ ok: false, code, message }"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "forbidden"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "auth-required"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "cancelled"
        }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "invalid-params"
        }), ", …). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "forbidden"
        }), " means your app lacks that capability —\nthat's policy, not a bug to retry around."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Declare what you invoke and provide."
        }), " Cross-app tasks go in\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "package.json"
        }), " under ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "\"immediately.run\""
        }), ": ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "\"invokes\""
        }), " for task contracts\nyou call, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "\"provides\""
        }), " for ones you implement. Undeclared invocations are\nrejected."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Don't imitate host chrome."
        }), " Never render fake sign-in prompts, consent\ndialogs, or the platform's seam/header UI. The host draws those; imitations\nare treated as spoofing."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "If you embed an LLM agent, its tool list is your catalog."
        }), " Use the\nSDK-provided method catalog as the agent's tools — it is pre-filtered to\nyour app's grants, so the agent can't exceed what your app may do. Don't\nhand-roll tools that shell around the SDK."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Expect cancellation and absence."
        }), " Interactive flows can resolve\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "cancelled"
        }), "; capabilities can be absent on a fork of your app. Degrade\nfeatures, don't crash."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "editing-delegate-to-the-platform-editor",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "editing-delegate-to-the-platform-editor"
      }), "Editing: delegate to the platform editor"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Your app's default text/code/file editing experience is the platform editor,\nnot a bespoke in-app editor."
      }), " When the thing the user edits ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "is"
      }), " a file (a\nMarkdown/MDX note, a JSON config, a source module, a CSV), hand that file to the\nplatform's editing surface instead of shipping your own ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "<textarea>"
      }), " or code\neditor. This is the same instinct as not reimplementing sign-in or PR review:\nthere is already a good, forkable, mobile-capable, agent-readable editor — use it.\n(Full rationale and the proposed platform additions are in\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "docs/specs/EDITOR_FIRST_EDITING_SPEC.md"
      }), ".)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Edit a file in one of your mounts via the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "edit-file"
          }), " task."]
        }), " Delegate a\ncapability for exactly that one file; the host opens the editor and tears the\ndelegation down when done. No consent prompt — you're narrowing a grant you\nalready hold:", "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            className: "language-ts",
            children: "import { invokeTask, capFile } from '@immediately-run/sdk';\nawait invokeTask('edit-file', {\n  file: capFile({ mountId: 'space:abc', relPath: 'notes/idea.mdx' }, { mode: 'rw' }),\n});\n"
          })
        }), "\n", "This is exactly how the whiteboard's \"Open source\" button works."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Offer \"edit\" as an affordance on the item, not a mode of your app."
        }), " Select\nan object / focus a row → an edit icon that opens ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "that"
        }), " file. Keep your\nrun-mode UI free of editor chrome (run-mode comes first)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Gate the affordance on writability."
        }), " Show it only when the mount is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "rw"
        }), ";\nre-evaluate on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "onMountsChange"
        }), " and hide it on a role downgrade. Never show a\nbutton that comes back ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "read-only"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "forbidden"
        }), ", and never surface ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "EROFS"
        }), " as UX."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "A few typed fields is a form, not an editor."
        }), " An inspector that sets a\ncolor, tags, or a lock toggle should be inline UI. Reach for the platform\neditor for the free-form body / the whole file."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Build a real in-app editor only with a stated reason"
        }), " — the content isn't a\nfile the platform editor can edit (freehand drawing, a node graph,\ndirect-manipulation geometry), or a measured UX need the platform editor can't\nmeet. Write the reason down; convenience is not a reason."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Known gaps (don't paper over them with a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "<textarea>"
          }), "):"]
        }), " an app running in\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "present"
        }), " mode can't yet summon the edit experience on its ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "own source"
        }), ", and\nopening a specific mounted file in the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "main"
        }), " editor (vs. the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "edit-file"
        }), "\noverlay) from a standalone app isn't supported yet. Both are specified as\nproposed deltas in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "EDITOR_FIRST_EDITING_SPEC.md"
        }), " §6; until they land, rely on\nthe ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "edit-file"
        }), " task and the host's edit experience rather than rolling your own."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "verify-before-youre-done",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "verify-before-youre-done"
      }), "Verify before you're done"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-bash",
        children: "npm run build   # must pass with no type errors\nnpm run lint    # must pass — this is the cheapest proof the Fast Refresh rule holds\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Then eyeball the page (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "npm run dev"
      }), ") and click any interactive controls."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "debugging-on-immediatelyrun-not-just-vite-dev",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "debugging-on-immediatelyrun-not-just-vite-dev"
      }), "Debugging on immediately.run (not just ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "vite dev"
      }), ")"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "vite dev"
      }), " proves your app renders, but the failure mode this whole file warns about\n— ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "\"works locally, breaks on immediately.run\""
      }), " — only shows up ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "running inside the\nhost"
      }), ": the sandboxed iframe, the SDK channel, the capability gate. Debug there too."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Drive a real browser with Chrome DevTools MCP."
        }), " The ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "mcp__chrome-devtools__*"
        }), "\ntools navigate the page, take an accessibility ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "snapshot"
        }), " (element ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "uid"
        }), "s to\nclick/fill), run JS with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "evaluate_script"
          })
        }), ", and read the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "console"
        }), " +\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "network"
        }), " — which is where SDK ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "{ ok: false, code }"
        }), " replies and sandbox errors\nactually surface. Reproduce, then ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "list_console_messages"
        }), " /\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "list_network_requests"
        }), "; don't guess from the rendered DOM alone."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Run your app ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "on the host"
          }), ", with no commit, via the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "local"
          }), " provider."]
        }), " Mount\nyour working tree into the real host and edit live:", "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            className: "language-bash",
            children: "immediately.run dev . --origin https://local.immediately.run --json\n# → open the printed /edit/local/<name>-<hash8>/.../live#ir-endpoint=…&ir-token=… link\n"
          })
        }), "\n", "Edits on disk hot-reload in the host preview, so you exercise the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "real"
        }), " SDK +\ncapability path (consent prompts, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "forbidden"
        }), ", mounts) instead of a local stub. A\ndev-served app gets a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "fresh appKey"
        }), " with no prior grants — handy for testing\nyour first-run consent flow honestly. (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "@immediately-run/cli"
        }), ", Node ≥ 18, git\nrepo.)"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Always use ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "https://local.immediately.run"
          }), ", never ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "localhost"
          })]
        }), " — config is\nkeyed by hostname and only the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "*.immediately.run"
        }), " origin is fully wired\n(sandbox + backend + auth allowlist)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "A passkey / Touch-ID prompt can't be automated"
        }), " — the first secret unseal or\nsign-in raises a native dialog; hand that step to a human, or reload after it's\ncached."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: ["The platform repo also ships a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "window.__irTest"
        }), " host hook for scripting\nspace/share drills, but that is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "host-internal"
        }), " (dev builds of immediately.run\nitself) — not something your app uses or should rely on. The full platform-side\nworkflow lives in the docs repo's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "tutorials/browser_debugging/"
        }), "."]
      }), "\n"]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/CLAUDE.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiYmxvY2txdW90ZSIsImNvZGUiLCJlbSIsImgxIiwiaDIiLCJsaSIsIm9sIiwicCIsInByZSIsInN0cm9uZyIsInVsIiwiX3Byb3ZpZGVDb21wb25lbnRzIiwiY29tcG9uZW50cyIsIkhlYWRpbmdBbmNob3IiLCJfbWlzc2luZ01keFJlZmVyZW5jZSIsImpzeHMiLCJGcmFnbWVudCIsImNoaWxkcmVuIiwiaWQiLCJqc3giLCJocmVmIiwiY2xhc3NOYW1lIiwiTURYQ29udGVudCIsIndyYXBwZXIiLCJNRFhMYXlvdXQiLCJfYyIsImNvbXBvbmVudCIsInBsYWNlIiwiRXJyb3IiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJDTEFVREUubWQiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgYTogXCJhXCIsXG4gICAgYmxvY2txdW90ZTogXCJibG9ja3F1b3RlXCIsXG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgZW06IFwiZW1cIixcbiAgICBoMTogXCJoMVwiLFxuICAgIGgyOiBcImgyXCIsXG4gICAgbGk6IFwibGlcIixcbiAgICBvbDogXCJvbFwiLFxuICAgIHA6IFwicFwiLFxuICAgIHByZTogXCJwcmVcIixcbiAgICBzdHJvbmc6IFwic3Ryb25nXCIsXG4gICAgdWw6IFwidWxcIixcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH0sIHtIZWFkaW5nQW5jaG9yfSA9IF9jb21wb25lbnRzO1xuICBpZiAoIUhlYWRpbmdBbmNob3IpIF9taXNzaW5nTWR4UmVmZXJlbmNlKFwiSGVhZGluZ0FuY2hvclwiLCB0cnVlKTtcbiAgcmV0dXJuIDw+PF9jb21wb25lbnRzLmgxIGlkPVwid29ya2luZy1pbi10aGlzLXJlcG9cIj48SGVhZGluZ0FuY2hvciBpZD1cIndvcmtpbmctaW4tdGhpcy1yZXBvXCIgLz57XCJXb3JraW5nIGluIHRoaXMgcmVwb1wifTwvX2NvbXBvbmVudHMuaDE+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhpcyBpcyBhbiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImltbWVkaWF0ZWx5LnJ1biBhcHBcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCI6IFJlYWN0ICsgVHlwZVNjcmlwdCB0aGF0IGxvYWRzIGZyb20gR2l0SHViIGFuZFxcbnRyYW5zcGlsZXMgaW4gdGhlIGJyb3dzZXIgKG5vIHNlcnZlciwgbm8gYnVpbGQgc3RlcCBhdCBydW50aW1lKS4gS2VlcCB0aGUgcnVsZXNcXG5iZWxvdyBvciB0aGUgYXBwIGJyZWFrcyBcIn08X2NvbXBvbmVudHMuZW0+e1wib25seVwifTwvX2NvbXBvbmVudHMuZW0+e1wiIG9uIGltbWVkaWF0ZWx5LnJ1biB3aGlsZSBzdGlsbCBsb29raW5nIGZpbmUgaW5cXG5sb2NhbCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ2aXRlIGRldlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIHRoZSBtb3N0IGNvbW1vbiBzaWxlbnQgZmFpbHVyZS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwiaGFyZC1ydWxlcy10aGVzZS1icmVhay1pbW1lZGlhdGVseXJ1bi1pZi12aW9sYXRlZFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiaGFyZC1ydWxlcy10aGVzZS1icmVhay1pbW1lZGlhdGVseXJ1bi1pZi12aW9sYXRlZFwiIC8+e1wiSGFyZCBydWxlcyAodGhlc2UgYnJlYWsgaW1tZWRpYXRlbHkucnVuIGlmIHZpb2xhdGVkKVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPjxfY29tcG9uZW50cy5jb2RlPntcInNyYy9BcHAudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpcyB0aGUgZW50cnkgcG9pbnQuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGltbWVkaWF0ZWx5LnJ1biByZW5kZXJzIGl0cyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImRlZmF1bHRcXG5leHBvcnRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIuIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9tYWluLnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaXMgZm9yIGxvY2FsIGRldi9idWlsZCBvbmx5IGFuZCBpcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImlnbm9yZWRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYXRcXG5ydW50aW1lIOKAlCBuZXZlciBwdXQgQ1NTIGltcG9ydHMsIHByb3ZpZGVycywgb3IgYXBwIGxvZ2ljIHRoZXJlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiSW1wb3J0IGdsb2JhbCBDU1MgZnJvbSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJBcHAudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgbm90IGZyb20gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibWFpbi50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLiBBbnl0aGluZyB0aGVcXG5yZW5kZXJlZCB0cmVlIG5lZWRzIChDU1MsIGNvbnRleHQgcHJvdmlkZXJzKSBtdXN0IGJlIHJlYWNoYWJsZSBmcm9tXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQXBwLnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJBIGZpbGUgdGhhdCBleHBvcnRzIGEgUmVhY3QgY29tcG9uZW50IGV4cG9ydHMgT05MWSBjb21wb25lbnRzLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBObyBtaXhpbmcgYVxcbmNvbXBvbmVudCB3aXRoIG5hbWVkIGV4cG9ydHMgb2YgZGF0YS9jb25zdGFudHMvaGVscGVycy4gKFwifTxfY29tcG9uZW50cy5jb2RlPntcImludGVyZmFjZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widHlwZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG5hcmUgZXJhc2VkIGF0IGNvbXBpbGUgdGltZSBhbmQgYXJlIGZpbmUuKSBUaGlzIGlzIHRoZSBSZWFjdCBGYXN0IFJlZnJlc2ggcnVsZTtcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJucG0gcnVuIGxpbnRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGVuZm9yY2VzIGl0LiBQdXQgZGF0YSBpbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvZGF0YS9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBob29rcyBpbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvaG9va3MvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIixcXG51dGlsaXRpZXMgaW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2xpYi9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiT25lIGNvbXBvbmVudCBwZXIgZmlsZSwgZGVmYXVsdC1leHBvcnRlZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgbmFtZWQgZm9yIHdoYXQgaXQgcmVuZGVycy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkNTUyBsaXZlcyBpbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCIuY3NzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBmaWxlcyBpbXBvcnRlZCBmcm9tIFR5cGVTY3JpcHRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIG5vdCBpbiBnaWFudFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcIjxzdHlsZT5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGJsb2NrcyBvciBpbmxpbmUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3R5bGU9e3t9fVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZm9yIHRoZSBidWxrIG9mIHN0eWxpbmcuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJGb250cyBhcyBkZWNsYXJlZCBhc3NldHNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcImRhdGEvdGhlbWVGb250cy50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oaSIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlRoZW1lQXNzZXRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIik6IHRoZVxcbmVuZ2luZSByZWFkcyB0aGUgYnl0ZXMgZnJvbSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJhc3NldHMvZm9udHMvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhbmQgbWludHMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYmxvYjpcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkBmb250LWZhY2VcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxucnVsZXMuIE5vIHJlbW90ZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJAaW1wb3J0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgaXQgYnJlYWtzIG9mZmxpbmUgaW4gZXZlcnkgc3RhbmNlIGFuZCBpcyBibG9ja2VkXFxudW5kZXIgY29tcGlsZWQgZGlzcGF0Y2ggKFIzLTMxNSkuIE5vdCBcIn08X2NvbXBvbmVudHMuY29kZT57XCI8bGluaz5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHRhZ3MgaW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW5kZXguaHRtbFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZWl0aGVyLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiSW1wb3J0IGxvY2FsIGFzc2V0c1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW1wb3J0IGxvZ28gZnJvbSAnLi9hc3NldHMvbG9nby5wbmcnXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIik7IGRvbid0XFxucmVmZXJlbmNlIHNlcnZlciBwYXRocyB0aGF0IHdvbid0IGV4aXN0IGluIHRoZSBzYW5kYm94LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiTm8gTm9kZSAvIGJ1aWxkLXRpbWUtb25seSBBUElzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGluIHRoZSByZW5kZXJlZCB0cmVlIOKAlCBpdCBydW5zIGluIGEgYnJvd3NlclxcbmlmcmFtZS4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZG9jdW1lbnRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ3aW5kb3dcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBhbmQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZmV0Y2hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFyZSBhdmFpbGFibGUuIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiV2ViIHN0b3JhZ2UgaXNcXG5ub3RcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCI6IFwifTxfY29tcG9uZW50cy5jb2RlPntcImxvY2FsU3RvcmFnZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNlc3Npb25TdG9yYWdlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW5kZXhlZERCXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhbmQgdGhlIENhY2hlIEFQSSBhcmVcXG5hbGwgdW5hdmFpbGFibGUg4oCUIGFwcHMgcnVuIGF0IGFuIG9wYXF1ZSBvcmlnaW4gKGEgc2FuZGJveGVkIGlmcmFtZSB3aXRob3V0XFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYWxsb3ctc2FtZS1vcmlnaW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiOyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJCUk9XU0VSX0NBUEFCSUxJVElFU19TUEVDXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDCpzEgaW4gdGhlIGRvY3MgcmVwbyksIHdoZXJlXFxuZXZlbiBcIn08X2NvbXBvbmVudHMuZW0+e1wicmVhZGluZ1wifTwvX2NvbXBvbmVudHMuZW0+e1wiIFwifTxfY29tcG9uZW50cy5jb2RlPntcImxvY2FsU3RvcmFnZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdGhyb3dzIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlNlY3VyaXR5RXJyb3JcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBzbyBhXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widHlwZW9mIGxvY2FsU3RvcmFnZSA9PT0gJ3VuZGVmaW5lZCdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGd1YXJkIGRvZXMgTk9UIHdvcmsgKHRoZSB0aHJvdyBpcyBvblxcbmFjY2Vzcywgbm90IG9uIHRoZSB2YWx1ZSkuIFN0YXRlIGdvZXMgdG8gdGhlIG1vdW50cyBpbnN0ZWFkOlwifXtcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJEZXZpY2UtbG9jYWwsIHJlYnVpbGRhYmxlIHN0YXRlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChjYWNoZXMsIGRyYWZ0cywgc2Nyb2xsIHBvc2l0aW9ucyxcXG5jaGVja3BvaW50cyk6IHRoZSBtb3VudCBmcm9tIFwifTxfY29tcG9uZW50cy5jb2RlPntcImF3YWl0IG9wZW5Mb2NhbFN0b3JlKClcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGluXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQGltbWVkaWF0ZWx5LXJ1bi9zZGtcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCBwZXIgZGV2aWNlLCBuZXZlciBzeW5jZWQsIGV2aWN0YWJsZSBieSB0aGVcXG5icm93c2VyIHVuZGVyIHN0b3JhZ2UgcHJlc3N1cmUuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJTeW5jZWQgc3RhdGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCI6IFwifTxfY29tcG9uZW50cy5jb2RlPntcIm9wZW5TZXR0aW5ncygpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJCb3RoIG5lZWQgYSBzaWduZWQtaW4gdXNlcjogXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wib3BlbkxvY2FsU3RvcmUoKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcmVqZWN0cyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJhdXRoLXJlcXVpcmVkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIlxcbndoZW4gc2lnbmVkIG91dCwgc28gdGhlIGFwcCBkZWdyYWRlcyB0byBpbi1tZW1vcnkgc3RhdGUgcmF0aGVyIHRoYW5cXG5jcmFzaGluZyAocGxhdGZvcm0gc2VjdXJpdHkgbW9kZWwgcnVsZSA5KS4gVHJlYXQgcGVyc2lzdGVuY2UgYXMgb3B0aW9uYWxcXG5hbmQga2VlcCB0aGUgYXBwIGZ1bGx5IHVzYWJsZSB3aXRob3V0IGl0LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIk1EWCBpcyBvbmx5IGZvciBsb25nLWZvcm0gcHJvc2VcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKGFydGljbGVzLCBndWlkZXMpLiBTdHJ1Y3R1cmVkL3JlcGVhdGVkXFxuZGF0YSBzdGF5cyBhcyB0eXBlZCBhcnJheXMgaW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2RhdGEvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi4gSWYgeW91IGFkZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCIubWR4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgdGhlIFZpdGUgcGx1Z2luXFxuYW5kIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9tZHguZC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgc2hpbSBhcmUgYWxyZWFkeSB3aXJlZCB1cC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMub2w+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwibG9hZGluZy1jYWNoaW5nLW9uLWltbWVkaWF0ZWx5cnVuXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJsb2FkaW5nLWNhY2hpbmctb24taW1tZWRpYXRlbHlydW5cIiAvPntcIkxvYWRpbmcgJiBjYWNoaW5nIG9uIGltbWVkaWF0ZWx5LnJ1blwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLmNvZGU+e1wiLmdpdGh1Yi93b3JrZmxvd3MvY2FjaGUueW1sXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBwdWJsaXNoZXMgYSBwcmUtY2FjaGVkIHppcCBvZiB0aGlzIHJlcG8gdG8gaXRzIG93blxcbkdpdEh1YiBQYWdlcyBvbiBlYWNoIHB1c2ggdG8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibWFpblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIHNvIGltbWVkaWF0ZWx5LnJ1biBsb2FkcyBmYXN0IGFuZCB3aXRoaW5cXG5hbm9ueW1vdXMgcmF0ZSBsaW1pdHMuIFBhZ2VzIGlzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wic2VsZi1wcm92aXNpb25lZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBvbiB0aGUgZmlyc3QgcnVuIHdoZW4gdGhlIG9yZydzXFxuZGVwbG95IEdpdEh1YiBBcHAgKFBhZ2VzICsgQWRtaW5pc3RyYXRpb246IHdyaXRlKSBhbmQgaXRzIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkRFUExPWV9BUFBfSURcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIC9cXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJERVBMT1lfQVBQX1BSSVZBVEVfS0VZXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBvcmcgc2VjcmV0cyBhcmUgc2V0OyBvdGhlcndpc2UgZW5hYmxlIGl0IG9uY2UgdmlhIFBhZ2VzXFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJTb3VyY2U6IEdpdEh1YiBBY3Rpb25zXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGluIHJlcG8gc2V0dGluZ3MuIERvbid0IG1vdmUgdGhlIGNhY2hlIHRvIGEgZGlmZmVyZW50IHBhdGggb3IgaG9zdG5hbWUg4oCUIHRoZSBjbGllbnRcXG5kaXNjb3ZlcnMgaXQgYnkgY29udmVudGlvbiBhdFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcImh0dHBzOi8vPG93bmVyPi5naXRodWIuaW8vPHJlcG8+L2NhY2hlZF9yZXBvc2l0b3JpZXMvbWFpbi56aXBcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuY29kZT57XCJcXFwiaW1tZWRpYXRlbHkucnVuXFxcIjogeyBcXFwicmVxdWlyZUxhdGVzdFxcXCI6IFxcXCIuLi5cXFwiIH1cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGluIFwifTxfY29tcG9uZW50cy5jb2RlPntcInBhY2thZ2UuanNvblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgY29udHJvbHNcXG5mcmVzaG5lc3MuIEl0IGlzIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJzdHJpbmcgZW51bVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgbm90IGEgYm9vbGVhbjogXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiXFxcInN0YWxlX29rXFxcIlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKGFsd2F5cyBzZXJ2ZVxcbnRoZSBjYWNoZSwgZmFzdGVzdCwgb2ZmbGluZS1mcmllbmRseSksIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlxcXCJvcHRpbWlzdGljXFxcIlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKHRoZSBkZWZhdWx0IOKAlCBzZXJ2ZVxcbmNhY2hlLCBjaGVjayBpbiBiYWNrZ3JvdW5kKSwgb3IgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiXFxcInN0cmljdFxcXCJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChhbHdheXMgcnVuIHRoZSBuZXdlc3QgY29tbWl0LCBhdFxcbnRoZSBjb3N0IG9mIGEgZnJlc2huZXNzIGNoZWNrIG9uIGxhdW5jaCkuIExlYXZlIGl0IHVuc2V0IHVubGVzc1xcbnRvLXRoZS1jb21taXQgZnJlc2huZXNzIG1hdHRlcnM7IHRoZSBkZWZhdWx0IGlzIGZhc3QgYW5kIHdvcmtzIG9mZmxpbmUuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cImRlc2lnbi1zeXN0ZW1cIj48SGVhZGluZ0FuY2hvciBpZD1cImRlc2lnbi1zeXN0ZW1cIiAvPntcIkRlc2lnbiBzeXN0ZW1cIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoaXMgYnJhbmQgaXM6IGNvb2wgbmVhci1ibGFjayBjYW52YXMgwrcgbWFnZW50YeKGlHZpb2xldCBzaWduYXR1cmUgZ3JhZGllbnQgwrdcXG5HYWJhcml0byBkaXNwbGF5IHR5cGUgwrcgU3BhY2UgTW9ubyBkZXRhaWxzIMK3IGhhaXJsaW5lIGJvcmRlcnMgwrcgaGFyZC1vZmZzZXQgaG92ZXJcXG5zaGFkb3dzIMK3IHNlbnRlbmNlIGNhc2UgwrcgaGVhZGxpbmVzIGVuZCBvbiBhIHBlcmlvZCDCtyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vIGVtb2ppXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLiBEYXJrIGlzIHRoZVxcbmRlZmF1bHQ7IGEgbGlnaHQgdGhlbWUgaXMgd2lyZWQgdmlhIFwifTxfY29tcG9uZW50cy5jb2RlPntcImRhdGEtdGhlbWU9XFxcImxpZ2h0XFxcIlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgb24gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiPGh0bWw+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlB1bGwgdG9rZW5zIGZyb20gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2luZGV4LmNzc1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnN0cm9uZz57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIi0tYmdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCItLXBhbmVsXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1pbmtcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCItLWFjY2VudFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1ncmFkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1yLWxnXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1zaGFkb3ctY2FyZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIHRoZSB0eXBlIGZhbWlsaWVzLCBldGMuKSBpbnN0ZWFkIG9mXFxuaGFyZC1jb2RpbmcgY29sb3JzLCByYWRpaSwgb3IgZm9udHMuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiQXBwbHkgdGhlIHNpZ25hdHVyZSBncmFkaWVudCB0byB0ZXh0IHdpdGggXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2xhc3NOYW1lPVxcXCJncmFkLXRleHRcXFwiXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJGb3IgaWNvbnMgYmV5b25kIHRoZSB1bmljb2RlIHNldCAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wi4oaSIOKYhSDil48g4piAIOKYvlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLCB1c2VcXG5cIn08X2NvbXBvbmVudHMuYSBocmVmPVwiaHR0cHM6Ly9sdWNpZGUuZGV2XCI+e1wiTHVjaWRlXCJ9PC9fY29tcG9uZW50cy5hPntcIiBhdCAxNuKAkzI0cHgsIFwifTxfY29tcG9uZW50cy5jb2RlPntcImN1cnJlbnRDb2xvclwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuIE5vIGVtb2ppLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJmaW5kaW5nLXRoZS1wbGF0Zm9ybS1hcGlzLXJlYWQtdGhpcy1iZWZvcmUtZ3Vlc3NpbmctaW1wb3J0c1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwiZmluZGluZy10aGUtcGxhdGZvcm0tYXBpcy1yZWFkLXRoaXMtYmVmb3JlLWd1ZXNzaW5nLWltcG9ydHNcIiAvPntcIkZpbmRpbmcgdGhlIHBsYXRmb3JtIEFQSXMgKHJlYWQgdGhpcyBiZWZvcmUgZ3Vlc3NpbmcgaW1wb3J0cylcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkRvbid0IGd1ZXNzIGV4cG9ydCBuYW1lcyBvciBzaWduYXR1cmVzIOKAlCBsb29rIHRoZW0gdXAuIEV2ZXJ5IHB1Ymxpc2hlZCBwbGF0Zm9ybVxcbnBhY2thZ2Ugc2hpcHMgYW4gYWdlbnQtZmFjaW5nIFwifTxfY29tcG9uZW50cy5jb2RlPntcImxsbXMudHh0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoYSBjb25jaXNlIG1hcCBvZiBldmVyeSBleHBvcnQgd2l0aCBpdHNcXG5pbXBvcnQgcGF0aCBhbmQgYSBvbmUtbGluZXIpLCBnZW5lcmF0ZWQgZnJvbSB0aGUgc2FtZSBzb3VyY2VzIHRoZSByZWxlYXNlIGdhdGVzXFxuY2hlY2ssIHNvIGl0IGNhbm5vdCByb3Q6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz48X2NvbXBvbmVudHMuY29kZT57XCJAaW1tZWRpYXRlbHktcnVuL3Nka1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIFwifTxfY29tcG9uZW50cy5hIGhyZWY9XCJodHRwczovL2ltbWVkaWF0ZWx5LXJ1bi5naXRodWIuaW8vaW1tZWRpYXRlbHktcnVuLXNkay9sbG1zLnR4dFwiPntcImh0dHBzOi8vaW1tZWRpYXRlbHktcnVuLmdpdGh1Yi5pby9pbW1lZGlhdGVseS1ydW4tc2RrL2xsbXMudHh0XCJ9PC9fY29tcG9uZW50cy5hPntcIlxcbihhbHNvIFwifTxfY29tcG9uZW50cy5jb2RlPntcImFwaS5qc29uXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgdGhlIGZ1bGwgVHlwZURvYyBtb2RlbCDigJQgYW5kIGFuIEhUTUwgcmVmZXJlbmNlIGF0IHRoZSBzYW1lXFxub3JpZ2luKS4gVGhlIHBsYXRmb3JtIGNsaWVudDogUlBDLCBjYXBhYmlsaXRpZXMsIG1vdW50cywgZnMsIGVkaXRvciwgTExNLFxcbm1ldGFkYXRhIHF1ZXJpZXMsIGxpbmsgc3BhY2VzLCB0aGUgc2FmZSByZW5kZXJlciByZS1leHBvcnRzLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+PF9jb21wb25lbnRzLmNvZGU+e1wiQGltbWVkaWF0ZWx5LXJ1bi9ncm92ZVwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHRoaXMgcmVwbydzIG93biBcIn08X2NvbXBvbmVudHMuY29kZT57XCJsbG1zLnR4dFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKHJlcG8gcm9vdCwgYW5kIHNoaXBwZWRcXG5pbiB0aGUgcGFja2FnZSB0YXJiYWxsKTogdGhlIGNvbXBvc2l0aW9uIHN1cmZhY2UsIHRoZSBjb21wb25lbnQgdm9jYWJ1bGFyeSB3aXRoXFxudGllcnMvcHJvcHMvb3ZlcnJpZGFiaWxpdHksIGFuZCB0aGUgZnJvbnRtYXR0ZXIga2V5cyB0aGUgZW5naW5lIHJlYWRzLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+PF9jb21wb25lbnRzLmNvZGU+e1wiQGltbWVkaWF0ZWx5LXJ1bi9tZHgtcGx1Z2luc1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHRoZSBncmFtbWFyIGNhbm9uOiBoZWFkaW5nLWlkL3NsdWcgcnVsZXMsXFxuZnJvbnRtYXR0ZXIgcGFyc2luZywgdGhlIGVudHJ5IHJ1bGUsIHRoZSBsaW5rLXNwYWNlIHJlc29sdmVyICsgaXRzIHBhcml0eSBmaXh0dXJlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+PF9jb21wb25lbnRzLmNvZGU+e1wiQGltbWVkaWF0ZWx5LXJ1bi9zYWZlLWNvbnRlbnRcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCB0aGUgbm9uLWV4ZWN1dGFibGUgTURYIHJlbmRlcmVyLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJJbnN0YWxsZWQgcGFja2FnZXMgYWxzbyBzaGlwIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi5kLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB3aXRoIHRoZSBzYW1lIEpTRG9jLCBzbyB5b3VyIGVkaXRvciByZWFkcyB0aGVcXG50eXBlZCBBUEkgaW5saW5lIHdpdGggbm8gbmV0d29yazsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibm9kZV9tb2R1bGVzL0BpbW1lZGlhdGVseS1ydW4vPHBrZz4vbGxtcy50eHRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGlzXFxudGhlIHZlcnNpb24tbWF0Y2hlZCBtYXAgd2hlbiB5b3Ugd2FudCBpdCBpbiBvbmUgcmVhZC4gVGhlIG9uZS1wYWdlIGluZGV4IG9mIHdoaWNoXFxubGF5ZXIgYW5zd2VycyB3aGljaCBuZWVkIGlzIHRoZSBwbGF0Zm9ybSBzdXJmYWNlcyBtYXAgaW4gdGhlIGRvY3Mgd2lraVxcbihcIn08X2NvbXBvbmVudHMuY29kZT57XCJjb250ZW50L2NvbnRleHQvcGxhdGZvcm1fc3VyZmFjZXMubWR4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInBsYXRmb3JtLXNlY3VyaXR5LW1vZGVsLXdoYXQteW91ci1hcHAtY2FuLWFuZC1jYW50LWRvXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJwbGF0Zm9ybS1zZWN1cml0eS1tb2RlbC13aGF0LXlvdXItYXBwLWNhbi1hbmQtY2FudC1kb1wiIC8+e1wiUGxhdGZvcm0gc2VjdXJpdHkgbW9kZWwgKHdoYXQgeW91ciBhcHAgY2FuIGFuZCBjYW4ndCBkbylcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIllvdXIgYXBwIHJ1bnMgaW4gYSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInNhbmRib3hlZCBpZnJhbWUgd2l0aCBhbiBvcGFxdWUgb3JpZ2luXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLiBUaGUgcnVsZXMgYmVsb3dcXG5mb2xsb3cgZnJvbSB0aGF0IGFuZCBmcm9tIHRoZSBwbGF0Zm9ybSBjYXBhYmlsaXR5IG1vZGVsXFxuKFwifTxfY29tcG9uZW50cy5jb2RlPntcImRvY3Mvc3BlY3MvVUlfQVNfQVBQU19TUEVDLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDCpzggaW4gdGhlIGRvY3MgcmVwbykuIFZpb2xhdGlvbnMgZG9uJ3QganVzdFxcbmJyZWFrIHlvdXIgYXBwIOKAlCBjYWxscyBmYWlsIHdpdGggdHlwZWQgZXJyb3JzLCBhbmQgdHJ5aW5nIHRvIHdvcmsgYXJvdW5kIHRoZW1cXG5yZWFkcyBhcyBob3N0aWxlLiAoRW5mb3JjZW1lbnQgaXMgcm9sbGluZyBvdXQgcGVyIHRoZSBzcGVjJ3MgwqcxMCBsYWRkZXIg4oCUXFxuaXRlbXMgNCwgNiBhbmQgOCBkZXNjcmliZSBtYWNoaW5lcnkgdGhhdCBpcyBzcGVjaWZpZWQgYnV0IG5vdCB5ZXQgbGl2ZTsgd3JpdGVcXG5uZXcgY29kZSBhcyBpZiB0aGV5J3JlIGVuZm9yY2VkIGFuZCBpdCB3aWxsIGtlZXAgd29ya2luZyBhcyB0aGV5IGxhbmQuKVwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMub2w+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQWxsIHBsYXRmb3JtIGludGVyYWN0aW9uIGdvZXMgdGhyb3VnaCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJAaW1tZWRpYXRlbHktcnVuL3Nka1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRoZXJlIGlzXFxubm8gb3RoZXIgY2hhbm5lbDogbm8gc2hhcmVkIHN0b3JhZ2Ugd2l0aCBvdGhlciBhcHBzLCBubyByZWFjaGluZyBzaWJsaW5nXFxuaWZyYW1lcywgbm8gcG9zdE1lc3NhZ2Ugb2YgeW91ciBvd24gdG8gdGhlIHBhcmVudC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIk5ldmVyIGhhbmRsZSB1c2VyIGNyZWRlbnRpYWxzLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBZb3Ugd2lsbCBuZXZlciBzZWUgdGhlIHVzZXIncyBHaXRIdWJcXG50b2tlbiwgQVBJIGtleXMsIG9yIGFueSBzZWNyZXQg4oCUIHNpZ24taW4gYW5kIHByaXZpbGVnZWQgYWN0aW9ucyBhcmVcXG5ob3N0LWRyaXZlbi4gQ2FsbCBwcm90b2NvbCBtZXRob2RzIHJlYWN0aXZlbHksIGdhdGVkIG9uXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZ2V0QXV0aFN0YXRlKCkuc3RhdHVzID09PSAnc2lnbmVkLWluJ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCI7IG5ldmVyIHN0b3JlIG9yIHJlcXVlc3QgdG9rZW5zLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVGhlIGZpbGVzeXN0ZW0geW91IHNlZSBpcyB0aGUgZmlsZXN5c3RlbSB5b3UgZ290LlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBNb3VudHMgdGhlIGhvc3QgZ2l2ZXNcXG55b3UgKHlvdXIgYXBwJ3Mgc3BhY2VzLCBncmFudGVkIGZvbGRlcnMpIGFyZSB5b3VyIHdob2xlIHdvcmxkIOKAlCBvdXRzaWRlXFxucGF0aHMgZG9uJ3QgZXhpc3QsIGFuZCBhIGdyYW50IG1heSBiZSByZWFkLW9ubHkuIERvbid0IHByb2JlIGZvciBlc2NhcGVzXFxuKFwifTxfY29tcG9uZW50cy5jb2RlPntcIi4uXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgYWJzb2x1dGUgcGF0aHMpOyB3cml0ZXMgdG8gcmVhZC1vbmx5IG1vdW50cyBmYWlsIHdpdGggXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRVJPRlNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQWNjZXNzIHRvIG1vcmUgZGF0YSBpcyBhc2tlZCBmb3IsIG5vdCB0YWtlbi5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgTmVlZCBhbm90aGVyIHNwYWNlIG9yXFxuZm9sZGVyPyBDYWxsIHRoZSBTREsgcmVxdWVzdCBtZXRob2QgYW5kIHRoZSBcIn08X2NvbXBvbmVudHMuZW0+e1widXNlclwifTwvX2NvbXBvbmVudHMuZW0+e1wiIHBpY2tzIGluIGhvc3QgVUkuIEV4cGVjdFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcInsgb2s6IGZhbHNlLCBjb2RlOiAnY2FuY2VsbGVkJyB8ICdmb3JiaWRkZW4nIH1cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFuZCBoYW5kbGUgaXQgZ3JhY2VmdWxseS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkhhbmRsZSB0eXBlZCBlcnJvcnMgZXZlcnl3aGVyZS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgUGxhdGZvcm0gY2FsbHMgcmVwbHlcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJ7IG9rOiBmYWxzZSwgY29kZSwgbWVzc2FnZSB9XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZm9yYmlkZGVuXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYXV0aC1yZXF1aXJlZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNhbmNlbGxlZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW52YWxpZC1wYXJhbXNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCDigKYpLiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmb3JiaWRkZW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG1lYW5zIHlvdXIgYXBwIGxhY2tzIHRoYXQgY2FwYWJpbGl0eSDigJRcXG50aGF0J3MgcG9saWN5LCBub3QgYSBidWcgdG8gcmV0cnkgYXJvdW5kLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRGVjbGFyZSB3aGF0IHlvdSBpbnZva2UgYW5kIHByb3ZpZGUuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIENyb3NzLWFwcCB0YXNrcyBnbyBpblxcblwifTxfY29tcG9uZW50cy5jb2RlPntcInBhY2thZ2UuanNvblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdW5kZXIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiXFxcImltbWVkaWF0ZWx5LnJ1blxcXCJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiOiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJcXFwiaW52b2tlc1xcXCJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGZvciB0YXNrIGNvbnRyYWN0c1xcbnlvdSBjYWxsLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJcXFwicHJvdmlkZXNcXFwiXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBmb3Igb25lcyB5b3UgaW1wbGVtZW50LiBVbmRlY2xhcmVkIGludm9jYXRpb25zIGFyZVxcbnJlamVjdGVkLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRG9uJ3QgaW1pdGF0ZSBob3N0IGNocm9tZS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgTmV2ZXIgcmVuZGVyIGZha2Ugc2lnbi1pbiBwcm9tcHRzLCBjb25zZW50XFxuZGlhbG9ncywgb3IgdGhlIHBsYXRmb3JtJ3Mgc2VhbS9oZWFkZXIgVUkuIFRoZSBob3N0IGRyYXdzIHRob3NlOyBpbWl0YXRpb25zXFxuYXJlIHRyZWF0ZWQgYXMgc3Bvb2ZpbmcuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJJZiB5b3UgZW1iZWQgYW4gTExNIGFnZW50LCBpdHMgdG9vbCBsaXN0IGlzIHlvdXIgY2F0YWxvZy5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVXNlIHRoZVxcblNESy1wcm92aWRlZCBtZXRob2QgY2F0YWxvZyBhcyB0aGUgYWdlbnQncyB0b29scyDigJQgaXQgaXMgcHJlLWZpbHRlcmVkIHRvXFxueW91ciBhcHAncyBncmFudHMsIHNvIHRoZSBhZ2VudCBjYW4ndCBleGNlZWQgd2hhdCB5b3VyIGFwcCBtYXkgZG8uIERvbid0XFxuaGFuZC1yb2xsIHRvb2xzIHRoYXQgc2hlbGwgYXJvdW5kIHRoZSBTREsuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJFeHBlY3QgY2FuY2VsbGF0aW9uIGFuZCBhYnNlbmNlLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBJbnRlcmFjdGl2ZSBmbG93cyBjYW4gcmVzb2x2ZVxcblwifTxfY29tcG9uZW50cy5jb2RlPntcImNhbmNlbGxlZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCI7IGNhcGFiaWxpdGllcyBjYW4gYmUgYWJzZW50IG9uIGEgZm9yayBvZiB5b3VyIGFwcC4gRGVncmFkZVxcbmZlYXR1cmVzLCBkb24ndCBjcmFzaC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMub2w+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwiZWRpdGluZy1kZWxlZ2F0ZS10by10aGUtcGxhdGZvcm0tZWRpdG9yXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJlZGl0aW5nLWRlbGVnYXRlLXRvLXRoZS1wbGF0Zm9ybS1lZGl0b3JcIiAvPntcIkVkaXRpbmc6IGRlbGVnYXRlIHRvIHRoZSBwbGF0Zm9ybSBlZGl0b3JcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiWW91ciBhcHAncyBkZWZhdWx0IHRleHQvY29kZS9maWxlIGVkaXRpbmcgZXhwZXJpZW5jZSBpcyB0aGUgcGxhdGZvcm0gZWRpdG9yLFxcbm5vdCBhIGJlc3Bva2UgaW4tYXBwIGVkaXRvci5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgV2hlbiB0aGUgdGhpbmcgdGhlIHVzZXIgZWRpdHMgXCJ9PF9jb21wb25lbnRzLmVtPntcImlzXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgYSBmaWxlIChhXFxuTWFya2Rvd24vTURYIG5vdGUsIGEgSlNPTiBjb25maWcsIGEgc291cmNlIG1vZHVsZSwgYSBDU1YpLCBoYW5kIHRoYXQgZmlsZSB0byB0aGVcXG5wbGF0Zm9ybSdzIGVkaXRpbmcgc3VyZmFjZSBpbnN0ZWFkIG9mIHNoaXBwaW5nIHlvdXIgb3duIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjx0ZXh0YXJlYT5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG9yIGNvZGVcXG5lZGl0b3IuIFRoaXMgaXMgdGhlIHNhbWUgaW5zdGluY3QgYXMgbm90IHJlaW1wbGVtZW50aW5nIHNpZ24taW4gb3IgUFIgcmV2aWV3OlxcbnRoZXJlIGlzIGFscmVhZHkgYSBnb29kLCBmb3JrYWJsZSwgbW9iaWxlLWNhcGFibGUsIGFnZW50LXJlYWRhYmxlIGVkaXRvciDigJQgdXNlIGl0LlxcbihGdWxsIHJhdGlvbmFsZSBhbmQgdGhlIHByb3Bvc2VkIHBsYXRmb3JtIGFkZGl0aW9ucyBhcmUgaW5cXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJkb2NzL3NwZWNzL0VESVRPUl9GSVJTVF9FRElUSU5HX1NQRUMubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLilcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkVkaXQgYSBmaWxlIGluIG9uZSBvZiB5b3VyIG1vdW50cyB2aWEgdGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcImVkaXQtZmlsZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdGFzay5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgRGVsZWdhdGUgYVxcbmNhcGFiaWxpdHkgZm9yIGV4YWN0bHkgdGhhdCBvbmUgZmlsZTsgdGhlIGhvc3Qgb3BlbnMgdGhlIGVkaXRvciBhbmQgdGVhcnMgdGhlXFxuZGVsZWdhdGlvbiBkb3duIHdoZW4gZG9uZS4gTm8gY29uc2VudCBwcm9tcHQg4oCUIHlvdSdyZSBuYXJyb3dpbmcgYSBncmFudCB5b3VcXG5hbHJlYWR5IGhvbGQ6XCJ9e1wiXFxuXCJ9PF9jb21wb25lbnRzLnByZT48X2NvbXBvbmVudHMuY29kZSBjbGFzc05hbWU9XCJsYW5ndWFnZS10c1wiPntcImltcG9ydCB7IGludm9rZVRhc2ssIGNhcEZpbGUgfSBmcm9tICdAaW1tZWRpYXRlbHktcnVuL3Nkayc7XFxuYXdhaXQgaW52b2tlVGFzaygnZWRpdC1maWxlJywge1xcbiAgZmlsZTogY2FwRmlsZSh7IG1vdW50SWQ6ICdzcGFjZTphYmMnLCByZWxQYXRoOiAnbm90ZXMvaWRlYS5tZHgnIH0sIHsgbW9kZTogJ3J3JyB9KSxcXG59KTtcXG5cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5wcmU+e1wiXFxuXCJ9e1wiVGhpcyBpcyBleGFjdGx5IGhvdyB0aGUgd2hpdGVib2FyZCdzIFxcXCJPcGVuIHNvdXJjZVxcXCIgYnV0dG9uIHdvcmtzLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiT2ZmZXIgXFxcImVkaXRcXFwiIGFzIGFuIGFmZm9yZGFuY2Ugb24gdGhlIGl0ZW0sIG5vdCBhIG1vZGUgb2YgeW91ciBhcHAuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFNlbGVjdFxcbmFuIG9iamVjdCAvIGZvY3VzIGEgcm93IOKGkiBhbiBlZGl0IGljb24gdGhhdCBvcGVucyBcIn08X2NvbXBvbmVudHMuZW0+e1widGhhdFwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGZpbGUuIEtlZXAgeW91clxcbnJ1bi1tb2RlIFVJIGZyZWUgb2YgZWRpdG9yIGNocm9tZSAocnVuLW1vZGUgY29tZXMgZmlyc3QpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiR2F0ZSB0aGUgYWZmb3JkYW5jZSBvbiB3cml0YWJpbGl0eS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgU2hvdyBpdCBvbmx5IHdoZW4gdGhlIG1vdW50IGlzIFwifTxfY29tcG9uZW50cy5jb2RlPntcInJ3XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjtcXG5yZS1ldmFsdWF0ZSBvbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJvbk1vdW50c0NoYW5nZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYW5kIGhpZGUgaXQgb24gYSByb2xlIGRvd25ncmFkZS4gTmV2ZXIgc2hvdyBhXFxuYnV0dG9uIHRoYXQgY29tZXMgYmFjayBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyZWFkLW9ubHlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcImZvcmJpZGRlblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGFuZCBuZXZlciBzdXJmYWNlIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkVST0ZTXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhcyBVWC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkEgZmV3IHR5cGVkIGZpZWxkcyBpcyBhIGZvcm0sIG5vdCBhbiBlZGl0b3IuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIEFuIGluc3BlY3RvciB0aGF0IHNldHMgYVxcbmNvbG9yLCB0YWdzLCBvciBhIGxvY2sgdG9nZ2xlIHNob3VsZCBiZSBpbmxpbmUgVUkuIFJlYWNoIGZvciB0aGUgcGxhdGZvcm1cXG5lZGl0b3IgZm9yIHRoZSBmcmVlLWZvcm0gYm9keSAvIHRoZSB3aG9sZSBmaWxlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQnVpbGQgYSByZWFsIGluLWFwcCBlZGl0b3Igb25seSB3aXRoIGEgc3RhdGVkIHJlYXNvblwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgdGhlIGNvbnRlbnQgaXNuJ3QgYVxcbmZpbGUgdGhlIHBsYXRmb3JtIGVkaXRvciBjYW4gZWRpdCAoZnJlZWhhbmQgZHJhd2luZywgYSBub2RlIGdyYXBoLFxcbmRpcmVjdC1tYW5pcHVsYXRpb24gZ2VvbWV0cnkpLCBvciBhIG1lYXN1cmVkIFVYIG5lZWQgdGhlIHBsYXRmb3JtIGVkaXRvciBjYW4ndFxcbm1lZXQuIFdyaXRlIHRoZSByZWFzb24gZG93bjsgY29udmVuaWVuY2UgaXMgbm90IGEgcmVhc29uLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiS25vd24gZ2FwcyAoZG9uJ3QgcGFwZXIgb3ZlciB0aGVtIHdpdGggYSBcIn08X2NvbXBvbmVudHMuY29kZT57XCI8dGV4dGFyZWE+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIik6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGFuIGFwcCBydW5uaW5nIGluXFxuXCJ9PF9jb21wb25lbnRzLmVtPntcInByZXNlbnRcIn08L19jb21wb25lbnRzLmVtPntcIiBtb2RlIGNhbid0IHlldCBzdW1tb24gdGhlIGVkaXQgZXhwZXJpZW5jZSBvbiBpdHMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJvd24gc291cmNlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBhbmRcXG5vcGVuaW5nIGEgc3BlY2lmaWMgbW91bnRlZCBmaWxlIGluIHRoZSBcIn08X2NvbXBvbmVudHMuZW0+e1wibWFpblwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGVkaXRvciAodnMuIHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJlZGl0LWZpbGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxub3ZlcmxheSkgZnJvbSBhIHN0YW5kYWxvbmUgYXBwIGlzbid0IHN1cHBvcnRlZCB5ZXQuIEJvdGggYXJlIHNwZWNpZmllZCBhc1xcbnByb3Bvc2VkIGRlbHRhcyBpbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJFRElUT1JfRklSU1RfRURJVElOR19TUEVDLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDCpzY7IHVudGlsIHRoZXkgbGFuZCwgcmVseSBvblxcbnRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJlZGl0LWZpbGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHRhc2sgYW5kIHRoZSBob3N0J3MgZWRpdCBleHBlcmllbmNlIHJhdGhlciB0aGFuIHJvbGxpbmcgeW91ciBvd24uXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInZlcmlmeS1iZWZvcmUteW91cmUtZG9uZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwidmVyaWZ5LWJlZm9yZS15b3VyZS1kb25lXCIgLz57XCJWZXJpZnkgYmVmb3JlIHlvdSdyZSBkb25lXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucHJlPjxfY29tcG9uZW50cy5jb2RlIGNsYXNzTmFtZT1cImxhbmd1YWdlLWJhc2hcIj57XCJucG0gcnVuIGJ1aWxkICAgIyBtdXN0IHBhc3Mgd2l0aCBubyB0eXBlIGVycm9yc1xcbm5wbSBydW4gbGludCAgICAjIG11c3QgcGFzcyDigJQgdGhpcyBpcyB0aGUgY2hlYXBlc3QgcHJvb2YgdGhlIEZhc3QgUmVmcmVzaCBydWxlIGhvbGRzXFxuXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMucHJlPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZW4gZXllYmFsbCB0aGUgcGFnZSAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibnBtIHJ1biBkZXZcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSBhbmQgY2xpY2sgYW55IGludGVyYWN0aXZlIGNvbnRyb2xzLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJkZWJ1Z2dpbmctb24taW1tZWRpYXRlbHlydW4tbm90LWp1c3Qtdml0ZS1kZXZcIj48SGVhZGluZ0FuY2hvciBpZD1cImRlYnVnZ2luZy1vbi1pbW1lZGlhdGVseXJ1bi1ub3QtanVzdC12aXRlLWRldlwiIC8+e1wiRGVidWdnaW5nIG9uIGltbWVkaWF0ZWx5LnJ1biAobm90IGp1c3QgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widml0ZSBkZXZcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLmNvZGU+e1widml0ZSBkZXZcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHByb3ZlcyB5b3VyIGFwcCByZW5kZXJzLCBidXQgdGhlIGZhaWx1cmUgbW9kZSB0aGlzIHdob2xlIGZpbGUgd2FybnMgYWJvdXRcXG7igJQgXCJ9PF9jb21wb25lbnRzLmVtPntcIlxcXCJ3b3JrcyBsb2NhbGx5LCBicmVha3Mgb24gaW1tZWRpYXRlbHkucnVuXFxcIlwifTwvX2NvbXBvbmVudHMuZW0+e1wiIOKAlCBvbmx5IHNob3dzIHVwIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicnVubmluZyBpbnNpZGUgdGhlXFxuaG9zdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIjogdGhlIHNhbmRib3hlZCBpZnJhbWUsIHRoZSBTREsgY2hhbm5lbCwgdGhlIGNhcGFiaWxpdHkgZ2F0ZS4gRGVidWcgdGhlcmUgdG9vLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRHJpdmUgYSByZWFsIGJyb3dzZXIgd2l0aCBDaHJvbWUgRGV2VG9vbHMgTUNQLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibWNwX19jaHJvbWUtZGV2dG9vbHNfXypcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxudG9vbHMgbmF2aWdhdGUgdGhlIHBhZ2UsIHRha2UgYW4gYWNjZXNzaWJpbGl0eSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInNuYXBzaG90XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChlbGVtZW50IFwifTxfY29tcG9uZW50cy5jb2RlPntcInVpZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCJzIHRvXFxuY2xpY2svZmlsbCksIHJ1biBKUyB3aXRoIFwifTxfY29tcG9uZW50cy5zdHJvbmc+PF9jb21wb25lbnRzLmNvZGU+e1wiZXZhbHVhdGVfc2NyaXB0XCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgYW5kIHJlYWQgdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiY29uc29sZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiArXFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJuZXR3b3JrXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCB3aGljaCBpcyB3aGVyZSBTREsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wieyBvazogZmFsc2UsIGNvZGUgfVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcmVwbGllcyBhbmQgc2FuZGJveCBlcnJvcnNcXG5hY3R1YWxseSBzdXJmYWNlLiBSZXByb2R1Y2UsIHRoZW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibGlzdF9jb25zb2xlX21lc3NhZ2VzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAvXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibGlzdF9uZXR3b3JrX3JlcXVlc3RzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjsgZG9uJ3QgZ3Vlc3MgZnJvbSB0aGUgcmVuZGVyZWQgRE9NIGFsb25lLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUnVuIHlvdXIgYXBwIFwifTxfY29tcG9uZW50cy5lbT57XCJvbiB0aGUgaG9zdFwifTwvX2NvbXBvbmVudHMuZW0+e1wiLCB3aXRoIG5vIGNvbW1pdCwgdmlhIHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJsb2NhbFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcHJvdmlkZXIuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIE1vdW50XFxueW91ciB3b3JraW5nIHRyZWUgaW50byB0aGUgcmVhbCBob3N0IGFuZCBlZGl0IGxpdmU6XCJ9e1wiXFxuXCJ9PF9jb21wb25lbnRzLnByZT48X2NvbXBvbmVudHMuY29kZSBjbGFzc05hbWU9XCJsYW5ndWFnZS1iYXNoXCI+e1wiaW1tZWRpYXRlbHkucnVuIGRldiAuIC0tb3JpZ2luIGh0dHBzOi8vbG9jYWwuaW1tZWRpYXRlbHkucnVuIC0tanNvblxcbiMg4oaSIG9wZW4gdGhlIHByaW50ZWQgL2VkaXQvbG9jYWwvPG5hbWU+LTxoYXNoOD4vLi4uL2xpdmUjaXItZW5kcG9pbnQ94oCmJmlyLXRva2VuPeKApiBsaW5rXFxuXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMucHJlPntcIlxcblwifXtcIkVkaXRzIG9uIGRpc2sgaG90LXJlbG9hZCBpbiB0aGUgaG9zdCBwcmV2aWV3LCBzbyB5b3UgZXhlcmNpc2UgdGhlIFwifTxfY29tcG9uZW50cy5lbT57XCJyZWFsXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgU0RLICtcXG5jYXBhYmlsaXR5IHBhdGggKGNvbnNlbnQgcHJvbXB0cywgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZm9yYmlkZGVuXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgbW91bnRzKSBpbnN0ZWFkIG9mIGEgbG9jYWwgc3R1Yi4gQVxcbmRldi1zZXJ2ZWQgYXBwIGdldHMgYSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImZyZXNoIGFwcEtleVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB3aXRoIG5vIHByaW9yIGdyYW50cyDigJQgaGFuZHkgZm9yIHRlc3RpbmdcXG55b3VyIGZpcnN0LXJ1biBjb25zZW50IGZsb3cgaG9uZXN0bHkuIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJAaW1tZWRpYXRlbHktcnVuL2NsaVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIE5vZGUg4omlIDE4LCBnaXRcXG5yZXBvLilcIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkFsd2F5cyB1c2UgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaHR0cHM6Ly9sb2NhbC5pbW1lZGlhdGVseS5ydW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBuZXZlciBcIn08X2NvbXBvbmVudHMuY29kZT57XCJsb2NhbGhvc3RcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBjb25maWcgaXNcXG5rZXllZCBieSBob3N0bmFtZSBhbmQgb25seSB0aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiKi5pbW1lZGlhdGVseS5ydW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG9yaWdpbiBpcyBmdWxseSB3aXJlZFxcbihzYW5kYm94ICsgYmFja2VuZCArIGF1dGggYWxsb3dsaXN0KS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkEgcGFzc2tleSAvIFRvdWNoLUlEIHByb21wdCBjYW4ndCBiZSBhdXRvbWF0ZWRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHRoZSBmaXJzdCBzZWNyZXQgdW5zZWFsIG9yXFxuc2lnbi1pbiByYWlzZXMgYSBuYXRpdmUgZGlhbG9nOyBoYW5kIHRoYXQgc3RlcCB0byBhIGh1bWFuLCBvciByZWxvYWQgYWZ0ZXIgaXQnc1xcbmNhY2hlZC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIHBsYXRmb3JtIHJlcG8gYWxzbyBzaGlwcyBhIFwifTxfY29tcG9uZW50cy5jb2RlPntcIndpbmRvdy5fX2lyVGVzdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaG9zdCBob29rIGZvciBzY3JpcHRpbmdcXG5zcGFjZS9zaGFyZSBkcmlsbHMsIGJ1dCB0aGF0IGlzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiaG9zdC1pbnRlcm5hbFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoZGV2IGJ1aWxkcyBvZiBpbW1lZGlhdGVseS5ydW5cXG5pdHNlbGYpIOKAlCBub3Qgc29tZXRoaW5nIHlvdXIgYXBwIHVzZXMgb3Igc2hvdWxkIHJlbHkgb24uIFRoZSBmdWxsIHBsYXRmb3JtLXNpZGVcXG53b3JrZmxvdyBsaXZlcyBpbiB0aGUgZG9jcyByZXBvJ3MgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widHV0b3JpYWxzL2Jyb3dzZXJfZGVidWdnaW5nL1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTwvX2NvbXBvbmVudHMuYmxvY2txdW90ZT48Lz47XG59XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNRFhDb250ZW50KHByb3BzID0ge30pIHtcbiAgY29uc3Qge3dyYXBwZXI6IE1EWExheW91dH0gPSB7XG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9O1xuICByZXR1cm4gTURYTGF5b3V0ID8gPE1EWExheW91dCB7Li4ucHJvcHN9PjxfY3JlYXRlTWR4Q29udGVudCB7Li4ucHJvcHN9IC8+PC9NRFhMYXlvdXQ+IDogX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpO1xufVxuZnVuY3Rpb24gX21pc3NpbmdNZHhSZWZlcmVuY2UoaWQsIGNvbXBvbmVudCwgcGxhY2UpIHtcbiAgdGhyb3cgbmV3IEVycm9yKFwiRXhwZWN0ZWQgXCIgKyAoY29tcG9uZW50ID8gXCJjb21wb25lbnRcIiA6IFwib2JqZWN0XCIpICsgXCIgYFwiICsgaWQgKyBcImAgdG8gYmUgZGVmaW5lZDogeW91IGxpa2VseSBmb3Jnb3QgdG8gaW1wb3J0LCBwYXNzLCBvciBwcm92aWRlIGl0LlwiICsgKHBsYWNlID8gXCJcXG5JdOKAmXMgcmVmZXJlbmNlZCBpbiB5b3VyIGNvZGUgYXQgYFwiICsgcGxhY2UgKyBcImAgaW4gYC9hcHAvQ0xBVURFLm1kYFwiIDogXCJcIikpO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFFQSxJQUFBQSxZQUFBLEdBQUFDLE9BQUE7QUFBd0YsSUFBQUMsV0FBQSxHQUFBRCxPQUFBO0FBRnhGO0FBQ0E7O0FBRUEsU0FBU0UsaUJBQWlCQSxDQUFDQyxLQUFLLEVBQUU7RUFDaEMsTUFBTUMsV0FBVyxHQUFHO01BQ2xCQyxDQUFDLEVBQUUsR0FBRztNQUNOQyxVQUFVLEVBQUUsWUFBWTtNQUN4QkMsSUFBSSxFQUFFLE1BQU07TUFDWkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsR0FBRyxFQUFFLEtBQUs7TUFDVkMsTUFBTSxFQUFFLFFBQVE7TUFDaEJDLEVBQUUsRUFBRSxJQUFJO01BQ1IsR0FBRyxJQUFBQyw2QkFBa0IsRUFBQyxDQUFDO01BQ3ZCLEdBQUdkLEtBQUssQ0FBQ2U7SUFDWCxDQUFDO0lBQUU7TUFBQ0M7SUFBYSxDQUFDLEdBQUdmLFdBQVc7RUFDaEMsSUFBSSxDQUFDZSxhQUFhLEVBQUVDLG9CQUFvQixDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUM7RUFDL0Qsb0JBQU8sSUFBQW5CLFdBQUEsQ0FBQW9CLElBQUEsRUFBQXBCLFdBQUEsQ0FBQXFCLFFBQUE7SUFBQUMsUUFBQSxnQkFBRSxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDSyxFQUFFO01BQUNlLEVBQUUsRUFBQyxzQkFBc0I7TUFBQUQsUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFzQixDQUFFLENBQUMsRUFBQyxzQkFBc0I7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNTLENBQUM7TUFBQVUsUUFBQSxHQUFFLGFBQWEsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFxQixDQUFxQixDQUFDLEVBQUMsNEpBQTRKLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0ksRUFBRTtRQUFBZSxRQUFBLEVBQUU7TUFBTSxDQUFpQixDQUFDLEVBQUMseURBQXlELGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQVUsQ0FBbUIsQ0FBQyxFQUFDLG9DQUFvQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDYyxFQUFFLEVBQUMsbURBQW1EO01BQUFELFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBbUQsQ0FBRSxDQUFDLEVBQUMsc0RBQXNEO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDUSxFQUFFO01BQUFXLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1lBQUFnQixRQUFBLEVBQUU7VUFBYSxDQUFtQixDQUFDLEVBQUMsc0JBQXNCO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLCtCQUErQixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQWlCLENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLHNDQUFzQyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQVMsQ0FBcUIsQ0FBQyxFQUFDLHNFQUFzRTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxHQUFFLHlCQUF5QixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7WUFBQWdCLFFBQUEsRUFBRTtVQUFTLENBQW1CLENBQUM7UUFBQSxDQUFvQixDQUFDLEVBQUMsYUFBYSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQyx1RkFBdUYsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBUyxDQUFtQixDQUFDLEVBQUMsR0FBRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQWdFLENBQXFCLENBQUMsRUFBQyx5RUFBeUUsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFNLENBQW1CLENBQUMsRUFBQyxvRkFBb0YsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBYyxDQUFtQixDQUFDLEVBQUMsNEJBQTRCLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLGFBQWEsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBWSxDQUFtQixDQUFDLEVBQUMsa0JBQWtCLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVUsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUEwQyxDQUFxQixDQUFDLEVBQUMsOEJBQThCO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEdBQUUsZUFBZSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7WUFBQWdCLFFBQUEsRUFBRTtVQUFNLENBQW1CLENBQUMsRUFBQyxpQ0FBaUM7UUFBQSxDQUFxQixDQUFDLEVBQUMsbUJBQW1CLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVMsQ0FBbUIsQ0FBQyxFQUFDLG9CQUFvQixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFZLENBQW1CLENBQUMsRUFBQywyQkFBMkI7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUEwQixDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFvQixDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyxzQ0FBc0MsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBZSxDQUFtQixDQUFDLEVBQUMsYUFBYSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFPLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVksQ0FBbUIsQ0FBQyxFQUFDLHFCQUFxQixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFTLENBQW1CLENBQUMsRUFBQyw2RkFBNkYsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsV0FBVyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFZLENBQW1CLENBQUMsRUFBQyxVQUFVO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBcUIsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBc0MsQ0FBbUIsQ0FBQyxFQUFDLG1FQUFtRTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQWdDLENBQXFCLENBQUMsRUFBQyx3REFBd0QsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBVSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFRLENBQW1CLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQU8sQ0FBbUIsQ0FBQyxFQUFDLGtCQUFrQixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQXFCLENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsc0dBQXNHLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQW1CLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQTJCLENBQW1CLENBQUMsRUFBQyxxQ0FBcUMsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDSSxFQUFFO1VBQUFlLFFBQUEsRUFBRTtRQUFTLENBQWlCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLFVBQVUsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBZSxDQUFtQixDQUFDLEVBQUMsVUFBVSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFxQyxDQUFtQixDQUFDLEVBQUMscUdBQXFHLEVBQUUsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNZLEVBQUU7VUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1lBQUFZLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtjQUFBUSxRQUFBLEVBQUU7WUFBaUMsQ0FBcUIsQ0FBQyxFQUFDLG9FQUFvRSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7Y0FBQWdCLFFBQUEsRUFBRTtZQUF3QixDQUFtQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7Y0FBQWdCLFFBQUEsRUFBRTtZQUFzQixDQUFtQixDQUFDLEVBQUMsZ0ZBQWdGO1VBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1lBQUFZLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtjQUFBUSxRQUFBLEVBQUU7WUFBYyxDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7Y0FBQWdCLFFBQUEsRUFBRTtZQUFnQixDQUFtQixDQUFDLEVBQUMsR0FBRztVQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtZQUFBWSxRQUFBLEdBQUUsOEJBQThCLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBZ0IsUUFBQSxFQUFFO1lBQWtCLENBQW1CLENBQUMsRUFBQyxXQUFXLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBZ0IsUUFBQSxFQUFFO1lBQWUsQ0FBbUIsQ0FBQyxFQUFDLDRMQUE0TDtVQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO1FBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFpQyxDQUFxQixDQUFDLEVBQUMsMEVBQTBFLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLGVBQWUsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBTSxDQUFtQixDQUFDLEVBQUMseUJBQXlCLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLDZCQUE2QjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTSxFQUFFO01BQUNjLEVBQUUsRUFBQyxtQ0FBbUM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFtQyxDQUFFLENBQUMsRUFBQyxzQ0FBc0M7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNTLENBQUM7TUFBQVUsUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBNkIsQ0FBbUIsQ0FBQyxFQUFDLG9GQUFvRixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFNLENBQW1CLENBQUMsRUFBQyw4RUFBOEUsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFrQixDQUFxQixDQUFDLEVBQUMsOEZBQThGLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQWUsQ0FBbUIsQ0FBQyxFQUFDLE1BQU0sZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBd0IsQ0FBbUIsQ0FBQyxFQUFDLDREQUE0RCxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQXdCLENBQXFCLENBQUMsRUFBQyx1SEFBdUgsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBK0QsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNTLENBQUM7TUFBQVUsUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBcUQsQ0FBbUIsQ0FBQyxFQUFDLE1BQU0sZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBYyxDQUFtQixDQUFDLEVBQUMsZ0NBQWdDLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBYSxDQUFxQixDQUFDLEVBQUMsbUJBQW1CLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQWMsQ0FBbUIsQ0FBQyxFQUFDLHlEQUF5RCxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFnQixDQUFtQixDQUFDLEVBQUMseURBQXlELGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQVksQ0FBbUIsQ0FBQyxFQUFDLDhLQUE4SztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDYyxFQUFFLEVBQUMsZUFBZTtNQUFBRCxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQWUsQ0FBRSxDQUFDLEVBQUMsZUFBZTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBVSxRQUFBLEdBQUUsd05BQXdOLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBVSxDQUFxQixDQUFDLEVBQUMscURBQXFELGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQXNCLENBQW1CLENBQUMsRUFBQyxNQUFNLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQVEsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNZLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEdBQUUsbUJBQW1CLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBZ0IsUUFBQSxFQUFFO1VBQWUsQ0FBbUIsQ0FBQztRQUFBLENBQW9CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQU0sQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBUyxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFPLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVUsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFRLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWUsQ0FBbUIsQ0FBQyxFQUFDLDZFQUE2RTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBWSxRQUFBLEdBQUUsNENBQTRDLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQXlCLENBQW1CLENBQUMsRUFBQyxHQUFHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1FBQUFZLFFBQUEsR0FBRSxvQ0FBb0MsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsVUFBVSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNDLENBQUM7VUFBQ3FCLElBQUksRUFBQyxvQkFBb0I7VUFBQUgsUUFBQSxFQUFFO1FBQVEsQ0FBZ0IsQ0FBQyxFQUFDLGVBQWUsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBYyxDQUFtQixDQUFDLEVBQUMsYUFBYTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTSxFQUFFO01BQUNjLEVBQUUsRUFBQyw2REFBNkQ7TUFBQUQsUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUE2RCxDQUFFLENBQUMsRUFBQywrREFBK0Q7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNTLENBQUM7TUFBQVUsUUFBQSxHQUFFLGlIQUFpSCxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFVLENBQW1CLENBQUMsRUFBQyxxSkFBcUo7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNZLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBZ0IsUUFBQSxFQUFFO1VBQXNCLENBQW1CO1FBQUMsQ0FBb0IsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDQyxDQUFDO1VBQUNxQixJQUFJLEVBQUMsZ0VBQWdFO1VBQUFILFFBQUEsRUFBRTtRQUFnRSxDQUFnQixDQUFDLEVBQUMsVUFBVSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQyx3TUFBd007TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1lBQUFnQixRQUFBLEVBQUU7VUFBd0IsQ0FBbUI7UUFBQyxDQUFvQixDQUFDLEVBQUMscUJBQXFCLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVUsQ0FBbUIsQ0FBQyxFQUFDLG1MQUFtTDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7WUFBQWdCLFFBQUEsRUFBRTtVQUE4QixDQUFtQjtRQUFDLENBQW9CLENBQUMsRUFBQyxrSUFBa0k7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1lBQUFnQixRQUFBLEVBQUU7VUFBK0IsQ0FBbUI7UUFBQyxDQUFvQixDQUFDLEVBQUMscUNBQXFDO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNTLENBQUM7TUFBQVUsUUFBQSxHQUFFLCtCQUErQixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFPLENBQW1CLENBQUMsRUFBQyxvRkFBb0YsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBOEMsQ0FBbUIsQ0FBQyxFQUFDLG1LQUFtSyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUF1QyxDQUFtQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDYyxFQUFFLEVBQUMsdURBQXVEO01BQUFELFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBdUQsQ0FBRSxDQUFDLEVBQUMsMERBQTBEO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDUyxDQUFDO01BQUFVLFFBQUEsR0FBRSxxQkFBcUIsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUF3QyxDQUFxQixDQUFDLEVBQUMsK0VBQStFLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQStCLENBQW1CLENBQUMsRUFBQyxnV0FBZ1c7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNRLEVBQUU7TUFBQVcsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEdBQUUsd0NBQXdDLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBZ0IsUUFBQSxFQUFFO1VBQXNCLENBQW1CLENBQUMsRUFBQyxHQUFHO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLHlJQUF5STtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQWdDLENBQXFCLENBQUMsRUFBQyx1S0FBdUssZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBdUMsQ0FBbUIsQ0FBQyxFQUFDLGtDQUFrQztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQW1ELENBQXFCLENBQUMsRUFBQyw4S0FBOEssZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBSSxDQUFtQixDQUFDLEVBQUMsMERBQTBELGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQU8sQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUE4QyxDQUFxQixDQUFDLEVBQUMsc0VBQXNFLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0ksRUFBRTtVQUFBZSxRQUFBLEVBQUU7UUFBTSxDQUFpQixDQUFDLEVBQUMsNkJBQTZCLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWdELENBQW1CLENBQUMsRUFBQyw0QkFBNEI7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFpQyxDQUFxQixDQUFDLEVBQUMseUJBQXlCLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQThCLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBZSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWdCLENBQW1CLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLG9GQUFvRjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQXNDLENBQXFCLENBQUMsRUFBQywwQkFBMEIsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBYyxDQUFtQixDQUFDLEVBQUMsU0FBUyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFxQixDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyxpQ0FBaUMsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBYyxDQUFtQixDQUFDLEVBQUMsZ0VBQWdFO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBNEIsQ0FBcUIsQ0FBQyxFQUFDLG9KQUFvSjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQTJELENBQXFCLENBQUMsRUFBQywwTUFBME07TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFrQyxDQUFxQixDQUFDLEVBQUMsa0NBQWtDLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLHFGQUFxRjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTSxFQUFFO01BQUNjLEVBQUUsRUFBQyx5Q0FBeUM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUF5QyxDQUFFLENBQUMsRUFBQywwQ0FBMEM7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNTLENBQUM7TUFBQVUsUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUE0RyxDQUFxQixDQUFDLEVBQUMsaUNBQWlDLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0ksRUFBRTtRQUFBZSxRQUFBLEVBQUU7TUFBSSxDQUFpQixDQUFDLEVBQUMsd0pBQXdKLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQVksQ0FBbUIsQ0FBQyxFQUFDLDJPQUEyTyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUF5QyxDQUFtQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1EsRUFBRTtNQUFBVyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsR0FBRSw0Q0FBNEMsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1lBQUFnQixRQUFBLEVBQUU7VUFBVyxDQUFtQixDQUFDLEVBQUMsUUFBUTtRQUFBLENBQXFCLENBQUMsRUFBQyx3TEFBd0wsRUFBRSxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1UsR0FBRztVQUFBUyxRQUFBLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtZQUFDb0IsU0FBUyxFQUFDLGFBQWE7WUFBQUosUUFBQSxFQUFFO1VBQTRMLENBQW1CO1FBQUMsQ0FBaUIsQ0FBQyxFQUFDLElBQUksRUFBRSxvRUFBb0U7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFzRSxDQUFxQixDQUFDLEVBQUMsNkRBQTZELGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0ksRUFBRTtVQUFBZSxRQUFBLEVBQUU7UUFBTSxDQUFpQixDQUFDLEVBQUMsNkVBQTZFO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBcUMsQ0FBcUIsQ0FBQyxFQUFDLGtDQUFrQyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFJLENBQW1CLENBQUMsRUFBQyxvQkFBb0IsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLHlFQUF5RSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLHNCQUFzQixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFPLENBQW1CLENBQUMsRUFBQyxTQUFTO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBOEMsQ0FBcUIsQ0FBQyxFQUFDLHVKQUF1SjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQXNELENBQXFCLENBQUMsRUFBQyx1T0FBdU87TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsR0FBRSwyQ0FBMkMsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1lBQUFnQixRQUFBLEVBQUU7VUFBWSxDQUFtQixDQUFDLEVBQUMsSUFBSTtRQUFBLENBQXFCLENBQUMsRUFBQyxzQkFBc0IsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDSSxFQUFFO1VBQUFlLFFBQUEsRUFBRTtRQUFTLENBQWlCLENBQUMsRUFBQyxvREFBb0QsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFZLENBQXFCLENBQUMsRUFBQyxnREFBZ0QsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDSSxFQUFFO1VBQUFlLFFBQUEsRUFBRTtRQUFNLENBQWlCLENBQUMsRUFBQyxtQkFBbUIsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsa0dBQWtHLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQThCLENBQW1CLENBQUMsRUFBQyxxQ0FBcUMsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsb0VBQW9FO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNNLEVBQUU7TUFBQ2MsRUFBRSxFQUFDLDBCQUEwQjtNQUFBRCxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQTBCLENBQUUsQ0FBQyxFQUFDLDJCQUEyQjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1UsR0FBRztNQUFBUyxRQUFBLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtRQUFDb0IsU0FBUyxFQUFDLGVBQWU7UUFBQUosUUFBQSxFQUFFO01BQXlJLENBQW1CO0lBQUMsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDUyxDQUFDO01BQUFVLFFBQUEsR0FBRSx5QkFBeUIsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBYSxDQUFtQixDQUFDLEVBQUMsdUNBQXVDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTSxFQUFFO01BQUNjLEVBQUUsRUFBQywrQ0FBK0M7TUFBQUQsUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUErQyxDQUFFLENBQUMsRUFBQyx5Q0FBeUMsZUFBQyxJQUFBdkIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBVSxDQUFtQixDQUFDLEVBQUMsR0FBRztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBVSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFVLENBQW1CLENBQUMsRUFBQyxnRkFBZ0YsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDSSxFQUFFO1FBQUFlLFFBQUEsRUFBRTtNQUE4QyxDQUFpQixDQUFDLEVBQUMsbUJBQW1CLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBMEIsQ0FBcUIsQ0FBQyxFQUFDLGdGQUFnRjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1ksRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFnRCxDQUFxQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUF5QixDQUFtQixDQUFDLEVBQUMsbURBQW1ELGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBVSxDQUFxQixDQUFDLEVBQUMsWUFBWSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFLLENBQW1CLENBQUMsRUFBQyxpQ0FBaUMsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1lBQUFnQixRQUFBLEVBQUU7VUFBaUIsQ0FBbUI7UUFBQyxDQUFvQixDQUFDLEVBQUMsaUJBQWlCLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBUyxDQUFxQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQVMsQ0FBcUIsQ0FBQyxFQUFDLHdCQUF3QixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFxQixDQUFtQixDQUFDLEVBQUMsaUVBQWlFLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQXVCLENBQW1CLENBQUMsRUFBQyxNQUFNLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQXVCLENBQW1CLENBQUMsRUFBQyw0Q0FBNEM7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsR0FBRSxlQUFlLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0ksRUFBRTtZQUFBZSxRQUFBLEVBQUU7VUFBYSxDQUFpQixDQUFDLEVBQUMsNEJBQTRCLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBZ0IsUUFBQSxFQUFFO1VBQU8sQ0FBbUIsQ0FBQyxFQUFDLFlBQVk7UUFBQSxDQUFxQixDQUFDLEVBQUMsNkRBQTZELEVBQUUsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNVLEdBQUc7VUFBQVMsUUFBQSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7WUFBQ29CLFNBQVMsRUFBQyxlQUFlO1lBQUFKLFFBQUEsRUFBRTtVQUErSixDQUFtQjtRQUFDLENBQWlCLENBQUMsRUFBQyxJQUFJLEVBQUUsb0VBQW9FLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0ksRUFBRTtVQUFBZSxRQUFBLEVBQUU7UUFBTSxDQUFpQixDQUFDLEVBQUMsNENBQTRDLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLDhEQUE4RCxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQWMsQ0FBcUIsQ0FBQyxFQUFDLG9GQUFvRixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFzQixDQUFtQixDQUFDLEVBQUMsMEJBQTBCO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEdBQUUsYUFBYSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7WUFBQWdCLFFBQUEsRUFBRTtVQUErQixDQUFtQixDQUFDLEVBQUMsVUFBVSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7WUFBQWdCLFFBQUEsRUFBRTtVQUFXLENBQW1CLENBQUM7UUFBQSxDQUFvQixDQUFDLEVBQUMsK0NBQStDLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQW1CLENBQW1CLENBQUMsRUFBQywrREFBK0Q7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFnRCxDQUFxQixDQUFDLEVBQUMseUhBQXlIO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNFLFVBQVU7TUFBQWlCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1MsQ0FBQztRQUFBVSxRQUFBLEdBQUUsaUNBQWlDLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWlCLENBQW1CLENBQUMsRUFBQyw0REFBNEQsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFlLENBQXFCLENBQUMsRUFBQyxzSkFBc0osZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBOEIsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7TUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQXlCLENBQUM7RUFBQSxDQUFFLENBQUM7QUFDaHR5QjtBQUNlLFNBQVNLLFVBQVVBLENBQUN6QixLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUU7RUFDN0MsTUFBTTtJQUFDMEIsT0FBTyxFQUFFQztFQUFTLENBQUMsR0FBRztJQUMzQixHQUFHLElBQUFiLDZCQUFrQixFQUFDLENBQUM7SUFDdkIsR0FBR2QsS0FBSyxDQUFDZTtFQUNYLENBQUM7RUFDRCxPQUFPWSxTQUFTLGdCQUFHLElBQUE3QixXQUFBLENBQUF3QixHQUFBLEVBQUNLLFNBQVM7SUFBQSxHQUFLM0IsS0FBSztJQUFBb0IsUUFBQSxlQUFFLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUN2QixpQkFBaUI7TUFBQSxHQUFLQztJQUFLLENBQUc7RUFBQyxDQUFXLENBQUMsR0FBR0QsaUJBQWlCLENBQUNDLEtBQUssQ0FBQztBQUNsSDtBQUFDNEIsRUFBQSxHQU51QkgsVUFBVTtBQU9sQyxTQUFTUixvQkFBb0JBLENBQUNJLEVBQUUsRUFBRVEsU0FBUyxFQUFFQyxLQUFLLEVBQUU7RUFDbEQsTUFBTSxJQUFJQyxLQUFLLENBQUMsV0FBVyxJQUFJRixTQUFTLEdBQUcsV0FBVyxHQUFHLFFBQVEsQ0FBQyxHQUFHLElBQUksR0FBR1IsRUFBRSxHQUFHLG9FQUFvRSxJQUFJUyxLQUFLLEdBQUcscUNBQXFDLEdBQUdBLEtBQUssR0FBRyx1QkFBdUIsR0FBRyxFQUFFLENBQUMsQ0FBQztBQUNqUDtBQUFDLElBQUFGLEVBQUE7QUFBQUksWUFBQSxDQUFBSixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}