var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {#!/usr/bin/env node
// check-theme-contrast.mjs — AA contrast asserted from the DECLARED tokens, for
// every catalogue theme, in BOTH polarities (R3-308; 02-theme-contract §5).
//
// WHY A SCRIPT AND NOT A REVIEWER. The alternates are where contrast breaks — the
// default palette has had a year of eyes on it and new polarities have not — so
// the check belongs in `verify` against the token values in GroveApp.css, not in a
// reviewer's judgement. A prose rule is not checkable (ways_of_working §4).
//
// WHAT IT READS. The theme token blocks in src/GroveApp.css, by selector shape:
//
//   .grove-root                                      → default, dark (the base)
//   .grove-root[data-theme="light"]                  → default, light
//   .grove-root[data-grove-theme="X"]                → X, its PREFERRED polarity
//   .grove-root[data-grove-theme="X"][data-theme=Y]  → X, the OTHER polarity
//
// The BOTH-POLARITIES rule is enforced structurally: a theme seen in the CSS must
// resolve to exactly a light and a dark token map — a bare block with no paired
// [data-theme] sibling (single-polarity by construction, the exact bug R3-308
// fixes) fails the check.
//
// THE PAIRS TABLE is the contract's coverage floor, stated once and test-visible:
// body ink tiers on every ground at AA (4.5:1); accent on the page grounds at
// 3:1 (accent is Grove's large/bold register — headings, icons, controls; body
// text and links are ink). `--ink-3` is deliberately NOT floored: it is the
// de-emphasized tier (timestamps, metas) and even the default palette holds it
// below AA by design — pretending otherwise would fail every theme on day one
// and teach everyone to ignore the check.
//
// FAULT INJECTION. `--self-test` plants a sub-AA pair, a missing-polarity theme,
// and an unsupported colour, and asserts each fails for the reason claimed — a
// checker nobody has watched reject anything is an assumption, not a guard.
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.PAIRS = void 0;
exports.checkThemes = checkThemes;
exports.collectThemes = collectThemes;
exports.contrast = void 0;
exports.parseColor = parseColor;
exports.parseTokenBlocks = parseTokenBlocks;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.some.js");
var _nodeFs = require("node:fs");
var _nodeUrl = require("node:url");
var _nodePath = require("node:path");
const root = (0, _nodePath.join)((0, _nodePath.dirname)((0, _nodeUrl.fileURLToPath)($ir_import_meta.url)), '..');
const CSS_PATH = (0, _nodePath.join)(root, 'src', 'GroveApp.css');

/** The coverage floor: [token, ground, minRatio]. Exported shape for the self-test. */
const PAIRS = exports.PAIRS = [['--ink', '--bg', 4.5], ['--ink', '--panel', 4.5], ['--ink', '--panel-2', 4.5], ['--ink-2', '--bg', 4.5], ['--ink-2', '--panel', 4.5], ['--ink-2', '--panel-2', 4.5], ['--accent', '--bg', 3.0], ['--accent', '--panel', 3.0]];

// ── colour: everything resolves to linear-light sRGB triplets ────────────────

/** Gamma-decode one sRGB channel (0..1). */
const srgbToLinear = c => c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);

/** WCAG relative luminance of an sRGB triplet (0..1 each). */
function luminance([r, g, b]) {
  const [R, G, B] = [r, g, b].map(srgbToLinear);
  return 0.2126 * R + 0.7152 * G + 0.0722 * B;
}

/** The WCAG contrast ratio between two opaque colours. */
const contrast = (a, b) => {
  const [l1, l2] = [luminance(a), luminance(b)].sort((x, y) => y - x);
  return (l1 + 0.05) / (l2 + 0.05);
};

/** oklch(L C H) → sRGB (0..1, clamped to sRGB gamut). CSS Color 4 matrices. */
exports.contrast = contrast;
function oklchToSrgb(L, C, Hdeg) {
  const h = Hdeg * Math.PI / 180;
  const a = C * Math.cos(h);
  const b = C * Math.sin(h);
  const l_ = L + 0.3963377774 * a + 0.2158037573 * b;
  const m_ = L - 0.1055613458 * a - 0.0638541728 * b;
  const s_ = L - 0.0894841775 * a - 1.291485548 * b;
  const l = l_ ** 3;
  const m = m_ ** 3;
  const s = s_ ** 3;
  const r = +4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s;
  const g = -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s;
  const bl = -0.0041960863 * l - 0.7034186147 * m + 1.707614701 * s;
  // Clamp to gamut: the declared accents are in-gamut; a future theme that isn't
  // gets the nearest sRGB colour, which is also what the browser renders.
  return [r, g, bl].map(v => Math.min(1, Math.max(0, v)));
}

/**
 * Parse one CSS colour value into an sRGB triplet, or `null` when it is a shape
 * this checker does not floor (rgba()/gradients/none — the non-text tokens).
 */
function parseColor(value) {
  const v = value.trim().toLowerCase();
  const hex = v.match(/^#([0-9a-f]{3}|[0-9a-f]{6})$/);
  if (hex) {
    const h = hex[1].length === 3 ? [...hex[1]].map(c => c + c).join('') : hex[1];
    return [0, 2, 4].map(i => parseInt(h.slice(i, i + 2), 16) / 255);
  }
  const ok = v.match(/^oklch\(\s*([\d.]+)\s+([\d.]+)\s+([\d.-]+)/);
  if (ok) return oklchToSrgb(Number(ok[1]), Number(ok[2]), Number(ok[3]));
  return null;
}

// ── the token blocks ─────────────────────────────────────────────────────────

/** Parse `.grove-root…` blocks into { selector, decls: Map<token,value> }. */
function parseTokenBlocks(css) {
  const out = [];
  const re = /\.grove-root[^{]*\{[^}]*\}/g;
  for (const m of css.matchAll(re)) {
    const block = m[0];
    const selector = block.slice(0, block.indexOf('{')).trim();
    const decls = new Map();
    for (const d of block.slice(block.indexOf('{') + 1, -1).split(';')) {
      const i = d.indexOf(':');
      if (i > 0) decls.set(d.slice(0, i).trim(), d.slice(i + 1).trim());
    }
    // Only the token-only theme blocks carry custom properties at top level; the
    // shell blocks (buttons, links) are skipped by having no declarations we read.
    out.push({
      selector,
      decls
    });
  }
  return out;
}

/**
 * Organize blocks into themes × polarities. The bare `[data-grove-theme="X"]`
 * block is X's PREFERRED polarity; the paired `[data-theme=Y]` block is the other
 * one. The base `.grove-root` block is default/dark; `[data-theme="light"]` alone
 * (single attribute, no grove-theme) is default/light.
 */
function collectThemes(blocks) {
  const themes = new Map(); // id → { light?: decls, dark?: decls }
  const put = (id, polarity, decls) => {
    if (!themes.has(id)) themes.set(id, {});
    themes.get(id)[polarity] = decls;
  };
  for (const {
    selector,
    decls
  } of blocks) {
    const grove = selector.match(/\[data-grove-theme="([^"]+)"\]/);
    const theme = selector.match(/\[data-theme="([^"]+)"\]/);
    if (grove) {
      // The paired block names its polarity; the bare block is the OTHER one.
      if (theme) put(grove[1], theme[1], decls);else {
        // Filled in below, once we know which polarity the pair names.
        const bare = themes.get(grove[1]) ?? {};
        bare.bare = decls;
        themes.set(grove[1], bare);
      }
    } else if (theme) {
      put('default', theme[1], decls);
    } else if (selector === '.grove-root') {
      // EXACTLY the base block — the shell's compound selectors (`.grove-root a`,
      // `.grove-root button`, …) also reach here and must not overwrite it.
      put('default', 'dark', decls);
    }
  }
  for (const [id, t] of themes) {
    if (t.bare) {
      const other = t.light ? 'dark' : 'light';
      t[other] = t.bare;
      delete t.bare;
    }
  }
  return themes;
}

/** Run the coverage floor over every theme × polarity. Returns failures[]. */
function checkThemes(themes, pairs = PAIRS) {
  const failures = [];
  if (themes.size === 0) return [{
    theme: '(none)',
    why: 'no theme token blocks found'
  }];
  for (const [id, polarities] of [...themes].sort()) {
    for (const polarity of ['light', 'dark']) {
      const decls = polarities[polarity];
      if (!decls || decls.size === 0) {
        failures.push({
          theme: id,
          polarity,
          why: 'missing polarity — every theme ships BOTH'
        });
        continue;
      }
      for (const [fg, bg, min] of pairs) {
        const fgV = decls.get(fg);
        const bgV = decls.get(bg);
        if (!fgV || !bgV) {
          failures.push({
            theme: id,
            polarity,
            why: `${!fgV ? fg : bg} not declared`
          });
          continue;
        }
        const fgC = parseColor(fgV);
        const bgC = parseColor(bgV);
        if (!fgC || !bgC) {
          failures.push({
            theme: id,
            polarity,
            why: `${!fgC ? fg : bg}=${!fgC ? fgV : bgV} is not a contrast-checkable colour`
          });
          continue;
        }
        const ratio = contrast(fgC, bgC);
        if (ratio < min) {
          failures.push({
            theme: id,
            polarity,
            why: `${fg} on ${bg} = ${ratio.toFixed(2)}:1 < ${min}:1 (${fgV} on ${bgV})`
          });
        }
      }
    }
  }
  return failures;
}

// ── entry points ─────────────────────────────────────────────────────────────

function runOn(css) {
  return checkThemes(collectThemes(parseTokenBlocks(css)));
}
const css = (0, _nodeFs.readFileSync)(CSS_PATH, 'utf8');
if (process.argv.includes('--self-test')) {
  let failed = 0;
  const expect = (name, cond) => {
    if (cond) console.log(`  ✓ ${name}`);else {
      failed++;
      console.error(`  ✗ ${name}`);
    }
  };
  const GOOD = `
    .grove-root { --bg: #0a0b11; --panel: #13141d; --panel-2: #191b26; --ink: #ecebf4; --ink-2: #9b97b3; --accent: #f49ad4; }
    .grove-root[data-theme="light"] { --bg: #f6f4fb; --panel: #ffffff; --panel-2: #f0ecf8; --ink: #1c1726; --ink-2: #5d5670; --accent: #b02a6f; }
    .grove-root[data-grove-theme="x"] { --bg: #101010; --panel: #1a1a1a; --panel-2: #222222; --ink: #f0f0f0; --ink-2: #b0b0b0; --accent: #e06060; }
    .grove-root[data-grove-theme="x"][data-theme="light"] { --bg: #fafafa; --panel: #ffffff; --panel-2: #f0f0f0; --ink: #202020; --ink-2: #555555; --accent: #a03030; }
  `;
  // 1. the good fixture passes.
  expect('a both-polarity, AA fixture passes', runOn(GOOD).length === 0);
  // 2. a planted sub-AA pair fails — in an ALTERNATE theme, in the LIGHT polarity:
  // the exact regression this gate exists to catch.
  const PLANTED = GOOD.replace('.grove-root[data-grove-theme="x"][data-theme="light"] { --bg: #fafafa;', '.grove-root[data-grove-theme="x"][data-theme="light"] { --bg: #0a0a0a;');
  const planted = runOn(PLANTED);
  expect('a planted sub-AA pair fails', planted.length > 0 && /--ink on --bg/.test(planted[0].why));
  // 3. single-polarity by construction fails — the bare block with no pair.
  const SINGLE = GOOD.replace(/\n\s*\.grove-root\[data-grove-theme="x"\]\[data-theme="light"\][^\n]*/, '');
  const single = runOn(SINGLE);
  expect('a theme missing one polarity fails', single.some(f => /missing polarity/.test(f.why)));
  // 4. an unparseable colour fails LOUDLY rather than being skipped.
  const WEIRD = GOOD.replace('--accent: #e06060;', '--accent: var(--nope);');
  expect('an uncheckable accent colour fails', runOn(WEIRD).length > 0);
  // 5. the real stylesheet's shape parses into themes (the loader half).
  const themes = collectThemes(parseTokenBlocks(css));
  expect('the shipped CSS yields default + 3 alternates, both polarities', themes.size === 4 && [...themes.values()].every(t => t.light && t.dark));
  console.log(failed === 0 ? 'theme-contrast self-test: 5/5' : `theme-contrast self-test: FAILED ${failed}`);
  process.exit(failed === 0 ? 0 : 1);
}
const failures = runOn(css);
if (failures.length > 0) {
  console.error(`✗ theme contrast: ${failures.length} pair(s) below the floor`);
  for (const f of failures) console.error(`  · ${f.theme}/${f.polarity}: ${f.why}`);
  process.exit(1);
}
console.log(`✓ theme contrast: every theme, both polarities, at the floor (${[...collectThemes(parseTokenBlocks(css)).keys()].join(', ')})`);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJPYmplY3QiLCJkZWZpbmVQcm9wZXJ0eSIsImV4cG9ydHMiLCJ2YWx1ZSIsIlBBSVJTIiwiY2hlY2tUaGVtZXMiLCJjb2xsZWN0VGhlbWVzIiwiY29udHJhc3QiLCJwYXJzZUNvbG9yIiwicGFyc2VUb2tlbkJsb2NrcyIsInJlcXVpcmUiLCJfbm9kZUZzIiwiX25vZGVVcmwiLCJfbm9kZVBhdGgiLCJyb290Iiwiam9pbiIsImRpcm5hbWUiLCJmaWxlVVJMVG9QYXRoIiwiJGlyX2ltcG9ydF9tZXRhIiwidXJsIiwiQ1NTX1BBVEgiLCJzcmdiVG9MaW5lYXIiLCJjIiwiTWF0aCIsInBvdyIsImx1bWluYW5jZSIsInIiLCJnIiwiYiIsIlIiLCJHIiwiQiIsIm1hcCIsImEiLCJsMSIsImwyIiwic29ydCIsIngiLCJ5Iiwib2tsY2hUb1NyZ2IiLCJMIiwiQyIsIkhkZWciLCJoIiwiUEkiLCJjb3MiLCJzaW4iLCJsXyIsIm1fIiwic18iLCJsIiwibSIsInMiLCJibCIsInYiLCJtaW4iLCJtYXgiLCJ0cmltIiwidG9Mb3dlckNhc2UiLCJoZXgiLCJtYXRjaCIsImxlbmd0aCIsImkiLCJwYXJzZUludCIsInNsaWNlIiwib2siLCJOdW1iZXIiLCJjc3MiLCJvdXQiLCJyZSIsIm1hdGNoQWxsIiwiYmxvY2siLCJzZWxlY3RvciIsImluZGV4T2YiLCJkZWNscyIsIk1hcCIsImQiLCJzcGxpdCIsInNldCIsInB1c2giLCJibG9ja3MiLCJ0aGVtZXMiLCJwdXQiLCJpZCIsInBvbGFyaXR5IiwiaGFzIiwiZ2V0IiwiZ3JvdmUiLCJ0aGVtZSIsImJhcmUiLCJ0Iiwib3RoZXIiLCJsaWdodCIsInBhaXJzIiwiZmFpbHVyZXMiLCJzaXplIiwid2h5IiwicG9sYXJpdGllcyIsImZnIiwiYmciLCJmZ1YiLCJiZ1YiLCJmZ0MiLCJiZ0MiLCJyYXRpbyIsInRvRml4ZWQiLCJydW5PbiIsInJlYWRGaWxlU3luYyIsInByb2Nlc3MiLCJhcmd2IiwiaW5jbHVkZXMiLCJmYWlsZWQiLCJleHBlY3QiLCJuYW1lIiwiY29uZCIsImNvbnNvbGUiLCJsb2ciLCJlcnJvciIsIkdPT0QiLCJQTEFOVEVEIiwicmVwbGFjZSIsInBsYW50ZWQiLCJ0ZXN0IiwiU0lOR0xFIiwic2luZ2xlIiwic29tZSIsImYiLCJXRUlSRCIsInZhbHVlcyIsImV2ZXJ5IiwiZGFyayIsImV4aXQiLCJrZXlzIl0sInNvdXJjZXMiOlsiY2hlY2stdGhlbWUtY29udHJhc3QubWpzIl0sInNvdXJjZXNDb250ZW50IjpbIiMhL3Vzci9iaW4vZW52IG5vZGVcbi8vIGNoZWNrLXRoZW1lLWNvbnRyYXN0Lm1qcyDigJQgQUEgY29udHJhc3QgYXNzZXJ0ZWQgZnJvbSB0aGUgREVDTEFSRUQgdG9rZW5zLCBmb3Jcbi8vIGV2ZXJ5IGNhdGFsb2d1ZSB0aGVtZSwgaW4gQk9USCBwb2xhcml0aWVzIChSMy0zMDg7IDAyLXRoZW1lLWNvbnRyYWN0IMKnNSkuXG4vL1xuLy8gV0hZIEEgU0NSSVBUIEFORCBOT1QgQSBSRVZJRVdFUi4gVGhlIGFsdGVybmF0ZXMgYXJlIHdoZXJlIGNvbnRyYXN0IGJyZWFrcyDigJQgdGhlXG4vLyBkZWZhdWx0IHBhbGV0dGUgaGFzIGhhZCBhIHllYXIgb2YgZXllcyBvbiBpdCBhbmQgbmV3IHBvbGFyaXRpZXMgaGF2ZSBub3Qg4oCUIHNvXG4vLyB0aGUgY2hlY2sgYmVsb25ncyBpbiBgdmVyaWZ5YCBhZ2FpbnN0IHRoZSB0b2tlbiB2YWx1ZXMgaW4gR3JvdmVBcHAuY3NzLCBub3QgaW4gYVxuLy8gcmV2aWV3ZXIncyBqdWRnZW1lbnQuIEEgcHJvc2UgcnVsZSBpcyBub3QgY2hlY2thYmxlICh3YXlzX29mX3dvcmtpbmcgwqc0KS5cbi8vXG4vLyBXSEFUIElUIFJFQURTLiBUaGUgdGhlbWUgdG9rZW4gYmxvY2tzIGluIHNyYy9Hcm92ZUFwcC5jc3MsIGJ5IHNlbGVjdG9yIHNoYXBlOlxuLy9cbi8vICAgLmdyb3ZlLXJvb3QgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKGkiBkZWZhdWx0LCBkYXJrICh0aGUgYmFzZSlcbi8vICAgLmdyb3ZlLXJvb3RbZGF0YS10aGVtZT1cImxpZ2h0XCJdICAgICAgICAgICAgICAgICAg4oaSIGRlZmF1bHQsIGxpZ2h0XG4vLyAgIC5ncm92ZS1yb290W2RhdGEtZ3JvdmUtdGhlbWU9XCJYXCJdICAgICAgICAgICAgICAgIOKGkiBYLCBpdHMgUFJFRkVSUkVEIHBvbGFyaXR5XG4vLyAgIC5ncm92ZS1yb290W2RhdGEtZ3JvdmUtdGhlbWU9XCJYXCJdW2RhdGEtdGhlbWU9WV0gIOKGkiBYLCB0aGUgT1RIRVIgcG9sYXJpdHlcbi8vXG4vLyBUaGUgQk9USC1QT0xBUklUSUVTIHJ1bGUgaXMgZW5mb3JjZWQgc3RydWN0dXJhbGx5OiBhIHRoZW1lIHNlZW4gaW4gdGhlIENTUyBtdXN0XG4vLyByZXNvbHZlIHRvIGV4YWN0bHkgYSBsaWdodCBhbmQgYSBkYXJrIHRva2VuIG1hcCDigJQgYSBiYXJlIGJsb2NrIHdpdGggbm8gcGFpcmVkXG4vLyBbZGF0YS10aGVtZV0gc2libGluZyAoc2luZ2xlLXBvbGFyaXR5IGJ5IGNvbnN0cnVjdGlvbiwgdGhlIGV4YWN0IGJ1ZyBSMy0zMDhcbi8vIGZpeGVzKSBmYWlscyB0aGUgY2hlY2suXG4vL1xuLy8gVEhFIFBBSVJTIFRBQkxFIGlzIHRoZSBjb250cmFjdCdzIGNvdmVyYWdlIGZsb29yLCBzdGF0ZWQgb25jZSBhbmQgdGVzdC12aXNpYmxlOlxuLy8gYm9keSBpbmsgdGllcnMgb24gZXZlcnkgZ3JvdW5kIGF0IEFBICg0LjU6MSk7IGFjY2VudCBvbiB0aGUgcGFnZSBncm91bmRzIGF0XG4vLyAzOjEgKGFjY2VudCBpcyBHcm92ZSdzIGxhcmdlL2JvbGQgcmVnaXN0ZXIg4oCUIGhlYWRpbmdzLCBpY29ucywgY29udHJvbHM7IGJvZHlcbi8vIHRleHQgYW5kIGxpbmtzIGFyZSBpbmspLiBgLS1pbmstM2AgaXMgZGVsaWJlcmF0ZWx5IE5PVCBmbG9vcmVkOiBpdCBpcyB0aGVcbi8vIGRlLWVtcGhhc2l6ZWQgdGllciAodGltZXN0YW1wcywgbWV0YXMpIGFuZCBldmVuIHRoZSBkZWZhdWx0IHBhbGV0dGUgaG9sZHMgaXRcbi8vIGJlbG93IEFBIGJ5IGRlc2lnbiDigJQgcHJldGVuZGluZyBvdGhlcndpc2Ugd291bGQgZmFpbCBldmVyeSB0aGVtZSBvbiBkYXkgb25lXG4vLyBhbmQgdGVhY2ggZXZlcnlvbmUgdG8gaWdub3JlIHRoZSBjaGVjay5cbi8vXG4vLyBGQVVMVCBJTkpFQ1RJT04uIGAtLXNlbGYtdGVzdGAgcGxhbnRzIGEgc3ViLUFBIHBhaXIsIGEgbWlzc2luZy1wb2xhcml0eSB0aGVtZSxcbi8vIGFuZCBhbiB1bnN1cHBvcnRlZCBjb2xvdXIsIGFuZCBhc3NlcnRzIGVhY2ggZmFpbHMgZm9yIHRoZSByZWFzb24gY2xhaW1lZCDigJQgYVxuLy8gY2hlY2tlciBub2JvZHkgaGFzIHdhdGNoZWQgcmVqZWN0IGFueXRoaW5nIGlzIGFuIGFzc3VtcHRpb24sIG5vdCBhIGd1YXJkLlxuXG5pbXBvcnQgeyByZWFkRmlsZVN5bmMgfSBmcm9tICdub2RlOmZzJztcbmltcG9ydCB7IGZpbGVVUkxUb1BhdGggfSBmcm9tICdub2RlOnVybCc7XG5pbXBvcnQgeyBkaXJuYW1lLCBqb2luIH0gZnJvbSAnbm9kZTpwYXRoJztcblxuY29uc3Qgcm9vdCA9IGpvaW4oZGlybmFtZShmaWxlVVJMVG9QYXRoKGltcG9ydC5tZXRhLnVybCkpLCAnLi4nKTtcbmNvbnN0IENTU19QQVRIID0gam9pbihyb290LCAnc3JjJywgJ0dyb3ZlQXBwLmNzcycpO1xuXG4vKiogVGhlIGNvdmVyYWdlIGZsb29yOiBbdG9rZW4sIGdyb3VuZCwgbWluUmF0aW9dLiBFeHBvcnRlZCBzaGFwZSBmb3IgdGhlIHNlbGYtdGVzdC4gKi9cbmV4cG9ydCBjb25zdCBQQUlSUyA9IFtcbiAgWyctLWluaycsICctLWJnJywgNC41XSxcbiAgWyctLWluaycsICctLXBhbmVsJywgNC41XSxcbiAgWyctLWluaycsICctLXBhbmVsLTInLCA0LjVdLFxuICBbJy0taW5rLTInLCAnLS1iZycsIDQuNV0sXG4gIFsnLS1pbmstMicsICctLXBhbmVsJywgNC41XSxcbiAgWyctLWluay0yJywgJy0tcGFuZWwtMicsIDQuNV0sXG4gIFsnLS1hY2NlbnQnLCAnLS1iZycsIDMuMF0sXG4gIFsnLS1hY2NlbnQnLCAnLS1wYW5lbCcsIDMuMF0sXG5dO1xuXG4vLyDilIDilIAgY29sb3VyOiBldmVyeXRoaW5nIHJlc29sdmVzIHRvIGxpbmVhci1saWdodCBzUkdCIHRyaXBsZXRzIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG4vKiogR2FtbWEtZGVjb2RlIG9uZSBzUkdCIGNoYW5uZWwgKDAuLjEpLiAqL1xuY29uc3Qgc3JnYlRvTGluZWFyID0gKGMpID0+IChjIDw9IDAuMDQwNDUgPyBjIC8gMTIuOTIgOiBNYXRoLnBvdygoYyArIDAuMDU1KSAvIDEuMDU1LCAyLjQpKTtcblxuLyoqIFdDQUcgcmVsYXRpdmUgbHVtaW5hbmNlIG9mIGFuIHNSR0IgdHJpcGxldCAoMC4uMSBlYWNoKS4gKi9cbmZ1bmN0aW9uIGx1bWluYW5jZShbciwgZywgYl0pIHtcbiAgY29uc3QgW1IsIEcsIEJdID0gW3IsIGcsIGJdLm1hcChzcmdiVG9MaW5lYXIpO1xuICByZXR1cm4gMC4yMTI2ICogUiArIDAuNzE1MiAqIEcgKyAwLjA3MjIgKiBCO1xufVxuXG4vKiogVGhlIFdDQUcgY29udHJhc3QgcmF0aW8gYmV0d2VlbiB0d28gb3BhcXVlIGNvbG91cnMuICovXG5leHBvcnQgY29uc3QgY29udHJhc3QgPSAoYSwgYikgPT4ge1xuICBjb25zdCBbbDEsIGwyXSA9IFtsdW1pbmFuY2UoYSksIGx1bWluYW5jZShiKV0uc29ydCgoeCwgeSkgPT4geSAtIHgpO1xuICByZXR1cm4gKGwxICsgMC4wNSkgLyAobDIgKyAwLjA1KTtcbn07XG5cbi8qKiBva2xjaChMIEMgSCkg4oaSIHNSR0IgKDAuLjEsIGNsYW1wZWQgdG8gc1JHQiBnYW11dCkuIENTUyBDb2xvciA0IG1hdHJpY2VzLiAqL1xuZnVuY3Rpb24gb2tsY2hUb1NyZ2IoTCwgQywgSGRlZykge1xuICBjb25zdCBoID0gKEhkZWcgKiBNYXRoLlBJKSAvIDE4MDtcbiAgY29uc3QgYSA9IEMgKiBNYXRoLmNvcyhoKTtcbiAgY29uc3QgYiA9IEMgKiBNYXRoLnNpbihoKTtcbiAgY29uc3QgbF8gPSBMICsgMC4zOTYzMzc3Nzc0ICogYSArIDAuMjE1ODAzNzU3MyAqIGI7XG4gIGNvbnN0IG1fID0gTCAtIDAuMTA1NTYxMzQ1OCAqIGEgLSAwLjA2Mzg1NDE3MjggKiBiO1xuICBjb25zdCBzXyA9IEwgLSAwLjA4OTQ4NDE3NzUgKiBhIC0gMS4yOTE0ODU1NDggKiBiO1xuICBjb25zdCBsID0gbF8gKiogMztcbiAgY29uc3QgbSA9IG1fICoqIDM7XG4gIGNvbnN0IHMgPSBzXyAqKiAzO1xuICBjb25zdCByID0gKzQuMDc2NzQxNjYyMSAqIGwgLSAzLjMwNzcxMTU5MTMgKiBtICsgMC4yMzA5Njk5MjkyICogcztcbiAgY29uc3QgZyA9IC0xLjI2ODQzODAwNDYgKiBsICsgMi42MDk3NTc0MDExICogbSAtIDAuMzQxMzE5Mzk2NSAqIHM7XG4gIGNvbnN0IGJsID0gLTAuMDA0MTk2MDg2MyAqIGwgLSAwLjcwMzQxODYxNDcgKiBtICsgMS43MDc2MTQ3MDEgKiBzO1xuICAvLyBDbGFtcCB0byBnYW11dDogdGhlIGRlY2xhcmVkIGFjY2VudHMgYXJlIGluLWdhbXV0OyBhIGZ1dHVyZSB0aGVtZSB0aGF0IGlzbid0XG4gIC8vIGdldHMgdGhlIG5lYXJlc3Qgc1JHQiBjb2xvdXIsIHdoaWNoIGlzIGFsc28gd2hhdCB0aGUgYnJvd3NlciByZW5kZXJzLlxuICByZXR1cm4gW3IsIGcsIGJsXS5tYXAoKHYpID0+IE1hdGgubWluKDEsIE1hdGgubWF4KDAsIHYpKSk7XG59XG5cbi8qKlxuICogUGFyc2Ugb25lIENTUyBjb2xvdXIgdmFsdWUgaW50byBhbiBzUkdCIHRyaXBsZXQsIG9yIGBudWxsYCB3aGVuIGl0IGlzIGEgc2hhcGVcbiAqIHRoaXMgY2hlY2tlciBkb2VzIG5vdCBmbG9vciAocmdiYSgpL2dyYWRpZW50cy9ub25lIOKAlCB0aGUgbm9uLXRleHQgdG9rZW5zKS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlQ29sb3IodmFsdWUpIHtcbiAgY29uc3QgdiA9IHZhbHVlLnRyaW0oKS50b0xvd2VyQ2FzZSgpO1xuICBjb25zdCBoZXggPSB2Lm1hdGNoKC9eIyhbMC05YS1mXXszfXxbMC05YS1mXXs2fSkkLyk7XG4gIGlmIChoZXgpIHtcbiAgICBjb25zdCBoID0gaGV4WzFdLmxlbmd0aCA9PT0gMyA/IFsuLi5oZXhbMV1dLm1hcCgoYykgPT4gYyArIGMpLmpvaW4oJycpIDogaGV4WzFdO1xuICAgIHJldHVybiBbMCwgMiwgNF0ubWFwKChpKSA9PiBwYXJzZUludChoLnNsaWNlKGksIGkgKyAyKSwgMTYpIC8gMjU1KTtcbiAgfVxuICBjb25zdCBvayA9IHYubWF0Y2goL15va2xjaFxcKFxccyooW1xcZC5dKylcXHMrKFtcXGQuXSspXFxzKyhbXFxkLi1dKykvKTtcbiAgaWYgKG9rKSByZXR1cm4gb2tsY2hUb1NyZ2IoTnVtYmVyKG9rWzFdKSwgTnVtYmVyKG9rWzJdKSwgTnVtYmVyKG9rWzNdKSk7XG4gIHJldHVybiBudWxsO1xufVxuXG4vLyDilIDilIAgdGhlIHRva2VuIGJsb2NrcyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuLyoqIFBhcnNlIGAuZ3JvdmUtcm9vdOKApmAgYmxvY2tzIGludG8geyBzZWxlY3RvciwgZGVjbHM6IE1hcDx0b2tlbix2YWx1ZT4gfS4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZVRva2VuQmxvY2tzKGNzcykge1xuICBjb25zdCBvdXQgPSBbXTtcbiAgY29uc3QgcmUgPSAvXFwuZ3JvdmUtcm9vdFtee10qXFx7W159XSpcXH0vZztcbiAgZm9yIChjb25zdCBtIG9mIGNzcy5tYXRjaEFsbChyZSkpIHtcbiAgICBjb25zdCBibG9jayA9IG1bMF07XG4gICAgY29uc3Qgc2VsZWN0b3IgPSBibG9jay5zbGljZSgwLCBibG9jay5pbmRleE9mKCd7JykpLnRyaW0oKTtcbiAgICBjb25zdCBkZWNscyA9IG5ldyBNYXAoKTtcbiAgICBmb3IgKGNvbnN0IGQgb2YgYmxvY2suc2xpY2UoYmxvY2suaW5kZXhPZigneycpICsgMSwgLTEpLnNwbGl0KCc7JykpIHtcbiAgICAgIGNvbnN0IGkgPSBkLmluZGV4T2YoJzonKTtcbiAgICAgIGlmIChpID4gMCkgZGVjbHMuc2V0KGQuc2xpY2UoMCwgaSkudHJpbSgpLCBkLnNsaWNlKGkgKyAxKS50cmltKCkpO1xuICAgIH1cbiAgICAvLyBPbmx5IHRoZSB0b2tlbi1vbmx5IHRoZW1lIGJsb2NrcyBjYXJyeSBjdXN0b20gcHJvcGVydGllcyBhdCB0b3AgbGV2ZWw7IHRoZVxuICAgIC8vIHNoZWxsIGJsb2NrcyAoYnV0dG9ucywgbGlua3MpIGFyZSBza2lwcGVkIGJ5IGhhdmluZyBubyBkZWNsYXJhdGlvbnMgd2UgcmVhZC5cbiAgICBvdXQucHVzaCh7IHNlbGVjdG9yLCBkZWNscyB9KTtcbiAgfVxuICByZXR1cm4gb3V0O1xufVxuXG4vKipcbiAqIE9yZ2FuaXplIGJsb2NrcyBpbnRvIHRoZW1lcyDDlyBwb2xhcml0aWVzLiBUaGUgYmFyZSBgW2RhdGEtZ3JvdmUtdGhlbWU9XCJYXCJdYFxuICogYmxvY2sgaXMgWCdzIFBSRUZFUlJFRCBwb2xhcml0eTsgdGhlIHBhaXJlZCBgW2RhdGEtdGhlbWU9WV1gIGJsb2NrIGlzIHRoZSBvdGhlclxuICogb25lLiBUaGUgYmFzZSBgLmdyb3ZlLXJvb3RgIGJsb2NrIGlzIGRlZmF1bHQvZGFyazsgYFtkYXRhLXRoZW1lPVwibGlnaHRcIl1gIGFsb25lXG4gKiAoc2luZ2xlIGF0dHJpYnV0ZSwgbm8gZ3JvdmUtdGhlbWUpIGlzIGRlZmF1bHQvbGlnaHQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjb2xsZWN0VGhlbWVzKGJsb2Nrcykge1xuICBjb25zdCB0aGVtZXMgPSBuZXcgTWFwKCk7IC8vIGlkIOKGkiB7IGxpZ2h0PzogZGVjbHMsIGRhcms/OiBkZWNscyB9XG4gIGNvbnN0IHB1dCA9IChpZCwgcG9sYXJpdHksIGRlY2xzKSA9PiB7XG4gICAgaWYgKCF0aGVtZXMuaGFzKGlkKSkgdGhlbWVzLnNldChpZCwge30pO1xuICAgIHRoZW1lcy5nZXQoaWQpW3BvbGFyaXR5XSA9IGRlY2xzO1xuICB9O1xuICBmb3IgKGNvbnN0IHsgc2VsZWN0b3IsIGRlY2xzIH0gb2YgYmxvY2tzKSB7XG4gICAgY29uc3QgZ3JvdmUgPSBzZWxlY3Rvci5tYXRjaCgvXFxbZGF0YS1ncm92ZS10aGVtZT1cIihbXlwiXSspXCJcXF0vKTtcbiAgICBjb25zdCB0aGVtZSA9IHNlbGVjdG9yLm1hdGNoKC9cXFtkYXRhLXRoZW1lPVwiKFteXCJdKylcIlxcXS8pO1xuICAgIGlmIChncm92ZSkge1xuICAgICAgLy8gVGhlIHBhaXJlZCBibG9jayBuYW1lcyBpdHMgcG9sYXJpdHk7IHRoZSBiYXJlIGJsb2NrIGlzIHRoZSBPVEhFUiBvbmUuXG4gICAgICBpZiAodGhlbWUpIHB1dChncm92ZVsxXSwgdGhlbWVbMV0sIGRlY2xzKTtcbiAgICAgIGVsc2Uge1xuICAgICAgICAvLyBGaWxsZWQgaW4gYmVsb3csIG9uY2Ugd2Uga25vdyB3aGljaCBwb2xhcml0eSB0aGUgcGFpciBuYW1lcy5cbiAgICAgICAgY29uc3QgYmFyZSA9IHRoZW1lcy5nZXQoZ3JvdmVbMV0pID8/IHt9O1xuICAgICAgICBiYXJlLmJhcmUgPSBkZWNscztcbiAgICAgICAgdGhlbWVzLnNldChncm92ZVsxXSwgYmFyZSk7XG4gICAgICB9XG4gICAgfSBlbHNlIGlmICh0aGVtZSkge1xuICAgICAgcHV0KCdkZWZhdWx0JywgdGhlbWVbMV0sIGRlY2xzKTtcbiAgICB9IGVsc2UgaWYgKHNlbGVjdG9yID09PSAnLmdyb3ZlLXJvb3QnKSB7XG4gICAgICAvLyBFWEFDVExZIHRoZSBiYXNlIGJsb2NrIOKAlCB0aGUgc2hlbGwncyBjb21wb3VuZCBzZWxlY3RvcnMgKGAuZ3JvdmUtcm9vdCBhYCxcbiAgICAgIC8vIGAuZ3JvdmUtcm9vdCBidXR0b25gLCDigKYpIGFsc28gcmVhY2ggaGVyZSBhbmQgbXVzdCBub3Qgb3ZlcndyaXRlIGl0LlxuICAgICAgcHV0KCdkZWZhdWx0JywgJ2RhcmsnLCBkZWNscyk7XG4gICAgfVxuICB9XG4gIGZvciAoY29uc3QgW2lkLCB0XSBvZiB0aGVtZXMpIHtcbiAgICBpZiAodC5iYXJlKSB7XG4gICAgICBjb25zdCBvdGhlciA9IHQubGlnaHQgPyAnZGFyaycgOiAnbGlnaHQnO1xuICAgICAgdFtvdGhlcl0gPSB0LmJhcmU7XG4gICAgICBkZWxldGUgdC5iYXJlO1xuICAgIH1cbiAgfVxuICByZXR1cm4gdGhlbWVzO1xufVxuXG4vKiogUnVuIHRoZSBjb3ZlcmFnZSBmbG9vciBvdmVyIGV2ZXJ5IHRoZW1lIMOXIHBvbGFyaXR5LiBSZXR1cm5zIGZhaWx1cmVzW10uICovXG5leHBvcnQgZnVuY3Rpb24gY2hlY2tUaGVtZXModGhlbWVzLCBwYWlycyA9IFBBSVJTKSB7XG4gIGNvbnN0IGZhaWx1cmVzID0gW107XG4gIGlmICh0aGVtZXMuc2l6ZSA9PT0gMCkgcmV0dXJuIFt7IHRoZW1lOiAnKG5vbmUpJywgd2h5OiAnbm8gdGhlbWUgdG9rZW4gYmxvY2tzIGZvdW5kJyB9XTtcbiAgZm9yIChjb25zdCBbaWQsIHBvbGFyaXRpZXNdIG9mIFsuLi50aGVtZXNdLnNvcnQoKSkge1xuICAgIGZvciAoY29uc3QgcG9sYXJpdHkgb2YgWydsaWdodCcsICdkYXJrJ10pIHtcbiAgICAgIGNvbnN0IGRlY2xzID0gcG9sYXJpdGllc1twb2xhcml0eV07XG4gICAgICBpZiAoIWRlY2xzIHx8IGRlY2xzLnNpemUgPT09IDApIHtcbiAgICAgICAgZmFpbHVyZXMucHVzaCh7IHRoZW1lOiBpZCwgcG9sYXJpdHksIHdoeTogJ21pc3NpbmcgcG9sYXJpdHkg4oCUIGV2ZXJ5IHRoZW1lIHNoaXBzIEJPVEgnIH0pO1xuICAgICAgICBjb250aW51ZTtcbiAgICAgIH1cbiAgICAgIGZvciAoY29uc3QgW2ZnLCBiZywgbWluXSBvZiBwYWlycykge1xuICAgICAgICBjb25zdCBmZ1YgPSBkZWNscy5nZXQoZmcpO1xuICAgICAgICBjb25zdCBiZ1YgPSBkZWNscy5nZXQoYmcpO1xuICAgICAgICBpZiAoIWZnViB8fCAhYmdWKSB7XG4gICAgICAgICAgZmFpbHVyZXMucHVzaCh7IHRoZW1lOiBpZCwgcG9sYXJpdHksIHdoeTogYCR7IWZnViA/IGZnIDogYmd9IG5vdCBkZWNsYXJlZGAgfSk7XG4gICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgZmdDID0gcGFyc2VDb2xvcihmZ1YpO1xuICAgICAgICBjb25zdCBiZ0MgPSBwYXJzZUNvbG9yKGJnVik7XG4gICAgICAgIGlmICghZmdDIHx8ICFiZ0MpIHtcbiAgICAgICAgICBmYWlsdXJlcy5wdXNoKHsgdGhlbWU6IGlkLCBwb2xhcml0eSwgd2h5OiBgJHshZmdDID8gZmcgOiBiZ309JHshZmdDID8gZmdWIDogYmdWfSBpcyBub3QgYSBjb250cmFzdC1jaGVja2FibGUgY29sb3VyYCB9KTtcbiAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCByYXRpbyA9IGNvbnRyYXN0KGZnQywgYmdDKTtcbiAgICAgICAgaWYgKHJhdGlvIDwgbWluKSB7XG4gICAgICAgICAgZmFpbHVyZXMucHVzaCh7XG4gICAgICAgICAgICB0aGVtZTogaWQsXG4gICAgICAgICAgICBwb2xhcml0eSxcbiAgICAgICAgICAgIHdoeTogYCR7Zmd9IG9uICR7Ymd9ID0gJHtyYXRpby50b0ZpeGVkKDIpfToxIDwgJHttaW59OjEgKCR7ZmdWfSBvbiAke2JnVn0pYCxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfVxuICByZXR1cm4gZmFpbHVyZXM7XG59XG5cbi8vIOKUgOKUgCBlbnRyeSBwb2ludHMg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbmZ1bmN0aW9uIHJ1bk9uKGNzcykge1xuICByZXR1cm4gY2hlY2tUaGVtZXMoY29sbGVjdFRoZW1lcyhwYXJzZVRva2VuQmxvY2tzKGNzcykpKTtcbn1cblxuY29uc3QgY3NzID0gcmVhZEZpbGVTeW5jKENTU19QQVRILCAndXRmOCcpO1xuXG5pZiAocHJvY2Vzcy5hcmd2LmluY2x1ZGVzKCctLXNlbGYtdGVzdCcpKSB7XG4gIGxldCBmYWlsZWQgPSAwO1xuICBjb25zdCBleHBlY3QgPSAobmFtZSwgY29uZCkgPT4ge1xuICAgIGlmIChjb25kKSBjb25zb2xlLmxvZyhgICDinJMgJHtuYW1lfWApO1xuICAgIGVsc2Uge1xuICAgICAgZmFpbGVkKys7XG4gICAgICBjb25zb2xlLmVycm9yKGAgIOKclyAke25hbWV9YCk7XG4gICAgfVxuICB9O1xuICBjb25zdCBHT09EID0gYFxuICAgIC5ncm92ZS1yb290IHsgLS1iZzogIzBhMGIxMTsgLS1wYW5lbDogIzEzMTQxZDsgLS1wYW5lbC0yOiAjMTkxYjI2OyAtLWluazogI2VjZWJmNDsgLS1pbmstMjogIzliOTdiMzsgLS1hY2NlbnQ6ICNmNDlhZDQ7IH1cbiAgICAuZ3JvdmUtcm9vdFtkYXRhLXRoZW1lPVwibGlnaHRcIl0geyAtLWJnOiAjZjZmNGZiOyAtLXBhbmVsOiAjZmZmZmZmOyAtLXBhbmVsLTI6ICNmMGVjZjg7IC0taW5rOiAjMWMxNzI2OyAtLWluay0yOiAjNWQ1NjcwOyAtLWFjY2VudDogI2IwMmE2ZjsgfVxuICAgIC5ncm92ZS1yb290W2RhdGEtZ3JvdmUtdGhlbWU9XCJ4XCJdIHsgLS1iZzogIzEwMTAxMDsgLS1wYW5lbDogIzFhMWExYTsgLS1wYW5lbC0yOiAjMjIyMjIyOyAtLWluazogI2YwZjBmMDsgLS1pbmstMjogI2IwYjBiMDsgLS1hY2NlbnQ6ICNlMDYwNjA7IH1cbiAgICAuZ3JvdmUtcm9vdFtkYXRhLWdyb3ZlLXRoZW1lPVwieFwiXVtkYXRhLXRoZW1lPVwibGlnaHRcIl0geyAtLWJnOiAjZmFmYWZhOyAtLXBhbmVsOiAjZmZmZmZmOyAtLXBhbmVsLTI6ICNmMGYwZjA7IC0taW5rOiAjMjAyMDIwOyAtLWluay0yOiAjNTU1NTU1OyAtLWFjY2VudDogI2EwMzAzMDsgfVxuICBgO1xuICAvLyAxLiB0aGUgZ29vZCBmaXh0dXJlIHBhc3Nlcy5cbiAgZXhwZWN0KCdhIGJvdGgtcG9sYXJpdHksIEFBIGZpeHR1cmUgcGFzc2VzJywgcnVuT24oR09PRCkubGVuZ3RoID09PSAwKTtcbiAgLy8gMi4gYSBwbGFudGVkIHN1Yi1BQSBwYWlyIGZhaWxzIOKAlCBpbiBhbiBBTFRFUk5BVEUgdGhlbWUsIGluIHRoZSBMSUdIVCBwb2xhcml0eTpcbiAgLy8gdGhlIGV4YWN0IHJlZ3Jlc3Npb24gdGhpcyBnYXRlIGV4aXN0cyB0byBjYXRjaC5cbiAgY29uc3QgUExBTlRFRCA9IEdPT0QucmVwbGFjZShcbiAgICAnLmdyb3ZlLXJvb3RbZGF0YS1ncm92ZS10aGVtZT1cInhcIl1bZGF0YS10aGVtZT1cImxpZ2h0XCJdIHsgLS1iZzogI2ZhZmFmYTsnLFxuICAgICcuZ3JvdmUtcm9vdFtkYXRhLWdyb3ZlLXRoZW1lPVwieFwiXVtkYXRhLXRoZW1lPVwibGlnaHRcIl0geyAtLWJnOiAjMGEwYTBhOycsXG4gICk7XG4gIGNvbnN0IHBsYW50ZWQgPSBydW5PbihQTEFOVEVEKTtcbiAgZXhwZWN0KCdhIHBsYW50ZWQgc3ViLUFBIHBhaXIgZmFpbHMnLCBwbGFudGVkLmxlbmd0aCA+IDAgJiYgLy0taW5rIG9uIC0tYmcvLnRlc3QocGxhbnRlZFswXS53aHkpKTtcbiAgLy8gMy4gc2luZ2xlLXBvbGFyaXR5IGJ5IGNvbnN0cnVjdGlvbiBmYWlscyDigJQgdGhlIGJhcmUgYmxvY2sgd2l0aCBubyBwYWlyLlxuICBjb25zdCBTSU5HTEUgPSBHT09ELnJlcGxhY2UoXG4gICAgL1xcblxccypcXC5ncm92ZS1yb290XFxbZGF0YS1ncm92ZS10aGVtZT1cInhcIlxcXVxcW2RhdGEtdGhlbWU9XCJsaWdodFwiXFxdW15cXG5dKi8sXG4gICAgJycsXG4gICk7XG4gIGNvbnN0IHNpbmdsZSA9IHJ1bk9uKFNJTkdMRSk7XG4gIGV4cGVjdCgnYSB0aGVtZSBtaXNzaW5nIG9uZSBwb2xhcml0eSBmYWlscycsIHNpbmdsZS5zb21lKChmKSA9PiAvbWlzc2luZyBwb2xhcml0eS8udGVzdChmLndoeSkpKTtcbiAgLy8gNC4gYW4gdW5wYXJzZWFibGUgY29sb3VyIGZhaWxzIExPVURMWSByYXRoZXIgdGhhbiBiZWluZyBza2lwcGVkLlxuICBjb25zdCBXRUlSRCA9IEdPT0QucmVwbGFjZSgnLS1hY2NlbnQ6ICNlMDYwNjA7JywgJy0tYWNjZW50OiB2YXIoLS1ub3BlKTsnKTtcbiAgZXhwZWN0KCdhbiB1bmNoZWNrYWJsZSBhY2NlbnQgY29sb3VyIGZhaWxzJywgcnVuT24oV0VJUkQpLmxlbmd0aCA+IDApO1xuICAvLyA1LiB0aGUgcmVhbCBzdHlsZXNoZWV0J3Mgc2hhcGUgcGFyc2VzIGludG8gdGhlbWVzICh0aGUgbG9hZGVyIGhhbGYpLlxuICBjb25zdCB0aGVtZXMgPSBjb2xsZWN0VGhlbWVzKHBhcnNlVG9rZW5CbG9ja3MoY3NzKSk7XG4gIGV4cGVjdChcbiAgICAndGhlIHNoaXBwZWQgQ1NTIHlpZWxkcyBkZWZhdWx0ICsgMyBhbHRlcm5hdGVzLCBib3RoIHBvbGFyaXRpZXMnLFxuICAgIHRoZW1lcy5zaXplID09PSA0ICYmIFsuLi50aGVtZXMudmFsdWVzKCldLmV2ZXJ5KCh0KSA9PiB0LmxpZ2h0ICYmIHQuZGFyayksXG4gICk7XG4gIGNvbnNvbGUubG9nKGZhaWxlZCA9PT0gMCA/ICd0aGVtZS1jb250cmFzdCBzZWxmLXRlc3Q6IDUvNScgOiBgdGhlbWUtY29udHJhc3Qgc2VsZi10ZXN0OiBGQUlMRUQgJHtmYWlsZWR9YCk7XG4gIHByb2Nlc3MuZXhpdChmYWlsZWQgPT09IDAgPyAwIDogMSk7XG59XG5cbmNvbnN0IGZhaWx1cmVzID0gcnVuT24oY3NzKTtcbmlmIChmYWlsdXJlcy5sZW5ndGggPiAwKSB7XG4gIGNvbnNvbGUuZXJyb3IoYOKclyB0aGVtZSBjb250cmFzdDogJHtmYWlsdXJlcy5sZW5ndGh9IHBhaXIocykgYmVsb3cgdGhlIGZsb29yYCk7XG4gIGZvciAoY29uc3QgZiBvZiBmYWlsdXJlcykgY29uc29sZS5lcnJvcihgICDCtyAke2YudGhlbWV9LyR7Zi5wb2xhcml0eX06ICR7Zi53aHl9YCk7XG4gIHByb2Nlc3MuZXhpdCgxKTtcbn1cbmNvbnNvbGUubG9nKGDinJMgdGhlbWUgY29udHJhc3Q6IGV2ZXJ5IHRoZW1lLCBib3RoIHBvbGFyaXRpZXMsIGF0IHRoZSBmbG9vciAoJHtbLi4uY29sbGVjdFRoZW1lcyhwYXJzZVRva2VuQmxvY2tzKGNzcykpLmtleXMoKV0uam9pbignLCAnKX0pYCk7XG4iXSwibWFwcGluZ3MiOiJBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFBQTs7QUFBQUEsTUFBQSxDQUFBQyxjQUFBLENBQUFDLE9BQUE7RUFBQUMsS0FBQTtBQUFBO0FBQUFELE9BQUEsQ0FBQUUsS0FBQTtBQUFBRixPQUFBLENBQUFHLFdBQUEsR0FBQUEsV0FBQTtBQUFBSCxPQUFBLENBQUFJLGFBQUEsR0FBQUEsYUFBQTtBQUFBSixPQUFBLENBQUFLLFFBQUE7QUFBQUwsT0FBQSxDQUFBTSxVQUFBLEdBQUFBLFVBQUE7QUFBQU4sT0FBQSxDQUFBTyxnQkFBQSxHQUFBQSxnQkFBQTtBQUFBQyxPQUFBO0FBQUFBLE9BQUE7QUFFQSxJQUFBQyxPQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxRQUFBLEdBQUFGLE9BQUE7QUFDQSxJQUFBRyxTQUFBLEdBQUFILE9BQUE7QUFFQSxNQUFNSSxJQUFJLEdBQUcsSUFBQUMsY0FBSSxFQUFDLElBQUFDLGlCQUFPLEVBQUMsSUFBQUMsc0JBQWEsRUFBQ0MsZUFBQSxDQUFZQyxHQUFHLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQztBQUNoRSxNQUFNQyxRQUFRLEdBQUcsSUFBQUwsY0FBSSxFQUFDRCxJQUFJLEVBQUUsS0FBSyxFQUFFLGNBQWMsQ0FBQzs7QUFFbEQ7QUFDTyxNQUFNVixLQUFLLEdBQUFGLE9BQUEsQ0FBQUUsS0FBQSxHQUFHLENBQ25CLENBQUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxHQUFHLENBQUMsRUFDdEIsQ0FBQyxPQUFPLEVBQUUsU0FBUyxFQUFFLEdBQUcsQ0FBQyxFQUN6QixDQUFDLE9BQU8sRUFBRSxXQUFXLEVBQUUsR0FBRyxDQUFDLEVBQzNCLENBQUMsU0FBUyxFQUFFLE1BQU0sRUFBRSxHQUFHLENBQUMsRUFDeEIsQ0FBQyxTQUFTLEVBQUUsU0FBUyxFQUFFLEdBQUcsQ0FBQyxFQUMzQixDQUFDLFNBQVMsRUFBRSxXQUFXLEVBQUUsR0FBRyxDQUFDLEVBQzdCLENBQUMsVUFBVSxFQUFFLE1BQU0sRUFBRSxHQUFHLENBQUMsRUFDekIsQ0FBQyxVQUFVLEVBQUUsU0FBUyxFQUFFLEdBQUcsQ0FBQyxDQUM3Qjs7QUFFRDs7QUFFQTtBQUNBLE1BQU1pQixZQUFZLEdBQUlDLENBQUMsSUFBTUEsQ0FBQyxJQUFJLE9BQU8sR0FBR0EsQ0FBQyxHQUFHLEtBQUssR0FBR0MsSUFBSSxDQUFDQyxHQUFHLENBQUMsQ0FBQ0YsQ0FBQyxHQUFHLEtBQUssSUFBSSxLQUFLLEVBQUUsR0FBRyxDQUFFOztBQUUzRjtBQUNBLFNBQVNHLFNBQVNBLENBQUMsQ0FBQ0MsQ0FBQyxFQUFFQyxDQUFDLEVBQUVDLENBQUMsQ0FBQyxFQUFFO0VBQzVCLE1BQU0sQ0FBQ0MsQ0FBQyxFQUFFQyxDQUFDLEVBQUVDLENBQUMsQ0FBQyxHQUFHLENBQUNMLENBQUMsRUFBRUMsQ0FBQyxFQUFFQyxDQUFDLENBQUMsQ0FBQ0ksR0FBRyxDQUFDWCxZQUFZLENBQUM7RUFDN0MsT0FBTyxNQUFNLEdBQUdRLENBQUMsR0FBRyxNQUFNLEdBQUdDLENBQUMsR0FBRyxNQUFNLEdBQUdDLENBQUM7QUFDN0M7O0FBRUE7QUFDTyxNQUFNeEIsUUFBUSxHQUFHQSxDQUFDMEIsQ0FBQyxFQUFFTCxDQUFDLEtBQUs7RUFDaEMsTUFBTSxDQUFDTSxFQUFFLEVBQUVDLEVBQUUsQ0FBQyxHQUFHLENBQUNWLFNBQVMsQ0FBQ1EsQ0FBQyxDQUFDLEVBQUVSLFNBQVMsQ0FBQ0csQ0FBQyxDQUFDLENBQUMsQ0FBQ1EsSUFBSSxDQUFDLENBQUNDLENBQUMsRUFBRUMsQ0FBQyxLQUFLQSxDQUFDLEdBQUdELENBQUMsQ0FBQztFQUNuRSxPQUFPLENBQUNILEVBQUUsR0FBRyxJQUFJLEtBQUtDLEVBQUUsR0FBRyxJQUFJLENBQUM7QUFDbEMsQ0FBQzs7QUFFRDtBQUFBakMsT0FBQSxDQUFBSyxRQUFBLEdBQUFBLFFBQUE7QUFDQSxTQUFTZ0MsV0FBV0EsQ0FBQ0MsQ0FBQyxFQUFFQyxDQUFDLEVBQUVDLElBQUksRUFBRTtFQUMvQixNQUFNQyxDQUFDLEdBQUlELElBQUksR0FBR25CLElBQUksQ0FBQ3FCLEVBQUUsR0FBSSxHQUFHO0VBQ2hDLE1BQU1YLENBQUMsR0FBR1EsQ0FBQyxHQUFHbEIsSUFBSSxDQUFDc0IsR0FBRyxDQUFDRixDQUFDLENBQUM7RUFDekIsTUFBTWYsQ0FBQyxHQUFHYSxDQUFDLEdBQUdsQixJQUFJLENBQUN1QixHQUFHLENBQUNILENBQUMsQ0FBQztFQUN6QixNQUFNSSxFQUFFLEdBQUdQLENBQUMsR0FBRyxZQUFZLEdBQUdQLENBQUMsR0FBRyxZQUFZLEdBQUdMLENBQUM7RUFDbEQsTUFBTW9CLEVBQUUsR0FBR1IsQ0FBQyxHQUFHLFlBQVksR0FBR1AsQ0FBQyxHQUFHLFlBQVksR0FBR0wsQ0FBQztFQUNsRCxNQUFNcUIsRUFBRSxHQUFHVCxDQUFDLEdBQUcsWUFBWSxHQUFHUCxDQUFDLEdBQUcsV0FBVyxHQUFHTCxDQUFDO0VBQ2pELE1BQU1zQixDQUFDLEdBQUdILEVBQUUsSUFBSSxDQUFDO0VBQ2pCLE1BQU1JLENBQUMsR0FBR0gsRUFBRSxJQUFJLENBQUM7RUFDakIsTUFBTUksQ0FBQyxHQUFHSCxFQUFFLElBQUksQ0FBQztFQUNqQixNQUFNdkIsQ0FBQyxHQUFHLENBQUMsWUFBWSxHQUFHd0IsQ0FBQyxHQUFHLFlBQVksR0FBR0MsQ0FBQyxHQUFHLFlBQVksR0FBR0MsQ0FBQztFQUNqRSxNQUFNekIsQ0FBQyxHQUFHLENBQUMsWUFBWSxHQUFHdUIsQ0FBQyxHQUFHLFlBQVksR0FBR0MsQ0FBQyxHQUFHLFlBQVksR0FBR0MsQ0FBQztFQUNqRSxNQUFNQyxFQUFFLEdBQUcsQ0FBQyxZQUFZLEdBQUdILENBQUMsR0FBRyxZQUFZLEdBQUdDLENBQUMsR0FBRyxXQUFXLEdBQUdDLENBQUM7RUFDakU7RUFDQTtFQUNBLE9BQU8sQ0FBQzFCLENBQUMsRUFBRUMsQ0FBQyxFQUFFMEIsRUFBRSxDQUFDLENBQUNyQixHQUFHLENBQUVzQixDQUFDLElBQUsvQixJQUFJLENBQUNnQyxHQUFHLENBQUMsQ0FBQyxFQUFFaEMsSUFBSSxDQUFDaUMsR0FBRyxDQUFDLENBQUMsRUFBRUYsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMzRDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVM5QyxVQUFVQSxDQUFDTCxLQUFLLEVBQUU7RUFDaEMsTUFBTW1ELENBQUMsR0FBR25ELEtBQUssQ0FBQ3NELElBQUksQ0FBQyxDQUFDLENBQUNDLFdBQVcsQ0FBQyxDQUFDO0VBQ3BDLE1BQU1DLEdBQUcsR0FBR0wsQ0FBQyxDQUFDTSxLQUFLLENBQUMsOEJBQThCLENBQUM7RUFDbkQsSUFBSUQsR0FBRyxFQUFFO0lBQ1AsTUFBTWhCLENBQUMsR0FBR2dCLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQ0UsTUFBTSxLQUFLLENBQUMsR0FBRyxDQUFDLEdBQUdGLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDM0IsR0FBRyxDQUFFVixDQUFDLElBQUtBLENBQUMsR0FBR0EsQ0FBQyxDQUFDLENBQUNQLElBQUksQ0FBQyxFQUFFLENBQUMsR0FBRzRDLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFDL0UsT0FBTyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMzQixHQUFHLENBQUU4QixDQUFDLElBQUtDLFFBQVEsQ0FBQ3BCLENBQUMsQ0FBQ3FCLEtBQUssQ0FBQ0YsQ0FBQyxFQUFFQSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLEdBQUcsR0FBRyxDQUFDO0VBQ3BFO0VBQ0EsTUFBTUcsRUFBRSxHQUFHWCxDQUFDLENBQUNNLEtBQUssQ0FBQyw0Q0FBNEMsQ0FBQztFQUNoRSxJQUFJSyxFQUFFLEVBQUUsT0FBTzFCLFdBQVcsQ0FBQzJCLE1BQU0sQ0FBQ0QsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUVDLE1BQU0sQ0FBQ0QsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUVDLE1BQU0sQ0FBQ0QsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDdkUsT0FBTyxJQUFJO0FBQ2I7O0FBRUE7O0FBRUE7QUFDTyxTQUFTeEQsZ0JBQWdCQSxDQUFDMEQsR0FBRyxFQUFFO0VBQ3BDLE1BQU1DLEdBQUcsR0FBRyxFQUFFO0VBQ2QsTUFBTUMsRUFBRSxHQUFHLDZCQUE2QjtFQUN4QyxLQUFLLE1BQU1sQixDQUFDLElBQUlnQixHQUFHLENBQUNHLFFBQVEsQ0FBQ0QsRUFBRSxDQUFDLEVBQUU7SUFDaEMsTUFBTUUsS0FBSyxHQUFHcEIsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUNsQixNQUFNcUIsUUFBUSxHQUFHRCxLQUFLLENBQUNQLEtBQUssQ0FBQyxDQUFDLEVBQUVPLEtBQUssQ0FBQ0UsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUNoQixJQUFJLENBQUMsQ0FBQztJQUMxRCxNQUFNaUIsS0FBSyxHQUFHLElBQUlDLEdBQUcsQ0FBQyxDQUFDO0lBQ3ZCLEtBQUssTUFBTUMsQ0FBQyxJQUFJTCxLQUFLLENBQUNQLEtBQUssQ0FBQ08sS0FBSyxDQUFDRSxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUNJLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRTtNQUNsRSxNQUFNZixDQUFDLEdBQUdjLENBQUMsQ0FBQ0gsT0FBTyxDQUFDLEdBQUcsQ0FBQztNQUN4QixJQUFJWCxDQUFDLEdBQUcsQ0FBQyxFQUFFWSxLQUFLLENBQUNJLEdBQUcsQ0FBQ0YsQ0FBQyxDQUFDWixLQUFLLENBQUMsQ0FBQyxFQUFFRixDQUFDLENBQUMsQ0FBQ0wsSUFBSSxDQUFDLENBQUMsRUFBRW1CLENBQUMsQ0FBQ1osS0FBSyxDQUFDRixDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUNMLElBQUksQ0FBQyxDQUFDLENBQUM7SUFDbkU7SUFDQTtJQUNBO0lBQ0FXLEdBQUcsQ0FBQ1csSUFBSSxDQUFDO01BQUVQLFFBQVE7TUFBRUU7SUFBTSxDQUFDLENBQUM7RUFDL0I7RUFDQSxPQUFPTixHQUFHO0FBQ1o7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBUzlELGFBQWFBLENBQUMwRSxNQUFNLEVBQUU7RUFDcEMsTUFBTUMsTUFBTSxHQUFHLElBQUlOLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUMxQixNQUFNTyxHQUFHLEdBQUdBLENBQUNDLEVBQUUsRUFBRUMsUUFBUSxFQUFFVixLQUFLLEtBQUs7SUFDbkMsSUFBSSxDQUFDTyxNQUFNLENBQUNJLEdBQUcsQ0FBQ0YsRUFBRSxDQUFDLEVBQUVGLE1BQU0sQ0FBQ0gsR0FBRyxDQUFDSyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUM7SUFDdkNGLE1BQU0sQ0FBQ0ssR0FBRyxDQUFDSCxFQUFFLENBQUMsQ0FBQ0MsUUFBUSxDQUFDLEdBQUdWLEtBQUs7RUFDbEMsQ0FBQztFQUNELEtBQUssTUFBTTtJQUFFRixRQUFRO0lBQUVFO0VBQU0sQ0FBQyxJQUFJTSxNQUFNLEVBQUU7SUFDeEMsTUFBTU8sS0FBSyxHQUFHZixRQUFRLENBQUNaLEtBQUssQ0FBQyxnQ0FBZ0MsQ0FBQztJQUM5RCxNQUFNNEIsS0FBSyxHQUFHaEIsUUFBUSxDQUFDWixLQUFLLENBQUMsMEJBQTBCLENBQUM7SUFDeEQsSUFBSTJCLEtBQUssRUFBRTtNQUNUO01BQ0EsSUFBSUMsS0FBSyxFQUFFTixHQUFHLENBQUNLLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFZCxLQUFLLENBQUMsQ0FBQyxLQUNyQztRQUNIO1FBQ0EsTUFBTWUsSUFBSSxHQUFHUixNQUFNLENBQUNLLEdBQUcsQ0FBQ0MsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3ZDRSxJQUFJLENBQUNBLElBQUksR0FBR2YsS0FBSztRQUNqQk8sTUFBTSxDQUFDSCxHQUFHLENBQUNTLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRUUsSUFBSSxDQUFDO01BQzVCO0lBQ0YsQ0FBQyxNQUFNLElBQUlELEtBQUssRUFBRTtNQUNoQk4sR0FBRyxDQUFDLFNBQVMsRUFBRU0sS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFZCxLQUFLLENBQUM7SUFDakMsQ0FBQyxNQUFNLElBQUlGLFFBQVEsS0FBSyxhQUFhLEVBQUU7TUFDckM7TUFDQTtNQUNBVSxHQUFHLENBQUMsU0FBUyxFQUFFLE1BQU0sRUFBRVIsS0FBSyxDQUFDO0lBQy9CO0VBQ0Y7RUFDQSxLQUFLLE1BQU0sQ0FBQ1MsRUFBRSxFQUFFTyxDQUFDLENBQUMsSUFBSVQsTUFBTSxFQUFFO0lBQzVCLElBQUlTLENBQUMsQ0FBQ0QsSUFBSSxFQUFFO01BQ1YsTUFBTUUsS0FBSyxHQUFHRCxDQUFDLENBQUNFLEtBQUssR0FBRyxNQUFNLEdBQUcsT0FBTztNQUN4Q0YsQ0FBQyxDQUFDQyxLQUFLLENBQUMsR0FBR0QsQ0FBQyxDQUFDRCxJQUFJO01BQ2pCLE9BQU9DLENBQUMsQ0FBQ0QsSUFBSTtJQUNmO0VBQ0Y7RUFDQSxPQUFPUixNQUFNO0FBQ2Y7O0FBRUE7QUFDTyxTQUFTNUUsV0FBV0EsQ0FBQzRFLE1BQU0sRUFBRVksS0FBSyxHQUFHekYsS0FBSyxFQUFFO0VBQ2pELE1BQU0wRixRQUFRLEdBQUcsRUFBRTtFQUNuQixJQUFJYixNQUFNLENBQUNjLElBQUksS0FBSyxDQUFDLEVBQUUsT0FBTyxDQUFDO0lBQUVQLEtBQUssRUFBRSxRQUFRO0lBQUVRLEdBQUcsRUFBRTtFQUE4QixDQUFDLENBQUM7RUFDdkYsS0FBSyxNQUFNLENBQUNiLEVBQUUsRUFBRWMsVUFBVSxDQUFDLElBQUksQ0FBQyxHQUFHaEIsTUFBTSxDQUFDLENBQUM3QyxJQUFJLENBQUMsQ0FBQyxFQUFFO0lBQ2pELEtBQUssTUFBTWdELFFBQVEsSUFBSSxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsRUFBRTtNQUN4QyxNQUFNVixLQUFLLEdBQUd1QixVQUFVLENBQUNiLFFBQVEsQ0FBQztNQUNsQyxJQUFJLENBQUNWLEtBQUssSUFBSUEsS0FBSyxDQUFDcUIsSUFBSSxLQUFLLENBQUMsRUFBRTtRQUM5QkQsUUFBUSxDQUFDZixJQUFJLENBQUM7VUFBRVMsS0FBSyxFQUFFTCxFQUFFO1VBQUVDLFFBQVE7VUFBRVksR0FBRyxFQUFFO1FBQTRDLENBQUMsQ0FBQztRQUN4RjtNQUNGO01BQ0EsS0FBSyxNQUFNLENBQUNFLEVBQUUsRUFBRUMsRUFBRSxFQUFFNUMsR0FBRyxDQUFDLElBQUlzQyxLQUFLLEVBQUU7UUFDakMsTUFBTU8sR0FBRyxHQUFHMUIsS0FBSyxDQUFDWSxHQUFHLENBQUNZLEVBQUUsQ0FBQztRQUN6QixNQUFNRyxHQUFHLEdBQUczQixLQUFLLENBQUNZLEdBQUcsQ0FBQ2EsRUFBRSxDQUFDO1FBQ3pCLElBQUksQ0FBQ0MsR0FBRyxJQUFJLENBQUNDLEdBQUcsRUFBRTtVQUNoQlAsUUFBUSxDQUFDZixJQUFJLENBQUM7WUFBRVMsS0FBSyxFQUFFTCxFQUFFO1lBQUVDLFFBQVE7WUFBRVksR0FBRyxFQUFFLEdBQUcsQ0FBQ0ksR0FBRyxHQUFHRixFQUFFLEdBQUdDLEVBQUU7VUFBZ0IsQ0FBQyxDQUFDO1VBQzdFO1FBQ0Y7UUFDQSxNQUFNRyxHQUFHLEdBQUc5RixVQUFVLENBQUM0RixHQUFHLENBQUM7UUFDM0IsTUFBTUcsR0FBRyxHQUFHL0YsVUFBVSxDQUFDNkYsR0FBRyxDQUFDO1FBQzNCLElBQUksQ0FBQ0MsR0FBRyxJQUFJLENBQUNDLEdBQUcsRUFBRTtVQUNoQlQsUUFBUSxDQUFDZixJQUFJLENBQUM7WUFBRVMsS0FBSyxFQUFFTCxFQUFFO1lBQUVDLFFBQVE7WUFBRVksR0FBRyxFQUFFLEdBQUcsQ0FBQ00sR0FBRyxHQUFHSixFQUFFLEdBQUdDLEVBQUUsSUFBSSxDQUFDRyxHQUFHLEdBQUdGLEdBQUcsR0FBR0MsR0FBRztVQUFzQyxDQUFDLENBQUM7VUFDdkg7UUFDRjtRQUNBLE1BQU1HLEtBQUssR0FBR2pHLFFBQVEsQ0FBQytGLEdBQUcsRUFBRUMsR0FBRyxDQUFDO1FBQ2hDLElBQUlDLEtBQUssR0FBR2pELEdBQUcsRUFBRTtVQUNmdUMsUUFBUSxDQUFDZixJQUFJLENBQUM7WUFDWlMsS0FBSyxFQUFFTCxFQUFFO1lBQ1RDLFFBQVE7WUFDUlksR0FBRyxFQUFFLEdBQUdFLEVBQUUsT0FBT0MsRUFBRSxNQUFNSyxLQUFLLENBQUNDLE9BQU8sQ0FBQyxDQUFDLENBQUMsUUFBUWxELEdBQUcsT0FBTzZDLEdBQUcsT0FBT0MsR0FBRztVQUMxRSxDQUFDLENBQUM7UUFDSjtNQUNGO0lBQ0Y7RUFDRjtFQUNBLE9BQU9QLFFBQVE7QUFDakI7O0FBRUE7O0FBRUEsU0FBU1ksS0FBS0EsQ0FBQ3ZDLEdBQUcsRUFBRTtFQUNsQixPQUFPOUQsV0FBVyxDQUFDQyxhQUFhLENBQUNHLGdCQUFnQixDQUFDMEQsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUMxRDtBQUVBLE1BQU1BLEdBQUcsR0FBRyxJQUFBd0Msb0JBQVksRUFBQ3ZGLFFBQVEsRUFBRSxNQUFNLENBQUM7QUFFMUMsSUFBSXdGLE9BQU8sQ0FBQ0MsSUFBSSxDQUFDQyxRQUFRLENBQUMsYUFBYSxDQUFDLEVBQUU7RUFDeEMsSUFBSUMsTUFBTSxHQUFHLENBQUM7RUFDZCxNQUFNQyxNQUFNLEdBQUdBLENBQUNDLElBQUksRUFBRUMsSUFBSSxLQUFLO0lBQzdCLElBQUlBLElBQUksRUFBRUMsT0FBTyxDQUFDQyxHQUFHLENBQUMsT0FBT0gsSUFBSSxFQUFFLENBQUMsQ0FBQyxLQUNoQztNQUNIRixNQUFNLEVBQUU7TUFDUkksT0FBTyxDQUFDRSxLQUFLLENBQUMsT0FBT0osSUFBSSxFQUFFLENBQUM7SUFDOUI7RUFDRixDQUFDO0VBQ0QsTUFBTUssSUFBSSxHQUFHO0FBQ2Y7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0VBQ0Q7RUFDQU4sTUFBTSxDQUFDLG9DQUFvQyxFQUFFTixLQUFLLENBQUNZLElBQUksQ0FBQyxDQUFDekQsTUFBTSxLQUFLLENBQUMsQ0FBQztFQUN0RTtFQUNBO0VBQ0EsTUFBTTBELE9BQU8sR0FBR0QsSUFBSSxDQUFDRSxPQUFPLENBQzFCLHdFQUF3RSxFQUN4RSx3RUFDRixDQUFDO0VBQ0QsTUFBTUMsT0FBTyxHQUFHZixLQUFLLENBQUNhLE9BQU8sQ0FBQztFQUM5QlAsTUFBTSxDQUFDLDZCQUE2QixFQUFFUyxPQUFPLENBQUM1RCxNQUFNLEdBQUcsQ0FBQyxJQUFJLGVBQWUsQ0FBQzZELElBQUksQ0FBQ0QsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDekIsR0FBRyxDQUFDLENBQUM7RUFDakc7RUFDQSxNQUFNMkIsTUFBTSxHQUFHTCxJQUFJLENBQUNFLE9BQU8sQ0FDekIsdUVBQXVFLEVBQ3ZFLEVBQ0YsQ0FBQztFQUNELE1BQU1JLE1BQU0sR0FBR2xCLEtBQUssQ0FBQ2lCLE1BQU0sQ0FBQztFQUM1QlgsTUFBTSxDQUFDLG9DQUFvQyxFQUFFWSxNQUFNLENBQUNDLElBQUksQ0FBRUMsQ0FBQyxJQUFLLGtCQUFrQixDQUFDSixJQUFJLENBQUNJLENBQUMsQ0FBQzlCLEdBQUcsQ0FBQyxDQUFDLENBQUM7RUFDaEc7RUFDQSxNQUFNK0IsS0FBSyxHQUFHVCxJQUFJLENBQUNFLE9BQU8sQ0FBQyxvQkFBb0IsRUFBRSx3QkFBd0IsQ0FBQztFQUMxRVIsTUFBTSxDQUFDLG9DQUFvQyxFQUFFTixLQUFLLENBQUNxQixLQUFLLENBQUMsQ0FBQ2xFLE1BQU0sR0FBRyxDQUFDLENBQUM7RUFDckU7RUFDQSxNQUFNb0IsTUFBTSxHQUFHM0UsYUFBYSxDQUFDRyxnQkFBZ0IsQ0FBQzBELEdBQUcsQ0FBQyxDQUFDO0VBQ25ENkMsTUFBTSxDQUNKLGdFQUFnRSxFQUNoRS9CLE1BQU0sQ0FBQ2MsSUFBSSxLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUdkLE1BQU0sQ0FBQytDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQ0MsS0FBSyxDQUFFdkMsQ0FBQyxJQUFLQSxDQUFDLENBQUNFLEtBQUssSUFBSUYsQ0FBQyxDQUFDd0MsSUFBSSxDQUMxRSxDQUFDO0VBQ0RmLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDTCxNQUFNLEtBQUssQ0FBQyxHQUFHLCtCQUErQixHQUFHLG9DQUFvQ0EsTUFBTSxFQUFFLENBQUM7RUFDMUdILE9BQU8sQ0FBQ3VCLElBQUksQ0FBQ3BCLE1BQU0sS0FBSyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNwQztBQUVBLE1BQU1qQixRQUFRLEdBQUdZLEtBQUssQ0FBQ3ZDLEdBQUcsQ0FBQztBQUMzQixJQUFJMkIsUUFBUSxDQUFDakMsTUFBTSxHQUFHLENBQUMsRUFBRTtFQUN2QnNELE9BQU8sQ0FBQ0UsS0FBSyxDQUFDLHFCQUFxQnZCLFFBQVEsQ0FBQ2pDLE1BQU0sMEJBQTBCLENBQUM7RUFDN0UsS0FBSyxNQUFNaUUsQ0FBQyxJQUFJaEMsUUFBUSxFQUFFcUIsT0FBTyxDQUFDRSxLQUFLLENBQUMsT0FBT1MsQ0FBQyxDQUFDdEMsS0FBSyxJQUFJc0MsQ0FBQyxDQUFDMUMsUUFBUSxLQUFLMEMsQ0FBQyxDQUFDOUIsR0FBRyxFQUFFLENBQUM7RUFDakZZLE9BQU8sQ0FBQ3VCLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDakI7QUFDQWhCLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDLGlFQUFpRSxDQUFDLEdBQUc5RyxhQUFhLENBQUNHLGdCQUFnQixDQUFDMEQsR0FBRyxDQUFDLENBQUMsQ0FBQ2lFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQ3JILElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}