var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {#!/usr/bin/env node
/*
 * If this version is ALREADY on npm, what we would publish must declare the same
 * install surface as what IS published.
 *
 * `ci.yml`'s publish step skips when `package.json`'s version already exists, and says so
 * with a `::notice::` — not a failure. That skip is correct (a re-run of an old commit
 * must not try to republish) and it is also how `main` and the published package drifted
 * apart for weeks without a single red build: the SDK pin moved from `^0.52.0` to
 * `^0.65.0` on `main`, the version was never bumped, so `0.1.2` on npm kept declaring
 * `^0.52.0`. Every consumer installing the package got the OLD pin, npm nested a second
 * SDK copy under grove, and R3-556 — which composes this package — was blocked by it with
 * nothing anywhere reporting a problem.
 *
 * The invariant this restores: a skip is benign only when it is a NO-OP. Same version,
 * different declarations, means the version number is a lie and the fix is to bump it.
 *
 * ## What is compared, and what cannot be
 *
 * The dependency blocks, plus `main` and `exports`: the parts of the manifest a
 * consumer's install and resolution actually read, so a difference there changes what is
 * on a consumer's disk or which file they get when they import. `devDependencies` is
 * excluded because it is never on a consumer's disk. `files` is excluded from the
 * MANIFEST comparison because it CANNOT be compared there — npm does not keep it in the
 * packument, so the registry has no answer to compare against. Comparing whole tarballs
 * would fail on every timestamp and prove nothing.
 *
 * The manifest half closed the R3-556 hole and left the PAYLOAD half open, which then
 * produced a worse instance of the same failure (R3-751): a source-only change under an
 * already-published version passes the manifest comparison, the publish step skips with
 * a notice, and every consumer keeps the broken surface. So when the manifest is at
 * parity, the packed payload is compared too — per-entry content digests over `npm pack`
 * of both sides, `package.json` included (a change to `files` or `scripts` is invisible
 * to the manifest comparison but lands in the payload). Tarball bytes are never compared:
 * gzip framing, mtimes, uid/gid and mode differ on every pack of identical content; the
 * file contents are exact.
 *
 * ## Where it runs, and why in two places
 *
 * `build-test` (through `verify`), where it catches a pin that moves without a version
 * bump ON THE PULL REQUEST that does it — which is the only moment the fix is one line.
 * A version not yet published is the ordinary state there, so that is exit 0, not a
 * failure. And again in the publish job, where a drift means the release about to be
 * skipped would silently no-op.
 *
 * Usage: node scripts/check-published-parity.mjs [--self-test] [--offline-ok]
 * Exit:  0 parity (manifest and, once the version is published, payload), or this
 *        version is not published yet (nothing to compare)
 *        1 drift — same version, different manifest declarations or a different
 *        packed payload
 *        2 cannot answer (registry unreadable, offline, malformed reply; or the
 *        payload comparison could not run)
 *          …unless --offline-ok, which downgrades ONLY that case to 0.
 */
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.classifyRegistryReply = classifyRegistryReply;
exports.dependencyDrift = dependencyDrift;
exports.entryDigests = entryDigests;
exports.onlyTarball = onlyTarball;
exports.payloadDrift = payloadDrift;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.find.js");
require("core-js/modules/esnext.iterator.map.js");
var _nodeFs = require("node:fs");
var _nodePath = require("node:path");
var _nodeOs = require("node:os");
var _nodeUrl = require("node:url");
var _nodeCrypto = require("node:crypto");
var _nodeChild_process = require("node:child_process");
const ROOT = (0, _nodePath.join)((0, _nodePath.dirname)((0, _nodeUrl.fileURLToPath)($ir_import_meta.url)), '..');

/** The dependency blocks a consumer's install resolves against. */
const BLOCKS = ['dependencies', 'peerDependencies', 'optionalDependencies'];
/** Non-block fields that decide WHICH FILE a consumer's import lands on. */
const FIELDS = ['main', 'exports'];

/** Stable stringify, so key ORDER is not reported as a difference. */
const stable = v => {
  if (v === undefined) return undefined;
  if (v === null || typeof v !== 'object') return JSON.stringify(v);
  if (Array.isArray(v)) return `[${v.map(stable).join(',')}]`;
  return `{${Object.keys(v).sort().map(k => `${JSON.stringify(k)}:${stable(v[k])}`).join(',')}}`;
};

/**
 * Compare two manifests' install surface.
 *
 * Returns the differences as `{ block, name, published, local }` rows — empty means
 * parity. A missing block on either side is the empty object, never a reason to skip the
 * comparison: dropping `peerDependencies` wholesale is exactly the kind of change that
 * must not ride an unbumped version.
 */
function dependencyDrift(published, local) {
  const rows = [];
  for (const block of BLOCKS) {
    const p = published?.[block] ?? {};
    const l = local?.[block] ?? {};
    for (const name of [...new Set([...Object.keys(p), ...Object.keys(l)])].sort()) {
      if (p[name] !== l[name]) {
        rows.push({
          block,
          name,
          published: p[name] ?? '(absent)',
          local: l[name] ?? '(absent)'
        });
      }
    }
  }
  for (const field of FIELDS) {
    const p = stable(published?.[field]);
    const l = stable(local?.[field]);
    if (p !== l) rows.push({
      block: '(root)',
      name: field,
      published: p ?? '(absent)',
      local: l ?? '(absent)'
    });
  }
  return rows;
}

/**
 * Compare two packed payloads, per entry.
 *
 * Takes two `Map<string, string>` of package-relative path → content digest, as
 * `entryDigests` returns. Returns the differences as `{ path, published, local }` rows —
 * empty means parity. A path on one side only is a row reading `(absent)` on the other,
 * in both directions: 80ff078 both changed and added files, and an added-only change
 * must not be silent (R3-751).
 */
function payloadDrift(published, local) {
  const rows = [];
  for (const path of [...new Set([...published.keys(), ...local.keys()])].sort()) {
    const p = published.get(path);
    const l = local.get(path);
    if (p !== l) rows.push({
      path,
      published: p ?? '(absent)',
      local: l ?? '(absent)'
    });
  }
  return rows;
}

/** sha256 of one extracted entry, hex — the per-entry content digest. */
function fileDigest(absPath) {
  return (0, _nodeCrypto.createHash)('sha256').update((0, _nodeFs.readFileSync)(absPath)).digest('hex');
}

/** Walk an extracted package root, returning `Map<relativePath, digest>` (regular files). */
function treeDigests(root) {
  const map = new Map();
  const walk = rel => {
    const abs = rel === '' ? root : (0, _nodePath.join)(root, rel);
    if ((0, _nodeFs.statSync)(abs).isDirectory()) {
      for (const entry of (0, _nodeFs.readdirSync)(abs)) walk(rel === '' ? entry : `${rel}/${entry}`);
    } else if ((0, _nodeFs.statSync)(abs).isFile()) {
      map.set(rel, fileDigest(abs));
    }
  };
  walk('');
  return map;
}

/**
 * The impure half, one function: extract one packed tarball into a temp directory this
 * script creates and removes, and return `Map<package-relative path, content digest>`.
 * `tar` extracts with `--strip-components 1` so the archive's `package/` prefix is gone
 * and keys are package-root-relative (`package.json`, `src/lib.ts`, …).
 * Shells out to `tar -xzf` as the script shells out to `npm` — no new dependency.
 */
function entryDigests(tarballPath) {
  const dir = (0, _nodeFs.mkdtempSync)((0, _nodePath.join)((0, _nodeOs.tmpdir)(), 'published-parity-payload-'));
  try {
    (0, _nodeChild_process.execFileSync)('tar', ['-xzf', tarballPath, '-C', dir, '--strip-components', '1'], {
      stdio: ['ignore', 'ignore', 'pipe'],
      // Bounded like every other process this script spawns: a stalled extraction must
      // land in the cannot-answer catch, not hang the job (R17).
      timeout: 120_000
    });
    return treeDigests(dir);
  } finally {
    (0, _nodeFs.rmSync)(dir, {
      recursive: true,
      force: true
    });
  }
}

/**
 * The one tarball in a directory `npm pack` was pointed at. Thrown as its own error so
 * the "packed nothing" failure has a name the self-test can pin (R2).
 */
function onlyTarball(dir) {
  const tarball = (0, _nodeFs.readdirSync)(dir).find(f => f.endsWith('.tgz'));
  if (!tarball) throw new Error('npm pack wrote no tarball');
  return tarball;
}

/**
 * Pack one side into a fresh temp directory and return the tarball's path. Both payload
 * sides come from `npm pack` so they are by construction the `files:` payload, and the
 * published side uses the same code path as the local side (npm downloads the registry
 * tarball for a `<name>@<version>` spec). A fresh directory per side, because the
 * published tarball and the local pack have the SAME filename and would collide.
 */
function packTarball(spec, cwd) {
  const dest = (0, _nodeFs.mkdtempSync)((0, _nodePath.join)((0, _nodeOs.tmpdir)(), 'published-parity-pack-'));
  try {
    (0, _nodeChild_process.execFileSync)('npm', ['pack', ...spec, '--pack-destination', dest], {
      cwd,
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'ignore'],
      timeout: 120_000
    });
    return {
      dir: dest,
      tarball: (0, _nodePath.join)(dest, onlyTarball(dest))
    };
  } catch (e) {
    (0, _nodeFs.rmSync)(dest, {
      recursive: true,
      force: true
    });
    throw e;
  }
}

/**
 * The one cannot-answer shape, shared by both sites that cannot run a comparison (R6):
 * a registry read that would not answer, and a payload comparison that could not run.
 * Both mean "parity was NOT checked", both are exit 2, and `--offline-ok` downgrades
 * ONLY this case — never a drift — with a line that says the comparison never ran.
 */
function cannotAnswerExit(subject, reason, offlineOk) {
  console.error(offlineOk ? `⚠ could not ${subject} (${reason}) — parity was NOT checked. ` + `Not failing the build (--offline-ok); the publish job checks this strictly.` : `✗ cannot ${subject} (${reason}) — not answering is not a pass.`);
  return offlineOk ? 0 : 2;
}

/**
 * What the registry's answer MEANS — pure, so every branch is testable without a
 * network. `npm view <spec> … --json` has three shapes worth telling apart, and the
 * first two both exit non-zero, which is why the exit code alone is not the answer:
 *
 *  - **absent** — the version is not published. npm prints `{"error":{"code":"E404"}}`
 *    to STDOUT and exits non-zero. There is nothing to compare, and on a pull request
 *    this is the ordinary state, so it is a pass.
 *  - **unreadable** — no network, a private-registry auth failure, a malformed reply.
 *    Never a pass on its own: the publish job only reaches this once `npm view` has
 *    already said the version EXISTS, so failing to read it there is a real problem.
 *  - **published** — a JSON object of the requested fields. EMPTY stdout is this case
 *    too, and means a manifest declaring none of them.
 */
function classifyRegistryReply({
  stdout,
  failed
}) {
  const text = (stdout ?? '').trim();
  if (text === '') return failed ? {
    kind: 'unreadable',
    reason: 'empty reply'
  } : {
    kind: 'published',
    manifest: {}
  };
  let parsed;
  try {
    parsed = JSON.parse(text);
  } catch {
    return {
      kind: 'unreadable',
      reason: 'reply was not JSON'
    };
  }
  if (parsed && typeof parsed === 'object' && parsed.error) {
    return parsed.error.code === 'E404' ? {
      kind: 'absent'
    } : {
      kind: 'unreadable',
      reason: parsed.error.summary ?? parsed.error.code ?? 'registry error'
    };
  }
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
    return {
      kind: 'unreadable',
      reason: 'reply was not an object'
    };
  }
  return {
    kind: 'published',
    manifest: parsed
  };
}
function selfTest() {
  let ok = 0;
  let total = 0;
  const check = (label, cond) => {
    total += 1;
    if (cond) ok += 1;
    console.log(`${cond ? 'PASS' : 'FAIL'}  ${label}`);
  };
  const dep = o => ({
    dependencies: o
  });

  // ── the comparison ─────────────────────────────────────────────────────────
  check('identical manifests have no drift', dependencyDrift(dep({
    a: '1.0.0'
  }), dep({
    a: '1.0.0'
  })).length === 0);
  // The R3-556 case, verbatim.
  const moved = dependencyDrift(dep({
    '@immediately-run/sdk': '^0.52.0'
  }), dep({
    '@immediately-run/sdk': '^0.65.0'
  }));
  check('a moved pin is drift', moved.length === 1);
  check('…and names both sides', moved[0].published === '^0.52.0' && moved[0].local === '^0.65.0');
  check('an ADDED dependency is drift', dependencyDrift(dep({}), dep({
    a: '1.0.0'
  }))[0]?.local === '1.0.0');
  check('a REMOVED dependency is drift', dependencyDrift(dep({
    a: '1.0.0'
  }), dep({}))[0]?.local === '(absent)');
  check('a peer moved while the dependency stayed is still drift', dependencyDrift({
    dependencies: {
      a: '1.0.0'
    },
    peerDependencies: {
      a: '^1.0.0'
    }
  }, {
    dependencies: {
      a: '1.0.0'
    },
    peerDependencies: {
      a: '^2.0.0'
    }
  }).length === 1);
  check('dropping peerDependencies entirely is drift, not an excuse to skip', dependencyDrift({
    peerDependencies: {
      a: '^1.0.0'
    }
  }, {}).length === 1);
  check('devDependencies are not compared — they are not on a consumer disk', dependencyDrift({
    devDependencies: {
      a: '1'
    }
  }, {
    devDependencies: {
      a: '2'
    }
  }).length === 0);
  check('order does not matter', dependencyDrift(dep({
    a: '1',
    b: '2'
  }), dep({
    b: '2',
    a: '1'
  })).length === 0);
  // `main`/`exports` decide which FILE an import lands on, so they are the same class of
  // change as a moved pin — and an exports map is nested, hence the stable compare.
  check('a moved `main` is drift', dependencyDrift({
    main: 'src/a.tsx'
  }, {
    main: 'src/b.tsx'
  }).length === 1);
  check('a changed `exports` subpath is drift', dependencyDrift({
    exports: {
      '.': './a.ts'
    }
  }, {
    exports: {
      '.': './b.ts'
    }
  }).length === 1);
  check('an ADDED `exports` subpath is drift', dependencyDrift({
    exports: {
      '.': './a.ts'
    }
  }, {
    exports: {
      '.': './a.ts',
      './x': './x.ts'
    }
  }).length === 1);
  check('the same exports map in a different key order is NOT drift', dependencyDrift({
    exports: {
      '.': './a.ts',
      './x': './x.ts'
    }
  }, {
    exports: {
      './x': './x.ts',
      '.': './a.ts'
    }
  }).length === 0);

  // ── what the registry's answer means ───────────────────────────────────────
  // The E404 body is the REAL one, captured from
  // `npm view @immediately-run/grove@0.1.3 dependencies --json` on 2026-09-15, when
  // 0.1.3 was unpublished — not a hand-written approximation of it.
  const e404 = JSON.stringify({
    error: {
      code: 'E404',
      summary: 'No match found for version 0.1.3',
      detail: "'@immediately-run/grove@0.1.3' is not in this registry."
    }
  });
  check('an E404 body is ABSENT, not unreadable', classifyRegistryReply({
    stdout: e404,
    failed: true
  }).kind === 'absent');
  // The published body is equally real: the SAME argv this script sends (`BLOCKS` +
  // `FIELDS`), against 0.1.2, captured 2026-09-15. Capturing a narrower command would
  // make the fixture stop being the producer's output the moment a field is added —
  // and would leave this case green with the whole `main`/`exports` comparison deleted.
  const real = JSON.stringify({
    dependencies: {
      '@immediately-run/mdx-plugins': '0.4.0',
      '@immediately-run/sdk': '^0.52.0',
      react: '^19.2.5',
      'react-dom': '^19.2.5'
    },
    peerDependencies: {
      '@immediately-run/sdk': '^0.52.0',
      react: '^19.2.5',
      'react-dom': '^19.2.5'
    },
    main: 'src/main.tsx',
    exports: {
      '.': './src/lib.ts',
      './app': './src/App.tsx',
      './manifest': './viewer.manifest.json',
      './components': './src/mdxComponents.ts',
      './styles.css': './src/GroveApp.css',
      './theme.css': './src/index.css',
      './package.json': './package.json'
    }
  });
  const pub = classifyRegistryReply({
    stdout: real,
    failed: false
  });
  check('a real packument reply is PUBLISHED', pub.kind === 'published');
  // EXACTLY the three real drifts, and NO `(root)` row: 0.1.2's `main`/`exports` match
  // this tree, so a spurious root row would mean the comparison of those fields is wrong.
  const realRows = dependencyDrift(pub.manifest, JSON.parse((0, _nodeFs.readFileSync)((0, _nodePath.join)(ROOT, 'package.json'), 'utf8')));
  check('…and drifts against this tree in EXACTLY the three places 0.1.2 really drifted', JSON.stringify(realRows.map(r => `${r.block}.${r.name}`)) === JSON.stringify(['dependencies.@immediately-run/mdx-plugins', 'dependencies.@immediately-run/sdk', 'peerDependencies.@immediately-run/sdk']));
  check('an absent-blocks manifest is published-with-nothing, not unreadable', classifyRegistryReply({
    stdout: '',
    failed: false
  }).kind === 'published');
  check('…which then reads every local block as ADDED', dependencyDrift(classifyRegistryReply({
    stdout: '',
    failed: false
  }).manifest, dep({
    a: '1'
  })).length === 1);
  check('an empty reply that FAILED is unreadable', classifyRegistryReply({
    stdout: '',
    failed: true
  }).kind === 'unreadable');
  check('a non-E404 registry error is unreadable, never absent', classifyRegistryReply({
    stdout: JSON.stringify({
      error: {
        code: 'E401',
        summary: 'auth'
      }
    }),
    failed: true
  }).kind === 'unreadable');
  check('a non-JSON reply is unreadable', classifyRegistryReply({
    stdout: '<html>502</html>',
    failed: true
  }).kind === 'unreadable');
  check('a JSON ARRAY reply is unreadable, not an empty manifest', classifyRegistryReply({
    stdout: '["0.1.1","0.1.2"]',
    failed: false
  }).kind === 'unreadable');

  // ── the payload comparison ─────────────────────────────────────────────────
  const map = o => new Map(Object.entries(o));
  check('identical payload Maps have no drift', payloadDrift(map({
    a: 'h1',
    b: 'h2'
  }), map({
    b: 'h2',
    a: 'h1'
  })).length === 0);
  const changed = payloadDrift(map({
    a: 'h1',
    b: 'h2'
  }), map({
    a: 'h9',
    b: 'h2'
  }));
  check('a changed digest is one row naming the path and both digests', changed.length === 1 && changed[0].path === 'a' && changed[0].published === 'h1' && changed[0].local === 'h9');
  const added = payloadDrift(map({
    a: 'h1'
  }), map({
    a: 'h1',
    'src/new.ts': 'h2'
  }));
  check('an ADDED file is a row, (absent) on the published side', added.length === 1 && added[0].path === 'src/new.ts' && added[0].published === '(absent)' && added[0].local === 'h2');
  const removed = payloadDrift(map({
    'src/old.ts': 'h1'
  }), map({}));
  check('a REMOVED file is a row, (absent) on the local side', removed.length === 1 && removed[0].path === 'src/old.ts' && removed[0].published === 'h1' && removed[0].local === '(absent)');

  // Real producer: the fixture Maps for the identical-tree case are built by running
  // `entryDigests` over a tarball THIS repo packs right here through the production
  // `packTarball` path — a hand-typed Map would stay green with the digest function
  // deleted, and an inline duplicate of the pack call would stay green with
  // `packTarball` deleted (R3-751, R2). No `prepack` script exists, so the pack is
  // offline and side-effect-free.
  const emptyDir = (0, _nodeFs.mkdtempSync)((0, _nodePath.join)((0, _nodeOs.tmpdir)(), 'published-parity-empty-'));
  const synthDir = (0, _nodeFs.mkdtempSync)((0, _nodePath.join)((0, _nodeOs.tmpdir)(), 'published-parity-synth-'));
  let packed;
  try {
    let threw = null;
    try {
      onlyTarball(emptyDir);
    } catch (e) {
      threw = e;
    }
    check('onlyTarball refuses a directory with no tarball, by name', threw instanceof Error && threw.message === 'npm pack wrote no tarball');

    // The digest walk, pinned against DIRECT hashes of a synthetic tree (a file, and a
    // file one level down): a `fileDigest` that returned a constant, or a `treeDigests`
    // that skipped subdirectories, would otherwise leave every real-pack case green —
    // the gate could silently never fire, which is the exact failure R3-751 closes.
    (0, _nodeFs.mkdirSync)((0, _nodePath.join)(synthDir, 'package', 'sub'), {
      recursive: true
    });
    (0, _nodeFs.writeFileSync)((0, _nodePath.join)(synthDir, 'package', 'a.txt'), 'alpha');
    (0, _nodeFs.writeFileSync)((0, _nodePath.join)(synthDir, 'package', 'sub', 'b.txt'), 'beta');
    (0, _nodeChild_process.execFileSync)('tar', ['-czf', (0, _nodePath.join)(synthDir, 'synth.tgz'), '-C', synthDir, 'package'], {
      stdio: ['ignore', 'ignore', 'pipe'],
      timeout: 30_000
    });
    const synth = entryDigests((0, _nodePath.join)(synthDir, 'synth.tgz'));
    const direct = p => (0, _nodeCrypto.createHash)('sha256').update((0, _nodeFs.readFileSync)((0, _nodePath.join)(synthDir, 'package', p))).digest('hex');
    check('entryDigests returns the exact content digests, nested keys included', synth.size === 2 && synth.get('a.txt') === direct('a.txt') && synth.get('sub/b.txt') === direct('sub/b.txt'));
    packed = packTarball([], ROOT);
    const real = entryDigests(packed.tarball);
    check('entryDigests reads a real pack of this repo (non-empty, package.json included)', real.size > 0 && real.has('package.json'));
    check('…and the identical-tree case has no drift', payloadDrift(real, real).length === 0);
    const firstPath = [...real.keys()][0];
    const mutated = new Map(real);
    mutated.set(firstPath, 'deadbeef');
    const mutatedRows = payloadDrift(real, mutated);
    check('…a one-file mutation against the real Map is exactly one row', mutatedRows.length === 1 && mutatedRows[0].path === firstPath && mutatedRows[0].published === real.get(firstPath) && mutatedRows[0].local === 'deadbeef');
    check('…and the pack directory it made is the one `onlyTarball` finds', onlyTarball(packed.dir) === packed.tarball.split('/').pop());

    // The one downgrade policy, called directly: strict is exit 2 with the honest line,
    // `--offline-ok` is exit 0 and says the comparison never ran. A flipped ternary or a
    // re-pasted message turns these red (round-2 R2).
    const seen = [];
    const realError = console.error;
    console.error = m => seen.push(m);
    const strictCode = cannotAnswerExit('read X from the registry', 'boom', false);
    const offlineCode = cannotAnswerExit('read X from the registry', 'boom', true);
    console.error = realError;
    check('cannotAnswerExit: strict is 2 and names what did not answer; --offline-ok is 0 and says parity was NOT checked', strictCode === 2 && seen[0].includes('read X from the registry') && seen[0].includes('not answering is not a pass') && offlineCode === 0 && seen[1].includes('parity was NOT checked'));
  } finally {
    for (const dir of [emptyDir, synthDir, packed?.dir]) {
      if (dir) (0, _nodeFs.rmSync)(dir, {
        recursive: true,
        force: true
      });
    }
  }
  console.log(`\n${ok}/${total} self-test cases.`);
  return ok === total ? 0 : 1;
}
if (process.argv.includes('--self-test')) process.exit(selfTest());
const offlineOk = process.argv.includes('--offline-ok');
const local = JSON.parse((0, _nodeFs.readFileSync)((0, _nodePath.join)(ROOT, 'package.json'), 'utf8'));
const spec = `${local.name}@${local.version}`;
let stdout = '';
let failed = false;
try {
  stdout = (0, _nodeChild_process.execFileSync)('npm', ['view', spec, ...BLOCKS, ...FIELDS, '--json'], {
    encoding: 'utf8',
    stdio: ['ignore', 'pipe', 'ignore'],
    // The repo's only outbound call. Without a bound, a hung registry read holds the
    // job to its ceiling; a kill lands in the catch below and reads as unreadable.
    timeout: 30_000
  });
} catch (e) {
  failed = true;
  stdout = typeof e?.stdout === 'string' ? e.stdout : '';
}
const reply = classifyRegistryReply({
  stdout,
  failed
});
if (reply.kind === 'absent') {
  console.log(`✓ ${spec} is not published yet — nothing to compare.`);
  process.exit(0);
}
if (reply.kind === 'unreadable') {
  // Under `--offline-ok` this IS a pass — the build is deliberately not failed for a
  // registry that would not answer — and a log that says "not answering is not a pass"
  // beside a zero exit tells a reader the opposite of what happened, and hides that the
  // comparison never ran at all. The one cannot-answer shape lives in `cannotAnswerExit`.
  process.exit(cannotAnswerExit(`read ${spec} from the registry`, reply.reason, offlineOk));
}
const rows = dependencyDrift(reply.manifest, local);
if (rows.length > 0) {
  console.error(`::error::${spec} is already published, and this tree declares a DIFFERENT install surface. ` + `Publishing would be skipped, so the change would never reach npm — bump the version.`);
  for (const r of rows) {
    console.error(`  ${r.block}.${r.name}: published ${r.published} · here ${r.local}`);
  }
  process.exit(1);
}

// Manifest at parity — the exact hole R3-751 closed: a source-only change under an
// already-published version passes everything above while every consumer keeps the old
// bytes. Compare the packed payloads, `package.json` included.
//
// No `process.exit` inside the try: it terminates without unwinding, so the `finally`
// that removes the pack directories would never run and every strict comparison would
// leak both. Every path sets `exitCode` and falls through to the one exit at the end.
let publishedPack;
let localPack;
let exitCode = 0;
try {
  publishedPack = packTarball([spec], ROOT);
  localPack = packTarball([], ROOT);
  const payloadRows = payloadDrift(entryDigests(publishedPack.tarball), entryDigests(localPack.tarball));
  if (payloadRows.length === 0) {
    console.log(`✓ ${spec} on npm declares the same install surface and ships the same payload as this tree.`);
  } else {
    console.error(`::error::${spec} is already published, and this tree's packed PAYLOAD differs from the published package ` + `in ${payloadRows.length} file(s). Publishing would be skipped, so the change would never reach npm — bump the version.`);
    for (const r of payloadRows.slice(0, 20)) {
      const short = d => d === '(absent)' ? d : `${d.slice(0, 12)}…`;
      console.error(`  ${r.path}: published ${short(r.published)} · here ${short(r.local)}`);
    }
    if (payloadRows.length > 20) console.error(`  …and ${payloadRows.length - 20} more.`);
    exitCode = 1;
  }
} catch (e) {
  // The payload comparison could not RUN — the same class as an unreadable registry, and
  // never reported as a pass. Downgraded only by --offline-ok, like that case.
  exitCode = cannotAnswerExit('compare the packed payload', e instanceof Error ? e.message : String(e), offlineOk);
} finally {
  for (const pack of [publishedPack, localPack]) {
    if (pack) (0, _nodeFs.rmSync)(pack.dir, {
      recursive: true,
      force: true
    });
  }
}
process.exit(exitCode);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJPYmplY3QiLCJkZWZpbmVQcm9wZXJ0eSIsImV4cG9ydHMiLCJ2YWx1ZSIsImNsYXNzaWZ5UmVnaXN0cnlSZXBseSIsImRlcGVuZGVuY3lEcmlmdCIsImVudHJ5RGlnZXN0cyIsIm9ubHlUYXJiYWxsIiwicGF5bG9hZERyaWZ0IiwicmVxdWlyZSIsIl9ub2RlRnMiLCJfbm9kZVBhdGgiLCJfbm9kZU9zIiwiX25vZGVVcmwiLCJfbm9kZUNyeXB0byIsIl9ub2RlQ2hpbGRfcHJvY2VzcyIsIlJPT1QiLCJqb2luIiwiZGlybmFtZSIsImZpbGVVUkxUb1BhdGgiLCIkaXJfaW1wb3J0X21ldGEiLCJ1cmwiLCJCTE9DS1MiLCJGSUVMRFMiLCJzdGFibGUiLCJ2IiwidW5kZWZpbmVkIiwiSlNPTiIsInN0cmluZ2lmeSIsIkFycmF5IiwiaXNBcnJheSIsIm1hcCIsImtleXMiLCJzb3J0IiwiayIsInB1Ymxpc2hlZCIsImxvY2FsIiwicm93cyIsImJsb2NrIiwicCIsImwiLCJuYW1lIiwiU2V0IiwicHVzaCIsImZpZWxkIiwicGF0aCIsImdldCIsImZpbGVEaWdlc3QiLCJhYnNQYXRoIiwiY3JlYXRlSGFzaCIsInVwZGF0ZSIsInJlYWRGaWxlU3luYyIsImRpZ2VzdCIsInRyZWVEaWdlc3RzIiwicm9vdCIsIk1hcCIsIndhbGsiLCJyZWwiLCJhYnMiLCJzdGF0U3luYyIsImlzRGlyZWN0b3J5IiwiZW50cnkiLCJyZWFkZGlyU3luYyIsImlzRmlsZSIsInNldCIsInRhcmJhbGxQYXRoIiwiZGlyIiwibWtkdGVtcFN5bmMiLCJ0bXBkaXIiLCJleGVjRmlsZVN5bmMiLCJzdGRpbyIsInRpbWVvdXQiLCJybVN5bmMiLCJyZWN1cnNpdmUiLCJmb3JjZSIsInRhcmJhbGwiLCJmaW5kIiwiZiIsImVuZHNXaXRoIiwiRXJyb3IiLCJwYWNrVGFyYmFsbCIsInNwZWMiLCJjd2QiLCJkZXN0IiwiZW5jb2RpbmciLCJlIiwiY2Fubm90QW5zd2VyRXhpdCIsInN1YmplY3QiLCJyZWFzb24iLCJvZmZsaW5lT2siLCJjb25zb2xlIiwiZXJyb3IiLCJzdGRvdXQiLCJmYWlsZWQiLCJ0ZXh0IiwidHJpbSIsImtpbmQiLCJtYW5pZmVzdCIsInBhcnNlZCIsInBhcnNlIiwiY29kZSIsInN1bW1hcnkiLCJzZWxmVGVzdCIsIm9rIiwidG90YWwiLCJjaGVjayIsImxhYmVsIiwiY29uZCIsImxvZyIsImRlcCIsIm8iLCJkZXBlbmRlbmNpZXMiLCJhIiwibGVuZ3RoIiwibW92ZWQiLCJwZWVyRGVwZW5kZW5jaWVzIiwiZGV2RGVwZW5kZW5jaWVzIiwiYiIsIm1haW4iLCJlNDA0IiwiZGV0YWlsIiwicmVhbCIsInJlYWN0IiwicHViIiwicmVhbFJvd3MiLCJyIiwiZW50cmllcyIsImNoYW5nZWQiLCJhZGRlZCIsInJlbW92ZWQiLCJlbXB0eURpciIsInN5bnRoRGlyIiwicGFja2VkIiwidGhyZXciLCJtZXNzYWdlIiwibWtkaXJTeW5jIiwid3JpdGVGaWxlU3luYyIsInN5bnRoIiwiZGlyZWN0Iiwic2l6ZSIsImhhcyIsImZpcnN0UGF0aCIsIm11dGF0ZWQiLCJtdXRhdGVkUm93cyIsInNwbGl0IiwicG9wIiwic2VlbiIsInJlYWxFcnJvciIsIm0iLCJzdHJpY3RDb2RlIiwib2ZmbGluZUNvZGUiLCJpbmNsdWRlcyIsInByb2Nlc3MiLCJhcmd2IiwiZXhpdCIsInZlcnNpb24iLCJyZXBseSIsInB1Ymxpc2hlZFBhY2siLCJsb2NhbFBhY2siLCJleGl0Q29kZSIsInBheWxvYWRSb3dzIiwic2xpY2UiLCJzaG9ydCIsImQiLCJTdHJpbmciLCJwYWNrIl0sInNvdXJjZXMiOlsiY2hlY2stcHVibGlzaGVkLXBhcml0eS5tanMiXSwic291cmNlc0NvbnRlbnQiOlsiIyEvdXNyL2Jpbi9lbnYgbm9kZVxuLypcbiAqIElmIHRoaXMgdmVyc2lvbiBpcyBBTFJFQURZIG9uIG5wbSwgd2hhdCB3ZSB3b3VsZCBwdWJsaXNoIG11c3QgZGVjbGFyZSB0aGUgc2FtZVxuICogaW5zdGFsbCBzdXJmYWNlIGFzIHdoYXQgSVMgcHVibGlzaGVkLlxuICpcbiAqIGBjaS55bWxgJ3MgcHVibGlzaCBzdGVwIHNraXBzIHdoZW4gYHBhY2thZ2UuanNvbmAncyB2ZXJzaW9uIGFscmVhZHkgZXhpc3RzLCBhbmQgc2F5cyBzb1xuICogd2l0aCBhIGA6Om5vdGljZTo6YCDigJQgbm90IGEgZmFpbHVyZS4gVGhhdCBza2lwIGlzIGNvcnJlY3QgKGEgcmUtcnVuIG9mIGFuIG9sZCBjb21taXRcbiAqIG11c3Qgbm90IHRyeSB0byByZXB1Ymxpc2gpIGFuZCBpdCBpcyBhbHNvIGhvdyBgbWFpbmAgYW5kIHRoZSBwdWJsaXNoZWQgcGFja2FnZSBkcmlmdGVkXG4gKiBhcGFydCBmb3Igd2Vla3Mgd2l0aG91dCBhIHNpbmdsZSByZWQgYnVpbGQ6IHRoZSBTREsgcGluIG1vdmVkIGZyb20gYF4wLjUyLjBgIHRvXG4gKiBgXjAuNjUuMGAgb24gYG1haW5gLCB0aGUgdmVyc2lvbiB3YXMgbmV2ZXIgYnVtcGVkLCBzbyBgMC4xLjJgIG9uIG5wbSBrZXB0IGRlY2xhcmluZ1xuICogYF4wLjUyLjBgLiBFdmVyeSBjb25zdW1lciBpbnN0YWxsaW5nIHRoZSBwYWNrYWdlIGdvdCB0aGUgT0xEIHBpbiwgbnBtIG5lc3RlZCBhIHNlY29uZFxuICogU0RLIGNvcHkgdW5kZXIgZ3JvdmUsIGFuZCBSMy01NTYg4oCUIHdoaWNoIGNvbXBvc2VzIHRoaXMgcGFja2FnZSDigJQgd2FzIGJsb2NrZWQgYnkgaXQgd2l0aFxuICogbm90aGluZyBhbnl3aGVyZSByZXBvcnRpbmcgYSBwcm9ibGVtLlxuICpcbiAqIFRoZSBpbnZhcmlhbnQgdGhpcyByZXN0b3JlczogYSBza2lwIGlzIGJlbmlnbiBvbmx5IHdoZW4gaXQgaXMgYSBOTy1PUC4gU2FtZSB2ZXJzaW9uLFxuICogZGlmZmVyZW50IGRlY2xhcmF0aW9ucywgbWVhbnMgdGhlIHZlcnNpb24gbnVtYmVyIGlzIGEgbGllIGFuZCB0aGUgZml4IGlzIHRvIGJ1bXAgaXQuXG4gKlxuICogIyMgV2hhdCBpcyBjb21wYXJlZCwgYW5kIHdoYXQgY2Fubm90IGJlXG4gKlxuICogVGhlIGRlcGVuZGVuY3kgYmxvY2tzLCBwbHVzIGBtYWluYCBhbmQgYGV4cG9ydHNgOiB0aGUgcGFydHMgb2YgdGhlIG1hbmlmZXN0IGFcbiAqIGNvbnN1bWVyJ3MgaW5zdGFsbCBhbmQgcmVzb2x1dGlvbiBhY3R1YWxseSByZWFkLCBzbyBhIGRpZmZlcmVuY2UgdGhlcmUgY2hhbmdlcyB3aGF0IGlzXG4gKiBvbiBhIGNvbnN1bWVyJ3MgZGlzayBvciB3aGljaCBmaWxlIHRoZXkgZ2V0IHdoZW4gdGhleSBpbXBvcnQuIGBkZXZEZXBlbmRlbmNpZXNgIGlzXG4gKiBleGNsdWRlZCBiZWNhdXNlIGl0IGlzIG5ldmVyIG9uIGEgY29uc3VtZXIncyBkaXNrLiBgZmlsZXNgIGlzIGV4Y2x1ZGVkIGZyb20gdGhlXG4gKiBNQU5JRkVTVCBjb21wYXJpc29uIGJlY2F1c2UgaXQgQ0FOTk9UIGJlIGNvbXBhcmVkIHRoZXJlIOKAlCBucG0gZG9lcyBub3Qga2VlcCBpdCBpbiB0aGVcbiAqIHBhY2t1bWVudCwgc28gdGhlIHJlZ2lzdHJ5IGhhcyBubyBhbnN3ZXIgdG8gY29tcGFyZSBhZ2FpbnN0LiBDb21wYXJpbmcgd2hvbGUgdGFyYmFsbHNcbiAqIHdvdWxkIGZhaWwgb24gZXZlcnkgdGltZXN0YW1wIGFuZCBwcm92ZSBub3RoaW5nLlxuICpcbiAqIFRoZSBtYW5pZmVzdCBoYWxmIGNsb3NlZCB0aGUgUjMtNTU2IGhvbGUgYW5kIGxlZnQgdGhlIFBBWUxPQUQgaGFsZiBvcGVuLCB3aGljaCB0aGVuXG4gKiBwcm9kdWNlZCBhIHdvcnNlIGluc3RhbmNlIG9mIHRoZSBzYW1lIGZhaWx1cmUgKFIzLTc1MSk6IGEgc291cmNlLW9ubHkgY2hhbmdlIHVuZGVyIGFuXG4gKiBhbHJlYWR5LXB1Ymxpc2hlZCB2ZXJzaW9uIHBhc3NlcyB0aGUgbWFuaWZlc3QgY29tcGFyaXNvbiwgdGhlIHB1Ymxpc2ggc3RlcCBza2lwcyB3aXRoXG4gKiBhIG5vdGljZSwgYW5kIGV2ZXJ5IGNvbnN1bWVyIGtlZXBzIHRoZSBicm9rZW4gc3VyZmFjZS4gU28gd2hlbiB0aGUgbWFuaWZlc3QgaXMgYXRcbiAqIHBhcml0eSwgdGhlIHBhY2tlZCBwYXlsb2FkIGlzIGNvbXBhcmVkIHRvbyDigJQgcGVyLWVudHJ5IGNvbnRlbnQgZGlnZXN0cyBvdmVyIGBucG0gcGFja2BcbiAqIG9mIGJvdGggc2lkZXMsIGBwYWNrYWdlLmpzb25gIGluY2x1ZGVkIChhIGNoYW5nZSB0byBgZmlsZXNgIG9yIGBzY3JpcHRzYCBpcyBpbnZpc2libGVcbiAqIHRvIHRoZSBtYW5pZmVzdCBjb21wYXJpc29uIGJ1dCBsYW5kcyBpbiB0aGUgcGF5bG9hZCkuIFRhcmJhbGwgYnl0ZXMgYXJlIG5ldmVyIGNvbXBhcmVkOlxuICogZ3ppcCBmcmFtaW5nLCBtdGltZXMsIHVpZC9naWQgYW5kIG1vZGUgZGlmZmVyIG9uIGV2ZXJ5IHBhY2sgb2YgaWRlbnRpY2FsIGNvbnRlbnQ7IHRoZVxuICogZmlsZSBjb250ZW50cyBhcmUgZXhhY3QuXG4gKlxuICogIyMgV2hlcmUgaXQgcnVucywgYW5kIHdoeSBpbiB0d28gcGxhY2VzXG4gKlxuICogYGJ1aWxkLXRlc3RgICh0aHJvdWdoIGB2ZXJpZnlgKSwgd2hlcmUgaXQgY2F0Y2hlcyBhIHBpbiB0aGF0IG1vdmVzIHdpdGhvdXQgYSB2ZXJzaW9uXG4gKiBidW1wIE9OIFRIRSBQVUxMIFJFUVVFU1QgdGhhdCBkb2VzIGl0IOKAlCB3aGljaCBpcyB0aGUgb25seSBtb21lbnQgdGhlIGZpeCBpcyBvbmUgbGluZS5cbiAqIEEgdmVyc2lvbiBub3QgeWV0IHB1Ymxpc2hlZCBpcyB0aGUgb3JkaW5hcnkgc3RhdGUgdGhlcmUsIHNvIHRoYXQgaXMgZXhpdCAwLCBub3QgYVxuICogZmFpbHVyZS4gQW5kIGFnYWluIGluIHRoZSBwdWJsaXNoIGpvYiwgd2hlcmUgYSBkcmlmdCBtZWFucyB0aGUgcmVsZWFzZSBhYm91dCB0byBiZVxuICogc2tpcHBlZCB3b3VsZCBzaWxlbnRseSBuby1vcC5cbiAqXG4gKiBVc2FnZTogbm9kZSBzY3JpcHRzL2NoZWNrLXB1Ymxpc2hlZC1wYXJpdHkubWpzIFstLXNlbGYtdGVzdF0gWy0tb2ZmbGluZS1va11cbiAqIEV4aXQ6ICAwIHBhcml0eSAobWFuaWZlc3QgYW5kLCBvbmNlIHRoZSB2ZXJzaW9uIGlzIHB1Ymxpc2hlZCwgcGF5bG9hZCksIG9yIHRoaXNcbiAqICAgICAgICB2ZXJzaW9uIGlzIG5vdCBwdWJsaXNoZWQgeWV0IChub3RoaW5nIHRvIGNvbXBhcmUpXG4gKiAgICAgICAgMSBkcmlmdCDigJQgc2FtZSB2ZXJzaW9uLCBkaWZmZXJlbnQgbWFuaWZlc3QgZGVjbGFyYXRpb25zIG9yIGEgZGlmZmVyZW50XG4gKiAgICAgICAgcGFja2VkIHBheWxvYWRcbiAqICAgICAgICAyIGNhbm5vdCBhbnN3ZXIgKHJlZ2lzdHJ5IHVucmVhZGFibGUsIG9mZmxpbmUsIG1hbGZvcm1lZCByZXBseTsgb3IgdGhlXG4gKiAgICAgICAgcGF5bG9hZCBjb21wYXJpc29uIGNvdWxkIG5vdCBydW4pXG4gKiAgICAgICAgICDigKZ1bmxlc3MgLS1vZmZsaW5lLW9rLCB3aGljaCBkb3duZ3JhZGVzIE9OTFkgdGhhdCBjYXNlIHRvIDAuXG4gKi9cbmltcG9ydCB7IHJlYWRGaWxlU3luYywgd3JpdGVGaWxlU3luYywgbWtkaXJTeW5jLCBta2R0ZW1wU3luYywgcm1TeW5jLCByZWFkZGlyU3luYywgc3RhdFN5bmMgfSBmcm9tICdub2RlOmZzJztcbmltcG9ydCB7IGpvaW4sIGRpcm5hbWUgfSBmcm9tICdub2RlOnBhdGgnO1xuaW1wb3J0IHsgdG1wZGlyIH0gZnJvbSAnbm9kZTpvcyc7XG5pbXBvcnQgeyBmaWxlVVJMVG9QYXRoIH0gZnJvbSAnbm9kZTp1cmwnO1xuaW1wb3J0IHsgY3JlYXRlSGFzaCB9IGZyb20gJ25vZGU6Y3J5cHRvJztcbmltcG9ydCB7IGV4ZWNGaWxlU3luYyB9IGZyb20gJ25vZGU6Y2hpbGRfcHJvY2Vzcyc7XG5cbmNvbnN0IFJPT1QgPSBqb2luKGRpcm5hbWUoZmlsZVVSTFRvUGF0aChpbXBvcnQubWV0YS51cmwpKSwgJy4uJyk7XG5cbi8qKiBUaGUgZGVwZW5kZW5jeSBibG9ja3MgYSBjb25zdW1lcidzIGluc3RhbGwgcmVzb2x2ZXMgYWdhaW5zdC4gKi9cbmNvbnN0IEJMT0NLUyA9IFsnZGVwZW5kZW5jaWVzJywgJ3BlZXJEZXBlbmRlbmNpZXMnLCAnb3B0aW9uYWxEZXBlbmRlbmNpZXMnXTtcbi8qKiBOb24tYmxvY2sgZmllbGRzIHRoYXQgZGVjaWRlIFdISUNIIEZJTEUgYSBjb25zdW1lcidzIGltcG9ydCBsYW5kcyBvbi4gKi9cbmNvbnN0IEZJRUxEUyA9IFsnbWFpbicsICdleHBvcnRzJ107XG5cbi8qKiBTdGFibGUgc3RyaW5naWZ5LCBzbyBrZXkgT1JERVIgaXMgbm90IHJlcG9ydGVkIGFzIGEgZGlmZmVyZW5jZS4gKi9cbmNvbnN0IHN0YWJsZSA9ICh2KSA9PiB7XG4gIGlmICh2ID09PSB1bmRlZmluZWQpIHJldHVybiB1bmRlZmluZWQ7XG4gIGlmICh2ID09PSBudWxsIHx8IHR5cGVvZiB2ICE9PSAnb2JqZWN0JykgcmV0dXJuIEpTT04uc3RyaW5naWZ5KHYpO1xuICBpZiAoQXJyYXkuaXNBcnJheSh2KSkgcmV0dXJuIGBbJHt2Lm1hcChzdGFibGUpLmpvaW4oJywnKX1dYDtcbiAgcmV0dXJuIGB7JHtPYmplY3Qua2V5cyh2KVxuICAgIC5zb3J0KClcbiAgICAubWFwKChrKSA9PiBgJHtKU09OLnN0cmluZ2lmeShrKX06JHtzdGFibGUodltrXSl9YClcbiAgICAuam9pbignLCcpfX1gO1xufTtcblxuLyoqXG4gKiBDb21wYXJlIHR3byBtYW5pZmVzdHMnIGluc3RhbGwgc3VyZmFjZS5cbiAqXG4gKiBSZXR1cm5zIHRoZSBkaWZmZXJlbmNlcyBhcyBgeyBibG9jaywgbmFtZSwgcHVibGlzaGVkLCBsb2NhbCB9YCByb3dzIOKAlCBlbXB0eSBtZWFuc1xuICogcGFyaXR5LiBBIG1pc3NpbmcgYmxvY2sgb24gZWl0aGVyIHNpZGUgaXMgdGhlIGVtcHR5IG9iamVjdCwgbmV2ZXIgYSByZWFzb24gdG8gc2tpcCB0aGVcbiAqIGNvbXBhcmlzb246IGRyb3BwaW5nIGBwZWVyRGVwZW5kZW5jaWVzYCB3aG9sZXNhbGUgaXMgZXhhY3RseSB0aGUga2luZCBvZiBjaGFuZ2UgdGhhdFxuICogbXVzdCBub3QgcmlkZSBhbiB1bmJ1bXBlZCB2ZXJzaW9uLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZGVwZW5kZW5jeURyaWZ0KHB1Ymxpc2hlZCwgbG9jYWwpIHtcbiAgY29uc3Qgcm93cyA9IFtdO1xuICBmb3IgKGNvbnN0IGJsb2NrIG9mIEJMT0NLUykge1xuICAgIGNvbnN0IHAgPSBwdWJsaXNoZWQ/LltibG9ja10gPz8ge307XG4gICAgY29uc3QgbCA9IGxvY2FsPy5bYmxvY2tdID8/IHt9O1xuICAgIGZvciAoY29uc3QgbmFtZSBvZiBbLi4ubmV3IFNldChbLi4uT2JqZWN0LmtleXMocCksIC4uLk9iamVjdC5rZXlzKGwpXSldLnNvcnQoKSkge1xuICAgICAgaWYgKHBbbmFtZV0gIT09IGxbbmFtZV0pIHtcbiAgICAgICAgcm93cy5wdXNoKHsgYmxvY2ssIG5hbWUsIHB1Ymxpc2hlZDogcFtuYW1lXSA/PyAnKGFic2VudCknLCBsb2NhbDogbFtuYW1lXSA/PyAnKGFic2VudCknIH0pO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICBmb3IgKGNvbnN0IGZpZWxkIG9mIEZJRUxEUykge1xuICAgIGNvbnN0IHAgPSBzdGFibGUocHVibGlzaGVkPy5bZmllbGRdKTtcbiAgICBjb25zdCBsID0gc3RhYmxlKGxvY2FsPy5bZmllbGRdKTtcbiAgICBpZiAocCAhPT0gbCkgcm93cy5wdXNoKHsgYmxvY2s6ICcocm9vdCknLCBuYW1lOiBmaWVsZCwgcHVibGlzaGVkOiBwID8/ICcoYWJzZW50KScsIGxvY2FsOiBsID8/ICcoYWJzZW50KScgfSk7XG4gIH1cbiAgcmV0dXJuIHJvd3M7XG59XG5cbi8qKlxuICogQ29tcGFyZSB0d28gcGFja2VkIHBheWxvYWRzLCBwZXIgZW50cnkuXG4gKlxuICogVGFrZXMgdHdvIGBNYXA8c3RyaW5nLCBzdHJpbmc+YCBvZiBwYWNrYWdlLXJlbGF0aXZlIHBhdGgg4oaSIGNvbnRlbnQgZGlnZXN0LCBhc1xuICogYGVudHJ5RGlnZXN0c2AgcmV0dXJucy4gUmV0dXJucyB0aGUgZGlmZmVyZW5jZXMgYXMgYHsgcGF0aCwgcHVibGlzaGVkLCBsb2NhbCB9YCByb3dzIOKAlFxuICogZW1wdHkgbWVhbnMgcGFyaXR5LiBBIHBhdGggb24gb25lIHNpZGUgb25seSBpcyBhIHJvdyByZWFkaW5nIGAoYWJzZW50KWAgb24gdGhlIG90aGVyLFxuICogaW4gYm90aCBkaXJlY3Rpb25zOiA4MGZmMDc4IGJvdGggY2hhbmdlZCBhbmQgYWRkZWQgZmlsZXMsIGFuZCBhbiBhZGRlZC1vbmx5IGNoYW5nZVxuICogbXVzdCBub3QgYmUgc2lsZW50IChSMy03NTEpLlxuICovXG5leHBvcnQgZnVuY3Rpb24gcGF5bG9hZERyaWZ0KHB1Ymxpc2hlZCwgbG9jYWwpIHtcbiAgY29uc3Qgcm93cyA9IFtdO1xuICBmb3IgKGNvbnN0IHBhdGggb2YgWy4uLm5ldyBTZXQoWy4uLnB1Ymxpc2hlZC5rZXlzKCksIC4uLmxvY2FsLmtleXMoKV0pXS5zb3J0KCkpIHtcbiAgICBjb25zdCBwID0gcHVibGlzaGVkLmdldChwYXRoKTtcbiAgICBjb25zdCBsID0gbG9jYWwuZ2V0KHBhdGgpO1xuICAgIGlmIChwICE9PSBsKSByb3dzLnB1c2goeyBwYXRoLCBwdWJsaXNoZWQ6IHAgPz8gJyhhYnNlbnQpJywgbG9jYWw6IGwgPz8gJyhhYnNlbnQpJyB9KTtcbiAgfVxuICByZXR1cm4gcm93cztcbn1cblxuLyoqIHNoYTI1NiBvZiBvbmUgZXh0cmFjdGVkIGVudHJ5LCBoZXgg4oCUIHRoZSBwZXItZW50cnkgY29udGVudCBkaWdlc3QuICovXG5mdW5jdGlvbiBmaWxlRGlnZXN0KGFic1BhdGgpIHtcbiAgcmV0dXJuIGNyZWF0ZUhhc2goJ3NoYTI1NicpLnVwZGF0ZShyZWFkRmlsZVN5bmMoYWJzUGF0aCkpLmRpZ2VzdCgnaGV4Jyk7XG59XG5cbi8qKiBXYWxrIGFuIGV4dHJhY3RlZCBwYWNrYWdlIHJvb3QsIHJldHVybmluZyBgTWFwPHJlbGF0aXZlUGF0aCwgZGlnZXN0PmAgKHJlZ3VsYXIgZmlsZXMpLiAqL1xuZnVuY3Rpb24gdHJlZURpZ2VzdHMocm9vdCkge1xuICBjb25zdCBtYXAgPSBuZXcgTWFwKCk7XG4gIGNvbnN0IHdhbGsgPSAocmVsKSA9PiB7XG4gICAgY29uc3QgYWJzID0gcmVsID09PSAnJyA/IHJvb3QgOiBqb2luKHJvb3QsIHJlbCk7XG4gICAgaWYgKHN0YXRTeW5jKGFicykuaXNEaXJlY3RvcnkoKSkge1xuICAgICAgZm9yIChjb25zdCBlbnRyeSBvZiByZWFkZGlyU3luYyhhYnMpKSB3YWxrKHJlbCA9PT0gJycgPyBlbnRyeSA6IGAke3JlbH0vJHtlbnRyeX1gKTtcbiAgICB9IGVsc2UgaWYgKHN0YXRTeW5jKGFicykuaXNGaWxlKCkpIHtcbiAgICAgIG1hcC5zZXQocmVsLCBmaWxlRGlnZXN0KGFicykpO1xuICAgIH1cbiAgfTtcbiAgd2FsaygnJyk7XG4gIHJldHVybiBtYXA7XG59XG5cbi8qKlxuICogVGhlIGltcHVyZSBoYWxmLCBvbmUgZnVuY3Rpb246IGV4dHJhY3Qgb25lIHBhY2tlZCB0YXJiYWxsIGludG8gYSB0ZW1wIGRpcmVjdG9yeSB0aGlzXG4gKiBzY3JpcHQgY3JlYXRlcyBhbmQgcmVtb3ZlcywgYW5kIHJldHVybiBgTWFwPHBhY2thZ2UtcmVsYXRpdmUgcGF0aCwgY29udGVudCBkaWdlc3Q+YC5cbiAqIGB0YXJgIGV4dHJhY3RzIHdpdGggYC0tc3RyaXAtY29tcG9uZW50cyAxYCBzbyB0aGUgYXJjaGl2ZSdzIGBwYWNrYWdlL2AgcHJlZml4IGlzIGdvbmVcbiAqIGFuZCBrZXlzIGFyZSBwYWNrYWdlLXJvb3QtcmVsYXRpdmUgKGBwYWNrYWdlLmpzb25gLCBgc3JjL2xpYi50c2AsIOKApikuXG4gKiBTaGVsbHMgb3V0IHRvIGB0YXIgLXh6ZmAgYXMgdGhlIHNjcmlwdCBzaGVsbHMgb3V0IHRvIGBucG1gIOKAlCBubyBuZXcgZGVwZW5kZW5jeS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGVudHJ5RGlnZXN0cyh0YXJiYWxsUGF0aCkge1xuICBjb25zdCBkaXIgPSBta2R0ZW1wU3luYyhqb2luKHRtcGRpcigpLCAncHVibGlzaGVkLXBhcml0eS1wYXlsb2FkLScpKTtcbiAgdHJ5IHtcbiAgICBleGVjRmlsZVN5bmMoJ3RhcicsIFsnLXh6ZicsIHRhcmJhbGxQYXRoLCAnLUMnLCBkaXIsICctLXN0cmlwLWNvbXBvbmVudHMnLCAnMSddLCB7XG4gICAgICBzdGRpbzogWydpZ25vcmUnLCAnaWdub3JlJywgJ3BpcGUnXSxcbiAgICAgIC8vIEJvdW5kZWQgbGlrZSBldmVyeSBvdGhlciBwcm9jZXNzIHRoaXMgc2NyaXB0IHNwYXduczogYSBzdGFsbGVkIGV4dHJhY3Rpb24gbXVzdFxuICAgICAgLy8gbGFuZCBpbiB0aGUgY2Fubm90LWFuc3dlciBjYXRjaCwgbm90IGhhbmcgdGhlIGpvYiAoUjE3KS5cbiAgICAgIHRpbWVvdXQ6IDEyMF8wMDAsXG4gICAgfSk7XG4gICAgcmV0dXJuIHRyZWVEaWdlc3RzKGRpcik7XG4gIH0gZmluYWxseSB7XG4gICAgcm1TeW5jKGRpciwgeyByZWN1cnNpdmU6IHRydWUsIGZvcmNlOiB0cnVlIH0pO1xuICB9XG59XG5cbi8qKlxuICogVGhlIG9uZSB0YXJiYWxsIGluIGEgZGlyZWN0b3J5IGBucG0gcGFja2Agd2FzIHBvaW50ZWQgYXQuIFRocm93biBhcyBpdHMgb3duIGVycm9yIHNvXG4gKiB0aGUgXCJwYWNrZWQgbm90aGluZ1wiIGZhaWx1cmUgaGFzIGEgbmFtZSB0aGUgc2VsZi10ZXN0IGNhbiBwaW4gKFIyKS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIG9ubHlUYXJiYWxsKGRpcikge1xuICBjb25zdCB0YXJiYWxsID0gcmVhZGRpclN5bmMoZGlyKS5maW5kKChmKSA9PiBmLmVuZHNXaXRoKCcudGd6JykpO1xuICBpZiAoIXRhcmJhbGwpIHRocm93IG5ldyBFcnJvcignbnBtIHBhY2sgd3JvdGUgbm8gdGFyYmFsbCcpO1xuICByZXR1cm4gdGFyYmFsbDtcbn1cblxuLyoqXG4gKiBQYWNrIG9uZSBzaWRlIGludG8gYSBmcmVzaCB0ZW1wIGRpcmVjdG9yeSBhbmQgcmV0dXJuIHRoZSB0YXJiYWxsJ3MgcGF0aC4gQm90aCBwYXlsb2FkXG4gKiBzaWRlcyBjb21lIGZyb20gYG5wbSBwYWNrYCBzbyB0aGV5IGFyZSBieSBjb25zdHJ1Y3Rpb24gdGhlIGBmaWxlczpgIHBheWxvYWQsIGFuZCB0aGVcbiAqIHB1Ymxpc2hlZCBzaWRlIHVzZXMgdGhlIHNhbWUgY29kZSBwYXRoIGFzIHRoZSBsb2NhbCBzaWRlIChucG0gZG93bmxvYWRzIHRoZSByZWdpc3RyeVxuICogdGFyYmFsbCBmb3IgYSBgPG5hbWU+QDx2ZXJzaW9uPmAgc3BlYykuIEEgZnJlc2ggZGlyZWN0b3J5IHBlciBzaWRlLCBiZWNhdXNlIHRoZVxuICogcHVibGlzaGVkIHRhcmJhbGwgYW5kIHRoZSBsb2NhbCBwYWNrIGhhdmUgdGhlIFNBTUUgZmlsZW5hbWUgYW5kIHdvdWxkIGNvbGxpZGUuXG4gKi9cbmZ1bmN0aW9uIHBhY2tUYXJiYWxsKHNwZWMsIGN3ZCkge1xuICBjb25zdCBkZXN0ID0gbWtkdGVtcFN5bmMoam9pbih0bXBkaXIoKSwgJ3B1Ymxpc2hlZC1wYXJpdHktcGFjay0nKSk7XG4gIHRyeSB7XG4gICAgZXhlY0ZpbGVTeW5jKCducG0nLCBbJ3BhY2snLCAuLi5zcGVjLCAnLS1wYWNrLWRlc3RpbmF0aW9uJywgZGVzdF0sIHtcbiAgICAgIGN3ZCxcbiAgICAgIGVuY29kaW5nOiAndXRmOCcsXG4gICAgICBzdGRpbzogWydpZ25vcmUnLCAncGlwZScsICdpZ25vcmUnXSxcbiAgICAgIHRpbWVvdXQ6IDEyMF8wMDAsXG4gICAgfSk7XG4gICAgcmV0dXJuIHsgZGlyOiBkZXN0LCB0YXJiYWxsOiBqb2luKGRlc3QsIG9ubHlUYXJiYWxsKGRlc3QpKSB9O1xuICB9IGNhdGNoIChlKSB7XG4gICAgcm1TeW5jKGRlc3QsIHsgcmVjdXJzaXZlOiB0cnVlLCBmb3JjZTogdHJ1ZSB9KTtcbiAgICB0aHJvdyBlO1xuICB9XG59XG5cbi8qKlxuICogVGhlIG9uZSBjYW5ub3QtYW5zd2VyIHNoYXBlLCBzaGFyZWQgYnkgYm90aCBzaXRlcyB0aGF0IGNhbm5vdCBydW4gYSBjb21wYXJpc29uIChSNik6XG4gKiBhIHJlZ2lzdHJ5IHJlYWQgdGhhdCB3b3VsZCBub3QgYW5zd2VyLCBhbmQgYSBwYXlsb2FkIGNvbXBhcmlzb24gdGhhdCBjb3VsZCBub3QgcnVuLlxuICogQm90aCBtZWFuIFwicGFyaXR5IHdhcyBOT1QgY2hlY2tlZFwiLCBib3RoIGFyZSBleGl0IDIsIGFuZCBgLS1vZmZsaW5lLW9rYCBkb3duZ3JhZGVzXG4gKiBPTkxZIHRoaXMgY2FzZSDigJQgbmV2ZXIgYSBkcmlmdCDigJQgd2l0aCBhIGxpbmUgdGhhdCBzYXlzIHRoZSBjb21wYXJpc29uIG5ldmVyIHJhbi5cbiAqL1xuZnVuY3Rpb24gY2Fubm90QW5zd2VyRXhpdChzdWJqZWN0LCByZWFzb24sIG9mZmxpbmVPaykge1xuICBjb25zb2xlLmVycm9yKFxuICAgIG9mZmxpbmVPa1xuICAgICAgPyBg4pqgIGNvdWxkIG5vdCAke3N1YmplY3R9ICgke3JlYXNvbn0pIOKAlCBwYXJpdHkgd2FzIE5PVCBjaGVja2VkLiBgICtcbiAgICAgICAgICBgTm90IGZhaWxpbmcgdGhlIGJ1aWxkICgtLW9mZmxpbmUtb2spOyB0aGUgcHVibGlzaCBqb2IgY2hlY2tzIHRoaXMgc3RyaWN0bHkuYFxuICAgICAgOiBg4pyXIGNhbm5vdCAke3N1YmplY3R9ICgke3JlYXNvbn0pIOKAlCBub3QgYW5zd2VyaW5nIGlzIG5vdCBhIHBhc3MuYCxcbiAgKTtcbiAgcmV0dXJuIG9mZmxpbmVPayA/IDAgOiAyO1xufVxuXG4vKipcbiAqIFdoYXQgdGhlIHJlZ2lzdHJ5J3MgYW5zd2VyIE1FQU5TIOKAlCBwdXJlLCBzbyBldmVyeSBicmFuY2ggaXMgdGVzdGFibGUgd2l0aG91dCBhXG4gKiBuZXR3b3JrLiBgbnBtIHZpZXcgPHNwZWM+IOKApiAtLWpzb25gIGhhcyB0aHJlZSBzaGFwZXMgd29ydGggdGVsbGluZyBhcGFydCwgYW5kIHRoZVxuICogZmlyc3QgdHdvIGJvdGggZXhpdCBub24temVybywgd2hpY2ggaXMgd2h5IHRoZSBleGl0IGNvZGUgYWxvbmUgaXMgbm90IHRoZSBhbnN3ZXI6XG4gKlxuICogIC0gKiphYnNlbnQqKiDigJQgdGhlIHZlcnNpb24gaXMgbm90IHB1Ymxpc2hlZC4gbnBtIHByaW50cyBge1wiZXJyb3JcIjp7XCJjb2RlXCI6XCJFNDA0XCJ9fWBcbiAqICAgIHRvIFNURE9VVCBhbmQgZXhpdHMgbm9uLXplcm8uIFRoZXJlIGlzIG5vdGhpbmcgdG8gY29tcGFyZSwgYW5kIG9uIGEgcHVsbCByZXF1ZXN0XG4gKiAgICB0aGlzIGlzIHRoZSBvcmRpbmFyeSBzdGF0ZSwgc28gaXQgaXMgYSBwYXNzLlxuICogIC0gKip1bnJlYWRhYmxlKiog4oCUIG5vIG5ldHdvcmssIGEgcHJpdmF0ZS1yZWdpc3RyeSBhdXRoIGZhaWx1cmUsIGEgbWFsZm9ybWVkIHJlcGx5LlxuICogICAgTmV2ZXIgYSBwYXNzIG9uIGl0cyBvd246IHRoZSBwdWJsaXNoIGpvYiBvbmx5IHJlYWNoZXMgdGhpcyBvbmNlIGBucG0gdmlld2AgaGFzXG4gKiAgICBhbHJlYWR5IHNhaWQgdGhlIHZlcnNpb24gRVhJU1RTLCBzbyBmYWlsaW5nIHRvIHJlYWQgaXQgdGhlcmUgaXMgYSByZWFsIHByb2JsZW0uXG4gKiAgLSAqKnB1Ymxpc2hlZCoqIOKAlCBhIEpTT04gb2JqZWN0IG9mIHRoZSByZXF1ZXN0ZWQgZmllbGRzLiBFTVBUWSBzdGRvdXQgaXMgdGhpcyBjYXNlXG4gKiAgICB0b28sIGFuZCBtZWFucyBhIG1hbmlmZXN0IGRlY2xhcmluZyBub25lIG9mIHRoZW0uXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjbGFzc2lmeVJlZ2lzdHJ5UmVwbHkoeyBzdGRvdXQsIGZhaWxlZCB9KSB7XG4gIGNvbnN0IHRleHQgPSAoc3Rkb3V0ID8/ICcnKS50cmltKCk7XG4gIGlmICh0ZXh0ID09PSAnJykgcmV0dXJuIGZhaWxlZCA/IHsga2luZDogJ3VucmVhZGFibGUnLCByZWFzb246ICdlbXB0eSByZXBseScgfSA6IHsga2luZDogJ3B1Ymxpc2hlZCcsIG1hbmlmZXN0OiB7fSB9O1xuICBsZXQgcGFyc2VkO1xuICB0cnkge1xuICAgIHBhcnNlZCA9IEpTT04ucGFyc2UodGV4dCk7XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiB7IGtpbmQ6ICd1bnJlYWRhYmxlJywgcmVhc29uOiAncmVwbHkgd2FzIG5vdCBKU09OJyB9O1xuICB9XG4gIGlmIChwYXJzZWQgJiYgdHlwZW9mIHBhcnNlZCA9PT0gJ29iamVjdCcgJiYgcGFyc2VkLmVycm9yKSB7XG4gICAgcmV0dXJuIHBhcnNlZC5lcnJvci5jb2RlID09PSAnRTQwNCdcbiAgICAgID8geyBraW5kOiAnYWJzZW50JyB9XG4gICAgICA6IHsga2luZDogJ3VucmVhZGFibGUnLCByZWFzb246IHBhcnNlZC5lcnJvci5zdW1tYXJ5ID8/IHBhcnNlZC5lcnJvci5jb2RlID8/ICdyZWdpc3RyeSBlcnJvcicgfTtcbiAgfVxuICBpZiAoIXBhcnNlZCB8fCB0eXBlb2YgcGFyc2VkICE9PSAnb2JqZWN0JyB8fCBBcnJheS5pc0FycmF5KHBhcnNlZCkpIHtcbiAgICByZXR1cm4geyBraW5kOiAndW5yZWFkYWJsZScsIHJlYXNvbjogJ3JlcGx5IHdhcyBub3QgYW4gb2JqZWN0JyB9O1xuICB9XG4gIHJldHVybiB7IGtpbmQ6ICdwdWJsaXNoZWQnLCBtYW5pZmVzdDogcGFyc2VkIH07XG59XG5cbmZ1bmN0aW9uIHNlbGZUZXN0KCkge1xuICBsZXQgb2sgPSAwO1xuICBsZXQgdG90YWwgPSAwO1xuICBjb25zdCBjaGVjayA9IChsYWJlbCwgY29uZCkgPT4ge1xuICAgIHRvdGFsICs9IDE7XG4gICAgaWYgKGNvbmQpIG9rICs9IDE7XG4gICAgY29uc29sZS5sb2coYCR7Y29uZCA/ICdQQVNTJyA6ICdGQUlMJ30gICR7bGFiZWx9YCk7XG4gIH07XG4gIGNvbnN0IGRlcCA9IChvKSA9PiAoeyBkZXBlbmRlbmNpZXM6IG8gfSk7XG5cbiAgLy8g4pSA4pSAIHRoZSBjb21wYXJpc29uIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICBjaGVjaygnaWRlbnRpY2FsIG1hbmlmZXN0cyBoYXZlIG5vIGRyaWZ0JywgZGVwZW5kZW5jeURyaWZ0KGRlcCh7IGE6ICcxLjAuMCcgfSksIGRlcCh7IGE6ICcxLjAuMCcgfSkpLmxlbmd0aCA9PT0gMCk7XG4gIC8vIFRoZSBSMy01NTYgY2FzZSwgdmVyYmF0aW0uXG4gIGNvbnN0IG1vdmVkID0gZGVwZW5kZW5jeURyaWZ0KGRlcCh7ICdAaW1tZWRpYXRlbHktcnVuL3Nkayc6ICdeMC41Mi4wJyB9KSwgZGVwKHsgJ0BpbW1lZGlhdGVseS1ydW4vc2RrJzogJ14wLjY1LjAnIH0pKTtcbiAgY2hlY2soJ2EgbW92ZWQgcGluIGlzIGRyaWZ0JywgbW92ZWQubGVuZ3RoID09PSAxKTtcbiAgY2hlY2soJ+KApmFuZCBuYW1lcyBib3RoIHNpZGVzJywgbW92ZWRbMF0ucHVibGlzaGVkID09PSAnXjAuNTIuMCcgJiYgbW92ZWRbMF0ubG9jYWwgPT09ICdeMC42NS4wJyk7XG4gIGNoZWNrKCdhbiBBRERFRCBkZXBlbmRlbmN5IGlzIGRyaWZ0JywgZGVwZW5kZW5jeURyaWZ0KGRlcCh7fSksIGRlcCh7IGE6ICcxLjAuMCcgfSkpWzBdPy5sb2NhbCA9PT0gJzEuMC4wJyk7XG4gIGNoZWNrKCdhIFJFTU9WRUQgZGVwZW5kZW5jeSBpcyBkcmlmdCcsIGRlcGVuZGVuY3lEcmlmdChkZXAoeyBhOiAnMS4wLjAnIH0pLCBkZXAoe30pKVswXT8ubG9jYWwgPT09ICcoYWJzZW50KScpO1xuICBjaGVjayhcbiAgICAnYSBwZWVyIG1vdmVkIHdoaWxlIHRoZSBkZXBlbmRlbmN5IHN0YXllZCBpcyBzdGlsbCBkcmlmdCcsXG4gICAgZGVwZW5kZW5jeURyaWZ0KFxuICAgICAgeyBkZXBlbmRlbmNpZXM6IHsgYTogJzEuMC4wJyB9LCBwZWVyRGVwZW5kZW5jaWVzOiB7IGE6ICdeMS4wLjAnIH0gfSxcbiAgICAgIHsgZGVwZW5kZW5jaWVzOiB7IGE6ICcxLjAuMCcgfSwgcGVlckRlcGVuZGVuY2llczogeyBhOiAnXjIuMC4wJyB9IH0sXG4gICAgKS5sZW5ndGggPT09IDEsXG4gICk7XG4gIGNoZWNrKFxuICAgICdkcm9wcGluZyBwZWVyRGVwZW5kZW5jaWVzIGVudGlyZWx5IGlzIGRyaWZ0LCBub3QgYW4gZXhjdXNlIHRvIHNraXAnLFxuICAgIGRlcGVuZGVuY3lEcmlmdCh7IHBlZXJEZXBlbmRlbmNpZXM6IHsgYTogJ14xLjAuMCcgfSB9LCB7fSkubGVuZ3RoID09PSAxLFxuICApO1xuICBjaGVjaygnZGV2RGVwZW5kZW5jaWVzIGFyZSBub3QgY29tcGFyZWQg4oCUIHRoZXkgYXJlIG5vdCBvbiBhIGNvbnN1bWVyIGRpc2snLCBkZXBlbmRlbmN5RHJpZnQoeyBkZXZEZXBlbmRlbmNpZXM6IHsgYTogJzEnIH0gfSwgeyBkZXZEZXBlbmRlbmNpZXM6IHsgYTogJzInIH0gfSkubGVuZ3RoID09PSAwKTtcbiAgY2hlY2soJ29yZGVyIGRvZXMgbm90IG1hdHRlcicsIGRlcGVuZGVuY3lEcmlmdChkZXAoeyBhOiAnMScsIGI6ICcyJyB9KSwgZGVwKHsgYjogJzInLCBhOiAnMScgfSkpLmxlbmd0aCA9PT0gMCk7XG4gIC8vIGBtYWluYC9gZXhwb3J0c2AgZGVjaWRlIHdoaWNoIEZJTEUgYW4gaW1wb3J0IGxhbmRzIG9uLCBzbyB0aGV5IGFyZSB0aGUgc2FtZSBjbGFzcyBvZlxuICAvLyBjaGFuZ2UgYXMgYSBtb3ZlZCBwaW4g4oCUIGFuZCBhbiBleHBvcnRzIG1hcCBpcyBuZXN0ZWQsIGhlbmNlIHRoZSBzdGFibGUgY29tcGFyZS5cbiAgY2hlY2soJ2EgbW92ZWQgYG1haW5gIGlzIGRyaWZ0JywgZGVwZW5kZW5jeURyaWZ0KHsgbWFpbjogJ3NyYy9hLnRzeCcgfSwgeyBtYWluOiAnc3JjL2IudHN4JyB9KS5sZW5ndGggPT09IDEpO1xuICBjaGVjaygnYSBjaGFuZ2VkIGBleHBvcnRzYCBzdWJwYXRoIGlzIGRyaWZ0JywgZGVwZW5kZW5jeURyaWZ0KHsgZXhwb3J0czogeyAnLic6ICcuL2EudHMnIH0gfSwgeyBleHBvcnRzOiB7ICcuJzogJy4vYi50cycgfSB9KS5sZW5ndGggPT09IDEpO1xuICBjaGVjaygnYW4gQURERUQgYGV4cG9ydHNgIHN1YnBhdGggaXMgZHJpZnQnLCBkZXBlbmRlbmN5RHJpZnQoeyBleHBvcnRzOiB7ICcuJzogJy4vYS50cycgfSB9LCB7IGV4cG9ydHM6IHsgJy4nOiAnLi9hLnRzJywgJy4veCc6ICcuL3gudHMnIH0gfSkubGVuZ3RoID09PSAxKTtcbiAgY2hlY2soXG4gICAgJ3RoZSBzYW1lIGV4cG9ydHMgbWFwIGluIGEgZGlmZmVyZW50IGtleSBvcmRlciBpcyBOT1QgZHJpZnQnLFxuICAgIGRlcGVuZGVuY3lEcmlmdCh7IGV4cG9ydHM6IHsgJy4nOiAnLi9hLnRzJywgJy4veCc6ICcuL3gudHMnIH0gfSwgeyBleHBvcnRzOiB7ICcuL3gnOiAnLi94LnRzJywgJy4nOiAnLi9hLnRzJyB9IH0pLmxlbmd0aCA9PT0gMCxcbiAgKTtcblxuICAvLyDilIDilIAgd2hhdCB0aGUgcmVnaXN0cnkncyBhbnN3ZXIgbWVhbnMg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIC8vIFRoZSBFNDA0IGJvZHkgaXMgdGhlIFJFQUwgb25lLCBjYXB0dXJlZCBmcm9tXG4gIC8vIGBucG0gdmlldyBAaW1tZWRpYXRlbHktcnVuL2dyb3ZlQDAuMS4zIGRlcGVuZGVuY2llcyAtLWpzb25gIG9uIDIwMjYtMDktMTUsIHdoZW5cbiAgLy8gMC4xLjMgd2FzIHVucHVibGlzaGVkIOKAlCBub3QgYSBoYW5kLXdyaXR0ZW4gYXBwcm94aW1hdGlvbiBvZiBpdC5cbiAgY29uc3QgZTQwNCA9IEpTT04uc3RyaW5naWZ5KHtcbiAgICBlcnJvcjoge1xuICAgICAgY29kZTogJ0U0MDQnLFxuICAgICAgc3VtbWFyeTogJ05vIG1hdGNoIGZvdW5kIGZvciB2ZXJzaW9uIDAuMS4zJyxcbiAgICAgIGRldGFpbDogXCInQGltbWVkaWF0ZWx5LXJ1bi9ncm92ZUAwLjEuMycgaXMgbm90IGluIHRoaXMgcmVnaXN0cnkuXCIsXG4gICAgfSxcbiAgfSk7XG4gIGNoZWNrKCdhbiBFNDA0IGJvZHkgaXMgQUJTRU5ULCBub3QgdW5yZWFkYWJsZScsIGNsYXNzaWZ5UmVnaXN0cnlSZXBseSh7IHN0ZG91dDogZTQwNCwgZmFpbGVkOiB0cnVlIH0pLmtpbmQgPT09ICdhYnNlbnQnKTtcbiAgLy8gVGhlIHB1Ymxpc2hlZCBib2R5IGlzIGVxdWFsbHkgcmVhbDogdGhlIFNBTUUgYXJndiB0aGlzIHNjcmlwdCBzZW5kcyAoYEJMT0NLU2AgK1xuICAvLyBgRklFTERTYCksIGFnYWluc3QgMC4xLjIsIGNhcHR1cmVkIDIwMjYtMDktMTUuIENhcHR1cmluZyBhIG5hcnJvd2VyIGNvbW1hbmQgd291bGRcbiAgLy8gbWFrZSB0aGUgZml4dHVyZSBzdG9wIGJlaW5nIHRoZSBwcm9kdWNlcidzIG91dHB1dCB0aGUgbW9tZW50IGEgZmllbGQgaXMgYWRkZWQg4oCUXG4gIC8vIGFuZCB3b3VsZCBsZWF2ZSB0aGlzIGNhc2UgZ3JlZW4gd2l0aCB0aGUgd2hvbGUgYG1haW5gL2BleHBvcnRzYCBjb21wYXJpc29uIGRlbGV0ZWQuXG4gIGNvbnN0IHJlYWwgPSBKU09OLnN0cmluZ2lmeSh7XG4gICAgZGVwZW5kZW5jaWVzOiB7ICdAaW1tZWRpYXRlbHktcnVuL21keC1wbHVnaW5zJzogJzAuNC4wJywgJ0BpbW1lZGlhdGVseS1ydW4vc2RrJzogJ14wLjUyLjAnLCByZWFjdDogJ14xOS4yLjUnLCAncmVhY3QtZG9tJzogJ14xOS4yLjUnIH0sXG4gICAgcGVlckRlcGVuZGVuY2llczogeyAnQGltbWVkaWF0ZWx5LXJ1bi9zZGsnOiAnXjAuNTIuMCcsIHJlYWN0OiAnXjE5LjIuNScsICdyZWFjdC1kb20nOiAnXjE5LjIuNScgfSxcbiAgICBtYWluOiAnc3JjL21haW4udHN4JyxcbiAgICBleHBvcnRzOiB7XG4gICAgICAnLic6ICcuL3NyYy9saWIudHMnLFxuICAgICAgJy4vYXBwJzogJy4vc3JjL0FwcC50c3gnLFxuICAgICAgJy4vbWFuaWZlc3QnOiAnLi92aWV3ZXIubWFuaWZlc3QuanNvbicsXG4gICAgICAnLi9jb21wb25lbnRzJzogJy4vc3JjL21keENvbXBvbmVudHMudHMnLFxuICAgICAgJy4vc3R5bGVzLmNzcyc6ICcuL3NyYy9Hcm92ZUFwcC5jc3MnLFxuICAgICAgJy4vdGhlbWUuY3NzJzogJy4vc3JjL2luZGV4LmNzcycsXG4gICAgICAnLi9wYWNrYWdlLmpzb24nOiAnLi9wYWNrYWdlLmpzb24nLFxuICAgIH0sXG4gIH0pO1xuICBjb25zdCBwdWIgPSBjbGFzc2lmeVJlZ2lzdHJ5UmVwbHkoeyBzdGRvdXQ6IHJlYWwsIGZhaWxlZDogZmFsc2UgfSk7XG4gIGNoZWNrKCdhIHJlYWwgcGFja3VtZW50IHJlcGx5IGlzIFBVQkxJU0hFRCcsIHB1Yi5raW5kID09PSAncHVibGlzaGVkJyk7XG4gIC8vIEVYQUNUTFkgdGhlIHRocmVlIHJlYWwgZHJpZnRzLCBhbmQgTk8gYChyb290KWAgcm93OiAwLjEuMidzIGBtYWluYC9gZXhwb3J0c2AgbWF0Y2hcbiAgLy8gdGhpcyB0cmVlLCBzbyBhIHNwdXJpb3VzIHJvb3Qgcm93IHdvdWxkIG1lYW4gdGhlIGNvbXBhcmlzb24gb2YgdGhvc2UgZmllbGRzIGlzIHdyb25nLlxuICBjb25zdCByZWFsUm93cyA9IGRlcGVuZGVuY3lEcmlmdChwdWIubWFuaWZlc3QsIEpTT04ucGFyc2UocmVhZEZpbGVTeW5jKGpvaW4oUk9PVCwgJ3BhY2thZ2UuanNvbicpLCAndXRmOCcpKSk7XG4gIGNoZWNrKFxuICAgICfigKZhbmQgZHJpZnRzIGFnYWluc3QgdGhpcyB0cmVlIGluIEVYQUNUTFkgdGhlIHRocmVlIHBsYWNlcyAwLjEuMiByZWFsbHkgZHJpZnRlZCcsXG4gICAgSlNPTi5zdHJpbmdpZnkocmVhbFJvd3MubWFwKChyKSA9PiBgJHtyLmJsb2NrfS4ke3IubmFtZX1gKSkgPT09XG4gICAgICBKU09OLnN0cmluZ2lmeShbXG4gICAgICAgICdkZXBlbmRlbmNpZXMuQGltbWVkaWF0ZWx5LXJ1bi9tZHgtcGx1Z2lucycsXG4gICAgICAgICdkZXBlbmRlbmNpZXMuQGltbWVkaWF0ZWx5LXJ1bi9zZGsnLFxuICAgICAgICAncGVlckRlcGVuZGVuY2llcy5AaW1tZWRpYXRlbHktcnVuL3NkaycsXG4gICAgICBdKSxcbiAgKTtcbiAgY2hlY2soJ2FuIGFic2VudC1ibG9ja3MgbWFuaWZlc3QgaXMgcHVibGlzaGVkLXdpdGgtbm90aGluZywgbm90IHVucmVhZGFibGUnLCBjbGFzc2lmeVJlZ2lzdHJ5UmVwbHkoeyBzdGRvdXQ6ICcnLCBmYWlsZWQ6IGZhbHNlIH0pLmtpbmQgPT09ICdwdWJsaXNoZWQnKTtcbiAgY2hlY2soJ+KApndoaWNoIHRoZW4gcmVhZHMgZXZlcnkgbG9jYWwgYmxvY2sgYXMgQURERUQnLCBkZXBlbmRlbmN5RHJpZnQoY2xhc3NpZnlSZWdpc3RyeVJlcGx5KHsgc3Rkb3V0OiAnJywgZmFpbGVkOiBmYWxzZSB9KS5tYW5pZmVzdCwgZGVwKHsgYTogJzEnIH0pKS5sZW5ndGggPT09IDEpO1xuICBjaGVjaygnYW4gZW1wdHkgcmVwbHkgdGhhdCBGQUlMRUQgaXMgdW5yZWFkYWJsZScsIGNsYXNzaWZ5UmVnaXN0cnlSZXBseSh7IHN0ZG91dDogJycsIGZhaWxlZDogdHJ1ZSB9KS5raW5kID09PSAndW5yZWFkYWJsZScpO1xuICBjaGVjaygnYSBub24tRTQwNCByZWdpc3RyeSBlcnJvciBpcyB1bnJlYWRhYmxlLCBuZXZlciBhYnNlbnQnLCBjbGFzc2lmeVJlZ2lzdHJ5UmVwbHkoeyBzdGRvdXQ6IEpTT04uc3RyaW5naWZ5KHsgZXJyb3I6IHsgY29kZTogJ0U0MDEnLCBzdW1tYXJ5OiAnYXV0aCcgfSB9KSwgZmFpbGVkOiB0cnVlIH0pLmtpbmQgPT09ICd1bnJlYWRhYmxlJyk7XG4gIGNoZWNrKCdhIG5vbi1KU09OIHJlcGx5IGlzIHVucmVhZGFibGUnLCBjbGFzc2lmeVJlZ2lzdHJ5UmVwbHkoeyBzdGRvdXQ6ICc8aHRtbD41MDI8L2h0bWw+JywgZmFpbGVkOiB0cnVlIH0pLmtpbmQgPT09ICd1bnJlYWRhYmxlJyk7XG4gIGNoZWNrKCdhIEpTT04gQVJSQVkgcmVwbHkgaXMgdW5yZWFkYWJsZSwgbm90IGFuIGVtcHR5IG1hbmlmZXN0JywgY2xhc3NpZnlSZWdpc3RyeVJlcGx5KHsgc3Rkb3V0OiAnW1wiMC4xLjFcIixcIjAuMS4yXCJdJywgZmFpbGVkOiBmYWxzZSB9KS5raW5kID09PSAndW5yZWFkYWJsZScpO1xuXG4gIC8vIOKUgOKUgCB0aGUgcGF5bG9hZCBjb21wYXJpc29uIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICBjb25zdCBtYXAgPSAobykgPT4gbmV3IE1hcChPYmplY3QuZW50cmllcyhvKSk7XG4gIGNoZWNrKCdpZGVudGljYWwgcGF5bG9hZCBNYXBzIGhhdmUgbm8gZHJpZnQnLCBwYXlsb2FkRHJpZnQobWFwKHsgYTogJ2gxJywgYjogJ2gyJyB9KSwgbWFwKHsgYjogJ2gyJywgYTogJ2gxJyB9KSkubGVuZ3RoID09PSAwKTtcbiAgY29uc3QgY2hhbmdlZCA9IHBheWxvYWREcmlmdChtYXAoeyBhOiAnaDEnLCBiOiAnaDInIH0pLCBtYXAoeyBhOiAnaDknLCBiOiAnaDInIH0pKTtcbiAgY2hlY2soJ2EgY2hhbmdlZCBkaWdlc3QgaXMgb25lIHJvdyBuYW1pbmcgdGhlIHBhdGggYW5kIGJvdGggZGlnZXN0cycsIGNoYW5nZWQubGVuZ3RoID09PSAxICYmIGNoYW5nZWRbMF0ucGF0aCA9PT0gJ2EnICYmIGNoYW5nZWRbMF0ucHVibGlzaGVkID09PSAnaDEnICYmIGNoYW5nZWRbMF0ubG9jYWwgPT09ICdoOScpO1xuICBjb25zdCBhZGRlZCA9IHBheWxvYWREcmlmdChtYXAoeyBhOiAnaDEnIH0pLCBtYXAoeyBhOiAnaDEnLCAnc3JjL25ldy50cyc6ICdoMicgfSkpO1xuICBjaGVjaygnYW4gQURERUQgZmlsZSBpcyBhIHJvdywgKGFic2VudCkgb24gdGhlIHB1Ymxpc2hlZCBzaWRlJywgYWRkZWQubGVuZ3RoID09PSAxICYmIGFkZGVkWzBdLnBhdGggPT09ICdzcmMvbmV3LnRzJyAmJiBhZGRlZFswXS5wdWJsaXNoZWQgPT09ICcoYWJzZW50KScgJiYgYWRkZWRbMF0ubG9jYWwgPT09ICdoMicpO1xuICBjb25zdCByZW1vdmVkID0gcGF5bG9hZERyaWZ0KG1hcCh7ICdzcmMvb2xkLnRzJzogJ2gxJyB9KSwgbWFwKHt9KSk7XG4gIGNoZWNrKCdhIFJFTU9WRUQgZmlsZSBpcyBhIHJvdywgKGFic2VudCkgb24gdGhlIGxvY2FsIHNpZGUnLCByZW1vdmVkLmxlbmd0aCA9PT0gMSAmJiByZW1vdmVkWzBdLnBhdGggPT09ICdzcmMvb2xkLnRzJyAmJiByZW1vdmVkWzBdLnB1Ymxpc2hlZCA9PT0gJ2gxJyAmJiByZW1vdmVkWzBdLmxvY2FsID09PSAnKGFic2VudCknKTtcblxuICAvLyBSZWFsIHByb2R1Y2VyOiB0aGUgZml4dHVyZSBNYXBzIGZvciB0aGUgaWRlbnRpY2FsLXRyZWUgY2FzZSBhcmUgYnVpbHQgYnkgcnVubmluZ1xuICAvLyBgZW50cnlEaWdlc3RzYCBvdmVyIGEgdGFyYmFsbCBUSElTIHJlcG8gcGFja3MgcmlnaHQgaGVyZSB0aHJvdWdoIHRoZSBwcm9kdWN0aW9uXG4gIC8vIGBwYWNrVGFyYmFsbGAgcGF0aCDigJQgYSBoYW5kLXR5cGVkIE1hcCB3b3VsZCBzdGF5IGdyZWVuIHdpdGggdGhlIGRpZ2VzdCBmdW5jdGlvblxuICAvLyBkZWxldGVkLCBhbmQgYW4gaW5saW5lIGR1cGxpY2F0ZSBvZiB0aGUgcGFjayBjYWxsIHdvdWxkIHN0YXkgZ3JlZW4gd2l0aFxuICAvLyBgcGFja1RhcmJhbGxgIGRlbGV0ZWQgKFIzLTc1MSwgUjIpLiBObyBgcHJlcGFja2Agc2NyaXB0IGV4aXN0cywgc28gdGhlIHBhY2sgaXNcbiAgLy8gb2ZmbGluZSBhbmQgc2lkZS1lZmZlY3QtZnJlZS5cbiAgY29uc3QgZW1wdHlEaXIgPSBta2R0ZW1wU3luYyhqb2luKHRtcGRpcigpLCAncHVibGlzaGVkLXBhcml0eS1lbXB0eS0nKSk7XG4gIGNvbnN0IHN5bnRoRGlyID0gbWtkdGVtcFN5bmMoam9pbih0bXBkaXIoKSwgJ3B1Ymxpc2hlZC1wYXJpdHktc3ludGgtJykpO1xuICBsZXQgcGFja2VkO1xuICB0cnkge1xuICAgIGxldCB0aHJldyA9IG51bGw7XG4gICAgdHJ5IHtcbiAgICAgIG9ubHlUYXJiYWxsKGVtcHR5RGlyKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICB0aHJldyA9IGU7XG4gICAgfVxuICAgIGNoZWNrKCdvbmx5VGFyYmFsbCByZWZ1c2VzIGEgZGlyZWN0b3J5IHdpdGggbm8gdGFyYmFsbCwgYnkgbmFtZScsIHRocmV3IGluc3RhbmNlb2YgRXJyb3IgJiYgdGhyZXcubWVzc2FnZSA9PT0gJ25wbSBwYWNrIHdyb3RlIG5vIHRhcmJhbGwnKTtcblxuICAgIC8vIFRoZSBkaWdlc3Qgd2FsaywgcGlubmVkIGFnYWluc3QgRElSRUNUIGhhc2hlcyBvZiBhIHN5bnRoZXRpYyB0cmVlIChhIGZpbGUsIGFuZCBhXG4gICAgLy8gZmlsZSBvbmUgbGV2ZWwgZG93bik6IGEgYGZpbGVEaWdlc3RgIHRoYXQgcmV0dXJuZWQgYSBjb25zdGFudCwgb3IgYSBgdHJlZURpZ2VzdHNgXG4gICAgLy8gdGhhdCBza2lwcGVkIHN1YmRpcmVjdG9yaWVzLCB3b3VsZCBvdGhlcndpc2UgbGVhdmUgZXZlcnkgcmVhbC1wYWNrIGNhc2UgZ3JlZW4g4oCUXG4gICAgLy8gdGhlIGdhdGUgY291bGQgc2lsZW50bHkgbmV2ZXIgZmlyZSwgd2hpY2ggaXMgdGhlIGV4YWN0IGZhaWx1cmUgUjMtNzUxIGNsb3Nlcy5cbiAgICBta2RpclN5bmMoam9pbihzeW50aERpciwgJ3BhY2thZ2UnLCAnc3ViJyksIHsgcmVjdXJzaXZlOiB0cnVlIH0pO1xuICAgIHdyaXRlRmlsZVN5bmMoam9pbihzeW50aERpciwgJ3BhY2thZ2UnLCAnYS50eHQnKSwgJ2FscGhhJyk7XG4gICAgd3JpdGVGaWxlU3luYyhqb2luKHN5bnRoRGlyLCAncGFja2FnZScsICdzdWInLCAnYi50eHQnKSwgJ2JldGEnKTtcbiAgICBleGVjRmlsZVN5bmMoJ3RhcicsIFsnLWN6ZicsIGpvaW4oc3ludGhEaXIsICdzeW50aC50Z3onKSwgJy1DJywgc3ludGhEaXIsICdwYWNrYWdlJ10sIHtcbiAgICAgIHN0ZGlvOiBbJ2lnbm9yZScsICdpZ25vcmUnLCAncGlwZSddLFxuICAgICAgdGltZW91dDogMzBfMDAwLFxuICAgIH0pO1xuICAgIGNvbnN0IHN5bnRoID0gZW50cnlEaWdlc3RzKGpvaW4oc3ludGhEaXIsICdzeW50aC50Z3onKSk7XG4gICAgY29uc3QgZGlyZWN0ID0gKHApID0+IGNyZWF0ZUhhc2goJ3NoYTI1NicpLnVwZGF0ZShyZWFkRmlsZVN5bmMoam9pbihzeW50aERpciwgJ3BhY2thZ2UnLCBwKSkpLmRpZ2VzdCgnaGV4Jyk7XG4gICAgY2hlY2soXG4gICAgICAnZW50cnlEaWdlc3RzIHJldHVybnMgdGhlIGV4YWN0IGNvbnRlbnQgZGlnZXN0cywgbmVzdGVkIGtleXMgaW5jbHVkZWQnLFxuICAgICAgc3ludGguc2l6ZSA9PT0gMiAmJiBzeW50aC5nZXQoJ2EudHh0JykgPT09IGRpcmVjdCgnYS50eHQnKSAmJiBzeW50aC5nZXQoJ3N1Yi9iLnR4dCcpID09PSBkaXJlY3QoJ3N1Yi9iLnR4dCcpLFxuICAgICk7XG5cbiAgICBwYWNrZWQgPSBwYWNrVGFyYmFsbChbXSwgUk9PVCk7XG4gICAgY29uc3QgcmVhbCA9IGVudHJ5RGlnZXN0cyhwYWNrZWQudGFyYmFsbCk7XG4gICAgY2hlY2soJ2VudHJ5RGlnZXN0cyByZWFkcyBhIHJlYWwgcGFjayBvZiB0aGlzIHJlcG8gKG5vbi1lbXB0eSwgcGFja2FnZS5qc29uIGluY2x1ZGVkKScsIHJlYWwuc2l6ZSA+IDAgJiYgcmVhbC5oYXMoJ3BhY2thZ2UuanNvbicpKTtcbiAgICBjaGVjaygn4oCmYW5kIHRoZSBpZGVudGljYWwtdHJlZSBjYXNlIGhhcyBubyBkcmlmdCcsIHBheWxvYWREcmlmdChyZWFsLCByZWFsKS5sZW5ndGggPT09IDApO1xuICAgIGNvbnN0IGZpcnN0UGF0aCA9IFsuLi5yZWFsLmtleXMoKV1bMF07XG4gICAgY29uc3QgbXV0YXRlZCA9IG5ldyBNYXAocmVhbCk7XG4gICAgbXV0YXRlZC5zZXQoZmlyc3RQYXRoLCAnZGVhZGJlZWYnKTtcbiAgICBjb25zdCBtdXRhdGVkUm93cyA9IHBheWxvYWREcmlmdChyZWFsLCBtdXRhdGVkKTtcbiAgICBjaGVjaygn4oCmYSBvbmUtZmlsZSBtdXRhdGlvbiBhZ2FpbnN0IHRoZSByZWFsIE1hcCBpcyBleGFjdGx5IG9uZSByb3cnLCBtdXRhdGVkUm93cy5sZW5ndGggPT09IDEgJiYgbXV0YXRlZFJvd3NbMF0ucGF0aCA9PT0gZmlyc3RQYXRoICYmIG11dGF0ZWRSb3dzWzBdLnB1Ymxpc2hlZCA9PT0gcmVhbC5nZXQoZmlyc3RQYXRoKSAmJiBtdXRhdGVkUm93c1swXS5sb2NhbCA9PT0gJ2RlYWRiZWVmJyk7XG4gICAgY2hlY2soJ+KApmFuZCB0aGUgcGFjayBkaXJlY3RvcnkgaXQgbWFkZSBpcyB0aGUgb25lIGBvbmx5VGFyYmFsbGAgZmluZHMnLCBvbmx5VGFyYmFsbChwYWNrZWQuZGlyKSA9PT0gcGFja2VkLnRhcmJhbGwuc3BsaXQoJy8nKS5wb3AoKSk7XG5cbiAgICAvLyBUaGUgb25lIGRvd25ncmFkZSBwb2xpY3ksIGNhbGxlZCBkaXJlY3RseTogc3RyaWN0IGlzIGV4aXQgMiB3aXRoIHRoZSBob25lc3QgbGluZSxcbiAgICAvLyBgLS1vZmZsaW5lLW9rYCBpcyBleGl0IDAgYW5kIHNheXMgdGhlIGNvbXBhcmlzb24gbmV2ZXIgcmFuLiBBIGZsaXBwZWQgdGVybmFyeSBvciBhXG4gICAgLy8gcmUtcGFzdGVkIG1lc3NhZ2UgdHVybnMgdGhlc2UgcmVkIChyb3VuZC0yIFIyKS5cbiAgICBjb25zdCBzZWVuID0gW107XG4gICAgY29uc3QgcmVhbEVycm9yID0gY29uc29sZS5lcnJvcjtcbiAgICBjb25zb2xlLmVycm9yID0gKG0pID0+IHNlZW4ucHVzaChtKTtcbiAgICBjb25zdCBzdHJpY3RDb2RlID0gY2Fubm90QW5zd2VyRXhpdCgncmVhZCBYIGZyb20gdGhlIHJlZ2lzdHJ5JywgJ2Jvb20nLCBmYWxzZSk7XG4gICAgY29uc3Qgb2ZmbGluZUNvZGUgPSBjYW5ub3RBbnN3ZXJFeGl0KCdyZWFkIFggZnJvbSB0aGUgcmVnaXN0cnknLCAnYm9vbScsIHRydWUpO1xuICAgIGNvbnNvbGUuZXJyb3IgPSByZWFsRXJyb3I7XG4gICAgY2hlY2soXG4gICAgICAnY2Fubm90QW5zd2VyRXhpdDogc3RyaWN0IGlzIDIgYW5kIG5hbWVzIHdoYXQgZGlkIG5vdCBhbnN3ZXI7IC0tb2ZmbGluZS1vayBpcyAwIGFuZCBzYXlzIHBhcml0eSB3YXMgTk9UIGNoZWNrZWQnLFxuICAgICAgc3RyaWN0Q29kZSA9PT0gMiAmJlxuICAgICAgICBzZWVuWzBdLmluY2x1ZGVzKCdyZWFkIFggZnJvbSB0aGUgcmVnaXN0cnknKSAmJlxuICAgICAgICBzZWVuWzBdLmluY2x1ZGVzKCdub3QgYW5zd2VyaW5nIGlzIG5vdCBhIHBhc3MnKSAmJlxuICAgICAgICBvZmZsaW5lQ29kZSA9PT0gMCAmJlxuICAgICAgICBzZWVuWzFdLmluY2x1ZGVzKCdwYXJpdHkgd2FzIE5PVCBjaGVja2VkJyksXG4gICAgKTtcbiAgfSBmaW5hbGx5IHtcbiAgICBmb3IgKGNvbnN0IGRpciBvZiBbZW1wdHlEaXIsIHN5bnRoRGlyLCBwYWNrZWQ/LmRpcl0pIHtcbiAgICAgIGlmIChkaXIpIHJtU3luYyhkaXIsIHsgcmVjdXJzaXZlOiB0cnVlLCBmb3JjZTogdHJ1ZSB9KTtcbiAgICB9XG4gIH1cblxuICBjb25zb2xlLmxvZyhgXFxuJHtva30vJHt0b3RhbH0gc2VsZi10ZXN0IGNhc2VzLmApO1xuICByZXR1cm4gb2sgPT09IHRvdGFsID8gMCA6IDE7XG59XG5cbmlmIChwcm9jZXNzLmFyZ3YuaW5jbHVkZXMoJy0tc2VsZi10ZXN0JykpIHByb2Nlc3MuZXhpdChzZWxmVGVzdCgpKTtcblxuY29uc3Qgb2ZmbGluZU9rID0gcHJvY2Vzcy5hcmd2LmluY2x1ZGVzKCctLW9mZmxpbmUtb2snKTtcbmNvbnN0IGxvY2FsID0gSlNPTi5wYXJzZShyZWFkRmlsZVN5bmMoam9pbihST09ULCAncGFja2FnZS5qc29uJyksICd1dGY4JykpO1xuY29uc3Qgc3BlYyA9IGAke2xvY2FsLm5hbWV9QCR7bG9jYWwudmVyc2lvbn1gO1xuXG5sZXQgc3Rkb3V0ID0gJyc7XG5sZXQgZmFpbGVkID0gZmFsc2U7XG50cnkge1xuICBzdGRvdXQgPSBleGVjRmlsZVN5bmMoJ25wbScsIFsndmlldycsIHNwZWMsIC4uLkJMT0NLUywgLi4uRklFTERTLCAnLS1qc29uJ10sIHtcbiAgICBlbmNvZGluZzogJ3V0ZjgnLFxuICAgIHN0ZGlvOiBbJ2lnbm9yZScsICdwaXBlJywgJ2lnbm9yZSddLFxuICAgIC8vIFRoZSByZXBvJ3Mgb25seSBvdXRib3VuZCBjYWxsLiBXaXRob3V0IGEgYm91bmQsIGEgaHVuZyByZWdpc3RyeSByZWFkIGhvbGRzIHRoZVxuICAgIC8vIGpvYiB0byBpdHMgY2VpbGluZzsgYSBraWxsIGxhbmRzIGluIHRoZSBjYXRjaCBiZWxvdyBhbmQgcmVhZHMgYXMgdW5yZWFkYWJsZS5cbiAgICB0aW1lb3V0OiAzMF8wMDAsXG4gIH0pO1xufSBjYXRjaCAoZSkge1xuICBmYWlsZWQgPSB0cnVlO1xuICBzdGRvdXQgPSB0eXBlb2YgZT8uc3Rkb3V0ID09PSAnc3RyaW5nJyA/IGUuc3Rkb3V0IDogJyc7XG59XG5cbmNvbnN0IHJlcGx5ID0gY2xhc3NpZnlSZWdpc3RyeVJlcGx5KHsgc3Rkb3V0LCBmYWlsZWQgfSk7XG5cbmlmIChyZXBseS5raW5kID09PSAnYWJzZW50Jykge1xuICBjb25zb2xlLmxvZyhg4pyTICR7c3BlY30gaXMgbm90IHB1Ymxpc2hlZCB5ZXQg4oCUIG5vdGhpbmcgdG8gY29tcGFyZS5gKTtcbiAgcHJvY2Vzcy5leGl0KDApO1xufVxuXG5pZiAocmVwbHkua2luZCA9PT0gJ3VucmVhZGFibGUnKSB7XG4gIC8vIFVuZGVyIGAtLW9mZmxpbmUtb2tgIHRoaXMgSVMgYSBwYXNzIOKAlCB0aGUgYnVpbGQgaXMgZGVsaWJlcmF0ZWx5IG5vdCBmYWlsZWQgZm9yIGFcbiAgLy8gcmVnaXN0cnkgdGhhdCB3b3VsZCBub3QgYW5zd2VyIOKAlCBhbmQgYSBsb2cgdGhhdCBzYXlzIFwibm90IGFuc3dlcmluZyBpcyBub3QgYSBwYXNzXCJcbiAgLy8gYmVzaWRlIGEgemVybyBleGl0IHRlbGxzIGEgcmVhZGVyIHRoZSBvcHBvc2l0ZSBvZiB3aGF0IGhhcHBlbmVkLCBhbmQgaGlkZXMgdGhhdCB0aGVcbiAgLy8gY29tcGFyaXNvbiBuZXZlciByYW4gYXQgYWxsLiBUaGUgb25lIGNhbm5vdC1hbnN3ZXIgc2hhcGUgbGl2ZXMgaW4gYGNhbm5vdEFuc3dlckV4aXRgLlxuICBwcm9jZXNzLmV4aXQoY2Fubm90QW5zd2VyRXhpdChgcmVhZCAke3NwZWN9IGZyb20gdGhlIHJlZ2lzdHJ5YCwgcmVwbHkucmVhc29uLCBvZmZsaW5lT2spKTtcbn1cblxuY29uc3Qgcm93cyA9IGRlcGVuZGVuY3lEcmlmdChyZXBseS5tYW5pZmVzdCwgbG9jYWwpO1xuaWYgKHJvd3MubGVuZ3RoID4gMCkge1xuICBjb25zb2xlLmVycm9yKFxuICAgIGA6OmVycm9yOjoke3NwZWN9IGlzIGFscmVhZHkgcHVibGlzaGVkLCBhbmQgdGhpcyB0cmVlIGRlY2xhcmVzIGEgRElGRkVSRU5UIGluc3RhbGwgc3VyZmFjZS4gYCArXG4gICAgICBgUHVibGlzaGluZyB3b3VsZCBiZSBza2lwcGVkLCBzbyB0aGUgY2hhbmdlIHdvdWxkIG5ldmVyIHJlYWNoIG5wbSDigJQgYnVtcCB0aGUgdmVyc2lvbi5gLFxuICApO1xuICBmb3IgKGNvbnN0IHIgb2Ygcm93cykge1xuICAgIGNvbnNvbGUuZXJyb3IoYCAgJHtyLmJsb2NrfS4ke3IubmFtZX06IHB1Ymxpc2hlZCAke3IucHVibGlzaGVkfSDCtyBoZXJlICR7ci5sb2NhbH1gKTtcbiAgfVxuICBwcm9jZXNzLmV4aXQoMSk7XG59XG5cbi8vIE1hbmlmZXN0IGF0IHBhcml0eSDigJQgdGhlIGV4YWN0IGhvbGUgUjMtNzUxIGNsb3NlZDogYSBzb3VyY2Utb25seSBjaGFuZ2UgdW5kZXIgYW5cbi8vIGFscmVhZHktcHVibGlzaGVkIHZlcnNpb24gcGFzc2VzIGV2ZXJ5dGhpbmcgYWJvdmUgd2hpbGUgZXZlcnkgY29uc3VtZXIga2VlcHMgdGhlIG9sZFxuLy8gYnl0ZXMuIENvbXBhcmUgdGhlIHBhY2tlZCBwYXlsb2FkcywgYHBhY2thZ2UuanNvbmAgaW5jbHVkZWQuXG4vL1xuLy8gTm8gYHByb2Nlc3MuZXhpdGAgaW5zaWRlIHRoZSB0cnk6IGl0IHRlcm1pbmF0ZXMgd2l0aG91dCB1bndpbmRpbmcsIHNvIHRoZSBgZmluYWxseWBcbi8vIHRoYXQgcmVtb3ZlcyB0aGUgcGFjayBkaXJlY3RvcmllcyB3b3VsZCBuZXZlciBydW4gYW5kIGV2ZXJ5IHN0cmljdCBjb21wYXJpc29uIHdvdWxkXG4vLyBsZWFrIGJvdGguIEV2ZXJ5IHBhdGggc2V0cyBgZXhpdENvZGVgIGFuZCBmYWxscyB0aHJvdWdoIHRvIHRoZSBvbmUgZXhpdCBhdCB0aGUgZW5kLlxubGV0IHB1Ymxpc2hlZFBhY2s7XG5sZXQgbG9jYWxQYWNrO1xubGV0IGV4aXRDb2RlID0gMDtcbnRyeSB7XG4gIHB1Ymxpc2hlZFBhY2sgPSBwYWNrVGFyYmFsbChbc3BlY10sIFJPT1QpO1xuICBsb2NhbFBhY2sgPSBwYWNrVGFyYmFsbChbXSwgUk9PVCk7XG4gIGNvbnN0IHBheWxvYWRSb3dzID0gcGF5bG9hZERyaWZ0KGVudHJ5RGlnZXN0cyhwdWJsaXNoZWRQYWNrLnRhcmJhbGwpLCBlbnRyeURpZ2VzdHMobG9jYWxQYWNrLnRhcmJhbGwpKTtcbiAgaWYgKHBheWxvYWRSb3dzLmxlbmd0aCA9PT0gMCkge1xuICAgIGNvbnNvbGUubG9nKGDinJMgJHtzcGVjfSBvbiBucG0gZGVjbGFyZXMgdGhlIHNhbWUgaW5zdGFsbCBzdXJmYWNlIGFuZCBzaGlwcyB0aGUgc2FtZSBwYXlsb2FkIGFzIHRoaXMgdHJlZS5gKTtcbiAgfSBlbHNlIHtcbiAgICBjb25zb2xlLmVycm9yKFxuICAgICAgYDo6ZXJyb3I6OiR7c3BlY30gaXMgYWxyZWFkeSBwdWJsaXNoZWQsIGFuZCB0aGlzIHRyZWUncyBwYWNrZWQgUEFZTE9BRCBkaWZmZXJzIGZyb20gdGhlIHB1Ymxpc2hlZCBwYWNrYWdlIGAgK1xuICAgICAgICBgaW4gJHtwYXlsb2FkUm93cy5sZW5ndGh9IGZpbGUocykuIFB1Ymxpc2hpbmcgd291bGQgYmUgc2tpcHBlZCwgc28gdGhlIGNoYW5nZSB3b3VsZCBuZXZlciByZWFjaCBucG0g4oCUIGJ1bXAgdGhlIHZlcnNpb24uYCxcbiAgICApO1xuICAgIGZvciAoY29uc3QgciBvZiBwYXlsb2FkUm93cy5zbGljZSgwLCAyMCkpIHtcbiAgICAgIGNvbnN0IHNob3J0ID0gKGQpID0+IChkID09PSAnKGFic2VudCknID8gZCA6IGAke2Quc2xpY2UoMCwgMTIpfeKApmApO1xuICAgICAgY29uc29sZS5lcnJvcihgICAke3IucGF0aH06IHB1Ymxpc2hlZCAke3Nob3J0KHIucHVibGlzaGVkKX0gwrcgaGVyZSAke3Nob3J0KHIubG9jYWwpfWApO1xuICAgIH1cbiAgICBpZiAocGF5bG9hZFJvd3MubGVuZ3RoID4gMjApIGNvbnNvbGUuZXJyb3IoYCAg4oCmYW5kICR7cGF5bG9hZFJvd3MubGVuZ3RoIC0gMjB9IG1vcmUuYCk7XG4gICAgZXhpdENvZGUgPSAxO1xuICB9XG59IGNhdGNoIChlKSB7XG4gIC8vIFRoZSBwYXlsb2FkIGNvbXBhcmlzb24gY291bGQgbm90IFJVTiDigJQgdGhlIHNhbWUgY2xhc3MgYXMgYW4gdW5yZWFkYWJsZSByZWdpc3RyeSwgYW5kXG4gIC8vIG5ldmVyIHJlcG9ydGVkIGFzIGEgcGFzcy4gRG93bmdyYWRlZCBvbmx5IGJ5IC0tb2ZmbGluZS1vaywgbGlrZSB0aGF0IGNhc2UuXG4gIGV4aXRDb2RlID0gY2Fubm90QW5zd2VyRXhpdChcbiAgICAnY29tcGFyZSB0aGUgcGFja2VkIHBheWxvYWQnLFxuICAgIGUgaW5zdGFuY2VvZiBFcnJvciA/IGUubWVzc2FnZSA6IFN0cmluZyhlKSxcbiAgICBvZmZsaW5lT2ssXG4gICk7XG59IGZpbmFsbHkge1xuICBmb3IgKGNvbnN0IHBhY2sgb2YgW3B1Ymxpc2hlZFBhY2ssIGxvY2FsUGFja10pIHtcbiAgICBpZiAocGFjaykgcm1TeW5jKHBhY2suZGlyLCB7IHJlY3Vyc2l2ZTogdHJ1ZSwgZm9yY2U6IHRydWUgfSk7XG4gIH1cbn1cbnByb2Nlc3MuZXhpdChleGl0Q29kZSk7XG4iXSwibWFwcGluZ3MiOiJBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQXBEQTs7QUFBQUEsTUFBQSxDQUFBQyxjQUFBLENBQUFDLE9BQUE7RUFBQUMsS0FBQTtBQUFBO0FBQUFELE9BQUEsQ0FBQUUscUJBQUEsR0FBQUEscUJBQUE7QUFBQUYsT0FBQSxDQUFBRyxlQUFBLEdBQUFBLGVBQUE7QUFBQUgsT0FBQSxDQUFBSSxZQUFBLEdBQUFBLFlBQUE7QUFBQUosT0FBQSxDQUFBSyxXQUFBLEdBQUFBLFdBQUE7QUFBQUwsT0FBQSxDQUFBTSxZQUFBLEdBQUFBLFlBQUE7QUFBQUMsT0FBQTtBQUFBQSxPQUFBO0FBQUFBLE9BQUE7QUFxREEsSUFBQUMsT0FBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsU0FBQSxHQUFBRixPQUFBO0FBQ0EsSUFBQUcsT0FBQSxHQUFBSCxPQUFBO0FBQ0EsSUFBQUksUUFBQSxHQUFBSixPQUFBO0FBQ0EsSUFBQUssV0FBQSxHQUFBTCxPQUFBO0FBQ0EsSUFBQU0sa0JBQUEsR0FBQU4sT0FBQTtBQUVBLE1BQU1PLElBQUksR0FBRyxJQUFBQyxjQUFJLEVBQUMsSUFBQUMsaUJBQU8sRUFBQyxJQUFBQyxzQkFBYSxFQUFDQyxlQUFBLENBQVlDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDOztBQUVoRTtBQUNBLE1BQU1DLE1BQU0sR0FBRyxDQUFDLGNBQWMsRUFBRSxrQkFBa0IsRUFBRSxzQkFBc0IsQ0FBQztBQUMzRTtBQUNBLE1BQU1DLE1BQU0sR0FBRyxDQUFDLE1BQU0sRUFBRSxTQUFTLENBQUM7O0FBRWxDO0FBQ0EsTUFBTUMsTUFBTSxHQUFJQyxDQUFDLElBQUs7RUFDcEIsSUFBSUEsQ0FBQyxLQUFLQyxTQUFTLEVBQUUsT0FBT0EsU0FBUztFQUNyQyxJQUFJRCxDQUFDLEtBQUssSUFBSSxJQUFJLE9BQU9BLENBQUMsS0FBSyxRQUFRLEVBQUUsT0FBT0UsSUFBSSxDQUFDQyxTQUFTLENBQUNILENBQUMsQ0FBQztFQUNqRSxJQUFJSSxLQUFLLENBQUNDLE9BQU8sQ0FBQ0wsQ0FBQyxDQUFDLEVBQUUsT0FBTyxJQUFJQSxDQUFDLENBQUNNLEdBQUcsQ0FBQ1AsTUFBTSxDQUFDLENBQUNQLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRztFQUMzRCxPQUFPLElBQUlqQixNQUFNLENBQUNnQyxJQUFJLENBQUNQLENBQUMsQ0FBQyxDQUN0QlEsSUFBSSxDQUFDLENBQUMsQ0FDTkYsR0FBRyxDQUFFRyxDQUFDLElBQUssR0FBR1AsSUFBSSxDQUFDQyxTQUFTLENBQUNNLENBQUMsQ0FBQyxJQUFJVixNQUFNLENBQUNDLENBQUMsQ0FBQ1MsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQ2xEakIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHO0FBQ2pCLENBQUM7O0FBRUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVNaLGVBQWVBLENBQUM4QixTQUFTLEVBQUVDLEtBQUssRUFBRTtFQUNoRCxNQUFNQyxJQUFJLEdBQUcsRUFBRTtFQUNmLEtBQUssTUFBTUMsS0FBSyxJQUFJaEIsTUFBTSxFQUFFO0lBQzFCLE1BQU1pQixDQUFDLEdBQUdKLFNBQVMsR0FBR0csS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ2xDLE1BQU1FLENBQUMsR0FBR0osS0FBSyxHQUFHRSxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDOUIsS0FBSyxNQUFNRyxJQUFJLElBQUksQ0FBQyxHQUFHLElBQUlDLEdBQUcsQ0FBQyxDQUFDLEdBQUcxQyxNQUFNLENBQUNnQyxJQUFJLENBQUNPLENBQUMsQ0FBQyxFQUFFLEdBQUd2QyxNQUFNLENBQUNnQyxJQUFJLENBQUNRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDUCxJQUFJLENBQUMsQ0FBQyxFQUFFO01BQzlFLElBQUlNLENBQUMsQ0FBQ0UsSUFBSSxDQUFDLEtBQUtELENBQUMsQ0FBQ0MsSUFBSSxDQUFDLEVBQUU7UUFDdkJKLElBQUksQ0FBQ00sSUFBSSxDQUFDO1VBQUVMLEtBQUs7VUFBRUcsSUFBSTtVQUFFTixTQUFTLEVBQUVJLENBQUMsQ0FBQ0UsSUFBSSxDQUFDLElBQUksVUFBVTtVQUFFTCxLQUFLLEVBQUVJLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLElBQUk7UUFBVyxDQUFDLENBQUM7TUFDNUY7SUFDRjtFQUNGO0VBQ0EsS0FBSyxNQUFNRyxLQUFLLElBQUlyQixNQUFNLEVBQUU7SUFDMUIsTUFBTWdCLENBQUMsR0FBR2YsTUFBTSxDQUFDVyxTQUFTLEdBQUdTLEtBQUssQ0FBQyxDQUFDO0lBQ3BDLE1BQU1KLENBQUMsR0FBR2hCLE1BQU0sQ0FBQ1ksS0FBSyxHQUFHUSxLQUFLLENBQUMsQ0FBQztJQUNoQyxJQUFJTCxDQUFDLEtBQUtDLENBQUMsRUFBRUgsSUFBSSxDQUFDTSxJQUFJLENBQUM7TUFBRUwsS0FBSyxFQUFFLFFBQVE7TUFBRUcsSUFBSSxFQUFFRyxLQUFLO01BQUVULFNBQVMsRUFBRUksQ0FBQyxJQUFJLFVBQVU7TUFBRUgsS0FBSyxFQUFFSSxDQUFDLElBQUk7SUFBVyxDQUFDLENBQUM7RUFDOUc7RUFDQSxPQUFPSCxJQUFJO0FBQ2I7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBUzdCLFlBQVlBLENBQUMyQixTQUFTLEVBQUVDLEtBQUssRUFBRTtFQUM3QyxNQUFNQyxJQUFJLEdBQUcsRUFBRTtFQUNmLEtBQUssTUFBTVEsSUFBSSxJQUFJLENBQUMsR0FBRyxJQUFJSCxHQUFHLENBQUMsQ0FBQyxHQUFHUCxTQUFTLENBQUNILElBQUksQ0FBQyxDQUFDLEVBQUUsR0FBR0ksS0FBSyxDQUFDSixJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDQyxJQUFJLENBQUMsQ0FBQyxFQUFFO0lBQzlFLE1BQU1NLENBQUMsR0FBR0osU0FBUyxDQUFDVyxHQUFHLENBQUNELElBQUksQ0FBQztJQUM3QixNQUFNTCxDQUFDLEdBQUdKLEtBQUssQ0FBQ1UsR0FBRyxDQUFDRCxJQUFJLENBQUM7SUFDekIsSUFBSU4sQ0FBQyxLQUFLQyxDQUFDLEVBQUVILElBQUksQ0FBQ00sSUFBSSxDQUFDO01BQUVFLElBQUk7TUFBRVYsU0FBUyxFQUFFSSxDQUFDLElBQUksVUFBVTtNQUFFSCxLQUFLLEVBQUVJLENBQUMsSUFBSTtJQUFXLENBQUMsQ0FBQztFQUN0RjtFQUNBLE9BQU9ILElBQUk7QUFDYjs7QUFFQTtBQUNBLFNBQVNVLFVBQVVBLENBQUNDLE9BQU8sRUFBRTtFQUMzQixPQUFPLElBQUFDLHNCQUFVLEVBQUMsUUFBUSxDQUFDLENBQUNDLE1BQU0sQ0FBQyxJQUFBQyxvQkFBWSxFQUFDSCxPQUFPLENBQUMsQ0FBQyxDQUFDSSxNQUFNLENBQUMsS0FBSyxDQUFDO0FBQ3pFOztBQUVBO0FBQ0EsU0FBU0MsV0FBV0EsQ0FBQ0MsSUFBSSxFQUFFO0VBQ3pCLE1BQU12QixHQUFHLEdBQUcsSUFBSXdCLEdBQUcsQ0FBQyxDQUFDO0VBQ3JCLE1BQU1DLElBQUksR0FBSUMsR0FBRyxJQUFLO0lBQ3BCLE1BQU1DLEdBQUcsR0FBR0QsR0FBRyxLQUFLLEVBQUUsR0FBR0gsSUFBSSxHQUFHLElBQUFyQyxjQUFJLEVBQUNxQyxJQUFJLEVBQUVHLEdBQUcsQ0FBQztJQUMvQyxJQUFJLElBQUFFLGdCQUFRLEVBQUNELEdBQUcsQ0FBQyxDQUFDRSxXQUFXLENBQUMsQ0FBQyxFQUFFO01BQy9CLEtBQUssTUFBTUMsS0FBSyxJQUFJLElBQUFDLG1CQUFXLEVBQUNKLEdBQUcsQ0FBQyxFQUFFRixJQUFJLENBQUNDLEdBQUcsS0FBSyxFQUFFLEdBQUdJLEtBQUssR0FBRyxHQUFHSixHQUFHLElBQUlJLEtBQUssRUFBRSxDQUFDO0lBQ3BGLENBQUMsTUFBTSxJQUFJLElBQUFGLGdCQUFRLEVBQUNELEdBQUcsQ0FBQyxDQUFDSyxNQUFNLENBQUMsQ0FBQyxFQUFFO01BQ2pDaEMsR0FBRyxDQUFDaUMsR0FBRyxDQUFDUCxHQUFHLEVBQUVWLFVBQVUsQ0FBQ1csR0FBRyxDQUFDLENBQUM7SUFDL0I7RUFDRixDQUFDO0VBQ0RGLElBQUksQ0FBQyxFQUFFLENBQUM7RUFDUixPQUFPekIsR0FBRztBQUNaOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBU3pCLFlBQVlBLENBQUMyRCxXQUFXLEVBQUU7RUFDeEMsTUFBTUMsR0FBRyxHQUFHLElBQUFDLG1CQUFXLEVBQUMsSUFBQWxELGNBQUksRUFBQyxJQUFBbUQsY0FBTSxFQUFDLENBQUMsRUFBRSwyQkFBMkIsQ0FBQyxDQUFDO0VBQ3BFLElBQUk7SUFDRixJQUFBQywrQkFBWSxFQUFDLEtBQUssRUFBRSxDQUFDLE1BQU0sRUFBRUosV0FBVyxFQUFFLElBQUksRUFBRUMsR0FBRyxFQUFFLG9CQUFvQixFQUFFLEdBQUcsQ0FBQyxFQUFFO01BQy9FSSxLQUFLLEVBQUUsQ0FBQyxRQUFRLEVBQUUsUUFBUSxFQUFFLE1BQU0sQ0FBQztNQUNuQztNQUNBO01BQ0FDLE9BQU8sRUFBRTtJQUNYLENBQUMsQ0FBQztJQUNGLE9BQU9sQixXQUFXLENBQUNhLEdBQUcsQ0FBQztFQUN6QixDQUFDLFNBQVM7SUFDUixJQUFBTSxjQUFNLEVBQUNOLEdBQUcsRUFBRTtNQUFFTyxTQUFTLEVBQUUsSUFBSTtNQUFFQyxLQUFLLEVBQUU7SUFBSyxDQUFDLENBQUM7RUFDL0M7QUFDRjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVNuRSxXQUFXQSxDQUFDMkQsR0FBRyxFQUFFO0VBQy9CLE1BQU1TLE9BQU8sR0FBRyxJQUFBYixtQkFBVyxFQUFDSSxHQUFHLENBQUMsQ0FBQ1UsSUFBSSxDQUFFQyxDQUFDLElBQUtBLENBQUMsQ0FBQ0MsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0VBQ2hFLElBQUksQ0FBQ0gsT0FBTyxFQUFFLE1BQU0sSUFBSUksS0FBSyxDQUFDLDJCQUEyQixDQUFDO0VBQzFELE9BQU9KLE9BQU87QUFDaEI7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTSyxXQUFXQSxDQUFDQyxJQUFJLEVBQUVDLEdBQUcsRUFBRTtFQUM5QixNQUFNQyxJQUFJLEdBQUcsSUFBQWhCLG1CQUFXLEVBQUMsSUFBQWxELGNBQUksRUFBQyxJQUFBbUQsY0FBTSxFQUFDLENBQUMsRUFBRSx3QkFBd0IsQ0FBQyxDQUFDO0VBQ2xFLElBQUk7SUFDRixJQUFBQywrQkFBWSxFQUFDLEtBQUssRUFBRSxDQUFDLE1BQU0sRUFBRSxHQUFHWSxJQUFJLEVBQUUsb0JBQW9CLEVBQUVFLElBQUksQ0FBQyxFQUFFO01BQ2pFRCxHQUFHO01BQ0hFLFFBQVEsRUFBRSxNQUFNO01BQ2hCZCxLQUFLLEVBQUUsQ0FBQyxRQUFRLEVBQUUsTUFBTSxFQUFFLFFBQVEsQ0FBQztNQUNuQ0MsT0FBTyxFQUFFO0lBQ1gsQ0FBQyxDQUFDO0lBQ0YsT0FBTztNQUFFTCxHQUFHLEVBQUVpQixJQUFJO01BQUVSLE9BQU8sRUFBRSxJQUFBMUQsY0FBSSxFQUFDa0UsSUFBSSxFQUFFNUUsV0FBVyxDQUFDNEUsSUFBSSxDQUFDO0lBQUUsQ0FBQztFQUM5RCxDQUFDLENBQUMsT0FBT0UsQ0FBQyxFQUFFO0lBQ1YsSUFBQWIsY0FBTSxFQUFDVyxJQUFJLEVBQUU7TUFBRVYsU0FBUyxFQUFFLElBQUk7TUFBRUMsS0FBSyxFQUFFO0lBQUssQ0FBQyxDQUFDO0lBQzlDLE1BQU1XLENBQUM7RUFDVDtBQUNGOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVNDLGdCQUFnQkEsQ0FBQ0MsT0FBTyxFQUFFQyxNQUFNLEVBQUVDLFNBQVMsRUFBRTtFQUNwREMsT0FBTyxDQUFDQyxLQUFLLENBQ1hGLFNBQVMsR0FDTCxlQUFlRixPQUFPLEtBQUtDLE1BQU0sOEJBQThCLEdBQzdELDZFQUE2RSxHQUMvRSxZQUFZRCxPQUFPLEtBQUtDLE1BQU0sa0NBQ3BDLENBQUM7RUFDRCxPQUFPQyxTQUFTLEdBQUcsQ0FBQyxHQUFHLENBQUM7QUFDMUI7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVNyRixxQkFBcUJBLENBQUM7RUFBRXdGLE1BQU07RUFBRUM7QUFBTyxDQUFDLEVBQUU7RUFDeEQsTUFBTUMsSUFBSSxHQUFHLENBQUNGLE1BQU0sSUFBSSxFQUFFLEVBQUVHLElBQUksQ0FBQyxDQUFDO0VBQ2xDLElBQUlELElBQUksS0FBSyxFQUFFLEVBQUUsT0FBT0QsTUFBTSxHQUFHO0lBQUVHLElBQUksRUFBRSxZQUFZO0lBQUVSLE1BQU0sRUFBRTtFQUFjLENBQUMsR0FBRztJQUFFUSxJQUFJLEVBQUUsV0FBVztJQUFFQyxRQUFRLEVBQUUsQ0FBQztFQUFFLENBQUM7RUFDcEgsSUFBSUMsTUFBTTtFQUNWLElBQUk7SUFDRkEsTUFBTSxHQUFHdkUsSUFBSSxDQUFDd0UsS0FBSyxDQUFDTCxJQUFJLENBQUM7RUFDM0IsQ0FBQyxDQUFDLE1BQU07SUFDTixPQUFPO01BQUVFLElBQUksRUFBRSxZQUFZO01BQUVSLE1BQU0sRUFBRTtJQUFxQixDQUFDO0VBQzdEO0VBQ0EsSUFBSVUsTUFBTSxJQUFJLE9BQU9BLE1BQU0sS0FBSyxRQUFRLElBQUlBLE1BQU0sQ0FBQ1AsS0FBSyxFQUFFO0lBQ3hELE9BQU9PLE1BQU0sQ0FBQ1AsS0FBSyxDQUFDUyxJQUFJLEtBQUssTUFBTSxHQUMvQjtNQUFFSixJQUFJLEVBQUU7SUFBUyxDQUFDLEdBQ2xCO01BQUVBLElBQUksRUFBRSxZQUFZO01BQUVSLE1BQU0sRUFBRVUsTUFBTSxDQUFDUCxLQUFLLENBQUNVLE9BQU8sSUFBSUgsTUFBTSxDQUFDUCxLQUFLLENBQUNTLElBQUksSUFBSTtJQUFpQixDQUFDO0VBQ25HO0VBQ0EsSUFBSSxDQUFDRixNQUFNLElBQUksT0FBT0EsTUFBTSxLQUFLLFFBQVEsSUFBSXJFLEtBQUssQ0FBQ0MsT0FBTyxDQUFDb0UsTUFBTSxDQUFDLEVBQUU7SUFDbEUsT0FBTztNQUFFRixJQUFJLEVBQUUsWUFBWTtNQUFFUixNQUFNLEVBQUU7SUFBMEIsQ0FBQztFQUNsRTtFQUNBLE9BQU87SUFBRVEsSUFBSSxFQUFFLFdBQVc7SUFBRUMsUUFBUSxFQUFFQztFQUFPLENBQUM7QUFDaEQ7QUFFQSxTQUFTSSxRQUFRQSxDQUFBLEVBQUc7RUFDbEIsSUFBSUMsRUFBRSxHQUFHLENBQUM7RUFDVixJQUFJQyxLQUFLLEdBQUcsQ0FBQztFQUNiLE1BQU1DLEtBQUssR0FBR0EsQ0FBQ0MsS0FBSyxFQUFFQyxJQUFJLEtBQUs7SUFDN0JILEtBQUssSUFBSSxDQUFDO0lBQ1YsSUFBSUcsSUFBSSxFQUFFSixFQUFFLElBQUksQ0FBQztJQUNqQmIsT0FBTyxDQUFDa0IsR0FBRyxDQUFDLEdBQUdELElBQUksR0FBRyxNQUFNLEdBQUcsTUFBTSxLQUFLRCxLQUFLLEVBQUUsQ0FBQztFQUNwRCxDQUFDO0VBQ0QsTUFBTUcsR0FBRyxHQUFJQyxDQUFDLEtBQU07SUFBRUMsWUFBWSxFQUFFRDtFQUFFLENBQUMsQ0FBQzs7RUFFeEM7RUFDQUwsS0FBSyxDQUFDLG1DQUFtQyxFQUFFcEcsZUFBZSxDQUFDd0csR0FBRyxDQUFDO0lBQUVHLENBQUMsRUFBRTtFQUFRLENBQUMsQ0FBQyxFQUFFSCxHQUFHLENBQUM7SUFBRUcsQ0FBQyxFQUFFO0VBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQ0MsTUFBTSxLQUFLLENBQUMsQ0FBQztFQUNsSDtFQUNBLE1BQU1DLEtBQUssR0FBRzdHLGVBQWUsQ0FBQ3dHLEdBQUcsQ0FBQztJQUFFLHNCQUFzQixFQUFFO0VBQVUsQ0FBQyxDQUFDLEVBQUVBLEdBQUcsQ0FBQztJQUFFLHNCQUFzQixFQUFFO0VBQVUsQ0FBQyxDQUFDLENBQUM7RUFDckhKLEtBQUssQ0FBQyxzQkFBc0IsRUFBRVMsS0FBSyxDQUFDRCxNQUFNLEtBQUssQ0FBQyxDQUFDO0VBQ2pEUixLQUFLLENBQUMsdUJBQXVCLEVBQUVTLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQy9FLFNBQVMsS0FBSyxTQUFTLElBQUkrRSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM5RSxLQUFLLEtBQUssU0FBUyxDQUFDO0VBQ2hHcUUsS0FBSyxDQUFDLDhCQUE4QixFQUFFcEcsZUFBZSxDQUFDd0csR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUVBLEdBQUcsQ0FBQztJQUFFRyxDQUFDLEVBQUU7RUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFNUUsS0FBSyxLQUFLLE9BQU8sQ0FBQztFQUMxR3FFLEtBQUssQ0FBQywrQkFBK0IsRUFBRXBHLGVBQWUsQ0FBQ3dHLEdBQUcsQ0FBQztJQUFFRyxDQUFDLEVBQUU7RUFBUSxDQUFDLENBQUMsRUFBRUgsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRXpFLEtBQUssS0FBSyxVQUFVLENBQUM7RUFDOUdxRSxLQUFLLENBQ0gseURBQXlELEVBQ3pEcEcsZUFBZSxDQUNiO0lBQUUwRyxZQUFZLEVBQUU7TUFBRUMsQ0FBQyxFQUFFO0lBQVEsQ0FBQztJQUFFRyxnQkFBZ0IsRUFBRTtNQUFFSCxDQUFDLEVBQUU7SUFBUztFQUFFLENBQUMsRUFDbkU7SUFBRUQsWUFBWSxFQUFFO01BQUVDLENBQUMsRUFBRTtJQUFRLENBQUM7SUFBRUcsZ0JBQWdCLEVBQUU7TUFBRUgsQ0FBQyxFQUFFO0lBQVM7RUFBRSxDQUNwRSxDQUFDLENBQUNDLE1BQU0sS0FBSyxDQUNmLENBQUM7RUFDRFIsS0FBSyxDQUNILG9FQUFvRSxFQUNwRXBHLGVBQWUsQ0FBQztJQUFFOEcsZ0JBQWdCLEVBQUU7TUFBRUgsQ0FBQyxFQUFFO0lBQVM7RUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQ0MsTUFBTSxLQUFLLENBQ3hFLENBQUM7RUFDRFIsS0FBSyxDQUFDLG9FQUFvRSxFQUFFcEcsZUFBZSxDQUFDO0lBQUUrRyxlQUFlLEVBQUU7TUFBRUosQ0FBQyxFQUFFO0lBQUk7RUFBRSxDQUFDLEVBQUU7SUFBRUksZUFBZSxFQUFFO01BQUVKLENBQUMsRUFBRTtJQUFJO0VBQUUsQ0FBQyxDQUFDLENBQUNDLE1BQU0sS0FBSyxDQUFDLENBQUM7RUFDM0tSLEtBQUssQ0FBQyx1QkFBdUIsRUFBRXBHLGVBQWUsQ0FBQ3dHLEdBQUcsQ0FBQztJQUFFRyxDQUFDLEVBQUUsR0FBRztJQUFFSyxDQUFDLEVBQUU7RUFBSSxDQUFDLENBQUMsRUFBRVIsR0FBRyxDQUFDO0lBQUVRLENBQUMsRUFBRSxHQUFHO0lBQUVMLENBQUMsRUFBRTtFQUFJLENBQUMsQ0FBQyxDQUFDLENBQUNDLE1BQU0sS0FBSyxDQUFDLENBQUM7RUFDOUc7RUFDQTtFQUNBUixLQUFLLENBQUMseUJBQXlCLEVBQUVwRyxlQUFlLENBQUM7SUFBRWlILElBQUksRUFBRTtFQUFZLENBQUMsRUFBRTtJQUFFQSxJQUFJLEVBQUU7RUFBWSxDQUFDLENBQUMsQ0FBQ0wsTUFBTSxLQUFLLENBQUMsQ0FBQztFQUM1R1IsS0FBSyxDQUFDLHNDQUFzQyxFQUFFcEcsZUFBZSxDQUFDO0lBQUVILE9BQU8sRUFBRTtNQUFFLEdBQUcsRUFBRTtJQUFTO0VBQUUsQ0FBQyxFQUFFO0lBQUVBLE9BQU8sRUFBRTtNQUFFLEdBQUcsRUFBRTtJQUFTO0VBQUUsQ0FBQyxDQUFDLENBQUMrRyxNQUFNLEtBQUssQ0FBQyxDQUFDO0VBQzNJUixLQUFLLENBQUMscUNBQXFDLEVBQUVwRyxlQUFlLENBQUM7SUFBRUgsT0FBTyxFQUFFO01BQUUsR0FBRyxFQUFFO0lBQVM7RUFBRSxDQUFDLEVBQUU7SUFBRUEsT0FBTyxFQUFFO01BQUUsR0FBRyxFQUFFLFFBQVE7TUFBRSxLQUFLLEVBQUU7SUFBUztFQUFFLENBQUMsQ0FBQyxDQUFDK0csTUFBTSxLQUFLLENBQUMsQ0FBQztFQUMzSlIsS0FBSyxDQUNILDREQUE0RCxFQUM1RHBHLGVBQWUsQ0FBQztJQUFFSCxPQUFPLEVBQUU7TUFBRSxHQUFHLEVBQUUsUUFBUTtNQUFFLEtBQUssRUFBRTtJQUFTO0VBQUUsQ0FBQyxFQUFFO0lBQUVBLE9BQU8sRUFBRTtNQUFFLEtBQUssRUFBRSxRQUFRO01BQUUsR0FBRyxFQUFFO0lBQVM7RUFBRSxDQUFDLENBQUMsQ0FBQytHLE1BQU0sS0FBSyxDQUMvSCxDQUFDOztFQUVEO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsTUFBTU0sSUFBSSxHQUFHNUYsSUFBSSxDQUFDQyxTQUFTLENBQUM7SUFDMUIrRCxLQUFLLEVBQUU7TUFDTFMsSUFBSSxFQUFFLE1BQU07TUFDWkMsT0FBTyxFQUFFLGtDQUFrQztNQUMzQ21CLE1BQU0sRUFBRTtJQUNWO0VBQ0YsQ0FBQyxDQUFDO0VBQ0ZmLEtBQUssQ0FBQyx3Q0FBd0MsRUFBRXJHLHFCQUFxQixDQUFDO0lBQUV3RixNQUFNLEVBQUUyQixJQUFJO0lBQUUxQixNQUFNLEVBQUU7RUFBSyxDQUFDLENBQUMsQ0FBQ0csSUFBSSxLQUFLLFFBQVEsQ0FBQztFQUN4SDtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU15QixJQUFJLEdBQUc5RixJQUFJLENBQUNDLFNBQVMsQ0FBQztJQUMxQm1GLFlBQVksRUFBRTtNQUFFLDhCQUE4QixFQUFFLE9BQU87TUFBRSxzQkFBc0IsRUFBRSxTQUFTO01BQUVXLEtBQUssRUFBRSxTQUFTO01BQUUsV0FBVyxFQUFFO0lBQVUsQ0FBQztJQUN0SVAsZ0JBQWdCLEVBQUU7TUFBRSxzQkFBc0IsRUFBRSxTQUFTO01BQUVPLEtBQUssRUFBRSxTQUFTO01BQUUsV0FBVyxFQUFFO0lBQVUsQ0FBQztJQUNqR0osSUFBSSxFQUFFLGNBQWM7SUFDcEJwSCxPQUFPLEVBQUU7TUFDUCxHQUFHLEVBQUUsY0FBYztNQUNuQixPQUFPLEVBQUUsZUFBZTtNQUN4QixZQUFZLEVBQUUsd0JBQXdCO01BQ3RDLGNBQWMsRUFBRSx3QkFBd0I7TUFDeEMsY0FBYyxFQUFFLG9CQUFvQjtNQUNwQyxhQUFhLEVBQUUsaUJBQWlCO01BQ2hDLGdCQUFnQixFQUFFO0lBQ3BCO0VBQ0YsQ0FBQyxDQUFDO0VBQ0YsTUFBTXlILEdBQUcsR0FBR3ZILHFCQUFxQixDQUFDO0lBQUV3RixNQUFNLEVBQUU2QixJQUFJO0lBQUU1QixNQUFNLEVBQUU7RUFBTSxDQUFDLENBQUM7RUFDbEVZLEtBQUssQ0FBQyxxQ0FBcUMsRUFBRWtCLEdBQUcsQ0FBQzNCLElBQUksS0FBSyxXQUFXLENBQUM7RUFDdEU7RUFDQTtFQUNBLE1BQU00QixRQUFRLEdBQUd2SCxlQUFlLENBQUNzSCxHQUFHLENBQUMxQixRQUFRLEVBQUV0RSxJQUFJLENBQUN3RSxLQUFLLENBQUMsSUFBQWhELG9CQUFZLEVBQUMsSUFBQWxDLGNBQUksRUFBQ0QsSUFBSSxFQUFFLGNBQWMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUM7RUFDNUd5RixLQUFLLENBQ0gsZ0ZBQWdGLEVBQ2hGOUUsSUFBSSxDQUFDQyxTQUFTLENBQUNnRyxRQUFRLENBQUM3RixHQUFHLENBQUU4RixDQUFDLElBQUssR0FBR0EsQ0FBQyxDQUFDdkYsS0FBSyxJQUFJdUYsQ0FBQyxDQUFDcEYsSUFBSSxFQUFFLENBQUMsQ0FBQyxLQUN6RGQsSUFBSSxDQUFDQyxTQUFTLENBQUMsQ0FDYiwyQ0FBMkMsRUFDM0MsbUNBQW1DLEVBQ25DLHVDQUF1QyxDQUN4QyxDQUNMLENBQUM7RUFDRDZFLEtBQUssQ0FBQyxxRUFBcUUsRUFBRXJHLHFCQUFxQixDQUFDO0lBQUV3RixNQUFNLEVBQUUsRUFBRTtJQUFFQyxNQUFNLEVBQUU7RUFBTSxDQUFDLENBQUMsQ0FBQ0csSUFBSSxLQUFLLFdBQVcsQ0FBQztFQUN2SlMsS0FBSyxDQUFDLDhDQUE4QyxFQUFFcEcsZUFBZSxDQUFDRCxxQkFBcUIsQ0FBQztJQUFFd0YsTUFBTSxFQUFFLEVBQUU7SUFBRUMsTUFBTSxFQUFFO0VBQU0sQ0FBQyxDQUFDLENBQUNJLFFBQVEsRUFBRVksR0FBRyxDQUFDO0lBQUVHLENBQUMsRUFBRTtFQUFJLENBQUMsQ0FBQyxDQUFDLENBQUNDLE1BQU0sS0FBSyxDQUFDLENBQUM7RUFDbktSLEtBQUssQ0FBQywwQ0FBMEMsRUFBRXJHLHFCQUFxQixDQUFDO0lBQUV3RixNQUFNLEVBQUUsRUFBRTtJQUFFQyxNQUFNLEVBQUU7RUFBSyxDQUFDLENBQUMsQ0FBQ0csSUFBSSxLQUFLLFlBQVksQ0FBQztFQUM1SFMsS0FBSyxDQUFDLHVEQUF1RCxFQUFFckcscUJBQXFCLENBQUM7SUFBRXdGLE1BQU0sRUFBRWpFLElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQUUrRCxLQUFLLEVBQUU7UUFBRVMsSUFBSSxFQUFFLE1BQU07UUFBRUMsT0FBTyxFQUFFO01BQU87SUFBRSxDQUFDLENBQUM7SUFBRVIsTUFBTSxFQUFFO0VBQUssQ0FBQyxDQUFDLENBQUNHLElBQUksS0FBSyxZQUFZLENBQUM7RUFDbk1TLEtBQUssQ0FBQyxnQ0FBZ0MsRUFBRXJHLHFCQUFxQixDQUFDO0lBQUV3RixNQUFNLEVBQUUsa0JBQWtCO0lBQUVDLE1BQU0sRUFBRTtFQUFLLENBQUMsQ0FBQyxDQUFDRyxJQUFJLEtBQUssWUFBWSxDQUFDO0VBQ2xJUyxLQUFLLENBQUMseURBQXlELEVBQUVyRyxxQkFBcUIsQ0FBQztJQUFFd0YsTUFBTSxFQUFFLG1CQUFtQjtJQUFFQyxNQUFNLEVBQUU7RUFBTSxDQUFDLENBQUMsQ0FBQ0csSUFBSSxLQUFLLFlBQVksQ0FBQzs7RUFFN0o7RUFDQSxNQUFNakUsR0FBRyxHQUFJK0UsQ0FBQyxJQUFLLElBQUl2RCxHQUFHLENBQUN2RCxNQUFNLENBQUM4SCxPQUFPLENBQUNoQixDQUFDLENBQUMsQ0FBQztFQUM3Q0wsS0FBSyxDQUFDLHNDQUFzQyxFQUFFakcsWUFBWSxDQUFDdUIsR0FBRyxDQUFDO0lBQUVpRixDQUFDLEVBQUUsSUFBSTtJQUFFSyxDQUFDLEVBQUU7RUFBSyxDQUFDLENBQUMsRUFBRXRGLEdBQUcsQ0FBQztJQUFFc0YsQ0FBQyxFQUFFLElBQUk7SUFBRUwsQ0FBQyxFQUFFO0VBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQ0MsTUFBTSxLQUFLLENBQUMsQ0FBQztFQUM5SCxNQUFNYyxPQUFPLEdBQUd2SCxZQUFZLENBQUN1QixHQUFHLENBQUM7SUFBRWlGLENBQUMsRUFBRSxJQUFJO0lBQUVLLENBQUMsRUFBRTtFQUFLLENBQUMsQ0FBQyxFQUFFdEYsR0FBRyxDQUFDO0lBQUVpRixDQUFDLEVBQUUsSUFBSTtJQUFFSyxDQUFDLEVBQUU7RUFBSyxDQUFDLENBQUMsQ0FBQztFQUNsRlosS0FBSyxDQUFDLDhEQUE4RCxFQUFFc0IsT0FBTyxDQUFDZCxNQUFNLEtBQUssQ0FBQyxJQUFJYyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUNsRixJQUFJLEtBQUssR0FBRyxJQUFJa0YsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDNUYsU0FBUyxLQUFLLElBQUksSUFBSTRGLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQzNGLEtBQUssS0FBSyxJQUFJLENBQUM7RUFDcEwsTUFBTTRGLEtBQUssR0FBR3hILFlBQVksQ0FBQ3VCLEdBQUcsQ0FBQztJQUFFaUYsQ0FBQyxFQUFFO0VBQUssQ0FBQyxDQUFDLEVBQUVqRixHQUFHLENBQUM7SUFBRWlGLENBQUMsRUFBRSxJQUFJO0lBQUUsWUFBWSxFQUFFO0VBQUssQ0FBQyxDQUFDLENBQUM7RUFDbEZQLEtBQUssQ0FBQyx3REFBd0QsRUFBRXVCLEtBQUssQ0FBQ2YsTUFBTSxLQUFLLENBQUMsSUFBSWUsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDbkYsSUFBSSxLQUFLLFlBQVksSUFBSW1GLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQzdGLFNBQVMsS0FBSyxVQUFVLElBQUk2RixLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM1RixLQUFLLEtBQUssSUFBSSxDQUFDO0VBQ3JMLE1BQU02RixPQUFPLEdBQUd6SCxZQUFZLENBQUN1QixHQUFHLENBQUM7SUFBRSxZQUFZLEVBQUU7RUFBSyxDQUFDLENBQUMsRUFBRUEsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDbEUwRSxLQUFLLENBQUMscURBQXFELEVBQUV3QixPQUFPLENBQUNoQixNQUFNLEtBQUssQ0FBQyxJQUFJZ0IsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDcEYsSUFBSSxLQUFLLFlBQVksSUFBSW9GLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQzlGLFNBQVMsS0FBSyxJQUFJLElBQUk4RixPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM3RixLQUFLLEtBQUssVUFBVSxDQUFDOztFQUUxTDtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNOEYsUUFBUSxHQUFHLElBQUEvRCxtQkFBVyxFQUFDLElBQUFsRCxjQUFJLEVBQUMsSUFBQW1ELGNBQU0sRUFBQyxDQUFDLEVBQUUseUJBQXlCLENBQUMsQ0FBQztFQUN2RSxNQUFNK0QsUUFBUSxHQUFHLElBQUFoRSxtQkFBVyxFQUFDLElBQUFsRCxjQUFJLEVBQUMsSUFBQW1ELGNBQU0sRUFBQyxDQUFDLEVBQUUseUJBQXlCLENBQUMsQ0FBQztFQUN2RSxJQUFJZ0UsTUFBTTtFQUNWLElBQUk7SUFDRixJQUFJQyxLQUFLLEdBQUcsSUFBSTtJQUNoQixJQUFJO01BQ0Y5SCxXQUFXLENBQUMySCxRQUFRLENBQUM7SUFDdkIsQ0FBQyxDQUFDLE9BQU83QyxDQUFDLEVBQUU7TUFDVmdELEtBQUssR0FBR2hELENBQUM7SUFDWDtJQUNBb0IsS0FBSyxDQUFDLDBEQUEwRCxFQUFFNEIsS0FBSyxZQUFZdEQsS0FBSyxJQUFJc0QsS0FBSyxDQUFDQyxPQUFPLEtBQUssMkJBQTJCLENBQUM7O0lBRTFJO0lBQ0E7SUFDQTtJQUNBO0lBQ0EsSUFBQUMsaUJBQVMsRUFBQyxJQUFBdEgsY0FBSSxFQUFDa0gsUUFBUSxFQUFFLFNBQVMsRUFBRSxLQUFLLENBQUMsRUFBRTtNQUFFMUQsU0FBUyxFQUFFO0lBQUssQ0FBQyxDQUFDO0lBQ2hFLElBQUErRCxxQkFBYSxFQUFDLElBQUF2SCxjQUFJLEVBQUNrSCxRQUFRLEVBQUUsU0FBUyxFQUFFLE9BQU8sQ0FBQyxFQUFFLE9BQU8sQ0FBQztJQUMxRCxJQUFBSyxxQkFBYSxFQUFDLElBQUF2SCxjQUFJLEVBQUNrSCxRQUFRLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxPQUFPLENBQUMsRUFBRSxNQUFNLENBQUM7SUFDaEUsSUFBQTlELCtCQUFZLEVBQUMsS0FBSyxFQUFFLENBQUMsTUFBTSxFQUFFLElBQUFwRCxjQUFJLEVBQUNrSCxRQUFRLEVBQUUsV0FBVyxDQUFDLEVBQUUsSUFBSSxFQUFFQSxRQUFRLEVBQUUsU0FBUyxDQUFDLEVBQUU7TUFDcEY3RCxLQUFLLEVBQUUsQ0FBQyxRQUFRLEVBQUUsUUFBUSxFQUFFLE1BQU0sQ0FBQztNQUNuQ0MsT0FBTyxFQUFFO0lBQ1gsQ0FBQyxDQUFDO0lBQ0YsTUFBTWtFLEtBQUssR0FBR25JLFlBQVksQ0FBQyxJQUFBVyxjQUFJLEVBQUNrSCxRQUFRLEVBQUUsV0FBVyxDQUFDLENBQUM7SUFDdkQsTUFBTU8sTUFBTSxHQUFJbkcsQ0FBQyxJQUFLLElBQUFVLHNCQUFVLEVBQUMsUUFBUSxDQUFDLENBQUNDLE1BQU0sQ0FBQyxJQUFBQyxvQkFBWSxFQUFDLElBQUFsQyxjQUFJLEVBQUNrSCxRQUFRLEVBQUUsU0FBUyxFQUFFNUYsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDYSxNQUFNLENBQUMsS0FBSyxDQUFDO0lBQzNHcUQsS0FBSyxDQUNILHNFQUFzRSxFQUN0RWdDLEtBQUssQ0FBQ0UsSUFBSSxLQUFLLENBQUMsSUFBSUYsS0FBSyxDQUFDM0YsR0FBRyxDQUFDLE9BQU8sQ0FBQyxLQUFLNEYsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJRCxLQUFLLENBQUMzRixHQUFHLENBQUMsV0FBVyxDQUFDLEtBQUs0RixNQUFNLENBQUMsV0FBVyxDQUM3RyxDQUFDO0lBRUROLE1BQU0sR0FBR3BELFdBQVcsQ0FBQyxFQUFFLEVBQUVoRSxJQUFJLENBQUM7SUFDOUIsTUFBTXlHLElBQUksR0FBR25ILFlBQVksQ0FBQzhILE1BQU0sQ0FBQ3pELE9BQU8sQ0FBQztJQUN6QzhCLEtBQUssQ0FBQyxnRkFBZ0YsRUFBRWdCLElBQUksQ0FBQ2tCLElBQUksR0FBRyxDQUFDLElBQUlsQixJQUFJLENBQUNtQixHQUFHLENBQUMsY0FBYyxDQUFDLENBQUM7SUFDbEluQyxLQUFLLENBQUMsMkNBQTJDLEVBQUVqRyxZQUFZLENBQUNpSCxJQUFJLEVBQUVBLElBQUksQ0FBQyxDQUFDUixNQUFNLEtBQUssQ0FBQyxDQUFDO0lBQ3pGLE1BQU00QixTQUFTLEdBQUcsQ0FBQyxHQUFHcEIsSUFBSSxDQUFDekYsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUNyQyxNQUFNOEcsT0FBTyxHQUFHLElBQUl2RixHQUFHLENBQUNrRSxJQUFJLENBQUM7SUFDN0JxQixPQUFPLENBQUM5RSxHQUFHLENBQUM2RSxTQUFTLEVBQUUsVUFBVSxDQUFDO0lBQ2xDLE1BQU1FLFdBQVcsR0FBR3ZJLFlBQVksQ0FBQ2lILElBQUksRUFBRXFCLE9BQU8sQ0FBQztJQUMvQ3JDLEtBQUssQ0FBQyw4REFBOEQsRUFBRXNDLFdBQVcsQ0FBQzlCLE1BQU0sS0FBSyxDQUFDLElBQUk4QixXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUNsRyxJQUFJLEtBQUtnRyxTQUFTLElBQUlFLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQzVHLFNBQVMsS0FBS3NGLElBQUksQ0FBQzNFLEdBQUcsQ0FBQytGLFNBQVMsQ0FBQyxJQUFJRSxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMzRyxLQUFLLEtBQUssVUFBVSxDQUFDO0lBQy9OcUUsS0FBSyxDQUFDLGdFQUFnRSxFQUFFbEcsV0FBVyxDQUFDNkgsTUFBTSxDQUFDbEUsR0FBRyxDQUFDLEtBQUtrRSxNQUFNLENBQUN6RCxPQUFPLENBQUNxRSxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUNDLEdBQUcsQ0FBQyxDQUFDLENBQUM7O0lBRXBJO0lBQ0E7SUFDQTtJQUNBLE1BQU1DLElBQUksR0FBRyxFQUFFO0lBQ2YsTUFBTUMsU0FBUyxHQUFHekQsT0FBTyxDQUFDQyxLQUFLO0lBQy9CRCxPQUFPLENBQUNDLEtBQUssR0FBSXlELENBQUMsSUFBS0YsSUFBSSxDQUFDdkcsSUFBSSxDQUFDeUcsQ0FBQyxDQUFDO0lBQ25DLE1BQU1DLFVBQVUsR0FBRy9ELGdCQUFnQixDQUFDLDBCQUEwQixFQUFFLE1BQU0sRUFBRSxLQUFLLENBQUM7SUFDOUUsTUFBTWdFLFdBQVcsR0FBR2hFLGdCQUFnQixDQUFDLDBCQUEwQixFQUFFLE1BQU0sRUFBRSxJQUFJLENBQUM7SUFDOUVJLE9BQU8sQ0FBQ0MsS0FBSyxHQUFHd0QsU0FBUztJQUN6QjFDLEtBQUssQ0FDSCxnSEFBZ0gsRUFDaEg0QyxVQUFVLEtBQUssQ0FBQyxJQUNkSCxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUNLLFFBQVEsQ0FBQywwQkFBMEIsQ0FBQyxJQUM1Q0wsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDSyxRQUFRLENBQUMsNkJBQTZCLENBQUMsSUFDL0NELFdBQVcsS0FBSyxDQUFDLElBQ2pCSixJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUNLLFFBQVEsQ0FBQyx3QkFBd0IsQ0FDN0MsQ0FBQztFQUNILENBQUMsU0FBUztJQUNSLEtBQUssTUFBTXJGLEdBQUcsSUFBSSxDQUFDZ0UsUUFBUSxFQUFFQyxRQUFRLEVBQUVDLE1BQU0sRUFBRWxFLEdBQUcsQ0FBQyxFQUFFO01BQ25ELElBQUlBLEdBQUcsRUFBRSxJQUFBTSxjQUFNLEVBQUNOLEdBQUcsRUFBRTtRQUFFTyxTQUFTLEVBQUUsSUFBSTtRQUFFQyxLQUFLLEVBQUU7TUFBSyxDQUFDLENBQUM7SUFDeEQ7RUFDRjtFQUVBZ0IsT0FBTyxDQUFDa0IsR0FBRyxDQUFDLEtBQUtMLEVBQUUsSUFBSUMsS0FBSyxtQkFBbUIsQ0FBQztFQUNoRCxPQUFPRCxFQUFFLEtBQUtDLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQztBQUM3QjtBQUVBLElBQUlnRCxPQUFPLENBQUNDLElBQUksQ0FBQ0YsUUFBUSxDQUFDLGFBQWEsQ0FBQyxFQUFFQyxPQUFPLENBQUNFLElBQUksQ0FBQ3BELFFBQVEsQ0FBQyxDQUFDLENBQUM7QUFFbEUsTUFBTWIsU0FBUyxHQUFHK0QsT0FBTyxDQUFDQyxJQUFJLENBQUNGLFFBQVEsQ0FBQyxjQUFjLENBQUM7QUFDdkQsTUFBTW5ILEtBQUssR0FBR1QsSUFBSSxDQUFDd0UsS0FBSyxDQUFDLElBQUFoRCxvQkFBWSxFQUFDLElBQUFsQyxjQUFJLEVBQUNELElBQUksRUFBRSxjQUFjLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQztBQUMxRSxNQUFNaUUsSUFBSSxHQUFHLEdBQUc3QyxLQUFLLENBQUNLLElBQUksSUFBSUwsS0FBSyxDQUFDdUgsT0FBTyxFQUFFO0FBRTdDLElBQUkvRCxNQUFNLEdBQUcsRUFBRTtBQUNmLElBQUlDLE1BQU0sR0FBRyxLQUFLO0FBQ2xCLElBQUk7RUFDRkQsTUFBTSxHQUFHLElBQUF2QiwrQkFBWSxFQUFDLEtBQUssRUFBRSxDQUFDLE1BQU0sRUFBRVksSUFBSSxFQUFFLEdBQUczRCxNQUFNLEVBQUUsR0FBR0MsTUFBTSxFQUFFLFFBQVEsQ0FBQyxFQUFFO0lBQzNFNkQsUUFBUSxFQUFFLE1BQU07SUFDaEJkLEtBQUssRUFBRSxDQUFDLFFBQVEsRUFBRSxNQUFNLEVBQUUsUUFBUSxDQUFDO0lBQ25DO0lBQ0E7SUFDQUMsT0FBTyxFQUFFO0VBQ1gsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLE9BQU9jLENBQUMsRUFBRTtFQUNWUSxNQUFNLEdBQUcsSUFBSTtFQUNiRCxNQUFNLEdBQUcsT0FBT1AsQ0FBQyxFQUFFTyxNQUFNLEtBQUssUUFBUSxHQUFHUCxDQUFDLENBQUNPLE1BQU0sR0FBRyxFQUFFO0FBQ3hEO0FBRUEsTUFBTWdFLEtBQUssR0FBR3hKLHFCQUFxQixDQUFDO0VBQUV3RixNQUFNO0VBQUVDO0FBQU8sQ0FBQyxDQUFDO0FBRXZELElBQUkrRCxLQUFLLENBQUM1RCxJQUFJLEtBQUssUUFBUSxFQUFFO0VBQzNCTixPQUFPLENBQUNrQixHQUFHLENBQUMsS0FBSzNCLElBQUksNkNBQTZDLENBQUM7RUFDbkV1RSxPQUFPLENBQUNFLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDakI7QUFFQSxJQUFJRSxLQUFLLENBQUM1RCxJQUFJLEtBQUssWUFBWSxFQUFFO0VBQy9CO0VBQ0E7RUFDQTtFQUNBO0VBQ0F3RCxPQUFPLENBQUNFLElBQUksQ0FBQ3BFLGdCQUFnQixDQUFDLFFBQVFMLElBQUksb0JBQW9CLEVBQUUyRSxLQUFLLENBQUNwRSxNQUFNLEVBQUVDLFNBQVMsQ0FBQyxDQUFDO0FBQzNGO0FBRUEsTUFBTXBELElBQUksR0FBR2hDLGVBQWUsQ0FBQ3VKLEtBQUssQ0FBQzNELFFBQVEsRUFBRTdELEtBQUssQ0FBQztBQUNuRCxJQUFJQyxJQUFJLENBQUM0RSxNQUFNLEdBQUcsQ0FBQyxFQUFFO0VBQ25CdkIsT0FBTyxDQUFDQyxLQUFLLENBQ1gsWUFBWVYsSUFBSSw2RUFBNkUsR0FDM0Ysc0ZBQ0osQ0FBQztFQUNELEtBQUssTUFBTTRDLENBQUMsSUFBSXhGLElBQUksRUFBRTtJQUNwQnFELE9BQU8sQ0FBQ0MsS0FBSyxDQUFDLEtBQUtrQyxDQUFDLENBQUN2RixLQUFLLElBQUl1RixDQUFDLENBQUNwRixJQUFJLGVBQWVvRixDQUFDLENBQUMxRixTQUFTLFdBQVcwRixDQUFDLENBQUN6RixLQUFLLEVBQUUsQ0FBQztFQUNyRjtFQUNBb0gsT0FBTyxDQUFDRSxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ2pCOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSUcsYUFBYTtBQUNqQixJQUFJQyxTQUFTO0FBQ2IsSUFBSUMsUUFBUSxHQUFHLENBQUM7QUFDaEIsSUFBSTtFQUNGRixhQUFhLEdBQUc3RSxXQUFXLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLEVBQUVqRSxJQUFJLENBQUM7RUFDekM4SSxTQUFTLEdBQUc5RSxXQUFXLENBQUMsRUFBRSxFQUFFaEUsSUFBSSxDQUFDO0VBQ2pDLE1BQU1nSixXQUFXLEdBQUd4SixZQUFZLENBQUNGLFlBQVksQ0FBQ3VKLGFBQWEsQ0FBQ2xGLE9BQU8sQ0FBQyxFQUFFckUsWUFBWSxDQUFDd0osU0FBUyxDQUFDbkYsT0FBTyxDQUFDLENBQUM7RUFDdEcsSUFBSXFGLFdBQVcsQ0FBQy9DLE1BQU0sS0FBSyxDQUFDLEVBQUU7SUFDNUJ2QixPQUFPLENBQUNrQixHQUFHLENBQUMsS0FBSzNCLElBQUksb0ZBQW9GLENBQUM7RUFDNUcsQ0FBQyxNQUFNO0lBQ0xTLE9BQU8sQ0FBQ0MsS0FBSyxDQUNYLFlBQVlWLElBQUksMkZBQTJGLEdBQ3pHLE1BQU0rRSxXQUFXLENBQUMvQyxNQUFNLGdHQUM1QixDQUFDO0lBQ0QsS0FBSyxNQUFNWSxDQUFDLElBQUltQyxXQUFXLENBQUNDLEtBQUssQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUU7TUFDeEMsTUFBTUMsS0FBSyxHQUFJQyxDQUFDLElBQU1BLENBQUMsS0FBSyxVQUFVLEdBQUdBLENBQUMsR0FBRyxHQUFHQSxDQUFDLENBQUNGLEtBQUssQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLEdBQUk7TUFDbEV2RSxPQUFPLENBQUNDLEtBQUssQ0FBQyxLQUFLa0MsQ0FBQyxDQUFDaEYsSUFBSSxlQUFlcUgsS0FBSyxDQUFDckMsQ0FBQyxDQUFDMUYsU0FBUyxDQUFDLFdBQVcrSCxLQUFLLENBQUNyQyxDQUFDLENBQUN6RixLQUFLLENBQUMsRUFBRSxDQUFDO0lBQ3hGO0lBQ0EsSUFBSTRILFdBQVcsQ0FBQy9DLE1BQU0sR0FBRyxFQUFFLEVBQUV2QixPQUFPLENBQUNDLEtBQUssQ0FBQyxVQUFVcUUsV0FBVyxDQUFDL0MsTUFBTSxHQUFHLEVBQUUsUUFBUSxDQUFDO0lBQ3JGOEMsUUFBUSxHQUFHLENBQUM7RUFDZDtBQUNGLENBQUMsQ0FBQyxPQUFPMUUsQ0FBQyxFQUFFO0VBQ1Y7RUFDQTtFQUNBMEUsUUFBUSxHQUFHekUsZ0JBQWdCLENBQ3pCLDRCQUE0QixFQUM1QkQsQ0FBQyxZQUFZTixLQUFLLEdBQUdNLENBQUMsQ0FBQ2lELE9BQU8sR0FBRzhCLE1BQU0sQ0FBQy9FLENBQUMsQ0FBQyxFQUMxQ0ksU0FDRixDQUFDO0FBQ0gsQ0FBQyxTQUFTO0VBQ1IsS0FBSyxNQUFNNEUsSUFBSSxJQUFJLENBQUNSLGFBQWEsRUFBRUMsU0FBUyxDQUFDLEVBQUU7SUFDN0MsSUFBSU8sSUFBSSxFQUFFLElBQUE3RixjQUFNLEVBQUM2RixJQUFJLENBQUNuRyxHQUFHLEVBQUU7TUFBRU8sU0FBUyxFQUFFLElBQUk7TUFBRUMsS0FBSyxFQUFFO0lBQUssQ0FBQyxDQUFDO0VBQzlEO0FBQ0Y7QUFDQThFLE9BQU8sQ0FBQ0UsSUFBSSxDQUFDSyxRQUFRLENBQUMiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}