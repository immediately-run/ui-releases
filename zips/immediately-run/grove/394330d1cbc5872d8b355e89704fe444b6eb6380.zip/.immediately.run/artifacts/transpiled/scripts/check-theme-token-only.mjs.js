var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {#!/usr/bin/env node
// check-theme-token-only.mjs — R3-310 (02-theme-contract §1): a theme file
// declares custom properties and NOTHING ELSE. No selectors beyond the theme's
// own root scoping, no `url(`, no `@import`, no `@font-face` — faces arrive as
// DECLARED assets the engine mints (R3-315), never as a location a theme names.
//
// WHY A SCRIPT. The token-only rule is what makes "CSS-only re-skin over the
// same DOM" true rather than aspirational, and a contributed theme reviewable in
// one screen — the adversarial exit plants a `url(`/`@import`/`@font-face` in a
// theme and requires the gate to fail. Prose cannot fail a build
// (ways_of_working §4).
//
// WHAT IT READS. The `[data-grove-theme=…]` blocks in src/GroveApp.css: each
// block's declaration list must be custom properties only.
//
// FAULT INJECTION. `--self-test` plants each violation and asserts the checker
// rejects it for the reason claimed.
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.themeViolations = themeViolations;
var _nodeFs = require("node:fs");
var _nodeUrl = require("node:url");
var _nodePath = require("node:path");
const root = (0, _nodePath.join)((0, _nodePath.dirname)((0, _nodeUrl.fileURLToPath)($ir_import_meta.url)), '..');
const CSS_PATH = (0, _nodePath.join)(root, 'src', 'GroveApp.css');

/** The violations in one theme-block text. Exported shape for the self-test. */
function themeViolations(css) {
  const out = [];
  const blockRe = /\.grove-root\[data-grove-theme="[^"]+"\]([^\{]*)\{/g;
  let m;
  while ((m = blockRe.exec(css)) !== null) {
    const selectorSuffix = m[1];
    // The block's body: track braces to find the matching close.
    let depth = 1;
    let end = blockRe.lastIndex;
    while (end < css.length && depth > 0) {
      if (css[end] === '{') depth++;else if (css[end] === '}') depth--;
      end++;
    }
    const body = css.slice(blockRe.lastIndex, end - 1);
    const label = `data-grove-theme block at ${m.index}`;
    // A theme block may carry its polarity pairing ([data-theme=…]) and nothing
    // else — any further compound selector is a component reaching into the
    // theme, which is the fork-with-a-friendly-name failure.
    if (!/^\s*(\[data-theme="[^"]+"\])?\s*$/.test(selectorSuffix)) {
      out.push({
        theme: label,
        why: `unexpected selector suffix: ${selectorSuffix.trim()}`
      });
    }
    if (/@import|@font-face|url\(/i.test(body)) {
      out.push({
        theme: label,
        why: 'theme names a location or rule (url(/@import/@font-face) — faces are declared assets, not URLs'
      });
    }
    for (const line of body.split('\n')) {
      const decl = line.replace(/\/\*.*?\*\//g, '').trim();
      if (!decl || decl.startsWith('/*') || decl === '') continue;
      if (!/^--[\w-]+\s*:/.test(decl)) {
        out.push({
          theme: label,
          why: `non-token declaration: ${decl.slice(0, 60)}`
        });
      }
    }
  }
  return out;
}
function run() {
  const css = (0, _nodeFs.readFileSync)(CSS_PATH, 'utf8');
  const v = themeViolations(css);
  if (v.length > 0) {
    console.error(`✗ check-theme-token-only: ${v.length} violation(s) in the catalogue themes:`);
    for (const {
      theme,
      why
    } of v) console.error(`  ${theme}: ${why}`);
    process.exit(1);
  }
  console.log('OK: every catalogue theme block is token-only (custom properties, nothing else).');
}
function selfTest() {
  let ok = 0;
  const check = (name, cond) => {
    console.log(`${cond ? 'PASS' : 'FAIL'}  ${name}`);
    if (cond) ok++;
  };
  check('a clean token block passes', themeViolations('.grove-root[data-grove-theme="x"] {\n  --bg: #111;\n}\n').length === 0);
  check('a polarity-paired block passes', themeViolations('.grove-root[data-grove-theme="x"][data-theme="dark"] {\n  --bg: #111;\n}\n').length === 0);
  check('a planted url( fails', themeViolations('.grove-root[data-grove-theme="x"] {\n  --wash: url(paper.jpg);\n}\n').length === 1);
  check('a planted @font-face fails', themeViolations('.grove-root[data-grove-theme="x"] {\n  @font-face { src: url(a.woff2); }\n}\n').length >= 1);
  check('a planted @import fails', themeViolations('.grove-root[data-grove-theme="x"] {\n  @import url(x.css);\n}\n').length >= 1);
  check('a non-token rule fails', themeViolations('.grove-root[data-grove-theme="x"] {\n  .sidebar { display: none; }\n}\n').length >= 1);
  check('a compound component selector fails', themeViolations('.grove-root[data-grove-theme="x"] .sidebar {\n  --bg: #111;\n}\n').length === 1);
  console.log(`\n${ok}/7 self-test cases.`);
  if (ok !== 7) process.exit(1);
}
if (process.argv.includes('--self-test')) selfTest();else run();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJPYmplY3QiLCJkZWZpbmVQcm9wZXJ0eSIsImV4cG9ydHMiLCJ2YWx1ZSIsInRoZW1lVmlvbGF0aW9ucyIsIl9ub2RlRnMiLCJyZXF1aXJlIiwiX25vZGVVcmwiLCJfbm9kZVBhdGgiLCJyb290Iiwiam9pbiIsImRpcm5hbWUiLCJmaWxlVVJMVG9QYXRoIiwiJGlyX2ltcG9ydF9tZXRhIiwidXJsIiwiQ1NTX1BBVEgiLCJjc3MiLCJvdXQiLCJibG9ja1JlIiwibSIsImV4ZWMiLCJzZWxlY3RvclN1ZmZpeCIsImRlcHRoIiwiZW5kIiwibGFzdEluZGV4IiwibGVuZ3RoIiwiYm9keSIsInNsaWNlIiwibGFiZWwiLCJpbmRleCIsInRlc3QiLCJwdXNoIiwidGhlbWUiLCJ3aHkiLCJ0cmltIiwibGluZSIsInNwbGl0IiwiZGVjbCIsInJlcGxhY2UiLCJzdGFydHNXaXRoIiwicnVuIiwicmVhZEZpbGVTeW5jIiwidiIsImNvbnNvbGUiLCJlcnJvciIsInByb2Nlc3MiLCJleGl0IiwibG9nIiwic2VsZlRlc3QiLCJvayIsImNoZWNrIiwibmFtZSIsImNvbmQiLCJhcmd2IiwiaW5jbHVkZXMiXSwic291cmNlcyI6WyJjaGVjay10aGVtZS10b2tlbi1vbmx5Lm1qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIjIS91c3IvYmluL2VudiBub2RlXG4vLyBjaGVjay10aGVtZS10b2tlbi1vbmx5Lm1qcyDigJQgUjMtMzEwICgwMi10aGVtZS1jb250cmFjdCDCpzEpOiBhIHRoZW1lIGZpbGVcbi8vIGRlY2xhcmVzIGN1c3RvbSBwcm9wZXJ0aWVzIGFuZCBOT1RISU5HIEVMU0UuIE5vIHNlbGVjdG9ycyBiZXlvbmQgdGhlIHRoZW1lJ3Ncbi8vIG93biByb290IHNjb3BpbmcsIG5vIGB1cmwoYCwgbm8gYEBpbXBvcnRgLCBubyBgQGZvbnQtZmFjZWAg4oCUIGZhY2VzIGFycml2ZSBhc1xuLy8gREVDTEFSRUQgYXNzZXRzIHRoZSBlbmdpbmUgbWludHMgKFIzLTMxNSksIG5ldmVyIGFzIGEgbG9jYXRpb24gYSB0aGVtZSBuYW1lcy5cbi8vXG4vLyBXSFkgQSBTQ1JJUFQuIFRoZSB0b2tlbi1vbmx5IHJ1bGUgaXMgd2hhdCBtYWtlcyBcIkNTUy1vbmx5IHJlLXNraW4gb3ZlciB0aGVcbi8vIHNhbWUgRE9NXCIgdHJ1ZSByYXRoZXIgdGhhbiBhc3BpcmF0aW9uYWwsIGFuZCBhIGNvbnRyaWJ1dGVkIHRoZW1lIHJldmlld2FibGUgaW5cbi8vIG9uZSBzY3JlZW4g4oCUIHRoZSBhZHZlcnNhcmlhbCBleGl0IHBsYW50cyBhIGB1cmwoYC9gQGltcG9ydGAvYEBmb250LWZhY2VgIGluIGFcbi8vIHRoZW1lIGFuZCByZXF1aXJlcyB0aGUgZ2F0ZSB0byBmYWlsLiBQcm9zZSBjYW5ub3QgZmFpbCBhIGJ1aWxkXG4vLyAod2F5c19vZl93b3JraW5nIMKnNCkuXG4vL1xuLy8gV0hBVCBJVCBSRUFEUy4gVGhlIGBbZGF0YS1ncm92ZS10aGVtZT3igKZdYCBibG9ja3MgaW4gc3JjL0dyb3ZlQXBwLmNzczogZWFjaFxuLy8gYmxvY2sncyBkZWNsYXJhdGlvbiBsaXN0IG11c3QgYmUgY3VzdG9tIHByb3BlcnRpZXMgb25seS5cbi8vXG4vLyBGQVVMVCBJTkpFQ1RJT04uIGAtLXNlbGYtdGVzdGAgcGxhbnRzIGVhY2ggdmlvbGF0aW9uIGFuZCBhc3NlcnRzIHRoZSBjaGVja2VyXG4vLyByZWplY3RzIGl0IGZvciB0aGUgcmVhc29uIGNsYWltZWQuXG5pbXBvcnQgeyByZWFkRmlsZVN5bmMgfSBmcm9tICdub2RlOmZzJztcbmltcG9ydCB7IGZpbGVVUkxUb1BhdGggfSBmcm9tICdub2RlOnVybCc7XG5pbXBvcnQgeyBkaXJuYW1lLCBqb2luIH0gZnJvbSAnbm9kZTpwYXRoJztcblxuY29uc3Qgcm9vdCA9IGpvaW4oZGlybmFtZShmaWxlVVJMVG9QYXRoKGltcG9ydC5tZXRhLnVybCkpLCAnLi4nKTtcbmNvbnN0IENTU19QQVRIID0gam9pbihyb290LCAnc3JjJywgJ0dyb3ZlQXBwLmNzcycpO1xuXG4vKiogVGhlIHZpb2xhdGlvbnMgaW4gb25lIHRoZW1lLWJsb2NrIHRleHQuIEV4cG9ydGVkIHNoYXBlIGZvciB0aGUgc2VsZi10ZXN0LiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRoZW1lVmlvbGF0aW9ucyhjc3MpIHtcbiAgY29uc3Qgb3V0ID0gW107XG4gIGNvbnN0IGJsb2NrUmUgPSAvXFwuZ3JvdmUtcm9vdFxcW2RhdGEtZ3JvdmUtdGhlbWU9XCJbXlwiXStcIlxcXShbXlxce10qKVxcey9nO1xuICBsZXQgbTtcbiAgd2hpbGUgKChtID0gYmxvY2tSZS5leGVjKGNzcykpICE9PSBudWxsKSB7XG4gICAgY29uc3Qgc2VsZWN0b3JTdWZmaXggPSBtWzFdO1xuICAgIC8vIFRoZSBibG9jaydzIGJvZHk6IHRyYWNrIGJyYWNlcyB0byBmaW5kIHRoZSBtYXRjaGluZyBjbG9zZS5cbiAgICBsZXQgZGVwdGggPSAxO1xuICAgIGxldCBlbmQgPSBibG9ja1JlLmxhc3RJbmRleDtcbiAgICB3aGlsZSAoZW5kIDwgY3NzLmxlbmd0aCAmJiBkZXB0aCA+IDApIHtcbiAgICAgIGlmIChjc3NbZW5kXSA9PT0gJ3snKSBkZXB0aCsrO1xuICAgICAgZWxzZSBpZiAoY3NzW2VuZF0gPT09ICd9JykgZGVwdGgtLTtcbiAgICAgIGVuZCsrO1xuICAgIH1cbiAgICBjb25zdCBib2R5ID0gY3NzLnNsaWNlKGJsb2NrUmUubGFzdEluZGV4LCBlbmQgLSAxKTtcbiAgICBjb25zdCBsYWJlbCA9IGBkYXRhLWdyb3ZlLXRoZW1lIGJsb2NrIGF0ICR7bS5pbmRleH1gO1xuICAgIC8vIEEgdGhlbWUgYmxvY2sgbWF5IGNhcnJ5IGl0cyBwb2xhcml0eSBwYWlyaW5nIChbZGF0YS10aGVtZT3igKZdKSBhbmQgbm90aGluZ1xuICAgIC8vIGVsc2Ug4oCUIGFueSBmdXJ0aGVyIGNvbXBvdW5kIHNlbGVjdG9yIGlzIGEgY29tcG9uZW50IHJlYWNoaW5nIGludG8gdGhlXG4gICAgLy8gdGhlbWUsIHdoaWNoIGlzIHRoZSBmb3JrLXdpdGgtYS1mcmllbmRseS1uYW1lIGZhaWx1cmUuXG4gICAgaWYgKCEvXlxccyooXFxbZGF0YS10aGVtZT1cIlteXCJdK1wiXFxdKT9cXHMqJC8udGVzdChzZWxlY3RvclN1ZmZpeCkpIHtcbiAgICAgIG91dC5wdXNoKHsgdGhlbWU6IGxhYmVsLCB3aHk6IGB1bmV4cGVjdGVkIHNlbGVjdG9yIHN1ZmZpeDogJHtzZWxlY3RvclN1ZmZpeC50cmltKCl9YCB9KTtcbiAgICB9XG4gICAgaWYgKC9AaW1wb3J0fEBmb250LWZhY2V8dXJsXFwoL2kudGVzdChib2R5KSkge1xuICAgICAgb3V0LnB1c2goeyB0aGVtZTogbGFiZWwsIHdoeTogJ3RoZW1lIG5hbWVzIGEgbG9jYXRpb24gb3IgcnVsZSAodXJsKC9AaW1wb3J0L0Bmb250LWZhY2UpIOKAlCBmYWNlcyBhcmUgZGVjbGFyZWQgYXNzZXRzLCBub3QgVVJMcycgfSk7XG4gICAgfVxuICAgIGZvciAoY29uc3QgbGluZSBvZiBib2R5LnNwbGl0KCdcXG4nKSkge1xuICAgICAgY29uc3QgZGVjbCA9IGxpbmUucmVwbGFjZSgvXFwvXFwqLio/XFwqXFwvL2csICcnKS50cmltKCk7XG4gICAgICBpZiAoIWRlY2wgfHwgZGVjbC5zdGFydHNXaXRoKCcvKicpIHx8IGRlY2wgPT09ICcnKSBjb250aW51ZTtcbiAgICAgIGlmICghL14tLVtcXHctXStcXHMqOi8udGVzdChkZWNsKSkge1xuICAgICAgICBvdXQucHVzaCh7IHRoZW1lOiBsYWJlbCwgd2h5OiBgbm9uLXRva2VuIGRlY2xhcmF0aW9uOiAke2RlY2wuc2xpY2UoMCwgNjApfWAgfSk7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIHJldHVybiBvdXQ7XG59XG5cbmZ1bmN0aW9uIHJ1bigpIHtcbiAgY29uc3QgY3NzID0gcmVhZEZpbGVTeW5jKENTU19QQVRILCAndXRmOCcpO1xuICBjb25zdCB2ID0gdGhlbWVWaW9sYXRpb25zKGNzcyk7XG4gIGlmICh2Lmxlbmd0aCA+IDApIHtcbiAgICBjb25zb2xlLmVycm9yKGDinJcgY2hlY2stdGhlbWUtdG9rZW4tb25seTogJHt2Lmxlbmd0aH0gdmlvbGF0aW9uKHMpIGluIHRoZSBjYXRhbG9ndWUgdGhlbWVzOmApO1xuICAgIGZvciAoY29uc3QgeyB0aGVtZSwgd2h5IH0gb2YgdikgY29uc29sZS5lcnJvcihgICAke3RoZW1lfTogJHt3aHl9YCk7XG4gICAgcHJvY2Vzcy5leGl0KDEpO1xuICB9XG4gIGNvbnNvbGUubG9nKCdPSzogZXZlcnkgY2F0YWxvZ3VlIHRoZW1lIGJsb2NrIGlzIHRva2VuLW9ubHkgKGN1c3RvbSBwcm9wZXJ0aWVzLCBub3RoaW5nIGVsc2UpLicpO1xufVxuXG5mdW5jdGlvbiBzZWxmVGVzdCgpIHtcbiAgbGV0IG9rID0gMDtcbiAgY29uc3QgY2hlY2sgPSAobmFtZSwgY29uZCkgPT4ge1xuICAgIGNvbnNvbGUubG9nKGAke2NvbmQgPyAnUEFTUycgOiAnRkFJTCd9ICAke25hbWV9YCk7XG4gICAgaWYgKGNvbmQpIG9rKys7XG4gIH07XG4gIGNoZWNrKCdhIGNsZWFuIHRva2VuIGJsb2NrIHBhc3NlcycsIHRoZW1lVmlvbGF0aW9ucygnLmdyb3ZlLXJvb3RbZGF0YS1ncm92ZS10aGVtZT1cInhcIl0ge1xcbiAgLS1iZzogIzExMTtcXG59XFxuJykubGVuZ3RoID09PSAwKTtcbiAgY2hlY2soJ2EgcG9sYXJpdHktcGFpcmVkIGJsb2NrIHBhc3NlcycsIHRoZW1lVmlvbGF0aW9ucygnLmdyb3ZlLXJvb3RbZGF0YS1ncm92ZS10aGVtZT1cInhcIl1bZGF0YS10aGVtZT1cImRhcmtcIl0ge1xcbiAgLS1iZzogIzExMTtcXG59XFxuJykubGVuZ3RoID09PSAwKTtcbiAgY2hlY2soJ2EgcGxhbnRlZCB1cmwoIGZhaWxzJywgdGhlbWVWaW9sYXRpb25zKCcuZ3JvdmUtcm9vdFtkYXRhLWdyb3ZlLXRoZW1lPVwieFwiXSB7XFxuICAtLXdhc2g6IHVybChwYXBlci5qcGcpO1xcbn1cXG4nKS5sZW5ndGggPT09IDEpO1xuICBjaGVjaygnYSBwbGFudGVkIEBmb250LWZhY2UgZmFpbHMnLCB0aGVtZVZpb2xhdGlvbnMoJy5ncm92ZS1yb290W2RhdGEtZ3JvdmUtdGhlbWU9XCJ4XCJdIHtcXG4gIEBmb250LWZhY2UgeyBzcmM6IHVybChhLndvZmYyKTsgfVxcbn1cXG4nKS5sZW5ndGggPj0gMSk7XG4gIGNoZWNrKCdhIHBsYW50ZWQgQGltcG9ydCBmYWlscycsIHRoZW1lVmlvbGF0aW9ucygnLmdyb3ZlLXJvb3RbZGF0YS1ncm92ZS10aGVtZT1cInhcIl0ge1xcbiAgQGltcG9ydCB1cmwoeC5jc3MpO1xcbn1cXG4nKS5sZW5ndGggPj0gMSk7XG4gIGNoZWNrKCdhIG5vbi10b2tlbiBydWxlIGZhaWxzJywgdGhlbWVWaW9sYXRpb25zKCcuZ3JvdmUtcm9vdFtkYXRhLWdyb3ZlLXRoZW1lPVwieFwiXSB7XFxuICAuc2lkZWJhciB7IGRpc3BsYXk6IG5vbmU7IH1cXG59XFxuJykubGVuZ3RoID49IDEpO1xuICBjaGVjaygnYSBjb21wb3VuZCBjb21wb25lbnQgc2VsZWN0b3IgZmFpbHMnLCB0aGVtZVZpb2xhdGlvbnMoJy5ncm92ZS1yb290W2RhdGEtZ3JvdmUtdGhlbWU9XCJ4XCJdIC5zaWRlYmFyIHtcXG4gIC0tYmc6ICMxMTE7XFxufVxcbicpLmxlbmd0aCA9PT0gMSk7XG4gIGNvbnNvbGUubG9nKGBcXG4ke29rfS83IHNlbGYtdGVzdCBjYXNlcy5gKTtcbiAgaWYgKG9rICE9PSA3KSBwcm9jZXNzLmV4aXQoMSk7XG59XG5cbmlmIChwcm9jZXNzLmFyZ3YuaW5jbHVkZXMoJy0tc2VsZi10ZXN0JykpIHNlbGZUZXN0KCk7XG5lbHNlIHJ1bigpO1xuIl0sIm1hcHBpbmdzIjoiQUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQUE7O0FBQUFBLE1BQUEsQ0FBQUMsY0FBQSxDQUFBQyxPQUFBO0VBQUFDLEtBQUE7QUFBQTtBQUFBRCxPQUFBLENBQUFFLGVBQUEsR0FBQUEsZUFBQTtBQUNBLElBQUFDLE9BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLFFBQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLFNBQUEsR0FBQUYsT0FBQTtBQUVBLE1BQU1HLElBQUksR0FBRyxJQUFBQyxjQUFJLEVBQUMsSUFBQUMsaUJBQU8sRUFBQyxJQUFBQyxzQkFBYSxFQUFDQyxlQUFBLENBQVlDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDO0FBQ2hFLE1BQU1DLFFBQVEsR0FBRyxJQUFBTCxjQUFJLEVBQUNELElBQUksRUFBRSxLQUFLLEVBQUUsY0FBYyxDQUFDOztBQUVsRDtBQUNPLFNBQVNMLGVBQWVBLENBQUNZLEdBQUcsRUFBRTtFQUNuQyxNQUFNQyxHQUFHLEdBQUcsRUFBRTtFQUNkLE1BQU1DLE9BQU8sR0FBRyxxREFBcUQ7RUFDckUsSUFBSUMsQ0FBQztFQUNMLE9BQU8sQ0FBQ0EsQ0FBQyxHQUFHRCxPQUFPLENBQUNFLElBQUksQ0FBQ0osR0FBRyxDQUFDLE1BQU0sSUFBSSxFQUFFO0lBQ3ZDLE1BQU1LLGNBQWMsR0FBR0YsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUMzQjtJQUNBLElBQUlHLEtBQUssR0FBRyxDQUFDO0lBQ2IsSUFBSUMsR0FBRyxHQUFHTCxPQUFPLENBQUNNLFNBQVM7SUFDM0IsT0FBT0QsR0FBRyxHQUFHUCxHQUFHLENBQUNTLE1BQU0sSUFBSUgsS0FBSyxHQUFHLENBQUMsRUFBRTtNQUNwQyxJQUFJTixHQUFHLENBQUNPLEdBQUcsQ0FBQyxLQUFLLEdBQUcsRUFBRUQsS0FBSyxFQUFFLENBQUMsS0FDekIsSUFBSU4sR0FBRyxDQUFDTyxHQUFHLENBQUMsS0FBSyxHQUFHLEVBQUVELEtBQUssRUFBRTtNQUNsQ0MsR0FBRyxFQUFFO0lBQ1A7SUFDQSxNQUFNRyxJQUFJLEdBQUdWLEdBQUcsQ0FBQ1csS0FBSyxDQUFDVCxPQUFPLENBQUNNLFNBQVMsRUFBRUQsR0FBRyxHQUFHLENBQUMsQ0FBQztJQUNsRCxNQUFNSyxLQUFLLEdBQUcsNkJBQTZCVCxDQUFDLENBQUNVLEtBQUssRUFBRTtJQUNwRDtJQUNBO0lBQ0E7SUFDQSxJQUFJLENBQUMsbUNBQW1DLENBQUNDLElBQUksQ0FBQ1QsY0FBYyxDQUFDLEVBQUU7TUFDN0RKLEdBQUcsQ0FBQ2MsSUFBSSxDQUFDO1FBQUVDLEtBQUssRUFBRUosS0FBSztRQUFFSyxHQUFHLEVBQUUsK0JBQStCWixjQUFjLENBQUNhLElBQUksQ0FBQyxDQUFDO01BQUcsQ0FBQyxDQUFDO0lBQ3pGO0lBQ0EsSUFBSSwyQkFBMkIsQ0FBQ0osSUFBSSxDQUFDSixJQUFJLENBQUMsRUFBRTtNQUMxQ1QsR0FBRyxDQUFDYyxJQUFJLENBQUM7UUFBRUMsS0FBSyxFQUFFSixLQUFLO1FBQUVLLEdBQUcsRUFBRTtNQUFpRyxDQUFDLENBQUM7SUFDbkk7SUFDQSxLQUFLLE1BQU1FLElBQUksSUFBSVQsSUFBSSxDQUFDVSxLQUFLLENBQUMsSUFBSSxDQUFDLEVBQUU7TUFDbkMsTUFBTUMsSUFBSSxHQUFHRixJQUFJLENBQUNHLE9BQU8sQ0FBQyxjQUFjLEVBQUUsRUFBRSxDQUFDLENBQUNKLElBQUksQ0FBQyxDQUFDO01BQ3BELElBQUksQ0FBQ0csSUFBSSxJQUFJQSxJQUFJLENBQUNFLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSUYsSUFBSSxLQUFLLEVBQUUsRUFBRTtNQUNuRCxJQUFJLENBQUMsZUFBZSxDQUFDUCxJQUFJLENBQUNPLElBQUksQ0FBQyxFQUFFO1FBQy9CcEIsR0FBRyxDQUFDYyxJQUFJLENBQUM7VUFBRUMsS0FBSyxFQUFFSixLQUFLO1VBQUVLLEdBQUcsRUFBRSwwQkFBMEJJLElBQUksQ0FBQ1YsS0FBSyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUM7UUFBRyxDQUFDLENBQUM7TUFDaEY7SUFDRjtFQUNGO0VBQ0EsT0FBT1YsR0FBRztBQUNaO0FBRUEsU0FBU3VCLEdBQUdBLENBQUEsRUFBRztFQUNiLE1BQU14QixHQUFHLEdBQUcsSUFBQXlCLG9CQUFZLEVBQUMxQixRQUFRLEVBQUUsTUFBTSxDQUFDO0VBQzFDLE1BQU0yQixDQUFDLEdBQUd0QyxlQUFlLENBQUNZLEdBQUcsQ0FBQztFQUM5QixJQUFJMEIsQ0FBQyxDQUFDakIsTUFBTSxHQUFHLENBQUMsRUFBRTtJQUNoQmtCLE9BQU8sQ0FBQ0MsS0FBSyxDQUFDLDZCQUE2QkYsQ0FBQyxDQUFDakIsTUFBTSx3Q0FBd0MsQ0FBQztJQUM1RixLQUFLLE1BQU07TUFBRU8sS0FBSztNQUFFQztJQUFJLENBQUMsSUFBSVMsQ0FBQyxFQUFFQyxPQUFPLENBQUNDLEtBQUssQ0FBQyxLQUFLWixLQUFLLEtBQUtDLEdBQUcsRUFBRSxDQUFDO0lBQ25FWSxPQUFPLENBQUNDLElBQUksQ0FBQyxDQUFDLENBQUM7RUFDakI7RUFDQUgsT0FBTyxDQUFDSSxHQUFHLENBQUMsa0ZBQWtGLENBQUM7QUFDakc7QUFFQSxTQUFTQyxRQUFRQSxDQUFBLEVBQUc7RUFDbEIsSUFBSUMsRUFBRSxHQUFHLENBQUM7RUFDVixNQUFNQyxLQUFLLEdBQUdBLENBQUNDLElBQUksRUFBRUMsSUFBSSxLQUFLO0lBQzVCVCxPQUFPLENBQUNJLEdBQUcsQ0FBQyxHQUFHSyxJQUFJLEdBQUcsTUFBTSxHQUFHLE1BQU0sS0FBS0QsSUFBSSxFQUFFLENBQUM7SUFDakQsSUFBSUMsSUFBSSxFQUFFSCxFQUFFLEVBQUU7RUFDaEIsQ0FBQztFQUNEQyxLQUFLLENBQUMsNEJBQTRCLEVBQUU5QyxlQUFlLENBQUMseURBQXlELENBQUMsQ0FBQ3FCLE1BQU0sS0FBSyxDQUFDLENBQUM7RUFDNUh5QixLQUFLLENBQUMsZ0NBQWdDLEVBQUU5QyxlQUFlLENBQUMsNEVBQTRFLENBQUMsQ0FBQ3FCLE1BQU0sS0FBSyxDQUFDLENBQUM7RUFDbkp5QixLQUFLLENBQUMsc0JBQXNCLEVBQUU5QyxlQUFlLENBQUMscUVBQXFFLENBQUMsQ0FBQ3FCLE1BQU0sS0FBSyxDQUFDLENBQUM7RUFDbEl5QixLQUFLLENBQUMsNEJBQTRCLEVBQUU5QyxlQUFlLENBQUMsK0VBQStFLENBQUMsQ0FBQ3FCLE1BQU0sSUFBSSxDQUFDLENBQUM7RUFDakp5QixLQUFLLENBQUMseUJBQXlCLEVBQUU5QyxlQUFlLENBQUMsaUVBQWlFLENBQUMsQ0FBQ3FCLE1BQU0sSUFBSSxDQUFDLENBQUM7RUFDaEl5QixLQUFLLENBQUMsd0JBQXdCLEVBQUU5QyxlQUFlLENBQUMseUVBQXlFLENBQUMsQ0FBQ3FCLE1BQU0sSUFBSSxDQUFDLENBQUM7RUFDdkl5QixLQUFLLENBQUMscUNBQXFDLEVBQUU5QyxlQUFlLENBQUMsa0VBQWtFLENBQUMsQ0FBQ3FCLE1BQU0sS0FBSyxDQUFDLENBQUM7RUFDOUlrQixPQUFPLENBQUNJLEdBQUcsQ0FBQyxLQUFLRSxFQUFFLHFCQUFxQixDQUFDO0VBQ3pDLElBQUlBLEVBQUUsS0FBSyxDQUFDLEVBQUVKLE9BQU8sQ0FBQ0MsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUMvQjtBQUVBLElBQUlELE9BQU8sQ0FBQ1EsSUFBSSxDQUFDQyxRQUFRLENBQUMsYUFBYSxDQUFDLEVBQUVOLFFBQVEsQ0FBQyxDQUFDLENBQUMsS0FDaERSLEdBQUcsQ0FBQyxDQUFDIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}