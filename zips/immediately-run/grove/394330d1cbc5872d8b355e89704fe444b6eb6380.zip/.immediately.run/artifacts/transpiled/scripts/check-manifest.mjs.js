var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {#!/usr/bin/env node
// The manifest ↔ reality gate (R3-277c: "the manifest is validated against reality — a
// component exported but missing from the manifest, or vice versa, fails the engine's own
// `npm run verify`").
//
// A manifest that drifts from the code is worse than no manifest: a corpus checker would
// flag a component that works, or pass one that does not, and a composing shell would be
// told it may override something that no longer exists. So this runs in `verify`, before
// lint and build, because it is the cheapest of the three and the one whose failure is
// most confusing to debug later.
//
// It reads GROVE_MDX's keys by parsing the module rather than importing it (the module
// pulls in TSX, CSS and the SDK — not loadable from plain node), but it parses the OBJECT
// LITERAL's keys, not a regex over the whole file. That is the distinction R3-277c asks
// for: reformatting `mdxComponents.ts` must not change the outcome.
"use strict";

require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.map.js");
var _nodeFs = require("node:fs");
var _nodeUrl = require("node:url");
var _nodePath = require("node:path");
var _nodeModule = require("node:module");
const root = (0, _nodePath.join)((0, _nodePath.dirname)((0, _nodeUrl.fileURLToPath)($ir_import_meta.url)), '..');
// ajv arrives transitively with eslint (the same arrangement docs' scripts rely on);
// say so when it is absent rather than dying on a bare module-not-found.
const _require = (0, _nodeModule.createRequire)((0, _nodePath.join)(root, 'package.json'));
const Ajv = (() => {
  try {
    return _require('ajv');
  } catch {
    console.error('check-manifest: ajv is not resolvable — it rides with eslint; run npm install.');
    process.exit(1);
  }
})();
const manifest = JSON.parse((0, _nodeFs.readFileSync)((0, _nodePath.join)(root, 'viewer.manifest.json'), 'utf8'));
const source = (0, _nodeFs.readFileSync)((0, _nodePath.join)(root, 'src/mdxComponents.ts'), 'utf8');

/**
 * Strip comments and string literals, replacing each with equivalent-length whitespace so
 * every offset in the result still lines up with the original. Brace-matching MUST run
 * over this and not the raw source: a `}` inside a comment or a string would otherwise end
 * the object literal early, and the failure mode is the worst kind — the gate reports the
 * whole manifest as drifted, which reads as "the manifest is broken" rather than "the
 * scanner is". (Found by planting a `}`-bearing comment; see the reformatting test.)
 */
function blankNonCode(src) {
  const out = src.split('');
  let i = 0;
  const blankTo = end => {
    for (; i < end && i < out.length; i++) if (out[i] !== '\n') out[i] = ' ';
  };
  while (i < src.length) {
    const two = src.slice(i, i + 2);
    if (two === '//') {
      const nl = src.indexOf('\n', i);
      blankTo(nl === -1 ? src.length : nl);
    } else if (two === '/*') {
      const close = src.indexOf('*/', i + 2);
      blankTo(close === -1 ? src.length : close + 2);
    } else if (src[i] === "'" || src[i] === '"' || src[i] === '`') {
      const quote = src[i];
      let j = i + 1;
      while (j < src.length && src[j] !== quote) j += src[j] === '\\' ? 2 : 1;
      blankTo(Math.min(j + 1, src.length));
    } else {
      i++;
    }
  }
  return out.join('');
}

/** The keys of the `export const GROVE_MDX = { … }` object literal, brace-matched over the
 *  comment- and string-blanked source so reformatting cannot change the outcome. */
function groveMdxKeys(rawSrc) {
  const src = blankNonCode(rawSrc);
  const start = src.indexOf('export const GROVE_MDX = {');
  if (start === -1) throw new Error('GROVE_MDX object literal not found in src/mdxComponents.ts');
  const open = src.indexOf('{', start);
  let depth = 0;
  let end = -1;
  for (let j = open; j < src.length; j++) {
    if (src[j] === '{') depth++;else if (src[j] === '}') {
      depth--;
      if (depth === 0) {
        end = j;
        break;
      }
    }
  }
  if (end === -1) throw new Error('GROVE_MDX object literal is unterminated');
  const keys = [];
  let nesting = 0;
  for (const line of src.slice(open + 1, end).split('\n')) {
    // Only TOP-level keys are the vocabulary; a nested object's keys are props, not
    // components.
    const before = nesting;
    for (const ch of line) {
      if (ch === '{' || ch === '[') nesting++;else if (ch === '}' || ch === ']') nesting--;
    }
    if (before !== 0) continue;
    const m = line.match(/^\s*([A-Za-z_$][\w$]*)\s*[,:]/);
    if (m) keys.push(m[1]);
  }
  return keys;
}

// Rule 0 — the manifest validates against the FORMAT schema. This pair lived
// un-checked here for a year (the validation rule existed only in the docs fork's
// port), which is how the schema could lack the `themes`/`pageVariants` blocks the
// manifest already shipped (R3-661): nothing on this side ever read the two together.
// The schema is viewer-generic by contract — a Lodestar-shaped manifest must validate
// through it — so a drift here is a broken promise to every second viewer.
//
// It runs FIRST, and it HALTS: every later rule assumes the shape this one enforces,
// so a rejected manifest reports the schema verdict and stops — never a raw TypeError
// from a rule that trusted the shape (a missing `components`, a null entry, …).
// Extracted pure so the self-test can drive planted manifests through it.
const schema = JSON.parse((0, _nodeFs.readFileSync)((0, _nodePath.join)(root, 'viewer-manifest.schema.json'), 'utf8'));
function schemaErrors(m) {
  const ajv = new Ajv({
    logger: false
  });
  const validate = ajv.compile(schema);
  return validate(m) ? [] : [ajv.errorsText(validate.errors)];
}
{
  const rule0 = schemaErrors(manifest);
  if (rule0.length) {
    console.error(`FAIL manifest ↔ reality (${rule0.length}):\n  manifest fails viewer-manifest.schema.json: ${rule0.join('\n  ')}`);
    process.exit(1);
  }
}
const errors = [];
const exported = new Set(groveMdxKeys(source));
const declared = new Set(Object.keys(manifest.components));
for (const name of exported) {
  if (!declared.has(name)) {
    errors.push(`  ${name} — registered in GROVE_MDX but NOT in the manifest. A corpus can use it and ` + `a checker will flag it; a shell cannot override it. Declare it, or make it internal ` + `by removing it from GROVE_MDX.`);
  }
}
for (const name of declared) {
  if (manifest.components[name].tier === 'corpus') continue; // declared by a corpus, not here
  if (!exported.has(name)) {
    errors.push(`  ${name} — declared in the manifest but NOT registered in GROVE_MDX. A corpus using ` + `it renders nothing, and a shell overriding it overrides a component that never runs.`);
  }
}

// The viewer identity must match the package it ships in, or a shell resolving the
// manifest by package name gets someone else's contract.
const pkg = JSON.parse((0, _nodeFs.readFileSync)((0, _nodePath.join)(root, 'package.json'), 'utf8'));
if (manifest.viewer.name !== pkg.name) {
  errors.push(`  viewer.name "${manifest.viewer.name}" ≠ package.json name "${pkg.name}".`);
}
const provides = (pkg['immediately.run']?.provides ?? []).map(p => p.task);
if (manifest.viewer.task && !provides.includes(manifest.viewer.task)) {
  errors.push(`  viewer.task "${manifest.viewer.task}" is not in package.json immediately.run.provides ` + `(${provides.join(', ') || 'none'}).`);
}

// Every export must be reachable, or a shell's import fails at compose time rather than here.
for (const [subpath, target] of Object.entries(pkg.exports ?? {})) {
  try {
    (0, _nodeFs.readFileSync)((0, _nodePath.join)(root, target));
  } catch {
    errors.push(`  exports["${subpath}"] → ${target} does not exist.`);
  }
}

// ── R3-309 — the layout-catalogue gates ─────────────────────────────────────
//
// The manifest's `layouts` entries and the files under content/_layouts/ must agree
// in BOTH directions (the same two-way rule the components section enforces), and a
// shipping starter's OWN frontmatter must carry the `layoutRole` its entry declares.
// That is the job the field was given: it sat unread in the sample layouts for a
// year, and "an inert field in a file people copy is a field people will copy".

const LAYOUTS_DIR = (0, _nodePath.join)(root, 'content', '_layouts');
const starterIds = (0, _nodeFs.existsSync)(LAYOUTS_DIR) ? (0, _nodeFs.readdirSync)(LAYOUTS_DIR, {
  withFileTypes: true
}).filter(e => e.isFile() && /\.mdx?$/.test(e.name)).map(e => e.name.replace(/\.mdx?$/, '')) : [];

/** The frontmatter block of a starter, as key → value (scalars only — that is all a
 *  starter declares). */
function frontmatterOf(file) {
  const src = (0, _nodeFs.readFileSync)((0, _nodePath.join)(LAYOUTS_DIR, file), 'utf8');
  const m = src.match(/^---\n([\s\S]*?)\n---/);
  const fm = {};
  if (m) for (const line of m[1].split('\n')) {
    const kv = line.match(/^(\w+):\s*(.+)$/);
    if (kv) fm[kv[1]] = kv[2].trim().replace(/^['"]|['"]$/g, '');
  }
  return fm;
}
const declaredLayouts = manifest.layouts ?? {};
for (const [id, entry] of Object.entries(declaredLayouts)) {
  if (entry.ships && !starterIds.includes(id)) {
    errors.push(`  layouts.${id} — declared ships:true but content/_layouts/${id}.mdx does not exist.`);
  }
  if (entry.ships) {
    const fm = frontmatterOf(`${id}.mdx`);
    if (fm.layoutRole !== entry.layoutRole) {
      errors.push(`  layouts.${id} — manifest says layoutRole:${entry.layoutRole}, the starter's frontmatter says ` + `${JSON.stringify(fm.layoutRole)}. The two must agree.`);
    }
    if (fm.nav && fm.nav !== 'top' && fm.nav !== 'side') {
      errors.push(`  layouts.${id} — nav:${fm.nav} is neither 'top' nor 'side'; resolveNavMode would silently fall back.`);
    }
  }
}
for (const id of starterIds) {
  if (!declaredLayouts[id]) {
    errors.push(`  content/_layouts/${id}.mdx — a starter on disk with NO manifest entry. It renders (when ` + `copied) but nothing declares it: a corpus checker cannot find it and an agent cannot discover it.`);
  }
}

// Collection shapes ride on engine components; a declared component that is not in the
// vocabulary is the same lie as an undeclared one in the components section.
const collections = manifest.collections ?? {};
for (const [id, entry] of Object.entries(collections)) {
  if (entry.component && !exported.has(entry.component)) {
    errors.push(`  collections.${id} — rides on "${entry.component}", which is not registered in GROVE_MDX. ` + `A corpus writing the documented call renders nothing.`);
  }
  for (const [prop, value] of Object.entries(entry.props ?? {})) {
    if (/^\{.*\}$/.test(value)) {
      errors.push(`  collections.${id} — props.${prop} is an EXPRESSION (${value}). The interpreter drops it silently.`);
    }
  }
}
if (errors.length) {
  console.error(`FAIL manifest ↔ reality (${errors.length}):\n${errors.join('\n')}`);
  process.exit(1);
}
console.log(`OK ${manifest.viewer.name}: ${declared.size} components declared, ` + `${[...declared].filter(n => manifest.components[n].overridable).length} overridable, ` + `${Object.keys(pkg.exports ?? {}).length} export subpaths resolve, ` + `${starterIds.length} layout starter(s), ${Object.keys(collections).length} collection shape(s).`);

// ── self-test ─────────────────────────────────────────────────────────────────
// Rule 0's teeth, planted rather than asserted (the reviewer was right to demand the
// committed form of the manual fault injection): a gate nothing has watched reject
// anything is an assumption. Driven through `schemaErrors` — the same function the
// gate runs — so the cases move when the rule does.
const selfTest = () => {
  const cases = [];
  cases.push(['the shipped pair validates', () => schemaErrors(manifest).length === 0]);
  cases.push(['a planted top-level key fails', () => schemaErrors({
    ...manifest,
    bogusKey: 'x'
  }).length > 0]);
  cases.push(['a manifest missing components fails with the schema verdict, not a crash', () => {
    const {
      components,
      ...rest
    } = manifest;
    return schemaErrors(rest).length > 0;
  }]);
  // The viewer-generic contract (spec §5.1): a Lodestar-shaped manifest — node/edge
  // vocabulary, its own themes — validates through the same schema.
  const lodestar = {
    schemaVersion: 1,
    viewer: {
      name: '@fictional/lodestar',
      kind: 'mindmap',
      task: 'open-mindmap'
    },
    components: {
      MindNode: {
        tier: 'engine',
        overridable: true,
        sanitizing: false,
        props: {
          label: 'string?',
          depth: 'number?'
        },
        summary: 'A node.'
      },
      MindEdge: {
        tier: 'engine',
        overridable: true,
        sanitizing: false,
        props: {
          from: 'string',
          to: 'string'
        },
        summary: 'An edge.'
      },
      Legend: {
        tier: 'chrome',
        overridable: true,
        sanitizing: false,
        props: {},
        summary: 'Map chrome.'
      },
      RiskBadge: {
        tier: 'corpus',
        overridable: true,
        sanitizing: false,
        props: {},
        summary: 'One corpus convention.'
      }
    },
    frontmatter: {
      engine: ['view', 'collapsed'],
      corpusTooling: ['risk'],
      passThrough: true
    }
  };
  cases.push(['a Lodestar manifest validates through the same schema', () => schemaErrors(lodestar).length === 0]);
  cases.push(['a manifest with an unknown tier is rejected', () => schemaErrors({
    ...lodestar,
    components: {
      X: {
        tier: 'galaxy',
        overridable: true
      }
    }
  }).length > 0]);
  let failed = 0;
  for (const [name, fn] of cases) {
    let pass = false;
    try {
      pass = fn();
    } catch {
      pass = false;
    }
    console.log(`${pass ? '✓' : '✗'} ${name}`);
    if (!pass) failed++;
  }
  console.log(`\n${cases.length - failed}/${cases.length} self-test cases.`);
  return failed === 0;
};
if (process.argv.includes('--self-test')) process.exit(selfTest() ? 0 : 1);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJyZXF1aXJlIiwiX25vZGVGcyIsIl9ub2RlVXJsIiwiX25vZGVQYXRoIiwiX25vZGVNb2R1bGUiLCJyb290Iiwiam9pbiIsImRpcm5hbWUiLCJmaWxlVVJMVG9QYXRoIiwiJGlyX2ltcG9ydF9tZXRhIiwidXJsIiwiY3JlYXRlUmVxdWlyZSIsIkFqdiIsImNvbnNvbGUiLCJlcnJvciIsInByb2Nlc3MiLCJleGl0IiwibWFuaWZlc3QiLCJKU09OIiwicGFyc2UiLCJyZWFkRmlsZVN5bmMiLCJzb3VyY2UiLCJibGFua05vbkNvZGUiLCJzcmMiLCJvdXQiLCJzcGxpdCIsImkiLCJibGFua1RvIiwiZW5kIiwibGVuZ3RoIiwidHdvIiwic2xpY2UiLCJubCIsImluZGV4T2YiLCJjbG9zZSIsInF1b3RlIiwiaiIsIk1hdGgiLCJtaW4iLCJncm92ZU1keEtleXMiLCJyYXdTcmMiLCJzdGFydCIsIkVycm9yIiwib3BlbiIsImRlcHRoIiwia2V5cyIsIm5lc3RpbmciLCJsaW5lIiwiYmVmb3JlIiwiY2giLCJtIiwibWF0Y2giLCJwdXNoIiwic2NoZW1hIiwic2NoZW1hRXJyb3JzIiwiYWp2IiwibG9nZ2VyIiwidmFsaWRhdGUiLCJjb21waWxlIiwiZXJyb3JzVGV4dCIsImVycm9ycyIsInJ1bGUwIiwiZXhwb3J0ZWQiLCJTZXQiLCJkZWNsYXJlZCIsIk9iamVjdCIsImNvbXBvbmVudHMiLCJuYW1lIiwiaGFzIiwidGllciIsInBrZyIsInZpZXdlciIsInByb3ZpZGVzIiwibWFwIiwicCIsInRhc2siLCJpbmNsdWRlcyIsInN1YnBhdGgiLCJ0YXJnZXQiLCJlbnRyaWVzIiwiZXhwb3J0cyIsIkxBWU9VVFNfRElSIiwic3RhcnRlcklkcyIsImV4aXN0c1N5bmMiLCJyZWFkZGlyU3luYyIsIndpdGhGaWxlVHlwZXMiLCJmaWx0ZXIiLCJlIiwiaXNGaWxlIiwidGVzdCIsInJlcGxhY2UiLCJmcm9udG1hdHRlck9mIiwiZmlsZSIsImZtIiwia3YiLCJ0cmltIiwiZGVjbGFyZWRMYXlvdXRzIiwibGF5b3V0cyIsImlkIiwiZW50cnkiLCJzaGlwcyIsImxheW91dFJvbGUiLCJzdHJpbmdpZnkiLCJuYXYiLCJjb2xsZWN0aW9ucyIsImNvbXBvbmVudCIsInByb3AiLCJ2YWx1ZSIsInByb3BzIiwibG9nIiwic2l6ZSIsIm4iLCJvdmVycmlkYWJsZSIsInNlbGZUZXN0IiwiY2FzZXMiLCJib2d1c0tleSIsInJlc3QiLCJsb2Rlc3RhciIsInNjaGVtYVZlcnNpb24iLCJraW5kIiwiTWluZE5vZGUiLCJzYW5pdGl6aW5nIiwibGFiZWwiLCJzdW1tYXJ5IiwiTWluZEVkZ2UiLCJmcm9tIiwidG8iLCJMZWdlbmQiLCJSaXNrQmFkZ2UiLCJmcm9udG1hdHRlciIsImVuZ2luZSIsImNvcnB1c1Rvb2xpbmciLCJwYXNzVGhyb3VnaCIsIlgiLCJmYWlsZWQiLCJmbiIsInBhc3MiLCJhcmd2Il0sInNvdXJjZXMiOlsiY2hlY2stbWFuaWZlc3QubWpzIl0sInNvdXJjZXNDb250ZW50IjpbIiMhL3Vzci9iaW4vZW52IG5vZGVcbi8vIFRoZSBtYW5pZmVzdCDihpQgcmVhbGl0eSBnYXRlIChSMy0yNzdjOiBcInRoZSBtYW5pZmVzdCBpcyB2YWxpZGF0ZWQgYWdhaW5zdCByZWFsaXR5IOKAlCBhXG4vLyBjb21wb25lbnQgZXhwb3J0ZWQgYnV0IG1pc3NpbmcgZnJvbSB0aGUgbWFuaWZlc3QsIG9yIHZpY2UgdmVyc2EsIGZhaWxzIHRoZSBlbmdpbmUncyBvd25cbi8vIGBucG0gcnVuIHZlcmlmeWBcIikuXG4vL1xuLy8gQSBtYW5pZmVzdCB0aGF0IGRyaWZ0cyBmcm9tIHRoZSBjb2RlIGlzIHdvcnNlIHRoYW4gbm8gbWFuaWZlc3Q6IGEgY29ycHVzIGNoZWNrZXIgd291bGRcbi8vIGZsYWcgYSBjb21wb25lbnQgdGhhdCB3b3Jrcywgb3IgcGFzcyBvbmUgdGhhdCBkb2VzIG5vdCwgYW5kIGEgY29tcG9zaW5nIHNoZWxsIHdvdWxkIGJlXG4vLyB0b2xkIGl0IG1heSBvdmVycmlkZSBzb21ldGhpbmcgdGhhdCBubyBsb25nZXIgZXhpc3RzLiBTbyB0aGlzIHJ1bnMgaW4gYHZlcmlmeWAsIGJlZm9yZVxuLy8gbGludCBhbmQgYnVpbGQsIGJlY2F1c2UgaXQgaXMgdGhlIGNoZWFwZXN0IG9mIHRoZSB0aHJlZSBhbmQgdGhlIG9uZSB3aG9zZSBmYWlsdXJlIGlzXG4vLyBtb3N0IGNvbmZ1c2luZyB0byBkZWJ1ZyBsYXRlci5cbi8vXG4vLyBJdCByZWFkcyBHUk9WRV9NRFgncyBrZXlzIGJ5IHBhcnNpbmcgdGhlIG1vZHVsZSByYXRoZXIgdGhhbiBpbXBvcnRpbmcgaXQgKHRoZSBtb2R1bGVcbi8vIHB1bGxzIGluIFRTWCwgQ1NTIGFuZCB0aGUgU0RLIOKAlCBub3QgbG9hZGFibGUgZnJvbSBwbGFpbiBub2RlKSwgYnV0IGl0IHBhcnNlcyB0aGUgT0JKRUNUXG4vLyBMSVRFUkFMJ3Mga2V5cywgbm90IGEgcmVnZXggb3ZlciB0aGUgd2hvbGUgZmlsZS4gVGhhdCBpcyB0aGUgZGlzdGluY3Rpb24gUjMtMjc3YyBhc2tzXG4vLyBmb3I6IHJlZm9ybWF0dGluZyBgbWR4Q29tcG9uZW50cy50c2AgbXVzdCBub3QgY2hhbmdlIHRoZSBvdXRjb21lLlxuXG5pbXBvcnQgeyByZWFkRmlsZVN5bmMsIHJlYWRkaXJTeW5jLCBleGlzdHNTeW5jIH0gZnJvbSAnbm9kZTpmcyc7XG5pbXBvcnQgeyBmaWxlVVJMVG9QYXRoIH0gZnJvbSAnbm9kZTp1cmwnO1xuaW1wb3J0IHsgZGlybmFtZSwgam9pbiB9IGZyb20gJ25vZGU6cGF0aCc7XG5pbXBvcnQgeyBjcmVhdGVSZXF1aXJlIH0gZnJvbSAnbm9kZTptb2R1bGUnO1xuXG5jb25zdCByb290ID0gam9pbihkaXJuYW1lKGZpbGVVUkxUb1BhdGgoaW1wb3J0Lm1ldGEudXJsKSksICcuLicpO1xuLy8gYWp2IGFycml2ZXMgdHJhbnNpdGl2ZWx5IHdpdGggZXNsaW50ICh0aGUgc2FtZSBhcnJhbmdlbWVudCBkb2NzJyBzY3JpcHRzIHJlbHkgb24pO1xuLy8gc2F5IHNvIHdoZW4gaXQgaXMgYWJzZW50IHJhdGhlciB0aGFuIGR5aW5nIG9uIGEgYmFyZSBtb2R1bGUtbm90LWZvdW5kLlxuY29uc3QgcmVxdWlyZSA9IGNyZWF0ZVJlcXVpcmUoam9pbihyb290LCAncGFja2FnZS5qc29uJykpO1xuY29uc3QgQWp2ID0gKCgpID0+IHtcbiAgdHJ5IHtcbiAgICByZXR1cm4gcmVxdWlyZSgnYWp2Jyk7XG4gIH0gY2F0Y2gge1xuICAgIGNvbnNvbGUuZXJyb3IoJ2NoZWNrLW1hbmlmZXN0OiBhanYgaXMgbm90IHJlc29sdmFibGUg4oCUIGl0IHJpZGVzIHdpdGggZXNsaW50OyBydW4gbnBtIGluc3RhbGwuJyk7XG4gICAgcHJvY2Vzcy5leGl0KDEpO1xuICB9XG59KSgpO1xuY29uc3QgbWFuaWZlc3QgPSBKU09OLnBhcnNlKHJlYWRGaWxlU3luYyhqb2luKHJvb3QsICd2aWV3ZXIubWFuaWZlc3QuanNvbicpLCAndXRmOCcpKTtcbmNvbnN0IHNvdXJjZSA9IHJlYWRGaWxlU3luYyhqb2luKHJvb3QsICdzcmMvbWR4Q29tcG9uZW50cy50cycpLCAndXRmOCcpO1xuXG4vKipcbiAqIFN0cmlwIGNvbW1lbnRzIGFuZCBzdHJpbmcgbGl0ZXJhbHMsIHJlcGxhY2luZyBlYWNoIHdpdGggZXF1aXZhbGVudC1sZW5ndGggd2hpdGVzcGFjZSBzb1xuICogZXZlcnkgb2Zmc2V0IGluIHRoZSByZXN1bHQgc3RpbGwgbGluZXMgdXAgd2l0aCB0aGUgb3JpZ2luYWwuIEJyYWNlLW1hdGNoaW5nIE1VU1QgcnVuXG4gKiBvdmVyIHRoaXMgYW5kIG5vdCB0aGUgcmF3IHNvdXJjZTogYSBgfWAgaW5zaWRlIGEgY29tbWVudCBvciBhIHN0cmluZyB3b3VsZCBvdGhlcndpc2UgZW5kXG4gKiB0aGUgb2JqZWN0IGxpdGVyYWwgZWFybHksIGFuZCB0aGUgZmFpbHVyZSBtb2RlIGlzIHRoZSB3b3JzdCBraW5kIOKAlCB0aGUgZ2F0ZSByZXBvcnRzIHRoZVxuICogd2hvbGUgbWFuaWZlc3QgYXMgZHJpZnRlZCwgd2hpY2ggcmVhZHMgYXMgXCJ0aGUgbWFuaWZlc3QgaXMgYnJva2VuXCIgcmF0aGVyIHRoYW4gXCJ0aGVcbiAqIHNjYW5uZXIgaXNcIi4gKEZvdW5kIGJ5IHBsYW50aW5nIGEgYH1gLWJlYXJpbmcgY29tbWVudDsgc2VlIHRoZSByZWZvcm1hdHRpbmcgdGVzdC4pXG4gKi9cbmZ1bmN0aW9uIGJsYW5rTm9uQ29kZShzcmMpIHtcbiAgY29uc3Qgb3V0ID0gc3JjLnNwbGl0KCcnKTtcbiAgbGV0IGkgPSAwO1xuICBjb25zdCBibGFua1RvID0gKGVuZCkgPT4ge1xuICAgIGZvciAoOyBpIDwgZW5kICYmIGkgPCBvdXQubGVuZ3RoOyBpKyspIGlmIChvdXRbaV0gIT09ICdcXG4nKSBvdXRbaV0gPSAnICc7XG4gIH07XG4gIHdoaWxlIChpIDwgc3JjLmxlbmd0aCkge1xuICAgIGNvbnN0IHR3byA9IHNyYy5zbGljZShpLCBpICsgMik7XG4gICAgaWYgKHR3byA9PT0gJy8vJykge1xuICAgICAgY29uc3QgbmwgPSBzcmMuaW5kZXhPZignXFxuJywgaSk7XG4gICAgICBibGFua1RvKG5sID09PSAtMSA/IHNyYy5sZW5ndGggOiBubCk7XG4gICAgfSBlbHNlIGlmICh0d28gPT09ICcvKicpIHtcbiAgICAgIGNvbnN0IGNsb3NlID0gc3JjLmluZGV4T2YoJyovJywgaSArIDIpO1xuICAgICAgYmxhbmtUbyhjbG9zZSA9PT0gLTEgPyBzcmMubGVuZ3RoIDogY2xvc2UgKyAyKTtcbiAgICB9IGVsc2UgaWYgKHNyY1tpXSA9PT0gXCInXCIgfHwgc3JjW2ldID09PSAnXCInIHx8IHNyY1tpXSA9PT0gJ2AnKSB7XG4gICAgICBjb25zdCBxdW90ZSA9IHNyY1tpXTtcbiAgICAgIGxldCBqID0gaSArIDE7XG4gICAgICB3aGlsZSAoaiA8IHNyYy5sZW5ndGggJiYgc3JjW2pdICE9PSBxdW90ZSkgaiArPSBzcmNbal0gPT09ICdcXFxcJyA/IDIgOiAxO1xuICAgICAgYmxhbmtUbyhNYXRoLm1pbihqICsgMSwgc3JjLmxlbmd0aCkpO1xuICAgIH0gZWxzZSB7XG4gICAgICBpKys7XG4gICAgfVxuICB9XG4gIHJldHVybiBvdXQuam9pbignJyk7XG59XG5cbi8qKiBUaGUga2V5cyBvZiB0aGUgYGV4cG9ydCBjb25zdCBHUk9WRV9NRFggPSB7IOKApiB9YCBvYmplY3QgbGl0ZXJhbCwgYnJhY2UtbWF0Y2hlZCBvdmVyIHRoZVxuICogIGNvbW1lbnQtIGFuZCBzdHJpbmctYmxhbmtlZCBzb3VyY2Ugc28gcmVmb3JtYXR0aW5nIGNhbm5vdCBjaGFuZ2UgdGhlIG91dGNvbWUuICovXG5mdW5jdGlvbiBncm92ZU1keEtleXMocmF3U3JjKSB7XG4gIGNvbnN0IHNyYyA9IGJsYW5rTm9uQ29kZShyYXdTcmMpO1xuICBjb25zdCBzdGFydCA9IHNyYy5pbmRleE9mKCdleHBvcnQgY29uc3QgR1JPVkVfTURYID0geycpO1xuICBpZiAoc3RhcnQgPT09IC0xKSB0aHJvdyBuZXcgRXJyb3IoJ0dST1ZFX01EWCBvYmplY3QgbGl0ZXJhbCBub3QgZm91bmQgaW4gc3JjL21keENvbXBvbmVudHMudHMnKTtcbiAgY29uc3Qgb3BlbiA9IHNyYy5pbmRleE9mKCd7Jywgc3RhcnQpO1xuICBsZXQgZGVwdGggPSAwO1xuICBsZXQgZW5kID0gLTE7XG4gIGZvciAobGV0IGogPSBvcGVuOyBqIDwgc3JjLmxlbmd0aDsgaisrKSB7XG4gICAgaWYgKHNyY1tqXSA9PT0gJ3snKSBkZXB0aCsrO1xuICAgIGVsc2UgaWYgKHNyY1tqXSA9PT0gJ30nKSB7XG4gICAgICBkZXB0aC0tO1xuICAgICAgaWYgKGRlcHRoID09PSAwKSB7XG4gICAgICAgIGVuZCA9IGo7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICBpZiAoZW5kID09PSAtMSkgdGhyb3cgbmV3IEVycm9yKCdHUk9WRV9NRFggb2JqZWN0IGxpdGVyYWwgaXMgdW50ZXJtaW5hdGVkJyk7XG4gIGNvbnN0IGtleXMgPSBbXTtcbiAgbGV0IG5lc3RpbmcgPSAwO1xuICBmb3IgKGNvbnN0IGxpbmUgb2Ygc3JjLnNsaWNlKG9wZW4gKyAxLCBlbmQpLnNwbGl0KCdcXG4nKSkge1xuICAgIC8vIE9ubHkgVE9QLWxldmVsIGtleXMgYXJlIHRoZSB2b2NhYnVsYXJ5OyBhIG5lc3RlZCBvYmplY3QncyBrZXlzIGFyZSBwcm9wcywgbm90XG4gICAgLy8gY29tcG9uZW50cy5cbiAgICBjb25zdCBiZWZvcmUgPSBuZXN0aW5nO1xuICAgIGZvciAoY29uc3QgY2ggb2YgbGluZSkge1xuICAgICAgaWYgKGNoID09PSAneycgfHwgY2ggPT09ICdbJykgbmVzdGluZysrO1xuICAgICAgZWxzZSBpZiAoY2ggPT09ICd9JyB8fCBjaCA9PT0gJ10nKSBuZXN0aW5nLS07XG4gICAgfVxuICAgIGlmIChiZWZvcmUgIT09IDApIGNvbnRpbnVlO1xuICAgIGNvbnN0IG0gPSBsaW5lLm1hdGNoKC9eXFxzKihbQS1aYS16XyRdW1xcdyRdKilcXHMqWyw6XS8pO1xuICAgIGlmIChtKSBrZXlzLnB1c2gobVsxXSk7XG4gIH1cbiAgcmV0dXJuIGtleXM7XG59XG5cbi8vIFJ1bGUgMCDigJQgdGhlIG1hbmlmZXN0IHZhbGlkYXRlcyBhZ2FpbnN0IHRoZSBGT1JNQVQgc2NoZW1hLiBUaGlzIHBhaXIgbGl2ZWRcbi8vIHVuLWNoZWNrZWQgaGVyZSBmb3IgYSB5ZWFyICh0aGUgdmFsaWRhdGlvbiBydWxlIGV4aXN0ZWQgb25seSBpbiB0aGUgZG9jcyBmb3JrJ3Ncbi8vIHBvcnQpLCB3aGljaCBpcyBob3cgdGhlIHNjaGVtYSBjb3VsZCBsYWNrIHRoZSBgdGhlbWVzYC9gcGFnZVZhcmlhbnRzYCBibG9ja3MgdGhlXG4vLyBtYW5pZmVzdCBhbHJlYWR5IHNoaXBwZWQgKFIzLTY2MSk6IG5vdGhpbmcgb24gdGhpcyBzaWRlIGV2ZXIgcmVhZCB0aGUgdHdvIHRvZ2V0aGVyLlxuLy8gVGhlIHNjaGVtYSBpcyB2aWV3ZXItZ2VuZXJpYyBieSBjb250cmFjdCDigJQgYSBMb2Rlc3Rhci1zaGFwZWQgbWFuaWZlc3QgbXVzdCB2YWxpZGF0ZVxuLy8gdGhyb3VnaCBpdCDigJQgc28gYSBkcmlmdCBoZXJlIGlzIGEgYnJva2VuIHByb21pc2UgdG8gZXZlcnkgc2Vjb25kIHZpZXdlci5cbi8vXG4vLyBJdCBydW5zIEZJUlNULCBhbmQgaXQgSEFMVFM6IGV2ZXJ5IGxhdGVyIHJ1bGUgYXNzdW1lcyB0aGUgc2hhcGUgdGhpcyBvbmUgZW5mb3JjZXMsXG4vLyBzbyBhIHJlamVjdGVkIG1hbmlmZXN0IHJlcG9ydHMgdGhlIHNjaGVtYSB2ZXJkaWN0IGFuZCBzdG9wcyDigJQgbmV2ZXIgYSByYXcgVHlwZUVycm9yXG4vLyBmcm9tIGEgcnVsZSB0aGF0IHRydXN0ZWQgdGhlIHNoYXBlIChhIG1pc3NpbmcgYGNvbXBvbmVudHNgLCBhIG51bGwgZW50cnksIOKApikuXG4vLyBFeHRyYWN0ZWQgcHVyZSBzbyB0aGUgc2VsZi10ZXN0IGNhbiBkcml2ZSBwbGFudGVkIG1hbmlmZXN0cyB0aHJvdWdoIGl0LlxuY29uc3Qgc2NoZW1hID0gSlNPTi5wYXJzZShyZWFkRmlsZVN5bmMoam9pbihyb290LCAndmlld2VyLW1hbmlmZXN0LnNjaGVtYS5qc29uJyksICd1dGY4JykpO1xuZnVuY3Rpb24gc2NoZW1hRXJyb3JzKG0pIHtcbiAgY29uc3QgYWp2ID0gbmV3IEFqdih7IGxvZ2dlcjogZmFsc2UgfSk7XG4gIGNvbnN0IHZhbGlkYXRlID0gYWp2LmNvbXBpbGUoc2NoZW1hKTtcbiAgcmV0dXJuIHZhbGlkYXRlKG0pID8gW10gOiBbYWp2LmVycm9yc1RleHQodmFsaWRhdGUuZXJyb3JzKV07XG59XG57XG4gIGNvbnN0IHJ1bGUwID0gc2NoZW1hRXJyb3JzKG1hbmlmZXN0KTtcbiAgaWYgKHJ1bGUwLmxlbmd0aCkge1xuICAgIGNvbnNvbGUuZXJyb3IoYEZBSUwgbWFuaWZlc3Qg4oaUIHJlYWxpdHkgKCR7cnVsZTAubGVuZ3RofSk6XFxuICBtYW5pZmVzdCBmYWlscyB2aWV3ZXItbWFuaWZlc3Quc2NoZW1hLmpzb246ICR7cnVsZTAuam9pbignXFxuICAnKX1gKTtcbiAgICBwcm9jZXNzLmV4aXQoMSk7XG4gIH1cbn1cblxuY29uc3QgZXJyb3JzID0gW107XG5cbmNvbnN0IGV4cG9ydGVkID0gbmV3IFNldChncm92ZU1keEtleXMoc291cmNlKSk7XG5jb25zdCBkZWNsYXJlZCA9IG5ldyBTZXQoT2JqZWN0LmtleXMobWFuaWZlc3QuY29tcG9uZW50cykpO1xuXG5mb3IgKGNvbnN0IG5hbWUgb2YgZXhwb3J0ZWQpIHtcbiAgaWYgKCFkZWNsYXJlZC5oYXMobmFtZSkpIHtcbiAgICBlcnJvcnMucHVzaChcbiAgICAgIGAgICR7bmFtZX0g4oCUIHJlZ2lzdGVyZWQgaW4gR1JPVkVfTURYIGJ1dCBOT1QgaW4gdGhlIG1hbmlmZXN0LiBBIGNvcnB1cyBjYW4gdXNlIGl0IGFuZCBgICtcbiAgICAgICAgYGEgY2hlY2tlciB3aWxsIGZsYWcgaXQ7IGEgc2hlbGwgY2Fubm90IG92ZXJyaWRlIGl0LiBEZWNsYXJlIGl0LCBvciBtYWtlIGl0IGludGVybmFsIGAgK1xuICAgICAgICBgYnkgcmVtb3ZpbmcgaXQgZnJvbSBHUk9WRV9NRFguYCxcbiAgICApO1xuICB9XG59XG5mb3IgKGNvbnN0IG5hbWUgb2YgZGVjbGFyZWQpIHtcbiAgaWYgKG1hbmlmZXN0LmNvbXBvbmVudHNbbmFtZV0udGllciA9PT0gJ2NvcnB1cycpIGNvbnRpbnVlOyAvLyBkZWNsYXJlZCBieSBhIGNvcnB1cywgbm90IGhlcmVcbiAgaWYgKCFleHBvcnRlZC5oYXMobmFtZSkpIHtcbiAgICBlcnJvcnMucHVzaChcbiAgICAgIGAgICR7bmFtZX0g4oCUIGRlY2xhcmVkIGluIHRoZSBtYW5pZmVzdCBidXQgTk9UIHJlZ2lzdGVyZWQgaW4gR1JPVkVfTURYLiBBIGNvcnB1cyB1c2luZyBgICtcbiAgICAgICAgYGl0IHJlbmRlcnMgbm90aGluZywgYW5kIGEgc2hlbGwgb3ZlcnJpZGluZyBpdCBvdmVycmlkZXMgYSBjb21wb25lbnQgdGhhdCBuZXZlciBydW5zLmAsXG4gICAgKTtcbiAgfVxufVxuXG4vLyBUaGUgdmlld2VyIGlkZW50aXR5IG11c3QgbWF0Y2ggdGhlIHBhY2thZ2UgaXQgc2hpcHMgaW4sIG9yIGEgc2hlbGwgcmVzb2x2aW5nIHRoZVxuLy8gbWFuaWZlc3QgYnkgcGFja2FnZSBuYW1lIGdldHMgc29tZW9uZSBlbHNlJ3MgY29udHJhY3QuXG5jb25zdCBwa2cgPSBKU09OLnBhcnNlKHJlYWRGaWxlU3luYyhqb2luKHJvb3QsICdwYWNrYWdlLmpzb24nKSwgJ3V0ZjgnKSk7XG5pZiAobWFuaWZlc3Qudmlld2VyLm5hbWUgIT09IHBrZy5uYW1lKSB7XG4gIGVycm9ycy5wdXNoKGAgIHZpZXdlci5uYW1lIFwiJHttYW5pZmVzdC52aWV3ZXIubmFtZX1cIiDiiaAgcGFja2FnZS5qc29uIG5hbWUgXCIke3BrZy5uYW1lfVwiLmApO1xufVxuY29uc3QgcHJvdmlkZXMgPSAocGtnWydpbW1lZGlhdGVseS5ydW4nXT8ucHJvdmlkZXMgPz8gW10pLm1hcCgocCkgPT4gcC50YXNrKTtcbmlmIChtYW5pZmVzdC52aWV3ZXIudGFzayAmJiAhcHJvdmlkZXMuaW5jbHVkZXMobWFuaWZlc3Qudmlld2VyLnRhc2spKSB7XG4gIGVycm9ycy5wdXNoKFxuICAgIGAgIHZpZXdlci50YXNrIFwiJHttYW5pZmVzdC52aWV3ZXIudGFza31cIiBpcyBub3QgaW4gcGFja2FnZS5qc29uIGltbWVkaWF0ZWx5LnJ1bi5wcm92aWRlcyBgICtcbiAgICAgIGAoJHtwcm92aWRlcy5qb2luKCcsICcpIHx8ICdub25lJ30pLmAsXG4gICk7XG59XG5cbi8vIEV2ZXJ5IGV4cG9ydCBtdXN0IGJlIHJlYWNoYWJsZSwgb3IgYSBzaGVsbCdzIGltcG9ydCBmYWlscyBhdCBjb21wb3NlIHRpbWUgcmF0aGVyIHRoYW4gaGVyZS5cbmZvciAoY29uc3QgW3N1YnBhdGgsIHRhcmdldF0gb2YgT2JqZWN0LmVudHJpZXMocGtnLmV4cG9ydHMgPz8ge30pKSB7XG4gIHRyeSB7XG4gICAgcmVhZEZpbGVTeW5jKGpvaW4ocm9vdCwgdGFyZ2V0KSk7XG4gIH0gY2F0Y2gge1xuICAgIGVycm9ycy5wdXNoKGAgIGV4cG9ydHNbXCIke3N1YnBhdGh9XCJdIOKGkiAke3RhcmdldH0gZG9lcyBub3QgZXhpc3QuYCk7XG4gIH1cbn1cblxuLy8g4pSA4pSAIFIzLTMwOSDigJQgdGhlIGxheW91dC1jYXRhbG9ndWUgZ2F0ZXMg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4vL1xuLy8gVGhlIG1hbmlmZXN0J3MgYGxheW91dHNgIGVudHJpZXMgYW5kIHRoZSBmaWxlcyB1bmRlciBjb250ZW50L19sYXlvdXRzLyBtdXN0IGFncmVlXG4vLyBpbiBCT1RIIGRpcmVjdGlvbnMgKHRoZSBzYW1lIHR3by13YXkgcnVsZSB0aGUgY29tcG9uZW50cyBzZWN0aW9uIGVuZm9yY2VzKSwgYW5kIGFcbi8vIHNoaXBwaW5nIHN0YXJ0ZXIncyBPV04gZnJvbnRtYXR0ZXIgbXVzdCBjYXJyeSB0aGUgYGxheW91dFJvbGVgIGl0cyBlbnRyeSBkZWNsYXJlcy5cbi8vIFRoYXQgaXMgdGhlIGpvYiB0aGUgZmllbGQgd2FzIGdpdmVuOiBpdCBzYXQgdW5yZWFkIGluIHRoZSBzYW1wbGUgbGF5b3V0cyBmb3IgYVxuLy8geWVhciwgYW5kIFwiYW4gaW5lcnQgZmllbGQgaW4gYSBmaWxlIHBlb3BsZSBjb3B5IGlzIGEgZmllbGQgcGVvcGxlIHdpbGwgY29weVwiLlxuXG5jb25zdCBMQVlPVVRTX0RJUiA9IGpvaW4ocm9vdCwgJ2NvbnRlbnQnLCAnX2xheW91dHMnKTtcbmNvbnN0IHN0YXJ0ZXJJZHMgPVxuICBleGlzdHNTeW5jKExBWU9VVFNfRElSKVxuICAgID8gcmVhZGRpclN5bmMoTEFZT1VUU19ESVIsIHsgd2l0aEZpbGVUeXBlczogdHJ1ZSB9KVxuICAgICAgICAuZmlsdGVyKChlKSA9PiBlLmlzRmlsZSgpICYmIC9cXC5tZHg/JC8udGVzdChlLm5hbWUpKVxuICAgICAgICAubWFwKChlKSA9PiBlLm5hbWUucmVwbGFjZSgvXFwubWR4PyQvLCAnJykpXG4gICAgOiBbXTtcblxuLyoqIFRoZSBmcm9udG1hdHRlciBibG9jayBvZiBhIHN0YXJ0ZXIsIGFzIGtleSDihpIgdmFsdWUgKHNjYWxhcnMgb25seSDigJQgdGhhdCBpcyBhbGwgYVxuICogIHN0YXJ0ZXIgZGVjbGFyZXMpLiAqL1xuZnVuY3Rpb24gZnJvbnRtYXR0ZXJPZihmaWxlKSB7XG4gIGNvbnN0IHNyYyA9IHJlYWRGaWxlU3luYyhqb2luKExBWU9VVFNfRElSLCBmaWxlKSwgJ3V0ZjgnKTtcbiAgY29uc3QgbSA9IHNyYy5tYXRjaCgvXi0tLVxcbihbXFxzXFxTXSo/KVxcbi0tLS8pO1xuICBjb25zdCBmbSA9IHt9O1xuICBpZiAobSkgZm9yIChjb25zdCBsaW5lIG9mIG1bMV0uc3BsaXQoJ1xcbicpKSB7XG4gICAgY29uc3Qga3YgPSBsaW5lLm1hdGNoKC9eKFxcdyspOlxccyooLispJC8pO1xuICAgIGlmIChrdikgZm1ba3ZbMV1dID0ga3ZbMl0udHJpbSgpLnJlcGxhY2UoL15bJ1wiXXxbJ1wiXSQvZywgJycpO1xuICB9XG4gIHJldHVybiBmbTtcbn1cblxuY29uc3QgZGVjbGFyZWRMYXlvdXRzID0gbWFuaWZlc3QubGF5b3V0cyA/PyB7fTtcbmZvciAoY29uc3QgW2lkLCBlbnRyeV0gb2YgT2JqZWN0LmVudHJpZXMoZGVjbGFyZWRMYXlvdXRzKSkge1xuICBpZiAoZW50cnkuc2hpcHMgJiYgIXN0YXJ0ZXJJZHMuaW5jbHVkZXMoaWQpKSB7XG4gICAgZXJyb3JzLnB1c2goYCAgbGF5b3V0cy4ke2lkfSDigJQgZGVjbGFyZWQgc2hpcHM6dHJ1ZSBidXQgY29udGVudC9fbGF5b3V0cy8ke2lkfS5tZHggZG9lcyBub3QgZXhpc3QuYCk7XG4gIH1cbiAgaWYgKGVudHJ5LnNoaXBzKSB7XG4gICAgY29uc3QgZm0gPSBmcm9udG1hdHRlck9mKGAke2lkfS5tZHhgKTtcbiAgICBpZiAoZm0ubGF5b3V0Um9sZSAhPT0gZW50cnkubGF5b3V0Um9sZSkge1xuICAgICAgZXJyb3JzLnB1c2goXG4gICAgICAgIGAgIGxheW91dHMuJHtpZH0g4oCUIG1hbmlmZXN0IHNheXMgbGF5b3V0Um9sZToke2VudHJ5LmxheW91dFJvbGV9LCB0aGUgc3RhcnRlcidzIGZyb250bWF0dGVyIHNheXMgYCArXG4gICAgICAgICAgYCR7SlNPTi5zdHJpbmdpZnkoZm0ubGF5b3V0Um9sZSl9LiBUaGUgdHdvIG11c3QgYWdyZWUuYCxcbiAgICAgICk7XG4gICAgfVxuICAgIGlmIChmbS5uYXYgJiYgZm0ubmF2ICE9PSAndG9wJyAmJiBmbS5uYXYgIT09ICdzaWRlJykge1xuICAgICAgZXJyb3JzLnB1c2goYCAgbGF5b3V0cy4ke2lkfSDigJQgbmF2OiR7Zm0ubmF2fSBpcyBuZWl0aGVyICd0b3AnIG5vciAnc2lkZSc7IHJlc29sdmVOYXZNb2RlIHdvdWxkIHNpbGVudGx5IGZhbGwgYmFjay5gKTtcbiAgICB9XG4gIH1cbn1cbmZvciAoY29uc3QgaWQgb2Ygc3RhcnRlcklkcykge1xuICBpZiAoIWRlY2xhcmVkTGF5b3V0c1tpZF0pIHtcbiAgICBlcnJvcnMucHVzaChcbiAgICAgIGAgIGNvbnRlbnQvX2xheW91dHMvJHtpZH0ubWR4IOKAlCBhIHN0YXJ0ZXIgb24gZGlzayB3aXRoIE5PIG1hbmlmZXN0IGVudHJ5LiBJdCByZW5kZXJzICh3aGVuIGAgK1xuICAgICAgICBgY29waWVkKSBidXQgbm90aGluZyBkZWNsYXJlcyBpdDogYSBjb3JwdXMgY2hlY2tlciBjYW5ub3QgZmluZCBpdCBhbmQgYW4gYWdlbnQgY2Fubm90IGRpc2NvdmVyIGl0LmAsXG4gICAgKTtcbiAgfVxufVxuXG4vLyBDb2xsZWN0aW9uIHNoYXBlcyByaWRlIG9uIGVuZ2luZSBjb21wb25lbnRzOyBhIGRlY2xhcmVkIGNvbXBvbmVudCB0aGF0IGlzIG5vdCBpbiB0aGVcbi8vIHZvY2FidWxhcnkgaXMgdGhlIHNhbWUgbGllIGFzIGFuIHVuZGVjbGFyZWQgb25lIGluIHRoZSBjb21wb25lbnRzIHNlY3Rpb24uXG5jb25zdCBjb2xsZWN0aW9ucyA9IG1hbmlmZXN0LmNvbGxlY3Rpb25zID8/IHt9O1xuZm9yIChjb25zdCBbaWQsIGVudHJ5XSBvZiBPYmplY3QuZW50cmllcyhjb2xsZWN0aW9ucykpIHtcbiAgaWYgKGVudHJ5LmNvbXBvbmVudCAmJiAhZXhwb3J0ZWQuaGFzKGVudHJ5LmNvbXBvbmVudCkpIHtcbiAgICBlcnJvcnMucHVzaChcbiAgICAgIGAgIGNvbGxlY3Rpb25zLiR7aWR9IOKAlCByaWRlcyBvbiBcIiR7ZW50cnkuY29tcG9uZW50fVwiLCB3aGljaCBpcyBub3QgcmVnaXN0ZXJlZCBpbiBHUk9WRV9NRFguIGAgK1xuICAgICAgICBgQSBjb3JwdXMgd3JpdGluZyB0aGUgZG9jdW1lbnRlZCBjYWxsIHJlbmRlcnMgbm90aGluZy5gLFxuICAgICk7XG4gIH1cbiAgZm9yIChjb25zdCBbcHJvcCwgdmFsdWVdIG9mIE9iamVjdC5lbnRyaWVzKGVudHJ5LnByb3BzID8/IHt9KSkge1xuICAgIGlmICgvXlxcey4qXFx9JC8udGVzdCh2YWx1ZSkpIHtcbiAgICAgIGVycm9ycy5wdXNoKGAgIGNvbGxlY3Rpb25zLiR7aWR9IOKAlCBwcm9wcy4ke3Byb3B9IGlzIGFuIEVYUFJFU1NJT04gKCR7dmFsdWV9KS4gVGhlIGludGVycHJldGVyIGRyb3BzIGl0IHNpbGVudGx5LmApO1xuICAgIH1cbiAgfVxufVxuXG5pZiAoZXJyb3JzLmxlbmd0aCkge1xuICBjb25zb2xlLmVycm9yKGBGQUlMIG1hbmlmZXN0IOKGlCByZWFsaXR5ICgke2Vycm9ycy5sZW5ndGh9KTpcXG4ke2Vycm9ycy5qb2luKCdcXG4nKX1gKTtcbiAgcHJvY2Vzcy5leGl0KDEpO1xufVxuY29uc29sZS5sb2coXG4gIGBPSyAke21hbmlmZXN0LnZpZXdlci5uYW1lfTogJHtkZWNsYXJlZC5zaXplfSBjb21wb25lbnRzIGRlY2xhcmVkLCBgICtcbiAgICBgJHtbLi4uZGVjbGFyZWRdLmZpbHRlcigobikgPT4gbWFuaWZlc3QuY29tcG9uZW50c1tuXS5vdmVycmlkYWJsZSkubGVuZ3RofSBvdmVycmlkYWJsZSwgYCArXG4gICAgYCR7T2JqZWN0LmtleXMocGtnLmV4cG9ydHMgPz8ge30pLmxlbmd0aH0gZXhwb3J0IHN1YnBhdGhzIHJlc29sdmUsIGAgK1xuICAgIGAke3N0YXJ0ZXJJZHMubGVuZ3RofSBsYXlvdXQgc3RhcnRlcihzKSwgJHtPYmplY3Qua2V5cyhjb2xsZWN0aW9ucykubGVuZ3RofSBjb2xsZWN0aW9uIHNoYXBlKHMpLmAsXG4pO1xuXG4vLyDilIDilIAgc2VsZi10ZXN0IOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuLy8gUnVsZSAwJ3MgdGVldGgsIHBsYW50ZWQgcmF0aGVyIHRoYW4gYXNzZXJ0ZWQgKHRoZSByZXZpZXdlciB3YXMgcmlnaHQgdG8gZGVtYW5kIHRoZVxuLy8gY29tbWl0dGVkIGZvcm0gb2YgdGhlIG1hbnVhbCBmYXVsdCBpbmplY3Rpb24pOiBhIGdhdGUgbm90aGluZyBoYXMgd2F0Y2hlZCByZWplY3Rcbi8vIGFueXRoaW5nIGlzIGFuIGFzc3VtcHRpb24uIERyaXZlbiB0aHJvdWdoIGBzY2hlbWFFcnJvcnNgIOKAlCB0aGUgc2FtZSBmdW5jdGlvbiB0aGVcbi8vIGdhdGUgcnVucyDigJQgc28gdGhlIGNhc2VzIG1vdmUgd2hlbiB0aGUgcnVsZSBkb2VzLlxuY29uc3Qgc2VsZlRlc3QgPSAoKSA9PiB7XG4gIGNvbnN0IGNhc2VzID0gW107XG4gIGNhc2VzLnB1c2goWyd0aGUgc2hpcHBlZCBwYWlyIHZhbGlkYXRlcycsICgpID0+IHNjaGVtYUVycm9ycyhtYW5pZmVzdCkubGVuZ3RoID09PSAwXSk7XG4gIGNhc2VzLnB1c2goWydhIHBsYW50ZWQgdG9wLWxldmVsIGtleSBmYWlscycsICgpID0+XG4gICAgc2NoZW1hRXJyb3JzKHsgLi4ubWFuaWZlc3QsIGJvZ3VzS2V5OiAneCcgfSkubGVuZ3RoID4gMF0pO1xuICBjYXNlcy5wdXNoKFsnYSBtYW5pZmVzdCBtaXNzaW5nIGNvbXBvbmVudHMgZmFpbHMgd2l0aCB0aGUgc2NoZW1hIHZlcmRpY3QsIG5vdCBhIGNyYXNoJywgKCkgPT4ge1xuICAgIGNvbnN0IHsgY29tcG9uZW50cywgLi4ucmVzdCB9ID0gbWFuaWZlc3Q7XG4gICAgcmV0dXJuIHNjaGVtYUVycm9ycyhyZXN0KS5sZW5ndGggPiAwO1xuICB9XSk7XG4gIC8vIFRoZSB2aWV3ZXItZ2VuZXJpYyBjb250cmFjdCAoc3BlYyDCpzUuMSk6IGEgTG9kZXN0YXItc2hhcGVkIG1hbmlmZXN0IOKAlCBub2RlL2VkZ2VcbiAgLy8gdm9jYWJ1bGFyeSwgaXRzIG93biB0aGVtZXMg4oCUIHZhbGlkYXRlcyB0aHJvdWdoIHRoZSBzYW1lIHNjaGVtYS5cbiAgY29uc3QgbG9kZXN0YXIgPSB7XG4gICAgc2NoZW1hVmVyc2lvbjogMSxcbiAgICB2aWV3ZXI6IHsgbmFtZTogJ0BmaWN0aW9uYWwvbG9kZXN0YXInLCBraW5kOiAnbWluZG1hcCcsIHRhc2s6ICdvcGVuLW1pbmRtYXAnIH0sXG4gICAgY29tcG9uZW50czoge1xuICAgICAgTWluZE5vZGU6IHsgdGllcjogJ2VuZ2luZScsIG92ZXJyaWRhYmxlOiB0cnVlLCBzYW5pdGl6aW5nOiBmYWxzZSwgcHJvcHM6IHsgbGFiZWw6ICdzdHJpbmc/JywgZGVwdGg6ICdudW1iZXI/JyB9LCBzdW1tYXJ5OiAnQSBub2RlLicgfSxcbiAgICAgIE1pbmRFZGdlOiB7IHRpZXI6ICdlbmdpbmUnLCBvdmVycmlkYWJsZTogdHJ1ZSwgc2FuaXRpemluZzogZmFsc2UsIHByb3BzOiB7IGZyb206ICdzdHJpbmcnLCB0bzogJ3N0cmluZycgfSwgc3VtbWFyeTogJ0FuIGVkZ2UuJyB9LFxuICAgICAgTGVnZW5kOiB7IHRpZXI6ICdjaHJvbWUnLCBvdmVycmlkYWJsZTogdHJ1ZSwgc2FuaXRpemluZzogZmFsc2UsIHByb3BzOiB7fSwgc3VtbWFyeTogJ01hcCBjaHJvbWUuJyB9LFxuICAgICAgUmlza0JhZGdlOiB7IHRpZXI6ICdjb3JwdXMnLCBvdmVycmlkYWJsZTogdHJ1ZSwgc2FuaXRpemluZzogZmFsc2UsIHByb3BzOiB7fSwgc3VtbWFyeTogJ09uZSBjb3JwdXMgY29udmVudGlvbi4nIH0sXG4gICAgfSxcbiAgICBmcm9udG1hdHRlcjogeyBlbmdpbmU6IFsndmlldycsICdjb2xsYXBzZWQnXSwgY29ycHVzVG9vbGluZzogWydyaXNrJ10sIHBhc3NUaHJvdWdoOiB0cnVlIH0sXG4gIH07XG4gIGNhc2VzLnB1c2goWydhIExvZGVzdGFyIG1hbmlmZXN0IHZhbGlkYXRlcyB0aHJvdWdoIHRoZSBzYW1lIHNjaGVtYScsICgpID0+IHNjaGVtYUVycm9ycyhsb2Rlc3RhcikubGVuZ3RoID09PSAwXSk7XG4gIGNhc2VzLnB1c2goWydhIG1hbmlmZXN0IHdpdGggYW4gdW5rbm93biB0aWVyIGlzIHJlamVjdGVkJywgKCkgPT5cbiAgICBzY2hlbWFFcnJvcnMoeyAuLi5sb2Rlc3RhciwgY29tcG9uZW50czogeyBYOiB7IHRpZXI6ICdnYWxheHknLCBvdmVycmlkYWJsZTogdHJ1ZSB9IH0gfSkubGVuZ3RoID4gMF0pO1xuXG4gIGxldCBmYWlsZWQgPSAwO1xuICBmb3IgKGNvbnN0IFtuYW1lLCBmbl0gb2YgY2FzZXMpIHtcbiAgICBsZXQgcGFzcyA9IGZhbHNlO1xuICAgIHRyeSB7XG4gICAgICBwYXNzID0gZm4oKTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIHBhc3MgPSBmYWxzZTtcbiAgICB9XG4gICAgY29uc29sZS5sb2coYCR7cGFzcyA/ICfinJMnIDogJ+Kclyd9ICR7bmFtZX1gKTtcbiAgICBpZiAoIXBhc3MpIGZhaWxlZCsrO1xuICB9XG4gIGNvbnNvbGUubG9nKGBcXG4ke2Nhc2VzLmxlbmd0aCAtIGZhaWxlZH0vJHtjYXNlcy5sZW5ndGh9IHNlbGYtdGVzdCBjYXNlcy5gKTtcbiAgcmV0dXJuIGZhaWxlZCA9PT0gMDtcbn07XG5cbmlmIChwcm9jZXNzLmFyZ3YuaW5jbHVkZXMoJy0tc2VsZi10ZXN0JykpIHByb2Nlc3MuZXhpdChzZWxmVGVzdCgpID8gMCA6IDEpO1xuIl0sIm1hcHBpbmdzIjoiQUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFBQTs7QUFBQUEsT0FBQTtBQUFBQSxPQUFBO0FBQUFBLE9BQUE7QUFFQSxJQUFBQyxPQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxRQUFBLEdBQUFGLE9BQUE7QUFDQSxJQUFBRyxTQUFBLEdBQUFILE9BQUE7QUFDQSxJQUFBSSxXQUFBLEdBQUFKLE9BQUE7QUFFQSxNQUFNSyxJQUFJLEdBQUcsSUFBQUMsY0FBSSxFQUFDLElBQUFDLGlCQUFPLEVBQUMsSUFBQUMsc0JBQWEsRUFBQ0MsZUFBQSxDQUFZQyxHQUFHLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQztBQUNoRTtBQUNBO0FBQ0EsTUFBTVYsUUFBTyxHQUFHLElBQUFXLHlCQUFhLEVBQUMsSUFBQUwsY0FBSSxFQUFDRCxJQUFJLEVBQUUsY0FBYyxDQUFDLENBQUM7QUFDekQsTUFBTU8sR0FBRyxHQUFHLENBQUMsTUFBTTtFQUNqQixJQUFJO0lBQ0YsT0FBT1osUUFBTyxDQUFDLEtBQUssQ0FBQztFQUN2QixDQUFDLENBQUMsTUFBTTtJQUNOYSxPQUFPLENBQUNDLEtBQUssQ0FBQyxnRkFBZ0YsQ0FBQztJQUMvRkMsT0FBTyxDQUFDQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0VBQ2pCO0FBQ0YsQ0FBQyxFQUFFLENBQUM7QUFDSixNQUFNQyxRQUFRLEdBQUdDLElBQUksQ0FBQ0MsS0FBSyxDQUFDLElBQUFDLG9CQUFZLEVBQUMsSUFBQWQsY0FBSSxFQUFDRCxJQUFJLEVBQUUsc0JBQXNCLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQztBQUNyRixNQUFNZ0IsTUFBTSxHQUFHLElBQUFELG9CQUFZLEVBQUMsSUFBQWQsY0FBSSxFQUFDRCxJQUFJLEVBQUUsc0JBQXNCLENBQUMsRUFBRSxNQUFNLENBQUM7O0FBRXZFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTaUIsWUFBWUEsQ0FBQ0MsR0FBRyxFQUFFO0VBQ3pCLE1BQU1DLEdBQUcsR0FBR0QsR0FBRyxDQUFDRSxLQUFLLENBQUMsRUFBRSxDQUFDO0VBQ3pCLElBQUlDLENBQUMsR0FBRyxDQUFDO0VBQ1QsTUFBTUMsT0FBTyxHQUFJQyxHQUFHLElBQUs7SUFDdkIsT0FBT0YsQ0FBQyxHQUFHRSxHQUFHLElBQUlGLENBQUMsR0FBR0YsR0FBRyxDQUFDSyxNQUFNLEVBQUVILENBQUMsRUFBRSxFQUFFLElBQUlGLEdBQUcsQ0FBQ0UsQ0FBQyxDQUFDLEtBQUssSUFBSSxFQUFFRixHQUFHLENBQUNFLENBQUMsQ0FBQyxHQUFHLEdBQUc7RUFDMUUsQ0FBQztFQUNELE9BQU9BLENBQUMsR0FBR0gsR0FBRyxDQUFDTSxNQUFNLEVBQUU7SUFDckIsTUFBTUMsR0FBRyxHQUFHUCxHQUFHLENBQUNRLEtBQUssQ0FBQ0wsQ0FBQyxFQUFFQSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQy9CLElBQUlJLEdBQUcsS0FBSyxJQUFJLEVBQUU7TUFDaEIsTUFBTUUsRUFBRSxHQUFHVCxHQUFHLENBQUNVLE9BQU8sQ0FBQyxJQUFJLEVBQUVQLENBQUMsQ0FBQztNQUMvQkMsT0FBTyxDQUFDSyxFQUFFLEtBQUssQ0FBQyxDQUFDLEdBQUdULEdBQUcsQ0FBQ00sTUFBTSxHQUFHRyxFQUFFLENBQUM7SUFDdEMsQ0FBQyxNQUFNLElBQUlGLEdBQUcsS0FBSyxJQUFJLEVBQUU7TUFDdkIsTUFBTUksS0FBSyxHQUFHWCxHQUFHLENBQUNVLE9BQU8sQ0FBQyxJQUFJLEVBQUVQLENBQUMsR0FBRyxDQUFDLENBQUM7TUFDdENDLE9BQU8sQ0FBQ08sS0FBSyxLQUFLLENBQUMsQ0FBQyxHQUFHWCxHQUFHLENBQUNNLE1BQU0sR0FBR0ssS0FBSyxHQUFHLENBQUMsQ0FBQztJQUNoRCxDQUFDLE1BQU0sSUFBSVgsR0FBRyxDQUFDRyxDQUFDLENBQUMsS0FBSyxHQUFHLElBQUlILEdBQUcsQ0FBQ0csQ0FBQyxDQUFDLEtBQUssR0FBRyxJQUFJSCxHQUFHLENBQUNHLENBQUMsQ0FBQyxLQUFLLEdBQUcsRUFBRTtNQUM3RCxNQUFNUyxLQUFLLEdBQUdaLEdBQUcsQ0FBQ0csQ0FBQyxDQUFDO01BQ3BCLElBQUlVLENBQUMsR0FBR1YsQ0FBQyxHQUFHLENBQUM7TUFDYixPQUFPVSxDQUFDLEdBQUdiLEdBQUcsQ0FBQ00sTUFBTSxJQUFJTixHQUFHLENBQUNhLENBQUMsQ0FBQyxLQUFLRCxLQUFLLEVBQUVDLENBQUMsSUFBSWIsR0FBRyxDQUFDYSxDQUFDLENBQUMsS0FBSyxJQUFJLEdBQUcsQ0FBQyxHQUFHLENBQUM7TUFDdkVULE9BQU8sQ0FBQ1UsSUFBSSxDQUFDQyxHQUFHLENBQUNGLENBQUMsR0FBRyxDQUFDLEVBQUViLEdBQUcsQ0FBQ00sTUFBTSxDQUFDLENBQUM7SUFDdEMsQ0FBQyxNQUFNO01BQ0xILENBQUMsRUFBRTtJQUNMO0VBQ0Y7RUFDQSxPQUFPRixHQUFHLENBQUNsQixJQUFJLENBQUMsRUFBRSxDQUFDO0FBQ3JCOztBQUVBO0FBQ0E7QUFDQSxTQUFTaUMsWUFBWUEsQ0FBQ0MsTUFBTSxFQUFFO0VBQzVCLE1BQU1qQixHQUFHLEdBQUdELFlBQVksQ0FBQ2tCLE1BQU0sQ0FBQztFQUNoQyxNQUFNQyxLQUFLLEdBQUdsQixHQUFHLENBQUNVLE9BQU8sQ0FBQyw0QkFBNEIsQ0FBQztFQUN2RCxJQUFJUSxLQUFLLEtBQUssQ0FBQyxDQUFDLEVBQUUsTUFBTSxJQUFJQyxLQUFLLENBQUMsNERBQTRELENBQUM7RUFDL0YsTUFBTUMsSUFBSSxHQUFHcEIsR0FBRyxDQUFDVSxPQUFPLENBQUMsR0FBRyxFQUFFUSxLQUFLLENBQUM7RUFDcEMsSUFBSUcsS0FBSyxHQUFHLENBQUM7RUFDYixJQUFJaEIsR0FBRyxHQUFHLENBQUMsQ0FBQztFQUNaLEtBQUssSUFBSVEsQ0FBQyxHQUFHTyxJQUFJLEVBQUVQLENBQUMsR0FBR2IsR0FBRyxDQUFDTSxNQUFNLEVBQUVPLENBQUMsRUFBRSxFQUFFO0lBQ3RDLElBQUliLEdBQUcsQ0FBQ2EsQ0FBQyxDQUFDLEtBQUssR0FBRyxFQUFFUSxLQUFLLEVBQUUsQ0FBQyxLQUN2QixJQUFJckIsR0FBRyxDQUFDYSxDQUFDLENBQUMsS0FBSyxHQUFHLEVBQUU7TUFDdkJRLEtBQUssRUFBRTtNQUNQLElBQUlBLEtBQUssS0FBSyxDQUFDLEVBQUU7UUFDZmhCLEdBQUcsR0FBR1EsQ0FBQztRQUNQO01BQ0Y7SUFDRjtFQUNGO0VBQ0EsSUFBSVIsR0FBRyxLQUFLLENBQUMsQ0FBQyxFQUFFLE1BQU0sSUFBSWMsS0FBSyxDQUFDLDBDQUEwQyxDQUFDO0VBQzNFLE1BQU1HLElBQUksR0FBRyxFQUFFO0VBQ2YsSUFBSUMsT0FBTyxHQUFHLENBQUM7RUFDZixLQUFLLE1BQU1DLElBQUksSUFBSXhCLEdBQUcsQ0FBQ1EsS0FBSyxDQUFDWSxJQUFJLEdBQUcsQ0FBQyxFQUFFZixHQUFHLENBQUMsQ0FBQ0gsS0FBSyxDQUFDLElBQUksQ0FBQyxFQUFFO0lBQ3ZEO0lBQ0E7SUFDQSxNQUFNdUIsTUFBTSxHQUFHRixPQUFPO0lBQ3RCLEtBQUssTUFBTUcsRUFBRSxJQUFJRixJQUFJLEVBQUU7TUFDckIsSUFBSUUsRUFBRSxLQUFLLEdBQUcsSUFBSUEsRUFBRSxLQUFLLEdBQUcsRUFBRUgsT0FBTyxFQUFFLENBQUMsS0FDbkMsSUFBSUcsRUFBRSxLQUFLLEdBQUcsSUFBSUEsRUFBRSxLQUFLLEdBQUcsRUFBRUgsT0FBTyxFQUFFO0lBQzlDO0lBQ0EsSUFBSUUsTUFBTSxLQUFLLENBQUMsRUFBRTtJQUNsQixNQUFNRSxDQUFDLEdBQUdILElBQUksQ0FBQ0ksS0FBSyxDQUFDLCtCQUErQixDQUFDO0lBQ3JELElBQUlELENBQUMsRUFBRUwsSUFBSSxDQUFDTyxJQUFJLENBQUNGLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUN4QjtFQUNBLE9BQU9MLElBQUk7QUFDYjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTVEsTUFBTSxHQUFHbkMsSUFBSSxDQUFDQyxLQUFLLENBQUMsSUFBQUMsb0JBQVksRUFBQyxJQUFBZCxjQUFJLEVBQUNELElBQUksRUFBRSw2QkFBNkIsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDO0FBQzFGLFNBQVNpRCxZQUFZQSxDQUFDSixDQUFDLEVBQUU7RUFDdkIsTUFBTUssR0FBRyxHQUFHLElBQUkzQyxHQUFHLENBQUM7SUFBRTRDLE1BQU0sRUFBRTtFQUFNLENBQUMsQ0FBQztFQUN0QyxNQUFNQyxRQUFRLEdBQUdGLEdBQUcsQ0FBQ0csT0FBTyxDQUFDTCxNQUFNLENBQUM7RUFDcEMsT0FBT0ksUUFBUSxDQUFDUCxDQUFDLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQ0ssR0FBRyxDQUFDSSxVQUFVLENBQUNGLFFBQVEsQ0FBQ0csTUFBTSxDQUFDLENBQUM7QUFDN0Q7QUFDQTtFQUNFLE1BQU1DLEtBQUssR0FBR1AsWUFBWSxDQUFDckMsUUFBUSxDQUFDO0VBQ3BDLElBQUk0QyxLQUFLLENBQUNoQyxNQUFNLEVBQUU7SUFDaEJoQixPQUFPLENBQUNDLEtBQUssQ0FBQyw0QkFBNEIrQyxLQUFLLENBQUNoQyxNQUFNLHFEQUFxRGdDLEtBQUssQ0FBQ3ZELElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO0lBQ2hJUyxPQUFPLENBQUNDLElBQUksQ0FBQyxDQUFDLENBQUM7RUFDakI7QUFDRjtBQUVBLE1BQU00QyxNQUFNLEdBQUcsRUFBRTtBQUVqQixNQUFNRSxRQUFRLEdBQUcsSUFBSUMsR0FBRyxDQUFDeEIsWUFBWSxDQUFDbEIsTUFBTSxDQUFDLENBQUM7QUFDOUMsTUFBTTJDLFFBQVEsR0FBRyxJQUFJRCxHQUFHLENBQUNFLE1BQU0sQ0FBQ3BCLElBQUksQ0FBQzVCLFFBQVEsQ0FBQ2lELFVBQVUsQ0FBQyxDQUFDO0FBRTFELEtBQUssTUFBTUMsSUFBSSxJQUFJTCxRQUFRLEVBQUU7RUFDM0IsSUFBSSxDQUFDRSxRQUFRLENBQUNJLEdBQUcsQ0FBQ0QsSUFBSSxDQUFDLEVBQUU7SUFDdkJQLE1BQU0sQ0FBQ1IsSUFBSSxDQUNULEtBQUtlLElBQUksOEVBQThFLEdBQ3JGLHNGQUFzRixHQUN0RixnQ0FDSixDQUFDO0VBQ0g7QUFDRjtBQUNBLEtBQUssTUFBTUEsSUFBSSxJQUFJSCxRQUFRLEVBQUU7RUFDM0IsSUFBSS9DLFFBQVEsQ0FBQ2lELFVBQVUsQ0FBQ0MsSUFBSSxDQUFDLENBQUNFLElBQUksS0FBSyxRQUFRLEVBQUUsU0FBUyxDQUFDO0VBQzNELElBQUksQ0FBQ1AsUUFBUSxDQUFDTSxHQUFHLENBQUNELElBQUksQ0FBQyxFQUFFO0lBQ3ZCUCxNQUFNLENBQUNSLElBQUksQ0FDVCxLQUFLZSxJQUFJLDhFQUE4RSxHQUNyRixzRkFDSixDQUFDO0VBQ0g7QUFDRjs7QUFFQTtBQUNBO0FBQ0EsTUFBTUcsR0FBRyxHQUFHcEQsSUFBSSxDQUFDQyxLQUFLLENBQUMsSUFBQUMsb0JBQVksRUFBQyxJQUFBZCxjQUFJLEVBQUNELElBQUksRUFBRSxjQUFjLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQztBQUN4RSxJQUFJWSxRQUFRLENBQUNzRCxNQUFNLENBQUNKLElBQUksS0FBS0csR0FBRyxDQUFDSCxJQUFJLEVBQUU7RUFDckNQLE1BQU0sQ0FBQ1IsSUFBSSxDQUFDLGtCQUFrQm5DLFFBQVEsQ0FBQ3NELE1BQU0sQ0FBQ0osSUFBSSwwQkFBMEJHLEdBQUcsQ0FBQ0gsSUFBSSxJQUFJLENBQUM7QUFDM0Y7QUFDQSxNQUFNSyxRQUFRLEdBQUcsQ0FBQ0YsR0FBRyxDQUFDLGlCQUFpQixDQUFDLEVBQUVFLFFBQVEsSUFBSSxFQUFFLEVBQUVDLEdBQUcsQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUNDLElBQUksQ0FBQztBQUM1RSxJQUFJMUQsUUFBUSxDQUFDc0QsTUFBTSxDQUFDSSxJQUFJLElBQUksQ0FBQ0gsUUFBUSxDQUFDSSxRQUFRLENBQUMzRCxRQUFRLENBQUNzRCxNQUFNLENBQUNJLElBQUksQ0FBQyxFQUFFO0VBQ3BFZixNQUFNLENBQUNSLElBQUksQ0FDVCxrQkFBa0JuQyxRQUFRLENBQUNzRCxNQUFNLENBQUNJLElBQUksb0RBQW9ELEdBQ3hGLElBQUlILFFBQVEsQ0FBQ2xFLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxNQUFNLElBQ3JDLENBQUM7QUFDSDs7QUFFQTtBQUNBLEtBQUssTUFBTSxDQUFDdUUsT0FBTyxFQUFFQyxNQUFNLENBQUMsSUFBSWIsTUFBTSxDQUFDYyxPQUFPLENBQUNULEdBQUcsQ0FBQ1UsT0FBTyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUU7RUFDakUsSUFBSTtJQUNGLElBQUE1RCxvQkFBWSxFQUFDLElBQUFkLGNBQUksRUFBQ0QsSUFBSSxFQUFFeUUsTUFBTSxDQUFDLENBQUM7RUFDbEMsQ0FBQyxDQUFDLE1BQU07SUFDTmxCLE1BQU0sQ0FBQ1IsSUFBSSxDQUFDLGNBQWN5QixPQUFPLFFBQVFDLE1BQU0sa0JBQWtCLENBQUM7RUFDcEU7QUFDRjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxNQUFNRyxXQUFXLEdBQUcsSUFBQTNFLGNBQUksRUFBQ0QsSUFBSSxFQUFFLFNBQVMsRUFBRSxVQUFVLENBQUM7QUFDckQsTUFBTTZFLFVBQVUsR0FDZCxJQUFBQyxrQkFBVSxFQUFDRixXQUFXLENBQUMsR0FDbkIsSUFBQUcsbUJBQVcsRUFBQ0gsV0FBVyxFQUFFO0VBQUVJLGFBQWEsRUFBRTtBQUFLLENBQUMsQ0FBQyxDQUM5Q0MsTUFBTSxDQUFFQyxDQUFDLElBQUtBLENBQUMsQ0FBQ0MsTUFBTSxDQUFDLENBQUMsSUFBSSxTQUFTLENBQUNDLElBQUksQ0FBQ0YsQ0FBQyxDQUFDcEIsSUFBSSxDQUFDLENBQUMsQ0FDbkRNLEdBQUcsQ0FBRWMsQ0FBQyxJQUFLQSxDQUFDLENBQUNwQixJQUFJLENBQUN1QixPQUFPLENBQUMsU0FBUyxFQUFFLEVBQUUsQ0FBQyxDQUFDLEdBQzVDLEVBQUU7O0FBRVI7QUFDQTtBQUNBLFNBQVNDLGFBQWFBLENBQUNDLElBQUksRUFBRTtFQUMzQixNQUFNckUsR0FBRyxHQUFHLElBQUFILG9CQUFZLEVBQUMsSUFBQWQsY0FBSSxFQUFDMkUsV0FBVyxFQUFFVyxJQUFJLENBQUMsRUFBRSxNQUFNLENBQUM7RUFDekQsTUFBTTFDLENBQUMsR0FBRzNCLEdBQUcsQ0FBQzRCLEtBQUssQ0FBQyx1QkFBdUIsQ0FBQztFQUM1QyxNQUFNMEMsRUFBRSxHQUFHLENBQUMsQ0FBQztFQUNiLElBQUkzQyxDQUFDLEVBQUUsS0FBSyxNQUFNSCxJQUFJLElBQUlHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ3pCLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFBRTtJQUMxQyxNQUFNcUUsRUFBRSxHQUFHL0MsSUFBSSxDQUFDSSxLQUFLLENBQUMsaUJBQWlCLENBQUM7SUFDeEMsSUFBSTJDLEVBQUUsRUFBRUQsRUFBRSxDQUFDQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBR0EsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDQyxJQUFJLENBQUMsQ0FBQyxDQUFDTCxPQUFPLENBQUMsY0FBYyxFQUFFLEVBQUUsQ0FBQztFQUM5RDtFQUNBLE9BQU9HLEVBQUU7QUFDWDtBQUVBLE1BQU1HLGVBQWUsR0FBRy9FLFFBQVEsQ0FBQ2dGLE9BQU8sSUFBSSxDQUFDLENBQUM7QUFDOUMsS0FBSyxNQUFNLENBQUNDLEVBQUUsRUFBRUMsS0FBSyxDQUFDLElBQUlsQyxNQUFNLENBQUNjLE9BQU8sQ0FBQ2lCLGVBQWUsQ0FBQyxFQUFFO0VBQ3pELElBQUlHLEtBQUssQ0FBQ0MsS0FBSyxJQUFJLENBQUNsQixVQUFVLENBQUNOLFFBQVEsQ0FBQ3NCLEVBQUUsQ0FBQyxFQUFFO0lBQzNDdEMsTUFBTSxDQUFDUixJQUFJLENBQUMsYUFBYThDLEVBQUUsK0NBQStDQSxFQUFFLHNCQUFzQixDQUFDO0VBQ3JHO0VBQ0EsSUFBSUMsS0FBSyxDQUFDQyxLQUFLLEVBQUU7SUFDZixNQUFNUCxFQUFFLEdBQUdGLGFBQWEsQ0FBQyxHQUFHTyxFQUFFLE1BQU0sQ0FBQztJQUNyQyxJQUFJTCxFQUFFLENBQUNRLFVBQVUsS0FBS0YsS0FBSyxDQUFDRSxVQUFVLEVBQUU7TUFDdEN6QyxNQUFNLENBQUNSLElBQUksQ0FDVCxhQUFhOEMsRUFBRSwrQkFBK0JDLEtBQUssQ0FBQ0UsVUFBVSxtQ0FBbUMsR0FDL0YsR0FBR25GLElBQUksQ0FBQ29GLFNBQVMsQ0FBQ1QsRUFBRSxDQUFDUSxVQUFVLENBQUMsdUJBQ3BDLENBQUM7SUFDSDtJQUNBLElBQUlSLEVBQUUsQ0FBQ1UsR0FBRyxJQUFJVixFQUFFLENBQUNVLEdBQUcsS0FBSyxLQUFLLElBQUlWLEVBQUUsQ0FBQ1UsR0FBRyxLQUFLLE1BQU0sRUFBRTtNQUNuRDNDLE1BQU0sQ0FBQ1IsSUFBSSxDQUFDLGFBQWE4QyxFQUFFLFVBQVVMLEVBQUUsQ0FBQ1UsR0FBRyx3RUFBd0UsQ0FBQztJQUN0SDtFQUNGO0FBQ0Y7QUFDQSxLQUFLLE1BQU1MLEVBQUUsSUFBSWhCLFVBQVUsRUFBRTtFQUMzQixJQUFJLENBQUNjLGVBQWUsQ0FBQ0UsRUFBRSxDQUFDLEVBQUU7SUFDeEJ0QyxNQUFNLENBQUNSLElBQUksQ0FDVCxzQkFBc0I4QyxFQUFFLG9FQUFvRSxHQUMxRixtR0FDSixDQUFDO0VBQ0g7QUFDRjs7QUFFQTtBQUNBO0FBQ0EsTUFBTU0sV0FBVyxHQUFHdkYsUUFBUSxDQUFDdUYsV0FBVyxJQUFJLENBQUMsQ0FBQztBQUM5QyxLQUFLLE1BQU0sQ0FBQ04sRUFBRSxFQUFFQyxLQUFLLENBQUMsSUFBSWxDLE1BQU0sQ0FBQ2MsT0FBTyxDQUFDeUIsV0FBVyxDQUFDLEVBQUU7RUFDckQsSUFBSUwsS0FBSyxDQUFDTSxTQUFTLElBQUksQ0FBQzNDLFFBQVEsQ0FBQ00sR0FBRyxDQUFDK0IsS0FBSyxDQUFDTSxTQUFTLENBQUMsRUFBRTtJQUNyRDdDLE1BQU0sQ0FBQ1IsSUFBSSxDQUNULGlCQUFpQjhDLEVBQUUsZ0JBQWdCQyxLQUFLLENBQUNNLFNBQVMsMkNBQTJDLEdBQzNGLHVEQUNKLENBQUM7RUFDSDtFQUNBLEtBQUssTUFBTSxDQUFDQyxJQUFJLEVBQUVDLEtBQUssQ0FBQyxJQUFJMUMsTUFBTSxDQUFDYyxPQUFPLENBQUNvQixLQUFLLENBQUNTLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFO0lBQzdELElBQUksVUFBVSxDQUFDbkIsSUFBSSxDQUFDa0IsS0FBSyxDQUFDLEVBQUU7TUFDMUIvQyxNQUFNLENBQUNSLElBQUksQ0FBQyxpQkFBaUI4QyxFQUFFLFlBQVlRLElBQUksc0JBQXNCQyxLQUFLLHVDQUF1QyxDQUFDO0lBQ3BIO0VBQ0Y7QUFDRjtBQUVBLElBQUkvQyxNQUFNLENBQUMvQixNQUFNLEVBQUU7RUFDakJoQixPQUFPLENBQUNDLEtBQUssQ0FBQyw0QkFBNEI4QyxNQUFNLENBQUMvQixNQUFNLE9BQU8rQixNQUFNLENBQUN0RCxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQztFQUNsRlMsT0FBTyxDQUFDQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ2pCO0FBQ0FILE9BQU8sQ0FBQ2dHLEdBQUcsQ0FDVCxNQUFNNUYsUUFBUSxDQUFDc0QsTUFBTSxDQUFDSixJQUFJLEtBQUtILFFBQVEsQ0FBQzhDLElBQUksd0JBQXdCLEdBQ2xFLEdBQUcsQ0FBQyxHQUFHOUMsUUFBUSxDQUFDLENBQUNzQixNQUFNLENBQUV5QixDQUFDLElBQUs5RixRQUFRLENBQUNpRCxVQUFVLENBQUM2QyxDQUFDLENBQUMsQ0FBQ0MsV0FBVyxDQUFDLENBQUNuRixNQUFNLGdCQUFnQixHQUN6RixHQUFHb0MsTUFBTSxDQUFDcEIsSUFBSSxDQUFDeUIsR0FBRyxDQUFDVSxPQUFPLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQ25ELE1BQU0sNEJBQTRCLEdBQ3BFLEdBQUdxRCxVQUFVLENBQUNyRCxNQUFNLHVCQUF1Qm9DLE1BQU0sQ0FBQ3BCLElBQUksQ0FBQzJELFdBQVcsQ0FBQyxDQUFDM0UsTUFBTSx1QkFDOUUsQ0FBQzs7QUFFRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTW9GLFFBQVEsR0FBR0EsQ0FBQSxLQUFNO0VBQ3JCLE1BQU1DLEtBQUssR0FBRyxFQUFFO0VBQ2hCQSxLQUFLLENBQUM5RCxJQUFJLENBQUMsQ0FBQyw0QkFBNEIsRUFBRSxNQUFNRSxZQUFZLENBQUNyQyxRQUFRLENBQUMsQ0FBQ1ksTUFBTSxLQUFLLENBQUMsQ0FBQyxDQUFDO0VBQ3JGcUYsS0FBSyxDQUFDOUQsSUFBSSxDQUFDLENBQUMsK0JBQStCLEVBQUUsTUFDM0NFLFlBQVksQ0FBQztJQUFFLEdBQUdyQyxRQUFRO0lBQUVrRyxRQUFRLEVBQUU7RUFBSSxDQUFDLENBQUMsQ0FBQ3RGLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQztFQUMzRHFGLEtBQUssQ0FBQzlELElBQUksQ0FBQyxDQUFDLDBFQUEwRSxFQUFFLE1BQU07SUFDNUYsTUFBTTtNQUFFYyxVQUFVO01BQUUsR0FBR2tEO0lBQUssQ0FBQyxHQUFHbkcsUUFBUTtJQUN4QyxPQUFPcUMsWUFBWSxDQUFDOEQsSUFBSSxDQUFDLENBQUN2RixNQUFNLEdBQUcsQ0FBQztFQUN0QyxDQUFDLENBQUMsQ0FBQztFQUNIO0VBQ0E7RUFDQSxNQUFNd0YsUUFBUSxHQUFHO0lBQ2ZDLGFBQWEsRUFBRSxDQUFDO0lBQ2hCL0MsTUFBTSxFQUFFO01BQUVKLElBQUksRUFBRSxxQkFBcUI7TUFBRW9ELElBQUksRUFBRSxTQUFTO01BQUU1QyxJQUFJLEVBQUU7SUFBZSxDQUFDO0lBQzlFVCxVQUFVLEVBQUU7TUFDVnNELFFBQVEsRUFBRTtRQUFFbkQsSUFBSSxFQUFFLFFBQVE7UUFBRTJDLFdBQVcsRUFBRSxJQUFJO1FBQUVTLFVBQVUsRUFBRSxLQUFLO1FBQUViLEtBQUssRUFBRTtVQUFFYyxLQUFLLEVBQUUsU0FBUztVQUFFOUUsS0FBSyxFQUFFO1FBQVUsQ0FBQztRQUFFK0UsT0FBTyxFQUFFO01BQVUsQ0FBQztNQUNySUMsUUFBUSxFQUFFO1FBQUV2RCxJQUFJLEVBQUUsUUFBUTtRQUFFMkMsV0FBVyxFQUFFLElBQUk7UUFBRVMsVUFBVSxFQUFFLEtBQUs7UUFBRWIsS0FBSyxFQUFFO1VBQUVpQixJQUFJLEVBQUUsUUFBUTtVQUFFQyxFQUFFLEVBQUU7UUFBUyxDQUFDO1FBQUVILE9BQU8sRUFBRTtNQUFXLENBQUM7TUFDaElJLE1BQU0sRUFBRTtRQUFFMUQsSUFBSSxFQUFFLFFBQVE7UUFBRTJDLFdBQVcsRUFBRSxJQUFJO1FBQUVTLFVBQVUsRUFBRSxLQUFLO1FBQUViLEtBQUssRUFBRSxDQUFDLENBQUM7UUFBRWUsT0FBTyxFQUFFO01BQWMsQ0FBQztNQUNuR0ssU0FBUyxFQUFFO1FBQUUzRCxJQUFJLEVBQUUsUUFBUTtRQUFFMkMsV0FBVyxFQUFFLElBQUk7UUFBRVMsVUFBVSxFQUFFLEtBQUs7UUFBRWIsS0FBSyxFQUFFLENBQUMsQ0FBQztRQUFFZSxPQUFPLEVBQUU7TUFBeUI7SUFDbEgsQ0FBQztJQUNETSxXQUFXLEVBQUU7TUFBRUMsTUFBTSxFQUFFLENBQUMsTUFBTSxFQUFFLFdBQVcsQ0FBQztNQUFFQyxhQUFhLEVBQUUsQ0FBQyxNQUFNLENBQUM7TUFBRUMsV0FBVyxFQUFFO0lBQUs7RUFDM0YsQ0FBQztFQUNEbEIsS0FBSyxDQUFDOUQsSUFBSSxDQUFDLENBQUMsdURBQXVELEVBQUUsTUFBTUUsWUFBWSxDQUFDK0QsUUFBUSxDQUFDLENBQUN4RixNQUFNLEtBQUssQ0FBQyxDQUFDLENBQUM7RUFDaEhxRixLQUFLLENBQUM5RCxJQUFJLENBQUMsQ0FBQyw2Q0FBNkMsRUFBRSxNQUN6REUsWUFBWSxDQUFDO0lBQUUsR0FBRytELFFBQVE7SUFBRW5ELFVBQVUsRUFBRTtNQUFFbUUsQ0FBQyxFQUFFO1FBQUVoRSxJQUFJLEVBQUUsUUFBUTtRQUFFMkMsV0FBVyxFQUFFO01BQUs7SUFBRTtFQUFFLENBQUMsQ0FBQyxDQUFDbkYsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDO0VBRXRHLElBQUl5RyxNQUFNLEdBQUcsQ0FBQztFQUNkLEtBQUssTUFBTSxDQUFDbkUsSUFBSSxFQUFFb0UsRUFBRSxDQUFDLElBQUlyQixLQUFLLEVBQUU7SUFDOUIsSUFBSXNCLElBQUksR0FBRyxLQUFLO0lBQ2hCLElBQUk7TUFDRkEsSUFBSSxHQUFHRCxFQUFFLENBQUMsQ0FBQztJQUNiLENBQUMsQ0FBQyxNQUFNO01BQ05DLElBQUksR0FBRyxLQUFLO0lBQ2Q7SUFDQTNILE9BQU8sQ0FBQ2dHLEdBQUcsQ0FBQyxHQUFHMkIsSUFBSSxHQUFHLEdBQUcsR0FBRyxHQUFHLElBQUlyRSxJQUFJLEVBQUUsQ0FBQztJQUMxQyxJQUFJLENBQUNxRSxJQUFJLEVBQUVGLE1BQU0sRUFBRTtFQUNyQjtFQUNBekgsT0FBTyxDQUFDZ0csR0FBRyxDQUFDLEtBQUtLLEtBQUssQ0FBQ3JGLE1BQU0sR0FBR3lHLE1BQU0sSUFBSXBCLEtBQUssQ0FBQ3JGLE1BQU0sbUJBQW1CLENBQUM7RUFDMUUsT0FBT3lHLE1BQU0sS0FBSyxDQUFDO0FBQ3JCLENBQUM7QUFFRCxJQUFJdkgsT0FBTyxDQUFDMEgsSUFBSSxDQUFDN0QsUUFBUSxDQUFDLGFBQWEsQ0FBQyxFQUFFN0QsT0FBTyxDQUFDQyxJQUFJLENBQUNpRyxRQUFRLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}