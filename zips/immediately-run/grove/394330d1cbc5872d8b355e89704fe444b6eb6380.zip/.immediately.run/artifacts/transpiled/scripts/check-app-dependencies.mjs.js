var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {#!/usr/bin/env node
/*
 * Everything `src/` imports at runtime must be in `dependencies`.
 *
 * Grove is BOTH a library and an app, and the two roles want opposite things from
 * package.json:
 *
 *   · as a LIBRARY, `react`/`react-dom`/`@immediately-run/sdk` are peers — the
 *     consumer supplies one React and one SDK, and grove must not bring a second;
 *   · as an APP, the immediately.run sandbox resolves the dependency tree from
 *     `dependencies` ALONE (`bundler.loadNodeModules` → `parsedPackageJSON.dependencies`).
 *     A peer is not fetched: at the ROOT of a run there is no consumer to supply it.
 *
 * R3-280 packaged the library role and moved those three out of `dependencies`. The
 * app role then died at boot — and not with "react is missing", but with
 *
 *     Cannot find module 'react' from '/node_modules/react-error-boundary/…'
 *
 * because the React preset injects `react-error-boundary` (an SDK dependency) into
 * every app, and IT imports react. The name in the error is a package grove never
 * mentions, which is why the cause is not obvious from the symptom. `npm run verify`,
 * `vite build` and every test passed the whole time: a bundler resolves from
 * node_modules, where devDependencies are just as present.
 *
 * So this check reads what the SOURCE imports and asserts the manifest declares it.
 * It is the only gate here that can see the difference, because it is the only one
 * that reads package.json instead of node_modules.
 *
 * Usage: node scripts/check-app-dependencies.mjs [--self-test]
 */
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.packageOf = exports.importedPackages = exports.findMissing = void 0;
var _nodeFs = require("node:fs");
var _nodePath = require("node:path");
var _nodeUrl = require("node:url");
const ROOT = (0, _nodePath.join)((0, _nodePath.dirname)((0, _nodeUrl.fileURLToPath)($ir_import_meta.url)), '..');

/** Node builtins and virtual specifiers no manifest declares. */
const BUILTIN = /^(node:|bun:)/;
/** Vite/toolchain specifiers that never resolve through node_modules at runtime. */
const VIRTUAL = new Set(['virtual:', 'vite/client']);
/**
 * Modules the SANDBOX itself preloads, so an app imports them without declaring
 * anything (`bundler.preloadModules`). `fs` is the notable one: it is not a CDN
 * polyfill but the shared filesystem backed by the parent window over the Port —
 * the thing every Grove read goes through. Kept as an explicit list rather than a
 * blanket "node builtins are fine", because these are provided by THIS platform
 * and the set is a contract that could change.
 */
const SANDBOX_PROVIDED = new Set(['fs', 'path', 'util', 'assert', 'module', 'os']);

/** The package name a specifier belongs to: `react-dom/client` → `react-dom`,
 *  `@scope/pkg/sub` → `@scope/pkg`. */
const packageOf = spec => {
  const parts = spec.split('/');
  return spec.startsWith('@') ? parts.slice(0, 2).join('/') : parts[0];
};

/** Every bare package a source file imports (static, dynamic, and re-export). */
exports.packageOf = packageOf;
const importedPackages = source => {
  const out = new Set();
  const patterns = [/(?:^|[\s;}])(?:import|export)\b[^;'"]*?\sfrom\s*["']([^"']+)["']/g, /(?:^|[\s;}])import\s*["']([^"']+)["']/g, /\bimport\(\s*["']([^"']+)["']\s*\)/g, /\brequire\(\s*["']([^"']+)["']\s*\)/g];
  for (const re of patterns) {
    for (const m of source.matchAll(re)) {
      const spec = m[1];
      if (spec.startsWith('.') || spec.startsWith('/')) continue;
      if (BUILTIN.test(spec) || VIRTUAL.has(spec) || spec.startsWith('virtual:')) continue;
      if (SANDBOX_PROVIDED.has(packageOf(spec))) continue;
      out.add(packageOf(spec));
    }
  }
  return out;
};

/** Runtime source files — the app's own code. Tests are excluded: they run under
 *  vitest in node, where devDependencies are exactly the right home. */
exports.importedPackages = importedPackages;
const sourceFiles = (dir, rel = '') => {
  const out = [];
  for (const entry of (0, _nodeFs.readdirSync)(dir, {
    withFileTypes: true
  })) {
    const childRel = rel ? `${rel}/${entry.name}` : entry.name;
    if (entry.isDirectory()) out.push(...sourceFiles((0, _nodePath.join)(dir, entry.name), childRel));else if (/\.(ts|tsx|js|jsx)$/.test(entry.name) && !/\.test\.(ts|tsx|js|jsx)$/.test(entry.name)) {
      out.push(childRel);
    }
  }
  return out;
};
const findMissing = (readFile, files, declared) => {
  const missing = new Map();
  for (const file of files) {
    for (const pkg of importedPackages(readFile(file))) {
      if (declared.has(pkg)) continue;
      if (!missing.has(pkg)) missing.set(pkg, []);
      missing.get(pkg).push(file);
    }
  }
  return missing;
};
exports.findMissing = findMissing;
const selfTest = () => {
  const cases = [{
    name: 'a relative import needs no declaration',
    src: 'import { a } from "./x";',
    declared: [],
    want: 0
  }, {
    name: 'a node builtin needs no declaration',
    src: 'import { join } from "node:path";',
    declared: [],
    want: 0
  }, {
    name: 'a declared package is fine',
    src: 'import React from "react";',
    declared: ['react'],
    want: 0
  }, {
    name: 'THE R3-280 REGRESSION: react imported, not declared',
    src: 'import React from "react";',
    declared: [],
    want: 1
  }, {
    name: 'a SUBPATH counts as its package',
    src: 'import { createRoot } from "react-dom/client";',
    declared: ['react-dom'],
    want: 0
  }, {
    name: '…and is reported under the package name',
    src: 'import x from "@immediately-run/sdk/boot";',
    declared: [],
    want: 1
  }, {
    name: 'a scoped package keeps both segments',
    src: 'import x from "@scope/pkg/deep/path";',
    declared: ['@scope/pkg'],
    want: 0
  }, {
    name: 'a dynamic import counts',
    src: 'const m = await import("some-pkg");',
    declared: [],
    want: 1
  }, {
    name: 'a re-export counts',
    src: 'export { x } from "some-pkg";',
    declared: [],
    want: 1
  }, {
    name: 'the sandbox-preloaded `fs` needs no declaration',
    src: 'import fs from "fs";',
    declared: [],
    want: 0
  }, {
    name: '…and so do the other preloaded builtins',
    src: 'import { join } from "path";',
    declared: [],
    want: 0
  }];
  let failed = 0;
  for (const c of cases) {
    const got = findMissing(() => c.src, ['f.ts'], new Set(c.declared)).size;
    const ok = got === c.want;
    if (!ok) failed++;
    console.log(`${ok ? 'PASS' : 'FAIL'}  ${c.name} (expected ${c.want}, got ${got})`);
  }
  console.log(`\n${cases.length - failed}/${cases.length} self-test cases.`);
  return failed === 0;
};
if (process.argv.includes('--self-test')) {
  process.exit(selfTest() ? 0 : 1);
}
const pkg = JSON.parse((0, _nodeFs.readFileSync)((0, _nodePath.join)(ROOT, 'package.json'), 'utf8'));
const declared = new Set(Object.keys(pkg.dependencies ?? {}));
const files = sourceFiles((0, _nodePath.join)(ROOT, 'src'));
const missing = findMissing(f => (0, _nodeFs.readFileSync)((0, _nodePath.join)(ROOT, 'src', f), 'utf8'), files, declared);
if (missing.size === 0) {
  console.log(`OK: every package src/ imports is in "dependencies" (${files.length} file(s), ${declared.size} declared).`);
  process.exit(0);
}
console.error(`::error::${missing.size} package(s) imported by src/ but absent from "dependencies".\n` + 'The sandbox resolves an app\'s modules from `dependencies` alone — a peer or a\n' + 'devDependency is NOT fetched, and the app dies at boot naming some other package\n' + 'that needed it. Declare them in `dependencies`; keep the peer entry too if the\n' + 'library role needs it (both is legal, and what `file-explorer` does).\n');
for (const [pkgName, files_] of missing) {
  const where = pkg.peerDependencies?.[pkgName] ? ' (declared as a PEER only)' : pkg.devDependencies?.[pkgName] ? ' (declared as a devDependency only)' : '';
  console.error(`  ${pkgName}${where}\n    ${files_.slice(0, 4).join('\n    ')}`);
}
process.exit(1);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJPYmplY3QiLCJkZWZpbmVQcm9wZXJ0eSIsImV4cG9ydHMiLCJ2YWx1ZSIsInBhY2thZ2VPZiIsImltcG9ydGVkUGFja2FnZXMiLCJmaW5kTWlzc2luZyIsIl9ub2RlRnMiLCJyZXF1aXJlIiwiX25vZGVQYXRoIiwiX25vZGVVcmwiLCJST09UIiwiam9pbiIsImRpcm5hbWUiLCJmaWxlVVJMVG9QYXRoIiwiJGlyX2ltcG9ydF9tZXRhIiwidXJsIiwiQlVJTFRJTiIsIlZJUlRVQUwiLCJTZXQiLCJTQU5EQk9YX1BST1ZJREVEIiwic3BlYyIsInBhcnRzIiwic3BsaXQiLCJzdGFydHNXaXRoIiwic2xpY2UiLCJzb3VyY2UiLCJvdXQiLCJwYXR0ZXJucyIsInJlIiwibSIsIm1hdGNoQWxsIiwidGVzdCIsImhhcyIsImFkZCIsInNvdXJjZUZpbGVzIiwiZGlyIiwicmVsIiwiZW50cnkiLCJyZWFkZGlyU3luYyIsIndpdGhGaWxlVHlwZXMiLCJjaGlsZFJlbCIsIm5hbWUiLCJpc0RpcmVjdG9yeSIsInB1c2giLCJyZWFkRmlsZSIsImZpbGVzIiwiZGVjbGFyZWQiLCJtaXNzaW5nIiwiTWFwIiwiZmlsZSIsInBrZyIsInNldCIsImdldCIsInNlbGZUZXN0IiwiY2FzZXMiLCJzcmMiLCJ3YW50IiwiZmFpbGVkIiwiYyIsImdvdCIsInNpemUiLCJvayIsImNvbnNvbGUiLCJsb2ciLCJsZW5ndGgiLCJwcm9jZXNzIiwiYXJndiIsImluY2x1ZGVzIiwiZXhpdCIsIkpTT04iLCJwYXJzZSIsInJlYWRGaWxlU3luYyIsImtleXMiLCJkZXBlbmRlbmNpZXMiLCJmIiwiZXJyb3IiLCJwa2dOYW1lIiwiZmlsZXNfIiwid2hlcmUiLCJwZWVyRGVwZW5kZW5jaWVzIiwiZGV2RGVwZW5kZW5jaWVzIl0sInNvdXJjZXMiOlsiY2hlY2stYXBwLWRlcGVuZGVuY2llcy5tanMiXSwic291cmNlc0NvbnRlbnQiOlsiIyEvdXNyL2Jpbi9lbnYgbm9kZVxuLypcbiAqIEV2ZXJ5dGhpbmcgYHNyYy9gIGltcG9ydHMgYXQgcnVudGltZSBtdXN0IGJlIGluIGBkZXBlbmRlbmNpZXNgLlxuICpcbiAqIEdyb3ZlIGlzIEJPVEggYSBsaWJyYXJ5IGFuZCBhbiBhcHAsIGFuZCB0aGUgdHdvIHJvbGVzIHdhbnQgb3Bwb3NpdGUgdGhpbmdzIGZyb21cbiAqIHBhY2thZ2UuanNvbjpcbiAqXG4gKiAgIMK3IGFzIGEgTElCUkFSWSwgYHJlYWN0YC9gcmVhY3QtZG9tYC9gQGltbWVkaWF0ZWx5LXJ1bi9zZGtgIGFyZSBwZWVycyDigJQgdGhlXG4gKiAgICAgY29uc3VtZXIgc3VwcGxpZXMgb25lIFJlYWN0IGFuZCBvbmUgU0RLLCBhbmQgZ3JvdmUgbXVzdCBub3QgYnJpbmcgYSBzZWNvbmQ7XG4gKiAgIMK3IGFzIGFuIEFQUCwgdGhlIGltbWVkaWF0ZWx5LnJ1biBzYW5kYm94IHJlc29sdmVzIHRoZSBkZXBlbmRlbmN5IHRyZWUgZnJvbVxuICogICAgIGBkZXBlbmRlbmNpZXNgIEFMT05FIChgYnVuZGxlci5sb2FkTm9kZU1vZHVsZXNgIOKGkiBgcGFyc2VkUGFja2FnZUpTT04uZGVwZW5kZW5jaWVzYCkuXG4gKiAgICAgQSBwZWVyIGlzIG5vdCBmZXRjaGVkOiBhdCB0aGUgUk9PVCBvZiBhIHJ1biB0aGVyZSBpcyBubyBjb25zdW1lciB0byBzdXBwbHkgaXQuXG4gKlxuICogUjMtMjgwIHBhY2thZ2VkIHRoZSBsaWJyYXJ5IHJvbGUgYW5kIG1vdmVkIHRob3NlIHRocmVlIG91dCBvZiBgZGVwZW5kZW5jaWVzYC4gVGhlXG4gKiBhcHAgcm9sZSB0aGVuIGRpZWQgYXQgYm9vdCDigJQgYW5kIG5vdCB3aXRoIFwicmVhY3QgaXMgbWlzc2luZ1wiLCBidXQgd2l0aFxuICpcbiAqICAgICBDYW5ub3QgZmluZCBtb2R1bGUgJ3JlYWN0JyBmcm9tICcvbm9kZV9tb2R1bGVzL3JlYWN0LWVycm9yLWJvdW5kYXJ5L+KApidcbiAqXG4gKiBiZWNhdXNlIHRoZSBSZWFjdCBwcmVzZXQgaW5qZWN0cyBgcmVhY3QtZXJyb3ItYm91bmRhcnlgIChhbiBTREsgZGVwZW5kZW5jeSkgaW50b1xuICogZXZlcnkgYXBwLCBhbmQgSVQgaW1wb3J0cyByZWFjdC4gVGhlIG5hbWUgaW4gdGhlIGVycm9yIGlzIGEgcGFja2FnZSBncm92ZSBuZXZlclxuICogbWVudGlvbnMsIHdoaWNoIGlzIHdoeSB0aGUgY2F1c2UgaXMgbm90IG9idmlvdXMgZnJvbSB0aGUgc3ltcHRvbS4gYG5wbSBydW4gdmVyaWZ5YCxcbiAqIGB2aXRlIGJ1aWxkYCBhbmQgZXZlcnkgdGVzdCBwYXNzZWQgdGhlIHdob2xlIHRpbWU6IGEgYnVuZGxlciByZXNvbHZlcyBmcm9tXG4gKiBub2RlX21vZHVsZXMsIHdoZXJlIGRldkRlcGVuZGVuY2llcyBhcmUganVzdCBhcyBwcmVzZW50LlxuICpcbiAqIFNvIHRoaXMgY2hlY2sgcmVhZHMgd2hhdCB0aGUgU09VUkNFIGltcG9ydHMgYW5kIGFzc2VydHMgdGhlIG1hbmlmZXN0IGRlY2xhcmVzIGl0LlxuICogSXQgaXMgdGhlIG9ubHkgZ2F0ZSBoZXJlIHRoYXQgY2FuIHNlZSB0aGUgZGlmZmVyZW5jZSwgYmVjYXVzZSBpdCBpcyB0aGUgb25seSBvbmVcbiAqIHRoYXQgcmVhZHMgcGFja2FnZS5qc29uIGluc3RlYWQgb2Ygbm9kZV9tb2R1bGVzLlxuICpcbiAqIFVzYWdlOiBub2RlIHNjcmlwdHMvY2hlY2stYXBwLWRlcGVuZGVuY2llcy5tanMgWy0tc2VsZi10ZXN0XVxuICovXG5pbXBvcnQgeyByZWFkZGlyU3luYywgcmVhZEZpbGVTeW5jIH0gZnJvbSAnbm9kZTpmcyc7XG5pbXBvcnQgeyBqb2luLCBkaXJuYW1lIH0gZnJvbSAnbm9kZTpwYXRoJztcbmltcG9ydCB7IGZpbGVVUkxUb1BhdGggfSBmcm9tICdub2RlOnVybCc7XG5cbmNvbnN0IFJPT1QgPSBqb2luKGRpcm5hbWUoZmlsZVVSTFRvUGF0aChpbXBvcnQubWV0YS51cmwpKSwgJy4uJyk7XG5cbi8qKiBOb2RlIGJ1aWx0aW5zIGFuZCB2aXJ0dWFsIHNwZWNpZmllcnMgbm8gbWFuaWZlc3QgZGVjbGFyZXMuICovXG5jb25zdCBCVUlMVElOID0gL14obm9kZTp8YnVuOikvO1xuLyoqIFZpdGUvdG9vbGNoYWluIHNwZWNpZmllcnMgdGhhdCBuZXZlciByZXNvbHZlIHRocm91Z2ggbm9kZV9tb2R1bGVzIGF0IHJ1bnRpbWUuICovXG5jb25zdCBWSVJUVUFMID0gbmV3IFNldChbJ3ZpcnR1YWw6JywgJ3ZpdGUvY2xpZW50J10pO1xuLyoqXG4gKiBNb2R1bGVzIHRoZSBTQU5EQk9YIGl0c2VsZiBwcmVsb2Fkcywgc28gYW4gYXBwIGltcG9ydHMgdGhlbSB3aXRob3V0IGRlY2xhcmluZ1xuICogYW55dGhpbmcgKGBidW5kbGVyLnByZWxvYWRNb2R1bGVzYCkuIGBmc2AgaXMgdGhlIG5vdGFibGUgb25lOiBpdCBpcyBub3QgYSBDRE5cbiAqIHBvbHlmaWxsIGJ1dCB0aGUgc2hhcmVkIGZpbGVzeXN0ZW0gYmFja2VkIGJ5IHRoZSBwYXJlbnQgd2luZG93IG92ZXIgdGhlIFBvcnQg4oCUXG4gKiB0aGUgdGhpbmcgZXZlcnkgR3JvdmUgcmVhZCBnb2VzIHRocm91Z2guIEtlcHQgYXMgYW4gZXhwbGljaXQgbGlzdCByYXRoZXIgdGhhbiBhXG4gKiBibGFua2V0IFwibm9kZSBidWlsdGlucyBhcmUgZmluZVwiLCBiZWNhdXNlIHRoZXNlIGFyZSBwcm92aWRlZCBieSBUSElTIHBsYXRmb3JtXG4gKiBhbmQgdGhlIHNldCBpcyBhIGNvbnRyYWN0IHRoYXQgY291bGQgY2hhbmdlLlxuICovXG5jb25zdCBTQU5EQk9YX1BST1ZJREVEID0gbmV3IFNldChbJ2ZzJywgJ3BhdGgnLCAndXRpbCcsICdhc3NlcnQnLCAnbW9kdWxlJywgJ29zJ10pO1xuXG4vKiogVGhlIHBhY2thZ2UgbmFtZSBhIHNwZWNpZmllciBiZWxvbmdzIHRvOiBgcmVhY3QtZG9tL2NsaWVudGAg4oaSIGByZWFjdC1kb21gLFxuICogIGBAc2NvcGUvcGtnL3N1YmAg4oaSIGBAc2NvcGUvcGtnYC4gKi9cbmV4cG9ydCBjb25zdCBwYWNrYWdlT2YgPSAoc3BlYykgPT4ge1xuICBjb25zdCBwYXJ0cyA9IHNwZWMuc3BsaXQoJy8nKTtcbiAgcmV0dXJuIHNwZWMuc3RhcnRzV2l0aCgnQCcpID8gcGFydHMuc2xpY2UoMCwgMikuam9pbignLycpIDogcGFydHNbMF07XG59O1xuXG4vKiogRXZlcnkgYmFyZSBwYWNrYWdlIGEgc291cmNlIGZpbGUgaW1wb3J0cyAoc3RhdGljLCBkeW5hbWljLCBhbmQgcmUtZXhwb3J0KS4gKi9cbmV4cG9ydCBjb25zdCBpbXBvcnRlZFBhY2thZ2VzID0gKHNvdXJjZSkgPT4ge1xuICBjb25zdCBvdXQgPSBuZXcgU2V0KCk7XG4gIGNvbnN0IHBhdHRlcm5zID0gW1xuICAgIC8oPzpefFtcXHM7fV0pKD86aW1wb3J0fGV4cG9ydClcXGJbXjsnXCJdKj9cXHNmcm9tXFxzKltcIiddKFteXCInXSspW1wiJ10vZyxcbiAgICAvKD86XnxbXFxzO31dKWltcG9ydFxccypbXCInXShbXlwiJ10rKVtcIiddL2csXG4gICAgL1xcYmltcG9ydFxcKFxccypbXCInXShbXlwiJ10rKVtcIiddXFxzKlxcKS9nLFxuICAgIC9cXGJyZXF1aXJlXFwoXFxzKltcIiddKFteXCInXSspW1wiJ11cXHMqXFwpL2csXG4gIF07XG4gIGZvciAoY29uc3QgcmUgb2YgcGF0dGVybnMpIHtcbiAgICBmb3IgKGNvbnN0IG0gb2Ygc291cmNlLm1hdGNoQWxsKHJlKSkge1xuICAgICAgY29uc3Qgc3BlYyA9IG1bMV07XG4gICAgICBpZiAoc3BlYy5zdGFydHNXaXRoKCcuJykgfHwgc3BlYy5zdGFydHNXaXRoKCcvJykpIGNvbnRpbnVlO1xuICAgICAgaWYgKEJVSUxUSU4udGVzdChzcGVjKSB8fCBWSVJUVUFMLmhhcyhzcGVjKSB8fCBzcGVjLnN0YXJ0c1dpdGgoJ3ZpcnR1YWw6JykpIGNvbnRpbnVlO1xuICAgICAgaWYgKFNBTkRCT1hfUFJPVklERUQuaGFzKHBhY2thZ2VPZihzcGVjKSkpIGNvbnRpbnVlO1xuICAgICAgb3V0LmFkZChwYWNrYWdlT2Yoc3BlYykpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gb3V0O1xufTtcblxuLyoqIFJ1bnRpbWUgc291cmNlIGZpbGVzIOKAlCB0aGUgYXBwJ3Mgb3duIGNvZGUuIFRlc3RzIGFyZSBleGNsdWRlZDogdGhleSBydW4gdW5kZXJcbiAqICB2aXRlc3QgaW4gbm9kZSwgd2hlcmUgZGV2RGVwZW5kZW5jaWVzIGFyZSBleGFjdGx5IHRoZSByaWdodCBob21lLiAqL1xuY29uc3Qgc291cmNlRmlsZXMgPSAoZGlyLCByZWwgPSAnJykgPT4ge1xuICBjb25zdCBvdXQgPSBbXTtcbiAgZm9yIChjb25zdCBlbnRyeSBvZiByZWFkZGlyU3luYyhkaXIsIHsgd2l0aEZpbGVUeXBlczogdHJ1ZSB9KSkge1xuICAgIGNvbnN0IGNoaWxkUmVsID0gcmVsID8gYCR7cmVsfS8ke2VudHJ5Lm5hbWV9YCA6IGVudHJ5Lm5hbWU7XG4gICAgaWYgKGVudHJ5LmlzRGlyZWN0b3J5KCkpIG91dC5wdXNoKC4uLnNvdXJjZUZpbGVzKGpvaW4oZGlyLCBlbnRyeS5uYW1lKSwgY2hpbGRSZWwpKTtcbiAgICBlbHNlIGlmICgvXFwuKHRzfHRzeHxqc3xqc3gpJC8udGVzdChlbnRyeS5uYW1lKSAmJiAhL1xcLnRlc3RcXC4odHN8dHN4fGpzfGpzeCkkLy50ZXN0KGVudHJ5Lm5hbWUpKSB7XG4gICAgICBvdXQucHVzaChjaGlsZFJlbCk7XG4gICAgfVxuICB9XG4gIHJldHVybiBvdXQ7XG59O1xuXG5leHBvcnQgY29uc3QgZmluZE1pc3NpbmcgPSAocmVhZEZpbGUsIGZpbGVzLCBkZWNsYXJlZCkgPT4ge1xuICBjb25zdCBtaXNzaW5nID0gbmV3IE1hcCgpO1xuICBmb3IgKGNvbnN0IGZpbGUgb2YgZmlsZXMpIHtcbiAgICBmb3IgKGNvbnN0IHBrZyBvZiBpbXBvcnRlZFBhY2thZ2VzKHJlYWRGaWxlKGZpbGUpKSkge1xuICAgICAgaWYgKGRlY2xhcmVkLmhhcyhwa2cpKSBjb250aW51ZTtcbiAgICAgIGlmICghbWlzc2luZy5oYXMocGtnKSkgbWlzc2luZy5zZXQocGtnLCBbXSk7XG4gICAgICBtaXNzaW5nLmdldChwa2cpLnB1c2goZmlsZSk7XG4gICAgfVxuICB9XG4gIHJldHVybiBtaXNzaW5nO1xufTtcblxuY29uc3Qgc2VsZlRlc3QgPSAoKSA9PiB7XG4gIGNvbnN0IGNhc2VzID0gW1xuICAgIHsgbmFtZTogJ2EgcmVsYXRpdmUgaW1wb3J0IG5lZWRzIG5vIGRlY2xhcmF0aW9uJywgc3JjOiAnaW1wb3J0IHsgYSB9IGZyb20gXCIuL3hcIjsnLCBkZWNsYXJlZDogW10sIHdhbnQ6IDAgfSxcbiAgICB7IG5hbWU6ICdhIG5vZGUgYnVpbHRpbiBuZWVkcyBubyBkZWNsYXJhdGlvbicsIHNyYzogJ2ltcG9ydCB7IGpvaW4gfSBmcm9tIFwibm9kZTpwYXRoXCI7JywgZGVjbGFyZWQ6IFtdLCB3YW50OiAwIH0sXG4gICAgeyBuYW1lOiAnYSBkZWNsYXJlZCBwYWNrYWdlIGlzIGZpbmUnLCBzcmM6ICdpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7JywgZGVjbGFyZWQ6IFsncmVhY3QnXSwgd2FudDogMCB9LFxuICAgIHsgbmFtZTogJ1RIRSBSMy0yODAgUkVHUkVTU0lPTjogcmVhY3QgaW1wb3J0ZWQsIG5vdCBkZWNsYXJlZCcsIHNyYzogJ2ltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjsnLCBkZWNsYXJlZDogW10sIHdhbnQ6IDEgfSxcbiAgICB7IG5hbWU6ICdhIFNVQlBBVEggY291bnRzIGFzIGl0cyBwYWNrYWdlJywgc3JjOiAnaW1wb3J0IHsgY3JlYXRlUm9vdCB9IGZyb20gXCJyZWFjdC1kb20vY2xpZW50XCI7JywgZGVjbGFyZWQ6IFsncmVhY3QtZG9tJ10sIHdhbnQ6IDAgfSxcbiAgICB7IG5hbWU6ICfigKZhbmQgaXMgcmVwb3J0ZWQgdW5kZXIgdGhlIHBhY2thZ2UgbmFtZScsIHNyYzogJ2ltcG9ydCB4IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9ib290XCI7JywgZGVjbGFyZWQ6IFtdLCB3YW50OiAxIH0sXG4gICAgeyBuYW1lOiAnYSBzY29wZWQgcGFja2FnZSBrZWVwcyBib3RoIHNlZ21lbnRzJywgc3JjOiAnaW1wb3J0IHggZnJvbSBcIkBzY29wZS9wa2cvZGVlcC9wYXRoXCI7JywgZGVjbGFyZWQ6IFsnQHNjb3BlL3BrZyddLCB3YW50OiAwIH0sXG4gICAgeyBuYW1lOiAnYSBkeW5hbWljIGltcG9ydCBjb3VudHMnLCBzcmM6ICdjb25zdCBtID0gYXdhaXQgaW1wb3J0KFwic29tZS1wa2dcIik7JywgZGVjbGFyZWQ6IFtdLCB3YW50OiAxIH0sXG4gICAgeyBuYW1lOiAnYSByZS1leHBvcnQgY291bnRzJywgc3JjOiAnZXhwb3J0IHsgeCB9IGZyb20gXCJzb21lLXBrZ1wiOycsIGRlY2xhcmVkOiBbXSwgd2FudDogMSB9LFxuICAgIHsgbmFtZTogJ3RoZSBzYW5kYm94LXByZWxvYWRlZCBgZnNgIG5lZWRzIG5vIGRlY2xhcmF0aW9uJywgc3JjOiAnaW1wb3J0IGZzIGZyb20gXCJmc1wiOycsIGRlY2xhcmVkOiBbXSwgd2FudDogMCB9LFxuICAgIHsgbmFtZTogJ+KApmFuZCBzbyBkbyB0aGUgb3RoZXIgcHJlbG9hZGVkIGJ1aWx0aW5zJywgc3JjOiAnaW1wb3J0IHsgam9pbiB9IGZyb20gXCJwYXRoXCI7JywgZGVjbGFyZWQ6IFtdLCB3YW50OiAwIH0sXG4gIF07XG4gIGxldCBmYWlsZWQgPSAwO1xuICBmb3IgKGNvbnN0IGMgb2YgY2FzZXMpIHtcbiAgICBjb25zdCBnb3QgPSBmaW5kTWlzc2luZygoKSA9PiBjLnNyYywgWydmLnRzJ10sIG5ldyBTZXQoYy5kZWNsYXJlZCkpLnNpemU7XG4gICAgY29uc3Qgb2sgPSBnb3QgPT09IGMud2FudDtcbiAgICBpZiAoIW9rKSBmYWlsZWQrKztcbiAgICBjb25zb2xlLmxvZyhgJHtvayA/ICdQQVNTJyA6ICdGQUlMJ30gICR7Yy5uYW1lfSAoZXhwZWN0ZWQgJHtjLndhbnR9LCBnb3QgJHtnb3R9KWApO1xuICB9XG4gIGNvbnNvbGUubG9nKGBcXG4ke2Nhc2VzLmxlbmd0aCAtIGZhaWxlZH0vJHtjYXNlcy5sZW5ndGh9IHNlbGYtdGVzdCBjYXNlcy5gKTtcbiAgcmV0dXJuIGZhaWxlZCA9PT0gMDtcbn07XG5cbmlmIChwcm9jZXNzLmFyZ3YuaW5jbHVkZXMoJy0tc2VsZi10ZXN0JykpIHtcbiAgcHJvY2Vzcy5leGl0KHNlbGZUZXN0KCkgPyAwIDogMSk7XG59XG5cbmNvbnN0IHBrZyA9IEpTT04ucGFyc2UocmVhZEZpbGVTeW5jKGpvaW4oUk9PVCwgJ3BhY2thZ2UuanNvbicpLCAndXRmOCcpKTtcbmNvbnN0IGRlY2xhcmVkID0gbmV3IFNldChPYmplY3Qua2V5cyhwa2cuZGVwZW5kZW5jaWVzID8/IHt9KSk7XG5jb25zdCBmaWxlcyA9IHNvdXJjZUZpbGVzKGpvaW4oUk9PVCwgJ3NyYycpKTtcbmNvbnN0IG1pc3NpbmcgPSBmaW5kTWlzc2luZygoZikgPT4gcmVhZEZpbGVTeW5jKGpvaW4oUk9PVCwgJ3NyYycsIGYpLCAndXRmOCcpLCBmaWxlcywgZGVjbGFyZWQpO1xuXG5pZiAobWlzc2luZy5zaXplID09PSAwKSB7XG4gIGNvbnNvbGUubG9nKFxuICAgIGBPSzogZXZlcnkgcGFja2FnZSBzcmMvIGltcG9ydHMgaXMgaW4gXCJkZXBlbmRlbmNpZXNcIiAoJHtmaWxlcy5sZW5ndGh9IGZpbGUocyksICR7ZGVjbGFyZWQuc2l6ZX0gZGVjbGFyZWQpLmAsXG4gICk7XG4gIHByb2Nlc3MuZXhpdCgwKTtcbn1cbmNvbnNvbGUuZXJyb3IoXG4gIGA6OmVycm9yOjoke21pc3Npbmcuc2l6ZX0gcGFja2FnZShzKSBpbXBvcnRlZCBieSBzcmMvIGJ1dCBhYnNlbnQgZnJvbSBcImRlcGVuZGVuY2llc1wiLlxcbmAgK1xuICAgICdUaGUgc2FuZGJveCByZXNvbHZlcyBhbiBhcHBcXCdzIG1vZHVsZXMgZnJvbSBgZGVwZW5kZW5jaWVzYCBhbG9uZSDigJQgYSBwZWVyIG9yIGFcXG4nICtcbiAgICAnZGV2RGVwZW5kZW5jeSBpcyBOT1QgZmV0Y2hlZCwgYW5kIHRoZSBhcHAgZGllcyBhdCBib290IG5hbWluZyBzb21lIG90aGVyIHBhY2thZ2VcXG4nICtcbiAgICAndGhhdCBuZWVkZWQgaXQuIERlY2xhcmUgdGhlbSBpbiBgZGVwZW5kZW5jaWVzYDsga2VlcCB0aGUgcGVlciBlbnRyeSB0b28gaWYgdGhlXFxuJyArXG4gICAgJ2xpYnJhcnkgcm9sZSBuZWVkcyBpdCAoYm90aCBpcyBsZWdhbCwgYW5kIHdoYXQgYGZpbGUtZXhwbG9yZXJgIGRvZXMpLlxcbicsXG4pO1xuZm9yIChjb25zdCBbcGtnTmFtZSwgZmlsZXNfXSBvZiBtaXNzaW5nKSB7XG4gIGNvbnN0IHdoZXJlID0gcGtnLnBlZXJEZXBlbmRlbmNpZXM/Lltwa2dOYW1lXVxuICAgID8gJyAoZGVjbGFyZWQgYXMgYSBQRUVSIG9ubHkpJ1xuICAgIDogcGtnLmRldkRlcGVuZGVuY2llcz8uW3BrZ05hbWVdXG4gICAgICA/ICcgKGRlY2xhcmVkIGFzIGEgZGV2RGVwZW5kZW5jeSBvbmx5KSdcbiAgICAgIDogJyc7XG4gIGNvbnNvbGUuZXJyb3IoYCAgJHtwa2dOYW1lfSR7d2hlcmV9XFxuICAgICR7ZmlsZXNfLnNsaWNlKDAsIDQpLmpvaW4oJ1xcbiAgICAnKX1gKTtcbn1cbnByb2Nlc3MuZXhpdCgxKTtcbiJdLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBNUJBOztBQUFBQSxNQUFBLENBQUFDLGNBQUEsQ0FBQUMsT0FBQTtFQUFBQyxLQUFBO0FBQUE7QUFBQUQsT0FBQSxDQUFBRSxTQUFBLEdBQUFGLE9BQUEsQ0FBQUcsZ0JBQUEsR0FBQUgsT0FBQSxDQUFBSSxXQUFBO0FBNkJBLElBQUFDLE9BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLFNBQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLFFBQUEsR0FBQUYsT0FBQTtBQUVBLE1BQU1HLElBQUksR0FBRyxJQUFBQyxjQUFJLEVBQUMsSUFBQUMsaUJBQU8sRUFBQyxJQUFBQyxzQkFBYSxFQUFDQyxlQUFBLENBQVlDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDOztBQUVoRTtBQUNBLE1BQU1DLE9BQU8sR0FBRyxlQUFlO0FBQy9CO0FBQ0EsTUFBTUMsT0FBTyxHQUFHLElBQUlDLEdBQUcsQ0FBQyxDQUFDLFVBQVUsRUFBRSxhQUFhLENBQUMsQ0FBQztBQUNwRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTUMsZ0JBQWdCLEdBQUcsSUFBSUQsR0FBRyxDQUFDLENBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBRSxJQUFJLENBQUMsQ0FBQzs7QUFFbEY7QUFDQTtBQUNPLE1BQU1mLFNBQVMsR0FBSWlCLElBQUksSUFBSztFQUNqQyxNQUFNQyxLQUFLLEdBQUdELElBQUksQ0FBQ0UsS0FBSyxDQUFDLEdBQUcsQ0FBQztFQUM3QixPQUFPRixJQUFJLENBQUNHLFVBQVUsQ0FBQyxHQUFHLENBQUMsR0FBR0YsS0FBSyxDQUFDRyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDYixJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUdVLEtBQUssQ0FBQyxDQUFDLENBQUM7QUFDdEUsQ0FBQzs7QUFFRDtBQUFBcEIsT0FBQSxDQUFBRSxTQUFBLEdBQUFBLFNBQUE7QUFDTyxNQUFNQyxnQkFBZ0IsR0FBSXFCLE1BQU0sSUFBSztFQUMxQyxNQUFNQyxHQUFHLEdBQUcsSUFBSVIsR0FBRyxDQUFDLENBQUM7RUFDckIsTUFBTVMsUUFBUSxHQUFHLENBQ2YsbUVBQW1FLEVBQ25FLHdDQUF3QyxFQUN4QyxxQ0FBcUMsRUFDckMsc0NBQXNDLENBQ3ZDO0VBQ0QsS0FBSyxNQUFNQyxFQUFFLElBQUlELFFBQVEsRUFBRTtJQUN6QixLQUFLLE1BQU1FLENBQUMsSUFBSUosTUFBTSxDQUFDSyxRQUFRLENBQUNGLEVBQUUsQ0FBQyxFQUFFO01BQ25DLE1BQU1SLElBQUksR0FBR1MsQ0FBQyxDQUFDLENBQUMsQ0FBQztNQUNqQixJQUFJVCxJQUFJLENBQUNHLFVBQVUsQ0FBQyxHQUFHLENBQUMsSUFBSUgsSUFBSSxDQUFDRyxVQUFVLENBQUMsR0FBRyxDQUFDLEVBQUU7TUFDbEQsSUFBSVAsT0FBTyxDQUFDZSxJQUFJLENBQUNYLElBQUksQ0FBQyxJQUFJSCxPQUFPLENBQUNlLEdBQUcsQ0FBQ1osSUFBSSxDQUFDLElBQUlBLElBQUksQ0FBQ0csVUFBVSxDQUFDLFVBQVUsQ0FBQyxFQUFFO01BQzVFLElBQUlKLGdCQUFnQixDQUFDYSxHQUFHLENBQUM3QixTQUFTLENBQUNpQixJQUFJLENBQUMsQ0FBQyxFQUFFO01BQzNDTSxHQUFHLENBQUNPLEdBQUcsQ0FBQzlCLFNBQVMsQ0FBQ2lCLElBQUksQ0FBQyxDQUFDO0lBQzFCO0VBQ0Y7RUFDQSxPQUFPTSxHQUFHO0FBQ1osQ0FBQzs7QUFFRDtBQUNBO0FBREF6QixPQUFBLENBQUFHLGdCQUFBLEdBQUFBLGdCQUFBO0FBRUEsTUFBTThCLFdBQVcsR0FBR0EsQ0FBQ0MsR0FBRyxFQUFFQyxHQUFHLEdBQUcsRUFBRSxLQUFLO0VBQ3JDLE1BQU1WLEdBQUcsR0FBRyxFQUFFO0VBQ2QsS0FBSyxNQUFNVyxLQUFLLElBQUksSUFBQUMsbUJBQVcsRUFBQ0gsR0FBRyxFQUFFO0lBQUVJLGFBQWEsRUFBRTtFQUFLLENBQUMsQ0FBQyxFQUFFO0lBQzdELE1BQU1DLFFBQVEsR0FBR0osR0FBRyxHQUFHLEdBQUdBLEdBQUcsSUFBSUMsS0FBSyxDQUFDSSxJQUFJLEVBQUUsR0FBR0osS0FBSyxDQUFDSSxJQUFJO0lBQzFELElBQUlKLEtBQUssQ0FBQ0ssV0FBVyxDQUFDLENBQUMsRUFBRWhCLEdBQUcsQ0FBQ2lCLElBQUksQ0FBQyxHQUFHVCxXQUFXLENBQUMsSUFBQXZCLGNBQUksRUFBQ3dCLEdBQUcsRUFBRUUsS0FBSyxDQUFDSSxJQUFJLENBQUMsRUFBRUQsUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUM5RSxJQUFJLG9CQUFvQixDQUFDVCxJQUFJLENBQUNNLEtBQUssQ0FBQ0ksSUFBSSxDQUFDLElBQUksQ0FBQywwQkFBMEIsQ0FBQ1YsSUFBSSxDQUFDTSxLQUFLLENBQUNJLElBQUksQ0FBQyxFQUFFO01BQzlGZixHQUFHLENBQUNpQixJQUFJLENBQUNILFFBQVEsQ0FBQztJQUNwQjtFQUNGO0VBQ0EsT0FBT2QsR0FBRztBQUNaLENBQUM7QUFFTSxNQUFNckIsV0FBVyxHQUFHQSxDQUFDdUMsUUFBUSxFQUFFQyxLQUFLLEVBQUVDLFFBQVEsS0FBSztFQUN4RCxNQUFNQyxPQUFPLEdBQUcsSUFBSUMsR0FBRyxDQUFDLENBQUM7RUFDekIsS0FBSyxNQUFNQyxJQUFJLElBQUlKLEtBQUssRUFBRTtJQUN4QixLQUFLLE1BQU1LLEdBQUcsSUFBSTlDLGdCQUFnQixDQUFDd0MsUUFBUSxDQUFDSyxJQUFJLENBQUMsQ0FBQyxFQUFFO01BQ2xELElBQUlILFFBQVEsQ0FBQ2QsR0FBRyxDQUFDa0IsR0FBRyxDQUFDLEVBQUU7TUFDdkIsSUFBSSxDQUFDSCxPQUFPLENBQUNmLEdBQUcsQ0FBQ2tCLEdBQUcsQ0FBQyxFQUFFSCxPQUFPLENBQUNJLEdBQUcsQ0FBQ0QsR0FBRyxFQUFFLEVBQUUsQ0FBQztNQUMzQ0gsT0FBTyxDQUFDSyxHQUFHLENBQUNGLEdBQUcsQ0FBQyxDQUFDUCxJQUFJLENBQUNNLElBQUksQ0FBQztJQUM3QjtFQUNGO0VBQ0EsT0FBT0YsT0FBTztBQUNoQixDQUFDO0FBQUM5QyxPQUFBLENBQUFJLFdBQUEsR0FBQUEsV0FBQTtBQUVGLE1BQU1nRCxRQUFRLEdBQUdBLENBQUEsS0FBTTtFQUNyQixNQUFNQyxLQUFLLEdBQUcsQ0FDWjtJQUFFYixJQUFJLEVBQUUsd0NBQXdDO0lBQUVjLEdBQUcsRUFBRSwwQkFBMEI7SUFBRVQsUUFBUSxFQUFFLEVBQUU7SUFBRVUsSUFBSSxFQUFFO0VBQUUsQ0FBQyxFQUMxRztJQUFFZixJQUFJLEVBQUUscUNBQXFDO0lBQUVjLEdBQUcsRUFBRSxtQ0FBbUM7SUFBRVQsUUFBUSxFQUFFLEVBQUU7SUFBRVUsSUFBSSxFQUFFO0VBQUUsQ0FBQyxFQUNoSDtJQUFFZixJQUFJLEVBQUUsNEJBQTRCO0lBQUVjLEdBQUcsRUFBRSw0QkFBNEI7SUFBRVQsUUFBUSxFQUFFLENBQUMsT0FBTyxDQUFDO0lBQUVVLElBQUksRUFBRTtFQUFFLENBQUMsRUFDdkc7SUFBRWYsSUFBSSxFQUFFLHFEQUFxRDtJQUFFYyxHQUFHLEVBQUUsNEJBQTRCO0lBQUVULFFBQVEsRUFBRSxFQUFFO0lBQUVVLElBQUksRUFBRTtFQUFFLENBQUMsRUFDekg7SUFBRWYsSUFBSSxFQUFFLGlDQUFpQztJQUFFYyxHQUFHLEVBQUUsZ0RBQWdEO0lBQUVULFFBQVEsRUFBRSxDQUFDLFdBQVcsQ0FBQztJQUFFVSxJQUFJLEVBQUU7RUFBRSxDQUFDLEVBQ3BJO0lBQUVmLElBQUksRUFBRSx5Q0FBeUM7SUFBRWMsR0FBRyxFQUFFLDRDQUE0QztJQUFFVCxRQUFRLEVBQUUsRUFBRTtJQUFFVSxJQUFJLEVBQUU7RUFBRSxDQUFDLEVBQzdIO0lBQUVmLElBQUksRUFBRSxzQ0FBc0M7SUFBRWMsR0FBRyxFQUFFLHVDQUF1QztJQUFFVCxRQUFRLEVBQUUsQ0FBQyxZQUFZLENBQUM7SUFBRVUsSUFBSSxFQUFFO0VBQUUsQ0FBQyxFQUNqSTtJQUFFZixJQUFJLEVBQUUseUJBQXlCO0lBQUVjLEdBQUcsRUFBRSxxQ0FBcUM7SUFBRVQsUUFBUSxFQUFFLEVBQUU7SUFBRVUsSUFBSSxFQUFFO0VBQUUsQ0FBQyxFQUN0RztJQUFFZixJQUFJLEVBQUUsb0JBQW9CO0lBQUVjLEdBQUcsRUFBRSwrQkFBK0I7SUFBRVQsUUFBUSxFQUFFLEVBQUU7SUFBRVUsSUFBSSxFQUFFO0VBQUUsQ0FBQyxFQUMzRjtJQUFFZixJQUFJLEVBQUUsaURBQWlEO0lBQUVjLEdBQUcsRUFBRSxzQkFBc0I7SUFBRVQsUUFBUSxFQUFFLEVBQUU7SUFBRVUsSUFBSSxFQUFFO0VBQUUsQ0FBQyxFQUMvRztJQUFFZixJQUFJLEVBQUUseUNBQXlDO0lBQUVjLEdBQUcsRUFBRSw4QkFBOEI7SUFBRVQsUUFBUSxFQUFFLEVBQUU7SUFBRVUsSUFBSSxFQUFFO0VBQUUsQ0FBQyxDQUNoSDtFQUNELElBQUlDLE1BQU0sR0FBRyxDQUFDO0VBQ2QsS0FBSyxNQUFNQyxDQUFDLElBQUlKLEtBQUssRUFBRTtJQUNyQixNQUFNSyxHQUFHLEdBQUd0RCxXQUFXLENBQUMsTUFBTXFELENBQUMsQ0FBQ0gsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLEVBQUUsSUFBSXJDLEdBQUcsQ0FBQ3dDLENBQUMsQ0FBQ1osUUFBUSxDQUFDLENBQUMsQ0FBQ2MsSUFBSTtJQUN4RSxNQUFNQyxFQUFFLEdBQUdGLEdBQUcsS0FBS0QsQ0FBQyxDQUFDRixJQUFJO0lBQ3pCLElBQUksQ0FBQ0ssRUFBRSxFQUFFSixNQUFNLEVBQUU7SUFDakJLLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDLEdBQUdGLEVBQUUsR0FBRyxNQUFNLEdBQUcsTUFBTSxLQUFLSCxDQUFDLENBQUNqQixJQUFJLGNBQWNpQixDQUFDLENBQUNGLElBQUksU0FBU0csR0FBRyxHQUFHLENBQUM7RUFDcEY7RUFDQUcsT0FBTyxDQUFDQyxHQUFHLENBQUMsS0FBS1QsS0FBSyxDQUFDVSxNQUFNLEdBQUdQLE1BQU0sSUFBSUgsS0FBSyxDQUFDVSxNQUFNLG1CQUFtQixDQUFDO0VBQzFFLE9BQU9QLE1BQU0sS0FBSyxDQUFDO0FBQ3JCLENBQUM7QUFFRCxJQUFJUSxPQUFPLENBQUNDLElBQUksQ0FBQ0MsUUFBUSxDQUFDLGFBQWEsQ0FBQyxFQUFFO0VBQ3hDRixPQUFPLENBQUNHLElBQUksQ0FBQ2YsUUFBUSxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ2xDO0FBRUEsTUFBTUgsR0FBRyxHQUFHbUIsSUFBSSxDQUFDQyxLQUFLLENBQUMsSUFBQUMsb0JBQVksRUFBQyxJQUFBNUQsY0FBSSxFQUFDRCxJQUFJLEVBQUUsY0FBYyxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUM7QUFDeEUsTUFBTW9DLFFBQVEsR0FBRyxJQUFJNUIsR0FBRyxDQUFDbkIsTUFBTSxDQUFDeUUsSUFBSSxDQUFDdEIsR0FBRyxDQUFDdUIsWUFBWSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0QsTUFBTTVCLEtBQUssR0FBR1gsV0FBVyxDQUFDLElBQUF2QixjQUFJLEVBQUNELElBQUksRUFBRSxLQUFLLENBQUMsQ0FBQztBQUM1QyxNQUFNcUMsT0FBTyxHQUFHMUMsV0FBVyxDQUFFcUUsQ0FBQyxJQUFLLElBQUFILG9CQUFZLEVBQUMsSUFBQTVELGNBQUksRUFBQ0QsSUFBSSxFQUFFLEtBQUssRUFBRWdFLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxFQUFFN0IsS0FBSyxFQUFFQyxRQUFRLENBQUM7QUFFL0YsSUFBSUMsT0FBTyxDQUFDYSxJQUFJLEtBQUssQ0FBQyxFQUFFO0VBQ3RCRSxPQUFPLENBQUNDLEdBQUcsQ0FDVCx3REFBd0RsQixLQUFLLENBQUNtQixNQUFNLGFBQWFsQixRQUFRLENBQUNjLElBQUksYUFDaEcsQ0FBQztFQUNESyxPQUFPLENBQUNHLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDakI7QUFDQU4sT0FBTyxDQUFDYSxLQUFLLENBQ1gsWUFBWTVCLE9BQU8sQ0FBQ2EsSUFBSSxnRUFBZ0UsR0FDdEYsa0ZBQWtGLEdBQ2xGLG9GQUFvRixHQUNwRixrRkFBa0YsR0FDbEYseUVBQ0osQ0FBQztBQUNELEtBQUssTUFBTSxDQUFDZ0IsT0FBTyxFQUFFQyxNQUFNLENBQUMsSUFBSTlCLE9BQU8sRUFBRTtFQUN2QyxNQUFNK0IsS0FBSyxHQUFHNUIsR0FBRyxDQUFDNkIsZ0JBQWdCLEdBQUdILE9BQU8sQ0FBQyxHQUN6Qyw0QkFBNEIsR0FDNUIxQixHQUFHLENBQUM4QixlQUFlLEdBQUdKLE9BQU8sQ0FBQyxHQUM1QixxQ0FBcUMsR0FDckMsRUFBRTtFQUNSZCxPQUFPLENBQUNhLEtBQUssQ0FBQyxLQUFLQyxPQUFPLEdBQUdFLEtBQUssU0FBU0QsTUFBTSxDQUFDckQsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQ2IsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUM7QUFDakY7QUFDQXNELE9BQU8sQ0FBQ0csSUFBSSxDQUFDLENBQUMsQ0FBQyIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}