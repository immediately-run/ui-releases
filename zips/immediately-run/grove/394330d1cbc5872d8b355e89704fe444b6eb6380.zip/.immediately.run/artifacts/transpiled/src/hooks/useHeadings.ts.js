"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useActiveHeading = useActiveHeading;
exports.useHeadings = useHeadings;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.every.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.for-each.js");
require("core-js/modules/esnext.iterator.map.js");
var _react = require("react");
var _wiki = require("../lib/wiki");
// The rendered entry's headings, and which one the reader is in.
//
// Extracted from `<Toc>` when `<TableOfContents>` arrived, so the two surfaces cannot
// disagree about what a heading is — the drift ENGINE_BOUNDARY §4 exists to prevent. The
// scan reads the DOM rather than the source because an entry is rendered through
// `<Include>` (compiled MDX) or the safe renderer; neither hands back a heading list, and
// the ids a citation lands on are the ones actually in the document.

/** Heading text WITHOUT the kernel's autolink anchor. The SDK's HeadingAnchor (§15.4)
 *  prepends `<a class="ir-heading-anchor">#</a>` as the first child, so `textContent`
 *  alone would put a stray `#` in every label and in the id fallback. */
function headingText(node) {
  const anchor = node.querySelector('.ir-heading-anchor');
  if (!anchor) return (node.textContent || '').trim();
  return Array.from(node.childNodes).filter(c => c !== anchor).map(c => c.textContent ?? '').join('').trim();
}

/**
 * Scan `.grove-prose` for `h2`/`h3`, assigning the canonical id to any heading the kernel
 * did not emit one for, and re-scan as the prose mounts or swaps on navigation.
 */
function useHeadings(entryKey) {
  const [heads, setHeads] = (0, _react.useState)([]);
  (0, _react.useEffect)(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setHeads([]);
    const scan = () => {
      const prose = document.querySelector('.grove-prose');
      const nodes = prose ? Array.from(prose.querySelectorAll('h2, h3')) : [];
      const found = nodes.map(n => {
        const text = headingText(n);
        // Prefer the kernel-emitted id (§15.5); `headingId` reproduces the same canon
        // (`@immediately-run/mdx-plugins`) for a heading that has none.
        const id = n.id || (0, _wiki.headingId)(text);
        n.id = id;
        return {
          id,
          text,
          level: n.tagName === 'H3' ? 3 : 2
        };
      });
      // Identity-stable when nothing changed: this runs from a MutationObserver, and a
      // fresh array every mutation would re-run every downstream effect (the spy, the
      // scroll) on each keystroke of an editor-driven re-render.
      setHeads(prev => prev.length === found.length && prev.every((h, i) => h.id === found[i].id) ? prev : found);
    };
    scan();
    const prose = document.querySelector('.grove-prose');
    const obs = prose ? new MutationObserver(scan) : null;
    if (prose && obs) obs.observe(prose, {
      childList: true,
      subtree: true
    });
    // `<Include>` resolves asynchronously, and the observer only fires if `.grove-prose`
    // already existed — these catch the window where it did not.
    const timers = [120, 300, 600].map(d => setTimeout(scan, d));
    return () => {
      obs?.disconnect();
      timers.forEach(clearTimeout);
    };
  }, [entryKey]);
  return heads;
}

/** Which heading the reader is currently in — scroll-spied off the document. */
function useActiveHeading(heads) {
  const [cur, setCur] = (0, _react.useState)('');
  (0, _react.useEffect)(() => {
    if (!heads.length) return;
    const obs = new IntersectionObserver(entries => {
      const visible = entries.filter(e => e.isIntersecting);
      if (visible.length) setCur(visible[0].target.id);
    }, {
      rootMargin: '-64px 0px -70% 0px',
      threshold: 0
    });
    heads.forEach(h => {
      const el = document.getElementById(h.id);
      if (el) obs.observe(el);
    });
    return () => obs.disconnect();
  }, [heads]);
  return cur;
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3dpa2kiLCJoZWFkaW5nVGV4dCIsIm5vZGUiLCJhbmNob3IiLCJxdWVyeVNlbGVjdG9yIiwidGV4dENvbnRlbnQiLCJ0cmltIiwiQXJyYXkiLCJmcm9tIiwiY2hpbGROb2RlcyIsImZpbHRlciIsImMiLCJtYXAiLCJqb2luIiwidXNlSGVhZGluZ3MiLCJlbnRyeUtleSIsImhlYWRzIiwic2V0SGVhZHMiLCJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsInNjYW4iLCJwcm9zZSIsImRvY3VtZW50Iiwibm9kZXMiLCJxdWVyeVNlbGVjdG9yQWxsIiwiZm91bmQiLCJuIiwidGV4dCIsImlkIiwiaGVhZGluZ0lkIiwibGV2ZWwiLCJ0YWdOYW1lIiwicHJldiIsImxlbmd0aCIsImV2ZXJ5IiwiaCIsImkiLCJvYnMiLCJNdXRhdGlvbk9ic2VydmVyIiwib2JzZXJ2ZSIsImNoaWxkTGlzdCIsInN1YnRyZWUiLCJ0aW1lcnMiLCJkIiwic2V0VGltZW91dCIsImRpc2Nvbm5lY3QiLCJmb3JFYWNoIiwiY2xlYXJUaW1lb3V0IiwidXNlQWN0aXZlSGVhZGluZyIsImN1ciIsInNldEN1ciIsIkludGVyc2VjdGlvbk9ic2VydmVyIiwiZW50cmllcyIsInZpc2libGUiLCJlIiwiaXNJbnRlcnNlY3RpbmciLCJ0YXJnZXQiLCJyb290TWFyZ2luIiwidGhyZXNob2xkIiwiZWwiLCJnZXRFbGVtZW50QnlJZCJdLCJzb3VyY2VzIjpbInVzZUhlYWRpbmdzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIFRoZSByZW5kZXJlZCBlbnRyeSdzIGhlYWRpbmdzLCBhbmQgd2hpY2ggb25lIHRoZSByZWFkZXIgaXMgaW4uXG4vL1xuLy8gRXh0cmFjdGVkIGZyb20gYDxUb2M+YCB3aGVuIGA8VGFibGVPZkNvbnRlbnRzPmAgYXJyaXZlZCwgc28gdGhlIHR3byBzdXJmYWNlcyBjYW5ub3Rcbi8vIGRpc2FncmVlIGFib3V0IHdoYXQgYSBoZWFkaW5nIGlzIOKAlCB0aGUgZHJpZnQgRU5HSU5FX0JPVU5EQVJZIMKnNCBleGlzdHMgdG8gcHJldmVudC4gVGhlXG4vLyBzY2FuIHJlYWRzIHRoZSBET00gcmF0aGVyIHRoYW4gdGhlIHNvdXJjZSBiZWNhdXNlIGFuIGVudHJ5IGlzIHJlbmRlcmVkIHRocm91Z2hcbi8vIGA8SW5jbHVkZT5gIChjb21waWxlZCBNRFgpIG9yIHRoZSBzYWZlIHJlbmRlcmVyOyBuZWl0aGVyIGhhbmRzIGJhY2sgYSBoZWFkaW5nIGxpc3QsIGFuZFxuLy8gdGhlIGlkcyBhIGNpdGF0aW9uIGxhbmRzIG9uIGFyZSB0aGUgb25lcyBhY3R1YWxseSBpbiB0aGUgZG9jdW1lbnQuXG5cbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBoZWFkaW5nSWQgfSBmcm9tICcuLi9saWIvd2lraSc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgSGVhZGluZyB7XG4gIGlkOiBzdHJpbmc7XG4gIHRleHQ6IHN0cmluZztcbiAgbGV2ZWw6IG51bWJlcjtcbn1cblxuLyoqIEhlYWRpbmcgdGV4dCBXSVRIT1VUIHRoZSBrZXJuZWwncyBhdXRvbGluayBhbmNob3IuIFRoZSBTREsncyBIZWFkaW5nQW5jaG9yICjCpzE1LjQpXG4gKiAgcHJlcGVuZHMgYDxhIGNsYXNzPVwiaXItaGVhZGluZy1hbmNob3JcIj4jPC9hPmAgYXMgdGhlIGZpcnN0IGNoaWxkLCBzbyBgdGV4dENvbnRlbnRgXG4gKiAgYWxvbmUgd291bGQgcHV0IGEgc3RyYXkgYCNgIGluIGV2ZXJ5IGxhYmVsIGFuZCBpbiB0aGUgaWQgZmFsbGJhY2suICovXG5mdW5jdGlvbiBoZWFkaW5nVGV4dChub2RlOiBFbGVtZW50KTogc3RyaW5nIHtcbiAgY29uc3QgYW5jaG9yID0gbm9kZS5xdWVyeVNlbGVjdG9yKCcuaXItaGVhZGluZy1hbmNob3InKTtcbiAgaWYgKCFhbmNob3IpIHJldHVybiAobm9kZS50ZXh0Q29udGVudCB8fCAnJykudHJpbSgpO1xuICByZXR1cm4gQXJyYXkuZnJvbShub2RlLmNoaWxkTm9kZXMpXG4gICAgLmZpbHRlcigoYykgPT4gYyAhPT0gYW5jaG9yKVxuICAgIC5tYXAoKGMpID0+IGMudGV4dENvbnRlbnQgPz8gJycpXG4gICAgLmpvaW4oJycpXG4gICAgLnRyaW0oKTtcbn1cblxuLyoqXG4gKiBTY2FuIGAuZ3JvdmUtcHJvc2VgIGZvciBgaDJgL2BoM2AsIGFzc2lnbmluZyB0aGUgY2Fub25pY2FsIGlkIHRvIGFueSBoZWFkaW5nIHRoZSBrZXJuZWxcbiAqIGRpZCBub3QgZW1pdCBvbmUgZm9yLCBhbmQgcmUtc2NhbiBhcyB0aGUgcHJvc2UgbW91bnRzIG9yIHN3YXBzIG9uIG5hdmlnYXRpb24uXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VIZWFkaW5ncyhlbnRyeUtleT86IHN0cmluZyk6IEhlYWRpbmdbXSB7XG4gIGNvbnN0IFtoZWFkcywgc2V0SGVhZHNdID0gdXNlU3RhdGU8SGVhZGluZ1tdPihbXSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgcmVhY3QtaG9va3Mvc2V0LXN0YXRlLWluLWVmZmVjdFxuICAgIHNldEhlYWRzKFtdKTtcbiAgICBjb25zdCBzY2FuID0gKCkgPT4ge1xuICAgICAgY29uc3QgcHJvc2UgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcuZ3JvdmUtcHJvc2UnKTtcbiAgICAgIGNvbnN0IG5vZGVzID0gcHJvc2UgPyBBcnJheS5mcm9tKHByb3NlLnF1ZXJ5U2VsZWN0b3JBbGwoJ2gyLCBoMycpKSA6IFtdO1xuICAgICAgY29uc3QgZm91bmQ6IEhlYWRpbmdbXSA9IG5vZGVzLm1hcCgobikgPT4ge1xuICAgICAgICBjb25zdCB0ZXh0ID0gaGVhZGluZ1RleHQobik7XG4gICAgICAgIC8vIFByZWZlciB0aGUga2VybmVsLWVtaXR0ZWQgaWQgKMKnMTUuNSk7IGBoZWFkaW5nSWRgIHJlcHJvZHVjZXMgdGhlIHNhbWUgY2Fub25cbiAgICAgICAgLy8gKGBAaW1tZWRpYXRlbHktcnVuL21keC1wbHVnaW5zYCkgZm9yIGEgaGVhZGluZyB0aGF0IGhhcyBub25lLlxuICAgICAgICBjb25zdCBpZCA9IG4uaWQgfHwgaGVhZGluZ0lkKHRleHQpO1xuICAgICAgICBuLmlkID0gaWQ7XG4gICAgICAgIHJldHVybiB7IGlkLCB0ZXh0LCBsZXZlbDogbi50YWdOYW1lID09PSAnSDMnID8gMyA6IDIgfTtcbiAgICAgIH0pO1xuICAgICAgLy8gSWRlbnRpdHktc3RhYmxlIHdoZW4gbm90aGluZyBjaGFuZ2VkOiB0aGlzIHJ1bnMgZnJvbSBhIE11dGF0aW9uT2JzZXJ2ZXIsIGFuZCBhXG4gICAgICAvLyBmcmVzaCBhcnJheSBldmVyeSBtdXRhdGlvbiB3b3VsZCByZS1ydW4gZXZlcnkgZG93bnN0cmVhbSBlZmZlY3QgKHRoZSBzcHksIHRoZVxuICAgICAgLy8gc2Nyb2xsKSBvbiBlYWNoIGtleXN0cm9rZSBvZiBhbiBlZGl0b3ItZHJpdmVuIHJlLXJlbmRlci5cbiAgICAgIHNldEhlYWRzKChwcmV2KSA9PlxuICAgICAgICBwcmV2Lmxlbmd0aCA9PT0gZm91bmQubGVuZ3RoICYmIHByZXYuZXZlcnkoKGgsIGkpID0+IGguaWQgPT09IGZvdW5kW2ldLmlkKSA/IHByZXYgOiBmb3VuZFxuICAgICAgKTtcbiAgICB9O1xuICAgIHNjYW4oKTtcbiAgICBjb25zdCBwcm9zZSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJy5ncm92ZS1wcm9zZScpO1xuICAgIGNvbnN0IG9icyA9IHByb3NlID8gbmV3IE11dGF0aW9uT2JzZXJ2ZXIoc2NhbikgOiBudWxsO1xuICAgIGlmIChwcm9zZSAmJiBvYnMpIG9icy5vYnNlcnZlKHByb3NlLCB7IGNoaWxkTGlzdDogdHJ1ZSwgc3VidHJlZTogdHJ1ZSB9KTtcbiAgICAvLyBgPEluY2x1ZGU+YCByZXNvbHZlcyBhc3luY2hyb25vdXNseSwgYW5kIHRoZSBvYnNlcnZlciBvbmx5IGZpcmVzIGlmIGAuZ3JvdmUtcHJvc2VgXG4gICAgLy8gYWxyZWFkeSBleGlzdGVkIOKAlCB0aGVzZSBjYXRjaCB0aGUgd2luZG93IHdoZXJlIGl0IGRpZCBub3QuXG4gICAgY29uc3QgdGltZXJzID0gWzEyMCwgMzAwLCA2MDBdLm1hcCgoZCkgPT4gc2V0VGltZW91dChzY2FuLCBkKSk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIG9icz8uZGlzY29ubmVjdCgpO1xuICAgICAgdGltZXJzLmZvckVhY2goY2xlYXJUaW1lb3V0KTtcbiAgICB9O1xuICB9LCBbZW50cnlLZXldKTtcblxuICByZXR1cm4gaGVhZHM7XG59XG5cbi8qKiBXaGljaCBoZWFkaW5nIHRoZSByZWFkZXIgaXMgY3VycmVudGx5IGluIOKAlCBzY3JvbGwtc3BpZWQgb2ZmIHRoZSBkb2N1bWVudC4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VBY3RpdmVIZWFkaW5nKGhlYWRzOiBIZWFkaW5nW10pOiBzdHJpbmcge1xuICBjb25zdCBbY3VyLCBzZXRDdXJdID0gdXNlU3RhdGU8c3RyaW5nPignJyk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIWhlYWRzLmxlbmd0aCkgcmV0dXJuO1xuICAgIGNvbnN0IG9icyA9IG5ldyBJbnRlcnNlY3Rpb25PYnNlcnZlcihcbiAgICAgIChlbnRyaWVzKSA9PiB7XG4gICAgICAgIGNvbnN0IHZpc2libGUgPSBlbnRyaWVzLmZpbHRlcigoZSkgPT4gZS5pc0ludGVyc2VjdGluZyk7XG4gICAgICAgIGlmICh2aXNpYmxlLmxlbmd0aCkgc2V0Q3VyKCh2aXNpYmxlWzBdLnRhcmdldCBhcyBIVE1MRWxlbWVudCkuaWQpO1xuICAgICAgfSxcbiAgICAgIHsgcm9vdE1hcmdpbjogJy02NHB4IDBweCAtNzAlIDBweCcsIHRocmVzaG9sZDogMCB9XG4gICAgKTtcbiAgICBoZWFkcy5mb3JFYWNoKChoKSA9PiB7XG4gICAgICBjb25zdCBlbCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGguaWQpO1xuICAgICAgaWYgKGVsKSBvYnMub2JzZXJ2ZShlbCk7XG4gICAgfSk7XG4gICAgcmV0dXJuICgpID0+IG9icy5kaXNjb25uZWN0KCk7XG4gIH0sIFtoZWFkc10pO1xuXG4gIHJldHVybiBjdXI7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7OztBQVFBLElBQUFBLE1BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLEtBQUEsR0FBQUQsT0FBQTtBQVRBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQVdBO0FBQ0E7QUFDQTtBQUNBLFNBQVNFLFdBQVdBLENBQUNDLElBQWEsRUFBVTtFQUMxQyxNQUFNQyxNQUFNLEdBQUdELElBQUksQ0FBQ0UsYUFBYSxDQUFDLG9CQUFvQixDQUFDO0VBQ3ZELElBQUksQ0FBQ0QsTUFBTSxFQUFFLE9BQU8sQ0FBQ0QsSUFBSSxDQUFDRyxXQUFXLElBQUksRUFBRSxFQUFFQyxJQUFJLENBQUMsQ0FBQztFQUNuRCxPQUFPQyxLQUFLLENBQUNDLElBQUksQ0FBQ04sSUFBSSxDQUFDTyxVQUFVLENBQUMsQ0FDL0JDLE1BQU0sQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLEtBQUtSLE1BQU0sQ0FBQyxDQUMzQlMsR0FBRyxDQUFFRCxDQUFDLElBQUtBLENBQUMsQ0FBQ04sV0FBVyxJQUFJLEVBQUUsQ0FBQyxDQUMvQlEsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUNSUCxJQUFJLENBQUMsQ0FBQztBQUNYOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBU1EsV0FBV0EsQ0FBQ0MsUUFBaUIsRUFBYTtFQUN4RCxNQUFNLENBQUNDLEtBQUssRUFBRUMsUUFBUSxDQUFDLEdBQUcsSUFBQUMsZUFBUSxFQUFZLEVBQUUsQ0FBQztFQUVqRCxJQUFBQyxnQkFBUyxFQUFDLE1BQU07SUFDZDtJQUNBRixRQUFRLENBQUMsRUFBRSxDQUFDO0lBQ1osTUFBTUcsSUFBSSxHQUFHQSxDQUFBLEtBQU07TUFDakIsTUFBTUMsS0FBSyxHQUFHQyxRQUFRLENBQUNsQixhQUFhLENBQUMsY0FBYyxDQUFDO01BQ3BELE1BQU1tQixLQUFLLEdBQUdGLEtBQUssR0FBR2QsS0FBSyxDQUFDQyxJQUFJLENBQUNhLEtBQUssQ0FBQ0csZ0JBQWdCLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBRyxFQUFFO01BQ3ZFLE1BQU1DLEtBQWdCLEdBQUdGLEtBQUssQ0FBQ1gsR0FBRyxDQUFFYyxDQUFDLElBQUs7UUFDeEMsTUFBTUMsSUFBSSxHQUFHMUIsV0FBVyxDQUFDeUIsQ0FBQyxDQUFDO1FBQzNCO1FBQ0E7UUFDQSxNQUFNRSxFQUFFLEdBQUdGLENBQUMsQ0FBQ0UsRUFBRSxJQUFJLElBQUFDLGVBQVMsRUFBQ0YsSUFBSSxDQUFDO1FBQ2xDRCxDQUFDLENBQUNFLEVBQUUsR0FBR0EsRUFBRTtRQUNULE9BQU87VUFBRUEsRUFBRTtVQUFFRCxJQUFJO1VBQUVHLEtBQUssRUFBRUosQ0FBQyxDQUFDSyxPQUFPLEtBQUssSUFBSSxHQUFHLENBQUMsR0FBRztRQUFFLENBQUM7TUFDeEQsQ0FBQyxDQUFDO01BQ0Y7TUFDQTtNQUNBO01BQ0FkLFFBQVEsQ0FBRWUsSUFBSSxJQUNaQSxJQUFJLENBQUNDLE1BQU0sS0FBS1IsS0FBSyxDQUFDUSxNQUFNLElBQUlELElBQUksQ0FBQ0UsS0FBSyxDQUFDLENBQUNDLENBQUMsRUFBRUMsQ0FBQyxLQUFLRCxDQUFDLENBQUNQLEVBQUUsS0FBS0gsS0FBSyxDQUFDVyxDQUFDLENBQUMsQ0FBQ1IsRUFBRSxDQUFDLEdBQUdJLElBQUksR0FBR1AsS0FDdEYsQ0FBQztJQUNILENBQUM7SUFDREwsSUFBSSxDQUFDLENBQUM7SUFDTixNQUFNQyxLQUFLLEdBQUdDLFFBQVEsQ0FBQ2xCLGFBQWEsQ0FBQyxjQUFjLENBQUM7SUFDcEQsTUFBTWlDLEdBQUcsR0FBR2hCLEtBQUssR0FBRyxJQUFJaUIsZ0JBQWdCLENBQUNsQixJQUFJLENBQUMsR0FBRyxJQUFJO0lBQ3JELElBQUlDLEtBQUssSUFBSWdCLEdBQUcsRUFBRUEsR0FBRyxDQUFDRSxPQUFPLENBQUNsQixLQUFLLEVBQUU7TUFBRW1CLFNBQVMsRUFBRSxJQUFJO01BQUVDLE9BQU8sRUFBRTtJQUFLLENBQUMsQ0FBQztJQUN4RTtJQUNBO0lBQ0EsTUFBTUMsTUFBTSxHQUFHLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQzlCLEdBQUcsQ0FBRStCLENBQUMsSUFBS0MsVUFBVSxDQUFDeEIsSUFBSSxFQUFFdUIsQ0FBQyxDQUFDLENBQUM7SUFDOUQsT0FBTyxNQUFNO01BQ1hOLEdBQUcsRUFBRVEsVUFBVSxDQUFDLENBQUM7TUFDakJILE1BQU0sQ0FBQ0ksT0FBTyxDQUFDQyxZQUFZLENBQUM7SUFDOUIsQ0FBQztFQUNILENBQUMsRUFBRSxDQUFDaEMsUUFBUSxDQUFDLENBQUM7RUFFZCxPQUFPQyxLQUFLO0FBQ2Q7O0FBRUE7QUFDTyxTQUFTZ0MsZ0JBQWdCQSxDQUFDaEMsS0FBZ0IsRUFBVTtFQUN6RCxNQUFNLENBQUNpQyxHQUFHLEVBQUVDLE1BQU0sQ0FBQyxHQUFHLElBQUFoQyxlQUFRLEVBQVMsRUFBRSxDQUFDO0VBRTFDLElBQUFDLGdCQUFTLEVBQUMsTUFBTTtJQUNkLElBQUksQ0FBQ0gsS0FBSyxDQUFDaUIsTUFBTSxFQUFFO0lBQ25CLE1BQU1JLEdBQUcsR0FBRyxJQUFJYyxvQkFBb0IsQ0FDakNDLE9BQU8sSUFBSztNQUNYLE1BQU1DLE9BQU8sR0FBR0QsT0FBTyxDQUFDMUMsTUFBTSxDQUFFNEMsQ0FBQyxJQUFLQSxDQUFDLENBQUNDLGNBQWMsQ0FBQztNQUN2RCxJQUFJRixPQUFPLENBQUNwQixNQUFNLEVBQUVpQixNQUFNLENBQUVHLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQ0csTUFBTSxDQUFpQjVCLEVBQUUsQ0FBQztJQUNuRSxDQUFDLEVBQ0Q7TUFBRTZCLFVBQVUsRUFBRSxvQkFBb0I7TUFBRUMsU0FBUyxFQUFFO0lBQUUsQ0FDbkQsQ0FBQztJQUNEMUMsS0FBSyxDQUFDOEIsT0FBTyxDQUFFWCxDQUFDLElBQUs7TUFDbkIsTUFBTXdCLEVBQUUsR0FBR3JDLFFBQVEsQ0FBQ3NDLGNBQWMsQ0FBQ3pCLENBQUMsQ0FBQ1AsRUFBRSxDQUFDO01BQ3hDLElBQUkrQixFQUFFLEVBQUV0QixHQUFHLENBQUNFLE9BQU8sQ0FBQ29CLEVBQUUsQ0FBQztJQUN6QixDQUFDLENBQUM7SUFDRixPQUFPLE1BQU10QixHQUFHLENBQUNRLFVBQVUsQ0FBQyxDQUFDO0VBQy9CLENBQUMsRUFBRSxDQUFDN0IsS0FBSyxDQUFDLENBQUM7RUFFWCxPQUFPaUMsR0FBRztBQUNaIiwiaWdub3JlTGlzdCI6W119