var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = EntryHeader;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.map.js");
var _sdk = require("@immediately-run/sdk");
var _shell = require("../lib/shell");
var _wiki = require("../lib/wiki");
var _Icon = _interopRequireDefault(require("./Icon"));
var _InlineProse = _interopRequireDefault(require("./InlineProse"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$();
/* eslint-disable @typescript-eslint/no-explicit-any */
// The entry's header block: breadcrumb, title (optional gradient), meta row
// (date · reading time · tags) and the unobtrusive edit affordance. Rendered by
// <PageView> at the top of every entry.
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function EntryHeader({
  entryKey,
  writable,
  mins
}) {
  _s();
  const {
    openEditor,
    editBusy,
    editRefused,
    editHint
  } = (0, _shell.useShell)();
  const meta = (0, _sdk.useFileMetadata)(entryKey);
  if (!meta) return null;
  const tags = Array.isArray(meta.tags) ? meta.tags.filter(t => !t.startsWith('ui/')) : [];
  const cr = (0, _wiki.crumb)(entryKey);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("header", {
    className: "grove-entry-header",
    children: [cr.includes('/') ? /*#__PURE__*/(0, _jsxRuntime.jsx)("nav", {
      className: "crumb",
      children: cr
    }) : null, /*#__PURE__*/(0, _jsxRuntime.jsx)("h1", {
      className: meta.grad ? 'grad' : '',
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_InlineProse.default, {
        text: meta.title || cr
      })
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "grove-meta",
      children: [meta.date && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        children: meta.date
      }), mins ? /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
        children: ["\u2192 ", mins, " min read"]
      }) : null, tags.length ? /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "dot",
        children: "\xB7"
      }) : null, tags.map(t => /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
        className: "grove-tag",
        children: ["#", t]
      }, t)), writable && /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
          className: "grove-edit-affordance",
          "data-busy": editBusy ? '1' : '0',
          title: editHint,
          onClick: () => openEditor(entryKey),
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
            name: "pencil"
          }), editBusy ? 'Opening editor…' : 'Edit']
        }), editRefused && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "grove-edit-refused",
          role: "status",
          children: _shell.EDIT_REFUSED_NOTICE
        })]
      })]
    })]
  });
}
_s(EntryHeader, "y0UgCMIV2nnREYMmlt6BkNGQkuM=", false, function () {
  return [_shell.useShell, _sdk.useFileMetadata];
});
_c = EntryHeader;
var _c;
$RefreshReg$(_c, "EntryHeader");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfc2RrIiwicmVxdWlyZSIsIl9zaGVsbCIsIl93aWtpIiwiX0ljb24iLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX0lubGluZVByb3NlIiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsIkVudHJ5SGVhZGVyIiwiZW50cnlLZXkiLCJ3cml0YWJsZSIsIm1pbnMiLCJvcGVuRWRpdG9yIiwiZWRpdEJ1c3kiLCJlZGl0UmVmdXNlZCIsImVkaXRIaW50IiwidXNlU2hlbGwiLCJtZXRhIiwidXNlRmlsZU1ldGFkYXRhIiwidGFncyIsIkFycmF5IiwiaXNBcnJheSIsImZpbHRlciIsInQiLCJzdGFydHNXaXRoIiwiY3IiLCJjcnVtYiIsImpzeHMiLCJjbGFzc05hbWUiLCJjaGlsZHJlbiIsImluY2x1ZGVzIiwianN4IiwiZ3JhZCIsInRleHQiLCJ0aXRsZSIsImRhdGUiLCJsZW5ndGgiLCJtYXAiLCJGcmFnbWVudCIsIm9uQ2xpY2siLCJuYW1lIiwicm9sZSIsIkVESVRfUkVGVVNFRF9OT1RJQ0UiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkVudHJ5SGVhZGVyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55ICovXG5pbXBvcnQgeyB1c2VGaWxlTWV0YWRhdGEgfSBmcm9tICdAaW1tZWRpYXRlbHktcnVuL3Nkayc7XG5pbXBvcnQgeyB1c2VTaGVsbCwgRURJVF9SRUZVU0VEX05PVElDRSB9IGZyb20gJy4uL2xpYi9zaGVsbCc7XG5pbXBvcnQgeyBjcnVtYiB9IGZyb20gJy4uL2xpYi93aWtpJztcbmltcG9ydCBJY29uIGZyb20gJy4vSWNvbic7XG5pbXBvcnQgSW5saW5lUHJvc2UgZnJvbSAnLi9JbmxpbmVQcm9zZSc7XG5cbi8vIFRoZSBlbnRyeSdzIGhlYWRlciBibG9jazogYnJlYWRjcnVtYiwgdGl0bGUgKG9wdGlvbmFsIGdyYWRpZW50KSwgbWV0YSByb3dcbi8vIChkYXRlIMK3IHJlYWRpbmcgdGltZSDCtyB0YWdzKSBhbmQgdGhlIHVub2J0cnVzaXZlIGVkaXQgYWZmb3JkYW5jZS4gUmVuZGVyZWQgYnlcbi8vIDxQYWdlVmlldz4gYXQgdGhlIHRvcCBvZiBldmVyeSBlbnRyeS5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEVudHJ5SGVhZGVyKHtcbiAgZW50cnlLZXksXG4gIHdyaXRhYmxlLFxuICBtaW5zLFxufToge1xuICBlbnRyeUtleTogc3RyaW5nO1xuICB3cml0YWJsZTogYm9vbGVhbjtcbiAgbWluczogbnVtYmVyO1xufSkge1xuICBjb25zdCB7IG9wZW5FZGl0b3IsIGVkaXRCdXN5LCBlZGl0UmVmdXNlZCwgZWRpdEhpbnQgfSA9IHVzZVNoZWxsKCk7XG4gIGNvbnN0IG1ldGEgPSB1c2VGaWxlTWV0YWRhdGEoZW50cnlLZXkpIGFzIGFueTtcbiAgaWYgKCFtZXRhKSByZXR1cm4gbnVsbDtcbiAgY29uc3QgdGFnczogc3RyaW5nW10gPSBBcnJheS5pc0FycmF5KG1ldGEudGFncykgPyBtZXRhLnRhZ3MuZmlsdGVyKCh0OiBzdHJpbmcpID0+ICF0LnN0YXJ0c1dpdGgoJ3VpLycpKSA6IFtdO1xuICBjb25zdCBjciA9IGNydW1iKGVudHJ5S2V5KTtcbiAgcmV0dXJuIChcbiAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImdyb3ZlLWVudHJ5LWhlYWRlclwiPlxuICAgICAge2NyLmluY2x1ZGVzKCcvJykgPyA8bmF2IGNsYXNzTmFtZT1cImNydW1iXCI+e2NyfTwvbmF2PiA6IG51bGx9XG4gICAgICA8aDEgY2xhc3NOYW1lPXttZXRhLmdyYWQgPyAnZ3JhZCcgOiAnJ30+XG4gICAgICAgIHsvKiBSMy01MzEg4oCUIHRoZSB0aXRsZSBpcyBmcm9udG1hdHRlciBwcm9zZTogY29kZSBzcGFucyByZW5kZXIgYXMgY29kZS4gKi99XG4gICAgICAgIDxJbmxpbmVQcm9zZSB0ZXh0PXttZXRhLnRpdGxlIHx8IGNyfSAvPlxuICAgICAgPC9oMT5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JvdmUtbWV0YVwiPlxuICAgICAgICB7bWV0YS5kYXRlICYmIDxzcGFuPnttZXRhLmRhdGV9PC9zcGFuPn1cbiAgICAgICAge21pbnMgPyA8c3Bhbj7ihpIge21pbnN9IG1pbiByZWFkPC9zcGFuPiA6IG51bGx9XG4gICAgICAgIHt0YWdzLmxlbmd0aCA/IDxzcGFuIGNsYXNzTmFtZT1cImRvdFwiPsK3PC9zcGFuPiA6IG51bGx9XG4gICAgICAgIHt0YWdzLm1hcCgodCkgPT4gKFxuICAgICAgICAgIDxzcGFuIGtleT17dH0gY2xhc3NOYW1lPVwiZ3JvdmUtdGFnXCI+I3t0fTwvc3Bhbj5cbiAgICAgICAgKSl9XG4gICAgICAgIHt3cml0YWJsZSAmJiAoXG4gICAgICAgICAgPD5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ3JvdmUtZWRpdC1hZmZvcmRhbmNlXCJcbiAgICAgICAgICAgICAgZGF0YS1idXN5PXtlZGl0QnVzeSA/ICcxJyA6ICcwJ31cbiAgICAgICAgICAgICAgdGl0bGU9e2VkaXRIaW50fVxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvcGVuRWRpdG9yKGVudHJ5S2V5KX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPEljb24gbmFtZT1cInBlbmNpbFwiIC8+XG4gICAgICAgICAgICAgIHtlZGl0QnVzeSA/ICdPcGVuaW5nIGVkaXRvcuKApicgOiAnRWRpdCd9XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIHtlZGl0UmVmdXNlZCAmJiAoXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImdyb3ZlLWVkaXQtcmVmdXNlZFwiIHJvbGU9XCJzdGF0dXNcIj5cbiAgICAgICAgICAgICAgICB7RURJVF9SRUZVU0VEX05PVElDRX1cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8Lz5cbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuICAgIDwvaGVhZGVyPlxuICApO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFDQSxJQUFBQSxJQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxNQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxLQUFBLEdBQUFGLE9BQUE7QUFDQSxJQUFBRyxLQUFBLEdBQUFDLHNCQUFBLENBQUFKLE9BQUE7QUFDQSxJQUFBSyxZQUFBLEdBQUFELHNCQUFBLENBQUFKLE9BQUE7QUFBd0MsSUFBQU0sV0FBQSxHQUFBTixPQUFBO0FBQUEsSUFBQU8sRUFBQSxHQUFBQyxZQUFBO0FBTHhDO0FBT0E7QUFDQTtBQUNBO0FBQUEsU0FBQUosdUJBQUFLLENBQUEsV0FBQUEsQ0FBQSxJQUFBQSxDQUFBLENBQUFDLFVBQUEsR0FBQUQsQ0FBQSxLQUFBRSxPQUFBLEVBQUFGLENBQUE7QUFDZSxTQUFTRyxXQUFXQSxDQUFDO0VBQ2xDQyxRQUFRO0VBQ1JDLFFBQVE7RUFDUkM7QUFLRixDQUFDLEVBQUU7RUFBQVIsRUFBQTtFQUNELE1BQU07SUFBRVMsVUFBVTtJQUFFQyxRQUFRO0lBQUVDLFdBQVc7SUFBRUM7RUFBUyxDQUFDLEdBQUcsSUFBQUMsZUFBUSxFQUFDLENBQUM7RUFDbEUsTUFBTUMsSUFBSSxHQUFHLElBQUFDLG9CQUFlLEVBQUNULFFBQVEsQ0FBUTtFQUM3QyxJQUFJLENBQUNRLElBQUksRUFBRSxPQUFPLElBQUk7RUFDdEIsTUFBTUUsSUFBYyxHQUFHQyxLQUFLLENBQUNDLE9BQU8sQ0FBQ0osSUFBSSxDQUFDRSxJQUFJLENBQUMsR0FBR0YsSUFBSSxDQUFDRSxJQUFJLENBQUNHLE1BQU0sQ0FBRUMsQ0FBUyxJQUFLLENBQUNBLENBQUMsQ0FBQ0MsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsRUFBRTtFQUM1RyxNQUFNQyxFQUFFLEdBQUcsSUFBQUMsV0FBSyxFQUFDakIsUUFBUSxDQUFDO0VBQzFCLG9CQUNFLElBQUFQLFdBQUEsQ0FBQXlCLElBQUE7SUFBUUMsU0FBUyxFQUFDLG9CQUFvQjtJQUFBQyxRQUFBLEdBQ25DSixFQUFFLENBQUNLLFFBQVEsQ0FBQyxHQUFHLENBQUMsZ0JBQUcsSUFBQTVCLFdBQUEsQ0FBQTZCLEdBQUE7TUFBS0gsU0FBUyxFQUFDLE9BQU87TUFBQUMsUUFBQSxFQUFFSjtJQUFFLENBQU0sQ0FBQyxHQUFHLElBQUksZUFDNUQsSUFBQXZCLFdBQUEsQ0FBQTZCLEdBQUE7TUFBSUgsU0FBUyxFQUFFWCxJQUFJLENBQUNlLElBQUksR0FBRyxNQUFNLEdBQUcsRUFBRztNQUFBSCxRQUFBLGVBRXJDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUM5QixZQUFBLENBQUFNLE9BQVc7UUFBQzBCLElBQUksRUFBRWhCLElBQUksQ0FBQ2lCLEtBQUssSUFBSVQ7TUFBRyxDQUFFO0lBQUMsQ0FDckMsQ0FBQyxlQUNMLElBQUF2QixXQUFBLENBQUF5QixJQUFBO01BQUtDLFNBQVMsRUFBQyxZQUFZO01BQUFDLFFBQUEsR0FDeEJaLElBQUksQ0FBQ2tCLElBQUksaUJBQUksSUFBQWpDLFdBQUEsQ0FBQTZCLEdBQUE7UUFBQUYsUUFBQSxFQUFPWixJQUFJLENBQUNrQjtNQUFJLENBQU8sQ0FBQyxFQUNyQ3hCLElBQUksZ0JBQUcsSUFBQVQsV0FBQSxDQUFBeUIsSUFBQTtRQUFBRSxRQUFBLEdBQU0sU0FBRSxFQUFDbEIsSUFBSSxFQUFDLFdBQVM7TUFBQSxDQUFNLENBQUMsR0FBRyxJQUFJLEVBQzVDUSxJQUFJLENBQUNpQixNQUFNLGdCQUFHLElBQUFsQyxXQUFBLENBQUE2QixHQUFBO1FBQU1ILFNBQVMsRUFBQyxLQUFLO1FBQUFDLFFBQUEsRUFBQztNQUFDLENBQU0sQ0FBQyxHQUFHLElBQUksRUFDbkRWLElBQUksQ0FBQ2tCLEdBQUcsQ0FBRWQsQ0FBQyxpQkFDVixJQUFBckIsV0FBQSxDQUFBeUIsSUFBQTtRQUFjQyxTQUFTLEVBQUMsV0FBVztRQUFBQyxRQUFBLEdBQUMsR0FBQyxFQUFDTixDQUFDO01BQUEsR0FBNUJBLENBQW1DLENBQy9DLENBQUMsRUFDRGIsUUFBUSxpQkFDUCxJQUFBUixXQUFBLENBQUF5QixJQUFBLEVBQUF6QixXQUFBLENBQUFvQyxRQUFBO1FBQUFULFFBQUEsZ0JBQ0UsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUE7VUFDRUMsU0FBUyxFQUFDLHVCQUF1QjtVQUNqQyxhQUFXZixRQUFRLEdBQUcsR0FBRyxHQUFHLEdBQUk7VUFDaENxQixLQUFLLEVBQUVuQixRQUFTO1VBQ2hCd0IsT0FBTyxFQUFFQSxDQUFBLEtBQU0zQixVQUFVLENBQUNILFFBQVEsQ0FBRTtVQUFBb0IsUUFBQSxnQkFFcEMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQ2hDLEtBQUEsQ0FBQVEsT0FBSTtZQUFDaUMsSUFBSSxFQUFDO1VBQVEsQ0FBRSxDQUFDLEVBQ3JCM0IsUUFBUSxHQUFHLGlCQUFpQixHQUFHLE1BQU07UUFBQSxDQUNoQyxDQUFDLEVBQ1JDLFdBQVcsaUJBQ1YsSUFBQVosV0FBQSxDQUFBNkIsR0FBQTtVQUFNSCxTQUFTLEVBQUMsb0JBQW9CO1VBQUNhLElBQUksRUFBQyxRQUFRO1VBQUFaLFFBQUEsRUFDL0NhO1FBQW1CLENBQ2hCLENBQ1A7TUFBQSxDQUNELENBQ0g7SUFBQSxDQUNFLENBQUM7RUFBQSxDQUNBLENBQUM7QUFFYjtBQUFDdkMsRUFBQSxDQWpEdUJLLFdBQVc7RUFBQSxRQVN1QlEsZUFBUSxFQUNuREUsb0JBQWU7QUFBQTtBQUFBeUIsRUFBQSxHQVZObkMsV0FBVztBQUFBLElBQUFtQyxFQUFBO0FBQUFDLFlBQUEsQ0FBQUQsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}