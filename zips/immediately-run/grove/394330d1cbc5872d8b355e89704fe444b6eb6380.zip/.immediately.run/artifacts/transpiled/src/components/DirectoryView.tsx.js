var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = DirectoryView;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
var _shell = require("../lib/shell");
var _content = require("../lib/content");
var _directory = require("../lib/directory");
var _DirectoryList = _interopRequireDefault(require("./DirectoryList"));
var _Icon = _interopRequireDefault(require("./Icon"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$();
/* eslint-disable @typescript-eslint/no-explicit-any */
// Resolving the table through the MDX component map is what makes it OVERRIDABLE.
// `useMDXComponents({})` returns the provider's map — the SDK defaults, under Grove's
// vocabulary, under whatever a fork or (once R3-174 lands) the CONTENT registered. So
// replacing `DirectoryList` replaces it everywhere it renders, including this route,
// rather than only where an author typed the tag. The literal `{}` is hoisted because
// the SDK memoizes on the argument's identity.
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
const NO_OVERRIDES = {};

/**
 * The reading view for a URL that names a FOLDER.
 *
 * Grove's routes are filesystem paths, so a folder is an address a reader can reach —
 * by typing it, by trimming a URL, from the host's file explorer, or by following a
 * link into a namespace. It used to resolve to "No entry at …", which is false: the
 * entries exist, one level down. This renders the folder instead: breadcrumb, name, and
 * the overridable `<DirectoryList/>`.
 *
 * (An author who wants a *curated* page at a folder URL writes `index.mdx` in it — the
 * router prefers that over this view. See `folderIndexKey`.)
 */
function DirectoryView() {
  _s();
  const {
    entryKey,
    siteTitle
  } = (0, _shell.useShell)();
  const components = (0, _sdk.useMDXComponents)(NO_OVERRIDES);
  const List = components.DirectoryList ?? _DirectoryList.default;
  const crumbs = (0, _directory.dirCrumbs)(entryKey);
  const name = crumbs.length ? crumbs[crumbs.length - 1].label : siteTitle;
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("article", {
    className: "grove-page",
    "data-layout": "doc",
    "data-view": "directory",
    children: /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "gp-main",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("header", {
        className: "grove-entry-header",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("nav", {
          className: "crumb",
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_sdk.Link, {
            href: "/",
            children: siteTitle
          }), crumbs.slice(0, -1).map(c => /*#__PURE__*/(0, _jsxRuntime.jsxs)(_react.Fragment, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
              "aria-hidden": "true",
              children: "/"
            }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_sdk.Link, {
              href: (0, _content.keyToHref)(c.key),
              children: c.label
            })]
          }, c.key))]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("h1", {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
            className: "gdir__title-icon",
            "aria-hidden": "true",
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
              name: "folder"
            })
          }), name]
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
          className: "grove-meta",
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
            children: "Folder"
          })
        })]
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "grove-prose",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(List, {
          path: (0, _directory.dirKeyToPath)(entryKey)
        })
      })]
    })
  });
}
_s(DirectoryView, "x6RCxkEsru5mkgi28kZZ59GqK+8=", false, function () {
  return [_shell.useShell, _sdk.useMDXComponents];
});
_c = DirectoryView;
var _c;
$RefreshReg$(_c, "DirectoryView");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NkayIsIl9zaGVsbCIsIl9jb250ZW50IiwiX2RpcmVjdG9yeSIsIl9EaXJlY3RvcnlMaXN0IiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsIl9JY29uIiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsIk5PX09WRVJSSURFUyIsIkRpcmVjdG9yeVZpZXciLCJlbnRyeUtleSIsInNpdGVUaXRsZSIsInVzZVNoZWxsIiwiY29tcG9uZW50cyIsInVzZU1EWENvbXBvbmVudHMiLCJMaXN0IiwiRGlyZWN0b3J5TGlzdCIsImNydW1icyIsImRpckNydW1icyIsIm5hbWUiLCJsZW5ndGgiLCJsYWJlbCIsImpzeCIsImNsYXNzTmFtZSIsImNoaWxkcmVuIiwianN4cyIsIkxpbmsiLCJocmVmIiwic2xpY2UiLCJtYXAiLCJjIiwiRnJhZ21lbnQiLCJrZXlUb0hyZWYiLCJrZXkiLCJwYXRoIiwiZGlyS2V5VG9QYXRoIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJEaXJlY3RvcnlWaWV3LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55ICovXG5pbXBvcnQgeyBGcmFnbWVudCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB0eXBlIHsgQ29tcG9uZW50VHlwZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IExpbmssIHVzZU1EWENvbXBvbmVudHMgfSBmcm9tICdAaW1tZWRpYXRlbHktcnVuL3Nkayc7XG5pbXBvcnQgeyB1c2VTaGVsbCB9IGZyb20gJy4uL2xpYi9zaGVsbCc7XG5pbXBvcnQgeyBrZXlUb0hyZWYgfSBmcm9tICcuLi9saWIvY29udGVudCc7XG5pbXBvcnQgeyBkaXJDcnVtYnMsIGRpcktleVRvUGF0aCB9IGZyb20gJy4uL2xpYi9kaXJlY3RvcnknO1xuaW1wb3J0IERpcmVjdG9yeUxpc3QgZnJvbSAnLi9EaXJlY3RvcnlMaXN0JztcbmltcG9ydCBJY29uIGZyb20gJy4vSWNvbic7XG5cbi8vIFJlc29sdmluZyB0aGUgdGFibGUgdGhyb3VnaCB0aGUgTURYIGNvbXBvbmVudCBtYXAgaXMgd2hhdCBtYWtlcyBpdCBPVkVSUklEQUJMRS5cbi8vIGB1c2VNRFhDb21wb25lbnRzKHt9KWAgcmV0dXJucyB0aGUgcHJvdmlkZXIncyBtYXAg4oCUIHRoZSBTREsgZGVmYXVsdHMsIHVuZGVyIEdyb3ZlJ3Ncbi8vIHZvY2FidWxhcnksIHVuZGVyIHdoYXRldmVyIGEgZm9yayBvciAob25jZSBSMy0xNzQgbGFuZHMpIHRoZSBDT05URU5UIHJlZ2lzdGVyZWQuIFNvXG4vLyByZXBsYWNpbmcgYERpcmVjdG9yeUxpc3RgIHJlcGxhY2VzIGl0IGV2ZXJ5d2hlcmUgaXQgcmVuZGVycywgaW5jbHVkaW5nIHRoaXMgcm91dGUsXG4vLyByYXRoZXIgdGhhbiBvbmx5IHdoZXJlIGFuIGF1dGhvciB0eXBlZCB0aGUgdGFnLiBUaGUgbGl0ZXJhbCBge31gIGlzIGhvaXN0ZWQgYmVjYXVzZVxuLy8gdGhlIFNESyBtZW1vaXplcyBvbiB0aGUgYXJndW1lbnQncyBpZGVudGl0eS5cbmNvbnN0IE5PX09WRVJSSURFUyA9IHt9O1xuXG4vKipcbiAqIFRoZSByZWFkaW5nIHZpZXcgZm9yIGEgVVJMIHRoYXQgbmFtZXMgYSBGT0xERVIuXG4gKlxuICogR3JvdmUncyByb3V0ZXMgYXJlIGZpbGVzeXN0ZW0gcGF0aHMsIHNvIGEgZm9sZGVyIGlzIGFuIGFkZHJlc3MgYSByZWFkZXIgY2FuIHJlYWNoIOKAlFxuICogYnkgdHlwaW5nIGl0LCBieSB0cmltbWluZyBhIFVSTCwgZnJvbSB0aGUgaG9zdCdzIGZpbGUgZXhwbG9yZXIsIG9yIGJ5IGZvbGxvd2luZyBhXG4gKiBsaW5rIGludG8gYSBuYW1lc3BhY2UuIEl0IHVzZWQgdG8gcmVzb2x2ZSB0byBcIk5vIGVudHJ5IGF0IOKAplwiLCB3aGljaCBpcyBmYWxzZTogdGhlXG4gKiBlbnRyaWVzIGV4aXN0LCBvbmUgbGV2ZWwgZG93bi4gVGhpcyByZW5kZXJzIHRoZSBmb2xkZXIgaW5zdGVhZDogYnJlYWRjcnVtYiwgbmFtZSwgYW5kXG4gKiB0aGUgb3ZlcnJpZGFibGUgYDxEaXJlY3RvcnlMaXN0Lz5gLlxuICpcbiAqIChBbiBhdXRob3Igd2hvIHdhbnRzIGEgKmN1cmF0ZWQqIHBhZ2UgYXQgYSBmb2xkZXIgVVJMIHdyaXRlcyBgaW5kZXgubWR4YCBpbiBpdCDigJQgdGhlXG4gKiByb3V0ZXIgcHJlZmVycyB0aGF0IG92ZXIgdGhpcyB2aWV3LiBTZWUgYGZvbGRlckluZGV4S2V5YC4pXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIERpcmVjdG9yeVZpZXcoKSB7XG4gIGNvbnN0IHsgZW50cnlLZXksIHNpdGVUaXRsZSB9ID0gdXNlU2hlbGwoKTtcbiAgY29uc3QgY29tcG9uZW50cyA9IHVzZU1EWENvbXBvbmVudHMoTk9fT1ZFUlJJREVTKSBhcyBSZWNvcmQ8c3RyaW5nLCBDb21wb25lbnRUeXBlPGFueT4gfCB1bmRlZmluZWQ+O1xuICBjb25zdCBMaXN0ID0gY29tcG9uZW50cy5EaXJlY3RvcnlMaXN0ID8/IERpcmVjdG9yeUxpc3Q7XG5cbiAgY29uc3QgY3J1bWJzID0gZGlyQ3J1bWJzKGVudHJ5S2V5KTtcbiAgY29uc3QgbmFtZSA9IGNydW1icy5sZW5ndGggPyBjcnVtYnNbY3J1bWJzLmxlbmd0aCAtIDFdLmxhYmVsIDogc2l0ZVRpdGxlO1xuXG4gIHJldHVybiAoXG4gICAgPGFydGljbGUgY2xhc3NOYW1lPVwiZ3JvdmUtcGFnZVwiIGRhdGEtbGF5b3V0PVwiZG9jXCIgZGF0YS12aWV3PVwiZGlyZWN0b3J5XCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdwLW1haW5cIj5cbiAgICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJncm92ZS1lbnRyeS1oZWFkZXJcIj5cbiAgICAgICAgICA8bmF2IGNsYXNzTmFtZT1cImNydW1iXCI+XG4gICAgICAgICAgICA8TGluayBocmVmPVwiL1wiPntzaXRlVGl0bGV9PC9MaW5rPlxuICAgICAgICAgICAge2NydW1icy5zbGljZSgwLCAtMSkubWFwKChjKSA9PiAoXG4gICAgICAgICAgICAgIDxGcmFnbWVudCBrZXk9e2Mua2V5fT5cbiAgICAgICAgICAgICAgICA8c3BhbiBhcmlhLWhpZGRlbj1cInRydWVcIj4vPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9e2tleVRvSHJlZihjLmtleSl9PntjLmxhYmVsfTwvTGluaz5cbiAgICAgICAgICAgICAgPC9GcmFnbWVudD5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvbmF2PlxuICAgICAgICAgIDxoMT5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImdkaXJfX3RpdGxlLWljb25cIiBhcmlhLWhpZGRlbj1cInRydWVcIj5cbiAgICAgICAgICAgICAgPEljb24gbmFtZT1cImZvbGRlclwiIC8+XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICB7bmFtZX1cbiAgICAgICAgICA8L2gxPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JvdmUtbWV0YVwiPlxuICAgICAgICAgICAgPHNwYW4+Rm9sZGVyPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2hlYWRlcj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncm92ZS1wcm9zZVwiPlxuICAgICAgICAgIDxMaXN0IHBhdGg9e2RpcktleVRvUGF0aChlbnRyeUtleSl9IC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9hcnRpY2xlPlxuICApO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUNBLElBQUFBLE1BQUEsR0FBQUMsT0FBQTtBQUVBLElBQUFDLElBQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLE1BQUEsR0FBQUYsT0FBQTtBQUNBLElBQUFHLFFBQUEsR0FBQUgsT0FBQTtBQUNBLElBQUFJLFVBQUEsR0FBQUosT0FBQTtBQUNBLElBQUFLLGNBQUEsR0FBQUMsc0JBQUEsQ0FBQU4sT0FBQTtBQUNBLElBQUFPLEtBQUEsR0FBQUQsc0JBQUEsQ0FBQU4sT0FBQTtBQUEwQixJQUFBUSxXQUFBLEdBQUFSLE9BQUE7QUFBQSxJQUFBUyxFQUFBLEdBQUFDLFlBQUE7QUFSMUI7QUFVQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFBQSxTQUFBSix1QkFBQUssQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQUNBLE1BQU1HLFlBQVksR0FBRyxDQUFDLENBQUM7O0FBRXZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNlLFNBQVNDLGFBQWFBLENBQUEsRUFBRztFQUFBTixFQUFBO0VBQ3RDLE1BQU07SUFBRU8sUUFBUTtJQUFFQztFQUFVLENBQUMsR0FBRyxJQUFBQyxlQUFRLEVBQUMsQ0FBQztFQUMxQyxNQUFNQyxVQUFVLEdBQUcsSUFBQUMscUJBQWdCLEVBQUNOLFlBQVksQ0FBbUQ7RUFDbkcsTUFBTU8sSUFBSSxHQUFHRixVQUFVLENBQUNHLGFBQWEsSUFBSUEsc0JBQWE7RUFFdEQsTUFBTUMsTUFBTSxHQUFHLElBQUFDLG9CQUFTLEVBQUNSLFFBQVEsQ0FBQztFQUNsQyxNQUFNUyxJQUFJLEdBQUdGLE1BQU0sQ0FBQ0csTUFBTSxHQUFHSCxNQUFNLENBQUNBLE1BQU0sQ0FBQ0csTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDQyxLQUFLLEdBQUdWLFNBQVM7RUFFeEUsb0JBQ0UsSUFBQVQsV0FBQSxDQUFBb0IsR0FBQTtJQUFTQyxTQUFTLEVBQUMsWUFBWTtJQUFDLGVBQVksS0FBSztJQUFDLGFBQVUsV0FBVztJQUFBQyxRQUFBLGVBQ3JFLElBQUF0QixXQUFBLENBQUF1QixJQUFBO01BQUtGLFNBQVMsRUFBQyxTQUFTO01BQUFDLFFBQUEsZ0JBQ3RCLElBQUF0QixXQUFBLENBQUF1QixJQUFBO1FBQVFGLFNBQVMsRUFBQyxvQkFBb0I7UUFBQUMsUUFBQSxnQkFDcEMsSUFBQXRCLFdBQUEsQ0FBQXVCLElBQUE7VUFBS0YsU0FBUyxFQUFDLE9BQU87VUFBQUMsUUFBQSxnQkFDcEIsSUFBQXRCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQzNCLElBQUEsQ0FBQStCLElBQUk7WUFBQ0MsSUFBSSxFQUFDLEdBQUc7WUFBQUgsUUFBQSxFQUFFYjtVQUFTLENBQU8sQ0FBQyxFQUNoQ00sTUFBTSxDQUFDVyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUNDLEdBQUcsQ0FBRUMsQ0FBQyxpQkFDekIsSUFBQTVCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ2hDLE1BQUEsQ0FBQXNDLFFBQVE7WUFBQVAsUUFBQSxnQkFDUCxJQUFBdEIsV0FBQSxDQUFBb0IsR0FBQTtjQUFNLGVBQVksTUFBTTtjQUFBRSxRQUFBLEVBQUM7WUFBQyxDQUFNLENBQUMsZUFDakMsSUFBQXRCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQzNCLElBQUEsQ0FBQStCLElBQUk7Y0FBQ0MsSUFBSSxFQUFFLElBQUFLLGtCQUFTLEVBQUNGLENBQUMsQ0FBQ0csR0FBRyxDQUFFO2NBQUFULFFBQUEsRUFBRU0sQ0FBQyxDQUFDVDtZQUFLLENBQU8sQ0FBQztVQUFBLEdBRmpDUyxDQUFDLENBQUNHLEdBR1AsQ0FDWCxDQUFDO1FBQUEsQ0FDQyxDQUFDLGVBQ04sSUFBQS9CLFdBQUEsQ0FBQXVCLElBQUE7VUFBQUQsUUFBQSxnQkFDRSxJQUFBdEIsV0FBQSxDQUFBb0IsR0FBQTtZQUFNQyxTQUFTLEVBQUMsa0JBQWtCO1lBQUMsZUFBWSxNQUFNO1lBQUFDLFFBQUEsZUFDbkQsSUFBQXRCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ3JCLEtBQUEsQ0FBQU0sT0FBSTtjQUFDWSxJQUFJLEVBQUM7WUFBUSxDQUFFO1VBQUMsQ0FDbEIsQ0FBQyxFQUNOQSxJQUFJO1FBQUEsQ0FDSCxDQUFDLGVBQ0wsSUFBQWpCLFdBQUEsQ0FBQW9CLEdBQUE7VUFBS0MsU0FBUyxFQUFDLFlBQVk7VUFBQUMsUUFBQSxlQUN6QixJQUFBdEIsV0FBQSxDQUFBb0IsR0FBQTtZQUFBRSxRQUFBLEVBQU07VUFBTSxDQUFNO1FBQUMsQ0FDaEIsQ0FBQztNQUFBLENBQ0EsQ0FBQyxlQUNULElBQUF0QixXQUFBLENBQUFvQixHQUFBO1FBQUtDLFNBQVMsRUFBQyxhQUFhO1FBQUFDLFFBQUEsZUFDMUIsSUFBQXRCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ1AsSUFBSTtVQUFDbUIsSUFBSSxFQUFFLElBQUFDLHVCQUFZLEVBQUN6QixRQUFRO1FBQUUsQ0FBRTtNQUFDLENBQ25DLENBQUM7SUFBQSxDQUNIO0VBQUMsQ0FDQyxDQUFDO0FBRWQ7QUFBQ1AsRUFBQSxDQXJDdUJNLGFBQWE7RUFBQSxRQUNIRyxlQUFRLEVBQ3JCRSxxQkFBZ0I7QUFBQTtBQUFBc0IsRUFBQSxHQUZiM0IsYUFBYTtBQUFBLElBQUEyQixFQUFBO0FBQUFDLFlBQUEsQ0FBQUQsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}