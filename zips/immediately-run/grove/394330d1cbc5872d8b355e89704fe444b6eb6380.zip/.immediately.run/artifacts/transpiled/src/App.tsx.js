var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = App;
var _react = require("react");
var _sdk = _interopRequireWildcard(require("@immediately-run/sdk"));
var sdk = _sdk;
var _sandboxUtils = require("@immediately-run/sdk/sandboxUtils");
var _TinkerableContext = require("@immediately-run/sdk/TinkerableContext");
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _useOpenWikiBoot = require("./hooks/useOpenWikiBoot");
var _useBundleMetadata = require("./hooks/useBundleMetadata");
var _useContentComponents = require("./hooks/useContentComponents");
var _contentRoot = require("./lib/contentRoot");
var _content = require("./lib/content");
var _GroveWiki = _interopRequireDefault(require("./GroveWiki"));
var _BootMessage = _interopRequireDefault(require("./components/BootMessage"));
var _corpusScanContext = require("./lib/corpusScanContext");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The entry point immediately.run renders — deliberately a GATE, not the wiki.
//
// Grove ships in two packagings and they disagree about two things: where the corpus is,
// and who knows what is in it.
//
//   • FORK      — `/app/content/`, indexed by the bundler at build time. Both answers
//                 arrive before the app boots, so the gate falls straight through.
//   • DISPATCH  — a host-minted chroot at someone else's directory (R3-169), which the
//                 bundler never scanned, so the frontmatter index has to be BUILT
//                 (R3-265). Neither answer exists at first render.
//
// Every helper the wiki is made of — which keys are entries, what their hrefs are, which
// layouts wrap them — is a function of the root; every surface a reader sees — nav,
// sidebar, search, backlinks, routing, the 404 index — is a function of the index. A
// component that rendered before the root was settled would show the VIEWER's corpus, and
// then not correct itself; so would one that rendered with no index in scope, because the
// metadata hooks fall back to the host's store. So this file holds until the root is
// settled and the bundle is LISTED — every key known, rows filling in — and from then on
// always provides the bundle's index. Which rows an entry needs READ before it paints is
// GroveWiki's call (MDX_FROM_MOUNT_SPEC D8).
//
// Hence the split: this file resolves, `GroveWiki` renders.
// R3-268 — the viewed-document rule, registered ONCE at module load: every
// `navigate()`/`<Link>` navigation declares which file the destination renders,
// so the host's file explorer can highlight it. The mapping is
// `viewedDocumentForTarget` (lib/content): repo-relative for a fork,
// CORPUS-relative under dispatch — the host joins its chroot prefix, since the
// corpus's repo-side location is host knowledge this app cannot see. Resolved
// PER NAVIGATION, not captured: the content root is a function of dispatch
// state (see `contentRoot`). Guarded with `?.` so Grove still runs against an
// SDK generation without the hook (the host then falls back to the URL
// convention, which under dispatch simply yields no highlight). Highlight-only
// by contract — this never scrolls, never moves focus, never opens the editor.
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
sdk.setViewedDocumentResolver?.(_content.viewedDocumentForTarget);
function App() {
  _s();
  const host = (0, _react.use)(_TinkerableContext.TinkerableContext);
  const boot = (0, _useOpenWikiBoot.useOpenWikiBoot)();
  // R3-268 deep links: declare the INITIALLY rendered document once at boot. A
  // fresh page load performs no navigation, so without this the host records no
  // viewed document for a deep link and the explorer shows no highlight (nor
  // ancestor dot) until the first in-app click. Carries no gesture: the host
  // records it userInitiated=false — highlight-only, never a reveal. Waits for
  // the boot resolution because the content root (and so the mapping) is a
  // function of dispatch state. Fire-and-forget: no transport (plain `vite dev`)
  // must not crash the wiki.
  const declaredBootRef = (0, _react.useRef)(false);
  const outerHref = host?.outerHref;
  (0, _react.useEffect)(() => {
    if (declaredBootRef.current) return;
    if (boot.status !== 'ready' && boot.status !== 'fork') return;
    if (!outerHref) return;
    declaredBootRef.current = true;
    try {
      (0, _sandboxUtils.sendMessage)('viewed-document-declare', {
        value: (0, _content.viewedDocumentForTarget)(outerHref)
      });
    } catch {
      /* no host transport — a standalone dev server render */
    }
  }, [boot.status, outerHref]);
  // Only a dispatched viewer scans; a fork's index is already in the context.
  const bundle = (0, _useBundleMetadata.useBundleMetadata)(boot.status === 'ready' ? (0, _contentRoot.getContentRoot)() : null);
  // BOTH packagings, deliberately (R3-174). A corpus's own component vocabulary must not
  // depend on how it was composed — `PLATFORM_LAYERING_SPEC` §1.1's mode-invariance rule —
  // so a fork reads its marker too; that is one cheap open of a file already in `/app`.
  // Gated on the boot status for the same reason the scan is: before the delegation
  // resolves, `getContentRoot()` is still the fork default, and reading THAT marker under
  // dispatch would register the viewer's own sample-corpus components against someone
  // else's content.
  const contentComponents = (0, _useContentComponents.useContentComponents)(boot.status === 'ready' || boot.status === 'fork' ? (0, _contentRoot.getContentRoot)() : null);
  if (boot.status === 'failed') return /*#__PURE__*/(0, _jsxRuntime.jsx)(_BootMessage.default, {
    children: boot.message
  });

  // The provider must be COMPLETE before content paints (MDX_FROM_MOUNT_SPEC §2's
  // invariant): rendering into a half-composed map would flash a missing-component error
  // for `<RoadmapBoard>` until registration landed — the very error content components
  // exist to remove — and a nested provider patched in afterwards would do the same.
  //
  // The frontmatter index is NOT held for (D8). Once the bundle is listed every key is
  // known; the rows the requested entry needs are GroveWiki's to wait for, and the rest
  // fill in around a painted page.
  if (boot.status === 'waiting' || bundle.status === 'listing' || contentComponents.status === 'loading') {
    return /*#__PURE__*/(0, _jsxRuntime.jsx)(_BootMessage.default, {});
  }

  // Corpus-declared components (R3-174) go on as a nested provider, which the SDK's
  // `useMDXComponents` resolves as `{...stock, ...content}` — so CONTENT WINS a name
  // clash, and a wiki may override even `<DocsByTag>` with its own (value 4, max
  // hackability). §2's "single-map merge, never provider nesting" was written against
  // patching a provider in AFTER a partial render; nesting it INSIDE the gate above is
  // that same merge, composed before anything paints.
  const wiki = /*#__PURE__*/(0, _jsxRuntime.jsx)(_GroveWiki.default, {
    readOnly: boot.readOnly,
    rejectedComponents: contentComponents.rejected
  });
  const withComponents = contentComponents.status === 'ready' && Object.keys(contentComponents.components).length > 0 ? /*#__PURE__*/(0, _jsxRuntime.jsx)(_MDXProvider.MDXProvider, {
    components: contentComponents.components,
    children: wiki
  }) : wiki;

  // R3-315/R3-310 — the declared face set mounts INSIDE GroveWiki now, keyed to
  // the resolved theme (the catalogue looks change the reading face); nothing
  // font-shaped waits on the scan from here.

  if (bundle.metadata && bundle.scan) {
    // Provide the scanned bundle as the metadata SOURCE through the supported
    // surface (R3-276), not a wholesale TinkerableContext re-provision: the
    // platform stays free to grow its own state, and the hooks read the nearest
    // MetadataSource — so every consumer works unchanged, and nothing re-states
    // host fields it does not own. Provided from the first partial index on, so the
    // tree keeps its shape when the scan completes rather than remounting the wiki.
    return /*#__PURE__*/(0, _jsxRuntime.jsx)(_corpusScanContext.CorpusScanContext, {
      value: bundle.scan,
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_sdk.MetadataSource, {
        value: bundle.metadata,
        children: withComponents
      })
    });
  }
  return withComponents;
}
_s(App, "8aFcjso5ZOZG6dqmwV/LVIfYt6o=", false, function () {
  return [_useOpenWikiBoot.useOpenWikiBoot, _useBundleMetadata.useBundleMetadata, _useContentComponents.useContentComponents];
});
_c = App;
var _c;
$RefreshReg$(_c, "App");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NkayIsIl9pbnRlcm9wUmVxdWlyZVdpbGRjYXJkIiwic2RrIiwiX3NhbmRib3hVdGlscyIsIl9UaW5rZXJhYmxlQ29udGV4dCIsIl9NRFhQcm92aWRlciIsIl91c2VPcGVuV2lraUJvb3QiLCJfdXNlQnVuZGxlTWV0YWRhdGEiLCJfdXNlQ29udGVudENvbXBvbmVudHMiLCJfY29udGVudFJvb3QiLCJfY29udGVudCIsIl9Hcm92ZVdpa2kiLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX0Jvb3RNZXNzYWdlIiwiX2NvcnB1c1NjYW5Db250ZXh0IiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsIl9nZXRSZXF1aXJlV2lsZGNhcmRDYWNoZSIsIldlYWtNYXAiLCJyIiwidCIsImhhcyIsImdldCIsIm4iLCJfX3Byb3RvX18iLCJhIiwiT2JqZWN0IiwiZGVmaW5lUHJvcGVydHkiLCJnZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IiLCJ1IiwiaGFzT3duUHJvcGVydHkiLCJjYWxsIiwiaSIsInNldCIsInNldFZpZXdlZERvY3VtZW50UmVzb2x2ZXIiLCJ2aWV3ZWREb2N1bWVudEZvclRhcmdldCIsIkFwcCIsImhvc3QiLCJ1c2UiLCJUaW5rZXJhYmxlQ29udGV4dCIsImJvb3QiLCJ1c2VPcGVuV2lraUJvb3QiLCJkZWNsYXJlZEJvb3RSZWYiLCJ1c2VSZWYiLCJvdXRlckhyZWYiLCJ1c2VFZmZlY3QiLCJjdXJyZW50Iiwic3RhdHVzIiwic2VuZE1lc3NhZ2UiLCJ2YWx1ZSIsImJ1bmRsZSIsInVzZUJ1bmRsZU1ldGFkYXRhIiwiZ2V0Q29udGVudFJvb3QiLCJjb250ZW50Q29tcG9uZW50cyIsInVzZUNvbnRlbnRDb21wb25lbnRzIiwianN4IiwiY2hpbGRyZW4iLCJtZXNzYWdlIiwid2lraSIsInJlYWRPbmx5IiwicmVqZWN0ZWRDb21wb25lbnRzIiwicmVqZWN0ZWQiLCJ3aXRoQ29tcG9uZW50cyIsImtleXMiLCJjb21wb25lbnRzIiwibGVuZ3RoIiwiTURYUHJvdmlkZXIiLCJtZXRhZGF0YSIsInNjYW4iLCJDb3JwdXNTY2FuQ29udGV4dCIsIk1ldGFkYXRhU291cmNlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBcHAudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIFRoZSBlbnRyeSBwb2ludCBpbW1lZGlhdGVseS5ydW4gcmVuZGVycyDigJQgZGVsaWJlcmF0ZWx5IGEgR0FURSwgbm90IHRoZSB3aWtpLlxuLy9cbi8vIEdyb3ZlIHNoaXBzIGluIHR3byBwYWNrYWdpbmdzIGFuZCB0aGV5IGRpc2FncmVlIGFib3V0IHR3byB0aGluZ3M6IHdoZXJlIHRoZSBjb3JwdXMgaXMsXG4vLyBhbmQgd2hvIGtub3dzIHdoYXQgaXMgaW4gaXQuXG4vL1xuLy8gICDigKIgRk9SSyAgICAgIOKAlCBgL2FwcC9jb250ZW50L2AsIGluZGV4ZWQgYnkgdGhlIGJ1bmRsZXIgYXQgYnVpbGQgdGltZS4gQm90aCBhbnN3ZXJzXG4vLyAgICAgICAgICAgICAgICAgYXJyaXZlIGJlZm9yZSB0aGUgYXBwIGJvb3RzLCBzbyB0aGUgZ2F0ZSBmYWxscyBzdHJhaWdodCB0aHJvdWdoLlxuLy8gICDigKIgRElTUEFUQ0ggIOKAlCBhIGhvc3QtbWludGVkIGNocm9vdCBhdCBzb21lb25lIGVsc2UncyBkaXJlY3RvcnkgKFIzLTE2OSksIHdoaWNoIHRoZVxuLy8gICAgICAgICAgICAgICAgIGJ1bmRsZXIgbmV2ZXIgc2Nhbm5lZCwgc28gdGhlIGZyb250bWF0dGVyIGluZGV4IGhhcyB0byBiZSBCVUlMVFxuLy8gICAgICAgICAgICAgICAgIChSMy0yNjUpLiBOZWl0aGVyIGFuc3dlciBleGlzdHMgYXQgZmlyc3QgcmVuZGVyLlxuLy9cbi8vIEV2ZXJ5IGhlbHBlciB0aGUgd2lraSBpcyBtYWRlIG9mIOKAlCB3aGljaCBrZXlzIGFyZSBlbnRyaWVzLCB3aGF0IHRoZWlyIGhyZWZzIGFyZSwgd2hpY2hcbi8vIGxheW91dHMgd3JhcCB0aGVtIOKAlCBpcyBhIGZ1bmN0aW9uIG9mIHRoZSByb290OyBldmVyeSBzdXJmYWNlIGEgcmVhZGVyIHNlZXMg4oCUIG5hdixcbi8vIHNpZGViYXIsIHNlYXJjaCwgYmFja2xpbmtzLCByb3V0aW5nLCB0aGUgNDA0IGluZGV4IOKAlCBpcyBhIGZ1bmN0aW9uIG9mIHRoZSBpbmRleC4gQVxuLy8gY29tcG9uZW50IHRoYXQgcmVuZGVyZWQgYmVmb3JlIHRoZSByb290IHdhcyBzZXR0bGVkIHdvdWxkIHNob3cgdGhlIFZJRVdFUidzIGNvcnB1cywgYW5kXG4vLyB0aGVuIG5vdCBjb3JyZWN0IGl0c2VsZjsgc28gd291bGQgb25lIHRoYXQgcmVuZGVyZWQgd2l0aCBubyBpbmRleCBpbiBzY29wZSwgYmVjYXVzZSB0aGVcbi8vIG1ldGFkYXRhIGhvb2tzIGZhbGwgYmFjayB0byB0aGUgaG9zdCdzIHN0b3JlLiBTbyB0aGlzIGZpbGUgaG9sZHMgdW50aWwgdGhlIHJvb3QgaXNcbi8vIHNldHRsZWQgYW5kIHRoZSBidW5kbGUgaXMgTElTVEVEIOKAlCBldmVyeSBrZXkga25vd24sIHJvd3MgZmlsbGluZyBpbiDigJQgYW5kIGZyb20gdGhlbiBvblxuLy8gYWx3YXlzIHByb3ZpZGVzIHRoZSBidW5kbGUncyBpbmRleC4gV2hpY2ggcm93cyBhbiBlbnRyeSBuZWVkcyBSRUFEIGJlZm9yZSBpdCBwYWludHMgaXNcbi8vIEdyb3ZlV2lraSdzIGNhbGwgKE1EWF9GUk9NX01PVU5UX1NQRUMgRDgpLlxuLy9cbi8vIEhlbmNlIHRoZSBzcGxpdDogdGhpcyBmaWxlIHJlc29sdmVzLCBgR3JvdmVXaWtpYCByZW5kZXJzLlxuXG5pbXBvcnQgeyB1c2UsIHVzZUVmZmVjdCwgdXNlUmVmIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0ICogYXMgc2RrIGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrJztcbmltcG9ydCB7IHNlbmRNZXNzYWdlIH0gZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9zZGsvc2FuZGJveFV0aWxzJztcbmltcG9ydCB7IE1ldGFkYXRhU291cmNlIH0gZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9zZGsnO1xuaW1wb3J0IHsgVGlua2VyYWJsZUNvbnRleHQgfSBmcm9tICdAaW1tZWRpYXRlbHktcnVuL3Nkay9UaW5rZXJhYmxlQ29udGV4dCc7XG5pbXBvcnQgeyBNRFhQcm92aWRlciB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrL01EWFByb3ZpZGVyJztcbmltcG9ydCB7IHVzZU9wZW5XaWtpQm9vdCB9IGZyb20gJy4vaG9va3MvdXNlT3Blbldpa2lCb290JztcbmltcG9ydCB7IHVzZUJ1bmRsZU1ldGFkYXRhIH0gZnJvbSAnLi9ob29rcy91c2VCdW5kbGVNZXRhZGF0YSc7XG5pbXBvcnQgeyB1c2VDb250ZW50Q29tcG9uZW50cyB9IGZyb20gJy4vaG9va3MvdXNlQ29udGVudENvbXBvbmVudHMnO1xuaW1wb3J0IHsgZ2V0Q29udGVudFJvb3QgfSBmcm9tICcuL2xpYi9jb250ZW50Um9vdCc7XG5pbXBvcnQgeyB2aWV3ZWREb2N1bWVudEZvclRhcmdldCB9IGZyb20gJy4vbGliL2NvbnRlbnQnO1xuaW1wb3J0IEdyb3ZlV2lraSBmcm9tICcuL0dyb3ZlV2lraSc7XG5pbXBvcnQgQm9vdE1lc3NhZ2UgZnJvbSAnLi9jb21wb25lbnRzL0Jvb3RNZXNzYWdlJztcbmltcG9ydCB7IENvcnB1c1NjYW5Db250ZXh0IH0gZnJvbSAnLi9saWIvY29ycHVzU2NhbkNvbnRleHQnO1xuXG4vLyBSMy0yNjgg4oCUIHRoZSB2aWV3ZWQtZG9jdW1lbnQgcnVsZSwgcmVnaXN0ZXJlZCBPTkNFIGF0IG1vZHVsZSBsb2FkOiBldmVyeVxuLy8gYG5hdmlnYXRlKClgL2A8TGluaz5gIG5hdmlnYXRpb24gZGVjbGFyZXMgd2hpY2ggZmlsZSB0aGUgZGVzdGluYXRpb24gcmVuZGVycyxcbi8vIHNvIHRoZSBob3N0J3MgZmlsZSBleHBsb3JlciBjYW4gaGlnaGxpZ2h0IGl0LiBUaGUgbWFwcGluZyBpc1xuLy8gYHZpZXdlZERvY3VtZW50Rm9yVGFyZ2V0YCAobGliL2NvbnRlbnQpOiByZXBvLXJlbGF0aXZlIGZvciBhIGZvcmssXG4vLyBDT1JQVVMtcmVsYXRpdmUgdW5kZXIgZGlzcGF0Y2gg4oCUIHRoZSBob3N0IGpvaW5zIGl0cyBjaHJvb3QgcHJlZml4LCBzaW5jZSB0aGVcbi8vIGNvcnB1cydzIHJlcG8tc2lkZSBsb2NhdGlvbiBpcyBob3N0IGtub3dsZWRnZSB0aGlzIGFwcCBjYW5ub3Qgc2VlLiBSZXNvbHZlZFxuLy8gUEVSIE5BVklHQVRJT04sIG5vdCBjYXB0dXJlZDogdGhlIGNvbnRlbnQgcm9vdCBpcyBhIGZ1bmN0aW9uIG9mIGRpc3BhdGNoXG4vLyBzdGF0ZSAoc2VlIGBjb250ZW50Um9vdGApLiBHdWFyZGVkIHdpdGggYD8uYCBzbyBHcm92ZSBzdGlsbCBydW5zIGFnYWluc3QgYW5cbi8vIFNESyBnZW5lcmF0aW9uIHdpdGhvdXQgdGhlIGhvb2sgKHRoZSBob3N0IHRoZW4gZmFsbHMgYmFjayB0byB0aGUgVVJMXG4vLyBjb252ZW50aW9uLCB3aGljaCB1bmRlciBkaXNwYXRjaCBzaW1wbHkgeWllbGRzIG5vIGhpZ2hsaWdodCkuIEhpZ2hsaWdodC1vbmx5XG4vLyBieSBjb250cmFjdCDigJQgdGhpcyBuZXZlciBzY3JvbGxzLCBuZXZlciBtb3ZlcyBmb2N1cywgbmV2ZXIgb3BlbnMgdGhlIGVkaXRvci5cbihzZGsgYXMgeyBzZXRWaWV3ZWREb2N1bWVudFJlc29sdmVyPzogKHI6IChocmVmOiBzdHJpbmcpID0+IHN0cmluZyB8IG51bGwgfCB1bmRlZmluZWQpID0+IHZvaWQgfSlcbiAgLnNldFZpZXdlZERvY3VtZW50UmVzb2x2ZXI/Lih2aWV3ZWREb2N1bWVudEZvclRhcmdldCk7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFwcCgpIHtcbiAgY29uc3QgaG9zdCA9IHVzZShUaW5rZXJhYmxlQ29udGV4dCk7XG4gIGNvbnN0IGJvb3QgPSB1c2VPcGVuV2lraUJvb3QoKTtcbiAgLy8gUjMtMjY4IGRlZXAgbGlua3M6IGRlY2xhcmUgdGhlIElOSVRJQUxMWSByZW5kZXJlZCBkb2N1bWVudCBvbmNlIGF0IGJvb3QuIEFcbiAgLy8gZnJlc2ggcGFnZSBsb2FkIHBlcmZvcm1zIG5vIG5hdmlnYXRpb24sIHNvIHdpdGhvdXQgdGhpcyB0aGUgaG9zdCByZWNvcmRzIG5vXG4gIC8vIHZpZXdlZCBkb2N1bWVudCBmb3IgYSBkZWVwIGxpbmsgYW5kIHRoZSBleHBsb3JlciBzaG93cyBubyBoaWdobGlnaHQgKG5vclxuICAvLyBhbmNlc3RvciBkb3QpIHVudGlsIHRoZSBmaXJzdCBpbi1hcHAgY2xpY2suIENhcnJpZXMgbm8gZ2VzdHVyZTogdGhlIGhvc3RcbiAgLy8gcmVjb3JkcyBpdCB1c2VySW5pdGlhdGVkPWZhbHNlIOKAlCBoaWdobGlnaHQtb25seSwgbmV2ZXIgYSByZXZlYWwuIFdhaXRzIGZvclxuICAvLyB0aGUgYm9vdCByZXNvbHV0aW9uIGJlY2F1c2UgdGhlIGNvbnRlbnQgcm9vdCAoYW5kIHNvIHRoZSBtYXBwaW5nKSBpcyBhXG4gIC8vIGZ1bmN0aW9uIG9mIGRpc3BhdGNoIHN0YXRlLiBGaXJlLWFuZC1mb3JnZXQ6IG5vIHRyYW5zcG9ydCAocGxhaW4gYHZpdGUgZGV2YClcbiAgLy8gbXVzdCBub3QgY3Jhc2ggdGhlIHdpa2kuXG4gIGNvbnN0IGRlY2xhcmVkQm9vdFJlZiA9IHVzZVJlZihmYWxzZSk7XG4gIGNvbnN0IG91dGVySHJlZiA9IGhvc3Q/Lm91dGVySHJlZjtcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoZGVjbGFyZWRCb290UmVmLmN1cnJlbnQpIHJldHVybjtcbiAgICBpZiAoYm9vdC5zdGF0dXMgIT09ICdyZWFkeScgJiYgYm9vdC5zdGF0dXMgIT09ICdmb3JrJykgcmV0dXJuO1xuICAgIGlmICghb3V0ZXJIcmVmKSByZXR1cm47XG4gICAgZGVjbGFyZWRCb290UmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgIHRyeSB7XG4gICAgICBzZW5kTWVzc2FnZSgndmlld2VkLWRvY3VtZW50LWRlY2xhcmUnLCB7IHZhbHVlOiB2aWV3ZWREb2N1bWVudEZvclRhcmdldChvdXRlckhyZWYpIH0pO1xuICAgIH0gY2F0Y2gge1xuICAgICAgLyogbm8gaG9zdCB0cmFuc3BvcnQg4oCUIGEgc3RhbmRhbG9uZSBkZXYgc2VydmVyIHJlbmRlciAqL1xuICAgIH1cbiAgfSwgW2Jvb3Quc3RhdHVzLCBvdXRlckhyZWZdKTtcbiAgLy8gT25seSBhIGRpc3BhdGNoZWQgdmlld2VyIHNjYW5zOyBhIGZvcmsncyBpbmRleCBpcyBhbHJlYWR5IGluIHRoZSBjb250ZXh0LlxuICBjb25zdCBidW5kbGUgPSB1c2VCdW5kbGVNZXRhZGF0YShib290LnN0YXR1cyA9PT0gJ3JlYWR5JyA/IGdldENvbnRlbnRSb290KCkgOiBudWxsKTtcbiAgLy8gQk9USCBwYWNrYWdpbmdzLCBkZWxpYmVyYXRlbHkgKFIzLTE3NCkuIEEgY29ycHVzJ3Mgb3duIGNvbXBvbmVudCB2b2NhYnVsYXJ5IG11c3Qgbm90XG4gIC8vIGRlcGVuZCBvbiBob3cgaXQgd2FzIGNvbXBvc2VkIOKAlCBgUExBVEZPUk1fTEFZRVJJTkdfU1BFQ2AgwqcxLjEncyBtb2RlLWludmFyaWFuY2UgcnVsZSDigJRcbiAgLy8gc28gYSBmb3JrIHJlYWRzIGl0cyBtYXJrZXIgdG9vOyB0aGF0IGlzIG9uZSBjaGVhcCBvcGVuIG9mIGEgZmlsZSBhbHJlYWR5IGluIGAvYXBwYC5cbiAgLy8gR2F0ZWQgb24gdGhlIGJvb3Qgc3RhdHVzIGZvciB0aGUgc2FtZSByZWFzb24gdGhlIHNjYW4gaXM6IGJlZm9yZSB0aGUgZGVsZWdhdGlvblxuICAvLyByZXNvbHZlcywgYGdldENvbnRlbnRSb290KClgIGlzIHN0aWxsIHRoZSBmb3JrIGRlZmF1bHQsIGFuZCByZWFkaW5nIFRIQVQgbWFya2VyIHVuZGVyXG4gIC8vIGRpc3BhdGNoIHdvdWxkIHJlZ2lzdGVyIHRoZSB2aWV3ZXIncyBvd24gc2FtcGxlLWNvcnB1cyBjb21wb25lbnRzIGFnYWluc3Qgc29tZW9uZVxuICAvLyBlbHNlJ3MgY29udGVudC5cbiAgY29uc3QgY29udGVudENvbXBvbmVudHMgPSB1c2VDb250ZW50Q29tcG9uZW50cyhcbiAgICBib290LnN0YXR1cyA9PT0gJ3JlYWR5JyB8fCBib290LnN0YXR1cyA9PT0gJ2ZvcmsnID8gZ2V0Q29udGVudFJvb3QoKSA6IG51bGwsXG4gICk7XG5cbiAgaWYgKGJvb3Quc3RhdHVzID09PSAnZmFpbGVkJykgcmV0dXJuIDxCb290TWVzc2FnZT57Ym9vdC5tZXNzYWdlfTwvQm9vdE1lc3NhZ2U+O1xuXG4gIC8vIFRoZSBwcm92aWRlciBtdXN0IGJlIENPTVBMRVRFIGJlZm9yZSBjb250ZW50IHBhaW50cyAoTURYX0ZST01fTU9VTlRfU1BFQyDCpzInc1xuICAvLyBpbnZhcmlhbnQpOiByZW5kZXJpbmcgaW50byBhIGhhbGYtY29tcG9zZWQgbWFwIHdvdWxkIGZsYXNoIGEgbWlzc2luZy1jb21wb25lbnQgZXJyb3JcbiAgLy8gZm9yIGA8Um9hZG1hcEJvYXJkPmAgdW50aWwgcmVnaXN0cmF0aW9uIGxhbmRlZCDigJQgdGhlIHZlcnkgZXJyb3IgY29udGVudCBjb21wb25lbnRzXG4gIC8vIGV4aXN0IHRvIHJlbW92ZSDigJQgYW5kIGEgbmVzdGVkIHByb3ZpZGVyIHBhdGNoZWQgaW4gYWZ0ZXJ3YXJkcyB3b3VsZCBkbyB0aGUgc2FtZS5cbiAgLy9cbiAgLy8gVGhlIGZyb250bWF0dGVyIGluZGV4IGlzIE5PVCBoZWxkIGZvciAoRDgpLiBPbmNlIHRoZSBidW5kbGUgaXMgbGlzdGVkIGV2ZXJ5IGtleSBpc1xuICAvLyBrbm93bjsgdGhlIHJvd3MgdGhlIHJlcXVlc3RlZCBlbnRyeSBuZWVkcyBhcmUgR3JvdmVXaWtpJ3MgdG8gd2FpdCBmb3IsIGFuZCB0aGUgcmVzdFxuICAvLyBmaWxsIGluIGFyb3VuZCBhIHBhaW50ZWQgcGFnZS5cbiAgaWYgKGJvb3Quc3RhdHVzID09PSAnd2FpdGluZycgfHwgYnVuZGxlLnN0YXR1cyA9PT0gJ2xpc3RpbmcnIHx8IGNvbnRlbnRDb21wb25lbnRzLnN0YXR1cyA9PT0gJ2xvYWRpbmcnKSB7XG4gICAgcmV0dXJuIDxCb290TWVzc2FnZSAvPjtcbiAgfVxuXG4gIC8vIENvcnB1cy1kZWNsYXJlZCBjb21wb25lbnRzIChSMy0xNzQpIGdvIG9uIGFzIGEgbmVzdGVkIHByb3ZpZGVyLCB3aGljaCB0aGUgU0RLJ3NcbiAgLy8gYHVzZU1EWENvbXBvbmVudHNgIHJlc29sdmVzIGFzIGB7Li4uc3RvY2ssIC4uLmNvbnRlbnR9YCDigJQgc28gQ09OVEVOVCBXSU5TIGEgbmFtZVxuICAvLyBjbGFzaCwgYW5kIGEgd2lraSBtYXkgb3ZlcnJpZGUgZXZlbiBgPERvY3NCeVRhZz5gIHdpdGggaXRzIG93biAodmFsdWUgNCwgbWF4XG4gIC8vIGhhY2thYmlsaXR5KS4gwqcyJ3MgXCJzaW5nbGUtbWFwIG1lcmdlLCBuZXZlciBwcm92aWRlciBuZXN0aW5nXCIgd2FzIHdyaXR0ZW4gYWdhaW5zdFxuICAvLyBwYXRjaGluZyBhIHByb3ZpZGVyIGluIEFGVEVSIGEgcGFydGlhbCByZW5kZXI7IG5lc3RpbmcgaXQgSU5TSURFIHRoZSBnYXRlIGFib3ZlIGlzXG4gIC8vIHRoYXQgc2FtZSBtZXJnZSwgY29tcG9zZWQgYmVmb3JlIGFueXRoaW5nIHBhaW50cy5cbiAgY29uc3Qgd2lraSA9IDxHcm92ZVdpa2kgcmVhZE9ubHk9e2Jvb3QucmVhZE9ubHl9IHJlamVjdGVkQ29tcG9uZW50cz17Y29udGVudENvbXBvbmVudHMucmVqZWN0ZWR9IC8+O1xuICBjb25zdCB3aXRoQ29tcG9uZW50cyA9XG4gICAgY29udGVudENvbXBvbmVudHMuc3RhdHVzID09PSAncmVhZHknICYmIE9iamVjdC5rZXlzKGNvbnRlbnRDb21wb25lbnRzLmNvbXBvbmVudHMpLmxlbmd0aCA+IDAgPyAoXG4gICAgICA8TURYUHJvdmlkZXIgY29tcG9uZW50cz17Y29udGVudENvbXBvbmVudHMuY29tcG9uZW50c30+e3dpa2l9PC9NRFhQcm92aWRlcj5cbiAgICApIDogKFxuICAgICAgd2lraVxuICAgICk7XG5cbiAgLy8gUjMtMzE1L1IzLTMxMCDigJQgdGhlIGRlY2xhcmVkIGZhY2Ugc2V0IG1vdW50cyBJTlNJREUgR3JvdmVXaWtpIG5vdywga2V5ZWQgdG9cbiAgLy8gdGhlIHJlc29sdmVkIHRoZW1lICh0aGUgY2F0YWxvZ3VlIGxvb2tzIGNoYW5nZSB0aGUgcmVhZGluZyBmYWNlKTsgbm90aGluZ1xuICAvLyBmb250LXNoYXBlZCB3YWl0cyBvbiB0aGUgc2NhbiBmcm9tIGhlcmUuXG5cbiAgaWYgKGJ1bmRsZS5tZXRhZGF0YSAmJiBidW5kbGUuc2Nhbikge1xuICAgIC8vIFByb3ZpZGUgdGhlIHNjYW5uZWQgYnVuZGxlIGFzIHRoZSBtZXRhZGF0YSBTT1VSQ0UgdGhyb3VnaCB0aGUgc3VwcG9ydGVkXG4gICAgLy8gc3VyZmFjZSAoUjMtMjc2KSwgbm90IGEgd2hvbGVzYWxlIFRpbmtlcmFibGVDb250ZXh0IHJlLXByb3Zpc2lvbjogdGhlXG4gICAgLy8gcGxhdGZvcm0gc3RheXMgZnJlZSB0byBncm93IGl0cyBvd24gc3RhdGUsIGFuZCB0aGUgaG9va3MgcmVhZCB0aGUgbmVhcmVzdFxuICAgIC8vIE1ldGFkYXRhU291cmNlIOKAlCBzbyBldmVyeSBjb25zdW1lciB3b3JrcyB1bmNoYW5nZWQsIGFuZCBub3RoaW5nIHJlLXN0YXRlc1xuICAgIC8vIGhvc3QgZmllbGRzIGl0IGRvZXMgbm90IG93bi4gUHJvdmlkZWQgZnJvbSB0aGUgZmlyc3QgcGFydGlhbCBpbmRleCBvbiwgc28gdGhlXG4gICAgLy8gdHJlZSBrZWVwcyBpdHMgc2hhcGUgd2hlbiB0aGUgc2NhbiBjb21wbGV0ZXMgcmF0aGVyIHRoYW4gcmVtb3VudGluZyB0aGUgd2lraS5cbiAgICByZXR1cm4gKFxuICAgICAgPENvcnB1c1NjYW5Db250ZXh0IHZhbHVlPXtidW5kbGUuc2Nhbn0+XG4gICAgICAgIDxNZXRhZGF0YVNvdXJjZSB2YWx1ZT17YnVuZGxlLm1ldGFkYXRhfT57d2l0aENvbXBvbmVudHN9PC9NZXRhZGF0YVNvdXJjZT5cbiAgICAgIDwvQ29ycHVzU2NhbkNvbnRleHQ+XG4gICAgKTtcbiAgfVxuXG4gIHJldHVybiB3aXRoQ29tcG9uZW50cztcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBdUJBLElBQUFBLE1BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLElBQUEsR0FBQUMsdUJBQUEsQ0FBQUYsT0FBQTtBQUE0QyxJQUFBRyxHQUFBLEdBQUFGLElBQUE7QUFDNUMsSUFBQUcsYUFBQSxHQUFBSixPQUFBO0FBRUEsSUFBQUssa0JBQUEsR0FBQUwsT0FBQTtBQUNBLElBQUFNLFlBQUEsR0FBQU4sT0FBQTtBQUNBLElBQUFPLGdCQUFBLEdBQUFQLE9BQUE7QUFDQSxJQUFBUSxrQkFBQSxHQUFBUixPQUFBO0FBQ0EsSUFBQVMscUJBQUEsR0FBQVQsT0FBQTtBQUNBLElBQUFVLFlBQUEsR0FBQVYsT0FBQTtBQUNBLElBQUFXLFFBQUEsR0FBQVgsT0FBQTtBQUNBLElBQUFZLFVBQUEsR0FBQUMsc0JBQUEsQ0FBQWIsT0FBQTtBQUNBLElBQUFjLFlBQUEsR0FBQUQsc0JBQUEsQ0FBQWIsT0FBQTtBQUNBLElBQUFlLGtCQUFBLEdBQUFmLE9BQUE7QUFBNEQsSUFBQWdCLFdBQUEsR0FBQWhCLE9BQUE7QUFBQSxJQUFBaUIsRUFBQSxHQUFBQyxZQUFBLElBcEM1RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWlCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQUEsU0FBQUwsdUJBQUFNLENBQUEsV0FBQUEsQ0FBQSxJQUFBQSxDQUFBLENBQUFDLFVBQUEsR0FBQUQsQ0FBQSxLQUFBRSxPQUFBLEVBQUFGLENBQUE7QUFBQSxTQUFBRyx5QkFBQUgsQ0FBQSw2QkFBQUksT0FBQSxtQkFBQUMsQ0FBQSxPQUFBRCxPQUFBLElBQUFFLENBQUEsT0FBQUYsT0FBQSxZQUFBRCx3QkFBQSxZQUFBQSxDQUFBSCxDQUFBLFdBQUFBLENBQUEsR0FBQU0sQ0FBQSxHQUFBRCxDQUFBLEtBQUFMLENBQUE7QUFBQSxTQUFBakIsd0JBQUFpQixDQUFBLEVBQUFLLENBQUEsU0FBQUEsQ0FBQSxJQUFBTCxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxTQUFBRCxDQUFBLGVBQUFBLENBQUEsdUJBQUFBLENBQUEseUJBQUFBLENBQUEsV0FBQUUsT0FBQSxFQUFBRixDQUFBLFFBQUFNLENBQUEsR0FBQUgsd0JBQUEsQ0FBQUUsQ0FBQSxPQUFBQyxDQUFBLElBQUFBLENBQUEsQ0FBQUMsR0FBQSxDQUFBUCxDQUFBLFVBQUFNLENBQUEsQ0FBQUUsR0FBQSxDQUFBUixDQUFBLE9BQUFTLENBQUEsS0FBQUMsU0FBQSxVQUFBQyxDQUFBLEdBQUFDLE1BQUEsQ0FBQUMsY0FBQSxJQUFBRCxNQUFBLENBQUFFLHdCQUFBLFdBQUFDLENBQUEsSUFBQWYsQ0FBQSxvQkFBQWUsQ0FBQSxPQUFBQyxjQUFBLENBQUFDLElBQUEsQ0FBQWpCLENBQUEsRUFBQWUsQ0FBQSxTQUFBRyxDQUFBLEdBQUFQLENBQUEsR0FBQUMsTUFBQSxDQUFBRSx3QkFBQSxDQUFBZCxDQUFBLEVBQUFlLENBQUEsVUFBQUcsQ0FBQSxLQUFBQSxDQUFBLENBQUFWLEdBQUEsSUFBQVUsQ0FBQSxDQUFBQyxHQUFBLElBQUFQLE1BQUEsQ0FBQUMsY0FBQSxDQUFBSixDQUFBLEVBQUFNLENBQUEsRUFBQUcsQ0FBQSxJQUFBVCxDQUFBLENBQUFNLENBQUEsSUFBQWYsQ0FBQSxDQUFBZSxDQUFBLFlBQUFOLENBQUEsQ0FBQVAsT0FBQSxHQUFBRixDQUFBLEVBQUFNLENBQUEsSUFBQUEsQ0FBQSxDQUFBYSxHQUFBLENBQUFuQixDQUFBLEVBQUFTLENBQUEsR0FBQUEsQ0FBQTtBQUNDekIsR0FBRyxDQUNEb0MseUJBQXlCLEdBQUdDLGdDQUF1QixDQUFDO0FBRXhDLFNBQVNDLEdBQUdBLENBQUEsRUFBRztFQUFBeEIsRUFBQTtFQUM1QixNQUFNeUIsSUFBSSxHQUFHLElBQUFDLFVBQUcsRUFBQ0Msb0NBQWlCLENBQUM7RUFDbkMsTUFBTUMsSUFBSSxHQUFHLElBQUFDLGdDQUFlLEVBQUMsQ0FBQztFQUM5QjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsTUFBTUMsZUFBZSxHQUFHLElBQUFDLGFBQU0sRUFBQyxLQUFLLENBQUM7RUFDckMsTUFBTUMsU0FBUyxHQUFHUCxJQUFJLEVBQUVPLFNBQVM7RUFDakMsSUFBQUMsZ0JBQVMsRUFBQyxNQUFNO0lBQ2QsSUFBSUgsZUFBZSxDQUFDSSxPQUFPLEVBQUU7SUFDN0IsSUFBSU4sSUFBSSxDQUFDTyxNQUFNLEtBQUssT0FBTyxJQUFJUCxJQUFJLENBQUNPLE1BQU0sS0FBSyxNQUFNLEVBQUU7SUFDdkQsSUFBSSxDQUFDSCxTQUFTLEVBQUU7SUFDaEJGLGVBQWUsQ0FBQ0ksT0FBTyxHQUFHLElBQUk7SUFDOUIsSUFBSTtNQUNGLElBQUFFLHlCQUFXLEVBQUMseUJBQXlCLEVBQUU7UUFBRUMsS0FBSyxFQUFFLElBQUFkLGdDQUF1QixFQUFDUyxTQUFTO01BQUUsQ0FBQyxDQUFDO0lBQ3ZGLENBQUMsQ0FBQyxNQUFNO01BQ047SUFBQTtFQUVKLENBQUMsRUFBRSxDQUFDSixJQUFJLENBQUNPLE1BQU0sRUFBRUgsU0FBUyxDQUFDLENBQUM7RUFDNUI7RUFDQSxNQUFNTSxNQUFNLEdBQUcsSUFBQUMsb0NBQWlCLEVBQUNYLElBQUksQ0FBQ08sTUFBTSxLQUFLLE9BQU8sR0FBRyxJQUFBSywyQkFBYyxFQUFDLENBQUMsR0FBRyxJQUFJLENBQUM7RUFDbkY7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNQyxpQkFBaUIsR0FBRyxJQUFBQywwQ0FBb0IsRUFDNUNkLElBQUksQ0FBQ08sTUFBTSxLQUFLLE9BQU8sSUFBSVAsSUFBSSxDQUFDTyxNQUFNLEtBQUssTUFBTSxHQUFHLElBQUFLLDJCQUFjLEVBQUMsQ0FBQyxHQUFHLElBQ3pFLENBQUM7RUFFRCxJQUFJWixJQUFJLENBQUNPLE1BQU0sS0FBSyxRQUFRLEVBQUUsb0JBQU8sSUFBQXBDLFdBQUEsQ0FBQTRDLEdBQUEsRUFBQzlDLFlBQUEsQ0FBQU8sT0FBVztJQUFBd0MsUUFBQSxFQUFFaEIsSUFBSSxDQUFDaUI7RUFBTyxDQUFjLENBQUM7O0VBRTlFO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxJQUFJakIsSUFBSSxDQUFDTyxNQUFNLEtBQUssU0FBUyxJQUFJRyxNQUFNLENBQUNILE1BQU0sS0FBSyxTQUFTLElBQUlNLGlCQUFpQixDQUFDTixNQUFNLEtBQUssU0FBUyxFQUFFO0lBQ3RHLG9CQUFPLElBQUFwQyxXQUFBLENBQUE0QyxHQUFBLEVBQUM5QyxZQUFBLENBQUFPLE9BQVcsSUFBRSxDQUFDO0VBQ3hCOztFQUVBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU0wQyxJQUFJLGdCQUFHLElBQUEvQyxXQUFBLENBQUE0QyxHQUFBLEVBQUNoRCxVQUFBLENBQUFTLE9BQVM7SUFBQzJDLFFBQVEsRUFBRW5CLElBQUksQ0FBQ21CLFFBQVM7SUFBQ0Msa0JBQWtCLEVBQUVQLGlCQUFpQixDQUFDUTtFQUFTLENBQUUsQ0FBQztFQUNuRyxNQUFNQyxjQUFjLEdBQ2xCVCxpQkFBaUIsQ0FBQ04sTUFBTSxLQUFLLE9BQU8sSUFBSXJCLE1BQU0sQ0FBQ3FDLElBQUksQ0FBQ1YsaUJBQWlCLENBQUNXLFVBQVUsQ0FBQyxDQUFDQyxNQUFNLEdBQUcsQ0FBQyxnQkFDMUYsSUFBQXRELFdBQUEsQ0FBQTRDLEdBQUEsRUFBQ3RELFlBQUEsQ0FBQWlFLFdBQVc7SUFBQ0YsVUFBVSxFQUFFWCxpQkFBaUIsQ0FBQ1csVUFBVztJQUFBUixRQUFBLEVBQUVFO0VBQUksQ0FBYyxDQUFDLEdBRTNFQSxJQUNEOztFQUVIO0VBQ0E7RUFDQTs7RUFFQSxJQUFJUixNQUFNLENBQUNpQixRQUFRLElBQUlqQixNQUFNLENBQUNrQixJQUFJLEVBQUU7SUFDbEM7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0Esb0JBQ0UsSUFBQXpELFdBQUEsQ0FBQTRDLEdBQUEsRUFBQzdDLGtCQUFBLENBQUEyRCxpQkFBaUI7TUFBQ3BCLEtBQUssRUFBRUMsTUFBTSxDQUFDa0IsSUFBSztNQUFBWixRQUFBLGVBQ3BDLElBQUE3QyxXQUFBLENBQUE0QyxHQUFBLEVBQUMzRCxJQUFBLENBQUEwRSxjQUFjO1FBQUNyQixLQUFLLEVBQUVDLE1BQU0sQ0FBQ2lCLFFBQVM7UUFBQVgsUUFBQSxFQUFFTTtNQUFjLENBQWlCO0lBQUMsQ0FDeEQsQ0FBQztFQUV4QjtFQUVBLE9BQU9BLGNBQWM7QUFDdkI7QUFBQ2xELEVBQUEsQ0FwRnVCd0IsR0FBRztFQUFBLFFBRVpLLGdDQUFlLEVBdUJiVSxvQ0FBaUIsRUFRTkcsMENBQW9CO0FBQUE7QUFBQWlCLEVBQUEsR0FqQ3hCbkMsR0FBRztBQUFBLElBQUFtQyxFQUFBO0FBQUFDLFlBQUEsQ0FBQUQsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}