var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = More;
var _jsxRuntime = require("react/jsx-runtime");
// Import-free engine component: marks the excerpt cutoff in an entry body.
function More() {
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "grove-more",
    "aria-hidden": "true",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
      children: "\u25CF"
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
      children: "\u25CF"
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
      children: "\u25CF"
    })]
  });
}
_c = More;
var _c;
$RefreshReg$(_c, "More");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJNb3JlIiwiX2pzeFJ1bnRpbWUiLCJqc3hzIiwiY2xhc3NOYW1lIiwiY2hpbGRyZW4iLCJqc3giLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIk1vcmUudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIEltcG9ydC1mcmVlIGVuZ2luZSBjb21wb25lbnQ6IG1hcmtzIHRoZSBleGNlcnB0IGN1dG9mZiBpbiBhbiBlbnRyeSBib2R5LlxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTW9yZSgpIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImdyb3ZlLW1vcmVcIiBhcmlhLWhpZGRlbj1cInRydWVcIj5cbiAgICAgIDxzcGFuPuKXjzwvc3Bhbj5cbiAgICAgIDxzcGFuPuKXjzwvc3Bhbj5cbiAgICAgIDxzcGFuPuKXjzwvc3Bhbj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUFBO0FBQ2UsU0FBU0EsSUFBSUEsQ0FBQSxFQUFHO0VBQzdCLG9CQUNFLElBQUFDLFdBQUEsQ0FBQUMsSUFBQTtJQUFLQyxTQUFTLEVBQUMsWUFBWTtJQUFDLGVBQVksTUFBTTtJQUFBQyxRQUFBLGdCQUM1QyxJQUFBSCxXQUFBLENBQUFJLEdBQUE7TUFBQUQsUUFBQSxFQUFNO0lBQUMsQ0FBTSxDQUFDLGVBQ2QsSUFBQUgsV0FBQSxDQUFBSSxHQUFBO01BQUFELFFBQUEsRUFBTTtJQUFDLENBQU0sQ0FBQyxlQUNkLElBQUFILFdBQUEsQ0FBQUksR0FBQTtNQUFBRCxRQUFBLEVBQU07SUFBQyxDQUFNLENBQUM7RUFBQSxDQUNYLENBQUM7QUFFVjtBQUFDRSxFQUFBLEdBUnVCTixJQUFJO0FBQUEsSUFBQU0sRUFBQTtBQUFBQyxZQUFBLENBQUFELEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}