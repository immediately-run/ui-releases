var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = ChildPages;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.map.js");
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
var _TinkerableContext = require("@immediately-run/sdk/TinkerableContext");
var _content = require("../lib/content");
var _wiki = require("../lib/wiki");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$();
/* eslint-disable @typescript-eslint/no-explicit-any */
// `<ChildPages/>` — the entries that live under the current entry's namespace, as
// a compact nested list (e.g. everything in `handbook/` from the handbook index).
function ChildPages() {
  _s();
  const ctx = (0, _react.useContext)(_TinkerableContext.TinkerableContext);
  const currentKey = (0, _content.sandboxPathToKey)(ctx?.navigationState?.sandboxPath || '/');
  const rel = currentKey.replace((0, _content.contentDir)(), '').replace(/\.mdx?$/, '');
  // The folder this entry indexes: its own slug if it's a section index, else its namespace.
  const scope = rel.replace(/\/?(index|home)$/, '');
  const queryFn = (0, _react.useCallback)(fm => Object.keys(fm).filter(p => {
    if (!(0, _content.isContentEntry)(p) || p === currentKey) return false;
    return (0, _wiki.namespaceOf)(p) === scope;
  }).sort(), [currentKey, scope]);
  const q = (0, _sdk.useMetadataQuery)(queryFn);
  const paths = (0, _wiki.queryPaths)(q);
  if (!paths.length) return null;
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    className: "grove-doclist",
    "data-shape": "feed",
    children: paths.map(p => /*#__PURE__*/(0, _jsxRuntime.jsx)(_sdk.Link, {
      href: (0, _content.keyToHref)(p),
      className: "gdl-row",
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "gdl-row__t",
        children: p.replace((0, _content.contentDir)(), '').replace(/\.mdx?$/, '').split('/').pop()
      })
    }, p))
  });
}
_s(ChildPages, "Oycr/aSiOBfLWRwgRwmCOPKcxQE=", false, function () {
  return [_sdk.useMetadataQuery];
});
_c = ChildPages;
var _c;
$RefreshReg$(_c, "ChildPages");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NkayIsIl9UaW5rZXJhYmxlQ29udGV4dCIsIl9jb250ZW50IiwiX3dpa2kiLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiQ2hpbGRQYWdlcyIsImN0eCIsInVzZUNvbnRleHQiLCJUaW5rZXJhYmxlQ29udGV4dCIsImN1cnJlbnRLZXkiLCJzYW5kYm94UGF0aFRvS2V5IiwibmF2aWdhdGlvblN0YXRlIiwic2FuZGJveFBhdGgiLCJyZWwiLCJyZXBsYWNlIiwiY29udGVudERpciIsInNjb3BlIiwicXVlcnlGbiIsInVzZUNhbGxiYWNrIiwiZm0iLCJPYmplY3QiLCJrZXlzIiwiZmlsdGVyIiwicCIsImlzQ29udGVudEVudHJ5IiwibmFtZXNwYWNlT2YiLCJzb3J0IiwicSIsInVzZU1ldGFkYXRhUXVlcnkiLCJwYXRocyIsInF1ZXJ5UGF0aHMiLCJsZW5ndGgiLCJqc3giLCJjbGFzc05hbWUiLCJjaGlsZHJlbiIsIm1hcCIsIkxpbmsiLCJocmVmIiwia2V5VG9IcmVmIiwic3BsaXQiLCJwb3AiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkNoaWxkUGFnZXMudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHBsaWNpdC1hbnkgKi9cbmltcG9ydCB7IHVzZUNhbGxiYWNrLCB1c2VDb250ZXh0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgTGluaywgdXNlTWV0YWRhdGFRdWVyeSB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrJztcbmltcG9ydCB7IFRpbmtlcmFibGVDb250ZXh0IH0gZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9zZGsvVGlua2VyYWJsZUNvbnRleHQnO1xuaW1wb3J0IHsgY29udGVudERpciwgaXNDb250ZW50RW50cnksIGtleVRvSHJlZiwgc2FuZGJveFBhdGhUb0tleSB9IGZyb20gJy4uL2xpYi9jb250ZW50JztcbmltcG9ydCB7IG5hbWVzcGFjZU9mLCBxdWVyeVBhdGhzIH0gZnJvbSAnLi4vbGliL3dpa2knO1xuXG4vLyBgPENoaWxkUGFnZXMvPmAg4oCUIHRoZSBlbnRyaWVzIHRoYXQgbGl2ZSB1bmRlciB0aGUgY3VycmVudCBlbnRyeSdzIG5hbWVzcGFjZSwgYXNcbi8vIGEgY29tcGFjdCBuZXN0ZWQgbGlzdCAoZS5nLiBldmVyeXRoaW5nIGluIGBoYW5kYm9vay9gIGZyb20gdGhlIGhhbmRib29rIGluZGV4KS5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIENoaWxkUGFnZXMoKSB7XG4gIGNvbnN0IGN0eCA9IHVzZUNvbnRleHQoVGlua2VyYWJsZUNvbnRleHQpIGFzIGFueTtcbiAgY29uc3QgY3VycmVudEtleSA9IHNhbmRib3hQYXRoVG9LZXkoY3R4Py5uYXZpZ2F0aW9uU3RhdGU/LnNhbmRib3hQYXRoIHx8ICcvJyk7XG4gIGNvbnN0IHJlbCA9IGN1cnJlbnRLZXkucmVwbGFjZShjb250ZW50RGlyKCksICcnKS5yZXBsYWNlKC9cXC5tZHg/JC8sICcnKTtcbiAgLy8gVGhlIGZvbGRlciB0aGlzIGVudHJ5IGluZGV4ZXM6IGl0cyBvd24gc2x1ZyBpZiBpdCdzIGEgc2VjdGlvbiBpbmRleCwgZWxzZSBpdHMgbmFtZXNwYWNlLlxuICBjb25zdCBzY29wZSA9IHJlbC5yZXBsYWNlKC9cXC8/KGluZGV4fGhvbWUpJC8sICcnKTtcblxuICBjb25zdCBxdWVyeUZuID0gdXNlQ2FsbGJhY2soXG4gICAgKGZtOiBSZWNvcmQ8c3RyaW5nLCBhbnk+KSA9PlxuICAgICAgT2JqZWN0LmtleXMoZm0pXG4gICAgICAgIC5maWx0ZXIoKHApID0+IHtcbiAgICAgICAgICBpZiAoIWlzQ29udGVudEVudHJ5KHApIHx8IHAgPT09IGN1cnJlbnRLZXkpIHJldHVybiBmYWxzZTtcbiAgICAgICAgICByZXR1cm4gbmFtZXNwYWNlT2YocCkgPT09IHNjb3BlO1xuICAgICAgICB9KVxuICAgICAgICAuc29ydCgpLFxuICAgIFtjdXJyZW50S2V5LCBzY29wZV1cbiAgKTtcbiAgY29uc3QgcSA9IHVzZU1ldGFkYXRhUXVlcnkocXVlcnlGbik7XG4gIGNvbnN0IHBhdGhzOiBzdHJpbmdbXSA9IHF1ZXJ5UGF0aHMocSk7XG5cbiAgaWYgKCFwYXRocy5sZW5ndGgpIHJldHVybiBudWxsO1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JvdmUtZG9jbGlzdFwiIGRhdGEtc2hhcGU9XCJmZWVkXCI+XG4gICAgICB7cGF0aHMubWFwKChwKSA9PiAoXG4gICAgICAgIDxMaW5rIGtleT17cH0gaHJlZj17a2V5VG9IcmVmKHApfSBjbGFzc05hbWU9XCJnZGwtcm93XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJnZGwtcm93X190XCI+e3AucmVwbGFjZShjb250ZW50RGlyKCksICcnKS5yZXBsYWNlKC9cXC5tZHg/JC8sICcnKS5zcGxpdCgnLycpLnBvcCgpfTwvZGl2PlxuICAgICAgICA8L0xpbms+XG4gICAgICApKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQ0EsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsSUFBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsa0JBQUEsR0FBQUYsT0FBQTtBQUNBLElBQUFHLFFBQUEsR0FBQUgsT0FBQTtBQUNBLElBQUFJLEtBQUEsR0FBQUosT0FBQTtBQUFzRCxJQUFBSyxXQUFBLEdBQUFMLE9BQUE7QUFBQSxJQUFBTSxFQUFBLEdBQUFDLFlBQUE7QUFMdEQ7QUFPQTtBQUNBO0FBQ2UsU0FBU0MsVUFBVUEsQ0FBQSxFQUFHO0VBQUFGLEVBQUE7RUFDbkMsTUFBTUcsR0FBRyxHQUFHLElBQUFDLGlCQUFVLEVBQUNDLG9DQUFpQixDQUFRO0VBQ2hELE1BQU1DLFVBQVUsR0FBRyxJQUFBQyx5QkFBZ0IsRUFBQ0osR0FBRyxFQUFFSyxlQUFlLEVBQUVDLFdBQVcsSUFBSSxHQUFHLENBQUM7RUFDN0UsTUFBTUMsR0FBRyxHQUFHSixVQUFVLENBQUNLLE9BQU8sQ0FBQyxJQUFBQyxtQkFBVSxFQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQ0QsT0FBTyxDQUFDLFNBQVMsRUFBRSxFQUFFLENBQUM7RUFDdkU7RUFDQSxNQUFNRSxLQUFLLEdBQUdILEdBQUcsQ0FBQ0MsT0FBTyxDQUFDLGtCQUFrQixFQUFFLEVBQUUsQ0FBQztFQUVqRCxNQUFNRyxPQUFPLEdBQUcsSUFBQUMsa0JBQVcsRUFDeEJDLEVBQXVCLElBQ3RCQyxNQUFNLENBQUNDLElBQUksQ0FBQ0YsRUFBRSxDQUFDLENBQ1pHLE1BQU0sQ0FBRUMsQ0FBQyxJQUFLO0lBQ2IsSUFBSSxDQUFDLElBQUFDLHVCQUFjLEVBQUNELENBQUMsQ0FBQyxJQUFJQSxDQUFDLEtBQUtkLFVBQVUsRUFBRSxPQUFPLEtBQUs7SUFDeEQsT0FBTyxJQUFBZ0IsaUJBQVcsRUFBQ0YsQ0FBQyxDQUFDLEtBQUtQLEtBQUs7RUFDakMsQ0FBQyxDQUFDLENBQ0RVLElBQUksQ0FBQyxDQUFDLEVBQ1gsQ0FBQ2pCLFVBQVUsRUFBRU8sS0FBSyxDQUNwQixDQUFDO0VBQ0QsTUFBTVcsQ0FBQyxHQUFHLElBQUFDLHFCQUFnQixFQUFDWCxPQUFPLENBQUM7RUFDbkMsTUFBTVksS0FBZSxHQUFHLElBQUFDLGdCQUFVLEVBQUNILENBQUMsQ0FBQztFQUVyQyxJQUFJLENBQUNFLEtBQUssQ0FBQ0UsTUFBTSxFQUFFLE9BQU8sSUFBSTtFQUM5QixvQkFDRSxJQUFBN0IsV0FBQSxDQUFBOEIsR0FBQTtJQUFLQyxTQUFTLEVBQUMsZUFBZTtJQUFDLGNBQVcsTUFBTTtJQUFBQyxRQUFBLEVBQzdDTCxLQUFLLENBQUNNLEdBQUcsQ0FBRVosQ0FBQyxpQkFDWCxJQUFBckIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDbEMsSUFBQSxDQUFBc0MsSUFBSTtNQUFTQyxJQUFJLEVBQUUsSUFBQUMsa0JBQVMsRUFBQ2YsQ0FBQyxDQUFFO01BQUNVLFNBQVMsRUFBQyxTQUFTO01BQUFDLFFBQUEsZUFDbkQsSUFBQWhDLFdBQUEsQ0FBQThCLEdBQUE7UUFBS0MsU0FBUyxFQUFDLFlBQVk7UUFBQUMsUUFBQSxFQUFFWCxDQUFDLENBQUNULE9BQU8sQ0FBQyxJQUFBQyxtQkFBVSxFQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQ0QsT0FBTyxDQUFDLFNBQVMsRUFBRSxFQUFFLENBQUMsQ0FBQ3lCLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQ0MsR0FBRyxDQUFDO01BQUMsQ0FBTTtJQUFDLEdBRDlGakIsQ0FFTCxDQUNQO0VBQUMsQ0FDQyxDQUFDO0FBRVY7QUFBQ3BCLEVBQUEsQ0E5QnVCRSxVQUFVO0VBQUEsUUFpQnRCdUIscUJBQWdCO0FBQUE7QUFBQWEsRUFBQSxHQWpCSnBDLFVBQVU7QUFBQSxJQUFBb0MsRUFBQTtBQUFBQyxZQUFBLENBQUFELEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}