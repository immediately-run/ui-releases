var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Backlinks;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.map.js");
var _react = require("react");
var _fs = _interopRequireDefault(require("fs"));
var _sdk = require("@immediately-run/sdk");
var _TinkerableContext = require("@immediately-run/sdk/TinkerableContext");
var _content = require("../lib/content");
var _wiki = require("../lib/wiki");
var _InlineProse = _interopRequireDefault(require("./InlineProse"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(),
  _s2 = $RefreshSig$();
/* eslint-disable @typescript-eslint/no-explicit-any */
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// One linking entry: title + namespace crumb + the snippet around the link.
function Row({
  hit
}) {
  _s();
  const meta = (0, _sdk.useFileMetadata)(hit.key);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_sdk.Link, {
    href: (0, _content.keyToHref)(hit.key),
    className: "grove-bl",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "grove-bl__t",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_InlineProse.default, {
        text: meta?.title || (0, _wiki.crumb)(hit.key),
        trimPeriod: true
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
        className: "crumb",
        children: ["/", (0, _wiki.crumb)(hit.key)]
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "grove-bl__snip",
      dangerouslySetInnerHTML: {
        __html: hit.snippet
      }
    })]
  });
}

// `<Backlinks/>` — the signature wiki affordance: who links here. Reads sibling
// entry bodies off the fs and scans for a link to the current entry.
_s(Row, "HCQWmXfXYtrNQZ9MFtiZso5O/l0=", false, function () {
  return [_sdk.useFileMetadata];
});
_c = Row;
function Backlinks() {
  _s2();
  const ctx = (0, _react.useContext)(_TinkerableContext.TinkerableContext);
  const currentKey = (0, _content.sandboxPathToKey)(ctx?.navigationState?.sandboxPath || '/');
  const allKeys = (0, _react.useCallback)(fm => Object.keys(fm).filter(_content.isContentEntry), []);
  const q = (0, _sdk.useMetadataQuery)(allKeys);
  const keys = (0, _wiki.queryPaths)(q);
  const keysKey = keys.join('|');
  const [hits, setHits] = (0, _react.useState)(null);
  (0, _react.useEffect)(() => {
    let active = true;
    if (!keys.length) return; // index not loaded yet → keep the skeleton
    const others = keys.filter(k => k !== currentKey);
    Promise.all(others.map(k => _fs.default.promises.readFile((0, _content.keyToFsPath)(k), 'utf8').then(body => ({
      key: k,
      body: String(body)
    })).catch(() => null))).then(rows => {
      if (!active) return;
      const found = [];
      for (const r of rows) {
        // R3-283: the linking entry's own key is part of the question — corpus links
        // are RELATIVE to the file they are written in, so `r.key` is what resolves them.
        if (r && (0, _wiki.bodyLinksTo)(r.body, currentKey, r.key)) {
          found.push({
            key: r.key,
            snippet: (0, _wiki.backlinkSnippet)(r.body, currentKey, r.key)
          });
        }
      }
      setHits(found.sort((a, b) => a.key < b.key ? -1 : 1));
    });
    return () => {
      active = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentKey, keysKey]);

  // Skeleton while the bodies resolve.
  if (hits === null) {
    return /*#__PURE__*/(0, _jsxRuntime.jsxs)("section", {
      className: "grove-backlinks",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "grove-backlinks__h",
        children: "Backlinks"
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "grove-backlinks__list",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
          className: "sk sk-line",
          style: {
            width: '60%'
          }
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
          className: "sk sk-line",
          style: {
            width: '40%'
          }
        })]
      })]
    });
  }
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("section", {
    className: "grove-backlinks",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("h2", {
      className: "grove-backlinks__h",
      children: ["Linked from", /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
        className: "n",
        children: [hits.length, " ", hits.length === 1 ? 'entry' : 'entries']
      })]
    }), hits.length ? /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "grove-backlinks__list",
      children: hits.map(h => /*#__PURE__*/(0, _jsxRuntime.jsx)(Row, {
        hit: h
      }, h.key))
    }) : /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
      className: "grove-bl__snip",
      children: "Nothing links here yet."
    })]
  });
}
_s2(Backlinks, "GprOVkTQaBSH6Ew9uGUgxO56jws=", false, function () {
  return [_sdk.useMetadataQuery];
});
_c2 = Backlinks;
var _c, _c2;
$RefreshReg$(_c, "Row");
$RefreshReg$(_c2, "Backlinks");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX2ZzIiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsIl9zZGsiLCJfVGlua2VyYWJsZUNvbnRleHQiLCJfY29udGVudCIsIl93aWtpIiwiX0lubGluZVByb3NlIiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsIl9zMiIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsIlJvdyIsImhpdCIsIm1ldGEiLCJ1c2VGaWxlTWV0YWRhdGEiLCJrZXkiLCJqc3hzIiwiTGluayIsImhyZWYiLCJrZXlUb0hyZWYiLCJjbGFzc05hbWUiLCJjaGlsZHJlbiIsImpzeCIsInRleHQiLCJ0aXRsZSIsImNydW1iIiwidHJpbVBlcmlvZCIsImRhbmdlcm91c2x5U2V0SW5uZXJIVE1MIiwiX19odG1sIiwic25pcHBldCIsIl9jIiwiQmFja2xpbmtzIiwiY3R4IiwidXNlQ29udGV4dCIsIlRpbmtlcmFibGVDb250ZXh0IiwiY3VycmVudEtleSIsInNhbmRib3hQYXRoVG9LZXkiLCJuYXZpZ2F0aW9uU3RhdGUiLCJzYW5kYm94UGF0aCIsImFsbEtleXMiLCJ1c2VDYWxsYmFjayIsImZtIiwiT2JqZWN0Iiwia2V5cyIsImZpbHRlciIsImlzQ29udGVudEVudHJ5IiwicSIsInVzZU1ldGFkYXRhUXVlcnkiLCJxdWVyeVBhdGhzIiwia2V5c0tleSIsImpvaW4iLCJoaXRzIiwic2V0SGl0cyIsInVzZVN0YXRlIiwidXNlRWZmZWN0IiwiYWN0aXZlIiwibGVuZ3RoIiwib3RoZXJzIiwiayIsIlByb21pc2UiLCJhbGwiLCJtYXAiLCJmcyIsInByb21pc2VzIiwicmVhZEZpbGUiLCJrZXlUb0ZzUGF0aCIsInRoZW4iLCJib2R5IiwiU3RyaW5nIiwiY2F0Y2giLCJyb3dzIiwiZm91bmQiLCJyIiwiYm9keUxpbmtzVG8iLCJwdXNoIiwiYmFja2xpbmtTbmlwcGV0Iiwic29ydCIsImEiLCJiIiwic3R5bGUiLCJ3aWR0aCIsImgiLCJfYzIiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJCYWNrbGlua3MudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHBsaWNpdC1hbnkgKi9cbmltcG9ydCB7IHVzZUNhbGxiYWNrLCB1c2VDb250ZXh0LCB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IGZzIGZyb20gJ2ZzJztcbmltcG9ydCB7IExpbmssIHVzZUZpbGVNZXRhZGF0YSwgdXNlTWV0YWRhdGFRdWVyeSB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrJztcbmltcG9ydCB7IFRpbmtlcmFibGVDb250ZXh0IH0gZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9zZGsvVGlua2VyYWJsZUNvbnRleHQnO1xuaW1wb3J0IHsgaXNDb250ZW50RW50cnksIGtleVRvRnNQYXRoLCBrZXlUb0hyZWYsIHNhbmRib3hQYXRoVG9LZXkgfSBmcm9tICcuLi9saWIvY29udGVudCc7XG5pbXBvcnQgeyBiYWNrbGlua1NuaXBwZXQsIGJvZHlMaW5rc1RvLCBjcnVtYiwgcXVlcnlQYXRocyB9IGZyb20gJy4uL2xpYi93aWtpJztcbmltcG9ydCBJbmxpbmVQcm9zZSBmcm9tICcuL0lubGluZVByb3NlJztcblxuaW50ZXJmYWNlIEhpdCB7XG4gIGtleTogc3RyaW5nO1xuICBzbmlwcGV0OiBzdHJpbmc7XG59XG5cbi8vIE9uZSBsaW5raW5nIGVudHJ5OiB0aXRsZSArIG5hbWVzcGFjZSBjcnVtYiArIHRoZSBzbmlwcGV0IGFyb3VuZCB0aGUgbGluay5cbmZ1bmN0aW9uIFJvdyh7IGhpdCB9OiB7IGhpdDogSGl0IH0pIHtcbiAgY29uc3QgbWV0YSA9IHVzZUZpbGVNZXRhZGF0YShoaXQua2V5KSBhcyBhbnk7XG4gIHJldHVybiAoXG4gICAgPExpbmsgaHJlZj17a2V5VG9IcmVmKGhpdC5rZXkpfSBjbGFzc05hbWU9XCJncm92ZS1ibFwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncm92ZS1ibF9fdFwiPlxuICAgICAgICA8SW5saW5lUHJvc2UgdGV4dD17bWV0YT8udGl0bGUgfHwgY3J1bWIoaGl0LmtleSl9IHRyaW1QZXJpb2QgLz5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY3J1bWJcIj4ve2NydW1iKGhpdC5rZXkpfTwvc3Bhbj5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncm92ZS1ibF9fc25pcFwiIGRhbmdlcm91c2x5U2V0SW5uZXJIVE1MPXt7IF9faHRtbDogaGl0LnNuaXBwZXQgfX0gLz5cbiAgICA8L0xpbms+XG4gICk7XG59XG5cbi8vIGA8QmFja2xpbmtzLz5gIOKAlCB0aGUgc2lnbmF0dXJlIHdpa2kgYWZmb3JkYW5jZTogd2hvIGxpbmtzIGhlcmUuIFJlYWRzIHNpYmxpbmdcbi8vIGVudHJ5IGJvZGllcyBvZmYgdGhlIGZzIGFuZCBzY2FucyBmb3IgYSBsaW5rIHRvIHRoZSBjdXJyZW50IGVudHJ5LlxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQmFja2xpbmtzKCkge1xuICBjb25zdCBjdHggPSB1c2VDb250ZXh0KFRpbmtlcmFibGVDb250ZXh0KSBhcyBhbnk7XG4gIGNvbnN0IGN1cnJlbnRLZXkgPSBzYW5kYm94UGF0aFRvS2V5KGN0eD8ubmF2aWdhdGlvblN0YXRlPy5zYW5kYm94UGF0aCB8fCAnLycpO1xuXG4gIGNvbnN0IGFsbEtleXMgPSB1c2VDYWxsYmFjayhcbiAgICAoZm06IFJlY29yZDxzdHJpbmcsIGFueT4pID0+IE9iamVjdC5rZXlzKGZtKS5maWx0ZXIoaXNDb250ZW50RW50cnkpLFxuICAgIFtdXG4gICk7XG4gIGNvbnN0IHEgPSB1c2VNZXRhZGF0YVF1ZXJ5KGFsbEtleXMpO1xuICBjb25zdCBrZXlzOiBzdHJpbmdbXSA9IHF1ZXJ5UGF0aHMocSk7XG4gIGNvbnN0IGtleXNLZXkgPSBrZXlzLmpvaW4oJ3wnKTtcblxuICBjb25zdCBbaGl0cywgc2V0SGl0c10gPSB1c2VTdGF0ZTxIaXRbXSB8IG51bGw+KG51bGwpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgbGV0IGFjdGl2ZSA9IHRydWU7XG4gICAgaWYgKCFrZXlzLmxlbmd0aCkgcmV0dXJuOyAvLyBpbmRleCBub3QgbG9hZGVkIHlldCDihpIga2VlcCB0aGUgc2tlbGV0b25cbiAgICBjb25zdCBvdGhlcnMgPSBrZXlzLmZpbHRlcigoaykgPT4gayAhPT0gY3VycmVudEtleSk7XG4gICAgUHJvbWlzZS5hbGwoXG4gICAgICBvdGhlcnMubWFwKChrKSA9PlxuICAgICAgICBmcy5wcm9taXNlc1xuICAgICAgICAgIC5yZWFkRmlsZShrZXlUb0ZzUGF0aChrKSwgJ3V0ZjgnKVxuICAgICAgICAgIC50aGVuKChib2R5OiB1bmtub3duKSA9PiAoeyBrZXk6IGssIGJvZHk6IFN0cmluZyhib2R5KSB9KSlcbiAgICAgICAgICAuY2F0Y2goKCkgPT4gbnVsbClcbiAgICAgIClcbiAgICApLnRoZW4oKHJvd3MpID0+IHtcbiAgICAgIGlmICghYWN0aXZlKSByZXR1cm47XG4gICAgICBjb25zdCBmb3VuZDogSGl0W10gPSBbXTtcbiAgICAgIGZvciAoY29uc3QgciBvZiByb3dzKSB7XG4gICAgICAgIC8vIFIzLTI4MzogdGhlIGxpbmtpbmcgZW50cnkncyBvd24ga2V5IGlzIHBhcnQgb2YgdGhlIHF1ZXN0aW9uIOKAlCBjb3JwdXMgbGlua3NcbiAgICAgICAgLy8gYXJlIFJFTEFUSVZFIHRvIHRoZSBmaWxlIHRoZXkgYXJlIHdyaXR0ZW4gaW4sIHNvIGByLmtleWAgaXMgd2hhdCByZXNvbHZlcyB0aGVtLlxuICAgICAgICBpZiAociAmJiBib2R5TGlua3NUbyhyLmJvZHksIGN1cnJlbnRLZXksIHIua2V5KSkge1xuICAgICAgICAgIGZvdW5kLnB1c2goeyBrZXk6IHIua2V5LCBzbmlwcGV0OiBiYWNrbGlua1NuaXBwZXQoci5ib2R5LCBjdXJyZW50S2V5LCByLmtleSkgfSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHNldEhpdHMoZm91bmQuc29ydCgoYSwgYikgPT4gKGEua2V5IDwgYi5rZXkgPyAtMSA6IDEpKSk7XG4gICAgfSk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGFjdGl2ZSA9IGZhbHNlO1xuICAgIH07XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWhvb2tzL2V4aGF1c3RpdmUtZGVwc1xuICB9LCBbY3VycmVudEtleSwga2V5c0tleV0pO1xuXG4gIC8vIFNrZWxldG9uIHdoaWxlIHRoZSBib2RpZXMgcmVzb2x2ZS5cbiAgaWYgKGhpdHMgPT09IG51bGwpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiZ3JvdmUtYmFja2xpbmtzXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JvdmUtYmFja2xpbmtzX19oXCI+QmFja2xpbmtzPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JvdmUtYmFja2xpbmtzX19saXN0XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzayBzay1saW5lXCIgc3R5bGU9e3sgd2lkdGg6ICc2MCUnIH19IC8+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzayBzay1saW5lXCIgc3R5bGU9e3sgd2lkdGg6ICc0MCUnIH19IC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9zZWN0aW9uPlxuICAgICk7XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImdyb3ZlLWJhY2tsaW5rc1wiPlxuICAgICAgPGgyIGNsYXNzTmFtZT1cImdyb3ZlLWJhY2tsaW5rc19faFwiPlxuICAgICAgICBMaW5rZWQgZnJvbVxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJuXCI+e2hpdHMubGVuZ3RofSB7aGl0cy5sZW5ndGggPT09IDEgPyAnZW50cnknIDogJ2VudHJpZXMnfTwvc3Bhbj5cbiAgICAgIDwvaDI+XG4gICAgICB7aGl0cy5sZW5ndGggPyAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JvdmUtYmFja2xpbmtzX19saXN0XCI+XG4gICAgICAgICAge2hpdHMubWFwKChoKSA9PiAoXG4gICAgICAgICAgICA8Um93IGtleT17aC5rZXl9IGhpdD17aH0gLz5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICApIDogKFxuICAgICAgICA8cCBjbGFzc05hbWU9XCJncm92ZS1ibF9fc25pcFwiPk5vdGhpbmcgbGlua3MgaGVyZSB5ZXQuPC9wPlxuICAgICAgKX1cbiAgICA8L3NlY3Rpb24+XG4gICk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUNBLElBQUFBLE1BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLEdBQUEsR0FBQUMsc0JBQUEsQ0FBQUYsT0FBQTtBQUNBLElBQUFHLElBQUEsR0FBQUgsT0FBQTtBQUNBLElBQUFJLGtCQUFBLEdBQUFKLE9BQUE7QUFDQSxJQUFBSyxRQUFBLEdBQUFMLE9BQUE7QUFDQSxJQUFBTSxLQUFBLEdBQUFOLE9BQUE7QUFDQSxJQUFBTyxZQUFBLEdBQUFMLHNCQUFBLENBQUFGLE9BQUE7QUFBd0MsSUFBQVEsV0FBQSxHQUFBUixPQUFBO0FBQUEsSUFBQVMsRUFBQSxHQUFBQyxZQUFBO0VBQUFDLEdBQUEsR0FBQUQsWUFBQTtBQVB4QztBQUFBLFNBQUFSLHVCQUFBVSxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBY0E7QUFDQSxTQUFTRyxHQUFHQSxDQUFDO0VBQUVDO0FBQWtCLENBQUMsRUFBRTtFQUFBUCxFQUFBO0VBQ2xDLE1BQU1RLElBQUksR0FBRyxJQUFBQyxvQkFBZSxFQUFDRixHQUFHLENBQUNHLEdBQUcsQ0FBUTtFQUM1QyxvQkFDRSxJQUFBWCxXQUFBLENBQUFZLElBQUEsRUFBQ2pCLElBQUEsQ0FBQWtCLElBQUk7SUFBQ0MsSUFBSSxFQUFFLElBQUFDLGtCQUFTLEVBQUNQLEdBQUcsQ0FBQ0csR0FBRyxDQUFFO0lBQUNLLFNBQVMsRUFBQyxVQUFVO0lBQUFDLFFBQUEsZ0JBQ2xELElBQUFqQixXQUFBLENBQUFZLElBQUE7TUFBS0ksU0FBUyxFQUFDLGFBQWE7TUFBQUMsUUFBQSxnQkFDMUIsSUFBQWpCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ25CLFlBQUEsQ0FBQU8sT0FBVztRQUFDYSxJQUFJLEVBQUVWLElBQUksRUFBRVcsS0FBSyxJQUFJLElBQUFDLFdBQUssRUFBQ2IsR0FBRyxDQUFDRyxHQUFHLENBQUU7UUFBQ1csVUFBVTtNQUFBLENBQUUsQ0FBQyxlQUMvRCxJQUFBdEIsV0FBQSxDQUFBWSxJQUFBO1FBQU1JLFNBQVMsRUFBQyxPQUFPO1FBQUFDLFFBQUEsR0FBQyxHQUFDLEVBQUMsSUFBQUksV0FBSyxFQUFDYixHQUFHLENBQUNHLEdBQUcsQ0FBQztNQUFBLENBQU8sQ0FBQztJQUFBLENBQzdDLENBQUMsZUFDTixJQUFBWCxXQUFBLENBQUFrQixHQUFBO01BQUtGLFNBQVMsRUFBQyxnQkFBZ0I7TUFBQ08sdUJBQXVCLEVBQUU7UUFBRUMsTUFBTSxFQUFFaEIsR0FBRyxDQUFDaUI7TUFBUTtJQUFFLENBQUUsQ0FBQztFQUFBLENBQ2hGLENBQUM7QUFFWDs7QUFFQTtBQUNBO0FBQUF4QixFQUFBLENBZFNNLEdBQUc7RUFBQSxRQUNHRyxvQkFBZTtBQUFBO0FBQUFnQixFQUFBLEdBRHJCbkIsR0FBRztBQWVHLFNBQVNvQixTQUFTQSxDQUFBLEVBQUc7RUFBQXhCLEdBQUE7RUFDbEMsTUFBTXlCLEdBQUcsR0FBRyxJQUFBQyxpQkFBVSxFQUFDQyxvQ0FBaUIsQ0FBUTtFQUNoRCxNQUFNQyxVQUFVLEdBQUcsSUFBQUMseUJBQWdCLEVBQUNKLEdBQUcsRUFBRUssZUFBZSxFQUFFQyxXQUFXLElBQUksR0FBRyxDQUFDO0VBRTdFLE1BQU1DLE9BQU8sR0FBRyxJQUFBQyxrQkFBVyxFQUN4QkMsRUFBdUIsSUFBS0MsTUFBTSxDQUFDQyxJQUFJLENBQUNGLEVBQUUsQ0FBQyxDQUFDRyxNQUFNLENBQUNDLHVCQUFjLENBQUMsRUFDbkUsRUFDRixDQUFDO0VBQ0QsTUFBTUMsQ0FBQyxHQUFHLElBQUFDLHFCQUFnQixFQUFDUixPQUFPLENBQUM7RUFDbkMsTUFBTUksSUFBYyxHQUFHLElBQUFLLGdCQUFVLEVBQUNGLENBQUMsQ0FBQztFQUNwQyxNQUFNRyxPQUFPLEdBQUdOLElBQUksQ0FBQ08sSUFBSSxDQUFDLEdBQUcsQ0FBQztFQUU5QixNQUFNLENBQUNDLElBQUksRUFBRUMsT0FBTyxDQUFDLEdBQUcsSUFBQUMsZUFBUSxFQUFlLElBQUksQ0FBQztFQUVwRCxJQUFBQyxnQkFBUyxFQUFDLE1BQU07SUFDZCxJQUFJQyxNQUFNLEdBQUcsSUFBSTtJQUNqQixJQUFJLENBQUNaLElBQUksQ0FBQ2EsTUFBTSxFQUFFLE9BQU8sQ0FBQztJQUMxQixNQUFNQyxNQUFNLEdBQUdkLElBQUksQ0FBQ0MsTUFBTSxDQUFFYyxDQUFDLElBQUtBLENBQUMsS0FBS3ZCLFVBQVUsQ0FBQztJQUNuRHdCLE9BQU8sQ0FBQ0MsR0FBRyxDQUNUSCxNQUFNLENBQUNJLEdBQUcsQ0FBRUgsQ0FBQyxJQUNYSSxXQUFFLENBQUNDLFFBQVEsQ0FDUkMsUUFBUSxDQUFDLElBQUFDLG9CQUFXLEVBQUNQLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUNoQ1EsSUFBSSxDQUFFQyxJQUFhLEtBQU07TUFBRXBELEdBQUcsRUFBRTJDLENBQUM7TUFBRVMsSUFBSSxFQUFFQyxNQUFNLENBQUNELElBQUk7SUFBRSxDQUFDLENBQUMsQ0FBQyxDQUN6REUsS0FBSyxDQUFDLE1BQU0sSUFBSSxDQUNyQixDQUNGLENBQUMsQ0FBQ0gsSUFBSSxDQUFFSSxJQUFJLElBQUs7TUFDZixJQUFJLENBQUNmLE1BQU0sRUFBRTtNQUNiLE1BQU1nQixLQUFZLEdBQUcsRUFBRTtNQUN2QixLQUFLLE1BQU1DLENBQUMsSUFBSUYsSUFBSSxFQUFFO1FBQ3BCO1FBQ0E7UUFDQSxJQUFJRSxDQUFDLElBQUksSUFBQUMsaUJBQVcsRUFBQ0QsQ0FBQyxDQUFDTCxJQUFJLEVBQUVoQyxVQUFVLEVBQUVxQyxDQUFDLENBQUN6RCxHQUFHLENBQUMsRUFBRTtVQUMvQ3dELEtBQUssQ0FBQ0csSUFBSSxDQUFDO1lBQUUzRCxHQUFHLEVBQUV5RCxDQUFDLENBQUN6RCxHQUFHO1lBQUVjLE9BQU8sRUFBRSxJQUFBOEMscUJBQWUsRUFBQ0gsQ0FBQyxDQUFDTCxJQUFJLEVBQUVoQyxVQUFVLEVBQUVxQyxDQUFDLENBQUN6RCxHQUFHO1VBQUUsQ0FBQyxDQUFDO1FBQ2pGO01BQ0Y7TUFDQXFDLE9BQU8sQ0FBQ21CLEtBQUssQ0FBQ0ssSUFBSSxDQUFDLENBQUNDLENBQUMsRUFBRUMsQ0FBQyxLQUFNRCxDQUFDLENBQUM5RCxHQUFHLEdBQUcrRCxDQUFDLENBQUMvRCxHQUFHLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBRSxDQUFDLENBQUM7SUFDekQsQ0FBQyxDQUFDO0lBQ0YsT0FBTyxNQUFNO01BQ1h3QyxNQUFNLEdBQUcsS0FBSztJQUNoQixDQUFDO0lBQ0Q7RUFDRixDQUFDLEVBQUUsQ0FBQ3BCLFVBQVUsRUFBRWMsT0FBTyxDQUFDLENBQUM7O0VBRXpCO0VBQ0EsSUFBSUUsSUFBSSxLQUFLLElBQUksRUFBRTtJQUNqQixvQkFDRSxJQUFBL0MsV0FBQSxDQUFBWSxJQUFBO01BQVNJLFNBQVMsRUFBQyxpQkFBaUI7TUFBQUMsUUFBQSxnQkFDbEMsSUFBQWpCLFdBQUEsQ0FBQWtCLEdBQUE7UUFBS0YsU0FBUyxFQUFDLG9CQUFvQjtRQUFBQyxRQUFBLEVBQUM7TUFBUyxDQUFLLENBQUMsZUFDbkQsSUFBQWpCLFdBQUEsQ0FBQVksSUFBQTtRQUFLSSxTQUFTLEVBQUMsdUJBQXVCO1FBQUFDLFFBQUEsZ0JBQ3BDLElBQUFqQixXQUFBLENBQUFrQixHQUFBO1VBQUtGLFNBQVMsRUFBQyxZQUFZO1VBQUMyRCxLQUFLLEVBQUU7WUFBRUMsS0FBSyxFQUFFO1VBQU07UUFBRSxDQUFFLENBQUMsZUFDdkQsSUFBQTVFLFdBQUEsQ0FBQWtCLEdBQUE7VUFBS0YsU0FBUyxFQUFDLFlBQVk7VUFBQzJELEtBQUssRUFBRTtZQUFFQyxLQUFLLEVBQUU7VUFBTTtRQUFFLENBQUUsQ0FBQztNQUFBLENBQ3BELENBQUM7SUFBQSxDQUNDLENBQUM7RUFFZDtFQUVBLG9CQUNFLElBQUE1RSxXQUFBLENBQUFZLElBQUE7SUFBU0ksU0FBUyxFQUFDLGlCQUFpQjtJQUFBQyxRQUFBLGdCQUNsQyxJQUFBakIsV0FBQSxDQUFBWSxJQUFBO01BQUlJLFNBQVMsRUFBQyxvQkFBb0I7TUFBQUMsUUFBQSxHQUFDLGFBRWpDLG1CQUFBakIsV0FBQSxDQUFBWSxJQUFBO1FBQU1JLFNBQVMsRUFBQyxHQUFHO1FBQUFDLFFBQUEsR0FBRThCLElBQUksQ0FBQ0ssTUFBTSxFQUFDLEdBQUMsRUFBQ0wsSUFBSSxDQUFDSyxNQUFNLEtBQUssQ0FBQyxHQUFHLE9BQU8sR0FBRyxTQUFTO01BQUEsQ0FBTyxDQUFDO0lBQUEsQ0FDaEYsQ0FBQyxFQUNKTCxJQUFJLENBQUNLLE1BQU0sZ0JBQ1YsSUFBQXBELFdBQUEsQ0FBQWtCLEdBQUE7TUFBS0YsU0FBUyxFQUFDLHVCQUF1QjtNQUFBQyxRQUFBLEVBQ25DOEIsSUFBSSxDQUFDVSxHQUFHLENBQUVvQixDQUFDLGlCQUNWLElBQUE3RSxXQUFBLENBQUFrQixHQUFBLEVBQUNYLEdBQUc7UUFBYUMsR0FBRyxFQUFFcUU7TUFBRSxHQUFkQSxDQUFDLENBQUNsRSxHQUFjLENBQzNCO0lBQUMsQ0FDQyxDQUFDLGdCQUVOLElBQUFYLFdBQUEsQ0FBQWtCLEdBQUE7TUFBR0YsU0FBUyxFQUFDLGdCQUFnQjtNQUFBQyxRQUFBLEVBQUM7SUFBdUIsQ0FBRyxDQUN6RDtFQUFBLENBQ00sQ0FBQztBQUVkO0FBQUNkLEdBQUEsQ0F6RXVCd0IsU0FBUztFQUFBLFFBUXJCZ0IscUJBQWdCO0FBQUE7QUFBQW1DLEdBQUEsR0FSSm5ELFNBQVM7QUFBQSxJQUFBRCxFQUFBLEVBQUFvRCxHQUFBO0FBQUFDLFlBQUEsQ0FBQXJELEVBQUE7QUFBQXFELFlBQUEsQ0FBQUQsR0FBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}