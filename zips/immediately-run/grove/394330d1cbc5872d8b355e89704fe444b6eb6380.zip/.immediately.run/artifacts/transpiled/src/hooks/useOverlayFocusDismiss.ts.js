"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useOverlayFocusDismiss = useOverlayFocusDismiss;
var _react = require("react");
// The dialog/menu contract for Grove's overlays (R3-608, R-IX-1): focus moves
// IN on open, Tab is trapped while open (unless the surface is a menu — menus
// do not trap Tab), Escape closes only the TOP of a module-level stack, and
// focus RETURNS to the element that opened the overlay. The stack exists
// because the surfaces overlap (GroveNav's own comment names drawer, search
// and theme menu as shared interactive state): one Escape closes one overlay.

/** Elements that can hold focus inside the overlay. */
const FOCUSABLE = 'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])';

/** The open-overlay stack, newest last. Only the top entry answers Escape —
 *  a nested pair closes one per key, never both at once. */
const stack = [];
/**
 * Wire the contract to an overlay root. Attach the returned ref to the element
 * that bounds the overlay (its panel/menu box).
 *
 * @param open    the overlay's open state — the effect arms on true and cleans
 *                up (returning focus) on false/unmount.
 * @param onClose Escape's meaning: close without committing.
 */
function useOverlayFocusDismiss(open, onClose, opts = {}) {
  const rootRef = (0, _react.useRef)(null);
  // The latest close callback, kept current in an effect (never a render-time
  // ref write — the react-hooks compiler forbids it, correctly).
  const onCloseRef = (0, _react.useRef)(onClose);
  (0, _react.useEffect)(() => {
    onCloseRef.current = onClose;
  });
  const trapTab = opts.trapTab !== false;
  (0, _react.useEffect)(() => {
    if (!open) return;
    // The trigger to return to, captured BEFORE focus moves in.
    const trigger = document.activeElement;
    const entry = {
      close: () => onCloseRef.current()
    };
    stack.push(entry);
    // Set when a MENU surface closes because Tab left it: the browser's own
    // focus move must stand (APG Menu Button), so the cleanup below must NOT
    // yank focus back to the trigger.
    let closedViaTab = false;
    const root = rootRef.current;
    const focusables = root ? [...root.querySelectorAll(FOCUSABLE)] : [];
    // Focus IN: the first control; a panel with no focusable content takes
    // focus itself so Escape has a home.
    (focusables[0] ?? root)?.focus();
    const onKeyDown = e => {
      const isTop = stack[stack.length - 1] === entry;
      if (e.key === 'Escape') {
        if (!isTop) return; // a nested overlay above owns this key
        e.preventDefault();
        e.stopPropagation();
        onCloseRef.current();
        return;
      }
      if (!trapTab && e.key === 'Tab') {
        // APG Menu: Tab is LEAVE — the focus move proceeds (no preventDefault)
        // and the menu closes behind it, never stranded over a scrim. The
        // flag keeps the cleanup from pulling focus back to the trigger: the
        // move the browser just made is the contract.
        if (isTop) {
          closedViaTab = true;
          onCloseRef.current();
        }
        return;
      }
      if (!trapTab || e.key !== 'Tab' || !root) return;
      const list = [...root.querySelectorAll(FOCUSABLE)].filter(el => !el.hasAttribute('disabled'));
      if (!list.length) {
        e.preventDefault();
        return;
      }
      const first = list[0];
      const last = list[list.length - 1];
      const active = document.activeElement;
      if (!root.contains(active)) {
        e.preventDefault();
        first.focus();
      } else if (e.shiftKey && active === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && active === last) {
        e.preventDefault();
        first.focus();
      }
    };
    // Capture phase: the contract runs before any app-level key handling.
    document.addEventListener('keydown', onKeyDown, true);
    return () => {
      document.removeEventListener('keydown', onKeyDown, true);
      const i = stack.indexOf(entry);
      if (i >= 0) stack.splice(i, 1);
      // Focus RETURNS to the trigger (R-IX-1) — unless the menu closed BECAUSE
      // Tab left it: that move is the contract and stands. Guarded: the
      // trigger may be gone.
      if (!closedViaTab && trigger && document.contains(trigger)) trigger.focus();
    };
  }, [open, trapTab]);
  return rootRef;
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiRk9DVVNBQkxFIiwic3RhY2siLCJ1c2VPdmVybGF5Rm9jdXNEaXNtaXNzIiwib3BlbiIsIm9uQ2xvc2UiLCJvcHRzIiwicm9vdFJlZiIsInVzZVJlZiIsIm9uQ2xvc2VSZWYiLCJ1c2VFZmZlY3QiLCJjdXJyZW50IiwidHJhcFRhYiIsInRyaWdnZXIiLCJkb2N1bWVudCIsImFjdGl2ZUVsZW1lbnQiLCJlbnRyeSIsImNsb3NlIiwicHVzaCIsImNsb3NlZFZpYVRhYiIsInJvb3QiLCJmb2N1c2FibGVzIiwicXVlcnlTZWxlY3RvckFsbCIsImZvY3VzIiwib25LZXlEb3duIiwiZSIsImlzVG9wIiwibGVuZ3RoIiwia2V5IiwicHJldmVudERlZmF1bHQiLCJzdG9wUHJvcGFnYXRpb24iLCJsaXN0IiwiZmlsdGVyIiwiZWwiLCJoYXNBdHRyaWJ1dGUiLCJmaXJzdCIsImxhc3QiLCJhY3RpdmUiLCJjb250YWlucyIsInNoaWZ0S2V5IiwiYWRkRXZlbnRMaXN0ZW5lciIsInJlbW92ZUV2ZW50TGlzdGVuZXIiLCJpIiwiaW5kZXhPZiIsInNwbGljZSJdLCJzb3VyY2VzIjpbInVzZU92ZXJsYXlGb2N1c0Rpc21pc3MudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gVGhlIGRpYWxvZy9tZW51IGNvbnRyYWN0IGZvciBHcm92ZSdzIG92ZXJsYXlzIChSMy02MDgsIFItSVgtMSk6IGZvY3VzIG1vdmVzXG4vLyBJTiBvbiBvcGVuLCBUYWIgaXMgdHJhcHBlZCB3aGlsZSBvcGVuICh1bmxlc3MgdGhlIHN1cmZhY2UgaXMgYSBtZW51IOKAlCBtZW51c1xuLy8gZG8gbm90IHRyYXAgVGFiKSwgRXNjYXBlIGNsb3NlcyBvbmx5IHRoZSBUT1Agb2YgYSBtb2R1bGUtbGV2ZWwgc3RhY2ssIGFuZFxuLy8gZm9jdXMgUkVUVVJOUyB0byB0aGUgZWxlbWVudCB0aGF0IG9wZW5lZCB0aGUgb3ZlcmxheS4gVGhlIHN0YWNrIGV4aXN0c1xuLy8gYmVjYXVzZSB0aGUgc3VyZmFjZXMgb3ZlcmxhcCAoR3JvdmVOYXYncyBvd24gY29tbWVudCBuYW1lcyBkcmF3ZXIsIHNlYXJjaFxuLy8gYW5kIHRoZW1lIG1lbnUgYXMgc2hhcmVkIGludGVyYWN0aXZlIHN0YXRlKTogb25lIEVzY2FwZSBjbG9zZXMgb25lIG92ZXJsYXkuXG5cbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlUmVmIH0gZnJvbSAncmVhY3QnO1xuXG4vKiogRWxlbWVudHMgdGhhdCBjYW4gaG9sZCBmb2N1cyBpbnNpZGUgdGhlIG92ZXJsYXkuICovXG5jb25zdCBGT0NVU0FCTEUgPVxuICAnYVtocmVmXSwgYnV0dG9uOm5vdChbZGlzYWJsZWRdKSwgaW5wdXQ6bm90KFtkaXNhYmxlZF0pLCBzZWxlY3Q6bm90KFtkaXNhYmxlZF0pLCB0ZXh0YXJlYTpub3QoW2Rpc2FibGVkXSksIFt0YWJpbmRleF06bm90KFt0YWJpbmRleD1cIi0xXCJdKSc7XG5cbi8qKiBUaGUgb3Blbi1vdmVybGF5IHN0YWNrLCBuZXdlc3QgbGFzdC4gT25seSB0aGUgdG9wIGVudHJ5IGFuc3dlcnMgRXNjYXBlIOKAlFxuICogIGEgbmVzdGVkIHBhaXIgY2xvc2VzIG9uZSBwZXIga2V5LCBuZXZlciBib3RoIGF0IG9uY2UuICovXG5jb25zdCBzdGFjazogeyBjbG9zZTogKCkgPT4gdm9pZCB9W10gPSBbXTtcblxuaW50ZXJmYWNlIE92ZXJsYXlGb2N1c0Rpc21pc3NPcHRpb25zIHtcbiAgLyoqIE1lbnVzIGRvIG5vdCB0cmFwIFRhYiAodGhlIEFQRyBtZW51IHBhdHRlcm4ga2VlcHMgVGFiIGFzIGxlYXZlKTsgZGlhbG9nc1xuICAgKiAgZG8uIERlZmF1bHQgdHJ1ZS4gKi9cbiAgdHJhcFRhYj86IGJvb2xlYW47XG59XG5cbi8qKlxuICogV2lyZSB0aGUgY29udHJhY3QgdG8gYW4gb3ZlcmxheSByb290LiBBdHRhY2ggdGhlIHJldHVybmVkIHJlZiB0byB0aGUgZWxlbWVudFxuICogdGhhdCBib3VuZHMgdGhlIG92ZXJsYXkgKGl0cyBwYW5lbC9tZW51IGJveCkuXG4gKlxuICogQHBhcmFtIG9wZW4gICAgdGhlIG92ZXJsYXkncyBvcGVuIHN0YXRlIOKAlCB0aGUgZWZmZWN0IGFybXMgb24gdHJ1ZSBhbmQgY2xlYW5zXG4gKiAgICAgICAgICAgICAgICB1cCAocmV0dXJuaW5nIGZvY3VzKSBvbiBmYWxzZS91bm1vdW50LlxuICogQHBhcmFtIG9uQ2xvc2UgRXNjYXBlJ3MgbWVhbmluZzogY2xvc2Ugd2l0aG91dCBjb21taXR0aW5nLlxuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlT3ZlcmxheUZvY3VzRGlzbWlzcyhcbiAgb3BlbjogYm9vbGVhbixcbiAgb25DbG9zZTogKCkgPT4gdm9pZCxcbiAgb3B0czogT3ZlcmxheUZvY3VzRGlzbWlzc09wdGlvbnMgPSB7fSxcbikge1xuICBjb25zdCByb290UmVmID0gdXNlUmVmPEhUTUxEaXZFbGVtZW50IHwgbnVsbD4obnVsbCk7XG4gIC8vIFRoZSBsYXRlc3QgY2xvc2UgY2FsbGJhY2ssIGtlcHQgY3VycmVudCBpbiBhbiBlZmZlY3QgKG5ldmVyIGEgcmVuZGVyLXRpbWVcbiAgLy8gcmVmIHdyaXRlIOKAlCB0aGUgcmVhY3QtaG9va3MgY29tcGlsZXIgZm9yYmlkcyBpdCwgY29ycmVjdGx5KS5cbiAgY29uc3Qgb25DbG9zZVJlZiA9IHVzZVJlZihvbkNsb3NlKTtcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBvbkNsb3NlUmVmLmN1cnJlbnQgPSBvbkNsb3NlO1xuICB9KTtcbiAgY29uc3QgdHJhcFRhYiA9IG9wdHMudHJhcFRhYiAhPT0gZmFsc2U7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIW9wZW4pIHJldHVybjtcbiAgICAvLyBUaGUgdHJpZ2dlciB0byByZXR1cm4gdG8sIGNhcHR1cmVkIEJFRk9SRSBmb2N1cyBtb3ZlcyBpbi5cbiAgICBjb25zdCB0cmlnZ2VyID0gZG9jdW1lbnQuYWN0aXZlRWxlbWVudCBhcyBIVE1MRWxlbWVudCB8IG51bGw7XG4gICAgY29uc3QgZW50cnkgPSB7XG4gICAgICBjbG9zZTogKCkgPT4gb25DbG9zZVJlZi5jdXJyZW50KCksXG4gICAgfTtcbiAgICBzdGFjay5wdXNoKGVudHJ5KTtcbiAgICAvLyBTZXQgd2hlbiBhIE1FTlUgc3VyZmFjZSBjbG9zZXMgYmVjYXVzZSBUYWIgbGVmdCBpdDogdGhlIGJyb3dzZXIncyBvd25cbiAgICAvLyBmb2N1cyBtb3ZlIG11c3Qgc3RhbmQgKEFQRyBNZW51IEJ1dHRvbiksIHNvIHRoZSBjbGVhbnVwIGJlbG93IG11c3QgTk9UXG4gICAgLy8geWFuayBmb2N1cyBiYWNrIHRvIHRoZSB0cmlnZ2VyLlxuICAgIGxldCBjbG9zZWRWaWFUYWIgPSBmYWxzZTtcbiAgICBjb25zdCByb290ID0gcm9vdFJlZi5jdXJyZW50O1xuICAgIGNvbnN0IGZvY3VzYWJsZXMgPSByb290ID8gWy4uLnJvb3QucXVlcnlTZWxlY3RvckFsbDxIVE1MRWxlbWVudD4oRk9DVVNBQkxFKV0gOiBbXTtcbiAgICAvLyBGb2N1cyBJTjogdGhlIGZpcnN0IGNvbnRyb2w7IGEgcGFuZWwgd2l0aCBubyBmb2N1c2FibGUgY29udGVudCB0YWtlc1xuICAgIC8vIGZvY3VzIGl0c2VsZiBzbyBFc2NhcGUgaGFzIGEgaG9tZS5cbiAgICAoZm9jdXNhYmxlc1swXSA/PyByb290KT8uZm9jdXMoKTtcblxuICAgIGNvbnN0IG9uS2V5RG93biA9IChlOiBLZXlib2FyZEV2ZW50KSA9PiB7XG4gICAgICBjb25zdCBpc1RvcCA9IHN0YWNrW3N0YWNrLmxlbmd0aCAtIDFdID09PSBlbnRyeTtcbiAgICAgIGlmIChlLmtleSA9PT0gJ0VzY2FwZScpIHtcbiAgICAgICAgaWYgKCFpc1RvcCkgcmV0dXJuOyAvLyBhIG5lc3RlZCBvdmVybGF5IGFib3ZlIG93bnMgdGhpcyBrZXlcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgICBvbkNsb3NlUmVmLmN1cnJlbnQoKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgaWYgKCF0cmFwVGFiICYmIGUua2V5ID09PSAnVGFiJykge1xuICAgICAgICAvLyBBUEcgTWVudTogVGFiIGlzIExFQVZFIOKAlCB0aGUgZm9jdXMgbW92ZSBwcm9jZWVkcyAobm8gcHJldmVudERlZmF1bHQpXG4gICAgICAgIC8vIGFuZCB0aGUgbWVudSBjbG9zZXMgYmVoaW5kIGl0LCBuZXZlciBzdHJhbmRlZCBvdmVyIGEgc2NyaW0uIFRoZVxuICAgICAgICAvLyBmbGFnIGtlZXBzIHRoZSBjbGVhbnVwIGZyb20gcHVsbGluZyBmb2N1cyBiYWNrIHRvIHRoZSB0cmlnZ2VyOiB0aGVcbiAgICAgICAgLy8gbW92ZSB0aGUgYnJvd3NlciBqdXN0IG1hZGUgaXMgdGhlIGNvbnRyYWN0LlxuICAgICAgICBpZiAoaXNUb3ApIHtcbiAgICAgICAgICBjbG9zZWRWaWFUYWIgPSB0cnVlO1xuICAgICAgICAgIG9uQ2xvc2VSZWYuY3VycmVudCgpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGlmICghdHJhcFRhYiB8fCBlLmtleSAhPT0gJ1RhYicgfHwgIXJvb3QpIHJldHVybjtcbiAgICAgIGNvbnN0IGxpc3QgPSBbLi4ucm9vdC5xdWVyeVNlbGVjdG9yQWxsPEhUTUxFbGVtZW50PihGT0NVU0FCTEUpXS5maWx0ZXIoKGVsKSA9PiAhZWwuaGFzQXR0cmlidXRlKCdkaXNhYmxlZCcpKTtcbiAgICAgIGlmICghbGlzdC5sZW5ndGgpIHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBjb25zdCBmaXJzdCA9IGxpc3RbMF07XG4gICAgICBjb25zdCBsYXN0ID0gbGlzdFtsaXN0Lmxlbmd0aCAtIDFdO1xuICAgICAgY29uc3QgYWN0aXZlID0gZG9jdW1lbnQuYWN0aXZlRWxlbWVudDtcbiAgICAgIGlmICghcm9vdC5jb250YWlucyhhY3RpdmUpKSB7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgZmlyc3QuZm9jdXMoKTtcbiAgICAgIH0gZWxzZSBpZiAoZS5zaGlmdEtleSAmJiBhY3RpdmUgPT09IGZpcnN0KSB7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgbGFzdC5mb2N1cygpO1xuICAgICAgfSBlbHNlIGlmICghZS5zaGlmdEtleSAmJiBhY3RpdmUgPT09IGxhc3QpIHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICBmaXJzdC5mb2N1cygpO1xuICAgICAgfVxuICAgIH07XG4gICAgLy8gQ2FwdHVyZSBwaGFzZTogdGhlIGNvbnRyYWN0IHJ1bnMgYmVmb3JlIGFueSBhcHAtbGV2ZWwga2V5IGhhbmRsaW5nLlxuICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ2tleWRvd24nLCBvbktleURvd24sIHRydWUpO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKCdrZXlkb3duJywgb25LZXlEb3duLCB0cnVlKTtcbiAgICAgIGNvbnN0IGkgPSBzdGFjay5pbmRleE9mKGVudHJ5KTtcbiAgICAgIGlmIChpID49IDApIHN0YWNrLnNwbGljZShpLCAxKTtcbiAgICAgIC8vIEZvY3VzIFJFVFVSTlMgdG8gdGhlIHRyaWdnZXIgKFItSVgtMSkg4oCUIHVubGVzcyB0aGUgbWVudSBjbG9zZWQgQkVDQVVTRVxuICAgICAgLy8gVGFiIGxlZnQgaXQ6IHRoYXQgbW92ZSBpcyB0aGUgY29udHJhY3QgYW5kIHN0YW5kcy4gR3VhcmRlZDogdGhlXG4gICAgICAvLyB0cmlnZ2VyIG1heSBiZSBnb25lLlxuICAgICAgaWYgKCFjbG9zZWRWaWFUYWIgJiYgdHJpZ2dlciAmJiBkb2N1bWVudC5jb250YWlucyh0cmlnZ2VyKSkgdHJpZ2dlci5mb2N1cygpO1xuICAgIH07XG4gIH0sIFtvcGVuLCB0cmFwVGFiXSk7XG5cbiAgcmV0dXJuIHJvb3RSZWY7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQU9BLElBQUFBLE1BQUEsR0FBQUMsT0FBQTtBQVBBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFJQTtBQUNBLE1BQU1DLFNBQVMsR0FDYiwySUFBMkk7O0FBRTdJO0FBQ0E7QUFDQSxNQUFNQyxLQUE4QixHQUFHLEVBQUU7QUFRekM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVNDLHNCQUFzQkEsQ0FDcENDLElBQWEsRUFDYkMsT0FBbUIsRUFDbkJDLElBQWdDLEdBQUcsQ0FBQyxDQUFDLEVBQ3JDO0VBQ0EsTUFBTUMsT0FBTyxHQUFHLElBQUFDLGFBQU0sRUFBd0IsSUFBSSxDQUFDO0VBQ25EO0VBQ0E7RUFDQSxNQUFNQyxVQUFVLEdBQUcsSUFBQUQsYUFBTSxFQUFDSCxPQUFPLENBQUM7RUFDbEMsSUFBQUssZ0JBQVMsRUFBQyxNQUFNO0lBQ2RELFVBQVUsQ0FBQ0UsT0FBTyxHQUFHTixPQUFPO0VBQzlCLENBQUMsQ0FBQztFQUNGLE1BQU1PLE9BQU8sR0FBR04sSUFBSSxDQUFDTSxPQUFPLEtBQUssS0FBSztFQUV0QyxJQUFBRixnQkFBUyxFQUFDLE1BQU07SUFDZCxJQUFJLENBQUNOLElBQUksRUFBRTtJQUNYO0lBQ0EsTUFBTVMsT0FBTyxHQUFHQyxRQUFRLENBQUNDLGFBQW1DO0lBQzVELE1BQU1DLEtBQUssR0FBRztNQUNaQyxLQUFLLEVBQUVBLENBQUEsS0FBTVIsVUFBVSxDQUFDRSxPQUFPLENBQUM7SUFDbEMsQ0FBQztJQUNEVCxLQUFLLENBQUNnQixJQUFJLENBQUNGLEtBQUssQ0FBQztJQUNqQjtJQUNBO0lBQ0E7SUFDQSxJQUFJRyxZQUFZLEdBQUcsS0FBSztJQUN4QixNQUFNQyxJQUFJLEdBQUdiLE9BQU8sQ0FBQ0ksT0FBTztJQUM1QixNQUFNVSxVQUFVLEdBQUdELElBQUksR0FBRyxDQUFDLEdBQUdBLElBQUksQ0FBQ0UsZ0JBQWdCLENBQWNyQixTQUFTLENBQUMsQ0FBQyxHQUFHLEVBQUU7SUFDakY7SUFDQTtJQUNBLENBQUNvQixVQUFVLENBQUMsQ0FBQyxDQUFDLElBQUlELElBQUksR0FBR0csS0FBSyxDQUFDLENBQUM7SUFFaEMsTUFBTUMsU0FBUyxHQUFJQyxDQUFnQixJQUFLO01BQ3RDLE1BQU1DLEtBQUssR0FBR3hCLEtBQUssQ0FBQ0EsS0FBSyxDQUFDeUIsTUFBTSxHQUFHLENBQUMsQ0FBQyxLQUFLWCxLQUFLO01BQy9DLElBQUlTLENBQUMsQ0FBQ0csR0FBRyxLQUFLLFFBQVEsRUFBRTtRQUN0QixJQUFJLENBQUNGLEtBQUssRUFBRSxPQUFPLENBQUM7UUFDcEJELENBQUMsQ0FBQ0ksY0FBYyxDQUFDLENBQUM7UUFDbEJKLENBQUMsQ0FBQ0ssZUFBZSxDQUFDLENBQUM7UUFDbkJyQixVQUFVLENBQUNFLE9BQU8sQ0FBQyxDQUFDO1FBQ3BCO01BQ0Y7TUFDQSxJQUFJLENBQUNDLE9BQU8sSUFBSWEsQ0FBQyxDQUFDRyxHQUFHLEtBQUssS0FBSyxFQUFFO1FBQy9CO1FBQ0E7UUFDQTtRQUNBO1FBQ0EsSUFBSUYsS0FBSyxFQUFFO1VBQ1RQLFlBQVksR0FBRyxJQUFJO1VBQ25CVixVQUFVLENBQUNFLE9BQU8sQ0FBQyxDQUFDO1FBQ3RCO1FBQ0E7TUFDRjtNQUNBLElBQUksQ0FBQ0MsT0FBTyxJQUFJYSxDQUFDLENBQUNHLEdBQUcsS0FBSyxLQUFLLElBQUksQ0FBQ1IsSUFBSSxFQUFFO01BQzFDLE1BQU1XLElBQUksR0FBRyxDQUFDLEdBQUdYLElBQUksQ0FBQ0UsZ0JBQWdCLENBQWNyQixTQUFTLENBQUMsQ0FBQyxDQUFDK0IsTUFBTSxDQUFFQyxFQUFFLElBQUssQ0FBQ0EsRUFBRSxDQUFDQyxZQUFZLENBQUMsVUFBVSxDQUFDLENBQUM7TUFDNUcsSUFBSSxDQUFDSCxJQUFJLENBQUNKLE1BQU0sRUFBRTtRQUNoQkYsQ0FBQyxDQUFDSSxjQUFjLENBQUMsQ0FBQztRQUNsQjtNQUNGO01BQ0EsTUFBTU0sS0FBSyxHQUFHSixJQUFJLENBQUMsQ0FBQyxDQUFDO01BQ3JCLE1BQU1LLElBQUksR0FBR0wsSUFBSSxDQUFDQSxJQUFJLENBQUNKLE1BQU0sR0FBRyxDQUFDLENBQUM7TUFDbEMsTUFBTVUsTUFBTSxHQUFHdkIsUUFBUSxDQUFDQyxhQUFhO01BQ3JDLElBQUksQ0FBQ0ssSUFBSSxDQUFDa0IsUUFBUSxDQUFDRCxNQUFNLENBQUMsRUFBRTtRQUMxQlosQ0FBQyxDQUFDSSxjQUFjLENBQUMsQ0FBQztRQUNsQk0sS0FBSyxDQUFDWixLQUFLLENBQUMsQ0FBQztNQUNmLENBQUMsTUFBTSxJQUFJRSxDQUFDLENBQUNjLFFBQVEsSUFBSUYsTUFBTSxLQUFLRixLQUFLLEVBQUU7UUFDekNWLENBQUMsQ0FBQ0ksY0FBYyxDQUFDLENBQUM7UUFDbEJPLElBQUksQ0FBQ2IsS0FBSyxDQUFDLENBQUM7TUFDZCxDQUFDLE1BQU0sSUFBSSxDQUFDRSxDQUFDLENBQUNjLFFBQVEsSUFBSUYsTUFBTSxLQUFLRCxJQUFJLEVBQUU7UUFDekNYLENBQUMsQ0FBQ0ksY0FBYyxDQUFDLENBQUM7UUFDbEJNLEtBQUssQ0FBQ1osS0FBSyxDQUFDLENBQUM7TUFDZjtJQUNGLENBQUM7SUFDRDtJQUNBVCxRQUFRLENBQUMwQixnQkFBZ0IsQ0FBQyxTQUFTLEVBQUVoQixTQUFTLEVBQUUsSUFBSSxDQUFDO0lBQ3JELE9BQU8sTUFBTTtNQUNYVixRQUFRLENBQUMyQixtQkFBbUIsQ0FBQyxTQUFTLEVBQUVqQixTQUFTLEVBQUUsSUFBSSxDQUFDO01BQ3hELE1BQU1rQixDQUFDLEdBQUd4QyxLQUFLLENBQUN5QyxPQUFPLENBQUMzQixLQUFLLENBQUM7TUFDOUIsSUFBSTBCLENBQUMsSUFBSSxDQUFDLEVBQUV4QyxLQUFLLENBQUMwQyxNQUFNLENBQUNGLENBQUMsRUFBRSxDQUFDLENBQUM7TUFDOUI7TUFDQTtNQUNBO01BQ0EsSUFBSSxDQUFDdkIsWUFBWSxJQUFJTixPQUFPLElBQUlDLFFBQVEsQ0FBQ3dCLFFBQVEsQ0FBQ3pCLE9BQU8sQ0FBQyxFQUFFQSxPQUFPLENBQUNVLEtBQUssQ0FBQyxDQUFDO0lBQzdFLENBQUM7RUFDSCxDQUFDLEVBQUUsQ0FBQ25CLElBQUksRUFBRVEsT0FBTyxDQUFDLENBQUM7RUFFbkIsT0FBT0wsT0FBTztBQUNoQiIsImlnbm9yZUxpc3QiOltdfQ==