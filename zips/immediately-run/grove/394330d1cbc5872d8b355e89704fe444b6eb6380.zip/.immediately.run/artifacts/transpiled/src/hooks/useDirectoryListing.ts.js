"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useDirectoryListing = useDirectoryListing;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
var _react = require("react");
var _fs = _interopRequireDefault(require("fs"));
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// Does this key name a DIRECTORY, and what is in it?
//
// The frontmatter index cannot answer this. It holds `.md`/`.mdx` entries only, so a
// folder of assets is invisible to it and a folder whose only child is an image would
// read as "nothing here". The filesystem is the authority, so this hook asks it — the
// one effectful step in the directory feature (the rules live in `lib/directory`).
//
// It runs ONLY for a key the entry index already missed, which is the whole cost
// argument: an ordinary page render performs no extra I/O, and the readdir happens on
// the path that was about to render a 404 anyway.

/** The `fs.promises` slice this hook needs — injectable so the effect is testable. */

/** Read `dirKey`, or do nothing when it is null. A read that throws means "not a
 *  directory" (ENOTDIR/ENOENT are the same answer to the only question asked). */
function useDirectoryListing(dirKey, io) {
  const [state, setState] = (0, _react.useState)(null);
  (0, _react.useEffect)(() => {
    if (!dirKey || state?.key === dirKey) return;
    let cancelled = false;
    const api = io ?? _fs.default.promises;
    api.readdir(dirKey, {
      withFileTypes: true
    }).then(items => {
      if (!cancelled) {
        setState({
          key: dirKey,
          entries: items.map(i => ({
            name: i.name,
            isDirectory: i.isDirectory()
          }))
        });
      }
    }).catch(() => {
      if (!cancelled) setState({
        key: dirKey,
        entries: null
      });
    });
    return () => {
      cancelled = true;
    };
  }, [dirKey, state?.key, io]);
  if (!dirKey) return {
    status: 'none'
  };
  if (state?.key !== dirKey) return {
    status: 'checking'
  };
  return state.entries ? {
    status: 'ready',
    entries: state.entries
  } : {
    status: 'none'
  };
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX2ZzIiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsInVzZURpcmVjdG9yeUxpc3RpbmciLCJkaXJLZXkiLCJpbyIsInN0YXRlIiwic2V0U3RhdGUiLCJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsImtleSIsImNhbmNlbGxlZCIsImFwaSIsImZzIiwicHJvbWlzZXMiLCJyZWFkZGlyIiwid2l0aEZpbGVUeXBlcyIsInRoZW4iLCJpdGVtcyIsImVudHJpZXMiLCJtYXAiLCJpIiwibmFtZSIsImlzRGlyZWN0b3J5IiwiY2F0Y2giLCJzdGF0dXMiXSwic291cmNlcyI6WyJ1c2VEaXJlY3RvcnlMaXN0aW5nLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIERvZXMgdGhpcyBrZXkgbmFtZSBhIERJUkVDVE9SWSwgYW5kIHdoYXQgaXMgaW4gaXQ/XG4vL1xuLy8gVGhlIGZyb250bWF0dGVyIGluZGV4IGNhbm5vdCBhbnN3ZXIgdGhpcy4gSXQgaG9sZHMgYC5tZGAvYC5tZHhgIGVudHJpZXMgb25seSwgc28gYVxuLy8gZm9sZGVyIG9mIGFzc2V0cyBpcyBpbnZpc2libGUgdG8gaXQgYW5kIGEgZm9sZGVyIHdob3NlIG9ubHkgY2hpbGQgaXMgYW4gaW1hZ2Ugd291bGRcbi8vIHJlYWQgYXMgXCJub3RoaW5nIGhlcmVcIi4gVGhlIGZpbGVzeXN0ZW0gaXMgdGhlIGF1dGhvcml0eSwgc28gdGhpcyBob29rIGFza3MgaXQg4oCUIHRoZVxuLy8gb25lIGVmZmVjdGZ1bCBzdGVwIGluIHRoZSBkaXJlY3RvcnkgZmVhdHVyZSAodGhlIHJ1bGVzIGxpdmUgaW4gYGxpYi9kaXJlY3RvcnlgKS5cbi8vXG4vLyBJdCBydW5zIE9OTFkgZm9yIGEga2V5IHRoZSBlbnRyeSBpbmRleCBhbHJlYWR5IG1pc3NlZCwgd2hpY2ggaXMgdGhlIHdob2xlIGNvc3Rcbi8vIGFyZ3VtZW50OiBhbiBvcmRpbmFyeSBwYWdlIHJlbmRlciBwZXJmb3JtcyBubyBleHRyYSBJL08sIGFuZCB0aGUgcmVhZGRpciBoYXBwZW5zIG9uXG4vLyB0aGUgcGF0aCB0aGF0IHdhcyBhYm91dCB0byByZW5kZXIgYSA0MDQgYW55d2F5LlxuXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IGZzIGZyb20gJ2ZzJztcbmltcG9ydCB0eXBlIHsgRGlyRW50cnkgfSBmcm9tICcuLi9saWIvZGlyZWN0b3J5JztcblxuZXhwb3J0IHR5cGUgRGlyZWN0b3J5TGlzdGluZyA9XG4gIC8qKiBOb3QgYXNrZWQgKGEgcmVzb2x2ZWQgZW50cnkpLCBvciB0aGUga2V5IGlzIGEgZmlsZSDigJQgcmVuZGVyIHRoZSBlbnRyeSAvIHRoZSA0MDQuICovXG4gIHwgeyBzdGF0dXM6ICdub25lJyB9XG4gIC8qKiBUaGUgcmVhZGRpciBpcyBpbiBmbGlnaHQuIENhbGxlcnMgbXVzdCBOT1Qgc2hvdyB0aGUgNDA0IGhlcmU6IGEgNDA0IHRoYXQgZmxhc2hlc1xuICAgKiAgYW5kIHRoZW4gYmVjb21lcyBhIGxpc3RpbmcgcmVhZHMgYXMgYSBicm9rZW4gbGluayB0aGF0IGhlYWxlZCBpdHNlbGYuICovXG4gIHwgeyBzdGF0dXM6ICdjaGVja2luZycgfVxuICB8IHsgc3RhdHVzOiAncmVhZHknOyBlbnRyaWVzOiBEaXJFbnRyeVtdIH07XG5cbi8qKiBUaGUgYGZzLnByb21pc2VzYCBzbGljZSB0aGlzIGhvb2sgbmVlZHMg4oCUIGluamVjdGFibGUgc28gdGhlIGVmZmVjdCBpcyB0ZXN0YWJsZS4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgUmVhZGRpckZzIHtcbiAgcmVhZGRpcihwYXRoOiBzdHJpbmcsIG9wdHM6IHsgd2l0aEZpbGVUeXBlczogdHJ1ZSB9KTogUHJvbWlzZTxBcnJheTx7IG5hbWU6IHN0cmluZzsgaXNEaXJlY3RvcnkoKTogYm9vbGVhbiB9Pj47XG59XG5cbi8qKiBSZWFkIGBkaXJLZXlgLCBvciBkbyBub3RoaW5nIHdoZW4gaXQgaXMgbnVsbC4gQSByZWFkIHRoYXQgdGhyb3dzIG1lYW5zIFwibm90IGFcbiAqICBkaXJlY3RvcnlcIiAoRU5PVERJUi9FTk9FTlQgYXJlIHRoZSBzYW1lIGFuc3dlciB0byB0aGUgb25seSBxdWVzdGlvbiBhc2tlZCkuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlRGlyZWN0b3J5TGlzdGluZyhkaXJLZXk6IHN0cmluZyB8IG51bGwsIGlvPzogUmVhZGRpckZzKTogRGlyZWN0b3J5TGlzdGluZyB7XG4gIGNvbnN0IFtzdGF0ZSwgc2V0U3RhdGVdID0gdXNlU3RhdGU8eyBrZXk6IHN0cmluZzsgZW50cmllczogRGlyRW50cnlbXSB8IG51bGwgfSB8IG51bGw+KG51bGwpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFkaXJLZXkgfHwgc3RhdGU/LmtleSA9PT0gZGlyS2V5KSByZXR1cm47XG4gICAgbGV0IGNhbmNlbGxlZCA9IGZhbHNlO1xuICAgIGNvbnN0IGFwaSA9IGlvID8/IChmcy5wcm9taXNlcyBhcyB1bmtub3duIGFzIFJlYWRkaXJGcyk7XG4gICAgYXBpXG4gICAgICAucmVhZGRpcihkaXJLZXksIHsgd2l0aEZpbGVUeXBlczogdHJ1ZSB9KVxuICAgICAgLnRoZW4oKGl0ZW1zKSA9PiB7XG4gICAgICAgIGlmICghY2FuY2VsbGVkKSB7XG4gICAgICAgICAgc2V0U3RhdGUoeyBrZXk6IGRpcktleSwgZW50cmllczogaXRlbXMubWFwKChpKSA9PiAoeyBuYW1lOiBpLm5hbWUsIGlzRGlyZWN0b3J5OiBpLmlzRGlyZWN0b3J5KCkgfSkpIH0pO1xuICAgICAgICB9XG4gICAgICB9KVxuICAgICAgLmNhdGNoKCgpID0+IHtcbiAgICAgICAgaWYgKCFjYW5jZWxsZWQpIHNldFN0YXRlKHsga2V5OiBkaXJLZXksIGVudHJpZXM6IG51bGwgfSk7XG4gICAgICB9KTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgY2FuY2VsbGVkID0gdHJ1ZTtcbiAgICB9O1xuICB9LCBbZGlyS2V5LCBzdGF0ZT8ua2V5LCBpb10pO1xuXG4gIGlmICghZGlyS2V5KSByZXR1cm4geyBzdGF0dXM6ICdub25lJyB9O1xuICBpZiAoc3RhdGU/LmtleSAhPT0gZGlyS2V5KSByZXR1cm4geyBzdGF0dXM6ICdjaGVja2luZycgfTtcbiAgcmV0dXJuIHN0YXRlLmVudHJpZXMgPyB7IHN0YXR1czogJ3JlYWR5JywgZW50cmllczogc3RhdGUuZW50cmllcyB9IDogeyBzdGF0dXM6ICdub25lJyB9O1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQVdBLElBQUFBLE1BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLEdBQUEsR0FBQUMsc0JBQUEsQ0FBQUYsT0FBQTtBQUFvQixTQUFBRSx1QkFBQUMsQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQVpwQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFjQTs7QUFLQTtBQUNBO0FBQ08sU0FBU0csbUJBQW1CQSxDQUFDQyxNQUFxQixFQUFFQyxFQUFjLEVBQW9CO0VBQzNGLE1BQU0sQ0FBQ0MsS0FBSyxFQUFFQyxRQUFRLENBQUMsR0FBRyxJQUFBQyxlQUFRLEVBQXFELElBQUksQ0FBQztFQUU1RixJQUFBQyxnQkFBUyxFQUFDLE1BQU07SUFDZCxJQUFJLENBQUNMLE1BQU0sSUFBSUUsS0FBSyxFQUFFSSxHQUFHLEtBQUtOLE1BQU0sRUFBRTtJQUN0QyxJQUFJTyxTQUFTLEdBQUcsS0FBSztJQUNyQixNQUFNQyxHQUFHLEdBQUdQLEVBQUUsSUFBS1EsV0FBRSxDQUFDQyxRQUFpQztJQUN2REYsR0FBRyxDQUNBRyxPQUFPLENBQUNYLE1BQU0sRUFBRTtNQUFFWSxhQUFhLEVBQUU7SUFBSyxDQUFDLENBQUMsQ0FDeENDLElBQUksQ0FBRUMsS0FBSyxJQUFLO01BQ2YsSUFBSSxDQUFDUCxTQUFTLEVBQUU7UUFDZEosUUFBUSxDQUFDO1VBQUVHLEdBQUcsRUFBRU4sTUFBTTtVQUFFZSxPQUFPLEVBQUVELEtBQUssQ0FBQ0UsR0FBRyxDQUFFQyxDQUFDLEtBQU07WUFBRUMsSUFBSSxFQUFFRCxDQUFDLENBQUNDLElBQUk7WUFBRUMsV0FBVyxFQUFFRixDQUFDLENBQUNFLFdBQVcsQ0FBQztVQUFFLENBQUMsQ0FBQztRQUFFLENBQUMsQ0FBQztNQUN4RztJQUNGLENBQUMsQ0FBQyxDQUNEQyxLQUFLLENBQUMsTUFBTTtNQUNYLElBQUksQ0FBQ2IsU0FBUyxFQUFFSixRQUFRLENBQUM7UUFBRUcsR0FBRyxFQUFFTixNQUFNO1FBQUVlLE9BQU8sRUFBRTtNQUFLLENBQUMsQ0FBQztJQUMxRCxDQUFDLENBQUM7SUFDSixPQUFPLE1BQU07TUFDWFIsU0FBUyxHQUFHLElBQUk7SUFDbEIsQ0FBQztFQUNILENBQUMsRUFBRSxDQUFDUCxNQUFNLEVBQUVFLEtBQUssRUFBRUksR0FBRyxFQUFFTCxFQUFFLENBQUMsQ0FBQztFQUU1QixJQUFJLENBQUNELE1BQU0sRUFBRSxPQUFPO0lBQUVxQixNQUFNLEVBQUU7RUFBTyxDQUFDO0VBQ3RDLElBQUluQixLQUFLLEVBQUVJLEdBQUcsS0FBS04sTUFBTSxFQUFFLE9BQU87SUFBRXFCLE1BQU0sRUFBRTtFQUFXLENBQUM7RUFDeEQsT0FBT25CLEtBQUssQ0FBQ2EsT0FBTyxHQUFHO0lBQUVNLE1BQU0sRUFBRSxPQUFPO0lBQUVOLE9BQU8sRUFBRWIsS0FBSyxDQUFDYTtFQUFRLENBQUMsR0FBRztJQUFFTSxNQUFNLEVBQUU7RUFBTyxDQUFDO0FBQ3pGIiwiaWdub3JlTGlzdCI6W119