var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.some.js");
var _vitest = require("vitest");
var _react = require("react");
var _client = require("react-dom/client");
var _sdk = require("@immediately-run/sdk");
var _TinkerableContext = require("@immediately-run/sdk/TinkerableContext");
var _contentRoot = require("../lib/contentRoot");
var _shell = require("../lib/shell");
var _jsxRuntime = require("react/jsx-runtime");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; } // @vitest-environment jsdom
// `useDirectoryListing` reads the real `fs` module — the one the host supplies inside the
// sandbox. Mocked here so the table is exercised over a known tree, and mocked at the
// MODULE level (not injected through a prop) because the injection point is not part of
// the component's contract: content writes `<DirectoryList path="…"/>` and nothing else.
const readdir = _vitest.vi.fn();
_vitest.vi.mock('fs', () => ({
  default: {
    promises: {
      readdir: (...a) => readdir(...a)
    }
  }
}));
const {
  default: DirectoryList
} = await Promise.resolve().then(() => _interopRequireWildcard(require('./DirectoryList')));
const {
  default: DirectoryView
} = await Promise.resolve().then(() => _interopRequireWildcard(require('./DirectoryView')));

/** The slice of the shell <DirectoryView> reads, cast in. */
const shell = entryKey => ({
  entryKey,
  siteTitle: 'Meridian handbook'
});
const dirent = (name, isDirectory = false) => ({
  name,
  isDirectory: () => isDirectory
});
const METADATA = {
  '/app/content/handbook/onboarding.mdx': {
    title: 'Onboarding, day one.',
    description: 'What every new hire does in their first week.',
    tags: ['handbook', 'ui/nav'],
    date: '2026-06-22'
  },
  '/app/content/handbook/expenses.mdx': {
    title: 'Expenses.'
  }
};
function host(children, sandboxPath = '/files/content/handbook/onboarding.mdx') {
  const value = {
    outerHref: 'https://immediately.run/present/github/o/r/main/files/content/handbook/onboarding.mdx',
    navigationState: {
      mode: 'present',
      namespace: 'github',
      provider: 'github',
      repository: 'o/r',
      ref: 'main',
      sandboxPath,
      hash: '',
      search: ''
    },
    routingSpec: {
      routes: []
    },
    filesMetadata: METADATA
  };
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_TinkerableContext.TinkerableContext.Provider, {
    value: value,
    children: children
  });
}
async function render(node) {
  const container = document.createElement('div');
  document.body.appendChild(container);
  await (0, _react.act)(async () => {
    (0, _client.createRoot)(container).render(node);
  });
  return container;
}
(0, _vitest.beforeEach)(() => {
  readdir.mockReset();
  readdir.mockResolvedValue([dirent('archive', true), dirent('onboarding.mdx'), dirent('expenses.mdx'), dirent('policy.pdf'), dirent('_layout.mdx')]);
});
(0, _vitest.afterEach)(() => {
  (0, _contentRoot.resetContentRoot)();
  document.body.innerHTML = '';
});
(0, _vitest.describe)('<DirectoryList/>', () => {
  (0, _vitest.it)('lists the folder of the current entry when given no path', async () => {
    const el = await render(host(/*#__PURE__*/(0, _jsxRuntime.jsx)(DirectoryList, {})));
    (0, _vitest.expect)(readdir).toHaveBeenCalledWith('/app/content/handbook', {
      withFileTypes: true
    });
    const names = [...el.querySelectorAll('.gdir__labels')].map(n => n.textContent);
    // Directory first; the structural `_layout.mdx` is not a reader-facing row.
    (0, _vitest.expect)(names).toEqual(['archive', 'Expensesexpenses.mdx', 'Onboarding, day oneonboarding.mdx', 'policy.pdf']);
  });
  (0, _vitest.it)('links entries and subfolders, and leaves an asset unlinked', async () => {
    const el = await render(host(/*#__PURE__*/(0, _jsxRuntime.jsx)(DirectoryList, {})));
    const hrefs = [...el.querySelectorAll('tbody a')].map(a => a.getAttribute('href'));
    (0, _vitest.expect)(hrefs.some(h => h?.endsWith('/files/content/handbook/archive'))).toBe(true);
    (0, _vitest.expect)(hrefs.some(h => h?.endsWith('/files/content/handbook/onboarding.mdx'))).toBe(true);
    (0, _vitest.expect)(hrefs.some(h => h?.includes('policy.pdf'))).toBe(false);
    (0, _vitest.expect)(el.querySelector('tr[data-kind="file"] .gdir__plain')?.textContent).toBe('policy.pdf');
  });
  (0, _vitest.it)('shows only the metadata columns the corpus supplies, and drops `ui/` tags', async () => {
    const el = await render(host(/*#__PURE__*/(0, _jsxRuntime.jsx)(DirectoryList, {})));
    (0, _vitest.expect)([...el.querySelectorAll('th')].map(t => t.textContent)).toEqual(['Name', 'Description', 'Tags', 'Updated']);
    (0, _vitest.expect)([...el.querySelectorAll('.grove-tag')].map(t => t.textContent)).toEqual(['#handbook']);
  });
  (0, _vitest.it)('renders a plain table over a corpus with no frontmatter at all', async () => {
    readdir.mockResolvedValue([dirent('a.md'), dirent('b.md')]);
    const el = await render(host(/*#__PURE__*/(0, _jsxRuntime.jsx)(DirectoryList, {
      path: "/plain"
    })));
    (0, _vitest.expect)([...el.querySelectorAll('th')].map(t => t.textContent)).toEqual(['Name']);
  });
  (0, _vitest.it)('resolves `path` corpus-relative with a leading slash, entry-relative without', async () => {
    await render(host(/*#__PURE__*/(0, _jsxRuntime.jsx)(DirectoryList, {
      path: "/teams"
    })));
    (0, _vitest.expect)(readdir).toHaveBeenCalledWith('/app/content/teams', {
      withFileTypes: true
    });
    readdir.mockClear();
    await render(host(/*#__PURE__*/(0, _jsxRuntime.jsx)(DirectoryList, {
      path: "archive"
    })));
    (0, _vitest.expect)(readdir).toHaveBeenCalledWith('/app/content/handbook/archive', {
      withFileTypes: true
    });
  });
  (0, _vitest.it)('says so when the folder is empty rather than rendering an empty table', async () => {
    readdir.mockResolvedValue([]);
    const el = await render(host(/*#__PURE__*/(0, _jsxRuntime.jsx)(DirectoryList, {})));
    (0, _vitest.expect)(el.textContent).toContain('This folder is empty.');
    (0, _vitest.expect)(el.textContent).toContain('No entries, subfolders or files here yet.');
    (0, _vitest.expect)(el.querySelector('table')).toBeNull();
  });
  (0, _vitest.it)('distinguishes an EMPTY folder from one whose every child is hidden', async () => {
    // Both produce zero rows. "This folder is empty." is false for the second, and a
    // reader who knows `_layout.mdx` is in there goes looking for a bug that is not one.
    readdir.mockResolvedValue([dirent('_layout.mdx'), dirent('.DS_Store')]);
    const el = await render(host(/*#__PURE__*/(0, _jsxRuntime.jsx)(DirectoryList, {})));
    (0, _vitest.expect)(el.textContent).toContain('Nothing to show in this folder.');
    (0, _vitest.expect)(el.textContent).toContain('2 files skipped');
    (0, _vitest.expect)(el.textContent).not.toContain('This folder is empty.');
  });
  (0, _vitest.it)('survives an unreadable path without throwing', async () => {
    readdir.mockRejectedValue(new Error('ENOTDIR'));
    const el = await render(host(/*#__PURE__*/(0, _jsxRuntime.jsx)(DirectoryList, {
      path: "/nope"
    })));
    (0, _vitest.expect)(el.querySelector('table')).toBeNull();
  });
  (0, _vitest.it)('reads `hidden` as a STRING attribute — the safe renderer passes literals only', async () => {
    // Under the interpreter every attribute arrives as a string, so `hidden="false"`
    // would switch the flag ON if truthiness were the test.
    const off = await render(host(/*#__PURE__*/(0, _jsxRuntime.jsx)(DirectoryList, {
      hidden: "false"
    })));
    (0, _vitest.expect)(off.textContent).not.toContain('_layout.mdx');
    const on = await render(host(/*#__PURE__*/(0, _jsxRuntime.jsx)(DirectoryList, {
      hidden: "true"
    })));
    (0, _vitest.expect)(on.textContent).toContain('_layout.mdx');
  });
  (0, _vitest.it)('is overridable through the MDX provider — the FOLDER ROUTE included', async () => {
    // The override contract in one assertion, driven through the real <DirectoryView>:
    // whatever the provider resolves for the name `DirectoryList` is what the folder
    // route renders. The view LOOKS THE COMPONENT UP rather than importing it, so a
    // replacement reaches the route too — not only MDX bodies that spell the tag out.
    const Replacement = ({
      path
    }) => /*#__PURE__*/(0, _jsxRuntime.jsxs)("p", {
      className: "mine",
      children: ["listing of ", path]
    });
    const el = await render(host(/*#__PURE__*/(0, _jsxRuntime.jsx)(_sdk.MDXProvider, {
      components: {
        DirectoryList: Replacement
      },
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_shell.GroveShellContext.Provider, {
        value: shell('/app/content/handbook'),
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(DirectoryView, {})
      })
    }), '/files/content/handbook'));
    (0, _vitest.expect)(el.querySelector('.mine')?.textContent).toBe('listing of /handbook');
    // …and the stock table is genuinely gone, not merely joined.
    (0, _vitest.expect)(el.querySelector('.grove-dirlist__table')).toBeNull();
  });
  (0, _vitest.it)('falls back to the built-in table when nothing overrides the name', async () => {
    const el = await render(host(/*#__PURE__*/(0, _jsxRuntime.jsx)(_shell.GroveShellContext.Provider, {
      value: shell('/app/content/handbook'),
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(DirectoryView, {})
    }), '/files/content/handbook'));
    (0, _vitest.expect)(el.querySelector('.grove-dirlist__table')).not.toBeNull();
    (0, _vitest.expect)(el.querySelector('h1')?.textContent).toContain('handbook');
  });
});

// ── The DISPATCH packaging ────────────────────────────────────────────────────────────
//
// A dispatched Grove renders SOMEBODY ELSE'S corpus, mounted at a host-minted chroot
// (`/mnt/<hash>/`), while the engine itself is loaded from Grove's own repo. Every path
// helper is a function of that root — which is why `contentRoot.ts` warns "call it, don't
// capture it": a helper that froze `/app/content/` at module scope renders the VIEWER's
// corpus while claiming to render yours, and corrects itself never.
//
// Directory listings touch both path spaces at once — they READ through the mount and
// LINK through the URL space — so they are exactly where the two can be got backwards.
// Verified live against a dispatched corpus on the local host (2026-08-18); these pin it.
(0, _vitest.describe)('<DirectoryList/> under dispatch', () => {
  const MOUNT = '/mnt/abc123def456/';
  const CORPUS_META = {
    '/mnt/abc123def456/context/ways_of_working.mdx': {
      title: 'Ways of working.',
      description: 'The engineering practices behind the product values.',
      updated: '2026-07-11'
    }
  };
  function dispatched(children, sandboxPath) {
    (0, _contentRoot.setContentRoot)(MOUNT);
    const value = {
      outerHref: `https://local.immediately.run/present/local/ns/corpus/live${sandboxPath}`,
      navigationState: {
        mode: 'present',
        namespace: 'local',
        provider: 'local',
        repository: 'ns/corpus',
        ref: 'live',
        sandboxPath,
        hash: '',
        search: ''
      },
      routingSpec: {
        routes: []
      },
      filesMetadata: CORPUS_META
    };
    return /*#__PURE__*/(0, _jsxRuntime.jsx)(_TinkerableContext.TinkerableContext.Provider, {
      value: value,
      children: children
    });
  }
  (0, _vitest.beforeEach)(() => {
    readdir.mockReset();
    readdir.mockResolvedValue([dirent('ways_of_working.mdx'), dirent('diagram.svg')]);
  });
  (0, _vitest.it)('reads through the MOUNT, not the fork root', async () => {
    await render(dispatched(/*#__PURE__*/(0, _jsxRuntime.jsx)(DirectoryList, {}), '/files/context'));
    // `/app/content/context` here would be the viewer rendering its own corpus.
    (0, _vitest.expect)(readdir).toHaveBeenCalledWith('/mnt/abc123def456/context', {
      withFileTypes: true
    });
  });
  (0, _vitest.it)('links in CORPUS-relative URL space — the mount path never reaches the DOM', async () => {
    const el = await render(dispatched(/*#__PURE__*/(0, _jsxRuntime.jsx)(_shell.GroveShellContext.Provider, {
      value: shell('/mnt/abc123def456/context'),
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(DirectoryView, {})
    }), '/files/context'));
    const hrefs = [...el.querySelectorAll('tbody a')].map(a => a.getAttribute('href'));
    (0, _vitest.expect)(hrefs).toHaveLength(1); // the asset is listed, not linked
    (0, _vitest.expect)(hrefs[0]?.endsWith('/files/context/ways_of_working.mdx')).toBe(true);

    // The load-bearing assertion, and the one that would have caught the R3-268 bug this
    // same mapping already had once: the chroot prefix is HOST knowledge. Grove can read
    // through it but must never publish it — a `/mnt/<hash>/…` href is a URL no router
    // resolves and a path the host's existence check misses.
    (0, _vitest.expect)(el.innerHTML).not.toContain('mnt');
    (0, _vitest.expect)(el.innerHTML).not.toContain('abc123def456');
    (0, _vitest.expect)(el.innerHTML).not.toContain('/app/');
  });
  (0, _vitest.it)('measures breadcrumbs from the corpus root, not from `/`', async () => {
    const el = await render(dispatched(/*#__PURE__*/(0, _jsxRuntime.jsx)(_shell.GroveShellContext.Provider, {
      value: shell('/mnt/abc123def456/plans/ui-as-apps'),
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(DirectoryView, {})
    }), '/files/plans/ui-as-apps'));
    const crumb = el.querySelector('.crumb')?.textContent ?? '';
    (0, _vitest.expect)(crumb).toContain('plans');
    (0, _vitest.expect)(crumb).not.toContain('mnt');
    (0, _vitest.expect)(el.querySelector('h1')?.textContent).toContain('ui-as-apps');
  });
  (0, _vitest.it)('resolves `path` against the mounted corpus, and confines traversal to it', async () => {
    await render(dispatched(/*#__PURE__*/(0, _jsxRuntime.jsx)(DirectoryList, {
      path: "/specs"
    }), '/files/context'));
    (0, _vitest.expect)(readdir).toHaveBeenCalledWith('/mnt/abc123def456/specs', {
      withFileTypes: true
    });
    readdir.mockClear();
    // Foreign content authored the href; `..` must not become a readdir of the host's fs.
    await render(dispatched(/*#__PURE__*/(0, _jsxRuntime.jsx)(DirectoryList, {
      path: "../../.."
    }), '/files/context'));
    (0, _vitest.expect)(readdir).toHaveBeenCalledWith('/mnt/abc123def456', {
      withFileTypes: true
    });
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZXN0IiwicmVxdWlyZSIsIl9yZWFjdCIsIl9jbGllbnQiLCJfc2RrIiwiX1RpbmtlcmFibGVDb250ZXh0IiwiX2NvbnRlbnRSb290IiwiX3NoZWxsIiwiX2pzeFJ1bnRpbWUiLCJfZ2V0UmVxdWlyZVdpbGRjYXJkQ2FjaGUiLCJlIiwiV2Vha01hcCIsInIiLCJ0IiwiX2ludGVyb3BSZXF1aXJlV2lsZGNhcmQiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsImhhcyIsImdldCIsIm4iLCJfX3Byb3RvX18iLCJhIiwiT2JqZWN0IiwiZGVmaW5lUHJvcGVydHkiLCJnZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IiLCJ1IiwiaGFzT3duUHJvcGVydHkiLCJjYWxsIiwiaSIsInNldCIsInJlYWRkaXIiLCJ2aSIsImZuIiwibW9jayIsInByb21pc2VzIiwiRGlyZWN0b3J5TGlzdCIsIlByb21pc2UiLCJyZXNvbHZlIiwidGhlbiIsIkRpcmVjdG9yeVZpZXciLCJzaGVsbCIsImVudHJ5S2V5Iiwic2l0ZVRpdGxlIiwiZGlyZW50IiwibmFtZSIsImlzRGlyZWN0b3J5IiwiTUVUQURBVEEiLCJ0aXRsZSIsImRlc2NyaXB0aW9uIiwidGFncyIsImRhdGUiLCJob3N0IiwiY2hpbGRyZW4iLCJzYW5kYm94UGF0aCIsInZhbHVlIiwib3V0ZXJIcmVmIiwibmF2aWdhdGlvblN0YXRlIiwibW9kZSIsIm5hbWVzcGFjZSIsInByb3ZpZGVyIiwicmVwb3NpdG9yeSIsInJlZiIsImhhc2giLCJzZWFyY2giLCJyb3V0aW5nU3BlYyIsInJvdXRlcyIsImZpbGVzTWV0YWRhdGEiLCJqc3giLCJUaW5rZXJhYmxlQ29udGV4dCIsIlByb3ZpZGVyIiwicmVuZGVyIiwibm9kZSIsImNvbnRhaW5lciIsImRvY3VtZW50IiwiY3JlYXRlRWxlbWVudCIsImJvZHkiLCJhcHBlbmRDaGlsZCIsImFjdCIsImNyZWF0ZVJvb3QiLCJiZWZvcmVFYWNoIiwibW9ja1Jlc2V0IiwibW9ja1Jlc29sdmVkVmFsdWUiLCJhZnRlckVhY2giLCJyZXNldENvbnRlbnRSb290IiwiaW5uZXJIVE1MIiwiZGVzY3JpYmUiLCJpdCIsImVsIiwiZXhwZWN0IiwidG9IYXZlQmVlbkNhbGxlZFdpdGgiLCJ3aXRoRmlsZVR5cGVzIiwibmFtZXMiLCJxdWVyeVNlbGVjdG9yQWxsIiwibWFwIiwidGV4dENvbnRlbnQiLCJ0b0VxdWFsIiwiaHJlZnMiLCJnZXRBdHRyaWJ1dGUiLCJzb21lIiwiaCIsImVuZHNXaXRoIiwidG9CZSIsImluY2x1ZGVzIiwicXVlcnlTZWxlY3RvciIsInBhdGgiLCJtb2NrQ2xlYXIiLCJ0b0NvbnRhaW4iLCJ0b0JlTnVsbCIsIm5vdCIsIm1vY2tSZWplY3RlZFZhbHVlIiwiRXJyb3IiLCJvZmYiLCJoaWRkZW4iLCJvbiIsIlJlcGxhY2VtZW50IiwianN4cyIsImNsYXNzTmFtZSIsIk1EWFByb3ZpZGVyIiwiY29tcG9uZW50cyIsIkdyb3ZlU2hlbGxDb250ZXh0IiwiTU9VTlQiLCJDT1JQVVNfTUVUQSIsInVwZGF0ZWQiLCJkaXNwYXRjaGVkIiwic2V0Q29udGVudFJvb3QiLCJ0b0hhdmVMZW5ndGgiLCJjcnVtYiJdLCJzb3VyY2VzIjpbIkRpcmVjdG9yeUxpc3QudGVzdC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gQHZpdGVzdC1lbnZpcm9ubWVudCBqc2RvbVxuaW1wb3J0IHsgZGVzY3JpYmUsIGl0LCBleHBlY3QsIHZpLCBiZWZvcmVFYWNoLCBhZnRlckVhY2ggfSBmcm9tICd2aXRlc3QnO1xuaW1wb3J0IHsgYWN0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgY3JlYXRlUm9vdCB9IGZyb20gJ3JlYWN0LWRvbS9jbGllbnQnO1xuaW1wb3J0IHR5cGUgeyBSZWFjdE5vZGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBNRFhQcm92aWRlciB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrJztcbmltcG9ydCB7IFRpbmtlcmFibGVDb250ZXh0IH0gZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9zZGsvVGlua2VyYWJsZUNvbnRleHQnO1xuaW1wb3J0IHsgcmVzZXRDb250ZW50Um9vdCwgc2V0Q29udGVudFJvb3QgfSBmcm9tICcuLi9saWIvY29udGVudFJvb3QnO1xuaW1wb3J0IHsgR3JvdmVTaGVsbENvbnRleHQsIHR5cGUgR3JvdmVTaGVsbCB9IGZyb20gJy4uL2xpYi9zaGVsbCc7XG5cbi8vIGB1c2VEaXJlY3RvcnlMaXN0aW5nYCByZWFkcyB0aGUgcmVhbCBgZnNgIG1vZHVsZSDigJQgdGhlIG9uZSB0aGUgaG9zdCBzdXBwbGllcyBpbnNpZGUgdGhlXG4vLyBzYW5kYm94LiBNb2NrZWQgaGVyZSBzbyB0aGUgdGFibGUgaXMgZXhlcmNpc2VkIG92ZXIgYSBrbm93biB0cmVlLCBhbmQgbW9ja2VkIGF0IHRoZVxuLy8gTU9EVUxFIGxldmVsIChub3QgaW5qZWN0ZWQgdGhyb3VnaCBhIHByb3ApIGJlY2F1c2UgdGhlIGluamVjdGlvbiBwb2ludCBpcyBub3QgcGFydCBvZlxuLy8gdGhlIGNvbXBvbmVudCdzIGNvbnRyYWN0OiBjb250ZW50IHdyaXRlcyBgPERpcmVjdG9yeUxpc3QgcGF0aD1cIuKAplwiLz5gIGFuZCBub3RoaW5nIGVsc2UuXG5jb25zdCByZWFkZGlyID0gdmkuZm4oKTtcbnZpLm1vY2soJ2ZzJywgKCkgPT4gKHsgZGVmYXVsdDogeyBwcm9taXNlczogeyByZWFkZGlyOiAoLi4uYTogdW5rbm93bltdKSA9PiByZWFkZGlyKC4uLmEpIH0gfSB9KSk7XG5cbmNvbnN0IHsgZGVmYXVsdDogRGlyZWN0b3J5TGlzdCB9ID0gYXdhaXQgaW1wb3J0KCcuL0RpcmVjdG9yeUxpc3QnKTtcbmNvbnN0IHsgZGVmYXVsdDogRGlyZWN0b3J5VmlldyB9ID0gYXdhaXQgaW1wb3J0KCcuL0RpcmVjdG9yeVZpZXcnKTtcblxuLyoqIFRoZSBzbGljZSBvZiB0aGUgc2hlbGwgPERpcmVjdG9yeVZpZXc+IHJlYWRzLCBjYXN0IGluLiAqL1xuY29uc3Qgc2hlbGwgPSAoZW50cnlLZXk6IHN0cmluZyk6IEdyb3ZlU2hlbGwgPT5cbiAgKHsgZW50cnlLZXksIHNpdGVUaXRsZTogJ01lcmlkaWFuIGhhbmRib29rJyB9KSBhcyBHcm92ZVNoZWxsO1xuXG5jb25zdCBkaXJlbnQgPSAobmFtZTogc3RyaW5nLCBpc0RpcmVjdG9yeSA9IGZhbHNlKSA9PiAoeyBuYW1lLCBpc0RpcmVjdG9yeTogKCkgPT4gaXNEaXJlY3RvcnkgfSk7XG5cbmNvbnN0IE1FVEFEQVRBID0ge1xuICAnL2FwcC9jb250ZW50L2hhbmRib29rL29uYm9hcmRpbmcubWR4Jzoge1xuICAgIHRpdGxlOiAnT25ib2FyZGluZywgZGF5IG9uZS4nLFxuICAgIGRlc2NyaXB0aW9uOiAnV2hhdCBldmVyeSBuZXcgaGlyZSBkb2VzIGluIHRoZWlyIGZpcnN0IHdlZWsuJyxcbiAgICB0YWdzOiBbJ2hhbmRib29rJywgJ3VpL25hdiddLFxuICAgIGRhdGU6ICcyMDI2LTA2LTIyJyxcbiAgfSxcbiAgJy9hcHAvY29udGVudC9oYW5kYm9vay9leHBlbnNlcy5tZHgnOiB7IHRpdGxlOiAnRXhwZW5zZXMuJyB9LFxufTtcblxuZnVuY3Rpb24gaG9zdChjaGlsZHJlbjogUmVhY3ROb2RlLCBzYW5kYm94UGF0aCA9ICcvZmlsZXMvY29udGVudC9oYW5kYm9vay9vbmJvYXJkaW5nLm1keCcpIHtcbiAgY29uc3QgdmFsdWUgPSB7XG4gICAgb3V0ZXJIcmVmOiAnaHR0cHM6Ly9pbW1lZGlhdGVseS5ydW4vcHJlc2VudC9naXRodWIvby9yL21haW4vZmlsZXMvY29udGVudC9oYW5kYm9vay9vbmJvYXJkaW5nLm1keCcsXG4gICAgbmF2aWdhdGlvblN0YXRlOiB7IG1vZGU6ICdwcmVzZW50JywgbmFtZXNwYWNlOiAnZ2l0aHViJywgcHJvdmlkZXI6ICdnaXRodWInLCByZXBvc2l0b3J5OiAnby9yJywgcmVmOiAnbWFpbicsIHNhbmRib3hQYXRoLCBoYXNoOiAnJywgc2VhcmNoOiAnJyB9LFxuICAgIHJvdXRpbmdTcGVjOiB7IHJvdXRlczogW10gfSxcbiAgICBmaWxlc01ldGFkYXRhOiBNRVRBREFUQSxcbiAgfTtcbiAgcmV0dXJuIDxUaW5rZXJhYmxlQ29udGV4dC5Qcm92aWRlciB2YWx1ZT17dmFsdWUgYXMgbmV2ZXJ9PntjaGlsZHJlbn08L1RpbmtlcmFibGVDb250ZXh0LlByb3ZpZGVyPjtcbn1cblxuYXN5bmMgZnVuY3Rpb24gcmVuZGVyKG5vZGU6IFJlYWN0Tm9kZSk6IFByb21pc2U8SFRNTEVsZW1lbnQ+IHtcbiAgY29uc3QgY29udGFpbmVyID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoY29udGFpbmVyKTtcbiAgYXdhaXQgYWN0KGFzeW5jICgpID0+IHtcbiAgICBjcmVhdGVSb290KGNvbnRhaW5lcikucmVuZGVyKG5vZGUpO1xuICB9KTtcbiAgcmV0dXJuIGNvbnRhaW5lcjtcbn1cblxuYmVmb3JlRWFjaCgoKSA9PiB7XG4gIHJlYWRkaXIubW9ja1Jlc2V0KCk7XG4gIHJlYWRkaXIubW9ja1Jlc29sdmVkVmFsdWUoW1xuICAgIGRpcmVudCgnYXJjaGl2ZScsIHRydWUpLFxuICAgIGRpcmVudCgnb25ib2FyZGluZy5tZHgnKSxcbiAgICBkaXJlbnQoJ2V4cGVuc2VzLm1keCcpLFxuICAgIGRpcmVudCgncG9saWN5LnBkZicpLFxuICAgIGRpcmVudCgnX2xheW91dC5tZHgnKSxcbiAgXSk7XG59KTtcbmFmdGVyRWFjaCgoKSA9PiB7XG4gIHJlc2V0Q29udGVudFJvb3QoKTtcbiAgZG9jdW1lbnQuYm9keS5pbm5lckhUTUwgPSAnJztcbn0pO1xuXG5kZXNjcmliZSgnPERpcmVjdG9yeUxpc3QvPicsICgpID0+IHtcbiAgaXQoJ2xpc3RzIHRoZSBmb2xkZXIgb2YgdGhlIGN1cnJlbnQgZW50cnkgd2hlbiBnaXZlbiBubyBwYXRoJywgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IGVsID0gYXdhaXQgcmVuZGVyKGhvc3QoPERpcmVjdG9yeUxpc3QgLz4pKTtcbiAgICBleHBlY3QocmVhZGRpcikudG9IYXZlQmVlbkNhbGxlZFdpdGgoJy9hcHAvY29udGVudC9oYW5kYm9vaycsIHsgd2l0aEZpbGVUeXBlczogdHJ1ZSB9KTtcbiAgICBjb25zdCBuYW1lcyA9IFsuLi5lbC5xdWVyeVNlbGVjdG9yQWxsKCcuZ2Rpcl9fbGFiZWxzJyldLm1hcCgobikgPT4gbi50ZXh0Q29udGVudCk7XG4gICAgLy8gRGlyZWN0b3J5IGZpcnN0OyB0aGUgc3RydWN0dXJhbCBgX2xheW91dC5tZHhgIGlzIG5vdCBhIHJlYWRlci1mYWNpbmcgcm93LlxuICAgIGV4cGVjdChuYW1lcykudG9FcXVhbChbXG4gICAgICAnYXJjaGl2ZScsXG4gICAgICAnRXhwZW5zZXNleHBlbnNlcy5tZHgnLFxuICAgICAgJ09uYm9hcmRpbmcsIGRheSBvbmVvbmJvYXJkaW5nLm1keCcsXG4gICAgICAncG9saWN5LnBkZicsXG4gICAgXSk7XG4gIH0pO1xuXG4gIGl0KCdsaW5rcyBlbnRyaWVzIGFuZCBzdWJmb2xkZXJzLCBhbmQgbGVhdmVzIGFuIGFzc2V0IHVubGlua2VkJywgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IGVsID0gYXdhaXQgcmVuZGVyKGhvc3QoPERpcmVjdG9yeUxpc3QgLz4pKTtcbiAgICBjb25zdCBocmVmcyA9IFsuLi5lbC5xdWVyeVNlbGVjdG9yQWxsKCd0Ym9keSBhJyldLm1hcCgoYSkgPT4gYS5nZXRBdHRyaWJ1dGUoJ2hyZWYnKSk7XG4gICAgZXhwZWN0KGhyZWZzLnNvbWUoKGgpID0+IGg/LmVuZHNXaXRoKCcvZmlsZXMvY29udGVudC9oYW5kYm9vay9hcmNoaXZlJykpKS50b0JlKHRydWUpO1xuICAgIGV4cGVjdChocmVmcy5zb21lKChoKSA9PiBoPy5lbmRzV2l0aCgnL2ZpbGVzL2NvbnRlbnQvaGFuZGJvb2svb25ib2FyZGluZy5tZHgnKSkpLnRvQmUodHJ1ZSk7XG4gICAgZXhwZWN0KGhyZWZzLnNvbWUoKGgpID0+IGg/LmluY2x1ZGVzKCdwb2xpY3kucGRmJykpKS50b0JlKGZhbHNlKTtcbiAgICBleHBlY3QoZWwucXVlcnlTZWxlY3RvcigndHJbZGF0YS1raW5kPVwiZmlsZVwiXSAuZ2Rpcl9fcGxhaW4nKT8udGV4dENvbnRlbnQpLnRvQmUoJ3BvbGljeS5wZGYnKTtcbiAgfSk7XG5cbiAgaXQoJ3Nob3dzIG9ubHkgdGhlIG1ldGFkYXRhIGNvbHVtbnMgdGhlIGNvcnB1cyBzdXBwbGllcywgYW5kIGRyb3BzIGB1aS9gIHRhZ3MnLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgZWwgPSBhd2FpdCByZW5kZXIoaG9zdCg8RGlyZWN0b3J5TGlzdCAvPikpO1xuICAgIGV4cGVjdChbLi4uZWwucXVlcnlTZWxlY3RvckFsbCgndGgnKV0ubWFwKCh0KSA9PiB0LnRleHRDb250ZW50KSkudG9FcXVhbChbXG4gICAgICAnTmFtZScsXG4gICAgICAnRGVzY3JpcHRpb24nLFxuICAgICAgJ1RhZ3MnLFxuICAgICAgJ1VwZGF0ZWQnLFxuICAgIF0pO1xuICAgIGV4cGVjdChbLi4uZWwucXVlcnlTZWxlY3RvckFsbCgnLmdyb3ZlLXRhZycpXS5tYXAoKHQpID0+IHQudGV4dENvbnRlbnQpKS50b0VxdWFsKFsnI2hhbmRib29rJ10pO1xuICB9KTtcblxuICBpdCgncmVuZGVycyBhIHBsYWluIHRhYmxlIG92ZXIgYSBjb3JwdXMgd2l0aCBubyBmcm9udG1hdHRlciBhdCBhbGwnLCBhc3luYyAoKSA9PiB7XG4gICAgcmVhZGRpci5tb2NrUmVzb2x2ZWRWYWx1ZShbZGlyZW50KCdhLm1kJyksIGRpcmVudCgnYi5tZCcpXSk7XG4gICAgY29uc3QgZWwgPSBhd2FpdCByZW5kZXIoaG9zdCg8RGlyZWN0b3J5TGlzdCBwYXRoPVwiL3BsYWluXCIgLz4pKTtcbiAgICBleHBlY3QoWy4uLmVsLnF1ZXJ5U2VsZWN0b3JBbGwoJ3RoJyldLm1hcCgodCkgPT4gdC50ZXh0Q29udGVudCkpLnRvRXF1YWwoWydOYW1lJ10pO1xuICB9KTtcblxuICBpdCgncmVzb2x2ZXMgYHBhdGhgIGNvcnB1cy1yZWxhdGl2ZSB3aXRoIGEgbGVhZGluZyBzbGFzaCwgZW50cnktcmVsYXRpdmUgd2l0aG91dCcsIGFzeW5jICgpID0+IHtcbiAgICBhd2FpdCByZW5kZXIoaG9zdCg8RGlyZWN0b3J5TGlzdCBwYXRoPVwiL3RlYW1zXCIgLz4pKTtcbiAgICBleHBlY3QocmVhZGRpcikudG9IYXZlQmVlbkNhbGxlZFdpdGgoJy9hcHAvY29udGVudC90ZWFtcycsIHsgd2l0aEZpbGVUeXBlczogdHJ1ZSB9KTtcbiAgICByZWFkZGlyLm1vY2tDbGVhcigpO1xuICAgIGF3YWl0IHJlbmRlcihob3N0KDxEaXJlY3RvcnlMaXN0IHBhdGg9XCJhcmNoaXZlXCIgLz4pKTtcbiAgICBleHBlY3QocmVhZGRpcikudG9IYXZlQmVlbkNhbGxlZFdpdGgoJy9hcHAvY29udGVudC9oYW5kYm9vay9hcmNoaXZlJywgeyB3aXRoRmlsZVR5cGVzOiB0cnVlIH0pO1xuICB9KTtcblxuICBpdCgnc2F5cyBzbyB3aGVuIHRoZSBmb2xkZXIgaXMgZW1wdHkgcmF0aGVyIHRoYW4gcmVuZGVyaW5nIGFuIGVtcHR5IHRhYmxlJywgYXN5bmMgKCkgPT4ge1xuICAgIHJlYWRkaXIubW9ja1Jlc29sdmVkVmFsdWUoW10pO1xuICAgIGNvbnN0IGVsID0gYXdhaXQgcmVuZGVyKGhvc3QoPERpcmVjdG9yeUxpc3QgLz4pKTtcbiAgICBleHBlY3QoZWwudGV4dENvbnRlbnQpLnRvQ29udGFpbignVGhpcyBmb2xkZXIgaXMgZW1wdHkuJyk7XG4gICAgZXhwZWN0KGVsLnRleHRDb250ZW50KS50b0NvbnRhaW4oJ05vIGVudHJpZXMsIHN1YmZvbGRlcnMgb3IgZmlsZXMgaGVyZSB5ZXQuJyk7XG4gICAgZXhwZWN0KGVsLnF1ZXJ5U2VsZWN0b3IoJ3RhYmxlJykpLnRvQmVOdWxsKCk7XG4gIH0pO1xuXG4gIGl0KCdkaXN0aW5ndWlzaGVzIGFuIEVNUFRZIGZvbGRlciBmcm9tIG9uZSB3aG9zZSBldmVyeSBjaGlsZCBpcyBoaWRkZW4nLCBhc3luYyAoKSA9PiB7XG4gICAgLy8gQm90aCBwcm9kdWNlIHplcm8gcm93cy4gXCJUaGlzIGZvbGRlciBpcyBlbXB0eS5cIiBpcyBmYWxzZSBmb3IgdGhlIHNlY29uZCwgYW5kIGFcbiAgICAvLyByZWFkZXIgd2hvIGtub3dzIGBfbGF5b3V0Lm1keGAgaXMgaW4gdGhlcmUgZ29lcyBsb29raW5nIGZvciBhIGJ1ZyB0aGF0IGlzIG5vdCBvbmUuXG4gICAgcmVhZGRpci5tb2NrUmVzb2x2ZWRWYWx1ZShbZGlyZW50KCdfbGF5b3V0Lm1keCcpLCBkaXJlbnQoJy5EU19TdG9yZScpXSk7XG4gICAgY29uc3QgZWwgPSBhd2FpdCByZW5kZXIoaG9zdCg8RGlyZWN0b3J5TGlzdCAvPikpO1xuICAgIGV4cGVjdChlbC50ZXh0Q29udGVudCkudG9Db250YWluKCdOb3RoaW5nIHRvIHNob3cgaW4gdGhpcyBmb2xkZXIuJyk7XG4gICAgZXhwZWN0KGVsLnRleHRDb250ZW50KS50b0NvbnRhaW4oJzIgZmlsZXMgc2tpcHBlZCcpO1xuICAgIGV4cGVjdChlbC50ZXh0Q29udGVudCkubm90LnRvQ29udGFpbignVGhpcyBmb2xkZXIgaXMgZW1wdHkuJyk7XG4gIH0pO1xuXG4gIGl0KCdzdXJ2aXZlcyBhbiB1bnJlYWRhYmxlIHBhdGggd2l0aG91dCB0aHJvd2luZycsIGFzeW5jICgpID0+IHtcbiAgICByZWFkZGlyLm1vY2tSZWplY3RlZFZhbHVlKG5ldyBFcnJvcignRU5PVERJUicpKTtcbiAgICBjb25zdCBlbCA9IGF3YWl0IHJlbmRlcihob3N0KDxEaXJlY3RvcnlMaXN0IHBhdGg9XCIvbm9wZVwiIC8+KSk7XG4gICAgZXhwZWN0KGVsLnF1ZXJ5U2VsZWN0b3IoJ3RhYmxlJykpLnRvQmVOdWxsKCk7XG4gIH0pO1xuXG4gIGl0KCdyZWFkcyBgaGlkZGVuYCBhcyBhIFNUUklORyBhdHRyaWJ1dGUg4oCUIHRoZSBzYWZlIHJlbmRlcmVyIHBhc3NlcyBsaXRlcmFscyBvbmx5JywgYXN5bmMgKCkgPT4ge1xuICAgIC8vIFVuZGVyIHRoZSBpbnRlcnByZXRlciBldmVyeSBhdHRyaWJ1dGUgYXJyaXZlcyBhcyBhIHN0cmluZywgc28gYGhpZGRlbj1cImZhbHNlXCJgXG4gICAgLy8gd291bGQgc3dpdGNoIHRoZSBmbGFnIE9OIGlmIHRydXRoaW5lc3Mgd2VyZSB0aGUgdGVzdC5cbiAgICBjb25zdCBvZmYgPSBhd2FpdCByZW5kZXIoaG9zdCg8RGlyZWN0b3J5TGlzdCBoaWRkZW49XCJmYWxzZVwiIC8+KSk7XG4gICAgZXhwZWN0KG9mZi50ZXh0Q29udGVudCkubm90LnRvQ29udGFpbignX2xheW91dC5tZHgnKTtcbiAgICBjb25zdCBvbiA9IGF3YWl0IHJlbmRlcihob3N0KDxEaXJlY3RvcnlMaXN0IGhpZGRlbj1cInRydWVcIiAvPikpO1xuICAgIGV4cGVjdChvbi50ZXh0Q29udGVudCkudG9Db250YWluKCdfbGF5b3V0Lm1keCcpO1xuICB9KTtcblxuICBpdCgnaXMgb3ZlcnJpZGFibGUgdGhyb3VnaCB0aGUgTURYIHByb3ZpZGVyIOKAlCB0aGUgRk9MREVSIFJPVVRFIGluY2x1ZGVkJywgYXN5bmMgKCkgPT4ge1xuICAgIC8vIFRoZSBvdmVycmlkZSBjb250cmFjdCBpbiBvbmUgYXNzZXJ0aW9uLCBkcml2ZW4gdGhyb3VnaCB0aGUgcmVhbCA8RGlyZWN0b3J5Vmlldz46XG4gICAgLy8gd2hhdGV2ZXIgdGhlIHByb3ZpZGVyIHJlc29sdmVzIGZvciB0aGUgbmFtZSBgRGlyZWN0b3J5TGlzdGAgaXMgd2hhdCB0aGUgZm9sZGVyXG4gICAgLy8gcm91dGUgcmVuZGVycy4gVGhlIHZpZXcgTE9PS1MgVEhFIENPTVBPTkVOVCBVUCByYXRoZXIgdGhhbiBpbXBvcnRpbmcgaXQsIHNvIGFcbiAgICAvLyByZXBsYWNlbWVudCByZWFjaGVzIHRoZSByb3V0ZSB0b28g4oCUIG5vdCBvbmx5IE1EWCBib2RpZXMgdGhhdCBzcGVsbCB0aGUgdGFnIG91dC5cbiAgICBjb25zdCBSZXBsYWNlbWVudCA9ICh7IHBhdGggfTogeyBwYXRoPzogc3RyaW5nIH0pID0+IDxwIGNsYXNzTmFtZT1cIm1pbmVcIj5saXN0aW5nIG9mIHtwYXRofTwvcD47XG4gICAgY29uc3QgZWwgPSBhd2FpdCByZW5kZXIoXG4gICAgICBob3N0KFxuICAgICAgICA8TURYUHJvdmlkZXIgY29tcG9uZW50cz17eyBEaXJlY3RvcnlMaXN0OiBSZXBsYWNlbWVudCB9fT5cbiAgICAgICAgICA8R3JvdmVTaGVsbENvbnRleHQuUHJvdmlkZXIgdmFsdWU9e3NoZWxsKCcvYXBwL2NvbnRlbnQvaGFuZGJvb2snKX0+XG4gICAgICAgICAgICA8RGlyZWN0b3J5VmlldyAvPlxuICAgICAgICAgIDwvR3JvdmVTaGVsbENvbnRleHQuUHJvdmlkZXI+XG4gICAgICAgIDwvTURYUHJvdmlkZXI+LFxuICAgICAgICAnL2ZpbGVzL2NvbnRlbnQvaGFuZGJvb2snXG4gICAgICApXG4gICAgKTtcbiAgICBleHBlY3QoZWwucXVlcnlTZWxlY3RvcignLm1pbmUnKT8udGV4dENvbnRlbnQpLnRvQmUoJ2xpc3Rpbmcgb2YgL2hhbmRib29rJyk7XG4gICAgLy8g4oCmYW5kIHRoZSBzdG9jayB0YWJsZSBpcyBnZW51aW5lbHkgZ29uZSwgbm90IG1lcmVseSBqb2luZWQuXG4gICAgZXhwZWN0KGVsLnF1ZXJ5U2VsZWN0b3IoJy5ncm92ZS1kaXJsaXN0X190YWJsZScpKS50b0JlTnVsbCgpO1xuICB9KTtcblxuICBpdCgnZmFsbHMgYmFjayB0byB0aGUgYnVpbHQtaW4gdGFibGUgd2hlbiBub3RoaW5nIG92ZXJyaWRlcyB0aGUgbmFtZScsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCBlbCA9IGF3YWl0IHJlbmRlcihcbiAgICAgIGhvc3QoXG4gICAgICAgIDxHcm92ZVNoZWxsQ29udGV4dC5Qcm92aWRlciB2YWx1ZT17c2hlbGwoJy9hcHAvY29udGVudC9oYW5kYm9vaycpfT5cbiAgICAgICAgICA8RGlyZWN0b3J5VmlldyAvPlxuICAgICAgICA8L0dyb3ZlU2hlbGxDb250ZXh0LlByb3ZpZGVyPixcbiAgICAgICAgJy9maWxlcy9jb250ZW50L2hhbmRib29rJ1xuICAgICAgKVxuICAgICk7XG4gICAgZXhwZWN0KGVsLnF1ZXJ5U2VsZWN0b3IoJy5ncm92ZS1kaXJsaXN0X190YWJsZScpKS5ub3QudG9CZU51bGwoKTtcbiAgICBleHBlY3QoZWwucXVlcnlTZWxlY3RvcignaDEnKT8udGV4dENvbnRlbnQpLnRvQ29udGFpbignaGFuZGJvb2snKTtcbiAgfSk7XG59KTtcblxuLy8g4pSA4pSAIFRoZSBESVNQQVRDSCBwYWNrYWdpbmcg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4vL1xuLy8gQSBkaXNwYXRjaGVkIEdyb3ZlIHJlbmRlcnMgU09NRUJPRFkgRUxTRSdTIGNvcnB1cywgbW91bnRlZCBhdCBhIGhvc3QtbWludGVkIGNocm9vdFxuLy8gKGAvbW50LzxoYXNoPi9gKSwgd2hpbGUgdGhlIGVuZ2luZSBpdHNlbGYgaXMgbG9hZGVkIGZyb20gR3JvdmUncyBvd24gcmVwby4gRXZlcnkgcGF0aFxuLy8gaGVscGVyIGlzIGEgZnVuY3Rpb24gb2YgdGhhdCByb290IOKAlCB3aGljaCBpcyB3aHkgYGNvbnRlbnRSb290LnRzYCB3YXJucyBcImNhbGwgaXQsIGRvbid0XG4vLyBjYXB0dXJlIGl0XCI6IGEgaGVscGVyIHRoYXQgZnJvemUgYC9hcHAvY29udGVudC9gIGF0IG1vZHVsZSBzY29wZSByZW5kZXJzIHRoZSBWSUVXRVInc1xuLy8gY29ycHVzIHdoaWxlIGNsYWltaW5nIHRvIHJlbmRlciB5b3VycywgYW5kIGNvcnJlY3RzIGl0c2VsZiBuZXZlci5cbi8vXG4vLyBEaXJlY3RvcnkgbGlzdGluZ3MgdG91Y2ggYm90aCBwYXRoIHNwYWNlcyBhdCBvbmNlIOKAlCB0aGV5IFJFQUQgdGhyb3VnaCB0aGUgbW91bnQgYW5kXG4vLyBMSU5LIHRocm91Z2ggdGhlIFVSTCBzcGFjZSDigJQgc28gdGhleSBhcmUgZXhhY3RseSB3aGVyZSB0aGUgdHdvIGNhbiBiZSBnb3QgYmFja3dhcmRzLlxuLy8gVmVyaWZpZWQgbGl2ZSBhZ2FpbnN0IGEgZGlzcGF0Y2hlZCBjb3JwdXMgb24gdGhlIGxvY2FsIGhvc3QgKDIwMjYtMDgtMTgpOyB0aGVzZSBwaW4gaXQuXG5kZXNjcmliZSgnPERpcmVjdG9yeUxpc3QvPiB1bmRlciBkaXNwYXRjaCcsICgpID0+IHtcbiAgY29uc3QgTU9VTlQgPSAnL21udC9hYmMxMjNkZWY0NTYvJztcbiAgY29uc3QgQ09SUFVTX01FVEEgPSB7XG4gICAgJy9tbnQvYWJjMTIzZGVmNDU2L2NvbnRleHQvd2F5c19vZl93b3JraW5nLm1keCc6IHtcbiAgICAgIHRpdGxlOiAnV2F5cyBvZiB3b3JraW5nLicsXG4gICAgICBkZXNjcmlwdGlvbjogJ1RoZSBlbmdpbmVlcmluZyBwcmFjdGljZXMgYmVoaW5kIHRoZSBwcm9kdWN0IHZhbHVlcy4nLFxuICAgICAgdXBkYXRlZDogJzIwMjYtMDctMTEnLFxuICAgIH0sXG4gIH07XG5cbiAgZnVuY3Rpb24gZGlzcGF0Y2hlZChjaGlsZHJlbjogUmVhY3ROb2RlLCBzYW5kYm94UGF0aDogc3RyaW5nKSB7XG4gICAgc2V0Q29udGVudFJvb3QoTU9VTlQpO1xuICAgIGNvbnN0IHZhbHVlID0ge1xuICAgICAgb3V0ZXJIcmVmOiBgaHR0cHM6Ly9sb2NhbC5pbW1lZGlhdGVseS5ydW4vcHJlc2VudC9sb2NhbC9ucy9jb3JwdXMvbGl2ZSR7c2FuZGJveFBhdGh9YCxcbiAgICAgIG5hdmlnYXRpb25TdGF0ZTogeyBtb2RlOiAncHJlc2VudCcsIG5hbWVzcGFjZTogJ2xvY2FsJywgcHJvdmlkZXI6ICdsb2NhbCcsIHJlcG9zaXRvcnk6ICducy9jb3JwdXMnLCByZWY6ICdsaXZlJywgc2FuZGJveFBhdGgsIGhhc2g6ICcnLCBzZWFyY2g6ICcnIH0sXG4gICAgICByb3V0aW5nU3BlYzogeyByb3V0ZXM6IFtdIH0sXG4gICAgICBmaWxlc01ldGFkYXRhOiBDT1JQVVNfTUVUQSxcbiAgICB9O1xuICAgIHJldHVybiA8VGlua2VyYWJsZUNvbnRleHQuUHJvdmlkZXIgdmFsdWU9e3ZhbHVlIGFzIG5ldmVyfT57Y2hpbGRyZW59PC9UaW5rZXJhYmxlQ29udGV4dC5Qcm92aWRlcj47XG4gIH1cblxuICBiZWZvcmVFYWNoKCgpID0+IHtcbiAgICByZWFkZGlyLm1vY2tSZXNldCgpO1xuICAgIHJlYWRkaXIubW9ja1Jlc29sdmVkVmFsdWUoW2RpcmVudCgnd2F5c19vZl93b3JraW5nLm1keCcpLCBkaXJlbnQoJ2RpYWdyYW0uc3ZnJyldKTtcbiAgfSk7XG5cbiAgaXQoJ3JlYWRzIHRocm91Z2ggdGhlIE1PVU5ULCBub3QgdGhlIGZvcmsgcm9vdCcsIGFzeW5jICgpID0+IHtcbiAgICBhd2FpdCByZW5kZXIoZGlzcGF0Y2hlZCg8RGlyZWN0b3J5TGlzdCAvPiwgJy9maWxlcy9jb250ZXh0JykpO1xuICAgIC8vIGAvYXBwL2NvbnRlbnQvY29udGV4dGAgaGVyZSB3b3VsZCBiZSB0aGUgdmlld2VyIHJlbmRlcmluZyBpdHMgb3duIGNvcnB1cy5cbiAgICBleHBlY3QocmVhZGRpcikudG9IYXZlQmVlbkNhbGxlZFdpdGgoJy9tbnQvYWJjMTIzZGVmNDU2L2NvbnRleHQnLCB7IHdpdGhGaWxlVHlwZXM6IHRydWUgfSk7XG4gIH0pO1xuXG4gIGl0KCdsaW5rcyBpbiBDT1JQVVMtcmVsYXRpdmUgVVJMIHNwYWNlIOKAlCB0aGUgbW91bnQgcGF0aCBuZXZlciByZWFjaGVzIHRoZSBET00nLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgZWwgPSBhd2FpdCByZW5kZXIoXG4gICAgICBkaXNwYXRjaGVkKFxuICAgICAgICA8R3JvdmVTaGVsbENvbnRleHQuUHJvdmlkZXIgdmFsdWU9e3NoZWxsKCcvbW50L2FiYzEyM2RlZjQ1Ni9jb250ZXh0Jyl9PlxuICAgICAgICAgIDxEaXJlY3RvcnlWaWV3IC8+XG4gICAgICAgIDwvR3JvdmVTaGVsbENvbnRleHQuUHJvdmlkZXI+LFxuICAgICAgICAnL2ZpbGVzL2NvbnRleHQnXG4gICAgICApXG4gICAgKTtcbiAgICBjb25zdCBocmVmcyA9IFsuLi5lbC5xdWVyeVNlbGVjdG9yQWxsKCd0Ym9keSBhJyldLm1hcCgoYSkgPT4gYS5nZXRBdHRyaWJ1dGUoJ2hyZWYnKSk7XG4gICAgZXhwZWN0KGhyZWZzKS50b0hhdmVMZW5ndGgoMSk7IC8vIHRoZSBhc3NldCBpcyBsaXN0ZWQsIG5vdCBsaW5rZWRcbiAgICBleHBlY3QoaHJlZnNbMF0/LmVuZHNXaXRoKCcvZmlsZXMvY29udGV4dC93YXlzX29mX3dvcmtpbmcubWR4JykpLnRvQmUodHJ1ZSk7XG5cbiAgICAvLyBUaGUgbG9hZC1iZWFyaW5nIGFzc2VydGlvbiwgYW5kIHRoZSBvbmUgdGhhdCB3b3VsZCBoYXZlIGNhdWdodCB0aGUgUjMtMjY4IGJ1ZyB0aGlzXG4gICAgLy8gc2FtZSBtYXBwaW5nIGFscmVhZHkgaGFkIG9uY2U6IHRoZSBjaHJvb3QgcHJlZml4IGlzIEhPU1Qga25vd2xlZGdlLiBHcm92ZSBjYW4gcmVhZFxuICAgIC8vIHRocm91Z2ggaXQgYnV0IG11c3QgbmV2ZXIgcHVibGlzaCBpdCDigJQgYSBgL21udC88aGFzaD4v4oCmYCBocmVmIGlzIGEgVVJMIG5vIHJvdXRlclxuICAgIC8vIHJlc29sdmVzIGFuZCBhIHBhdGggdGhlIGhvc3QncyBleGlzdGVuY2UgY2hlY2sgbWlzc2VzLlxuICAgIGV4cGVjdChlbC5pbm5lckhUTUwpLm5vdC50b0NvbnRhaW4oJ21udCcpO1xuICAgIGV4cGVjdChlbC5pbm5lckhUTUwpLm5vdC50b0NvbnRhaW4oJ2FiYzEyM2RlZjQ1NicpO1xuICAgIGV4cGVjdChlbC5pbm5lckhUTUwpLm5vdC50b0NvbnRhaW4oJy9hcHAvJyk7XG4gIH0pO1xuXG4gIGl0KCdtZWFzdXJlcyBicmVhZGNydW1icyBmcm9tIHRoZSBjb3JwdXMgcm9vdCwgbm90IGZyb20gYC9gJywgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IGVsID0gYXdhaXQgcmVuZGVyKFxuICAgICAgZGlzcGF0Y2hlZChcbiAgICAgICAgPEdyb3ZlU2hlbGxDb250ZXh0LlByb3ZpZGVyIHZhbHVlPXtzaGVsbCgnL21udC9hYmMxMjNkZWY0NTYvcGxhbnMvdWktYXMtYXBwcycpfT5cbiAgICAgICAgICA8RGlyZWN0b3J5VmlldyAvPlxuICAgICAgICA8L0dyb3ZlU2hlbGxDb250ZXh0LlByb3ZpZGVyPixcbiAgICAgICAgJy9maWxlcy9wbGFucy91aS1hcy1hcHBzJ1xuICAgICAgKVxuICAgICk7XG4gICAgY29uc3QgY3J1bWIgPSBlbC5xdWVyeVNlbGVjdG9yKCcuY3J1bWInKT8udGV4dENvbnRlbnQgPz8gJyc7XG4gICAgZXhwZWN0KGNydW1iKS50b0NvbnRhaW4oJ3BsYW5zJyk7XG4gICAgZXhwZWN0KGNydW1iKS5ub3QudG9Db250YWluKCdtbnQnKTtcbiAgICBleHBlY3QoZWwucXVlcnlTZWxlY3RvcignaDEnKT8udGV4dENvbnRlbnQpLnRvQ29udGFpbigndWktYXMtYXBwcycpO1xuICB9KTtcblxuICBpdCgncmVzb2x2ZXMgYHBhdGhgIGFnYWluc3QgdGhlIG1vdW50ZWQgY29ycHVzLCBhbmQgY29uZmluZXMgdHJhdmVyc2FsIHRvIGl0JywgYXN5bmMgKCkgPT4ge1xuICAgIGF3YWl0IHJlbmRlcihkaXNwYXRjaGVkKDxEaXJlY3RvcnlMaXN0IHBhdGg9XCIvc3BlY3NcIiAvPiwgJy9maWxlcy9jb250ZXh0JykpO1xuICAgIGV4cGVjdChyZWFkZGlyKS50b0hhdmVCZWVuQ2FsbGVkV2l0aCgnL21udC9hYmMxMjNkZWY0NTYvc3BlY3MnLCB7IHdpdGhGaWxlVHlwZXM6IHRydWUgfSk7XG4gICAgcmVhZGRpci5tb2NrQ2xlYXIoKTtcbiAgICAvLyBGb3JlaWduIGNvbnRlbnQgYXV0aG9yZWQgdGhlIGhyZWY7IGAuLmAgbXVzdCBub3QgYmVjb21lIGEgcmVhZGRpciBvZiB0aGUgaG9zdCdzIGZzLlxuICAgIGF3YWl0IHJlbmRlcihkaXNwYXRjaGVkKDxEaXJlY3RvcnlMaXN0IHBhdGg9XCIuLi8uLi8uLlwiIC8+LCAnL2ZpbGVzL2NvbnRleHQnKSk7XG4gICAgZXhwZWN0KHJlYWRkaXIpLnRvSGF2ZUJlZW5DYWxsZWRXaXRoKCcvbW50L2FiYzEyM2RlZjQ1NicsIHsgd2l0aEZpbGVUeXBlczogdHJ1ZSB9KTtcbiAgfSk7XG59KTtcbiJdLCJtYXBwaW5ncyI6Ijs7OztBQUNBLElBQUFBLE9BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLE1BQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLE9BQUEsR0FBQUYsT0FBQTtBQUVBLElBQUFHLElBQUEsR0FBQUgsT0FBQTtBQUNBLElBQUFJLGtCQUFBLEdBQUFKLE9BQUE7QUFDQSxJQUFBSyxZQUFBLEdBQUFMLE9BQUE7QUFDQSxJQUFBTSxNQUFBLEdBQUFOLE9BQUE7QUFBa0UsSUFBQU8sV0FBQSxHQUFBUCxPQUFBO0FBQUEsU0FBQVEseUJBQUFDLENBQUEsNkJBQUFDLE9BQUEsbUJBQUFDLENBQUEsT0FBQUQsT0FBQSxJQUFBRSxDQUFBLE9BQUFGLE9BQUEsWUFBQUYsd0JBQUEsWUFBQUEsQ0FBQUMsQ0FBQSxXQUFBQSxDQUFBLEdBQUFHLENBQUEsR0FBQUQsQ0FBQSxLQUFBRixDQUFBO0FBQUEsU0FBQUksd0JBQUFKLENBQUEsRUFBQUUsQ0FBQSxTQUFBQSxDQUFBLElBQUFGLENBQUEsSUFBQUEsQ0FBQSxDQUFBSyxVQUFBLFNBQUFMLENBQUEsZUFBQUEsQ0FBQSx1QkFBQUEsQ0FBQSx5QkFBQUEsQ0FBQSxXQUFBTSxPQUFBLEVBQUFOLENBQUEsUUFBQUcsQ0FBQSxHQUFBSix3QkFBQSxDQUFBRyxDQUFBLE9BQUFDLENBQUEsSUFBQUEsQ0FBQSxDQUFBSSxHQUFBLENBQUFQLENBQUEsVUFBQUcsQ0FBQSxDQUFBSyxHQUFBLENBQUFSLENBQUEsT0FBQVMsQ0FBQSxLQUFBQyxTQUFBLFVBQUFDLENBQUEsR0FBQUMsTUFBQSxDQUFBQyxjQUFBLElBQUFELE1BQUEsQ0FBQUUsd0JBQUEsV0FBQUMsQ0FBQSxJQUFBZixDQUFBLG9CQUFBZSxDQUFBLE9BQUFDLGNBQUEsQ0FBQUMsSUFBQSxDQUFBakIsQ0FBQSxFQUFBZSxDQUFBLFNBQUFHLENBQUEsR0FBQVAsQ0FBQSxHQUFBQyxNQUFBLENBQUFFLHdCQUFBLENBQUFkLENBQUEsRUFBQWUsQ0FBQSxVQUFBRyxDQUFBLEtBQUFBLENBQUEsQ0FBQVYsR0FBQSxJQUFBVSxDQUFBLENBQUFDLEdBQUEsSUFBQVAsTUFBQSxDQUFBQyxjQUFBLENBQUFKLENBQUEsRUFBQU0sQ0FBQSxFQUFBRyxDQUFBLElBQUFULENBQUEsQ0FBQU0sQ0FBQSxJQUFBZixDQUFBLENBQUFlLENBQUEsWUFBQU4sQ0FBQSxDQUFBSCxPQUFBLEdBQUFOLENBQUEsRUFBQUcsQ0FBQSxJQUFBQSxDQUFBLENBQUFnQixHQUFBLENBQUFuQixDQUFBLEVBQUFTLENBQUEsR0FBQUEsQ0FBQSxJQVJsRTtBQVVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTVcsT0FBTyxHQUFHQyxVQUFFLENBQUNDLEVBQUUsQ0FBQyxDQUFDO0FBQ3ZCRCxVQUFFLENBQUNFLElBQUksQ0FBQyxJQUFJLEVBQUUsT0FBTztFQUFFakIsT0FBTyxFQUFFO0lBQUVrQixRQUFRLEVBQUU7TUFBRUosT0FBTyxFQUFFQSxDQUFDLEdBQUdULENBQVksS0FBS1MsT0FBTyxDQUFDLEdBQUdULENBQUM7SUFBRTtFQUFFO0FBQUUsQ0FBQyxDQUFDLENBQUM7QUFFakcsTUFBTTtFQUFFTCxPQUFPLEVBQUVtQjtBQUFjLENBQUMsR0FBRyxNQUFBQyxPQUFBLENBQUFDLE9BQUEsR0FBQUMsSUFBQSxPQUFBeEIsdUJBQUEsQ0FBQWIsT0FBQSxDQUFhLGlCQUFpQixHQUFDO0FBQ2xFLE1BQU07RUFBRWUsT0FBTyxFQUFFdUI7QUFBYyxDQUFDLEdBQUcsTUFBQUgsT0FBQSxDQUFBQyxPQUFBLEdBQUFDLElBQUEsT0FBQXhCLHVCQUFBLENBQUFiLE9BQUEsQ0FBYSxpQkFBaUIsR0FBQzs7QUFFbEU7QUFDQSxNQUFNdUMsS0FBSyxHQUFJQyxRQUFnQixLQUM1QjtFQUFFQSxRQUFRO0VBQUVDLFNBQVMsRUFBRTtBQUFvQixDQUFDLENBQWU7QUFFOUQsTUFBTUMsTUFBTSxHQUFHQSxDQUFDQyxJQUFZLEVBQUVDLFdBQVcsR0FBRyxLQUFLLE1BQU07RUFBRUQsSUFBSTtFQUFFQyxXQUFXLEVBQUVBLENBQUEsS0FBTUE7QUFBWSxDQUFDLENBQUM7QUFFaEcsTUFBTUMsUUFBUSxHQUFHO0VBQ2Ysc0NBQXNDLEVBQUU7SUFDdENDLEtBQUssRUFBRSxzQkFBc0I7SUFDN0JDLFdBQVcsRUFBRSwrQ0FBK0M7SUFDNURDLElBQUksRUFBRSxDQUFDLFVBQVUsRUFBRSxRQUFRLENBQUM7SUFDNUJDLElBQUksRUFBRTtFQUNSLENBQUM7RUFDRCxvQ0FBb0MsRUFBRTtJQUFFSCxLQUFLLEVBQUU7RUFBWTtBQUM3RCxDQUFDO0FBRUQsU0FBU0ksSUFBSUEsQ0FBQ0MsUUFBbUIsRUFBRUMsV0FBVyxHQUFHLHdDQUF3QyxFQUFFO0VBQ3pGLE1BQU1DLEtBQUssR0FBRztJQUNaQyxTQUFTLEVBQUUsdUZBQXVGO0lBQ2xHQyxlQUFlLEVBQUU7TUFBRUMsSUFBSSxFQUFFLFNBQVM7TUFBRUMsU0FBUyxFQUFFLFFBQVE7TUFBRUMsUUFBUSxFQUFFLFFBQVE7TUFBRUMsVUFBVSxFQUFFLEtBQUs7TUFBRUMsR0FBRyxFQUFFLE1BQU07TUFBRVIsV0FBVztNQUFFUyxJQUFJLEVBQUUsRUFBRTtNQUFFQyxNQUFNLEVBQUU7SUFBRyxDQUFDO0lBQ2hKQyxXQUFXLEVBQUU7TUFBRUMsTUFBTSxFQUFFO0lBQUcsQ0FBQztJQUMzQkMsYUFBYSxFQUFFcEI7RUFDakIsQ0FBQztFQUNELG9CQUFPLElBQUF0QyxXQUFBLENBQUEyRCxHQUFBLEVBQUM5RCxrQkFBQSxDQUFBK0QsaUJBQWlCLENBQUNDLFFBQVE7SUFBQ2YsS0FBSyxFQUFFQSxLQUFlO0lBQUFGLFFBQUEsRUFBRUE7RUFBUSxDQUE2QixDQUFDO0FBQ25HO0FBRUEsZUFBZWtCLE1BQU1BLENBQUNDLElBQWUsRUFBd0I7RUFDM0QsTUFBTUMsU0FBUyxHQUFHQyxRQUFRLENBQUNDLGFBQWEsQ0FBQyxLQUFLLENBQUM7RUFDL0NELFFBQVEsQ0FBQ0UsSUFBSSxDQUFDQyxXQUFXLENBQUNKLFNBQVMsQ0FBQztFQUNwQyxNQUFNLElBQUFLLFVBQUcsRUFBQyxZQUFZO0lBQ3BCLElBQUFDLGtCQUFVLEVBQUNOLFNBQVMsQ0FBQyxDQUFDRixNQUFNLENBQUNDLElBQUksQ0FBQztFQUNwQyxDQUFDLENBQUM7RUFDRixPQUFPQyxTQUFTO0FBQ2xCO0FBRUEsSUFBQU8sa0JBQVUsRUFBQyxNQUFNO0VBQ2ZqRCxPQUFPLENBQUNrRCxTQUFTLENBQUMsQ0FBQztFQUNuQmxELE9BQU8sQ0FBQ21ELGlCQUFpQixDQUFDLENBQ3hCdEMsTUFBTSxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsRUFDdkJBLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxFQUN4QkEsTUFBTSxDQUFDLGNBQWMsQ0FBQyxFQUN0QkEsTUFBTSxDQUFDLFlBQVksQ0FBQyxFQUNwQkEsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUN0QixDQUFDO0FBQ0osQ0FBQyxDQUFDO0FBQ0YsSUFBQXVDLGlCQUFTLEVBQUMsTUFBTTtFQUNkLElBQUFDLDZCQUFnQixFQUFDLENBQUM7RUFDbEJWLFFBQVEsQ0FBQ0UsSUFBSSxDQUFDUyxTQUFTLEdBQUcsRUFBRTtBQUM5QixDQUFDLENBQUM7QUFFRixJQUFBQyxnQkFBUSxFQUFDLGtCQUFrQixFQUFFLE1BQU07RUFDakMsSUFBQUMsVUFBRSxFQUFDLDBEQUEwRCxFQUFFLFlBQVk7SUFDekUsTUFBTUMsRUFBRSxHQUFHLE1BQU1qQixNQUFNLENBQUNuQixJQUFJLGNBQUMsSUFBQTNDLFdBQUEsQ0FBQTJELEdBQUEsRUFBQ2hDLGFBQWEsSUFBRSxDQUFDLENBQUMsQ0FBQztJQUNoRCxJQUFBcUQsY0FBTSxFQUFDMUQsT0FBTyxDQUFDLENBQUMyRCxvQkFBb0IsQ0FBQyx1QkFBdUIsRUFBRTtNQUFFQyxhQUFhLEVBQUU7SUFBSyxDQUFDLENBQUM7SUFDdEYsTUFBTUMsS0FBSyxHQUFHLENBQUMsR0FBR0osRUFBRSxDQUFDSyxnQkFBZ0IsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDQyxHQUFHLENBQUUxRSxDQUFDLElBQUtBLENBQUMsQ0FBQzJFLFdBQVcsQ0FBQztJQUNqRjtJQUNBLElBQUFOLGNBQU0sRUFBQ0csS0FBSyxDQUFDLENBQUNJLE9BQU8sQ0FBQyxDQUNwQixTQUFTLEVBQ1Qsc0JBQXNCLEVBQ3RCLG1DQUFtQyxFQUNuQyxZQUFZLENBQ2IsQ0FBQztFQUNKLENBQUMsQ0FBQztFQUVGLElBQUFULFVBQUUsRUFBQyw0REFBNEQsRUFBRSxZQUFZO0lBQzNFLE1BQU1DLEVBQUUsR0FBRyxNQUFNakIsTUFBTSxDQUFDbkIsSUFBSSxjQUFDLElBQUEzQyxXQUFBLENBQUEyRCxHQUFBLEVBQUNoQyxhQUFhLElBQUUsQ0FBQyxDQUFDLENBQUM7SUFDaEQsTUFBTTZELEtBQUssR0FBRyxDQUFDLEdBQUdULEVBQUUsQ0FBQ0ssZ0JBQWdCLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQ0MsR0FBRyxDQUFFeEUsQ0FBQyxJQUFLQSxDQUFDLENBQUM0RSxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDcEYsSUFBQVQsY0FBTSxFQUFDUSxLQUFLLENBQUNFLElBQUksQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLEVBQUVDLFFBQVEsQ0FBQyxpQ0FBaUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLElBQUksQ0FBQztJQUNwRixJQUFBYixjQUFNLEVBQUNRLEtBQUssQ0FBQ0UsSUFBSSxDQUFFQyxDQUFDLElBQUtBLENBQUMsRUFBRUMsUUFBUSxDQUFDLHdDQUF3QyxDQUFDLENBQUMsQ0FBQyxDQUFDQyxJQUFJLENBQUMsSUFBSSxDQUFDO0lBQzNGLElBQUFiLGNBQU0sRUFBQ1EsS0FBSyxDQUFDRSxJQUFJLENBQUVDLENBQUMsSUFBS0EsQ0FBQyxFQUFFRyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDRCxJQUFJLENBQUMsS0FBSyxDQUFDO0lBQ2hFLElBQUFiLGNBQU0sRUFBQ0QsRUFBRSxDQUFDZ0IsYUFBYSxDQUFDLG1DQUFtQyxDQUFDLEVBQUVULFdBQVcsQ0FBQyxDQUFDTyxJQUFJLENBQUMsWUFBWSxDQUFDO0VBQy9GLENBQUMsQ0FBQztFQUVGLElBQUFmLFVBQUUsRUFBQywyRUFBMkUsRUFBRSxZQUFZO0lBQzFGLE1BQU1DLEVBQUUsR0FBRyxNQUFNakIsTUFBTSxDQUFDbkIsSUFBSSxjQUFDLElBQUEzQyxXQUFBLENBQUEyRCxHQUFBLEVBQUNoQyxhQUFhLElBQUUsQ0FBQyxDQUFDLENBQUM7SUFDaEQsSUFBQXFELGNBQU0sRUFBQyxDQUFDLEdBQUdELEVBQUUsQ0FBQ0ssZ0JBQWdCLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQ0MsR0FBRyxDQUFFaEYsQ0FBQyxJQUFLQSxDQUFDLENBQUNpRixXQUFXLENBQUMsQ0FBQyxDQUFDQyxPQUFPLENBQUMsQ0FDdkUsTUFBTSxFQUNOLGFBQWEsRUFDYixNQUFNLEVBQ04sU0FBUyxDQUNWLENBQUM7SUFDRixJQUFBUCxjQUFNLEVBQUMsQ0FBQyxHQUFHRCxFQUFFLENBQUNLLGdCQUFnQixDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUNDLEdBQUcsQ0FBRWhGLENBQUMsSUFBS0EsQ0FBQyxDQUFDaUYsV0FBVyxDQUFDLENBQUMsQ0FBQ0MsT0FBTyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUM7RUFDakcsQ0FBQyxDQUFDO0VBRUYsSUFBQVQsVUFBRSxFQUFDLGdFQUFnRSxFQUFFLFlBQVk7SUFDL0V4RCxPQUFPLENBQUNtRCxpQkFBaUIsQ0FBQyxDQUFDdEMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFQSxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztJQUMzRCxNQUFNNEMsRUFBRSxHQUFHLE1BQU1qQixNQUFNLENBQUNuQixJQUFJLGNBQUMsSUFBQTNDLFdBQUEsQ0FBQTJELEdBQUEsRUFBQ2hDLGFBQWE7TUFBQ3FFLElBQUksRUFBQztJQUFRLENBQUUsQ0FBQyxDQUFDLENBQUM7SUFDOUQsSUFBQWhCLGNBQU0sRUFBQyxDQUFDLEdBQUdELEVBQUUsQ0FBQ0ssZ0JBQWdCLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQ0MsR0FBRyxDQUFFaEYsQ0FBQyxJQUFLQSxDQUFDLENBQUNpRixXQUFXLENBQUMsQ0FBQyxDQUFDQyxPQUFPLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztFQUNwRixDQUFDLENBQUM7RUFFRixJQUFBVCxVQUFFLEVBQUMsOEVBQThFLEVBQUUsWUFBWTtJQUM3RixNQUFNaEIsTUFBTSxDQUFDbkIsSUFBSSxjQUFDLElBQUEzQyxXQUFBLENBQUEyRCxHQUFBLEVBQUNoQyxhQUFhO01BQUNxRSxJQUFJLEVBQUM7SUFBUSxDQUFFLENBQUMsQ0FBQyxDQUFDO0lBQ25ELElBQUFoQixjQUFNLEVBQUMxRCxPQUFPLENBQUMsQ0FBQzJELG9CQUFvQixDQUFDLG9CQUFvQixFQUFFO01BQUVDLGFBQWEsRUFBRTtJQUFLLENBQUMsQ0FBQztJQUNuRjVELE9BQU8sQ0FBQzJFLFNBQVMsQ0FBQyxDQUFDO0lBQ25CLE1BQU1uQyxNQUFNLENBQUNuQixJQUFJLGNBQUMsSUFBQTNDLFdBQUEsQ0FBQTJELEdBQUEsRUFBQ2hDLGFBQWE7TUFBQ3FFLElBQUksRUFBQztJQUFTLENBQUUsQ0FBQyxDQUFDLENBQUM7SUFDcEQsSUFBQWhCLGNBQU0sRUFBQzFELE9BQU8sQ0FBQyxDQUFDMkQsb0JBQW9CLENBQUMsK0JBQStCLEVBQUU7TUFBRUMsYUFBYSxFQUFFO0lBQUssQ0FBQyxDQUFDO0VBQ2hHLENBQUMsQ0FBQztFQUVGLElBQUFKLFVBQUUsRUFBQyx1RUFBdUUsRUFBRSxZQUFZO0lBQ3RGeEQsT0FBTyxDQUFDbUQsaUJBQWlCLENBQUMsRUFBRSxDQUFDO0lBQzdCLE1BQU1NLEVBQUUsR0FBRyxNQUFNakIsTUFBTSxDQUFDbkIsSUFBSSxjQUFDLElBQUEzQyxXQUFBLENBQUEyRCxHQUFBLEVBQUNoQyxhQUFhLElBQUUsQ0FBQyxDQUFDLENBQUM7SUFDaEQsSUFBQXFELGNBQU0sRUFBQ0QsRUFBRSxDQUFDTyxXQUFXLENBQUMsQ0FBQ1ksU0FBUyxDQUFDLHVCQUF1QixDQUFDO0lBQ3pELElBQUFsQixjQUFNLEVBQUNELEVBQUUsQ0FBQ08sV0FBVyxDQUFDLENBQUNZLFNBQVMsQ0FBQywyQ0FBMkMsQ0FBQztJQUM3RSxJQUFBbEIsY0FBTSxFQUFDRCxFQUFFLENBQUNnQixhQUFhLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQ0ksUUFBUSxDQUFDLENBQUM7RUFDOUMsQ0FBQyxDQUFDO0VBRUYsSUFBQXJCLFVBQUUsRUFBQyxvRUFBb0UsRUFBRSxZQUFZO0lBQ25GO0lBQ0E7SUFDQXhELE9BQU8sQ0FBQ21ELGlCQUFpQixDQUFDLENBQUN0QyxNQUFNLENBQUMsYUFBYSxDQUFDLEVBQUVBLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO0lBQ3ZFLE1BQU00QyxFQUFFLEdBQUcsTUFBTWpCLE1BQU0sQ0FBQ25CLElBQUksY0FBQyxJQUFBM0MsV0FBQSxDQUFBMkQsR0FBQSxFQUFDaEMsYUFBYSxJQUFFLENBQUMsQ0FBQyxDQUFDO0lBQ2hELElBQUFxRCxjQUFNLEVBQUNELEVBQUUsQ0FBQ08sV0FBVyxDQUFDLENBQUNZLFNBQVMsQ0FBQyxpQ0FBaUMsQ0FBQztJQUNuRSxJQUFBbEIsY0FBTSxFQUFDRCxFQUFFLENBQUNPLFdBQVcsQ0FBQyxDQUFDWSxTQUFTLENBQUMsaUJBQWlCLENBQUM7SUFDbkQsSUFBQWxCLGNBQU0sRUFBQ0QsRUFBRSxDQUFDTyxXQUFXLENBQUMsQ0FBQ2MsR0FBRyxDQUFDRixTQUFTLENBQUMsdUJBQXVCLENBQUM7RUFDL0QsQ0FBQyxDQUFDO0VBRUYsSUFBQXBCLFVBQUUsRUFBQyw4Q0FBOEMsRUFBRSxZQUFZO0lBQzdEeEQsT0FBTyxDQUFDK0UsaUJBQWlCLENBQUMsSUFBSUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQy9DLE1BQU12QixFQUFFLEdBQUcsTUFBTWpCLE1BQU0sQ0FBQ25CLElBQUksY0FBQyxJQUFBM0MsV0FBQSxDQUFBMkQsR0FBQSxFQUFDaEMsYUFBYTtNQUFDcUUsSUFBSSxFQUFDO0lBQU8sQ0FBRSxDQUFDLENBQUMsQ0FBQztJQUM3RCxJQUFBaEIsY0FBTSxFQUFDRCxFQUFFLENBQUNnQixhQUFhLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQ0ksUUFBUSxDQUFDLENBQUM7RUFDOUMsQ0FBQyxDQUFDO0VBRUYsSUFBQXJCLFVBQUUsRUFBQywrRUFBK0UsRUFBRSxZQUFZO0lBQzlGO0lBQ0E7SUFDQSxNQUFNeUIsR0FBRyxHQUFHLE1BQU16QyxNQUFNLENBQUNuQixJQUFJLGNBQUMsSUFBQTNDLFdBQUEsQ0FBQTJELEdBQUEsRUFBQ2hDLGFBQWE7TUFBQzZFLE1BQU0sRUFBQztJQUFPLENBQUUsQ0FBQyxDQUFDLENBQUM7SUFDaEUsSUFBQXhCLGNBQU0sRUFBQ3VCLEdBQUcsQ0FBQ2pCLFdBQVcsQ0FBQyxDQUFDYyxHQUFHLENBQUNGLFNBQVMsQ0FBQyxhQUFhLENBQUM7SUFDcEQsTUFBTU8sRUFBRSxHQUFHLE1BQU0zQyxNQUFNLENBQUNuQixJQUFJLGNBQUMsSUFBQTNDLFdBQUEsQ0FBQTJELEdBQUEsRUFBQ2hDLGFBQWE7TUFBQzZFLE1BQU0sRUFBQztJQUFNLENBQUUsQ0FBQyxDQUFDLENBQUM7SUFDOUQsSUFBQXhCLGNBQU0sRUFBQ3lCLEVBQUUsQ0FBQ25CLFdBQVcsQ0FBQyxDQUFDWSxTQUFTLENBQUMsYUFBYSxDQUFDO0VBQ2pELENBQUMsQ0FBQztFQUVGLElBQUFwQixVQUFFLEVBQUMscUVBQXFFLEVBQUUsWUFBWTtJQUNwRjtJQUNBO0lBQ0E7SUFDQTtJQUNBLE1BQU00QixXQUFXLEdBQUdBLENBQUM7TUFBRVY7SUFBd0IsQ0FBQyxrQkFBSyxJQUFBaEcsV0FBQSxDQUFBMkcsSUFBQTtNQUFHQyxTQUFTLEVBQUMsTUFBTTtNQUFBaEUsUUFBQSxHQUFDLGFBQVcsRUFBQ29ELElBQUk7SUFBQSxDQUFJLENBQUM7SUFDOUYsTUFBTWpCLEVBQUUsR0FBRyxNQUFNakIsTUFBTSxDQUNyQm5CLElBQUksY0FDRixJQUFBM0MsV0FBQSxDQUFBMkQsR0FBQSxFQUFDL0QsSUFBQSxDQUFBaUgsV0FBVztNQUFDQyxVQUFVLEVBQUU7UUFBRW5GLGFBQWEsRUFBRStFO01BQVksQ0FBRTtNQUFBOUQsUUFBQSxlQUN0RCxJQUFBNUMsV0FBQSxDQUFBMkQsR0FBQSxFQUFDNUQsTUFBQSxDQUFBZ0gsaUJBQWlCLENBQUNsRCxRQUFRO1FBQUNmLEtBQUssRUFBRWQsS0FBSyxDQUFDLHVCQUF1QixDQUFFO1FBQUFZLFFBQUEsZUFDaEUsSUFBQTVDLFdBQUEsQ0FBQTJELEdBQUEsRUFBQzVCLGFBQWEsSUFBRTtNQUFDLENBQ1M7SUFBQyxDQUNsQixDQUFDLEVBQ2QseUJBQ0YsQ0FDRixDQUFDO0lBQ0QsSUFBQWlELGNBQU0sRUFBQ0QsRUFBRSxDQUFDZ0IsYUFBYSxDQUFDLE9BQU8sQ0FBQyxFQUFFVCxXQUFXLENBQUMsQ0FBQ08sSUFBSSxDQUFDLHNCQUFzQixDQUFDO0lBQzNFO0lBQ0EsSUFBQWIsY0FBTSxFQUFDRCxFQUFFLENBQUNnQixhQUFhLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxDQUFDSSxRQUFRLENBQUMsQ0FBQztFQUM5RCxDQUFDLENBQUM7RUFFRixJQUFBckIsVUFBRSxFQUFDLGtFQUFrRSxFQUFFLFlBQVk7SUFDakYsTUFBTUMsRUFBRSxHQUFHLE1BQU1qQixNQUFNLENBQ3JCbkIsSUFBSSxjQUNGLElBQUEzQyxXQUFBLENBQUEyRCxHQUFBLEVBQUM1RCxNQUFBLENBQUFnSCxpQkFBaUIsQ0FBQ2xELFFBQVE7TUFBQ2YsS0FBSyxFQUFFZCxLQUFLLENBQUMsdUJBQXVCLENBQUU7TUFBQVksUUFBQSxlQUNoRSxJQUFBNUMsV0FBQSxDQUFBMkQsR0FBQSxFQUFDNUIsYUFBYSxJQUFFO0lBQUMsQ0FDUyxDQUFDLEVBQzdCLHlCQUNGLENBQ0YsQ0FBQztJQUNELElBQUFpRCxjQUFNLEVBQUNELEVBQUUsQ0FBQ2dCLGFBQWEsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUNLLEdBQUcsQ0FBQ0QsUUFBUSxDQUFDLENBQUM7SUFDaEUsSUFBQW5CLGNBQU0sRUFBQ0QsRUFBRSxDQUFDZ0IsYUFBYSxDQUFDLElBQUksQ0FBQyxFQUFFVCxXQUFXLENBQUMsQ0FBQ1ksU0FBUyxDQUFDLFVBQVUsQ0FBQztFQUNuRSxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7O0FBRUY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUFyQixnQkFBUSxFQUFDLGlDQUFpQyxFQUFFLE1BQU07RUFDaEQsTUFBTW1DLEtBQUssR0FBRyxvQkFBb0I7RUFDbEMsTUFBTUMsV0FBVyxHQUFHO0lBQ2xCLCtDQUErQyxFQUFFO01BQy9DMUUsS0FBSyxFQUFFLGtCQUFrQjtNQUN6QkMsV0FBVyxFQUFFLHNEQUFzRDtNQUNuRTBFLE9BQU8sRUFBRTtJQUNYO0VBQ0YsQ0FBQztFQUVELFNBQVNDLFVBQVVBLENBQUN2RSxRQUFtQixFQUFFQyxXQUFtQixFQUFFO0lBQzVELElBQUF1RSwyQkFBYyxFQUFDSixLQUFLLENBQUM7SUFDckIsTUFBTWxFLEtBQUssR0FBRztNQUNaQyxTQUFTLEVBQUUsNkRBQTZERixXQUFXLEVBQUU7TUFDckZHLGVBQWUsRUFBRTtRQUFFQyxJQUFJLEVBQUUsU0FBUztRQUFFQyxTQUFTLEVBQUUsT0FBTztRQUFFQyxRQUFRLEVBQUUsT0FBTztRQUFFQyxVQUFVLEVBQUUsV0FBVztRQUFFQyxHQUFHLEVBQUUsTUFBTTtRQUFFUixXQUFXO1FBQUVTLElBQUksRUFBRSxFQUFFO1FBQUVDLE1BQU0sRUFBRTtNQUFHLENBQUM7TUFDcEpDLFdBQVcsRUFBRTtRQUFFQyxNQUFNLEVBQUU7TUFBRyxDQUFDO01BQzNCQyxhQUFhLEVBQUV1RDtJQUNqQixDQUFDO0lBQ0Qsb0JBQU8sSUFBQWpILFdBQUEsQ0FBQTJELEdBQUEsRUFBQzlELGtCQUFBLENBQUErRCxpQkFBaUIsQ0FBQ0MsUUFBUTtNQUFDZixLQUFLLEVBQUVBLEtBQWU7TUFBQUYsUUFBQSxFQUFFQTtJQUFRLENBQTZCLENBQUM7RUFDbkc7RUFFQSxJQUFBMkIsa0JBQVUsRUFBQyxNQUFNO0lBQ2ZqRCxPQUFPLENBQUNrRCxTQUFTLENBQUMsQ0FBQztJQUNuQmxELE9BQU8sQ0FBQ21ELGlCQUFpQixDQUFDLENBQUN0QyxNQUFNLENBQUMscUJBQXFCLENBQUMsRUFBRUEsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUM7RUFDbkYsQ0FBQyxDQUFDO0VBRUYsSUFBQTJDLFVBQUUsRUFBQyw0Q0FBNEMsRUFBRSxZQUFZO0lBQzNELE1BQU1oQixNQUFNLENBQUNxRCxVQUFVLGNBQUMsSUFBQW5ILFdBQUEsQ0FBQTJELEdBQUEsRUFBQ2hDLGFBQWEsSUFBRSxDQUFDLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQztJQUM3RDtJQUNBLElBQUFxRCxjQUFNLEVBQUMxRCxPQUFPLENBQUMsQ0FBQzJELG9CQUFvQixDQUFDLDJCQUEyQixFQUFFO01BQUVDLGFBQWEsRUFBRTtJQUFLLENBQUMsQ0FBQztFQUM1RixDQUFDLENBQUM7RUFFRixJQUFBSixVQUFFLEVBQUMsMkVBQTJFLEVBQUUsWUFBWTtJQUMxRixNQUFNQyxFQUFFLEdBQUcsTUFBTWpCLE1BQU0sQ0FDckJxRCxVQUFVLGNBQ1IsSUFBQW5ILFdBQUEsQ0FBQTJELEdBQUEsRUFBQzVELE1BQUEsQ0FBQWdILGlCQUFpQixDQUFDbEQsUUFBUTtNQUFDZixLQUFLLEVBQUVkLEtBQUssQ0FBQywyQkFBMkIsQ0FBRTtNQUFBWSxRQUFBLGVBQ3BFLElBQUE1QyxXQUFBLENBQUEyRCxHQUFBLEVBQUM1QixhQUFhLElBQUU7SUFBQyxDQUNTLENBQUMsRUFDN0IsZ0JBQ0YsQ0FDRixDQUFDO0lBQ0QsTUFBTXlELEtBQUssR0FBRyxDQUFDLEdBQUdULEVBQUUsQ0FBQ0ssZ0JBQWdCLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQ0MsR0FBRyxDQUFFeEUsQ0FBQyxJQUFLQSxDQUFDLENBQUM0RSxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDcEYsSUFBQVQsY0FBTSxFQUFDUSxLQUFLLENBQUMsQ0FBQzZCLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQy9CLElBQUFyQyxjQUFNLEVBQUNRLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRUksUUFBUSxDQUFDLG9DQUFvQyxDQUFDLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLElBQUksQ0FBQzs7SUFFM0U7SUFDQTtJQUNBO0lBQ0E7SUFDQSxJQUFBYixjQUFNLEVBQUNELEVBQUUsQ0FBQ0gsU0FBUyxDQUFDLENBQUN3QixHQUFHLENBQUNGLFNBQVMsQ0FBQyxLQUFLLENBQUM7SUFDekMsSUFBQWxCLGNBQU0sRUFBQ0QsRUFBRSxDQUFDSCxTQUFTLENBQUMsQ0FBQ3dCLEdBQUcsQ0FBQ0YsU0FBUyxDQUFDLGNBQWMsQ0FBQztJQUNsRCxJQUFBbEIsY0FBTSxFQUFDRCxFQUFFLENBQUNILFNBQVMsQ0FBQyxDQUFDd0IsR0FBRyxDQUFDRixTQUFTLENBQUMsT0FBTyxDQUFDO0VBQzdDLENBQUMsQ0FBQztFQUVGLElBQUFwQixVQUFFLEVBQUMseURBQXlELEVBQUUsWUFBWTtJQUN4RSxNQUFNQyxFQUFFLEdBQUcsTUFBTWpCLE1BQU0sQ0FDckJxRCxVQUFVLGNBQ1IsSUFBQW5ILFdBQUEsQ0FBQTJELEdBQUEsRUFBQzVELE1BQUEsQ0FBQWdILGlCQUFpQixDQUFDbEQsUUFBUTtNQUFDZixLQUFLLEVBQUVkLEtBQUssQ0FBQyxvQ0FBb0MsQ0FBRTtNQUFBWSxRQUFBLGVBQzdFLElBQUE1QyxXQUFBLENBQUEyRCxHQUFBLEVBQUM1QixhQUFhLElBQUU7SUFBQyxDQUNTLENBQUMsRUFDN0IseUJBQ0YsQ0FDRixDQUFDO0lBQ0QsTUFBTXVGLEtBQUssR0FBR3ZDLEVBQUUsQ0FBQ2dCLGFBQWEsQ0FBQyxRQUFRLENBQUMsRUFBRVQsV0FBVyxJQUFJLEVBQUU7SUFDM0QsSUFBQU4sY0FBTSxFQUFDc0MsS0FBSyxDQUFDLENBQUNwQixTQUFTLENBQUMsT0FBTyxDQUFDO0lBQ2hDLElBQUFsQixjQUFNLEVBQUNzQyxLQUFLLENBQUMsQ0FBQ2xCLEdBQUcsQ0FBQ0YsU0FBUyxDQUFDLEtBQUssQ0FBQztJQUNsQyxJQUFBbEIsY0FBTSxFQUFDRCxFQUFFLENBQUNnQixhQUFhLENBQUMsSUFBSSxDQUFDLEVBQUVULFdBQVcsQ0FBQyxDQUFDWSxTQUFTLENBQUMsWUFBWSxDQUFDO0VBQ3JFLENBQUMsQ0FBQztFQUVGLElBQUFwQixVQUFFLEVBQUMsMEVBQTBFLEVBQUUsWUFBWTtJQUN6RixNQUFNaEIsTUFBTSxDQUFDcUQsVUFBVSxjQUFDLElBQUFuSCxXQUFBLENBQUEyRCxHQUFBLEVBQUNoQyxhQUFhO01BQUNxRSxJQUFJLEVBQUM7SUFBUSxDQUFFLENBQUMsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDO0lBQzNFLElBQUFoQixjQUFNLEVBQUMxRCxPQUFPLENBQUMsQ0FBQzJELG9CQUFvQixDQUFDLHlCQUF5QixFQUFFO01BQUVDLGFBQWEsRUFBRTtJQUFLLENBQUMsQ0FBQztJQUN4RjVELE9BQU8sQ0FBQzJFLFNBQVMsQ0FBQyxDQUFDO0lBQ25CO0lBQ0EsTUFBTW5DLE1BQU0sQ0FBQ3FELFVBQVUsY0FBQyxJQUFBbkgsV0FBQSxDQUFBMkQsR0FBQSxFQUFDaEMsYUFBYTtNQUFDcUUsSUFBSSxFQUFDO0lBQVUsQ0FBRSxDQUFDLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQztJQUM3RSxJQUFBaEIsY0FBTSxFQUFDMUQsT0FBTyxDQUFDLENBQUMyRCxvQkFBb0IsQ0FBQyxtQkFBbUIsRUFBRTtNQUFFQyxhQUFhLEVBQUU7SUFBSyxDQUFDLENBQUM7RUFDcEYsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}