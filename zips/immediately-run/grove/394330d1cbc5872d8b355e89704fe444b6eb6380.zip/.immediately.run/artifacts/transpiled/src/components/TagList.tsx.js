var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = TagList;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.for-each.js");
require("core-js/modules/esnext.iterator.map.js");
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
var _content = require("../lib/content");
var _wiki = require("../lib/wiki");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$();
/* eslint-disable @typescript-eslint/no-explicit-any */
// `<TagList/>` — every content tag, sorted, as plain chips (the "related tags"
// strip on a tag page). Reserved `ui/*` chrome tags are excluded.
function TagList() {
  _s();
  const queryFn = (0, _react.useCallback)(fm => {
    const set = new Set();
    Object.entries(fm).forEach(([p, m]) => {
      if (!p.startsWith((0, _content.contentDir)())) return;
      (Array.isArray(m?.tags) ? m.tags : []).forEach(t => {
        if (!t.startsWith('ui/')) set.add(t);
      });
    });
    return Array.from(set).sort();
  }, []);
  const q = (0, _sdk.useMetadataQuery)(queryFn);
  const tags = (0, _wiki.queryPaths)(q);
  if (!tags.length) return null;
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    className: "grove-tagcloud",
    children: tags.map(t => /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
      className: "grove-tag",
      children: ["#", t]
    }, t))
  });
}
_s(TagList, "wwx07dpKidh/vhfuCH1U58t3SjM=", false, function () {
  return [_sdk.useMetadataQuery];
});
_c = TagList;
var _c;
$RefreshReg$(_c, "TagList");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NkayIsIl9jb250ZW50IiwiX3dpa2kiLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiVGFnTGlzdCIsInF1ZXJ5Rm4iLCJ1c2VDYWxsYmFjayIsImZtIiwic2V0IiwiU2V0IiwiT2JqZWN0IiwiZW50cmllcyIsImZvckVhY2giLCJwIiwibSIsInN0YXJ0c1dpdGgiLCJjb250ZW50RGlyIiwiQXJyYXkiLCJpc0FycmF5IiwidGFncyIsInQiLCJhZGQiLCJmcm9tIiwic29ydCIsInEiLCJ1c2VNZXRhZGF0YVF1ZXJ5IiwicXVlcnlQYXRocyIsImxlbmd0aCIsImpzeCIsImNsYXNzTmFtZSIsImNoaWxkcmVuIiwibWFwIiwianN4cyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiVGFnTGlzdC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueSAqL1xuaW1wb3J0IHsgdXNlQ2FsbGJhY2sgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VNZXRhZGF0YVF1ZXJ5IH0gZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9zZGsnO1xuaW1wb3J0IHsgY29udGVudERpciB9IGZyb20gJy4uL2xpYi9jb250ZW50JztcbmltcG9ydCB7IHF1ZXJ5UGF0aHMgfSBmcm9tICcuLi9saWIvd2lraSc7XG5cbi8vIGA8VGFnTGlzdC8+YCDigJQgZXZlcnkgY29udGVudCB0YWcsIHNvcnRlZCwgYXMgcGxhaW4gY2hpcHMgKHRoZSBcInJlbGF0ZWQgdGFnc1wiXG4vLyBzdHJpcCBvbiBhIHRhZyBwYWdlKS4gUmVzZXJ2ZWQgYHVpLypgIGNocm9tZSB0YWdzIGFyZSBleGNsdWRlZC5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFRhZ0xpc3QoKSB7XG4gIGNvbnN0IHF1ZXJ5Rm4gPSB1c2VDYWxsYmFjaygoZm06IFJlY29yZDxzdHJpbmcsIGFueT4pID0+IHtcbiAgICBjb25zdCBzZXQgPSBuZXcgU2V0PHN0cmluZz4oKTtcbiAgICBPYmplY3QuZW50cmllcyhmbSkuZm9yRWFjaCgoW3AsIG1dOiBbc3RyaW5nLCBhbnldKSA9PiB7XG4gICAgICBpZiAoIXAuc3RhcnRzV2l0aChjb250ZW50RGlyKCkpKSByZXR1cm47XG4gICAgICAoQXJyYXkuaXNBcnJheShtPy50YWdzKSA/IG0udGFncyA6IFtdKS5mb3JFYWNoKCh0OiBzdHJpbmcpID0+IHtcbiAgICAgICAgaWYgKCF0LnN0YXJ0c1dpdGgoJ3VpLycpKSBzZXQuYWRkKHQpO1xuICAgICAgfSk7XG4gICAgfSk7XG4gICAgcmV0dXJuIEFycmF5LmZyb20oc2V0KS5zb3J0KCk7XG4gIH0sIFtdKTtcbiAgY29uc3QgcSA9IHVzZU1ldGFkYXRhUXVlcnkocXVlcnlGbik7XG4gIGNvbnN0IHRhZ3M6IHN0cmluZ1tdID0gcXVlcnlQYXRocyhxKTtcblxuICBpZiAoIXRhZ3MubGVuZ3RoKSByZXR1cm4gbnVsbDtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImdyb3ZlLXRhZ2Nsb3VkXCI+XG4gICAgICB7dGFncy5tYXAoKHQpID0+IChcbiAgICAgICAgPHNwYW4ga2V5PXt0fSBjbGFzc05hbWU9XCJncm92ZS10YWdcIj4je3R9PC9zcGFuPlxuICAgICAgKSl9XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUNBLElBQUFBLE1BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLElBQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLFFBQUEsR0FBQUYsT0FBQTtBQUNBLElBQUFHLEtBQUEsR0FBQUgsT0FBQTtBQUF5QyxJQUFBSSxXQUFBLEdBQUFKLE9BQUE7QUFBQSxJQUFBSyxFQUFBLEdBQUFDLFlBQUE7QUFKekM7QUFNQTtBQUNBO0FBQ2UsU0FBU0MsT0FBT0EsQ0FBQSxFQUFHO0VBQUFGLEVBQUE7RUFDaEMsTUFBTUcsT0FBTyxHQUFHLElBQUFDLGtCQUFXLEVBQUVDLEVBQXVCLElBQUs7SUFDdkQsTUFBTUMsR0FBRyxHQUFHLElBQUlDLEdBQUcsQ0FBUyxDQUFDO0lBQzdCQyxNQUFNLENBQUNDLE9BQU8sQ0FBQ0osRUFBRSxDQUFDLENBQUNLLE9BQU8sQ0FBQyxDQUFDLENBQUNDLENBQUMsRUFBRUMsQ0FBQyxDQUFnQixLQUFLO01BQ3BELElBQUksQ0FBQ0QsQ0FBQyxDQUFDRSxVQUFVLENBQUMsSUFBQUMsbUJBQVUsRUFBQyxDQUFDLENBQUMsRUFBRTtNQUNqQyxDQUFDQyxLQUFLLENBQUNDLE9BQU8sQ0FBQ0osQ0FBQyxFQUFFSyxJQUFJLENBQUMsR0FBR0wsQ0FBQyxDQUFDSyxJQUFJLEdBQUcsRUFBRSxFQUFFUCxPQUFPLENBQUVRLENBQVMsSUFBSztRQUM1RCxJQUFJLENBQUNBLENBQUMsQ0FBQ0wsVUFBVSxDQUFDLEtBQUssQ0FBQyxFQUFFUCxHQUFHLENBQUNhLEdBQUcsQ0FBQ0QsQ0FBQyxDQUFDO01BQ3RDLENBQUMsQ0FBQztJQUNKLENBQUMsQ0FBQztJQUNGLE9BQU9ILEtBQUssQ0FBQ0ssSUFBSSxDQUFDZCxHQUFHLENBQUMsQ0FBQ2UsSUFBSSxDQUFDLENBQUM7RUFDL0IsQ0FBQyxFQUFFLEVBQUUsQ0FBQztFQUNOLE1BQU1DLENBQUMsR0FBRyxJQUFBQyxxQkFBZ0IsRUFBQ3BCLE9BQU8sQ0FBQztFQUNuQyxNQUFNYyxJQUFjLEdBQUcsSUFBQU8sZ0JBQVUsRUFBQ0YsQ0FBQyxDQUFDO0VBRXBDLElBQUksQ0FBQ0wsSUFBSSxDQUFDUSxNQUFNLEVBQUUsT0FBTyxJQUFJO0VBQzdCLG9CQUNFLElBQUExQixXQUFBLENBQUEyQixHQUFBO0lBQUtDLFNBQVMsRUFBQyxnQkFBZ0I7SUFBQUMsUUFBQSxFQUM1QlgsSUFBSSxDQUFDWSxHQUFHLENBQUVYLENBQUMsaUJBQ1YsSUFBQW5CLFdBQUEsQ0FBQStCLElBQUE7TUFBY0gsU0FBUyxFQUFDLFdBQVc7TUFBQUMsUUFBQSxHQUFDLEdBQUMsRUFBQ1YsQ0FBQztJQUFBLEdBQTVCQSxDQUFtQyxDQUMvQztFQUFDLENBQ0MsQ0FBQztBQUVWO0FBQUNsQixFQUFBLENBdEJ1QkUsT0FBTztFQUFBLFFBV25CcUIscUJBQWdCO0FBQUE7QUFBQVEsRUFBQSxHQVhKN0IsT0FBTztBQUFBLElBQUE2QixFQUFBO0FBQUFDLFlBQUEsQ0FBQUQsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}