var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.some.js");
var _vitest = require("vitest");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; } // @vitest-environment jsdom
// ONE case, in its own file, because it needs a module registry where the catalog has
// never been answered.
//
// `useCatalogAnswered`'s flag is module-global and never resets — correct for an app, in
// which the host answers once per realm, but it means any test that has already pushed an
// `api-catalog` poisons this one. Every case in `GroveAgent.test.tsx` pushes one. Vitest
// isolates by file, so a separate file IS the isolation; the harness is shared rather
// than copied (`src/test/groveAgentHarness.tsx`).
//
// Why this case exists at all: round 3 showed the hook was not load-bearing for any
// component test — replacing `useCatalogAnswered()` with the literal `true`, i.e. exactly
// the behaviour the hook was written to replace, left all 506 tests green. The unit arm
// (`reachCard.test.ts`) and the hook itself were covered; the wire between them was not.
// That is round 1's blocking finding recurring one level up.
// `useHeadings` scans the DOM; `fs` is read only on the stuffing path, never here.
_vitest.vi.mock('fs', () => ({
  default: {
    promises: {
      readFile: _vitest.vi.fn(async () => '')
    }
  }
}));
_vitest.vi.mock('@immediately-run/sdk', async importOriginal => ({
  ...(await importOriginal()),
  runAgent: _vitest.vi.fn()
}));
const {
  renderAgent,
  openPanel,
  push
} = await Promise.resolve().then(() => _interopRequireWildcard(require('../../test/groveAgentHarness')));
(0, _vitest.describe)('R3-688 — before the catalog answers, the Q&A row names no cause', () => {
  (0, _vitest.it)('renders neutral: not a guessed consent state, not a guessed key state, no chips', async () => {
    // No catalog push at all. The provider HAS answered `{ provider: null }`, which on a
    // pre-mark host is what both a keyless frame and an ungranted fork receive — so the
    // grant is genuinely unknown and the card must say nothing rather than pick one.
    const {
      container
    } = await renderAgent({
      writable: true
    });
    await push({
      type: 'llm-provider',
      provider: null
    });
    await openPanel(container);
    const text = container.textContent ?? '';
    (0, _vitest.expect)(text).toContain('Answer questions about this wiki');
    (0, _vitest.expect)(text).not.toContain("wasn't granted chat");
    (0, _vitest.expect)(text).not.toContain('no model key connected');
    // No Q&A chips. Not "no chips at all": `writable: true` makes the Draft row ✓ and it
    // contributes its own, which is correct and has nothing to do with the catalog.
    const chips = [...container.querySelectorAll('.ga-chip')].map(c => c.textContent ?? '');
    (0, _vitest.expect)(chips.some(c => /summarize|tagged security/i.test(c))).toBe(false);
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZXN0IiwicmVxdWlyZSIsIl9nZXRSZXF1aXJlV2lsZGNhcmRDYWNoZSIsImUiLCJXZWFrTWFwIiwiciIsInQiLCJfaW50ZXJvcFJlcXVpcmVXaWxkY2FyZCIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiaGFzIiwiZ2V0IiwibiIsIl9fcHJvdG9fXyIsImEiLCJPYmplY3QiLCJkZWZpbmVQcm9wZXJ0eSIsImdldE93blByb3BlcnR5RGVzY3JpcHRvciIsInUiLCJoYXNPd25Qcm9wZXJ0eSIsImNhbGwiLCJpIiwic2V0IiwidmkiLCJtb2NrIiwicHJvbWlzZXMiLCJyZWFkRmlsZSIsImZuIiwiaW1wb3J0T3JpZ2luYWwiLCJydW5BZ2VudCIsInJlbmRlckFnZW50Iiwib3BlblBhbmVsIiwicHVzaCIsIlByb21pc2UiLCJyZXNvbHZlIiwidGhlbiIsImRlc2NyaWJlIiwiaXQiLCJjb250YWluZXIiLCJ3cml0YWJsZSIsInR5cGUiLCJwcm92aWRlciIsInRleHQiLCJ0ZXh0Q29udGVudCIsImV4cGVjdCIsInRvQ29udGFpbiIsIm5vdCIsImNoaXBzIiwicXVlcnlTZWxlY3RvckFsbCIsIm1hcCIsImMiLCJzb21lIiwidGVzdCIsInRvQmUiXSwic291cmNlcyI6WyJHcm92ZUFnZW50LnVuYW5zd2VyZWQudGVzdC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gQHZpdGVzdC1lbnZpcm9ubWVudCBqc2RvbVxuLy8gT05FIGNhc2UsIGluIGl0cyBvd24gZmlsZSwgYmVjYXVzZSBpdCBuZWVkcyBhIG1vZHVsZSByZWdpc3RyeSB3aGVyZSB0aGUgY2F0YWxvZyBoYXNcbi8vIG5ldmVyIGJlZW4gYW5zd2VyZWQuXG4vL1xuLy8gYHVzZUNhdGFsb2dBbnN3ZXJlZGAncyBmbGFnIGlzIG1vZHVsZS1nbG9iYWwgYW5kIG5ldmVyIHJlc2V0cyDigJQgY29ycmVjdCBmb3IgYW4gYXBwLCBpblxuLy8gd2hpY2ggdGhlIGhvc3QgYW5zd2VycyBvbmNlIHBlciByZWFsbSwgYnV0IGl0IG1lYW5zIGFueSB0ZXN0IHRoYXQgaGFzIGFscmVhZHkgcHVzaGVkIGFuXG4vLyBgYXBpLWNhdGFsb2dgIHBvaXNvbnMgdGhpcyBvbmUuIEV2ZXJ5IGNhc2UgaW4gYEdyb3ZlQWdlbnQudGVzdC50c3hgIHB1c2hlcyBvbmUuIFZpdGVzdFxuLy8gaXNvbGF0ZXMgYnkgZmlsZSwgc28gYSBzZXBhcmF0ZSBmaWxlIElTIHRoZSBpc29sYXRpb247IHRoZSBoYXJuZXNzIGlzIHNoYXJlZCByYXRoZXJcbi8vIHRoYW4gY29waWVkIChgc3JjL3Rlc3QvZ3JvdmVBZ2VudEhhcm5lc3MudHN4YCkuXG4vL1xuLy8gV2h5IHRoaXMgY2FzZSBleGlzdHMgYXQgYWxsOiByb3VuZCAzIHNob3dlZCB0aGUgaG9vayB3YXMgbm90IGxvYWQtYmVhcmluZyBmb3IgYW55XG4vLyBjb21wb25lbnQgdGVzdCDigJQgcmVwbGFjaW5nIGB1c2VDYXRhbG9nQW5zd2VyZWQoKWAgd2l0aCB0aGUgbGl0ZXJhbCBgdHJ1ZWAsIGkuZS4gZXhhY3RseVxuLy8gdGhlIGJlaGF2aW91ciB0aGUgaG9vayB3YXMgd3JpdHRlbiB0byByZXBsYWNlLCBsZWZ0IGFsbCA1MDYgdGVzdHMgZ3JlZW4uIFRoZSB1bml0IGFybVxuLy8gKGByZWFjaENhcmQudGVzdC50c2ApIGFuZCB0aGUgaG9vayBpdHNlbGYgd2VyZSBjb3ZlcmVkOyB0aGUgd2lyZSBiZXR3ZWVuIHRoZW0gd2FzIG5vdC5cbi8vIFRoYXQgaXMgcm91bmQgMSdzIGJsb2NraW5nIGZpbmRpbmcgcmVjdXJyaW5nIG9uZSBsZXZlbCB1cC5cbmltcG9ydCB7IGRlc2NyaWJlLCBpdCwgZXhwZWN0LCB2aSB9IGZyb20gJ3ZpdGVzdCc7XG5cbi8vIGB1c2VIZWFkaW5nc2Agc2NhbnMgdGhlIERPTTsgYGZzYCBpcyByZWFkIG9ubHkgb24gdGhlIHN0dWZmaW5nIHBhdGgsIG5ldmVyIGhlcmUuXG52aS5tb2NrKCdmcycsICgpID0+ICh7IGRlZmF1bHQ6IHsgcHJvbWlzZXM6IHsgcmVhZEZpbGU6IHZpLmZuKGFzeW5jICgpID0+ICcnKSB9IH0gfSkpO1xudmkubW9jaygnQGltbWVkaWF0ZWx5LXJ1bi9zZGsnLCBhc3luYyAoaW1wb3J0T3JpZ2luYWwpID0+ICh7XG4gIC4uLihhd2FpdCBpbXBvcnRPcmlnaW5hbDx0eXBlb2YgaW1wb3J0KCdAaW1tZWRpYXRlbHktcnVuL3NkaycpPigpKSxcbiAgcnVuQWdlbnQ6IHZpLmZuKCksXG59KSk7XG5cbmNvbnN0IHsgcmVuZGVyQWdlbnQsIG9wZW5QYW5lbCwgcHVzaCB9ID0gYXdhaXQgaW1wb3J0KCcuLi8uLi90ZXN0L2dyb3ZlQWdlbnRIYXJuZXNzJyk7XG5cbmRlc2NyaWJlKCdSMy02ODgg4oCUIGJlZm9yZSB0aGUgY2F0YWxvZyBhbnN3ZXJzLCB0aGUgUSZBIHJvdyBuYW1lcyBubyBjYXVzZScsICgpID0+IHtcbiAgaXQoJ3JlbmRlcnMgbmV1dHJhbDogbm90IGEgZ3Vlc3NlZCBjb25zZW50IHN0YXRlLCBub3QgYSBndWVzc2VkIGtleSBzdGF0ZSwgbm8gY2hpcHMnLCBhc3luYyAoKSA9PiB7XG4gICAgLy8gTm8gY2F0YWxvZyBwdXNoIGF0IGFsbC4gVGhlIHByb3ZpZGVyIEhBUyBhbnN3ZXJlZCBgeyBwcm92aWRlcjogbnVsbCB9YCwgd2hpY2ggb24gYVxuICAgIC8vIHByZS1tYXJrIGhvc3QgaXMgd2hhdCBib3RoIGEga2V5bGVzcyBmcmFtZSBhbmQgYW4gdW5ncmFudGVkIGZvcmsgcmVjZWl2ZSDigJQgc28gdGhlXG4gICAgLy8gZ3JhbnQgaXMgZ2VudWluZWx5IHVua25vd24gYW5kIHRoZSBjYXJkIG11c3Qgc2F5IG5vdGhpbmcgcmF0aGVyIHRoYW4gcGljayBvbmUuXG4gICAgY29uc3QgeyBjb250YWluZXIgfSA9IGF3YWl0IHJlbmRlckFnZW50KHsgd3JpdGFibGU6IHRydWUgfSk7XG4gICAgYXdhaXQgcHVzaCh7IHR5cGU6ICdsbG0tcHJvdmlkZXInLCBwcm92aWRlcjogbnVsbCB9KTtcbiAgICBhd2FpdCBvcGVuUGFuZWwoY29udGFpbmVyKTtcbiAgICBjb25zdCB0ZXh0ID0gY29udGFpbmVyLnRleHRDb250ZW50ID8/ICcnO1xuXG4gICAgZXhwZWN0KHRleHQpLnRvQ29udGFpbignQW5zd2VyIHF1ZXN0aW9ucyBhYm91dCB0aGlzIHdpa2knKTtcbiAgICBleHBlY3QodGV4dCkubm90LnRvQ29udGFpbihcIndhc24ndCBncmFudGVkIGNoYXRcIik7XG4gICAgZXhwZWN0KHRleHQpLm5vdC50b0NvbnRhaW4oJ25vIG1vZGVsIGtleSBjb25uZWN0ZWQnKTtcbiAgICAvLyBObyBRJkEgY2hpcHMuIE5vdCBcIm5vIGNoaXBzIGF0IGFsbFwiOiBgd3JpdGFibGU6IHRydWVgIG1ha2VzIHRoZSBEcmFmdCByb3cg4pyTIGFuZCBpdFxuICAgIC8vIGNvbnRyaWJ1dGVzIGl0cyBvd24sIHdoaWNoIGlzIGNvcnJlY3QgYW5kIGhhcyBub3RoaW5nIHRvIGRvIHdpdGggdGhlIGNhdGFsb2cuXG4gICAgY29uc3QgY2hpcHMgPSBbLi4uY29udGFpbmVyLnF1ZXJ5U2VsZWN0b3JBbGwoJy5nYS1jaGlwJyldLm1hcCgoYykgPT4gYy50ZXh0Q29udGVudCA/PyAnJyk7XG4gICAgZXhwZWN0KGNoaXBzLnNvbWUoKGMpID0+IC9zdW1tYXJpemV8dGFnZ2VkIHNlY3VyaXR5L2kudGVzdChjKSkpLnRvQmUoZmFsc2UpO1xuICB9KTtcbn0pO1xuIl0sIm1hcHBpbmdzIjoiOzs7O0FBZUEsSUFBQUEsT0FBQSxHQUFBQyxPQUFBO0FBQWtELFNBQUFDLHlCQUFBQyxDQUFBLDZCQUFBQyxPQUFBLG1CQUFBQyxDQUFBLE9BQUFELE9BQUEsSUFBQUUsQ0FBQSxPQUFBRixPQUFBLFlBQUFGLHdCQUFBLFlBQUFBLENBQUFDLENBQUEsV0FBQUEsQ0FBQSxHQUFBRyxDQUFBLEdBQUFELENBQUEsS0FBQUYsQ0FBQTtBQUFBLFNBQUFJLHdCQUFBSixDQUFBLEVBQUFFLENBQUEsU0FBQUEsQ0FBQSxJQUFBRixDQUFBLElBQUFBLENBQUEsQ0FBQUssVUFBQSxTQUFBTCxDQUFBLGVBQUFBLENBQUEsdUJBQUFBLENBQUEseUJBQUFBLENBQUEsV0FBQU0sT0FBQSxFQUFBTixDQUFBLFFBQUFHLENBQUEsR0FBQUosd0JBQUEsQ0FBQUcsQ0FBQSxPQUFBQyxDQUFBLElBQUFBLENBQUEsQ0FBQUksR0FBQSxDQUFBUCxDQUFBLFVBQUFHLENBQUEsQ0FBQUssR0FBQSxDQUFBUixDQUFBLE9BQUFTLENBQUEsS0FBQUMsU0FBQSxVQUFBQyxDQUFBLEdBQUFDLE1BQUEsQ0FBQUMsY0FBQSxJQUFBRCxNQUFBLENBQUFFLHdCQUFBLFdBQUFDLENBQUEsSUFBQWYsQ0FBQSxvQkFBQWUsQ0FBQSxPQUFBQyxjQUFBLENBQUFDLElBQUEsQ0FBQWpCLENBQUEsRUFBQWUsQ0FBQSxTQUFBRyxDQUFBLEdBQUFQLENBQUEsR0FBQUMsTUFBQSxDQUFBRSx3QkFBQSxDQUFBZCxDQUFBLEVBQUFlLENBQUEsVUFBQUcsQ0FBQSxLQUFBQSxDQUFBLENBQUFWLEdBQUEsSUFBQVUsQ0FBQSxDQUFBQyxHQUFBLElBQUFQLE1BQUEsQ0FBQUMsY0FBQSxDQUFBSixDQUFBLEVBQUFNLENBQUEsRUFBQUcsQ0FBQSxJQUFBVCxDQUFBLENBQUFNLENBQUEsSUFBQWYsQ0FBQSxDQUFBZSxDQUFBLFlBQUFOLENBQUEsQ0FBQUgsT0FBQSxHQUFBTixDQUFBLEVBQUFHLENBQUEsSUFBQUEsQ0FBQSxDQUFBZ0IsR0FBQSxDQUFBbkIsQ0FBQSxFQUFBUyxDQUFBLEdBQUFBLENBQUEsSUFmbEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBR0E7QUFDQVcsVUFBRSxDQUFDQyxJQUFJLENBQUMsSUFBSSxFQUFFLE9BQU87RUFBRWYsT0FBTyxFQUFFO0lBQUVnQixRQUFRLEVBQUU7TUFBRUMsUUFBUSxFQUFFSCxVQUFFLENBQUNJLEVBQUUsQ0FBQyxZQUFZLEVBQUU7SUFBRTtFQUFFO0FBQUUsQ0FBQyxDQUFDLENBQUM7QUFDckZKLFVBQUUsQ0FBQ0MsSUFBSSxDQUFDLHNCQUFzQixFQUFFLE1BQU9JLGNBQWMsS0FBTTtFQUN6RCxJQUFJLE1BQU1BLGNBQWMsQ0FBd0MsQ0FBQyxDQUFDO0VBQ2xFQyxRQUFRLEVBQUVOLFVBQUUsQ0FBQ0ksRUFBRSxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDO0FBRUgsTUFBTTtFQUFFRyxXQUFXO0VBQUVDLFNBQVM7RUFBRUM7QUFBSyxDQUFDLEdBQUcsTUFBQUMsT0FBQSxDQUFBQyxPQUFBLEdBQUFDLElBQUEsT0FBQTVCLHVCQUFBLENBQUFOLE9BQUEsQ0FBYSw4QkFBOEIsR0FBQztBQUVyRixJQUFBbUMsZ0JBQVEsRUFBQyxpRUFBaUUsRUFBRSxNQUFNO0VBQ2hGLElBQUFDLFVBQUUsRUFBQyxpRkFBaUYsRUFBRSxZQUFZO0lBQ2hHO0lBQ0E7SUFDQTtJQUNBLE1BQU07TUFBRUM7SUFBVSxDQUFDLEdBQUcsTUFBTVIsV0FBVyxDQUFDO01BQUVTLFFBQVEsRUFBRTtJQUFLLENBQUMsQ0FBQztJQUMzRCxNQUFNUCxJQUFJLENBQUM7TUFBRVEsSUFBSSxFQUFFLGNBQWM7TUFBRUMsUUFBUSxFQUFFO0lBQUssQ0FBQyxDQUFDO0lBQ3BELE1BQU1WLFNBQVMsQ0FBQ08sU0FBUyxDQUFDO0lBQzFCLE1BQU1JLElBQUksR0FBR0osU0FBUyxDQUFDSyxXQUFXLElBQUksRUFBRTtJQUV4QyxJQUFBQyxjQUFNLEVBQUNGLElBQUksQ0FBQyxDQUFDRyxTQUFTLENBQUMsa0NBQWtDLENBQUM7SUFDMUQsSUFBQUQsY0FBTSxFQUFDRixJQUFJLENBQUMsQ0FBQ0ksR0FBRyxDQUFDRCxTQUFTLENBQUMscUJBQXFCLENBQUM7SUFDakQsSUFBQUQsY0FBTSxFQUFDRixJQUFJLENBQUMsQ0FBQ0ksR0FBRyxDQUFDRCxTQUFTLENBQUMsd0JBQXdCLENBQUM7SUFDcEQ7SUFDQTtJQUNBLE1BQU1FLEtBQUssR0FBRyxDQUFDLEdBQUdULFNBQVMsQ0FBQ1UsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQ0MsR0FBRyxDQUFFQyxDQUFDLElBQUtBLENBQUMsQ0FBQ1AsV0FBVyxJQUFJLEVBQUUsQ0FBQztJQUN6RixJQUFBQyxjQUFNLEVBQUNHLEtBQUssQ0FBQ0ksSUFBSSxDQUFFRCxDQUFDLElBQUssNEJBQTRCLENBQUNFLElBQUksQ0FBQ0YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDRyxJQUFJLENBQUMsS0FBSyxDQUFDO0VBQzdFLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}