var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Drawer;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
var _sdk = require("@immediately-run/sdk");
var _useOverlayFocusDismiss = require("../hooks/useOverlayFocusDismiss");
var _Sidebar = _interopRequireDefault(require("./Sidebar"));
var _Icon = _interopRequireDefault(require("./Icon"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$();
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// `.grove-drawer` — the mobile nav drawer: site mark + nav items + the full
// namespace tree, over a dismiss scrim. The panel carries the dialog contract
// (R3-608): focus in, Tab trapped, Escape, focus return — via the shared
// overlay hook, whose stack makes nested overlays close one per Escape.
function Drawer({
  siteTitle,
  nav,
  onClose
}) {
  _s();
  const dialogRef = (0, _useOverlayFocusDismiss.useOverlayFocusDismiss)(true, onClose);
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    className: "grove-drawer",
    onClick: onClose,
    children: /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "grove-drawer__panel",
      ref: dialogRef,
      tabIndex: -1,
      role: "dialog",
      "aria-modal": "true",
      "aria-label": "Site menu",
      onClick: e => e.stopPropagation(),
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "grove-drawer__h",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "mk"
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "t",
          children: siteTitle
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          className: "x",
          "aria-label": "Close menu",
          onClick: onClose,
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
            name: "x"
          })
        })]
      }), nav.length ? /*#__PURE__*/(0, _jsxRuntime.jsx)("nav", {
        className: "grove-drawer__nav",
        children: nav.map(n => /*#__PURE__*/(0, _jsxRuntime.jsx)(_sdk.Link, {
          href: n.href,
          "data-cur": n.cur ? '1' : '0',
          onClick: onClose,
          children: n.label
        }, n.href))
      }) : null, /*#__PURE__*/(0, _jsxRuntime.jsx)(_Sidebar.default, {})]
    })
  });
}
_s(Drawer, "OWMT8rFJZTUp56ag0XCFLDkYo5o=", false, function () {
  return [_useOverlayFocusDismiss.useOverlayFocusDismiss];
});
_c = Drawer;
var _c;
$RefreshReg$(_c, "Drawer");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfc2RrIiwicmVxdWlyZSIsIl91c2VPdmVybGF5Rm9jdXNEaXNtaXNzIiwiX1NpZGViYXIiLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX0ljb24iLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiRHJhd2VyIiwic2l0ZVRpdGxlIiwibmF2Iiwib25DbG9zZSIsImRpYWxvZ1JlZiIsInVzZU92ZXJsYXlGb2N1c0Rpc21pc3MiLCJqc3giLCJjbGFzc05hbWUiLCJvbkNsaWNrIiwiY2hpbGRyZW4iLCJqc3hzIiwicmVmIiwidGFiSW5kZXgiLCJyb2xlIiwic3RvcFByb3BhZ2F0aW9uIiwibmFtZSIsImxlbmd0aCIsIm1hcCIsIm4iLCJMaW5rIiwiaHJlZiIsImN1ciIsImxhYmVsIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJEcmF3ZXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IExpbmsgfSBmcm9tICdAaW1tZWRpYXRlbHktcnVuL3Nkayc7XG5pbXBvcnQgeyB1c2VPdmVybGF5Rm9jdXNEaXNtaXNzIH0gZnJvbSAnLi4vaG9va3MvdXNlT3ZlcmxheUZvY3VzRGlzbWlzcyc7XG5pbXBvcnQgU2lkZWJhciBmcm9tICcuL1NpZGViYXInO1xuaW1wb3J0IEljb24gZnJvbSAnLi9JY29uJztcblxuaW50ZXJmYWNlIE5hdkl0ZW0ge1xuICBocmVmOiBzdHJpbmc7XG4gIGxhYmVsOiBzdHJpbmc7XG4gIGN1cjogYm9vbGVhbjtcbn1cblxuLy8gYC5ncm92ZS1kcmF3ZXJgIOKAlCB0aGUgbW9iaWxlIG5hdiBkcmF3ZXI6IHNpdGUgbWFyayArIG5hdiBpdGVtcyArIHRoZSBmdWxsXG4vLyBuYW1lc3BhY2UgdHJlZSwgb3ZlciBhIGRpc21pc3Mgc2NyaW0uIFRoZSBwYW5lbCBjYXJyaWVzIHRoZSBkaWFsb2cgY29udHJhY3Rcbi8vIChSMy02MDgpOiBmb2N1cyBpbiwgVGFiIHRyYXBwZWQsIEVzY2FwZSwgZm9jdXMgcmV0dXJuIOKAlCB2aWEgdGhlIHNoYXJlZFxuLy8gb3ZlcmxheSBob29rLCB3aG9zZSBzdGFjayBtYWtlcyBuZXN0ZWQgb3ZlcmxheXMgY2xvc2Ugb25lIHBlciBFc2NhcGUuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBEcmF3ZXIoe1xuICBzaXRlVGl0bGUsXG4gIG5hdixcbiAgb25DbG9zZSxcbn06IHtcbiAgc2l0ZVRpdGxlOiBzdHJpbmc7XG4gIG5hdjogTmF2SXRlbVtdO1xuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xufSkge1xuICBjb25zdCBkaWFsb2dSZWYgPSB1c2VPdmVybGF5Rm9jdXNEaXNtaXNzKHRydWUsIG9uQ2xvc2UpO1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JvdmUtZHJhd2VyXCIgb25DbGljaz17b25DbG9zZX0+XG4gICAgICA8ZGl2XG4gICAgICAgIGNsYXNzTmFtZT1cImdyb3ZlLWRyYXdlcl9fcGFuZWxcIlxuICAgICAgICByZWY9e2RpYWxvZ1JlZn1cbiAgICAgICAgdGFiSW5kZXg9ey0xfVxuICAgICAgICByb2xlPVwiZGlhbG9nXCJcbiAgICAgICAgYXJpYS1tb2RhbD1cInRydWVcIlxuICAgICAgICBhcmlhLWxhYmVsPVwiU2l0ZSBtZW51XCJcbiAgICAgICAgb25DbGljaz17KGUpID0+IGUuc3RvcFByb3BhZ2F0aW9uKCl9XG4gICAgICA+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JvdmUtZHJhd2VyX19oXCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWtcIiAvPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRcIj57c2l0ZVRpdGxlfTwvc3Bhbj5cbiAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cInhcIiBhcmlhLWxhYmVsPVwiQ2xvc2UgbWVudVwiIG9uQ2xpY2s9e29uQ2xvc2V9PlxuICAgICAgICAgICAgPEljb24gbmFtZT1cInhcIiAvPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAge25hdi5sZW5ndGggPyAoXG4gICAgICAgICAgPG5hdiBjbGFzc05hbWU9XCJncm92ZS1kcmF3ZXJfX25hdlwiPlxuICAgICAgICAgICAge25hdi5tYXAoKG4pID0+IChcbiAgICAgICAgICAgICAgPExpbmsga2V5PXtuLmhyZWZ9IGhyZWY9e24uaHJlZn0gZGF0YS1jdXI9e24uY3VyID8gJzEnIDogJzAnfSBvbkNsaWNrPXtvbkNsb3NlfT5cbiAgICAgICAgICAgICAgICB7bi5sYWJlbH1cbiAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9uYXY+XG4gICAgICAgICkgOiBudWxsfVxuICAgICAgICA8U2lkZWJhciAvPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUEsSUFBQUEsSUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsdUJBQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLFFBQUEsR0FBQUMsc0JBQUEsQ0FBQUgsT0FBQTtBQUNBLElBQUFJLEtBQUEsR0FBQUQsc0JBQUEsQ0FBQUgsT0FBQTtBQUEwQixJQUFBSyxXQUFBLEdBQUFMLE9BQUE7QUFBQSxJQUFBTSxFQUFBLEdBQUFDLFlBQUE7QUFBQSxTQUFBSix1QkFBQUssQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQVExQjtBQUNBO0FBQ0E7QUFDQTtBQUNlLFNBQVNHLE1BQU1BLENBQUM7RUFDN0JDLFNBQVM7RUFDVEMsR0FBRztFQUNIQztBQUtGLENBQUMsRUFBRTtFQUFBUixFQUFBO0VBQ0QsTUFBTVMsU0FBUyxHQUFHLElBQUFDLDhDQUFzQixFQUFDLElBQUksRUFBRUYsT0FBTyxDQUFDO0VBQ3ZELG9CQUNFLElBQUFULFdBQUEsQ0FBQVksR0FBQTtJQUFLQyxTQUFTLEVBQUMsY0FBYztJQUFDQyxPQUFPLEVBQUVMLE9BQVE7SUFBQU0sUUFBQSxlQUM3QyxJQUFBZixXQUFBLENBQUFnQixJQUFBO01BQ0VILFNBQVMsRUFBQyxxQkFBcUI7TUFDL0JJLEdBQUcsRUFBRVAsU0FBVTtNQUNmUSxRQUFRLEVBQUUsQ0FBQyxDQUFFO01BQ2JDLElBQUksRUFBQyxRQUFRO01BQ2IsY0FBVyxNQUFNO01BQ2pCLGNBQVcsV0FBVztNQUN0QkwsT0FBTyxFQUFHWCxDQUFDLElBQUtBLENBQUMsQ0FBQ2lCLGVBQWUsQ0FBQyxDQUFFO01BQUFMLFFBQUEsZ0JBRXBDLElBQUFmLFdBQUEsQ0FBQWdCLElBQUE7UUFBS0gsU0FBUyxFQUFDLGlCQUFpQjtRQUFBRSxRQUFBLGdCQUM5QixJQUFBZixXQUFBLENBQUFZLEdBQUE7VUFBTUMsU0FBUyxFQUFDO1FBQUksQ0FBRSxDQUFDLGVBQ3ZCLElBQUFiLFdBQUEsQ0FBQVksR0FBQTtVQUFNQyxTQUFTLEVBQUMsR0FBRztVQUFBRSxRQUFBLEVBQUVSO1FBQVMsQ0FBTyxDQUFDLGVBQ3RDLElBQUFQLFdBQUEsQ0FBQVksR0FBQTtVQUFRQyxTQUFTLEVBQUMsR0FBRztVQUFDLGNBQVcsWUFBWTtVQUFDQyxPQUFPLEVBQUVMLE9BQVE7VUFBQU0sUUFBQSxlQUM3RCxJQUFBZixXQUFBLENBQUFZLEdBQUEsRUFBQ2IsS0FBQSxDQUFBTSxPQUFJO1lBQUNnQixJQUFJLEVBQUM7VUFBRyxDQUFFO1FBQUMsQ0FDWCxDQUFDO01BQUEsQ0FDTixDQUFDLEVBQ0xiLEdBQUcsQ0FBQ2MsTUFBTSxnQkFDVCxJQUFBdEIsV0FBQSxDQUFBWSxHQUFBO1FBQUtDLFNBQVMsRUFBQyxtQkFBbUI7UUFBQUUsUUFBQSxFQUMvQlAsR0FBRyxDQUFDZSxHQUFHLENBQUVDLENBQUMsaUJBQ1QsSUFBQXhCLFdBQUEsQ0FBQVksR0FBQSxFQUFDbEIsSUFBQSxDQUFBK0IsSUFBSTtVQUFjQyxJQUFJLEVBQUVGLENBQUMsQ0FBQ0UsSUFBSztVQUFDLFlBQVVGLENBQUMsQ0FBQ0csR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFJO1VBQUNiLE9BQU8sRUFBRUwsT0FBUTtVQUFBTSxRQUFBLEVBQzVFUyxDQUFDLENBQUNJO1FBQUssR0FEQ0osQ0FBQyxDQUFDRSxJQUVQLENBQ1A7TUFBQyxDQUNDLENBQUMsR0FDSixJQUFJLGVBQ1IsSUFBQTFCLFdBQUEsQ0FBQVksR0FBQSxFQUFDZixRQUFBLENBQUFRLE9BQU8sSUFBRSxDQUFDO0lBQUEsQ0FDUjtFQUFDLENBQ0gsQ0FBQztBQUVWO0FBQUNKLEVBQUEsQ0F6Q3VCSyxNQUFNO0VBQUEsUUFTVkssOENBQXNCO0FBQUE7QUFBQWtCLEVBQUEsR0FUbEJ2QixNQUFNO0FBQUEsSUFBQXVCLEVBQUE7QUFBQUMsWUFBQSxDQUFBRCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}