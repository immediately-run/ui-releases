var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = KeyValue;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
var _jsxRuntime = require("react/jsx-runtime");
// Import-free engine component: a compact definition list of label/value pairs
// (contact details, metadata, quick facts). `label` is set in Space Mono and
// uppercased; `value` may be a string or any ReactNode, so links and inline
// code compose naturally. Rendered as a <dl> of <dt>/<dd> pairs with hairline
// row separators and a panel background, using the same design tokens as the
// rest of the component vocabulary.
function KeyValue({
  pairs
}) {
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("dl", {
    className: "grove-keyvalue",
    children: pairs.map((p, i) => /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "grove-keyvalue__row",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("dt", {
        className: "grove-keyvalue__label",
        children: p.label
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("dd", {
        className: "grove-keyvalue__value",
        children: p.value
      })]
    }, i))
  });
}
_c = KeyValue;
var _c;
$RefreshReg$(_c, "KeyValue");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJLZXlWYWx1ZSIsInBhaXJzIiwiX2pzeFJ1bnRpbWUiLCJqc3giLCJjbGFzc05hbWUiLCJjaGlsZHJlbiIsIm1hcCIsInAiLCJpIiwianN4cyIsImxhYmVsIiwidmFsdWUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIktleVZhbHVlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IFJlYWN0Tm9kZSB9IGZyb20gJ3JlYWN0JztcblxuaW50ZXJmYWNlIFBhaXIge1xuICAvKiogTGFiZWwg4oCUIHJlbmRlcmVkIGluIFNwYWNlIE1vbm8sIHVwcGVyY2FzZWQuICovXG4gIGxhYmVsOiBzdHJpbmc7XG4gIC8qKiBWYWx1ZSDigJQgYSBwbGFpbiBzdHJpbmcgb3IgYXJiaXRyYXJ5IFJlYWN0Tm9kZSAobGlua3MsIGNvZGUsIGV0Yy4pLiAqL1xuICB2YWx1ZTogUmVhY3ROb2RlO1xufVxuXG5pbnRlcmZhY2UgUHJvcHMge1xuICAvKiogTGFiZWwvdmFsdWUgcGFpcnMsIHJlbmRlcmVkIHRvcC10by1ib3R0b20gYXMgPGR0Pi88ZGQ+IHJvd3MuICovXG4gIHBhaXJzOiBQYWlyW107XG59XG5cbi8vIEltcG9ydC1mcmVlIGVuZ2luZSBjb21wb25lbnQ6IGEgY29tcGFjdCBkZWZpbml0aW9uIGxpc3Qgb2YgbGFiZWwvdmFsdWUgcGFpcnNcbi8vIChjb250YWN0IGRldGFpbHMsIG1ldGFkYXRhLCBxdWljayBmYWN0cykuIGBsYWJlbGAgaXMgc2V0IGluIFNwYWNlIE1vbm8gYW5kXG4vLyB1cHBlcmNhc2VkOyBgdmFsdWVgIG1heSBiZSBhIHN0cmluZyBvciBhbnkgUmVhY3ROb2RlLCBzbyBsaW5rcyBhbmQgaW5saW5lXG4vLyBjb2RlIGNvbXBvc2UgbmF0dXJhbGx5LiBSZW5kZXJlZCBhcyBhIDxkbD4gb2YgPGR0Pi88ZGQ+IHBhaXJzIHdpdGggaGFpcmxpbmVcbi8vIHJvdyBzZXBhcmF0b3JzIGFuZCBhIHBhbmVsIGJhY2tncm91bmQsIHVzaW5nIHRoZSBzYW1lIGRlc2lnbiB0b2tlbnMgYXMgdGhlXG4vLyByZXN0IG9mIHRoZSBjb21wb25lbnQgdm9jYWJ1bGFyeS5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEtleVZhbHVlKHsgcGFpcnMgfTogUHJvcHMpIHtcbiAgcmV0dXJuIChcbiAgICA8ZGwgY2xhc3NOYW1lPVwiZ3JvdmUta2V5dmFsdWVcIj5cbiAgICAgIHtwYWlycy5tYXAoKHAsIGkpID0+IChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncm92ZS1rZXl2YWx1ZV9fcm93XCIga2V5PXtpfT5cbiAgICAgICAgICA8ZHQgY2xhc3NOYW1lPVwiZ3JvdmUta2V5dmFsdWVfX2xhYmVsXCI+e3AubGFiZWx9PC9kdD5cbiAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwiZ3JvdmUta2V5dmFsdWVfX3ZhbHVlXCI+e3AudmFsdWV9PC9kZD5cbiAgICAgICAgPC9kaXY+XG4gICAgICApKX1cbiAgICA8L2RsPlxuICApO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFjQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDZSxTQUFTQSxRQUFRQSxDQUFDO0VBQUVDO0FBQWEsQ0FBQyxFQUFFO0VBQ2pELG9CQUNFLElBQUFDLFdBQUEsQ0FBQUMsR0FBQTtJQUFJQyxTQUFTLEVBQUMsZ0JBQWdCO0lBQUFDLFFBQUEsRUFDM0JKLEtBQUssQ0FBQ0ssR0FBRyxDQUFDLENBQUNDLENBQUMsRUFBRUMsQ0FBQyxrQkFDZCxJQUFBTixXQUFBLENBQUFPLElBQUE7TUFBS0wsU0FBUyxFQUFDLHFCQUFxQjtNQUFBQyxRQUFBLGdCQUNsQyxJQUFBSCxXQUFBLENBQUFDLEdBQUE7UUFBSUMsU0FBUyxFQUFDLHVCQUF1QjtRQUFBQyxRQUFBLEVBQUVFLENBQUMsQ0FBQ0c7TUFBSyxDQUFLLENBQUMsZUFDcEQsSUFBQVIsV0FBQSxDQUFBQyxHQUFBO1FBQUlDLFNBQVMsRUFBQyx1QkFBdUI7UUFBQUMsUUFBQSxFQUFFRSxDQUFDLENBQUNJO01BQUssQ0FBSyxDQUFDO0lBQUEsR0FGWkgsQ0FHckMsQ0FDTjtFQUFDLENBQ0EsQ0FBQztBQUVUO0FBQUNJLEVBQUEsR0FYdUJaLFFBQVE7QUFBQSxJQUFBWSxFQUFBO0FBQUFDLFlBQUEsQ0FBQUQsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}