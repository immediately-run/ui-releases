"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useOpenWikiBoot = useOpenWikiBoot;
var _react = require("react");
var _mounts = require("@immediately-run/sdk/mounts");
var _tasks = require("@immediately-run/sdk/tasks");
var _contentRoot = require("../lib/contentRoot");
var _openWiki = require("../lib/openWiki");
// Boot resolution for the `open-wiki` provider (R3-169).
//
// Grove has two packagings and this is where they diverge, ONCE, before anything reads
// the corpus:
//
//   • FORK      — engine and corpus in one repo. No task input ever arrives; the content
//                 root stays `/app/content/` and this hook is a no-op.
//   • DISPATCH  — a caller invoked `open-wiki` with a directory delegation. The host
//                 mounts the corpus at a task-scoped chroot and we re-point the content
//                 root at it before the first entry renders.
//
// The distinction has to be settled BEFORE render, not during it: every helper that
// answers "is this key an entry / what is its href / which layouts wrap it" is built on
// the root, so a component that renders while the root is still the default would resolve
// against the VIEWER's corpus and then not re-resolve. Hence a gate, not a fallback.

/** How long a callee waits for its delegated mount before cancelling. Long enough for the
 *  host's mount announcement to land after the overlay mounts, short enough that a reader
 *  is not left looking at a blank frame until the §5.7.1 liveness bound fires. */
const MOUNT_GRACE_MS = 5_000;
function useOpenWikiBoot() {
  const input = (0, _tasks.useTaskInput)();
  const mounts = (0, _mounts.useMounts)();
  const [failed, setFailed] = (0, _react.useState)('');
  const resolution = (0, _openWiki.resolveOpenWiki)(input, mounts ?? [], (0, _mounts.getAppMountPath)());
  if (resolution.ok) {
    // Setting the root is what makes the corpus readable, so it happens in render — an
    // effect would run AFTER the first content render, which is the whole failure this
    // gate exists to prevent. Idempotent and purely derived, so a StrictMode double
    // render sets the same value twice.
    (0, _contentRoot.setContentRoot)(resolution.root, {
      readOnly: resolution.readOnly,
      mountId: resolution.mountId
    });
  }

  // The module IS the latch: once a root is set, the delegation is final for the life of
  // the instance. Deriving "resolved" from it rather than from local state is what stops
  // a momentarily empty mount set from cancelling a task that is already open and being
  // read — and it needs no ref, which the render rules would not allow anyway.
  const resolved = (0, _contentRoot.isDispatched)();

  // ⚠ THE COLD-LOAD RACE, and why this does NOT wait for it.
  //
  // A task callee always has a `useTaskInput()`, so "no input" reliably meant "a fork". On a
  // cold URL load there is no input either way, so at first render "fork" and "dispatched,
  // mount not yet announced" look identical.
  //
  // The obvious guard — hold the render until the mount set is non-empty — is WRONG here,
  // and measurably so: a plain present-mode fork publishes **no mounts at all** (only
  // worktrees, spaces and dispatched corpora are published; the app's own repo arrives as
  // `/app` through the bundler, not through the mount channel). So "wait for mounts" would
  // block every ordinary wiki for the full grace period on a guess that never pays off.
  //
  // Instead: answer immediately, and let a late mark CORRECT the answer. `resolveOpenWiki`
  // re-runs on every mount change and `setContentRoot` latches, so a corpus announced after
  // first paint still flips this to `ready`. The residual is a brief flash of the viewer's
  // own corpus IF the host announces late — which it does not in practice, because the host
  // publishes from a React effect long before the sandboxed app's bundler has finished
  // loading it. **That ordering is a requirement on the host, not a hope**: publish the
  // corpus mount before the app boots, exactly as task delegations are minted before the
  // callee boots (`runTaskInvoke`).
  const pendingReason = resolved || resolution.ok || !input ? null : resolution.reason;
  (0, _react.useEffect)(() => {
    if (!pendingReason) return;
    // A callee whose delegation never arrives must not silently render its OWN corpus —
    // the reader asked for THEIR folder. Give the mount a moment (it arrives on a host
    // message just after the overlay mounts), then cancel with a typed error so the
    // caller's `invokeTask` rejects `cancelled` instead of hanging to the liveness bound.
    const t = setTimeout(() => {
      setFailed((0, _openWiki.openWikiFailureMessage)(pendingReason));
      (0, _tasks.cancelTask)();
    }, MOUNT_GRACE_MS);
    return () => clearTimeout(t);
  }, [pendingReason]);
  if (failed) return {
    status: 'failed',
    message: failed,
    readOnly: false
  };
  if (resolved) return {
    status: 'ready',
    message: '',
    readOnly: (0, _contentRoot.isContentReadOnly)()
  };
  if (!input) return {
    status: 'fork',
    message: '',
    readOnly: false
  };
  return {
    status: 'waiting',
    message: '',
    readOnly: false
  };
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX21vdW50cyIsIl90YXNrcyIsIl9jb250ZW50Um9vdCIsIl9vcGVuV2lraSIsIk1PVU5UX0dSQUNFX01TIiwidXNlT3Blbldpa2lCb290IiwiaW5wdXQiLCJ1c2VUYXNrSW5wdXQiLCJtb3VudHMiLCJ1c2VNb3VudHMiLCJmYWlsZWQiLCJzZXRGYWlsZWQiLCJ1c2VTdGF0ZSIsInJlc29sdXRpb24iLCJyZXNvbHZlT3Blbldpa2kiLCJnZXRBcHBNb3VudFBhdGgiLCJvayIsInNldENvbnRlbnRSb290Iiwicm9vdCIsInJlYWRPbmx5IiwibW91bnRJZCIsInJlc29sdmVkIiwiaXNEaXNwYXRjaGVkIiwicGVuZGluZ1JlYXNvbiIsInJlYXNvbiIsInVzZUVmZmVjdCIsInQiLCJzZXRUaW1lb3V0Iiwib3Blbldpa2lGYWlsdXJlTWVzc2FnZSIsImNhbmNlbFRhc2siLCJjbGVhclRpbWVvdXQiLCJzdGF0dXMiLCJtZXNzYWdlIiwiaXNDb250ZW50UmVhZE9ubHkiXSwic291cmNlcyI6WyJ1c2VPcGVuV2lraUJvb3QudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gQm9vdCByZXNvbHV0aW9uIGZvciB0aGUgYG9wZW4td2lraWAgcHJvdmlkZXIgKFIzLTE2OSkuXG4vL1xuLy8gR3JvdmUgaGFzIHR3byBwYWNrYWdpbmdzIGFuZCB0aGlzIGlzIHdoZXJlIHRoZXkgZGl2ZXJnZSwgT05DRSwgYmVmb3JlIGFueXRoaW5nIHJlYWRzXG4vLyB0aGUgY29ycHVzOlxuLy9cbi8vICAg4oCiIEZPUksgICAgICDigJQgZW5naW5lIGFuZCBjb3JwdXMgaW4gb25lIHJlcG8uIE5vIHRhc2sgaW5wdXQgZXZlciBhcnJpdmVzOyB0aGUgY29udGVudFxuLy8gICAgICAgICAgICAgICAgIHJvb3Qgc3RheXMgYC9hcHAvY29udGVudC9gIGFuZCB0aGlzIGhvb2sgaXMgYSBuby1vcC5cbi8vICAg4oCiIERJU1BBVENIICDigJQgYSBjYWxsZXIgaW52b2tlZCBgb3Blbi13aWtpYCB3aXRoIGEgZGlyZWN0b3J5IGRlbGVnYXRpb24uIFRoZSBob3N0XG4vLyAgICAgICAgICAgICAgICAgbW91bnRzIHRoZSBjb3JwdXMgYXQgYSB0YXNrLXNjb3BlZCBjaHJvb3QgYW5kIHdlIHJlLXBvaW50IHRoZSBjb250ZW50XG4vLyAgICAgICAgICAgICAgICAgcm9vdCBhdCBpdCBiZWZvcmUgdGhlIGZpcnN0IGVudHJ5IHJlbmRlcnMuXG4vL1xuLy8gVGhlIGRpc3RpbmN0aW9uIGhhcyB0byBiZSBzZXR0bGVkIEJFRk9SRSByZW5kZXIsIG5vdCBkdXJpbmcgaXQ6IGV2ZXJ5IGhlbHBlciB0aGF0XG4vLyBhbnN3ZXJzIFwiaXMgdGhpcyBrZXkgYW4gZW50cnkgLyB3aGF0IGlzIGl0cyBocmVmIC8gd2hpY2ggbGF5b3V0cyB3cmFwIGl0XCIgaXMgYnVpbHQgb25cbi8vIHRoZSByb290LCBzbyBhIGNvbXBvbmVudCB0aGF0IHJlbmRlcnMgd2hpbGUgdGhlIHJvb3QgaXMgc3RpbGwgdGhlIGRlZmF1bHQgd291bGQgcmVzb2x2ZVxuLy8gYWdhaW5zdCB0aGUgVklFV0VSJ3MgY29ycHVzIGFuZCB0aGVuIG5vdCByZS1yZXNvbHZlLiBIZW5jZSBhIGdhdGUsIG5vdCBhIGZhbGxiYWNrLlxuXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlTW91bnRzLCBnZXRBcHBNb3VudFBhdGggfSBmcm9tICdAaW1tZWRpYXRlbHktcnVuL3Nkay9tb3VudHMnO1xuaW1wb3J0IHsgdXNlVGFza0lucHV0LCBjYW5jZWxUYXNrIH0gZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9zZGsvdGFza3MnO1xuaW1wb3J0IHsgc2V0Q29udGVudFJvb3QsIGlzRGlzcGF0Y2hlZCwgaXNDb250ZW50UmVhZE9ubHkgfSBmcm9tICcuLi9saWIvY29udGVudFJvb3QnO1xuaW1wb3J0IHsgcmVzb2x2ZU9wZW5XaWtpLCBvcGVuV2lraUZhaWx1cmVNZXNzYWdlIH0gZnJvbSAnLi4vbGliL29wZW5XaWtpJztcblxuLyoqIEhvdyBsb25nIGEgY2FsbGVlIHdhaXRzIGZvciBpdHMgZGVsZWdhdGVkIG1vdW50IGJlZm9yZSBjYW5jZWxsaW5nLiBMb25nIGVub3VnaCBmb3IgdGhlXG4gKiAgaG9zdCdzIG1vdW50IGFubm91bmNlbWVudCB0byBsYW5kIGFmdGVyIHRoZSBvdmVybGF5IG1vdW50cywgc2hvcnQgZW5vdWdoIHRoYXQgYSByZWFkZXJcbiAqICBpcyBub3QgbGVmdCBsb29raW5nIGF0IGEgYmxhbmsgZnJhbWUgdW50aWwgdGhlIMKnNS43LjEgbGl2ZW5lc3MgYm91bmQgZmlyZXMuICovXG5jb25zdCBNT1VOVF9HUkFDRV9NUyA9IDVfMDAwO1xuXG5leHBvcnQgaW50ZXJmYWNlIE9wZW5XaWtpQm9vdCB7XG4gIC8qKiBgZm9ya2Ag4oCUIHJlbmRlciBvdXIgb3duIGNvcnB1cyDCtyBgd2FpdGluZ2Ag4oCUIGEgY2FsbGVlIHdob3NlIG1vdW50IGhhc24ndCBhcnJpdmVkIMK3XG4gICAqICBgcmVhZHlgIOKAlCB0aGUgZGVsZWdhdGVkIHJvb3QgaXMgc2V0IMK3IGBmYWlsZWRgIOKAlCBjYW5jZWxsZWQsIHNob3cgdGhlIG1lc3NhZ2UuICovXG4gIHN0YXR1czogJ2ZvcmsnIHwgJ3dhaXRpbmcnIHwgJ3JlYWR5JyB8ICdmYWlsZWQnO1xuICBtZXNzYWdlOiBzdHJpbmc7XG4gIHJlYWRPbmx5OiBib29sZWFuO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gdXNlT3Blbldpa2lCb290KCk6IE9wZW5XaWtpQm9vdCB7XG4gIGNvbnN0IGlucHV0ID0gdXNlVGFza0lucHV0KCk7XG4gIGNvbnN0IG1vdW50cyA9IHVzZU1vdW50cygpO1xuICBjb25zdCBbZmFpbGVkLCBzZXRGYWlsZWRdID0gdXNlU3RhdGUoJycpO1xuXG4gIGNvbnN0IHJlc29sdXRpb24gPSByZXNvbHZlT3Blbldpa2koaW5wdXQsIG1vdW50cyA/PyBbXSwgZ2V0QXBwTW91bnRQYXRoKCkpO1xuICBpZiAocmVzb2x1dGlvbi5vaykge1xuICAgIC8vIFNldHRpbmcgdGhlIHJvb3QgaXMgd2hhdCBtYWtlcyB0aGUgY29ycHVzIHJlYWRhYmxlLCBzbyBpdCBoYXBwZW5zIGluIHJlbmRlciDigJQgYW5cbiAgICAvLyBlZmZlY3Qgd291bGQgcnVuIEFGVEVSIHRoZSBmaXJzdCBjb250ZW50IHJlbmRlciwgd2hpY2ggaXMgdGhlIHdob2xlIGZhaWx1cmUgdGhpc1xuICAgIC8vIGdhdGUgZXhpc3RzIHRvIHByZXZlbnQuIElkZW1wb3RlbnQgYW5kIHB1cmVseSBkZXJpdmVkLCBzbyBhIFN0cmljdE1vZGUgZG91YmxlXG4gICAgLy8gcmVuZGVyIHNldHMgdGhlIHNhbWUgdmFsdWUgdHdpY2UuXG4gICAgc2V0Q29udGVudFJvb3QocmVzb2x1dGlvbi5yb290LCB7IHJlYWRPbmx5OiByZXNvbHV0aW9uLnJlYWRPbmx5LCBtb3VudElkOiByZXNvbHV0aW9uLm1vdW50SWQgfSk7XG4gIH1cblxuICAvLyBUaGUgbW9kdWxlIElTIHRoZSBsYXRjaDogb25jZSBhIHJvb3QgaXMgc2V0LCB0aGUgZGVsZWdhdGlvbiBpcyBmaW5hbCBmb3IgdGhlIGxpZmUgb2ZcbiAgLy8gdGhlIGluc3RhbmNlLiBEZXJpdmluZyBcInJlc29sdmVkXCIgZnJvbSBpdCByYXRoZXIgdGhhbiBmcm9tIGxvY2FsIHN0YXRlIGlzIHdoYXQgc3RvcHNcbiAgLy8gYSBtb21lbnRhcmlseSBlbXB0eSBtb3VudCBzZXQgZnJvbSBjYW5jZWxsaW5nIGEgdGFzayB0aGF0IGlzIGFscmVhZHkgb3BlbiBhbmQgYmVpbmdcbiAgLy8gcmVhZCDigJQgYW5kIGl0IG5lZWRzIG5vIHJlZiwgd2hpY2ggdGhlIHJlbmRlciBydWxlcyB3b3VsZCBub3QgYWxsb3cgYW55d2F5LlxuICBjb25zdCByZXNvbHZlZCA9IGlzRGlzcGF0Y2hlZCgpO1xuXG4gIC8vIOKaoCBUSEUgQ09MRC1MT0FEIFJBQ0UsIGFuZCB3aHkgdGhpcyBkb2VzIE5PVCB3YWl0IGZvciBpdC5cbiAgLy9cbiAgLy8gQSB0YXNrIGNhbGxlZSBhbHdheXMgaGFzIGEgYHVzZVRhc2tJbnB1dCgpYCwgc28gXCJubyBpbnB1dFwiIHJlbGlhYmx5IG1lYW50IFwiYSBmb3JrXCIuIE9uIGFcbiAgLy8gY29sZCBVUkwgbG9hZCB0aGVyZSBpcyBubyBpbnB1dCBlaXRoZXIgd2F5LCBzbyBhdCBmaXJzdCByZW5kZXIgXCJmb3JrXCIgYW5kIFwiZGlzcGF0Y2hlZCxcbiAgLy8gbW91bnQgbm90IHlldCBhbm5vdW5jZWRcIiBsb29rIGlkZW50aWNhbC5cbiAgLy9cbiAgLy8gVGhlIG9idmlvdXMgZ3VhcmQg4oCUIGhvbGQgdGhlIHJlbmRlciB1bnRpbCB0aGUgbW91bnQgc2V0IGlzIG5vbi1lbXB0eSDigJQgaXMgV1JPTkcgaGVyZSxcbiAgLy8gYW5kIG1lYXN1cmFibHkgc286IGEgcGxhaW4gcHJlc2VudC1tb2RlIGZvcmsgcHVibGlzaGVzICoqbm8gbW91bnRzIGF0IGFsbCoqIChvbmx5XG4gIC8vIHdvcmt0cmVlcywgc3BhY2VzIGFuZCBkaXNwYXRjaGVkIGNvcnBvcmEgYXJlIHB1Ymxpc2hlZDsgdGhlIGFwcCdzIG93biByZXBvIGFycml2ZXMgYXNcbiAgLy8gYC9hcHBgIHRocm91Z2ggdGhlIGJ1bmRsZXIsIG5vdCB0aHJvdWdoIHRoZSBtb3VudCBjaGFubmVsKS4gU28gXCJ3YWl0IGZvciBtb3VudHNcIiB3b3VsZFxuICAvLyBibG9jayBldmVyeSBvcmRpbmFyeSB3aWtpIGZvciB0aGUgZnVsbCBncmFjZSBwZXJpb2Qgb24gYSBndWVzcyB0aGF0IG5ldmVyIHBheXMgb2ZmLlxuICAvL1xuICAvLyBJbnN0ZWFkOiBhbnN3ZXIgaW1tZWRpYXRlbHksIGFuZCBsZXQgYSBsYXRlIG1hcmsgQ09SUkVDVCB0aGUgYW5zd2VyLiBgcmVzb2x2ZU9wZW5XaWtpYFxuICAvLyByZS1ydW5zIG9uIGV2ZXJ5IG1vdW50IGNoYW5nZSBhbmQgYHNldENvbnRlbnRSb290YCBsYXRjaGVzLCBzbyBhIGNvcnB1cyBhbm5vdW5jZWQgYWZ0ZXJcbiAgLy8gZmlyc3QgcGFpbnQgc3RpbGwgZmxpcHMgdGhpcyB0byBgcmVhZHlgLiBUaGUgcmVzaWR1YWwgaXMgYSBicmllZiBmbGFzaCBvZiB0aGUgdmlld2VyJ3NcbiAgLy8gb3duIGNvcnB1cyBJRiB0aGUgaG9zdCBhbm5vdW5jZXMgbGF0ZSDigJQgd2hpY2ggaXQgZG9lcyBub3QgaW4gcHJhY3RpY2UsIGJlY2F1c2UgdGhlIGhvc3RcbiAgLy8gcHVibGlzaGVzIGZyb20gYSBSZWFjdCBlZmZlY3QgbG9uZyBiZWZvcmUgdGhlIHNhbmRib3hlZCBhcHAncyBidW5kbGVyIGhhcyBmaW5pc2hlZFxuICAvLyBsb2FkaW5nIGl0LiAqKlRoYXQgb3JkZXJpbmcgaXMgYSByZXF1aXJlbWVudCBvbiB0aGUgaG9zdCwgbm90IGEgaG9wZSoqOiBwdWJsaXNoIHRoZVxuICAvLyBjb3JwdXMgbW91bnQgYmVmb3JlIHRoZSBhcHAgYm9vdHMsIGV4YWN0bHkgYXMgdGFzayBkZWxlZ2F0aW9ucyBhcmUgbWludGVkIGJlZm9yZSB0aGVcbiAgLy8gY2FsbGVlIGJvb3RzIChgcnVuVGFza0ludm9rZWApLlxuICBjb25zdCBwZW5kaW5nUmVhc29uID0gcmVzb2x2ZWQgfHwgcmVzb2x1dGlvbi5vayB8fCAhaW5wdXQgPyBudWxsIDogcmVzb2x1dGlvbi5yZWFzb247XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIXBlbmRpbmdSZWFzb24pIHJldHVybjtcbiAgICAvLyBBIGNhbGxlZSB3aG9zZSBkZWxlZ2F0aW9uIG5ldmVyIGFycml2ZXMgbXVzdCBub3Qgc2lsZW50bHkgcmVuZGVyIGl0cyBPV04gY29ycHVzIOKAlFxuICAgIC8vIHRoZSByZWFkZXIgYXNrZWQgZm9yIFRIRUlSIGZvbGRlci4gR2l2ZSB0aGUgbW91bnQgYSBtb21lbnQgKGl0IGFycml2ZXMgb24gYSBob3N0XG4gICAgLy8gbWVzc2FnZSBqdXN0IGFmdGVyIHRoZSBvdmVybGF5IG1vdW50cyksIHRoZW4gY2FuY2VsIHdpdGggYSB0eXBlZCBlcnJvciBzbyB0aGVcbiAgICAvLyBjYWxsZXIncyBgaW52b2tlVGFza2AgcmVqZWN0cyBgY2FuY2VsbGVkYCBpbnN0ZWFkIG9mIGhhbmdpbmcgdG8gdGhlIGxpdmVuZXNzIGJvdW5kLlxuICAgIGNvbnN0IHQgPSBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIHNldEZhaWxlZChvcGVuV2lraUZhaWx1cmVNZXNzYWdlKHBlbmRpbmdSZWFzb24pKTtcbiAgICAgIGNhbmNlbFRhc2soKTtcbiAgICB9LCBNT1VOVF9HUkFDRV9NUyk7XG4gICAgcmV0dXJuICgpID0+IGNsZWFyVGltZW91dCh0KTtcbiAgfSwgW3BlbmRpbmdSZWFzb25dKTtcblxuICBpZiAoZmFpbGVkKSByZXR1cm4geyBzdGF0dXM6ICdmYWlsZWQnLCBtZXNzYWdlOiBmYWlsZWQsIHJlYWRPbmx5OiBmYWxzZSB9O1xuICBpZiAocmVzb2x2ZWQpIHJldHVybiB7IHN0YXR1czogJ3JlYWR5JywgbWVzc2FnZTogJycsIHJlYWRPbmx5OiBpc0NvbnRlbnRSZWFkT25seSgpIH07XG4gIGlmICghaW5wdXQpIHJldHVybiB7IHN0YXR1czogJ2ZvcmsnLCBtZXNzYWdlOiAnJywgcmVhZE9ubHk6IGZhbHNlIH07XG4gIHJldHVybiB7IHN0YXR1czogJ3dhaXRpbmcnLCBtZXNzYWdlOiAnJywgcmVhZE9ubHk6IGZhbHNlIH07XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQWdCQSxJQUFBQSxNQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxPQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxNQUFBLEdBQUFGLE9BQUE7QUFDQSxJQUFBRyxZQUFBLEdBQUFILE9BQUE7QUFDQSxJQUFBSSxTQUFBLEdBQUFKLE9BQUE7QUFwQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQVFBO0FBQ0E7QUFDQTtBQUNBLE1BQU1LLGNBQWMsR0FBRyxLQUFLO0FBVXJCLFNBQVNDLGVBQWVBLENBQUEsRUFBaUI7RUFDOUMsTUFBTUMsS0FBSyxHQUFHLElBQUFDLG1CQUFZLEVBQUMsQ0FBQztFQUM1QixNQUFNQyxNQUFNLEdBQUcsSUFBQUMsaUJBQVMsRUFBQyxDQUFDO0VBQzFCLE1BQU0sQ0FBQ0MsTUFBTSxFQUFFQyxTQUFTLENBQUMsR0FBRyxJQUFBQyxlQUFRLEVBQUMsRUFBRSxDQUFDO0VBRXhDLE1BQU1DLFVBQVUsR0FBRyxJQUFBQyx5QkFBZSxFQUFDUixLQUFLLEVBQUVFLE1BQU0sSUFBSSxFQUFFLEVBQUUsSUFBQU8sdUJBQWUsRUFBQyxDQUFDLENBQUM7RUFDMUUsSUFBSUYsVUFBVSxDQUFDRyxFQUFFLEVBQUU7SUFDakI7SUFDQTtJQUNBO0lBQ0E7SUFDQSxJQUFBQywyQkFBYyxFQUFDSixVQUFVLENBQUNLLElBQUksRUFBRTtNQUFFQyxRQUFRLEVBQUVOLFVBQVUsQ0FBQ00sUUFBUTtNQUFFQyxPQUFPLEVBQUVQLFVBQVUsQ0FBQ087SUFBUSxDQUFDLENBQUM7RUFDakc7O0VBRUE7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNQyxRQUFRLEdBQUcsSUFBQUMseUJBQVksRUFBQyxDQUFDOztFQUUvQjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsTUFBTUMsYUFBYSxHQUFHRixRQUFRLElBQUlSLFVBQVUsQ0FBQ0csRUFBRSxJQUFJLENBQUNWLEtBQUssR0FBRyxJQUFJLEdBQUdPLFVBQVUsQ0FBQ1csTUFBTTtFQUVwRixJQUFBQyxnQkFBUyxFQUFDLE1BQU07SUFDZCxJQUFJLENBQUNGLGFBQWEsRUFBRTtJQUNwQjtJQUNBO0lBQ0E7SUFDQTtJQUNBLE1BQU1HLENBQUMsR0FBR0MsVUFBVSxDQUFDLE1BQU07TUFDekJoQixTQUFTLENBQUMsSUFBQWlCLGdDQUFzQixFQUFDTCxhQUFhLENBQUMsQ0FBQztNQUNoRCxJQUFBTSxpQkFBVSxFQUFDLENBQUM7SUFDZCxDQUFDLEVBQUV6QixjQUFjLENBQUM7SUFDbEIsT0FBTyxNQUFNMEIsWUFBWSxDQUFDSixDQUFDLENBQUM7RUFDOUIsQ0FBQyxFQUFFLENBQUNILGFBQWEsQ0FBQyxDQUFDO0VBRW5CLElBQUliLE1BQU0sRUFBRSxPQUFPO0lBQUVxQixNQUFNLEVBQUUsUUFBUTtJQUFFQyxPQUFPLEVBQUV0QixNQUFNO0lBQUVTLFFBQVEsRUFBRTtFQUFNLENBQUM7RUFDekUsSUFBSUUsUUFBUSxFQUFFLE9BQU87SUFBRVUsTUFBTSxFQUFFLE9BQU87SUFBRUMsT0FBTyxFQUFFLEVBQUU7SUFBRWIsUUFBUSxFQUFFLElBQUFjLDhCQUFpQixFQUFDO0VBQUUsQ0FBQztFQUNwRixJQUFJLENBQUMzQixLQUFLLEVBQUUsT0FBTztJQUFFeUIsTUFBTSxFQUFFLE1BQU07SUFBRUMsT0FBTyxFQUFFLEVBQUU7SUFBRWIsUUFBUSxFQUFFO0VBQU0sQ0FBQztFQUNuRSxPQUFPO0lBQUVZLE1BQU0sRUFBRSxTQUFTO0lBQUVDLE9BQU8sRUFBRSxFQUFFO0lBQUViLFFBQVEsRUFBRTtFQUFNLENBQUM7QUFDNUQiLCJpZ25vcmVMaXN0IjpbXX0=