var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

var _vitest = require("vitest");
var _react = require("react");
var _client = require("react-dom/client");
var _sdk = require("@immediately-run/sdk");
var _useScrollReset = require("./useScrollReset");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // @vitest-environment jsdom
// A stand-in for `<GroveWiki>`'s `.device__scroll`: the hook's whole job is what it does
// to that element across a navigation, so the probe renders one and the assertions read
// its `scrollTop` — the property the reader experiences — rather than a call count.
function Probe({
  entryKey,
  hash
}) {
  _s();
  const ref = (0, _useScrollReset.useScrollReset)(entryKey, hash);
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    ref: ref,
    "data-testid": "scroller"
  });
}

/** Mount the probe and hand back a `navigate` that re-renders it, plus the container. */
_s(Probe, "ZAt6qlvUiLFOFFVX6g443RVP8No=", false, function () {
  return [_useScrollReset.useScrollReset];
});
_c = Probe;
function mount(entryKey, hash = '') {
  const host = document.createElement('div');
  document.body.appendChild(host);
  const root = (0, _client.createRoot)(host);
  (0, _react.act)(() => root.render(/*#__PURE__*/(0, _jsxRuntime.jsx)(Probe, {
    entryKey: entryKey,
    hash: hash
  })));
  const el = host.querySelector('[data-testid="scroller"]');
  return {
    el,
    navigate: (nextKey, nextHash = '') => (0, _react.act)(() => root.render(/*#__PURE__*/(0, _jsxRuntime.jsx)(Probe, {
      entryKey: nextKey,
      hash: nextHash
    }))),
    unmount: () => {
      (0, _react.act)(() => root.unmount());
      host.remove();
    }
  };
}
(0, _vitest.describe)('useScrollReset', () => {
  (0, _vitest.it)('puts the reader at the top of the entry they navigated to', () => {
    const {
      el,
      navigate,
      unmount
    } = mount('/app/content/projects/directory-as-content.mdx');
    // What a long list page leaves behind: the offset the reader had reached on it.
    el.scrollTop = 4200;
    navigate('/app/content/roadmap/R3-170.mdx');
    (0, _vitest.expect)(el.scrollTop).toBe(0);
    unmount();
  });
  (0, _vitest.it)('leaves a fragment navigation alone — that landing belongs to ScrollToFragment', () => {
    const {
      el,
      navigate,
      unmount
    } = mount('/app/content/a.mdx');
    el.scrollTop = 900;
    navigate('/app/content/b.mdx', '#sec-4');
    (0, _vitest.expect)(el.scrollTop).toBe(900);
    unmount();
  });
  (0, _vitest.it)('reads the fragment the same way the deep-link path does', () => {
    // The dev provider glues its `#ir-endpoint=…` locator onto the fragment, and
    // `fragmentOf` takes the leading component. A hash that is ONLY the locator names no
    // section, so it is an ordinary navigation and must reset; one that names a section
    // must not, locator or no locator.
    const only = mount('/app/content/a.mdx');
    only.el.scrollTop = 300;
    only.navigate('/app/content/b.mdx', '#&ir-endpoint=x&ir-token=y');
    (0, _vitest.expect)(only.el.scrollTop).toBe(0);
    only.unmount();
    const named = mount('/app/content/a.mdx');
    named.el.scrollTop = 300;
    named.navigate('/app/content/b.mdx', '#sec-2&ir-endpoint=x');
    (0, _vitest.expect)(named.el.scrollTop).toBe(300);
    named.unmount();
  });
  (0, _vitest.it)('does not fight the reader on a re-render that is not a navigation', () => {
    // The entry re-renders for reasons of its own — reading time arriving, a theme
    // change, the metadata store settling. Resetting on any of those would yank the page
    // out from under someone mid-read.
    const {
      el,
      navigate,
      unmount
    } = mount('/app/content/a.mdx');
    el.scrollTop = 1500;
    navigate('/app/content/a.mdx');
    (0, _vitest.expect)(el.scrollTop).toBe(1500);
    unmount();
  });
  (0, _vitest.it)('resets when a reader leaves a section for the page it is in', () => {
    // `/a#sec-4` → `/a` is a navigation even though the entry did not change: the reader
    // asked for the entry, not the section they were on.
    const {
      el,
      navigate,
      unmount
    } = mount('/app/content/a.mdx', '#sec-4');
    el.scrollTop = 700;
    navigate('/app/content/a.mdx', '');
    (0, _vitest.expect)(el.scrollTop).toBe(0);
    unmount();
  });
});
(0, _vitest.describe)('useScrollReset on a history traversal (R3-627)', () => {
  // The platform now restores where the reader was on a page they return to. This
  // hook runs on the same arrival, so if it still zeroed the container it would undo
  // that restoration a moment after it happened — the feature would look like it had
  // never shipped.
  (0, _vitest.afterEach)(() => (0, _sdk.resetEntryState)());
  (0, _vitest.it)('stands down on Back, leaving the restored position alone', () => {
    const {
      el,
      navigate,
      unmount
    } = mount('/app/content/a.mdx');
    (0, _react.act)(() => (0, _sdk.receiveNavigation)({
      state: {
        'ir.scroll': 640
      },
      direction: 'back'
    }));
    // What ScrollRestoration will have put back by the time this effect runs.
    el.scrollTop = 640;
    navigate('/app/content/projects/directory-as-content.mdx');
    (0, _vitest.expect)(el.scrollTop).toBe(640);
    unmount();
  });
  (0, _vitest.it)('stands down on Forward too — a traversal either way is a page already seen', () => {
    const {
      el,
      navigate,
      unmount
    } = mount('/app/content/a.mdx');
    (0, _react.act)(() => (0, _sdk.receiveNavigation)({
      state: {
        'ir.scroll': 120
      },
      direction: 'forward'
    }));
    el.scrollTop = 120;
    navigate('/app/content/b.mdx');
    (0, _vitest.expect)(el.scrollTop).toBe(120);
    unmount();
  });
  (0, _vitest.it)('still resets on an ordinary navigation after a traversal', () => {
    // The guard must follow the CURRENT arrival, not latch on the first traversal.
    const {
      el,
      navigate,
      unmount
    } = mount('/app/content/a.mdx');
    (0, _react.act)(() => (0, _sdk.receiveNavigation)({
      state: {
        'ir.scroll': 640
      },
      direction: 'back'
    }));
    el.scrollTop = 640;
    navigate('/app/content/b.mdx');
    (0, _vitest.expect)(el.scrollTop).toBe(640);
    (0, _react.act)(() => (0, _sdk.receiveNavigation)({
      state: undefined,
      direction: 'push'
    }));
    el.scrollTop = 900;
    navigate('/app/content/c.mdx');
    (0, _vitest.expect)(el.scrollTop).toBe(0);
    unmount();
  });
});
var _c;
$RefreshReg$(_c, "Probe");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZXN0IiwicmVxdWlyZSIsIl9yZWFjdCIsIl9jbGllbnQiLCJfc2RrIiwiX3VzZVNjcm9sbFJlc2V0IiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsIlByb2JlIiwiZW50cnlLZXkiLCJoYXNoIiwicmVmIiwidXNlU2Nyb2xsUmVzZXQiLCJqc3giLCJfYyIsIm1vdW50IiwiaG9zdCIsImRvY3VtZW50IiwiY3JlYXRlRWxlbWVudCIsImJvZHkiLCJhcHBlbmRDaGlsZCIsInJvb3QiLCJjcmVhdGVSb290IiwiYWN0IiwicmVuZGVyIiwiZWwiLCJxdWVyeVNlbGVjdG9yIiwibmF2aWdhdGUiLCJuZXh0S2V5IiwibmV4dEhhc2giLCJ1bm1vdW50IiwicmVtb3ZlIiwiZGVzY3JpYmUiLCJpdCIsInNjcm9sbFRvcCIsImV4cGVjdCIsInRvQmUiLCJvbmx5IiwibmFtZWQiLCJhZnRlckVhY2giLCJyZXNldEVudHJ5U3RhdGUiLCJyZWNlaXZlTmF2aWdhdGlvbiIsInN0YXRlIiwiZGlyZWN0aW9uIiwidW5kZWZpbmVkIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsidXNlU2Nyb2xsUmVzZXQudGVzdC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gQHZpdGVzdC1lbnZpcm9ubWVudCBqc2RvbVxuaW1wb3J0IHsgZGVzY3JpYmUsIGl0LCBleHBlY3QsIGFmdGVyRWFjaCB9IGZyb20gJ3ZpdGVzdCc7XG5pbXBvcnQgeyBhY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBjcmVhdGVSb290IH0gZnJvbSAncmVhY3QtZG9tL2NsaWVudCc7XG5pbXBvcnQgeyByZWNlaXZlTmF2aWdhdGlvbiwgcmVzZXRFbnRyeVN0YXRlIH0gZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9zZGsnO1xuaW1wb3J0IHsgdXNlU2Nyb2xsUmVzZXQgfSBmcm9tICcuL3VzZVNjcm9sbFJlc2V0JztcblxuLy8gQSBzdGFuZC1pbiBmb3IgYDxHcm92ZVdpa2k+YCdzIGAuZGV2aWNlX19zY3JvbGxgOiB0aGUgaG9vaydzIHdob2xlIGpvYiBpcyB3aGF0IGl0IGRvZXNcbi8vIHRvIHRoYXQgZWxlbWVudCBhY3Jvc3MgYSBuYXZpZ2F0aW9uLCBzbyB0aGUgcHJvYmUgcmVuZGVycyBvbmUgYW5kIHRoZSBhc3NlcnRpb25zIHJlYWRcbi8vIGl0cyBgc2Nyb2xsVG9wYCDigJQgdGhlIHByb3BlcnR5IHRoZSByZWFkZXIgZXhwZXJpZW5jZXMg4oCUIHJhdGhlciB0aGFuIGEgY2FsbCBjb3VudC5cbmZ1bmN0aW9uIFByb2JlKHsgZW50cnlLZXksIGhhc2ggfTogeyBlbnRyeUtleTogc3RyaW5nOyBoYXNoOiBzdHJpbmcgfSkge1xuICBjb25zdCByZWYgPSB1c2VTY3JvbGxSZXNldChlbnRyeUtleSwgaGFzaCk7XG4gIHJldHVybiA8ZGl2IHJlZj17cmVmfSBkYXRhLXRlc3RpZD1cInNjcm9sbGVyXCIgLz47XG59XG5cbi8qKiBNb3VudCB0aGUgcHJvYmUgYW5kIGhhbmQgYmFjayBhIGBuYXZpZ2F0ZWAgdGhhdCByZS1yZW5kZXJzIGl0LCBwbHVzIHRoZSBjb250YWluZXIuICovXG5mdW5jdGlvbiBtb3VudChlbnRyeUtleTogc3RyaW5nLCBoYXNoID0gJycpIHtcbiAgY29uc3QgaG9zdCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGhvc3QpO1xuICBjb25zdCByb290ID0gY3JlYXRlUm9vdChob3N0KTtcbiAgYWN0KCgpID0+IHJvb3QucmVuZGVyKDxQcm9iZSBlbnRyeUtleT17ZW50cnlLZXl9IGhhc2g9e2hhc2h9IC8+KSk7XG4gIGNvbnN0IGVsID0gaG9zdC5xdWVyeVNlbGVjdG9yPEhUTUxEaXZFbGVtZW50PignW2RhdGEtdGVzdGlkPVwic2Nyb2xsZXJcIl0nKSE7XG4gIHJldHVybiB7XG4gICAgZWwsXG4gICAgbmF2aWdhdGU6IChuZXh0S2V5OiBzdHJpbmcsIG5leHRIYXNoID0gJycpID0+XG4gICAgICBhY3QoKCkgPT4gcm9vdC5yZW5kZXIoPFByb2JlIGVudHJ5S2V5PXtuZXh0S2V5fSBoYXNoPXtuZXh0SGFzaH0gLz4pKSxcbiAgICB1bm1vdW50OiAoKSA9PiB7XG4gICAgICBhY3QoKCkgPT4gcm9vdC51bm1vdW50KCkpO1xuICAgICAgaG9zdC5yZW1vdmUoKTtcbiAgICB9LFxuICB9O1xufVxuXG5kZXNjcmliZSgndXNlU2Nyb2xsUmVzZXQnLCAoKSA9PiB7XG4gIGl0KCdwdXRzIHRoZSByZWFkZXIgYXQgdGhlIHRvcCBvZiB0aGUgZW50cnkgdGhleSBuYXZpZ2F0ZWQgdG8nLCAoKSA9PiB7XG4gICAgY29uc3QgeyBlbCwgbmF2aWdhdGUsIHVubW91bnQgfSA9IG1vdW50KCcvYXBwL2NvbnRlbnQvcHJvamVjdHMvZGlyZWN0b3J5LWFzLWNvbnRlbnQubWR4Jyk7XG4gICAgLy8gV2hhdCBhIGxvbmcgbGlzdCBwYWdlIGxlYXZlcyBiZWhpbmQ6IHRoZSBvZmZzZXQgdGhlIHJlYWRlciBoYWQgcmVhY2hlZCBvbiBpdC5cbiAgICBlbC5zY3JvbGxUb3AgPSA0MjAwO1xuICAgIG5hdmlnYXRlKCcvYXBwL2NvbnRlbnQvcm9hZG1hcC9SMy0xNzAubWR4Jyk7XG4gICAgZXhwZWN0KGVsLnNjcm9sbFRvcCkudG9CZSgwKTtcbiAgICB1bm1vdW50KCk7XG4gIH0pO1xuXG4gIGl0KCdsZWF2ZXMgYSBmcmFnbWVudCBuYXZpZ2F0aW9uIGFsb25lIOKAlCB0aGF0IGxhbmRpbmcgYmVsb25ncyB0byBTY3JvbGxUb0ZyYWdtZW50JywgKCkgPT4ge1xuICAgIGNvbnN0IHsgZWwsIG5hdmlnYXRlLCB1bm1vdW50IH0gPSBtb3VudCgnL2FwcC9jb250ZW50L2EubWR4Jyk7XG4gICAgZWwuc2Nyb2xsVG9wID0gOTAwO1xuICAgIG5hdmlnYXRlKCcvYXBwL2NvbnRlbnQvYi5tZHgnLCAnI3NlYy00Jyk7XG4gICAgZXhwZWN0KGVsLnNjcm9sbFRvcCkudG9CZSg5MDApO1xuICAgIHVubW91bnQoKTtcbiAgfSk7XG5cbiAgaXQoJ3JlYWRzIHRoZSBmcmFnbWVudCB0aGUgc2FtZSB3YXkgdGhlIGRlZXAtbGluayBwYXRoIGRvZXMnLCAoKSA9PiB7XG4gICAgLy8gVGhlIGRldiBwcm92aWRlciBnbHVlcyBpdHMgYCNpci1lbmRwb2ludD3igKZgIGxvY2F0b3Igb250byB0aGUgZnJhZ21lbnQsIGFuZFxuICAgIC8vIGBmcmFnbWVudE9mYCB0YWtlcyB0aGUgbGVhZGluZyBjb21wb25lbnQuIEEgaGFzaCB0aGF0IGlzIE9OTFkgdGhlIGxvY2F0b3IgbmFtZXMgbm9cbiAgICAvLyBzZWN0aW9uLCBzbyBpdCBpcyBhbiBvcmRpbmFyeSBuYXZpZ2F0aW9uIGFuZCBtdXN0IHJlc2V0OyBvbmUgdGhhdCBuYW1lcyBhIHNlY3Rpb25cbiAgICAvLyBtdXN0IG5vdCwgbG9jYXRvciBvciBubyBsb2NhdG9yLlxuICAgIGNvbnN0IG9ubHkgPSBtb3VudCgnL2FwcC9jb250ZW50L2EubWR4Jyk7XG4gICAgb25seS5lbC5zY3JvbGxUb3AgPSAzMDA7XG4gICAgb25seS5uYXZpZ2F0ZSgnL2FwcC9jb250ZW50L2IubWR4JywgJyMmaXItZW5kcG9pbnQ9eCZpci10b2tlbj15Jyk7XG4gICAgZXhwZWN0KG9ubHkuZWwuc2Nyb2xsVG9wKS50b0JlKDApO1xuICAgIG9ubHkudW5tb3VudCgpO1xuXG4gICAgY29uc3QgbmFtZWQgPSBtb3VudCgnL2FwcC9jb250ZW50L2EubWR4Jyk7XG4gICAgbmFtZWQuZWwuc2Nyb2xsVG9wID0gMzAwO1xuICAgIG5hbWVkLm5hdmlnYXRlKCcvYXBwL2NvbnRlbnQvYi5tZHgnLCAnI3NlYy0yJmlyLWVuZHBvaW50PXgnKTtcbiAgICBleHBlY3QobmFtZWQuZWwuc2Nyb2xsVG9wKS50b0JlKDMwMCk7XG4gICAgbmFtZWQudW5tb3VudCgpO1xuICB9KTtcblxuICBpdCgnZG9lcyBub3QgZmlnaHQgdGhlIHJlYWRlciBvbiBhIHJlLXJlbmRlciB0aGF0IGlzIG5vdCBhIG5hdmlnYXRpb24nLCAoKSA9PiB7XG4gICAgLy8gVGhlIGVudHJ5IHJlLXJlbmRlcnMgZm9yIHJlYXNvbnMgb2YgaXRzIG93biDigJQgcmVhZGluZyB0aW1lIGFycml2aW5nLCBhIHRoZW1lXG4gICAgLy8gY2hhbmdlLCB0aGUgbWV0YWRhdGEgc3RvcmUgc2V0dGxpbmcuIFJlc2V0dGluZyBvbiBhbnkgb2YgdGhvc2Ugd291bGQgeWFuayB0aGUgcGFnZVxuICAgIC8vIG91dCBmcm9tIHVuZGVyIHNvbWVvbmUgbWlkLXJlYWQuXG4gICAgY29uc3QgeyBlbCwgbmF2aWdhdGUsIHVubW91bnQgfSA9IG1vdW50KCcvYXBwL2NvbnRlbnQvYS5tZHgnKTtcbiAgICBlbC5zY3JvbGxUb3AgPSAxNTAwO1xuICAgIG5hdmlnYXRlKCcvYXBwL2NvbnRlbnQvYS5tZHgnKTtcbiAgICBleHBlY3QoZWwuc2Nyb2xsVG9wKS50b0JlKDE1MDApO1xuICAgIHVubW91bnQoKTtcbiAgfSk7XG5cbiAgaXQoJ3Jlc2V0cyB3aGVuIGEgcmVhZGVyIGxlYXZlcyBhIHNlY3Rpb24gZm9yIHRoZSBwYWdlIGl0IGlzIGluJywgKCkgPT4ge1xuICAgIC8vIGAvYSNzZWMtNGAg4oaSIGAvYWAgaXMgYSBuYXZpZ2F0aW9uIGV2ZW4gdGhvdWdoIHRoZSBlbnRyeSBkaWQgbm90IGNoYW5nZTogdGhlIHJlYWRlclxuICAgIC8vIGFza2VkIGZvciB0aGUgZW50cnksIG5vdCB0aGUgc2VjdGlvbiB0aGV5IHdlcmUgb24uXG4gICAgY29uc3QgeyBlbCwgbmF2aWdhdGUsIHVubW91bnQgfSA9IG1vdW50KCcvYXBwL2NvbnRlbnQvYS5tZHgnLCAnI3NlYy00Jyk7XG4gICAgZWwuc2Nyb2xsVG9wID0gNzAwO1xuICAgIG5hdmlnYXRlKCcvYXBwL2NvbnRlbnQvYS5tZHgnLCAnJyk7XG4gICAgZXhwZWN0KGVsLnNjcm9sbFRvcCkudG9CZSgwKTtcbiAgICB1bm1vdW50KCk7XG4gIH0pO1xufSk7XG5cbmRlc2NyaWJlKCd1c2VTY3JvbGxSZXNldCBvbiBhIGhpc3RvcnkgdHJhdmVyc2FsIChSMy02MjcpJywgKCkgPT4ge1xuICAvLyBUaGUgcGxhdGZvcm0gbm93IHJlc3RvcmVzIHdoZXJlIHRoZSByZWFkZXIgd2FzIG9uIGEgcGFnZSB0aGV5IHJldHVybiB0by4gVGhpc1xuICAvLyBob29rIHJ1bnMgb24gdGhlIHNhbWUgYXJyaXZhbCwgc28gaWYgaXQgc3RpbGwgemVyb2VkIHRoZSBjb250YWluZXIgaXQgd291bGQgdW5kb1xuICAvLyB0aGF0IHJlc3RvcmF0aW9uIGEgbW9tZW50IGFmdGVyIGl0IGhhcHBlbmVkIOKAlCB0aGUgZmVhdHVyZSB3b3VsZCBsb29rIGxpa2UgaXQgaGFkXG4gIC8vIG5ldmVyIHNoaXBwZWQuXG4gIGFmdGVyRWFjaCgoKSA9PiByZXNldEVudHJ5U3RhdGUoKSk7XG5cbiAgaXQoJ3N0YW5kcyBkb3duIG9uIEJhY2ssIGxlYXZpbmcgdGhlIHJlc3RvcmVkIHBvc2l0aW9uIGFsb25lJywgKCkgPT4ge1xuICAgIGNvbnN0IHsgZWwsIG5hdmlnYXRlLCB1bm1vdW50IH0gPSBtb3VudCgnL2FwcC9jb250ZW50L2EubWR4Jyk7XG4gICAgYWN0KCgpID0+IHJlY2VpdmVOYXZpZ2F0aW9uKHsgc3RhdGU6IHsgJ2lyLnNjcm9sbCc6IDY0MCB9LCBkaXJlY3Rpb246ICdiYWNrJyB9KSk7XG4gICAgLy8gV2hhdCBTY3JvbGxSZXN0b3JhdGlvbiB3aWxsIGhhdmUgcHV0IGJhY2sgYnkgdGhlIHRpbWUgdGhpcyBlZmZlY3QgcnVucy5cbiAgICBlbC5zY3JvbGxUb3AgPSA2NDA7XG4gICAgbmF2aWdhdGUoJy9hcHAvY29udGVudC9wcm9qZWN0cy9kaXJlY3RvcnktYXMtY29udGVudC5tZHgnKTtcbiAgICBleHBlY3QoZWwuc2Nyb2xsVG9wKS50b0JlKDY0MCk7XG4gICAgdW5tb3VudCgpO1xuICB9KTtcblxuICBpdCgnc3RhbmRzIGRvd24gb24gRm9yd2FyZCB0b28g4oCUIGEgdHJhdmVyc2FsIGVpdGhlciB3YXkgaXMgYSBwYWdlIGFscmVhZHkgc2VlbicsICgpID0+IHtcbiAgICBjb25zdCB7IGVsLCBuYXZpZ2F0ZSwgdW5tb3VudCB9ID0gbW91bnQoJy9hcHAvY29udGVudC9hLm1keCcpO1xuICAgIGFjdCgoKSA9PiByZWNlaXZlTmF2aWdhdGlvbih7IHN0YXRlOiB7ICdpci5zY3JvbGwnOiAxMjAgfSwgZGlyZWN0aW9uOiAnZm9yd2FyZCcgfSkpO1xuICAgIGVsLnNjcm9sbFRvcCA9IDEyMDtcbiAgICBuYXZpZ2F0ZSgnL2FwcC9jb250ZW50L2IubWR4Jyk7XG4gICAgZXhwZWN0KGVsLnNjcm9sbFRvcCkudG9CZSgxMjApO1xuICAgIHVubW91bnQoKTtcbiAgfSk7XG5cbiAgaXQoJ3N0aWxsIHJlc2V0cyBvbiBhbiBvcmRpbmFyeSBuYXZpZ2F0aW9uIGFmdGVyIGEgdHJhdmVyc2FsJywgKCkgPT4ge1xuICAgIC8vIFRoZSBndWFyZCBtdXN0IGZvbGxvdyB0aGUgQ1VSUkVOVCBhcnJpdmFsLCBub3QgbGF0Y2ggb24gdGhlIGZpcnN0IHRyYXZlcnNhbC5cbiAgICBjb25zdCB7IGVsLCBuYXZpZ2F0ZSwgdW5tb3VudCB9ID0gbW91bnQoJy9hcHAvY29udGVudC9hLm1keCcpO1xuICAgIGFjdCgoKSA9PiByZWNlaXZlTmF2aWdhdGlvbih7IHN0YXRlOiB7ICdpci5zY3JvbGwnOiA2NDAgfSwgZGlyZWN0aW9uOiAnYmFjaycgfSkpO1xuICAgIGVsLnNjcm9sbFRvcCA9IDY0MDtcbiAgICBuYXZpZ2F0ZSgnL2FwcC9jb250ZW50L2IubWR4Jyk7XG4gICAgZXhwZWN0KGVsLnNjcm9sbFRvcCkudG9CZSg2NDApO1xuXG4gICAgYWN0KCgpID0+IHJlY2VpdmVOYXZpZ2F0aW9uKHsgc3RhdGU6IHVuZGVmaW5lZCwgZGlyZWN0aW9uOiAncHVzaCcgfSkpO1xuICAgIGVsLnNjcm9sbFRvcCA9IDkwMDtcbiAgICBuYXZpZ2F0ZSgnL2FwcC9jb250ZW50L2MubWR4Jyk7XG4gICAgZXhwZWN0KGVsLnNjcm9sbFRvcCkudG9CZSgwKTtcbiAgICB1bm1vdW50KCk7XG4gIH0pO1xufSk7XG4iXSwibWFwcGluZ3MiOiI7O0FBQ0EsSUFBQUEsT0FBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsTUFBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsT0FBQSxHQUFBRixPQUFBO0FBQ0EsSUFBQUcsSUFBQSxHQUFBSCxPQUFBO0FBQ0EsSUFBQUksZUFBQSxHQUFBSixPQUFBO0FBQWtELElBQUFLLFdBQUEsR0FBQUwsT0FBQTtBQUFBLElBQUFNLEVBQUEsR0FBQUMsWUFBQSxJQUxsRDtBQU9BO0FBQ0E7QUFDQTtBQUNBLFNBQVNDLEtBQUtBLENBQUM7RUFBRUMsUUFBUTtFQUFFQztBQUF5QyxDQUFDLEVBQUU7RUFBQUosRUFBQTtFQUNyRSxNQUFNSyxHQUFHLEdBQUcsSUFBQUMsOEJBQWMsRUFBQ0gsUUFBUSxFQUFFQyxJQUFJLENBQUM7RUFDMUMsb0JBQU8sSUFBQUwsV0FBQSxDQUFBUSxHQUFBO0lBQUtGLEdBQUcsRUFBRUEsR0FBSTtJQUFDLGVBQVk7RUFBVSxDQUFFLENBQUM7QUFDakQ7O0FBRUE7QUFBQUwsRUFBQSxDQUxTRSxLQUFLO0VBQUEsUUFDQUksOEJBQWM7QUFBQTtBQUFBRSxFQUFBLEdBRG5CTixLQUFLO0FBTWQsU0FBU08sS0FBS0EsQ0FBQ04sUUFBZ0IsRUFBRUMsSUFBSSxHQUFHLEVBQUUsRUFBRTtFQUMxQyxNQUFNTSxJQUFJLEdBQUdDLFFBQVEsQ0FBQ0MsYUFBYSxDQUFDLEtBQUssQ0FBQztFQUMxQ0QsUUFBUSxDQUFDRSxJQUFJLENBQUNDLFdBQVcsQ0FBQ0osSUFBSSxDQUFDO0VBQy9CLE1BQU1LLElBQUksR0FBRyxJQUFBQyxrQkFBVSxFQUFDTixJQUFJLENBQUM7RUFDN0IsSUFBQU8sVUFBRyxFQUFDLE1BQU1GLElBQUksQ0FBQ0csTUFBTSxjQUFDLElBQUFuQixXQUFBLENBQUFRLEdBQUEsRUFBQ0wsS0FBSztJQUFDQyxRQUFRLEVBQUVBLFFBQVM7SUFBQ0MsSUFBSSxFQUFFQTtFQUFLLENBQUUsQ0FBQyxDQUFDLENBQUM7RUFDakUsTUFBTWUsRUFBRSxHQUFHVCxJQUFJLENBQUNVLGFBQWEsQ0FBaUIsMEJBQTBCLENBQUU7RUFDMUUsT0FBTztJQUNMRCxFQUFFO0lBQ0ZFLFFBQVEsRUFBRUEsQ0FBQ0MsT0FBZSxFQUFFQyxRQUFRLEdBQUcsRUFBRSxLQUN2QyxJQUFBTixVQUFHLEVBQUMsTUFBTUYsSUFBSSxDQUFDRyxNQUFNLGNBQUMsSUFBQW5CLFdBQUEsQ0FBQVEsR0FBQSxFQUFDTCxLQUFLO01BQUNDLFFBQVEsRUFBRW1CLE9BQVE7TUFBQ2xCLElBQUksRUFBRW1CO0lBQVMsQ0FBRSxDQUFDLENBQUMsQ0FBQztJQUN0RUMsT0FBTyxFQUFFQSxDQUFBLEtBQU07TUFDYixJQUFBUCxVQUFHLEVBQUMsTUFBTUYsSUFBSSxDQUFDUyxPQUFPLENBQUMsQ0FBQyxDQUFDO01BQ3pCZCxJQUFJLENBQUNlLE1BQU0sQ0FBQyxDQUFDO0lBQ2Y7RUFDRixDQUFDO0FBQ0g7QUFFQSxJQUFBQyxnQkFBUSxFQUFDLGdCQUFnQixFQUFFLE1BQU07RUFDL0IsSUFBQUMsVUFBRSxFQUFDLDJEQUEyRCxFQUFFLE1BQU07SUFDcEUsTUFBTTtNQUFFUixFQUFFO01BQUVFLFFBQVE7TUFBRUc7SUFBUSxDQUFDLEdBQUdmLEtBQUssQ0FBQyxnREFBZ0QsQ0FBQztJQUN6RjtJQUNBVSxFQUFFLENBQUNTLFNBQVMsR0FBRyxJQUFJO0lBQ25CUCxRQUFRLENBQUMsaUNBQWlDLENBQUM7SUFDM0MsSUFBQVEsY0FBTSxFQUFDVixFQUFFLENBQUNTLFNBQVMsQ0FBQyxDQUFDRSxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQzVCTixPQUFPLENBQUMsQ0FBQztFQUNYLENBQUMsQ0FBQztFQUVGLElBQUFHLFVBQUUsRUFBQywrRUFBK0UsRUFBRSxNQUFNO0lBQ3hGLE1BQU07TUFBRVIsRUFBRTtNQUFFRSxRQUFRO01BQUVHO0lBQVEsQ0FBQyxHQUFHZixLQUFLLENBQUMsb0JBQW9CLENBQUM7SUFDN0RVLEVBQUUsQ0FBQ1MsU0FBUyxHQUFHLEdBQUc7SUFDbEJQLFFBQVEsQ0FBQyxvQkFBb0IsRUFBRSxRQUFRLENBQUM7SUFDeEMsSUFBQVEsY0FBTSxFQUFDVixFQUFFLENBQUNTLFNBQVMsQ0FBQyxDQUFDRSxJQUFJLENBQUMsR0FBRyxDQUFDO0lBQzlCTixPQUFPLENBQUMsQ0FBQztFQUNYLENBQUMsQ0FBQztFQUVGLElBQUFHLFVBQUUsRUFBQyx5REFBeUQsRUFBRSxNQUFNO0lBQ2xFO0lBQ0E7SUFDQTtJQUNBO0lBQ0EsTUFBTUksSUFBSSxHQUFHdEIsS0FBSyxDQUFDLG9CQUFvQixDQUFDO0lBQ3hDc0IsSUFBSSxDQUFDWixFQUFFLENBQUNTLFNBQVMsR0FBRyxHQUFHO0lBQ3ZCRyxJQUFJLENBQUNWLFFBQVEsQ0FBQyxvQkFBb0IsRUFBRSw0QkFBNEIsQ0FBQztJQUNqRSxJQUFBUSxjQUFNLEVBQUNFLElBQUksQ0FBQ1osRUFBRSxDQUFDUyxTQUFTLENBQUMsQ0FBQ0UsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUNqQ0MsSUFBSSxDQUFDUCxPQUFPLENBQUMsQ0FBQztJQUVkLE1BQU1RLEtBQUssR0FBR3ZCLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQztJQUN6Q3VCLEtBQUssQ0FBQ2IsRUFBRSxDQUFDUyxTQUFTLEdBQUcsR0FBRztJQUN4QkksS0FBSyxDQUFDWCxRQUFRLENBQUMsb0JBQW9CLEVBQUUsc0JBQXNCLENBQUM7SUFDNUQsSUFBQVEsY0FBTSxFQUFDRyxLQUFLLENBQUNiLEVBQUUsQ0FBQ1MsU0FBUyxDQUFDLENBQUNFLElBQUksQ0FBQyxHQUFHLENBQUM7SUFDcENFLEtBQUssQ0FBQ1IsT0FBTyxDQUFDLENBQUM7RUFDakIsQ0FBQyxDQUFDO0VBRUYsSUFBQUcsVUFBRSxFQUFDLG1FQUFtRSxFQUFFLE1BQU07SUFDNUU7SUFDQTtJQUNBO0lBQ0EsTUFBTTtNQUFFUixFQUFFO01BQUVFLFFBQVE7TUFBRUc7SUFBUSxDQUFDLEdBQUdmLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQztJQUM3RFUsRUFBRSxDQUFDUyxTQUFTLEdBQUcsSUFBSTtJQUNuQlAsUUFBUSxDQUFDLG9CQUFvQixDQUFDO0lBQzlCLElBQUFRLGNBQU0sRUFBQ1YsRUFBRSxDQUFDUyxTQUFTLENBQUMsQ0FBQ0UsSUFBSSxDQUFDLElBQUksQ0FBQztJQUMvQk4sT0FBTyxDQUFDLENBQUM7RUFDWCxDQUFDLENBQUM7RUFFRixJQUFBRyxVQUFFLEVBQUMsNkRBQTZELEVBQUUsTUFBTTtJQUN0RTtJQUNBO0lBQ0EsTUFBTTtNQUFFUixFQUFFO01BQUVFLFFBQVE7TUFBRUc7SUFBUSxDQUFDLEdBQUdmLEtBQUssQ0FBQyxvQkFBb0IsRUFBRSxRQUFRLENBQUM7SUFDdkVVLEVBQUUsQ0FBQ1MsU0FBUyxHQUFHLEdBQUc7SUFDbEJQLFFBQVEsQ0FBQyxvQkFBb0IsRUFBRSxFQUFFLENBQUM7SUFDbEMsSUFBQVEsY0FBTSxFQUFDVixFQUFFLENBQUNTLFNBQVMsQ0FBQyxDQUFDRSxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQzVCTixPQUFPLENBQUMsQ0FBQztFQUNYLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQztBQUVGLElBQUFFLGdCQUFRLEVBQUMsZ0RBQWdELEVBQUUsTUFBTTtFQUMvRDtFQUNBO0VBQ0E7RUFDQTtFQUNBLElBQUFPLGlCQUFTLEVBQUMsTUFBTSxJQUFBQyxvQkFBZSxFQUFDLENBQUMsQ0FBQztFQUVsQyxJQUFBUCxVQUFFLEVBQUMsMERBQTBELEVBQUUsTUFBTTtJQUNuRSxNQUFNO01BQUVSLEVBQUU7TUFBRUUsUUFBUTtNQUFFRztJQUFRLENBQUMsR0FBR2YsS0FBSyxDQUFDLG9CQUFvQixDQUFDO0lBQzdELElBQUFRLFVBQUcsRUFBQyxNQUFNLElBQUFrQixzQkFBaUIsRUFBQztNQUFFQyxLQUFLLEVBQUU7UUFBRSxXQUFXLEVBQUU7TUFBSSxDQUFDO01BQUVDLFNBQVMsRUFBRTtJQUFPLENBQUMsQ0FBQyxDQUFDO0lBQ2hGO0lBQ0FsQixFQUFFLENBQUNTLFNBQVMsR0FBRyxHQUFHO0lBQ2xCUCxRQUFRLENBQUMsZ0RBQWdELENBQUM7SUFDMUQsSUFBQVEsY0FBTSxFQUFDVixFQUFFLENBQUNTLFNBQVMsQ0FBQyxDQUFDRSxJQUFJLENBQUMsR0FBRyxDQUFDO0lBQzlCTixPQUFPLENBQUMsQ0FBQztFQUNYLENBQUMsQ0FBQztFQUVGLElBQUFHLFVBQUUsRUFBQyw0RUFBNEUsRUFBRSxNQUFNO0lBQ3JGLE1BQU07TUFBRVIsRUFBRTtNQUFFRSxRQUFRO01BQUVHO0lBQVEsQ0FBQyxHQUFHZixLQUFLLENBQUMsb0JBQW9CLENBQUM7SUFDN0QsSUFBQVEsVUFBRyxFQUFDLE1BQU0sSUFBQWtCLHNCQUFpQixFQUFDO01BQUVDLEtBQUssRUFBRTtRQUFFLFdBQVcsRUFBRTtNQUFJLENBQUM7TUFBRUMsU0FBUyxFQUFFO0lBQVUsQ0FBQyxDQUFDLENBQUM7SUFDbkZsQixFQUFFLENBQUNTLFNBQVMsR0FBRyxHQUFHO0lBQ2xCUCxRQUFRLENBQUMsb0JBQW9CLENBQUM7SUFDOUIsSUFBQVEsY0FBTSxFQUFDVixFQUFFLENBQUNTLFNBQVMsQ0FBQyxDQUFDRSxJQUFJLENBQUMsR0FBRyxDQUFDO0lBQzlCTixPQUFPLENBQUMsQ0FBQztFQUNYLENBQUMsQ0FBQztFQUVGLElBQUFHLFVBQUUsRUFBQywwREFBMEQsRUFBRSxNQUFNO0lBQ25FO0lBQ0EsTUFBTTtNQUFFUixFQUFFO01BQUVFLFFBQVE7TUFBRUc7SUFBUSxDQUFDLEdBQUdmLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQztJQUM3RCxJQUFBUSxVQUFHLEVBQUMsTUFBTSxJQUFBa0Isc0JBQWlCLEVBQUM7TUFBRUMsS0FBSyxFQUFFO1FBQUUsV0FBVyxFQUFFO01BQUksQ0FBQztNQUFFQyxTQUFTLEVBQUU7SUFBTyxDQUFDLENBQUMsQ0FBQztJQUNoRmxCLEVBQUUsQ0FBQ1MsU0FBUyxHQUFHLEdBQUc7SUFDbEJQLFFBQVEsQ0FBQyxvQkFBb0IsQ0FBQztJQUM5QixJQUFBUSxjQUFNLEVBQUNWLEVBQUUsQ0FBQ1MsU0FBUyxDQUFDLENBQUNFLElBQUksQ0FBQyxHQUFHLENBQUM7SUFFOUIsSUFBQWIsVUFBRyxFQUFDLE1BQU0sSUFBQWtCLHNCQUFpQixFQUFDO01BQUVDLEtBQUssRUFBRUUsU0FBUztNQUFFRCxTQUFTLEVBQUU7SUFBTyxDQUFDLENBQUMsQ0FBQztJQUNyRWxCLEVBQUUsQ0FBQ1MsU0FBUyxHQUFHLEdBQUc7SUFDbEJQLFFBQVEsQ0FBQyxvQkFBb0IsQ0FBQztJQUM5QixJQUFBUSxjQUFNLEVBQUNWLEVBQUUsQ0FBQ1MsU0FBUyxDQUFDLENBQUNFLElBQUksQ0FBQyxDQUFDLENBQUM7SUFDNUJOLE9BQU8sQ0FBQyxDQUFDO0VBQ1gsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDO0FBQUMsSUFBQWhCLEVBQUE7QUFBQStCLFlBQUEsQ0FBQS9CLEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}