var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = GroveAgent;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
require("core-js/modules/esnext.iterator.some.js");
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
var _shell = require("../lib/shell");
var _useHeadings = require("../hooks/useHeadings");
var _useOverlayFocusDismiss = require("../hooks/useOverlayFocusDismiss");
var _contentRoot = require("../lib/contentRoot");
var _agentTools = require("../lib/agentTools");
var _agentPrompt = require("../lib/agentPrompt");
var _reachCard = require("../lib/reachCard");
var _agentTranscript = require("../lib/agentTranscript");
var _useCatalogAnswered = require("../hooks/useCatalogAnswered");
var _safeSources = require("../lib/safeSources");
var _Icon = _interopRequireDefault(require("./Icon"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // `.grove-agent` — Grove's own embedded agent (GROVE_AGENT_SPEC).
//
// The surface is a FUNCTION of the session's envelope (R-GA-1): the reach card in
// the expanded header is computed from the provider four-state (R3-688 added the
// host-marked `ungranted` — the distinct not-granted cause), the `llm:chat`
// grant (the grant-filtered catalog), mount writability, the corpus packaging,
// tools support, and source trust — never hand-written copy. The loop rides the
// workbench's seam — SDK `runAgent` over the host `llm.chat` slot — and its two
// tools are the mount-chrooted `read_entry` and
// the index query (R-GA-2). The widget never writes (R-GA-3): every change is a
// hand-off to the editor / workbench. Read-only never blocks Q&A (R-GA-5). When a
// provider is bound the egress line is shown unconditionally (R-GA-6). Every
// corpus-derived byte entering the loop is fenced (R-GA-7).
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function GroveAgent({
  writable,
  entryKey,
  entryTitle
}) {
  _s();
  const providerState = (0, _sdk.useChatProviderState)();
  const catalog = (0, _sdk.useCatalog)();
  const index = (0, _sdk.useAllMetadata)();
  const headings = (0, _useHeadings.useHeadings)(entryKey);
  const activeHeading = (0, _useHeadings.useActiveHeading)(headings);
  const {
    openEditor,
    editRefused
  } = (0, _shell.useShell)();
  const [open, setOpen] = (0, _react.useState)(false);
  const [detent, setDetent] = (0, _react.useState)('half');
  const [resting, setResting] = (0, _react.useState)('');
  const [draft, setDraft] = (0, _react.useState)('');
  const [rows, setRows] = (0, _react.useState)([]);
  const [streaming, setStreaming] = (0, _react.useState)(false);
  const [errorToast, setErrorToast] = (0, _react.useState)(null);
  const bodyRef = (0, _react.useRef)(null);
  const footRef = (0, _react.useRef)(null);
  // One AbortController per run (R3-608): the composer's stop control aborts the
  // in-flight run through the SDK signal the loop already honours.
  const abortRef = (0, _react.useRef)(null);
  // The panel carries the dialog contract (R3-608): focus in, Tab trapped,
  // Escape, focus return — the shared hook, stack-aware.
  const dialogRef = (0, _useOverlayFocusDismiss.useOverlayFocusDismiss)(open, () => setOpen(false));

  // The envelope, computed (R-GA-1). `llm:chat` appears in the grant-filtered
  // catalog iff this app holds the consent — an ungranted fork reads a DISTINCT
  // cause from a user without a key (G-GA-10).
  const chatGranted = catalog.some(m => m.name === 'llm:chat');
  // Distinguishes "granted nothing" from "has not replied yet" — `catalog` alone cannot,
  // because an empty catalog is a legitimate answer. See the hook for how it is derived.
  const catalogAnswered = (0, _useCatalogAnswered.useCatalogAnswered)();
  const context = (0, _sdk.useAgentContext)({
    entryPath: entryKey,
    entryTitle,
    heading: activeHeading || undefined
  });
  // G-GA-8: a provider without `features.tools` degrades to context-stuffing.
  // Computed ONCE at render scope — the reach card's Q&A qualifier (R3-752) and the
  // ask() path below read the same fact, never two computations of it.
  const toolsSupported = providerState.status === 'configured' && providerState.provider.features.tools === true;
  const reachRows = (0, _react.useMemo)(() => (0, _reachCard.computeReachRows)({
    providerState,
    chatGranted,
    catalogAnswered,
    writable,
    sourceShared: context.sourceShared,
    mountId: (0, _contentRoot.getCorpusMountId)(),
    toolsSupported
  }), [providerState, chatGranted, catalogAnswered, writable, context.sourceShared, toolsSupported]);
  const chips = (0, _react.useMemo)(() => (0, _reachCard.reachChips)(reachRows), [reachRows]);
  const trustLine = (0, _react.useMemo)(() => (0, _reachCard.sourceTrustLine)(context.sourceShared, context.sourceSharedBasis), [context.sourceShared, context.sourceSharedBasis]);
  // R-IX-7 (R3-752): a state flip is ANNOUNCED, not only re-rendered — one standing
  // polite live region whose text is the card's computed summary. A grant flip
  // changes the text, which is what a status region announces; the visually hidden
  // per-row words are static text and announce nothing.
  const reachAnnouncement = (0, _react.useMemo)(() => `What the agent can do here: ${reachRows.map(r => `${r.label} — ${(0, _reachCard.stateWord)(r.state)}`).join('; ')}`, [reachRows]);
  const canAsk = providerState.status === 'configured' && chatGranted;

  // Read at CALL time (a scan may land, the reader may navigate) — refs kept fresh
  // in an effect, never written during render (the react-hooks compiler rejects that).
  const indexRef = (0, _react.useRef)(index);
  const contextRef = (0, _react.useRef)(context);
  const entryRef = (0, _react.useRef)(entryKey);
  const headingRef = (0, _react.useRef)(activeHeading);
  (0, _react.useEffect)(() => {
    indexRef.current = index;
    contextRef.current = context;
    entryRef.current = entryKey;
    headingRef.current = activeHeading;
  }, [index, context, entryKey, activeHeading]);

  // The loop's transcript, kept so follow-up questions replay the tool-use chain.
  const transcriptRef = (0, _react.useRef)([]);
  (0, _react.useEffect)(() => {
    if (open) requestAnimationFrame(() => footRef.current?.focus());
  }, [open]);
  // The panel's only trigger (the resting input) UNMOUNTS when it opens, and
  // its onFocus IS the open action — returning focus to it would reopen the
  // panel. So the close path returns focus to the resting line's SUBMIT
  // control (R-IX-1): a real stop in the same surface that never reopens
  // anything, so Escape never strands the keyboard on <body>. On mount the
  // effect stays quiet (was-open gate) or the panel would open itself.
  const restingGoRef = (0, _react.useRef)(null);
  const wasOpenRef = (0, _react.useRef)(false);
  (0, _react.useEffect)(() => {
    if (wasOpenRef.current && !open) requestAnimationFrame(() => restingGoRef.current?.focus());
    wasOpenRef.current = open;
  }, [open]);
  (0, _react.useEffect)(() => {
    bodyRef.current?.scrollTo({
      top: bodyRef.current.scrollHeight
    });
  }, [rows, streaming]);
  async function ask(question) {
    const q = question.trim();
    if (!q || streaming) return;
    setOpen(true);
    setDraft('');
    setResting('');
    setErrorToast(null);
    setRows(prev => [...prev, {
      kind: 'user',
      text: q
    }]);
    setStreaming(true);

    // G-GA-8: a provider without `features.tools` degrades to context-stuffing —
    // the deixis block, an index summary, and the current entry body ride the
    // prompt; the request carries ZERO tools. The same hoisted fact the reach
    // card's Q&A qualifier reads (R3-752) — computed once at render scope.
    const chroot = (0, _contentRoot.getContentRoot)();
    const currentKey = entryRef.current;
    const contextBlock = (0, _sdk.renderAgentContext)({
      ...contextRef.current,
      entryPath: currentKey,
      heading: headingRef.current || undefined
    });
    let stuffedBody;
    if (!toolsSupported) {
      stuffedBody = await _safeSources.safeSources.read(currentKey).catch(() => undefined);
    }
    const system = (0, _agentPrompt.buildSystemPrompt)({
      contextBlock,
      toolsSupported,
      ...(toolsSupported ? {} : {
        entryBody: stuffedBody,
        entryPath: currentKey,
        index: indexRef.current,
        chroot
      })
    });
    const entryTool = (0, _agentTools.createReadEntryTool)(chroot);
    const metaTool = (0, _agentTools.createGroveMetadataTool)(chroot, () => indexRef.current);
    const execute = (0, _agentTools.toolExecutor)([entryTool, metaTool]);
    const tools = toolsSupported ? (0, _agentTools.groveAgentTools)(chroot, () => indexRef.current) : [];
    let acc = '';
    const pushAssistant = text => setRows(prev => {
      const next = prev.slice();
      if (next.length && next[next.length - 1].kind === 'assistant') next[next.length - 1] = {
        kind: 'assistant',
        text
      };else next.push({
        kind: 'assistant',
        text
      });
      return next;
    });
    const controller = new AbortController();
    abortRef.current = controller;
    try {
      const final = await (0, _sdk.runAgent)({
        client: (0, _sdk.createChatModelClient)(),
        tools,
        execute,
        system,
        prompt: q,
        history: transcriptRef.current,
        maxTurns: 8,
        signal: controller.signal,
        events: {
          onAssistantDelta: t => {
            acc += t;
            pushAssistant(acc);
          },
          onToolUse: (name, input) => {
            acc = '';
            setRows(prev => {
              const next = prev.slice();
              if (next.length && next[next.length - 1].kind === 'assistant' && !next[next.length - 1].text) next.pop();
              next.push({
                kind: 'activity',
                text: (0, _agentTranscript.toolActivityLine)(name, input)
              });
              return next;
            });
          }
        }
      });
      const rendered = (0, _agentTranscript.transcriptToRows)(final);
      // The real loop RESOLVES an aborted run with the partial transcript (a
      // clean stop, never a thrown error) — so the abort check lives here too,
      // not only in the catch: a stopped run keeps what streamed and appends a
      // named Stopped row (R3-608).
      if (controller.signal.aborted) {
        setRows(prev => [...prev, {
          kind: 'activity',
          text: 'Stopped'
        }]);
        return;
      }
      if (!rendered.some(r => r.kind === 'assistant')) throw new Error('empty');
      transcriptRef.current = final.slice();
      setRows(rendered);
    } catch (e) {
      // A stop is not an error (R3-608): the aborted run settles with a named
      // "Stopped" row, and the transcript keeps what streamed so far.
      if (controller.signal.aborted) {
        setRows(prev => [...prev, {
          kind: 'activity',
          text: 'Stopped'
        }]);
        return;
      }
      const code = e?.code || e.message;
      setErrorToast(code === 'auth-required' ? 'no model key connected — add one in Settings' : code === 'forbidden' ? _reachCard.UNGRANTED_CHAT_CAUSE : code === 'cancelled' ? `chat didn't start — ${_reachCard.READING_WORKS_NORMAL}; you can try again anytime` : 'the model or backend errored — try again in a moment');
      setRows(prev => prev.length && prev[prev.length - 1].kind === 'assistant' && !prev[prev.length - 1].text ? prev.slice(0, -1) : prev);
    } finally {
      setStreaming(false);
      if (abortRef.current === controller) abortRef.current = null;
    }
  }
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "grove-agent",
    children: [!open && /*#__PURE__*/(0, _jsxRuntime.jsxs)("form", {
      className: "ga-line",
      onSubmit: e => {
        e.preventDefault();
        if (canAsk) void ask(resting);else setOpen(true);
      },
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "mk"
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("input", {
        value: resting,
        placeholder: `Ask Grove about “${entryTitle}”…`,
        onChange: e => setResting(e.target.value),
        onFocus: () => setOpen(true),
        "aria-label": "Ask Grove"
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        ref: restingGoRef,
        className: "go",
        type: "submit",
        "aria-label": "Ask Grove",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
          name: "send"
        })
      })]
    }), open && /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "ga-scrim",
        onClick: () => setOpen(false)
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "ga-panel",
        "data-detent": detent,
        ref: dialogRef,
        tabIndex: -1,
        role: "dialog",
        "aria-modal": "true",
        "aria-label": "Ask Grove",
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
          className: "ga-panel-inner",
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
            className: "ga-head",
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
              className: "grip",
              onClick: () => setDetent(d => d === 'half' ? 'full' : 'half')
            }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
              className: "mk"
            }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
              className: "id",
              children: "Grove"
            }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
              className: "grow",
              children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
                className: "ic",
                "aria-label": detent === 'half' ? 'Expand' : 'Collapse',
                onClick: () => setDetent(d => d === 'half' ? 'full' : 'half'),
                children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
                  name: detent === 'half' ? 'chevron-down' : 'chevron-right'
                })
              }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
                className: "ic",
                "aria-label": "Close",
                onClick: () => setOpen(false),
                children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
                  name: "x"
                })
              })]
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
            className: "ga-reach",
            role: "list",
            "aria-label": "What the agent can do here",
            children: reachRows.map(r => /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
              className: `ga-reach__row ga-reach__row--${r.state}`,
              role: "listitem",
              children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
                className: "ga-reach__mark",
                "aria-hidden": true,
                children: r.state === 'ok' ? '✓' : r.state === 'blocked' ? '✗' : r.state === 'elsewhere' ? '→' : '·'
              }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
                className: "ga-reach__stateword",
                children: (0, _reachCard.stateWord)(r.state)
              }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
                className: "ga-reach__label",
                children: r.label
              }), r.cause && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
                className: "ga-reach__cause",
                children: r.cause
              }), r.destination && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
                className: "ga-reach__cause",
                children: `→ ${r.destination}`
              }), r.action === 'enable-chat' &&
              /*#__PURE__*/
              // R3-790: the earning affordance. Its click invokes ask() — the
              // ungranted llm:chat invoke fires the HOST's consent dialog on this
              // same activation (site-main#612), Allow mints + lifts, and the
              // same ask proceeds to stream. A decline answers 'cancelled' (the
              // catch below) and the row stays honestly ✗.
              (0, _jsxRuntime.jsx)("button", {
                type: "button",
                className: "ga-reach__enable",
                onClick: () => void ask(draft.trim() || 'Answer in one sentence: what can you tell me about this wiki?'),
                children: "Enable chat"
              })]
            }, r.key))
          }), trustLine && /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
            className: "ga-egress",
            children: trustLine
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
            className: "ga-reach__stateword",
            role: "status",
            children: reachAnnouncement
          }), (0, _reachCard.showEgressDisclosure)(providerState) && /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
            className: "ga-egress",
            children: _reachCard.EGRESS_DISCLOSURE
          }), errorToast && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
            className: "ga-toast",
            role: "status",
            children: errorToast
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
            className: "ga-body",
            ref: bodyRef,
            children: rows.length === 0 ? /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
              children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
                className: "ga-explain",
                children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("b", {
                  children: "Grove's agent"
                }), " answers questions about this wiki \u2014 its entries, tags, and structure \u2014 from the page you're on."]
              }), chips.length > 0 && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
                className: "ga-chips",
                children: chips.map(c => /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
                  className: "ga-chip",
                  onClick: () => void ask(c),
                  children: c
                }, c))
              })]
            }) : rows.map((r, i) => r.kind === 'activity' ? /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
              className: "ga-activity",
              children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
                name: "file"
              }), r.text]
            }, i) : /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
              className: `ga-msg ${r.kind}`,
              children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
                className: `ga-msg__av ${r.kind === 'assistant' ? 'grove' : 'user'}`,
                children: r.kind === 'assistant' ? '' : 'you'
              }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
                className: "ga-msg__b",
                children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
                  className: "ga-msg__who",
                  children: r.kind === 'assistant' ? 'Grove' : 'You'
                }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
                  className: "ga-msg__txt",
                  children: [r.text, streaming && i === rows.length - 1 && r.kind === 'assistant' ? /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
                    className: "ga-cursor"
                  }) : null]
                })]
              })]
            }, i))
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
            className: "ga-foot",
            children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("form", {
              className: "ga-foot__row",
              onSubmit: e => {
                e.preventDefault();
                void ask(draft);
              },
              children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("input", {
                ref: footRef,
                value: draft,
                placeholder: "Ask Grove\u2026",
                disabled: streaming || !canAsk,
                onChange: e => setDraft(e.target.value)
              }), streaming ? /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
                className: "stop",
                type: "button",
                "aria-label": "Stop",
                title: "Stop",
                onClick: () => abortRef.current?.abort(),
                children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
                  name: "x"
                })
              }) : null, /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
                className: "go",
                type: "submit",
                disabled: streaming || !canAsk || !draft.trim(),
                "aria-label": streaming ? 'Answering…' : 'Send',
                title: streaming ? 'Answering…' : 'Send',
                children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
                  name: "send"
                })
              })]
            }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
              className: "ga-foot__hand",
              children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
                children: _reachCard.EGRESS_DISCLOSURE
              }), editRefused && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
                className: "ga-edit-refused",
                role: "status",
                children: _shell.EDIT_REFUSED_NOTICE
              }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
                type: "button",
                onClick: () => openEditor(entryKey),
                children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
                  name: "external"
                }), "Open in the editor"]
              })]
            })]
          })]
        })
      })]
    })]
  });
}
_s(GroveAgent, "A9H/aJwB7+/1wRj1lKl+fWpL/So=", false, function () {
  return [_sdk.useChatProviderState, _sdk.useCatalog, _sdk.useAllMetadata, _useHeadings.useHeadings, _useHeadings.useActiveHeading, _shell.useShell, _useOverlayFocusDismiss.useOverlayFocusDismiss, _useCatalogAnswered.useCatalogAnswered, _sdk.useAgentContext];
});
_c = GroveAgent;
var _c;
$RefreshReg$(_c, "GroveAgent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NkayIsIl9zaGVsbCIsIl91c2VIZWFkaW5ncyIsIl91c2VPdmVybGF5Rm9jdXNEaXNtaXNzIiwiX2NvbnRlbnRSb290IiwiX2FnZW50VG9vbHMiLCJfYWdlbnRQcm9tcHQiLCJfcmVhY2hDYXJkIiwiX2FnZW50VHJhbnNjcmlwdCIsIl91c2VDYXRhbG9nQW5zd2VyZWQiLCJfc2FmZVNvdXJjZXMiLCJfSWNvbiIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiR3JvdmVBZ2VudCIsIndyaXRhYmxlIiwiZW50cnlLZXkiLCJlbnRyeVRpdGxlIiwicHJvdmlkZXJTdGF0ZSIsInVzZUNoYXRQcm92aWRlclN0YXRlIiwiY2F0YWxvZyIsInVzZUNhdGFsb2ciLCJpbmRleCIsInVzZUFsbE1ldGFkYXRhIiwiaGVhZGluZ3MiLCJ1c2VIZWFkaW5ncyIsImFjdGl2ZUhlYWRpbmciLCJ1c2VBY3RpdmVIZWFkaW5nIiwib3BlbkVkaXRvciIsImVkaXRSZWZ1c2VkIiwidXNlU2hlbGwiLCJvcGVuIiwic2V0T3BlbiIsInVzZVN0YXRlIiwiZGV0ZW50Iiwic2V0RGV0ZW50IiwicmVzdGluZyIsInNldFJlc3RpbmciLCJkcmFmdCIsInNldERyYWZ0Iiwicm93cyIsInNldFJvd3MiLCJzdHJlYW1pbmciLCJzZXRTdHJlYW1pbmciLCJlcnJvclRvYXN0Iiwic2V0RXJyb3JUb2FzdCIsImJvZHlSZWYiLCJ1c2VSZWYiLCJmb290UmVmIiwiYWJvcnRSZWYiLCJkaWFsb2dSZWYiLCJ1c2VPdmVybGF5Rm9jdXNEaXNtaXNzIiwiY2hhdEdyYW50ZWQiLCJzb21lIiwibSIsIm5hbWUiLCJjYXRhbG9nQW5zd2VyZWQiLCJ1c2VDYXRhbG9nQW5zd2VyZWQiLCJjb250ZXh0IiwidXNlQWdlbnRDb250ZXh0IiwiZW50cnlQYXRoIiwiaGVhZGluZyIsInVuZGVmaW5lZCIsInRvb2xzU3VwcG9ydGVkIiwic3RhdHVzIiwicHJvdmlkZXIiLCJmZWF0dXJlcyIsInRvb2xzIiwicmVhY2hSb3dzIiwidXNlTWVtbyIsImNvbXB1dGVSZWFjaFJvd3MiLCJzb3VyY2VTaGFyZWQiLCJtb3VudElkIiwiZ2V0Q29ycHVzTW91bnRJZCIsImNoaXBzIiwicmVhY2hDaGlwcyIsInRydXN0TGluZSIsInNvdXJjZVRydXN0TGluZSIsInNvdXJjZVNoYXJlZEJhc2lzIiwicmVhY2hBbm5vdW5jZW1lbnQiLCJtYXAiLCJyIiwibGFiZWwiLCJzdGF0ZVdvcmQiLCJzdGF0ZSIsImpvaW4iLCJjYW5Bc2siLCJpbmRleFJlZiIsImNvbnRleHRSZWYiLCJlbnRyeVJlZiIsImhlYWRpbmdSZWYiLCJ1c2VFZmZlY3QiLCJjdXJyZW50IiwidHJhbnNjcmlwdFJlZiIsInJlcXVlc3RBbmltYXRpb25GcmFtZSIsImZvY3VzIiwicmVzdGluZ0dvUmVmIiwid2FzT3BlblJlZiIsInNjcm9sbFRvIiwidG9wIiwic2Nyb2xsSGVpZ2h0IiwiYXNrIiwicXVlc3Rpb24iLCJxIiwidHJpbSIsInByZXYiLCJraW5kIiwidGV4dCIsImNocm9vdCIsImdldENvbnRlbnRSb290IiwiY3VycmVudEtleSIsImNvbnRleHRCbG9jayIsInJlbmRlckFnZW50Q29udGV4dCIsInN0dWZmZWRCb2R5Iiwic2FmZVNvdXJjZXMiLCJyZWFkIiwiY2F0Y2giLCJzeXN0ZW0iLCJidWlsZFN5c3RlbVByb21wdCIsImVudHJ5Qm9keSIsImVudHJ5VG9vbCIsImNyZWF0ZVJlYWRFbnRyeVRvb2wiLCJtZXRhVG9vbCIsImNyZWF0ZUdyb3ZlTWV0YWRhdGFUb29sIiwiZXhlY3V0ZSIsInRvb2xFeGVjdXRvciIsImdyb3ZlQWdlbnRUb29scyIsImFjYyIsInB1c2hBc3Npc3RhbnQiLCJuZXh0Iiwic2xpY2UiLCJsZW5ndGgiLCJwdXNoIiwiY29udHJvbGxlciIsIkFib3J0Q29udHJvbGxlciIsImZpbmFsIiwicnVuQWdlbnQiLCJjbGllbnQiLCJjcmVhdGVDaGF0TW9kZWxDbGllbnQiLCJwcm9tcHQiLCJoaXN0b3J5IiwibWF4VHVybnMiLCJzaWduYWwiLCJldmVudHMiLCJvbkFzc2lzdGFudERlbHRhIiwidCIsIm9uVG9vbFVzZSIsImlucHV0IiwicG9wIiwidG9vbEFjdGl2aXR5TGluZSIsInJlbmRlcmVkIiwidHJhbnNjcmlwdFRvUm93cyIsImFib3J0ZWQiLCJFcnJvciIsImNvZGUiLCJtZXNzYWdlIiwiVU5HUkFOVEVEX0NIQVRfQ0FVU0UiLCJSRUFESU5HX1dPUktTX05PUk1BTCIsImpzeHMiLCJjbGFzc05hbWUiLCJjaGlsZHJlbiIsIm9uU3VibWl0IiwicHJldmVudERlZmF1bHQiLCJqc3giLCJ2YWx1ZSIsInBsYWNlaG9sZGVyIiwib25DaGFuZ2UiLCJ0YXJnZXQiLCJvbkZvY3VzIiwicmVmIiwidHlwZSIsIkZyYWdtZW50Iiwib25DbGljayIsInRhYkluZGV4Iiwicm9sZSIsImQiLCJjYXVzZSIsImRlc3RpbmF0aW9uIiwiYWN0aW9uIiwia2V5Iiwic2hvd0VncmVzc0Rpc2Nsb3N1cmUiLCJFR1JFU1NfRElTQ0xPU1VSRSIsImMiLCJpIiwiZGlzYWJsZWQiLCJ0aXRsZSIsImFib3J0IiwiRURJVF9SRUZVU0VEX05PVElDRSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiR3JvdmVBZ2VudC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VNZW1vLCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHtcbiAgcnVuQWdlbnQsXG4gIGNyZWF0ZUNoYXRNb2RlbENsaWVudCxcbiAgdXNlQ2hhdFByb3ZpZGVyU3RhdGUsXG4gIHVzZUNhdGFsb2csXG4gIHVzZUFsbE1ldGFkYXRhLFxuICB1c2VBZ2VudENvbnRleHQsXG4gIHJlbmRlckFnZW50Q29udGV4dCxcbiAgdHlwZSBBZ2VudE1lc3NhZ2UsXG59IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrJztcbmltcG9ydCB7IHVzZVNoZWxsLCBFRElUX1JFRlVTRURfTk9USUNFIH0gZnJvbSAnLi4vbGliL3NoZWxsJztcbmltcG9ydCB7IHVzZUhlYWRpbmdzLCB1c2VBY3RpdmVIZWFkaW5nIH0gZnJvbSAnLi4vaG9va3MvdXNlSGVhZGluZ3MnO1xuaW1wb3J0IHsgdXNlT3ZlcmxheUZvY3VzRGlzbWlzcyB9IGZyb20gJy4uL2hvb2tzL3VzZU92ZXJsYXlGb2N1c0Rpc21pc3MnO1xuaW1wb3J0IHsgZ2V0Q29udGVudFJvb3QgfSBmcm9tICcuLi9saWIvY29udGVudFJvb3QnO1xuaW1wb3J0IHsgY3JlYXRlUmVhZEVudHJ5VG9vbCwgY3JlYXRlR3JvdmVNZXRhZGF0YVRvb2wsIGdyb3ZlQWdlbnRUb29scywgdG9vbEV4ZWN1dG9yIH0gZnJvbSAnLi4vbGliL2FnZW50VG9vbHMnO1xuaW1wb3J0IHsgYnVpbGRTeXN0ZW1Qcm9tcHQgfSBmcm9tICcuLi9saWIvYWdlbnRQcm9tcHQnO1xuaW1wb3J0IHsgY29tcHV0ZVJlYWNoUm93cywgcmVhY2hDaGlwcywgc291cmNlVHJ1c3RMaW5lLCBzdGF0ZVdvcmQsIHNob3dFZ3Jlc3NEaXNjbG9zdXJlLCBFR1JFU1NfRElTQ0xPU1VSRSwgVU5HUkFOVEVEX0NIQVRfQ0FVU0UsIFJFQURJTkdfV09SS1NfTk9STUFMIH0gZnJvbSAnLi4vbGliL3JlYWNoQ2FyZCc7XG5pbXBvcnQgeyBnZXRDb3JwdXNNb3VudElkIH0gZnJvbSAnLi4vbGliL2NvbnRlbnRSb290JztcbmltcG9ydCB7IHRyYW5zY3JpcHRUb1Jvd3MsIHRvb2xBY3Rpdml0eUxpbmUsIHR5cGUgQWdlbnRSb3cgfSBmcm9tICcuLi9saWIvYWdlbnRUcmFuc2NyaXB0JztcbmltcG9ydCB7IHVzZUNhdGFsb2dBbnN3ZXJlZCB9IGZyb20gJy4uL2hvb2tzL3VzZUNhdGFsb2dBbnN3ZXJlZCc7XG5pbXBvcnQgeyBzYWZlU291cmNlcyB9IGZyb20gJy4uL2xpYi9zYWZlU291cmNlcyc7XG5pbXBvcnQgSWNvbiBmcm9tICcuL0ljb24nO1xuXG4vLyBgLmdyb3ZlLWFnZW50YCDigJQgR3JvdmUncyBvd24gZW1iZWRkZWQgYWdlbnQgKEdST1ZFX0FHRU5UX1NQRUMpLlxuLy9cbi8vIFRoZSBzdXJmYWNlIGlzIGEgRlVOQ1RJT04gb2YgdGhlIHNlc3Npb24ncyBlbnZlbG9wZSAoUi1HQS0xKTogdGhlIHJlYWNoIGNhcmQgaW5cbi8vIHRoZSBleHBhbmRlZCBoZWFkZXIgaXMgY29tcHV0ZWQgZnJvbSB0aGUgcHJvdmlkZXIgZm91ci1zdGF0ZSAoUjMtNjg4IGFkZGVkIHRoZVxuLy8gaG9zdC1tYXJrZWQgYHVuZ3JhbnRlZGAg4oCUIHRoZSBkaXN0aW5jdCBub3QtZ3JhbnRlZCBjYXVzZSksIHRoZSBgbGxtOmNoYXRgXG4vLyBncmFudCAodGhlIGdyYW50LWZpbHRlcmVkIGNhdGFsb2cpLCBtb3VudCB3cml0YWJpbGl0eSwgdGhlIGNvcnB1cyBwYWNrYWdpbmcsXG4vLyB0b29scyBzdXBwb3J0LCBhbmQgc291cmNlIHRydXN0IOKAlCBuZXZlciBoYW5kLXdyaXR0ZW4gY29weS4gVGhlIGxvb3AgcmlkZXMgdGhlXG4vLyB3b3JrYmVuY2gncyBzZWFtIOKAlCBTREsgYHJ1bkFnZW50YCBvdmVyIHRoZSBob3N0IGBsbG0uY2hhdGAgc2xvdCDigJQgYW5kIGl0cyB0d29cbi8vIHRvb2xzIGFyZSB0aGUgbW91bnQtY2hyb290ZWQgYHJlYWRfZW50cnlgIGFuZFxuLy8gdGhlIGluZGV4IHF1ZXJ5IChSLUdBLTIpLiBUaGUgd2lkZ2V0IG5ldmVyIHdyaXRlcyAoUi1HQS0zKTogZXZlcnkgY2hhbmdlIGlzIGFcbi8vIGhhbmQtb2ZmIHRvIHRoZSBlZGl0b3IgLyB3b3JrYmVuY2guIFJlYWQtb25seSBuZXZlciBibG9ja3MgUSZBIChSLUdBLTUpLiBXaGVuIGFcbi8vIHByb3ZpZGVyIGlzIGJvdW5kIHRoZSBlZ3Jlc3MgbGluZSBpcyBzaG93biB1bmNvbmRpdGlvbmFsbHkgKFItR0EtNikuIEV2ZXJ5XG4vLyBjb3JwdXMtZGVyaXZlZCBieXRlIGVudGVyaW5nIHRoZSBsb29wIGlzIGZlbmNlZCAoUi1HQS03KS5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEdyb3ZlQWdlbnQoe1xuICB3cml0YWJsZSxcbiAgZW50cnlLZXksXG4gIGVudHJ5VGl0bGUsXG59OiB7XG4gIHdyaXRhYmxlOiBib29sZWFuO1xuICBlbnRyeUtleTogc3RyaW5nO1xuICBlbnRyeVRpdGxlOiBzdHJpbmc7XG59KSB7XG4gIGNvbnN0IHByb3ZpZGVyU3RhdGUgPSB1c2VDaGF0UHJvdmlkZXJTdGF0ZSgpO1xuICBjb25zdCBjYXRhbG9nID0gdXNlQ2F0YWxvZygpO1xuICBjb25zdCBpbmRleCA9IHVzZUFsbE1ldGFkYXRhKCk7XG4gIGNvbnN0IGhlYWRpbmdzID0gdXNlSGVhZGluZ3MoZW50cnlLZXkpO1xuICBjb25zdCBhY3RpdmVIZWFkaW5nID0gdXNlQWN0aXZlSGVhZGluZyhoZWFkaW5ncyk7XG4gIGNvbnN0IHsgb3BlbkVkaXRvciwgZWRpdFJlZnVzZWQgfSA9IHVzZVNoZWxsKCk7XG4gIGNvbnN0IFtvcGVuLCBzZXRPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2RldGVudCwgc2V0RGV0ZW50XSA9IHVzZVN0YXRlPCdoYWxmJyB8ICdmdWxsJz4oJ2hhbGYnKTtcbiAgY29uc3QgW3Jlc3RpbmcsIHNldFJlc3RpbmddID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbZHJhZnQsIHNldERyYWZ0XSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW3Jvd3MsIHNldFJvd3NdID0gdXNlU3RhdGU8QWdlbnRSb3dbXT4oW10pO1xuICBjb25zdCBbc3RyZWFtaW5nLCBzZXRTdHJlYW1pbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbZXJyb3JUb2FzdCwgc2V0RXJyb3JUb2FzdF0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgY29uc3QgYm9keVJlZiA9IHVzZVJlZjxIVE1MRGl2RWxlbWVudD4obnVsbCk7XG4gIGNvbnN0IGZvb3RSZWYgPSB1c2VSZWY8SFRNTElucHV0RWxlbWVudD4obnVsbCk7XG4gIC8vIE9uZSBBYm9ydENvbnRyb2xsZXIgcGVyIHJ1biAoUjMtNjA4KTogdGhlIGNvbXBvc2VyJ3Mgc3RvcCBjb250cm9sIGFib3J0cyB0aGVcbiAgLy8gaW4tZmxpZ2h0IHJ1biB0aHJvdWdoIHRoZSBTREsgc2lnbmFsIHRoZSBsb29wIGFscmVhZHkgaG9ub3Vycy5cbiAgY29uc3QgYWJvcnRSZWYgPSB1c2VSZWY8QWJvcnRDb250cm9sbGVyIHwgbnVsbD4obnVsbCk7XG4gIC8vIFRoZSBwYW5lbCBjYXJyaWVzIHRoZSBkaWFsb2cgY29udHJhY3QgKFIzLTYwOCk6IGZvY3VzIGluLCBUYWIgdHJhcHBlZCxcbiAgLy8gRXNjYXBlLCBmb2N1cyByZXR1cm4g4oCUIHRoZSBzaGFyZWQgaG9vaywgc3RhY2stYXdhcmUuXG4gIGNvbnN0IGRpYWxvZ1JlZiA9IHVzZU92ZXJsYXlGb2N1c0Rpc21pc3Mob3BlbiwgKCkgPT4gc2V0T3BlbihmYWxzZSkpO1xuXG4gIC8vIFRoZSBlbnZlbG9wZSwgY29tcHV0ZWQgKFItR0EtMSkuIGBsbG06Y2hhdGAgYXBwZWFycyBpbiB0aGUgZ3JhbnQtZmlsdGVyZWRcbiAgLy8gY2F0YWxvZyBpZmYgdGhpcyBhcHAgaG9sZHMgdGhlIGNvbnNlbnQg4oCUIGFuIHVuZ3JhbnRlZCBmb3JrIHJlYWRzIGEgRElTVElOQ1RcbiAgLy8gY2F1c2UgZnJvbSBhIHVzZXIgd2l0aG91dCBhIGtleSAoRy1HQS0xMCkuXG4gIGNvbnN0IGNoYXRHcmFudGVkID0gY2F0YWxvZy5zb21lKChtKSA9PiBtLm5hbWUgPT09ICdsbG06Y2hhdCcpO1xuICAvLyBEaXN0aW5ndWlzaGVzIFwiZ3JhbnRlZCBub3RoaW5nXCIgZnJvbSBcImhhcyBub3QgcmVwbGllZCB5ZXRcIiDigJQgYGNhdGFsb2dgIGFsb25lIGNhbm5vdCxcbiAgLy8gYmVjYXVzZSBhbiBlbXB0eSBjYXRhbG9nIGlzIGEgbGVnaXRpbWF0ZSBhbnN3ZXIuIFNlZSB0aGUgaG9vayBmb3IgaG93IGl0IGlzIGRlcml2ZWQuXG4gIGNvbnN0IGNhdGFsb2dBbnN3ZXJlZCA9IHVzZUNhdGFsb2dBbnN3ZXJlZCgpO1xuICBjb25zdCBjb250ZXh0ID0gdXNlQWdlbnRDb250ZXh0KHsgZW50cnlQYXRoOiBlbnRyeUtleSwgZW50cnlUaXRsZSwgaGVhZGluZzogYWN0aXZlSGVhZGluZyB8fCB1bmRlZmluZWQgfSk7XG4gIC8vIEctR0EtODogYSBwcm92aWRlciB3aXRob3V0IGBmZWF0dXJlcy50b29sc2AgZGVncmFkZXMgdG8gY29udGV4dC1zdHVmZmluZy5cbiAgLy8gQ29tcHV0ZWQgT05DRSBhdCByZW5kZXIgc2NvcGUg4oCUIHRoZSByZWFjaCBjYXJkJ3MgUSZBIHF1YWxpZmllciAoUjMtNzUyKSBhbmQgdGhlXG4gIC8vIGFzaygpIHBhdGggYmVsb3cgcmVhZCB0aGUgc2FtZSBmYWN0LCBuZXZlciB0d28gY29tcHV0YXRpb25zIG9mIGl0LlxuICBjb25zdCB0b29sc1N1cHBvcnRlZCA9IHByb3ZpZGVyU3RhdGUuc3RhdHVzID09PSAnY29uZmlndXJlZCcgJiYgcHJvdmlkZXJTdGF0ZS5wcm92aWRlci5mZWF0dXJlcy50b29scyA9PT0gdHJ1ZTtcbiAgY29uc3QgcmVhY2hSb3dzID0gdXNlTWVtbyhcbiAgICAoKSA9PlxuICAgICAgY29tcHV0ZVJlYWNoUm93cyh7XG4gICAgICAgIHByb3ZpZGVyU3RhdGUsXG4gICAgICAgIGNoYXRHcmFudGVkLFxuICAgICAgICBjYXRhbG9nQW5zd2VyZWQsXG4gICAgICAgIHdyaXRhYmxlLFxuICAgICAgICBzb3VyY2VTaGFyZWQ6IGNvbnRleHQuc291cmNlU2hhcmVkLFxuICAgICAgICBtb3VudElkOiBnZXRDb3JwdXNNb3VudElkKCksXG4gICAgICAgIHRvb2xzU3VwcG9ydGVkLFxuICAgICAgfSksXG4gICAgW3Byb3ZpZGVyU3RhdGUsIGNoYXRHcmFudGVkLCBjYXRhbG9nQW5zd2VyZWQsIHdyaXRhYmxlLCBjb250ZXh0LnNvdXJjZVNoYXJlZCwgdG9vbHNTdXBwb3J0ZWRdLFxuICApO1xuICBjb25zdCBjaGlwcyA9IHVzZU1lbW8oKCkgPT4gcmVhY2hDaGlwcyhyZWFjaFJvd3MpLCBbcmVhY2hSb3dzXSk7XG4gIGNvbnN0IHRydXN0TGluZSA9IHVzZU1lbW8oXG4gICAgKCkgPT4gc291cmNlVHJ1c3RMaW5lKGNvbnRleHQuc291cmNlU2hhcmVkLCBjb250ZXh0LnNvdXJjZVNoYXJlZEJhc2lzKSxcbiAgICBbY29udGV4dC5zb3VyY2VTaGFyZWQsIGNvbnRleHQuc291cmNlU2hhcmVkQmFzaXNdLFxuICApO1xuICAvLyBSLUlYLTcgKFIzLTc1Mik6IGEgc3RhdGUgZmxpcCBpcyBBTk5PVU5DRUQsIG5vdCBvbmx5IHJlLXJlbmRlcmVkIOKAlCBvbmUgc3RhbmRpbmdcbiAgLy8gcG9saXRlIGxpdmUgcmVnaW9uIHdob3NlIHRleHQgaXMgdGhlIGNhcmQncyBjb21wdXRlZCBzdW1tYXJ5LiBBIGdyYW50IGZsaXBcbiAgLy8gY2hhbmdlcyB0aGUgdGV4dCwgd2hpY2ggaXMgd2hhdCBhIHN0YXR1cyByZWdpb24gYW5ub3VuY2VzOyB0aGUgdmlzdWFsbHkgaGlkZGVuXG4gIC8vIHBlci1yb3cgd29yZHMgYXJlIHN0YXRpYyB0ZXh0IGFuZCBhbm5vdW5jZSBub3RoaW5nLlxuICBjb25zdCByZWFjaEFubm91bmNlbWVudCA9IHVzZU1lbW8oXG4gICAgKCkgPT4gYFdoYXQgdGhlIGFnZW50IGNhbiBkbyBoZXJlOiAke3JlYWNoUm93cy5tYXAoKHIpID0+IGAke3IubGFiZWx9IOKAlCAke3N0YXRlV29yZChyLnN0YXRlKX1gKS5qb2luKCc7ICcpfWAsXG4gICAgW3JlYWNoUm93c10sXG4gICk7XG4gIGNvbnN0IGNhbkFzayA9IHByb3ZpZGVyU3RhdGUuc3RhdHVzID09PSAnY29uZmlndXJlZCcgJiYgY2hhdEdyYW50ZWQ7XG5cbiAgLy8gUmVhZCBhdCBDQUxMIHRpbWUgKGEgc2NhbiBtYXkgbGFuZCwgdGhlIHJlYWRlciBtYXkgbmF2aWdhdGUpIOKAlCByZWZzIGtlcHQgZnJlc2hcbiAgLy8gaW4gYW4gZWZmZWN0LCBuZXZlciB3cml0dGVuIGR1cmluZyByZW5kZXIgKHRoZSByZWFjdC1ob29rcyBjb21waWxlciByZWplY3RzIHRoYXQpLlxuICBjb25zdCBpbmRleFJlZiA9IHVzZVJlZihpbmRleCk7XG4gIGNvbnN0IGNvbnRleHRSZWYgPSB1c2VSZWYoY29udGV4dCk7XG4gIGNvbnN0IGVudHJ5UmVmID0gdXNlUmVmKGVudHJ5S2V5KTtcbiAgY29uc3QgaGVhZGluZ1JlZiA9IHVzZVJlZihhY3RpdmVIZWFkaW5nKTtcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpbmRleFJlZi5jdXJyZW50ID0gaW5kZXg7XG4gICAgY29udGV4dFJlZi5jdXJyZW50ID0gY29udGV4dDtcbiAgICBlbnRyeVJlZi5jdXJyZW50ID0gZW50cnlLZXk7XG4gICAgaGVhZGluZ1JlZi5jdXJyZW50ID0gYWN0aXZlSGVhZGluZztcbiAgfSwgW2luZGV4LCBjb250ZXh0LCBlbnRyeUtleSwgYWN0aXZlSGVhZGluZ10pO1xuXG4gIC8vIFRoZSBsb29wJ3MgdHJhbnNjcmlwdCwga2VwdCBzbyBmb2xsb3ctdXAgcXVlc3Rpb25zIHJlcGxheSB0aGUgdG9vbC11c2UgY2hhaW4uXG4gIGNvbnN0IHRyYW5zY3JpcHRSZWYgPSB1c2VSZWY8QWdlbnRNZXNzYWdlW10+KFtdKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChvcGVuKSByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoKCkgPT4gZm9vdFJlZi5jdXJyZW50Py5mb2N1cygpKTtcbiAgfSwgW29wZW5dKTtcbiAgLy8gVGhlIHBhbmVsJ3Mgb25seSB0cmlnZ2VyICh0aGUgcmVzdGluZyBpbnB1dCkgVU5NT1VOVFMgd2hlbiBpdCBvcGVucywgYW5kXG4gIC8vIGl0cyBvbkZvY3VzIElTIHRoZSBvcGVuIGFjdGlvbiDigJQgcmV0dXJuaW5nIGZvY3VzIHRvIGl0IHdvdWxkIHJlb3BlbiB0aGVcbiAgLy8gcGFuZWwuIFNvIHRoZSBjbG9zZSBwYXRoIHJldHVybnMgZm9jdXMgdG8gdGhlIHJlc3RpbmcgbGluZSdzIFNVQk1JVFxuICAvLyBjb250cm9sIChSLUlYLTEpOiBhIHJlYWwgc3RvcCBpbiB0aGUgc2FtZSBzdXJmYWNlIHRoYXQgbmV2ZXIgcmVvcGVuc1xuICAvLyBhbnl0aGluZywgc28gRXNjYXBlIG5ldmVyIHN0cmFuZHMgdGhlIGtleWJvYXJkIG9uIDxib2R5Pi4gT24gbW91bnQgdGhlXG4gIC8vIGVmZmVjdCBzdGF5cyBxdWlldCAod2FzLW9wZW4gZ2F0ZSkgb3IgdGhlIHBhbmVsIHdvdWxkIG9wZW4gaXRzZWxmLlxuICBjb25zdCByZXN0aW5nR29SZWYgPSB1c2VSZWY8SFRNTEJ1dHRvbkVsZW1lbnQ+KG51bGwpO1xuICBjb25zdCB3YXNPcGVuUmVmID0gdXNlUmVmKGZhbHNlKTtcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAod2FzT3BlblJlZi5jdXJyZW50ICYmICFvcGVuKSByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoKCkgPT4gcmVzdGluZ0dvUmVmLmN1cnJlbnQ/LmZvY3VzKCkpO1xuICAgIHdhc09wZW5SZWYuY3VycmVudCA9IG9wZW47XG4gIH0sIFtvcGVuXSk7XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgYm9keVJlZi5jdXJyZW50Py5zY3JvbGxUbyh7IHRvcDogYm9keVJlZi5jdXJyZW50LnNjcm9sbEhlaWdodCB9KTtcbiAgfSwgW3Jvd3MsIHN0cmVhbWluZ10pO1xuXG4gIGFzeW5jIGZ1bmN0aW9uIGFzayhxdWVzdGlvbjogc3RyaW5nKSB7XG4gICAgY29uc3QgcSA9IHF1ZXN0aW9uLnRyaW0oKTtcbiAgICBpZiAoIXEgfHwgc3RyZWFtaW5nKSByZXR1cm47XG4gICAgc2V0T3Blbih0cnVlKTtcbiAgICBzZXREcmFmdCgnJyk7XG4gICAgc2V0UmVzdGluZygnJyk7XG4gICAgc2V0RXJyb3JUb2FzdChudWxsKTtcbiAgICBzZXRSb3dzKChwcmV2KSA9PiBbLi4ucHJldiwgeyBraW5kOiAndXNlcicsIHRleHQ6IHEgfV0pO1xuICAgIHNldFN0cmVhbWluZyh0cnVlKTtcblxuICAgIC8vIEctR0EtODogYSBwcm92aWRlciB3aXRob3V0IGBmZWF0dXJlcy50b29sc2AgZGVncmFkZXMgdG8gY29udGV4dC1zdHVmZmluZyDigJRcbiAgICAvLyB0aGUgZGVpeGlzIGJsb2NrLCBhbiBpbmRleCBzdW1tYXJ5LCBhbmQgdGhlIGN1cnJlbnQgZW50cnkgYm9keSByaWRlIHRoZVxuICAgIC8vIHByb21wdDsgdGhlIHJlcXVlc3QgY2FycmllcyBaRVJPIHRvb2xzLiBUaGUgc2FtZSBob2lzdGVkIGZhY3QgdGhlIHJlYWNoXG4gICAgLy8gY2FyZCdzIFEmQSBxdWFsaWZpZXIgcmVhZHMgKFIzLTc1Mikg4oCUIGNvbXB1dGVkIG9uY2UgYXQgcmVuZGVyIHNjb3BlLlxuICAgIGNvbnN0IGNocm9vdCA9IGdldENvbnRlbnRSb290KCk7XG4gICAgY29uc3QgY3VycmVudEtleSA9IGVudHJ5UmVmLmN1cnJlbnQ7XG4gICAgY29uc3QgY29udGV4dEJsb2NrID0gcmVuZGVyQWdlbnRDb250ZXh0KHtcbiAgICAgIC4uLmNvbnRleHRSZWYuY3VycmVudCxcbiAgICAgIGVudHJ5UGF0aDogY3VycmVudEtleSxcbiAgICAgIGhlYWRpbmc6IGhlYWRpbmdSZWYuY3VycmVudCB8fCB1bmRlZmluZWQsXG4gICAgfSk7XG4gICAgbGV0IHN0dWZmZWRCb2R5OiBzdHJpbmcgfCB1bmRlZmluZWQ7XG4gICAgaWYgKCF0b29sc1N1cHBvcnRlZCkge1xuICAgICAgc3R1ZmZlZEJvZHkgPSBhd2FpdCBzYWZlU291cmNlcy5yZWFkKGN1cnJlbnRLZXkpLmNhdGNoKCgpID0+IHVuZGVmaW5lZCk7XG4gICAgfVxuICAgIGNvbnN0IHN5c3RlbSA9IGJ1aWxkU3lzdGVtUHJvbXB0KHtcbiAgICAgIGNvbnRleHRCbG9jayxcbiAgICAgIHRvb2xzU3VwcG9ydGVkLFxuICAgICAgLi4uKHRvb2xzU3VwcG9ydGVkID8ge30gOiB7IGVudHJ5Qm9keTogc3R1ZmZlZEJvZHksIGVudHJ5UGF0aDogY3VycmVudEtleSwgaW5kZXg6IGluZGV4UmVmLmN1cnJlbnQsIGNocm9vdCB9KSxcbiAgICB9KTtcbiAgICBjb25zdCBlbnRyeVRvb2wgPSBjcmVhdGVSZWFkRW50cnlUb29sKGNocm9vdCk7XG4gICAgY29uc3QgbWV0YVRvb2wgPSBjcmVhdGVHcm92ZU1ldGFkYXRhVG9vbChjaHJvb3QsICgpID0+IGluZGV4UmVmLmN1cnJlbnQpO1xuICAgIGNvbnN0IGV4ZWN1dGUgPSB0b29sRXhlY3V0b3IoW2VudHJ5VG9vbCwgbWV0YVRvb2xdKTtcbiAgICBjb25zdCB0b29scyA9IHRvb2xzU3VwcG9ydGVkID8gZ3JvdmVBZ2VudFRvb2xzKGNocm9vdCwgKCkgPT4gaW5kZXhSZWYuY3VycmVudCkgOiBbXTtcblxuICAgIGxldCBhY2MgPSAnJztcbiAgICBjb25zdCBwdXNoQXNzaXN0YW50ID0gKHRleHQ6IHN0cmluZykgPT5cbiAgICAgIHNldFJvd3MoKHByZXYpID0+IHtcbiAgICAgICAgY29uc3QgbmV4dCA9IHByZXYuc2xpY2UoKTtcbiAgICAgICAgaWYgKG5leHQubGVuZ3RoICYmIG5leHRbbmV4dC5sZW5ndGggLSAxXS5raW5kID09PSAnYXNzaXN0YW50JykgbmV4dFtuZXh0Lmxlbmd0aCAtIDFdID0geyBraW5kOiAnYXNzaXN0YW50JywgdGV4dCB9O1xuICAgICAgICBlbHNlIG5leHQucHVzaCh7IGtpbmQ6ICdhc3Npc3RhbnQnLCB0ZXh0IH0pO1xuICAgICAgICByZXR1cm4gbmV4dDtcbiAgICAgIH0pO1xuICAgIGNvbnN0IGNvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG4gICAgYWJvcnRSZWYuY3VycmVudCA9IGNvbnRyb2xsZXI7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGZpbmFsID0gYXdhaXQgcnVuQWdlbnQoe1xuICAgICAgICBjbGllbnQ6IGNyZWF0ZUNoYXRNb2RlbENsaWVudCgpLFxuICAgICAgICB0b29scyxcbiAgICAgICAgZXhlY3V0ZSxcbiAgICAgICAgc3lzdGVtLFxuICAgICAgICBwcm9tcHQ6IHEsXG4gICAgICAgIGhpc3Rvcnk6IHRyYW5zY3JpcHRSZWYuY3VycmVudCxcbiAgICAgICAgbWF4VHVybnM6IDgsXG4gICAgICAgIHNpZ25hbDogY29udHJvbGxlci5zaWduYWwsXG4gICAgICAgIGV2ZW50czoge1xuICAgICAgICAgIG9uQXNzaXN0YW50RGVsdGE6ICh0KSA9PiB7XG4gICAgICAgICAgICBhY2MgKz0gdDtcbiAgICAgICAgICAgIHB1c2hBc3Npc3RhbnQoYWNjKTtcbiAgICAgICAgICB9LFxuICAgICAgICAgIG9uVG9vbFVzZTogKG5hbWUsIGlucHV0KSA9PiB7XG4gICAgICAgICAgICBhY2MgPSAnJztcbiAgICAgICAgICAgIHNldFJvd3MoKHByZXYpID0+IHtcbiAgICAgICAgICAgICAgY29uc3QgbmV4dCA9IHByZXYuc2xpY2UoKTtcbiAgICAgICAgICAgICAgaWYgKG5leHQubGVuZ3RoICYmIG5leHRbbmV4dC5sZW5ndGggLSAxXS5raW5kID09PSAnYXNzaXN0YW50JyAmJiAhbmV4dFtuZXh0Lmxlbmd0aCAtIDFdLnRleHQpIG5leHQucG9wKCk7XG4gICAgICAgICAgICAgIG5leHQucHVzaCh7IGtpbmQ6ICdhY3Rpdml0eScsIHRleHQ6IHRvb2xBY3Rpdml0eUxpbmUobmFtZSwgaW5wdXQpIH0pO1xuICAgICAgICAgICAgICByZXR1cm4gbmV4dDtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICAgIGNvbnN0IHJlbmRlcmVkID0gdHJhbnNjcmlwdFRvUm93cyhmaW5hbCk7XG4gICAgICAvLyBUaGUgcmVhbCBsb29wIFJFU09MVkVTIGFuIGFib3J0ZWQgcnVuIHdpdGggdGhlIHBhcnRpYWwgdHJhbnNjcmlwdCAoYVxuICAgICAgLy8gY2xlYW4gc3RvcCwgbmV2ZXIgYSB0aHJvd24gZXJyb3IpIOKAlCBzbyB0aGUgYWJvcnQgY2hlY2sgbGl2ZXMgaGVyZSB0b28sXG4gICAgICAvLyBub3Qgb25seSBpbiB0aGUgY2F0Y2g6IGEgc3RvcHBlZCBydW4ga2VlcHMgd2hhdCBzdHJlYW1lZCBhbmQgYXBwZW5kcyBhXG4gICAgICAvLyBuYW1lZCBTdG9wcGVkIHJvdyAoUjMtNjA4KS5cbiAgICAgIGlmIChjb250cm9sbGVyLnNpZ25hbC5hYm9ydGVkKSB7XG4gICAgICAgIHNldFJvd3MoKHByZXYpID0+IFsuLi5wcmV2LCB7IGtpbmQ6ICdhY3Rpdml0eScsIHRleHQ6ICdTdG9wcGVkJyB9XSk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGlmICghcmVuZGVyZWQuc29tZSgocikgPT4gci5raW5kID09PSAnYXNzaXN0YW50JykpIHRocm93IG5ldyBFcnJvcignZW1wdHknKTtcbiAgICAgIHRyYW5zY3JpcHRSZWYuY3VycmVudCA9IGZpbmFsLnNsaWNlKCk7XG4gICAgICBzZXRSb3dzKHJlbmRlcmVkKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICAvLyBBIHN0b3AgaXMgbm90IGFuIGVycm9yIChSMy02MDgpOiB0aGUgYWJvcnRlZCBydW4gc2V0dGxlcyB3aXRoIGEgbmFtZWRcbiAgICAgIC8vIFwiU3RvcHBlZFwiIHJvdywgYW5kIHRoZSB0cmFuc2NyaXB0IGtlZXBzIHdoYXQgc3RyZWFtZWQgc28gZmFyLlxuICAgICAgaWYgKGNvbnRyb2xsZXIuc2lnbmFsLmFib3J0ZWQpIHtcbiAgICAgICAgc2V0Um93cygocHJldikgPT4gWy4uLnByZXYsIHsga2luZDogJ2FjdGl2aXR5JywgdGV4dDogJ1N0b3BwZWQnIH1dKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgY29uc3QgY29kZSA9IChlIGFzIHsgY29kZT86IHN0cmluZyB9KT8uY29kZSB8fCAoZSBhcyBFcnJvcikubWVzc2FnZTtcbiAgICAgIHNldEVycm9yVG9hc3QoXG4gICAgICAgIGNvZGUgPT09ICdhdXRoLXJlcXVpcmVkJ1xuICAgICAgICAgID8gJ25vIG1vZGVsIGtleSBjb25uZWN0ZWQg4oCUIGFkZCBvbmUgaW4gU2V0dGluZ3MnXG4gICAgICAgICAgOiBjb2RlID09PSAnZm9yYmlkZGVuJ1xuICAgICAgICAgICAgPyBVTkdSQU5URURfQ0hBVF9DQVVTRVxuICAgICAgICAgICAgOiBjb2RlID09PSAnY2FuY2VsbGVkJ1xuICAgICAgICAgICAgICA/IGBjaGF0IGRpZG4ndCBzdGFydCDigJQgJHtSRUFESU5HX1dPUktTX05PUk1BTH07IHlvdSBjYW4gdHJ5IGFnYWluIGFueXRpbWVgXG4gICAgICAgICAgICAgIDogJ3RoZSBtb2RlbCBvciBiYWNrZW5kIGVycm9yZWQg4oCUIHRyeSBhZ2FpbiBpbiBhIG1vbWVudCcsXG4gICAgICApO1xuICAgICAgc2V0Um93cygocHJldikgPT5cbiAgICAgICAgcHJldi5sZW5ndGggJiYgcHJldltwcmV2Lmxlbmd0aCAtIDFdLmtpbmQgPT09ICdhc3Npc3RhbnQnICYmICFwcmV2W3ByZXYubGVuZ3RoIC0gMV0udGV4dCA/IHByZXYuc2xpY2UoMCwgLTEpIDogcHJldixcbiAgICAgICk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldFN0cmVhbWluZyhmYWxzZSk7XG4gICAgICBpZiAoYWJvcnRSZWYuY3VycmVudCA9PT0gY29udHJvbGxlcikgYWJvcnRSZWYuY3VycmVudCA9IG51bGw7XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImdyb3ZlLWFnZW50XCI+XG4gICAgICB7LyogUmVzdGluZzogdGhlIGFsd2F5cy1wcmVzZW50IHRoaW4gaW5wdXQgbGluZS4gUSZBIGlzIG5ldmVyIGRpc2FibGVkIGJ5XG4gICAgICAgICAgcmVhZC1vbmx5IChSLUdBLTUpIOKAlCBvbmx5IGJ5IHRoZSBlbnZlbG9wZSBnZW51aW5lbHkgbGFja2luZyBhIHByb3ZpZGVyLiAqL31cbiAgICAgIHshb3BlbiAmJiAoXG4gICAgICAgIDxmb3JtXG4gICAgICAgICAgY2xhc3NOYW1lPVwiZ2EtbGluZVwiXG4gICAgICAgICAgb25TdWJtaXQ9eyhlKSA9PiB7XG4gICAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICAgICBpZiAoY2FuQXNrKSB2b2lkIGFzayhyZXN0aW5nKTtcbiAgICAgICAgICAgIGVsc2Ugc2V0T3Blbih0cnVlKTtcbiAgICAgICAgICB9fVxuICAgICAgICA+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWtcIiAvPlxuICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgdmFsdWU9e3Jlc3Rpbmd9XG4gICAgICAgICAgICBwbGFjZWhvbGRlcj17YEFzayBHcm92ZSBhYm91dCDigJwke2VudHJ5VGl0bGV94oCd4oCmYH1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UmVzdGluZyhlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICBvbkZvY3VzPXsoKSA9PiBzZXRPcGVuKHRydWUpfVxuICAgICAgICAgICAgYXJpYS1sYWJlbD1cIkFzayBHcm92ZVwiXG4gICAgICAgICAgLz5cbiAgICAgICAgICA8YnV0dG9uIHJlZj17cmVzdGluZ0dvUmVmfSBjbGFzc05hbWU9XCJnb1wiIHR5cGU9XCJzdWJtaXRcIiBhcmlhLWxhYmVsPVwiQXNrIEdyb3ZlXCI+XG4gICAgICAgICAgICA8SWNvbiBuYW1lPVwic2VuZFwiIC8+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZm9ybT5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBFeHBhbmRlZDogZG9jayAoZGVza3RvcCkgLyBzaGVldCAobW9iaWxlKS4gKi99XG4gICAgICB7b3BlbiAmJiAoXG4gICAgICAgIDw+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJnYS1zY3JpbVwiIG9uQ2xpY2s9eygpID0+IHNldE9wZW4oZmFsc2UpfSAvPlxuICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImdhLXBhbmVsXCJcbiAgICAgICAgICAgIGRhdGEtZGV0ZW50PXtkZXRlbnR9XG4gICAgICAgICAgICByZWY9e2RpYWxvZ1JlZn1cbiAgICAgICAgICAgIHRhYkluZGV4PXstMX1cbiAgICAgICAgICAgIHJvbGU9XCJkaWFsb2dcIlxuICAgICAgICAgICAgYXJpYS1tb2RhbD1cInRydWVcIlxuICAgICAgICAgICAgYXJpYS1sYWJlbD1cIkFzayBHcm92ZVwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJnYS1wYW5lbC1pbm5lclwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdhLWhlYWRcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJncmlwXCIgb25DbGljaz17KCkgPT4gc2V0RGV0ZW50KChkKSA9PiAoZCA9PT0gJ2hhbGYnID8gJ2Z1bGwnIDogJ2hhbGYnKSl9IC8+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWtcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlkXCI+R3JvdmU8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZ3Jvd1wiPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJpY1wiIGFyaWEtbGFiZWw9e2RldGVudCA9PT0gJ2hhbGYnID8gJ0V4cGFuZCcgOiAnQ29sbGFwc2UnfSBvbkNsaWNrPXsoKSA9PiBzZXREZXRlbnQoKGQpID0+IChkID09PSAnaGFsZicgPyAnZnVsbCcgOiAnaGFsZicpKX0+XG4gICAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9e2RldGVudCA9PT0gJ2hhbGYnID8gJ2NoZXZyb24tZG93bicgOiAnY2hldnJvbi1yaWdodCd9IC8+XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiaWNcIiBhcmlhLWxhYmVsPVwiQ2xvc2VcIiBvbkNsaWNrPXsoKSA9PiBzZXRPcGVuKGZhbHNlKX0+XG4gICAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJ4XCIgLz5cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIFRoZSByZWFjaCBjYXJkIOKAlCB0aGUgZW52ZWxvcGUsIGNvbXB1dGVkIChSLUdBLTEpLiBTdGF0ZSBpcyB0ZXh0IGFzXG4gICAgICAgICAgICAgICAgICB3ZWxsIGFzIGdseXBoIChSMy03NTIpOiB0aGUgaGlkZGVuIHdvcmQgYmVzaWRlIHRoZSBtYXJrIGtlZXBzIHRoZVxuICAgICAgICAgICAgICAgICAgY2FyZCBmcm9tIHJlYWRpbmcgYXMgZm91ciBpZGVudGljYWwgbGluZXMgdG8gYSBzY3JlZW4gcmVhZGVyLiAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJnYS1yZWFjaFwiIHJvbGU9XCJsaXN0XCIgYXJpYS1sYWJlbD1cIldoYXQgdGhlIGFnZW50IGNhbiBkbyBoZXJlXCI+XG4gICAgICAgICAgICAgICAge3JlYWNoUm93cy5tYXAoKHIpID0+IChcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgZ2EtcmVhY2hfX3JvdyBnYS1yZWFjaF9fcm93LS0ke3Iuc3RhdGV9YH0gcm9sZT1cImxpc3RpdGVtXCIga2V5PXtyLmtleX0+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImdhLXJlYWNoX19tYXJrXCIgYXJpYS1oaWRkZW4+XG4gICAgICAgICAgICAgICAgICAgICAge3Iuc3RhdGUgPT09ICdvaycgPyAn4pyTJyA6IHIuc3RhdGUgPT09ICdibG9ja2VkJyA/ICfinJcnIDogci5zdGF0ZSA9PT0gJ2Vsc2V3aGVyZScgPyAn4oaSJyA6ICfCtyd9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZ2EtcmVhY2hfX3N0YXRld29yZFwiPntzdGF0ZVdvcmQoci5zdGF0ZSl9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJnYS1yZWFjaF9fbGFiZWxcIj57ci5sYWJlbH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIHtyLmNhdXNlICYmIDxzcGFuIGNsYXNzTmFtZT1cImdhLXJlYWNoX19jYXVzZVwiPntyLmNhdXNlfTwvc3Bhbj59XG4gICAgICAgICAgICAgICAgICAgIHtyLmRlc3RpbmF0aW9uICYmIDxzcGFuIGNsYXNzTmFtZT1cImdhLXJlYWNoX19jYXVzZVwiPntg4oaSICR7ci5kZXN0aW5hdGlvbn1gfTwvc3Bhbj59XG4gICAgICAgICAgICAgICAgICAgIHtyLmFjdGlvbiA9PT0gJ2VuYWJsZS1jaGF0JyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgLy8gUjMtNzkwOiB0aGUgZWFybmluZyBhZmZvcmRhbmNlLiBJdHMgY2xpY2sgaW52b2tlcyBhc2soKSDigJQgdGhlXG4gICAgICAgICAgICAgICAgICAgICAgLy8gdW5ncmFudGVkIGxsbTpjaGF0IGludm9rZSBmaXJlcyB0aGUgSE9TVCdzIGNvbnNlbnQgZGlhbG9nIG9uIHRoaXNcbiAgICAgICAgICAgICAgICAgICAgICAvLyBzYW1lIGFjdGl2YXRpb24gKHNpdGUtbWFpbiM2MTIpLCBBbGxvdyBtaW50cyArIGxpZnRzLCBhbmQgdGhlXG4gICAgICAgICAgICAgICAgICAgICAgLy8gc2FtZSBhc2sgcHJvY2VlZHMgdG8gc3RyZWFtLiBBIGRlY2xpbmUgYW5zd2VycyAnY2FuY2VsbGVkJyAodGhlXG4gICAgICAgICAgICAgICAgICAgICAgLy8gY2F0Y2ggYmVsb3cpIGFuZCB0aGUgcm93IHN0YXlzIGhvbmVzdGx5IOKcly5cbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImdhLXJlYWNoX19lbmFibGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgdm9pZCBhc2soZHJhZnQudHJpbSgpIHx8ICdBbnN3ZXIgaW4gb25lIHNlbnRlbmNlOiB3aGF0IGNhbiB5b3UgdGVsbCBtZSBhYm91dCB0aGlzIHdpa2k/JylcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICBFbmFibGUgY2hhdFxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICB7dHJ1c3RMaW5lICYmIDxwIGNsYXNzTmFtZT1cImdhLWVncmVzc1wiPnt0cnVzdExpbmV9PC9wPn1cbiAgICAgICAgICAgICAgey8qIFRoZSBzdGFuZGluZyBsaXZlIHJlZ2lvbiAoUi1JWC03KTogdGhlIGNvbXB1dGVkIGNhcmQgc3VtbWFyeSwgc28gYVxuICAgICAgICAgICAgICAgICAgc3RhdGUgZmxpcCBpcyBhbm5vdW5jZWQgcG9saXRlbHkgYW5kIG5vdCBvbmx5IHJlLXJlbmRlcmVkLiAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJnYS1yZWFjaF9fc3RhdGV3b3JkXCIgcm9sZT1cInN0YXR1c1wiPlxuICAgICAgICAgICAgICAgIHtyZWFjaEFubm91bmNlbWVudH1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIHtzaG93RWdyZXNzRGlzY2xvc3VyZShwcm92aWRlclN0YXRlKSAmJiA8cCBjbGFzc05hbWU9XCJnYS1lZ3Jlc3NcIj57RUdSRVNTX0RJU0NMT1NVUkV9PC9wPn1cbiAgICAgICAgICAgICAge2Vycm9yVG9hc3QgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ2EtdG9hc3RcIiByb2xlPVwic3RhdHVzXCI+XG4gICAgICAgICAgICAgICAgICB7ZXJyb3JUb2FzdH1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdhLWJvZHlcIiByZWY9e2JvZHlSZWZ9PlxuICAgICAgICAgICAgICAgIHtyb3dzLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ2EtZXhwbGFpblwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxiPkdyb3ZlJ3MgYWdlbnQ8L2I+IGFuc3dlcnMgcXVlc3Rpb25zIGFib3V0IHRoaXMgd2lraSDigJQgaXRzIGVudHJpZXMsIHRhZ3MsIGFuZCBzdHJ1Y3R1cmUg4oCUIGZyb20gdGhlXG4gICAgICAgICAgICAgICAgICAgICAgcGFnZSB5b3UncmUgb24uXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICB7Y2hpcHMubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJnYS1jaGlwc1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAge2NoaXBzLm1hcCgoYykgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGtleT17Y30gY2xhc3NOYW1lPVwiZ2EtY2hpcFwiIG9uQ2xpY2s9eygpID0+IHZvaWQgYXNrKGMpfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICByb3dzLm1hcCgociwgaSkgPT5cbiAgICAgICAgICAgICAgICAgICAgci5raW5kID09PSAnYWN0aXZpdHknID8gKFxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpfSBjbGFzc05hbWU9XCJnYS1hY3Rpdml0eVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cImZpbGVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAge3IudGV4dH1cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17aX0gY2xhc3NOYW1lPXtgZ2EtbXNnICR7ci5raW5kfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgZ2EtbXNnX19hdiAke3Iua2luZCA9PT0gJ2Fzc2lzdGFudCcgPyAnZ3JvdmUnIDogJ3VzZXInfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7ci5raW5kID09PSAnYXNzaXN0YW50JyA/ICcnIDogJ3lvdSd9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdhLW1zZ19fYlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdhLW1zZ19fd2hvXCI+e3Iua2luZCA9PT0gJ2Fzc2lzdGFudCcgPyAnR3JvdmUnIDogJ1lvdSd9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ2EtbXNnX190eHRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ci50ZXh0fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzdHJlYW1pbmcgJiYgaSA9PT0gcm93cy5sZW5ndGggLSAxICYmIHIua2luZCA9PT0gJ2Fzc2lzdGFudCcgPyA8c3BhbiBjbGFzc05hbWU9XCJnYS1jdXJzb3JcIiAvPiA6IG51bGx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICksXG4gICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJnYS1mb290XCI+XG4gICAgICAgICAgICAgICAgPGZvcm1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImdhLWZvb3RfX3Jvd1wiXG4gICAgICAgICAgICAgICAgICBvblN1Ym1pdD17KGUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgICAgICAgICAgICB2b2lkIGFzayhkcmFmdCk7XG4gICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICByZWY9e2Zvb3RSZWZ9XG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkcmFmdH1cbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJBc2sgR3JvdmXigKZcIlxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17c3RyZWFtaW5nIHx8ICFjYW5Bc2t9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RHJhZnQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIHtzdHJlYW1pbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzdG9wXCJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiU3RvcFwiXG4gICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJTdG9wXCJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBhYm9ydFJlZi5jdXJyZW50Py5hYm9ydCgpfVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cInhcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICkgOiBudWxsfVxuICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJnb1wiIHR5cGU9XCJzdWJtaXRcIiBkaXNhYmxlZD17c3RyZWFtaW5nIHx8ICFjYW5Bc2sgfHwgIWRyYWZ0LnRyaW0oKX0gYXJpYS1sYWJlbD17c3RyZWFtaW5nID8gJ0Fuc3dlcmluZ+KApicgOiAnU2VuZCd9IHRpdGxlPXtzdHJlYW1pbmcgPyAnQW5zd2VyaW5n4oCmJyA6ICdTZW5kJ30+XG4gICAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJzZW5kXCIgLz5cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdhLWZvb3RfX2hhbmRcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPntFR1JFU1NfRElTQ0xPU1VSRX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICB7ZWRpdFJlZnVzZWQgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJnYS1lZGl0LXJlZnVzZWRcIiByb2xlPVwic3RhdHVzXCI+XG4gICAgICAgICAgICAgICAgICAgICAge0VESVRfUkVGVVNFRF9OT1RJQ0V9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBvcGVuRWRpdG9yKGVudHJ5S2V5KX0+XG4gICAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJleHRlcm5hbFwiIC8+XG4gICAgICAgICAgICAgICAgICAgIE9wZW4gaW4gdGhlIGVkaXRvclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvPlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQUEsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsSUFBQSxHQUFBRCxPQUFBO0FBVUEsSUFBQUUsTUFBQSxHQUFBRixPQUFBO0FBQ0EsSUFBQUcsWUFBQSxHQUFBSCxPQUFBO0FBQ0EsSUFBQUksdUJBQUEsR0FBQUosT0FBQTtBQUNBLElBQUFLLFlBQUEsR0FBQUwsT0FBQTtBQUNBLElBQUFNLFdBQUEsR0FBQU4sT0FBQTtBQUNBLElBQUFPLFlBQUEsR0FBQVAsT0FBQTtBQUNBLElBQUFRLFVBQUEsR0FBQVIsT0FBQTtBQUVBLElBQUFTLGdCQUFBLEdBQUFULE9BQUE7QUFDQSxJQUFBVSxtQkFBQSxHQUFBVixPQUFBO0FBQ0EsSUFBQVcsWUFBQSxHQUFBWCxPQUFBO0FBQ0EsSUFBQVksS0FBQSxHQUFBQyxzQkFBQSxDQUFBYixPQUFBO0FBQTBCLElBQUFjLFdBQUEsR0FBQWQsT0FBQTtBQUFBLElBQUFlLEVBQUEsR0FBQUMsWUFBQSxJQUUxQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUFBLFNBQUFILHVCQUFBSSxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBQ2UsU0FBU0csVUFBVUEsQ0FBQztFQUNqQ0MsUUFBUTtFQUNSQyxRQUFRO0VBQ1JDO0FBS0YsQ0FBQyxFQUFFO0VBQUFSLEVBQUE7RUFDRCxNQUFNUyxhQUFhLEdBQUcsSUFBQUMseUJBQW9CLEVBQUMsQ0FBQztFQUM1QyxNQUFNQyxPQUFPLEdBQUcsSUFBQUMsZUFBVSxFQUFDLENBQUM7RUFDNUIsTUFBTUMsS0FBSyxHQUFHLElBQUFDLG1CQUFjLEVBQUMsQ0FBQztFQUM5QixNQUFNQyxRQUFRLEdBQUcsSUFBQUMsd0JBQVcsRUFBQ1QsUUFBUSxDQUFDO0VBQ3RDLE1BQU1VLGFBQWEsR0FBRyxJQUFBQyw2QkFBZ0IsRUFBQ0gsUUFBUSxDQUFDO0VBQ2hELE1BQU07SUFBRUksVUFBVTtJQUFFQztFQUFZLENBQUMsR0FBRyxJQUFBQyxlQUFRLEVBQUMsQ0FBQztFQUM5QyxNQUFNLENBQUNDLElBQUksRUFBRUMsT0FBTyxDQUFDLEdBQUcsSUFBQUMsZUFBUSxFQUFDLEtBQUssQ0FBQztFQUN2QyxNQUFNLENBQUNDLE1BQU0sRUFBRUMsU0FBUyxDQUFDLEdBQUcsSUFBQUYsZUFBUSxFQUFrQixNQUFNLENBQUM7RUFDN0QsTUFBTSxDQUFDRyxPQUFPLEVBQUVDLFVBQVUsQ0FBQyxHQUFHLElBQUFKLGVBQVEsRUFBQyxFQUFFLENBQUM7RUFDMUMsTUFBTSxDQUFDSyxLQUFLLEVBQUVDLFFBQVEsQ0FBQyxHQUFHLElBQUFOLGVBQVEsRUFBQyxFQUFFLENBQUM7RUFDdEMsTUFBTSxDQUFDTyxJQUFJLEVBQUVDLE9BQU8sQ0FBQyxHQUFHLElBQUFSLGVBQVEsRUFBYSxFQUFFLENBQUM7RUFDaEQsTUFBTSxDQUFDUyxTQUFTLEVBQUVDLFlBQVksQ0FBQyxHQUFHLElBQUFWLGVBQVEsRUFBQyxLQUFLLENBQUM7RUFDakQsTUFBTSxDQUFDVyxVQUFVLEVBQUVDLGFBQWEsQ0FBQyxHQUFHLElBQUFaLGVBQVEsRUFBZ0IsSUFBSSxDQUFDO0VBQ2pFLE1BQU1hLE9BQU8sR0FBRyxJQUFBQyxhQUFNLEVBQWlCLElBQUksQ0FBQztFQUM1QyxNQUFNQyxPQUFPLEdBQUcsSUFBQUQsYUFBTSxFQUFtQixJQUFJLENBQUM7RUFDOUM7RUFDQTtFQUNBLE1BQU1FLFFBQVEsR0FBRyxJQUFBRixhQUFNLEVBQXlCLElBQUksQ0FBQztFQUNyRDtFQUNBO0VBQ0EsTUFBTUcsU0FBUyxHQUFHLElBQUFDLDhDQUFzQixFQUFDcEIsSUFBSSxFQUFFLE1BQU1DLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQzs7RUFFcEU7RUFDQTtFQUNBO0VBQ0EsTUFBTW9CLFdBQVcsR0FBR2hDLE9BQU8sQ0FBQ2lDLElBQUksQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUNDLElBQUksS0FBSyxVQUFVLENBQUM7RUFDOUQ7RUFDQTtFQUNBLE1BQU1DLGVBQWUsR0FBRyxJQUFBQyxzQ0FBa0IsRUFBQyxDQUFDO0VBQzVDLE1BQU1DLE9BQU8sR0FBRyxJQUFBQyxvQkFBZSxFQUFDO0lBQUVDLFNBQVMsRUFBRTVDLFFBQVE7SUFBRUMsVUFBVTtJQUFFNEMsT0FBTyxFQUFFbkMsYUFBYSxJQUFJb0M7RUFBVSxDQUFDLENBQUM7RUFDekc7RUFDQTtFQUNBO0VBQ0EsTUFBTUMsY0FBYyxHQUFHN0MsYUFBYSxDQUFDOEMsTUFBTSxLQUFLLFlBQVksSUFBSTlDLGFBQWEsQ0FBQytDLFFBQVEsQ0FBQ0MsUUFBUSxDQUFDQyxLQUFLLEtBQUssSUFBSTtFQUM5RyxNQUFNQyxTQUFTLEdBQUcsSUFBQUMsY0FBTyxFQUN2QixNQUNFLElBQUFDLDJCQUFnQixFQUFDO0lBQ2ZwRCxhQUFhO0lBQ2JrQyxXQUFXO0lBQ1hJLGVBQWU7SUFDZnpDLFFBQVE7SUFDUndELFlBQVksRUFBRWIsT0FBTyxDQUFDYSxZQUFZO0lBQ2xDQyxPQUFPLEVBQUUsSUFBQUMsNkJBQWdCLEVBQUMsQ0FBQztJQUMzQlY7RUFDRixDQUFDLENBQUMsRUFDSixDQUFDN0MsYUFBYSxFQUFFa0MsV0FBVyxFQUFFSSxlQUFlLEVBQUV6QyxRQUFRLEVBQUUyQyxPQUFPLENBQUNhLFlBQVksRUFBRVIsY0FBYyxDQUM5RixDQUFDO0VBQ0QsTUFBTVcsS0FBSyxHQUFHLElBQUFMLGNBQU8sRUFBQyxNQUFNLElBQUFNLHFCQUFVLEVBQUNQLFNBQVMsQ0FBQyxFQUFFLENBQUNBLFNBQVMsQ0FBQyxDQUFDO0VBQy9ELE1BQU1RLFNBQVMsR0FBRyxJQUFBUCxjQUFPLEVBQ3ZCLE1BQU0sSUFBQVEsMEJBQWUsRUFBQ25CLE9BQU8sQ0FBQ2EsWUFBWSxFQUFFYixPQUFPLENBQUNvQixpQkFBaUIsQ0FBQyxFQUN0RSxDQUFDcEIsT0FBTyxDQUFDYSxZQUFZLEVBQUViLE9BQU8sQ0FBQ29CLGlCQUFpQixDQUNsRCxDQUFDO0VBQ0Q7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNQyxpQkFBaUIsR0FBRyxJQUFBVixjQUFPLEVBQy9CLE1BQU0sK0JBQStCRCxTQUFTLENBQUNZLEdBQUcsQ0FBRUMsQ0FBQyxJQUFLLEdBQUdBLENBQUMsQ0FBQ0MsS0FBSyxNQUFNLElBQUFDLG9CQUFTLEVBQUNGLENBQUMsQ0FBQ0csS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFDNUcsQ0FBQ2pCLFNBQVMsQ0FDWixDQUFDO0VBQ0QsTUFBTWtCLE1BQU0sR0FBR3BFLGFBQWEsQ0FBQzhDLE1BQU0sS0FBSyxZQUFZLElBQUlaLFdBQVc7O0VBRW5FO0VBQ0E7RUFDQSxNQUFNbUMsUUFBUSxHQUFHLElBQUF4QyxhQUFNLEVBQUN6QixLQUFLLENBQUM7RUFDOUIsTUFBTWtFLFVBQVUsR0FBRyxJQUFBekMsYUFBTSxFQUFDVyxPQUFPLENBQUM7RUFDbEMsTUFBTStCLFFBQVEsR0FBRyxJQUFBMUMsYUFBTSxFQUFDL0IsUUFBUSxDQUFDO0VBQ2pDLE1BQU0wRSxVQUFVLEdBQUcsSUFBQTNDLGFBQU0sRUFBQ3JCLGFBQWEsQ0FBQztFQUN4QyxJQUFBaUUsZ0JBQVMsRUFBQyxNQUFNO0lBQ2RKLFFBQVEsQ0FBQ0ssT0FBTyxHQUFHdEUsS0FBSztJQUN4QmtFLFVBQVUsQ0FBQ0ksT0FBTyxHQUFHbEMsT0FBTztJQUM1QitCLFFBQVEsQ0FBQ0csT0FBTyxHQUFHNUUsUUFBUTtJQUMzQjBFLFVBQVUsQ0FBQ0UsT0FBTyxHQUFHbEUsYUFBYTtFQUNwQyxDQUFDLEVBQUUsQ0FBQ0osS0FBSyxFQUFFb0MsT0FBTyxFQUFFMUMsUUFBUSxFQUFFVSxhQUFhLENBQUMsQ0FBQzs7RUFFN0M7RUFDQSxNQUFNbUUsYUFBYSxHQUFHLElBQUE5QyxhQUFNLEVBQWlCLEVBQUUsQ0FBQztFQUVoRCxJQUFBNEMsZ0JBQVMsRUFBQyxNQUFNO0lBQ2QsSUFBSTVELElBQUksRUFBRStELHFCQUFxQixDQUFDLE1BQU05QyxPQUFPLENBQUM0QyxPQUFPLEVBQUVHLEtBQUssQ0FBQyxDQUFDLENBQUM7RUFDakUsQ0FBQyxFQUFFLENBQUNoRSxJQUFJLENBQUMsQ0FBQztFQUNWO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU1pRSxZQUFZLEdBQUcsSUFBQWpELGFBQU0sRUFBb0IsSUFBSSxDQUFDO0VBQ3BELE1BQU1rRCxVQUFVLEdBQUcsSUFBQWxELGFBQU0sRUFBQyxLQUFLLENBQUM7RUFDaEMsSUFBQTRDLGdCQUFTLEVBQUMsTUFBTTtJQUNkLElBQUlNLFVBQVUsQ0FBQ0wsT0FBTyxJQUFJLENBQUM3RCxJQUFJLEVBQUUrRCxxQkFBcUIsQ0FBQyxNQUFNRSxZQUFZLENBQUNKLE9BQU8sRUFBRUcsS0FBSyxDQUFDLENBQUMsQ0FBQztJQUMzRkUsVUFBVSxDQUFDTCxPQUFPLEdBQUc3RCxJQUFJO0VBQzNCLENBQUMsRUFBRSxDQUFDQSxJQUFJLENBQUMsQ0FBQztFQUNWLElBQUE0RCxnQkFBUyxFQUFDLE1BQU07SUFDZDdDLE9BQU8sQ0FBQzhDLE9BQU8sRUFBRU0sUUFBUSxDQUFDO01BQUVDLEdBQUcsRUFBRXJELE9BQU8sQ0FBQzhDLE9BQU8sQ0FBQ1E7SUFBYSxDQUFDLENBQUM7RUFDbEUsQ0FBQyxFQUFFLENBQUM1RCxJQUFJLEVBQUVFLFNBQVMsQ0FBQyxDQUFDO0VBRXJCLGVBQWUyRCxHQUFHQSxDQUFDQyxRQUFnQixFQUFFO0lBQ25DLE1BQU1DLENBQUMsR0FBR0QsUUFBUSxDQUFDRSxJQUFJLENBQUMsQ0FBQztJQUN6QixJQUFJLENBQUNELENBQUMsSUFBSTdELFNBQVMsRUFBRTtJQUNyQlYsT0FBTyxDQUFDLElBQUksQ0FBQztJQUNiTyxRQUFRLENBQUMsRUFBRSxDQUFDO0lBQ1pGLFVBQVUsQ0FBQyxFQUFFLENBQUM7SUFDZFEsYUFBYSxDQUFDLElBQUksQ0FBQztJQUNuQkosT0FBTyxDQUFFZ0UsSUFBSSxJQUFLLENBQUMsR0FBR0EsSUFBSSxFQUFFO01BQUVDLElBQUksRUFBRSxNQUFNO01BQUVDLElBQUksRUFBRUo7SUFBRSxDQUFDLENBQUMsQ0FBQztJQUN2RDVELFlBQVksQ0FBQyxJQUFJLENBQUM7O0lBRWxCO0lBQ0E7SUFDQTtJQUNBO0lBQ0EsTUFBTWlFLE1BQU0sR0FBRyxJQUFBQywyQkFBYyxFQUFDLENBQUM7SUFDL0IsTUFBTUMsVUFBVSxHQUFHckIsUUFBUSxDQUFDRyxPQUFPO0lBQ25DLE1BQU1tQixZQUFZLEdBQUcsSUFBQUMsdUJBQWtCLEVBQUM7TUFDdEMsR0FBR3hCLFVBQVUsQ0FBQ0ksT0FBTztNQUNyQmhDLFNBQVMsRUFBRWtELFVBQVU7TUFDckJqRCxPQUFPLEVBQUU2QixVQUFVLENBQUNFLE9BQU8sSUFBSTlCO0lBQ2pDLENBQUMsQ0FBQztJQUNGLElBQUltRCxXQUErQjtJQUNuQyxJQUFJLENBQUNsRCxjQUFjLEVBQUU7TUFDbkJrRCxXQUFXLEdBQUcsTUFBTUMsd0JBQVcsQ0FBQ0MsSUFBSSxDQUFDTCxVQUFVLENBQUMsQ0FBQ00sS0FBSyxDQUFDLE1BQU10RCxTQUFTLENBQUM7SUFDekU7SUFDQSxNQUFNdUQsTUFBTSxHQUFHLElBQUFDLDhCQUFpQixFQUFDO01BQy9CUCxZQUFZO01BQ1poRCxjQUFjO01BQ2QsSUFBSUEsY0FBYyxHQUFHLENBQUMsQ0FBQyxHQUFHO1FBQUV3RCxTQUFTLEVBQUVOLFdBQVc7UUFBRXJELFNBQVMsRUFBRWtELFVBQVU7UUFBRXhGLEtBQUssRUFBRWlFLFFBQVEsQ0FBQ0ssT0FBTztRQUFFZ0I7TUFBTyxDQUFDO0lBQzlHLENBQUMsQ0FBQztJQUNGLE1BQU1ZLFNBQVMsR0FBRyxJQUFBQywrQkFBbUIsRUFBQ2IsTUFBTSxDQUFDO0lBQzdDLE1BQU1jLFFBQVEsR0FBRyxJQUFBQyxtQ0FBdUIsRUFBQ2YsTUFBTSxFQUFFLE1BQU1yQixRQUFRLENBQUNLLE9BQU8sQ0FBQztJQUN4RSxNQUFNZ0MsT0FBTyxHQUFHLElBQUFDLHdCQUFZLEVBQUMsQ0FBQ0wsU0FBUyxFQUFFRSxRQUFRLENBQUMsQ0FBQztJQUNuRCxNQUFNdkQsS0FBSyxHQUFHSixjQUFjLEdBQUcsSUFBQStELDJCQUFlLEVBQUNsQixNQUFNLEVBQUUsTUFBTXJCLFFBQVEsQ0FBQ0ssT0FBTyxDQUFDLEdBQUcsRUFBRTtJQUVuRixJQUFJbUMsR0FBRyxHQUFHLEVBQUU7SUFDWixNQUFNQyxhQUFhLEdBQUlyQixJQUFZLElBQ2pDbEUsT0FBTyxDQUFFZ0UsSUFBSSxJQUFLO01BQ2hCLE1BQU13QixJQUFJLEdBQUd4QixJQUFJLENBQUN5QixLQUFLLENBQUMsQ0FBQztNQUN6QixJQUFJRCxJQUFJLENBQUNFLE1BQU0sSUFBSUYsSUFBSSxDQUFDQSxJQUFJLENBQUNFLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQ3pCLElBQUksS0FBSyxXQUFXLEVBQUV1QixJQUFJLENBQUNBLElBQUksQ0FBQ0UsTUFBTSxHQUFHLENBQUMsQ0FBQyxHQUFHO1FBQUV6QixJQUFJLEVBQUUsV0FBVztRQUFFQztNQUFLLENBQUMsQ0FBQyxLQUM5R3NCLElBQUksQ0FBQ0csSUFBSSxDQUFDO1FBQUUxQixJQUFJLEVBQUUsV0FBVztRQUFFQztNQUFLLENBQUMsQ0FBQztNQUMzQyxPQUFPc0IsSUFBSTtJQUNiLENBQUMsQ0FBQztJQUNKLE1BQU1JLFVBQVUsR0FBRyxJQUFJQyxlQUFlLENBQUMsQ0FBQztJQUN4Q3JGLFFBQVEsQ0FBQzJDLE9BQU8sR0FBR3lDLFVBQVU7SUFDN0IsSUFBSTtNQUNGLE1BQU1FLEtBQUssR0FBRyxNQUFNLElBQUFDLGFBQVEsRUFBQztRQUMzQkMsTUFBTSxFQUFFLElBQUFDLDBCQUFxQixFQUFDLENBQUM7UUFDL0J2RSxLQUFLO1FBQ0x5RCxPQUFPO1FBQ1BQLE1BQU07UUFDTnNCLE1BQU0sRUFBRXBDLENBQUM7UUFDVHFDLE9BQU8sRUFBRS9DLGFBQWEsQ0FBQ0QsT0FBTztRQUM5QmlELFFBQVEsRUFBRSxDQUFDO1FBQ1hDLE1BQU0sRUFBRVQsVUFBVSxDQUFDUyxNQUFNO1FBQ3pCQyxNQUFNLEVBQUU7VUFDTkMsZ0JBQWdCLEVBQUdDLENBQUMsSUFBSztZQUN2QmxCLEdBQUcsSUFBSWtCLENBQUM7WUFDUmpCLGFBQWEsQ0FBQ0QsR0FBRyxDQUFDO1VBQ3BCLENBQUM7VUFDRG1CLFNBQVMsRUFBRUEsQ0FBQzNGLElBQUksRUFBRTRGLEtBQUssS0FBSztZQUMxQnBCLEdBQUcsR0FBRyxFQUFFO1lBQ1J0RixPQUFPLENBQUVnRSxJQUFJLElBQUs7Y0FDaEIsTUFBTXdCLElBQUksR0FBR3hCLElBQUksQ0FBQ3lCLEtBQUssQ0FBQyxDQUFDO2NBQ3pCLElBQUlELElBQUksQ0FBQ0UsTUFBTSxJQUFJRixJQUFJLENBQUNBLElBQUksQ0FBQ0UsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDekIsSUFBSSxLQUFLLFdBQVcsSUFBSSxDQUFDdUIsSUFBSSxDQUFDQSxJQUFJLENBQUNFLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQ3hCLElBQUksRUFBRXNCLElBQUksQ0FBQ21CLEdBQUcsQ0FBQyxDQUFDO2NBQ3hHbkIsSUFBSSxDQUFDRyxJQUFJLENBQUM7Z0JBQUUxQixJQUFJLEVBQUUsVUFBVTtnQkFBRUMsSUFBSSxFQUFFLElBQUEwQyxpQ0FBZ0IsRUFBQzlGLElBQUksRUFBRTRGLEtBQUs7Y0FBRSxDQUFDLENBQUM7Y0FDcEUsT0FBT2xCLElBQUk7WUFDYixDQUFDLENBQUM7VUFDSjtRQUNGO01BQ0YsQ0FBQyxDQUFDO01BQ0YsTUFBTXFCLFFBQVEsR0FBRyxJQUFBQyxpQ0FBZ0IsRUFBQ2hCLEtBQUssQ0FBQztNQUN4QztNQUNBO01BQ0E7TUFDQTtNQUNBLElBQUlGLFVBQVUsQ0FBQ1MsTUFBTSxDQUFDVSxPQUFPLEVBQUU7UUFDN0IvRyxPQUFPLENBQUVnRSxJQUFJLElBQUssQ0FBQyxHQUFHQSxJQUFJLEVBQUU7VUFBRUMsSUFBSSxFQUFFLFVBQVU7VUFBRUMsSUFBSSxFQUFFO1FBQVUsQ0FBQyxDQUFDLENBQUM7UUFDbkU7TUFDRjtNQUNBLElBQUksQ0FBQzJDLFFBQVEsQ0FBQ2pHLElBQUksQ0FBRTRCLENBQUMsSUFBS0EsQ0FBQyxDQUFDeUIsSUFBSSxLQUFLLFdBQVcsQ0FBQyxFQUFFLE1BQU0sSUFBSStDLEtBQUssQ0FBQyxPQUFPLENBQUM7TUFDM0U1RCxhQUFhLENBQUNELE9BQU8sR0FBRzJDLEtBQUssQ0FBQ0wsS0FBSyxDQUFDLENBQUM7TUFDckN6RixPQUFPLENBQUM2RyxRQUFRLENBQUM7SUFDbkIsQ0FBQyxDQUFDLE9BQU8zSSxDQUFDLEVBQUU7TUFDVjtNQUNBO01BQ0EsSUFBSTBILFVBQVUsQ0FBQ1MsTUFBTSxDQUFDVSxPQUFPLEVBQUU7UUFDN0IvRyxPQUFPLENBQUVnRSxJQUFJLElBQUssQ0FBQyxHQUFHQSxJQUFJLEVBQUU7VUFBRUMsSUFBSSxFQUFFLFVBQVU7VUFBRUMsSUFBSSxFQUFFO1FBQVUsQ0FBQyxDQUFDLENBQUM7UUFDbkU7TUFDRjtNQUNBLE1BQU0rQyxJQUFJLEdBQUkvSSxDQUFDLEVBQXdCK0ksSUFBSSxJQUFLL0ksQ0FBQyxDQUFXZ0osT0FBTztNQUNuRTlHLGFBQWEsQ0FDWDZHLElBQUksS0FBSyxlQUFlLEdBQ3BCLDhDQUE4QyxHQUM5Q0EsSUFBSSxLQUFLLFdBQVcsR0FDbEJFLCtCQUFvQixHQUNwQkYsSUFBSSxLQUFLLFdBQVcsR0FDbEIsdUJBQXVCRywrQkFBb0IsNkJBQTZCLEdBQ3hFLHNEQUNWLENBQUM7TUFDRHBILE9BQU8sQ0FBRWdFLElBQUksSUFDWEEsSUFBSSxDQUFDMEIsTUFBTSxJQUFJMUIsSUFBSSxDQUFDQSxJQUFJLENBQUMwQixNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUN6QixJQUFJLEtBQUssV0FBVyxJQUFJLENBQUNELElBQUksQ0FBQ0EsSUFBSSxDQUFDMEIsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDeEIsSUFBSSxHQUFHRixJQUFJLENBQUN5QixLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUd6QixJQUNqSCxDQUFDO0lBQ0gsQ0FBQyxTQUFTO01BQ1I5RCxZQUFZLENBQUMsS0FBSyxDQUFDO01BQ25CLElBQUlNLFFBQVEsQ0FBQzJDLE9BQU8sS0FBS3lDLFVBQVUsRUFBRXBGLFFBQVEsQ0FBQzJDLE9BQU8sR0FBRyxJQUFJO0lBQzlEO0VBQ0Y7RUFFQSxvQkFDRSxJQUFBcEYsV0FBQSxDQUFBc0osSUFBQTtJQUFLQyxTQUFTLEVBQUMsYUFBYTtJQUFBQyxRQUFBLEdBR3pCLENBQUNqSSxJQUFJLGlCQUNKLElBQUF2QixXQUFBLENBQUFzSixJQUFBO01BQ0VDLFNBQVMsRUFBQyxTQUFTO01BQ25CRSxRQUFRLEVBQUd0SixDQUFDLElBQUs7UUFDZkEsQ0FBQyxDQUFDdUosY0FBYyxDQUFDLENBQUM7UUFDbEIsSUFBSTVFLE1BQU0sRUFBRSxLQUFLZSxHQUFHLENBQUNqRSxPQUFPLENBQUMsQ0FBQyxLQUN6QkosT0FBTyxDQUFDLElBQUksQ0FBQztNQUNwQixDQUFFO01BQUFnSSxRQUFBLGdCQUVGLElBQUF4SixXQUFBLENBQUEySixHQUFBO1FBQU1KLFNBQVMsRUFBQztNQUFJLENBQUUsQ0FBQyxlQUN2QixJQUFBdkosV0FBQSxDQUFBMkosR0FBQTtRQUNFQyxLQUFLLEVBQUVoSSxPQUFRO1FBQ2ZpSSxXQUFXLEVBQUUsb0JBQW9CcEosVUFBVSxJQUFLO1FBQ2hEcUosUUFBUSxFQUFHM0osQ0FBQyxJQUFLMEIsVUFBVSxDQUFDMUIsQ0FBQyxDQUFDNEosTUFBTSxDQUFDSCxLQUFLLENBQUU7UUFDNUNJLE9BQU8sRUFBRUEsQ0FBQSxLQUFNeEksT0FBTyxDQUFDLElBQUksQ0FBRTtRQUM3QixjQUFXO01BQVcsQ0FDdkIsQ0FBQyxlQUNGLElBQUF4QixXQUFBLENBQUEySixHQUFBO1FBQVFNLEdBQUcsRUFBRXpFLFlBQWE7UUFBQytELFNBQVMsRUFBQyxJQUFJO1FBQUNXLElBQUksRUFBQyxRQUFRO1FBQUMsY0FBVyxXQUFXO1FBQUFWLFFBQUEsZUFDNUUsSUFBQXhKLFdBQUEsQ0FBQTJKLEdBQUEsRUFBQzdKLEtBQUEsQ0FBQU8sT0FBSTtVQUFDMEMsSUFBSSxFQUFDO1FBQU0sQ0FBRTtNQUFDLENBQ2QsQ0FBQztJQUFBLENBQ0wsQ0FDUCxFQUdBeEIsSUFBSSxpQkFDSCxJQUFBdkIsV0FBQSxDQUFBc0osSUFBQSxFQUFBdEosV0FBQSxDQUFBbUssUUFBQTtNQUFBWCxRQUFBLGdCQUNFLElBQUF4SixXQUFBLENBQUEySixHQUFBO1FBQUtKLFNBQVMsRUFBQyxVQUFVO1FBQUNhLE9BQU8sRUFBRUEsQ0FBQSxLQUFNNUksT0FBTyxDQUFDLEtBQUs7TUFBRSxDQUFFLENBQUMsZUFDM0QsSUFBQXhCLFdBQUEsQ0FBQTJKLEdBQUE7UUFDRUosU0FBUyxFQUFDLFVBQVU7UUFDcEIsZUFBYTdILE1BQU87UUFDcEJ1SSxHQUFHLEVBQUV2SCxTQUFVO1FBQ2YySCxRQUFRLEVBQUUsQ0FBQyxDQUFFO1FBQ2JDLElBQUksRUFBQyxRQUFRO1FBQ2IsY0FBVyxNQUFNO1FBQ2pCLGNBQVcsV0FBVztRQUFBZCxRQUFBLGVBRXRCLElBQUF4SixXQUFBLENBQUFzSixJQUFBO1VBQUtDLFNBQVMsRUFBQyxnQkFBZ0I7VUFBQUMsUUFBQSxnQkFDN0IsSUFBQXhKLFdBQUEsQ0FBQXNKLElBQUE7WUFBS0MsU0FBUyxFQUFDLFNBQVM7WUFBQUMsUUFBQSxnQkFDdEIsSUFBQXhKLFdBQUEsQ0FBQTJKLEdBQUE7Y0FBTUosU0FBUyxFQUFDLE1BQU07Y0FBQ2EsT0FBTyxFQUFFQSxDQUFBLEtBQU16SSxTQUFTLENBQUU0SSxDQUFDLElBQU1BLENBQUMsS0FBSyxNQUFNLEdBQUcsTUFBTSxHQUFHLE1BQU87WUFBRSxDQUFFLENBQUMsZUFDNUYsSUFBQXZLLFdBQUEsQ0FBQTJKLEdBQUE7Y0FBTUosU0FBUyxFQUFDO1lBQUksQ0FBRSxDQUFDLGVBQ3ZCLElBQUF2SixXQUFBLENBQUEySixHQUFBO2NBQU1KLFNBQVMsRUFBQyxJQUFJO2NBQUFDLFFBQUEsRUFBQztZQUFLLENBQU0sQ0FBQyxlQUNqQyxJQUFBeEosV0FBQSxDQUFBc0osSUFBQTtjQUFNQyxTQUFTLEVBQUMsTUFBTTtjQUFBQyxRQUFBLGdCQUNwQixJQUFBeEosV0FBQSxDQUFBMkosR0FBQTtnQkFBUUosU0FBUyxFQUFDLElBQUk7Z0JBQUMsY0FBWTdILE1BQU0sS0FBSyxNQUFNLEdBQUcsUUFBUSxHQUFHLFVBQVc7Z0JBQUMwSSxPQUFPLEVBQUVBLENBQUEsS0FBTXpJLFNBQVMsQ0FBRTRJLENBQUMsSUFBTUEsQ0FBQyxLQUFLLE1BQU0sR0FBRyxNQUFNLEdBQUcsTUFBTyxDQUFFO2dCQUFBZixRQUFBLGVBQzlJLElBQUF4SixXQUFBLENBQUEySixHQUFBLEVBQUM3SixLQUFBLENBQUFPLE9BQUk7a0JBQUMwQyxJQUFJLEVBQUVyQixNQUFNLEtBQUssTUFBTSxHQUFHLGNBQWMsR0FBRztnQkFBZ0IsQ0FBRTtjQUFDLENBQzlELENBQUMsZUFDVCxJQUFBMUIsV0FBQSxDQUFBMkosR0FBQTtnQkFBUUosU0FBUyxFQUFDLElBQUk7Z0JBQUMsY0FBVyxPQUFPO2dCQUFDYSxPQUFPLEVBQUVBLENBQUEsS0FBTTVJLE9BQU8sQ0FBQyxLQUFLLENBQUU7Z0JBQUFnSSxRQUFBLGVBQ3RFLElBQUF4SixXQUFBLENBQUEySixHQUFBLEVBQUM3SixLQUFBLENBQUFPLE9BQUk7a0JBQUMwQyxJQUFJLEVBQUM7Z0JBQUcsQ0FBRTtjQUFDLENBQ1gsQ0FBQztZQUFBLENBQ0wsQ0FBQztVQUFBLENBQ0osQ0FBQyxlQUtOLElBQUEvQyxXQUFBLENBQUEySixHQUFBO1lBQUtKLFNBQVMsRUFBQyxVQUFVO1lBQUNlLElBQUksRUFBQyxNQUFNO1lBQUMsY0FBVyw0QkFBNEI7WUFBQWQsUUFBQSxFQUMxRTVGLFNBQVMsQ0FBQ1ksR0FBRyxDQUFFQyxDQUFDLGlCQUNmLElBQUF6RSxXQUFBLENBQUFzSixJQUFBO2NBQUtDLFNBQVMsRUFBRSxnQ0FBZ0M5RSxDQUFDLENBQUNHLEtBQUssRUFBRztjQUFDMEYsSUFBSSxFQUFDLFVBQVU7Y0FBQWQsUUFBQSxnQkFDeEUsSUFBQXhKLFdBQUEsQ0FBQTJKLEdBQUE7Z0JBQU1KLFNBQVMsRUFBQyxnQkFBZ0I7Z0JBQUMsbUJBQVc7Z0JBQUFDLFFBQUEsRUFDekMvRSxDQUFDLENBQUNHLEtBQUssS0FBSyxJQUFJLEdBQUcsR0FBRyxHQUFHSCxDQUFDLENBQUNHLEtBQUssS0FBSyxTQUFTLEdBQUcsR0FBRyxHQUFHSCxDQUFDLENBQUNHLEtBQUssS0FBSyxXQUFXLEdBQUcsR0FBRyxHQUFHO2NBQUcsQ0FDdkYsQ0FBQyxlQUNQLElBQUE1RSxXQUFBLENBQUEySixHQUFBO2dCQUFNSixTQUFTLEVBQUMscUJBQXFCO2dCQUFBQyxRQUFBLEVBQUUsSUFBQTdFLG9CQUFTLEVBQUNGLENBQUMsQ0FBQ0csS0FBSztjQUFDLENBQU8sQ0FBQyxlQUNqRSxJQUFBNUUsV0FBQSxDQUFBMkosR0FBQTtnQkFBTUosU0FBUyxFQUFDLGlCQUFpQjtnQkFBQUMsUUFBQSxFQUFFL0UsQ0FBQyxDQUFDQztjQUFLLENBQU8sQ0FBQyxFQUNqREQsQ0FBQyxDQUFDK0YsS0FBSyxpQkFBSSxJQUFBeEssV0FBQSxDQUFBMkosR0FBQTtnQkFBTUosU0FBUyxFQUFDLGlCQUFpQjtnQkFBQUMsUUFBQSxFQUFFL0UsQ0FBQyxDQUFDK0Y7Y0FBSyxDQUFPLENBQUMsRUFDN0QvRixDQUFDLENBQUNnRyxXQUFXLGlCQUFJLElBQUF6SyxXQUFBLENBQUEySixHQUFBO2dCQUFNSixTQUFTLEVBQUMsaUJBQWlCO2dCQUFBQyxRQUFBLEVBQUUsS0FBSy9FLENBQUMsQ0FBQ2dHLFdBQVc7Y0FBRSxDQUFPLENBQUMsRUFDaEZoRyxDQUFDLENBQUNpRyxNQUFNLEtBQUssYUFBYTtjQUFBO2NBQ3pCO2NBQ0E7Y0FDQTtjQUNBO2NBQ0E7Y0FDQSxJQUFBMUssV0FBQSxDQUFBMkosR0FBQTtnQkFDRU8sSUFBSSxFQUFDLFFBQVE7Z0JBQ2JYLFNBQVMsRUFBQyxrQkFBa0I7Z0JBQzVCYSxPQUFPLEVBQUVBLENBQUEsS0FDUCxLQUFLdkUsR0FBRyxDQUFDL0QsS0FBSyxDQUFDa0UsSUFBSSxDQUFDLENBQUMsSUFBSSwrREFBK0QsQ0FDekY7Z0JBQUF3RCxRQUFBLEVBQ0Y7Y0FFRCxDQUFRLENBQ1Q7WUFBQSxHQXZCNkUvRSxDQUFDLENBQUNrRyxHQXdCN0UsQ0FDTjtVQUFDLENBQ0MsQ0FBQyxFQUNMdkcsU0FBUyxpQkFBSSxJQUFBcEUsV0FBQSxDQUFBMkosR0FBQTtZQUFHSixTQUFTLEVBQUMsV0FBVztZQUFBQyxRQUFBLEVBQUVwRjtVQUFTLENBQUksQ0FBQyxlQUd0RCxJQUFBcEUsV0FBQSxDQUFBMkosR0FBQTtZQUFLSixTQUFTLEVBQUMscUJBQXFCO1lBQUNlLElBQUksRUFBQyxRQUFRO1lBQUFkLFFBQUEsRUFDL0NqRjtVQUFpQixDQUNmLENBQUMsRUFDTCxJQUFBcUcsK0JBQW9CLEVBQUNsSyxhQUFhLENBQUMsaUJBQUksSUFBQVYsV0FBQSxDQUFBMkosR0FBQTtZQUFHSixTQUFTLEVBQUMsV0FBVztZQUFBQyxRQUFBLEVBQUVxQjtVQUFpQixDQUFJLENBQUMsRUFDdkZ6SSxVQUFVLGlCQUNULElBQUFwQyxXQUFBLENBQUEySixHQUFBO1lBQUtKLFNBQVMsRUFBQyxVQUFVO1lBQUNlLElBQUksRUFBQyxRQUFRO1lBQUFkLFFBQUEsRUFDcENwSDtVQUFVLENBQ1IsQ0FDTixlQUVELElBQUFwQyxXQUFBLENBQUEySixHQUFBO1lBQUtKLFNBQVMsRUFBQyxTQUFTO1lBQUNVLEdBQUcsRUFBRTNILE9BQVE7WUFBQWtILFFBQUEsRUFDbkN4SCxJQUFJLENBQUMyRixNQUFNLEtBQUssQ0FBQyxnQkFDaEIsSUFBQTNILFdBQUEsQ0FBQXNKLElBQUEsRUFBQXRKLFdBQUEsQ0FBQW1LLFFBQUE7Y0FBQVgsUUFBQSxnQkFDRSxJQUFBeEosV0FBQSxDQUFBc0osSUFBQTtnQkFBS0MsU0FBUyxFQUFDLFlBQVk7Z0JBQUFDLFFBQUEsZ0JBQ3pCLElBQUF4SixXQUFBLENBQUEySixHQUFBO2tCQUFBSCxRQUFBLEVBQUc7Z0JBQWEsQ0FBRyxDQUFDLDhHQUV0QjtjQUFBLENBQUssQ0FBQyxFQUNMdEYsS0FBSyxDQUFDeUQsTUFBTSxHQUFHLENBQUMsaUJBQ2YsSUFBQTNILFdBQUEsQ0FBQTJKLEdBQUE7Z0JBQUtKLFNBQVMsRUFBQyxVQUFVO2dCQUFBQyxRQUFBLEVBQ3RCdEYsS0FBSyxDQUFDTSxHQUFHLENBQUVzRyxDQUFDLGlCQUNYLElBQUE5SyxXQUFBLENBQUEySixHQUFBO2tCQUFnQkosU0FBUyxFQUFDLFNBQVM7a0JBQUNhLE9BQU8sRUFBRUEsQ0FBQSxLQUFNLEtBQUt2RSxHQUFHLENBQUNpRixDQUFDLENBQUU7a0JBQUF0QixRQUFBLEVBQzVEc0I7Z0JBQUMsR0FEU0EsQ0FFTCxDQUNUO2NBQUMsQ0FDQyxDQUNOO1lBQUEsQ0FDRCxDQUFDLEdBRUg5SSxJQUFJLENBQUN3QyxHQUFHLENBQUMsQ0FBQ0MsQ0FBQyxFQUFFc0csQ0FBQyxLQUNadEcsQ0FBQyxDQUFDeUIsSUFBSSxLQUFLLFVBQVUsZ0JBQ25CLElBQUFsRyxXQUFBLENBQUFzSixJQUFBO2NBQWFDLFNBQVMsRUFBQyxhQUFhO2NBQUFDLFFBQUEsZ0JBQ2xDLElBQUF4SixXQUFBLENBQUEySixHQUFBLEVBQUM3SixLQUFBLENBQUFPLE9BQUk7Z0JBQUMwQyxJQUFJLEVBQUM7Y0FBTSxDQUFFLENBQUMsRUFDbkIwQixDQUFDLENBQUMwQixJQUFJO1lBQUEsR0FGQzRFLENBR0wsQ0FBQyxnQkFFTixJQUFBL0ssV0FBQSxDQUFBc0osSUFBQTtjQUFhQyxTQUFTLEVBQUUsVUFBVTlFLENBQUMsQ0FBQ3lCLElBQUksRUFBRztjQUFBc0QsUUFBQSxnQkFDekMsSUFBQXhKLFdBQUEsQ0FBQTJKLEdBQUE7Z0JBQU1KLFNBQVMsRUFBRSxjQUFjOUUsQ0FBQyxDQUFDeUIsSUFBSSxLQUFLLFdBQVcsR0FBRyxPQUFPLEdBQUcsTUFBTSxFQUFHO2dCQUFBc0QsUUFBQSxFQUN4RS9FLENBQUMsQ0FBQ3lCLElBQUksS0FBSyxXQUFXLEdBQUcsRUFBRSxHQUFHO2NBQUssQ0FDaEMsQ0FBQyxlQUNQLElBQUFsRyxXQUFBLENBQUFzSixJQUFBO2dCQUFLQyxTQUFTLEVBQUMsV0FBVztnQkFBQUMsUUFBQSxnQkFDeEIsSUFBQXhKLFdBQUEsQ0FBQTJKLEdBQUE7a0JBQUtKLFNBQVMsRUFBQyxhQUFhO2tCQUFBQyxRQUFBLEVBQUUvRSxDQUFDLENBQUN5QixJQUFJLEtBQUssV0FBVyxHQUFHLE9BQU8sR0FBRztnQkFBSyxDQUFNLENBQUMsZUFDN0UsSUFBQWxHLFdBQUEsQ0FBQXNKLElBQUE7a0JBQUtDLFNBQVMsRUFBQyxhQUFhO2tCQUFBQyxRQUFBLEdBQ3pCL0UsQ0FBQyxDQUFDMEIsSUFBSSxFQUNOakUsU0FBUyxJQUFJNkksQ0FBQyxLQUFLL0ksSUFBSSxDQUFDMkYsTUFBTSxHQUFHLENBQUMsSUFBSWxELENBQUMsQ0FBQ3lCLElBQUksS0FBSyxXQUFXLGdCQUFHLElBQUFsRyxXQUFBLENBQUEySixHQUFBO29CQUFNSixTQUFTLEVBQUM7a0JBQVcsQ0FBRSxDQUFDLEdBQUcsSUFBSTtnQkFBQSxDQUNsRyxDQUFDO2NBQUEsQ0FDSCxDQUFDO1lBQUEsR0FWRXdCLENBV0wsQ0FFVDtVQUNELENBQ0UsQ0FBQyxlQUVOLElBQUEvSyxXQUFBLENBQUFzSixJQUFBO1lBQUtDLFNBQVMsRUFBQyxTQUFTO1lBQUFDLFFBQUEsZ0JBQ3RCLElBQUF4SixXQUFBLENBQUFzSixJQUFBO2NBQ0VDLFNBQVMsRUFBQyxjQUFjO2NBQ3hCRSxRQUFRLEVBQUd0SixDQUFDLElBQUs7Z0JBQ2ZBLENBQUMsQ0FBQ3VKLGNBQWMsQ0FBQyxDQUFDO2dCQUNsQixLQUFLN0QsR0FBRyxDQUFDL0QsS0FBSyxDQUFDO2NBQ2pCLENBQUU7Y0FBQTBILFFBQUEsZ0JBRUYsSUFBQXhKLFdBQUEsQ0FBQTJKLEdBQUE7Z0JBQ0VNLEdBQUcsRUFBRXpILE9BQVE7Z0JBQ2JvSCxLQUFLLEVBQUU5SCxLQUFNO2dCQUNiK0gsV0FBVyxFQUFDLGlCQUFZO2dCQUN4Qm1CLFFBQVEsRUFBRTlJLFNBQVMsSUFBSSxDQUFDNEMsTUFBTztnQkFDL0JnRixRQUFRLEVBQUczSixDQUFDLElBQUs0QixRQUFRLENBQUM1QixDQUFDLENBQUM0SixNQUFNLENBQUNILEtBQUs7Y0FBRSxDQUMzQyxDQUFDLEVBQ0QxSCxTQUFTLGdCQUNSLElBQUFsQyxXQUFBLENBQUEySixHQUFBO2dCQUNFSixTQUFTLEVBQUMsTUFBTTtnQkFDaEJXLElBQUksRUFBQyxRQUFRO2dCQUNiLGNBQVcsTUFBTTtnQkFDakJlLEtBQUssRUFBQyxNQUFNO2dCQUNaYixPQUFPLEVBQUVBLENBQUEsS0FBTTNILFFBQVEsQ0FBQzJDLE9BQU8sRUFBRThGLEtBQUssQ0FBQyxDQUFFO2dCQUFBMUIsUUFBQSxlQUV6QyxJQUFBeEosV0FBQSxDQUFBMkosR0FBQSxFQUFDN0osS0FBQSxDQUFBTyxPQUFJO2tCQUFDMEMsSUFBSSxFQUFDO2dCQUFHLENBQUU7Y0FBQyxDQUNYLENBQUMsR0FDUCxJQUFJLGVBQ1IsSUFBQS9DLFdBQUEsQ0FBQTJKLEdBQUE7Z0JBQVFKLFNBQVMsRUFBQyxJQUFJO2dCQUFDVyxJQUFJLEVBQUMsUUFBUTtnQkFBQ2MsUUFBUSxFQUFFOUksU0FBUyxJQUFJLENBQUM0QyxNQUFNLElBQUksQ0FBQ2hELEtBQUssQ0FBQ2tFLElBQUksQ0FBQyxDQUFFO2dCQUFDLGNBQVk5RCxTQUFTLEdBQUcsWUFBWSxHQUFHLE1BQU87Z0JBQUMrSSxLQUFLLEVBQUUvSSxTQUFTLEdBQUcsWUFBWSxHQUFHLE1BQU87Z0JBQUFzSCxRQUFBLGVBQzVLLElBQUF4SixXQUFBLENBQUEySixHQUFBLEVBQUM3SixLQUFBLENBQUFPLE9BQUk7a0JBQUMwQyxJQUFJLEVBQUM7Z0JBQU0sQ0FBRTtjQUFDLENBQ2QsQ0FBQztZQUFBLENBQ0wsQ0FBQyxlQUNQLElBQUEvQyxXQUFBLENBQUFzSixJQUFBO2NBQUtDLFNBQVMsRUFBQyxlQUFlO2NBQUFDLFFBQUEsZ0JBQzVCLElBQUF4SixXQUFBLENBQUEySixHQUFBO2dCQUFBSCxRQUFBLEVBQU9xQjtjQUFpQixDQUFPLENBQUMsRUFDL0J4SixXQUFXLGlCQUNWLElBQUFyQixXQUFBLENBQUEySixHQUFBO2dCQUFNSixTQUFTLEVBQUMsaUJBQWlCO2dCQUFDZSxJQUFJLEVBQUMsUUFBUTtnQkFBQWQsUUFBQSxFQUM1QzJCO2NBQW1CLENBQ2hCLENBQ1AsZUFDRCxJQUFBbkwsV0FBQSxDQUFBc0osSUFBQTtnQkFBUVksSUFBSSxFQUFDLFFBQVE7Z0JBQUNFLE9BQU8sRUFBRUEsQ0FBQSxLQUFNaEosVUFBVSxDQUFDWixRQUFRLENBQUU7Z0JBQUFnSixRQUFBLGdCQUN4RCxJQUFBeEosV0FBQSxDQUFBMkosR0FBQSxFQUFDN0osS0FBQSxDQUFBTyxPQUFJO2tCQUFDMEMsSUFBSSxFQUFDO2dCQUFVLENBQUUsQ0FBQyxzQkFFMUI7Y0FBQSxDQUFRLENBQUM7WUFBQSxDQUNOLENBQUM7VUFBQSxDQUNILENBQUM7UUFBQSxDQUNIO01BQUMsQ0FDSCxDQUFDO0lBQUEsQ0FDTixDQUNIO0VBQUEsQ0FDRSxDQUFDO0FBRVY7QUFBQzlDLEVBQUEsQ0F0WnVCSyxVQUFVO0VBQUEsUUFTVksseUJBQW9CLEVBQzFCRSxlQUFVLEVBQ1pFLG1CQUFjLEVBQ1hFLHdCQUFXLEVBQ05FLDZCQUFnQixFQUNGRyxlQUFRLEVBZTFCcUIsOENBQXNCLEVBUWhCTSxzQ0FBa0IsRUFDMUJFLG9CQUFlO0FBQUE7QUFBQWlJLEVBQUEsR0F0Q1Q5SyxVQUFVO0FBQUEsSUFBQThLLEVBQUE7QUFBQUMsWUFBQSxDQUFBRCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}