var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = GroveNav;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
var _sdk = require("@immediately-run/sdk");
var _shell = require("../lib/shell");
var _contentRoot = require("../lib/contentRoot");
var _useOverlayFocusDismiss = require("../hooks/useOverlayFocusDismiss");
var _themes = require("../data/themes");
var _Icon = _interopRequireDefault(require("./Icon"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // `<GroveNav/>` — the top navigation bar. Import-free in MDX, so a layout places
// it with `<GroveNav/>`. Its interactive state (drawer / search / theme menu)
// lives in the shell context; this component only arranges and drives it.
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function GroveNav() {
  _s();
  const {
    siteTitle,
    navItems,
    entryKey,
    writable,
    openEditor,
    editBusy,
    editRefused,
    editHint,
    theme,
    setTheme,
    light,
    setLight,
    menuOpen,
    setMenuOpen,
    setSearchOpen,
    setDrawerOpen
  } = (0, _shell.useShell)();
  const askGrove = () => {
    const el = document.querySelector('.ga-foot input') || document.querySelector('.ga-line input');
    el?.focus();
  };
  // The new entry belongs to whichever corpus is mounted, so it is named from the
  // content ROOT rather than the fork's `content/` literal — under dispatch the latter
  // would create a file in Grove's own repo (R3-266).
  const newEntry = () => openEditor(`${(0, _contentRoot.getContentRoot)()}untitled.mdx`);

  // The theme menu's contract (R3-608): the shared overlay hook with Tab-trap
  // OFF (menus do not trap Tab), plus the menu keydown map — arrows walk the
  // menuitems, Escape closes (the hook), focus returns to the theme button.
  const menuRef = (0, _useOverlayFocusDismiss.useOverlayFocusDismiss)(menuOpen, () => setMenuOpen(false), {
    trapTab: false
  });
  const onMenuKeyDown = e => {
    const items = [...(menuRef.current?.querySelectorAll('[role^="menuitem"]') ?? [])];
    if (!items.length) return;
    const idx = items.indexOf(document.activeElement);
    const move = i => {
      e.preventDefault();
      const next = items[(i + items.length) % items.length];
      next.focus();
      // APG menu radios: arrows MOVE focus AND activate — the radio the arrow
      // lands on is selected, so the keyboard alone can change the theme.
      if (next.getAttribute('role') === 'menuitemradio' && next.getAttribute('aria-checked') !== 'true') next.click();
    };
    if (e.key === 'ArrowDown') move(idx + 1);else if (e.key === 'ArrowUp') move(idx - 1);else if (e.key === 'Home') move(0);else if (e.key === 'End') move(items.length - 1);
  };
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("nav", {
    className: "grove-nav",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
      className: "grove-hamburger icbtn",
      "aria-label": "Menu",
      onClick: () => setDrawerOpen(true),
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
        name: "list"
      })
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_sdk.Link, {
      href: "/",
      className: "grove-brand",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "tile",
        style: {
          background: 'var(--grad)'
        }
      }), siteTitle]
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "grove-nav__links",
      children: navItems.map(n => /*#__PURE__*/(0, _jsxRuntime.jsx)(_sdk.Link, {
        href: n.href,
        "data-cur": n.key === entryKey ? '1' : '0',
        children: n.label
      }, n.key))
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "grove-nav__cluster",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        className: "icbtn",
        "aria-label": "Search",
        onClick: () => setSearchOpen(true),
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
          name: "search"
        })
      }), writable && /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          className: "icbtn",
          "aria-label": editBusy ? 'Opening editor…' : 'New entry',
          title: editHint,
          "data-busy": editBusy ? '1' : '0',
          disabled: editBusy,
          onClick: newEntry,
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
            name: "plus"
          })
        }), editRefused && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "grove-edit-refused",
          role: "status",
          title: _shell.EDIT_REFUSED_NOTICE,
          children: _shell.EDIT_REFUSED_NOTICE
        })]
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        className: "icbtn",
        "aria-label": "Ask Grove",
        onClick: askGrove,
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
          name: "message"
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "grove-nav__more",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          className: "icbtn grove-theme-control",
          title: "Theme",
          "aria-expanded": menuOpen,
          "aria-haspopup": "menu",
          onClick: () => setMenuOpen(o => !o),
          children: "\u2600"
        }), menuOpen ? /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
            className: "gtm__scrim",
            onClick: () => setMenuOpen(false)
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
            className: "grove-theme-menu",
            role: "menu",
            "aria-label": "Theme",
            ref: menuRef,
            tabIndex: -1,
            onKeyDown: onMenuKeyDown,
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
              className: "gtm__h",
              children: "Theme"
            }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
              className: "gtm__list",
              children: _themes.THEMES.map(t => /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
                className: "gtm__row",
                "data-cur": theme === t.id ? '1' : '0',
                role: "menuitemradio",
                "aria-checked": theme === t.id,
                tabIndex: -1,
                onClick: () => setTheme(t.id),
                children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
                  className: "gtm__sw",
                  style: {
                    background: t.swatch
                  }
                }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
                  className: "gtm__name",
                  children: t.label
                }), theme === t.id ? /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
                  className: "gtm__ck",
                  children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
                    name: "check"
                  })
                }) : null]
              }, t.id))
            }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
              className: "gtm__appearance",
              children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
                className: "gtm__sub",
                children: "Appearance"
              }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
                className: "gtm__seg",
                children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
                  "data-on": !light ? '1' : '0',
                  role: "menuitemradio",
                  "aria-checked": !light,
                  tabIndex: -1,
                  onClick: () => setLight(false),
                  children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
                    name: "moon"
                  }), " Dark"]
                }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
                  "data-on": light ? '1' : '0',
                  role: "menuitemradio",
                  "aria-checked": light,
                  tabIndex: -1,
                  onClick: () => setLight(true),
                  children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
                    name: "sun"
                  }), " Light"]
                })]
              })]
            })]
          })]
        }) : null]
      })]
    })]
  });
}
_s(GroveNav, "ch9aCHj/iJgVZ/7phMTpmnidAgk=", false, function () {
  return [_shell.useShell, _useOverlayFocusDismiss.useOverlayFocusDismiss];
});
_c = GroveNav;
var _c;
$RefreshReg$(_c, "GroveNav");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfc2RrIiwicmVxdWlyZSIsIl9zaGVsbCIsIl9jb250ZW50Um9vdCIsIl91c2VPdmVybGF5Rm9jdXNEaXNtaXNzIiwiX3RoZW1lcyIsIl9JY29uIiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsIl9qc3hSdW50aW1lIiwiX3MiLCIkUmVmcmVzaFNpZyQiLCJlIiwiX19lc01vZHVsZSIsImRlZmF1bHQiLCJHcm92ZU5hdiIsInNpdGVUaXRsZSIsIm5hdkl0ZW1zIiwiZW50cnlLZXkiLCJ3cml0YWJsZSIsIm9wZW5FZGl0b3IiLCJlZGl0QnVzeSIsImVkaXRSZWZ1c2VkIiwiZWRpdEhpbnQiLCJ0aGVtZSIsInNldFRoZW1lIiwibGlnaHQiLCJzZXRMaWdodCIsIm1lbnVPcGVuIiwic2V0TWVudU9wZW4iLCJzZXRTZWFyY2hPcGVuIiwic2V0RHJhd2VyT3BlbiIsInVzZVNoZWxsIiwiYXNrR3JvdmUiLCJlbCIsImRvY3VtZW50IiwicXVlcnlTZWxlY3RvciIsImZvY3VzIiwibmV3RW50cnkiLCJnZXRDb250ZW50Um9vdCIsIm1lbnVSZWYiLCJ1c2VPdmVybGF5Rm9jdXNEaXNtaXNzIiwidHJhcFRhYiIsIm9uTWVudUtleURvd24iLCJpdGVtcyIsImN1cnJlbnQiLCJxdWVyeVNlbGVjdG9yQWxsIiwibGVuZ3RoIiwiaWR4IiwiaW5kZXhPZiIsImFjdGl2ZUVsZW1lbnQiLCJtb3ZlIiwiaSIsInByZXZlbnREZWZhdWx0IiwibmV4dCIsImdldEF0dHJpYnV0ZSIsImNsaWNrIiwia2V5IiwianN4cyIsImNsYXNzTmFtZSIsImNoaWxkcmVuIiwianN4Iiwib25DbGljayIsIm5hbWUiLCJMaW5rIiwiaHJlZiIsInN0eWxlIiwiYmFja2dyb3VuZCIsIm1hcCIsIm4iLCJsYWJlbCIsIkZyYWdtZW50IiwidGl0bGUiLCJkaXNhYmxlZCIsInJvbGUiLCJFRElUX1JFRlVTRURfTk9USUNFIiwibyIsInJlZiIsInRhYkluZGV4Iiwib25LZXlEb3duIiwiVEhFTUVTIiwidCIsImlkIiwic3dhdGNoIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJHcm92ZU5hdi50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTGluayB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrJztcbmltcG9ydCB7IHVzZVNoZWxsLCBFRElUX1JFRlVTRURfTk9USUNFIH0gZnJvbSAnLi4vbGliL3NoZWxsJztcbmltcG9ydCB7IGdldENvbnRlbnRSb290IH0gZnJvbSAnLi4vbGliL2NvbnRlbnRSb290JztcbmltcG9ydCB7IHVzZU92ZXJsYXlGb2N1c0Rpc21pc3MgfSBmcm9tICcuLi9ob29rcy91c2VPdmVybGF5Rm9jdXNEaXNtaXNzJztcbmltcG9ydCB7IFRIRU1FUyB9IGZyb20gJy4uL2RhdGEvdGhlbWVzJztcbmltcG9ydCBJY29uIGZyb20gJy4vSWNvbic7XG5cbi8vIGA8R3JvdmVOYXYvPmAg4oCUIHRoZSB0b3AgbmF2aWdhdGlvbiBiYXIuIEltcG9ydC1mcmVlIGluIE1EWCwgc28gYSBsYXlvdXQgcGxhY2VzXG4vLyBpdCB3aXRoIGA8R3JvdmVOYXYvPmAuIEl0cyBpbnRlcmFjdGl2ZSBzdGF0ZSAoZHJhd2VyIC8gc2VhcmNoIC8gdGhlbWUgbWVudSlcbi8vIGxpdmVzIGluIHRoZSBzaGVsbCBjb250ZXh0OyB0aGlzIGNvbXBvbmVudCBvbmx5IGFycmFuZ2VzIGFuZCBkcml2ZXMgaXQuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBHcm92ZU5hdigpIHtcbiAgY29uc3Qge1xuICAgIHNpdGVUaXRsZSxcbiAgICBuYXZJdGVtcyxcbiAgICBlbnRyeUtleSxcbiAgICB3cml0YWJsZSxcbiAgICBvcGVuRWRpdG9yLFxuICAgIGVkaXRCdXN5LFxuICAgIGVkaXRSZWZ1c2VkLFxuICAgIGVkaXRIaW50LFxuICAgIHRoZW1lLFxuICAgIHNldFRoZW1lLFxuICAgIGxpZ2h0LFxuICAgIHNldExpZ2h0LFxuICAgIG1lbnVPcGVuLFxuICAgIHNldE1lbnVPcGVuLFxuICAgIHNldFNlYXJjaE9wZW4sXG4gICAgc2V0RHJhd2VyT3BlbixcbiAgfSA9IHVzZVNoZWxsKCk7XG5cbiAgY29uc3QgYXNrR3JvdmUgPSAoKSA9PiB7XG4gICAgY29uc3QgZWwgPSAoZG9jdW1lbnQucXVlcnlTZWxlY3RvcignLmdhLWZvb3QgaW5wdXQnKSB8fCBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcuZ2EtbGluZSBpbnB1dCcpKSBhcyBIVE1MRWxlbWVudCB8IG51bGw7XG4gICAgZWw/LmZvY3VzKCk7XG4gIH07XG4gIC8vIFRoZSBuZXcgZW50cnkgYmVsb25ncyB0byB3aGljaGV2ZXIgY29ycHVzIGlzIG1vdW50ZWQsIHNvIGl0IGlzIG5hbWVkIGZyb20gdGhlXG4gIC8vIGNvbnRlbnQgUk9PVCByYXRoZXIgdGhhbiB0aGUgZm9yaydzIGBjb250ZW50L2AgbGl0ZXJhbCDigJQgdW5kZXIgZGlzcGF0Y2ggdGhlIGxhdHRlclxuICAvLyB3b3VsZCBjcmVhdGUgYSBmaWxlIGluIEdyb3ZlJ3Mgb3duIHJlcG8gKFIzLTI2NikuXG4gIGNvbnN0IG5ld0VudHJ5ID0gKCkgPT4gb3BlbkVkaXRvcihgJHtnZXRDb250ZW50Um9vdCgpfXVudGl0bGVkLm1keGApO1xuXG4gIC8vIFRoZSB0aGVtZSBtZW51J3MgY29udHJhY3QgKFIzLTYwOCk6IHRoZSBzaGFyZWQgb3ZlcmxheSBob29rIHdpdGggVGFiLXRyYXBcbiAgLy8gT0ZGIChtZW51cyBkbyBub3QgdHJhcCBUYWIpLCBwbHVzIHRoZSBtZW51IGtleWRvd24gbWFwIOKAlCBhcnJvd3Mgd2FsayB0aGVcbiAgLy8gbWVudWl0ZW1zLCBFc2NhcGUgY2xvc2VzICh0aGUgaG9vayksIGZvY3VzIHJldHVybnMgdG8gdGhlIHRoZW1lIGJ1dHRvbi5cbiAgY29uc3QgbWVudVJlZiA9IHVzZU92ZXJsYXlGb2N1c0Rpc21pc3MobWVudU9wZW4sICgpID0+IHNldE1lbnVPcGVuKGZhbHNlKSwgeyB0cmFwVGFiOiBmYWxzZSB9KTtcbiAgY29uc3Qgb25NZW51S2V5RG93biA9IChlOiBSZWFjdC5LZXlib2FyZEV2ZW50KSA9PiB7XG4gICAgY29uc3QgaXRlbXMgPSBbLi4uKG1lbnVSZWYuY3VycmVudD8ucXVlcnlTZWxlY3RvckFsbDxIVE1MRWxlbWVudD4oJ1tyb2xlXj1cIm1lbnVpdGVtXCJdJykgPz8gW10pXTtcbiAgICBpZiAoIWl0ZW1zLmxlbmd0aCkgcmV0dXJuO1xuICAgIGNvbnN0IGlkeCA9IGl0ZW1zLmluZGV4T2YoZG9jdW1lbnQuYWN0aXZlRWxlbWVudCBhcyBIVE1MRWxlbWVudCk7XG4gICAgY29uc3QgbW92ZSA9IChpOiBudW1iZXIpID0+IHtcbiAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgIGNvbnN0IG5leHQgPSBpdGVtc1soaSArIGl0ZW1zLmxlbmd0aCkgJSBpdGVtcy5sZW5ndGhdO1xuICAgICAgbmV4dC5mb2N1cygpO1xuICAgICAgLy8gQVBHIG1lbnUgcmFkaW9zOiBhcnJvd3MgTU9WRSBmb2N1cyBBTkQgYWN0aXZhdGUg4oCUIHRoZSByYWRpbyB0aGUgYXJyb3dcbiAgICAgIC8vIGxhbmRzIG9uIGlzIHNlbGVjdGVkLCBzbyB0aGUga2V5Ym9hcmQgYWxvbmUgY2FuIGNoYW5nZSB0aGUgdGhlbWUuXG4gICAgICBpZiAobmV4dC5nZXRBdHRyaWJ1dGUoJ3JvbGUnKSA9PT0gJ21lbnVpdGVtcmFkaW8nICYmIG5leHQuZ2V0QXR0cmlidXRlKCdhcmlhLWNoZWNrZWQnKSAhPT0gJ3RydWUnKSBuZXh0LmNsaWNrKCk7XG4gICAgfTtcbiAgICBpZiAoZS5rZXkgPT09ICdBcnJvd0Rvd24nKSBtb3ZlKGlkeCArIDEpO1xuICAgIGVsc2UgaWYgKGUua2V5ID09PSAnQXJyb3dVcCcpIG1vdmUoaWR4IC0gMSk7XG4gICAgZWxzZSBpZiAoZS5rZXkgPT09ICdIb21lJykgbW92ZSgwKTtcbiAgICBlbHNlIGlmIChlLmtleSA9PT0gJ0VuZCcpIG1vdmUoaXRlbXMubGVuZ3RoIC0gMSk7XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8bmF2IGNsYXNzTmFtZT1cImdyb3ZlLW5hdlwiPlxuICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJncm92ZS1oYW1idXJnZXIgaWNidG5cIiBhcmlhLWxhYmVsPVwiTWVudVwiIG9uQ2xpY2s9eygpID0+IHNldERyYXdlck9wZW4odHJ1ZSl9PlxuICAgICAgICA8SWNvbiBuYW1lPVwibGlzdFwiIC8+XG4gICAgICA8L2J1dHRvbj5cbiAgICAgIDxMaW5rIGhyZWY9XCIvXCIgY2xhc3NOYW1lPVwiZ3JvdmUtYnJhbmRcIj5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGlsZVwiIHN0eWxlPXt7IGJhY2tncm91bmQ6ICd2YXIoLS1ncmFkKScgfX0gLz5cbiAgICAgICAge3NpdGVUaXRsZX1cbiAgICAgIDwvTGluaz5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JvdmUtbmF2X19saW5rc1wiPlxuICAgICAgICB7bmF2SXRlbXMubWFwKChuKSA9PiAoXG4gICAgICAgICAgPExpbmsga2V5PXtuLmtleX0gaHJlZj17bi5ocmVmfSBkYXRhLWN1cj17bi5rZXkgPT09IGVudHJ5S2V5ID8gJzEnIDogJzAnfT5cbiAgICAgICAgICAgIHtuLmxhYmVsfVxuICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgKSl9XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JvdmUtbmF2X19jbHVzdGVyXCI+XG4gICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiaWNidG5cIiBhcmlhLWxhYmVsPVwiU2VhcmNoXCIgb25DbGljaz17KCkgPT4gc2V0U2VhcmNoT3Blbih0cnVlKX0+XG4gICAgICAgICAgPEljb24gbmFtZT1cInNlYXJjaFwiIC8+XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgICB7d3JpdGFibGUgJiYgKFxuICAgICAgICAgIDw+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImljYnRuXCJcbiAgICAgICAgICAgICAgYXJpYS1sYWJlbD17ZWRpdEJ1c3kgPyAnT3BlbmluZyBlZGl0b3LigKYnIDogJ05ldyBlbnRyeSd9XG4gICAgICAgICAgICAgIHRpdGxlPXtlZGl0SGludH1cbiAgICAgICAgICAgICAgZGF0YS1idXN5PXtlZGl0QnVzeSA/ICcxJyA6ICcwJ31cbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e2VkaXRCdXN5fVxuICAgICAgICAgICAgICBvbkNsaWNrPXtuZXdFbnRyeX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPEljb24gbmFtZT1cInBsdXNcIiAvPlxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICB7ZWRpdFJlZnVzZWQgJiYgKFxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJncm92ZS1lZGl0LXJlZnVzZWRcIiByb2xlPVwic3RhdHVzXCIgdGl0bGU9e0VESVRfUkVGVVNFRF9OT1RJQ0V9PlxuICAgICAgICAgICAgICAgIHtFRElUX1JFRlVTRURfTk9USUNFfVxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvPlxuICAgICAgICApfVxuICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImljYnRuXCIgYXJpYS1sYWJlbD1cIkFzayBHcm92ZVwiIG9uQ2xpY2s9e2Fza0dyb3ZlfT5cbiAgICAgICAgICA8SWNvbiBuYW1lPVwibWVzc2FnZVwiIC8+XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyb3ZlLW5hdl9fbW9yZVwiPlxuICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiaWNidG4gZ3JvdmUtdGhlbWUtY29udHJvbFwiIHRpdGxlPVwiVGhlbWVcIiBhcmlhLWV4cGFuZGVkPXttZW51T3Blbn0gYXJpYS1oYXNwb3B1cD1cIm1lbnVcIiBvbkNsaWNrPXsoKSA9PiBzZXRNZW51T3BlbigobykgPT4gIW8pfT5cbiAgICAgICAgICAgIOKYgFxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIHttZW51T3BlbiA/IChcbiAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3RtX19zY3JpbVwiIG9uQ2xpY2s9eygpID0+IHNldE1lbnVPcGVuKGZhbHNlKX0gLz5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncm92ZS10aGVtZS1tZW51XCIgcm9sZT1cIm1lbnVcIiBhcmlhLWxhYmVsPVwiVGhlbWVcIiByZWY9e21lbnVSZWZ9IHRhYkluZGV4PXstMX0gb25LZXlEb3duPXtvbk1lbnVLZXlEb3dufT5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImd0bV9faFwiPlRoZW1lPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJndG1fX2xpc3RcIj5cbiAgICAgICAgICAgICAgICAgIHtUSEVNRVMubWFwKCh0KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICBrZXk9e3QuaWR9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ3RtX19yb3dcIlxuICAgICAgICAgICAgICAgICAgICAgIGRhdGEtY3VyPXt0aGVtZSA9PT0gdC5pZCA/ICcxJyA6ICcwJ31cbiAgICAgICAgICAgICAgICAgICAgICByb2xlPVwibWVudWl0ZW1yYWRpb1wiXG4gICAgICAgICAgICAgICAgICAgICAgYXJpYS1jaGVja2VkPXt0aGVtZSA9PT0gdC5pZH1cbiAgICAgICAgICAgICAgICAgICAgICB0YWJJbmRleD17LTF9XG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0VGhlbWUodC5pZCl9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJndG1fX3N3XCIgc3R5bGU9e3sgYmFja2dyb3VuZDogdC5zd2F0Y2ggfX0gLz5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJndG1fX25hbWVcIj57dC5sYWJlbH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAge3RoZW1lID09PSB0LmlkID8gPHNwYW4gY2xhc3NOYW1lPVwiZ3RtX19ja1wiPjxJY29uIG5hbWU9XCJjaGVja1wiIC8+PC9zcGFuPiA6IG51bGx9XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgey8qIFIzLTMwODogdGhlIGFwcGVhcmFuY2UgY29udHJvbCBpcyBvZmZlcmVkIGZvciBFVkVSWSB0aGVtZSDigJQgZWFjaFxuICAgICAgICAgICAgICAgICAgICBjYXRhbG9ndWUgZW50cnkgc2hpcHMgYm90aCBwb2xhcml0aWVzLCBzbyBnYXRpbmcgaXQgb25cbiAgICAgICAgICAgICAgICAgICAgYGRlZmF1bHRgIHdvdWxkIGJlIHNpbmdsZS1wb2xhcml0eSBieSBjb25zdHJ1Y3Rpb24gYWdhaW4uICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3RtX19hcHBlYXJhbmNlXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImd0bV9fc3ViXCI+QXBwZWFyYW5jZTwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJndG1fX3NlZ1wiPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGRhdGEtb249eyFsaWdodCA/ICcxJyA6ICcwJ30gcm9sZT1cIm1lbnVpdGVtcmFkaW9cIiBhcmlhLWNoZWNrZWQ9eyFsaWdodH0gdGFiSW5kZXg9ey0xfSBvbkNsaWNrPXsoKSA9PiBzZXRMaWdodChmYWxzZSl9PlxuICAgICAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJtb29uXCIgLz4gRGFya1xuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBkYXRhLW9uPXtsaWdodCA/ICcxJyA6ICcwJ30gcm9sZT1cIm1lbnVpdGVtcmFkaW9cIiBhcmlhLWNoZWNrZWQ9e2xpZ2h0fSB0YWJJbmRleD17LTF9IG9uQ2xpY2s9eygpID0+IHNldExpZ2h0KHRydWUpfT5cbiAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwic3VuXCIgLz4gTGlnaHRcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8Lz5cbiAgICAgICAgICApIDogbnVsbH1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L25hdj5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQSxJQUFBQSxJQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxNQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxZQUFBLEdBQUFGLE9BQUE7QUFDQSxJQUFBRyx1QkFBQSxHQUFBSCxPQUFBO0FBQ0EsSUFBQUksT0FBQSxHQUFBSixPQUFBO0FBQ0EsSUFBQUssS0FBQSxHQUFBQyxzQkFBQSxDQUFBTixPQUFBO0FBQTBCLElBQUFPLFdBQUEsR0FBQVAsT0FBQTtBQUFBLElBQUFRLEVBQUEsR0FBQUMsWUFBQSxJQUUxQjtBQUNBO0FBQ0E7QUFBQSxTQUFBSCx1QkFBQUksQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQUNlLFNBQVNHLFFBQVFBLENBQUEsRUFBRztFQUFBTCxFQUFBO0VBQ2pDLE1BQU07SUFDSk0sU0FBUztJQUNUQyxRQUFRO0lBQ1JDLFFBQVE7SUFDUkMsUUFBUTtJQUNSQyxVQUFVO0lBQ1ZDLFFBQVE7SUFDUkMsV0FBVztJQUNYQyxRQUFRO0lBQ1JDLEtBQUs7SUFDTEMsUUFBUTtJQUNSQyxLQUFLO0lBQ0xDLFFBQVE7SUFDUkMsUUFBUTtJQUNSQyxXQUFXO0lBQ1hDLGFBQWE7SUFDYkM7RUFDRixDQUFDLEdBQUcsSUFBQUMsZUFBUSxFQUFDLENBQUM7RUFFZCxNQUFNQyxRQUFRLEdBQUdBLENBQUEsS0FBTTtJQUNyQixNQUFNQyxFQUFFLEdBQUlDLFFBQVEsQ0FBQ0MsYUFBYSxDQUFDLGdCQUFnQixDQUFDLElBQUlELFFBQVEsQ0FBQ0MsYUFBYSxDQUFDLGdCQUFnQixDQUF3QjtJQUN2SEYsRUFBRSxFQUFFRyxLQUFLLENBQUMsQ0FBQztFQUNiLENBQUM7RUFDRDtFQUNBO0VBQ0E7RUFDQSxNQUFNQyxRQUFRLEdBQUdBLENBQUEsS0FBTWxCLFVBQVUsQ0FBQyxHQUFHLElBQUFtQiwyQkFBYyxFQUFDLENBQUMsY0FBYyxDQUFDOztFQUVwRTtFQUNBO0VBQ0E7RUFDQSxNQUFNQyxPQUFPLEdBQUcsSUFBQUMsOENBQXNCLEVBQUNiLFFBQVEsRUFBRSxNQUFNQyxXQUFXLENBQUMsS0FBSyxDQUFDLEVBQUU7SUFBRWEsT0FBTyxFQUFFO0VBQU0sQ0FBQyxDQUFDO0VBQzlGLE1BQU1DLGFBQWEsR0FBSS9CLENBQXNCLElBQUs7SUFDaEQsTUFBTWdDLEtBQUssR0FBRyxDQUFDLElBQUlKLE9BQU8sQ0FBQ0ssT0FBTyxFQUFFQyxnQkFBZ0IsQ0FBYyxvQkFBb0IsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDO0lBQy9GLElBQUksQ0FBQ0YsS0FBSyxDQUFDRyxNQUFNLEVBQUU7SUFDbkIsTUFBTUMsR0FBRyxHQUFHSixLQUFLLENBQUNLLE9BQU8sQ0FBQ2QsUUFBUSxDQUFDZSxhQUE0QixDQUFDO0lBQ2hFLE1BQU1DLElBQUksR0FBSUMsQ0FBUyxJQUFLO01BQzFCeEMsQ0FBQyxDQUFDeUMsY0FBYyxDQUFDLENBQUM7TUFDbEIsTUFBTUMsSUFBSSxHQUFHVixLQUFLLENBQUMsQ0FBQ1EsQ0FBQyxHQUFHUixLQUFLLENBQUNHLE1BQU0sSUFBSUgsS0FBSyxDQUFDRyxNQUFNLENBQUM7TUFDckRPLElBQUksQ0FBQ2pCLEtBQUssQ0FBQyxDQUFDO01BQ1o7TUFDQTtNQUNBLElBQUlpQixJQUFJLENBQUNDLFlBQVksQ0FBQyxNQUFNLENBQUMsS0FBSyxlQUFlLElBQUlELElBQUksQ0FBQ0MsWUFBWSxDQUFDLGNBQWMsQ0FBQyxLQUFLLE1BQU0sRUFBRUQsSUFBSSxDQUFDRSxLQUFLLENBQUMsQ0FBQztJQUNqSCxDQUFDO0lBQ0QsSUFBSTVDLENBQUMsQ0FBQzZDLEdBQUcsS0FBSyxXQUFXLEVBQUVOLElBQUksQ0FBQ0gsR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDLEtBQ3BDLElBQUlwQyxDQUFDLENBQUM2QyxHQUFHLEtBQUssU0FBUyxFQUFFTixJQUFJLENBQUNILEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUN2QyxJQUFJcEMsQ0FBQyxDQUFDNkMsR0FBRyxLQUFLLE1BQU0sRUFBRU4sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQzlCLElBQUl2QyxDQUFDLENBQUM2QyxHQUFHLEtBQUssS0FBSyxFQUFFTixJQUFJLENBQUNQLEtBQUssQ0FBQ0csTUFBTSxHQUFHLENBQUMsQ0FBQztFQUNsRCxDQUFDO0VBRUQsb0JBQ0UsSUFBQXRDLFdBQUEsQ0FBQWlELElBQUE7SUFBS0MsU0FBUyxFQUFDLFdBQVc7SUFBQUMsUUFBQSxnQkFDeEIsSUFBQW5ELFdBQUEsQ0FBQW9ELEdBQUE7TUFBUUYsU0FBUyxFQUFDLHVCQUF1QjtNQUFDLGNBQVcsTUFBTTtNQUFDRyxPQUFPLEVBQUVBLENBQUEsS0FBTS9CLGFBQWEsQ0FBQyxJQUFJLENBQUU7TUFBQTZCLFFBQUEsZUFDN0YsSUFBQW5ELFdBQUEsQ0FBQW9ELEdBQUEsRUFBQ3RELEtBQUEsQ0FBQU8sT0FBSTtRQUFDaUQsSUFBSSxFQUFDO01BQU0sQ0FBRTtJQUFDLENBQ2QsQ0FBQyxlQUNULElBQUF0RCxXQUFBLENBQUFpRCxJQUFBLEVBQUN6RCxJQUFBLENBQUErRCxJQUFJO01BQUNDLElBQUksRUFBQyxHQUFHO01BQUNOLFNBQVMsRUFBQyxhQUFhO01BQUFDLFFBQUEsZ0JBQ3BDLElBQUFuRCxXQUFBLENBQUFvRCxHQUFBO1FBQU1GLFNBQVMsRUFBQyxNQUFNO1FBQUNPLEtBQUssRUFBRTtVQUFFQyxVQUFVLEVBQUU7UUFBYztNQUFFLENBQUUsQ0FBQyxFQUM5RG5ELFNBQVM7SUFBQSxDQUNOLENBQUMsZUFDUCxJQUFBUCxXQUFBLENBQUFvRCxHQUFBO01BQUtGLFNBQVMsRUFBQyxrQkFBa0I7TUFBQUMsUUFBQSxFQUM5QjNDLFFBQVEsQ0FBQ21ELEdBQUcsQ0FBRUMsQ0FBQyxpQkFDZCxJQUFBNUQsV0FBQSxDQUFBb0QsR0FBQSxFQUFDNUQsSUFBQSxDQUFBK0QsSUFBSTtRQUFhQyxJQUFJLEVBQUVJLENBQUMsQ0FBQ0osSUFBSztRQUFDLFlBQVVJLENBQUMsQ0FBQ1osR0FBRyxLQUFLdkMsUUFBUSxHQUFHLEdBQUcsR0FBRyxHQUFJO1FBQUEwQyxRQUFBLEVBQ3RFUyxDQUFDLENBQUNDO01BQUssR0FEQ0QsQ0FBQyxDQUFDWixHQUVQLENBQ1A7SUFBQyxDQUNDLENBQUMsZUFDTixJQUFBaEQsV0FBQSxDQUFBaUQsSUFBQTtNQUFLQyxTQUFTLEVBQUMsb0JBQW9CO01BQUFDLFFBQUEsZ0JBQ2pDLElBQUFuRCxXQUFBLENBQUFvRCxHQUFBO1FBQVFGLFNBQVMsRUFBQyxPQUFPO1FBQUMsY0FBVyxRQUFRO1FBQUNHLE9BQU8sRUFBRUEsQ0FBQSxLQUFNaEMsYUFBYSxDQUFDLElBQUksQ0FBRTtRQUFBOEIsUUFBQSxlQUMvRSxJQUFBbkQsV0FBQSxDQUFBb0QsR0FBQSxFQUFDdEQsS0FBQSxDQUFBTyxPQUFJO1VBQUNpRCxJQUFJLEVBQUM7UUFBUSxDQUFFO01BQUMsQ0FDaEIsQ0FBQyxFQUNSNUMsUUFBUSxpQkFDUCxJQUFBVixXQUFBLENBQUFpRCxJQUFBLEVBQUFqRCxXQUFBLENBQUE4RCxRQUFBO1FBQUFYLFFBQUEsZ0JBQ0UsSUFBQW5ELFdBQUEsQ0FBQW9ELEdBQUE7VUFDRUYsU0FBUyxFQUFDLE9BQU87VUFDakIsY0FBWXRDLFFBQVEsR0FBRyxpQkFBaUIsR0FBRyxXQUFZO1VBQ3ZEbUQsS0FBSyxFQUFFakQsUUFBUztVQUNoQixhQUFXRixRQUFRLEdBQUcsR0FBRyxHQUFHLEdBQUk7VUFDaENvRCxRQUFRLEVBQUVwRCxRQUFTO1VBQ25CeUMsT0FBTyxFQUFFeEIsUUFBUztVQUFBc0IsUUFBQSxlQUVsQixJQUFBbkQsV0FBQSxDQUFBb0QsR0FBQSxFQUFDdEQsS0FBQSxDQUFBTyxPQUFJO1lBQUNpRCxJQUFJLEVBQUM7VUFBTSxDQUFFO1FBQUMsQ0FDZCxDQUFDLEVBQ1J6QyxXQUFXLGlCQUNWLElBQUFiLFdBQUEsQ0FBQW9ELEdBQUE7VUFBTUYsU0FBUyxFQUFDLG9CQUFvQjtVQUFDZSxJQUFJLEVBQUMsUUFBUTtVQUFDRixLQUFLLEVBQUVHLDBCQUFvQjtVQUFBZixRQUFBLEVBQzNFZTtRQUFtQixDQUNoQixDQUNQO01BQUEsQ0FDRCxDQUNILGVBQ0QsSUFBQWxFLFdBQUEsQ0FBQW9ELEdBQUE7UUFBUUYsU0FBUyxFQUFDLE9BQU87UUFBQyxjQUFXLFdBQVc7UUFBQ0csT0FBTyxFQUFFN0IsUUFBUztRQUFBMkIsUUFBQSxlQUNqRSxJQUFBbkQsV0FBQSxDQUFBb0QsR0FBQSxFQUFDdEQsS0FBQSxDQUFBTyxPQUFJO1VBQUNpRCxJQUFJLEVBQUM7UUFBUyxDQUFFO01BQUMsQ0FDakIsQ0FBQyxlQUNULElBQUF0RCxXQUFBLENBQUFpRCxJQUFBO1FBQUtDLFNBQVMsRUFBQyxpQkFBaUI7UUFBQUMsUUFBQSxnQkFDOUIsSUFBQW5ELFdBQUEsQ0FBQW9ELEdBQUE7VUFBUUYsU0FBUyxFQUFDLDJCQUEyQjtVQUFDYSxLQUFLLEVBQUMsT0FBTztVQUFDLGlCQUFlNUMsUUFBUztVQUFDLGlCQUFjLE1BQU07VUFBQ2tDLE9BQU8sRUFBRUEsQ0FBQSxLQUFNakMsV0FBVyxDQUFFK0MsQ0FBQyxJQUFLLENBQUNBLENBQUMsQ0FBRTtVQUFBaEIsUUFBQSxFQUFDO1FBRWpKLENBQVEsQ0FBQyxFQUNSaEMsUUFBUSxnQkFDUCxJQUFBbkIsV0FBQSxDQUFBaUQsSUFBQSxFQUFBakQsV0FBQSxDQUFBOEQsUUFBQTtVQUFBWCxRQUFBLGdCQUNFLElBQUFuRCxXQUFBLENBQUFvRCxHQUFBO1lBQUtGLFNBQVMsRUFBQyxZQUFZO1lBQUNHLE9BQU8sRUFBRUEsQ0FBQSxLQUFNakMsV0FBVyxDQUFDLEtBQUs7VUFBRSxDQUFFLENBQUMsZUFDakUsSUFBQXBCLFdBQUEsQ0FBQWlELElBQUE7WUFBS0MsU0FBUyxFQUFDLGtCQUFrQjtZQUFDZSxJQUFJLEVBQUMsTUFBTTtZQUFDLGNBQVcsT0FBTztZQUFDRyxHQUFHLEVBQUVyQyxPQUFRO1lBQUNzQyxRQUFRLEVBQUUsQ0FBQyxDQUFFO1lBQUNDLFNBQVMsRUFBRXBDLGFBQWM7WUFBQWlCLFFBQUEsZ0JBQ3BILElBQUFuRCxXQUFBLENBQUFvRCxHQUFBO2NBQUtGLFNBQVMsRUFBQyxRQUFRO2NBQUFDLFFBQUEsRUFBQztZQUFLLENBQUssQ0FBQyxlQUNuQyxJQUFBbkQsV0FBQSxDQUFBb0QsR0FBQTtjQUFLRixTQUFTLEVBQUMsV0FBVztjQUFBQyxRQUFBLEVBQ3ZCb0IsY0FBTSxDQUFDWixHQUFHLENBQUVhLENBQUMsaUJBQ1osSUFBQXhFLFdBQUEsQ0FBQWlELElBQUE7Z0JBRUVDLFNBQVMsRUFBQyxVQUFVO2dCQUNwQixZQUFVbkMsS0FBSyxLQUFLeUQsQ0FBQyxDQUFDQyxFQUFFLEdBQUcsR0FBRyxHQUFHLEdBQUk7Z0JBQ3JDUixJQUFJLEVBQUMsZUFBZTtnQkFDcEIsZ0JBQWNsRCxLQUFLLEtBQUt5RCxDQUFDLENBQUNDLEVBQUc7Z0JBQzdCSixRQUFRLEVBQUUsQ0FBQyxDQUFFO2dCQUNiaEIsT0FBTyxFQUFFQSxDQUFBLEtBQU1yQyxRQUFRLENBQUN3RCxDQUFDLENBQUNDLEVBQUUsQ0FBRTtnQkFBQXRCLFFBQUEsZ0JBRTlCLElBQUFuRCxXQUFBLENBQUFvRCxHQUFBO2tCQUFNRixTQUFTLEVBQUMsU0FBUztrQkFBQ08sS0FBSyxFQUFFO29CQUFFQyxVQUFVLEVBQUVjLENBQUMsQ0FBQ0U7a0JBQU87Z0JBQUUsQ0FBRSxDQUFDLGVBQzdELElBQUExRSxXQUFBLENBQUFvRCxHQUFBO2tCQUFNRixTQUFTLEVBQUMsV0FBVztrQkFBQUMsUUFBQSxFQUFFcUIsQ0FBQyxDQUFDWDtnQkFBSyxDQUFPLENBQUMsRUFDM0M5QyxLQUFLLEtBQUt5RCxDQUFDLENBQUNDLEVBQUUsZ0JBQUcsSUFBQXpFLFdBQUEsQ0FBQW9ELEdBQUE7a0JBQU1GLFNBQVMsRUFBQyxTQUFTO2tCQUFBQyxRQUFBLGVBQUMsSUFBQW5ELFdBQUEsQ0FBQW9ELEdBQUEsRUFBQ3RELEtBQUEsQ0FBQU8sT0FBSTtvQkFBQ2lELElBQUksRUFBQztrQkFBTyxDQUFFO2dCQUFDLENBQU0sQ0FBQyxHQUFHLElBQUk7Y0FBQSxHQVYxRWtCLENBQUMsQ0FBQ0MsRUFXRCxDQUNUO1lBQUMsQ0FDQyxDQUFDLGVBSU4sSUFBQXpFLFdBQUEsQ0FBQWlELElBQUE7Y0FBS0MsU0FBUyxFQUFDLGlCQUFpQjtjQUFBQyxRQUFBLGdCQUM5QixJQUFBbkQsV0FBQSxDQUFBb0QsR0FBQTtnQkFBS0YsU0FBUyxFQUFDLFVBQVU7Z0JBQUFDLFFBQUEsRUFBQztjQUFVLENBQUssQ0FBQyxlQUMxQyxJQUFBbkQsV0FBQSxDQUFBaUQsSUFBQTtnQkFBS0MsU0FBUyxFQUFDLFVBQVU7Z0JBQUFDLFFBQUEsZ0JBQ3ZCLElBQUFuRCxXQUFBLENBQUFpRCxJQUFBO2tCQUFRLFdBQVMsQ0FBQ2hDLEtBQUssR0FBRyxHQUFHLEdBQUcsR0FBSTtrQkFBQ2dELElBQUksRUFBQyxlQUFlO2tCQUFDLGdCQUFjLENBQUNoRCxLQUFNO2tCQUFDb0QsUUFBUSxFQUFFLENBQUMsQ0FBRTtrQkFBQ2hCLE9BQU8sRUFBRUEsQ0FBQSxLQUFNbkMsUUFBUSxDQUFDLEtBQUssQ0FBRTtrQkFBQWlDLFFBQUEsZ0JBQzNILElBQUFuRCxXQUFBLENBQUFvRCxHQUFBLEVBQUN0RCxLQUFBLENBQUFPLE9BQUk7b0JBQUNpRCxJQUFJLEVBQUM7a0JBQU0sQ0FBRSxDQUFDLFNBQ3RCO2dCQUFBLENBQVEsQ0FBQyxlQUNULElBQUF0RCxXQUFBLENBQUFpRCxJQUFBO2tCQUFRLFdBQVNoQyxLQUFLLEdBQUcsR0FBRyxHQUFHLEdBQUk7a0JBQUNnRCxJQUFJLEVBQUMsZUFBZTtrQkFBQyxnQkFBY2hELEtBQU07a0JBQUNvRCxRQUFRLEVBQUUsQ0FBQyxDQUFFO2tCQUFDaEIsT0FBTyxFQUFFQSxDQUFBLEtBQU1uQyxRQUFRLENBQUMsSUFBSSxDQUFFO2tCQUFBaUMsUUFBQSxnQkFDeEgsSUFBQW5ELFdBQUEsQ0FBQW9ELEdBQUEsRUFBQ3RELEtBQUEsQ0FBQU8sT0FBSTtvQkFBQ2lELElBQUksRUFBQztrQkFBSyxDQUFFLENBQUMsVUFDckI7Z0JBQUEsQ0FBUSxDQUFDO2NBQUEsQ0FDTixDQUFDO1lBQUEsQ0FDSCxDQUFDO1VBQUEsQ0FDSCxDQUFDO1FBQUEsQ0FDTixDQUFDLEdBQ0QsSUFBSTtNQUFBLENBQ0wsQ0FBQztJQUFBLENBQ0gsQ0FBQztFQUFBLENBQ0gsQ0FBQztBQUVWO0FBQUNyRCxFQUFBLENBNUl1QkssUUFBUTtFQUFBLFFBa0IxQmlCLGVBQVEsRUFjSVMsOENBQXNCO0FBQUE7QUFBQTJDLEVBQUEsR0FoQ2hCckUsUUFBUTtBQUFBLElBQUFxRSxFQUFBO0FBQUFDLFlBQUEsQ0FBQUQsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}