var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Infobox;
var _jsxRuntime = require("react/jsx-runtime");
// Import-free engine component: a sidebar fact panel. Authors put a markdown
// list of `- Key: value` lines inside; it renders as the panel body.
function Infobox({
  title,
  cover,
  children
}) {
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("aside", {
    className: "grove-infobox",
    children: [title ? /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "grove-infobox__h",
      children: title
    }) : null, cover ? /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "grove-infobox__cover"
    }) : null, /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "grove-infobox__body",
      children: children
    })]
  });
}
_c = Infobox;
var _c;
$RefreshReg$(_c, "Infobox");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJJbmZvYm94IiwidGl0bGUiLCJjb3ZlciIsImNoaWxkcmVuIiwiX2pzeFJ1bnRpbWUiLCJqc3hzIiwiY2xhc3NOYW1lIiwianN4IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJJbmZvYm94LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IFJlYWN0Tm9kZSB9IGZyb20gJ3JlYWN0JztcblxuaW50ZXJmYWNlIFByb3BzIHtcbiAgdGl0bGU/OiBzdHJpbmc7XG4gIGNvdmVyPzogYm9vbGVhbjtcbiAgY2hpbGRyZW4/OiBSZWFjdE5vZGU7XG59XG5cbi8vIEltcG9ydC1mcmVlIGVuZ2luZSBjb21wb25lbnQ6IGEgc2lkZWJhciBmYWN0IHBhbmVsLiBBdXRob3JzIHB1dCBhIG1hcmtkb3duXG4vLyBsaXN0IG9mIGAtIEtleTogdmFsdWVgIGxpbmVzIGluc2lkZTsgaXQgcmVuZGVycyBhcyB0aGUgcGFuZWwgYm9keS5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEluZm9ib3goeyB0aXRsZSwgY292ZXIsIGNoaWxkcmVuIH06IFByb3BzKSB7XG4gIHJldHVybiAoXG4gICAgPGFzaWRlIGNsYXNzTmFtZT1cImdyb3ZlLWluZm9ib3hcIj5cbiAgICAgIHt0aXRsZSA/IDxkaXYgY2xhc3NOYW1lPVwiZ3JvdmUtaW5mb2JveF9faFwiPnt0aXRsZX08L2Rpdj4gOiBudWxsfVxuICAgICAge2NvdmVyID8gPGRpdiBjbGFzc05hbWU9XCJncm92ZS1pbmZvYm94X19jb3ZlclwiIC8+IDogbnVsbH1cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JvdmUtaW5mb2JveF9fYm9keVwiPntjaGlsZHJlbn08L2Rpdj5cbiAgICA8L2FzaWRlPlxuICApO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBUUE7QUFDQTtBQUNlLFNBQVNBLE9BQU9BLENBQUM7RUFBRUMsS0FBSztFQUFFQyxLQUFLO0VBQUVDO0FBQWdCLENBQUMsRUFBRTtFQUNqRSxvQkFDRSxJQUFBQyxXQUFBLENBQUFDLElBQUE7SUFBT0MsU0FBUyxFQUFDLGVBQWU7SUFBQUgsUUFBQSxHQUM3QkYsS0FBSyxnQkFBRyxJQUFBRyxXQUFBLENBQUFHLEdBQUE7TUFBS0QsU0FBUyxFQUFDLGtCQUFrQjtNQUFBSCxRQUFBLEVBQUVGO0lBQUssQ0FBTSxDQUFDLEdBQUcsSUFBSSxFQUM5REMsS0FBSyxnQkFBRyxJQUFBRSxXQUFBLENBQUFHLEdBQUE7TUFBS0QsU0FBUyxFQUFDO0lBQXNCLENBQUUsQ0FBQyxHQUFHLElBQUksZUFDeEQsSUFBQUYsV0FBQSxDQUFBRyxHQUFBO01BQUtELFNBQVMsRUFBQyxxQkFBcUI7TUFBQUgsUUFBQSxFQUFFQTtJQUFRLENBQU0sQ0FBQztFQUFBLENBQ2hELENBQUM7QUFFWjtBQUFDSyxFQUFBLEdBUnVCUixPQUFPO0FBQUEsSUFBQVEsRUFBQTtBQUFBQyxZQUFBLENBQUFELEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}