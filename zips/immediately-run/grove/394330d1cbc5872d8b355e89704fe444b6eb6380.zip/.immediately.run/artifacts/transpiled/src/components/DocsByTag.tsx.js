var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = DocsByTag;
var _DocList = _interopRequireDefault(require("./DocList"));
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// `<DocsByTag tag>` — the body of a tag page: a `#tag` header + the filtered feed.
function DocsByTag({
  tag,
  shape = 'feed'
}) {
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "grove-doclist__head",
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)("h2", {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
          className: "grove-tag",
          "data-active": "1",
          children: ["#", tag]
        })
      })
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_DocList.default, {
      shape: shape,
      tag: tag
    })]
  });
}
_c = DocsByTag;
var _c;
$RefreshReg$(_c, "DocsByTag");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfRG9jTGlzdCIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJlIiwiX19lc01vZHVsZSIsImRlZmF1bHQiLCJEb2NzQnlUYWciLCJ0YWciLCJzaGFwZSIsImpzeHMiLCJjaGlsZHJlbiIsImpzeCIsImNsYXNzTmFtZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiRG9jc0J5VGFnLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgRG9jTGlzdCBmcm9tICcuL0RvY0xpc3QnO1xuXG4vLyBgPERvY3NCeVRhZyB0YWc+YCDigJQgdGhlIGJvZHkgb2YgYSB0YWcgcGFnZTogYSBgI3RhZ2AgaGVhZGVyICsgdGhlIGZpbHRlcmVkIGZlZWQuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBEb2NzQnlUYWcoeyB0YWcsIHNoYXBlID0gJ2ZlZWQnIH06IHsgdGFnOiBzdHJpbmc7IHNoYXBlPzogJ2ZlZWQnIHwgJ2dyaWQnIH0pIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncm92ZS1kb2NsaXN0X19oZWFkXCI+XG4gICAgICAgIDxoMj48c3BhbiBjbGFzc05hbWU9XCJncm92ZS10YWdcIiBkYXRhLWFjdGl2ZT1cIjFcIj4je3RhZ308L3NwYW4+PC9oMj5cbiAgICAgIDwvZGl2PlxuICAgICAgPERvY0xpc3Qgc2hhcGU9e3NoYXBlfSB0YWc9e3RhZ30gLz5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQUEsSUFBQUEsUUFBQSxHQUFBQyxzQkFBQSxDQUFBQyxPQUFBO0FBQWdDLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUFBLFNBQUFELHVCQUFBRyxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBRWhDO0FBQ2UsU0FBU0csU0FBU0EsQ0FBQztFQUFFQyxHQUFHO0VBQUVDLEtBQUssR0FBRztBQUFpRCxDQUFDLEVBQUU7RUFDbkcsb0JBQ0UsSUFBQU4sV0FBQSxDQUFBTyxJQUFBO0lBQUFDLFFBQUEsZ0JBQ0UsSUFBQVIsV0FBQSxDQUFBUyxHQUFBO01BQUtDLFNBQVMsRUFBQyxxQkFBcUI7TUFBQUYsUUFBQSxlQUNsQyxJQUFBUixXQUFBLENBQUFTLEdBQUE7UUFBQUQsUUFBQSxlQUFJLElBQUFSLFdBQUEsQ0FBQU8sSUFBQTtVQUFNRyxTQUFTLEVBQUMsV0FBVztVQUFDLGVBQVksR0FBRztVQUFBRixRQUFBLEdBQUMsR0FBQyxFQUFDSCxHQUFHO1FBQUEsQ0FBTztNQUFDLENBQUk7SUFBQyxDQUMvRCxDQUFDLGVBQ04sSUFBQUwsV0FBQSxDQUFBUyxHQUFBLEVBQUNaLFFBQUEsQ0FBQU0sT0FBTztNQUFDRyxLQUFLLEVBQUVBLEtBQU07TUFBQ0QsR0FBRyxFQUFFQTtJQUFJLENBQUUsQ0FBQztFQUFBLENBQ2hDLENBQUM7QUFFVjtBQUFDTSxFQUFBLEdBVHVCUCxTQUFTO0FBQUEsSUFBQU8sRUFBQTtBQUFBQyxZQUFBLENBQUFELEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}