var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Timeline;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.map.js");
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
var _content = require("../lib/content");
var _InlineProse = _interopRequireDefault(require("./InlineProse"));
var _wiki = require("../lib/wiki");
var _EntryImage = _interopRequireDefault(require("./EntryImage"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(),
  _s2 = $RefreshSig$();
/* eslint-disable @typescript-eslint/no-explicit-any */
// One dated entry on the axis: mono date · node · card.
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function Row({
  path
}) {
  _s();
  const m = (0, _sdk.useFileMetadata)(path);
  if (!m) return null;
  const tags = Array.isArray(m.tags) ? m.tags.filter(t => !t.startsWith('ui/')) : [];
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_sdk.Link, {
    href: (0, _content.keyToHref)(path),
    className: "gtl-row",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "gtl-date",
      children: m.date
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "gtl-node"
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "gtl-card",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_EntryImage.default, {
        entryPath: path,
        src: m.cover,
        alt: "",
        className: "gtl-cover",
        degrade: null
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "gtl-title",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_InlineProse.default, {
          text: m.title || path,
          trimPeriod: true
        })
      }), m.description && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "gtl-desc",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_InlineProse.default, {
          text: m.description
        })
      }), tags.length ? /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "gtl-tags",
        children: tags.slice(0, 3).map(t => /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
          className: "grove-tag",
          children: ["#", t]
        }, t))
      }) : null]
    })]
  });
}

// `<Timeline/>` — an agent-added view: every entry with a `date`, laid on a time
// axis newest-first, with a restrained per-row reveal (CSS `gtlin`).
_s(Row, "HCQWmXfXYtrNQZ9MFtiZso5O/l0=", false, function () {
  return [_sdk.useFileMetadata];
});
_c = Row;
function Timeline() {
  _s2();
  const queryFn = (0, _react.useCallback)(fm => Object.keys(fm).filter(p => (0, _content.isContentEntry)(p) && fm[p]?.date && !fm[p]?.view).sort((a, b) => String(fm[b].date).localeCompare(String(fm[a].date))), []);
  const q = (0, _sdk.useMetadataQuery)(queryFn);
  const loaded = Array.isArray(q);
  const paths = (0, _wiki.queryPaths)(q);
  if (loaded && !paths.length) {
    return /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
      className: "grove-search__empty",
      children: "No dated entries yet."
    });
  }
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    className: "grove-timeline",
    children: paths.map(p => /*#__PURE__*/(0, _jsxRuntime.jsx)(Row, {
      path: p
    }, p))
  });
}
_s2(Timeline, "wwx07dpKidh/vhfuCH1U58t3SjM=", false, function () {
  return [_sdk.useMetadataQuery];
});
_c2 = Timeline;
var _c, _c2;
$RefreshReg$(_c, "Row");
$RefreshReg$(_c2, "Timeline");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NkayIsIl9jb250ZW50IiwiX0lubGluZVByb3NlIiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsIl93aWtpIiwiX0VudHJ5SW1hZ2UiLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiX3MyIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiUm93IiwicGF0aCIsIm0iLCJ1c2VGaWxlTWV0YWRhdGEiLCJ0YWdzIiwiQXJyYXkiLCJpc0FycmF5IiwiZmlsdGVyIiwidCIsInN0YXJ0c1dpdGgiLCJqc3hzIiwiTGluayIsImhyZWYiLCJrZXlUb0hyZWYiLCJjbGFzc05hbWUiLCJjaGlsZHJlbiIsImpzeCIsImRhdGUiLCJlbnRyeVBhdGgiLCJzcmMiLCJjb3ZlciIsImFsdCIsImRlZ3JhZGUiLCJ0ZXh0IiwidGl0bGUiLCJ0cmltUGVyaW9kIiwiZGVzY3JpcHRpb24iLCJsZW5ndGgiLCJzbGljZSIsIm1hcCIsIl9jIiwiVGltZWxpbmUiLCJxdWVyeUZuIiwidXNlQ2FsbGJhY2siLCJmbSIsIk9iamVjdCIsImtleXMiLCJwIiwiaXNDb250ZW50RW50cnkiLCJ2aWV3Iiwic29ydCIsImEiLCJiIiwiU3RyaW5nIiwibG9jYWxlQ29tcGFyZSIsInEiLCJ1c2VNZXRhZGF0YVF1ZXJ5IiwibG9hZGVkIiwicGF0aHMiLCJxdWVyeVBhdGhzIiwiX2MyIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiVGltZWxpbmUudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHBsaWNpdC1hbnkgKi9cbmltcG9ydCB7IHVzZUNhbGxiYWNrIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgTGluaywgdXNlRmlsZU1ldGFkYXRhLCB1c2VNZXRhZGF0YVF1ZXJ5IH0gZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9zZGsnO1xuaW1wb3J0IHsgaXNDb250ZW50RW50cnksIGtleVRvSHJlZiB9IGZyb20gJy4uL2xpYi9jb250ZW50JztcbmltcG9ydCBJbmxpbmVQcm9zZSBmcm9tICcuL0lubGluZVByb3NlJztcbmltcG9ydCB7IHF1ZXJ5UGF0aHMgfSBmcm9tICcuLi9saWIvd2lraSc7XG5pbXBvcnQgRW50cnlJbWFnZSBmcm9tICcuL0VudHJ5SW1hZ2UnO1xuXG4vLyBPbmUgZGF0ZWQgZW50cnkgb24gdGhlIGF4aXM6IG1vbm8gZGF0ZSDCtyBub2RlIMK3IGNhcmQuXG5mdW5jdGlvbiBSb3coeyBwYXRoIH06IHsgcGF0aDogc3RyaW5nIH0pIHtcbiAgY29uc3QgbSA9IHVzZUZpbGVNZXRhZGF0YShwYXRoKSBhcyBhbnk7XG4gIGlmICghbSkgcmV0dXJuIG51bGw7XG4gIGNvbnN0IHRhZ3M6IHN0cmluZ1tdID0gQXJyYXkuaXNBcnJheShtLnRhZ3MpID8gbS50YWdzLmZpbHRlcigodDogc3RyaW5nKSA9PiAhdC5zdGFydHNXaXRoKCd1aS8nKSkgOiBbXTtcbiAgcmV0dXJuIChcbiAgICA8TGluayBocmVmPXtrZXlUb0hyZWYocGF0aCl9IGNsYXNzTmFtZT1cImd0bC1yb3dcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3RsLWRhdGVcIj57bS5kYXRlfTwvZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJndGwtbm9kZVwiIC8+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImd0bC1jYXJkXCI+XG4gICAgICAgIDxFbnRyeUltYWdlIGVudHJ5UGF0aD17cGF0aH0gc3JjPXttLmNvdmVyfSBhbHQ9XCJcIiBjbGFzc05hbWU9XCJndGwtY292ZXJcIiBkZWdyYWRlPXtudWxsfSAvPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImd0bC10aXRsZVwiPjxJbmxpbmVQcm9zZSB0ZXh0PXttLnRpdGxlIHx8IHBhdGh9IHRyaW1QZXJpb2QgLz48L2Rpdj5cbiAgICAgICAge20uZGVzY3JpcHRpb24gJiYgPGRpdiBjbGFzc05hbWU9XCJndGwtZGVzY1wiPjxJbmxpbmVQcm9zZSB0ZXh0PXttLmRlc2NyaXB0aW9ufSAvPjwvZGl2Pn1cbiAgICAgICAge3RhZ3MubGVuZ3RoID8gKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3RsLXRhZ3NcIj5cbiAgICAgICAgICAgIHt0YWdzLnNsaWNlKDAsIDMpLm1hcCgodCkgPT4gKFxuICAgICAgICAgICAgICA8c3BhbiBrZXk9e3R9IGNsYXNzTmFtZT1cImdyb3ZlLXRhZ1wiPiN7dH08L3NwYW4+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKSA6IG51bGx9XG4gICAgICA8L2Rpdj5cbiAgICA8L0xpbms+XG4gICk7XG59XG5cbi8vIGA8VGltZWxpbmUvPmAg4oCUIGFuIGFnZW50LWFkZGVkIHZpZXc6IGV2ZXJ5IGVudHJ5IHdpdGggYSBgZGF0ZWAsIGxhaWQgb24gYSB0aW1lXG4vLyBheGlzIG5ld2VzdC1maXJzdCwgd2l0aCBhIHJlc3RyYWluZWQgcGVyLXJvdyByZXZlYWwgKENTUyBgZ3RsaW5gKS5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFRpbWVsaW5lKCkge1xuICBjb25zdCBxdWVyeUZuID0gdXNlQ2FsbGJhY2soXG4gICAgKGZtOiBSZWNvcmQ8c3RyaW5nLCBhbnk+KSA9PlxuICAgICAgT2JqZWN0LmtleXMoZm0pXG4gICAgICAgIC5maWx0ZXIoKHApID0+IGlzQ29udGVudEVudHJ5KHApICYmIGZtW3BdPy5kYXRlICYmICFmbVtwXT8udmlldylcbiAgICAgICAgLnNvcnQoKGEsIGIpID0+IFN0cmluZyhmbVtiXS5kYXRlKS5sb2NhbGVDb21wYXJlKFN0cmluZyhmbVthXS5kYXRlKSkpLFxuICAgIFtdXG4gICk7XG4gIGNvbnN0IHEgPSB1c2VNZXRhZGF0YVF1ZXJ5KHF1ZXJ5Rm4pO1xuICBjb25zdCBsb2FkZWQgPSBBcnJheS5pc0FycmF5KHEpO1xuICBjb25zdCBwYXRoczogc3RyaW5nW10gPSBxdWVyeVBhdGhzKHEpO1xuXG4gIGlmIChsb2FkZWQgJiYgIXBhdGhzLmxlbmd0aCkge1xuICAgIHJldHVybiA8cCBjbGFzc05hbWU9XCJncm92ZS1zZWFyY2hfX2VtcHR5XCI+Tm8gZGF0ZWQgZW50cmllcyB5ZXQuPC9wPjtcbiAgfVxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JvdmUtdGltZWxpbmVcIj5cbiAgICAgIHtwYXRocy5tYXAoKHApID0+IChcbiAgICAgICAgPFJvdyBrZXk9e3B9IHBhdGg9e3B9IC8+XG4gICAgICApKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQ0EsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsSUFBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsUUFBQSxHQUFBRixPQUFBO0FBQ0EsSUFBQUcsWUFBQSxHQUFBQyxzQkFBQSxDQUFBSixPQUFBO0FBQ0EsSUFBQUssS0FBQSxHQUFBTCxPQUFBO0FBQ0EsSUFBQU0sV0FBQSxHQUFBRixzQkFBQSxDQUFBSixPQUFBO0FBQXNDLElBQUFPLFdBQUEsR0FBQVAsT0FBQTtBQUFBLElBQUFRLEVBQUEsR0FBQUMsWUFBQTtFQUFBQyxHQUFBLEdBQUFELFlBQUE7QUFOdEM7QUFRQTtBQUFBLFNBQUFMLHVCQUFBTyxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBQ0EsU0FBU0csR0FBR0EsQ0FBQztFQUFFQztBQUF1QixDQUFDLEVBQUU7RUFBQVAsRUFBQTtFQUN2QyxNQUFNUSxDQUFDLEdBQUcsSUFBQUMsb0JBQWUsRUFBQ0YsSUFBSSxDQUFRO0VBQ3RDLElBQUksQ0FBQ0MsQ0FBQyxFQUFFLE9BQU8sSUFBSTtFQUNuQixNQUFNRSxJQUFjLEdBQUdDLEtBQUssQ0FBQ0MsT0FBTyxDQUFDSixDQUFDLENBQUNFLElBQUksQ0FBQyxHQUFHRixDQUFDLENBQUNFLElBQUksQ0FBQ0csTUFBTSxDQUFFQyxDQUFTLElBQUssQ0FBQ0EsQ0FBQyxDQUFDQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxFQUFFO0VBQ3RHLG9CQUNFLElBQUFoQixXQUFBLENBQUFpQixJQUFBLEVBQUN2QixJQUFBLENBQUF3QixJQUFJO0lBQUNDLElBQUksRUFBRSxJQUFBQyxrQkFBUyxFQUFDWixJQUFJLENBQUU7SUFBQ2EsU0FBUyxFQUFDLFNBQVM7SUFBQUMsUUFBQSxnQkFDOUMsSUFBQXRCLFdBQUEsQ0FBQXVCLEdBQUE7TUFBS0YsU0FBUyxFQUFDLFVBQVU7TUFBQUMsUUFBQSxFQUFFYixDQUFDLENBQUNlO0lBQUksQ0FBTSxDQUFDLGVBQ3hDLElBQUF4QixXQUFBLENBQUF1QixHQUFBO01BQUtGLFNBQVMsRUFBQztJQUFVLENBQUUsQ0FBQyxlQUM1QixJQUFBckIsV0FBQSxDQUFBaUIsSUFBQTtNQUFLSSxTQUFTLEVBQUMsVUFBVTtNQUFBQyxRQUFBLGdCQUN2QixJQUFBdEIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDeEIsV0FBQSxDQUFBTyxPQUFVO1FBQUNtQixTQUFTLEVBQUVqQixJQUFLO1FBQUNrQixHQUFHLEVBQUVqQixDQUFDLENBQUNrQixLQUFNO1FBQUNDLEdBQUcsRUFBQyxFQUFFO1FBQUNQLFNBQVMsRUFBQyxXQUFXO1FBQUNRLE9BQU8sRUFBRTtNQUFLLENBQUUsQ0FBQyxlQUN6RixJQUFBN0IsV0FBQSxDQUFBdUIsR0FBQTtRQUFLRixTQUFTLEVBQUMsV0FBVztRQUFBQyxRQUFBLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQzNCLFlBQUEsQ0FBQVUsT0FBVztVQUFDd0IsSUFBSSxFQUFFckIsQ0FBQyxDQUFDc0IsS0FBSyxJQUFJdkIsSUFBSztVQUFDd0IsVUFBVTtRQUFBLENBQUU7TUFBQyxDQUFLLENBQUMsRUFDakZ2QixDQUFDLENBQUN3QixXQUFXLGlCQUFJLElBQUFqQyxXQUFBLENBQUF1QixHQUFBO1FBQUtGLFNBQVMsRUFBQyxVQUFVO1FBQUFDLFFBQUEsZUFBQyxJQUFBdEIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDM0IsWUFBQSxDQUFBVSxPQUFXO1VBQUN3QixJQUFJLEVBQUVyQixDQUFDLENBQUN3QjtRQUFZLENBQUU7TUFBQyxDQUFLLENBQUMsRUFDckZ0QixJQUFJLENBQUN1QixNQUFNLGdCQUNWLElBQUFsQyxXQUFBLENBQUF1QixHQUFBO1FBQUtGLFNBQVMsRUFBQyxVQUFVO1FBQUFDLFFBQUEsRUFDdEJYLElBQUksQ0FBQ3dCLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUNDLEdBQUcsQ0FBRXJCLENBQUMsaUJBQ3RCLElBQUFmLFdBQUEsQ0FBQWlCLElBQUE7VUFBY0ksU0FBUyxFQUFDLFdBQVc7VUFBQUMsUUFBQSxHQUFDLEdBQUMsRUFBQ1AsQ0FBQztRQUFBLEdBQTVCQSxDQUFtQyxDQUMvQztNQUFDLENBQ0MsQ0FBQyxHQUNKLElBQUk7SUFBQSxDQUNMLENBQUM7RUFBQSxDQUNGLENBQUM7QUFFWDs7QUFFQTtBQUNBO0FBQUFkLEVBQUEsQ0F6QlNNLEdBQUc7RUFBQSxRQUNBRyxvQkFBZTtBQUFBO0FBQUEyQixFQUFBLEdBRGxCOUIsR0FBRztBQTBCRyxTQUFTK0IsUUFBUUEsQ0FBQSxFQUFHO0VBQUFuQyxHQUFBO0VBQ2pDLE1BQU1vQyxPQUFPLEdBQUcsSUFBQUMsa0JBQVcsRUFDeEJDLEVBQXVCLElBQ3RCQyxNQUFNLENBQUNDLElBQUksQ0FBQ0YsRUFBRSxDQUFDLENBQ1ozQixNQUFNLENBQUU4QixDQUFDLElBQUssSUFBQUMsdUJBQWMsRUFBQ0QsQ0FBQyxDQUFDLElBQUlILEVBQUUsQ0FBQ0csQ0FBQyxDQUFDLEVBQUVwQixJQUFJLElBQUksQ0FBQ2lCLEVBQUUsQ0FBQ0csQ0FBQyxDQUFDLEVBQUVFLElBQUksQ0FBQyxDQUMvREMsSUFBSSxDQUFDLENBQUNDLENBQUMsRUFBRUMsQ0FBQyxLQUFLQyxNQUFNLENBQUNULEVBQUUsQ0FBQ1EsQ0FBQyxDQUFDLENBQUN6QixJQUFJLENBQUMsQ0FBQzJCLGFBQWEsQ0FBQ0QsTUFBTSxDQUFDVCxFQUFFLENBQUNPLENBQUMsQ0FBQyxDQUFDeEIsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUN6RSxFQUNGLENBQUM7RUFDRCxNQUFNNEIsQ0FBQyxHQUFHLElBQUFDLHFCQUFnQixFQUFDZCxPQUFPLENBQUM7RUFDbkMsTUFBTWUsTUFBTSxHQUFHMUMsS0FBSyxDQUFDQyxPQUFPLENBQUN1QyxDQUFDLENBQUM7RUFDL0IsTUFBTUcsS0FBZSxHQUFHLElBQUFDLGdCQUFVLEVBQUNKLENBQUMsQ0FBQztFQUVyQyxJQUFJRSxNQUFNLElBQUksQ0FBQ0MsS0FBSyxDQUFDckIsTUFBTSxFQUFFO0lBQzNCLG9CQUFPLElBQUFsQyxXQUFBLENBQUF1QixHQUFBO01BQUdGLFNBQVMsRUFBQyxxQkFBcUI7TUFBQUMsUUFBQSxFQUFDO0lBQXFCLENBQUcsQ0FBQztFQUNyRTtFQUNBLG9CQUNFLElBQUF0QixXQUFBLENBQUF1QixHQUFBO0lBQUtGLFNBQVMsRUFBQyxnQkFBZ0I7SUFBQUMsUUFBQSxFQUM1QmlDLEtBQUssQ0FBQ25CLEdBQUcsQ0FBRVEsQ0FBQyxpQkFDWCxJQUFBNUMsV0FBQSxDQUFBdUIsR0FBQSxFQUFDaEIsR0FBRztNQUFTQyxJQUFJLEVBQUVvQztJQUFFLEdBQVhBLENBQWEsQ0FDeEI7RUFBQyxDQUNDLENBQUM7QUFFVjtBQUFDekMsR0FBQSxDQXRCdUJtQyxRQUFRO0VBQUEsUUFRcEJlLHFCQUFnQjtBQUFBO0FBQUFJLEdBQUEsR0FSSm5CLFFBQVE7QUFBQSxJQUFBRCxFQUFBLEVBQUFvQixHQUFBO0FBQUFDLFlBQUEsQ0FBQXJCLEVBQUE7QUFBQXFCLFlBQUEsQ0FBQUQsR0FBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}