var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = TableOfContents;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
var _react = require("react");
var _useHeadings = require("../hooks/useHeadings");
var _tocScroll = require("../lib/tocScroll");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$();
/** Breathing room kept between the active entry and the edge it is pulled away from. One
 *  row's worth: an entry flush against the fold reads as "the last one", and the margin is
 *  what tells the reader the list continues. */
const EDGE_MARGIN = 28;

/** How long a manual scroll of the list suppresses the automatic one. Without this the
 *  reader who scrolls the contents to look ahead is yanked back on the next heading the
 *  DOCUMENT passes — the list fighting the hand that moved it. */
const MANUAL_SCROLL_GRACE_MS = 2000;

/**
 * `<TableOfContents/>` — the on-this-page list, which **keeps the current entry in view**.
 *
 * A long entry has a long contents list, and a list taller than its rail scrolls. Without
 * this the reader scrolls into §12 and the contents still shows §1–§9 with nothing
 * highlighted: the one surface whose whole job is "where am I" stops answering exactly
 * when the document is long enough to need it.
 *
 * Three things it deliberately does NOT do:
 *
 * - **It never scrolls the page.** `scrollIntoView()` walks every scrollable ancestor, so
 *   the obvious implementation moves the document too — the reader passes a heading and
 *   the article jumps. This assigns `scrollTop` on its OWN container and nothing else can
 *   move (`lib/tocScroll`).
 * - **It does not scroll when the entry is already visible.** Otherwise the list twitches
 *   on every heading the reader passes.
 * - **It does not fight the reader.** A manual scroll of the list suspends the automatic
 *   one briefly.
 */
function TableOfContents({
  entryKey,
  title = 'On this page',
  className
}) {
  _s();
  const heads = (0, _useHeadings.useHeadings)(entryKey);
  const cur = (0, _useHeadings.useActiveHeading)(heads);
  const listRef = (0, _react.useRef)(null);
  const itemsRef = (0, _react.useRef)(new Map());
  const manualUntilRef = (0, _react.useRef)(0);
  const noteManualScroll = (0, _react.useCallback)(() => {
    manualUntilRef.current = Date.now() + MANUAL_SCROLL_GRACE_MS;
  }, []);
  (0, _react.useEffect)(() => {
    const list = listRef.current;
    const item = cur ? itemsRef.current.get(cur) : undefined;
    if (!list || !item) return;
    if (Date.now() < manualUntilRef.current) return;
    const offset = (0, _tocScroll.scrollOffsetFor)(...(0, _tocScroll.measure)(list, item), {
      margin: EDGE_MARGIN
    });
    if (offset === null) return; // already in view — "when necessary"
    // `scroll()` on the element, never `scrollIntoView()` on the item: only this container
    // may move. Motion is opt-out — a reader who asked the OS for less of it gets a jump.
    const reduced = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;
    list.scrollTo({
      top: offset,
      behavior: reduced ? 'auto' : 'smooth'
    });
  }, [cur]);
  if (!heads.length) return null;
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("nav", {
    ref: listRef,
    className: ['grove-toc', className].filter(Boolean).join(' '),
    "aria-label": title || 'On this page',
    onWheel: noteManualScroll,
    onTouchMove: noteManualScroll,
    children: [title ? /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "grove-toc__h",
      children: title
    }) : null, heads.map(h => /*#__PURE__*/(0, _jsxRuntime.jsx)("a", {
      ref: el => {
        if (el) itemsRef.current.set(h.id, el);else itemsRef.current.delete(h.id);
      },
      href: `#${h.id}`,
      "data-cur": cur === h.id ? '1' : '0',
      "aria-current": cur === h.id ? 'location' : undefined,
      className: h.level === 3 ? 'lvl3' : undefined,
      onClick: e => {
        e.preventDefault();
        // Clicking IS the reader moving the list, so don't also auto-scroll it.
        noteManualScroll();
        document.getElementById(h.id)?.scrollIntoView({
          behavior: 'smooth',
          block: 'start'
        });
      },
      children: h.text
    }, h.id))]
  });
}
_s(TableOfContents, "WOjDKBLjSCNT37Qn/vBYfiiQTj0=", false, function () {
  return [_useHeadings.useHeadings, _useHeadings.useActiveHeading];
});
_c = TableOfContents;
var _c;
$RefreshReg$(_c, "TableOfContents");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3VzZUhlYWRpbmdzIiwiX3RvY1Njcm9sbCIsIl9qc3hSdW50aW1lIiwiX3MiLCIkUmVmcmVzaFNpZyQiLCJFREdFX01BUkdJTiIsIk1BTlVBTF9TQ1JPTExfR1JBQ0VfTVMiLCJUYWJsZU9mQ29udGVudHMiLCJlbnRyeUtleSIsInRpdGxlIiwiY2xhc3NOYW1lIiwiaGVhZHMiLCJ1c2VIZWFkaW5ncyIsImN1ciIsInVzZUFjdGl2ZUhlYWRpbmciLCJsaXN0UmVmIiwidXNlUmVmIiwiaXRlbXNSZWYiLCJNYXAiLCJtYW51YWxVbnRpbFJlZiIsIm5vdGVNYW51YWxTY3JvbGwiLCJ1c2VDYWxsYmFjayIsImN1cnJlbnQiLCJEYXRlIiwibm93IiwidXNlRWZmZWN0IiwibGlzdCIsIml0ZW0iLCJnZXQiLCJ1bmRlZmluZWQiLCJvZmZzZXQiLCJzY3JvbGxPZmZzZXRGb3IiLCJtZWFzdXJlIiwibWFyZ2luIiwicmVkdWNlZCIsIndpbmRvdyIsIm1hdGNoTWVkaWEiLCJtYXRjaGVzIiwic2Nyb2xsVG8iLCJ0b3AiLCJiZWhhdmlvciIsImxlbmd0aCIsImpzeHMiLCJyZWYiLCJmaWx0ZXIiLCJCb29sZWFuIiwiam9pbiIsIm9uV2hlZWwiLCJvblRvdWNoTW92ZSIsImNoaWxkcmVuIiwianN4IiwibWFwIiwiaCIsImVsIiwic2V0IiwiaWQiLCJkZWxldGUiLCJocmVmIiwibGV2ZWwiLCJvbkNsaWNrIiwiZSIsInByZXZlbnREZWZhdWx0IiwiZG9jdW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsInNjcm9sbEludG9WaWV3IiwiYmxvY2siLCJ0ZXh0IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJUYWJsZU9mQ29udGVudHMudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUNhbGxiYWNrLCB1c2VFZmZlY3QsIHVzZVJlZiB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZUhlYWRpbmdzLCB1c2VBY3RpdmVIZWFkaW5nIH0gZnJvbSAnLi4vaG9va3MvdXNlSGVhZGluZ3MnO1xuaW1wb3J0IHsgbWVhc3VyZSwgc2Nyb2xsT2Zmc2V0Rm9yIH0gZnJvbSAnLi4vbGliL3RvY1Njcm9sbCc7XG5cbmludGVyZmFjZSBQcm9wcyB7XG4gIC8qKiBSZS1zY2FuIHdoZW4gdGhlIHJlbmRlcmVkIGVudHJ5IGNoYW5nZXMuICovXG4gIGVudHJ5S2V5Pzogc3RyaW5nO1xuICAvKiogSGVhZGluZyBhYm92ZSB0aGUgbGlzdDsgYG51bGxgL2BcIlwiYCByZW5kZXJzIG5vbmUuICovXG4gIHRpdGxlPzogc3RyaW5nIHwgbnVsbDtcbiAgLyoqIEV4dHJhIGNsYXNzIG9uIHRoZSBgPG5hdj5gIOKAlCBob3cgYDxUb2M+YCBrZWVwcyBpdHMgcmFpbCBzdHlsaW5nLiAqL1xuICBjbGFzc05hbWU/OiBzdHJpbmc7XG59XG5cbi8qKiBCcmVhdGhpbmcgcm9vbSBrZXB0IGJldHdlZW4gdGhlIGFjdGl2ZSBlbnRyeSBhbmQgdGhlIGVkZ2UgaXQgaXMgcHVsbGVkIGF3YXkgZnJvbS4gT25lXG4gKiAgcm93J3Mgd29ydGg6IGFuIGVudHJ5IGZsdXNoIGFnYWluc3QgdGhlIGZvbGQgcmVhZHMgYXMgXCJ0aGUgbGFzdCBvbmVcIiwgYW5kIHRoZSBtYXJnaW4gaXNcbiAqICB3aGF0IHRlbGxzIHRoZSByZWFkZXIgdGhlIGxpc3QgY29udGludWVzLiAqL1xuY29uc3QgRURHRV9NQVJHSU4gPSAyODtcblxuLyoqIEhvdyBsb25nIGEgbWFudWFsIHNjcm9sbCBvZiB0aGUgbGlzdCBzdXBwcmVzc2VzIHRoZSBhdXRvbWF0aWMgb25lLiBXaXRob3V0IHRoaXMgdGhlXG4gKiAgcmVhZGVyIHdobyBzY3JvbGxzIHRoZSBjb250ZW50cyB0byBsb29rIGFoZWFkIGlzIHlhbmtlZCBiYWNrIG9uIHRoZSBuZXh0IGhlYWRpbmcgdGhlXG4gKiAgRE9DVU1FTlQgcGFzc2VzIOKAlCB0aGUgbGlzdCBmaWdodGluZyB0aGUgaGFuZCB0aGF0IG1vdmVkIGl0LiAqL1xuY29uc3QgTUFOVUFMX1NDUk9MTF9HUkFDRV9NUyA9IDIwMDA7XG5cbi8qKlxuICogYDxUYWJsZU9mQ29udGVudHMvPmAg4oCUIHRoZSBvbi10aGlzLXBhZ2UgbGlzdCwgd2hpY2ggKiprZWVwcyB0aGUgY3VycmVudCBlbnRyeSBpbiB2aWV3KiouXG4gKlxuICogQSBsb25nIGVudHJ5IGhhcyBhIGxvbmcgY29udGVudHMgbGlzdCwgYW5kIGEgbGlzdCB0YWxsZXIgdGhhbiBpdHMgcmFpbCBzY3JvbGxzLiBXaXRob3V0XG4gKiB0aGlzIHRoZSByZWFkZXIgc2Nyb2xscyBpbnRvIMKnMTIgYW5kIHRoZSBjb250ZW50cyBzdGlsbCBzaG93cyDCpzHigJPCpzkgd2l0aCBub3RoaW5nXG4gKiBoaWdobGlnaHRlZDogdGhlIG9uZSBzdXJmYWNlIHdob3NlIHdob2xlIGpvYiBpcyBcIndoZXJlIGFtIElcIiBzdG9wcyBhbnN3ZXJpbmcgZXhhY3RseVxuICogd2hlbiB0aGUgZG9jdW1lbnQgaXMgbG9uZyBlbm91Z2ggdG8gbmVlZCBpdC5cbiAqXG4gKiBUaHJlZSB0aGluZ3MgaXQgZGVsaWJlcmF0ZWx5IGRvZXMgTk9UIGRvOlxuICpcbiAqIC0gKipJdCBuZXZlciBzY3JvbGxzIHRoZSBwYWdlLioqIGBzY3JvbGxJbnRvVmlldygpYCB3YWxrcyBldmVyeSBzY3JvbGxhYmxlIGFuY2VzdG9yLCBzb1xuICogICB0aGUgb2J2aW91cyBpbXBsZW1lbnRhdGlvbiBtb3ZlcyB0aGUgZG9jdW1lbnQgdG9vIOKAlCB0aGUgcmVhZGVyIHBhc3NlcyBhIGhlYWRpbmcgYW5kXG4gKiAgIHRoZSBhcnRpY2xlIGp1bXBzLiBUaGlzIGFzc2lnbnMgYHNjcm9sbFRvcGAgb24gaXRzIE9XTiBjb250YWluZXIgYW5kIG5vdGhpbmcgZWxzZSBjYW5cbiAqICAgbW92ZSAoYGxpYi90b2NTY3JvbGxgKS5cbiAqIC0gKipJdCBkb2VzIG5vdCBzY3JvbGwgd2hlbiB0aGUgZW50cnkgaXMgYWxyZWFkeSB2aXNpYmxlLioqIE90aGVyd2lzZSB0aGUgbGlzdCB0d2l0Y2hlc1xuICogICBvbiBldmVyeSBoZWFkaW5nIHRoZSByZWFkZXIgcGFzc2VzLlxuICogLSAqKkl0IGRvZXMgbm90IGZpZ2h0IHRoZSByZWFkZXIuKiogQSBtYW51YWwgc2Nyb2xsIG9mIHRoZSBsaXN0IHN1c3BlbmRzIHRoZSBhdXRvbWF0aWNcbiAqICAgb25lIGJyaWVmbHkuXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFRhYmxlT2ZDb250ZW50cyh7IGVudHJ5S2V5LCB0aXRsZSA9ICdPbiB0aGlzIHBhZ2UnLCBjbGFzc05hbWUgfTogUHJvcHMpIHtcbiAgY29uc3QgaGVhZHMgPSB1c2VIZWFkaW5ncyhlbnRyeUtleSk7XG4gIGNvbnN0IGN1ciA9IHVzZUFjdGl2ZUhlYWRpbmcoaGVhZHMpO1xuICBjb25zdCBsaXN0UmVmID0gdXNlUmVmPEhUTUxFbGVtZW50IHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IGl0ZW1zUmVmID0gdXNlUmVmKG5ldyBNYXA8c3RyaW5nLCBIVE1MQW5jaG9yRWxlbWVudD4oKSk7XG4gIGNvbnN0IG1hbnVhbFVudGlsUmVmID0gdXNlUmVmKDApO1xuXG4gIGNvbnN0IG5vdGVNYW51YWxTY3JvbGwgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgbWFudWFsVW50aWxSZWYuY3VycmVudCA9IERhdGUubm93KCkgKyBNQU5VQUxfU0NST0xMX0dSQUNFX01TO1xuICB9LCBbXSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBsaXN0ID0gbGlzdFJlZi5jdXJyZW50O1xuICAgIGNvbnN0IGl0ZW0gPSBjdXIgPyBpdGVtc1JlZi5jdXJyZW50LmdldChjdXIpIDogdW5kZWZpbmVkO1xuICAgIGlmICghbGlzdCB8fCAhaXRlbSkgcmV0dXJuO1xuICAgIGlmIChEYXRlLm5vdygpIDwgbWFudWFsVW50aWxSZWYuY3VycmVudCkgcmV0dXJuO1xuICAgIGNvbnN0IG9mZnNldCA9IHNjcm9sbE9mZnNldEZvciguLi5tZWFzdXJlKGxpc3QsIGl0ZW0pLCB7IG1hcmdpbjogRURHRV9NQVJHSU4gfSk7XG4gICAgaWYgKG9mZnNldCA9PT0gbnVsbCkgcmV0dXJuOyAvLyBhbHJlYWR5IGluIHZpZXcg4oCUIFwid2hlbiBuZWNlc3NhcnlcIlxuICAgIC8vIGBzY3JvbGwoKWAgb24gdGhlIGVsZW1lbnQsIG5ldmVyIGBzY3JvbGxJbnRvVmlldygpYCBvbiB0aGUgaXRlbTogb25seSB0aGlzIGNvbnRhaW5lclxuICAgIC8vIG1heSBtb3ZlLiBNb3Rpb24gaXMgb3B0LW91dCDigJQgYSByZWFkZXIgd2hvIGFza2VkIHRoZSBPUyBmb3IgbGVzcyBvZiBpdCBnZXRzIGEganVtcC5cbiAgICBjb25zdCByZWR1Y2VkID0gd2luZG93Lm1hdGNoTWVkaWE/LignKHByZWZlcnMtcmVkdWNlZC1tb3Rpb246IHJlZHVjZSknKS5tYXRjaGVzID8/IGZhbHNlO1xuICAgIGxpc3Quc2Nyb2xsVG8oeyB0b3A6IG9mZnNldCwgYmVoYXZpb3I6IHJlZHVjZWQgPyAnYXV0bycgOiAnc21vb3RoJyB9KTtcbiAgfSwgW2N1cl0pO1xuXG4gIGlmICghaGVhZHMubGVuZ3RoKSByZXR1cm4gbnVsbDtcblxuICByZXR1cm4gKFxuICAgIDxuYXZcbiAgICAgIHJlZj17bGlzdFJlZn1cbiAgICAgIGNsYXNzTmFtZT17Wydncm92ZS10b2MnLCBjbGFzc05hbWVdLmZpbHRlcihCb29sZWFuKS5qb2luKCcgJyl9XG4gICAgICBhcmlhLWxhYmVsPXt0aXRsZSB8fCAnT24gdGhpcyBwYWdlJ31cbiAgICAgIG9uV2hlZWw9e25vdGVNYW51YWxTY3JvbGx9XG4gICAgICBvblRvdWNoTW92ZT17bm90ZU1hbnVhbFNjcm9sbH1cbiAgICA+XG4gICAgICB7dGl0bGUgPyA8ZGl2IGNsYXNzTmFtZT1cImdyb3ZlLXRvY19faFwiPnt0aXRsZX08L2Rpdj4gOiBudWxsfVxuICAgICAge2hlYWRzLm1hcCgoaCkgPT4gKFxuICAgICAgICA8YVxuICAgICAgICAgIGtleT17aC5pZH1cbiAgICAgICAgICByZWY9eyhlbCkgPT4ge1xuICAgICAgICAgICAgaWYgKGVsKSBpdGVtc1JlZi5jdXJyZW50LnNldChoLmlkLCBlbCk7XG4gICAgICAgICAgICBlbHNlIGl0ZW1zUmVmLmN1cnJlbnQuZGVsZXRlKGguaWQpO1xuICAgICAgICAgIH19XG4gICAgICAgICAgaHJlZj17YCMke2guaWR9YH1cbiAgICAgICAgICBkYXRhLWN1cj17Y3VyID09PSBoLmlkID8gJzEnIDogJzAnfVxuICAgICAgICAgIGFyaWEtY3VycmVudD17Y3VyID09PSBoLmlkID8gJ2xvY2F0aW9uJyA6IHVuZGVmaW5lZH1cbiAgICAgICAgICBjbGFzc05hbWU9e2gubGV2ZWwgPT09IDMgPyAnbHZsMycgOiB1bmRlZmluZWR9XG4gICAgICAgICAgb25DbGljaz17KGUpID0+IHtcbiAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICAgIC8vIENsaWNraW5nIElTIHRoZSByZWFkZXIgbW92aW5nIHRoZSBsaXN0LCBzbyBkb24ndCBhbHNvIGF1dG8tc2Nyb2xsIGl0LlxuICAgICAgICAgICAgbm90ZU1hbnVhbFNjcm9sbCgpO1xuICAgICAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoaC5pZCk/LnNjcm9sbEludG9WaWV3KHsgYmVoYXZpb3I6ICdzbW9vdGgnLCBibG9jazogJ3N0YXJ0JyB9KTtcbiAgICAgICAgICB9fVxuICAgICAgICA+XG4gICAgICAgICAge2gudGV4dH1cbiAgICAgICAgPC9hPlxuICAgICAgKSl9XG4gICAgPC9uYXY+XG4gICk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUEsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsWUFBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsVUFBQSxHQUFBRixPQUFBO0FBQTRELElBQUFHLFdBQUEsR0FBQUgsT0FBQTtBQUFBLElBQUFJLEVBQUEsR0FBQUMsWUFBQTtBQVc1RDtBQUNBO0FBQ0E7QUFDQSxNQUFNQyxXQUFXLEdBQUcsRUFBRTs7QUFFdEI7QUFDQTtBQUNBO0FBQ0EsTUFBTUMsc0JBQXNCLEdBQUcsSUFBSTs7QUFFbkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDZSxTQUFTQyxlQUFlQSxDQUFDO0VBQUVDLFFBQVE7RUFBRUMsS0FBSyxHQUFHLGNBQWM7RUFBRUM7QUFBaUIsQ0FBQyxFQUFFO0VBQUFQLEVBQUE7RUFDOUYsTUFBTVEsS0FBSyxHQUFHLElBQUFDLHdCQUFXLEVBQUNKLFFBQVEsQ0FBQztFQUNuQyxNQUFNSyxHQUFHLEdBQUcsSUFBQUMsNkJBQWdCLEVBQUNILEtBQUssQ0FBQztFQUNuQyxNQUFNSSxPQUFPLEdBQUcsSUFBQUMsYUFBTSxFQUFxQixJQUFJLENBQUM7RUFDaEQsTUFBTUMsUUFBUSxHQUFHLElBQUFELGFBQU0sRUFBQyxJQUFJRSxHQUFHLENBQTRCLENBQUMsQ0FBQztFQUM3RCxNQUFNQyxjQUFjLEdBQUcsSUFBQUgsYUFBTSxFQUFDLENBQUMsQ0FBQztFQUVoQyxNQUFNSSxnQkFBZ0IsR0FBRyxJQUFBQyxrQkFBVyxFQUFDLE1BQU07SUFDekNGLGNBQWMsQ0FBQ0csT0FBTyxHQUFHQyxJQUFJLENBQUNDLEdBQUcsQ0FBQyxDQUFDLEdBQUdsQixzQkFBc0I7RUFDOUQsQ0FBQyxFQUFFLEVBQUUsQ0FBQztFQUVOLElBQUFtQixnQkFBUyxFQUFDLE1BQU07SUFDZCxNQUFNQyxJQUFJLEdBQUdYLE9BQU8sQ0FBQ08sT0FBTztJQUM1QixNQUFNSyxJQUFJLEdBQUdkLEdBQUcsR0FBR0ksUUFBUSxDQUFDSyxPQUFPLENBQUNNLEdBQUcsQ0FBQ2YsR0FBRyxDQUFDLEdBQUdnQixTQUFTO0lBQ3hELElBQUksQ0FBQ0gsSUFBSSxJQUFJLENBQUNDLElBQUksRUFBRTtJQUNwQixJQUFJSixJQUFJLENBQUNDLEdBQUcsQ0FBQyxDQUFDLEdBQUdMLGNBQWMsQ0FBQ0csT0FBTyxFQUFFO0lBQ3pDLE1BQU1RLE1BQU0sR0FBRyxJQUFBQywwQkFBZSxFQUFDLEdBQUcsSUFBQUMsa0JBQU8sRUFBQ04sSUFBSSxFQUFFQyxJQUFJLENBQUMsRUFBRTtNQUFFTSxNQUFNLEVBQUU1QjtJQUFZLENBQUMsQ0FBQztJQUMvRSxJQUFJeUIsTUFBTSxLQUFLLElBQUksRUFBRSxPQUFPLENBQUM7SUFDN0I7SUFDQTtJQUNBLE1BQU1JLE9BQU8sR0FBR0MsTUFBTSxDQUFDQyxVQUFVLEdBQUcsa0NBQWtDLENBQUMsQ0FBQ0MsT0FBTyxJQUFJLEtBQUs7SUFDeEZYLElBQUksQ0FBQ1ksUUFBUSxDQUFDO01BQUVDLEdBQUcsRUFBRVQsTUFBTTtNQUFFVSxRQUFRLEVBQUVOLE9BQU8sR0FBRyxNQUFNLEdBQUc7SUFBUyxDQUFDLENBQUM7RUFDdkUsQ0FBQyxFQUFFLENBQUNyQixHQUFHLENBQUMsQ0FBQztFQUVULElBQUksQ0FBQ0YsS0FBSyxDQUFDOEIsTUFBTSxFQUFFLE9BQU8sSUFBSTtFQUU5QixvQkFDRSxJQUFBdkMsV0FBQSxDQUFBd0MsSUFBQTtJQUNFQyxHQUFHLEVBQUU1QixPQUFRO0lBQ2JMLFNBQVMsRUFBRSxDQUFDLFdBQVcsRUFBRUEsU0FBUyxDQUFDLENBQUNrQyxNQUFNLENBQUNDLE9BQU8sQ0FBQyxDQUFDQyxJQUFJLENBQUMsR0FBRyxDQUFFO0lBQzlELGNBQVlyQyxLQUFLLElBQUksY0FBZTtJQUNwQ3NDLE9BQU8sRUFBRTNCLGdCQUFpQjtJQUMxQjRCLFdBQVcsRUFBRTVCLGdCQUFpQjtJQUFBNkIsUUFBQSxHQUU3QnhDLEtBQUssZ0JBQUcsSUFBQVAsV0FBQSxDQUFBZ0QsR0FBQTtNQUFLeEMsU0FBUyxFQUFDLGNBQWM7TUFBQXVDLFFBQUEsRUFBRXhDO0lBQUssQ0FBTSxDQUFDLEdBQUcsSUFBSSxFQUMxREUsS0FBSyxDQUFDd0MsR0FBRyxDQUFFQyxDQUFDLGlCQUNYLElBQUFsRCxXQUFBLENBQUFnRCxHQUFBO01BRUVQLEdBQUcsRUFBR1UsRUFBRSxJQUFLO1FBQ1gsSUFBSUEsRUFBRSxFQUFFcEMsUUFBUSxDQUFDSyxPQUFPLENBQUNnQyxHQUFHLENBQUNGLENBQUMsQ0FBQ0csRUFBRSxFQUFFRixFQUFFLENBQUMsQ0FBQyxLQUNsQ3BDLFFBQVEsQ0FBQ0ssT0FBTyxDQUFDa0MsTUFBTSxDQUFDSixDQUFDLENBQUNHLEVBQUUsQ0FBQztNQUNwQyxDQUFFO01BQ0ZFLElBQUksRUFBRSxJQUFJTCxDQUFDLENBQUNHLEVBQUUsRUFBRztNQUNqQixZQUFVMUMsR0FBRyxLQUFLdUMsQ0FBQyxDQUFDRyxFQUFFLEdBQUcsR0FBRyxHQUFHLEdBQUk7TUFDbkMsZ0JBQWMxQyxHQUFHLEtBQUt1QyxDQUFDLENBQUNHLEVBQUUsR0FBRyxVQUFVLEdBQUcxQixTQUFVO01BQ3BEbkIsU0FBUyxFQUFFMEMsQ0FBQyxDQUFDTSxLQUFLLEtBQUssQ0FBQyxHQUFHLE1BQU0sR0FBRzdCLFNBQVU7TUFDOUM4QixPQUFPLEVBQUdDLENBQUMsSUFBSztRQUNkQSxDQUFDLENBQUNDLGNBQWMsQ0FBQyxDQUFDO1FBQ2xCO1FBQ0F6QyxnQkFBZ0IsQ0FBQyxDQUFDO1FBQ2xCMEMsUUFBUSxDQUFDQyxjQUFjLENBQUNYLENBQUMsQ0FBQ0csRUFBRSxDQUFDLEVBQUVTLGNBQWMsQ0FBQztVQUFFeEIsUUFBUSxFQUFFLFFBQVE7VUFBRXlCLEtBQUssRUFBRTtRQUFRLENBQUMsQ0FBQztNQUN2RixDQUFFO01BQUFoQixRQUFBLEVBRURHLENBQUMsQ0FBQ2M7SUFBSSxHQWhCRmQsQ0FBQyxDQUFDRyxFQWlCTixDQUNKLENBQUM7RUFBQSxDQUNDLENBQUM7QUFFVjtBQUFDcEQsRUFBQSxDQTFEdUJJLGVBQWU7RUFBQSxRQUN2Qkssd0JBQVcsRUFDYkUsNkJBQWdCO0FBQUE7QUFBQXFELEVBQUEsR0FGTjVELGVBQWU7QUFBQSxJQUFBNEQsRUFBQTtBQUFBQyxZQUFBLENBQUFELEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}