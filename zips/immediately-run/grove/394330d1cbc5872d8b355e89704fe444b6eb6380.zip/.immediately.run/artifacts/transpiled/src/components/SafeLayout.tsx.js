var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = SafeLayout;
var _sdk = require("@immediately-run/sdk");
var _mdxComponents = require("../mdxComponents");
var _jsxRuntime = require("react/jsx-runtime");
// A `_layout.mdx` rendered NON-EXECUTABLY — now a thin call to the PLATFORM's interpreter
// include rather than Grove's own reader. (R3-263: (a) built it here, (b) moved it into the
// SDK, this switch consumes it.)
//
// WHY THE LAYOUT NEEDS THIS AT ALL. `renderLayers` used to send every layer through
// `<Include>` — the compiled path — *regardless* of `render: safe`. So an interpreter-mode
// wiki still EXECUTED author JavaScript out of one content file, and the non-executable
// guarantee had a hole in the shell rather than in the entries. It was also inoperable under
// dispatch: the compiled path evaluates an app-source module, which a mount-resident layout
// is not.
//
// WHY IT IS NOW THE SDK'S JOB. The same capability is what whiteboard object bodies and the
// `AGENT_AUTHORING §10` MDX-from-mount gate need — a gate `TRUST_MODES §5.1` says MUST
// terminate in the safe renderer and never in compiled MDX. Keeping a second implementation
// here would let the platform path and the path Grove actually exercises drift apart; and
// because the SDK's own render-level coverage is bounded by its CJS test runner, this wiki
// exercising the real thing is what keeps the platform path honest.
//
// WHAT GROVE STILL OWNS: the component map. `<Include mode="interpreted">` resolves components
// from `useMDXComponents` — the map `boot({ mdxComponents })` established — which for this app
// is `SAFE_MDX` (`mdxComponents.ts`): the SDK defaults under the Grove vocabulary, plus the
// sanitizing structural tags (`lib/safeIntrinsics.tsx`). That is app policy and stays here.
//
// THE AUTHORING CONSTRAINTS ARE UNCHANGED and documented in `docs/ENGINE_BOUNDARY.md §6`:
// literal attributes only; an unregistered tag collapses to a Fragment that keeps its
// children; an `import` renders as visible prose rather than resolving; and a block tag must
// open on its own line or micromark consumes it as an HTML block.

/** Interpreter-mode layout layer: the raw `_layout.mdx` rendered as data (no author JS runs). */function SafeLayout({
  layoutKey
}) {
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_sdk.Include, {
    filename: layoutKey,
    mode: "interpreted",
    components: _mdxComponents.SAFE_MDX
  });
}
_c = SafeLayout;
var _c;
$RefreshReg$(_c, "SafeLayout");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfc2RrIiwicmVxdWlyZSIsIl9tZHhDb21wb25lbnRzIiwiX2pzeFJ1bnRpbWUiLCJTYWZlTGF5b3V0IiwibGF5b3V0S2V5IiwianN4IiwiSW5jbHVkZSIsImZpbGVuYW1lIiwibW9kZSIsImNvbXBvbmVudHMiLCJTQUZFX01EWCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiU2FmZUxheW91dC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5jbHVkZSB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrJztcbmltcG9ydCB7IFNBRkVfTURYIH0gZnJvbSAnLi4vbWR4Q29tcG9uZW50cyc7XG5cbi8vIEEgYF9sYXlvdXQubWR4YCByZW5kZXJlZCBOT04tRVhFQ1VUQUJMWSDigJQgbm93IGEgdGhpbiBjYWxsIHRvIHRoZSBQTEFURk9STSdzIGludGVycHJldGVyXG4vLyBpbmNsdWRlIHJhdGhlciB0aGFuIEdyb3ZlJ3Mgb3duIHJlYWRlci4gKFIzLTI2MzogKGEpIGJ1aWx0IGl0IGhlcmUsIChiKSBtb3ZlZCBpdCBpbnRvIHRoZVxuLy8gU0RLLCB0aGlzIHN3aXRjaCBjb25zdW1lcyBpdC4pXG4vL1xuLy8gV0hZIFRIRSBMQVlPVVQgTkVFRFMgVEhJUyBBVCBBTEwuIGByZW5kZXJMYXllcnNgIHVzZWQgdG8gc2VuZCBldmVyeSBsYXllciB0aHJvdWdoXG4vLyBgPEluY2x1ZGU+YCDigJQgdGhlIGNvbXBpbGVkIHBhdGgg4oCUICpyZWdhcmRsZXNzKiBvZiBgcmVuZGVyOiBzYWZlYC4gU28gYW4gaW50ZXJwcmV0ZXItbW9kZVxuLy8gd2lraSBzdGlsbCBFWEVDVVRFRCBhdXRob3IgSmF2YVNjcmlwdCBvdXQgb2Ygb25lIGNvbnRlbnQgZmlsZSwgYW5kIHRoZSBub24tZXhlY3V0YWJsZVxuLy8gZ3VhcmFudGVlIGhhZCBhIGhvbGUgaW4gdGhlIHNoZWxsIHJhdGhlciB0aGFuIGluIHRoZSBlbnRyaWVzLiBJdCB3YXMgYWxzbyBpbm9wZXJhYmxlIHVuZGVyXG4vLyBkaXNwYXRjaDogdGhlIGNvbXBpbGVkIHBhdGggZXZhbHVhdGVzIGFuIGFwcC1zb3VyY2UgbW9kdWxlLCB3aGljaCBhIG1vdW50LXJlc2lkZW50IGxheW91dFxuLy8gaXMgbm90LlxuLy9cbi8vIFdIWSBJVCBJUyBOT1cgVEhFIFNESydTIEpPQi4gVGhlIHNhbWUgY2FwYWJpbGl0eSBpcyB3aGF0IHdoaXRlYm9hcmQgb2JqZWN0IGJvZGllcyBhbmQgdGhlXG4vLyBgQUdFTlRfQVVUSE9SSU5HIMKnMTBgIE1EWC1mcm9tLW1vdW50IGdhdGUgbmVlZCDigJQgYSBnYXRlIGBUUlVTVF9NT0RFUyDCpzUuMWAgc2F5cyBNVVNUXG4vLyB0ZXJtaW5hdGUgaW4gdGhlIHNhZmUgcmVuZGVyZXIgYW5kIG5ldmVyIGluIGNvbXBpbGVkIE1EWC4gS2VlcGluZyBhIHNlY29uZCBpbXBsZW1lbnRhdGlvblxuLy8gaGVyZSB3b3VsZCBsZXQgdGhlIHBsYXRmb3JtIHBhdGggYW5kIHRoZSBwYXRoIEdyb3ZlIGFjdHVhbGx5IGV4ZXJjaXNlcyBkcmlmdCBhcGFydDsgYW5kXG4vLyBiZWNhdXNlIHRoZSBTREsncyBvd24gcmVuZGVyLWxldmVsIGNvdmVyYWdlIGlzIGJvdW5kZWQgYnkgaXRzIENKUyB0ZXN0IHJ1bm5lciwgdGhpcyB3aWtpXG4vLyBleGVyY2lzaW5nIHRoZSByZWFsIHRoaW5nIGlzIHdoYXQga2VlcHMgdGhlIHBsYXRmb3JtIHBhdGggaG9uZXN0LlxuLy9cbi8vIFdIQVQgR1JPVkUgU1RJTEwgT1dOUzogdGhlIGNvbXBvbmVudCBtYXAuIGA8SW5jbHVkZSBtb2RlPVwiaW50ZXJwcmV0ZWRcIj5gIHJlc29sdmVzIGNvbXBvbmVudHNcbi8vIGZyb20gYHVzZU1EWENvbXBvbmVudHNgIOKAlCB0aGUgbWFwIGBib290KHsgbWR4Q29tcG9uZW50cyB9KWAgZXN0YWJsaXNoZWQg4oCUIHdoaWNoIGZvciB0aGlzIGFwcFxuLy8gaXMgYFNBRkVfTURYYCAoYG1keENvbXBvbmVudHMudHNgKTogdGhlIFNESyBkZWZhdWx0cyB1bmRlciB0aGUgR3JvdmUgdm9jYWJ1bGFyeSwgcGx1cyB0aGVcbi8vIHNhbml0aXppbmcgc3RydWN0dXJhbCB0YWdzIChgbGliL3NhZmVJbnRyaW5zaWNzLnRzeGApLiBUaGF0IGlzIGFwcCBwb2xpY3kgYW5kIHN0YXlzIGhlcmUuXG4vL1xuLy8gVEhFIEFVVEhPUklORyBDT05TVFJBSU5UUyBBUkUgVU5DSEFOR0VEIGFuZCBkb2N1bWVudGVkIGluIGBkb2NzL0VOR0lORV9CT1VOREFSWS5tZCDCpzZgOlxuLy8gbGl0ZXJhbCBhdHRyaWJ1dGVzIG9ubHk7IGFuIHVucmVnaXN0ZXJlZCB0YWcgY29sbGFwc2VzIHRvIGEgRnJhZ21lbnQgdGhhdCBrZWVwcyBpdHNcbi8vIGNoaWxkcmVuOyBhbiBgaW1wb3J0YCByZW5kZXJzIGFzIHZpc2libGUgcHJvc2UgcmF0aGVyIHRoYW4gcmVzb2x2aW5nOyBhbmQgYSBibG9jayB0YWcgbXVzdFxuLy8gb3BlbiBvbiBpdHMgb3duIGxpbmUgb3IgbWljcm9tYXJrIGNvbnN1bWVzIGl0IGFzIGFuIEhUTUwgYmxvY2suXG5cbi8qKiBJbnRlcnByZXRlci1tb2RlIGxheW91dCBsYXllcjogdGhlIHJhdyBgX2xheW91dC5tZHhgIHJlbmRlcmVkIGFzIGRhdGEgKG5vIGF1dGhvciBKUyBydW5zKS4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFNhZmVMYXlvdXQoeyBsYXlvdXRLZXkgfTogeyBsYXlvdXRLZXk6IHN0cmluZyB9KSB7XG4gIHJldHVybiA8SW5jbHVkZSBmaWxlbmFtZT17bGF5b3V0S2V5fSBtb2RlPVwiaW50ZXJwcmV0ZWRcIiBjb21wb25lbnRzPXtTQUZFX01EWCBhcyBuZXZlcn0gLz47XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUFBLElBQUFBLElBQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLGNBQUEsR0FBQUQsT0FBQTtBQUE0QyxJQUFBRSxXQUFBLEdBQUFGLE9BQUE7QUFFNUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLGlHQUNlLFNBQVNHLFVBQVVBLENBQUM7RUFBRUM7QUFBaUMsQ0FBQyxFQUFFO0VBQ3ZFLG9CQUFPLElBQUFGLFdBQUEsQ0FBQUcsR0FBQSxFQUFDTixJQUFBLENBQUFPLE9BQU87SUFBQ0MsUUFBUSxFQUFFSCxTQUFVO0lBQUNJLElBQUksRUFBQyxhQUFhO0lBQUNDLFVBQVUsRUFBRUM7RUFBa0IsQ0FBRSxDQUFDO0FBQzNGO0FBQUNDLEVBQUEsR0FGdUJSLFVBQVU7QUFBQSxJQUFBUSxFQUFBO0FBQUFDLFlBQUEsQ0FBQUQsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}