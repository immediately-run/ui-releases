var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Callout;
var _Icon = _interopRequireDefault(require("./Icon"));
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
const ICON = {
  tip: 'sparkles',
  note: 'message',
  warning: 'alert'
};

// Import-free engine component: an Obsidian-style callout panel with an accent
// spine + a Lucide cue (tip / note / warning).
function Callout({
  variant,
  type,
  title,
  children
}) {
  const v = variant || type || 'note';
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "grove-callout",
    "data-v": v,
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
      name: ICON[v] || 'message'
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      children: [title ? /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "grove-callout__t",
        children: title
      }) : null, /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "grove-callout__b",
        children: children
      })]
    })]
  });
}
_c = Callout;
var _c;
$RefreshReg$(_c, "Callout");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfSWNvbiIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJlIiwiX19lc01vZHVsZSIsImRlZmF1bHQiLCJJQ09OIiwidGlwIiwibm90ZSIsIndhcm5pbmciLCJDYWxsb3V0IiwidmFyaWFudCIsInR5cGUiLCJ0aXRsZSIsImNoaWxkcmVuIiwidiIsImpzeHMiLCJjbGFzc05hbWUiLCJqc3giLCJuYW1lIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJDYWxsb3V0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IFJlYWN0Tm9kZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCBJY29uIGZyb20gJy4vSWNvbic7XG5cbmludGVyZmFjZSBQcm9wcyB7XG4gIHZhcmlhbnQ/OiAndGlwJyB8ICdub3RlJyB8ICd3YXJuaW5nJztcbiAgdHlwZT86ICd0aXAnIHwgJ25vdGUnIHwgJ3dhcm5pbmcnO1xuICB0aXRsZT86IHN0cmluZztcbiAgY2hpbGRyZW4/OiBSZWFjdE5vZGU7XG59XG5cbmNvbnN0IElDT046IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7IHRpcDogJ3NwYXJrbGVzJywgbm90ZTogJ21lc3NhZ2UnLCB3YXJuaW5nOiAnYWxlcnQnIH07XG5cbi8vIEltcG9ydC1mcmVlIGVuZ2luZSBjb21wb25lbnQ6IGFuIE9ic2lkaWFuLXN0eWxlIGNhbGxvdXQgcGFuZWwgd2l0aCBhbiBhY2NlbnRcbi8vIHNwaW5lICsgYSBMdWNpZGUgY3VlICh0aXAgLyBub3RlIC8gd2FybmluZykuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBDYWxsb3V0KHsgdmFyaWFudCwgdHlwZSwgdGl0bGUsIGNoaWxkcmVuIH06IFByb3BzKSB7XG4gIGNvbnN0IHYgPSB2YXJpYW50IHx8IHR5cGUgfHwgJ25vdGUnO1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JvdmUtY2FsbG91dFwiIGRhdGEtdj17dn0+XG4gICAgICA8SWNvbiBuYW1lPXtJQ09OW3ZdIHx8ICdtZXNzYWdlJ30gLz5cbiAgICAgIDxkaXY+XG4gICAgICAgIHt0aXRsZSA/IDxkaXYgY2xhc3NOYW1lPVwiZ3JvdmUtY2FsbG91dF9fdFwiPnt0aXRsZX08L2Rpdj4gOiBudWxsfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyb3ZlLWNhbGxvdXRfX2JcIj57Y2hpbGRyZW59PC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQ0EsSUFBQUEsS0FBQSxHQUFBQyxzQkFBQSxDQUFBQyxPQUFBO0FBQTBCLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUFBLFNBQUFELHVCQUFBRyxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBUzFCLE1BQU1HLElBQTRCLEdBQUc7RUFBRUMsR0FBRyxFQUFFLFVBQVU7RUFBRUMsSUFBSSxFQUFFLFNBQVM7RUFBRUMsT0FBTyxFQUFFO0FBQVEsQ0FBQzs7QUFFM0Y7QUFDQTtBQUNlLFNBQVNDLE9BQU9BLENBQUM7RUFBRUMsT0FBTztFQUFFQyxJQUFJO0VBQUVDLEtBQUs7RUFBRUM7QUFBZ0IsQ0FBQyxFQUFFO0VBQ3pFLE1BQU1DLENBQUMsR0FBR0osT0FBTyxJQUFJQyxJQUFJLElBQUksTUFBTTtFQUNuQyxvQkFDRSxJQUFBVixXQUFBLENBQUFjLElBQUE7SUFBS0MsU0FBUyxFQUFDLGVBQWU7SUFBQyxVQUFRRixDQUFFO0lBQUFELFFBQUEsZ0JBQ3ZDLElBQUFaLFdBQUEsQ0FBQWdCLEdBQUEsRUFBQ25CLEtBQUEsQ0FBQU0sT0FBSTtNQUFDYyxJQUFJLEVBQUViLElBQUksQ0FBQ1MsQ0FBQyxDQUFDLElBQUk7SUFBVSxDQUFFLENBQUMsZUFDcEMsSUFBQWIsV0FBQSxDQUFBYyxJQUFBO01BQUFGLFFBQUEsR0FDR0QsS0FBSyxnQkFBRyxJQUFBWCxXQUFBLENBQUFnQixHQUFBO1FBQUtELFNBQVMsRUFBQyxrQkFBa0I7UUFBQUgsUUFBQSxFQUFFRDtNQUFLLENBQU0sQ0FBQyxHQUFHLElBQUksZUFDL0QsSUFBQVgsV0FBQSxDQUFBZ0IsR0FBQTtRQUFLRCxTQUFTLEVBQUMsa0JBQWtCO1FBQUFILFFBQUEsRUFBRUE7TUFBUSxDQUFNLENBQUM7SUFBQSxDQUMvQyxDQUFDO0VBQUEsQ0FDSCxDQUFDO0FBRVY7QUFBQ00sRUFBQSxHQVh1QlYsT0FBTztBQUFBLElBQUFVLEVBQUE7QUFBQUMsWUFBQSxDQUFBRCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}