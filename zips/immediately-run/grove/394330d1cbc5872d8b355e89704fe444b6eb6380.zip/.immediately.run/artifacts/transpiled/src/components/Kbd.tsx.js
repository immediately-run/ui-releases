var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Kbd;
var _jsxRuntime = require("react/jsx-runtime");
// Import-free engine component: a keyboard key cap, e.g. <Kbd>⌘K</Kbd>.
function Kbd({
  children
}) {
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("kbd", {
    className: "grove-kbd",
    children: children
  });
}
_c = Kbd;
var _c;
$RefreshReg$(_c, "Kbd");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJLYmQiLCJjaGlsZHJlbiIsIl9qc3hSdW50aW1lIiwianN4IiwiY2xhc3NOYW1lIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJLYmQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgUmVhY3ROb2RlIH0gZnJvbSAncmVhY3QnO1xuXG5pbnRlcmZhY2UgUHJvcHMge1xuICBjaGlsZHJlbj86IFJlYWN0Tm9kZTtcbn1cblxuLy8gSW1wb3J0LWZyZWUgZW5naW5lIGNvbXBvbmVudDogYSBrZXlib2FyZCBrZXkgY2FwLCBlLmcuIDxLYmQ+4oyYSzwvS2JkPi5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEtiZCh7IGNoaWxkcmVuIH06IFByb3BzKSB7XG4gIHJldHVybiA8a2JkIGNsYXNzTmFtZT1cImdyb3ZlLWtiZFwiPntjaGlsZHJlbn08L2tiZD47XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFNQTtBQUNlLFNBQVNBLEdBQUdBLENBQUM7RUFBRUM7QUFBZ0IsQ0FBQyxFQUFFO0VBQy9DLG9CQUFPLElBQUFDLFdBQUEsQ0FBQUMsR0FBQTtJQUFLQyxTQUFTLEVBQUMsV0FBVztJQUFBSCxRQUFBLEVBQUVBO0VBQVEsQ0FBTSxDQUFDO0FBQ3BEO0FBQUNJLEVBQUEsR0FGdUJMLEdBQUc7QUFBQSxJQUFBSyxFQUFBO0FBQUFDLFlBQUEsQ0FBQUQsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}