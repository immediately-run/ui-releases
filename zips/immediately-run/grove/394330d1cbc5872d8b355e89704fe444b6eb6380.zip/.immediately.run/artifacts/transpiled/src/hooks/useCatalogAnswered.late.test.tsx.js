var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

var _vitest = require("vitest");
var _jsxRuntime = require("react/jsx-runtime");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; } // @vitest-environment jsdom
// The LATE-IMPORT case, in its own file because it is the one ordering the sibling suite
// cannot produce: the host answers BEFORE this module is evaluated.
//
// grove is published as a pinned library (`src/lib.ts`), so "imported before any render"
// is an assumption about one embedding, not a guarantee. If the subscribe-time call is
// discarded with a blanket reset, a host that already answered is invisible for the
// realm's life — and because the host does not push again, nothing corrects it.
//
// This file exists because round 3's own fix was untested: replacing
// `answered = catalog.length > 0` with `answered = false` — i.e. the blanket reset the
// fix replaced — left the whole suite green. A fix with no failing case is a guess.
const handlers = new Set();
const emit = msg => {
  for (const h of handlers) h(msg);
};
globalThis.__immediatelyRun__ = {
  transport: {
    sendMessage: _vitest.vi.fn(),
    protocolRequest: _vitest.vi.fn(async () => ({})),
    onMessage: handler => {
      handlers.add(handler);
      return {
        dispose: () => handlers.delete(handler)
      };
    }
  }
};
(0, _vitest.describe)('useCatalogAnswered, imported AFTER the host answered', () => {
  (0, _vitest.it)('reads a non-empty catalog at subscribe as proof the answer landed', async () => {
    var _s = $RefreshSig$();
    // Start and answer the channel through the SDK directly, with the hook module not yet
    // imported — the ordering a late-mounting library consumer produces.
    const {
      getCatalog
    } = await Promise.resolve().then(() => _interopRequireWildcard(require('@immediately-run/sdk')));
    getCatalog();
    emit({
      type: 'api-catalog',
      methods: [{
        name: 'llm:chat',
        capability: 'llm:chat',
        stream: true
      }]
    });

    // NOW import. The listener's synchronous subscribe-time call carries the answered
    // catalog; a blanket reset would throw it away and the flag would be false forever.
    const {
      useCatalogAnswered
    } = await Promise.resolve().then(() => _interopRequireWildcard(require('./useCatalogAnswered')));
    const {
      act
    } = await Promise.resolve().then(() => _interopRequireWildcard(require('react')));
    const {
      createRoot
    } = await Promise.resolve().then(() => _interopRequireWildcard(require('react-dom/client')));
    const seen = [];
    const Probe = () => {
      _s();
      seen.push(useCatalogAnswered());
      return null;
    };
    _s(Probe, "RwilvecANRMzLklwXLFewrbBy6k=", false, function () {
      return [useCatalogAnswered];
    });
    const root = createRoot(document.createElement('div'));
    await act(async () => {
      root.render(/*#__PURE__*/(0, _jsxRuntime.jsx)(Probe, {}));
    });
    (0, _vitest.expect)(seen[seen.length - 1]).toBe(true);
    await act(async () => root.unmount());
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZXN0IiwicmVxdWlyZSIsIl9qc3hSdW50aW1lIiwiX2dldFJlcXVpcmVXaWxkY2FyZENhY2hlIiwiZSIsIldlYWtNYXAiLCJyIiwidCIsIl9pbnRlcm9wUmVxdWlyZVdpbGRjYXJkIiwiX19lc01vZHVsZSIsImRlZmF1bHQiLCJoYXMiLCJnZXQiLCJuIiwiX19wcm90b19fIiwiYSIsIk9iamVjdCIsImRlZmluZVByb3BlcnR5IiwiZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yIiwidSIsImhhc093blByb3BlcnR5IiwiY2FsbCIsImkiLCJzZXQiLCJoYW5kbGVycyIsIlNldCIsImVtaXQiLCJtc2ciLCJoIiwiZ2xvYmFsVGhpcyIsIl9faW1tZWRpYXRlbHlSdW5fXyIsInRyYW5zcG9ydCIsInNlbmRNZXNzYWdlIiwidmkiLCJmbiIsInByb3RvY29sUmVxdWVzdCIsIm9uTWVzc2FnZSIsImhhbmRsZXIiLCJhZGQiLCJkaXNwb3NlIiwiZGVsZXRlIiwiZGVzY3JpYmUiLCJpdCIsIl9zIiwiJFJlZnJlc2hTaWckIiwiZ2V0Q2F0YWxvZyIsIlByb21pc2UiLCJyZXNvbHZlIiwidGhlbiIsInR5cGUiLCJtZXRob2RzIiwibmFtZSIsImNhcGFiaWxpdHkiLCJzdHJlYW0iLCJ1c2VDYXRhbG9nQW5zd2VyZWQiLCJhY3QiLCJjcmVhdGVSb290Iiwic2VlbiIsIlByb2JlIiwicHVzaCIsInJvb3QiLCJkb2N1bWVudCIsImNyZWF0ZUVsZW1lbnQiLCJyZW5kZXIiLCJqc3giLCJleHBlY3QiLCJsZW5ndGgiLCJ0b0JlIiwidW5tb3VudCJdLCJzb3VyY2VzIjpbInVzZUNhdGFsb2dBbnN3ZXJlZC5sYXRlLnRlc3QudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIEB2aXRlc3QtZW52aXJvbm1lbnQganNkb21cbi8vIFRoZSBMQVRFLUlNUE9SVCBjYXNlLCBpbiBpdHMgb3duIGZpbGUgYmVjYXVzZSBpdCBpcyB0aGUgb25lIG9yZGVyaW5nIHRoZSBzaWJsaW5nIHN1aXRlXG4vLyBjYW5ub3QgcHJvZHVjZTogdGhlIGhvc3QgYW5zd2VycyBCRUZPUkUgdGhpcyBtb2R1bGUgaXMgZXZhbHVhdGVkLlxuLy9cbi8vIGdyb3ZlIGlzIHB1Ymxpc2hlZCBhcyBhIHBpbm5lZCBsaWJyYXJ5IChgc3JjL2xpYi50c2ApLCBzbyBcImltcG9ydGVkIGJlZm9yZSBhbnkgcmVuZGVyXCJcbi8vIGlzIGFuIGFzc3VtcHRpb24gYWJvdXQgb25lIGVtYmVkZGluZywgbm90IGEgZ3VhcmFudGVlLiBJZiB0aGUgc3Vic2NyaWJlLXRpbWUgY2FsbCBpc1xuLy8gZGlzY2FyZGVkIHdpdGggYSBibGFua2V0IHJlc2V0LCBhIGhvc3QgdGhhdCBhbHJlYWR5IGFuc3dlcmVkIGlzIGludmlzaWJsZSBmb3IgdGhlXG4vLyByZWFsbSdzIGxpZmUg4oCUIGFuZCBiZWNhdXNlIHRoZSBob3N0IGRvZXMgbm90IHB1c2ggYWdhaW4sIG5vdGhpbmcgY29ycmVjdHMgaXQuXG4vL1xuLy8gVGhpcyBmaWxlIGV4aXN0cyBiZWNhdXNlIHJvdW5kIDMncyBvd24gZml4IHdhcyB1bnRlc3RlZDogcmVwbGFjaW5nXG4vLyBgYW5zd2VyZWQgPSBjYXRhbG9nLmxlbmd0aCA+IDBgIHdpdGggYGFuc3dlcmVkID0gZmFsc2VgIOKAlCBpLmUuIHRoZSBibGFua2V0IHJlc2V0IHRoZVxuLy8gZml4IHJlcGxhY2VkIOKAlCBsZWZ0IHRoZSB3aG9sZSBzdWl0ZSBncmVlbi4gQSBmaXggd2l0aCBubyBmYWlsaW5nIGNhc2UgaXMgYSBndWVzcy5cbmltcG9ydCB7IGRlc2NyaWJlLCBpdCwgZXhwZWN0LCB2aSB9IGZyb20gJ3ZpdGVzdCc7XG5cbnR5cGUgSGFuZGxlciA9IChtc2c6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KSA9PiB2b2lkO1xuY29uc3QgaGFuZGxlcnMgPSBuZXcgU2V0PEhhbmRsZXI+KCk7XG5jb25zdCBlbWl0ID0gKG1zZzogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiB2b2lkID0+IHtcbiAgZm9yIChjb25zdCBoIG9mIGhhbmRsZXJzKSBoKG1zZyk7XG59O1xuXG4oZ2xvYmFsVGhpcyBhcyB7IF9faW1tZWRpYXRlbHlSdW5fXz86IHVua25vd24gfSkuX19pbW1lZGlhdGVseVJ1bl9fID0ge1xuICB0cmFuc3BvcnQ6IHtcbiAgICBzZW5kTWVzc2FnZTogdmkuZm4oKSxcbiAgICBwcm90b2NvbFJlcXVlc3Q6IHZpLmZuKGFzeW5jICgpID0+ICh7fSkpLFxuICAgIG9uTWVzc2FnZTogKGhhbmRsZXI6IEhhbmRsZXIpID0+IHtcbiAgICAgIGhhbmRsZXJzLmFkZChoYW5kbGVyKTtcbiAgICAgIHJldHVybiB7IGRpc3Bvc2U6ICgpID0+IGhhbmRsZXJzLmRlbGV0ZShoYW5kbGVyKSB9O1xuICAgIH0sXG4gIH0sXG59O1xuXG5kZXNjcmliZSgndXNlQ2F0YWxvZ0Fuc3dlcmVkLCBpbXBvcnRlZCBBRlRFUiB0aGUgaG9zdCBhbnN3ZXJlZCcsICgpID0+IHtcbiAgaXQoJ3JlYWRzIGEgbm9uLWVtcHR5IGNhdGFsb2cgYXQgc3Vic2NyaWJlIGFzIHByb29mIHRoZSBhbnN3ZXIgbGFuZGVkJywgYXN5bmMgKCkgPT4ge1xuICAgIC8vIFN0YXJ0IGFuZCBhbnN3ZXIgdGhlIGNoYW5uZWwgdGhyb3VnaCB0aGUgU0RLIGRpcmVjdGx5LCB3aXRoIHRoZSBob29rIG1vZHVsZSBub3QgeWV0XG4gICAgLy8gaW1wb3J0ZWQg4oCUIHRoZSBvcmRlcmluZyBhIGxhdGUtbW91bnRpbmcgbGlicmFyeSBjb25zdW1lciBwcm9kdWNlcy5cbiAgICBjb25zdCB7IGdldENhdGFsb2cgfSA9IGF3YWl0IGltcG9ydCgnQGltbWVkaWF0ZWx5LXJ1bi9zZGsnKTtcbiAgICBnZXRDYXRhbG9nKCk7XG4gICAgZW1pdCh7IHR5cGU6ICdhcGktY2F0YWxvZycsIG1ldGhvZHM6IFt7IG5hbWU6ICdsbG06Y2hhdCcsIGNhcGFiaWxpdHk6ICdsbG06Y2hhdCcsIHN0cmVhbTogdHJ1ZSB9XSB9KTtcblxuICAgIC8vIE5PVyBpbXBvcnQuIFRoZSBsaXN0ZW5lcidzIHN5bmNocm9ub3VzIHN1YnNjcmliZS10aW1lIGNhbGwgY2FycmllcyB0aGUgYW5zd2VyZWRcbiAgICAvLyBjYXRhbG9nOyBhIGJsYW5rZXQgcmVzZXQgd291bGQgdGhyb3cgaXQgYXdheSBhbmQgdGhlIGZsYWcgd291bGQgYmUgZmFsc2UgZm9yZXZlci5cbiAgICBjb25zdCB7IHVzZUNhdGFsb2dBbnN3ZXJlZCB9ID0gYXdhaXQgaW1wb3J0KCcuL3VzZUNhdGFsb2dBbnN3ZXJlZCcpO1xuXG4gICAgY29uc3QgeyBhY3QgfSA9IGF3YWl0IGltcG9ydCgncmVhY3QnKTtcbiAgICBjb25zdCB7IGNyZWF0ZVJvb3QgfSA9IGF3YWl0IGltcG9ydCgncmVhY3QtZG9tL2NsaWVudCcpO1xuICAgIGNvbnN0IHNlZW46IGJvb2xlYW5bXSA9IFtdO1xuICAgIGNvbnN0IFByb2JlID0gKCkgPT4ge1xuICAgICAgc2Vlbi5wdXNoKHVzZUNhdGFsb2dBbnN3ZXJlZCgpKTtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH07XG4gICAgY29uc3Qgcm9vdCA9IGNyZWF0ZVJvb3QoZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2JykpO1xuICAgIGF3YWl0IGFjdChhc3luYyAoKSA9PiB7XG4gICAgICByb290LnJlbmRlcig8UHJvYmUgLz4pO1xuICAgIH0pO1xuXG4gICAgZXhwZWN0KHNlZW5bc2Vlbi5sZW5ndGggLSAxXSkudG9CZSh0cnVlKTtcbiAgICBhd2FpdCBhY3QoYXN5bmMgKCkgPT4gcm9vdC51bm1vdW50KCkpO1xuICB9KTtcbn0pO1xuIl0sIm1hcHBpbmdzIjoiOztBQVlBLElBQUFBLE9BQUEsR0FBQUMsT0FBQTtBQUFrRCxJQUFBQyxXQUFBLEdBQUFELE9BQUE7QUFBQSxTQUFBRSx5QkFBQUMsQ0FBQSw2QkFBQUMsT0FBQSxtQkFBQUMsQ0FBQSxPQUFBRCxPQUFBLElBQUFFLENBQUEsT0FBQUYsT0FBQSxZQUFBRix3QkFBQSxZQUFBQSxDQUFBQyxDQUFBLFdBQUFBLENBQUEsR0FBQUcsQ0FBQSxHQUFBRCxDQUFBLEtBQUFGLENBQUE7QUFBQSxTQUFBSSx3QkFBQUosQ0FBQSxFQUFBRSxDQUFBLFNBQUFBLENBQUEsSUFBQUYsQ0FBQSxJQUFBQSxDQUFBLENBQUFLLFVBQUEsU0FBQUwsQ0FBQSxlQUFBQSxDQUFBLHVCQUFBQSxDQUFBLHlCQUFBQSxDQUFBLFdBQUFNLE9BQUEsRUFBQU4sQ0FBQSxRQUFBRyxDQUFBLEdBQUFKLHdCQUFBLENBQUFHLENBQUEsT0FBQUMsQ0FBQSxJQUFBQSxDQUFBLENBQUFJLEdBQUEsQ0FBQVAsQ0FBQSxVQUFBRyxDQUFBLENBQUFLLEdBQUEsQ0FBQVIsQ0FBQSxPQUFBUyxDQUFBLEtBQUFDLFNBQUEsVUFBQUMsQ0FBQSxHQUFBQyxNQUFBLENBQUFDLGNBQUEsSUFBQUQsTUFBQSxDQUFBRSx3QkFBQSxXQUFBQyxDQUFBLElBQUFmLENBQUEsb0JBQUFlLENBQUEsT0FBQUMsY0FBQSxDQUFBQyxJQUFBLENBQUFqQixDQUFBLEVBQUFlLENBQUEsU0FBQUcsQ0FBQSxHQUFBUCxDQUFBLEdBQUFDLE1BQUEsQ0FBQUUsd0JBQUEsQ0FBQWQsQ0FBQSxFQUFBZSxDQUFBLFVBQUFHLENBQUEsS0FBQUEsQ0FBQSxDQUFBVixHQUFBLElBQUFVLENBQUEsQ0FBQUMsR0FBQSxJQUFBUCxNQUFBLENBQUFDLGNBQUEsQ0FBQUosQ0FBQSxFQUFBTSxDQUFBLEVBQUFHLENBQUEsSUFBQVQsQ0FBQSxDQUFBTSxDQUFBLElBQUFmLENBQUEsQ0FBQWUsQ0FBQSxZQUFBTixDQUFBLENBQUFILE9BQUEsR0FBQU4sQ0FBQSxFQUFBRyxDQUFBLElBQUFBLENBQUEsQ0FBQWdCLEdBQUEsQ0FBQW5CLENBQUEsRUFBQVMsQ0FBQSxHQUFBQSxDQUFBLElBWmxEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUlBLE1BQU1XLFFBQVEsR0FBRyxJQUFJQyxHQUFHLENBQVUsQ0FBQztBQUNuQyxNQUFNQyxJQUFJLEdBQUlDLEdBQTRCLElBQVc7RUFDbkQsS0FBSyxNQUFNQyxDQUFDLElBQUlKLFFBQVEsRUFBRUksQ0FBQyxDQUFDRCxHQUFHLENBQUM7QUFDbEMsQ0FBQztBQUVBRSxVQUFVLENBQXNDQyxrQkFBa0IsR0FBRztFQUNwRUMsU0FBUyxFQUFFO0lBQ1RDLFdBQVcsRUFBRUMsVUFBRSxDQUFDQyxFQUFFLENBQUMsQ0FBQztJQUNwQkMsZUFBZSxFQUFFRixVQUFFLENBQUNDLEVBQUUsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDeENFLFNBQVMsRUFBR0MsT0FBZ0IsSUFBSztNQUMvQmIsUUFBUSxDQUFDYyxHQUFHLENBQUNELE9BQU8sQ0FBQztNQUNyQixPQUFPO1FBQUVFLE9BQU8sRUFBRUEsQ0FBQSxLQUFNZixRQUFRLENBQUNnQixNQUFNLENBQUNILE9BQU87TUFBRSxDQUFDO0lBQ3BEO0VBQ0Y7QUFDRixDQUFDO0FBRUQsSUFBQUksZ0JBQVEsRUFBQyxzREFBc0QsRUFBRSxNQUFNO0VBQ3JFLElBQUFDLFVBQUUsRUFBQyxtRUFBbUUsRUFBRSxZQUFZO0lBQUEsSUFBQUMsRUFBQSxHQUFBQyxZQUFBO0lBQ2xGO0lBQ0E7SUFDQSxNQUFNO01BQUVDO0lBQVcsQ0FBQyxHQUFHLE1BQUFDLE9BQUEsQ0FBQUMsT0FBQSxHQUFBQyxJQUFBLE9BQUF4Qyx1QkFBQSxDQUFBUCxPQUFBLENBQWEsc0JBQXNCLEdBQUM7SUFDM0Q0QyxVQUFVLENBQUMsQ0FBQztJQUNabkIsSUFBSSxDQUFDO01BQUV1QixJQUFJLEVBQUUsYUFBYTtNQUFFQyxPQUFPLEVBQUUsQ0FBQztRQUFFQyxJQUFJLEVBQUUsVUFBVTtRQUFFQyxVQUFVLEVBQUUsVUFBVTtRQUFFQyxNQUFNLEVBQUU7TUFBSyxDQUFDO0lBQUUsQ0FBQyxDQUFDOztJQUVwRztJQUNBO0lBQ0EsTUFBTTtNQUFFQztJQUFtQixDQUFDLEdBQUcsTUFBQVIsT0FBQSxDQUFBQyxPQUFBLEdBQUFDLElBQUEsT0FBQXhDLHVCQUFBLENBQUFQLE9BQUEsQ0FBYSxzQkFBc0IsR0FBQztJQUVuRSxNQUFNO01BQUVzRDtJQUFJLENBQUMsR0FBRyxNQUFBVCxPQUFBLENBQUFDLE9BQUEsR0FBQUMsSUFBQSxPQUFBeEMsdUJBQUEsQ0FBQVAsT0FBQSxDQUFhLE9BQU8sR0FBQztJQUNyQyxNQUFNO01BQUV1RDtJQUFXLENBQUMsR0FBRyxNQUFBVixPQUFBLENBQUFDLE9BQUEsR0FBQUMsSUFBQSxPQUFBeEMsdUJBQUEsQ0FBQVAsT0FBQSxDQUFhLGtCQUFrQixHQUFDO0lBQ3ZELE1BQU13RCxJQUFlLEdBQUcsRUFBRTtJQUMxQixNQUFNQyxLQUFLLEdBQUdBLENBQUEsS0FBTTtNQUFBZixFQUFBO01BQ2xCYyxJQUFJLENBQUNFLElBQUksQ0FBQ0wsa0JBQWtCLENBQUMsQ0FBQyxDQUFDO01BQy9CLE9BQU8sSUFBSTtJQUNiLENBQUM7SUFBQ1gsRUFBQSxDQUhJZSxLQUFLO01BQUEsUUFDQ0osa0JBQWtCO0lBQUE7SUFHOUIsTUFBTU0sSUFBSSxHQUFHSixVQUFVLENBQUNLLFFBQVEsQ0FBQ0MsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3RELE1BQU1QLEdBQUcsQ0FBQyxZQUFZO01BQ3BCSyxJQUFJLENBQUNHLE1BQU0sY0FBQyxJQUFBN0QsV0FBQSxDQUFBOEQsR0FBQSxFQUFDTixLQUFLLElBQUUsQ0FBQyxDQUFDO0lBQ3hCLENBQUMsQ0FBQztJQUVGLElBQUFPLGNBQU0sRUFBQ1IsSUFBSSxDQUFDQSxJQUFJLENBQUNTLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDQyxJQUFJLENBQUMsSUFBSSxDQUFDO0lBQ3hDLE1BQU1aLEdBQUcsQ0FBQyxZQUFZSyxJQUFJLENBQUNRLE9BQU8sQ0FBQyxDQUFDLENBQUM7RUFDdkMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}