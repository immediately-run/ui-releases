var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = GroveWiki;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.map.js");
var _react = require("react");
var _fs = _interopRequireDefault(require("fs"));
var _sdk = require("@immediately-run/sdk");
var _TinkerableContext = require("@immediately-run/sdk/TinkerableContext");
var _linkSpace = require("@immediately-run/sdk/linkSpace");
var _bundle = require("@immediately-run/sdk/bundle");
var _content = require("./lib/content");
var _wiki = require("./lib/wiki");
var _queries = require("./lib/queries");
var _layout = require("./lib/layout");
var _directory = require("./lib/directory");
var _themeSelection = require("./lib/themeSelection");
var _themes = require("./data/themes");
var _useDirectoryListing = require("./hooks/useDirectoryListing");
var _useScrollReset = require("./hooks/useScrollReset");
var _useEditAffordance = require("./hooks/useEditAffordance");
var _contentRoot = require("./lib/contentRoot");
var _shell = require("./lib/shell");
var _PageView = _interopRequireDefault(require("./components/PageView"));
var _SafeLayout = _interopRequireDefault(require("./components/SafeLayout"));
var _DefaultLayout = _interopRequireDefault(require("./components/DefaultLayout"));
var _Search = _interopRequireDefault(require("./components/Search"));
var _Drawer = _interopRequireDefault(require("./components/Drawer"));
var _GroveAgent = _interopRequireDefault(require("./components/GroveAgent"));
var _ThemeAssets = _interopRequireDefault(require("./components/ThemeAssets"));
var _ContentTheme = _interopRequireDefault(require("./components/ContentTheme"));
var _BootMessage = _interopRequireDefault(require("./components/BootMessage"));
var _themeFonts = require("./data/themeFonts");
var _useContentStylesheets = require("./hooks/useContentStylesheets");
var _criticalKeys = require("./lib/criticalKeys");
var _entryGate = require("./lib/entryGate");
var _corpusScanContext = require("./lib/corpusScanContext");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$();
/* eslint-disable @typescript-eslint/no-explicit-any */
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function readPref(k) {
  try {
    return localStorage.getItem(k);
  } catch {
    return null;
  }
}
function writePref(k, v) {
  try {
    localStorage.setItem(k, v);
  } catch {
    /* ignore */
  }
}

// Bundle-absolute path → the href that navigates to it, for CONTENT (R3-174).
//
// Module scope, and that is load-bearing rather than tidiness: this function is handed to
// content through `BundleContext`, and the SDK's `useBundleEntries` memoizes on its
// identity. A closure rebuilt each render would make that memo never hold, so the hook the
// SDK documents as "safe in a dependency array" would quietly stop being one — from the
// PROVIDER's side, where nobody using it would think to look. Nothing here is reactive:
// `contentDir()` is boot-settled module state and `keyToHref` is a pure function of it.
function bundleHref(bundlePath) {
  const absolute = (0, _bundle.fromBundlePath)(bundlePath, (0, _content.contentDir)().replace(/\/+$/, ''));
  return absolute === null ? bundlePath : (0, _content.keyToHref)(absolute);
}

// Build the nested render for a layout chain (outermost first). Each layer wraps
// its `_layout.mdx` (or the built-in <DefaultLayout/>) in an OutletContext whose
// value is the node one level inward — so `<Outlet/>` inside a layer renders the
// next layer, and the innermost <Outlet/> renders the page (<PageView/>).
//
// `safe` picks the RENDERER for each layer, exactly as it does for entry bodies in
// <PageView/> (R3-263). Before this, every layer went through <Include> whatever the wiki
// declared — so an interpreter-mode wiki still EXECUTED author JavaScript out of its
// `_layout.mdx`, and the non-executable guarantee had a hole in the shell rather than in
// the entries. It is also what makes the chain work at all under dispatch: <Include>
// evaluates an app-source module, which a layout resident in a content mount is not.
function renderLayers(chain, useDefault, safe) {
  let node = /*#__PURE__*/(0, _jsxRuntime.jsx)(_PageView.default, {});
  if (useDefault) {
    return /*#__PURE__*/(0, _jsxRuntime.jsx)(_shell.OutletContext.Provider, {
      value: node,
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_DefaultLayout.default, {})
    });
  }
  for (let i = chain.length - 1; i >= 0; i--) {
    const inner = node;
    node = /*#__PURE__*/(0, _jsxRuntime.jsx)(_shell.OutletContext.Provider, {
      value: inner,
      children: safe ? /*#__PURE__*/(0, _jsxRuntime.jsx)(_SafeLayout.default, {
        layoutKey: chain[i]
      }) : /*#__PURE__*/(0, _jsxRuntime.jsx)(_sdk.Include, {
        filename: chain[i],
        baseModule: module
      })
    }, chain[i]);
  }
  return node;
}

/**
 * The wiki itself: routing, chrome, and the entry render. Everything here reads the
 * content root, so it may only mount once that root is settled — which is why the
 * default export of `App.tsx` is a gate in front of it rather than this component
 * (R3-169: under dispatch the root is a runtime value, not `/app/content/`).
 */
function GroveWiki({
  readOnly = false,
  rejectedComponents = []
}) {
  _s();
  const ctx = (0, _react.useContext)(_TinkerableContext.TinkerableContext);
  const sandboxPath = ctx?.navigationState?.sandboxPath || '/';
  const hash = ctx?.navigationState?.hash ?? '';

  // ── Theme selection (R3-308, 02-theme-contract §4) ─────────────────────────
  //
  // Two INDEPENDENT axes with three sources, resolved through ONE module
  // (lib/themeSelection) so no surface re-derives the precedence:
  //
  //   palette  = reader override, else the author's `theme:` on the home entry, else default
  //   polarity = reader override, else the host's theme, else the palette's preferred
  //
  // The stored prefs are OVERRIDES, nullable by nature: absent until the reader
  // acts, which is what gives the author's declaration its turn. They are written
  // by the user actions (chooseTheme/choosePolarity), NEVER by an effect on mount
  // — the old effects promoted the initial value to a reader choice on first
  // visit, which is exactly why a `theme:` declaration could never have won.
  // (Visitors from before this change carry a mount-written pref; it stands —
  // they are Grove readers, and a reader outranks an author.)
  const [readerTheme, setReaderTheme] = (0, _react.useState)(() => readPref('grove:theme'));
  const [readerAppearance, setReaderAppearance] = (0, _react.useState)(() => {
    const p = readPref('grove:appearance');
    return p === 'light' || p === 'dark' ? p : null;
  });
  const chooseTheme = id => {
    setReaderTheme(id);
    writePref('grove:theme', id);
  };
  const choosePolarity = wantLight => {
    const p = wantLight ? 'light' : 'dark';
    setReaderAppearance(p);
    writePref('grove:appearance', p);
  };
  // The host drives POLARITY ONLY (`theme:read` is the one theme capability the
  // open-wiki binding holds) — and only when there IS a host. `useHostTheme`'s
  // channel reports an `initial: 'dark'` before any host speaks, so an unframed
  // standalone `vite dev` render would otherwise carry a phantom host opinion
  // and flip light-preferred themes. Framed === a host exists to have one.
  const framed = typeof window !== 'undefined' && window.parent !== window;
  const hostTheme = (0, _sdk.useHostTheme)();
  const hostPolarity = framed ? hostTheme : null;
  const [menuOpen, setMenuOpen] = (0, _react.useState)(false);
  const [searchOpen, setSearchOpen] = (0, _react.useState)(false);
  const [drawerOpen, setDrawerOpen] = (0, _react.useState)(false);
  const [mins, setMins] = (0, _react.useState)(0);
  const [vw, setVw] = (0, _react.useState)(() => typeof window !== 'undefined' && window.matchMedia('(max-width: 720px)').matches ? 'mobile' : 'desktop');
  (0, _react.useEffect)(() => {
    const mq = window.matchMedia('(max-width: 720px)');
    const on = () => setVw(mq.matches ? 'mobile' : 'desktop');
    mq.addEventListener('change', on);
    return () => mq.removeEventListener('change', on);
  }, []);

  // ⌘K / Ctrl-K opens search.
  (0, _react.useEffect)(() => {
    const on = e => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setSearchOpen(o => !o);
      }
    };
    window.addEventListener('keydown', on);
    return () => window.removeEventListener('keydown', on);
  }, []);

  // R3-266 — dispatched content IS writable, and the MOUNT decides.
  //
  // This used to read `!isDispatched() && …`, withholding every edit affordance from a
  // dispatched viewer. The reason was real but the conclusion was not: `requestEdit` is
  // **self-scoped by contract**, so under dispatch it names a path in GROVE's repo rather
  // than in the corpus on screen. The fix is a verb swap, not a withheld capability — see
  // `lib/editTarget` — and the gate is the corpus mount's CURRENT mode, re-read on every
  // mount change so a live role downgrade hides the affordance instead of producing
  // `EROFS` on click.
  const {
    writable,
    busy: editBusy,
    refused: editRefused,
    openEditor,
    editHint
  } = (0, _useEditAffordance.useEditAffordance)(readOnly);
  const routeKey = (0, _content.sandboxPathToKey)(sandboxPath) || (0, _content.homeKey)();
  // The site brand is a wiki-wide constant, so read it from the home entry's
  // `site` frontmatter — not the current entry's (which only home would carry),
  // else the brand flips to the 'Grove' fallback on every sub-page.
  const homeMeta = (0, _sdk.useFileMetadata)((0, _content.homeKey)());
  // R3-308: the author's palette declaration — `theme:` on the home entry, the
  // wiki-wide sibling of `site:`. Like `site`, it is read from HOME and not the
  // current entry, so a sub-page never flips the wiki's look back to `default`.
  const authorTheme = typeof homeMeta?.theme === 'string' && homeMeta.theme ? homeMeta.theme : null;
  // The two axes, resolved through the one module that owns the precedence. `theme`
  // and `light` below are the RESOLVED values every surface renders from — the raw
  // reader overrides live only in state and in the menu handlers.
  const theme = (0, _themeSelection.resolvePalette)({
    reader: readerTheme,
    author: authorTheme
  });
  const polarity = (0, _themeSelection.resolvePolarity)({
    reader: readerAppearance,
    host: hostPolarity,
    preferred: (0, _themes.preferredPolarity)(theme)
  });
  const light = polarity === 'light';
  // Existence / 404: the whole index tells us if a followed link is dead. Layout
  // files are structure, not entries, so they're excluded here (and everywhere).
  const allKeysQuery = (0, _react.useCallback)(fm => Object.keys(fm).filter(_content.isContentEntry), []);
  const idx = (0, _sdk.useMetadataQuery)(allKeysQuery);
  const keys = (0, _wiki.queryPaths)(idx);
  const indexLoaded = keys.length > 0;

  // A URL that names a FOLDER is a legitimate address, and there are two right answers
  // to it — in this order:
  //
  //   1. the folder's own `index.mdx`, if the author wrote one. Curation beats
  //      generation, and it is how a corpus overrides the listing per folder without
  //      touching the engine;
  //   2. otherwise the generated <DirectoryView> — the entries and assets that are
  //      actually there.
  //
  // Both used to be "No entry at …", which is the one answer that is false.
  const folderIndex = indexLoaded && !keys.includes(routeKey) ? (0, _directory.folderIndexKey)(routeKey, keys) : null;
  const entryKey = folderIndex ?? routeKey;
  const includePath = (0, _content.keyToInclude)(entryKey);
  const meta = (0, _sdk.useFileMetadata)(entryKey);
  const layout = (0, _layout.resolvePageLayout)(meta);
  const siteTitle = meta?.site || homeMeta?.site || 'Grove';
  // Interpreter mode (TRUST_MODES §5 / R3-213): render this entry's body through the
  // non-executable safe renderer instead of the compiled `<Include>` path.
  //
  // Read from the HOME entry (wiki-wide) OR this entry (per-entry), because the two
  // answer different questions. Wiki-wide is the interpreter declaration — a Grove
  // rendering foreign content sets it there. Per-entry exists because this corpus has
  // one document, the non-executable proof page, whose whole point is planted code that
  // must NOT execute: on the compiled path that page doesn't just look wrong, it runs
  // (R3-252). A document that is only correct as data says so itself.
  const safe = homeMeta?.render === 'safe' || meta?.render === 'safe';
  const showRails = layout === 'doc' && !meta?.view;

  // Ask the filesystem only about a key the ENTRY index already missed: an ordinary page
  // render performs no extra I/O, and this readdir replaces a 404 that was about to
  // render anyway. The index cannot answer it — it holds `.md`/`.mdx` only, so a folder
  // of assets is invisible to it.
  const unresolved = indexLoaded && !keys.includes(entryKey);
  const directory = (0, _useDirectoryListing.useDirectoryListing)(unresolved ? entryKey : null);
  const missing = unresolved && directory.status === 'none';

  // The layout chain wrapping this entry (outermost first). Needs the full
  // frontmatter map (folder convention + `frame` override), so it reads the whole
  // metadata store and re-derives when the content set or the entry changes.
  const allMeta = (0, _sdk.useAllMetadata)();

  // ── Content-carried themes (R3-316; MDX_FROM_MOUNT_SPEC D7) ─────────────────
  // The stylesheets the home entry declares (`stylesheets:`); bodies are raw CSS
  // behind frontmatter, gated by the grammar inside ContentTheme and admitted only
  // into the lowest cascade layer. A declaration that names no entry, a sheet that
  // will not read, and a sheet the grammar rejects all degrade to a status line
  // naming it — never a silent drop, never a crash.
  const stylesheets = (0, _useContentStylesheets.useContentStylesheets)(homeMeta?.stylesheets, (0, _content.homeKey)());
  const [rejectedSheet, setRejectedSheet] = (0, _react.useState)(null);
  const sheetErrors = rejectedSheet ? [...stylesheets.errors, rejectedSheet] : stylesheets.errors;

  // ── The entry gate (MDX_FROM_MOUNT_SPEC D8) ─────────────────────────────────
  // Under dispatch the index fills in while the wiki is already on screen. The files
  // that decide how THIS entry renders — itself, home, its layouts, its `frame:` — are
  // read ahead of the rest, and the body waits for them: an unread row reads as
  // `render` unset, which is the executing path. The chrome around it stays mounted.
  const scanGate = (0, _react.useContext)(_corpusScanContext.CorpusScanContext);
  const critical = (0, _criticalKeys.criticalKeys)(entryKey, allMeta, scanGate.readFailure);
  const criticalSig = critical.join('|');
  (0, _react.useEffect)(() => {
    scanGate.prioritize(criticalSig.split('|'));
  }, [scanGate, criticalSig]);
  const pending = (0, _entryGate.entryPending)(critical, scanGate.isSettled, stylesheets.status);
  const failure = (0, _entryGate.criticalFailure)(critical, scanGate.readFailure);
  const chain = (0, _layout.layoutChainForKey)(entryKey, allMeta);
  const frameNone = meta?.frame === 'none' || meta?.frame === false;

  // R3-309 — the nav arrangement is the ROOT layout's to choose (`nav: top` in the
  // outermost _layout.mdx's frontmatter; the default shell and the starters read the
  // same value through the shell). Undeclared or unknown → 'side', the arrangement
  // Grove has always shipped — never an unstyled page.
  const navMode = (0, _layout.resolveNavMode)(chain.length ? allMeta[chain[0]] : undefined);
  const useDefault = chain.length === 0 && !frameNone;

  // Every navigation starts at the top of the entry, except one aimed at a section. The
  // ref goes on `.device__scroll` below — the only thing on the page that scrolls.
  const scrollRef = (0, _useScrollReset.useScrollReset)(entryKey, hash);

  // Reading time: read the entry body once per entry.
  (0, _react.useEffect)(() => {
    let active = true;
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setMins(0);
    _fs.default.promises.readFile((0, _content.keyToFsPath)(entryKey), 'utf8').then(b => {
      if (active) setMins((0, _wiki.readingTime)((0, _wiki.stripFrontmatter)(String(b))));
    }).catch(() => undefined);
    return () => {
      active = false;
    };
  }, [entryKey]);

  // Records, not tab-encoded paths (R3-276a): the query selects `{ path, label }`
  // and the hook returns them as-is — no fake-path encoding round-trip.
  const navResult = (0, _sdk.useMetadataQuery)(_queries.navQuery);
  const navItems = (0, _wiki.queryRecords)(navResult).map(({
    path,
    label
  }) => ({
    key: path,
    href: (0, _content.keyToHref)(path),
    label
  }));

  // Closest-match suggestion for a 404 (shared namespace or name overlap).
  const suggestion = missing ? keys.map(k => ({
    k,
    score: overlap(k, entryKey)
  })).sort((a, b) => b.score - a.score)[0]?.k : undefined;
  const shell = {
    theme,
    setTheme: chooseTheme,
    light,
    setLight: choosePolarity,
    menuOpen,
    setMenuOpen,
    searchOpen,
    setSearchOpen,
    drawerOpen,
    setDrawerOpen,
    vw,
    navMode,
    writable,
    openEditor,
    editBusy,
    editRefused,
    editHint,
    siteTitle,
    safe,
    navItems,
    entryKey,
    includePath,
    layout,
    showRails,
    mins,
    missing,
    suggestion,
    directory
  };

  // The bundle scope handed to CONTENT (R3-174; MDX_FROM_MOUNT_SPEC §2, §7 1a).
  //
  // A component the bundle ships cannot import this engine — it would resolve a second
  // copy from the registry, with its own `contentRoot` module state, and answer about the
  // wrong bundle — so everything it needs about the bundle arrives through the SDK, which
  // both sides genuinely share (one `/node_modules` per frame). Three facts, and each is
  // one a content component cannot derive for itself:
  //
  //  • `root` — so metadata keys can be rebased off the mount prefix. Content must never
  //    see `/mnt/<hash>/…`: it is host knowledge the viewer reads THROUGH but does not
  //    publish (the property `DirectoryList.test.tsx` pins), and it is not stable across
  //    loads, so anything content stored or linked with it would rot.
  //  • `entry` — the entry being READ, not the file the component sits in. A component in
  //    a `_layout.mdx` wraps the entry, so `<Include>`'s own module identity would name
  //    the layout; furniture in the layout chain (a status line, a dependency rail) needs
  //    the page it is describing.
  //  • `toHref` — because bundle-path→URL is this VIEWER's policy and the two packagings
  //    genuinely disagree (`urlAnchor`). Content that computed its own hrefs would be
  //    correct in exactly one packaging, which is the mode-invariance rule
  //    (PLATFORM_LAYERING §1.1) broken in the least visible possible way.
  // `contentRoot` is module state settled at boot, so it is read here — into a local the
  // memo can list as a dependency — rather than inside the factory. Calling it inside
  // would close over a value the dependency list does not name, which the React Compiler
  // correctly refuses to preserve memoization across.
  // Built fresh each render, like everything else in this component — no hand-memoization
  // (the rest of the file has none either; `react-hooks/preserve-manual-memoization`
  // rejects one here because `entryKey` derives from the metadata query's array).
  //
  // That is safe because the EXPENSIVE half does not key on this object's identity: the
  // SDK's `useBundleEntries` destructures `{root, toHref}` and memoizes on those, and both
  // are stable — `root` is a string compared by value, `toHref` is the module-scope
  // `bundleHref` above. A new wrapper re-renders consumers (cheap); it does not re-derive
  // 800-odd entries. Making `toHref` a closure would silently undo that, which is the
  // whole reason it is not one.
  const bundleRoot = (0, _content.contentDir)().replace(/\/+$/, '');
  const bundleEntry = (0, _bundle.toBundlePath)(entryKey, bundleRoot);
  const bundleScope = {
    root: bundleRoot,
    entry: bundleEntry,
    toHref: bundleHref
  };
  return (
    /*#__PURE__*/
    // R3-277b: declare the enclosing bundle for the platform's link-space consumers
    // (the shared resolver's bundle-anchored absolute + `$fs:` handling read this).
    // R3-482: the SDK pin (^0.72.0, #75) reads `bundleRoot` new-then-old, so the new
    // spelling is stated alone — the deprecated `corpusRoot` stays in the type for
    // older consumers (mdx-plugins' forever-compat) but no longer here.
    (0, _jsxRuntime.jsx)(_linkSpace.LinkSpaceContext.Provider, {
      value: {
        bundleRoot: (0, _contentRoot.getContentRoot)(),
        // R3-184 S2 (PERSISTENCE_SPEC §8.3) — the `$fs:` clamp, on this render path.
        // The clamp that is IN FORCE lives in `lib/content.ts` (`linkSpaceOpts`):
        // `hrefTargetKey` is where a corpus document's link targets actually
        // resolve (grove's own WikiLink override routes there), and it passes
        // `bundleChrooted: isDispatched()` to the shared resolver (R3-319's
        // chroot), so a dispatched corpus document's `$fs:/mnt/{hash}/…` cannot
        // name a federated mount materialised beside it — the app-level mount
        // point is not a corpus path — and the fork's `$fs:` stays
        // mount-absolute. THIS field carries the same flag for the SDK's generic
        // component consumers (WikiLink/MDXComponents): the pinned SDK 0.72.0
        // does not forward it, so it is decided-but-not-consumed until a
        // forwarding release is published and pinned — the booked follow-up,
        // stated here rather than blurred (§8.3's dated note:
        // built-but-not-in-force is a materially different state from done).
        bundleChrooted: (0, _contentRoot.isDispatched)()
      },
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_bundle.BundleContext, {
        value: bundleScope,
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_shell.GroveShellContext.Provider, {
          value: shell,
          children: /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
            className: "grove-root",
            "data-vw": vw,
            "data-nav": navMode,
            "data-grove-theme": theme === 'default' ? undefined : theme,
            "data-theme": polarity,
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_ThemeAssets.default, {
              declarations: (0, _themeFonts.themeAssetsFor)(theme)
            }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_ContentTheme.default, {
              sheets: stylesheets.sheets,
              onRejected: (path, v) => setRejectedSheet(`${path}:${v.line} — ${v.reason}`)
            }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_sdk.ScrollRestoration, {
              scroller: scrollRef
            }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
              className: "device__scroll",
              ref: scrollRef,
              children: [sheetErrors.length > 0 ? /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
                className: "grove-decl-error",
                role: "status",
                children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("strong", {
                  children: "A stylesheet this corpus declares could not be applied."
                }), /*#__PURE__*/(0, _jsxRuntime.jsx)("ul", {
                  children: sheetErrors.map((e, i) => /*#__PURE__*/(0, _jsxRuntime.jsx)("li", {
                    children: e
                  }, i))
                })]
              }) : null, rejectedComponents.length > 0 ? /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
                className: "grove-decl-error",
                role: "status",
                children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("strong", {
                  children: "This corpus declares components that could not be loaded."
                }), /*#__PURE__*/(0, _jsxRuntime.jsx)("ul", {
                  children: rejectedComponents.map(r => /*#__PURE__*/(0, _jsxRuntime.jsxs)("li", {
                    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("code", {
                      children: r.name
                    }), " \u2014 ", r.reason]
                  }, r.name))
                })]
              }) : null, /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
                className: "grove-shell",
                "data-nav": frameNone ? undefined : navMode,
                children: failure ? /*#__PURE__*/(0, _jsxRuntime.jsx)(_BootMessage.default, {
                  children: failure
                }) : pending ? /*#__PURE__*/(0, _jsxRuntime.jsx)(_BootMessage.default, {}) : renderLayers(chain, useDefault, safe)
              })]
            }), searchOpen ? /*#__PURE__*/(0, _jsxRuntime.jsx)(_Search.default, {
              onClose: () => setSearchOpen(false)
            }) : null, drawerOpen ? /*#__PURE__*/(0, _jsxRuntime.jsx)(_Drawer.default, {
              siteTitle: siteTitle,
              nav: navItems.map(n => ({
                href: n.href,
                label: n.label,
                cur: n.key === entryKey
              })),
              onClose: () => setDrawerOpen(false)
            }) : null, /*#__PURE__*/(0, _jsxRuntime.jsx)(_GroveAgent.default, {
              writable: writable,
              entryKey: entryKey,
              entryTitle: (0, _queries.plainLabel)(meta?.title || 'this entry')
            })]
          })
        })
      })
    })
  );
}

// Crude closest-match score for the 404 suggestion: shared namespace + name chars.
_s(GroveWiki, "+8nsTuAElvrC/S4vXZDqmpDVaYQ=", false, function () {
  return [_sdk.useHostTheme, _useEditAffordance.useEditAffordance, _sdk.useFileMetadata, _sdk.useMetadataQuery, _sdk.useFileMetadata, _useDirectoryListing.useDirectoryListing, _sdk.useAllMetadata, _useContentStylesheets.useContentStylesheets, _useScrollReset.useScrollReset, _sdk.useMetadataQuery];
});
_c = GroveWiki;
function overlap(a, b) {
  const an = a.replace((0, _content.contentDir)(), '').replace(/\.mdx?$/, '');
  const bn = b.replace((0, _content.contentDir)(), '').replace(/\.mdx?$/, '');
  const aNs = an.split('/').slice(0, -1).join('/');
  const bNs = bn.split('/').slice(0, -1).join('/');
  let score = aNs && aNs === bNs ? 5 : 0;
  const aName = an.split('/').pop() || '';
  const bName = bn.split('/').pop() || '';
  for (const ch of new Set(aName)) if (bName.includes(ch)) score++;
  return score;
}
var _c;
$RefreshReg$(_c, "GroveWiki");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX2ZzIiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsIl9zZGsiLCJfVGlua2VyYWJsZUNvbnRleHQiLCJfbGlua1NwYWNlIiwiX2J1bmRsZSIsIl9jb250ZW50IiwiX3dpa2kiLCJfcXVlcmllcyIsIl9sYXlvdXQiLCJfZGlyZWN0b3J5IiwiX3RoZW1lU2VsZWN0aW9uIiwiX3RoZW1lcyIsIl91c2VEaXJlY3RvcnlMaXN0aW5nIiwiX3VzZVNjcm9sbFJlc2V0IiwiX3VzZUVkaXRBZmZvcmRhbmNlIiwiX2NvbnRlbnRSb290IiwiX3NoZWxsIiwiX1BhZ2VWaWV3IiwiX1NhZmVMYXlvdXQiLCJfRGVmYXVsdExheW91dCIsIl9TZWFyY2giLCJfRHJhd2VyIiwiX0dyb3ZlQWdlbnQiLCJfVGhlbWVBc3NldHMiLCJfQ29udGVudFRoZW1lIiwiX0Jvb3RNZXNzYWdlIiwiX3RoZW1lRm9udHMiLCJfdXNlQ29udGVudFN0eWxlc2hlZXRzIiwiX2NyaXRpY2FsS2V5cyIsIl9lbnRyeUdhdGUiLCJfY29ycHVzU2NhbkNvbnRleHQiLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwicmVhZFByZWYiLCJrIiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsIndyaXRlUHJlZiIsInYiLCJzZXRJdGVtIiwiYnVuZGxlSHJlZiIsImJ1bmRsZVBhdGgiLCJhYnNvbHV0ZSIsImZyb21CdW5kbGVQYXRoIiwiY29udGVudERpciIsInJlcGxhY2UiLCJrZXlUb0hyZWYiLCJyZW5kZXJMYXllcnMiLCJjaGFpbiIsInVzZURlZmF1bHQiLCJzYWZlIiwibm9kZSIsImpzeCIsIk91dGxldENvbnRleHQiLCJQcm92aWRlciIsInZhbHVlIiwiY2hpbGRyZW4iLCJpIiwibGVuZ3RoIiwiaW5uZXIiLCJsYXlvdXRLZXkiLCJJbmNsdWRlIiwiZmlsZW5hbWUiLCJiYXNlTW9kdWxlIiwibW9kdWxlIiwiR3JvdmVXaWtpIiwicmVhZE9ubHkiLCJyZWplY3RlZENvbXBvbmVudHMiLCJjdHgiLCJ1c2VDb250ZXh0IiwiVGlua2VyYWJsZUNvbnRleHQiLCJzYW5kYm94UGF0aCIsIm5hdmlnYXRpb25TdGF0ZSIsImhhc2giLCJyZWFkZXJUaGVtZSIsInNldFJlYWRlclRoZW1lIiwidXNlU3RhdGUiLCJyZWFkZXJBcHBlYXJhbmNlIiwic2V0UmVhZGVyQXBwZWFyYW5jZSIsInAiLCJjaG9vc2VUaGVtZSIsImlkIiwiY2hvb3NlUG9sYXJpdHkiLCJ3YW50TGlnaHQiLCJmcmFtZWQiLCJ3aW5kb3ciLCJwYXJlbnQiLCJob3N0VGhlbWUiLCJ1c2VIb3N0VGhlbWUiLCJob3N0UG9sYXJpdHkiLCJtZW51T3BlbiIsInNldE1lbnVPcGVuIiwic2VhcmNoT3BlbiIsInNldFNlYXJjaE9wZW4iLCJkcmF3ZXJPcGVuIiwic2V0RHJhd2VyT3BlbiIsIm1pbnMiLCJzZXRNaW5zIiwidnciLCJzZXRWdyIsIm1hdGNoTWVkaWEiLCJtYXRjaGVzIiwidXNlRWZmZWN0IiwibXEiLCJvbiIsImFkZEV2ZW50TGlzdGVuZXIiLCJyZW1vdmVFdmVudExpc3RlbmVyIiwibWV0YUtleSIsImN0cmxLZXkiLCJrZXkiLCJ0b0xvd2VyQ2FzZSIsInByZXZlbnREZWZhdWx0IiwibyIsIndyaXRhYmxlIiwiYnVzeSIsImVkaXRCdXN5IiwicmVmdXNlZCIsImVkaXRSZWZ1c2VkIiwib3BlbkVkaXRvciIsImVkaXRIaW50IiwidXNlRWRpdEFmZm9yZGFuY2UiLCJyb3V0ZUtleSIsInNhbmRib3hQYXRoVG9LZXkiLCJob21lS2V5IiwiaG9tZU1ldGEiLCJ1c2VGaWxlTWV0YWRhdGEiLCJhdXRob3JUaGVtZSIsInRoZW1lIiwicmVzb2x2ZVBhbGV0dGUiLCJyZWFkZXIiLCJhdXRob3IiLCJwb2xhcml0eSIsInJlc29sdmVQb2xhcml0eSIsImhvc3QiLCJwcmVmZXJyZWQiLCJwcmVmZXJyZWRQb2xhcml0eSIsImxpZ2h0IiwiYWxsS2V5c1F1ZXJ5IiwidXNlQ2FsbGJhY2siLCJmbSIsIk9iamVjdCIsImtleXMiLCJmaWx0ZXIiLCJpc0NvbnRlbnRFbnRyeSIsImlkeCIsInVzZU1ldGFkYXRhUXVlcnkiLCJxdWVyeVBhdGhzIiwiaW5kZXhMb2FkZWQiLCJmb2xkZXJJbmRleCIsImluY2x1ZGVzIiwiZm9sZGVySW5kZXhLZXkiLCJlbnRyeUtleSIsImluY2x1ZGVQYXRoIiwia2V5VG9JbmNsdWRlIiwibWV0YSIsImxheW91dCIsInJlc29sdmVQYWdlTGF5b3V0Iiwic2l0ZVRpdGxlIiwic2l0ZSIsInJlbmRlciIsInNob3dSYWlscyIsInZpZXciLCJ1bnJlc29sdmVkIiwiZGlyZWN0b3J5IiwidXNlRGlyZWN0b3J5TGlzdGluZyIsIm1pc3NpbmciLCJzdGF0dXMiLCJhbGxNZXRhIiwidXNlQWxsTWV0YWRhdGEiLCJzdHlsZXNoZWV0cyIsInVzZUNvbnRlbnRTdHlsZXNoZWV0cyIsInJlamVjdGVkU2hlZXQiLCJzZXRSZWplY3RlZFNoZWV0Iiwic2hlZXRFcnJvcnMiLCJlcnJvcnMiLCJzY2FuR2F0ZSIsIkNvcnB1c1NjYW5Db250ZXh0IiwiY3JpdGljYWwiLCJjcml0aWNhbEtleXMiLCJyZWFkRmFpbHVyZSIsImNyaXRpY2FsU2lnIiwiam9pbiIsInByaW9yaXRpemUiLCJzcGxpdCIsInBlbmRpbmciLCJlbnRyeVBlbmRpbmciLCJpc1NldHRsZWQiLCJmYWlsdXJlIiwiY3JpdGljYWxGYWlsdXJlIiwibGF5b3V0Q2hhaW5Gb3JLZXkiLCJmcmFtZU5vbmUiLCJmcmFtZSIsIm5hdk1vZGUiLCJyZXNvbHZlTmF2TW9kZSIsInVuZGVmaW5lZCIsInNjcm9sbFJlZiIsInVzZVNjcm9sbFJlc2V0IiwiYWN0aXZlIiwiZnMiLCJwcm9taXNlcyIsInJlYWRGaWxlIiwia2V5VG9Gc1BhdGgiLCJ0aGVuIiwiYiIsInJlYWRpbmdUaW1lIiwic3RyaXBGcm9udG1hdHRlciIsIlN0cmluZyIsImNhdGNoIiwibmF2UmVzdWx0IiwibmF2UXVlcnkiLCJuYXZJdGVtcyIsInF1ZXJ5UmVjb3JkcyIsIm1hcCIsInBhdGgiLCJsYWJlbCIsImhyZWYiLCJzdWdnZXN0aW9uIiwic2NvcmUiLCJvdmVybGFwIiwic29ydCIsImEiLCJzaGVsbCIsInNldFRoZW1lIiwic2V0TGlnaHQiLCJidW5kbGVSb290IiwiYnVuZGxlRW50cnkiLCJ0b0J1bmRsZVBhdGgiLCJidW5kbGVTY29wZSIsInJvb3QiLCJlbnRyeSIsInRvSHJlZiIsIkxpbmtTcGFjZUNvbnRleHQiLCJnZXRDb250ZW50Um9vdCIsImJ1bmRsZUNocm9vdGVkIiwiaXNEaXNwYXRjaGVkIiwiQnVuZGxlQ29udGV4dCIsIkdyb3ZlU2hlbGxDb250ZXh0IiwianN4cyIsImNsYXNzTmFtZSIsImRlY2xhcmF0aW9ucyIsInRoZW1lQXNzZXRzRm9yIiwic2hlZXRzIiwib25SZWplY3RlZCIsImxpbmUiLCJyZWFzb24iLCJTY3JvbGxSZXN0b3JhdGlvbiIsInNjcm9sbGVyIiwicmVmIiwicm9sZSIsInIiLCJuYW1lIiwib25DbG9zZSIsIm5hdiIsIm4iLCJjdXIiLCJlbnRyeVRpdGxlIiwicGxhaW5MYWJlbCIsInRpdGxlIiwiX2MiLCJhbiIsImJuIiwiYU5zIiwic2xpY2UiLCJiTnMiLCJhTmFtZSIsInBvcCIsImJOYW1lIiwiY2giLCJTZXQiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJHcm92ZVdpa2kudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHBsaWNpdC1hbnkgKi9cbmltcG9ydCB7IHVzZUNhbGxiYWNrLCB1c2VDb250ZXh0LCB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHR5cGUgeyBSZWFjdE5vZGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgZnMgZnJvbSAnZnMnO1xuaW1wb3J0IHR5cGUgeyBNZXRhZGF0YSB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrJztcbmltcG9ydCB7XG4gIEluY2x1ZGUsXG4gIFNjcm9sbFJlc3RvcmF0aW9uLFxuICB1c2VBbGxNZXRhZGF0YSxcbiAgdXNlRmlsZU1ldGFkYXRhLFxuICB1c2VIb3N0VGhlbWUsXG4gIHVzZU1ldGFkYXRhUXVlcnksXG59IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrJztcbmltcG9ydCB7IFRpbmtlcmFibGVDb250ZXh0IH0gZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9zZGsvVGlua2VyYWJsZUNvbnRleHQnO1xuaW1wb3J0IHsgTGlua1NwYWNlQ29udGV4dCB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrL2xpbmtTcGFjZSc7XG5pbXBvcnQgeyBCdW5kbGVDb250ZXh0LCB0b0J1bmRsZVBhdGgsIGZyb21CdW5kbGVQYXRoIH0gZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9zZGsvYnVuZGxlJztcbmltcG9ydCB7XG4gIGNvbnRlbnREaXIsXG4gIGhvbWVLZXksXG4gIGlzQ29udGVudEVudHJ5LFxuICBrZXlUb0ZzUGF0aCxcbiAga2V5VG9IcmVmLFxuICBrZXlUb0luY2x1ZGUsXG4gIHNhbmRib3hQYXRoVG9LZXksXG59IGZyb20gJy4vbGliL2NvbnRlbnQnO1xuaW1wb3J0IHsgcXVlcnlQYXRocywgcXVlcnlSZWNvcmRzLCByZWFkaW5nVGltZSwgc3RyaXBGcm9udG1hdHRlciB9IGZyb20gJy4vbGliL3dpa2knO1xuaW1wb3J0IHsgbmF2UXVlcnksIHBsYWluTGFiZWwgfSBmcm9tICcuL2xpYi9xdWVyaWVzJztcbmltcG9ydCB0eXBlIHsgTmF2UmVjb3JkIH0gZnJvbSAnLi9saWIvcXVlcmllcyc7XG5pbXBvcnQgeyBsYXlvdXRDaGFpbkZvcktleSwgcmVzb2x2ZU5hdk1vZGUsIHJlc29sdmVQYWdlTGF5b3V0IH0gZnJvbSAnLi9saWIvbGF5b3V0JztcbmltcG9ydCB7IGZvbGRlckluZGV4S2V5IH0gZnJvbSAnLi9saWIvZGlyZWN0b3J5JztcbmltcG9ydCB7IHJlc29sdmVQYWxldHRlLCByZXNvbHZlUG9sYXJpdHksIHR5cGUgUG9sYXJpdHkgfSBmcm9tICcuL2xpYi90aGVtZVNlbGVjdGlvbic7XG5pbXBvcnQgeyBwcmVmZXJyZWRQb2xhcml0eSB9IGZyb20gJy4vZGF0YS90aGVtZXMnO1xuaW1wb3J0IHsgdXNlRGlyZWN0b3J5TGlzdGluZyB9IGZyb20gJy4vaG9va3MvdXNlRGlyZWN0b3J5TGlzdGluZyc7XG5pbXBvcnQgeyB1c2VTY3JvbGxSZXNldCB9IGZyb20gJy4vaG9va3MvdXNlU2Nyb2xsUmVzZXQnO1xuaW1wb3J0IHsgdXNlRWRpdEFmZm9yZGFuY2UgfSBmcm9tICcuL2hvb2tzL3VzZUVkaXRBZmZvcmRhbmNlJztcbmltcG9ydCB7IGdldENvbnRlbnRSb290LCBpc0Rpc3BhdGNoZWQgfSBmcm9tICcuL2xpYi9jb250ZW50Um9vdCc7XG5pbXBvcnQgdHlwZSB7IFJlamVjdGVkQ29tcG9uZW50IH0gZnJvbSAnLi9saWIvY29ycHVzQ29tcG9uZW50cyc7XG5pbXBvcnQgeyBHcm92ZVNoZWxsQ29udGV4dCwgT3V0bGV0Q29udGV4dCB9IGZyb20gJy4vbGliL3NoZWxsJztcbmltcG9ydCB0eXBlIHsgR3JvdmVTaGVsbCwgTmF2SXRlbSB9IGZyb20gJy4vbGliL3NoZWxsJztcbmltcG9ydCBQYWdlVmlldyBmcm9tICcuL2NvbXBvbmVudHMvUGFnZVZpZXcnO1xuaW1wb3J0IFNhZmVMYXlvdXQgZnJvbSAnLi9jb21wb25lbnRzL1NhZmVMYXlvdXQnO1xuaW1wb3J0IERlZmF1bHRMYXlvdXQgZnJvbSAnLi9jb21wb25lbnRzL0RlZmF1bHRMYXlvdXQnO1xuaW1wb3J0IFNlYXJjaCBmcm9tICcuL2NvbXBvbmVudHMvU2VhcmNoJztcbmltcG9ydCBEcmF3ZXIgZnJvbSAnLi9jb21wb25lbnRzL0RyYXdlcic7XG5pbXBvcnQgR3JvdmVBZ2VudCBmcm9tICcuL2NvbXBvbmVudHMvR3JvdmVBZ2VudCc7XG5pbXBvcnQgVGhlbWVBc3NldHMgZnJvbSAnLi9jb21wb25lbnRzL1RoZW1lQXNzZXRzJztcbmltcG9ydCBDb250ZW50VGhlbWUgZnJvbSAnLi9jb21wb25lbnRzL0NvbnRlbnRUaGVtZSc7XG5pbXBvcnQgQm9vdE1lc3NhZ2UgZnJvbSAnLi9jb21wb25lbnRzL0Jvb3RNZXNzYWdlJztcbmltcG9ydCB7IHRoZW1lQXNzZXRzRm9yIH0gZnJvbSAnLi9kYXRhL3RoZW1lRm9udHMnO1xuaW1wb3J0IHsgdXNlQ29udGVudFN0eWxlc2hlZXRzIH0gZnJvbSAnLi9ob29rcy91c2VDb250ZW50U3R5bGVzaGVldHMnO1xuaW1wb3J0IHsgY3JpdGljYWxLZXlzIH0gZnJvbSAnLi9saWIvY3JpdGljYWxLZXlzJztcbmltcG9ydCB7IGNyaXRpY2FsRmFpbHVyZSwgZW50cnlQZW5kaW5nIH0gZnJvbSAnLi9saWIvZW50cnlHYXRlJztcbmltcG9ydCB7IENvcnB1c1NjYW5Db250ZXh0IH0gZnJvbSAnLi9saWIvY29ycHVzU2NhbkNvbnRleHQnO1xuXG5kZWNsYXJlIGNvbnN0IG1vZHVsZTogYW55O1xuXG5mdW5jdGlvbiByZWFkUHJlZihrOiBzdHJpbmcpOiBzdHJpbmcgfCBudWxsIHtcbiAgdHJ5IHtcbiAgICByZXR1cm4gbG9jYWxTdG9yYWdlLmdldEl0ZW0oayk7XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiBudWxsO1xuICB9XG59XG5mdW5jdGlvbiB3cml0ZVByZWYoazogc3RyaW5nLCB2OiBzdHJpbmcpOiB2b2lkIHtcbiAgdHJ5IHtcbiAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShrLCB2KTtcbiAgfSBjYXRjaCB7XG4gICAgLyogaWdub3JlICovXG4gIH1cbn1cblxuLy8gQnVuZGxlLWFic29sdXRlIHBhdGgg4oaSIHRoZSBocmVmIHRoYXQgbmF2aWdhdGVzIHRvIGl0LCBmb3IgQ09OVEVOVCAoUjMtMTc0KS5cbi8vXG4vLyBNb2R1bGUgc2NvcGUsIGFuZCB0aGF0IGlzIGxvYWQtYmVhcmluZyByYXRoZXIgdGhhbiB0aWRpbmVzczogdGhpcyBmdW5jdGlvbiBpcyBoYW5kZWQgdG9cbi8vIGNvbnRlbnQgdGhyb3VnaCBgQnVuZGxlQ29udGV4dGAsIGFuZCB0aGUgU0RLJ3MgYHVzZUJ1bmRsZUVudHJpZXNgIG1lbW9pemVzIG9uIGl0c1xuLy8gaWRlbnRpdHkuIEEgY2xvc3VyZSByZWJ1aWx0IGVhY2ggcmVuZGVyIHdvdWxkIG1ha2UgdGhhdCBtZW1vIG5ldmVyIGhvbGQsIHNvIHRoZSBob29rIHRoZVxuLy8gU0RLIGRvY3VtZW50cyBhcyBcInNhZmUgaW4gYSBkZXBlbmRlbmN5IGFycmF5XCIgd291bGQgcXVpZXRseSBzdG9wIGJlaW5nIG9uZSDigJQgZnJvbSB0aGVcbi8vIFBST1ZJREVSJ3Mgc2lkZSwgd2hlcmUgbm9ib2R5IHVzaW5nIGl0IHdvdWxkIHRoaW5rIHRvIGxvb2suIE5vdGhpbmcgaGVyZSBpcyByZWFjdGl2ZTpcbi8vIGBjb250ZW50RGlyKClgIGlzIGJvb3Qtc2V0dGxlZCBtb2R1bGUgc3RhdGUgYW5kIGBrZXlUb0hyZWZgIGlzIGEgcHVyZSBmdW5jdGlvbiBvZiBpdC5cbmZ1bmN0aW9uIGJ1bmRsZUhyZWYoYnVuZGxlUGF0aDogc3RyaW5nKTogc3RyaW5nIHtcbiAgY29uc3QgYWJzb2x1dGUgPSBmcm9tQnVuZGxlUGF0aChidW5kbGVQYXRoLCBjb250ZW50RGlyKCkucmVwbGFjZSgvXFwvKyQvLCAnJykpO1xuICByZXR1cm4gYWJzb2x1dGUgPT09IG51bGwgPyBidW5kbGVQYXRoIDoga2V5VG9IcmVmKGFic29sdXRlKTtcbn1cblxuLy8gQnVpbGQgdGhlIG5lc3RlZCByZW5kZXIgZm9yIGEgbGF5b3V0IGNoYWluIChvdXRlcm1vc3QgZmlyc3QpLiBFYWNoIGxheWVyIHdyYXBzXG4vLyBpdHMgYF9sYXlvdXQubWR4YCAob3IgdGhlIGJ1aWx0LWluIDxEZWZhdWx0TGF5b3V0Lz4pIGluIGFuIE91dGxldENvbnRleHQgd2hvc2Vcbi8vIHZhbHVlIGlzIHRoZSBub2RlIG9uZSBsZXZlbCBpbndhcmQg4oCUIHNvIGA8T3V0bGV0Lz5gIGluc2lkZSBhIGxheWVyIHJlbmRlcnMgdGhlXG4vLyBuZXh0IGxheWVyLCBhbmQgdGhlIGlubmVybW9zdCA8T3V0bGV0Lz4gcmVuZGVycyB0aGUgcGFnZSAoPFBhZ2VWaWV3Lz4pLlxuLy9cbi8vIGBzYWZlYCBwaWNrcyB0aGUgUkVOREVSRVIgZm9yIGVhY2ggbGF5ZXIsIGV4YWN0bHkgYXMgaXQgZG9lcyBmb3IgZW50cnkgYm9kaWVzIGluXG4vLyA8UGFnZVZpZXcvPiAoUjMtMjYzKS4gQmVmb3JlIHRoaXMsIGV2ZXJ5IGxheWVyIHdlbnQgdGhyb3VnaCA8SW5jbHVkZT4gd2hhdGV2ZXIgdGhlIHdpa2lcbi8vIGRlY2xhcmVkIOKAlCBzbyBhbiBpbnRlcnByZXRlci1tb2RlIHdpa2kgc3RpbGwgRVhFQ1VURUQgYXV0aG9yIEphdmFTY3JpcHQgb3V0IG9mIGl0c1xuLy8gYF9sYXlvdXQubWR4YCwgYW5kIHRoZSBub24tZXhlY3V0YWJsZSBndWFyYW50ZWUgaGFkIGEgaG9sZSBpbiB0aGUgc2hlbGwgcmF0aGVyIHRoYW4gaW5cbi8vIHRoZSBlbnRyaWVzLiBJdCBpcyBhbHNvIHdoYXQgbWFrZXMgdGhlIGNoYWluIHdvcmsgYXQgYWxsIHVuZGVyIGRpc3BhdGNoOiA8SW5jbHVkZT5cbi8vIGV2YWx1YXRlcyBhbiBhcHAtc291cmNlIG1vZHVsZSwgd2hpY2ggYSBsYXlvdXQgcmVzaWRlbnQgaW4gYSBjb250ZW50IG1vdW50IGlzIG5vdC5cbmZ1bmN0aW9uIHJlbmRlckxheWVycyhjaGFpbjogc3RyaW5nW10sIHVzZURlZmF1bHQ6IGJvb2xlYW4sIHNhZmU6IGJvb2xlYW4pOiBSZWFjdE5vZGUge1xuICBsZXQgbm9kZTogUmVhY3ROb2RlID0gPFBhZ2VWaWV3IC8+O1xuICBpZiAodXNlRGVmYXVsdCkge1xuICAgIHJldHVybiA8T3V0bGV0Q29udGV4dC5Qcm92aWRlciB2YWx1ZT17bm9kZX0+PERlZmF1bHRMYXlvdXQgLz48L091dGxldENvbnRleHQuUHJvdmlkZXI+O1xuICB9XG4gIGZvciAobGV0IGkgPSBjaGFpbi5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuICAgIGNvbnN0IGlubmVyID0gbm9kZTtcbiAgICBub2RlID0gKFxuICAgICAgPE91dGxldENvbnRleHQuUHJvdmlkZXIgdmFsdWU9e2lubmVyfSBrZXk9e2NoYWluW2ldfT5cbiAgICAgICAge3NhZmUgPyA8U2FmZUxheW91dCBsYXlvdXRLZXk9e2NoYWluW2ldfSAvPiA6IDxJbmNsdWRlIGZpbGVuYW1lPXtjaGFpbltpXX0gYmFzZU1vZHVsZT17bW9kdWxlfSAvPn1cbiAgICAgIDwvT3V0bGV0Q29udGV4dC5Qcm92aWRlcj5cbiAgICApO1xuICB9XG4gIHJldHVybiBub2RlO1xufVxuXG4vKipcbiAqIFRoZSB3aWtpIGl0c2VsZjogcm91dGluZywgY2hyb21lLCBhbmQgdGhlIGVudHJ5IHJlbmRlci4gRXZlcnl0aGluZyBoZXJlIHJlYWRzIHRoZVxuICogY29udGVudCByb290LCBzbyBpdCBtYXkgb25seSBtb3VudCBvbmNlIHRoYXQgcm9vdCBpcyBzZXR0bGVkIOKAlCB3aGljaCBpcyB3aHkgdGhlXG4gKiBkZWZhdWx0IGV4cG9ydCBvZiBgQXBwLnRzeGAgaXMgYSBnYXRlIGluIGZyb250IG9mIGl0IHJhdGhlciB0aGFuIHRoaXMgY29tcG9uZW50XG4gKiAoUjMtMTY5OiB1bmRlciBkaXNwYXRjaCB0aGUgcm9vdCBpcyBhIHJ1bnRpbWUgdmFsdWUsIG5vdCBgL2FwcC9jb250ZW50L2ApLlxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBHcm92ZVdpa2koe1xuICByZWFkT25seSA9IGZhbHNlLFxuICByZWplY3RlZENvbXBvbmVudHMgPSBbXSxcbn06IHtcbiAgcmVhZE9ubHk/OiBib29sZWFuO1xuICAvKiogQ29ycHVzIGNvbXBvbmVudCBkZWNsYXJhdGlvbnMgdGhhdCBjb3VsZCBub3QgYmUgbG9hZGVkIChSMy0xNzQpLiBTaG93biwgbm90XG4gICAqICBzd2FsbG93ZWQ6IGEgYDxSb2FkbWFwQm9hcmQvPmAgdGhhdCBzaWxlbnRseSBuZXZlciBhcHBlYXJzIGlzIGluZGlzdGluZ3Vpc2hhYmxlIGZyb21cbiAgICogIG9uZSBub2JvZHkgd3JvdGUsIGFuZCB0aGUgYXV0aG9yIGhhcyBubyBvdGhlciBjaGFubmVsIHRvIGxlYXJuIHdoaWNoIGl0IHdhcy4gKi9cbiAgcmVqZWN0ZWRDb21wb25lbnRzPzogUmVqZWN0ZWRDb21wb25lbnRbXTtcbn0pIHtcbiAgY29uc3QgY3R4ID0gdXNlQ29udGV4dChUaW5rZXJhYmxlQ29udGV4dCkgYXMgYW55O1xuICBjb25zdCBzYW5kYm94UGF0aDogc3RyaW5nID0gY3R4Py5uYXZpZ2F0aW9uU3RhdGU/LnNhbmRib3hQYXRoIHx8ICcvJztcbiAgY29uc3QgaGFzaDogc3RyaW5nID0gY3R4Py5uYXZpZ2F0aW9uU3RhdGU/Lmhhc2ggPz8gJyc7XG5cbiAgLy8g4pSA4pSAIFRoZW1lIHNlbGVjdGlvbiAoUjMtMzA4LCAwMi10aGVtZS1jb250cmFjdCDCpzQpIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAvL1xuICAvLyBUd28gSU5ERVBFTkRFTlQgYXhlcyB3aXRoIHRocmVlIHNvdXJjZXMsIHJlc29sdmVkIHRocm91Z2ggT05FIG1vZHVsZVxuICAvLyAobGliL3RoZW1lU2VsZWN0aW9uKSBzbyBubyBzdXJmYWNlIHJlLWRlcml2ZXMgdGhlIHByZWNlZGVuY2U6XG4gIC8vXG4gIC8vICAgcGFsZXR0ZSAgPSByZWFkZXIgb3ZlcnJpZGUsIGVsc2UgdGhlIGF1dGhvcidzIGB0aGVtZTpgIG9uIHRoZSBob21lIGVudHJ5LCBlbHNlIGRlZmF1bHRcbiAgLy8gICBwb2xhcml0eSA9IHJlYWRlciBvdmVycmlkZSwgZWxzZSB0aGUgaG9zdCdzIHRoZW1lLCBlbHNlIHRoZSBwYWxldHRlJ3MgcHJlZmVycmVkXG4gIC8vXG4gIC8vIFRoZSBzdG9yZWQgcHJlZnMgYXJlIE9WRVJSSURFUywgbnVsbGFibGUgYnkgbmF0dXJlOiBhYnNlbnQgdW50aWwgdGhlIHJlYWRlclxuICAvLyBhY3RzLCB3aGljaCBpcyB3aGF0IGdpdmVzIHRoZSBhdXRob3IncyBkZWNsYXJhdGlvbiBpdHMgdHVybi4gVGhleSBhcmUgd3JpdHRlblxuICAvLyBieSB0aGUgdXNlciBhY3Rpb25zIChjaG9vc2VUaGVtZS9jaG9vc2VQb2xhcml0eSksIE5FVkVSIGJ5IGFuIGVmZmVjdCBvbiBtb3VudFxuICAvLyDigJQgdGhlIG9sZCBlZmZlY3RzIHByb21vdGVkIHRoZSBpbml0aWFsIHZhbHVlIHRvIGEgcmVhZGVyIGNob2ljZSBvbiBmaXJzdFxuICAvLyB2aXNpdCwgd2hpY2ggaXMgZXhhY3RseSB3aHkgYSBgdGhlbWU6YCBkZWNsYXJhdGlvbiBjb3VsZCBuZXZlciBoYXZlIHdvbi5cbiAgLy8gKFZpc2l0b3JzIGZyb20gYmVmb3JlIHRoaXMgY2hhbmdlIGNhcnJ5IGEgbW91bnQtd3JpdHRlbiBwcmVmOyBpdCBzdGFuZHMg4oCUXG4gIC8vIHRoZXkgYXJlIEdyb3ZlIHJlYWRlcnMsIGFuZCBhIHJlYWRlciBvdXRyYW5rcyBhbiBhdXRob3IuKVxuICBjb25zdCBbcmVhZGVyVGhlbWUsIHNldFJlYWRlclRoZW1lXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KCgpID0+IHJlYWRQcmVmKCdncm92ZTp0aGVtZScpKTtcbiAgY29uc3QgW3JlYWRlckFwcGVhcmFuY2UsIHNldFJlYWRlckFwcGVhcmFuY2VdID0gdXNlU3RhdGU8UG9sYXJpdHkgfCBudWxsPigoKSA9PiB7XG4gICAgY29uc3QgcCA9IHJlYWRQcmVmKCdncm92ZTphcHBlYXJhbmNlJyk7XG4gICAgcmV0dXJuIHAgPT09ICdsaWdodCcgfHwgcCA9PT0gJ2RhcmsnID8gcCA6IG51bGw7XG4gIH0pO1xuICBjb25zdCBjaG9vc2VUaGVtZSA9IChpZDogc3RyaW5nKSA9PiB7XG4gICAgc2V0UmVhZGVyVGhlbWUoaWQpO1xuICAgIHdyaXRlUHJlZignZ3JvdmU6dGhlbWUnLCBpZCk7XG4gIH07XG4gIGNvbnN0IGNob29zZVBvbGFyaXR5ID0gKHdhbnRMaWdodDogYm9vbGVhbikgPT4ge1xuICAgIGNvbnN0IHA6IFBvbGFyaXR5ID0gd2FudExpZ2h0ID8gJ2xpZ2h0JyA6ICdkYXJrJztcbiAgICBzZXRSZWFkZXJBcHBlYXJhbmNlKHApO1xuICAgIHdyaXRlUHJlZignZ3JvdmU6YXBwZWFyYW5jZScsIHApO1xuICB9O1xuICAvLyBUaGUgaG9zdCBkcml2ZXMgUE9MQVJJVFkgT05MWSAoYHRoZW1lOnJlYWRgIGlzIHRoZSBvbmUgdGhlbWUgY2FwYWJpbGl0eSB0aGVcbiAgLy8gb3Blbi13aWtpIGJpbmRpbmcgaG9sZHMpIOKAlCBhbmQgb25seSB3aGVuIHRoZXJlIElTIGEgaG9zdC4gYHVzZUhvc3RUaGVtZWAnc1xuICAvLyBjaGFubmVsIHJlcG9ydHMgYW4gYGluaXRpYWw6ICdkYXJrJ2AgYmVmb3JlIGFueSBob3N0IHNwZWFrcywgc28gYW4gdW5mcmFtZWRcbiAgLy8gc3RhbmRhbG9uZSBgdml0ZSBkZXZgIHJlbmRlciB3b3VsZCBvdGhlcndpc2UgY2FycnkgYSBwaGFudG9tIGhvc3Qgb3BpbmlvblxuICAvLyBhbmQgZmxpcCBsaWdodC1wcmVmZXJyZWQgdGhlbWVzLiBGcmFtZWQgPT09IGEgaG9zdCBleGlzdHMgdG8gaGF2ZSBvbmUuXG4gIGNvbnN0IGZyYW1lZCA9IHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnICYmIHdpbmRvdy5wYXJlbnQgIT09IHdpbmRvdztcbiAgY29uc3QgaG9zdFRoZW1lID0gdXNlSG9zdFRoZW1lKCk7XG4gIGNvbnN0IGhvc3RQb2xhcml0eTogUG9sYXJpdHkgfCBudWxsID0gZnJhbWVkID8gaG9zdFRoZW1lIDogbnVsbDtcbiAgY29uc3QgW21lbnVPcGVuLCBzZXRNZW51T3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtzZWFyY2hPcGVuLCBzZXRTZWFyY2hPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2RyYXdlck9wZW4sIHNldERyYXdlck9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbbWlucywgc2V0TWluc10gPSB1c2VTdGF0ZSgwKTtcbiAgY29uc3QgW3Z3LCBzZXRWd10gPSB1c2VTdGF0ZTwnbW9iaWxlJyB8ICdkZXNrdG9wJz4oKCkgPT5cbiAgICB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyAmJiB3aW5kb3cubWF0Y2hNZWRpYSgnKG1heC13aWR0aDogNzIwcHgpJykubWF0Y2hlcyA/ICdtb2JpbGUnIDogJ2Rlc2t0b3AnXG4gICk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBtcSA9IHdpbmRvdy5tYXRjaE1lZGlhKCcobWF4LXdpZHRoOiA3MjBweCknKTtcbiAgICBjb25zdCBvbiA9ICgpID0+IHNldFZ3KG1xLm1hdGNoZXMgPyAnbW9iaWxlJyA6ICdkZXNrdG9wJyk7XG4gICAgbXEuYWRkRXZlbnRMaXN0ZW5lcignY2hhbmdlJywgb24pO1xuICAgIHJldHVybiAoKSA9PiBtcS5yZW1vdmVFdmVudExpc3RlbmVyKCdjaGFuZ2UnLCBvbik7XG4gIH0sIFtdKTtcblxuICAvLyDijJhLIC8gQ3RybC1LIG9wZW5zIHNlYXJjaC5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBvbiA9IChlOiBLZXlib2FyZEV2ZW50KSA9PiB7XG4gICAgICBpZiAoKGUubWV0YUtleSB8fCBlLmN0cmxLZXkpICYmIGUua2V5LnRvTG93ZXJDYXNlKCkgPT09ICdrJykge1xuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIHNldFNlYXJjaE9wZW4oKG8pID0+ICFvKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdrZXlkb3duJywgb24pO1xuICAgIHJldHVybiAoKSA9PiB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcigna2V5ZG93bicsIG9uKTtcbiAgfSwgW10pO1xuXG4gIC8vIFIzLTI2NiDigJQgZGlzcGF0Y2hlZCBjb250ZW50IElTIHdyaXRhYmxlLCBhbmQgdGhlIE1PVU5UIGRlY2lkZXMuXG4gIC8vXG4gIC8vIFRoaXMgdXNlZCB0byByZWFkIGAhaXNEaXNwYXRjaGVkKCkgJiYg4oCmYCwgd2l0aGhvbGRpbmcgZXZlcnkgZWRpdCBhZmZvcmRhbmNlIGZyb20gYVxuICAvLyBkaXNwYXRjaGVkIHZpZXdlci4gVGhlIHJlYXNvbiB3YXMgcmVhbCBidXQgdGhlIGNvbmNsdXNpb24gd2FzIG5vdDogYHJlcXVlc3RFZGl0YCBpc1xuICAvLyAqKnNlbGYtc2NvcGVkIGJ5IGNvbnRyYWN0KiosIHNvIHVuZGVyIGRpc3BhdGNoIGl0IG5hbWVzIGEgcGF0aCBpbiBHUk9WRSdzIHJlcG8gcmF0aGVyXG4gIC8vIHRoYW4gaW4gdGhlIGNvcnB1cyBvbiBzY3JlZW4uIFRoZSBmaXggaXMgYSB2ZXJiIHN3YXAsIG5vdCBhIHdpdGhoZWxkIGNhcGFiaWxpdHkg4oCUIHNlZVxuICAvLyBgbGliL2VkaXRUYXJnZXRgIOKAlCBhbmQgdGhlIGdhdGUgaXMgdGhlIGNvcnB1cyBtb3VudCdzIENVUlJFTlQgbW9kZSwgcmUtcmVhZCBvbiBldmVyeVxuICAvLyBtb3VudCBjaGFuZ2Ugc28gYSBsaXZlIHJvbGUgZG93bmdyYWRlIGhpZGVzIHRoZSBhZmZvcmRhbmNlIGluc3RlYWQgb2YgcHJvZHVjaW5nXG4gIC8vIGBFUk9GU2Agb24gY2xpY2suXG4gIGNvbnN0IHsgd3JpdGFibGUsIGJ1c3k6IGVkaXRCdXN5LCByZWZ1c2VkOiBlZGl0UmVmdXNlZCwgb3BlbkVkaXRvciwgZWRpdEhpbnQgfSA9IHVzZUVkaXRBZmZvcmRhbmNlKHJlYWRPbmx5KTtcblxuICBjb25zdCByb3V0ZUtleSA9IHNhbmRib3hQYXRoVG9LZXkoc2FuZGJveFBhdGgpIHx8IGhvbWVLZXkoKTtcbiAgLy8gVGhlIHNpdGUgYnJhbmQgaXMgYSB3aWtpLXdpZGUgY29uc3RhbnQsIHNvIHJlYWQgaXQgZnJvbSB0aGUgaG9tZSBlbnRyeSdzXG4gIC8vIGBzaXRlYCBmcm9udG1hdHRlciDigJQgbm90IHRoZSBjdXJyZW50IGVudHJ5J3MgKHdoaWNoIG9ubHkgaG9tZSB3b3VsZCBjYXJyeSksXG4gIC8vIGVsc2UgdGhlIGJyYW5kIGZsaXBzIHRvIHRoZSAnR3JvdmUnIGZhbGxiYWNrIG9uIGV2ZXJ5IHN1Yi1wYWdlLlxuICBjb25zdCBob21lTWV0YSA9IHVzZUZpbGVNZXRhZGF0YShob21lS2V5KCkpIGFzIGFueTtcbiAgLy8gUjMtMzA4OiB0aGUgYXV0aG9yJ3MgcGFsZXR0ZSBkZWNsYXJhdGlvbiDigJQgYHRoZW1lOmAgb24gdGhlIGhvbWUgZW50cnksIHRoZVxuICAvLyB3aWtpLXdpZGUgc2libGluZyBvZiBgc2l0ZTpgLiBMaWtlIGBzaXRlYCwgaXQgaXMgcmVhZCBmcm9tIEhPTUUgYW5kIG5vdCB0aGVcbiAgLy8gY3VycmVudCBlbnRyeSwgc28gYSBzdWItcGFnZSBuZXZlciBmbGlwcyB0aGUgd2lraSdzIGxvb2sgYmFjayB0byBgZGVmYXVsdGAuXG4gIGNvbnN0IGF1dGhvclRoZW1lOiBzdHJpbmcgfCBudWxsID1cbiAgICB0eXBlb2YgaG9tZU1ldGE/LnRoZW1lID09PSAnc3RyaW5nJyAmJiBob21lTWV0YS50aGVtZSA/IGhvbWVNZXRhLnRoZW1lIDogbnVsbDtcbiAgLy8gVGhlIHR3byBheGVzLCByZXNvbHZlZCB0aHJvdWdoIHRoZSBvbmUgbW9kdWxlIHRoYXQgb3ducyB0aGUgcHJlY2VkZW5jZS4gYHRoZW1lYFxuICAvLyBhbmQgYGxpZ2h0YCBiZWxvdyBhcmUgdGhlIFJFU09MVkVEIHZhbHVlcyBldmVyeSBzdXJmYWNlIHJlbmRlcnMgZnJvbSDigJQgdGhlIHJhd1xuICAvLyByZWFkZXIgb3ZlcnJpZGVzIGxpdmUgb25seSBpbiBzdGF0ZSBhbmQgaW4gdGhlIG1lbnUgaGFuZGxlcnMuXG4gIGNvbnN0IHRoZW1lID0gcmVzb2x2ZVBhbGV0dGUoeyByZWFkZXI6IHJlYWRlclRoZW1lLCBhdXRob3I6IGF1dGhvclRoZW1lIH0pO1xuICBjb25zdCBwb2xhcml0eTogUG9sYXJpdHkgPSByZXNvbHZlUG9sYXJpdHkoe1xuICAgIHJlYWRlcjogcmVhZGVyQXBwZWFyYW5jZSxcbiAgICBob3N0OiBob3N0UG9sYXJpdHksXG4gICAgcHJlZmVycmVkOiBwcmVmZXJyZWRQb2xhcml0eSh0aGVtZSksXG4gIH0pO1xuICBjb25zdCBsaWdodCA9IHBvbGFyaXR5ID09PSAnbGlnaHQnO1xuICAvLyBFeGlzdGVuY2UgLyA0MDQ6IHRoZSB3aG9sZSBpbmRleCB0ZWxscyB1cyBpZiBhIGZvbGxvd2VkIGxpbmsgaXMgZGVhZC4gTGF5b3V0XG4gIC8vIGZpbGVzIGFyZSBzdHJ1Y3R1cmUsIG5vdCBlbnRyaWVzLCBzbyB0aGV5J3JlIGV4Y2x1ZGVkIGhlcmUgKGFuZCBldmVyeXdoZXJlKS5cbiAgY29uc3QgYWxsS2V5c1F1ZXJ5ID0gdXNlQ2FsbGJhY2soKGZtOiBSZWNvcmQ8c3RyaW5nLCBhbnk+KSA9PiBPYmplY3Qua2V5cyhmbSkuZmlsdGVyKGlzQ29udGVudEVudHJ5KSwgW10pO1xuICBjb25zdCBpZHggPSB1c2VNZXRhZGF0YVF1ZXJ5KGFsbEtleXNRdWVyeSk7XG4gIGNvbnN0IGtleXM6IHN0cmluZ1tdID0gcXVlcnlQYXRocyhpZHgpO1xuICBjb25zdCBpbmRleExvYWRlZCA9IGtleXMubGVuZ3RoID4gMDtcblxuICAvLyBBIFVSTCB0aGF0IG5hbWVzIGEgRk9MREVSIGlzIGEgbGVnaXRpbWF0ZSBhZGRyZXNzLCBhbmQgdGhlcmUgYXJlIHR3byByaWdodCBhbnN3ZXJzXG4gIC8vIHRvIGl0IOKAlCBpbiB0aGlzIG9yZGVyOlxuICAvL1xuICAvLyAgIDEuIHRoZSBmb2xkZXIncyBvd24gYGluZGV4Lm1keGAsIGlmIHRoZSBhdXRob3Igd3JvdGUgb25lLiBDdXJhdGlvbiBiZWF0c1xuICAvLyAgICAgIGdlbmVyYXRpb24sIGFuZCBpdCBpcyBob3cgYSBjb3JwdXMgb3ZlcnJpZGVzIHRoZSBsaXN0aW5nIHBlciBmb2xkZXIgd2l0aG91dFxuICAvLyAgICAgIHRvdWNoaW5nIHRoZSBlbmdpbmU7XG4gIC8vICAgMi4gb3RoZXJ3aXNlIHRoZSBnZW5lcmF0ZWQgPERpcmVjdG9yeVZpZXc+IOKAlCB0aGUgZW50cmllcyBhbmQgYXNzZXRzIHRoYXQgYXJlXG4gIC8vICAgICAgYWN0dWFsbHkgdGhlcmUuXG4gIC8vXG4gIC8vIEJvdGggdXNlZCB0byBiZSBcIk5vIGVudHJ5IGF0IOKAplwiLCB3aGljaCBpcyB0aGUgb25lIGFuc3dlciB0aGF0IGlzIGZhbHNlLlxuICBjb25zdCBmb2xkZXJJbmRleCA9IGluZGV4TG9hZGVkICYmICFrZXlzLmluY2x1ZGVzKHJvdXRlS2V5KSA/IGZvbGRlckluZGV4S2V5KHJvdXRlS2V5LCBrZXlzKSA6IG51bGw7XG4gIGNvbnN0IGVudHJ5S2V5ID0gZm9sZGVySW5kZXggPz8gcm91dGVLZXk7XG4gIGNvbnN0IGluY2x1ZGVQYXRoID0ga2V5VG9JbmNsdWRlKGVudHJ5S2V5KTtcbiAgY29uc3QgbWV0YSA9IHVzZUZpbGVNZXRhZGF0YShlbnRyeUtleSkgYXMgYW55O1xuXG4gIGNvbnN0IGxheW91dCA9IHJlc29sdmVQYWdlTGF5b3V0KG1ldGEpO1xuICBjb25zdCBzaXRlVGl0bGU6IHN0cmluZyA9IG1ldGE/LnNpdGUgfHwgaG9tZU1ldGE/LnNpdGUgfHwgJ0dyb3ZlJztcbiAgLy8gSW50ZXJwcmV0ZXIgbW9kZSAoVFJVU1RfTU9ERVMgwqc1IC8gUjMtMjEzKTogcmVuZGVyIHRoaXMgZW50cnkncyBib2R5IHRocm91Z2ggdGhlXG4gIC8vIG5vbi1leGVjdXRhYmxlIHNhZmUgcmVuZGVyZXIgaW5zdGVhZCBvZiB0aGUgY29tcGlsZWQgYDxJbmNsdWRlPmAgcGF0aC5cbiAgLy9cbiAgLy8gUmVhZCBmcm9tIHRoZSBIT01FIGVudHJ5ICh3aWtpLXdpZGUpIE9SIHRoaXMgZW50cnkgKHBlci1lbnRyeSksIGJlY2F1c2UgdGhlIHR3b1xuICAvLyBhbnN3ZXIgZGlmZmVyZW50IHF1ZXN0aW9ucy4gV2lraS13aWRlIGlzIHRoZSBpbnRlcnByZXRlciBkZWNsYXJhdGlvbiDigJQgYSBHcm92ZVxuICAvLyByZW5kZXJpbmcgZm9yZWlnbiBjb250ZW50IHNldHMgaXQgdGhlcmUuIFBlci1lbnRyeSBleGlzdHMgYmVjYXVzZSB0aGlzIGNvcnB1cyBoYXNcbiAgLy8gb25lIGRvY3VtZW50LCB0aGUgbm9uLWV4ZWN1dGFibGUgcHJvb2YgcGFnZSwgd2hvc2Ugd2hvbGUgcG9pbnQgaXMgcGxhbnRlZCBjb2RlIHRoYXRcbiAgLy8gbXVzdCBOT1QgZXhlY3V0ZTogb24gdGhlIGNvbXBpbGVkIHBhdGggdGhhdCBwYWdlIGRvZXNuJ3QganVzdCBsb29rIHdyb25nLCBpdCBydW5zXG4gIC8vIChSMy0yNTIpLiBBIGRvY3VtZW50IHRoYXQgaXMgb25seSBjb3JyZWN0IGFzIGRhdGEgc2F5cyBzbyBpdHNlbGYuXG4gIGNvbnN0IHNhZmU6IGJvb2xlYW4gPSBob21lTWV0YT8ucmVuZGVyID09PSAnc2FmZScgfHwgbWV0YT8ucmVuZGVyID09PSAnc2FmZSc7XG4gIGNvbnN0IHNob3dSYWlscyA9IGxheW91dCA9PT0gJ2RvYycgJiYgIW1ldGE/LnZpZXc7XG5cblxuICAvLyBBc2sgdGhlIGZpbGVzeXN0ZW0gb25seSBhYm91dCBhIGtleSB0aGUgRU5UUlkgaW5kZXggYWxyZWFkeSBtaXNzZWQ6IGFuIG9yZGluYXJ5IHBhZ2VcbiAgLy8gcmVuZGVyIHBlcmZvcm1zIG5vIGV4dHJhIEkvTywgYW5kIHRoaXMgcmVhZGRpciByZXBsYWNlcyBhIDQwNCB0aGF0IHdhcyBhYm91dCB0b1xuICAvLyByZW5kZXIgYW55d2F5LiBUaGUgaW5kZXggY2Fubm90IGFuc3dlciBpdCDigJQgaXQgaG9sZHMgYC5tZGAvYC5tZHhgIG9ubHksIHNvIGEgZm9sZGVyXG4gIC8vIG9mIGFzc2V0cyBpcyBpbnZpc2libGUgdG8gaXQuXG4gIGNvbnN0IHVucmVzb2x2ZWQgPSBpbmRleExvYWRlZCAmJiAha2V5cy5pbmNsdWRlcyhlbnRyeUtleSk7XG4gIGNvbnN0IGRpcmVjdG9yeSA9IHVzZURpcmVjdG9yeUxpc3RpbmcodW5yZXNvbHZlZCA/IGVudHJ5S2V5IDogbnVsbCk7XG4gIGNvbnN0IG1pc3NpbmcgPSB1bnJlc29sdmVkICYmIGRpcmVjdG9yeS5zdGF0dXMgPT09ICdub25lJztcblxuICAvLyBUaGUgbGF5b3V0IGNoYWluIHdyYXBwaW5nIHRoaXMgZW50cnkgKG91dGVybW9zdCBmaXJzdCkuIE5lZWRzIHRoZSBmdWxsXG4gIC8vIGZyb250bWF0dGVyIG1hcCAoZm9sZGVyIGNvbnZlbnRpb24gKyBgZnJhbWVgIG92ZXJyaWRlKSwgc28gaXQgcmVhZHMgdGhlIHdob2xlXG4gIC8vIG1ldGFkYXRhIHN0b3JlIGFuZCByZS1kZXJpdmVzIHdoZW4gdGhlIGNvbnRlbnQgc2V0IG9yIHRoZSBlbnRyeSBjaGFuZ2VzLlxuICBjb25zdCBhbGxNZXRhID0gdXNlQWxsTWV0YWRhdGEoKSBhcyBSZWNvcmQ8c3RyaW5nLCBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPj47XG5cbiAgLy8g4pSA4pSAIENvbnRlbnQtY2FycmllZCB0aGVtZXMgKFIzLTMxNjsgTURYX0ZST01fTU9VTlRfU1BFQyBENykg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIC8vIFRoZSBzdHlsZXNoZWV0cyB0aGUgaG9tZSBlbnRyeSBkZWNsYXJlcyAoYHN0eWxlc2hlZXRzOmApOyBib2RpZXMgYXJlIHJhdyBDU1NcbiAgLy8gYmVoaW5kIGZyb250bWF0dGVyLCBnYXRlZCBieSB0aGUgZ3JhbW1hciBpbnNpZGUgQ29udGVudFRoZW1lIGFuZCBhZG1pdHRlZCBvbmx5XG4gIC8vIGludG8gdGhlIGxvd2VzdCBjYXNjYWRlIGxheWVyLiBBIGRlY2xhcmF0aW9uIHRoYXQgbmFtZXMgbm8gZW50cnksIGEgc2hlZXQgdGhhdFxuICAvLyB3aWxsIG5vdCByZWFkLCBhbmQgYSBzaGVldCB0aGUgZ3JhbW1hciByZWplY3RzIGFsbCBkZWdyYWRlIHRvIGEgc3RhdHVzIGxpbmVcbiAgLy8gbmFtaW5nIGl0IOKAlCBuZXZlciBhIHNpbGVudCBkcm9wLCBuZXZlciBhIGNyYXNoLlxuICBjb25zdCBzdHlsZXNoZWV0cyA9IHVzZUNvbnRlbnRTdHlsZXNoZWV0cyhob21lTWV0YT8uc3R5bGVzaGVldHMsIGhvbWVLZXkoKSk7XG4gIGNvbnN0IFtyZWplY3RlZFNoZWV0LCBzZXRSZWplY3RlZFNoZWV0XSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICBjb25zdCBzaGVldEVycm9ycyA9IHJlamVjdGVkU2hlZXQgPyBbLi4uc3R5bGVzaGVldHMuZXJyb3JzLCByZWplY3RlZFNoZWV0XSA6IHN0eWxlc2hlZXRzLmVycm9ycztcblxuICAvLyDilIDilIAgVGhlIGVudHJ5IGdhdGUgKE1EWF9GUk9NX01PVU5UX1NQRUMgRDgpIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAvLyBVbmRlciBkaXNwYXRjaCB0aGUgaW5kZXggZmlsbHMgaW4gd2hpbGUgdGhlIHdpa2kgaXMgYWxyZWFkeSBvbiBzY3JlZW4uIFRoZSBmaWxlc1xuICAvLyB0aGF0IGRlY2lkZSBob3cgVEhJUyBlbnRyeSByZW5kZXJzIOKAlCBpdHNlbGYsIGhvbWUsIGl0cyBsYXlvdXRzLCBpdHMgYGZyYW1lOmAg4oCUIGFyZVxuICAvLyByZWFkIGFoZWFkIG9mIHRoZSByZXN0LCBhbmQgdGhlIGJvZHkgd2FpdHMgZm9yIHRoZW06IGFuIHVucmVhZCByb3cgcmVhZHMgYXNcbiAgLy8gYHJlbmRlcmAgdW5zZXQsIHdoaWNoIGlzIHRoZSBleGVjdXRpbmcgcGF0aC4gVGhlIGNocm9tZSBhcm91bmQgaXQgc3RheXMgbW91bnRlZC5cbiAgY29uc3Qgc2NhbkdhdGUgPSB1c2VDb250ZXh0KENvcnB1c1NjYW5Db250ZXh0KTtcbiAgY29uc3QgY3JpdGljYWwgPSBjcml0aWNhbEtleXMoZW50cnlLZXksIGFsbE1ldGEsIHNjYW5HYXRlLnJlYWRGYWlsdXJlKTtcbiAgY29uc3QgY3JpdGljYWxTaWcgPSBjcml0aWNhbC5qb2luKCd8Jyk7XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgc2NhbkdhdGUucHJpb3JpdGl6ZShjcml0aWNhbFNpZy5zcGxpdCgnfCcpKTtcbiAgfSwgW3NjYW5HYXRlLCBjcml0aWNhbFNpZ10pO1xuICBjb25zdCBwZW5kaW5nID0gZW50cnlQZW5kaW5nKGNyaXRpY2FsLCBzY2FuR2F0ZS5pc1NldHRsZWQsIHN0eWxlc2hlZXRzLnN0YXR1cyk7XG4gIGNvbnN0IGZhaWx1cmUgPSBjcml0aWNhbEZhaWx1cmUoY3JpdGljYWwsIHNjYW5HYXRlLnJlYWRGYWlsdXJlKTtcbiAgY29uc3QgY2hhaW46IHN0cmluZ1tdID0gbGF5b3V0Q2hhaW5Gb3JLZXkoZW50cnlLZXksIGFsbE1ldGEpO1xuICBjb25zdCBmcmFtZU5vbmUgPSBtZXRhPy5mcmFtZSA9PT0gJ25vbmUnIHx8IG1ldGE/LmZyYW1lID09PSBmYWxzZTtcblxuICAvLyBSMy0zMDkg4oCUIHRoZSBuYXYgYXJyYW5nZW1lbnQgaXMgdGhlIFJPT1QgbGF5b3V0J3MgdG8gY2hvb3NlIChgbmF2OiB0b3BgIGluIHRoZVxuICAvLyBvdXRlcm1vc3QgX2xheW91dC5tZHgncyBmcm9udG1hdHRlcjsgdGhlIGRlZmF1bHQgc2hlbGwgYW5kIHRoZSBzdGFydGVycyByZWFkIHRoZVxuICAvLyBzYW1lIHZhbHVlIHRocm91Z2ggdGhlIHNoZWxsKS4gVW5kZWNsYXJlZCBvciB1bmtub3duIOKGkiAnc2lkZScsIHRoZSBhcnJhbmdlbWVudFxuICAvLyBHcm92ZSBoYXMgYWx3YXlzIHNoaXBwZWQg4oCUIG5ldmVyIGFuIHVuc3R5bGVkIHBhZ2UuXG4gIGNvbnN0IG5hdk1vZGUgPSByZXNvbHZlTmF2TW9kZShjaGFpbi5sZW5ndGggPyAoYWxsTWV0YVtjaGFpblswXSFdIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KSA6IHVuZGVmaW5lZCk7XG4gIGNvbnN0IHVzZURlZmF1bHQgPSBjaGFpbi5sZW5ndGggPT09IDAgJiYgIWZyYW1lTm9uZTtcblxuICAvLyBFdmVyeSBuYXZpZ2F0aW9uIHN0YXJ0cyBhdCB0aGUgdG9wIG9mIHRoZSBlbnRyeSwgZXhjZXB0IG9uZSBhaW1lZCBhdCBhIHNlY3Rpb24uIFRoZVxuICAvLyByZWYgZ29lcyBvbiBgLmRldmljZV9fc2Nyb2xsYCBiZWxvdyDigJQgdGhlIG9ubHkgdGhpbmcgb24gdGhlIHBhZ2UgdGhhdCBzY3JvbGxzLlxuICBjb25zdCBzY3JvbGxSZWYgPSB1c2VTY3JvbGxSZXNldChlbnRyeUtleSwgaGFzaCk7XG5cbiAgLy8gUmVhZGluZyB0aW1lOiByZWFkIHRoZSBlbnRyeSBib2R5IG9uY2UgcGVyIGVudHJ5LlxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGxldCBhY3RpdmUgPSB0cnVlO1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9zZXQtc3RhdGUtaW4tZWZmZWN0XG4gICAgc2V0TWlucygwKTtcbiAgICBmcy5wcm9taXNlc1xuICAgICAgLnJlYWRGaWxlKGtleVRvRnNQYXRoKGVudHJ5S2V5KSwgJ3V0ZjgnKVxuICAgICAgLnRoZW4oKGI6IHVua25vd24pID0+IHtcbiAgICAgICAgaWYgKGFjdGl2ZSkgc2V0TWlucyhyZWFkaW5nVGltZShzdHJpcEZyb250bWF0dGVyKFN0cmluZyhiKSkpKTtcbiAgICAgIH0pXG4gICAgICAuY2F0Y2goKCkgPT4gdW5kZWZpbmVkKTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgYWN0aXZlID0gZmFsc2U7XG4gICAgfTtcbiAgfSwgW2VudHJ5S2V5XSk7XG5cbiAgLy8gUmVjb3Jkcywgbm90IHRhYi1lbmNvZGVkIHBhdGhzIChSMy0yNzZhKTogdGhlIHF1ZXJ5IHNlbGVjdHMgYHsgcGF0aCwgbGFiZWwgfWBcbiAgLy8gYW5kIHRoZSBob29rIHJldHVybnMgdGhlbSBhcy1pcyDigJQgbm8gZmFrZS1wYXRoIGVuY29kaW5nIHJvdW5kLXRyaXAuXG4gIGNvbnN0IG5hdlJlc3VsdCA9IHVzZU1ldGFkYXRhUXVlcnk8TWV0YWRhdGEsIE5hdlJlY29yZD4obmF2UXVlcnkpO1xuICBjb25zdCBuYXZJdGVtczogTmF2SXRlbVtdID0gcXVlcnlSZWNvcmRzPE5hdlJlY29yZD4obmF2UmVzdWx0KS5tYXAoKHsgcGF0aCwgbGFiZWwgfSkgPT4gKHtcbiAgICBrZXk6IHBhdGgsXG4gICAgaHJlZjoga2V5VG9IcmVmKHBhdGgpLFxuICAgIGxhYmVsLFxuICB9KSk7XG5cbiAgLy8gQ2xvc2VzdC1tYXRjaCBzdWdnZXN0aW9uIGZvciBhIDQwNCAoc2hhcmVkIG5hbWVzcGFjZSBvciBuYW1lIG92ZXJsYXApLlxuICBjb25zdCBzdWdnZXN0aW9uID0gbWlzc2luZ1xuICAgID8ga2V5c1xuICAgICAgICAubWFwKChrKSA9PiAoeyBrLCBzY29yZTogb3ZlcmxhcChrLCBlbnRyeUtleSkgfSkpXG4gICAgICAgIC5zb3J0KChhLCBiKSA9PiBiLnNjb3JlIC0gYS5zY29yZSlbMF0/LmtcbiAgICA6IHVuZGVmaW5lZDtcblxuICBjb25zdCBzaGVsbDogR3JvdmVTaGVsbCA9IHtcbiAgICB0aGVtZSxcbiAgICBzZXRUaGVtZTogY2hvb3NlVGhlbWUsXG4gICAgbGlnaHQsXG4gICAgc2V0TGlnaHQ6IGNob29zZVBvbGFyaXR5LFxuICAgIG1lbnVPcGVuLFxuICAgIHNldE1lbnVPcGVuLFxuICAgIHNlYXJjaE9wZW4sXG4gICAgc2V0U2VhcmNoT3BlbixcbiAgICBkcmF3ZXJPcGVuLFxuICAgIHNldERyYXdlck9wZW4sXG4gICAgdncsXG4gICAgbmF2TW9kZSxcbiAgICB3cml0YWJsZSxcbiAgICBvcGVuRWRpdG9yLFxuICAgIGVkaXRCdXN5LFxuICAgIGVkaXRSZWZ1c2VkLFxuICAgIGVkaXRIaW50LFxuICAgIHNpdGVUaXRsZSxcbiAgICBzYWZlLFxuICAgIG5hdkl0ZW1zLFxuICAgIGVudHJ5S2V5LFxuICAgIGluY2x1ZGVQYXRoLFxuICAgIGxheW91dCxcbiAgICBzaG93UmFpbHMsXG4gICAgbWlucyxcbiAgICBtaXNzaW5nLFxuICAgIHN1Z2dlc3Rpb24sXG4gICAgZGlyZWN0b3J5LFxuICB9O1xuXG4gIC8vIFRoZSBidW5kbGUgc2NvcGUgaGFuZGVkIHRvIENPTlRFTlQgKFIzLTE3NDsgTURYX0ZST01fTU9VTlRfU1BFQyDCpzIsIMKnNyAxYSkuXG4gIC8vXG4gIC8vIEEgY29tcG9uZW50IHRoZSBidW5kbGUgc2hpcHMgY2Fubm90IGltcG9ydCB0aGlzIGVuZ2luZSDigJQgaXQgd291bGQgcmVzb2x2ZSBhIHNlY29uZFxuICAvLyBjb3B5IGZyb20gdGhlIHJlZ2lzdHJ5LCB3aXRoIGl0cyBvd24gYGNvbnRlbnRSb290YCBtb2R1bGUgc3RhdGUsIGFuZCBhbnN3ZXIgYWJvdXQgdGhlXG4gIC8vIHdyb25nIGJ1bmRsZSDigJQgc28gZXZlcnl0aGluZyBpdCBuZWVkcyBhYm91dCB0aGUgYnVuZGxlIGFycml2ZXMgdGhyb3VnaCB0aGUgU0RLLCB3aGljaFxuICAvLyBib3RoIHNpZGVzIGdlbnVpbmVseSBzaGFyZSAob25lIGAvbm9kZV9tb2R1bGVzYCBwZXIgZnJhbWUpLiBUaHJlZSBmYWN0cywgYW5kIGVhY2ggaXNcbiAgLy8gb25lIGEgY29udGVudCBjb21wb25lbnQgY2Fubm90IGRlcml2ZSBmb3IgaXRzZWxmOlxuICAvL1xuICAvLyAg4oCiIGByb290YCDigJQgc28gbWV0YWRhdGEga2V5cyBjYW4gYmUgcmViYXNlZCBvZmYgdGhlIG1vdW50IHByZWZpeC4gQ29udGVudCBtdXN0IG5ldmVyXG4gIC8vICAgIHNlZSBgL21udC88aGFzaD4v4oCmYDogaXQgaXMgaG9zdCBrbm93bGVkZ2UgdGhlIHZpZXdlciByZWFkcyBUSFJPVUdIIGJ1dCBkb2VzIG5vdFxuICAvLyAgICBwdWJsaXNoICh0aGUgcHJvcGVydHkgYERpcmVjdG9yeUxpc3QudGVzdC50c3hgIHBpbnMpLCBhbmQgaXQgaXMgbm90IHN0YWJsZSBhY3Jvc3NcbiAgLy8gICAgbG9hZHMsIHNvIGFueXRoaW5nIGNvbnRlbnQgc3RvcmVkIG9yIGxpbmtlZCB3aXRoIGl0IHdvdWxkIHJvdC5cbiAgLy8gIOKAoiBgZW50cnlgIOKAlCB0aGUgZW50cnkgYmVpbmcgUkVBRCwgbm90IHRoZSBmaWxlIHRoZSBjb21wb25lbnQgc2l0cyBpbi4gQSBjb21wb25lbnQgaW5cbiAgLy8gICAgYSBgX2xheW91dC5tZHhgIHdyYXBzIHRoZSBlbnRyeSwgc28gYDxJbmNsdWRlPmAncyBvd24gbW9kdWxlIGlkZW50aXR5IHdvdWxkIG5hbWVcbiAgLy8gICAgdGhlIGxheW91dDsgZnVybml0dXJlIGluIHRoZSBsYXlvdXQgY2hhaW4gKGEgc3RhdHVzIGxpbmUsIGEgZGVwZW5kZW5jeSByYWlsKSBuZWVkc1xuICAvLyAgICB0aGUgcGFnZSBpdCBpcyBkZXNjcmliaW5nLlxuICAvLyAg4oCiIGB0b0hyZWZgIOKAlCBiZWNhdXNlIGJ1bmRsZS1wYXRo4oaSVVJMIGlzIHRoaXMgVklFV0VSJ3MgcG9saWN5IGFuZCB0aGUgdHdvIHBhY2thZ2luZ3NcbiAgLy8gICAgZ2VudWluZWx5IGRpc2FncmVlIChgdXJsQW5jaG9yYCkuIENvbnRlbnQgdGhhdCBjb21wdXRlZCBpdHMgb3duIGhyZWZzIHdvdWxkIGJlXG4gIC8vICAgIGNvcnJlY3QgaW4gZXhhY3RseSBvbmUgcGFja2FnaW5nLCB3aGljaCBpcyB0aGUgbW9kZS1pbnZhcmlhbmNlIHJ1bGVcbiAgLy8gICAgKFBMQVRGT1JNX0xBWUVSSU5HIMKnMS4xKSBicm9rZW4gaW4gdGhlIGxlYXN0IHZpc2libGUgcG9zc2libGUgd2F5LlxuICAvLyBgY29udGVudFJvb3RgIGlzIG1vZHVsZSBzdGF0ZSBzZXR0bGVkIGF0IGJvb3QsIHNvIGl0IGlzIHJlYWQgaGVyZSDigJQgaW50byBhIGxvY2FsIHRoZVxuICAvLyBtZW1vIGNhbiBsaXN0IGFzIGEgZGVwZW5kZW5jeSDigJQgcmF0aGVyIHRoYW4gaW5zaWRlIHRoZSBmYWN0b3J5LiBDYWxsaW5nIGl0IGluc2lkZVxuICAvLyB3b3VsZCBjbG9zZSBvdmVyIGEgdmFsdWUgdGhlIGRlcGVuZGVuY3kgbGlzdCBkb2VzIG5vdCBuYW1lLCB3aGljaCB0aGUgUmVhY3QgQ29tcGlsZXJcbiAgLy8gY29ycmVjdGx5IHJlZnVzZXMgdG8gcHJlc2VydmUgbWVtb2l6YXRpb24gYWNyb3NzLlxuICAvLyBCdWlsdCBmcmVzaCBlYWNoIHJlbmRlciwgbGlrZSBldmVyeXRoaW5nIGVsc2UgaW4gdGhpcyBjb21wb25lbnQg4oCUIG5vIGhhbmQtbWVtb2l6YXRpb25cbiAgLy8gKHRoZSByZXN0IG9mIHRoZSBmaWxlIGhhcyBub25lIGVpdGhlcjsgYHJlYWN0LWhvb2tzL3ByZXNlcnZlLW1hbnVhbC1tZW1vaXphdGlvbmBcbiAgLy8gcmVqZWN0cyBvbmUgaGVyZSBiZWNhdXNlIGBlbnRyeUtleWAgZGVyaXZlcyBmcm9tIHRoZSBtZXRhZGF0YSBxdWVyeSdzIGFycmF5KS5cbiAgLy9cbiAgLy8gVGhhdCBpcyBzYWZlIGJlY2F1c2UgdGhlIEVYUEVOU0lWRSBoYWxmIGRvZXMgbm90IGtleSBvbiB0aGlzIG9iamVjdCdzIGlkZW50aXR5OiB0aGVcbiAgLy8gU0RLJ3MgYHVzZUJ1bmRsZUVudHJpZXNgIGRlc3RydWN0dXJlcyBge3Jvb3QsIHRvSHJlZn1gIGFuZCBtZW1vaXplcyBvbiB0aG9zZSwgYW5kIGJvdGhcbiAgLy8gYXJlIHN0YWJsZSDigJQgYHJvb3RgIGlzIGEgc3RyaW5nIGNvbXBhcmVkIGJ5IHZhbHVlLCBgdG9IcmVmYCBpcyB0aGUgbW9kdWxlLXNjb3BlXG4gIC8vIGBidW5kbGVIcmVmYCBhYm92ZS4gQSBuZXcgd3JhcHBlciByZS1yZW5kZXJzIGNvbnN1bWVycyAoY2hlYXApOyBpdCBkb2VzIG5vdCByZS1kZXJpdmVcbiAgLy8gODAwLW9kZCBlbnRyaWVzLiBNYWtpbmcgYHRvSHJlZmAgYSBjbG9zdXJlIHdvdWxkIHNpbGVudGx5IHVuZG8gdGhhdCwgd2hpY2ggaXMgdGhlXG4gIC8vIHdob2xlIHJlYXNvbiBpdCBpcyBub3Qgb25lLlxuICBjb25zdCBidW5kbGVSb290ID0gY29udGVudERpcigpLnJlcGxhY2UoL1xcLyskLywgJycpO1xuICBjb25zdCBidW5kbGVFbnRyeSA9IHRvQnVuZGxlUGF0aChlbnRyeUtleSwgYnVuZGxlUm9vdCk7XG4gIGNvbnN0IGJ1bmRsZVNjb3BlID0geyByb290OiBidW5kbGVSb290LCBlbnRyeTogYnVuZGxlRW50cnksIHRvSHJlZjogYnVuZGxlSHJlZiB9O1xuXG4gIHJldHVybiAoXG4gICAgLy8gUjMtMjc3YjogZGVjbGFyZSB0aGUgZW5jbG9zaW5nIGJ1bmRsZSBmb3IgdGhlIHBsYXRmb3JtJ3MgbGluay1zcGFjZSBjb25zdW1lcnNcbiAgICAvLyAodGhlIHNoYXJlZCByZXNvbHZlcidzIGJ1bmRsZS1hbmNob3JlZCBhYnNvbHV0ZSArIGAkZnM6YCBoYW5kbGluZyByZWFkIHRoaXMpLlxuICAgIC8vIFIzLTQ4MjogdGhlIFNESyBwaW4gKF4wLjcyLjAsICM3NSkgcmVhZHMgYGJ1bmRsZVJvb3RgIG5ldy10aGVuLW9sZCwgc28gdGhlIG5ld1xuICAgIC8vIHNwZWxsaW5nIGlzIHN0YXRlZCBhbG9uZSDigJQgdGhlIGRlcHJlY2F0ZWQgYGNvcnB1c1Jvb3RgIHN0YXlzIGluIHRoZSB0eXBlIGZvclxuICAgIC8vIG9sZGVyIGNvbnN1bWVycyAobWR4LXBsdWdpbnMnIGZvcmV2ZXItY29tcGF0KSBidXQgbm8gbG9uZ2VyIGhlcmUuXG4gICAgPExpbmtTcGFjZUNvbnRleHQuUHJvdmlkZXJcbiAgICAgIHZhbHVlPXt7XG4gICAgICAgIGJ1bmRsZVJvb3Q6IGdldENvbnRlbnRSb290KCksXG4gICAgICAgIC8vIFIzLTE4NCBTMiAoUEVSU0lTVEVOQ0VfU1BFQyDCpzguMykg4oCUIHRoZSBgJGZzOmAgY2xhbXAsIG9uIHRoaXMgcmVuZGVyIHBhdGguXG4gICAgICAgIC8vIFRoZSBjbGFtcCB0aGF0IGlzIElOIEZPUkNFIGxpdmVzIGluIGBsaWIvY29udGVudC50c2AgKGBsaW5rU3BhY2VPcHRzYCk6XG4gICAgICAgIC8vIGBocmVmVGFyZ2V0S2V5YCBpcyB3aGVyZSBhIGNvcnB1cyBkb2N1bWVudCdzIGxpbmsgdGFyZ2V0cyBhY3R1YWxseVxuICAgICAgICAvLyByZXNvbHZlIChncm92ZSdzIG93biBXaWtpTGluayBvdmVycmlkZSByb3V0ZXMgdGhlcmUpLCBhbmQgaXQgcGFzc2VzXG4gICAgICAgIC8vIGBidW5kbGVDaHJvb3RlZDogaXNEaXNwYXRjaGVkKClgIHRvIHRoZSBzaGFyZWQgcmVzb2x2ZXIgKFIzLTMxOSdzXG4gICAgICAgIC8vIGNocm9vdCksIHNvIGEgZGlzcGF0Y2hlZCBjb3JwdXMgZG9jdW1lbnQncyBgJGZzOi9tbnQve2hhc2h9L+KApmAgY2Fubm90XG4gICAgICAgIC8vIG5hbWUgYSBmZWRlcmF0ZWQgbW91bnQgbWF0ZXJpYWxpc2VkIGJlc2lkZSBpdCDigJQgdGhlIGFwcC1sZXZlbCBtb3VudFxuICAgICAgICAvLyBwb2ludCBpcyBub3QgYSBjb3JwdXMgcGF0aCDigJQgYW5kIHRoZSBmb3JrJ3MgYCRmczpgIHN0YXlzXG4gICAgICAgIC8vIG1vdW50LWFic29sdXRlLiBUSElTIGZpZWxkIGNhcnJpZXMgdGhlIHNhbWUgZmxhZyBmb3IgdGhlIFNESydzIGdlbmVyaWNcbiAgICAgICAgLy8gY29tcG9uZW50IGNvbnN1bWVycyAoV2lraUxpbmsvTURYQ29tcG9uZW50cyk6IHRoZSBwaW5uZWQgU0RLIDAuNzIuMFxuICAgICAgICAvLyBkb2VzIG5vdCBmb3J3YXJkIGl0LCBzbyBpdCBpcyBkZWNpZGVkLWJ1dC1ub3QtY29uc3VtZWQgdW50aWwgYVxuICAgICAgICAvLyBmb3J3YXJkaW5nIHJlbGVhc2UgaXMgcHVibGlzaGVkIGFuZCBwaW5uZWQg4oCUIHRoZSBib29rZWQgZm9sbG93LXVwLFxuICAgICAgICAvLyBzdGF0ZWQgaGVyZSByYXRoZXIgdGhhbiBibHVycmVkICjCpzguMydzIGRhdGVkIG5vdGU6XG4gICAgICAgIC8vIGJ1aWx0LWJ1dC1ub3QtaW4tZm9yY2UgaXMgYSBtYXRlcmlhbGx5IGRpZmZlcmVudCBzdGF0ZSBmcm9tIGRvbmUpLlxuICAgICAgICBidW5kbGVDaHJvb3RlZDogaXNEaXNwYXRjaGVkKCksXG4gICAgICB9fVxuICAgID5cbiAgICB7LyogUjMtMTc0OiB0aGUgYnVuZGxlIHNjb3BlIENPTlRFTlQgcmVhZHMg4oCUIHNpYmxpbmcgdG8gdGhlIGxpbmsgc3BhY2UsIG5vdCBhXG4gICAgICAgIHJlcGxhY2VtZW50IGZvciBpdC4gVGhlIHR3byBhbnN3ZXIgZGlmZmVyZW50IHF1ZXN0aW9uczogYExpbmtTcGFjZUNvbnRleHRgIHRlbGxzXG4gICAgICAgIHRoZSBwbGF0Zm9ybSdzIGxpbmsgcmVzb2x2ZXIgd2hlcmUgYWJzb2x1dGUgaHJlZnMgYXJlIGFuY2hvcmVkOyBgQnVuZGxlQ29udGV4dGBcbiAgICAgICAgdGVsbHMgYSBjb21wb25lbnQgdGhlIGJ1bmRsZSBzaGlwcyB3aGljaCBlbnRyaWVzIGV4aXN0LCB3aGljaCBvbmUgaXMgYmVpbmcgcmVhZCxcbiAgICAgICAgYW5kIGhvdyB0byB0dXJuIGEgYnVuZGxlIHBhdGggaW50byBhIFVSTC4gKi99XG4gICAgPEJ1bmRsZUNvbnRleHQgdmFsdWU9e2J1bmRsZVNjb3BlfT5cbiAgICA8R3JvdmVTaGVsbENvbnRleHQuUHJvdmlkZXIgdmFsdWU9e3NoZWxsfT5cbiAgICAgIDxkaXZcbiAgICAgICAgY2xhc3NOYW1lPVwiZ3JvdmUtcm9vdFwiXG4gICAgICAgIGRhdGEtdnc9e3Z3fVxuICAgICAgICBkYXRhLW5hdj17bmF2TW9kZX1cbiAgICAgICAgZGF0YS1ncm92ZS10aGVtZT17dGhlbWUgPT09ICdkZWZhdWx0JyA/IHVuZGVmaW5lZCA6IHRoZW1lfVxuICAgICAgICBkYXRhLXRoZW1lPXtwb2xhcml0eX1cbiAgICAgID5cbiAgICAgICAgey8qIFIzLTMxMDogdGhlIEFDVElWRSB0aGVtZSdzIGRlY2xhcmVkIGZhY2VzIOKAlCB0aGUgZW5naW5lIG1pbnRzIGJsb2I6XG4gICAgICAgICAgICBAZm9udC1mYWNlIHJ1bGVzIChSMy0zMTUncyBtZWNoYW5pc20pOyBzd2l0Y2hpbmcgdGhlbWVzIHJldm9rZXMgdGhlXG4gICAgICAgICAgICBvdXRnb2luZyBzZXQgYW5kIHJlLW1pbnRzLiAqL31cbiAgICAgICAgPFRoZW1lQXNzZXRzIGRlY2xhcmF0aW9ucz17dGhlbWVBc3NldHNGb3IodGhlbWUpfSAvPlxuICAgICAgICA8Q29udGVudFRoZW1lIHNoZWV0cz17c3R5bGVzaGVldHMuc2hlZXRzfSBvblJlamVjdGVkPXsocGF0aCwgdikgPT4gc2V0UmVqZWN0ZWRTaGVldChgJHtwYXRofToke3YubGluZX0g4oCUICR7di5yZWFzb259YCl9IC8+XG4gICAgICAgIHsvKiBSMy02Mjc6IHJlbWVtYmVyIHdoZXJlIHRoZSByZWFkZXIgd2FzIG9uIHRoZSBlbnRyeSB0aGV5IGxlYXZlLCBhbmQgcHV0XG4gICAgICAgICAgICB0aGVtIGJhY2sgdGhlcmUgb24gQmFjay4gR3JvdmUncyBzY3JvbGxlciBpcyBpdHMgb3duIGNvbnRhaW5lciwgc28gdGhlXG4gICAgICAgICAgICByZWYgZ29lcyBhY3Jvc3M7IGB1c2VTY3JvbGxSZXNldGAgYWJvdmUgc3RhbmRzIGRvd24gb24gdGhlIHNhbWVcbiAgICAgICAgICAgIHRyYXZlcnNhbCBzbyB0aGUgdHdvIGRvIG5vdCBmaWdodC4gKi99XG4gICAgICAgIDxTY3JvbGxSZXN0b3JhdGlvbiBzY3JvbGxlcj17c2Nyb2xsUmVmfSAvPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRldmljZV9fc2Nyb2xsXCIgcmVmPXtzY3JvbGxSZWZ9PlxuICAgICAgICAgIHtzaGVldEVycm9ycy5sZW5ndGggPiAwID8gKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncm92ZS1kZWNsLWVycm9yXCIgcm9sZT1cInN0YXR1c1wiPlxuICAgICAgICAgICAgICA8c3Ryb25nPkEgc3R5bGVzaGVldCB0aGlzIGNvcnB1cyBkZWNsYXJlcyBjb3VsZCBub3QgYmUgYXBwbGllZC48L3N0cm9uZz5cbiAgICAgICAgICAgICAgPHVsPlxuICAgICAgICAgICAgICAgIHtzaGVldEVycm9ycy5tYXAoKGUsIGkpID0+IChcbiAgICAgICAgICAgICAgICAgIDxsaSBrZXk9e2l9PntlfTwvbGk+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApIDogbnVsbH1cbiAgICAgICAgICB7cmVqZWN0ZWRDb21wb25lbnRzLmxlbmd0aCA+IDAgPyAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyb3ZlLWRlY2wtZXJyb3JcIiByb2xlPVwic3RhdHVzXCI+XG4gICAgICAgICAgICAgIDxzdHJvbmc+VGhpcyBjb3JwdXMgZGVjbGFyZXMgY29tcG9uZW50cyB0aGF0IGNvdWxkIG5vdCBiZSBsb2FkZWQuPC9zdHJvbmc+XG4gICAgICAgICAgICAgIDx1bD5cbiAgICAgICAgICAgICAgICB7cmVqZWN0ZWRDb21wb25lbnRzLm1hcCgocikgPT4gKFxuICAgICAgICAgICAgICAgICAgPGxpIGtleT17ci5uYW1lfT5cbiAgICAgICAgICAgICAgICAgICAgPGNvZGU+e3IubmFtZX08L2NvZGU+IOKAlCB7ci5yZWFzb259XG4gICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L3VsPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSA6IG51bGx9XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncm92ZS1zaGVsbFwiIGRhdGEtbmF2PXtmcmFtZU5vbmUgPyB1bmRlZmluZWQgOiBuYXZNb2RlfT5cbiAgICAgICAgICAgIHtmYWlsdXJlID8gPEJvb3RNZXNzYWdlPntmYWlsdXJlfTwvQm9vdE1lc3NhZ2U+IDogcGVuZGluZyA/IDxCb290TWVzc2FnZSAvPiA6IHJlbmRlckxheWVycyhjaGFpbiwgdXNlRGVmYXVsdCwgc2FmZSl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHtzZWFyY2hPcGVuID8gPFNlYXJjaCBvbkNsb3NlPXsoKSA9PiBzZXRTZWFyY2hPcGVuKGZhbHNlKX0gLz4gOiBudWxsfVxuICAgICAgICB7ZHJhd2VyT3BlbiA/IChcbiAgICAgICAgICA8RHJhd2VyXG4gICAgICAgICAgICBzaXRlVGl0bGU9e3NpdGVUaXRsZX1cbiAgICAgICAgICAgIG5hdj17bmF2SXRlbXMubWFwKChuKSA9PiAoeyBocmVmOiBuLmhyZWYsIGxhYmVsOiBuLmxhYmVsLCBjdXI6IG4ua2V5ID09PSBlbnRyeUtleSB9KSl9XG4gICAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXREcmF3ZXJPcGVuKGZhbHNlKX1cbiAgICAgICAgICAvPlxuICAgICAgICApIDogbnVsbH1cbiAgICAgICAgPEdyb3ZlQWdlbnQgd3JpdGFibGU9e3dyaXRhYmxlfSBlbnRyeUtleT17ZW50cnlLZXl9IGVudHJ5VGl0bGU9e3BsYWluTGFiZWwobWV0YT8udGl0bGUgfHwgJ3RoaXMgZW50cnknKX0gLz5cbiAgICAgIDwvZGl2PlxuICAgIDwvR3JvdmVTaGVsbENvbnRleHQuUHJvdmlkZXI+XG4gICAgPC9CdW5kbGVDb250ZXh0PlxuICAgIDwvTGlua1NwYWNlQ29udGV4dC5Qcm92aWRlcj5cbiAgKTtcbn1cblxuLy8gQ3J1ZGUgY2xvc2VzdC1tYXRjaCBzY29yZSBmb3IgdGhlIDQwNCBzdWdnZXN0aW9uOiBzaGFyZWQgbmFtZXNwYWNlICsgbmFtZSBjaGFycy5cbmZ1bmN0aW9uIG92ZXJsYXAoYTogc3RyaW5nLCBiOiBzdHJpbmcpOiBudW1iZXIge1xuICBjb25zdCBhbiA9IGEucmVwbGFjZShjb250ZW50RGlyKCksICcnKS5yZXBsYWNlKC9cXC5tZHg/JC8sICcnKTtcbiAgY29uc3QgYm4gPSBiLnJlcGxhY2UoY29udGVudERpcigpLCAnJykucmVwbGFjZSgvXFwubWR4PyQvLCAnJyk7XG4gIGNvbnN0IGFOcyA9IGFuLnNwbGl0KCcvJykuc2xpY2UoMCwgLTEpLmpvaW4oJy8nKTtcbiAgY29uc3QgYk5zID0gYm4uc3BsaXQoJy8nKS5zbGljZSgwLCAtMSkuam9pbignLycpO1xuICBsZXQgc2NvcmUgPSBhTnMgJiYgYU5zID09PSBiTnMgPyA1IDogMDtcbiAgY29uc3QgYU5hbWUgPSBhbi5zcGxpdCgnLycpLnBvcCgpIHx8ICcnO1xuICBjb25zdCBiTmFtZSA9IGJuLnNwbGl0KCcvJykucG9wKCkgfHwgJyc7XG4gIGZvciAoY29uc3QgY2ggb2YgbmV3IFNldChhTmFtZSkpIGlmIChiTmFtZS5pbmNsdWRlcyhjaCkpIHNjb3JlKys7XG4gIHJldHVybiBzY29yZTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQ0EsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBRUEsSUFBQUMsR0FBQSxHQUFBQyxzQkFBQSxDQUFBRixPQUFBO0FBRUEsSUFBQUcsSUFBQSxHQUFBSCxPQUFBO0FBUUEsSUFBQUksa0JBQUEsR0FBQUosT0FBQTtBQUNBLElBQUFLLFVBQUEsR0FBQUwsT0FBQTtBQUNBLElBQUFNLE9BQUEsR0FBQU4sT0FBQTtBQUNBLElBQUFPLFFBQUEsR0FBQVAsT0FBQTtBQVNBLElBQUFRLEtBQUEsR0FBQVIsT0FBQTtBQUNBLElBQUFTLFFBQUEsR0FBQVQsT0FBQTtBQUVBLElBQUFVLE9BQUEsR0FBQVYsT0FBQTtBQUNBLElBQUFXLFVBQUEsR0FBQVgsT0FBQTtBQUNBLElBQUFZLGVBQUEsR0FBQVosT0FBQTtBQUNBLElBQUFhLE9BQUEsR0FBQWIsT0FBQTtBQUNBLElBQUFjLG9CQUFBLEdBQUFkLE9BQUE7QUFDQSxJQUFBZSxlQUFBLEdBQUFmLE9BQUE7QUFDQSxJQUFBZ0Isa0JBQUEsR0FBQWhCLE9BQUE7QUFDQSxJQUFBaUIsWUFBQSxHQUFBakIsT0FBQTtBQUVBLElBQUFrQixNQUFBLEdBQUFsQixPQUFBO0FBRUEsSUFBQW1CLFNBQUEsR0FBQWpCLHNCQUFBLENBQUFGLE9BQUE7QUFDQSxJQUFBb0IsV0FBQSxHQUFBbEIsc0JBQUEsQ0FBQUYsT0FBQTtBQUNBLElBQUFxQixjQUFBLEdBQUFuQixzQkFBQSxDQUFBRixPQUFBO0FBQ0EsSUFBQXNCLE9BQUEsR0FBQXBCLHNCQUFBLENBQUFGLE9BQUE7QUFDQSxJQUFBdUIsT0FBQSxHQUFBckIsc0JBQUEsQ0FBQUYsT0FBQTtBQUNBLElBQUF3QixXQUFBLEdBQUF0QixzQkFBQSxDQUFBRixPQUFBO0FBQ0EsSUFBQXlCLFlBQUEsR0FBQXZCLHNCQUFBLENBQUFGLE9BQUE7QUFDQSxJQUFBMEIsYUFBQSxHQUFBeEIsc0JBQUEsQ0FBQUYsT0FBQTtBQUNBLElBQUEyQixZQUFBLEdBQUF6QixzQkFBQSxDQUFBRixPQUFBO0FBQ0EsSUFBQTRCLFdBQUEsR0FBQTVCLE9BQUE7QUFDQSxJQUFBNkIsc0JBQUEsR0FBQTdCLE9BQUE7QUFDQSxJQUFBOEIsYUFBQSxHQUFBOUIsT0FBQTtBQUNBLElBQUErQixVQUFBLEdBQUEvQixPQUFBO0FBQ0EsSUFBQWdDLGtCQUFBLEdBQUFoQyxPQUFBO0FBQTRELElBQUFpQyxXQUFBLEdBQUFqQyxPQUFBO0FBQUEsSUFBQWtDLEVBQUEsR0FBQUMsWUFBQTtBQXBENUQ7QUFBQSxTQUFBakMsdUJBQUFrQyxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBd0RBLFNBQVNHLFFBQVFBLENBQUNDLENBQVMsRUFBaUI7RUFDMUMsSUFBSTtJQUNGLE9BQU9DLFlBQVksQ0FBQ0MsT0FBTyxDQUFDRixDQUFDLENBQUM7RUFDaEMsQ0FBQyxDQUFDLE1BQU07SUFDTixPQUFPLElBQUk7RUFDYjtBQUNGO0FBQ0EsU0FBU0csU0FBU0EsQ0FBQ0gsQ0FBUyxFQUFFSSxDQUFTLEVBQVE7RUFDN0MsSUFBSTtJQUNGSCxZQUFZLENBQUNJLE9BQU8sQ0FBQ0wsQ0FBQyxFQUFFSSxDQUFDLENBQUM7RUFDNUIsQ0FBQyxDQUFDLE1BQU07SUFDTjtFQUFBO0FBRUo7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVNFLFVBQVVBLENBQUNDLFVBQWtCLEVBQVU7RUFDOUMsTUFBTUMsUUFBUSxHQUFHLElBQUFDLHNCQUFjLEVBQUNGLFVBQVUsRUFBRSxJQUFBRyxtQkFBVSxFQUFDLENBQUMsQ0FBQ0MsT0FBTyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsQ0FBQztFQUM3RSxPQUFPSCxRQUFRLEtBQUssSUFBSSxHQUFHRCxVQUFVLEdBQUcsSUFBQUssa0JBQVMsRUFBQ0osUUFBUSxDQUFDO0FBQzdEOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTSyxZQUFZQSxDQUFDQyxLQUFlLEVBQUVDLFVBQW1CLEVBQUVDLElBQWEsRUFBYTtFQUNwRixJQUFJQyxJQUFlLGdCQUFHLElBQUF4QixXQUFBLENBQUF5QixHQUFBLEVBQUN2QyxTQUFBLENBQUFtQixPQUFRLElBQUUsQ0FBQztFQUNsQyxJQUFJaUIsVUFBVSxFQUFFO0lBQ2Qsb0JBQU8sSUFBQXRCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3hDLE1BQUEsQ0FBQXlDLGFBQWEsQ0FBQ0MsUUFBUTtNQUFDQyxLQUFLLEVBQUVKLElBQUs7TUFBQUssUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUF5QixHQUFBLEVBQUNyQyxjQUFBLENBQUFpQixPQUFhLElBQUU7SUFBQyxDQUF3QixDQUFDO0VBQ3hGO0VBQ0EsS0FBSyxJQUFJeUIsQ0FBQyxHQUFHVCxLQUFLLENBQUNVLE1BQU0sR0FBRyxDQUFDLEVBQUVELENBQUMsSUFBSSxDQUFDLEVBQUVBLENBQUMsRUFBRSxFQUFFO0lBQzFDLE1BQU1FLEtBQUssR0FBR1IsSUFBSTtJQUNsQkEsSUFBSSxnQkFDRixJQUFBeEIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDeEMsTUFBQSxDQUFBeUMsYUFBYSxDQUFDQyxRQUFRO01BQUNDLEtBQUssRUFBRUksS0FBTTtNQUFBSCxRQUFBLEVBQ2xDTixJQUFJLGdCQUFHLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QyxXQUFBLENBQUFrQixPQUFVO1FBQUM0QixTQUFTLEVBQUVaLEtBQUssQ0FBQ1MsQ0FBQztNQUFFLENBQUUsQ0FBQyxnQkFBRyxJQUFBOUIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdkQsSUFBQSxDQUFBZ0UsT0FBTztRQUFDQyxRQUFRLEVBQUVkLEtBQUssQ0FBQ1MsQ0FBQyxDQUFFO1FBQUNNLFVBQVUsRUFBRUM7TUFBTyxDQUFFO0lBQUMsR0FEeERoQixLQUFLLENBQUNTLENBQUMsQ0FFMUIsQ0FDekI7RUFDSDtFQUNBLE9BQU9OLElBQUk7QUFDYjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDZSxTQUFTYyxTQUFTQSxDQUFDO0VBQ2hDQyxRQUFRLEdBQUcsS0FBSztFQUNoQkMsa0JBQWtCLEdBQUc7QUFPdkIsQ0FBQyxFQUFFO0VBQUF2QyxFQUFBO0VBQ0QsTUFBTXdDLEdBQUcsR0FBRyxJQUFBQyxpQkFBVSxFQUFDQyxvQ0FBaUIsQ0FBUTtFQUNoRCxNQUFNQyxXQUFtQixHQUFHSCxHQUFHLEVBQUVJLGVBQWUsRUFBRUQsV0FBVyxJQUFJLEdBQUc7RUFDcEUsTUFBTUUsSUFBWSxHQUFHTCxHQUFHLEVBQUVJLGVBQWUsRUFBRUMsSUFBSSxJQUFJLEVBQUU7O0VBRXJEO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU0sQ0FBQ0MsV0FBVyxFQUFFQyxjQUFjLENBQUMsR0FBRyxJQUFBQyxlQUFRLEVBQWdCLE1BQU0zQyxRQUFRLENBQUMsYUFBYSxDQUFDLENBQUM7RUFDNUYsTUFBTSxDQUFDNEMsZ0JBQWdCLEVBQUVDLG1CQUFtQixDQUFDLEdBQUcsSUFBQUYsZUFBUSxFQUFrQixNQUFNO0lBQzlFLE1BQU1HLENBQUMsR0FBRzlDLFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQztJQUN0QyxPQUFPOEMsQ0FBQyxLQUFLLE9BQU8sSUFBSUEsQ0FBQyxLQUFLLE1BQU0sR0FBR0EsQ0FBQyxHQUFHLElBQUk7RUFDakQsQ0FBQyxDQUFDO0VBQ0YsTUFBTUMsV0FBVyxHQUFJQyxFQUFVLElBQUs7SUFDbENOLGNBQWMsQ0FBQ00sRUFBRSxDQUFDO0lBQ2xCNUMsU0FBUyxDQUFDLGFBQWEsRUFBRTRDLEVBQUUsQ0FBQztFQUM5QixDQUFDO0VBQ0QsTUFBTUMsY0FBYyxHQUFJQyxTQUFrQixJQUFLO0lBQzdDLE1BQU1KLENBQVcsR0FBR0ksU0FBUyxHQUFHLE9BQU8sR0FBRyxNQUFNO0lBQ2hETCxtQkFBbUIsQ0FBQ0MsQ0FBQyxDQUFDO0lBQ3RCMUMsU0FBUyxDQUFDLGtCQUFrQixFQUFFMEMsQ0FBQyxDQUFDO0VBQ2xDLENBQUM7RUFDRDtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsTUFBTUssTUFBTSxHQUFHLE9BQU9DLE1BQU0sS0FBSyxXQUFXLElBQUlBLE1BQU0sQ0FBQ0MsTUFBTSxLQUFLRCxNQUFNO0VBQ3hFLE1BQU1FLFNBQVMsR0FBRyxJQUFBQyxpQkFBWSxFQUFDLENBQUM7RUFDaEMsTUFBTUMsWUFBNkIsR0FBR0wsTUFBTSxHQUFHRyxTQUFTLEdBQUcsSUFBSTtFQUMvRCxNQUFNLENBQUNHLFFBQVEsRUFBRUMsV0FBVyxDQUFDLEdBQUcsSUFBQWYsZUFBUSxFQUFDLEtBQUssQ0FBQztFQUMvQyxNQUFNLENBQUNnQixVQUFVLEVBQUVDLGFBQWEsQ0FBQyxHQUFHLElBQUFqQixlQUFRLEVBQUMsS0FBSyxDQUFDO0VBQ25ELE1BQU0sQ0FBQ2tCLFVBQVUsRUFBRUMsYUFBYSxDQUFDLEdBQUcsSUFBQW5CLGVBQVEsRUFBQyxLQUFLLENBQUM7RUFDbkQsTUFBTSxDQUFDb0IsSUFBSSxFQUFFQyxPQUFPLENBQUMsR0FBRyxJQUFBckIsZUFBUSxFQUFDLENBQUMsQ0FBQztFQUNuQyxNQUFNLENBQUNzQixFQUFFLEVBQUVDLEtBQUssQ0FBQyxHQUFHLElBQUF2QixlQUFRLEVBQXVCLE1BQ2pELE9BQU9TLE1BQU0sS0FBSyxXQUFXLElBQUlBLE1BQU0sQ0FBQ2UsVUFBVSxDQUFDLG9CQUFvQixDQUFDLENBQUNDLE9BQU8sR0FBRyxRQUFRLEdBQUcsU0FDaEcsQ0FBQztFQUVELElBQUFDLGdCQUFTLEVBQUMsTUFBTTtJQUNkLE1BQU1DLEVBQUUsR0FBR2xCLE1BQU0sQ0FBQ2UsVUFBVSxDQUFDLG9CQUFvQixDQUFDO0lBQ2xELE1BQU1JLEVBQUUsR0FBR0EsQ0FBQSxLQUFNTCxLQUFLLENBQUNJLEVBQUUsQ0FBQ0YsT0FBTyxHQUFHLFFBQVEsR0FBRyxTQUFTLENBQUM7SUFDekRFLEVBQUUsQ0FBQ0UsZ0JBQWdCLENBQUMsUUFBUSxFQUFFRCxFQUFFLENBQUM7SUFDakMsT0FBTyxNQUFNRCxFQUFFLENBQUNHLG1CQUFtQixDQUFDLFFBQVEsRUFBRUYsRUFBRSxDQUFDO0VBQ25ELENBQUMsRUFBRSxFQUFFLENBQUM7O0VBRU47RUFDQSxJQUFBRixnQkFBUyxFQUFDLE1BQU07SUFDZCxNQUFNRSxFQUFFLEdBQUkxRSxDQUFnQixJQUFLO01BQy9CLElBQUksQ0FBQ0EsQ0FBQyxDQUFDNkUsT0FBTyxJQUFJN0UsQ0FBQyxDQUFDOEUsT0FBTyxLQUFLOUUsQ0FBQyxDQUFDK0UsR0FBRyxDQUFDQyxXQUFXLENBQUMsQ0FBQyxLQUFLLEdBQUcsRUFBRTtRQUMzRGhGLENBQUMsQ0FBQ2lGLGNBQWMsQ0FBQyxDQUFDO1FBQ2xCbEIsYUFBYSxDQUFFbUIsQ0FBQyxJQUFLLENBQUNBLENBQUMsQ0FBQztNQUMxQjtJQUNGLENBQUM7SUFDRDNCLE1BQU0sQ0FBQ29CLGdCQUFnQixDQUFDLFNBQVMsRUFBRUQsRUFBRSxDQUFDO0lBQ3RDLE9BQU8sTUFBTW5CLE1BQU0sQ0FBQ3FCLG1CQUFtQixDQUFDLFNBQVMsRUFBRUYsRUFBRSxDQUFDO0VBQ3hELENBQUMsRUFBRSxFQUFFLENBQUM7O0VBRU47RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsTUFBTTtJQUFFUyxRQUFRO0lBQUVDLElBQUksRUFBRUMsUUFBUTtJQUFFQyxPQUFPLEVBQUVDLFdBQVc7SUFBRUMsVUFBVTtJQUFFQztFQUFTLENBQUMsR0FBRyxJQUFBQyxvQ0FBaUIsRUFBQ3RELFFBQVEsQ0FBQztFQUU1RyxNQUFNdUQsUUFBUSxHQUFHLElBQUFDLHlCQUFnQixFQUFDbkQsV0FBVyxDQUFDLElBQUksSUFBQW9ELGdCQUFPLEVBQUMsQ0FBQztFQUMzRDtFQUNBO0VBQ0E7RUFDQSxNQUFNQyxRQUFRLEdBQUcsSUFBQUMsb0JBQWUsRUFBQyxJQUFBRixnQkFBTyxFQUFDLENBQUMsQ0FBUTtFQUNsRDtFQUNBO0VBQ0E7RUFDQSxNQUFNRyxXQUEwQixHQUM5QixPQUFPRixRQUFRLEVBQUVHLEtBQUssS0FBSyxRQUFRLElBQUlILFFBQVEsQ0FBQ0csS0FBSyxHQUFHSCxRQUFRLENBQUNHLEtBQUssR0FBRyxJQUFJO0VBQy9FO0VBQ0E7RUFDQTtFQUNBLE1BQU1BLEtBQUssR0FBRyxJQUFBQyw4QkFBYyxFQUFDO0lBQUVDLE1BQU0sRUFBRXZELFdBQVc7SUFBRXdELE1BQU0sRUFBRUo7RUFBWSxDQUFDLENBQUM7RUFDMUUsTUFBTUssUUFBa0IsR0FBRyxJQUFBQywrQkFBZSxFQUFDO0lBQ3pDSCxNQUFNLEVBQUVwRCxnQkFBZ0I7SUFDeEJ3RCxJQUFJLEVBQUU1QyxZQUFZO0lBQ2xCNkMsU0FBUyxFQUFFLElBQUFDLHlCQUFpQixFQUFDUixLQUFLO0VBQ3BDLENBQUMsQ0FBQztFQUNGLE1BQU1TLEtBQUssR0FBR0wsUUFBUSxLQUFLLE9BQU87RUFDbEM7RUFDQTtFQUNBLE1BQU1NLFlBQVksR0FBRyxJQUFBQyxrQkFBVyxFQUFFQyxFQUF1QixJQUFLQyxNQUFNLENBQUNDLElBQUksQ0FBQ0YsRUFBRSxDQUFDLENBQUNHLE1BQU0sQ0FBQ0MsdUJBQWMsQ0FBQyxFQUFFLEVBQUUsQ0FBQztFQUN6RyxNQUFNQyxHQUFHLEdBQUcsSUFBQUMscUJBQWdCLEVBQUNSLFlBQVksQ0FBQztFQUMxQyxNQUFNSSxJQUFjLEdBQUcsSUFBQUssZ0JBQVUsRUFBQ0YsR0FBRyxDQUFDO0VBQ3RDLE1BQU1HLFdBQVcsR0FBR04sSUFBSSxDQUFDbkYsTUFBTSxHQUFHLENBQUM7O0VBRW5DO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsTUFBTTBGLFdBQVcsR0FBR0QsV0FBVyxJQUFJLENBQUNOLElBQUksQ0FBQ1EsUUFBUSxDQUFDNUIsUUFBUSxDQUFDLEdBQUcsSUFBQTZCLHlCQUFjLEVBQUM3QixRQUFRLEVBQUVvQixJQUFJLENBQUMsR0FBRyxJQUFJO0VBQ25HLE1BQU1VLFFBQVEsR0FBR0gsV0FBVyxJQUFJM0IsUUFBUTtFQUN4QyxNQUFNK0IsV0FBVyxHQUFHLElBQUFDLHFCQUFZLEVBQUNGLFFBQVEsQ0FBQztFQUMxQyxNQUFNRyxJQUFJLEdBQUcsSUFBQTdCLG9CQUFlLEVBQUMwQixRQUFRLENBQVE7RUFFN0MsTUFBTUksTUFBTSxHQUFHLElBQUFDLHlCQUFpQixFQUFDRixJQUFJLENBQUM7RUFDdEMsTUFBTUcsU0FBaUIsR0FBR0gsSUFBSSxFQUFFSSxJQUFJLElBQUlsQyxRQUFRLEVBQUVrQyxJQUFJLElBQUksT0FBTztFQUNqRTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNNUcsSUFBYSxHQUFHMEUsUUFBUSxFQUFFbUMsTUFBTSxLQUFLLE1BQU0sSUFBSUwsSUFBSSxFQUFFSyxNQUFNLEtBQUssTUFBTTtFQUM1RSxNQUFNQyxTQUFTLEdBQUdMLE1BQU0sS0FBSyxLQUFLLElBQUksQ0FBQ0QsSUFBSSxFQUFFTyxJQUFJOztFQUdqRDtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU1DLFVBQVUsR0FBR2YsV0FBVyxJQUFJLENBQUNOLElBQUksQ0FBQ1EsUUFBUSxDQUFDRSxRQUFRLENBQUM7RUFDMUQsTUFBTVksU0FBUyxHQUFHLElBQUFDLHdDQUFtQixFQUFDRixVQUFVLEdBQUdYLFFBQVEsR0FBRyxJQUFJLENBQUM7RUFDbkUsTUFBTWMsT0FBTyxHQUFHSCxVQUFVLElBQUlDLFNBQVMsQ0FBQ0csTUFBTSxLQUFLLE1BQU07O0VBRXpEO0VBQ0E7RUFDQTtFQUNBLE1BQU1DLE9BQU8sR0FBRyxJQUFBQyxtQkFBYyxFQUFDLENBQTRDOztFQUUzRTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNQyxXQUFXLEdBQUcsSUFBQUMsNENBQXFCLEVBQUM5QyxRQUFRLEVBQUU2QyxXQUFXLEVBQUUsSUFBQTlDLGdCQUFPLEVBQUMsQ0FBQyxDQUFDO0VBQzNFLE1BQU0sQ0FBQ2dELGFBQWEsRUFBRUMsZ0JBQWdCLENBQUMsR0FBRyxJQUFBaEcsZUFBUSxFQUFnQixJQUFJLENBQUM7RUFDdkUsTUFBTWlHLFdBQVcsR0FBR0YsYUFBYSxHQUFHLENBQUMsR0FBR0YsV0FBVyxDQUFDSyxNQUFNLEVBQUVILGFBQWEsQ0FBQyxHQUFHRixXQUFXLENBQUNLLE1BQU07O0VBRS9GO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNQyxRQUFRLEdBQUcsSUFBQTFHLGlCQUFVLEVBQUMyRyxvQ0FBaUIsQ0FBQztFQUM5QyxNQUFNQyxRQUFRLEdBQUcsSUFBQUMsMEJBQVksRUFBQzNCLFFBQVEsRUFBRWdCLE9BQU8sRUFBRVEsUUFBUSxDQUFDSSxXQUFXLENBQUM7RUFDdEUsTUFBTUMsV0FBVyxHQUFHSCxRQUFRLENBQUNJLElBQUksQ0FBQyxHQUFHLENBQUM7RUFDdEMsSUFBQS9FLGdCQUFTLEVBQUMsTUFBTTtJQUNkeUUsUUFBUSxDQUFDTyxVQUFVLENBQUNGLFdBQVcsQ0FBQ0csS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0VBQzdDLENBQUMsRUFBRSxDQUFDUixRQUFRLEVBQUVLLFdBQVcsQ0FBQyxDQUFDO0VBQzNCLE1BQU1JLE9BQU8sR0FBRyxJQUFBQyx1QkFBWSxFQUFDUixRQUFRLEVBQUVGLFFBQVEsQ0FBQ1csU0FBUyxFQUFFakIsV0FBVyxDQUFDSCxNQUFNLENBQUM7RUFDOUUsTUFBTXFCLE9BQU8sR0FBRyxJQUFBQywwQkFBZSxFQUFDWCxRQUFRLEVBQUVGLFFBQVEsQ0FBQ0ksV0FBVyxDQUFDO0VBQy9ELE1BQU1uSSxLQUFlLEdBQUcsSUFBQTZJLHlCQUFpQixFQUFDdEMsUUFBUSxFQUFFZ0IsT0FBTyxDQUFDO0VBQzVELE1BQU11QixTQUFTLEdBQUdwQyxJQUFJLEVBQUVxQyxLQUFLLEtBQUssTUFBTSxJQUFJckMsSUFBSSxFQUFFcUMsS0FBSyxLQUFLLEtBQUs7O0VBRWpFO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsTUFBTUMsT0FBTyxHQUFHLElBQUFDLHNCQUFjLEVBQUNqSixLQUFLLENBQUNVLE1BQU0sR0FBSTZHLE9BQU8sQ0FBQ3ZILEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBRSxHQUErQmtKLFNBQVMsQ0FBQztFQUMxRyxNQUFNakosVUFBVSxHQUFHRCxLQUFLLENBQUNVLE1BQU0sS0FBSyxDQUFDLElBQUksQ0FBQ29JLFNBQVM7O0VBRW5EO0VBQ0E7RUFDQSxNQUFNSyxTQUFTLEdBQUcsSUFBQUMsOEJBQWMsRUFBQzdDLFFBQVEsRUFBRTlFLElBQUksQ0FBQzs7RUFFaEQ7RUFDQSxJQUFBNkIsZ0JBQVMsRUFBQyxNQUFNO0lBQ2QsSUFBSStGLE1BQU0sR0FBRyxJQUFJO0lBQ2pCO0lBQ0FwRyxPQUFPLENBQUMsQ0FBQyxDQUFDO0lBQ1ZxRyxXQUFFLENBQUNDLFFBQVEsQ0FDUkMsUUFBUSxDQUFDLElBQUFDLG9CQUFXLEVBQUNsRCxRQUFRLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FDdkNtRCxJQUFJLENBQUVDLENBQVUsSUFBSztNQUNwQixJQUFJTixNQUFNLEVBQUVwRyxPQUFPLENBQUMsSUFBQTJHLGlCQUFXLEVBQUMsSUFBQUMsc0JBQWdCLEVBQUNDLE1BQU0sQ0FBQ0gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQy9ELENBQUMsQ0FBQyxDQUNESSxLQUFLLENBQUMsTUFBTWIsU0FBUyxDQUFDO0lBQ3pCLE9BQU8sTUFBTTtNQUNYRyxNQUFNLEdBQUcsS0FBSztJQUNoQixDQUFDO0VBQ0gsQ0FBQyxFQUFFLENBQUM5QyxRQUFRLENBQUMsQ0FBQzs7RUFFZDtFQUNBO0VBQ0EsTUFBTXlELFNBQVMsR0FBRyxJQUFBL0QscUJBQWdCLEVBQXNCZ0UsaUJBQVEsQ0FBQztFQUNqRSxNQUFNQyxRQUFtQixHQUFHLElBQUFDLGtCQUFZLEVBQVlILFNBQVMsQ0FBQyxDQUFDSSxHQUFHLENBQUMsQ0FBQztJQUFFQyxJQUFJO0lBQUVDO0VBQU0sQ0FBQyxNQUFNO0lBQ3ZGekcsR0FBRyxFQUFFd0csSUFBSTtJQUNURSxJQUFJLEVBQUUsSUFBQXpLLGtCQUFTLEVBQUN1SyxJQUFJLENBQUM7SUFDckJDO0VBQ0YsQ0FBQyxDQUFDLENBQUM7O0VBRUg7RUFDQSxNQUFNRSxVQUFVLEdBQUduRCxPQUFPLEdBQ3RCeEIsSUFBSSxDQUNEdUUsR0FBRyxDQUFFbEwsQ0FBQyxLQUFNO0lBQUVBLENBQUM7SUFBRXVMLEtBQUssRUFBRUMsT0FBTyxDQUFDeEwsQ0FBQyxFQUFFcUgsUUFBUTtFQUFFLENBQUMsQ0FBQyxDQUFDLENBQ2hEb0UsSUFBSSxDQUFDLENBQUNDLENBQUMsRUFBRWpCLENBQUMsS0FBS0EsQ0FBQyxDQUFDYyxLQUFLLEdBQUdHLENBQUMsQ0FBQ0gsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUV2TCxDQUFDLEdBQzFDZ0ssU0FBUztFQUViLE1BQU0yQixLQUFpQixHQUFHO0lBQ3hCOUYsS0FBSztJQUNMK0YsUUFBUSxFQUFFOUksV0FBVztJQUNyQndELEtBQUs7SUFDTHVGLFFBQVEsRUFBRTdJLGNBQWM7SUFDeEJRLFFBQVE7SUFDUkMsV0FBVztJQUNYQyxVQUFVO0lBQ1ZDLGFBQWE7SUFDYkMsVUFBVTtJQUNWQyxhQUFhO0lBQ2JHLEVBQUU7SUFDRjhGLE9BQU87SUFDUC9FLFFBQVE7SUFDUkssVUFBVTtJQUNWSCxRQUFRO0lBQ1JFLFdBQVc7SUFDWEUsUUFBUTtJQUNSc0MsU0FBUztJQUNUM0csSUFBSTtJQUNKZ0ssUUFBUTtJQUNSM0QsUUFBUTtJQUNSQyxXQUFXO0lBQ1hHLE1BQU07SUFDTkssU0FBUztJQUNUaEUsSUFBSTtJQUNKcUUsT0FBTztJQUNQbUQsVUFBVTtJQUNWckQ7RUFDRixDQUFDOztFQUVEO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsTUFBTTZELFVBQVUsR0FBRyxJQUFBcEwsbUJBQVUsRUFBQyxDQUFDLENBQUNDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDO0VBQ25ELE1BQU1vTCxXQUFXLEdBQUcsSUFBQUMsb0JBQVksRUFBQzNFLFFBQVEsRUFBRXlFLFVBQVUsQ0FBQztFQUN0RCxNQUFNRyxXQUFXLEdBQUc7SUFBRUMsSUFBSSxFQUFFSixVQUFVO0lBQUVLLEtBQUssRUFBRUosV0FBVztJQUFFSyxNQUFNLEVBQUU5TDtFQUFXLENBQUM7RUFFaEY7SUFBQTtJQUNFO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQSxJQUFBYixXQUFBLENBQUF5QixHQUFBLEVBQUNyRCxVQUFBLENBQUF3TyxnQkFBZ0IsQ0FBQ2pMLFFBQVE7TUFDeEJDLEtBQUssRUFBRTtRQUNMeUssVUFBVSxFQUFFLElBQUFRLDJCQUFjLEVBQUMsQ0FBQztRQUM1QjtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0FDLGNBQWMsRUFBRSxJQUFBQyx5QkFBWSxFQUFDO01BQy9CLENBQUU7TUFBQWxMLFFBQUEsZUFPSixJQUFBN0IsV0FBQSxDQUFBeUIsR0FBQSxFQUFDcEQsT0FBQSxDQUFBMk8sYUFBYTtRQUFDcEwsS0FBSyxFQUFFNEssV0FBWTtRQUFBM0ssUUFBQSxlQUNsQyxJQUFBN0IsV0FBQSxDQUFBeUIsR0FBQSxFQUFDeEMsTUFBQSxDQUFBZ08saUJBQWlCLENBQUN0TCxRQUFRO1VBQUNDLEtBQUssRUFBRXNLLEtBQU07VUFBQXJLLFFBQUEsZUFDdkMsSUFBQTdCLFdBQUEsQ0FBQWtOLElBQUE7WUFDRUMsU0FBUyxFQUFDLFlBQVk7WUFDdEIsV0FBUzVJLEVBQUc7WUFDWixZQUFVOEYsT0FBUTtZQUNsQixvQkFBa0JqRSxLQUFLLEtBQUssU0FBUyxHQUFHbUUsU0FBUyxHQUFHbkUsS0FBTTtZQUMxRCxjQUFZSSxRQUFTO1lBQUEzRSxRQUFBLGdCQUtyQixJQUFBN0IsV0FBQSxDQUFBeUIsR0FBQSxFQUFDakMsWUFBQSxDQUFBYSxPQUFXO2NBQUMrTSxZQUFZLEVBQUUsSUFBQUMsMEJBQWMsRUFBQ2pILEtBQUs7WUFBRSxDQUFFLENBQUMsZUFDcEQsSUFBQXBHLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ2hDLGFBQUEsQ0FBQVksT0FBWTtjQUFDaU4sTUFBTSxFQUFFeEUsV0FBVyxDQUFDd0UsTUFBTztjQUFDQyxVQUFVLEVBQUVBLENBQUM3QixJQUFJLEVBQUUvSyxDQUFDLEtBQUtzSSxnQkFBZ0IsQ0FBQyxHQUFHeUMsSUFBSSxJQUFJL0ssQ0FBQyxDQUFDNk0sSUFBSSxNQUFNN00sQ0FBQyxDQUFDOE0sTUFBTSxFQUFFO1lBQUUsQ0FBRSxDQUFDLGVBSzFILElBQUF6TixXQUFBLENBQUF5QixHQUFBLEVBQUN2RCxJQUFBLENBQUF3UCxpQkFBaUI7Y0FBQ0MsUUFBUSxFQUFFbkQ7WUFBVSxDQUFFLENBQUMsZUFDMUMsSUFBQXhLLFdBQUEsQ0FBQWtOLElBQUE7Y0FBS0MsU0FBUyxFQUFDLGdCQUFnQjtjQUFDUyxHQUFHLEVBQUVwRCxTQUFVO2NBQUEzSSxRQUFBLEdBQzVDcUgsV0FBVyxDQUFDbkgsTUFBTSxHQUFHLENBQUMsZ0JBQ3JCLElBQUEvQixXQUFBLENBQUFrTixJQUFBO2dCQUFLQyxTQUFTLEVBQUMsa0JBQWtCO2dCQUFDVSxJQUFJLEVBQUMsUUFBUTtnQkFBQWhNLFFBQUEsZ0JBQzdDLElBQUE3QixXQUFBLENBQUF5QixHQUFBO2tCQUFBSSxRQUFBLEVBQVE7Z0JBQXVELENBQVEsQ0FBQyxlQUN4RSxJQUFBN0IsV0FBQSxDQUFBeUIsR0FBQTtrQkFBQUksUUFBQSxFQUNHcUgsV0FBVyxDQUFDdUMsR0FBRyxDQUFDLENBQUN0TCxDQUFDLEVBQUUyQixDQUFDLGtCQUNwQixJQUFBOUIsV0FBQSxDQUFBeUIsR0FBQTtvQkFBQUksUUFBQSxFQUFhMUI7a0JBQUMsR0FBTDJCLENBQVUsQ0FDcEI7Z0JBQUMsQ0FDQSxDQUFDO2NBQUEsQ0FDRixDQUFDLEdBQ0osSUFBSSxFQUNQVSxrQkFBa0IsQ0FBQ1QsTUFBTSxHQUFHLENBQUMsZ0JBQzVCLElBQUEvQixXQUFBLENBQUFrTixJQUFBO2dCQUFLQyxTQUFTLEVBQUMsa0JBQWtCO2dCQUFDVSxJQUFJLEVBQUMsUUFBUTtnQkFBQWhNLFFBQUEsZ0JBQzdDLElBQUE3QixXQUFBLENBQUF5QixHQUFBO2tCQUFBSSxRQUFBLEVBQVE7Z0JBQXlELENBQVEsQ0FBQyxlQUMxRSxJQUFBN0IsV0FBQSxDQUFBeUIsR0FBQTtrQkFBQUksUUFBQSxFQUNHVyxrQkFBa0IsQ0FBQ2lKLEdBQUcsQ0FBRXFDLENBQUMsaUJBQ3hCLElBQUE5TixXQUFBLENBQUFrTixJQUFBO29CQUFBckwsUUFBQSxnQkFDRSxJQUFBN0IsV0FBQSxDQUFBeUIsR0FBQTtzQkFBQUksUUFBQSxFQUFPaU0sQ0FBQyxDQUFDQztvQkFBSSxDQUFPLENBQUMsWUFBRyxFQUFDRCxDQUFDLENBQUNMLE1BQU07a0JBQUEsR0FEMUJLLENBQUMsQ0FBQ0MsSUFFUCxDQUNMO2dCQUFDLENBQ0EsQ0FBQztjQUFBLENBQ0YsQ0FBQyxHQUNKLElBQUksZUFDUixJQUFBL04sV0FBQSxDQUFBeUIsR0FBQTtnQkFBSzBMLFNBQVMsRUFBQyxhQUFhO2dCQUFDLFlBQVVoRCxTQUFTLEdBQUdJLFNBQVMsR0FBR0YsT0FBUTtnQkFBQXhJLFFBQUEsRUFDcEVtSSxPQUFPLGdCQUFHLElBQUFoSyxXQUFBLENBQUF5QixHQUFBLEVBQUMvQixZQUFBLENBQUFXLE9BQVc7a0JBQUF3QixRQUFBLEVBQUVtSTtnQkFBTyxDQUFjLENBQUMsR0FBR0gsT0FBTyxnQkFBRyxJQUFBN0osV0FBQSxDQUFBeUIsR0FBQSxFQUFDL0IsWUFBQSxDQUFBVyxPQUFXLElBQUUsQ0FBQyxHQUFHZSxZQUFZLENBQUNDLEtBQUssRUFBRUMsVUFBVSxFQUFFQyxJQUFJO2NBQUMsQ0FDaEgsQ0FBQztZQUFBLENBQ0gsQ0FBQyxFQUVMMEMsVUFBVSxnQkFBRyxJQUFBakUsV0FBQSxDQUFBeUIsR0FBQSxFQUFDcEMsT0FBQSxDQUFBZ0IsT0FBTTtjQUFDMk4sT0FBTyxFQUFFQSxDQUFBLEtBQU05SixhQUFhLENBQUMsS0FBSztZQUFFLENBQUUsQ0FBQyxHQUFHLElBQUksRUFDbkVDLFVBQVUsZ0JBQ1QsSUFBQW5FLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ25DLE9BQUEsQ0FBQWUsT0FBTTtjQUNMNkgsU0FBUyxFQUFFQSxTQUFVO2NBQ3JCK0YsR0FBRyxFQUFFMUMsUUFBUSxDQUFDRSxHQUFHLENBQUV5QyxDQUFDLEtBQU07Z0JBQUV0QyxJQUFJLEVBQUVzQyxDQUFDLENBQUN0QyxJQUFJO2dCQUFFRCxLQUFLLEVBQUV1QyxDQUFDLENBQUN2QyxLQUFLO2dCQUFFd0MsR0FBRyxFQUFFRCxDQUFDLENBQUNoSixHQUFHLEtBQUswQztjQUFTLENBQUMsQ0FBQyxDQUFFO2NBQ3RGb0csT0FBTyxFQUFFQSxDQUFBLEtBQU01SixhQUFhLENBQUMsS0FBSztZQUFFLENBQ3JDLENBQUMsR0FDQSxJQUFJLGVBQ1IsSUFBQXBFLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ2xDLFdBQUEsQ0FBQWMsT0FBVTtjQUFDaUYsUUFBUSxFQUFFQSxRQUFTO2NBQUNzQyxRQUFRLEVBQUVBLFFBQVM7Y0FBQ3dHLFVBQVUsRUFBRSxJQUFBQyxtQkFBVSxFQUFDdEcsSUFBSSxFQUFFdUcsS0FBSyxJQUFJLFlBQVk7WUFBRSxDQUFFLENBQUM7VUFBQSxDQUN4RztRQUFDLENBQ29CO01BQUMsQ0FDZDtJQUFDLENBQ1c7RUFBQztBQUVoQzs7QUFFQTtBQUFBck8sRUFBQSxDQXZZd0JxQyxTQUFTO0VBQUEsUUFpRGJ1QixpQkFBWSxFQXNDbURnQyxvQ0FBaUIsRUFNakZLLG9CQUFlLEVBbUJwQm9CLHFCQUFnQixFQWlCZnBCLG9CQUFlLEVBc0JWdUMsd0NBQW1CLEVBTXJCSSxtQkFBYyxFQVFWRSw0Q0FBcUIsRUE2QnZCMEIsOEJBQWMsRUFvQmRuRCxxQkFBZ0I7QUFBQTtBQUFBaUgsRUFBQSxHQXROWmpNLFNBQVM7QUF3WWpDLFNBQVN5SixPQUFPQSxDQUFDRSxDQUFTLEVBQUVqQixDQUFTLEVBQVU7RUFDN0MsTUFBTXdELEVBQUUsR0FBR3ZDLENBQUMsQ0FBQy9LLE9BQU8sQ0FBQyxJQUFBRCxtQkFBVSxFQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQ0MsT0FBTyxDQUFDLFNBQVMsRUFBRSxFQUFFLENBQUM7RUFDN0QsTUFBTXVOLEVBQUUsR0FBR3pELENBQUMsQ0FBQzlKLE9BQU8sQ0FBQyxJQUFBRCxtQkFBVSxFQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQ0MsT0FBTyxDQUFDLFNBQVMsRUFBRSxFQUFFLENBQUM7RUFDN0QsTUFBTXdOLEdBQUcsR0FBR0YsRUFBRSxDQUFDNUUsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDK0UsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDakYsSUFBSSxDQUFDLEdBQUcsQ0FBQztFQUNoRCxNQUFNa0YsR0FBRyxHQUFHSCxFQUFFLENBQUM3RSxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMrRSxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUNqRixJQUFJLENBQUMsR0FBRyxDQUFDO0VBQ2hELElBQUlvQyxLQUFLLEdBQUc0QyxHQUFHLElBQUlBLEdBQUcsS0FBS0UsR0FBRyxHQUFHLENBQUMsR0FBRyxDQUFDO0VBQ3RDLE1BQU1DLEtBQUssR0FBR0wsRUFBRSxDQUFDNUUsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDa0YsR0FBRyxDQUFDLENBQUMsSUFBSSxFQUFFO0VBQ3ZDLE1BQU1DLEtBQUssR0FBR04sRUFBRSxDQUFDN0UsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDa0YsR0FBRyxDQUFDLENBQUMsSUFBSSxFQUFFO0VBQ3ZDLEtBQUssTUFBTUUsRUFBRSxJQUFJLElBQUlDLEdBQUcsQ0FBQ0osS0FBSyxDQUFDLEVBQUUsSUFBSUUsS0FBSyxDQUFDckgsUUFBUSxDQUFDc0gsRUFBRSxDQUFDLEVBQUVsRCxLQUFLLEVBQUU7RUFDaEUsT0FBT0EsS0FBSztBQUNkO0FBQUMsSUFBQXlDLEVBQUE7QUFBQVcsWUFBQSxDQUFBWCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}