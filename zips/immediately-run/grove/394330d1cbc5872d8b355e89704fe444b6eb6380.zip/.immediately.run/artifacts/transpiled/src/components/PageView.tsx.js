var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = PageView;
var _sdk = require("@immediately-run/sdk");
var _shell = require("../lib/shell");
var _content = require("../lib/content");
var _wiki = require("../lib/wiki");
var _useHeadingFragmentUrl = require("../hooks/useHeadingFragmentUrl");
var _DirectoryView = _interopRequireDefault(require("./DirectoryView"));
var _EntryHeader = _interopRequireDefault(require("./EntryHeader"));
var _SafeEntryBody = _interopRequireDefault(require("./SafeEntryBody"));
var _ScrollToFragment = _interopRequireDefault(require("./ScrollToFragment"));
var _Toc = _interopRequireDefault(require("./Toc"));
var _Backlinks = _interopRequireDefault(require("./Backlinks"));
var _Icon = _interopRequireDefault(require("./Icon"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$();
/* eslint-disable @typescript-eslint/no-explicit-any */
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// `<PageView/>` — the reading view for the current entry: the 404/missing state,
// or the entry header + prose body (+ ToC / backlinks rails). This is what the
// INNERMOST `<Outlet/>` renders at the bottom of the layout chain. It carries no
// site chrome (nav / sidebar / footer) — that's the layout's job — so the page
// stays free of shell concerns.
function PageView() {
  _s();
  const {
    entryKey,
    includePath,
    layout,
    showRails,
    mins,
    missing,
    suggestion,
    writable,
    openEditor,
    editBusy,
    editRefused,
    editHint,
    vw,
    safe,
    directory
  } = (0, _shell.useShell)();

  // The reading view owns the headings, so it owns the outgoing half of deep
  // linking: same-page heading navigation writes the fragment into the host's
  // address bar (`useHeadingFragmentUrl` for the whole story).
  (0, _useHeadingFragmentUrl.useHeadingFragmentUrl)();

  // A folder URL. `checking` renders nothing rather than the 404: the readdir that
  // decides between them is one RPC away, and a 404 that appears and then turns into a
  // listing reads as a broken link that healed itself.
  if (directory.status === 'checking') return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    className: "grove-state",
    "data-state": "checking"
  });
  if (directory.status === 'ready') return /*#__PURE__*/(0, _jsxRuntime.jsx)(_DirectoryView.default, {});
  if (missing) {
    return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "grove-state",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "grove-state__art"
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("h2", {
        children: ["No entry at ", /*#__PURE__*/(0, _jsxRuntime.jsx)("code", {
          children: (0, _content.keyToRepoRel)(entryKey).replace(/^content/, '')
        }), "."]
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("p", {
        children: ["That link points to an entry that doesn\u2019t exist yet.", suggestion ? /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
          children: [" Did you mean ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_sdk.Link, {
            className: "grove-wikilink",
            "data-state": "ok",
            href: (0, _content.keyToHref)(suggestion),
            children: (0, _wiki.crumb)(suggestion)
          }), "?"]
        }) : null]
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "grove-state__actions",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_sdk.Link, {
          className: "btn-ghost",
          href: "/",
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
            name: "chevron-right"
          }), " Back to home"]
        }), writable ? /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
            className: "btn-primary",
            "data-busy": editBusy ? '1' : '0',
            title: editHint,
            disabled: editBusy,
            onClick: () => openEditor(entryKey),
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
              name: "file-plus"
            }), editBusy ? 'Opening editor…' : 'Create it']
          }), editRefused && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
            className: "grove-edit-refused",
            role: "status",
            children: _shell.EDIT_REFUSED_NOTICE
          })]
        }) : null]
      })]
    });
  }
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("article", {
    className: "grove-page",
    "data-layout": layout,
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "gp-main",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_EntryHeader.default, {
        entryKey: entryKey,
        writable: writable,
        mins: mins
      }), showRails && vw === 'mobile' ? /*#__PURE__*/(0, _jsxRuntime.jsxs)("details", {
        className: "grove-toc__disclosure",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("summary", {
          children: "On this page"
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_Toc.default, {
          entryKey: entryKey
        })]
      }) : null, /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "grove-prose",
        children: safe ? /*#__PURE__*/(0, _jsxRuntime.jsx)(_SafeEntryBody.default, {
          entryKey: entryKey
        }) : /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
          className: "grove-entry-body",
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_sdk.Include, {
            filename: includePath,
            baseModule: module
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_ScrollToFragment.default, {
            entryKey: entryKey
          })]
        }, entryKey)
      }), showRails ? /*#__PURE__*/(0, _jsxRuntime.jsx)(_Backlinks.default, {}) : null]
    }), showRails && vw === 'desktop' ? /*#__PURE__*/(0, _jsxRuntime.jsx)(_Toc.default, {
      entryKey: entryKey
    }) : null]
  });
}
_s(PageView, "jIBoBsQs6RUqt96eNXUXGXcJ36Y=", false, function () {
  return [_shell.useShell, _useHeadingFragmentUrl.useHeadingFragmentUrl];
});
_c = PageView;
var _c;
$RefreshReg$(_c, "PageView");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfc2RrIiwicmVxdWlyZSIsIl9zaGVsbCIsIl9jb250ZW50IiwiX3dpa2kiLCJfdXNlSGVhZGluZ0ZyYWdtZW50VXJsIiwiX0RpcmVjdG9yeVZpZXciLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX0VudHJ5SGVhZGVyIiwiX1NhZmVFbnRyeUJvZHkiLCJfU2Nyb2xsVG9GcmFnbWVudCIsIl9Ub2MiLCJfQmFja2xpbmtzIiwiX0ljb24iLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiUGFnZVZpZXciLCJlbnRyeUtleSIsImluY2x1ZGVQYXRoIiwibGF5b3V0Iiwic2hvd1JhaWxzIiwibWlucyIsIm1pc3NpbmciLCJzdWdnZXN0aW9uIiwid3JpdGFibGUiLCJvcGVuRWRpdG9yIiwiZWRpdEJ1c3kiLCJlZGl0UmVmdXNlZCIsImVkaXRIaW50IiwidnciLCJzYWZlIiwiZGlyZWN0b3J5IiwidXNlU2hlbGwiLCJ1c2VIZWFkaW5nRnJhZ21lbnRVcmwiLCJzdGF0dXMiLCJqc3giLCJjbGFzc05hbWUiLCJqc3hzIiwiY2hpbGRyZW4iLCJrZXlUb1JlcG9SZWwiLCJyZXBsYWNlIiwiRnJhZ21lbnQiLCJMaW5rIiwiaHJlZiIsImtleVRvSHJlZiIsImNydW1iIiwibmFtZSIsInRpdGxlIiwiZGlzYWJsZWQiLCJvbkNsaWNrIiwicm9sZSIsIkVESVRfUkVGVVNFRF9OT1RJQ0UiLCJJbmNsdWRlIiwiZmlsZW5hbWUiLCJiYXNlTW9kdWxlIiwibW9kdWxlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJQYWdlVmlldy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueSAqL1xuaW1wb3J0IHsgSW5jbHVkZSwgTGluayB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrJztcbmltcG9ydCB7IHVzZVNoZWxsLCBFRElUX1JFRlVTRURfTk9USUNFIH0gZnJvbSAnLi4vbGliL3NoZWxsJztcbmltcG9ydCB7IGtleVRvSHJlZiwga2V5VG9SZXBvUmVsIH0gZnJvbSAnLi4vbGliL2NvbnRlbnQnO1xuaW1wb3J0IHsgY3J1bWIgfSBmcm9tICcuLi9saWIvd2lraSc7XG5pbXBvcnQgeyB1c2VIZWFkaW5nRnJhZ21lbnRVcmwgfSBmcm9tICcuLi9ob29rcy91c2VIZWFkaW5nRnJhZ21lbnRVcmwnO1xuaW1wb3J0IERpcmVjdG9yeVZpZXcgZnJvbSAnLi9EaXJlY3RvcnlWaWV3JztcbmltcG9ydCBFbnRyeUhlYWRlciBmcm9tICcuL0VudHJ5SGVhZGVyJztcbmltcG9ydCBTYWZlRW50cnlCb2R5IGZyb20gJy4vU2FmZUVudHJ5Qm9keSc7XG5pbXBvcnQgU2Nyb2xsVG9GcmFnbWVudCBmcm9tICcuL1Njcm9sbFRvRnJhZ21lbnQnO1xuaW1wb3J0IFRvYyBmcm9tICcuL1RvYyc7XG5pbXBvcnQgQmFja2xpbmtzIGZyb20gJy4vQmFja2xpbmtzJztcbmltcG9ydCBJY29uIGZyb20gJy4vSWNvbic7XG5cbmRlY2xhcmUgY29uc3QgbW9kdWxlOiBhbnk7XG5cbi8vIGA8UGFnZVZpZXcvPmAg4oCUIHRoZSByZWFkaW5nIHZpZXcgZm9yIHRoZSBjdXJyZW50IGVudHJ5OiB0aGUgNDA0L21pc3Npbmcgc3RhdGUsXG4vLyBvciB0aGUgZW50cnkgaGVhZGVyICsgcHJvc2UgYm9keSAoKyBUb0MgLyBiYWNrbGlua3MgcmFpbHMpLiBUaGlzIGlzIHdoYXQgdGhlXG4vLyBJTk5FUk1PU1QgYDxPdXRsZXQvPmAgcmVuZGVycyBhdCB0aGUgYm90dG9tIG9mIHRoZSBsYXlvdXQgY2hhaW4uIEl0IGNhcnJpZXMgbm9cbi8vIHNpdGUgY2hyb21lIChuYXYgLyBzaWRlYmFyIC8gZm9vdGVyKSDigJQgdGhhdCdzIHRoZSBsYXlvdXQncyBqb2Ig4oCUIHNvIHRoZSBwYWdlXG4vLyBzdGF5cyBmcmVlIG9mIHNoZWxsIGNvbmNlcm5zLlxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUGFnZVZpZXcoKSB7XG4gIGNvbnN0IHsgZW50cnlLZXksIGluY2x1ZGVQYXRoLCBsYXlvdXQsIHNob3dSYWlscywgbWlucywgbWlzc2luZywgc3VnZ2VzdGlvbiwgd3JpdGFibGUsIG9wZW5FZGl0b3IsIGVkaXRCdXN5LCBlZGl0UmVmdXNlZCwgZWRpdEhpbnQsIHZ3LCBzYWZlLCBkaXJlY3RvcnkgfSA9XG4gICAgdXNlU2hlbGwoKTtcblxuICAvLyBUaGUgcmVhZGluZyB2aWV3IG93bnMgdGhlIGhlYWRpbmdzLCBzbyBpdCBvd25zIHRoZSBvdXRnb2luZyBoYWxmIG9mIGRlZXBcbiAgLy8gbGlua2luZzogc2FtZS1wYWdlIGhlYWRpbmcgbmF2aWdhdGlvbiB3cml0ZXMgdGhlIGZyYWdtZW50IGludG8gdGhlIGhvc3Qnc1xuICAvLyBhZGRyZXNzIGJhciAoYHVzZUhlYWRpbmdGcmFnbWVudFVybGAgZm9yIHRoZSB3aG9sZSBzdG9yeSkuXG4gIHVzZUhlYWRpbmdGcmFnbWVudFVybCgpO1xuXG4gIC8vIEEgZm9sZGVyIFVSTC4gYGNoZWNraW5nYCByZW5kZXJzIG5vdGhpbmcgcmF0aGVyIHRoYW4gdGhlIDQwNDogdGhlIHJlYWRkaXIgdGhhdFxuICAvLyBkZWNpZGVzIGJldHdlZW4gdGhlbSBpcyBvbmUgUlBDIGF3YXksIGFuZCBhIDQwNCB0aGF0IGFwcGVhcnMgYW5kIHRoZW4gdHVybnMgaW50byBhXG4gIC8vIGxpc3RpbmcgcmVhZHMgYXMgYSBicm9rZW4gbGluayB0aGF0IGhlYWxlZCBpdHNlbGYuXG4gIGlmIChkaXJlY3Rvcnkuc3RhdHVzID09PSAnY2hlY2tpbmcnKSByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJncm92ZS1zdGF0ZVwiIGRhdGEtc3RhdGU9XCJjaGVja2luZ1wiIC8+O1xuICBpZiAoZGlyZWN0b3J5LnN0YXR1cyA9PT0gJ3JlYWR5JykgcmV0dXJuIDxEaXJlY3RvcnlWaWV3IC8+O1xuXG4gIGlmIChtaXNzaW5nKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JvdmUtc3RhdGVcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncm92ZS1zdGF0ZV9fYXJ0XCIgLz5cbiAgICAgICAgPGgyPk5vIGVudHJ5IGF0IDxjb2RlPntrZXlUb1JlcG9SZWwoZW50cnlLZXkpLnJlcGxhY2UoL15jb250ZW50LywgJycpfTwvY29kZT4uPC9oMj5cbiAgICAgICAgPHA+XG4gICAgICAgICAgVGhhdCBsaW5rIHBvaW50cyB0byBhbiBlbnRyeSB0aGF0IGRvZXNu4oCZdCBleGlzdCB5ZXQuXG4gICAgICAgICAge3N1Z2dlc3Rpb24gPyA8PiBEaWQgeW91IG1lYW4gPExpbmsgY2xhc3NOYW1lPVwiZ3JvdmUtd2lraWxpbmtcIiBkYXRhLXN0YXRlPVwib2tcIiBocmVmPXtrZXlUb0hyZWYoc3VnZ2VzdGlvbil9PntjcnVtYihzdWdnZXN0aW9uKX08L0xpbms+PzwvPiA6IG51bGx9XG4gICAgICAgIDwvcD5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncm92ZS1zdGF0ZV9fYWN0aW9uc1wiPlxuICAgICAgICAgIDxMaW5rIGNsYXNzTmFtZT1cImJ0bi1naG9zdFwiIGhyZWY9XCIvXCI+PEljb24gbmFtZT1cImNoZXZyb24tcmlnaHRcIiAvPiBCYWNrIHRvIGhvbWU8L0xpbms+XG4gICAgICAgICAge3dyaXRhYmxlID8gKFxuICAgICAgICAgICAgPD5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYnRuLXByaW1hcnlcIlxuICAgICAgICAgICAgICBkYXRhLWJ1c3k9e2VkaXRCdXN5ID8gJzEnIDogJzAnfVxuICAgICAgICAgICAgICB0aXRsZT17ZWRpdEhpbnR9XG4gICAgICAgICAgICAgIGRpc2FibGVkPXtlZGl0QnVzeX1cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb3BlbkVkaXRvcihlbnRyeUtleSl9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJmaWxlLXBsdXNcIiAvPntlZGl0QnVzeSA/ICdPcGVuaW5nIGVkaXRvcuKApicgOiAnQ3JlYXRlIGl0J31cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICB7ZWRpdFJlZnVzZWQgJiYgKFxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImdyb3ZlLWVkaXQtcmVmdXNlZFwiIHJvbGU9XCJzdGF0dXNcIj57RURJVF9SRUZVU0VEX05PVElDRX08L3NwYW4+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8Lz5cbiAgICAgICAgICApIDogbnVsbH1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICApO1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8YXJ0aWNsZSBjbGFzc05hbWU9XCJncm92ZS1wYWdlXCIgZGF0YS1sYXlvdXQ9e2xheW91dH0+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdwLW1haW5cIj5cbiAgICAgICAgPEVudHJ5SGVhZGVyIGVudHJ5S2V5PXtlbnRyeUtleX0gd3JpdGFibGU9e3dyaXRhYmxlfSBtaW5zPXttaW5zfSAvPlxuICAgICAgICB7c2hvd1JhaWxzICYmIHZ3ID09PSAnbW9iaWxlJyA/IChcbiAgICAgICAgICA8ZGV0YWlscyBjbGFzc05hbWU9XCJncm92ZS10b2NfX2Rpc2Nsb3N1cmVcIj5cbiAgICAgICAgICAgIDxzdW1tYXJ5Pk9uIHRoaXMgcGFnZTwvc3VtbWFyeT5cbiAgICAgICAgICAgIDxUb2MgZW50cnlLZXk9e2VudHJ5S2V5fSAvPlxuICAgICAgICAgIDwvZGV0YWlscz5cbiAgICAgICAgKSA6IG51bGx9XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JvdmUtcHJvc2VcIj5cbiAgICAgICAgICB7LyogSW50ZXJwcmV0ZXIgbW9kZSAoUjMtMjEzKSByZW5kZXJzIHRoZSByYXcgZW50cnkgYXMgZGF0YSDigJQgbm8gYXV0aG9yIEpTIHJ1bnM7XG4gICAgICAgICAgICAgIGV4ZWN1dGFibGUgbW9kZSBjb21waWxlcyArIHJ1bnMgdGhlIE1EWCB2aWEgPEluY2x1ZGU+LiBCb3RoIGFyZSBzdXBwb3J0ZWQsXG4gICAgICAgICAgICAgIGFuZCBzaW5jZSBSMy0yNTIgdGhlIGNob2ljZSBpcyBwZXItZW50cnkgYXMgd2VsbCBhcyB3aWtpLXdpZGUuXG5cbiAgICAgICAgICAgICAgVGhlIGNvbXBpbGVkIGJyYW5jaCBtb3VudHMgPFNjcm9sbFRvRnJhZ21lbnQ+IHRvbyDigJQgZGVlcC1saW5rIGxhbmRpbmcgaXMgbm90XG4gICAgICAgICAgICAgIGEgc2FmZS1wYXRoIGZlYXR1cmUg4oCUIGJ1dCBkZWxpYmVyYXRlbHkgY2FycmllcyBOTyBgZGF0YS1lbnRyeWAgbWFya2VyLCBhbmRcbiAgICAgICAgICAgICAgYm90aCBoYWx2ZXMgb2YgdGhhdCBhcmUgbG9hZC1iZWFyaW5nIChSMy0yNTIpLlxuXG4gICAgICAgICAgICAgIGBrZXk9e2VudHJ5S2V5fWAgZm9yY2VzIGFuIHVubW91bnQgYWNyb3NzIGEgY2xpZW50LXNpZGUgbmF2aWdhdGlvbi4gV2l0aG91dFxuICAgICAgICAgICAgICBpdCBSZWFjdCByZXVzZXMgdGhpcyBzdWJ0cmVlIGFuZCBrZWVwcyB0aGUgUFJFVklPVVMgZG9jdW1lbnQgbW91bnRlZCB3aGlsZVxuICAgICAgICAgICAgICB0aGUgbmV3IG9uZSBjb21waWxlcywgc28gYCNzZWMtNGAgcmVzb2x2ZXMgYWdhaW5zdCB0aGUgd3JvbmcgZW50cnkg4oCUIGV2ZXJ5XG4gICAgICAgICAgICAgIGVudHJ5IGhlcmUgbnVtYmVycyBpdHMgc2VjdGlvbnMgZnJvbSAxLCBzbyB0aGF0IGxvb2t1cCBhbHdheXMgc3VjY2VlZHMgYW5kXG4gICAgICAgICAgICAgIGFsd2F5cyBsYW5kcyB3cm9uZy4gTWVhc3VyZWQgb24gdGhlIGhvc3Q6IGEgY2l0YXRpb24gdG8gY29yZV9jb25jZXB0cyDCpzRcbiAgICAgICAgICAgICAgKFwiNCDigJQgUHJpbmNpcGFsXCIpIHNjcm9sbGVkIHRvIGEgZGlmZmVyZW50IGRvY3VtZW50J3MgXCI0LiBUaGUgcHJvdmlkZXItZmFjaW5nXG4gICAgICAgICAgICAgIGNvbnRyYWN0XCIgKFIzLTI0OSdzIGhhemFyZCwgcmVpbnRyb2R1Y2VkKS5cblxuICAgICAgICAgICAgICBObyBtYXJrZXIsIGJlY2F1c2UgYDxJbmNsdWRlPmAgb3ducyBhbiBpbnRlcm5hbCA8U3VzcGVuc2U+IGFuZCB0aGlzIHdyYXBwZXJcbiAgICAgICAgICAgICAgaXMgT1VUU0lERSBpdCDigJQgc28gYSBtYXJrZXIgaGVyZSB3b3VsZCBhcHBlYXIgdGhlIGluc3RhbnQgd2UgbmF2aWdhdGUsIHdoaWxlXG4gICAgICAgICAgICAgIHRoZSBib2R5IGlzIHN0aWxsIGNvbXBpbGluZywgYW5kIGNsYWltIGEgY29tbWl0IHRoYXQgaGFzIG5vdCBoYXBwZW5lZC4gVGhhdFxuICAgICAgICAgICAgICBpcyB3b3JzZSB0aGFuIG5vIHNpZ25hbDogYGRhdGEtZW50cnlgIG1lYW5zIFwidGhpcyBzdWJ0cmVlIGhvbGRzIGVudHJ5IFgnc1xuICAgICAgICAgICAgICBjb21taXR0ZWQgYm9keVwiIGV2ZXJ5d2hlcmUgZWxzZSAoYFNhZmVFbnRyeUJvZHlgIHB1dHMgaXQgaW5zaWRlIHRoZSBzdXNwZW5kZWRcbiAgICAgICAgICAgICAgc3VidHJlZSwgc28gaXQgaXMgdHJ1ZSB0aGVyZSksIGFuZCB0aGUgb24taG9zdCBoYXJuZXNzIHdhaXRzIG9uIGl0LiBLZXlpbmdcbiAgICAgICAgICAgICAgYWxyZWFkeSByZW1vdmVzIHRoZSBoYXphcmQgdGhlIG1hcmtlciBkZWZlbmRlZCBhZ2FpbnN0IOKAlCB0aGUgb3V0Z29pbmdcbiAgICAgICAgICAgICAgZG9jdW1lbnQgaXMgZ29uZSBmcm9tIHRoZSBET00sIG5vdCBsaW5nZXJpbmcg4oCUIHNvIGByZXNvbHZlRnJhZ21lbnRUYXJnZXRgJ3NcbiAgICAgICAgICAgICAgZG9jdW1lbnRlZCBkb2N1bWVudC13aWRlIGZhbGxiYWNrIGZvciB0aGUgY29tcGlsZWQgcGF0aCBpcyBzYWZlIGhlcmUuICovfVxuICAgICAgICAgIHtzYWZlID8gKFxuICAgICAgICAgICAgPFNhZmVFbnRyeUJvZHkgZW50cnlLZXk9e2VudHJ5S2V5fSAvPlxuICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyb3ZlLWVudHJ5LWJvZHlcIiBrZXk9e2VudHJ5S2V5fT5cbiAgICAgICAgICAgICAgPEluY2x1ZGUgZmlsZW5hbWU9e2luY2x1ZGVQYXRofSBiYXNlTW9kdWxlPXttb2R1bGV9IC8+XG4gICAgICAgICAgICAgIDxTY3JvbGxUb0ZyYWdtZW50IGVudHJ5S2V5PXtlbnRyeUtleX0gLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgICB7c2hvd1JhaWxzID8gPEJhY2tsaW5rcyAvPiA6IG51bGx9XG4gICAgICA8L2Rpdj5cbiAgICAgIHtzaG93UmFpbHMgJiYgdncgPT09ICdkZXNrdG9wJyA/IDxUb2MgZW50cnlLZXk9e2VudHJ5S2V5fSAvPiA6IG51bGx9XG4gICAgPC9hcnRpY2xlPlxuICApO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFDQSxJQUFBQSxJQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxNQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxRQUFBLEdBQUFGLE9BQUE7QUFDQSxJQUFBRyxLQUFBLEdBQUFILE9BQUE7QUFDQSxJQUFBSSxzQkFBQSxHQUFBSixPQUFBO0FBQ0EsSUFBQUssY0FBQSxHQUFBQyxzQkFBQSxDQUFBTixPQUFBO0FBQ0EsSUFBQU8sWUFBQSxHQUFBRCxzQkFBQSxDQUFBTixPQUFBO0FBQ0EsSUFBQVEsY0FBQSxHQUFBRixzQkFBQSxDQUFBTixPQUFBO0FBQ0EsSUFBQVMsaUJBQUEsR0FBQUgsc0JBQUEsQ0FBQU4sT0FBQTtBQUNBLElBQUFVLElBQUEsR0FBQUosc0JBQUEsQ0FBQU4sT0FBQTtBQUNBLElBQUFXLFVBQUEsR0FBQUwsc0JBQUEsQ0FBQU4sT0FBQTtBQUNBLElBQUFZLEtBQUEsR0FBQU4sc0JBQUEsQ0FBQU4sT0FBQTtBQUEwQixJQUFBYSxXQUFBLEdBQUFiLE9BQUE7QUFBQSxJQUFBYyxFQUFBLEdBQUFDLFlBQUE7QUFaMUI7QUFBQSxTQUFBVCx1QkFBQVUsQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQWdCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ2UsU0FBU0csUUFBUUEsQ0FBQSxFQUFHO0VBQUFMLEVBQUE7RUFDakMsTUFBTTtJQUFFTSxRQUFRO0lBQUVDLFdBQVc7SUFBRUMsTUFBTTtJQUFFQyxTQUFTO0lBQUVDLElBQUk7SUFBRUMsT0FBTztJQUFFQyxVQUFVO0lBQUVDLFFBQVE7SUFBRUMsVUFBVTtJQUFFQyxRQUFRO0lBQUVDLFdBQVc7SUFBRUMsUUFBUTtJQUFFQyxFQUFFO0lBQUVDLElBQUk7SUFBRUM7RUFBVSxDQUFDLEdBQ3ZKLElBQUFDLGVBQVEsRUFBQyxDQUFDOztFQUVaO0VBQ0E7RUFDQTtFQUNBLElBQUFDLDRDQUFxQixFQUFDLENBQUM7O0VBRXZCO0VBQ0E7RUFDQTtFQUNBLElBQUlGLFNBQVMsQ0FBQ0csTUFBTSxLQUFLLFVBQVUsRUFBRSxvQkFBTyxJQUFBeEIsV0FBQSxDQUFBeUIsR0FBQTtJQUFLQyxTQUFTLEVBQUMsYUFBYTtJQUFDLGNBQVc7RUFBVSxDQUFFLENBQUM7RUFDakcsSUFBSUwsU0FBUyxDQUFDRyxNQUFNLEtBQUssT0FBTyxFQUFFLG9CQUFPLElBQUF4QixXQUFBLENBQUF5QixHQUFBLEVBQUNqQyxjQUFBLENBQUFhLE9BQWEsSUFBRSxDQUFDO0VBRTFELElBQUlPLE9BQU8sRUFBRTtJQUNYLG9CQUNFLElBQUFaLFdBQUEsQ0FBQTJCLElBQUE7TUFBS0QsU0FBUyxFQUFDLGFBQWE7TUFBQUUsUUFBQSxnQkFDMUIsSUFBQTVCLFdBQUEsQ0FBQXlCLEdBQUE7UUFBS0MsU0FBUyxFQUFDO01BQWtCLENBQUUsQ0FBQyxlQUNwQyxJQUFBMUIsV0FBQSxDQUFBMkIsSUFBQTtRQUFBQyxRQUFBLEdBQUksY0FBWSxtQkFBQTVCLFdBQUEsQ0FBQXlCLEdBQUE7VUFBQUcsUUFBQSxFQUFPLElBQUFDLHFCQUFZLEVBQUN0QixRQUFRLENBQUMsQ0FBQ3VCLE9BQU8sQ0FBQyxVQUFVLEVBQUUsRUFBRTtRQUFDLENBQU8sQ0FBQyxLQUFDO01BQUEsQ0FBSSxDQUFDLGVBQ25GLElBQUE5QixXQUFBLENBQUEyQixJQUFBO1FBQUFDLFFBQUEsR0FBRywyREFFRCxFQUFDZixVQUFVLGdCQUFHLElBQUFiLFdBQUEsQ0FBQTJCLElBQUEsRUFBQTNCLFdBQUEsQ0FBQStCLFFBQUE7VUFBQUgsUUFBQSxHQUFFLGdCQUFjLG1CQUFBNUIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdkMsSUFBQSxDQUFBOEMsSUFBSTtZQUFDTixTQUFTLEVBQUMsZ0JBQWdCO1lBQUMsY0FBVyxJQUFJO1lBQUNPLElBQUksRUFBRSxJQUFBQyxrQkFBUyxFQUFDckIsVUFBVSxDQUFFO1lBQUFlLFFBQUEsRUFBRSxJQUFBTyxXQUFLLEVBQUN0QixVQUFVO1VBQUMsQ0FBTyxDQUFDLEtBQUM7UUFBQSxDQUFFLENBQUMsR0FBRyxJQUFJO01BQUEsQ0FDaEosQ0FBQyxlQUNKLElBQUFiLFdBQUEsQ0FBQTJCLElBQUE7UUFBS0QsU0FBUyxFQUFDLHNCQUFzQjtRQUFBRSxRQUFBLGdCQUNuQyxJQUFBNUIsV0FBQSxDQUFBMkIsSUFBQSxFQUFDekMsSUFBQSxDQUFBOEMsSUFBSTtVQUFDTixTQUFTLEVBQUMsV0FBVztVQUFDTyxJQUFJLEVBQUMsR0FBRztVQUFBTCxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUF5QixHQUFBLEVBQUMxQixLQUFBLENBQUFNLE9BQUk7WUFBQytCLElBQUksRUFBQztVQUFlLENBQUUsQ0FBQyxpQkFBYTtRQUFBLENBQU0sQ0FBQyxFQUNyRnRCLFFBQVEsZ0JBQ1AsSUFBQWQsV0FBQSxDQUFBMkIsSUFBQSxFQUFBM0IsV0FBQSxDQUFBK0IsUUFBQTtVQUFBSCxRQUFBLGdCQUNBLElBQUE1QixXQUFBLENBQUEyQixJQUFBO1lBQ0VELFNBQVMsRUFBQyxhQUFhO1lBQ3ZCLGFBQVdWLFFBQVEsR0FBRyxHQUFHLEdBQUcsR0FBSTtZQUNoQ3FCLEtBQUssRUFBRW5CLFFBQVM7WUFDaEJvQixRQUFRLEVBQUV0QixRQUFTO1lBQ25CdUIsT0FBTyxFQUFFQSxDQUFBLEtBQU14QixVQUFVLENBQUNSLFFBQVEsQ0FBRTtZQUFBcUIsUUFBQSxnQkFFcEMsSUFBQTVCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQzFCLEtBQUEsQ0FBQU0sT0FBSTtjQUFDK0IsSUFBSSxFQUFDO1lBQVcsQ0FBRSxDQUFDLEVBQUNwQixRQUFRLEdBQUcsaUJBQWlCLEdBQUcsV0FBVztVQUFBLENBQzlELENBQUMsRUFDTkMsV0FBVyxpQkFDVixJQUFBakIsV0FBQSxDQUFBeUIsR0FBQTtZQUFNQyxTQUFTLEVBQUMsb0JBQW9CO1lBQUNjLElBQUksRUFBQyxRQUFRO1lBQUFaLFFBQUEsRUFBRWE7VUFBbUIsQ0FBTyxDQUMvRTtRQUFBLENBQ0QsQ0FBQyxHQUNELElBQUk7TUFBQSxDQUNMLENBQUM7SUFBQSxDQUNILENBQUM7RUFFVjtFQUVBLG9CQUNFLElBQUF6QyxXQUFBLENBQUEyQixJQUFBO0lBQVNELFNBQVMsRUFBQyxZQUFZO0lBQUMsZUFBYWpCLE1BQU87SUFBQW1CLFFBQUEsZ0JBQ2xELElBQUE1QixXQUFBLENBQUEyQixJQUFBO01BQUtELFNBQVMsRUFBQyxTQUFTO01BQUFFLFFBQUEsZ0JBQ3RCLElBQUE1QixXQUFBLENBQUF5QixHQUFBLEVBQUMvQixZQUFBLENBQUFXLE9BQVc7UUFBQ0UsUUFBUSxFQUFFQSxRQUFTO1FBQUNPLFFBQVEsRUFBRUEsUUFBUztRQUFDSCxJQUFJLEVBQUVBO01BQUssQ0FBRSxDQUFDLEVBQ2xFRCxTQUFTLElBQUlTLEVBQUUsS0FBSyxRQUFRLGdCQUMzQixJQUFBbkIsV0FBQSxDQUFBMkIsSUFBQTtRQUFTRCxTQUFTLEVBQUMsdUJBQXVCO1FBQUFFLFFBQUEsZ0JBQ3hDLElBQUE1QixXQUFBLENBQUF5QixHQUFBO1VBQUFHLFFBQUEsRUFBUztRQUFZLENBQVMsQ0FBQyxlQUMvQixJQUFBNUIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDNUIsSUFBQSxDQUFBUSxPQUFHO1VBQUNFLFFBQVEsRUFBRUE7UUFBUyxDQUFFLENBQUM7TUFBQSxDQUNwQixDQUFDLEdBQ1IsSUFBSSxlQUNSLElBQUFQLFdBQUEsQ0FBQXlCLEdBQUE7UUFBS0MsU0FBUyxFQUFDLGFBQWE7UUFBQUUsUUFBQSxFQTBCekJSLElBQUksZ0JBQ0gsSUFBQXBCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQzlCLGNBQUEsQ0FBQVUsT0FBYTtVQUFDRSxRQUFRLEVBQUVBO1FBQVMsQ0FBRSxDQUFDLGdCQUVyQyxJQUFBUCxXQUFBLENBQUEyQixJQUFBO1VBQUtELFNBQVMsRUFBQyxrQkFBa0I7VUFBQUUsUUFBQSxnQkFDL0IsSUFBQTVCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3ZDLElBQUEsQ0FBQXdELE9BQU87WUFBQ0MsUUFBUSxFQUFFbkMsV0FBWTtZQUFDb0MsVUFBVSxFQUFFQztVQUFPLENBQUUsQ0FBQyxlQUN0RCxJQUFBN0MsV0FBQSxDQUFBeUIsR0FBQSxFQUFDN0IsaUJBQUEsQ0FBQVMsT0FBZ0I7WUFBQ0UsUUFBUSxFQUFFQTtVQUFTLENBQUUsQ0FBQztRQUFBLEdBRkhBLFFBR2xDO01BQ04sQ0FDRSxDQUFDLEVBQ0xHLFNBQVMsZ0JBQUcsSUFBQVYsV0FBQSxDQUFBeUIsR0FBQSxFQUFDM0IsVUFBQSxDQUFBTyxPQUFTLElBQUUsQ0FBQyxHQUFHLElBQUk7SUFBQSxDQUM5QixDQUFDLEVBQ0xLLFNBQVMsSUFBSVMsRUFBRSxLQUFLLFNBQVMsZ0JBQUcsSUFBQW5CLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQzVCLElBQUEsQ0FBQVEsT0FBRztNQUFDRSxRQUFRLEVBQUVBO0lBQVMsQ0FBRSxDQUFDLEdBQUcsSUFBSTtFQUFBLENBQzVELENBQUM7QUFFZDtBQUFDTixFQUFBLENBakd1QkssUUFBUTtFQUFBLFFBRTVCZ0IsZUFBUSxFQUtWQyw0Q0FBcUI7QUFBQTtBQUFBdUIsRUFBQSxHQVBDeEMsUUFBUTtBQUFBLElBQUF3QyxFQUFBO0FBQUFDLFlBQUEsQ0FBQUQsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}