var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = SafeEntryBody;
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
var _mdxComponents = require("../mdxComponents");
var _safeSources = require("../lib/safeSources");
var _ScrollToFragment = _interopRequireDefault(require("./ScrollToFragment"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The NON-EXECUTABLE (interpreter) body renderer — TRUST_MODES §5.1 / R3-213. It reads
// the entry's RAW `.mdx` and renders it through the SDK safe renderer (parseSafeMdast +
// renderMdast): **no author JavaScript executes** — a stray `{fetch(...)}` in any entry
// is inert literal text. This is the alternative to `<Include>` (the executable/executor
// path, where compiled MDX runs) that `PageView` uses when the wiki is NOT in interpreter
// mode. The engine keeps BOTH; the wiki declares which via the home entry's `render:` flag,
// so a trusted first-party grove deployment can still use standard, executable MDX.
//
// Uniformity (R3-213): the component map is `SAFE_MDX` — the SDK's DEFAULT_MDX_COMPONENTS
// (the platform Admonition / WikiLink / HeadingAnchor, carrying the R3-212 deep-link
// resolver) merged UNDER the Grove vocabulary, the SAME merge `boot()` does for the compiled
// path — so the admonitions / wiki-links / `sec-…` heading ids the shared remark plugins emit
// render identically in both standards. Since R3-263 that map lives in `mdxComponents.ts` and
// is shared with `SafeLayout`, so the body and the shell around it cannot resolve differently.
// We publish `RenderExportedComponentContext` with this entry's path so the WikiLink resolver
// learns the current file and a relative `[[target]]` (and its `#sec-…` fragment) resolves
// exactly as it does under `<Include>`.
/** Strip a leading YAML frontmatter block (and an optional BOM) so only the body reaches
 *  the safe renderer. */
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function stripFrontmatter(src) {
  return src.replace(/^\uFEFF?---\r?\n[\s\S]*?\r?\n---[ \t]*\r?\n?/, "");
}
function SafeBody({
  entryKey
}) {
  _s();
  const raw = (0, _react.use)(_safeSources.safeSources.read(entryKey));
  // Consume the entry's metadata so this re-renders if frontmatter changes (parity with
  // the compiled path's reactivity); the body itself is the stripped source.
  (0, _sdk.useFileMetadata)(entryKey);
  const body = stripFrontmatter(raw);
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_sdk.RenderExportedComponentContext, {
    value: {
      evaluationContext: {
        evaluation: {
          module: {
            filepath: entryKey
          }
        }
      }
    },
    children: /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "grove-entry-body",
      "data-entry": entryKey,
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_sdk.SafeContent, {
        source: body,
        components: _mdxComponents.SAFE_MDX,
        fallback: /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
          className: "grove-prose__loading"
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_ScrollToFragment.default, {
        entryKey: entryKey
      })]
    })
  });
}

/** Interpreter-mode entry body: the raw `.mdx` rendered as data (no author JS runs). */
_s(SafeBody, "HCQWmXfXYtrNQZ9MFtiZso5O/l0=", false, function () {
  return [_sdk.useFileMetadata];
});
_c = SafeBody;
function SafeEntryBody({
  entryKey
}) {
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_react.Suspense, {
    fallback: /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "grove-prose__loading"
    }),
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(SafeBody, {
      entryKey: entryKey
    })
  });
}
_c2 = SafeEntryBody;
var _c, _c2;
$RefreshReg$(_c, "SafeBody");
$RefreshReg$(_c2, "SafeEntryBody");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NkayIsIl9tZHhDb21wb25lbnRzIiwiX3NhZmVTb3VyY2VzIiwiX1Njcm9sbFRvRnJhZ21lbnQiLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsInN0cmlwRnJvbnRtYXR0ZXIiLCJzcmMiLCJyZXBsYWNlIiwiU2FmZUJvZHkiLCJlbnRyeUtleSIsInJhdyIsInVzZSIsInNhZmVTb3VyY2VzIiwicmVhZCIsInVzZUZpbGVNZXRhZGF0YSIsImJvZHkiLCJqc3giLCJSZW5kZXJFeHBvcnRlZENvbXBvbmVudENvbnRleHQiLCJ2YWx1ZSIsImV2YWx1YXRpb25Db250ZXh0IiwiZXZhbHVhdGlvbiIsIm1vZHVsZSIsImZpbGVwYXRoIiwiY2hpbGRyZW4iLCJqc3hzIiwiY2xhc3NOYW1lIiwiU2FmZUNvbnRlbnQiLCJzb3VyY2UiLCJjb21wb25lbnRzIiwiU0FGRV9NRFgiLCJmYWxsYmFjayIsIl9jIiwiU2FmZUVudHJ5Qm9keSIsIlN1c3BlbnNlIiwiX2MyIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiU2FmZUVudHJ5Qm9keS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgU3VzcGVuc2UsIHVzZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7XG4gIFNhZmVDb250ZW50LFxuICBSZW5kZXJFeHBvcnRlZENvbXBvbmVudENvbnRleHQsXG4gIHVzZUZpbGVNZXRhZGF0YSxcbn0gZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9zZGsnO1xuaW1wb3J0IHsgU0FGRV9NRFggfSBmcm9tICcuLi9tZHhDb21wb25lbnRzJztcbmltcG9ydCB7IHNhZmVTb3VyY2VzIH0gZnJvbSAnLi4vbGliL3NhZmVTb3VyY2VzJztcbmltcG9ydCBTY3JvbGxUb0ZyYWdtZW50IGZyb20gJy4vU2Nyb2xsVG9GcmFnbWVudCc7XG5cbi8vIFRoZSBOT04tRVhFQ1VUQUJMRSAoaW50ZXJwcmV0ZXIpIGJvZHkgcmVuZGVyZXIg4oCUIFRSVVNUX01PREVTIMKnNS4xIC8gUjMtMjEzLiBJdCByZWFkc1xuLy8gdGhlIGVudHJ5J3MgUkFXIGAubWR4YCBhbmQgcmVuZGVycyBpdCB0aHJvdWdoIHRoZSBTREsgc2FmZSByZW5kZXJlciAocGFyc2VTYWZlTWRhc3QgK1xuLy8gcmVuZGVyTWRhc3QpOiAqKm5vIGF1dGhvciBKYXZhU2NyaXB0IGV4ZWN1dGVzKiog4oCUIGEgc3RyYXkgYHtmZXRjaCguLi4pfWAgaW4gYW55IGVudHJ5XG4vLyBpcyBpbmVydCBsaXRlcmFsIHRleHQuIFRoaXMgaXMgdGhlIGFsdGVybmF0aXZlIHRvIGA8SW5jbHVkZT5gICh0aGUgZXhlY3V0YWJsZS9leGVjdXRvclxuLy8gcGF0aCwgd2hlcmUgY29tcGlsZWQgTURYIHJ1bnMpIHRoYXQgYFBhZ2VWaWV3YCB1c2VzIHdoZW4gdGhlIHdpa2kgaXMgTk9UIGluIGludGVycHJldGVyXG4vLyBtb2RlLiBUaGUgZW5naW5lIGtlZXBzIEJPVEg7IHRoZSB3aWtpIGRlY2xhcmVzIHdoaWNoIHZpYSB0aGUgaG9tZSBlbnRyeSdzIGByZW5kZXI6YCBmbGFnLFxuLy8gc28gYSB0cnVzdGVkIGZpcnN0LXBhcnR5IGdyb3ZlIGRlcGxveW1lbnQgY2FuIHN0aWxsIHVzZSBzdGFuZGFyZCwgZXhlY3V0YWJsZSBNRFguXG4vL1xuLy8gVW5pZm9ybWl0eSAoUjMtMjEzKTogdGhlIGNvbXBvbmVudCBtYXAgaXMgYFNBRkVfTURYYCDigJQgdGhlIFNESydzIERFRkFVTFRfTURYX0NPTVBPTkVOVFNcbi8vICh0aGUgcGxhdGZvcm0gQWRtb25pdGlvbiAvIFdpa2lMaW5rIC8gSGVhZGluZ0FuY2hvciwgY2FycnlpbmcgdGhlIFIzLTIxMiBkZWVwLWxpbmtcbi8vIHJlc29sdmVyKSBtZXJnZWQgVU5ERVIgdGhlIEdyb3ZlIHZvY2FidWxhcnksIHRoZSBTQU1FIG1lcmdlIGBib290KClgIGRvZXMgZm9yIHRoZSBjb21waWxlZFxuLy8gcGF0aCDigJQgc28gdGhlIGFkbW9uaXRpb25zIC8gd2lraS1saW5rcyAvIGBzZWMt4oCmYCBoZWFkaW5nIGlkcyB0aGUgc2hhcmVkIHJlbWFyayBwbHVnaW5zIGVtaXRcbi8vIHJlbmRlciBpZGVudGljYWxseSBpbiBib3RoIHN0YW5kYXJkcy4gU2luY2UgUjMtMjYzIHRoYXQgbWFwIGxpdmVzIGluIGBtZHhDb21wb25lbnRzLnRzYCBhbmRcbi8vIGlzIHNoYXJlZCB3aXRoIGBTYWZlTGF5b3V0YCwgc28gdGhlIGJvZHkgYW5kIHRoZSBzaGVsbCBhcm91bmQgaXQgY2Fubm90IHJlc29sdmUgZGlmZmVyZW50bHkuXG4vLyBXZSBwdWJsaXNoIGBSZW5kZXJFeHBvcnRlZENvbXBvbmVudENvbnRleHRgIHdpdGggdGhpcyBlbnRyeSdzIHBhdGggc28gdGhlIFdpa2lMaW5rIHJlc29sdmVyXG4vLyBsZWFybnMgdGhlIGN1cnJlbnQgZmlsZSBhbmQgYSByZWxhdGl2ZSBgW1t0YXJnZXRdXWAgKGFuZCBpdHMgYCNzZWMt4oCmYCBmcmFnbWVudCkgcmVzb2x2ZXNcbi8vIGV4YWN0bHkgYXMgaXQgZG9lcyB1bmRlciBgPEluY2x1ZGU+YC5cblxuLyoqIFN0cmlwIGEgbGVhZGluZyBZQU1MIGZyb250bWF0dGVyIGJsb2NrIChhbmQgYW4gb3B0aW9uYWwgQk9NKSBzbyBvbmx5IHRoZSBib2R5IHJlYWNoZXNcbiAqICB0aGUgc2FmZSByZW5kZXJlci4gKi9cbmZ1bmN0aW9uIHN0cmlwRnJvbnRtYXR0ZXIoc3JjOiBzdHJpbmcpOiBzdHJpbmcge1xuICByZXR1cm4gc3JjLnJlcGxhY2UoL15cXHVGRUZGPy0tLVxccj9cXG5bXFxzXFxTXSo/XFxyP1xcbi0tLVsgXFx0XSpcXHI/XFxuPy8sIFwiXCIpO1xufVxuXG5mdW5jdGlvbiBTYWZlQm9keSh7IGVudHJ5S2V5IH06IHsgZW50cnlLZXk6IHN0cmluZyB9KSB7XG4gIGNvbnN0IHJhdyA9IHVzZShzYWZlU291cmNlcy5yZWFkKGVudHJ5S2V5KSk7XG4gIC8vIENvbnN1bWUgdGhlIGVudHJ5J3MgbWV0YWRhdGEgc28gdGhpcyByZS1yZW5kZXJzIGlmIGZyb250bWF0dGVyIGNoYW5nZXMgKHBhcml0eSB3aXRoXG4gIC8vIHRoZSBjb21waWxlZCBwYXRoJ3MgcmVhY3Rpdml0eSk7IHRoZSBib2R5IGl0c2VsZiBpcyB0aGUgc3RyaXBwZWQgc291cmNlLlxuICB1c2VGaWxlTWV0YWRhdGEoZW50cnlLZXkpO1xuICBjb25zdCBib2R5ID0gc3RyaXBGcm9udG1hdHRlcihyYXcpO1xuICByZXR1cm4gKFxuICAgIDxSZW5kZXJFeHBvcnRlZENvbXBvbmVudENvbnRleHRcbiAgICAgIHZhbHVlPXt7IGV2YWx1YXRpb25Db250ZXh0OiB7IGV2YWx1YXRpb246IHsgbW9kdWxlOiB7IGZpbGVwYXRoOiBlbnRyeUtleSB9IH0gfSB9IGFzIG5ldmVyfVxuICAgID5cbiAgICAgIHsvKiBgZGF0YS1lbnRyeWAgbWFya3MgV0hJQ0ggZW50cnkgdGhlc2UgYnl0ZXMgYXJlLCBhbmQgaXQgaXMgcmVuZGVyZWQgSU5TSURFIHRoZVxuICAgICAgICAgIHN1c3BlbmRlZCBzdWJ0cmVlIOKAlCBzbyBpdCBmbGlwcyBvbmx5IHdoZW4gdGhlIG5ldyBib2R5IGFjdHVhbGx5IGNvbW1pdHMsIG5ldmVyXG4gICAgICAgICAgd2hpbGUgdGhlIHByZXZpb3VzIGVudHJ5IGlzIHN0aWxsIG9uIHNjcmVlbi4gYDxTY3JvbGxUb0ZyYWdtZW50PmAgd2FpdHMgZm9yIGl0XG4gICAgICAgICAgYmVmb3JlIHNjcm9sbGluZy4gV2l0aG91dCB0aGF0IHNpZ25hbCBhIGRlZXAtbGluayBzY3JvbGxzIHRoZSBPVVRHT0lORyBkb2N1bWVudDpcbiAgICAgICAgICBldmVyeSBzcGVjIGhhcyBgc2VjLTEg4oCmIHNlYy1OYCwgc28gdGhlIGlkIHRoZSBpbmNvbWluZyBwYWdlIHdhbnRzIGlzIGFscmVhZHkgaW5cbiAgICAgICAgICB0aGUgRE9NLCBhbmQgYSBzY3JvbGwgZmlyZWQgYXQgbmF2aWdhdGlvbiB0aW1lIGxhbmRzIG9uIHRoZSB3cm9uZyBwYWdlJ3Mgc2VjdGlvblxuICAgICAgICAgIGFuZCBpcyB0aGVuIHRocm93biBhd2F5IGJ5IHRoZSByZS1yZW5kZXIgKFIzLTI0OSkuICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncm92ZS1lbnRyeS1ib2R5XCIgZGF0YS1lbnRyeT17ZW50cnlLZXl9PlxuICAgICAgICA8U2FmZUNvbnRlbnQgc291cmNlPXtib2R5fSBjb21wb25lbnRzPXtTQUZFX01EWCBhcyBuZXZlcn0gZmFsbGJhY2s9ezxkaXYgY2xhc3NOYW1lPVwiZ3JvdmUtcHJvc2VfX2xvYWRpbmdcIiAvPn0gLz5cbiAgICAgICAgey8qIERlZXAtbGluayBsYW5kaW5nIGxpdmVzIElOU0lERSB0aGUgY29tbWl0dGVkIGJvZHksIG5vdCBvdXRzaWRlIHdhdGNoaW5nIGZvciBpdC5cbiAgICAgICAgICAgIE1vdW50ZWQgYW55d2hlcmUgYWJvdmUgdGhpcyBib3VuZGFyeSBpdCBpcyB1bm1vdW50ZWQgYnkgdGhlIHZlcnkgdHJhbnNpdGlvbiBpdFxuICAgICAgICAgICAgaXMgd2FpdGluZyBvbiDigJQgbWVhc3VyZWQgb24gdGhlIHJlYWwgaG9zdDogaXQgcG9sbGVkIDE1OSB0aW1lcyBhbmQgd2FzIHRvcm5cbiAgICAgICAgICAgIGRvd24gYXQgdGhlIGV4YWN0IG1vbWVudCB0aGUgbmV3IGJvZHkgYXJyaXZlZC4gSGVyZSBpdCBtb3VudHMgKmJlY2F1c2UqIHRoZVxuICAgICAgICAgICAgY29udGVudCBkaWQsIHNvIHRoZXJlIGlzIG5vdGhpbmcgdG8gd2FpdCBmb3IuICovfVxuICAgICAgICA8U2Nyb2xsVG9GcmFnbWVudCBlbnRyeUtleT17ZW50cnlLZXl9IC8+XG4gICAgICA8L2Rpdj5cbiAgICA8L1JlbmRlckV4cG9ydGVkQ29tcG9uZW50Q29udGV4dD5cbiAgKTtcbn1cblxuLyoqIEludGVycHJldGVyLW1vZGUgZW50cnkgYm9keTogdGhlIHJhdyBgLm1keGAgcmVuZGVyZWQgYXMgZGF0YSAobm8gYXV0aG9yIEpTIHJ1bnMpLiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gU2FmZUVudHJ5Qm9keSh7IGVudHJ5S2V5IH06IHsgZW50cnlLZXk6IHN0cmluZyB9KSB7XG4gIHJldHVybiAoXG4gICAgPFN1c3BlbnNlIGZhbGxiYWNrPXs8ZGl2IGNsYXNzTmFtZT1cImdyb3ZlLXByb3NlX19sb2FkaW5nXCIgLz59PlxuICAgICAgPFNhZmVCb2R5IGVudHJ5S2V5PXtlbnRyeUtleX0gLz5cbiAgICA8L1N1c3BlbnNlPlxuICApO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFBQSxJQUFBQSxNQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxJQUFBLEdBQUFELE9BQUE7QUFLQSxJQUFBRSxjQUFBLEdBQUFGLE9BQUE7QUFDQSxJQUFBRyxZQUFBLEdBQUFILE9BQUE7QUFDQSxJQUFBSSxpQkFBQSxHQUFBQyxzQkFBQSxDQUFBTCxPQUFBO0FBQWtELElBQUFNLFdBQUEsR0FBQU4sT0FBQTtBQUFBLElBQUFPLEVBQUEsR0FBQUMsWUFBQSxJQUVsRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQURBLFNBQUFILHVCQUFBSSxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBRUEsU0FBU0csZ0JBQWdCQSxDQUFDQyxHQUFXLEVBQVU7RUFDN0MsT0FBT0EsR0FBRyxDQUFDQyxPQUFPLENBQUMsOENBQThDLEVBQUUsRUFBRSxDQUFDO0FBQ3hFO0FBRUEsU0FBU0MsUUFBUUEsQ0FBQztFQUFFQztBQUErQixDQUFDLEVBQUU7RUFBQVQsRUFBQTtFQUNwRCxNQUFNVSxHQUFHLEdBQUcsSUFBQUMsVUFBRyxFQUFDQyx3QkFBVyxDQUFDQyxJQUFJLENBQUNKLFFBQVEsQ0FBQyxDQUFDO0VBQzNDO0VBQ0E7RUFDQSxJQUFBSyxvQkFBZSxFQUFDTCxRQUFRLENBQUM7RUFDekIsTUFBTU0sSUFBSSxHQUFHVixnQkFBZ0IsQ0FBQ0ssR0FBRyxDQUFDO0VBQ2xDLG9CQUNFLElBQUFYLFdBQUEsQ0FBQWlCLEdBQUEsRUFBQ3RCLElBQUEsQ0FBQXVCLDhCQUE4QjtJQUM3QkMsS0FBSyxFQUFFO01BQUVDLGlCQUFpQixFQUFFO1FBQUVDLFVBQVUsRUFBRTtVQUFFQyxNQUFNLEVBQUU7WUFBRUMsUUFBUSxFQUFFYjtVQUFTO1FBQUU7TUFBRTtJQUFFLENBQVc7SUFBQWMsUUFBQSxlQVMxRixJQUFBeEIsV0FBQSxDQUFBeUIsSUFBQTtNQUFLQyxTQUFTLEVBQUMsa0JBQWtCO01BQUMsY0FBWWhCLFFBQVM7TUFBQWMsUUFBQSxnQkFDckQsSUFBQXhCLFdBQUEsQ0FBQWlCLEdBQUEsRUFBQ3RCLElBQUEsQ0FBQWdDLFdBQVc7UUFBQ0MsTUFBTSxFQUFFWixJQUFLO1FBQUNhLFVBQVUsRUFBRUMsdUJBQWtCO1FBQUNDLFFBQVEsZUFBRSxJQUFBL0IsV0FBQSxDQUFBaUIsR0FBQTtVQUFLUyxTQUFTLEVBQUM7UUFBc0IsQ0FBRTtNQUFFLENBQUUsQ0FBQyxlQU1oSCxJQUFBMUIsV0FBQSxDQUFBaUIsR0FBQSxFQUFDbkIsaUJBQUEsQ0FBQU8sT0FBZ0I7UUFBQ0ssUUFBUSxFQUFFQTtNQUFTLENBQUUsQ0FBQztJQUFBLENBQ3JDO0VBQUMsQ0FDd0IsQ0FBQztBQUVyQzs7QUFFQTtBQUFBVCxFQUFBLENBOUJTUSxRQUFRO0VBQUEsUUFJZk0sb0JBQWU7QUFBQTtBQUFBaUIsRUFBQSxHQUpSdkIsUUFBUTtBQStCRixTQUFTd0IsYUFBYUEsQ0FBQztFQUFFdkI7QUFBK0IsQ0FBQyxFQUFFO0VBQ3hFLG9CQUNFLElBQUFWLFdBQUEsQ0FBQWlCLEdBQUEsRUFBQ3hCLE1BQUEsQ0FBQXlDLFFBQVE7SUFBQ0gsUUFBUSxlQUFFLElBQUEvQixXQUFBLENBQUFpQixHQUFBO01BQUtTLFNBQVMsRUFBQztJQUFzQixDQUFFLENBQUU7SUFBQUYsUUFBQSxlQUMzRCxJQUFBeEIsV0FBQSxDQUFBaUIsR0FBQSxFQUFDUixRQUFRO01BQUNDLFFBQVEsRUFBRUE7SUFBUyxDQUFFO0VBQUMsQ0FDeEIsQ0FBQztBQUVmO0FBQUN5QixHQUFBLEdBTnVCRixhQUFhO0FBQUEsSUFBQUQsRUFBQSxFQUFBRyxHQUFBO0FBQUFDLFlBQUEsQ0FBQUosRUFBQTtBQUFBSSxZQUFBLENBQUFELEdBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}