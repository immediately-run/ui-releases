var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = InlineProse;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
var _react = require("react");
var _mdxPlugins = require("@immediately-run/mdx-plugins");
var _jsxRuntime = require("react/jsx-runtime");
// R3-531 — the one component that renders a frontmatter prose field: a
// `title`/`description`/`scope` parsed by `@immediately-run/mdx-plugins`'s
// `parseInlineProse` into `code`/`strong`/`em` and text. Every list row, card,
// header, search hit and sidebar label renders its metadata field through this,
// so a backtick in the corpus prints as a code span and never as body-font
// punctuation. The docs fork copies this file VERBATIM (its convention for
// engine components) — which is why it imports nothing grove-local.
//
// Links, images, HTML and JSX are not inline prose and never will be: a title
// is not a body. Fields that become attributes, labels or prompt strings use
// the parser's `plainProse` directly instead of this component.

function renderNodes(nodes) {
  return nodes.map((n, i) => {
    if (n.type === 'code') return /*#__PURE__*/(0, _jsxRuntime.jsx)("code", {
      children: n.value
    }, i);
    if (n.type === 'strong') return /*#__PURE__*/(0, _jsxRuntime.jsx)("strong", {
      children: renderNodes(n.children)
    }, i);
    if (n.type === 'emphasis') return /*#__PURE__*/(0, _jsxRuntime.jsx)("em", {
      children: renderNodes(n.children)
    }, i);
    return /*#__PURE__*/(0, _jsxRuntime.jsx)(_react.Fragment, {
      children: n.value
    }, i);
  });
}
function InlineProse({
  text,
  trimPeriod = false
}) {
  // Trim before parsing: the corpus ends titles on a period, and the period
  // sits OUTSIDE any code span, so a raw-string slice is the whole job.
  const src = trimPeriod && text.endsWith('.') ? text.slice(0, -1) : text;
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_react.Fragment, {
    children: renderNodes((0, _mdxPlugins.parseInlineProse)(src))
  });
}
_c = InlineProse;
var _c;
$RefreshReg$(_c, "InlineProse");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX21keFBsdWdpbnMiLCJfanN4UnVudGltZSIsInJlbmRlck5vZGVzIiwibm9kZXMiLCJtYXAiLCJuIiwiaSIsInR5cGUiLCJqc3giLCJjaGlsZHJlbiIsInZhbHVlIiwiRnJhZ21lbnQiLCJJbmxpbmVQcm9zZSIsInRleHQiLCJ0cmltUGVyaW9kIiwic3JjIiwiZW5kc1dpdGgiLCJzbGljZSIsInBhcnNlSW5saW5lUHJvc2UiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIklubGluZVByb3NlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBSMy01MzEg4oCUIHRoZSBvbmUgY29tcG9uZW50IHRoYXQgcmVuZGVycyBhIGZyb250bWF0dGVyIHByb3NlIGZpZWxkOiBhXG4vLyBgdGl0bGVgL2BkZXNjcmlwdGlvbmAvYHNjb3BlYCBwYXJzZWQgYnkgYEBpbW1lZGlhdGVseS1ydW4vbWR4LXBsdWdpbnNgJ3Ncbi8vIGBwYXJzZUlubGluZVByb3NlYCBpbnRvIGBjb2RlYC9gc3Ryb25nYC9gZW1gIGFuZCB0ZXh0LiBFdmVyeSBsaXN0IHJvdywgY2FyZCxcbi8vIGhlYWRlciwgc2VhcmNoIGhpdCBhbmQgc2lkZWJhciBsYWJlbCByZW5kZXJzIGl0cyBtZXRhZGF0YSBmaWVsZCB0aHJvdWdoIHRoaXMsXG4vLyBzbyBhIGJhY2t0aWNrIGluIHRoZSBjb3JwdXMgcHJpbnRzIGFzIGEgY29kZSBzcGFuIGFuZCBuZXZlciBhcyBib2R5LWZvbnRcbi8vIHB1bmN0dWF0aW9uLiBUaGUgZG9jcyBmb3JrIGNvcGllcyB0aGlzIGZpbGUgVkVSQkFUSU0gKGl0cyBjb252ZW50aW9uIGZvclxuLy8gZW5naW5lIGNvbXBvbmVudHMpIOKAlCB3aGljaCBpcyB3aHkgaXQgaW1wb3J0cyBub3RoaW5nIGdyb3ZlLWxvY2FsLlxuLy9cbi8vIExpbmtzLCBpbWFnZXMsIEhUTUwgYW5kIEpTWCBhcmUgbm90IGlubGluZSBwcm9zZSBhbmQgbmV2ZXIgd2lsbCBiZTogYSB0aXRsZVxuLy8gaXMgbm90IGEgYm9keS4gRmllbGRzIHRoYXQgYmVjb21lIGF0dHJpYnV0ZXMsIGxhYmVscyBvciBwcm9tcHQgc3RyaW5ncyB1c2Vcbi8vIHRoZSBwYXJzZXIncyBgcGxhaW5Qcm9zZWAgZGlyZWN0bHkgaW5zdGVhZCBvZiB0aGlzIGNvbXBvbmVudC5cblxuaW1wb3J0IHsgRnJhZ21lbnQgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBwYXJzZUlubGluZVByb3NlLCB0eXBlIElubGluZVByb3NlTm9kZSB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vbWR4LXBsdWdpbnMnO1xuXG5mdW5jdGlvbiByZW5kZXJOb2Rlcyhub2RlczogSW5saW5lUHJvc2VOb2RlW10pOiBSZWFjdC5SZWFjdE5vZGVbXSB7XG4gIHJldHVybiBub2Rlcy5tYXAoKG4sIGkpID0+IHtcbiAgICBpZiAobi50eXBlID09PSAnY29kZScpIHJldHVybiA8Y29kZSBrZXk9e2l9PntuLnZhbHVlfTwvY29kZT47XG4gICAgaWYgKG4udHlwZSA9PT0gJ3N0cm9uZycpIHJldHVybiA8c3Ryb25nIGtleT17aX0+e3JlbmRlck5vZGVzKG4uY2hpbGRyZW4pfTwvc3Ryb25nPjtcbiAgICBpZiAobi50eXBlID09PSAnZW1waGFzaXMnKSByZXR1cm4gPGVtIGtleT17aX0+e3JlbmRlck5vZGVzKG4uY2hpbGRyZW4pfTwvZW0+O1xuICAgIHJldHVybiA8RnJhZ21lbnQga2V5PXtpfT57bi52YWx1ZX08L0ZyYWdtZW50PjtcbiAgfSk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIElubGluZVByb3NlKHtcbiAgdGV4dCxcbiAgdHJpbVBlcmlvZCA9IGZhbHNlLFxufToge1xuICB0ZXh0OiBzdHJpbmc7XG4gIC8qKiBUcmltIG9uZSB0cmFpbGluZyBwZXJpb2QsIGFzIHRoZSBsaXN0IGNvbXBvbmVudHMgYWx3YXlzIGhhdmUuICovXG4gIHRyaW1QZXJpb2Q/OiBib29sZWFuO1xufSkge1xuICAvLyBUcmltIGJlZm9yZSBwYXJzaW5nOiB0aGUgY29ycHVzIGVuZHMgdGl0bGVzIG9uIGEgcGVyaW9kLCBhbmQgdGhlIHBlcmlvZFxuICAvLyBzaXRzIE9VVFNJREUgYW55IGNvZGUgc3Bhbiwgc28gYSByYXctc3RyaW5nIHNsaWNlIGlzIHRoZSB3aG9sZSBqb2IuXG4gIGNvbnN0IHNyYyA9IHRyaW1QZXJpb2QgJiYgdGV4dC5lbmRzV2l0aCgnLicpID8gdGV4dC5zbGljZSgwLCAtMSkgOiB0ZXh0O1xuICByZXR1cm4gPEZyYWdtZW50PntyZW5kZXJOb2RlcyhwYXJzZUlubGluZVByb3NlKHNyYykpfTwvRnJhZ21lbnQ+O1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQVlBLElBQUFBLE1BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUFzRixJQUFBRSxXQUFBLEdBQUFGLE9BQUE7QUFidEY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFLQSxTQUFTRyxXQUFXQSxDQUFDQyxLQUF3QixFQUFxQjtFQUNoRSxPQUFPQSxLQUFLLENBQUNDLEdBQUcsQ0FBQyxDQUFDQyxDQUFDLEVBQUVDLENBQUMsS0FBSztJQUN6QixJQUFJRCxDQUFDLENBQUNFLElBQUksS0FBSyxNQUFNLEVBQUUsb0JBQU8sSUFBQU4sV0FBQSxDQUFBTyxHQUFBO01BQUFDLFFBQUEsRUFBZUosQ0FBQyxDQUFDSztJQUFLLEdBQVhKLENBQWtCLENBQUM7SUFDNUQsSUFBSUQsQ0FBQyxDQUFDRSxJQUFJLEtBQUssUUFBUSxFQUFFLG9CQUFPLElBQUFOLFdBQUEsQ0FBQU8sR0FBQTtNQUFBQyxRQUFBLEVBQWlCUCxXQUFXLENBQUNHLENBQUMsQ0FBQ0ksUUFBUTtJQUFDLEdBQTNCSCxDQUFvQyxDQUFDO0lBQ2xGLElBQUlELENBQUMsQ0FBQ0UsSUFBSSxLQUFLLFVBQVUsRUFBRSxvQkFBTyxJQUFBTixXQUFBLENBQUFPLEdBQUE7TUFBQUMsUUFBQSxFQUFhUCxXQUFXLENBQUNHLENBQUMsQ0FBQ0ksUUFBUTtJQUFDLEdBQTNCSCxDQUFnQyxDQUFDO0lBQzVFLG9CQUFPLElBQUFMLFdBQUEsQ0FBQU8sR0FBQSxFQUFDVixNQUFBLENBQUFhLFFBQVE7TUFBQUYsUUFBQSxFQUFVSixDQUFDLENBQUNLO0lBQUssR0FBWEosQ0FBc0IsQ0FBQztFQUMvQyxDQUFDLENBQUM7QUFDSjtBQUVlLFNBQVNNLFdBQVdBLENBQUM7RUFDbENDLElBQUk7RUFDSkMsVUFBVSxHQUFHO0FBS2YsQ0FBQyxFQUFFO0VBQ0Q7RUFDQTtFQUNBLE1BQU1DLEdBQUcsR0FBR0QsVUFBVSxJQUFJRCxJQUFJLENBQUNHLFFBQVEsQ0FBQyxHQUFHLENBQUMsR0FBR0gsSUFBSSxDQUFDSSxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUdKLElBQUk7RUFDdkUsb0JBQU8sSUFBQVosV0FBQSxDQUFBTyxHQUFBLEVBQUNWLE1BQUEsQ0FBQWEsUUFBUTtJQUFBRixRQUFBLEVBQUVQLFdBQVcsQ0FBQyxJQUFBZ0IsNEJBQWdCLEVBQUNILEdBQUcsQ0FBQztFQUFDLENBQVcsQ0FBQztBQUNsRTtBQUFDSSxFQUFBLEdBWnVCUCxXQUFXO0FBQUEsSUFBQU8sRUFBQTtBQUFBQyxZQUFBLENBQUFELEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}