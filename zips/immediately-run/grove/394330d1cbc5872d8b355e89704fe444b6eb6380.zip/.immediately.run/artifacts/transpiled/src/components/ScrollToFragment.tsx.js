var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = ScrollToFragment;
var _react = require("react");
var _TinkerableContext = require("@immediately-run/sdk/TinkerableContext");
var _fragment = require("../lib/fragment");
var _s = $RefreshSig$();
/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * Land a deep-link on its section.
 *
 * **Mounted inside the entry body it belongs to** (`SafeEntryBody`), which is the whole
 * trick. The obvious placement — up in `PageView`, watching for the new content to arrive —
 * does not work: the component is unmounted by the very transition it is waiting on.
 * Measured on the real host, it polled 159 times and was torn down at the exact moment the
 * new body committed, so it never saw the thing it existed to see. Rendered *within* the
 * body, it mounts because the content did; the first attempt succeeds and there is nothing
 * to wait for.
 *
 * The target is still resolved against `data-entry` rather than looked up blindly, because
 * the outgoing document lingers briefly during a navigation and every document in this
 * corpus numbers its sections from 1 — `#sec-4` exists in almost all of them, so an
 * unscoped lookup can land on the page you just left (R3-249).
 *
 * Requires a host that forwards the fragment (`site-main` #272). Before that fix
 * `navigationState.hash` was always empty inside the sandbox, and no app could do this at
 * all. The SDK's own `<ScrollAfterNavigation>` is not used: it scrolls on its first hit and
 * returns, and with repeated section ids that first hit is the outgoing document's.
 */
function ScrollToFragment({
  entryKey
}) {
  _s();
  const ctx = (0, _react.useContext)(_TinkerableContext.TinkerableContext);
  const hash = ctx?.navigationState?.hash ?? '';
  const frag = (0, _fragment.fragmentOf)(hash);
  (0, _react.useEffect)(() => {
    if (!frag || typeof document === 'undefined') return;
    let done = false;
    const attempt = () => {
      if (done) return true;
      const el = (0, _fragment.resolveFragmentTarget)(document, entryKey, frag);
      if (!el) return false;
      el.scrollIntoView();
      done = true;
      return true;
    };

    // The first attempt succeeds on the safe path — that effect runs after the body has
    // committed. On the COMPILED path it cannot: `<Include>` owns an internal Suspense, so
    // this mounts while the entry is still being compiled in-browser, and the retry is the
    // whole mechanism rather than a fallback.
    //
    // The window is sized from measurement, not taste (R3-252). Time from mount to a
    // rendered body on the real host: ~2.6s for a 3K entry, ~12s for 37K, ~24s for the
    // 282K `UI_AS_APPS_SPEC`. The old 5s bound was tuned for the safe renderer (~2–10s)
    // and silently expired mid-compile on any large spec — the citation landed on the
    // page and never reached the section. 30s clears the largest entry with margin;
    // polling is 200ms, it stops on the first success, and it cannot outlive the entry.
    if (attempt()) return;
    const timer = setInterval(() => {
      if (attempt()) clearInterval(timer);
    }, 200);
    const stop = setTimeout(() => clearInterval(timer), 30_000);
    return () => {
      clearInterval(timer);
      clearTimeout(stop);
    };
  }, [entryKey, frag]);
  return null;
}
_s(ScrollToFragment, "fLVqO3p0FcvnEO4nGi6SNKkqK10=");
_c = ScrollToFragment;
var _c;
$RefreshReg$(_c, "ScrollToFragment");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX1RpbmtlcmFibGVDb250ZXh0IiwiX2ZyYWdtZW50IiwiX3MiLCIkUmVmcmVzaFNpZyQiLCJTY3JvbGxUb0ZyYWdtZW50IiwiZW50cnlLZXkiLCJjdHgiLCJ1c2VDb250ZXh0IiwiVGlua2VyYWJsZUNvbnRleHQiLCJoYXNoIiwibmF2aWdhdGlvblN0YXRlIiwiZnJhZyIsImZyYWdtZW50T2YiLCJ1c2VFZmZlY3QiLCJkb2N1bWVudCIsImRvbmUiLCJhdHRlbXB0IiwiZWwiLCJyZXNvbHZlRnJhZ21lbnRUYXJnZXQiLCJzY3JvbGxJbnRvVmlldyIsInRpbWVyIiwic2V0SW50ZXJ2YWwiLCJjbGVhckludGVydmFsIiwic3RvcCIsInNldFRpbWVvdXQiLCJjbGVhclRpbWVvdXQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlNjcm9sbFRvRnJhZ21lbnQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHBsaWNpdC1hbnkgKi9cbmltcG9ydCB7IHVzZUNvbnRleHQsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFRpbmtlcmFibGVDb250ZXh0IH0gZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9zZGsvVGlua2VyYWJsZUNvbnRleHQnO1xuaW1wb3J0IHsgZnJhZ21lbnRPZiwgcmVzb2x2ZUZyYWdtZW50VGFyZ2V0IH0gZnJvbSAnLi4vbGliL2ZyYWdtZW50JztcblxuLyoqXG4gKiBMYW5kIGEgZGVlcC1saW5rIG9uIGl0cyBzZWN0aW9uLlxuICpcbiAqICoqTW91bnRlZCBpbnNpZGUgdGhlIGVudHJ5IGJvZHkgaXQgYmVsb25ncyB0byoqIChgU2FmZUVudHJ5Qm9keWApLCB3aGljaCBpcyB0aGUgd2hvbGVcbiAqIHRyaWNrLiBUaGUgb2J2aW91cyBwbGFjZW1lbnQg4oCUIHVwIGluIGBQYWdlVmlld2AsIHdhdGNoaW5nIGZvciB0aGUgbmV3IGNvbnRlbnQgdG8gYXJyaXZlIOKAlFxuICogZG9lcyBub3Qgd29yazogdGhlIGNvbXBvbmVudCBpcyB1bm1vdW50ZWQgYnkgdGhlIHZlcnkgdHJhbnNpdGlvbiBpdCBpcyB3YWl0aW5nIG9uLlxuICogTWVhc3VyZWQgb24gdGhlIHJlYWwgaG9zdCwgaXQgcG9sbGVkIDE1OSB0aW1lcyBhbmQgd2FzIHRvcm4gZG93biBhdCB0aGUgZXhhY3QgbW9tZW50IHRoZVxuICogbmV3IGJvZHkgY29tbWl0dGVkLCBzbyBpdCBuZXZlciBzYXcgdGhlIHRoaW5nIGl0IGV4aXN0ZWQgdG8gc2VlLiBSZW5kZXJlZCAqd2l0aGluKiB0aGVcbiAqIGJvZHksIGl0IG1vdW50cyBiZWNhdXNlIHRoZSBjb250ZW50IGRpZDsgdGhlIGZpcnN0IGF0dGVtcHQgc3VjY2VlZHMgYW5kIHRoZXJlIGlzIG5vdGhpbmdcbiAqIHRvIHdhaXQgZm9yLlxuICpcbiAqIFRoZSB0YXJnZXQgaXMgc3RpbGwgcmVzb2x2ZWQgYWdhaW5zdCBgZGF0YS1lbnRyeWAgcmF0aGVyIHRoYW4gbG9va2VkIHVwIGJsaW5kbHksIGJlY2F1c2VcbiAqIHRoZSBvdXRnb2luZyBkb2N1bWVudCBsaW5nZXJzIGJyaWVmbHkgZHVyaW5nIGEgbmF2aWdhdGlvbiBhbmQgZXZlcnkgZG9jdW1lbnQgaW4gdGhpc1xuICogY29ycHVzIG51bWJlcnMgaXRzIHNlY3Rpb25zIGZyb20gMSDigJQgYCNzZWMtNGAgZXhpc3RzIGluIGFsbW9zdCBhbGwgb2YgdGhlbSwgc28gYW5cbiAqIHVuc2NvcGVkIGxvb2t1cCBjYW4gbGFuZCBvbiB0aGUgcGFnZSB5b3UganVzdCBsZWZ0IChSMy0yNDkpLlxuICpcbiAqIFJlcXVpcmVzIGEgaG9zdCB0aGF0IGZvcndhcmRzIHRoZSBmcmFnbWVudCAoYHNpdGUtbWFpbmAgIzI3MikuIEJlZm9yZSB0aGF0IGZpeFxuICogYG5hdmlnYXRpb25TdGF0ZS5oYXNoYCB3YXMgYWx3YXlzIGVtcHR5IGluc2lkZSB0aGUgc2FuZGJveCwgYW5kIG5vIGFwcCBjb3VsZCBkbyB0aGlzIGF0XG4gKiBhbGwuIFRoZSBTREsncyBvd24gYDxTY3JvbGxBZnRlck5hdmlnYXRpb24+YCBpcyBub3QgdXNlZDogaXQgc2Nyb2xscyBvbiBpdHMgZmlyc3QgaGl0IGFuZFxuICogcmV0dXJucywgYW5kIHdpdGggcmVwZWF0ZWQgc2VjdGlvbiBpZHMgdGhhdCBmaXJzdCBoaXQgaXMgdGhlIG91dGdvaW5nIGRvY3VtZW50J3MuXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFNjcm9sbFRvRnJhZ21lbnQoeyBlbnRyeUtleSB9OiB7IGVudHJ5S2V5OiBzdHJpbmcgfSkge1xuICBjb25zdCBjdHggPSB1c2VDb250ZXh0KFRpbmtlcmFibGVDb250ZXh0KSBhcyBhbnk7XG4gIGNvbnN0IGhhc2ggPSBjdHg/Lm5hdmlnYXRpb25TdGF0ZT8uaGFzaCA/PyAnJztcbiAgY29uc3QgZnJhZyA9IGZyYWdtZW50T2YoaGFzaCk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIWZyYWcgfHwgdHlwZW9mIGRvY3VtZW50ID09PSAndW5kZWZpbmVkJykgcmV0dXJuO1xuICAgIGxldCBkb25lID0gZmFsc2U7XG5cbiAgICBjb25zdCBhdHRlbXB0ID0gKCkgPT4ge1xuICAgICAgaWYgKGRvbmUpIHJldHVybiB0cnVlO1xuICAgICAgY29uc3QgZWwgPSByZXNvbHZlRnJhZ21lbnRUYXJnZXQoZG9jdW1lbnQsIGVudHJ5S2V5LCBmcmFnKTtcbiAgICAgIGlmICghZWwpIHJldHVybiBmYWxzZTtcbiAgICAgIGVsLnNjcm9sbEludG9WaWV3KCk7XG4gICAgICBkb25lID0gdHJ1ZTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH07XG5cbiAgICAvLyBUaGUgZmlyc3QgYXR0ZW1wdCBzdWNjZWVkcyBvbiB0aGUgc2FmZSBwYXRoIOKAlCB0aGF0IGVmZmVjdCBydW5zIGFmdGVyIHRoZSBib2R5IGhhc1xuICAgIC8vIGNvbW1pdHRlZC4gT24gdGhlIENPTVBJTEVEIHBhdGggaXQgY2Fubm90OiBgPEluY2x1ZGU+YCBvd25zIGFuIGludGVybmFsIFN1c3BlbnNlLCBzb1xuICAgIC8vIHRoaXMgbW91bnRzIHdoaWxlIHRoZSBlbnRyeSBpcyBzdGlsbCBiZWluZyBjb21waWxlZCBpbi1icm93c2VyLCBhbmQgdGhlIHJldHJ5IGlzIHRoZVxuICAgIC8vIHdob2xlIG1lY2hhbmlzbSByYXRoZXIgdGhhbiBhIGZhbGxiYWNrLlxuICAgIC8vXG4gICAgLy8gVGhlIHdpbmRvdyBpcyBzaXplZCBmcm9tIG1lYXN1cmVtZW50LCBub3QgdGFzdGUgKFIzLTI1MikuIFRpbWUgZnJvbSBtb3VudCB0byBhXG4gICAgLy8gcmVuZGVyZWQgYm9keSBvbiB0aGUgcmVhbCBob3N0OiB+Mi42cyBmb3IgYSAzSyBlbnRyeSwgfjEycyBmb3IgMzdLLCB+MjRzIGZvciB0aGVcbiAgICAvLyAyODJLIGBVSV9BU19BUFBTX1NQRUNgLiBUaGUgb2xkIDVzIGJvdW5kIHdhcyB0dW5lZCBmb3IgdGhlIHNhZmUgcmVuZGVyZXIgKH4y4oCTMTBzKVxuICAgIC8vIGFuZCBzaWxlbnRseSBleHBpcmVkIG1pZC1jb21waWxlIG9uIGFueSBsYXJnZSBzcGVjIOKAlCB0aGUgY2l0YXRpb24gbGFuZGVkIG9uIHRoZVxuICAgIC8vIHBhZ2UgYW5kIG5ldmVyIHJlYWNoZWQgdGhlIHNlY3Rpb24uIDMwcyBjbGVhcnMgdGhlIGxhcmdlc3QgZW50cnkgd2l0aCBtYXJnaW47XG4gICAgLy8gcG9sbGluZyBpcyAyMDBtcywgaXQgc3RvcHMgb24gdGhlIGZpcnN0IHN1Y2Nlc3MsIGFuZCBpdCBjYW5ub3Qgb3V0bGl2ZSB0aGUgZW50cnkuXG4gICAgaWYgKGF0dGVtcHQoKSkgcmV0dXJuO1xuICAgIGNvbnN0IHRpbWVyID0gc2V0SW50ZXJ2YWwoKCkgPT4geyBpZiAoYXR0ZW1wdCgpKSBjbGVhckludGVydmFsKHRpbWVyKTsgfSwgMjAwKTtcbiAgICBjb25zdCBzdG9wID0gc2V0VGltZW91dCgoKSA9PiBjbGVhckludGVydmFsKHRpbWVyKSwgMzBfMDAwKTtcbiAgICByZXR1cm4gKCkgPT4geyBjbGVhckludGVydmFsKHRpbWVyKTsgY2xlYXJUaW1lb3V0KHN0b3ApOyB9O1xuICB9LCBbZW50cnlLZXksIGZyYWddKTtcblxuICByZXR1cm4gbnVsbDtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQ0EsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsa0JBQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLFNBQUEsR0FBQUYsT0FBQTtBQUFvRSxJQUFBRyxFQUFBLEdBQUFDLFlBQUE7QUFIcEU7QUFLQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDZSxTQUFTQyxnQkFBZ0JBLENBQUM7RUFBRUM7QUFBK0IsQ0FBQyxFQUFFO0VBQUFILEVBQUE7RUFDM0UsTUFBTUksR0FBRyxHQUFHLElBQUFDLGlCQUFVLEVBQUNDLG9DQUFpQixDQUFRO0VBQ2hELE1BQU1DLElBQUksR0FBR0gsR0FBRyxFQUFFSSxlQUFlLEVBQUVELElBQUksSUFBSSxFQUFFO0VBQzdDLE1BQU1FLElBQUksR0FBRyxJQUFBQyxvQkFBVSxFQUFDSCxJQUFJLENBQUM7RUFFN0IsSUFBQUksZ0JBQVMsRUFBQyxNQUFNO0lBQ2QsSUFBSSxDQUFDRixJQUFJLElBQUksT0FBT0csUUFBUSxLQUFLLFdBQVcsRUFBRTtJQUM5QyxJQUFJQyxJQUFJLEdBQUcsS0FBSztJQUVoQixNQUFNQyxPQUFPLEdBQUdBLENBQUEsS0FBTTtNQUNwQixJQUFJRCxJQUFJLEVBQUUsT0FBTyxJQUFJO01BQ3JCLE1BQU1FLEVBQUUsR0FBRyxJQUFBQywrQkFBcUIsRUFBQ0osUUFBUSxFQUFFVCxRQUFRLEVBQUVNLElBQUksQ0FBQztNQUMxRCxJQUFJLENBQUNNLEVBQUUsRUFBRSxPQUFPLEtBQUs7TUFDckJBLEVBQUUsQ0FBQ0UsY0FBYyxDQUFDLENBQUM7TUFDbkJKLElBQUksR0FBRyxJQUFJO01BQ1gsT0FBTyxJQUFJO0lBQ2IsQ0FBQzs7SUFFRDtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0EsSUFBSUMsT0FBTyxDQUFDLENBQUMsRUFBRTtJQUNmLE1BQU1JLEtBQUssR0FBR0MsV0FBVyxDQUFDLE1BQU07TUFBRSxJQUFJTCxPQUFPLENBQUMsQ0FBQyxFQUFFTSxhQUFhLENBQUNGLEtBQUssQ0FBQztJQUFFLENBQUMsRUFBRSxHQUFHLENBQUM7SUFDOUUsTUFBTUcsSUFBSSxHQUFHQyxVQUFVLENBQUMsTUFBTUYsYUFBYSxDQUFDRixLQUFLLENBQUMsRUFBRSxNQUFNLENBQUM7SUFDM0QsT0FBTyxNQUFNO01BQUVFLGFBQWEsQ0FBQ0YsS0FBSyxDQUFDO01BQUVLLFlBQVksQ0FBQ0YsSUFBSSxDQUFDO0lBQUUsQ0FBQztFQUM1RCxDQUFDLEVBQUUsQ0FBQ2xCLFFBQVEsRUFBRU0sSUFBSSxDQUFDLENBQUM7RUFFcEIsT0FBTyxJQUFJO0FBQ2I7QUFBQ1QsRUFBQSxDQXBDdUJFLGdCQUFnQjtBQUFBc0IsRUFBQSxHQUFoQnRCLGdCQUFnQjtBQUFBLElBQUFzQixFQUFBO0FBQUFDLFlBQUEsQ0FBQUQsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}