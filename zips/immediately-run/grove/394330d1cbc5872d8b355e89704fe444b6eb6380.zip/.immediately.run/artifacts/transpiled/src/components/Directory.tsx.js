var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Directory;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.map.js");
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
var _content = require("../lib/content");
var _wiki = require("../lib/wiki");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(),
  _s2 = $RefreshSig$();
/* eslint-disable @typescript-eslint/no-explicit-any */
function isPerson(m) {
  return m && m.name && m.role && m.team && m.phone;
}
function Row({
  path,
  compact
}) {
  _s();
  const m = (0, _sdk.useFileMetadata)(path);
  if (!m) return null;
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("tr", {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("td", {
      style: {
        fontWeight: 600
      },
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_sdk.Link, {
        href: (0, _content.keyToHref)(path),
        children: m.name
      })
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("td", {
      children: m.role
    }), !compact && /*#__PURE__*/(0, _jsxRuntime.jsx)("td", {
      children: m.team
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("td", {
      className: "mono",
      children: m.phone
    }), !compact && /*#__PURE__*/(0, _jsxRuntime.jsx)("td", {
      className: "mono",
      children: m.email
    })]
  });
}

// Import-free engine component: the phone book, built from per-person entries.
_s(Row, "HCQWmXfXYtrNQZ9MFtiZso5O/l0=", false, function () {
  return [_sdk.useFileMetadata];
});
_c = Row;
function Directory({
  team,
  compact
}) {
  _s2();
  const queryFn = (0, _react.useCallback)(filesMetadata => Object.keys(filesMetadata).filter(p => p.startsWith((0, _content.contentDir)()) && isPerson(filesMetadata[p])).filter(p => !team || filesMetadata[p].team === team).sort((a, b) => filesMetadata[a].name < filesMetadata[b].name ? -1 : 1), [team]);
  const result = (0, _sdk.useMetadataQuery)(queryFn);
  const paths = (0, _wiki.queryPaths)(result);
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    className: "grove-table-wrap",
    children: /*#__PURE__*/(0, _jsxRuntime.jsxs)("table", {
      className: "grove-table",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("thead", {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)("tr", {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("th", {
            children: "Name"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)("th", {
            children: "Role"
          }), !compact && /*#__PURE__*/(0, _jsxRuntime.jsx)("th", {
            children: "Team"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)("th", {
            children: "Phone"
          }), !compact && /*#__PURE__*/(0, _jsxRuntime.jsx)("th", {
            children: "Email"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("tbody", {
        children: paths.map(p => /*#__PURE__*/(0, _jsxRuntime.jsx)(Row, {
          path: p,
          compact: compact
        }, p))
      })]
    })
  });
}
_s2(Directory, "92XDcBEKcr0huS9xFVJPNEOy7oY=", false, function () {
  return [_sdk.useMetadataQuery];
});
_c2 = Directory;
var _c, _c2;
$RefreshReg$(_c, "Row");
$RefreshReg$(_c2, "Directory");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NkayIsIl9jb250ZW50IiwiX3dpa2kiLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiX3MyIiwiaXNQZXJzb24iLCJtIiwibmFtZSIsInJvbGUiLCJ0ZWFtIiwicGhvbmUiLCJSb3ciLCJwYXRoIiwiY29tcGFjdCIsInVzZUZpbGVNZXRhZGF0YSIsImpzeHMiLCJjaGlsZHJlbiIsImpzeCIsInN0eWxlIiwiZm9udFdlaWdodCIsIkxpbmsiLCJocmVmIiwia2V5VG9IcmVmIiwiY2xhc3NOYW1lIiwiZW1haWwiLCJfYyIsIkRpcmVjdG9yeSIsInF1ZXJ5Rm4iLCJ1c2VDYWxsYmFjayIsImZpbGVzTWV0YWRhdGEiLCJPYmplY3QiLCJrZXlzIiwiZmlsdGVyIiwicCIsInN0YXJ0c1dpdGgiLCJjb250ZW50RGlyIiwic29ydCIsImEiLCJiIiwicmVzdWx0IiwidXNlTWV0YWRhdGFRdWVyeSIsInBhdGhzIiwicXVlcnlQYXRocyIsIm1hcCIsIl9jMiIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkRpcmVjdG9yeS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueSAqL1xuaW1wb3J0IHsgdXNlQ2FsbGJhY2sgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBMaW5rLCB1c2VGaWxlTWV0YWRhdGEsIHVzZU1ldGFkYXRhUXVlcnkgfSBmcm9tICdAaW1tZWRpYXRlbHktcnVuL3Nkayc7XG5pbXBvcnQgeyBjb250ZW50RGlyLCBrZXlUb0hyZWYgfSBmcm9tICcuLi9saWIvY29udGVudCc7XG5pbXBvcnQgeyBxdWVyeVBhdGhzIH0gZnJvbSAnLi4vbGliL3dpa2knO1xuXG5pbnRlcmZhY2UgUHJvcHMge1xuICB0ZWFtPzogc3RyaW5nO1xuICBjb21wYWN0PzogYm9vbGVhbjtcbn1cblxuZnVuY3Rpb24gaXNQZXJzb24obTogYW55KTogYm9vbGVhbiB7XG4gIHJldHVybiBtICYmIG0ubmFtZSAmJiBtLnJvbGUgJiYgbS50ZWFtICYmIG0ucGhvbmU7XG59XG5cbmZ1bmN0aW9uIFJvdyh7IHBhdGgsIGNvbXBhY3QgfTogeyBwYXRoOiBzdHJpbmc7IGNvbXBhY3Q/OiBib29sZWFuIH0pIHtcbiAgY29uc3QgbSA9IHVzZUZpbGVNZXRhZGF0YShwYXRoKSBhcyBhbnk7XG4gIGlmICghbSkgcmV0dXJuIG51bGw7XG4gIHJldHVybiAoXG4gICAgPHRyPlxuICAgICAgPHRkIHN0eWxlPXt7IGZvbnRXZWlnaHQ6IDYwMCB9fT5cbiAgICAgICAgPExpbmsgaHJlZj17a2V5VG9IcmVmKHBhdGgpfT57bS5uYW1lfTwvTGluaz5cbiAgICAgIDwvdGQ+XG4gICAgICA8dGQ+e20ucm9sZX08L3RkPlxuICAgICAgeyFjb21wYWN0ICYmIDx0ZD57bS50ZWFtfTwvdGQ+fVxuICAgICAgPHRkIGNsYXNzTmFtZT1cIm1vbm9cIj57bS5waG9uZX08L3RkPlxuICAgICAgeyFjb21wYWN0ICYmIDx0ZCBjbGFzc05hbWU9XCJtb25vXCI+e20uZW1haWx9PC90ZD59XG4gICAgPC90cj5cbiAgKTtcbn1cblxuLy8gSW1wb3J0LWZyZWUgZW5naW5lIGNvbXBvbmVudDogdGhlIHBob25lIGJvb2ssIGJ1aWx0IGZyb20gcGVyLXBlcnNvbiBlbnRyaWVzLlxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gRGlyZWN0b3J5KHsgdGVhbSwgY29tcGFjdCB9OiBQcm9wcykge1xuICBjb25zdCBxdWVyeUZuID0gdXNlQ2FsbGJhY2soXG4gICAgKGZpbGVzTWV0YWRhdGE6IFJlY29yZDxzdHJpbmcsIGFueT4pID0+XG4gICAgICBPYmplY3Qua2V5cyhmaWxlc01ldGFkYXRhKVxuICAgICAgICAuZmlsdGVyKChwKSA9PiBwLnN0YXJ0c1dpdGgoY29udGVudERpcigpKSAmJiBpc1BlcnNvbihmaWxlc01ldGFkYXRhW3BdKSlcbiAgICAgICAgLmZpbHRlcigocCkgPT4gIXRlYW0gfHwgZmlsZXNNZXRhZGF0YVtwXS50ZWFtID09PSB0ZWFtKVxuICAgICAgICAuc29ydCgoYSwgYikgPT4gKGZpbGVzTWV0YWRhdGFbYV0ubmFtZSA8IGZpbGVzTWV0YWRhdGFbYl0ubmFtZSA/IC0xIDogMSkpLFxuICAgIFt0ZWFtXVxuICApO1xuICBjb25zdCByZXN1bHQgPSB1c2VNZXRhZGF0YVF1ZXJ5KHF1ZXJ5Rm4pO1xuICBjb25zdCBwYXRoczogc3RyaW5nW10gPSBxdWVyeVBhdGhzKHJlc3VsdCk7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImdyb3ZlLXRhYmxlLXdyYXBcIj5cbiAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJncm92ZS10YWJsZVwiPlxuICAgICAgICA8dGhlYWQ+XG4gICAgICAgICAgPHRyPlxuICAgICAgICAgICAgPHRoPk5hbWU8L3RoPlxuICAgICAgICAgICAgPHRoPlJvbGU8L3RoPlxuICAgICAgICAgICAgeyFjb21wYWN0ICYmIDx0aD5UZWFtPC90aD59XG4gICAgICAgICAgICA8dGg+UGhvbmU8L3RoPlxuICAgICAgICAgICAgeyFjb21wYWN0ICYmIDx0aD5FbWFpbDwvdGg+fVxuICAgICAgICAgIDwvdHI+XG4gICAgICAgIDwvdGhlYWQ+XG4gICAgICAgIDx0Ym9keT5cbiAgICAgICAgICB7cGF0aHMubWFwKChwKSA9PiAoXG4gICAgICAgICAgICA8Um93IGtleT17cH0gcGF0aD17cH0gY29tcGFjdD17Y29tcGFjdH0gLz5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC90Ym9keT5cbiAgICAgIDwvdGFibGU+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUNBLElBQUFBLE1BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLElBQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLFFBQUEsR0FBQUYsT0FBQTtBQUNBLElBQUFHLEtBQUEsR0FBQUgsT0FBQTtBQUF5QyxJQUFBSSxXQUFBLEdBQUFKLE9BQUE7QUFBQSxJQUFBSyxFQUFBLEdBQUFDLFlBQUE7RUFBQUMsR0FBQSxHQUFBRCxZQUFBO0FBSnpDO0FBV0EsU0FBU0UsUUFBUUEsQ0FBQ0MsQ0FBTSxFQUFXO0VBQ2pDLE9BQU9BLENBQUMsSUFBSUEsQ0FBQyxDQUFDQyxJQUFJLElBQUlELENBQUMsQ0FBQ0UsSUFBSSxJQUFJRixDQUFDLENBQUNHLElBQUksSUFBSUgsQ0FBQyxDQUFDSSxLQUFLO0FBQ25EO0FBRUEsU0FBU0MsR0FBR0EsQ0FBQztFQUFFQyxJQUFJO0VBQUVDO0FBQTZDLENBQUMsRUFBRTtFQUFBWCxFQUFBO0VBQ25FLE1BQU1JLENBQUMsR0FBRyxJQUFBUSxvQkFBZSxFQUFDRixJQUFJLENBQVE7RUFDdEMsSUFBSSxDQUFDTixDQUFDLEVBQUUsT0FBTyxJQUFJO0VBQ25CLG9CQUNFLElBQUFMLFdBQUEsQ0FBQWMsSUFBQTtJQUFBQyxRQUFBLGdCQUNFLElBQUFmLFdBQUEsQ0FBQWdCLEdBQUE7TUFBSUMsS0FBSyxFQUFFO1FBQUVDLFVBQVUsRUFBRTtNQUFJLENBQUU7TUFBQUgsUUFBQSxlQUM3QixJQUFBZixXQUFBLENBQUFnQixHQUFBLEVBQUNuQixJQUFBLENBQUFzQixJQUFJO1FBQUNDLElBQUksRUFBRSxJQUFBQyxrQkFBUyxFQUFDVixJQUFJLENBQUU7UUFBQUksUUFBQSxFQUFFVixDQUFDLENBQUNDO01BQUksQ0FBTztJQUFDLENBQzFDLENBQUMsZUFDTCxJQUFBTixXQUFBLENBQUFnQixHQUFBO01BQUFELFFBQUEsRUFBS1YsQ0FBQyxDQUFDRTtJQUFJLENBQUssQ0FBQyxFQUNoQixDQUFDSyxPQUFPLGlCQUFJLElBQUFaLFdBQUEsQ0FBQWdCLEdBQUE7TUFBQUQsUUFBQSxFQUFLVixDQUFDLENBQUNHO0lBQUksQ0FBSyxDQUFDLGVBQzlCLElBQUFSLFdBQUEsQ0FBQWdCLEdBQUE7TUFBSU0sU0FBUyxFQUFDLE1BQU07TUFBQVAsUUFBQSxFQUFFVixDQUFDLENBQUNJO0lBQUssQ0FBSyxDQUFDLEVBQ2xDLENBQUNHLE9BQU8saUJBQUksSUFBQVosV0FBQSxDQUFBZ0IsR0FBQTtNQUFJTSxTQUFTLEVBQUMsTUFBTTtNQUFBUCxRQUFBLEVBQUVWLENBQUMsQ0FBQ2tCO0lBQUssQ0FBSyxDQUFDO0VBQUEsQ0FDOUMsQ0FBQztBQUVUOztBQUVBO0FBQUF0QixFQUFBLENBaEJTUyxHQUFHO0VBQUEsUUFDQUcsb0JBQWU7QUFBQTtBQUFBVyxFQUFBLEdBRGxCZCxHQUFHO0FBaUJHLFNBQVNlLFNBQVNBLENBQUM7RUFBRWpCLElBQUk7RUFBRUk7QUFBZSxDQUFDLEVBQUU7RUFBQVQsR0FBQTtFQUMxRCxNQUFNdUIsT0FBTyxHQUFHLElBQUFDLGtCQUFXLEVBQ3hCQyxhQUFrQyxJQUNqQ0MsTUFBTSxDQUFDQyxJQUFJLENBQUNGLGFBQWEsQ0FBQyxDQUN2QkcsTUFBTSxDQUFFQyxDQUFDLElBQUtBLENBQUMsQ0FBQ0MsVUFBVSxDQUFDLElBQUFDLG1CQUFVLEVBQUMsQ0FBQyxDQUFDLElBQUk5QixRQUFRLENBQUN3QixhQUFhLENBQUNJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FDdkVELE1BQU0sQ0FBRUMsQ0FBQyxJQUFLLENBQUN4QixJQUFJLElBQUlvQixhQUFhLENBQUNJLENBQUMsQ0FBQyxDQUFDeEIsSUFBSSxLQUFLQSxJQUFJLENBQUMsQ0FDdEQyQixJQUFJLENBQUMsQ0FBQ0MsQ0FBQyxFQUFFQyxDQUFDLEtBQU1ULGFBQWEsQ0FBQ1EsQ0FBQyxDQUFDLENBQUM5QixJQUFJLEdBQUdzQixhQUFhLENBQUNTLENBQUMsQ0FBQyxDQUFDL0IsSUFBSSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUUsQ0FBQyxFQUM3RSxDQUFDRSxJQUFJLENBQ1AsQ0FBQztFQUNELE1BQU04QixNQUFNLEdBQUcsSUFBQUMscUJBQWdCLEVBQUNiLE9BQU8sQ0FBQztFQUN4QyxNQUFNYyxLQUFlLEdBQUcsSUFBQUMsZ0JBQVUsRUFBQ0gsTUFBTSxDQUFDO0VBRTFDLG9CQUNFLElBQUF0QyxXQUFBLENBQUFnQixHQUFBO0lBQUtNLFNBQVMsRUFBQyxrQkFBa0I7SUFBQVAsUUFBQSxlQUMvQixJQUFBZixXQUFBLENBQUFjLElBQUE7TUFBT1EsU0FBUyxFQUFDLGFBQWE7TUFBQVAsUUFBQSxnQkFDNUIsSUFBQWYsV0FBQSxDQUFBZ0IsR0FBQTtRQUFBRCxRQUFBLGVBQ0UsSUFBQWYsV0FBQSxDQUFBYyxJQUFBO1VBQUFDLFFBQUEsZ0JBQ0UsSUFBQWYsV0FBQSxDQUFBZ0IsR0FBQTtZQUFBRCxRQUFBLEVBQUk7VUFBSSxDQUFJLENBQUMsZUFDYixJQUFBZixXQUFBLENBQUFnQixHQUFBO1lBQUFELFFBQUEsRUFBSTtVQUFJLENBQUksQ0FBQyxFQUNaLENBQUNILE9BQU8saUJBQUksSUFBQVosV0FBQSxDQUFBZ0IsR0FBQTtZQUFBRCxRQUFBLEVBQUk7VUFBSSxDQUFJLENBQUMsZUFDMUIsSUFBQWYsV0FBQSxDQUFBZ0IsR0FBQTtZQUFBRCxRQUFBLEVBQUk7VUFBSyxDQUFJLENBQUMsRUFDYixDQUFDSCxPQUFPLGlCQUFJLElBQUFaLFdBQUEsQ0FBQWdCLEdBQUE7WUFBQUQsUUFBQSxFQUFJO1VBQUssQ0FBSSxDQUFDO1FBQUEsQ0FDekI7TUFBQyxDQUNBLENBQUMsZUFDUixJQUFBZixXQUFBLENBQUFnQixHQUFBO1FBQUFELFFBQUEsRUFDR3lCLEtBQUssQ0FBQ0UsR0FBRyxDQUFFVixDQUFDLGlCQUNYLElBQUFoQyxXQUFBLENBQUFnQixHQUFBLEVBQUNOLEdBQUc7VUFBU0MsSUFBSSxFQUFFcUIsQ0FBRTtVQUFDcEIsT0FBTyxFQUFFQTtRQUFRLEdBQTdCb0IsQ0FBK0IsQ0FDMUM7TUFBQyxDQUNHLENBQUM7SUFBQSxDQUNIO0VBQUMsQ0FDTCxDQUFDO0FBRVY7QUFBQzdCLEdBQUEsQ0FoQ3VCc0IsU0FBUztFQUFBLFFBU2hCYyxxQkFBZ0I7QUFBQTtBQUFBSSxHQUFBLEdBVFRsQixTQUFTO0FBQUEsSUFBQUQsRUFBQSxFQUFBbUIsR0FBQTtBQUFBQyxZQUFBLENBQUFwQixFQUFBO0FBQUFvQixZQUFBLENBQUFELEdBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}