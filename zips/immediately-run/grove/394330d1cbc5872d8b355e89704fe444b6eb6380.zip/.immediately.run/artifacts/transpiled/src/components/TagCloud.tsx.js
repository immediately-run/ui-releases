var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = TagCloud;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.for-each.js");
require("core-js/modules/esnext.iterator.map.js");
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
var _content = require("../lib/content");
var _wiki = require("../lib/wiki");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$();
/* eslint-disable @typescript-eslint/no-explicit-any */
// Import-free engine component: every tag across the site, sized by frequency.
// Chrome tags (`ui/*`) are excluded — they drive layout, not classification.
function TagCloud() {
  _s();
  const queryFn = (0, _react.useCallback)(filesMetadata => {
    const counts = {};
    Object.entries(filesMetadata).forEach(([p, m]) => {
      if (!p.startsWith((0, _content.contentDir)())) return;
      if (m && Array.isArray(m.tags)) {
        m.tags.forEach(t => {
          if (t.startsWith('ui/')) return;
          counts[t] = (counts[t] || 0) + 1;
        });
      }
    });
    // Encode counts into the string[] the query contract returns.
    return Object.keys(counts).sort().map(t => `${t}:${counts[t]}`);
  }, []);
  const result = (0, _sdk.useMetadataQuery)(queryFn);
  const entries = (0, _wiki.queryPaths)(result);
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    className: "grove-tagcloud",
    children: entries.map(e => {
      const [tag, count] = e.split(':');
      return /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
        className: "grove-tag",
        style: {
          fontSize: 11 + Number(count) * 2 + 'px',
          padding: '4px 12px'
        },
        children: ["#", tag, " ", /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          style: {
            opacity: 0.5,
            marginLeft: 4
          },
          children: count
        })]
      }, tag);
    })
  });
}
_s(TagCloud, "92XDcBEKcr0huS9xFVJPNEOy7oY=", false, function () {
  return [_sdk.useMetadataQuery];
});
_c = TagCloud;
var _c;
$RefreshReg$(_c, "TagCloud");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NkayIsIl9jb250ZW50IiwiX3dpa2kiLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiVGFnQ2xvdWQiLCJxdWVyeUZuIiwidXNlQ2FsbGJhY2siLCJmaWxlc01ldGFkYXRhIiwiY291bnRzIiwiT2JqZWN0IiwiZW50cmllcyIsImZvckVhY2giLCJwIiwibSIsInN0YXJ0c1dpdGgiLCJjb250ZW50RGlyIiwiQXJyYXkiLCJpc0FycmF5IiwidGFncyIsInQiLCJrZXlzIiwic29ydCIsIm1hcCIsInJlc3VsdCIsInVzZU1ldGFkYXRhUXVlcnkiLCJxdWVyeVBhdGhzIiwianN4IiwiY2xhc3NOYW1lIiwiY2hpbGRyZW4iLCJlIiwidGFnIiwiY291bnQiLCJzcGxpdCIsImpzeHMiLCJzdHlsZSIsImZvbnRTaXplIiwiTnVtYmVyIiwicGFkZGluZyIsIm9wYWNpdHkiLCJtYXJnaW5MZWZ0IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJUYWdDbG91ZC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueSAqL1xuaW1wb3J0IHsgdXNlQ2FsbGJhY2sgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VNZXRhZGF0YVF1ZXJ5IH0gZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9zZGsnO1xuaW1wb3J0IHsgY29udGVudERpciB9IGZyb20gJy4uL2xpYi9jb250ZW50JztcbmltcG9ydCB7IHF1ZXJ5UGF0aHMgfSBmcm9tICcuLi9saWIvd2lraSc7XG5cbi8vIEltcG9ydC1mcmVlIGVuZ2luZSBjb21wb25lbnQ6IGV2ZXJ5IHRhZyBhY3Jvc3MgdGhlIHNpdGUsIHNpemVkIGJ5IGZyZXF1ZW5jeS5cbi8vIENocm9tZSB0YWdzIChgdWkvKmApIGFyZSBleGNsdWRlZCDigJQgdGhleSBkcml2ZSBsYXlvdXQsIG5vdCBjbGFzc2lmaWNhdGlvbi5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFRhZ0Nsb3VkKCkge1xuICBjb25zdCBxdWVyeUZuID0gdXNlQ2FsbGJhY2soKGZpbGVzTWV0YWRhdGE6IFJlY29yZDxzdHJpbmcsIGFueT4pID0+IHtcbiAgICBjb25zdCBjb3VudHM6IFJlY29yZDxzdHJpbmcsIG51bWJlcj4gPSB7fTtcbiAgICBPYmplY3QuZW50cmllcyhmaWxlc01ldGFkYXRhKS5mb3JFYWNoKChbcCwgbV0pID0+IHtcbiAgICAgIGlmICghcC5zdGFydHNXaXRoKGNvbnRlbnREaXIoKSkpIHJldHVybjtcbiAgICAgIGlmIChtICYmIEFycmF5LmlzQXJyYXkobS50YWdzKSkge1xuICAgICAgICBtLnRhZ3MuZm9yRWFjaCgodDogc3RyaW5nKSA9PiB7XG4gICAgICAgICAgaWYgKHQuc3RhcnRzV2l0aCgndWkvJykpIHJldHVybjtcbiAgICAgICAgICBjb3VudHNbdF0gPSAoY291bnRzW3RdIHx8IDApICsgMTtcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfSk7XG4gICAgLy8gRW5jb2RlIGNvdW50cyBpbnRvIHRoZSBzdHJpbmdbXSB0aGUgcXVlcnkgY29udHJhY3QgcmV0dXJucy5cbiAgICByZXR1cm4gT2JqZWN0LmtleXMoY291bnRzKVxuICAgICAgLnNvcnQoKVxuICAgICAgLm1hcCgodCkgPT4gYCR7dH06JHtjb3VudHNbdF19YCk7XG4gIH0sIFtdKTtcblxuICBjb25zdCByZXN1bHQgPSB1c2VNZXRhZGF0YVF1ZXJ5KHF1ZXJ5Rm4pO1xuICBjb25zdCBlbnRyaWVzOiBzdHJpbmdbXSA9IHF1ZXJ5UGF0aHMocmVzdWx0KTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JvdmUtdGFnY2xvdWRcIj5cbiAgICAgIHtlbnRyaWVzLm1hcCgoZSkgPT4ge1xuICAgICAgICBjb25zdCBbdGFnLCBjb3VudF0gPSBlLnNwbGl0KCc6Jyk7XG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgIGtleT17dGFnfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ3JvdmUtdGFnXCJcbiAgICAgICAgICAgIHN0eWxlPXt7IGZvbnRTaXplOiAxMSArIE51bWJlcihjb3VudCkgKiAyICsgJ3B4JywgcGFkZGluZzogJzRweCAxMnB4JyB9fVxuICAgICAgICAgID5cbiAgICAgICAgICAgICN7dGFnfSA8c3BhbiBzdHlsZT17eyBvcGFjaXR5OiAwLjUsIG1hcmdpbkxlZnQ6IDQgfX0+e2NvdW50fTwvc3Bhbj5cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICk7XG4gICAgICB9KX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQ0EsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsSUFBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsUUFBQSxHQUFBRixPQUFBO0FBQ0EsSUFBQUcsS0FBQSxHQUFBSCxPQUFBO0FBQXlDLElBQUFJLFdBQUEsR0FBQUosT0FBQTtBQUFBLElBQUFLLEVBQUEsR0FBQUMsWUFBQTtBQUp6QztBQU1BO0FBQ0E7QUFDZSxTQUFTQyxRQUFRQSxDQUFBLEVBQUc7RUFBQUYsRUFBQTtFQUNqQyxNQUFNRyxPQUFPLEdBQUcsSUFBQUMsa0JBQVcsRUFBRUMsYUFBa0MsSUFBSztJQUNsRSxNQUFNQyxNQUE4QixHQUFHLENBQUMsQ0FBQztJQUN6Q0MsTUFBTSxDQUFDQyxPQUFPLENBQUNILGFBQWEsQ0FBQyxDQUFDSSxPQUFPLENBQUMsQ0FBQyxDQUFDQyxDQUFDLEVBQUVDLENBQUMsQ0FBQyxLQUFLO01BQ2hELElBQUksQ0FBQ0QsQ0FBQyxDQUFDRSxVQUFVLENBQUMsSUFBQUMsbUJBQVUsRUFBQyxDQUFDLENBQUMsRUFBRTtNQUNqQyxJQUFJRixDQUFDLElBQUlHLEtBQUssQ0FBQ0MsT0FBTyxDQUFDSixDQUFDLENBQUNLLElBQUksQ0FBQyxFQUFFO1FBQzlCTCxDQUFDLENBQUNLLElBQUksQ0FBQ1AsT0FBTyxDQUFFUSxDQUFTLElBQUs7VUFDNUIsSUFBSUEsQ0FBQyxDQUFDTCxVQUFVLENBQUMsS0FBSyxDQUFDLEVBQUU7VUFDekJOLE1BQU0sQ0FBQ1csQ0FBQyxDQUFDLEdBQUcsQ0FBQ1gsTUFBTSxDQUFDVyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztRQUNsQyxDQUFDLENBQUM7TUFDSjtJQUNGLENBQUMsQ0FBQztJQUNGO0lBQ0EsT0FBT1YsTUFBTSxDQUFDVyxJQUFJLENBQUNaLE1BQU0sQ0FBQyxDQUN2QmEsSUFBSSxDQUFDLENBQUMsQ0FDTkMsR0FBRyxDQUFFSCxDQUFDLElBQUssR0FBR0EsQ0FBQyxJQUFJWCxNQUFNLENBQUNXLENBQUMsQ0FBQyxFQUFFLENBQUM7RUFDcEMsQ0FBQyxFQUFFLEVBQUUsQ0FBQztFQUVOLE1BQU1JLE1BQU0sR0FBRyxJQUFBQyxxQkFBZ0IsRUFBQ25CLE9BQU8sQ0FBQztFQUN4QyxNQUFNSyxPQUFpQixHQUFHLElBQUFlLGdCQUFVLEVBQUNGLE1BQU0sQ0FBQztFQUU1QyxvQkFDRSxJQUFBdEIsV0FBQSxDQUFBeUIsR0FBQTtJQUFLQyxTQUFTLEVBQUMsZ0JBQWdCO0lBQUFDLFFBQUEsRUFDNUJsQixPQUFPLENBQUNZLEdBQUcsQ0FBRU8sQ0FBQyxJQUFLO01BQ2xCLE1BQU0sQ0FBQ0MsR0FBRyxFQUFFQyxLQUFLLENBQUMsR0FBR0YsQ0FBQyxDQUFDRyxLQUFLLENBQUMsR0FBRyxDQUFDO01BQ2pDLG9CQUNFLElBQUEvQixXQUFBLENBQUFnQyxJQUFBO1FBRUVOLFNBQVMsRUFBQyxXQUFXO1FBQ3JCTyxLQUFLLEVBQUU7VUFBRUMsUUFBUSxFQUFFLEVBQUUsR0FBR0MsTUFBTSxDQUFDTCxLQUFLLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSTtVQUFFTSxPQUFPLEVBQUU7UUFBVyxDQUFFO1FBQUFULFFBQUEsR0FDekUsR0FDRSxFQUFDRSxHQUFHLEVBQUMsR0FBQyxtQkFBQTdCLFdBQUEsQ0FBQXlCLEdBQUE7VUFBTVEsS0FBSyxFQUFFO1lBQUVJLE9BQU8sRUFBRSxHQUFHO1lBQUVDLFVBQVUsRUFBRTtVQUFFLENBQUU7VUFBQVgsUUFBQSxFQUFFRztRQUFLLENBQU8sQ0FBQztNQUFBLEdBSjlERCxHQUtELENBQUM7SUFFWCxDQUFDO0VBQUMsQ0FDQyxDQUFDO0FBRVY7QUFBQzVCLEVBQUEsQ0FyQ3VCRSxRQUFRO0VBQUEsUUFrQmZvQixxQkFBZ0I7QUFBQTtBQUFBZ0IsRUFBQSxHQWxCVHBDLFFBQVE7QUFBQSxJQUFBb0MsRUFBQTtBQUFBQyxZQUFBLENBQUFELEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}