var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = GroveFooter;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
var _sdk = require("@immediately-run/sdk");
var _shell = require("../lib/shell");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // `<GroveFooter/>` — the site footer. Import-free in MDX; reads the nav items from
// the shell context so a layout just places `<GroveFooter/>`.
function GroveFooter() {
  _s();
  const {
    navItems
  } = (0, _shell.useShell)();
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("footer", {
    className: "grove-footer",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "grove-footer__links",
      children: navItems.slice(0, 4).map(n => /*#__PURE__*/(0, _jsxRuntime.jsx)(_sdk.Link, {
        href: n.href,
        children: n.label
      }, n.key))
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "grove-footer__meta",
      children: "built with grove"
    })]
  });
}
_s(GroveFooter, "4FLaaOYJnF/j7jbhWE66jpsb2JA=", false, function () {
  return [_shell.useShell];
});
_c = GroveFooter;
var _c;
$RefreshReg$(_c, "GroveFooter");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfc2RrIiwicmVxdWlyZSIsIl9zaGVsbCIsIl9qc3hSdW50aW1lIiwiX3MiLCIkUmVmcmVzaFNpZyQiLCJHcm92ZUZvb3RlciIsIm5hdkl0ZW1zIiwidXNlU2hlbGwiLCJqc3hzIiwiY2xhc3NOYW1lIiwiY2hpbGRyZW4iLCJqc3giLCJzbGljZSIsIm1hcCIsIm4iLCJMaW5rIiwiaHJlZiIsImxhYmVsIiwia2V5IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJHcm92ZUZvb3Rlci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTGluayB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrJztcbmltcG9ydCB7IHVzZVNoZWxsIH0gZnJvbSAnLi4vbGliL3NoZWxsJztcblxuLy8gYDxHcm92ZUZvb3Rlci8+YCDigJQgdGhlIHNpdGUgZm9vdGVyLiBJbXBvcnQtZnJlZSBpbiBNRFg7IHJlYWRzIHRoZSBuYXYgaXRlbXMgZnJvbVxuLy8gdGhlIHNoZWxsIGNvbnRleHQgc28gYSBsYXlvdXQganVzdCBwbGFjZXMgYDxHcm92ZUZvb3Rlci8+YC5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEdyb3ZlRm9vdGVyKCkge1xuICBjb25zdCB7IG5hdkl0ZW1zIH0gPSB1c2VTaGVsbCgpO1xuICByZXR1cm4gKFxuICAgIDxmb290ZXIgY2xhc3NOYW1lPVwiZ3JvdmUtZm9vdGVyXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyb3ZlLWZvb3Rlcl9fbGlua3NcIj5cbiAgICAgICAge25hdkl0ZW1zLnNsaWNlKDAsIDQpLm1hcCgobikgPT4gKFxuICAgICAgICAgIDxMaW5rIGtleT17bi5rZXl9IGhyZWY9e24uaHJlZn0+XG4gICAgICAgICAgICB7bi5sYWJlbH1cbiAgICAgICAgICA8L0xpbms+XG4gICAgICAgICkpfVxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyb3ZlLWZvb3Rlcl9fbWV0YVwiPmJ1aWx0IHdpdGggZ3JvdmU8L2Rpdj5cbiAgICA8L2Zvb3Rlcj5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQSxJQUFBQSxJQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxNQUFBLEdBQUFELE9BQUE7QUFBd0MsSUFBQUUsV0FBQSxHQUFBRixPQUFBO0FBQUEsSUFBQUcsRUFBQSxHQUFBQyxZQUFBLElBRXhDO0FBQ0E7QUFDZSxTQUFTQyxXQUFXQSxDQUFBLEVBQUc7RUFBQUYsRUFBQTtFQUNwQyxNQUFNO0lBQUVHO0VBQVMsQ0FBQyxHQUFHLElBQUFDLGVBQVEsRUFBQyxDQUFDO0VBQy9CLG9CQUNFLElBQUFMLFdBQUEsQ0FBQU0sSUFBQTtJQUFRQyxTQUFTLEVBQUMsY0FBYztJQUFBQyxRQUFBLGdCQUM5QixJQUFBUixXQUFBLENBQUFTLEdBQUE7TUFBS0YsU0FBUyxFQUFDLHFCQUFxQjtNQUFBQyxRQUFBLEVBQ2pDSixRQUFRLENBQUNNLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUNDLEdBQUcsQ0FBRUMsQ0FBQyxpQkFDMUIsSUFBQVosV0FBQSxDQUFBUyxHQUFBLEVBQUNaLElBQUEsQ0FBQWdCLElBQUk7UUFBYUMsSUFBSSxFQUFFRixDQUFDLENBQUNFLElBQUs7UUFBQU4sUUFBQSxFQUM1QkksQ0FBQyxDQUFDRztNQUFLLEdBRENILENBQUMsQ0FBQ0ksR0FFUCxDQUNQO0lBQUMsQ0FDQyxDQUFDLGVBQ04sSUFBQWhCLFdBQUEsQ0FBQVMsR0FBQTtNQUFLRixTQUFTLEVBQUMsb0JBQW9CO01BQUFDLFFBQUEsRUFBQztJQUFnQixDQUFLLENBQUM7RUFBQSxDQUNwRCxDQUFDO0FBRWI7QUFBQ1AsRUFBQSxDQWR1QkUsV0FBVztFQUFBLFFBQ1pFLGVBQVE7QUFBQTtBQUFBWSxFQUFBLEdBRFBkLFdBQVc7QUFBQSxJQUFBYyxFQUFBO0FBQUFDLFlBQUEsQ0FBQUQsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}