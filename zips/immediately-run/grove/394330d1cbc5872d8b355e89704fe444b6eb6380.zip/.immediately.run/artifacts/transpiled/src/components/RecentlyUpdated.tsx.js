var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = RecentlyUpdated;
var _DocList = _interopRequireDefault(require("./DocList"));
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// `<RecentlyUpdated limit>` — a compact, date-sorted feed of the latest entries.
function RecentlyUpdated({
  limit = 6,
  title
}) {
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_DocList.default, {
    shape: "feed",
    sort: "date",
    limit: limit,
    title: title ?? 'Recently updated'
  });
}
_c = RecentlyUpdated;
var _c;
$RefreshReg$(_c, "RecentlyUpdated");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfRG9jTGlzdCIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJlIiwiX19lc01vZHVsZSIsImRlZmF1bHQiLCJSZWNlbnRseVVwZGF0ZWQiLCJsaW1pdCIsInRpdGxlIiwianN4Iiwic2hhcGUiLCJzb3J0IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJSZWNlbnRseVVwZGF0ZWQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBEb2NMaXN0IGZyb20gJy4vRG9jTGlzdCc7XG5cbi8vIGA8UmVjZW50bHlVcGRhdGVkIGxpbWl0PmAg4oCUIGEgY29tcGFjdCwgZGF0ZS1zb3J0ZWQgZmVlZCBvZiB0aGUgbGF0ZXN0IGVudHJpZXMuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBSZWNlbnRseVVwZGF0ZWQoeyBsaW1pdCA9IDYsIHRpdGxlIH06IHsgbGltaXQ/OiBzdHJpbmcgfCBudW1iZXI7IHRpdGxlPzogc3RyaW5nIH0pIHtcbiAgcmV0dXJuIDxEb2NMaXN0IHNoYXBlPVwiZmVlZFwiIHNvcnQ9XCJkYXRlXCIgbGltaXQ9e2xpbWl0fSB0aXRsZT17dGl0bGUgPz8gJ1JlY2VudGx5IHVwZGF0ZWQnfSAvPjtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQUEsSUFBQUEsUUFBQSxHQUFBQyxzQkFBQSxDQUFBQyxPQUFBO0FBQWdDLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUFBLFNBQUFELHVCQUFBRyxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBRWhDO0FBQ2UsU0FBU0csZUFBZUEsQ0FBQztFQUFFQyxLQUFLLEdBQUcsQ0FBQztFQUFFQztBQUFtRCxDQUFDLEVBQUU7RUFDekcsb0JBQU8sSUFBQU4sV0FBQSxDQUFBTyxHQUFBLEVBQUNWLFFBQUEsQ0FBQU0sT0FBTztJQUFDSyxLQUFLLEVBQUMsTUFBTTtJQUFDQyxJQUFJLEVBQUMsTUFBTTtJQUFDSixLQUFLLEVBQUVBLEtBQU07SUFBQ0MsS0FBSyxFQUFFQSxLQUFLLElBQUk7RUFBbUIsQ0FBRSxDQUFDO0FBQy9GO0FBQUNJLEVBQUEsR0FGdUJOLGVBQWU7QUFBQSxJQUFBTSxFQUFBO0FBQUFDLFlBQUEsQ0FBQUQsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}