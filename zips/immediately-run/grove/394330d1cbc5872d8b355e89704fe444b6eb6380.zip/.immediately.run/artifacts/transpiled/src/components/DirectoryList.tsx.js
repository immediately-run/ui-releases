var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = DirectoryList;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
var _TinkerableContext = require("@immediately-run/sdk/TinkerableContext");
var _content = require("../lib/content");
var _directory = require("../lib/directory");
var _useDirectoryListing = require("../hooks/useDirectoryListing");
var _Icon = _interopRequireDefault(require("./Icon"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$();
/* eslint-disable @typescript-eslint/no-explicit-any */
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
const HEADINGS = {
  name: 'Name',
  description: 'Description',
  tags: 'Tags',
  updated: 'Updated',
  status: 'Status'
};

// `hidden="false"` is a string in MDX, and under the safe renderer EVERY attribute is a
// literal string — so a boolean prop that trusted truthiness would read `"false"` as on.
function flag(v) {
  return v === true || v === '' || v === 'true';
}
function Cell({
  row,
  col
}) {
  const value = (0, _directory.columnValue)(row, col);
  if (col === 'tags') {
    const tags = Array.isArray(value) ? value : [];
    return /*#__PURE__*/(0, _jsxRuntime.jsx)("td", {
      className: "gdir__tags",
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "gdir__tagbox",
        children: tags.slice(0, 4).map(t => /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
          className: "grove-tag",
          children: ["#", t]
        }, t))
      })
    });
  }
  if (col === 'updated' || col === 'status') {
    return /*#__PURE__*/(0, _jsxRuntime.jsx)("td", {
      className: `mono gdir__${col}`,
      children: typeof value === 'string' ? value : null
    });
  }
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("td", {
    className: "gdir__desc",
    children: typeof value === 'string' ? value : null
  });
}
_c = Cell;
function Row({
  row,
  cols
}) {
  const label = (0, _directory.rowLabel)(row);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("tr", {
    "data-kind": row.kind,
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("td", {
      className: "gdir__name",
      children: /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "gdir__namebox",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "gdir__icon",
          "aria-hidden": "true",
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
            name: row.kind === 'dir' ? 'folder' : 'file'
          })
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
          className: "gdir__labels",
          children: [row.href ? /*#__PURE__*/(0, _jsxRuntime.jsx)(_sdk.Link, {
            href: row.href,
            className: "gdir__link",
            children: label
          }) :
          /*#__PURE__*/
          // An asset is listed but not linked: Grove's route space renders entries,
          // so a link here would resolve to the 404 it was meant to replace.
          (0, _jsxRuntime.jsx)("span", {
            className: "gdir__plain",
            children: label
          }), label !== row.name ? /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
            className: "gdir__file",
            children: row.name
          }) : null]
        })]
      })
    }), cols.slice(1).map(c => /*#__PURE__*/(0, _jsxRuntime.jsx)(Cell, {
      row: row,
      col: c
    }, c))]
  });
}

/**
 * `<DirectoryList/>` — every file in a folder as a table, enriched with whatever Grove
 * frontmatter its entries carry.
 *
 * Two callers, one component. Content uses it as ordinary import-free vocabulary
 * (`<DirectoryList path="/handbook"/>`); the router renders it for a URL that names a
 * FOLDER rather than an entry — the case that used to 404. Both go through the MDX
 * component map, so a fork or a content-provided `DirectoryList` (R3-174) replaces the
 * built-in on *both* surfaces at once. That is the point of resolving it by name rather
 * than importing it in the router: an override that only reached MDX bodies and left the
 * folder route rendering the stock table would be a half-override nobody could see.
 */
_c2 = Row;
function DirectoryList({
  path,
  title,
  columns,
  sort = 'name',
  hidden
}) {
  _s();
  const ctx = (0, _react.useContext)(_TinkerableContext.TinkerableContext);
  const routeKey = (0, _content.sandboxPathToKey)(ctx?.navigationState?.sandboxPath || '/');
  // The route key is a FILE when it names an entry; a listing anchored at an entry means
  // "the folder that entry lives in", which is what an author writing `<DirectoryList/>`
  // inside a page means by "here".
  const fromDir = /\.mdx?$/.test(routeKey) ? routeKey.slice(0, routeKey.lastIndexOf('/')) : routeKey;
  const dirKey = (0, _directory.resolveDirKey)(path, fromDir);
  const listing = (0, _useDirectoryListing.useDirectoryListing)(dirKey);
  const metadata = (0, _sdk.useAllMetadata)();
  if (listing.status !== 'ready') {
    return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "grove-dirlist",
      "data-state": listing.status,
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "sk sk-line",
        style: {
          width: '60%'
        }
      })
    });
  }
  const rows = (0, _directory.buildDirectoryRows)(dirKey, listing.entries, metadata, {
    hidden: flag(hidden),
    sort
  });
  const cols = (0, _directory.visibleColumns)(rows, (0, _directory.parseColumns)(columns));
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "grove-dirlist",
    children: [title ? /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "grove-doclist__head",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("h2", {
        children: title
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
        className: "n",
        children: [rows.length, " ", rows.length === 1 ? 'item' : 'items']
      })]
    }) : null, rows.length === 0 ?
    /*#__PURE__*/
    // Two different facts, said differently. A folder with nothing in it and a folder
    // whose every child is structural (`_layout.mdx`) both produce zero rows, and
    // "This folder is empty." is false for the second — the reader goes looking for
    // the file they know is there. Say which it is.
    (0, _jsxRuntime.jsxs)("div", {
      className: "grove-dirlist__empty",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "gdir__icon",
        "aria-hidden": "true",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
          name: "folder"
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
        className: "grove-dirlist__empty-t",
        children: listing.entries.length === 0 ? 'This folder is empty.' : 'Nothing to show in this folder.'
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
        className: "grove-dirlist__empty-d",
        children: listing.entries.length === 0 ? 'No entries, subfolders or files here yet.' : `Everything here is hidden or structural — ${listing.entries.length} ${listing.entries.length === 1 ? 'file' : 'files'} skipped.`
      })]
    }) : /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "grove-table-wrap",
      children: /*#__PURE__*/(0, _jsxRuntime.jsxs)("table", {
        className: "grove-table grove-dirlist__table",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("thead", {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)("tr", {
            children: cols.map(c => /*#__PURE__*/(0, _jsxRuntime.jsx)("th", {
              scope: "col",
              className: `gdir__th gdir__th--${c}`,
              children: HEADINGS[c]
            }, c))
          })
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("tbody", {
          children: rows.map(r => /*#__PURE__*/(0, _jsxRuntime.jsx)(Row, {
            row: r,
            cols: cols
          }, r.key))
        })]
      })
    })]
  });
}
_s(DirectoryList, "VzEOKwoM4yf9D9B5Lj/qK4BFXNA=", false, function () {
  return [_useDirectoryListing.useDirectoryListing, _sdk.useAllMetadata];
});
_c3 = DirectoryList;
var _c, _c2, _c3;
$RefreshReg$(_c, "Cell");
$RefreshReg$(_c2, "Row");
$RefreshReg$(_c3, "DirectoryList");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NkayIsIl9UaW5rZXJhYmxlQ29udGV4dCIsIl9jb250ZW50IiwiX2RpcmVjdG9yeSIsIl91c2VEaXJlY3RvcnlMaXN0aW5nIiwiX0ljb24iLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsIkhFQURJTkdTIiwibmFtZSIsImRlc2NyaXB0aW9uIiwidGFncyIsInVwZGF0ZWQiLCJzdGF0dXMiLCJmbGFnIiwidiIsIkNlbGwiLCJyb3ciLCJjb2wiLCJ2YWx1ZSIsImNvbHVtblZhbHVlIiwiQXJyYXkiLCJpc0FycmF5IiwianN4IiwiY2xhc3NOYW1lIiwiY2hpbGRyZW4iLCJzbGljZSIsIm1hcCIsInQiLCJqc3hzIiwiX2MiLCJSb3ciLCJjb2xzIiwibGFiZWwiLCJyb3dMYWJlbCIsImtpbmQiLCJocmVmIiwiTGluayIsImMiLCJfYzIiLCJEaXJlY3RvcnlMaXN0IiwicGF0aCIsInRpdGxlIiwiY29sdW1ucyIsInNvcnQiLCJoaWRkZW4iLCJjdHgiLCJ1c2VDb250ZXh0IiwiVGlua2VyYWJsZUNvbnRleHQiLCJyb3V0ZUtleSIsInNhbmRib3hQYXRoVG9LZXkiLCJuYXZpZ2F0aW9uU3RhdGUiLCJzYW5kYm94UGF0aCIsImZyb21EaXIiLCJ0ZXN0IiwibGFzdEluZGV4T2YiLCJkaXJLZXkiLCJyZXNvbHZlRGlyS2V5IiwibGlzdGluZyIsInVzZURpcmVjdG9yeUxpc3RpbmciLCJtZXRhZGF0YSIsInVzZUFsbE1ldGFkYXRhIiwic3R5bGUiLCJ3aWR0aCIsInJvd3MiLCJidWlsZERpcmVjdG9yeVJvd3MiLCJlbnRyaWVzIiwidmlzaWJsZUNvbHVtbnMiLCJwYXJzZUNvbHVtbnMiLCJsZW5ndGgiLCJzY29wZSIsInIiLCJrZXkiLCJfYzMiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJEaXJlY3RvcnlMaXN0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55ICovXG5pbXBvcnQgeyB1c2VDb250ZXh0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgTGluaywgdXNlQWxsTWV0YWRhdGEgfSBmcm9tICdAaW1tZWRpYXRlbHktcnVuL3Nkayc7XG5pbXBvcnQgeyBUaW5rZXJhYmxlQ29udGV4dCB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrL1RpbmtlcmFibGVDb250ZXh0JztcbmltcG9ydCB7IHNhbmRib3hQYXRoVG9LZXkgfSBmcm9tICcuLi9saWIvY29udGVudCc7XG5pbXBvcnQge1xuICBidWlsZERpcmVjdG9yeVJvd3MsXG4gIGNvbHVtblZhbHVlLFxuICBwYXJzZUNvbHVtbnMsXG4gIHJlc29sdmVEaXJLZXksXG4gIHJvd0xhYmVsLFxuICB2aXNpYmxlQ29sdW1ucyxcbiAgdHlwZSBEaXJDb2x1bW4sXG4gIHR5cGUgRGlyUm93LFxufSBmcm9tICcuLi9saWIvZGlyZWN0b3J5JztcbmltcG9ydCB7IHVzZURpcmVjdG9yeUxpc3RpbmcgfSBmcm9tICcuLi9ob29rcy91c2VEaXJlY3RvcnlMaXN0aW5nJztcbmltcG9ydCBJY29uIGZyb20gJy4vSWNvbic7XG5cbmludGVyZmFjZSBQcm9wcyB7XG4gIC8qKiBUaGUgZm9sZGVyIHRvIGxpc3QuIENvcnB1cy1yZWxhdGl2ZSB3aXRoIGEgbGVhZGluZyBgL2AgKGAvaGFuZGJvb2tgKSwgb3RoZXJ3aXNlXG4gICAqICByZWxhdGl2ZSB0byB0aGUgY3VycmVudCBlbnRyeSdzIGZvbGRlci4gT21pdCBpdCB0byBsaXN0IHRoZSBjdXJyZW50IGZvbGRlci4gKi9cbiAgcGF0aD86IHN0cmluZztcbiAgLyoqIEhlYWRpbmcgYWJvdmUgdGhlIHRhYmxlLiBgbnVsbGAvYFwiXCJgIHJlbmRlcnMgbm8gaGVhZGluZy4gKi9cbiAgdGl0bGU/OiBzdHJpbmcgfCBudWxsO1xuICAvKiogYGRlc2NyaXB0aW9uLHRhZ3MsdXBkYXRlZCxzdGF0dXNgIOKAlCB3aGljaCBtZXRhZGF0YSBjb2x1bW5zIHRvIGNvbnNpZGVyLiBBIGNvbHVtblxuICAgKiAgbm8gcm93IGNhcnJpZXMgaXMgZHJvcHBlZCByZWdhcmRsZXNzLCBzbyB0aGlzIG5hcnJvd3MsIG5ldmVyIHBhZHMuICovXG4gIGNvbHVtbnM/OiBzdHJpbmc7XG4gIHNvcnQ/OiAnbmFtZScgfCAndGl0bGUnIHwgJ3VwZGF0ZWQnO1xuICAvKiogSW5jbHVkZSBkb3QtIGFuZCBgX2AtcHJlZml4ZWQgbmFtZXMuICovXG4gIGhpZGRlbj86IGJvb2xlYW4gfCBzdHJpbmc7XG59XG5cbmNvbnN0IEhFQURJTkdTOiBSZWNvcmQ8RGlyQ29sdW1uLCBzdHJpbmc+ID0ge1xuICBuYW1lOiAnTmFtZScsXG4gIGRlc2NyaXB0aW9uOiAnRGVzY3JpcHRpb24nLFxuICB0YWdzOiAnVGFncycsXG4gIHVwZGF0ZWQ6ICdVcGRhdGVkJyxcbiAgc3RhdHVzOiAnU3RhdHVzJyxcbn07XG5cbi8vIGBoaWRkZW49XCJmYWxzZVwiYCBpcyBhIHN0cmluZyBpbiBNRFgsIGFuZCB1bmRlciB0aGUgc2FmZSByZW5kZXJlciBFVkVSWSBhdHRyaWJ1dGUgaXMgYVxuLy8gbGl0ZXJhbCBzdHJpbmcg4oCUIHNvIGEgYm9vbGVhbiBwcm9wIHRoYXQgdHJ1c3RlZCB0cnV0aGluZXNzIHdvdWxkIHJlYWQgYFwiZmFsc2VcImAgYXMgb24uXG5mdW5jdGlvbiBmbGFnKHY6IGJvb2xlYW4gfCBzdHJpbmcgfCB1bmRlZmluZWQpOiBib29sZWFuIHtcbiAgcmV0dXJuIHYgPT09IHRydWUgfHwgdiA9PT0gJycgfHwgdiA9PT0gJ3RydWUnO1xufVxuXG5mdW5jdGlvbiBDZWxsKHsgcm93LCBjb2wgfTogeyByb3c6IERpclJvdzsgY29sOiBEaXJDb2x1bW4gfSkge1xuICBjb25zdCB2YWx1ZSA9IGNvbHVtblZhbHVlKHJvdywgY29sKTtcbiAgaWYgKGNvbCA9PT0gJ3RhZ3MnKSB7XG4gICAgY29uc3QgdGFncyA9IEFycmF5LmlzQXJyYXkodmFsdWUpID8gdmFsdWUgOiBbXTtcbiAgICByZXR1cm4gKFxuICAgICAgPHRkIGNsYXNzTmFtZT1cImdkaXJfX3RhZ3NcIj5cbiAgICAgICAgey8qIFNhbWUgcmVhc29uIGFzIHRoZSBuYW1lIGNlbGw6IHRoZSBmbGV4IGJveCBnb2VzIElOU0lERSB0aGUgYDx0ZD5gLiAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJnZGlyX190YWdib3hcIj5cbiAgICAgICAgICB7dGFncy5zbGljZSgwLCA0KS5tYXAoKHQpID0+IChcbiAgICAgICAgICAgIDxzcGFuIGtleT17dH0gY2xhc3NOYW1lPVwiZ3JvdmUtdGFnXCI+I3t0fTwvc3Bhbj5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L3RkPlxuICAgICk7XG4gIH1cbiAgaWYgKGNvbCA9PT0gJ3VwZGF0ZWQnIHx8IGNvbCA9PT0gJ3N0YXR1cycpIHtcbiAgICByZXR1cm4gPHRkIGNsYXNzTmFtZT17YG1vbm8gZ2Rpcl9fJHtjb2x9YH0+e3R5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycgPyB2YWx1ZSA6IG51bGx9PC90ZD47XG4gIH1cbiAgcmV0dXJuIDx0ZCBjbGFzc05hbWU9XCJnZGlyX19kZXNjXCI+e3R5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycgPyB2YWx1ZSA6IG51bGx9PC90ZD47XG59XG5cbmZ1bmN0aW9uIFJvdyh7IHJvdywgY29scyB9OiB7IHJvdzogRGlyUm93OyBjb2xzOiBEaXJDb2x1bW5bXSB9KSB7XG4gIGNvbnN0IGxhYmVsID0gcm93TGFiZWwocm93KTtcbiAgcmV0dXJuIChcbiAgICA8dHIgZGF0YS1raW5kPXtyb3cua2luZH0+XG4gICAgICA8dGQgY2xhc3NOYW1lPVwiZ2Rpcl9fbmFtZVwiPlxuICAgICAgICB7LyogVGhlIGZsZXggYm94IGlzIElOU0lERSB0aGUgY2VsbC4gYGRpc3BsYXk6ZmxleGAgb24gYSBgPHRkPmAgdGFrZXMgaXQgb3V0IG9mXG4gICAgICAgICAgICB0aGUgdGFibGUgbGF5b3V0IGFsZ29yaXRobSwgYW5kIHRoZSBjb2x1bW4gc3RvcHMgc2hhcmluZyBhIHdpZHRoIHdpdGggaXRzXG4gICAgICAgICAgICBoZWFkZXIg4oCUIHRoZSBzeW1wdG9tIGlzIHBlci1yb3cgYm9yZGVycyB0aGF0IGRvbid0IGxpbmUgdXAuICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdkaXJfX25hbWVib3hcIj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJnZGlyX19pY29uXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+XG4gICAgICAgICAgICA8SWNvbiBuYW1lPXtyb3cua2luZCA9PT0gJ2RpcicgPyAnZm9sZGVyJyA6ICdmaWxlJ30gLz5cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZ2Rpcl9fbGFiZWxzXCI+XG4gICAgICAgICAgICB7cm93LmhyZWYgPyAoXG4gICAgICAgICAgICAgIDxMaW5rIGhyZWY9e3Jvdy5ocmVmfSBjbGFzc05hbWU9XCJnZGlyX19saW5rXCI+XG4gICAgICAgICAgICAgICAge2xhYmVsfVxuICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAvLyBBbiBhc3NldCBpcyBsaXN0ZWQgYnV0IG5vdCBsaW5rZWQ6IEdyb3ZlJ3Mgcm91dGUgc3BhY2UgcmVuZGVycyBlbnRyaWVzLFxuICAgICAgICAgICAgICAvLyBzbyBhIGxpbmsgaGVyZSB3b3VsZCByZXNvbHZlIHRvIHRoZSA0MDQgaXQgd2FzIG1lYW50IHRvIHJlcGxhY2UuXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImdkaXJfX3BsYWluXCI+e2xhYmVsfTwvc3Bhbj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgICB7bGFiZWwgIT09IHJvdy5uYW1lID8gPHNwYW4gY2xhc3NOYW1lPVwiZ2Rpcl9fZmlsZVwiPntyb3cubmFtZX08L3NwYW4+IDogbnVsbH1cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC90ZD5cbiAgICAgIHtjb2xzLnNsaWNlKDEpLm1hcCgoYykgPT4gKFxuICAgICAgICA8Q2VsbCBrZXk9e2N9IHJvdz17cm93fSBjb2w9e2N9IC8+XG4gICAgICApKX1cbiAgICA8L3RyPlxuICApO1xufVxuXG4vKipcbiAqIGA8RGlyZWN0b3J5TGlzdC8+YCDigJQgZXZlcnkgZmlsZSBpbiBhIGZvbGRlciBhcyBhIHRhYmxlLCBlbnJpY2hlZCB3aXRoIHdoYXRldmVyIEdyb3ZlXG4gKiBmcm9udG1hdHRlciBpdHMgZW50cmllcyBjYXJyeS5cbiAqXG4gKiBUd28gY2FsbGVycywgb25lIGNvbXBvbmVudC4gQ29udGVudCB1c2VzIGl0IGFzIG9yZGluYXJ5IGltcG9ydC1mcmVlIHZvY2FidWxhcnlcbiAqIChgPERpcmVjdG9yeUxpc3QgcGF0aD1cIi9oYW5kYm9va1wiLz5gKTsgdGhlIHJvdXRlciByZW5kZXJzIGl0IGZvciBhIFVSTCB0aGF0IG5hbWVzIGFcbiAqIEZPTERFUiByYXRoZXIgdGhhbiBhbiBlbnRyeSDigJQgdGhlIGNhc2UgdGhhdCB1c2VkIHRvIDQwNC4gQm90aCBnbyB0aHJvdWdoIHRoZSBNRFhcbiAqIGNvbXBvbmVudCBtYXAsIHNvIGEgZm9yayBvciBhIGNvbnRlbnQtcHJvdmlkZWQgYERpcmVjdG9yeUxpc3RgIChSMy0xNzQpIHJlcGxhY2VzIHRoZVxuICogYnVpbHQtaW4gb24gKmJvdGgqIHN1cmZhY2VzIGF0IG9uY2UuIFRoYXQgaXMgdGhlIHBvaW50IG9mIHJlc29sdmluZyBpdCBieSBuYW1lIHJhdGhlclxuICogdGhhbiBpbXBvcnRpbmcgaXQgaW4gdGhlIHJvdXRlcjogYW4gb3ZlcnJpZGUgdGhhdCBvbmx5IHJlYWNoZWQgTURYIGJvZGllcyBhbmQgbGVmdCB0aGVcbiAqIGZvbGRlciByb3V0ZSByZW5kZXJpbmcgdGhlIHN0b2NrIHRhYmxlIHdvdWxkIGJlIGEgaGFsZi1vdmVycmlkZSBub2JvZHkgY291bGQgc2VlLlxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBEaXJlY3RvcnlMaXN0KHsgcGF0aCwgdGl0bGUsIGNvbHVtbnMsIHNvcnQgPSAnbmFtZScsIGhpZGRlbiB9OiBQcm9wcykge1xuICBjb25zdCBjdHggPSB1c2VDb250ZXh0KFRpbmtlcmFibGVDb250ZXh0KSBhcyBhbnk7XG4gIGNvbnN0IHJvdXRlS2V5ID0gc2FuZGJveFBhdGhUb0tleShjdHg/Lm5hdmlnYXRpb25TdGF0ZT8uc2FuZGJveFBhdGggfHwgJy8nKTtcbiAgLy8gVGhlIHJvdXRlIGtleSBpcyBhIEZJTEUgd2hlbiBpdCBuYW1lcyBhbiBlbnRyeTsgYSBsaXN0aW5nIGFuY2hvcmVkIGF0IGFuIGVudHJ5IG1lYW5zXG4gIC8vIFwidGhlIGZvbGRlciB0aGF0IGVudHJ5IGxpdmVzIGluXCIsIHdoaWNoIGlzIHdoYXQgYW4gYXV0aG9yIHdyaXRpbmcgYDxEaXJlY3RvcnlMaXN0Lz5gXG4gIC8vIGluc2lkZSBhIHBhZ2UgbWVhbnMgYnkgXCJoZXJlXCIuXG4gIGNvbnN0IGZyb21EaXIgPSAvXFwubWR4PyQvLnRlc3Qocm91dGVLZXkpID8gcm91dGVLZXkuc2xpY2UoMCwgcm91dGVLZXkubGFzdEluZGV4T2YoJy8nKSkgOiByb3V0ZUtleTtcbiAgY29uc3QgZGlyS2V5ID0gcmVzb2x2ZURpcktleShwYXRoLCBmcm9tRGlyKTtcblxuICBjb25zdCBsaXN0aW5nID0gdXNlRGlyZWN0b3J5TGlzdGluZyhkaXJLZXkpO1xuICBjb25zdCBtZXRhZGF0YSA9IHVzZUFsbE1ldGFkYXRhKCkgYXMgUmVjb3JkPHN0cmluZywgYW55PjtcblxuICBpZiAobGlzdGluZy5zdGF0dXMgIT09ICdyZWFkeScpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncm92ZS1kaXJsaXN0XCIgZGF0YS1zdGF0ZT17bGlzdGluZy5zdGF0dXN9PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNrIHNrLWxpbmVcIiBzdHlsZT17eyB3aWR0aDogJzYwJScgfX0gLz5cbiAgICAgIDwvZGl2PlxuICAgICk7XG4gIH1cblxuICBjb25zdCByb3dzID0gYnVpbGREaXJlY3RvcnlSb3dzKGRpcktleSwgbGlzdGluZy5lbnRyaWVzLCBtZXRhZGF0YSwge1xuICAgIGhpZGRlbjogZmxhZyhoaWRkZW4pLFxuICAgIHNvcnQsXG4gIH0pO1xuICBjb25zdCBjb2xzID0gdmlzaWJsZUNvbHVtbnMocm93cywgcGFyc2VDb2x1bW5zKGNvbHVtbnMpKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JvdmUtZGlybGlzdFwiPlxuICAgICAge3RpdGxlID8gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyb3ZlLWRvY2xpc3RfX2hlYWRcIj5cbiAgICAgICAgICA8aDI+e3RpdGxlfTwvaDI+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiblwiPlxuICAgICAgICAgICAge3Jvd3MubGVuZ3RofSB7cm93cy5sZW5ndGggPT09IDEgPyAnaXRlbScgOiAnaXRlbXMnfVxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApIDogbnVsbH1cbiAgICAgIHtyb3dzLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgLy8gVHdvIGRpZmZlcmVudCBmYWN0cywgc2FpZCBkaWZmZXJlbnRseS4gQSBmb2xkZXIgd2l0aCBub3RoaW5nIGluIGl0IGFuZCBhIGZvbGRlclxuICAgICAgICAvLyB3aG9zZSBldmVyeSBjaGlsZCBpcyBzdHJ1Y3R1cmFsIChgX2xheW91dC5tZHhgKSBib3RoIHByb2R1Y2UgemVybyByb3dzLCBhbmRcbiAgICAgICAgLy8gXCJUaGlzIGZvbGRlciBpcyBlbXB0eS5cIiBpcyBmYWxzZSBmb3IgdGhlIHNlY29uZCDigJQgdGhlIHJlYWRlciBnb2VzIGxvb2tpbmcgZm9yXG4gICAgICAgIC8vIHRoZSBmaWxlIHRoZXkga25vdyBpcyB0aGVyZS4gU2F5IHdoaWNoIGl0IGlzLlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyb3ZlLWRpcmxpc3RfX2VtcHR5XCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZ2Rpcl9faWNvblwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPlxuICAgICAgICAgICAgPEljb24gbmFtZT1cImZvbGRlclwiIC8+XG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImdyb3ZlLWRpcmxpc3RfX2VtcHR5LXRcIj5cbiAgICAgICAgICAgIHtsaXN0aW5nLmVudHJpZXMubGVuZ3RoID09PSAwID8gJ1RoaXMgZm9sZGVyIGlzIGVtcHR5LicgOiAnTm90aGluZyB0byBzaG93IGluIHRoaXMgZm9sZGVyLid9XG4gICAgICAgICAgPC9wPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImdyb3ZlLWRpcmxpc3RfX2VtcHR5LWRcIj5cbiAgICAgICAgICAgIHtsaXN0aW5nLmVudHJpZXMubGVuZ3RoID09PSAwXG4gICAgICAgICAgICAgID8gJ05vIGVudHJpZXMsIHN1YmZvbGRlcnMgb3IgZmlsZXMgaGVyZSB5ZXQuJ1xuICAgICAgICAgICAgICA6IGBFdmVyeXRoaW5nIGhlcmUgaXMgaGlkZGVuIG9yIHN0cnVjdHVyYWwg4oCUICR7bGlzdGluZy5lbnRyaWVzLmxlbmd0aH0gJHtsaXN0aW5nLmVudHJpZXMubGVuZ3RoID09PSAxID8gJ2ZpbGUnIDogJ2ZpbGVzJ30gc2tpcHBlZC5gfVxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICApIDogKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyb3ZlLXRhYmxlLXdyYXBcIj5cbiAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwiZ3JvdmUtdGFibGUgZ3JvdmUtZGlybGlzdF9fdGFibGVcIj5cbiAgICAgICAgICAgIDx0aGVhZD5cbiAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgIHtjb2xzLm1hcCgoYykgPT4gKFxuICAgICAgICAgICAgICAgICAgPHRoIGtleT17Y30gc2NvcGU9XCJjb2xcIiBjbGFzc05hbWU9e2BnZGlyX190aCBnZGlyX190aC0tJHtjfWB9PlxuICAgICAgICAgICAgICAgICAgICB7SEVBRElOR1NbY119XG4gICAgICAgICAgICAgICAgICA8L3RoPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgIDx0Ym9keT5cbiAgICAgICAgICAgICAge3Jvd3MubWFwKChyKSA9PiAoXG4gICAgICAgICAgICAgICAgPFJvdyBrZXk9e3Iua2V5fSByb3c9e3J9IGNvbHM9e2NvbHN9IC8+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQ0EsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsSUFBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsa0JBQUEsR0FBQUYsT0FBQTtBQUNBLElBQUFHLFFBQUEsR0FBQUgsT0FBQTtBQUNBLElBQUFJLFVBQUEsR0FBQUosT0FBQTtBQVVBLElBQUFLLG9CQUFBLEdBQUFMLE9BQUE7QUFDQSxJQUFBTSxLQUFBLEdBQUFDLHNCQUFBLENBQUFQLE9BQUE7QUFBMEIsSUFBQVEsV0FBQSxHQUFBUixPQUFBO0FBQUEsSUFBQVMsRUFBQSxHQUFBQyxZQUFBO0FBaEIxQjtBQUFBLFNBQUFILHVCQUFBSSxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBZ0NBLE1BQU1HLFFBQW1DLEdBQUc7RUFDMUNDLElBQUksRUFBRSxNQUFNO0VBQ1pDLFdBQVcsRUFBRSxhQUFhO0VBQzFCQyxJQUFJLEVBQUUsTUFBTTtFQUNaQyxPQUFPLEVBQUUsU0FBUztFQUNsQkMsTUFBTSxFQUFFO0FBQ1YsQ0FBQzs7QUFFRDtBQUNBO0FBQ0EsU0FBU0MsSUFBSUEsQ0FBQ0MsQ0FBK0IsRUFBVztFQUN0RCxPQUFPQSxDQUFDLEtBQUssSUFBSSxJQUFJQSxDQUFDLEtBQUssRUFBRSxJQUFJQSxDQUFDLEtBQUssTUFBTTtBQUMvQztBQUVBLFNBQVNDLElBQUlBLENBQUM7RUFBRUMsR0FBRztFQUFFQztBQUFxQyxDQUFDLEVBQUU7RUFDM0QsTUFBTUMsS0FBSyxHQUFHLElBQUFDLHNCQUFXLEVBQUNILEdBQUcsRUFBRUMsR0FBRyxDQUFDO0VBQ25DLElBQUlBLEdBQUcsS0FBSyxNQUFNLEVBQUU7SUFDbEIsTUFBTVAsSUFBSSxHQUFHVSxLQUFLLENBQUNDLE9BQU8sQ0FBQ0gsS0FBSyxDQUFDLEdBQUdBLEtBQUssR0FBRyxFQUFFO0lBQzlDLG9CQUNFLElBQUFqQixXQUFBLENBQUFxQixHQUFBO01BQUlDLFNBQVMsRUFBQyxZQUFZO01BQUFDLFFBQUEsZUFFeEIsSUFBQXZCLFdBQUEsQ0FBQXFCLEdBQUE7UUFBS0MsU0FBUyxFQUFDLGNBQWM7UUFBQUMsUUFBQSxFQUMxQmQsSUFBSSxDQUFDZSxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDQyxHQUFHLENBQUVDLENBQUMsaUJBQ3RCLElBQUExQixXQUFBLENBQUEyQixJQUFBO1VBQWNMLFNBQVMsRUFBQyxXQUFXO1VBQUFDLFFBQUEsR0FBQyxHQUFDLEVBQUNHLENBQUM7UUFBQSxHQUE1QkEsQ0FBbUMsQ0FDL0M7TUFBQyxDQUNDO0lBQUMsQ0FDSixDQUFDO0VBRVQ7RUFDQSxJQUFJVixHQUFHLEtBQUssU0FBUyxJQUFJQSxHQUFHLEtBQUssUUFBUSxFQUFFO0lBQ3pDLG9CQUFPLElBQUFoQixXQUFBLENBQUFxQixHQUFBO01BQUlDLFNBQVMsRUFBRSxjQUFjTixHQUFHLEVBQUc7TUFBQU8sUUFBQSxFQUFFLE9BQU9OLEtBQUssS0FBSyxRQUFRLEdBQUdBLEtBQUssR0FBRztJQUFJLENBQUssQ0FBQztFQUM1RjtFQUNBLG9CQUFPLElBQUFqQixXQUFBLENBQUFxQixHQUFBO0lBQUlDLFNBQVMsRUFBQyxZQUFZO0lBQUFDLFFBQUEsRUFBRSxPQUFPTixLQUFLLEtBQUssUUFBUSxHQUFHQSxLQUFLLEdBQUc7RUFBSSxDQUFLLENBQUM7QUFDbkY7QUFBQ1csRUFBQSxHQW5CUWQsSUFBSTtBQXFCYixTQUFTZSxHQUFHQSxDQUFDO0VBQUVkLEdBQUc7RUFBRWU7QUFBeUMsQ0FBQyxFQUFFO0VBQzlELE1BQU1DLEtBQUssR0FBRyxJQUFBQyxtQkFBUSxFQUFDakIsR0FBRyxDQUFDO0VBQzNCLG9CQUNFLElBQUFmLFdBQUEsQ0FBQTJCLElBQUE7SUFBSSxhQUFXWixHQUFHLENBQUNrQixJQUFLO0lBQUFWLFFBQUEsZ0JBQ3RCLElBQUF2QixXQUFBLENBQUFxQixHQUFBO01BQUlDLFNBQVMsRUFBQyxZQUFZO01BQUFDLFFBQUEsZUFJeEIsSUFBQXZCLFdBQUEsQ0FBQTJCLElBQUE7UUFBS0wsU0FBUyxFQUFDLGVBQWU7UUFBQUMsUUFBQSxnQkFDNUIsSUFBQXZCLFdBQUEsQ0FBQXFCLEdBQUE7VUFBTUMsU0FBUyxFQUFDLFlBQVk7VUFBQyxlQUFZLE1BQU07VUFBQUMsUUFBQSxlQUM3QyxJQUFBdkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDdkIsS0FBQSxDQUFBTyxPQUFJO1lBQUNFLElBQUksRUFBRVEsR0FBRyxDQUFDa0IsSUFBSSxLQUFLLEtBQUssR0FBRyxRQUFRLEdBQUc7VUFBTyxDQUFFO1FBQUMsQ0FDbEQsQ0FBQyxlQUNQLElBQUFqQyxXQUFBLENBQUEyQixJQUFBO1VBQU1MLFNBQVMsRUFBQyxjQUFjO1VBQUFDLFFBQUEsR0FDM0JSLEdBQUcsQ0FBQ21CLElBQUksZ0JBQ1AsSUFBQWxDLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQzVCLElBQUEsQ0FBQTBDLElBQUk7WUFBQ0QsSUFBSSxFQUFFbkIsR0FBRyxDQUFDbUIsSUFBSztZQUFDWixTQUFTLEVBQUMsWUFBWTtZQUFBQyxRQUFBLEVBQ3pDUTtVQUFLLENBQ0YsQ0FBQztVQUFBO1VBRVA7VUFDQTtVQUNBLElBQUEvQixXQUFBLENBQUFxQixHQUFBO1lBQU1DLFNBQVMsRUFBQyxhQUFhO1lBQUFDLFFBQUEsRUFBRVE7VUFBSyxDQUFPLENBQzVDLEVBQ0FBLEtBQUssS0FBS2hCLEdBQUcsQ0FBQ1IsSUFBSSxnQkFBRyxJQUFBUCxXQUFBLENBQUFxQixHQUFBO1lBQU1DLFNBQVMsRUFBQyxZQUFZO1lBQUFDLFFBQUEsRUFBRVIsR0FBRyxDQUFDUjtVQUFJLENBQU8sQ0FBQyxHQUFHLElBQUk7UUFBQSxDQUN2RSxDQUFDO01BQUEsQ0FDSjtJQUFDLENBQ0osQ0FBQyxFQUNKdUIsSUFBSSxDQUFDTixLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUNDLEdBQUcsQ0FBRVcsQ0FBQyxpQkFDbkIsSUFBQXBDLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ1AsSUFBSTtNQUFTQyxHQUFHLEVBQUVBLEdBQUk7TUFBQ0MsR0FBRyxFQUFFb0I7SUFBRSxHQUFwQkEsQ0FBc0IsQ0FDbEMsQ0FBQztFQUFBLENBQ0EsQ0FBQztBQUVUOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVhBQyxHQUFBLEdBakNTUixHQUFHO0FBNkNHLFNBQVNTLGFBQWFBLENBQUM7RUFBRUMsSUFBSTtFQUFFQyxLQUFLO0VBQUVDLE9BQU87RUFBRUMsSUFBSSxHQUFHLE1BQU07RUFBRUM7QUFBYyxDQUFDLEVBQUU7RUFBQTFDLEVBQUE7RUFDNUYsTUFBTTJDLEdBQUcsR0FBRyxJQUFBQyxpQkFBVSxFQUFDQyxvQ0FBaUIsQ0FBUTtFQUNoRCxNQUFNQyxRQUFRLEdBQUcsSUFBQUMseUJBQWdCLEVBQUNKLEdBQUcsRUFBRUssZUFBZSxFQUFFQyxXQUFXLElBQUksR0FBRyxDQUFDO0VBQzNFO0VBQ0E7RUFDQTtFQUNBLE1BQU1DLE9BQU8sR0FBRyxTQUFTLENBQUNDLElBQUksQ0FBQ0wsUUFBUSxDQUFDLEdBQUdBLFFBQVEsQ0FBQ3ZCLEtBQUssQ0FBQyxDQUFDLEVBQUV1QixRQUFRLENBQUNNLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHTixRQUFRO0VBQ2xHLE1BQU1PLE1BQU0sR0FBRyxJQUFBQyx3QkFBYSxFQUFDaEIsSUFBSSxFQUFFWSxPQUFPLENBQUM7RUFFM0MsTUFBTUssT0FBTyxHQUFHLElBQUFDLHdDQUFtQixFQUFDSCxNQUFNLENBQUM7RUFDM0MsTUFBTUksUUFBUSxHQUFHLElBQUFDLG1CQUFjLEVBQUMsQ0FBd0I7RUFFeEQsSUFBSUgsT0FBTyxDQUFDN0MsTUFBTSxLQUFLLE9BQU8sRUFBRTtJQUM5QixvQkFDRSxJQUFBWCxXQUFBLENBQUFxQixHQUFBO01BQUtDLFNBQVMsRUFBQyxlQUFlO01BQUMsY0FBWWtDLE9BQU8sQ0FBQzdDLE1BQU87TUFBQVksUUFBQSxlQUN4RCxJQUFBdkIsV0FBQSxDQUFBcUIsR0FBQTtRQUFLQyxTQUFTLEVBQUMsWUFBWTtRQUFDc0MsS0FBSyxFQUFFO1VBQUVDLEtBQUssRUFBRTtRQUFNO01BQUUsQ0FBRTtJQUFDLENBQ3BELENBQUM7RUFFVjtFQUVBLE1BQU1DLElBQUksR0FBRyxJQUFBQyw2QkFBa0IsRUFBQ1QsTUFBTSxFQUFFRSxPQUFPLENBQUNRLE9BQU8sRUFBRU4sUUFBUSxFQUFFO0lBQ2pFZixNQUFNLEVBQUUvQixJQUFJLENBQUMrQixNQUFNLENBQUM7SUFDcEJEO0VBQ0YsQ0FBQyxDQUFDO0VBQ0YsTUFBTVosSUFBSSxHQUFHLElBQUFtQyx5QkFBYyxFQUFDSCxJQUFJLEVBQUUsSUFBQUksdUJBQVksRUFBQ3pCLE9BQU8sQ0FBQyxDQUFDO0VBRXhELG9CQUNFLElBQUF6QyxXQUFBLENBQUEyQixJQUFBO0lBQUtMLFNBQVMsRUFBQyxlQUFlO0lBQUFDLFFBQUEsR0FDM0JpQixLQUFLLGdCQUNKLElBQUF4QyxXQUFBLENBQUEyQixJQUFBO01BQUtMLFNBQVMsRUFBQyxxQkFBcUI7TUFBQUMsUUFBQSxnQkFDbEMsSUFBQXZCLFdBQUEsQ0FBQXFCLEdBQUE7UUFBQUUsUUFBQSxFQUFLaUI7TUFBSyxDQUFLLENBQUMsZUFDaEIsSUFBQXhDLFdBQUEsQ0FBQTJCLElBQUE7UUFBTUwsU0FBUyxFQUFDLEdBQUc7UUFBQUMsUUFBQSxHQUNoQnVDLElBQUksQ0FBQ0ssTUFBTSxFQUFDLEdBQUMsRUFBQ0wsSUFBSSxDQUFDSyxNQUFNLEtBQUssQ0FBQyxHQUFHLE1BQU0sR0FBRyxPQUFPO01BQUEsQ0FDL0MsQ0FBQztJQUFBLENBQ0osQ0FBQyxHQUNKLElBQUksRUFDUEwsSUFBSSxDQUFDSyxNQUFNLEtBQUssQ0FBQztJQUFBO0lBQ2hCO0lBQ0E7SUFDQTtJQUNBO0lBQ0EsSUFBQW5FLFdBQUEsQ0FBQTJCLElBQUE7TUFBS0wsU0FBUyxFQUFDLHNCQUFzQjtNQUFBQyxRQUFBLGdCQUNuQyxJQUFBdkIsV0FBQSxDQUFBcUIsR0FBQTtRQUFNQyxTQUFTLEVBQUMsWUFBWTtRQUFDLGVBQVksTUFBTTtRQUFBQyxRQUFBLGVBQzdDLElBQUF2QixXQUFBLENBQUFxQixHQUFBLEVBQUN2QixLQUFBLENBQUFPLE9BQUk7VUFBQ0UsSUFBSSxFQUFDO1FBQVEsQ0FBRTtNQUFDLENBQ2xCLENBQUMsZUFDUCxJQUFBUCxXQUFBLENBQUFxQixHQUFBO1FBQUdDLFNBQVMsRUFBQyx3QkFBd0I7UUFBQUMsUUFBQSxFQUNsQ2lDLE9BQU8sQ0FBQ1EsT0FBTyxDQUFDRyxNQUFNLEtBQUssQ0FBQyxHQUFHLHVCQUF1QixHQUFHO01BQWlDLENBQzFGLENBQUMsZUFDSixJQUFBbkUsV0FBQSxDQUFBcUIsR0FBQTtRQUFHQyxTQUFTLEVBQUMsd0JBQXdCO1FBQUFDLFFBQUEsRUFDbENpQyxPQUFPLENBQUNRLE9BQU8sQ0FBQ0csTUFBTSxLQUFLLENBQUMsR0FDekIsMkNBQTJDLEdBQzNDLDZDQUE2Q1gsT0FBTyxDQUFDUSxPQUFPLENBQUNHLE1BQU0sSUFBSVgsT0FBTyxDQUFDUSxPQUFPLENBQUNHLE1BQU0sS0FBSyxDQUFDLEdBQUcsTUFBTSxHQUFHLE9BQU87TUFBVyxDQUNwSSxDQUFDO0lBQUEsQ0FDRCxDQUFDLGdCQUVOLElBQUFuRSxXQUFBLENBQUFxQixHQUFBO01BQUtDLFNBQVMsRUFBQyxrQkFBa0I7TUFBQUMsUUFBQSxlQUMvQixJQUFBdkIsV0FBQSxDQUFBMkIsSUFBQTtRQUFPTCxTQUFTLEVBQUMsa0NBQWtDO1FBQUFDLFFBQUEsZ0JBQ2pELElBQUF2QixXQUFBLENBQUFxQixHQUFBO1VBQUFFLFFBQUEsZUFDRSxJQUFBdkIsV0FBQSxDQUFBcUIsR0FBQTtZQUFBRSxRQUFBLEVBQ0dPLElBQUksQ0FBQ0wsR0FBRyxDQUFFVyxDQUFDLGlCQUNWLElBQUFwQyxXQUFBLENBQUFxQixHQUFBO2NBQVkrQyxLQUFLLEVBQUMsS0FBSztjQUFDOUMsU0FBUyxFQUFFLHNCQUFzQmMsQ0FBQyxFQUFHO2NBQUFiLFFBQUEsRUFDMURqQixRQUFRLENBQUM4QixDQUFDO1lBQUMsR0FETEEsQ0FFTCxDQUNMO1VBQUMsQ0FDQTtRQUFDLENBQ0EsQ0FBQyxlQUNSLElBQUFwQyxXQUFBLENBQUFxQixHQUFBO1VBQUFFLFFBQUEsRUFDR3VDLElBQUksQ0FBQ3JDLEdBQUcsQ0FBRTRDLENBQUMsaUJBQ1YsSUFBQXJFLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ1EsR0FBRztZQUFhZCxHQUFHLEVBQUVzRCxDQUFFO1lBQUN2QyxJQUFJLEVBQUVBO1VBQUssR0FBMUJ1QyxDQUFDLENBQUNDLEdBQTBCLENBQ3ZDO1FBQUMsQ0FDRyxDQUFDO01BQUEsQ0FDSDtJQUFDLENBQ0wsQ0FDTjtFQUFBLENBQ0UsQ0FBQztBQUVWO0FBQUNyRSxFQUFBLENBNUV1QnFDLGFBQWE7RUFBQSxRQVNuQm1CLHdDQUFtQixFQUNsQkUsbUJBQWM7QUFBQTtBQUFBWSxHQUFBLEdBVlRqQyxhQUFhO0FBQUEsSUFBQVYsRUFBQSxFQUFBUyxHQUFBLEVBQUFrQyxHQUFBO0FBQUFDLFlBQUEsQ0FBQTVDLEVBQUE7QUFBQTRDLFlBQUEsQ0FBQW5DLEdBQUE7QUFBQW1DLFlBQUEsQ0FBQUQsR0FBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}