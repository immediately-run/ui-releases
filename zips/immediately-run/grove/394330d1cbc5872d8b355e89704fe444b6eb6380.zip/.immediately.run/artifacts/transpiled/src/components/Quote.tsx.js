var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Quote;
var _WikiLink = _interopRequireDefault(require("./WikiLink"));
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// Import-free engine component: a pull-quote with a gradient accent spine and a
// large gradient opening quote mark. `cite` is the attribution (Space Mono);
// `source`, when given, links to the entry the quote came from — its
// resolved / broken / self state is decided by the shared <WikiLink> resolver, so
// a moved or missing target reads as broken rather than a dead link (no
// hand-rolled href logic here, just the wiki path → in-app href normalization).
function Quote({
  cite,
  source,
  children
}) {
  const href = source ? source.startsWith('/') ? source : `/${source}` : null;
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("figure", {
    className: "grove-quote",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("blockquote", {
      className: "grove-quote__body",
      children: children
    }), (cite || href) && /*#__PURE__*/(0, _jsxRuntime.jsxs)("figcaption", {
      className: "grove-quote__cap",
      children: [cite ? /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        className: "grove-quote__cite",
        children: cite
      }) : null, href ? /*#__PURE__*/(0, _jsxRuntime.jsx)(_WikiLink.default, {
        href: href,
        className: "grove-quote__src",
        children: "Source \u2192"
      }) : null]
    })]
  });
}
_c = Quote;
var _c;
$RefreshReg$(_c, "Quote");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfV2lraUxpbmsiLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwicmVxdWlyZSIsIl9qc3hSdW50aW1lIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiUXVvdGUiLCJjaXRlIiwic291cmNlIiwiY2hpbGRyZW4iLCJocmVmIiwic3RhcnRzV2l0aCIsImpzeHMiLCJjbGFzc05hbWUiLCJqc3giLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlF1b3RlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IFJlYWN0Tm9kZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCBXaWtpTGluayBmcm9tICcuL1dpa2lMaW5rJztcblxuaW50ZXJmYWNlIFByb3BzIHtcbiAgLyoqIEF0dHJpYnV0aW9uIOKAlCBhIHBlcnNvbiwgcm9sZSwgb3IgZG9jdW1lbnQuIFJlbmRlcmVkIGluIG1vbm8gYXMgXCLigJQgY2l0ZVwiLiAqL1xuICBjaXRlPzogc3RyaW5nO1xuICAvKiogV2lraSBwYXRoIG9mIHRoZSBlbnRyeSB0aGUgcXVvdGUgaXMgZHJhd24gZnJvbSwgZS5nLlxuICAgKiAgXCJjb250ZW50L2hhbmRib29rL29uYm9hcmRpbmcubWR4XCIuIFdoZW4gc2V0LCBhIFwiU291cmNlIOKGklwiIGxpbmsgaXMgc2hvd24uICovXG4gIHNvdXJjZT86IHN0cmluZztcbiAgY2hpbGRyZW4/OiBSZWFjdE5vZGU7XG59XG5cbi8vIEltcG9ydC1mcmVlIGVuZ2luZSBjb21wb25lbnQ6IGEgcHVsbC1xdW90ZSB3aXRoIGEgZ3JhZGllbnQgYWNjZW50IHNwaW5lIGFuZCBhXG4vLyBsYXJnZSBncmFkaWVudCBvcGVuaW5nIHF1b3RlIG1hcmsuIGBjaXRlYCBpcyB0aGUgYXR0cmlidXRpb24gKFNwYWNlIE1vbm8pO1xuLy8gYHNvdXJjZWAsIHdoZW4gZ2l2ZW4sIGxpbmtzIHRvIHRoZSBlbnRyeSB0aGUgcXVvdGUgY2FtZSBmcm9tIOKAlCBpdHNcbi8vIHJlc29sdmVkIC8gYnJva2VuIC8gc2VsZiBzdGF0ZSBpcyBkZWNpZGVkIGJ5IHRoZSBzaGFyZWQgPFdpa2lMaW5rPiByZXNvbHZlciwgc29cbi8vIGEgbW92ZWQgb3IgbWlzc2luZyB0YXJnZXQgcmVhZHMgYXMgYnJva2VuIHJhdGhlciB0aGFuIGEgZGVhZCBsaW5rIChub1xuLy8gaGFuZC1yb2xsZWQgaHJlZiBsb2dpYyBoZXJlLCBqdXN0IHRoZSB3aWtpIHBhdGgg4oaSIGluLWFwcCBocmVmIG5vcm1hbGl6YXRpb24pLlxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUXVvdGUoeyBjaXRlLCBzb3VyY2UsIGNoaWxkcmVuIH06IFByb3BzKSB7XG4gIGNvbnN0IGhyZWYgPSBzb3VyY2UgPyAoc291cmNlLnN0YXJ0c1dpdGgoJy8nKSA/IHNvdXJjZSA6IGAvJHtzb3VyY2V9YCkgOiBudWxsO1xuICByZXR1cm4gKFxuICAgIDxmaWd1cmUgY2xhc3NOYW1lPVwiZ3JvdmUtcXVvdGVcIj5cbiAgICAgIDxibG9ja3F1b3RlIGNsYXNzTmFtZT1cImdyb3ZlLXF1b3RlX19ib2R5XCI+e2NoaWxkcmVufTwvYmxvY2txdW90ZT5cbiAgICAgIHsoY2l0ZSB8fCBocmVmKSAmJiAoXG4gICAgICAgIDxmaWdjYXB0aW9uIGNsYXNzTmFtZT1cImdyb3ZlLXF1b3RlX19jYXBcIj5cbiAgICAgICAgICB7Y2l0ZSA/IDxzcGFuIGNsYXNzTmFtZT1cImdyb3ZlLXF1b3RlX19jaXRlXCI+e2NpdGV9PC9zcGFuPiA6IG51bGx9XG4gICAgICAgICAge2hyZWYgPyAoXG4gICAgICAgICAgICA8V2lraUxpbmsgaHJlZj17aHJlZn0gY2xhc3NOYW1lPVwiZ3JvdmUtcXVvdGVfX3NyY1wiPlxuICAgICAgICAgICAgICBTb3VyY2Ug4oaSXG4gICAgICAgICAgICA8L1dpa2lMaW5rPlxuICAgICAgICAgICkgOiBudWxsfVxuICAgICAgICA8L2ZpZ2NhcHRpb24+XG4gICAgICApfVxuICAgIDwvZmlndXJlPlxuICApO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFDQSxJQUFBQSxTQUFBLEdBQUFDLHNCQUFBLENBQUFDLE9BQUE7QUFBa0MsSUFBQUMsV0FBQSxHQUFBRCxPQUFBO0FBQUEsU0FBQUQsdUJBQUFHLENBQUEsV0FBQUEsQ0FBQSxJQUFBQSxDQUFBLENBQUFDLFVBQUEsR0FBQUQsQ0FBQSxLQUFBRSxPQUFBLEVBQUFGLENBQUE7QUFXbEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ2UsU0FBU0csS0FBS0EsQ0FBQztFQUFFQyxJQUFJO0VBQUVDLE1BQU07RUFBRUM7QUFBZ0IsQ0FBQyxFQUFFO0VBQy9ELE1BQU1DLElBQUksR0FBR0YsTUFBTSxHQUFJQSxNQUFNLENBQUNHLFVBQVUsQ0FBQyxHQUFHLENBQUMsR0FBR0gsTUFBTSxHQUFHLElBQUlBLE1BQU0sRUFBRSxHQUFJLElBQUk7RUFDN0Usb0JBQ0UsSUFBQU4sV0FBQSxDQUFBVSxJQUFBO0lBQVFDLFNBQVMsRUFBQyxhQUFhO0lBQUFKLFFBQUEsZ0JBQzdCLElBQUFQLFdBQUEsQ0FBQVksR0FBQTtNQUFZRCxTQUFTLEVBQUMsbUJBQW1CO01BQUFKLFFBQUEsRUFBRUE7SUFBUSxDQUFhLENBQUMsRUFDaEUsQ0FBQ0YsSUFBSSxJQUFJRyxJQUFJLGtCQUNaLElBQUFSLFdBQUEsQ0FBQVUsSUFBQTtNQUFZQyxTQUFTLEVBQUMsa0JBQWtCO01BQUFKLFFBQUEsR0FDckNGLElBQUksZ0JBQUcsSUFBQUwsV0FBQSxDQUFBWSxHQUFBO1FBQU1ELFNBQVMsRUFBQyxtQkFBbUI7UUFBQUosUUFBQSxFQUFFRjtNQUFJLENBQU8sQ0FBQyxHQUFHLElBQUksRUFDL0RHLElBQUksZ0JBQ0gsSUFBQVIsV0FBQSxDQUFBWSxHQUFBLEVBQUNmLFNBQUEsQ0FBQU0sT0FBUTtRQUFDSyxJQUFJLEVBQUVBLElBQUs7UUFBQ0csU0FBUyxFQUFDLGtCQUFrQjtRQUFBSixRQUFBLEVBQUM7TUFFbkQsQ0FBVSxDQUFDLEdBQ1QsSUFBSTtJQUFBLENBQ0UsQ0FDYjtFQUFBLENBQ0ssQ0FBQztBQUViO0FBQUNNLEVBQUEsR0FqQnVCVCxLQUFLO0FBQUEsSUFBQVMsRUFBQTtBQUFBQyxZQUFBLENBQUFELEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}