var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = ThemeAssets;
var _react = require("react");
var _themeAssets = require("../lib/themeAssets");
var _sdk = require("@immediately-run/sdk");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The engine-owned emission of a declaration set's minted assets (R3-315): one
// `<style data-grove-theme-assets>` carrying the `@font-face` rules inside the
// ENGINE cascade layer and the `--asset-*` assignments on `.grove-root`. The
// revoke scope is the declaration set's lifetime — switching themes (or a reader
// override re-resolving the set) revokes the outgoing URLs before the incoming
// ones mint, so repeated switches leak nothing.
//
// Nothing here is content-styleable: the layer order in `index.css` namespaces
// these rules as `grove.engine`, below the reset but above theme and content.
/** The declaring-file anchor for the engine's own default set — the app repo root
 *  (fork AND dispatch load the engine from this repo; `/app` is its own tree). */
const ENGINE_DECLARING_FILE = '/app/src/index.css';

// The whole sandbox fs, `/`-rooted — the same anchor `AssetImage`/`EntryImage` use.
const ROOT_MOUNT = {
  path: '/',
  type: 'repo'
};
function ThemeAssets({
  declarations,
  basePath = ENGINE_DECLARING_FILE
}) {
  _s();
  const [minted, setMinted] = (0, _react.useState)(null);
  // The CURRENT set, reached from the cleanup — a setState updater does NOT run
  // on unmount (React 18+), so reaching the outgoing URLs only through state
  // would leak them exactly there.
  const mintedRef = (0, _react.useRef)(null);
  (0, _react.useEffect)(() => {
    let alive = true;
    // Read through the SDK's fs surface (the same one `MountImage` reads
    // through): it resolves the sandbox's injected shared fs in every stance,
    // where a bare `import fs` would only work where the bundler shims it.
    const rootFs = (0, _sdk.openFs)(ROOT_MOUNT);
    void (0, _themeAssets.mintThemeAssets)(declarations, basePath, async p => {
      const bytes = await rootFs.readFile(p.replace(/^\/+/, ''));
      return typeof bytes === 'string' ? new TextEncoder().encode(bytes) : new Uint8Array(bytes);
    }).then(m => {
      if (!alive) {
        m.revoke(); // the set changed/unmounted mid-mint — never leak the late arrival
        return;
      }
      mintedRef.current = m;
      setMinted(m);
    });
    return () => {
      alive = false;
      // Revoke the OUTGOING set on switch/unmount — the theme's lifetime ends here.
      mintedRef.current?.revoke();
      mintedRef.current = null;
      setMinted(null);
    };
  }, [declarations, basePath]);
  if (!minted || !minted.fontFaceCss && !minted.assetVarsCss) return null;
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("style", {
    "data-grove-theme-assets": "",
    children: `@layer grove.engine{${minted.fontFaceCss}}\n${minted.assetVarsCss}`
  });
}
_s(ThemeAssets, "0+mjLfPgl2Uvh1Fs+n/8i/YbjTU=");
_c = ThemeAssets;
var _c;
$RefreshReg$(_c, "ThemeAssets");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3RoZW1lQXNzZXRzIiwiX3NkayIsIl9qc3hSdW50aW1lIiwiX3MiLCIkUmVmcmVzaFNpZyQiLCJFTkdJTkVfREVDTEFSSU5HX0ZJTEUiLCJST09UX01PVU5UIiwicGF0aCIsInR5cGUiLCJUaGVtZUFzc2V0cyIsImRlY2xhcmF0aW9ucyIsImJhc2VQYXRoIiwibWludGVkIiwic2V0TWludGVkIiwidXNlU3RhdGUiLCJtaW50ZWRSZWYiLCJ1c2VSZWYiLCJ1c2VFZmZlY3QiLCJhbGl2ZSIsInJvb3RGcyIsIm9wZW5GcyIsIm1pbnRUaGVtZUFzc2V0cyIsInAiLCJieXRlcyIsInJlYWRGaWxlIiwicmVwbGFjZSIsIlRleHRFbmNvZGVyIiwiZW5jb2RlIiwiVWludDhBcnJheSIsInRoZW4iLCJtIiwicmV2b2tlIiwiY3VycmVudCIsImZvbnRGYWNlQ3NzIiwiYXNzZXRWYXJzQ3NzIiwianN4IiwiY2hpbGRyZW4iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlRoZW1lQXNzZXRzLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBtaW50VGhlbWVBc3NldHMsIHR5cGUgTWludGVkVGhlbWVBc3NldHMsIHR5cGUgVGhlbWVBc3NldERlY2xhcmF0aW9ucyB9IGZyb20gJy4uL2xpYi90aGVtZUFzc2V0cyc7XG5pbXBvcnQgeyBvcGVuRnMgfSBmcm9tICdAaW1tZWRpYXRlbHktcnVuL3Nkayc7XG5cbi8vIFRoZSBlbmdpbmUtb3duZWQgZW1pc3Npb24gb2YgYSBkZWNsYXJhdGlvbiBzZXQncyBtaW50ZWQgYXNzZXRzIChSMy0zMTUpOiBvbmVcbi8vIGA8c3R5bGUgZGF0YS1ncm92ZS10aGVtZS1hc3NldHM+YCBjYXJyeWluZyB0aGUgYEBmb250LWZhY2VgIHJ1bGVzIGluc2lkZSB0aGVcbi8vIEVOR0lORSBjYXNjYWRlIGxheWVyIGFuZCB0aGUgYC0tYXNzZXQtKmAgYXNzaWdubWVudHMgb24gYC5ncm92ZS1yb290YC4gVGhlXG4vLyByZXZva2Ugc2NvcGUgaXMgdGhlIGRlY2xhcmF0aW9uIHNldCdzIGxpZmV0aW1lIOKAlCBzd2l0Y2hpbmcgdGhlbWVzIChvciBhIHJlYWRlclxuLy8gb3ZlcnJpZGUgcmUtcmVzb2x2aW5nIHRoZSBzZXQpIHJldm9rZXMgdGhlIG91dGdvaW5nIFVSTHMgYmVmb3JlIHRoZSBpbmNvbWluZ1xuLy8gb25lcyBtaW50LCBzbyByZXBlYXRlZCBzd2l0Y2hlcyBsZWFrIG5vdGhpbmcuXG4vL1xuLy8gTm90aGluZyBoZXJlIGlzIGNvbnRlbnQtc3R5bGVhYmxlOiB0aGUgbGF5ZXIgb3JkZXIgaW4gYGluZGV4LmNzc2AgbmFtZXNwYWNlc1xuLy8gdGhlc2UgcnVsZXMgYXMgYGdyb3ZlLmVuZ2luZWAsIGJlbG93IHRoZSByZXNldCBidXQgYWJvdmUgdGhlbWUgYW5kIGNvbnRlbnQuXG5cbi8qKiBUaGUgZGVjbGFyaW5nLWZpbGUgYW5jaG9yIGZvciB0aGUgZW5naW5lJ3Mgb3duIGRlZmF1bHQgc2V0IOKAlCB0aGUgYXBwIHJlcG8gcm9vdFxuICogIChmb3JrIEFORCBkaXNwYXRjaCBsb2FkIHRoZSBlbmdpbmUgZnJvbSB0aGlzIHJlcG87IGAvYXBwYCBpcyBpdHMgb3duIHRyZWUpLiAqL1xuY29uc3QgRU5HSU5FX0RFQ0xBUklOR19GSUxFID0gJy9hcHAvc3JjL2luZGV4LmNzcyc7XG5cbi8vIFRoZSB3aG9sZSBzYW5kYm94IGZzLCBgL2Atcm9vdGVkIOKAlCB0aGUgc2FtZSBhbmNob3IgYEFzc2V0SW1hZ2VgL2BFbnRyeUltYWdlYCB1c2UuXG5jb25zdCBST09UX01PVU5UID0geyBwYXRoOiAnLycsIHR5cGU6ICdyZXBvJyB9IGFzIGNvbnN0O1xuXG5pbnRlcmZhY2UgUHJvcHMge1xuICBkZWNsYXJhdGlvbnM6IFRoZW1lQXNzZXREZWNsYXJhdGlvbnM7XG4gIC8qKiBBYnNvbHV0ZSBmcyBwYXRoIG9mIHRoZSBmaWxlIHRoZSBkZWNsYXJhdGlvbnMgbGl2ZSBpbiAocmVzb2x1dGlvbiBiYXNlKS4gKi9cbiAgYmFzZVBhdGg/OiBzdHJpbmc7XG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFRoZW1lQXNzZXRzKHsgZGVjbGFyYXRpb25zLCBiYXNlUGF0aCA9IEVOR0lORV9ERUNMQVJJTkdfRklMRSB9OiBQcm9wcykge1xuICBjb25zdCBbbWludGVkLCBzZXRNaW50ZWRdID0gdXNlU3RhdGU8TWludGVkVGhlbWVBc3NldHMgfCBudWxsPihudWxsKTtcbiAgLy8gVGhlIENVUlJFTlQgc2V0LCByZWFjaGVkIGZyb20gdGhlIGNsZWFudXAg4oCUIGEgc2V0U3RhdGUgdXBkYXRlciBkb2VzIE5PVCBydW5cbiAgLy8gb24gdW5tb3VudCAoUmVhY3QgMTgrKSwgc28gcmVhY2hpbmcgdGhlIG91dGdvaW5nIFVSTHMgb25seSB0aHJvdWdoIHN0YXRlXG4gIC8vIHdvdWxkIGxlYWsgdGhlbSBleGFjdGx5IHRoZXJlLlxuICBjb25zdCBtaW50ZWRSZWYgPSB1c2VSZWY8TWludGVkVGhlbWVBc3NldHMgfCBudWxsPihudWxsKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGxldCBhbGl2ZSA9IHRydWU7XG4gICAgLy8gUmVhZCB0aHJvdWdoIHRoZSBTREsncyBmcyBzdXJmYWNlICh0aGUgc2FtZSBvbmUgYE1vdW50SW1hZ2VgIHJlYWRzXG4gICAgLy8gdGhyb3VnaCk6IGl0IHJlc29sdmVzIHRoZSBzYW5kYm94J3MgaW5qZWN0ZWQgc2hhcmVkIGZzIGluIGV2ZXJ5IHN0YW5jZSxcbiAgICAvLyB3aGVyZSBhIGJhcmUgYGltcG9ydCBmc2Agd291bGQgb25seSB3b3JrIHdoZXJlIHRoZSBidW5kbGVyIHNoaW1zIGl0LlxuICAgIGNvbnN0IHJvb3RGcyA9IG9wZW5GcyhST09UX01PVU5UKTtcbiAgICB2b2lkIG1pbnRUaGVtZUFzc2V0cyhkZWNsYXJhdGlvbnMsIGJhc2VQYXRoLCBhc3luYyAocCkgPT4ge1xuICAgICAgY29uc3QgYnl0ZXMgPSBhd2FpdCByb290RnMucmVhZEZpbGUocC5yZXBsYWNlKC9eXFwvKy8sICcnKSk7XG4gICAgICByZXR1cm4gdHlwZW9mIGJ5dGVzID09PSAnc3RyaW5nJyA/IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShieXRlcykgOiBuZXcgVWludDhBcnJheShieXRlcyk7XG4gICAgfSkudGhlbigobSkgPT4ge1xuICAgICAgaWYgKCFhbGl2ZSkge1xuICAgICAgICBtLnJldm9rZSgpOyAvLyB0aGUgc2V0IGNoYW5nZWQvdW5tb3VudGVkIG1pZC1taW50IOKAlCBuZXZlciBsZWFrIHRoZSBsYXRlIGFycml2YWxcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgbWludGVkUmVmLmN1cnJlbnQgPSBtO1xuICAgICAgc2V0TWludGVkKG0pO1xuICAgIH0pO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBhbGl2ZSA9IGZhbHNlO1xuICAgICAgLy8gUmV2b2tlIHRoZSBPVVRHT0lORyBzZXQgb24gc3dpdGNoL3VubW91bnQg4oCUIHRoZSB0aGVtZSdzIGxpZmV0aW1lIGVuZHMgaGVyZS5cbiAgICAgIG1pbnRlZFJlZi5jdXJyZW50Py5yZXZva2UoKTtcbiAgICAgIG1pbnRlZFJlZi5jdXJyZW50ID0gbnVsbDtcbiAgICAgIHNldE1pbnRlZChudWxsKTtcbiAgICB9O1xuICB9LCBbZGVjbGFyYXRpb25zLCBiYXNlUGF0aF0pO1xuXG4gIGlmICghbWludGVkIHx8ICghbWludGVkLmZvbnRGYWNlQ3NzICYmICFtaW50ZWQuYXNzZXRWYXJzQ3NzKSkgcmV0dXJuIG51bGw7XG4gIHJldHVybiA8c3R5bGUgZGF0YS1ncm92ZS10aGVtZS1hc3NldHM9XCJcIj57YEBsYXllciBncm92ZS5lbmdpbmV7JHttaW50ZWQuZm9udEZhY2VDc3N9fVxcbiR7bWludGVkLmFzc2V0VmFyc0Nzc31gfTwvc3R5bGU+O1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFBQSxJQUFBQSxNQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxZQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxJQUFBLEdBQUFGLE9BQUE7QUFBOEMsSUFBQUcsV0FBQSxHQUFBSCxPQUFBO0FBQUEsSUFBQUksRUFBQSxHQUFBQyxZQUFBLElBRTlDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQSxNQUFNQyxxQkFBcUIsR0FBRyxvQkFBb0I7O0FBRWxEO0FBQ0EsTUFBTUMsVUFBVSxHQUFHO0VBQUVDLElBQUksRUFBRSxHQUFHO0VBQUVDLElBQUksRUFBRTtBQUFPLENBQVU7QUFReEMsU0FBU0MsV0FBV0EsQ0FBQztFQUFFQyxZQUFZO0VBQUVDLFFBQVEsR0FBR047QUFBNkIsQ0FBQyxFQUFFO0VBQUFGLEVBQUE7RUFDN0YsTUFBTSxDQUFDUyxNQUFNLEVBQUVDLFNBQVMsQ0FBQyxHQUFHLElBQUFDLGVBQVEsRUFBMkIsSUFBSSxDQUFDO0VBQ3BFO0VBQ0E7RUFDQTtFQUNBLE1BQU1DLFNBQVMsR0FBRyxJQUFBQyxhQUFNLEVBQTJCLElBQUksQ0FBQztFQUV4RCxJQUFBQyxnQkFBUyxFQUFDLE1BQU07SUFDZCxJQUFJQyxLQUFLLEdBQUcsSUFBSTtJQUNoQjtJQUNBO0lBQ0E7SUFDQSxNQUFNQyxNQUFNLEdBQUcsSUFBQUMsV0FBTSxFQUFDZCxVQUFVLENBQUM7SUFDakMsS0FBSyxJQUFBZSw0QkFBZSxFQUFDWCxZQUFZLEVBQUVDLFFBQVEsRUFBRSxNQUFPVyxDQUFDLElBQUs7TUFDeEQsTUFBTUMsS0FBSyxHQUFHLE1BQU1KLE1BQU0sQ0FBQ0ssUUFBUSxDQUFDRixDQUFDLENBQUNHLE9BQU8sQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLENBQUM7TUFDMUQsT0FBTyxPQUFPRixLQUFLLEtBQUssUUFBUSxHQUFHLElBQUlHLFdBQVcsQ0FBQyxDQUFDLENBQUNDLE1BQU0sQ0FBQ0osS0FBSyxDQUFDLEdBQUcsSUFBSUssVUFBVSxDQUFDTCxLQUFLLENBQUM7SUFDNUYsQ0FBQyxDQUFDLENBQUNNLElBQUksQ0FBRUMsQ0FBQyxJQUFLO01BQ2IsSUFBSSxDQUFDWixLQUFLLEVBQUU7UUFDVlksQ0FBQyxDQUFDQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDWjtNQUNGO01BQ0FoQixTQUFTLENBQUNpQixPQUFPLEdBQUdGLENBQUM7TUFDckJqQixTQUFTLENBQUNpQixDQUFDLENBQUM7SUFDZCxDQUFDLENBQUM7SUFDRixPQUFPLE1BQU07TUFDWFosS0FBSyxHQUFHLEtBQUs7TUFDYjtNQUNBSCxTQUFTLENBQUNpQixPQUFPLEVBQUVELE1BQU0sQ0FBQyxDQUFDO01BQzNCaEIsU0FBUyxDQUFDaUIsT0FBTyxHQUFHLElBQUk7TUFDeEJuQixTQUFTLENBQUMsSUFBSSxDQUFDO0lBQ2pCLENBQUM7RUFDSCxDQUFDLEVBQUUsQ0FBQ0gsWUFBWSxFQUFFQyxRQUFRLENBQUMsQ0FBQztFQUU1QixJQUFJLENBQUNDLE1BQU0sSUFBSyxDQUFDQSxNQUFNLENBQUNxQixXQUFXLElBQUksQ0FBQ3JCLE1BQU0sQ0FBQ3NCLFlBQWEsRUFBRSxPQUFPLElBQUk7RUFDekUsb0JBQU8sSUFBQWhDLFdBQUEsQ0FBQWlDLEdBQUE7SUFBTywyQkFBd0IsRUFBRTtJQUFBQyxRQUFBLEVBQUUsdUJBQXVCeEIsTUFBTSxDQUFDcUIsV0FBVyxNQUFNckIsTUFBTSxDQUFDc0IsWUFBWTtFQUFFLENBQVEsQ0FBQztBQUN6SDtBQUFDL0IsRUFBQSxDQW5DdUJNLFdBQVc7QUFBQTRCLEVBQUEsR0FBWDVCLFdBQVc7QUFBQSxJQUFBNEIsRUFBQTtBQUFBQyxZQUFBLENBQUFELEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}