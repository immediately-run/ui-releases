var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.for-each.js");
var _vitest = require("vitest");
var _react = require("react");
var _client = require("react-dom/client");
var _jsxRuntime = require("react/jsx-runtime");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; } // @vitest-environment jsdom
// G-GA-1 / G-GA-2 — the surface itself: with `writable=false` and no provider, the
// DOM contains no write-flavored chip and no "proposes the edit"/"host confirms"
// copy; with `writable=false` but a configured, granted provider, Q&A is fully
// enabled (read-only NEVER blocks asking — R-GA-5). Provider/grant state is driven
// through the SDK's REAL push channels (an emitting stub transport), not mocks of
// the hooks — the component reads what the host would have said.
// `useHeadings` scans the DOM (no .grove-prose in this harness ⇒ no headings — fine).
// `fs` is read only through safeSources on the stuffing path, never in these cases.
_vitest.vi.mock('fs', () => ({
  default: {
    promises: {
      readFile: _vitest.vi.fn(async () => '')
    }
  }
}));

// runAgent is controllable for the stop-abort case (R3-608); everything else in
// the barrel stays real — the existing cases never invoke it.
const runAgentMock = _vitest.vi.fn();
_vitest.vi.mock('@immediately-run/sdk', async importOriginal => ({
  ...(await importOriginal()),
  runAgent: opts => runAgentMock(opts)
}));

// The transport stub, the renderer and the push driver live in
// `src/test/groveAgentHarness.tsx` — shared rather than copied, because
// `GroveAgent.unanswered.test.tsx` needs the same harness in a module registry where the
// catalog has never been answered (grove#75 round 3).
const {
  renderAgent,
  openPanel,
  push,
  protocolRequest
} = await Promise.resolve().then(() => _interopRequireWildcard(require('../../test/groveAgentHarness')));

// NOTE: no per-test handler reset. The SDK's push channels are module-global and
// subscribe to the transport exactly once (the `started` flag in `createPushChannel`),
// so clearing the handler set would sever every later emit from the channels. Each
// test drives the FULL desired host state through its own pushes instead.

(0, _vitest.describe)('G-GA-1 — no unbacked capability claims in the DOM', () => {
  (0, _vitest.it)('writable=false + no provider: no write-flavored chip, no phantom-write copy', async () => {
    const {
      container
    } = await renderAgent({
      writable: false
    });
    // The host generation this models matters, because the two pushes below only make
    // sense together on ONE of them. R-LLM-2 says a frame lacking `llm:chat` is answered
    // `{ provider: null }` — the SAME payload as a granted frame with no key — so on a
    // host that predates R3-688's `ungranted` mark this pair (null provider, empty
    // catalog) is exactly what an ungranted fork sees, and it is indistinguishable at the
    // provider channel from keyless-but-granted. That indistinguishability IS R3-688.
    // A 0.72.0 host would instead mark the answer, which the R3-688 case below covers.
    await push({
      type: 'llm-provider',
      provider: null
    }); // pre-mark host: null either way
    await push({
      type: 'api-catalog',
      methods: []
    }); // nothing granted — the deciding fact
    await openPanel(container);
    const text = container.textContent ?? '';
    (0, _vitest.expect)(text).not.toMatch(/add an entry|fix broken links|reorganize the sidebar|add a timeline/i);
    (0, _vitest.expect)(text).not.toMatch(/proposes the edit|host confirms the write/i);
    (0, _vitest.expect)(container.querySelectorAll('.ga-chip').length).toBe(0); // no ✓ rows ⇒ no chips
    // And the honest causes ARE there. R3-688 CHANGED which one this case gets, and the
    // change is the point of the item. On a pre-mark host the provider channel cannot
    // tell keyless from ungranted, so the CATALOG is the only fact that discriminates —
    // and it says not granted. The old order asked not-configured first and therefore
    // told a user who may well have a key to go add one, which cannot unblock them.
    // The key cause is still rendered for a frame the catalog says IS granted
    // (`reachCard.test.ts` — "not-configured names the KEY cause").
    (0, _vitest.expect)(text).toContain("wasn't granted chat");
    (0, _vitest.expect)(text).not.toContain('no model key connected');
    (0, _vitest.expect)(text).toContain('you’re a reader here');
  });
});
(0, _vitest.describe)('G-GA-2 / R-GA-5 — read-only never blocks Q&A', () => {
  (0, _vitest.it)('writable=false + configured granted provider ⇒ input enabled, reach card says so', async () => {
    const {
      container
    } = await renderAgent({
      writable: false
    });
    await push({
      type: 'llm-provider',
      provider: {
        providerId: 'llm.chat.anthropic',
        hostVouched: true,
        features: {
          vision: false,
          tools: true,
          jsonMode: true,
          reasoning: false,
          maxContextTokens: 100000
        }
      }
    });
    await push({
      type: 'api-catalog',
      methods: [{
        name: 'llm:chat',
        capability: 'llm:chat',
        stream: true
      }]
    });
    await openPanel(container);
    const input = container.querySelector('.ga-foot input');
    (0, _vitest.expect)(input.disabled).toBe(false);
    const text = container.textContent ?? '';
    (0, _vitest.expect)(text).toContain('Answer questions about this wiki');
    (0, _vitest.expect)(text).toContain('you’re a reader here'); // draft row still honest
    (0, _vitest.expect)(container.textContent).not.toMatch(/Suggest an edit/i); // no write chip while read-only
  });
  (0, _vitest.it)('keyless but GRANTED renders the KEY cause — the case the catalog decides the other way', async () => {
    // The counterpart the suite lost when the G-GA-1 case above changed verdict, and the
    // one that proves the reorder did not simply make the grant cause win everywhere.
    // Same provider payload as that case — `{ provider: null }`, which R-LLM-2 gives both
    // a keyless frame and (on a pre-mark host) an ungranted one — but the catalog says
    // `llm:chat` IS granted. So the only actionable fact is the missing key, and that is
    // what the card must say.
    const {
      container
    } = await renderAgent({
      writable: true
    });
    await push({
      type: 'llm-provider',
      provider: null
    });
    await push({
      type: 'api-catalog',
      methods: [{
        name: 'llm:chat',
        capability: 'llm:chat',
        stream: true
      }]
    });
    await openPanel(container);
    const text = container.textContent ?? '';
    (0, _vitest.expect)(text).toContain('no model key connected — add one in Settings');
    (0, _vitest.expect)(text).not.toContain("wasn't granted chat");
  });
  (0, _vitest.it)('an ungranted fork renders the DISTINCT forbidden cause, never connect-a-key copy', async () => {
    const {
      container
    } = await renderAgent({
      writable: true
    });
    await push({
      type: 'llm-provider',
      provider: {
        providerId: 'llm.chat.anthropic',
        hostVouched: true,
        features: {
          vision: false,
          tools: true,
          jsonMode: true,
          reasoning: false,
          maxContextTokens: 100000
        }
      }
    });
    await push({
      type: 'api-catalog',
      methods: []
    }); // a key exists; this copy wasn't granted chat
    await openPanel(container);
    const text = container.textContent ?? '';
    (0, _vitest.expect)(text).toContain("this Grove wasn't granted chat — reading works as normal");
    (0, _vitest.expect)(text).not.toContain('add one in Settings');
    const input = container.querySelector('.ga-foot input');
    (0, _vitest.expect)(input.disabled).toBe(true); // cannot ask — but reading works, and the card says why
  });
  (0, _vitest.it)('R3-688 — the host-marked grantless answer renders the consent cause without any provider', async () => {
    // The ungranted fork is answered {provider:null, ungranted:true} — never the
    // provider — so before the mark this fork could only render the KEY copy. The
    // mark is the host's grant decision; the card repeats it, never invents it.
    const {
      container
    } = await renderAgent({
      writable: true
    });
    await push({
      type: 'llm-provider',
      provider: null,
      ungranted: true
    });
    await push({
      type: 'api-catalog',
      methods: []
    });
    await openPanel(container);
    const text = container.textContent ?? '';
    (0, _vitest.expect)(text).toContain("this Grove wasn't granted chat — reading works as normal");
    (0, _vitest.expect)(text).not.toContain('add one in Settings'); // the KEY copy — never conflated (G-GA-10)
  });
  (0, _vitest.it)('R-GA-6 — the egress disclosure shows whenever a provider is bound', async () => {
    const {
      container
    } = await renderAgent({
      writable: false
    });
    await push({
      type: 'llm-provider',
      provider: {
        providerId: 'llm.chat.anthropic',
        hostVouched: true,
        features: {
          vision: false,
          tools: true,
          jsonMode: true,
          reasoning: false,
          maxContextTokens: 100000
        }
      }
    });
    await push({
      type: 'api-catalog',
      methods: [{
        name: 'llm:chat',
        capability: 'llm:chat',
        stream: true
      }]
    });
    await openPanel(container);
    (0, _vitest.expect)(container.textContent).toContain('answers come from your connected model provider');
  });

  // R3-752 — the apply row is a DESTINATION: `→` on the row, no ✗ anywhere on the
  // card, and every row's state is text as well as glyph.
  (0, _vitest.it)('R3-752 — read-only + configured granted provider: the apply row renders → elsewhere, never ✗, with hidden state words', async () => {
    const {
      container
    } = await renderAgent({
      writable: false
    });
    await push({
      type: 'llm-provider',
      provider: {
        providerId: 'llm.chat.anthropic',
        hostVouched: true,
        features: {
          vision: false,
          tools: true,
          jsonMode: true,
          reasoning: false,
          maxContextTokens: 100000
        }
      }
    });
    await push({
      type: 'api-catalog',
      methods: [{
        name: 'llm:chat',
        capability: 'llm:chat',
        stream: true
      }]
    });
    await openPanel(container);
    const card = container.querySelector('.ga-reach');
    const applyRow = card.querySelector('.ga-reach__row--elsewhere');
    (0, _vitest.expect)(applyRow.textContent).toContain('Apply changes');
    (0, _vitest.expect)(applyRow.textContent).toContain('→ in the editor or workbench, where you confirm them');
    // A destination is never rendered as a denial: the card's only ✗ is the draft
    // row's (read-only), the apply row's mark is the arrow.
    (0, _vitest.expect)(applyRow.querySelector('.ga-reach__mark').textContent).toBe('→');
    (0, _vitest.expect)(card.textContent).not.toContain('changes open in the editor'); // the old cause copy is gone
    // State is text, never glyph alone: the hidden words are in the tree.
    const words = [...card.querySelectorAll('.ga-reach__stateword')].map(n => n.textContent);
    (0, _vitest.expect)(words).toContain('available');
    (0, _vitest.expect)(words).toContain('unavailable');
    (0, _vitest.expect)(words).toContain('opens elsewhere');
    // The substrate is context, stated, with the git-indeterminate trust line under
    // the card (the SDK's fail-closed default basis).
    (0, _vitest.expect)(card.textContent).toContain('Reads its own entries');
    (0, _vitest.expect)(card.parentElement.textContent).toContain('anyone who can push to this repo can change what the agent reads');
  });
  (0, _vitest.it)('R3-752 — a grant flip is ANNOUNCED, not only re-rendered (R-IX-7): the standing live region tracks the card', async () => {
    const {
      container
    } = await renderAgent({
      writable: false
    });
    await push({
      type: 'llm-provider',
      provider: {
        providerId: 'llm.chat.anthropic',
        hostVouched: true,
        features: {
          vision: false,
          tools: true,
          jsonMode: true,
          reasoning: false,
          maxContextTokens: 100000
        }
      }
    });
    await push({
      type: 'api-catalog',
      methods: []
    }); // key, but NOT granted chat
    await openPanel(container);
    const live = container.querySelector('[role="status"].ga-reach__stateword');
    (0, _vitest.expect)(live.getAttribute('aria-live') ?? 'polite').toBe('polite'); // role=status is polite by default
    (0, _vitest.expect)(live.textContent).toContain('unavailable'); // the blocked Q&A row, in words

    // Grant chat: the flip must change the announcement — the Q&A segment goes
    // unavailable → available (the draft row stays honestly unavailable; read-only).
    await push({
      type: 'api-catalog',
      methods: [{
        name: 'llm:chat',
        capability: 'llm:chat',
        stream: true
      }]
    });
    (0, _vitest.expect)(live.textContent).toContain('Answer questions about this wiki — available');
    (0, _vitest.expect)(live.textContent).not.toContain('Answer questions about this wiki — unavailable');
  });
  (0, _vitest.it)('R3-752 — a configured provider WITHOUT tools keeps Q&A ✓ and shows the degrade qualifier, not silence', async () => {
    const {
      container
    } = await renderAgent({
      writable: false
    });
    await push({
      type: 'llm-provider',
      provider: {
        providerId: 'llm.chat.anthropic',
        hostVouched: true,
        features: {
          vision: false,
          tools: false,
          jsonMode: true,
          reasoning: false,
          maxContextTokens: 100000
        }
      }
    });
    await push({
      type: 'api-catalog',
      methods: [{
        name: 'llm:chat',
        capability: 'llm:chat',
        stream: true
      }]
    });
    await openPanel(container);
    const answerRow = container.querySelector('.ga-reach__row--ok');
    (0, _vitest.expect)(answerRow.textContent).toContain('Answer questions about this wiki');
    (0, _vitest.expect)(answerRow.textContent).toContain('reads a summary of this wiki, not entries on demand');
  });
});
(0, _vitest.describe)('R3-608 — the composer stops the run; a refusal surfaces, a cancel does not', () => {
  (0, _vitest.beforeAll)(() => {
    // jsdom lacks Element.scrollTo; the auto-scroll effect only needs to be a no-op.
    HTMLElement.prototype.scrollTo = () => undefined;
  });
  const configured = {
    type: 'llm-provider',
    provider: {
      providerId: 'llm.chat.anthropic',
      hostVouched: true,
      features: {
        vision: false,
        tools: true,
        jsonMode: true,
        reasoning: false,
        maxContextTokens: 100000
      }
    }
  };
  const granted = {
    type: 'api-catalog',
    methods: [{
      name: 'llm:chat',
      capability: 'llm:chat',
      stream: true
    }]
  };
  (0, _vitest.it)('stop aborts the in-flight run — signal aborted, streaming cleared, a Stopped row, no error', async () => {
    // The REAL loop contract on abort: the promise RESOLVES with the partial
    // transcript (a clean stop, never a thrown error) — the mock mirrors it.
    runAgentMock.mockImplementationOnce(opts => new Promise(resolve => {
      opts.signal?.addEventListener('abort', () => resolve([{
        role: 'user',
        content: 'what is here?'
      }, {
        role: 'assistant',
        content: 'partial answer'
      }]));
    }));
    const {
      container
    } = await renderAgent({
      writable: false
    });
    await push(configured);
    await push(granted);
    await openPanel(container);
    const input = container.querySelector('.ga-foot input');
    await (0, _react.act)(async () => {
      // The native value setter: React's tracker ignores a bare .value assign.
      const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
      setter.call(input, 'what is here?');
      input.dispatchEvent(new Event('input', {
        bubbles: true
      }));
    });
    await (0, _react.act)(async () => {
      container.querySelector('.ga-foot .go').click();
    });
    // Streaming: the stop control exists and the send is spent.
    const stop = container.querySelector('.ga-foot .stop');
    (0, _vitest.expect)(stop).toBeTruthy();
    let signal;
    runAgentMock.mock.calls.forEach(c => {
      signal = c[0].signal;
    });
    (0, _vitest.expect)(signal).toBeTruthy();
    await (0, _react.act)(async () => {
      stop.click();
    });
    (0, _vitest.expect)(signal.aborted).toBe(true);
    (0, _vitest.expect)(container.textContent).toContain('Stopped');
    (0, _vitest.expect)(container.textContent).not.toContain('the model or backend errored');
    (0, _vitest.expect)(container.querySelector('.ga-foot .stop')).toBeNull();
  });
  (0, _vitest.it)('a REFUSING edit renders the failure text; a cancelled one renders nothing', async () => {
    var _s = $RefreshSig$();
    // The real hook, through the real requestEdit → the controllable transport.
    const {
      useEditAffordance
    } = await Promise.resolve().then(() => _interopRequireWildcard(require('../hooks/useEditAffordance')));
    const refusedStates = [];
    function Probe() {
      _s();
      const aff = useEditAffordance(false);
      refusedStates.push(aff.refused);
      return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          onClick: () => aff.openEditor('/app/content/wiki/security.mdx'),
          children: "edit"
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
          "data-testid": "refused",
          children: aff.refused ? 'REFUSED' : ''
        })]
      });
    }
    _s(Probe, "s43IUPyXTEmL5ca9dIKOGC7L/gY=", false, function () {
      return [useEditAffordance];
    });
    const host = document.createElement('div');
    document.body.appendChild(host);
    const root = (0, _client.createRoot)(host);
    await (0, _react.act)(async () => {
      root.render(/*#__PURE__*/(0, _jsxRuntime.jsx)(Probe, {}));
    });

    // A refusal (anything not `cancelled`): the host said no — it must surface.
    protocolRequest.mockRejectedValueOnce(Object.assign(new Error('denied'), {
      code: 'forbidden'
    }));
    await (0, _react.act)(async () => {
      host.querySelector('button').click();
    });
    (0, _vitest.expect)(host.querySelector('[data-testid="refused"]')?.textContent).toBe('REFUSED');

    // A cancellation: the reader closed the editor — silent by contract.
    await (0, _react.act)(async () => {
      root.render(/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {}));
      root.render(/*#__PURE__*/(0, _jsxRuntime.jsx)(Probe, {}));
    });
    refusedStates.length = 0;
    protocolRequest.mockRejectedValueOnce(Object.assign(new Error('closed'), {
      code: 'cancelled'
    }));
    await (0, _react.act)(async () => {
      host.querySelector('button').click();
    });
    (0, _vitest.expect)(host.querySelector('[data-testid="refused"]')?.textContent).toBe('');
    await (0, _react.act)(async () => {
      root.unmount();
    });
  });
  (0, _vitest.it)('the agent panel renders the refusal text where the affordance is offered', async () => {
    const {
      root,
      container: host
    } = await renderAgent({
      writable: false
    }, {
      shell: {
        editRefused: true
      }
    });
    await openPanel(host);
    (0, _vitest.expect)(host.textContent).toContain('Could not open the editor — the host refused');
    await (0, _react.act)(async () => {
      root.unmount();
    });
  });
});
(0, _vitest.describe)('R3-608 round 2 — the panel returns focus to its (unmounted) trigger', () => {
  (0, _vitest.it)('Escape-close lands focus back on the resting input, not <body>', async () => {
    const {
      container
    } = await renderAgent({
      writable: false
    });
    await push({
      type: 'llm-provider',
      provider: null
    });
    await push({
      type: 'api-catalog',
      methods: []
    });
    // Open through the resting input (the real trigger path).
    const resting = container.querySelector('.ga-line input');
    await (0, _react.act)(async () => {
      resting.focus();
    });
    (0, _vitest.expect)(container.querySelector('.ga-panel')).toBeTruthy();
    await (0, _react.act)(async () => {
      document.dispatchEvent(new KeyboardEvent('keydown', {
        key: 'Escape',
        bubbles: true,
        cancelable: true
      }));
    });
    (0, _vitest.expect)(container.querySelector('.ga-panel')).toBeNull();
    // The focus return rides a requestAnimationFrame — flush the frame.
    await (0, _react.act)(async () => {
      await new Promise(r => setTimeout(r, 16));
    });
    // The resting line remounted and its SUBMIT control took focus — a real
    // stop that cannot reopen the panel, never <body>.
    const remounted = container.querySelector('.ga-line .go');
    (0, _vitest.expect)(remounted).toBeTruthy();
    (0, _vitest.expect)(document.activeElement).toBe(remounted);
    (0, _vitest.expect)(container.querySelector('.ga-panel')).toBeNull(); // focus did not reopen
  });
});

// ── R3-790 — the ungranted chat row's earning affordance ──────────────────────

(0, _vitest.describe)("R3-790 — the ✗ chat row offers its earning affordance (click invokes; the host gesture mints)", () => {
  (0, _vitest.beforeAll)(() => {
    HTMLElement.prototype.scrollTo = () => undefined;
  });
  (0, _vitest.it)('renders Enable chat on the ungranted row — the host-marked forbidden cause', async () => {
    const {
      container
    } = await renderAgent({
      writable: false
    });
    // The cold mark — no prior configured push: the host strips the provider from
    // every answer to an ungranted frame (the R3-688 test's shape).
    await push({
      type: 'llm-provider',
      provider: null,
      ungranted: true
    });
    await push({
      type: 'api-catalog',
      methods: []
    }); // answered: nothing granted
    await openPanel(container);
    const enable = container.querySelector('.ga-reach__enable');
    (0, _vitest.expect)(enable).toBeTruthy(); // the affordance exists on the ✗ row
    (0, _vitest.expect)(enable.textContent).toBe('Enable chat');
    // …and the row itself still tells the honest cause.
    (0, _vitest.expect)(container.querySelector('.ga-reach__row--blocked')?.textContent).toContain("this Grove wasn't granted chat");
  });
  (0, _vitest.it)('renders NO affordance when the provider is not configured (that row points at Settings)', async () => {
    const {
      container
    } = await renderAgent({
      writable: false
    });
    await push({
      type: 'llm-provider',
      provider: null
    }); // not-configured, not ungranted
    await push({
      type: 'api-catalog',
      methods: []
    });
    await openPanel(container);
    (0, _vitest.expect)(container.querySelector('.ga-reach__enable')).toBeNull();
  });
  (0, _vitest.it)("a click invokes; a DECLINED dialog ('cancelled') keeps the honest row and says so", async () => {
    runAgentMock.mockClear();
    runAgentMock.mockImplementationOnce(() => {
      const e = new Error('declined');
      e.code = 'cancelled';
      throw e;
    });
    const {
      container
    } = await renderAgent({
      writable: false
    });
    // The cold mark — no prior configured push: the host strips the provider from
    // every answer to an ungranted frame (the R3-688 test's shape).
    await push({
      type: 'llm-provider',
      provider: null,
      ungranted: true
    });
    await push({
      type: 'api-catalog',
      methods: []
    });
    await openPanel(container);
    await (0, _react.act)(async () => {
      container.querySelector('.ga-reach__enable').click();
    });
    // The invoke RAN (runAgent was called once — the gesture's trigger)…
    (0, _vitest.expect)(runAgentMock).toHaveBeenCalledTimes(1);
    // …the decline surfaced honestly…
    await (0, _react.act)(async () => {
      await new Promise(r => setTimeout(r, 16));
    });
    (0, _vitest.expect)(container.querySelector('.ga-toast')?.textContent).toContain("chat didn't start — reading works as normal; you can try again anytime");
    // …and the row still reads the forbidden cause with the affordance for the next click.
    (0, _vitest.expect)(container.querySelector('.ga-reach__row--blocked')?.textContent).toContain("this Grove wasn't granted chat");
    (0, _vitest.expect)(container.querySelector('.ga-reach__enable')).toBeTruthy();
  });
  (0, _vitest.it)('a click invokes; a still-FORBIDDEN answer surfaces the refusal toast (pre-gesture hosts)', async () => {
    runAgentMock.mockImplementationOnce(() => {
      const e = new Error('forbidden');
      e.code = 'forbidden';
      throw e;
    });
    const {
      container
    } = await renderAgent({
      writable: false
    });
    // The cold mark — no prior configured push: the host strips the provider from
    // every answer to an ungranted frame (the R3-688 test's shape).
    await push({
      type: 'llm-provider',
      provider: null,
      ungranted: true
    });
    await push({
      type: 'api-catalog',
      methods: []
    });
    await openPanel(container);
    await (0, _react.act)(async () => {
      container.querySelector('.ga-reach__enable').click();
    });
    await (0, _react.act)(async () => {
      await new Promise(r => setTimeout(r, 16));
    });
    (0, _vitest.expect)(container.querySelector('.ga-toast')?.textContent).toContain("this Grove wasn't granted chat");
  });
});

// ── R3-790 round 1 — the GRANTED leg: the click's invoke proceeds when the grant lands ──

(0, _vitest.describe)("R3-790 — the granted leg (click → invoke → the grant lands → the ask proceeds, the row flips)", () => {
  (0, _vitest.beforeAll)(() => {
    HTMLElement.prototype.scrollTo = () => undefined;
  });
  const configured = {
    type: 'llm-provider',
    provider: {
      providerId: 'llm.chat.anthropic',
      hostVouched: true,
      features: {
        vision: false,
        tools: true,
        jsonMode: true,
        reasoning: false,
        maxContextTokens: 100000
      }
    }
  };
  const grantedCatalog = {
    type: 'api-catalog',
    methods: [{
      name: 'llm:chat',
      capability: 'llm:chat',
      stream: true
    }]
  };
  (0, _vitest.it)("the affordance's click drives the invoke; the granted catalog flips the row ✓ and the input enables", async () => {
    runAgentMock.mockClear();
    runAgentMock.mockImplementationOnce(async () => [{
      role: 'user',
      content: [{
        type: 'text',
        text: 'Answer in one sentence: what can you tell me about this wiki?'
      }]
    }, {
      role: 'assistant',
      content: [{
        type: 'text',
        text: 'This wiki is a small corpus about enabling chat.'
      }]
    }]);
    const {
      container
    } = await renderAgent({
      writable: false
    });
    await push({
      type: 'llm-provider',
      provider: null,
      ungranted: true
    });
    await push({
      type: 'api-catalog',
      methods: []
    });
    await openPanel(container);
    // Before: the honest ✗ row + the affordance.
    (0, _vitest.expect)(container.querySelector('.ga-reach__row--blocked')?.textContent).toContain("this Grove wasn't granted chat");
    await (0, _react.act)(async () => {
      container.querySelector('.ga-reach__enable').click();
    });
    // The invoke RAN (the gesture's trigger).
    (0, _vitest.expect)(runAgentMock).toHaveBeenCalledTimes(1);
    // The grant lands (the host's mint + lift answers the channels): push the
    // granted catalog + the configured provider — the envelope recomputes.
    await push(grantedCatalog);
    await push(configured);
    await (0, _react.act)(async () => {
      await new Promise(r => setTimeout(r, 16));
    });
    await (0, _react.act)(async () => {
      await new Promise(r => setTimeout(r, 16));
    });
    // The ask PROCEEDED: the assistant answer is in the body…
    (0, _vitest.expect)(container.querySelector('.ga-body')?.textContent).toContain('enabling chat');
    // …the ANSWER row flipped ✓ (the read-only draft row stays honestly ✗ — that is
    // its own row, not this one)…
    const answerRow = [...container.querySelectorAll('.ga-reach__row')].find(r => r.textContent?.includes('Answer questions about this wiki'));
    (0, _vitest.expect)(answerRow?.className).not.toContain('blocked');
    (0, _vitest.expect)(container.querySelector('.ga-reach__enable')).toBeNull();
    // …and the composer input is ENABLED (canAsk true).
    const input = container.querySelector('.ga-foot input');
    (0, _vitest.expect)(input?.disabled).toBe(false);
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZXN0IiwicmVxdWlyZSIsIl9yZWFjdCIsIl9jbGllbnQiLCJfanN4UnVudGltZSIsIl9nZXRSZXF1aXJlV2lsZGNhcmRDYWNoZSIsImUiLCJXZWFrTWFwIiwiciIsInQiLCJfaW50ZXJvcFJlcXVpcmVXaWxkY2FyZCIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiaGFzIiwiZ2V0IiwibiIsIl9fcHJvdG9fXyIsImEiLCJPYmplY3QiLCJkZWZpbmVQcm9wZXJ0eSIsImdldE93blByb3BlcnR5RGVzY3JpcHRvciIsInUiLCJoYXNPd25Qcm9wZXJ0eSIsImNhbGwiLCJpIiwic2V0IiwidmkiLCJtb2NrIiwicHJvbWlzZXMiLCJyZWFkRmlsZSIsImZuIiwicnVuQWdlbnRNb2NrIiwiaW1wb3J0T3JpZ2luYWwiLCJydW5BZ2VudCIsIm9wdHMiLCJyZW5kZXJBZ2VudCIsIm9wZW5QYW5lbCIsInB1c2giLCJwcm90b2NvbFJlcXVlc3QiLCJQcm9taXNlIiwicmVzb2x2ZSIsInRoZW4iLCJkZXNjcmliZSIsIml0IiwiY29udGFpbmVyIiwid3JpdGFibGUiLCJ0eXBlIiwicHJvdmlkZXIiLCJtZXRob2RzIiwidGV4dCIsInRleHRDb250ZW50IiwiZXhwZWN0Iiwibm90IiwidG9NYXRjaCIsInF1ZXJ5U2VsZWN0b3JBbGwiLCJsZW5ndGgiLCJ0b0JlIiwidG9Db250YWluIiwicHJvdmlkZXJJZCIsImhvc3RWb3VjaGVkIiwiZmVhdHVyZXMiLCJ2aXNpb24iLCJ0b29scyIsImpzb25Nb2RlIiwicmVhc29uaW5nIiwibWF4Q29udGV4dFRva2VucyIsIm5hbWUiLCJjYXBhYmlsaXR5Iiwic3RyZWFtIiwiaW5wdXQiLCJxdWVyeVNlbGVjdG9yIiwiZGlzYWJsZWQiLCJ1bmdyYW50ZWQiLCJjYXJkIiwiYXBwbHlSb3ciLCJ3b3JkcyIsIm1hcCIsInBhcmVudEVsZW1lbnQiLCJsaXZlIiwiZ2V0QXR0cmlidXRlIiwiYW5zd2VyUm93IiwiYmVmb3JlQWxsIiwiSFRNTEVsZW1lbnQiLCJwcm90b3R5cGUiLCJzY3JvbGxUbyIsInVuZGVmaW5lZCIsImNvbmZpZ3VyZWQiLCJncmFudGVkIiwibW9ja0ltcGxlbWVudGF0aW9uT25jZSIsInNpZ25hbCIsImFkZEV2ZW50TGlzdGVuZXIiLCJyb2xlIiwiY29udGVudCIsImFjdCIsInNldHRlciIsIkhUTUxJbnB1dEVsZW1lbnQiLCJkaXNwYXRjaEV2ZW50IiwiRXZlbnQiLCJidWJibGVzIiwiY2xpY2siLCJzdG9wIiwidG9CZVRydXRoeSIsImNhbGxzIiwiZm9yRWFjaCIsImMiLCJhYm9ydGVkIiwidG9CZU51bGwiLCJfcyIsIiRSZWZyZXNoU2lnJCIsInVzZUVkaXRBZmZvcmRhbmNlIiwicmVmdXNlZFN0YXRlcyIsIlByb2JlIiwiYWZmIiwicmVmdXNlZCIsImpzeHMiLCJjaGlsZHJlbiIsImpzeCIsIm9uQ2xpY2siLCJvcGVuRWRpdG9yIiwiaG9zdCIsImRvY3VtZW50IiwiY3JlYXRlRWxlbWVudCIsImJvZHkiLCJhcHBlbmRDaGlsZCIsInJvb3QiLCJjcmVhdGVSb290IiwicmVuZGVyIiwibW9ja1JlamVjdGVkVmFsdWVPbmNlIiwiYXNzaWduIiwiRXJyb3IiLCJjb2RlIiwidW5tb3VudCIsInNoZWxsIiwiZWRpdFJlZnVzZWQiLCJyZXN0aW5nIiwiZm9jdXMiLCJLZXlib2FyZEV2ZW50Iiwia2V5IiwiY2FuY2VsYWJsZSIsInNldFRpbWVvdXQiLCJyZW1vdW50ZWQiLCJhY3RpdmVFbGVtZW50IiwiZW5hYmxlIiwibW9ja0NsZWFyIiwidG9IYXZlQmVlbkNhbGxlZFRpbWVzIiwiZ3JhbnRlZENhdGFsb2ciLCJmaW5kIiwiaW5jbHVkZXMiLCJjbGFzc05hbWUiXSwic291cmNlcyI6WyJHcm92ZUFnZW50LnRlc3QudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIEB2aXRlc3QtZW52aXJvbm1lbnQganNkb21cbi8vIEctR0EtMSAvIEctR0EtMiDigJQgdGhlIHN1cmZhY2UgaXRzZWxmOiB3aXRoIGB3cml0YWJsZT1mYWxzZWAgYW5kIG5vIHByb3ZpZGVyLCB0aGVcbi8vIERPTSBjb250YWlucyBubyB3cml0ZS1mbGF2b3JlZCBjaGlwIGFuZCBubyBcInByb3Bvc2VzIHRoZSBlZGl0XCIvXCJob3N0IGNvbmZpcm1zXCJcbi8vIGNvcHk7IHdpdGggYHdyaXRhYmxlPWZhbHNlYCBidXQgYSBjb25maWd1cmVkLCBncmFudGVkIHByb3ZpZGVyLCBRJkEgaXMgZnVsbHlcbi8vIGVuYWJsZWQgKHJlYWQtb25seSBORVZFUiBibG9ja3MgYXNraW5nIOKAlCBSLUdBLTUpLiBQcm92aWRlci9ncmFudCBzdGF0ZSBpcyBkcml2ZW5cbi8vIHRocm91Z2ggdGhlIFNESydzIFJFQUwgcHVzaCBjaGFubmVscyAoYW4gZW1pdHRpbmcgc3R1YiB0cmFuc3BvcnQpLCBub3QgbW9ja3Mgb2Zcbi8vIHRoZSBob29rcyDigJQgdGhlIGNvbXBvbmVudCByZWFkcyB3aGF0IHRoZSBob3N0IHdvdWxkIGhhdmUgc2FpZC5cbmltcG9ydCB7IGRlc2NyaWJlLCBpdCwgZXhwZWN0LCB2aSwgYmVmb3JlQWxsIH0gZnJvbSAndml0ZXN0JztcbmltcG9ydCB7IGFjdCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IGNyZWF0ZVJvb3QgfSBmcm9tICdyZWFjdC1kb20vY2xpZW50JztcblxuLy8gYHVzZUhlYWRpbmdzYCBzY2FucyB0aGUgRE9NIChubyAuZ3JvdmUtcHJvc2UgaW4gdGhpcyBoYXJuZXNzIOKHkiBubyBoZWFkaW5ncyDigJQgZmluZSkuXG4vLyBgZnNgIGlzIHJlYWQgb25seSB0aHJvdWdoIHNhZmVTb3VyY2VzIG9uIHRoZSBzdHVmZmluZyBwYXRoLCBuZXZlciBpbiB0aGVzZSBjYXNlcy5cbnZpLm1vY2soJ2ZzJywgKCkgPT4gKHsgZGVmYXVsdDogeyBwcm9taXNlczogeyByZWFkRmlsZTogdmkuZm4oYXN5bmMgKCkgPT4gJycpIH0gfSB9KSk7XG5cbi8vIHJ1bkFnZW50IGlzIGNvbnRyb2xsYWJsZSBmb3IgdGhlIHN0b3AtYWJvcnQgY2FzZSAoUjMtNjA4KTsgZXZlcnl0aGluZyBlbHNlIGluXG4vLyB0aGUgYmFycmVsIHN0YXlzIHJlYWwg4oCUIHRoZSBleGlzdGluZyBjYXNlcyBuZXZlciBpbnZva2UgaXQuXG5jb25zdCBydW5BZ2VudE1vY2sgPSB2aS5mbigpO1xudmkubW9jaygnQGltbWVkaWF0ZWx5LXJ1bi9zZGsnLCBhc3luYyAoaW1wb3J0T3JpZ2luYWwpID0+ICh7XG4gIC4uLihhd2FpdCBpbXBvcnRPcmlnaW5hbDx0eXBlb2YgaW1wb3J0KCdAaW1tZWRpYXRlbHktcnVuL3NkaycpPigpKSxcbiAgcnVuQWdlbnQ6IChvcHRzOiB1bmtub3duKSA9PiBydW5BZ2VudE1vY2sob3B0cyksXG59KSk7XG5cbi8vIFRoZSB0cmFuc3BvcnQgc3R1YiwgdGhlIHJlbmRlcmVyIGFuZCB0aGUgcHVzaCBkcml2ZXIgbGl2ZSBpblxuLy8gYHNyYy90ZXN0L2dyb3ZlQWdlbnRIYXJuZXNzLnRzeGAg4oCUIHNoYXJlZCByYXRoZXIgdGhhbiBjb3BpZWQsIGJlY2F1c2Vcbi8vIGBHcm92ZUFnZW50LnVuYW5zd2VyZWQudGVzdC50c3hgIG5lZWRzIHRoZSBzYW1lIGhhcm5lc3MgaW4gYSBtb2R1bGUgcmVnaXN0cnkgd2hlcmUgdGhlXG4vLyBjYXRhbG9nIGhhcyBuZXZlciBiZWVuIGFuc3dlcmVkIChncm92ZSM3NSByb3VuZCAzKS5cbmNvbnN0IHsgcmVuZGVyQWdlbnQsIG9wZW5QYW5lbCwgcHVzaCwgcHJvdG9jb2xSZXF1ZXN0IH0gPSBhd2FpdCBpbXBvcnQoJy4uLy4uL3Rlc3QvZ3JvdmVBZ2VudEhhcm5lc3MnKTtcblxuLy8gTk9URTogbm8gcGVyLXRlc3QgaGFuZGxlciByZXNldC4gVGhlIFNESydzIHB1c2ggY2hhbm5lbHMgYXJlIG1vZHVsZS1nbG9iYWwgYW5kXG4vLyBzdWJzY3JpYmUgdG8gdGhlIHRyYW5zcG9ydCBleGFjdGx5IG9uY2UgKHRoZSBgc3RhcnRlZGAgZmxhZyBpbiBgY3JlYXRlUHVzaENoYW5uZWxgKSxcbi8vIHNvIGNsZWFyaW5nIHRoZSBoYW5kbGVyIHNldCB3b3VsZCBzZXZlciBldmVyeSBsYXRlciBlbWl0IGZyb20gdGhlIGNoYW5uZWxzLiBFYWNoXG4vLyB0ZXN0IGRyaXZlcyB0aGUgRlVMTCBkZXNpcmVkIGhvc3Qgc3RhdGUgdGhyb3VnaCBpdHMgb3duIHB1c2hlcyBpbnN0ZWFkLlxuXG5kZXNjcmliZSgnRy1HQS0xIOKAlCBubyB1bmJhY2tlZCBjYXBhYmlsaXR5IGNsYWltcyBpbiB0aGUgRE9NJywgKCkgPT4ge1xuICBpdCgnd3JpdGFibGU9ZmFsc2UgKyBubyBwcm92aWRlcjogbm8gd3JpdGUtZmxhdm9yZWQgY2hpcCwgbm8gcGhhbnRvbS13cml0ZSBjb3B5JywgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHsgY29udGFpbmVyIH0gPSBhd2FpdCByZW5kZXJBZ2VudCh7IHdyaXRhYmxlOiBmYWxzZSB9KTtcbiAgICAvLyBUaGUgaG9zdCBnZW5lcmF0aW9uIHRoaXMgbW9kZWxzIG1hdHRlcnMsIGJlY2F1c2UgdGhlIHR3byBwdXNoZXMgYmVsb3cgb25seSBtYWtlXG4gICAgLy8gc2Vuc2UgdG9nZXRoZXIgb24gT05FIG9mIHRoZW0uIFItTExNLTIgc2F5cyBhIGZyYW1lIGxhY2tpbmcgYGxsbTpjaGF0YCBpcyBhbnN3ZXJlZFxuICAgIC8vIGB7IHByb3ZpZGVyOiBudWxsIH1gIOKAlCB0aGUgU0FNRSBwYXlsb2FkIGFzIGEgZ3JhbnRlZCBmcmFtZSB3aXRoIG5vIGtleSDigJQgc28gb24gYVxuICAgIC8vIGhvc3QgdGhhdCBwcmVkYXRlcyBSMy02ODgncyBgdW5ncmFudGVkYCBtYXJrIHRoaXMgcGFpciAobnVsbCBwcm92aWRlciwgZW1wdHlcbiAgICAvLyBjYXRhbG9nKSBpcyBleGFjdGx5IHdoYXQgYW4gdW5ncmFudGVkIGZvcmsgc2VlcywgYW5kIGl0IGlzIGluZGlzdGluZ3Vpc2hhYmxlIGF0IHRoZVxuICAgIC8vIHByb3ZpZGVyIGNoYW5uZWwgZnJvbSBrZXlsZXNzLWJ1dC1ncmFudGVkLiBUaGF0IGluZGlzdGluZ3Vpc2hhYmlsaXR5IElTIFIzLTY4OC5cbiAgICAvLyBBIDAuNzIuMCBob3N0IHdvdWxkIGluc3RlYWQgbWFyayB0aGUgYW5zd2VyLCB3aGljaCB0aGUgUjMtNjg4IGNhc2UgYmVsb3cgY292ZXJzLlxuICAgIGF3YWl0IHB1c2goeyB0eXBlOiAnbGxtLXByb3ZpZGVyJywgcHJvdmlkZXI6IG51bGwgfSk7IC8vIHByZS1tYXJrIGhvc3Q6IG51bGwgZWl0aGVyIHdheVxuICAgIGF3YWl0IHB1c2goeyB0eXBlOiAnYXBpLWNhdGFsb2cnLCBtZXRob2RzOiBbXSB9KTsgLy8gbm90aGluZyBncmFudGVkIOKAlCB0aGUgZGVjaWRpbmcgZmFjdFxuICAgIGF3YWl0IG9wZW5QYW5lbChjb250YWluZXIpO1xuICAgIGNvbnN0IHRleHQgPSBjb250YWluZXIudGV4dENvbnRlbnQgPz8gJyc7XG4gICAgZXhwZWN0KHRleHQpLm5vdC50b01hdGNoKC9hZGQgYW4gZW50cnl8Zml4IGJyb2tlbiBsaW5rc3xyZW9yZ2FuaXplIHRoZSBzaWRlYmFyfGFkZCBhIHRpbWVsaW5lL2kpO1xuICAgIGV4cGVjdCh0ZXh0KS5ub3QudG9NYXRjaCgvcHJvcG9zZXMgdGhlIGVkaXR8aG9zdCBjb25maXJtcyB0aGUgd3JpdGUvaSk7XG4gICAgZXhwZWN0KGNvbnRhaW5lci5xdWVyeVNlbGVjdG9yQWxsKCcuZ2EtY2hpcCcpLmxlbmd0aCkudG9CZSgwKTsgLy8gbm8g4pyTIHJvd3Mg4oeSIG5vIGNoaXBzXG4gICAgLy8gQW5kIHRoZSBob25lc3QgY2F1c2VzIEFSRSB0aGVyZS4gUjMtNjg4IENIQU5HRUQgd2hpY2ggb25lIHRoaXMgY2FzZSBnZXRzLCBhbmQgdGhlXG4gICAgLy8gY2hhbmdlIGlzIHRoZSBwb2ludCBvZiB0aGUgaXRlbS4gT24gYSBwcmUtbWFyayBob3N0IHRoZSBwcm92aWRlciBjaGFubmVsIGNhbm5vdFxuICAgIC8vIHRlbGwga2V5bGVzcyBmcm9tIHVuZ3JhbnRlZCwgc28gdGhlIENBVEFMT0cgaXMgdGhlIG9ubHkgZmFjdCB0aGF0IGRpc2NyaW1pbmF0ZXMg4oCUXG4gICAgLy8gYW5kIGl0IHNheXMgbm90IGdyYW50ZWQuIFRoZSBvbGQgb3JkZXIgYXNrZWQgbm90LWNvbmZpZ3VyZWQgZmlyc3QgYW5kIHRoZXJlZm9yZVxuICAgIC8vIHRvbGQgYSB1c2VyIHdobyBtYXkgd2VsbCBoYXZlIGEga2V5IHRvIGdvIGFkZCBvbmUsIHdoaWNoIGNhbm5vdCB1bmJsb2NrIHRoZW0uXG4gICAgLy8gVGhlIGtleSBjYXVzZSBpcyBzdGlsbCByZW5kZXJlZCBmb3IgYSBmcmFtZSB0aGUgY2F0YWxvZyBzYXlzIElTIGdyYW50ZWRcbiAgICAvLyAoYHJlYWNoQ2FyZC50ZXN0LnRzYCDigJQgXCJub3QtY29uZmlndXJlZCBuYW1lcyB0aGUgS0VZIGNhdXNlXCIpLlxuICAgIGV4cGVjdCh0ZXh0KS50b0NvbnRhaW4oXCJ3YXNuJ3QgZ3JhbnRlZCBjaGF0XCIpO1xuICAgIGV4cGVjdCh0ZXh0KS5ub3QudG9Db250YWluKCdubyBtb2RlbCBrZXkgY29ubmVjdGVkJyk7XG4gICAgZXhwZWN0KHRleHQpLnRvQ29udGFpbigneW914oCZcmUgYSByZWFkZXIgaGVyZScpO1xuICB9KTtcbn0pO1xuXG5kZXNjcmliZSgnRy1HQS0yIC8gUi1HQS01IOKAlCByZWFkLW9ubHkgbmV2ZXIgYmxvY2tzIFEmQScsICgpID0+IHtcbiAgaXQoJ3dyaXRhYmxlPWZhbHNlICsgY29uZmlndXJlZCBncmFudGVkIHByb3ZpZGVyIOKHkiBpbnB1dCBlbmFibGVkLCByZWFjaCBjYXJkIHNheXMgc28nLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgeyBjb250YWluZXIgfSA9IGF3YWl0IHJlbmRlckFnZW50KHsgd3JpdGFibGU6IGZhbHNlIH0pO1xuICAgIGF3YWl0IHB1c2goe1xuICAgICAgdHlwZTogJ2xsbS1wcm92aWRlcicsXG4gICAgICBwcm92aWRlcjoge1xuICAgICAgICBwcm92aWRlcklkOiAnbGxtLmNoYXQuYW50aHJvcGljJyxcbiAgICAgICAgaG9zdFZvdWNoZWQ6IHRydWUsXG4gICAgICAgIGZlYXR1cmVzOiB7IHZpc2lvbjogZmFsc2UsIHRvb2xzOiB0cnVlLCBqc29uTW9kZTogdHJ1ZSwgcmVhc29uaW5nOiBmYWxzZSwgbWF4Q29udGV4dFRva2VuczogMTAwMDAwIH0sXG4gICAgICB9LFxuICAgIH0pO1xuICAgIGF3YWl0IHB1c2goeyB0eXBlOiAnYXBpLWNhdGFsb2cnLCBtZXRob2RzOiBbeyBuYW1lOiAnbGxtOmNoYXQnLCBjYXBhYmlsaXR5OiAnbGxtOmNoYXQnLCBzdHJlYW06IHRydWUgfV0gfSk7XG4gICAgYXdhaXQgb3BlblBhbmVsKGNvbnRhaW5lcik7XG4gICAgY29uc3QgaW5wdXQgPSBjb250YWluZXIucXVlcnlTZWxlY3RvcignLmdhLWZvb3QgaW5wdXQnKSBhcyBIVE1MSW5wdXRFbGVtZW50O1xuICAgIGV4cGVjdChpbnB1dC5kaXNhYmxlZCkudG9CZShmYWxzZSk7XG4gICAgY29uc3QgdGV4dCA9IGNvbnRhaW5lci50ZXh0Q29udGVudCA/PyAnJztcbiAgICBleHBlY3QodGV4dCkudG9Db250YWluKCdBbnN3ZXIgcXVlc3Rpb25zIGFib3V0IHRoaXMgd2lraScpO1xuICAgIGV4cGVjdCh0ZXh0KS50b0NvbnRhaW4oJ3lvdeKAmXJlIGEgcmVhZGVyIGhlcmUnKTsgLy8gZHJhZnQgcm93IHN0aWxsIGhvbmVzdFxuICAgIGV4cGVjdChjb250YWluZXIudGV4dENvbnRlbnQpLm5vdC50b01hdGNoKC9TdWdnZXN0IGFuIGVkaXQvaSk7IC8vIG5vIHdyaXRlIGNoaXAgd2hpbGUgcmVhZC1vbmx5XG4gIH0pO1xuXG4gIGl0KCdrZXlsZXNzIGJ1dCBHUkFOVEVEIHJlbmRlcnMgdGhlIEtFWSBjYXVzZSDigJQgdGhlIGNhc2UgdGhlIGNhdGFsb2cgZGVjaWRlcyB0aGUgb3RoZXIgd2F5JywgYXN5bmMgKCkgPT4ge1xuICAgIC8vIFRoZSBjb3VudGVycGFydCB0aGUgc3VpdGUgbG9zdCB3aGVuIHRoZSBHLUdBLTEgY2FzZSBhYm92ZSBjaGFuZ2VkIHZlcmRpY3QsIGFuZCB0aGVcbiAgICAvLyBvbmUgdGhhdCBwcm92ZXMgdGhlIHJlb3JkZXIgZGlkIG5vdCBzaW1wbHkgbWFrZSB0aGUgZ3JhbnQgY2F1c2Ugd2luIGV2ZXJ5d2hlcmUuXG4gICAgLy8gU2FtZSBwcm92aWRlciBwYXlsb2FkIGFzIHRoYXQgY2FzZSDigJQgYHsgcHJvdmlkZXI6IG51bGwgfWAsIHdoaWNoIFItTExNLTIgZ2l2ZXMgYm90aFxuICAgIC8vIGEga2V5bGVzcyBmcmFtZSBhbmQgKG9uIGEgcHJlLW1hcmsgaG9zdCkgYW4gdW5ncmFudGVkIG9uZSDigJQgYnV0IHRoZSBjYXRhbG9nIHNheXNcbiAgICAvLyBgbGxtOmNoYXRgIElTIGdyYW50ZWQuIFNvIHRoZSBvbmx5IGFjdGlvbmFibGUgZmFjdCBpcyB0aGUgbWlzc2luZyBrZXksIGFuZCB0aGF0IGlzXG4gICAgLy8gd2hhdCB0aGUgY2FyZCBtdXN0IHNheS5cbiAgICBjb25zdCB7IGNvbnRhaW5lciB9ID0gYXdhaXQgcmVuZGVyQWdlbnQoeyB3cml0YWJsZTogdHJ1ZSB9KTtcbiAgICBhd2FpdCBwdXNoKHsgdHlwZTogJ2xsbS1wcm92aWRlcicsIHByb3ZpZGVyOiBudWxsIH0pO1xuICAgIGF3YWl0IHB1c2goeyB0eXBlOiAnYXBpLWNhdGFsb2cnLCBtZXRob2RzOiBbeyBuYW1lOiAnbGxtOmNoYXQnLCBjYXBhYmlsaXR5OiAnbGxtOmNoYXQnLCBzdHJlYW06IHRydWUgfV0gfSk7XG4gICAgYXdhaXQgb3BlblBhbmVsKGNvbnRhaW5lcik7XG4gICAgY29uc3QgdGV4dCA9IGNvbnRhaW5lci50ZXh0Q29udGVudCA/PyAnJztcbiAgICBleHBlY3QodGV4dCkudG9Db250YWluKCdubyBtb2RlbCBrZXkgY29ubmVjdGVkIOKAlCBhZGQgb25lIGluIFNldHRpbmdzJyk7XG4gICAgZXhwZWN0KHRleHQpLm5vdC50b0NvbnRhaW4oXCJ3YXNuJ3QgZ3JhbnRlZCBjaGF0XCIpO1xuICB9KTtcblxuICBpdCgnYW4gdW5ncmFudGVkIGZvcmsgcmVuZGVycyB0aGUgRElTVElOQ1QgZm9yYmlkZGVuIGNhdXNlLCBuZXZlciBjb25uZWN0LWEta2V5IGNvcHknLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgeyBjb250YWluZXIgfSA9IGF3YWl0IHJlbmRlckFnZW50KHsgd3JpdGFibGU6IHRydWUgfSk7XG4gICAgYXdhaXQgcHVzaCh7XG4gICAgICB0eXBlOiAnbGxtLXByb3ZpZGVyJyxcbiAgICAgIHByb3ZpZGVyOiB7XG4gICAgICAgIHByb3ZpZGVySWQ6ICdsbG0uY2hhdC5hbnRocm9waWMnLFxuICAgICAgICBob3N0Vm91Y2hlZDogdHJ1ZSxcbiAgICAgICAgZmVhdHVyZXM6IHsgdmlzaW9uOiBmYWxzZSwgdG9vbHM6IHRydWUsIGpzb25Nb2RlOiB0cnVlLCByZWFzb25pbmc6IGZhbHNlLCBtYXhDb250ZXh0VG9rZW5zOiAxMDAwMDAgfSxcbiAgICAgIH0sXG4gICAgfSk7XG4gICAgYXdhaXQgcHVzaCh7IHR5cGU6ICdhcGktY2F0YWxvZycsIG1ldGhvZHM6IFtdIH0pOyAvLyBhIGtleSBleGlzdHM7IHRoaXMgY29weSB3YXNuJ3QgZ3JhbnRlZCBjaGF0XG4gICAgYXdhaXQgb3BlblBhbmVsKGNvbnRhaW5lcik7XG4gICAgY29uc3QgdGV4dCA9IGNvbnRhaW5lci50ZXh0Q29udGVudCA/PyAnJztcbiAgICBleHBlY3QodGV4dCkudG9Db250YWluKFwidGhpcyBHcm92ZSB3YXNuJ3QgZ3JhbnRlZCBjaGF0IOKAlCByZWFkaW5nIHdvcmtzIGFzIG5vcm1hbFwiKTtcbiAgICBleHBlY3QodGV4dCkubm90LnRvQ29udGFpbignYWRkIG9uZSBpbiBTZXR0aW5ncycpO1xuICAgIGNvbnN0IGlucHV0ID0gY29udGFpbmVyLnF1ZXJ5U2VsZWN0b3IoJy5nYS1mb290IGlucHV0JykgYXMgSFRNTElucHV0RWxlbWVudDtcbiAgICBleHBlY3QoaW5wdXQuZGlzYWJsZWQpLnRvQmUodHJ1ZSk7IC8vIGNhbm5vdCBhc2sg4oCUIGJ1dCByZWFkaW5nIHdvcmtzLCBhbmQgdGhlIGNhcmQgc2F5cyB3aHlcbiAgfSk7XG5cbiAgaXQoJ1IzLTY4OCDigJQgdGhlIGhvc3QtbWFya2VkIGdyYW50bGVzcyBhbnN3ZXIgcmVuZGVycyB0aGUgY29uc2VudCBjYXVzZSB3aXRob3V0IGFueSBwcm92aWRlcicsIGFzeW5jICgpID0+IHtcbiAgICAvLyBUaGUgdW5ncmFudGVkIGZvcmsgaXMgYW5zd2VyZWQge3Byb3ZpZGVyOm51bGwsIHVuZ3JhbnRlZDp0cnVlfSDigJQgbmV2ZXIgdGhlXG4gICAgLy8gcHJvdmlkZXIg4oCUIHNvIGJlZm9yZSB0aGUgbWFyayB0aGlzIGZvcmsgY291bGQgb25seSByZW5kZXIgdGhlIEtFWSBjb3B5LiBUaGVcbiAgICAvLyBtYXJrIGlzIHRoZSBob3N0J3MgZ3JhbnQgZGVjaXNpb247IHRoZSBjYXJkIHJlcGVhdHMgaXQsIG5ldmVyIGludmVudHMgaXQuXG4gICAgY29uc3QgeyBjb250YWluZXIgfSA9IGF3YWl0IHJlbmRlckFnZW50KHsgd3JpdGFibGU6IHRydWUgfSk7XG4gICAgYXdhaXQgcHVzaCh7IHR5cGU6ICdsbG0tcHJvdmlkZXInLCBwcm92aWRlcjogbnVsbCwgdW5ncmFudGVkOiB0cnVlIH0pO1xuICAgIGF3YWl0IHB1c2goeyB0eXBlOiAnYXBpLWNhdGFsb2cnLCBtZXRob2RzOiBbXSB9KTtcbiAgICBhd2FpdCBvcGVuUGFuZWwoY29udGFpbmVyKTtcbiAgICBjb25zdCB0ZXh0ID0gY29udGFpbmVyLnRleHRDb250ZW50ID8/ICcnO1xuICAgIGV4cGVjdCh0ZXh0KS50b0NvbnRhaW4oXCJ0aGlzIEdyb3ZlIHdhc24ndCBncmFudGVkIGNoYXQg4oCUIHJlYWRpbmcgd29ya3MgYXMgbm9ybWFsXCIpO1xuICAgIGV4cGVjdCh0ZXh0KS5ub3QudG9Db250YWluKCdhZGQgb25lIGluIFNldHRpbmdzJyk7IC8vIHRoZSBLRVkgY29weSDigJQgbmV2ZXIgY29uZmxhdGVkIChHLUdBLTEwKVxuICB9KTtcblxuICBpdCgnUi1HQS02IOKAlCB0aGUgZWdyZXNzIGRpc2Nsb3N1cmUgc2hvd3Mgd2hlbmV2ZXIgYSBwcm92aWRlciBpcyBib3VuZCcsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCB7IGNvbnRhaW5lciB9ID0gYXdhaXQgcmVuZGVyQWdlbnQoeyB3cml0YWJsZTogZmFsc2UgfSk7XG4gICAgYXdhaXQgcHVzaCh7XG4gICAgICB0eXBlOiAnbGxtLXByb3ZpZGVyJyxcbiAgICAgIHByb3ZpZGVyOiB7XG4gICAgICAgIHByb3ZpZGVySWQ6ICdsbG0uY2hhdC5hbnRocm9waWMnLFxuICAgICAgICBob3N0Vm91Y2hlZDogdHJ1ZSxcbiAgICAgICAgZmVhdHVyZXM6IHsgdmlzaW9uOiBmYWxzZSwgdG9vbHM6IHRydWUsIGpzb25Nb2RlOiB0cnVlLCByZWFzb25pbmc6IGZhbHNlLCBtYXhDb250ZXh0VG9rZW5zOiAxMDAwMDAgfSxcbiAgICAgIH0sXG4gICAgfSk7XG4gICAgYXdhaXQgcHVzaCh7IHR5cGU6ICdhcGktY2F0YWxvZycsIG1ldGhvZHM6IFt7IG5hbWU6ICdsbG06Y2hhdCcsIGNhcGFiaWxpdHk6ICdsbG06Y2hhdCcsIHN0cmVhbTogdHJ1ZSB9XSB9KTtcbiAgICBhd2FpdCBvcGVuUGFuZWwoY29udGFpbmVyKTtcbiAgICBleHBlY3QoY29udGFpbmVyLnRleHRDb250ZW50KS50b0NvbnRhaW4oJ2Fuc3dlcnMgY29tZSBmcm9tIHlvdXIgY29ubmVjdGVkIG1vZGVsIHByb3ZpZGVyJyk7XG4gIH0pO1xuXG4gIC8vIFIzLTc1MiDigJQgdGhlIGFwcGx5IHJvdyBpcyBhIERFU1RJTkFUSU9OOiBg4oaSYCBvbiB0aGUgcm93LCBubyDinJcgYW55d2hlcmUgb24gdGhlXG4gIC8vIGNhcmQsIGFuZCBldmVyeSByb3cncyBzdGF0ZSBpcyB0ZXh0IGFzIHdlbGwgYXMgZ2x5cGguXG4gIGl0KCdSMy03NTIg4oCUIHJlYWQtb25seSArIGNvbmZpZ3VyZWQgZ3JhbnRlZCBwcm92aWRlcjogdGhlIGFwcGx5IHJvdyByZW5kZXJzIOKGkiBlbHNld2hlcmUsIG5ldmVyIOKclywgd2l0aCBoaWRkZW4gc3RhdGUgd29yZHMnLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgeyBjb250YWluZXIgfSA9IGF3YWl0IHJlbmRlckFnZW50KHsgd3JpdGFibGU6IGZhbHNlIH0pO1xuICAgIGF3YWl0IHB1c2goe1xuICAgICAgdHlwZTogJ2xsbS1wcm92aWRlcicsXG4gICAgICBwcm92aWRlcjoge1xuICAgICAgICBwcm92aWRlcklkOiAnbGxtLmNoYXQuYW50aHJvcGljJyxcbiAgICAgICAgaG9zdFZvdWNoZWQ6IHRydWUsXG4gICAgICAgIGZlYXR1cmVzOiB7IHZpc2lvbjogZmFsc2UsIHRvb2xzOiB0cnVlLCBqc29uTW9kZTogdHJ1ZSwgcmVhc29uaW5nOiBmYWxzZSwgbWF4Q29udGV4dFRva2VuczogMTAwMDAwIH0sXG4gICAgICB9LFxuICAgIH0pO1xuICAgIGF3YWl0IHB1c2goeyB0eXBlOiAnYXBpLWNhdGFsb2cnLCBtZXRob2RzOiBbeyBuYW1lOiAnbGxtOmNoYXQnLCBjYXBhYmlsaXR5OiAnbGxtOmNoYXQnLCBzdHJlYW06IHRydWUgfV0gfSk7XG4gICAgYXdhaXQgb3BlblBhbmVsKGNvbnRhaW5lcik7XG4gICAgY29uc3QgY2FyZCA9IGNvbnRhaW5lci5xdWVyeVNlbGVjdG9yKCcuZ2EtcmVhY2gnKSE7XG4gICAgY29uc3QgYXBwbHlSb3cgPSBjYXJkLnF1ZXJ5U2VsZWN0b3IoJy5nYS1yZWFjaF9fcm93LS1lbHNld2hlcmUnKSE7XG4gICAgZXhwZWN0KGFwcGx5Um93LnRleHRDb250ZW50KS50b0NvbnRhaW4oJ0FwcGx5IGNoYW5nZXMnKTtcbiAgICBleHBlY3QoYXBwbHlSb3cudGV4dENvbnRlbnQpLnRvQ29udGFpbign4oaSIGluIHRoZSBlZGl0b3Igb3Igd29ya2JlbmNoLCB3aGVyZSB5b3UgY29uZmlybSB0aGVtJyk7XG4gICAgLy8gQSBkZXN0aW5hdGlvbiBpcyBuZXZlciByZW5kZXJlZCBhcyBhIGRlbmlhbDogdGhlIGNhcmQncyBvbmx5IOKclyBpcyB0aGUgZHJhZnRcbiAgICAvLyByb3cncyAocmVhZC1vbmx5KSwgdGhlIGFwcGx5IHJvdydzIG1hcmsgaXMgdGhlIGFycm93LlxuICAgIGV4cGVjdChhcHBseVJvdy5xdWVyeVNlbGVjdG9yKCcuZ2EtcmVhY2hfX21hcmsnKSEudGV4dENvbnRlbnQpLnRvQmUoJ+KGkicpO1xuICAgIGV4cGVjdChjYXJkLnRleHRDb250ZW50KS5ub3QudG9Db250YWluKCdjaGFuZ2VzIG9wZW4gaW4gdGhlIGVkaXRvcicpOyAvLyB0aGUgb2xkIGNhdXNlIGNvcHkgaXMgZ29uZVxuICAgIC8vIFN0YXRlIGlzIHRleHQsIG5ldmVyIGdseXBoIGFsb25lOiB0aGUgaGlkZGVuIHdvcmRzIGFyZSBpbiB0aGUgdHJlZS5cbiAgICBjb25zdCB3b3JkcyA9IFsuLi5jYXJkLnF1ZXJ5U2VsZWN0b3JBbGwoJy5nYS1yZWFjaF9fc3RhdGV3b3JkJyldLm1hcCgobikgPT4gbi50ZXh0Q29udGVudCk7XG4gICAgZXhwZWN0KHdvcmRzKS50b0NvbnRhaW4oJ2F2YWlsYWJsZScpO1xuICAgIGV4cGVjdCh3b3JkcykudG9Db250YWluKCd1bmF2YWlsYWJsZScpO1xuICAgIGV4cGVjdCh3b3JkcykudG9Db250YWluKCdvcGVucyBlbHNld2hlcmUnKTtcbiAgICAvLyBUaGUgc3Vic3RyYXRlIGlzIGNvbnRleHQsIHN0YXRlZCwgd2l0aCB0aGUgZ2l0LWluZGV0ZXJtaW5hdGUgdHJ1c3QgbGluZSB1bmRlclxuICAgIC8vIHRoZSBjYXJkICh0aGUgU0RLJ3MgZmFpbC1jbG9zZWQgZGVmYXVsdCBiYXNpcykuXG4gICAgZXhwZWN0KGNhcmQudGV4dENvbnRlbnQpLnRvQ29udGFpbignUmVhZHMgaXRzIG93biBlbnRyaWVzJyk7XG4gICAgZXhwZWN0KGNhcmQucGFyZW50RWxlbWVudCEudGV4dENvbnRlbnQpLnRvQ29udGFpbignYW55b25lIHdobyBjYW4gcHVzaCB0byB0aGlzIHJlcG8gY2FuIGNoYW5nZSB3aGF0IHRoZSBhZ2VudCByZWFkcycpO1xuICB9KTtcblxuICBpdCgnUjMtNzUyIOKAlCBhIGdyYW50IGZsaXAgaXMgQU5OT1VOQ0VELCBub3Qgb25seSByZS1yZW5kZXJlZCAoUi1JWC03KTogdGhlIHN0YW5kaW5nIGxpdmUgcmVnaW9uIHRyYWNrcyB0aGUgY2FyZCcsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCB7IGNvbnRhaW5lciB9ID0gYXdhaXQgcmVuZGVyQWdlbnQoeyB3cml0YWJsZTogZmFsc2UgfSk7XG4gICAgYXdhaXQgcHVzaCh7XG4gICAgICB0eXBlOiAnbGxtLXByb3ZpZGVyJyxcbiAgICAgIHByb3ZpZGVyOiB7XG4gICAgICAgIHByb3ZpZGVySWQ6ICdsbG0uY2hhdC5hbnRocm9waWMnLFxuICAgICAgICBob3N0Vm91Y2hlZDogdHJ1ZSxcbiAgICAgICAgZmVhdHVyZXM6IHsgdmlzaW9uOiBmYWxzZSwgdG9vbHM6IHRydWUsIGpzb25Nb2RlOiB0cnVlLCByZWFzb25pbmc6IGZhbHNlLCBtYXhDb250ZXh0VG9rZW5zOiAxMDAwMDAgfSxcbiAgICAgIH0sXG4gICAgfSk7XG4gICAgYXdhaXQgcHVzaCh7IHR5cGU6ICdhcGktY2F0YWxvZycsIG1ldGhvZHM6IFtdIH0pOyAvLyBrZXksIGJ1dCBOT1QgZ3JhbnRlZCBjaGF0XG4gICAgYXdhaXQgb3BlblBhbmVsKGNvbnRhaW5lcik7XG4gICAgY29uc3QgbGl2ZSA9IGNvbnRhaW5lci5xdWVyeVNlbGVjdG9yKCdbcm9sZT1cInN0YXR1c1wiXS5nYS1yZWFjaF9fc3RhdGV3b3JkJykhO1xuICAgIGV4cGVjdChsaXZlLmdldEF0dHJpYnV0ZSgnYXJpYS1saXZlJykgPz8gJ3BvbGl0ZScpLnRvQmUoJ3BvbGl0ZScpOyAvLyByb2xlPXN0YXR1cyBpcyBwb2xpdGUgYnkgZGVmYXVsdFxuICAgIGV4cGVjdChsaXZlLnRleHRDb250ZW50KS50b0NvbnRhaW4oJ3VuYXZhaWxhYmxlJyk7IC8vIHRoZSBibG9ja2VkIFEmQSByb3csIGluIHdvcmRzXG5cbiAgICAvLyBHcmFudCBjaGF0OiB0aGUgZmxpcCBtdXN0IGNoYW5nZSB0aGUgYW5ub3VuY2VtZW50IOKAlCB0aGUgUSZBIHNlZ21lbnQgZ29lc1xuICAgIC8vIHVuYXZhaWxhYmxlIOKGkiBhdmFpbGFibGUgKHRoZSBkcmFmdCByb3cgc3RheXMgaG9uZXN0bHkgdW5hdmFpbGFibGU7IHJlYWQtb25seSkuXG4gICAgYXdhaXQgcHVzaCh7IHR5cGU6ICdhcGktY2F0YWxvZycsIG1ldGhvZHM6IFt7IG5hbWU6ICdsbG06Y2hhdCcsIGNhcGFiaWxpdHk6ICdsbG06Y2hhdCcsIHN0cmVhbTogdHJ1ZSB9XSB9KTtcbiAgICBleHBlY3QobGl2ZS50ZXh0Q29udGVudCkudG9Db250YWluKCdBbnN3ZXIgcXVlc3Rpb25zIGFib3V0IHRoaXMgd2lraSDigJQgYXZhaWxhYmxlJyk7XG4gICAgZXhwZWN0KGxpdmUudGV4dENvbnRlbnQpLm5vdC50b0NvbnRhaW4oJ0Fuc3dlciBxdWVzdGlvbnMgYWJvdXQgdGhpcyB3aWtpIOKAlCB1bmF2YWlsYWJsZScpO1xuICB9KTtcblxuICBpdCgnUjMtNzUyIOKAlCBhIGNvbmZpZ3VyZWQgcHJvdmlkZXIgV0lUSE9VVCB0b29scyBrZWVwcyBRJkEg4pyTIGFuZCBzaG93cyB0aGUgZGVncmFkZSBxdWFsaWZpZXIsIG5vdCBzaWxlbmNlJywgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHsgY29udGFpbmVyIH0gPSBhd2FpdCByZW5kZXJBZ2VudCh7IHdyaXRhYmxlOiBmYWxzZSB9KTtcbiAgICBhd2FpdCBwdXNoKHtcbiAgICAgIHR5cGU6ICdsbG0tcHJvdmlkZXInLFxuICAgICAgcHJvdmlkZXI6IHtcbiAgICAgICAgcHJvdmlkZXJJZDogJ2xsbS5jaGF0LmFudGhyb3BpYycsXG4gICAgICAgIGhvc3RWb3VjaGVkOiB0cnVlLFxuICAgICAgICBmZWF0dXJlczogeyB2aXNpb246IGZhbHNlLCB0b29sczogZmFsc2UsIGpzb25Nb2RlOiB0cnVlLCByZWFzb25pbmc6IGZhbHNlLCBtYXhDb250ZXh0VG9rZW5zOiAxMDAwMDAgfSxcbiAgICAgIH0sXG4gICAgfSk7XG4gICAgYXdhaXQgcHVzaCh7IHR5cGU6ICdhcGktY2F0YWxvZycsIG1ldGhvZHM6IFt7IG5hbWU6ICdsbG06Y2hhdCcsIGNhcGFiaWxpdHk6ICdsbG06Y2hhdCcsIHN0cmVhbTogdHJ1ZSB9XSB9KTtcbiAgICBhd2FpdCBvcGVuUGFuZWwoY29udGFpbmVyKTtcbiAgICBjb25zdCBhbnN3ZXJSb3cgPSBjb250YWluZXIucXVlcnlTZWxlY3RvcignLmdhLXJlYWNoX19yb3ctLW9rJykhO1xuICAgIGV4cGVjdChhbnN3ZXJSb3cudGV4dENvbnRlbnQpLnRvQ29udGFpbignQW5zd2VyIHF1ZXN0aW9ucyBhYm91dCB0aGlzIHdpa2knKTtcbiAgICBleHBlY3QoYW5zd2VyUm93LnRleHRDb250ZW50KS50b0NvbnRhaW4oJ3JlYWRzIGEgc3VtbWFyeSBvZiB0aGlzIHdpa2ksIG5vdCBlbnRyaWVzIG9uIGRlbWFuZCcpO1xuICB9KTtcbn0pO1xuXG5kZXNjcmliZSgnUjMtNjA4IOKAlCB0aGUgY29tcG9zZXIgc3RvcHMgdGhlIHJ1bjsgYSByZWZ1c2FsIHN1cmZhY2VzLCBhIGNhbmNlbCBkb2VzIG5vdCcsICgpID0+IHtcbiAgYmVmb3JlQWxsKCgpID0+IHtcbiAgICAvLyBqc2RvbSBsYWNrcyBFbGVtZW50LnNjcm9sbFRvOyB0aGUgYXV0by1zY3JvbGwgZWZmZWN0IG9ubHkgbmVlZHMgdG8gYmUgYSBuby1vcC5cbiAgICBIVE1MRWxlbWVudC5wcm90b3R5cGUuc2Nyb2xsVG8gPSAoKSA9PiB1bmRlZmluZWQgYXMgdW5rbm93biBhcyB2b2lkO1xuICB9KTtcbiAgY29uc3QgY29uZmlndXJlZCA9IHtcbiAgICB0eXBlOiAnbGxtLXByb3ZpZGVyJyxcbiAgICBwcm92aWRlcjoge1xuICAgICAgcHJvdmlkZXJJZDogJ2xsbS5jaGF0LmFudGhyb3BpYycsXG4gICAgICBob3N0Vm91Y2hlZDogdHJ1ZSxcbiAgICAgIGZlYXR1cmVzOiB7IHZpc2lvbjogZmFsc2UsIHRvb2xzOiB0cnVlLCBqc29uTW9kZTogdHJ1ZSwgcmVhc29uaW5nOiBmYWxzZSwgbWF4Q29udGV4dFRva2VuczogMTAwMDAwIH0sXG4gICAgfSxcbiAgfSBhcyBjb25zdDtcbiAgY29uc3QgZ3JhbnRlZCA9IHtcbiAgICB0eXBlOiAnYXBpLWNhdGFsb2cnLFxuICAgIG1ldGhvZHM6IFt7IG5hbWU6ICdsbG06Y2hhdCcsIGNhcGFiaWxpdHk6ICdsbG06Y2hhdCcsIHN0cmVhbTogdHJ1ZSB9XSxcbiAgfSBhcyBjb25zdDtcblxuICBpdCgnc3RvcCBhYm9ydHMgdGhlIGluLWZsaWdodCBydW4g4oCUIHNpZ25hbCBhYm9ydGVkLCBzdHJlYW1pbmcgY2xlYXJlZCwgYSBTdG9wcGVkIHJvdywgbm8gZXJyb3InLCBhc3luYyAoKSA9PiB7XG4gICAgLy8gVGhlIFJFQUwgbG9vcCBjb250cmFjdCBvbiBhYm9ydDogdGhlIHByb21pc2UgUkVTT0xWRVMgd2l0aCB0aGUgcGFydGlhbFxuICAgIC8vIHRyYW5zY3JpcHQgKGEgY2xlYW4gc3RvcCwgbmV2ZXIgYSB0aHJvd24gZXJyb3IpIOKAlCB0aGUgbW9jayBtaXJyb3JzIGl0LlxuICAgIHJ1bkFnZW50TW9jay5tb2NrSW1wbGVtZW50YXRpb25PbmNlKFxuICAgICAgKG9wdHM6IHsgc2lnbmFsPzogQWJvcnRTaWduYWwgfSkgPT5cbiAgICAgICAgbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICAgICAgICBvcHRzLnNpZ25hbD8uYWRkRXZlbnRMaXN0ZW5lcignYWJvcnQnLCAoKSA9PlxuICAgICAgICAgICAgcmVzb2x2ZShbXG4gICAgICAgICAgICAgIHsgcm9sZTogJ3VzZXInLCBjb250ZW50OiAnd2hhdCBpcyBoZXJlPycgfSxcbiAgICAgICAgICAgICAgeyByb2xlOiAnYXNzaXN0YW50JywgY29udGVudDogJ3BhcnRpYWwgYW5zd2VyJyB9LFxuICAgICAgICAgICAgXSksXG4gICAgICAgICAgKTtcbiAgICAgICAgfSksXG4gICAgKTtcbiAgICBjb25zdCB7IGNvbnRhaW5lciB9ID0gYXdhaXQgcmVuZGVyQWdlbnQoeyB3cml0YWJsZTogZmFsc2UgfSk7XG4gICAgYXdhaXQgcHVzaChjb25maWd1cmVkKTtcbiAgICBhd2FpdCBwdXNoKGdyYW50ZWQpO1xuICAgIGF3YWl0IG9wZW5QYW5lbChjb250YWluZXIpO1xuICAgIGNvbnN0IGlucHV0ID0gY29udGFpbmVyLnF1ZXJ5U2VsZWN0b3IoJy5nYS1mb290IGlucHV0JykgYXMgSFRNTElucHV0RWxlbWVudDtcbiAgICBhd2FpdCBhY3QoYXN5bmMgKCkgPT4ge1xuICAgICAgLy8gVGhlIG5hdGl2ZSB2YWx1ZSBzZXR0ZXI6IFJlYWN0J3MgdHJhY2tlciBpZ25vcmVzIGEgYmFyZSAudmFsdWUgYXNzaWduLlxuICAgICAgY29uc3Qgc2V0dGVyID0gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihIVE1MSW5wdXRFbGVtZW50LnByb3RvdHlwZSwgJ3ZhbHVlJykhLnNldCE7XG4gICAgICBzZXR0ZXIuY2FsbChpbnB1dCwgJ3doYXQgaXMgaGVyZT8nKTtcbiAgICAgIGlucHV0LmRpc3BhdGNoRXZlbnQobmV3IEV2ZW50KCdpbnB1dCcsIHsgYnViYmxlczogdHJ1ZSB9KSk7XG4gICAgfSk7XG4gICAgYXdhaXQgYWN0KGFzeW5jICgpID0+IHtcbiAgICAgIChjb250YWluZXIucXVlcnlTZWxlY3RvcignLmdhLWZvb3QgLmdvJykgYXMgSFRNTEVsZW1lbnQpLmNsaWNrKCk7XG4gICAgfSk7XG4gICAgLy8gU3RyZWFtaW5nOiB0aGUgc3RvcCBjb250cm9sIGV4aXN0cyBhbmQgdGhlIHNlbmQgaXMgc3BlbnQuXG4gICAgY29uc3Qgc3RvcCA9IGNvbnRhaW5lci5xdWVyeVNlbGVjdG9yKCcuZ2EtZm9vdCAuc3RvcCcpIGFzIEhUTUxFbGVtZW50O1xuICAgIGV4cGVjdChzdG9wKS50b0JlVHJ1dGh5KCk7XG4gICAgbGV0IHNpZ25hbDogQWJvcnRTaWduYWwgfCB1bmRlZmluZWQ7XG4gICAgcnVuQWdlbnRNb2NrLm1vY2suY2FsbHMuZm9yRWFjaCgoYykgPT4ge1xuICAgICAgc2lnbmFsID0gKGNbMF0gYXMgeyBzaWduYWw/OiBBYm9ydFNpZ25hbCB9KS5zaWduYWw7XG4gICAgfSk7XG4gICAgZXhwZWN0KHNpZ25hbCkudG9CZVRydXRoeSgpO1xuICAgIGF3YWl0IGFjdChhc3luYyAoKSA9PiB7XG4gICAgICBzdG9wLmNsaWNrKCk7XG4gICAgfSk7XG4gICAgZXhwZWN0KHNpZ25hbCEuYWJvcnRlZCkudG9CZSh0cnVlKTtcbiAgICBleHBlY3QoY29udGFpbmVyLnRleHRDb250ZW50KS50b0NvbnRhaW4oJ1N0b3BwZWQnKTtcbiAgICBleHBlY3QoY29udGFpbmVyLnRleHRDb250ZW50KS5ub3QudG9Db250YWluKCd0aGUgbW9kZWwgb3IgYmFja2VuZCBlcnJvcmVkJyk7XG4gICAgZXhwZWN0KGNvbnRhaW5lci5xdWVyeVNlbGVjdG9yKCcuZ2EtZm9vdCAuc3RvcCcpKS50b0JlTnVsbCgpO1xuICB9KTtcblxuICBpdCgnYSBSRUZVU0lORyBlZGl0IHJlbmRlcnMgdGhlIGZhaWx1cmUgdGV4dDsgYSBjYW5jZWxsZWQgb25lIHJlbmRlcnMgbm90aGluZycsIGFzeW5jICgpID0+IHtcbiAgICAvLyBUaGUgcmVhbCBob29rLCB0aHJvdWdoIHRoZSByZWFsIHJlcXVlc3RFZGl0IOKGkiB0aGUgY29udHJvbGxhYmxlIHRyYW5zcG9ydC5cbiAgICBjb25zdCB7IHVzZUVkaXRBZmZvcmRhbmNlIH0gPSBhd2FpdCBpbXBvcnQoJy4uL2hvb2tzL3VzZUVkaXRBZmZvcmRhbmNlJyk7XG4gICAgY29uc3QgcmVmdXNlZFN0YXRlczogYm9vbGVhbltdID0gW107XG4gICAgZnVuY3Rpb24gUHJvYmUoKSB7XG4gICAgICBjb25zdCBhZmYgPSB1c2VFZGl0QWZmb3JkYW5jZShmYWxzZSk7XG4gICAgICByZWZ1c2VkU3RhdGVzLnB1c2goYWZmLnJlZnVzZWQpO1xuICAgICAgcmV0dXJuIChcbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IGFmZi5vcGVuRWRpdG9yKCcvYXBwL2NvbnRlbnQvd2lraS9zZWN1cml0eS5tZHgnKX0+ZWRpdDwvYnV0dG9uPlxuICAgICAgICAgIDxkaXYgZGF0YS10ZXN0aWQ9XCJyZWZ1c2VkXCI+e2FmZi5yZWZ1c2VkID8gJ1JFRlVTRUQnIDogJyd9PC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKTtcbiAgICB9XG4gICAgY29uc3QgaG9zdCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoaG9zdCk7XG4gICAgY29uc3Qgcm9vdCA9IGNyZWF0ZVJvb3QoaG9zdCk7XG4gICAgYXdhaXQgYWN0KGFzeW5jICgpID0+IHtcbiAgICAgIHJvb3QucmVuZGVyKDxQcm9iZSAvPik7XG4gICAgfSk7XG5cbiAgICAvLyBBIHJlZnVzYWwgKGFueXRoaW5nIG5vdCBgY2FuY2VsbGVkYCk6IHRoZSBob3N0IHNhaWQgbm8g4oCUIGl0IG11c3Qgc3VyZmFjZS5cbiAgICBwcm90b2NvbFJlcXVlc3QubW9ja1JlamVjdGVkVmFsdWVPbmNlKE9iamVjdC5hc3NpZ24obmV3IEVycm9yKCdkZW5pZWQnKSwgeyBjb2RlOiAnZm9yYmlkZGVuJyB9KSk7XG4gICAgYXdhaXQgYWN0KGFzeW5jICgpID0+IHtcbiAgICAgIChob3N0LnF1ZXJ5U2VsZWN0b3IoJ2J1dHRvbicpIGFzIEhUTUxFbGVtZW50KS5jbGljaygpO1xuICAgIH0pO1xuICAgIGV4cGVjdChob3N0LnF1ZXJ5U2VsZWN0b3IoJ1tkYXRhLXRlc3RpZD1cInJlZnVzZWRcIl0nKT8udGV4dENvbnRlbnQpLnRvQmUoJ1JFRlVTRUQnKTtcblxuICAgIC8vIEEgY2FuY2VsbGF0aW9uOiB0aGUgcmVhZGVyIGNsb3NlZCB0aGUgZWRpdG9yIOKAlCBzaWxlbnQgYnkgY29udHJhY3QuXG4gICAgYXdhaXQgYWN0KGFzeW5jICgpID0+IHtcbiAgICAgIHJvb3QucmVuZGVyKDxkaXYgLz4pO1xuICAgICAgcm9vdC5yZW5kZXIoPFByb2JlIC8+KTtcbiAgICB9KTtcbiAgICByZWZ1c2VkU3RhdGVzLmxlbmd0aCA9IDA7XG4gICAgcHJvdG9jb2xSZXF1ZXN0Lm1vY2tSZWplY3RlZFZhbHVlT25jZShPYmplY3QuYXNzaWduKG5ldyBFcnJvcignY2xvc2VkJyksIHsgY29kZTogJ2NhbmNlbGxlZCcgfSkpO1xuICAgIGF3YWl0IGFjdChhc3luYyAoKSA9PiB7XG4gICAgICAoaG9zdC5xdWVyeVNlbGVjdG9yKCdidXR0b24nKSBhcyBIVE1MRWxlbWVudCkuY2xpY2soKTtcbiAgICB9KTtcbiAgICBleHBlY3QoaG9zdC5xdWVyeVNlbGVjdG9yKCdbZGF0YS10ZXN0aWQ9XCJyZWZ1c2VkXCJdJyk/LnRleHRDb250ZW50KS50b0JlKCcnKTtcbiAgICBhd2FpdCBhY3QoYXN5bmMgKCkgPT4ge1xuICAgICAgcm9vdC51bm1vdW50KCk7XG4gICAgfSk7XG4gIH0pO1xuXG4gIGl0KCd0aGUgYWdlbnQgcGFuZWwgcmVuZGVycyB0aGUgcmVmdXNhbCB0ZXh0IHdoZXJlIHRoZSBhZmZvcmRhbmNlIGlzIG9mZmVyZWQnLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgeyByb290LCBjb250YWluZXI6IGhvc3QgfSA9IGF3YWl0IHJlbmRlckFnZW50KFxuICAgICAgeyB3cml0YWJsZTogZmFsc2UgfSxcbiAgICAgIHsgc2hlbGw6IHsgZWRpdFJlZnVzZWQ6IHRydWUgfSBhcyBQYXJ0aWFsPGltcG9ydCgnLi4vbGliL3NoZWxsJykuR3JvdmVTaGVsbD4gfSxcbiAgICApO1xuICAgIGF3YWl0IG9wZW5QYW5lbChob3N0KTtcbiAgICBleHBlY3QoaG9zdC50ZXh0Q29udGVudCkudG9Db250YWluKCdDb3VsZCBub3Qgb3BlbiB0aGUgZWRpdG9yIOKAlCB0aGUgaG9zdCByZWZ1c2VkJyk7XG4gICAgYXdhaXQgYWN0KGFzeW5jICgpID0+IHtcbiAgICAgIHJvb3QudW5tb3VudCgpO1xuICAgIH0pO1xuICB9KTtcbn0pO1xuXG5kZXNjcmliZSgnUjMtNjA4IHJvdW5kIDIg4oCUIHRoZSBwYW5lbCByZXR1cm5zIGZvY3VzIHRvIGl0cyAodW5tb3VudGVkKSB0cmlnZ2VyJywgKCkgPT4ge1xuICBpdCgnRXNjYXBlLWNsb3NlIGxhbmRzIGZvY3VzIGJhY2sgb24gdGhlIHJlc3RpbmcgaW5wdXQsIG5vdCA8Ym9keT4nLCBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgeyBjb250YWluZXIgfSA9IGF3YWl0IHJlbmRlckFnZW50KHsgd3JpdGFibGU6IGZhbHNlIH0pO1xuICAgIGF3YWl0IHB1c2goeyB0eXBlOiAnbGxtLXByb3ZpZGVyJywgcHJvdmlkZXI6IG51bGwgfSk7XG4gICAgYXdhaXQgcHVzaCh7IHR5cGU6ICdhcGktY2F0YWxvZycsIG1ldGhvZHM6IFtdIH0pO1xuICAgIC8vIE9wZW4gdGhyb3VnaCB0aGUgcmVzdGluZyBpbnB1dCAodGhlIHJlYWwgdHJpZ2dlciBwYXRoKS5cbiAgICBjb25zdCByZXN0aW5nID0gY29udGFpbmVyLnF1ZXJ5U2VsZWN0b3IoJy5nYS1saW5lIGlucHV0JykgYXMgSFRNTElucHV0RWxlbWVudDtcbiAgICBhd2FpdCBhY3QoYXN5bmMgKCkgPT4ge1xuICAgICAgcmVzdGluZy5mb2N1cygpO1xuICAgIH0pO1xuICAgIGV4cGVjdChjb250YWluZXIucXVlcnlTZWxlY3RvcignLmdhLXBhbmVsJykpLnRvQmVUcnV0aHkoKTtcbiAgICBhd2FpdCBhY3QoYXN5bmMgKCkgPT4ge1xuICAgICAgZG9jdW1lbnQuZGlzcGF0Y2hFdmVudChuZXcgS2V5Ym9hcmRFdmVudCgna2V5ZG93bicsIHsga2V5OiAnRXNjYXBlJywgYnViYmxlczogdHJ1ZSwgY2FuY2VsYWJsZTogdHJ1ZSB9KSk7XG4gICAgfSk7XG4gICAgZXhwZWN0KGNvbnRhaW5lci5xdWVyeVNlbGVjdG9yKCcuZ2EtcGFuZWwnKSkudG9CZU51bGwoKTtcbiAgICAvLyBUaGUgZm9jdXMgcmV0dXJuIHJpZGVzIGEgcmVxdWVzdEFuaW1hdGlvbkZyYW1lIOKAlCBmbHVzaCB0aGUgZnJhbWUuXG4gICAgYXdhaXQgYWN0KGFzeW5jICgpID0+IHtcbiAgICAgIGF3YWl0IG5ldyBQcm9taXNlKChyKSA9PiBzZXRUaW1lb3V0KHIsIDE2KSk7XG4gICAgfSk7XG4gICAgLy8gVGhlIHJlc3RpbmcgbGluZSByZW1vdW50ZWQgYW5kIGl0cyBTVUJNSVQgY29udHJvbCB0b29rIGZvY3VzIOKAlCBhIHJlYWxcbiAgICAvLyBzdG9wIHRoYXQgY2Fubm90IHJlb3BlbiB0aGUgcGFuZWwsIG5ldmVyIDxib2R5Pi5cbiAgICBjb25zdCByZW1vdW50ZWQgPSBjb250YWluZXIucXVlcnlTZWxlY3RvcignLmdhLWxpbmUgLmdvJykgYXMgSFRNTEJ1dHRvbkVsZW1lbnQ7XG4gICAgZXhwZWN0KHJlbW91bnRlZCkudG9CZVRydXRoeSgpO1xuICAgIGV4cGVjdChkb2N1bWVudC5hY3RpdmVFbGVtZW50KS50b0JlKHJlbW91bnRlZCk7XG4gICAgZXhwZWN0KGNvbnRhaW5lci5xdWVyeVNlbGVjdG9yKCcuZ2EtcGFuZWwnKSkudG9CZU51bGwoKTsgLy8gZm9jdXMgZGlkIG5vdCByZW9wZW5cbiAgfSk7XG59KTtcblxuLy8g4pSA4pSAIFIzLTc5MCDigJQgdGhlIHVuZ3JhbnRlZCBjaGF0IHJvdydzIGVhcm5pbmcgYWZmb3JkYW5jZSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuZGVzY3JpYmUoXCJSMy03OTAg4oCUIHRoZSDinJcgY2hhdCByb3cgb2ZmZXJzIGl0cyBlYXJuaW5nIGFmZm9yZGFuY2UgKGNsaWNrIGludm9rZXM7IHRoZSBob3N0IGdlc3R1cmUgbWludHMpXCIsICgpID0+IHtcbiAgYmVmb3JlQWxsKCgpID0+IHtcbiAgICBIVE1MRWxlbWVudC5wcm90b3R5cGUuc2Nyb2xsVG8gPSAoKSA9PiB1bmRlZmluZWQgYXMgdW5rbm93biBhcyB2b2lkO1xuICB9KTtcblxuICBpdCgncmVuZGVycyBFbmFibGUgY2hhdCBvbiB0aGUgdW5ncmFudGVkIHJvdyDigJQgdGhlIGhvc3QtbWFya2VkIGZvcmJpZGRlbiBjYXVzZScsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCB7IGNvbnRhaW5lciB9ID0gYXdhaXQgcmVuZGVyQWdlbnQoeyB3cml0YWJsZTogZmFsc2UgfSk7XG4gICAgLy8gVGhlIGNvbGQgbWFyayDigJQgbm8gcHJpb3IgY29uZmlndXJlZCBwdXNoOiB0aGUgaG9zdCBzdHJpcHMgdGhlIHByb3ZpZGVyIGZyb21cbiAgICAvLyBldmVyeSBhbnN3ZXIgdG8gYW4gdW5ncmFudGVkIGZyYW1lICh0aGUgUjMtNjg4IHRlc3QncyBzaGFwZSkuXG4gICAgYXdhaXQgcHVzaCh7IHR5cGU6ICdsbG0tcHJvdmlkZXInLCBwcm92aWRlcjogbnVsbCwgdW5ncmFudGVkOiB0cnVlIH0pO1xuICAgIGF3YWl0IHB1c2goeyB0eXBlOiAnYXBpLWNhdGFsb2cnLCBtZXRob2RzOiBbXSB9KTsgLy8gYW5zd2VyZWQ6IG5vdGhpbmcgZ3JhbnRlZFxuICAgIGF3YWl0IG9wZW5QYW5lbChjb250YWluZXIpO1xuICAgIGNvbnN0IGVuYWJsZSA9IGNvbnRhaW5lci5xdWVyeVNlbGVjdG9yKCcuZ2EtcmVhY2hfX2VuYWJsZScpO1xuICAgIGV4cGVjdChlbmFibGUpLnRvQmVUcnV0aHkoKTsgLy8gdGhlIGFmZm9yZGFuY2UgZXhpc3RzIG9uIHRoZSDinJcgcm93XG4gICAgZXhwZWN0KChlbmFibGUgYXMgSFRNTEVsZW1lbnQpLnRleHRDb250ZW50KS50b0JlKCdFbmFibGUgY2hhdCcpO1xuICAgIC8vIOKApmFuZCB0aGUgcm93IGl0c2VsZiBzdGlsbCB0ZWxscyB0aGUgaG9uZXN0IGNhdXNlLlxuICAgIGV4cGVjdChjb250YWluZXIucXVlcnlTZWxlY3RvcignLmdhLXJlYWNoX19yb3ctLWJsb2NrZWQnKT8udGV4dENvbnRlbnQpLnRvQ29udGFpbihcbiAgICAgIFwidGhpcyBHcm92ZSB3YXNuJ3QgZ3JhbnRlZCBjaGF0XCIsXG4gICAgKTtcbiAgfSk7XG5cbiAgaXQoJ3JlbmRlcnMgTk8gYWZmb3JkYW5jZSB3aGVuIHRoZSBwcm92aWRlciBpcyBub3QgY29uZmlndXJlZCAodGhhdCByb3cgcG9pbnRzIGF0IFNldHRpbmdzKScsIGFzeW5jICgpID0+IHtcbiAgICBjb25zdCB7IGNvbnRhaW5lciB9ID0gYXdhaXQgcmVuZGVyQWdlbnQoeyB3cml0YWJsZTogZmFsc2UgfSk7XG4gICAgYXdhaXQgcHVzaCh7IHR5cGU6ICdsbG0tcHJvdmlkZXInLCBwcm92aWRlcjogbnVsbCB9KTsgLy8gbm90LWNvbmZpZ3VyZWQsIG5vdCB1bmdyYW50ZWRcbiAgICBhd2FpdCBwdXNoKHsgdHlwZTogJ2FwaS1jYXRhbG9nJywgbWV0aG9kczogW10gfSk7XG4gICAgYXdhaXQgb3BlblBhbmVsKGNvbnRhaW5lcik7XG4gICAgZXhwZWN0KGNvbnRhaW5lci5xdWVyeVNlbGVjdG9yKCcuZ2EtcmVhY2hfX2VuYWJsZScpKS50b0JlTnVsbCgpO1xuICB9KTtcblxuICBpdChcImEgY2xpY2sgaW52b2tlczsgYSBERUNMSU5FRCBkaWFsb2cgKCdjYW5jZWxsZWQnKSBrZWVwcyB0aGUgaG9uZXN0IHJvdyBhbmQgc2F5cyBzb1wiLCBhc3luYyAoKSA9PiB7XG4gICAgcnVuQWdlbnRNb2NrLm1vY2tDbGVhcigpO1xuICAgIHJ1bkFnZW50TW9jay5tb2NrSW1wbGVtZW50YXRpb25PbmNlKCgpID0+IHtcbiAgICAgIGNvbnN0IGUgPSBuZXcgRXJyb3IoJ2RlY2xpbmVkJykgYXMgRXJyb3IgJiB7IGNvZGU/OiBzdHJpbmcgfTtcbiAgICAgIGUuY29kZSA9ICdjYW5jZWxsZWQnO1xuICAgICAgdGhyb3cgZTtcbiAgICB9KTtcbiAgICBjb25zdCB7IGNvbnRhaW5lciB9ID0gYXdhaXQgcmVuZGVyQWdlbnQoeyB3cml0YWJsZTogZmFsc2UgfSk7XG4gICAgLy8gVGhlIGNvbGQgbWFyayDigJQgbm8gcHJpb3IgY29uZmlndXJlZCBwdXNoOiB0aGUgaG9zdCBzdHJpcHMgdGhlIHByb3ZpZGVyIGZyb21cbiAgICAvLyBldmVyeSBhbnN3ZXIgdG8gYW4gdW5ncmFudGVkIGZyYW1lICh0aGUgUjMtNjg4IHRlc3QncyBzaGFwZSkuXG4gICAgYXdhaXQgcHVzaCh7IHR5cGU6ICdsbG0tcHJvdmlkZXInLCBwcm92aWRlcjogbnVsbCwgdW5ncmFudGVkOiB0cnVlIH0pO1xuICAgIGF3YWl0IHB1c2goeyB0eXBlOiAnYXBpLWNhdGFsb2cnLCBtZXRob2RzOiBbXSB9KTtcbiAgICBhd2FpdCBvcGVuUGFuZWwoY29udGFpbmVyKTtcbiAgICBhd2FpdCBhY3QoYXN5bmMgKCkgPT4ge1xuICAgICAgKGNvbnRhaW5lci5xdWVyeVNlbGVjdG9yKCcuZ2EtcmVhY2hfX2VuYWJsZScpIGFzIEhUTUxCdXR0b25FbGVtZW50KS5jbGljaygpO1xuICAgIH0pO1xuICAgIC8vIFRoZSBpbnZva2UgUkFOIChydW5BZ2VudCB3YXMgY2FsbGVkIG9uY2Ug4oCUIHRoZSBnZXN0dXJlJ3MgdHJpZ2dlcinigKZcbiAgICBleHBlY3QocnVuQWdlbnRNb2NrKS50b0hhdmVCZWVuQ2FsbGVkVGltZXMoMSk7XG4gICAgLy8g4oCmdGhlIGRlY2xpbmUgc3VyZmFjZWQgaG9uZXN0bHnigKZcbiAgICBhd2FpdCBhY3QoYXN5bmMgKCkgPT4ge1xuICAgICAgYXdhaXQgbmV3IFByb21pc2UoKHIpID0+IHNldFRpbWVvdXQociwgMTYpKTtcbiAgICB9KTtcbiAgICBleHBlY3QoY29udGFpbmVyLnF1ZXJ5U2VsZWN0b3IoJy5nYS10b2FzdCcpPy50ZXh0Q29udGVudCkudG9Db250YWluKFwiY2hhdCBkaWRuJ3Qgc3RhcnQg4oCUIHJlYWRpbmcgd29ya3MgYXMgbm9ybWFsOyB5b3UgY2FuIHRyeSBhZ2FpbiBhbnl0aW1lXCIpO1xuICAgIC8vIOKApmFuZCB0aGUgcm93IHN0aWxsIHJlYWRzIHRoZSBmb3JiaWRkZW4gY2F1c2Ugd2l0aCB0aGUgYWZmb3JkYW5jZSBmb3IgdGhlIG5leHQgY2xpY2suXG4gICAgZXhwZWN0KGNvbnRhaW5lci5xdWVyeVNlbGVjdG9yKCcuZ2EtcmVhY2hfX3Jvdy0tYmxvY2tlZCcpPy50ZXh0Q29udGVudCkudG9Db250YWluKFxuICAgICAgXCJ0aGlzIEdyb3ZlIHdhc24ndCBncmFudGVkIGNoYXRcIixcbiAgICApO1xuICAgIGV4cGVjdChjb250YWluZXIucXVlcnlTZWxlY3RvcignLmdhLXJlYWNoX19lbmFibGUnKSkudG9CZVRydXRoeSgpO1xuICB9KTtcblxuICBpdCgnYSBjbGljayBpbnZva2VzOyBhIHN0aWxsLUZPUkJJRERFTiBhbnN3ZXIgc3VyZmFjZXMgdGhlIHJlZnVzYWwgdG9hc3QgKHByZS1nZXN0dXJlIGhvc3RzKScsIGFzeW5jICgpID0+IHtcbiAgICBydW5BZ2VudE1vY2subW9ja0ltcGxlbWVudGF0aW9uT25jZSgoKSA9PiB7XG4gICAgICBjb25zdCBlID0gbmV3IEVycm9yKCdmb3JiaWRkZW4nKSBhcyBFcnJvciAmIHsgY29kZT86IHN0cmluZyB9O1xuICAgICAgZS5jb2RlID0gJ2ZvcmJpZGRlbic7XG4gICAgICB0aHJvdyBlO1xuICAgIH0pO1xuICAgIGNvbnN0IHsgY29udGFpbmVyIH0gPSBhd2FpdCByZW5kZXJBZ2VudCh7IHdyaXRhYmxlOiBmYWxzZSB9KTtcbiAgICAvLyBUaGUgY29sZCBtYXJrIOKAlCBubyBwcmlvciBjb25maWd1cmVkIHB1c2g6IHRoZSBob3N0IHN0cmlwcyB0aGUgcHJvdmlkZXIgZnJvbVxuICAgIC8vIGV2ZXJ5IGFuc3dlciB0byBhbiB1bmdyYW50ZWQgZnJhbWUgKHRoZSBSMy02ODggdGVzdCdzIHNoYXBlKS5cbiAgICBhd2FpdCBwdXNoKHsgdHlwZTogJ2xsbS1wcm92aWRlcicsIHByb3ZpZGVyOiBudWxsLCB1bmdyYW50ZWQ6IHRydWUgfSk7XG4gICAgYXdhaXQgcHVzaCh7IHR5cGU6ICdhcGktY2F0YWxvZycsIG1ldGhvZHM6IFtdIH0pO1xuICAgIGF3YWl0IG9wZW5QYW5lbChjb250YWluZXIpO1xuICAgIGF3YWl0IGFjdChhc3luYyAoKSA9PiB7XG4gICAgICAoY29udGFpbmVyLnF1ZXJ5U2VsZWN0b3IoJy5nYS1yZWFjaF9fZW5hYmxlJykgYXMgSFRNTEJ1dHRvbkVsZW1lbnQpLmNsaWNrKCk7XG4gICAgfSk7XG4gICAgYXdhaXQgYWN0KGFzeW5jICgpID0+IHtcbiAgICAgIGF3YWl0IG5ldyBQcm9taXNlKChyKSA9PiBzZXRUaW1lb3V0KHIsIDE2KSk7XG4gICAgfSk7XG4gICAgZXhwZWN0KGNvbnRhaW5lci5xdWVyeVNlbGVjdG9yKCcuZ2EtdG9hc3QnKT8udGV4dENvbnRlbnQpLnRvQ29udGFpbihcInRoaXMgR3JvdmUgd2Fzbid0IGdyYW50ZWQgY2hhdFwiKTtcbiAgfSk7XG59KTtcblxuLy8g4pSA4pSAIFIzLTc5MCByb3VuZCAxIOKAlCB0aGUgR1JBTlRFRCBsZWc6IHRoZSBjbGljaydzIGludm9rZSBwcm9jZWVkcyB3aGVuIHRoZSBncmFudCBsYW5kcyDilIDilIBcblxuZGVzY3JpYmUoXCJSMy03OTAg4oCUIHRoZSBncmFudGVkIGxlZyAoY2xpY2sg4oaSIGludm9rZSDihpIgdGhlIGdyYW50IGxhbmRzIOKGkiB0aGUgYXNrIHByb2NlZWRzLCB0aGUgcm93IGZsaXBzKVwiLCAoKSA9PiB7XG4gIGJlZm9yZUFsbCgoKSA9PiB7XG4gICAgSFRNTEVsZW1lbnQucHJvdG90eXBlLnNjcm9sbFRvID0gKCkgPT4gdW5kZWZpbmVkIGFzIHVua25vd24gYXMgdm9pZDtcbiAgfSk7XG4gIGNvbnN0IGNvbmZpZ3VyZWQgPSB7XG4gICAgdHlwZTogJ2xsbS1wcm92aWRlcicsXG4gICAgcHJvdmlkZXI6IHtcbiAgICAgIHByb3ZpZGVySWQ6ICdsbG0uY2hhdC5hbnRocm9waWMnLFxuICAgICAgaG9zdFZvdWNoZWQ6IHRydWUsXG4gICAgICBmZWF0dXJlczogeyB2aXNpb246IGZhbHNlLCB0b29sczogdHJ1ZSwganNvbk1vZGU6IHRydWUsIHJlYXNvbmluZzogZmFsc2UsIG1heENvbnRleHRUb2tlbnM6IDEwMDAwMCB9LFxuICAgIH0sXG4gIH0gYXMgY29uc3Q7XG4gIGNvbnN0IGdyYW50ZWRDYXRhbG9nID0ge1xuICAgIHR5cGU6ICdhcGktY2F0YWxvZycsXG4gICAgbWV0aG9kczogW3sgbmFtZTogJ2xsbTpjaGF0JywgY2FwYWJpbGl0eTogJ2xsbTpjaGF0Jywgc3RyZWFtOiB0cnVlIH1dLFxuICB9IGFzIGNvbnN0O1xuXG4gIGl0KFwidGhlIGFmZm9yZGFuY2UncyBjbGljayBkcml2ZXMgdGhlIGludm9rZTsgdGhlIGdyYW50ZWQgY2F0YWxvZyBmbGlwcyB0aGUgcm93IOKckyBhbmQgdGhlIGlucHV0IGVuYWJsZXNcIiwgYXN5bmMgKCkgPT4ge1xuICAgIHJ1bkFnZW50TW9jay5tb2NrQ2xlYXIoKTtcbiAgICBydW5BZ2VudE1vY2subW9ja0ltcGxlbWVudGF0aW9uT25jZShhc3luYyAoKSA9PiBbXG4gICAgICB7XG4gICAgICAgIHJvbGU6ICd1c2VyJyxcbiAgICAgICAgY29udGVudDogW3sgdHlwZTogJ3RleHQnLCB0ZXh0OiAnQW5zd2VyIGluIG9uZSBzZW50ZW5jZTogd2hhdCBjYW4geW91IHRlbGwgbWUgYWJvdXQgdGhpcyB3aWtpPycgfV0sXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICByb2xlOiAnYXNzaXN0YW50JyxcbiAgICAgICAgY29udGVudDogW3sgdHlwZTogJ3RleHQnLCB0ZXh0OiAnVGhpcyB3aWtpIGlzIGEgc21hbGwgY29ycHVzIGFib3V0IGVuYWJsaW5nIGNoYXQuJyB9XSxcbiAgICAgIH0sXG4gICAgXSk7XG4gICAgY29uc3QgeyBjb250YWluZXIgfSA9IGF3YWl0IHJlbmRlckFnZW50KHsgd3JpdGFibGU6IGZhbHNlIH0pO1xuICAgIGF3YWl0IHB1c2goeyB0eXBlOiAnbGxtLXByb3ZpZGVyJywgcHJvdmlkZXI6IG51bGwsIHVuZ3JhbnRlZDogdHJ1ZSB9KTtcbiAgICBhd2FpdCBwdXNoKHsgdHlwZTogJ2FwaS1jYXRhbG9nJywgbWV0aG9kczogW10gfSk7XG4gICAgYXdhaXQgb3BlblBhbmVsKGNvbnRhaW5lcik7XG4gICAgLy8gQmVmb3JlOiB0aGUgaG9uZXN0IOKclyByb3cgKyB0aGUgYWZmb3JkYW5jZS5cbiAgICBleHBlY3QoY29udGFpbmVyLnF1ZXJ5U2VsZWN0b3IoJy5nYS1yZWFjaF9fcm93LS1ibG9ja2VkJyk/LnRleHRDb250ZW50KS50b0NvbnRhaW4oXG4gICAgICBcInRoaXMgR3JvdmUgd2Fzbid0IGdyYW50ZWQgY2hhdFwiLFxuICAgICk7XG4gICAgYXdhaXQgYWN0KGFzeW5jICgpID0+IHtcbiAgICAgIChjb250YWluZXIucXVlcnlTZWxlY3RvcignLmdhLXJlYWNoX19lbmFibGUnKSBhcyBIVE1MQnV0dG9uRWxlbWVudCkuY2xpY2soKTtcbiAgICB9KTtcbiAgICAvLyBUaGUgaW52b2tlIFJBTiAodGhlIGdlc3R1cmUncyB0cmlnZ2VyKS5cbiAgICBleHBlY3QocnVuQWdlbnRNb2NrKS50b0hhdmVCZWVuQ2FsbGVkVGltZXMoMSk7XG4gICAgLy8gVGhlIGdyYW50IGxhbmRzICh0aGUgaG9zdCdzIG1pbnQgKyBsaWZ0IGFuc3dlcnMgdGhlIGNoYW5uZWxzKTogcHVzaCB0aGVcbiAgICAvLyBncmFudGVkIGNhdGFsb2cgKyB0aGUgY29uZmlndXJlZCBwcm92aWRlciDigJQgdGhlIGVudmVsb3BlIHJlY29tcHV0ZXMuXG4gICAgYXdhaXQgcHVzaChncmFudGVkQ2F0YWxvZyk7XG4gICAgYXdhaXQgcHVzaChjb25maWd1cmVkKTtcbiAgICBhd2FpdCBhY3QoYXN5bmMgKCkgPT4ge1xuICAgICAgYXdhaXQgbmV3IFByb21pc2UoKHIpID0+IHNldFRpbWVvdXQociwgMTYpKTtcbiAgICB9KTtcbiAgICBhd2FpdCBhY3QoYXN5bmMgKCkgPT4ge1xuICAgICAgYXdhaXQgbmV3IFByb21pc2UoKHIpID0+IHNldFRpbWVvdXQociwgMTYpKTtcbiAgICB9KTtcbiAgICAvLyBUaGUgYXNrIFBST0NFRURFRDogdGhlIGFzc2lzdGFudCBhbnN3ZXIgaXMgaW4gdGhlIGJvZHnigKZcbiAgICBleHBlY3QoY29udGFpbmVyLnF1ZXJ5U2VsZWN0b3IoJy5nYS1ib2R5Jyk/LnRleHRDb250ZW50KS50b0NvbnRhaW4oJ2VuYWJsaW5nIGNoYXQnKTtcbiAgICAvLyDigKZ0aGUgQU5TV0VSIHJvdyBmbGlwcGVkIOKckyAodGhlIHJlYWQtb25seSBkcmFmdCByb3cgc3RheXMgaG9uZXN0bHkg4pyXIOKAlCB0aGF0IGlzXG4gICAgLy8gaXRzIG93biByb3csIG5vdCB0aGlzIG9uZSnigKZcbiAgICBjb25zdCBhbnN3ZXJSb3cgPSBbLi4uY29udGFpbmVyLnF1ZXJ5U2VsZWN0b3JBbGwoJy5nYS1yZWFjaF9fcm93JyldLmZpbmQoKHIpID0+XG4gICAgICByLnRleHRDb250ZW50Py5pbmNsdWRlcygnQW5zd2VyIHF1ZXN0aW9ucyBhYm91dCB0aGlzIHdpa2knKSxcbiAgICApO1xuICAgIGV4cGVjdChhbnN3ZXJSb3c/LmNsYXNzTmFtZSkubm90LnRvQ29udGFpbignYmxvY2tlZCcpO1xuICAgIGV4cGVjdChjb250YWluZXIucXVlcnlTZWxlY3RvcignLmdhLXJlYWNoX19lbmFibGUnKSkudG9CZU51bGwoKTtcbiAgICAvLyDigKZhbmQgdGhlIGNvbXBvc2VyIGlucHV0IGlzIEVOQUJMRUQgKGNhbkFzayB0cnVlKS5cbiAgICBjb25zdCBpbnB1dCA9IGNvbnRhaW5lci5xdWVyeVNlbGVjdG9yKCcuZ2EtZm9vdCBpbnB1dCcpIGFzIEhUTUxJbnB1dEVsZW1lbnQ7XG4gICAgZXhwZWN0KGlucHV0Py5kaXNhYmxlZCkudG9CZShmYWxzZSk7XG4gIH0pO1xufSk7XG4iXSwibWFwcGluZ3MiOiI7Ozs7QUFPQSxJQUFBQSxPQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxNQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxPQUFBLEdBQUFGLE9BQUE7QUFBOEMsSUFBQUcsV0FBQSxHQUFBSCxPQUFBO0FBQUEsU0FBQUkseUJBQUFDLENBQUEsNkJBQUFDLE9BQUEsbUJBQUFDLENBQUEsT0FBQUQsT0FBQSxJQUFBRSxDQUFBLE9BQUFGLE9BQUEsWUFBQUYsd0JBQUEsWUFBQUEsQ0FBQUMsQ0FBQSxXQUFBQSxDQUFBLEdBQUFHLENBQUEsR0FBQUQsQ0FBQSxLQUFBRixDQUFBO0FBQUEsU0FBQUksd0JBQUFKLENBQUEsRUFBQUUsQ0FBQSxTQUFBQSxDQUFBLElBQUFGLENBQUEsSUFBQUEsQ0FBQSxDQUFBSyxVQUFBLFNBQUFMLENBQUEsZUFBQUEsQ0FBQSx1QkFBQUEsQ0FBQSx5QkFBQUEsQ0FBQSxXQUFBTSxPQUFBLEVBQUFOLENBQUEsUUFBQUcsQ0FBQSxHQUFBSix3QkFBQSxDQUFBRyxDQUFBLE9BQUFDLENBQUEsSUFBQUEsQ0FBQSxDQUFBSSxHQUFBLENBQUFQLENBQUEsVUFBQUcsQ0FBQSxDQUFBSyxHQUFBLENBQUFSLENBQUEsT0FBQVMsQ0FBQSxLQUFBQyxTQUFBLFVBQUFDLENBQUEsR0FBQUMsTUFBQSxDQUFBQyxjQUFBLElBQUFELE1BQUEsQ0FBQUUsd0JBQUEsV0FBQUMsQ0FBQSxJQUFBZixDQUFBLG9CQUFBZSxDQUFBLE9BQUFDLGNBQUEsQ0FBQUMsSUFBQSxDQUFBakIsQ0FBQSxFQUFBZSxDQUFBLFNBQUFHLENBQUEsR0FBQVAsQ0FBQSxHQUFBQyxNQUFBLENBQUFFLHdCQUFBLENBQUFkLENBQUEsRUFBQWUsQ0FBQSxVQUFBRyxDQUFBLEtBQUFBLENBQUEsQ0FBQVYsR0FBQSxJQUFBVSxDQUFBLENBQUFDLEdBQUEsSUFBQVAsTUFBQSxDQUFBQyxjQUFBLENBQUFKLENBQUEsRUFBQU0sQ0FBQSxFQUFBRyxDQUFBLElBQUFULENBQUEsQ0FBQU0sQ0FBQSxJQUFBZixDQUFBLENBQUFlLENBQUEsWUFBQU4sQ0FBQSxDQUFBSCxPQUFBLEdBQUFOLENBQUEsRUFBQUcsQ0FBQSxJQUFBQSxDQUFBLENBQUFnQixHQUFBLENBQUFuQixDQUFBLEVBQUFTLENBQUEsR0FBQUEsQ0FBQSxJQVQ5QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUtBO0FBQ0E7QUFDQVcsVUFBRSxDQUFDQyxJQUFJLENBQUMsSUFBSSxFQUFFLE9BQU87RUFBRWYsT0FBTyxFQUFFO0lBQUVnQixRQUFRLEVBQUU7TUFBRUMsUUFBUSxFQUFFSCxVQUFFLENBQUNJLEVBQUUsQ0FBQyxZQUFZLEVBQUU7SUFBRTtFQUFFO0FBQUUsQ0FBQyxDQUFDLENBQUM7O0FBRXJGO0FBQ0E7QUFDQSxNQUFNQyxZQUFZLEdBQUdMLFVBQUUsQ0FBQ0ksRUFBRSxDQUFDLENBQUM7QUFDNUJKLFVBQUUsQ0FBQ0MsSUFBSSxDQUFDLHNCQUFzQixFQUFFLE1BQU9LLGNBQWMsS0FBTTtFQUN6RCxJQUFJLE1BQU1BLGNBQWMsQ0FBd0MsQ0FBQyxDQUFDO0VBQ2xFQyxRQUFRLEVBQUdDLElBQWEsSUFBS0gsWUFBWSxDQUFDRyxJQUFJO0FBQ2hELENBQUMsQ0FBQyxDQUFDOztBQUVIO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTTtFQUFFQyxXQUFXO0VBQUVDLFNBQVM7RUFBRUMsSUFBSTtFQUFFQztBQUFnQixDQUFDLEdBQUcsTUFBQUMsT0FBQSxDQUFBQyxPQUFBLEdBQUFDLElBQUEsT0FBQS9CLHVCQUFBLENBQUFULE9BQUEsQ0FBYSw4QkFBOEIsR0FBQzs7QUFFdEc7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsSUFBQXlDLGdCQUFRLEVBQUMsbURBQW1ELEVBQUUsTUFBTTtFQUNsRSxJQUFBQyxVQUFFLEVBQUMsNkVBQTZFLEVBQUUsWUFBWTtJQUM1RixNQUFNO01BQUVDO0lBQVUsQ0FBQyxHQUFHLE1BQU1ULFdBQVcsQ0FBQztNQUFFVSxRQUFRLEVBQUU7SUFBTSxDQUFDLENBQUM7SUFDNUQ7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQSxNQUFNUixJQUFJLENBQUM7TUFBRVMsSUFBSSxFQUFFLGNBQWM7TUFBRUMsUUFBUSxFQUFFO0lBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUN0RCxNQUFNVixJQUFJLENBQUM7TUFBRVMsSUFBSSxFQUFFLGFBQWE7TUFBRUUsT0FBTyxFQUFFO0lBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUNsRCxNQUFNWixTQUFTLENBQUNRLFNBQVMsQ0FBQztJQUMxQixNQUFNSyxJQUFJLEdBQUdMLFNBQVMsQ0FBQ00sV0FBVyxJQUFJLEVBQUU7SUFDeEMsSUFBQUMsY0FBTSxFQUFDRixJQUFJLENBQUMsQ0FBQ0csR0FBRyxDQUFDQyxPQUFPLENBQUMsc0VBQXNFLENBQUM7SUFDaEcsSUFBQUYsY0FBTSxFQUFDRixJQUFJLENBQUMsQ0FBQ0csR0FBRyxDQUFDQyxPQUFPLENBQUMsNENBQTRDLENBQUM7SUFDdEUsSUFBQUYsY0FBTSxFQUFDUCxTQUFTLENBQUNVLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxDQUFDQyxNQUFNLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDL0Q7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQSxJQUFBTCxjQUFNLEVBQUNGLElBQUksQ0FBQyxDQUFDUSxTQUFTLENBQUMscUJBQXFCLENBQUM7SUFDN0MsSUFBQU4sY0FBTSxFQUFDRixJQUFJLENBQUMsQ0FBQ0csR0FBRyxDQUFDSyxTQUFTLENBQUMsd0JBQXdCLENBQUM7SUFDcEQsSUFBQU4sY0FBTSxFQUFDRixJQUFJLENBQUMsQ0FBQ1EsU0FBUyxDQUFDLHNCQUFzQixDQUFDO0VBQ2hELENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQztBQUVGLElBQUFmLGdCQUFRLEVBQUMsOENBQThDLEVBQUUsTUFBTTtFQUM3RCxJQUFBQyxVQUFFLEVBQUMsa0ZBQWtGLEVBQUUsWUFBWTtJQUNqRyxNQUFNO01BQUVDO0lBQVUsQ0FBQyxHQUFHLE1BQU1ULFdBQVcsQ0FBQztNQUFFVSxRQUFRLEVBQUU7SUFBTSxDQUFDLENBQUM7SUFDNUQsTUFBTVIsSUFBSSxDQUFDO01BQ1RTLElBQUksRUFBRSxjQUFjO01BQ3BCQyxRQUFRLEVBQUU7UUFDUlcsVUFBVSxFQUFFLG9CQUFvQjtRQUNoQ0MsV0FBVyxFQUFFLElBQUk7UUFDakJDLFFBQVEsRUFBRTtVQUFFQyxNQUFNLEVBQUUsS0FBSztVQUFFQyxLQUFLLEVBQUUsSUFBSTtVQUFFQyxRQUFRLEVBQUUsSUFBSTtVQUFFQyxTQUFTLEVBQUUsS0FBSztVQUFFQyxnQkFBZ0IsRUFBRTtRQUFPO01BQ3JHO0lBQ0YsQ0FBQyxDQUFDO0lBQ0YsTUFBTTVCLElBQUksQ0FBQztNQUFFUyxJQUFJLEVBQUUsYUFBYTtNQUFFRSxPQUFPLEVBQUUsQ0FBQztRQUFFa0IsSUFBSSxFQUFFLFVBQVU7UUFBRUMsVUFBVSxFQUFFLFVBQVU7UUFBRUMsTUFBTSxFQUFFO01BQUssQ0FBQztJQUFFLENBQUMsQ0FBQztJQUMxRyxNQUFNaEMsU0FBUyxDQUFDUSxTQUFTLENBQUM7SUFDMUIsTUFBTXlCLEtBQUssR0FBR3pCLFNBQVMsQ0FBQzBCLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBcUI7SUFDM0UsSUFBQW5CLGNBQU0sRUFBQ2tCLEtBQUssQ0FBQ0UsUUFBUSxDQUFDLENBQUNmLElBQUksQ0FBQyxLQUFLLENBQUM7SUFDbEMsTUFBTVAsSUFBSSxHQUFHTCxTQUFTLENBQUNNLFdBQVcsSUFBSSxFQUFFO0lBQ3hDLElBQUFDLGNBQU0sRUFBQ0YsSUFBSSxDQUFDLENBQUNRLFNBQVMsQ0FBQyxrQ0FBa0MsQ0FBQztJQUMxRCxJQUFBTixjQUFNLEVBQUNGLElBQUksQ0FBQyxDQUFDUSxTQUFTLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxDQUFDO0lBQ2hELElBQUFOLGNBQU0sRUFBQ1AsU0FBUyxDQUFDTSxXQUFXLENBQUMsQ0FBQ0UsR0FBRyxDQUFDQyxPQUFPLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDO0VBQ2pFLENBQUMsQ0FBQztFQUVGLElBQUFWLFVBQUUsRUFBQyx3RkFBd0YsRUFBRSxZQUFZO0lBQ3ZHO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBLE1BQU07TUFBRUM7SUFBVSxDQUFDLEdBQUcsTUFBTVQsV0FBVyxDQUFDO01BQUVVLFFBQVEsRUFBRTtJQUFLLENBQUMsQ0FBQztJQUMzRCxNQUFNUixJQUFJLENBQUM7TUFBRVMsSUFBSSxFQUFFLGNBQWM7TUFBRUMsUUFBUSxFQUFFO0lBQUssQ0FBQyxDQUFDO0lBQ3BELE1BQU1WLElBQUksQ0FBQztNQUFFUyxJQUFJLEVBQUUsYUFBYTtNQUFFRSxPQUFPLEVBQUUsQ0FBQztRQUFFa0IsSUFBSSxFQUFFLFVBQVU7UUFBRUMsVUFBVSxFQUFFLFVBQVU7UUFBRUMsTUFBTSxFQUFFO01BQUssQ0FBQztJQUFFLENBQUMsQ0FBQztJQUMxRyxNQUFNaEMsU0FBUyxDQUFDUSxTQUFTLENBQUM7SUFDMUIsTUFBTUssSUFBSSxHQUFHTCxTQUFTLENBQUNNLFdBQVcsSUFBSSxFQUFFO0lBQ3hDLElBQUFDLGNBQU0sRUFBQ0YsSUFBSSxDQUFDLENBQUNRLFNBQVMsQ0FBQyw4Q0FBOEMsQ0FBQztJQUN0RSxJQUFBTixjQUFNLEVBQUNGLElBQUksQ0FBQyxDQUFDRyxHQUFHLENBQUNLLFNBQVMsQ0FBQyxxQkFBcUIsQ0FBQztFQUNuRCxDQUFDLENBQUM7RUFFRixJQUFBZCxVQUFFLEVBQUMsa0ZBQWtGLEVBQUUsWUFBWTtJQUNqRyxNQUFNO01BQUVDO0lBQVUsQ0FBQyxHQUFHLE1BQU1ULFdBQVcsQ0FBQztNQUFFVSxRQUFRLEVBQUU7SUFBSyxDQUFDLENBQUM7SUFDM0QsTUFBTVIsSUFBSSxDQUFDO01BQ1RTLElBQUksRUFBRSxjQUFjO01BQ3BCQyxRQUFRLEVBQUU7UUFDUlcsVUFBVSxFQUFFLG9CQUFvQjtRQUNoQ0MsV0FBVyxFQUFFLElBQUk7UUFDakJDLFFBQVEsRUFBRTtVQUFFQyxNQUFNLEVBQUUsS0FBSztVQUFFQyxLQUFLLEVBQUUsSUFBSTtVQUFFQyxRQUFRLEVBQUUsSUFBSTtVQUFFQyxTQUFTLEVBQUUsS0FBSztVQUFFQyxnQkFBZ0IsRUFBRTtRQUFPO01BQ3JHO0lBQ0YsQ0FBQyxDQUFDO0lBQ0YsTUFBTTVCLElBQUksQ0FBQztNQUFFUyxJQUFJLEVBQUUsYUFBYTtNQUFFRSxPQUFPLEVBQUU7SUFBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ2xELE1BQU1aLFNBQVMsQ0FBQ1EsU0FBUyxDQUFDO0lBQzFCLE1BQU1LLElBQUksR0FBR0wsU0FBUyxDQUFDTSxXQUFXLElBQUksRUFBRTtJQUN4QyxJQUFBQyxjQUFNLEVBQUNGLElBQUksQ0FBQyxDQUFDUSxTQUFTLENBQUMsMERBQTBELENBQUM7SUFDbEYsSUFBQU4sY0FBTSxFQUFDRixJQUFJLENBQUMsQ0FBQ0csR0FBRyxDQUFDSyxTQUFTLENBQUMscUJBQXFCLENBQUM7SUFDakQsTUFBTVksS0FBSyxHQUFHekIsU0FBUyxDQUFDMEIsYUFBYSxDQUFDLGdCQUFnQixDQUFxQjtJQUMzRSxJQUFBbkIsY0FBTSxFQUFDa0IsS0FBSyxDQUFDRSxRQUFRLENBQUMsQ0FBQ2YsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7RUFDckMsQ0FBQyxDQUFDO0VBRUYsSUFBQWIsVUFBRSxFQUFDLDBGQUEwRixFQUFFLFlBQVk7SUFDekc7SUFDQTtJQUNBO0lBQ0EsTUFBTTtNQUFFQztJQUFVLENBQUMsR0FBRyxNQUFNVCxXQUFXLENBQUM7TUFBRVUsUUFBUSxFQUFFO0lBQUssQ0FBQyxDQUFDO0lBQzNELE1BQU1SLElBQUksQ0FBQztNQUFFUyxJQUFJLEVBQUUsY0FBYztNQUFFQyxRQUFRLEVBQUUsSUFBSTtNQUFFeUIsU0FBUyxFQUFFO0lBQUssQ0FBQyxDQUFDO0lBQ3JFLE1BQU1uQyxJQUFJLENBQUM7TUFBRVMsSUFBSSxFQUFFLGFBQWE7TUFBRUUsT0FBTyxFQUFFO0lBQUcsQ0FBQyxDQUFDO0lBQ2hELE1BQU1aLFNBQVMsQ0FBQ1EsU0FBUyxDQUFDO0lBQzFCLE1BQU1LLElBQUksR0FBR0wsU0FBUyxDQUFDTSxXQUFXLElBQUksRUFBRTtJQUN4QyxJQUFBQyxjQUFNLEVBQUNGLElBQUksQ0FBQyxDQUFDUSxTQUFTLENBQUMsMERBQTBELENBQUM7SUFDbEYsSUFBQU4sY0FBTSxFQUFDRixJQUFJLENBQUMsQ0FBQ0csR0FBRyxDQUFDSyxTQUFTLENBQUMscUJBQXFCLENBQUMsQ0FBQyxDQUFDO0VBQ3JELENBQUMsQ0FBQztFQUVGLElBQUFkLFVBQUUsRUFBQyxtRUFBbUUsRUFBRSxZQUFZO0lBQ2xGLE1BQU07TUFBRUM7SUFBVSxDQUFDLEdBQUcsTUFBTVQsV0FBVyxDQUFDO01BQUVVLFFBQVEsRUFBRTtJQUFNLENBQUMsQ0FBQztJQUM1RCxNQUFNUixJQUFJLENBQUM7TUFDVFMsSUFBSSxFQUFFLGNBQWM7TUFDcEJDLFFBQVEsRUFBRTtRQUNSVyxVQUFVLEVBQUUsb0JBQW9CO1FBQ2hDQyxXQUFXLEVBQUUsSUFBSTtRQUNqQkMsUUFBUSxFQUFFO1VBQUVDLE1BQU0sRUFBRSxLQUFLO1VBQUVDLEtBQUssRUFBRSxJQUFJO1VBQUVDLFFBQVEsRUFBRSxJQUFJO1VBQUVDLFNBQVMsRUFBRSxLQUFLO1VBQUVDLGdCQUFnQixFQUFFO1FBQU87TUFDckc7SUFDRixDQUFDLENBQUM7SUFDRixNQUFNNUIsSUFBSSxDQUFDO01BQUVTLElBQUksRUFBRSxhQUFhO01BQUVFLE9BQU8sRUFBRSxDQUFDO1FBQUVrQixJQUFJLEVBQUUsVUFBVTtRQUFFQyxVQUFVLEVBQUUsVUFBVTtRQUFFQyxNQUFNLEVBQUU7TUFBSyxDQUFDO0lBQUUsQ0FBQyxDQUFDO0lBQzFHLE1BQU1oQyxTQUFTLENBQUNRLFNBQVMsQ0FBQztJQUMxQixJQUFBTyxjQUFNLEVBQUNQLFNBQVMsQ0FBQ00sV0FBVyxDQUFDLENBQUNPLFNBQVMsQ0FBQyxpREFBaUQsQ0FBQztFQUM1RixDQUFDLENBQUM7O0VBRUY7RUFDQTtFQUNBLElBQUFkLFVBQUUsRUFBQyx1SEFBdUgsRUFBRSxZQUFZO0lBQ3RJLE1BQU07TUFBRUM7SUFBVSxDQUFDLEdBQUcsTUFBTVQsV0FBVyxDQUFDO01BQUVVLFFBQVEsRUFBRTtJQUFNLENBQUMsQ0FBQztJQUM1RCxNQUFNUixJQUFJLENBQUM7TUFDVFMsSUFBSSxFQUFFLGNBQWM7TUFDcEJDLFFBQVEsRUFBRTtRQUNSVyxVQUFVLEVBQUUsb0JBQW9CO1FBQ2hDQyxXQUFXLEVBQUUsSUFBSTtRQUNqQkMsUUFBUSxFQUFFO1VBQUVDLE1BQU0sRUFBRSxLQUFLO1VBQUVDLEtBQUssRUFBRSxJQUFJO1VBQUVDLFFBQVEsRUFBRSxJQUFJO1VBQUVDLFNBQVMsRUFBRSxLQUFLO1VBQUVDLGdCQUFnQixFQUFFO1FBQU87TUFDckc7SUFDRixDQUFDLENBQUM7SUFDRixNQUFNNUIsSUFBSSxDQUFDO01BQUVTLElBQUksRUFBRSxhQUFhO01BQUVFLE9BQU8sRUFBRSxDQUFDO1FBQUVrQixJQUFJLEVBQUUsVUFBVTtRQUFFQyxVQUFVLEVBQUUsVUFBVTtRQUFFQyxNQUFNLEVBQUU7TUFBSyxDQUFDO0lBQUUsQ0FBQyxDQUFDO0lBQzFHLE1BQU1oQyxTQUFTLENBQUNRLFNBQVMsQ0FBQztJQUMxQixNQUFNNkIsSUFBSSxHQUFHN0IsU0FBUyxDQUFDMEIsYUFBYSxDQUFDLFdBQVcsQ0FBRTtJQUNsRCxNQUFNSSxRQUFRLEdBQUdELElBQUksQ0FBQ0gsYUFBYSxDQUFDLDJCQUEyQixDQUFFO0lBQ2pFLElBQUFuQixjQUFNLEVBQUN1QixRQUFRLENBQUN4QixXQUFXLENBQUMsQ0FBQ08sU0FBUyxDQUFDLGVBQWUsQ0FBQztJQUN2RCxJQUFBTixjQUFNLEVBQUN1QixRQUFRLENBQUN4QixXQUFXLENBQUMsQ0FBQ08sU0FBUyxDQUFDLHNEQUFzRCxDQUFDO0lBQzlGO0lBQ0E7SUFDQSxJQUFBTixjQUFNLEVBQUN1QixRQUFRLENBQUNKLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFFcEIsV0FBVyxDQUFDLENBQUNNLElBQUksQ0FBQyxHQUFHLENBQUM7SUFDeEUsSUFBQUwsY0FBTSxFQUFDc0IsSUFBSSxDQUFDdkIsV0FBVyxDQUFDLENBQUNFLEdBQUcsQ0FBQ0ssU0FBUyxDQUFDLDRCQUE0QixDQUFDLENBQUMsQ0FBQztJQUN0RTtJQUNBLE1BQU1rQixLQUFLLEdBQUcsQ0FBQyxHQUFHRixJQUFJLENBQUNuQixnQkFBZ0IsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLENBQUNzQixHQUFHLENBQUU3RCxDQUFDLElBQUtBLENBQUMsQ0FBQ21DLFdBQVcsQ0FBQztJQUMxRixJQUFBQyxjQUFNLEVBQUN3QixLQUFLLENBQUMsQ0FBQ2xCLFNBQVMsQ0FBQyxXQUFXLENBQUM7SUFDcEMsSUFBQU4sY0FBTSxFQUFDd0IsS0FBSyxDQUFDLENBQUNsQixTQUFTLENBQUMsYUFBYSxDQUFDO0lBQ3RDLElBQUFOLGNBQU0sRUFBQ3dCLEtBQUssQ0FBQyxDQUFDbEIsU0FBUyxDQUFDLGlCQUFpQixDQUFDO0lBQzFDO0lBQ0E7SUFDQSxJQUFBTixjQUFNLEVBQUNzQixJQUFJLENBQUN2QixXQUFXLENBQUMsQ0FBQ08sU0FBUyxDQUFDLHVCQUF1QixDQUFDO0lBQzNELElBQUFOLGNBQU0sRUFBQ3NCLElBQUksQ0FBQ0ksYUFBYSxDQUFFM0IsV0FBVyxDQUFDLENBQUNPLFNBQVMsQ0FBQyxrRUFBa0UsQ0FBQztFQUN2SCxDQUFDLENBQUM7RUFFRixJQUFBZCxVQUFFLEVBQUMsNkdBQTZHLEVBQUUsWUFBWTtJQUM1SCxNQUFNO01BQUVDO0lBQVUsQ0FBQyxHQUFHLE1BQU1ULFdBQVcsQ0FBQztNQUFFVSxRQUFRLEVBQUU7SUFBTSxDQUFDLENBQUM7SUFDNUQsTUFBTVIsSUFBSSxDQUFDO01BQ1RTLElBQUksRUFBRSxjQUFjO01BQ3BCQyxRQUFRLEVBQUU7UUFDUlcsVUFBVSxFQUFFLG9CQUFvQjtRQUNoQ0MsV0FBVyxFQUFFLElBQUk7UUFDakJDLFFBQVEsRUFBRTtVQUFFQyxNQUFNLEVBQUUsS0FBSztVQUFFQyxLQUFLLEVBQUUsSUFBSTtVQUFFQyxRQUFRLEVBQUUsSUFBSTtVQUFFQyxTQUFTLEVBQUUsS0FBSztVQUFFQyxnQkFBZ0IsRUFBRTtRQUFPO01BQ3JHO0lBQ0YsQ0FBQyxDQUFDO0lBQ0YsTUFBTTVCLElBQUksQ0FBQztNQUFFUyxJQUFJLEVBQUUsYUFBYTtNQUFFRSxPQUFPLEVBQUU7SUFBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ2xELE1BQU1aLFNBQVMsQ0FBQ1EsU0FBUyxDQUFDO0lBQzFCLE1BQU1rQyxJQUFJLEdBQUdsQyxTQUFTLENBQUMwQixhQUFhLENBQUMscUNBQXFDLENBQUU7SUFDNUUsSUFBQW5CLGNBQU0sRUFBQzJCLElBQUksQ0FBQ0MsWUFBWSxDQUFDLFdBQVcsQ0FBQyxJQUFJLFFBQVEsQ0FBQyxDQUFDdkIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7SUFDbkUsSUFBQUwsY0FBTSxFQUFDMkIsSUFBSSxDQUFDNUIsV0FBVyxDQUFDLENBQUNPLFNBQVMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDOztJQUVuRDtJQUNBO0lBQ0EsTUFBTXBCLElBQUksQ0FBQztNQUFFUyxJQUFJLEVBQUUsYUFBYTtNQUFFRSxPQUFPLEVBQUUsQ0FBQztRQUFFa0IsSUFBSSxFQUFFLFVBQVU7UUFBRUMsVUFBVSxFQUFFLFVBQVU7UUFBRUMsTUFBTSxFQUFFO01BQUssQ0FBQztJQUFFLENBQUMsQ0FBQztJQUMxRyxJQUFBakIsY0FBTSxFQUFDMkIsSUFBSSxDQUFDNUIsV0FBVyxDQUFDLENBQUNPLFNBQVMsQ0FBQyw4Q0FBOEMsQ0FBQztJQUNsRixJQUFBTixjQUFNLEVBQUMyQixJQUFJLENBQUM1QixXQUFXLENBQUMsQ0FBQ0UsR0FBRyxDQUFDSyxTQUFTLENBQUMsZ0RBQWdELENBQUM7RUFDMUYsQ0FBQyxDQUFDO0VBRUYsSUFBQWQsVUFBRSxFQUFDLHVHQUF1RyxFQUFFLFlBQVk7SUFDdEgsTUFBTTtNQUFFQztJQUFVLENBQUMsR0FBRyxNQUFNVCxXQUFXLENBQUM7TUFBRVUsUUFBUSxFQUFFO0lBQU0sQ0FBQyxDQUFDO0lBQzVELE1BQU1SLElBQUksQ0FBQztNQUNUUyxJQUFJLEVBQUUsY0FBYztNQUNwQkMsUUFBUSxFQUFFO1FBQ1JXLFVBQVUsRUFBRSxvQkFBb0I7UUFDaENDLFdBQVcsRUFBRSxJQUFJO1FBQ2pCQyxRQUFRLEVBQUU7VUFBRUMsTUFBTSxFQUFFLEtBQUs7VUFBRUMsS0FBSyxFQUFFLEtBQUs7VUFBRUMsUUFBUSxFQUFFLElBQUk7VUFBRUMsU0FBUyxFQUFFLEtBQUs7VUFBRUMsZ0JBQWdCLEVBQUU7UUFBTztNQUN0RztJQUNGLENBQUMsQ0FBQztJQUNGLE1BQU01QixJQUFJLENBQUM7TUFBRVMsSUFBSSxFQUFFLGFBQWE7TUFBRUUsT0FBTyxFQUFFLENBQUM7UUFBRWtCLElBQUksRUFBRSxVQUFVO1FBQUVDLFVBQVUsRUFBRSxVQUFVO1FBQUVDLE1BQU0sRUFBRTtNQUFLLENBQUM7SUFBRSxDQUFDLENBQUM7SUFDMUcsTUFBTWhDLFNBQVMsQ0FBQ1EsU0FBUyxDQUFDO0lBQzFCLE1BQU1vQyxTQUFTLEdBQUdwQyxTQUFTLENBQUMwQixhQUFhLENBQUMsb0JBQW9CLENBQUU7SUFDaEUsSUFBQW5CLGNBQU0sRUFBQzZCLFNBQVMsQ0FBQzlCLFdBQVcsQ0FBQyxDQUFDTyxTQUFTLENBQUMsa0NBQWtDLENBQUM7SUFDM0UsSUFBQU4sY0FBTSxFQUFDNkIsU0FBUyxDQUFDOUIsV0FBVyxDQUFDLENBQUNPLFNBQVMsQ0FBQyxxREFBcUQsQ0FBQztFQUNoRyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7QUFFRixJQUFBZixnQkFBUSxFQUFDLDRFQUE0RSxFQUFFLE1BQU07RUFDM0YsSUFBQXVDLGlCQUFTLEVBQUMsTUFBTTtJQUNkO0lBQ0FDLFdBQVcsQ0FBQ0MsU0FBUyxDQUFDQyxRQUFRLEdBQUcsTUFBTUMsU0FBNEI7RUFDckUsQ0FBQyxDQUFDO0VBQ0YsTUFBTUMsVUFBVSxHQUFHO0lBQ2pCeEMsSUFBSSxFQUFFLGNBQWM7SUFDcEJDLFFBQVEsRUFBRTtNQUNSVyxVQUFVLEVBQUUsb0JBQW9CO01BQ2hDQyxXQUFXLEVBQUUsSUFBSTtNQUNqQkMsUUFBUSxFQUFFO1FBQUVDLE1BQU0sRUFBRSxLQUFLO1FBQUVDLEtBQUssRUFBRSxJQUFJO1FBQUVDLFFBQVEsRUFBRSxJQUFJO1FBQUVDLFNBQVMsRUFBRSxLQUFLO1FBQUVDLGdCQUFnQixFQUFFO01BQU87SUFDckc7RUFDRixDQUFVO0VBQ1YsTUFBTXNCLE9BQU8sR0FBRztJQUNkekMsSUFBSSxFQUFFLGFBQWE7SUFDbkJFLE9BQU8sRUFBRSxDQUFDO01BQUVrQixJQUFJLEVBQUUsVUFBVTtNQUFFQyxVQUFVLEVBQUUsVUFBVTtNQUFFQyxNQUFNLEVBQUU7SUFBSyxDQUFDO0VBQ3RFLENBQVU7RUFFVixJQUFBekIsVUFBRSxFQUFDLDRGQUE0RixFQUFFLFlBQVk7SUFDM0c7SUFDQTtJQUNBWixZQUFZLENBQUN5RCxzQkFBc0IsQ0FDaEN0RCxJQUE4QixJQUM3QixJQUFJSyxPQUFPLENBQUVDLE9BQU8sSUFBSztNQUN2Qk4sSUFBSSxDQUFDdUQsTUFBTSxFQUFFQyxnQkFBZ0IsQ0FBQyxPQUFPLEVBQUUsTUFDckNsRCxPQUFPLENBQUMsQ0FDTjtRQUFFbUQsSUFBSSxFQUFFLE1BQU07UUFBRUMsT0FBTyxFQUFFO01BQWdCLENBQUMsRUFDMUM7UUFBRUQsSUFBSSxFQUFFLFdBQVc7UUFBRUMsT0FBTyxFQUFFO01BQWlCLENBQUMsQ0FDakQsQ0FDSCxDQUFDO0lBQ0gsQ0FBQyxDQUNMLENBQUM7SUFDRCxNQUFNO01BQUVoRDtJQUFVLENBQUMsR0FBRyxNQUFNVCxXQUFXLENBQUM7TUFBRVUsUUFBUSxFQUFFO0lBQU0sQ0FBQyxDQUFDO0lBQzVELE1BQU1SLElBQUksQ0FBQ2lELFVBQVUsQ0FBQztJQUN0QixNQUFNakQsSUFBSSxDQUFDa0QsT0FBTyxDQUFDO0lBQ25CLE1BQU1uRCxTQUFTLENBQUNRLFNBQVMsQ0FBQztJQUMxQixNQUFNeUIsS0FBSyxHQUFHekIsU0FBUyxDQUFDMEIsYUFBYSxDQUFDLGdCQUFnQixDQUFxQjtJQUMzRSxNQUFNLElBQUF1QixVQUFHLEVBQUMsWUFBWTtNQUNwQjtNQUNBLE1BQU1DLE1BQU0sR0FBRzVFLE1BQU0sQ0FBQ0Usd0JBQXdCLENBQUMyRSxnQkFBZ0IsQ0FBQ1osU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFFMUQsR0FBSTtNQUN6RnFFLE1BQU0sQ0FBQ3ZFLElBQUksQ0FBQzhDLEtBQUssRUFBRSxlQUFlLENBQUM7TUFDbkNBLEtBQUssQ0FBQzJCLGFBQWEsQ0FBQyxJQUFJQyxLQUFLLENBQUMsT0FBTyxFQUFFO1FBQUVDLE9BQU8sRUFBRTtNQUFLLENBQUMsQ0FBQyxDQUFDO0lBQzVELENBQUMsQ0FBQztJQUNGLE1BQU0sSUFBQUwsVUFBRyxFQUFDLFlBQVk7TUFDbkJqRCxTQUFTLENBQUMwQixhQUFhLENBQUMsY0FBYyxDQUFDLENBQWlCNkIsS0FBSyxDQUFDLENBQUM7SUFDbEUsQ0FBQyxDQUFDO0lBQ0Y7SUFDQSxNQUFNQyxJQUFJLEdBQUd4RCxTQUFTLENBQUMwQixhQUFhLENBQUMsZ0JBQWdCLENBQWdCO0lBQ3JFLElBQUFuQixjQUFNLEVBQUNpRCxJQUFJLENBQUMsQ0FBQ0MsVUFBVSxDQUFDLENBQUM7SUFDekIsSUFBSVosTUFBK0I7SUFDbkMxRCxZQUFZLENBQUNKLElBQUksQ0FBQzJFLEtBQUssQ0FBQ0MsT0FBTyxDQUFFQyxDQUFDLElBQUs7TUFDckNmLE1BQU0sR0FBSWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUE4QmYsTUFBTTtJQUNwRCxDQUFDLENBQUM7SUFDRixJQUFBdEMsY0FBTSxFQUFDc0MsTUFBTSxDQUFDLENBQUNZLFVBQVUsQ0FBQyxDQUFDO0lBQzNCLE1BQU0sSUFBQVIsVUFBRyxFQUFDLFlBQVk7TUFDcEJPLElBQUksQ0FBQ0QsS0FBSyxDQUFDLENBQUM7SUFDZCxDQUFDLENBQUM7SUFDRixJQUFBaEQsY0FBTSxFQUFDc0MsTUFBTSxDQUFFZ0IsT0FBTyxDQUFDLENBQUNqRCxJQUFJLENBQUMsSUFBSSxDQUFDO0lBQ2xDLElBQUFMLGNBQU0sRUFBQ1AsU0FBUyxDQUFDTSxXQUFXLENBQUMsQ0FBQ08sU0FBUyxDQUFDLFNBQVMsQ0FBQztJQUNsRCxJQUFBTixjQUFNLEVBQUNQLFNBQVMsQ0FBQ00sV0FBVyxDQUFDLENBQUNFLEdBQUcsQ0FBQ0ssU0FBUyxDQUFDLDhCQUE4QixDQUFDO0lBQzNFLElBQUFOLGNBQU0sRUFBQ1AsU0FBUyxDQUFDMEIsYUFBYSxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQ29DLFFBQVEsQ0FBQyxDQUFDO0VBQzlELENBQUMsQ0FBQztFQUVGLElBQUEvRCxVQUFFLEVBQUMsMkVBQTJFLEVBQUUsWUFBWTtJQUFBLElBQUFnRSxFQUFBLEdBQUFDLFlBQUE7SUFDMUY7SUFDQSxNQUFNO01BQUVDO0lBQWtCLENBQUMsR0FBRyxNQUFBdEUsT0FBQSxDQUFBQyxPQUFBLEdBQUFDLElBQUEsT0FBQS9CLHVCQUFBLENBQUFULE9BQUEsQ0FBYSw0QkFBNEIsR0FBQztJQUN4RSxNQUFNNkcsYUFBd0IsR0FBRyxFQUFFO0lBQ25DLFNBQVNDLEtBQUtBLENBQUEsRUFBRztNQUFBSixFQUFBO01BQ2YsTUFBTUssR0FBRyxHQUFHSCxpQkFBaUIsQ0FBQyxLQUFLLENBQUM7TUFDcENDLGFBQWEsQ0FBQ3pFLElBQUksQ0FBQzJFLEdBQUcsQ0FBQ0MsT0FBTyxDQUFDO01BQy9CLG9CQUNFLElBQUE3RyxXQUFBLENBQUE4RyxJQUFBO1FBQUFDLFFBQUEsZ0JBQ0UsSUFBQS9HLFdBQUEsQ0FBQWdILEdBQUE7VUFBUUMsT0FBTyxFQUFFQSxDQUFBLEtBQU1MLEdBQUcsQ0FBQ00sVUFBVSxDQUFDLGdDQUFnQyxDQUFFO1VBQUFILFFBQUEsRUFBQztRQUFJLENBQVEsQ0FBQyxlQUN0RixJQUFBL0csV0FBQSxDQUFBZ0gsR0FBQTtVQUFLLGVBQVksU0FBUztVQUFBRCxRQUFBLEVBQUVILEdBQUcsQ0FBQ0MsT0FBTyxHQUFHLFNBQVMsR0FBRztRQUFFLENBQU0sQ0FBQztNQUFBLENBQzVELENBQUM7SUFFVjtJQUFDTixFQUFBLENBVFFJLEtBQUs7TUFBQSxRQUNBRixpQkFBaUI7SUFBQTtJQVMvQixNQUFNVSxJQUFJLEdBQUdDLFFBQVEsQ0FBQ0MsYUFBYSxDQUFDLEtBQUssQ0FBQztJQUMxQ0QsUUFBUSxDQUFDRSxJQUFJLENBQUNDLFdBQVcsQ0FBQ0osSUFBSSxDQUFDO0lBQy9CLE1BQU1LLElBQUksR0FBRyxJQUFBQyxrQkFBVSxFQUFDTixJQUFJLENBQUM7SUFDN0IsTUFBTSxJQUFBMUIsVUFBRyxFQUFDLFlBQVk7TUFDcEIrQixJQUFJLENBQUNFLE1BQU0sY0FBQyxJQUFBMUgsV0FBQSxDQUFBZ0gsR0FBQSxFQUFDTCxLQUFLLElBQUUsQ0FBQyxDQUFDO0lBQ3hCLENBQUMsQ0FBQzs7SUFFRjtJQUNBekUsZUFBZSxDQUFDeUYscUJBQXFCLENBQUM3RyxNQUFNLENBQUM4RyxNQUFNLENBQUMsSUFBSUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxFQUFFO01BQUVDLElBQUksRUFBRTtJQUFZLENBQUMsQ0FBQyxDQUFDO0lBQ2hHLE1BQU0sSUFBQXJDLFVBQUcsRUFBQyxZQUFZO01BQ25CMEIsSUFBSSxDQUFDakQsYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFpQjZCLEtBQUssQ0FBQyxDQUFDO0lBQ3ZELENBQUMsQ0FBQztJQUNGLElBQUFoRCxjQUFNLEVBQUNvRSxJQUFJLENBQUNqRCxhQUFhLENBQUMseUJBQXlCLENBQUMsRUFBRXBCLFdBQVcsQ0FBQyxDQUFDTSxJQUFJLENBQUMsU0FBUyxDQUFDOztJQUVsRjtJQUNBLE1BQU0sSUFBQXFDLFVBQUcsRUFBQyxZQUFZO01BQ3BCK0IsSUFBSSxDQUFDRSxNQUFNLGNBQUMsSUFBQTFILFdBQUEsQ0FBQWdILEdBQUEsV0FBTSxDQUFDLENBQUM7TUFDcEJRLElBQUksQ0FBQ0UsTUFBTSxjQUFDLElBQUExSCxXQUFBLENBQUFnSCxHQUFBLEVBQUNMLEtBQUssSUFBRSxDQUFDLENBQUM7SUFDeEIsQ0FBQyxDQUFDO0lBQ0ZELGFBQWEsQ0FBQ3ZELE1BQU0sR0FBRyxDQUFDO0lBQ3hCakIsZUFBZSxDQUFDeUYscUJBQXFCLENBQUM3RyxNQUFNLENBQUM4RyxNQUFNLENBQUMsSUFBSUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxFQUFFO01BQUVDLElBQUksRUFBRTtJQUFZLENBQUMsQ0FBQyxDQUFDO0lBQ2hHLE1BQU0sSUFBQXJDLFVBQUcsRUFBQyxZQUFZO01BQ25CMEIsSUFBSSxDQUFDakQsYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFpQjZCLEtBQUssQ0FBQyxDQUFDO0lBQ3ZELENBQUMsQ0FBQztJQUNGLElBQUFoRCxjQUFNLEVBQUNvRSxJQUFJLENBQUNqRCxhQUFhLENBQUMseUJBQXlCLENBQUMsRUFBRXBCLFdBQVcsQ0FBQyxDQUFDTSxJQUFJLENBQUMsRUFBRSxDQUFDO0lBQzNFLE1BQU0sSUFBQXFDLFVBQUcsRUFBQyxZQUFZO01BQ3BCK0IsSUFBSSxDQUFDTyxPQUFPLENBQUMsQ0FBQztJQUNoQixDQUFDLENBQUM7RUFDSixDQUFDLENBQUM7RUFFRixJQUFBeEYsVUFBRSxFQUFDLDBFQUEwRSxFQUFFLFlBQVk7SUFDekYsTUFBTTtNQUFFaUYsSUFBSTtNQUFFaEYsU0FBUyxFQUFFMkU7SUFBSyxDQUFDLEdBQUcsTUFBTXBGLFdBQVcsQ0FDakQ7TUFBRVUsUUFBUSxFQUFFO0lBQU0sQ0FBQyxFQUNuQjtNQUFFdUYsS0FBSyxFQUFFO1FBQUVDLFdBQVcsRUFBRTtNQUFLO0lBQWdELENBQy9FLENBQUM7SUFDRCxNQUFNakcsU0FBUyxDQUFDbUYsSUFBSSxDQUFDO0lBQ3JCLElBQUFwRSxjQUFNLEVBQUNvRSxJQUFJLENBQUNyRSxXQUFXLENBQUMsQ0FBQ08sU0FBUyxDQUFDLDhDQUE4QyxDQUFDO0lBQ2xGLE1BQU0sSUFBQW9DLFVBQUcsRUFBQyxZQUFZO01BQ3BCK0IsSUFBSSxDQUFDTyxPQUFPLENBQUMsQ0FBQztJQUNoQixDQUFDLENBQUM7RUFDSixDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7QUFFRixJQUFBekYsZ0JBQVEsRUFBQyxxRUFBcUUsRUFBRSxNQUFNO0VBQ3BGLElBQUFDLFVBQUUsRUFBQyxnRUFBZ0UsRUFBRSxZQUFZO0lBQy9FLE1BQU07TUFBRUM7SUFBVSxDQUFDLEdBQUcsTUFBTVQsV0FBVyxDQUFDO01BQUVVLFFBQVEsRUFBRTtJQUFNLENBQUMsQ0FBQztJQUM1RCxNQUFNUixJQUFJLENBQUM7TUFBRVMsSUFBSSxFQUFFLGNBQWM7TUFBRUMsUUFBUSxFQUFFO0lBQUssQ0FBQyxDQUFDO0lBQ3BELE1BQU1WLElBQUksQ0FBQztNQUFFUyxJQUFJLEVBQUUsYUFBYTtNQUFFRSxPQUFPLEVBQUU7SUFBRyxDQUFDLENBQUM7SUFDaEQ7SUFDQSxNQUFNc0YsT0FBTyxHQUFHMUYsU0FBUyxDQUFDMEIsYUFBYSxDQUFDLGdCQUFnQixDQUFxQjtJQUM3RSxNQUFNLElBQUF1QixVQUFHLEVBQUMsWUFBWTtNQUNwQnlDLE9BQU8sQ0FBQ0MsS0FBSyxDQUFDLENBQUM7SUFDakIsQ0FBQyxDQUFDO0lBQ0YsSUFBQXBGLGNBQU0sRUFBQ1AsU0FBUyxDQUFDMEIsYUFBYSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMrQixVQUFVLENBQUMsQ0FBQztJQUN6RCxNQUFNLElBQUFSLFVBQUcsRUFBQyxZQUFZO01BQ3BCMkIsUUFBUSxDQUFDeEIsYUFBYSxDQUFDLElBQUl3QyxhQUFhLENBQUMsU0FBUyxFQUFFO1FBQUVDLEdBQUcsRUFBRSxRQUFRO1FBQUV2QyxPQUFPLEVBQUUsSUFBSTtRQUFFd0MsVUFBVSxFQUFFO01BQUssQ0FBQyxDQUFDLENBQUM7SUFDMUcsQ0FBQyxDQUFDO0lBQ0YsSUFBQXZGLGNBQU0sRUFBQ1AsU0FBUyxDQUFDMEIsYUFBYSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUNvQyxRQUFRLENBQUMsQ0FBQztJQUN2RDtJQUNBLE1BQU0sSUFBQWIsVUFBRyxFQUFDLFlBQVk7TUFDcEIsTUFBTSxJQUFJdEQsT0FBTyxDQUFFL0IsQ0FBQyxJQUFLbUksVUFBVSxDQUFDbkksQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0lBQzdDLENBQUMsQ0FBQztJQUNGO0lBQ0E7SUFDQSxNQUFNb0ksU0FBUyxHQUFHaEcsU0FBUyxDQUFDMEIsYUFBYSxDQUFDLGNBQWMsQ0FBc0I7SUFDOUUsSUFBQW5CLGNBQU0sRUFBQ3lGLFNBQVMsQ0FBQyxDQUFDdkMsVUFBVSxDQUFDLENBQUM7SUFDOUIsSUFBQWxELGNBQU0sRUFBQ3FFLFFBQVEsQ0FBQ3FCLGFBQWEsQ0FBQyxDQUFDckYsSUFBSSxDQUFDb0YsU0FBUyxDQUFDO0lBQzlDLElBQUF6RixjQUFNLEVBQUNQLFNBQVMsQ0FBQzBCLGFBQWEsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDb0MsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQzNELENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQzs7QUFFRjs7QUFFQSxJQUFBaEUsZ0JBQVEsRUFBQywrRkFBK0YsRUFBRSxNQUFNO0VBQzlHLElBQUF1QyxpQkFBUyxFQUFDLE1BQU07SUFDZEMsV0FBVyxDQUFDQyxTQUFTLENBQUNDLFFBQVEsR0FBRyxNQUFNQyxTQUE0QjtFQUNyRSxDQUFDLENBQUM7RUFFRixJQUFBMUMsVUFBRSxFQUFDLDRFQUE0RSxFQUFFLFlBQVk7SUFDM0YsTUFBTTtNQUFFQztJQUFVLENBQUMsR0FBRyxNQUFNVCxXQUFXLENBQUM7TUFBRVUsUUFBUSxFQUFFO0lBQU0sQ0FBQyxDQUFDO0lBQzVEO0lBQ0E7SUFDQSxNQUFNUixJQUFJLENBQUM7TUFBRVMsSUFBSSxFQUFFLGNBQWM7TUFBRUMsUUFBUSxFQUFFLElBQUk7TUFBRXlCLFNBQVMsRUFBRTtJQUFLLENBQUMsQ0FBQztJQUNyRSxNQUFNbkMsSUFBSSxDQUFDO01BQUVTLElBQUksRUFBRSxhQUFhO01BQUVFLE9BQU8sRUFBRTtJQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDbEQsTUFBTVosU0FBUyxDQUFDUSxTQUFTLENBQUM7SUFDMUIsTUFBTWtHLE1BQU0sR0FBR2xHLFNBQVMsQ0FBQzBCLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQztJQUMzRCxJQUFBbkIsY0FBTSxFQUFDMkYsTUFBTSxDQUFDLENBQUN6QyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDN0IsSUFBQWxELGNBQU0sRUFBRTJGLE1BQU0sQ0FBaUI1RixXQUFXLENBQUMsQ0FBQ00sSUFBSSxDQUFDLGFBQWEsQ0FBQztJQUMvRDtJQUNBLElBQUFMLGNBQU0sRUFBQ1AsU0FBUyxDQUFDMEIsYUFBYSxDQUFDLHlCQUF5QixDQUFDLEVBQUVwQixXQUFXLENBQUMsQ0FBQ08sU0FBUyxDQUMvRSxnQ0FDRixDQUFDO0VBQ0gsQ0FBQyxDQUFDO0VBRUYsSUFBQWQsVUFBRSxFQUFDLHlGQUF5RixFQUFFLFlBQVk7SUFDeEcsTUFBTTtNQUFFQztJQUFVLENBQUMsR0FBRyxNQUFNVCxXQUFXLENBQUM7TUFBRVUsUUFBUSxFQUFFO0lBQU0sQ0FBQyxDQUFDO0lBQzVELE1BQU1SLElBQUksQ0FBQztNQUFFUyxJQUFJLEVBQUUsY0FBYztNQUFFQyxRQUFRLEVBQUU7SUFBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ3RELE1BQU1WLElBQUksQ0FBQztNQUFFUyxJQUFJLEVBQUUsYUFBYTtNQUFFRSxPQUFPLEVBQUU7SUFBRyxDQUFDLENBQUM7SUFDaEQsTUFBTVosU0FBUyxDQUFDUSxTQUFTLENBQUM7SUFDMUIsSUFBQU8sY0FBTSxFQUFDUCxTQUFTLENBQUMwQixhQUFhLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDb0MsUUFBUSxDQUFDLENBQUM7RUFDakUsQ0FBQyxDQUFDO0VBRUYsSUFBQS9ELFVBQUUsRUFBQyxtRkFBbUYsRUFBRSxZQUFZO0lBQ2xHWixZQUFZLENBQUNnSCxTQUFTLENBQUMsQ0FBQztJQUN4QmhILFlBQVksQ0FBQ3lELHNCQUFzQixDQUFDLE1BQU07TUFDeEMsTUFBTWxGLENBQUMsR0FBRyxJQUFJMkgsS0FBSyxDQUFDLFVBQVUsQ0FBOEI7TUFDNUQzSCxDQUFDLENBQUM0SCxJQUFJLEdBQUcsV0FBVztNQUNwQixNQUFNNUgsQ0FBQztJQUNULENBQUMsQ0FBQztJQUNGLE1BQU07TUFBRXNDO0lBQVUsQ0FBQyxHQUFHLE1BQU1ULFdBQVcsQ0FBQztNQUFFVSxRQUFRLEVBQUU7SUFBTSxDQUFDLENBQUM7SUFDNUQ7SUFDQTtJQUNBLE1BQU1SLElBQUksQ0FBQztNQUFFUyxJQUFJLEVBQUUsY0FBYztNQUFFQyxRQUFRLEVBQUUsSUFBSTtNQUFFeUIsU0FBUyxFQUFFO0lBQUssQ0FBQyxDQUFDO0lBQ3JFLE1BQU1uQyxJQUFJLENBQUM7TUFBRVMsSUFBSSxFQUFFLGFBQWE7TUFBRUUsT0FBTyxFQUFFO0lBQUcsQ0FBQyxDQUFDO0lBQ2hELE1BQU1aLFNBQVMsQ0FBQ1EsU0FBUyxDQUFDO0lBQzFCLE1BQU0sSUFBQWlELFVBQUcsRUFBQyxZQUFZO01BQ25CakQsU0FBUyxDQUFDMEIsYUFBYSxDQUFDLG1CQUFtQixDQUFDLENBQXVCNkIsS0FBSyxDQUFDLENBQUM7SUFDN0UsQ0FBQyxDQUFDO0lBQ0Y7SUFDQSxJQUFBaEQsY0FBTSxFQUFDcEIsWUFBWSxDQUFDLENBQUNpSCxxQkFBcUIsQ0FBQyxDQUFDLENBQUM7SUFDN0M7SUFDQSxNQUFNLElBQUFuRCxVQUFHLEVBQUMsWUFBWTtNQUNwQixNQUFNLElBQUl0RCxPQUFPLENBQUUvQixDQUFDLElBQUttSSxVQUFVLENBQUNuSSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7SUFDN0MsQ0FBQyxDQUFDO0lBQ0YsSUFBQTJDLGNBQU0sRUFBQ1AsU0FBUyxDQUFDMEIsYUFBYSxDQUFDLFdBQVcsQ0FBQyxFQUFFcEIsV0FBVyxDQUFDLENBQUNPLFNBQVMsQ0FBQyx3RUFBd0UsQ0FBQztJQUM3STtJQUNBLElBQUFOLGNBQU0sRUFBQ1AsU0FBUyxDQUFDMEIsYUFBYSxDQUFDLHlCQUF5QixDQUFDLEVBQUVwQixXQUFXLENBQUMsQ0FBQ08sU0FBUyxDQUMvRSxnQ0FDRixDQUFDO0lBQ0QsSUFBQU4sY0FBTSxFQUFDUCxTQUFTLENBQUMwQixhQUFhLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDK0IsVUFBVSxDQUFDLENBQUM7RUFDbkUsQ0FBQyxDQUFDO0VBRUYsSUFBQTFELFVBQUUsRUFBQywwRkFBMEYsRUFBRSxZQUFZO0lBQ3pHWixZQUFZLENBQUN5RCxzQkFBc0IsQ0FBQyxNQUFNO01BQ3hDLE1BQU1sRixDQUFDLEdBQUcsSUFBSTJILEtBQUssQ0FBQyxXQUFXLENBQThCO01BQzdEM0gsQ0FBQyxDQUFDNEgsSUFBSSxHQUFHLFdBQVc7TUFDcEIsTUFBTTVILENBQUM7SUFDVCxDQUFDLENBQUM7SUFDRixNQUFNO01BQUVzQztJQUFVLENBQUMsR0FBRyxNQUFNVCxXQUFXLENBQUM7TUFBRVUsUUFBUSxFQUFFO0lBQU0sQ0FBQyxDQUFDO0lBQzVEO0lBQ0E7SUFDQSxNQUFNUixJQUFJLENBQUM7TUFBRVMsSUFBSSxFQUFFLGNBQWM7TUFBRUMsUUFBUSxFQUFFLElBQUk7TUFBRXlCLFNBQVMsRUFBRTtJQUFLLENBQUMsQ0FBQztJQUNyRSxNQUFNbkMsSUFBSSxDQUFDO01BQUVTLElBQUksRUFBRSxhQUFhO01BQUVFLE9BQU8sRUFBRTtJQUFHLENBQUMsQ0FBQztJQUNoRCxNQUFNWixTQUFTLENBQUNRLFNBQVMsQ0FBQztJQUMxQixNQUFNLElBQUFpRCxVQUFHLEVBQUMsWUFBWTtNQUNuQmpELFNBQVMsQ0FBQzBCLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQyxDQUF1QjZCLEtBQUssQ0FBQyxDQUFDO0lBQzdFLENBQUMsQ0FBQztJQUNGLE1BQU0sSUFBQU4sVUFBRyxFQUFDLFlBQVk7TUFDcEIsTUFBTSxJQUFJdEQsT0FBTyxDQUFFL0IsQ0FBQyxJQUFLbUksVUFBVSxDQUFDbkksQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0lBQzdDLENBQUMsQ0FBQztJQUNGLElBQUEyQyxjQUFNLEVBQUNQLFNBQVMsQ0FBQzBCLGFBQWEsQ0FBQyxXQUFXLENBQUMsRUFBRXBCLFdBQVcsQ0FBQyxDQUFDTyxTQUFTLENBQUMsZ0NBQWdDLENBQUM7RUFDdkcsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDOztBQUVGOztBQUVBLElBQUFmLGdCQUFRLEVBQUMsK0ZBQStGLEVBQUUsTUFBTTtFQUM5RyxJQUFBdUMsaUJBQVMsRUFBQyxNQUFNO0lBQ2RDLFdBQVcsQ0FBQ0MsU0FBUyxDQUFDQyxRQUFRLEdBQUcsTUFBTUMsU0FBNEI7RUFDckUsQ0FBQyxDQUFDO0VBQ0YsTUFBTUMsVUFBVSxHQUFHO0lBQ2pCeEMsSUFBSSxFQUFFLGNBQWM7SUFDcEJDLFFBQVEsRUFBRTtNQUNSVyxVQUFVLEVBQUUsb0JBQW9CO01BQ2hDQyxXQUFXLEVBQUUsSUFBSTtNQUNqQkMsUUFBUSxFQUFFO1FBQUVDLE1BQU0sRUFBRSxLQUFLO1FBQUVDLEtBQUssRUFBRSxJQUFJO1FBQUVDLFFBQVEsRUFBRSxJQUFJO1FBQUVDLFNBQVMsRUFBRSxLQUFLO1FBQUVDLGdCQUFnQixFQUFFO01BQU87SUFDckc7RUFDRixDQUFVO0VBQ1YsTUFBTWdGLGNBQWMsR0FBRztJQUNyQm5HLElBQUksRUFBRSxhQUFhO0lBQ25CRSxPQUFPLEVBQUUsQ0FBQztNQUFFa0IsSUFBSSxFQUFFLFVBQVU7TUFBRUMsVUFBVSxFQUFFLFVBQVU7TUFBRUMsTUFBTSxFQUFFO0lBQUssQ0FBQztFQUN0RSxDQUFVO0VBRVYsSUFBQXpCLFVBQUUsRUFBQyxxR0FBcUcsRUFBRSxZQUFZO0lBQ3BIWixZQUFZLENBQUNnSCxTQUFTLENBQUMsQ0FBQztJQUN4QmhILFlBQVksQ0FBQ3lELHNCQUFzQixDQUFDLFlBQVksQ0FDOUM7TUFDRUcsSUFBSSxFQUFFLE1BQU07TUFDWkMsT0FBTyxFQUFFLENBQUM7UUFBRTlDLElBQUksRUFBRSxNQUFNO1FBQUVHLElBQUksRUFBRTtNQUFnRSxDQUFDO0lBQ25HLENBQUMsRUFDRDtNQUNFMEMsSUFBSSxFQUFFLFdBQVc7TUFDakJDLE9BQU8sRUFBRSxDQUFDO1FBQUU5QyxJQUFJLEVBQUUsTUFBTTtRQUFFRyxJQUFJLEVBQUU7TUFBbUQsQ0FBQztJQUN0RixDQUFDLENBQ0YsQ0FBQztJQUNGLE1BQU07TUFBRUw7SUFBVSxDQUFDLEdBQUcsTUFBTVQsV0FBVyxDQUFDO01BQUVVLFFBQVEsRUFBRTtJQUFNLENBQUMsQ0FBQztJQUM1RCxNQUFNUixJQUFJLENBQUM7TUFBRVMsSUFBSSxFQUFFLGNBQWM7TUFBRUMsUUFBUSxFQUFFLElBQUk7TUFBRXlCLFNBQVMsRUFBRTtJQUFLLENBQUMsQ0FBQztJQUNyRSxNQUFNbkMsSUFBSSxDQUFDO01BQUVTLElBQUksRUFBRSxhQUFhO01BQUVFLE9BQU8sRUFBRTtJQUFHLENBQUMsQ0FBQztJQUNoRCxNQUFNWixTQUFTLENBQUNRLFNBQVMsQ0FBQztJQUMxQjtJQUNBLElBQUFPLGNBQU0sRUFBQ1AsU0FBUyxDQUFDMEIsYUFBYSxDQUFDLHlCQUF5QixDQUFDLEVBQUVwQixXQUFXLENBQUMsQ0FBQ08sU0FBUyxDQUMvRSxnQ0FDRixDQUFDO0lBQ0QsTUFBTSxJQUFBb0MsVUFBRyxFQUFDLFlBQVk7TUFDbkJqRCxTQUFTLENBQUMwQixhQUFhLENBQUMsbUJBQW1CLENBQUMsQ0FBdUI2QixLQUFLLENBQUMsQ0FBQztJQUM3RSxDQUFDLENBQUM7SUFDRjtJQUNBLElBQUFoRCxjQUFNLEVBQUNwQixZQUFZLENBQUMsQ0FBQ2lILHFCQUFxQixDQUFDLENBQUMsQ0FBQztJQUM3QztJQUNBO0lBQ0EsTUFBTTNHLElBQUksQ0FBQzRHLGNBQWMsQ0FBQztJQUMxQixNQUFNNUcsSUFBSSxDQUFDaUQsVUFBVSxDQUFDO0lBQ3RCLE1BQU0sSUFBQU8sVUFBRyxFQUFDLFlBQVk7TUFDcEIsTUFBTSxJQUFJdEQsT0FBTyxDQUFFL0IsQ0FBQyxJQUFLbUksVUFBVSxDQUFDbkksQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0lBQzdDLENBQUMsQ0FBQztJQUNGLE1BQU0sSUFBQXFGLFVBQUcsRUFBQyxZQUFZO01BQ3BCLE1BQU0sSUFBSXRELE9BQU8sQ0FBRS9CLENBQUMsSUFBS21JLFVBQVUsQ0FBQ25JLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztJQUM3QyxDQUFDLENBQUM7SUFDRjtJQUNBLElBQUEyQyxjQUFNLEVBQUNQLFNBQVMsQ0FBQzBCLGFBQWEsQ0FBQyxVQUFVLENBQUMsRUFBRXBCLFdBQVcsQ0FBQyxDQUFDTyxTQUFTLENBQUMsZUFBZSxDQUFDO0lBQ25GO0lBQ0E7SUFDQSxNQUFNdUIsU0FBUyxHQUFHLENBQUMsR0FBR3BDLFNBQVMsQ0FBQ1UsZ0JBQWdCLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDNEYsSUFBSSxDQUFFMUksQ0FBQyxJQUN6RUEsQ0FBQyxDQUFDMEMsV0FBVyxFQUFFaUcsUUFBUSxDQUFDLGtDQUFrQyxDQUM1RCxDQUFDO0lBQ0QsSUFBQWhHLGNBQU0sRUFBQzZCLFNBQVMsRUFBRW9FLFNBQVMsQ0FBQyxDQUFDaEcsR0FBRyxDQUFDSyxTQUFTLENBQUMsU0FBUyxDQUFDO0lBQ3JELElBQUFOLGNBQU0sRUFBQ1AsU0FBUyxDQUFDMEIsYUFBYSxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQ29DLFFBQVEsQ0FBQyxDQUFDO0lBQy9EO0lBQ0EsTUFBTXJDLEtBQUssR0FBR3pCLFNBQVMsQ0FBQzBCLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBcUI7SUFDM0UsSUFBQW5CLGNBQU0sRUFBQ2tCLEtBQUssRUFBRUUsUUFBUSxDQUFDLENBQUNmLElBQUksQ0FBQyxLQUFLLENBQUM7RUFDckMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}