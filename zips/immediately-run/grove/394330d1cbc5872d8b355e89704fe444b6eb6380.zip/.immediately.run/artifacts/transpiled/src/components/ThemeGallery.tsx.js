var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = ThemeGallery;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.find.js");
require("core-js/modules/esnext.iterator.map.js");
var _catalogue = require("../data/catalogue");
var _themes = require("../data/themes");
var _jsxRuntime = require("react/jsx-runtime");
// The themes gallery (R3-311): one row per SHIPPED theme, enumerated from
// viewer.manifest.json — adding a theme to the manifest adds a row here with no
// edit to the entry. The swatch is the live gradient each catalogue entry
// declares (data/themes.ts), rendered with the theme's OWN tokens applied to the
// swatch chip, so the comparison is the real thing, not a screenshot of it.
function ThemeGallery() {
  const rows = (0, _catalogue.manifestThemes)();
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    className: "gg-gallery",
    role: "list",
    "aria-label": "The shipped themes",
    children: rows.map(([id, t]) => {
      const swatch = _themes.THEMES.find(x => x.id === id)?.swatch ?? 'linear-gradient(96deg,#888,#555)';
      return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "gg-row",
        role: "listitem",
        "data-gallery-id": id,
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          className: "gg-swatch",
          style: {
            background: swatch
          },
          "aria-hidden": true
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
          className: "gg-body",
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
            className: "gg-title",
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("code", {
              children: id
            }), " \u2014 ", t.label, /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
              className: "gg-meta",
              children: ["opens ", t.preferred]
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
            className: "gg-summary",
            children: t.summary
          })]
        })]
      }, id);
    })
  });
}
_c = ThemeGallery;
var _c;
$RefreshReg$(_c, "ThemeGallery");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY2F0YWxvZ3VlIiwicmVxdWlyZSIsIl90aGVtZXMiLCJfanN4UnVudGltZSIsIlRoZW1lR2FsbGVyeSIsInJvd3MiLCJtYW5pZmVzdFRoZW1lcyIsImpzeCIsImNsYXNzTmFtZSIsInJvbGUiLCJjaGlsZHJlbiIsIm1hcCIsImlkIiwidCIsInN3YXRjaCIsIlRIRU1FUyIsImZpbmQiLCJ4IiwianN4cyIsInN0eWxlIiwiYmFja2dyb3VuZCIsImxhYmVsIiwicHJlZmVycmVkIiwic3VtbWFyeSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiVGhlbWVHYWxsZXJ5LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBtYW5pZmVzdFRoZW1lcyB9IGZyb20gJy4uL2RhdGEvY2F0YWxvZ3VlJztcbmltcG9ydCB7IFRIRU1FUyB9IGZyb20gJy4uL2RhdGEvdGhlbWVzJztcblxuLy8gVGhlIHRoZW1lcyBnYWxsZXJ5IChSMy0zMTEpOiBvbmUgcm93IHBlciBTSElQUEVEIHRoZW1lLCBlbnVtZXJhdGVkIGZyb21cbi8vIHZpZXdlci5tYW5pZmVzdC5qc29uIOKAlCBhZGRpbmcgYSB0aGVtZSB0byB0aGUgbWFuaWZlc3QgYWRkcyBhIHJvdyBoZXJlIHdpdGggbm9cbi8vIGVkaXQgdG8gdGhlIGVudHJ5LiBUaGUgc3dhdGNoIGlzIHRoZSBsaXZlIGdyYWRpZW50IGVhY2ggY2F0YWxvZ3VlIGVudHJ5XG4vLyBkZWNsYXJlcyAoZGF0YS90aGVtZXMudHMpLCByZW5kZXJlZCB3aXRoIHRoZSB0aGVtZSdzIE9XTiB0b2tlbnMgYXBwbGllZCB0byB0aGVcbi8vIHN3YXRjaCBjaGlwLCBzbyB0aGUgY29tcGFyaXNvbiBpcyB0aGUgcmVhbCB0aGluZywgbm90IGEgc2NyZWVuc2hvdCBvZiBpdC5cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gVGhlbWVHYWxsZXJ5KCkge1xuICBjb25zdCByb3dzID0gbWFuaWZlc3RUaGVtZXMoKTtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImdnLWdhbGxlcnlcIiByb2xlPVwibGlzdFwiIGFyaWEtbGFiZWw9XCJUaGUgc2hpcHBlZCB0aGVtZXNcIj5cbiAgICAgIHtyb3dzLm1hcCgoW2lkLCB0XSkgPT4ge1xuICAgICAgICBjb25zdCBzd2F0Y2ggPSBUSEVNRVMuZmluZCgoeCkgPT4geC5pZCA9PT0gaWQpPy5zd2F0Y2ggPz8gJ2xpbmVhci1ncmFkaWVudCg5NmRlZywjODg4LCM1NTUpJztcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdnLXJvd1wiIHJvbGU9XCJsaXN0aXRlbVwiIGtleT17aWR9IGRhdGEtZ2FsbGVyeS1pZD17aWR9PlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZ2ctc3dhdGNoXCIgc3R5bGU9e3sgYmFja2dyb3VuZDogc3dhdGNoIH19IGFyaWEtaGlkZGVuIC8+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdnLWJvZHlcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJnZy10aXRsZVwiPlxuICAgICAgICAgICAgICAgIDxjb2RlPntpZH08L2NvZGU+IOKAlCB7dC5sYWJlbH1cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJnZy1tZXRhXCI+b3BlbnMge3QucHJlZmVycmVkfTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ2ctc3VtbWFyeVwiPnt0LnN1bW1hcnl9PC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKTtcbiAgICAgIH0pfVxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBQSxJQUFBQSxVQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxPQUFBLEdBQUFELE9BQUE7QUFBd0MsSUFBQUUsV0FBQSxHQUFBRixPQUFBO0FBRXhDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFZSxTQUFTRyxZQUFZQSxDQUFBLEVBQUc7RUFDckMsTUFBTUMsSUFBSSxHQUFHLElBQUFDLHlCQUFjLEVBQUMsQ0FBQztFQUM3QixvQkFDRSxJQUFBSCxXQUFBLENBQUFJLEdBQUE7SUFBS0MsU0FBUyxFQUFDLFlBQVk7SUFBQ0MsSUFBSSxFQUFDLE1BQU07SUFBQyxjQUFXLG9CQUFvQjtJQUFBQyxRQUFBLEVBQ3BFTCxJQUFJLENBQUNNLEdBQUcsQ0FBQyxDQUFDLENBQUNDLEVBQUUsRUFBRUMsQ0FBQyxDQUFDLEtBQUs7TUFDckIsTUFBTUMsTUFBTSxHQUFHQyxjQUFNLENBQUNDLElBQUksQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUNMLEVBQUUsS0FBS0EsRUFBRSxDQUFDLEVBQUVFLE1BQU0sSUFBSSxrQ0FBa0M7TUFDNUYsb0JBQ0UsSUFBQVgsV0FBQSxDQUFBZSxJQUFBO1FBQUtWLFNBQVMsRUFBQyxRQUFRO1FBQUNDLElBQUksRUFBQyxVQUFVO1FBQVUsbUJBQWlCRyxFQUFHO1FBQUFGLFFBQUEsZ0JBQ25FLElBQUFQLFdBQUEsQ0FBQUksR0FBQTtVQUFNQyxTQUFTLEVBQUMsV0FBVztVQUFDVyxLQUFLLEVBQUU7WUFBRUMsVUFBVSxFQUFFTjtVQUFPLENBQUU7VUFBQztRQUFXLENBQUUsQ0FBQyxlQUN6RSxJQUFBWCxXQUFBLENBQUFlLElBQUE7VUFBS1YsU0FBUyxFQUFDLFNBQVM7VUFBQUUsUUFBQSxnQkFDdEIsSUFBQVAsV0FBQSxDQUFBZSxJQUFBO1lBQUtWLFNBQVMsRUFBQyxVQUFVO1lBQUFFLFFBQUEsZ0JBQ3ZCLElBQUFQLFdBQUEsQ0FBQUksR0FBQTtjQUFBRyxRQUFBLEVBQU9FO1lBQUUsQ0FBTyxDQUFDLFlBQUcsRUFBQ0MsQ0FBQyxDQUFDUSxLQUFLLGVBQzVCLElBQUFsQixXQUFBLENBQUFlLElBQUE7Y0FBTVYsU0FBUyxFQUFDLFNBQVM7Y0FBQUUsUUFBQSxHQUFDLFFBQU0sRUFBQ0csQ0FBQyxDQUFDUyxTQUFTO1lBQUEsQ0FBTyxDQUFDO1VBQUEsQ0FDakQsQ0FBQyxlQUNOLElBQUFuQixXQUFBLENBQUFJLEdBQUE7WUFBS0MsU0FBUyxFQUFDLFlBQVk7WUFBQUUsUUFBQSxFQUFFRyxDQUFDLENBQUNVO1VBQU8sQ0FBTSxDQUFDO1FBQUEsQ0FDMUMsQ0FBQztNQUFBLEdBUnFDWCxFQVN4QyxDQUFDO0lBRVYsQ0FBQztFQUFDLENBQ0MsQ0FBQztBQUVWO0FBQUNZLEVBQUEsR0FyQnVCcEIsWUFBWTtBQUFBLElBQUFvQixFQUFBO0FBQUFDLFlBQUEsQ0FBQUQsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}