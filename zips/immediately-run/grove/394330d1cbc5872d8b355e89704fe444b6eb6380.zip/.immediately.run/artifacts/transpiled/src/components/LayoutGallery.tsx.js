var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = LayoutGallery;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
var _catalogue = require("../data/catalogue");
var _jsxRuntime = require("react/jsx-runtime");
// The layouts gallery (R3-311): the twelve shapes, grouped by the three buckets
// the catalogue exists as three of — because the MECHANISM differs per bucket (a
// copyable starter file · a frontmatter key · a component call), and one flat
// list would promise what a starter cannot deliver. Enumerated from
// viewer.manifest.json: adding a shape adds a row with no edit to the entry.
function Section({
  title,
  note,
  children
}) {
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("section", {
    className: "gg-section",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("h3", {
      children: title
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
      className: "gg-note",
      children: note
    }), children]
  });
}
_c = Section;
function LayoutGallery() {
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "gg-gallery",
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(Section, {
      title: "Layout starters",
      note: "An `_layout.mdx` file a contributor copies \u2014 chrome is content.",
      children: (0, _catalogue.manifestLayouts)().map(([id, l]) => /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "gg-row",
        role: "listitem",
        "data-gallery-id": id,
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
          className: "gg-body",
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
            className: "gg-title",
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("code", {
              children: id
            }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
              className: "gg-meta",
              children: l.arranges
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
            className: "gg-summary",
            children: l.summary
          })]
        })
      }, id))
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)(Section, {
      title: "Page variants",
      note: "A frontmatter key on one entry \u2014 the page, not the chrome.",
      children: (0, _catalogue.manifestPageVariants)().map(([id, v]) => /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "gg-row",
        role: "listitem",
        "data-gallery-id": id,
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
          className: "gg-body",
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
            className: "gg-title",
            children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("code", {
              children: [v.key, ": ", v.value]
            }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
              className: "gg-meta",
              children: id
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
            className: "gg-summary",
            children: v.summary
          })]
        })
      }, id))
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)(Section, {
      title: "Collection shapes",
      note: "What a list of entries looks like \u2014 a component call.",
      children: (0, _catalogue.manifestCollections)().map(([id, c]) => /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "gg-row",
        role: "listitem",
        "data-gallery-id": id,
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
          className: "gg-body",
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
            className: "gg-title",
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("code", {
              children: id
            }), c.component && /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
              className: "gg-meta",
              children: ["<", c.component, ">"]
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
            className: "gg-summary",
            children: c.summary
          })]
        })
      }, id))
    })]
  });
}
_c2 = LayoutGallery;
var _c, _c2;
$RefreshReg$(_c, "Section");
$RefreshReg$(_c2, "LayoutGallery");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY2F0YWxvZ3VlIiwicmVxdWlyZSIsIl9qc3hSdW50aW1lIiwiU2VjdGlvbiIsInRpdGxlIiwibm90ZSIsImNoaWxkcmVuIiwianN4cyIsImNsYXNzTmFtZSIsImpzeCIsIl9jIiwiTGF5b3V0R2FsbGVyeSIsIm1hbmlmZXN0TGF5b3V0cyIsIm1hcCIsImlkIiwibCIsInJvbGUiLCJhcnJhbmdlcyIsInN1bW1hcnkiLCJtYW5pZmVzdFBhZ2VWYXJpYW50cyIsInYiLCJrZXkiLCJ2YWx1ZSIsIm1hbmlmZXN0Q29sbGVjdGlvbnMiLCJjIiwiY29tcG9uZW50IiwiX2MyIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiTGF5b3V0R2FsbGVyeS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgbWFuaWZlc3RMYXlvdXRzLCBtYW5pZmVzdFBhZ2VWYXJpYW50cywgbWFuaWZlc3RDb2xsZWN0aW9ucyB9IGZyb20gJy4uL2RhdGEvY2F0YWxvZ3VlJztcblxuLy8gVGhlIGxheW91dHMgZ2FsbGVyeSAoUjMtMzExKTogdGhlIHR3ZWx2ZSBzaGFwZXMsIGdyb3VwZWQgYnkgdGhlIHRocmVlIGJ1Y2tldHNcbi8vIHRoZSBjYXRhbG9ndWUgZXhpc3RzIGFzIHRocmVlIG9mIOKAlCBiZWNhdXNlIHRoZSBNRUNIQU5JU00gZGlmZmVycyBwZXIgYnVja2V0IChhXG4vLyBjb3B5YWJsZSBzdGFydGVyIGZpbGUgwrcgYSBmcm9udG1hdHRlciBrZXkgwrcgYSBjb21wb25lbnQgY2FsbCksIGFuZCBvbmUgZmxhdFxuLy8gbGlzdCB3b3VsZCBwcm9taXNlIHdoYXQgYSBzdGFydGVyIGNhbm5vdCBkZWxpdmVyLiBFbnVtZXJhdGVkIGZyb21cbi8vIHZpZXdlci5tYW5pZmVzdC5qc29uOiBhZGRpbmcgYSBzaGFwZSBhZGRzIGEgcm93IHdpdGggbm8gZWRpdCB0byB0aGUgZW50cnkuXG5cbmZ1bmN0aW9uIFNlY3Rpb24oeyB0aXRsZSwgbm90ZSwgY2hpbGRyZW4gfTogeyB0aXRsZTogc3RyaW5nOyBub3RlOiBzdHJpbmc7IGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGUgfSkge1xuICByZXR1cm4gKFxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImdnLXNlY3Rpb25cIj5cbiAgICAgIDxoMz57dGl0bGV9PC9oMz5cbiAgICAgIDxwIGNsYXNzTmFtZT1cImdnLW5vdGVcIj57bm90ZX08L3A+XG4gICAgICB7Y2hpbGRyZW59XG4gICAgPC9zZWN0aW9uPlxuICApO1xufVxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBMYXlvdXRHYWxsZXJ5KCkge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZ2ctZ2FsbGVyeVwiPlxuICAgICAgPFNlY3Rpb24gdGl0bGU9XCJMYXlvdXQgc3RhcnRlcnNcIiBub3RlPVwiQW4gYF9sYXlvdXQubWR4YCBmaWxlIGEgY29udHJpYnV0b3IgY29waWVzIOKAlCBjaHJvbWUgaXMgY29udGVudC5cIj5cbiAgICAgICAge21hbmlmZXN0TGF5b3V0cygpLm1hcCgoW2lkLCBsXSkgPT4gKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ2ctcm93XCIgcm9sZT1cImxpc3RpdGVtXCIga2V5PXtpZH0gZGF0YS1nYWxsZXJ5LWlkPXtpZH0+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdnLWJvZHlcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJnZy10aXRsZVwiPlxuICAgICAgICAgICAgICAgIDxjb2RlPntpZH08L2NvZGU+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZ2ctbWV0YVwiPntsLmFycmFuZ2VzfTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ2ctc3VtbWFyeVwiPntsLnN1bW1hcnl9PC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKSl9XG4gICAgICA8L1NlY3Rpb24+XG4gICAgICA8U2VjdGlvbiB0aXRsZT1cIlBhZ2UgdmFyaWFudHNcIiBub3RlPVwiQSBmcm9udG1hdHRlciBrZXkgb24gb25lIGVudHJ5IOKAlCB0aGUgcGFnZSwgbm90IHRoZSBjaHJvbWUuXCI+XG4gICAgICAgIHttYW5pZmVzdFBhZ2VWYXJpYW50cygpLm1hcCgoW2lkLCB2XSkgPT4gKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ2ctcm93XCIgcm9sZT1cImxpc3RpdGVtXCIga2V5PXtpZH0gZGF0YS1nYWxsZXJ5LWlkPXtpZH0+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdnLWJvZHlcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJnZy10aXRsZVwiPlxuICAgICAgICAgICAgICAgIDxjb2RlPlxuICAgICAgICAgICAgICAgICAge3Yua2V5fToge3YudmFsdWV9XG4gICAgICAgICAgICAgICAgPC9jb2RlPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImdnLW1ldGFcIj57aWR9PC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJnZy1zdW1tYXJ5XCI+e3Yuc3VtbWFyeX08L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApKX1cbiAgICAgIDwvU2VjdGlvbj5cbiAgICAgIDxTZWN0aW9uIHRpdGxlPVwiQ29sbGVjdGlvbiBzaGFwZXNcIiBub3RlPVwiV2hhdCBhIGxpc3Qgb2YgZW50cmllcyBsb29rcyBsaWtlIOKAlCBhIGNvbXBvbmVudCBjYWxsLlwiPlxuICAgICAgICB7bWFuaWZlc3RDb2xsZWN0aW9ucygpLm1hcCgoW2lkLCBjXSkgPT4gKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ2ctcm93XCIgcm9sZT1cImxpc3RpdGVtXCIga2V5PXtpZH0gZGF0YS1nYWxsZXJ5LWlkPXtpZH0+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdnLWJvZHlcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJnZy10aXRsZVwiPlxuICAgICAgICAgICAgICAgIDxjb2RlPntpZH08L2NvZGU+XG4gICAgICAgICAgICAgICAge2MuY29tcG9uZW50ICYmIDxzcGFuIGNsYXNzTmFtZT1cImdnLW1ldGFcIj4mbHQ7e2MuY29tcG9uZW50fSZndDs8L3NwYW4+fVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJnZy1zdW1tYXJ5XCI+e2Muc3VtbWFyeX08L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApKX1cbiAgICAgIDwvU2VjdGlvbj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQSxJQUFBQSxVQUFBLEdBQUFDLE9BQUE7QUFBK0YsSUFBQUMsV0FBQSxHQUFBRCxPQUFBO0FBRS9GO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQSxTQUFTRSxPQUFPQSxDQUFDO0VBQUVDLEtBQUs7RUFBRUMsSUFBSTtFQUFFQztBQUFxRSxDQUFDLEVBQUU7RUFDdEcsb0JBQ0UsSUFBQUosV0FBQSxDQUFBSyxJQUFBO0lBQVNDLFNBQVMsRUFBQyxZQUFZO0lBQUFGLFFBQUEsZ0JBQzdCLElBQUFKLFdBQUEsQ0FBQU8sR0FBQTtNQUFBSCxRQUFBLEVBQUtGO0lBQUssQ0FBSyxDQUFDLGVBQ2hCLElBQUFGLFdBQUEsQ0FBQU8sR0FBQTtNQUFHRCxTQUFTLEVBQUMsU0FBUztNQUFBRixRQUFBLEVBQUVEO0lBQUksQ0FBSSxDQUFDLEVBQ2hDQyxRQUFRO0VBQUEsQ0FDRixDQUFDO0FBRWQ7QUFBQ0ksRUFBQSxHQVJRUCxPQUFPO0FBVUQsU0FBU1EsYUFBYUEsQ0FBQSxFQUFHO0VBQ3RDLG9CQUNFLElBQUFULFdBQUEsQ0FBQUssSUFBQTtJQUFLQyxTQUFTLEVBQUMsWUFBWTtJQUFBRixRQUFBLGdCQUN6QixJQUFBSixXQUFBLENBQUFPLEdBQUEsRUFBQ04sT0FBTztNQUFDQyxLQUFLLEVBQUMsaUJBQWlCO01BQUNDLElBQUksRUFBQyxzRUFBaUU7TUFBQUMsUUFBQSxFQUNwRyxJQUFBTSwwQkFBZSxFQUFDLENBQUMsQ0FBQ0MsR0FBRyxDQUFDLENBQUMsQ0FBQ0MsRUFBRSxFQUFFQyxDQUFDLENBQUMsa0JBQzdCLElBQUFiLFdBQUEsQ0FBQU8sR0FBQTtRQUFLRCxTQUFTLEVBQUMsUUFBUTtRQUFDUSxJQUFJLEVBQUMsVUFBVTtRQUFVLG1CQUFpQkYsRUFBRztRQUFBUixRQUFBLGVBQ25FLElBQUFKLFdBQUEsQ0FBQUssSUFBQTtVQUFLQyxTQUFTLEVBQUMsU0FBUztVQUFBRixRQUFBLGdCQUN0QixJQUFBSixXQUFBLENBQUFLLElBQUE7WUFBS0MsU0FBUyxFQUFDLFVBQVU7WUFBQUYsUUFBQSxnQkFDdkIsSUFBQUosV0FBQSxDQUFBTyxHQUFBO2NBQUFILFFBQUEsRUFBT1E7WUFBRSxDQUFPLENBQUMsZUFDakIsSUFBQVosV0FBQSxDQUFBTyxHQUFBO2NBQU1ELFNBQVMsRUFBQyxTQUFTO2NBQUFGLFFBQUEsRUFBRVMsQ0FBQyxDQUFDRTtZQUFRLENBQU8sQ0FBQztVQUFBLENBQzFDLENBQUMsZUFDTixJQUFBZixXQUFBLENBQUFPLEdBQUE7WUFBS0QsU0FBUyxFQUFDLFlBQVk7WUFBQUYsUUFBQSxFQUFFUyxDQUFDLENBQUNHO1VBQU8sQ0FBTSxDQUFDO1FBQUEsQ0FDMUM7TUFBQyxHQVBxQ0osRUFReEMsQ0FDTjtJQUFDLENBQ0ssQ0FBQyxlQUNWLElBQUFaLFdBQUEsQ0FBQU8sR0FBQSxFQUFDTixPQUFPO01BQUNDLEtBQUssRUFBQyxlQUFlO01BQUNDLElBQUksRUFBQyxpRUFBNEQ7TUFBQUMsUUFBQSxFQUM3RixJQUFBYSwrQkFBb0IsRUFBQyxDQUFDLENBQUNOLEdBQUcsQ0FBQyxDQUFDLENBQUNDLEVBQUUsRUFBRU0sQ0FBQyxDQUFDLGtCQUNsQyxJQUFBbEIsV0FBQSxDQUFBTyxHQUFBO1FBQUtELFNBQVMsRUFBQyxRQUFRO1FBQUNRLElBQUksRUFBQyxVQUFVO1FBQVUsbUJBQWlCRixFQUFHO1FBQUFSLFFBQUEsZUFDbkUsSUFBQUosV0FBQSxDQUFBSyxJQUFBO1VBQUtDLFNBQVMsRUFBQyxTQUFTO1VBQUFGLFFBQUEsZ0JBQ3RCLElBQUFKLFdBQUEsQ0FBQUssSUFBQTtZQUFLQyxTQUFTLEVBQUMsVUFBVTtZQUFBRixRQUFBLGdCQUN2QixJQUFBSixXQUFBLENBQUFLLElBQUE7Y0FBQUQsUUFBQSxHQUNHYyxDQUFDLENBQUNDLEdBQUcsRUFBQyxJQUFFLEVBQUNELENBQUMsQ0FBQ0UsS0FBSztZQUFBLENBQ2IsQ0FBQyxlQUNQLElBQUFwQixXQUFBLENBQUFPLEdBQUE7Y0FBTUQsU0FBUyxFQUFDLFNBQVM7Y0FBQUYsUUFBQSxFQUFFUTtZQUFFLENBQU8sQ0FBQztVQUFBLENBQ2xDLENBQUMsZUFDTixJQUFBWixXQUFBLENBQUFPLEdBQUE7WUFBS0QsU0FBUyxFQUFDLFlBQVk7WUFBQUYsUUFBQSxFQUFFYyxDQUFDLENBQUNGO1VBQU8sQ0FBTSxDQUFDO1FBQUEsQ0FDMUM7TUFBQyxHQVRxQ0osRUFVeEMsQ0FDTjtJQUFDLENBQ0ssQ0FBQyxlQUNWLElBQUFaLFdBQUEsQ0FBQU8sR0FBQSxFQUFDTixPQUFPO01BQUNDLEtBQUssRUFBQyxtQkFBbUI7TUFBQ0MsSUFBSSxFQUFDLDREQUF1RDtNQUFBQyxRQUFBLEVBQzVGLElBQUFpQiw4QkFBbUIsRUFBQyxDQUFDLENBQUNWLEdBQUcsQ0FBQyxDQUFDLENBQUNDLEVBQUUsRUFBRVUsQ0FBQyxDQUFDLGtCQUNqQyxJQUFBdEIsV0FBQSxDQUFBTyxHQUFBO1FBQUtELFNBQVMsRUFBQyxRQUFRO1FBQUNRLElBQUksRUFBQyxVQUFVO1FBQVUsbUJBQWlCRixFQUFHO1FBQUFSLFFBQUEsZUFDbkUsSUFBQUosV0FBQSxDQUFBSyxJQUFBO1VBQUtDLFNBQVMsRUFBQyxTQUFTO1VBQUFGLFFBQUEsZ0JBQ3RCLElBQUFKLFdBQUEsQ0FBQUssSUFBQTtZQUFLQyxTQUFTLEVBQUMsVUFBVTtZQUFBRixRQUFBLGdCQUN2QixJQUFBSixXQUFBLENBQUFPLEdBQUE7Y0FBQUgsUUFBQSxFQUFPUTtZQUFFLENBQU8sQ0FBQyxFQUNoQlUsQ0FBQyxDQUFDQyxTQUFTLGlCQUFJLElBQUF2QixXQUFBLENBQUFLLElBQUE7Y0FBTUMsU0FBUyxFQUFDLFNBQVM7Y0FBQUYsUUFBQSxHQUFDLEdBQUksRUFBQ2tCLENBQUMsQ0FBQ0MsU0FBUyxFQUFDLEdBQUk7WUFBQSxDQUFNLENBQUM7VUFBQSxDQUNuRSxDQUFDLGVBQ04sSUFBQXZCLFdBQUEsQ0FBQU8sR0FBQTtZQUFLRCxTQUFTLEVBQUMsWUFBWTtZQUFBRixRQUFBLEVBQUVrQixDQUFDLENBQUNOO1VBQU8sQ0FBTSxDQUFDO1FBQUEsQ0FDMUM7TUFBQyxHQVBxQ0osRUFReEMsQ0FDTjtJQUFDLENBQ0ssQ0FBQztFQUFBLENBQ1AsQ0FBQztBQUVWO0FBQUNZLEdBQUEsR0E5Q3VCZixhQUFhO0FBQUEsSUFBQUQsRUFBQSxFQUFBZ0IsR0FBQTtBQUFBQyxZQUFBLENBQUFqQixFQUFBO0FBQUFpQixZQUFBLENBQUFELEdBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}