var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

require("./index.css");
require("./GroveApp.css");
var _boot = require("@immediately-run/sdk/boot");
var _mdxComponents = require("./mdxComponents");
var _App = _interopRequireDefault(require("./App"));
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// Entry point. immediately.run runs this module (package.json "main") and
// boot() installs the host runtime providers (module cache, MDX provider,
// TinkerableContext, router) and renders into #root. Global CSS is imported
// here so it is present at runtime.

// A single catch-all route renders the Grove shell for every URL; the shell
// reads the current path from TinkerableContext and renders the matching entry,
// so the nav/footer/theme chrome persists across navigation.
(0, _boot.boot)({
  mdxComponents: _mdxComponents.GROVE_MDX,
  routingSpec: {
    routes: [{
      name: 'grove',
      pattern: /.*/,
      reactNode: /*#__PURE__*/(0, _jsxRuntime.jsx)(_App.default, {})
    }]
  }
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJyZXF1aXJlIiwiX2Jvb3QiLCJfbWR4Q29tcG9uZW50cyIsIl9BcHAiLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX2pzeFJ1bnRpbWUiLCJlIiwiX19lc01vZHVsZSIsImRlZmF1bHQiLCJib290IiwibWR4Q29tcG9uZW50cyIsIkdST1ZFX01EWCIsInJvdXRpbmdTcGVjIiwicm91dGVzIiwibmFtZSIsInBhdHRlcm4iLCJyZWFjdE5vZGUiLCJqc3giXSwic291cmNlcyI6WyJtYWluLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBFbnRyeSBwb2ludC4gaW1tZWRpYXRlbHkucnVuIHJ1bnMgdGhpcyBtb2R1bGUgKHBhY2thZ2UuanNvbiBcIm1haW5cIikgYW5kXG4vLyBib290KCkgaW5zdGFsbHMgdGhlIGhvc3QgcnVudGltZSBwcm92aWRlcnMgKG1vZHVsZSBjYWNoZSwgTURYIHByb3ZpZGVyLFxuLy8gVGlua2VyYWJsZUNvbnRleHQsIHJvdXRlcikgYW5kIHJlbmRlcnMgaW50byAjcm9vdC4gR2xvYmFsIENTUyBpcyBpbXBvcnRlZFxuLy8gaGVyZSBzbyBpdCBpcyBwcmVzZW50IGF0IHJ1bnRpbWUuXG5pbXBvcnQgJy4vaW5kZXguY3NzJztcbmltcG9ydCAnLi9Hcm92ZUFwcC5jc3MnO1xuaW1wb3J0IHsgYm9vdCB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrL2Jvb3QnO1xuaW1wb3J0IHsgR1JPVkVfTURYIH0gZnJvbSAnLi9tZHhDb21wb25lbnRzJztcbmltcG9ydCBBcHAgZnJvbSAnLi9BcHAnO1xuXG4vLyBBIHNpbmdsZSBjYXRjaC1hbGwgcm91dGUgcmVuZGVycyB0aGUgR3JvdmUgc2hlbGwgZm9yIGV2ZXJ5IFVSTDsgdGhlIHNoZWxsXG4vLyByZWFkcyB0aGUgY3VycmVudCBwYXRoIGZyb20gVGlua2VyYWJsZUNvbnRleHQgYW5kIHJlbmRlcnMgdGhlIG1hdGNoaW5nIGVudHJ5LFxuLy8gc28gdGhlIG5hdi9mb290ZXIvdGhlbWUgY2hyb21lIHBlcnNpc3RzIGFjcm9zcyBuYXZpZ2F0aW9uLlxuYm9vdCh7XG4gIG1keENvbXBvbmVudHM6IEdST1ZFX01EWCBhcyBuZXZlcixcbiAgcm91dGluZ1NwZWM6IHtcbiAgICByb3V0ZXM6IFt7IG5hbWU6ICdncm92ZScsIHBhdHRlcm46IC8uKi8sIHJlYWN0Tm9kZTogPEFwcCAvPiB9XSxcbiAgfSxcbn0pO1xuIl0sIm1hcHBpbmdzIjoiOztBQUlBQSxPQUFBO0FBQ0FBLE9BQUE7QUFDQSxJQUFBQyxLQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxjQUFBLEdBQUFGLE9BQUE7QUFDQSxJQUFBRyxJQUFBLEdBQUFDLHNCQUFBLENBQUFKLE9BQUE7QUFBd0IsSUFBQUssV0FBQSxHQUFBTCxPQUFBO0FBQUEsU0FBQUksdUJBQUFFLENBQUEsV0FBQUEsQ0FBQSxJQUFBQSxDQUFBLENBQUFDLFVBQUEsR0FBQUQsQ0FBQSxLQUFBRSxPQUFBLEVBQUFGLENBQUE7QUFSeEI7QUFDQTtBQUNBO0FBQ0E7O0FBT0E7QUFDQTtBQUNBO0FBQ0EsSUFBQUcsVUFBSSxFQUFDO0VBQ0hDLGFBQWEsRUFBRUMsd0JBQWtCO0VBQ2pDQyxXQUFXLEVBQUU7SUFDWEMsTUFBTSxFQUFFLENBQUM7TUFBRUMsSUFBSSxFQUFFLE9BQU87TUFBRUMsT0FBTyxFQUFFLElBQUk7TUFBRUMsU0FBUyxlQUFFLElBQUFYLFdBQUEsQ0FBQVksR0FBQSxFQUFDZCxJQUFBLENBQUFLLE9BQUcsSUFBRTtJQUFFLENBQUM7RUFDL0Q7QUFDRixDQUFDLENBQUMiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}