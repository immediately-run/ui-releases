var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = BootMessage;
var _jsxRuntime = require("react/jsx-runtime");
/** The single line Grove shows while it cannot paint an entry yet — booting, listing the
 *  bundle, or waiting on the files an entry needs — and, given a message, when boot fails. */
function BootMessage({
  children = 'Opening…'
}) {
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    className: "grove-boot",
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
      className: "grove-boot__msg",
      children: children
    })
  });
}
_c = BootMessage;
var _c;
$RefreshReg$(_c, "BootMessage");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJCb290TWVzc2FnZSIsImNoaWxkcmVuIiwiX2pzeFJ1bnRpbWUiLCJqc3giLCJjbGFzc05hbWUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkJvb3RNZXNzYWdlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IFJlYWN0Tm9kZSB9IGZyb20gJ3JlYWN0JztcblxuLyoqIFRoZSBzaW5nbGUgbGluZSBHcm92ZSBzaG93cyB3aGlsZSBpdCBjYW5ub3QgcGFpbnQgYW4gZW50cnkgeWV0IOKAlCBib290aW5nLCBsaXN0aW5nIHRoZVxuICogIGJ1bmRsZSwgb3Igd2FpdGluZyBvbiB0aGUgZmlsZXMgYW4gZW50cnkgbmVlZHMg4oCUIGFuZCwgZ2l2ZW4gYSBtZXNzYWdlLCB3aGVuIGJvb3QgZmFpbHMuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBCb290TWVzc2FnZSh7IGNoaWxkcmVuID0gJ09wZW5pbmfigKYnIH06IHsgY2hpbGRyZW4/OiBSZWFjdE5vZGUgfSkge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JvdmUtYm9vdFwiPlxuICAgICAgPHAgY2xhc3NOYW1lPVwiZ3JvdmUtYm9vdF9fbXNnXCI+e2NoaWxkcmVufTwvcD5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUVBO0FBQ0E7QUFDZSxTQUFTQSxXQUFXQSxDQUFDO0VBQUVDLFFBQVEsR0FBRztBQUFxQyxDQUFDLEVBQUU7RUFDdkYsb0JBQ0UsSUFBQUMsV0FBQSxDQUFBQyxHQUFBO0lBQUtDLFNBQVMsRUFBQyxZQUFZO0lBQUFILFFBQUEsZUFDekIsSUFBQUMsV0FBQSxDQUFBQyxHQUFBO01BQUdDLFNBQVMsRUFBQyxpQkFBaUI7TUFBQUgsUUFBQSxFQUFFQTtJQUFRLENBQUk7RUFBQyxDQUMxQyxDQUFDO0FBRVY7QUFBQ0ksRUFBQSxHQU51QkwsV0FBVztBQUFBLElBQUFLLEVBQUE7QUFBQUMsWUFBQSxDQUFBRCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}