var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Outlet;
var _react = require("react");
var _shell = require("../lib/shell");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // `<Outlet/>` — the injection point inside a layout (`_layout.mdx`). It renders
// whatever the engine placed one level inward: the next nested layout, or — at
// the bottom of the chain — the page itself. Import-free in MDX (registered in
// GROVE_MDX), so a layout author just writes `<Outlet/>` where the page goes.
// The React Router analogue, adapted to Grove's content-is-chrome model.
function Outlet() {
  _s();
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_jsxRuntime.Fragment, {
    children: (0, _react.useContext)(_shell.OutletContext)
  });
}
_s(Outlet, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");
_c = Outlet;
var _c;
$RefreshReg$(_c, "Outlet");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NoZWxsIiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsIk91dGxldCIsImpzeCIsIkZyYWdtZW50IiwiY2hpbGRyZW4iLCJ1c2VDb250ZXh0IiwiT3V0bGV0Q29udGV4dCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiT3V0bGV0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VDb250ZXh0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgT3V0bGV0Q29udGV4dCB9IGZyb20gJy4uL2xpYi9zaGVsbCc7XG5cbi8vIGA8T3V0bGV0Lz5gIOKAlCB0aGUgaW5qZWN0aW9uIHBvaW50IGluc2lkZSBhIGxheW91dCAoYF9sYXlvdXQubWR4YCkuIEl0IHJlbmRlcnNcbi8vIHdoYXRldmVyIHRoZSBlbmdpbmUgcGxhY2VkIG9uZSBsZXZlbCBpbndhcmQ6IHRoZSBuZXh0IG5lc3RlZCBsYXlvdXQsIG9yIOKAlCBhdFxuLy8gdGhlIGJvdHRvbSBvZiB0aGUgY2hhaW4g4oCUIHRoZSBwYWdlIGl0c2VsZi4gSW1wb3J0LWZyZWUgaW4gTURYIChyZWdpc3RlcmVkIGluXG4vLyBHUk9WRV9NRFgpLCBzbyBhIGxheW91dCBhdXRob3IganVzdCB3cml0ZXMgYDxPdXRsZXQvPmAgd2hlcmUgdGhlIHBhZ2UgZ29lcy5cbi8vIFRoZSBSZWFjdCBSb3V0ZXIgYW5hbG9ndWUsIGFkYXB0ZWQgdG8gR3JvdmUncyBjb250ZW50LWlzLWNocm9tZSBtb2RlbC5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE91dGxldCgpIHtcbiAgcmV0dXJuIDw+e3VzZUNvbnRleHQoT3V0bGV0Q29udGV4dCl9PC8+O1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFBQSxJQUFBQSxNQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxNQUFBLEdBQUFELE9BQUE7QUFBNkMsSUFBQUUsV0FBQSxHQUFBRixPQUFBO0FBQUEsSUFBQUcsRUFBQSxHQUFBQyxZQUFBLElBRTdDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDZSxTQUFTQyxNQUFNQSxDQUFBLEVBQUc7RUFBQUYsRUFBQTtFQUMvQixvQkFBTyxJQUFBRCxXQUFBLENBQUFJLEdBQUEsRUFBQUosV0FBQSxDQUFBSyxRQUFBO0lBQUFDLFFBQUEsRUFBRyxJQUFBQyxpQkFBVSxFQUFDQyxvQkFBYTtFQUFDLENBQUcsQ0FBQztBQUN6QztBQUFDUCxFQUFBLENBRnVCRSxNQUFNO0FBQUFNLEVBQUEsR0FBTk4sTUFBTTtBQUFBLElBQUFNLEVBQUE7QUFBQUMsWUFBQSxDQUFBRCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}