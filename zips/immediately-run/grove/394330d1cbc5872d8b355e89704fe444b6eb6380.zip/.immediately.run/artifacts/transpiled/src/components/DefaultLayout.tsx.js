var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = DefaultLayout;
var _shell = require("../lib/shell");
var _GroveNav = _interopRequireDefault(require("./GroveNav"));
var _Sidebar = _interopRequireDefault(require("./Sidebar"));
var _GroveFooter = _interopRequireDefault(require("./GroveFooter"));
var _Outlet = _interopRequireDefault(require("./Outlet"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The built-in root layout: the standard Grove shell, used when a repo ships no
// `content/_layout.mdx` of its own — so even a bare folder of `.mdx` files gets
// full chrome (product value 3, "a bare folder is a usable site"). A repo makes
// the shell its own by dropping in `content/_layout.mdx`, which overrides this.
//
// This is intentionally the SAME arrangement a content `_layout.mdx` would write
// by hand (`<GroveNav/> <GroveSidebar/> <main><Outlet/></main> <GroveFooter/>`),
// so the default and a custom shell are structurally identical.
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function DefaultLayout() {
  _s();
  const {
    navMode
  } = (0, _shell.useShell)();
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_GroveNav.default, {}), navMode === 'side' ? /*#__PURE__*/(0, _jsxRuntime.jsx)(_Sidebar.default, {}) : null, /*#__PURE__*/(0, _jsxRuntime.jsx)("main", {
      className: "grove-content",
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Outlet.default, {})
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_GroveFooter.default, {})]
  });
}
_s(DefaultLayout, "tsajcUg6tCBY6iAU0w8P0erScNY=", false, function () {
  return [_shell.useShell];
});
_c = DefaultLayout;
var _c;
$RefreshReg$(_c, "DefaultLayout");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfc2hlbGwiLCJyZXF1aXJlIiwiX0dyb3ZlTmF2IiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsIl9TaWRlYmFyIiwiX0dyb3ZlRm9vdGVyIiwiX091dGxldCIsIl9qc3hSdW50aW1lIiwiX3MiLCIkUmVmcmVzaFNpZyQiLCJlIiwiX19lc01vZHVsZSIsImRlZmF1bHQiLCJEZWZhdWx0TGF5b3V0IiwibmF2TW9kZSIsInVzZVNoZWxsIiwianN4cyIsIkZyYWdtZW50IiwiY2hpbGRyZW4iLCJqc3giLCJjbGFzc05hbWUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkRlZmF1bHRMYXlvdXQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVNoZWxsIH0gZnJvbSAnLi4vbGliL3NoZWxsJztcbmltcG9ydCBHcm92ZU5hdiBmcm9tICcuL0dyb3ZlTmF2JztcbmltcG9ydCBTaWRlYmFyIGZyb20gJy4vU2lkZWJhcic7XG5pbXBvcnQgR3JvdmVGb290ZXIgZnJvbSAnLi9Hcm92ZUZvb3Rlcic7XG5pbXBvcnQgT3V0bGV0IGZyb20gJy4vT3V0bGV0JztcblxuLy8gVGhlIGJ1aWx0LWluIHJvb3QgbGF5b3V0OiB0aGUgc3RhbmRhcmQgR3JvdmUgc2hlbGwsIHVzZWQgd2hlbiBhIHJlcG8gc2hpcHMgbm9cbi8vIGBjb250ZW50L19sYXlvdXQubWR4YCBvZiBpdHMgb3duIOKAlCBzbyBldmVuIGEgYmFyZSBmb2xkZXIgb2YgYC5tZHhgIGZpbGVzIGdldHNcbi8vIGZ1bGwgY2hyb21lIChwcm9kdWN0IHZhbHVlIDMsIFwiYSBiYXJlIGZvbGRlciBpcyBhIHVzYWJsZSBzaXRlXCIpLiBBIHJlcG8gbWFrZXNcbi8vIHRoZSBzaGVsbCBpdHMgb3duIGJ5IGRyb3BwaW5nIGluIGBjb250ZW50L19sYXlvdXQubWR4YCwgd2hpY2ggb3ZlcnJpZGVzIHRoaXMuXG4vL1xuLy8gVGhpcyBpcyBpbnRlbnRpb25hbGx5IHRoZSBTQU1FIGFycmFuZ2VtZW50IGEgY29udGVudCBgX2xheW91dC5tZHhgIHdvdWxkIHdyaXRlXG4vLyBieSBoYW5kIChgPEdyb3ZlTmF2Lz4gPEdyb3ZlU2lkZWJhci8+IDxtYWluPjxPdXRsZXQvPjwvbWFpbj4gPEdyb3ZlRm9vdGVyLz5gKSxcbi8vIHNvIHRoZSBkZWZhdWx0IGFuZCBhIGN1c3RvbSBzaGVsbCBhcmUgc3RydWN0dXJhbGx5IGlkZW50aWNhbC5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIERlZmF1bHRMYXlvdXQoKSB7XG4gIGNvbnN0IHsgbmF2TW9kZSB9ID0gdXNlU2hlbGwoKTtcbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPEdyb3ZlTmF2IC8+XG4gICAgICB7bmF2TW9kZSA9PT0gJ3NpZGUnID8gPFNpZGViYXIgLz4gOiBudWxsfVxuICAgICAgPG1haW4gY2xhc3NOYW1lPVwiZ3JvdmUtY29udGVudFwiPlxuICAgICAgICA8T3V0bGV0IC8+XG4gICAgICA8L21haW4+XG4gICAgICA8R3JvdmVGb290ZXIgLz5cbiAgICA8Lz5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQUEsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsU0FBQSxHQUFBQyxzQkFBQSxDQUFBRixPQUFBO0FBQ0EsSUFBQUcsUUFBQSxHQUFBRCxzQkFBQSxDQUFBRixPQUFBO0FBQ0EsSUFBQUksWUFBQSxHQUFBRixzQkFBQSxDQUFBRixPQUFBO0FBQ0EsSUFBQUssT0FBQSxHQUFBSCxzQkFBQSxDQUFBRixPQUFBO0FBQThCLElBQUFNLFdBQUEsR0FBQU4sT0FBQTtBQUFBLElBQUFPLEVBQUEsR0FBQUMsWUFBQSxJQUU5QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQUEsU0FBQU4sdUJBQUFPLENBQUEsV0FBQUEsQ0FBQSxJQUFBQSxDQUFBLENBQUFDLFVBQUEsR0FBQUQsQ0FBQSxLQUFBRSxPQUFBLEVBQUFGLENBQUE7QUFDZSxTQUFTRyxhQUFhQSxDQUFBLEVBQUc7RUFBQUwsRUFBQTtFQUN0QyxNQUFNO0lBQUVNO0VBQVEsQ0FBQyxHQUFHLElBQUFDLGVBQVEsRUFBQyxDQUFDO0VBQzlCLG9CQUNFLElBQUFSLFdBQUEsQ0FBQVMsSUFBQSxFQUFBVCxXQUFBLENBQUFVLFFBQUE7SUFBQUMsUUFBQSxnQkFDRSxJQUFBWCxXQUFBLENBQUFZLEdBQUEsRUFBQ2pCLFNBQUEsQ0FBQVUsT0FBUSxJQUFFLENBQUMsRUFDWEUsT0FBTyxLQUFLLE1BQU0sZ0JBQUcsSUFBQVAsV0FBQSxDQUFBWSxHQUFBLEVBQUNmLFFBQUEsQ0FBQVEsT0FBTyxJQUFFLENBQUMsR0FBRyxJQUFJLGVBQ3hDLElBQUFMLFdBQUEsQ0FBQVksR0FBQTtNQUFNQyxTQUFTLEVBQUMsZUFBZTtNQUFBRixRQUFBLGVBQzdCLElBQUFYLFdBQUEsQ0FBQVksR0FBQSxFQUFDYixPQUFBLENBQUFNLE9BQU0sSUFBRTtJQUFDLENBQ04sQ0FBQyxlQUNQLElBQUFMLFdBQUEsQ0FBQVksR0FBQSxFQUFDZCxZQUFBLENBQUFPLE9BQVcsSUFBRSxDQUFDO0VBQUEsQ0FDZixDQUFDO0FBRVA7QUFBQ0osRUFBQSxDQVp1QkssYUFBYTtFQUFBLFFBQ2ZFLGVBQVE7QUFBQTtBQUFBTSxFQUFBLEdBRE5SLGFBQWE7QUFBQSxJQUFBUSxFQUFBO0FBQUFDLFlBQUEsQ0FBQUQsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}