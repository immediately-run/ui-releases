var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = WikiLink;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.find.js");
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
var _TinkerableContext = require("@immediately-run/sdk/TinkerableContext");
var _content = require("../lib/content");
var _directory = require("../lib/directory");
var _wiki = require("../lib/wiki");
var _Icon = _interopRequireDefault(require("./Icon"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$();
/* eslint-disable @typescript-eslint/no-explicit-any */
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// The MDX `a` override. A link into the content space renders as a wiki-link with one of
// three states (brief 00) — resolved / broken / self; an external scheme or a bare
// `#anchor` renders as an ordinary markdown link, so the two are distinguishable at a
// glance. Those are the ONLY two shapes: an in-app href that resolves to nothing renders
// broken, never as a bare `<a>` (see `linkKind` — R3-252).
function WikiLink({
  href = '',
  children,
  ...rest
}) {
  _s();
  const ctx = (0, _react.useContext)(_TinkerableContext.TinkerableContext);
  const currentKey = (0, _content.sandboxPathToKey)(ctx?.navigationState?.sandboxPath || '/');

  // Resolve existence against the whole in-memory index (so a missing target is
  // *definitively* broken, not a load-time flash).
  const allKeysQuery = (0, _react.useCallback)(fm => Object.keys(fm).filter(_content.isContentEntry), []);
  const q = (0, _sdk.useMetadataQuery)(allKeysQuery);
  const keys = (0, _wiki.queryPaths)(q);
  const loaded = keys.length > 0;

  // Normalize an in-app content href to its canonical metadata key; null for
  // external/anchor links. Handles the ABSOLUTE forms (`/content/x.mdx`,
  // `/files/content/x.mdx`) and the RELATIVE form an author actually writes
  // (`roadmap/index.mdx`, `../specs/FOO.mdx`), which is resolved against the current
  // entry the same way `check-docs-wiki` resolves `[[…]]` links. A relative href used
  // to land here as `null` and render as a bare `<a>`, so clicking it made the sandbox
  // perform a real navigation instead of routing — the "Failed to construct 'URL'"
  // crash. Candidates are tried in order so a pre-cutover `foo.md` still finds `foo.mdx`
  // even though the corpus itself no longer carries those names.
  const candidates = (0, _content.hrefKeyCandidates)(href, currentKey);
  const targetKey = candidates.find(k => keys.includes(k)) ?? candidates[0] ?? null;
  // Route on the RESOLVED key, not the author's text: handing `<Link>` a relative href
  // would make it resolve against the outer page URL rather than the content tree.
  const [, fragment] = (0, _content.splitFragment)(href);
  const resolvedHref = targetKey ? (0, _content.keyToHref)(targetKey) + fragment : href;

  // Only an href that MEANS to leave the document becomes a real `<a>` — see `linkKind`.
  // An unresolvable in-app href renders broken rather than falling through to an anchor
  // that would navigate the sandboxed frame away and kill the app (R3-252).
  if (!targetKey) {
    const kind = (0, _content.linkKind)(href);
    // A FOLDER is a destination too, since directory listings landed: `[the
    // handbook](handbook)` names something real, and the extension test that decides
    // what an *entry* is would otherwise call it broken. Judged from the index (no fs
    // call per link) — see `isFolderKey` for what that trades away.
    const dirKey = kind === 'content' ? (0, _content.hrefTargetKey)(href, currentKey) : null;
    if (dirKey && loaded && (0, _directory.isFolderKey)(dirKey, keys)) {
      return /*#__PURE__*/(0, _jsxRuntime.jsx)(_sdk.Link, {
        href: (0, _content.keyToHref)(dirKey) + fragment,
        className: "grove-wikilink",
        "data-state": "ok",
        ...rest,
        children: children
      });
    }
    if (kind !== 'content') {
      const web = /^https?:/i.test(href);
      return /*#__PURE__*/(0, _jsxRuntime.jsx)("a", {
        className: "mdlink",
        href: href,
        ...(web ? {
          target: '_blank',
          rel: 'noreferrer'
        } : {}),
        ...rest,
        children: children
      });
    }
    return /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
      className: "grove-wikilink",
      "data-state": "broken",
      title: `No entry at ${href}`,
      "aria-label": `No entry at ${href}`,
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
        name: "unlink"
      }), children]
    });
  }
  if (targetKey === currentKey) {
    return /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
      className: "grove-wikilink",
      "data-state": "self",
      children: children
    });
  }
  const exists = !loaded || keys.includes(targetKey); // optimistic until loaded
  if (!exists) {
    return /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
      className: "grove-wikilink",
      "data-state": "broken",
      title: `No entry at ${href}`,
      "aria-label": `No entry at ${href}`,
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
        name: "unlink"
      }), children]
    });
  }
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_sdk.Link, {
    href: resolvedHref,
    className: "grove-wikilink",
    "data-state": "ok",
    ...rest,
    children: children
  });
}
_s(WikiLink, "9bkoheOkmDqqnXC+6uE2Db2HyU8=", false, function () {
  return [_sdk.useMetadataQuery];
});
_c = WikiLink;
var _c;
$RefreshReg$(_c, "WikiLink");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NkayIsIl9UaW5rZXJhYmxlQ29udGV4dCIsIl9jb250ZW50IiwiX2RpcmVjdG9yeSIsIl93aWtpIiwiX0ljb24iLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsIldpa2lMaW5rIiwiaHJlZiIsImNoaWxkcmVuIiwicmVzdCIsImN0eCIsInVzZUNvbnRleHQiLCJUaW5rZXJhYmxlQ29udGV4dCIsImN1cnJlbnRLZXkiLCJzYW5kYm94UGF0aFRvS2V5IiwibmF2aWdhdGlvblN0YXRlIiwic2FuZGJveFBhdGgiLCJhbGxLZXlzUXVlcnkiLCJ1c2VDYWxsYmFjayIsImZtIiwiT2JqZWN0Iiwia2V5cyIsImZpbHRlciIsImlzQ29udGVudEVudHJ5IiwicSIsInVzZU1ldGFkYXRhUXVlcnkiLCJxdWVyeVBhdGhzIiwibG9hZGVkIiwibGVuZ3RoIiwiY2FuZGlkYXRlcyIsImhyZWZLZXlDYW5kaWRhdGVzIiwidGFyZ2V0S2V5IiwiZmluZCIsImsiLCJpbmNsdWRlcyIsImZyYWdtZW50Iiwic3BsaXRGcmFnbWVudCIsInJlc29sdmVkSHJlZiIsImtleVRvSHJlZiIsImtpbmQiLCJsaW5rS2luZCIsImRpcktleSIsImhyZWZUYXJnZXRLZXkiLCJpc0ZvbGRlcktleSIsImpzeCIsIkxpbmsiLCJjbGFzc05hbWUiLCJ3ZWIiLCJ0ZXN0IiwidGFyZ2V0IiwicmVsIiwianN4cyIsInRpdGxlIiwibmFtZSIsImV4aXN0cyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiV2lraUxpbmsudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHBsaWNpdC1hbnkgKi9cbmltcG9ydCB7IHVzZUNhbGxiYWNrLCB1c2VDb250ZXh0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgTGluaywgdXNlTWV0YWRhdGFRdWVyeSB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrJztcbmltcG9ydCB7IFRpbmtlcmFibGVDb250ZXh0IH0gZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9zZGsvVGlua2VyYWJsZUNvbnRleHQnO1xuaW1wb3J0IHsgaHJlZktleUNhbmRpZGF0ZXMsIGhyZWZUYXJnZXRLZXksIGlzQ29udGVudEVudHJ5LCBrZXlUb0hyZWYsIGxpbmtLaW5kLCBzYW5kYm94UGF0aFRvS2V5LCBzcGxpdEZyYWdtZW50IH0gZnJvbSAnLi4vbGliL2NvbnRlbnQnO1xuaW1wb3J0IHsgaXNGb2xkZXJLZXkgfSBmcm9tICcuLi9saWIvZGlyZWN0b3J5JztcbmltcG9ydCB7IHF1ZXJ5UGF0aHMgfSBmcm9tICcuLi9saWIvd2lraSc7XG5pbXBvcnQgSWNvbiBmcm9tICcuL0ljb24nO1xuXG5pbnRlcmZhY2UgUHJvcHMge1xuICBocmVmPzogc3RyaW5nO1xuICBjaGlsZHJlbj86IFJlYWN0LlJlYWN0Tm9kZTtcbiAgY2xhc3NOYW1lPzogc3RyaW5nO1xufVxuXG4vLyBUaGUgTURYIGBhYCBvdmVycmlkZS4gQSBsaW5rIGludG8gdGhlIGNvbnRlbnQgc3BhY2UgcmVuZGVycyBhcyBhIHdpa2ktbGluayB3aXRoIG9uZSBvZlxuLy8gdGhyZWUgc3RhdGVzIChicmllZiAwMCkg4oCUIHJlc29sdmVkIC8gYnJva2VuIC8gc2VsZjsgYW4gZXh0ZXJuYWwgc2NoZW1lIG9yIGEgYmFyZVxuLy8gYCNhbmNob3JgIHJlbmRlcnMgYXMgYW4gb3JkaW5hcnkgbWFya2Rvd24gbGluaywgc28gdGhlIHR3byBhcmUgZGlzdGluZ3Vpc2hhYmxlIGF0IGFcbi8vIGdsYW5jZS4gVGhvc2UgYXJlIHRoZSBPTkxZIHR3byBzaGFwZXM6IGFuIGluLWFwcCBocmVmIHRoYXQgcmVzb2x2ZXMgdG8gbm90aGluZyByZW5kZXJzXG4vLyBicm9rZW4sIG5ldmVyIGFzIGEgYmFyZSBgPGE+YCAoc2VlIGBsaW5rS2luZGAg4oCUIFIzLTI1MikuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBXaWtpTGluayh7IGhyZWYgPSAnJywgY2hpbGRyZW4sIC4uLnJlc3QgfTogUHJvcHMpIHtcbiAgY29uc3QgY3R4ID0gdXNlQ29udGV4dChUaW5rZXJhYmxlQ29udGV4dCkgYXMgYW55O1xuICBjb25zdCBjdXJyZW50S2V5ID0gc2FuZGJveFBhdGhUb0tleShjdHg/Lm5hdmlnYXRpb25TdGF0ZT8uc2FuZGJveFBhdGggfHwgJy8nKTtcblxuICAvLyBSZXNvbHZlIGV4aXN0ZW5jZSBhZ2FpbnN0IHRoZSB3aG9sZSBpbi1tZW1vcnkgaW5kZXggKHNvIGEgbWlzc2luZyB0YXJnZXQgaXNcbiAgLy8gKmRlZmluaXRpdmVseSogYnJva2VuLCBub3QgYSBsb2FkLXRpbWUgZmxhc2gpLlxuICBjb25zdCBhbGxLZXlzUXVlcnkgPSB1c2VDYWxsYmFjayhcbiAgICAoZm06IFJlY29yZDxzdHJpbmcsIGFueT4pID0+IE9iamVjdC5rZXlzKGZtKS5maWx0ZXIoaXNDb250ZW50RW50cnkpLFxuICAgIFtdXG4gICk7XG4gIGNvbnN0IHEgPSB1c2VNZXRhZGF0YVF1ZXJ5KGFsbEtleXNRdWVyeSk7XG4gIGNvbnN0IGtleXM6IHN0cmluZ1tdID0gcXVlcnlQYXRocyhxKTtcbiAgY29uc3QgbG9hZGVkID0ga2V5cy5sZW5ndGggPiAwO1xuXG4gIC8vIE5vcm1hbGl6ZSBhbiBpbi1hcHAgY29udGVudCBocmVmIHRvIGl0cyBjYW5vbmljYWwgbWV0YWRhdGEga2V5OyBudWxsIGZvclxuICAvLyBleHRlcm5hbC9hbmNob3IgbGlua3MuIEhhbmRsZXMgdGhlIEFCU09MVVRFIGZvcm1zIChgL2NvbnRlbnQveC5tZHhgLFxuICAvLyBgL2ZpbGVzL2NvbnRlbnQveC5tZHhgKSBhbmQgdGhlIFJFTEFUSVZFIGZvcm0gYW4gYXV0aG9yIGFjdHVhbGx5IHdyaXRlc1xuICAvLyAoYHJvYWRtYXAvaW5kZXgubWR4YCwgYC4uL3NwZWNzL0ZPTy5tZHhgKSwgd2hpY2ggaXMgcmVzb2x2ZWQgYWdhaW5zdCB0aGUgY3VycmVudFxuICAvLyBlbnRyeSB0aGUgc2FtZSB3YXkgYGNoZWNrLWRvY3Mtd2lraWAgcmVzb2x2ZXMgYFtb4oCmXV1gIGxpbmtzLiBBIHJlbGF0aXZlIGhyZWYgdXNlZFxuICAvLyB0byBsYW5kIGhlcmUgYXMgYG51bGxgIGFuZCByZW5kZXIgYXMgYSBiYXJlIGA8YT5gLCBzbyBjbGlja2luZyBpdCBtYWRlIHRoZSBzYW5kYm94XG4gIC8vIHBlcmZvcm0gYSByZWFsIG5hdmlnYXRpb24gaW5zdGVhZCBvZiByb3V0aW5nIOKAlCB0aGUgXCJGYWlsZWQgdG8gY29uc3RydWN0ICdVUkwnXCJcbiAgLy8gY3Jhc2guIENhbmRpZGF0ZXMgYXJlIHRyaWVkIGluIG9yZGVyIHNvIGEgcHJlLWN1dG92ZXIgYGZvby5tZGAgc3RpbGwgZmluZHMgYGZvby5tZHhgXG4gIC8vIGV2ZW4gdGhvdWdoIHRoZSBjb3JwdXMgaXRzZWxmIG5vIGxvbmdlciBjYXJyaWVzIHRob3NlIG5hbWVzLlxuICBjb25zdCBjYW5kaWRhdGVzID0gaHJlZktleUNhbmRpZGF0ZXMoaHJlZiwgY3VycmVudEtleSk7XG4gIGNvbnN0IHRhcmdldEtleSA9IGNhbmRpZGF0ZXMuZmluZCgoaykgPT4ga2V5cy5pbmNsdWRlcyhrKSkgPz8gY2FuZGlkYXRlc1swXSA/PyBudWxsO1xuICAvLyBSb3V0ZSBvbiB0aGUgUkVTT0xWRUQga2V5LCBub3QgdGhlIGF1dGhvcidzIHRleHQ6IGhhbmRpbmcgYDxMaW5rPmAgYSByZWxhdGl2ZSBocmVmXG4gIC8vIHdvdWxkIG1ha2UgaXQgcmVzb2x2ZSBhZ2FpbnN0IHRoZSBvdXRlciBwYWdlIFVSTCByYXRoZXIgdGhhbiB0aGUgY29udGVudCB0cmVlLlxuICBjb25zdCBbLCBmcmFnbWVudF0gPSBzcGxpdEZyYWdtZW50KGhyZWYpO1xuICBjb25zdCByZXNvbHZlZEhyZWYgPSB0YXJnZXRLZXkgPyBrZXlUb0hyZWYodGFyZ2V0S2V5KSArIGZyYWdtZW50IDogaHJlZjtcblxuICAvLyBPbmx5IGFuIGhyZWYgdGhhdCBNRUFOUyB0byBsZWF2ZSB0aGUgZG9jdW1lbnQgYmVjb21lcyBhIHJlYWwgYDxhPmAg4oCUIHNlZSBgbGlua0tpbmRgLlxuICAvLyBBbiB1bnJlc29sdmFibGUgaW4tYXBwIGhyZWYgcmVuZGVycyBicm9rZW4gcmF0aGVyIHRoYW4gZmFsbGluZyB0aHJvdWdoIHRvIGFuIGFuY2hvclxuICAvLyB0aGF0IHdvdWxkIG5hdmlnYXRlIHRoZSBzYW5kYm94ZWQgZnJhbWUgYXdheSBhbmQga2lsbCB0aGUgYXBwIChSMy0yNTIpLlxuICBpZiAoIXRhcmdldEtleSkge1xuICAgIGNvbnN0IGtpbmQgPSBsaW5rS2luZChocmVmKTtcbiAgICAvLyBBIEZPTERFUiBpcyBhIGRlc3RpbmF0aW9uIHRvbywgc2luY2UgZGlyZWN0b3J5IGxpc3RpbmdzIGxhbmRlZDogYFt0aGVcbiAgICAvLyBoYW5kYm9va10oaGFuZGJvb2spYCBuYW1lcyBzb21ldGhpbmcgcmVhbCwgYW5kIHRoZSBleHRlbnNpb24gdGVzdCB0aGF0IGRlY2lkZXNcbiAgICAvLyB3aGF0IGFuICplbnRyeSogaXMgd291bGQgb3RoZXJ3aXNlIGNhbGwgaXQgYnJva2VuLiBKdWRnZWQgZnJvbSB0aGUgaW5kZXggKG5vIGZzXG4gICAgLy8gY2FsbCBwZXIgbGluaykg4oCUIHNlZSBgaXNGb2xkZXJLZXlgIGZvciB3aGF0IHRoYXQgdHJhZGVzIGF3YXkuXG4gICAgY29uc3QgZGlyS2V5ID0ga2luZCA9PT0gJ2NvbnRlbnQnID8gaHJlZlRhcmdldEtleShocmVmLCBjdXJyZW50S2V5KSA6IG51bGw7XG4gICAgaWYgKGRpcktleSAmJiBsb2FkZWQgJiYgaXNGb2xkZXJLZXkoZGlyS2V5LCBrZXlzKSkge1xuICAgICAgcmV0dXJuIChcbiAgICAgICAgPExpbmsgaHJlZj17a2V5VG9IcmVmKGRpcktleSkgKyBmcmFnbWVudH0gY2xhc3NOYW1lPVwiZ3JvdmUtd2lraWxpbmtcIiBkYXRhLXN0YXRlPVwib2tcIiB7Li4ucmVzdH0+XG4gICAgICAgICAge2NoaWxkcmVufVxuICAgICAgICA8L0xpbms+XG4gICAgICApO1xuICAgIH1cbiAgICBpZiAoa2luZCAhPT0gJ2NvbnRlbnQnKSB7XG4gICAgICBjb25zdCB3ZWIgPSAvXmh0dHBzPzovaS50ZXN0KGhyZWYpO1xuICAgICAgcmV0dXJuIChcbiAgICAgICAgPGFcbiAgICAgICAgICBjbGFzc05hbWU9XCJtZGxpbmtcIlxuICAgICAgICAgIGhyZWY9e2hyZWZ9XG4gICAgICAgICAgey4uLih3ZWIgPyB7IHRhcmdldDogJ19ibGFuaycsIHJlbDogJ25vcmVmZXJyZXInIH0gOiB7fSl9XG4gICAgICAgICAgey4uLnJlc3R9XG4gICAgICAgID5cbiAgICAgICAgICB7Y2hpbGRyZW59XG4gICAgICAgIDwvYT5cbiAgICAgICk7XG4gICAgfVxuICAgIHJldHVybiAoXG4gICAgICA8c3BhbiBjbGFzc05hbWU9XCJncm92ZS13aWtpbGlua1wiIGRhdGEtc3RhdGU9XCJicm9rZW5cIiB0aXRsZT17YE5vIGVudHJ5IGF0ICR7aHJlZn1gfSBhcmlhLWxhYmVsPXtgTm8gZW50cnkgYXQgJHtocmVmfWB9PlxuICAgICAgICA8SWNvbiBuYW1lPVwidW5saW5rXCIgLz5cbiAgICAgICAge2NoaWxkcmVufVxuICAgICAgPC9zcGFuPlxuICAgICk7XG4gIH1cblxuICBpZiAodGFyZ2V0S2V5ID09PSBjdXJyZW50S2V5KSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImdyb3ZlLXdpa2lsaW5rXCIgZGF0YS1zdGF0ZT1cInNlbGZcIj5cbiAgICAgICAge2NoaWxkcmVufVxuICAgICAgPC9zcGFuPlxuICAgICk7XG4gIH1cblxuICBjb25zdCBleGlzdHMgPSAhbG9hZGVkIHx8IGtleXMuaW5jbHVkZXModGFyZ2V0S2V5KTsgLy8gb3B0aW1pc3RpYyB1bnRpbCBsb2FkZWRcbiAgaWYgKCFleGlzdHMpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZ3JvdmUtd2lraWxpbmtcIiBkYXRhLXN0YXRlPVwiYnJva2VuXCIgdGl0bGU9e2BObyBlbnRyeSBhdCAke2hyZWZ9YH0gYXJpYS1sYWJlbD17YE5vIGVudHJ5IGF0ICR7aHJlZn1gfT5cbiAgICAgICAgPEljb24gbmFtZT1cInVubGlua1wiIC8+XG4gICAgICAgIHtjaGlsZHJlbn1cbiAgICAgIDwvc3Bhbj5cbiAgICApO1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8TGluayBocmVmPXtyZXNvbHZlZEhyZWZ9IGNsYXNzTmFtZT1cImdyb3ZlLXdpa2lsaW5rXCIgZGF0YS1zdGF0ZT1cIm9rXCIgey4uLnJlc3R9PlxuICAgICAge2NoaWxkcmVufVxuICAgIDwvTGluaz5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQ0EsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsSUFBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsa0JBQUEsR0FBQUYsT0FBQTtBQUNBLElBQUFHLFFBQUEsR0FBQUgsT0FBQTtBQUNBLElBQUFJLFVBQUEsR0FBQUosT0FBQTtBQUNBLElBQUFLLEtBQUEsR0FBQUwsT0FBQTtBQUNBLElBQUFNLEtBQUEsR0FBQUMsc0JBQUEsQ0FBQVAsT0FBQTtBQUEwQixJQUFBUSxXQUFBLEdBQUFSLE9BQUE7QUFBQSxJQUFBUyxFQUFBLEdBQUFDLFlBQUE7QUFQMUI7QUFBQSxTQUFBSCx1QkFBQUksQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQWVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDZSxTQUFTRyxRQUFRQSxDQUFDO0VBQUVDLElBQUksR0FBRyxFQUFFO0VBQUVDLFFBQVE7RUFBRSxHQUFHQztBQUFZLENBQUMsRUFBRTtFQUFBUixFQUFBO0VBQ3hFLE1BQU1TLEdBQUcsR0FBRyxJQUFBQyxpQkFBVSxFQUFDQyxvQ0FBaUIsQ0FBUTtFQUNoRCxNQUFNQyxVQUFVLEdBQUcsSUFBQUMseUJBQWdCLEVBQUNKLEdBQUcsRUFBRUssZUFBZSxFQUFFQyxXQUFXLElBQUksR0FBRyxDQUFDOztFQUU3RTtFQUNBO0VBQ0EsTUFBTUMsWUFBWSxHQUFHLElBQUFDLGtCQUFXLEVBQzdCQyxFQUF1QixJQUFLQyxNQUFNLENBQUNDLElBQUksQ0FBQ0YsRUFBRSxDQUFDLENBQUNHLE1BQU0sQ0FBQ0MsdUJBQWMsQ0FBQyxFQUNuRSxFQUNGLENBQUM7RUFDRCxNQUFNQyxDQUFDLEdBQUcsSUFBQUMscUJBQWdCLEVBQUNSLFlBQVksQ0FBQztFQUN4QyxNQUFNSSxJQUFjLEdBQUcsSUFBQUssZ0JBQVUsRUFBQ0YsQ0FBQyxDQUFDO0VBQ3BDLE1BQU1HLE1BQU0sR0FBR04sSUFBSSxDQUFDTyxNQUFNLEdBQUcsQ0FBQzs7RUFFOUI7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsTUFBTUMsVUFBVSxHQUFHLElBQUFDLDBCQUFpQixFQUFDdkIsSUFBSSxFQUFFTSxVQUFVLENBQUM7RUFDdEQsTUFBTWtCLFNBQVMsR0FBR0YsVUFBVSxDQUFDRyxJQUFJLENBQUVDLENBQUMsSUFBS1osSUFBSSxDQUFDYSxRQUFRLENBQUNELENBQUMsQ0FBQyxDQUFDLElBQUlKLFVBQVUsQ0FBQyxDQUFDLENBQUMsSUFBSSxJQUFJO0VBQ25GO0VBQ0E7RUFDQSxNQUFNLEdBQUdNLFFBQVEsQ0FBQyxHQUFHLElBQUFDLHNCQUFhLEVBQUM3QixJQUFJLENBQUM7RUFDeEMsTUFBTThCLFlBQVksR0FBR04sU0FBUyxHQUFHLElBQUFPLGtCQUFTLEVBQUNQLFNBQVMsQ0FBQyxHQUFHSSxRQUFRLEdBQUc1QixJQUFJOztFQUV2RTtFQUNBO0VBQ0E7RUFDQSxJQUFJLENBQUN3QixTQUFTLEVBQUU7SUFDZCxNQUFNUSxJQUFJLEdBQUcsSUFBQUMsaUJBQVEsRUFBQ2pDLElBQUksQ0FBQztJQUMzQjtJQUNBO0lBQ0E7SUFDQTtJQUNBLE1BQU1rQyxNQUFNLEdBQUdGLElBQUksS0FBSyxTQUFTLEdBQUcsSUFBQUcsc0JBQWEsRUFBQ25DLElBQUksRUFBRU0sVUFBVSxDQUFDLEdBQUcsSUFBSTtJQUMxRSxJQUFJNEIsTUFBTSxJQUFJZCxNQUFNLElBQUksSUFBQWdCLHNCQUFXLEVBQUNGLE1BQU0sRUFBRXBCLElBQUksQ0FBQyxFQUFFO01BQ2pELG9CQUNFLElBQUFyQixXQUFBLENBQUE0QyxHQUFBLEVBQUNuRCxJQUFBLENBQUFvRCxJQUFJO1FBQUN0QyxJQUFJLEVBQUUsSUFBQStCLGtCQUFTLEVBQUNHLE1BQU0sQ0FBQyxHQUFHTixRQUFTO1FBQUNXLFNBQVMsRUFBQyxnQkFBZ0I7UUFBQyxjQUFXLElBQUk7UUFBQSxHQUFLckMsSUFBSTtRQUFBRCxRQUFBLEVBQzFGQTtNQUFRLENBQ0wsQ0FBQztJQUVYO0lBQ0EsSUFBSStCLElBQUksS0FBSyxTQUFTLEVBQUU7TUFDdEIsTUFBTVEsR0FBRyxHQUFHLFdBQVcsQ0FBQ0MsSUFBSSxDQUFDekMsSUFBSSxDQUFDO01BQ2xDLG9CQUNFLElBQUFQLFdBQUEsQ0FBQTRDLEdBQUE7UUFDRUUsU0FBUyxFQUFDLFFBQVE7UUFDbEJ2QyxJQUFJLEVBQUVBLElBQUs7UUFBQSxJQUNOd0MsR0FBRyxHQUFHO1VBQUVFLE1BQU0sRUFBRSxRQUFRO1VBQUVDLEdBQUcsRUFBRTtRQUFhLENBQUMsR0FBRyxDQUFDLENBQUM7UUFBQSxHQUNuRHpDLElBQUk7UUFBQUQsUUFBQSxFQUVQQTtNQUFRLENBQ1IsQ0FBQztJQUVSO0lBQ0Esb0JBQ0UsSUFBQVIsV0FBQSxDQUFBbUQsSUFBQTtNQUFNTCxTQUFTLEVBQUMsZ0JBQWdCO01BQUMsY0FBVyxRQUFRO01BQUNNLEtBQUssRUFBRSxlQUFlN0MsSUFBSSxFQUFHO01BQUMsY0FBWSxlQUFlQSxJQUFJLEVBQUc7TUFBQUMsUUFBQSxnQkFDbkgsSUFBQVIsV0FBQSxDQUFBNEMsR0FBQSxFQUFDOUMsS0FBQSxDQUFBTyxPQUFJO1FBQUNnRCxJQUFJLEVBQUM7TUFBUSxDQUFFLENBQUMsRUFDckI3QyxRQUFRO0lBQUEsQ0FDTCxDQUFDO0VBRVg7RUFFQSxJQUFJdUIsU0FBUyxLQUFLbEIsVUFBVSxFQUFFO0lBQzVCLG9CQUNFLElBQUFiLFdBQUEsQ0FBQTRDLEdBQUE7TUFBTUUsU0FBUyxFQUFDLGdCQUFnQjtNQUFDLGNBQVcsTUFBTTtNQUFBdEMsUUFBQSxFQUMvQ0E7SUFBUSxDQUNMLENBQUM7RUFFWDtFQUVBLE1BQU04QyxNQUFNLEdBQUcsQ0FBQzNCLE1BQU0sSUFBSU4sSUFBSSxDQUFDYSxRQUFRLENBQUNILFNBQVMsQ0FBQyxDQUFDLENBQUM7RUFDcEQsSUFBSSxDQUFDdUIsTUFBTSxFQUFFO0lBQ1gsb0JBQ0UsSUFBQXRELFdBQUEsQ0FBQW1ELElBQUE7TUFBTUwsU0FBUyxFQUFDLGdCQUFnQjtNQUFDLGNBQVcsUUFBUTtNQUFDTSxLQUFLLEVBQUUsZUFBZTdDLElBQUksRUFBRztNQUFDLGNBQVksZUFBZUEsSUFBSSxFQUFHO01BQUFDLFFBQUEsZ0JBQ25ILElBQUFSLFdBQUEsQ0FBQTRDLEdBQUEsRUFBQzlDLEtBQUEsQ0FBQU8sT0FBSTtRQUFDZ0QsSUFBSSxFQUFDO01BQVEsQ0FBRSxDQUFDLEVBQ3JCN0MsUUFBUTtJQUFBLENBQ0wsQ0FBQztFQUVYO0VBRUEsb0JBQ0UsSUFBQVIsV0FBQSxDQUFBNEMsR0FBQSxFQUFDbkQsSUFBQSxDQUFBb0QsSUFBSTtJQUFDdEMsSUFBSSxFQUFFOEIsWUFBYTtJQUFDUyxTQUFTLEVBQUMsZ0JBQWdCO0lBQUMsY0FBVyxJQUFJO0lBQUEsR0FBS3JDLElBQUk7SUFBQUQsUUFBQSxFQUMxRUE7RUFBUSxDQUNMLENBQUM7QUFFWDtBQUFDUCxFQUFBLENBM0Z1QkssUUFBUTtFQUFBLFFBVXBCbUIscUJBQWdCO0FBQUE7QUFBQThCLEVBQUEsR0FWSmpELFFBQVE7QUFBQSxJQUFBaUQsRUFBQTtBQUFBQyxZQUFBLENBQUFELEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}