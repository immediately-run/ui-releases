var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Lede;
var _jsxRuntime = require("react/jsx-runtime");
// Import-free engine component: the oversized opening paragraph of an entry.
function Lede({
  children
}) {
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("p", {
    className: "grove-lede",
    children: children
  });
}
_c = Lede;
var _c;
$RefreshReg$(_c, "Lede");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJMZWRlIiwiY2hpbGRyZW4iLCJfanN4UnVudGltZSIsImpzeCIsImNsYXNzTmFtZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiTGVkZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBSZWFjdE5vZGUgfSBmcm9tICdyZWFjdCc7XG5cbi8vIEltcG9ydC1mcmVlIGVuZ2luZSBjb21wb25lbnQ6IHRoZSBvdmVyc2l6ZWQgb3BlbmluZyBwYXJhZ3JhcGggb2YgYW4gZW50cnkuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBMZWRlKHsgY2hpbGRyZW4gfTogeyBjaGlsZHJlbj86IFJlYWN0Tm9kZSB9KSB7XG4gIHJldHVybiA8cCBjbGFzc05hbWU9XCJncm92ZS1sZWRlXCI+e2NoaWxkcmVufTwvcD47XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFFQTtBQUNlLFNBQVNBLElBQUlBLENBQUM7RUFBRUM7QUFBbUMsQ0FBQyxFQUFFO0VBQ25FLG9CQUFPLElBQUFDLFdBQUEsQ0FBQUMsR0FBQTtJQUFHQyxTQUFTLEVBQUMsWUFBWTtJQUFBSCxRQUFBLEVBQUVBO0VBQVEsQ0FBSSxDQUFDO0FBQ2pEO0FBQUNJLEVBQUEsR0FGdUJMLElBQUk7QUFBQSxJQUFBSyxFQUFBO0FBQUFDLFlBQUEsQ0FBQUQsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}