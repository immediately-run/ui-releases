var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

var _vitest = require("vitest");
var _react = require("react");
var _client = require("react-dom/client");
var _jsxRuntime = require("react/jsx-runtime");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; } // @vitest-environment jsdom
// `useCatalogAnswered` — rendered in a real React tree, driven through the SDK's REAL
// catalog push channel against an emitting stub transport. The whole point of the hook is
// a timing property of that channel, so a mock of either would assert nothing.
//
// The property under test: the push channel has no value-equality check, so a host answer
// of `[]` — identical to the initial value — still notifies. That second notification is
// the signal. A test that only pushed a NON-empty catalog would pass against a naive
// `catalog.length > 0` implementation and prove nothing, which is why the empty-answer
// case is the one that carries this file.
const handlers = new Set();
const emit = msg => {
  for (const h of handlers) h(msg);
};

// Installed BEFORE the SDK is imported: the channel resolves its transport lazily, and
// the hook module subscribes at import time.
globalThis.__immediatelyRun__ = {
  transport: {
    sendMessage: _vitest.vi.fn(),
    protocolRequest: _vitest.vi.fn(async () => ({})),
    onMessage: handler => {
      handlers.add(handler);
      return {
        dispose: () => handlers.delete(handler)
      };
    }
  }
};
let useCatalogAnswered;
let getCatalog;
(0, _vitest.beforeAll)(async () => {
  ({
    useCatalogAnswered
  } = await Promise.resolve().then(() => _interopRequireWildcard(require('./useCatalogAnswered'))));
  ({
    getCatalog
  } = await Promise.resolve().then(() => _interopRequireWildcard(require('@immediately-run/sdk'))));
});

/** Render a probe recording the hook's value on every render. */
const renderProbe = async () => {
  var _s = $RefreshSig$();
  const seen = [];
  const Probe = () => {
    _s();
    seen.push(useCatalogAnswered());
    return null;
  };
  _s(Probe, "RwilvecANRMzLklwXLFewrbBy6k=", false, function () {
    return [useCatalogAnswered];
  });
  const root = (0, _client.createRoot)(document.createElement('div'));
  await (0, _react.act)(async () => {
    root.render(/*#__PURE__*/(0, _jsxRuntime.jsx)(Probe, {}));
  });
  return {
    seen,
    unmount: () => (0, _react.act)(async () => root.unmount())
  };
};
(0, _vitest.describe)('useCatalogAnswered', () => {
  (0, _vitest.it)('is false before the host answers — the subscribe-time call is not an answer', async () => {
    // `onCatalogChange` invokes its listener once, SYNCHRONOUSLY, with the current value
    // when you subscribe. If that counted, the flag would be true from module load and
    // the reach card would read an unanswered catalog as "not granted" — the exact defect
    // this hook exists to prevent.
    getCatalog(); // start the channel the way the app does
    const {
      seen,
      unmount
    } = await renderProbe();
    (0, _vitest.expect)(seen[seen.length - 1]).toBe(false);
    await unmount();
  });
  (0, _vitest.it)('an EMPTY catalog answer flips it, and RE-RENDERS — an empty answer is still an answer', async () => {
    const {
      seen,
      unmount
    } = await renderProbe();
    (0, _vitest.expect)(seen[seen.length - 1]).toBe(false);
    const before = seen.length;
    await (0, _react.act)(async () => {
      emit({
        type: 'api-catalog',
        methods: []
      });
    });

    // Both halves matter: a hook that returned the flag without subscribing would show
    // the right value only on the NEXT unrelated render.
    (0, _vitest.expect)(seen.length).toBeGreaterThan(before);
    (0, _vitest.expect)(seen[seen.length - 1]).toBe(true);
    await unmount();
  });
  (0, _vitest.it)('stays true for a probe mounted after the answer', async () => {
    const {
      seen,
      unmount
    } = await renderProbe();
    (0, _vitest.expect)(seen[seen.length - 1]).toBe(true);
    await unmount();
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZXN0IiwicmVxdWlyZSIsIl9yZWFjdCIsIl9jbGllbnQiLCJfanN4UnVudGltZSIsIl9nZXRSZXF1aXJlV2lsZGNhcmRDYWNoZSIsImUiLCJXZWFrTWFwIiwiciIsInQiLCJfaW50ZXJvcFJlcXVpcmVXaWxkY2FyZCIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiaGFzIiwiZ2V0IiwibiIsIl9fcHJvdG9fXyIsImEiLCJPYmplY3QiLCJkZWZpbmVQcm9wZXJ0eSIsImdldE93blByb3BlcnR5RGVzY3JpcHRvciIsInUiLCJoYXNPd25Qcm9wZXJ0eSIsImNhbGwiLCJpIiwic2V0IiwiaGFuZGxlcnMiLCJTZXQiLCJlbWl0IiwibXNnIiwiaCIsImdsb2JhbFRoaXMiLCJfX2ltbWVkaWF0ZWx5UnVuX18iLCJ0cmFuc3BvcnQiLCJzZW5kTWVzc2FnZSIsInZpIiwiZm4iLCJwcm90b2NvbFJlcXVlc3QiLCJvbk1lc3NhZ2UiLCJoYW5kbGVyIiwiYWRkIiwiZGlzcG9zZSIsImRlbGV0ZSIsInVzZUNhdGFsb2dBbnN3ZXJlZCIsImdldENhdGFsb2ciLCJiZWZvcmVBbGwiLCJQcm9taXNlIiwicmVzb2x2ZSIsInRoZW4iLCJyZW5kZXJQcm9iZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwic2VlbiIsIlByb2JlIiwicHVzaCIsInJvb3QiLCJjcmVhdGVSb290IiwiZG9jdW1lbnQiLCJjcmVhdGVFbGVtZW50IiwiYWN0IiwicmVuZGVyIiwianN4IiwidW5tb3VudCIsImRlc2NyaWJlIiwiaXQiLCJleHBlY3QiLCJsZW5ndGgiLCJ0b0JlIiwiYmVmb3JlIiwidHlwZSIsIm1ldGhvZHMiLCJ0b0JlR3JlYXRlclRoYW4iXSwic291cmNlcyI6WyJ1c2VDYXRhbG9nQW5zd2VyZWQudGVzdC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gQHZpdGVzdC1lbnZpcm9ubWVudCBqc2RvbVxuLy8gYHVzZUNhdGFsb2dBbnN3ZXJlZGAg4oCUIHJlbmRlcmVkIGluIGEgcmVhbCBSZWFjdCB0cmVlLCBkcml2ZW4gdGhyb3VnaCB0aGUgU0RLJ3MgUkVBTFxuLy8gY2F0YWxvZyBwdXNoIGNoYW5uZWwgYWdhaW5zdCBhbiBlbWl0dGluZyBzdHViIHRyYW5zcG9ydC4gVGhlIHdob2xlIHBvaW50IG9mIHRoZSBob29rIGlzXG4vLyBhIHRpbWluZyBwcm9wZXJ0eSBvZiB0aGF0IGNoYW5uZWwsIHNvIGEgbW9jayBvZiBlaXRoZXIgd291bGQgYXNzZXJ0IG5vdGhpbmcuXG4vL1xuLy8gVGhlIHByb3BlcnR5IHVuZGVyIHRlc3Q6IHRoZSBwdXNoIGNoYW5uZWwgaGFzIG5vIHZhbHVlLWVxdWFsaXR5IGNoZWNrLCBzbyBhIGhvc3QgYW5zd2VyXG4vLyBvZiBgW11gIOKAlCBpZGVudGljYWwgdG8gdGhlIGluaXRpYWwgdmFsdWUg4oCUIHN0aWxsIG5vdGlmaWVzLiBUaGF0IHNlY29uZCBub3RpZmljYXRpb24gaXNcbi8vIHRoZSBzaWduYWwuIEEgdGVzdCB0aGF0IG9ubHkgcHVzaGVkIGEgTk9OLWVtcHR5IGNhdGFsb2cgd291bGQgcGFzcyBhZ2FpbnN0IGEgbmFpdmVcbi8vIGBjYXRhbG9nLmxlbmd0aCA+IDBgIGltcGxlbWVudGF0aW9uIGFuZCBwcm92ZSBub3RoaW5nLCB3aGljaCBpcyB3aHkgdGhlIGVtcHR5LWFuc3dlclxuLy8gY2FzZSBpcyB0aGUgb25lIHRoYXQgY2FycmllcyB0aGlzIGZpbGUuXG5pbXBvcnQgeyBkZXNjcmliZSwgaXQsIGV4cGVjdCwgdmksIGJlZm9yZUFsbCB9IGZyb20gJ3ZpdGVzdCc7XG5pbXBvcnQgeyBhY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBjcmVhdGVSb290IH0gZnJvbSAncmVhY3QtZG9tL2NsaWVudCc7XG5cbnR5cGUgSGFuZGxlciA9IChtc2c6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KSA9PiB2b2lkO1xuY29uc3QgaGFuZGxlcnMgPSBuZXcgU2V0PEhhbmRsZXI+KCk7XG5jb25zdCBlbWl0ID0gKG1zZzogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiB2b2lkID0+IHtcbiAgZm9yIChjb25zdCBoIG9mIGhhbmRsZXJzKSBoKG1zZyk7XG59O1xuXG4vLyBJbnN0YWxsZWQgQkVGT1JFIHRoZSBTREsgaXMgaW1wb3J0ZWQ6IHRoZSBjaGFubmVsIHJlc29sdmVzIGl0cyB0cmFuc3BvcnQgbGF6aWx5LCBhbmRcbi8vIHRoZSBob29rIG1vZHVsZSBzdWJzY3JpYmVzIGF0IGltcG9ydCB0aW1lLlxuKGdsb2JhbFRoaXMgYXMgeyBfX2ltbWVkaWF0ZWx5UnVuX18/OiB1bmtub3duIH0pLl9faW1tZWRpYXRlbHlSdW5fXyA9IHtcbiAgdHJhbnNwb3J0OiB7XG4gICAgc2VuZE1lc3NhZ2U6IHZpLmZuKCksXG4gICAgcHJvdG9jb2xSZXF1ZXN0OiB2aS5mbihhc3luYyAoKSA9PiAoe30pKSxcbiAgICBvbk1lc3NhZ2U6IChoYW5kbGVyOiBIYW5kbGVyKSA9PiB7XG4gICAgICBoYW5kbGVycy5hZGQoaGFuZGxlcik7XG4gICAgICByZXR1cm4geyBkaXNwb3NlOiAoKSA9PiBoYW5kbGVycy5kZWxldGUoaGFuZGxlcikgfTtcbiAgICB9LFxuICB9LFxufTtcblxubGV0IHVzZUNhdGFsb2dBbnN3ZXJlZDogdHlwZW9mIGltcG9ydCgnLi91c2VDYXRhbG9nQW5zd2VyZWQnKS51c2VDYXRhbG9nQW5zd2VyZWQ7XG5sZXQgZ2V0Q2F0YWxvZzogdHlwZW9mIGltcG9ydCgnQGltbWVkaWF0ZWx5LXJ1bi9zZGsnKS5nZXRDYXRhbG9nO1xuXG5iZWZvcmVBbGwoYXN5bmMgKCkgPT4ge1xuICAoeyB1c2VDYXRhbG9nQW5zd2VyZWQgfSA9IGF3YWl0IGltcG9ydCgnLi91c2VDYXRhbG9nQW5zd2VyZWQnKSk7XG4gICh7IGdldENhdGFsb2cgfSA9IGF3YWl0IGltcG9ydCgnQGltbWVkaWF0ZWx5LXJ1bi9zZGsnKSk7XG59KTtcblxuLyoqIFJlbmRlciBhIHByb2JlIHJlY29yZGluZyB0aGUgaG9vaydzIHZhbHVlIG9uIGV2ZXJ5IHJlbmRlci4gKi9cbmNvbnN0IHJlbmRlclByb2JlID0gYXN5bmMgKCkgPT4ge1xuICBjb25zdCBzZWVuOiBib29sZWFuW10gPSBbXTtcbiAgY29uc3QgUHJvYmUgPSAoKSA9PiB7XG4gICAgc2Vlbi5wdXNoKHVzZUNhdGFsb2dBbnN3ZXJlZCgpKTtcbiAgICByZXR1cm4gbnVsbDtcbiAgfTtcbiAgY29uc3Qgcm9vdCA9IGNyZWF0ZVJvb3QoZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2JykpO1xuICBhd2FpdCBhY3QoYXN5bmMgKCkgPT4ge1xuICAgIHJvb3QucmVuZGVyKDxQcm9iZSAvPik7XG4gIH0pO1xuICByZXR1cm4geyBzZWVuLCB1bm1vdW50OiAoKSA9PiBhY3QoYXN5bmMgKCkgPT4gcm9vdC51bm1vdW50KCkpIH07XG59O1xuXG5kZXNjcmliZSgndXNlQ2F0YWxvZ0Fuc3dlcmVkJywgKCkgPT4ge1xuICBpdCgnaXMgZmFsc2UgYmVmb3JlIHRoZSBob3N0IGFuc3dlcnMg4oCUIHRoZSBzdWJzY3JpYmUtdGltZSBjYWxsIGlzIG5vdCBhbiBhbnN3ZXInLCBhc3luYyAoKSA9PiB7XG4gICAgLy8gYG9uQ2F0YWxvZ0NoYW5nZWAgaW52b2tlcyBpdHMgbGlzdGVuZXIgb25jZSwgU1lOQ0hST05PVVNMWSwgd2l0aCB0aGUgY3VycmVudCB2YWx1ZVxuICAgIC8vIHdoZW4geW91IHN1YnNjcmliZS4gSWYgdGhhdCBjb3VudGVkLCB0aGUgZmxhZyB3b3VsZCBiZSB0cnVlIGZyb20gbW9kdWxlIGxvYWQgYW5kXG4gICAgLy8gdGhlIHJlYWNoIGNhcmQgd291bGQgcmVhZCBhbiB1bmFuc3dlcmVkIGNhdGFsb2cgYXMgXCJub3QgZ3JhbnRlZFwiIOKAlCB0aGUgZXhhY3QgZGVmZWN0XG4gICAgLy8gdGhpcyBob29rIGV4aXN0cyB0byBwcmV2ZW50LlxuICAgIGdldENhdGFsb2coKTsgLy8gc3RhcnQgdGhlIGNoYW5uZWwgdGhlIHdheSB0aGUgYXBwIGRvZXNcbiAgICBjb25zdCB7IHNlZW4sIHVubW91bnQgfSA9IGF3YWl0IHJlbmRlclByb2JlKCk7XG4gICAgZXhwZWN0KHNlZW5bc2Vlbi5sZW5ndGggLSAxXSkudG9CZShmYWxzZSk7XG4gICAgYXdhaXQgdW5tb3VudCgpO1xuICB9KTtcblxuICBpdCgnYW4gRU1QVFkgY2F0YWxvZyBhbnN3ZXIgZmxpcHMgaXQsIGFuZCBSRS1SRU5ERVJTIOKAlCBhbiBlbXB0eSBhbnN3ZXIgaXMgc3RpbGwgYW4gYW5zd2VyJywgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHsgc2VlbiwgdW5tb3VudCB9ID0gYXdhaXQgcmVuZGVyUHJvYmUoKTtcbiAgICBleHBlY3Qoc2VlbltzZWVuLmxlbmd0aCAtIDFdKS50b0JlKGZhbHNlKTtcbiAgICBjb25zdCBiZWZvcmUgPSBzZWVuLmxlbmd0aDtcblxuICAgIGF3YWl0IGFjdChhc3luYyAoKSA9PiB7XG4gICAgICBlbWl0KHsgdHlwZTogJ2FwaS1jYXRhbG9nJywgbWV0aG9kczogW10gfSk7XG4gICAgfSk7XG5cbiAgICAvLyBCb3RoIGhhbHZlcyBtYXR0ZXI6IGEgaG9vayB0aGF0IHJldHVybmVkIHRoZSBmbGFnIHdpdGhvdXQgc3Vic2NyaWJpbmcgd291bGQgc2hvd1xuICAgIC8vIHRoZSByaWdodCB2YWx1ZSBvbmx5IG9uIHRoZSBORVhUIHVucmVsYXRlZCByZW5kZXIuXG4gICAgZXhwZWN0KHNlZW4ubGVuZ3RoKS50b0JlR3JlYXRlclRoYW4oYmVmb3JlKTtcbiAgICBleHBlY3Qoc2VlbltzZWVuLmxlbmd0aCAtIDFdKS50b0JlKHRydWUpO1xuICAgIGF3YWl0IHVubW91bnQoKTtcbiAgfSk7XG5cbiAgaXQoJ3N0YXlzIHRydWUgZm9yIGEgcHJvYmUgbW91bnRlZCBhZnRlciB0aGUgYW5zd2VyJywgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHsgc2VlbiwgdW5tb3VudCB9ID0gYXdhaXQgcmVuZGVyUHJvYmUoKTtcbiAgICBleHBlY3Qoc2VlbltzZWVuLmxlbmd0aCAtIDFdKS50b0JlKHRydWUpO1xuICAgIGF3YWl0IHVubW91bnQoKTtcbiAgfSk7XG59KTtcbiJdLCJtYXBwaW5ncyI6Ijs7QUFVQSxJQUFBQSxPQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxNQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxPQUFBLEdBQUFGLE9BQUE7QUFBOEMsSUFBQUcsV0FBQSxHQUFBSCxPQUFBO0FBQUEsU0FBQUkseUJBQUFDLENBQUEsNkJBQUFDLE9BQUEsbUJBQUFDLENBQUEsT0FBQUQsT0FBQSxJQUFBRSxDQUFBLE9BQUFGLE9BQUEsWUFBQUYsd0JBQUEsWUFBQUEsQ0FBQUMsQ0FBQSxXQUFBQSxDQUFBLEdBQUFHLENBQUEsR0FBQUQsQ0FBQSxLQUFBRixDQUFBO0FBQUEsU0FBQUksd0JBQUFKLENBQUEsRUFBQUUsQ0FBQSxTQUFBQSxDQUFBLElBQUFGLENBQUEsSUFBQUEsQ0FBQSxDQUFBSyxVQUFBLFNBQUFMLENBQUEsZUFBQUEsQ0FBQSx1QkFBQUEsQ0FBQSx5QkFBQUEsQ0FBQSxXQUFBTSxPQUFBLEVBQUFOLENBQUEsUUFBQUcsQ0FBQSxHQUFBSix3QkFBQSxDQUFBRyxDQUFBLE9BQUFDLENBQUEsSUFBQUEsQ0FBQSxDQUFBSSxHQUFBLENBQUFQLENBQUEsVUFBQUcsQ0FBQSxDQUFBSyxHQUFBLENBQUFSLENBQUEsT0FBQVMsQ0FBQSxLQUFBQyxTQUFBLFVBQUFDLENBQUEsR0FBQUMsTUFBQSxDQUFBQyxjQUFBLElBQUFELE1BQUEsQ0FBQUUsd0JBQUEsV0FBQUMsQ0FBQSxJQUFBZixDQUFBLG9CQUFBZSxDQUFBLE9BQUFDLGNBQUEsQ0FBQUMsSUFBQSxDQUFBakIsQ0FBQSxFQUFBZSxDQUFBLFNBQUFHLENBQUEsR0FBQVAsQ0FBQSxHQUFBQyxNQUFBLENBQUFFLHdCQUFBLENBQUFkLENBQUEsRUFBQWUsQ0FBQSxVQUFBRyxDQUFBLEtBQUFBLENBQUEsQ0FBQVYsR0FBQSxJQUFBVSxDQUFBLENBQUFDLEdBQUEsSUFBQVAsTUFBQSxDQUFBQyxjQUFBLENBQUFKLENBQUEsRUFBQU0sQ0FBQSxFQUFBRyxDQUFBLElBQUFULENBQUEsQ0FBQU0sQ0FBQSxJQUFBZixDQUFBLENBQUFlLENBQUEsWUFBQU4sQ0FBQSxDQUFBSCxPQUFBLEdBQUFOLENBQUEsRUFBQUcsQ0FBQSxJQUFBQSxDQUFBLENBQUFnQixHQUFBLENBQUFuQixDQUFBLEVBQUFTLENBQUEsR0FBQUEsQ0FBQSxJQVo5QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQU1BLE1BQU1XLFFBQVEsR0FBRyxJQUFJQyxHQUFHLENBQVUsQ0FBQztBQUNuQyxNQUFNQyxJQUFJLEdBQUlDLEdBQTRCLElBQVc7RUFDbkQsS0FBSyxNQUFNQyxDQUFDLElBQUlKLFFBQVEsRUFBRUksQ0FBQyxDQUFDRCxHQUFHLENBQUM7QUFDbEMsQ0FBQzs7QUFFRDtBQUNBO0FBQ0NFLFVBQVUsQ0FBc0NDLGtCQUFrQixHQUFHO0VBQ3BFQyxTQUFTLEVBQUU7SUFDVEMsV0FBVyxFQUFFQyxVQUFFLENBQUNDLEVBQUUsQ0FBQyxDQUFDO0lBQ3BCQyxlQUFlLEVBQUVGLFVBQUUsQ0FBQ0MsRUFBRSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUN4Q0UsU0FBUyxFQUFHQyxPQUFnQixJQUFLO01BQy9CYixRQUFRLENBQUNjLEdBQUcsQ0FBQ0QsT0FBTyxDQUFDO01BQ3JCLE9BQU87UUFBRUUsT0FBTyxFQUFFQSxDQUFBLEtBQU1mLFFBQVEsQ0FBQ2dCLE1BQU0sQ0FBQ0gsT0FBTztNQUFFLENBQUM7SUFDcEQ7RUFDRjtBQUNGLENBQUM7QUFFRCxJQUFJSSxrQkFBNEU7QUFDaEYsSUFBSUMsVUFBNEQ7QUFFaEUsSUFBQUMsaUJBQVMsRUFBQyxZQUFZO0VBQ3BCLENBQUM7SUFBRUY7RUFBbUIsQ0FBQyxHQUFHLE1BQUFHLE9BQUEsQ0FBQUMsT0FBQSxHQUFBQyxJQUFBLE9BQUF0Qyx1QkFBQSxDQUFBVCxPQUFBLENBQWEsc0JBQXNCLEdBQUM7RUFDOUQsQ0FBQztJQUFFMkM7RUFBVyxDQUFDLEdBQUcsTUFBQUUsT0FBQSxDQUFBQyxPQUFBLEdBQUFDLElBQUEsT0FBQXRDLHVCQUFBLENBQUFULE9BQUEsQ0FBYSxzQkFBc0IsR0FBQztBQUN4RCxDQUFDLENBQUM7O0FBRUY7QUFDQSxNQUFNZ0QsV0FBVyxHQUFHLE1BQUFBLENBQUEsS0FBWTtFQUFBLElBQUFDLEVBQUEsR0FBQUMsWUFBQTtFQUM5QixNQUFNQyxJQUFlLEdBQUcsRUFBRTtFQUMxQixNQUFNQyxLQUFLLEdBQUdBLENBQUEsS0FBTTtJQUFBSCxFQUFBO0lBQ2xCRSxJQUFJLENBQUNFLElBQUksQ0FBQ1gsa0JBQWtCLENBQUMsQ0FBQyxDQUFDO0lBQy9CLE9BQU8sSUFBSTtFQUNiLENBQUM7RUFBQ08sRUFBQSxDQUhJRyxLQUFLO0lBQUEsUUFDQ1Ysa0JBQWtCO0VBQUE7RUFHOUIsTUFBTVksSUFBSSxHQUFHLElBQUFDLGtCQUFVLEVBQUNDLFFBQVEsQ0FBQ0MsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDO0VBQ3RELE1BQU0sSUFBQUMsVUFBRyxFQUFDLFlBQVk7SUFDcEJKLElBQUksQ0FBQ0ssTUFBTSxjQUFDLElBQUF4RCxXQUFBLENBQUF5RCxHQUFBLEVBQUNSLEtBQUssSUFBRSxDQUFDLENBQUM7RUFDeEIsQ0FBQyxDQUFDO0VBQ0YsT0FBTztJQUFFRCxJQUFJO0lBQUVVLE9BQU8sRUFBRUEsQ0FBQSxLQUFNLElBQUFILFVBQUcsRUFBQyxZQUFZSixJQUFJLENBQUNPLE9BQU8sQ0FBQyxDQUFDO0VBQUUsQ0FBQztBQUNqRSxDQUFDO0FBRUQsSUFBQUMsZ0JBQVEsRUFBQyxvQkFBb0IsRUFBRSxNQUFNO0VBQ25DLElBQUFDLFVBQUUsRUFBQyw2RUFBNkUsRUFBRSxZQUFZO0lBQzVGO0lBQ0E7SUFDQTtJQUNBO0lBQ0FwQixVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDZCxNQUFNO01BQUVRLElBQUk7TUFBRVU7SUFBUSxDQUFDLEdBQUcsTUFBTWIsV0FBVyxDQUFDLENBQUM7SUFDN0MsSUFBQWdCLGNBQU0sRUFBQ2IsSUFBSSxDQUFDQSxJQUFJLENBQUNjLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDQyxJQUFJLENBQUMsS0FBSyxDQUFDO0lBQ3pDLE1BQU1MLE9BQU8sQ0FBQyxDQUFDO0VBQ2pCLENBQUMsQ0FBQztFQUVGLElBQUFFLFVBQUUsRUFBQyx1RkFBdUYsRUFBRSxZQUFZO0lBQ3RHLE1BQU07TUFBRVosSUFBSTtNQUFFVTtJQUFRLENBQUMsR0FBRyxNQUFNYixXQUFXLENBQUMsQ0FBQztJQUM3QyxJQUFBZ0IsY0FBTSxFQUFDYixJQUFJLENBQUNBLElBQUksQ0FBQ2MsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUNDLElBQUksQ0FBQyxLQUFLLENBQUM7SUFDekMsTUFBTUMsTUFBTSxHQUFHaEIsSUFBSSxDQUFDYyxNQUFNO0lBRTFCLE1BQU0sSUFBQVAsVUFBRyxFQUFDLFlBQVk7TUFDcEIvQixJQUFJLENBQUM7UUFBRXlDLElBQUksRUFBRSxhQUFhO1FBQUVDLE9BQU8sRUFBRTtNQUFHLENBQUMsQ0FBQztJQUM1QyxDQUFDLENBQUM7O0lBRUY7SUFDQTtJQUNBLElBQUFMLGNBQU0sRUFBQ2IsSUFBSSxDQUFDYyxNQUFNLENBQUMsQ0FBQ0ssZUFBZSxDQUFDSCxNQUFNLENBQUM7SUFDM0MsSUFBQUgsY0FBTSxFQUFDYixJQUFJLENBQUNBLElBQUksQ0FBQ2MsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUNDLElBQUksQ0FBQyxJQUFJLENBQUM7SUFDeEMsTUFBTUwsT0FBTyxDQUFDLENBQUM7RUFDakIsQ0FBQyxDQUFDO0VBRUYsSUFBQUUsVUFBRSxFQUFDLGlEQUFpRCxFQUFFLFlBQVk7SUFDaEUsTUFBTTtNQUFFWixJQUFJO01BQUVVO0lBQVEsQ0FBQyxHQUFHLE1BQU1iLFdBQVcsQ0FBQyxDQUFDO0lBQzdDLElBQUFnQixjQUFNLEVBQUNiLElBQUksQ0FBQ0EsSUFBSSxDQUFDYyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLElBQUksQ0FBQztJQUN4QyxNQUFNTCxPQUFPLENBQUMsQ0FBQztFQUNqQixDQUFDLENBQUM7QUFDSixDQUFDLENBQUMiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}