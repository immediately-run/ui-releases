var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = PageMeta;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.map.js");
var _react = require("react");
var _sdk = require("@immediately-run/sdk");
var _TinkerableContext = require("@immediately-run/sdk/TinkerableContext");
var _content = require("../lib/content");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$();
/* eslint-disable @typescript-eslint/no-explicit-any */
// `<PageMeta/>` — the current entry's date + tags as a styled strip, for authors
// who want the meta inside the body (the entry header already renders one).
function PageMeta() {
  _s();
  const ctx = (0, _react.useContext)(_TinkerableContext.TinkerableContext);
  const key = (0, _content.sandboxPathToKey)(ctx?.navigationState?.sandboxPath || '/');
  const meta = (0, _sdk.useFileMetadata)(key);
  if (!meta) return null;
  const tags = Array.isArray(meta.tags) ? meta.tags.filter(t => !t.startsWith('ui/')) : [];
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "grove-meta",
    children: [meta.date && /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
      children: meta.date
    }), tags.length ? /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
      className: "dot",
      children: "\xB7"
    }) : null, tags.map(t => /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
      className: "grove-tag",
      children: ["#", t]
    }, t))]
  });
}
_s(PageMeta, "XsLrYX1eIrfJj2lJAI6wnixvVtI=", false, function () {
  return [_sdk.useFileMetadata];
});
_c = PageMeta;
var _c;
$RefreshReg$(_c, "PageMeta");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3NkayIsIl9UaW5rZXJhYmxlQ29udGV4dCIsIl9jb250ZW50IiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsIlBhZ2VNZXRhIiwiY3R4IiwidXNlQ29udGV4dCIsIlRpbmtlcmFibGVDb250ZXh0Iiwia2V5Iiwic2FuZGJveFBhdGhUb0tleSIsIm5hdmlnYXRpb25TdGF0ZSIsInNhbmRib3hQYXRoIiwibWV0YSIsInVzZUZpbGVNZXRhZGF0YSIsInRhZ3MiLCJBcnJheSIsImlzQXJyYXkiLCJmaWx0ZXIiLCJ0Iiwic3RhcnRzV2l0aCIsImpzeHMiLCJjbGFzc05hbWUiLCJjaGlsZHJlbiIsImRhdGUiLCJqc3giLCJsZW5ndGgiLCJtYXAiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlBhZ2VNZXRhLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55ICovXG5pbXBvcnQgeyB1c2VDb250ZXh0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlRmlsZU1ldGFkYXRhIH0gZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9zZGsnO1xuaW1wb3J0IHsgVGlua2VyYWJsZUNvbnRleHQgfSBmcm9tICdAaW1tZWRpYXRlbHktcnVuL3Nkay9UaW5rZXJhYmxlQ29udGV4dCc7XG5pbXBvcnQgeyBzYW5kYm94UGF0aFRvS2V5IH0gZnJvbSAnLi4vbGliL2NvbnRlbnQnO1xuXG4vLyBgPFBhZ2VNZXRhLz5gIOKAlCB0aGUgY3VycmVudCBlbnRyeSdzIGRhdGUgKyB0YWdzIGFzIGEgc3R5bGVkIHN0cmlwLCBmb3IgYXV0aG9yc1xuLy8gd2hvIHdhbnQgdGhlIG1ldGEgaW5zaWRlIHRoZSBib2R5ICh0aGUgZW50cnkgaGVhZGVyIGFscmVhZHkgcmVuZGVycyBvbmUpLlxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUGFnZU1ldGEoKSB7XG4gIGNvbnN0IGN0eCA9IHVzZUNvbnRleHQoVGlua2VyYWJsZUNvbnRleHQpIGFzIGFueTtcbiAgY29uc3Qga2V5ID0gc2FuZGJveFBhdGhUb0tleShjdHg/Lm5hdmlnYXRpb25TdGF0ZT8uc2FuZGJveFBhdGggfHwgJy8nKTtcbiAgY29uc3QgbWV0YSA9IHVzZUZpbGVNZXRhZGF0YShrZXkpIGFzIGFueTtcbiAgaWYgKCFtZXRhKSByZXR1cm4gbnVsbDtcbiAgY29uc3QgdGFnczogc3RyaW5nW10gPSBBcnJheS5pc0FycmF5KG1ldGEudGFncykgPyBtZXRhLnRhZ3MuZmlsdGVyKCh0OiBzdHJpbmcpID0+ICF0LnN0YXJ0c1dpdGgoJ3VpLycpKSA6IFtdO1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JvdmUtbWV0YVwiPlxuICAgICAge21ldGEuZGF0ZSAmJiA8c3Bhbj57bWV0YS5kYXRlfTwvc3Bhbj59XG4gICAgICB7dGFncy5sZW5ndGggPyA8c3BhbiBjbGFzc05hbWU9XCJkb3RcIj7Ctzwvc3Bhbj4gOiBudWxsfVxuICAgICAge3RhZ3MubWFwKCh0KSA9PiAoXG4gICAgICAgIDxzcGFuIGtleT17dH0gY2xhc3NOYW1lPVwiZ3JvdmUtdGFnXCI+I3t0fTwvc3Bhbj5cbiAgICAgICkpfVxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFDQSxJQUFBQSxNQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxJQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxrQkFBQSxHQUFBRixPQUFBO0FBQ0EsSUFBQUcsUUFBQSxHQUFBSCxPQUFBO0FBQWtELElBQUFJLFdBQUEsR0FBQUosT0FBQTtBQUFBLElBQUFLLEVBQUEsR0FBQUMsWUFBQTtBQUpsRDtBQU1BO0FBQ0E7QUFDZSxTQUFTQyxRQUFRQSxDQUFBLEVBQUc7RUFBQUYsRUFBQTtFQUNqQyxNQUFNRyxHQUFHLEdBQUcsSUFBQUMsaUJBQVUsRUFBQ0Msb0NBQWlCLENBQVE7RUFDaEQsTUFBTUMsR0FBRyxHQUFHLElBQUFDLHlCQUFnQixFQUFDSixHQUFHLEVBQUVLLGVBQWUsRUFBRUMsV0FBVyxJQUFJLEdBQUcsQ0FBQztFQUN0RSxNQUFNQyxJQUFJLEdBQUcsSUFBQUMsb0JBQWUsRUFBQ0wsR0FBRyxDQUFRO0VBQ3hDLElBQUksQ0FBQ0ksSUFBSSxFQUFFLE9BQU8sSUFBSTtFQUN0QixNQUFNRSxJQUFjLEdBQUdDLEtBQUssQ0FBQ0MsT0FBTyxDQUFDSixJQUFJLENBQUNFLElBQUksQ0FBQyxHQUFHRixJQUFJLENBQUNFLElBQUksQ0FBQ0csTUFBTSxDQUFFQyxDQUFTLElBQUssQ0FBQ0EsQ0FBQyxDQUFDQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxFQUFFO0VBQzVHLG9CQUNFLElBQUFsQixXQUFBLENBQUFtQixJQUFBO0lBQUtDLFNBQVMsRUFBQyxZQUFZO0lBQUFDLFFBQUEsR0FDeEJWLElBQUksQ0FBQ1csSUFBSSxpQkFBSSxJQUFBdEIsV0FBQSxDQUFBdUIsR0FBQTtNQUFBRixRQUFBLEVBQU9WLElBQUksQ0FBQ1c7SUFBSSxDQUFPLENBQUMsRUFDckNULElBQUksQ0FBQ1csTUFBTSxnQkFBRyxJQUFBeEIsV0FBQSxDQUFBdUIsR0FBQTtNQUFNSCxTQUFTLEVBQUMsS0FBSztNQUFBQyxRQUFBLEVBQUM7SUFBQyxDQUFNLENBQUMsR0FBRyxJQUFJLEVBQ25EUixJQUFJLENBQUNZLEdBQUcsQ0FBRVIsQ0FBQyxpQkFDVixJQUFBakIsV0FBQSxDQUFBbUIsSUFBQTtNQUFjQyxTQUFTLEVBQUMsV0FBVztNQUFBQyxRQUFBLEdBQUMsR0FBQyxFQUFDSixDQUFDO0lBQUEsR0FBNUJBLENBQW1DLENBQy9DLENBQUM7RUFBQSxDQUNDLENBQUM7QUFFVjtBQUFDaEIsRUFBQSxDQWZ1QkUsUUFBUTtFQUFBLFFBR2pCUyxvQkFBZTtBQUFBO0FBQUFjLEVBQUEsR0FITnZCLFFBQVE7QUFBQSxJQUFBdUIsRUFBQTtBQUFBQyxZQUFBLENBQUFELEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}