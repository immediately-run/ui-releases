var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = AssetImage;
var _react = require("react");
var _TinkerableContext = require("@immediately-run/sdk/TinkerableContext");
var _sdk = require("@immediately-run/sdk");
var _content = require("../lib/content");
var _assetPath = require("../lib/assetPath");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // MDX `img` override: display a mount-relative image by reading its bytes off the
// sandbox fs (the opaque-origin iframe can't fetch a relative path). Resolves the
// src relative to the entry currently being rendered (navigationState.sandboxPath),
// then hands the file to the SDK's `MountImage`, which owns the read → object URL →
// revoke lifecycle we used to hand-roll here.
// The whole sandbox fs, `/`-rooted. The resolved asset path is already absolute
// (`/app/content/…`), so anchor at root and pass it as the mount-relative path
// (leading slash stripped) — preserving the exact paths the old `fs.readFile` read.
const ROOT_MOUNT = {
  path: '/',
  type: 'repo'
};
function AssetImage({
  src = '',
  alt = '',
  className
}) {
  _s();
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const {
    navigationState
  } = (0, _react.useContext)(_TinkerableContext.TinkerableContext);
  const relPath = (0, _react.useMemo)(() => {
    // The entry's absolute fs path (/app/content/...) is the base for relative assets.
    const base = (0, _content.toFsPath)(navigationState?.sandboxPath || '/');
    return (0, _assetPath.resolvePath)(base, src).replace(/^\/+/, '');
  }, [navigationState?.sandboxPath, src]);
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_sdk.MountImage, {
    mount: ROOT_MOUNT,
    relPath: relPath,
    alt: alt,
    className: className || 'grove-img__el',
    placeholder: /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
      className: "grove-img__box",
      style: {
        display: 'block',
        minHeight: 80
      }
    }),
    fallback: /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
      className: "grove-img__cap",
      children: ["missing asset: ", src]
    })
  });
}
_s(AssetImage, "6xdvNmgBdt2bJOBczsCyhVjAIlE=");
_c = AssetImage;
var _c;
$RefreshReg$(_c, "AssetImage");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX1RpbmtlcmFibGVDb250ZXh0IiwiX3NkayIsIl9jb250ZW50IiwiX2Fzc2V0UGF0aCIsIl9qc3hSdW50aW1lIiwiX3MiLCIkUmVmcmVzaFNpZyQiLCJST09UX01PVU5UIiwicGF0aCIsInR5cGUiLCJBc3NldEltYWdlIiwic3JjIiwiYWx0IiwiY2xhc3NOYW1lIiwibmF2aWdhdGlvblN0YXRlIiwidXNlQ29udGV4dCIsIlRpbmtlcmFibGVDb250ZXh0IiwicmVsUGF0aCIsInVzZU1lbW8iLCJiYXNlIiwidG9Gc1BhdGgiLCJzYW5kYm94UGF0aCIsInJlc29sdmVQYXRoIiwicmVwbGFjZSIsImpzeCIsIk1vdW50SW1hZ2UiLCJtb3VudCIsInBsYWNlaG9sZGVyIiwic3R5bGUiLCJkaXNwbGF5IiwibWluSGVpZ2h0IiwiZmFsbGJhY2siLCJqc3hzIiwiY2hpbGRyZW4iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkFzc2V0SW1hZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUNvbnRleHQsIHVzZU1lbW8gfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBUaW5rZXJhYmxlQ29udGV4dCB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrL1RpbmtlcmFibGVDb250ZXh0JztcbmltcG9ydCB7IE1vdW50SW1hZ2UgfSBmcm9tICdAaW1tZWRpYXRlbHktcnVuL3Nkayc7XG5pbXBvcnQgdHlwZSB7IFNhbmRib3hNb3VudCB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrJztcbmltcG9ydCB7IHRvRnNQYXRoIH0gZnJvbSAnLi4vbGliL2NvbnRlbnQnO1xuaW1wb3J0IHsgcmVzb2x2ZVBhdGggfSBmcm9tICcuLi9saWIvYXNzZXRQYXRoJztcblxuLy8gTURYIGBpbWdgIG92ZXJyaWRlOiBkaXNwbGF5IGEgbW91bnQtcmVsYXRpdmUgaW1hZ2UgYnkgcmVhZGluZyBpdHMgYnl0ZXMgb2ZmIHRoZVxuLy8gc2FuZGJveCBmcyAodGhlIG9wYXF1ZS1vcmlnaW4gaWZyYW1lIGNhbid0IGZldGNoIGEgcmVsYXRpdmUgcGF0aCkuIFJlc29sdmVzIHRoZVxuLy8gc3JjIHJlbGF0aXZlIHRvIHRoZSBlbnRyeSBjdXJyZW50bHkgYmVpbmcgcmVuZGVyZWQgKG5hdmlnYXRpb25TdGF0ZS5zYW5kYm94UGF0aCksXG4vLyB0aGVuIGhhbmRzIHRoZSBmaWxlIHRvIHRoZSBTREsncyBgTW91bnRJbWFnZWAsIHdoaWNoIG93bnMgdGhlIHJlYWQg4oaSIG9iamVjdCBVUkwg4oaSXG4vLyByZXZva2UgbGlmZWN5Y2xlIHdlIHVzZWQgdG8gaGFuZC1yb2xsIGhlcmUuXG5cbi8vIFRoZSB3aG9sZSBzYW5kYm94IGZzLCBgL2Atcm9vdGVkLiBUaGUgcmVzb2x2ZWQgYXNzZXQgcGF0aCBpcyBhbHJlYWR5IGFic29sdXRlXG4vLyAoYC9hcHAvY29udGVudC/igKZgKSwgc28gYW5jaG9yIGF0IHJvb3QgYW5kIHBhc3MgaXQgYXMgdGhlIG1vdW50LXJlbGF0aXZlIHBhdGhcbi8vIChsZWFkaW5nIHNsYXNoIHN0cmlwcGVkKSDigJQgcHJlc2VydmluZyB0aGUgZXhhY3QgcGF0aHMgdGhlIG9sZCBgZnMucmVhZEZpbGVgIHJlYWQuXG5jb25zdCBST09UX01PVU5UOiBTYW5kYm94TW91bnQgPSB7IHBhdGg6ICcvJywgdHlwZTogJ3JlcG8nIH07XG5cbmludGVyZmFjZSBQcm9wcyB7XG4gIHNyYz86IHN0cmluZztcbiAgYWx0Pzogc3RyaW5nO1xuICBjbGFzc05hbWU/OiBzdHJpbmc7XG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFzc2V0SW1hZ2UoeyBzcmMgPSAnJywgYWx0ID0gJycsIGNsYXNzTmFtZSB9OiBQcm9wcykge1xuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueVxuICBjb25zdCB7IG5hdmlnYXRpb25TdGF0ZSB9ID0gdXNlQ29udGV4dChUaW5rZXJhYmxlQ29udGV4dCkgYXMgYW55O1xuXG4gIGNvbnN0IHJlbFBhdGggPSB1c2VNZW1vKCgpID0+IHtcbiAgICAvLyBUaGUgZW50cnkncyBhYnNvbHV0ZSBmcyBwYXRoICgvYXBwL2NvbnRlbnQvLi4uKSBpcyB0aGUgYmFzZSBmb3IgcmVsYXRpdmUgYXNzZXRzLlxuICAgIGNvbnN0IGJhc2UgPSB0b0ZzUGF0aChuYXZpZ2F0aW9uU3RhdGU/LnNhbmRib3hQYXRoIHx8ICcvJyk7XG4gICAgcmV0dXJuIHJlc29sdmVQYXRoKGJhc2UsIHNyYykucmVwbGFjZSgvXlxcLysvLCAnJyk7XG4gIH0sIFtuYXZpZ2F0aW9uU3RhdGU/LnNhbmRib3hQYXRoLCBzcmNdKTtcblxuICByZXR1cm4gKFxuICAgIDxNb3VudEltYWdlXG4gICAgICBtb3VudD17Uk9PVF9NT1VOVH1cbiAgICAgIHJlbFBhdGg9e3JlbFBhdGh9XG4gICAgICBhbHQ9e2FsdH1cbiAgICAgIGNsYXNzTmFtZT17Y2xhc3NOYW1lIHx8ICdncm92ZS1pbWdfX2VsJ31cbiAgICAgIHBsYWNlaG9sZGVyPXtcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZ3JvdmUtaW1nX19ib3hcIiBzdHlsZT17eyBkaXNwbGF5OiAnYmxvY2snLCBtaW5IZWlnaHQ6IDgwIH19IC8+XG4gICAgICB9XG4gICAgICBmYWxsYmFjaz17PHNwYW4gY2xhc3NOYW1lPVwiZ3JvdmUtaW1nX19jYXBcIj5taXNzaW5nIGFzc2V0OiB7c3JjfTwvc3Bhbj59XG4gICAgLz5cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQUEsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsa0JBQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLElBQUEsR0FBQUYsT0FBQTtBQUVBLElBQUFHLFFBQUEsR0FBQUgsT0FBQTtBQUNBLElBQUFJLFVBQUEsR0FBQUosT0FBQTtBQUErQyxJQUFBSyxXQUFBLEdBQUFMLE9BQUE7QUFBQSxJQUFBTSxFQUFBLEdBQUFDLFlBQUEsSUFFL0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBLE1BQU1DLFVBQXdCLEdBQUc7RUFBRUMsSUFBSSxFQUFFLEdBQUc7RUFBRUMsSUFBSSxFQUFFO0FBQU8sQ0FBQztBQVE3QyxTQUFTQyxVQUFVQSxDQUFDO0VBQUVDLEdBQUcsR0FBRyxFQUFFO0VBQUVDLEdBQUcsR0FBRyxFQUFFO0VBQUVDO0FBQWlCLENBQUMsRUFBRTtFQUFBUixFQUFBO0VBQzNFO0VBQ0EsTUFBTTtJQUFFUztFQUFnQixDQUFDLEdBQUcsSUFBQUMsaUJBQVUsRUFBQ0Msb0NBQWlCLENBQVE7RUFFaEUsTUFBTUMsT0FBTyxHQUFHLElBQUFDLGNBQU8sRUFBQyxNQUFNO0lBQzVCO0lBQ0EsTUFBTUMsSUFBSSxHQUFHLElBQUFDLGlCQUFRLEVBQUNOLGVBQWUsRUFBRU8sV0FBVyxJQUFJLEdBQUcsQ0FBQztJQUMxRCxPQUFPLElBQUFDLHNCQUFXLEVBQUNILElBQUksRUFBRVIsR0FBRyxDQUFDLENBQUNZLE9BQU8sQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDO0VBQ25ELENBQUMsRUFBRSxDQUFDVCxlQUFlLEVBQUVPLFdBQVcsRUFBRVYsR0FBRyxDQUFDLENBQUM7RUFFdkMsb0JBQ0UsSUFBQVAsV0FBQSxDQUFBb0IsR0FBQSxFQUFDdkIsSUFBQSxDQUFBd0IsVUFBVTtJQUNUQyxLQUFLLEVBQUVuQixVQUFXO0lBQ2xCVSxPQUFPLEVBQUVBLE9BQVE7SUFDakJMLEdBQUcsRUFBRUEsR0FBSTtJQUNUQyxTQUFTLEVBQUVBLFNBQVMsSUFBSSxlQUFnQjtJQUN4Q2MsV0FBVyxlQUNULElBQUF2QixXQUFBLENBQUFvQixHQUFBO01BQU1YLFNBQVMsRUFBQyxnQkFBZ0I7TUFBQ2UsS0FBSyxFQUFFO1FBQUVDLE9BQU8sRUFBRSxPQUFPO1FBQUVDLFNBQVMsRUFBRTtNQUFHO0lBQUUsQ0FBRSxDQUMvRTtJQUNEQyxRQUFRLGVBQUUsSUFBQTNCLFdBQUEsQ0FBQTRCLElBQUE7TUFBTW5CLFNBQVMsRUFBQyxnQkFBZ0I7TUFBQW9CLFFBQUEsR0FBQyxpQkFBZSxFQUFDdEIsR0FBRztJQUFBLENBQU87RUFBRSxDQUN4RSxDQUFDO0FBRU47QUFBQ04sRUFBQSxDQXRCdUJLLFVBQVU7QUFBQXdCLEVBQUEsR0FBVnhCLFVBQVU7QUFBQSxJQUFBd0IsRUFBQTtBQUFBQyxZQUFBLENBQUFELEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}