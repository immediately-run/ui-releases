var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Toc;
var _TableOfContents = _interopRequireDefault(require("./TableOfContents"));
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// `<Toc/>` — the on-this-page rail, and the name every existing layout and entry uses.
//
// It is now an alias for `<TableOfContents/>`, which is the same list plus "keep the
// current entry in view". Kept as its own name rather than rewritten at the call sites
// because `Toc` is registered content vocabulary: a corpus may already say `<Toc/>`, and
// the engine's names are an interface (spec_style's §-number rule, applied to components).
//
// Deliberately NOT a second implementation. The two used to be one copy of the DOM scan
// each, which is precisely the drift ENGINE_BOUNDARY §4 was written about.
function Toc({
  entryKey
}) {
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_TableOfContents.default, {
    entryKey: entryKey
  });
}
_c = Toc;
var _c;
$RefreshReg$(_c, "Toc");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfVGFibGVPZkNvbnRlbnRzIiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsInJlcXVpcmUiLCJfanN4UnVudGltZSIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsIlRvYyIsImVudHJ5S2V5IiwianN4IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJUb2MudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBUYWJsZU9mQ29udGVudHMgZnJvbSAnLi9UYWJsZU9mQ29udGVudHMnO1xuXG4vLyBgPFRvYy8+YCDigJQgdGhlIG9uLXRoaXMtcGFnZSByYWlsLCBhbmQgdGhlIG5hbWUgZXZlcnkgZXhpc3RpbmcgbGF5b3V0IGFuZCBlbnRyeSB1c2VzLlxuLy9cbi8vIEl0IGlzIG5vdyBhbiBhbGlhcyBmb3IgYDxUYWJsZU9mQ29udGVudHMvPmAsIHdoaWNoIGlzIHRoZSBzYW1lIGxpc3QgcGx1cyBcImtlZXAgdGhlXG4vLyBjdXJyZW50IGVudHJ5IGluIHZpZXdcIi4gS2VwdCBhcyBpdHMgb3duIG5hbWUgcmF0aGVyIHRoYW4gcmV3cml0dGVuIGF0IHRoZSBjYWxsIHNpdGVzXG4vLyBiZWNhdXNlIGBUb2NgIGlzIHJlZ2lzdGVyZWQgY29udGVudCB2b2NhYnVsYXJ5OiBhIGNvcnB1cyBtYXkgYWxyZWFkeSBzYXkgYDxUb2MvPmAsIGFuZFxuLy8gdGhlIGVuZ2luZSdzIG5hbWVzIGFyZSBhbiBpbnRlcmZhY2UgKHNwZWNfc3R5bGUncyDCpy1udW1iZXIgcnVsZSwgYXBwbGllZCB0byBjb21wb25lbnRzKS5cbi8vXG4vLyBEZWxpYmVyYXRlbHkgTk9UIGEgc2Vjb25kIGltcGxlbWVudGF0aW9uLiBUaGUgdHdvIHVzZWQgdG8gYmUgb25lIGNvcHkgb2YgdGhlIERPTSBzY2FuXG4vLyBlYWNoLCB3aGljaCBpcyBwcmVjaXNlbHkgdGhlIGRyaWZ0IEVOR0lORV9CT1VOREFSWSDCpzQgd2FzIHdyaXR0ZW4gYWJvdXQuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBUb2MoeyBlbnRyeUtleSB9OiB7IGVudHJ5S2V5Pzogc3RyaW5nIH0pIHtcbiAgcmV0dXJuIDxUYWJsZU9mQ29udGVudHMgZW50cnlLZXk9e2VudHJ5S2V5fSAvPjtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQUEsSUFBQUEsZ0JBQUEsR0FBQUMsc0JBQUEsQ0FBQUMsT0FBQTtBQUFnRCxJQUFBQyxXQUFBLEdBQUFELE9BQUE7QUFBQSxTQUFBRCx1QkFBQUcsQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQUVoRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDZSxTQUFTRyxHQUFHQSxDQUFDO0VBQUVDO0FBQWdDLENBQUMsRUFBRTtFQUMvRCxvQkFBTyxJQUFBTCxXQUFBLENBQUFNLEdBQUEsRUFBQ1QsZ0JBQUEsQ0FBQU0sT0FBZTtJQUFDRSxRQUFRLEVBQUVBO0VBQVMsQ0FBRSxDQUFDO0FBQ2hEO0FBQUNFLEVBQUEsR0FGdUJILEdBQUc7QUFBQSxJQUFBRyxFQUFBO0FBQUFDLFlBQUEsQ0FBQUQsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}