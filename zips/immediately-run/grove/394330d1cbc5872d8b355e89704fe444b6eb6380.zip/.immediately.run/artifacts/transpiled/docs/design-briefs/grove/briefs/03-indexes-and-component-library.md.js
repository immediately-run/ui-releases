var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      li: "li",
      p: "p",
      strong: "strong",
      table: "table",
      tbody: "tbody",
      td: "td",
      th: "th",
      thead: "thead",
      tr: "tr",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "brief-03-indexes-and-the-built-in-component-library",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "brief-03-indexes-and-the-built-in-component-library"
      }), "Brief 03 — Indexes and the built-in component library"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Discovery surfaces and the visual vocabulary of the import-free components. Assumes\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "./00-foundation.md",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "00-foundation"
        })
      }), ". Source: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "grove.md"
      }), " \"The component library\",\n\"Content model\"."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "the-index-home",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-index-home"
      }), "The index / home"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["A Grove's home is itself an entry that typically renders a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "<DocList>"
      }), " (chronological feed\nor grid) — there's no separate \"home template\" to invent, but design the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "two index\nshapes"
      }), " the components below produce, because the home, tag pages, and section pages all\nreuse them:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Feed shape"
        }), " — a vertical list of entry rows (title, mono date, tag chips, a\none-line description/excerpt, reading time). The journal/blog/changelog look."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Grid shape"
        }), " — entry ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "cards"
        }), " on the brand's asymmetric tile grid: hairline ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--r-lg"
        }), "\ncard, optional cover/asset or the link-graph placeholder motif, title, description, tag\nchips, the hard-offset hover lift. The showcase look (Pixies discography, KB sections)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Both must show ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "loading"
      }), " (skeleton rows/cards), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "empty"
      }), " (\"No entries yet.\"), and\nwork mobile-first (cards → single column)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "the-built-in-components-design-each-once-reuse-everywhere",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-built-in-components-design-each-once-reuse-everywhere"
      }), "The built-in components (design each once, reuse everywhere)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Each is a thin presentational reader with a stable ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: ".grove-*"
      }), " class (brief 00). Design the\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "populated"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "empty"
      }), ", and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "loading"
      }), " appearance of each:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Component"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Class"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Visual spec"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "<DocList sort filter limit>"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: ".grove-doclist"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "the feed/grid shapes above; sort/filter are data, not visible chrome unless the author adds it"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "<DocsByTag tag>"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: ".grove-doclist"
            }), " (filtered)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["identical to DocList; the tag-page body is just this. Header shows the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "#tag"
            }), " + count"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "<Backlinks>"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: ".grove-backlinks"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["footer block: mono \"", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "N"
            }), " entries link here.\" + linking-entry list with snippet (detailed in brief 01)"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "<TagCloud>"
            }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "<TagList>"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: ".grove-tagcloud"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "tag chips sized by frequency (cloud) or a plain sorted list; chips are the brief-00 component"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "<ChildPages>"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: ".grove-doclist"
            }), " (scoped)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "the entries under this one; a compact nested list"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "<Toc>"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: ".grove-toc"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "the on-this-page rail/disclosure (brief 01)"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "<RecentlyUpdated limit>"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: ".grove-doclist"
            }), " (date-sorted)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "compact dated list, mono dates"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "<PageMeta>"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: ".grove-pagemeta"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "the entry's date + tags as a styled header strip (used in the entry header, brief 01)"
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Design rules to honour visually: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "data in, markup out"
      }), " (no chrome of their own beyond\ntheir class), and they must ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "re-skin via CSS"
      }), " like everything else."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "author-reuse-the-infobox-example",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "author-reuse-the-infobox-example"
      }), "Author reuse — the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "<Infobox>"
      }), " example"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Authors share their own repeated elements by ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "MDX import"
      }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "grove.md"
      }), " \"two component\ntiers\"). Design one ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "reference example"
      }), " so the pattern is concrete and dev-copyable: an\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<Infobox>"
        })
      }), " (the LOTR character / Pixies song \"facts panel\"):"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["A right-floated (desktop) / full-width (mobile) hairline ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--r-lg"
        }), " panel inside the prose\ncolumn; a gradient or ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--panel-2"
        }), " header bar with the subject name; a definition-list\nbody of typed fields (mono labels, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--ink"
        }), " values) read from frontmatter\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "house"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "reign"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "album"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "released"
        }), ", …); optional cover asset at top."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["This is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "author-land"
        }), ", not an engine component — present it as a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "pattern + example"
        }), "\nothers clone, styled with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".grove-"
        }), "-adjacent classes so it themes consistently."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "tag-pages",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "tag-pages"
      }), "Tag pages"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The destination of a tag chip / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ui/nav"
      }), " tag: header (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "#tag"
      }), ", count, optional description\nentry), then ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "<DocsByTag>"
      }), " in feed or grid shape, plus a \"related tags\" ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "<TagList>"
      }), ".\nEmpty state for a tag with no entries."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "states-copy",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "states-copy"
      }), "States & copy"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Per surface: populated, empty (each component's \"nothing here\" line — make them specific:\n\"No entries tagged ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "#song"
      }), " yet.\", \"Nothing links here yet.\"), loading skeletons. Draft the\nindex/section headers and the count strings (mono). Sentence case, period-terminated."]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/design-briefs/grove/briefs/03-indexes-and-component-library.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiY29kZSIsImVtIiwiaDEiLCJoMiIsImxpIiwicCIsInN0cm9uZyIsInRhYmxlIiwidGJvZHkiLCJ0ZCIsInRoIiwidGhlYWQiLCJ0ciIsInVsIiwiX3Byb3ZpZGVDb21wb25lbnRzIiwiY29tcG9uZW50cyIsIkhlYWRpbmdBbmNob3IiLCJfbWlzc2luZ01keFJlZmVyZW5jZSIsImpzeHMiLCJGcmFnbWVudCIsImNoaWxkcmVuIiwiaWQiLCJqc3giLCJocmVmIiwiTURYQ29udGVudCIsIndyYXBwZXIiLCJNRFhMYXlvdXQiLCJfYyIsImNvbXBvbmVudCIsInBsYWNlIiwiRXJyb3IiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyIwMy1pbmRleGVzLWFuZC1jb21wb25lbnQtbGlicmFyeS5tZCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKkBqc3hSdW50aW1lIGF1dG9tYXRpYyovXG4vKkBqc3hJbXBvcnRTb3VyY2UgcmVhY3QqL1xuaW1wb3J0IHt1c2VNRFhDb21wb25lbnRzIGFzIF9wcm92aWRlQ29tcG9uZW50c30gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrL01EWFByb3ZpZGVyXCI7XG5mdW5jdGlvbiBfY3JlYXRlTWR4Q29udGVudChwcm9wcykge1xuICBjb25zdCBfY29tcG9uZW50cyA9IHtcbiAgICBhOiBcImFcIixcbiAgICBjb2RlOiBcImNvZGVcIixcbiAgICBlbTogXCJlbVwiLFxuICAgIGgxOiBcImgxXCIsXG4gICAgaDI6IFwiaDJcIixcbiAgICBsaTogXCJsaVwiLFxuICAgIHA6IFwicFwiLFxuICAgIHN0cm9uZzogXCJzdHJvbmdcIixcbiAgICB0YWJsZTogXCJ0YWJsZVwiLFxuICAgIHRib2R5OiBcInRib2R5XCIsXG4gICAgdGQ6IFwidGRcIixcbiAgICB0aDogXCJ0aFwiLFxuICAgIHRoZWFkOiBcInRoZWFkXCIsXG4gICAgdHI6IFwidHJcIixcbiAgICB1bDogXCJ1bFwiLFxuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfSwge0hlYWRpbmdBbmNob3J9ID0gX2NvbXBvbmVudHM7XG4gIGlmICghSGVhZGluZ0FuY2hvcikgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJIZWFkaW5nQW5jaG9yXCIsIHRydWUpO1xuICByZXR1cm4gPD48X2NvbXBvbmVudHMuaDEgaWQ9XCJicmllZi0wMy1pbmRleGVzLWFuZC10aGUtYnVpbHQtaW4tY29tcG9uZW50LWxpYnJhcnlcIj48SGVhZGluZ0FuY2hvciBpZD1cImJyaWVmLTAzLWluZGV4ZXMtYW5kLXRoZS1idWlsdC1pbi1jb21wb25lbnQtbGlicmFyeVwiIC8+e1wiQnJpZWYgMDMg4oCUIEluZGV4ZXMgYW5kIHRoZSBidWlsdC1pbiBjb21wb25lbnQgbGlicmFyeVwifTwvX2NvbXBvbmVudHMuaDE+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiRGlzY292ZXJ5IHN1cmZhY2VzIGFuZCB0aGUgdmlzdWFsIHZvY2FidWxhcnkgb2YgdGhlIGltcG9ydC1mcmVlIGNvbXBvbmVudHMuIEFzc3VtZXNcXG5cIn08X2NvbXBvbmVudHMuYSBocmVmPVwiLi8wMC1mb3VuZGF0aW9uLm1kXCI+PF9jb21wb25lbnRzLmNvZGU+e1wiMDAtZm91bmRhdGlvblwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLmE+e1wiLiBTb3VyY2U6IFwifTxfY29tcG9uZW50cy5jb2RlPntcImdyb3ZlLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBcXFwiVGhlIGNvbXBvbmVudCBsaWJyYXJ5XFxcIixcXG5cXFwiQ29udGVudCBtb2RlbFxcXCIuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInRoZS1pbmRleC1ob21lXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJ0aGUtaW5kZXgtaG9tZVwiIC8+e1wiVGhlIGluZGV4IC8gaG9tZVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiQSBHcm92ZSdzIGhvbWUgaXMgaXRzZWxmIGFuIGVudHJ5IHRoYXQgdHlwaWNhbGx5IHJlbmRlcnMgYSBcIn08X2NvbXBvbmVudHMuY29kZT57XCI8RG9jTGlzdD5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChjaHJvbm9sb2dpY2FsIGZlZWRcXG5vciBncmlkKSDigJQgdGhlcmUncyBubyBzZXBhcmF0ZSBcXFwiaG9tZSB0ZW1wbGF0ZVxcXCIgdG8gaW52ZW50LCBidXQgZGVzaWduIHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInR3byBpbmRleFxcbnNoYXBlc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB0aGUgY29tcG9uZW50cyBiZWxvdyBwcm9kdWNlLCBiZWNhdXNlIHRoZSBob21lLCB0YWcgcGFnZXMsIGFuZCBzZWN0aW9uIHBhZ2VzIGFsbFxcbnJldXNlIHRoZW06XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJGZWVkIHNoYXBlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBhIHZlcnRpY2FsIGxpc3Qgb2YgZW50cnkgcm93cyAodGl0bGUsIG1vbm8gZGF0ZSwgdGFnIGNoaXBzLCBhXFxub25lLWxpbmUgZGVzY3JpcHRpb24vZXhjZXJwdCwgcmVhZGluZyB0aW1lKS4gVGhlIGpvdXJuYWwvYmxvZy9jaGFuZ2Vsb2cgbG9vay5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkdyaWQgc2hhcGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIGVudHJ5IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiY2FyZHNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgb24gdGhlIGJyYW5kJ3MgYXN5bW1ldHJpYyB0aWxlIGdyaWQ6IGhhaXJsaW5lIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi0tci1sZ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG5jYXJkLCBvcHRpb25hbCBjb3Zlci9hc3NldCBvciB0aGUgbGluay1ncmFwaCBwbGFjZWhvbGRlciBtb3RpZiwgdGl0bGUsIGRlc2NyaXB0aW9uLCB0YWdcXG5jaGlwcywgdGhlIGhhcmQtb2Zmc2V0IGhvdmVyIGxpZnQuIFRoZSBzaG93Y2FzZSBsb29rIChQaXhpZXMgZGlzY29ncmFwaHksIEtCIHNlY3Rpb25zKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiQm90aCBtdXN0IHNob3cgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJsb2FkaW5nXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChza2VsZXRvbiByb3dzL2NhcmRzKSwgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJlbXB0eVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoXFxcIk5vIGVudHJpZXMgeWV0LlxcXCIpLCBhbmRcXG53b3JrIG1vYmlsZS1maXJzdCAoY2FyZHMg4oaSIHNpbmdsZSBjb2x1bW4pLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJ0aGUtYnVpbHQtaW4tY29tcG9uZW50cy1kZXNpZ24tZWFjaC1vbmNlLXJldXNlLWV2ZXJ5d2hlcmVcIj48SGVhZGluZ0FuY2hvciBpZD1cInRoZS1idWlsdC1pbi1jb21wb25lbnRzLWRlc2lnbi1lYWNoLW9uY2UtcmV1c2UtZXZlcnl3aGVyZVwiIC8+e1wiVGhlIGJ1aWx0LWluIGNvbXBvbmVudHMgKGRlc2lnbiBlYWNoIG9uY2UsIHJldXNlIGV2ZXJ5d2hlcmUpXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJFYWNoIGlzIGEgdGhpbiBwcmVzZW50YXRpb25hbCByZWFkZXIgd2l0aCBhIHN0YWJsZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCIuZ3JvdmUtKlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgY2xhc3MgKGJyaWVmIDAwKS4gRGVzaWduIHRoZVxcblwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicG9wdWxhdGVkXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImVtcHR5XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBhbmQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJsb2FkaW5nXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGFwcGVhcmFuY2Ugb2YgZWFjaDpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnRhYmxlPjxfY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRoPntcIkNvbXBvbmVudFwifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIkNsYXNzXCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGg+e1wiVmlzdWFsIHNwZWNcIn08L19jb21wb25lbnRzLnRoPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudGJvZHk+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCI8RG9jTGlzdCBzb3J0IGZpbHRlciBsaW1pdD5cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiLmdyb3ZlLWRvY2xpc3RcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1widGhlIGZlZWQvZ3JpZCBzaGFwZXMgYWJvdmU7IHNvcnQvZmlsdGVyIGFyZSBkYXRhLCBub3QgdmlzaWJsZSBjaHJvbWUgdW5sZXNzIHRoZSBhdXRob3IgYWRkcyBpdFwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcIjxEb2NzQnlUYWcgdGFnPlwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCIuZ3JvdmUtZG9jbGlzdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKGZpbHRlcmVkKVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcImlkZW50aWNhbCB0byBEb2NMaXN0OyB0aGUgdGFnLXBhZ2UgYm9keSBpcyBqdXN0IHRoaXMuIEhlYWRlciBzaG93cyB0aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiI3RhZ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKyBjb3VudFwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcIjxCYWNrbGlua3M+XCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcIi5ncm92ZS1iYWNrbGlua3NcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiZm9vdGVyIGJsb2NrOiBtb25vIFxcXCJcIn08X2NvbXBvbmVudHMuY29kZT57XCJOXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBlbnRyaWVzIGxpbmsgaGVyZS5cXFwiICsgbGlua2luZy1lbnRyeSBsaXN0IHdpdGggc25pcHBldCAoZGV0YWlsZWQgaW4gYnJpZWYgMDEpXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiPFRhZ0Nsb3VkPlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgLyBcIn08X2NvbXBvbmVudHMuY29kZT57XCI8VGFnTGlzdD5cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiLmdyb3ZlLXRhZ2Nsb3VkXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcInRhZyBjaGlwcyBzaXplZCBieSBmcmVxdWVuY3kgKGNsb3VkKSBvciBhIHBsYWluIHNvcnRlZCBsaXN0OyBjaGlwcyBhcmUgdGhlIGJyaWVmLTAwIGNvbXBvbmVudFwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcIjxDaGlsZFBhZ2VzPlwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCIuZ3JvdmUtZG9jbGlzdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKHNjb3BlZClcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJ0aGUgZW50cmllcyB1bmRlciB0aGlzIG9uZTsgYSBjb21wYWN0IG5lc3RlZCBsaXN0XCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiPFRvYz5cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiLmdyb3ZlLXRvY1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJ0aGUgb24tdGhpcy1wYWdlIHJhaWwvZGlzY2xvc3VyZSAoYnJpZWYgMDEpXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiPFJlY2VudGx5VXBkYXRlZCBsaW1pdD5cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiLmdyb3ZlLWRvY2xpc3RcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChkYXRlLXNvcnRlZClcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJjb21wYWN0IGRhdGVkIGxpc3QsIG1vbm8gZGF0ZXNcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCI8UGFnZU1ldGE+XCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcIi5ncm92ZS1wYWdlbWV0YVwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJ0aGUgZW50cnkncyBkYXRlICsgdGFncyBhcyBhIHN0eWxlZCBoZWFkZXIgc3RyaXAgKHVzZWQgaW4gdGhlIGVudHJ5IGhlYWRlciwgYnJpZWYgMDEpXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGJvZHk+PC9fY29tcG9uZW50cy50YWJsZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJEZXNpZ24gcnVsZXMgdG8gaG9ub3VyIHZpc3VhbGx5OiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImRhdGEgaW4sIG1hcmt1cCBvdXRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKG5vIGNocm9tZSBvZiB0aGVpciBvd24gYmV5b25kXFxudGhlaXIgY2xhc3MpLCBhbmQgdGhleSBtdXN0IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicmUtc2tpbiB2aWEgQ1NTXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGxpa2UgZXZlcnl0aGluZyBlbHNlLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJhdXRob3ItcmV1c2UtdGhlLWluZm9ib3gtZXhhbXBsZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiYXV0aG9yLXJldXNlLXRoZS1pbmZvYm94LWV4YW1wbGVcIiAvPntcIkF1dGhvciByZXVzZSDigJQgdGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjxJbmZvYm94PlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZXhhbXBsZVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiQXV0aG9ycyBzaGFyZSB0aGVpciBvd24gcmVwZWF0ZWQgZWxlbWVudHMgYnkgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJNRFggaW1wb3J0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJncm92ZS5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgXFxcInR3byBjb21wb25lbnRcXG50aWVyc1xcXCIpLiBEZXNpZ24gb25lIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicmVmZXJlbmNlIGV4YW1wbGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgc28gdGhlIHBhdHRlcm4gaXMgY29uY3JldGUgYW5kIGRldi1jb3B5YWJsZTogYW5cXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPjxfY29tcG9uZW50cy5jb2RlPntcIjxJbmZvYm94PlwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHRoZSBMT1RSIGNoYXJhY3RlciAvIFBpeGllcyBzb25nIFxcXCJmYWN0cyBwYW5lbFxcXCIpOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIkEgcmlnaHQtZmxvYXRlZCAoZGVza3RvcCkgLyBmdWxsLXdpZHRoIChtb2JpbGUpIGhhaXJsaW5lIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi0tci1sZ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcGFuZWwgaW5zaWRlIHRoZSBwcm9zZVxcbmNvbHVtbjsgYSBncmFkaWVudCBvciBcIn08X2NvbXBvbmVudHMuY29kZT57XCItLXBhbmVsLTJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGhlYWRlciBiYXIgd2l0aCB0aGUgc3ViamVjdCBuYW1lOyBhIGRlZmluaXRpb24tbGlzdFxcbmJvZHkgb2YgdHlwZWQgZmllbGRzIChtb25vIGxhYmVscywgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1pbmtcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHZhbHVlcykgcmVhZCBmcm9tIGZyb250bWF0dGVyXFxuKFwifTxfY29tcG9uZW50cy5jb2RlPntcImhvdXNlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicmVpZ25cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJhbGJ1bVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcInJlbGVhc2VkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwg4oCmKTsgb3B0aW9uYWwgY292ZXIgYXNzZXQgYXQgdG9wLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIlRoaXMgaXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJhdXRob3ItbGFuZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgbm90IGFuIGVuZ2luZSBjb21wb25lbnQg4oCUIHByZXNlbnQgaXQgYXMgYSBcIn08X2NvbXBvbmVudHMuZW0+e1wicGF0dGVybiArIGV4YW1wbGVcIn08L19jb21wb25lbnRzLmVtPntcIlxcbm90aGVycyBjbG9uZSwgc3R5bGVkIHdpdGggXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLmdyb3ZlLVwifTwvX2NvbXBvbmVudHMuY29kZT57XCItYWRqYWNlbnQgY2xhc3NlcyBzbyBpdCB0aGVtZXMgY29uc2lzdGVudGx5LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJ0YWctcGFnZXNcIj48SGVhZGluZ0FuY2hvciBpZD1cInRhZy1wYWdlc1wiIC8+e1wiVGFnIHBhZ2VzXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgZGVzdGluYXRpb24gb2YgYSB0YWcgY2hpcCAvIFwifTxfY29tcG9uZW50cy5jb2RlPntcInVpL25hdlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdGFnOiBoZWFkZXIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIiN0YWdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBjb3VudCwgb3B0aW9uYWwgZGVzY3JpcHRpb25cXG5lbnRyeSksIHRoZW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiPERvY3NCeVRhZz5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGluIGZlZWQgb3IgZ3JpZCBzaGFwZSwgcGx1cyBhIFxcXCJyZWxhdGVkIHRhZ3NcXFwiIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjxUYWdMaXN0PlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuXFxuRW1wdHkgc3RhdGUgZm9yIGEgdGFnIHdpdGggbm8gZW50cmllcy5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic3RhdGVzLWNvcHlcIj48SGVhZGluZ0FuY2hvciBpZD1cInN0YXRlcy1jb3B5XCIgLz57XCJTdGF0ZXMgJiBjb3B5XCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJQZXIgc3VyZmFjZTogcG9wdWxhdGVkLCBlbXB0eSAoZWFjaCBjb21wb25lbnQncyBcXFwibm90aGluZyBoZXJlXFxcIiBsaW5lIOKAlCBtYWtlIHRoZW0gc3BlY2lmaWM6XFxuXFxcIk5vIGVudHJpZXMgdGFnZ2VkIFwifTxfY29tcG9uZW50cy5jb2RlPntcIiNzb25nXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB5ZXQuXFxcIiwgXFxcIk5vdGhpbmcgbGlua3MgaGVyZSB5ZXQuXFxcIiksIGxvYWRpbmcgc2tlbGV0b25zLiBEcmFmdCB0aGVcXG5pbmRleC9zZWN0aW9uIGhlYWRlcnMgYW5kIHRoZSBjb3VudCBzdHJpbmdzIChtb25vKS4gU2VudGVuY2UgY2FzZSwgcGVyaW9kLXRlcm1pbmF0ZWQuXCJ9PC9fY29tcG9uZW50cy5wPjwvPjtcbn1cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE1EWENvbnRlbnQocHJvcHMgPSB7fSkge1xuICBjb25zdCB7d3JhcHBlcjogTURYTGF5b3V0fSA9IHtcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH07XG4gIHJldHVybiBNRFhMYXlvdXQgPyA8TURYTGF5b3V0IHsuLi5wcm9wc30+PF9jcmVhdGVNZHhDb250ZW50IHsuLi5wcm9wc30gLz48L01EWExheW91dD4gOiBfY3JlYXRlTWR4Q29udGVudChwcm9wcyk7XG59XG5mdW5jdGlvbiBfbWlzc2luZ01keFJlZmVyZW5jZShpZCwgY29tcG9uZW50LCBwbGFjZSkge1xuICB0aHJvdyBuZXcgRXJyb3IoXCJFeHBlY3RlZCBcIiArIChjb21wb25lbnQgPyBcImNvbXBvbmVudFwiIDogXCJvYmplY3RcIikgKyBcIiBgXCIgKyBpZCArIFwiYCB0byBiZSBkZWZpbmVkOiB5b3UgbGlrZWx5IGZvcmdvdCB0byBpbXBvcnQsIHBhc3MsIG9yIHByb3ZpZGUgaXQuXCIgKyAocGxhY2UgPyBcIlxcbkl04oCZcyByZWZlcmVuY2VkIGluIHlvdXIgY29kZSBhdCBgXCIgKyBwbGFjZSArIFwiYCBpbiBgL2FwcC9kb2NzL2Rlc2lnbi1icmllZnMvZ3JvdmUvYnJpZWZzLzAzLWluZGV4ZXMtYW5kLWNvbXBvbmVudC1saWJyYXJ5Lm1kYFwiIDogXCJcIikpO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFFQSxJQUFBQSxZQUFBLEdBQUFDLE9BQUE7QUFBd0YsSUFBQUMsV0FBQSxHQUFBRCxPQUFBO0FBRnhGO0FBQ0E7O0FBRUEsU0FBU0UsaUJBQWlCQSxDQUFDQyxLQUFLLEVBQUU7RUFDaEMsTUFBTUMsV0FBVyxHQUFHO01BQ2xCQyxDQUFDLEVBQUUsR0FBRztNQUNOQyxJQUFJLEVBQUUsTUFBTTtNQUNaQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxDQUFDLEVBQUUsR0FBRztNQUNOQyxNQUFNLEVBQUUsUUFBUTtNQUNoQkMsS0FBSyxFQUFFLE9BQU87TUFDZEMsS0FBSyxFQUFFLE9BQU87TUFDZEMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsS0FBSyxFQUFFLE9BQU87TUFDZEMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUixHQUFHLElBQUFDLDZCQUFrQixFQUFDLENBQUM7TUFDdkIsR0FBR2pCLEtBQUssQ0FBQ2tCO0lBQ1gsQ0FBQztJQUFFO01BQUNDO0lBQWEsQ0FBQyxHQUFHbEIsV0FBVztFQUNoQyxJQUFJLENBQUNrQixhQUFhLEVBQUVDLG9CQUFvQixDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUM7RUFDL0Qsb0JBQU8sSUFBQXRCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQXZCLFdBQUEsQ0FBQXdCLFFBQUE7SUFBQUMsUUFBQSxnQkFBRSxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDSSxFQUFFO01BQUNtQixFQUFFLEVBQUMscURBQXFEO01BQUFELFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBcUQsQ0FBRSxDQUFDLEVBQUMsdURBQXVEO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDTyxDQUFDO01BQUFlLFFBQUEsR0FBRSx1RkFBdUYsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxDQUFDO1FBQUN3QixJQUFJLEVBQUMsb0JBQW9CO1FBQUFILFFBQUEsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFvQixRQUFBLEVBQUU7UUFBZSxDQUFtQjtNQUFDLENBQWUsQ0FBQyxFQUFDLFlBQVksZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFvQixRQUFBLEVBQUU7TUFBVSxDQUFtQixDQUFDLEVBQUMsaURBQWlEO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDSyxFQUFFO01BQUNrQixFQUFFLEVBQUMsZ0JBQWdCO01BQUFELFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBZ0IsQ0FBRSxDQUFDLEVBQUMsa0JBQWtCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDTyxDQUFDO01BQUFlLFFBQUEsR0FBRSw2REFBNkQsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFvQixRQUFBLEVBQUU7TUFBVyxDQUFtQixDQUFDLEVBQUMsbUdBQW1HLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBbUIsQ0FBcUIsQ0FBQyxFQUFDLGdHQUFnRztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ2UsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNNLEVBQUU7UUFBQWdCLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBWSxDQUFxQixDQUFDLEVBQUMsaUpBQWlKO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDTSxFQUFFO1FBQUFnQixRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNRLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQVksQ0FBcUIsQ0FBQyxFQUFDLFdBQVcsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDUSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFPLENBQXFCLENBQUMsRUFBQyxpREFBaUQsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFvQixRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsb0xBQW9MO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNPLENBQUM7TUFBQWUsUUFBQSxHQUFFLGlCQUFpQixlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNRLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVMsQ0FBcUIsQ0FBQyxFQUFDLDBCQUEwQixlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNRLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQU8sQ0FBcUIsQ0FBQyxFQUFDLHlFQUF5RTtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDa0IsRUFBRSxFQUFDLDJEQUEyRDtNQUFBRCxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQTJELENBQUUsQ0FBQyxFQUFDLDhEQUE4RDtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ08sQ0FBQztNQUFBZSxRQUFBLEdBQUUscURBQXFELGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBb0IsUUFBQSxFQUFFO01BQVUsQ0FBbUIsQ0FBQyxFQUFDLGlDQUFpQyxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNRLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVcsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDUSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFPLENBQXFCLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBUyxDQUFxQixDQUFDLEVBQUMsc0JBQXNCO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDUyxLQUFLO01BQUFhLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2EsS0FBSztRQUFBUyxRQUFBLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ2MsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNZLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQVcsQ0FBaUIsQ0FBQyxtQkFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBTyxDQUFpQixDQUFDLG1CQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDWSxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFhLENBQWlCLENBQUM7UUFBQSxDQUFnQjtNQUFDLENBQW1CLENBQUMsbUJBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNVLEtBQUs7UUFBQVksUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDYyxFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1csRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBb0IsUUFBQSxFQUFFO1lBQTZCLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1csRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBb0IsUUFBQSxFQUFFO1lBQWdCLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1csRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBZ0csQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNjLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDVyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRSxJQUFJO2NBQUFvQixRQUFBLEVBQUU7WUFBaUIsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDVyxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBb0IsUUFBQSxFQUFFO1lBQWdCLENBQW1CLENBQUMsRUFBQyxhQUFhO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1csRUFBRTtZQUFBVyxRQUFBLEdBQUUseUVBQXlFLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBb0IsUUFBQSxFQUFFO1lBQU0sQ0FBbUIsQ0FBQyxFQUFDLFVBQVU7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ2MsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNXLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNFLElBQUk7Y0FBQW9CLFFBQUEsRUFBRTtZQUFhLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1csRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBb0IsUUFBQSxFQUFFO1lBQWtCLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1csRUFBRTtZQUFBVyxRQUFBLEdBQUUsdUJBQXVCLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBb0IsUUFBQSxFQUFFO1lBQUcsQ0FBbUIsQ0FBQyxFQUFDLGdGQUFnRjtVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDYyxFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1csRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNFLElBQUk7Y0FBQW9CLFFBQUEsRUFBRTtZQUFZLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBb0IsUUFBQSxFQUFFO1lBQVcsQ0FBbUIsQ0FBQztVQUFBLENBQWdCLENBQUMsbUJBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNXLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNFLElBQUk7Y0FBQW9CLFFBQUEsRUFBRTtZQUFpQixDQUFtQjtVQUFDLENBQWdCLENBQUMsbUJBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNXLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQStGLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDYyxFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1csRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBb0IsUUFBQSxFQUFFO1lBQWMsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDVyxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBb0IsUUFBQSxFQUFFO1lBQWdCLENBQW1CLENBQUMsRUFBQyxXQUFXO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1csRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBbUQsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNjLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDVyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRSxJQUFJO2NBQUFvQixRQUFBLEVBQUU7WUFBTyxDQUFtQjtVQUFDLENBQWdCLENBQUMsbUJBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNXLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNFLElBQUk7Y0FBQW9CLFFBQUEsRUFBRTtZQUFZLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1csRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBNkMsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNjLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDVyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRSxJQUFJO2NBQUFvQixRQUFBLEVBQUU7WUFBeUIsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDVyxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBb0IsUUFBQSxFQUFFO1lBQWdCLENBQW1CLENBQUMsRUFBQyxnQkFBZ0I7VUFBQSxDQUFpQixDQUFDLG1CQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDVyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFnQyxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ2MsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNXLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNFLElBQUk7Y0FBQW9CLFFBQUEsRUFBRTtZQUFZLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1csRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBb0IsUUFBQSxFQUFFO1lBQWlCLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1csRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBdUYsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUM7TUFBQSxDQUFtQixDQUFDO0lBQUEsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDTyxDQUFDO01BQUFlLFFBQUEsR0FBRSxtQ0FBbUMsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDUSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFxQixDQUFxQixDQUFDLEVBQUMsK0RBQStELGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBaUIsQ0FBcUIsQ0FBQyxFQUFDLHdCQUF3QjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDa0IsRUFBRSxFQUFDLGtDQUFrQztNQUFBRCxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQWtDLENBQUUsQ0FBQyxFQUFDLHFCQUFxQixlQUFDLElBQUExQixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNFLElBQUk7UUFBQW9CLFFBQUEsRUFBRTtNQUFXLENBQW1CLENBQUMsRUFBQyxVQUFVO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDTyxDQUFDO01BQUFlLFFBQUEsR0FBRSwrQ0FBK0MsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDUSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFZLENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBb0IsUUFBQSxFQUFFO01BQVUsQ0FBbUIsQ0FBQyxFQUFDLHlDQUF5QyxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNRLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQW1CLENBQXFCLENBQUMsRUFBQyxvREFBb0QsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDUSxNQUFNO1FBQUFjLFFBQUEsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFvQixRQUFBLEVBQUU7UUFBVyxDQUFtQjtNQUFDLENBQW9CLENBQUMsRUFBQyxzREFBc0Q7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNlLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDTSxFQUFFO1FBQUFnQixRQUFBLEdBQUUsMkRBQTJELGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBb0IsUUFBQSxFQUFFO1FBQVEsQ0FBbUIsQ0FBQyxFQUFDLGlEQUFpRCxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNFLElBQUk7VUFBQW9CLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQywyRkFBMkYsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFvQixRQUFBLEVBQUU7UUFBTyxDQUFtQixDQUFDLEVBQUMsbUNBQW1DLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBb0IsUUFBQSxFQUFFO1FBQU8sQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFvQixRQUFBLEVBQUU7UUFBTyxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNFLElBQUk7VUFBQW9CLFFBQUEsRUFBRTtRQUFPLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBb0IsUUFBQSxFQUFFO1FBQVUsQ0FBbUIsQ0FBQyxFQUFDLG9DQUFvQztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ00sRUFBRTtRQUFBZ0IsUUFBQSxHQUFFLFVBQVUsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDUSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFhLENBQXFCLENBQUMsRUFBQyw4Q0FBOEMsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRyxFQUFFO1VBQUFtQixRQUFBLEVBQUU7UUFBbUIsQ0FBaUIsQ0FBQyxFQUFDLDhCQUE4QixlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNFLElBQUk7VUFBQW9CLFFBQUEsRUFBRTtRQUFTLENBQW1CLENBQUMsRUFBQyw4Q0FBOEM7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDa0IsRUFBRSxFQUFDLFdBQVc7TUFBQUQsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFXLENBQUUsQ0FBQyxFQUFDLFdBQVc7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNPLENBQUM7TUFBQWUsUUFBQSxHQUFFLGtDQUFrQyxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNFLElBQUk7UUFBQW9CLFFBQUEsRUFBRTtNQUFRLENBQW1CLENBQUMsRUFBQyxnQkFBZ0IsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFvQixRQUFBLEVBQUU7TUFBTSxDQUFtQixDQUFDLEVBQUMsOENBQThDLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBb0IsUUFBQSxFQUFFO01BQWEsQ0FBbUIsQ0FBQyxFQUFDLGtEQUFrRCxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNFLElBQUk7UUFBQW9CLFFBQUEsRUFBRTtNQUFXLENBQW1CLENBQUMsRUFBQywyQ0FBMkM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNLLEVBQUU7TUFBQ2tCLEVBQUUsRUFBQyxhQUFhO01BQUFELFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBYSxDQUFFLENBQUMsRUFBQyxlQUFlO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDTyxDQUFDO01BQUFlLFFBQUEsR0FBRSxtSEFBbUgsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFvQixRQUFBLEVBQUU7TUFBTyxDQUFtQixDQUFDLEVBQUMsNEpBQTRKO0lBQUEsQ0FBZ0IsQ0FBQztFQUFBLENBQUUsQ0FBQztBQUM3bFI7QUFDZSxTQUFTSSxVQUFVQSxDQUFDM0IsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFO0VBQzdDLE1BQU07SUFBQzRCLE9BQU8sRUFBRUM7RUFBUyxDQUFDLEdBQUc7SUFDM0IsR0FBRyxJQUFBWiw2QkFBa0IsRUFBQyxDQUFDO0lBQ3ZCLEdBQUdqQixLQUFLLENBQUNrQjtFQUNYLENBQUM7RUFDRCxPQUFPVyxTQUFTLGdCQUFHLElBQUEvQixXQUFBLENBQUEyQixHQUFBLEVBQUNJLFNBQVM7SUFBQSxHQUFLN0IsS0FBSztJQUFBdUIsUUFBQSxlQUFFLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUMxQixpQkFBaUI7TUFBQSxHQUFLQztJQUFLLENBQUc7RUFBQyxDQUFXLENBQUMsR0FBR0QsaUJBQWlCLENBQUNDLEtBQUssQ0FBQztBQUNsSDtBQUFDOEIsRUFBQSxHQU51QkgsVUFBVTtBQU9sQyxTQUFTUCxvQkFBb0JBLENBQUNJLEVBQUUsRUFBRU8sU0FBUyxFQUFFQyxLQUFLLEVBQUU7RUFDbEQsTUFBTSxJQUFJQyxLQUFLLENBQUMsV0FBVyxJQUFJRixTQUFTLEdBQUcsV0FBVyxHQUFHLFFBQVEsQ0FBQyxHQUFHLElBQUksR0FBR1AsRUFBRSxHQUFHLG9FQUFvRSxJQUFJUSxLQUFLLEdBQUcscUNBQXFDLEdBQUdBLEtBQUssR0FBRyxpRkFBaUYsR0FBRyxFQUFFLENBQUMsQ0FBQztBQUMzUztBQUFDLElBQUFGLEVBQUE7QUFBQUksWUFBQSxDQUFBSixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}