var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      li: "li",
      ol: "ol",
      p: "p",
      strong: "strong",
      table: "table",
      tbody: "tbody",
      td: "td",
      th: "th",
      thead: "thead",
      tr: "tr",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "brief-00-grove-foundation-read-first",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "brief-00-grove-foundation-read-first"
      }), "Brief 00 — Grove foundation (read first)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "For:"
      }), " whoever designs/builds Grove. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Read with:"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "../HANDOFF.md",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "../HANDOFF.md"
        })
      }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "docs/product-defs/grove.md"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/index.css"
      }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "CLAUDE.md"
      }), " \"Design system\". Every other Grove brief assumes this foundation and only\nnotes its deviations."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "inherit-dont-invent",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "inherit-dont-invent"
      }), "Inherit, don't invent"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The default Grove theme ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "is"
      }), " the immediately.run brand applied to a reading surface. All\nfoundations from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "CLAUDE.md"
      }), " \"Design system\" hold verbatim: near-black ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "--bg"
      }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "#0a0b11"
      }), ")\ndark default + lilac-white light (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "data-theme=\"light\""
      }), "); the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "--grad"
      }), " magenta↔violet\nsignature gradient (text-clip on display headlines + big numerals, fill on the app mark\nand primary buttons, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "never"
      }), " behind body text); Gabarito 800 display / Public Sans body /\nSpace Mono details; translucent violet hairlines define surfaces; the hard-offset\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "6px 6px 0 var(--accent-2)"
      }), " hover shadow; pills for buttons; the radii ladder\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "--r-xs"
      }), "…", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "--r-pill"
      }), "); the two faint radial page washes; Lucide + the unicode micro-set;\nrestrained ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: ".14s"
      }), " motion. Don't restate these per surface — design to them."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "whats-grove-specific-the-small-delta-to-add",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "whats-grove-specific-the-small-delta-to-add"
      }), "What's Grove-specific (the small delta to add)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "Reading typography is the centrepiece."
          }), " The marketing site shouts in display type;\nGrove mostly renders ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "long-form MDX prose"
          }), ", so the body reading column is where the\ncraft goes. Define a measured prose scale (≈", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "--body"
          }), " 16px/1.5, max measure ~68–72ch,\ngenerous heading rhythm in Gabarito, Space Mono for inline ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "code"
          }), "/fenced blocks using\nthe editor syntax tokens). This is the one place the brand's \"fashion-poster display\ntype\" yields to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "legibility"
          }), ". Headlines (entry titles, section heads) still end on a\nperiod and may take the gradient clip; running prose never does."]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "The link-graph motif — Grove's flavour of the placeholder texture."
          }), " The brand's\nrecurring \"art\" is the 45° hairline stripe. Grove adds a sibling motif that ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "means"
          }), "\nsomething here: a sparse ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "node-and-edge lattice"
          }), " (small ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "--ink-3"
          }), " dots joined by\nhairline ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "--line"
          }), " edges) evoking the interlinked entries / knowledge graph. Use it for\nempty-state art, the app-icon glyph, and saturated tiles (with a radial accent bloom\nover it, like the stripe tiles). It is abstract and geometric — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "no literal trees,\nleaves, or photography"
          }), " (the \"grove/garden\" is a metaphor, not an illustration)."]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "Wiki-link styling — a first-class type treatment."
          }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "[[wiki-links]]"
          }), " need three\nvisible states (this is load-bearing for a wiki, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "grove.md"
          }), " \"Wiki-links\"):"]
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
          children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "resolved"
            }), " — accent-tinted link, subtle underline-on-hover, no icon clutter;"]
          }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "broken/ambiguous"
            }), " — dimmed to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "--ink-3"
            }), " with a hairline dotted underline and a\nsmall Lucide ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "unlink"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "alert"
            }), " cue; never red-error-loud, but unmistakably \"dead\";"]
          }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "current entry / self"
            }), " — non-interactive, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "--ink"
            }), " weight.\nMarkdown links and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "[[wiki-links]]"
            }), " should be visually distinguishable at a glance."]
          }), "\n"]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "Tag chips."
          }), " Tags are everywhere (frontmatter, tag pages, tag-driven UI). One chip\ncomponent: mono ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "#tag"
          }), ", hairline pill, faint fill on hover, accent border when active.\nReserved ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "ui/*"
          }), " tags are an authoring concept, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "not"
          }), " shown as content chips."]
        }), "\n"]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "the-agent-contract-groves-foundation-mostly-invisible",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-agent-contract-groves-foundation-mostly-invisible"
      }), "The agent contract — Grove's foundation, mostly invisible"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Grove's deepest property is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "agent legibility"
      }), ": each instance carries a self-describing\ncontract (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "grove.md"
      }), " \"The agent contract\") — a shipped engine reference, a generated\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: ".grove/manifest.json"
      }), ", and an authored ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "GROVE.md"
      }), " — so a future coding-agent session\nre-derives this wiki's conventions instead of guessing. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "You don't style these files"
      }), "\n(they're agent-facing), and the contract's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "validation/drift diagnostics surface through\nthe host edit experience, not Grove"
      }), " (don't draw a diagnostics panel — see ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "HANDOFF.md"
      }), "\nconstraint 1). Your job is the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "flip side"
      }), " of the same coin: the structure a reader sees\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "is"
      }), " the structure an agent reads, so making it legible is the design contribution.\nTouchpoints:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "In-content legibility"
        }), " — the wiki-link states above, tag chips, and the namespace\ntree (brief 02) carry the conventions visibly. Get these crisp and the wiki is legible\nto humans and agents alike."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The embedded Grove agent (brief 06)"
        }), " — the contract's working interface; it reads and\nupdates ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "GROVE.md"
        }), ". It ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "is"
        }), " a styled surface (Grove's own, not the host's), and most\nusers touch the contract through it."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["An optional ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "/about"
          }), " (colophon) entry"]
        }), " — a human-readable summary of the instance's\nconventions is just a normal MDX entry in the reading view; no special chrome, but a\ntasteful colophon pattern is a welcome example deliverable."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "the-class-name-token-contract-the-themeability-backbone",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-class-name-token-contract-the-themeability-backbone"
      }), "The class-name + token contract (the themeability backbone)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Grove's CSS-only theming promise (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "grove.md"
      }), " \"Theming & layout\") only works if you design\nto ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "stable, documented class names"
      }), " driven by tokens — never one-off styling. Treat this\nlist as the contract a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "THEMING.md"
      }), " will publish; name layers in your mockups accordingly:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Class"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Surface"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: ".grove-shell"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "the app frame (nav + sidebar + content + footer grid)"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: ".grove-nav"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: ".grove-sidebar"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: ".grove-footer"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "the tag-driven chrome regions"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: ".grove-content"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "the reading column wrapper"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: ".grove-page[data-layout=\"doc|post|full\"]"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["per-entry layout variant (from frontmatter ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "layout"
            }), ")"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: ".grove-entry-header"
            }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: ".grove-meta"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "title + frontmatter meta (date, tags)"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: ".grove-prose"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "the MDX-rendered body (all prose element styles scope under here)"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: ".grove-wikilink[data-state=\"ok|broken|self\"]"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "link states above"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: ".grove-doclist"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: ".grove-backlinks"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: ".grove-tagcloud"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: ".grove-toc"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: ".grove-pagemeta"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "built-in components (brief 03)"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: ".grove-tag"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "the tag chip"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: ".grove-edit-affordance"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "the host hand-off control (brief 02)"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: ".grove-agent"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: ".grove-agent-launcher"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: ".grove-agent-message"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: ".grove-agent-preview"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Grove's own embedded agent conversation (brief 06)"
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Layout shape is selected by ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "data-"
      }), " attributes on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: ".grove-shell"
      }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: ".grove-page"
      }), " (e.g.\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "data-nav=\"top\\|side\""
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "data-layout=\"…\""
      }), ") so re-laying-out is a CSS/data change, not a\ncomponent swap. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "No inline styles, no CSS-in-JS"
      }), " in anything you hand to a dev."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "the-grove-app-mark",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-grove-app-mark"
      }), "The Grove app mark"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Grove is an app within immediately.run, so it gets an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "app icon"
      }), " in the system idiom\n(like the runner mark, but Grove's): a rounded-square tile (~23% corner radius) filled\nwith the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "--grad"
      }), " magenta→violet gradient, bearing an abstract ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "node-and-edge glyph"
      }), "\n(2–4 nodes joined by edges — the link-graph motif, masked to white over the gradient).\nProvide: the full tile icon, a simplified tiny inline variant (a single rotated\ngradient square at ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "--r-xs"
      }), ", like the editor top-bar mark, for cramped chrome), and the\nwordmark ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "grove"
        })
      }), " set in Gabarito 800 lowercase. Keep it unmistakably part of the\nimmediately.run family — not a competing logo."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "voice-drafted-copy-must-match",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "voice-drafted-copy-must-match"
      }), "Voice (drafted copy must match)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Confident, plainspoken, sentence case; display headlines end on a hard period; numbers\nbrag in mono (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "142 entries"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "38 backlinks"
      }), "); one gradient marker-highlight per block,\nmax; no emoji, no exclamation points. Empty/error copy is helpful and intentional, never\ncute. Grove's own micro-labels wear mono ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "/slug"
      }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "#tag"
      }), " ornament like the rest of the\nbrand."]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/design-briefs/grove/briefs/00-foundation.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiY29kZSIsImVtIiwiaDEiLCJoMiIsImxpIiwib2wiLCJwIiwic3Ryb25nIiwidGFibGUiLCJ0Ym9keSIsInRkIiwidGgiLCJ0aGVhZCIsInRyIiwidWwiLCJfcHJvdmlkZUNvbXBvbmVudHMiLCJjb21wb25lbnRzIiwiSGVhZGluZ0FuY2hvciIsIl9taXNzaW5nTWR4UmVmZXJlbmNlIiwianN4cyIsIkZyYWdtZW50IiwiY2hpbGRyZW4iLCJpZCIsImpzeCIsImhyZWYiLCJNRFhDb250ZW50Iiwid3JhcHBlciIsIk1EWExheW91dCIsIl9jIiwiY29tcG9uZW50IiwicGxhY2UiLCJFcnJvciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIjAwLWZvdW5kYXRpb24ubWQiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgYTogXCJhXCIsXG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgZW06IFwiZW1cIixcbiAgICBoMTogXCJoMVwiLFxuICAgIGgyOiBcImgyXCIsXG4gICAgbGk6IFwibGlcIixcbiAgICBvbDogXCJvbFwiLFxuICAgIHA6IFwicFwiLFxuICAgIHN0cm9uZzogXCJzdHJvbmdcIixcbiAgICB0YWJsZTogXCJ0YWJsZVwiLFxuICAgIHRib2R5OiBcInRib2R5XCIsXG4gICAgdGQ6IFwidGRcIixcbiAgICB0aDogXCJ0aFwiLFxuICAgIHRoZWFkOiBcInRoZWFkXCIsXG4gICAgdHI6IFwidHJcIixcbiAgICB1bDogXCJ1bFwiLFxuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfSwge0hlYWRpbmdBbmNob3J9ID0gX2NvbXBvbmVudHM7XG4gIGlmICghSGVhZGluZ0FuY2hvcikgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJIZWFkaW5nQW5jaG9yXCIsIHRydWUpO1xuICByZXR1cm4gPD48X2NvbXBvbmVudHMuaDEgaWQ9XCJicmllZi0wMC1ncm92ZS1mb3VuZGF0aW9uLXJlYWQtZmlyc3RcIj48SGVhZGluZ0FuY2hvciBpZD1cImJyaWVmLTAwLWdyb3ZlLWZvdW5kYXRpb24tcmVhZC1maXJzdFwiIC8+e1wiQnJpZWYgMDAg4oCUIEdyb3ZlIGZvdW5kYXRpb24gKHJlYWQgZmlyc3QpXCJ9PC9fY29tcG9uZW50cy5oMT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkZvcjpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgd2hvZXZlciBkZXNpZ25zL2J1aWxkcyBHcm92ZS4gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJSZWFkIHdpdGg6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5hIGhyZWY9XCIuLi9IQU5ET0ZGLm1kXCI+PF9jb21wb25lbnRzLmNvZGU+e1wiLi4vSEFORE9GRi5tZFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLmE+e1wiLFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcImRvY3MvcHJvZHVjdC1kZWZzL2dyb3ZlLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2luZGV4LmNzc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQ0xBVURFLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBcXFwiRGVzaWduIHN5c3RlbVxcXCIuIEV2ZXJ5IG90aGVyIEdyb3ZlIGJyaWVmIGFzc3VtZXMgdGhpcyBmb3VuZGF0aW9uIGFuZCBvbmx5XFxubm90ZXMgaXRzIGRldmlhdGlvbnMuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cImluaGVyaXQtZG9udC1pbnZlbnRcIj48SGVhZGluZ0FuY2hvciBpZD1cImluaGVyaXQtZG9udC1pbnZlbnRcIiAvPntcIkluaGVyaXQsIGRvbid0IGludmVudFwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIGRlZmF1bHQgR3JvdmUgdGhlbWUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJpc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB0aGUgaW1tZWRpYXRlbHkucnVuIGJyYW5kIGFwcGxpZWQgdG8gYSByZWFkaW5nIHN1cmZhY2UuIEFsbFxcbmZvdW5kYXRpb25zIGZyb20gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQ0xBVURFLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBcXFwiRGVzaWduIHN5c3RlbVxcXCIgaG9sZCB2ZXJiYXRpbTogbmVhci1ibGFjayBcIn08X2NvbXBvbmVudHMuY29kZT57XCItLWJnXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiIzBhMGIxMVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpXFxuZGFyayBkZWZhdWx0ICsgbGlsYWMtd2hpdGUgbGlnaHQgKFwifTxfY29tcG9uZW50cy5jb2RlPntcImRhdGEtdGhlbWU9XFxcImxpZ2h0XFxcIlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpOyB0aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1ncmFkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBtYWdlbnRh4oaUdmlvbGV0XFxuc2lnbmF0dXJlIGdyYWRpZW50ICh0ZXh0LWNsaXAgb24gZGlzcGxheSBoZWFkbGluZXMgKyBiaWcgbnVtZXJhbHMsIGZpbGwgb24gdGhlIGFwcCBtYXJrXFxuYW5kIHByaW1hcnkgYnV0dG9ucywgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJuZXZlclwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBiZWhpbmQgYm9keSB0ZXh0KTsgR2FiYXJpdG8gODAwIGRpc3BsYXkgLyBQdWJsaWMgU2FucyBib2R5IC9cXG5TcGFjZSBNb25vIGRldGFpbHM7IHRyYW5zbHVjZW50IHZpb2xldCBoYWlybGluZXMgZGVmaW5lIHN1cmZhY2VzOyB0aGUgaGFyZC1vZmZzZXRcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCI2cHggNnB4IDAgdmFyKC0tYWNjZW50LTIpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBob3ZlciBzaGFkb3c7IHBpbGxzIGZvciBidXR0b25zOyB0aGUgcmFkaWkgbGFkZGVyXFxuKFwifTxfY29tcG9uZW50cy5jb2RlPntcIi0tci14c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCLigKZcIn08X2NvbXBvbmVudHMuY29kZT57XCItLXItcGlsbFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpOyB0aGUgdHdvIGZhaW50IHJhZGlhbCBwYWdlIHdhc2hlczsgTHVjaWRlICsgdGhlIHVuaWNvZGUgbWljcm8tc2V0O1xcbnJlc3RyYWluZWQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLjE0c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgbW90aW9uLiBEb24ndCByZXN0YXRlIHRoZXNlIHBlciBzdXJmYWNlIOKAlCBkZXNpZ24gdG8gdGhlbS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwid2hhdHMtZ3JvdmUtc3BlY2lmaWMtdGhlLXNtYWxsLWRlbHRhLXRvLWFkZFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwid2hhdHMtZ3JvdmUtc3BlY2lmaWMtdGhlLXNtYWxsLWRlbHRhLXRvLWFkZFwiIC8+e1wiV2hhdCdzIEdyb3ZlLXNwZWNpZmljICh0aGUgc21hbGwgZGVsdGEgdG8gYWRkKVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlJlYWRpbmcgdHlwb2dyYXBoeSBpcyB0aGUgY2VudHJlcGllY2UuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRoZSBtYXJrZXRpbmcgc2l0ZSBzaG91dHMgaW4gZGlzcGxheSB0eXBlO1xcbkdyb3ZlIG1vc3RseSByZW5kZXJzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibG9uZy1mb3JtIE1EWCBwcm9zZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgc28gdGhlIGJvZHkgcmVhZGluZyBjb2x1bW4gaXMgd2hlcmUgdGhlXFxuY3JhZnQgZ29lcy4gRGVmaW5lIGEgbWVhc3VyZWQgcHJvc2Ugc2NhbGUgKOKJiFwifTxfY29tcG9uZW50cy5jb2RlPntcIi0tYm9keVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgMTZweC8xLjUsIG1heCBtZWFzdXJlIH42OOKAkzcyY2gsXFxuZ2VuZXJvdXMgaGVhZGluZyByaHl0aG0gaW4gR2FiYXJpdG8sIFNwYWNlIE1vbm8gZm9yIGlubGluZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjb2RlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9mZW5jZWQgYmxvY2tzIHVzaW5nXFxudGhlIGVkaXRvciBzeW50YXggdG9rZW5zKS4gVGhpcyBpcyB0aGUgb25lIHBsYWNlIHRoZSBicmFuZCdzIFxcXCJmYXNoaW9uLXBvc3RlciBkaXNwbGF5XFxudHlwZVxcXCIgeWllbGRzIHRvIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibGVnaWJpbGl0eVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIi4gSGVhZGxpbmVzIChlbnRyeSB0aXRsZXMsIHNlY3Rpb24gaGVhZHMpIHN0aWxsIGVuZCBvbiBhXFxucGVyaW9kIGFuZCBtYXkgdGFrZSB0aGUgZ3JhZGllbnQgY2xpcDsgcnVubmluZyBwcm9zZSBuZXZlciBkb2VzLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlRoZSBsaW5rLWdyYXBoIG1vdGlmIOKAlCBHcm92ZSdzIGZsYXZvdXIgb2YgdGhlIHBsYWNlaG9sZGVyIHRleHR1cmUuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRoZSBicmFuZCdzXFxucmVjdXJyaW5nIFxcXCJhcnRcXFwiIGlzIHRoZSA0NcKwIGhhaXJsaW5lIHN0cmlwZS4gR3JvdmUgYWRkcyBhIHNpYmxpbmcgbW90aWYgdGhhdCBcIn08X2NvbXBvbmVudHMuZW0+e1wibWVhbnNcIn08L19jb21wb25lbnRzLmVtPntcIlxcbnNvbWV0aGluZyBoZXJlOiBhIHNwYXJzZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vZGUtYW5kLWVkZ2UgbGF0dGljZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoc21hbGwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1pbmstM1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZG90cyBqb2luZWQgYnlcXG5oYWlybGluZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCItLWxpbmVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGVkZ2VzKSBldm9raW5nIHRoZSBpbnRlcmxpbmtlZCBlbnRyaWVzIC8ga25vd2xlZGdlIGdyYXBoLiBVc2UgaXQgZm9yXFxuZW1wdHktc3RhdGUgYXJ0LCB0aGUgYXBwLWljb24gZ2x5cGgsIGFuZCBzYXR1cmF0ZWQgdGlsZXMgKHdpdGggYSByYWRpYWwgYWNjZW50IGJsb29tXFxub3ZlciBpdCwgbGlrZSB0aGUgc3RyaXBlIHRpbGVzKS4gSXQgaXMgYWJzdHJhY3QgYW5kIGdlb21ldHJpYyDigJQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJubyBsaXRlcmFsIHRyZWVzLFxcbmxlYXZlcywgb3IgcGhvdG9ncmFwaHlcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHRoZSBcXFwiZ3JvdmUvZ2FyZGVuXFxcIiBpcyBhIG1ldGFwaG9yLCBub3QgYW4gaWxsdXN0cmF0aW9uKS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJXaWtpLWxpbmsgc3R5bGluZyDigJQgYSBmaXJzdC1jbGFzcyB0eXBlIHRyZWF0bWVudC5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiW1t3aWtpLWxpbmtzXV1cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG5lZWQgdGhyZWVcXG52aXNpYmxlIHN0YXRlcyAodGhpcyBpcyBsb2FkLWJlYXJpbmcgZm9yIGEgd2lraSwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZ3JvdmUubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIFxcXCJXaWtpLWxpbmtzXFxcIik6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJyZXNvbHZlZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgYWNjZW50LXRpbnRlZCBsaW5rLCBzdWJ0bGUgdW5kZXJsaW5lLW9uLWhvdmVyLCBubyBpY29uIGNsdXR0ZXI7XCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJicm9rZW4vYW1iaWd1b3VzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBkaW1tZWQgdG8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1pbmstM1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgd2l0aCBhIGhhaXJsaW5lIGRvdHRlZCB1bmRlcmxpbmUgYW5kIGFcXG5zbWFsbCBMdWNpZGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widW5saW5rXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJhbGVydFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgY3VlOyBuZXZlciByZWQtZXJyb3ItbG91ZCwgYnV0IHVubWlzdGFrYWJseSBcXFwiZGVhZFxcXCI7XCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJjdXJyZW50IGVudHJ5IC8gc2VsZlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgbm9uLWludGVyYWN0aXZlLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCItLWlua1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgd2VpZ2h0Llxcbk1hcmtkb3duIGxpbmtzIGFuZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJbW3dpa2ktbGlua3NdXVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgc2hvdWxkIGJlIHZpc3VhbGx5IGRpc3Rpbmd1aXNoYWJsZSBhdCBhIGdsYW5jZS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUYWcgY2hpcHMuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRhZ3MgYXJlIGV2ZXJ5d2hlcmUgKGZyb250bWF0dGVyLCB0YWcgcGFnZXMsIHRhZy1kcml2ZW4gVUkpLiBPbmUgY2hpcFxcbmNvbXBvbmVudDogbW9ubyBcIn08X2NvbXBvbmVudHMuY29kZT57XCIjdGFnXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgaGFpcmxpbmUgcGlsbCwgZmFpbnQgZmlsbCBvbiBob3ZlciwgYWNjZW50IGJvcmRlciB3aGVuIGFjdGl2ZS5cXG5SZXNlcnZlZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ1aS8qXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB0YWdzIGFyZSBhbiBhdXRob3JpbmcgY29uY2VwdCwgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJub3RcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgc2hvd24gYXMgY29udGVudCBjaGlwcy5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInRoZS1hZ2VudC1jb250cmFjdC1ncm92ZXMtZm91bmRhdGlvbi1tb3N0bHktaW52aXNpYmxlXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJ0aGUtYWdlbnQtY29udHJhY3QtZ3JvdmVzLWZvdW5kYXRpb24tbW9zdGx5LWludmlzaWJsZVwiIC8+e1wiVGhlIGFnZW50IGNvbnRyYWN0IOKAlCBHcm92ZSdzIGZvdW5kYXRpb24sIG1vc3RseSBpbnZpc2libGVcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkdyb3ZlJ3MgZGVlcGVzdCBwcm9wZXJ0eSBpcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImFnZW50IGxlZ2liaWxpdHlcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCI6IGVhY2ggaW5zdGFuY2UgY2FycmllcyBhIHNlbGYtZGVzY3JpYmluZ1xcbmNvbnRyYWN0IChcIn08X2NvbXBvbmVudHMuY29kZT57XCJncm92ZS5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgXFxcIlRoZSBhZ2VudCBjb250cmFjdFxcXCIpIOKAlCBhIHNoaXBwZWQgZW5naW5lIHJlZmVyZW5jZSwgYSBnZW5lcmF0ZWRcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCIuZ3JvdmUvbWFuaWZlc3QuanNvblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGFuZCBhbiBhdXRob3JlZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJHUk9WRS5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIHNvIGEgZnV0dXJlIGNvZGluZy1hZ2VudCBzZXNzaW9uXFxucmUtZGVyaXZlcyB0aGlzIHdpa2kncyBjb252ZW50aW9ucyBpbnN0ZWFkIG9mIGd1ZXNzaW5nLiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIllvdSBkb24ndCBzdHlsZSB0aGVzZSBmaWxlc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIlxcbih0aGV5J3JlIGFnZW50LWZhY2luZyksIGFuZCB0aGUgY29udHJhY3QncyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInZhbGlkYXRpb24vZHJpZnQgZGlhZ25vc3RpY3Mgc3VyZmFjZSB0aHJvdWdoXFxudGhlIGhvc3QgZWRpdCBleHBlcmllbmNlLCBub3QgR3JvdmVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKGRvbid0IGRyYXcgYSBkaWFnbm9zdGljcyBwYW5lbCDigJQgc2VlIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkhBTkRPRkYubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxuY29uc3RyYWludCAxKS4gWW91ciBqb2IgaXMgdGhlIFwifTxfY29tcG9uZW50cy5lbT57XCJmbGlwIHNpZGVcIn08L19jb21wb25lbnRzLmVtPntcIiBvZiB0aGUgc2FtZSBjb2luOiB0aGUgc3RydWN0dXJlIGEgcmVhZGVyIHNlZXNcXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImlzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHRoZSBzdHJ1Y3R1cmUgYW4gYWdlbnQgcmVhZHMsIHNvIG1ha2luZyBpdCBsZWdpYmxlIGlzIHRoZSBkZXNpZ24gY29udHJpYnV0aW9uLlxcblRvdWNocG9pbnRzOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiSW4tY29udGVudCBsZWdpYmlsaXR5XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCB0aGUgd2lraS1saW5rIHN0YXRlcyBhYm92ZSwgdGFnIGNoaXBzLCBhbmQgdGhlIG5hbWVzcGFjZVxcbnRyZWUgKGJyaWVmIDAyKSBjYXJyeSB0aGUgY29udmVudGlvbnMgdmlzaWJseS4gR2V0IHRoZXNlIGNyaXNwIGFuZCB0aGUgd2lraSBpcyBsZWdpYmxlXFxudG8gaHVtYW5zIGFuZCBhZ2VudHMgYWxpa2UuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgZW1iZWRkZWQgR3JvdmUgYWdlbnQgKGJyaWVmIDA2KVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgdGhlIGNvbnRyYWN0J3Mgd29ya2luZyBpbnRlcmZhY2U7IGl0IHJlYWRzIGFuZFxcbnVwZGF0ZXMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiR1JPVkUubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLiBJdCBcIn08X2NvbXBvbmVudHMuZW0+e1wiaXNcIn08L19jb21wb25lbnRzLmVtPntcIiBhIHN0eWxlZCBzdXJmYWNlIChHcm92ZSdzIG93biwgbm90IHRoZSBob3N0J3MpLCBhbmQgbW9zdFxcbnVzZXJzIHRvdWNoIHRoZSBjb250cmFjdCB0aHJvdWdoIGl0LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQW4gb3B0aW9uYWwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiL2Fib3V0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoY29sb3Bob24pIGVudHJ5XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBhIGh1bWFuLXJlYWRhYmxlIHN1bW1hcnkgb2YgdGhlIGluc3RhbmNlJ3NcXG5jb252ZW50aW9ucyBpcyBqdXN0IGEgbm9ybWFsIE1EWCBlbnRyeSBpbiB0aGUgcmVhZGluZyB2aWV3OyBubyBzcGVjaWFsIGNocm9tZSwgYnV0IGFcXG50YXN0ZWZ1bCBjb2xvcGhvbiBwYXR0ZXJuIGlzIGEgd2VsY29tZSBleGFtcGxlIGRlbGl2ZXJhYmxlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJ0aGUtY2xhc3MtbmFtZS10b2tlbi1jb250cmFjdC10aGUtdGhlbWVhYmlsaXR5LWJhY2tib25lXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJ0aGUtY2xhc3MtbmFtZS10b2tlbi1jb250cmFjdC10aGUtdGhlbWVhYmlsaXR5LWJhY2tib25lXCIgLz57XCJUaGUgY2xhc3MtbmFtZSArIHRva2VuIGNvbnRyYWN0ICh0aGUgdGhlbWVhYmlsaXR5IGJhY2tib25lKVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiR3JvdmUncyBDU1Mtb25seSB0aGVtaW5nIHByb21pc2UgKFwifTxfY29tcG9uZW50cy5jb2RlPntcImdyb3ZlLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBcXFwiVGhlbWluZyAmIGxheW91dFxcXCIpIG9ubHkgd29ya3MgaWYgeW91IGRlc2lnblxcbnRvIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wic3RhYmxlLCBkb2N1bWVudGVkIGNsYXNzIG5hbWVzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGRyaXZlbiBieSB0b2tlbnMg4oCUIG5ldmVyIG9uZS1vZmYgc3R5bGluZy4gVHJlYXQgdGhpc1xcbmxpc3QgYXMgdGhlIGNvbnRyYWN0IGEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiVEhFTUlORy5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgd2lsbCBwdWJsaXNoOyBuYW1lIGxheWVycyBpbiB5b3VyIG1vY2t1cHMgYWNjb3JkaW5nbHk6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy50YWJsZT48X2NvbXBvbmVudHMudGhlYWQ+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50aD57XCJDbGFzc1wifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIlN1cmZhY2VcIn08L19jb21wb25lbnRzLnRoPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudGJvZHk+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCIuZ3JvdmUtc2hlbGxcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1widGhlIGFwcCBmcmFtZSAobmF2ICsgc2lkZWJhciArIGNvbnRlbnQgKyBmb290ZXIgZ3JpZClcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCIuZ3JvdmUtbmF2XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLmdyb3ZlLXNpZGViYXJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCIuZ3JvdmUtZm9vdGVyXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcInRoZSB0YWctZHJpdmVuIGNocm9tZSByZWdpb25zXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiLmdyb3ZlLWNvbnRlbnRcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1widGhlIHJlYWRpbmcgY29sdW1uIHdyYXBwZXJcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCIuZ3JvdmUtcGFnZVtkYXRhLWxheW91dD1cXFwiZG9jfHBvc3R8ZnVsbFxcXCJdXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcInBlci1lbnRyeSBsYXlvdXQgdmFyaWFudCAoZnJvbSBmcm9udG1hdHRlciBcIn08X2NvbXBvbmVudHMuY29kZT57XCJsYXlvdXRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcIi5ncm92ZS1lbnRyeS1oZWFkZXJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIC8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLmdyb3ZlLW1ldGFcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1widGl0bGUgKyBmcm9udG1hdHRlciBtZXRhIChkYXRlLCB0YWdzKVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcIi5ncm92ZS1wcm9zZVwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJ0aGUgTURYLXJlbmRlcmVkIGJvZHkgKGFsbCBwcm9zZSBlbGVtZW50IHN0eWxlcyBzY29wZSB1bmRlciBoZXJlKVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcIi5ncm92ZS13aWtpbGlua1tkYXRhLXN0YXRlPVxcXCJva3xicm9rZW58c2VsZlxcXCJdXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcImxpbmsgc3RhdGVzIGFib3ZlXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiLmdyb3ZlLWRvY2xpc3RcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCIuZ3JvdmUtYmFja2xpbmtzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLmdyb3ZlLXRhZ2Nsb3VkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLmdyb3ZlLXRvY1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi5ncm92ZS1wYWdlbWV0YVwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJidWlsdC1pbiBjb21wb25lbnRzIChicmllZiAwMylcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCIuZ3JvdmUtdGFnXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcInRoZSB0YWcgY2hpcFwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcIi5ncm92ZS1lZGl0LWFmZm9yZGFuY2VcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1widGhlIGhvc3QgaGFuZC1vZmYgY29udHJvbCAoYnJpZWYgMDIpXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiLmdyb3ZlLWFnZW50XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLmdyb3ZlLWFnZW50LWxhdW5jaGVyXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLmdyb3ZlLWFnZW50LW1lc3NhZ2VcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCIuZ3JvdmUtYWdlbnQtcHJldmlld1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJHcm92ZSdzIG93biBlbWJlZGRlZCBhZ2VudCBjb252ZXJzYXRpb24gKGJyaWVmIDA2KVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRib2R5PjwvX2NvbXBvbmVudHMudGFibGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiTGF5b3V0IHNoYXBlIGlzIHNlbGVjdGVkIGJ5IFwifTxfY29tcG9uZW50cy5jb2RlPntcImRhdGEtXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhdHRyaWJ1dGVzIG9uIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi5ncm92ZS1zaGVsbFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgLyBcIn08X2NvbXBvbmVudHMuY29kZT57XCIuZ3JvdmUtcGFnZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKGUuZy5cXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJkYXRhLW5hdj1cXFwidG9wXFxcXHxzaWRlXFxcIlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcImRhdGEtbGF5b3V0PVxcXCLigKZcXFwiXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikgc28gcmUtbGF5aW5nLW91dCBpcyBhIENTUy9kYXRhIGNoYW5nZSwgbm90IGFcXG5jb21wb25lbnQgc3dhcC4gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJObyBpbmxpbmUgc3R5bGVzLCBubyBDU1MtaW4tSlNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgaW4gYW55dGhpbmcgeW91IGhhbmQgdG8gYSBkZXYuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInRoZS1ncm92ZS1hcHAtbWFya1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwidGhlLWdyb3ZlLWFwcC1tYXJrXCIgLz57XCJUaGUgR3JvdmUgYXBwIG1hcmtcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkdyb3ZlIGlzIGFuIGFwcCB3aXRoaW4gaW1tZWRpYXRlbHkucnVuLCBzbyBpdCBnZXRzIGFuIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiYXBwIGljb25cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgaW4gdGhlIHN5c3RlbSBpZGlvbVxcbihsaWtlIHRoZSBydW5uZXIgbWFyaywgYnV0IEdyb3ZlJ3MpOiBhIHJvdW5kZWQtc3F1YXJlIHRpbGUgKH4yMyUgY29ybmVyIHJhZGl1cykgZmlsbGVkXFxud2l0aCB0aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1ncmFkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBtYWdlbnRh4oaSdmlvbGV0IGdyYWRpZW50LCBiZWFyaW5nIGFuIGFic3RyYWN0IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibm9kZS1hbmQtZWRnZSBnbHlwaFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIlxcbigy4oCTNCBub2RlcyBqb2luZWQgYnkgZWRnZXMg4oCUIHRoZSBsaW5rLWdyYXBoIG1vdGlmLCBtYXNrZWQgdG8gd2hpdGUgb3ZlciB0aGUgZ3JhZGllbnQpLlxcblByb3ZpZGU6IHRoZSBmdWxsIHRpbGUgaWNvbiwgYSBzaW1wbGlmaWVkIHRpbnkgaW5saW5lIHZhcmlhbnQgKGEgc2luZ2xlIHJvdGF0ZWRcXG5ncmFkaWVudCBzcXVhcmUgYXQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1yLXhzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgbGlrZSB0aGUgZWRpdG9yIHRvcC1iYXIgbWFyaywgZm9yIGNyYW1wZWQgY2hyb21lKSwgYW5kIHRoZVxcbndvcmRtYXJrIFwifTxfY29tcG9uZW50cy5zdHJvbmc+PF9jb21wb25lbnRzLmNvZGU+e1wiZ3JvdmVcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHNldCBpbiBHYWJhcml0byA4MDAgbG93ZXJjYXNlLiBLZWVwIGl0IHVubWlzdGFrYWJseSBwYXJ0IG9mIHRoZVxcbmltbWVkaWF0ZWx5LnJ1biBmYW1pbHkg4oCUIG5vdCBhIGNvbXBldGluZyBsb2dvLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJ2b2ljZS1kcmFmdGVkLWNvcHktbXVzdC1tYXRjaFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwidm9pY2UtZHJhZnRlZC1jb3B5LW11c3QtbWF0Y2hcIiAvPntcIlZvaWNlIChkcmFmdGVkIGNvcHkgbXVzdCBtYXRjaClcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkNvbmZpZGVudCwgcGxhaW5zcG9rZW4sIHNlbnRlbmNlIGNhc2U7IGRpc3BsYXkgaGVhZGxpbmVzIGVuZCBvbiBhIGhhcmQgcGVyaW9kOyBudW1iZXJzXFxuYnJhZyBpbiBtb25vIChcIn08X2NvbXBvbmVudHMuY29kZT57XCIxNDIgZW50cmllc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjM4IGJhY2tsaW5rc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpOyBvbmUgZ3JhZGllbnQgbWFya2VyLWhpZ2hsaWdodCBwZXIgYmxvY2ssXFxubWF4OyBubyBlbW9qaSwgbm8gZXhjbGFtYXRpb24gcG9pbnRzLiBFbXB0eS9lcnJvciBjb3B5IGlzIGhlbHBmdWwgYW5kIGludGVudGlvbmFsLCBuZXZlclxcbmN1dGUuIEdyb3ZlJ3Mgb3duIG1pY3JvLWxhYmVscyB3ZWFyIG1vbm8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiL3NsdWdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFuZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCIjdGFnXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBvcm5hbWVudCBsaWtlIHRoZSByZXN0IG9mIHRoZVxcbmJyYW5kLlwifTwvX2NvbXBvbmVudHMucD48Lz47XG59XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNRFhDb250ZW50KHByb3BzID0ge30pIHtcbiAgY29uc3Qge3dyYXBwZXI6IE1EWExheW91dH0gPSB7XG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9O1xuICByZXR1cm4gTURYTGF5b3V0ID8gPE1EWExheW91dCB7Li4ucHJvcHN9PjxfY3JlYXRlTWR4Q29udGVudCB7Li4ucHJvcHN9IC8+PC9NRFhMYXlvdXQ+IDogX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpO1xufVxuZnVuY3Rpb24gX21pc3NpbmdNZHhSZWZlcmVuY2UoaWQsIGNvbXBvbmVudCwgcGxhY2UpIHtcbiAgdGhyb3cgbmV3IEVycm9yKFwiRXhwZWN0ZWQgXCIgKyAoY29tcG9uZW50ID8gXCJjb21wb25lbnRcIiA6IFwib2JqZWN0XCIpICsgXCIgYFwiICsgaWQgKyBcImAgdG8gYmUgZGVmaW5lZDogeW91IGxpa2VseSBmb3Jnb3QgdG8gaW1wb3J0LCBwYXNzLCBvciBwcm92aWRlIGl0LlwiICsgKHBsYWNlID8gXCJcXG5JdOKAmXMgcmVmZXJlbmNlZCBpbiB5b3VyIGNvZGUgYXQgYFwiICsgcGxhY2UgKyBcImAgaW4gYC9hcHAvZG9jcy9kZXNpZ24tYnJpZWZzL2dyb3ZlL2JyaWVmcy8wMC1mb3VuZGF0aW9uLm1kYFwiIDogXCJcIikpO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFFQSxJQUFBQSxZQUFBLEdBQUFDLE9BQUE7QUFBd0YsSUFBQUMsV0FBQSxHQUFBRCxPQUFBO0FBRnhGO0FBQ0E7O0FBRUEsU0FBU0UsaUJBQWlCQSxDQUFDQyxLQUFLLEVBQUU7RUFDaEMsTUFBTUMsV0FBVyxHQUFHO01BQ2xCQyxDQUFDLEVBQUUsR0FBRztNQUNOQyxJQUFJLEVBQUUsTUFBTTtNQUNaQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxDQUFDLEVBQUUsR0FBRztNQUNOQyxNQUFNLEVBQUUsUUFBUTtNQUNoQkMsS0FBSyxFQUFFLE9BQU87TUFDZEMsS0FBSyxFQUFFLE9BQU87TUFDZEMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsS0FBSyxFQUFFLE9BQU87TUFDZEMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUixHQUFHLElBQUFDLDZCQUFrQixFQUFDLENBQUM7TUFDdkIsR0FBR2xCLEtBQUssQ0FBQ21CO0lBQ1gsQ0FBQztJQUFFO01BQUNDO0lBQWEsQ0FBQyxHQUFHbkIsV0FBVztFQUNoQyxJQUFJLENBQUNtQixhQUFhLEVBQUVDLG9CQUFvQixDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUM7RUFDL0Qsb0JBQU8sSUFBQXZCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQXhCLFdBQUEsQ0FBQXlCLFFBQUE7SUFBQUMsUUFBQSxnQkFBRSxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDSSxFQUFFO01BQUNvQixFQUFFLEVBQUMsc0NBQXNDO01BQUFELFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBc0MsQ0FBRSxDQUFDLEVBQUMsMENBQTBDO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDUSxDQUFDO01BQUFlLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBTSxDQUFxQixDQUFDLEVBQUMsaUNBQWlDLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBWSxDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNDLENBQUM7UUFBQ3lCLElBQUksRUFBQyxlQUFlO1FBQUFILFFBQUEsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBZSxDQUFtQjtNQUFDLENBQWUsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBNEIsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBZSxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFXLENBQW1CLENBQUMsRUFBQyxxR0FBcUc7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNLLEVBQUU7TUFBQ21CLEVBQUUsRUFBQyxxQkFBcUI7TUFBQUQsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFxQixDQUFFLENBQUMsRUFBQyx1QkFBdUI7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNRLENBQUM7TUFBQWUsUUFBQSxHQUFFLDBCQUEwQixlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQUksQ0FBcUIsQ0FBQyxFQUFDLGlGQUFpRixlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFXLENBQW1CLENBQUMsRUFBQywrQ0FBK0MsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBTSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFTLENBQW1CLENBQUMsRUFBQyx1Q0FBdUMsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBc0IsQ0FBbUIsQ0FBQyxFQUFDLFNBQVMsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBUSxDQUFtQixDQUFDLEVBQUMsaUlBQWlJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBTyxDQUFxQixDQUFDLEVBQUMsb0pBQW9KLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQTJCLENBQW1CLENBQUMsRUFBQyx1REFBdUQsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBUSxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFVLENBQW1CLENBQUMsRUFBQyxtRkFBbUYsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBTSxDQUFtQixDQUFDLEVBQUMsNERBQTREO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDSyxFQUFFO01BQUNtQixFQUFFLEVBQUMsNkNBQTZDO01BQUFELFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBNkMsQ0FBRSxDQUFDLEVBQUMsZ0RBQWdEO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDTyxFQUFFO01BQUFnQixRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNNLEVBQUU7UUFBQWlCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1EsQ0FBQztVQUFBZSxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07WUFBQWMsUUFBQSxFQUFFO1VBQXdDLENBQXFCLENBQUMsRUFBQyxvRUFBb0UsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1lBQUFjLFFBQUEsRUFBRTtVQUFxQixDQUFxQixDQUFDLEVBQUMseUZBQXlGLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBcUIsUUFBQSxFQUFFO1VBQVEsQ0FBbUIsQ0FBQyxFQUFDLCtGQUErRixlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7WUFBQXFCLFFBQUEsRUFBRTtVQUFNLENBQW1CLENBQUMsRUFBQyxnSUFBZ0ksZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1lBQUFjLFFBQUEsRUFBRTtVQUFZLENBQXFCLENBQUMsRUFBQyw0SEFBNEg7UUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ00sRUFBRTtRQUFBaUIsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDUSxDQUFDO1VBQUFlLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtZQUFBYyxRQUFBLEVBQUU7VUFBb0UsQ0FBcUIsQ0FBQyxFQUFDLDhGQUE4RixlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNHLEVBQUU7WUFBQW9CLFFBQUEsRUFBRTtVQUFPLENBQWlCLENBQUMsRUFBQyw2QkFBNkIsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1lBQUFjLFFBQUEsRUFBRTtVQUF1QixDQUFxQixDQUFDLEVBQUMsVUFBVSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7WUFBQXFCLFFBQUEsRUFBRTtVQUFTLENBQW1CLENBQUMsRUFBQyw0QkFBNEIsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1lBQUFxQixRQUFBLEVBQUU7VUFBUSxDQUFtQixDQUFDLEVBQUMsK05BQStOLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtZQUFBYyxRQUFBLEVBQUU7VUFBMkMsQ0FBcUIsQ0FBQyxFQUFDLDZEQUE2RDtRQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDTSxFQUFFO1FBQUFpQixRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNRLENBQUM7VUFBQWUsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1lBQUFjLFFBQUEsRUFBRTtVQUFtRCxDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7WUFBQXFCLFFBQUEsRUFBRTtVQUFnQixDQUFtQixDQUFDLEVBQUMsZ0VBQWdFLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBcUIsUUFBQSxFQUFFO1VBQVUsQ0FBbUIsQ0FBQyxFQUFDLG1CQUFtQjtRQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ2dCLEVBQUU7VUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDTSxFQUFFO1lBQUFpQixRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQVUsQ0FBcUIsQ0FBQyxFQUFDLG9FQUFvRTtVQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ00sRUFBRTtZQUFBaUIsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFrQixDQUFxQixDQUFDLEVBQUMsZUFBZSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUFTLENBQW1CLENBQUMsRUFBQyx3REFBd0QsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBUSxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUFPLENBQW1CLENBQUMsRUFBQyx3REFBd0Q7VUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNNLEVBQUU7WUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBc0IsQ0FBcUIsQ0FBQyxFQUFDLHNCQUFzQixlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUFPLENBQW1CLENBQUMsRUFBQywrQkFBK0IsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLGtEQUFrRDtVQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO1FBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNNLEVBQUU7UUFBQWlCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1EsQ0FBQztVQUFBZSxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07WUFBQWMsUUFBQSxFQUFFO1VBQVksQ0FBcUIsQ0FBQyxFQUFDLDBGQUEwRixlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7WUFBQXFCLFFBQUEsRUFBRTtVQUFNLENBQW1CLENBQUMsRUFBQyw2RUFBNkUsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1lBQUFxQixRQUFBLEVBQUU7VUFBTSxDQUFtQixDQUFDLEVBQUMsa0NBQWtDLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtZQUFBYyxRQUFBLEVBQUU7VUFBSyxDQUFxQixDQUFDLEVBQUMsMEJBQTBCO1FBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDbUIsRUFBRSxFQUFDLHVEQUF1RDtNQUFBRCxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQXVELENBQUUsQ0FBQyxFQUFDLDJEQUEyRDtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1EsQ0FBQztNQUFBZSxRQUFBLEdBQUUsOEJBQThCLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBa0IsQ0FBcUIsQ0FBQyxFQUFDLHVEQUF1RCxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFVLENBQW1CLENBQUMsRUFBQyxzRUFBc0UsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBc0IsQ0FBbUIsQ0FBQyxFQUFDLG9CQUFvQixlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFVLENBQW1CLENBQUMsRUFBQywrRkFBK0YsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUE2QixDQUFxQixDQUFDLEVBQUMsK0NBQStDLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBbUYsQ0FBcUIsQ0FBQyxFQUFDLHlDQUF5QyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFZLENBQW1CLENBQUMsRUFBQyxtQ0FBbUMsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRyxFQUFFO1FBQUFvQixRQUFBLEVBQUU7TUFBVyxDQUFpQixDQUFDLEVBQUMsa0RBQWtELGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBSSxDQUFxQixDQUFDLEVBQUMsK0ZBQStGO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDZ0IsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNNLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBdUIsQ0FBcUIsQ0FBQyxFQUFDLGtMQUFrTDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ00sRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFxQyxDQUFxQixDQUFDLEVBQUMsNkRBQTZELGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQVUsQ0FBbUIsQ0FBQyxFQUFDLE9BQU8sZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRyxFQUFFO1VBQUFvQixRQUFBLEVBQUU7UUFBSSxDQUFpQixDQUFDLEVBQUMsaUdBQWlHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDTSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNTLE1BQU07VUFBQWMsUUFBQSxHQUFFLGNBQWMsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1lBQUFxQixRQUFBLEVBQUU7VUFBUSxDQUFtQixDQUFDLEVBQUMsbUJBQW1CO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLGtNQUFrTTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDSyxFQUFFO01BQUNtQixFQUFFLEVBQUMseURBQXlEO01BQUFELFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBeUQsQ0FBRSxDQUFDLEVBQUMsNkRBQTZEO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDUSxDQUFDO01BQUFlLFFBQUEsR0FBRSxvQ0FBb0MsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBVSxDQUFtQixDQUFDLEVBQUMsc0RBQXNELGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBZ0MsQ0FBcUIsQ0FBQyxFQUFDLGdGQUFnRixlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFZLENBQW1CLENBQUMsRUFBQyx5REFBeUQ7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNVLEtBQUs7TUFBQWEsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDYyxLQUFLO1FBQUFTLFFBQUEsZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDZSxFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBTyxDQUFpQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDYSxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFTLENBQWlCLENBQUM7UUFBQSxDQUFnQjtNQUFDLENBQW1CLENBQUMsbUJBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNXLEtBQUs7UUFBQVksUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDZSxFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQWMsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUF1RCxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ2UsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBWSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUFnQixDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUFlLENBQW1CLENBQUM7VUFBQSxDQUFnQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUErQixDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ2UsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUFnQixDQUFtQjtVQUFDLENBQWdCLENBQUMsbUJBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQTRCLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDZSxFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQTRDLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLEdBQUUsNkNBQTZDLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQVEsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ2UsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBcUIsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBYSxDQUFtQixDQUFDO1VBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBdUMsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNlLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBYyxDQUFtQjtVQUFDLENBQWdCLENBQUMsbUJBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQW1FLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDZSxFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQWdELENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBbUIsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNlLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQWdCLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQWtCLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQWlCLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQVksQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBaUIsQ0FBbUIsQ0FBQztVQUFBLENBQWdCLENBQUMsbUJBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQWdDLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDZSxFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQVksQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFjLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDZSxFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQXdCLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBc0MsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNlLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQWMsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBdUIsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBc0IsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBc0IsQ0FBbUIsQ0FBQztVQUFBLENBQWdCLENBQUMsbUJBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQW9ELENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDO01BQUEsQ0FBbUIsQ0FBQztJQUFBLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1EsQ0FBQztNQUFBZSxRQUFBLEdBQUUsOEJBQThCLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQU8sQ0FBbUIsQ0FBQyxFQUFDLGlCQUFpQixlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFjLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQWEsQ0FBbUIsQ0FBQyxFQUFDLFVBQVUsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBeUIsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBbUIsQ0FBbUIsQ0FBQyxFQUFDLGtFQUFrRSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQWdDLENBQXFCLENBQUMsRUFBQyxpQ0FBaUM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNLLEVBQUU7TUFBQ21CLEVBQUUsRUFBQyxvQkFBb0I7TUFBQUQsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFvQixDQUFFLENBQUMsRUFBQyxvQkFBb0I7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNRLENBQUM7TUFBQWUsUUFBQSxHQUFFLHdEQUF3RCxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVUsQ0FBcUIsQ0FBQyxFQUFDLHlIQUF5SCxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFRLENBQW1CLENBQUMsRUFBQyxnREFBZ0QsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFxQixDQUFxQixDQUFDLEVBQUMsZ01BQWdNLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQVEsQ0FBbUIsQ0FBQyxFQUFDLHlFQUF5RSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07UUFBQWMsUUFBQSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFPLENBQW1CO01BQUMsQ0FBb0IsQ0FBQyxFQUFDLGtIQUFrSDtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDbUIsRUFBRSxFQUFDLCtCQUErQjtNQUFBRCxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQStCLENBQUUsQ0FBQyxFQUFDLGlDQUFpQztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1EsQ0FBQztNQUFBZSxRQUFBLEdBQUUsd0dBQXdHLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQWEsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBYyxDQUFtQixDQUFDLEVBQUMsa0xBQWtMLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQU8sQ0FBbUIsQ0FBQyxFQUFDLE9BQU8sZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBTSxDQUFtQixDQUFDLEVBQUMsd0NBQXdDO0lBQUEsQ0FBZ0IsQ0FBQztFQUFBLENBQUUsQ0FBQztBQUNqM2M7QUFDZSxTQUFTSSxVQUFVQSxDQUFDNUIsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFO0VBQzdDLE1BQU07SUFBQzZCLE9BQU8sRUFBRUM7RUFBUyxDQUFDLEdBQUc7SUFDM0IsR0FBRyxJQUFBWiw2QkFBa0IsRUFBQyxDQUFDO0lBQ3ZCLEdBQUdsQixLQUFLLENBQUNtQjtFQUNYLENBQUM7RUFDRCxPQUFPVyxTQUFTLGdCQUFHLElBQUFoQyxXQUFBLENBQUE0QixHQUFBLEVBQUNJLFNBQVM7SUFBQSxHQUFLOUIsS0FBSztJQUFBd0IsUUFBQSxlQUFFLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUMzQixpQkFBaUI7TUFBQSxHQUFLQztJQUFLLENBQUc7RUFBQyxDQUFXLENBQUMsR0FBR0QsaUJBQWlCLENBQUNDLEtBQUssQ0FBQztBQUNsSDtBQUFDK0IsRUFBQSxHQU51QkgsVUFBVTtBQU9sQyxTQUFTUCxvQkFBb0JBLENBQUNJLEVBQUUsRUFBRU8sU0FBUyxFQUFFQyxLQUFLLEVBQUU7RUFDbEQsTUFBTSxJQUFJQyxLQUFLLENBQUMsV0FBVyxJQUFJRixTQUFTLEdBQUcsV0FBVyxHQUFHLFFBQVEsQ0FBQyxHQUFHLElBQUksR0FBR1AsRUFBRSxHQUFHLG9FQUFvRSxJQUFJUSxLQUFLLEdBQUcscUNBQXFDLEdBQUdBLEtBQUssR0FBRyw4REFBOEQsR0FBRyxFQUFFLENBQUMsQ0FBQztBQUN4UjtBQUFDLElBQUFGLEVBQUE7QUFBQUksWUFBQSxDQUFBSixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}