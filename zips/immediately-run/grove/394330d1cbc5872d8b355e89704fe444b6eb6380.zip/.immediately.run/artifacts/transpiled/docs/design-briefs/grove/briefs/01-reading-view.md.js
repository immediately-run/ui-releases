var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      code: "code",
      h1: "h1",
      h2: "h2",
      li: "li",
      ol: "ol",
      p: "p",
      strong: "strong",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "brief-01-the-reading-view-the-entry-page",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "brief-01-the-reading-view-the-entry-page"
      }), "Brief 01 — The reading view (the entry page)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "The hero surface."
      }), " This is what a reader sees and where most of Grove's time is spent.\nGet the long-form reading craft right here and the product feels good. Assumes\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "./00-foundation.md",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "00-foundation"
        })
      }), ". Source: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "grove.md"
      }), " \"Content model\", \"Wiki-links\",\n\"Images & assets\", \"Authoring\"."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "anatomy-of-an-entry",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "anatomy-of-an-entry"
      }), "Anatomy of an entry"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: ".grove-page"
      }), " → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: ".grove-entry-header"
      }), " + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: ".grove-prose"
      }), " (+ optional ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: ".grove-toc"
      }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: ".grove-backlinks"
      }), "). Design these:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "Entry header"
          }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: ".grove-entry-header"
          }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: ".grove-meta"
          }), "):"]
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
          children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Title"
            }), " — Gabarito 800, sentence case, ends on a period when it's a statement;\nmay take the gradient text-clip on hero entries, plain ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "--ink"
            }), " on dense reference\nentries. One title per entry."]
          }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Meta row"
            }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: ".grove-meta"
            }), ") — mono ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "--mono-sm"
            }), ": date, reading time (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "→ 6 min read"
            }), "),\nand tag chips. Muted ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "--ink-2"
            }), ". On a reference wiki the date may be hidden; on a\njournal/blog layout it's prominent. This is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "<PageMeta />"
            }), " (brief 03)."]
          }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: ["The optional ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "edit affordance"
            }), " sits here, top-right, unobtrusive (brief 02)."]
          }), "\n"]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "The prose body"
          }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: ".grove-prose"
          }), ") — the measured reading column (~68–72ch). Specify\nthe full MDX element kit, because MDX renders all of it:"]
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
          children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: ["Headings h1–h4 (Gabarito, tightening rhythm), body (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "--body"
            }), " 16px/1.5), lists,\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "blockquotes"
            }), ", and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "callouts"
            }), " (an Obsidian-style ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "> [!tip] Title"
            }), " block — a\nhairline-bordered panel with an accent spine and a Lucide icon; design ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "tip"
            }), " /\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "note"
            }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "warning"
            }), " variants using ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "--accent"
            }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "--ink-2"
            }), " / a warm-via-token cue,\nnever raw red)."]
          }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Inline code"
            }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "fenced code blocks"
            }), " — use the editor syntax tokens\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "--editor-bg"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "--syn-*"
            }), ") so code on a Grove page matches the platform editor;\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "--r-md"
            }), " corners, Space Mono."]
          }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Tables"
            }), " (the LOTR/chronology and KB cases lean on these) — hairline rules, mono\nnumerics, zebra via ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "--panel-2"
            }), " at most; must reflow/scroll on mobile."]
          }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Images"
            }), " — full-width within the measure, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "--r-md"
            }), ", hairline frame, optional mono\ncaption. (These come through the SDK asset primitive, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "grove.md"
            }), " \"Images & assets\" —\ndesign a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "loading placeholder"
            }), " for an image whose bytes are still resolving: the\nlink-graph motif or a shimmer, sized to the image's box to avoid layout shift.)"]
          }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Embeds"
            }), " — YouTube/Spotify iframes (Pixies case) in a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "--r-md"
            }), " hairline frame,\nresponsive aspect-ratio box, with a lightweight pre-consent poster if the iframe\nhasn't loaded."]
          }), "\n"]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "Wiki-links in flow"
          }), " — render the three ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: ".grove-wikilink[data-state]"
          }), " states from\nbrief 00. Show a paragraph with a resolved link, a broken link, and a self-link so the\ncontrast is legible."]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "Table of contents"
          }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: ".grove-toc"
          }), ", the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "<Toc />"
          }), " component) — on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "doc"
          }), " layout, a\nsticky right-rail ToC on desktop that collapses into a top \"On this page\" disclosure on\nmobile. Current-section highlighted with the accent."]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "Backlinks"
          }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: ".grove-backlinks"
          }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "<Backlinks />"
          }), ") — a footer block under the prose:\n\"", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "38"
          }), " entries link here.\" as a mono stat + a list of linking entries (title +\nbreadcrumb of its namespace + the snippet around the link). This is a signature wiki\naffordance — make it feel substantial, not an afterthought. Design its ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "empty state"
          }), "\n(\"Nothing links here yet.\") and a collapsed/expandable form when the list is long."]
        }), "\n"]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "layout-variants-data-layout-all-css-selectable",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "layout-variants-data-layout-all-css-selectable"
      }), "Layout variants (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "data-layout"
      }), ", all CSS-selectable)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Same DOM, different ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "data-layout"
      }), " — design all three:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "doc"
          })
        }), " — reference/wiki: optional left namespace context, prose, right ToC rail.\nThe default for encyclopedic content (LOTR, KB, Pixies song pages)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "post"
          })
        }), " — chronological/blog: centered single column, prominent date + author, no\nToC rail, generous lede. The family-journal / changelog shape."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "full"
          })
        }), " — full-bleed: edge-to-edge for a landing/portal entry or a media-heavy page,\nminimal chrome."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "mobile",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "mobile"
      }), "Mobile"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Single column; the ToC becomes a disclosure; the meta row wraps; tap targets ≥44px;\nimages and embeds go edge-to-edge within the gutter. Reading column comfortable at 16px.\nThe edit affordance moves into the entry's overflow menu, never a floating bar over text."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "states",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "states"
      }), "States"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Loading"
        }), " — skeleton of header + 6–8 prose lines + a ToC ghost (no spinner < 150ms)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Empty"
        }), " — an entry that exists but has no body yet (\"This entry is a stub.\" + an\nask-the-agent / edit affordance if writable)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Error / 404"
        }), " — the route resolves to no entry (a broken ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "[[wiki-link]]"
        }), " was\nfollowed): a designed \"No entry at ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "/slug"
        }), ".\" with the closest-match suggestion and, if\nwritable, \"create it\" → hands to the host. Never a raw stack or blank page."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Read-only"
        }), " — identical, minus any edit affordance (brief 02 / 05)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "copy-to-draft",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "copy-to-draft"
      }), "Copy to draft"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The backlinks header (\"", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "N"
      }), " entries link here.\"), the stub-entry line, the 404 line +\nsuggestion, callout default titles, and the image/embed loading captions. Sentence case,\nperiod-terminated, mono for counts."]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/design-briefs/grove/briefs/01-reading-view.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiY29kZSIsImgxIiwiaDIiLCJsaSIsIm9sIiwicCIsInN0cm9uZyIsInVsIiwiX3Byb3ZpZGVDb21wb25lbnRzIiwiY29tcG9uZW50cyIsIkhlYWRpbmdBbmNob3IiLCJfbWlzc2luZ01keFJlZmVyZW5jZSIsImpzeHMiLCJGcmFnbWVudCIsImNoaWxkcmVuIiwiaWQiLCJqc3giLCJocmVmIiwiTURYQ29udGVudCIsIndyYXBwZXIiLCJNRFhMYXlvdXQiLCJfYyIsImNvbXBvbmVudCIsInBsYWNlIiwiRXJyb3IiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyIwMS1yZWFkaW5nLXZpZXcubWQiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgYTogXCJhXCIsXG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgaDE6IFwiaDFcIixcbiAgICBoMjogXCJoMlwiLFxuICAgIGxpOiBcImxpXCIsXG4gICAgb2w6IFwib2xcIixcbiAgICBwOiBcInBcIixcbiAgICBzdHJvbmc6IFwic3Ryb25nXCIsXG4gICAgdWw6IFwidWxcIixcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH0sIHtIZWFkaW5nQW5jaG9yfSA9IF9jb21wb25lbnRzO1xuICBpZiAoIUhlYWRpbmdBbmNob3IpIF9taXNzaW5nTWR4UmVmZXJlbmNlKFwiSGVhZGluZ0FuY2hvclwiLCB0cnVlKTtcbiAgcmV0dXJuIDw+PF9jb21wb25lbnRzLmgxIGlkPVwiYnJpZWYtMDEtdGhlLXJlYWRpbmctdmlldy10aGUtZW50cnktcGFnZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiYnJpZWYtMDEtdGhlLXJlYWRpbmctdmlldy10aGUtZW50cnktcGFnZVwiIC8+e1wiQnJpZWYgMDEg4oCUIFRoZSByZWFkaW5nIHZpZXcgKHRoZSBlbnRyeSBwYWdlKVwifTwvX2NvbXBvbmVudHMuaDE+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgaGVybyBzdXJmYWNlLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGlzIGlzIHdoYXQgYSByZWFkZXIgc2VlcyBhbmQgd2hlcmUgbW9zdCBvZiBHcm92ZSdzIHRpbWUgaXMgc3BlbnQuXFxuR2V0IHRoZSBsb25nLWZvcm0gcmVhZGluZyBjcmFmdCByaWdodCBoZXJlIGFuZCB0aGUgcHJvZHVjdCBmZWVscyBnb29kLiBBc3N1bWVzXFxuXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cIi4vMDAtZm91bmRhdGlvbi5tZFwiPjxfY29tcG9uZW50cy5jb2RlPntcIjAwLWZvdW5kYXRpb25cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5hPntcIi4gU291cmNlOiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJncm92ZS5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgXFxcIkNvbnRlbnQgbW9kZWxcXFwiLCBcXFwiV2lraS1saW5rc1xcXCIsXFxuXFxcIkltYWdlcyAmIGFzc2V0c1xcXCIsIFxcXCJBdXRob3JpbmdcXFwiLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJhbmF0b215LW9mLWFuLWVudHJ5XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJhbmF0b215LW9mLWFuLWVudHJ5XCIgLz57XCJBbmF0b215IG9mIGFuIGVudHJ5XCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuY29kZT57XCIuZ3JvdmUtcGFnZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oaSIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi5ncm92ZS1lbnRyeS1oZWFkZXJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLmdyb3ZlLXByb3NlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoKyBvcHRpb25hbCBcIn08X2NvbXBvbmVudHMuY29kZT57XCIuZ3JvdmUtdG9jXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIixcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCIuZ3JvdmUtYmFja2xpbmtzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikuIERlc2lnbiB0aGVzZTpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkVudHJ5IGhlYWRlclwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLmdyb3ZlLWVudHJ5LWhlYWRlclwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgLyBcIn08X2NvbXBvbmVudHMuY29kZT57XCIuZ3JvdmUtbWV0YVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVGl0bGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIEdhYmFyaXRvIDgwMCwgc2VudGVuY2UgY2FzZSwgZW5kcyBvbiBhIHBlcmlvZCB3aGVuIGl0J3MgYSBzdGF0ZW1lbnQ7XFxubWF5IHRha2UgdGhlIGdyYWRpZW50IHRleHQtY2xpcCBvbiBoZXJvIGVudHJpZXMsIHBsYWluIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi0taW5rXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBvbiBkZW5zZSByZWZlcmVuY2VcXG5lbnRyaWVzLiBPbmUgdGl0bGUgcGVyIGVudHJ5LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiTWV0YSByb3dcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIi5ncm92ZS1tZXRhXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikg4oCUIG1vbm8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1tb25vLXNtXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjogZGF0ZSwgcmVhZGluZyB0aW1lIChcIn08X2NvbXBvbmVudHMuY29kZT57XCLihpIgNiBtaW4gcmVhZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLFxcbmFuZCB0YWcgY2hpcHMuIE11dGVkIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi0taW5rLTJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLiBPbiBhIHJlZmVyZW5jZSB3aWtpIHRoZSBkYXRlIG1heSBiZSBoaWRkZW47IG9uIGFcXG5qb3VybmFsL2Jsb2cgbGF5b3V0IGl0J3MgcHJvbWluZW50LiBUaGlzIGlzIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjxQYWdlTWV0YSAvPlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKGJyaWVmIDAzKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJUaGUgb3B0aW9uYWwgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJlZGl0IGFmZm9yZGFuY2VcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgc2l0cyBoZXJlLCB0b3AtcmlnaHQsIHVub2J0cnVzaXZlIChicmllZiAwMikuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVGhlIHByb3NlIGJvZHlcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIi5ncm92ZS1wcm9zZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpIOKAlCB0aGUgbWVhc3VyZWQgcmVhZGluZyBjb2x1bW4gKH42OOKAkzcyY2gpLiBTcGVjaWZ5XFxudGhlIGZ1bGwgTURYIGVsZW1lbnQga2l0LCBiZWNhdXNlIE1EWCByZW5kZXJzIGFsbCBvZiBpdDpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJIZWFkaW5ncyBoMeKAk2g0IChHYWJhcml0bywgdGlnaHRlbmluZyByaHl0aG0pLCBib2R5IChcIn08X2NvbXBvbmVudHMuY29kZT57XCItLWJvZHlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIDE2cHgvMS41KSwgbGlzdHMsXFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJibG9ja3F1b3Rlc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgYW5kIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiY2FsbG91dHNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKGFuIE9ic2lkaWFuLXN0eWxlIFwifTxfY29tcG9uZW50cy5jb2RlPntcIj4gWyF0aXBdIFRpdGxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBibG9jayDigJQgYVxcbmhhaXJsaW5lLWJvcmRlcmVkIHBhbmVsIHdpdGggYW4gYWNjZW50IHNwaW5lIGFuZCBhIEx1Y2lkZSBpY29uOyBkZXNpZ24gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widGlwXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAvXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibm90ZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgLyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ3YXJuaW5nXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB2YXJpYW50cyB1c2luZyBcIn08X2NvbXBvbmVudHMuY29kZT57XCItLWFjY2VudFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgLyBcIn08X2NvbXBvbmVudHMuY29kZT57XCItLWluay0yXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAvIGEgd2FybS12aWEtdG9rZW4gY3VlLFxcbm5ldmVyIHJhdyByZWQpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiSW5saW5lIGNvZGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYW5kIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZmVuY2VkIGNvZGUgYmxvY2tzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCB1c2UgdGhlIGVkaXRvciBzeW50YXggdG9rZW5zXFxuKFwifTxfY29tcG9uZW50cy5jb2RlPntcIi0tZWRpdG9yLWJnXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1zeW4tKlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpIHNvIGNvZGUgb24gYSBHcm92ZSBwYWdlIG1hdGNoZXMgdGhlIHBsYXRmb3JtIGVkaXRvcjtcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCItLXItbWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNvcm5lcnMsIFNwYWNlIE1vbm8uXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUYWJsZXNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHRoZSBMT1RSL2Nocm9ub2xvZ3kgYW5kIEtCIGNhc2VzIGxlYW4gb24gdGhlc2UpIOKAlCBoYWlybGluZSBydWxlcywgbW9ub1xcbm51bWVyaWNzLCB6ZWJyYSB2aWEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1wYW5lbC0yXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhdCBtb3N0OyBtdXN0IHJlZmxvdy9zY3JvbGwgb24gbW9iaWxlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiSW1hZ2VzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBmdWxsLXdpZHRoIHdpdGhpbiB0aGUgbWVhc3VyZSwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1yLW1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgaGFpcmxpbmUgZnJhbWUsIG9wdGlvbmFsIG1vbm9cXG5jYXB0aW9uLiAoVGhlc2UgY29tZSB0aHJvdWdoIHRoZSBTREsgYXNzZXQgcHJpbWl0aXZlLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJncm92ZS5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgXFxcIkltYWdlcyAmIGFzc2V0c1xcXCIg4oCUXFxuZGVzaWduIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJsb2FkaW5nIHBsYWNlaG9sZGVyXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGZvciBhbiBpbWFnZSB3aG9zZSBieXRlcyBhcmUgc3RpbGwgcmVzb2x2aW5nOiB0aGVcXG5saW5rLWdyYXBoIG1vdGlmIG9yIGEgc2hpbW1lciwgc2l6ZWQgdG8gdGhlIGltYWdlJ3MgYm94IHRvIGF2b2lkIGxheW91dCBzaGlmdC4pXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJFbWJlZHNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIFlvdVR1YmUvU3BvdGlmeSBpZnJhbWVzIChQaXhpZXMgY2FzZSkgaW4gYSBcIn08X2NvbXBvbmVudHMuY29kZT57XCItLXItbWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGhhaXJsaW5lIGZyYW1lLFxcbnJlc3BvbnNpdmUgYXNwZWN0LXJhdGlvIGJveCwgd2l0aCBhIGxpZ2h0d2VpZ2h0IHByZS1jb25zZW50IHBvc3RlciBpZiB0aGUgaWZyYW1lXFxuaGFzbid0IGxvYWRlZC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJXaWtpLWxpbmtzIGluIGZsb3dcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHJlbmRlciB0aGUgdGhyZWUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLmdyb3ZlLXdpa2lsaW5rW2RhdGEtc3RhdGVdXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBzdGF0ZXMgZnJvbVxcbmJyaWVmIDAwLiBTaG93IGEgcGFyYWdyYXBoIHdpdGggYSByZXNvbHZlZCBsaW5rLCBhIGJyb2tlbiBsaW5rLCBhbmQgYSBzZWxmLWxpbmsgc28gdGhlXFxuY29udHJhc3QgaXMgbGVnaWJsZS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUYWJsZSBvZiBjb250ZW50c1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLmdyb3ZlLXRvY1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCI8VG9jIC8+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjb21wb25lbnQpIOKAlCBvbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJkb2NcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGxheW91dCwgYVxcbnN0aWNreSByaWdodC1yYWlsIFRvQyBvbiBkZXNrdG9wIHRoYXQgY29sbGFwc2VzIGludG8gYSB0b3AgXFxcIk9uIHRoaXMgcGFnZVxcXCIgZGlzY2xvc3VyZSBvblxcbm1vYmlsZS4gQ3VycmVudC1zZWN0aW9uIGhpZ2hsaWdodGVkIHdpdGggdGhlIGFjY2VudC5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJCYWNrbGlua3NcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIi5ncm92ZS1iYWNrbGlua3NcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCI8QmFja2xpbmtzIC8+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikg4oCUIGEgZm9vdGVyIGJsb2NrIHVuZGVyIHRoZSBwcm9zZTpcXG5cXFwiXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiMzhcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGVudHJpZXMgbGluayBoZXJlLlxcXCIgYXMgYSBtb25vIHN0YXQgKyBhIGxpc3Qgb2YgbGlua2luZyBlbnRyaWVzICh0aXRsZSArXFxuYnJlYWRjcnVtYiBvZiBpdHMgbmFtZXNwYWNlICsgdGhlIHNuaXBwZXQgYXJvdW5kIHRoZSBsaW5rKS4gVGhpcyBpcyBhIHNpZ25hdHVyZSB3aWtpXFxuYWZmb3JkYW5jZSDigJQgbWFrZSBpdCBmZWVsIHN1YnN0YW50aWFsLCBub3QgYW4gYWZ0ZXJ0aG91Z2h0LiBEZXNpZ24gaXRzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZW1wdHkgc3RhdGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCJcXG4oXFxcIk5vdGhpbmcgbGlua3MgaGVyZSB5ZXQuXFxcIikgYW5kIGEgY29sbGFwc2VkL2V4cGFuZGFibGUgZm9ybSB3aGVuIHRoZSBsaXN0IGlzIGxvbmcuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJsYXlvdXQtdmFyaWFudHMtZGF0YS1sYXlvdXQtYWxsLWNzcy1zZWxlY3RhYmxlXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJsYXlvdXQtdmFyaWFudHMtZGF0YS1sYXlvdXQtYWxsLWNzcy1zZWxlY3RhYmxlXCIgLz57XCJMYXlvdXQgdmFyaWFudHMgKFwifTxfY29tcG9uZW50cy5jb2RlPntcImRhdGEtbGF5b3V0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgYWxsIENTUy1zZWxlY3RhYmxlKVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiU2FtZSBET00sIGRpZmZlcmVudCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJkYXRhLWxheW91dFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIGRlc2lnbiBhbGwgdGhyZWU6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz48X2NvbXBvbmVudHMuY29kZT57XCJkb2NcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCByZWZlcmVuY2Uvd2lraTogb3B0aW9uYWwgbGVmdCBuYW1lc3BhY2UgY29udGV4dCwgcHJvc2UsIHJpZ2h0IFRvQyByYWlsLlxcblRoZSBkZWZhdWx0IGZvciBlbmN5Y2xvcGVkaWMgY29udGVudCAoTE9UUiwgS0IsIFBpeGllcyBzb25nIHBhZ2VzKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPjxfY29tcG9uZW50cy5jb2RlPntcInBvc3RcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBjaHJvbm9sb2dpY2FsL2Jsb2c6IGNlbnRlcmVkIHNpbmdsZSBjb2x1bW4sIHByb21pbmVudCBkYXRlICsgYXV0aG9yLCBub1xcblRvQyByYWlsLCBnZW5lcm91cyBsZWRlLiBUaGUgZmFtaWx5LWpvdXJuYWwgLyBjaGFuZ2Vsb2cgc2hhcGUuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz48X2NvbXBvbmVudHMuY29kZT57XCJmdWxsXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgZnVsbC1ibGVlZDogZWRnZS10by1lZGdlIGZvciBhIGxhbmRpbmcvcG9ydGFsIGVudHJ5IG9yIGEgbWVkaWEtaGVhdnkgcGFnZSxcXG5taW5pbWFsIGNocm9tZS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwibW9iaWxlXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJtb2JpbGVcIiAvPntcIk1vYmlsZVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiU2luZ2xlIGNvbHVtbjsgdGhlIFRvQyBiZWNvbWVzIGEgZGlzY2xvc3VyZTsgdGhlIG1ldGEgcm93IHdyYXBzOyB0YXAgdGFyZ2V0cyDiiaU0NHB4O1xcbmltYWdlcyBhbmQgZW1iZWRzIGdvIGVkZ2UtdG8tZWRnZSB3aXRoaW4gdGhlIGd1dHRlci4gUmVhZGluZyBjb2x1bW4gY29tZm9ydGFibGUgYXQgMTZweC5cXG5UaGUgZWRpdCBhZmZvcmRhbmNlIG1vdmVzIGludG8gdGhlIGVudHJ5J3Mgb3ZlcmZsb3cgbWVudSwgbmV2ZXIgYSBmbG9hdGluZyBiYXIgb3ZlciB0ZXh0LlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzdGF0ZXNcIj48SGVhZGluZ0FuY2hvciBpZD1cInN0YXRlc1wiIC8+e1wiU3RhdGVzXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiTG9hZGluZ1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgc2tlbGV0b24gb2YgaGVhZGVyICsgNuKAkzggcHJvc2UgbGluZXMgKyBhIFRvQyBnaG9zdCAobm8gc3Bpbm5lciA8IDE1MG1zKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkVtcHR5XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBhbiBlbnRyeSB0aGF0IGV4aXN0cyBidXQgaGFzIG5vIGJvZHkgeWV0IChcXFwiVGhpcyBlbnRyeSBpcyBhIHN0dWIuXFxcIiArIGFuXFxuYXNrLXRoZS1hZ2VudCAvIGVkaXQgYWZmb3JkYW5jZSBpZiB3cml0YWJsZSkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJFcnJvciAvIDQwNFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgdGhlIHJvdXRlIHJlc29sdmVzIHRvIG5vIGVudHJ5IChhIGJyb2tlbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJbW3dpa2ktbGlua11dXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB3YXNcXG5mb2xsb3dlZCk6IGEgZGVzaWduZWQgXFxcIk5vIGVudHJ5IGF0IFwifTxfY29tcG9uZW50cy5jb2RlPntcIi9zbHVnXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi5cXFwiIHdpdGggdGhlIGNsb3Nlc3QtbWF0Y2ggc3VnZ2VzdGlvbiBhbmQsIGlmXFxud3JpdGFibGUsIFxcXCJjcmVhdGUgaXRcXFwiIOKGkiBoYW5kcyB0byB0aGUgaG9zdC4gTmV2ZXIgYSByYXcgc3RhY2sgb3IgYmxhbmsgcGFnZS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlJlYWQtb25seVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgaWRlbnRpY2FsLCBtaW51cyBhbnkgZWRpdCBhZmZvcmRhbmNlIChicmllZiAwMiAvIDA1KS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwiY29weS10by1kcmFmdFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiY29weS10by1kcmFmdFwiIC8+e1wiQ29weSB0byBkcmFmdFwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIGJhY2tsaW5rcyBoZWFkZXIgKFxcXCJcIn08X2NvbXBvbmVudHMuY29kZT57XCJOXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBlbnRyaWVzIGxpbmsgaGVyZS5cXFwiKSwgdGhlIHN0dWItZW50cnkgbGluZSwgdGhlIDQwNCBsaW5lICtcXG5zdWdnZXN0aW9uLCBjYWxsb3V0IGRlZmF1bHQgdGl0bGVzLCBhbmQgdGhlIGltYWdlL2VtYmVkIGxvYWRpbmcgY2FwdGlvbnMuIFNlbnRlbmNlIGNhc2UsXFxucGVyaW9kLXRlcm1pbmF0ZWQsIG1vbm8gZm9yIGNvdW50cy5cIn08L19jb21wb25lbnRzLnA+PC8+O1xufVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTURYQ29udGVudChwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHt3cmFwcGVyOiBNRFhMYXlvdXR9ID0ge1xuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfTtcbiAgcmV0dXJuIE1EWExheW91dCA/IDxNRFhMYXlvdXQgey4uLnByb3BzfT48X2NyZWF0ZU1keENvbnRlbnQgey4uLnByb3BzfSAvPjwvTURYTGF5b3V0PiA6IF9jcmVhdGVNZHhDb250ZW50KHByb3BzKTtcbn1cbmZ1bmN0aW9uIF9taXNzaW5nTWR4UmVmZXJlbmNlKGlkLCBjb21wb25lbnQsIHBsYWNlKSB7XG4gIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIFwiICsgKGNvbXBvbmVudCA/IFwiY29tcG9uZW50XCIgOiBcIm9iamVjdFwiKSArIFwiIGBcIiArIGlkICsgXCJgIHRvIGJlIGRlZmluZWQ6IHlvdSBsaWtlbHkgZm9yZ290IHRvIGltcG9ydCwgcGFzcywgb3IgcHJvdmlkZSBpdC5cIiArIChwbGFjZSA/IFwiXFxuSXTigJlzIHJlZmVyZW5jZWQgaW4geW91ciBjb2RlIGF0IGBcIiArIHBsYWNlICsgXCJgIGluIGAvYXBwL2RvY3MvZGVzaWduLWJyaWVmcy9ncm92ZS9icmllZnMvMDEtcmVhZGluZy12aWV3Lm1kYFwiIDogXCJcIikpO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFFQSxJQUFBQSxZQUFBLEdBQUFDLE9BQUE7QUFBd0YsSUFBQUMsV0FBQSxHQUFBRCxPQUFBO0FBRnhGO0FBQ0E7O0FBRUEsU0FBU0UsaUJBQWlCQSxDQUFDQyxLQUFLLEVBQUU7RUFDaEMsTUFBTUMsV0FBVyxHQUFHO01BQ2xCQyxDQUFDLEVBQUUsR0FBRztNQUNOQyxJQUFJLEVBQUUsTUFBTTtNQUNaQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxDQUFDLEVBQUUsR0FBRztNQUNOQyxNQUFNLEVBQUUsUUFBUTtNQUNoQkMsRUFBRSxFQUFFLElBQUk7TUFDUixHQUFHLElBQUFDLDZCQUFrQixFQUFDLENBQUM7TUFDdkIsR0FBR1gsS0FBSyxDQUFDWTtJQUNYLENBQUM7SUFBRTtNQUFDQztJQUFhLENBQUMsR0FBR1osV0FBVztFQUNoQyxJQUFJLENBQUNZLGFBQWEsRUFBRUMsb0JBQW9CLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQztFQUMvRCxvQkFBTyxJQUFBaEIsV0FBQSxDQUFBaUIsSUFBQSxFQUFBakIsV0FBQSxDQUFBa0IsUUFBQTtJQUFBQyxRQUFBLGdCQUFFLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ0csRUFBRTtNQUFDYyxFQUFFLEVBQUMsMENBQTBDO01BQUFELFFBQUEsZ0JBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBMEMsQ0FBRSxDQUFDLEVBQUMsOENBQThDO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNPLENBQUM7TUFBQVMsUUFBQSxnQkFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDUSxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFtQixDQUFxQixDQUFDLEVBQUMsd0pBQXdKLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsQ0FBQztRQUFDa0IsSUFBSSxFQUFDLG9CQUFvQjtRQUFBSCxRQUFBLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBZSxDQUFtQjtNQUFDLENBQWUsQ0FBQyxFQUFDLFlBQVksZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFjLFFBQUEsRUFBRTtNQUFVLENBQW1CLENBQUMsRUFBQywwRUFBMEU7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ0ksRUFBRTtNQUFDYSxFQUFFLEVBQUMscUJBQXFCO01BQUFELFFBQUEsZ0JBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBcUIsQ0FBRSxDQUFDLEVBQUMscUJBQXFCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNPLENBQUM7TUFBQVMsUUFBQSxnQkFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFjLFFBQUEsRUFBRTtNQUFhLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBYyxRQUFBLEVBQUU7TUFBcUIsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFjLFFBQUEsRUFBRTtNQUFjLENBQW1CLENBQUMsRUFBQyxlQUFlLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBYyxRQUFBLEVBQUU7TUFBWSxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNFLElBQUk7UUFBQWMsUUFBQSxFQUFFO01BQWtCLENBQW1CLENBQUMsRUFBQyxrQkFBa0I7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ00sRUFBRTtNQUFBVSxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ0ssRUFBRTtRQUFBVyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ08sQ0FBQztVQUFBUyxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNRLE1BQU07WUFBQVEsUUFBQSxFQUFFO1VBQWMsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDRSxJQUFJO1lBQUFjLFFBQUEsRUFBRTtVQUFxQixDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNFLElBQUk7WUFBQWMsUUFBQSxFQUFFO1VBQWEsQ0FBbUIsQ0FBQyxFQUFDLElBQUk7UUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ1MsRUFBRTtVQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ0ssRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNRLE1BQU07Y0FBQVEsUUFBQSxFQUFFO1lBQU8sQ0FBcUIsQ0FBQyxFQUFDLGtJQUFrSSxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNFLElBQUk7Y0FBQWMsUUFBQSxFQUFFO1lBQU8sQ0FBbUIsQ0FBQyxFQUFDLG9EQUFvRDtVQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDSyxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1EsTUFBTTtjQUFBUSxRQUFBLEVBQUU7WUFBVSxDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNFLElBQUk7Y0FBQWMsUUFBQSxFQUFFO1lBQWEsQ0FBbUIsQ0FBQyxFQUFDLFdBQVcsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDRSxJQUFJO2NBQUFjLFFBQUEsRUFBRTtZQUFXLENBQW1CLENBQUMsRUFBQyx3QkFBd0IsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDRSxJQUFJO2NBQUFjLFFBQUEsRUFBRTtZQUFjLENBQW1CLENBQUMsRUFBQywyQkFBMkIsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDRSxJQUFJO2NBQUFjLFFBQUEsRUFBRTtZQUFTLENBQW1CLENBQUMsRUFBQyxrR0FBa0csZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDRSxJQUFJO2NBQUFjLFFBQUEsRUFBRTtZQUFjLENBQW1CLENBQUMsRUFBQyxjQUFjO1VBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNLLEVBQUU7WUFBQVcsUUFBQSxHQUFFLGVBQWUsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDUSxNQUFNO2NBQUFRLFFBQUEsRUFBRTtZQUFpQixDQUFxQixDQUFDLEVBQUMsZ0RBQWdEO1VBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7UUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDSyxFQUFFO1FBQUFXLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDTyxDQUFDO1VBQUFTLFFBQUEsZ0JBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1EsTUFBTTtZQUFBUSxRQUFBLEVBQUU7VUFBZ0IsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDRSxJQUFJO1lBQUFjLFFBQUEsRUFBRTtVQUFjLENBQW1CLENBQUMsRUFBQywrR0FBK0c7UUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ1MsRUFBRTtVQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ0ssRUFBRTtZQUFBVyxRQUFBLEdBQUUsc0RBQXNELGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBYyxRQUFBLEVBQUU7WUFBUSxDQUFtQixDQUFDLEVBQUMsc0JBQXNCLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1EsTUFBTTtjQUFBUSxRQUFBLEVBQUU7WUFBYSxDQUFxQixDQUFDLEVBQUMsUUFBUSxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNRLE1BQU07Y0FBQVEsUUFBQSxFQUFFO1lBQVUsQ0FBcUIsQ0FBQyxFQUFDLHNCQUFzQixlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNFLElBQUk7Y0FBQWMsUUFBQSxFQUFFO1lBQWdCLENBQW1CLENBQUMsRUFBQyxxRkFBcUYsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDRSxJQUFJO2NBQUFjLFFBQUEsRUFBRTtZQUFLLENBQW1CLENBQUMsRUFBQyxNQUFNLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBYyxRQUFBLEVBQUU7WUFBTSxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNFLElBQUk7Y0FBQWMsUUFBQSxFQUFFO1lBQVMsQ0FBbUIsQ0FBQyxFQUFDLGtCQUFrQixlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNFLElBQUk7Y0FBQWMsUUFBQSxFQUFFO1lBQVUsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDRSxJQUFJO2NBQUFjLFFBQUEsRUFBRTtZQUFTLENBQW1CLENBQUMsRUFBQywyQ0FBMkM7VUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ0ssRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNRLE1BQU07Y0FBQVEsUUFBQSxFQUFFO1lBQWEsQ0FBcUIsQ0FBQyxFQUFDLE9BQU8sZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDUSxNQUFNO2NBQUFRLFFBQUEsRUFBRTtZQUFvQixDQUFxQixDQUFDLEVBQUMsb0NBQW9DLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBYyxRQUFBLEVBQUU7WUFBYSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNFLElBQUk7Y0FBQWMsUUFBQSxFQUFFO1lBQVMsQ0FBbUIsQ0FBQyxFQUFDLDBEQUEwRCxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNFLElBQUk7Y0FBQWMsUUFBQSxFQUFFO1lBQVEsQ0FBbUIsQ0FBQyxFQUFDLHVCQUF1QjtVQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDSyxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1EsTUFBTTtjQUFBUSxRQUFBLEVBQUU7WUFBUSxDQUFxQixDQUFDLEVBQUMsZ0dBQWdHLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBYyxRQUFBLEVBQUU7WUFBVyxDQUFtQixDQUFDLEVBQUMseUNBQXlDO1VBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNLLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDUSxNQUFNO2NBQUFRLFFBQUEsRUFBRTtZQUFRLENBQXFCLENBQUMsRUFBQyxvQ0FBb0MsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDRSxJQUFJO2NBQUFjLFFBQUEsRUFBRTtZQUFRLENBQW1CLENBQUMsRUFBQyx5RkFBeUYsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDRSxJQUFJO2NBQUFjLFFBQUEsRUFBRTtZQUFVLENBQW1CLENBQUMsRUFBQyxtQ0FBbUMsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDUSxNQUFNO2NBQUFRLFFBQUEsRUFBRTtZQUFxQixDQUFxQixDQUFDLEVBQUMscUlBQXFJO1VBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNLLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDUSxNQUFNO2NBQUFRLFFBQUEsRUFBRTtZQUFRLENBQXFCLENBQUMsRUFBQyxnREFBZ0QsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDRSxJQUFJO2NBQUFjLFFBQUEsRUFBRTtZQUFRLENBQW1CLENBQUMsRUFBQyxvSEFBb0g7VUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtRQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNLLEVBQUU7UUFBQVcsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNPLENBQUM7VUFBQVMsUUFBQSxnQkFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDUSxNQUFNO1lBQUFRLFFBQUEsRUFBRTtVQUFvQixDQUFxQixDQUFDLEVBQUMsc0JBQXNCLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBYyxRQUFBLEVBQUU7VUFBNkIsQ0FBbUIsQ0FBQyxFQUFDLDRIQUE0SDtRQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNLLEVBQUU7UUFBQVcsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNPLENBQUM7VUFBQVMsUUFBQSxnQkFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDUSxNQUFNO1lBQUFRLFFBQUEsRUFBRTtVQUFtQixDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNFLElBQUk7WUFBQWMsUUFBQSxFQUFFO1VBQVksQ0FBbUIsQ0FBQyxFQUFDLFFBQVEsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDRSxJQUFJO1lBQUFjLFFBQUEsRUFBRTtVQUFTLENBQW1CLENBQUMsRUFBQyxtQkFBbUIsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDRSxJQUFJO1lBQUFjLFFBQUEsRUFBRTtVQUFLLENBQW1CLENBQUMsRUFBQyw2SkFBNko7UUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDSyxFQUFFO1FBQUFXLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDTyxDQUFDO1VBQUFTLFFBQUEsZ0JBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1EsTUFBTTtZQUFBUSxRQUFBLEVBQUU7VUFBVyxDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNFLElBQUk7WUFBQWMsUUFBQSxFQUFFO1VBQWtCLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBYyxRQUFBLEVBQUU7VUFBZSxDQUFtQixDQUFDLEVBQUMseUNBQXlDLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBYyxRQUFBLEVBQUU7VUFBSSxDQUFtQixDQUFDLEVBQUMsME9BQTBPLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1EsTUFBTTtZQUFBUSxRQUFBLEVBQUU7VUFBYSxDQUFxQixDQUFDLEVBQUMsd0ZBQXdGO1FBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDSSxFQUFFO01BQUNhLEVBQUUsRUFBQyxnREFBZ0Q7TUFBQUQsUUFBQSxnQkFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFnRCxDQUFFLENBQUMsRUFBQyxtQkFBbUIsZUFBQyxJQUFBcEIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFjLFFBQUEsRUFBRTtNQUFhLENBQW1CLENBQUMsRUFBQyx1QkFBdUI7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ08sQ0FBQztNQUFBUyxRQUFBLEdBQUUsc0JBQXNCLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBYyxRQUFBLEVBQUU7TUFBYSxDQUFtQixDQUFDLEVBQUMsc0JBQXNCO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNTLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNLLEVBQUU7UUFBQVcsUUFBQSxnQkFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDUSxNQUFNO1VBQUFRLFFBQUEsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDRSxJQUFJO1lBQUFjLFFBQUEsRUFBRTtVQUFLLENBQW1CO1FBQUMsQ0FBb0IsQ0FBQyxFQUFDLGlKQUFpSjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDSyxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1EsTUFBTTtVQUFBUSxRQUFBLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBYyxRQUFBLEVBQUU7VUFBTSxDQUFtQjtRQUFDLENBQW9CLENBQUMsRUFBQyw0SUFBNEk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ0ssRUFBRTtRQUFBVyxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNRLE1BQU07VUFBQVEsUUFBQSxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNFLElBQUk7WUFBQWMsUUFBQSxFQUFFO1VBQU0sQ0FBbUI7UUFBQyxDQUFvQixDQUFDLEVBQUMsZ0dBQWdHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ0ksRUFBRTtNQUFDYSxFQUFFLEVBQUMsUUFBUTtNQUFBRCxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVEsQ0FBRSxDQUFDLEVBQUMsUUFBUTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ08sQ0FBQztNQUFBUyxRQUFBLEVBQUU7SUFBMFEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNJLEVBQUU7TUFBQ2EsRUFBRSxFQUFDLFFBQVE7TUFBQUQsUUFBQSxnQkFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFRLENBQUUsQ0FBQyxFQUFDLFFBQVE7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ1MsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ0ssRUFBRTtRQUFBVyxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNRLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQVMsQ0FBcUIsQ0FBQyxFQUFDLDZFQUE2RTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDSyxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1EsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBTyxDQUFxQixDQUFDLEVBQUMsNEhBQTRIO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNLLEVBQUU7UUFBQVcsUUFBQSxnQkFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDUSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFhLENBQXFCLENBQUMsRUFBQyw4Q0FBOEMsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUFlLENBQW1CLENBQUMsRUFBQyw0Q0FBNEMsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUFPLENBQW1CLENBQUMsRUFBQyw4SEFBOEg7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ0ssRUFBRTtRQUFBVyxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNRLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQVcsQ0FBcUIsQ0FBQyxFQUFDLDBEQUEwRDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNJLEVBQUU7TUFBQ2EsRUFBRSxFQUFDLGVBQWU7TUFBQUQsUUFBQSxnQkFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFlLENBQUUsQ0FBQyxFQUFDLGVBQWU7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ08sQ0FBQztNQUFBUyxRQUFBLEdBQUUsMEJBQTBCLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBYyxRQUFBLEVBQUU7TUFBRyxDQUFtQixDQUFDLEVBQUMsNExBQTRMO0lBQUEsQ0FBZ0IsQ0FBQztFQUFBLENBQUUsQ0FBQztBQUM5dVQ7QUFDZSxTQUFTSSxVQUFVQSxDQUFDckIsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFO0VBQzdDLE1BQU07SUFBQ3NCLE9BQU8sRUFBRUM7RUFBUyxDQUFDLEdBQUc7SUFDM0IsR0FBRyxJQUFBWiw2QkFBa0IsRUFBQyxDQUFDO0lBQ3ZCLEdBQUdYLEtBQUssQ0FBQ1k7RUFDWCxDQUFDO0VBQ0QsT0FBT1csU0FBUyxnQkFBRyxJQUFBekIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDSSxTQUFTO0lBQUEsR0FBS3ZCLEtBQUs7SUFBQWlCLFFBQUEsZUFBRSxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDcEIsaUJBQWlCO01BQUEsR0FBS0M7SUFBSyxDQUFHO0VBQUMsQ0FBVyxDQUFDLEdBQUdELGlCQUFpQixDQUFDQyxLQUFLLENBQUM7QUFDbEg7QUFBQ3dCLEVBQUEsR0FOdUJILFVBQVU7QUFPbEMsU0FBU1Asb0JBQW9CQSxDQUFDSSxFQUFFLEVBQUVPLFNBQVMsRUFBRUMsS0FBSyxFQUFFO0VBQ2xELE1BQU0sSUFBSUMsS0FBSyxDQUFDLFdBQVcsSUFBSUYsU0FBUyxHQUFHLFdBQVcsR0FBRyxRQUFRLENBQUMsR0FBRyxJQUFJLEdBQUdQLEVBQUUsR0FBRyxvRUFBb0UsSUFBSVEsS0FBSyxHQUFHLHFDQUFxQyxHQUFHQSxLQUFLLEdBQUcsZ0VBQWdFLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDMVI7QUFBQyxJQUFBRixFQUFBO0FBQUFJLFlBQUEsQ0FBQUosRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}