var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      li: "li",
      ol: "ol",
      p: "p",
      strong: "strong",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "brief-05-states-the-theming-showcase-and-the-app-mark",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "brief-05-states-the-theming-showcase-and-the-app-mark"
      }), "Brief 05 — States, the theming showcase, and the app mark"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The unglamorous-but-load-bearing surfaces, plus the deliverable that ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "proves"
      }), " Grove's\ncore promise. Assumes ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "./00-foundation.md",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "00-foundation"
        })
      }), ". Source: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "grove.md"
      }), " \"Theming &\nlayout\", \"Two ways to use Grove\", \"How it fits the platform\"."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "universal-states-design-once-reference-everywhere",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "universal-states-design-once-reference-everywhere"
      }), "Universal states (design once, reference everywhere)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The per-surface briefs each call their own states; this brief defines the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "shared\ntemplates"
      }), " they reuse so they're consistent:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Loading — skeletons, never spinners."
        }), " A skeleton kit matched to Grove's shapes:\nprose lines, entry rows, cards, table rows, ToC ghost, timeline axis, graph nodes. Use\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--panel"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--panel-2"
        }), " blocks with a slow shimmer; budget ~150ms before anything\nappears; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "zero layout shift"
        }), " (skeletons occupy the real box). The link-graph motif\ncan stand in for asset/graph placeholders."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Empty — designed, intentional, helpful."
        }), " A reusable empty-state block: the\nlink-graph motif art, a one-line sentence-case explanation, and (only if writable) one\naction that hands to the host. Per-surface copy lives in those briefs; the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "frame"
        }), " is\nhere. \"Nothing here\" must look composed, never broken."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Error / 404 / broken link."
        }), " The wiki-specific case matters: following a broken or\nambiguous ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "[[wiki-link]]"
        }), " lands on \"No entry at ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "/slug"
        }), ".\" with the closest-match\nsuggestion and a create-if-writable hand-off. Also: a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "mount/permission error"
        }), " (a\nspace the app can't read → \"This space isn't available.\" with a calm explanation, never\na raw ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "EROFS"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "forbidden"
        }), "), and a generic load failure. All designed, all on-brand,\nnever a stack trace."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Read-only viewer."
        }), " The whole app minus every authoring affordance (no edit pencil,\nno new-entry, no ask-the-agent). Design this as a first-class variant — an anonymous\nshare-link reader is a real, common viewer (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "grove.md"
        }), " \"Authoring\", \"How it fits the\nplatform\"). It should feel complete, not \"logged out\"."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "the-theming-showcase-the-proof-deliverable",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-theming-showcase-the-proof-deliverable"
      }), "The theming showcase (the proof deliverable)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Grove's promise is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "CSS-only re-skinning over stable classes + tokens"
      }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "grove.md"
      }), "\n\"Theming & layout\"; brief 00 contract). Make it visible:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Default Grove theme"
        }), " — the immediately.run brand (your baseline across all briefs)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Three alternate themes"
        }), ", each a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "CSS-only"
        }), " re-skin of the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "same DOM/components"
        }), ",\nkeyed to the real use cases so they double as showcase art:", "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
          children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                children: "pixies"
              })
            }), " — a saturated, high-contrast music theme (think gig-poster): bolder\ngradient use, heavier display type, denser grid. Proves \"loud\" is reachable."]
          }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                children: "family-journal"
              })
            }), " — soft, warm-leaning-within-tokens, generous whitespace, photo-\nforward ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "post"
            }), " layout. Proves \"gentle/personal\" is reachable."]
          }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                children: "lotr"
              })
            }), " — a quiet, dense, parchment-ish reference theme: muted palette, serif-ish\nfeel achieved within the type system, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "doc"
            }), " layout with prominent ToC + infoboxes.\nProves \"encyclopedic/archival\" is reachable."]
          }), "\n"]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Present them as a triptych of the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "same entry"
          })]
        }), " (e.g. one reference page) rendered\nunder each theme, side by side, with a caption that only the CSS changed. This single\ncomparison is the most persuasive asset in the whole set — it makes the product's\ncentral claim legible at a glance."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["For each theme, deliver the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "token overrides"
      }), " (the handful of ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "--bg"
      }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "--ink"
      }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "--accent"
      }), "/\ntype-family/radius values that define it) so a dev sees re-skinning is a small CSS diff,\nnot a rebuild. Keep them honest: only the look + the built-in layout shapes change; a\ngenuinely new structure is a fork (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "grove.md"
      }), " honesty note), not a theme."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "the-grove-app-mark-from-brief-00-delivered-here",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-grove-app-mark-from-brief-00-delivered-here"
      }), "The Grove app mark (from brief 00, delivered here)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Produce the asset set: the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "gradient rounded-tile app icon"
      }), " with the abstract\nnode-and-edge glyph; the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "tiny inline variant"
      }), " (rotated gradient square) for cramped\nchrome; the ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "grove"
        }), " wordmark"]
      }), " (Gabarito 800 lowercase); and a one-line lockup\n(mark + wordmark) for the nav. Light + dark. Unmistakably part of the immediately.run\nfamily, never a competing logo."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "accessibility-pass-every-state-both-themes",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "accessibility-pass-every-state-both-themes"
      }), "Accessibility pass (every state, both themes)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "AA contrast verified on default + all three alternate themes (the alternates are the risk\n— check them); state never conveyed by gradient/colour alone (broken links carry an icon +\ndotted underline, active sort carries a caret, etc.); skeletons and live regions announced\nsanely to assistive tech; full keyboard operability with the glow focus ring; semantic\nlandmarks/headings intact so agents and screen readers read the same structure."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "deliverable",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "deliverable"
      }), "Deliverable"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "The skeleton/empty/error/read-only templates; the four-theme showcase incl. the same-entry\ntriptych and per-theme token overrides; the app-mark asset set — all mobile + desktop, both\nthemes, with on-brand drafted copy for the shared empty/error strings."
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/design-briefs/grove/briefs/05-states-and-theming.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiY29kZSIsImVtIiwiaDEiLCJoMiIsImxpIiwib2wiLCJwIiwic3Ryb25nIiwidWwiLCJfcHJvdmlkZUNvbXBvbmVudHMiLCJjb21wb25lbnRzIiwiSGVhZGluZ0FuY2hvciIsIl9taXNzaW5nTWR4UmVmZXJlbmNlIiwianN4cyIsIkZyYWdtZW50IiwiY2hpbGRyZW4iLCJpZCIsImpzeCIsImhyZWYiLCJNRFhDb250ZW50Iiwid3JhcHBlciIsIk1EWExheW91dCIsIl9jIiwiY29tcG9uZW50IiwicGxhY2UiLCJFcnJvciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIjA1LXN0YXRlcy1hbmQtdGhlbWluZy5tZCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKkBqc3hSdW50aW1lIGF1dG9tYXRpYyovXG4vKkBqc3hJbXBvcnRTb3VyY2UgcmVhY3QqL1xuaW1wb3J0IHt1c2VNRFhDb21wb25lbnRzIGFzIF9wcm92aWRlQ29tcG9uZW50c30gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrL01EWFByb3ZpZGVyXCI7XG5mdW5jdGlvbiBfY3JlYXRlTWR4Q29udGVudChwcm9wcykge1xuICBjb25zdCBfY29tcG9uZW50cyA9IHtcbiAgICBhOiBcImFcIixcbiAgICBjb2RlOiBcImNvZGVcIixcbiAgICBlbTogXCJlbVwiLFxuICAgIGgxOiBcImgxXCIsXG4gICAgaDI6IFwiaDJcIixcbiAgICBsaTogXCJsaVwiLFxuICAgIG9sOiBcIm9sXCIsXG4gICAgcDogXCJwXCIsXG4gICAgc3Ryb25nOiBcInN0cm9uZ1wiLFxuICAgIHVsOiBcInVsXCIsXG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9LCB7SGVhZGluZ0FuY2hvcn0gPSBfY29tcG9uZW50cztcbiAgaWYgKCFIZWFkaW5nQW5jaG9yKSBfbWlzc2luZ01keFJlZmVyZW5jZShcIkhlYWRpbmdBbmNob3JcIiwgdHJ1ZSk7XG4gIHJldHVybiA8PjxfY29tcG9uZW50cy5oMSBpZD1cImJyaWVmLTA1LXN0YXRlcy10aGUtdGhlbWluZy1zaG93Y2FzZS1hbmQtdGhlLWFwcC1tYXJrXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJicmllZi0wNS1zdGF0ZXMtdGhlLXRoZW1pbmctc2hvd2Nhc2UtYW5kLXRoZS1hcHAtbWFya1wiIC8+e1wiQnJpZWYgMDUg4oCUIFN0YXRlcywgdGhlIHRoZW1pbmcgc2hvd2Nhc2UsIGFuZCB0aGUgYXBwIG1hcmtcIn08L19jb21wb25lbnRzLmgxPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSB1bmdsYW1vcm91cy1idXQtbG9hZC1iZWFyaW5nIHN1cmZhY2VzLCBwbHVzIHRoZSBkZWxpdmVyYWJsZSB0aGF0IFwifTxfY29tcG9uZW50cy5lbT57XCJwcm92ZXNcIn08L19jb21wb25lbnRzLmVtPntcIiBHcm92ZSdzXFxuY29yZSBwcm9taXNlLiBBc3N1bWVzIFwifTxfY29tcG9uZW50cy5hIGhyZWY9XCIuLzAwLWZvdW5kYXRpb24ubWRcIj48X2NvbXBvbmVudHMuY29kZT57XCIwMC1mb3VuZGF0aW9uXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuYT57XCIuIFNvdXJjZTogXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZ3JvdmUubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIFxcXCJUaGVtaW5nICZcXG5sYXlvdXRcXFwiLCBcXFwiVHdvIHdheXMgdG8gdXNlIEdyb3ZlXFxcIiwgXFxcIkhvdyBpdCBmaXRzIHRoZSBwbGF0Zm9ybVxcXCIuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInVuaXZlcnNhbC1zdGF0ZXMtZGVzaWduLW9uY2UtcmVmZXJlbmNlLWV2ZXJ5d2hlcmVcIj48SGVhZGluZ0FuY2hvciBpZD1cInVuaXZlcnNhbC1zdGF0ZXMtZGVzaWduLW9uY2UtcmVmZXJlbmNlLWV2ZXJ5d2hlcmVcIiAvPntcIlVuaXZlcnNhbCBzdGF0ZXMgKGRlc2lnbiBvbmNlLCByZWZlcmVuY2UgZXZlcnl3aGVyZSlcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSBwZXItc3VyZmFjZSBicmllZnMgZWFjaCBjYWxsIHRoZWlyIG93biBzdGF0ZXM7IHRoaXMgYnJpZWYgZGVmaW5lcyB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJzaGFyZWRcXG50ZW1wbGF0ZXNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdGhleSByZXVzZSBzbyB0aGV5J3JlIGNvbnNpc3RlbnQ6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJMb2FkaW5nIOKAlCBza2VsZXRvbnMsIG5ldmVyIHNwaW5uZXJzLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBBIHNrZWxldG9uIGtpdCBtYXRjaGVkIHRvIEdyb3ZlJ3Mgc2hhcGVzOlxcbnByb3NlIGxpbmVzLCBlbnRyeSByb3dzLCBjYXJkcywgdGFibGUgcm93cywgVG9DIGdob3N0LCB0aW1lbGluZSBheGlzLCBncmFwaCBub2Rlcy4gVXNlXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1wYW5lbFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1wYW5lbC0yXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBibG9ja3Mgd2l0aCBhIHNsb3cgc2hpbW1lcjsgYnVkZ2V0IH4xNTBtcyBiZWZvcmUgYW55dGhpbmdcXG5hcHBlYXJzOyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInplcm8gbGF5b3V0IHNoaWZ0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChza2VsZXRvbnMgb2NjdXB5IHRoZSByZWFsIGJveCkuIFRoZSBsaW5rLWdyYXBoIG1vdGlmXFxuY2FuIHN0YW5kIGluIGZvciBhc3NldC9ncmFwaCBwbGFjZWhvbGRlcnMuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJFbXB0eSDigJQgZGVzaWduZWQsIGludGVudGlvbmFsLCBoZWxwZnVsLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBBIHJldXNhYmxlIGVtcHR5LXN0YXRlIGJsb2NrOiB0aGVcXG5saW5rLWdyYXBoIG1vdGlmIGFydCwgYSBvbmUtbGluZSBzZW50ZW5jZS1jYXNlIGV4cGxhbmF0aW9uLCBhbmQgKG9ubHkgaWYgd3JpdGFibGUpIG9uZVxcbmFjdGlvbiB0aGF0IGhhbmRzIHRvIHRoZSBob3N0LiBQZXItc3VyZmFjZSBjb3B5IGxpdmVzIGluIHRob3NlIGJyaWVmczsgdGhlIFwifTxfY29tcG9uZW50cy5lbT57XCJmcmFtZVwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGlzXFxuaGVyZS4gXFxcIk5vdGhpbmcgaGVyZVxcXCIgbXVzdCBsb29rIGNvbXBvc2VkLCBuZXZlciBicm9rZW4uXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJFcnJvciAvIDQwNCAvIGJyb2tlbiBsaW5rLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGUgd2lraS1zcGVjaWZpYyBjYXNlIG1hdHRlcnM6IGZvbGxvd2luZyBhIGJyb2tlbiBvclxcbmFtYmlndW91cyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJbW3dpa2ktbGlua11dXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBsYW5kcyBvbiBcXFwiTm8gZW50cnkgYXQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiL3NsdWdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLlxcXCIgd2l0aCB0aGUgY2xvc2VzdC1tYXRjaFxcbnN1Z2dlc3Rpb24gYW5kIGEgY3JlYXRlLWlmLXdyaXRhYmxlIGhhbmQtb2ZmLiBBbHNvOiBhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibW91bnQvcGVybWlzc2lvbiBlcnJvclwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoYVxcbnNwYWNlIHRoZSBhcHAgY2FuJ3QgcmVhZCDihpIgXFxcIlRoaXMgc3BhY2UgaXNuJ3QgYXZhaWxhYmxlLlxcXCIgd2l0aCBhIGNhbG0gZXhwbGFuYXRpb24sIG5ldmVyXFxuYSByYXcgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRVJPRlNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcImZvcmJpZGRlblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLCBhbmQgYSBnZW5lcmljIGxvYWQgZmFpbHVyZS4gQWxsIGRlc2lnbmVkLCBhbGwgb24tYnJhbmQsXFxubmV2ZXIgYSBzdGFjayB0cmFjZS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlJlYWQtb25seSB2aWV3ZXIuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRoZSB3aG9sZSBhcHAgbWludXMgZXZlcnkgYXV0aG9yaW5nIGFmZm9yZGFuY2UgKG5vIGVkaXQgcGVuY2lsLFxcbm5vIG5ldy1lbnRyeSwgbm8gYXNrLXRoZS1hZ2VudCkuIERlc2lnbiB0aGlzIGFzIGEgZmlyc3QtY2xhc3MgdmFyaWFudCDigJQgYW4gYW5vbnltb3VzXFxuc2hhcmUtbGluayByZWFkZXIgaXMgYSByZWFsLCBjb21tb24gdmlld2VyIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJncm92ZS5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgXFxcIkF1dGhvcmluZ1xcXCIsIFxcXCJIb3cgaXQgZml0cyB0aGVcXG5wbGF0Zm9ybVxcXCIpLiBJdCBzaG91bGQgZmVlbCBjb21wbGV0ZSwgbm90IFxcXCJsb2dnZWQgb3V0XFxcIi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMub2w+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwidGhlLXRoZW1pbmctc2hvd2Nhc2UtdGhlLXByb29mLWRlbGl2ZXJhYmxlXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJ0aGUtdGhlbWluZy1zaG93Y2FzZS10aGUtcHJvb2YtZGVsaXZlcmFibGVcIiAvPntcIlRoZSB0aGVtaW5nIHNob3djYXNlICh0aGUgcHJvb2YgZGVsaXZlcmFibGUpXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJHcm92ZSdzIHByb21pc2UgaXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJDU1Mtb25seSByZS1za2lubmluZyBvdmVyIHN0YWJsZSBjbGFzc2VzICsgdG9rZW5zXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJncm92ZS5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG5cXFwiVGhlbWluZyAmIGxheW91dFxcXCI7IGJyaWVmIDAwIGNvbnRyYWN0KS4gTWFrZSBpdCB2aXNpYmxlOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRGVmYXVsdCBHcm92ZSB0aGVtZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgdGhlIGltbWVkaWF0ZWx5LnJ1biBicmFuZCAoeW91ciBiYXNlbGluZSBhY3Jvc3MgYWxsIGJyaWVmcykuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaHJlZSBhbHRlcm5hdGUgdGhlbWVzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBlYWNoIGEgXCJ9PF9jb21wb25lbnRzLmVtPntcIkNTUy1vbmx5XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgcmUtc2tpbiBvZiB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJzYW1lIERPTS9jb21wb25lbnRzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLFxcbmtleWVkIHRvIHRoZSByZWFsIHVzZSBjYXNlcyBzbyB0aGV5IGRvdWJsZSBhcyBzaG93Y2FzZSBhcnQ6XCJ9e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPjxfY29tcG9uZW50cy5jb2RlPntcInBpeGllc1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIGEgc2F0dXJhdGVkLCBoaWdoLWNvbnRyYXN0IG11c2ljIHRoZW1lICh0aGluayBnaWctcG9zdGVyKTogYm9sZGVyXFxuZ3JhZGllbnQgdXNlLCBoZWF2aWVyIGRpc3BsYXkgdHlwZSwgZGVuc2VyIGdyaWQuIFByb3ZlcyBcXFwibG91ZFxcXCIgaXMgcmVhY2hhYmxlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+PF9jb21wb25lbnRzLmNvZGU+e1wiZmFtaWx5LWpvdXJuYWxcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBzb2Z0LCB3YXJtLWxlYW5pbmctd2l0aGluLXRva2VucywgZ2VuZXJvdXMgd2hpdGVzcGFjZSwgcGhvdG8tXFxuZm9yd2FyZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJwb3N0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBsYXlvdXQuIFByb3ZlcyBcXFwiZ2VudGxlL3BlcnNvbmFsXFxcIiBpcyByZWFjaGFibGUuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz48X2NvbXBvbmVudHMuY29kZT57XCJsb3RyXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgYSBxdWlldCwgZGVuc2UsIHBhcmNobWVudC1pc2ggcmVmZXJlbmNlIHRoZW1lOiBtdXRlZCBwYWxldHRlLCBzZXJpZi1pc2hcXG5mZWVsIGFjaGlldmVkIHdpdGhpbiB0aGUgdHlwZSBzeXN0ZW0sIFwifTxfY29tcG9uZW50cy5jb2RlPntcImRvY1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgbGF5b3V0IHdpdGggcHJvbWluZW50IFRvQyArIGluZm9ib3hlcy5cXG5Qcm92ZXMgXFxcImVuY3ljbG9wZWRpYy9hcmNoaXZhbFxcXCIgaXMgcmVhY2hhYmxlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlByZXNlbnQgdGhlbSBhcyBhIHRyaXB0eWNoIG9mIHRoZSBcIn08X2NvbXBvbmVudHMuZW0+e1wic2FtZSBlbnRyeVwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChlLmcuIG9uZSByZWZlcmVuY2UgcGFnZSkgcmVuZGVyZWRcXG51bmRlciBlYWNoIHRoZW1lLCBzaWRlIGJ5IHNpZGUsIHdpdGggYSBjYXB0aW9uIHRoYXQgb25seSB0aGUgQ1NTIGNoYW5nZWQuIFRoaXMgc2luZ2xlXFxuY29tcGFyaXNvbiBpcyB0aGUgbW9zdCBwZXJzdWFzaXZlIGFzc2V0IGluIHRoZSB3aG9sZSBzZXQg4oCUIGl0IG1ha2VzIHRoZSBwcm9kdWN0J3NcXG5jZW50cmFsIGNsYWltIGxlZ2libGUgYXQgYSBnbGFuY2UuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkZvciBlYWNoIHRoZW1lLCBkZWxpdmVyIHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInRva2VuIG92ZXJyaWRlc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAodGhlIGhhbmRmdWwgb2YgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1iZ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1pbmtcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcIi0tYWNjZW50XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cXG50eXBlLWZhbWlseS9yYWRpdXMgdmFsdWVzIHRoYXQgZGVmaW5lIGl0KSBzbyBhIGRldiBzZWVzIHJlLXNraW5uaW5nIGlzIGEgc21hbGwgQ1NTIGRpZmYsXFxubm90IGEgcmVidWlsZC4gS2VlcCB0aGVtIGhvbmVzdDogb25seSB0aGUgbG9vayArIHRoZSBidWlsdC1pbiBsYXlvdXQgc2hhcGVzIGNoYW5nZTsgYVxcbmdlbnVpbmVseSBuZXcgc3RydWN0dXJlIGlzIGEgZm9yayAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZ3JvdmUubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGhvbmVzdHkgbm90ZSksIG5vdCBhIHRoZW1lLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJ0aGUtZ3JvdmUtYXBwLW1hcmstZnJvbS1icmllZi0wMC1kZWxpdmVyZWQtaGVyZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwidGhlLWdyb3ZlLWFwcC1tYXJrLWZyb20tYnJpZWYtMDAtZGVsaXZlcmVkLWhlcmVcIiAvPntcIlRoZSBHcm92ZSBhcHAgbWFyayAoZnJvbSBicmllZiAwMCwgZGVsaXZlcmVkIGhlcmUpXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJQcm9kdWNlIHRoZSBhc3NldCBzZXQ6IHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImdyYWRpZW50IHJvdW5kZWQtdGlsZSBhcHAgaWNvblwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB3aXRoIHRoZSBhYnN0cmFjdFxcbm5vZGUtYW5kLWVkZ2UgZ2x5cGg7IHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInRpbnkgaW5saW5lIHZhcmlhbnRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHJvdGF0ZWQgZ3JhZGllbnQgc3F1YXJlKSBmb3IgY3JhbXBlZFxcbmNocm9tZTsgdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+PF9jb21wb25lbnRzLmNvZGU+e1wiZ3JvdmVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHdvcmRtYXJrXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChHYWJhcml0byA4MDAgbG93ZXJjYXNlKTsgYW5kIGEgb25lLWxpbmUgbG9ja3VwXFxuKG1hcmsgKyB3b3JkbWFyaykgZm9yIHRoZSBuYXYuIExpZ2h0ICsgZGFyay4gVW5taXN0YWthYmx5IHBhcnQgb2YgdGhlIGltbWVkaWF0ZWx5LnJ1blxcbmZhbWlseSwgbmV2ZXIgYSBjb21wZXRpbmcgbG9nby5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwiYWNjZXNzaWJpbGl0eS1wYXNzLWV2ZXJ5LXN0YXRlLWJvdGgtdGhlbWVzXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJhY2Nlc3NpYmlsaXR5LXBhc3MtZXZlcnktc3RhdGUtYm90aC10aGVtZXNcIiAvPntcIkFjY2Vzc2liaWxpdHkgcGFzcyAoZXZlcnkgc3RhdGUsIGJvdGggdGhlbWVzKVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiQUEgY29udHJhc3QgdmVyaWZpZWQgb24gZGVmYXVsdCArIGFsbCB0aHJlZSBhbHRlcm5hdGUgdGhlbWVzICh0aGUgYWx0ZXJuYXRlcyBhcmUgdGhlIHJpc2tcXG7igJQgY2hlY2sgdGhlbSk7IHN0YXRlIG5ldmVyIGNvbnZleWVkIGJ5IGdyYWRpZW50L2NvbG91ciBhbG9uZSAoYnJva2VuIGxpbmtzIGNhcnJ5IGFuIGljb24gK1xcbmRvdHRlZCB1bmRlcmxpbmUsIGFjdGl2ZSBzb3J0IGNhcnJpZXMgYSBjYXJldCwgZXRjLik7IHNrZWxldG9ucyBhbmQgbGl2ZSByZWdpb25zIGFubm91bmNlZFxcbnNhbmVseSB0byBhc3Npc3RpdmUgdGVjaDsgZnVsbCBrZXlib2FyZCBvcGVyYWJpbGl0eSB3aXRoIHRoZSBnbG93IGZvY3VzIHJpbmc7IHNlbWFudGljXFxubGFuZG1hcmtzL2hlYWRpbmdzIGludGFjdCBzbyBhZ2VudHMgYW5kIHNjcmVlbiByZWFkZXJzIHJlYWQgdGhlIHNhbWUgc3RydWN0dXJlLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJkZWxpdmVyYWJsZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiZGVsaXZlcmFibGVcIiAvPntcIkRlbGl2ZXJhYmxlXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgc2tlbGV0b24vZW1wdHkvZXJyb3IvcmVhZC1vbmx5IHRlbXBsYXRlczsgdGhlIGZvdXItdGhlbWUgc2hvd2Nhc2UgaW5jbC4gdGhlIHNhbWUtZW50cnlcXG50cmlwdHljaCBhbmQgcGVyLXRoZW1lIHRva2VuIG92ZXJyaWRlczsgdGhlIGFwcC1tYXJrIGFzc2V0IHNldCDigJQgYWxsIG1vYmlsZSArIGRlc2t0b3AsIGJvdGhcXG50aGVtZXMsIHdpdGggb24tYnJhbmQgZHJhZnRlZCBjb3B5IGZvciB0aGUgc2hhcmVkIGVtcHR5L2Vycm9yIHN0cmluZ3MuXCJ9PC9fY29tcG9uZW50cy5wPjwvPjtcbn1cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE1EWENvbnRlbnQocHJvcHMgPSB7fSkge1xuICBjb25zdCB7d3JhcHBlcjogTURYTGF5b3V0fSA9IHtcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH07XG4gIHJldHVybiBNRFhMYXlvdXQgPyA8TURYTGF5b3V0IHsuLi5wcm9wc30+PF9jcmVhdGVNZHhDb250ZW50IHsuLi5wcm9wc30gLz48L01EWExheW91dD4gOiBfY3JlYXRlTWR4Q29udGVudChwcm9wcyk7XG59XG5mdW5jdGlvbiBfbWlzc2luZ01keFJlZmVyZW5jZShpZCwgY29tcG9uZW50LCBwbGFjZSkge1xuICB0aHJvdyBuZXcgRXJyb3IoXCJFeHBlY3RlZCBcIiArIChjb21wb25lbnQgPyBcImNvbXBvbmVudFwiIDogXCJvYmplY3RcIikgKyBcIiBgXCIgKyBpZCArIFwiYCB0byBiZSBkZWZpbmVkOiB5b3UgbGlrZWx5IGZvcmdvdCB0byBpbXBvcnQsIHBhc3MsIG9yIHByb3ZpZGUgaXQuXCIgKyAocGxhY2UgPyBcIlxcbkl04oCZcyByZWZlcmVuY2VkIGluIHlvdXIgY29kZSBhdCBgXCIgKyBwbGFjZSArIFwiYCBpbiBgL2FwcC9kb2NzL2Rlc2lnbi1icmllZnMvZ3JvdmUvYnJpZWZzLzA1LXN0YXRlcy1hbmQtdGhlbWluZy5tZGBcIiA6IFwiXCIpKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQXdGLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUZ4RjtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU1DLFdBQVcsR0FBRztNQUNsQkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsSUFBSSxFQUFFLE1BQU07TUFDWkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsTUFBTSxFQUFFLFFBQVE7TUFDaEJDLEVBQUUsRUFBRSxJQUFJO01BQ1IsR0FBRyxJQUFBQyw2QkFBa0IsRUFBQyxDQUFDO01BQ3ZCLEdBQUdaLEtBQUssQ0FBQ2E7SUFDWCxDQUFDO0lBQUU7TUFBQ0M7SUFBYSxDQUFDLEdBQUdiLFdBQVc7RUFDaEMsSUFBSSxDQUFDYSxhQUFhLEVBQUVDLG9CQUFvQixDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUM7RUFDL0Qsb0JBQU8sSUFBQWpCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQWxCLFdBQUEsQ0FBQW1CLFFBQUE7SUFBQUMsUUFBQSxnQkFBRSxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNJLEVBQUU7TUFBQ2MsRUFBRSxFQUFDLHVEQUF1RDtNQUFBRCxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQXVELENBQUUsQ0FBQyxFQUFDLDJEQUEyRDtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDUSxDQUFDO01BQUFTLFFBQUEsR0FBRSx1RUFBdUUsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRyxFQUFFO1FBQUFjLFFBQUEsRUFBRTtNQUFRLENBQWlCLENBQUMsRUFBQyxrQ0FBa0MsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDQyxDQUFDO1FBQUNtQixJQUFJLEVBQUMsb0JBQW9CO1FBQUFILFFBQUEsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRSxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFlLENBQW1CO01BQUMsQ0FBZSxDQUFDLEVBQUMsWUFBWSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNFLElBQUk7UUFBQWUsUUFBQSxFQUFFO01BQVUsQ0FBbUIsQ0FBQyxFQUFDLGtGQUFrRjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDSyxFQUFFO01BQUNhLEVBQUUsRUFBQyxtREFBbUQ7TUFBQUQsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFtRCxDQUFFLENBQUMsRUFBQyxzREFBc0Q7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ1EsQ0FBQztNQUFBUyxRQUFBLEdBQUUsNEVBQTRFLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBbUIsQ0FBcUIsQ0FBQyxFQUFDLG9DQUFvQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTyxFQUFFO01BQUFVLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTSxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBc0MsQ0FBcUIsQ0FBQyxFQUFDLHNJQUFzSSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNFLElBQUk7VUFBQWUsUUFBQSxFQUFFO1FBQVMsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRSxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyx1RUFBdUUsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDUyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFtQixDQUFxQixDQUFDLEVBQUMsb0dBQW9HO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7UUFBQVcsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDUyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUF5QyxDQUFxQixDQUFDLEVBQUMseU1BQXlNLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0csRUFBRTtVQUFBYyxRQUFBLEVBQUU7UUFBTyxDQUFpQixDQUFDLEVBQUMsK0RBQStEO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7UUFBQVcsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDUyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUE0QixDQUFxQixDQUFDLEVBQUMsb0VBQW9FLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBZSxDQUFtQixDQUFDLEVBQUMsMEJBQTBCLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBTyxDQUFtQixDQUFDLEVBQUMsb0ZBQW9GLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBd0IsQ0FBcUIsQ0FBQyxFQUFDLHdHQUF3RyxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNFLElBQUk7VUFBQWUsUUFBQSxFQUFFO1FBQU8sQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRSxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyxrRkFBa0Y7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ00sRUFBRTtRQUFBVyxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQW1CLENBQXFCLENBQUMsRUFBQyxzTUFBc00sZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRSxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQyw4RkFBOEY7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDSyxFQUFFO01BQUNhLEVBQUUsRUFBQyw0Q0FBNEM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUE0QyxDQUFFLENBQUMsRUFBQyw4Q0FBOEM7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ1EsQ0FBQztNQUFBUyxRQUFBLEdBQUUscUJBQXFCLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBbUQsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRSxJQUFJO1FBQUFlLFFBQUEsRUFBRTtNQUFVLENBQW1CLENBQUMsRUFBQyw4REFBOEQ7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ1UsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ00sRUFBRTtRQUFBVyxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQXFCLENBQXFCLENBQUMsRUFBQyxpRUFBaUU7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ00sRUFBRTtRQUFBVyxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQXdCLENBQXFCLENBQUMsRUFBQyxXQUFXLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0csRUFBRTtVQUFBYyxRQUFBLEVBQUU7UUFBVSxDQUFpQixDQUFDLEVBQUMsa0JBQWtCLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBcUIsQ0FBcUIsQ0FBQyxFQUFDLGdFQUFnRSxFQUFFLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNVLEVBQUU7VUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDUyxNQUFNO2NBQUFRLFFBQUEsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRSxJQUFJO2dCQUFBZSxRQUFBLEVBQUU7Y0FBUSxDQUFtQjtZQUFDLENBQW9CLENBQUMsRUFBQyxzSkFBc0o7VUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ00sRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07Y0FBQVEsUUFBQSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNFLElBQUk7Z0JBQUFlLFFBQUEsRUFBRTtjQUFnQixDQUFtQjtZQUFDLENBQW9CLENBQUMsRUFBQyw0RUFBNEUsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRSxJQUFJO2NBQUFlLFFBQUEsRUFBRTtZQUFNLENBQW1CLENBQUMsRUFBQyxtREFBbUQ7VUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ00sRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07Y0FBQVEsUUFBQSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNFLElBQUk7Z0JBQUFlLFFBQUEsRUFBRTtjQUFNLENBQW1CO1lBQUMsQ0FBb0IsQ0FBQyxFQUFDLG9IQUFvSCxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNFLElBQUk7Y0FBQWUsUUFBQSxFQUFFO1lBQUssQ0FBbUIsQ0FBQyxFQUFDLHlGQUF5RjtVQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO1FBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ00sRUFBRTtRQUFBVyxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEdBQUUsb0NBQW9DLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0csRUFBRTtZQUFBYyxRQUFBLEVBQUU7VUFBWSxDQUFpQixDQUFDO1FBQUEsQ0FBb0IsQ0FBQyxFQUFDLG1QQUFtUDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNRLENBQUM7TUFBQVMsUUFBQSxHQUFFLDhCQUE4QixlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQWlCLENBQXFCLENBQUMsRUFBQyxtQkFBbUIsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRSxJQUFJO1FBQUFlLFFBQUEsRUFBRTtNQUFNLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBZSxRQUFBLEVBQUU7TUFBTyxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNFLElBQUk7UUFBQWUsUUFBQSxFQUFFO01BQVUsQ0FBbUIsQ0FBQyxFQUFDLHlOQUF5TixlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNFLElBQUk7UUFBQWUsUUFBQSxFQUFFO01BQVUsQ0FBbUIsQ0FBQyxFQUFDLDhCQUE4QjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDSyxFQUFFO01BQUNhLEVBQUUsRUFBQyxpREFBaUQ7TUFBQUQsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFpRCxDQUFFLENBQUMsRUFBQyxvREFBb0Q7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ1EsQ0FBQztNQUFBUyxRQUFBLEdBQUUsNkJBQTZCLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBZ0MsQ0FBcUIsQ0FBQyxFQUFDLCtDQUErQyxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQXFCLENBQXFCLENBQUMsRUFBQyxzREFBc0QsZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNTLE1BQU07UUFBQVEsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRSxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFPLENBQW1CLENBQUMsRUFBQyxXQUFXO01BQUEsQ0FBcUIsQ0FBQyxFQUFDLDBLQUEwSztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDSyxFQUFFO01BQUNhLEVBQUUsRUFBQyw0Q0FBNEM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUE0QyxDQUFFLENBQUMsRUFBQywrQ0FBK0M7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNRLENBQUM7TUFBQVMsUUFBQSxFQUFFO0lBQTRiLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDSyxFQUFFO01BQUNhLEVBQUUsRUFBQyxhQUFhO01BQUFELFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBYSxDQUFFLENBQUMsRUFBQyxhQUFhO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDUSxDQUFDO01BQUFTLFFBQUEsRUFBRTtJQUFpUSxDQUFnQixDQUFDO0VBQUEsQ0FBRSxDQUFDO0FBQzNuUTtBQUNlLFNBQVNJLFVBQVVBLENBQUN0QixLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUU7RUFDN0MsTUFBTTtJQUFDdUIsT0FBTyxFQUFFQztFQUFTLENBQUMsR0FBRztJQUMzQixHQUFHLElBQUFaLDZCQUFrQixFQUFDLENBQUM7SUFDdkIsR0FBR1osS0FBSyxDQUFDYTtFQUNYLENBQUM7RUFDRCxPQUFPVyxTQUFTLGdCQUFHLElBQUExQixXQUFBLENBQUFzQixHQUFBLEVBQUNJLFNBQVM7SUFBQSxHQUFLeEIsS0FBSztJQUFBa0IsUUFBQSxlQUFFLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNyQixpQkFBaUI7TUFBQSxHQUFLQztJQUFLLENBQUc7RUFBQyxDQUFXLENBQUMsR0FBR0QsaUJBQWlCLENBQUNDLEtBQUssQ0FBQztBQUNsSDtBQUFDeUIsRUFBQSxHQU51QkgsVUFBVTtBQU9sQyxTQUFTUCxvQkFBb0JBLENBQUNJLEVBQUUsRUFBRU8sU0FBUyxFQUFFQyxLQUFLLEVBQUU7RUFDbEQsTUFBTSxJQUFJQyxLQUFLLENBQUMsV0FBVyxJQUFJRixTQUFTLEdBQUcsV0FBVyxHQUFHLFFBQVEsQ0FBQyxHQUFHLElBQUksR0FBR1AsRUFBRSxHQUFHLG9FQUFvRSxJQUFJUSxLQUFLLEdBQUcscUNBQXFDLEdBQUdBLEtBQUssR0FBRyxzRUFBc0UsR0FBRyxFQUFFLENBQUMsQ0FBQztBQUNoUztBQUFDLElBQUFGLEVBQUE7QUFBQUksWUFBQSxDQUFBSixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}