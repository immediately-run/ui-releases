var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      li: "li",
      ol: "ol",
      p: "p",
      strong: "strong",
      table: "table",
      tbody: "tbody",
      td: "td",
      th: "th",
      thead: "thead",
      tr: "tr",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "design-handoff-grove-an-mdx-wiki-engine",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "design-handoff-grove-an-mdx-wiki-engine"
      }), "Design handoff — Grove, an MDX wiki engine"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Read this first."
      }), " It's the self-contained on-ramp for designing the visual assets\nneeded to build ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Grove"
      }), ". With this doc plus the briefs in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "./briefs/",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "briefs/"
        })
      }), ", you\nhave everything you need to produce the layouts, components, states, and brand assets."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "For:"
      }), " Claude Design (or any designer, human or agent) generating Grove's UI.\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Source of truth:"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "docs/product-defs/grove.md"
        }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "the product"
        }), " (what Grove is, every feature named\nbelow traces to a section there). Read it before the briefs."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/index.css"
        }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "the tokens"
        }), " (the contract; pull every colour, font, radius,\nshadow from here — don't eyeball)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "CLAUDE.md"
        }), " \"Design system\" — voice + visual foundations for the immediately.run\nbrand Grove lives inside."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "what-youre-designing-in-one-paragraph",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "what-youre-designing-in-one-paragraph"
      }), "What you're designing, in one paragraph"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Grove is a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "wiki / knowledge-garden engine"
      }), " that runs as one immediately.run app: every\nentry is a single MDX file, entries interlink with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "[[wiki-links]]"
      }), ", and the whole site\nrenders in the browser. You are designing ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "the reading experience, the run-mode chrome,\nand Grove's own embedded agent conversation"
      }), " — the entry page, the navigation, the\nindex/collection surfaces, the built-in components, the extensibility views, ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["the embedded\nGrove agent conversation (Grove's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "primary"
        }), " authoring surface)"]
      }), ", every\nempty/loading/error state, a small Grove brand mark, and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "the default theme plus two or\nthree alternate themes"
      }), " that prove Grove can be re-skinned by editing CSS alone. You are\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "not"
      }), " designing a code ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "editor"
      }), " or any sign-in — those stay ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "host"
      }), " surfaces Grove\ndelegates to. You ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "are"
      }), " designing Grove's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "embedded agent conversation"
      }), ": the app's own\ncapability-scoped agent (each ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "CLAUDE.md"
      }), " security model §8), which is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "distinct from, and\nnever a spoof of,"
      }), " the host's agent pane (see ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "Hard constraints"
      }), ")."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "grove-is-an-app-in-the-immediatelyrun-design-system-not-a-new-brand",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "grove-is-an-app-in-the-immediatelyrun-design-system-not-a-new-brand"
      }), "Grove is an app ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "in"
      }), " the immediately.run design system — not a new brand"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Inherit the brand wholesale: cool near-black canvas, the magenta↔violet signature\ngradient, Gabarito display / Public Sans body / Space Mono details, hairline borders, the\nhard-offset hover shadow, sentence case, headlines that end on a period, no emoji. Pull\nall of it from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/index.css"
      }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "CLAUDE.md"
      }), " \"Design system\". The ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "default Grove\ntheme"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "is"
      }), " the immediately.run brand applied to a wiki. (Brief ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "00-foundation"
      }), " lists the\nfew Grove-specific motifs layered on top.)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "audience-rule-every-surface-in-priority-order",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "audience-rule-every-surface-in-priority-order"
      }), "Audience rule (every surface, in priority order)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The platform's audience priority (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "product_values"
      }), " §2/§5/§8), specialised for Grove:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Readers"
        }), " — mobile-first; the reading surface is the product. Typography, link\nintegrity, fast first paint. Most visits never edit."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Authors, including non-technical ones"
        }), " — they mostly ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "ask the agent"
        }), "; the manual\nediting affordance is a fallback. Design clean, discoverable affordances, not an\nauthor console."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Coding agents"
        }), " — semantic landmarks, stable structure, clean headings; agents read\nthe same DOM screen readers do."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "A desktop-human-only design is wrong here."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "the-two-themes-problem-a-core-deliverable-not-a-flourish",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-two-themes-problem-a-core-deliverable-not-a-flourish"
      }), "The two themes problem (a core deliverable, not a flourish)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Grove's product promise is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "CSS-only theming"
      }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "grove.md"
      }), " \"Theming & layout\"). That has\na concrete design consequence: every surface must be built from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "stable, semantic class\nnames + design tokens"
      }), ", never bespoke one-off styling, so a fork can re-skin by editing\nCSS. To prove it, you deliver:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The default theme"
        }), " — on the immediately.run brand."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Two–three alternate themes"
        }), " keyed to the real use cases (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "grove.md"
        }), " \"Representative\nuse cases\"): e.g. a saturated ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Pixies"
        }), " music theme, a soft ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "family-journal"
        }), " theme, a\nparchment-ish ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Lord of the Rings"
        }), " theme — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "same components and DOM, different CSS."
        }), "\nShow the same entry rendered under each, side by side, to make the claim visible."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "the-asset-screen-inventory-what-the-briefs-cover",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-asset-screen-inventory-what-the-briefs-cover"
      }), "The asset / screen inventory (what the briefs cover)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Brief"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Surface"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Why it matters"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "00-foundation"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Grove-specific motifs, the class-name/token contract, the app mark"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "the shared base every other brief assumes"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "01-reading-view"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "the entry page: MDX prose, entry header, backlinks, ToC, wiki-link styling, layout variants"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "the hero surface — readers live here"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "02-shell-navigation-and-authoring"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["top nav, sidebar (tag-driven + namespace tree), footer, search, theme toggle, mobile chrome, the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "edit / new-entry / ask-the-agent affordances"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "how you move through a Grove and hand off to the host"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "03-indexes-and-component-library"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["home/index, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "<DocList>"
            }), " feeds, tag pages, tag cloud, recently-updated, and each built-in component's appearance + an author ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "<Infobox>"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "discovery + the component vocabulary"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "04-extensibility-views"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["the agent-built views: animated ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "timeline"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "family tree"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "directory/table"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "proves the extension surface is designable"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "05-states-and-theming"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["loading skeletons, empty, error/404/broken-link, read-only viewer; the default + alternate ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "theme showcase"
            }), "; the Grove app icon"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "the unglamorous surfaces + the themeability proof"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "06-agent-conversation"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Grove's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "embedded coding-agent conversation"
            }), " — an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "integral, always-present"
            }), " surface with a minimal non-obscuring resting affordance (Safari-URL-bar style; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "iterate"
            }), " the form), proposed-change previews, all states, mobile, the workbench hand-off"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Grove's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "primary authoring surface"
            }), ", baked in front and center"]
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "groves-foundation-is-the-agent-contract-and-its-mostly-invisible-to-you",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "groves-foundation-is-the-agent-contract-and-its-mostly-invisible-to-you"
      }), "Grove's foundation is the agent contract — and it's mostly invisible to you"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Grove's single most important property is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "agent legibility"
      }), ": every instance carries a\nself-describing ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "contract"
      }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "grove.md"
      }), " \"The agent contract\") so a future coding-agent\nsession re-derives how ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "this"
      }), " wiki works. That contract is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "agent-facing infrastructure,\nnot a surface you style"
      }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "GROVE.md"
      }), " and the generated ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: ".grove/manifest.json"
      }), " are read by\nagents, and validation/drift ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "diagnostics surface through the host edit experience"
      }), ",\nwhich Grove must not imitate (see constraint 1). So it changes little about what you draw —\nbut you should know it's the product's centre of gravity, and it has these visual\ntouchpoints to get right:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Make conventions legible ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "in the content itself"
          })]
        }), " — this is why wiki-link states\n(resolved / broken / ambiguous), tag chips, and the namespace tree must read clearly\n(briefs 00–02). The structure a reader sees is the same structure an agent reads."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The embedded Grove agent (brief 06) is the contract's working interface"
        }), " — it's the\ncontract-aware agent that reads and updates ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "GROVE.md"
        }), ". Designing that conversation well\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "is"
        }), " designing how most users touch the contract, even though the contract files\nthemselves stay unstyled."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "An optional \"about this wiki\" / colophon entry"
        }), " — a human-readable rendering of the\ninstance's conventions (what tags mean, what custom components exist) is just a normal\nMDX entry rendered in the reading view; design no special chrome for it, but a tasteful\ncolophon/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "/about"
        }), " pattern is a welcome example. Never render a fake \"diagnostics panel\"\nor host editor chrome."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "hard-constraints-read-before-drawing-anything",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "hard-constraints-read-before-drawing-anything"
      }), "Hard constraints (read before drawing anything)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Don't imitate host chrome — but Grove's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "own"
          }), " agent is allowed"]
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "grove.md"
        }), " security\nmodel + \"Authoring\"; each ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "CLAUDE.md"
        }), " §8). Grove must ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "never"
        }), " render a fake code\neditor, a fake ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "host"
        }), " agent pane, a fake consent dialog, a fake validation/diagnostics\npanel, or a sign-in. When the user edits ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "text"
        }), ", Grove shows an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "edit affordance"
        }), "\nthat ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "hands off"
        }), " to the platform editor — design the affordance, not the editor; contract\nvalidation/drift ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "diagnostics are a host surface"
        }), " too. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The one exception is the\nagent conversation:"
        }), " Grove deliberately ships its ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "own"
        }), " embedded agent (brief 06),\nscoped to Grove's grants via the SDK catalog — so you ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "do"
        }), " design that surface. It must\nbe clearly ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Grove's own"
        }), " (its own placement/identity within the app), never styled to\npass as the host's trusted agent pane, and privileged actions (writes, contribute) still\nroute through the host. Spoofing host surfaces reads as hostile; building your own\ncapability-scoped agent does not."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Reading-first, with the agent as the deliberate always-present exception."
        }), " Run-mode\nUI stays free of ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "editor"
        }), " chrome; the edit affordance is unobtrusive and writable-only;\nthe ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "read-only viewer"
        }), " has no edit affordance at all. But the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "agent communication is\nbaked in, front and center"
        }), " — always present and one gesture away (brief 06). Reconcile\nthe two the way the iOS Safari URL bar does: a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "minimal persistent affordance"
        }), " (thin\nbottom input line / pull tab / icon) that ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "never obscures content on mobile"
        }), " and\nexpands only on demand. Front-and-center, not in-the-way."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Tokens are the contract."
        }), " Colours/fonts/radii/shadows come from\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/index.css"
        }), ". No hard-coded hexes in mockups you'd want a dev to copy."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "No emoji, ever."
        }), " Icons are ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Lucide"
        }), " (16–24px, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "currentColor"
        }), ", ~1.75 stroke) plus\nthe unicode micro-set (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "★ → ● ☀ ☾"
        }), "). Mono micro-labels are the one UPPERCASE-tracked\nexception."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Every dynamic surface needs four states:"
        }), " loading (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "skeleton"
        }), ", not spinner;\n~150ms budget), content, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "empty"
        }), " (designed, never broken), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "error/404"
        }), " (incl. a\nbroken/ambiguous ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "[[wiki-link]]"
        }), " target)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Accessibility AA on both themes"
        }), ", full keyboard operability, visible focus rings\n(the glow ring), semantic landmarks/headings, never state-by-gradient-alone."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "deliverable-per-brief",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "deliverable-per-brief"
      }), "Deliverable per brief"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Layouts at ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "mobile + desktop"
      }), ", all four states, interaction/transition notes (restrained\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "~.14s"
      }), ", no bounce/spring; respect ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "prefers-reduced-motion"
      }), "), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "drafted on-brand copy"
      }), " for\nthe key strings (sentence case, period-terminated headlines, mono ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "/slug"
      }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "#tag"
      }), "\nlabels), a ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["component inventory mapped to the tokens and to the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".grove-*"
        }), " class names"]
      }), "\nin brief ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "00"
      }), ", and — where relevant — the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "routes"
      }), " affordances point at (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "#/slug"
      }), " hash\nroutes within the app; the host hand-off for editing). Call out any forkability/theming\nnote specific to that surface."]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/design-briefs/grove/HANDOFF.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiY29kZSIsImVtIiwiaDEiLCJoMiIsImxpIiwib2wiLCJwIiwic3Ryb25nIiwidGFibGUiLCJ0Ym9keSIsInRkIiwidGgiLCJ0aGVhZCIsInRyIiwidWwiLCJfcHJvdmlkZUNvbXBvbmVudHMiLCJjb21wb25lbnRzIiwiSGVhZGluZ0FuY2hvciIsIl9taXNzaW5nTWR4UmVmZXJlbmNlIiwianN4cyIsIkZyYWdtZW50IiwiY2hpbGRyZW4iLCJpZCIsImpzeCIsImhyZWYiLCJNRFhDb250ZW50Iiwid3JhcHBlciIsIk1EWExheW91dCIsIl9jIiwiY29tcG9uZW50IiwicGxhY2UiLCJFcnJvciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkhBTkRPRkYubWQiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgYTogXCJhXCIsXG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgZW06IFwiZW1cIixcbiAgICBoMTogXCJoMVwiLFxuICAgIGgyOiBcImgyXCIsXG4gICAgbGk6IFwibGlcIixcbiAgICBvbDogXCJvbFwiLFxuICAgIHA6IFwicFwiLFxuICAgIHN0cm9uZzogXCJzdHJvbmdcIixcbiAgICB0YWJsZTogXCJ0YWJsZVwiLFxuICAgIHRib2R5OiBcInRib2R5XCIsXG4gICAgdGQ6IFwidGRcIixcbiAgICB0aDogXCJ0aFwiLFxuICAgIHRoZWFkOiBcInRoZWFkXCIsXG4gICAgdHI6IFwidHJcIixcbiAgICB1bDogXCJ1bFwiLFxuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfSwge0hlYWRpbmdBbmNob3J9ID0gX2NvbXBvbmVudHM7XG4gIGlmICghSGVhZGluZ0FuY2hvcikgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJIZWFkaW5nQW5jaG9yXCIsIHRydWUpO1xuICByZXR1cm4gPD48X2NvbXBvbmVudHMuaDEgaWQ9XCJkZXNpZ24taGFuZG9mZi1ncm92ZS1hbi1tZHgtd2lraS1lbmdpbmVcIj48SGVhZGluZ0FuY2hvciBpZD1cImRlc2lnbi1oYW5kb2ZmLWdyb3ZlLWFuLW1keC13aWtpLWVuZ2luZVwiIC8+e1wiRGVzaWduIGhhbmRvZmYg4oCUIEdyb3ZlLCBhbiBNRFggd2lraSBlbmdpbmVcIn08L19jb21wb25lbnRzLmgxPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUmVhZCB0aGlzIGZpcnN0LlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBJdCdzIHRoZSBzZWxmLWNvbnRhaW5lZCBvbi1yYW1wIGZvciBkZXNpZ25pbmcgdGhlIHZpc3VhbCBhc3NldHNcXG5uZWVkZWQgdG8gYnVpbGQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJHcm92ZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIi4gV2l0aCB0aGlzIGRvYyBwbHVzIHRoZSBicmllZnMgaW4gXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cIi4vYnJpZWZzL1wiPjxfY29tcG9uZW50cy5jb2RlPntcImJyaWVmcy9cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5hPntcIiwgeW91XFxuaGF2ZSBldmVyeXRoaW5nIHlvdSBuZWVkIHRvIHByb2R1Y2UgdGhlIGxheW91dHMsIGNvbXBvbmVudHMsIHN0YXRlcywgYW5kIGJyYW5kIGFzc2V0cy5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJGb3I6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIENsYXVkZSBEZXNpZ24gKG9yIGFueSBkZXNpZ25lciwgaHVtYW4gb3IgYWdlbnQpIGdlbmVyYXRpbmcgR3JvdmUncyBVSS5cXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlNvdXJjZSBvZiB0cnV0aDpcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuY29kZT57XCJkb2NzL3Byb2R1Y3QtZGVmcy9ncm92ZS5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1widGhlIHByb2R1Y3RcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHdoYXQgR3JvdmUgaXMsIGV2ZXJ5IGZlYXR1cmUgbmFtZWRcXG5iZWxvdyB0cmFjZXMgdG8gYSBzZWN0aW9uIHRoZXJlKS4gUmVhZCBpdCBiZWZvcmUgdGhlIGJyaWVmcy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuY29kZT57XCJzcmMvaW5kZXguY3NzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ0aGUgdG9rZW5zXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICh0aGUgY29udHJhY3Q7IHB1bGwgZXZlcnkgY29sb3VyLCBmb250LCByYWRpdXMsXFxuc2hhZG93IGZyb20gaGVyZSDigJQgZG9uJ3QgZXllYmFsbCkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLmNvZGU+e1wiQ0xBVURFLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBcXFwiRGVzaWduIHN5c3RlbVxcXCIg4oCUIHZvaWNlICsgdmlzdWFsIGZvdW5kYXRpb25zIGZvciB0aGUgaW1tZWRpYXRlbHkucnVuXFxuYnJhbmQgR3JvdmUgbGl2ZXMgaW5zaWRlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJ3aGF0LXlvdXJlLWRlc2lnbmluZy1pbi1vbmUtcGFyYWdyYXBoXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJ3aGF0LXlvdXJlLWRlc2lnbmluZy1pbi1vbmUtcGFyYWdyYXBoXCIgLz57XCJXaGF0IHlvdSdyZSBkZXNpZ25pbmcsIGluIG9uZSBwYXJhZ3JhcGhcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkdyb3ZlIGlzIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ3aWtpIC8ga25vd2xlZGdlLWdhcmRlbiBlbmdpbmVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdGhhdCBydW5zIGFzIG9uZSBpbW1lZGlhdGVseS5ydW4gYXBwOiBldmVyeVxcbmVudHJ5IGlzIGEgc2luZ2xlIE1EWCBmaWxlLCBlbnRyaWVzIGludGVybGluayB3aXRoIFwifTxfY29tcG9uZW50cy5jb2RlPntcIltbd2lraS1saW5rc11dXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgYW5kIHRoZSB3aG9sZSBzaXRlXFxucmVuZGVycyBpbiB0aGUgYnJvd3Nlci4gWW91IGFyZSBkZXNpZ25pbmcgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ0aGUgcmVhZGluZyBleHBlcmllbmNlLCB0aGUgcnVuLW1vZGUgY2hyb21lLFxcbmFuZCBHcm92ZSdzIG93biBlbWJlZGRlZCBhZ2VudCBjb252ZXJzYXRpb25cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHRoZSBlbnRyeSBwYWdlLCB0aGUgbmF2aWdhdGlvbiwgdGhlXFxuaW5kZXgvY29sbGVjdGlvbiBzdXJmYWNlcywgdGhlIGJ1aWx0LWluIGNvbXBvbmVudHMsIHRoZSBleHRlbnNpYmlsaXR5IHZpZXdzLCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInRoZSBlbWJlZGRlZFxcbkdyb3ZlIGFnZW50IGNvbnZlcnNhdGlvbiAoR3JvdmUncyBcIn08X2NvbXBvbmVudHMuZW0+e1wicHJpbWFyeVwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGF1dGhvcmluZyBzdXJmYWNlKVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgZXZlcnlcXG5lbXB0eS9sb2FkaW5nL2Vycm9yIHN0YXRlLCBhIHNtYWxsIEdyb3ZlIGJyYW5kIG1hcmssIGFuZCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInRoZSBkZWZhdWx0IHRoZW1lIHBsdXMgdHdvIG9yXFxudGhyZWUgYWx0ZXJuYXRlIHRoZW1lc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB0aGF0IHByb3ZlIEdyb3ZlIGNhbiBiZSByZS1za2lubmVkIGJ5IGVkaXRpbmcgQ1NTIGFsb25lLiBZb3UgYXJlXFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJub3RcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgZGVzaWduaW5nIGEgY29kZSBcIn08X2NvbXBvbmVudHMuZW0+e1wiZWRpdG9yXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgb3IgYW55IHNpZ24taW4g4oCUIHRob3NlIHN0YXkgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJob3N0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHN1cmZhY2VzIEdyb3ZlXFxuZGVsZWdhdGVzIHRvLiBZb3UgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJhcmVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgZGVzaWduaW5nIEdyb3ZlJ3MgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJlbWJlZGRlZCBhZ2VudCBjb252ZXJzYXRpb25cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCI6IHRoZSBhcHAncyBvd25cXG5jYXBhYmlsaXR5LXNjb3BlZCBhZ2VudCAoZWFjaCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJDTEFVREUubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHNlY3VyaXR5IG1vZGVsIMKnOCksIHdoaWNoIGlzIFwifTxfY29tcG9uZW50cy5lbT57XCJkaXN0aW5jdCBmcm9tLCBhbmRcXG5uZXZlciBhIHNwb29mIG9mLFwifTwvX2NvbXBvbmVudHMuZW0+e1wiIHRoZSBob3N0J3MgYWdlbnQgcGFuZSAoc2VlIFwifTxfY29tcG9uZW50cy5lbT57XCJIYXJkIGNvbnN0cmFpbnRzXCJ9PC9fY29tcG9uZW50cy5lbT57XCIpLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJncm92ZS1pcy1hbi1hcHAtaW4tdGhlLWltbWVkaWF0ZWx5cnVuLWRlc2lnbi1zeXN0ZW0tbm90LWEtbmV3LWJyYW5kXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJncm92ZS1pcy1hbi1hcHAtaW4tdGhlLWltbWVkaWF0ZWx5cnVuLWRlc2lnbi1zeXN0ZW0tbm90LWEtbmV3LWJyYW5kXCIgLz57XCJHcm92ZSBpcyBhbiBhcHAgXCJ9PF9jb21wb25lbnRzLmVtPntcImluXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgdGhlIGltbWVkaWF0ZWx5LnJ1biBkZXNpZ24gc3lzdGVtIOKAlCBub3QgYSBuZXcgYnJhbmRcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkluaGVyaXQgdGhlIGJyYW5kIHdob2xlc2FsZTogY29vbCBuZWFyLWJsYWNrIGNhbnZhcywgdGhlIG1hZ2VudGHihpR2aW9sZXQgc2lnbmF0dXJlXFxuZ3JhZGllbnQsIEdhYmFyaXRvIGRpc3BsYXkgLyBQdWJsaWMgU2FucyBib2R5IC8gU3BhY2UgTW9ubyBkZXRhaWxzLCBoYWlybGluZSBib3JkZXJzLCB0aGVcXG5oYXJkLW9mZnNldCBob3ZlciBzaGFkb3csIHNlbnRlbmNlIGNhc2UsIGhlYWRsaW5lcyB0aGF0IGVuZCBvbiBhIHBlcmlvZCwgbm8gZW1vamkuIFB1bGxcXG5hbGwgb2YgaXQgZnJvbSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvaW5kZXguY3NzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhbmQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQ0xBVURFLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBcXFwiRGVzaWduIHN5c3RlbVxcXCIuIFRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImRlZmF1bHQgR3JvdmVcXG50aGVtZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuZW0+e1wiaXNcIn08L19jb21wb25lbnRzLmVtPntcIiB0aGUgaW1tZWRpYXRlbHkucnVuIGJyYW5kIGFwcGxpZWQgdG8gYSB3aWtpLiAoQnJpZWYgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiMDAtZm91bmRhdGlvblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgbGlzdHMgdGhlXFxuZmV3IEdyb3ZlLXNwZWNpZmljIG1vdGlmcyBsYXllcmVkIG9uIHRvcC4pXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cImF1ZGllbmNlLXJ1bGUtZXZlcnktc3VyZmFjZS1pbi1wcmlvcml0eS1vcmRlclwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiYXVkaWVuY2UtcnVsZS1ldmVyeS1zdXJmYWNlLWluLXByaW9yaXR5LW9yZGVyXCIgLz57XCJBdWRpZW5jZSBydWxlIChldmVyeSBzdXJmYWNlLCBpbiBwcmlvcml0eSBvcmRlcilcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSBwbGF0Zm9ybSdzIGF1ZGllbmNlIHByaW9yaXR5IChcIn08X2NvbXBvbmVudHMuY29kZT57XCJwcm9kdWN0X3ZhbHVlc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgwqcyL8KnNS/CpzgpLCBzcGVjaWFsaXNlZCBmb3IgR3JvdmU6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJSZWFkZXJzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBtb2JpbGUtZmlyc3Q7IHRoZSByZWFkaW5nIHN1cmZhY2UgaXMgdGhlIHByb2R1Y3QuIFR5cG9ncmFwaHksIGxpbmtcXG5pbnRlZ3JpdHksIGZhc3QgZmlyc3QgcGFpbnQuIE1vc3QgdmlzaXRzIG5ldmVyIGVkaXQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJBdXRob3JzLCBpbmNsdWRpbmcgbm9uLXRlY2huaWNhbCBvbmVzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCB0aGV5IG1vc3RseSBcIn08X2NvbXBvbmVudHMuZW0+e1wiYXNrIHRoZSBhZ2VudFwifTwvX2NvbXBvbmVudHMuZW0+e1wiOyB0aGUgbWFudWFsXFxuZWRpdGluZyBhZmZvcmRhbmNlIGlzIGEgZmFsbGJhY2suIERlc2lnbiBjbGVhbiwgZGlzY292ZXJhYmxlIGFmZm9yZGFuY2VzLCBub3QgYW5cXG5hdXRob3IgY29uc29sZS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkNvZGluZyBhZ2VudHNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHNlbWFudGljIGxhbmRtYXJrcywgc3RhYmxlIHN0cnVjdHVyZSwgY2xlYW4gaGVhZGluZ3M7IGFnZW50cyByZWFkXFxudGhlIHNhbWUgRE9NIHNjcmVlbiByZWFkZXJzIGRvLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJBIGRlc2t0b3AtaHVtYW4tb25seSBkZXNpZ24gaXMgd3JvbmcgaGVyZS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwidGhlLXR3by10aGVtZXMtcHJvYmxlbS1hLWNvcmUtZGVsaXZlcmFibGUtbm90LWEtZmxvdXJpc2hcIj48SGVhZGluZ0FuY2hvciBpZD1cInRoZS10d28tdGhlbWVzLXByb2JsZW0tYS1jb3JlLWRlbGl2ZXJhYmxlLW5vdC1hLWZsb3VyaXNoXCIgLz57XCJUaGUgdHdvIHRoZW1lcyBwcm9ibGVtIChhIGNvcmUgZGVsaXZlcmFibGUsIG5vdCBhIGZsb3VyaXNoKVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiR3JvdmUncyBwcm9kdWN0IHByb21pc2UgaXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJDU1Mtb25seSB0aGVtaW5nXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJncm92ZS5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgXFxcIlRoZW1pbmcgJiBsYXlvdXRcXFwiKS4gVGhhdCBoYXNcXG5hIGNvbmNyZXRlIGRlc2lnbiBjb25zZXF1ZW5jZTogZXZlcnkgc3VyZmFjZSBtdXN0IGJlIGJ1aWx0IGZyb20gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJzdGFibGUsIHNlbWFudGljIGNsYXNzXFxubmFtZXMgKyBkZXNpZ24gdG9rZW5zXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBuZXZlciBiZXNwb2tlIG9uZS1vZmYgc3R5bGluZywgc28gYSBmb3JrIGNhbiByZS1za2luIGJ5IGVkaXRpbmdcXG5DU1MuIFRvIHByb3ZlIGl0LCB5b3UgZGVsaXZlcjpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlRoZSBkZWZhdWx0IHRoZW1lXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBvbiB0aGUgaW1tZWRpYXRlbHkucnVuIGJyYW5kLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVHdv4oCTdGhyZWUgYWx0ZXJuYXRlIHRoZW1lc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBrZXllZCB0byB0aGUgcmVhbCB1c2UgY2FzZXMgKFwifTxfY29tcG9uZW50cy5jb2RlPntcImdyb3ZlLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBcXFwiUmVwcmVzZW50YXRpdmVcXG51c2UgY2FzZXNcXFwiKTogZS5nLiBhIHNhdHVyYXRlZCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlBpeGllc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBtdXNpYyB0aGVtZSwgYSBzb2Z0IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZmFtaWx5LWpvdXJuYWxcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdGhlbWUsIGFcXG5wYXJjaG1lbnQtaXNoIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiTG9yZCBvZiB0aGUgUmluZ3NcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdGhlbWUg4oCUIFwifTxfY29tcG9uZW50cy5lbT57XCJzYW1lIGNvbXBvbmVudHMgYW5kIERPTSwgZGlmZmVyZW50IENTUy5cIn08L19jb21wb25lbnRzLmVtPntcIlxcblNob3cgdGhlIHNhbWUgZW50cnkgcmVuZGVyZWQgdW5kZXIgZWFjaCwgc2lkZSBieSBzaWRlLCB0byBtYWtlIHRoZSBjbGFpbSB2aXNpYmxlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJ0aGUtYXNzZXQtc2NyZWVuLWludmVudG9yeS13aGF0LXRoZS1icmllZnMtY292ZXJcIj48SGVhZGluZ0FuY2hvciBpZD1cInRoZS1hc3NldC1zY3JlZW4taW52ZW50b3J5LXdoYXQtdGhlLWJyaWVmcy1jb3ZlclwiIC8+e1wiVGhlIGFzc2V0IC8gc2NyZWVuIGludmVudG9yeSAod2hhdCB0aGUgYnJpZWZzIGNvdmVyKVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnRhYmxlPjxfY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRoPntcIkJyaWVmXCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGg+e1wiU3VyZmFjZVwifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIldoeSBpdCBtYXR0ZXJzXCJ9PC9fY29tcG9uZW50cy50aD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGhlYWQ+PF9jb21wb25lbnRzLnRib2R5PjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiMDAtZm91bmRhdGlvblwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJHcm92ZS1zcGVjaWZpYyBtb3RpZnMsIHRoZSBjbGFzcy1uYW1lL3Rva2VuIGNvbnRyYWN0LCB0aGUgYXBwIG1hcmtcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJ0aGUgc2hhcmVkIGJhc2UgZXZlcnkgb3RoZXIgYnJpZWYgYXNzdW1lc1wifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcIjAxLXJlYWRpbmctdmlld1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJ0aGUgZW50cnkgcGFnZTogTURYIHByb3NlLCBlbnRyeSBoZWFkZXIsIGJhY2tsaW5rcywgVG9DLCB3aWtpLWxpbmsgc3R5bGluZywgbGF5b3V0IHZhcmlhbnRzXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1widGhlIGhlcm8gc3VyZmFjZSDigJQgcmVhZGVycyBsaXZlIGhlcmVcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCIwMi1zaGVsbC1uYXZpZ2F0aW9uLWFuZC1hdXRob3JpbmdcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1widG9wIG5hdiwgc2lkZWJhciAodGFnLWRyaXZlbiArIG5hbWVzcGFjZSB0cmVlKSwgZm9vdGVyLCBzZWFyY2gsIHRoZW1lIHRvZ2dsZSwgbW9iaWxlIGNocm9tZSwgdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZWRpdCAvIG5ldy1lbnRyeSAvIGFzay10aGUtYWdlbnQgYWZmb3JkYW5jZXNcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJob3cgeW91IG1vdmUgdGhyb3VnaCBhIEdyb3ZlIGFuZCBoYW5kIG9mZiB0byB0aGUgaG9zdFwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcIjAzLWluZGV4ZXMtYW5kLWNvbXBvbmVudC1saWJyYXJ5XCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcImhvbWUvaW5kZXgsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjxEb2NMaXN0PlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZmVlZHMsIHRhZyBwYWdlcywgdGFnIGNsb3VkLCByZWNlbnRseS11cGRhdGVkLCBhbmQgZWFjaCBidWlsdC1pbiBjb21wb25lbnQncyBhcHBlYXJhbmNlICsgYW4gYXV0aG9yIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjxJbmZvYm94PlwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJkaXNjb3ZlcnkgKyB0aGUgY29tcG9uZW50IHZvY2FidWxhcnlcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCIwNC1leHRlbnNpYmlsaXR5LXZpZXdzXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcInRoZSBhZ2VudC1idWlsdCB2aWV3czogYW5pbWF0ZWQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ0aW1lbGluZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJmYW1pbHkgdHJlZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJkaXJlY3RvcnkvdGFibGVcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJwcm92ZXMgdGhlIGV4dGVuc2lvbiBzdXJmYWNlIGlzIGRlc2lnbmFibGVcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCIwNS1zdGF0ZXMtYW5kLXRoZW1pbmdcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wibG9hZGluZyBza2VsZXRvbnMsIGVtcHR5LCBlcnJvci80MDQvYnJva2VuLWxpbmssIHJlYWQtb25seSB2aWV3ZXI7IHRoZSBkZWZhdWx0ICsgYWx0ZXJuYXRlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1widGhlbWUgc2hvd2Nhc2VcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCI7IHRoZSBHcm92ZSBhcHAgaWNvblwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcInRoZSB1bmdsYW1vcm91cyBzdXJmYWNlcyArIHRoZSB0aGVtZWFiaWxpdHkgcHJvb2ZcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCIwNi1hZ2VudC1jb252ZXJzYXRpb25cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiR3JvdmUncyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImVtYmVkZGVkIGNvZGluZy1hZ2VudCBjb252ZXJzYXRpb25cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIGFuIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiaW50ZWdyYWwsIGFsd2F5cy1wcmVzZW50XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHN1cmZhY2Ugd2l0aCBhIG1pbmltYWwgbm9uLW9ic2N1cmluZyByZXN0aW5nIGFmZm9yZGFuY2UgKFNhZmFyaS1VUkwtYmFyIHN0eWxlOyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIml0ZXJhdGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdGhlIGZvcm0pLCBwcm9wb3NlZC1jaGFuZ2UgcHJldmlld3MsIGFsbCBzdGF0ZXMsIG1vYmlsZSwgdGhlIHdvcmtiZW5jaCBoYW5kLW9mZlwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIkdyb3ZlJ3MgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJwcmltYXJ5IGF1dGhvcmluZyBzdXJmYWNlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBiYWtlZCBpbiBmcm9udCBhbmQgY2VudGVyXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGJvZHk+PC9fY29tcG9uZW50cy50YWJsZT57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJncm92ZXMtZm91bmRhdGlvbi1pcy10aGUtYWdlbnQtY29udHJhY3QtYW5kLWl0cy1tb3N0bHktaW52aXNpYmxlLXRvLXlvdVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiZ3JvdmVzLWZvdW5kYXRpb24taXMtdGhlLWFnZW50LWNvbnRyYWN0LWFuZC1pdHMtbW9zdGx5LWludmlzaWJsZS10by15b3VcIiAvPntcIkdyb3ZlJ3MgZm91bmRhdGlvbiBpcyB0aGUgYWdlbnQgY29udHJhY3Qg4oCUIGFuZCBpdCdzIG1vc3RseSBpbnZpc2libGUgdG8geW91XCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJHcm92ZSdzIHNpbmdsZSBtb3N0IGltcG9ydGFudCBwcm9wZXJ0eSBpcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImFnZW50IGxlZ2liaWxpdHlcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCI6IGV2ZXJ5IGluc3RhbmNlIGNhcnJpZXMgYVxcbnNlbGYtZGVzY3JpYmluZyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImNvbnRyYWN0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJncm92ZS5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgXFxcIlRoZSBhZ2VudCBjb250cmFjdFxcXCIpIHNvIGEgZnV0dXJlIGNvZGluZy1hZ2VudFxcbnNlc3Npb24gcmUtZGVyaXZlcyBob3cgXCJ9PF9jb21wb25lbnRzLmVtPntcInRoaXNcIn08L19jb21wb25lbnRzLmVtPntcIiB3aWtpIHdvcmtzLiBUaGF0IGNvbnRyYWN0IGlzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiYWdlbnQtZmFjaW5nIGluZnJhc3RydWN0dXJlLFxcbm5vdCBhIHN1cmZhY2UgeW91IHN0eWxlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJHUk9WRS5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYW5kIHRoZSBnZW5lcmF0ZWQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLmdyb3ZlL21hbmlmZXN0Lmpzb25cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFyZSByZWFkIGJ5XFxuYWdlbnRzLCBhbmQgdmFsaWRhdGlvbi9kcmlmdCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImRpYWdub3N0aWNzIHN1cmZhY2UgdGhyb3VnaCB0aGUgaG9zdCBlZGl0IGV4cGVyaWVuY2VcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIsXFxud2hpY2ggR3JvdmUgbXVzdCBub3QgaW1pdGF0ZSAoc2VlIGNvbnN0cmFpbnQgMSkuIFNvIGl0IGNoYW5nZXMgbGl0dGxlIGFib3V0IHdoYXQgeW91IGRyYXcg4oCUXFxuYnV0IHlvdSBzaG91bGQga25vdyBpdCdzIHRoZSBwcm9kdWN0J3MgY2VudHJlIG9mIGdyYXZpdHksIGFuZCBpdCBoYXMgdGhlc2UgdmlzdWFsXFxudG91Y2hwb2ludHMgdG8gZ2V0IHJpZ2h0OlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMub2w+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiTWFrZSBjb252ZW50aW9ucyBsZWdpYmxlIFwifTxfY29tcG9uZW50cy5lbT57XCJpbiB0aGUgY29udGVudCBpdHNlbGZcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgdGhpcyBpcyB3aHkgd2lraS1saW5rIHN0YXRlc1xcbihyZXNvbHZlZCAvIGJyb2tlbiAvIGFtYmlndW91cyksIHRhZyBjaGlwcywgYW5kIHRoZSBuYW1lc3BhY2UgdHJlZSBtdXN0IHJlYWQgY2xlYXJseVxcbihicmllZnMgMDDigJMwMikuIFRoZSBzdHJ1Y3R1cmUgYSByZWFkZXIgc2VlcyBpcyB0aGUgc2FtZSBzdHJ1Y3R1cmUgYW4gYWdlbnQgcmVhZHMuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgZW1iZWRkZWQgR3JvdmUgYWdlbnQgKGJyaWVmIDA2KSBpcyB0aGUgY29udHJhY3QncyB3b3JraW5nIGludGVyZmFjZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgaXQncyB0aGVcXG5jb250cmFjdC1hd2FyZSBhZ2VudCB0aGF0IHJlYWRzIGFuZCB1cGRhdGVzIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkdST1ZFLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi4gRGVzaWduaW5nIHRoYXQgY29udmVyc2F0aW9uIHdlbGxcXG5cIn08X2NvbXBvbmVudHMuZW0+e1wiaXNcIn08L19jb21wb25lbnRzLmVtPntcIiBkZXNpZ25pbmcgaG93IG1vc3QgdXNlcnMgdG91Y2ggdGhlIGNvbnRyYWN0LCBldmVuIHRob3VnaCB0aGUgY29udHJhY3QgZmlsZXNcXG50aGVtc2VsdmVzIHN0YXkgdW5zdHlsZWQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJBbiBvcHRpb25hbCBcXFwiYWJvdXQgdGhpcyB3aWtpXFxcIiAvIGNvbG9waG9uIGVudHJ5XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBhIGh1bWFuLXJlYWRhYmxlIHJlbmRlcmluZyBvZiB0aGVcXG5pbnN0YW5jZSdzIGNvbnZlbnRpb25zICh3aGF0IHRhZ3MgbWVhbiwgd2hhdCBjdXN0b20gY29tcG9uZW50cyBleGlzdCkgaXMganVzdCBhIG5vcm1hbFxcbk1EWCBlbnRyeSByZW5kZXJlZCBpbiB0aGUgcmVhZGluZyB2aWV3OyBkZXNpZ24gbm8gc3BlY2lhbCBjaHJvbWUgZm9yIGl0LCBidXQgYSB0YXN0ZWZ1bFxcbmNvbG9waG9uL1wifTxfY29tcG9uZW50cy5jb2RlPntcIi9hYm91dFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcGF0dGVybiBpcyBhIHdlbGNvbWUgZXhhbXBsZS4gTmV2ZXIgcmVuZGVyIGEgZmFrZSBcXFwiZGlhZ25vc3RpY3MgcGFuZWxcXFwiXFxub3IgaG9zdCBlZGl0b3IgY2hyb21lLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJoYXJkLWNvbnN0cmFpbnRzLXJlYWQtYmVmb3JlLWRyYXdpbmctYW55dGhpbmdcIj48SGVhZGluZ0FuY2hvciBpZD1cImhhcmQtY29uc3RyYWludHMtcmVhZC1iZWZvcmUtZHJhd2luZy1hbnl0aGluZ1wiIC8+e1wiSGFyZCBjb25zdHJhaW50cyAocmVhZCBiZWZvcmUgZHJhd2luZyBhbnl0aGluZylcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJEb24ndCBpbWl0YXRlIGhvc3QgY2hyb21lIOKAlCBidXQgR3JvdmUncyBcIn08X2NvbXBvbmVudHMuZW0+e1wib3duXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgYWdlbnQgaXMgYWxsb3dlZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZ3JvdmUubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHNlY3VyaXR5XFxubW9kZWwgKyBcXFwiQXV0aG9yaW5nXFxcIjsgZWFjaCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJDTEFVREUubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIMKnOCkuIEdyb3ZlIG11c3QgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJuZXZlclwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiByZW5kZXIgYSBmYWtlIGNvZGVcXG5lZGl0b3IsIGEgZmFrZSBcIn08X2NvbXBvbmVudHMuZW0+e1wiaG9zdFwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGFnZW50IHBhbmUsIGEgZmFrZSBjb25zZW50IGRpYWxvZywgYSBmYWtlIHZhbGlkYXRpb24vZGlhZ25vc3RpY3NcXG5wYW5lbCwgb3IgYSBzaWduLWluLiBXaGVuIHRoZSB1c2VyIGVkaXRzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1widGV4dFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgR3JvdmUgc2hvd3MgYW4gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJlZGl0IGFmZm9yZGFuY2VcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCJcXG50aGF0IFwifTxfY29tcG9uZW50cy5lbT57XCJoYW5kcyBvZmZcIn08L19jb21wb25lbnRzLmVtPntcIiB0byB0aGUgcGxhdGZvcm0gZWRpdG9yIOKAlCBkZXNpZ24gdGhlIGFmZm9yZGFuY2UsIG5vdCB0aGUgZWRpdG9yOyBjb250cmFjdFxcbnZhbGlkYXRpb24vZHJpZnQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJkaWFnbm9zdGljcyBhcmUgYSBob3N0IHN1cmZhY2VcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdG9vLiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlRoZSBvbmUgZXhjZXB0aW9uIGlzIHRoZVxcbmFnZW50IGNvbnZlcnNhdGlvbjpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgR3JvdmUgZGVsaWJlcmF0ZWx5IHNoaXBzIGl0cyBcIn08X2NvbXBvbmVudHMuZW0+e1wib3duXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgZW1iZWRkZWQgYWdlbnQgKGJyaWVmIDA2KSxcXG5zY29wZWQgdG8gR3JvdmUncyBncmFudHMgdmlhIHRoZSBTREsgY2F0YWxvZyDigJQgc28geW91IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZG9cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgZGVzaWduIHRoYXQgc3VyZmFjZS4gSXQgbXVzdFxcbmJlIGNsZWFybHkgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJHcm92ZSdzIG93blwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoaXRzIG93biBwbGFjZW1lbnQvaWRlbnRpdHkgd2l0aGluIHRoZSBhcHApLCBuZXZlciBzdHlsZWQgdG9cXG5wYXNzIGFzIHRoZSBob3N0J3MgdHJ1c3RlZCBhZ2VudCBwYW5lLCBhbmQgcHJpdmlsZWdlZCBhY3Rpb25zICh3cml0ZXMsIGNvbnRyaWJ1dGUpIHN0aWxsXFxucm91dGUgdGhyb3VnaCB0aGUgaG9zdC4gU3Bvb2ZpbmcgaG9zdCBzdXJmYWNlcyByZWFkcyBhcyBob3N0aWxlOyBidWlsZGluZyB5b3VyIG93blxcbmNhcGFiaWxpdHktc2NvcGVkIGFnZW50IGRvZXMgbm90LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUmVhZGluZy1maXJzdCwgd2l0aCB0aGUgYWdlbnQgYXMgdGhlIGRlbGliZXJhdGUgYWx3YXlzLXByZXNlbnQgZXhjZXB0aW9uLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBSdW4tbW9kZVxcblVJIHN0YXlzIGZyZWUgb2YgXCJ9PF9jb21wb25lbnRzLmVtPntcImVkaXRvclwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGNocm9tZTsgdGhlIGVkaXQgYWZmb3JkYW5jZSBpcyB1bm9idHJ1c2l2ZSBhbmQgd3JpdGFibGUtb25seTtcXG50aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJyZWFkLW9ubHkgdmlld2VyXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGhhcyBubyBlZGl0IGFmZm9yZGFuY2UgYXQgYWxsLiBCdXQgdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiYWdlbnQgY29tbXVuaWNhdGlvbiBpc1xcbmJha2VkIGluLCBmcm9udCBhbmQgY2VudGVyXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBhbHdheXMgcHJlc2VudCBhbmQgb25lIGdlc3R1cmUgYXdheSAoYnJpZWYgMDYpLiBSZWNvbmNpbGVcXG50aGUgdHdvIHRoZSB3YXkgdGhlIGlPUyBTYWZhcmkgVVJMIGJhciBkb2VzOiBhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibWluaW1hbCBwZXJzaXN0ZW50IGFmZm9yZGFuY2VcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHRoaW5cXG5ib3R0b20gaW5wdXQgbGluZSAvIHB1bGwgdGFiIC8gaWNvbikgdGhhdCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5ldmVyIG9ic2N1cmVzIGNvbnRlbnQgb24gbW9iaWxlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGFuZFxcbmV4cGFuZHMgb25seSBvbiBkZW1hbmQuIEZyb250LWFuZC1jZW50ZXIsIG5vdCBpbi10aGUtd2F5LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVG9rZW5zIGFyZSB0aGUgY29udHJhY3QuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIENvbG91cnMvZm9udHMvcmFkaWkvc2hhZG93cyBjb21lIGZyb21cXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvaW5kZXguY3NzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi4gTm8gaGFyZC1jb2RlZCBoZXhlcyBpbiBtb2NrdXBzIHlvdSdkIHdhbnQgYSBkZXYgdG8gY29weS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIk5vIGVtb2ppLCBldmVyLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBJY29ucyBhcmUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJMdWNpZGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKDE24oCTMjRweCwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY3VycmVudENvbG9yXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgfjEuNzUgc3Ryb2tlKSBwbHVzXFxudGhlIHVuaWNvZGUgbWljcm8tc2V0IChcIn08X2NvbXBvbmVudHMuY29kZT57XCLimIUg4oaSIOKXjyDimIAg4pi+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikuIE1vbm8gbWljcm8tbGFiZWxzIGFyZSB0aGUgb25lIFVQUEVSQ0FTRS10cmFja2VkXFxuZXhjZXB0aW9uLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRXZlcnkgZHluYW1pYyBzdXJmYWNlIG5lZWRzIGZvdXIgc3RhdGVzOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBsb2FkaW5nIChcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInNrZWxldG9uXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBub3Qgc3Bpbm5lcjtcXG5+MTUwbXMgYnVkZ2V0KSwgY29udGVudCwgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJlbXB0eVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoZGVzaWduZWQsIG5ldmVyIGJyb2tlbiksIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZXJyb3IvNDA0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChpbmNsLiBhXFxuYnJva2VuL2FtYmlndW91cyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJbW3dpa2ktbGlua11dXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB0YXJnZXQpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQWNjZXNzaWJpbGl0eSBBQSBvbiBib3RoIHRoZW1lc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgZnVsbCBrZXlib2FyZCBvcGVyYWJpbGl0eSwgdmlzaWJsZSBmb2N1cyByaW5nc1xcbih0aGUgZ2xvdyByaW5nKSwgc2VtYW50aWMgbGFuZG1hcmtzL2hlYWRpbmdzLCBuZXZlciBzdGF0ZS1ieS1ncmFkaWVudC1hbG9uZS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMub2w+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwiZGVsaXZlcmFibGUtcGVyLWJyaWVmXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJkZWxpdmVyYWJsZS1wZXItYnJpZWZcIiAvPntcIkRlbGl2ZXJhYmxlIHBlciBicmllZlwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiTGF5b3V0cyBhdCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm1vYmlsZSArIGRlc2t0b3BcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIsIGFsbCBmb3VyIHN0YXRlcywgaW50ZXJhY3Rpb24vdHJhbnNpdGlvbiBub3RlcyAocmVzdHJhaW5lZFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcIn4uMTRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgbm8gYm91bmNlL3NwcmluZzsgcmVzcGVjdCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJwcmVmZXJzLXJlZHVjZWQtbW90aW9uXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiksIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZHJhZnRlZCBvbi1icmFuZCBjb3B5XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGZvclxcbnRoZSBrZXkgc3RyaW5ncyAoc2VudGVuY2UgY2FzZSwgcGVyaW9kLXRlcm1pbmF0ZWQgaGVhZGxpbmVzLCBtb25vIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi9zbHVnXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhbmQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiI3RhZ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG5sYWJlbHMpLCBhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiY29tcG9uZW50IGludmVudG9yeSBtYXBwZWQgdG8gdGhlIHRva2VucyBhbmQgdG8gdGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi5ncm92ZS0qXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjbGFzcyBuYW1lc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIlxcbmluIGJyaWVmIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjAwXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgYW5kIOKAlCB3aGVyZSByZWxldmFudCDigJQgdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicm91dGVzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGFmZm9yZGFuY2VzIHBvaW50IGF0IChcIn08X2NvbXBvbmVudHMuY29kZT57XCIjL3NsdWdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGhhc2hcXG5yb3V0ZXMgd2l0aGluIHRoZSBhcHA7IHRoZSBob3N0IGhhbmQtb2ZmIGZvciBlZGl0aW5nKS4gQ2FsbCBvdXQgYW55IGZvcmthYmlsaXR5L3RoZW1pbmdcXG5ub3RlIHNwZWNpZmljIHRvIHRoYXQgc3VyZmFjZS5cIn08L19jb21wb25lbnRzLnA+PC8+O1xufVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTURYQ29udGVudChwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHt3cmFwcGVyOiBNRFhMYXlvdXR9ID0ge1xuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfTtcbiAgcmV0dXJuIE1EWExheW91dCA/IDxNRFhMYXlvdXQgey4uLnByb3BzfT48X2NyZWF0ZU1keENvbnRlbnQgey4uLnByb3BzfSAvPjwvTURYTGF5b3V0PiA6IF9jcmVhdGVNZHhDb250ZW50KHByb3BzKTtcbn1cbmZ1bmN0aW9uIF9taXNzaW5nTWR4UmVmZXJlbmNlKGlkLCBjb21wb25lbnQsIHBsYWNlKSB7XG4gIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIFwiICsgKGNvbXBvbmVudCA/IFwiY29tcG9uZW50XCIgOiBcIm9iamVjdFwiKSArIFwiIGBcIiArIGlkICsgXCJgIHRvIGJlIGRlZmluZWQ6IHlvdSBsaWtlbHkgZm9yZ290IHRvIGltcG9ydCwgcGFzcywgb3IgcHJvdmlkZSBpdC5cIiArIChwbGFjZSA/IFwiXFxuSXTigJlzIHJlZmVyZW5jZWQgaW4geW91ciBjb2RlIGF0IGBcIiArIHBsYWNlICsgXCJgIGluIGAvYXBwL2RvY3MvZGVzaWduLWJyaWVmcy9ncm92ZS9IQU5ET0ZGLm1kYFwiIDogXCJcIikpO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFFQSxJQUFBQSxZQUFBLEdBQUFDLE9BQUE7QUFBd0YsSUFBQUMsV0FBQSxHQUFBRCxPQUFBO0FBRnhGO0FBQ0E7O0FBRUEsU0FBU0UsaUJBQWlCQSxDQUFDQyxLQUFLLEVBQUU7RUFDaEMsTUFBTUMsV0FBVyxHQUFHO01BQ2xCQyxDQUFDLEVBQUUsR0FBRztNQUNOQyxJQUFJLEVBQUUsTUFBTTtNQUNaQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxDQUFDLEVBQUUsR0FBRztNQUNOQyxNQUFNLEVBQUUsUUFBUTtNQUNoQkMsS0FBSyxFQUFFLE9BQU87TUFDZEMsS0FBSyxFQUFFLE9BQU87TUFDZEMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsS0FBSyxFQUFFLE9BQU87TUFDZEMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUixHQUFHLElBQUFDLDZCQUFrQixFQUFDLENBQUM7TUFDdkIsR0FBR2xCLEtBQUssQ0FBQ21CO0lBQ1gsQ0FBQztJQUFFO01BQUNDO0lBQWEsQ0FBQyxHQUFHbkIsV0FBVztFQUNoQyxJQUFJLENBQUNtQixhQUFhLEVBQUVDLG9CQUFvQixDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUM7RUFDL0Qsb0JBQU8sSUFBQXZCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQXhCLFdBQUEsQ0FBQXlCLFFBQUE7SUFBQUMsUUFBQSxnQkFBRSxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDSSxFQUFFO01BQUNvQixFQUFFLEVBQUMseUNBQXlDO01BQUFELFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBeUMsQ0FBRSxDQUFDLEVBQUMsNENBQTRDO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDUSxDQUFDO01BQUFlLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBa0IsQ0FBcUIsQ0FBQyxFQUFDLG9GQUFvRixlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQU8sQ0FBcUIsQ0FBQyxFQUFDLHFDQUFxQyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNDLENBQUM7UUFBQ3lCLElBQUksRUFBQyxXQUFXO1FBQUFILFFBQUEsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBUyxDQUFtQjtNQUFDLENBQWUsQ0FBQyxFQUFDLCtGQUErRjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1EsQ0FBQztNQUFBZSxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQU0sQ0FBcUIsQ0FBQyxFQUFDLDJFQUEyRSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQWtCLENBQXFCLENBQUM7SUFBQSxDQUFlLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ2dCLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDTSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUE0QixDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWEsQ0FBcUIsQ0FBQyxFQUFDLG9HQUFvRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ00sRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBZSxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQVksQ0FBcUIsQ0FBQyxFQUFDLHNGQUFzRjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ00sRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsb0dBQW9HO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNLLEVBQUU7TUFBQ21CLEVBQUUsRUFBQyx1Q0FBdUM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUF1QyxDQUFFLENBQUMsRUFBQyx5Q0FBeUM7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNRLENBQUM7TUFBQWUsUUFBQSxHQUFFLGFBQWEsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFnQyxDQUFxQixDQUFDLEVBQUMsbUdBQW1HLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQWdCLENBQW1CLENBQUMsRUFBQyxrRUFBa0UsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUEyRixDQUFxQixDQUFDLEVBQUMsdUhBQXVILGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBYyxRQUFBLEdBQUUsa0RBQWtELGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBb0IsUUFBQSxFQUFFO1FBQVMsQ0FBaUIsQ0FBQyxFQUFDLHFCQUFxQjtNQUFBLENBQXFCLENBQUMsRUFBQyxvRUFBb0UsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUF1RCxDQUFxQixDQUFDLEVBQUMscUVBQXFFLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBSyxDQUFxQixDQUFDLEVBQUMsb0JBQW9CLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBb0IsUUFBQSxFQUFFO01BQVEsQ0FBaUIsQ0FBQyxFQUFDLCtCQUErQixlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQU0sQ0FBcUIsQ0FBQyxFQUFDLHFDQUFxQyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQUssQ0FBcUIsQ0FBQyxFQUFDLHFCQUFxQixlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQTZCLENBQXFCLENBQUMsRUFBQyxpREFBaUQsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBVyxDQUFtQixDQUFDLEVBQUMsZ0NBQWdDLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBb0IsUUFBQSxFQUFFO01BQXVDLENBQWlCLENBQUMsRUFBQyw4QkFBOEIsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRyxFQUFFO1FBQUFvQixRQUFBLEVBQUU7TUFBa0IsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNLLEVBQUU7TUFBQ21CLEVBQUUsRUFBQyxxRUFBcUU7TUFBQUQsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFxRSxDQUFFLENBQUMsRUFBQyxrQkFBa0IsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRyxFQUFFO1FBQUFvQixRQUFBLEVBQUU7TUFBSSxDQUFpQixDQUFDLEVBQUMsc0RBQXNEO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDUSxDQUFDO01BQUFlLFFBQUEsR0FBRSx3UkFBd1IsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBZSxDQUFtQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFXLENBQW1CLENBQUMsRUFBQywwQkFBMEIsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFzQixDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNHLEVBQUU7UUFBQW9CLFFBQUEsRUFBRTtNQUFJLENBQWlCLENBQUMsRUFBQyx1REFBdUQsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBZSxDQUFtQixDQUFDLEVBQUMsd0RBQXdEO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDSyxFQUFFO01BQUNtQixFQUFFLEVBQUMsK0NBQStDO01BQUFELFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBK0MsQ0FBRSxDQUFDLEVBQUMsa0RBQWtEO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDUSxDQUFDO01BQUFlLFFBQUEsR0FBRSxvQ0FBb0MsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLG9DQUFvQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ08sRUFBRTtNQUFBZ0IsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDTSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQVMsQ0FBcUIsQ0FBQyxFQUFDLDZIQUE2SDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ00sRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUF1QyxDQUFxQixDQUFDLEVBQUMsaUJBQWlCLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBb0IsUUFBQSxFQUFFO1FBQWUsQ0FBaUIsQ0FBQyxFQUFDLGlIQUFpSDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ00sRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFlLENBQXFCLENBQUMsRUFBQyx1R0FBdUc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1EsQ0FBQztNQUFBZSxRQUFBLEVBQUU7SUFBNEMsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDSyxFQUFFO01BQUNtQixFQUFFLEVBQUMsMERBQTBEO01BQUFELFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBMEQsQ0FBRSxDQUFDLEVBQUMsNkRBQTZEO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDUSxDQUFDO01BQUFlLFFBQUEsR0FBRSw2QkFBNkIsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFrQixDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFVLENBQW1CLENBQUMsRUFBQyxvR0FBb0csZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUErQyxDQUFxQixDQUFDLEVBQUMsbUdBQW1HO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDZ0IsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNNLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBbUIsQ0FBcUIsQ0FBQyxFQUFDLGtDQUFrQztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ00sRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUE0QixDQUFxQixDQUFDLEVBQUMsZ0NBQWdDLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQVUsQ0FBbUIsQ0FBQyxFQUFDLG9EQUFvRCxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQVEsQ0FBcUIsQ0FBQyxFQUFDLHVCQUF1QixlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWdCLENBQXFCLENBQUMsRUFBQywyQkFBMkIsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFtQixDQUFxQixDQUFDLEVBQUMsV0FBVyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNHLEVBQUU7VUFBQW9CLFFBQUEsRUFBRTtRQUF5QyxDQUFpQixDQUFDLEVBQUMscUZBQXFGO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNLLEVBQUU7TUFBQ21CLEVBQUUsRUFBQyxrREFBa0Q7TUFBQUQsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFrRCxDQUFFLENBQUMsRUFBQyxzREFBc0Q7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNVLEtBQUs7TUFBQWEsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDYyxLQUFLO1FBQUFTLFFBQUEsZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDZSxFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBTyxDQUFpQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDYSxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFTLENBQWlCLENBQUMsbUJBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNhLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQWdCLENBQWlCLENBQUM7UUFBQSxDQUFnQjtNQUFDLENBQW1CLENBQUMsbUJBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNXLEtBQUs7UUFBQVksUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDZSxFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQWUsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFvRSxDQUFpQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUEyQyxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ2UsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUFpQixDQUFtQjtVQUFDLENBQWdCLENBQUMsbUJBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQTZGLENBQWlCLENBQUMsbUJBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQXNDLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDZSxFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQW1DLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLEdBQUUsbUdBQW1HLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBOEMsQ0FBcUIsQ0FBQztVQUFBLENBQWdCLENBQUMsbUJBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQXVELENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDZSxFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQWtDLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLEdBQUUsY0FBYyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUFXLENBQW1CLENBQUMsRUFBQyx1R0FBdUcsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBVyxDQUFtQixDQUFDO1VBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBc0MsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNlLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBd0IsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsR0FBRSxrQ0FBa0MsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFVLENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBYSxDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQWlCLENBQXFCLENBQUM7VUFBQSxDQUFnQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUE0QyxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ2UsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUF1QixDQUFtQjtVQUFDLENBQWdCLENBQUMsbUJBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxHQUFFLDZGQUE2RixlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQWdCLENBQXFCLENBQUMsRUFBQyxzQkFBc0I7VUFBQSxDQUFpQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFtRCxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ2UsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUF1QixDQUFtQjtVQUFDLENBQWdCLENBQUMsbUJBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxHQUFFLFVBQVUsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFvQyxDQUFxQixDQUFDLEVBQUMsUUFBUSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQTBCLENBQXFCLENBQUMsRUFBQyxrRkFBa0YsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFTLENBQXFCLENBQUMsRUFBQyxrRkFBa0Y7VUFBQSxDQUFpQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsR0FBRSxVQUFVLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBMkIsQ0FBcUIsQ0FBQyxFQUFDLDZCQUE2QjtVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDO01BQUEsQ0FBbUIsQ0FBQztJQUFBLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDbUIsRUFBRSxFQUFDLHlFQUF5RTtNQUFBRCxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQXlFLENBQUUsQ0FBQyxFQUFDLDZFQUE2RTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1EsQ0FBQztNQUFBZSxRQUFBLEdBQUUsNENBQTRDLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBa0IsQ0FBcUIsQ0FBQyxFQUFDLDhDQUE4QyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVUsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBVSxDQUFtQixDQUFDLEVBQUMsNEVBQTRFLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBb0IsUUFBQSxFQUFFO01BQU0sQ0FBaUIsQ0FBQyxFQUFDLGdDQUFnQyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQXVELENBQXFCLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQVUsQ0FBbUIsQ0FBQyxFQUFDLHFCQUFxQixlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFzQixDQUFtQixDQUFDLEVBQUMsNkNBQTZDLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBc0QsQ0FBcUIsQ0FBQyxFQUFDLDhNQUE4TTtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ08sRUFBRTtNQUFBZ0IsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDTSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNTLE1BQU07VUFBQWMsUUFBQSxHQUFFLDJCQUEyQixlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNHLEVBQUU7WUFBQW9CLFFBQUEsRUFBRTtVQUF1QixDQUFpQixDQUFDO1FBQUEsQ0FBb0IsQ0FBQyxFQUFDLDBNQUEwTTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ00sRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUF5RSxDQUFxQixDQUFDLEVBQUMsMkRBQTJELGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQVUsQ0FBbUIsQ0FBQyxFQUFDLHNDQUFzQyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNHLEVBQUU7VUFBQW9CLFFBQUEsRUFBRTtRQUFJLENBQWlCLENBQUMsRUFBQyx5R0FBeUc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNNLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBa0QsQ0FBcUIsQ0FBQyxFQUFDLGtPQUFrTyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFRLENBQW1CLENBQUMsRUFBQyxrR0FBa0c7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDbUIsRUFBRSxFQUFDLCtDQUErQztNQUFBRCxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQStDLENBQUUsQ0FBQyxFQUFDLGlEQUFpRDtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ08sRUFBRTtNQUFBZ0IsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDTSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNTLE1BQU07VUFBQWMsUUFBQSxHQUFFLDBDQUEwQyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNHLEVBQUU7WUFBQW9CLFFBQUEsRUFBRTtVQUFLLENBQWlCLENBQUMsRUFBQyxtQkFBbUI7UUFBQSxDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQyx5Q0FBeUMsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsbUJBQW1CLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBTyxDQUFxQixDQUFDLEVBQUMsc0NBQXNDLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBb0IsUUFBQSxFQUFFO1FBQU0sQ0FBaUIsQ0FBQyxFQUFDLDhHQUE4RyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQU0sQ0FBcUIsQ0FBQyxFQUFDLG1CQUFtQixlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWlCLENBQXFCLENBQUMsRUFBQyxTQUFTLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBb0IsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLDhGQUE4RixlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWdDLENBQXFCLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBK0MsQ0FBcUIsQ0FBQyxFQUFDLGdDQUFnQyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNHLEVBQUU7VUFBQW9CLFFBQUEsRUFBRTtRQUFLLENBQWlCLENBQUMsRUFBQyxxRkFBcUYsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFJLENBQXFCLENBQUMsRUFBQyw0Q0FBNEMsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFhLENBQXFCLENBQUMsRUFBQyxnUkFBZ1I7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNNLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBMkUsQ0FBcUIsQ0FBQyxFQUFDLDhCQUE4QixlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNHLEVBQUU7VUFBQW9CLFFBQUEsRUFBRTtRQUFRLENBQWlCLENBQUMsRUFBQyxzRUFBc0UsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFrQixDQUFxQixDQUFDLEVBQUMsMENBQTBDLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBb0QsQ0FBcUIsQ0FBQyxFQUFDLCtHQUErRyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQStCLENBQXFCLENBQUMsRUFBQyxvREFBb0QsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFrQyxDQUFxQixDQUFDLEVBQUMsaUVBQWlFO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDTSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTBCLENBQXFCLENBQUMsRUFBQywwQ0FBMEMsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBZSxDQUFtQixDQUFDLEVBQUMsNERBQTREO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDTSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWlCLENBQXFCLENBQUMsRUFBQyxhQUFhLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBUSxDQUFxQixDQUFDLEVBQUMsYUFBYSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUMsRUFBQywrQ0FBK0MsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsZ0VBQWdFO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDTSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTBDLENBQXFCLENBQUMsRUFBQyxZQUFZLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBVSxDQUFxQixDQUFDLEVBQUMsMkNBQTJDLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBTyxDQUFxQixDQUFDLEVBQUMsNkJBQTZCLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBVyxDQUFxQixDQUFDLEVBQUMsOEJBQThCLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQWUsQ0FBbUIsQ0FBQyxFQUFDLFdBQVc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNNLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBaUMsQ0FBcUIsQ0FBQyxFQUFDLGdJQUFnSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDSyxFQUFFO01BQUNtQixFQUFFLEVBQUMsdUJBQXVCO01BQUFELFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBdUIsQ0FBRSxDQUFDLEVBQUMsdUJBQXVCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDUSxDQUFDO01BQUFlLFFBQUEsR0FBRSxhQUFhLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBa0IsQ0FBcUIsQ0FBQyxFQUFDLCtEQUErRCxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFPLENBQW1CLENBQUMsRUFBQyw4QkFBOEIsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBd0IsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUF1QixDQUFxQixDQUFDLEVBQUMsMEVBQTBFLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQU8sQ0FBbUIsQ0FBQyxFQUFDLE9BQU8sZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBTSxDQUFtQixDQUFDLEVBQUMsZUFBZSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNTLE1BQU07UUFBQWMsUUFBQSxHQUFFLHNEQUFzRCxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQyxjQUFjO01BQUEsQ0FBcUIsQ0FBQyxFQUFDLGFBQWEsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBSSxDQUFtQixDQUFDLEVBQUMsK0JBQStCLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBUSxDQUFxQixDQUFDLEVBQUMseUJBQXlCLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQVEsQ0FBbUIsQ0FBQyxFQUFDLGdJQUFnSTtJQUFBLENBQWdCLENBQUM7RUFBQSxDQUFFLENBQUM7QUFDcm9sQjtBQUNlLFNBQVNJLFVBQVVBLENBQUM1QixLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUU7RUFDN0MsTUFBTTtJQUFDNkIsT0FBTyxFQUFFQztFQUFTLENBQUMsR0FBRztJQUMzQixHQUFHLElBQUFaLDZCQUFrQixFQUFDLENBQUM7SUFDdkIsR0FBR2xCLEtBQUssQ0FBQ21CO0VBQ1gsQ0FBQztFQUNELE9BQU9XLFNBQVMsZ0JBQUcsSUFBQWhDLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ0ksU0FBUztJQUFBLEdBQUs5QixLQUFLO0lBQUF3QixRQUFBLGVBQUUsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQzNCLGlCQUFpQjtNQUFBLEdBQUtDO0lBQUssQ0FBRztFQUFDLENBQVcsQ0FBQyxHQUFHRCxpQkFBaUIsQ0FBQ0MsS0FBSyxDQUFDO0FBQ2xIO0FBQUMrQixFQUFBLEdBTnVCSCxVQUFVO0FBT2xDLFNBQVNQLG9CQUFvQkEsQ0FBQ0ksRUFBRSxFQUFFTyxTQUFTLEVBQUVDLEtBQUssRUFBRTtFQUNsRCxNQUFNLElBQUlDLEtBQUssQ0FBQyxXQUFXLElBQUlGLFNBQVMsR0FBRyxXQUFXLEdBQUcsUUFBUSxDQUFDLEdBQUcsSUFBSSxHQUFHUCxFQUFFLEdBQUcsb0VBQW9FLElBQUlRLEtBQUssR0FBRyxxQ0FBcUMsR0FBR0EsS0FBSyxHQUFHLGlEQUFpRCxHQUFHLEVBQUUsQ0FBQyxDQUFDO0FBQzNRO0FBQUMsSUFBQUYsRUFBQTtBQUFBSSxZQUFBLENBQUFKLEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}