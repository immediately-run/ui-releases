var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      blockquote: "blockquote",
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      h3: "h3",
      li: "li",
      ol: "ol",
      p: "p",
      pre: "pre",
      strong: "strong",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "building-a-grove-component-with-the-in-browser-coding-agent",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "building-a-grove-component-with-the-in-browser-coding-agent"
      }), "Building a Grove component with the in-browser coding agent"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Grove's content is meant to be changed ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "by asking an agent"
      }), ". The platform also\nships a general ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "in-browser coding agent"
      }), " (the \"Agents\" activity) that reads,\nsearches, and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "edits the running app's files"
      }), " with a real tool-calling loop —\nthe same ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "<Quote>"
      }), " component from\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "./creating-a-component.md",
        children: "creating-a-component.md"
      }), ", built by talking instead of\ntyping."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["This guide is two things at once: the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "steps that work today"
      }), ", and an honest\nlog of ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "what's still rough"
      }), " (it was produced by actually driving the agent\nend-to-end against Grove with GLM 5.2 over OpenRouter and writing down where it\nbroke)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Status, 2026-06-30."
        }), " This flow now works end-to-end: the agent reads and\nwrites ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Grove's"
        }), " working tree and Grove re-renders. That last sentence used to\nbe false — the agent was mounted on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "its own"
        }), " repo and every Grove path read\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "not found"
        }), ". That was the AA-23 gap, now fixed (site-main #208 + agent-demo #11)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Re-verified 2026-07-01"
        }), " on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "local.immediately.run"
        }), " with GLM 5.2 over\nOpenRouter, driving a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "fresh"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<Kbd>"
        }), " component end-to-end: 6 real ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "read_file"
        }), "s\n(not ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "not found"
        }), "), then ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "write_file"
        }), " + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "edit_file"
        }), "×4, and Grove's preview\nhot-reloaded to render the new component. GLM ran ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "clean this time"
        }), " — every\nturn emitted its tool calls (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "finish_reason: tool_calls"
        }), "), so the \"announces but\nemits none\" edge (findings §2) is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "intermittent, not deterministic"
        }), ". The only\nhuman step was the one passkey tap (§1). Also fixed on the same day: the file\nexplorer now labels Grove's working tree ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "immediately-run/grove"
        }), " read-only\n(was mislabeled as the explorer's own repo, read-write — site-main #212 +\nfile-explorer #20)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "how-the-agent-is-wired",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "how-the-agent-is-wired"
      }), "How the agent is wired"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["The agent is the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "immediately-run/agent-demo"
        }), " app, bound in the build-default\nregistry to two regions: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "panel.agent"
          })
        }), " (the conversation list, left) and\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "stage.conversation"
          })
        }), " (the main pane — where you type and the agent runs).\nOpen it with the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "\"Agents\""
        }), " button in the left activity rail (edit mode)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["It authors the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "stage app's"
          }), " working tree, not its own (AA-23)."]
        }), " While Grove\nis the loaded app, the host confers Grove's working tree to the agent as a\nscoped, read-write ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "worktree"
        }), " mount — the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "editor's cross-repo grant kind"
        }), ", not\n\"self-access.\" The agent's filesystem tools (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "read_file"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "write_file"
        }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "edit_file"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "list_dir"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "glob"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "grep"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "stat"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "delete_file"
        }), ") are chrooted to\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "that"
        }), " tree, merged with the app's capability catalog (the header shows the\nmerged count, e.g. \"23 tools (catalog + files)\" — the exact number tracks the\ncatalog and drifts, so read the \"catalog + files\" suffix, not the digit). Switch\nwhich app is loaded and the prior port is torn down and a new one minted."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Inference goes through the platform ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "llm.chat"
          }), " service, not a per-app key."]
        }), "\nThe agent calls the host-mediated ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "chat()"
        }), " and needs only the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "llm:chat"
          })
        }), "\ncapability — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "no"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "net:fetch"
        }), ", no bring-your-own-key powerbox. The app names no\nvendor and no model; the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "host"
        }), " resolves your provider/model preference and\ninjects the key per request, so the app never sees the secret. (This replaced the\nold BYOK/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "net:fetch"
        }), " design — if you find docs mentioning an \"Add OpenRouter key\"\nbutton or ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "modelClient.ts"
        }), ", they're historical.)"]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "the-happy-path-what-works",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-happy-path-what-works"
      }), "The happy path (what works)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-1",
      "data-slug": "1-load-grove-with-a-writable-mount",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-1"
      }), "1. Load Grove with a writable mount"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "immediately.run dev"
      }), " (local provider) is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "read-only by construction"
      }), ", so the\nagent can't persist edits to a locally-served tree. Load Grove ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "from GitHub"
      }), "\ninstead — that gives a writable copy-on-write mount, and you persist with the\nnormal Contribute / PR flow:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "https://local.immediately.run/edit/github/immediately-run/grove/main/\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["(Use ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "local.immediately.run"
      }), " for the local host, or ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "immediately.run"
      }), " for prod —\nnever ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "localhost"
      }), "; config is keyed by hostname.)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-2",
      "data-slug": "2-set-the-provider-and-model-one-time",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-2"
      }), "2. Set the provider and model (one-time)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["There is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "no Settings UI yet"
      }), " (see the gaps below), so the provider/model\npreference is set with a dev hook. In the host's top-frame console:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-js",
        children: "await window.__irLlmPref.set({ providerId: 'llm.chat.openrouter', model: 'z-ai/glm-5.2' })\n// read it back: await window.__irLlmPref.get()\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["This writes ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "/etc/config/llm-provider.json"
      }), " in the host's ZenFS. The OpenRouter\nkey itself is stored once, host-side, sealed with your passkey — the app never\nsees it. GLM 5.2's OpenRouter slug is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "z-ai/glm-5.2"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-3",
      "data-slug": "3-open-the-agent-and-ask-for-the-component",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-3"
      }), "3. Open the agent and ask for the component"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
          children: ["Click ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "Agents"
          }), " in the left rail. The main pane becomes the conversation; the\nheader should read \"… tools (catalog + files)\"."]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
          children: ["Type a self-contained prompt and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "Run"
          }), ". Give it the conventions up front so\nit doesn't have to guess — point it at the same rules humans follow:"]
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
          children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
            children: ["Create a new MDX component ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "<Quote>"
            }), " … First read ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "CLAUDE.md"
            }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/mdxComponents.ts"
            }), ", and the existing ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "Callout.tsx"
            }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "WikiLink.tsx"
            }), " /\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "index.css"
            }), " to match conventions. Then create ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/components/Quote.tsx"
            }), "\n(default export, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "only"
            }), " the component), add ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: ".grove-quote"
            }), " styles using the\ndesign tokens, register it in the MDX component map, and add a demo ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "<Quote>"
            }), "\nto ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "content/home.mdx"
            }), ". Reuse ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "<WikiLink>"
            }), " for the source link."]
          }), "\n"]
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
          children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Pick a component that doesn't already exist."
            }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "<Quote>"
            }), " (and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "<Callout>"
            }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "<WikiLink>"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "<KeyValue>"
            }), ", …) already ship in this repo and are registered in\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/mdxComponents.ts"
            }), " — asking for one of those has the agent ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
              children: "rewrite"
            }), " an\nexisting file, so you can't tell a real create from a no-op. For a clean run\npick a fresh name and swap it through the prompt (the 2026-07-01 re-verify used\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "<Kbd>"
            }), " — a keycap: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/components/Kbd.tsx"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: ".grove-kbd"
            }), ", a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "<Kbd>⌘K</Kbd>"
            }), "\ndemo). Skim ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/components/"
            }), " first to see what's taken."]
          }), "\n"]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "Approve the passkey prompt."
          }), " The first ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "chat()"
          }), " of a session raises a native\nWebAuthn / Touch-ID dialog to unseal the model key. A human has to tap it once;\nit can't be automated (see the gaps). After that the loop runs unattended."]
        }), "\n"]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The agent reads the files with its tools, writes the new files into the CoW mount,\nand the preview hot-reloads. Review the diff, then ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Contribute"
      }), " to open a PR.\n(See ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "./creating-a-component.md",
        children: "creating-a-component.md"
      }), " for the five edits the\nagent should end up making — that's your review checklist.)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "verifying-iterating-driving-it-yourself",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "verifying-iterating-driving-it-yourself"
      }), "Verifying / iterating (driving it yourself)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "The honest way to confirm any of this — and to catch the \"works locally, breaks on\nthe host\" failures — is to drive a real browser and watch the SDK channel."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "Chrome DevTools MCP"
          }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "mcp__chrome-devtools__*"
          }), "): take an accessibility\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "snapshot"
          }), " for element ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "uid"
          }), "s, fill/click, then read the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "console"
          }), " and\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "network"
          }), ". The decisive signal for ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "this"
          }), " flow is a\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "POST https://openrouter.ai/api/v1/chat/completions"
          }), " carrying\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "\"model\":\"z-ai/glm-5.2\""
          }), " with a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "tools"
          }), " array, and a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "read_file"
          }), " tool result that\nreturns ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "real Grove file content"
          }), " (not ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "not found"
          }), ")."]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "Controlled-input gotcha:"
          }), " the prompt box is a React controlled input.\nProgrammatically ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "setting"
          }), " its value (e.g. Chrome MCP ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "fill"
          }), ") does ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "not"
          }), " arm\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "Run"
          }), " — only real keystrokes (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "type_text"
          }), ") sync React state. Type, don't set."]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "Testing an unmerged agent-demo:"
          }), " to run a local agent-demo build ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "as the\nworkbench"
          }), " (e.g. before a change is merged), dev-override the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "stage.conversation"
          }), "\nregion with Grove still the previewed app:"]
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            className: "language-bash",
            children: "# in a checkout of immediately-run/agent-demo\nimmediately.run dev --region stage.conversation \\\n  --preview \"edit/github/immediately-run/grove/main/\" \\\n  --origin https://local.immediately.run --json\n"
          })
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
          children: ["Open the printed deep link. The region shows a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "\"Customized binding\""
          }), " badge and\nloads your source over the loopback; the binding's working-tree exposure is\nre-derived from the build default, so the AA-23 ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "rw"
          }), " port still applies. (If the\noverride doesn't take on first load, reload once — the directive is persisted to\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "sessionStorage"
          }), " and applies on the next resolve.)"]
        }), "\n"]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "whats-still-rough-findings",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "whats-still-rough-findings"
      }), "What's still rough (findings)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Driving this with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "GLM 5.2 over OpenRouter"
      }), " surfaced real gaps. None of them\nbreak the architecture; they're UX and model-reliability edges."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["The first ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "chat()"
          }), " parks silently on the passkey unseal."]
        }), " Chrome-MCP (and\nany automation) can't tap the native WebAuthn dialog, so an unattended run sits\non \"Running…\" with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "no request, no error, no timeout"
        }), ". Keep a human on the\nkeyboard for that one tap. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Wanted: a visible \"waiting for unlock\" state and a\nturn timeout instead of a silent hang."
        })]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["GLM-via-OpenRouter sometimes announces tool calls but emits none —\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "intermittent"
          }), "."]
        }), " On some turns the model writes \"I'll read the files…\", reasons\nthrough it, then finishes with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "stop"
        }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "zero"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "tool_calls"
        }), "; and after a tool\nerror it can return an empty ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "stop"
        }), " (no text, no call) — a silent give-up. It is\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "not deterministic"
        }), ": the 2026-07-01 re-verify (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<Kbd>"
        }), ") ran fully clean — every\nturn returned ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "finish_reason: tool_calls"
        }), " and all 6 reads + 5 writes fired.\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Mitigated (agent-demo #14):"
        }), " the loop now has a bounded stall backstop — a\nno-tool-call turn that is empty or announces work without a call gets ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "one"
        }), "\ndirective nudge (\"emit the tool call now\") before it gives up, shown live as a\nmuted \"↺ nudging the model to continue…\" row. It's conservative (a genuine\nwrap-up is never nudged) and bounded (max one nudge per stall episode, reset by\nany tool-executing turn), so it recovers the common stalls without ever looping.\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Still wanted for the tail: auto-retry heuristics beyond a single nudge, or a more\nreliable provider route."
        })]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "No model picker in the UI."
        }), " Provider + model is a host preference set via the\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "window.__irLlmPref"
        }), " dev hook (step 2); the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Settings"
        }), " rail is still a stub\n(\"SETTINGS — SOON\") and doesn't navigate to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "/settings"
        }), ". ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Wanted: a real\nprovider+model selector on the conversation."
        })]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "A dead-end shows nothing."
        }), " When the model stops with empty content, the stage\nrenders only the (failed) tool chips — no \"I stopped because…\" line. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Wanted: a\nterminal-without-result state."
        })]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "recommendation",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "recommendation"
      }), "Recommendation"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The agent's architecture is right — a scoped rw working-tree port over the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "stage"
      }), "\napp (AA-23), real file tools, host-mediated ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "llm.chat"
      }), " (no per-app key), and a\ncapability-scoped tool catalog. The happy path works end-to-end today with a human\nfor the one passkey tap. The rough edges are ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "model selection UX"
      }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "GLM\ntool-call reliability"
      }), ", not the wiring."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: "For a smooth run, use a provider/model you've found reliable for tool-calling."
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["When the agent stalls mid-task or skips its tool calls, fall back to the manual\nsteps in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "./creating-a-component.md",
          children: "creating-a-component.md"
        }), " — which is how the\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<Quote>"
        }), " shipped in this repo was originally built."]
      }), "\n"]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/tutorials/building-with-the-in-browser-agent.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiYmxvY2txdW90ZSIsImNvZGUiLCJlbSIsImgxIiwiaDIiLCJoMyIsImxpIiwib2wiLCJwIiwicHJlIiwic3Ryb25nIiwidWwiLCJfcHJvdmlkZUNvbXBvbmVudHMiLCJjb21wb25lbnRzIiwiSGVhZGluZ0FuY2hvciIsIl9taXNzaW5nTWR4UmVmZXJlbmNlIiwianN4cyIsIkZyYWdtZW50IiwiY2hpbGRyZW4iLCJpZCIsImpzeCIsImhyZWYiLCJjbGFzc05hbWUiLCJNRFhDb250ZW50Iiwid3JhcHBlciIsIk1EWExheW91dCIsIl9jIiwiY29tcG9uZW50IiwicGxhY2UiLCJFcnJvciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbImJ1aWxkaW5nLXdpdGgtdGhlLWluLWJyb3dzZXItYWdlbnQubWQiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgYTogXCJhXCIsXG4gICAgYmxvY2txdW90ZTogXCJibG9ja3F1b3RlXCIsXG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgZW06IFwiZW1cIixcbiAgICBoMTogXCJoMVwiLFxuICAgIGgyOiBcImgyXCIsXG4gICAgaDM6IFwiaDNcIixcbiAgICBsaTogXCJsaVwiLFxuICAgIG9sOiBcIm9sXCIsXG4gICAgcDogXCJwXCIsXG4gICAgcHJlOiBcInByZVwiLFxuICAgIHN0cm9uZzogXCJzdHJvbmdcIixcbiAgICB1bDogXCJ1bFwiLFxuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfSwge0hlYWRpbmdBbmNob3J9ID0gX2NvbXBvbmVudHM7XG4gIGlmICghSGVhZGluZ0FuY2hvcikgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJIZWFkaW5nQW5jaG9yXCIsIHRydWUpO1xuICByZXR1cm4gPD48X2NvbXBvbmVudHMuaDEgaWQ9XCJidWlsZGluZy1hLWdyb3ZlLWNvbXBvbmVudC13aXRoLXRoZS1pbi1icm93c2VyLWNvZGluZy1hZ2VudFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiYnVpbGRpbmctYS1ncm92ZS1jb21wb25lbnQtd2l0aC10aGUtaW4tYnJvd3Nlci1jb2RpbmctYWdlbnRcIiAvPntcIkJ1aWxkaW5nIGEgR3JvdmUgY29tcG9uZW50IHdpdGggdGhlIGluLWJyb3dzZXIgY29kaW5nIGFnZW50XCJ9PC9fY29tcG9uZW50cy5oMT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJHcm92ZSdzIGNvbnRlbnQgaXMgbWVhbnQgdG8gYmUgY2hhbmdlZCBcIn08X2NvbXBvbmVudHMuZW0+e1wiYnkgYXNraW5nIGFuIGFnZW50XCJ9PC9fY29tcG9uZW50cy5lbT57XCIuIFRoZSBwbGF0Zm9ybSBhbHNvXFxuc2hpcHMgYSBnZW5lcmFsIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiaW4tYnJvd3NlciBjb2RpbmcgYWdlbnRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHRoZSBcXFwiQWdlbnRzXFxcIiBhY3Rpdml0eSkgdGhhdCByZWFkcyxcXG5zZWFyY2hlcywgYW5kIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZWRpdHMgdGhlIHJ1bm5pbmcgYXBwJ3MgZmlsZXNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgd2l0aCBhIHJlYWwgdG9vbC1jYWxsaW5nIGxvb3Ag4oCUXFxudGhlIHNhbWUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiPFF1b3RlPlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgY29tcG9uZW50IGZyb21cXG5cIn08X2NvbXBvbmVudHMuYSBocmVmPVwiLi9jcmVhdGluZy1hLWNvbXBvbmVudC5tZFwiPntcImNyZWF0aW5nLWEtY29tcG9uZW50Lm1kXCJ9PC9fY29tcG9uZW50cy5hPntcIiwgYnVpbHQgYnkgdGFsa2luZyBpbnN0ZWFkIG9mXFxudHlwaW5nLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGlzIGd1aWRlIGlzIHR3byB0aGluZ3MgYXQgb25jZTogdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wic3RlcHMgdGhhdCB3b3JrIHRvZGF5XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBhbmQgYW4gaG9uZXN0XFxubG9nIG9mIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wid2hhdCdzIHN0aWxsIHJvdWdoXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChpdCB3YXMgcHJvZHVjZWQgYnkgYWN0dWFsbHkgZHJpdmluZyB0aGUgYWdlbnRcXG5lbmQtdG8tZW5kIGFnYWluc3QgR3JvdmUgd2l0aCBHTE0gNS4yIG92ZXIgT3BlblJvdXRlciBhbmQgd3JpdGluZyBkb3duIHdoZXJlIGl0XFxuYnJva2UpLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuYmxvY2txdW90ZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlN0YXR1cywgMjAyNi0wNi0zMC5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhpcyBmbG93IG5vdyB3b3JrcyBlbmQtdG8tZW5kOiB0aGUgYWdlbnQgcmVhZHMgYW5kXFxud3JpdGVzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiR3JvdmUnc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB3b3JraW5nIHRyZWUgYW5kIEdyb3ZlIHJlLXJlbmRlcnMuIFRoYXQgbGFzdCBzZW50ZW5jZSB1c2VkIHRvXFxuYmUgZmFsc2Ug4oCUIHRoZSBhZ2VudCB3YXMgbW91bnRlZCBvbiBcIn08X2NvbXBvbmVudHMuZW0+e1wiaXRzIG93blwifTwvX2NvbXBvbmVudHMuZW0+e1wiIHJlcG8gYW5kIGV2ZXJ5IEdyb3ZlIHBhdGggcmVhZFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcIm5vdCBmb3VuZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuIFRoYXQgd2FzIHRoZSBBQS0yMyBnYXAsIG5vdyBmaXhlZCAoc2l0ZS1tYWluICMyMDggKyBhZ2VudC1kZW1vICMxMSkuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUmUtdmVyaWZpZWQgMjAyNi0wNy0wMVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBvbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJsb2NhbC5pbW1lZGlhdGVseS5ydW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHdpdGggR0xNIDUuMiBvdmVyXFxuT3BlblJvdXRlciwgZHJpdmluZyBhIFwifTxfY29tcG9uZW50cy5lbT57XCJmcmVzaFwifTwvX2NvbXBvbmVudHMuZW0+e1wiIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjxLYmQ+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjb21wb25lbnQgZW5kLXRvLWVuZDogNiByZWFsIFwifTxfY29tcG9uZW50cy5jb2RlPntcInJlYWRfZmlsZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCJzXFxuKG5vdCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJub3QgZm91bmRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSwgdGhlbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ3cml0ZV9maWxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiArIFwifTxfY29tcG9uZW50cy5jb2RlPntcImVkaXRfZmlsZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCLDlzQsIGFuZCBHcm92ZSdzIHByZXZpZXdcXG5ob3QtcmVsb2FkZWQgdG8gcmVuZGVyIHRoZSBuZXcgY29tcG9uZW50LiBHTE0gcmFuIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiY2xlYW4gdGhpcyB0aW1lXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBldmVyeVxcbnR1cm4gZW1pdHRlZCBpdHMgdG9vbCBjYWxscyAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZmluaXNoX3JlYXNvbjogdG9vbF9jYWxsc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLCBzbyB0aGUgXFxcImFubm91bmNlcyBidXRcXG5lbWl0cyBub25lXFxcIiBlZGdlIChmaW5kaW5ncyDCpzIpIGlzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiaW50ZXJtaXR0ZW50LCBub3QgZGV0ZXJtaW5pc3RpY1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIi4gVGhlIG9ubHlcXG5odW1hbiBzdGVwIHdhcyB0aGUgb25lIHBhc3NrZXkgdGFwICjCpzEpLiBBbHNvIGZpeGVkIG9uIHRoZSBzYW1lIGRheTogdGhlIGZpbGVcXG5leHBsb3JlciBub3cgbGFiZWxzIEdyb3ZlJ3Mgd29ya2luZyB0cmVlIFwifTxfY29tcG9uZW50cy5jb2RlPntcImltbWVkaWF0ZWx5LXJ1bi9ncm92ZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcmVhZC1vbmx5XFxuKHdhcyBtaXNsYWJlbGVkIGFzIHRoZSBleHBsb3JlcidzIG93biByZXBvLCByZWFkLXdyaXRlIOKAlCBzaXRlLW1haW4gIzIxMiArXFxuZmlsZS1leHBsb3JlciAjMjApLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08L19jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwiaG93LXRoZS1hZ2VudC1pcy13aXJlZFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiaG93LXRoZS1hZ2VudC1pcy13aXJlZFwiIC8+e1wiSG93IHRoZSBhZ2VudCBpcyB3aXJlZFwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJUaGUgYWdlbnQgaXMgdGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcImltbWVkaWF0ZWx5LXJ1bi9hZ2VudC1kZW1vXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhcHAsIGJvdW5kIGluIHRoZSBidWlsZC1kZWZhdWx0XFxucmVnaXN0cnkgdG8gdHdvIHJlZ2lvbnM6IFwifTxfY29tcG9uZW50cy5zdHJvbmc+PF9jb21wb25lbnRzLmNvZGU+e1wicGFuZWwuYWdlbnRcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICh0aGUgY29udmVyc2F0aW9uIGxpc3QsIGxlZnQpIGFuZFxcblwifTxfY29tcG9uZW50cy5zdHJvbmc+PF9jb21wb25lbnRzLmNvZGU+e1wic3RhZ2UuY29udmVyc2F0aW9uXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAodGhlIG1haW4gcGFuZSDigJQgd2hlcmUgeW91IHR5cGUgYW5kIHRoZSBhZ2VudCBydW5zKS5cXG5PcGVuIGl0IHdpdGggdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiXFxcIkFnZW50c1xcXCJcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYnV0dG9uIGluIHRoZSBsZWZ0IGFjdGl2aXR5IHJhaWwgKGVkaXQgbW9kZSkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJJdCBhdXRob3JzIHRoZSBcIn08X2NvbXBvbmVudHMuZW0+e1wic3RhZ2UgYXBwJ3NcIn08L19jb21wb25lbnRzLmVtPntcIiB3b3JraW5nIHRyZWUsIG5vdCBpdHMgb3duIChBQS0yMykuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFdoaWxlIEdyb3ZlXFxuaXMgdGhlIGxvYWRlZCBhcHAsIHRoZSBob3N0IGNvbmZlcnMgR3JvdmUncyB3b3JraW5nIHRyZWUgdG8gdGhlIGFnZW50IGFzIGFcXG5zY29wZWQsIHJlYWQtd3JpdGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wid29ya3RyZWVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG1vdW50IOKAlCB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJlZGl0b3IncyBjcm9zcy1yZXBvIGdyYW50IGtpbmRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIsIG5vdFxcblxcXCJzZWxmLWFjY2Vzcy5cXFwiIFRoZSBhZ2VudCdzIGZpbGVzeXN0ZW0gdG9vbHMgKFwifTxfY29tcG9uZW50cy5jb2RlPntcInJlYWRfZmlsZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIndyaXRlX2ZpbGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcImVkaXRfZmlsZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcImxpc3RfZGlyXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZ2xvYlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcImdyZXBcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzdGF0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZGVsZXRlX2ZpbGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSBhcmUgY2hyb290ZWQgdG9cXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInRoYXRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdHJlZSwgbWVyZ2VkIHdpdGggdGhlIGFwcCdzIGNhcGFiaWxpdHkgY2F0YWxvZyAodGhlIGhlYWRlciBzaG93cyB0aGVcXG5tZXJnZWQgY291bnQsIGUuZy4gXFxcIjIzIHRvb2xzIChjYXRhbG9nICsgZmlsZXMpXFxcIiDigJQgdGhlIGV4YWN0IG51bWJlciB0cmFja3MgdGhlXFxuY2F0YWxvZyBhbmQgZHJpZnRzLCBzbyByZWFkIHRoZSBcXFwiY2F0YWxvZyArIGZpbGVzXFxcIiBzdWZmaXgsIG5vdCB0aGUgZGlnaXQpLiBTd2l0Y2hcXG53aGljaCBhcHAgaXMgbG9hZGVkIGFuZCB0aGUgcHJpb3IgcG9ydCBpcyB0b3JuIGRvd24gYW5kIGEgbmV3IG9uZSBtaW50ZWQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJJbmZlcmVuY2UgZ29lcyB0aHJvdWdoIHRoZSBwbGF0Zm9ybSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJsbG0uY2hhdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgc2VydmljZSwgbm90IGEgcGVyLWFwcCBrZXkuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiXFxuVGhlIGFnZW50IGNhbGxzIHRoZSBob3N0LW1lZGlhdGVkIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNoYXQoKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYW5kIG5lZWRzIG9ubHkgdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+PF9jb21wb25lbnRzLmNvZGU+e1wibGxtOmNoYXRcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiXFxuY2FwYWJpbGl0eSDigJQgXCJ9PF9jb21wb25lbnRzLmVtPntcIm5vXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibmV0OmZldGNoXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgbm8gYnJpbmcteW91ci1vd24ta2V5IHBvd2VyYm94LiBUaGUgYXBwIG5hbWVzIG5vXFxudmVuZG9yIGFuZCBubyBtb2RlbDsgdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiaG9zdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiByZXNvbHZlcyB5b3VyIHByb3ZpZGVyL21vZGVsIHByZWZlcmVuY2UgYW5kXFxuaW5qZWN0cyB0aGUga2V5IHBlciByZXF1ZXN0LCBzbyB0aGUgYXBwIG5ldmVyIHNlZXMgdGhlIHNlY3JldC4gKFRoaXMgcmVwbGFjZWQgdGhlXFxub2xkIEJZT0svXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibmV0OmZldGNoXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBkZXNpZ24g4oCUIGlmIHlvdSBmaW5kIGRvY3MgbWVudGlvbmluZyBhbiBcXFwiQWRkIE9wZW5Sb3V0ZXIga2V5XFxcIlxcbmJ1dHRvbiBvciBcIn08X2NvbXBvbmVudHMuY29kZT57XCJtb2RlbENsaWVudC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIHRoZXkncmUgaGlzdG9yaWNhbC4pXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInRoZS1oYXBweS1wYXRoLXdoYXQtd29ya3NcIj48SGVhZGluZ0FuY2hvciBpZD1cInRoZS1oYXBweS1wYXRoLXdoYXQtd29ya3NcIiAvPntcIlRoZSBoYXBweSBwYXRoICh3aGF0IHdvcmtzKVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwic2VjLTFcIiBkYXRhLXNsdWc9XCIxLWxvYWQtZ3JvdmUtd2l0aC1hLXdyaXRhYmxlLW1vdW50XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtMVwiIC8+e1wiMS4gTG9hZCBHcm92ZSB3aXRoIGEgd3JpdGFibGUgbW91bnRcIn08L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5jb2RlPntcImltbWVkaWF0ZWx5LnJ1biBkZXZcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChsb2NhbCBwcm92aWRlcikgaXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJyZWFkLW9ubHkgYnkgY29uc3RydWN0aW9uXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBzbyB0aGVcXG5hZ2VudCBjYW4ndCBwZXJzaXN0IGVkaXRzIHRvIGEgbG9jYWxseS1zZXJ2ZWQgdHJlZS4gTG9hZCBHcm92ZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImZyb20gR2l0SHViXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiXFxuaW5zdGVhZCDigJQgdGhhdCBnaXZlcyBhIHdyaXRhYmxlIGNvcHktb24td3JpdGUgbW91bnQsIGFuZCB5b3UgcGVyc2lzdCB3aXRoIHRoZVxcbm5vcm1hbCBDb250cmlidXRlIC8gUFIgZmxvdzpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnByZT48X2NvbXBvbmVudHMuY29kZT57XCJodHRwczovL2xvY2FsLmltbWVkaWF0ZWx5LnJ1bi9lZGl0L2dpdGh1Yi9pbW1lZGlhdGVseS1ydW4vZ3JvdmUvbWFpbi9cXG5cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5wcmU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiKFVzZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJsb2NhbC5pbW1lZGlhdGVseS5ydW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGZvciB0aGUgbG9jYWwgaG9zdCwgb3IgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW1tZWRpYXRlbHkucnVuXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBmb3IgcHJvZCDigJRcXG5uZXZlciBcIn08X2NvbXBvbmVudHMuY29kZT57XCJsb2NhbGhvc3RcIn08L19jb21wb25lbnRzLmNvZGU+e1wiOyBjb25maWcgaXMga2V5ZWQgYnkgaG9zdG5hbWUuKVwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCJzZWMtMlwiIGRhdGEtc2x1Zz1cIjItc2V0LXRoZS1wcm92aWRlci1hbmQtbW9kZWwtb25lLXRpbWVcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy0yXCIgLz57XCIyLiBTZXQgdGhlIHByb3ZpZGVyIGFuZCBtb2RlbCAob25lLXRpbWUpXCJ9PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGVyZSBpcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vIFNldHRpbmdzIFVJIHlldFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoc2VlIHRoZSBnYXBzIGJlbG93KSwgc28gdGhlIHByb3ZpZGVyL21vZGVsXFxucHJlZmVyZW5jZSBpcyBzZXQgd2l0aCBhIGRldiBob29rLiBJbiB0aGUgaG9zdCdzIHRvcC1mcmFtZSBjb25zb2xlOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucHJlPjxfY29tcG9uZW50cy5jb2RlIGNsYXNzTmFtZT1cImxhbmd1YWdlLWpzXCI+e1wiYXdhaXQgd2luZG93Ll9faXJMbG1QcmVmLnNldCh7IHByb3ZpZGVySWQ6ICdsbG0uY2hhdC5vcGVucm91dGVyJywgbW9kZWw6ICd6LWFpL2dsbS01LjInIH0pXFxuLy8gcmVhZCBpdCBiYWNrOiBhd2FpdCB3aW5kb3cuX19pckxsbVByZWYuZ2V0KClcXG5cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5wcmU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhpcyB3cml0ZXMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiL2V0Yy9jb25maWcvbGxtLXByb3ZpZGVyLmpzb25cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGluIHRoZSBob3N0J3MgWmVuRlMuIFRoZSBPcGVuUm91dGVyXFxua2V5IGl0c2VsZiBpcyBzdG9yZWQgb25jZSwgaG9zdC1zaWRlLCBzZWFsZWQgd2l0aCB5b3VyIHBhc3NrZXkg4oCUIHRoZSBhcHAgbmV2ZXJcXG5zZWVzIGl0LiBHTE0gNS4yJ3MgT3BlblJvdXRlciBzbHVnIGlzIFwifTxfY29tcG9uZW50cy5jb2RlPntcInotYWkvZ2xtLTUuMlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cInNlYy0zXCIgZGF0YS1zbHVnPVwiMy1vcGVuLXRoZS1hZ2VudC1hbmQtYXNrLWZvci10aGUtY29tcG9uZW50XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtM1wiIC8+e1wiMy4gT3BlbiB0aGUgYWdlbnQgYW5kIGFzayBmb3IgdGhlIGNvbXBvbmVudFwifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJDbGljayBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIkFnZW50c1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBpbiB0aGUgbGVmdCByYWlsLiBUaGUgbWFpbiBwYW5lIGJlY29tZXMgdGhlIGNvbnZlcnNhdGlvbjsgdGhlXFxuaGVhZGVyIHNob3VsZCByZWFkIFxcXCLigKYgdG9vbHMgKGNhdGFsb2cgKyBmaWxlcylcXFwiLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUeXBlIGEgc2VsZi1jb250YWluZWQgcHJvbXB0IGFuZCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlJ1blwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIi4gR2l2ZSBpdCB0aGUgY29udmVudGlvbnMgdXAgZnJvbnQgc29cXG5pdCBkb2Vzbid0IGhhdmUgdG8gZ3Vlc3Mg4oCUIHBvaW50IGl0IGF0IHRoZSBzYW1lIHJ1bGVzIGh1bWFucyBmb2xsb3c6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkNyZWF0ZSBhIG5ldyBNRFggY29tcG9uZW50IFwifTxfY29tcG9uZW50cy5jb2RlPntcIjxRdW90ZT5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKApiBGaXJzdCByZWFkIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkNMQVVERS5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL21keENvbXBvbmVudHMudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBhbmQgdGhlIGV4aXN0aW5nIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkNhbGxvdXQudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAvIFwifTxfY29tcG9uZW50cy5jb2RlPntcIldpa2lMaW5rLnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgL1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcImluZGV4LmNzc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdG8gbWF0Y2ggY29udmVudGlvbnMuIFRoZW4gY3JlYXRlIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9jb21wb25lbnRzL1F1b3RlLnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG4oZGVmYXVsdCBleHBvcnQsIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wib25seVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB0aGUgY29tcG9uZW50KSwgYWRkIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi5ncm92ZS1xdW90ZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgc3R5bGVzIHVzaW5nIHRoZVxcbmRlc2lnbiB0b2tlbnMsIHJlZ2lzdGVyIGl0IGluIHRoZSBNRFggY29tcG9uZW50IG1hcCwgYW5kIGFkZCBhIGRlbW8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiPFF1b3RlPlwifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG50byBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjb250ZW50L2hvbWUubWR4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi4gUmV1c2UgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiPFdpa2lMaW5rPlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZm9yIHRoZSBzb3VyY2UgbGluay5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUGljayBhIGNvbXBvbmVudCB0aGF0IGRvZXNuJ3QgYWxyZWFkeSBleGlzdC5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiPFF1b3RlPlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKGFuZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCI8Q2FsbG91dD5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcIjxXaWtpTGluaz5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCI8S2V5VmFsdWU+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwg4oCmKSBhbHJlYWR5IHNoaXAgaW4gdGhpcyByZXBvIGFuZCBhcmUgcmVnaXN0ZXJlZCBpblxcblwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9tZHhDb21wb25lbnRzLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgYXNraW5nIGZvciBvbmUgb2YgdGhvc2UgaGFzIHRoZSBhZ2VudCBcIn08X2NvbXBvbmVudHMuZW0+e1wicmV3cml0ZVwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGFuXFxuZXhpc3RpbmcgZmlsZSwgc28geW91IGNhbid0IHRlbGwgYSByZWFsIGNyZWF0ZSBmcm9tIGEgbm8tb3AuIEZvciBhIGNsZWFuIHJ1blxcbnBpY2sgYSBmcmVzaCBuYW1lIGFuZCBzd2FwIGl0IHRocm91Z2ggdGhlIHByb21wdCAodGhlIDIwMjYtMDctMDEgcmUtdmVyaWZ5IHVzZWRcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCI8S2JkPlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIGEga2V5Y2FwOiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvY29tcG9uZW50cy9LYmQudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLmdyb3ZlLWtiZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiPEtiZD7ijJhLPC9LYmQ+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIlxcbmRlbW8pLiBTa2ltIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9jb21wb25lbnRzL1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZmlyc3QgdG8gc2VlIHdoYXQncyB0YWtlbi5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQXBwcm92ZSB0aGUgcGFzc2tleSBwcm9tcHQuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRoZSBmaXJzdCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjaGF0KClcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG9mIGEgc2Vzc2lvbiByYWlzZXMgYSBuYXRpdmVcXG5XZWJBdXRobiAvIFRvdWNoLUlEIGRpYWxvZyB0byB1bnNlYWwgdGhlIG1vZGVsIGtleS4gQSBodW1hbiBoYXMgdG8gdGFwIGl0IG9uY2U7XFxuaXQgY2FuJ3QgYmUgYXV0b21hdGVkIChzZWUgdGhlIGdhcHMpLiBBZnRlciB0aGF0IHRoZSBsb29wIHJ1bnMgdW5hdHRlbmRlZC5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSBhZ2VudCByZWFkcyB0aGUgZmlsZXMgd2l0aCBpdHMgdG9vbHMsIHdyaXRlcyB0aGUgbmV3IGZpbGVzIGludG8gdGhlIENvVyBtb3VudCxcXG5hbmQgdGhlIHByZXZpZXcgaG90LXJlbG9hZHMuIFJldmlldyB0aGUgZGlmZiwgdGhlbiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIkNvbnRyaWJ1dGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdG8gb3BlbiBhIFBSLlxcbihTZWUgXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cIi4vY3JlYXRpbmctYS1jb21wb25lbnQubWRcIj57XCJjcmVhdGluZy1hLWNvbXBvbmVudC5tZFwifTwvX2NvbXBvbmVudHMuYT57XCIgZm9yIHRoZSBmaXZlIGVkaXRzIHRoZVxcbmFnZW50IHNob3VsZCBlbmQgdXAgbWFraW5nIOKAlCB0aGF0J3MgeW91ciByZXZpZXcgY2hlY2tsaXN0LilcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwidmVyaWZ5aW5nLWl0ZXJhdGluZy1kcml2aW5nLWl0LXlvdXJzZWxmXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJ2ZXJpZnlpbmctaXRlcmF0aW5nLWRyaXZpbmctaXQteW91cnNlbGZcIiAvPntcIlZlcmlmeWluZyAvIGl0ZXJhdGluZyAoZHJpdmluZyBpdCB5b3Vyc2VsZilcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSBob25lc3Qgd2F5IHRvIGNvbmZpcm0gYW55IG9mIHRoaXMg4oCUIGFuZCB0byBjYXRjaCB0aGUgXFxcIndvcmtzIGxvY2FsbHksIGJyZWFrcyBvblxcbnRoZSBob3N0XFxcIiBmYWlsdXJlcyDigJQgaXMgdG8gZHJpdmUgYSByZWFsIGJyb3dzZXIgYW5kIHdhdGNoIHRoZSBTREsgY2hhbm5lbC5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkNocm9tZSBEZXZUb29scyBNQ1BcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1jcF9fY2hyb21lLWRldnRvb2xzX18qXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIik6IHRha2UgYW4gYWNjZXNzaWJpbGl0eVxcblwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wic25hcHNob3RcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgZm9yIGVsZW1lbnQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widWlkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcInMsIGZpbGwvY2xpY2ssIHRoZW4gcmVhZCB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJjb25zb2xlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGFuZFxcblwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibmV0d29ya1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIi4gVGhlIGRlY2lzaXZlIHNpZ25hbCBmb3IgXCJ9PF9jb21wb25lbnRzLmVtPntcInRoaXNcIn08L19jb21wb25lbnRzLmVtPntcIiBmbG93IGlzIGFcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJQT1NUIGh0dHBzOi8vb3BlbnJvdXRlci5haS9hcGkvdjEvY2hhdC9jb21wbGV0aW9uc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgY2FycnlpbmdcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJcXFwibW9kZWxcXFwiOlxcXCJ6LWFpL2dsbS01LjJcXFwiXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB3aXRoIGEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widG9vbHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFycmF5LCBhbmQgYSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyZWFkX2ZpbGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHRvb2wgcmVzdWx0IHRoYXRcXG5yZXR1cm5zIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicmVhbCBHcm92ZSBmaWxlIGNvbnRlbnRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKG5vdCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJub3QgZm91bmRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJDb250cm9sbGVkLWlucHV0IGdvdGNoYTpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdGhlIHByb21wdCBib3ggaXMgYSBSZWFjdCBjb250cm9sbGVkIGlucHV0LlxcblByb2dyYW1tYXRpY2FsbHkgXCJ9PF9jb21wb25lbnRzLmVtPntcInNldHRpbmdcIn08L19jb21wb25lbnRzLmVtPntcIiBpdHMgdmFsdWUgKGUuZy4gQ2hyb21lIE1DUCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmaWxsXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikgZG9lcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBhcm1cXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlJ1blwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgb25seSByZWFsIGtleXN0cm9rZXMgKFwifTxfY29tcG9uZW50cy5jb2RlPntcInR5cGVfdGV4dFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpIHN5bmMgUmVhY3Qgc3RhdGUuIFR5cGUsIGRvbid0IHNldC5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUZXN0aW5nIGFuIHVubWVyZ2VkIGFnZW50LWRlbW86XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHRvIHJ1biBhIGxvY2FsIGFnZW50LWRlbW8gYnVpbGQgXCJ9PF9jb21wb25lbnRzLmVtPntcImFzIHRoZVxcbndvcmtiZW5jaFwifTwvX2NvbXBvbmVudHMuZW0+e1wiIChlLmcuIGJlZm9yZSBhIGNoYW5nZSBpcyBtZXJnZWQpLCBkZXYtb3ZlcnJpZGUgdGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcInN0YWdlLmNvbnZlcnNhdGlvblwifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG5yZWdpb24gd2l0aCBHcm92ZSBzdGlsbCB0aGUgcHJldmlld2VkIGFwcDpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnByZT48X2NvbXBvbmVudHMuY29kZSBjbGFzc05hbWU9XCJsYW5ndWFnZS1iYXNoXCI+e1wiIyBpbiBhIGNoZWNrb3V0IG9mIGltbWVkaWF0ZWx5LXJ1bi9hZ2VudC1kZW1vXFxuaW1tZWRpYXRlbHkucnVuIGRldiAtLXJlZ2lvbiBzdGFnZS5jb252ZXJzYXRpb24gXFxcXFxcbiAgLS1wcmV2aWV3IFxcXCJlZGl0L2dpdGh1Yi9pbW1lZGlhdGVseS1ydW4vZ3JvdmUvbWFpbi9cXFwiIFxcXFxcXG4gIC0tb3JpZ2luIGh0dHBzOi8vbG9jYWwuaW1tZWRpYXRlbHkucnVuIC0tanNvblxcblwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnByZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJPcGVuIHRoZSBwcmludGVkIGRlZXAgbGluay4gVGhlIHJlZ2lvbiBzaG93cyBhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiXFxcIkN1c3RvbWl6ZWQgYmluZGluZ1xcXCJcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYmFkZ2UgYW5kXFxubG9hZHMgeW91ciBzb3VyY2Ugb3ZlciB0aGUgbG9vcGJhY2s7IHRoZSBiaW5kaW5nJ3Mgd29ya2luZy10cmVlIGV4cG9zdXJlIGlzXFxucmUtZGVyaXZlZCBmcm9tIHRoZSBidWlsZCBkZWZhdWx0LCBzbyB0aGUgQUEtMjMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicndcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHBvcnQgc3RpbGwgYXBwbGllcy4gKElmIHRoZVxcbm92ZXJyaWRlIGRvZXNuJ3QgdGFrZSBvbiBmaXJzdCBsb2FkLCByZWxvYWQgb25jZSDigJQgdGhlIGRpcmVjdGl2ZSBpcyBwZXJzaXN0ZWQgdG9cXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJzZXNzaW9uU3RvcmFnZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYW5kIGFwcGxpZXMgb24gdGhlIG5leHQgcmVzb2x2ZS4pXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJ3aGF0cy1zdGlsbC1yb3VnaC1maW5kaW5nc1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwid2hhdHMtc3RpbGwtcm91Z2gtZmluZGluZ3NcIiAvPntcIldoYXQncyBzdGlsbCByb3VnaCAoZmluZGluZ3MpXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJEcml2aW5nIHRoaXMgd2l0aCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIkdMTSA1LjIgb3ZlciBPcGVuUm91dGVyXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHN1cmZhY2VkIHJlYWwgZ2Fwcy4gTm9uZSBvZiB0aGVtXFxuYnJlYWsgdGhlIGFyY2hpdGVjdHVyZTsgdGhleSdyZSBVWCBhbmQgbW9kZWwtcmVsaWFiaWxpdHkgZWRnZXMuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgZmlyc3QgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2hhdCgpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBwYXJrcyBzaWxlbnRseSBvbiB0aGUgcGFzc2tleSB1bnNlYWwuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIENocm9tZS1NQ1AgKGFuZFxcbmFueSBhdXRvbWF0aW9uKSBjYW4ndCB0YXAgdGhlIG5hdGl2ZSBXZWJBdXRobiBkaWFsb2csIHNvIGFuIHVuYXR0ZW5kZWQgcnVuIHNpdHNcXG5vbiBcXFwiUnVubmluZ+KAplxcXCIgd2l0aCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vIHJlcXVlc3QsIG5vIGVycm9yLCBubyB0aW1lb3V0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLiBLZWVwIGEgaHVtYW4gb24gdGhlXFxua2V5Ym9hcmQgZm9yIHRoYXQgb25lIHRhcC4gXCJ9PF9jb21wb25lbnRzLmVtPntcIldhbnRlZDogYSB2aXNpYmxlIFxcXCJ3YWl0aW5nIGZvciB1bmxvY2tcXFwiIHN0YXRlIGFuZCBhXFxudHVybiB0aW1lb3V0IGluc3RlYWQgb2YgYSBzaWxlbnQgaGFuZy5cIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiR0xNLXZpYS1PcGVuUm91dGVyIHNvbWV0aW1lcyBhbm5vdW5jZXMgdG9vbCBjYWxscyBidXQgZW1pdHMgbm9uZSDigJRcXG5cIn08X2NvbXBvbmVudHMuZW0+e1wiaW50ZXJtaXR0ZW50XCJ9PC9fY29tcG9uZW50cy5lbT57XCIuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIE9uIHNvbWUgdHVybnMgdGhlIG1vZGVsIHdyaXRlcyBcXFwiSSdsbCByZWFkIHRoZSBmaWxlc+KAplxcXCIsIHJlYXNvbnNcXG50aHJvdWdoIGl0LCB0aGVuIGZpbmlzaGVzIHdpdGggXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3RvcFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYW5kIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiemVyb1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ0b29sX2NhbGxzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjsgYW5kIGFmdGVyIGEgdG9vbFxcbmVycm9yIGl0IGNhbiByZXR1cm4gYW4gZW1wdHkgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3RvcFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKG5vIHRleHQsIG5vIGNhbGwpIOKAlCBhIHNpbGVudCBnaXZlLXVwLiBJdCBpc1xcblwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibm90IGRldGVybWluaXN0aWNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCI6IHRoZSAyMDI2LTA3LTAxIHJlLXZlcmlmeSAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiPEtiZD5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSByYW4gZnVsbHkgY2xlYW4g4oCUIGV2ZXJ5XFxudHVybiByZXR1cm5lZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmaW5pc2hfcmVhc29uOiB0b29sX2NhbGxzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhbmQgYWxsIDYgcmVhZHMgKyA1IHdyaXRlcyBmaXJlZC5cXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIk1pdGlnYXRlZCAoYWdlbnQtZGVtbyAjMTQpOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB0aGUgbG9vcCBub3cgaGFzIGEgYm91bmRlZCBzdGFsbCBiYWNrc3RvcCDigJQgYVxcbm5vLXRvb2wtY2FsbCB0dXJuIHRoYXQgaXMgZW1wdHkgb3IgYW5ub3VuY2VzIHdvcmsgd2l0aG91dCBhIGNhbGwgZ2V0cyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm9uZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIlxcbmRpcmVjdGl2ZSBudWRnZSAoXFxcImVtaXQgdGhlIHRvb2wgY2FsbCBub3dcXFwiKSBiZWZvcmUgaXQgZ2l2ZXMgdXAsIHNob3duIGxpdmUgYXMgYVxcbm11dGVkIFxcXCLihrogbnVkZ2luZyB0aGUgbW9kZWwgdG8gY29udGludWXigKZcXFwiIHJvdy4gSXQncyBjb25zZXJ2YXRpdmUgKGEgZ2VudWluZVxcbndyYXAtdXAgaXMgbmV2ZXIgbnVkZ2VkKSBhbmQgYm91bmRlZCAobWF4IG9uZSBudWRnZSBwZXIgc3RhbGwgZXBpc29kZSwgcmVzZXQgYnlcXG5hbnkgdG9vbC1leGVjdXRpbmcgdHVybiksIHNvIGl0IHJlY292ZXJzIHRoZSBjb21tb24gc3RhbGxzIHdpdGhvdXQgZXZlciBsb29waW5nLlxcblwifTxfY29tcG9uZW50cy5lbT57XCJTdGlsbCB3YW50ZWQgZm9yIHRoZSB0YWlsOiBhdXRvLXJldHJ5IGhldXJpc3RpY3MgYmV5b25kIGEgc2luZ2xlIG51ZGdlLCBvciBhIG1vcmVcXG5yZWxpYWJsZSBwcm92aWRlciByb3V0ZS5cIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiTm8gbW9kZWwgcGlja2VyIGluIHRoZSBVSS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgUHJvdmlkZXIgKyBtb2RlbCBpcyBhIGhvc3QgcHJlZmVyZW5jZSBzZXQgdmlhIHRoZVxcblwifTxfY29tcG9uZW50cy5jb2RlPntcIndpbmRvdy5fX2lyTGxtUHJlZlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZGV2IGhvb2sgKHN0ZXAgMik7IHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlNldHRpbmdzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHJhaWwgaXMgc3RpbGwgYSBzdHViXFxuKFxcXCJTRVRUSU5HUyDigJQgU09PTlxcXCIpIGFuZCBkb2Vzbid0IG5hdmlnYXRlIHRvIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi9zZXR0aW5nc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIuIFwifTxfY29tcG9uZW50cy5lbT57XCJXYW50ZWQ6IGEgcmVhbFxcbnByb3ZpZGVyK21vZGVsIHNlbGVjdG9yIG9uIHRoZSBjb252ZXJzYXRpb24uXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkEgZGVhZC1lbmQgc2hvd3Mgbm90aGluZy5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgV2hlbiB0aGUgbW9kZWwgc3RvcHMgd2l0aCBlbXB0eSBjb250ZW50LCB0aGUgc3RhZ2VcXG5yZW5kZXJzIG9ubHkgdGhlIChmYWlsZWQpIHRvb2wgY2hpcHMg4oCUIG5vIFxcXCJJIHN0b3BwZWQgYmVjYXVzZeKAplxcXCIgbGluZS4gXCJ9PF9jb21wb25lbnRzLmVtPntcIldhbnRlZDogYVxcbnRlcm1pbmFsLXdpdGhvdXQtcmVzdWx0IHN0YXRlLlwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInJlY29tbWVuZGF0aW9uXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJyZWNvbW1lbmRhdGlvblwiIC8+e1wiUmVjb21tZW5kYXRpb25cIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSBhZ2VudCdzIGFyY2hpdGVjdHVyZSBpcyByaWdodCDigJQgYSBzY29wZWQgcncgd29ya2luZy10cmVlIHBvcnQgb3ZlciB0aGUgXCJ9PF9jb21wb25lbnRzLmVtPntcInN0YWdlXCJ9PC9fY29tcG9uZW50cy5lbT57XCJcXG5hcHAgKEFBLTIzKSwgcmVhbCBmaWxlIHRvb2xzLCBob3N0LW1lZGlhdGVkIFwifTxfY29tcG9uZW50cy5jb2RlPntcImxsbS5jaGF0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAobm8gcGVyLWFwcCBrZXkpLCBhbmQgYVxcbmNhcGFiaWxpdHktc2NvcGVkIHRvb2wgY2F0YWxvZy4gVGhlIGhhcHB5IHBhdGggd29ya3MgZW5kLXRvLWVuZCB0b2RheSB3aXRoIGEgaHVtYW5cXG5mb3IgdGhlIG9uZSBwYXNza2V5IHRhcC4gVGhlIHJvdWdoIGVkZ2VzIGFyZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm1vZGVsIHNlbGVjdGlvbiBVWFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBhbmQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJHTE1cXG50b29sLWNhbGwgcmVsaWFiaWxpdHlcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIsIG5vdCB0aGUgd2lyaW5nLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIkZvciBhIHNtb290aCBydW4sIHVzZSBhIHByb3ZpZGVyL21vZGVsIHlvdSd2ZSBmb3VuZCByZWxpYWJsZSBmb3IgdG9vbC1jYWxsaW5nLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIldoZW4gdGhlIGFnZW50IHN0YWxscyBtaWQtdGFzayBvciBza2lwcyBpdHMgdG9vbCBjYWxscywgZmFsbCBiYWNrIHRvIHRoZSBtYW51YWxcXG5zdGVwcyBpbiBcIn08X2NvbXBvbmVudHMuYSBocmVmPVwiLi9jcmVhdGluZy1hLWNvbXBvbmVudC5tZFwiPntcImNyZWF0aW5nLWEtY29tcG9uZW50Lm1kXCJ9PC9fY29tcG9uZW50cy5hPntcIiDigJQgd2hpY2ggaXMgaG93IHRoZVxcblwifTxfY29tcG9uZW50cy5jb2RlPntcIjxRdW90ZT5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHNoaXBwZWQgaW4gdGhpcyByZXBvIHdhcyBvcmlnaW5hbGx5IGJ1aWx0LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD48Lz47XG59XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNRFhDb250ZW50KHByb3BzID0ge30pIHtcbiAgY29uc3Qge3dyYXBwZXI6IE1EWExheW91dH0gPSB7XG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9O1xuICByZXR1cm4gTURYTGF5b3V0ID8gPE1EWExheW91dCB7Li4ucHJvcHN9PjxfY3JlYXRlTWR4Q29udGVudCB7Li4ucHJvcHN9IC8+PC9NRFhMYXlvdXQ+IDogX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpO1xufVxuZnVuY3Rpb24gX21pc3NpbmdNZHhSZWZlcmVuY2UoaWQsIGNvbXBvbmVudCwgcGxhY2UpIHtcbiAgdGhyb3cgbmV3IEVycm9yKFwiRXhwZWN0ZWQgXCIgKyAoY29tcG9uZW50ID8gXCJjb21wb25lbnRcIiA6IFwib2JqZWN0XCIpICsgXCIgYFwiICsgaWQgKyBcImAgdG8gYmUgZGVmaW5lZDogeW91IGxpa2VseSBmb3Jnb3QgdG8gaW1wb3J0LCBwYXNzLCBvciBwcm92aWRlIGl0LlwiICsgKHBsYWNlID8gXCJcXG5JdOKAmXMgcmVmZXJlbmNlZCBpbiB5b3VyIGNvZGUgYXQgYFwiICsgcGxhY2UgKyBcImAgaW4gYC9hcHAvZG9jcy90dXRvcmlhbHMvYnVpbGRpbmctd2l0aC10aGUtaW4tYnJvd3Nlci1hZ2VudC5tZGBcIiA6IFwiXCIpKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQXdGLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUZ4RjtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU1DLFdBQVcsR0FBRztNQUNsQkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsVUFBVSxFQUFFLFlBQVk7TUFDeEJDLElBQUksRUFBRSxNQUFNO01BQ1pDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLENBQUMsRUFBRSxHQUFHO01BQ05DLEdBQUcsRUFBRSxLQUFLO01BQ1ZDLE1BQU0sRUFBRSxRQUFRO01BQ2hCQyxFQUFFLEVBQUUsSUFBSTtNQUNSLEdBQUcsSUFBQUMsNkJBQWtCLEVBQUMsQ0FBQztNQUN2QixHQUFHZixLQUFLLENBQUNnQjtJQUNYLENBQUM7SUFBRTtNQUFDQztJQUFhLENBQUMsR0FBR2hCLFdBQVc7RUFDaEMsSUFBSSxDQUFDZ0IsYUFBYSxFQUFFQyxvQkFBb0IsQ0FBQyxlQUFlLEVBQUUsSUFBSSxDQUFDO0VBQy9ELG9CQUFPLElBQUFwQixXQUFBLENBQUFxQixJQUFBLEVBQUFyQixXQUFBLENBQUFzQixRQUFBO0lBQUFDLFFBQUEsZ0JBQUUsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDZ0IsRUFBRSxFQUFDLDZEQUE2RDtNQUFBRCxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQTZELENBQUUsQ0FBQyxFQUFDLDZEQUE2RDtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBVSxRQUFBLEdBQUUseUNBQXlDLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0ksRUFBRTtRQUFBZ0IsUUFBQSxFQUFFO01BQW9CLENBQWlCLENBQUMsRUFBQyx1Q0FBdUMsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUF5QixDQUFxQixDQUFDLEVBQUMsd0RBQXdELGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBK0IsQ0FBcUIsQ0FBQyxFQUFDLDZDQUE2QyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUFTLENBQW1CLENBQUMsRUFBQyxtQkFBbUIsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDQyxDQUFDO1FBQUNzQixJQUFJLEVBQUMsMkJBQTJCO1FBQUFILFFBQUEsRUFBRTtNQUF5QixDQUFnQixDQUFDLEVBQUMsd0NBQXdDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDVSxDQUFDO01BQUFVLFFBQUEsR0FBRSx3Q0FBd0MsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUF1QixDQUFxQixDQUFDLEVBQUMsMEJBQTBCLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBb0IsQ0FBcUIsQ0FBQyxFQUFDLDJJQUEySTtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0UsVUFBVTtNQUFBa0IsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDVSxDQUFDO1FBQUFVLFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBcUIsQ0FBcUIsQ0FBQyxFQUFDLCtEQUErRCxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQVMsQ0FBcUIsQ0FBQyxFQUFDLHNHQUFzRyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNJLEVBQUU7VUFBQWdCLFFBQUEsRUFBRTtRQUFTLENBQWlCLENBQUMsRUFBQyxtQ0FBbUMsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsd0VBQXdFO01BQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDVSxDQUFDO1FBQUFVLFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBd0IsQ0FBcUIsQ0FBQyxFQUFDLE1BQU0sZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBdUIsQ0FBbUIsQ0FBQyxFQUFDLDRDQUE0QyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNJLEVBQUU7VUFBQWdCLFFBQUEsRUFBRTtRQUFPLENBQWlCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQU8sQ0FBbUIsQ0FBQyxFQUFDLGdDQUFnQyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyxVQUFVLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLFVBQVUsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBWSxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyw2RUFBNkUsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFpQixDQUFxQixDQUFDLEVBQUMseUNBQXlDLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQTJCLENBQW1CLENBQUMsRUFBQyxnRUFBZ0UsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFpQyxDQUFxQixDQUFDLEVBQUMsc0lBQXNJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQXVCLENBQW1CLENBQUMsRUFBQyw0R0FBNEc7TUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQXlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDZSxFQUFFLEVBQUMsd0JBQXdCO01BQUFELFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBd0IsQ0FBRSxDQUFDLEVBQUMsd0JBQXdCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBeEIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDYSxFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBWSxRQUFBLEdBQUUsbUJBQW1CLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQTRCLENBQW1CLENBQUMsRUFBQyw2REFBNkQsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFRLFFBQUEsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1lBQUFpQixRQUFBLEVBQUU7VUFBYSxDQUFtQjtRQUFDLENBQW9CLENBQUMsRUFBQyxzQ0FBc0MsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFRLFFBQUEsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1lBQUFpQixRQUFBLEVBQUU7VUFBb0IsQ0FBbUI7UUFBQyxDQUFvQixDQUFDLEVBQUMsMEVBQTBFLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBWSxDQUFxQixDQUFDLEVBQUMsZ0RBQWdEO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBUSxRQUFBLEdBQUUsaUJBQWlCLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0ksRUFBRTtZQUFBZ0IsUUFBQSxFQUFFO1VBQWEsQ0FBaUIsQ0FBQyxFQUFDLHFDQUFxQztRQUFBLENBQXFCLENBQUMsRUFBQywrR0FBK0csZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBVSxDQUFtQixDQUFDLEVBQUMsZUFBZSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQWdDLENBQXFCLENBQUMsRUFBQyx3REFBd0QsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFZLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBVSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFNLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQU0sQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBTSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyxxQkFBcUIsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFNLENBQXFCLENBQUMsRUFBQyx1VEFBdVQ7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNRLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFRLFFBQUEsR0FBRSxzQ0FBc0MsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1lBQUFpQixRQUFBLEVBQUU7VUFBVSxDQUFtQixDQUFDLEVBQUMsOEJBQThCO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLHNDQUFzQyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFRLENBQW1CLENBQUMsRUFBQyxzQkFBc0IsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFRLFFBQUEsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1lBQUFpQixRQUFBLEVBQUU7VUFBVSxDQUFtQjtRQUFDLENBQW9CLENBQUMsRUFBQyxpQkFBaUIsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDSSxFQUFFO1VBQUFnQixRQUFBLEVBQUU7UUFBSSxDQUFpQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQywrRUFBK0UsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFNLENBQXFCLENBQUMsRUFBQyw0SUFBNEksZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsNkVBQTZFLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQWdCLENBQW1CLENBQUMsRUFBQyx3QkFBd0I7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDZSxFQUFFLEVBQUMsMkJBQTJCO01BQUFELFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBMkIsQ0FBRSxDQUFDLEVBQUMsNkJBQTZCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBeEIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDTyxFQUFFO01BQUNjLEVBQUUsRUFBQyxPQUFPO01BQUMsYUFBVSxvQ0FBb0M7TUFBQUQsUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLHFDQUFxQztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBVSxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUFxQixDQUFtQixDQUFDLEVBQUMsdUJBQXVCLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBMkIsQ0FBcUIsQ0FBQyxFQUFDLDJFQUEyRSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQWEsQ0FBcUIsQ0FBQyxFQUFDLCtHQUErRztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1csR0FBRztNQUFBUyxRQUFBLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBaUIsUUFBQSxFQUFFO01BQXlFLENBQW1CO0lBQUMsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDVSxDQUFDO01BQUFVLFFBQUEsR0FBRSxPQUFPLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBaUIsUUFBQSxFQUFFO01BQXVCLENBQW1CLENBQUMsRUFBQywwQkFBMEIsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1FBQUFpQixRQUFBLEVBQUU7TUFBaUIsQ0FBbUIsQ0FBQyxFQUFDLHFCQUFxQixlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUFXLENBQW1CLENBQUMsRUFBQyxpQ0FBaUM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNPLEVBQUU7TUFBQ2MsRUFBRSxFQUFDLE9BQU87TUFBQyxhQUFVLHVDQUF1QztNQUFBRCxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMsMENBQTBDO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBeEIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDVSxDQUFDO01BQUFVLFFBQUEsR0FBRSxXQUFXLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBb0IsQ0FBcUIsQ0FBQyxFQUFDLG1IQUFtSDtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1csR0FBRztNQUFBUyxRQUFBLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtRQUFDcUIsU0FBUyxFQUFDLGFBQWE7UUFBQUosUUFBQSxFQUFFO01BQStJLENBQW1CO0lBQUMsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDVSxDQUFDO01BQUFVLFFBQUEsR0FBRSxjQUFjLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBaUIsUUFBQSxFQUFFO01BQStCLENBQW1CLENBQUMsRUFBQyw4SkFBOEosZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1FBQUFpQixRQUFBLEVBQUU7TUFBYyxDQUFtQixDQUFDLEVBQUMsR0FBRztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ08sRUFBRTtNQUFDYyxFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUsNENBQTRDO01BQUFELFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQyw2Q0FBNkM7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF4QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNTLEVBQUU7TUFBQVcsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFZLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1UsQ0FBQztVQUFBVSxRQUFBLEdBQUUsUUFBUSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07WUFBQVEsUUFBQSxFQUFFO1VBQVEsQ0FBcUIsQ0FBQyxFQUFDLG1IQUFtSDtRQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFZLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1UsQ0FBQztVQUFBVSxRQUFBLEdBQUUsbUNBQW1DLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtZQUFBUSxRQUFBLEVBQUU7VUFBSyxDQUFxQixDQUFDLEVBQUMsNkdBQTZHO1FBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDRSxVQUFVO1VBQUFrQixRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNVLENBQUM7WUFBQVUsUUFBQSxHQUFFLDZCQUE2QixlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7Y0FBQWlCLFFBQUEsRUFBRTtZQUFTLENBQW1CLENBQUMsRUFBQyxnQkFBZ0IsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO2NBQUFpQixRQUFBLEVBQUU7WUFBVyxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7Y0FBQWlCLFFBQUEsRUFBRTtZQUFzQixDQUFtQixDQUFDLEVBQUMscUJBQXFCLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBaUIsUUFBQSxFQUFFO1lBQWEsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO2NBQUFpQixRQUFBLEVBQUU7WUFBYyxDQUFtQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7Y0FBQWlCLFFBQUEsRUFBRTtZQUFXLENBQW1CLENBQUMsRUFBQyxxQ0FBcUMsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO2NBQUFpQixRQUFBLEVBQUU7WUFBMEIsQ0FBbUIsQ0FBQyxFQUFDLHFCQUFxQixlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07Y0FBQVEsUUFBQSxFQUFFO1lBQU0sQ0FBcUIsQ0FBQyxFQUFDLHVCQUF1QixlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7Y0FBQWlCLFFBQUEsRUFBRTtZQUFjLENBQW1CLENBQUMsRUFBQyx5RkFBeUYsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO2NBQUFpQixRQUFBLEVBQUU7WUFBUyxDQUFtQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7Y0FBQWlCLFFBQUEsRUFBRTtZQUFrQixDQUFtQixDQUFDLEVBQUMsVUFBVSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7Y0FBQWlCLFFBQUEsRUFBRTtZQUFZLENBQW1CLENBQUMsRUFBQyx1QkFBdUI7VUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSTtRQUFBLENBQXlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0UsVUFBVTtVQUFBa0IsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDVSxDQUFDO1lBQUFVLFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtjQUFBUSxRQUFBLEVBQUU7WUFBOEMsQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO2NBQUFpQixRQUFBLEVBQUU7WUFBUyxDQUFtQixDQUFDLEVBQUMsUUFBUSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7Y0FBQWlCLFFBQUEsRUFBRTtZQUFXLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBaUIsUUFBQSxFQUFFO1lBQVksQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO2NBQUFpQixRQUFBLEVBQUU7WUFBWSxDQUFtQixDQUFDLEVBQUMsd0RBQXdELGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBaUIsUUFBQSxFQUFFO1lBQXNCLENBQW1CLENBQUMsRUFBQywyQ0FBMkMsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDSSxFQUFFO2NBQUFnQixRQUFBLEVBQUU7WUFBUyxDQUFpQixDQUFDLEVBQUMsc0tBQXNLLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBaUIsUUFBQSxFQUFFO1lBQU8sQ0FBbUIsQ0FBQyxFQUFDLGVBQWUsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO2NBQUFpQixRQUFBLEVBQUU7WUFBd0IsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO2NBQUFpQixRQUFBLEVBQUU7WUFBWSxDQUFtQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7Y0FBQWlCLFFBQUEsRUFBRTtZQUFlLENBQW1CLENBQUMsRUFBQyxnQkFBZ0IsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO2NBQUFpQixRQUFBLEVBQUU7WUFBaUIsQ0FBbUIsQ0FBQyxFQUFDLDZCQUE2QjtVQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJO1FBQUEsQ0FBeUIsQ0FBQyxFQUFDLElBQUk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNRLEVBQUU7UUFBQVksUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDVSxDQUFDO1VBQUFVLFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtZQUFBUSxRQUFBLEVBQUU7VUFBNkIsQ0FBcUIsQ0FBQyxFQUFDLGFBQWEsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1lBQUFpQixRQUFBLEVBQUU7VUFBUSxDQUFtQixDQUFDLEVBQUMsNExBQTRMO1FBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBVSxRQUFBLEdBQUUseUlBQXlJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBWSxDQUFxQixDQUFDLEVBQUMsdUJBQXVCLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0MsQ0FBQztRQUFDc0IsSUFBSSxFQUFDLDJCQUEyQjtRQUFBSCxRQUFBLEVBQUU7TUFBeUIsQ0FBZ0IsQ0FBQyxFQUFDLHNGQUFzRjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDZSxFQUFFLEVBQUMseUNBQXlDO01BQUFELFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBeUMsQ0FBRSxDQUFDLEVBQUMsNkNBQTZDO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBeEIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDVSxDQUFDO01BQUFVLFFBQUEsRUFBRTtJQUFrSyxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNhLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFZLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1UsQ0FBQztVQUFBVSxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07WUFBQVEsUUFBQSxFQUFFO1VBQXFCLENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBaUIsUUFBQSxFQUFFO1VBQXlCLENBQW1CLENBQUMsRUFBQyw0QkFBNEIsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1lBQUFRLFFBQUEsRUFBRTtVQUFVLENBQXFCLENBQUMsRUFBQyxlQUFlLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBaUIsUUFBQSxFQUFFO1VBQUssQ0FBbUIsQ0FBQyxFQUFDLCtCQUErQixlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07WUFBQVEsUUFBQSxFQUFFO1VBQVMsQ0FBcUIsQ0FBQyxFQUFDLFFBQVEsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1lBQUFRLFFBQUEsRUFBRTtVQUFTLENBQXFCLENBQUMsRUFBQyw0QkFBNEIsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDSSxFQUFFO1lBQUFnQixRQUFBLEVBQUU7VUFBTSxDQUFpQixDQUFDLEVBQUMsY0FBYyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7WUFBQWlCLFFBQUEsRUFBRTtVQUFvRCxDQUFtQixDQUFDLEVBQUMsYUFBYSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7WUFBQWlCLFFBQUEsRUFBRTtVQUE0QixDQUFtQixDQUFDLEVBQUMsVUFBVSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7WUFBQWlCLFFBQUEsRUFBRTtVQUFPLENBQW1CLENBQUMsRUFBQyxnQkFBZ0IsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1lBQUFpQixRQUFBLEVBQUU7VUFBVyxDQUFtQixDQUFDLEVBQUMsNkJBQTZCLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtZQUFBUSxRQUFBLEVBQUU7VUFBeUIsQ0FBcUIsQ0FBQyxFQUFDLFFBQVEsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1lBQUFpQixRQUFBLEVBQUU7VUFBVyxDQUFtQixDQUFDLEVBQUMsSUFBSTtRQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFZLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1UsQ0FBQztVQUFBVSxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07WUFBQVEsUUFBQSxFQUFFO1VBQTBCLENBQXFCLENBQUMsRUFBQyxpRUFBaUUsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDSSxFQUFFO1lBQUFnQixRQUFBLEVBQUU7VUFBUyxDQUFpQixDQUFDLEVBQUMsOEJBQThCLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBaUIsUUFBQSxFQUFFO1VBQU0sQ0FBbUIsQ0FBQyxFQUFDLFNBQVMsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1lBQUFRLFFBQUEsRUFBRTtVQUFLLENBQXFCLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtZQUFBUSxRQUFBLEVBQUU7VUFBSyxDQUFxQixDQUFDLEVBQUMsMkJBQTJCLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBaUIsUUFBQSxFQUFFO1VBQVcsQ0FBbUIsQ0FBQyxFQUFDLHNDQUFzQztRQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFZLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1UsQ0FBQztVQUFBVSxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07WUFBQVEsUUFBQSxFQUFFO1VBQWlDLENBQXFCLENBQUMsRUFBQyxtQ0FBbUMsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDSSxFQUFFO1lBQUFnQixRQUFBLEVBQUU7VUFBbUIsQ0FBaUIsQ0FBQyxFQUFDLHNEQUFzRCxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7WUFBQWlCLFFBQUEsRUFBRTtVQUFvQixDQUFtQixDQUFDLEVBQUMsOENBQThDO1FBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDVyxHQUFHO1VBQUFTLFFBQUEsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1lBQUNxQixTQUFTLEVBQUMsZUFBZTtZQUFBSixRQUFBLEVBQUU7VUFBa04sQ0FBbUI7UUFBQyxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNVLENBQUM7VUFBQVUsUUFBQSxHQUFFLGlEQUFpRCxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07WUFBQVEsUUFBQSxFQUFFO1VBQXdCLENBQXFCLENBQUMsRUFBQywySUFBMkksZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1lBQUFpQixRQUFBLEVBQUU7VUFBSSxDQUFtQixDQUFDLEVBQUMsa0hBQWtILGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBaUIsUUFBQSxFQUFFO1VBQWdCLENBQW1CLENBQUMsRUFBQyxvQ0FBb0M7UUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDTSxFQUFFO01BQUNlLEVBQUUsRUFBQyw0QkFBNEI7TUFBQUQsUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUE0QixDQUFFLENBQUMsRUFBQywrQkFBK0I7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF4QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNVLENBQUM7TUFBQVUsUUFBQSxHQUFFLG9CQUFvQixlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQXlCLENBQXFCLENBQUMsRUFBQyxvR0FBb0c7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNTLEVBQUU7TUFBQVcsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBUSxRQUFBLEdBQUUsWUFBWSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7WUFBQWlCLFFBQUEsRUFBRTtVQUFRLENBQW1CLENBQUMsRUFBQyx3Q0FBd0M7UUFBQSxDQUFxQixDQUFDLEVBQUMsMEhBQTBILGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBa0MsQ0FBcUIsQ0FBQyxFQUFDLG9EQUFvRCxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNJLEVBQUU7VUFBQWdCLFFBQUEsRUFBRTtRQUE4RixDQUFpQixDQUFDO01BQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBUSxRQUFBLEdBQUUsc0VBQXNFLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0ksRUFBRTtZQUFBZ0IsUUFBQSxFQUFFO1VBQWMsQ0FBaUIsQ0FBQyxFQUFDLEdBQUc7UUFBQSxDQUFxQixDQUFDLEVBQUMsb0dBQW9HLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQU0sQ0FBbUIsQ0FBQyxFQUFDLE9BQU8sZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFNLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQVksQ0FBbUIsQ0FBQyxFQUFDLG1EQUFtRCxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFNLENBQW1CLENBQUMsRUFBQyxpREFBaUQsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFtQixDQUFxQixDQUFDLEVBQUMsOEJBQThCLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQU8sQ0FBbUIsQ0FBQyxFQUFDLDJDQUEyQyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUEyQixDQUFtQixDQUFDLEVBQUMsc0NBQXNDLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBNkIsQ0FBcUIsQ0FBQyxFQUFDLHdIQUF3SCxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQUssQ0FBcUIsQ0FBQyxFQUFDLHVVQUF1VSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNJLEVBQUU7VUFBQWdCLFFBQUEsRUFBRTtRQUE2RyxDQUFpQixDQUFDO01BQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBNEIsQ0FBcUIsQ0FBQyxFQUFDLHNEQUFzRCxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFvQixDQUFtQixDQUFDLEVBQUMsMEJBQTBCLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBVSxDQUFxQixDQUFDLEVBQUMsdUVBQXVFLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDSSxFQUFFO1VBQUFnQixRQUFBLEVBQUU7UUFBOEQsQ0FBaUIsQ0FBQztNQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQTJCLENBQXFCLENBQUMsRUFBQyw4SEFBOEgsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDSSxFQUFFO1VBQUFnQixRQUFBLEVBQUU7UUFBMkMsQ0FBaUIsQ0FBQztNQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDTSxFQUFFO01BQUNlLEVBQUUsRUFBQyxnQkFBZ0I7TUFBQUQsUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFnQixDQUFFLENBQUMsRUFBQyxnQkFBZ0I7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF4QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNVLENBQUM7TUFBQVUsUUFBQSxHQUFFLDZFQUE2RSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNJLEVBQUU7UUFBQWdCLFFBQUEsRUFBRTtNQUFPLENBQWlCLENBQUMsRUFBQyxnREFBZ0QsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1FBQUFpQixRQUFBLEVBQUU7TUFBVSxDQUFtQixDQUFDLEVBQUMsNkpBQTZKLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBb0IsQ0FBcUIsQ0FBQyxFQUFDLE9BQU8sZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUE0QixDQUFxQixDQUFDLEVBQUMsbUJBQW1CO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDYSxFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBWSxRQUFBLEVBQUU7TUFBZ0YsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFZLFFBQUEsR0FBRSw0RkFBNEYsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDQyxDQUFDO1VBQUNzQixJQUFJLEVBQUMsMkJBQTJCO1VBQUFILFFBQUEsRUFBRTtRQUF5QixDQUFnQixDQUFDLEVBQUMsdUJBQXVCLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQVMsQ0FBbUIsQ0FBQyxFQUFDLDZDQUE2QztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQztFQUFBLENBQUUsQ0FBQztBQUNwd25CO0FBQ2UsU0FBU0ssVUFBVUEsQ0FBQzFCLEtBQUssR0FBRyxDQUFDLENBQUMsRUFBRTtFQUM3QyxNQUFNO0lBQUMyQixPQUFPLEVBQUVDO0VBQVMsQ0FBQyxHQUFHO0lBQzNCLEdBQUcsSUFBQWIsNkJBQWtCLEVBQUMsQ0FBQztJQUN2QixHQUFHZixLQUFLLENBQUNnQjtFQUNYLENBQUM7RUFDRCxPQUFPWSxTQUFTLGdCQUFHLElBQUE5QixXQUFBLENBQUF5QixHQUFBLEVBQUNLLFNBQVM7SUFBQSxHQUFLNUIsS0FBSztJQUFBcUIsUUFBQSxlQUFFLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN4QixpQkFBaUI7TUFBQSxHQUFLQztJQUFLLENBQUc7RUFBQyxDQUFXLENBQUMsR0FBR0QsaUJBQWlCLENBQUNDLEtBQUssQ0FBQztBQUNsSDtBQUFDNkIsRUFBQSxHQU51QkgsVUFBVTtBQU9sQyxTQUFTUixvQkFBb0JBLENBQUNJLEVBQUUsRUFBRVEsU0FBUyxFQUFFQyxLQUFLLEVBQUU7RUFDbEQsTUFBTSxJQUFJQyxLQUFLLENBQUMsV0FBVyxJQUFJRixTQUFTLEdBQUcsV0FBVyxHQUFHLFFBQVEsQ0FBQyxHQUFHLElBQUksR0FBR1IsRUFBRSxHQUFHLG9FQUFvRSxJQUFJUyxLQUFLLEdBQUcscUNBQXFDLEdBQUdBLEtBQUssR0FBRyxrRUFBa0UsR0FBRyxFQUFFLENBQUMsQ0FBQztBQUM1UjtBQUFDLElBQUFGLEVBQUE7QUFBQUksWUFBQSxDQUFBSixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}