var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      li: "li",
      ol: "ol",
      p: "p",
      strong: "strong",
      table: "table",
      tbody: "tbody",
      td: "td",
      th: "th",
      thead: "thead",
      tr: "tr",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "the-grove-engine-boundary-what-lives-here-what-lives-in-a-corpus",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-grove-engine-boundary-what-lives-here-what-lives-in-a-corpus"
      }), "The Grove engine boundary — what lives here, what lives in a corpus"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Status:"
      }), " decision record · ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Recorded:"
      }), " 2026-08-13 · ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Item:"
      }), " R3-262"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["This repo is the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "canonical Grove engine"
      }), ". This document records why, what belongs in it,\nand what deliberately does not — so the fork that exists downstream is a known specialization\nrather than drift nobody is tracking. It exists because the drift already happened once: see\n§4."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-1",
      "data-slug": "1-canonical-home-this-repo",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-1"
      }), "1. Canonical home — this repo"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "immediately-run/grove"
      }), " is the engine. The ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "immediately-run/docs"
      }), " wiki carries a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "fork"
      }), " of\nit at its own repo root, and that fork is a recorded specialization, not a second engine."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The reason is dispatch. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "REPO_CONTENT_DISPATCH_SPEC"
      }), " resolves a content repo's\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "opensWith: { task: 'open-wiki' }"
      }), " marker through the binding registry to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "a Grove repo"
      }), ",\nwhich then renders that repo's content. Self-dispatch is refused — the viewer must be a\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "different program"
      }), " than the content it renders — so the engine has to be a repo of its own.\nThere is no arrangement where \"the docs wiki\" is the thing a stranger's content dispatches to."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The reason the fork exists anyway is the kernel: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "APP_ROOT"
      }), " is hard-coded to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "/app"
      }), " (the repo\nroot) with no subdirectory anchoring (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "sandbox/src/fsLayout.ts"
      }), "), so the bare\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "github/immediately-run/docs/main"
      }), " URL only boots if the engine sits at the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "docs"
      }), " repo root.\nThat constraint is real and unresolved; it is why the fork is tolerated rather than deleted."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "The follow-through, not yet done:"
      }), " once a viewer can render content from a mount\n(R3-168/R3-169), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "docs"
      }), " becomes an ordinary content corpus dispatched to this engine and the\nfork can go. Until then, an engine change lands ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "here first"
      }), " and is ported to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "docs"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-1a",
      "data-slug": "1a-what-grove-is-r3-280-recorded-2026-08-19",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-1a"
      }), "1a. What Grove IS (R3-280, recorded 2026-08-19)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Packaging the engine as a library forced the question, so record the answer: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Grove is a\n(plugin-extensible) kit of React components, prebuilt layouts and themes that together make\na wiki easy to build and good-looking by default — not a wiki engine in the traditional\nsense."
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Most of what a traditional wiki engine owns is not here, and should not be. Routing\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "Routes"
      }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "Route"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "sandboxPath"
      }), "), MDX compilation, the frontmatter metadata index and its\nsidecar, link spaces (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "corpusRoot"
      }), " + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "$fs:"
      }), "), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "Include"
      }), ", and heading anchors are all\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "sandbox + SDK"
      }), ", because they are cross-cutting concerns of ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "every"
      }), " immediately.run app,\nnot of wikis. What is left for Grove to own — and it is a real thing to own — is the\ncomponent vocabulary, the chrome, the layout chain, the themes, and the defaults that make\nthe result look considered without anyone tuning it."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Future scope stays inside that boundary. Author-facing collaboration features (Google-Docs\nstyle comment threads between authors, say) belong here because they are wiki-shaped\npresentation and interaction. Anything a second viewer would also need belongs one layer\ndown — that is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "PLATFORM_LAYERING_SPEC §5.1"
      }), "'s tier test (\"would Lodestar need to change it\nto use it?\"), and this framing is what makes it decidable rather than a judgement call."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-1b",
      "data-slug": "1b-the-three-composition-modes-and-what-each-needs-from-this-repo",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-1b"
      }), "1b. The three composition modes, and what each needs from this repo"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "PLATFORM_LAYERING_SPEC §1.1"
      }), " names three modes, and since R3-280 all three are real:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Mode"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "What it is"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "What it needs here"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "M1 dispatch"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "a content repo's marker resolves to this repo through the binding registry"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "immediately.run.provides: open-wiki"
            }), ", and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/App.tsx"
            }), " as the entry"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "M2 fork"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "engine + corpus in one repo under one identity (the docs wiki)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "nothing extra — this is the historical shape (§1, §4)"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "M3 library"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "a thin shell imports the engine pinned and arranges it"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["the package name, the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "exports"
            }), " map, and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                children: "viewer.manifest.json"
              })
            })]
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "The manifest is the override contract."
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "viewer.manifest.json"
      }), " declares the component\nvocabulary — name, tier, whether a shell may override it, its props, whether it is a\nsanitizing wrapper — and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "composeComponents()"
      }), " enforces it: overriding a name that is not\ndeclared, or one declared ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "overridable: false"
      }), ", throws rather than silently doing nothing.\nSilence is the accident worth engineering against; a plain ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "{...base, ...overrides}"
      }), " accepts\nevery typo, and a shell then ships an override that quietly stopped working when the engine\nrenamed something. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "Outlet"
      }), " is the standing locked case — replacing it detaches every layout\nlayer from the page it wraps, and the symptom is a blank body with no error."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "scripts/check-manifest.mjs"
      }), " runs first in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "npm run verify"
      }), " and fails on drift in either\ndirection: a component in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "GROVE_MDX"
      }), " but not the manifest, or vice versa. It brace-matches\nthe object literal over a comment- and string-blanked copy of the source, so reformatting\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "mdxComponents.ts"
      }), " cannot change the outcome — the property R3-277c asks for, and one the\nfirst draft of that script got wrong (a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "}"
      }), " inside a comment ended the scan early and the\ngate reported the whole manifest as drifted)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The manifest FORMAT is viewer-generic (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "viewer-manifest.schema.json"
      }), "): a Lodestar manifest\nwith a node/edge vocabulary validates through the same schema. Only the entries are\nper-viewer — which is also how corpus furniture (§3) becomes checkable, as ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "tier: \"corpus\""
      }), "\nentries declared by the corpus rather than by this repo."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-2",
      "data-slug": "2-what-is-engine",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-2"
      }), "2. What is engine"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Anything that renders ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "any"
      }), " corpus, and holds no opinion about what the corpus is about:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["the two render paths — compiled MDX via ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<Include>"
        }), ", and the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "interpreter"
        }), " path\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "SafeEntryBody"
        }), " → the SDK's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "parseSafeMdast"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "renderMdast"
        }), "), selected by ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "render: safe"
        }), " on\nthe home entry (wiki-wide) or a single entry;"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["routing, path helpers and link classification (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "lib/content.ts"
        }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "hrefKeyCandidates"
        }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "linkKind"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "splitFragment"
        }), "), and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<WikiLink>"
        }), "'s resolution of author-relative hrefs;"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["deep-linking (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "lib/fragment.ts"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ScrollToFragment"
        }), ") and the raw-source read cache\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "lib/sourceCache.ts"
        }), ");"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["the layout chain (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "lib/layout.ts"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "_layout.mdx"
        }), " + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<Outlet/>"
        }), ") and the shell primitives;"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["the generic content vocabulary registered in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "mdxComponents.ts"
        }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<DocList>"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<TagCloud>"
        }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<Backlinks>"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<Timeline>"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<FamilyTree>"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<DirectoryList>"
        }), ", and friends;"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "folder routing"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "lib/directory.ts"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "hooks/useDirectoryListing"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<DirectoryView>"
        }), "):\na URL naming a directory renders its ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "index.mdx"
        }), " if the corpus wrote one, else the\ngenerated listing. The route resolves ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "DirectoryList"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "through the MDX component map"
        }), "\nrather than importing it, so a fork's or (with R3-174) a corpus's replacement reaches the\nroute as well as the tag — a half-override that only reached MDX bodies would be\ninvisible to whoever installed it."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-3",
      "data-slug": "3-what-is-corpus-furniture",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-3"
      }), "3. What is corpus furniture"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Components that encode ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "one corpus's frontmatter conventions"
      }), ". They live with that corpus,\nnot here. In the docs wiki that is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "RoadmapBoard"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "RoadmapMeta"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "NextAvailable"
      }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "Dependencies"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ProjectIndex"
      }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ProjectItems"
      }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ProjectMeta"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "TopicIndex"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "StatusBadge"
      }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ItemCard"
      }), ", plus ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "data/roadmap.ts"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "lib/roadmap.ts"
      }), ", their ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: ".rm-*"
      }), " stylesheet block, the\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "<Dependencies/>"
      }), " slot in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "PageView"
      }), ", and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "EntryHeader"
      }), "'s ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "isItemMeta"
      }), " → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "<RoadmapMeta>"
      }), " hook.\nEvery one of them reads ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "status:"
      }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "project:"
      }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "prs:"
      }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "depends_on:"
      }), " — fields that mean\nsomething only to an engineering roadmap."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The measured shape of that boundary, taken 2026-08-13: the docs fork's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "GroveApp.css"
      }), " delta is\na ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "pure append"
      }), " of 221 ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: ".rm-*"
      }), " lines, and its ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "mdxComponents.ts"
      }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "EntryHeader.tsx"
      }), " deltas\nare ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "entirely"
      }), " roadmap wiring. Nothing about the engine's own rendering had diverged. That is\nwhat makes the split cheap to state and cheap to keep."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "How furniture is meant to travel, eventually."
      }), " R3-174 (frontmatter-discovered content\ncomponents, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "type: component"
      }), ", content-wins on a name clash) is the mechanism: a corpus ships\nits own components and the viewer registers them, no fork. Note the constraint that follows —\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "a content component is author JavaScript, so R3-174 is available only to a corpus rendered\non the compiled path."
      }), " The docs wiki qualifies (it left interpreter mode in R3-252). An\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "interpreter-mode"
      }), " wiki cannot have content components at all, and must use the engine's\nvocabulary or extend the engine."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-4",
      "data-slug": "4-why-this-document-exists",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-4"
      }), "4. Why this document exists"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Between 2026-07-10 and 2026-08-13 every engine change landed only in the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "docs"
      }), " fork, and\nnobody noticed. By the time it was measured, this repo had ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "no interpreter path at all"
      }), " —\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "grep -rn safe src/"
      }), " returned zero matches — while the specs described Grove as an interpreter\nand a planned dispatch feature assumed stock Grove would render foreign content\nnon-executably. It would have rendered it as ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "code"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The engine's tests had drifted the same way, and unevenly: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "fragment.ts"
      }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "sourceCache.ts"
      }), "\narrived with their tests in the same commit, but ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "lib/content.ts"
      }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "SafeEntryBody.tsx"
      }), " both\nshipped bare and were untested for three weeks, gaining coverage only when a bug forced it. If\nyou add to this engine, the test goes in the same commit as the source."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-5",
      "data-slug": "5-test-posture",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-5"
      }), "5. Test posture"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "npm run verify"
      }), " = ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "lint"
      }), " + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "build"
      }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "tsc -b"
      }), ", all three TS projects) + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "test"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/lib/safeRender.test.ts"
      }), " drives the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "real published"
      }), " SDK safe renderer — the same bytes\nthe sandbox resolves on immediately.run — and proves the non-executable property: planted\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "{fetch()}"
      }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "<script>"
      }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "import"
      }), " stay inert, unknown components collapse to their children,\nand heading ids exist for citations to land on."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/components/DirectoryList.test.tsx"
      }), " carries a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "dispatch packaging"
      }), " block. The fork and\ndispatch packagings differ in exactly one thing — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "getContentRoot()"
      }), " — and directory listings\ntouch both path spaces at once: they READ through the mount and LINK through the URL space.\nIts load-bearing assertion is that the chroot prefix reaches ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "no"
      }), " rendered href\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "expect(el.innerHTML).not.toContain('mnt')"
      }), "); that is host knowledge the viewer may read\nthrough but never publish, and the same mapping already leaked it once (R3-268). Proven\nnon-vacuous by fault injection — freezing ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "urlAnchor()"
      }), " at the fork root, and stopping\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "keyToHref"
      }), " from stripping the anchor, each fail it."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Driving the dispatch packaging locally"
      }), " (how that block was checked against the real host,\n2026-08-18): serve the corpus and the viewer as ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "two"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "immediately.run dev"
      }), " servers, seed the\nVIEWER's locator into ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "sessionStorage"
      }), " under ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ir-local-locator:<ns>/<repo>/<ref>"
      }), " (the fragment\ncan only carry one endpoint/token, and it has to be the corpus's), and re-point the binding with\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "#ir-dev-region=task.open-wiki&ir-dev-source=local/<ns>/<repo>/<ref>"
      }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ContentViewer"
      }), "'s\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "resolveViewerBinding"
      }), " honours the §6.8 ephemeral layer for ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "task.<name>"
      }), " exactly as it does for\na chrome region. Without that override, dispatch resolves to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "published"
      }), " Grove and the local\nbuild is never exercised."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Two of its cases are ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["fixture-backed here and corpus-backed in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "docs"
        })]
      }), ", deliberately. This\nrepo's sample corpus writes no ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "[[…]]"
      }), " citations and no ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "#sec-…"
      }), " deep-links, so a corpus read\nwould assert nothing — and the sweeps carry non-vacuity guards (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "checked > 0"
      }), ") that correctly\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "fail"
      }), " on an empty sweep rather than passing quietly. The fixtures make the property\ndeterministic here; the docs wiki keeps the large-corpus sweep, which is what R3-252 says that\nharness is for. Do not \"fix\" a fixture by pointing it back at the corpus, and do not delete a\nnon-vacuity guard to make a sweep green."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-6",
      "data-slug": "6-authoring-a-layout-under-the-interpreter-r3-263",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-6"
      }), "6. Authoring a layout under the interpreter (R3-263)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "_layout.mdx"
      }), " renders through the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "safe"
      }), " renderer whenever the wiki declares ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "render: safe"
      }), "\n— it used to go through ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "<Include>"
      }), " (the compiled path) regardless, which meant an\n\"interpreter\" wiki still executed author JavaScript out of its shell. Four things an author\nneeds to know, all of which fail ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "quietly"
      }), ":"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Literal attributes only."
        }), " The renderer copies literal attributes and drops expression\nones, so ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<Foo n={3}/>"
        }), " arrives with no ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "n"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Only allow-listed structural tags render as elements."
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/lib/safeIntrinsics.tsx"
        }), "\nholds the closed set (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "main"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "section"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "div"
        }), ", …) with an attribute allow-list\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "className"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "id"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "data-*"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "aria-*"
        }), ", …). A tag outside it collapses to a Fragment that\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "keeps its children"
        }), " — content survives, the wrapper and its class do not."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "import"
          }), " lines are not resolved — and they are not silently dropped either."]
        }), " The ESM\nextension is off, so no ESM node is produced and the line renders as ordinary paragraph\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "text, printed on the page"
        }), ". Layouts are import-free by design; the vocabulary arrives\nthrough the component map."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "A block tag must open on its own line."
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<main className=\"x\">text</main>"
        }), " on one line is\nconsumed by micromark as an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "HTML block"
        }), " and renders as literal angle brackets; the same\ntag opened on its own line parses as JSX. The symptom is \"my layout is visible as markup\"\nwith no error anywhere, and the fix is a line break, which nobody guesses."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Why the allow-list rather than raw tags."
      }), " The SDK's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "literalProps"
      }), " does no name filtering\nand no URL sanitizing — it copies every literal attribute verbatim onto whatever the map\nresolves. Measured against React 19: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "onclick="
      }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "onerror="
      }), " are dropped by React, and a\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "javascript:"
      }), " URL is blocked by React — but ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "style=\"…\""
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "throws"
      }), " (\"expects a mapping … not a\nstring\"), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "dangerouslySetInnerHTML=\"…\""
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "throws"
      }), ", and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "iframe srcdoc=\"<script>…\""
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "passes\nstraight through"
      }), ". The two throwing cases are worse than they look: the throw is in the\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "layout"
      }), ", so one content file takes down the shell for every page. So the barrier is the\nallow-list, and React's own defenses are a second layer rather than the only one.\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/lib/safeIntrinsics.test.tsx"
      }), " pins every one of those cases, including the raw-tag\nbehaviour that motivates the wrapper."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-7",
      "data-slug": "7-fork-delta-re-measured-after-the-r3-276a-port-2026-08-25",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-7"
      }), "7. Fork delta, re-measured after the R3-276a port (2026-08-25)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The R3-276a port (record queries + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "MetadataSource"
      }), ", grove #45) landed in both trees in\nthe same window. Measured immediately after, engine ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/"
      }), " vs the docs fork's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/"
      }), ":"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Byte-identical after the port:"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "lib/queries.ts"
        }), " + its tests, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Search.tsx"
        }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "FamilyTree.tsx"
        }), " — the shared metadata-query surfaces have zero fork divergence."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Fork-only (the furniture, unchanged in kind):"
        }), " the roadmap components\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "RoadmapBoard"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "RoadmapMeta"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "NextAvailable"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Dependencies"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ProjectIndex"
        }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ProjectItems"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ProjectMeta"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "TopicIndex"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ItemCard"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "StatusBadge"
        }), "), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "data/roadmap.ts"
        }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "lib/roadmap.ts"
        }), ", plus the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".rm-*"
        }), " css block. Every one reads ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "status:"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "project:"
        }), "/\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "prs:"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "depends_on:"
        }), " — corpus tooling, not engine."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Fork naming specialization:"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "CONTENT_DIR"
        }), " constant vs the engine's\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "contentDir()"
        }), " runtime call (the fork is single-packaging and knows its root at build\ntime); visible as ~8-line diffs in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Sidebar.tsx"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "TagCloud.tsx"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ChildPages.tsx"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Engine-ahead (NOT ported by R3-276a, pre-existing):"
        }), " the fork's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "App.tsx"
        }), " is still\nthe pre-R3-169 monolith — it never needed the dispatch gate — and it lacks the newer\nengine features (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "GroveWiki"
        }), " split, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "DirectoryList"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "DirectoryView"
        }), " folder routing,\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "SafeLayout"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "TableOfContents"
        }), "). That is drift the fork OWNS catching up on, tracked\nseparately from this boundary record; the fork renders the docs corpus on the surfaces\nit has."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The R3-276a fork/dispatch parity drill (headless Chrome on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "local.immediately.run"
      }), ", same\nthrowaway corpus rendered both ways) found nav, search, and family-tree ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "identical"
      }), "\nbetween the modes: same labels, same in-corpus hrefs, same family labels\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "Engineering · Operations · Ada Lovelace · Alan Turing · Dorothy Vaughan"
      }), "), with 83\nviewer-dev-server requests proving the dispatch render exercised the local engine build."]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/ENGINE_BOUNDARY.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJjb2RlIiwiZW0iLCJoMSIsImgyIiwibGkiLCJvbCIsInAiLCJzdHJvbmciLCJ0YWJsZSIsInRib2R5IiwidGQiLCJ0aCIsInRoZWFkIiwidHIiLCJ1bCIsIl9wcm92aWRlQ29tcG9uZW50cyIsImNvbXBvbmVudHMiLCJIZWFkaW5nQW5jaG9yIiwiX21pc3NpbmdNZHhSZWZlcmVuY2UiLCJqc3hzIiwiRnJhZ21lbnQiLCJjaGlsZHJlbiIsImlkIiwianN4IiwiTURYQ29udGVudCIsIndyYXBwZXIiLCJNRFhMYXlvdXQiLCJfYyIsImNvbXBvbmVudCIsInBsYWNlIiwiRXJyb3IiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJFTkdJTkVfQk9VTkRBUlkubWQiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgZW06IFwiZW1cIixcbiAgICBoMTogXCJoMVwiLFxuICAgIGgyOiBcImgyXCIsXG4gICAgbGk6IFwibGlcIixcbiAgICBvbDogXCJvbFwiLFxuICAgIHA6IFwicFwiLFxuICAgIHN0cm9uZzogXCJzdHJvbmdcIixcbiAgICB0YWJsZTogXCJ0YWJsZVwiLFxuICAgIHRib2R5OiBcInRib2R5XCIsXG4gICAgdGQ6IFwidGRcIixcbiAgICB0aDogXCJ0aFwiLFxuICAgIHRoZWFkOiBcInRoZWFkXCIsXG4gICAgdHI6IFwidHJcIixcbiAgICB1bDogXCJ1bFwiLFxuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfSwge0hlYWRpbmdBbmNob3J9ID0gX2NvbXBvbmVudHM7XG4gIGlmICghSGVhZGluZ0FuY2hvcikgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJIZWFkaW5nQW5jaG9yXCIsIHRydWUpO1xuICByZXR1cm4gPD48X2NvbXBvbmVudHMuaDEgaWQ9XCJ0aGUtZ3JvdmUtZW5naW5lLWJvdW5kYXJ5LXdoYXQtbGl2ZXMtaGVyZS13aGF0LWxpdmVzLWluLWEtY29ycHVzXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJ0aGUtZ3JvdmUtZW5naW5lLWJvdW5kYXJ5LXdoYXQtbGl2ZXMtaGVyZS13aGF0LWxpdmVzLWluLWEtY29ycHVzXCIgLz57XCJUaGUgR3JvdmUgZW5naW5lIGJvdW5kYXJ5IOKAlCB3aGF0IGxpdmVzIGhlcmUsIHdoYXQgbGl2ZXMgaW4gYSBjb3JwdXNcIn08L19jb21wb25lbnRzLmgxPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiU3RhdHVzOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBkZWNpc2lvbiByZWNvcmQgwrcgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJSZWNvcmRlZDpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgMjAyNi0wOC0xMyDCtyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIkl0ZW06XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFIzLTI2MlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGlzIHJlcG8gaXMgdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiY2Fub25pY2FsIEdyb3ZlIGVuZ2luZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIi4gVGhpcyBkb2N1bWVudCByZWNvcmRzIHdoeSwgd2hhdCBiZWxvbmdzIGluIGl0LFxcbmFuZCB3aGF0IGRlbGliZXJhdGVseSBkb2VzIG5vdCDigJQgc28gdGhlIGZvcmsgdGhhdCBleGlzdHMgZG93bnN0cmVhbSBpcyBhIGtub3duIHNwZWNpYWxpemF0aW9uXFxucmF0aGVyIHRoYW4gZHJpZnQgbm9ib2R5IGlzIHRyYWNraW5nLiBJdCBleGlzdHMgYmVjYXVzZSB0aGUgZHJpZnQgYWxyZWFkeSBoYXBwZW5lZCBvbmNlOiBzZWVcXG7CpzQuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInNlYy0xXCIgZGF0YS1zbHVnPVwiMS1jYW5vbmljYWwtaG9tZS10aGlzLXJlcG9cIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy0xXCIgLz57XCIxLiBDYW5vbmljYWwgaG9tZSDigJQgdGhpcyByZXBvXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuY29kZT57XCJpbW1lZGlhdGVseS1ydW4vZ3JvdmVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGlzIHRoZSBlbmdpbmUuIFRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJpbW1lZGlhdGVseS1ydW4vZG9jc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgd2lraSBjYXJyaWVzIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJmb3JrXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIG9mXFxuaXQgYXQgaXRzIG93biByZXBvIHJvb3QsIGFuZCB0aGF0IGZvcmsgaXMgYSByZWNvcmRlZCBzcGVjaWFsaXphdGlvbiwgbm90IGEgc2Vjb25kIGVuZ2luZS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIHJlYXNvbiBpcyBkaXNwYXRjaC4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiUkVQT19DT05URU5UX0RJU1BBVENIX1NQRUNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHJlc29sdmVzIGEgY29udGVudCByZXBvJ3NcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJvcGVuc1dpdGg6IHsgdGFzazogJ29wZW4td2lraScgfVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgbWFya2VyIHRocm91Z2ggdGhlIGJpbmRpbmcgcmVnaXN0cnkgdG8gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJhIEdyb3ZlIHJlcG9cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIsXFxud2hpY2ggdGhlbiByZW5kZXJzIHRoYXQgcmVwbydzIGNvbnRlbnQuIFNlbGYtZGlzcGF0Y2ggaXMgcmVmdXNlZCDigJQgdGhlIHZpZXdlciBtdXN0IGJlIGFcXG5cIn08X2NvbXBvbmVudHMuZW0+e1wiZGlmZmVyZW50IHByb2dyYW1cIn08L19jb21wb25lbnRzLmVtPntcIiB0aGFuIHRoZSBjb250ZW50IGl0IHJlbmRlcnMg4oCUIHNvIHRoZSBlbmdpbmUgaGFzIHRvIGJlIGEgcmVwbyBvZiBpdHMgb3duLlxcblRoZXJlIGlzIG5vIGFycmFuZ2VtZW50IHdoZXJlIFxcXCJ0aGUgZG9jcyB3aWtpXFxcIiBpcyB0aGUgdGhpbmcgYSBzdHJhbmdlcidzIGNvbnRlbnQgZGlzcGF0Y2hlcyB0by5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIHJlYXNvbiB0aGUgZm9yayBleGlzdHMgYW55d2F5IGlzIHRoZSBrZXJuZWw6IFwifTxfY29tcG9uZW50cy5jb2RlPntcIkFQUF9ST09UXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpcyBoYXJkLWNvZGVkIHRvIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi9hcHBcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICh0aGUgcmVwb1xcbnJvb3QpIHdpdGggbm8gc3ViZGlyZWN0b3J5IGFuY2hvcmluZyAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic2FuZGJveC9zcmMvZnNMYXlvdXQudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSwgc28gdGhlIGJhcmVcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJnaXRodWIvaW1tZWRpYXRlbHktcnVuL2RvY3MvbWFpblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgVVJMIG9ubHkgYm9vdHMgaWYgdGhlIGVuZ2luZSBzaXRzIGF0IHRoZSBcIn08X2NvbXBvbmVudHMuZW0+e1wiZG9jc1wifTwvX2NvbXBvbmVudHMuZW0+e1wiIHJlcG8gcm9vdC5cXG5UaGF0IGNvbnN0cmFpbnQgaXMgcmVhbCBhbmQgdW5yZXNvbHZlZDsgaXQgaXMgd2h5IHRoZSBmb3JrIGlzIHRvbGVyYXRlZCByYXRoZXIgdGhhbiBkZWxldGVkLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlRoZSBmb2xsb3ctdGhyb3VnaCwgbm90IHlldCBkb25lOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBvbmNlIGEgdmlld2VyIGNhbiByZW5kZXIgY29udGVudCBmcm9tIGEgbW91bnRcXG4oUjMtMTY4L1IzLTE2OSksIFwifTxfY29tcG9uZW50cy5jb2RlPntcImRvY3NcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGJlY29tZXMgYW4gb3JkaW5hcnkgY29udGVudCBjb3JwdXMgZGlzcGF0Y2hlZCB0byB0aGlzIGVuZ2luZSBhbmQgdGhlXFxuZm9yayBjYW4gZ28uIFVudGlsIHRoZW4sIGFuIGVuZ2luZSBjaGFuZ2UgbGFuZHMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJoZXJlIGZpcnN0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGFuZCBpcyBwb3J0ZWQgdG8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZG9jc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInNlYy0xYVwiIGRhdGEtc2x1Zz1cIjFhLXdoYXQtZ3JvdmUtaXMtcjMtMjgwLXJlY29yZGVkLTIwMjYtMDgtMTlcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy0xYVwiIC8+e1wiMWEuIFdoYXQgR3JvdmUgSVMgKFIzLTI4MCwgcmVjb3JkZWQgMjAyNi0wOC0xOSlcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlBhY2thZ2luZyB0aGUgZW5naW5lIGFzIGEgbGlicmFyeSBmb3JjZWQgdGhlIHF1ZXN0aW9uLCBzbyByZWNvcmQgdGhlIGFuc3dlcjogXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJHcm92ZSBpcyBhXFxuKHBsdWdpbi1leHRlbnNpYmxlKSBraXQgb2YgUmVhY3QgY29tcG9uZW50cywgcHJlYnVpbHQgbGF5b3V0cyBhbmQgdGhlbWVzIHRoYXQgdG9nZXRoZXIgbWFrZVxcbmEgd2lraSBlYXN5IHRvIGJ1aWxkIGFuZCBnb29kLWxvb2tpbmcgYnkgZGVmYXVsdCDigJQgbm90IGEgd2lraSBlbmdpbmUgaW4gdGhlIHRyYWRpdGlvbmFsXFxuc2Vuc2UuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIk1vc3Qgb2Ygd2hhdCBhIHRyYWRpdGlvbmFsIHdpa2kgZW5naW5lIG93bnMgaXMgbm90IGhlcmUsIGFuZCBzaG91bGQgbm90IGJlLiBSb3V0aW5nXFxuKFwifTxfY29tcG9uZW50cy5jb2RlPntcIlJvdXRlc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiUm91dGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzYW5kYm94UGF0aFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLCBNRFggY29tcGlsYXRpb24sIHRoZSBmcm9udG1hdHRlciBtZXRhZGF0YSBpbmRleCBhbmQgaXRzXFxuc2lkZWNhciwgbGluayBzcGFjZXMgKFwifTxfY29tcG9uZW50cy5jb2RlPntcImNvcnB1c1Jvb3RcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiJGZzOlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJJbmNsdWRlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgYW5kIGhlYWRpbmcgYW5jaG9ycyBhcmUgYWxsXFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJzYW5kYm94ICsgU0RLXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBiZWNhdXNlIHRoZXkgYXJlIGNyb3NzLWN1dHRpbmcgY29uY2VybnMgb2YgXCJ9PF9jb21wb25lbnRzLmVtPntcImV2ZXJ5XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgaW1tZWRpYXRlbHkucnVuIGFwcCxcXG5ub3Qgb2Ygd2lraXMuIFdoYXQgaXMgbGVmdCBmb3IgR3JvdmUgdG8gb3duIOKAlCBhbmQgaXQgaXMgYSByZWFsIHRoaW5nIHRvIG93biDigJQgaXMgdGhlXFxuY29tcG9uZW50IHZvY2FidWxhcnksIHRoZSBjaHJvbWUsIHRoZSBsYXlvdXQgY2hhaW4sIHRoZSB0aGVtZXMsIGFuZCB0aGUgZGVmYXVsdHMgdGhhdCBtYWtlXFxudGhlIHJlc3VsdCBsb29rIGNvbnNpZGVyZWQgd2l0aG91dCBhbnlvbmUgdHVuaW5nIGl0LlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJGdXR1cmUgc2NvcGUgc3RheXMgaW5zaWRlIHRoYXQgYm91bmRhcnkuIEF1dGhvci1mYWNpbmcgY29sbGFib3JhdGlvbiBmZWF0dXJlcyAoR29vZ2xlLURvY3NcXG5zdHlsZSBjb21tZW50IHRocmVhZHMgYmV0d2VlbiBhdXRob3JzLCBzYXkpIGJlbG9uZyBoZXJlIGJlY2F1c2UgdGhleSBhcmUgd2lraS1zaGFwZWRcXG5wcmVzZW50YXRpb24gYW5kIGludGVyYWN0aW9uLiBBbnl0aGluZyBhIHNlY29uZCB2aWV3ZXIgd291bGQgYWxzbyBuZWVkIGJlbG9uZ3Mgb25lIGxheWVyXFxuZG93biDigJQgdGhhdCBpcyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJQTEFURk9STV9MQVlFUklOR19TUEVDIMKnNS4xXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIidzIHRpZXIgdGVzdCAoXFxcIndvdWxkIExvZGVzdGFyIG5lZWQgdG8gY2hhbmdlIGl0XFxudG8gdXNlIGl0P1xcXCIpLCBhbmQgdGhpcyBmcmFtaW5nIGlzIHdoYXQgbWFrZXMgaXQgZGVjaWRhYmxlIHJhdGhlciB0aGFuIGEganVkZ2VtZW50IGNhbGwuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInNlYy0xYlwiIGRhdGEtc2x1Zz1cIjFiLXRoZS10aHJlZS1jb21wb3NpdGlvbi1tb2Rlcy1hbmQtd2hhdC1lYWNoLW5lZWRzLWZyb20tdGhpcy1yZXBvXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtMWJcIiAvPntcIjFiLiBUaGUgdGhyZWUgY29tcG9zaXRpb24gbW9kZXMsIGFuZCB3aGF0IGVhY2ggbmVlZHMgZnJvbSB0aGlzIHJlcG9cIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5jb2RlPntcIlBMQVRGT1JNX0xBWUVSSU5HX1NQRUMgwqcxLjFcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG5hbWVzIHRocmVlIG1vZGVzLCBhbmQgc2luY2UgUjMtMjgwIGFsbCB0aHJlZSBhcmUgcmVhbDpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnRhYmxlPjxfY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRoPntcIk1vZGVcIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aD57XCJXaGF0IGl0IGlzXCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGg+e1wiV2hhdCBpdCBuZWVkcyBoZXJlXCJ9PC9fY29tcG9uZW50cy50aD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGhlYWQ+PF9jb21wb25lbnRzLnRib2R5PjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnN0cm9uZz57XCJNMSBkaXNwYXRjaFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcImEgY29udGVudCByZXBvJ3MgbWFya2VyIHJlc29sdmVzIHRvIHRoaXMgcmVwbyB0aHJvdWdoIHRoZSBiaW5kaW5nIHJlZ2lzdHJ5XCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiaW1tZWRpYXRlbHkucnVuLnByb3ZpZGVzOiBvcGVuLXdpa2lcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBhbmQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL0FwcC50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFzIHRoZSBlbnRyeVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiTTIgZm9ya1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcImVuZ2luZSArIGNvcnB1cyBpbiBvbmUgcmVwbyB1bmRlciBvbmUgaWRlbnRpdHkgKHRoZSBkb2NzIHdpa2kpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wibm90aGluZyBleHRyYSDigJQgdGhpcyBpcyB0aGUgaGlzdG9yaWNhbCBzaGFwZSAowqcxLCDCpzQpXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnN0cm9uZz57XCJNMyBsaWJyYXJ5XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiYSB0aGluIHNoZWxsIGltcG9ydHMgdGhlIGVuZ2luZSBwaW5uZWQgYW5kIGFycmFuZ2VzIGl0XCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1widGhlIHBhY2thZ2UgbmFtZSwgdGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcImV4cG9ydHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG1hcCwgYW5kIFwifTxfY29tcG9uZW50cy5zdHJvbmc+PF9jb21wb25lbnRzLmNvZGU+e1widmlld2VyLm1hbmlmZXN0Lmpzb25cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGJvZHk+PC9fY29tcG9uZW50cy50YWJsZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlRoZSBtYW5pZmVzdCBpcyB0aGUgb3ZlcnJpZGUgY29udHJhY3QuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5jb2RlPntcInZpZXdlci5tYW5pZmVzdC5qc29uXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBkZWNsYXJlcyB0aGUgY29tcG9uZW50XFxudm9jYWJ1bGFyeSDigJQgbmFtZSwgdGllciwgd2hldGhlciBhIHNoZWxsIG1heSBvdmVycmlkZSBpdCwgaXRzIHByb3BzLCB3aGV0aGVyIGl0IGlzIGFcXG5zYW5pdGl6aW5nIHdyYXBwZXIg4oCUIGFuZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjb21wb3NlQ29tcG9uZW50cygpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBlbmZvcmNlcyBpdDogb3ZlcnJpZGluZyBhIG5hbWUgdGhhdCBpcyBub3RcXG5kZWNsYXJlZCwgb3Igb25lIGRlY2xhcmVkIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm92ZXJyaWRhYmxlOiBmYWxzZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIHRocm93cyByYXRoZXIgdGhhbiBzaWxlbnRseSBkb2luZyBub3RoaW5nLlxcblNpbGVuY2UgaXMgdGhlIGFjY2lkZW50IHdvcnRoIGVuZ2luZWVyaW5nIGFnYWluc3Q7IGEgcGxhaW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiey4uLmJhc2UsIC4uLm92ZXJyaWRlc31cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFjY2VwdHNcXG5ldmVyeSB0eXBvLCBhbmQgYSBzaGVsbCB0aGVuIHNoaXBzIGFuIG92ZXJyaWRlIHRoYXQgcXVpZXRseSBzdG9wcGVkIHdvcmtpbmcgd2hlbiB0aGUgZW5naW5lXFxucmVuYW1lZCBzb21ldGhpbmcuIFwifTxfY29tcG9uZW50cy5jb2RlPntcIk91dGxldFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaXMgdGhlIHN0YW5kaW5nIGxvY2tlZCBjYXNlIOKAlCByZXBsYWNpbmcgaXQgZGV0YWNoZXMgZXZlcnkgbGF5b3V0XFxubGF5ZXIgZnJvbSB0aGUgcGFnZSBpdCB3cmFwcywgYW5kIHRoZSBzeW1wdG9tIGlzIGEgYmxhbmsgYm9keSB3aXRoIG5vIGVycm9yLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuY29kZT57XCJzY3JpcHRzL2NoZWNrLW1hbmlmZXN0Lm1qc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcnVucyBmaXJzdCBpbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJucG0gcnVuIHZlcmlmeVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYW5kIGZhaWxzIG9uIGRyaWZ0IGluIGVpdGhlclxcbmRpcmVjdGlvbjogYSBjb21wb25lbnQgaW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiR1JPVkVfTURYXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBidXQgbm90IHRoZSBtYW5pZmVzdCwgb3IgdmljZSB2ZXJzYS4gSXQgYnJhY2UtbWF0Y2hlc1xcbnRoZSBvYmplY3QgbGl0ZXJhbCBvdmVyIGEgY29tbWVudC0gYW5kIHN0cmluZy1ibGFua2VkIGNvcHkgb2YgdGhlIHNvdXJjZSwgc28gcmVmb3JtYXR0aW5nXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibWR4Q29tcG9uZW50cy50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgY2Fubm90IGNoYW5nZSB0aGUgb3V0Y29tZSDigJQgdGhlIHByb3BlcnR5IFIzLTI3N2MgYXNrcyBmb3IsIGFuZCBvbmUgdGhlXFxuZmlyc3QgZHJhZnQgb2YgdGhhdCBzY3JpcHQgZ290IHdyb25nIChhIFwifTxfY29tcG9uZW50cy5jb2RlPntcIn1cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGluc2lkZSBhIGNvbW1lbnQgZW5kZWQgdGhlIHNjYW4gZWFybHkgYW5kIHRoZVxcbmdhdGUgcmVwb3J0ZWQgdGhlIHdob2xlIG1hbmlmZXN0IGFzIGRyaWZ0ZWQpLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgbWFuaWZlc3QgRk9STUFUIGlzIHZpZXdlci1nZW5lcmljIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJ2aWV3ZXItbWFuaWZlc3Quc2NoZW1hLmpzb25cIn08L19jb21wb25lbnRzLmNvZGU+e1wiKTogYSBMb2Rlc3RhciBtYW5pZmVzdFxcbndpdGggYSBub2RlL2VkZ2Ugdm9jYWJ1bGFyeSB2YWxpZGF0ZXMgdGhyb3VnaCB0aGUgc2FtZSBzY2hlbWEuIE9ubHkgdGhlIGVudHJpZXMgYXJlXFxucGVyLXZpZXdlciDigJQgd2hpY2ggaXMgYWxzbyBob3cgY29ycHVzIGZ1cm5pdHVyZSAowqczKSBiZWNvbWVzIGNoZWNrYWJsZSwgYXMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widGllcjogXFxcImNvcnB1c1xcXCJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxuZW50cmllcyBkZWNsYXJlZCBieSB0aGUgY29ycHVzIHJhdGhlciB0aGFuIGJ5IHRoaXMgcmVwby5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTJcIiBkYXRhLXNsdWc9XCIyLXdoYXQtaXMtZW5naW5lXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtMlwiIC8+e1wiMi4gV2hhdCBpcyBlbmdpbmVcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkFueXRoaW5nIHRoYXQgcmVuZGVycyBcIn08X2NvbXBvbmVudHMuZW0+e1wiYW55XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgY29ycHVzLCBhbmQgaG9sZHMgbm8gb3BpbmlvbiBhYm91dCB3aGF0IHRoZSBjb3JwdXMgaXMgYWJvdXQ6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1widGhlIHR3byByZW5kZXIgcGF0aHMg4oCUIGNvbXBpbGVkIE1EWCB2aWEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiPEluY2x1ZGU+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgYW5kIHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImludGVycHJldGVyXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHBhdGhcXG4oXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiU2FmZUVudHJ5Qm9keVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oaSIHRoZSBTREsncyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJwYXJzZVNhZmVNZGFzdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicmVuZGVyTWRhc3RcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSwgc2VsZWN0ZWQgYnkgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicmVuZGVyOiBzYWZlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBvblxcbnRoZSBob21lIGVudHJ5ICh3aWtpLXdpZGUpIG9yIGEgc2luZ2xlIGVudHJ5O1wifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcInJvdXRpbmcsIHBhdGggaGVscGVycyBhbmQgbGluayBjbGFzc2lmaWNhdGlvbiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibGliL2NvbnRlbnQudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJocmVmS2V5Q2FuZGlkYXRlc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibGlua0tpbmRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcGxpdEZyYWdtZW50XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiksIGFuZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCI8V2lraUxpbms+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIidzIHJlc29sdXRpb24gb2YgYXV0aG9yLXJlbGF0aXZlIGhyZWZzO1wifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcImRlZXAtbGlua2luZyAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibGliL2ZyYWdtZW50LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiU2Nyb2xsVG9GcmFnbWVudFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpIGFuZCB0aGUgcmF3LXNvdXJjZSByZWFkIGNhY2hlXFxuKFwifTxfY29tcG9uZW50cy5jb2RlPntcImxpYi9zb3VyY2VDYWNoZS50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpO1wifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcInRoZSBsYXlvdXQgY2hhaW4gKFwifTxfY29tcG9uZW50cy5jb2RlPntcImxpYi9sYXlvdXQudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJfbGF5b3V0Lm1keFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKyBcIn08X2NvbXBvbmVudHMuY29kZT57XCI8T3V0bGV0Lz5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSBhbmQgdGhlIHNoZWxsIHByaW1pdGl2ZXM7XCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1widGhlIGdlbmVyaWMgY29udGVudCB2b2NhYnVsYXJ5IHJlZ2lzdGVyZWQgaW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibWR4Q29tcG9uZW50cy50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjxEb2NMaXN0PlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjxUYWdDbG91ZD5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcIjxCYWNrbGlua3M+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiPFRpbWVsaW5lPlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjxGYW1pbHlUcmVlPlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjxEaXJlY3RvcnlMaXN0PlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGFuZCBmcmllbmRzO1wifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiZm9sZGVyIHJvdXRpbmdcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcImxpYi9kaXJlY3RvcnkudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJob29rcy91c2VEaXJlY3RvcnlMaXN0aW5nXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiPERpcmVjdG9yeVZpZXc+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIik6XFxuYSBVUkwgbmFtaW5nIGEgZGlyZWN0b3J5IHJlbmRlcnMgaXRzIFwifTxfY29tcG9uZW50cy5jb2RlPntcImluZGV4Lm1keFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaWYgdGhlIGNvcnB1cyB3cm90ZSBvbmUsIGVsc2UgdGhlXFxuZ2VuZXJhdGVkIGxpc3RpbmcuIFRoZSByb3V0ZSByZXNvbHZlcyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJEaXJlY3RvcnlMaXN0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInRocm91Z2ggdGhlIE1EWCBjb21wb25lbnQgbWFwXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiXFxucmF0aGVyIHRoYW4gaW1wb3J0aW5nIGl0LCBzbyBhIGZvcmsncyBvciAod2l0aCBSMy0xNzQpIGEgY29ycHVzJ3MgcmVwbGFjZW1lbnQgcmVhY2hlcyB0aGVcXG5yb3V0ZSBhcyB3ZWxsIGFzIHRoZSB0YWcg4oCUIGEgaGFsZi1vdmVycmlkZSB0aGF0IG9ubHkgcmVhY2hlZCBNRFggYm9kaWVzIHdvdWxkIGJlXFxuaW52aXNpYmxlIHRvIHdob2V2ZXIgaW5zdGFsbGVkIGl0LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtM1wiIGRhdGEtc2x1Zz1cIjMtd2hhdC1pcy1jb3JwdXMtZnVybml0dXJlXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtM1wiIC8+e1wiMy4gV2hhdCBpcyBjb3JwdXMgZnVybml0dXJlXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJDb21wb25lbnRzIHRoYXQgZW5jb2RlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wib25lIGNvcnB1cydzIGZyb250bWF0dGVyIGNvbnZlbnRpb25zXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLiBUaGV5IGxpdmUgd2l0aCB0aGF0IGNvcnB1cyxcXG5ub3QgaGVyZS4gSW4gdGhlIGRvY3Mgd2lraSB0aGF0IGlzIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlJvYWRtYXBCb2FyZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlJvYWRtYXBNZXRhXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiTmV4dEF2YWlsYWJsZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRGVwZW5kZW5jaWVzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiUHJvamVjdEluZGV4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJQcm9qZWN0SXRlbXNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcIlByb2plY3RNZXRhXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiVG9waWNJbmRleFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlN0YXR1c0JhZGdlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIixcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJJdGVtQ2FyZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIHBsdXMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZGF0YS9yb2FkbWFwLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibGliL3JvYWRtYXAudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCB0aGVpciBcIn08X2NvbXBvbmVudHMuY29kZT57XCIucm0tKlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgc3R5bGVzaGVldCBibG9jaywgdGhlXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiPERlcGVuZGVuY2llcy8+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBzbG90IGluIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlBhZ2VWaWV3XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgYW5kIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkVudHJ5SGVhZGVyXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIidzIFwifTxfY29tcG9uZW50cy5jb2RlPntcImlzSXRlbU1ldGFcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKGkiBcIn08X2NvbXBvbmVudHMuY29kZT57XCI8Um9hZG1hcE1ldGE+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBob29rLlxcbkV2ZXJ5IG9uZSBvZiB0aGVtIHJlYWRzIFwifTxfY29tcG9uZW50cy5jb2RlPntcInN0YXR1czpcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIC8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicHJvamVjdDpcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIC8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicHJzOlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgLyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJkZXBlbmRzX29uOlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIGZpZWxkcyB0aGF0IG1lYW5cXG5zb21ldGhpbmcgb25seSB0byBhbiBlbmdpbmVlcmluZyByb2FkbWFwLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgbWVhc3VyZWQgc2hhcGUgb2YgdGhhdCBib3VuZGFyeSwgdGFrZW4gMjAyNi0wOC0xMzogdGhlIGRvY3MgZm9yaydzIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkdyb3ZlQXBwLmNzc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZGVsdGEgaXNcXG5hIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicHVyZSBhcHBlbmRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgb2YgMjIxIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi5ybS0qXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBsaW5lcywgYW5kIGl0cyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJtZHhDb21wb25lbnRzLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhbmQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRW50cnlIZWFkZXIudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBkZWx0YXNcXG5hcmUgXCJ9PF9jb21wb25lbnRzLmVtPntcImVudGlyZWx5XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgcm9hZG1hcCB3aXJpbmcuIE5vdGhpbmcgYWJvdXQgdGhlIGVuZ2luZSdzIG93biByZW5kZXJpbmcgaGFkIGRpdmVyZ2VkLiBUaGF0IGlzXFxud2hhdCBtYWtlcyB0aGUgc3BsaXQgY2hlYXAgdG8gc3RhdGUgYW5kIGNoZWFwIHRvIGtlZXAuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiSG93IGZ1cm5pdHVyZSBpcyBtZWFudCB0byB0cmF2ZWwsIGV2ZW50dWFsbHkuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFIzLTE3NCAoZnJvbnRtYXR0ZXItZGlzY292ZXJlZCBjb250ZW50XFxuY29tcG9uZW50cywgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widHlwZTogY29tcG9uZW50XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgY29udGVudC13aW5zIG9uIGEgbmFtZSBjbGFzaCkgaXMgdGhlIG1lY2hhbmlzbTogYSBjb3JwdXMgc2hpcHNcXG5pdHMgb3duIGNvbXBvbmVudHMgYW5kIHRoZSB2aWV3ZXIgcmVnaXN0ZXJzIHRoZW0sIG5vIGZvcmsuIE5vdGUgdGhlIGNvbnN0cmFpbnQgdGhhdCBmb2xsb3dzIOKAlFxcblwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiYSBjb250ZW50IGNvbXBvbmVudCBpcyBhdXRob3IgSmF2YVNjcmlwdCwgc28gUjMtMTc0IGlzIGF2YWlsYWJsZSBvbmx5IHRvIGEgY29ycHVzIHJlbmRlcmVkXFxub24gdGhlIGNvbXBpbGVkIHBhdGguXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRoZSBkb2NzIHdpa2kgcXVhbGlmaWVzIChpdCBsZWZ0IGludGVycHJldGVyIG1vZGUgaW4gUjMtMjUyKS4gQW5cXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImludGVycHJldGVyLW1vZGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgd2lraSBjYW5ub3QgaGF2ZSBjb250ZW50IGNvbXBvbmVudHMgYXQgYWxsLCBhbmQgbXVzdCB1c2UgdGhlIGVuZ2luZSdzXFxudm9jYWJ1bGFyeSBvciBleHRlbmQgdGhlIGVuZ2luZS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTRcIiBkYXRhLXNsdWc9XCI0LXdoeS10aGlzLWRvY3VtZW50LWV4aXN0c1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTRcIiAvPntcIjQuIFdoeSB0aGlzIGRvY3VtZW50IGV4aXN0c1wifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiQmV0d2VlbiAyMDI2LTA3LTEwIGFuZCAyMDI2LTA4LTEzIGV2ZXJ5IGVuZ2luZSBjaGFuZ2UgbGFuZGVkIG9ubHkgaW4gdGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcImRvY3NcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGZvcmssIGFuZFxcbm5vYm9keSBub3RpY2VkLiBCeSB0aGUgdGltZSBpdCB3YXMgbWVhc3VyZWQsIHRoaXMgcmVwbyBoYWQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJubyBpbnRlcnByZXRlciBwYXRoIGF0IGFsbFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJRcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJncmVwIC1ybiBzYWZlIHNyYy9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHJldHVybmVkIHplcm8gbWF0Y2hlcyDigJQgd2hpbGUgdGhlIHNwZWNzIGRlc2NyaWJlZCBHcm92ZSBhcyBhbiBpbnRlcnByZXRlclxcbmFuZCBhIHBsYW5uZWQgZGlzcGF0Y2ggZmVhdHVyZSBhc3N1bWVkIHN0b2NrIEdyb3ZlIHdvdWxkIHJlbmRlciBmb3JlaWduIGNvbnRlbnRcXG5ub24tZXhlY3V0YWJseS4gSXQgd291bGQgaGF2ZSByZW5kZXJlZCBpdCBhcyBcIn08X2NvbXBvbmVudHMuZW0+e1wiY29kZVwifTwvX2NvbXBvbmVudHMuZW0+e1wiLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgZW5naW5lJ3MgdGVzdHMgaGFkIGRyaWZ0ZWQgdGhlIHNhbWUgd2F5LCBhbmQgdW5ldmVubHk6IFwifTxfY29tcG9uZW50cy5jb2RlPntcImZyYWdtZW50LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhbmQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic291cmNlQ2FjaGUudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxuYXJyaXZlZCB3aXRoIHRoZWlyIHRlc3RzIGluIHRoZSBzYW1lIGNvbW1pdCwgYnV0IFwifTxfY29tcG9uZW50cy5jb2RlPntcImxpYi9jb250ZW50LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhbmQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiU2FmZUVudHJ5Qm9keS50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGJvdGhcXG5zaGlwcGVkIGJhcmUgYW5kIHdlcmUgdW50ZXN0ZWQgZm9yIHRocmVlIHdlZWtzLCBnYWluaW5nIGNvdmVyYWdlIG9ubHkgd2hlbiBhIGJ1ZyBmb3JjZWQgaXQuIElmXFxueW91IGFkZCB0byB0aGlzIGVuZ2luZSwgdGhlIHRlc3QgZ29lcyBpbiB0aGUgc2FtZSBjb21taXQgYXMgdGhlIHNvdXJjZS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTVcIiBkYXRhLXNsdWc9XCI1LXRlc3QtcG9zdHVyZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTVcIiAvPntcIjUuIFRlc3QgcG9zdHVyZVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLmNvZGU+e1wibnBtIHJ1biB2ZXJpZnlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiID0gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibGludFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJidWlsZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcInRzYyAtYlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGFsbCB0aHJlZSBUUyBwcm9qZWN0cykgKyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ0ZXN0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2xpYi9zYWZlUmVuZGVyLnRlc3QudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGRyaXZlcyB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJyZWFsIHB1Ymxpc2hlZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBTREsgc2FmZSByZW5kZXJlciDigJQgdGhlIHNhbWUgYnl0ZXNcXG50aGUgc2FuZGJveCByZXNvbHZlcyBvbiBpbW1lZGlhdGVseS5ydW4g4oCUIGFuZCBwcm92ZXMgdGhlIG5vbi1leGVjdXRhYmxlIHByb3BlcnR5OiBwbGFudGVkXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wie2ZldGNoKCl9XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAvIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjxzY3JpcHQ+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAvIFwifTxfY29tcG9uZW50cy5jb2RlPntcImltcG9ydFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgc3RheSBpbmVydCwgdW5rbm93biBjb21wb25lbnRzIGNvbGxhcHNlIHRvIHRoZWlyIGNoaWxkcmVuLFxcbmFuZCBoZWFkaW5nIGlkcyBleGlzdCBmb3IgY2l0YXRpb25zIHRvIGxhbmQgb24uXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5jb2RlPntcInNyYy9jb21wb25lbnRzL0RpcmVjdG9yeUxpc3QudGVzdC50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNhcnJpZXMgYSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImRpc3BhdGNoIHBhY2thZ2luZ1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBibG9jay4gVGhlIGZvcmsgYW5kXFxuZGlzcGF0Y2ggcGFja2FnaW5ncyBkaWZmZXIgaW4gZXhhY3RseSBvbmUgdGhpbmcg4oCUIFwifTxfY29tcG9uZW50cy5jb2RlPntcImdldENvbnRlbnRSb290KClcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCBhbmQgZGlyZWN0b3J5IGxpc3RpbmdzXFxudG91Y2ggYm90aCBwYXRoIHNwYWNlcyBhdCBvbmNlOiB0aGV5IFJFQUQgdGhyb3VnaCB0aGUgbW91bnQgYW5kIExJTksgdGhyb3VnaCB0aGUgVVJMIHNwYWNlLlxcbkl0cyBsb2FkLWJlYXJpbmcgYXNzZXJ0aW9uIGlzIHRoYXQgdGhlIGNocm9vdCBwcmVmaXggcmVhY2hlcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHJlbmRlcmVkIGhyZWZcXG4oXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZXhwZWN0KGVsLmlubmVySFRNTCkubm90LnRvQ29udGFpbignbW50JylcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKTsgdGhhdCBpcyBob3N0IGtub3dsZWRnZSB0aGUgdmlld2VyIG1heSByZWFkXFxudGhyb3VnaCBidXQgbmV2ZXIgcHVibGlzaCwgYW5kIHRoZSBzYW1lIG1hcHBpbmcgYWxyZWFkeSBsZWFrZWQgaXQgb25jZSAoUjMtMjY4KS4gUHJvdmVuXFxubm9uLXZhY3VvdXMgYnkgZmF1bHQgaW5qZWN0aW9uIOKAlCBmcmVlemluZyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ1cmxBbmNob3IoKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYXQgdGhlIGZvcmsgcm9vdCwgYW5kIHN0b3BwaW5nXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wia2V5VG9IcmVmXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBmcm9tIHN0cmlwcGluZyB0aGUgYW5jaG9yLCBlYWNoIGZhaWwgaXQuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRHJpdmluZyB0aGUgZGlzcGF0Y2ggcGFja2FnaW5nIGxvY2FsbHlcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKGhvdyB0aGF0IGJsb2NrIHdhcyBjaGVja2VkIGFnYWluc3QgdGhlIHJlYWwgaG9zdCxcXG4yMDI2LTA4LTE4KTogc2VydmUgdGhlIGNvcnB1cyBhbmQgdGhlIHZpZXdlciBhcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInR3b1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJpbW1lZGlhdGVseS5ydW4gZGV2XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBzZXJ2ZXJzLCBzZWVkIHRoZVxcblZJRVdFUidzIGxvY2F0b3IgaW50byBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzZXNzaW9uU3RvcmFnZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdW5kZXIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaXItbG9jYWwtbG9jYXRvcjo8bnM+LzxyZXBvPi88cmVmPlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKHRoZSBmcmFnbWVudFxcbmNhbiBvbmx5IGNhcnJ5IG9uZSBlbmRwb2ludC90b2tlbiwgYW5kIGl0IGhhcyB0byBiZSB0aGUgY29ycHVzJ3MpLCBhbmQgcmUtcG9pbnQgdGhlIGJpbmRpbmcgd2l0aFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcIiNpci1kZXYtcmVnaW9uPXRhc2sub3Blbi13aWtpJmlyLWRldi1zb3VyY2U9bG9jYWwvPG5zPi88cmVwbz4vPHJlZj5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJDb250ZW50Vmlld2VyXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIidzXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicmVzb2x2ZVZpZXdlckJpbmRpbmdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGhvbm91cnMgdGhlIMKnNi44IGVwaGVtZXJhbCBsYXllciBmb3IgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widGFzay48bmFtZT5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGV4YWN0bHkgYXMgaXQgZG9lcyBmb3JcXG5hIGNocm9tZSByZWdpb24uIFdpdGhvdXQgdGhhdCBvdmVycmlkZSwgZGlzcGF0Y2ggcmVzb2x2ZXMgdG8gXCJ9PF9jb21wb25lbnRzLmVtPntcInB1Ymxpc2hlZFwifTwvX2NvbXBvbmVudHMuZW0+e1wiIEdyb3ZlIGFuZCB0aGUgbG9jYWxcXG5idWlsZCBpcyBuZXZlciBleGVyY2lzZWQuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlR3byBvZiBpdHMgY2FzZXMgYXJlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZml4dHVyZS1iYWNrZWQgaGVyZSBhbmQgY29ycHVzLWJhY2tlZCBpbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJkb2NzXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgZGVsaWJlcmF0ZWx5LiBUaGlzXFxucmVwbydzIHNhbXBsZSBjb3JwdXMgd3JpdGVzIG5vIFwifTxfY29tcG9uZW50cy5jb2RlPntcIltb4oCmXV1cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNpdGF0aW9ucyBhbmQgbm8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiI3NlYy3igKZcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGRlZXAtbGlua3MsIHNvIGEgY29ycHVzIHJlYWRcXG53b3VsZCBhc3NlcnQgbm90aGluZyDigJQgYW5kIHRoZSBzd2VlcHMgY2Fycnkgbm9uLXZhY3VpdHkgZ3VhcmRzIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJjaGVja2VkID4gMFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpIHRoYXQgY29ycmVjdGx5XFxuXCJ9PF9jb21wb25lbnRzLmVtPntcImZhaWxcIn08L19jb21wb25lbnRzLmVtPntcIiBvbiBhbiBlbXB0eSBzd2VlcCByYXRoZXIgdGhhbiBwYXNzaW5nIHF1aWV0bHkuIFRoZSBmaXh0dXJlcyBtYWtlIHRoZSBwcm9wZXJ0eVxcbmRldGVybWluaXN0aWMgaGVyZTsgdGhlIGRvY3Mgd2lraSBrZWVwcyB0aGUgbGFyZ2UtY29ycHVzIHN3ZWVwLCB3aGljaCBpcyB3aGF0IFIzLTI1MiBzYXlzIHRoYXRcXG5oYXJuZXNzIGlzIGZvci4gRG8gbm90IFxcXCJmaXhcXFwiIGEgZml4dHVyZSBieSBwb2ludGluZyBpdCBiYWNrIGF0IHRoZSBjb3JwdXMsIGFuZCBkbyBub3QgZGVsZXRlIGFcXG5ub24tdmFjdWl0eSBndWFyZCB0byBtYWtlIGEgc3dlZXAgZ3JlZW4uXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInNlYy02XCIgZGF0YS1zbHVnPVwiNi1hdXRob3JpbmctYS1sYXlvdXQtdW5kZXItdGhlLWludGVycHJldGVyLXIzLTI2M1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTZcIiAvPntcIjYuIEF1dGhvcmluZyBhIGxheW91dCB1bmRlciB0aGUgaW50ZXJwcmV0ZXIgKFIzLTI2MylcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5jb2RlPntcIl9sYXlvdXQubWR4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiByZW5kZXJzIHRocm91Z2ggdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wic2FmZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiByZW5kZXJlciB3aGVuZXZlciB0aGUgd2lraSBkZWNsYXJlcyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyZW5kZXI6IHNhZmVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxu4oCUIGl0IHVzZWQgdG8gZ28gdGhyb3VnaCBcIn08X2NvbXBvbmVudHMuY29kZT57XCI8SW5jbHVkZT5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiICh0aGUgY29tcGlsZWQgcGF0aCkgcmVnYXJkbGVzcywgd2hpY2ggbWVhbnQgYW5cXG5cXFwiaW50ZXJwcmV0ZXJcXFwiIHdpa2kgc3RpbGwgZXhlY3V0ZWQgYXV0aG9yIEphdmFTY3JpcHQgb3V0IG9mIGl0cyBzaGVsbC4gRm91ciB0aGluZ3MgYW4gYXV0aG9yXFxubmVlZHMgdG8ga25vdywgYWxsIG9mIHdoaWNoIGZhaWwgXCJ9PF9jb21wb25lbnRzLmVtPntcInF1aWV0bHlcIn08L19jb21wb25lbnRzLmVtPntcIjpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkxpdGVyYWwgYXR0cmlidXRlcyBvbmx5LlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGUgcmVuZGVyZXIgY29waWVzIGxpdGVyYWwgYXR0cmlidXRlcyBhbmQgZHJvcHMgZXhwcmVzc2lvblxcbm9uZXMsIHNvIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjxGb28gbj17M30vPlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYXJyaXZlcyB3aXRoIG5vIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiT25seSBhbGxvdy1saXN0ZWQgc3RydWN0dXJhbCB0YWdzIHJlbmRlciBhcyBlbGVtZW50cy5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2xpYi9zYWZlSW50cmluc2ljcy50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxuaG9sZHMgdGhlIGNsb3NlZCBzZXQgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1haW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzZWN0aW9uXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZGl2XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwg4oCmKSB3aXRoIGFuIGF0dHJpYnV0ZSBhbGxvdy1saXN0XFxuKFwifTxfY29tcG9uZW50cy5jb2RlPntcImNsYXNzTmFtZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcImlkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZGF0YS0qXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYXJpYS0qXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwg4oCmKS4gQSB0YWcgb3V0c2lkZSBpdCBjb2xsYXBzZXMgdG8gYSBGcmFnbWVudCB0aGF0XFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJrZWVwcyBpdHMgY2hpbGRyZW5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIGNvbnRlbnQgc3Vydml2ZXMsIHRoZSB3cmFwcGVyIGFuZCBpdHMgY2xhc3MgZG8gbm90LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+PF9jb21wb25lbnRzLmNvZGU+e1wiaW1wb3J0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBsaW5lcyBhcmUgbm90IHJlc29sdmVkIOKAlCBhbmQgdGhleSBhcmUgbm90IHNpbGVudGx5IGRyb3BwZWQgZWl0aGVyLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGUgRVNNXFxuZXh0ZW5zaW9uIGlzIG9mZiwgc28gbm8gRVNNIG5vZGUgaXMgcHJvZHVjZWQgYW5kIHRoZSBsaW5lIHJlbmRlcnMgYXMgb3JkaW5hcnkgcGFyYWdyYXBoXFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ0ZXh0LCBwcmludGVkIG9uIHRoZSBwYWdlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLiBMYXlvdXRzIGFyZSBpbXBvcnQtZnJlZSBieSBkZXNpZ247IHRoZSB2b2NhYnVsYXJ5IGFycml2ZXNcXG50aHJvdWdoIHRoZSBjb21wb25lbnQgbWFwLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQSBibG9jayB0YWcgbXVzdCBvcGVuIG9uIGl0cyBvd24gbGluZS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiPG1haW4gY2xhc3NOYW1lPVxcXCJ4XFxcIj50ZXh0PC9tYWluPlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgb24gb25lIGxpbmUgaXNcXG5jb25zdW1lZCBieSBtaWNyb21hcmsgYXMgYW4gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJIVE1MIGJsb2NrXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGFuZCByZW5kZXJzIGFzIGxpdGVyYWwgYW5nbGUgYnJhY2tldHM7IHRoZSBzYW1lXFxudGFnIG9wZW5lZCBvbiBpdHMgb3duIGxpbmUgcGFyc2VzIGFzIEpTWC4gVGhlIHN5bXB0b20gaXMgXFxcIm15IGxheW91dCBpcyB2aXNpYmxlIGFzIG1hcmt1cFxcXCJcXG53aXRoIG5vIGVycm9yIGFueXdoZXJlLCBhbmQgdGhlIGZpeCBpcyBhIGxpbmUgYnJlYWssIHdoaWNoIG5vYm9keSBndWVzc2VzLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIldoeSB0aGUgYWxsb3ctbGlzdCByYXRoZXIgdGhhbiByYXcgdGFncy5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhlIFNESydzIFwifTxfY29tcG9uZW50cy5jb2RlPntcImxpdGVyYWxQcm9wc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZG9lcyBubyBuYW1lIGZpbHRlcmluZ1xcbmFuZCBubyBVUkwgc2FuaXRpemluZyDigJQgaXQgY29waWVzIGV2ZXJ5IGxpdGVyYWwgYXR0cmlidXRlIHZlcmJhdGltIG9udG8gd2hhdGV2ZXIgdGhlIG1hcFxcbnJlc29sdmVzLiBNZWFzdXJlZCBhZ2FpbnN0IFJlYWN0IDE5OiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJvbmNsaWNrPVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYW5kIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm9uZXJyb3I9XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhcmUgZHJvcHBlZCBieSBSZWFjdCwgYW5kIGFcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJqYXZhc2NyaXB0OlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgVVJMIGlzIGJsb2NrZWQgYnkgUmVhY3Qg4oCUIGJ1dCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzdHlsZT1cXFwi4oCmXFxcIlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ0aHJvd3NcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKFxcXCJleHBlY3RzIGEgbWFwcGluZyDigKYgbm90IGFcXG5zdHJpbmdcXFwiKSwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZGFuZ2Vyb3VzbHlTZXRJbm5lckhUTUw9XFxcIuKAplxcXCJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1widGhyb3dzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBhbmQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaWZyYW1lIHNyY2RvYz1cXFwiPHNjcmlwdD7igKZcXFwiXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInBhc3Nlc1xcbnN0cmFpZ2h0IHRocm91Z2hcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIuIFRoZSB0d28gdGhyb3dpbmcgY2FzZXMgYXJlIHdvcnNlIHRoYW4gdGhleSBsb29rOiB0aGUgdGhyb3cgaXMgaW4gdGhlXFxuXCJ9PF9jb21wb25lbnRzLmVtPntcImxheW91dFwifTwvX2NvbXBvbmVudHMuZW0+e1wiLCBzbyBvbmUgY29udGVudCBmaWxlIHRha2VzIGRvd24gdGhlIHNoZWxsIGZvciBldmVyeSBwYWdlLiBTbyB0aGUgYmFycmllciBpcyB0aGVcXG5hbGxvdy1saXN0LCBhbmQgUmVhY3QncyBvd24gZGVmZW5zZXMgYXJlIGEgc2Vjb25kIGxheWVyIHJhdGhlciB0aGFuIHRoZSBvbmx5IG9uZS5cXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvbGliL3NhZmVJbnRyaW5zaWNzLnRlc3QudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBwaW5zIGV2ZXJ5IG9uZSBvZiB0aG9zZSBjYXNlcywgaW5jbHVkaW5nIHRoZSByYXctdGFnXFxuYmVoYXZpb3VyIHRoYXQgbW90aXZhdGVzIHRoZSB3cmFwcGVyLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtN1wiIGRhdGEtc2x1Zz1cIjctZm9yay1kZWx0YS1yZS1tZWFzdXJlZC1hZnRlci10aGUtcjMtMjc2YS1wb3J0LTIwMjYtMDgtMjVcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy03XCIgLz57XCI3LiBGb3JrIGRlbHRhLCByZS1tZWFzdXJlZCBhZnRlciB0aGUgUjMtMjc2YSBwb3J0ICgyMDI2LTA4LTI1KVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIFIzLTI3NmEgcG9ydCAocmVjb3JkIHF1ZXJpZXMgKyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJNZXRhZGF0YVNvdXJjZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGdyb3ZlICM0NSkgbGFuZGVkIGluIGJvdGggdHJlZXMgaW5cXG50aGUgc2FtZSB3aW5kb3cuIE1lYXN1cmVkIGltbWVkaWF0ZWx5IGFmdGVyLCBlbmdpbmUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdnMgdGhlIGRvY3MgZm9yaydzIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQnl0ZS1pZGVudGljYWwgYWZ0ZXIgdGhlIHBvcnQ6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5jb2RlPntcImxpYi9xdWVyaWVzLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiArIGl0cyB0ZXN0cywgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiU2VhcmNoLnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRmFtaWx5VHJlZS50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCB0aGUgc2hhcmVkIG1ldGFkYXRhLXF1ZXJ5IHN1cmZhY2VzIGhhdmUgemVybyBmb3JrIGRpdmVyZ2VuY2UuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJGb3JrLW9ubHkgKHRoZSBmdXJuaXR1cmUsIHVuY2hhbmdlZCBpbiBraW5kKTpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdGhlIHJvYWRtYXAgY29tcG9uZW50c1xcbihcIn08X2NvbXBvbmVudHMuY29kZT57XCJSb2FkbWFwQm9hcmRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJSb2FkbWFwTWV0YVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIk5leHRBdmFpbGFibGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJEZXBlbmRlbmNpZXNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJQcm9qZWN0SW5kZXhcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcIlByb2plY3RJdGVtc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlByb2plY3RNZXRhXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiVG9waWNJbmRleFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkl0ZW1DYXJkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiU3RhdHVzQmFkZ2VcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZGF0YS9yb2FkbWFwLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIixcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJsaWIvcm9hZG1hcC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIHBsdXMgdGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi5ybS0qXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjc3MgYmxvY2suIEV2ZXJ5IG9uZSByZWFkcyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzdGF0dXM6XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJwcm9qZWN0OlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicHJzOlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZGVwZW5kc19vbjpcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCBjb3JwdXMgdG9vbGluZywgbm90IGVuZ2luZS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkZvcmsgbmFtaW5nIHNwZWNpYWxpemF0aW9uOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJDT05URU5UX0RJUlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgY29uc3RhbnQgdnMgdGhlIGVuZ2luZSdzXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY29udGVudERpcigpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBydW50aW1lIGNhbGwgKHRoZSBmb3JrIGlzIHNpbmdsZS1wYWNrYWdpbmcgYW5kIGtub3dzIGl0cyByb290IGF0IGJ1aWxkXFxudGltZSk7IHZpc2libGUgYXMgfjgtbGluZSBkaWZmcyBpbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJTaWRlYmFyLnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlRhZ0Nsb3VkLnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkNoaWxkUGFnZXMudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkVuZ2luZS1haGVhZCAoTk9UIHBvcnRlZCBieSBSMy0yNzZhLCBwcmUtZXhpc3RpbmcpOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB0aGUgZm9yaydzIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkFwcC50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGlzIHN0aWxsXFxudGhlIHByZS1SMy0xNjkgbW9ub2xpdGgg4oCUIGl0IG5ldmVyIG5lZWRlZCB0aGUgZGlzcGF0Y2ggZ2F0ZSDigJQgYW5kIGl0IGxhY2tzIHRoZSBuZXdlclxcbmVuZ2luZSBmZWF0dXJlcyAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiR3JvdmVXaWtpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBzcGxpdCwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRGlyZWN0b3J5TGlzdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRGlyZWN0b3J5Vmlld1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZm9sZGVyIHJvdXRpbmcsXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiU2FmZUxheW91dFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlRhYmxlT2ZDb250ZW50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLiBUaGF0IGlzIGRyaWZ0IHRoZSBmb3JrIE9XTlMgY2F0Y2hpbmcgdXAgb24sIHRyYWNrZWRcXG5zZXBhcmF0ZWx5IGZyb20gdGhpcyBib3VuZGFyeSByZWNvcmQ7IHRoZSBmb3JrIHJlbmRlcnMgdGhlIGRvY3MgY29ycHVzIG9uIHRoZSBzdXJmYWNlc1xcbml0IGhhcy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIFIzLTI3NmEgZm9yay9kaXNwYXRjaCBwYXJpdHkgZHJpbGwgKGhlYWRsZXNzIENocm9tZSBvbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJsb2NhbC5pbW1lZGlhdGVseS5ydW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBzYW1lXFxudGhyb3dhd2F5IGNvcnB1cyByZW5kZXJlZCBib3RoIHdheXMpIGZvdW5kIG5hdiwgc2VhcmNoLCBhbmQgZmFtaWx5LXRyZWUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJpZGVudGljYWxcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCJcXG5iZXR3ZWVuIHRoZSBtb2Rlczogc2FtZSBsYWJlbHMsIHNhbWUgaW4tY29ycHVzIGhyZWZzLCBzYW1lIGZhbWlseSBsYWJlbHNcXG4oXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRW5naW5lZXJpbmcgwrcgT3BlcmF0aW9ucyDCtyBBZGEgTG92ZWxhY2UgwrcgQWxhbiBUdXJpbmcgwrcgRG9yb3RoeSBWYXVnaGFuXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiksIHdpdGggODNcXG52aWV3ZXItZGV2LXNlcnZlciByZXF1ZXN0cyBwcm92aW5nIHRoZSBkaXNwYXRjaCByZW5kZXIgZXhlcmNpc2VkIHRoZSBsb2NhbCBlbmdpbmUgYnVpbGQuXCJ9PC9fY29tcG9uZW50cy5wPjwvPjtcbn1cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE1EWENvbnRlbnQocHJvcHMgPSB7fSkge1xuICBjb25zdCB7d3JhcHBlcjogTURYTGF5b3V0fSA9IHtcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH07XG4gIHJldHVybiBNRFhMYXlvdXQgPyA8TURYTGF5b3V0IHsuLi5wcm9wc30+PF9jcmVhdGVNZHhDb250ZW50IHsuLi5wcm9wc30gLz48L01EWExheW91dD4gOiBfY3JlYXRlTWR4Q29udGVudChwcm9wcyk7XG59XG5mdW5jdGlvbiBfbWlzc2luZ01keFJlZmVyZW5jZShpZCwgY29tcG9uZW50LCBwbGFjZSkge1xuICB0aHJvdyBuZXcgRXJyb3IoXCJFeHBlY3RlZCBcIiArIChjb21wb25lbnQgPyBcImNvbXBvbmVudFwiIDogXCJvYmplY3RcIikgKyBcIiBgXCIgKyBpZCArIFwiYCB0byBiZSBkZWZpbmVkOiB5b3UgbGlrZWx5IGZvcmdvdCB0byBpbXBvcnQsIHBhc3MsIG9yIHByb3ZpZGUgaXQuXCIgKyAocGxhY2UgPyBcIlxcbkl04oCZcyByZWZlcmVuY2VkIGluIHlvdXIgY29kZSBhdCBgXCIgKyBwbGFjZSArIFwiYCBpbiBgL2FwcC9kb2NzL0VOR0lORV9CT1VOREFSWS5tZGBcIiA6IFwiXCIpKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQXdGLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUZ4RjtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU1DLFdBQVcsR0FBRztNQUNsQkMsSUFBSSxFQUFFLE1BQU07TUFDWkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsTUFBTSxFQUFFLFFBQVE7TUFDaEJDLEtBQUssRUFBRSxPQUFPO01BQ2RDLEtBQUssRUFBRSxPQUFPO01BQ2RDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEtBQUssRUFBRSxPQUFPO01BQ2RDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1IsR0FBRyxJQUFBQyw2QkFBa0IsRUFBQyxDQUFDO01BQ3ZCLEdBQUdqQixLQUFLLENBQUNrQjtJQUNYLENBQUM7SUFBRTtNQUFDQztJQUFhLENBQUMsR0FBR2xCLFdBQVc7RUFDaEMsSUFBSSxDQUFDa0IsYUFBYSxFQUFFQyxvQkFBb0IsQ0FBQyxlQUFlLEVBQUUsSUFBSSxDQUFDO0VBQy9ELG9CQUFPLElBQUF0QixXQUFBLENBQUF1QixJQUFBLEVBQUF2QixXQUFBLENBQUF3QixRQUFBO0lBQUFDLFFBQUEsZ0JBQUUsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0csRUFBRTtNQUFDb0IsRUFBRSxFQUFDLGtFQUFrRTtNQUFBRCxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQWtFLENBQUUsQ0FBQyxFQUFDLHFFQUFxRTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ08sQ0FBQztNQUFBZSxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNRLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVMsQ0FBcUIsQ0FBQyxFQUFDLHFCQUFxQixlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNRLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVcsQ0FBcUIsQ0FBQyxFQUFDLGdCQUFnQixlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNRLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQU8sQ0FBcUIsQ0FBQyxFQUFDLFNBQVM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNPLENBQUM7TUFBQWUsUUFBQSxHQUFFLG1CQUFtQixlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNRLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQXdCLENBQXFCLENBQUMsRUFBQyxvUEFBb1A7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNJLEVBQUU7TUFBQ21CLEVBQUUsRUFBQyxPQUFPO01BQUMsYUFBVSw0QkFBNEI7TUFBQUQsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLCtCQUErQjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ08sQ0FBQztNQUFBZSxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUF1QixDQUFtQixDQUFDLEVBQUMsc0JBQXNCLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQXNCLENBQW1CLENBQUMsRUFBQyxrQkFBa0IsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDUSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFNLENBQXFCLENBQUMsRUFBQyxnR0FBZ0c7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNPLENBQUM7TUFBQWUsUUFBQSxHQUFFLDBCQUEwQixlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUE0QixDQUFtQixDQUFDLEVBQUMsOEJBQThCLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQWtDLENBQW1CLENBQUMsRUFBQywwQ0FBMEMsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDUSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFjLENBQXFCLENBQUMsRUFBQyw4RkFBOEYsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRSxFQUFFO1FBQUFvQixRQUFBLEVBQUU7TUFBbUIsQ0FBaUIsQ0FBQyxFQUFDLDZLQUE2SztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ08sQ0FBQztNQUFBZSxRQUFBLEdBQUUsbURBQW1ELGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQVUsQ0FBbUIsQ0FBQyxFQUFDLG9CQUFvQixlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFNLENBQW1CLENBQUMsRUFBQyxvREFBb0QsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBeUIsQ0FBbUIsQ0FBQyxFQUFDLGtCQUFrQixlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFrQyxDQUFtQixDQUFDLEVBQUMsNENBQTRDLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0UsRUFBRTtRQUFBb0IsUUFBQSxFQUFFO01BQU0sQ0FBaUIsQ0FBQyxFQUFDLDJHQUEyRztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ08sQ0FBQztNQUFBZSxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNRLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQW1DLENBQXFCLENBQUMsRUFBQyxtRUFBbUUsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBTSxDQUFtQixDQUFDLEVBQUMseUhBQXlILGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBWSxDQUFxQixDQUFDLEVBQUMsb0JBQW9CLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQU0sQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNJLEVBQUU7TUFBQ21CLEVBQUUsRUFBQyxRQUFRO01BQUMsYUFBVSw2Q0FBNkM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFRLENBQUUsQ0FBQyxFQUFDLGlEQUFpRDtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ08sQ0FBQztNQUFBZSxRQUFBLEdBQUUsK0VBQStFLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBME0sQ0FBcUIsQ0FBQztJQUFBLENBQWUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDTyxDQUFDO01BQUFlLFFBQUEsR0FBRSx3RkFBd0YsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBUSxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFPLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQWEsQ0FBbUIsQ0FBQyxFQUFDLG9GQUFvRixlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFZLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQU0sQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBUyxDQUFtQixDQUFDLEVBQUMsaUNBQWlDLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBZSxDQUFxQixDQUFDLEVBQUMsK0NBQStDLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0UsRUFBRTtRQUFBb0IsUUFBQSxFQUFFO01BQU8sQ0FBaUIsQ0FBQyxFQUFDLCtQQUErUDtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ08sQ0FBQztNQUFBZSxRQUFBLEdBQUUsNlJBQTZSLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQTZCLENBQW1CLENBQUMsRUFBQyw0SUFBNEk7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNJLEVBQUU7TUFBQ21CLEVBQUUsRUFBQyxRQUFRO01BQUMsYUFBVSxtRUFBbUU7TUFBQUQsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFRLENBQUUsQ0FBQyxFQUFDLHFFQUFxRTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ08sQ0FBQztNQUFBZSxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUE2QixDQUFtQixDQUFDLEVBQUMsMERBQTBEO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDUyxLQUFLO01BQUFhLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2EsS0FBSztRQUFBUyxRQUFBLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ2MsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNZLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQU0sQ0FBaUIsQ0FBQyxtQkFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBWSxDQUFpQixDQUFDLG1CQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDWSxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFvQixDQUFpQixDQUFDO1FBQUEsQ0FBZ0I7TUFBQyxDQUFtQixDQUFDLG1CQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDVSxLQUFLO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ2MsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNXLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNRLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQWEsQ0FBcUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDVyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUE0RSxDQUFpQixDQUFDLG1CQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDVyxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQXFDLENBQW1CLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQWEsQ0FBbUIsQ0FBQyxFQUFDLGVBQWU7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ2MsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNXLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNRLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQVMsQ0FBcUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDVyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFnRSxDQUFpQixDQUFDLG1CQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDVyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUF1RCxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ2MsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNXLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNRLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQVksQ0FBcUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDVyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUF3RCxDQUFpQixDQUFDLG1CQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDVyxFQUFFO1lBQUFXLFFBQUEsR0FBRSx3QkFBd0IsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBUyxDQUFtQixDQUFDLEVBQUMsWUFBWSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNRLE1BQU07Y0FBQWMsUUFBQSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7Z0JBQUFxQixRQUFBLEVBQUU7Y0FBc0IsQ0FBbUI7WUFBQyxDQUFvQixDQUFDO1VBQUEsQ0FBZ0IsQ0FBQztRQUFBLENBQWdCLENBQUM7TUFBQSxDQUFtQixDQUFDO0lBQUEsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDTyxDQUFDO01BQUFlLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBd0MsQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBc0IsQ0FBbUIsQ0FBQyxFQUFDLDBJQUEwSSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFxQixDQUFtQixDQUFDLEVBQUMseUVBQXlFLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQW9CLENBQW1CLENBQUMsRUFBQywyR0FBMkcsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBeUIsQ0FBbUIsQ0FBQyxFQUFDLDRIQUE0SCxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFRLENBQW1CLENBQUMsRUFBQyxpSkFBaUo7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNPLENBQUM7TUFBQWUsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBNEIsQ0FBbUIsQ0FBQyxFQUFDLGlCQUFpQixlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFnQixDQUFtQixDQUFDLEVBQUMsMkRBQTJELGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQVcsQ0FBbUIsQ0FBQyxFQUFDLHFKQUFxSixlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFrQixDQUFtQixDQUFDLEVBQUMsbUhBQW1ILGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQUcsQ0FBbUIsQ0FBQyxFQUFDLCtGQUErRjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ08sQ0FBQztNQUFBZSxRQUFBLEdBQUUseUNBQXlDLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQTZCLENBQW1CLENBQUMsRUFBQywwTEFBMEwsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBa0IsQ0FBbUIsQ0FBQyxFQUFDLDREQUE0RDtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0ksRUFBRTtNQUFDbUIsRUFBRSxFQUFDLE9BQU87TUFBQyxhQUFVLGtCQUFrQjtNQUFBRCxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMsbUJBQW1CO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDTyxDQUFDO01BQUFlLFFBQUEsR0FBRSx3QkFBd0IsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRSxFQUFFO1FBQUFvQixRQUFBLEVBQUU7TUFBSyxDQUFpQixDQUFDLEVBQUMsK0RBQStEO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDZSxFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0ssRUFBRTtRQUFBaUIsUUFBQSxHQUFFLDBDQUEwQyxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyxZQUFZLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBYSxDQUFxQixDQUFDLEVBQUMsVUFBVSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFlLENBQW1CLENBQUMsRUFBQyxlQUFlLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQWdCLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQyxFQUFDLGlCQUFpQixlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUMsRUFBQyxvREFBb0Q7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNLLEVBQUU7UUFBQWlCLFFBQUEsR0FBRSxpREFBaUQsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBbUIsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBVSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFlLENBQW1CLENBQUMsRUFBQyxTQUFTLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQVksQ0FBbUIsQ0FBQyxFQUFDLHlDQUF5QztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0ssRUFBRTtRQUFBaUIsUUFBQSxHQUFFLGdCQUFnQixlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFpQixDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFrQixDQUFtQixDQUFDLEVBQUMsb0NBQW9DLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQW9CLENBQW1CLENBQUMsRUFBQyxJQUFJO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDSyxFQUFFO1FBQUFpQixRQUFBLEdBQUUsb0JBQW9CLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQWUsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBYSxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyw2QkFBNkI7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNLLEVBQUU7UUFBQWlCLFFBQUEsR0FBRSwrQ0FBK0MsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBa0IsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFZLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBWSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQWlCLENBQW1CLENBQUMsRUFBQyxnQkFBZ0I7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNLLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBZ0IsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBa0IsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBMkIsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBaUIsQ0FBbUIsQ0FBQyxFQUFDLDJDQUEyQyxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyw0RUFBNEUsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBZSxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNRLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQStCLENBQXFCLENBQUMsRUFBQyxtTkFBbU47TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0ksRUFBRTtNQUFDbUIsRUFBRSxFQUFDLE9BQU87TUFBQyxhQUFVLDRCQUE0QjtNQUFBRCxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMsNkJBQTZCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDTyxDQUFDO01BQUFlLFFBQUEsR0FBRSx5QkFBeUIsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDUSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFzQyxDQUFxQixDQUFDLEVBQUMsb0VBQW9FLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQWMsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBYSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFlLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQWMsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBYyxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFjLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQWEsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBWSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFhLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQVUsQ0FBbUIsQ0FBQyxFQUFDLFNBQVMsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBaUIsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLFVBQVUsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBTyxDQUFtQixDQUFDLEVBQUMsMEJBQTBCLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQWlCLENBQW1CLENBQUMsRUFBQyxXQUFXLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQVUsQ0FBbUIsQ0FBQyxFQUFDLFFBQVEsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBYSxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFZLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQWUsQ0FBbUIsQ0FBQyxFQUFDLGtDQUFrQyxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFTLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQVUsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBTSxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFhLENBQW1CLENBQUMsRUFBQyxnRUFBZ0U7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNPLENBQUM7TUFBQWUsUUFBQSxHQUFFLHlFQUF5RSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFjLENBQW1CLENBQUMsRUFBQyxlQUFlLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBYSxDQUFxQixDQUFDLEVBQUMsVUFBVSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFPLENBQW1CLENBQUMsRUFBQyxrQkFBa0IsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBa0IsQ0FBbUIsQ0FBQyxFQUFDLE9BQU8sZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBaUIsQ0FBbUIsQ0FBQyxFQUFDLGVBQWUsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRSxFQUFFO1FBQUFvQixRQUFBLEVBQUU7TUFBVSxDQUFpQixDQUFDLEVBQUMseUlBQXlJO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDTyxDQUFDO01BQUFlLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBK0MsQ0FBcUIsQ0FBQyxFQUFDLHVEQUF1RCxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFpQixDQUFtQixDQUFDLEVBQUMsbUtBQW1LLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBbUgsQ0FBcUIsQ0FBQyxFQUFDLHFFQUFxRSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNRLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQWtCLENBQXFCLENBQUMsRUFBQywwR0FBMEc7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNJLEVBQUU7TUFBQ21CLEVBQUUsRUFBQyxPQUFPO01BQUMsYUFBVSw0QkFBNEI7TUFBQUQsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLDZCQUE2QjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ08sQ0FBQztNQUFBZSxRQUFBLEdBQUUsMkVBQTJFLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQU0sQ0FBbUIsQ0FBQyxFQUFDLHlFQUF5RSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNRLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQTRCLENBQXFCLENBQUMsRUFBQyxNQUFNLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQW9CLENBQW1CLENBQUMsRUFBQyw0TUFBNE0sZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRSxFQUFFO1FBQUFvQixRQUFBLEVBQUU7TUFBTSxDQUFpQixDQUFDLEVBQUMsR0FBRztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ08sQ0FBQztNQUFBZSxRQUFBLEdBQUUsNkRBQTZELGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQWEsQ0FBbUIsQ0FBQyxFQUFDLE9BQU8sZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLHFEQUFxRCxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFnQixDQUFtQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFtQixDQUFtQixDQUFDLEVBQUMsZ0xBQWdMO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDSSxFQUFFO01BQUNtQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUsZ0JBQWdCO01BQUFELFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQyxpQkFBaUI7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNPLENBQUM7TUFBQWUsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBTSxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFPLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQVEsQ0FBbUIsQ0FBQyxFQUFDLDZCQUE2QixlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFNLENBQW1CLENBQUMsRUFBQyxHQUFHO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDTyxDQUFDO01BQUFlLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQTRCLENBQW1CLENBQUMsRUFBQyxjQUFjLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBZ0IsQ0FBcUIsQ0FBQyxFQUFDLGtJQUFrSSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFXLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQVUsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBUSxDQUFtQixDQUFDLEVBQUMsOEdBQThHO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDTyxDQUFDO01BQUFlLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQXVDLENBQW1CLENBQUMsRUFBQyxhQUFhLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBb0IsQ0FBcUIsQ0FBQyxFQUFDLDBFQUEwRSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFrQixDQUFtQixDQUFDLEVBQUMsdUxBQXVMLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBSSxDQUFxQixDQUFDLEVBQUMsbUJBQW1CLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQTJDLENBQW1CLENBQUMsRUFBQyxvTEFBb0wsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBYSxDQUFtQixDQUFDLEVBQUMsbUNBQW1DLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQVcsQ0FBbUIsQ0FBQyxFQUFDLDJDQUEyQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ08sQ0FBQztNQUFBZSxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNRLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQXdDLENBQXFCLENBQUMsRUFBQyx1R0FBdUcsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDUSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFLLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQXFCLENBQW1CLENBQUMsRUFBQyw0Q0FBNEMsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLFNBQVMsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBb0MsQ0FBbUIsQ0FBQyxFQUFDLG9IQUFvSCxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFxRSxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFlLENBQW1CLENBQUMsRUFBQyxNQUFNLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQXNCLENBQW1CLENBQUMsRUFBQyx3Q0FBd0MsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBYSxDQUFtQixDQUFDLEVBQUMsd0ZBQXdGLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0UsRUFBRTtRQUFBb0IsUUFBQSxFQUFFO01BQVcsQ0FBaUIsQ0FBQyxFQUFDLGlEQUFpRDtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ08sQ0FBQztNQUFBZSxRQUFBLEdBQUUsdUJBQXVCLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1EsTUFBTTtRQUFBYyxRQUFBLEdBQUUsMkNBQTJDLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQU0sQ0FBbUIsQ0FBQztNQUFBLENBQW9CLENBQUMsRUFBQyx1REFBdUQsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBTyxDQUFtQixDQUFDLEVBQUMsb0JBQW9CLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQVEsQ0FBbUIsQ0FBQyxFQUFDLGlHQUFpRyxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFhLENBQW1CLENBQUMsRUFBQyxvQkFBb0IsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRSxFQUFFO1FBQUFvQixRQUFBLEVBQUU7TUFBTSxDQUFpQixDQUFDLEVBQUMsMlRBQTJUO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDSSxFQUFFO01BQUNtQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUsbURBQW1EO01BQUFELFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQyxzREFBc0Q7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNPLENBQUM7TUFBQWUsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBYSxDQUFtQixDQUFDLEVBQUMsdUJBQXVCLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBTSxDQUFxQixDQUFDLEVBQUMsdUNBQXVDLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQWMsQ0FBbUIsQ0FBQyxFQUFDLDRCQUE0QixlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFXLENBQW1CLENBQUMsRUFBQyxtTEFBbUwsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRSxFQUFFO1FBQUFvQixRQUFBLEVBQUU7TUFBUyxDQUFpQixDQUFDLEVBQUMsR0FBRztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ00sRUFBRTtNQUFBZ0IsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDSyxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNRLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTBCLENBQXFCLENBQUMsRUFBQyx5RUFBeUUsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBYyxDQUFtQixDQUFDLEVBQUMsbUJBQW1CLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQUcsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNLLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBdUQsQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBNEIsQ0FBbUIsQ0FBQyxFQUFDLDBCQUEwQixlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFNLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQVMsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBSyxDQUFtQixDQUFDLEVBQUMsc0NBQXNDLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBSSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFRLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQVEsQ0FBbUIsQ0FBQyxFQUFDLHVEQUF1RCxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNRLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQW9CLENBQXFCLENBQUMsRUFBQyx3REFBd0Q7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNLLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1EsTUFBTTtVQUFBYyxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7WUFBQXFCLFFBQUEsRUFBRTtVQUFRLENBQW1CLENBQUMsRUFBQyxxRUFBcUU7UUFBQSxDQUFxQixDQUFDLEVBQUMscUdBQXFHLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBMkIsQ0FBcUIsQ0FBQyxFQUFDLHlGQUF5RjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0ssRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDUSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUF3QyxDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFtQyxDQUFtQixDQUFDLEVBQUMsK0NBQStDLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBWSxDQUFxQixDQUFDLEVBQUMsMk5BQTJOO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNPLENBQUM7TUFBQWUsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDUSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUEwQyxDQUFxQixDQUFDLEVBQUMsYUFBYSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFjLENBQW1CLENBQUMsRUFBQywwSkFBMEosZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBVSxDQUFtQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFVLENBQW1CLENBQUMsRUFBQyxnQ0FBZ0MsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBYSxDQUFtQixDQUFDLEVBQUMsaUNBQWlDLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQWEsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDUSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFRLENBQXFCLENBQUMsRUFBQyw0Q0FBNEMsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBK0IsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDUSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFRLENBQXFCLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQTZCLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBMEIsQ0FBcUIsQ0FBQyxFQUFDLDBFQUEwRSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNFLEVBQUU7UUFBQW9CLFFBQUEsRUFBRTtNQUFRLENBQWlCLENBQUMsRUFBQyx1S0FBdUssZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBaUMsQ0FBbUIsQ0FBQyxFQUFDLDhGQUE4RjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0ksRUFBRTtNQUFDbUIsRUFBRSxFQUFDLE9BQU87TUFBQyxhQUFVLDREQUE0RDtNQUFBRCxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMsZ0VBQWdFO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDTyxDQUFDO01BQUFlLFFBQUEsR0FBRSxxQ0FBcUMsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLDRGQUE0RixlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFNLENBQW1CLENBQUMsRUFBQyxzQkFBc0IsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBTSxDQUFtQixDQUFDLEVBQUMsR0FBRztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ2UsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNLLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBZ0MsQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLGdCQUFnQixlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFZLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQWdCLENBQW1CLENBQUMsRUFBQyxrRUFBa0U7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNLLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBK0MsQ0FBcUIsQ0FBQyxFQUFDLDRCQUE0QixlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBZSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBYyxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQVksQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBVSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQWlCLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQWdCLENBQW1CLENBQUMsRUFBQyxhQUFhLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQU8sQ0FBbUIsQ0FBQyxFQUFDLDhCQUE4QixlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFTLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQVUsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBTSxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyxnQ0FBZ0M7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNLLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBNkIsQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBYSxDQUFtQixDQUFDLEVBQUMsNkJBQTZCLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLDhHQUE4RyxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNLLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBcUQsQ0FBcUIsQ0FBQyxFQUFDLGNBQWMsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBUyxDQUFtQixDQUFDLEVBQUMsb0hBQW9ILGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLFVBQVUsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBZSxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFlLENBQW1CLENBQUMsRUFBQyxvQkFBb0IsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBWSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFpQixDQUFtQixDQUFDLEVBQUMseUpBQXlKO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNPLENBQUM7TUFBQWUsUUFBQSxHQUFFLDZEQUE2RCxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUF1QixDQUFtQixDQUFDLEVBQUMsa0ZBQWtGLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBVyxDQUFxQixDQUFDLEVBQUMsK0VBQStFLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQXlFLENBQW1CLENBQUMsRUFBQyxzR0FBc0c7SUFBQSxDQUFnQixDQUFDO0VBQUEsQ0FBRSxDQUFDO0FBQ2g1NUI7QUFDZSxTQUFTRyxVQUFVQSxDQUFDMUIsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFO0VBQzdDLE1BQU07SUFBQzJCLE9BQU8sRUFBRUM7RUFBUyxDQUFDLEdBQUc7SUFDM0IsR0FBRyxJQUFBWCw2QkFBa0IsRUFBQyxDQUFDO0lBQ3ZCLEdBQUdqQixLQUFLLENBQUNrQjtFQUNYLENBQUM7RUFDRCxPQUFPVSxTQUFTLGdCQUFHLElBQUE5QixXQUFBLENBQUEyQixHQUFBLEVBQUNHLFNBQVM7SUFBQSxHQUFLNUIsS0FBSztJQUFBdUIsUUFBQSxlQUFFLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUMxQixpQkFBaUI7TUFBQSxHQUFLQztJQUFLLENBQUc7RUFBQyxDQUFXLENBQUMsR0FBR0QsaUJBQWlCLENBQUNDLEtBQUssQ0FBQztBQUNsSDtBQUFDNkIsRUFBQSxHQU51QkgsVUFBVTtBQU9sQyxTQUFTTixvQkFBb0JBLENBQUNJLEVBQUUsRUFBRU0sU0FBUyxFQUFFQyxLQUFLLEVBQUU7RUFDbEQsTUFBTSxJQUFJQyxLQUFLLENBQUMsV0FBVyxJQUFJRixTQUFTLEdBQUcsV0FBVyxHQUFHLFFBQVEsQ0FBQyxHQUFHLElBQUksR0FBR04sRUFBRSxHQUFHLG9FQUFvRSxJQUFJTyxLQUFLLEdBQUcscUNBQXFDLEdBQUdBLEtBQUssR0FBRyxxQ0FBcUMsR0FBRyxFQUFFLENBQUMsQ0FBQztBQUMvUDtBQUFDLElBQUFGLEVBQUE7QUFBQUksWUFBQSxDQUFBSixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}