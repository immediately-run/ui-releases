var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      blockquote: "blockquote",
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      li: "li",
      ol: "ol",
      p: "p",
      strong: "strong",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "brief-02-shell-navigation-and-authoring-affordances",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "brief-02-shell-navigation-and-authoring-affordances"
      }), "Brief 02 — Shell, navigation, and authoring affordances"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["How a reader moves through a Grove, and how an author hands off to the host to change it.\nAssumes ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "./00-foundation.md",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "00-foundation"
        })
      }), ". Source: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "grove.md"
      }), " \"Tag-driven UI\",\n\"Authoring\", \"Two ways to use Grove\"."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "the-shell-grove-shell",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-shell-grove-shell"
      }), "The shell (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: ".grove-shell"
      }), ")"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["A CSS-grid frame whose ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "regions are filled by tagged content"
      }), ", not hard-coded (this is\nthe TiddlyWiki-style tag-driven UI, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "grove.md"
      }), "). Design the frame and each region's\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "rendering of tagged entries"
      }), " — remember the content is data, so design the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "template"
      }), ",\nthen show it populated and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "empty"
      }), " (a Grove with no ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ui/*"
      }), "-tagged entries still works —\nit falls back to title + a default index)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "data-nav=\"top\""
          })
        }), " — horizontal nav bar (blog/journal shape)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "data-nav=\"side\""
          })
        }), " — left sidebar nav (wiki/docs shape).\nBoth are CSS-selectable over the same DOM; design both."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "top-nav-grove-nav",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "top-nav-grove-nav"
      }), "Top nav (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: ".grove-nav"
      }), ")"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["Left: the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Grove app mark + site title"
        }), " (the site's own name, from config/home entry)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["Center/right: ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["menu items composed from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "ui/nav"
          }), "-tagged entries"]
        }), " — pill ghost links,\nsentence case, current one filled faintly. Overflow into a \"More\" menu past N items."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["Right cluster: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "search"
        }), " trigger (Lucide ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "search"
        }), "), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "theme toggle"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "☀"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "☾"
        }), "), and —\nwhen writable — the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "new-entry"
        }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "ask-the-agent"
        }), " affordances (below)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["Sticky on scroll, hairline bottom border, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--bg"
        }), " with slight translucency."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sidebar-grove-sidebar",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sidebar-grove-sidebar"
      }), "Sidebar (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: ".grove-sidebar"
      }), ")"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Two stacked, independently designable parts:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Namespace tree"
        }), " — the hierarchical entry namespace (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "grove.md"
        }), " \"Wiki-links\") as a\ncollapsible tree: folders + entries, current entry highlighted, breadcrumb-aware. The\nLOTR ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "dwarves/ elves/ men/houses/"
        }), " structure is the stress test — design nesting to 3–4\nlevels without getting noisy. Lucide ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "chevron"
        }), " disclosure; mono counts optional."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "ui/sidebar"
          }), "-tagged sections"]
        }), " — author-defined panels (an \"About\", a featured list,\na tag cloud) transcluded from tagged entries. Design the section header + body slot."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "footer-grove-footer",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "footer-grove-footer"
      }), "Footer (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: ".grove-footer"
      }), ")"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Composed from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ui/footer"
      }), "-tagged entries (links, colophon). Minimal, hairline top border,\nmono micro-labels. The brand's huge \"Go build.\"-style sign-off is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "immediately.run's"
      }), ", not\nGrove's — a Grove site's footer is the author's, so keep the template neutral."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "search",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "search"
      }), "Search"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Design as an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "overlay command palette"
      }), " (the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "⌘K"
      }), " idiom, but also a tap target on\nmobile): an input + live results grouped by kind (entries, tags), each result showing\ntitle + namespace breadcrumb + matched snippet. States: idle (recent / suggested),\ntyping, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "no results"
      }), " (designed empty: \"No entry matches ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "query"
      }), ".\" + create-if-writable),\nloading skeleton rows. Keyboard-navigable; visible focus. This is client-side search over\nthe in-memory index (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "grove.md"
      }), " open question 8) — keep it instant-feeling."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "authoring-affordances-editor-hands-off-the-agent-is-groves-own",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "authoring-affordances-editor-hands-off-the-agent-is-groves-own"
      }), "Authoring affordances — editor hands off, the agent is Grove's own"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Important distinction"
      }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "HANDOFF.md"
      }), " §Hard constraints, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "grove.md"
      }), " \"Authoring\"): Grove\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "delegates text editing"
      }), " to the host editor, but ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "ships its own embedded agent\nconversation"
      }), " (the primary path). So two of the three controls below are ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "hand-off\naffordances"
      }), "; the third opens ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "Grove's own"
      }), " surface (brief 06):"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Edit affordance"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".grove-edit-affordance"
        }), ") — a small Lucide ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "pencil"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "edit"
        }), " control\non the entry header, shown ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "only when the source is writable"
        }), " (re-evaluated on mount\nchanges; absent entirely for a read-only viewer). Activating it calls the host\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "requestEdit"
        }), " in Mode A / the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "edit-file"
        }), " task in Mode B) — design the control and its\nhover/active/disabled-while-opening states, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "not"
        }), " the editor that appears."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "New entry"
        }), " — a nav-cluster button (Lucide ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "plus"
        }), "). Usually this is just a phrasing of\nan agent request; the manual path hands a new MDX file to the host editor with a\nfrontmatter stub. Design the button + (optionally) a tiny inline \"name / location\" step\nthat is a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "form, not an editor"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "EDITOR_FIRST_EDITING_SPEC"
        }), " §2.2 — a few typed fields)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Ask the agent"
        }), " — the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "primary"
        }), " authoring path (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "grove.md"
        }), " \"Authoring\"), and unlike\nthe two above it is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "not"
        }), " a mere nav-cluster button: the agent is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "baked in, front and\ncenter"
        }), " as an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "always-present"
        }), " surface with a minimal non-obscuring resting affordance\n(the Safari-URL-bar-style thin bottom line / pull tab / icon — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "brief 06 owns the form\nand invites iteration"
        }), "). A nav-cluster \"Ask Grove…\" entry may ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "also"
        }), " exist, but the\npersistent presence is the point. It opens ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Grove's own embedded conversation"
        }), " (brief\n06), not the host agent (a secondary \"open in the workbench agent\" hand-off should exist),\nreads as ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Grove's own"
        }), " agent scoped to Grove's grants, and never styles itself to pass\nas the host's trusted agent pane."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: ["Show the edit/new-entry affordances ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "present (writable)"
        }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "absent (read-only)"
        }), " so\nthe writability gating is unambiguous. The edit/new-entry affordances must not look like\nthe host editor they summon; the agent entry point opens Grove's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "own"
        }), " conversation\n(brief 06), which must not look like the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "host's"
        }), " agent pane."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "mobile-chrome",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "mobile-chrome"
      }), "Mobile chrome"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Nav collapses to a top bar with the mark, a search tap target, and a menu (hamburger or\nbottom-sheet) that holds nav items + theme toggle. The sidebar namespace tree becomes a\nfull-height drawer. Authoring affordances live in a per-entry overflow menu. Bottom-sheet\noverlays for search and menus; comfy tap targets; reachable with one thumb."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "states-copy",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "states-copy"
      }), "States & copy"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Every region: populated, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "empty"
      }), " (no ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ui/*"
      }), " entries → graceful default), loading\nskeleton. Draft: the search placeholder + no-results line, the ask-the-agent label, the\nnew-entry label, and the read-only-viewer absence (nothing to draw, but note it)."]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/design-briefs/grove/briefs/02-shell-navigation-and-authoring.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiYmxvY2txdW90ZSIsImNvZGUiLCJlbSIsImgxIiwiaDIiLCJsaSIsIm9sIiwicCIsInN0cm9uZyIsInVsIiwiX3Byb3ZpZGVDb21wb25lbnRzIiwiY29tcG9uZW50cyIsIkhlYWRpbmdBbmNob3IiLCJfbWlzc2luZ01keFJlZmVyZW5jZSIsImpzeHMiLCJGcmFnbWVudCIsImNoaWxkcmVuIiwiaWQiLCJqc3giLCJocmVmIiwiTURYQ29udGVudCIsIndyYXBwZXIiLCJNRFhMYXlvdXQiLCJfYyIsImNvbXBvbmVudCIsInBsYWNlIiwiRXJyb3IiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyIwMi1zaGVsbC1uYXZpZ2F0aW9uLWFuZC1hdXRob3JpbmcubWQiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgYTogXCJhXCIsXG4gICAgYmxvY2txdW90ZTogXCJibG9ja3F1b3RlXCIsXG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgZW06IFwiZW1cIixcbiAgICBoMTogXCJoMVwiLFxuICAgIGgyOiBcImgyXCIsXG4gICAgbGk6IFwibGlcIixcbiAgICBvbDogXCJvbFwiLFxuICAgIHA6IFwicFwiLFxuICAgIHN0cm9uZzogXCJzdHJvbmdcIixcbiAgICB1bDogXCJ1bFwiLFxuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfSwge0hlYWRpbmdBbmNob3J9ID0gX2NvbXBvbmVudHM7XG4gIGlmICghSGVhZGluZ0FuY2hvcikgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJIZWFkaW5nQW5jaG9yXCIsIHRydWUpO1xuICByZXR1cm4gPD48X2NvbXBvbmVudHMuaDEgaWQ9XCJicmllZi0wMi1zaGVsbC1uYXZpZ2F0aW9uLWFuZC1hdXRob3JpbmctYWZmb3JkYW5jZXNcIj48SGVhZGluZ0FuY2hvciBpZD1cImJyaWVmLTAyLXNoZWxsLW5hdmlnYXRpb24tYW5kLWF1dGhvcmluZy1hZmZvcmRhbmNlc1wiIC8+e1wiQnJpZWYgMDIg4oCUIFNoZWxsLCBuYXZpZ2F0aW9uLCBhbmQgYXV0aG9yaW5nIGFmZm9yZGFuY2VzXCJ9PC9fY29tcG9uZW50cy5oMT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJIb3cgYSByZWFkZXIgbW92ZXMgdGhyb3VnaCBhIEdyb3ZlLCBhbmQgaG93IGFuIGF1dGhvciBoYW5kcyBvZmYgdG8gdGhlIGhvc3QgdG8gY2hhbmdlIGl0LlxcbkFzc3VtZXMgXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cIi4vMDAtZm91bmRhdGlvbi5tZFwiPjxfY29tcG9uZW50cy5jb2RlPntcIjAwLWZvdW5kYXRpb25cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5hPntcIi4gU291cmNlOiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJncm92ZS5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgXFxcIlRhZy1kcml2ZW4gVUlcXFwiLFxcblxcXCJBdXRob3JpbmdcXFwiLCBcXFwiVHdvIHdheXMgdG8gdXNlIEdyb3ZlXFxcIi5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwidGhlLXNoZWxsLWdyb3ZlLXNoZWxsXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJ0aGUtc2hlbGwtZ3JvdmUtc2hlbGxcIiAvPntcIlRoZSBzaGVsbCAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLmdyb3ZlLXNoZWxsXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIilcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkEgQ1NTLWdyaWQgZnJhbWUgd2hvc2UgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJyZWdpb25zIGFyZSBmaWxsZWQgYnkgdGFnZ2VkIGNvbnRlbnRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIsIG5vdCBoYXJkLWNvZGVkICh0aGlzIGlzXFxudGhlIFRpZGRseVdpa2ktc3R5bGUgdGFnLWRyaXZlbiBVSSwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZ3JvdmUubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKS4gRGVzaWduIHRoZSBmcmFtZSBhbmQgZWFjaCByZWdpb24nc1xcblwifTxfY29tcG9uZW50cy5lbT57XCJyZW5kZXJpbmcgb2YgdGFnZ2VkIGVudHJpZXNcIn08L19jb21wb25lbnRzLmVtPntcIiDigJQgcmVtZW1iZXIgdGhlIGNvbnRlbnQgaXMgZGF0YSwgc28gZGVzaWduIHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInRlbXBsYXRlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLFxcbnRoZW4gc2hvdyBpdCBwb3B1bGF0ZWQgYW5kIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZW1wdHlcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKGEgR3JvdmUgd2l0aCBubyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ1aS8qXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi10YWdnZWQgZW50cmllcyBzdGlsbCB3b3JrcyDigJRcXG5pdCBmYWxscyBiYWNrIHRvIHRpdGxlICsgYSBkZWZhdWx0IGluZGV4KS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPjxfY29tcG9uZW50cy5jb2RlPntcImRhdGEtbmF2PVxcXCJ0b3BcXFwiXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgaG9yaXpvbnRhbCBuYXYgYmFyIChibG9nL2pvdXJuYWwgc2hhcGUpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+PF9jb21wb25lbnRzLmNvZGU+e1wiZGF0YS1uYXY9XFxcInNpZGVcXFwiXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgbGVmdCBzaWRlYmFyIG5hdiAod2lraS9kb2NzIHNoYXBlKS5cXG5Cb3RoIGFyZSBDU1Mtc2VsZWN0YWJsZSBvdmVyIHRoZSBzYW1lIERPTTsgZGVzaWduIGJvdGguXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInRvcC1uYXYtZ3JvdmUtbmF2XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJ0b3AtbmF2LWdyb3ZlLW5hdlwiIC8+e1wiVG9wIG5hdiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLmdyb3ZlLW5hdlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIkxlZnQ6IHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIkdyb3ZlIGFwcCBtYXJrICsgc2l0ZSB0aXRsZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAodGhlIHNpdGUncyBvd24gbmFtZSwgZnJvbSBjb25maWcvaG9tZSBlbnRyeSkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiQ2VudGVyL3JpZ2h0OiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm1lbnUgaXRlbXMgY29tcG9zZWQgZnJvbSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ1aS9uYXZcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLXRhZ2dlZCBlbnRyaWVzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBwaWxsIGdob3N0IGxpbmtzLFxcbnNlbnRlbmNlIGNhc2UsIGN1cnJlbnQgb25lIGZpbGxlZCBmYWludGx5LiBPdmVyZmxvdyBpbnRvIGEgXFxcIk1vcmVcXFwiIG1lbnUgcGFzdCBOIGl0ZW1zLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIlJpZ2h0IGNsdXN0ZXI6IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wic2VhcmNoXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHRyaWdnZXIgKEx1Y2lkZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzZWFyY2hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSwgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ0aGVtZSB0b2dnbGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIuKYgFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wi4pi+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiksIGFuZCDigJRcXG53aGVuIHdyaXRhYmxlIOKAlCB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJuZXctZW50cnlcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYW5kIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiYXNrLXRoZS1hZ2VudFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBhZmZvcmRhbmNlcyAoYmVsb3cpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIlN0aWNreSBvbiBzY3JvbGwsIGhhaXJsaW5lIGJvdHRvbSBib3JkZXIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi0tYmdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHdpdGggc2xpZ2h0IHRyYW5zbHVjZW5jeS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2lkZWJhci1ncm92ZS1zaWRlYmFyXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzaWRlYmFyLWdyb3ZlLXNpZGViYXJcIiAvPntcIlNpZGViYXIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIi5ncm92ZS1zaWRlYmFyXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIilcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlR3byBzdGFja2VkLCBpbmRlcGVuZGVudGx5IGRlc2lnbmFibGUgcGFydHM6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJOYW1lc3BhY2UgdHJlZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgdGhlIGhpZXJhcmNoaWNhbCBlbnRyeSBuYW1lc3BhY2UgKFwifTxfY29tcG9uZW50cy5jb2RlPntcImdyb3ZlLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBcXFwiV2lraS1saW5rc1xcXCIpIGFzIGFcXG5jb2xsYXBzaWJsZSB0cmVlOiBmb2xkZXJzICsgZW50cmllcywgY3VycmVudCBlbnRyeSBoaWdobGlnaHRlZCwgYnJlYWRjcnVtYi1hd2FyZS4gVGhlXFxuTE9UUiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJkd2FydmVzLyBlbHZlcy8gbWVuL2hvdXNlcy9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHN0cnVjdHVyZSBpcyB0aGUgc3RyZXNzIHRlc3Qg4oCUIGRlc2lnbiBuZXN0aW5nIHRvIDPigJM0XFxubGV2ZWxzIHdpdGhvdXQgZ2V0dGluZyBub2lzeS4gTHVjaWRlIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNoZXZyb25cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGRpc2Nsb3N1cmU7IG1vbm8gY291bnRzIG9wdGlvbmFsLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+PF9jb21wb25lbnRzLmNvZGU+e1widWkvc2lkZWJhclwifTwvX2NvbXBvbmVudHMuY29kZT57XCItdGFnZ2VkIHNlY3Rpb25zXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBhdXRob3ItZGVmaW5lZCBwYW5lbHMgKGFuIFxcXCJBYm91dFxcXCIsIGEgZmVhdHVyZWQgbGlzdCxcXG5hIHRhZyBjbG91ZCkgdHJhbnNjbHVkZWQgZnJvbSB0YWdnZWQgZW50cmllcy4gRGVzaWduIHRoZSBzZWN0aW9uIGhlYWRlciArIGJvZHkgc2xvdC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMub2w+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwiZm9vdGVyLWdyb3ZlLWZvb3RlclwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiZm9vdGVyLWdyb3ZlLWZvb3RlclwiIC8+e1wiRm9vdGVyIChcIn08X2NvbXBvbmVudHMuY29kZT57XCIuZ3JvdmUtZm9vdGVyXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIilcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkNvbXBvc2VkIGZyb20gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widWkvZm9vdGVyXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi10YWdnZWQgZW50cmllcyAobGlua3MsIGNvbG9waG9uKS4gTWluaW1hbCwgaGFpcmxpbmUgdG9wIGJvcmRlcixcXG5tb25vIG1pY3JvLWxhYmVscy4gVGhlIGJyYW5kJ3MgaHVnZSBcXFwiR28gYnVpbGQuXFxcIi1zdHlsZSBzaWduLW9mZiBpcyBcIn08X2NvbXBvbmVudHMuZW0+e1wiaW1tZWRpYXRlbHkucnVuJ3NcIn08L19jb21wb25lbnRzLmVtPntcIiwgbm90XFxuR3JvdmUncyDigJQgYSBHcm92ZSBzaXRlJ3MgZm9vdGVyIGlzIHRoZSBhdXRob3Incywgc28ga2VlcCB0aGUgdGVtcGxhdGUgbmV1dHJhbC5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VhcmNoXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWFyY2hcIiAvPntcIlNlYXJjaFwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiRGVzaWduIGFzIGFuIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wib3ZlcmxheSBjb21tYW5kIHBhbGV0dGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCLijJhLXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpZGlvbSwgYnV0IGFsc28gYSB0YXAgdGFyZ2V0IG9uXFxubW9iaWxlKTogYW4gaW5wdXQgKyBsaXZlIHJlc3VsdHMgZ3JvdXBlZCBieSBraW5kIChlbnRyaWVzLCB0YWdzKSwgZWFjaCByZXN1bHQgc2hvd2luZ1xcbnRpdGxlICsgbmFtZXNwYWNlIGJyZWFkY3J1bWIgKyBtYXRjaGVkIHNuaXBwZXQuIFN0YXRlczogaWRsZSAocmVjZW50IC8gc3VnZ2VzdGVkKSxcXG50eXBpbmcsIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibm8gcmVzdWx0c1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoZGVzaWduZWQgZW1wdHk6IFxcXCJObyBlbnRyeSBtYXRjaGVzIFwifTxfY29tcG9uZW50cy5jb2RlPntcInF1ZXJ5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi5cXFwiICsgY3JlYXRlLWlmLXdyaXRhYmxlKSxcXG5sb2FkaW5nIHNrZWxldG9uIHJvd3MuIEtleWJvYXJkLW5hdmlnYWJsZTsgdmlzaWJsZSBmb2N1cy4gVGhpcyBpcyBjbGllbnQtc2lkZSBzZWFyY2ggb3ZlclxcbnRoZSBpbi1tZW1vcnkgaW5kZXggKFwifTxfY29tcG9uZW50cy5jb2RlPntcImdyb3ZlLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBvcGVuIHF1ZXN0aW9uIDgpIOKAlCBrZWVwIGl0IGluc3RhbnQtZmVlbGluZy5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwiYXV0aG9yaW5nLWFmZm9yZGFuY2VzLWVkaXRvci1oYW5kcy1vZmYtdGhlLWFnZW50LWlzLWdyb3Zlcy1vd25cIj48SGVhZGluZ0FuY2hvciBpZD1cImF1dGhvcmluZy1hZmZvcmRhbmNlcy1lZGl0b3ItaGFuZHMtb2ZmLXRoZS1hZ2VudC1pcy1ncm92ZXMtb3duXCIgLz57XCJBdXRob3JpbmcgYWZmb3JkYW5jZXMg4oCUIGVkaXRvciBoYW5kcyBvZmYsIHRoZSBhZ2VudCBpcyBHcm92ZSdzIG93blwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJJbXBvcnRhbnQgZGlzdGluY3Rpb25cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIkhBTkRPRkYubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIMKnSGFyZCBjb25zdHJhaW50cywgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZ3JvdmUubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIFxcXCJBdXRob3JpbmdcXFwiKTogR3JvdmVcXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImRlbGVnYXRlcyB0ZXh0IGVkaXRpbmdcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdG8gdGhlIGhvc3QgZWRpdG9yLCBidXQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJzaGlwcyBpdHMgb3duIGVtYmVkZGVkIGFnZW50XFxuY29udmVyc2F0aW9uXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICh0aGUgcHJpbWFyeSBwYXRoKS4gU28gdHdvIG9mIHRoZSB0aHJlZSBjb250cm9scyBiZWxvdyBhcmUgXCJ9PF9jb21wb25lbnRzLmVtPntcImhhbmQtb2ZmXFxuYWZmb3JkYW5jZXNcIn08L19jb21wb25lbnRzLmVtPntcIjsgdGhlIHRoaXJkIG9wZW5zIFwifTxfY29tcG9uZW50cy5lbT57XCJHcm92ZSdzIG93blwifTwvX2NvbXBvbmVudHMuZW0+e1wiIHN1cmZhY2UgKGJyaWVmIDA2KTpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkVkaXQgYWZmb3JkYW5jZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLmdyb3ZlLWVkaXQtYWZmb3JkYW5jZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpIOKAlCBhIHNtYWxsIEx1Y2lkZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJwZW5jaWxcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcImVkaXRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNvbnRyb2xcXG5vbiB0aGUgZW50cnkgaGVhZGVyLCBzaG93biBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm9ubHkgd2hlbiB0aGUgc291cmNlIGlzIHdyaXRhYmxlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChyZS1ldmFsdWF0ZWQgb24gbW91bnRcXG5jaGFuZ2VzOyBhYnNlbnQgZW50aXJlbHkgZm9yIGEgcmVhZC1vbmx5IHZpZXdlcikuIEFjdGl2YXRpbmcgaXQgY2FsbHMgdGhlIGhvc3RcXG4oXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicmVxdWVzdEVkaXRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGluIE1vZGUgQSAvIHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJlZGl0LWZpbGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHRhc2sgaW4gTW9kZSBCKSDigJQgZGVzaWduIHRoZSBjb250cm9sIGFuZCBpdHNcXG5ob3Zlci9hY3RpdmUvZGlzYWJsZWQtd2hpbGUtb3BlbmluZyBzdGF0ZXMsIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibm90XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHRoZSBlZGl0b3IgdGhhdCBhcHBlYXJzLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiTmV3IGVudHJ5XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBhIG5hdi1jbHVzdGVyIGJ1dHRvbiAoTHVjaWRlIFwifTxfY29tcG9uZW50cy5jb2RlPntcInBsdXNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKS4gVXN1YWxseSB0aGlzIGlzIGp1c3QgYSBwaHJhc2luZyBvZlxcbmFuIGFnZW50IHJlcXVlc3Q7IHRoZSBtYW51YWwgcGF0aCBoYW5kcyBhIG5ldyBNRFggZmlsZSB0byB0aGUgaG9zdCBlZGl0b3Igd2l0aCBhXFxuZnJvbnRtYXR0ZXIgc3R1Yi4gRGVzaWduIHRoZSBidXR0b24gKyAob3B0aW9uYWxseSkgYSB0aW55IGlubGluZSBcXFwibmFtZSAvIGxvY2F0aW9uXFxcIiBzdGVwXFxudGhhdCBpcyBhIFwifTxfY29tcG9uZW50cy5lbT57XCJmb3JtLCBub3QgYW4gZWRpdG9yXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIkVESVRPUl9GSVJTVF9FRElUSU5HX1NQRUNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIMKnMi4yIOKAlCBhIGZldyB0eXBlZCBmaWVsZHMpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQXNrIHRoZSBhZ2VudFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicHJpbWFyeVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBhdXRob3JpbmcgcGF0aCAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZ3JvdmUubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIFxcXCJBdXRob3JpbmdcXFwiKSwgYW5kIHVubGlrZVxcbnRoZSB0d28gYWJvdmUgaXQgaXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJub3RcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYSBtZXJlIG5hdi1jbHVzdGVyIGJ1dHRvbjogdGhlIGFnZW50IGlzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiYmFrZWQgaW4sIGZyb250IGFuZFxcbmNlbnRlclwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBhcyBhbiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImFsd2F5cy1wcmVzZW50XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHN1cmZhY2Ugd2l0aCBhIG1pbmltYWwgbm9uLW9ic2N1cmluZyByZXN0aW5nIGFmZm9yZGFuY2VcXG4odGhlIFNhZmFyaS1VUkwtYmFyLXN0eWxlIHRoaW4gYm90dG9tIGxpbmUgLyBwdWxsIHRhYiAvIGljb24g4oCUIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiYnJpZWYgMDYgb3ducyB0aGUgZm9ybVxcbmFuZCBpbnZpdGVzIGl0ZXJhdGlvblwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIikuIEEgbmF2LWNsdXN0ZXIgXFxcIkFzayBHcm92ZeKAplxcXCIgZW50cnkgbWF5IFwifTxfY29tcG9uZW50cy5lbT57XCJhbHNvXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgZXhpc3QsIGJ1dCB0aGVcXG5wZXJzaXN0ZW50IHByZXNlbmNlIGlzIHRoZSBwb2ludC4gSXQgb3BlbnMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJHcm92ZSdzIG93biBlbWJlZGRlZCBjb252ZXJzYXRpb25cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKGJyaWVmXFxuMDYpLCBub3QgdGhlIGhvc3QgYWdlbnQgKGEgc2Vjb25kYXJ5IFxcXCJvcGVuIGluIHRoZSB3b3JrYmVuY2ggYWdlbnRcXFwiIGhhbmQtb2ZmIHNob3VsZCBleGlzdCksXFxucmVhZHMgYXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJHcm92ZSdzIG93blwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBhZ2VudCBzY29wZWQgdG8gR3JvdmUncyBncmFudHMsIGFuZCBuZXZlciBzdHlsZXMgaXRzZWxmIHRvIHBhc3NcXG5hcyB0aGUgaG9zdCdzIHRydXN0ZWQgYWdlbnQgcGFuZS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMub2w+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiU2hvdyB0aGUgZWRpdC9uZXctZW50cnkgYWZmb3JkYW5jZXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJwcmVzZW50ICh3cml0YWJsZSlcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYW5kIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiYWJzZW50IChyZWFkLW9ubHkpXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHNvXFxudGhlIHdyaXRhYmlsaXR5IGdhdGluZyBpcyB1bmFtYmlndW91cy4gVGhlIGVkaXQvbmV3LWVudHJ5IGFmZm9yZGFuY2VzIG11c3Qgbm90IGxvb2sgbGlrZVxcbnRoZSBob3N0IGVkaXRvciB0aGV5IHN1bW1vbjsgdGhlIGFnZW50IGVudHJ5IHBvaW50IG9wZW5zIEdyb3ZlJ3MgXCJ9PF9jb21wb25lbnRzLmVtPntcIm93blwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGNvbnZlcnNhdGlvblxcbihicmllZiAwNiksIHdoaWNoIG11c3Qgbm90IGxvb2sgbGlrZSB0aGUgXCJ9PF9jb21wb25lbnRzLmVtPntcImhvc3Qnc1wifTwvX2NvbXBvbmVudHMuZW0+e1wiIGFnZW50IHBhbmUuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTwvX2NvbXBvbmVudHMuYmxvY2txdW90ZT57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJtb2JpbGUtY2hyb21lXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJtb2JpbGUtY2hyb21lXCIgLz57XCJNb2JpbGUgY2hyb21lXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJOYXYgY29sbGFwc2VzIHRvIGEgdG9wIGJhciB3aXRoIHRoZSBtYXJrLCBhIHNlYXJjaCB0YXAgdGFyZ2V0LCBhbmQgYSBtZW51IChoYW1idXJnZXIgb3JcXG5ib3R0b20tc2hlZXQpIHRoYXQgaG9sZHMgbmF2IGl0ZW1zICsgdGhlbWUgdG9nZ2xlLiBUaGUgc2lkZWJhciBuYW1lc3BhY2UgdHJlZSBiZWNvbWVzIGFcXG5mdWxsLWhlaWdodCBkcmF3ZXIuIEF1dGhvcmluZyBhZmZvcmRhbmNlcyBsaXZlIGluIGEgcGVyLWVudHJ5IG92ZXJmbG93IG1lbnUuIEJvdHRvbS1zaGVldFxcbm92ZXJsYXlzIGZvciBzZWFyY2ggYW5kIG1lbnVzOyBjb21meSB0YXAgdGFyZ2V0czsgcmVhY2hhYmxlIHdpdGggb25lIHRodW1iLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzdGF0ZXMtY29weVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic3RhdGVzLWNvcHlcIiAvPntcIlN0YXRlcyAmIGNvcHlcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkV2ZXJ5IHJlZ2lvbjogcG9wdWxhdGVkLCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImVtcHR5XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChubyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ1aS8qXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBlbnRyaWVzIOKGkiBncmFjZWZ1bCBkZWZhdWx0KSwgbG9hZGluZ1xcbnNrZWxldG9uLiBEcmFmdDogdGhlIHNlYXJjaCBwbGFjZWhvbGRlciArIG5vLXJlc3VsdHMgbGluZSwgdGhlIGFzay10aGUtYWdlbnQgbGFiZWwsIHRoZVxcbm5ldy1lbnRyeSBsYWJlbCwgYW5kIHRoZSByZWFkLW9ubHktdmlld2VyIGFic2VuY2UgKG5vdGhpbmcgdG8gZHJhdywgYnV0IG5vdGUgaXQpLlwifTwvX2NvbXBvbmVudHMucD48Lz47XG59XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNRFhDb250ZW50KHByb3BzID0ge30pIHtcbiAgY29uc3Qge3dyYXBwZXI6IE1EWExheW91dH0gPSB7XG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9O1xuICByZXR1cm4gTURYTGF5b3V0ID8gPE1EWExheW91dCB7Li4ucHJvcHN9PjxfY3JlYXRlTWR4Q29udGVudCB7Li4ucHJvcHN9IC8+PC9NRFhMYXlvdXQ+IDogX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpO1xufVxuZnVuY3Rpb24gX21pc3NpbmdNZHhSZWZlcmVuY2UoaWQsIGNvbXBvbmVudCwgcGxhY2UpIHtcbiAgdGhyb3cgbmV3IEVycm9yKFwiRXhwZWN0ZWQgXCIgKyAoY29tcG9uZW50ID8gXCJjb21wb25lbnRcIiA6IFwib2JqZWN0XCIpICsgXCIgYFwiICsgaWQgKyBcImAgdG8gYmUgZGVmaW5lZDogeW91IGxpa2VseSBmb3Jnb3QgdG8gaW1wb3J0LCBwYXNzLCBvciBwcm92aWRlIGl0LlwiICsgKHBsYWNlID8gXCJcXG5JdOKAmXMgcmVmZXJlbmNlZCBpbiB5b3VyIGNvZGUgYXQgYFwiICsgcGxhY2UgKyBcImAgaW4gYC9hcHAvZG9jcy9kZXNpZ24tYnJpZWZzL2dyb3ZlL2JyaWVmcy8wMi1zaGVsbC1uYXZpZ2F0aW9uLWFuZC1hdXRob3JpbmcubWRgXCIgOiBcIlwiKSk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUVBLElBQUFBLFlBQUEsR0FBQUMsT0FBQTtBQUF3RixJQUFBQyxXQUFBLEdBQUFELE9BQUE7QUFGeEY7QUFDQTs7QUFFQSxTQUFTRSxpQkFBaUJBLENBQUNDLEtBQUssRUFBRTtFQUNoQyxNQUFNQyxXQUFXLEdBQUc7TUFDbEJDLENBQUMsRUFBRSxHQUFHO01BQ05DLFVBQVUsRUFBRSxZQUFZO01BQ3hCQyxJQUFJLEVBQUUsTUFBTTtNQUNaQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxDQUFDLEVBQUUsR0FBRztNQUNOQyxNQUFNLEVBQUUsUUFBUTtNQUNoQkMsRUFBRSxFQUFFLElBQUk7TUFDUixHQUFHLElBQUFDLDZCQUFrQixFQUFDLENBQUM7TUFDdkIsR0FBR2IsS0FBSyxDQUFDYztJQUNYLENBQUM7SUFBRTtNQUFDQztJQUFhLENBQUMsR0FBR2QsV0FBVztFQUNoQyxJQUFJLENBQUNjLGFBQWEsRUFBRUMsb0JBQW9CLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQztFQUMvRCxvQkFBTyxJQUFBbEIsV0FBQSxDQUFBbUIsSUFBQSxFQUFBbkIsV0FBQSxDQUFBb0IsUUFBQTtJQUFBQyxRQUFBLGdCQUFFLElBQUFyQixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNLLEVBQUU7TUFBQ2MsRUFBRSxFQUFDLHFEQUFxRDtNQUFBRCxRQUFBLGdCQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQXFELENBQUUsQ0FBQyxFQUFDLHlEQUF5RDtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBUyxRQUFBLEdBQUUscUdBQXFHLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0MsQ0FBQztRQUFDb0IsSUFBSSxFQUFDLG9CQUFvQjtRQUFBSCxRQUFBLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBZSxDQUFtQjtNQUFDLENBQWUsQ0FBQyxFQUFDLFlBQVksZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRyxJQUFJO1FBQUFlLFFBQUEsRUFBRTtNQUFVLENBQW1CLENBQUMsRUFBQyxnRUFBZ0U7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNNLEVBQUU7TUFBQ2EsRUFBRSxFQUFDLHVCQUF1QjtNQUFBRCxRQUFBLGdCQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQXVCLENBQUUsQ0FBQyxFQUFDLGFBQWEsZUFBQyxJQUFBdEIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRyxJQUFJO1FBQUFlLFFBQUEsRUFBRTtNQUFjLENBQW1CLENBQUMsRUFBQyxHQUFHO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBbUIsSUFBQSxFQUFDaEIsV0FBVyxDQUFDUyxDQUFDO01BQUFTLFFBQUEsR0FBRSx5QkFBeUIsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDVSxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFzQyxDQUFxQixDQUFDLEVBQUMsaUVBQWlFLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBZSxRQUFBLEVBQUU7TUFBVSxDQUFtQixDQUFDLEVBQUMseUNBQXlDLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0ksRUFBRTtRQUFBYyxRQUFBLEVBQUU7TUFBNkIsQ0FBaUIsQ0FBQyxFQUFDLGlEQUFpRCxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNVLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQVUsQ0FBcUIsQ0FBQyxFQUFDLGdDQUFnQyxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNVLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQU8sQ0FBcUIsQ0FBQyxFQUFDLG9CQUFvQixlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNHLElBQUk7UUFBQWUsUUFBQSxFQUFFO01BQU0sQ0FBbUIsQ0FBQyxFQUFDLDJFQUEyRTtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ1csRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNPLEVBQUU7UUFBQVcsUUFBQSxnQkFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDVSxNQUFNO1VBQUFRLFFBQUEsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRyxJQUFJO1lBQUFlLFFBQUEsRUFBRTtVQUFrQixDQUFtQjtRQUFDLENBQW9CLENBQUMsRUFBQyw2Q0FBNkM7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNPLEVBQUU7UUFBQVcsUUFBQSxnQkFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDVSxNQUFNO1VBQUFRLFFBQUEsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRyxJQUFJO1lBQUFlLFFBQUEsRUFBRTtVQUFtQixDQUFtQjtRQUFDLENBQW9CLENBQUMsRUFBQyxpR0FBaUc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDYSxFQUFFLEVBQUMsbUJBQW1CO01BQUFELFFBQUEsZ0JBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBbUIsQ0FBRSxDQUFDLEVBQUMsV0FBVyxlQUFDLElBQUF0QixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNHLElBQUk7UUFBQWUsUUFBQSxFQUFFO01BQVksQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNXLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBbUIsSUFBQSxFQUFDaEIsV0FBVyxDQUFDTyxFQUFFO1FBQUFXLFFBQUEsR0FBRSxZQUFZLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBNkIsQ0FBcUIsQ0FBQyxFQUFDLGlEQUFpRDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBVyxRQUFBLEdBQUUsZ0JBQWdCLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBUSxRQUFBLEdBQUUsMkJBQTJCLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBZSxRQUFBLEVBQUU7VUFBUSxDQUFtQixDQUFDLEVBQUMsaUJBQWlCO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLDhHQUE4RztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBVyxRQUFBLEdBQUUsaUJBQWlCLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBUSxDQUFxQixDQUFDLEVBQUMsbUJBQW1CLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNVLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQWMsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFHLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBRyxDQUFtQixDQUFDLEVBQUMsZ0NBQWdDLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBVyxDQUFxQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNVLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQWUsQ0FBcUIsQ0FBQyxFQUFDLHVCQUF1QjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBVyxRQUFBLEdBQUUsNENBQTRDLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBTSxDQUFtQixDQUFDLEVBQUMsNEJBQTRCO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNNLEVBQUU7TUFBQ2EsRUFBRSxFQUFDLHVCQUF1QjtNQUFBRCxRQUFBLGdCQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQXVCLENBQUUsQ0FBQyxFQUFDLFdBQVcsZUFBQyxJQUFBdEIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRyxJQUFJO1FBQUFlLFFBQUEsRUFBRTtNQUFnQixDQUFtQixDQUFDLEVBQUMsR0FBRztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBUyxRQUFBLEVBQUU7SUFBOEMsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBbUIsSUFBQSxFQUFDaEIsV0FBVyxDQUFDUSxFQUFFO01BQUFVLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBVyxRQUFBLGdCQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNVLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQWdCLENBQXFCLENBQUMsRUFBQyx1Q0FBdUMsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQyxxSEFBcUgsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUE2QixDQUFtQixDQUFDLEVBQUMsOEZBQThGLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBUyxDQUFtQixDQUFDLEVBQUMsb0NBQW9DO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBbUIsSUFBQSxFQUFDaEIsV0FBVyxDQUFDTyxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQXJCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBUSxRQUFBLGdCQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNHLElBQUk7WUFBQWUsUUFBQSxFQUFFO1VBQVksQ0FBbUIsQ0FBQyxFQUFDLGtCQUFrQjtRQUFBLENBQXFCLENBQUMsRUFBQyxnSkFBZ0o7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDYSxFQUFFLEVBQUMscUJBQXFCO01BQUFELFFBQUEsZ0JBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBcUIsQ0FBRSxDQUFDLEVBQUMsVUFBVSxlQUFDLElBQUF0QixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNHLElBQUk7UUFBQWUsUUFBQSxFQUFFO01BQWUsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNTLENBQUM7TUFBQVMsUUFBQSxHQUFFLGdCQUFnQixlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNHLElBQUk7UUFBQWUsUUFBQSxFQUFFO01BQVcsQ0FBbUIsQ0FBQyxFQUFDLHdJQUF3SSxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNJLEVBQUU7UUFBQWMsUUFBQSxFQUFFO01BQW1CLENBQWlCLENBQUMsRUFBQyx1RkFBdUY7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNNLEVBQUU7TUFBQ2EsRUFBRSxFQUFDLFFBQVE7TUFBQUQsUUFBQSxnQkFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFRLENBQUUsQ0FBQyxFQUFDLFFBQVE7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNTLENBQUM7TUFBQVMsUUFBQSxHQUFFLGVBQWUsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDVSxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUF5QixDQUFxQixDQUFDLEVBQUMsUUFBUSxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNHLElBQUk7UUFBQWUsUUFBQSxFQUFFO01BQUksQ0FBbUIsQ0FBQyxFQUFDLHVOQUF1TixlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNVLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQVksQ0FBcUIsQ0FBQyxFQUFDLHVDQUF1QyxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNHLElBQUk7UUFBQWUsUUFBQSxFQUFFO01BQU8sQ0FBbUIsQ0FBQyxFQUFDLDhJQUE4SSxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNHLElBQUk7UUFBQWUsUUFBQSxFQUFFO01BQVUsQ0FBbUIsQ0FBQyxFQUFDLDhDQUE4QztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDYSxFQUFFLEVBQUMsZ0VBQWdFO01BQUFELFFBQUEsZ0JBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBZ0UsQ0FBRSxDQUFDLEVBQUMsb0VBQW9FO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBbUIsSUFBQSxFQUFDaEIsV0FBVyxDQUFDUyxDQUFDO01BQUFTLFFBQUEsZ0JBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1UsTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBdUIsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRyxJQUFJO1FBQUFlLFFBQUEsRUFBRTtNQUFZLENBQW1CLENBQUMsRUFBQyxzQkFBc0IsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRyxJQUFJO1FBQUFlLFFBQUEsRUFBRTtNQUFVLENBQW1CLENBQUMsRUFBQywwQkFBMEIsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDVSxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUF3QixDQUFxQixDQUFDLEVBQUMsMkJBQTJCLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1UsTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBNEMsQ0FBcUIsQ0FBQyxFQUFDLDhEQUE4RCxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNJLEVBQUU7UUFBQWMsUUFBQSxFQUFFO01BQXVCLENBQWlCLENBQUMsRUFBQyxvQkFBb0IsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDSSxFQUFFO1FBQUFjLFFBQUEsRUFBRTtNQUFhLENBQWlCLENBQUMsRUFBQyxzQkFBc0I7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNRLEVBQUU7TUFBQVUsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBbUIsSUFBQSxFQUFDaEIsV0FBVyxDQUFDTyxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBaUIsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUF3QixDQUFtQixDQUFDLEVBQUMscUJBQXFCLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNHLElBQUk7VUFBQWUsUUFBQSxFQUFFO1FBQU0sQ0FBbUIsQ0FBQyxFQUFDLHVDQUF1QyxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNVLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQWtDLENBQXFCLENBQUMsRUFBQyw0R0FBNEcsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyxtQkFBbUIsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyw2RkFBNkYsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDVSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFLLENBQXFCLENBQUMsRUFBQywyQkFBMkI7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNPLEVBQUU7UUFBQVcsUUFBQSxnQkFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDVSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFXLENBQXFCLENBQUMsRUFBQyxrQ0FBa0MsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFNLENBQW1CLENBQUMsRUFBQyxnT0FBZ08sZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDSSxFQUFFO1VBQUFjLFFBQUEsRUFBRTtRQUFxQixDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNHLElBQUk7VUFBQWUsUUFBQSxFQUFFO1FBQTJCLENBQW1CLENBQUMsRUFBQyw4QkFBOEI7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNPLEVBQUU7UUFBQVcsUUFBQSxnQkFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDVSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFlLENBQXFCLENBQUMsRUFBQyxTQUFTLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBUyxDQUFxQixDQUFDLEVBQUMsbUJBQW1CLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBVSxDQUFtQixDQUFDLEVBQUMsbURBQW1ELGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBSyxDQUFxQixDQUFDLEVBQUMsMkNBQTJDLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBNkIsQ0FBcUIsQ0FBQyxFQUFDLFNBQVMsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDVSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFnQixDQUFxQixDQUFDLEVBQUMsMkhBQTJILGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBK0MsQ0FBcUIsQ0FBQyxFQUFDLDRDQUE0QyxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNJLEVBQUU7VUFBQWMsUUFBQSxFQUFFO1FBQU0sQ0FBaUIsQ0FBQyxFQUFDLDhEQUE4RCxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNVLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQW1DLENBQXFCLENBQUMsRUFBQyxrSEFBa0gsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDVSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFhLENBQXFCLENBQUMsRUFBQyxxR0FBcUc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ0UsVUFBVTtNQUFBZ0IsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBbUIsSUFBQSxFQUFDaEIsV0FBVyxDQUFDUyxDQUFDO1FBQUFTLFFBQUEsR0FBRSxzQ0FBc0MsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDVSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFvQixDQUFxQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNVLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQW9CLENBQXFCLENBQUMsRUFBQyxrS0FBa0ssZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDSSxFQUFFO1VBQUFjLFFBQUEsRUFBRTtRQUFLLENBQWlCLENBQUMsRUFBQywwREFBMEQsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDSSxFQUFFO1VBQUFjLFFBQUEsRUFBRTtRQUFRLENBQWlCLENBQUMsRUFBQyxjQUFjO01BQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUF5QixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNNLEVBQUU7TUFBQ2EsRUFBRSxFQUFDLGVBQWU7TUFBQUQsUUFBQSxnQkFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFlLENBQUUsQ0FBQyxFQUFDLGVBQWU7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNTLENBQUM7TUFBQVMsUUFBQSxFQUFFO0lBQTBWLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDYSxFQUFFLEVBQUMsYUFBYTtNQUFBRCxRQUFBLGdCQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQWEsQ0FBRSxDQUFDLEVBQUMsZUFBZTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBUyxRQUFBLEdBQUUsMkJBQTJCLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1UsTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBTyxDQUFxQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNHLElBQUk7UUFBQWUsUUFBQSxFQUFFO01BQU0sQ0FBbUIsQ0FBQyxFQUFDLG1OQUFtTjtJQUFBLENBQWdCLENBQUM7RUFBQSxDQUFFLENBQUM7QUFDbjFWO0FBQ2UsU0FBU0ksVUFBVUEsQ0FBQ3ZCLEtBQUssR0FBRyxDQUFDLENBQUMsRUFBRTtFQUM3QyxNQUFNO0lBQUN3QixPQUFPLEVBQUVDO0VBQVMsQ0FBQyxHQUFHO0lBQzNCLEdBQUcsSUFBQVosNkJBQWtCLEVBQUMsQ0FBQztJQUN2QixHQUFHYixLQUFLLENBQUNjO0VBQ1gsQ0FBQztFQUNELE9BQU9XLFNBQVMsZ0JBQUcsSUFBQTNCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ0ksU0FBUztJQUFBLEdBQUt6QixLQUFLO0lBQUFtQixRQUFBLGVBQUUsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3RCLGlCQUFpQjtNQUFBLEdBQUtDO0lBQUssQ0FBRztFQUFDLENBQVcsQ0FBQyxHQUFHRCxpQkFBaUIsQ0FBQ0MsS0FBSyxDQUFDO0FBQ2xIO0FBQUMwQixFQUFBLEdBTnVCSCxVQUFVO0FBT2xDLFNBQVNQLG9CQUFvQkEsQ0FBQ0ksRUFBRSxFQUFFTyxTQUFTLEVBQUVDLEtBQUssRUFBRTtFQUNsRCxNQUFNLElBQUlDLEtBQUssQ0FBQyxXQUFXLElBQUlGLFNBQVMsR0FBRyxXQUFXLEdBQUcsUUFBUSxDQUFDLEdBQUcsSUFBSSxHQUFHUCxFQUFFLEdBQUcsb0VBQW9FLElBQUlRLEtBQUssR0FBRyxxQ0FBcUMsR0FBR0EsS0FBSyxHQUFHLGtGQUFrRixHQUFHLEVBQUUsQ0FBQyxDQUFDO0FBQzVTO0FBQUMsSUFBQUYsRUFBQTtBQUFBSSxZQUFBLENBQUFKLEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}