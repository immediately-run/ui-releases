var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      blockquote: "blockquote",
      code: "code",
      del: "del",
      em: "em",
      h1: "h1",
      h2: "h2",
      hr: "hr",
      li: "li",
      ol: "ol",
      p: "p",
      strong: "strong",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "grove-the-agent-authoring-loop",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "grove-the-agent-authoring-loop"
      }), "Grove — the agent authoring loop"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Status:"
      }), " product definition (proposal) · ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Updated:"
      }), " 2026-06-26\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Author:"
      }), " drafted for ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "mailto:peter@peterneumark.com",
        children: "peter@peterneumark.com"
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Companion to:"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "./grove.md",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "grove.md"
        })
      }), " and\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "./grove-interactive-content.md",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "grove-interactive-content.md"
        })
      }), " — read those first.\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Platform source of truth:"
      }), " the immediately-run ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "docs"
      }), " repo,\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "specs/AGENT_AUTHORING_ARCHITECTURE.md"
      }), " (the cross-app architecture; this doc is the\nGrove-specific application of it)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "why-this-document-exists",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "why-this-document-exists"
      }), "Why this document exists"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "grove-interactive-content.md"
      }), " settles ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "where authority lives"
      }), ": Grove holds no standing\nhigh-stakes authority, and the agent — because it needs ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "llm:chat"
      }), " — runs as a separate,\nhost-brokered ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "mini-app"
      }), ", not ambient in Grove's tree. This document settles the part that\nleft open: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "how that agent actually authors the wiki and closes the loop on what it wrote"
      }), " —\nthe principal it runs under, the interface it uses to change content, what it observes, and how\nits edits reconcile with a human editing at the same time."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The one-line thesis: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "the agent proposes; Grove applies."
      }), " The agent never holds write access\nto the wiki. It emits semantic patches; Grove — which owns the wiki schema and contract —\nvalidates them, merges them against concurrent edits, and writes."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "the-self-authoring-agent-principal",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-self-authoring-agent-principal"
      }), "The self-authoring agent principal"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "The agent mini-app runs under a tight principal whose ceiling is exactly:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "chat()"
        }), " — the LLM slot (the host injects the user's key; Grove/the agent never sees it)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "diagnostics:read"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "(subject: this Grove)"
        }), " — MDX compile/transpile errors + captured console."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "render:read"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "(subject)"
        }), " — an on-demand rendered-DOM / a11y snapshot, to verify a result."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ipc → Grove"
        }), " — propose patches; receive \"current entry / selection\" context deltas."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "and nothing else"
        }), " — no ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "net:fetch"
        }), ", no secrets, no foreign mounts, no cross-repo reach,\nand ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "no document write"
        }), "."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["It has its ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "own appKey"
      }), " (distinct from Grove), which keeps its grants isolated from Grove's\nframe (and sidesteps the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "SPEC_AUDIT_REPORT.md"
      }), " SH-1 grant-bleed defect). Because\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "diagnostics:read"
      }), " and a write port are above the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "stage"
      }), " ceiling Grove runs under, the agent\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "must"
      }), " be a separate, higher-principal slot — the platform forces the externalization, and that\nis what makes the agent survive Grove re-rendering itself."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The signature always-present ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "\"Ask Grove…\" line stays in Grove's own DOM"
      }), " (brief 06), but it\nholds no loop and no grants: it only ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "forwards the prompt over IPC"
      }), " to the agent mini-app.\nThe conversation, the loop, and the authority live in the mini-app; the line is a styled\nforwarder, so a re-render of the wiki never loses the conversation."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "the-interface-semantic-patches-not-file-writes",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-interface-semantic-patches-not-file-writes"
      }), "The interface: semantic patches, not file writes"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.em, {
          children: ["(Superseded 2026-06-27 by ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "AGENT_AUTHORING_ARCHITECTURE.md"
          }), " §3/§7. The semantic-patch interface\nis ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "dropped"
          }), ": the workbench agent writes Grove's filesystem directly (an ordinary\nediting-session write), and Grove does not validate/apply patches. The motivation below — the\nagent needs no write authority because Grove is the gatekeeper — is replaced by: the agent has\nthe workbench's existing tree-write authority, and the security backstop is the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "gate"
          }), " (commit\nfor git; for a non-git space, a local pre-publish diff review + LWW publish with\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "detect-after-clobber"
          }), " via ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "RemoteOverwriteEmitter"
          }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "not"
          }), " a preventing CAS, FirestoreFS has\nno etag), not a Grove validator. Grove's contract (taxonomy, link integrity, frontmatter schema)\nbecomes ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "feedback"
          }), " via ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "diagnostics:read"
          }), " + a Layer-3 drift flag, not a pre-write reject.\nConflict is file-level (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "buffer.ts"
          }), " block-on-dirty + a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "content-comparison token"
          }), " — git blob\nSHA / Firestore ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "!sameData"
          }), "), not a Grove-run conflict chain.)"]
        })
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
        children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
          children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
            children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
              children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
                children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
                  children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
                    children: "7ad89b3 (docs(agent-authoring): fix stale CAS terminology in reconciliation notes (D2))\nThe agent speaks Grove's schema over the IPC edge, in two verbs:"
                  }), "\n"]
                }), "\n"]
              }), "\n"]
            }), "\n"]
          }), "\n"]
        }), "\n"]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "patch(target, fieldOps)"
        }), " for a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "wiki entry"
        }), " (an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".mdx"
        }), " file: typed frontmatter + MDX body).\nExamples: ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.em, {
          children: ["add tag ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "draft"
          }), " to entry E"]
        }), "; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "set the body of E to …"
        }), "; ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.em, {
          children: ["create entry ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "{ slug, title, tags, body }"
          })]
        }), "; ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.em, {
          children: ["rewrite the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "[[link]]"
          }), " in E from X to Y"]
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "putAsset(path, bytes)"
        }), " for an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "opaque"
        }), " unit (an image) — whole-file replace."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Grove receives a patch and, before writing, runs it through its own gate: validate against the\ncontract (Layer 0 conventions, the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "GROVE.md"
      }), " taxonomy, frontmatter schema), check link\nintegrity, then apply through the conflict chain (below). This is the principled \"proxy through\nthe app\" — Grove adds real policy (schema + contract + conflict handling), so the hop earns its\nplace, and the agent needs no write authority at all."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "What Grove writes through."
      }), " In the common case Grove's content lives in a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "separate"
      }), "\nfilesystem (a space / a content repo), and Grove writes it via an ordinary ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "rw mount grant"
      }), " —\ncollaborator-gated, read-only for untrusted viewers, revocable; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "not"
      }), " a standing app\ncapability. Only in the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "fused single-repo"
      }), " Grove (content stored in Grove's own app repo) is\nthe write the standing ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "exposesWorkingTree:'rw'"
      }), " region property — opt-in, and the configuration\nwhere GitHub's branch/PR/merge becomes the durable conflict layer (a real reason a\nheavily-customized Grove chooses it)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "observe-context-closing-the-loop",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "observe-context-closing-the-loop"
      }), "Observe + context: closing the loop"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Context — re-derived, never read from Grove's memory."
      }), " The agent builds context the same way\na fresh agent session does: it reads the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "manifest"
      }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: ".grove/manifest.json"
      }), "), the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "authored\ncontract"
      }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "GROVE.md"
      }), "), and the entries themselves; and it receives ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "live deltas"
      }), " — the\ncurrent entry, the text selection — over the IPC edge. The context contract ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "is"
      }), " the agent\ncontract Grove already defines (Layers 0–2)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Observe — what it sees after a write."
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Diagnostics"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "diagnostics:read"
        }), "): if a patch produces invalid MDX, the compile error is\ndelivered to the agent so it can self-correct. Covers compile failures and runtime ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "console"
        }), "\nthrows."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Render snapshot"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "render:read"
        }), ", on demand): \"did the entry render the way I intended,\"\nfor the visual/semantic check diagnostics can't give."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "The loop:"
      }), " read context → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "chat()"
      }), " → emit ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "patch"
      }), " → Grove validates + merges + writes → host\nre-reads/recompiles (last-good Grove keeps rendering if a candidate fails) → diagnostics (± a\nrender snapshot) come back → broken means the error is in the next prompt; good means Grove\nre-renders and re-emits context. ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["Landing is a separate, gated ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "contribute"
        }), " step"]
      }), " — the user\nreviews the diff before agent-authored bytes become durable."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "conflicts-the-agent-is-just-another-writer",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "conflicts-the-agent-is-just-another-writer"
      }), "Conflicts: the agent is just another writer"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Scope is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "light async collaboration"
      }), " (a few writers, mostly different entries, occasional\ncollision) — not real-time multi-cursor. Agent patches, a human editing in the platform editor,\nand a remote collaborator all become writes to the content mount, surfaced to everyone by\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "onFsChange"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "File-per-entry partitions most conflict away."
        }), " Two writers on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "different"
        }), " entries never\nconflict. The domain shrinks to the same entry, concurrently."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Within an entry, merge by field."
        }), " Frontmatter is a typed map (per-key merge — disjoint keys\nauto-merge); the body is text (3-way). A human retitling while the agent retags the same entry\nis disjoint and merges cleanly; only a true same-field overlap blocks."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Chained resolvers, most-specific to most-general:"
        }), " Grove's contract-aware resolver\n(taxonomy, link integrity) → MDX/Markdown structural merge → generic text → terminal. The\nterminal is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "GitHub branch/PR"
        }), " when content is a git repo, or last-write / a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "user-initiated"
        }), "\nagent-diff for a non-git space."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Backstops:"
        }), " semantic staleness (a patch correct as bytes but wrong because the entry's\nmeaning changed under it) is caught by ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["human review at ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "contribute"
          })]
        }), "; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "undo is\nper-author-scoped"
        }), " (your edits and your agent's, not a collaborator's)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "what-changes-in-grove-from-today",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "what-changes-in-grove-from-today"
      }), "What changes in Grove (from today)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "GroveAgent.tsx"
      }), " today runs ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "chat()"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "text-only, ambient in Grove's tree"
      }), ", and hands writes off\nto the platform editor via ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "requestEdit"
      }), ". The target architecture:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.em, {
          children: ["(Corrected 2026-06-27 per ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "AGENT_AUTHORING_ARCHITECTURE.md"
          }), " §3/§7 — steps 1–3 below are\nsuperseded. The agent is the platform ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "workbench agent"
          }), " (editing-session principal), not a\nGrove self-authoring mini-app; it ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "writes Grove's filesystem directly"
          }), ", so there is no patch\ninterface and no Grove-run conflict chain. Grove becomes a read-only renderer; its contract\nsurfaces as ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "diagnostics:read"
          }), " + a Layer-3 drift flag (feedback), and conflict is file-level\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "buffer.ts"
          }), " block-on-dirty + a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "content-comparison token"
          }), ", detect-after-clobber on non-git via\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "RemoteOverwriteEmitter"
          }), " — not a preventing CAS) reconciled at the gate, not inside Grove.)"]
        })
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.del, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "Externalize the agent"
          }), " into a mini-app under the self-authoring principal"]
        }), " → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "use the\nplatform workbench agent"
        }), " (own appKey, editing-session principal). Keep the in-DOM \"Ask\nGrove…\" line as a grant-less forwarder of the prompt to the workbench agent."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.del, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "Replace the text-only loop with the patch interface"
          })
        }), " → the workbench agent ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "writes\nGrove's filesystem directly"
        }), "; Grove does not validate/apply patches."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.del, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "Apply through a conflict chain"
          }), " inside Grove"]
        }), " → conflict is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "file-level at the working\ntree / the gate"
        }), " (not a Grove-run resolver chain in V1)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Wire observation"
        }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "diagnostics:read"
        }), " (+ optional ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "render:read"
        }), "), context re-derived from\nthe manifest/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "GROVE.md"
        }), "/entries plus IPC nav deltas."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Consider the FS-1/FS-2 split"
        }), " — content in a separate mount by default (no standing write\ncapability for Grove), with the fused single-repo as the opt-in, GitHub-conflict-resolved\nconfiguration for a heavily-customized Grove."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "None of this requires Grove to run with elevated privilege, and none of it is a privileged\nagent daemon: the trusted core stays the host, the agent stays confined, and Grove's\ncustomization stays in unprivileged code."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "open-questions-grove-specific-platform-level-ones-live-in-the-docs-repo-note",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "open-questions-grove-specific-platform-level-ones-live-in-the-docs-repo-note"
      }), "Open questions (Grove-specific; platform-level ones live in the docs-repo note)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Patch vocabulary"
        }), " — the concrete ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "fieldOps"
        }), " for entries (tags, frontmatter keys, body\nranges, link rewrites) and how Grove registers its resolver + schema with the host."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Fused-case write scoping"
        }), " — when content is in Grove's own repo, whether patch application\nis chroot'd to the content subtree so document patches cannot reach engine source."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Contract validation timing"
        }), " — validate a patch ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "before"
        }), " writing (reject) vs. write then\nflag drift (the Layer-3 validator), and how rejections surface back to the agent."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Always-present line ↔ mini-app placement"
        }), " — keeping the brief-06 resting/expanded feel when\nthe loop's surface is a host-composited region."]
      }), "\n"]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/product-defs/grove-agent-authoring.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiYmxvY2txdW90ZSIsImNvZGUiLCJkZWwiLCJlbSIsImgxIiwiaDIiLCJociIsImxpIiwib2wiLCJwIiwic3Ryb25nIiwidWwiLCJfcHJvdmlkZUNvbXBvbmVudHMiLCJjb21wb25lbnRzIiwiSGVhZGluZ0FuY2hvciIsIl9taXNzaW5nTWR4UmVmZXJlbmNlIiwianN4cyIsIkZyYWdtZW50IiwiY2hpbGRyZW4iLCJpZCIsImpzeCIsImhyZWYiLCJNRFhDb250ZW50Iiwid3JhcHBlciIsIk1EWExheW91dCIsIl9jIiwiY29tcG9uZW50IiwicGxhY2UiLCJFcnJvciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbImdyb3ZlLWFnZW50LWF1dGhvcmluZy5tZCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKkBqc3hSdW50aW1lIGF1dG9tYXRpYyovXG4vKkBqc3hJbXBvcnRTb3VyY2UgcmVhY3QqL1xuaW1wb3J0IHt1c2VNRFhDb21wb25lbnRzIGFzIF9wcm92aWRlQ29tcG9uZW50c30gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrL01EWFByb3ZpZGVyXCI7XG5mdW5jdGlvbiBfY3JlYXRlTWR4Q29udGVudChwcm9wcykge1xuICBjb25zdCBfY29tcG9uZW50cyA9IHtcbiAgICBhOiBcImFcIixcbiAgICBibG9ja3F1b3RlOiBcImJsb2NrcXVvdGVcIixcbiAgICBjb2RlOiBcImNvZGVcIixcbiAgICBkZWw6IFwiZGVsXCIsXG4gICAgZW06IFwiZW1cIixcbiAgICBoMTogXCJoMVwiLFxuICAgIGgyOiBcImgyXCIsXG4gICAgaHI6IFwiaHJcIixcbiAgICBsaTogXCJsaVwiLFxuICAgIG9sOiBcIm9sXCIsXG4gICAgcDogXCJwXCIsXG4gICAgc3Ryb25nOiBcInN0cm9uZ1wiLFxuICAgIHVsOiBcInVsXCIsXG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9LCB7SGVhZGluZ0FuY2hvcn0gPSBfY29tcG9uZW50cztcbiAgaWYgKCFIZWFkaW5nQW5jaG9yKSBfbWlzc2luZ01keFJlZmVyZW5jZShcIkhlYWRpbmdBbmNob3JcIiwgdHJ1ZSk7XG4gIHJldHVybiA8PjxfY29tcG9uZW50cy5oMSBpZD1cImdyb3ZlLXRoZS1hZ2VudC1hdXRob3JpbmctbG9vcFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiZ3JvdmUtdGhlLWFnZW50LWF1dGhvcmluZy1sb29wXCIgLz57XCJHcm92ZSDigJQgdGhlIGFnZW50IGF1dGhvcmluZyBsb29wXCJ9PC9fY29tcG9uZW50cy5oMT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlN0YXR1czpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgcHJvZHVjdCBkZWZpbml0aW9uIChwcm9wb3NhbCkgwrcgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJVcGRhdGVkOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAyMDI2LTA2LTI2XFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJBdXRob3I6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGRyYWZ0ZWQgZm9yIFwifTxfY29tcG9uZW50cy5hIGhyZWY9XCJtYWlsdG86cGV0ZXJAcGV0ZXJuZXVtYXJrLmNvbVwiPntcInBldGVyQHBldGVybmV1bWFyay5jb21cIn08L19jb21wb25lbnRzLmE+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJDb21wYW5pb24gdG86XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5hIGhyZWY9XCIuL2dyb3ZlLm1kXCI+PF9jb21wb25lbnRzLmNvZGU+e1wiZ3JvdmUubWRcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5hPntcIiBhbmRcXG5cIn08X2NvbXBvbmVudHMuYSBocmVmPVwiLi9ncm92ZS1pbnRlcmFjdGl2ZS1jb250ZW50Lm1kXCI+PF9jb21wb25lbnRzLmNvZGU+e1wiZ3JvdmUtaW50ZXJhY3RpdmUtY29udGVudC5tZFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLmE+e1wiIOKAlCByZWFkIHRob3NlIGZpcnN0LlxcblwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiUGxhdGZvcm0gc291cmNlIG9mIHRydXRoOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB0aGUgaW1tZWRpYXRlbHktcnVuIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZG9jc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiByZXBvLFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcInNwZWNzL0FHRU5UX0FVVEhPUklOR19BUkNISVRFQ1RVUkUubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICh0aGUgY3Jvc3MtYXBwIGFyY2hpdGVjdHVyZTsgdGhpcyBkb2MgaXMgdGhlXFxuR3JvdmUtc3BlY2lmaWMgYXBwbGljYXRpb24gb2YgaXQpLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaHIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJ3aHktdGhpcy1kb2N1bWVudC1leGlzdHNcIj48SGVhZGluZ0FuY2hvciBpZD1cIndoeS10aGlzLWRvY3VtZW50LWV4aXN0c1wiIC8+e1wiV2h5IHRoaXMgZG9jdW1lbnQgZXhpc3RzXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuY29kZT57XCJncm92ZS1pbnRlcmFjdGl2ZS1jb250ZW50Lm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBzZXR0bGVzIFwifTxfY29tcG9uZW50cy5lbT57XCJ3aGVyZSBhdXRob3JpdHkgbGl2ZXNcIn08L19jb21wb25lbnRzLmVtPntcIjogR3JvdmUgaG9sZHMgbm8gc3RhbmRpbmdcXG5oaWdoLXN0YWtlcyBhdXRob3JpdHksIGFuZCB0aGUgYWdlbnQg4oCUIGJlY2F1c2UgaXQgbmVlZHMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibGxtOmNoYXRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCBydW5zIGFzIGEgc2VwYXJhdGUsXFxuaG9zdC1icm9rZXJlZCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm1pbmktYXBwXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBub3QgYW1iaWVudCBpbiBHcm92ZSdzIHRyZWUuIFRoaXMgZG9jdW1lbnQgc2V0dGxlcyB0aGUgcGFydCB0aGF0XFxubGVmdCBvcGVuOiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImhvdyB0aGF0IGFnZW50IGFjdHVhbGx5IGF1dGhvcnMgdGhlIHdpa2kgYW5kIGNsb3NlcyB0aGUgbG9vcCBvbiB3aGF0IGl0IHdyb3RlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlFxcbnRoZSBwcmluY2lwYWwgaXQgcnVucyB1bmRlciwgdGhlIGludGVyZmFjZSBpdCB1c2VzIHRvIGNoYW5nZSBjb250ZW50LCB3aGF0IGl0IG9ic2VydmVzLCBhbmQgaG93XFxuaXRzIGVkaXRzIHJlY29uY2lsZSB3aXRoIGEgaHVtYW4gZWRpdGluZyBhdCB0aGUgc2FtZSB0aW1lLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgb25lLWxpbmUgdGhlc2lzOiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInRoZSBhZ2VudCBwcm9wb3NlczsgR3JvdmUgYXBwbGllcy5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhlIGFnZW50IG5ldmVyIGhvbGRzIHdyaXRlIGFjY2Vzc1xcbnRvIHRoZSB3aWtpLiBJdCBlbWl0cyBzZW1hbnRpYyBwYXRjaGVzOyBHcm92ZSDigJQgd2hpY2ggb3ducyB0aGUgd2lraSBzY2hlbWEgYW5kIGNvbnRyYWN0IOKAlFxcbnZhbGlkYXRlcyB0aGVtLCBtZXJnZXMgdGhlbSBhZ2FpbnN0IGNvbmN1cnJlbnQgZWRpdHMsIGFuZCB3cml0ZXMuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5ociAvPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInRoZS1zZWxmLWF1dGhvcmluZy1hZ2VudC1wcmluY2lwYWxcIj48SGVhZGluZ0FuY2hvciBpZD1cInRoZS1zZWxmLWF1dGhvcmluZy1hZ2VudC1wcmluY2lwYWxcIiAvPntcIlRoZSBzZWxmLWF1dGhvcmluZyBhZ2VudCBwcmluY2lwYWxcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSBhZ2VudCBtaW5pLWFwcCBydW5zIHVuZGVyIGEgdGlnaHQgcHJpbmNpcGFsIHdob3NlIGNlaWxpbmcgaXMgZXhhY3RseTpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuY29kZT57XCJjaGF0KClcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCB0aGUgTExNIHNsb3QgKHRoZSBob3N0IGluamVjdHMgdGhlIHVzZXIncyBrZXk7IEdyb3ZlL3RoZSBhZ2VudCBuZXZlciBzZWVzIGl0KS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuY29kZT57XCJkaWFnbm9zdGljczpyZWFkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBcIn08X2NvbXBvbmVudHMuZW0+e1wiKHN1YmplY3Q6IHRoaXMgR3JvdmUpXCJ9PC9fY29tcG9uZW50cy5lbT57XCIg4oCUIE1EWCBjb21waWxlL3RyYW5zcGlsZSBlcnJvcnMgKyBjYXB0dXJlZCBjb25zb2xlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5jb2RlPntcInJlbmRlcjpyZWFkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBcIn08X2NvbXBvbmVudHMuZW0+e1wiKHN1YmplY3QpXCJ9PC9fY29tcG9uZW50cy5lbT57XCIg4oCUIGFuIG9uLWRlbWFuZCByZW5kZXJlZC1ET00gLyBhMTF5IHNuYXBzaG90LCB0byB2ZXJpZnkgYSByZXN1bHQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLmNvZGU+e1wiaXBjIOKGkiBHcm92ZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIHByb3Bvc2UgcGF0Y2hlczsgcmVjZWl2ZSBcXFwiY3VycmVudCBlbnRyeSAvIHNlbGVjdGlvblxcXCIgY29udGV4dCBkZWx0YXMuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJhbmQgbm90aGluZyBlbHNlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBubyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJuZXQ6ZmV0Y2hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBubyBzZWNyZXRzLCBubyBmb3JlaWduIG1vdW50cywgbm8gY3Jvc3MtcmVwbyByZWFjaCxcXG5hbmQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJubyBkb2N1bWVudCB3cml0ZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiSXQgaGFzIGl0cyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm93biBhcHBLZXlcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKGRpc3RpbmN0IGZyb20gR3JvdmUpLCB3aGljaCBrZWVwcyBpdHMgZ3JhbnRzIGlzb2xhdGVkIGZyb20gR3JvdmUnc1xcbmZyYW1lIChhbmQgc2lkZXN0ZXBzIHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJTUEVDX0FVRElUX1JFUE9SVC5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgU0gtMSBncmFudC1ibGVlZCBkZWZlY3QpLiBCZWNhdXNlXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZGlhZ25vc3RpY3M6cmVhZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYW5kIGEgd3JpdGUgcG9ydCBhcmUgYWJvdmUgdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wic3RhZ2VcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgY2VpbGluZyBHcm92ZSBydW5zIHVuZGVyLCB0aGUgYWdlbnRcXG5cIn08X2NvbXBvbmVudHMuZW0+e1wibXVzdFwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGJlIGEgc2VwYXJhdGUsIGhpZ2hlci1wcmluY2lwYWwgc2xvdCDigJQgdGhlIHBsYXRmb3JtIGZvcmNlcyB0aGUgZXh0ZXJuYWxpemF0aW9uLCBhbmQgdGhhdFxcbmlzIHdoYXQgbWFrZXMgdGhlIGFnZW50IHN1cnZpdmUgR3JvdmUgcmUtcmVuZGVyaW5nIGl0c2VsZi5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIHNpZ25hdHVyZSBhbHdheXMtcHJlc2VudCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlxcXCJBc2sgR3JvdmXigKZcXFwiIGxpbmUgc3RheXMgaW4gR3JvdmUncyBvd24gRE9NXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChicmllZiAwNiksIGJ1dCBpdFxcbmhvbGRzIG5vIGxvb3AgYW5kIG5vIGdyYW50czogaXQgb25seSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImZvcndhcmRzIHRoZSBwcm9tcHQgb3ZlciBJUENcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdG8gdGhlIGFnZW50IG1pbmktYXBwLlxcblRoZSBjb252ZXJzYXRpb24sIHRoZSBsb29wLCBhbmQgdGhlIGF1dGhvcml0eSBsaXZlIGluIHRoZSBtaW5pLWFwcDsgdGhlIGxpbmUgaXMgYSBzdHlsZWRcXG5mb3J3YXJkZXIsIHNvIGEgcmUtcmVuZGVyIG9mIHRoZSB3aWtpIG5ldmVyIGxvc2VzIHRoZSBjb252ZXJzYXRpb24uXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5ociAvPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInRoZS1pbnRlcmZhY2Utc2VtYW50aWMtcGF0Y2hlcy1ub3QtZmlsZS13cml0ZXNcIj48SGVhZGluZ0FuY2hvciBpZD1cInRoZS1pbnRlcmZhY2Utc2VtYW50aWMtcGF0Y2hlcy1ub3QtZmlsZS13cml0ZXNcIiAvPntcIlRoZSBpbnRlcmZhY2U6IHNlbWFudGljIHBhdGNoZXMsIG5vdCBmaWxlIHdyaXRlc1wifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLmVtPntcIihTdXBlcnNlZGVkIDIwMjYtMDYtMjcgYnkgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQUdFTlRfQVVUSE9SSU5HX0FSQ0hJVEVDVFVSRS5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgwqczL8KnNy4gVGhlIHNlbWFudGljLXBhdGNoIGludGVyZmFjZVxcbmlzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZHJvcHBlZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIjogdGhlIHdvcmtiZW5jaCBhZ2VudCB3cml0ZXMgR3JvdmUncyBmaWxlc3lzdGVtIGRpcmVjdGx5IChhbiBvcmRpbmFyeVxcbmVkaXRpbmctc2Vzc2lvbiB3cml0ZSksIGFuZCBHcm92ZSBkb2VzIG5vdCB2YWxpZGF0ZS9hcHBseSBwYXRjaGVzLiBUaGUgbW90aXZhdGlvbiBiZWxvdyDigJQgdGhlXFxuYWdlbnQgbmVlZHMgbm8gd3JpdGUgYXV0aG9yaXR5IGJlY2F1c2UgR3JvdmUgaXMgdGhlIGdhdGVrZWVwZXIg4oCUIGlzIHJlcGxhY2VkIGJ5OiB0aGUgYWdlbnQgaGFzXFxudGhlIHdvcmtiZW5jaCdzIGV4aXN0aW5nIHRyZWUtd3JpdGUgYXV0aG9yaXR5LCBhbmQgdGhlIHNlY3VyaXR5IGJhY2tzdG9wIGlzIHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImdhdGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKGNvbW1pdFxcbmZvciBnaXQ7IGZvciBhIG5vbi1naXQgc3BhY2UsIGEgbG9jYWwgcHJlLXB1Ymxpc2ggZGlmZiByZXZpZXcgKyBMV1cgcHVibGlzaCB3aXRoXFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJkZXRlY3QtYWZ0ZXItY2xvYmJlclwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB2aWEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiUmVtb3RlT3ZlcndyaXRlRW1pdHRlclwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibm90XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGEgcHJldmVudGluZyBDQVMsIEZpcmVzdG9yZUZTIGhhc1xcbm5vIGV0YWcpLCBub3QgYSBHcm92ZSB2YWxpZGF0b3IuIEdyb3ZlJ3MgY29udHJhY3QgKHRheG9ub215LCBsaW5rIGludGVncml0eSwgZnJvbnRtYXR0ZXIgc2NoZW1hKVxcbmJlY29tZXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJmZWVkYmFja1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB2aWEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZGlhZ25vc3RpY3M6cmVhZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKyBhIExheWVyLTMgZHJpZnQgZmxhZywgbm90IGEgcHJlLXdyaXRlIHJlamVjdC5cXG5Db25mbGljdCBpcyBmaWxlLWxldmVsIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJidWZmZXIudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGJsb2NrLW9uLWRpcnR5ICsgYSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImNvbnRlbnQtY29tcGFyaXNvbiB0b2tlblwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgZ2l0IGJsb2JcXG5TSEEgLyBGaXJlc3RvcmUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiIXNhbWVEYXRhXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiksIG5vdCBhIEdyb3ZlLXJ1biBjb25mbGljdCBjaGFpbi4pXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIjdhZDg5YjMgKGRvY3MoYWdlbnQtYXV0aG9yaW5nKTogZml4IHN0YWxlIENBUyB0ZXJtaW5vbG9neSBpbiByZWNvbmNpbGlhdGlvbiBub3RlcyAoRDIpKVxcblRoZSBhZ2VudCBzcGVha3MgR3JvdmUncyBzY2hlbWEgb3ZlciB0aGUgSVBDIGVkZ2UsIGluIHR3byB2ZXJiczpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTwvX2NvbXBvbmVudHMuYmxvY2txdW90ZT57XCJcXG5cIn08L19jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTwvX2NvbXBvbmVudHMuYmxvY2txdW90ZT57XCJcXG5cIn08L19jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLmNvZGU+e1wicGF0Y2godGFyZ2V0LCBmaWVsZE9wcylcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGZvciBhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wid2lraSBlbnRyeVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoYW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLm1keFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZmlsZTogdHlwZWQgZnJvbnRtYXR0ZXIgKyBNRFggYm9keSkuXFxuRXhhbXBsZXM6IFwifTxfY29tcG9uZW50cy5lbT57XCJhZGQgdGFnIFwifTxfY29tcG9uZW50cy5jb2RlPntcImRyYWZ0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB0byBlbnRyeSBFXCJ9PC9fY29tcG9uZW50cy5lbT57XCI7IFwifTxfY29tcG9uZW50cy5lbT57XCJzZXQgdGhlIGJvZHkgb2YgRSB0byDigKZcIn08L19jb21wb25lbnRzLmVtPntcIjsgXCJ9PF9jb21wb25lbnRzLmVtPntcImNyZWF0ZSBlbnRyeSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ7IHNsdWcsIHRpdGxlLCB0YWdzLCBib2R5IH1cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5lbT57XCI7IFwifTxfY29tcG9uZW50cy5lbT57XCJyZXdyaXRlIHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJbW2xpbmtdXVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaW4gRSBmcm9tIFggdG8gWVwifTwvX2NvbXBvbmVudHMuZW0+e1wiLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5jb2RlPntcInB1dEFzc2V0KHBhdGgsIGJ5dGVzKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZm9yIGFuIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wib3BhcXVlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHVuaXQgKGFuIGltYWdlKSDigJQgd2hvbGUtZmlsZSByZXBsYWNlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJHcm92ZSByZWNlaXZlcyBhIHBhdGNoIGFuZCwgYmVmb3JlIHdyaXRpbmcsIHJ1bnMgaXQgdGhyb3VnaCBpdHMgb3duIGdhdGU6IHZhbGlkYXRlIGFnYWluc3QgdGhlXFxuY29udHJhY3QgKExheWVyIDAgY29udmVudGlvbnMsIHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJHUk9WRS5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdGF4b25vbXksIGZyb250bWF0dGVyIHNjaGVtYSksIGNoZWNrIGxpbmtcXG5pbnRlZ3JpdHksIHRoZW4gYXBwbHkgdGhyb3VnaCB0aGUgY29uZmxpY3QgY2hhaW4gKGJlbG93KS4gVGhpcyBpcyB0aGUgcHJpbmNpcGxlZCBcXFwicHJveHkgdGhyb3VnaFxcbnRoZSBhcHBcXFwiIOKAlCBHcm92ZSBhZGRzIHJlYWwgcG9saWN5IChzY2hlbWEgKyBjb250cmFjdCArIGNvbmZsaWN0IGhhbmRsaW5nKSwgc28gdGhlIGhvcCBlYXJucyBpdHNcXG5wbGFjZSwgYW5kIHRoZSBhZ2VudCBuZWVkcyBubyB3cml0ZSBhdXRob3JpdHkgYXQgYWxsLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIldoYXQgR3JvdmUgd3JpdGVzIHRocm91Z2guXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIEluIHRoZSBjb21tb24gY2FzZSBHcm92ZSdzIGNvbnRlbnQgbGl2ZXMgaW4gYSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInNlcGFyYXRlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiXFxuZmlsZXN5c3RlbSAoYSBzcGFjZSAvIGEgY29udGVudCByZXBvKSwgYW5kIEdyb3ZlIHdyaXRlcyBpdCB2aWEgYW4gb3JkaW5hcnkgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJydyBtb3VudCBncmFudFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJRcXG5jb2xsYWJvcmF0b3ItZ2F0ZWQsIHJlYWQtb25seSBmb3IgdW50cnVzdGVkIHZpZXdlcnMsIHJldm9jYWJsZTsgXCJ9PF9jb21wb25lbnRzLmVtPntcIm5vdFwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGEgc3RhbmRpbmcgYXBwXFxuY2FwYWJpbGl0eS4gT25seSBpbiB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJmdXNlZCBzaW5nbGUtcmVwb1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBHcm92ZSAoY29udGVudCBzdG9yZWQgaW4gR3JvdmUncyBvd24gYXBwIHJlcG8pIGlzXFxudGhlIHdyaXRlIHRoZSBzdGFuZGluZyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJleHBvc2VzV29ya2luZ1RyZWU6J3J3J1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcmVnaW9uIHByb3BlcnR5IOKAlCBvcHQtaW4sIGFuZCB0aGUgY29uZmlndXJhdGlvblxcbndoZXJlIEdpdEh1YidzIGJyYW5jaC9QUi9tZXJnZSBiZWNvbWVzIHRoZSBkdXJhYmxlIGNvbmZsaWN0IGxheWVyIChhIHJlYWwgcmVhc29uIGFcXG5oZWF2aWx5LWN1c3RvbWl6ZWQgR3JvdmUgY2hvb3NlcyBpdCkuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5ociAvPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cIm9ic2VydmUtY29udGV4dC1jbG9zaW5nLXRoZS1sb29wXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJvYnNlcnZlLWNvbnRleHQtY2xvc2luZy10aGUtbG9vcFwiIC8+e1wiT2JzZXJ2ZSArIGNvbnRleHQ6IGNsb3NpbmcgdGhlIGxvb3BcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQ29udGV4dCDigJQgcmUtZGVyaXZlZCwgbmV2ZXIgcmVhZCBmcm9tIEdyb3ZlJ3MgbWVtb3J5LlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGUgYWdlbnQgYnVpbGRzIGNvbnRleHQgdGhlIHNhbWUgd2F5XFxuYSBmcmVzaCBhZ2VudCBzZXNzaW9uIGRvZXM6IGl0IHJlYWRzIHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm1hbmlmZXN0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChcIn08X2NvbXBvbmVudHMuY29kZT57XCIuZ3JvdmUvbWFuaWZlc3QuanNvblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLCB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJhdXRob3JlZFxcbmNvbnRyYWN0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJHUk9WRS5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLCBhbmQgdGhlIGVudHJpZXMgdGhlbXNlbHZlczsgYW5kIGl0IHJlY2VpdmVzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibGl2ZSBkZWx0YXNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHRoZVxcbmN1cnJlbnQgZW50cnksIHRoZSB0ZXh0IHNlbGVjdGlvbiDigJQgb3ZlciB0aGUgSVBDIGVkZ2UuIFRoZSBjb250ZXh0IGNvbnRyYWN0IFwifTxfY29tcG9uZW50cy5lbT57XCJpc1wifTwvX2NvbXBvbmVudHMuZW0+e1wiIHRoZSBhZ2VudFxcbmNvbnRyYWN0IEdyb3ZlIGFscmVhZHkgZGVmaW5lcyAoTGF5ZXJzIDDigJMyKS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJPYnNlcnZlIOKAlCB3aGF0IGl0IHNlZXMgYWZ0ZXIgYSB3cml0ZS5cIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkRpYWdub3N0aWNzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJkaWFnbm9zdGljczpyZWFkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIik6IGlmIGEgcGF0Y2ggcHJvZHVjZXMgaW52YWxpZCBNRFgsIHRoZSBjb21waWxlIGVycm9yIGlzXFxuZGVsaXZlcmVkIHRvIHRoZSBhZ2VudCBzbyBpdCBjYW4gc2VsZi1jb3JyZWN0LiBDb3ZlcnMgY29tcGlsZSBmYWlsdXJlcyBhbmQgcnVudGltZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjb25zb2xlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIlxcbnRocm93cy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlJlbmRlciBzbmFwc2hvdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicmVuZGVyOnJlYWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBvbiBkZW1hbmQpOiBcXFwiZGlkIHRoZSBlbnRyeSByZW5kZXIgdGhlIHdheSBJIGludGVuZGVkLFxcXCJcXG5mb3IgdGhlIHZpc3VhbC9zZW1hbnRpYyBjaGVjayBkaWFnbm9zdGljcyBjYW4ndCBnaXZlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlRoZSBsb29wOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiByZWFkIGNvbnRleHQg4oaSIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNoYXQoKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oaSIGVtaXQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicGF0Y2hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKGkiBHcm92ZSB2YWxpZGF0ZXMgKyBtZXJnZXMgKyB3cml0ZXMg4oaSIGhvc3RcXG5yZS1yZWFkcy9yZWNvbXBpbGVzIChsYXN0LWdvb2QgR3JvdmUga2VlcHMgcmVuZGVyaW5nIGlmIGEgY2FuZGlkYXRlIGZhaWxzKSDihpIgZGlhZ25vc3RpY3MgKMKxIGFcXG5yZW5kZXIgc25hcHNob3QpIGNvbWUgYmFjayDihpIgYnJva2VuIG1lYW5zIHRoZSBlcnJvciBpcyBpbiB0aGUgbmV4dCBwcm9tcHQ7IGdvb2QgbWVhbnMgR3JvdmVcXG5yZS1yZW5kZXJzIGFuZCByZS1lbWl0cyBjb250ZXh0LiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIkxhbmRpbmcgaXMgYSBzZXBhcmF0ZSwgZ2F0ZWQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY29udHJpYnV0ZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgc3RlcFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgdGhlIHVzZXJcXG5yZXZpZXdzIHRoZSBkaWZmIGJlZm9yZSBhZ2VudC1hdXRob3JlZCBieXRlcyBiZWNvbWUgZHVyYWJsZS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmhyIC8+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwiY29uZmxpY3RzLXRoZS1hZ2VudC1pcy1qdXN0LWFub3RoZXItd3JpdGVyXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJjb25mbGljdHMtdGhlLWFnZW50LWlzLWp1c3QtYW5vdGhlci13cml0ZXJcIiAvPntcIkNvbmZsaWN0czogdGhlIGFnZW50IGlzIGp1c3QgYW5vdGhlciB3cml0ZXJcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlNjb3BlIGlzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibGlnaHQgYXN5bmMgY29sbGFib3JhdGlvblwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoYSBmZXcgd3JpdGVycywgbW9zdGx5IGRpZmZlcmVudCBlbnRyaWVzLCBvY2Nhc2lvbmFsXFxuY29sbGlzaW9uKSDigJQgbm90IHJlYWwtdGltZSBtdWx0aS1jdXJzb3IuIEFnZW50IHBhdGNoZXMsIGEgaHVtYW4gZWRpdGluZyBpbiB0aGUgcGxhdGZvcm0gZWRpdG9yLFxcbmFuZCBhIHJlbW90ZSBjb2xsYWJvcmF0b3IgYWxsIGJlY29tZSB3cml0ZXMgdG8gdGhlIGNvbnRlbnQgbW91bnQsIHN1cmZhY2VkIHRvIGV2ZXJ5b25lIGJ5XFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wib25Gc0NoYW5nZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJGaWxlLXBlci1lbnRyeSBwYXJ0aXRpb25zIG1vc3QgY29uZmxpY3QgYXdheS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVHdvIHdyaXRlcnMgb24gXCJ9PF9jb21wb25lbnRzLmVtPntcImRpZmZlcmVudFwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGVudHJpZXMgbmV2ZXJcXG5jb25mbGljdC4gVGhlIGRvbWFpbiBzaHJpbmtzIHRvIHRoZSBzYW1lIGVudHJ5LCBjb25jdXJyZW50bHkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJXaXRoaW4gYW4gZW50cnksIG1lcmdlIGJ5IGZpZWxkLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBGcm9udG1hdHRlciBpcyBhIHR5cGVkIG1hcCAocGVyLWtleSBtZXJnZSDigJQgZGlzam9pbnQga2V5c1xcbmF1dG8tbWVyZ2UpOyB0aGUgYm9keSBpcyB0ZXh0ICgzLXdheSkuIEEgaHVtYW4gcmV0aXRsaW5nIHdoaWxlIHRoZSBhZ2VudCByZXRhZ3MgdGhlIHNhbWUgZW50cnlcXG5pcyBkaXNqb2ludCBhbmQgbWVyZ2VzIGNsZWFubHk7IG9ubHkgYSB0cnVlIHNhbWUtZmllbGQgb3ZlcmxhcCBibG9ja3MuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJDaGFpbmVkIHJlc29sdmVycywgbW9zdC1zcGVjaWZpYyB0byBtb3N0LWdlbmVyYWw6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIEdyb3ZlJ3MgY29udHJhY3QtYXdhcmUgcmVzb2x2ZXJcXG4odGF4b25vbXksIGxpbmsgaW50ZWdyaXR5KSDihpIgTURYL01hcmtkb3duIHN0cnVjdHVyYWwgbWVyZ2Ug4oaSIGdlbmVyaWMgdGV4dCDihpIgdGVybWluYWwuIFRoZVxcbnRlcm1pbmFsIGlzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiR2l0SHViIGJyYW5jaC9QUlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB3aGVuIGNvbnRlbnQgaXMgYSBnaXQgcmVwbywgb3IgbGFzdC13cml0ZSAvIGEgXCJ9PF9jb21wb25lbnRzLmVtPntcInVzZXItaW5pdGlhdGVkXCJ9PC9fY29tcG9uZW50cy5lbT57XCJcXG5hZ2VudC1kaWZmIGZvciBhIG5vbi1naXQgc3BhY2UuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJCYWNrc3RvcHM6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHNlbWFudGljIHN0YWxlbmVzcyAoYSBwYXRjaCBjb3JyZWN0IGFzIGJ5dGVzIGJ1dCB3cm9uZyBiZWNhdXNlIHRoZSBlbnRyeSdzXFxubWVhbmluZyBjaGFuZ2VkIHVuZGVyIGl0KSBpcyBjYXVnaHQgYnkgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJodW1hbiByZXZpZXcgYXQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY29udHJpYnV0ZVwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnN0cm9uZz57XCI7IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1widW5kbyBpc1xcbnBlci1hdXRob3Itc2NvcGVkXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICh5b3VyIGVkaXRzIGFuZCB5b3VyIGFnZW50J3MsIG5vdCBhIGNvbGxhYm9yYXRvcidzKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmhyIC8+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwid2hhdC1jaGFuZ2VzLWluLWdyb3ZlLWZyb20tdG9kYXlcIj48SGVhZGluZ0FuY2hvciBpZD1cIndoYXQtY2hhbmdlcy1pbi1ncm92ZS1mcm9tLXRvZGF5XCIgLz57XCJXaGF0IGNoYW5nZXMgaW4gR3JvdmUgKGZyb20gdG9kYXkpXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuY29kZT57XCJHcm92ZUFnZW50LnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdG9kYXkgcnVucyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjaGF0KClcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1widGV4dC1vbmx5LCBhbWJpZW50IGluIEdyb3ZlJ3MgdHJlZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgYW5kIGhhbmRzIHdyaXRlcyBvZmZcXG50byB0aGUgcGxhdGZvcm0gZWRpdG9yIHZpYSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyZXF1ZXN0RWRpdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuIFRoZSB0YXJnZXQgYXJjaGl0ZWN0dXJlOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuYmxvY2txdW90ZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuZW0+e1wiKENvcnJlY3RlZCAyMDI2LTA2LTI3IHBlciBcIn08X2NvbXBvbmVudHMuY29kZT57XCJBR0VOVF9BVVRIT1JJTkdfQVJDSElURUNUVVJFLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDCpzMvwqc3IOKAlCBzdGVwcyAx4oCTMyBiZWxvdyBhcmVcXG5zdXBlcnNlZGVkLiBUaGUgYWdlbnQgaXMgdGhlIHBsYXRmb3JtIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wid29ya2JlbmNoIGFnZW50XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChlZGl0aW5nLXNlc3Npb24gcHJpbmNpcGFsKSwgbm90IGFcXG5Hcm92ZSBzZWxmLWF1dGhvcmluZyBtaW5pLWFwcDsgaXQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ3cml0ZXMgR3JvdmUncyBmaWxlc3lzdGVtIGRpcmVjdGx5XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBzbyB0aGVyZSBpcyBubyBwYXRjaFxcbmludGVyZmFjZSBhbmQgbm8gR3JvdmUtcnVuIGNvbmZsaWN0IGNoYWluLiBHcm92ZSBiZWNvbWVzIGEgcmVhZC1vbmx5IHJlbmRlcmVyOyBpdHMgY29udHJhY3RcXG5zdXJmYWNlcyBhcyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJkaWFnbm9zdGljczpyZWFkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiArIGEgTGF5ZXItMyBkcmlmdCBmbGFnIChmZWVkYmFjayksIGFuZCBjb25mbGljdCBpcyBmaWxlLWxldmVsXFxuKFwifTxfY29tcG9uZW50cy5jb2RlPntcImJ1ZmZlci50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYmxvY2stb24tZGlydHkgKyBhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiY29udGVudC1jb21wYXJpc29uIHRva2VuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBkZXRlY3QtYWZ0ZXItY2xvYmJlciBvbiBub24tZ2l0IHZpYVxcblwifTxfY29tcG9uZW50cy5jb2RlPntcIlJlbW90ZU92ZXJ3cml0ZUVtaXR0ZXJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCBub3QgYSBwcmV2ZW50aW5nIENBUykgcmVjb25jaWxlZCBhdCB0aGUgZ2F0ZSwgbm90IGluc2lkZSBHcm92ZS4pXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLmRlbD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkV4dGVybmFsaXplIHRoZSBhZ2VudFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBpbnRvIGEgbWluaS1hcHAgdW5kZXIgdGhlIHNlbGYtYXV0aG9yaW5nIHByaW5jaXBhbFwifTwvX2NvbXBvbmVudHMuZGVsPntcIiDihpIgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ1c2UgdGhlXFxucGxhdGZvcm0gd29ya2JlbmNoIGFnZW50XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChvd24gYXBwS2V5LCBlZGl0aW5nLXNlc3Npb24gcHJpbmNpcGFsKS4gS2VlcCB0aGUgaW4tRE9NIFxcXCJBc2tcXG5Hcm92ZeKAplxcXCIgbGluZSBhcyBhIGdyYW50LWxlc3MgZm9yd2FyZGVyIG9mIHRoZSBwcm9tcHQgdG8gdGhlIHdvcmtiZW5jaCBhZ2VudC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuZGVsPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUmVwbGFjZSB0aGUgdGV4dC1vbmx5IGxvb3Agd2l0aCB0aGUgcGF0Y2ggaW50ZXJmYWNlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy5kZWw+e1wiIOKGkiB0aGUgd29ya2JlbmNoIGFnZW50IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wid3JpdGVzXFxuR3JvdmUncyBmaWxlc3lzdGVtIGRpcmVjdGx5XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiOyBHcm92ZSBkb2VzIG5vdCB2YWxpZGF0ZS9hcHBseSBwYXRjaGVzLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5kZWw+PF9jb21wb25lbnRzLnN0cm9uZz57XCJBcHBseSB0aHJvdWdoIGEgY29uZmxpY3QgY2hhaW5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgaW5zaWRlIEdyb3ZlXCJ9PC9fY29tcG9uZW50cy5kZWw+e1wiIOKGkiBjb25mbGljdCBpcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImZpbGUtbGV2ZWwgYXQgdGhlIHdvcmtpbmdcXG50cmVlIC8gdGhlIGdhdGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKG5vdCBhIEdyb3ZlLXJ1biByZXNvbHZlciBjaGFpbiBpbiBWMSkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJXaXJlIG9ic2VydmF0aW9uXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJkaWFnbm9zdGljczpyZWFkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoKyBvcHRpb25hbCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyZW5kZXI6cmVhZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLCBjb250ZXh0IHJlLWRlcml2ZWQgZnJvbVxcbnRoZSBtYW5pZmVzdC9cIn08X2NvbXBvbmVudHMuY29kZT57XCJHUk9WRS5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvZW50cmllcyBwbHVzIElQQyBuYXYgZGVsdGFzLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQ29uc2lkZXIgdGhlIEZTLTEvRlMtMiBzcGxpdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgY29udGVudCBpbiBhIHNlcGFyYXRlIG1vdW50IGJ5IGRlZmF1bHQgKG5vIHN0YW5kaW5nIHdyaXRlXFxuY2FwYWJpbGl0eSBmb3IgR3JvdmUpLCB3aXRoIHRoZSBmdXNlZCBzaW5nbGUtcmVwbyBhcyB0aGUgb3B0LWluLCBHaXRIdWItY29uZmxpY3QtcmVzb2x2ZWRcXG5jb25maWd1cmF0aW9uIGZvciBhIGhlYXZpbHktY3VzdG9taXplZCBHcm92ZS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMub2w+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiTm9uZSBvZiB0aGlzIHJlcXVpcmVzIEdyb3ZlIHRvIHJ1biB3aXRoIGVsZXZhdGVkIHByaXZpbGVnZSwgYW5kIG5vbmUgb2YgaXQgaXMgYSBwcml2aWxlZ2VkXFxuYWdlbnQgZGFlbW9uOiB0aGUgdHJ1c3RlZCBjb3JlIHN0YXlzIHRoZSBob3N0LCB0aGUgYWdlbnQgc3RheXMgY29uZmluZWQsIGFuZCBHcm92ZSdzXFxuY3VzdG9taXphdGlvbiBzdGF5cyBpbiB1bnByaXZpbGVnZWQgY29kZS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmhyIC8+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwib3Blbi1xdWVzdGlvbnMtZ3JvdmUtc3BlY2lmaWMtcGxhdGZvcm0tbGV2ZWwtb25lcy1saXZlLWluLXRoZS1kb2NzLXJlcG8tbm90ZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwib3Blbi1xdWVzdGlvbnMtZ3JvdmUtc3BlY2lmaWMtcGxhdGZvcm0tbGV2ZWwtb25lcy1saXZlLWluLXRoZS1kb2NzLXJlcG8tbm90ZVwiIC8+e1wiT3BlbiBxdWVzdGlvbnMgKEdyb3ZlLXNwZWNpZmljOyBwbGF0Zm9ybS1sZXZlbCBvbmVzIGxpdmUgaW4gdGhlIGRvY3MtcmVwbyBub3RlKVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlBhdGNoIHZvY2FidWxhcnlcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHRoZSBjb25jcmV0ZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmaWVsZE9wc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZm9yIGVudHJpZXMgKHRhZ3MsIGZyb250bWF0dGVyIGtleXMsIGJvZHlcXG5yYW5nZXMsIGxpbmsgcmV3cml0ZXMpIGFuZCBob3cgR3JvdmUgcmVnaXN0ZXJzIGl0cyByZXNvbHZlciArIHNjaGVtYSB3aXRoIHRoZSBob3N0LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRnVzZWQtY2FzZSB3cml0ZSBzY29waW5nXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCB3aGVuIGNvbnRlbnQgaXMgaW4gR3JvdmUncyBvd24gcmVwbywgd2hldGhlciBwYXRjaCBhcHBsaWNhdGlvblxcbmlzIGNocm9vdCdkIHRvIHRoZSBjb250ZW50IHN1YnRyZWUgc28gZG9jdW1lbnQgcGF0Y2hlcyBjYW5ub3QgcmVhY2ggZW5naW5lIHNvdXJjZS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkNvbnRyYWN0IHZhbGlkYXRpb24gdGltaW5nXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCB2YWxpZGF0ZSBhIHBhdGNoIFwifTxfY29tcG9uZW50cy5lbT57XCJiZWZvcmVcIn08L19jb21wb25lbnRzLmVtPntcIiB3cml0aW5nIChyZWplY3QpIHZzLiB3cml0ZSB0aGVuXFxuZmxhZyBkcmlmdCAodGhlIExheWVyLTMgdmFsaWRhdG9yKSwgYW5kIGhvdyByZWplY3Rpb25zIHN1cmZhY2UgYmFjayB0byB0aGUgYWdlbnQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJBbHdheXMtcHJlc2VudCBsaW5lIOKGlCBtaW5pLWFwcCBwbGFjZW1lbnRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIGtlZXBpbmcgdGhlIGJyaWVmLTA2IHJlc3RpbmcvZXhwYW5kZWQgZmVlbCB3aGVuXFxudGhlIGxvb3AncyBzdXJmYWNlIGlzIGEgaG9zdC1jb21wb3NpdGVkIHJlZ2lvbi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMub2w+PC8+O1xufVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTURYQ29udGVudChwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHt3cmFwcGVyOiBNRFhMYXlvdXR9ID0ge1xuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfTtcbiAgcmV0dXJuIE1EWExheW91dCA/IDxNRFhMYXlvdXQgey4uLnByb3BzfT48X2NyZWF0ZU1keENvbnRlbnQgey4uLnByb3BzfSAvPjwvTURYTGF5b3V0PiA6IF9jcmVhdGVNZHhDb250ZW50KHByb3BzKTtcbn1cbmZ1bmN0aW9uIF9taXNzaW5nTWR4UmVmZXJlbmNlKGlkLCBjb21wb25lbnQsIHBsYWNlKSB7XG4gIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIFwiICsgKGNvbXBvbmVudCA/IFwiY29tcG9uZW50XCIgOiBcIm9iamVjdFwiKSArIFwiIGBcIiArIGlkICsgXCJgIHRvIGJlIGRlZmluZWQ6IHlvdSBsaWtlbHkgZm9yZ290IHRvIGltcG9ydCwgcGFzcywgb3IgcHJvdmlkZSBpdC5cIiArIChwbGFjZSA/IFwiXFxuSXTigJlzIHJlZmVyZW5jZWQgaW4geW91ciBjb2RlIGF0IGBcIiArIHBsYWNlICsgXCJgIGluIGAvYXBwL2RvY3MvcHJvZHVjdC1kZWZzL2dyb3ZlLWFnZW50LWF1dGhvcmluZy5tZGBcIiA6IFwiXCIpKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQXdGLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUZ4RjtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU1DLFdBQVcsR0FBRztNQUNsQkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsVUFBVSxFQUFFLFlBQVk7TUFDeEJDLElBQUksRUFBRSxNQUFNO01BQ1pDLEdBQUcsRUFBRSxLQUFLO01BQ1ZDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLENBQUMsRUFBRSxHQUFHO01BQ05DLE1BQU0sRUFBRSxRQUFRO01BQ2hCQyxFQUFFLEVBQUUsSUFBSTtNQUNSLEdBQUcsSUFBQUMsNkJBQWtCLEVBQUMsQ0FBQztNQUN2QixHQUFHZixLQUFLLENBQUNnQjtJQUNYLENBQUM7SUFBRTtNQUFDQztJQUFhLENBQUMsR0FBR2hCLFdBQVc7RUFDaEMsSUFBSSxDQUFDZ0IsYUFBYSxFQUFFQyxvQkFBb0IsQ0FBQyxlQUFlLEVBQUUsSUFBSSxDQUFDO0VBQy9ELG9CQUFPLElBQUFwQixXQUFBLENBQUFxQixJQUFBLEVBQUFyQixXQUFBLENBQUFzQixRQUFBO0lBQUFDLFFBQUEsZ0JBQUUsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDZSxFQUFFLEVBQUMsZ0NBQWdDO01BQUFELFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBZ0MsQ0FBRSxDQUFDLEVBQUMsa0NBQWtDO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBeEIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDVyxDQUFDO01BQUFTLFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBUyxDQUFxQixDQUFDLEVBQUMsbUNBQW1DLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBVSxDQUFxQixDQUFDLEVBQUMsZUFBZSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQVMsQ0FBcUIsQ0FBQyxFQUFDLGVBQWUsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDQyxDQUFDO1FBQUNzQixJQUFJLEVBQUMsK0JBQStCO1FBQUFILFFBQUEsRUFBRTtNQUF3QixDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQWUsQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDQyxDQUFDO1FBQUNzQixJQUFJLEVBQUMsWUFBWTtRQUFBSCxRQUFBLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQVUsQ0FBbUI7TUFBQyxDQUFlLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0MsQ0FBQztRQUFDc0IsSUFBSSxFQUFDLGdDQUFnQztRQUFBSCxRQUFBLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQThCLENBQW1CO01BQUMsQ0FBZSxDQUFDLEVBQUMsd0JBQXdCLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBMkIsQ0FBcUIsQ0FBQyxFQUFDLHVCQUF1QixlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQU0sQ0FBcUIsQ0FBQyxFQUFDLFVBQVUsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1FBQUFpQixRQUFBLEVBQUU7TUFBdUMsQ0FBbUIsQ0FBQyxFQUFDLG1GQUFtRjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1EsRUFBRSxJQUFFLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQVgsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDTyxFQUFFO01BQUNjLEVBQUUsRUFBQywwQkFBMEI7TUFBQUQsUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUEwQixDQUFFLENBQUMsRUFBQywwQkFBMEI7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF4QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNXLENBQUM7TUFBQVMsUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1FBQUFpQixRQUFBLEVBQUU7TUFBOEIsQ0FBbUIsQ0FBQyxFQUFDLFdBQVcsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDSyxFQUFFO1FBQUFlLFFBQUEsRUFBRTtNQUF1QixDQUFpQixDQUFDLEVBQUMscUZBQXFGLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBaUIsUUFBQSxFQUFFO01BQVUsQ0FBbUIsQ0FBQyxFQUFDLHdDQUF3QyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQVUsQ0FBcUIsQ0FBQyxFQUFDLGlGQUFpRixlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQStFLENBQXFCLENBQUMsRUFBQyxpS0FBaUs7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNXLENBQUM7TUFBQVMsUUFBQSxHQUFFLHVCQUF1QixlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQW9DLENBQXFCLENBQUMsRUFBQyxtTUFBbU07SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNRLEVBQUUsSUFBRSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFYLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ08sRUFBRTtNQUFDYyxFQUFFLEVBQUMsb0NBQW9DO01BQUFELFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBb0MsQ0FBRSxDQUFDLEVBQUMsb0NBQW9DO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBeEIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDVyxDQUFDO01BQUFTLFFBQUEsRUFBRTtJQUEyRSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNhLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDUyxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQVEsQ0FBbUIsQ0FBQyxFQUFDLG1GQUFtRjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1MsRUFBRTtRQUFBVyxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFrQixDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNLLEVBQUU7VUFBQWUsUUFBQSxFQUFFO1FBQXVCLENBQWlCLENBQUMsRUFBQyxxREFBcUQ7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNTLEVBQUU7UUFBQVcsUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBYSxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNLLEVBQUU7VUFBQWUsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLG1FQUFtRTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1MsRUFBRTtRQUFBVyxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQywyRUFBMkU7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNTLEVBQUU7UUFBQVcsUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFrQixDQUFxQixDQUFDLEVBQUMsUUFBUSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyw2REFBNkQsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFtQixDQUFxQixDQUFDLEVBQUMsR0FBRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDVyxDQUFDO01BQUFTLFFBQUEsR0FBRSxhQUFhLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBWSxDQUFxQixDQUFDLEVBQUMsaUdBQWlHLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBaUIsUUFBQSxFQUFFO01BQXNCLENBQW1CLENBQUMsRUFBQyxzQ0FBc0MsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1FBQUFpQixRQUFBLEVBQUU7TUFBa0IsQ0FBbUIsQ0FBQyxFQUFDLGtDQUFrQyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQU8sQ0FBcUIsQ0FBQyxFQUFDLHdDQUF3QyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNLLEVBQUU7UUFBQWUsUUFBQSxFQUFFO01BQU0sQ0FBaUIsQ0FBQyxFQUFDLHVKQUF1SjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1csQ0FBQztNQUFBUyxRQUFBLEdBQUUsK0JBQStCLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBOEMsQ0FBcUIsQ0FBQyxFQUFDLDREQUE0RCxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQThCLENBQXFCLENBQUMsRUFBQyx3TEFBd0w7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNRLEVBQUUsSUFBRSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFYLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ08sRUFBRTtNQUFDYyxFQUFFLEVBQUMsZ0RBQWdEO01BQUFELFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBZ0QsQ0FBRSxDQUFDLEVBQUMsa0RBQWtEO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBeEIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDRSxVQUFVO01BQUFrQixRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNXLENBQUM7UUFBQVMsUUFBQSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNLLEVBQUU7VUFBQWUsUUFBQSxHQUFFLDRCQUE0QixlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7WUFBQWlCLFFBQUEsRUFBRTtVQUFpQyxDQUFtQixDQUFDLEVBQUMsMkNBQTJDLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtZQUFBUSxRQUFBLEVBQUU7VUFBUyxDQUFxQixDQUFDLEVBQUMsd1ZBQXdWLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtZQUFBUSxRQUFBLEVBQUU7VUFBTSxDQUFxQixDQUFDLEVBQUMsOEZBQThGLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtZQUFBUSxRQUFBLEVBQUU7VUFBc0IsQ0FBcUIsQ0FBQyxFQUFDLE9BQU8sZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1lBQUFpQixRQUFBLEVBQUU7VUFBd0IsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1lBQUFRLFFBQUEsRUFBRTtVQUFLLENBQXFCLENBQUMsRUFBQyxnSkFBZ0osZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1lBQUFRLFFBQUEsRUFBRTtVQUFVLENBQXFCLENBQUMsRUFBQyxPQUFPLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBaUIsUUFBQSxFQUFFO1VBQWtCLENBQW1CLENBQUMsRUFBQyw0RUFBNEUsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1lBQUFpQixRQUFBLEVBQUU7VUFBVyxDQUFtQixDQUFDLEVBQUMsc0JBQXNCLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtZQUFBUSxRQUFBLEVBQUU7VUFBMEIsQ0FBcUIsQ0FBQyxFQUFDLCtCQUErQixlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7WUFBQWlCLFFBQUEsRUFBRTtVQUFXLENBQW1CLENBQUMsRUFBQyxxQ0FBcUM7UUFBQSxDQUFpQjtNQUFDLENBQWUsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUF5QixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNFLFVBQVU7TUFBQWtCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0UsVUFBVTtRQUFBa0IsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDRSxVQUFVO1VBQUFrQixRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNFLFVBQVU7WUFBQWtCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0UsVUFBVTtjQUFBa0IsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDRSxVQUFVO2dCQUFBa0IsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDRSxVQUFVO2tCQUFBa0IsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDVyxDQUFDO29CQUFBUyxRQUFBLEVBQUU7a0JBQTJKLENBQWdCLENBQUMsRUFBQyxJQUFJO2dCQUFBLENBQXlCLENBQUMsRUFBQyxJQUFJO2NBQUEsQ0FBeUIsQ0FBQyxFQUFDLElBQUk7WUFBQSxDQUF5QixDQUFDLEVBQUMsSUFBSTtVQUFBLENBQXlCLENBQUMsRUFBQyxJQUFJO1FBQUEsQ0FBeUIsQ0FBQyxFQUFDLElBQUk7TUFBQSxDQUF5QixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQXlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ2EsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNTLEVBQUU7UUFBQVcsUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBeUIsQ0FBbUIsQ0FBQyxFQUFDLFNBQVMsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFZLENBQXFCLENBQUMsRUFBQyxPQUFPLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQU0sQ0FBbUIsQ0FBQyxFQUFDLG1EQUFtRCxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNLLEVBQUU7VUFBQWUsUUFBQSxHQUFFLFVBQVUsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1lBQUFpQixRQUFBLEVBQUU7VUFBTyxDQUFtQixDQUFDLEVBQUMsYUFBYTtRQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0ssRUFBRTtVQUFBZSxRQUFBLEVBQUU7UUFBd0IsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDSyxFQUFFO1VBQUFlLFFBQUEsR0FBRSxlQUFlLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBaUIsUUFBQSxFQUFFO1VBQTZCLENBQW1CLENBQUM7UUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNLLEVBQUU7VUFBQWUsUUFBQSxHQUFFLGNBQWMsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1lBQUFpQixRQUFBLEVBQUU7VUFBVSxDQUFtQixDQUFDLEVBQUMsbUJBQW1CO1FBQUEsQ0FBaUIsQ0FBQyxFQUFDLEdBQUc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNTLEVBQUU7UUFBQVcsUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBdUIsQ0FBbUIsQ0FBQyxFQUFDLFVBQVUsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFRLENBQXFCLENBQUMsRUFBQyx3Q0FBd0M7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1csQ0FBQztNQUFBUyxRQUFBLEdBQUUscUlBQXFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBaUIsUUFBQSxFQUFFO01BQVUsQ0FBbUIsQ0FBQyxFQUFDLHVTQUF1UztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1csQ0FBQztNQUFBUyxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQTRCLENBQXFCLENBQUMsRUFBQyxpREFBaUQsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFVLENBQXFCLENBQUMsRUFBQywrRUFBK0UsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFnQixDQUFxQixDQUFDLEVBQUMsc0VBQXNFLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0ssRUFBRTtRQUFBZSxRQUFBLEVBQUU7TUFBSyxDQUFpQixDQUFDLEVBQUMsMkNBQTJDLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBbUIsQ0FBcUIsQ0FBQyxFQUFDLDZFQUE2RSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUF5QixDQUFtQixDQUFDLEVBQUMsNktBQTZLO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDUSxFQUFFLElBQUUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBWCxXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNPLEVBQUU7TUFBQ2MsRUFBRSxFQUFDLGtDQUFrQztNQUFBRCxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQWtDLENBQUUsQ0FBQyxFQUFDLHFDQUFxQztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1csQ0FBQztNQUFBUyxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQXVELENBQXFCLENBQUMsRUFBQyxtRkFBbUYsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFVLENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBaUIsUUFBQSxFQUFFO01BQXNCLENBQW1CLENBQUMsRUFBQyxTQUFTLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBb0IsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1FBQUFpQixRQUFBLEVBQUU7TUFBVSxDQUFtQixDQUFDLEVBQUMsaURBQWlELGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBYSxDQUFxQixDQUFDLEVBQUMsc0ZBQXNGLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0ssRUFBRTtRQUFBZSxRQUFBLEVBQUU7TUFBSSxDQUFpQixDQUFDLEVBQUMsMERBQTBEO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDVyxDQUFDO01BQUFTLFFBQUEsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUF1QyxDQUFxQjtJQUFDLENBQWUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDVSxFQUFFO01BQUFVLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1MsRUFBRTtRQUFBVyxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQWEsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBa0IsQ0FBbUIsQ0FBQyxFQUFDLCtJQUErSSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFTLENBQW1CLENBQUMsRUFBQyxXQUFXO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDUyxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBaUIsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBYSxDQUFtQixDQUFDLEVBQUMsbUhBQW1IO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNXLENBQUM7TUFBQVMsUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFXLENBQXFCLENBQUMsRUFBQyxrQkFBa0IsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1FBQUFpQixRQUFBLEVBQUU7TUFBUSxDQUFtQixDQUFDLEVBQUMsVUFBVSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUFPLENBQW1CLENBQUMsRUFBQyw0UUFBNFEsZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDWSxNQUFNO1FBQUFRLFFBQUEsR0FBRSwrQkFBK0IsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBWSxDQUFtQixDQUFDLEVBQUMsT0FBTztNQUFBLENBQXFCLENBQUMsRUFBQywyRUFBMkU7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNRLEVBQUUsSUFBRSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFYLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ08sRUFBRTtNQUFDYyxFQUFFLEVBQUMsNENBQTRDO01BQUFELFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBNEMsQ0FBRSxDQUFDLEVBQUMsNkNBQTZDO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBeEIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDVyxDQUFDO01BQUFTLFFBQUEsR0FBRSxXQUFXLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBMkIsQ0FBcUIsQ0FBQyxFQUFDLHFQQUFxUCxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUFZLENBQW1CLENBQUMsRUFBQyxHQUFHO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDYSxFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1MsRUFBRTtRQUFBVyxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQStDLENBQXFCLENBQUMsRUFBQyxrQkFBa0IsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDSyxFQUFFO1VBQUFlLFFBQUEsRUFBRTtRQUFXLENBQWlCLENBQUMsRUFBQywrRUFBK0U7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNTLEVBQUU7UUFBQVcsUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFrQyxDQUFxQixDQUFDLEVBQUMsb09BQW9PO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDUyxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBbUQsQ0FBcUIsQ0FBQyxFQUFDLDJJQUEySSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQWtCLENBQXFCLENBQUMsRUFBQyxpREFBaUQsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDSyxFQUFFO1VBQUFlLFFBQUEsRUFBRTtRQUFnQixDQUFpQixDQUFDLEVBQUMsbUNBQW1DO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDUyxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBWSxDQUFxQixDQUFDLEVBQUMsc0hBQXNILGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBUSxRQUFBLEdBQUUsa0JBQWtCLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBaUIsUUFBQSxFQUFFO1VBQVksQ0FBbUIsQ0FBQztRQUFBLENBQW9CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBNEIsQ0FBcUIsQ0FBQyxFQUFDLHVEQUF1RDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDUSxFQUFFLElBQUUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBWCxXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNPLEVBQUU7TUFBQ2MsRUFBRSxFQUFDLGtDQUFrQztNQUFBRCxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQWtDLENBQUUsQ0FBQyxFQUFDLG9DQUFvQztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1csQ0FBQztNQUFBUyxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUFnQixDQUFtQixDQUFDLEVBQUMsY0FBYyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUFRLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBb0MsQ0FBcUIsQ0FBQyxFQUFDLHFEQUFxRCxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUFhLENBQW1CLENBQUMsRUFBQyw0QkFBNEI7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNFLFVBQVU7TUFBQWtCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1csQ0FBQztRQUFBUyxRQUFBLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0ssRUFBRTtVQUFBZSxRQUFBLEdBQUUsNEJBQTRCLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBaUIsUUFBQSxFQUFFO1VBQWlDLENBQW1CLENBQUMsRUFBQyxzRUFBc0UsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1lBQUFRLFFBQUEsRUFBRTtVQUFpQixDQUFxQixDQUFDLEVBQUMseUVBQXlFLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtZQUFBUSxRQUFBLEVBQUU7VUFBb0MsQ0FBcUIsQ0FBQyxFQUFDLG1JQUFtSSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7WUFBQWlCLFFBQUEsRUFBRTtVQUFrQixDQUFtQixDQUFDLEVBQUMsbUVBQW1FLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBaUIsUUFBQSxFQUFFO1VBQVcsQ0FBbUIsQ0FBQyxFQUFDLHNCQUFzQixlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07WUFBQVEsUUFBQSxFQUFFO1VBQTBCLENBQXFCLENBQUMsRUFBQyx5Q0FBeUMsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1lBQUFpQixRQUFBLEVBQUU7VUFBd0IsQ0FBbUIsQ0FBQyxFQUFDLHFFQUFxRTtRQUFBLENBQWlCO01BQUMsQ0FBZSxDQUFDLEVBQUMsSUFBSTtJQUFBLENBQXlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1UsRUFBRTtNQUFBVSxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNTLEVBQUU7UUFBQVcsUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDSSxHQUFHO1VBQUFnQixRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07WUFBQVEsUUFBQSxFQUFFO1VBQXVCLENBQXFCLENBQUMsRUFBQyxxREFBcUQ7UUFBQSxDQUFrQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQW1DLENBQXFCLENBQUMsRUFBQyxnSkFBZ0o7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNTLEVBQUU7UUFBQVcsUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDSSxHQUFHO1VBQUFnQixRQUFBLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtZQUFBUSxRQUFBLEVBQUU7VUFBcUQsQ0FBcUI7UUFBQyxDQUFpQixDQUFDLEVBQUMseUJBQXlCLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBcUMsQ0FBcUIsQ0FBQyxFQUFDLDBDQUEwQztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1MsRUFBRTtRQUFBVyxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNJLEdBQUc7VUFBQWdCLFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtZQUFBUSxRQUFBLEVBQUU7VUFBZ0MsQ0FBcUIsQ0FBQyxFQUFDLGVBQWU7UUFBQSxDQUFrQixDQUFDLEVBQUMsaUJBQWlCLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBNEMsQ0FBcUIsQ0FBQyxFQUFDLDBDQUEwQztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1MsRUFBRTtRQUFBVyxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQWtCLENBQXFCLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQWtCLENBQW1CLENBQUMsRUFBQyxlQUFlLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQyxFQUFDLDJDQUEyQyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQywrQkFBK0I7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNTLEVBQUU7UUFBQVcsUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUE4QixDQUFxQixDQUFDLEVBQUMsd01BQXdNO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNXLENBQUM7TUFBQVMsUUFBQSxFQUFFO0lBQTZOLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1EsRUFBRSxJQUFFLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQVgsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDTyxFQUFFO01BQUNjLEVBQUUsRUFBQyw4RUFBOEU7TUFBQUQsUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUE4RSxDQUFFLENBQUMsRUFBQyxpRkFBaUY7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF4QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNVLEVBQUU7TUFBQVUsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDUyxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBa0IsQ0FBcUIsQ0FBQyxFQUFDLGtCQUFrQixlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQyxpSUFBaUk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNTLEVBQUU7UUFBQVcsUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUEwQixDQUFxQixDQUFDLEVBQUMsdUpBQXVKO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDUyxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBNEIsQ0FBcUIsQ0FBQyxFQUFDLHNCQUFzQixlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNLLEVBQUU7VUFBQWUsUUFBQSxFQUFFO1FBQVEsQ0FBaUIsQ0FBQyxFQUFDLHFIQUFxSDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1MsRUFBRTtRQUFBVyxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQTBDLENBQXFCLENBQUMsRUFBQyxxR0FBcUc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUM7RUFBQSxDQUFFLENBQUM7QUFDN3ltQjtBQUNlLFNBQVNJLFVBQVVBLENBQUN6QixLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUU7RUFDN0MsTUFBTTtJQUFDMEIsT0FBTyxFQUFFQztFQUFTLENBQUMsR0FBRztJQUMzQixHQUFHLElBQUFaLDZCQUFrQixFQUFDLENBQUM7SUFDdkIsR0FBR2YsS0FBSyxDQUFDZ0I7RUFDWCxDQUFDO0VBQ0QsT0FBT1csU0FBUyxnQkFBRyxJQUFBN0IsV0FBQSxDQUFBeUIsR0FBQSxFQUFDSSxTQUFTO0lBQUEsR0FBSzNCLEtBQUs7SUFBQXFCLFFBQUEsZUFBRSxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDeEIsaUJBQWlCO01BQUEsR0FBS0M7SUFBSyxDQUFHO0VBQUMsQ0FBVyxDQUFDLEdBQUdELGlCQUFpQixDQUFDQyxLQUFLLENBQUM7QUFDbEg7QUFBQzRCLEVBQUEsR0FOdUJILFVBQVU7QUFPbEMsU0FBU1Asb0JBQW9CQSxDQUFDSSxFQUFFLEVBQUVPLFNBQVMsRUFBRUMsS0FBSyxFQUFFO0VBQ2xELE1BQU0sSUFBSUMsS0FBSyxDQUFDLFdBQVcsSUFBSUYsU0FBUyxHQUFHLFdBQVcsR0FBRyxRQUFRLENBQUMsR0FBRyxJQUFJLEdBQUdQLEVBQUUsR0FBRyxvRUFBb0UsSUFBSVEsS0FBSyxHQUFHLHFDQUFxQyxHQUFHQSxLQUFLLEdBQUcsd0RBQXdELEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDbFI7QUFBQyxJQUFBRixFQUFBO0FBQUFJLFlBQUEsQ0FBQUosRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}