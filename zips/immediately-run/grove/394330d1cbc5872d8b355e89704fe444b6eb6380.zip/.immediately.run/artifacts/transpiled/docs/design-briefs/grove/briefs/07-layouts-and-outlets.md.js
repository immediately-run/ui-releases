var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      blockquote: "blockquote",
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      li: "li",
      p: "p",
      strong: "strong",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "brief-07-layouts-outlets-separating-chrome-from-content",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "brief-07-layouts-outlets-separating-chrome-from-content"
      }), "Brief 07 — Layouts & outlets (separating chrome from content)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["How Grove separates ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "page layout from page content"
      }), " so entries don't each repeat\nthe nav, sidebar, footer, section hero, etc. — while the URL keeps naming the\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "actual content file"
      }), ". This is Grove's take on React Router's nested layout\nroutes / outlets, adapted to the content-is-chrome model. Assumes\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "./00-foundation.md",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "00-foundation"
        })
      }), "; relates to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "grove.md"
      }), " \"Theming & layout\"\nand the tag-driven UI section."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Two different things both once called \"layout\"."
        }), " Keep them distinct:"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
        children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "layout:"
            }), " frontmatter"]
          }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "doc"
          }), " | ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "post"
          }), " | ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "full"
          }), ") → a CSS ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "data-layout"
            }), "\nvariant"]
          }), " of a single page (its measure, whether it has a ToC rail). Per-page,\nvisual, unchanged by this brief."]
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
            children: ["A layout file (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "_layout.mdx"
            }), ") + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "<Outlet/>"
            })]
          }), " → shared ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "chrome composition"
          }), "\nwrapped ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "around"
          }), " a page (and around a whole folder of pages). This brief.\nThe per-entry override key for it is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "frame:"
            })
          }), ", chosen so it never collides\nwith ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "layout:"
          }), "."]
        }), "\n"]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "the-mechanism",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-mechanism"
      }), "The mechanism"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "<Outlet/>"
          })
        }), " is an import-free engine component. Inside a layout it marks\nwhere the page — or the next nested layout — renders. (The React Router analogue.)"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "A layout is an MDX file"
        }), " named ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "_layout.mdx"
        }), ". It arranges chrome out of the\nimport-free layout primitives (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<GroveNav/>"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<GroveSidebar/>"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<GroveFooter/>"
        }), ",\nand any author/engine component) around an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<Outlet/>"
        }), ". Because it's MDX, it's\nauthored, forked, and CSS-themed like any entry — the shell is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "content"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Association is folder convention, nested up the namespace."
        }), " A ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "_layout.mdx"
        }), "\nin a directory wraps every entry in that subtree, and directories nest:\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "content/_layout.mdx"
        }), " (the site shell) wraps ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "content/people/_layout.mdx"
        }), " (a\nsection) wraps the profile page. That chain ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "is"
        }), " the outlet nesting."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The URL never sees it."
        }), " Routing still targets the leaf content file\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "/content/people/ada-lovelace.mdx"
        }), "); the engine resolves the layout chain\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "around"
        }), " it at render time. Layout files are ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "_"
        }), "-prefixed, so they're excluded\nfrom routing, nav, the sidebar tree, search, backlinks, and every index —\nthey're structure, never entries."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "overriding-the-convention-frame",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "overriding-the-convention-frame"
      }), "Overriding the convention — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "frame:"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Frontmatter on an entry overrides folder convention:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "frame: none"
        }), " (or ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "frame: false"
        }), ") → render the page ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "bare"
        }), " (no chrome) — for a\nlanding/portal page that supplies its own frame."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "frame: <slug>"
        }), " → wrap with exactly that one layout instead of the inherited chain."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["A ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "_layout.mdx"
        }), " whose own frontmatter sets ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "frame: none"
        }), " becomes a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "new root"
        }), " —\nlayers above it are dropped (a section that deliberately escapes the site shell)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "the-enginecontent-seam-whats-not-content",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-enginecontent-seam-whats-not-content"
      }), "The engine/content seam (what's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "not"
      }), " content)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "\"Shell as content\" stops at the visible arrangement. The invisible scaffolding\nstays in the engine because MDX can't own it:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["the outer ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".grove-root"
        }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".device__scroll"
        }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".grove-shell"
        }), " wrappers and the\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "data-theme"
        }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "data-vw"
        }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "data-nav"
        }), " attributes every CSS rule keys off;"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["the shell state (theme, appearance, search/drawer/menu open) — held in\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "GroveShellContext"
        }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "read"
        }), " by the chrome components wherever a layout places\nthem;"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: "the global overlays (search, drawer, the Grove agent)."
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["So a layout composes and places the chrome; the engine provides the themed\ncontainer, the state, and the overlays. Delete every ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "_layout.mdx"
      }), " and the engine\nfalls back to a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "built-in default shell"
      }), " that is the identical arrangement — so a\nbare folder of ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: ".mdx"
      }), " is still a fully-chromed site (value 3)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "reference-implementation-in-this-repo",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "reference-implementation-in-this-repo"
      }), "Reference implementation (in this repo)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "content/_layout.mdx"
        }), " — the site shell as content: `", " ", "\n", "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "content/people/_layout.mdx"
        }), " — a nested section: a shared hero + a \"more people\"\nrail (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<ChildPages/>"
        }), ") around ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<Outlet/>"
        }), ", so ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "no profile carries that header"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".grove-section*"
        }), " classes in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "GroveApp.css"
        }), " — the section-layout styling, themeable\nvia the same token/class contract as everything else (brief 00)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "deliverable-design-notes",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "deliverable-design-notes"
      }), "Deliverable / design notes"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Design the section-layout shapes (hero band, section sub-nav, section footer) so a\nfolder of entries reads as a coherent sub-site while each page's own ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "data-layout"
      }), "\nstill governs its reading column. Show a section layout at mobile + desktop and its\nempty state (a section with one entry → the \"more\" rail hides). Restrained motion,\nhairline borders, tokens only — like the rest of Grove."]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/design-briefs/grove/briefs/07-layouts-and-outlets.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiYmxvY2txdW90ZSIsImNvZGUiLCJlbSIsImgxIiwiaDIiLCJsaSIsInAiLCJzdHJvbmciLCJ1bCIsIl9wcm92aWRlQ29tcG9uZW50cyIsImNvbXBvbmVudHMiLCJIZWFkaW5nQW5jaG9yIiwiX21pc3NpbmdNZHhSZWZlcmVuY2UiLCJqc3hzIiwiRnJhZ21lbnQiLCJjaGlsZHJlbiIsImlkIiwianN4IiwiaHJlZiIsIk1EWENvbnRlbnQiLCJ3cmFwcGVyIiwiTURYTGF5b3V0IiwiX2MiLCJjb21wb25lbnQiLCJwbGFjZSIsIkVycm9yIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiMDctbGF5b3V0cy1hbmQtb3V0bGV0cy5tZCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKkBqc3hSdW50aW1lIGF1dG9tYXRpYyovXG4vKkBqc3hJbXBvcnRTb3VyY2UgcmVhY3QqL1xuaW1wb3J0IHt1c2VNRFhDb21wb25lbnRzIGFzIF9wcm92aWRlQ29tcG9uZW50c30gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrL01EWFByb3ZpZGVyXCI7XG5mdW5jdGlvbiBfY3JlYXRlTWR4Q29udGVudChwcm9wcykge1xuICBjb25zdCBfY29tcG9uZW50cyA9IHtcbiAgICBhOiBcImFcIixcbiAgICBibG9ja3F1b3RlOiBcImJsb2NrcXVvdGVcIixcbiAgICBjb2RlOiBcImNvZGVcIixcbiAgICBlbTogXCJlbVwiLFxuICAgIGgxOiBcImgxXCIsXG4gICAgaDI6IFwiaDJcIixcbiAgICBsaTogXCJsaVwiLFxuICAgIHA6IFwicFwiLFxuICAgIHN0cm9uZzogXCJzdHJvbmdcIixcbiAgICB1bDogXCJ1bFwiLFxuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfSwge0hlYWRpbmdBbmNob3J9ID0gX2NvbXBvbmVudHM7XG4gIGlmICghSGVhZGluZ0FuY2hvcikgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJIZWFkaW5nQW5jaG9yXCIsIHRydWUpO1xuICByZXR1cm4gPD48X2NvbXBvbmVudHMuaDEgaWQ9XCJicmllZi0wNy1sYXlvdXRzLW91dGxldHMtc2VwYXJhdGluZy1jaHJvbWUtZnJvbS1jb250ZW50XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJicmllZi0wNy1sYXlvdXRzLW91dGxldHMtc2VwYXJhdGluZy1jaHJvbWUtZnJvbS1jb250ZW50XCIgLz57XCJCcmllZiAwNyDigJQgTGF5b3V0cyAmIG91dGxldHMgKHNlcGFyYXRpbmcgY2hyb21lIGZyb20gY29udGVudClcIn08L19jb21wb25lbnRzLmgxPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkhvdyBHcm92ZSBzZXBhcmF0ZXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJwYWdlIGxheW91dCBmcm9tIHBhZ2UgY29udGVudFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBzbyBlbnRyaWVzIGRvbid0IGVhY2ggcmVwZWF0XFxudGhlIG5hdiwgc2lkZWJhciwgZm9vdGVyLCBzZWN0aW9uIGhlcm8sIGV0Yy4g4oCUIHdoaWxlIHRoZSBVUkwga2VlcHMgbmFtaW5nIHRoZVxcblwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiYWN0dWFsIGNvbnRlbnQgZmlsZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIi4gVGhpcyBpcyBHcm92ZSdzIHRha2Ugb24gUmVhY3QgUm91dGVyJ3MgbmVzdGVkIGxheW91dFxcbnJvdXRlcyAvIG91dGxldHMsIGFkYXB0ZWQgdG8gdGhlIGNvbnRlbnQtaXMtY2hyb21lIG1vZGVsLiBBc3N1bWVzXFxuXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cIi4vMDAtZm91bmRhdGlvbi5tZFwiPjxfY29tcG9uZW50cy5jb2RlPntcIjAwLWZvdW5kYXRpb25cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5hPntcIjsgcmVsYXRlcyB0byBcIn08X2NvbXBvbmVudHMuY29kZT57XCJncm92ZS5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgXFxcIlRoZW1pbmcgJiBsYXlvdXRcXFwiXFxuYW5kIHRoZSB0YWctZHJpdmVuIFVJIHNlY3Rpb24uXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVHdvIGRpZmZlcmVudCB0aGluZ3MgYm90aCBvbmNlIGNhbGxlZCBcXFwibGF5b3V0XFxcIi5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgS2VlcCB0aGVtIGRpc3RpbmN0OlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+PF9jb21wb25lbnRzLmNvZGU+e1wibGF5b3V0OlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZnJvbnRtYXR0ZXJcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcImRvY1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgfCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJwb3N0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB8IFwifTxfY29tcG9uZW50cy5jb2RlPntcImZ1bGxcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSDihpIgYSBDU1MgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz48X2NvbXBvbmVudHMuY29kZT57XCJkYXRhLWxheW91dFwifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG52YXJpYW50XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIG9mIGEgc2luZ2xlIHBhZ2UgKGl0cyBtZWFzdXJlLCB3aGV0aGVyIGl0IGhhcyBhIFRvQyByYWlsKS4gUGVyLXBhZ2UsXFxudmlzdWFsLCB1bmNoYW5nZWQgYnkgdGhpcyBicmllZi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkEgbGF5b3V0IGZpbGUgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIl9sYXlvdXQubWR4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikgKyBcIn08X2NvbXBvbmVudHMuY29kZT57XCI8T3V0bGV0Lz5cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKGkiBzaGFyZWQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJjaHJvbWUgY29tcG9zaXRpb25cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCJcXG53cmFwcGVkIFwifTxfY29tcG9uZW50cy5lbT57XCJhcm91bmRcIn08L19jb21wb25lbnRzLmVtPntcIiBhIHBhZ2UgKGFuZCBhcm91bmQgYSB3aG9sZSBmb2xkZXIgb2YgcGFnZXMpLiBUaGlzIGJyaWVmLlxcblRoZSBwZXItZW50cnkgb3ZlcnJpZGUga2V5IGZvciBpdCBpcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPjxfY29tcG9uZW50cy5jb2RlPntcImZyYW1lOlwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnN0cm9uZz57XCIsIGNob3NlbiBzbyBpdCBuZXZlciBjb2xsaWRlc1xcbndpdGggXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibGF5b3V0OlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTwvX2NvbXBvbmVudHMuYmxvY2txdW90ZT57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJ0aGUtbWVjaGFuaXNtXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJ0aGUtbWVjaGFuaXNtXCIgLz57XCJUaGUgbWVjaGFuaXNtXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+PF9jb21wb25lbnRzLmNvZGU+e1wiPE91dGxldC8+XCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBpcyBhbiBpbXBvcnQtZnJlZSBlbmdpbmUgY29tcG9uZW50LiBJbnNpZGUgYSBsYXlvdXQgaXQgbWFya3NcXG53aGVyZSB0aGUgcGFnZSDigJQgb3IgdGhlIG5leHQgbmVzdGVkIGxheW91dCDigJQgcmVuZGVycy4gKFRoZSBSZWFjdCBSb3V0ZXIgYW5hbG9ndWUuKVwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQSBsYXlvdXQgaXMgYW4gTURYIGZpbGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgbmFtZWQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiX2xheW91dC5tZHhcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLiBJdCBhcnJhbmdlcyBjaHJvbWUgb3V0IG9mIHRoZVxcbmltcG9ydC1mcmVlIGxheW91dCBwcmltaXRpdmVzIChcIn08X2NvbXBvbmVudHMuY29kZT57XCI8R3JvdmVOYXYvPlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjxHcm92ZVNpZGViYXIvPlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjxHcm92ZUZvb3Rlci8+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIixcXG5hbmQgYW55IGF1dGhvci9lbmdpbmUgY29tcG9uZW50KSBhcm91bmQgYW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiPE91dGxldC8+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi4gQmVjYXVzZSBpdCdzIE1EWCwgaXQnc1xcbmF1dGhvcmVkLCBmb3JrZWQsIGFuZCBDU1MtdGhlbWVkIGxpa2UgYW55IGVudHJ5IOKAlCB0aGUgc2hlbGwgaXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJjb250ZW50XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQXNzb2NpYXRpb24gaXMgZm9sZGVyIGNvbnZlbnRpb24sIG5lc3RlZCB1cCB0aGUgbmFtZXNwYWNlLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBBIFwifTxfY29tcG9uZW50cy5jb2RlPntcIl9sYXlvdXQubWR4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIlxcbmluIGEgZGlyZWN0b3J5IHdyYXBzIGV2ZXJ5IGVudHJ5IGluIHRoYXQgc3VidHJlZSwgYW5kIGRpcmVjdG9yaWVzIG5lc3Q6XFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY29udGVudC9fbGF5b3V0Lm1keFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKHRoZSBzaXRlIHNoZWxsKSB3cmFwcyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjb250ZW50L3Blb3BsZS9fbGF5b3V0Lm1keFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKGFcXG5zZWN0aW9uKSB3cmFwcyB0aGUgcHJvZmlsZSBwYWdlLiBUaGF0IGNoYWluIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiaXNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdGhlIG91dGxldCBuZXN0aW5nLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVGhlIFVSTCBuZXZlciBzZWVzIGl0LlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBSb3V0aW5nIHN0aWxsIHRhcmdldHMgdGhlIGxlYWYgY29udGVudCBmaWxlXFxuKFwifTxfY29tcG9uZW50cy5jb2RlPntcIi9jb250ZW50L3Blb3BsZS9hZGEtbG92ZWxhY2UubWR4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIik7IHRoZSBlbmdpbmUgcmVzb2x2ZXMgdGhlIGxheW91dCBjaGFpblxcblwifTxfY29tcG9uZW50cy5lbT57XCJhcm91bmRcIn08L19jb21wb25lbnRzLmVtPntcIiBpdCBhdCByZW5kZXIgdGltZS4gTGF5b3V0IGZpbGVzIGFyZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJfXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi1wcmVmaXhlZCwgc28gdGhleSdyZSBleGNsdWRlZFxcbmZyb20gcm91dGluZywgbmF2LCB0aGUgc2lkZWJhciB0cmVlLCBzZWFyY2gsIGJhY2tsaW5rcywgYW5kIGV2ZXJ5IGluZGV4IOKAlFxcbnRoZXkncmUgc3RydWN0dXJlLCBuZXZlciBlbnRyaWVzLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJvdmVycmlkaW5nLXRoZS1jb252ZW50aW9uLWZyYW1lXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJvdmVycmlkaW5nLXRoZS1jb252ZW50aW9uLWZyYW1lXCIgLz57XCJPdmVycmlkaW5nIHRoZSBjb252ZW50aW9uIOKAlCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmcmFtZTpcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJGcm9udG1hdHRlciBvbiBhbiBlbnRyeSBvdmVycmlkZXMgZm9sZGVyIGNvbnZlbnRpb246XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLmNvZGU+e1wiZnJhbWU6IG5vbmVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChvciBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmcmFtZTogZmFsc2VcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSDihpIgcmVuZGVyIHRoZSBwYWdlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiYmFyZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAobm8gY2hyb21lKSDigJQgZm9yIGFcXG5sYW5kaW5nL3BvcnRhbCBwYWdlIHRoYXQgc3VwcGxpZXMgaXRzIG93biBmcmFtZS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuY29kZT57XCJmcmFtZTogPHNsdWc+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDihpIgd3JhcCB3aXRoIGV4YWN0bHkgdGhhdCBvbmUgbGF5b3V0IGluc3RlYWQgb2YgdGhlIGluaGVyaXRlZCBjaGFpbi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJBIFwifTxfY29tcG9uZW50cy5jb2RlPntcIl9sYXlvdXQubWR4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB3aG9zZSBvd24gZnJvbnRtYXR0ZXIgc2V0cyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmcmFtZTogbm9uZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYmVjb21lcyBhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibmV3IHJvb3RcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUXFxubGF5ZXJzIGFib3ZlIGl0IGFyZSBkcm9wcGVkIChhIHNlY3Rpb24gdGhhdCBkZWxpYmVyYXRlbHkgZXNjYXBlcyB0aGUgc2l0ZSBzaGVsbCkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInRoZS1lbmdpbmVjb250ZW50LXNlYW0td2hhdHMtbm90LWNvbnRlbnRcIj48SGVhZGluZ0FuY2hvciBpZD1cInRoZS1lbmdpbmVjb250ZW50LXNlYW0td2hhdHMtbm90LWNvbnRlbnRcIiAvPntcIlRoZSBlbmdpbmUvY29udGVudCBzZWFtICh3aGF0J3MgXCJ9PF9jb21wb25lbnRzLmVtPntcIm5vdFwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGNvbnRlbnQpXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJcXFwiU2hlbGwgYXMgY29udGVudFxcXCIgc3RvcHMgYXQgdGhlIHZpc2libGUgYXJyYW5nZW1lbnQuIFRoZSBpbnZpc2libGUgc2NhZmZvbGRpbmdcXG5zdGF5cyBpbiB0aGUgZW5naW5lIGJlY2F1c2UgTURYIGNhbid0IG93biBpdDpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJ0aGUgb3V0ZXIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLmdyb3ZlLXJvb3RcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIC8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLmRldmljZV9fc2Nyb2xsXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAvIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi5ncm92ZS1zaGVsbFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgd3JhcHBlcnMgYW5kIHRoZVxcblwifTxfY29tcG9uZW50cy5jb2RlPntcImRhdGEtdGhlbWVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIC8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZGF0YS12d1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgLyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJkYXRhLW5hdlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYXR0cmlidXRlcyBldmVyeSBDU1MgcnVsZSBrZXlzIG9mZjtcIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJ0aGUgc2hlbGwgc3RhdGUgKHRoZW1lLCBhcHBlYXJhbmNlLCBzZWFyY2gvZHJhd2VyL21lbnUgb3Blbikg4oCUIGhlbGQgaW5cXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJHcm92ZVNoZWxsQ29udGV4dFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYW5kIFwifTxfY29tcG9uZW50cy5lbT57XCJyZWFkXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgYnkgdGhlIGNocm9tZSBjb21wb25lbnRzIHdoZXJldmVyIGEgbGF5b3V0IHBsYWNlc1xcbnRoZW07XCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1widGhlIGdsb2JhbCBvdmVybGF5cyAoc2VhcmNoLCBkcmF3ZXIsIHRoZSBHcm92ZSBhZ2VudCkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlNvIGEgbGF5b3V0IGNvbXBvc2VzIGFuZCBwbGFjZXMgdGhlIGNocm9tZTsgdGhlIGVuZ2luZSBwcm92aWRlcyB0aGUgdGhlbWVkXFxuY29udGFpbmVyLCB0aGUgc3RhdGUsIGFuZCB0aGUgb3ZlcmxheXMuIERlbGV0ZSBldmVyeSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJfbGF5b3V0Lm1keFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYW5kIHRoZSBlbmdpbmVcXG5mYWxscyBiYWNrIHRvIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJidWlsdC1pbiBkZWZhdWx0IHNoZWxsXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHRoYXQgaXMgdGhlIGlkZW50aWNhbCBhcnJhbmdlbWVudCDigJQgc28gYVxcbmJhcmUgZm9sZGVyIG9mIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi5tZHhcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGlzIHN0aWxsIGEgZnVsbHktY2hyb21lZCBzaXRlICh2YWx1ZSAzKS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwicmVmZXJlbmNlLWltcGxlbWVudGF0aW9uLWluLXRoaXMtcmVwb1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwicmVmZXJlbmNlLWltcGxlbWVudGF0aW9uLWluLXRoaXMtcmVwb1wiIC8+e1wiUmVmZXJlbmNlIGltcGxlbWVudGF0aW9uIChpbiB0aGlzIHJlcG8pXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5jb2RlPntcImNvbnRlbnQvX2xheW91dC5tZHhcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCB0aGUgc2l0ZSBzaGVsbCBhcyBjb250ZW50OiBgXCJ9e1wiIFwifXtcIlxcblwifXtcIlxcblwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5jb2RlPntcImNvbnRlbnQvcGVvcGxlL19sYXlvdXQubWR4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgYSBuZXN0ZWQgc2VjdGlvbjogYSBzaGFyZWQgaGVybyArIGEgXFxcIm1vcmUgcGVvcGxlXFxcIlxcbnJhaWwgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIjxDaGlsZFBhZ2VzLz5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSBhcm91bmQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiPE91dGxldC8+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgc28gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJubyBwcm9maWxlIGNhcnJpZXMgdGhhdCBoZWFkZXJcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLmNvZGU+e1wiLmdyb3ZlLXNlY3Rpb24qXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjbGFzc2VzIGluIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkdyb3ZlQXBwLmNzc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIHRoZSBzZWN0aW9uLWxheW91dCBzdHlsaW5nLCB0aGVtZWFibGVcXG52aWEgdGhlIHNhbWUgdG9rZW4vY2xhc3MgY29udHJhY3QgYXMgZXZlcnl0aGluZyBlbHNlIChicmllZiAwMCkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cImRlbGl2ZXJhYmxlLWRlc2lnbi1ub3Rlc1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwiZGVsaXZlcmFibGUtZGVzaWduLW5vdGVzXCIgLz57XCJEZWxpdmVyYWJsZSAvIGRlc2lnbiBub3Rlc1wifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiRGVzaWduIHRoZSBzZWN0aW9uLWxheW91dCBzaGFwZXMgKGhlcm8gYmFuZCwgc2VjdGlvbiBzdWItbmF2LCBzZWN0aW9uIGZvb3Rlcikgc28gYVxcbmZvbGRlciBvZiBlbnRyaWVzIHJlYWRzIGFzIGEgY29oZXJlbnQgc3ViLXNpdGUgd2hpbGUgZWFjaCBwYWdlJ3Mgb3duIFwifTxfY29tcG9uZW50cy5jb2RlPntcImRhdGEtbGF5b3V0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIlxcbnN0aWxsIGdvdmVybnMgaXRzIHJlYWRpbmcgY29sdW1uLiBTaG93IGEgc2VjdGlvbiBsYXlvdXQgYXQgbW9iaWxlICsgZGVza3RvcCBhbmQgaXRzXFxuZW1wdHkgc3RhdGUgKGEgc2VjdGlvbiB3aXRoIG9uZSBlbnRyeSDihpIgdGhlIFxcXCJtb3JlXFxcIiByYWlsIGhpZGVzKS4gUmVzdHJhaW5lZCBtb3Rpb24sXFxuaGFpcmxpbmUgYm9yZGVycywgdG9rZW5zIG9ubHkg4oCUIGxpa2UgdGhlIHJlc3Qgb2YgR3JvdmUuXCJ9PC9fY29tcG9uZW50cy5wPjwvPjtcbn1cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE1EWENvbnRlbnQocHJvcHMgPSB7fSkge1xuICBjb25zdCB7d3JhcHBlcjogTURYTGF5b3V0fSA9IHtcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH07XG4gIHJldHVybiBNRFhMYXlvdXQgPyA8TURYTGF5b3V0IHsuLi5wcm9wc30+PF9jcmVhdGVNZHhDb250ZW50IHsuLi5wcm9wc30gLz48L01EWExheW91dD4gOiBfY3JlYXRlTWR4Q29udGVudChwcm9wcyk7XG59XG5mdW5jdGlvbiBfbWlzc2luZ01keFJlZmVyZW5jZShpZCwgY29tcG9uZW50LCBwbGFjZSkge1xuICB0aHJvdyBuZXcgRXJyb3IoXCJFeHBlY3RlZCBcIiArIChjb21wb25lbnQgPyBcImNvbXBvbmVudFwiIDogXCJvYmplY3RcIikgKyBcIiBgXCIgKyBpZCArIFwiYCB0byBiZSBkZWZpbmVkOiB5b3UgbGlrZWx5IGZvcmdvdCB0byBpbXBvcnQsIHBhc3MsIG9yIHByb3ZpZGUgaXQuXCIgKyAocGxhY2UgPyBcIlxcbkl04oCZcyByZWZlcmVuY2VkIGluIHlvdXIgY29kZSBhdCBgXCIgKyBwbGFjZSArIFwiYCBpbiBgL2FwcC9kb2NzL2Rlc2lnbi1icmllZnMvZ3JvdmUvYnJpZWZzLzA3LWxheW91dHMtYW5kLW91dGxldHMubWRgXCIgOiBcIlwiKSk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUVBLElBQUFBLFlBQUEsR0FBQUMsT0FBQTtBQUF3RixJQUFBQyxXQUFBLEdBQUFELE9BQUE7QUFGeEY7QUFDQTs7QUFFQSxTQUFTRSxpQkFBaUJBLENBQUNDLEtBQUssRUFBRTtFQUNoQyxNQUFNQyxXQUFXLEdBQUc7TUFDbEJDLENBQUMsRUFBRSxHQUFHO01BQ05DLFVBQVUsRUFBRSxZQUFZO01BQ3hCQyxJQUFJLEVBQUUsTUFBTTtNQUNaQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxDQUFDLEVBQUUsR0FBRztNQUNOQyxNQUFNLEVBQUUsUUFBUTtNQUNoQkMsRUFBRSxFQUFFLElBQUk7TUFDUixHQUFHLElBQUFDLDZCQUFrQixFQUFDLENBQUM7TUFDdkIsR0FBR1osS0FBSyxDQUFDYTtJQUNYLENBQUM7SUFBRTtNQUFDQztJQUFhLENBQUMsR0FBR2IsV0FBVztFQUNoQyxJQUFJLENBQUNhLGFBQWEsRUFBRUMsb0JBQW9CLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQztFQUMvRCxvQkFBTyxJQUFBakIsV0FBQSxDQUFBa0IsSUFBQSxFQUFBbEIsV0FBQSxDQUFBbUIsUUFBQTtJQUFBQyxRQUFBLGdCQUFFLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDYSxFQUFFLEVBQUMseURBQXlEO01BQUFELFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBeUQsQ0FBRSxDQUFDLEVBQUMsK0RBQStEO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNRLENBQUM7TUFBQVMsUUFBQSxHQUFFLHNCQUFzQixlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQStCLENBQXFCLENBQUMsRUFBQyxnSEFBZ0gsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDUyxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFxQixDQUFxQixDQUFDLEVBQUMsNkhBQTZILGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsQ0FBQztRQUFDbUIsSUFBSSxFQUFDLG9CQUFvQjtRQUFBSCxRQUFBLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0csSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBZSxDQUFtQjtNQUFDLENBQWUsQ0FBQyxFQUFDLGVBQWUsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRyxJQUFJO1FBQUFjLFFBQUEsRUFBRTtNQUFVLENBQW1CLENBQUMsRUFBQyx1REFBdUQ7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ0UsVUFBVTtNQUFBZSxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ1EsQ0FBQztRQUFBUyxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQW1ELENBQXFCLENBQUMsRUFBQyxzQkFBc0I7TUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ1UsRUFBRTtRQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ08sRUFBRTtVQUFBVSxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ1MsTUFBTTtZQUFBUSxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNHLElBQUk7Y0FBQWMsUUFBQSxFQUFFO1lBQVMsQ0FBbUIsQ0FBQyxFQUFDLGNBQWM7VUFBQSxDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNHLElBQUk7WUFBQWMsUUFBQSxFQUFFO1VBQUssQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRyxJQUFJO1lBQUFjLFFBQUEsRUFBRTtVQUFNLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0csSUFBSTtZQUFBYyxRQUFBLEVBQUU7VUFBTSxDQUFtQixDQUFDLEVBQUMsWUFBWSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ1MsTUFBTTtZQUFBUSxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNHLElBQUk7Y0FBQWMsUUFBQSxFQUFFO1lBQWEsQ0FBbUIsQ0FBQyxFQUFDLFdBQVc7VUFBQSxDQUFxQixDQUFDLEVBQUMseUdBQXlHO1FBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNPLEVBQUU7VUFBQVUsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNTLE1BQU07WUFBQVEsUUFBQSxHQUFFLGlCQUFpQixlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNHLElBQUk7Y0FBQWMsUUFBQSxFQUFFO1lBQWEsQ0FBbUIsQ0FBQyxFQUFDLE1BQU0sZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRyxJQUFJO2NBQUFjLFFBQUEsRUFBRTtZQUFXLENBQW1CLENBQUM7VUFBQSxDQUFvQixDQUFDLEVBQUMsWUFBWSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07WUFBQVEsUUFBQSxFQUFFO1VBQW9CLENBQXFCLENBQUMsRUFBQyxZQUFZLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0ksRUFBRTtZQUFBYSxRQUFBLEVBQUU7VUFBUSxDQUFpQixDQUFDLEVBQUMsa0dBQWtHLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtZQUFBUSxRQUFBLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0csSUFBSTtjQUFBYyxRQUFBLEVBQUU7WUFBUSxDQUFtQjtVQUFDLENBQW9CLENBQUMsRUFBQyxzQ0FBc0MsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRyxJQUFJO1lBQUFjLFFBQUEsRUFBRTtVQUFTLENBQW1CLENBQUMsRUFBQyxHQUFHO1FBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQXlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTSxFQUFFO01BQUNZLEVBQUUsRUFBQyxlQUFlO01BQUFELFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBZSxDQUFFLENBQUMsRUFBQyxlQUFlO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNVLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNPLEVBQUU7UUFBQVUsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDUyxNQUFNO1VBQUFRLFFBQUEsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRyxJQUFJO1lBQUFjLFFBQUEsRUFBRTtVQUFXLENBQW1CO1FBQUMsQ0FBb0IsQ0FBQyxFQUFDLG1KQUFtSjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTyxFQUFFO1FBQUFVLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBeUIsQ0FBcUIsQ0FBQyxFQUFDLFNBQVMsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRyxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyxrRUFBa0UsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRyxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0csSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBaUIsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRyxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUFnQixDQUFtQixDQUFDLEVBQUMsZ0RBQWdELGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0csSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsMkZBQTJGLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBUyxDQUFxQixDQUFDLEVBQUMsR0FBRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTyxFQUFFO1FBQUFVLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBNEQsQ0FBcUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRyxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyw2RUFBNkUsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRyxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUFxQixDQUFtQixDQUFDLEVBQUMsMEJBQTBCLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0csSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBNEIsQ0FBbUIsQ0FBQyxFQUFDLG1EQUFtRCxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQUksQ0FBcUIsQ0FBQyxFQUFDLHNCQUFzQjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTyxFQUFFO1FBQUFVLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBd0IsQ0FBcUIsQ0FBQyxFQUFDLGlEQUFpRCxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNHLElBQUk7VUFBQWMsUUFBQSxFQUFFO1FBQWtDLENBQW1CLENBQUMsRUFBQywyQ0FBMkMsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDSSxFQUFFO1VBQUFhLFFBQUEsRUFBRTtRQUFRLENBQWlCLENBQUMsRUFBQyx1Q0FBdUMsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRyxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUFHLENBQW1CLENBQUMsRUFBQyw4SUFBOEk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTSxFQUFFO01BQUNZLEVBQUUsRUFBQyxpQ0FBaUM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFpQyxDQUFFLENBQUMsRUFBQyw4QkFBOEIsZUFBQyxJQUFBckIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRyxJQUFJO1FBQUFjLFFBQUEsRUFBRTtNQUFRLENBQW1CLENBQUM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNRLENBQUM7TUFBQVMsUUFBQSxFQUFFO0lBQXNELENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDVSxFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTyxFQUFFO1FBQUFVLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0csSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBYSxDQUFtQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNHLElBQUk7VUFBQWMsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLHNCQUFzQixlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQU0sQ0FBcUIsQ0FBQyxFQUFDLHdFQUF3RTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTyxFQUFFO1FBQUFVLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0csSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBZSxDQUFtQixDQUFDLEVBQUMsc0VBQXNFO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNPLEVBQUU7UUFBQVUsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRyxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyw4QkFBOEIsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRyxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyxhQUFhLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBVSxDQUFxQixDQUFDLEVBQUMsdUZBQXVGO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ00sRUFBRTtNQUFDWSxFQUFFLEVBQUMsMENBQTBDO01BQUFELFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBMEMsQ0FBRSxDQUFDLEVBQUMsa0NBQWtDLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0ksRUFBRTtRQUFBYSxRQUFBLEVBQUU7TUFBSyxDQUFpQixDQUFDLEVBQUMsV0FBVztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1EsQ0FBQztNQUFBUyxRQUFBLEVBQUU7SUFBaUksQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNVLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNPLEVBQUU7UUFBQVUsUUFBQSxHQUFFLFlBQVksZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRyxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0csSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBaUIsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRyxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUMsRUFBQyxxQkFBcUIsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRyxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUFZLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0csSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBUyxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNHLElBQUk7VUFBQWMsUUFBQSxFQUFFO1FBQVUsQ0FBbUIsQ0FBQyxFQUFDLHNDQUFzQztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTyxFQUFFO1FBQUFVLFFBQUEsR0FBRSwwRUFBMEUsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRyxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUFtQixDQUFtQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNJLEVBQUU7VUFBQWEsUUFBQSxFQUFFO1FBQU0sQ0FBaUIsQ0FBQyxFQUFDLDJEQUEyRDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ08sRUFBRTtRQUFBVSxRQUFBLEVBQUU7TUFBd0QsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ1EsQ0FBQztNQUFBUyxRQUFBLEdBQUUsbUlBQW1JLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0csSUFBSTtRQUFBYyxRQUFBLEVBQUU7TUFBYSxDQUFtQixDQUFDLEVBQUMsbUNBQW1DLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBd0IsQ0FBcUIsQ0FBQyxFQUFDLDREQUE0RCxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNHLElBQUk7UUFBQWMsUUFBQSxFQUFFO01BQU0sQ0FBbUIsQ0FBQyxFQUFDLDJDQUEyQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTSxFQUFFO01BQUNZLEVBQUUsRUFBQyx1Q0FBdUM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUF1QyxDQUFFLENBQUMsRUFBQyx5Q0FBeUM7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ1UsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ08sRUFBRTtRQUFBVSxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNHLElBQUk7VUFBQWMsUUFBQSxFQUFFO1FBQXFCLENBQW1CLENBQUMsRUFBQyxpQ0FBaUMsRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFLElBQUk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ08sRUFBRTtRQUFBVSxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNHLElBQUk7VUFBQWMsUUFBQSxFQUFFO1FBQTRCLENBQW1CLENBQUMsRUFBQyxnRUFBZ0UsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRyxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUFlLENBQW1CLENBQUMsRUFBQyxXQUFXLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0csSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQWdDLENBQXFCLENBQUMsRUFBQyxHQUFHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNPLEVBQUU7UUFBQVUsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRyxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUFpQixDQUFtQixDQUFDLEVBQUMsY0FBYyxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNHLElBQUk7VUFBQWMsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLDRHQUE0RztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7TUFBQ1ksRUFBRSxFQUFDLDBCQUEwQjtNQUFBRCxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQTBCLENBQUUsQ0FBQyxFQUFDLDRCQUE0QjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDUSxDQUFDO01BQUFTLFFBQUEsR0FBRSwySkFBMkosZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRyxJQUFJO1FBQUFjLFFBQUEsRUFBRTtNQUFhLENBQW1CLENBQUMsRUFBQyxzT0FBc087SUFBQSxDQUFnQixDQUFDO0VBQUEsQ0FBRSxDQUFDO0FBQ2w1UjtBQUNlLFNBQVNJLFVBQVVBLENBQUN0QixLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUU7RUFDN0MsTUFBTTtJQUFDdUIsT0FBTyxFQUFFQztFQUFTLENBQUMsR0FBRztJQUMzQixHQUFHLElBQUFaLDZCQUFrQixFQUFDLENBQUM7SUFDdkIsR0FBR1osS0FBSyxDQUFDYTtFQUNYLENBQUM7RUFDRCxPQUFPVyxTQUFTLGdCQUFHLElBQUExQixXQUFBLENBQUFzQixHQUFBLEVBQUNJLFNBQVM7SUFBQSxHQUFLeEIsS0FBSztJQUFBa0IsUUFBQSxlQUFFLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNyQixpQkFBaUI7TUFBQSxHQUFLQztJQUFLLENBQUc7RUFBQyxDQUFXLENBQUMsR0FBR0QsaUJBQWlCLENBQUNDLEtBQUssQ0FBQztBQUNsSDtBQUFDeUIsRUFBQSxHQU51QkgsVUFBVTtBQU9sQyxTQUFTUCxvQkFBb0JBLENBQUNJLEVBQUUsRUFBRU8sU0FBUyxFQUFFQyxLQUFLLEVBQUU7RUFDbEQsTUFBTSxJQUFJQyxLQUFLLENBQUMsV0FBVyxJQUFJRixTQUFTLEdBQUcsV0FBVyxHQUFHLFFBQVEsQ0FBQyxHQUFHLElBQUksR0FBR1AsRUFBRSxHQUFHLG9FQUFvRSxJQUFJUSxLQUFLLEdBQUcscUNBQXFDLEdBQUdBLEtBQUssR0FBRyx1RUFBdUUsR0FBRyxFQUFFLENBQUMsQ0FBQztBQUNqUztBQUFDLElBQUFGLEVBQUE7QUFBQUksWUFBQSxDQUFBSixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}