var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      input: "input",
      li: "li",
      ol: "ol",
      p: "p",
      pre: "pre",
      strong: "strong",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "creating-a-new-grove-component",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "creating-a-new-grove-component"
      }), "Creating a new Grove component"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["How to add a new ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "import-free MDX component"
      }), " to this wiki — a piece of UI\nvocabulary that any ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: ".mdx"
      }), " entry can use with no import line, like ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "<Callout>"
      }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "<DocList>"
      }), ", or ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "<Toc>"
      }), ". We build a real one end to end: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<Quote>"
        })
      }), ", a\npull-quote that can link back to the entry it came from."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["This is written so a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "human or a coding agent"
      }), " can follow it verbatim. Every\nstep names the exact file and the convention behind it."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "what-a-component-means-in-grove",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "what-a-component-means-in-grove"
      }), "What \"a component\" means in Grove"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Grove renders each entry's MDX against a fixed component vocabulary registered in\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "../../src/mdxComponents.ts",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/mdxComponents.ts"
        })
      }), " (the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "GROVE_MDX"
      }), " map). Adding\na component means: write a React component, give it styles, and register it in\nthat map. After that, authors write ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "<Quote>…</Quote>"
      }), " in any entry with no\nimport — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "boot()"
      }), " wires the map into the MDX provider."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "There are five edits, always the same shape:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The component"
        }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/components/<Name>.tsx"
        })]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The styles"
        }), " — rules in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/GroveApp.css"
        })]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The registration"
        }), " — one import + one line in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/mdxComponents.ts"
        })]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "A demonstration"
        }), " — use it in a content entry so it renders"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Verify"
        }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npm run build"
        }), " + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npm run lint"
        }), ", then look at it"]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "the-hard-rules-these-break-only-on-immediatelyrun-if-violated",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-hard-rules-these-break-only-on-immediatelyrun-if-violated"
      }), "The hard rules (these break ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "only"
      }), " on immediately.run if violated)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["From ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "../../CLAUDE.md",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "CLAUDE.md"
        })
      }), " — the failure mode is \"works in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "vite dev"
      }), ",\nbreaks in the sandbox,\" so honor them up front:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "One component per file, default-exported"
        }), ", named for what it renders."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "A component file exports ONLY the component."
        }), " No mixing in exported\nconstants/data/helpers — that trips React Fast Refresh and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npm run lint"
        }), "\nfails. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "interface"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "type"
        }), " are erased at compile time and are fine. Put data in\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/data/"
        }), ", helpers in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/lib/"
        }), ", hooks in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/hooks/"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Pull design tokens from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "src/index.css"
          })]
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--bg"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--panel"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--ink"
        }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--accent"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--grad"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--r-lg"
        }), ", the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--disp"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--sans"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--mono"
        }), " families, …).\nDon't hard-code colors, radii, or fonts. Apply the signature gradient to text\nwith ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "className=\"grad-text\""
        }), ". ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "No emoji"
        }), "; icons come from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<Icon>"
        }), " (Lucide)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "No Node / build-only APIs"
        }), " in the rendered tree — it runs in a browser\niframe. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "document"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "window"
        }), ", and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "fetch"
        }), " are available. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Web storage is\nnot"
        }), " (opaque origin, no ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "allow-same-origin"
        }), "): device-local state goes in the\nmount from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "openLocalStore()"
        }), ", synced state in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "openSettings()"
        }), " — hard\nrule 8."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "step-1-write-the-component",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "step-1-write-the-component"
      }), "Step 1 — Write the component"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Create ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/components/Quote.tsx"
      }), ". Note how it ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["reuses ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<WikiLink>"
        })]
      }), " for the\nsource link instead of hand-rolling an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "href"
      }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "WikiLink"
      }), " resolves a content\npath to the right in-app link and renders the correct ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "resolved / broken / self"
      }), "\nstate, so a moved or deleted target degrades gracefully instead of 404-ing."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-tsx",
        children: "import type { ReactNode } from 'react';\nimport WikiLink from './WikiLink';\n\ninterface Props {\n  /** Attribution — a person, role, or document. Rendered in mono as \"— cite\". */\n  cite?: string;\n  /** Wiki path of the entry the quote is drawn from, e.g.\n   *  \"content/handbook/onboarding.mdx\". When set, a \"Source →\" link is shown. */\n  source?: string;\n  children?: ReactNode;\n}\n\nexport default function Quote({ cite, source, children }: Props) {\n  const href = source ? (source.startsWith('/') ? source : `/${source}`) : null;\n  return (\n    <figure className=\"grove-quote\">\n      <blockquote className=\"grove-quote__body\">{children}</blockquote>\n      {(cite || href) && (\n        <figcaption className=\"grove-quote__cap\">\n          {cite ? <span className=\"grove-quote__cite\">{cite}</span> : null}\n          {href ? (\n            <WikiLink href={href} className=\"grove-quote__src\">\n              Source →\n            </WikiLink>\n          ) : null}\n        </figcaption>\n      )}\n    </figure>\n  );\n}\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Conventions worth copying:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Props are an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "interface"
          })]
        }), " (erased at compile time — does not violate the\n\"components only\" rule). Make optional props genuinely optional and degrade\nwhen absent (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<Quote>"
        }), " works with no ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "cite"
        }), " and no ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "source"
        }), ")."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Link into the wiki via ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "<WikiLink>"
          })]
        }), ", not a raw ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<a>"
        }), ". ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "WikiLink"
        }), " wants an\nhref like ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "/content/handbook/onboarding.mdx"
        }), "; we normalize the author-facing\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "source=\"content/…\""
        }), " to that. Path translation helpers (key ↔ href ↔ repo-rel)\nlive in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "../../src/lib/content.ts",
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "src/lib/content.ts"
          })
        }), " if you need them."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Reach for existing components"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<Icon>"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<WikiLink>"
        }), ") before writing new\nprimitives."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "step-2-style-it-with-tokens",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "step-2-style-it-with-tokens"
      }), "Step 2 — Style it with tokens"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Grove ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "centralizes component styles"
      }), " in\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "../../src/GroveApp.css",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/GroveApp.css"
        })
      }), " (imported once from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "App.tsx"
      }), ") — the\nexisting ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: ".grove-callout"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: ".grove-lede"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: ".grove-wikilink"
      }), " rules all live there.\nAdd your block there too (don't add a per-component ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "import './Quote.css'"
      }), "; the\ncentralized sheet is the established pattern and is guaranteed to be present at\nruntime)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Use ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "only tokens"
      }), " so light, dark, and the alternate themes all work for free:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-css",
        children: "/* pull-quote */\n.grove-quote {\n  position: relative;\n  margin: 22px 0;\n  padding: 22px 24px 20px 28px;\n  background: var(--panel);\n  border: 1px solid var(--line);\n  border-radius: var(--r-lg);\n  overflow: hidden;\n}\n.grove-quote::before {                 /* gradient accent spine */\n  content: \"\";\n  position: absolute; left: 0; top: 0; bottom: 0; width: 4px;\n  background: var(--grad);\n}\n.grove-quote__body {\n  font-family: var(--disp); font-weight: 500;\n  font-size: 1.18rem; line-height: 1.5; color: var(--ink);\n  font-style: normal; border: 0; margin: 0; padding: 0;\n}\n.grove-quote__body::before {           /* large gradient opening quote mark */\n  content: \"\\201C\";\n  font-family: var(--disp); font-weight: 900; font-size: 3.2rem; line-height: 0.1;\n  margin-right: 0.06em; vertical-align: -0.42em;\n  background: var(--grad); -webkit-background-clip: text; background-clip: text;\n  color: transparent;\n}\n.grove-quote__cap {\n  display: flex; flex-wrap: wrap; align-items: baseline; gap: 6px 16px;\n  margin-top: 14px; font-family: var(--mono); font-size: 0.8rem;\n}\n.grove-quote__cite { color: var(--ink-2); }\n.grove-quote__cite::before { content: \"— \"; color: var(--ink-3); }\n.grove-quote__src {\n  color: var(--accent); white-space: nowrap;\n  border-bottom: 1px solid color-mix(in srgb, var(--accent) 40%, transparent);\n  transition: 0.12s;\n}\n.grove-quote__src:hover { border-bottom-color: var(--accent); }\n.grove-quote__cap .grove-wikilink { font-family: var(--mono); font-size: 0.8rem; }\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Because every value is a token (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "--grad"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "--accent"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "--panel"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "--ink"
      }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "--line"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "--r-lg"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "--mono"
      }), "), the component inherits the active theme — no\nlight-mode special-casing needed."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "step-3-register-it",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "step-3-register-it"
      }), "Step 3 — Register it"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["In ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "../../src/mdxComponents.ts",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/mdxComponents.ts"
        })
      }), ", add the import and put\nthe component in the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "GROVE_MDX"
      }), " map:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-diff",
        children: " import WikiLink from './components/WikiLink';\n+import Quote from './components/Quote';\n import Toc from './components/Toc';\n …\n   Directory,\n+  Quote,\n   Toc,\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["That single map is the whole vocabulary — once it's in there, every entry can use\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "<Quote>"
      }), " with no import."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "step-4-demonstrate-it",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "step-4-demonstrate-it"
      }), "Step 4 — Demonstrate it"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Use the component in a real entry so it renders and you can eyeball it. We added\none to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "../../content/home.mdx",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "content/home.mdx"
        })
      }), ":"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-mdx",
        children: "<Quote cite=\"Meridian onboarding guide\" source=\"content/handbook/onboarding.mdx\">\nYour first week is about meeting people and shipping one small thing — not reading every page of the handbook.\n</Quote>\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "step-5-verify",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "step-5-verify"
      }), "Step 5 — Verify"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Run Grove's own gate — both must pass:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-bash",
        children: "npm run build   # tsc -b && vite build — no type errors\nnpm run lint    # eslint — proves the Fast Refresh \"components only\" rule holds\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Then ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "see it actually render"
      }), " (not just compile):"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
          children: ["Quick local check: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "npm run dev"
          }), " (Vite) and open the home page."]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
          children: "Real check on the platform — exercise the actual sandbox + MDX provider, which\nis where the \"works locally, breaks on immediately.run\" class of bug shows up.\nServe the working tree with the CLI and open the printed link:"
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            className: "language-bash",
            children: "immediately.run dev . --origin https://local.immediately.run --json\n# open the printed /present/local/<name>-<hash>/grove/live#… link\n"
          })
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
          children: ["Edits on disk hot-reload in the preview. For the worked example you should see\nthe pull-quote with its gradient spine and a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "\"Source →\""
          }), " link that resolves\nto the onboarding entry."]
        }), "\n"]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "step-6-contribute",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "step-6-contribute"
      }), "Step 6 — Contribute"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "immediately.run dev"
      }), " is read-only and never writes your repo; your edits are the\nfiles you changed on disk. Commit and open a PR the normal way:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-bash",
        children: "git checkout -b quote-component\ngit add src/components/Quote.tsx src/GroveApp.css src/mdxComponents.ts content/home.mdx\ngit commit -m \"Add <Quote> pull-quote component\"\ngit push -u origin quote-component\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "checklist-copy-this-for-the-next-component",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "checklist-copy-this-for-the-next-component"
      }), "Checklist (copy this for the next component)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      className: "contains-task-list",
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        className: "task-list-item",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.input, {
          type: "checkbox",
          disabled: true
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/components/<Name>.tsx"
        }), " — one default-exported component, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "only"
        }), " the\ncomponent exported, props as an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "interface"
        }), ", degrades when optional props\nare absent."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        className: "task-list-item",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.input, {
          type: "checkbox",
          disabled: true
        }), " ", "Links into the wiki go through ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<WikiLink>"
        }), " (resolved/broken/self), not raw\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<a>"
        }), "/hand-rolled hrefs."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        className: "task-list-item",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.input, {
          type: "checkbox",
          disabled: true
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".grove-<name>"
        }), " styles added to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/GroveApp.css"
        }), " using ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "tokens only"
        }), "\n(no hard-coded colors/radii/fonts), no emoji."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        className: "task-list-item",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.input, {
          type: "checkbox",
          disabled: true
        }), " ", "Imported + added to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "GROVE_MDX"
        }), " in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/mdxComponents.ts"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        className: "task-list-item",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.input, {
          type: "checkbox",
          disabled: true
        }), " ", "Used in a content entry as a live demo."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        className: "task-list-item",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.input, {
          type: "checkbox",
          disabled: true
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npm run build"
        }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npm run lint"
        }), " pass; rendered and eyeballed (ideally on\nimmediately.run, both light and dark)."]
      }), "\n"]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/tutorials/creating-a-component.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiY29kZSIsImVtIiwiaDEiLCJoMiIsImlucHV0IiwibGkiLCJvbCIsInAiLCJwcmUiLCJzdHJvbmciLCJ1bCIsIl9wcm92aWRlQ29tcG9uZW50cyIsImNvbXBvbmVudHMiLCJIZWFkaW5nQW5jaG9yIiwiX21pc3NpbmdNZHhSZWZlcmVuY2UiLCJqc3hzIiwiRnJhZ21lbnQiLCJjaGlsZHJlbiIsImlkIiwianN4IiwiaHJlZiIsImNsYXNzTmFtZSIsInR5cGUiLCJkaXNhYmxlZCIsIk1EWENvbnRlbnQiLCJ3cmFwcGVyIiwiTURYTGF5b3V0IiwiX2MiLCJjb21wb25lbnQiLCJwbGFjZSIsIkVycm9yIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiY3JlYXRpbmctYS1jb21wb25lbnQubWQiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgYTogXCJhXCIsXG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgZW06IFwiZW1cIixcbiAgICBoMTogXCJoMVwiLFxuICAgIGgyOiBcImgyXCIsXG4gICAgaW5wdXQ6IFwiaW5wdXRcIixcbiAgICBsaTogXCJsaVwiLFxuICAgIG9sOiBcIm9sXCIsXG4gICAgcDogXCJwXCIsXG4gICAgcHJlOiBcInByZVwiLFxuICAgIHN0cm9uZzogXCJzdHJvbmdcIixcbiAgICB1bDogXCJ1bFwiLFxuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfSwge0hlYWRpbmdBbmNob3J9ID0gX2NvbXBvbmVudHM7XG4gIGlmICghSGVhZGluZ0FuY2hvcikgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJIZWFkaW5nQW5jaG9yXCIsIHRydWUpO1xuICByZXR1cm4gPD48X2NvbXBvbmVudHMuaDEgaWQ9XCJjcmVhdGluZy1hLW5ldy1ncm92ZS1jb21wb25lbnRcIj48SGVhZGluZ0FuY2hvciBpZD1cImNyZWF0aW5nLWEtbmV3LWdyb3ZlLWNvbXBvbmVudFwiIC8+e1wiQ3JlYXRpbmcgYSBuZXcgR3JvdmUgY29tcG9uZW50XCJ9PC9fY29tcG9uZW50cy5oMT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJIb3cgdG8gYWRkIGEgbmV3IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiaW1wb3J0LWZyZWUgTURYIGNvbXBvbmVudFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB0byB0aGlzIHdpa2kg4oCUIGEgcGllY2Ugb2YgVUlcXG52b2NhYnVsYXJ5IHRoYXQgYW55IFwifTxfY29tcG9uZW50cy5jb2RlPntcIi5tZHhcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGVudHJ5IGNhbiB1c2Ugd2l0aCBubyBpbXBvcnQgbGluZSwgbGlrZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCI8Q2FsbG91dD5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcIjxEb2NMaXN0PlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIG9yIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjxUb2M+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi4gV2UgYnVpbGQgYSByZWFsIG9uZSBlbmQgdG8gZW5kOiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPjxfY29tcG9uZW50cy5jb2RlPntcIjxRdW90ZT5cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBhXFxucHVsbC1xdW90ZSB0aGF0IGNhbiBsaW5rIGJhY2sgdG8gdGhlIGVudHJ5IGl0IGNhbWUgZnJvbS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhpcyBpcyB3cml0dGVuIHNvIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJodW1hbiBvciBhIGNvZGluZyBhZ2VudFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBjYW4gZm9sbG93IGl0IHZlcmJhdGltLiBFdmVyeVxcbnN0ZXAgbmFtZXMgdGhlIGV4YWN0IGZpbGUgYW5kIHRoZSBjb252ZW50aW9uIGJlaGluZCBpdC5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwid2hhdC1hLWNvbXBvbmVudC1tZWFucy1pbi1ncm92ZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwid2hhdC1hLWNvbXBvbmVudC1tZWFucy1pbi1ncm92ZVwiIC8+e1wiV2hhdCBcXFwiYSBjb21wb25lbnRcXFwiIG1lYW5zIGluIEdyb3ZlXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJHcm92ZSByZW5kZXJzIGVhY2ggZW50cnkncyBNRFggYWdhaW5zdCBhIGZpeGVkIGNvbXBvbmVudCB2b2NhYnVsYXJ5IHJlZ2lzdGVyZWQgaW5cXG5cIn08X2NvbXBvbmVudHMuYSBocmVmPVwiLi4vLi4vc3JjL21keENvbXBvbmVudHMudHNcIj48X2NvbXBvbmVudHMuY29kZT57XCJzcmMvbWR4Q29tcG9uZW50cy50c1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLmE+e1wiICh0aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiR1JPVkVfTURYXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBtYXApLiBBZGRpbmdcXG5hIGNvbXBvbmVudCBtZWFuczogd3JpdGUgYSBSZWFjdCBjb21wb25lbnQsIGdpdmUgaXQgc3R5bGVzLCBhbmQgcmVnaXN0ZXIgaXQgaW5cXG50aGF0IG1hcC4gQWZ0ZXIgdGhhdCwgYXV0aG9ycyB3cml0ZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCI8UXVvdGU+4oCmPC9RdW90ZT5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGluIGFueSBlbnRyeSB3aXRoIG5vXFxuaW1wb3J0IOKAlCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJib290KClcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHdpcmVzIHRoZSBtYXAgaW50byB0aGUgTURYIHByb3ZpZGVyLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGVyZSBhcmUgZml2ZSBlZGl0cywgYWx3YXlzIHRoZSBzYW1lIHNoYXBlOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMub2w+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVGhlIGNvbXBvbmVudFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2NvbXBvbmVudHMvPE5hbWU+LnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlRoZSBzdHlsZXNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHJ1bGVzIGluIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9Hcm92ZUFwcC5jc3NcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgcmVnaXN0cmF0aW9uXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBvbmUgaW1wb3J0ICsgb25lIGxpbmUgaW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL21keENvbXBvbmVudHMudHNcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJBIGRlbW9uc3RyYXRpb25cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHVzZSBpdCBpbiBhIGNvbnRlbnQgZW50cnkgc28gaXQgcmVuZGVyc1wifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVmVyaWZ5XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJucG0gcnVuIGJ1aWxkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiArIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm5wbSBydW4gbGludFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIHRoZW4gbG9vayBhdCBpdFwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJ0aGUtaGFyZC1ydWxlcy10aGVzZS1icmVhay1vbmx5LW9uLWltbWVkaWF0ZWx5cnVuLWlmLXZpb2xhdGVkXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJ0aGUtaGFyZC1ydWxlcy10aGVzZS1icmVhay1vbmx5LW9uLWltbWVkaWF0ZWx5cnVuLWlmLXZpb2xhdGVkXCIgLz57XCJUaGUgaGFyZCBydWxlcyAodGhlc2UgYnJlYWsgXCJ9PF9jb21wb25lbnRzLmVtPntcIm9ubHlcIn08L19jb21wb25lbnRzLmVtPntcIiBvbiBpbW1lZGlhdGVseS5ydW4gaWYgdmlvbGF0ZWQpXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJGcm9tIFwifTxfY29tcG9uZW50cy5hIGhyZWY9XCIuLi8uLi9DTEFVREUubWRcIj48X2NvbXBvbmVudHMuY29kZT57XCJDTEFVREUubWRcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5hPntcIiDigJQgdGhlIGZhaWx1cmUgbW9kZSBpcyBcXFwid29ya3MgaW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widml0ZSBkZXZcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLFxcbmJyZWFrcyBpbiB0aGUgc2FuZGJveCxcXFwiIHNvIGhvbm9yIHRoZW0gdXAgZnJvbnQ6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJPbmUgY29tcG9uZW50IHBlciBmaWxlLCBkZWZhdWx0LWV4cG9ydGVkXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBuYW1lZCBmb3Igd2hhdCBpdCByZW5kZXJzLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQSBjb21wb25lbnQgZmlsZSBleHBvcnRzIE9OTFkgdGhlIGNvbXBvbmVudC5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgTm8gbWl4aW5nIGluIGV4cG9ydGVkXFxuY29uc3RhbnRzL2RhdGEvaGVscGVycyDigJQgdGhhdCB0cmlwcyBSZWFjdCBGYXN0IFJlZnJlc2ggYW5kIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm5wbSBydW4gbGludFwifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG5mYWlscy4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW50ZXJmYWNlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJ0eXBlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhcmUgZXJhc2VkIGF0IGNvbXBpbGUgdGltZSBhbmQgYXJlIGZpbmUuIFB1dCBkYXRhIGluXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2RhdGEvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgaGVscGVycyBpbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvbGliL1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGhvb2tzIGluIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9ob29rcy9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUHVsbCBkZXNpZ24gdG9rZW5zIGZyb20gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2luZGV4LmNzc1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnN0cm9uZz57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIi0tYmdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCItLXBhbmVsXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1pbmtcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcIi0tYWNjZW50XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1ncmFkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1yLWxnXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgdGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi0tZGlzcFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1zYW5zXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCItLW1vbm9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGZhbWlsaWVzLCDigKYpLlxcbkRvbid0IGhhcmQtY29kZSBjb2xvcnMsIHJhZGlpLCBvciBmb250cy4gQXBwbHkgdGhlIHNpZ25hdHVyZSBncmFkaWVudCB0byB0ZXh0XFxud2l0aCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjbGFzc05hbWU9XFxcImdyYWQtdGV4dFxcXCJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIk5vIGVtb2ppXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiOyBpY29ucyBjb21lIGZyb20gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiPEljb24+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoTHVjaWRlKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIk5vIE5vZGUgLyBidWlsZC1vbmx5IEFQSXNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgaW4gdGhlIHJlbmRlcmVkIHRyZWUg4oCUIGl0IHJ1bnMgaW4gYSBicm93c2VyXFxuaWZyYW1lLiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJkb2N1bWVudFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIndpbmRvd1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGFuZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmZXRjaFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYXJlIGF2YWlsYWJsZS4gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJXZWIgc3RvcmFnZSBpc1xcbm5vdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAob3BhcXVlIG9yaWdpbiwgbm8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYWxsb3ctc2FtZS1vcmlnaW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiKTogZGV2aWNlLWxvY2FsIHN0YXRlIGdvZXMgaW4gdGhlXFxubW91bnQgZnJvbSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJvcGVuTG9jYWxTdG9yZSgpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgc3luY2VkIHN0YXRlIGluIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm9wZW5TZXR0aW5ncygpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgaGFyZFxcbnJ1bGUgOC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic3RlcC0xLXdyaXRlLXRoZS1jb21wb25lbnRcIj48SGVhZGluZ0FuY2hvciBpZD1cInN0ZXAtMS13cml0ZS10aGUtY29tcG9uZW50XCIgLz57XCJTdGVwIDEg4oCUIFdyaXRlIHRoZSBjb21wb25lbnRcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkNyZWF0ZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvY29tcG9uZW50cy9RdW90ZS50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLiBOb3RlIGhvdyBpdCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInJldXNlcyBcIn08X2NvbXBvbmVudHMuY29kZT57XCI8V2lraUxpbms+XCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBmb3IgdGhlXFxuc291cmNlIGxpbmsgaW5zdGVhZCBvZiBoYW5kLXJvbGxpbmcgYW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaHJlZlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIFwifTxfY29tcG9uZW50cy5jb2RlPntcIldpa2lMaW5rXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiByZXNvbHZlcyBhIGNvbnRlbnRcXG5wYXRoIHRvIHRoZSByaWdodCBpbi1hcHAgbGluayBhbmQgcmVuZGVycyB0aGUgY29ycmVjdCBcIn08X2NvbXBvbmVudHMuZW0+e1wicmVzb2x2ZWQgLyBicm9rZW4gLyBzZWxmXCJ9PC9fY29tcG9uZW50cy5lbT57XCJcXG5zdGF0ZSwgc28gYSBtb3ZlZCBvciBkZWxldGVkIHRhcmdldCBkZWdyYWRlcyBncmFjZWZ1bGx5IGluc3RlYWQgb2YgNDA0LWluZy5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnByZT48X2NvbXBvbmVudHMuY29kZSBjbGFzc05hbWU9XCJsYW5ndWFnZS10c3hcIj57XCJpbXBvcnQgdHlwZSB7IFJlYWN0Tm9kZSB9IGZyb20gJ3JlYWN0JztcXG5pbXBvcnQgV2lraUxpbmsgZnJvbSAnLi9XaWtpTGluayc7XFxuXFxuaW50ZXJmYWNlIFByb3BzIHtcXG4gIC8qKiBBdHRyaWJ1dGlvbiDigJQgYSBwZXJzb24sIHJvbGUsIG9yIGRvY3VtZW50LiBSZW5kZXJlZCBpbiBtb25vIGFzIFxcXCLigJQgY2l0ZVxcXCIuICovXFxuICBjaXRlPzogc3RyaW5nO1xcbiAgLyoqIFdpa2kgcGF0aCBvZiB0aGUgZW50cnkgdGhlIHF1b3RlIGlzIGRyYXduIGZyb20sIGUuZy5cXG4gICAqICBcXFwiY29udGVudC9oYW5kYm9vay9vbmJvYXJkaW5nLm1keFxcXCIuIFdoZW4gc2V0LCBhIFxcXCJTb3VyY2Ug4oaSXFxcIiBsaW5rIGlzIHNob3duLiAqL1xcbiAgc291cmNlPzogc3RyaW5nO1xcbiAgY2hpbGRyZW4/OiBSZWFjdE5vZGU7XFxufVxcblxcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFF1b3RlKHsgY2l0ZSwgc291cmNlLCBjaGlsZHJlbiB9OiBQcm9wcykge1xcbiAgY29uc3QgaHJlZiA9IHNvdXJjZSA/IChzb3VyY2Uuc3RhcnRzV2l0aCgnLycpID8gc291cmNlIDogYC8ke3NvdXJjZX1gKSA6IG51bGw7XFxuICByZXR1cm4gKFxcbiAgICA8ZmlndXJlIGNsYXNzTmFtZT1cXFwiZ3JvdmUtcXVvdGVcXFwiPlxcbiAgICAgIDxibG9ja3F1b3RlIGNsYXNzTmFtZT1cXFwiZ3JvdmUtcXVvdGVfX2JvZHlcXFwiPntjaGlsZHJlbn08L2Jsb2NrcXVvdGU+XFxuICAgICAgeyhjaXRlIHx8IGhyZWYpICYmIChcXG4gICAgICAgIDxmaWdjYXB0aW9uIGNsYXNzTmFtZT1cXFwiZ3JvdmUtcXVvdGVfX2NhcFxcXCI+XFxuICAgICAgICAgIHtjaXRlID8gPHNwYW4gY2xhc3NOYW1lPVxcXCJncm92ZS1xdW90ZV9fY2l0ZVxcXCI+e2NpdGV9PC9zcGFuPiA6IG51bGx9XFxuICAgICAgICAgIHtocmVmID8gKFxcbiAgICAgICAgICAgIDxXaWtpTGluayBocmVmPXtocmVmfSBjbGFzc05hbWU9XFxcImdyb3ZlLXF1b3RlX19zcmNcXFwiPlxcbiAgICAgICAgICAgICAgU291cmNlIOKGklxcbiAgICAgICAgICAgIDwvV2lraUxpbms+XFxuICAgICAgICAgICkgOiBudWxsfVxcbiAgICAgICAgPC9maWdjYXB0aW9uPlxcbiAgICAgICl9XFxuICAgIDwvZmlndXJlPlxcbiAgKTtcXG59XFxuXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMucHJlPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkNvbnZlbnRpb25zIHdvcnRoIGNvcHlpbmc6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJQcm9wcyBhcmUgYW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW50ZXJmYWNlXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoZXJhc2VkIGF0IGNvbXBpbGUgdGltZSDigJQgZG9lcyBub3QgdmlvbGF0ZSB0aGVcXG5cXFwiY29tcG9uZW50cyBvbmx5XFxcIiBydWxlKS4gTWFrZSBvcHRpb25hbCBwcm9wcyBnZW51aW5lbHkgb3B0aW9uYWwgYW5kIGRlZ3JhZGVcXG53aGVuIGFic2VudCAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiPFF1b3RlPlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgd29ya3Mgd2l0aCBubyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjaXRlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhbmQgbm8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic291cmNlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJMaW5rIGludG8gdGhlIHdpa2kgdmlhIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjxXaWtpTGluaz5cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBub3QgYSByYXcgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiPGE+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiV2lraUxpbmtcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHdhbnRzIGFuXFxuaHJlZiBsaWtlIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi9jb250ZW50L2hhbmRib29rL29uYm9hcmRpbmcubWR4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjsgd2Ugbm9ybWFsaXplIHRoZSBhdXRob3ItZmFjaW5nXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic291cmNlPVxcXCJjb250ZW50L+KAplxcXCJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHRvIHRoYXQuIFBhdGggdHJhbnNsYXRpb24gaGVscGVycyAoa2V5IOKGlCBocmVmIOKGlCByZXBvLXJlbClcXG5saXZlIGluIFwifTxfY29tcG9uZW50cy5hIGhyZWY9XCIuLi8uLi9zcmMvbGliL2NvbnRlbnQudHNcIj48X2NvbXBvbmVudHMuY29kZT57XCJzcmMvbGliL2NvbnRlbnQudHNcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5hPntcIiBpZiB5b3UgbmVlZCB0aGVtLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUmVhY2ggZm9yIGV4aXN0aW5nIGNvbXBvbmVudHNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIjxJY29uPlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjxXaWtpTGluaz5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSBiZWZvcmUgd3JpdGluZyBuZXdcXG5wcmltaXRpdmVzLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzdGVwLTItc3R5bGUtaXQtd2l0aC10b2tlbnNcIj48SGVhZGluZ0FuY2hvciBpZD1cInN0ZXAtMi1zdHlsZS1pdC13aXRoLXRva2Vuc1wiIC8+e1wiU3RlcCAyIOKAlCBTdHlsZSBpdCB3aXRoIHRva2Vuc1wifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiR3JvdmUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJjZW50cmFsaXplcyBjb21wb25lbnQgc3R5bGVzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGluXFxuXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cIi4uLy4uL3NyYy9Hcm92ZUFwcC5jc3NcIj48X2NvbXBvbmVudHMuY29kZT57XCJzcmMvR3JvdmVBcHAuY3NzXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuYT57XCIgKGltcG9ydGVkIG9uY2UgZnJvbSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJBcHAudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikg4oCUIHRoZVxcbmV4aXN0aW5nIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi5ncm92ZS1jYWxsb3V0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLmdyb3ZlLWxlZGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCIuZ3JvdmUtd2lraWxpbmtcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHJ1bGVzIGFsbCBsaXZlIHRoZXJlLlxcbkFkZCB5b3VyIGJsb2NrIHRoZXJlIHRvbyAoZG9uJ3QgYWRkIGEgcGVyLWNvbXBvbmVudCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJpbXBvcnQgJy4vUXVvdGUuY3NzJ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCI7IHRoZVxcbmNlbnRyYWxpemVkIHNoZWV0IGlzIHRoZSBlc3RhYmxpc2hlZCBwYXR0ZXJuIGFuZCBpcyBndWFyYW50ZWVkIHRvIGJlIHByZXNlbnQgYXRcXG5ydW50aW1lKS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVXNlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wib25seSB0b2tlbnNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgc28gbGlnaHQsIGRhcmssIGFuZCB0aGUgYWx0ZXJuYXRlIHRoZW1lcyBhbGwgd29yayBmb3IgZnJlZTpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnByZT48X2NvbXBvbmVudHMuY29kZSBjbGFzc05hbWU9XCJsYW5ndWFnZS1jc3NcIj57XCIvKiBwdWxsLXF1b3RlICovXFxuLmdyb3ZlLXF1b3RlIHtcXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcXG4gIG1hcmdpbjogMjJweCAwO1xcbiAgcGFkZGluZzogMjJweCAyNHB4IDIwcHggMjhweDtcXG4gIGJhY2tncm91bmQ6IHZhcigtLXBhbmVsKTtcXG4gIGJvcmRlcjogMXB4IHNvbGlkIHZhcigtLWxpbmUpO1xcbiAgYm9yZGVyLXJhZGl1czogdmFyKC0tci1sZyk7XFxuICBvdmVyZmxvdzogaGlkZGVuO1xcbn1cXG4uZ3JvdmUtcXVvdGU6OmJlZm9yZSB7ICAgICAgICAgICAgICAgICAvKiBncmFkaWVudCBhY2NlbnQgc3BpbmUgKi9cXG4gIGNvbnRlbnQ6IFxcXCJcXFwiO1xcbiAgcG9zaXRpb246IGFic29sdXRlOyBsZWZ0OiAwOyB0b3A6IDA7IGJvdHRvbTogMDsgd2lkdGg6IDRweDtcXG4gIGJhY2tncm91bmQ6IHZhcigtLWdyYWQpO1xcbn1cXG4uZ3JvdmUtcXVvdGVfX2JvZHkge1xcbiAgZm9udC1mYW1pbHk6IHZhcigtLWRpc3ApOyBmb250LXdlaWdodDogNTAwO1xcbiAgZm9udC1zaXplOiAxLjE4cmVtOyBsaW5lLWhlaWdodDogMS41OyBjb2xvcjogdmFyKC0taW5rKTtcXG4gIGZvbnQtc3R5bGU6IG5vcm1hbDsgYm9yZGVyOiAwOyBtYXJnaW46IDA7IHBhZGRpbmc6IDA7XFxufVxcbi5ncm92ZS1xdW90ZV9fYm9keTo6YmVmb3JlIHsgICAgICAgICAgIC8qIGxhcmdlIGdyYWRpZW50IG9wZW5pbmcgcXVvdGUgbWFyayAqL1xcbiAgY29udGVudDogXFxcIlxcXFwyMDFDXFxcIjtcXG4gIGZvbnQtZmFtaWx5OiB2YXIoLS1kaXNwKTsgZm9udC13ZWlnaHQ6IDkwMDsgZm9udC1zaXplOiAzLjJyZW07IGxpbmUtaGVpZ2h0OiAwLjE7XFxuICBtYXJnaW4tcmlnaHQ6IDAuMDZlbTsgdmVydGljYWwtYWxpZ246IC0wLjQyZW07XFxuICBiYWNrZ3JvdW5kOiB2YXIoLS1ncmFkKTsgLXdlYmtpdC1iYWNrZ3JvdW5kLWNsaXA6IHRleHQ7IGJhY2tncm91bmQtY2xpcDogdGV4dDtcXG4gIGNvbG9yOiB0cmFuc3BhcmVudDtcXG59XFxuLmdyb3ZlLXF1b3RlX19jYXAge1xcbiAgZGlzcGxheTogZmxleDsgZmxleC13cmFwOiB3cmFwOyBhbGlnbi1pdGVtczogYmFzZWxpbmU7IGdhcDogNnB4IDE2cHg7XFxuICBtYXJnaW4tdG9wOiAxNHB4OyBmb250LWZhbWlseTogdmFyKC0tbW9ubyk7IGZvbnQtc2l6ZTogMC44cmVtO1xcbn1cXG4uZ3JvdmUtcXVvdGVfX2NpdGUgeyBjb2xvcjogdmFyKC0taW5rLTIpOyB9XFxuLmdyb3ZlLXF1b3RlX19jaXRlOjpiZWZvcmUgeyBjb250ZW50OiBcXFwi4oCUIFxcXCI7IGNvbG9yOiB2YXIoLS1pbmstMyk7IH1cXG4uZ3JvdmUtcXVvdGVfX3NyYyB7XFxuICBjb2xvcjogdmFyKC0tYWNjZW50KTsgd2hpdGUtc3BhY2U6IG5vd3JhcDtcXG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCBjb2xvci1taXgoaW4gc3JnYiwgdmFyKC0tYWNjZW50KSA0MCUsIHRyYW5zcGFyZW50KTtcXG4gIHRyYW5zaXRpb246IDAuMTJzO1xcbn1cXG4uZ3JvdmUtcXVvdGVfX3NyYzpob3ZlciB7IGJvcmRlci1ib3R0b20tY29sb3I6IHZhcigtLWFjY2VudCk7IH1cXG4uZ3JvdmUtcXVvdGVfX2NhcCAuZ3JvdmUtd2lraWxpbmsgeyBmb250LWZhbWlseTogdmFyKC0tbW9ubyk7IGZvbnQtc2l6ZTogMC44cmVtOyB9XFxuXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMucHJlPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkJlY2F1c2UgZXZlcnkgdmFsdWUgaXMgYSB0b2tlbiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1ncmFkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1hY2NlbnRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCItLXBhbmVsXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1pbmtcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcIi0tbGluZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi0tci1sZ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi0tbW9ub1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLCB0aGUgY29tcG9uZW50IGluaGVyaXRzIHRoZSBhY3RpdmUgdGhlbWUg4oCUIG5vXFxubGlnaHQtbW9kZSBzcGVjaWFsLWNhc2luZyBuZWVkZWQuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInN0ZXAtMy1yZWdpc3Rlci1pdFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic3RlcC0zLXJlZ2lzdGVyLWl0XCIgLz57XCJTdGVwIDMg4oCUIFJlZ2lzdGVyIGl0XCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJJbiBcIn08X2NvbXBvbmVudHMuYSBocmVmPVwiLi4vLi4vc3JjL21keENvbXBvbmVudHMudHNcIj48X2NvbXBvbmVudHMuY29kZT57XCJzcmMvbWR4Q29tcG9uZW50cy50c1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLmE+e1wiLCBhZGQgdGhlIGltcG9ydCBhbmQgcHV0XFxudGhlIGNvbXBvbmVudCBpbiB0aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiR1JPVkVfTURYXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBtYXA6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wcmU+PF9jb21wb25lbnRzLmNvZGUgY2xhc3NOYW1lPVwibGFuZ3VhZ2UtZGlmZlwiPntcIiBpbXBvcnQgV2lraUxpbmsgZnJvbSAnLi9jb21wb25lbnRzL1dpa2lMaW5rJztcXG4raW1wb3J0IFF1b3RlIGZyb20gJy4vY29tcG9uZW50cy9RdW90ZSc7XFxuIGltcG9ydCBUb2MgZnJvbSAnLi9jb21wb25lbnRzL1RvYyc7XFxuIOKAplxcbiAgIERpcmVjdG9yeSxcXG4rICBRdW90ZSxcXG4gICBUb2MsXFxuXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMucHJlPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoYXQgc2luZ2xlIG1hcCBpcyB0aGUgd2hvbGUgdm9jYWJ1bGFyeSDigJQgb25jZSBpdCdzIGluIHRoZXJlLCBldmVyeSBlbnRyeSBjYW4gdXNlXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiPFF1b3RlPlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgd2l0aCBubyBpbXBvcnQuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInN0ZXAtNC1kZW1vbnN0cmF0ZS1pdFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic3RlcC00LWRlbW9uc3RyYXRlLWl0XCIgLz57XCJTdGVwIDQg4oCUIERlbW9uc3RyYXRlIGl0XCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJVc2UgdGhlIGNvbXBvbmVudCBpbiBhIHJlYWwgZW50cnkgc28gaXQgcmVuZGVycyBhbmQgeW91IGNhbiBleWViYWxsIGl0LiBXZSBhZGRlZFxcbm9uZSB0byBcIn08X2NvbXBvbmVudHMuYSBocmVmPVwiLi4vLi4vY29udGVudC9ob21lLm1keFwiPjxfY29tcG9uZW50cy5jb2RlPntcImNvbnRlbnQvaG9tZS5tZHhcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5hPntcIjpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnByZT48X2NvbXBvbmVudHMuY29kZSBjbGFzc05hbWU9XCJsYW5ndWFnZS1tZHhcIj57XCI8UXVvdGUgY2l0ZT1cXFwiTWVyaWRpYW4gb25ib2FyZGluZyBndWlkZVxcXCIgc291cmNlPVxcXCJjb250ZW50L2hhbmRib29rL29uYm9hcmRpbmcubWR4XFxcIj5cXG5Zb3VyIGZpcnN0IHdlZWsgaXMgYWJvdXQgbWVldGluZyBwZW9wbGUgYW5kIHNoaXBwaW5nIG9uZSBzbWFsbCB0aGluZyDigJQgbm90IHJlYWRpbmcgZXZlcnkgcGFnZSBvZiB0aGUgaGFuZGJvb2suXFxuPC9RdW90ZT5cXG5cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5wcmU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic3RlcC01LXZlcmlmeVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic3RlcC01LXZlcmlmeVwiIC8+e1wiU3RlcCA1IOKAlCBWZXJpZnlcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlJ1biBHcm92ZSdzIG93biBnYXRlIOKAlCBib3RoIG11c3QgcGFzczpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnByZT48X2NvbXBvbmVudHMuY29kZSBjbGFzc05hbWU9XCJsYW5ndWFnZS1iYXNoXCI+e1wibnBtIHJ1biBidWlsZCAgICMgdHNjIC1iICYmIHZpdGUgYnVpbGQg4oCUIG5vIHR5cGUgZXJyb3JzXFxubnBtIHJ1biBsaW50ICAgICMgZXNsaW50IOKAlCBwcm92ZXMgdGhlIEZhc3QgUmVmcmVzaCBcXFwiY29tcG9uZW50cyBvbmx5XFxcIiBydWxlIGhvbGRzXFxuXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMucHJlPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZW4gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJzZWUgaXQgYWN0dWFsbHkgcmVuZGVyXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChub3QganVzdCBjb21waWxlKTpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJRdWljayBsb2NhbCBjaGVjazogXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibnBtIHJ1biBkZXZcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChWaXRlKSBhbmQgb3BlbiB0aGUgaG9tZSBwYWdlLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJSZWFsIGNoZWNrIG9uIHRoZSBwbGF0Zm9ybSDigJQgZXhlcmNpc2UgdGhlIGFjdHVhbCBzYW5kYm94ICsgTURYIHByb3ZpZGVyLCB3aGljaFxcbmlzIHdoZXJlIHRoZSBcXFwid29ya3MgbG9jYWxseSwgYnJlYWtzIG9uIGltbWVkaWF0ZWx5LnJ1blxcXCIgY2xhc3Mgb2YgYnVnIHNob3dzIHVwLlxcblNlcnZlIHRoZSB3b3JraW5nIHRyZWUgd2l0aCB0aGUgQ0xJIGFuZCBvcGVuIHRoZSBwcmludGVkIGxpbms6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wcmU+PF9jb21wb25lbnRzLmNvZGUgY2xhc3NOYW1lPVwibGFuZ3VhZ2UtYmFzaFwiPntcImltbWVkaWF0ZWx5LnJ1biBkZXYgLiAtLW9yaWdpbiBodHRwczovL2xvY2FsLmltbWVkaWF0ZWx5LnJ1biAtLWpzb25cXG4jIG9wZW4gdGhlIHByaW50ZWQgL3ByZXNlbnQvbG9jYWwvPG5hbWU+LTxoYXNoPi9ncm92ZS9saXZlI+KApiBsaW5rXFxuXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMucHJlPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkVkaXRzIG9uIGRpc2sgaG90LXJlbG9hZCBpbiB0aGUgcHJldmlldy4gRm9yIHRoZSB3b3JrZWQgZXhhbXBsZSB5b3Ugc2hvdWxkIHNlZVxcbnRoZSBwdWxsLXF1b3RlIHdpdGggaXRzIGdyYWRpZW50IHNwaW5lIGFuZCBhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiXFxcIlNvdXJjZSDihpJcXFwiXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGxpbmsgdGhhdCByZXNvbHZlc1xcbnRvIHRoZSBvbmJvYXJkaW5nIGVudHJ5LlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic3RlcC02LWNvbnRyaWJ1dGVcIj48SGVhZGluZ0FuY2hvciBpZD1cInN0ZXAtNi1jb250cmlidXRlXCIgLz57XCJTdGVwIDYg4oCUIENvbnRyaWJ1dGVcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5jb2RlPntcImltbWVkaWF0ZWx5LnJ1biBkZXZcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGlzIHJlYWQtb25seSBhbmQgbmV2ZXIgd3JpdGVzIHlvdXIgcmVwbzsgeW91ciBlZGl0cyBhcmUgdGhlXFxuZmlsZXMgeW91IGNoYW5nZWQgb24gZGlzay4gQ29tbWl0IGFuZCBvcGVuIGEgUFIgdGhlIG5vcm1hbCB3YXk6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wcmU+PF9jb21wb25lbnRzLmNvZGUgY2xhc3NOYW1lPVwibGFuZ3VhZ2UtYmFzaFwiPntcImdpdCBjaGVja291dCAtYiBxdW90ZS1jb21wb25lbnRcXG5naXQgYWRkIHNyYy9jb21wb25lbnRzL1F1b3RlLnRzeCBzcmMvR3JvdmVBcHAuY3NzIHNyYy9tZHhDb21wb25lbnRzLnRzIGNvbnRlbnQvaG9tZS5tZHhcXG5naXQgY29tbWl0IC1tIFxcXCJBZGQgPFF1b3RlPiBwdWxsLXF1b3RlIGNvbXBvbmVudFxcXCJcXG5naXQgcHVzaCAtdSBvcmlnaW4gcXVvdGUtY29tcG9uZW50XFxuXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMucHJlPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cImNoZWNrbGlzdC1jb3B5LXRoaXMtZm9yLXRoZS1uZXh0LWNvbXBvbmVudFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiY2hlY2tsaXN0LWNvcHktdGhpcy1mb3ItdGhlLW5leHQtY29tcG9uZW50XCIgLz57XCJDaGVja2xpc3QgKGNvcHkgdGhpcyBmb3IgdGhlIG5leHQgY29tcG9uZW50KVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsIGNsYXNzTmFtZT1cImNvbnRhaW5zLXRhc2stbGlzdFwiPntcIlxcblwifTxfY29tcG9uZW50cy5saSBjbGFzc05hbWU9XCJ0YXNrLWxpc3QtaXRlbVwiPjxfY29tcG9uZW50cy5pbnB1dCB0eXBlPVwiY2hlY2tib3hcIiBkaXNhYmxlZCAvPntcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvY29tcG9uZW50cy88TmFtZT4udHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgb25lIGRlZmF1bHQtZXhwb3J0ZWQgY29tcG9uZW50LCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm9ubHlcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdGhlXFxuY29tcG9uZW50IGV4cG9ydGVkLCBwcm9wcyBhcyBhbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJpbnRlcmZhY2VcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBkZWdyYWRlcyB3aGVuIG9wdGlvbmFsIHByb3BzXFxuYXJlIGFic2VudC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saSBjbGFzc05hbWU9XCJ0YXNrLWxpc3QtaXRlbVwiPjxfY29tcG9uZW50cy5pbnB1dCB0eXBlPVwiY2hlY2tib3hcIiBkaXNhYmxlZCAvPntcIiBcIn17XCJMaW5rcyBpbnRvIHRoZSB3aWtpIGdvIHRocm91Z2ggXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiPFdpa2lMaW5rPlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKHJlc29sdmVkL2Jyb2tlbi9zZWxmKSwgbm90IHJhd1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcIjxhPlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvaGFuZC1yb2xsZWQgaHJlZnMuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGkgY2xhc3NOYW1lPVwidGFzay1saXN0LWl0ZW1cIj48X2NvbXBvbmVudHMuaW5wdXQgdHlwZT1cImNoZWNrYm94XCIgZGlzYWJsZWQgLz57XCIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLmdyb3ZlLTxuYW1lPlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgc3R5bGVzIGFkZGVkIHRvIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9Hcm92ZUFwcC5jc3NcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHVzaW5nIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1widG9rZW5zIG9ubHlcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCJcXG4obm8gaGFyZC1jb2RlZCBjb2xvcnMvcmFkaWkvZm9udHMpLCBubyBlbW9qaS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saSBjbGFzc05hbWU9XCJ0YXNrLWxpc3QtaXRlbVwiPjxfY29tcG9uZW50cy5pbnB1dCB0eXBlPVwiY2hlY2tib3hcIiBkaXNhYmxlZCAvPntcIiBcIn17XCJJbXBvcnRlZCArIGFkZGVkIHRvIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkdST1ZFX01EWFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL21keENvbXBvbmVudHMudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpIGNsYXNzTmFtZT1cInRhc2stbGlzdC1pdGVtXCI+PF9jb21wb25lbnRzLmlucHV0IHR5cGU9XCJjaGVja2JveFwiIGRpc2FibGVkIC8+e1wiIFwifXtcIlVzZWQgaW4gYSBjb250ZW50IGVudHJ5IGFzIGEgbGl2ZSBkZW1vLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpIGNsYXNzTmFtZT1cInRhc2stbGlzdC1pdGVtXCI+PF9jb21wb25lbnRzLmlucHV0IHR5cGU9XCJjaGVja2JveFwiIGRpc2FibGVkIC8+e1wiIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm5wbSBydW4gYnVpbGRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFuZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJucG0gcnVuIGxpbnRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHBhc3M7IHJlbmRlcmVkIGFuZCBleWViYWxsZWQgKGlkZWFsbHkgb25cXG5pbW1lZGlhdGVseS5ydW4sIGJvdGggbGlnaHQgYW5kIGRhcmspLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD48Lz47XG59XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNRFhDb250ZW50KHByb3BzID0ge30pIHtcbiAgY29uc3Qge3dyYXBwZXI6IE1EWExheW91dH0gPSB7XG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9O1xuICByZXR1cm4gTURYTGF5b3V0ID8gPE1EWExheW91dCB7Li4ucHJvcHN9PjxfY3JlYXRlTWR4Q29udGVudCB7Li4ucHJvcHN9IC8+PC9NRFhMYXlvdXQ+IDogX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpO1xufVxuZnVuY3Rpb24gX21pc3NpbmdNZHhSZWZlcmVuY2UoaWQsIGNvbXBvbmVudCwgcGxhY2UpIHtcbiAgdGhyb3cgbmV3IEVycm9yKFwiRXhwZWN0ZWQgXCIgKyAoY29tcG9uZW50ID8gXCJjb21wb25lbnRcIiA6IFwib2JqZWN0XCIpICsgXCIgYFwiICsgaWQgKyBcImAgdG8gYmUgZGVmaW5lZDogeW91IGxpa2VseSBmb3Jnb3QgdG8gaW1wb3J0LCBwYXNzLCBvciBwcm92aWRlIGl0LlwiICsgKHBsYWNlID8gXCJcXG5JdOKAmXMgcmVmZXJlbmNlZCBpbiB5b3VyIGNvZGUgYXQgYFwiICsgcGxhY2UgKyBcImAgaW4gYC9hcHAvZG9jcy90dXRvcmlhbHMvY3JlYXRpbmctYS1jb21wb25lbnQubWRgXCIgOiBcIlwiKSk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUVBLElBQUFBLFlBQUEsR0FBQUMsT0FBQTtBQUF3RixJQUFBQyxXQUFBLEdBQUFELE9BQUE7QUFGeEY7QUFDQTs7QUFFQSxTQUFTRSxpQkFBaUJBLENBQUNDLEtBQUssRUFBRTtFQUNoQyxNQUFNQyxXQUFXLEdBQUc7TUFDbEJDLENBQUMsRUFBRSxHQUFHO01BQ05DLElBQUksRUFBRSxNQUFNO01BQ1pDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEtBQUssRUFBRSxPQUFPO01BQ2RDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLENBQUMsRUFBRSxHQUFHO01BQ05DLEdBQUcsRUFBRSxLQUFLO01BQ1ZDLE1BQU0sRUFBRSxRQUFRO01BQ2hCQyxFQUFFLEVBQUUsSUFBSTtNQUNSLEdBQUcsSUFBQUMsNkJBQWtCLEVBQUMsQ0FBQztNQUN2QixHQUFHZCxLQUFLLENBQUNlO0lBQ1gsQ0FBQztJQUFFO01BQUNDO0lBQWEsQ0FBQyxHQUFHZixXQUFXO0VBQ2hDLElBQUksQ0FBQ2UsYUFBYSxFQUFFQyxvQkFBb0IsQ0FBQyxlQUFlLEVBQUUsSUFBSSxDQUFDO0VBQy9ELG9CQUFPLElBQUFuQixXQUFBLENBQUFvQixJQUFBLEVBQUFwQixXQUFBLENBQUFxQixRQUFBO0lBQUFDLFFBQUEsZ0JBQUUsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0ksRUFBRTtNQUFDZ0IsRUFBRSxFQUFDLGdDQUFnQztNQUFBRCxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQWdDLENBQUUsQ0FBQyxFQUFDLGdDQUFnQztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBVSxRQUFBLEdBQUUsbUJBQW1CLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBMkIsQ0FBcUIsQ0FBQyxFQUFDLHFEQUFxRCxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUFNLENBQW1CLENBQUMsRUFBQywyQ0FBMkMsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1FBQUFpQixRQUFBLEVBQUU7TUFBVyxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUFXLENBQW1CLENBQUMsRUFBQyxPQUFPLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBaUIsUUFBQSxFQUFFO01BQU8sQ0FBbUIsQ0FBQyxFQUFDLG9DQUFvQyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07UUFBQVEsUUFBQSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFTLENBQW1CO01BQUMsQ0FBb0IsQ0FBQyxFQUFDLCtEQUErRDtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBVSxRQUFBLEdBQUUsdUJBQXVCLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBeUIsQ0FBcUIsQ0FBQyxFQUFDLHlGQUF5RjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDZSxFQUFFLEVBQUMsaUNBQWlDO01BQUFELFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBaUMsQ0FBRSxDQUFDLEVBQUMscUNBQXFDO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDUyxDQUFDO01BQUFVLFFBQUEsR0FBRSxxRkFBcUYsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDQyxDQUFDO1FBQUNxQixJQUFJLEVBQUMsNEJBQTRCO1FBQUFILFFBQUEsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBc0IsQ0FBbUI7TUFBQyxDQUFlLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBaUIsUUFBQSxFQUFFO01BQVcsQ0FBbUIsQ0FBQyxFQUFDLHFJQUFxSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUFrQixDQUFtQixDQUFDLEVBQUMsa0NBQWtDLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBaUIsUUFBQSxFQUFFO01BQVEsQ0FBbUIsQ0FBQyxFQUFDLHVDQUF1QztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBVSxRQUFBLEVBQUU7SUFBOEMsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDUSxFQUFFO01BQUFXLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQWUsQ0FBcUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBMkIsQ0FBbUIsQ0FBQztNQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQVksQ0FBcUIsQ0FBQyxFQUFDLGNBQWMsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBa0IsQ0FBbUIsQ0FBQztNQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQWtCLENBQXFCLENBQUMsRUFBQyw4QkFBOEIsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBc0IsQ0FBbUIsQ0FBQztNQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQWlCLENBQXFCLENBQUMsRUFBQyw0Q0FBNEM7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFRLENBQXFCLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQWUsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBYyxDQUFtQixDQUFDLEVBQUMsbUJBQW1CO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNLLEVBQUU7TUFBQ2UsRUFBRSxFQUFDLCtEQUErRDtNQUFBRCxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQStELENBQUUsQ0FBQyxFQUFDLDhCQUE4QixlQUFDLElBQUF2QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLEVBQUU7UUFBQWdCLFFBQUEsRUFBRTtNQUFNLENBQWlCLENBQUMsRUFBQyxrQ0FBa0M7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNTLENBQUM7TUFBQVUsUUFBQSxHQUFFLE9BQU8sZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDQyxDQUFDO1FBQUNxQixJQUFJLEVBQUMsaUJBQWlCO1FBQUFILFFBQUEsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBVyxDQUFtQjtNQUFDLENBQWUsQ0FBQyxFQUFDLG9DQUFvQyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUFVLENBQW1CLENBQUMsRUFBQyxxREFBcUQ7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNZLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBMEMsQ0FBcUIsQ0FBQyxFQUFDLDhCQUE4QjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQThDLENBQXFCLENBQUMsRUFBQyxxRkFBcUYsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBYyxDQUFtQixDQUFDLEVBQUMsV0FBVyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQU0sQ0FBbUIsQ0FBQyxFQUFDLHlEQUF5RCxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyxlQUFlLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQVUsQ0FBbUIsQ0FBQyxFQUFDLGFBQWEsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBWSxDQUFtQixDQUFDLEVBQUMsR0FBRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxHQUFFLDBCQUEwQixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7WUFBQWlCLFFBQUEsRUFBRTtVQUFlLENBQW1CLENBQUM7UUFBQSxDQUFvQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFNLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQVMsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBTyxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQVEsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsUUFBUSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFRLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQVEsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsc0dBQXNHLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQXlCLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBVSxDQUFxQixDQUFDLEVBQUMsb0JBQW9CLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQVEsQ0FBbUIsQ0FBQyxFQUFDLFlBQVk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUEyQixDQUFxQixDQUFDLEVBQUMsd0RBQXdELGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQVUsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsUUFBUSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFPLENBQW1CLENBQUMsRUFBQyxrQkFBa0IsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFxQixDQUFxQixDQUFDLEVBQUMsc0JBQXNCLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQW1CLENBQW1CLENBQUMsRUFBQyxnREFBZ0QsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBa0IsQ0FBbUIsQ0FBQyxFQUFDLG9CQUFvQixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFnQixDQUFtQixDQUFDLEVBQUMsa0JBQWtCO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNLLEVBQUU7TUFBQ2UsRUFBRSxFQUFDLDRCQUE0QjtNQUFBRCxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQTRCLENBQUUsQ0FBQyxFQUFDLDhCQUE4QjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBVSxRQUFBLEdBQUUsU0FBUyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUEwQixDQUFtQixDQUFDLEVBQUMsZ0JBQWdCLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBUSxRQUFBLEdBQUUsU0FBUyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFZLENBQW1CLENBQUM7TUFBQSxDQUFvQixDQUFDLEVBQUMsbURBQW1ELGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBaUIsUUFBQSxFQUFFO01BQU0sQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1FBQUFpQixRQUFBLEVBQUU7TUFBVSxDQUFtQixDQUFDLEVBQUMsNkVBQTZFLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBZ0IsUUFBQSxFQUFFO01BQTBCLENBQWlCLENBQUMsRUFBQywrRUFBK0U7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNVLEdBQUc7TUFBQVMsUUFBQSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7UUFBQ3FCLFNBQVMsRUFBQyxjQUFjO1FBQUFKLFFBQUEsRUFBRTtNQUE0aEMsQ0FBbUI7SUFBQyxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNTLENBQUM7TUFBQVUsUUFBQSxFQUFFO0lBQTRCLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1ksRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsR0FBRSxlQUFlLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBaUIsUUFBQSxFQUFFO1VBQVcsQ0FBbUIsQ0FBQztRQUFBLENBQW9CLENBQUMsRUFBQywrSUFBK0ksZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBUyxDQUFtQixDQUFDLEVBQUMsaUJBQWlCLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQU0sQ0FBbUIsQ0FBQyxFQUFDLFVBQVUsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsSUFBSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxHQUFFLHlCQUF5QixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7WUFBQWlCLFFBQUEsRUFBRTtVQUFZLENBQW1CLENBQUM7UUFBQSxDQUFvQixDQUFDLEVBQUMsY0FBYyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFLLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQVUsQ0FBbUIsQ0FBQyxFQUFDLHVCQUF1QixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFrQyxDQUFtQixDQUFDLEVBQUMsb0NBQW9DLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQXNCLENBQW1CLENBQUMsRUFBQyxzRUFBc0UsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDQyxDQUFDO1VBQUNxQixJQUFJLEVBQUMsMEJBQTBCO1VBQUFILFFBQUEsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1lBQUFpQixRQUFBLEVBQUU7VUFBb0IsQ0FBbUI7UUFBQyxDQUFlLENBQUMsRUFBQyxvQkFBb0I7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUErQixDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFRLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQVksQ0FBbUIsQ0FBQyxFQUFDLG1DQUFtQztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDSyxFQUFFO01BQUNlLEVBQUUsRUFBQyw2QkFBNkI7TUFBQUQsUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUE2QixDQUFFLENBQUMsRUFBQywrQkFBK0I7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNTLENBQUM7TUFBQVUsUUFBQSxHQUFFLFFBQVEsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUE4QixDQUFxQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNDLENBQUM7UUFBQ3FCLElBQUksRUFBQyx3QkFBd0I7UUFBQUgsUUFBQSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFrQixDQUFtQjtNQUFDLENBQWUsQ0FBQyxFQUFDLHVCQUF1QixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUFTLENBQW1CLENBQUMsRUFBQyxvQkFBb0IsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1FBQUFpQixRQUFBLEVBQUU7TUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1FBQUFpQixRQUFBLEVBQUU7TUFBYSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUFpQixDQUFtQixDQUFDLEVBQUMsOEVBQThFLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBaUIsUUFBQSxFQUFFO01BQXNCLENBQW1CLENBQUMsRUFBQyxtR0FBbUc7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNTLENBQUM7TUFBQVUsUUFBQSxHQUFFLE1BQU0sZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFhLENBQXFCLENBQUMsRUFBQyw4REFBOEQ7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNVLEdBQUc7TUFBQVMsUUFBQSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7UUFBQ3FCLFNBQVMsRUFBQyxjQUFjO1FBQUFKLFFBQUEsRUFBRTtNQUF1Z0QsQ0FBbUI7SUFBQyxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNTLENBQUM7TUFBQVUsUUFBQSxHQUFFLGtDQUFrQyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUFRLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBaUIsUUFBQSxFQUFFO01BQVUsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1FBQUFpQixRQUFBLEVBQUU7TUFBUyxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUFPLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBaUIsUUFBQSxFQUFFO01BQVEsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1FBQUFpQixRQUFBLEVBQUU7TUFBUSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUFRLENBQW1CLENBQUMsRUFBQyxvRkFBb0Y7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNLLEVBQUU7TUFBQ2UsRUFBRSxFQUFDLG9CQUFvQjtNQUFBRCxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQW9CLENBQUUsQ0FBQyxFQUFDLHNCQUFzQjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBVSxRQUFBLEdBQUUsS0FBSyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNDLENBQUM7UUFBQ3FCLElBQUksRUFBQyw0QkFBNEI7UUFBQUgsUUFBQSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFzQixDQUFtQjtNQUFDLENBQWUsQ0FBQyxFQUFDLGlEQUFpRCxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUFXLENBQW1CLENBQUMsRUFBQyxPQUFPO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVSxHQUFHO01BQUFTLFFBQUEsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1FBQUNxQixTQUFTLEVBQUMsZUFBZTtRQUFBSixRQUFBLEVBQUU7TUFBeUssQ0FBbUI7SUFBQyxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNTLENBQUM7TUFBQVUsUUFBQSxHQUFFLHFGQUFxRixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUFTLENBQW1CLENBQUMsRUFBQyxrQkFBa0I7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNLLEVBQUU7TUFBQ2UsRUFBRSxFQUFDLHVCQUF1QjtNQUFBRCxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQXVCLENBQUUsQ0FBQyxFQUFDLHlCQUF5QjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBVSxRQUFBLEdBQUUsMkZBQTJGLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0MsQ0FBQztRQUFDcUIsSUFBSSxFQUFDLHdCQUF3QjtRQUFBSCxRQUFBLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQWtCLENBQW1CO01BQUMsQ0FBZSxDQUFDLEVBQUMsR0FBRztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1UsR0FBRztNQUFBUyxRQUFBLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFDcUIsU0FBUyxFQUFDLGNBQWM7UUFBQUosUUFBQSxFQUFFO01BQW1OLENBQW1CO0lBQUMsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDSyxFQUFFO01BQUNlLEVBQUUsRUFBQyxlQUFlO01BQUFELFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBZSxDQUFFLENBQUMsRUFBQyxpQkFBaUI7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNTLENBQUM7TUFBQVUsUUFBQSxFQUFFO0lBQXdDLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1UsR0FBRztNQUFBUyxRQUFBLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFDcUIsU0FBUyxFQUFDLGVBQWU7UUFBQUosUUFBQSxFQUFFO01BQThJLENBQW1CO0lBQUMsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDUyxDQUFDO01BQUFVLFFBQUEsR0FBRSxPQUFPLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBd0IsQ0FBcUIsQ0FBQyxFQUFDLHNCQUFzQjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1ksRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDUyxDQUFDO1VBQUFVLFFBQUEsR0FBRSxxQkFBcUIsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1lBQUFpQixRQUFBLEVBQUU7VUFBYSxDQUFtQixDQUFDLEVBQUMsaUNBQWlDO1FBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDUyxDQUFDO1VBQUFVLFFBQUEsRUFBRTtRQUFrTyxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNVLEdBQUc7VUFBQVMsUUFBQSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7WUFBQ3FCLFNBQVMsRUFBQyxlQUFlO1lBQUFKLFFBQUEsRUFBRTtVQUEwSSxDQUFtQjtRQUFDLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1MsQ0FBQztVQUFBVSxRQUFBLEdBQUUsK0hBQStILGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtZQUFBUSxRQUFBLEVBQUU7VUFBYyxDQUFxQixDQUFDLEVBQUMsK0NBQStDO1FBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDZSxFQUFFLEVBQUMsbUJBQW1CO01BQUFELFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBbUIsQ0FBRSxDQUFDLEVBQUMscUJBQXFCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDUyxDQUFDO01BQUFVLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBaUIsUUFBQSxFQUFFO01BQXFCLENBQW1CLENBQUMsRUFBQywrSEFBK0g7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNVLEdBQUc7TUFBQVMsUUFBQSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7UUFBQ3FCLFNBQVMsRUFBQyxlQUFlO1FBQUFKLFFBQUEsRUFBRTtNQUFvTixDQUFtQjtJQUFDLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDZSxFQUFFLEVBQUMsNENBQTRDO01BQUFELFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBNEMsQ0FBRSxDQUFDLEVBQUMsOENBQThDO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDWSxFQUFFO01BQUNXLFNBQVMsRUFBQyxvQkFBb0I7TUFBQUosUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1FBQUNnQixTQUFTLEVBQUMsZ0JBQWdCO1FBQUFKLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ00sS0FBSztVQUFDa0IsSUFBSSxFQUFDLFVBQVU7VUFBQ0MsUUFBUTtRQUFBLENBQUUsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBMkIsQ0FBbUIsQ0FBQyxFQUFDLHFDQUFxQyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQU0sQ0FBcUIsQ0FBQyxFQUFDLHdDQUF3QyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyw2Q0FBNkM7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQ2dCLFNBQVMsRUFBQyxnQkFBZ0I7UUFBQUosUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDTSxLQUFLO1VBQUNrQixJQUFJLEVBQUMsVUFBVTtVQUFDQyxRQUFRO1FBQUEsQ0FBRSxDQUFDLEVBQUMsR0FBRyxFQUFFLGlDQUFpQyxlQUFDLElBQUE1QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFZLENBQW1CLENBQUMsRUFBQyxvQ0FBb0MsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBSyxDQUFtQixDQUFDLEVBQUMscUJBQXFCO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1FBQUNnQixTQUFTLEVBQUMsZ0JBQWdCO1FBQUFKLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ00sS0FBSztVQUFDa0IsSUFBSSxFQUFDLFVBQVU7VUFBQ0MsUUFBUTtRQUFBLENBQUUsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBZSxDQUFtQixDQUFDLEVBQUMsbUJBQW1CLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQWtCLENBQW1CLENBQUMsRUFBQyxTQUFTLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBYSxDQUFxQixDQUFDLEVBQUMsaURBQWlEO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1FBQUNnQixTQUFTLEVBQUMsZ0JBQWdCO1FBQUFKLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ00sS0FBSztVQUFDa0IsSUFBSSxFQUFDLFVBQVU7VUFBQ0MsUUFBUTtRQUFBLENBQUUsQ0FBQyxFQUFDLEdBQUcsRUFBRSxzQkFBc0IsZUFBQyxJQUFBNUIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFzQixDQUFtQixDQUFDLEVBQUMsR0FBRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtRQUFDZ0IsU0FBUyxFQUFDLGdCQUFnQjtRQUFBSixRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNNLEtBQUs7VUFBQ2tCLElBQUksRUFBQyxVQUFVO1VBQUNDLFFBQVE7UUFBQSxDQUFFLENBQUMsRUFBQyxHQUFHLEVBQUUseUNBQXlDO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1FBQUNnQixTQUFTLEVBQUMsZ0JBQWdCO1FBQUFKLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ00sS0FBSztVQUFDa0IsSUFBSSxFQUFDLFVBQVU7VUFBQ0MsUUFBUTtRQUFBLENBQUUsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBZSxDQUFtQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUMsRUFBQyxtRkFBbUY7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUM7RUFBQSxDQUFFLENBQUM7QUFDanJrQjtBQUNlLFNBQVNPLFVBQVVBLENBQUMzQixLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUU7RUFDN0MsTUFBTTtJQUFDNEIsT0FBTyxFQUFFQztFQUFTLENBQUMsR0FBRztJQUMzQixHQUFHLElBQUFmLDZCQUFrQixFQUFDLENBQUM7SUFDdkIsR0FBR2QsS0FBSyxDQUFDZTtFQUNYLENBQUM7RUFDRCxPQUFPYyxTQUFTLGdCQUFHLElBQUEvQixXQUFBLENBQUF3QixHQUFBLEVBQUNPLFNBQVM7SUFBQSxHQUFLN0IsS0FBSztJQUFBb0IsUUFBQSxlQUFFLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUN2QixpQkFBaUI7TUFBQSxHQUFLQztJQUFLLENBQUc7RUFBQyxDQUFXLENBQUMsR0FBR0QsaUJBQWlCLENBQUNDLEtBQUssQ0FBQztBQUNsSDtBQUFDOEIsRUFBQSxHQU51QkgsVUFBVTtBQU9sQyxTQUFTVixvQkFBb0JBLENBQUNJLEVBQUUsRUFBRVUsU0FBUyxFQUFFQyxLQUFLLEVBQUU7RUFDbEQsTUFBTSxJQUFJQyxLQUFLLENBQUMsV0FBVyxJQUFJRixTQUFTLEdBQUcsV0FBVyxHQUFHLFFBQVEsQ0FBQyxHQUFHLElBQUksR0FBR1YsRUFBRSxHQUFHLG9FQUFvRSxJQUFJVyxLQUFLLEdBQUcscUNBQXFDLEdBQUdBLEtBQUssR0FBRyxvREFBb0QsR0FBRyxFQUFFLENBQUMsQ0FBQztBQUM5UTtBQUFDLElBQUFGLEVBQUE7QUFBQUksWUFBQSxDQUFBSixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}