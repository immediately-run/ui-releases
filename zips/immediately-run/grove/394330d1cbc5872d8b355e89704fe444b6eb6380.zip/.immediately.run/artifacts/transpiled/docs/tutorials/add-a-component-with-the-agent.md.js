var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      blockquote: "blockquote",
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      img: "img",
      li: "li",
      ol: "ol",
      p: "p",
      pre: "pre",
      strong: "strong",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "add-a-component-to-grove-with-the-coding-agent",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "add-a-component-to-grove-with-the-coding-agent"
      }), "Add a component to Grove with the coding agent."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["A step-by-step walkthrough: build a real Grove MDX component — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "<KeyValue>"
      }), ", a\ncompact definition list for contact details and quick facts — by ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "asking the\nin-browser coding agent"
      }), ", not by typing the files yourself. Every step below is\ntaken from an actual end-to-end run; the screenshots are that run."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["If you'd rather build the same kind of component ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "by hand"
      }), ", see\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "./creating-a-component.md",
        children: "creating-a-component.md"
      }), ". For how the agent is wired\nand its rough edges in general, see\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "./building-with-the-in-browser-agent.md",
        children: "building-with-the-in-browser-agent.md"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Honest summary up front."
        }), " The agent built, registered, and demoed a working\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<KeyValue>"
        }), " in one prompt — three files, correct on the first try. On the agent\nbuild used for this walkthrough it then ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "could not add the component's CSS"
        }), " to\nGrove's large shared stylesheet, because its only write tool overwrote whole files.\nThat split — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "great at new files, stuck on big-file edits"
        }), " — was the main lesson\nhere. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "It's since been fixed:"
        }), " the agent gained an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "edit_file"
        }), " (string-replace)\ntool (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "https://github.com/immediately-run/agent-demo/pull/12",
          children: "agent-demo #12"
        }), ") so it\npatches large files in place. The CSS step below is kept as the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "pre-fix"
        }), " account\nplus the by-hand workaround for any agent build that predates that tool."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "what-you-need",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "what-you-need"
      }), "What you need"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["A Grove site loaded on immediately.run (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "local.immediately.run"
        }), " for the local\nhost, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "immediately.run"
        }), " for prod — never ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "localhost"
        }), ")."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["Signed in, with an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "OpenRouter key stored"
        }), " and a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "model preference set"
        }), " once\n(the agent runs on the host's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "llm.chat"
        }), " service; it never sees your key). If you\nhaven't done this, do the one-time setup in\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "./building-with-the-in-browser-agent.md#2-set-the-provider-and-model-one-time",
          children: "building-with-the-in-browser-agent.md"
        }), ".\nThis run used ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "z-ai/glm-5.2"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["A finger free for ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Touch ID"
        }), " — see step 4."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "step-1-load-grove-with-a-writable-mount",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "step-1-load-grove-with-a-writable-mount"
      }), "Step 1 — Load Grove with a writable mount"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Open Grove ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "from GitHub"
      }), " (a local ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "immediately.run dev"
      }), " mount is read-only, so the\nagent can't edit it):"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "https://local.immediately.run/edit/github/immediately-run/grove/main/\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "This gives the agent a read-write, copy-on-write mount of Grove's working tree —\nedits live in the browser until you publish them with Contribute."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "step-2-open-the-agents-activity",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "step-2-open-the-agents-activity"
      }), "Step 2 — Open the Agents activity"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Click ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Agents"
      }), " in the left activity rail. The main pane becomes the conversation;\nits header reads \"… tools (catalog + files)\" — the agent's filesystem tools\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "read_file"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "write_file"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "list_dir"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "glob"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "grep"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "stat"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "delete_file"
      }), ")\nmerged with Grove's capability catalog. Those file tools are scoped to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Grove's"
      }), "\nworking tree, so the agent reads and writes the app you're looking at."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "step-3-write-the-prompt",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "step-3-write-the-prompt"
      }), "Step 3 — Write the prompt"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Give the agent the conventions up front so it doesn't have to guess — point it at\nthe same files a human would read first. The exact prompt used here:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: ["Add a new MDX component ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<KeyValue>"
        }), " to this Grove site — a compact definition\nlist of label/value pairs (e.g. contact details). Follow Grove's conventions:\n(1) First read ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/components/Quote.tsx"
        }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/mdxComponents.ts"
        }), ", and grep for\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "\"grove-quote\""
        }), " to find where the component CSS lives. (2) Create\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/components/KeyValue.tsx"
        }), ": an import-free engine component, default export\nonly, taking a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "pairs"
        }), " prop of ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "{label, value}[]"
        }), " (value may be a string or\nReactNode); render a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<dl class=\"grove-keyvalue\">"
        }), " of ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<dt>"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<dd>"
        }), " pairs.\n(3) Register ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "KeyValue"
        }), " in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/mdxComponents.ts"
        }), ". (4) Add ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".grove-keyvalue"
        }), "\nstyles next to the other component styles, using the design tokens (hairline\nborders, Space Mono for the labels). (5) Add a demo ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<KeyValue>"
        }), " block to\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "content/teams/engineering.mdx"
        }), " (team lead, Slack channel, on-call). Keep it small\nand idiomatic. When done, summarize the files you changed."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.img, {
        src: "./images/agent-01-prompt.png",
        alt: "Typing the build prompt into the Agents conversation"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["A good prompt for an agent looks a lot like a good ticket: name the file paths,\nname the conventions to match, and name a concrete demo so you can ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "see"
      }), " the result."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "step-4-run-and-approve-touch-id",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "step-4-run-and-approve-touch-id"
      }), "Step 4 — Run, and approve Touch ID"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Click ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Run"
      }), ". The first model call raises a native ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Touch ID / passkey"
      }), " prompt\nto unseal your provider key — approve it."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Heads-up (a real rough edge):"
        }), " a build is a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "loop"
        }), " of model calls, and the\nunseal isn't cached across them, so you'll be prompted ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "several times"
        }), " during one\nbuild (this run made five model calls and asked for Touch ID about three times).\nFor a one-shot question it's a single tap; for an agent loop it's several. Keep a\nhand near the keyboard."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "step-5-watch-the-tool-loop",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "step-5-watch-the-tool-loop"
      }), "Step 5 — Watch the tool loop"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The agent works the plan with its tools: it reads ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "Quote.tsx"
      }), " and\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/mdxComponents.ts"
      }), ", greps for ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "grove-quote"
      }), " to locate the styles, reads the\ntarget content file, then writes. In this run it created and wired everything on the\nfirst pass:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["✓ ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["wrote ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "src/components/KeyValue.tsx"
          })]
        }), " (the component, 1115 bytes)"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["✓ ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["wrote ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "src/mdxComponents.ts"
          })]
        }), " (registered ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "KeyValue"
        }), " in the MDX map)"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["✓ ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["wrote ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "content/teams/engineering.mdx"
          })]
        }), " (the demo block)"]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.img, {
        src: "./images/agent-02-toolloop.png",
        alt: "The agent's read \u2192 write tool loop in the conversation"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "The component it produced is clean, import-free, and idiomatic — no edits needed:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-tsx",
        children: "import type { ReactNode } from 'react';\n\ninterface Pair {\n  /** Label — rendered in Space Mono, uppercased. */\n  label: string;\n  /** Value — a plain string or arbitrary ReactNode (links, code, etc.). */\n  value: ReactNode;\n}\n\ninterface Props {\n  /** Label/value pairs, rendered top-to-bottom as <dt>/<dd> rows. */\n  pairs: Pair[];\n}\n\n// Import-free engine component: a compact definition list of label/value pairs…\nexport default function KeyValue({ pairs }: Props) {\n  return (\n    <dl className=\"grove-keyvalue\">\n      {pairs.map((p, i) => (\n        <div className=\"grove-keyvalue__row\" key={i}>\n          <dt className=\"grove-keyvalue__label\">{p.label}</dt>\n          <dd className=\"grove-keyvalue__value\">{p.value}</dd>\n        </div>\n      ))}\n    </dl>\n  );\n}\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["And the demo it added to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "content/teams/engineering.mdx"
      }), ":"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-mdx",
        children: "## Contact\n\n<KeyValue pairs={[\n  { label: 'Team lead', value: 'Grace Hopper' },\n  { label: 'Slack', value: '#eng-platform' },\n  { label: 'On-call', value: 'PagerDuty — eng-oncall rotation' },\n]} />\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "step-6-see-it-render",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "step-6-see-it-render"
      }), "Step 6 — See it render"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Navigate Grove to the page you seeded the demo into (the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Engineering"
      }), " entry). The\npreview hot-reloads and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "<KeyValue>"
      }), " renders the rows — the component, registration,\nand usage all work:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.img, {
        src: "./images/agent-03-rendered-and-css-stall.png",
        alt: "Grove rendering the KeyValue rows, with the agent grepping the large CSS file"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Notice two things in that screenshot. On the right, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "<KeyValue>"
      }), " renders the real\ndata (Grace Hopper, #eng-platform, the on-call rotation). On the left, the agent is\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["still grepping ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "GroveApp.css"
        })]
      }), " — which brings us to the one thing it couldn't do."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "step-7-where-the-agent-stalls-the-css",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "step-7-where-the-agent-stalls-the-css"
      }), "Step 7 — Where the agent stalls: the CSS"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The prompt asked for ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: ".grove-keyvalue"
      }), " styles too. The agent ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "never wrote them."
      }), " It\nread and grepped ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/GroveApp.css"
      }), " twenty-plus times across two attempts, announced\n\"now I'll add the styles\" repeatedly, and gave up each time — so ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "<KeyValue>"
      }), " renders\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "unstyled"
      }), " (a plain stacked list, not the two-column hairline layout)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The cause isn't the model being lazy. Grove keeps all component styles in one\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "~50 KB"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "GroveApp.css"
      }), ", and at the time of this run the agent's only writing tool,\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "write_file"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "overwrote the whole file"
      }), " — there was no patch / insert tool. To add\none rule, the agent would have to faithfully regenerate all 50,301 bytes, which it\nwon't (and shouldn't — a truncated rewrite would wipe every other component's styles).\nSo it looped looking for an \"insertion point\" the tool didn't offer."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Fixed."
        }), " The agent now has an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "edit_file"
          })
        }), " tool\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "https://github.com/immediately-run/agent-demo/pull/12",
          children: "agent-demo #12"
        }), ") that\nreplaces an exact, unique snippet — a surgical edit, no whole-file rewrite. On a\nbuild with that tool, the agent adds the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".grove-keyvalue"
        }), " rule itself (anchor on\nthe line after ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".grove-quote"
        }), ", insert the new block). The walkthrough above is from\na build ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "before"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "edit_file"
        }), " landed; if your agent still only offers ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "write_file"
        }), ",\nuse one of the workarounds below until the new tool is deployed."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["The rule of thumb still holds for ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "whole-file"
        }), " rewrites:"]
      }), " the agent is excellent\nat ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "creating new, small files"
      }), " and now at ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["surgical ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "edit_file"
        }), " changes"]
      }), ", but\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "don't ask it to rewrite a large file wholesale."
      }), " Two ways to finish the styling on\na pre-", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "edit_file"
      }), " build:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Do the CSS by hand"
        }), " in the platform editor — open ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/GroveApp.css"
        }), ", drop the\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".grove-keyvalue"
        }), " block in after ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".grove-quote"
        }), ". (This is the path used to finish\nthis run.)"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Keep component CSS small and local"
        }), " so the agent ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "can"
        }), " own it — e.g. a\nper-component ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "KeyValue.css"
        }), " imported from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "KeyValue.tsx"
        }), ", instead of one giant\nshared stylesheet. A small new file plays to the agent's strength."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["For reference, the styling to add — tokens from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/index.css"
      }), ", matching the rest\nof the vocabulary:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-css",
        children: ".grove-keyvalue { margin: 1.25rem 0; }\n.grove-keyvalue__row {\n  display: grid;\n  grid-template-columns: minmax(8rem, 12rem) 1fr;\n  gap: 1rem;\n  padding: 0.55rem 0;\n  border-bottom: 1px solid var(--border);\n}\n.grove-keyvalue__row:first-child { border-top: 1px solid var(--border); }\n.grove-keyvalue__label {\n  font-family: var(--mono);\n  font-size: 0.78rem;\n  letter-spacing: 0.04em;\n  text-transform: uppercase;\n  color: var(--ink-2);\n}\n.grove-keyvalue__value { color: var(--ink); }\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "step-8-review-and-publish",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "step-8-review-and-publish"
      }), "Step 8 — Review and publish"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["When the component looks right, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "review the diff"
      }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Contribute"
      }), " to open a PR —\nthe same flow as any other change. Read every hunk: the agent wrote real files in\nyour tree, so the PR review is your gate, not a formality."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "what-to-take-away",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "what-to-take-away"
      }), "What to take away"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Asking beats typing for new components."
        }), " One well-scoped prompt produced a\ncorrect, idiomatic ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<KeyValue>"
        }), " plus its registration and a working demo."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Give it the conventions."
        }), " Naming the files to read and the demo to add is what\nmakes the output match Grove instead of generic React."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Big-file edits used to be the wall; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "edit_file"
          }), " fixes the common case."]
        }), " With the\nstring-replace tool (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "https://github.com/immediately-run/agent-demo/pull/12",
          children: "agent-demo #12"
        }), ")\nthe agent patches large files in place. Still avoid asking it to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "rewrite"
        }), " a large\nfile wholesale, and structuring styles into small per-component files never hurts."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "You still review and publish."
        }), " The agent writes; Contribute + diff review is how\nthe change actually ships."]
      }), "\n"]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/tutorials/add-a-component-with-the-agent.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiYmxvY2txdW90ZSIsImNvZGUiLCJlbSIsImgxIiwiaDIiLCJpbWciLCJsaSIsIm9sIiwicCIsInByZSIsInN0cm9uZyIsInVsIiwiX3Byb3ZpZGVDb21wb25lbnRzIiwiY29tcG9uZW50cyIsIkhlYWRpbmdBbmNob3IiLCJfbWlzc2luZ01keFJlZmVyZW5jZSIsImpzeHMiLCJGcmFnbWVudCIsImNoaWxkcmVuIiwiaWQiLCJqc3giLCJocmVmIiwic3JjIiwiYWx0IiwiY2xhc3NOYW1lIiwiTURYQ29udGVudCIsIndyYXBwZXIiLCJNRFhMYXlvdXQiLCJfYyIsImNvbXBvbmVudCIsInBsYWNlIiwiRXJyb3IiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJhZGQtYS1jb21wb25lbnQtd2l0aC10aGUtYWdlbnQubWQiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgYTogXCJhXCIsXG4gICAgYmxvY2txdW90ZTogXCJibG9ja3F1b3RlXCIsXG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgZW06IFwiZW1cIixcbiAgICBoMTogXCJoMVwiLFxuICAgIGgyOiBcImgyXCIsXG4gICAgaW1nOiBcImltZ1wiLFxuICAgIGxpOiBcImxpXCIsXG4gICAgb2w6IFwib2xcIixcbiAgICBwOiBcInBcIixcbiAgICBwcmU6IFwicHJlXCIsXG4gICAgc3Ryb25nOiBcInN0cm9uZ1wiLFxuICAgIHVsOiBcInVsXCIsXG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9LCB7SGVhZGluZ0FuY2hvcn0gPSBfY29tcG9uZW50cztcbiAgaWYgKCFIZWFkaW5nQW5jaG9yKSBfbWlzc2luZ01keFJlZmVyZW5jZShcIkhlYWRpbmdBbmNob3JcIiwgdHJ1ZSk7XG4gIHJldHVybiA8PjxfY29tcG9uZW50cy5oMSBpZD1cImFkZC1hLWNvbXBvbmVudC10by1ncm92ZS13aXRoLXRoZS1jb2RpbmctYWdlbnRcIj48SGVhZGluZ0FuY2hvciBpZD1cImFkZC1hLWNvbXBvbmVudC10by1ncm92ZS13aXRoLXRoZS1jb2RpbmctYWdlbnRcIiAvPntcIkFkZCBhIGNvbXBvbmVudCB0byBHcm92ZSB3aXRoIHRoZSBjb2RpbmcgYWdlbnQuXCJ9PC9fY29tcG9uZW50cy5oMT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJBIHN0ZXAtYnktc3RlcCB3YWxrdGhyb3VnaDogYnVpbGQgYSByZWFsIEdyb3ZlIE1EWCBjb21wb25lbnQg4oCUIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjxLZXlWYWx1ZT5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBhXFxuY29tcGFjdCBkZWZpbml0aW9uIGxpc3QgZm9yIGNvbnRhY3QgZGV0YWlscyBhbmQgcXVpY2sgZmFjdHMg4oCUIGJ5IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiYXNraW5nIHRoZVxcbmluLWJyb3dzZXIgY29kaW5nIGFnZW50XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBub3QgYnkgdHlwaW5nIHRoZSBmaWxlcyB5b3Vyc2VsZi4gRXZlcnkgc3RlcCBiZWxvdyBpc1xcbnRha2VuIGZyb20gYW4gYWN0dWFsIGVuZC10by1lbmQgcnVuOyB0aGUgc2NyZWVuc2hvdHMgYXJlIHRoYXQgcnVuLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJJZiB5b3UnZCByYXRoZXIgYnVpbGQgdGhlIHNhbWUga2luZCBvZiBjb21wb25lbnQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJieSBoYW5kXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBzZWVcXG5cIn08X2NvbXBvbmVudHMuYSBocmVmPVwiLi9jcmVhdGluZy1hLWNvbXBvbmVudC5tZFwiPntcImNyZWF0aW5nLWEtY29tcG9uZW50Lm1kXCJ9PC9fY29tcG9uZW50cy5hPntcIi4gRm9yIGhvdyB0aGUgYWdlbnQgaXMgd2lyZWRcXG5hbmQgaXRzIHJvdWdoIGVkZ2VzIGluIGdlbmVyYWwsIHNlZVxcblwifTxfY29tcG9uZW50cy5hIGhyZWY9XCIuL2J1aWxkaW5nLXdpdGgtdGhlLWluLWJyb3dzZXItYWdlbnQubWRcIj57XCJidWlsZGluZy13aXRoLXRoZS1pbi1icm93c2VyLWFnZW50Lm1kXCJ9PC9fY29tcG9uZW50cy5hPntcIi5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJIb25lc3Qgc3VtbWFyeSB1cCBmcm9udC5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhlIGFnZW50IGJ1aWx0LCByZWdpc3RlcmVkLCBhbmQgZGVtb2VkIGEgd29ya2luZ1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcIjxLZXlWYWx1ZT5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGluIG9uZSBwcm9tcHQg4oCUIHRocmVlIGZpbGVzLCBjb3JyZWN0IG9uIHRoZSBmaXJzdCB0cnkuIE9uIHRoZSBhZ2VudFxcbmJ1aWxkIHVzZWQgZm9yIHRoaXMgd2Fsa3Rocm91Z2ggaXQgdGhlbiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImNvdWxkIG5vdCBhZGQgdGhlIGNvbXBvbmVudCdzIENTU1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB0b1xcbkdyb3ZlJ3MgbGFyZ2Ugc2hhcmVkIHN0eWxlc2hlZXQsIGJlY2F1c2UgaXRzIG9ubHkgd3JpdGUgdG9vbCBvdmVyd3JvdGUgd2hvbGUgZmlsZXMuXFxuVGhhdCBzcGxpdCDigJQgXCJ9PF9jb21wb25lbnRzLmVtPntcImdyZWF0IGF0IG5ldyBmaWxlcywgc3R1Y2sgb24gYmlnLWZpbGUgZWRpdHNcIn08L19jb21wb25lbnRzLmVtPntcIiDigJQgd2FzIHRoZSBtYWluIGxlc3NvblxcbmhlcmUuIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiSXQncyBzaW5jZSBiZWVuIGZpeGVkOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB0aGUgYWdlbnQgZ2FpbmVkIGFuIFwifTxfY29tcG9uZW50cy5jb2RlPntcImVkaXRfZmlsZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKHN0cmluZy1yZXBsYWNlKVxcbnRvb2wgKFwifTxfY29tcG9uZW50cy5hIGhyZWY9XCJodHRwczovL2dpdGh1Yi5jb20vaW1tZWRpYXRlbHktcnVuL2FnZW50LWRlbW8vcHVsbC8xMlwiPntcImFnZW50LWRlbW8gIzEyXCJ9PC9fY29tcG9uZW50cy5hPntcIikgc28gaXRcXG5wYXRjaGVzIGxhcmdlIGZpbGVzIGluIHBsYWNlLiBUaGUgQ1NTIHN0ZXAgYmVsb3cgaXMga2VwdCBhcyB0aGUgXCJ9PF9jb21wb25lbnRzLmVtPntcInByZS1maXhcIn08L19jb21wb25lbnRzLmVtPntcIiBhY2NvdW50XFxucGx1cyB0aGUgYnktaGFuZCB3b3JrYXJvdW5kIGZvciBhbnkgYWdlbnQgYnVpbGQgdGhhdCBwcmVkYXRlcyB0aGF0IHRvb2wuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTwvX2NvbXBvbmVudHMuYmxvY2txdW90ZT57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJ3aGF0LXlvdS1uZWVkXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJ3aGF0LXlvdS1uZWVkXCIgLz57XCJXaGF0IHlvdSBuZWVkXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIkEgR3JvdmUgc2l0ZSBsb2FkZWQgb24gaW1tZWRpYXRlbHkucnVuIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJsb2NhbC5pbW1lZGlhdGVseS5ydW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGZvciB0aGUgbG9jYWxcXG5ob3N0LCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJpbW1lZGlhdGVseS5ydW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGZvciBwcm9kIOKAlCBuZXZlciBcIn08X2NvbXBvbmVudHMuY29kZT57XCJsb2NhbGhvc3RcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJTaWduZWQgaW4sIHdpdGggYW4gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJPcGVuUm91dGVyIGtleSBzdG9yZWRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYW5kIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJtb2RlbCBwcmVmZXJlbmNlIHNldFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBvbmNlXFxuKHRoZSBhZ2VudCBydW5zIG9uIHRoZSBob3N0J3MgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibGxtLmNoYXRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHNlcnZpY2U7IGl0IG5ldmVyIHNlZXMgeW91ciBrZXkpLiBJZiB5b3VcXG5oYXZlbid0IGRvbmUgdGhpcywgZG8gdGhlIG9uZS10aW1lIHNldHVwIGluXFxuXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cIi4vYnVpbGRpbmctd2l0aC10aGUtaW4tYnJvd3Nlci1hZ2VudC5tZCMyLXNldC10aGUtcHJvdmlkZXItYW5kLW1vZGVsLW9uZS10aW1lXCI+e1wiYnVpbGRpbmctd2l0aC10aGUtaW4tYnJvd3Nlci1hZ2VudC5tZFwifTwvX2NvbXBvbmVudHMuYT57XCIuXFxuVGhpcyBydW4gdXNlZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ6LWFpL2dsbS01LjJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIkEgZmluZ2VyIGZyZWUgZm9yIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiVG91Y2ggSURcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHNlZSBzdGVwIDQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInN0ZXAtMS1sb2FkLWdyb3ZlLXdpdGgtYS13cml0YWJsZS1tb3VudFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic3RlcC0xLWxvYWQtZ3JvdmUtd2l0aC1hLXdyaXRhYmxlLW1vdW50XCIgLz57XCJTdGVwIDEg4oCUIExvYWQgR3JvdmUgd2l0aCBhIHdyaXRhYmxlIG1vdW50XCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJPcGVuIEdyb3ZlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZnJvbSBHaXRIdWJcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKGEgbG9jYWwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW1tZWRpYXRlbHkucnVuIGRldlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgbW91bnQgaXMgcmVhZC1vbmx5LCBzbyB0aGVcXG5hZ2VudCBjYW4ndCBlZGl0IGl0KTpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnByZT48X2NvbXBvbmVudHMuY29kZT57XCJodHRwczovL2xvY2FsLmltbWVkaWF0ZWx5LnJ1bi9lZGl0L2dpdGh1Yi9pbW1lZGlhdGVseS1ydW4vZ3JvdmUvbWFpbi9cXG5cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5wcmU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhpcyBnaXZlcyB0aGUgYWdlbnQgYSByZWFkLXdyaXRlLCBjb3B5LW9uLXdyaXRlIG1vdW50IG9mIEdyb3ZlJ3Mgd29ya2luZyB0cmVlIOKAlFxcbmVkaXRzIGxpdmUgaW4gdGhlIGJyb3dzZXIgdW50aWwgeW91IHB1Ymxpc2ggdGhlbSB3aXRoIENvbnRyaWJ1dGUuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInN0ZXAtMi1vcGVuLXRoZS1hZ2VudHMtYWN0aXZpdHlcIj48SGVhZGluZ0FuY2hvciBpZD1cInN0ZXAtMi1vcGVuLXRoZS1hZ2VudHMtYWN0aXZpdHlcIiAvPntcIlN0ZXAgMiDigJQgT3BlbiB0aGUgQWdlbnRzIGFjdGl2aXR5XCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJDbGljayBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIkFnZW50c1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBpbiB0aGUgbGVmdCBhY3Rpdml0eSByYWlsLiBUaGUgbWFpbiBwYW5lIGJlY29tZXMgdGhlIGNvbnZlcnNhdGlvbjtcXG5pdHMgaGVhZGVyIHJlYWRzIFxcXCLigKYgdG9vbHMgKGNhdGFsb2cgKyBmaWxlcylcXFwiIOKAlCB0aGUgYWdlbnQncyBmaWxlc3lzdGVtIHRvb2xzXFxuKFwifTxfY29tcG9uZW50cy5jb2RlPntcInJlYWRfZmlsZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIndyaXRlX2ZpbGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJsaXN0X2RpclwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcImdsb2JcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJncmVwXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3RhdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcImRlbGV0ZV9maWxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIilcXG5tZXJnZWQgd2l0aCBHcm92ZSdzIGNhcGFiaWxpdHkgY2F0YWxvZy4gVGhvc2UgZmlsZSB0b29scyBhcmUgc2NvcGVkIHRvIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiR3JvdmUnc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIlxcbndvcmtpbmcgdHJlZSwgc28gdGhlIGFnZW50IHJlYWRzIGFuZCB3cml0ZXMgdGhlIGFwcCB5b3UncmUgbG9va2luZyBhdC5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic3RlcC0zLXdyaXRlLXRoZS1wcm9tcHRcIj48SGVhZGluZ0FuY2hvciBpZD1cInN0ZXAtMy13cml0ZS10aGUtcHJvbXB0XCIgLz57XCJTdGVwIDMg4oCUIFdyaXRlIHRoZSBwcm9tcHRcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkdpdmUgdGhlIGFnZW50IHRoZSBjb252ZW50aW9ucyB1cCBmcm9udCBzbyBpdCBkb2Vzbid0IGhhdmUgdG8gZ3Vlc3Mg4oCUIHBvaW50IGl0IGF0XFxudGhlIHNhbWUgZmlsZXMgYSBodW1hbiB3b3VsZCByZWFkIGZpcnN0LiBUaGUgZXhhY3QgcHJvbXB0IHVzZWQgaGVyZTpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiQWRkIGEgbmV3IE1EWCBjb21wb25lbnQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiPEtleVZhbHVlPlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdG8gdGhpcyBHcm92ZSBzaXRlIOKAlCBhIGNvbXBhY3QgZGVmaW5pdGlvblxcbmxpc3Qgb2YgbGFiZWwvdmFsdWUgcGFpcnMgKGUuZy4gY29udGFjdCBkZXRhaWxzKS4gRm9sbG93IEdyb3ZlJ3MgY29udmVudGlvbnM6XFxuKDEpIEZpcnN0IHJlYWQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2NvbXBvbmVudHMvUXVvdGUudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhbmQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL21keENvbXBvbmVudHMudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBhbmQgZ3JlcCBmb3JcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJcXFwiZ3JvdmUtcXVvdGVcXFwiXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB0byBmaW5kIHdoZXJlIHRoZSBjb21wb25lbnQgQ1NTIGxpdmVzLiAoMikgQ3JlYXRlXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2NvbXBvbmVudHMvS2V5VmFsdWUudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjogYW4gaW1wb3J0LWZyZWUgZW5naW5lIGNvbXBvbmVudCwgZGVmYXVsdCBleHBvcnRcXG5vbmx5LCB0YWtpbmcgYSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJwYWlyc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcHJvcCBvZiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ7bGFiZWwsIHZhbHVlfVtdXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAodmFsdWUgbWF5IGJlIGEgc3RyaW5nIG9yXFxuUmVhY3ROb2RlKTsgcmVuZGVyIGEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiPGRsIGNsYXNzPVxcXCJncm92ZS1rZXl2YWx1ZVxcXCI+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBvZiBcIn08X2NvbXBvbmVudHMuY29kZT57XCI8ZHQ+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCI8ZGQ+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBwYWlycy5cXG4oMykgUmVnaXN0ZXIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiS2V5VmFsdWVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGluIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9tZHhDb21wb25lbnRzLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi4gKDQpIEFkZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCIuZ3JvdmUta2V5dmFsdWVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxuc3R5bGVzIG5leHQgdG8gdGhlIG90aGVyIGNvbXBvbmVudCBzdHlsZXMsIHVzaW5nIHRoZSBkZXNpZ24gdG9rZW5zIChoYWlybGluZVxcbmJvcmRlcnMsIFNwYWNlIE1vbm8gZm9yIHRoZSBsYWJlbHMpLiAoNSkgQWRkIGEgZGVtbyBcIn08X2NvbXBvbmVudHMuY29kZT57XCI8S2V5VmFsdWU+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBibG9jayB0b1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcImNvbnRlbnQvdGVhbXMvZW5naW5lZXJpbmcubWR4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAodGVhbSBsZWFkLCBTbGFjayBjaGFubmVsLCBvbi1jYWxsKS4gS2VlcCBpdCBzbWFsbFxcbmFuZCBpZGlvbWF0aWMuIFdoZW4gZG9uZSwgc3VtbWFyaXplIHRoZSBmaWxlcyB5b3UgY2hhbmdlZC5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5pbWcgc3JjPVwiLi9pbWFnZXMvYWdlbnQtMDEtcHJvbXB0LnBuZ1wiIGFsdD1cIlR5cGluZyB0aGUgYnVpbGQgcHJvbXB0IGludG8gdGhlIEFnZW50cyBjb252ZXJzYXRpb25cIiAvPjwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJBIGdvb2QgcHJvbXB0IGZvciBhbiBhZ2VudCBsb29rcyBhIGxvdCBsaWtlIGEgZ29vZCB0aWNrZXQ6IG5hbWUgdGhlIGZpbGUgcGF0aHMsXFxubmFtZSB0aGUgY29udmVudGlvbnMgdG8gbWF0Y2gsIGFuZCBuYW1lIGEgY29uY3JldGUgZGVtbyBzbyB5b3UgY2FuIFwifTxfY29tcG9uZW50cy5lbT57XCJzZWVcIn08L19jb21wb25lbnRzLmVtPntcIiB0aGUgcmVzdWx0LlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzdGVwLTQtcnVuLWFuZC1hcHByb3ZlLXRvdWNoLWlkXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzdGVwLTQtcnVuLWFuZC1hcHByb3ZlLXRvdWNoLWlkXCIgLz57XCJTdGVwIDQg4oCUIFJ1biwgYW5kIGFwcHJvdmUgVG91Y2ggSURcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkNsaWNrIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiUnVuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLiBUaGUgZmlyc3QgbW9kZWwgY2FsbCByYWlzZXMgYSBuYXRpdmUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJUb3VjaCBJRCAvIHBhc3NrZXlcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgcHJvbXB0XFxudG8gdW5zZWFsIHlvdXIgcHJvdmlkZXIga2V5IOKAlCBhcHByb3ZlIGl0LlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuYmxvY2txdW90ZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkhlYWRzLXVwIChhIHJlYWwgcm91Z2ggZWRnZSk6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGEgYnVpbGQgaXMgYSBcIn08X2NvbXBvbmVudHMuZW0+e1wibG9vcFwifTwvX2NvbXBvbmVudHMuZW0+e1wiIG9mIG1vZGVsIGNhbGxzLCBhbmQgdGhlXFxudW5zZWFsIGlzbid0IGNhY2hlZCBhY3Jvc3MgdGhlbSwgc28geW91J2xsIGJlIHByb21wdGVkIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wic2V2ZXJhbCB0aW1lc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBkdXJpbmcgb25lXFxuYnVpbGQgKHRoaXMgcnVuIG1hZGUgZml2ZSBtb2RlbCBjYWxscyBhbmQgYXNrZWQgZm9yIFRvdWNoIElEIGFib3V0IHRocmVlIHRpbWVzKS5cXG5Gb3IgYSBvbmUtc2hvdCBxdWVzdGlvbiBpdCdzIGEgc2luZ2xlIHRhcDsgZm9yIGFuIGFnZW50IGxvb3AgaXQncyBzZXZlcmFsLiBLZWVwIGFcXG5oYW5kIG5lYXIgdGhlIGtleWJvYXJkLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08L19jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic3RlcC01LXdhdGNoLXRoZS10b29sLWxvb3BcIj48SGVhZGluZ0FuY2hvciBpZD1cInN0ZXAtNS13YXRjaC10aGUtdG9vbC1sb29wXCIgLz57XCJTdGVwIDUg4oCUIFdhdGNoIHRoZSB0b29sIGxvb3BcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSBhZ2VudCB3b3JrcyB0aGUgcGxhbiB3aXRoIGl0cyB0b29sczogaXQgcmVhZHMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiUXVvdGUudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhbmRcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvbWR4Q29tcG9uZW50cy50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGdyZXBzIGZvciBcIn08X2NvbXBvbmVudHMuY29kZT57XCJncm92ZS1xdW90ZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdG8gbG9jYXRlIHRoZSBzdHlsZXMsIHJlYWRzIHRoZVxcbnRhcmdldCBjb250ZW50IGZpbGUsIHRoZW4gd3JpdGVzLiBJbiB0aGlzIHJ1biBpdCBjcmVhdGVkIGFuZCB3aXJlZCBldmVyeXRoaW5nIG9uIHRoZVxcbmZpcnN0IHBhc3M6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wi4pyTIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wid3JvdGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2NvbXBvbmVudHMvS2V5VmFsdWUudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAodGhlIGNvbXBvbmVudCwgMTExNSBieXRlcylcIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCLinJMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ3cm90ZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvbWR4Q29tcG9uZW50cy50c1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHJlZ2lzdGVyZWQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiS2V5VmFsdWVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGluIHRoZSBNRFggbWFwKVwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIuKckyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIndyb3RlIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNvbnRlbnQvdGVhbXMvZW5naW5lZXJpbmcubWR4XCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAodGhlIGRlbW8gYmxvY2spXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5pbWcgc3JjPVwiLi9pbWFnZXMvYWdlbnQtMDItdG9vbGxvb3AucG5nXCIgYWx0PVwiVGhlIGFnZW50J3MgcmVhZCDihpIgd3JpdGUgdG9vbCBsb29wIGluIHRoZSBjb252ZXJzYXRpb25cIiAvPjwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgY29tcG9uZW50IGl0IHByb2R1Y2VkIGlzIGNsZWFuLCBpbXBvcnQtZnJlZSwgYW5kIGlkaW9tYXRpYyDigJQgbm8gZWRpdHMgbmVlZGVkOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucHJlPjxfY29tcG9uZW50cy5jb2RlIGNsYXNzTmFtZT1cImxhbmd1YWdlLXRzeFwiPntcImltcG9ydCB0eXBlIHsgUmVhY3ROb2RlIH0gZnJvbSAncmVhY3QnO1xcblxcbmludGVyZmFjZSBQYWlyIHtcXG4gIC8qKiBMYWJlbCDigJQgcmVuZGVyZWQgaW4gU3BhY2UgTW9ubywgdXBwZXJjYXNlZC4gKi9cXG4gIGxhYmVsOiBzdHJpbmc7XFxuICAvKiogVmFsdWUg4oCUIGEgcGxhaW4gc3RyaW5nIG9yIGFyYml0cmFyeSBSZWFjdE5vZGUgKGxpbmtzLCBjb2RlLCBldGMuKS4gKi9cXG4gIHZhbHVlOiBSZWFjdE5vZGU7XFxufVxcblxcbmludGVyZmFjZSBQcm9wcyB7XFxuICAvKiogTGFiZWwvdmFsdWUgcGFpcnMsIHJlbmRlcmVkIHRvcC10by1ib3R0b20gYXMgPGR0Pi88ZGQ+IHJvd3MuICovXFxuICBwYWlyczogUGFpcltdO1xcbn1cXG5cXG4vLyBJbXBvcnQtZnJlZSBlbmdpbmUgY29tcG9uZW50OiBhIGNvbXBhY3QgZGVmaW5pdGlvbiBsaXN0IG9mIGxhYmVsL3ZhbHVlIHBhaXJz4oCmXFxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gS2V5VmFsdWUoeyBwYWlycyB9OiBQcm9wcykge1xcbiAgcmV0dXJuIChcXG4gICAgPGRsIGNsYXNzTmFtZT1cXFwiZ3JvdmUta2V5dmFsdWVcXFwiPlxcbiAgICAgIHtwYWlycy5tYXAoKHAsIGkpID0+IChcXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVxcXCJncm92ZS1rZXl2YWx1ZV9fcm93XFxcIiBrZXk9e2l9PlxcbiAgICAgICAgICA8ZHQgY2xhc3NOYW1lPVxcXCJncm92ZS1rZXl2YWx1ZV9fbGFiZWxcXFwiPntwLmxhYmVsfTwvZHQ+XFxuICAgICAgICAgIDxkZCBjbGFzc05hbWU9XFxcImdyb3ZlLWtleXZhbHVlX192YWx1ZVxcXCI+e3AudmFsdWV9PC9kZD5cXG4gICAgICAgIDwvZGl2PlxcbiAgICAgICkpfVxcbiAgICA8L2RsPlxcbiAgKTtcXG59XFxuXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMucHJlPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkFuZCB0aGUgZGVtbyBpdCBhZGRlZCB0byBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjb250ZW50L3RlYW1zL2VuZ2luZWVyaW5nLm1keFwifTwvX2NvbXBvbmVudHMuY29kZT57XCI6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wcmU+PF9jb21wb25lbnRzLmNvZGUgY2xhc3NOYW1lPVwibGFuZ3VhZ2UtbWR4XCI+e1wiIyMgQ29udGFjdFxcblxcbjxLZXlWYWx1ZSBwYWlycz17W1xcbiAgeyBsYWJlbDogJ1RlYW0gbGVhZCcsIHZhbHVlOiAnR3JhY2UgSG9wcGVyJyB9LFxcbiAgeyBsYWJlbDogJ1NsYWNrJywgdmFsdWU6ICcjZW5nLXBsYXRmb3JtJyB9LFxcbiAgeyBsYWJlbDogJ09uLWNhbGwnLCB2YWx1ZTogJ1BhZ2VyRHV0eSDigJQgZW5nLW9uY2FsbCByb3RhdGlvbicgfSxcXG5dfSAvPlxcblwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnByZT57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzdGVwLTYtc2VlLWl0LXJlbmRlclwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic3RlcC02LXNlZS1pdC1yZW5kZXJcIiAvPntcIlN0ZXAgNiDigJQgU2VlIGl0IHJlbmRlclwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiTmF2aWdhdGUgR3JvdmUgdG8gdGhlIHBhZ2UgeW91IHNlZWRlZCB0aGUgZGVtbyBpbnRvICh0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJFbmdpbmVlcmluZ1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBlbnRyeSkuIFRoZVxcbnByZXZpZXcgaG90LXJlbG9hZHMgYW5kIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjxLZXlWYWx1ZT5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHJlbmRlcnMgdGhlIHJvd3Mg4oCUIHRoZSBjb21wb25lbnQsIHJlZ2lzdHJhdGlvbixcXG5hbmQgdXNhZ2UgYWxsIHdvcms6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5pbWcgc3JjPVwiLi9pbWFnZXMvYWdlbnQtMDMtcmVuZGVyZWQtYW5kLWNzcy1zdGFsbC5wbmdcIiBhbHQ9XCJHcm92ZSByZW5kZXJpbmcgdGhlIEtleVZhbHVlIHJvd3MsIHdpdGggdGhlIGFnZW50IGdyZXBwaW5nIHRoZSBsYXJnZSBDU1MgZmlsZVwiIC8+PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIk5vdGljZSB0d28gdGhpbmdzIGluIHRoYXQgc2NyZWVuc2hvdC4gT24gdGhlIHJpZ2h0LCBcIn08X2NvbXBvbmVudHMuY29kZT57XCI8S2V5VmFsdWU+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiByZW5kZXJzIHRoZSByZWFsXFxuZGF0YSAoR3JhY2UgSG9wcGVyLCAjZW5nLXBsYXRmb3JtLCB0aGUgb24tY2FsbCByb3RhdGlvbikuIE9uIHRoZSBsZWZ0LCB0aGUgYWdlbnQgaXNcXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInN0aWxsIGdyZXBwaW5nIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkdyb3ZlQXBwLmNzc1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHdoaWNoIGJyaW5ncyB1cyB0byB0aGUgb25lIHRoaW5nIGl0IGNvdWxkbid0IGRvLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzdGVwLTctd2hlcmUtdGhlLWFnZW50LXN0YWxscy10aGUtY3NzXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzdGVwLTctd2hlcmUtdGhlLWFnZW50LXN0YWxscy10aGUtY3NzXCIgLz57XCJTdGVwIDcg4oCUIFdoZXJlIHRoZSBhZ2VudCBzdGFsbHM6IHRoZSBDU1NcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSBwcm9tcHQgYXNrZWQgZm9yIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi5ncm92ZS1rZXl2YWx1ZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgc3R5bGVzIHRvby4gVGhlIGFnZW50IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibmV2ZXIgd3JvdGUgdGhlbS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgSXRcXG5yZWFkIGFuZCBncmVwcGVkIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9Hcm92ZUFwcC5jc3NcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHR3ZW50eS1wbHVzIHRpbWVzIGFjcm9zcyB0d28gYXR0ZW1wdHMsIGFubm91bmNlZFxcblxcXCJub3cgSSdsbCBhZGQgdGhlIHN0eWxlc1xcXCIgcmVwZWF0ZWRseSwgYW5kIGdhdmUgdXAgZWFjaCB0aW1lIOKAlCBzbyBcIn08X2NvbXBvbmVudHMuY29kZT57XCI8S2V5VmFsdWU+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiByZW5kZXJzXFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ1bnN0eWxlZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoYSBwbGFpbiBzdGFja2VkIGxpc3QsIG5vdCB0aGUgdHdvLWNvbHVtbiBoYWlybGluZSBsYXlvdXQpLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgY2F1c2UgaXNuJ3QgdGhlIG1vZGVsIGJlaW5nIGxhenkuIEdyb3ZlIGtlZXBzIGFsbCBjb21wb25lbnQgc3R5bGVzIGluIG9uZVxcblwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wifjUwIEtCXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkdyb3ZlQXBwLmNzc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGFuZCBhdCB0aGUgdGltZSBvZiB0aGlzIHJ1biB0aGUgYWdlbnQncyBvbmx5IHdyaXRpbmcgdG9vbCxcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJ3cml0ZV9maWxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJvdmVyd3JvdGUgdGhlIHdob2xlIGZpbGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHRoZXJlIHdhcyBubyBwYXRjaCAvIGluc2VydCB0b29sLiBUbyBhZGRcXG5vbmUgcnVsZSwgdGhlIGFnZW50IHdvdWxkIGhhdmUgdG8gZmFpdGhmdWxseSByZWdlbmVyYXRlIGFsbCA1MCwzMDEgYnl0ZXMsIHdoaWNoIGl0XFxud29uJ3QgKGFuZCBzaG91bGRuJ3Qg4oCUIGEgdHJ1bmNhdGVkIHJld3JpdGUgd291bGQgd2lwZSBldmVyeSBvdGhlciBjb21wb25lbnQncyBzdHlsZXMpLlxcblNvIGl0IGxvb3BlZCBsb29raW5nIGZvciBhbiBcXFwiaW5zZXJ0aW9uIHBvaW50XFxcIiB0aGUgdG9vbCBkaWRuJ3Qgb2ZmZXIuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRml4ZWQuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRoZSBhZ2VudCBub3cgaGFzIGFuIFwifTxfY29tcG9uZW50cy5zdHJvbmc+PF9jb21wb25lbnRzLmNvZGU+e1wiZWRpdF9maWxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB0b29sXFxuKFwifTxfY29tcG9uZW50cy5hIGhyZWY9XCJodHRwczovL2dpdGh1Yi5jb20vaW1tZWRpYXRlbHktcnVuL2FnZW50LWRlbW8vcHVsbC8xMlwiPntcImFnZW50LWRlbW8gIzEyXCJ9PC9fY29tcG9uZW50cy5hPntcIikgdGhhdFxcbnJlcGxhY2VzIGFuIGV4YWN0LCB1bmlxdWUgc25pcHBldCDigJQgYSBzdXJnaWNhbCBlZGl0LCBubyB3aG9sZS1maWxlIHJld3JpdGUuIE9uIGFcXG5idWlsZCB3aXRoIHRoYXQgdG9vbCwgdGhlIGFnZW50IGFkZHMgdGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi5ncm92ZS1rZXl2YWx1ZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcnVsZSBpdHNlbGYgKGFuY2hvciBvblxcbnRoZSBsaW5lIGFmdGVyIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi5ncm92ZS1xdW90ZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGluc2VydCB0aGUgbmV3IGJsb2NrKS4gVGhlIHdhbGt0aHJvdWdoIGFib3ZlIGlzIGZyb21cXG5hIGJ1aWxkIFwifTxfY29tcG9uZW50cy5lbT57XCJiZWZvcmVcIn08L19jb21wb25lbnRzLmVtPntcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJlZGl0X2ZpbGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGxhbmRlZDsgaWYgeW91ciBhZ2VudCBzdGlsbCBvbmx5IG9mZmVycyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ3cml0ZV9maWxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIixcXG51c2Ugb25lIG9mIHRoZSB3b3JrYXJvdW5kcyBiZWxvdyB1bnRpbCB0aGUgbmV3IHRvb2wgaXMgZGVwbG95ZWQuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTwvX2NvbXBvbmVudHMuYmxvY2txdW90ZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlRoZSBydWxlIG9mIHRodW1iIHN0aWxsIGhvbGRzIGZvciBcIn08X2NvbXBvbmVudHMuZW0+e1wid2hvbGUtZmlsZVwifTwvX2NvbXBvbmVudHMuZW0+e1wiIHJld3JpdGVzOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB0aGUgYWdlbnQgaXMgZXhjZWxsZW50XFxuYXQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJjcmVhdGluZyBuZXcsIHNtYWxsIGZpbGVzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGFuZCBub3cgYXQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJzdXJnaWNhbCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJlZGl0X2ZpbGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNoYW5nZXNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIsIGJ1dFxcblwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZG9uJ3QgYXNrIGl0IHRvIHJld3JpdGUgYSBsYXJnZSBmaWxlIHdob2xlc2FsZS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVHdvIHdheXMgdG8gZmluaXNoIHRoZSBzdHlsaW5nIG9uXFxuYSBwcmUtXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZWRpdF9maWxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBidWlsZDpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkRvIHRoZSBDU1MgYnkgaGFuZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBpbiB0aGUgcGxhdGZvcm0gZWRpdG9yIOKAlCBvcGVuIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9Hcm92ZUFwcC5jc3NcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBkcm9wIHRoZVxcblwifTxfY29tcG9uZW50cy5jb2RlPntcIi5ncm92ZS1rZXl2YWx1ZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYmxvY2sgaW4gYWZ0ZXIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLmdyb3ZlLXF1b3RlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi4gKFRoaXMgaXMgdGhlIHBhdGggdXNlZCB0byBmaW5pc2hcXG50aGlzIHJ1bi4pXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJLZWVwIGNvbXBvbmVudCBDU1Mgc21hbGwgYW5kIGxvY2FsXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHNvIHRoZSBhZ2VudCBcIn08X2NvbXBvbmVudHMuZW0+e1wiY2FuXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgb3duIGl0IOKAlCBlLmcuIGFcXG5wZXItY29tcG9uZW50IFwifTxfY29tcG9uZW50cy5jb2RlPntcIktleVZhbHVlLmNzc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaW1wb3J0ZWQgZnJvbSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJLZXlWYWx1ZS50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBpbnN0ZWFkIG9mIG9uZSBnaWFudFxcbnNoYXJlZCBzdHlsZXNoZWV0LiBBIHNtYWxsIG5ldyBmaWxlIHBsYXlzIHRvIHRoZSBhZ2VudCdzIHN0cmVuZ3RoLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJGb3IgcmVmZXJlbmNlLCB0aGUgc3R5bGluZyB0byBhZGQg4oCUIHRva2VucyBmcm9tIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9pbmRleC5jc3NcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBtYXRjaGluZyB0aGUgcmVzdFxcbm9mIHRoZSB2b2NhYnVsYXJ5OlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucHJlPjxfY29tcG9uZW50cy5jb2RlIGNsYXNzTmFtZT1cImxhbmd1YWdlLWNzc1wiPntcIi5ncm92ZS1rZXl2YWx1ZSB7IG1hcmdpbjogMS4yNXJlbSAwOyB9XFxuLmdyb3ZlLWtleXZhbHVlX19yb3cge1xcbiAgZGlzcGxheTogZ3JpZDtcXG4gIGdyaWQtdGVtcGxhdGUtY29sdW1uczogbWlubWF4KDhyZW0sIDEycmVtKSAxZnI7XFxuICBnYXA6IDFyZW07XFxuICBwYWRkaW5nOiAwLjU1cmVtIDA7XFxuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgdmFyKC0tYm9yZGVyKTtcXG59XFxuLmdyb3ZlLWtleXZhbHVlX19yb3c6Zmlyc3QtY2hpbGQgeyBib3JkZXItdG9wOiAxcHggc29saWQgdmFyKC0tYm9yZGVyKTsgfVxcbi5ncm92ZS1rZXl2YWx1ZV9fbGFiZWwge1xcbiAgZm9udC1mYW1pbHk6IHZhcigtLW1vbm8pO1xcbiAgZm9udC1zaXplOiAwLjc4cmVtO1xcbiAgbGV0dGVyLXNwYWNpbmc6IDAuMDRlbTtcXG4gIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XFxuICBjb2xvcjogdmFyKC0taW5rLTIpO1xcbn1cXG4uZ3JvdmUta2V5dmFsdWVfX3ZhbHVlIHsgY29sb3I6IHZhcigtLWluayk7IH1cXG5cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5wcmU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic3RlcC04LXJldmlldy1hbmQtcHVibGlzaFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic3RlcC04LXJldmlldy1hbmQtcHVibGlzaFwiIC8+e1wiU3RlcCA4IOKAlCBSZXZpZXcgYW5kIHB1Ymxpc2hcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIldoZW4gdGhlIGNvbXBvbmVudCBsb29rcyByaWdodCwgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJyZXZpZXcgdGhlIGRpZmZcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYW5kIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiQ29udHJpYnV0ZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB0byBvcGVuIGEgUFIg4oCUXFxudGhlIHNhbWUgZmxvdyBhcyBhbnkgb3RoZXIgY2hhbmdlLiBSZWFkIGV2ZXJ5IGh1bms6IHRoZSBhZ2VudCB3cm90ZSByZWFsIGZpbGVzIGluXFxueW91ciB0cmVlLCBzbyB0aGUgUFIgcmV2aWV3IGlzIHlvdXIgZ2F0ZSwgbm90IGEgZm9ybWFsaXR5LlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJ3aGF0LXRvLXRha2UtYXdheVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwid2hhdC10by10YWtlLWF3YXlcIiAvPntcIldoYXQgdG8gdGFrZSBhd2F5XCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQXNraW5nIGJlYXRzIHR5cGluZyBmb3IgbmV3IGNvbXBvbmVudHMuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIE9uZSB3ZWxsLXNjb3BlZCBwcm9tcHQgcHJvZHVjZWQgYVxcbmNvcnJlY3QsIGlkaW9tYXRpYyBcIn08X2NvbXBvbmVudHMuY29kZT57XCI8S2V5VmFsdWU+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBwbHVzIGl0cyByZWdpc3RyYXRpb24gYW5kIGEgd29ya2luZyBkZW1vLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiR2l2ZSBpdCB0aGUgY29udmVudGlvbnMuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIE5hbWluZyB0aGUgZmlsZXMgdG8gcmVhZCBhbmQgdGhlIGRlbW8gdG8gYWRkIGlzIHdoYXRcXG5tYWtlcyB0aGUgb3V0cHV0IG1hdGNoIEdyb3ZlIGluc3RlYWQgb2YgZ2VuZXJpYyBSZWFjdC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkJpZy1maWxlIGVkaXRzIHVzZWQgdG8gYmUgdGhlIHdhbGw7IFwifTxfY29tcG9uZW50cy5jb2RlPntcImVkaXRfZmlsZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZml4ZXMgdGhlIGNvbW1vbiBjYXNlLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBXaXRoIHRoZVxcbnN0cmluZy1yZXBsYWNlIHRvb2wgKFwifTxfY29tcG9uZW50cy5hIGhyZWY9XCJodHRwczovL2dpdGh1Yi5jb20vaW1tZWRpYXRlbHktcnVuL2FnZW50LWRlbW8vcHVsbC8xMlwiPntcImFnZW50LWRlbW8gIzEyXCJ9PC9fY29tcG9uZW50cy5hPntcIilcXG50aGUgYWdlbnQgcGF0Y2hlcyBsYXJnZSBmaWxlcyBpbiBwbGFjZS4gU3RpbGwgYXZvaWQgYXNraW5nIGl0IHRvIFwifTxfY29tcG9uZW50cy5lbT57XCJyZXdyaXRlXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgYSBsYXJnZVxcbmZpbGUgd2hvbGVzYWxlLCBhbmQgc3RydWN0dXJpbmcgc3R5bGVzIGludG8gc21hbGwgcGVyLWNvbXBvbmVudCBmaWxlcyBuZXZlciBodXJ0cy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIllvdSBzdGlsbCByZXZpZXcgYW5kIHB1Ymxpc2guXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRoZSBhZ2VudCB3cml0ZXM7IENvbnRyaWJ1dGUgKyBkaWZmIHJldmlldyBpcyBob3dcXG50aGUgY2hhbmdlIGFjdHVhbGx5IHNoaXBzLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD48Lz47XG59XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNRFhDb250ZW50KHByb3BzID0ge30pIHtcbiAgY29uc3Qge3dyYXBwZXI6IE1EWExheW91dH0gPSB7XG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9O1xuICByZXR1cm4gTURYTGF5b3V0ID8gPE1EWExheW91dCB7Li4ucHJvcHN9PjxfY3JlYXRlTWR4Q29udGVudCB7Li4ucHJvcHN9IC8+PC9NRFhMYXlvdXQ+IDogX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpO1xufVxuZnVuY3Rpb24gX21pc3NpbmdNZHhSZWZlcmVuY2UoaWQsIGNvbXBvbmVudCwgcGxhY2UpIHtcbiAgdGhyb3cgbmV3IEVycm9yKFwiRXhwZWN0ZWQgXCIgKyAoY29tcG9uZW50ID8gXCJjb21wb25lbnRcIiA6IFwib2JqZWN0XCIpICsgXCIgYFwiICsgaWQgKyBcImAgdG8gYmUgZGVmaW5lZDogeW91IGxpa2VseSBmb3Jnb3QgdG8gaW1wb3J0LCBwYXNzLCBvciBwcm92aWRlIGl0LlwiICsgKHBsYWNlID8gXCJcXG5JdOKAmXMgcmVmZXJlbmNlZCBpbiB5b3VyIGNvZGUgYXQgYFwiICsgcGxhY2UgKyBcImAgaW4gYC9hcHAvZG9jcy90dXRvcmlhbHMvYWRkLWEtY29tcG9uZW50LXdpdGgtdGhlLWFnZW50Lm1kYFwiIDogXCJcIikpO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFFQSxJQUFBQSxZQUFBLEdBQUFDLE9BQUE7QUFBd0YsSUFBQUMsV0FBQSxHQUFBRCxPQUFBO0FBRnhGO0FBQ0E7O0FBRUEsU0FBU0UsaUJBQWlCQSxDQUFDQyxLQUFLLEVBQUU7RUFDaEMsTUFBTUMsV0FBVyxHQUFHO01BQ2xCQyxDQUFDLEVBQUUsR0FBRztNQUNOQyxVQUFVLEVBQUUsWUFBWTtNQUN4QkMsSUFBSSxFQUFFLE1BQU07TUFDWkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsR0FBRyxFQUFFLEtBQUs7TUFDVkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsR0FBRyxFQUFFLEtBQUs7TUFDVkMsTUFBTSxFQUFFLFFBQVE7TUFDaEJDLEVBQUUsRUFBRSxJQUFJO01BQ1IsR0FBRyxJQUFBQyw2QkFBa0IsRUFBQyxDQUFDO01BQ3ZCLEdBQUdmLEtBQUssQ0FBQ2dCO0lBQ1gsQ0FBQztJQUFFO01BQUNDO0lBQWEsQ0FBQyxHQUFHaEIsV0FBVztFQUNoQyxJQUFJLENBQUNnQixhQUFhLEVBQUVDLG9CQUFvQixDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUM7RUFDL0Qsb0JBQU8sSUFBQXBCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQXJCLFdBQUEsQ0FBQXNCLFFBQUE7SUFBQUMsUUFBQSxnQkFBRSxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDSyxFQUFFO01BQUNnQixFQUFFLEVBQUMsZ0RBQWdEO01BQUFELFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBZ0QsQ0FBRSxDQUFDLEVBQUMsaURBQWlEO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBeEIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDVSxDQUFDO01BQUFVLFFBQUEsR0FBRSxpRUFBaUUsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1FBQUFpQixRQUFBLEVBQUU7TUFBWSxDQUFtQixDQUFDLEVBQUMsd0VBQXdFLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBcUMsQ0FBcUIsQ0FBQyxFQUFDLDZIQUE2SDtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBVSxRQUFBLEdBQUUsbURBQW1ELGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBUyxDQUFxQixDQUFDLEVBQUMsU0FBUyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNDLENBQUM7UUFBQ3NCLElBQUksRUFBQywyQkFBMkI7UUFBQUgsUUFBQSxFQUFFO01BQXlCLENBQWdCLENBQUMsRUFBQyxxRUFBcUUsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDQyxDQUFDO1FBQUNzQixJQUFJLEVBQUMseUNBQXlDO1FBQUFILFFBQUEsRUFBRTtNQUF1QyxDQUFnQixDQUFDLEVBQUMsR0FBRztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0UsVUFBVTtNQUFBa0IsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDVSxDQUFDO1FBQUFVLFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBMEIsQ0FBcUIsQ0FBQyxFQUFDLHNEQUFzRCxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFZLENBQW1CLENBQUMsRUFBQyxnSEFBZ0gsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFtQyxDQUFxQixDQUFDLEVBQUMseUdBQXlHLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0ksRUFBRTtVQUFBZ0IsUUFBQSxFQUFFO1FBQTZDLENBQWlCLENBQUMsRUFBQyxnQ0FBZ0MsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUF3QixDQUFxQixDQUFDLEVBQUMsdUJBQXVCLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLDJCQUEyQixlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNDLENBQUM7VUFBQ3NCLElBQUksRUFBQyx1REFBdUQ7VUFBQUgsUUFBQSxFQUFFO1FBQWdCLENBQWdCLENBQUMsRUFBQywyRUFBMkUsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDSSxFQUFFO1VBQUFnQixRQUFBLEVBQUU7UUFBUyxDQUFpQixDQUFDLEVBQUMsb0ZBQW9GO01BQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUF5QixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNNLEVBQUU7TUFBQ2UsRUFBRSxFQUFDLGVBQWU7TUFBQUQsUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFlLENBQUUsQ0FBQyxFQUFDLGVBQWU7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF4QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNhLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFZLFFBQUEsR0FBRSwwQ0FBMEMsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBdUIsQ0FBbUIsQ0FBQyxFQUFDLHdCQUF3QixlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFpQixDQUFtQixDQUFDLEVBQUMsb0JBQW9CLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLElBQUk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNRLEVBQUU7UUFBQVksUUFBQSxHQUFFLHFCQUFxQixlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQXVCLENBQXFCLENBQUMsRUFBQyxTQUFTLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBc0IsQ0FBcUIsQ0FBQyxFQUFDLHVDQUF1QyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQywwRkFBMEYsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDQyxDQUFDO1VBQUNzQixJQUFJLEVBQUMsK0VBQStFO1VBQUFILFFBQUEsRUFBRTtRQUF1QyxDQUFnQixDQUFDLEVBQUMsbUJBQW1CLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNRLEVBQUU7UUFBQVksUUFBQSxHQUFFLG9CQUFvQixlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQVUsQ0FBcUIsQ0FBQyxFQUFDLGdCQUFnQjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDTSxFQUFFO01BQUNlLEVBQUUsRUFBQyx5Q0FBeUM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUF5QyxDQUFFLENBQUMsRUFBQywyQ0FBMkM7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF4QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNVLENBQUM7TUFBQVUsUUFBQSxHQUFFLGFBQWEsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFhLENBQXFCLENBQUMsRUFBQyxZQUFZLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBaUIsUUFBQSxFQUFFO01BQXFCLENBQW1CLENBQUMsRUFBQyxvREFBb0Q7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNXLEdBQUc7TUFBQVMsUUFBQSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUF5RSxDQUFtQjtJQUFDLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBVSxRQUFBLEVBQUU7SUFBcUosQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDTSxFQUFFO01BQUNlLEVBQUUsRUFBQyxpQ0FBaUM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFpQyxDQUFFLENBQUMsRUFBQyxtQ0FBbUM7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF4QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNVLENBQUM7TUFBQVUsUUFBQSxHQUFFLFFBQVEsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFRLENBQXFCLENBQUMsRUFBQyx1SkFBdUosZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1FBQUFpQixRQUFBLEVBQUU7TUFBVyxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUFZLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBaUIsUUFBQSxFQUFFO01BQVUsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1FBQUFpQixRQUFBLEVBQUU7TUFBTSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUFNLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBaUIsUUFBQSxFQUFFO01BQU0sQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1FBQUFpQixRQUFBLEVBQUU7TUFBYSxDQUFtQixDQUFDLEVBQUMsNEVBQTRFLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBUyxDQUFxQixDQUFDLEVBQUMsMEVBQTBFO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDTSxFQUFFO01BQUNlLEVBQUUsRUFBQyx5QkFBeUI7TUFBQUQsUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUF5QixDQUFFLENBQUMsRUFBQywyQkFBMkI7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF4QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNVLENBQUM7TUFBQVUsUUFBQSxFQUFFO0lBQXlKLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0UsVUFBVTtNQUFBa0IsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDVSxDQUFDO1FBQUFVLFFBQUEsR0FBRSwwQkFBMEIsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBWSxDQUFtQixDQUFDLEVBQUMsNElBQTRJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQTBCLENBQW1CLENBQUMsRUFBQyxPQUFPLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQXNCLENBQW1CLENBQUMsRUFBQyxrQkFBa0IsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBaUIsQ0FBbUIsQ0FBQyxFQUFDLHNEQUFzRCxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUE2QixDQUFtQixDQUFDLEVBQUMsb0VBQW9FLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQU8sQ0FBbUIsQ0FBQyxFQUFDLFdBQVcsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBa0IsQ0FBbUIsQ0FBQyxFQUFDLG1EQUFtRCxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUErQixDQUFtQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFNLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQU0sQ0FBbUIsQ0FBQyxFQUFDLHdCQUF3QixlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQyxNQUFNLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQXNCLENBQW1CLENBQUMsRUFBQyxZQUFZLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQWlCLENBQW1CLENBQUMsRUFBQyxzSUFBc0ksZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBWSxDQUFtQixDQUFDLEVBQUMsYUFBYSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUErQixDQUFtQixDQUFDLEVBQUMsaUhBQWlIO01BQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUF5QixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNVLENBQUM7TUFBQVUsUUFBQSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNPLEdBQUc7UUFBQ2lCLEdBQUcsRUFBQyw4QkFBOEI7UUFBQ0MsR0FBRyxFQUFDO01BQXNELENBQUU7SUFBQyxDQUFlLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBVSxRQUFBLEdBQUUsc0pBQXNKLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0ksRUFBRTtRQUFBZ0IsUUFBQSxFQUFFO01BQUssQ0FBaUIsQ0FBQyxFQUFDLGNBQWM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNNLEVBQUU7TUFBQ2UsRUFBRSxFQUFDLGlDQUFpQztNQUFBRCxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQWlDLENBQUUsQ0FBQyxFQUFDLG9DQUFvQztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBVSxRQUFBLEdBQUUsUUFBUSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQUssQ0FBcUIsQ0FBQyxFQUFDLHlDQUF5QyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQW9CLENBQXFCLENBQUMsRUFBQyxvREFBb0Q7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNFLFVBQVU7TUFBQWtCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1UsQ0FBQztRQUFBVSxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQStCLENBQXFCLENBQUMsRUFBQyxnQkFBZ0IsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDSSxFQUFFO1VBQUFnQixRQUFBLEVBQUU7UUFBTSxDQUFpQixDQUFDLEVBQUMsbUZBQW1GLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBZSxDQUFxQixDQUFDLEVBQUMsMk1BQTJNO01BQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUF5QixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNNLEVBQUU7TUFBQ2UsRUFBRSxFQUFDLDRCQUE0QjtNQUFBRCxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQTRCLENBQUUsQ0FBQyxFQUFDLDhCQUE4QjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBVSxRQUFBLEdBQUUsb0RBQW9ELGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBaUIsUUFBQSxFQUFFO01BQVcsQ0FBbUIsQ0FBQyxFQUFDLFFBQVEsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1FBQUFpQixRQUFBLEVBQUU7TUFBc0IsQ0FBbUIsQ0FBQyxFQUFDLGNBQWMsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1FBQUFpQixRQUFBLEVBQUU7TUFBYSxDQUFtQixDQUFDLEVBQUMscUlBQXFJO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDYSxFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBWSxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNZLE1BQU07VUFBQVEsUUFBQSxHQUFFLFFBQVEsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1lBQUFpQixRQUFBLEVBQUU7VUFBNkIsQ0FBbUIsQ0FBQztRQUFBLENBQW9CLENBQUMsRUFBQyw4QkFBOEI7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNRLEVBQUU7UUFBQVksUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFRLFFBQUEsR0FBRSxRQUFRLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBaUIsUUFBQSxFQUFFO1VBQXNCLENBQW1CLENBQUM7UUFBQSxDQUFvQixDQUFDLEVBQUMsZUFBZSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQyxrQkFBa0I7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNRLEVBQUU7UUFBQVksUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFRLFFBQUEsR0FBRSxRQUFRLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBaUIsUUFBQSxFQUFFO1VBQStCLENBQW1CLENBQUM7UUFBQSxDQUFvQixDQUFDLEVBQUMsbUJBQW1CO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNVLENBQUM7TUFBQVUsUUFBQSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNPLEdBQUc7UUFBQ2lCLEdBQUcsRUFBQyxnQ0FBZ0M7UUFBQ0MsR0FBRyxFQUFDO01BQXdELENBQUU7SUFBQyxDQUFlLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBVSxRQUFBLEVBQUU7SUFBbUYsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDVyxHQUFHO01BQUFTLFFBQUEsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1FBQUN1QixTQUFTLEVBQUMsY0FBYztRQUFBTixRQUFBLEVBQUU7TUFBb3lCLENBQW1CO0lBQUMsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDVSxDQUFDO01BQUFVLFFBQUEsR0FBRSwyQkFBMkIsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1FBQUFpQixRQUFBLEVBQUU7TUFBK0IsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNXLEdBQUc7TUFBQVMsUUFBQSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7UUFBQ3VCLFNBQVMsRUFBQyxjQUFjO1FBQUFOLFFBQUEsRUFBRTtNQUErTSxDQUFtQjtJQUFDLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDZSxFQUFFLEVBQUMsc0JBQXNCO01BQUFELFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBc0IsQ0FBRSxDQUFDLEVBQUMsd0JBQXdCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBeEIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDVSxDQUFDO01BQUFVLFFBQUEsR0FBRSwyREFBMkQsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFhLENBQXFCLENBQUMsRUFBQyx3Q0FBd0MsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1FBQUFpQixRQUFBLEVBQUU7TUFBWSxDQUFtQixDQUFDLEVBQUMsdUVBQXVFO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDVSxDQUFDO01BQUFVLFFBQUEsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDTyxHQUFHO1FBQUNpQixHQUFHLEVBQUMsOENBQThDO1FBQUNDLEdBQUcsRUFBQztNQUErRSxDQUFFO0lBQUMsQ0FBZSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNVLENBQUM7TUFBQVUsUUFBQSxHQUFFLHNEQUFzRCxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUFZLENBQW1CLENBQUMsRUFBQywwR0FBMEcsZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDWSxNQUFNO1FBQUFRLFFBQUEsR0FBRSxpQkFBaUIsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBYyxDQUFtQixDQUFDO01BQUEsQ0FBb0IsQ0FBQyxFQUFDLHFEQUFxRDtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDZSxFQUFFLEVBQUMsdUNBQXVDO01BQUFELFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBdUMsQ0FBRSxDQUFDLEVBQUMsMENBQTBDO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBeEIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDVSxDQUFDO01BQUFVLFFBQUEsR0FBRSx1QkFBdUIsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1FBQUFpQixRQUFBLEVBQUU7TUFBaUIsQ0FBbUIsQ0FBQyxFQUFDLHlCQUF5QixlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQW1CLENBQXFCLENBQUMsRUFBQyx3QkFBd0IsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1FBQUFpQixRQUFBLEVBQUU7TUFBa0IsQ0FBbUIsQ0FBQyxFQUFDLHdIQUF3SCxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUFZLENBQW1CLENBQUMsRUFBQyxZQUFZLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBVSxDQUFxQixDQUFDLEVBQUMsOERBQThEO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDVSxDQUFDO01BQUFVLFFBQUEsR0FBRSxpRkFBaUYsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFRLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBaUIsUUFBQSxFQUFFO01BQWMsQ0FBbUIsQ0FBQyxFQUFDLGdFQUFnRSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUFZLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBMEIsQ0FBcUIsQ0FBQyxFQUFDLGlTQUFpUztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0UsVUFBVTtNQUFBa0IsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDVSxDQUFDO1FBQUFVLFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBUSxDQUFxQixDQUFDLEVBQUMsd0JBQXdCLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBUSxRQUFBLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBaUIsUUFBQSxFQUFFO1VBQVcsQ0FBbUI7UUFBQyxDQUFvQixDQUFDLEVBQUMsVUFBVSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNDLENBQUM7VUFBQ3NCLElBQUksRUFBQyx1REFBdUQ7VUFBQUgsUUFBQSxFQUFFO1FBQWdCLENBQWdCLENBQUMsRUFBQyxxSUFBcUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBaUIsQ0FBbUIsQ0FBQyxFQUFDLDBDQUEwQyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUMsRUFBQyxrRUFBa0UsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDSSxFQUFFO1VBQUFnQixRQUFBLEVBQUU7UUFBUSxDQUFpQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQywyQ0FBMkMsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBWSxDQUFtQixDQUFDLEVBQUMscUVBQXFFO01BQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUF5QixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNVLENBQUM7TUFBQVUsUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDWSxNQUFNO1FBQUFRLFFBQUEsR0FBRSxvQ0FBb0MsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDSSxFQUFFO1VBQUFnQixRQUFBLEVBQUU7UUFBWSxDQUFpQixDQUFDLEVBQUMsWUFBWTtNQUFBLENBQXFCLENBQUMsRUFBQyw4QkFBOEIsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUEyQixDQUFxQixDQUFDLEVBQUMsY0FBYyxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNZLE1BQU07UUFBQVEsUUFBQSxHQUFFLFdBQVcsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsVUFBVTtNQUFBLENBQXFCLENBQUMsRUFBQyxTQUFTLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBaUQsQ0FBcUIsQ0FBQyxFQUFDLDRDQUE0QyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUFXLENBQW1CLENBQUMsRUFBQyxTQUFTO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDUyxFQUFFO01BQUFXLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQW9CLENBQXFCLENBQUMsRUFBQyxpQ0FBaUMsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBa0IsQ0FBbUIsQ0FBQyxFQUFDLGNBQWMsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBaUIsQ0FBbUIsQ0FBQyxFQUFDLGtCQUFrQixlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUMsRUFBQyxnREFBZ0Q7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNRLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFvQyxDQUFxQixDQUFDLEVBQUMsZ0JBQWdCLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0ksRUFBRTtVQUFBZ0IsUUFBQSxFQUFFO1FBQUssQ0FBaUIsQ0FBQyxFQUFDLGtDQUFrQyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUMsRUFBQyxpQkFBaUIsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBYyxDQUFtQixDQUFDLEVBQUMsNEZBQTRGO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNVLENBQUM7TUFBQVUsUUFBQSxHQUFFLGtEQUFrRCxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUFlLENBQW1CLENBQUMsRUFBQyx5Q0FBeUM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNXLEdBQUc7TUFBQVMsUUFBQSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7UUFBQ3VCLFNBQVMsRUFBQyxjQUFjO1FBQUFOLFFBQUEsRUFBRTtNQUFzZixDQUFtQjtJQUFDLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDZSxFQUFFLEVBQUMsMkJBQTJCO01BQUFELFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBMkIsQ0FBRSxDQUFDLEVBQUMsNkJBQTZCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBeEIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDVSxDQUFDO01BQUFVLFFBQUEsR0FBRSxrQ0FBa0MsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFpQixDQUFxQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQVksQ0FBcUIsQ0FBQyxFQUFDLGdLQUFnSztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDZSxFQUFFLEVBQUMsbUJBQW1CO01BQUFELFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBbUIsQ0FBRSxDQUFDLEVBQUMsbUJBQW1CO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBeEIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDYSxFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNZLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQXlDLENBQXFCLENBQUMsRUFBQyx5REFBeUQsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBWSxDQUFtQixDQUFDLEVBQUMsNENBQTRDO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBMEIsQ0FBcUIsQ0FBQyxFQUFDLCtHQUErRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNZLE1BQU07VUFBQVEsUUFBQSxHQUFFLHNDQUFzQyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7WUFBQWlCLFFBQUEsRUFBRTtVQUFXLENBQW1CLENBQUMsRUFBQyx5QkFBeUI7UUFBQSxDQUFxQixDQUFDLEVBQUMsa0NBQWtDLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0MsQ0FBQztVQUFDc0IsSUFBSSxFQUFDLHVEQUF1RDtVQUFBSCxRQUFBLEVBQUU7UUFBZ0IsQ0FBZ0IsQ0FBQyxFQUFDLHNFQUFzRSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNJLEVBQUU7VUFBQWdCLFFBQUEsRUFBRTtRQUFTLENBQWlCLENBQUMsRUFBQyw4RkFBOEY7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNRLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUErQixDQUFxQixDQUFDLEVBQUMsZ0ZBQWdGO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDO0VBQUEsQ0FBRSxDQUFDO0FBQy8xbEI7QUFDZSxTQUFTTyxVQUFVQSxDQUFDNUIsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFO0VBQzdDLE1BQU07SUFBQzZCLE9BQU8sRUFBRUM7RUFBUyxDQUFDLEdBQUc7SUFDM0IsR0FBRyxJQUFBZiw2QkFBa0IsRUFBQyxDQUFDO0lBQ3ZCLEdBQUdmLEtBQUssQ0FBQ2dCO0VBQ1gsQ0FBQztFQUNELE9BQU9jLFNBQVMsZ0JBQUcsSUFBQWhDLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ08sU0FBUztJQUFBLEdBQUs5QixLQUFLO0lBQUFxQixRQUFBLGVBQUUsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3hCLGlCQUFpQjtNQUFBLEdBQUtDO0lBQUssQ0FBRztFQUFDLENBQVcsQ0FBQyxHQUFHRCxpQkFBaUIsQ0FBQ0MsS0FBSyxDQUFDO0FBQ2xIO0FBQUMrQixFQUFBLEdBTnVCSCxVQUFVO0FBT2xDLFNBQVNWLG9CQUFvQkEsQ0FBQ0ksRUFBRSxFQUFFVSxTQUFTLEVBQUVDLEtBQUssRUFBRTtFQUNsRCxNQUFNLElBQUlDLEtBQUssQ0FBQyxXQUFXLElBQUlGLFNBQVMsR0FBRyxXQUFXLEdBQUcsUUFBUSxDQUFDLEdBQUcsSUFBSSxHQUFHVixFQUFFLEdBQUcsb0VBQW9FLElBQUlXLEtBQUssR0FBRyxxQ0FBcUMsR0FBR0EsS0FBSyxHQUFHLDhEQUE4RCxHQUFHLEVBQUUsQ0FBQyxDQUFDO0FBQ3hSO0FBQUMsSUFBQUYsRUFBQTtBQUFBSSxZQUFBLENBQUFKLEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}