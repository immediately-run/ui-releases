var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      blockquote: "blockquote",
      code: "code",
      em: "em",
      h1: "h1",
      li: "li",
      p: "p",
      strong: "strong",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "grove-tutorials",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "grove-tutorials"
      }), "Grove tutorials"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Practical, repeatable guides for working on this wiki — written for ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "humans and\ncoding agents alike"
      }), ". Each one is concrete: exact files, exact conventions, a\nworked example you can copy."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
            href: "./creating-a-component.md",
            children: "creating-a-component.md"
          })
        }), " — add a new import-free\nMDX component to Grove (the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<Quote>"
        }), " worked example): the files to touch, the\nconventions that keep it from breaking on immediately.run, how to link to wiki\nentries, and how to verify. Start here to add UI vocabulary authors can drop\ninto any ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".mdx"
        }), " entry."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
            href: "./add-a-component-with-the-agent.md",
            children: "add-a-component-with-the-agent.md"
          })
        }), " — a\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "step-by-step"
        }), " walkthrough that builds a real component (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<KeyValue>"
        }), ") by ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "asking\nthe in-browser coding agent"
        }), ", with screenshots from an actual end-to-end run —\nincluding, honestly, where it stalled and how that was fixed. Read this for the\nconcrete \"ask, don't type\" loop."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
            href: "./building-with-the-in-browser-agent.md",
            children: "building-with-the-in-browser-agent.md"
          })
        }), "\n— the reference for ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "how"
        }), " that agent is wired (regions, the host-mediated\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "llm.chat"
        }), " service, no per-app key) and its rough edges in general. Read this for\nthe mechanics behind the walkthrough above."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: ["The platform-wide tutorials (browser debugging, local dev, changing a UI\ncomponent, the MCP bridge) live in the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "docs repo"
        }), " under ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "docs/tutorials/"
        }), ".\nThese Grove-scoped guides assume that baseline and focus on Grove specifics."]
      }), "\n"]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/tutorials/README.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiYmxvY2txdW90ZSIsImNvZGUiLCJlbSIsImgxIiwibGkiLCJwIiwic3Ryb25nIiwidWwiLCJfcHJvdmlkZUNvbXBvbmVudHMiLCJjb21wb25lbnRzIiwiSGVhZGluZ0FuY2hvciIsIl9taXNzaW5nTWR4UmVmZXJlbmNlIiwianN4cyIsIkZyYWdtZW50IiwiY2hpbGRyZW4iLCJpZCIsImpzeCIsImhyZWYiLCJNRFhDb250ZW50Iiwid3JhcHBlciIsIk1EWExheW91dCIsIl9jIiwiY29tcG9uZW50IiwicGxhY2UiLCJFcnJvciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlJFQURNRS5tZCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKkBqc3hSdW50aW1lIGF1dG9tYXRpYyovXG4vKkBqc3hJbXBvcnRTb3VyY2UgcmVhY3QqL1xuaW1wb3J0IHt1c2VNRFhDb21wb25lbnRzIGFzIF9wcm92aWRlQ29tcG9uZW50c30gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrL01EWFByb3ZpZGVyXCI7XG5mdW5jdGlvbiBfY3JlYXRlTWR4Q29udGVudChwcm9wcykge1xuICBjb25zdCBfY29tcG9uZW50cyA9IHtcbiAgICBhOiBcImFcIixcbiAgICBibG9ja3F1b3RlOiBcImJsb2NrcXVvdGVcIixcbiAgICBjb2RlOiBcImNvZGVcIixcbiAgICBlbTogXCJlbVwiLFxuICAgIGgxOiBcImgxXCIsXG4gICAgbGk6IFwibGlcIixcbiAgICBwOiBcInBcIixcbiAgICBzdHJvbmc6IFwic3Ryb25nXCIsXG4gICAgdWw6IFwidWxcIixcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH0sIHtIZWFkaW5nQW5jaG9yfSA9IF9jb21wb25lbnRzO1xuICBpZiAoIUhlYWRpbmdBbmNob3IpIF9taXNzaW5nTWR4UmVmZXJlbmNlKFwiSGVhZGluZ0FuY2hvclwiLCB0cnVlKTtcbiAgcmV0dXJuIDw+PF9jb21wb25lbnRzLmgxIGlkPVwiZ3JvdmUtdHV0b3JpYWxzXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJncm92ZS10dXRvcmlhbHNcIiAvPntcIkdyb3ZlIHR1dG9yaWFsc1wifTwvX2NvbXBvbmVudHMuaDE+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiUHJhY3RpY2FsLCByZXBlYXRhYmxlIGd1aWRlcyBmb3Igd29ya2luZyBvbiB0aGlzIHdpa2kg4oCUIHdyaXR0ZW4gZm9yIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiaHVtYW5zIGFuZFxcbmNvZGluZyBhZ2VudHMgYWxpa2VcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIuIEVhY2ggb25lIGlzIGNvbmNyZXRlOiBleGFjdCBmaWxlcywgZXhhY3QgY29udmVudGlvbnMsIGFcXG53b3JrZWQgZXhhbXBsZSB5b3UgY2FuIGNvcHkuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz48X2NvbXBvbmVudHMuYSBocmVmPVwiLi9jcmVhdGluZy1hLWNvbXBvbmVudC5tZFwiPntcImNyZWF0aW5nLWEtY29tcG9uZW50Lm1kXCJ9PC9fY29tcG9uZW50cy5hPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgYWRkIGEgbmV3IGltcG9ydC1mcmVlXFxuTURYIGNvbXBvbmVudCB0byBHcm92ZSAodGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjxRdW90ZT5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHdvcmtlZCBleGFtcGxlKTogdGhlIGZpbGVzIHRvIHRvdWNoLCB0aGVcXG5jb252ZW50aW9ucyB0aGF0IGtlZXAgaXQgZnJvbSBicmVha2luZyBvbiBpbW1lZGlhdGVseS5ydW4sIGhvdyB0byBsaW5rIHRvIHdpa2lcXG5lbnRyaWVzLCBhbmQgaG93IHRvIHZlcmlmeS4gU3RhcnQgaGVyZSB0byBhZGQgVUkgdm9jYWJ1bGFyeSBhdXRob3JzIGNhbiBkcm9wXFxuaW50byBhbnkgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLm1keFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZW50cnkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz48X2NvbXBvbmVudHMuYSBocmVmPVwiLi9hZGQtYS1jb21wb25lbnQtd2l0aC10aGUtYWdlbnQubWRcIj57XCJhZGQtYS1jb21wb25lbnQtd2l0aC10aGUtYWdlbnQubWRcIn08L19jb21wb25lbnRzLmE+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBhXFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJzdGVwLWJ5LXN0ZXBcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgd2Fsa3Rocm91Z2ggdGhhdCBidWlsZHMgYSByZWFsIGNvbXBvbmVudCAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiPEtleVZhbHVlPlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpIGJ5IFwifTxfY29tcG9uZW50cy5lbT57XCJhc2tpbmdcXG50aGUgaW4tYnJvd3NlciBjb2RpbmcgYWdlbnRcIn08L19jb21wb25lbnRzLmVtPntcIiwgd2l0aCBzY3JlZW5zaG90cyBmcm9tIGFuIGFjdHVhbCBlbmQtdG8tZW5kIHJ1biDigJRcXG5pbmNsdWRpbmcsIGhvbmVzdGx5LCB3aGVyZSBpdCBzdGFsbGVkIGFuZCBob3cgdGhhdCB3YXMgZml4ZWQuIFJlYWQgdGhpcyBmb3IgdGhlXFxuY29uY3JldGUgXFxcImFzaywgZG9uJ3QgdHlwZVxcXCIgbG9vcC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPjxfY29tcG9uZW50cy5hIGhyZWY9XCIuL2J1aWxkaW5nLXdpdGgtdGhlLWluLWJyb3dzZXItYWdlbnQubWRcIj57XCJidWlsZGluZy13aXRoLXRoZS1pbi1icm93c2VyLWFnZW50Lm1kXCJ9PC9fY29tcG9uZW50cy5hPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIlxcbuKAlCB0aGUgcmVmZXJlbmNlIGZvciBcIn08X2NvbXBvbmVudHMuZW0+e1wiaG93XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgdGhhdCBhZ2VudCBpcyB3aXJlZCAocmVnaW9ucywgdGhlIGhvc3QtbWVkaWF0ZWRcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJsbG0uY2hhdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgc2VydmljZSwgbm8gcGVyLWFwcCBrZXkpIGFuZCBpdHMgcm91Z2ggZWRnZXMgaW4gZ2VuZXJhbC4gUmVhZCB0aGlzIGZvclxcbnRoZSBtZWNoYW5pY3MgYmVoaW5kIHRoZSB3YWxrdGhyb3VnaCBhYm92ZS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIHBsYXRmb3JtLXdpZGUgdHV0b3JpYWxzIChicm93c2VyIGRlYnVnZ2luZywgbG9jYWwgZGV2LCBjaGFuZ2luZyBhIFVJXFxuY29tcG9uZW50LCB0aGUgTUNQIGJyaWRnZSkgbGl2ZSBpbiB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJkb2NzIHJlcG9cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdW5kZXIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZG9jcy90dXRvcmlhbHMvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi5cXG5UaGVzZSBHcm92ZS1zY29wZWQgZ3VpZGVzIGFzc3VtZSB0aGF0IGJhc2VsaW5lIGFuZCBmb2N1cyBvbiBHcm92ZSBzcGVjaWZpY3MuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTwvX2NvbXBvbmVudHMuYmxvY2txdW90ZT48Lz47XG59XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNRFhDb250ZW50KHByb3BzID0ge30pIHtcbiAgY29uc3Qge3dyYXBwZXI6IE1EWExheW91dH0gPSB7XG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9O1xuICByZXR1cm4gTURYTGF5b3V0ID8gPE1EWExheW91dCB7Li4ucHJvcHN9PjxfY3JlYXRlTWR4Q29udGVudCB7Li4ucHJvcHN9IC8+PC9NRFhMYXlvdXQ+IDogX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpO1xufVxuZnVuY3Rpb24gX21pc3NpbmdNZHhSZWZlcmVuY2UoaWQsIGNvbXBvbmVudCwgcGxhY2UpIHtcbiAgdGhyb3cgbmV3IEVycm9yKFwiRXhwZWN0ZWQgXCIgKyAoY29tcG9uZW50ID8gXCJjb21wb25lbnRcIiA6IFwib2JqZWN0XCIpICsgXCIgYFwiICsgaWQgKyBcImAgdG8gYmUgZGVmaW5lZDogeW91IGxpa2VseSBmb3Jnb3QgdG8gaW1wb3J0LCBwYXNzLCBvciBwcm92aWRlIGl0LlwiICsgKHBsYWNlID8gXCJcXG5JdOKAmXMgcmVmZXJlbmNlZCBpbiB5b3VyIGNvZGUgYXQgYFwiICsgcGxhY2UgKyBcImAgaW4gYC9hcHAvZG9jcy90dXRvcmlhbHMvUkVBRE1FLm1kYFwiIDogXCJcIikpO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFFQSxJQUFBQSxZQUFBLEdBQUFDLE9BQUE7QUFBd0YsSUFBQUMsV0FBQSxHQUFBRCxPQUFBO0FBRnhGO0FBQ0E7O0FBRUEsU0FBU0UsaUJBQWlCQSxDQUFDQyxLQUFLLEVBQUU7RUFDaEMsTUFBTUMsV0FBVyxHQUFHO01BQ2xCQyxDQUFDLEVBQUUsR0FBRztNQUNOQyxVQUFVLEVBQUUsWUFBWTtNQUN4QkMsSUFBSSxFQUFFLE1BQU07TUFDWkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsTUFBTSxFQUFFLFFBQVE7TUFDaEJDLEVBQUUsRUFBRSxJQUFJO01BQ1IsR0FBRyxJQUFBQyw2QkFBa0IsRUFBQyxDQUFDO01BQ3ZCLEdBQUdYLEtBQUssQ0FBQ1k7SUFDWCxDQUFDO0lBQUU7TUFBQ0M7SUFBYSxDQUFDLEdBQUdaLFdBQVc7RUFDaEMsSUFBSSxDQUFDWSxhQUFhLEVBQUVDLG9CQUFvQixDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUM7RUFDL0Qsb0JBQU8sSUFBQWhCLFdBQUEsQ0FBQWlCLElBQUEsRUFBQWpCLFdBQUEsQ0FBQWtCLFFBQUE7SUFBQUMsUUFBQSxnQkFBRSxJQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNLLEVBQUU7TUFBQ1ksRUFBRSxFQUFDLGlCQUFpQjtNQUFBRCxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQWlCLENBQUUsQ0FBQyxFQUFDLGlCQUFpQjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDTyxDQUFDO01BQUFTLFFBQUEsR0FBRSxzRUFBc0UsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDUSxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFpQyxDQUFxQixDQUFDLEVBQUMseUZBQXlGO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNTLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNNLEVBQUU7UUFBQVUsUUFBQSxnQkFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDUSxNQUFNO1VBQUFRLFFBQUEsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxDQUFDO1lBQUNrQixJQUFJLEVBQUMsMkJBQTJCO1lBQUFILFFBQUEsRUFBRTtVQUF5QixDQUFnQjtRQUFDLENBQW9CLENBQUMsRUFBQyx3REFBd0QsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFhLFFBQUEsRUFBRTtRQUFTLENBQW1CLENBQUMsRUFBQyxvTkFBb04sZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFhLFFBQUEsRUFBRTtRQUFNLENBQW1CLENBQUMsRUFBQyxTQUFTO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNNLEVBQUU7UUFBQVUsUUFBQSxnQkFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDUSxNQUFNO1VBQUFRLFFBQUEsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxDQUFDO1lBQUNrQixJQUFJLEVBQUMscUNBQXFDO1lBQUFILFFBQUEsRUFBRTtVQUFtQyxDQUFnQjtRQUFDLENBQW9CLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1EsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBYyxDQUFxQixDQUFDLEVBQUMsNkNBQTZDLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBYSxRQUFBLEVBQUU7UUFBWSxDQUFtQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNJLEVBQUU7VUFBQVksUUFBQSxFQUFFO1FBQXFDLENBQWlCLENBQUMsRUFBQyx5S0FBeUs7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ00sRUFBRTtRQUFBVSxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNRLE1BQU07VUFBQVEsUUFBQSxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLENBQUM7WUFBQ2tCLElBQUksRUFBQyx5Q0FBeUM7WUFBQUgsUUFBQSxFQUFFO1VBQXVDLENBQWdCO1FBQUMsQ0FBb0IsQ0FBQyxFQUFDLHdCQUF3QixlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNJLEVBQUU7VUFBQVksUUFBQSxFQUFFO1FBQUssQ0FBaUIsQ0FBQyxFQUFDLG9EQUFvRCxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNHLElBQUk7VUFBQWEsUUFBQSxFQUFFO1FBQVUsQ0FBbUIsQ0FBQyxFQUFDLHNIQUFzSDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNFLFVBQVU7TUFBQWMsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNPLENBQUM7UUFBQVMsUUFBQSxHQUFFLG1IQUFtSCxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNRLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQVcsQ0FBcUIsQ0FBQyxFQUFDLFNBQVMsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFhLFFBQUEsRUFBRTtRQUFpQixDQUFtQixDQUFDLEVBQUMsaUZBQWlGO01BQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUF5QixDQUFDO0VBQUEsQ0FBRSxDQUFDO0FBQzU4RTtBQUNlLFNBQVNJLFVBQVVBLENBQUNyQixLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUU7RUFDN0MsTUFBTTtJQUFDc0IsT0FBTyxFQUFFQztFQUFTLENBQUMsR0FBRztJQUMzQixHQUFHLElBQUFaLDZCQUFrQixFQUFDLENBQUM7SUFDdkIsR0FBR1gsS0FBSyxDQUFDWTtFQUNYLENBQUM7RUFDRCxPQUFPVyxTQUFTLGdCQUFHLElBQUF6QixXQUFBLENBQUFxQixHQUFBLEVBQUNJLFNBQVM7SUFBQSxHQUFLdkIsS0FBSztJQUFBaUIsUUFBQSxlQUFFLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNwQixpQkFBaUI7TUFBQSxHQUFLQztJQUFLLENBQUc7RUFBQyxDQUFXLENBQUMsR0FBR0QsaUJBQWlCLENBQUNDLEtBQUssQ0FBQztBQUNsSDtBQUFDd0IsRUFBQSxHQU51QkgsVUFBVTtBQU9sQyxTQUFTUCxvQkFBb0JBLENBQUNJLEVBQUUsRUFBRU8sU0FBUyxFQUFFQyxLQUFLLEVBQUU7RUFDbEQsTUFBTSxJQUFJQyxLQUFLLENBQUMsV0FBVyxJQUFJRixTQUFTLEdBQUcsV0FBVyxHQUFHLFFBQVEsQ0FBQyxHQUFHLElBQUksR0FBR1AsRUFBRSxHQUFHLG9FQUFvRSxJQUFJUSxLQUFLLEdBQUcscUNBQXFDLEdBQUdBLEtBQUssR0FBRyxzQ0FBc0MsR0FBRyxFQUFFLENBQUMsQ0FBQztBQUNoUTtBQUFDLElBQUFGLEVBQUE7QUFBQUksWUFBQSxDQUFBSixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}