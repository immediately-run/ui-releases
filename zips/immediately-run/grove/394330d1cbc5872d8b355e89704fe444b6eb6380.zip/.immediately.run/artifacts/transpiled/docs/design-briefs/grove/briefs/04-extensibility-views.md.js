var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      blockquote: "blockquote",
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      li: "li",
      p: "p",
      strong: "strong",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "brief-04-extensibility-views-the-agent-built-surfaces",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "brief-04-extensibility-views-the-agent-built-surfaces"
      }), "Brief 04 — Extensibility views (the agent-built surfaces)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Grove's signature claim is that a coding agent can add views its authors never imagined,\nreading existing frontmatter, without changing how entries are written (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "grove.md"
      }), "\n\"Extending Grove with a coding agent\"). These three views are the worked examples — design\nthem both as ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "proof the extension surface is designable"
      }), " and as ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "on-brand reference\nimplementations"
      }), " an agent can target. Assumes ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "./00-foundation.md",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "00-foundation"
        })
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: ["These are ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "example"
        }), " extensions, not core chrome. Design them to feel native to Grove\n(same tokens, same ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".grove-*"
        }), " idiom) so a fork that adds them looks first-party — but\nnote in the inventory that they're optional, agent-added components."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-1",
      "data-slug": "1-animated-timeline-grovemd-worked-example",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-1"
      }), "1. Animated timeline (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "grove.md"
      }), " worked example)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Reads every entry with a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "date"
      }), " and lays them on a time axis. The family-journal and\nchangelog hero view."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Desktop"
        }), " — a horizontal or vertical time axis with hairline gridlines and mono year/\nmonth markers; each entry a node (the link-graph node motif) on the axis with title,\ndate, and an optional thumbnail/asset; clusters when dense; the accent marks \"today\"."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Motion"
        }), " — restrained reveal as the axis scrolls into view (respect\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "prefers-reduced-motion"
        }), "; the brand bans bounce/spring — keep it a smooth fade/slide,\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".14s"
        }), "–scale, not theatrical). \"Animated\" here means tasteful progressive reveal, not a\ncarousel."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Mobile"
        }), " — vertical axis, single column, nodes stack; sticky date headers."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "States"
        }), " — loading (axis skeleton with ghost nodes), empty (\"No dated entries yet.\"),\nand a dense-data state (hundreds of nodes → grouping/zoom affordance)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-2",
      "data-slug": "2-family-tree-relationship-graph",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-2"
      }), "2. Family tree / relationship graph"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Reads genealogy frontmatter (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "parent"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "house"
      }), ", …) for the LOTR case. Two presentations\nto sketch:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Tree"
        }), " — a classic hierarchical genealogy: nodes (name + dates) joined by hairline\nedges; the current entry highlighted; collapsible branches; pan/zoom on desktop,\nhorizontal scroll on mobile."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Graph"
        }), " — when relationships aren't a clean tree, the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "link-graph motif made\nliteral"
        }), ": nodes + labelled edges, force-directed-ish but legible. This is where Grove's\nnode-and-edge identity pays off visually."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "States"
        }), " — loading (ghost nodes/edges), empty (\"No relationships defined.\"), and an\noverflow state (too many nodes → focus + neighbourhood view)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-3",
      "data-slug": "3-directory-table-the-company-phone-book",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-3"
      }), "3. Directory / table (the company phone book)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Reads structured frontmatter (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "name"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "role"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "phone"
      }), ", …) across a set of entries and\nrenders a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "sortable, filterable table"
      }), ". The KB case."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: "Hairline table, mono for phone numbers/IDs, sticky header, click-to-sort (accent on the\nactive column), a filter input reusing the search field styling."
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Mobile"
        }), " — table collapses to stacked cards (label/value pairs), not a pinch-scroll\ngrid."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "States"
        }), " — loading (skeleton rows), empty (\"No people listed yet.\"), no-filter-match."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "why-these-three",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "why-these-three"
      }), "Why these three"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["They span the extension space the product promises: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "temporal"
      }), " (timeline), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "relational"
      }), "\n(tree/graph), and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "tabular"
      }), " (directory). If all three are designable in the Grove idiom\nand themeable via the same tokens/classes, the \"agent adds a view\" claim is visually\ncredible. Keep each one's chrome minimal and its data presentation the star."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "deliverable",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "deliverable"
      }), "Deliverable"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Each view at mobile + desktop, the three states, motion notes (restrained), and a short\nnote on which frontmatter fields drive it (so a dev/agent can wire it). Themeable via the\nbrief-00 token/class contract like everything else."
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/design-briefs/grove/briefs/04-extensibility-views.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiYmxvY2txdW90ZSIsImNvZGUiLCJlbSIsImgxIiwiaDIiLCJsaSIsInAiLCJzdHJvbmciLCJ1bCIsIl9wcm92aWRlQ29tcG9uZW50cyIsImNvbXBvbmVudHMiLCJIZWFkaW5nQW5jaG9yIiwiX21pc3NpbmdNZHhSZWZlcmVuY2UiLCJqc3hzIiwiRnJhZ21lbnQiLCJjaGlsZHJlbiIsImlkIiwianN4IiwiaHJlZiIsIk1EWENvbnRlbnQiLCJ3cmFwcGVyIiwiTURYTGF5b3V0IiwiX2MiLCJjb21wb25lbnQiLCJwbGFjZSIsIkVycm9yIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiMDQtZXh0ZW5zaWJpbGl0eS12aWV3cy5tZCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKkBqc3hSdW50aW1lIGF1dG9tYXRpYyovXG4vKkBqc3hJbXBvcnRTb3VyY2UgcmVhY3QqL1xuaW1wb3J0IHt1c2VNRFhDb21wb25lbnRzIGFzIF9wcm92aWRlQ29tcG9uZW50c30gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrL01EWFByb3ZpZGVyXCI7XG5mdW5jdGlvbiBfY3JlYXRlTWR4Q29udGVudChwcm9wcykge1xuICBjb25zdCBfY29tcG9uZW50cyA9IHtcbiAgICBhOiBcImFcIixcbiAgICBibG9ja3F1b3RlOiBcImJsb2NrcXVvdGVcIixcbiAgICBjb2RlOiBcImNvZGVcIixcbiAgICBlbTogXCJlbVwiLFxuICAgIGgxOiBcImgxXCIsXG4gICAgaDI6IFwiaDJcIixcbiAgICBsaTogXCJsaVwiLFxuICAgIHA6IFwicFwiLFxuICAgIHN0cm9uZzogXCJzdHJvbmdcIixcbiAgICB1bDogXCJ1bFwiLFxuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfSwge0hlYWRpbmdBbmNob3J9ID0gX2NvbXBvbmVudHM7XG4gIGlmICghSGVhZGluZ0FuY2hvcikgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJIZWFkaW5nQW5jaG9yXCIsIHRydWUpO1xuICByZXR1cm4gPD48X2NvbXBvbmVudHMuaDEgaWQ9XCJicmllZi0wNC1leHRlbnNpYmlsaXR5LXZpZXdzLXRoZS1hZ2VudC1idWlsdC1zdXJmYWNlc1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwiYnJpZWYtMDQtZXh0ZW5zaWJpbGl0eS12aWV3cy10aGUtYWdlbnQtYnVpbHQtc3VyZmFjZXNcIiAvPntcIkJyaWVmIDA0IOKAlCBFeHRlbnNpYmlsaXR5IHZpZXdzICh0aGUgYWdlbnQtYnVpbHQgc3VyZmFjZXMpXCJ9PC9fY29tcG9uZW50cy5oMT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJHcm92ZSdzIHNpZ25hdHVyZSBjbGFpbSBpcyB0aGF0IGEgY29kaW5nIGFnZW50IGNhbiBhZGQgdmlld3MgaXRzIGF1dGhvcnMgbmV2ZXIgaW1hZ2luZWQsXFxucmVhZGluZyBleGlzdGluZyBmcm9udG1hdHRlciwgd2l0aG91dCBjaGFuZ2luZyBob3cgZW50cmllcyBhcmUgd3JpdHRlbiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZ3JvdmUubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxuXFxcIkV4dGVuZGluZyBHcm92ZSB3aXRoIGEgY29kaW5nIGFnZW50XFxcIikuIFRoZXNlIHRocmVlIHZpZXdzIGFyZSB0aGUgd29ya2VkIGV4YW1wbGVzIOKAlCBkZXNpZ25cXG50aGVtIGJvdGggYXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJwcm9vZiB0aGUgZXh0ZW5zaW9uIHN1cmZhY2UgaXMgZGVzaWduYWJsZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBhbmQgYXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJvbi1icmFuZCByZWZlcmVuY2VcXG5pbXBsZW1lbnRhdGlvbnNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYW4gYWdlbnQgY2FuIHRhcmdldC4gQXNzdW1lcyBcIn08X2NvbXBvbmVudHMuYSBocmVmPVwiLi8wMC1mb3VuZGF0aW9uLm1kXCI+PF9jb21wb25lbnRzLmNvZGU+e1wiMDAtZm91bmRhdGlvblwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLmE+e1wiLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuYmxvY2txdW90ZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGVzZSBhcmUgXCJ9PF9jb21wb25lbnRzLmVtPntcImV4YW1wbGVcIn08L19jb21wb25lbnRzLmVtPntcIiBleHRlbnNpb25zLCBub3QgY29yZSBjaHJvbWUuIERlc2lnbiB0aGVtIHRvIGZlZWwgbmF0aXZlIHRvIEdyb3ZlXFxuKHNhbWUgdG9rZW5zLCBzYW1lIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi5ncm92ZS0qXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpZGlvbSkgc28gYSBmb3JrIHRoYXQgYWRkcyB0aGVtIGxvb2tzIGZpcnN0LXBhcnR5IOKAlCBidXRcXG5ub3RlIGluIHRoZSBpbnZlbnRvcnkgdGhhdCB0aGV5J3JlIG9wdGlvbmFsLCBhZ2VudC1hZGRlZCBjb21wb25lbnRzLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08L19jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTFcIiBkYXRhLXNsdWc9XCIxLWFuaW1hdGVkLXRpbWVsaW5lLWdyb3ZlbWQtd29ya2VkLWV4YW1wbGVcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy0xXCIgLz57XCIxLiBBbmltYXRlZCB0aW1lbGluZSAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZ3JvdmUubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHdvcmtlZCBleGFtcGxlKVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiUmVhZHMgZXZlcnkgZW50cnkgd2l0aCBhIFwifTxfY29tcG9uZW50cy5jb2RlPntcImRhdGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFuZCBsYXlzIHRoZW0gb24gYSB0aW1lIGF4aXMuIFRoZSBmYW1pbHktam91cm5hbCBhbmRcXG5jaGFuZ2Vsb2cgaGVybyB2aWV3LlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRGVza3RvcFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgYSBob3Jpem9udGFsIG9yIHZlcnRpY2FsIHRpbWUgYXhpcyB3aXRoIGhhaXJsaW5lIGdyaWRsaW5lcyBhbmQgbW9ubyB5ZWFyL1xcbm1vbnRoIG1hcmtlcnM7IGVhY2ggZW50cnkgYSBub2RlICh0aGUgbGluay1ncmFwaCBub2RlIG1vdGlmKSBvbiB0aGUgYXhpcyB3aXRoIHRpdGxlLFxcbmRhdGUsIGFuZCBhbiBvcHRpb25hbCB0aHVtYm5haWwvYXNzZXQ7IGNsdXN0ZXJzIHdoZW4gZGVuc2U7IHRoZSBhY2NlbnQgbWFya3MgXFxcInRvZGF5XFxcIi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIk1vdGlvblwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgcmVzdHJhaW5lZCByZXZlYWwgYXMgdGhlIGF4aXMgc2Nyb2xscyBpbnRvIHZpZXcgKHJlc3BlY3RcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJwcmVmZXJzLXJlZHVjZWQtbW90aW9uXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjsgdGhlIGJyYW5kIGJhbnMgYm91bmNlL3NwcmluZyDigJQga2VlcCBpdCBhIHNtb290aCBmYWRlL3NsaWRlLFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcIi4xNHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wi4oCTc2NhbGUsIG5vdCB0aGVhdHJpY2FsKS4gXFxcIkFuaW1hdGVkXFxcIiBoZXJlIG1lYW5zIHRhc3RlZnVsIHByb2dyZXNzaXZlIHJldmVhbCwgbm90IGFcXG5jYXJvdXNlbC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIk1vYmlsZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgdmVydGljYWwgYXhpcywgc2luZ2xlIGNvbHVtbiwgbm9kZXMgc3RhY2s7IHN0aWNreSBkYXRlIGhlYWRlcnMuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJTdGF0ZXNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIGxvYWRpbmcgKGF4aXMgc2tlbGV0b24gd2l0aCBnaG9zdCBub2RlcyksIGVtcHR5IChcXFwiTm8gZGF0ZWQgZW50cmllcyB5ZXQuXFxcIiksXFxuYW5kIGEgZGVuc2UtZGF0YSBzdGF0ZSAoaHVuZHJlZHMgb2Ygbm9kZXMg4oaSIGdyb3VwaW5nL3pvb20gYWZmb3JkYW5jZSkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInNlYy0yXCIgZGF0YS1zbHVnPVwiMi1mYW1pbHktdHJlZS1yZWxhdGlvbnNoaXAtZ3JhcGhcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy0yXCIgLz57XCIyLiBGYW1pbHkgdHJlZSAvIHJlbGF0aW9uc2hpcCBncmFwaFwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiUmVhZHMgZ2VuZWFsb2d5IGZyb250bWF0dGVyIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJwYXJlbnRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJob3VzZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIOKApikgZm9yIHRoZSBMT1RSIGNhc2UuIFR3byBwcmVzZW50YXRpb25zXFxudG8gc2tldGNoOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVHJlZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgYSBjbGFzc2ljIGhpZXJhcmNoaWNhbCBnZW5lYWxvZ3k6IG5vZGVzIChuYW1lICsgZGF0ZXMpIGpvaW5lZCBieSBoYWlybGluZVxcbmVkZ2VzOyB0aGUgY3VycmVudCBlbnRyeSBoaWdobGlnaHRlZDsgY29sbGFwc2libGUgYnJhbmNoZXM7IHBhbi96b29tIG9uIGRlc2t0b3AsXFxuaG9yaXpvbnRhbCBzY3JvbGwgb24gbW9iaWxlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiR3JhcGhcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHdoZW4gcmVsYXRpb25zaGlwcyBhcmVuJ3QgYSBjbGVhbiB0cmVlLCB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJsaW5rLWdyYXBoIG1vdGlmIG1hZGVcXG5saXRlcmFsXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiOiBub2RlcyArIGxhYmVsbGVkIGVkZ2VzLCBmb3JjZS1kaXJlY3RlZC1pc2ggYnV0IGxlZ2libGUuIFRoaXMgaXMgd2hlcmUgR3JvdmUnc1xcbm5vZGUtYW5kLWVkZ2UgaWRlbnRpdHkgcGF5cyBvZmYgdmlzdWFsbHkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJTdGF0ZXNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIGxvYWRpbmcgKGdob3N0IG5vZGVzL2VkZ2VzKSwgZW1wdHkgKFxcXCJObyByZWxhdGlvbnNoaXBzIGRlZmluZWQuXFxcIiksIGFuZCBhblxcbm92ZXJmbG93IHN0YXRlICh0b28gbWFueSBub2RlcyDihpIgZm9jdXMgKyBuZWlnaGJvdXJob29kIHZpZXcpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtM1wiIGRhdGEtc2x1Zz1cIjMtZGlyZWN0b3J5LXRhYmxlLXRoZS1jb21wYW55LXBob25lLWJvb2tcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy0zXCIgLz57XCIzLiBEaXJlY3RvcnkgLyB0YWJsZSAodGhlIGNvbXBhbnkgcGhvbmUgYm9vaylcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlJlYWRzIHN0cnVjdHVyZWQgZnJvbnRtYXR0ZXIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIm5hbWVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyb2xlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicGhvbmVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCDigKYpIGFjcm9zcyBhIHNldCBvZiBlbnRyaWVzIGFuZFxcbnJlbmRlcnMgYSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInNvcnRhYmxlLCBmaWx0ZXJhYmxlIHRhYmxlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLiBUaGUgS0IgY2FzZS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJIYWlybGluZSB0YWJsZSwgbW9ubyBmb3IgcGhvbmUgbnVtYmVycy9JRHMsIHN0aWNreSBoZWFkZXIsIGNsaWNrLXRvLXNvcnQgKGFjY2VudCBvbiB0aGVcXG5hY3RpdmUgY29sdW1uKSwgYSBmaWx0ZXIgaW5wdXQgcmV1c2luZyB0aGUgc2VhcmNoIGZpZWxkIHN0eWxpbmcuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJNb2JpbGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHRhYmxlIGNvbGxhcHNlcyB0byBzdGFja2VkIGNhcmRzIChsYWJlbC92YWx1ZSBwYWlycyksIG5vdCBhIHBpbmNoLXNjcm9sbFxcbmdyaWQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJTdGF0ZXNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIGxvYWRpbmcgKHNrZWxldG9uIHJvd3MpLCBlbXB0eSAoXFxcIk5vIHBlb3BsZSBsaXN0ZWQgeWV0LlxcXCIpLCBuby1maWx0ZXItbWF0Y2guXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cIndoeS10aGVzZS10aHJlZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwid2h5LXRoZXNlLXRocmVlXCIgLz57XCJXaHkgdGhlc2UgdGhyZWVcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZXkgc3BhbiB0aGUgZXh0ZW5zaW9uIHNwYWNlIHRoZSBwcm9kdWN0IHByb21pc2VzOiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInRlbXBvcmFsXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICh0aW1lbGluZSksIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicmVsYXRpb25hbFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIlxcbih0cmVlL2dyYXBoKSwgYW5kIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1widGFidWxhclwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoZGlyZWN0b3J5KS4gSWYgYWxsIHRocmVlIGFyZSBkZXNpZ25hYmxlIGluIHRoZSBHcm92ZSBpZGlvbVxcbmFuZCB0aGVtZWFibGUgdmlhIHRoZSBzYW1lIHRva2Vucy9jbGFzc2VzLCB0aGUgXFxcImFnZW50IGFkZHMgYSB2aWV3XFxcIiBjbGFpbSBpcyB2aXN1YWxseVxcbmNyZWRpYmxlLiBLZWVwIGVhY2ggb25lJ3MgY2hyb21lIG1pbmltYWwgYW5kIGl0cyBkYXRhIHByZXNlbnRhdGlvbiB0aGUgc3Rhci5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwiZGVsaXZlcmFibGVcIj48SGVhZGluZ0FuY2hvciBpZD1cImRlbGl2ZXJhYmxlXCIgLz57XCJEZWxpdmVyYWJsZVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiRWFjaCB2aWV3IGF0IG1vYmlsZSArIGRlc2t0b3AsIHRoZSB0aHJlZSBzdGF0ZXMsIG1vdGlvbiBub3RlcyAocmVzdHJhaW5lZCksIGFuZCBhIHNob3J0XFxubm90ZSBvbiB3aGljaCBmcm9udG1hdHRlciBmaWVsZHMgZHJpdmUgaXQgKHNvIGEgZGV2L2FnZW50IGNhbiB3aXJlIGl0KS4gVGhlbWVhYmxlIHZpYSB0aGVcXG5icmllZi0wMCB0b2tlbi9jbGFzcyBjb250cmFjdCBsaWtlIGV2ZXJ5dGhpbmcgZWxzZS5cIn08L19jb21wb25lbnRzLnA+PC8+O1xufVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTURYQ29udGVudChwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHt3cmFwcGVyOiBNRFhMYXlvdXR9ID0ge1xuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfTtcbiAgcmV0dXJuIE1EWExheW91dCA/IDxNRFhMYXlvdXQgey4uLnByb3BzfT48X2NyZWF0ZU1keENvbnRlbnQgey4uLnByb3BzfSAvPjwvTURYTGF5b3V0PiA6IF9jcmVhdGVNZHhDb250ZW50KHByb3BzKTtcbn1cbmZ1bmN0aW9uIF9taXNzaW5nTWR4UmVmZXJlbmNlKGlkLCBjb21wb25lbnQsIHBsYWNlKSB7XG4gIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIFwiICsgKGNvbXBvbmVudCA/IFwiY29tcG9uZW50XCIgOiBcIm9iamVjdFwiKSArIFwiIGBcIiArIGlkICsgXCJgIHRvIGJlIGRlZmluZWQ6IHlvdSBsaWtlbHkgZm9yZ290IHRvIGltcG9ydCwgcGFzcywgb3IgcHJvdmlkZSBpdC5cIiArIChwbGFjZSA/IFwiXFxuSXTigJlzIHJlZmVyZW5jZWQgaW4geW91ciBjb2RlIGF0IGBcIiArIHBsYWNlICsgXCJgIGluIGAvYXBwL2RvY3MvZGVzaWduLWJyaWVmcy9ncm92ZS9icmllZnMvMDQtZXh0ZW5zaWJpbGl0eS12aWV3cy5tZGBcIiA6IFwiXCIpKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQXdGLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUZ4RjtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU1DLFdBQVcsR0FBRztNQUNsQkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsVUFBVSxFQUFFLFlBQVk7TUFDeEJDLElBQUksRUFBRSxNQUFNO01BQ1pDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLENBQUMsRUFBRSxHQUFHO01BQ05DLE1BQU0sRUFBRSxRQUFRO01BQ2hCQyxFQUFFLEVBQUUsSUFBSTtNQUNSLEdBQUcsSUFBQUMsNkJBQWtCLEVBQUMsQ0FBQztNQUN2QixHQUFHWixLQUFLLENBQUNhO0lBQ1gsQ0FBQztJQUFFO01BQUNDO0lBQWEsQ0FBQyxHQUFHYixXQUFXO0VBQ2hDLElBQUksQ0FBQ2EsYUFBYSxFQUFFQyxvQkFBb0IsQ0FBQyxlQUFlLEVBQUUsSUFBSSxDQUFDO0VBQy9ELG9CQUFPLElBQUFqQixXQUFBLENBQUFrQixJQUFBLEVBQUFsQixXQUFBLENBQUFtQixRQUFBO0lBQUFDLFFBQUEsZ0JBQUUsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDSyxFQUFFO01BQUNhLEVBQUUsRUFBQyx1REFBdUQ7TUFBQUQsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUF1RCxDQUFFLENBQUMsRUFBQywyREFBMkQ7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ1EsQ0FBQztNQUFBUyxRQUFBLEdBQUUsb0tBQW9LLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0csSUFBSTtRQUFBYyxRQUFBLEVBQUU7TUFBVSxDQUFtQixDQUFDLEVBQUMsK0dBQStHLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBMkMsQ0FBcUIsQ0FBQyxFQUFDLFVBQVUsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDUyxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFxQyxDQUFxQixDQUFDLEVBQUMsZ0NBQWdDLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsQ0FBQztRQUFDbUIsSUFBSSxFQUFDLG9CQUFvQjtRQUFBSCxRQUFBLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0csSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBZSxDQUFtQjtNQUFDLENBQWUsQ0FBQyxFQUFDLEdBQUc7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ0UsVUFBVTtNQUFBZSxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ1EsQ0FBQztRQUFBUyxRQUFBLEdBQUUsWUFBWSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNJLEVBQUU7VUFBQWEsUUFBQSxFQUFFO1FBQVMsQ0FBaUIsQ0FBQyxFQUFDLHdGQUF3RixlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNHLElBQUk7VUFBQWMsUUFBQSxFQUFFO1FBQVUsQ0FBbUIsQ0FBQyxFQUFDLGdJQUFnSTtNQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBeUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7TUFBQ1ksRUFBRSxFQUFDLE9BQU87TUFBQyxhQUFVLDRDQUE0QztNQUFBRCxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMsd0JBQXdCLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0csSUFBSTtRQUFBYyxRQUFBLEVBQUU7TUFBVSxDQUFtQixDQUFDLEVBQUMsa0JBQWtCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNRLENBQUM7TUFBQVMsUUFBQSxHQUFFLDJCQUEyQixlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNHLElBQUk7UUFBQWMsUUFBQSxFQUFFO01BQU0sQ0FBbUIsQ0FBQyxFQUFDLDZFQUE2RTtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDVSxFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTyxFQUFFO1FBQUFVLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBUyxDQUFxQixDQUFDLEVBQUMsNlBBQTZQO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNPLEVBQUU7UUFBQVUsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDUyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFRLENBQXFCLENBQUMsRUFBQywrREFBK0QsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRyxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUF3QixDQUFtQixDQUFDLEVBQUMsaUVBQWlFLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0csSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBTSxDQUFtQixDQUFDLEVBQUMsZ0dBQWdHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNPLEVBQUU7UUFBQVUsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDUyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFRLENBQXFCLENBQUMsRUFBQyxvRUFBb0U7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ08sRUFBRTtRQUFBVSxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQVEsQ0FBcUIsQ0FBQyxFQUFDLHlKQUF5SjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7TUFBQ1ksRUFBRSxFQUFDLE9BQU87TUFBQyxhQUFVLGtDQUFrQztNQUFBRCxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMscUNBQXFDO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNRLENBQUM7TUFBQVMsUUFBQSxHQUFFLCtCQUErQixlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNHLElBQUk7UUFBQWMsUUFBQSxFQUFFO01BQVEsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRyxJQUFJO1FBQUFjLFFBQUEsRUFBRTtNQUFPLENBQW1CLENBQUMsRUFBQyx1REFBdUQ7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ1UsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ08sRUFBRTtRQUFBVSxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQU0sQ0FBcUIsQ0FBQyxFQUFDLDhMQUE4TDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTyxFQUFFO1FBQUFVLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBTyxDQUFxQixDQUFDLEVBQUMsaURBQWlELGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBZ0MsQ0FBcUIsQ0FBQyxFQUFDLDRIQUE0SDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTyxFQUFFO1FBQUFVLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBUSxDQUFxQixDQUFDLEVBQUMsOElBQThJO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ00sRUFBRTtNQUFDWSxFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUsMENBQTBDO01BQUFELFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQywrQ0FBK0M7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ1EsQ0FBQztNQUFBUyxRQUFBLEdBQUUsZ0NBQWdDLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0csSUFBSTtRQUFBYyxRQUFBLEVBQUU7TUFBTSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNHLElBQUk7UUFBQWMsUUFBQSxFQUFFO01BQU0sQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRyxJQUFJO1FBQUFjLFFBQUEsRUFBRTtNQUFPLENBQW1CLENBQUMsRUFBQyw4Q0FBOEMsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDUyxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUE0QixDQUFxQixDQUFDLEVBQUMsZ0JBQWdCO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNVLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDTyxFQUFFO1FBQUFVLFFBQUEsRUFBRTtNQUEySixDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ08sRUFBRTtRQUFBVSxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQVEsQ0FBcUIsQ0FBQyxFQUFDLG9GQUFvRjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTyxFQUFFO1FBQUFVLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBUSxDQUFxQixDQUFDLEVBQUMsaUZBQWlGO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ00sRUFBRTtNQUFDWSxFQUFFLEVBQUMsaUJBQWlCO01BQUFELFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBaUIsQ0FBRSxDQUFDLEVBQUMsaUJBQWlCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNRLENBQUM7TUFBQVMsUUFBQSxHQUFFLHNEQUFzRCxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQVUsQ0FBcUIsQ0FBQyxFQUFDLGVBQWUsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDUyxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFZLENBQXFCLENBQUMsRUFBQyxzQkFBc0IsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDUyxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFTLENBQXFCLENBQUMsRUFBQyxvT0FBb087SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ00sRUFBRTtNQUFDWSxFQUFFLEVBQUMsYUFBYTtNQUFBRCxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQWEsQ0FBRSxDQUFDLEVBQUMsYUFBYTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1EsQ0FBQztNQUFBUyxRQUFBLEVBQUU7SUFBeU8sQ0FBZ0IsQ0FBQztFQUFBLENBQUUsQ0FBQztBQUNueU07QUFDZSxTQUFTSSxVQUFVQSxDQUFDdEIsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFO0VBQzdDLE1BQU07SUFBQ3VCLE9BQU8sRUFBRUM7RUFBUyxDQUFDLEdBQUc7SUFDM0IsR0FBRyxJQUFBWiw2QkFBa0IsRUFBQyxDQUFDO0lBQ3ZCLEdBQUdaLEtBQUssQ0FBQ2E7RUFDWCxDQUFDO0VBQ0QsT0FBT1csU0FBUyxnQkFBRyxJQUFBMUIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDSSxTQUFTO0lBQUEsR0FBS3hCLEtBQUs7SUFBQWtCLFFBQUEsZUFBRSxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDckIsaUJBQWlCO01BQUEsR0FBS0M7SUFBSyxDQUFHO0VBQUMsQ0FBVyxDQUFDLEdBQUdELGlCQUFpQixDQUFDQyxLQUFLLENBQUM7QUFDbEg7QUFBQ3lCLEVBQUEsR0FOdUJILFVBQVU7QUFPbEMsU0FBU1Asb0JBQW9CQSxDQUFDSSxFQUFFLEVBQUVPLFNBQVMsRUFBRUMsS0FBSyxFQUFFO0VBQ2xELE1BQU0sSUFBSUMsS0FBSyxDQUFDLFdBQVcsSUFBSUYsU0FBUyxHQUFHLFdBQVcsR0FBRyxRQUFRLENBQUMsR0FBRyxJQUFJLEdBQUdQLEVBQUUsR0FBRyxvRUFBb0UsSUFBSVEsS0FBSyxHQUFHLHFDQUFxQyxHQUFHQSxLQUFLLEdBQUcsdUVBQXVFLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDalM7QUFBQyxJQUFBRixFQUFBO0FBQUFJLFlBQUEsQ0FBQUosRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}