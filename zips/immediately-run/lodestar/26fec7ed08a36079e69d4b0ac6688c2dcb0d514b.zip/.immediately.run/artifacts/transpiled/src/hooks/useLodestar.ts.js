"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.BUSY_LABELS = void 0;
exports.applySelection = applySelection;
exports.useLodestar = useLodestar;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.find.js");
require("core-js/modules/esnext.iterator.for-each.js");
require("core-js/modules/esnext.iterator.map.js");
require("core-js/modules/esnext.iterator.some.js");
var _react = require("react");
var _camera = require("../lib/camera");
var _geometry = require("../lib/geometry");
var _ids = require("../lib/ids");
var _seedBoard = require("../data/seedBoard");
var _boardStore = require("../lib/boardStore");
var _pickFile = require("../lib/pickFile");
var _mounts = require("@immediately-run/sdk/mounts");
var _openProject = require("../lib/openProject");
// Lodestar's single source of truth: camera, objects, selection, and all
// pointer/keyboard gesture logic. Ported from the design comp's controller into
// one hook so the presentational components stay thin. Geometry gestures write
// "once, on gesture end" (spec §5.1); here the write is an in-memory mutation +
// a saved-toast, the seam where the persistence layer (§2.6 round-trip discipline)
// will attach once the change layer lands.

// Subpath import, not the package barrel: the barrel re-exports `./tasks`,
// whose top-level `addListener` side effect throws `no host transport` at
// module-eval time under local `vite dev`. `/mounts` is side-effect-free.

/** Join a mount root with a (validated, relative) path; collapse double slashes. */
const subPath = (root, rel) => `${root}/${rel}`.replace(/\/+/g, '/');

/** Short ` · code` suffix from a typed platform/fs error, for toast text. */
function codeOf(e) {
  const c = e?.code;
  return c ? ` · ${c}` : '';
}
const initialViewport = () => ({
  vw: typeof window !== 'undefined' ? window.innerWidth : 1440,
  vh: typeof window !== 'undefined' ? window.innerHeight : 900,
  vleft: 0,
  vtop: 0
});

/** The ONE spelling of selection semantics (R3-607, R6): given the current
 *  selection and an id, the next selection for a replace- or toggle-click /
 *  focus. Pure, so the pointer path and the keyboard path cannot drift. */
function applySelection(sel, id, additive) {
  if (additive) return sel.includes(id) ? sel.filter(x => x !== id) : sel.concat(id);
  return sel.includes(id) ? sel : [id];
}
const MOBILE_BREAKPOINT = 720;

// The board-manifest schema version THIS reader understands. A manifest carrying
// a higher `schema:` is from a newer reader — recognised but marked readonly (the
// `readonly` degraded state, spec §2.4) rather than mis-rendered (R3-401).
const SUPPORTED_SCHEMA = 1;

// The usable height a journey-playing rect view fits into: the caption + controls
// take roughly the bottom 240px of an 844px phone viewport (item R3-400), so a
// fitted view must clear that band or the subject hides under the chrome.
const JOURNEY_FIT_INSET = 240;
const prefersReducedMotion = () => {
  try {
    return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  } catch {
    return false;
  }
};

/** The ONE spelling of what each named busy state says on its control
 *  (R-IX-2 / R6): every surface that names a wait reads this map — coupled
 *  surfaces cannot drift apart on a reword. */
const BUSY_LABELS = exports.BUSY_LABELS = {
  'insert-image': 'Adding image…',
  'new-board': 'Creating board…',
  'open-board': 'Opening board…'
};
function useLodestar() {
  // The canvas element arrives via a callback ref (a function, not a ref object
  // read during render) so the listener effect re-runs once it mounts.
  const [canvasEl, setCanvasEl] = (0, _react.useState)(null);
  const registerCanvas = (0, _react.useCallback)(el => setCanvasEl(el), []);
  const dragRef = (0, _react.useRef)(null);
  const tweenRef = (0, _react.useRef)(null);
  const holdTimer = (0, _react.useRef)(null);
  const spaceRef = (0, _react.useRef)(false);
  const toastSeq = (0, _react.useRef)(0);
  // Stable indirection for the dwell auto-advance: `goStep` schedules
  // `playNextRef.current()` so the timer always calls the LATEST playNext
  // (assigned after its useCallback is defined) — breaks the circular dep.
  const playNextRef = (0, _react.useRef)(() => {});
  const [state, setState] = (0, _react.useState)(() => ({
    mode: 'run',
    light: false,
    bg: _seedBoard.BOARD.background,
    title: _seedBoard.BOARD.title,
    cam: {
      cx: 250,
      cy: 150,
      zoom: 0.6
    },
    vp: initialViewport(),
    objects: (0, _seedBoard.seedObjects)(),
    views: _seedBoard.SEED_VIEWS.slice(),
    journeys: _seedBoard.SEED_JOURNEYS,
    selection: [],
    hover: null,
    marquee: null,
    connectPreview: null,
    connectFrom: null,
    connectCursor: null,
    inspectorOpen: false,
    panelOpen: false,
    quickMenu: null,
    journey: null,
    toasts: [],
    screen: null,
    demoMenuOpen: false,
    panning: false,
    reduced: prefersReducedMotion(),
    busy: null,
    mounts: []
  }));

  // Mirror committed state so the document-level handlers branch on fresh values.
  const stateRef = (0, _react.useRef)(state);
  (0, _react.useEffect)(() => {
    stateRef.current = state;
  });
  const update = (0, _react.useCallback)(patch => setState(prev => ({
    ...prev,
    ...(typeof patch === 'function' ? patch(prev) : patch)
  })), []);
  const isMobile = (0, _react.useCallback)(() => state.vp.vw < MOBILE_BREAKPOINT, [state.vp.vw]);

  // ---- camera helpers (read latest viewport from the ref) ----
  const localPoint = (0, _react.useCallback)(e => {
    const vp = stateRef.current.vp;
    return [e.clientX - vp.vleft, e.clientY - vp.vtop];
  }, []);
  const setZoom = (0, _react.useCallback)((nz, lx, ly) => {
    update(s => ({
      cam: (0, _camera.zoomAround)(s.cam, s.vp, nz, lx, ly)
    }));
  }, [update]);

  // ---- toasts ----
  const dismissToast = (0, _react.useCallback)(id => {
    update(s => ({
      toasts: s.toasts.filter(t => t.id !== id)
    }));
  }, [update]);
  const toast = (0, _react.useCallback)((text, icon = 'check', opts = {}) => {
    const id = ++toastSeq.current;
    const t = {
      id,
      text,
      icon,
      ...opts
    };
    update(s => ({
      toasts: s.toasts.concat(t)
    }));
    const ttl = opts.actionLabel ? 9000 : 3500;
    setTimeout(() => dismissToast(id), ttl);
  }, [update, dismissToast]);

  // ---- persistence (the §2.6 round-trip seam, now live) ----
  // The board's durable target (a per-user app space) once resolved; null means
  // we never got one (signed out / declined) and the board is in memory only.
  const boardRef = (0, _react.useRef)(null);
  // Per-object debounce timers so inspector typing / arrow nudges autosave once
  // they settle, not on every keystroke.
  const saveTimers = (0, _react.useRef)(new Map());

  // Write the given objects' files, then report with one toast. With no board
  // the change is in memory only (we keep the optimistic message); a read-only
  // board reports instead of silently dropping the write.
  const commitSave = (0, _react.useCallback)((objs, savedText, savedIcon = 'check') => {
    const t = boardRef.current;
    if (!t) {
      toast(savedText, savedIcon);
      return;
    }
    if (t.mode === 'ro') {
      toast('Read-only board · change not saved', 'lock', {
        iconColor: 'var(--ink-2)'
      });
      return;
    }
    Promise.all(objs.map(o => (0, _boardStore.saveObject)(t, o))).then(() => toast(savedText, savedIcon), e => toast(`Save failed${codeOf(e)}`, 'alert', {
      iconColor: '#caa24a'
    }));
  }, [toast]);

  // Quiet debounced autosave for continuous edits (typing, arrow-key nudges).
  const scheduleSave = (0, _react.useCallback)(ids => {
    const t = boardRef.current;
    if (!t || t.mode === 'ro') return;
    for (const id of ids) {
      const prev = saveTimers.current.get(id);
      if (prev) clearTimeout(prev);
      const handle = window.setTimeout(() => {
        saveTimers.current.delete(id);
        const o = stateRef.current.objects.find(x => x.id === id);
        if (o) (0, _boardStore.saveObject)(t, o).catch(() => undefined);
      }, 500);
      saveTimers.current.set(id, handle);
    }
  }, []);

  // ---- camera animation ----
  const flyTo = (0, _react.useCallback)((target, dur, fitH) => {
    if (!target) return;
    // A view carrying a rect names a REGION, not a magnification: fit it to the
    // usable viewport (R3-400). fitH (when given) is the usable height — the
    // caption band during journey playback — so the subject clears the chrome.
    const dest = (0, _camera.cameraForTarget)(target, stateRef.current.vp.vw, fitH ?? stateRef.current.vp.vh);
    if (tweenRef.current) cancelAnimationFrame(tweenRef.current);
    if (stateRef.current.reduced || !dur) {
      update({
        cam: dest
      });
      return;
    }
    const from = {
      ...stateRef.current.cam
    };
    const t0 = performance.now();
    const ease = p => p < 0.5 ? 4 * p * p * p : 1 - Math.pow(-2 * p + 2, 3) / 2;
    const step = now => {
      const p = Math.min(1, (now - t0) / dur);
      const e = ease(p);
      update({
        cam: {
          cx: from.cx + (dest.cx - from.cx) * e,
          cy: from.cy + (dest.cy - from.cy) * e,
          zoom: from.zoom + (dest.zoom - from.zoom) * e
        }
      });
      if (p < 1) tweenRef.current = requestAnimationFrame(step);
    };
    tweenRef.current = requestAnimationFrame(step);
  }, [update]);

  // ---- views & journeys ----
  const resolveView = (0, _react.useCallback)(v => {
    if (typeof v === 'string') return stateRef.current.views.find(x => x.name === v) ?? null;
    const t = {
      cx: v.cx,
      cy: v.cy,
      zoom: v.zoom
    };
    if (v.w) t.w = v.w;
    if (v.h) t.h = v.h;
    return t;
  }, []);
  const saveView = (0, _react.useCallback)(() => {
    const s = stateRef.current;
    const view = {
      name: `view-${s.views.length + 1}`,
      cx: s.cam.cx,
      cy: s.cam.cy,
      zoom: s.cam.zoom
    };
    update(st => ({
      views: st.views.concat([view])
    }));
    const text = `Saved views/${view.name}.md`;
    const t = boardRef.current;
    if (!t) {
      toast(text, 'save');
      return;
    }
    if (t.mode === 'ro') {
      toast('Read-only board · view not saved', 'lock', {
        iconColor: 'var(--ink-2)'
      });
      return;
    }
    (0, _boardStore.saveView)(t, view).then(() => toast(text, 'save'), e => toast(`Couldn't save view${codeOf(e)}`, 'alert', {
      iconColor: '#caa24a'
    }));
  }, [update, toast]);

  /** Remove a view on the surface that creates them (R3-607, R-IX-5). A
   *  read-only board refuses BEFORE anything drops (the row never vanishes
   *  into a refusal); on writable boards the drop is optimistic and a failed
   *  file removal rolls the view back in. */
  const deleteView = (0, _react.useCallback)(name => {
    const t = boardRef.current;
    const view = stateRef.current.views.find(v => v.name === name);
    if (!view) return;
    if (t && t.mode === 'ro') {
      toast('Read-only board · view not removed', 'lock', {
        iconColor: 'var(--ink-2)'
      });
      return;
    }
    update(s => ({
      views: s.views.filter(v => v.name !== name)
    }));
    if (!t) {
      toast(`Removed views/${name}.md`, 'trash');
      return;
    }
    (0, _boardStore.removeView)(t, name).then(() => toast(`Removed views/${name}.md`, 'trash'), e => {
      // Roll the optimistic drop back — the file survived, so must the row.
      update(s => s.views.some(v => v.name === name) ? {} : {
        views: s.views.concat([view])
      });
      toast(`Couldn't remove view${codeOf(e)}`, 'alert', {
        iconColor: '#caa24a'
      });
    });
  }, [update, toast]);
  const addJourneyStep = (0, _react.useCallback)(jid => {
    const s = stateRef.current;
    const j = s.journeys.find(x => x.id === jid);
    if (!j) return;
    const next = {
      ...j,
      steps: j.steps.concat([{
        view: {
          cx: s.cam.cx,
          cy: s.cam.cy,
          zoom: s.cam.zoom
        }
      }])
    };
    update(st => ({
      journeys: st.journeys.map(x => x.id === jid ? next : x)
    }));
    const text = `Added step ${next.steps.length} to ${j.title} · saved to ${j.id}.mdx`;
    const t = boardRef.current;
    if (!t) {
      toast(text, 'plus');
      return;
    }
    if (t.mode === 'ro') {
      toast('Read-only board · step not saved', 'lock', {
        iconColor: 'var(--ink-2)'
      });
      return;
    }
    (0, _boardStore.saveJourney)(t, next).then(() => toast(text, 'plus'), e => toast(`Couldn't save journey${codeOf(e)}`, 'alert', {
      iconColor: '#caa24a'
    }));
  }, [update, toast]);
  const goStep = (0, _react.useCallback)((j, idx, instant) => {
    const s = j.steps[idx];
    const v = resolveView(s.view);
    if (v) flyTo(v, instant ? 0 : s.duration ?? 800, stateRef.current.vp.vh - JOURNEY_FIT_INSET);
    // Dwell (R3-402): a step carrying `hold` pauses that long after arriving,
    // then AUTO-advances. Cleared by any viewer control (next/prev/seek/exit).
    // Under prefers-reduced-motion the journey stays input-driven — matching
    // flyTo's cut of the tween — so a viewer is never advanced unprompted.
    if (holdTimer.current) {
      clearTimeout(holdTimer.current);
      holdTimer.current = null;
    }
    if (s.hold && !stateRef.current.reduced) {
      holdTimer.current = window.setTimeout(() => playNextRef.current(), s.hold);
    }
  }, [resolveView, flyTo]);
  const playJourney = (0, _react.useCallback)(jid => {
    const j = stateRef.current.journeys.find(x => x.id === jid);
    if (!j) return;
    if (holdTimer.current) {
      clearTimeout(holdTimer.current);
      holdTimer.current = null;
    }
    update({
      journey: {
        jid,
        idx: 0
      },
      panelOpen: false,
      inspectorOpen: false
    });
    goStep(j, 0, true);
  }, [update, goStep]);
  const playExit = (0, _react.useCallback)(() => {
    if (tweenRef.current) cancelAnimationFrame(tweenRef.current);
    if (holdTimer.current) {
      clearTimeout(holdTimer.current);
      holdTimer.current = null;
    }
    update({
      journey: null
    });
  }, [update]);
  const playNext = (0, _react.useCallback)(() => {
    const jr = stateRef.current.journey;
    if (!jr) return;
    if (holdTimer.current) {
      clearTimeout(holdTimer.current);
      holdTimer.current = null;
    }
    const j = stateRef.current.journeys.find(x => x.id === jr.jid);
    if (!j) return;
    const ni = jr.idx + 1;
    if (ni >= j.steps.length) {
      playExit();
      return;
    }
    update({
      journey: {
        ...jr,
        idx: ni
      }
    });
    goStep(j, ni);
  }, [update, goStep, playExit]);
  // Keep the dwell timer's indirection pointed at the current playNext.
  playNextRef.current = playNext;
  const playPrev = (0, _react.useCallback)(() => {
    const jr = stateRef.current.journey;
    if (!jr) return;
    if (holdTimer.current) {
      clearTimeout(holdTimer.current);
      holdTimer.current = null;
    }
    const j = stateRef.current.journeys.find(x => x.id === jr.jid);
    if (!j) return;
    const ni = Math.max(0, jr.idx - 1);
    update({
      journey: {
        ...jr,
        idx: ni
      }
    });
    goStep(j, ni);
  }, [update, goStep]);
  const playSeek = (0, _react.useCallback)(idx => {
    const jr = stateRef.current.journey;
    if (!jr) return;
    if (holdTimer.current) {
      clearTimeout(holdTimer.current);
      holdTimer.current = null;
    }
    const j = stateRef.current.journeys.find(x => x.id === jr.jid);
    if (!j) return;
    update({
      journey: {
        ...jr,
        idx
      }
    });
    goStep(j, idx);
  }, [update, goStep]);

  // ---- mutations ----
  const patchSel = (0, _react.useCallback)(patch => {
    update(s => ({
      objects: s.objects.map(o => s.selection.includes(o.id) ? {
        ...o,
        ...patch
      } : o)
    }));
    scheduleSave(stateRef.current.selection);
  }, [update, scheduleSave]);

  // ---- selection: one action for pointer and keyboard (R3-607) ----
  const select = (0, _react.useCallback)((id, additive = false) => {
    update(s => ({
      selection: applySelection(s.selection, id, additive),
      inspectorOpen: true,
      quickMenu: null
    }));
  }, [update]);

  /** Close the quick-create menu (its Escape/blur path, R3-607). */
  const closeQuickMenu = (0, _react.useCallback)(() => update({
    quickMenu: null
  }), [update]);
  const deleteSelection = (0, _react.useCallback)(() => {
    const sel = stateRef.current.selection.slice();
    if (!sel.length) return;
    const removed = stateRef.current.objects.filter(o => sel.includes(o.id));
    update(s => ({
      objects: s.objects.filter(o => !sel.includes(o.id)),
      selection: []
    }));
    // Delete is a rename into objects/.trash/ with a 10s undo (spec §4.2).
    const t = boardRef.current;
    if (t && t.mode !== 'ro') {
      Promise.all(sel.map(id => (0, _boardStore.trashObject)(t, id))).catch(e => toast(`Delete failed${codeOf(e)}`, 'alert', {
        iconColor: '#caa24a'
      }));
    }
    toast(`${sel.length > 1 ? `${sel.length} objects` : 'Object'} moved to .trash`, 'trash', {
      actionLabel: 'Undo',
      onAction: () => {
        update(s => ({
          objects: s.objects.concat(removed)
        }));
        if (t && t.mode !== 'ro') {
          Promise.all(removed.map(o => (0, _boardStore.restoreObject)(t, o.id))).catch(() => undefined);
        }
      }
    });
  }, [update, toast]);
  const createObject = (0, _react.useCallback)((kind, wx, wy) => {
    const o = {
      id: (0, _ids.generateId)(kind === 'note' ? 'note' : kind),
      kind,
      x: wx - 100,
      y: wy - 74,
      w: 200,
      h: 148,
      rot: 0,
      scale: 1,
      z: 3,
      connections: []
    };
    if (kind === 'note') {
      o.color = 'lemon';
      o.title = 'New note';
    } else if (kind === 'prose') {
      o.title = 'Prose';
      o.body = 'Write here…';
      o.w = 260;
      o.h = 160;
    } else if (kind === 'label') {
      o.title = 'Label';
      o.w = 320;
      o.h = 80;
      o.z = 1;
    } else if (kind === 'shape') {
      o.shape = 'rect';
      o.title = '';
      o.w = 200;
      o.h = 140;
    } else if (kind === 'frame') {
      o.title = 'Frame';
      o.w = 360;
      o.h = 300;
      o.z = 1;
    } else if (kind === 'img') {
      o.loaded = false;
      o.title = 'Image';
    } else if (kind === 'component') {
      o.title = '<Component/>';
    }
    update(s => ({
      objects: s.objects.concat(o),
      selection: [o.id],
      quickMenu: null,
      inspectorOpen: true,
      mode: 'edit'
    }));
    commitSave([o], `Created objects/${o.id}.mdx`, 'plus');
  }, [update, commitSave]);

  // ── pick-file flows (spec §6.1 Open/New board, §4.2 Insert image) ──────────
  // Each invokes the platform picker over a `capDir` of the board's space (the
  // only authority we hold), then maps the returned `(root, relPath)` PATH back
  // onto our OWN mount — re-validating it first (defense in depth, §1.3).

  /** Insert an image: pick a file, copy it into the board's `assets/`, drop an
   *  <Img> object at the world point. Self-contained per §4.2. The pick is
   *  named-busy on the confirming control until it settles (R-IX-2). */
  const insertImage = (0, _react.useCallback)(async (wx, wy) => {
    const target = boardRef.current;
    if (!target) {
      toast('Sign in to insert images into your board.', 'save', {
        iconColor: 'var(--ink-2)'
      });
      return;
    }
    update({
      busy: 'insert-image'
    });
    try {
      const res = await (0, _pickFile.pickFile)({
        mode: 'open-file',
        roots: [await (0, _pickFile.boardSpaceRoot)(target)],
        rootLabels: ['This board’s space'],
        rootModes: [target.mode],
        title: 'Insert image',
        filters: [{
          label: 'Images',
          extensions: ['.png', '.jpg', '.jpeg', '.gif', '.webp', '.svg', '.avif']
        }, {
          label: 'All files',
          extensions: []
        }]
      });
      if (!res) return; // cancelled — no toast spam
      const rel = (0, _pickFile.safeRel)(res.relPath);
      if (!rel) {
        toast('That file can’t be inserted.', 'alert', {
          iconColor: '#caa24a'
        });
        return;
      }
      const name = await (0, _boardStore.copyIntoAssets)(target, rel);
      const o = {
        id: (0, _ids.generateId)('img'),
        kind: 'img',
        x: wx - 130,
        y: wy - 90,
        w: 260,
        h: 180,
        rot: 0,
        scale: 1,
        z: 3,
        title: name,
        body: `<Img src="assets/${name}" />`,
        loaded: true,
        connections: []
      };
      update(s => ({
        objects: s.objects.concat(o),
        selection: [o.id],
        quickMenu: null,
        inspectorOpen: true,
        mode: 'edit',
        screen: null
      }));
      commitSave([o], `Inserted assets/${name}`, 'image');
    } catch (e) {
      toast(`Couldn’t insert image${codeOf(e)}`, 'alert', {
        iconColor: '#caa24a'
      });
    } finally {
      update({
        busy: null
      });
    }
  }, [toast, update, commitSave]);

  /** Re-point the active board to `target` and hydrate the canvas from it. */
  const loadBoardInto = (0, _react.useCallback)(async target => {
    const board = await (0, _boardStore.loadBoard)(target);
    boardRef.current = target;
    // The board.md manifest names the board (spec §2.4) — a board is a folder
    // that can state its own name; fall back to the seed only when absent.
    // A manifest schema newer than this reader marks the board readonly (the
    // `readonly` degraded state), unless the mount itself is already ro.
    const readonly = target.mode === 'ro' || typeof board.schema === 'number' && board.schema > SUPPORTED_SCHEMA;
    update({
      objects: board.objects,
      views: board.views.length ? board.views : _seedBoard.SEED_VIEWS.slice(),
      journeys: board.journeys.length ? board.journeys : _seedBoard.SEED_JOURNEYS,
      bg: board.background ?? stateRef.current.bg,
      title: board.title ?? stateRef.current.title,
      mode: readonly ? 'run' : stateRef.current.mode,
      selection: [],
      // A keyboard connect armed against the previous board must not survive
      // the swap (R3-607 review): its source id is stale the moment objects
      // are replaced.
      connectFrom: null,
      connectCursor: null,
      inspectorOpen: false,
      screen: null
    });
  }, [update]);

  /** Open an existing board folder in `space`: pick a folder, require a board.md,
   *  then load it as the active board. Named-busy while the pick is out. */
  const openBoardIn = (0, _react.useCallback)(async space => {
    update({
      busy: 'open-board'
    });
    try {
      const res = await (0, _pickFile.pickFile)({
        mode: 'open-folder',
        roots: [await (0, _pickFile.boardSpaceRoot)(space)],
        rootLabels: ['Your board space'],
        rootModes: [space.mode],
        title: 'Open board'
      });
      if (!res) return;
      const rel = (0, _pickFile.safeRel)(res.relPath);
      if (!rel) {
        toast('That folder can’t be opened.', 'alert', {
          iconColor: '#caa24a'
        });
        return;
      }
      const candidate = {
        root: subPath(space.root, rel),
        mode: space.mode,
        spaceId: space.spaceId
      };
      if (!(await (0, _boardStore.folderIsBoard)(candidate)) && !(await (0, _boardStore.boardExists)(candidate))) {
        toast('That folder isn’t a board (no board.md). Open folder again to pick another.', 'alert', {
          iconColor: '#caa24a'
        });
        return;
      }
      await loadBoardInto(candidate);
      toast('Board opened.', 'check');
    } catch (e) {
      toast(`Couldn’t open board${codeOf(e)}`, 'alert', {
        iconColor: '#caa24a'
      });
    } finally {
      update({
        busy: null
      });
    }
  }, [toast, update, loadBoardInto]);

  /** Open a SPECIFIC board directory directly (the chooser's rows, R3-607):
   *  no picker — the caller already knows the folder (it listed it). Loads
   *  through the same `loadBoardInto` every open path funnels into. */
  const openBoardAt = (0, _react.useCallback)(async target => {
    update({
      busy: 'open-board'
    });
    try {
      await loadBoardInto(target);
      toast('Board opened.', 'check');
    } catch (e) {
      toast(`Couldn’t open board${codeOf(e)}`, 'alert', {
        iconColor: '#caa24a'
      });
    } finally {
      update({
        busy: null
      });
    }
  }, [toast, update, loadBoardInto]);

  /** New board: pick (or create) a folder in `space`, scaffold board.md, open it.
   *  Named-busy while the pick is out. */
  const newBoardIn = (0, _react.useCallback)(async space => {
    if (space.mode === 'ro') {
      toast('That space is read-only — you can’t create a board there.', 'lock', {
        iconColor: 'var(--ink-2)'
      });
      return;
    }
    update({
      busy: 'new-board'
    });
    try {
      const res = await (0, _pickFile.pickFile)({
        mode: 'open-folder',
        roots: [await (0, _pickFile.boardSpaceRoot)(space)],
        rootLabels: ['Your board space'],
        rootModes: [space.mode],
        title: 'New board · choose a folder',
        allowCreateFolder: true
      });
      if (!res) return;
      const rel = (0, _pickFile.safeRel)(res.relPath);
      if (!rel) {
        toast('That folder can’t be used.', 'alert', {
          iconColor: '#caa24a'
        });
        return;
      }
      const candidate = {
        root: subPath(space.root, rel),
        mode: 'rw',
        spaceId: space.spaceId
      };
      const title = rel.split('/').pop() || 'Untitled board';
      await (0, _boardStore.writeNewBoard)(candidate, title);
      await loadBoardInto(candidate);
      toast('Board created.', 'check');
    } catch (e) {
      toast(`Couldn’t create board${codeOf(e)}`, 'alert', {
        iconColor: '#caa24a'
      });
    } finally {
      update({
        busy: null
      });
    }
  }, [toast, update, loadBoardInto]);

  /** Open / new board against the CURRENT board space (the chooser's footer). */
  const openBoard = (0, _react.useCallback)(() => {
    const space = boardRef.current;
    if (!space) {
      toast('Sign in to open a board from your space.', 'save', {
        iconColor: 'var(--ink-2)'
      });
      return;
    }
    void openBoardIn(space);
  }, [toast, openBoardIn]);
  const newBoard = (0, _react.useCallback)(() => {
    const space = boardRef.current;
    if (!space) {
      toast('Sign in to create a board in your space.', 'save', {
        iconColor: 'var(--ink-2)'
      });
      return;
    }
    void newBoardIn(space);
  }, [toast, newBoardIn]);

  /** "Add a space": the host powerbox grants a NEW space (never this app, §2),
   *  then we offer to open a board in it. */
  const addSpace = (0, _react.useCallback)(async () => {
    try {
      const granted = await (0, _pickFile.requestSpace)();
      if (!granted) return; // cancelled
      const space = {
        root: granted.path,
        mode: granted.mode,
        spaceId: granted.id
      };
      await openBoardIn(space);
    } catch (e) {
      toast(`Couldn’t add a space${codeOf(e)}`, 'alert', {
        iconColor: '#caa24a'
      });
    }
  }, [toast, openBoardIn]);
  const patchObject = (0, _react.useCallback)((id, patch) => {
    update(s => ({
      objects: s.objects.map(o => o.id === id ? {
        ...o,
        ...patch
      } : o)
    }));
    scheduleSave([id]);
  }, [update, scheduleSave]);
  const addConnection = (0, _react.useCallback)((from, to) => {
    const c = {
      to,
      kind: 'arrow',
      style: {
        stroke: 'accent',
        dash: false
      }
    };
    const src = stateRef.current.objects.find(o => o.id === from);
    const updated = src ? {
      ...src,
      connections: src.connections.concat(c)
    } : null;
    update(s => ({
      objects: s.objects.map(o => o.id === from ? {
        ...o,
        connections: o.connections.concat(c)
      } : o)
    }));
    if (updated) commitSave([updated], `Connected ${from} → ${to}`);
  }, [update, commitSave]);

  // ---- keyboard connect (the non-drag path to an edge, R3-607 / 2.5.7) ----
  /** Enter connect-from on the selected object; the cursor starts on the first
   *  other object in stacking order. Arrows then walk the cursor (the overlay
   *  draws it), Enter commits through the same addConnection the drag calls,
   *  Escape cancels. */
  const beginConnect = (0, _react.useCallback)(() => {
    const s = stateRef.current;
    if (s.selection.length !== 1) return;
    const from = s.selection[0];
    const order = s.objects.slice().sort((a, b) => (a.z || 0) - (b.z || 0)).map(o => o.id).filter(id => id !== from);
    update({
      connectFrom: from,
      connectCursor: order[0] ?? null,
      inspectorOpen: false
    });
  }, [update]);
  const endConnect = (0, _react.useCallback)(commit => {
    const s = stateRef.current;
    if (!s.connectFrom) return;
    if (commit && s.connectCursor) addConnection(s.connectFrom, s.connectCursor);
    update({
      connectFrom: null,
      connectCursor: null
    });
  }, [update, addConnection]);
  const moveConnectCursor = (0, _react.useCallback)(dir => {
    update(s => {
      if (!s.connectFrom) return {};
      const order = s.objects.slice().sort((a, b) => (a.z || 0) - (b.z || 0)).map(o => o.id).filter(id => id !== s.connectFrom);
      if (!order.length) return {};
      const idx = order.indexOf(s.connectCursor ?? order[0]);
      return {
        connectCursor: order[(idx + dir + order.length) % order.length]
      };
    });
  }, [update]);

  // ---- pointer gestures ----
  const onCanvasDown = (0, _react.useCallback)(e => {
    const s = stateRef.current;
    if (s.quickMenu) update({
      quickMenu: null
    });
    if (s.demoMenuOpen) update({
      demoMenuOpen: false
    });
    const mid = e.button === 1;
    if (s.mode === 'edit' && !spaceRef.current && !mid && !isMobile()) {
      const [lx, ly] = localPoint(e);
      if (!e.shiftKey) update({
        selection: []
      });
      dragRef.current = {
        type: 'marquee',
        sx: lx,
        sy: ly,
        add: e.shiftKey,
        base: s.selection.slice()
      };
      update({
        marquee: {
          x: lx,
          y: ly,
          w: 0,
          h: 0
        }
      });
    } else {
      dragRef.current = {
        type: 'pan',
        sx: e.clientX,
        sy: e.clientY,
        cx: s.cam.cx,
        cy: s.cam.cy
      };
      update({
        panning: true
      });
    }
  }, [update, isMobile, localPoint]);
  const objPointerDown = (0, _react.useCallback)((id, e) => {
    e.stopPropagation();
    const s = stateRef.current;
    if (s.mode !== 'edit') {
      dragRef.current = {
        type: 'pan',
        sx: e.clientX,
        sy: e.clientY,
        cx: s.cam.cx,
        cy: s.cam.cy
      };
      update({
        panning: true
      });
      return;
    }
    const o = s.objects.find(x => x.id === id);
    if (!o) return;
    // One spelling of selection for pointer and keyboard alike (R3-607).
    const sel = applySelection(s.selection, id, e.shiftKey);
    update({
      selection: sel,
      inspectorOpen: true,
      quickMenu: null
    });
    if (o.locked) return;
    const orig = {};
    s.objects.forEach(x => {
      if (sel.includes(x.id)) orig[x.id] = {
        x: x.x,
        y: x.y
      };
    });
    dragRef.current = {
      type: 'move',
      sx: e.clientX,
      sy: e.clientY,
      ids: sel,
      orig,
      moved: false
    };
  }, [update]);
  const startHandle = (0, _react.useCallback)((kind, handle, e) => {
    e.stopPropagation();
    const s = stateRef.current;
    const id = s.selection[0];
    const o = s.objects.find(x => x.id === id);
    if (!o) return;
    const base = {
      x: o.x,
      y: o.y,
      w: o.w,
      h: o.h,
      rot: o.rot
    };
    dragRef.current = kind === 'rotate' ? {
      type: 'rotate',
      sx: e.clientX,
      sy: e.clientY,
      o: base,
      id,
      moved: false
    } : {
      type: 'resize',
      kind: handle,
      sx: e.clientX,
      sy: e.clientY,
      o: base,
      id,
      moved: false
    };
  }, []);
  const startConnect = (0, _react.useCallback)((id, side, e) => {
    e.stopPropagation();
    dragRef.current = {
      type: 'connect',
      from: id,
      side,
      moved: false
    };
    const [lx, ly] = localPoint(e);
    update({
      connectPreview: {
        from: id,
        x: lx,
        y: ly,
        target: null
      }
    });
  }, [update, localPoint]);
  const setHover = (0, _react.useCallback)(id => update({
    hover: id
  }), [update]);
  const clearSelection = (0, _react.useCallback)(() => update({
    selection: []
  }), [update]);

  // ---- mode / view controls ----
  const setRun = (0, _react.useCallback)(
  // Leaving edit disarms a keyboard connect too (its cursor lives on the
  // edit surface) — connectFrom surviving into run mode would own the
  // arrows of a mode that has no selection (R3-607 review).
  () => update({
    mode: 'run',
    selection: [],
    inspectorOpen: false,
    quickMenu: null,
    connectPreview: null,
    connectFrom: null,
    connectCursor: null
  }), [update]);
  const setEdit = (0, _react.useCallback)(() => update({
    mode: 'edit'
  }), [update]);
  const toggleTheme = (0, _react.useCallback)(() => update(s => ({
    light: !s.light
  })), [update]);
  const togglePanel = (0, _react.useCallback)(() => update(s => ({
    panelOpen: !s.panelOpen
  })), [update]);
  const setScreen = (0, _react.useCallback)(screen => update({
    screen
  }), [update]);
  const setBackground = (0, _react.useCallback)(bg => update({
    bg
  }), [update]);
  const setLight = (0, _react.useCallback)(light => update({
    light
  }), [update]);
  const closeInspector = (0, _react.useCallback)(() => update({
    inspectorOpen: false
  }), [update]);
  const closePanel = (0, _react.useCallback)(() => update({
    panelOpen: false
  }), [update]);
  const toggleDemoMenu = (0, _react.useCallback)(() => update(s => ({
    demoMenuOpen: !s.demoMenuOpen
  })), [update]);
  const onCanvasDblClick = (0, _react.useCallback)(e => {
    if (stateRef.current.mode !== 'edit') return;
    const [lx, ly] = localPoint(e);
    const [wx, wy] = (0, _camera.worldAt)(stateRef.current.cam, stateRef.current.vp, lx, ly);
    update({
      quickMenu: {
        lx,
        ly,
        wx,
        wy
      }
    });
  }, [update, localPoint]);

  // ---- demo scenarios (the design's "demo states" menu) ----
  const demoLWW = (0, _react.useCallback)(() => {
    toast('Note was changed by @dana while you edited — their version kept.', 'alert', {
      iconColor: '#caa24a',
      actionLabel: 'Keep mine',
      onAction: () => toast('Your version restored', 'check')
    });
  }, [toast]);
  const demoDowngrade = (0, _react.useCallback)(() => {
    update({
      mode: 'run',
      selection: [],
      inspectorOpen: false
    });
    toast('Your access changed to read-only. Edit mode closed.', 'lock', {
      iconColor: 'var(--ink-2)'
    });
  }, [update, toast]);

  // ---- effects: measurement + global listeners ----
  (0, _react.useEffect)(() => {
    document.documentElement.setAttribute('data-theme', state.light ? 'light' : 'dark');
  }, [state.light]);
  (0, _react.useEffect)(() => {
    const el = canvasEl;
    if (!el) return;
    const measure = () => {
      const r = el.getBoundingClientRect();
      update({
        vp: {
          vw: r.width,
          vh: r.height,
          vleft: r.left,
          vtop: r.top
        }
      });
    };
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    const onWheel = e => {
      e.preventDefault();
      const [lx, ly] = localPoint(e);
      if (e.ctrlKey || e.metaKey) {
        const f = Math.exp(-e.deltaY * 0.01);
        setZoom(stateRef.current.cam.zoom * f, lx, ly);
      } else {
        update(s => ({
          cam: {
            cx: s.cam.cx + e.deltaX / s.cam.zoom,
            cy: s.cam.cy + e.deltaY / s.cam.zoom,
            zoom: s.cam.zoom
          }
        }));
      }
    };
    el.addEventListener('wheel', onWheel, {
      passive: false
    });
    const onMove = e => {
      const d = dragRef.current;
      if (!d) return;
      const z = stateRef.current.cam.zoom;
      if (d.type === 'pan') {
        const dx = e.clientX - d.sx;
        const dy = e.clientY - d.sy;
        update({
          cam: {
            cx: d.cx - dx / z,
            cy: d.cy - dy / z,
            zoom: z
          }
        });
      } else if (d.type === 'move') {
        const dx = (e.clientX - d.sx) / z;
        const dy = (e.clientY - d.sy) / z;
        d.moved = true;
        update(s => ({
          objects: s.objects.map(o => d.ids.includes(o.id) && d.orig[o.id] ? {
            ...o,
            x: d.orig[o.id].x + dx,
            y: d.orig[o.id].y + dy
          } : o)
        }));
      } else if (d.type === 'marquee') {
        const [lx, ly] = localPoint(e);
        const x = Math.min(lx, d.sx);
        const y = Math.min(ly, d.sy);
        const w = Math.abs(lx - d.sx);
        const hh = Math.abs(ly - d.sy);
        const s = stateRef.current;
        const sel = (0, _geometry.objectsInRect)(s.objects, s.cam, s.vp, x, y, w, hh);
        update({
          marquee: {
            x,
            y,
            w,
            h: hh
          },
          selection: d.add ? Array.from(new Set(d.base.concat(sel))) : sel
        });
      } else if (d.type === 'connect') {
        const [lx, ly] = localPoint(e);
        const s = stateRef.current;
        const tgt = (0, _geometry.objectAtLocal)(s.objects, s.cam, s.vp, lx, ly, d.from);
        update({
          connectPreview: {
            from: d.from,
            x: lx,
            y: ly,
            target: tgt
          }
        });
      } else if (d.type === 'resize' || d.type === 'rotate') {
        applyHandle(d, e);
      }
    };
    const applyHandle = (d, e) => {
      const s = stateRef.current;
      const z = s.cam.zoom;
      const dx = (e.clientX - d.sx) / z;
      const dy = (e.clientY - d.sy) / z;
      d.moved = true;
      update(st => ({
        objects: st.objects.map(o => {
          if (o.id !== d.id) return o;
          if (d.type === 'rotate') {
            const cx = d.o.x + d.o.w / 2;
            const cy = d.o.y + d.o.h / 2;
            const [lx, ly] = localPoint(e);
            const [wx, wy] = (0, _camera.worldAt)(s.cam, s.vp, lx, ly);
            let ang = Math.atan2(wy - cy, wx - cx) * 180 / Math.PI + 90;
            if (e.shiftKey) ang = Math.round(ang / 15) * 15;
            return {
              ...o,
              rot: Math.round(ang)
            };
          }
          let x = d.o.x;
          let y = d.o.y;
          let w = d.o.w;
          let hh = d.o.h;
          const k = d.kind;
          if (k.includes('e')) w = Math.max(60, d.o.w + dx);
          if (k.includes('s')) hh = Math.max(48, d.o.h + dy);
          if (k.includes('w')) {
            w = Math.max(60, d.o.w - dx);
            x = d.o.x + (d.o.w - w);
          }
          if (k.includes('n')) {
            hh = Math.max(48, d.o.h - dy);
            y = d.o.y + (d.o.h - hh);
          }
          return {
            ...o,
            x,
            y,
            w,
            h: hh
          };
        })
      }));
    };
    const onUp = e => {
      const d = dragRef.current;
      dragRef.current = null;
      if (!d) {
        if (stateRef.current.panning) update({
          panning: false
        });
        return;
      }
      if (d.type === 'pan') {
        update({
          panning: false
        });
      } else if (d.type === 'move' && d.moved) {
        const moved = stateRef.current.objects.filter(o => d.ids.includes(o.id));
        commitSave(moved, `Moved · saved to ${d.ids.length > 1 ? `${d.ids.length} files` : `${d.ids[0]}.mdx`}`);
      } else if (d.type === 'marquee') {
        update({
          marquee: null
        });
      } else if (d.type === 'connect') {
        const [lx, ly] = localPoint(e);
        const s = stateRef.current;
        const tgt = (0, _geometry.objectAtLocal)(s.objects, s.cam, s.vp, lx, ly, d.from);
        if (tgt) addConnection(d.from, tgt);
        update({
          connectPreview: null
        });
      } else if ((d.type === 'resize' || d.type === 'rotate') && d.moved) {
        const o = stateRef.current.objects.find(x => x.id === d.id);
        commitSave(o ? [o] : [], 'Resized · saved');
      }
    };
    const onKeyDown = e => {
      const t = e.target;
      if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable)) return;
      const s = stateRef.current;
      if (s.journey) {
        if (e.key === 'ArrowRight' || e.key === ' ') {
          e.preventDefault();
          playNext();
        } else if (e.key === 'ArrowLeft') {
          playPrev();
        } else if (e.key === 'Escape') {
          playExit();
        }
        return;
      }
      // Keyboard connect owns the arrows while it is armed (R3-607): arrows
      // walk the target cursor, Enter commits, Escape cancels — never nudging
      // or deleting underneath a live connect.
      if (s.connectFrom) {
        if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
          e.preventDefault();
          moveConnectCursor(-1);
        } else if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
          e.preventDefault();
          moveConnectCursor(1);
        } else if (e.key === 'Enter') {
          e.preventDefault();
          endConnect(true);
        } else if (e.key === 'Escape') {
          e.preventDefault();
          endConnect(false);
        }
        return;
      }
      if (e.key === 'Escape') update({
        selection: [],
        quickMenu: null,
        screen: null
      });
      if (e.key === ' ') spaceRef.current = true;
      if (s.mode === 'edit' && s.selection.length) {
        const step = e.shiftKey ? 10 : 1;
        let dx = 0;
        let dy = 0;
        if (e.key === 'ArrowLeft') dx = -step;else if (e.key === 'ArrowRight') dx = step;else if (e.key === 'ArrowUp') dy = -step;else if (e.key === 'ArrowDown') dy = step;
        if (dx || dy) {
          e.preventDefault();
          const sel = s.selection;
          update(st => ({
            objects: st.objects.map(o => sel.includes(o.id) && !o.locked ? {
              ...o,
              x: o.x + dx,
              y: o.y + dy
            } : o)
          }));
          scheduleSave(sel);
        }
        if (e.key === 'Delete' || e.key === 'Backspace') deleteSelection();
      }
    };
    const onKeyUp = e => {
      if (e.key === ' ') spaceRef.current = false;
    };
    document.addEventListener('pointermove', onMove);
    document.addEventListener('pointerup', onUp);
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    return () => {
      el.removeEventListener('wheel', onWheel);
      ro.disconnect();
      document.removeEventListener('pointermove', onMove);
      document.removeEventListener('pointerup', onUp);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      if (tweenRef.current) cancelAnimationFrame(tweenRef.current);
    };
    // The listeners read the latest state via stateRef, so they install once
    // the canvas mounts; the action callbacks they close over are all stable.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [canvasEl]);

  /**
   * Provider side of `open-project` (SPACES_UI_SPEC §6): given the delegated
   * `capDir`, find the chroot the host mounted for it, hydrate the canvas from
   * it, and arm the durable-board machinery (autosave, downgrade watch) against
   * it. Resolves true once the board is shown, false if the delegated folder
   * never resolved to a mount (the caller then aborts the task). The folder is
   * expected to already be a board (the marker only lives on board folders); an
   * empty one is seeded so the canvas still renders.
   */
  const openDelegatedProject = (0, _react.useCallback)(async dirPath => {
    // The host announces the task chroot as a mount AT the delegated path; it
    // may not be present the instant we read the input, so poll briefly (a few
    // frames) for the mount whose `path` matches.
    let mount = (0, _openProject.resolveDelegatedMount)(dirPath, (0, _mounts.getMounts)());
    for (let tries = 0; !mount && tries < 40; tries += 1) {
      await new Promise(r => setTimeout(r, 50));
      mount = (0, _openProject.resolveDelegatedMount)(dirPath, (0, _mounts.getMounts)());
    }
    if (!mount) {
      toast('Couldn’t open that project — the folder isn’t available.', 'alert', {
        iconColor: '#caa24a'
      });
      return false;
    }
    const target = (0, _openProject.dirCapToBoardTarget)(mount);
    try {
      if (await (0, _boardStore.boardExists)(target)) {
        await loadBoardInto(target);
      } else {
        // The marker said this is a project folder but it has no objects yet:
        // seed it so the user lands on a usable board, not a blank canvas.
        boardRef.current = target;
        const s = stateRef.current;
        await (0, _boardStore.seedBoard)(target, {
          objects: s.objects,
          views: s.views,
          journeys: s.journeys
        });
      }
      toast('Project opened.', 'check');
      return true;
    } catch (e) {
      toast(`Couldn’t open project${codeOf(e)}`, 'alert', {
        iconColor: '#caa24a'
      });
      return false;
    }
  }, [toast, loadBoardInto]);

  // ---- open the durable board space, hydrate (or seed), watch for downgrades ----
  (0, _react.useEffect)(() => {
    let cancelled = false;
    let unsub;
    const timers = saveTimers.current;
    (async () => {
      // ── open-project provider path (SPACES_UI_SPEC §6, Phase 5) ───────────
      // If a file manager launched us via the `open-project` task, it handed a
      // `capDir` for the project folder; the host mounted that folder as a
      // chroot. Load the board from it and complete the task, then arm the same
      // downgrade watch below against the delegated mount. A normal launch (no
      // task input) falls through to the durable-board path unchanged.
      let delegated = false;
      const dir = await (0, _openProject.readOpenProjectInput)();
      if (dir) {
        const opened = await openDelegatedProject(dir);
        if (opened) await (0, _openProject.reportOpened)(true);else await (0, _openProject.abortOpenProject)();
        if (cancelled) return;
        // On success the canvas is chrooted at the project; skip the durable
        // board space. On failure, fall through to the in-memory seed so the
        // canvas still renders something rather than a blank app.
        delegated = opened;
      }
      if (!delegated) {
        let target;
        try {
          // Auto-open the signed-in user's board space. Declined / signed-out
          // rejects with a typed SpaceError — we degrade to the in-memory seed.
          target = await (0, _boardStore.openBoardTarget)();
        } catch {
          if (!cancelled) toast('Working in memory — sign in to save your board.', 'save', {
            iconColor: 'var(--ink-2)'
          });
          return;
        }
        if (cancelled) return;
        boardRef.current = target;
        try {
          if (await (0, _boardStore.boardExists)(target)) {
            const board = await (0, _boardStore.loadBoard)(target);
            if (!cancelled) {
              update({
                objects: board.objects,
                views: board.views.length ? board.views : _seedBoard.SEED_VIEWS.slice(),
                journeys: board.journeys.length ? board.journeys : _seedBoard.SEED_JOURNEYS
              });
              toast('Board loaded from your space.', 'check');
            }
          } else {
            // First run on an empty space: persist the seed demo as the starting board.
            const s = stateRef.current;
            await (0, _boardStore.seedBoard)(target, {
              objects: s.objects,
              views: s.views,
              journeys: s.journeys
            });
            if (!cancelled) toast('Board created in your space.', 'check');
          }
        } catch (e) {
          if (!cancelled) toast(`Couldn't open board${codeOf(e)}`, 'alert', {
            iconColor: '#caa24a'
          });
        }
      }
      if (cancelled) return;
      // Mirror the live mounts into state (the board chooser lists these,
      // R3-607) alongside the downgrade watch below.
      try {
        update({
          mounts: (0, _mounts.getMounts)()
        });
      } catch {
        // No host runtime yet — the list stays empty and the chooser degrades.
      }
      // A live role-downgrade re-announces the mount as `ro`; removal tears it down.
      // The mount service needs the host runtime, which is absent under local
      // `vite dev` — there the board is a static on-disk dir with no role changes,
      // so skip the subscription rather than crash.
      try {
        unsub = (0, _mounts.onMountsChange)((mounts, removed) => {
          update({
            mounts
          });
          const cur = boardRef.current;
          if (!cur) return;
          const m = mounts.find(x => cur.spaceId ? x.id === cur.spaceId : x.path === cur.root);
          if (m) {
            const mode = m.mode === 'ro' ? 'ro' : 'rw';
            if (mode !== cur.mode) {
              boardRef.current = {
                ...cur,
                mode
              };
              if (mode === 'ro') {
                update({
                  mode: 'run',
                  selection: [],
                  inspectorOpen: false
                });
                toast('Your access changed to read-only.', 'lock', {
                  iconColor: 'var(--ink-2)'
                });
              }
            }
          } else if (removed.some(r => cur.spaceId ? r.id === cur.spaceId : r.path === cur.root)) {
            boardRef.current = null;
            toast('Board space disconnected.', 'alert', {
              iconColor: 'var(--ink-2)'
            });
          }
        });
      } catch {
        // No host runtime (local `vite dev`): no live mount updates to track.
      }
    })();
    return () => {
      cancelled = true;
      unsub?.();
      for (const h of timers.values()) clearTimeout(h);
      timers.clear();
      if (holdTimer.current) clearTimeout(holdTimer.current);
      holdTimer.current = null;
    };
    // Runs once on mount; reads live state via stateRef and stable callbacks.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return {
    state,
    registerCanvas,
    boardRoot: boardRef.current?.root ?? null,
    isMobile,
    // camera
    originX: vw => (0, _camera.originX)(state.cam, vw),
    originY: vh => (0, _camera.originY)(state.cam, vh),
    project: (wx, wy) => (0, _camera.project)(state.cam, state.vp, wx, wy),
    setZoom,
    clampZoom: _camera.clampZoom,
    flyTo,
    anchorPoint: _geometry.anchorPoint,
    // gestures
    onCanvasDown,
    onCanvasDblClick,
    objPointerDown,
    startHandle,
    startConnect,
    setHover,
    clearSelection,
    select,
    closeQuickMenu,
    // keyboard connect (the non-drag path)
    beginConnect,
    endConnect,
    moveConnectCursor,
    // mutations
    patchSel,
    patchObject,
    deleteSelection,
    createObject,
    // pick-file flows
    insertImage,
    openBoard,
    openBoardAt,
    newBoard,
    newBoardIn,
    openBoardIn,
    addSpace,
    // views & journeys
    saveView,
    deleteView,
    addJourneyStep,
    resolveView,
    playJourney,
    playNext,
    playPrev,
    playExit,
    playSeek,
    // mode / chrome
    setRun,
    setEdit,
    toggleTheme,
    togglePanel,
    closeInspector,
    closePanel,
    setBackground,
    setLight,
    setScreen,
    toggleDemoMenu,
    // toasts + demo
    toast,
    dismissToast,
    demoLWW,
    demoDowngrade
  };
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX2NhbWVyYSIsIl9nZW9tZXRyeSIsIl9pZHMiLCJfc2VlZEJvYXJkIiwiX2JvYXJkU3RvcmUiLCJfcGlja0ZpbGUiLCJfbW91bnRzIiwiX29wZW5Qcm9qZWN0Iiwic3ViUGF0aCIsInJvb3QiLCJyZWwiLCJyZXBsYWNlIiwiY29kZU9mIiwiZSIsImMiLCJjb2RlIiwiaW5pdGlhbFZpZXdwb3J0IiwidnciLCJ3aW5kb3ciLCJpbm5lcldpZHRoIiwidmgiLCJpbm5lckhlaWdodCIsInZsZWZ0IiwidnRvcCIsImFwcGx5U2VsZWN0aW9uIiwic2VsIiwiaWQiLCJhZGRpdGl2ZSIsImluY2x1ZGVzIiwiZmlsdGVyIiwieCIsImNvbmNhdCIsIk1PQklMRV9CUkVBS1BPSU5UIiwiU1VQUE9SVEVEX1NDSEVNQSIsIkpPVVJORVlfRklUX0lOU0VUIiwicHJlZmVyc1JlZHVjZWRNb3Rpb24iLCJtYXRjaE1lZGlhIiwibWF0Y2hlcyIsIkJVU1lfTEFCRUxTIiwiZXhwb3J0cyIsInVzZUxvZGVzdGFyIiwiY2FudmFzRWwiLCJzZXRDYW52YXNFbCIsInVzZVN0YXRlIiwicmVnaXN0ZXJDYW52YXMiLCJ1c2VDYWxsYmFjayIsImVsIiwiZHJhZ1JlZiIsInVzZVJlZiIsInR3ZWVuUmVmIiwiaG9sZFRpbWVyIiwic3BhY2VSZWYiLCJ0b2FzdFNlcSIsInBsYXlOZXh0UmVmIiwic3RhdGUiLCJzZXRTdGF0ZSIsIm1vZGUiLCJsaWdodCIsImJnIiwiQk9BUkQiLCJiYWNrZ3JvdW5kIiwidGl0bGUiLCJjYW0iLCJjeCIsImN5Iiwiem9vbSIsInZwIiwib2JqZWN0cyIsInNlZWRPYmplY3RzIiwidmlld3MiLCJTRUVEX1ZJRVdTIiwic2xpY2UiLCJqb3VybmV5cyIsIlNFRURfSk9VUk5FWVMiLCJzZWxlY3Rpb24iLCJob3ZlciIsIm1hcnF1ZWUiLCJjb25uZWN0UHJldmlldyIsImNvbm5lY3RGcm9tIiwiY29ubmVjdEN1cnNvciIsImluc3BlY3Rvck9wZW4iLCJwYW5lbE9wZW4iLCJxdWlja01lbnUiLCJqb3VybmV5IiwidG9hc3RzIiwic2NyZWVuIiwiZGVtb01lbnVPcGVuIiwicGFubmluZyIsInJlZHVjZWQiLCJidXN5IiwibW91bnRzIiwic3RhdGVSZWYiLCJ1c2VFZmZlY3QiLCJjdXJyZW50IiwidXBkYXRlIiwicGF0Y2giLCJwcmV2IiwiaXNNb2JpbGUiLCJsb2NhbFBvaW50IiwiY2xpZW50WCIsImNsaWVudFkiLCJzZXRab29tIiwibnoiLCJseCIsImx5IiwicyIsInpvb21Bcm91bmQiLCJkaXNtaXNzVG9hc3QiLCJ0IiwidG9hc3QiLCJ0ZXh0IiwiaWNvbiIsIm9wdHMiLCJ0dGwiLCJhY3Rpb25MYWJlbCIsInNldFRpbWVvdXQiLCJib2FyZFJlZiIsInNhdmVUaW1lcnMiLCJNYXAiLCJjb21taXRTYXZlIiwib2JqcyIsInNhdmVkVGV4dCIsInNhdmVkSWNvbiIsImljb25Db2xvciIsIlByb21pc2UiLCJhbGwiLCJtYXAiLCJvIiwic2F2ZU9iamVjdCIsInRoZW4iLCJzY2hlZHVsZVNhdmUiLCJpZHMiLCJnZXQiLCJjbGVhclRpbWVvdXQiLCJoYW5kbGUiLCJkZWxldGUiLCJmaW5kIiwiY2F0Y2giLCJ1bmRlZmluZWQiLCJzZXQiLCJmbHlUbyIsInRhcmdldCIsImR1ciIsImZpdEgiLCJkZXN0IiwiY2FtZXJhRm9yVGFyZ2V0IiwiY2FuY2VsQW5pbWF0aW9uRnJhbWUiLCJmcm9tIiwidDAiLCJwZXJmb3JtYW5jZSIsIm5vdyIsImVhc2UiLCJwIiwiTWF0aCIsInBvdyIsInN0ZXAiLCJtaW4iLCJyZXF1ZXN0QW5pbWF0aW9uRnJhbWUiLCJyZXNvbHZlVmlldyIsInYiLCJuYW1lIiwidyIsImgiLCJzYXZlVmlldyIsInZpZXciLCJsZW5ndGgiLCJzdCIsInBlcnNpc3RWaWV3IiwiZGVsZXRlVmlldyIsInJlbW92ZVZpZXciLCJzb21lIiwiYWRkSm91cm5leVN0ZXAiLCJqaWQiLCJqIiwibmV4dCIsInN0ZXBzIiwicGVyc2lzdEpvdXJuZXkiLCJnb1N0ZXAiLCJpZHgiLCJpbnN0YW50IiwiZHVyYXRpb24iLCJob2xkIiwicGxheUpvdXJuZXkiLCJwbGF5RXhpdCIsInBsYXlOZXh0IiwianIiLCJuaSIsInBsYXlQcmV2IiwibWF4IiwicGxheVNlZWsiLCJwYXRjaFNlbCIsInNlbGVjdCIsImNsb3NlUXVpY2tNZW51IiwiZGVsZXRlU2VsZWN0aW9uIiwicmVtb3ZlZCIsInRyYXNoT2JqZWN0Iiwib25BY3Rpb24iLCJyZXN0b3JlT2JqZWN0IiwiY3JlYXRlT2JqZWN0Iiwia2luZCIsInd4Iiwid3kiLCJnZW5lcmF0ZUlkIiwieSIsInJvdCIsInNjYWxlIiwieiIsImNvbm5lY3Rpb25zIiwiY29sb3IiLCJib2R5Iiwic2hhcGUiLCJsb2FkZWQiLCJpbnNlcnRJbWFnZSIsInJlcyIsInBpY2tGaWxlIiwicm9vdHMiLCJib2FyZFNwYWNlUm9vdCIsInJvb3RMYWJlbHMiLCJyb290TW9kZXMiLCJmaWx0ZXJzIiwibGFiZWwiLCJleHRlbnNpb25zIiwic2FmZVJlbCIsInJlbFBhdGgiLCJjb3B5SW50b0Fzc2V0cyIsImxvYWRCb2FyZEludG8iLCJib2FyZCIsImxvYWRCb2FyZCIsInJlYWRvbmx5Iiwic2NoZW1hIiwib3BlbkJvYXJkSW4iLCJzcGFjZSIsImNhbmRpZGF0ZSIsInNwYWNlSWQiLCJmb2xkZXJJc0JvYXJkIiwiYm9hcmRFeGlzdHMiLCJvcGVuQm9hcmRBdCIsIm5ld0JvYXJkSW4iLCJhbGxvd0NyZWF0ZUZvbGRlciIsInNwbGl0IiwicG9wIiwid3JpdGVOZXdCb2FyZCIsIm9wZW5Cb2FyZCIsIm5ld0JvYXJkIiwiYWRkU3BhY2UiLCJncmFudGVkIiwicmVxdWVzdFNwYWNlIiwicGF0aCIsInBhdGNoT2JqZWN0IiwiYWRkQ29ubmVjdGlvbiIsInRvIiwic3R5bGUiLCJzdHJva2UiLCJkYXNoIiwic3JjIiwidXBkYXRlZCIsImJlZ2luQ29ubmVjdCIsIm9yZGVyIiwic29ydCIsImEiLCJiIiwiZW5kQ29ubmVjdCIsImNvbW1pdCIsIm1vdmVDb25uZWN0Q3Vyc29yIiwiZGlyIiwiaW5kZXhPZiIsIm9uQ2FudmFzRG93biIsIm1pZCIsImJ1dHRvbiIsInNoaWZ0S2V5IiwidHlwZSIsInN4Iiwic3kiLCJhZGQiLCJiYXNlIiwib2JqUG9pbnRlckRvd24iLCJzdG9wUHJvcGFnYXRpb24iLCJsb2NrZWQiLCJvcmlnIiwiZm9yRWFjaCIsIm1vdmVkIiwic3RhcnRIYW5kbGUiLCJzdGFydENvbm5lY3QiLCJzaWRlIiwic2V0SG92ZXIiLCJjbGVhclNlbGVjdGlvbiIsInNldFJ1biIsInNldEVkaXQiLCJ0b2dnbGVUaGVtZSIsInRvZ2dsZVBhbmVsIiwic2V0U2NyZWVuIiwic2V0QmFja2dyb3VuZCIsInNldExpZ2h0IiwiY2xvc2VJbnNwZWN0b3IiLCJjbG9zZVBhbmVsIiwidG9nZ2xlRGVtb01lbnUiLCJvbkNhbnZhc0RibENsaWNrIiwid29ybGRBdCIsImRlbW9MV1ciLCJkZW1vRG93bmdyYWRlIiwiZG9jdW1lbnQiLCJkb2N1bWVudEVsZW1lbnQiLCJzZXRBdHRyaWJ1dGUiLCJtZWFzdXJlIiwiciIsImdldEJvdW5kaW5nQ2xpZW50UmVjdCIsIndpZHRoIiwiaGVpZ2h0IiwibGVmdCIsInRvcCIsInJvIiwiUmVzaXplT2JzZXJ2ZXIiLCJvYnNlcnZlIiwib25XaGVlbCIsInByZXZlbnREZWZhdWx0IiwiY3RybEtleSIsIm1ldGFLZXkiLCJmIiwiZXhwIiwiZGVsdGFZIiwiZGVsdGFYIiwiYWRkRXZlbnRMaXN0ZW5lciIsInBhc3NpdmUiLCJvbk1vdmUiLCJkIiwiZHgiLCJkeSIsImFicyIsImhoIiwib2JqZWN0c0luUmVjdCIsIkFycmF5IiwiU2V0IiwidGd0Iiwib2JqZWN0QXRMb2NhbCIsImFwcGx5SGFuZGxlIiwiYW5nIiwiYXRhbjIiLCJQSSIsInJvdW5kIiwiayIsIm9uVXAiLCJvbktleURvd24iLCJ0YWdOYW1lIiwiaXNDb250ZW50RWRpdGFibGUiLCJrZXkiLCJvbktleVVwIiwicmVtb3ZlRXZlbnRMaXN0ZW5lciIsImRpc2Nvbm5lY3QiLCJvcGVuRGVsZWdhdGVkUHJvamVjdCIsImRpclBhdGgiLCJtb3VudCIsInJlc29sdmVEZWxlZ2F0ZWRNb3VudCIsImdldE1vdW50cyIsInRyaWVzIiwiZGlyQ2FwVG9Cb2FyZFRhcmdldCIsInNlZWRCb2FyZCIsImNhbmNlbGxlZCIsInVuc3ViIiwidGltZXJzIiwiZGVsZWdhdGVkIiwicmVhZE9wZW5Qcm9qZWN0SW5wdXQiLCJvcGVuZWQiLCJyZXBvcnRPcGVuZWQiLCJhYm9ydE9wZW5Qcm9qZWN0Iiwib3BlbkJvYXJkVGFyZ2V0Iiwib25Nb3VudHNDaGFuZ2UiLCJjdXIiLCJtIiwidmFsdWVzIiwiY2xlYXIiLCJib2FyZFJvb3QiLCJvcmlnaW5YIiwib3JpZ2luWSIsInByb2plY3QiLCJjbGFtcFpvb20iLCJhbmNob3JQb2ludCJdLCJzb3VyY2VzIjpbInVzZUxvZGVzdGFyLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIExvZGVzdGFyJ3Mgc2luZ2xlIHNvdXJjZSBvZiB0cnV0aDogY2FtZXJhLCBvYmplY3RzLCBzZWxlY3Rpb24sIGFuZCBhbGxcbi8vIHBvaW50ZXIva2V5Ym9hcmQgZ2VzdHVyZSBsb2dpYy4gUG9ydGVkIGZyb20gdGhlIGRlc2lnbiBjb21wJ3MgY29udHJvbGxlciBpbnRvXG4vLyBvbmUgaG9vayBzbyB0aGUgcHJlc2VudGF0aW9uYWwgY29tcG9uZW50cyBzdGF5IHRoaW4uIEdlb21ldHJ5IGdlc3R1cmVzIHdyaXRlXG4vLyBcIm9uY2UsIG9uIGdlc3R1cmUgZW5kXCIgKHNwZWMgwqc1LjEpOyBoZXJlIHRoZSB3cml0ZSBpcyBhbiBpbi1tZW1vcnkgbXV0YXRpb24gK1xuLy8gYSBzYXZlZC10b2FzdCwgdGhlIHNlYW0gd2hlcmUgdGhlIHBlcnNpc3RlbmNlIGxheWVyICjCpzIuNiByb3VuZC10cmlwIGRpc2NpcGxpbmUpXG4vLyB3aWxsIGF0dGFjaCBvbmNlIHRoZSBjaGFuZ2UgbGF5ZXIgbGFuZHMuXG5cbmltcG9ydCB7IHVzZUNhbGxiYWNrLCB1c2VFZmZlY3QsIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQge1xuICBjYW1lcmFGb3JUYXJnZXQsXG4gIGNsYW1wWm9vbSxcbiAgb3JpZ2luWCxcbiAgb3JpZ2luWSxcbiAgcHJvamVjdCxcbiAgd29ybGRBdCxcbiAgem9vbUFyb3VuZCxcbn0gZnJvbSAnLi4vbGliL2NhbWVyYSc7XG5pbXBvcnQgdHlwZSB7IFZpZXdwb3J0IH0gZnJvbSAnLi4vbGliL2NhbWVyYSc7XG5pbXBvcnQgeyBhbmNob3JQb2ludCwgb2JqZWN0QXRMb2NhbCwgb2JqZWN0c0luUmVjdCB9IGZyb20gJy4uL2xpYi9nZW9tZXRyeSc7XG5pbXBvcnQgeyBnZW5lcmF0ZUlkIH0gZnJvbSAnLi4vbGliL2lkcyc7XG5pbXBvcnQgdHlwZSB7XG4gIEJhY2tncm91bmQsXG4gIENhbWVyYSxcbiAgQ29ubmVjdGlvbixcbiAgSm91cm5leSxcbiAgTW9kZSxcbiAgT2JqZWN0S2luZCxcbiAgU2NyZWVuS2luZCxcbiAgVG9hc3QsXG4gIFZpZXcsXG4gIFZpZXdUYXJnZXQsXG4gIFdPYmplY3QsXG59IGZyb20gJy4uL2xpYi90eXBlcyc7XG5pbXBvcnQgeyBCT0FSRCwgU0VFRF9KT1VSTkVZUywgU0VFRF9WSUVXUywgc2VlZE9iamVjdHMgfSBmcm9tICcuLi9kYXRhL3NlZWRCb2FyZCc7XG5pbXBvcnQge1xuICBib2FyZEV4aXN0cyxcbiAgY29weUludG9Bc3NldHMsXG4gIGZvbGRlcklzQm9hcmQsXG4gIGxvYWRCb2FyZCxcbiAgb3BlbkJvYXJkVGFyZ2V0LFxuICByZW1vdmVWaWV3LFxuICByZXN0b3JlT2JqZWN0LFxuICBzYXZlSm91cm5leSBhcyBwZXJzaXN0Sm91cm5leSxcbiAgc2F2ZU9iamVjdCxcbiAgc2F2ZVZpZXcgYXMgcGVyc2lzdFZpZXcsXG4gIHNlZWRCb2FyZCxcbiAgdHJhc2hPYmplY3QsXG4gIHdyaXRlTmV3Qm9hcmQsXG59IGZyb20gJy4uL2xpYi9ib2FyZFN0b3JlJztcbmltcG9ydCB0eXBlIHsgQm9hcmRUYXJnZXQgfSBmcm9tICcuLi9saWIvYm9hcmRTdG9yZSc7XG5pbXBvcnQgeyBib2FyZFNwYWNlUm9vdCwgcGlja0ZpbGUsIHJlcXVlc3RTcGFjZSwgc2FmZVJlbCB9IGZyb20gJy4uL2xpYi9waWNrRmlsZSc7XG4vLyBTdWJwYXRoIGltcG9ydCwgbm90IHRoZSBwYWNrYWdlIGJhcnJlbDogdGhlIGJhcnJlbCByZS1leHBvcnRzIGAuL3Rhc2tzYCxcbi8vIHdob3NlIHRvcC1sZXZlbCBgYWRkTGlzdGVuZXJgIHNpZGUgZWZmZWN0IHRocm93cyBgbm8gaG9zdCB0cmFuc3BvcnRgIGF0XG4vLyBtb2R1bGUtZXZhbCB0aW1lIHVuZGVyIGxvY2FsIGB2aXRlIGRldmAuIGAvbW91bnRzYCBpcyBzaWRlLWVmZmVjdC1mcmVlLlxuaW1wb3J0IHsgZ2V0TW91bnRzLCBvbk1vdW50c0NoYW5nZSB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrL21vdW50cyc7XG5pbXBvcnQgdHlwZSB7IFNhbmRib3hNb3VudCB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrL21vdW50cyc7XG5pbXBvcnQge1xuICBhYm9ydE9wZW5Qcm9qZWN0LFxuICBkaXJDYXBUb0JvYXJkVGFyZ2V0LFxuICByZWFkT3BlblByb2plY3RJbnB1dCxcbiAgcmVwb3J0T3BlbmVkLFxuICByZXNvbHZlRGVsZWdhdGVkTW91bnQsXG59IGZyb20gJy4uL2xpYi9vcGVuUHJvamVjdCc7XG5cbi8qKiBKb2luIGEgbW91bnQgcm9vdCB3aXRoIGEgKHZhbGlkYXRlZCwgcmVsYXRpdmUpIHBhdGg7IGNvbGxhcHNlIGRvdWJsZSBzbGFzaGVzLiAqL1xuY29uc3Qgc3ViUGF0aCA9IChyb290OiBzdHJpbmcsIHJlbDogc3RyaW5nKTogc3RyaW5nID0+IGAke3Jvb3R9LyR7cmVsfWAucmVwbGFjZSgvXFwvKy9nLCAnLycpO1xuXG4vKiogU2hvcnQgYCDCtyBjb2RlYCBzdWZmaXggZnJvbSBhIHR5cGVkIHBsYXRmb3JtL2ZzIGVycm9yLCBmb3IgdG9hc3QgdGV4dC4gKi9cbmZ1bmN0aW9uIGNvZGVPZihlOiB1bmtub3duKTogc3RyaW5nIHtcbiAgY29uc3QgYyA9IChlIGFzIHsgY29kZT86IHN0cmluZyB9IHwgbnVsbCk/LmNvZGU7XG4gIHJldHVybiBjID8gYCDCtyAke2N9YCA6ICcnO1xufVxuXG5pbnRlcmZhY2UgV0JTdGF0ZSB7XG4gIG1vZGU6IE1vZGU7XG4gIGxpZ2h0OiBib29sZWFuO1xuICBiZzogQmFja2dyb3VuZDtcbiAgdGl0bGU6IHN0cmluZztcbiAgY2FtOiBDYW1lcmE7XG4gIHZwOiBWaWV3cG9ydDtcbiAgb2JqZWN0czogV09iamVjdFtdO1xuICB2aWV3czogVmlld1tdO1xuICBqb3VybmV5czogSm91cm5leVtdO1xuICBzZWxlY3Rpb246IHN0cmluZ1tdO1xuICBob3Zlcjogc3RyaW5nIHwgbnVsbDtcbiAgbWFycXVlZTogeyB4OiBudW1iZXI7IHk6IG51bWJlcjsgdzogbnVtYmVyOyBoOiBudW1iZXIgfSB8IG51bGw7XG4gIGNvbm5lY3RQcmV2aWV3OiB7IGZyb206IHN0cmluZzsgeDogbnVtYmVyOyB5OiBudW1iZXI7IHRhcmdldDogc3RyaW5nIHwgbnVsbCB9IHwgbnVsbDtcbiAgLyoqIEtleWJvYXJkIGNvbm5lY3QgbW9kZSAoUjMtNjA3KTogdGhlIHNvdXJjZSBvYmplY3QsIGFuZCB0aGUgY3Vyc29yIG9iamVjdFxuICAgKiAgYXJyb3dzIHdhbGsgYXMgdGhlIGNvbm5lY3QgdGFyZ2V0LiBOdWxsIHdoZW4gbm90IGNvbm5lY3RpbmcuICovXG4gIGNvbm5lY3RGcm9tOiBzdHJpbmcgfCBudWxsO1xuICBjb25uZWN0Q3Vyc29yOiBzdHJpbmcgfCBudWxsO1xuICBpbnNwZWN0b3JPcGVuOiBib29sZWFuO1xuICBwYW5lbE9wZW46IGJvb2xlYW47XG4gIHF1aWNrTWVudTogeyBseDogbnVtYmVyOyBseTogbnVtYmVyOyB3eDogbnVtYmVyOyB3eTogbnVtYmVyIH0gfCBudWxsO1xuICBqb3VybmV5OiB7IGppZDogc3RyaW5nOyBpZHg6IG51bWJlciB9IHwgbnVsbDtcbiAgdG9hc3RzOiBUb2FzdFtdO1xuICBzY3JlZW46IFNjcmVlbktpbmQ7XG4gIGRlbW9NZW51T3BlbjogYm9vbGVhbjtcbiAgcGFubmluZzogYm9vbGVhbjtcbiAgcmVkdWNlZDogYm9vbGVhbjtcbiAgLyoqIFRoZSBuYW1lZCBidXN5IHN0YXRlIG9mIHRoZSBvbmUgbG9uZy1ydW5uaW5nIHBpY2sgZmxvdyAoUi1JWC0yKTogdGhlXG4gICAqICBjb25maXJtaW5nIGNvbnRyb2wgc2hvd3MgdGhpcyBsYWJlbCBhbmQgYXJpYS1idXN5IHVudGlsIGl0IHNldHRsZXMuICovXG4gIGJ1c3k6IG51bGwgfCAnaW5zZXJ0LWltYWdlJyB8ICduZXctYm9hcmQnIHwgJ29wZW4tYm9hcmQnO1xuICAvKiogTGl2ZSBtb3VudHMsIG1pcnJvcmVkIGZyb20gdGhlIGhvc3QgKHRoZSBib2FyZCBjaG9vc2VyIGxpc3RzIHRoZXNlKS4gKi9cbiAgbW91bnRzOiBTYW5kYm94TW91bnRbXTtcbn1cblxudHlwZSBEcmFnID1cbiAgfCB7IHR5cGU6ICdwYW4nOyBzeDogbnVtYmVyOyBzeTogbnVtYmVyOyBjeDogbnVtYmVyOyBjeTogbnVtYmVyIH1cbiAgfCB7IHR5cGU6ICdtb3ZlJzsgc3g6IG51bWJlcjsgc3k6IG51bWJlcjsgaWRzOiBzdHJpbmdbXTsgb3JpZzogUmVjb3JkPHN0cmluZywgeyB4OiBudW1iZXI7IHk6IG51bWJlciB9PjsgbW92ZWQ6IGJvb2xlYW4gfVxuICB8IHsgdHlwZTogJ21hcnF1ZWUnOyBzeDogbnVtYmVyOyBzeTogbnVtYmVyOyBhZGQ6IGJvb2xlYW47IGJhc2U6IHN0cmluZ1tdIH1cbiAgfCB7IHR5cGU6ICdjb25uZWN0JzsgZnJvbTogc3RyaW5nOyBzaWRlOiBzdHJpbmc7IG1vdmVkOiBib29sZWFuIH1cbiAgfCB7IHR5cGU6ICdyZXNpemUnOyBraW5kOiBzdHJpbmc7IHN4OiBudW1iZXI7IHN5OiBudW1iZXI7IG86IHsgeDogbnVtYmVyOyB5OiBudW1iZXI7IHc6IG51bWJlcjsgaDogbnVtYmVyOyByb3Q6IG51bWJlciB9OyBpZDogc3RyaW5nOyBtb3ZlZDogYm9vbGVhbiB9XG4gIHwgeyB0eXBlOiAncm90YXRlJzsgc3g6IG51bWJlcjsgc3k6IG51bWJlcjsgbzogeyB4OiBudW1iZXI7IHk6IG51bWJlcjsgdzogbnVtYmVyOyBoOiBudW1iZXI7IHJvdDogbnVtYmVyIH07IGlkOiBzdHJpbmc7IG1vdmVkOiBib29sZWFuIH1cbiAgfCBudWxsO1xuXG5jb25zdCBpbml0aWFsVmlld3BvcnQgPSAoKTogVmlld3BvcnQgPT4gKHtcbiAgdnc6IHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnID8gd2luZG93LmlubmVyV2lkdGggOiAxNDQwLFxuICB2aDogdHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgPyB3aW5kb3cuaW5uZXJIZWlnaHQgOiA5MDAsXG4gIHZsZWZ0OiAwLFxuICB2dG9wOiAwLFxufSk7XG5cbi8qKiBUaGUgT05FIHNwZWxsaW5nIG9mIHNlbGVjdGlvbiBzZW1hbnRpY3MgKFIzLTYwNywgUjYpOiBnaXZlbiB0aGUgY3VycmVudFxuICogIHNlbGVjdGlvbiBhbmQgYW4gaWQsIHRoZSBuZXh0IHNlbGVjdGlvbiBmb3IgYSByZXBsYWNlLSBvciB0b2dnbGUtY2xpY2sgL1xuICogIGZvY3VzLiBQdXJlLCBzbyB0aGUgcG9pbnRlciBwYXRoIGFuZCB0aGUga2V5Ym9hcmQgcGF0aCBjYW5ub3QgZHJpZnQuICovXG5leHBvcnQgZnVuY3Rpb24gYXBwbHlTZWxlY3Rpb24oc2VsOiBzdHJpbmdbXSwgaWQ6IHN0cmluZywgYWRkaXRpdmU6IGJvb2xlYW4pOiBzdHJpbmdbXSB7XG4gIGlmIChhZGRpdGl2ZSkgcmV0dXJuIHNlbC5pbmNsdWRlcyhpZCkgPyBzZWwuZmlsdGVyKCh4KSA9PiB4ICE9PSBpZCkgOiBzZWwuY29uY2F0KGlkKTtcbiAgcmV0dXJuIHNlbC5pbmNsdWRlcyhpZCkgPyBzZWwgOiBbaWRdO1xufVxuXG5jb25zdCBNT0JJTEVfQlJFQUtQT0lOVCA9IDcyMDtcblxuLy8gVGhlIGJvYXJkLW1hbmlmZXN0IHNjaGVtYSB2ZXJzaW9uIFRISVMgcmVhZGVyIHVuZGVyc3RhbmRzLiBBIG1hbmlmZXN0IGNhcnJ5aW5nXG4vLyBhIGhpZ2hlciBgc2NoZW1hOmAgaXMgZnJvbSBhIG5ld2VyIHJlYWRlciDigJQgcmVjb2duaXNlZCBidXQgbWFya2VkIHJlYWRvbmx5ICh0aGVcbi8vIGByZWFkb25seWAgZGVncmFkZWQgc3RhdGUsIHNwZWMgwqcyLjQpIHJhdGhlciB0aGFuIG1pcy1yZW5kZXJlZCAoUjMtNDAxKS5cbmNvbnN0IFNVUFBPUlRFRF9TQ0hFTUEgPSAxO1xuXG4vLyBUaGUgdXNhYmxlIGhlaWdodCBhIGpvdXJuZXktcGxheWluZyByZWN0IHZpZXcgZml0cyBpbnRvOiB0aGUgY2FwdGlvbiArIGNvbnRyb2xzXG4vLyB0YWtlIHJvdWdobHkgdGhlIGJvdHRvbSAyNDBweCBvZiBhbiA4NDRweCBwaG9uZSB2aWV3cG9ydCAoaXRlbSBSMy00MDApLCBzbyBhXG4vLyBmaXR0ZWQgdmlldyBtdXN0IGNsZWFyIHRoYXQgYmFuZCBvciB0aGUgc3ViamVjdCBoaWRlcyB1bmRlciB0aGUgY2hyb21lLlxuY29uc3QgSk9VUk5FWV9GSVRfSU5TRVQgPSAyNDA7XG5cbmNvbnN0IHByZWZlcnNSZWR1Y2VkTW90aW9uID0gKCk6IGJvb2xlYW4gPT4ge1xuICB0cnkge1xuICAgIHJldHVybiB3aW5kb3cubWF0Y2hNZWRpYSgnKHByZWZlcnMtcmVkdWNlZC1tb3Rpb246IHJlZHVjZSknKS5tYXRjaGVzO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbn07XG5cbi8qKiBUaGUgT05FIHNwZWxsaW5nIG9mIHdoYXQgZWFjaCBuYW1lZCBidXN5IHN0YXRlIHNheXMgb24gaXRzIGNvbnRyb2xcbiAqICAoUi1JWC0yIC8gUjYpOiBldmVyeSBzdXJmYWNlIHRoYXQgbmFtZXMgYSB3YWl0IHJlYWRzIHRoaXMgbWFwIOKAlCBjb3VwbGVkXG4gKiAgc3VyZmFjZXMgY2Fubm90IGRyaWZ0IGFwYXJ0IG9uIGEgcmV3b3JkLiAqL1xuZXhwb3J0IGNvbnN0IEJVU1lfTEFCRUxTID0ge1xuICAnaW5zZXJ0LWltYWdlJzogJ0FkZGluZyBpbWFnZeKApicsXG4gICduZXctYm9hcmQnOiAnQ3JlYXRpbmcgYm9hcmTigKYnLFxuICAnb3Blbi1ib2FyZCc6ICdPcGVuaW5nIGJvYXJk4oCmJyxcbn0gYXMgY29uc3Q7XG5cbmV4cG9ydCBmdW5jdGlvbiB1c2VMb2Rlc3RhcigpIHtcbiAgLy8gVGhlIGNhbnZhcyBlbGVtZW50IGFycml2ZXMgdmlhIGEgY2FsbGJhY2sgcmVmIChhIGZ1bmN0aW9uLCBub3QgYSByZWYgb2JqZWN0XG4gIC8vIHJlYWQgZHVyaW5nIHJlbmRlcikgc28gdGhlIGxpc3RlbmVyIGVmZmVjdCByZS1ydW5zIG9uY2UgaXQgbW91bnRzLlxuICBjb25zdCBbY2FudmFzRWwsIHNldENhbnZhc0VsXSA9IHVzZVN0YXRlPEhUTUxEaXZFbGVtZW50IHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IHJlZ2lzdGVyQ2FudmFzID0gdXNlQ2FsbGJhY2soKGVsOiBIVE1MRGl2RWxlbWVudCB8IG51bGwpID0+IHNldENhbnZhc0VsKGVsKSwgW10pO1xuICBjb25zdCBkcmFnUmVmID0gdXNlUmVmPERyYWc+KG51bGwpO1xuICBjb25zdCB0d2VlblJlZiA9IHVzZVJlZjxudW1iZXIgfCBudWxsPihudWxsKTtcbiAgY29uc3QgaG9sZFRpbWVyID0gdXNlUmVmPG51bWJlciB8IG51bGw+KG51bGwpO1xuICBjb25zdCBzcGFjZVJlZiA9IHVzZVJlZihmYWxzZSk7XG4gIGNvbnN0IHRvYXN0U2VxID0gdXNlUmVmKDApO1xuICAvLyBTdGFibGUgaW5kaXJlY3Rpb24gZm9yIHRoZSBkd2VsbCBhdXRvLWFkdmFuY2U6IGBnb1N0ZXBgIHNjaGVkdWxlc1xuICAvLyBgcGxheU5leHRSZWYuY3VycmVudCgpYCBzbyB0aGUgdGltZXIgYWx3YXlzIGNhbGxzIHRoZSBMQVRFU1QgcGxheU5leHRcbiAgLy8gKGFzc2lnbmVkIGFmdGVyIGl0cyB1c2VDYWxsYmFjayBpcyBkZWZpbmVkKSDigJQgYnJlYWtzIHRoZSBjaXJjdWxhciBkZXAuXG4gIGNvbnN0IHBsYXlOZXh0UmVmID0gdXNlUmVmPCgpID0+IHZvaWQ+KCgpID0+IHt9KTtcblxuICBjb25zdCBbc3RhdGUsIHNldFN0YXRlXSA9IHVzZVN0YXRlPFdCU3RhdGU+KCgpID0+ICh7XG4gICAgbW9kZTogJ3J1bicsXG4gICAgbGlnaHQ6IGZhbHNlLFxuICAgIGJnOiBCT0FSRC5iYWNrZ3JvdW5kLFxuICAgIHRpdGxlOiBCT0FSRC50aXRsZSxcbiAgICBjYW06IHsgY3g6IDI1MCwgY3k6IDE1MCwgem9vbTogMC42IH0sXG4gICAgdnA6IGluaXRpYWxWaWV3cG9ydCgpLFxuICAgIG9iamVjdHM6IHNlZWRPYmplY3RzKCksXG4gICAgdmlld3M6IFNFRURfVklFV1Muc2xpY2UoKSxcbiAgICBqb3VybmV5czogU0VFRF9KT1VSTkVZUyxcbiAgICBzZWxlY3Rpb246IFtdLFxuICAgIGhvdmVyOiBudWxsLFxuICAgIG1hcnF1ZWU6IG51bGwsXG4gICAgY29ubmVjdFByZXZpZXc6IG51bGwsXG4gICAgY29ubmVjdEZyb206IG51bGwsXG4gICAgY29ubmVjdEN1cnNvcjogbnVsbCxcbiAgICBpbnNwZWN0b3JPcGVuOiBmYWxzZSxcbiAgICBwYW5lbE9wZW46IGZhbHNlLFxuICAgIHF1aWNrTWVudTogbnVsbCxcbiAgICBqb3VybmV5OiBudWxsLFxuICAgIHRvYXN0czogW10sXG4gICAgc2NyZWVuOiBudWxsLFxuICAgIGRlbW9NZW51T3BlbjogZmFsc2UsXG4gICAgcGFubmluZzogZmFsc2UsXG4gICAgcmVkdWNlZDogcHJlZmVyc1JlZHVjZWRNb3Rpb24oKSxcbiAgICBidXN5OiBudWxsLFxuICAgIG1vdW50czogW10sXG4gIH0pKTtcblxuICAvLyBNaXJyb3IgY29tbWl0dGVkIHN0YXRlIHNvIHRoZSBkb2N1bWVudC1sZXZlbCBoYW5kbGVycyBicmFuY2ggb24gZnJlc2ggdmFsdWVzLlxuICBjb25zdCBzdGF0ZVJlZiA9IHVzZVJlZihzdGF0ZSk7XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgc3RhdGVSZWYuY3VycmVudCA9IHN0YXRlO1xuICB9KTtcblxuICBjb25zdCB1cGRhdGUgPSB1c2VDYWxsYmFjayhcbiAgICAocGF0Y2g6IFBhcnRpYWw8V0JTdGF0ZT4gfCAoKHM6IFdCU3RhdGUpID0+IFBhcnRpYWw8V0JTdGF0ZT4pKSA9PlxuICAgICAgc2V0U3RhdGUoKHByZXYpID0+ICh7IC4uLnByZXYsIC4uLih0eXBlb2YgcGF0Y2ggPT09ICdmdW5jdGlvbicgPyBwYXRjaChwcmV2KSA6IHBhdGNoKSB9KSksXG4gICAgW10sXG4gICk7XG5cbiAgY29uc3QgaXNNb2JpbGUgPSB1c2VDYWxsYmFjaygoKSA9PiBzdGF0ZS52cC52dyA8IE1PQklMRV9CUkVBS1BPSU5ULCBbc3RhdGUudnAudnddKTtcblxuICAvLyAtLS0tIGNhbWVyYSBoZWxwZXJzIChyZWFkIGxhdGVzdCB2aWV3cG9ydCBmcm9tIHRoZSByZWYpIC0tLS1cbiAgY29uc3QgbG9jYWxQb2ludCA9IHVzZUNhbGxiYWNrKChlOiB7IGNsaWVudFg6IG51bWJlcjsgY2xpZW50WTogbnVtYmVyIH0pOiBbbnVtYmVyLCBudW1iZXJdID0+IHtcbiAgICBjb25zdCB2cCA9IHN0YXRlUmVmLmN1cnJlbnQudnA7XG4gICAgcmV0dXJuIFtlLmNsaWVudFggLSB2cC52bGVmdCwgZS5jbGllbnRZIC0gdnAudnRvcF07XG4gIH0sIFtdKTtcblxuICBjb25zdCBzZXRab29tID0gdXNlQ2FsbGJhY2soKG56OiBudW1iZXIsIGx4PzogbnVtYmVyLCBseT86IG51bWJlcikgPT4ge1xuICAgIHVwZGF0ZSgocykgPT4gKHsgY2FtOiB6b29tQXJvdW5kKHMuY2FtLCBzLnZwLCBueiwgbHgsIGx5KSB9KSk7XG4gIH0sIFt1cGRhdGVdKTtcblxuICAvLyAtLS0tIHRvYXN0cyAtLS0tXG4gIGNvbnN0IGRpc21pc3NUb2FzdCA9IHVzZUNhbGxiYWNrKChpZDogbnVtYmVyKSA9PiB7XG4gICAgdXBkYXRlKChzKSA9PiAoeyB0b2FzdHM6IHMudG9hc3RzLmZpbHRlcigodCkgPT4gdC5pZCAhPT0gaWQpIH0pKTtcbiAgfSwgW3VwZGF0ZV0pO1xuXG4gIGNvbnN0IHRvYXN0ID0gdXNlQ2FsbGJhY2soXG4gICAgKHRleHQ6IHN0cmluZywgaWNvbiA9ICdjaGVjaycsIG9wdHM6IFBhcnRpYWw8VG9hc3Q+ID0ge30pID0+IHtcbiAgICAgIGNvbnN0IGlkID0gKyt0b2FzdFNlcS5jdXJyZW50O1xuICAgICAgY29uc3QgdDogVG9hc3QgPSB7IGlkLCB0ZXh0LCBpY29uLCAuLi5vcHRzIH07XG4gICAgICB1cGRhdGUoKHMpID0+ICh7IHRvYXN0czogcy50b2FzdHMuY29uY2F0KHQpIH0pKTtcbiAgICAgIGNvbnN0IHR0bCA9IG9wdHMuYWN0aW9uTGFiZWwgPyA5MDAwIDogMzUwMDtcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4gZGlzbWlzc1RvYXN0KGlkKSwgdHRsKTtcbiAgICB9LFxuICAgIFt1cGRhdGUsIGRpc21pc3NUb2FzdF0sXG4gICk7XG5cbiAgLy8gLS0tLSBwZXJzaXN0ZW5jZSAodGhlIMKnMi42IHJvdW5kLXRyaXAgc2VhbSwgbm93IGxpdmUpIC0tLS1cbiAgLy8gVGhlIGJvYXJkJ3MgZHVyYWJsZSB0YXJnZXQgKGEgcGVyLXVzZXIgYXBwIHNwYWNlKSBvbmNlIHJlc29sdmVkOyBudWxsIG1lYW5zXG4gIC8vIHdlIG5ldmVyIGdvdCBvbmUgKHNpZ25lZCBvdXQgLyBkZWNsaW5lZCkgYW5kIHRoZSBib2FyZCBpcyBpbiBtZW1vcnkgb25seS5cbiAgY29uc3QgYm9hcmRSZWYgPSB1c2VSZWY8Qm9hcmRUYXJnZXQgfCBudWxsPihudWxsKTtcbiAgLy8gUGVyLW9iamVjdCBkZWJvdW5jZSB0aW1lcnMgc28gaW5zcGVjdG9yIHR5cGluZyAvIGFycm93IG51ZGdlcyBhdXRvc2F2ZSBvbmNlXG4gIC8vIHRoZXkgc2V0dGxlLCBub3Qgb24gZXZlcnkga2V5c3Ryb2tlLlxuICBjb25zdCBzYXZlVGltZXJzID0gdXNlUmVmPE1hcDxzdHJpbmcsIG51bWJlcj4+KG5ldyBNYXAoKSk7XG5cbiAgLy8gV3JpdGUgdGhlIGdpdmVuIG9iamVjdHMnIGZpbGVzLCB0aGVuIHJlcG9ydCB3aXRoIG9uZSB0b2FzdC4gV2l0aCBubyBib2FyZFxuICAvLyB0aGUgY2hhbmdlIGlzIGluIG1lbW9yeSBvbmx5ICh3ZSBrZWVwIHRoZSBvcHRpbWlzdGljIG1lc3NhZ2UpOyBhIHJlYWQtb25seVxuICAvLyBib2FyZCByZXBvcnRzIGluc3RlYWQgb2Ygc2lsZW50bHkgZHJvcHBpbmcgdGhlIHdyaXRlLlxuICBjb25zdCBjb21taXRTYXZlID0gdXNlQ2FsbGJhY2soXG4gICAgKG9ianM6IFdPYmplY3RbXSwgc2F2ZWRUZXh0OiBzdHJpbmcsIHNhdmVkSWNvbiA9ICdjaGVjaycpID0+IHtcbiAgICAgIGNvbnN0IHQgPSBib2FyZFJlZi5jdXJyZW50O1xuICAgICAgaWYgKCF0KSB7XG4gICAgICAgIHRvYXN0KHNhdmVkVGV4dCwgc2F2ZWRJY29uKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgaWYgKHQubW9kZSA9PT0gJ3JvJykge1xuICAgICAgICB0b2FzdCgnUmVhZC1vbmx5IGJvYXJkIMK3IGNoYW5nZSBub3Qgc2F2ZWQnLCAnbG9jaycsIHsgaWNvbkNvbG9yOiAndmFyKC0taW5rLTIpJyB9KTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgUHJvbWlzZS5hbGwob2Jqcy5tYXAoKG8pID0+IHNhdmVPYmplY3QodCwgbykpKS50aGVuKFxuICAgICAgICAoKSA9PiB0b2FzdChzYXZlZFRleHQsIHNhdmVkSWNvbiksXG4gICAgICAgIChlKSA9PiB0b2FzdChgU2F2ZSBmYWlsZWQke2NvZGVPZihlKX1gLCAnYWxlcnQnLCB7IGljb25Db2xvcjogJyNjYWEyNGEnIH0pLFxuICAgICAgKTtcbiAgICB9LFxuICAgIFt0b2FzdF0sXG4gICk7XG5cbiAgLy8gUXVpZXQgZGVib3VuY2VkIGF1dG9zYXZlIGZvciBjb250aW51b3VzIGVkaXRzICh0eXBpbmcsIGFycm93LWtleSBudWRnZXMpLlxuICBjb25zdCBzY2hlZHVsZVNhdmUgPSB1c2VDYWxsYmFjaygoaWRzOiBzdHJpbmdbXSkgPT4ge1xuICAgIGNvbnN0IHQgPSBib2FyZFJlZi5jdXJyZW50O1xuICAgIGlmICghdCB8fCB0Lm1vZGUgPT09ICdybycpIHJldHVybjtcbiAgICBmb3IgKGNvbnN0IGlkIG9mIGlkcykge1xuICAgICAgY29uc3QgcHJldiA9IHNhdmVUaW1lcnMuY3VycmVudC5nZXQoaWQpO1xuICAgICAgaWYgKHByZXYpIGNsZWFyVGltZW91dChwcmV2KTtcbiAgICAgIGNvbnN0IGhhbmRsZSA9IHdpbmRvdy5zZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgc2F2ZVRpbWVycy5jdXJyZW50LmRlbGV0ZShpZCk7XG4gICAgICAgIGNvbnN0IG8gPSBzdGF0ZVJlZi5jdXJyZW50Lm9iamVjdHMuZmluZCgoeCkgPT4geC5pZCA9PT0gaWQpO1xuICAgICAgICBpZiAobykgc2F2ZU9iamVjdCh0LCBvKS5jYXRjaCgoKSA9PiB1bmRlZmluZWQpO1xuICAgICAgfSwgNTAwKTtcbiAgICAgIHNhdmVUaW1lcnMuY3VycmVudC5zZXQoaWQsIGhhbmRsZSk7XG4gICAgfVxuICB9LCBbXSk7XG5cbiAgLy8gLS0tLSBjYW1lcmEgYW5pbWF0aW9uIC0tLS1cbiAgY29uc3QgZmx5VG8gPSB1c2VDYWxsYmFjayhcbiAgICAodGFyZ2V0OiBWaWV3VGFyZ2V0IHwgbnVsbCwgZHVyPzogbnVtYmVyLCBmaXRIPzogbnVtYmVyKSA9PiB7XG4gICAgICBpZiAoIXRhcmdldCkgcmV0dXJuO1xuICAgICAgLy8gQSB2aWV3IGNhcnJ5aW5nIGEgcmVjdCBuYW1lcyBhIFJFR0lPTiwgbm90IGEgbWFnbmlmaWNhdGlvbjogZml0IGl0IHRvIHRoZVxuICAgICAgLy8gdXNhYmxlIHZpZXdwb3J0IChSMy00MDApLiBmaXRIICh3aGVuIGdpdmVuKSBpcyB0aGUgdXNhYmxlIGhlaWdodCDigJQgdGhlXG4gICAgICAvLyBjYXB0aW9uIGJhbmQgZHVyaW5nIGpvdXJuZXkgcGxheWJhY2sg4oCUIHNvIHRoZSBzdWJqZWN0IGNsZWFycyB0aGUgY2hyb21lLlxuICAgICAgY29uc3QgZGVzdCA9IGNhbWVyYUZvclRhcmdldCh0YXJnZXQsIHN0YXRlUmVmLmN1cnJlbnQudnAudncsIGZpdEggPz8gc3RhdGVSZWYuY3VycmVudC52cC52aCk7XG4gICAgICBpZiAodHdlZW5SZWYuY3VycmVudCkgY2FuY2VsQW5pbWF0aW9uRnJhbWUodHdlZW5SZWYuY3VycmVudCk7XG4gICAgICBpZiAoc3RhdGVSZWYuY3VycmVudC5yZWR1Y2VkIHx8ICFkdXIpIHtcbiAgICAgICAgdXBkYXRlKHsgY2FtOiBkZXN0IH0pO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBjb25zdCBmcm9tID0geyAuLi5zdGF0ZVJlZi5jdXJyZW50LmNhbSB9O1xuICAgICAgY29uc3QgdDAgPSBwZXJmb3JtYW5jZS5ub3coKTtcbiAgICAgIGNvbnN0IGVhc2UgPSAocDogbnVtYmVyKSA9PiAocCA8IDAuNSA/IDQgKiBwICogcCAqIHAgOiAxIC0gTWF0aC5wb3coLTIgKiBwICsgMiwgMykgLyAyKTtcbiAgICAgIGNvbnN0IHN0ZXAgPSAobm93OiBudW1iZXIpID0+IHtcbiAgICAgICAgY29uc3QgcCA9IE1hdGgubWluKDEsIChub3cgLSB0MCkgLyBkdXIpO1xuICAgICAgICBjb25zdCBlID0gZWFzZShwKTtcbiAgICAgICAgdXBkYXRlKHtcbiAgICAgICAgICBjYW06IHtcbiAgICAgICAgICAgIGN4OiBmcm9tLmN4ICsgKGRlc3QuY3ggLSBmcm9tLmN4KSAqIGUsXG4gICAgICAgICAgICBjeTogZnJvbS5jeSArIChkZXN0LmN5IC0gZnJvbS5jeSkgKiBlLFxuICAgICAgICAgICAgem9vbTogZnJvbS56b29tICsgKGRlc3Quem9vbSAtIGZyb20uem9vbSkgKiBlLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgICBpZiAocCA8IDEpIHR3ZWVuUmVmLmN1cnJlbnQgPSByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoc3RlcCk7XG4gICAgICB9O1xuICAgICAgdHdlZW5SZWYuY3VycmVudCA9IHJlcXVlc3RBbmltYXRpb25GcmFtZShzdGVwKTtcbiAgICB9LFxuICAgIFt1cGRhdGVdLFxuICApO1xuXG4gIC8vIC0tLS0gdmlld3MgJiBqb3VybmV5cyAtLS0tXG4gIGNvbnN0IHJlc29sdmVWaWV3ID0gdXNlQ2FsbGJhY2soKHY6IFZpZXdUYXJnZXQgfCBzdHJpbmcpID0+IHtcbiAgICBpZiAodHlwZW9mIHYgPT09ICdzdHJpbmcnKSByZXR1cm4gc3RhdGVSZWYuY3VycmVudC52aWV3cy5maW5kKCh4KSA9PiB4Lm5hbWUgPT09IHYpID8/IG51bGw7XG4gICAgY29uc3QgdDogVmlld1RhcmdldCA9IHsgY3g6IHYuY3gsIGN5OiB2LmN5LCB6b29tOiB2Lnpvb20gfTtcbiAgICBpZiAodi53KSB0LncgPSB2Lnc7XG4gICAgaWYgKHYuaCkgdC5oID0gdi5oO1xuICAgIHJldHVybiB0O1xuICB9LCBbXSk7XG5cbiAgY29uc3Qgc2F2ZVZpZXcgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgY29uc3QgcyA9IHN0YXRlUmVmLmN1cnJlbnQ7XG4gICAgY29uc3QgdmlldzogVmlldyA9IHsgbmFtZTogYHZpZXctJHtzLnZpZXdzLmxlbmd0aCArIDF9YCwgY3g6IHMuY2FtLmN4LCBjeTogcy5jYW0uY3ksIHpvb206IHMuY2FtLnpvb20gfTtcbiAgICB1cGRhdGUoKHN0KSA9PiAoeyB2aWV3czogc3Qudmlld3MuY29uY2F0KFt2aWV3XSkgfSkpO1xuICAgIGNvbnN0IHRleHQgPSBgU2F2ZWQgdmlld3MvJHt2aWV3Lm5hbWV9Lm1kYDtcbiAgICBjb25zdCB0ID0gYm9hcmRSZWYuY3VycmVudDtcbiAgICBpZiAoIXQpIHtcbiAgICAgIHRvYXN0KHRleHQsICdzYXZlJyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmICh0Lm1vZGUgPT09ICdybycpIHtcbiAgICAgIHRvYXN0KCdSZWFkLW9ubHkgYm9hcmQgwrcgdmlldyBub3Qgc2F2ZWQnLCAnbG9jaycsIHsgaWNvbkNvbG9yOiAndmFyKC0taW5rLTIpJyB9KTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgcGVyc2lzdFZpZXcodCwgdmlldykudGhlbihcbiAgICAgICgpID0+IHRvYXN0KHRleHQsICdzYXZlJyksXG4gICAgICAoZSkgPT4gdG9hc3QoYENvdWxkbid0IHNhdmUgdmlldyR7Y29kZU9mKGUpfWAsICdhbGVydCcsIHsgaWNvbkNvbG9yOiAnI2NhYTI0YScgfSksXG4gICAgKTtcbiAgfSwgW3VwZGF0ZSwgdG9hc3RdKTtcblxuICAvKiogUmVtb3ZlIGEgdmlldyBvbiB0aGUgc3VyZmFjZSB0aGF0IGNyZWF0ZXMgdGhlbSAoUjMtNjA3LCBSLUlYLTUpLiBBXG4gICAqICByZWFkLW9ubHkgYm9hcmQgcmVmdXNlcyBCRUZPUkUgYW55dGhpbmcgZHJvcHMgKHRoZSByb3cgbmV2ZXIgdmFuaXNoZXNcbiAgICogIGludG8gYSByZWZ1c2FsKTsgb24gd3JpdGFibGUgYm9hcmRzIHRoZSBkcm9wIGlzIG9wdGltaXN0aWMgYW5kIGEgZmFpbGVkXG4gICAqICBmaWxlIHJlbW92YWwgcm9sbHMgdGhlIHZpZXcgYmFjayBpbi4gKi9cbiAgY29uc3QgZGVsZXRlVmlldyA9IHVzZUNhbGxiYWNrKFxuICAgIChuYW1lOiBzdHJpbmcpID0+IHtcbiAgICAgIGNvbnN0IHQgPSBib2FyZFJlZi5jdXJyZW50O1xuICAgICAgY29uc3QgdmlldyA9IHN0YXRlUmVmLmN1cnJlbnQudmlld3MuZmluZCgodikgPT4gdi5uYW1lID09PSBuYW1lKTtcbiAgICAgIGlmICghdmlldykgcmV0dXJuO1xuICAgICAgaWYgKHQgJiYgdC5tb2RlID09PSAncm8nKSB7XG4gICAgICAgIHRvYXN0KCdSZWFkLW9ubHkgYm9hcmQgwrcgdmlldyBub3QgcmVtb3ZlZCcsICdsb2NrJywgeyBpY29uQ29sb3I6ICd2YXIoLS1pbmstMiknIH0pO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICB1cGRhdGUoKHMpID0+ICh7IHZpZXdzOiBzLnZpZXdzLmZpbHRlcigodikgPT4gdi5uYW1lICE9PSBuYW1lKSB9KSk7XG4gICAgICBpZiAoIXQpIHtcbiAgICAgICAgdG9hc3QoYFJlbW92ZWQgdmlld3MvJHtuYW1lfS5tZGAsICd0cmFzaCcpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICByZW1vdmVWaWV3KHQsIG5hbWUpLnRoZW4oXG4gICAgICAgICgpID0+IHRvYXN0KGBSZW1vdmVkIHZpZXdzLyR7bmFtZX0ubWRgLCAndHJhc2gnKSxcbiAgICAgICAgKGUpID0+IHtcbiAgICAgICAgICAvLyBSb2xsIHRoZSBvcHRpbWlzdGljIGRyb3AgYmFjayDigJQgdGhlIGZpbGUgc3Vydml2ZWQsIHNvIG11c3QgdGhlIHJvdy5cbiAgICAgICAgICB1cGRhdGUoKHMpID0+IChzLnZpZXdzLnNvbWUoKHYpID0+IHYubmFtZSA9PT0gbmFtZSkgPyB7fSA6IHsgdmlld3M6IHMudmlld3MuY29uY2F0KFt2aWV3XSkgfSkpO1xuICAgICAgICAgIHRvYXN0KGBDb3VsZG4ndCByZW1vdmUgdmlldyR7Y29kZU9mKGUpfWAsICdhbGVydCcsIHsgaWNvbkNvbG9yOiAnI2NhYTI0YScgfSk7XG4gICAgICAgIH0sXG4gICAgICApO1xuICAgIH0sXG4gICAgW3VwZGF0ZSwgdG9hc3RdLFxuICApO1xuXG4gIGNvbnN0IGFkZEpvdXJuZXlTdGVwID0gdXNlQ2FsbGJhY2soXG4gICAgKGppZDogc3RyaW5nKSA9PiB7XG4gICAgICBjb25zdCBzID0gc3RhdGVSZWYuY3VycmVudDtcbiAgICAgIGNvbnN0IGogPSBzLmpvdXJuZXlzLmZpbmQoKHgpID0+IHguaWQgPT09IGppZCk7XG4gICAgICBpZiAoIWopIHJldHVybjtcbiAgICAgIGNvbnN0IG5leHQ6IEpvdXJuZXkgPSB7IC4uLmosIHN0ZXBzOiBqLnN0ZXBzLmNvbmNhdChbeyB2aWV3OiB7IGN4OiBzLmNhbS5jeCwgY3k6IHMuY2FtLmN5LCB6b29tOiBzLmNhbS56b29tIH0gfV0pIH07XG4gICAgICB1cGRhdGUoKHN0KSA9PiAoeyBqb3VybmV5czogc3Quam91cm5leXMubWFwKCh4KSA9PiAoeC5pZCA9PT0gamlkID8gbmV4dCA6IHgpKSB9KSk7XG4gICAgICBjb25zdCB0ZXh0ID0gYEFkZGVkIHN0ZXAgJHtuZXh0LnN0ZXBzLmxlbmd0aH0gdG8gJHtqLnRpdGxlfSDCtyBzYXZlZCB0byAke2ouaWR9Lm1keGA7XG4gICAgICBjb25zdCB0ID0gYm9hcmRSZWYuY3VycmVudDtcbiAgICAgIGlmICghdCkge1xuICAgICAgICB0b2FzdCh0ZXh0LCAncGx1cycpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAodC5tb2RlID09PSAncm8nKSB7XG4gICAgICAgIHRvYXN0KCdSZWFkLW9ubHkgYm9hcmQgwrcgc3RlcCBub3Qgc2F2ZWQnLCAnbG9jaycsIHsgaWNvbkNvbG9yOiAndmFyKC0taW5rLTIpJyB9KTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgcGVyc2lzdEpvdXJuZXkodCwgbmV4dCkudGhlbihcbiAgICAgICAgKCkgPT4gdG9hc3QodGV4dCwgJ3BsdXMnKSxcbiAgICAgICAgKGUpID0+IHRvYXN0KGBDb3VsZG4ndCBzYXZlIGpvdXJuZXkke2NvZGVPZihlKX1gLCAnYWxlcnQnLCB7IGljb25Db2xvcjogJyNjYWEyNGEnIH0pLFxuICAgICAgKTtcbiAgICB9LFxuICAgIFt1cGRhdGUsIHRvYXN0XSxcbiAgKTtcblxuICBjb25zdCBnb1N0ZXAgPSB1c2VDYWxsYmFjayhcbiAgICAoajogSm91cm5leSwgaWR4OiBudW1iZXIsIGluc3RhbnQ/OiBib29sZWFuKSA9PiB7XG4gICAgICBjb25zdCBzID0gai5zdGVwc1tpZHhdO1xuICAgICAgY29uc3QgdiA9IHJlc29sdmVWaWV3KHMudmlldyk7XG4gICAgICBpZiAodikgZmx5VG8odiwgaW5zdGFudCA/IDAgOiBzLmR1cmF0aW9uID8/IDgwMCwgc3RhdGVSZWYuY3VycmVudC52cC52aCAtIEpPVVJORVlfRklUX0lOU0VUKTtcbiAgICAgIC8vIER3ZWxsIChSMy00MDIpOiBhIHN0ZXAgY2FycnlpbmcgYGhvbGRgIHBhdXNlcyB0aGF0IGxvbmcgYWZ0ZXIgYXJyaXZpbmcsXG4gICAgICAvLyB0aGVuIEFVVE8tYWR2YW5jZXMuIENsZWFyZWQgYnkgYW55IHZpZXdlciBjb250cm9sIChuZXh0L3ByZXYvc2Vlay9leGl0KS5cbiAgICAgIC8vIFVuZGVyIHByZWZlcnMtcmVkdWNlZC1tb3Rpb24gdGhlIGpvdXJuZXkgc3RheXMgaW5wdXQtZHJpdmVuIOKAlCBtYXRjaGluZ1xuICAgICAgLy8gZmx5VG8ncyBjdXQgb2YgdGhlIHR3ZWVuIOKAlCBzbyBhIHZpZXdlciBpcyBuZXZlciBhZHZhbmNlZCB1bnByb21wdGVkLlxuICAgICAgaWYgKGhvbGRUaW1lci5jdXJyZW50KSB7XG4gICAgICAgIGNsZWFyVGltZW91dChob2xkVGltZXIuY3VycmVudCk7XG4gICAgICAgIGhvbGRUaW1lci5jdXJyZW50ID0gbnVsbDtcbiAgICAgIH1cbiAgICAgIGlmIChzLmhvbGQgJiYgIXN0YXRlUmVmLmN1cnJlbnQucmVkdWNlZCkge1xuICAgICAgICBob2xkVGltZXIuY3VycmVudCA9IHdpbmRvdy5zZXRUaW1lb3V0KCgpID0+IHBsYXlOZXh0UmVmLmN1cnJlbnQoKSwgcy5ob2xkKTtcbiAgICAgIH1cbiAgICB9LFxuICAgIFtyZXNvbHZlVmlldywgZmx5VG9dLFxuICApO1xuXG4gIGNvbnN0IHBsYXlKb3VybmV5ID0gdXNlQ2FsbGJhY2soXG4gICAgKGppZDogc3RyaW5nKSA9PiB7XG4gICAgICBjb25zdCBqID0gc3RhdGVSZWYuY3VycmVudC5qb3VybmV5cy5maW5kKCh4KSA9PiB4LmlkID09PSBqaWQpO1xuICAgICAgaWYgKCFqKSByZXR1cm47XG4gICAgICBpZiAoaG9sZFRpbWVyLmN1cnJlbnQpIHtcbiAgICAgICAgY2xlYXJUaW1lb3V0KGhvbGRUaW1lci5jdXJyZW50KTtcbiAgICAgICAgaG9sZFRpbWVyLmN1cnJlbnQgPSBudWxsO1xuICAgICAgfVxuICAgICAgdXBkYXRlKHsgam91cm5leTogeyBqaWQsIGlkeDogMCB9LCBwYW5lbE9wZW46IGZhbHNlLCBpbnNwZWN0b3JPcGVuOiBmYWxzZSB9KTtcbiAgICAgIGdvU3RlcChqLCAwLCB0cnVlKTtcbiAgICB9LFxuICAgIFt1cGRhdGUsIGdvU3RlcF0sXG4gICk7XG5cbiAgY29uc3QgcGxheUV4aXQgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgaWYgKHR3ZWVuUmVmLmN1cnJlbnQpIGNhbmNlbEFuaW1hdGlvbkZyYW1lKHR3ZWVuUmVmLmN1cnJlbnQpO1xuICAgIGlmIChob2xkVGltZXIuY3VycmVudCkge1xuICAgICAgY2xlYXJUaW1lb3V0KGhvbGRUaW1lci5jdXJyZW50KTtcbiAgICAgIGhvbGRUaW1lci5jdXJyZW50ID0gbnVsbDtcbiAgICB9XG4gICAgdXBkYXRlKHsgam91cm5leTogbnVsbCB9KTtcbiAgfSwgW3VwZGF0ZV0pO1xuXG4gIGNvbnN0IHBsYXlOZXh0ID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIGNvbnN0IGpyID0gc3RhdGVSZWYuY3VycmVudC5qb3VybmV5O1xuICAgIGlmICghanIpIHJldHVybjtcbiAgICBpZiAoaG9sZFRpbWVyLmN1cnJlbnQpIHtcbiAgICAgIGNsZWFyVGltZW91dChob2xkVGltZXIuY3VycmVudCk7XG4gICAgICBob2xkVGltZXIuY3VycmVudCA9IG51bGw7XG4gICAgfVxuICAgIGNvbnN0IGogPSBzdGF0ZVJlZi5jdXJyZW50LmpvdXJuZXlzLmZpbmQoKHgpID0+IHguaWQgPT09IGpyLmppZCk7XG4gICAgaWYgKCFqKSByZXR1cm47XG4gICAgY29uc3QgbmkgPSBqci5pZHggKyAxO1xuICAgIGlmIChuaSA+PSBqLnN0ZXBzLmxlbmd0aCkge1xuICAgICAgcGxheUV4aXQoKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdXBkYXRlKHsgam91cm5leTogeyAuLi5qciwgaWR4OiBuaSB9IH0pO1xuICAgIGdvU3RlcChqLCBuaSk7XG4gIH0sIFt1cGRhdGUsIGdvU3RlcCwgcGxheUV4aXRdKTtcbiAgLy8gS2VlcCB0aGUgZHdlbGwgdGltZXIncyBpbmRpcmVjdGlvbiBwb2ludGVkIGF0IHRoZSBjdXJyZW50IHBsYXlOZXh0LlxuICBwbGF5TmV4dFJlZi5jdXJyZW50ID0gcGxheU5leHQ7XG5cbiAgY29uc3QgcGxheVByZXYgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgY29uc3QganIgPSBzdGF0ZVJlZi5jdXJyZW50LmpvdXJuZXk7XG4gICAgaWYgKCFqcikgcmV0dXJuO1xuICAgIGlmIChob2xkVGltZXIuY3VycmVudCkge1xuICAgICAgY2xlYXJUaW1lb3V0KGhvbGRUaW1lci5jdXJyZW50KTtcbiAgICAgIGhvbGRUaW1lci5jdXJyZW50ID0gbnVsbDtcbiAgICB9XG4gICAgY29uc3QgaiA9IHN0YXRlUmVmLmN1cnJlbnQuam91cm5leXMuZmluZCgoeCkgPT4geC5pZCA9PT0ganIuamlkKTtcbiAgICBpZiAoIWopIHJldHVybjtcbiAgICBjb25zdCBuaSA9IE1hdGgubWF4KDAsIGpyLmlkeCAtIDEpO1xuICAgIHVwZGF0ZSh7IGpvdXJuZXk6IHsgLi4uanIsIGlkeDogbmkgfSB9KTtcbiAgICBnb1N0ZXAoaiwgbmkpO1xuICB9LCBbdXBkYXRlLCBnb1N0ZXBdKTtcblxuICBjb25zdCBwbGF5U2VlayA9IHVzZUNhbGxiYWNrKFxuICAgIChpZHg6IG51bWJlcikgPT4ge1xuICAgICAgY29uc3QganIgPSBzdGF0ZVJlZi5jdXJyZW50LmpvdXJuZXk7XG4gICAgICBpZiAoIWpyKSByZXR1cm47XG4gICAgICBpZiAoaG9sZFRpbWVyLmN1cnJlbnQpIHtcbiAgICAgICAgY2xlYXJUaW1lb3V0KGhvbGRUaW1lci5jdXJyZW50KTtcbiAgICAgICAgaG9sZFRpbWVyLmN1cnJlbnQgPSBudWxsO1xuICAgICAgfVxuICAgICAgY29uc3QgaiA9IHN0YXRlUmVmLmN1cnJlbnQuam91cm5leXMuZmluZCgoeCkgPT4geC5pZCA9PT0ganIuamlkKTtcbiAgICAgIGlmICghaikgcmV0dXJuO1xuICAgICAgdXBkYXRlKHsgam91cm5leTogeyAuLi5qciwgaWR4IH0gfSk7XG4gICAgICBnb1N0ZXAoaiwgaWR4KTtcbiAgICB9LFxuICAgIFt1cGRhdGUsIGdvU3RlcF0sXG4gICk7XG5cbiAgLy8gLS0tLSBtdXRhdGlvbnMgLS0tLVxuICBjb25zdCBwYXRjaFNlbCA9IHVzZUNhbGxiYWNrKFxuICAgIChwYXRjaDogUGFydGlhbDxXT2JqZWN0PikgPT4ge1xuICAgICAgdXBkYXRlKChzKSA9PiAoeyBvYmplY3RzOiBzLm9iamVjdHMubWFwKChvKSA9PiAocy5zZWxlY3Rpb24uaW5jbHVkZXMoby5pZCkgPyB7IC4uLm8sIC4uLnBhdGNoIH0gOiBvKSkgfSkpO1xuICAgICAgc2NoZWR1bGVTYXZlKHN0YXRlUmVmLmN1cnJlbnQuc2VsZWN0aW9uKTtcbiAgICB9LFxuICAgIFt1cGRhdGUsIHNjaGVkdWxlU2F2ZV0sXG4gICk7XG5cbiAgLy8gLS0tLSBzZWxlY3Rpb246IG9uZSBhY3Rpb24gZm9yIHBvaW50ZXIgYW5kIGtleWJvYXJkIChSMy02MDcpIC0tLS1cbiAgY29uc3Qgc2VsZWN0ID0gdXNlQ2FsbGJhY2soXG4gICAgKGlkOiBzdHJpbmcsIGFkZGl0aXZlID0gZmFsc2UpID0+IHtcbiAgICAgIHVwZGF0ZSgocykgPT4gKHtcbiAgICAgICAgc2VsZWN0aW9uOiBhcHBseVNlbGVjdGlvbihzLnNlbGVjdGlvbiwgaWQsIGFkZGl0aXZlKSxcbiAgICAgICAgaW5zcGVjdG9yT3BlbjogdHJ1ZSxcbiAgICAgICAgcXVpY2tNZW51OiBudWxsLFxuICAgICAgfSkpO1xuICAgIH0sXG4gICAgW3VwZGF0ZV0sXG4gICk7XG5cbiAgLyoqIENsb3NlIHRoZSBxdWljay1jcmVhdGUgbWVudSAoaXRzIEVzY2FwZS9ibHVyIHBhdGgsIFIzLTYwNykuICovXG4gIGNvbnN0IGNsb3NlUXVpY2tNZW51ID0gdXNlQ2FsbGJhY2soKCkgPT4gdXBkYXRlKHsgcXVpY2tNZW51OiBudWxsIH0pLCBbdXBkYXRlXSk7XG5cbiAgY29uc3QgZGVsZXRlU2VsZWN0aW9uID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIGNvbnN0IHNlbCA9IHN0YXRlUmVmLmN1cnJlbnQuc2VsZWN0aW9uLnNsaWNlKCk7XG4gICAgaWYgKCFzZWwubGVuZ3RoKSByZXR1cm47XG4gICAgY29uc3QgcmVtb3ZlZCA9IHN0YXRlUmVmLmN1cnJlbnQub2JqZWN0cy5maWx0ZXIoKG8pID0+IHNlbC5pbmNsdWRlcyhvLmlkKSk7XG4gICAgdXBkYXRlKChzKSA9PiAoeyBvYmplY3RzOiBzLm9iamVjdHMuZmlsdGVyKChvKSA9PiAhc2VsLmluY2x1ZGVzKG8uaWQpKSwgc2VsZWN0aW9uOiBbXSB9KSk7XG4gICAgLy8gRGVsZXRlIGlzIGEgcmVuYW1lIGludG8gb2JqZWN0cy8udHJhc2gvIHdpdGggYSAxMHMgdW5kbyAoc3BlYyDCpzQuMikuXG4gICAgY29uc3QgdCA9IGJvYXJkUmVmLmN1cnJlbnQ7XG4gICAgaWYgKHQgJiYgdC5tb2RlICE9PSAncm8nKSB7XG4gICAgICBQcm9taXNlLmFsbChzZWwubWFwKChpZCkgPT4gdHJhc2hPYmplY3QodCwgaWQpKSkuY2F0Y2goKGUpID0+XG4gICAgICAgIHRvYXN0KGBEZWxldGUgZmFpbGVkJHtjb2RlT2YoZSl9YCwgJ2FsZXJ0JywgeyBpY29uQ29sb3I6ICcjY2FhMjRhJyB9KSxcbiAgICAgICk7XG4gICAgfVxuICAgIHRvYXN0KGAke3NlbC5sZW5ndGggPiAxID8gYCR7c2VsLmxlbmd0aH0gb2JqZWN0c2AgOiAnT2JqZWN0J30gbW92ZWQgdG8gLnRyYXNoYCwgJ3RyYXNoJywge1xuICAgICAgYWN0aW9uTGFiZWw6ICdVbmRvJyxcbiAgICAgIG9uQWN0aW9uOiAoKSA9PiB7XG4gICAgICAgIHVwZGF0ZSgocykgPT4gKHsgb2JqZWN0czogcy5vYmplY3RzLmNvbmNhdChyZW1vdmVkKSB9KSk7XG4gICAgICAgIGlmICh0ICYmIHQubW9kZSAhPT0gJ3JvJykge1xuICAgICAgICAgIFByb21pc2UuYWxsKHJlbW92ZWQubWFwKChvKSA9PiByZXN0b3JlT2JqZWN0KHQsIG8uaWQpKSkuY2F0Y2goKCkgPT4gdW5kZWZpbmVkKTtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICB9KTtcbiAgfSwgW3VwZGF0ZSwgdG9hc3RdKTtcblxuICBjb25zdCBjcmVhdGVPYmplY3QgPSB1c2VDYWxsYmFjayhcbiAgICAoa2luZDogT2JqZWN0S2luZCwgd3g6IG51bWJlciwgd3k6IG51bWJlcikgPT4ge1xuICAgICAgY29uc3QgbzogV09iamVjdCA9IHtcbiAgICAgICAgaWQ6IGdlbmVyYXRlSWQoa2luZCA9PT0gJ25vdGUnID8gJ25vdGUnIDoga2luZCksXG4gICAgICAgIGtpbmQsXG4gICAgICAgIHg6IHd4IC0gMTAwLFxuICAgICAgICB5OiB3eSAtIDc0LFxuICAgICAgICB3OiAyMDAsXG4gICAgICAgIGg6IDE0OCxcbiAgICAgICAgcm90OiAwLFxuICAgICAgICBzY2FsZTogMSxcbiAgICAgICAgejogMyxcbiAgICAgICAgY29ubmVjdGlvbnM6IFtdLFxuICAgICAgfTtcbiAgICAgIGlmIChraW5kID09PSAnbm90ZScpIHtcbiAgICAgICAgby5jb2xvciA9ICdsZW1vbic7XG4gICAgICAgIG8udGl0bGUgPSAnTmV3IG5vdGUnO1xuICAgICAgfSBlbHNlIGlmIChraW5kID09PSAncHJvc2UnKSB7XG4gICAgICAgIG8udGl0bGUgPSAnUHJvc2UnO1xuICAgICAgICBvLmJvZHkgPSAnV3JpdGUgaGVyZeKApic7XG4gICAgICAgIG8udyA9IDI2MDtcbiAgICAgICAgby5oID0gMTYwO1xuICAgICAgfSBlbHNlIGlmIChraW5kID09PSAnbGFiZWwnKSB7XG4gICAgICAgIG8udGl0bGUgPSAnTGFiZWwnO1xuICAgICAgICBvLncgPSAzMjA7XG4gICAgICAgIG8uaCA9IDgwO1xuICAgICAgICBvLnogPSAxO1xuICAgICAgfSBlbHNlIGlmIChraW5kID09PSAnc2hhcGUnKSB7XG4gICAgICAgIG8uc2hhcGUgPSAncmVjdCc7XG4gICAgICAgIG8udGl0bGUgPSAnJztcbiAgICAgICAgby53ID0gMjAwO1xuICAgICAgICBvLmggPSAxNDA7XG4gICAgICB9IGVsc2UgaWYgKGtpbmQgPT09ICdmcmFtZScpIHtcbiAgICAgICAgby50aXRsZSA9ICdGcmFtZSc7XG4gICAgICAgIG8udyA9IDM2MDtcbiAgICAgICAgby5oID0gMzAwO1xuICAgICAgICBvLnogPSAxO1xuICAgICAgfSBlbHNlIGlmIChraW5kID09PSAnaW1nJykge1xuICAgICAgICBvLmxvYWRlZCA9IGZhbHNlO1xuICAgICAgICBvLnRpdGxlID0gJ0ltYWdlJztcbiAgICAgIH0gZWxzZSBpZiAoa2luZCA9PT0gJ2NvbXBvbmVudCcpIHtcbiAgICAgICAgby50aXRsZSA9ICc8Q29tcG9uZW50Lz4nO1xuICAgICAgfVxuICAgICAgdXBkYXRlKChzKSA9PiAoe1xuICAgICAgICBvYmplY3RzOiBzLm9iamVjdHMuY29uY2F0KG8pLFxuICAgICAgICBzZWxlY3Rpb246IFtvLmlkXSxcbiAgICAgICAgcXVpY2tNZW51OiBudWxsLFxuICAgICAgICBpbnNwZWN0b3JPcGVuOiB0cnVlLFxuICAgICAgICBtb2RlOiAnZWRpdCcsXG4gICAgICB9KSk7XG4gICAgICBjb21taXRTYXZlKFtvXSwgYENyZWF0ZWQgb2JqZWN0cy8ke28uaWR9Lm1keGAsICdwbHVzJyk7XG4gICAgfSxcbiAgICBbdXBkYXRlLCBjb21taXRTYXZlXSxcbiAgKTtcblxuICAvLyDilIDilIAgcGljay1maWxlIGZsb3dzIChzcGVjIMKnNi4xIE9wZW4vTmV3IGJvYXJkLCDCpzQuMiBJbnNlcnQgaW1hZ2UpIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAvLyBFYWNoIGludm9rZXMgdGhlIHBsYXRmb3JtIHBpY2tlciBvdmVyIGEgYGNhcERpcmAgb2YgdGhlIGJvYXJkJ3Mgc3BhY2UgKHRoZVxuICAvLyBvbmx5IGF1dGhvcml0eSB3ZSBob2xkKSwgdGhlbiBtYXBzIHRoZSByZXR1cm5lZCBgKHJvb3QsIHJlbFBhdGgpYCBQQVRIIGJhY2tcbiAgLy8gb250byBvdXIgT1dOIG1vdW50IOKAlCByZS12YWxpZGF0aW5nIGl0IGZpcnN0IChkZWZlbnNlIGluIGRlcHRoLCDCpzEuMykuXG5cbiAgLyoqIEluc2VydCBhbiBpbWFnZTogcGljayBhIGZpbGUsIGNvcHkgaXQgaW50byB0aGUgYm9hcmQncyBgYXNzZXRzL2AsIGRyb3AgYW5cbiAgICogIDxJbWc+IG9iamVjdCBhdCB0aGUgd29ybGQgcG9pbnQuIFNlbGYtY29udGFpbmVkIHBlciDCpzQuMi4gVGhlIHBpY2sgaXNcbiAgICogIG5hbWVkLWJ1c3kgb24gdGhlIGNvbmZpcm1pbmcgY29udHJvbCB1bnRpbCBpdCBzZXR0bGVzIChSLUlYLTIpLiAqL1xuICBjb25zdCBpbnNlcnRJbWFnZSA9IHVzZUNhbGxiYWNrKFxuICAgIGFzeW5jICh3eDogbnVtYmVyLCB3eTogbnVtYmVyKSA9PiB7XG4gICAgICBjb25zdCB0YXJnZXQgPSBib2FyZFJlZi5jdXJyZW50O1xuICAgICAgaWYgKCF0YXJnZXQpIHtcbiAgICAgICAgdG9hc3QoJ1NpZ24gaW4gdG8gaW5zZXJ0IGltYWdlcyBpbnRvIHlvdXIgYm9hcmQuJywgJ3NhdmUnLCB7IGljb25Db2xvcjogJ3ZhcigtLWluay0yKScgfSk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIHVwZGF0ZSh7IGJ1c3k6ICdpbnNlcnQtaW1hZ2UnIH0pO1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgcGlja0ZpbGUoe1xuICAgICAgICAgIG1vZGU6ICdvcGVuLWZpbGUnLFxuICAgICAgICAgIHJvb3RzOiBbYXdhaXQgYm9hcmRTcGFjZVJvb3QodGFyZ2V0KV0sXG4gICAgICAgICAgcm9vdExhYmVsczogWydUaGlzIGJvYXJk4oCZcyBzcGFjZSddLFxuICAgICAgICAgIHJvb3RNb2RlczogW3RhcmdldC5tb2RlXSxcbiAgICAgICAgICB0aXRsZTogJ0luc2VydCBpbWFnZScsXG4gICAgICAgICAgZmlsdGVyczogW1xuICAgICAgICAgICAgeyBsYWJlbDogJ0ltYWdlcycsIGV4dGVuc2lvbnM6IFsnLnBuZycsICcuanBnJywgJy5qcGVnJywgJy5naWYnLCAnLndlYnAnLCAnLnN2ZycsICcuYXZpZiddIH0sXG4gICAgICAgICAgICB7IGxhYmVsOiAnQWxsIGZpbGVzJywgZXh0ZW5zaW9uczogW10gfSxcbiAgICAgICAgICBdLFxuICAgICAgICB9KTtcbiAgICAgICAgaWYgKCFyZXMpIHJldHVybjsgLy8gY2FuY2VsbGVkIOKAlCBubyB0b2FzdCBzcGFtXG4gICAgICAgIGNvbnN0IHJlbCA9IHNhZmVSZWwocmVzLnJlbFBhdGgpO1xuICAgICAgICBpZiAoIXJlbCkge1xuICAgICAgICAgIHRvYXN0KCdUaGF0IGZpbGUgY2Fu4oCZdCBiZSBpbnNlcnRlZC4nLCAnYWxlcnQnLCB7IGljb25Db2xvcjogJyNjYWEyNGEnIH0pO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBuYW1lID0gYXdhaXQgY29weUludG9Bc3NldHModGFyZ2V0LCByZWwpO1xuICAgICAgICBjb25zdCBvOiBXT2JqZWN0ID0ge1xuICAgICAgICAgIGlkOiBnZW5lcmF0ZUlkKCdpbWcnKSxcbiAgICAgICAgICBraW5kOiAnaW1nJyxcbiAgICAgICAgICB4OiB3eCAtIDEzMCxcbiAgICAgICAgICB5OiB3eSAtIDkwLFxuICAgICAgICAgIHc6IDI2MCxcbiAgICAgICAgICBoOiAxODAsXG4gICAgICAgICAgcm90OiAwLFxuICAgICAgICAgIHNjYWxlOiAxLFxuICAgICAgICAgIHo6IDMsXG4gICAgICAgICAgdGl0bGU6IG5hbWUsXG4gICAgICAgICAgYm9keTogYDxJbWcgc3JjPVwiYXNzZXRzLyR7bmFtZX1cIiAvPmAsXG4gICAgICAgICAgbG9hZGVkOiB0cnVlLFxuICAgICAgICAgIGNvbm5lY3Rpb25zOiBbXSxcbiAgICAgICAgfTtcbiAgICAgICAgdXBkYXRlKChzKSA9PiAoe1xuICAgICAgICAgIG9iamVjdHM6IHMub2JqZWN0cy5jb25jYXQobyksXG4gICAgICAgICAgc2VsZWN0aW9uOiBbby5pZF0sXG4gICAgICAgICAgcXVpY2tNZW51OiBudWxsLFxuICAgICAgICAgIGluc3BlY3Rvck9wZW46IHRydWUsXG4gICAgICAgICAgbW9kZTogJ2VkaXQnLFxuICAgICAgICAgIHNjcmVlbjogbnVsbCxcbiAgICAgICAgfSkpO1xuICAgICAgICBjb21taXRTYXZlKFtvXSwgYEluc2VydGVkIGFzc2V0cy8ke25hbWV9YCwgJ2ltYWdlJyk7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIHRvYXN0KGBDb3VsZG7igJl0IGluc2VydCBpbWFnZSR7Y29kZU9mKGUpfWAsICdhbGVydCcsIHsgaWNvbkNvbG9yOiAnI2NhYTI0YScgfSk7XG4gICAgICB9IGZpbmFsbHkge1xuICAgICAgICB1cGRhdGUoeyBidXN5OiBudWxsIH0pO1xuICAgICAgfVxuICAgIH0sXG4gICAgW3RvYXN0LCB1cGRhdGUsIGNvbW1pdFNhdmVdLFxuICApO1xuXG4gIC8qKiBSZS1wb2ludCB0aGUgYWN0aXZlIGJvYXJkIHRvIGB0YXJnZXRgIGFuZCBoeWRyYXRlIHRoZSBjYW52YXMgZnJvbSBpdC4gKi9cbiAgY29uc3QgbG9hZEJvYXJkSW50byA9IHVzZUNhbGxiYWNrKFxuICAgIGFzeW5jICh0YXJnZXQ6IEJvYXJkVGFyZ2V0KSA9PiB7XG4gICAgICBjb25zdCBib2FyZCA9IGF3YWl0IGxvYWRCb2FyZCh0YXJnZXQpO1xuICAgICAgYm9hcmRSZWYuY3VycmVudCA9IHRhcmdldDtcbiAgICAgIC8vIFRoZSBib2FyZC5tZCBtYW5pZmVzdCBuYW1lcyB0aGUgYm9hcmQgKHNwZWMgwqcyLjQpIOKAlCBhIGJvYXJkIGlzIGEgZm9sZGVyXG4gICAgICAvLyB0aGF0IGNhbiBzdGF0ZSBpdHMgb3duIG5hbWU7IGZhbGwgYmFjayB0byB0aGUgc2VlZCBvbmx5IHdoZW4gYWJzZW50LlxuICAgICAgLy8gQSBtYW5pZmVzdCBzY2hlbWEgbmV3ZXIgdGhhbiB0aGlzIHJlYWRlciBtYXJrcyB0aGUgYm9hcmQgcmVhZG9ubHkgKHRoZVxuICAgICAgLy8gYHJlYWRvbmx5YCBkZWdyYWRlZCBzdGF0ZSksIHVubGVzcyB0aGUgbW91bnQgaXRzZWxmIGlzIGFscmVhZHkgcm8uXG4gICAgICBjb25zdCByZWFkb25seSA9IHRhcmdldC5tb2RlID09PSAncm8nIHx8ICh0eXBlb2YgYm9hcmQuc2NoZW1hID09PSAnbnVtYmVyJyAmJiBib2FyZC5zY2hlbWEgPiBTVVBQT1JURURfU0NIRU1BKTtcbiAgICAgIHVwZGF0ZSh7XG4gICAgICAgIG9iamVjdHM6IGJvYXJkLm9iamVjdHMsXG4gICAgICAgIHZpZXdzOiBib2FyZC52aWV3cy5sZW5ndGggPyBib2FyZC52aWV3cyA6IFNFRURfVklFV1Muc2xpY2UoKSxcbiAgICAgICAgam91cm5leXM6IGJvYXJkLmpvdXJuZXlzLmxlbmd0aCA/IGJvYXJkLmpvdXJuZXlzIDogU0VFRF9KT1VSTkVZUyxcbiAgICAgICAgYmc6IGJvYXJkLmJhY2tncm91bmQgPz8gc3RhdGVSZWYuY3VycmVudC5iZyxcbiAgICAgICAgdGl0bGU6IGJvYXJkLnRpdGxlID8/IHN0YXRlUmVmLmN1cnJlbnQudGl0bGUsXG4gICAgICAgIG1vZGU6IHJlYWRvbmx5ID8gJ3J1bicgOiBzdGF0ZVJlZi5jdXJyZW50Lm1vZGUsXG4gICAgICAgIHNlbGVjdGlvbjogW10sXG4gICAgICAgIC8vIEEga2V5Ym9hcmQgY29ubmVjdCBhcm1lZCBhZ2FpbnN0IHRoZSBwcmV2aW91cyBib2FyZCBtdXN0IG5vdCBzdXJ2aXZlXG4gICAgICAgIC8vIHRoZSBzd2FwIChSMy02MDcgcmV2aWV3KTogaXRzIHNvdXJjZSBpZCBpcyBzdGFsZSB0aGUgbW9tZW50IG9iamVjdHNcbiAgICAgICAgLy8gYXJlIHJlcGxhY2VkLlxuICAgICAgICBjb25uZWN0RnJvbTogbnVsbCxcbiAgICAgICAgY29ubmVjdEN1cnNvcjogbnVsbCxcbiAgICAgICAgaW5zcGVjdG9yT3BlbjogZmFsc2UsXG4gICAgICAgIHNjcmVlbjogbnVsbCxcbiAgICAgIH0pO1xuICAgIH0sXG4gICAgW3VwZGF0ZV0sXG4gICk7XG5cbiAgLyoqIE9wZW4gYW4gZXhpc3RpbmcgYm9hcmQgZm9sZGVyIGluIGBzcGFjZWA6IHBpY2sgYSBmb2xkZXIsIHJlcXVpcmUgYSBib2FyZC5tZCxcbiAgICogIHRoZW4gbG9hZCBpdCBhcyB0aGUgYWN0aXZlIGJvYXJkLiBOYW1lZC1idXN5IHdoaWxlIHRoZSBwaWNrIGlzIG91dC4gKi9cbiAgY29uc3Qgb3BlbkJvYXJkSW4gPSB1c2VDYWxsYmFjayhcbiAgICBhc3luYyAoc3BhY2U6IEJvYXJkVGFyZ2V0KSA9PiB7XG4gICAgICB1cGRhdGUoeyBidXN5OiAnb3Blbi1ib2FyZCcgfSk7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBwaWNrRmlsZSh7XG4gICAgICAgICAgbW9kZTogJ29wZW4tZm9sZGVyJyxcbiAgICAgICAgICByb290czogW2F3YWl0IGJvYXJkU3BhY2VSb290KHNwYWNlKV0sXG4gICAgICAgICAgcm9vdExhYmVsczogWydZb3VyIGJvYXJkIHNwYWNlJ10sXG4gICAgICAgICAgcm9vdE1vZGVzOiBbc3BhY2UubW9kZV0sXG4gICAgICAgICAgdGl0bGU6ICdPcGVuIGJvYXJkJyxcbiAgICAgICAgfSk7XG4gICAgICAgIGlmICghcmVzKSByZXR1cm47XG4gICAgICAgIGNvbnN0IHJlbCA9IHNhZmVSZWwocmVzLnJlbFBhdGgpO1xuICAgICAgICBpZiAoIXJlbCkge1xuICAgICAgICAgIHRvYXN0KCdUaGF0IGZvbGRlciBjYW7igJl0IGJlIG9wZW5lZC4nLCAnYWxlcnQnLCB7IGljb25Db2xvcjogJyNjYWEyNGEnIH0pO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBjYW5kaWRhdGU6IEJvYXJkVGFyZ2V0ID0geyByb290OiBzdWJQYXRoKHNwYWNlLnJvb3QsIHJlbCksIG1vZGU6IHNwYWNlLm1vZGUsIHNwYWNlSWQ6IHNwYWNlLnNwYWNlSWQgfTtcbiAgICAgICAgaWYgKCEoYXdhaXQgZm9sZGVySXNCb2FyZChjYW5kaWRhdGUpKSAmJiAhKGF3YWl0IGJvYXJkRXhpc3RzKGNhbmRpZGF0ZSkpKSB7XG4gICAgICAgICAgdG9hc3QoJ1RoYXQgZm9sZGVyIGlzbuKAmXQgYSBib2FyZCAobm8gYm9hcmQubWQpLiBPcGVuIGZvbGRlciBhZ2FpbiB0byBwaWNrIGFub3RoZXIuJywgJ2FsZXJ0Jywge1xuICAgICAgICAgICAgaWNvbkNvbG9yOiAnI2NhYTI0YScsXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGF3YWl0IGxvYWRCb2FyZEludG8oY2FuZGlkYXRlKTtcbiAgICAgICAgdG9hc3QoJ0JvYXJkIG9wZW5lZC4nLCAnY2hlY2snKTtcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgdG9hc3QoYENvdWxkbuKAmXQgb3BlbiBib2FyZCR7Y29kZU9mKGUpfWAsICdhbGVydCcsIHsgaWNvbkNvbG9yOiAnI2NhYTI0YScgfSk7XG4gICAgICB9IGZpbmFsbHkge1xuICAgICAgICB1cGRhdGUoeyBidXN5OiBudWxsIH0pO1xuICAgICAgfVxuICAgIH0sXG4gICAgW3RvYXN0LCB1cGRhdGUsIGxvYWRCb2FyZEludG9dLFxuICApO1xuXG4gIC8qKiBPcGVuIGEgU1BFQ0lGSUMgYm9hcmQgZGlyZWN0b3J5IGRpcmVjdGx5ICh0aGUgY2hvb3NlcidzIHJvd3MsIFIzLTYwNyk6XG4gICAqICBubyBwaWNrZXIg4oCUIHRoZSBjYWxsZXIgYWxyZWFkeSBrbm93cyB0aGUgZm9sZGVyIChpdCBsaXN0ZWQgaXQpLiBMb2Fkc1xuICAgKiAgdGhyb3VnaCB0aGUgc2FtZSBgbG9hZEJvYXJkSW50b2AgZXZlcnkgb3BlbiBwYXRoIGZ1bm5lbHMgaW50by4gKi9cbiAgY29uc3Qgb3BlbkJvYXJkQXQgPSB1c2VDYWxsYmFjayhcbiAgICBhc3luYyAodGFyZ2V0OiBCb2FyZFRhcmdldCkgPT4ge1xuICAgICAgdXBkYXRlKHsgYnVzeTogJ29wZW4tYm9hcmQnIH0pO1xuICAgICAgdHJ5IHtcbiAgICAgICAgYXdhaXQgbG9hZEJvYXJkSW50byh0YXJnZXQpO1xuICAgICAgICB0b2FzdCgnQm9hcmQgb3BlbmVkLicsICdjaGVjaycpO1xuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICB0b2FzdChgQ291bGRu4oCZdCBvcGVuIGJvYXJkJHtjb2RlT2YoZSl9YCwgJ2FsZXJ0JywgeyBpY29uQ29sb3I6ICcjY2FhMjRhJyB9KTtcbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIHVwZGF0ZSh7IGJ1c3k6IG51bGwgfSk7XG4gICAgICB9XG4gICAgfSxcbiAgICBbdG9hc3QsIHVwZGF0ZSwgbG9hZEJvYXJkSW50b10sXG4gICk7XG5cbiAgLyoqIE5ldyBib2FyZDogcGljayAob3IgY3JlYXRlKSBhIGZvbGRlciBpbiBgc3BhY2VgLCBzY2FmZm9sZCBib2FyZC5tZCwgb3BlbiBpdC5cbiAgICogIE5hbWVkLWJ1c3kgd2hpbGUgdGhlIHBpY2sgaXMgb3V0LiAqL1xuICBjb25zdCBuZXdCb2FyZEluID0gdXNlQ2FsbGJhY2soXG4gICAgYXN5bmMgKHNwYWNlOiBCb2FyZFRhcmdldCkgPT4ge1xuICAgICAgaWYgKHNwYWNlLm1vZGUgPT09ICdybycpIHtcbiAgICAgICAgdG9hc3QoJ1RoYXQgc3BhY2UgaXMgcmVhZC1vbmx5IOKAlCB5b3UgY2Fu4oCZdCBjcmVhdGUgYSBib2FyZCB0aGVyZS4nLCAnbG9jaycsIHsgaWNvbkNvbG9yOiAndmFyKC0taW5rLTIpJyB9KTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgdXBkYXRlKHsgYnVzeTogJ25ldy1ib2FyZCcgfSk7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBwaWNrRmlsZSh7XG4gICAgICAgICAgbW9kZTogJ29wZW4tZm9sZGVyJyxcbiAgICAgICAgICByb290czogW2F3YWl0IGJvYXJkU3BhY2VSb290KHNwYWNlKV0sXG4gICAgICAgICAgcm9vdExhYmVsczogWydZb3VyIGJvYXJkIHNwYWNlJ10sXG4gICAgICAgICAgcm9vdE1vZGVzOiBbc3BhY2UubW9kZV0sXG4gICAgICAgICAgdGl0bGU6ICdOZXcgYm9hcmQgwrcgY2hvb3NlIGEgZm9sZGVyJyxcbiAgICAgICAgICBhbGxvd0NyZWF0ZUZvbGRlcjogdHJ1ZSxcbiAgICAgICAgfSk7XG4gICAgICAgIGlmICghcmVzKSByZXR1cm47XG4gICAgICAgIGNvbnN0IHJlbCA9IHNhZmVSZWwocmVzLnJlbFBhdGgpO1xuICAgICAgICBpZiAoIXJlbCkge1xuICAgICAgICAgIHRvYXN0KCdUaGF0IGZvbGRlciBjYW7igJl0IGJlIHVzZWQuJywgJ2FsZXJ0JywgeyBpY29uQ29sb3I6ICcjY2FhMjRhJyB9KTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgY2FuZGlkYXRlOiBCb2FyZFRhcmdldCA9IHsgcm9vdDogc3ViUGF0aChzcGFjZS5yb290LCByZWwpLCBtb2RlOiAncncnLCBzcGFjZUlkOiBzcGFjZS5zcGFjZUlkIH07XG4gICAgICAgIGNvbnN0IHRpdGxlID0gcmVsLnNwbGl0KCcvJykucG9wKCkgfHwgJ1VudGl0bGVkIGJvYXJkJztcbiAgICAgICAgYXdhaXQgd3JpdGVOZXdCb2FyZChjYW5kaWRhdGUsIHRpdGxlKTtcbiAgICAgICAgYXdhaXQgbG9hZEJvYXJkSW50byhjYW5kaWRhdGUpO1xuICAgICAgICB0b2FzdCgnQm9hcmQgY3JlYXRlZC4nLCAnY2hlY2snKTtcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgdG9hc3QoYENvdWxkbuKAmXQgY3JlYXRlIGJvYXJkJHtjb2RlT2YoZSl9YCwgJ2FsZXJ0JywgeyBpY29uQ29sb3I6ICcjY2FhMjRhJyB9KTtcbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIHVwZGF0ZSh7IGJ1c3k6IG51bGwgfSk7XG4gICAgICB9XG4gICAgfSxcbiAgICBbdG9hc3QsIHVwZGF0ZSwgbG9hZEJvYXJkSW50b10sXG4gICk7XG5cbiAgLyoqIE9wZW4gLyBuZXcgYm9hcmQgYWdhaW5zdCB0aGUgQ1VSUkVOVCBib2FyZCBzcGFjZSAodGhlIGNob29zZXIncyBmb290ZXIpLiAqL1xuICBjb25zdCBvcGVuQm9hcmQgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgY29uc3Qgc3BhY2UgPSBib2FyZFJlZi5jdXJyZW50O1xuICAgIGlmICghc3BhY2UpIHtcbiAgICAgIHRvYXN0KCdTaWduIGluIHRvIG9wZW4gYSBib2FyZCBmcm9tIHlvdXIgc3BhY2UuJywgJ3NhdmUnLCB7IGljb25Db2xvcjogJ3ZhcigtLWluay0yKScgfSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHZvaWQgb3BlbkJvYXJkSW4oc3BhY2UpO1xuICB9LCBbdG9hc3QsIG9wZW5Cb2FyZEluXSk7XG5cbiAgY29uc3QgbmV3Qm9hcmQgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgY29uc3Qgc3BhY2UgPSBib2FyZFJlZi5jdXJyZW50O1xuICAgIGlmICghc3BhY2UpIHtcbiAgICAgIHRvYXN0KCdTaWduIGluIHRvIGNyZWF0ZSBhIGJvYXJkIGluIHlvdXIgc3BhY2UuJywgJ3NhdmUnLCB7IGljb25Db2xvcjogJ3ZhcigtLWluay0yKScgfSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHZvaWQgbmV3Qm9hcmRJbihzcGFjZSk7XG4gIH0sIFt0b2FzdCwgbmV3Qm9hcmRJbl0pO1xuXG4gIC8qKiBcIkFkZCBhIHNwYWNlXCI6IHRoZSBob3N0IHBvd2VyYm94IGdyYW50cyBhIE5FVyBzcGFjZSAobmV2ZXIgdGhpcyBhcHAsIMKnMiksXG4gICAqICB0aGVuIHdlIG9mZmVyIHRvIG9wZW4gYSBib2FyZCBpbiBpdC4gKi9cbiAgY29uc3QgYWRkU3BhY2UgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGdyYW50ZWQgPSBhd2FpdCByZXF1ZXN0U3BhY2UoKTtcbiAgICAgIGlmICghZ3JhbnRlZCkgcmV0dXJuOyAvLyBjYW5jZWxsZWRcbiAgICAgIGNvbnN0IHNwYWNlOiBCb2FyZFRhcmdldCA9IHsgcm9vdDogZ3JhbnRlZC5wYXRoLCBtb2RlOiBncmFudGVkLm1vZGUsIHNwYWNlSWQ6IGdyYW50ZWQuaWQgfTtcbiAgICAgIGF3YWl0IG9wZW5Cb2FyZEluKHNwYWNlKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICB0b2FzdChgQ291bGRu4oCZdCBhZGQgYSBzcGFjZSR7Y29kZU9mKGUpfWAsICdhbGVydCcsIHsgaWNvbkNvbG9yOiAnI2NhYTI0YScgfSk7XG4gICAgfVxuICB9LCBbdG9hc3QsIG9wZW5Cb2FyZEluXSk7XG5cbiAgY29uc3QgcGF0Y2hPYmplY3QgPSB1c2VDYWxsYmFjayhcbiAgICAoaWQ6IHN0cmluZywgcGF0Y2g6IFBhcnRpYWw8V09iamVjdD4pID0+IHtcbiAgICAgIHVwZGF0ZSgocykgPT4gKHsgb2JqZWN0czogcy5vYmplY3RzLm1hcCgobykgPT4gKG8uaWQgPT09IGlkID8geyAuLi5vLCAuLi5wYXRjaCB9IDogbykpIH0pKTtcbiAgICAgIHNjaGVkdWxlU2F2ZShbaWRdKTtcbiAgICB9LFxuICAgIFt1cGRhdGUsIHNjaGVkdWxlU2F2ZV0sXG4gICk7XG5cbiAgY29uc3QgYWRkQ29ubmVjdGlvbiA9IHVzZUNhbGxiYWNrKFxuICAgIChmcm9tOiBzdHJpbmcsIHRvOiBzdHJpbmcpID0+IHtcbiAgICAgIGNvbnN0IGM6IENvbm5lY3Rpb24gPSB7IHRvLCBraW5kOiAnYXJyb3cnLCBzdHlsZTogeyBzdHJva2U6ICdhY2NlbnQnLCBkYXNoOiBmYWxzZSB9IH07XG4gICAgICBjb25zdCBzcmMgPSBzdGF0ZVJlZi5jdXJyZW50Lm9iamVjdHMuZmluZCgobykgPT4gby5pZCA9PT0gZnJvbSk7XG4gICAgICBjb25zdCB1cGRhdGVkID0gc3JjID8geyAuLi5zcmMsIGNvbm5lY3Rpb25zOiBzcmMuY29ubmVjdGlvbnMuY29uY2F0KGMpIH0gOiBudWxsO1xuICAgICAgdXBkYXRlKChzKSA9PiAoeyBvYmplY3RzOiBzLm9iamVjdHMubWFwKChvKSA9PiAoby5pZCA9PT0gZnJvbSA/IHsgLi4ubywgY29ubmVjdGlvbnM6IG8uY29ubmVjdGlvbnMuY29uY2F0KGMpIH0gOiBvKSkgfSkpO1xuICAgICAgaWYgKHVwZGF0ZWQpIGNvbW1pdFNhdmUoW3VwZGF0ZWRdLCBgQ29ubmVjdGVkICR7ZnJvbX0g4oaSICR7dG99YCk7XG4gICAgfSxcbiAgICBbdXBkYXRlLCBjb21taXRTYXZlXSxcbiAgKTtcblxuICAvLyAtLS0tIGtleWJvYXJkIGNvbm5lY3QgKHRoZSBub24tZHJhZyBwYXRoIHRvIGFuIGVkZ2UsIFIzLTYwNyAvIDIuNS43KSAtLS0tXG4gIC8qKiBFbnRlciBjb25uZWN0LWZyb20gb24gdGhlIHNlbGVjdGVkIG9iamVjdDsgdGhlIGN1cnNvciBzdGFydHMgb24gdGhlIGZpcnN0XG4gICAqICBvdGhlciBvYmplY3QgaW4gc3RhY2tpbmcgb3JkZXIuIEFycm93cyB0aGVuIHdhbGsgdGhlIGN1cnNvciAodGhlIG92ZXJsYXlcbiAgICogIGRyYXdzIGl0KSwgRW50ZXIgY29tbWl0cyB0aHJvdWdoIHRoZSBzYW1lIGFkZENvbm5lY3Rpb24gdGhlIGRyYWcgY2FsbHMsXG4gICAqICBFc2NhcGUgY2FuY2Vscy4gKi9cbiAgY29uc3QgYmVnaW5Db25uZWN0ID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIGNvbnN0IHMgPSBzdGF0ZVJlZi5jdXJyZW50O1xuICAgIGlmIChzLnNlbGVjdGlvbi5sZW5ndGggIT09IDEpIHJldHVybjtcbiAgICBjb25zdCBmcm9tID0gcy5zZWxlY3Rpb25bMF07XG4gICAgY29uc3Qgb3JkZXIgPSBzLm9iamVjdHMuc2xpY2UoKS5zb3J0KChhLCBiKSA9PiAoYS56IHx8IDApIC0gKGIueiB8fCAwKSkubWFwKChvKSA9PiBvLmlkKS5maWx0ZXIoKGlkKSA9PiBpZCAhPT0gZnJvbSk7XG4gICAgdXBkYXRlKHsgY29ubmVjdEZyb206IGZyb20sIGNvbm5lY3RDdXJzb3I6IG9yZGVyWzBdID8/IG51bGwsIGluc3BlY3Rvck9wZW46IGZhbHNlIH0pO1xuICB9LCBbdXBkYXRlXSk7XG5cbiAgY29uc3QgZW5kQ29ubmVjdCA9IHVzZUNhbGxiYWNrKFxuICAgIChjb21taXQ6IGJvb2xlYW4pID0+IHtcbiAgICAgIGNvbnN0IHMgPSBzdGF0ZVJlZi5jdXJyZW50O1xuICAgICAgaWYgKCFzLmNvbm5lY3RGcm9tKSByZXR1cm47XG4gICAgICBpZiAoY29tbWl0ICYmIHMuY29ubmVjdEN1cnNvcikgYWRkQ29ubmVjdGlvbihzLmNvbm5lY3RGcm9tLCBzLmNvbm5lY3RDdXJzb3IpO1xuICAgICAgdXBkYXRlKHsgY29ubmVjdEZyb206IG51bGwsIGNvbm5lY3RDdXJzb3I6IG51bGwgfSk7XG4gICAgfSxcbiAgICBbdXBkYXRlLCBhZGRDb25uZWN0aW9uXSxcbiAgKTtcblxuICBjb25zdCBtb3ZlQ29ubmVjdEN1cnNvciA9IHVzZUNhbGxiYWNrKFxuICAgIChkaXI6IC0xIHwgMSkgPT4ge1xuICAgICAgdXBkYXRlKChzKSA9PiB7XG4gICAgICAgIGlmICghcy5jb25uZWN0RnJvbSkgcmV0dXJuIHt9O1xuICAgICAgICBjb25zdCBvcmRlciA9IHMub2JqZWN0cy5zbGljZSgpLnNvcnQoKGEsIGIpID0+IChhLnogfHwgMCkgLSAoYi56IHx8IDApKS5tYXAoKG8pID0+IG8uaWQpLmZpbHRlcigoaWQpID0+IGlkICE9PSBzLmNvbm5lY3RGcm9tKTtcbiAgICAgICAgaWYgKCFvcmRlci5sZW5ndGgpIHJldHVybiB7fTtcbiAgICAgICAgY29uc3QgaWR4ID0gb3JkZXIuaW5kZXhPZihzLmNvbm5lY3RDdXJzb3IgPz8gb3JkZXJbMF0pO1xuICAgICAgICByZXR1cm4geyBjb25uZWN0Q3Vyc29yOiBvcmRlclsoaWR4ICsgZGlyICsgb3JkZXIubGVuZ3RoKSAlIG9yZGVyLmxlbmd0aF0gfTtcbiAgICAgIH0pO1xuICAgIH0sXG4gICAgW3VwZGF0ZV0sXG4gICk7XG5cbiAgLy8gLS0tLSBwb2ludGVyIGdlc3R1cmVzIC0tLS1cbiAgY29uc3Qgb25DYW52YXNEb3duID0gdXNlQ2FsbGJhY2soXG4gICAgKGU6IFJlYWN0LlBvaW50ZXJFdmVudCkgPT4ge1xuICAgICAgY29uc3QgcyA9IHN0YXRlUmVmLmN1cnJlbnQ7XG4gICAgICBpZiAocy5xdWlja01lbnUpIHVwZGF0ZSh7IHF1aWNrTWVudTogbnVsbCB9KTtcbiAgICAgIGlmIChzLmRlbW9NZW51T3BlbikgdXBkYXRlKHsgZGVtb01lbnVPcGVuOiBmYWxzZSB9KTtcbiAgICAgIGNvbnN0IG1pZCA9IGUuYnV0dG9uID09PSAxO1xuICAgICAgaWYgKHMubW9kZSA9PT0gJ2VkaXQnICYmICFzcGFjZVJlZi5jdXJyZW50ICYmICFtaWQgJiYgIWlzTW9iaWxlKCkpIHtcbiAgICAgICAgY29uc3QgW2x4LCBseV0gPSBsb2NhbFBvaW50KGUpO1xuICAgICAgICBpZiAoIWUuc2hpZnRLZXkpIHVwZGF0ZSh7IHNlbGVjdGlvbjogW10gfSk7XG4gICAgICAgIGRyYWdSZWYuY3VycmVudCA9IHsgdHlwZTogJ21hcnF1ZWUnLCBzeDogbHgsIHN5OiBseSwgYWRkOiBlLnNoaWZ0S2V5LCBiYXNlOiBzLnNlbGVjdGlvbi5zbGljZSgpIH07XG4gICAgICAgIHVwZGF0ZSh7IG1hcnF1ZWU6IHsgeDogbHgsIHk6IGx5LCB3OiAwLCBoOiAwIH0gfSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBkcmFnUmVmLmN1cnJlbnQgPSB7IHR5cGU6ICdwYW4nLCBzeDogZS5jbGllbnRYLCBzeTogZS5jbGllbnRZLCBjeDogcy5jYW0uY3gsIGN5OiBzLmNhbS5jeSB9O1xuICAgICAgICB1cGRhdGUoeyBwYW5uaW5nOiB0cnVlIH0pO1xuICAgICAgfVxuICAgIH0sXG4gICAgW3VwZGF0ZSwgaXNNb2JpbGUsIGxvY2FsUG9pbnRdLFxuICApO1xuXG4gIGNvbnN0IG9ialBvaW50ZXJEb3duID0gdXNlQ2FsbGJhY2soXG4gICAgKGlkOiBzdHJpbmcsIGU6IFJlYWN0LlBvaW50ZXJFdmVudCkgPT4ge1xuICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgIGNvbnN0IHMgPSBzdGF0ZVJlZi5jdXJyZW50O1xuICAgICAgaWYgKHMubW9kZSAhPT0gJ2VkaXQnKSB7XG4gICAgICAgIGRyYWdSZWYuY3VycmVudCA9IHsgdHlwZTogJ3BhbicsIHN4OiBlLmNsaWVudFgsIHN5OiBlLmNsaWVudFksIGN4OiBzLmNhbS5jeCwgY3k6IHMuY2FtLmN5IH07XG4gICAgICAgIHVwZGF0ZSh7IHBhbm5pbmc6IHRydWUgfSk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IG8gPSBzLm9iamVjdHMuZmluZCgoeCkgPT4geC5pZCA9PT0gaWQpO1xuICAgICAgaWYgKCFvKSByZXR1cm47XG4gICAgICAvLyBPbmUgc3BlbGxpbmcgb2Ygc2VsZWN0aW9uIGZvciBwb2ludGVyIGFuZCBrZXlib2FyZCBhbGlrZSAoUjMtNjA3KS5cbiAgICAgIGNvbnN0IHNlbCA9IGFwcGx5U2VsZWN0aW9uKHMuc2VsZWN0aW9uLCBpZCwgZS5zaGlmdEtleSk7XG4gICAgICB1cGRhdGUoeyBzZWxlY3Rpb246IHNlbCwgaW5zcGVjdG9yT3BlbjogdHJ1ZSwgcXVpY2tNZW51OiBudWxsIH0pO1xuICAgICAgaWYgKG8ubG9ja2VkKSByZXR1cm47XG4gICAgICBjb25zdCBvcmlnOiBSZWNvcmQ8c3RyaW5nLCB7IHg6IG51bWJlcjsgeTogbnVtYmVyIH0+ID0ge307XG4gICAgICBzLm9iamVjdHMuZm9yRWFjaCgoeCkgPT4ge1xuICAgICAgICBpZiAoc2VsLmluY2x1ZGVzKHguaWQpKSBvcmlnW3guaWRdID0geyB4OiB4LngsIHk6IHgueSB9O1xuICAgICAgfSk7XG4gICAgICBkcmFnUmVmLmN1cnJlbnQgPSB7IHR5cGU6ICdtb3ZlJywgc3g6IGUuY2xpZW50WCwgc3k6IGUuY2xpZW50WSwgaWRzOiBzZWwsIG9yaWcsIG1vdmVkOiBmYWxzZSB9O1xuICAgIH0sXG4gICAgW3VwZGF0ZV0sXG4gICk7XG5cbiAgY29uc3Qgc3RhcnRIYW5kbGUgPSB1c2VDYWxsYmFjaygoa2luZDogJ3Jlc2l6ZScgfCAncm90YXRlJywgaGFuZGxlOiBzdHJpbmcsIGU6IFJlYWN0LlBvaW50ZXJFdmVudCkgPT4ge1xuICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgY29uc3QgcyA9IHN0YXRlUmVmLmN1cnJlbnQ7XG4gICAgY29uc3QgaWQgPSBzLnNlbGVjdGlvblswXTtcbiAgICBjb25zdCBvID0gcy5vYmplY3RzLmZpbmQoKHgpID0+IHguaWQgPT09IGlkKTtcbiAgICBpZiAoIW8pIHJldHVybjtcbiAgICBjb25zdCBiYXNlID0geyB4OiBvLngsIHk6IG8ueSwgdzogby53LCBoOiBvLmgsIHJvdDogby5yb3QgfTtcbiAgICBkcmFnUmVmLmN1cnJlbnQgPVxuICAgICAga2luZCA9PT0gJ3JvdGF0ZSdcbiAgICAgICAgPyB7IHR5cGU6ICdyb3RhdGUnLCBzeDogZS5jbGllbnRYLCBzeTogZS5jbGllbnRZLCBvOiBiYXNlLCBpZCwgbW92ZWQ6IGZhbHNlIH1cbiAgICAgICAgOiB7IHR5cGU6ICdyZXNpemUnLCBraW5kOiBoYW5kbGUsIHN4OiBlLmNsaWVudFgsIHN5OiBlLmNsaWVudFksIG86IGJhc2UsIGlkLCBtb3ZlZDogZmFsc2UgfTtcbiAgfSwgW10pO1xuXG4gIGNvbnN0IHN0YXJ0Q29ubmVjdCA9IHVzZUNhbGxiYWNrKFxuICAgIChpZDogc3RyaW5nLCBzaWRlOiBzdHJpbmcsIGU6IFJlYWN0LlBvaW50ZXJFdmVudCkgPT4ge1xuICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgIGRyYWdSZWYuY3VycmVudCA9IHsgdHlwZTogJ2Nvbm5lY3QnLCBmcm9tOiBpZCwgc2lkZSwgbW92ZWQ6IGZhbHNlIH07XG4gICAgICBjb25zdCBbbHgsIGx5XSA9IGxvY2FsUG9pbnQoZSk7XG4gICAgICB1cGRhdGUoeyBjb25uZWN0UHJldmlldzogeyBmcm9tOiBpZCwgeDogbHgsIHk6IGx5LCB0YXJnZXQ6IG51bGwgfSB9KTtcbiAgICB9LFxuICAgIFt1cGRhdGUsIGxvY2FsUG9pbnRdLFxuICApO1xuXG4gIGNvbnN0IHNldEhvdmVyID0gdXNlQ2FsbGJhY2soKGlkOiBzdHJpbmcgfCBudWxsKSA9PiB1cGRhdGUoeyBob3ZlcjogaWQgfSksIFt1cGRhdGVdKTtcbiAgY29uc3QgY2xlYXJTZWxlY3Rpb24gPSB1c2VDYWxsYmFjaygoKSA9PiB1cGRhdGUoeyBzZWxlY3Rpb246IFtdIH0pLCBbdXBkYXRlXSk7XG5cbiAgLy8gLS0tLSBtb2RlIC8gdmlldyBjb250cm9scyAtLS0tXG4gIGNvbnN0IHNldFJ1biA9IHVzZUNhbGxiYWNrKFxuICAgIC8vIExlYXZpbmcgZWRpdCBkaXNhcm1zIGEga2V5Ym9hcmQgY29ubmVjdCB0b28gKGl0cyBjdXJzb3IgbGl2ZXMgb24gdGhlXG4gICAgLy8gZWRpdCBzdXJmYWNlKSDigJQgY29ubmVjdEZyb20gc3Vydml2aW5nIGludG8gcnVuIG1vZGUgd291bGQgb3duIHRoZVxuICAgIC8vIGFycm93cyBvZiBhIG1vZGUgdGhhdCBoYXMgbm8gc2VsZWN0aW9uIChSMy02MDcgcmV2aWV3KS5cbiAgICAoKSA9PiB1cGRhdGUoeyBtb2RlOiAncnVuJywgc2VsZWN0aW9uOiBbXSwgaW5zcGVjdG9yT3BlbjogZmFsc2UsIHF1aWNrTWVudTogbnVsbCwgY29ubmVjdFByZXZpZXc6IG51bGwsIGNvbm5lY3RGcm9tOiBudWxsLCBjb25uZWN0Q3Vyc29yOiBudWxsIH0pLFxuICAgIFt1cGRhdGVdLFxuICApO1xuICBjb25zdCBzZXRFZGl0ID0gdXNlQ2FsbGJhY2soKCkgPT4gdXBkYXRlKHsgbW9kZTogJ2VkaXQnIH0pLCBbdXBkYXRlXSk7XG4gIGNvbnN0IHRvZ2dsZVRoZW1lID0gdXNlQ2FsbGJhY2soKCkgPT4gdXBkYXRlKChzKSA9PiAoeyBsaWdodDogIXMubGlnaHQgfSkpLCBbdXBkYXRlXSk7XG4gIGNvbnN0IHRvZ2dsZVBhbmVsID0gdXNlQ2FsbGJhY2soKCkgPT4gdXBkYXRlKChzKSA9PiAoeyBwYW5lbE9wZW46ICFzLnBhbmVsT3BlbiB9KSksIFt1cGRhdGVdKTtcbiAgY29uc3Qgc2V0U2NyZWVuID0gdXNlQ2FsbGJhY2soKHNjcmVlbjogU2NyZWVuS2luZCkgPT4gdXBkYXRlKHsgc2NyZWVuIH0pLCBbdXBkYXRlXSk7XG4gIGNvbnN0IHNldEJhY2tncm91bmQgPSB1c2VDYWxsYmFjaygoYmc6IEJhY2tncm91bmQpID0+IHVwZGF0ZSh7IGJnIH0pLCBbdXBkYXRlXSk7XG4gIGNvbnN0IHNldExpZ2h0ID0gdXNlQ2FsbGJhY2soKGxpZ2h0OiBib29sZWFuKSA9PiB1cGRhdGUoeyBsaWdodCB9KSwgW3VwZGF0ZV0pO1xuICBjb25zdCBjbG9zZUluc3BlY3RvciA9IHVzZUNhbGxiYWNrKCgpID0+IHVwZGF0ZSh7IGluc3BlY3Rvck9wZW46IGZhbHNlIH0pLCBbdXBkYXRlXSk7XG4gIGNvbnN0IGNsb3NlUGFuZWwgPSB1c2VDYWxsYmFjaygoKSA9PiB1cGRhdGUoeyBwYW5lbE9wZW46IGZhbHNlIH0pLCBbdXBkYXRlXSk7XG4gIGNvbnN0IHRvZ2dsZURlbW9NZW51ID0gdXNlQ2FsbGJhY2soKCkgPT4gdXBkYXRlKChzKSA9PiAoeyBkZW1vTWVudU9wZW46ICFzLmRlbW9NZW51T3BlbiB9KSksIFt1cGRhdGVdKTtcblxuICBjb25zdCBvbkNhbnZhc0RibENsaWNrID0gdXNlQ2FsbGJhY2soXG4gICAgKGU6IFJlYWN0Lk1vdXNlRXZlbnQpID0+IHtcbiAgICAgIGlmIChzdGF0ZVJlZi5jdXJyZW50Lm1vZGUgIT09ICdlZGl0JykgcmV0dXJuO1xuICAgICAgY29uc3QgW2x4LCBseV0gPSBsb2NhbFBvaW50KGUpO1xuICAgICAgY29uc3QgW3d4LCB3eV0gPSB3b3JsZEF0KHN0YXRlUmVmLmN1cnJlbnQuY2FtLCBzdGF0ZVJlZi5jdXJyZW50LnZwLCBseCwgbHkpO1xuICAgICAgdXBkYXRlKHsgcXVpY2tNZW51OiB7IGx4LCBseSwgd3gsIHd5IH0gfSk7XG4gICAgfSxcbiAgICBbdXBkYXRlLCBsb2NhbFBvaW50XSxcbiAgKTtcblxuICAvLyAtLS0tIGRlbW8gc2NlbmFyaW9zICh0aGUgZGVzaWduJ3MgXCJkZW1vIHN0YXRlc1wiIG1lbnUpIC0tLS1cbiAgY29uc3QgZGVtb0xXVyA9IHVzZUNhbGxiYWNrKCgpID0+IHtcbiAgICB0b2FzdCgnTm90ZSB3YXMgY2hhbmdlZCBieSBAZGFuYSB3aGlsZSB5b3UgZWRpdGVkIOKAlCB0aGVpciB2ZXJzaW9uIGtlcHQuJywgJ2FsZXJ0Jywge1xuICAgICAgaWNvbkNvbG9yOiAnI2NhYTI0YScsXG4gICAgICBhY3Rpb25MYWJlbDogJ0tlZXAgbWluZScsXG4gICAgICBvbkFjdGlvbjogKCkgPT4gdG9hc3QoJ1lvdXIgdmVyc2lvbiByZXN0b3JlZCcsICdjaGVjaycpLFxuICAgIH0pO1xuICB9LCBbdG9hc3RdKTtcblxuICBjb25zdCBkZW1vRG93bmdyYWRlID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIHVwZGF0ZSh7IG1vZGU6ICdydW4nLCBzZWxlY3Rpb246IFtdLCBpbnNwZWN0b3JPcGVuOiBmYWxzZSB9KTtcbiAgICB0b2FzdCgnWW91ciBhY2Nlc3MgY2hhbmdlZCB0byByZWFkLW9ubHkuIEVkaXQgbW9kZSBjbG9zZWQuJywgJ2xvY2snLCB7IGljb25Db2xvcjogJ3ZhcigtLWluay0yKScgfSk7XG4gIH0sIFt1cGRhdGUsIHRvYXN0XSk7XG5cbiAgLy8gLS0tLSBlZmZlY3RzOiBtZWFzdXJlbWVudCArIGdsb2JhbCBsaXN0ZW5lcnMgLS0tLVxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5zZXRBdHRyaWJ1dGUoJ2RhdGEtdGhlbWUnLCBzdGF0ZS5saWdodCA/ICdsaWdodCcgOiAnZGFyaycpO1xuICB9LCBbc3RhdGUubGlnaHRdKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IGVsID0gY2FudmFzRWw7XG4gICAgaWYgKCFlbCkgcmV0dXJuO1xuXG4gICAgY29uc3QgbWVhc3VyZSA9ICgpID0+IHtcbiAgICAgIGNvbnN0IHIgPSBlbC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICAgIHVwZGF0ZSh7IHZwOiB7IHZ3OiByLndpZHRoLCB2aDogci5oZWlnaHQsIHZsZWZ0OiByLmxlZnQsIHZ0b3A6IHIudG9wIH0gfSk7XG4gICAgfTtcbiAgICBtZWFzdXJlKCk7XG4gICAgY29uc3Qgcm8gPSBuZXcgUmVzaXplT2JzZXJ2ZXIobWVhc3VyZSk7XG4gICAgcm8ub2JzZXJ2ZShlbCk7XG5cbiAgICBjb25zdCBvbldoZWVsID0gKGU6IFdoZWVsRXZlbnQpID0+IHtcbiAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgIGNvbnN0IFtseCwgbHldID0gbG9jYWxQb2ludChlKTtcbiAgICAgIGlmIChlLmN0cmxLZXkgfHwgZS5tZXRhS2V5KSB7XG4gICAgICAgIGNvbnN0IGYgPSBNYXRoLmV4cCgtZS5kZWx0YVkgKiAwLjAxKTtcbiAgICAgICAgc2V0Wm9vbShzdGF0ZVJlZi5jdXJyZW50LmNhbS56b29tICogZiwgbHgsIGx5KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHVwZGF0ZSgocykgPT4gKHsgY2FtOiB7IGN4OiBzLmNhbS5jeCArIGUuZGVsdGFYIC8gcy5jYW0uem9vbSwgY3k6IHMuY2FtLmN5ICsgZS5kZWx0YVkgLyBzLmNhbS56b29tLCB6b29tOiBzLmNhbS56b29tIH0gfSkpO1xuICAgICAgfVxuICAgIH07XG4gICAgZWwuYWRkRXZlbnRMaXN0ZW5lcignd2hlZWwnLCBvbldoZWVsLCB7IHBhc3NpdmU6IGZhbHNlIH0pO1xuXG4gICAgY29uc3Qgb25Nb3ZlID0gKGU6IFBvaW50ZXJFdmVudCkgPT4ge1xuICAgICAgY29uc3QgZCA9IGRyYWdSZWYuY3VycmVudDtcbiAgICAgIGlmICghZCkgcmV0dXJuO1xuICAgICAgY29uc3QgeiA9IHN0YXRlUmVmLmN1cnJlbnQuY2FtLnpvb207XG4gICAgICBpZiAoZC50eXBlID09PSAncGFuJykge1xuICAgICAgICBjb25zdCBkeCA9IGUuY2xpZW50WCAtIGQuc3g7XG4gICAgICAgIGNvbnN0IGR5ID0gZS5jbGllbnRZIC0gZC5zeTtcbiAgICAgICAgdXBkYXRlKHsgY2FtOiB7IGN4OiBkLmN4IC0gZHggLyB6LCBjeTogZC5jeSAtIGR5IC8geiwgem9vbTogeiB9IH0pO1xuICAgICAgfSBlbHNlIGlmIChkLnR5cGUgPT09ICdtb3ZlJykge1xuICAgICAgICBjb25zdCBkeCA9IChlLmNsaWVudFggLSBkLnN4KSAvIHo7XG4gICAgICAgIGNvbnN0IGR5ID0gKGUuY2xpZW50WSAtIGQuc3kpIC8gejtcbiAgICAgICAgZC5tb3ZlZCA9IHRydWU7XG4gICAgICAgIHVwZGF0ZSgocykgPT4gKHtcbiAgICAgICAgICBvYmplY3RzOiBzLm9iamVjdHMubWFwKChvKSA9PlxuICAgICAgICAgICAgZC5pZHMuaW5jbHVkZXMoby5pZCkgJiYgZC5vcmlnW28uaWRdID8geyAuLi5vLCB4OiBkLm9yaWdbby5pZF0ueCArIGR4LCB5OiBkLm9yaWdbby5pZF0ueSArIGR5IH0gOiBvLFxuICAgICAgICAgICksXG4gICAgICAgIH0pKTtcbiAgICAgIH0gZWxzZSBpZiAoZC50eXBlID09PSAnbWFycXVlZScpIHtcbiAgICAgICAgY29uc3QgW2x4LCBseV0gPSBsb2NhbFBvaW50KGUpO1xuICAgICAgICBjb25zdCB4ID0gTWF0aC5taW4obHgsIGQuc3gpO1xuICAgICAgICBjb25zdCB5ID0gTWF0aC5taW4obHksIGQuc3kpO1xuICAgICAgICBjb25zdCB3ID0gTWF0aC5hYnMobHggLSBkLnN4KTtcbiAgICAgICAgY29uc3QgaGggPSBNYXRoLmFicyhseSAtIGQuc3kpO1xuICAgICAgICBjb25zdCBzID0gc3RhdGVSZWYuY3VycmVudDtcbiAgICAgICAgY29uc3Qgc2VsID0gb2JqZWN0c0luUmVjdChzLm9iamVjdHMsIHMuY2FtLCBzLnZwLCB4LCB5LCB3LCBoaCk7XG4gICAgICAgIHVwZGF0ZSh7IG1hcnF1ZWU6IHsgeCwgeSwgdywgaDogaGggfSwgc2VsZWN0aW9uOiBkLmFkZCA/IEFycmF5LmZyb20obmV3IFNldChkLmJhc2UuY29uY2F0KHNlbCkpKSA6IHNlbCB9KTtcbiAgICAgIH0gZWxzZSBpZiAoZC50eXBlID09PSAnY29ubmVjdCcpIHtcbiAgICAgICAgY29uc3QgW2x4LCBseV0gPSBsb2NhbFBvaW50KGUpO1xuICAgICAgICBjb25zdCBzID0gc3RhdGVSZWYuY3VycmVudDtcbiAgICAgICAgY29uc3QgdGd0ID0gb2JqZWN0QXRMb2NhbChzLm9iamVjdHMsIHMuY2FtLCBzLnZwLCBseCwgbHksIGQuZnJvbSk7XG4gICAgICAgIHVwZGF0ZSh7IGNvbm5lY3RQcmV2aWV3OiB7IGZyb206IGQuZnJvbSwgeDogbHgsIHk6IGx5LCB0YXJnZXQ6IHRndCB9IH0pO1xuICAgICAgfSBlbHNlIGlmIChkLnR5cGUgPT09ICdyZXNpemUnIHx8IGQudHlwZSA9PT0gJ3JvdGF0ZScpIHtcbiAgICAgICAgYXBwbHlIYW5kbGUoZCwgZSk7XG4gICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGFwcGx5SGFuZGxlID0gKGQ6IEV4dHJhY3Q8RHJhZywgeyB0eXBlOiAncmVzaXplJyB8ICdyb3RhdGUnIH0+LCBlOiBQb2ludGVyRXZlbnQpID0+IHtcbiAgICAgIGNvbnN0IHMgPSBzdGF0ZVJlZi5jdXJyZW50O1xuICAgICAgY29uc3QgeiA9IHMuY2FtLnpvb207XG4gICAgICBjb25zdCBkeCA9IChlLmNsaWVudFggLSBkLnN4KSAvIHo7XG4gICAgICBjb25zdCBkeSA9IChlLmNsaWVudFkgLSBkLnN5KSAvIHo7XG4gICAgICBkLm1vdmVkID0gdHJ1ZTtcbiAgICAgIHVwZGF0ZSgoc3QpID0+ICh7XG4gICAgICAgIG9iamVjdHM6IHN0Lm9iamVjdHMubWFwKChvKSA9PiB7XG4gICAgICAgICAgaWYgKG8uaWQgIT09IGQuaWQpIHJldHVybiBvO1xuICAgICAgICAgIGlmIChkLnR5cGUgPT09ICdyb3RhdGUnKSB7XG4gICAgICAgICAgICBjb25zdCBjeCA9IGQuby54ICsgZC5vLncgLyAyO1xuICAgICAgICAgICAgY29uc3QgY3kgPSBkLm8ueSArIGQuby5oIC8gMjtcbiAgICAgICAgICAgIGNvbnN0IFtseCwgbHldID0gbG9jYWxQb2ludChlKTtcbiAgICAgICAgICAgIGNvbnN0IFt3eCwgd3ldID0gd29ybGRBdChzLmNhbSwgcy52cCwgbHgsIGx5KTtcbiAgICAgICAgICAgIGxldCBhbmcgPSAoTWF0aC5hdGFuMih3eSAtIGN5LCB3eCAtIGN4KSAqIDE4MCkgLyBNYXRoLlBJICsgOTA7XG4gICAgICAgICAgICBpZiAoZS5zaGlmdEtleSkgYW5nID0gTWF0aC5yb3VuZChhbmcgLyAxNSkgKiAxNTtcbiAgICAgICAgICAgIHJldHVybiB7IC4uLm8sIHJvdDogTWF0aC5yb3VuZChhbmcpIH07XG4gICAgICAgICAgfVxuICAgICAgICAgIGxldCB4ID0gZC5vLng7XG4gICAgICAgICAgbGV0IHkgPSBkLm8ueTtcbiAgICAgICAgICBsZXQgdyA9IGQuby53O1xuICAgICAgICAgIGxldCBoaCA9IGQuby5oO1xuICAgICAgICAgIGNvbnN0IGsgPSBkLmtpbmQ7XG4gICAgICAgICAgaWYgKGsuaW5jbHVkZXMoJ2UnKSkgdyA9IE1hdGgubWF4KDYwLCBkLm8udyArIGR4KTtcbiAgICAgICAgICBpZiAoay5pbmNsdWRlcygncycpKSBoaCA9IE1hdGgubWF4KDQ4LCBkLm8uaCArIGR5KTtcbiAgICAgICAgICBpZiAoay5pbmNsdWRlcygndycpKSB7XG4gICAgICAgICAgICB3ID0gTWF0aC5tYXgoNjAsIGQuby53IC0gZHgpO1xuICAgICAgICAgICAgeCA9IGQuby54ICsgKGQuby53IC0gdyk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChrLmluY2x1ZGVzKCduJykpIHtcbiAgICAgICAgICAgIGhoID0gTWF0aC5tYXgoNDgsIGQuby5oIC0gZHkpO1xuICAgICAgICAgICAgeSA9IGQuby55ICsgKGQuby5oIC0gaGgpO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4geyAuLi5vLCB4LCB5LCB3LCBoOiBoaCB9O1xuICAgICAgICB9KSxcbiAgICAgIH0pKTtcbiAgICB9O1xuXG4gICAgY29uc3Qgb25VcCA9IChlOiBQb2ludGVyRXZlbnQpID0+IHtcbiAgICAgIGNvbnN0IGQgPSBkcmFnUmVmLmN1cnJlbnQ7XG4gICAgICBkcmFnUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgaWYgKCFkKSB7XG4gICAgICAgIGlmIChzdGF0ZVJlZi5jdXJyZW50LnBhbm5pbmcpIHVwZGF0ZSh7IHBhbm5pbmc6IGZhbHNlIH0pO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAoZC50eXBlID09PSAncGFuJykge1xuICAgICAgICB1cGRhdGUoeyBwYW5uaW5nOiBmYWxzZSB9KTtcbiAgICAgIH0gZWxzZSBpZiAoZC50eXBlID09PSAnbW92ZScgJiYgZC5tb3ZlZCkge1xuICAgICAgICBjb25zdCBtb3ZlZCA9IHN0YXRlUmVmLmN1cnJlbnQub2JqZWN0cy5maWx0ZXIoKG8pID0+IGQuaWRzLmluY2x1ZGVzKG8uaWQpKTtcbiAgICAgICAgY29tbWl0U2F2ZShtb3ZlZCwgYE1vdmVkIMK3IHNhdmVkIHRvICR7ZC5pZHMubGVuZ3RoID4gMSA/IGAke2QuaWRzLmxlbmd0aH0gZmlsZXNgIDogYCR7ZC5pZHNbMF19Lm1keGB9YCk7XG4gICAgICB9IGVsc2UgaWYgKGQudHlwZSA9PT0gJ21hcnF1ZWUnKSB7XG4gICAgICAgIHVwZGF0ZSh7IG1hcnF1ZWU6IG51bGwgfSk7XG4gICAgICB9IGVsc2UgaWYgKGQudHlwZSA9PT0gJ2Nvbm5lY3QnKSB7XG4gICAgICAgIGNvbnN0IFtseCwgbHldID0gbG9jYWxQb2ludChlKTtcbiAgICAgICAgY29uc3QgcyA9IHN0YXRlUmVmLmN1cnJlbnQ7XG4gICAgICAgIGNvbnN0IHRndCA9IG9iamVjdEF0TG9jYWwocy5vYmplY3RzLCBzLmNhbSwgcy52cCwgbHgsIGx5LCBkLmZyb20pO1xuICAgICAgICBpZiAodGd0KSBhZGRDb25uZWN0aW9uKGQuZnJvbSwgdGd0KTtcbiAgICAgICAgdXBkYXRlKHsgY29ubmVjdFByZXZpZXc6IG51bGwgfSk7XG4gICAgICB9IGVsc2UgaWYgKChkLnR5cGUgPT09ICdyZXNpemUnIHx8IGQudHlwZSA9PT0gJ3JvdGF0ZScpICYmIGQubW92ZWQpIHtcbiAgICAgICAgY29uc3QgbyA9IHN0YXRlUmVmLmN1cnJlbnQub2JqZWN0cy5maW5kKCh4KSA9PiB4LmlkID09PSBkLmlkKTtcbiAgICAgICAgY29tbWl0U2F2ZShvID8gW29dIDogW10sICdSZXNpemVkIMK3IHNhdmVkJyk7XG4gICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IG9uS2V5RG93biA9IChlOiBLZXlib2FyZEV2ZW50KSA9PiB7XG4gICAgICBjb25zdCB0ID0gZS50YXJnZXQgYXMgSFRNTEVsZW1lbnQgfCBudWxsO1xuICAgICAgaWYgKHQgJiYgKHQudGFnTmFtZSA9PT0gJ0lOUFVUJyB8fCB0LnRhZ05hbWUgPT09ICdURVhUQVJFQScgfHwgdC50YWdOYW1lID09PSAnU0VMRUNUJyB8fCB0LmlzQ29udGVudEVkaXRhYmxlKSkgcmV0dXJuO1xuICAgICAgY29uc3QgcyA9IHN0YXRlUmVmLmN1cnJlbnQ7XG4gICAgICBpZiAocy5qb3VybmV5KSB7XG4gICAgICAgIGlmIChlLmtleSA9PT0gJ0Fycm93UmlnaHQnIHx8IGUua2V5ID09PSAnICcpIHtcbiAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICAgcGxheU5leHQoKTtcbiAgICAgICAgfSBlbHNlIGlmIChlLmtleSA9PT0gJ0Fycm93TGVmdCcpIHtcbiAgICAgICAgICBwbGF5UHJldigpO1xuICAgICAgICB9IGVsc2UgaWYgKGUua2V5ID09PSAnRXNjYXBlJykge1xuICAgICAgICAgIHBsYXlFeGl0KCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgLy8gS2V5Ym9hcmQgY29ubmVjdCBvd25zIHRoZSBhcnJvd3Mgd2hpbGUgaXQgaXMgYXJtZWQgKFIzLTYwNyk6IGFycm93c1xuICAgICAgLy8gd2FsayB0aGUgdGFyZ2V0IGN1cnNvciwgRW50ZXIgY29tbWl0cywgRXNjYXBlIGNhbmNlbHMg4oCUIG5ldmVyIG51ZGdpbmdcbiAgICAgIC8vIG9yIGRlbGV0aW5nIHVuZGVybmVhdGggYSBsaXZlIGNvbm5lY3QuXG4gICAgICBpZiAocy5jb25uZWN0RnJvbSkge1xuICAgICAgICBpZiAoZS5rZXkgPT09ICdBcnJvd0xlZnQnIHx8IGUua2V5ID09PSAnQXJyb3dVcCcpIHtcbiAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICAgbW92ZUNvbm5lY3RDdXJzb3IoLTEpO1xuICAgICAgICB9IGVsc2UgaWYgKGUua2V5ID09PSAnQXJyb3dSaWdodCcgfHwgZS5rZXkgPT09ICdBcnJvd0Rvd24nKSB7XG4gICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgIG1vdmVDb25uZWN0Q3Vyc29yKDEpO1xuICAgICAgICB9IGVsc2UgaWYgKGUua2V5ID09PSAnRW50ZXInKSB7XG4gICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgIGVuZENvbm5lY3QodHJ1ZSk7XG4gICAgICAgIH0gZWxzZSBpZiAoZS5rZXkgPT09ICdFc2NhcGUnKSB7XG4gICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgIGVuZENvbm5lY3QoZmFsc2UpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGlmIChlLmtleSA9PT0gJ0VzY2FwZScpIHVwZGF0ZSh7IHNlbGVjdGlvbjogW10sIHF1aWNrTWVudTogbnVsbCwgc2NyZWVuOiBudWxsIH0pO1xuICAgICAgaWYgKGUua2V5ID09PSAnICcpIHNwYWNlUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgaWYgKHMubW9kZSA9PT0gJ2VkaXQnICYmIHMuc2VsZWN0aW9uLmxlbmd0aCkge1xuICAgICAgICBjb25zdCBzdGVwID0gZS5zaGlmdEtleSA/IDEwIDogMTtcbiAgICAgICAgbGV0IGR4ID0gMDtcbiAgICAgICAgbGV0IGR5ID0gMDtcbiAgICAgICAgaWYgKGUua2V5ID09PSAnQXJyb3dMZWZ0JykgZHggPSAtc3RlcDtcbiAgICAgICAgZWxzZSBpZiAoZS5rZXkgPT09ICdBcnJvd1JpZ2h0JykgZHggPSBzdGVwO1xuICAgICAgICBlbHNlIGlmIChlLmtleSA9PT0gJ0Fycm93VXAnKSBkeSA9IC1zdGVwO1xuICAgICAgICBlbHNlIGlmIChlLmtleSA9PT0gJ0Fycm93RG93bicpIGR5ID0gc3RlcDtcbiAgICAgICAgaWYgKGR4IHx8IGR5KSB7XG4gICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgIGNvbnN0IHNlbCA9IHMuc2VsZWN0aW9uO1xuICAgICAgICAgIHVwZGF0ZSgoc3QpID0+ICh7IG9iamVjdHM6IHN0Lm9iamVjdHMubWFwKChvKSA9PiAoc2VsLmluY2x1ZGVzKG8uaWQpICYmICFvLmxvY2tlZCA/IHsgLi4ubywgeDogby54ICsgZHgsIHk6IG8ueSArIGR5IH0gOiBvKSkgfSkpO1xuICAgICAgICAgIHNjaGVkdWxlU2F2ZShzZWwpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChlLmtleSA9PT0gJ0RlbGV0ZScgfHwgZS5rZXkgPT09ICdCYWNrc3BhY2UnKSBkZWxldGVTZWxlY3Rpb24oKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IG9uS2V5VXAgPSAoZTogS2V5Ym9hcmRFdmVudCkgPT4ge1xuICAgICAgaWYgKGUua2V5ID09PSAnICcpIHNwYWNlUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICB9O1xuXG4gICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcigncG9pbnRlcm1vdmUnLCBvbk1vdmUpO1xuICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ3BvaW50ZXJ1cCcsIG9uVXApO1xuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdrZXlkb3duJywgb25LZXlEb3duKTtcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigna2V5dXAnLCBvbktleVVwKTtcblxuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBlbC5yZW1vdmVFdmVudExpc3RlbmVyKCd3aGVlbCcsIG9uV2hlZWwpO1xuICAgICAgcm8uZGlzY29ubmVjdCgpO1xuICAgICAgZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcigncG9pbnRlcm1vdmUnLCBvbk1vdmUpO1xuICAgICAgZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcigncG9pbnRlcnVwJywgb25VcCk7XG4gICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcigna2V5ZG93bicsIG9uS2V5RG93bik7XG4gICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcigna2V5dXAnLCBvbktleVVwKTtcbiAgICAgIGlmICh0d2VlblJlZi5jdXJyZW50KSBjYW5jZWxBbmltYXRpb25GcmFtZSh0d2VlblJlZi5jdXJyZW50KTtcbiAgICB9O1xuICAgIC8vIFRoZSBsaXN0ZW5lcnMgcmVhZCB0aGUgbGF0ZXN0IHN0YXRlIHZpYSBzdGF0ZVJlZiwgc28gdGhleSBpbnN0YWxsIG9uY2VcbiAgICAvLyB0aGUgY2FudmFzIG1vdW50czsgdGhlIGFjdGlvbiBjYWxsYmFja3MgdGhleSBjbG9zZSBvdmVyIGFyZSBhbGwgc3RhYmxlLlxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9leGhhdXN0aXZlLWRlcHNcbiAgfSwgW2NhbnZhc0VsXSk7XG5cbiAgLyoqXG4gICAqIFByb3ZpZGVyIHNpZGUgb2YgYG9wZW4tcHJvamVjdGAgKFNQQUNFU19VSV9TUEVDIMKnNik6IGdpdmVuIHRoZSBkZWxlZ2F0ZWRcbiAgICogYGNhcERpcmAsIGZpbmQgdGhlIGNocm9vdCB0aGUgaG9zdCBtb3VudGVkIGZvciBpdCwgaHlkcmF0ZSB0aGUgY2FudmFzIGZyb21cbiAgICogaXQsIGFuZCBhcm0gdGhlIGR1cmFibGUtYm9hcmQgbWFjaGluZXJ5IChhdXRvc2F2ZSwgZG93bmdyYWRlIHdhdGNoKSBhZ2FpbnN0XG4gICAqIGl0LiBSZXNvbHZlcyB0cnVlIG9uY2UgdGhlIGJvYXJkIGlzIHNob3duLCBmYWxzZSBpZiB0aGUgZGVsZWdhdGVkIGZvbGRlclxuICAgKiBuZXZlciByZXNvbHZlZCB0byBhIG1vdW50ICh0aGUgY2FsbGVyIHRoZW4gYWJvcnRzIHRoZSB0YXNrKS4gVGhlIGZvbGRlciBpc1xuICAgKiBleHBlY3RlZCB0byBhbHJlYWR5IGJlIGEgYm9hcmQgKHRoZSBtYXJrZXIgb25seSBsaXZlcyBvbiBib2FyZCBmb2xkZXJzKTsgYW5cbiAgICogZW1wdHkgb25lIGlzIHNlZWRlZCBzbyB0aGUgY2FudmFzIHN0aWxsIHJlbmRlcnMuXG4gICAqL1xuICBjb25zdCBvcGVuRGVsZWdhdGVkUHJvamVjdCA9IHVzZUNhbGxiYWNrKFxuICAgIGFzeW5jIChkaXJQYXRoOiBzdHJpbmcpOiBQcm9taXNlPGJvb2xlYW4+ID0+IHtcbiAgICAgIC8vIFRoZSBob3N0IGFubm91bmNlcyB0aGUgdGFzayBjaHJvb3QgYXMgYSBtb3VudCBBVCB0aGUgZGVsZWdhdGVkIHBhdGg7IGl0XG4gICAgICAvLyBtYXkgbm90IGJlIHByZXNlbnQgdGhlIGluc3RhbnQgd2UgcmVhZCB0aGUgaW5wdXQsIHNvIHBvbGwgYnJpZWZseSAoYSBmZXdcbiAgICAgIC8vIGZyYW1lcykgZm9yIHRoZSBtb3VudCB3aG9zZSBgcGF0aGAgbWF0Y2hlcy5cbiAgICAgIGxldCBtb3VudCA9IHJlc29sdmVEZWxlZ2F0ZWRNb3VudChkaXJQYXRoLCBnZXRNb3VudHMoKSk7XG4gICAgICBmb3IgKGxldCB0cmllcyA9IDA7ICFtb3VudCAmJiB0cmllcyA8IDQwOyB0cmllcyArPSAxKSB7XG4gICAgICAgIGF3YWl0IG5ldyBQcm9taXNlKChyKSA9PiBzZXRUaW1lb3V0KHIsIDUwKSk7XG4gICAgICAgIG1vdW50ID0gcmVzb2x2ZURlbGVnYXRlZE1vdW50KGRpclBhdGgsIGdldE1vdW50cygpKTtcbiAgICAgIH1cbiAgICAgIGlmICghbW91bnQpIHtcbiAgICAgICAgdG9hc3QoJ0NvdWxkbuKAmXQgb3BlbiB0aGF0IHByb2plY3Qg4oCUIHRoZSBmb2xkZXIgaXNu4oCZdCBhdmFpbGFibGUuJywgJ2FsZXJ0JywgeyBpY29uQ29sb3I6ICcjY2FhMjRhJyB9KTtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgICAgY29uc3QgdGFyZ2V0ID0gZGlyQ2FwVG9Cb2FyZFRhcmdldChtb3VudCk7XG4gICAgICB0cnkge1xuICAgICAgICBpZiAoYXdhaXQgYm9hcmRFeGlzdHModGFyZ2V0KSkge1xuICAgICAgICAgIGF3YWl0IGxvYWRCb2FyZEludG8odGFyZ2V0KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAvLyBUaGUgbWFya2VyIHNhaWQgdGhpcyBpcyBhIHByb2plY3QgZm9sZGVyIGJ1dCBpdCBoYXMgbm8gb2JqZWN0cyB5ZXQ6XG4gICAgICAgICAgLy8gc2VlZCBpdCBzbyB0aGUgdXNlciBsYW5kcyBvbiBhIHVzYWJsZSBib2FyZCwgbm90IGEgYmxhbmsgY2FudmFzLlxuICAgICAgICAgIGJvYXJkUmVmLmN1cnJlbnQgPSB0YXJnZXQ7XG4gICAgICAgICAgY29uc3QgcyA9IHN0YXRlUmVmLmN1cnJlbnQ7XG4gICAgICAgICAgYXdhaXQgc2VlZEJvYXJkKHRhcmdldCwgeyBvYmplY3RzOiBzLm9iamVjdHMsIHZpZXdzOiBzLnZpZXdzLCBqb3VybmV5czogcy5qb3VybmV5cyB9KTtcbiAgICAgICAgfVxuICAgICAgICB0b2FzdCgnUHJvamVjdCBvcGVuZWQuJywgJ2NoZWNrJyk7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICB0b2FzdChgQ291bGRu4oCZdCBvcGVuIHByb2plY3Qke2NvZGVPZihlKX1gLCAnYWxlcnQnLCB7IGljb25Db2xvcjogJyNjYWEyNGEnIH0pO1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgfSxcbiAgICBbdG9hc3QsIGxvYWRCb2FyZEludG9dLFxuICApO1xuXG4gIC8vIC0tLS0gb3BlbiB0aGUgZHVyYWJsZSBib2FyZCBzcGFjZSwgaHlkcmF0ZSAob3Igc2VlZCksIHdhdGNoIGZvciBkb3duZ3JhZGVzIC0tLS1cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBsZXQgY2FuY2VsbGVkID0gZmFsc2U7XG4gICAgbGV0IHVuc3ViOiAoKCkgPT4gdm9pZCkgfCB1bmRlZmluZWQ7XG4gICAgY29uc3QgdGltZXJzID0gc2F2ZVRpbWVycy5jdXJyZW50O1xuICAgIChhc3luYyAoKSA9PiB7XG4gICAgICAvLyDilIDilIAgb3Blbi1wcm9qZWN0IHByb3ZpZGVyIHBhdGggKFNQQUNFU19VSV9TUEVDIMKnNiwgUGhhc2UgNSkg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gICAgICAvLyBJZiBhIGZpbGUgbWFuYWdlciBsYXVuY2hlZCB1cyB2aWEgdGhlIGBvcGVuLXByb2plY3RgIHRhc2ssIGl0IGhhbmRlZCBhXG4gICAgICAvLyBgY2FwRGlyYCBmb3IgdGhlIHByb2plY3QgZm9sZGVyOyB0aGUgaG9zdCBtb3VudGVkIHRoYXQgZm9sZGVyIGFzIGFcbiAgICAgIC8vIGNocm9vdC4gTG9hZCB0aGUgYm9hcmQgZnJvbSBpdCBhbmQgY29tcGxldGUgdGhlIHRhc2ssIHRoZW4gYXJtIHRoZSBzYW1lXG4gICAgICAvLyBkb3duZ3JhZGUgd2F0Y2ggYmVsb3cgYWdhaW5zdCB0aGUgZGVsZWdhdGVkIG1vdW50LiBBIG5vcm1hbCBsYXVuY2ggKG5vXG4gICAgICAvLyB0YXNrIGlucHV0KSBmYWxscyB0aHJvdWdoIHRvIHRoZSBkdXJhYmxlLWJvYXJkIHBhdGggdW5jaGFuZ2VkLlxuICAgICAgbGV0IGRlbGVnYXRlZCA9IGZhbHNlO1xuICAgICAgY29uc3QgZGlyID0gYXdhaXQgcmVhZE9wZW5Qcm9qZWN0SW5wdXQoKTtcbiAgICAgIGlmIChkaXIpIHtcbiAgICAgICAgY29uc3Qgb3BlbmVkID0gYXdhaXQgb3BlbkRlbGVnYXRlZFByb2plY3QoZGlyKTtcbiAgICAgICAgaWYgKG9wZW5lZCkgYXdhaXQgcmVwb3J0T3BlbmVkKHRydWUpO1xuICAgICAgICBlbHNlIGF3YWl0IGFib3J0T3BlblByb2plY3QoKTtcbiAgICAgICAgaWYgKGNhbmNlbGxlZCkgcmV0dXJuO1xuICAgICAgICAvLyBPbiBzdWNjZXNzIHRoZSBjYW52YXMgaXMgY2hyb290ZWQgYXQgdGhlIHByb2plY3Q7IHNraXAgdGhlIGR1cmFibGVcbiAgICAgICAgLy8gYm9hcmQgc3BhY2UuIE9uIGZhaWx1cmUsIGZhbGwgdGhyb3VnaCB0byB0aGUgaW4tbWVtb3J5IHNlZWQgc28gdGhlXG4gICAgICAgIC8vIGNhbnZhcyBzdGlsbCByZW5kZXJzIHNvbWV0aGluZyByYXRoZXIgdGhhbiBhIGJsYW5rIGFwcC5cbiAgICAgICAgZGVsZWdhdGVkID0gb3BlbmVkO1xuICAgICAgfVxuXG4gICAgICBpZiAoIWRlbGVnYXRlZCkge1xuICAgICAgICBsZXQgdGFyZ2V0OiBCb2FyZFRhcmdldDtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAvLyBBdXRvLW9wZW4gdGhlIHNpZ25lZC1pbiB1c2VyJ3MgYm9hcmQgc3BhY2UuIERlY2xpbmVkIC8gc2lnbmVkLW91dFxuICAgICAgICAgIC8vIHJlamVjdHMgd2l0aCBhIHR5cGVkIFNwYWNlRXJyb3Ig4oCUIHdlIGRlZ3JhZGUgdG8gdGhlIGluLW1lbW9yeSBzZWVkLlxuICAgICAgICAgIHRhcmdldCA9IGF3YWl0IG9wZW5Cb2FyZFRhcmdldCgpO1xuICAgICAgICB9IGNhdGNoIHtcbiAgICAgICAgICBpZiAoIWNhbmNlbGxlZCkgdG9hc3QoJ1dvcmtpbmcgaW4gbWVtb3J5IOKAlCBzaWduIGluIHRvIHNhdmUgeW91ciBib2FyZC4nLCAnc2F2ZScsIHsgaWNvbkNvbG9yOiAndmFyKC0taW5rLTIpJyB9KTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGNhbmNlbGxlZCkgcmV0dXJuO1xuICAgICAgICBib2FyZFJlZi5jdXJyZW50ID0gdGFyZ2V0O1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGlmIChhd2FpdCBib2FyZEV4aXN0cyh0YXJnZXQpKSB7XG4gICAgICAgICAgICBjb25zdCBib2FyZCA9IGF3YWl0IGxvYWRCb2FyZCh0YXJnZXQpO1xuICAgICAgICAgICAgaWYgKCFjYW5jZWxsZWQpIHtcbiAgICAgICAgICAgICAgdXBkYXRlKHtcbiAgICAgICAgICAgICAgICBvYmplY3RzOiBib2FyZC5vYmplY3RzLFxuICAgICAgICAgICAgICAgIHZpZXdzOiBib2FyZC52aWV3cy5sZW5ndGggPyBib2FyZC52aWV3cyA6IFNFRURfVklFV1Muc2xpY2UoKSxcbiAgICAgICAgICAgICAgICBqb3VybmV5czogYm9hcmQuam91cm5leXMubGVuZ3RoID8gYm9hcmQuam91cm5leXMgOiBTRUVEX0pPVVJORVlTLFxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgdG9hc3QoJ0JvYXJkIGxvYWRlZCBmcm9tIHlvdXIgc3BhY2UuJywgJ2NoZWNrJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIC8vIEZpcnN0IHJ1biBvbiBhbiBlbXB0eSBzcGFjZTogcGVyc2lzdCB0aGUgc2VlZCBkZW1vIGFzIHRoZSBzdGFydGluZyBib2FyZC5cbiAgICAgICAgICAgIGNvbnN0IHMgPSBzdGF0ZVJlZi5jdXJyZW50O1xuICAgICAgICAgICAgYXdhaXQgc2VlZEJvYXJkKHRhcmdldCwgeyBvYmplY3RzOiBzLm9iamVjdHMsIHZpZXdzOiBzLnZpZXdzLCBqb3VybmV5czogcy5qb3VybmV5cyB9KTtcbiAgICAgICAgICAgIGlmICghY2FuY2VsbGVkKSB0b2FzdCgnQm9hcmQgY3JlYXRlZCBpbiB5b3VyIHNwYWNlLicsICdjaGVjaycpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgIGlmICghY2FuY2VsbGVkKSB0b2FzdChgQ291bGRuJ3Qgb3BlbiBib2FyZCR7Y29kZU9mKGUpfWAsICdhbGVydCcsIHsgaWNvbkNvbG9yOiAnI2NhYTI0YScgfSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmIChjYW5jZWxsZWQpIHJldHVybjtcbiAgICAgIC8vIE1pcnJvciB0aGUgbGl2ZSBtb3VudHMgaW50byBzdGF0ZSAodGhlIGJvYXJkIGNob29zZXIgbGlzdHMgdGhlc2UsXG4gICAgICAvLyBSMy02MDcpIGFsb25nc2lkZSB0aGUgZG93bmdyYWRlIHdhdGNoIGJlbG93LlxuICAgICAgdHJ5IHtcbiAgICAgICAgdXBkYXRlKHsgbW91bnRzOiBnZXRNb3VudHMoKSB9KTtcbiAgICAgIH0gY2F0Y2gge1xuICAgICAgICAvLyBObyBob3N0IHJ1bnRpbWUgeWV0IOKAlCB0aGUgbGlzdCBzdGF5cyBlbXB0eSBhbmQgdGhlIGNob29zZXIgZGVncmFkZXMuXG4gICAgICB9XG4gICAgICAvLyBBIGxpdmUgcm9sZS1kb3duZ3JhZGUgcmUtYW5ub3VuY2VzIHRoZSBtb3VudCBhcyBgcm9gOyByZW1vdmFsIHRlYXJzIGl0IGRvd24uXG4gICAgICAvLyBUaGUgbW91bnQgc2VydmljZSBuZWVkcyB0aGUgaG9zdCBydW50aW1lLCB3aGljaCBpcyBhYnNlbnQgdW5kZXIgbG9jYWxcbiAgICAgIC8vIGB2aXRlIGRldmAg4oCUIHRoZXJlIHRoZSBib2FyZCBpcyBhIHN0YXRpYyBvbi1kaXNrIGRpciB3aXRoIG5vIHJvbGUgY2hhbmdlcyxcbiAgICAgIC8vIHNvIHNraXAgdGhlIHN1YnNjcmlwdGlvbiByYXRoZXIgdGhhbiBjcmFzaC5cbiAgICAgIHRyeSB7XG4gICAgICAgIHVuc3ViID0gb25Nb3VudHNDaGFuZ2UoKG1vdW50cywgcmVtb3ZlZCkgPT4ge1xuICAgICAgICAgIHVwZGF0ZSh7IG1vdW50cyB9KTtcbiAgICAgICAgICBjb25zdCBjdXIgPSBib2FyZFJlZi5jdXJyZW50O1xuICAgICAgICAgIGlmICghY3VyKSByZXR1cm47XG4gICAgICAgICAgY29uc3QgbSA9IG1vdW50cy5maW5kKCh4KSA9PiAoY3VyLnNwYWNlSWQgPyB4LmlkID09PSBjdXIuc3BhY2VJZCA6IHgucGF0aCA9PT0gY3VyLnJvb3QpKTtcbiAgICAgICAgICBpZiAobSkge1xuICAgICAgICAgICAgY29uc3QgbW9kZSA9IG0ubW9kZSA9PT0gJ3JvJyA/ICdybycgOiAncncnO1xuICAgICAgICAgICAgaWYgKG1vZGUgIT09IGN1ci5tb2RlKSB7XG4gICAgICAgICAgICAgIGJvYXJkUmVmLmN1cnJlbnQgPSB7IC4uLmN1ciwgbW9kZSB9O1xuICAgICAgICAgICAgICBpZiAobW9kZSA9PT0gJ3JvJykge1xuICAgICAgICAgICAgICAgIHVwZGF0ZSh7IG1vZGU6ICdydW4nLCBzZWxlY3Rpb246IFtdLCBpbnNwZWN0b3JPcGVuOiBmYWxzZSB9KTtcbiAgICAgICAgICAgICAgICB0b2FzdCgnWW91ciBhY2Nlc3MgY2hhbmdlZCB0byByZWFkLW9ubHkuJywgJ2xvY2snLCB7IGljb25Db2xvcjogJ3ZhcigtLWluay0yKScgfSk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9IGVsc2UgaWYgKHJlbW92ZWQuc29tZSgocikgPT4gKGN1ci5zcGFjZUlkID8gci5pZCA9PT0gY3VyLnNwYWNlSWQgOiByLnBhdGggPT09IGN1ci5yb290KSkpIHtcbiAgICAgICAgICAgIGJvYXJkUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgICAgICAgdG9hc3QoJ0JvYXJkIHNwYWNlIGRpc2Nvbm5lY3RlZC4nLCAnYWxlcnQnLCB7IGljb25Db2xvcjogJ3ZhcigtLWluay0yKScgfSk7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH0gY2F0Y2gge1xuICAgICAgICAvLyBObyBob3N0IHJ1bnRpbWUgKGxvY2FsIGB2aXRlIGRldmApOiBubyBsaXZlIG1vdW50IHVwZGF0ZXMgdG8gdHJhY2suXG4gICAgICB9XG4gICAgfSkoKTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgY2FuY2VsbGVkID0gdHJ1ZTtcbiAgICAgIHVuc3ViPy4oKTtcbiAgICAgIGZvciAoY29uc3QgaCBvZiB0aW1lcnMudmFsdWVzKCkpIGNsZWFyVGltZW91dChoKTtcbiAgICAgIHRpbWVycy5jbGVhcigpO1xuICAgICAgaWYgKGhvbGRUaW1lci5jdXJyZW50KSBjbGVhclRpbWVvdXQoaG9sZFRpbWVyLmN1cnJlbnQpO1xuICAgICAgaG9sZFRpbWVyLmN1cnJlbnQgPSBudWxsO1xuICAgIH07XG4gICAgLy8gUnVucyBvbmNlIG9uIG1vdW50OyByZWFkcyBsaXZlIHN0YXRlIHZpYSBzdGF0ZVJlZiBhbmQgc3RhYmxlIGNhbGxiYWNrcy5cbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgcmVhY3QtaG9va3MvZXhoYXVzdGl2ZS1kZXBzXG4gIH0sIFtdKTtcblxuICByZXR1cm4ge1xuICAgIHN0YXRlLFxuICAgIHJlZ2lzdGVyQ2FudmFzLFxuICAgIGJvYXJkUm9vdDogYm9hcmRSZWYuY3VycmVudD8ucm9vdCA/PyBudWxsLFxuICAgIGlzTW9iaWxlLFxuICAgIC8vIGNhbWVyYVxuICAgIG9yaWdpblg6ICh2dzogbnVtYmVyKSA9PiBvcmlnaW5YKHN0YXRlLmNhbSwgdncpLFxuICAgIG9yaWdpblk6ICh2aDogbnVtYmVyKSA9PiBvcmlnaW5ZKHN0YXRlLmNhbSwgdmgpLFxuICAgIHByb2plY3Q6ICh3eDogbnVtYmVyLCB3eTogbnVtYmVyKSA9PiBwcm9qZWN0KHN0YXRlLmNhbSwgc3RhdGUudnAsIHd4LCB3eSksXG4gICAgc2V0Wm9vbSxcbiAgICBjbGFtcFpvb20sXG4gICAgZmx5VG8sXG4gICAgYW5jaG9yUG9pbnQsXG4gICAgLy8gZ2VzdHVyZXNcbiAgICBvbkNhbnZhc0Rvd24sXG4gICAgb25DYW52YXNEYmxDbGljayxcbiAgICBvYmpQb2ludGVyRG93bixcbiAgICBzdGFydEhhbmRsZSxcbiAgICBzdGFydENvbm5lY3QsXG4gICAgc2V0SG92ZXIsXG4gICAgY2xlYXJTZWxlY3Rpb24sXG4gICAgc2VsZWN0LFxuICAgIGNsb3NlUXVpY2tNZW51LFxuICAgIC8vIGtleWJvYXJkIGNvbm5lY3QgKHRoZSBub24tZHJhZyBwYXRoKVxuICAgIGJlZ2luQ29ubmVjdCxcbiAgICBlbmRDb25uZWN0LFxuICAgIG1vdmVDb25uZWN0Q3Vyc29yLFxuICAgIC8vIG11dGF0aW9uc1xuICAgIHBhdGNoU2VsLFxuICAgIHBhdGNoT2JqZWN0LFxuICAgIGRlbGV0ZVNlbGVjdGlvbixcbiAgICBjcmVhdGVPYmplY3QsXG4gICAgLy8gcGljay1maWxlIGZsb3dzXG4gICAgaW5zZXJ0SW1hZ2UsXG4gICAgb3BlbkJvYXJkLFxuICAgIG9wZW5Cb2FyZEF0LFxuICAgIG5ld0JvYXJkLFxuICAgIG5ld0JvYXJkSW4sXG4gICAgb3BlbkJvYXJkSW4sXG4gICAgYWRkU3BhY2UsXG4gICAgLy8gdmlld3MgJiBqb3VybmV5c1xuICAgIHNhdmVWaWV3LFxuICAgIGRlbGV0ZVZpZXcsXG4gICAgYWRkSm91cm5leVN0ZXAsXG4gICAgcmVzb2x2ZVZpZXcsXG4gICAgcGxheUpvdXJuZXksXG4gICAgcGxheU5leHQsXG4gICAgcGxheVByZXYsXG4gICAgcGxheUV4aXQsXG4gICAgcGxheVNlZWssXG4gICAgLy8gbW9kZSAvIGNocm9tZVxuICAgIHNldFJ1bixcbiAgICBzZXRFZGl0LFxuICAgIHRvZ2dsZVRoZW1lLFxuICAgIHRvZ2dsZVBhbmVsLFxuICAgIGNsb3NlSW5zcGVjdG9yLFxuICAgIGNsb3NlUGFuZWwsXG4gICAgc2V0QmFja2dyb3VuZCxcbiAgICBzZXRMaWdodCxcbiAgICBzZXRTY3JlZW4sXG4gICAgdG9nZ2xlRGVtb01lbnUsXG4gICAgLy8gdG9hc3RzICsgZGVtb1xuICAgIHRvYXN0LFxuICAgIGRpc21pc3NUb2FzdCxcbiAgICBkZW1vTFdXLFxuICAgIGRlbW9Eb3duZ3JhZGUsXG4gIH07XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7O0FBT0EsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsT0FBQSxHQUFBRCxPQUFBO0FBVUEsSUFBQUUsU0FBQSxHQUFBRixPQUFBO0FBQ0EsSUFBQUcsSUFBQSxHQUFBSCxPQUFBO0FBY0EsSUFBQUksVUFBQSxHQUFBSixPQUFBO0FBQ0EsSUFBQUssV0FBQSxHQUFBTCxPQUFBO0FBZ0JBLElBQUFNLFNBQUEsR0FBQU4sT0FBQTtBQUlBLElBQUFPLE9BQUEsR0FBQVAsT0FBQTtBQUVBLElBQUFRLFlBQUEsR0FBQVIsT0FBQTtBQXhEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBOENBO0FBQ0E7QUFDQTs7QUFXQTtBQUNBLE1BQU1TLE9BQU8sR0FBR0EsQ0FBQ0MsSUFBWSxFQUFFQyxHQUFXLEtBQWEsR0FBR0QsSUFBSSxJQUFJQyxHQUFHLEVBQUUsQ0FBQ0MsT0FBTyxDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUM7O0FBRTVGO0FBQ0EsU0FBU0MsTUFBTUEsQ0FBQ0MsQ0FBVSxFQUFVO0VBQ2xDLE1BQU1DLENBQUMsR0FBSUQsQ0FBQyxFQUErQkUsSUFBSTtFQUMvQyxPQUFPRCxDQUFDLEdBQUcsTUFBTUEsQ0FBQyxFQUFFLEdBQUcsRUFBRTtBQUMzQjtBQTZDQSxNQUFNRSxlQUFlLEdBQUdBLENBQUEsTUFBaUI7RUFDdkNDLEVBQUUsRUFBRSxPQUFPQyxNQUFNLEtBQUssV0FBVyxHQUFHQSxNQUFNLENBQUNDLFVBQVUsR0FBRyxJQUFJO0VBQzVEQyxFQUFFLEVBQUUsT0FBT0YsTUFBTSxLQUFLLFdBQVcsR0FBR0EsTUFBTSxDQUFDRyxXQUFXLEdBQUcsR0FBRztFQUM1REMsS0FBSyxFQUFFLENBQUM7RUFDUkMsSUFBSSxFQUFFO0FBQ1IsQ0FBQyxDQUFDOztBQUVGO0FBQ0E7QUFDQTtBQUNPLFNBQVNDLGNBQWNBLENBQUNDLEdBQWEsRUFBRUMsRUFBVSxFQUFFQyxRQUFpQixFQUFZO0VBQ3JGLElBQUlBLFFBQVEsRUFBRSxPQUFPRixHQUFHLENBQUNHLFFBQVEsQ0FBQ0YsRUFBRSxDQUFDLEdBQUdELEdBQUcsQ0FBQ0ksTUFBTSxDQUFFQyxDQUFDLElBQUtBLENBQUMsS0FBS0osRUFBRSxDQUFDLEdBQUdELEdBQUcsQ0FBQ00sTUFBTSxDQUFDTCxFQUFFLENBQUM7RUFDcEYsT0FBT0QsR0FBRyxDQUFDRyxRQUFRLENBQUNGLEVBQUUsQ0FBQyxHQUFHRCxHQUFHLEdBQUcsQ0FBQ0MsRUFBRSxDQUFDO0FBQ3RDO0FBRUEsTUFBTU0saUJBQWlCLEdBQUcsR0FBRzs7QUFFN0I7QUFDQTtBQUNBO0FBQ0EsTUFBTUMsZ0JBQWdCLEdBQUcsQ0FBQzs7QUFFMUI7QUFDQTtBQUNBO0FBQ0EsTUFBTUMsaUJBQWlCLEdBQUcsR0FBRztBQUU3QixNQUFNQyxvQkFBb0IsR0FBR0EsQ0FBQSxLQUFlO0VBQzFDLElBQUk7SUFDRixPQUFPakIsTUFBTSxDQUFDa0IsVUFBVSxDQUFDLGtDQUFrQyxDQUFDLENBQUNDLE9BQU87RUFDdEUsQ0FBQyxDQUFDLE1BQU07SUFDTixPQUFPLEtBQUs7RUFDZDtBQUNGLENBQUM7O0FBRUQ7QUFDQTtBQUNBO0FBQ08sTUFBTUMsV0FBVyxHQUFBQyxPQUFBLENBQUFELFdBQUEsR0FBRztFQUN6QixjQUFjLEVBQUUsZUFBZTtFQUMvQixXQUFXLEVBQUUsaUJBQWlCO0VBQzlCLFlBQVksRUFBRTtBQUNoQixDQUFVO0FBRUgsU0FBU0UsV0FBV0EsQ0FBQSxFQUFHO0VBQzVCO0VBQ0E7RUFDQSxNQUFNLENBQUNDLFFBQVEsRUFBRUMsV0FBVyxDQUFDLEdBQUcsSUFBQUMsZUFBUSxFQUF3QixJQUFJLENBQUM7RUFDckUsTUFBTUMsY0FBYyxHQUFHLElBQUFDLGtCQUFXLEVBQUVDLEVBQXlCLElBQUtKLFdBQVcsQ0FBQ0ksRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDO0VBQ3RGLE1BQU1DLE9BQU8sR0FBRyxJQUFBQyxhQUFNLEVBQU8sSUFBSSxDQUFDO0VBQ2xDLE1BQU1DLFFBQVEsR0FBRyxJQUFBRCxhQUFNLEVBQWdCLElBQUksQ0FBQztFQUM1QyxNQUFNRSxTQUFTLEdBQUcsSUFBQUYsYUFBTSxFQUFnQixJQUFJLENBQUM7RUFDN0MsTUFBTUcsUUFBUSxHQUFHLElBQUFILGFBQU0sRUFBQyxLQUFLLENBQUM7RUFDOUIsTUFBTUksUUFBUSxHQUFHLElBQUFKLGFBQU0sRUFBQyxDQUFDLENBQUM7RUFDMUI7RUFDQTtFQUNBO0VBQ0EsTUFBTUssV0FBVyxHQUFHLElBQUFMLGFBQU0sRUFBYSxNQUFNLENBQUMsQ0FBQyxDQUFDO0VBRWhELE1BQU0sQ0FBQ00sS0FBSyxFQUFFQyxRQUFRLENBQUMsR0FBRyxJQUFBWixlQUFRLEVBQVUsT0FBTztJQUNqRGEsSUFBSSxFQUFFLEtBQUs7SUFDWEMsS0FBSyxFQUFFLEtBQUs7SUFDWkMsRUFBRSxFQUFFQyxnQkFBSyxDQUFDQyxVQUFVO0lBQ3BCQyxLQUFLLEVBQUVGLGdCQUFLLENBQUNFLEtBQUs7SUFDbEJDLEdBQUcsRUFBRTtNQUFFQyxFQUFFLEVBQUUsR0FBRztNQUFFQyxFQUFFLEVBQUUsR0FBRztNQUFFQyxJQUFJLEVBQUU7SUFBSSxDQUFDO0lBQ3BDQyxFQUFFLEVBQUVsRCxlQUFlLENBQUMsQ0FBQztJQUNyQm1ELE9BQU8sRUFBRSxJQUFBQyxzQkFBVyxFQUFDLENBQUM7SUFDdEJDLEtBQUssRUFBRUMscUJBQVUsQ0FBQ0MsS0FBSyxDQUFDLENBQUM7SUFDekJDLFFBQVEsRUFBRUMsd0JBQWE7SUFDdkJDLFNBQVMsRUFBRSxFQUFFO0lBQ2JDLEtBQUssRUFBRSxJQUFJO0lBQ1hDLE9BQU8sRUFBRSxJQUFJO0lBQ2JDLGNBQWMsRUFBRSxJQUFJO0lBQ3BCQyxXQUFXLEVBQUUsSUFBSTtJQUNqQkMsYUFBYSxFQUFFLElBQUk7SUFDbkJDLGFBQWEsRUFBRSxLQUFLO0lBQ3BCQyxTQUFTLEVBQUUsS0FBSztJQUNoQkMsU0FBUyxFQUFFLElBQUk7SUFDZkMsT0FBTyxFQUFFLElBQUk7SUFDYkMsTUFBTSxFQUFFLEVBQUU7SUFDVkMsTUFBTSxFQUFFLElBQUk7SUFDWkMsWUFBWSxFQUFFLEtBQUs7SUFDbkJDLE9BQU8sRUFBRSxLQUFLO0lBQ2RDLE9BQU8sRUFBRXJELG9CQUFvQixDQUFDLENBQUM7SUFDL0JzRCxJQUFJLEVBQUUsSUFBSTtJQUNWQyxNQUFNLEVBQUU7RUFDVixDQUFDLENBQUMsQ0FBQzs7RUFFSDtFQUNBLE1BQU1DLFFBQVEsR0FBRyxJQUFBM0MsYUFBTSxFQUFDTSxLQUFLLENBQUM7RUFDOUIsSUFBQXNDLGdCQUFTLEVBQUMsTUFBTTtJQUNkRCxRQUFRLENBQUNFLE9BQU8sR0FBR3ZDLEtBQUs7RUFDMUIsQ0FBQyxDQUFDO0VBRUYsTUFBTXdDLE1BQU0sR0FBRyxJQUFBakQsa0JBQVcsRUFDdkJrRCxLQUE0RCxJQUMzRHhDLFFBQVEsQ0FBRXlDLElBQUksS0FBTTtJQUFFLEdBQUdBLElBQUk7SUFBRSxJQUFJLE9BQU9ELEtBQUssS0FBSyxVQUFVLEdBQUdBLEtBQUssQ0FBQ0MsSUFBSSxDQUFDLEdBQUdELEtBQUs7RUFBRSxDQUFDLENBQUMsQ0FBQyxFQUMzRixFQUNGLENBQUM7RUFFRCxNQUFNRSxRQUFRLEdBQUcsSUFBQXBELGtCQUFXLEVBQUMsTUFBTVMsS0FBSyxDQUFDWSxFQUFFLENBQUNqRCxFQUFFLEdBQUdlLGlCQUFpQixFQUFFLENBQUNzQixLQUFLLENBQUNZLEVBQUUsQ0FBQ2pELEVBQUUsQ0FBQyxDQUFDOztFQUVsRjtFQUNBLE1BQU1pRixVQUFVLEdBQUcsSUFBQXJELGtCQUFXLEVBQUVoQyxDQUF1QyxJQUF1QjtJQUM1RixNQUFNcUQsRUFBRSxHQUFHeUIsUUFBUSxDQUFDRSxPQUFPLENBQUMzQixFQUFFO0lBQzlCLE9BQU8sQ0FBQ3JELENBQUMsQ0FBQ3NGLE9BQU8sR0FBR2pDLEVBQUUsQ0FBQzVDLEtBQUssRUFBRVQsQ0FBQyxDQUFDdUYsT0FBTyxHQUFHbEMsRUFBRSxDQUFDM0MsSUFBSSxDQUFDO0VBQ3BELENBQUMsRUFBRSxFQUFFLENBQUM7RUFFTixNQUFNOEUsT0FBTyxHQUFHLElBQUF4RCxrQkFBVyxFQUFDLENBQUN5RCxFQUFVLEVBQUVDLEVBQVcsRUFBRUMsRUFBVyxLQUFLO0lBQ3BFVixNQUFNLENBQUVXLENBQUMsS0FBTTtNQUFFM0MsR0FBRyxFQUFFLElBQUE0QyxrQkFBVSxFQUFDRCxDQUFDLENBQUMzQyxHQUFHLEVBQUUyQyxDQUFDLENBQUN2QyxFQUFFLEVBQUVvQyxFQUFFLEVBQUVDLEVBQUUsRUFBRUMsRUFBRTtJQUFFLENBQUMsQ0FBQyxDQUFDO0VBQy9ELENBQUMsRUFBRSxDQUFDVixNQUFNLENBQUMsQ0FBQzs7RUFFWjtFQUNBLE1BQU1hLFlBQVksR0FBRyxJQUFBOUQsa0JBQVcsRUFBRW5CLEVBQVUsSUFBSztJQUMvQ29FLE1BQU0sQ0FBRVcsQ0FBQyxLQUFNO01BQUVyQixNQUFNLEVBQUVxQixDQUFDLENBQUNyQixNQUFNLENBQUN2RCxNQUFNLENBQUUrRSxDQUFDLElBQUtBLENBQUMsQ0FBQ2xGLEVBQUUsS0FBS0EsRUFBRTtJQUFFLENBQUMsQ0FBQyxDQUFDO0VBQ2xFLENBQUMsRUFBRSxDQUFDb0UsTUFBTSxDQUFDLENBQUM7RUFFWixNQUFNZSxLQUFLLEdBQUcsSUFBQWhFLGtCQUFXLEVBQ3ZCLENBQUNpRSxJQUFZLEVBQUVDLElBQUksR0FBRyxPQUFPLEVBQUVDLElBQW9CLEdBQUcsQ0FBQyxDQUFDLEtBQUs7SUFDM0QsTUFBTXRGLEVBQUUsR0FBRyxFQUFFMEIsUUFBUSxDQUFDeUMsT0FBTztJQUM3QixNQUFNZSxDQUFRLEdBQUc7TUFBRWxGLEVBQUU7TUFBRW9GLElBQUk7TUFBRUMsSUFBSTtNQUFFLEdBQUdDO0lBQUssQ0FBQztJQUM1Q2xCLE1BQU0sQ0FBRVcsQ0FBQyxLQUFNO01BQUVyQixNQUFNLEVBQUVxQixDQUFDLENBQUNyQixNQUFNLENBQUNyRCxNQUFNLENBQUM2RSxDQUFDO0lBQUUsQ0FBQyxDQUFDLENBQUM7SUFDL0MsTUFBTUssR0FBRyxHQUFHRCxJQUFJLENBQUNFLFdBQVcsR0FBRyxJQUFJLEdBQUcsSUFBSTtJQUMxQ0MsVUFBVSxDQUFDLE1BQU1SLFlBQVksQ0FBQ2pGLEVBQUUsQ0FBQyxFQUFFdUYsR0FBRyxDQUFDO0VBQ3pDLENBQUMsRUFDRCxDQUFDbkIsTUFBTSxFQUFFYSxZQUFZLENBQ3ZCLENBQUM7O0VBRUQ7RUFDQTtFQUNBO0VBQ0EsTUFBTVMsUUFBUSxHQUFHLElBQUFwRSxhQUFNLEVBQXFCLElBQUksQ0FBQztFQUNqRDtFQUNBO0VBQ0EsTUFBTXFFLFVBQVUsR0FBRyxJQUFBckUsYUFBTSxFQUFzQixJQUFJc0UsR0FBRyxDQUFDLENBQUMsQ0FBQzs7RUFFekQ7RUFDQTtFQUNBO0VBQ0EsTUFBTUMsVUFBVSxHQUFHLElBQUExRSxrQkFBVyxFQUM1QixDQUFDMkUsSUFBZSxFQUFFQyxTQUFpQixFQUFFQyxTQUFTLEdBQUcsT0FBTyxLQUFLO0lBQzNELE1BQU1kLENBQUMsR0FBR1EsUUFBUSxDQUFDdkIsT0FBTztJQUMxQixJQUFJLENBQUNlLENBQUMsRUFBRTtNQUNOQyxLQUFLLENBQUNZLFNBQVMsRUFBRUMsU0FBUyxDQUFDO01BQzNCO0lBQ0Y7SUFDQSxJQUFJZCxDQUFDLENBQUNwRCxJQUFJLEtBQUssSUFBSSxFQUFFO01BQ25CcUQsS0FBSyxDQUFDLG9DQUFvQyxFQUFFLE1BQU0sRUFBRTtRQUFFYyxTQUFTLEVBQUU7TUFBZSxDQUFDLENBQUM7TUFDbEY7SUFDRjtJQUNBQyxPQUFPLENBQUNDLEdBQUcsQ0FBQ0wsSUFBSSxDQUFDTSxHQUFHLENBQUVDLENBQUMsSUFBSyxJQUFBQyxzQkFBVSxFQUFDcEIsQ0FBQyxFQUFFbUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDRSxJQUFJLENBQ2pELE1BQU1wQixLQUFLLENBQUNZLFNBQVMsRUFBRUMsU0FBUyxDQUFDLEVBQ2hDN0csQ0FBQyxJQUFLZ0csS0FBSyxDQUFDLGNBQWNqRyxNQUFNLENBQUNDLENBQUMsQ0FBQyxFQUFFLEVBQUUsT0FBTyxFQUFFO01BQUU4RyxTQUFTLEVBQUU7SUFBVSxDQUFDLENBQzNFLENBQUM7RUFDSCxDQUFDLEVBQ0QsQ0FBQ2QsS0FBSyxDQUNSLENBQUM7O0VBRUQ7RUFDQSxNQUFNcUIsWUFBWSxHQUFHLElBQUFyRixrQkFBVyxFQUFFc0YsR0FBYSxJQUFLO0lBQ2xELE1BQU12QixDQUFDLEdBQUdRLFFBQVEsQ0FBQ3ZCLE9BQU87SUFDMUIsSUFBSSxDQUFDZSxDQUFDLElBQUlBLENBQUMsQ0FBQ3BELElBQUksS0FBSyxJQUFJLEVBQUU7SUFDM0IsS0FBSyxNQUFNOUIsRUFBRSxJQUFJeUcsR0FBRyxFQUFFO01BQ3BCLE1BQU1uQyxJQUFJLEdBQUdxQixVQUFVLENBQUN4QixPQUFPLENBQUN1QyxHQUFHLENBQUMxRyxFQUFFLENBQUM7TUFDdkMsSUFBSXNFLElBQUksRUFBRXFDLFlBQVksQ0FBQ3JDLElBQUksQ0FBQztNQUM1QixNQUFNc0MsTUFBTSxHQUFHcEgsTUFBTSxDQUFDaUcsVUFBVSxDQUFDLE1BQU07UUFDckNFLFVBQVUsQ0FBQ3hCLE9BQU8sQ0FBQzBDLE1BQU0sQ0FBQzdHLEVBQUUsQ0FBQztRQUM3QixNQUFNcUcsQ0FBQyxHQUFHcEMsUUFBUSxDQUFDRSxPQUFPLENBQUMxQixPQUFPLENBQUNxRSxJQUFJLENBQUUxRyxDQUFDLElBQUtBLENBQUMsQ0FBQ0osRUFBRSxLQUFLQSxFQUFFLENBQUM7UUFDM0QsSUFBSXFHLENBQUMsRUFBRSxJQUFBQyxzQkFBVSxFQUFDcEIsQ0FBQyxFQUFFbUIsQ0FBQyxDQUFDLENBQUNVLEtBQUssQ0FBQyxNQUFNQyxTQUFTLENBQUM7TUFDaEQsQ0FBQyxFQUFFLEdBQUcsQ0FBQztNQUNQckIsVUFBVSxDQUFDeEIsT0FBTyxDQUFDOEMsR0FBRyxDQUFDakgsRUFBRSxFQUFFNEcsTUFBTSxDQUFDO0lBQ3BDO0VBQ0YsQ0FBQyxFQUFFLEVBQUUsQ0FBQzs7RUFFTjtFQUNBLE1BQU1NLEtBQUssR0FBRyxJQUFBL0Ysa0JBQVcsRUFDdkIsQ0FBQ2dHLE1BQXlCLEVBQUVDLEdBQVksRUFBRUMsSUFBYSxLQUFLO0lBQzFELElBQUksQ0FBQ0YsTUFBTSxFQUFFO0lBQ2I7SUFDQTtJQUNBO0lBQ0EsTUFBTUcsSUFBSSxHQUFHLElBQUFDLHVCQUFlLEVBQUNKLE1BQU0sRUFBRWxELFFBQVEsQ0FBQ0UsT0FBTyxDQUFDM0IsRUFBRSxDQUFDakQsRUFBRSxFQUFFOEgsSUFBSSxJQUFJcEQsUUFBUSxDQUFDRSxPQUFPLENBQUMzQixFQUFFLENBQUM5QyxFQUFFLENBQUM7SUFDNUYsSUFBSTZCLFFBQVEsQ0FBQzRDLE9BQU8sRUFBRXFELG9CQUFvQixDQUFDakcsUUFBUSxDQUFDNEMsT0FBTyxDQUFDO0lBQzVELElBQUlGLFFBQVEsQ0FBQ0UsT0FBTyxDQUFDTCxPQUFPLElBQUksQ0FBQ3NELEdBQUcsRUFBRTtNQUNwQ2hELE1BQU0sQ0FBQztRQUFFaEMsR0FBRyxFQUFFa0Y7TUFBSyxDQUFDLENBQUM7TUFDckI7SUFDRjtJQUNBLE1BQU1HLElBQUksR0FBRztNQUFFLEdBQUd4RCxRQUFRLENBQUNFLE9BQU8sQ0FBQy9CO0lBQUksQ0FBQztJQUN4QyxNQUFNc0YsRUFBRSxHQUFHQyxXQUFXLENBQUNDLEdBQUcsQ0FBQyxDQUFDO0lBQzVCLE1BQU1DLElBQUksR0FBSUMsQ0FBUyxJQUFNQSxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsR0FBR0EsQ0FBQyxHQUFHQSxDQUFDLEdBQUdBLENBQUMsR0FBRyxDQUFDLEdBQUdDLElBQUksQ0FBQ0MsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHRixDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUU7SUFDdkYsTUFBTUcsSUFBSSxHQUFJTCxHQUFXLElBQUs7TUFDNUIsTUFBTUUsQ0FBQyxHQUFHQyxJQUFJLENBQUNHLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQ04sR0FBRyxHQUFHRixFQUFFLElBQUlOLEdBQUcsQ0FBQztNQUN2QyxNQUFNakksQ0FBQyxHQUFHMEksSUFBSSxDQUFDQyxDQUFDLENBQUM7TUFDakIxRCxNQUFNLENBQUM7UUFDTGhDLEdBQUcsRUFBRTtVQUNIQyxFQUFFLEVBQUVvRixJQUFJLENBQUNwRixFQUFFLEdBQUcsQ0FBQ2lGLElBQUksQ0FBQ2pGLEVBQUUsR0FBR29GLElBQUksQ0FBQ3BGLEVBQUUsSUFBSWxELENBQUM7VUFDckNtRCxFQUFFLEVBQUVtRixJQUFJLENBQUNuRixFQUFFLEdBQUcsQ0FBQ2dGLElBQUksQ0FBQ2hGLEVBQUUsR0FBR21GLElBQUksQ0FBQ25GLEVBQUUsSUFBSW5ELENBQUM7VUFDckNvRCxJQUFJLEVBQUVrRixJQUFJLENBQUNsRixJQUFJLEdBQUcsQ0FBQytFLElBQUksQ0FBQy9FLElBQUksR0FBR2tGLElBQUksQ0FBQ2xGLElBQUksSUFBSXBEO1FBQzlDO01BQ0YsQ0FBQyxDQUFDO01BQ0YsSUFBSTJJLENBQUMsR0FBRyxDQUFDLEVBQUV2RyxRQUFRLENBQUM0QyxPQUFPLEdBQUdnRSxxQkFBcUIsQ0FBQ0YsSUFBSSxDQUFDO0lBQzNELENBQUM7SUFDRDFHLFFBQVEsQ0FBQzRDLE9BQU8sR0FBR2dFLHFCQUFxQixDQUFDRixJQUFJLENBQUM7RUFDaEQsQ0FBQyxFQUNELENBQUM3RCxNQUFNLENBQ1QsQ0FBQzs7RUFFRDtFQUNBLE1BQU1nRSxXQUFXLEdBQUcsSUFBQWpILGtCQUFXLEVBQUVrSCxDQUFzQixJQUFLO0lBQzFELElBQUksT0FBT0EsQ0FBQyxLQUFLLFFBQVEsRUFBRSxPQUFPcEUsUUFBUSxDQUFDRSxPQUFPLENBQUN4QixLQUFLLENBQUNtRSxJQUFJLENBQUUxRyxDQUFDLElBQUtBLENBQUMsQ0FBQ2tJLElBQUksS0FBS0QsQ0FBQyxDQUFDLElBQUksSUFBSTtJQUMxRixNQUFNbkQsQ0FBYSxHQUFHO01BQUU3QyxFQUFFLEVBQUVnRyxDQUFDLENBQUNoRyxFQUFFO01BQUVDLEVBQUUsRUFBRStGLENBQUMsQ0FBQy9GLEVBQUU7TUFBRUMsSUFBSSxFQUFFOEYsQ0FBQyxDQUFDOUY7SUFBSyxDQUFDO0lBQzFELElBQUk4RixDQUFDLENBQUNFLENBQUMsRUFBRXJELENBQUMsQ0FBQ3FELENBQUMsR0FBR0YsQ0FBQyxDQUFDRSxDQUFDO0lBQ2xCLElBQUlGLENBQUMsQ0FBQ0csQ0FBQyxFQUFFdEQsQ0FBQyxDQUFDc0QsQ0FBQyxHQUFHSCxDQUFDLENBQUNHLENBQUM7SUFDbEIsT0FBT3RELENBQUM7RUFDVixDQUFDLEVBQUUsRUFBRSxDQUFDO0VBRU4sTUFBTXVELFFBQVEsR0FBRyxJQUFBdEgsa0JBQVcsRUFBQyxNQUFNO0lBQ2pDLE1BQU00RCxDQUFDLEdBQUdkLFFBQVEsQ0FBQ0UsT0FBTztJQUMxQixNQUFNdUUsSUFBVSxHQUFHO01BQUVKLElBQUksRUFBRSxRQUFRdkQsQ0FBQyxDQUFDcEMsS0FBSyxDQUFDZ0csTUFBTSxHQUFHLENBQUMsRUFBRTtNQUFFdEcsRUFBRSxFQUFFMEMsQ0FBQyxDQUFDM0MsR0FBRyxDQUFDQyxFQUFFO01BQUVDLEVBQUUsRUFBRXlDLENBQUMsQ0FBQzNDLEdBQUcsQ0FBQ0UsRUFBRTtNQUFFQyxJQUFJLEVBQUV3QyxDQUFDLENBQUMzQyxHQUFHLENBQUNHO0lBQUssQ0FBQztJQUN2RzZCLE1BQU0sQ0FBRXdFLEVBQUUsS0FBTTtNQUFFakcsS0FBSyxFQUFFaUcsRUFBRSxDQUFDakcsS0FBSyxDQUFDdEMsTUFBTSxDQUFDLENBQUNxSSxJQUFJLENBQUM7SUFBRSxDQUFDLENBQUMsQ0FBQztJQUNwRCxNQUFNdEQsSUFBSSxHQUFHLGVBQWVzRCxJQUFJLENBQUNKLElBQUksS0FBSztJQUMxQyxNQUFNcEQsQ0FBQyxHQUFHUSxRQUFRLENBQUN2QixPQUFPO0lBQzFCLElBQUksQ0FBQ2UsQ0FBQyxFQUFFO01BQ05DLEtBQUssQ0FBQ0MsSUFBSSxFQUFFLE1BQU0sQ0FBQztNQUNuQjtJQUNGO0lBQ0EsSUFBSUYsQ0FBQyxDQUFDcEQsSUFBSSxLQUFLLElBQUksRUFBRTtNQUNuQnFELEtBQUssQ0FBQyxrQ0FBa0MsRUFBRSxNQUFNLEVBQUU7UUFBRWMsU0FBUyxFQUFFO01BQWUsQ0FBQyxDQUFDO01BQ2hGO0lBQ0Y7SUFDQSxJQUFBNEMsb0JBQVcsRUFBQzNELENBQUMsRUFBRXdELElBQUksQ0FBQyxDQUFDbkMsSUFBSSxDQUN2QixNQUFNcEIsS0FBSyxDQUFDQyxJQUFJLEVBQUUsTUFBTSxDQUFDLEVBQ3hCakcsQ0FBQyxJQUFLZ0csS0FBSyxDQUFDLHFCQUFxQmpHLE1BQU0sQ0FBQ0MsQ0FBQyxDQUFDLEVBQUUsRUFBRSxPQUFPLEVBQUU7TUFBRThHLFNBQVMsRUFBRTtJQUFVLENBQUMsQ0FDbEYsQ0FBQztFQUNILENBQUMsRUFBRSxDQUFDN0IsTUFBTSxFQUFFZSxLQUFLLENBQUMsQ0FBQzs7RUFFbkI7QUFDRjtBQUNBO0FBQ0E7RUFDRSxNQUFNMkQsVUFBVSxHQUFHLElBQUEzSCxrQkFBVyxFQUMzQm1ILElBQVksSUFBSztJQUNoQixNQUFNcEQsQ0FBQyxHQUFHUSxRQUFRLENBQUN2QixPQUFPO0lBQzFCLE1BQU11RSxJQUFJLEdBQUd6RSxRQUFRLENBQUNFLE9BQU8sQ0FBQ3hCLEtBQUssQ0FBQ21FLElBQUksQ0FBRXVCLENBQUMsSUFBS0EsQ0FBQyxDQUFDQyxJQUFJLEtBQUtBLElBQUksQ0FBQztJQUNoRSxJQUFJLENBQUNJLElBQUksRUFBRTtJQUNYLElBQUl4RCxDQUFDLElBQUlBLENBQUMsQ0FBQ3BELElBQUksS0FBSyxJQUFJLEVBQUU7TUFDeEJxRCxLQUFLLENBQUMsb0NBQW9DLEVBQUUsTUFBTSxFQUFFO1FBQUVjLFNBQVMsRUFBRTtNQUFlLENBQUMsQ0FBQztNQUNsRjtJQUNGO0lBQ0E3QixNQUFNLENBQUVXLENBQUMsS0FBTTtNQUFFcEMsS0FBSyxFQUFFb0MsQ0FBQyxDQUFDcEMsS0FBSyxDQUFDeEMsTUFBTSxDQUFFa0ksQ0FBQyxJQUFLQSxDQUFDLENBQUNDLElBQUksS0FBS0EsSUFBSTtJQUFFLENBQUMsQ0FBQyxDQUFDO0lBQ2xFLElBQUksQ0FBQ3BELENBQUMsRUFBRTtNQUNOQyxLQUFLLENBQUMsaUJBQWlCbUQsSUFBSSxLQUFLLEVBQUUsT0FBTyxDQUFDO01BQzFDO0lBQ0Y7SUFDQSxJQUFBUyxzQkFBVSxFQUFDN0QsQ0FBQyxFQUFFb0QsSUFBSSxDQUFDLENBQUMvQixJQUFJLENBQ3RCLE1BQU1wQixLQUFLLENBQUMsaUJBQWlCbUQsSUFBSSxLQUFLLEVBQUUsT0FBTyxDQUFDLEVBQy9DbkosQ0FBQyxJQUFLO01BQ0w7TUFDQWlGLE1BQU0sQ0FBRVcsQ0FBQyxJQUFNQSxDQUFDLENBQUNwQyxLQUFLLENBQUNxRyxJQUFJLENBQUVYLENBQUMsSUFBS0EsQ0FBQyxDQUFDQyxJQUFJLEtBQUtBLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHO1FBQUUzRixLQUFLLEVBQUVvQyxDQUFDLENBQUNwQyxLQUFLLENBQUN0QyxNQUFNLENBQUMsQ0FBQ3FJLElBQUksQ0FBQztNQUFFLENBQUUsQ0FBQztNQUM5RnZELEtBQUssQ0FBQyx1QkFBdUJqRyxNQUFNLENBQUNDLENBQUMsQ0FBQyxFQUFFLEVBQUUsT0FBTyxFQUFFO1FBQUU4RyxTQUFTLEVBQUU7TUFBVSxDQUFDLENBQUM7SUFDOUUsQ0FDRixDQUFDO0VBQ0gsQ0FBQyxFQUNELENBQUM3QixNQUFNLEVBQUVlLEtBQUssQ0FDaEIsQ0FBQztFQUVELE1BQU04RCxjQUFjLEdBQUcsSUFBQTlILGtCQUFXLEVBQy9CK0gsR0FBVyxJQUFLO0lBQ2YsTUFBTW5FLENBQUMsR0FBR2QsUUFBUSxDQUFDRSxPQUFPO0lBQzFCLE1BQU1nRixDQUFDLEdBQUdwRSxDQUFDLENBQUNqQyxRQUFRLENBQUNnRSxJQUFJLENBQUUxRyxDQUFDLElBQUtBLENBQUMsQ0FBQ0osRUFBRSxLQUFLa0osR0FBRyxDQUFDO0lBQzlDLElBQUksQ0FBQ0MsQ0FBQyxFQUFFO0lBQ1IsTUFBTUMsSUFBYSxHQUFHO01BQUUsR0FBR0QsQ0FBQztNQUFFRSxLQUFLLEVBQUVGLENBQUMsQ0FBQ0UsS0FBSyxDQUFDaEosTUFBTSxDQUFDLENBQUM7UUFBRXFJLElBQUksRUFBRTtVQUFFckcsRUFBRSxFQUFFMEMsQ0FBQyxDQUFDM0MsR0FBRyxDQUFDQyxFQUFFO1VBQUVDLEVBQUUsRUFBRXlDLENBQUMsQ0FBQzNDLEdBQUcsQ0FBQ0UsRUFBRTtVQUFFQyxJQUFJLEVBQUV3QyxDQUFDLENBQUMzQyxHQUFHLENBQUNHO1FBQUs7TUFBRSxDQUFDLENBQUM7SUFBRSxDQUFDO0lBQ25INkIsTUFBTSxDQUFFd0UsRUFBRSxLQUFNO01BQUU5RixRQUFRLEVBQUU4RixFQUFFLENBQUM5RixRQUFRLENBQUNzRCxHQUFHLENBQUVoRyxDQUFDLElBQU1BLENBQUMsQ0FBQ0osRUFBRSxLQUFLa0osR0FBRyxHQUFHRSxJQUFJLEdBQUdoSixDQUFFO0lBQUUsQ0FBQyxDQUFDLENBQUM7SUFDakYsTUFBTWdGLElBQUksR0FBRyxjQUFjZ0UsSUFBSSxDQUFDQyxLQUFLLENBQUNWLE1BQU0sT0FBT1EsQ0FBQyxDQUFDaEgsS0FBSyxlQUFlZ0gsQ0FBQyxDQUFDbkosRUFBRSxNQUFNO0lBQ25GLE1BQU1rRixDQUFDLEdBQUdRLFFBQVEsQ0FBQ3ZCLE9BQU87SUFDMUIsSUFBSSxDQUFDZSxDQUFDLEVBQUU7TUFDTkMsS0FBSyxDQUFDQyxJQUFJLEVBQUUsTUFBTSxDQUFDO01BQ25CO0lBQ0Y7SUFDQSxJQUFJRixDQUFDLENBQUNwRCxJQUFJLEtBQUssSUFBSSxFQUFFO01BQ25CcUQsS0FBSyxDQUFDLGtDQUFrQyxFQUFFLE1BQU0sRUFBRTtRQUFFYyxTQUFTLEVBQUU7TUFBZSxDQUFDLENBQUM7TUFDaEY7SUFDRjtJQUNBLElBQUFxRCx1QkFBYyxFQUFDcEUsQ0FBQyxFQUFFa0UsSUFBSSxDQUFDLENBQUM3QyxJQUFJLENBQzFCLE1BQU1wQixLQUFLLENBQUNDLElBQUksRUFBRSxNQUFNLENBQUMsRUFDeEJqRyxDQUFDLElBQUtnRyxLQUFLLENBQUMsd0JBQXdCakcsTUFBTSxDQUFDQyxDQUFDLENBQUMsRUFBRSxFQUFFLE9BQU8sRUFBRTtNQUFFOEcsU0FBUyxFQUFFO0lBQVUsQ0FBQyxDQUNyRixDQUFDO0VBQ0gsQ0FBQyxFQUNELENBQUM3QixNQUFNLEVBQUVlLEtBQUssQ0FDaEIsQ0FBQztFQUVELE1BQU1vRSxNQUFNLEdBQUcsSUFBQXBJLGtCQUFXLEVBQ3hCLENBQUNnSSxDQUFVLEVBQUVLLEdBQVcsRUFBRUMsT0FBaUIsS0FBSztJQUM5QyxNQUFNMUUsQ0FBQyxHQUFHb0UsQ0FBQyxDQUFDRSxLQUFLLENBQUNHLEdBQUcsQ0FBQztJQUN0QixNQUFNbkIsQ0FBQyxHQUFHRCxXQUFXLENBQUNyRCxDQUFDLENBQUMyRCxJQUFJLENBQUM7SUFDN0IsSUFBSUwsQ0FBQyxFQUFFbkIsS0FBSyxDQUFDbUIsQ0FBQyxFQUFFb0IsT0FBTyxHQUFHLENBQUMsR0FBRzFFLENBQUMsQ0FBQzJFLFFBQVEsSUFBSSxHQUFHLEVBQUV6RixRQUFRLENBQUNFLE9BQU8sQ0FBQzNCLEVBQUUsQ0FBQzlDLEVBQUUsR0FBR2MsaUJBQWlCLENBQUM7SUFDNUY7SUFDQTtJQUNBO0lBQ0E7SUFDQSxJQUFJZ0IsU0FBUyxDQUFDMkMsT0FBTyxFQUFFO01BQ3JCd0MsWUFBWSxDQUFDbkYsU0FBUyxDQUFDMkMsT0FBTyxDQUFDO01BQy9CM0MsU0FBUyxDQUFDMkMsT0FBTyxHQUFHLElBQUk7SUFDMUI7SUFDQSxJQUFJWSxDQUFDLENBQUM0RSxJQUFJLElBQUksQ0FBQzFGLFFBQVEsQ0FBQ0UsT0FBTyxDQUFDTCxPQUFPLEVBQUU7TUFDdkN0QyxTQUFTLENBQUMyQyxPQUFPLEdBQUczRSxNQUFNLENBQUNpRyxVQUFVLENBQUMsTUFBTTlELFdBQVcsQ0FBQ3dDLE9BQU8sQ0FBQyxDQUFDLEVBQUVZLENBQUMsQ0FBQzRFLElBQUksQ0FBQztJQUM1RTtFQUNGLENBQUMsRUFDRCxDQUFDdkIsV0FBVyxFQUFFbEIsS0FBSyxDQUNyQixDQUFDO0VBRUQsTUFBTTBDLFdBQVcsR0FBRyxJQUFBekksa0JBQVcsRUFDNUIrSCxHQUFXLElBQUs7SUFDZixNQUFNQyxDQUFDLEdBQUdsRixRQUFRLENBQUNFLE9BQU8sQ0FBQ3JCLFFBQVEsQ0FBQ2dFLElBQUksQ0FBRTFHLENBQUMsSUFBS0EsQ0FBQyxDQUFDSixFQUFFLEtBQUtrSixHQUFHLENBQUM7SUFDN0QsSUFBSSxDQUFDQyxDQUFDLEVBQUU7SUFDUixJQUFJM0gsU0FBUyxDQUFDMkMsT0FBTyxFQUFFO01BQ3JCd0MsWUFBWSxDQUFDbkYsU0FBUyxDQUFDMkMsT0FBTyxDQUFDO01BQy9CM0MsU0FBUyxDQUFDMkMsT0FBTyxHQUFHLElBQUk7SUFDMUI7SUFDQUMsTUFBTSxDQUFDO01BQUVYLE9BQU8sRUFBRTtRQUFFeUYsR0FBRztRQUFFTSxHQUFHLEVBQUU7TUFBRSxDQUFDO01BQUVqRyxTQUFTLEVBQUUsS0FBSztNQUFFRCxhQUFhLEVBQUU7SUFBTSxDQUFDLENBQUM7SUFDNUVpRyxNQUFNLENBQUNKLENBQUMsRUFBRSxDQUFDLEVBQUUsSUFBSSxDQUFDO0VBQ3BCLENBQUMsRUFDRCxDQUFDL0UsTUFBTSxFQUFFbUYsTUFBTSxDQUNqQixDQUFDO0VBRUQsTUFBTU0sUUFBUSxHQUFHLElBQUExSSxrQkFBVyxFQUFDLE1BQU07SUFDakMsSUFBSUksUUFBUSxDQUFDNEMsT0FBTyxFQUFFcUQsb0JBQW9CLENBQUNqRyxRQUFRLENBQUM0QyxPQUFPLENBQUM7SUFDNUQsSUFBSTNDLFNBQVMsQ0FBQzJDLE9BQU8sRUFBRTtNQUNyQndDLFlBQVksQ0FBQ25GLFNBQVMsQ0FBQzJDLE9BQU8sQ0FBQztNQUMvQjNDLFNBQVMsQ0FBQzJDLE9BQU8sR0FBRyxJQUFJO0lBQzFCO0lBQ0FDLE1BQU0sQ0FBQztNQUFFWCxPQUFPLEVBQUU7SUFBSyxDQUFDLENBQUM7RUFDM0IsQ0FBQyxFQUFFLENBQUNXLE1BQU0sQ0FBQyxDQUFDO0VBRVosTUFBTTBGLFFBQVEsR0FBRyxJQUFBM0ksa0JBQVcsRUFBQyxNQUFNO0lBQ2pDLE1BQU00SSxFQUFFLEdBQUc5RixRQUFRLENBQUNFLE9BQU8sQ0FBQ1YsT0FBTztJQUNuQyxJQUFJLENBQUNzRyxFQUFFLEVBQUU7SUFDVCxJQUFJdkksU0FBUyxDQUFDMkMsT0FBTyxFQUFFO01BQ3JCd0MsWUFBWSxDQUFDbkYsU0FBUyxDQUFDMkMsT0FBTyxDQUFDO01BQy9CM0MsU0FBUyxDQUFDMkMsT0FBTyxHQUFHLElBQUk7SUFDMUI7SUFDQSxNQUFNZ0YsQ0FBQyxHQUFHbEYsUUFBUSxDQUFDRSxPQUFPLENBQUNyQixRQUFRLENBQUNnRSxJQUFJLENBQUUxRyxDQUFDLElBQUtBLENBQUMsQ0FBQ0osRUFBRSxLQUFLK0osRUFBRSxDQUFDYixHQUFHLENBQUM7SUFDaEUsSUFBSSxDQUFDQyxDQUFDLEVBQUU7SUFDUixNQUFNYSxFQUFFLEdBQUdELEVBQUUsQ0FBQ1AsR0FBRyxHQUFHLENBQUM7SUFDckIsSUFBSVEsRUFBRSxJQUFJYixDQUFDLENBQUNFLEtBQUssQ0FBQ1YsTUFBTSxFQUFFO01BQ3hCa0IsUUFBUSxDQUFDLENBQUM7TUFDVjtJQUNGO0lBQ0F6RixNQUFNLENBQUM7TUFBRVgsT0FBTyxFQUFFO1FBQUUsR0FBR3NHLEVBQUU7UUFBRVAsR0FBRyxFQUFFUTtNQUFHO0lBQUUsQ0FBQyxDQUFDO0lBQ3ZDVCxNQUFNLENBQUNKLENBQUMsRUFBRWEsRUFBRSxDQUFDO0VBQ2YsQ0FBQyxFQUFFLENBQUM1RixNQUFNLEVBQUVtRixNQUFNLEVBQUVNLFFBQVEsQ0FBQyxDQUFDO0VBQzlCO0VBQ0FsSSxXQUFXLENBQUN3QyxPQUFPLEdBQUcyRixRQUFRO0VBRTlCLE1BQU1HLFFBQVEsR0FBRyxJQUFBOUksa0JBQVcsRUFBQyxNQUFNO0lBQ2pDLE1BQU00SSxFQUFFLEdBQUc5RixRQUFRLENBQUNFLE9BQU8sQ0FBQ1YsT0FBTztJQUNuQyxJQUFJLENBQUNzRyxFQUFFLEVBQUU7SUFDVCxJQUFJdkksU0FBUyxDQUFDMkMsT0FBTyxFQUFFO01BQ3JCd0MsWUFBWSxDQUFDbkYsU0FBUyxDQUFDMkMsT0FBTyxDQUFDO01BQy9CM0MsU0FBUyxDQUFDMkMsT0FBTyxHQUFHLElBQUk7SUFDMUI7SUFDQSxNQUFNZ0YsQ0FBQyxHQUFHbEYsUUFBUSxDQUFDRSxPQUFPLENBQUNyQixRQUFRLENBQUNnRSxJQUFJLENBQUUxRyxDQUFDLElBQUtBLENBQUMsQ0FBQ0osRUFBRSxLQUFLK0osRUFBRSxDQUFDYixHQUFHLENBQUM7SUFDaEUsSUFBSSxDQUFDQyxDQUFDLEVBQUU7SUFDUixNQUFNYSxFQUFFLEdBQUdqQyxJQUFJLENBQUNtQyxHQUFHLENBQUMsQ0FBQyxFQUFFSCxFQUFFLENBQUNQLEdBQUcsR0FBRyxDQUFDLENBQUM7SUFDbENwRixNQUFNLENBQUM7TUFBRVgsT0FBTyxFQUFFO1FBQUUsR0FBR3NHLEVBQUU7UUFBRVAsR0FBRyxFQUFFUTtNQUFHO0lBQUUsQ0FBQyxDQUFDO0lBQ3ZDVCxNQUFNLENBQUNKLENBQUMsRUFBRWEsRUFBRSxDQUFDO0VBQ2YsQ0FBQyxFQUFFLENBQUM1RixNQUFNLEVBQUVtRixNQUFNLENBQUMsQ0FBQztFQUVwQixNQUFNWSxRQUFRLEdBQUcsSUFBQWhKLGtCQUFXLEVBQ3pCcUksR0FBVyxJQUFLO0lBQ2YsTUFBTU8sRUFBRSxHQUFHOUYsUUFBUSxDQUFDRSxPQUFPLENBQUNWLE9BQU87SUFDbkMsSUFBSSxDQUFDc0csRUFBRSxFQUFFO0lBQ1QsSUFBSXZJLFNBQVMsQ0FBQzJDLE9BQU8sRUFBRTtNQUNyQndDLFlBQVksQ0FBQ25GLFNBQVMsQ0FBQzJDLE9BQU8sQ0FBQztNQUMvQjNDLFNBQVMsQ0FBQzJDLE9BQU8sR0FBRyxJQUFJO0lBQzFCO0lBQ0EsTUFBTWdGLENBQUMsR0FBR2xGLFFBQVEsQ0FBQ0UsT0FBTyxDQUFDckIsUUFBUSxDQUFDZ0UsSUFBSSxDQUFFMUcsQ0FBQyxJQUFLQSxDQUFDLENBQUNKLEVBQUUsS0FBSytKLEVBQUUsQ0FBQ2IsR0FBRyxDQUFDO0lBQ2hFLElBQUksQ0FBQ0MsQ0FBQyxFQUFFO0lBQ1IvRSxNQUFNLENBQUM7TUFBRVgsT0FBTyxFQUFFO1FBQUUsR0FBR3NHLEVBQUU7UUFBRVA7TUFBSTtJQUFFLENBQUMsQ0FBQztJQUNuQ0QsTUFBTSxDQUFDSixDQUFDLEVBQUVLLEdBQUcsQ0FBQztFQUNoQixDQUFDLEVBQ0QsQ0FBQ3BGLE1BQU0sRUFBRW1GLE1BQU0sQ0FDakIsQ0FBQzs7RUFFRDtFQUNBLE1BQU1hLFFBQVEsR0FBRyxJQUFBakosa0JBQVcsRUFDekJrRCxLQUF1QixJQUFLO0lBQzNCRCxNQUFNLENBQUVXLENBQUMsS0FBTTtNQUFFdEMsT0FBTyxFQUFFc0MsQ0FBQyxDQUFDdEMsT0FBTyxDQUFDMkQsR0FBRyxDQUFFQyxDQUFDLElBQU10QixDQUFDLENBQUMvQixTQUFTLENBQUM5QyxRQUFRLENBQUNtRyxDQUFDLENBQUNyRyxFQUFFLENBQUMsR0FBRztRQUFFLEdBQUdxRyxDQUFDO1FBQUUsR0FBR2hDO01BQU0sQ0FBQyxHQUFHZ0MsQ0FBRTtJQUFFLENBQUMsQ0FBQyxDQUFDO0lBQ3pHRyxZQUFZLENBQUN2QyxRQUFRLENBQUNFLE9BQU8sQ0FBQ25CLFNBQVMsQ0FBQztFQUMxQyxDQUFDLEVBQ0QsQ0FBQ29CLE1BQU0sRUFBRW9DLFlBQVksQ0FDdkIsQ0FBQzs7RUFFRDtFQUNBLE1BQU02RCxNQUFNLEdBQUcsSUFBQWxKLGtCQUFXLEVBQ3hCLENBQUNuQixFQUFVLEVBQUVDLFFBQVEsR0FBRyxLQUFLLEtBQUs7SUFDaENtRSxNQUFNLENBQUVXLENBQUMsS0FBTTtNQUNiL0IsU0FBUyxFQUFFbEQsY0FBYyxDQUFDaUYsQ0FBQyxDQUFDL0IsU0FBUyxFQUFFaEQsRUFBRSxFQUFFQyxRQUFRLENBQUM7TUFDcERxRCxhQUFhLEVBQUUsSUFBSTtNQUNuQkUsU0FBUyxFQUFFO0lBQ2IsQ0FBQyxDQUFDLENBQUM7RUFDTCxDQUFDLEVBQ0QsQ0FBQ1ksTUFBTSxDQUNULENBQUM7O0VBRUQ7RUFDQSxNQUFNa0csY0FBYyxHQUFHLElBQUFuSixrQkFBVyxFQUFDLE1BQU1pRCxNQUFNLENBQUM7SUFBRVosU0FBUyxFQUFFO0VBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQ1ksTUFBTSxDQUFDLENBQUM7RUFFL0UsTUFBTW1HLGVBQWUsR0FBRyxJQUFBcEosa0JBQVcsRUFBQyxNQUFNO0lBQ3hDLE1BQU1wQixHQUFHLEdBQUdrRSxRQUFRLENBQUNFLE9BQU8sQ0FBQ25CLFNBQVMsQ0FBQ0gsS0FBSyxDQUFDLENBQUM7SUFDOUMsSUFBSSxDQUFDOUMsR0FBRyxDQUFDNEksTUFBTSxFQUFFO0lBQ2pCLE1BQU02QixPQUFPLEdBQUd2RyxRQUFRLENBQUNFLE9BQU8sQ0FBQzFCLE9BQU8sQ0FBQ3RDLE1BQU0sQ0FBRWtHLENBQUMsSUFBS3RHLEdBQUcsQ0FBQ0csUUFBUSxDQUFDbUcsQ0FBQyxDQUFDckcsRUFBRSxDQUFDLENBQUM7SUFDMUVvRSxNQUFNLENBQUVXLENBQUMsS0FBTTtNQUFFdEMsT0FBTyxFQUFFc0MsQ0FBQyxDQUFDdEMsT0FBTyxDQUFDdEMsTUFBTSxDQUFFa0csQ0FBQyxJQUFLLENBQUN0RyxHQUFHLENBQUNHLFFBQVEsQ0FBQ21HLENBQUMsQ0FBQ3JHLEVBQUUsQ0FBQyxDQUFDO01BQUVnRCxTQUFTLEVBQUU7SUFBRyxDQUFDLENBQUMsQ0FBQztJQUN6RjtJQUNBLE1BQU1rQyxDQUFDLEdBQUdRLFFBQVEsQ0FBQ3ZCLE9BQU87SUFDMUIsSUFBSWUsQ0FBQyxJQUFJQSxDQUFDLENBQUNwRCxJQUFJLEtBQUssSUFBSSxFQUFFO01BQ3hCb0UsT0FBTyxDQUFDQyxHQUFHLENBQUNwRyxHQUFHLENBQUNxRyxHQUFHLENBQUVwRyxFQUFFLElBQUssSUFBQXlLLHVCQUFXLEVBQUN2RixDQUFDLEVBQUVsRixFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMrRyxLQUFLLENBQUU1SCxDQUFDLElBQ3ZEZ0csS0FBSyxDQUFDLGdCQUFnQmpHLE1BQU0sQ0FBQ0MsQ0FBQyxDQUFDLEVBQUUsRUFBRSxPQUFPLEVBQUU7UUFBRThHLFNBQVMsRUFBRTtNQUFVLENBQUMsQ0FDdEUsQ0FBQztJQUNIO0lBQ0FkLEtBQUssQ0FBQyxHQUFHcEYsR0FBRyxDQUFDNEksTUFBTSxHQUFHLENBQUMsR0FBRyxHQUFHNUksR0FBRyxDQUFDNEksTUFBTSxVQUFVLEdBQUcsUUFBUSxrQkFBa0IsRUFBRSxPQUFPLEVBQUU7TUFDdkZuRCxXQUFXLEVBQUUsTUFBTTtNQUNuQmtGLFFBQVEsRUFBRUEsQ0FBQSxLQUFNO1FBQ2R0RyxNQUFNLENBQUVXLENBQUMsS0FBTTtVQUFFdEMsT0FBTyxFQUFFc0MsQ0FBQyxDQUFDdEMsT0FBTyxDQUFDcEMsTUFBTSxDQUFDbUssT0FBTztRQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ3ZELElBQUl0RixDQUFDLElBQUlBLENBQUMsQ0FBQ3BELElBQUksS0FBSyxJQUFJLEVBQUU7VUFDeEJvRSxPQUFPLENBQUNDLEdBQUcsQ0FBQ3FFLE9BQU8sQ0FBQ3BFLEdBQUcsQ0FBRUMsQ0FBQyxJQUFLLElBQUFzRSx5QkFBYSxFQUFDekYsQ0FBQyxFQUFFbUIsQ0FBQyxDQUFDckcsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDK0csS0FBSyxDQUFDLE1BQU1DLFNBQVMsQ0FBQztRQUNoRjtNQUNGO0lBQ0YsQ0FBQyxDQUFDO0VBQ0osQ0FBQyxFQUFFLENBQUM1QyxNQUFNLEVBQUVlLEtBQUssQ0FBQyxDQUFDO0VBRW5CLE1BQU15RixZQUFZLEdBQUcsSUFBQXpKLGtCQUFXLEVBQzlCLENBQUMwSixJQUFnQixFQUFFQyxFQUFVLEVBQUVDLEVBQVUsS0FBSztJQUM1QyxNQUFNMUUsQ0FBVSxHQUFHO01BQ2pCckcsRUFBRSxFQUFFLElBQUFnTCxlQUFVLEVBQUNILElBQUksS0FBSyxNQUFNLEdBQUcsTUFBTSxHQUFHQSxJQUFJLENBQUM7TUFDL0NBLElBQUk7TUFDSnpLLENBQUMsRUFBRTBLLEVBQUUsR0FBRyxHQUFHO01BQ1hHLENBQUMsRUFBRUYsRUFBRSxHQUFHLEVBQUU7TUFDVnhDLENBQUMsRUFBRSxHQUFHO01BQ05DLENBQUMsRUFBRSxHQUFHO01BQ04wQyxHQUFHLEVBQUUsQ0FBQztNQUNOQyxLQUFLLEVBQUUsQ0FBQztNQUNSQyxDQUFDLEVBQUUsQ0FBQztNQUNKQyxXQUFXLEVBQUU7SUFDZixDQUFDO0lBQ0QsSUFBSVIsSUFBSSxLQUFLLE1BQU0sRUFBRTtNQUNuQnhFLENBQUMsQ0FBQ2lGLEtBQUssR0FBRyxPQUFPO01BQ2pCakYsQ0FBQyxDQUFDbEUsS0FBSyxHQUFHLFVBQVU7SUFDdEIsQ0FBQyxNQUFNLElBQUkwSSxJQUFJLEtBQUssT0FBTyxFQUFFO01BQzNCeEUsQ0FBQyxDQUFDbEUsS0FBSyxHQUFHLE9BQU87TUFDakJrRSxDQUFDLENBQUNrRixJQUFJLEdBQUcsYUFBYTtNQUN0QmxGLENBQUMsQ0FBQ2tDLENBQUMsR0FBRyxHQUFHO01BQ1RsQyxDQUFDLENBQUNtQyxDQUFDLEdBQUcsR0FBRztJQUNYLENBQUMsTUFBTSxJQUFJcUMsSUFBSSxLQUFLLE9BQU8sRUFBRTtNQUMzQnhFLENBQUMsQ0FBQ2xFLEtBQUssR0FBRyxPQUFPO01BQ2pCa0UsQ0FBQyxDQUFDa0MsQ0FBQyxHQUFHLEdBQUc7TUFDVGxDLENBQUMsQ0FBQ21DLENBQUMsR0FBRyxFQUFFO01BQ1JuQyxDQUFDLENBQUMrRSxDQUFDLEdBQUcsQ0FBQztJQUNULENBQUMsTUFBTSxJQUFJUCxJQUFJLEtBQUssT0FBTyxFQUFFO01BQzNCeEUsQ0FBQyxDQUFDbUYsS0FBSyxHQUFHLE1BQU07TUFDaEJuRixDQUFDLENBQUNsRSxLQUFLLEdBQUcsRUFBRTtNQUNaa0UsQ0FBQyxDQUFDa0MsQ0FBQyxHQUFHLEdBQUc7TUFDVGxDLENBQUMsQ0FBQ21DLENBQUMsR0FBRyxHQUFHO0lBQ1gsQ0FBQyxNQUFNLElBQUlxQyxJQUFJLEtBQUssT0FBTyxFQUFFO01BQzNCeEUsQ0FBQyxDQUFDbEUsS0FBSyxHQUFHLE9BQU87TUFDakJrRSxDQUFDLENBQUNrQyxDQUFDLEdBQUcsR0FBRztNQUNUbEMsQ0FBQyxDQUFDbUMsQ0FBQyxHQUFHLEdBQUc7TUFDVG5DLENBQUMsQ0FBQytFLENBQUMsR0FBRyxDQUFDO0lBQ1QsQ0FBQyxNQUFNLElBQUlQLElBQUksS0FBSyxLQUFLLEVBQUU7TUFDekJ4RSxDQUFDLENBQUNvRixNQUFNLEdBQUcsS0FBSztNQUNoQnBGLENBQUMsQ0FBQ2xFLEtBQUssR0FBRyxPQUFPO0lBQ25CLENBQUMsTUFBTSxJQUFJMEksSUFBSSxLQUFLLFdBQVcsRUFBRTtNQUMvQnhFLENBQUMsQ0FBQ2xFLEtBQUssR0FBRyxjQUFjO0lBQzFCO0lBQ0FpQyxNQUFNLENBQUVXLENBQUMsS0FBTTtNQUNidEMsT0FBTyxFQUFFc0MsQ0FBQyxDQUFDdEMsT0FBTyxDQUFDcEMsTUFBTSxDQUFDZ0csQ0FBQyxDQUFDO01BQzVCckQsU0FBUyxFQUFFLENBQUNxRCxDQUFDLENBQUNyRyxFQUFFLENBQUM7TUFDakJ3RCxTQUFTLEVBQUUsSUFBSTtNQUNmRixhQUFhLEVBQUUsSUFBSTtNQUNuQnhCLElBQUksRUFBRTtJQUNSLENBQUMsQ0FBQyxDQUFDO0lBQ0grRCxVQUFVLENBQUMsQ0FBQ1EsQ0FBQyxDQUFDLEVBQUUsbUJBQW1CQSxDQUFDLENBQUNyRyxFQUFFLE1BQU0sRUFBRSxNQUFNLENBQUM7RUFDeEQsQ0FBQyxFQUNELENBQUNvRSxNQUFNLEVBQUV5QixVQUFVLENBQ3JCLENBQUM7O0VBRUQ7RUFDQTtFQUNBO0VBQ0E7O0VBRUE7QUFDRjtBQUNBO0VBQ0UsTUFBTTZGLFdBQVcsR0FBRyxJQUFBdkssa0JBQVcsRUFDN0IsT0FBTzJKLEVBQVUsRUFBRUMsRUFBVSxLQUFLO0lBQ2hDLE1BQU01RCxNQUFNLEdBQUd6QixRQUFRLENBQUN2QixPQUFPO0lBQy9CLElBQUksQ0FBQ2dELE1BQU0sRUFBRTtNQUNYaEMsS0FBSyxDQUFDLDJDQUEyQyxFQUFFLE1BQU0sRUFBRTtRQUFFYyxTQUFTLEVBQUU7TUFBZSxDQUFDLENBQUM7TUFDekY7SUFDRjtJQUNBN0IsTUFBTSxDQUFDO01BQUVMLElBQUksRUFBRTtJQUFlLENBQUMsQ0FBQztJQUNoQyxJQUFJO01BQ0YsTUFBTTRILEdBQUcsR0FBRyxNQUFNLElBQUFDLGtCQUFRLEVBQUM7UUFDekI5SixJQUFJLEVBQUUsV0FBVztRQUNqQitKLEtBQUssRUFBRSxDQUFDLE1BQU0sSUFBQUMsd0JBQWMsRUFBQzNFLE1BQU0sQ0FBQyxDQUFDO1FBQ3JDNEUsVUFBVSxFQUFFLENBQUMsb0JBQW9CLENBQUM7UUFDbENDLFNBQVMsRUFBRSxDQUFDN0UsTUFBTSxDQUFDckYsSUFBSSxDQUFDO1FBQ3hCSyxLQUFLLEVBQUUsY0FBYztRQUNyQjhKLE9BQU8sRUFBRSxDQUNQO1VBQUVDLEtBQUssRUFBRSxRQUFRO1VBQUVDLFVBQVUsRUFBRSxDQUFDLE1BQU0sRUFBRSxNQUFNLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLE9BQU87UUFBRSxDQUFDLEVBQzVGO1VBQUVELEtBQUssRUFBRSxXQUFXO1VBQUVDLFVBQVUsRUFBRTtRQUFHLENBQUM7TUFFMUMsQ0FBQyxDQUFDO01BQ0YsSUFBSSxDQUFDUixHQUFHLEVBQUUsT0FBTyxDQUFDO01BQ2xCLE1BQU0zTSxHQUFHLEdBQUcsSUFBQW9OLGlCQUFPLEVBQUNULEdBQUcsQ0FBQ1UsT0FBTyxDQUFDO01BQ2hDLElBQUksQ0FBQ3JOLEdBQUcsRUFBRTtRQUNSbUcsS0FBSyxDQUFDLDhCQUE4QixFQUFFLE9BQU8sRUFBRTtVQUFFYyxTQUFTLEVBQUU7UUFBVSxDQUFDLENBQUM7UUFDeEU7TUFDRjtNQUNBLE1BQU1xQyxJQUFJLEdBQUcsTUFBTSxJQUFBZ0UsMEJBQWMsRUFBQ25GLE1BQU0sRUFBRW5JLEdBQUcsQ0FBQztNQUM5QyxNQUFNcUgsQ0FBVSxHQUFHO1FBQ2pCckcsRUFBRSxFQUFFLElBQUFnTCxlQUFVLEVBQUMsS0FBSyxDQUFDO1FBQ3JCSCxJQUFJLEVBQUUsS0FBSztRQUNYekssQ0FBQyxFQUFFMEssRUFBRSxHQUFHLEdBQUc7UUFDWEcsQ0FBQyxFQUFFRixFQUFFLEdBQUcsRUFBRTtRQUNWeEMsQ0FBQyxFQUFFLEdBQUc7UUFDTkMsQ0FBQyxFQUFFLEdBQUc7UUFDTjBDLEdBQUcsRUFBRSxDQUFDO1FBQ05DLEtBQUssRUFBRSxDQUFDO1FBQ1JDLENBQUMsRUFBRSxDQUFDO1FBQ0pqSixLQUFLLEVBQUVtRyxJQUFJO1FBQ1hpRCxJQUFJLEVBQUUsb0JBQW9CakQsSUFBSSxNQUFNO1FBQ3BDbUQsTUFBTSxFQUFFLElBQUk7UUFDWkosV0FBVyxFQUFFO01BQ2YsQ0FBQztNQUNEakgsTUFBTSxDQUFFVyxDQUFDLEtBQU07UUFDYnRDLE9BQU8sRUFBRXNDLENBQUMsQ0FBQ3RDLE9BQU8sQ0FBQ3BDLE1BQU0sQ0FBQ2dHLENBQUMsQ0FBQztRQUM1QnJELFNBQVMsRUFBRSxDQUFDcUQsQ0FBQyxDQUFDckcsRUFBRSxDQUFDO1FBQ2pCd0QsU0FBUyxFQUFFLElBQUk7UUFDZkYsYUFBYSxFQUFFLElBQUk7UUFDbkJ4QixJQUFJLEVBQUUsTUFBTTtRQUNaNkIsTUFBTSxFQUFFO01BQ1YsQ0FBQyxDQUFDLENBQUM7TUFDSGtDLFVBQVUsQ0FBQyxDQUFDUSxDQUFDLENBQUMsRUFBRSxtQkFBbUJpQyxJQUFJLEVBQUUsRUFBRSxPQUFPLENBQUM7SUFDckQsQ0FBQyxDQUFDLE9BQU9uSixDQUFDLEVBQUU7TUFDVmdHLEtBQUssQ0FBQyx3QkFBd0JqRyxNQUFNLENBQUNDLENBQUMsQ0FBQyxFQUFFLEVBQUUsT0FBTyxFQUFFO1FBQUU4RyxTQUFTLEVBQUU7TUFBVSxDQUFDLENBQUM7SUFDL0UsQ0FBQyxTQUFTO01BQ1I3QixNQUFNLENBQUM7UUFBRUwsSUFBSSxFQUFFO01BQUssQ0FBQyxDQUFDO0lBQ3hCO0VBQ0YsQ0FBQyxFQUNELENBQUNvQixLQUFLLEVBQUVmLE1BQU0sRUFBRXlCLFVBQVUsQ0FDNUIsQ0FBQzs7RUFFRDtFQUNBLE1BQU0wRyxhQUFhLEdBQUcsSUFBQXBMLGtCQUFXLEVBQy9CLE1BQU9nRyxNQUFtQixJQUFLO0lBQzdCLE1BQU1xRixLQUFLLEdBQUcsTUFBTSxJQUFBQyxxQkFBUyxFQUFDdEYsTUFBTSxDQUFDO0lBQ3JDekIsUUFBUSxDQUFDdkIsT0FBTyxHQUFHZ0QsTUFBTTtJQUN6QjtJQUNBO0lBQ0E7SUFDQTtJQUNBLE1BQU11RixRQUFRLEdBQUd2RixNQUFNLENBQUNyRixJQUFJLEtBQUssSUFBSSxJQUFLLE9BQU8wSyxLQUFLLENBQUNHLE1BQU0sS0FBSyxRQUFRLElBQUlILEtBQUssQ0FBQ0csTUFBTSxHQUFHcE0sZ0JBQWlCO0lBQzlHNkQsTUFBTSxDQUFDO01BQ0wzQixPQUFPLEVBQUUrSixLQUFLLENBQUMvSixPQUFPO01BQ3RCRSxLQUFLLEVBQUU2SixLQUFLLENBQUM3SixLQUFLLENBQUNnRyxNQUFNLEdBQUc2RCxLQUFLLENBQUM3SixLQUFLLEdBQUdDLHFCQUFVLENBQUNDLEtBQUssQ0FBQyxDQUFDO01BQzVEQyxRQUFRLEVBQUUwSixLQUFLLENBQUMxSixRQUFRLENBQUM2RixNQUFNLEdBQUc2RCxLQUFLLENBQUMxSixRQUFRLEdBQUdDLHdCQUFhO01BQ2hFZixFQUFFLEVBQUV3SyxLQUFLLENBQUN0SyxVQUFVLElBQUkrQixRQUFRLENBQUNFLE9BQU8sQ0FBQ25DLEVBQUU7TUFDM0NHLEtBQUssRUFBRXFLLEtBQUssQ0FBQ3JLLEtBQUssSUFBSThCLFFBQVEsQ0FBQ0UsT0FBTyxDQUFDaEMsS0FBSztNQUM1Q0wsSUFBSSxFQUFFNEssUUFBUSxHQUFHLEtBQUssR0FBR3pJLFFBQVEsQ0FBQ0UsT0FBTyxDQUFDckMsSUFBSTtNQUM5Q2tCLFNBQVMsRUFBRSxFQUFFO01BQ2I7TUFDQTtNQUNBO01BQ0FJLFdBQVcsRUFBRSxJQUFJO01BQ2pCQyxhQUFhLEVBQUUsSUFBSTtNQUNuQkMsYUFBYSxFQUFFLEtBQUs7TUFDcEJLLE1BQU0sRUFBRTtJQUNWLENBQUMsQ0FBQztFQUNKLENBQUMsRUFDRCxDQUFDUyxNQUFNLENBQ1QsQ0FBQzs7RUFFRDtBQUNGO0VBQ0UsTUFBTXdJLFdBQVcsR0FBRyxJQUFBekwsa0JBQVcsRUFDN0IsTUFBTzBMLEtBQWtCLElBQUs7SUFDNUJ6SSxNQUFNLENBQUM7TUFBRUwsSUFBSSxFQUFFO0lBQWEsQ0FBQyxDQUFDO0lBQzlCLElBQUk7TUFDRixNQUFNNEgsR0FBRyxHQUFHLE1BQU0sSUFBQUMsa0JBQVEsRUFBQztRQUN6QjlKLElBQUksRUFBRSxhQUFhO1FBQ25CK0osS0FBSyxFQUFFLENBQUMsTUFBTSxJQUFBQyx3QkFBYyxFQUFDZSxLQUFLLENBQUMsQ0FBQztRQUNwQ2QsVUFBVSxFQUFFLENBQUMsa0JBQWtCLENBQUM7UUFDaENDLFNBQVMsRUFBRSxDQUFDYSxLQUFLLENBQUMvSyxJQUFJLENBQUM7UUFDdkJLLEtBQUssRUFBRTtNQUNULENBQUMsQ0FBQztNQUNGLElBQUksQ0FBQ3dKLEdBQUcsRUFBRTtNQUNWLE1BQU0zTSxHQUFHLEdBQUcsSUFBQW9OLGlCQUFPLEVBQUNULEdBQUcsQ0FBQ1UsT0FBTyxDQUFDO01BQ2hDLElBQUksQ0FBQ3JOLEdBQUcsRUFBRTtRQUNSbUcsS0FBSyxDQUFDLDhCQUE4QixFQUFFLE9BQU8sRUFBRTtVQUFFYyxTQUFTLEVBQUU7UUFBVSxDQUFDLENBQUM7UUFDeEU7TUFDRjtNQUNBLE1BQU02RyxTQUFzQixHQUFHO1FBQUUvTixJQUFJLEVBQUVELE9BQU8sQ0FBQytOLEtBQUssQ0FBQzlOLElBQUksRUFBRUMsR0FBRyxDQUFDO1FBQUU4QyxJQUFJLEVBQUUrSyxLQUFLLENBQUMvSyxJQUFJO1FBQUVpTCxPQUFPLEVBQUVGLEtBQUssQ0FBQ0U7TUFBUSxDQUFDO01BQzNHLElBQUksRUFBRSxNQUFNLElBQUFDLHlCQUFhLEVBQUNGLFNBQVMsQ0FBQyxDQUFDLElBQUksRUFBRSxNQUFNLElBQUFHLHVCQUFXLEVBQUNILFNBQVMsQ0FBQyxDQUFDLEVBQUU7UUFDeEUzSCxLQUFLLENBQUMsNkVBQTZFLEVBQUUsT0FBTyxFQUFFO1VBQzVGYyxTQUFTLEVBQUU7UUFDYixDQUFDLENBQUM7UUFDRjtNQUNGO01BQ0EsTUFBTXNHLGFBQWEsQ0FBQ08sU0FBUyxDQUFDO01BQzlCM0gsS0FBSyxDQUFDLGVBQWUsRUFBRSxPQUFPLENBQUM7SUFDakMsQ0FBQyxDQUFDLE9BQU9oRyxDQUFDLEVBQUU7TUFDVmdHLEtBQUssQ0FBQyxzQkFBc0JqRyxNQUFNLENBQUNDLENBQUMsQ0FBQyxFQUFFLEVBQUUsT0FBTyxFQUFFO1FBQUU4RyxTQUFTLEVBQUU7TUFBVSxDQUFDLENBQUM7SUFDN0UsQ0FBQyxTQUFTO01BQ1I3QixNQUFNLENBQUM7UUFBRUwsSUFBSSxFQUFFO01BQUssQ0FBQyxDQUFDO0lBQ3hCO0VBQ0YsQ0FBQyxFQUNELENBQUNvQixLQUFLLEVBQUVmLE1BQU0sRUFBRW1JLGFBQWEsQ0FDL0IsQ0FBQzs7RUFFRDtBQUNGO0FBQ0E7RUFDRSxNQUFNVyxXQUFXLEdBQUcsSUFBQS9MLGtCQUFXLEVBQzdCLE1BQU9nRyxNQUFtQixJQUFLO0lBQzdCL0MsTUFBTSxDQUFDO01BQUVMLElBQUksRUFBRTtJQUFhLENBQUMsQ0FBQztJQUM5QixJQUFJO01BQ0YsTUFBTXdJLGFBQWEsQ0FBQ3BGLE1BQU0sQ0FBQztNQUMzQmhDLEtBQUssQ0FBQyxlQUFlLEVBQUUsT0FBTyxDQUFDO0lBQ2pDLENBQUMsQ0FBQyxPQUFPaEcsQ0FBQyxFQUFFO01BQ1ZnRyxLQUFLLENBQUMsc0JBQXNCakcsTUFBTSxDQUFDQyxDQUFDLENBQUMsRUFBRSxFQUFFLE9BQU8sRUFBRTtRQUFFOEcsU0FBUyxFQUFFO01BQVUsQ0FBQyxDQUFDO0lBQzdFLENBQUMsU0FBUztNQUNSN0IsTUFBTSxDQUFDO1FBQUVMLElBQUksRUFBRTtNQUFLLENBQUMsQ0FBQztJQUN4QjtFQUNGLENBQUMsRUFDRCxDQUFDb0IsS0FBSyxFQUFFZixNQUFNLEVBQUVtSSxhQUFhLENBQy9CLENBQUM7O0VBRUQ7QUFDRjtFQUNFLE1BQU1ZLFVBQVUsR0FBRyxJQUFBaE0sa0JBQVcsRUFDNUIsTUFBTzBMLEtBQWtCLElBQUs7SUFDNUIsSUFBSUEsS0FBSyxDQUFDL0ssSUFBSSxLQUFLLElBQUksRUFBRTtNQUN2QnFELEtBQUssQ0FBQywyREFBMkQsRUFBRSxNQUFNLEVBQUU7UUFBRWMsU0FBUyxFQUFFO01BQWUsQ0FBQyxDQUFDO01BQ3pHO0lBQ0Y7SUFDQTdCLE1BQU0sQ0FBQztNQUFFTCxJQUFJLEVBQUU7SUFBWSxDQUFDLENBQUM7SUFDN0IsSUFBSTtNQUNGLE1BQU00SCxHQUFHLEdBQUcsTUFBTSxJQUFBQyxrQkFBUSxFQUFDO1FBQ3pCOUosSUFBSSxFQUFFLGFBQWE7UUFDbkIrSixLQUFLLEVBQUUsQ0FBQyxNQUFNLElBQUFDLHdCQUFjLEVBQUNlLEtBQUssQ0FBQyxDQUFDO1FBQ3BDZCxVQUFVLEVBQUUsQ0FBQyxrQkFBa0IsQ0FBQztRQUNoQ0MsU0FBUyxFQUFFLENBQUNhLEtBQUssQ0FBQy9LLElBQUksQ0FBQztRQUN2QkssS0FBSyxFQUFFLDZCQUE2QjtRQUNwQ2lMLGlCQUFpQixFQUFFO01BQ3JCLENBQUMsQ0FBQztNQUNGLElBQUksQ0FBQ3pCLEdBQUcsRUFBRTtNQUNWLE1BQU0zTSxHQUFHLEdBQUcsSUFBQW9OLGlCQUFPLEVBQUNULEdBQUcsQ0FBQ1UsT0FBTyxDQUFDO01BQ2hDLElBQUksQ0FBQ3JOLEdBQUcsRUFBRTtRQUNSbUcsS0FBSyxDQUFDLDRCQUE0QixFQUFFLE9BQU8sRUFBRTtVQUFFYyxTQUFTLEVBQUU7UUFBVSxDQUFDLENBQUM7UUFDdEU7TUFDRjtNQUNBLE1BQU02RyxTQUFzQixHQUFHO1FBQUUvTixJQUFJLEVBQUVELE9BQU8sQ0FBQytOLEtBQUssQ0FBQzlOLElBQUksRUFBRUMsR0FBRyxDQUFDO1FBQUU4QyxJQUFJLEVBQUUsSUFBSTtRQUFFaUwsT0FBTyxFQUFFRixLQUFLLENBQUNFO01BQVEsQ0FBQztNQUNyRyxNQUFNNUssS0FBSyxHQUFHbkQsR0FBRyxDQUFDcU8sS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDQyxHQUFHLENBQUMsQ0FBQyxJQUFJLGdCQUFnQjtNQUN0RCxNQUFNLElBQUFDLHlCQUFhLEVBQUNULFNBQVMsRUFBRTNLLEtBQUssQ0FBQztNQUNyQyxNQUFNb0ssYUFBYSxDQUFDTyxTQUFTLENBQUM7TUFDOUIzSCxLQUFLLENBQUMsZ0JBQWdCLEVBQUUsT0FBTyxDQUFDO0lBQ2xDLENBQUMsQ0FBQyxPQUFPaEcsQ0FBQyxFQUFFO01BQ1ZnRyxLQUFLLENBQUMsd0JBQXdCakcsTUFBTSxDQUFDQyxDQUFDLENBQUMsRUFBRSxFQUFFLE9BQU8sRUFBRTtRQUFFOEcsU0FBUyxFQUFFO01BQVUsQ0FBQyxDQUFDO0lBQy9FLENBQUMsU0FBUztNQUNSN0IsTUFBTSxDQUFDO1FBQUVMLElBQUksRUFBRTtNQUFLLENBQUMsQ0FBQztJQUN4QjtFQUNGLENBQUMsRUFDRCxDQUFDb0IsS0FBSyxFQUFFZixNQUFNLEVBQUVtSSxhQUFhLENBQy9CLENBQUM7O0VBRUQ7RUFDQSxNQUFNaUIsU0FBUyxHQUFHLElBQUFyTSxrQkFBVyxFQUFDLE1BQU07SUFDbEMsTUFBTTBMLEtBQUssR0FBR25ILFFBQVEsQ0FBQ3ZCLE9BQU87SUFDOUIsSUFBSSxDQUFDMEksS0FBSyxFQUFFO01BQ1YxSCxLQUFLLENBQUMsMENBQTBDLEVBQUUsTUFBTSxFQUFFO1FBQUVjLFNBQVMsRUFBRTtNQUFlLENBQUMsQ0FBQztNQUN4RjtJQUNGO0lBQ0EsS0FBSzJHLFdBQVcsQ0FBQ0MsS0FBSyxDQUFDO0VBQ3pCLENBQUMsRUFBRSxDQUFDMUgsS0FBSyxFQUFFeUgsV0FBVyxDQUFDLENBQUM7RUFFeEIsTUFBTWEsUUFBUSxHQUFHLElBQUF0TSxrQkFBVyxFQUFDLE1BQU07SUFDakMsTUFBTTBMLEtBQUssR0FBR25ILFFBQVEsQ0FBQ3ZCLE9BQU87SUFDOUIsSUFBSSxDQUFDMEksS0FBSyxFQUFFO01BQ1YxSCxLQUFLLENBQUMsMENBQTBDLEVBQUUsTUFBTSxFQUFFO1FBQUVjLFNBQVMsRUFBRTtNQUFlLENBQUMsQ0FBQztNQUN4RjtJQUNGO0lBQ0EsS0FBS2tILFVBQVUsQ0FBQ04sS0FBSyxDQUFDO0VBQ3hCLENBQUMsRUFBRSxDQUFDMUgsS0FBSyxFQUFFZ0ksVUFBVSxDQUFDLENBQUM7O0VBRXZCO0FBQ0Y7RUFDRSxNQUFNTyxRQUFRLEdBQUcsSUFBQXZNLGtCQUFXLEVBQUMsWUFBWTtJQUN2QyxJQUFJO01BQ0YsTUFBTXdNLE9BQU8sR0FBRyxNQUFNLElBQUFDLHNCQUFZLEVBQUMsQ0FBQztNQUNwQyxJQUFJLENBQUNELE9BQU8sRUFBRSxPQUFPLENBQUM7TUFDdEIsTUFBTWQsS0FBa0IsR0FBRztRQUFFOU4sSUFBSSxFQUFFNE8sT0FBTyxDQUFDRSxJQUFJO1FBQUUvTCxJQUFJLEVBQUU2TCxPQUFPLENBQUM3TCxJQUFJO1FBQUVpTCxPQUFPLEVBQUVZLE9BQU8sQ0FBQzNOO01BQUcsQ0FBQztNQUMxRixNQUFNNE0sV0FBVyxDQUFDQyxLQUFLLENBQUM7SUFDMUIsQ0FBQyxDQUFDLE9BQU8xTixDQUFDLEVBQUU7TUFDVmdHLEtBQUssQ0FBQyx1QkFBdUJqRyxNQUFNLENBQUNDLENBQUMsQ0FBQyxFQUFFLEVBQUUsT0FBTyxFQUFFO1FBQUU4RyxTQUFTLEVBQUU7TUFBVSxDQUFDLENBQUM7SUFDOUU7RUFDRixDQUFDLEVBQUUsQ0FBQ2QsS0FBSyxFQUFFeUgsV0FBVyxDQUFDLENBQUM7RUFFeEIsTUFBTWtCLFdBQVcsR0FBRyxJQUFBM00sa0JBQVcsRUFDN0IsQ0FBQ25CLEVBQVUsRUFBRXFFLEtBQXVCLEtBQUs7SUFDdkNELE1BQU0sQ0FBRVcsQ0FBQyxLQUFNO01BQUV0QyxPQUFPLEVBQUVzQyxDQUFDLENBQUN0QyxPQUFPLENBQUMyRCxHQUFHLENBQUVDLENBQUMsSUFBTUEsQ0FBQyxDQUFDckcsRUFBRSxLQUFLQSxFQUFFLEdBQUc7UUFBRSxHQUFHcUcsQ0FBQztRQUFFLEdBQUdoQztNQUFNLENBQUMsR0FBR2dDLENBQUU7SUFBRSxDQUFDLENBQUMsQ0FBQztJQUMxRkcsWUFBWSxDQUFDLENBQUN4RyxFQUFFLENBQUMsQ0FBQztFQUNwQixDQUFDLEVBQ0QsQ0FBQ29FLE1BQU0sRUFBRW9DLFlBQVksQ0FDdkIsQ0FBQztFQUVELE1BQU11SCxhQUFhLEdBQUcsSUFBQTVNLGtCQUFXLEVBQy9CLENBQUNzRyxJQUFZLEVBQUV1RyxFQUFVLEtBQUs7SUFDNUIsTUFBTTVPLENBQWEsR0FBRztNQUFFNE8sRUFBRTtNQUFFbkQsSUFBSSxFQUFFLE9BQU87TUFBRW9ELEtBQUssRUFBRTtRQUFFQyxNQUFNLEVBQUUsUUFBUTtRQUFFQyxJQUFJLEVBQUU7TUFBTTtJQUFFLENBQUM7SUFDckYsTUFBTUMsR0FBRyxHQUFHbkssUUFBUSxDQUFDRSxPQUFPLENBQUMxQixPQUFPLENBQUNxRSxJQUFJLENBQUVULENBQUMsSUFBS0EsQ0FBQyxDQUFDckcsRUFBRSxLQUFLeUgsSUFBSSxDQUFDO0lBQy9ELE1BQU00RyxPQUFPLEdBQUdELEdBQUcsR0FBRztNQUFFLEdBQUdBLEdBQUc7TUFBRS9DLFdBQVcsRUFBRStDLEdBQUcsQ0FBQy9DLFdBQVcsQ0FBQ2hMLE1BQU0sQ0FBQ2pCLENBQUM7SUFBRSxDQUFDLEdBQUcsSUFBSTtJQUMvRWdGLE1BQU0sQ0FBRVcsQ0FBQyxLQUFNO01BQUV0QyxPQUFPLEVBQUVzQyxDQUFDLENBQUN0QyxPQUFPLENBQUMyRCxHQUFHLENBQUVDLENBQUMsSUFBTUEsQ0FBQyxDQUFDckcsRUFBRSxLQUFLeUgsSUFBSSxHQUFHO1FBQUUsR0FBR3BCLENBQUM7UUFBRWdGLFdBQVcsRUFBRWhGLENBQUMsQ0FBQ2dGLFdBQVcsQ0FBQ2hMLE1BQU0sQ0FBQ2pCLENBQUM7TUFBRSxDQUFDLEdBQUdpSCxDQUFFO0lBQUUsQ0FBQyxDQUFDLENBQUM7SUFDeEgsSUFBSWdJLE9BQU8sRUFBRXhJLFVBQVUsQ0FBQyxDQUFDd0ksT0FBTyxDQUFDLEVBQUUsYUFBYTVHLElBQUksTUFBTXVHLEVBQUUsRUFBRSxDQUFDO0VBQ2pFLENBQUMsRUFDRCxDQUFDNUosTUFBTSxFQUFFeUIsVUFBVSxDQUNyQixDQUFDOztFQUVEO0VBQ0E7QUFDRjtBQUNBO0FBQ0E7RUFDRSxNQUFNeUksWUFBWSxHQUFHLElBQUFuTixrQkFBVyxFQUFDLE1BQU07SUFDckMsTUFBTTRELENBQUMsR0FBR2QsUUFBUSxDQUFDRSxPQUFPO0lBQzFCLElBQUlZLENBQUMsQ0FBQy9CLFNBQVMsQ0FBQzJGLE1BQU0sS0FBSyxDQUFDLEVBQUU7SUFDOUIsTUFBTWxCLElBQUksR0FBRzFDLENBQUMsQ0FBQy9CLFNBQVMsQ0FBQyxDQUFDLENBQUM7SUFDM0IsTUFBTXVMLEtBQUssR0FBR3hKLENBQUMsQ0FBQ3RDLE9BQU8sQ0FBQ0ksS0FBSyxDQUFDLENBQUMsQ0FBQzJMLElBQUksQ0FBQyxDQUFDQyxDQUFDLEVBQUVDLENBQUMsS0FBSyxDQUFDRCxDQUFDLENBQUNyRCxDQUFDLElBQUksQ0FBQyxLQUFLc0QsQ0FBQyxDQUFDdEQsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUNoRixHQUFHLENBQUVDLENBQUMsSUFBS0EsQ0FBQyxDQUFDckcsRUFBRSxDQUFDLENBQUNHLE1BQU0sQ0FBRUgsRUFBRSxJQUFLQSxFQUFFLEtBQUt5SCxJQUFJLENBQUM7SUFDcEhyRCxNQUFNLENBQUM7TUFBRWhCLFdBQVcsRUFBRXFFLElBQUk7TUFBRXBFLGFBQWEsRUFBRWtMLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxJQUFJO01BQUVqTCxhQUFhLEVBQUU7SUFBTSxDQUFDLENBQUM7RUFDdEYsQ0FBQyxFQUFFLENBQUNjLE1BQU0sQ0FBQyxDQUFDO0VBRVosTUFBTXVLLFVBQVUsR0FBRyxJQUFBeE4sa0JBQVcsRUFDM0J5TixNQUFlLElBQUs7SUFDbkIsTUFBTTdKLENBQUMsR0FBR2QsUUFBUSxDQUFDRSxPQUFPO0lBQzFCLElBQUksQ0FBQ1ksQ0FBQyxDQUFDM0IsV0FBVyxFQUFFO0lBQ3BCLElBQUl3TCxNQUFNLElBQUk3SixDQUFDLENBQUMxQixhQUFhLEVBQUUwSyxhQUFhLENBQUNoSixDQUFDLENBQUMzQixXQUFXLEVBQUUyQixDQUFDLENBQUMxQixhQUFhLENBQUM7SUFDNUVlLE1BQU0sQ0FBQztNQUFFaEIsV0FBVyxFQUFFLElBQUk7TUFBRUMsYUFBYSxFQUFFO0lBQUssQ0FBQyxDQUFDO0VBQ3BELENBQUMsRUFDRCxDQUFDZSxNQUFNLEVBQUUySixhQUFhLENBQ3hCLENBQUM7RUFFRCxNQUFNYyxpQkFBaUIsR0FBRyxJQUFBMU4sa0JBQVcsRUFDbEMyTixHQUFXLElBQUs7SUFDZjFLLE1BQU0sQ0FBRVcsQ0FBQyxJQUFLO01BQ1osSUFBSSxDQUFDQSxDQUFDLENBQUMzQixXQUFXLEVBQUUsT0FBTyxDQUFDLENBQUM7TUFDN0IsTUFBTW1MLEtBQUssR0FBR3hKLENBQUMsQ0FBQ3RDLE9BQU8sQ0FBQ0ksS0FBSyxDQUFDLENBQUMsQ0FBQzJMLElBQUksQ0FBQyxDQUFDQyxDQUFDLEVBQUVDLENBQUMsS0FBSyxDQUFDRCxDQUFDLENBQUNyRCxDQUFDLElBQUksQ0FBQyxLQUFLc0QsQ0FBQyxDQUFDdEQsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUNoRixHQUFHLENBQUVDLENBQUMsSUFBS0EsQ0FBQyxDQUFDckcsRUFBRSxDQUFDLENBQUNHLE1BQU0sQ0FBRUgsRUFBRSxJQUFLQSxFQUFFLEtBQUsrRSxDQUFDLENBQUMzQixXQUFXLENBQUM7TUFDN0gsSUFBSSxDQUFDbUwsS0FBSyxDQUFDNUYsTUFBTSxFQUFFLE9BQU8sQ0FBQyxDQUFDO01BQzVCLE1BQU1hLEdBQUcsR0FBRytFLEtBQUssQ0FBQ1EsT0FBTyxDQUFDaEssQ0FBQyxDQUFDMUIsYUFBYSxJQUFJa0wsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO01BQ3RELE9BQU87UUFBRWxMLGFBQWEsRUFBRWtMLEtBQUssQ0FBQyxDQUFDL0UsR0FBRyxHQUFHc0YsR0FBRyxHQUFHUCxLQUFLLENBQUM1RixNQUFNLElBQUk0RixLQUFLLENBQUM1RixNQUFNO01BQUUsQ0FBQztJQUM1RSxDQUFDLENBQUM7RUFDSixDQUFDLEVBQ0QsQ0FBQ3ZFLE1BQU0sQ0FDVCxDQUFDOztFQUVEO0VBQ0EsTUFBTTRLLFlBQVksR0FBRyxJQUFBN04sa0JBQVcsRUFDN0JoQyxDQUFxQixJQUFLO0lBQ3pCLE1BQU00RixDQUFDLEdBQUdkLFFBQVEsQ0FBQ0UsT0FBTztJQUMxQixJQUFJWSxDQUFDLENBQUN2QixTQUFTLEVBQUVZLE1BQU0sQ0FBQztNQUFFWixTQUFTLEVBQUU7SUFBSyxDQUFDLENBQUM7SUFDNUMsSUFBSXVCLENBQUMsQ0FBQ25CLFlBQVksRUFBRVEsTUFBTSxDQUFDO01BQUVSLFlBQVksRUFBRTtJQUFNLENBQUMsQ0FBQztJQUNuRCxNQUFNcUwsR0FBRyxHQUFHOVAsQ0FBQyxDQUFDK1AsTUFBTSxLQUFLLENBQUM7SUFDMUIsSUFBSW5LLENBQUMsQ0FBQ2pELElBQUksS0FBSyxNQUFNLElBQUksQ0FBQ0wsUUFBUSxDQUFDMEMsT0FBTyxJQUFJLENBQUM4SyxHQUFHLElBQUksQ0FBQzFLLFFBQVEsQ0FBQyxDQUFDLEVBQUU7TUFDakUsTUFBTSxDQUFDTSxFQUFFLEVBQUVDLEVBQUUsQ0FBQyxHQUFHTixVQUFVLENBQUNyRixDQUFDLENBQUM7TUFDOUIsSUFBSSxDQUFDQSxDQUFDLENBQUNnUSxRQUFRLEVBQUUvSyxNQUFNLENBQUM7UUFBRXBCLFNBQVMsRUFBRTtNQUFHLENBQUMsQ0FBQztNQUMxQzNCLE9BQU8sQ0FBQzhDLE9BQU8sR0FBRztRQUFFaUwsSUFBSSxFQUFFLFNBQVM7UUFBRUMsRUFBRSxFQUFFeEssRUFBRTtRQUFFeUssRUFBRSxFQUFFeEssRUFBRTtRQUFFeUssR0FBRyxFQUFFcFEsQ0FBQyxDQUFDZ1EsUUFBUTtRQUFFSyxJQUFJLEVBQUV6SyxDQUFDLENBQUMvQixTQUFTLENBQUNILEtBQUssQ0FBQztNQUFFLENBQUM7TUFDakd1QixNQUFNLENBQUM7UUFBRWxCLE9BQU8sRUFBRTtVQUFFOUMsQ0FBQyxFQUFFeUUsRUFBRTtVQUFFb0csQ0FBQyxFQUFFbkcsRUFBRTtVQUFFeUQsQ0FBQyxFQUFFLENBQUM7VUFBRUMsQ0FBQyxFQUFFO1FBQUU7TUFBRSxDQUFDLENBQUM7SUFDbkQsQ0FBQyxNQUFNO01BQ0xuSCxPQUFPLENBQUM4QyxPQUFPLEdBQUc7UUFBRWlMLElBQUksRUFBRSxLQUFLO1FBQUVDLEVBQUUsRUFBRWxRLENBQUMsQ0FBQ3NGLE9BQU87UUFBRTZLLEVBQUUsRUFBRW5RLENBQUMsQ0FBQ3VGLE9BQU87UUFBRXJDLEVBQUUsRUFBRTBDLENBQUMsQ0FBQzNDLEdBQUcsQ0FBQ0MsRUFBRTtRQUFFQyxFQUFFLEVBQUV5QyxDQUFDLENBQUMzQyxHQUFHLENBQUNFO01BQUcsQ0FBQztNQUMzRjhCLE1BQU0sQ0FBQztRQUFFUCxPQUFPLEVBQUU7TUFBSyxDQUFDLENBQUM7SUFDM0I7RUFDRixDQUFDLEVBQ0QsQ0FBQ08sTUFBTSxFQUFFRyxRQUFRLEVBQUVDLFVBQVUsQ0FDL0IsQ0FBQztFQUVELE1BQU1pTCxjQUFjLEdBQUcsSUFBQXRPLGtCQUFXLEVBQ2hDLENBQUNuQixFQUFVLEVBQUViLENBQXFCLEtBQUs7SUFDckNBLENBQUMsQ0FBQ3VRLGVBQWUsQ0FBQyxDQUFDO0lBQ25CLE1BQU0zSyxDQUFDLEdBQUdkLFFBQVEsQ0FBQ0UsT0FBTztJQUMxQixJQUFJWSxDQUFDLENBQUNqRCxJQUFJLEtBQUssTUFBTSxFQUFFO01BQ3JCVCxPQUFPLENBQUM4QyxPQUFPLEdBQUc7UUFBRWlMLElBQUksRUFBRSxLQUFLO1FBQUVDLEVBQUUsRUFBRWxRLENBQUMsQ0FBQ3NGLE9BQU87UUFBRTZLLEVBQUUsRUFBRW5RLENBQUMsQ0FBQ3VGLE9BQU87UUFBRXJDLEVBQUUsRUFBRTBDLENBQUMsQ0FBQzNDLEdBQUcsQ0FBQ0MsRUFBRTtRQUFFQyxFQUFFLEVBQUV5QyxDQUFDLENBQUMzQyxHQUFHLENBQUNFO01BQUcsQ0FBQztNQUMzRjhCLE1BQU0sQ0FBQztRQUFFUCxPQUFPLEVBQUU7TUFBSyxDQUFDLENBQUM7TUFDekI7SUFDRjtJQUNBLE1BQU13QyxDQUFDLEdBQUd0QixDQUFDLENBQUN0QyxPQUFPLENBQUNxRSxJQUFJLENBQUUxRyxDQUFDLElBQUtBLENBQUMsQ0FBQ0osRUFBRSxLQUFLQSxFQUFFLENBQUM7SUFDNUMsSUFBSSxDQUFDcUcsQ0FBQyxFQUFFO0lBQ1I7SUFDQSxNQUFNdEcsR0FBRyxHQUFHRCxjQUFjLENBQUNpRixDQUFDLENBQUMvQixTQUFTLEVBQUVoRCxFQUFFLEVBQUViLENBQUMsQ0FBQ2dRLFFBQVEsQ0FBQztJQUN2RC9LLE1BQU0sQ0FBQztNQUFFcEIsU0FBUyxFQUFFakQsR0FBRztNQUFFdUQsYUFBYSxFQUFFLElBQUk7TUFBRUUsU0FBUyxFQUFFO0lBQUssQ0FBQyxDQUFDO0lBQ2hFLElBQUk2QyxDQUFDLENBQUNzSixNQUFNLEVBQUU7SUFDZCxNQUFNQyxJQUE4QyxHQUFHLENBQUMsQ0FBQztJQUN6RDdLLENBQUMsQ0FBQ3RDLE9BQU8sQ0FBQ29OLE9BQU8sQ0FBRXpQLENBQUMsSUFBSztNQUN2QixJQUFJTCxHQUFHLENBQUNHLFFBQVEsQ0FBQ0UsQ0FBQyxDQUFDSixFQUFFLENBQUMsRUFBRTRQLElBQUksQ0FBQ3hQLENBQUMsQ0FBQ0osRUFBRSxDQUFDLEdBQUc7UUFBRUksQ0FBQyxFQUFFQSxDQUFDLENBQUNBLENBQUM7UUFBRTZLLENBQUMsRUFBRTdLLENBQUMsQ0FBQzZLO01BQUUsQ0FBQztJQUN6RCxDQUFDLENBQUM7SUFDRjVKLE9BQU8sQ0FBQzhDLE9BQU8sR0FBRztNQUFFaUwsSUFBSSxFQUFFLE1BQU07TUFBRUMsRUFBRSxFQUFFbFEsQ0FBQyxDQUFDc0YsT0FBTztNQUFFNkssRUFBRSxFQUFFblEsQ0FBQyxDQUFDdUYsT0FBTztNQUFFK0IsR0FBRyxFQUFFMUcsR0FBRztNQUFFNlAsSUFBSTtNQUFFRSxLQUFLLEVBQUU7SUFBTSxDQUFDO0VBQ2hHLENBQUMsRUFDRCxDQUFDMUwsTUFBTSxDQUNULENBQUM7RUFFRCxNQUFNMkwsV0FBVyxHQUFHLElBQUE1TyxrQkFBVyxFQUFDLENBQUMwSixJQUF5QixFQUFFakUsTUFBYyxFQUFFekgsQ0FBcUIsS0FBSztJQUNwR0EsQ0FBQyxDQUFDdVEsZUFBZSxDQUFDLENBQUM7SUFDbkIsTUFBTTNLLENBQUMsR0FBR2QsUUFBUSxDQUFDRSxPQUFPO0lBQzFCLE1BQU1uRSxFQUFFLEdBQUcrRSxDQUFDLENBQUMvQixTQUFTLENBQUMsQ0FBQyxDQUFDO0lBQ3pCLE1BQU1xRCxDQUFDLEdBQUd0QixDQUFDLENBQUN0QyxPQUFPLENBQUNxRSxJQUFJLENBQUUxRyxDQUFDLElBQUtBLENBQUMsQ0FBQ0osRUFBRSxLQUFLQSxFQUFFLENBQUM7SUFDNUMsSUFBSSxDQUFDcUcsQ0FBQyxFQUFFO0lBQ1IsTUFBTW1KLElBQUksR0FBRztNQUFFcFAsQ0FBQyxFQUFFaUcsQ0FBQyxDQUFDakcsQ0FBQztNQUFFNkssQ0FBQyxFQUFFNUUsQ0FBQyxDQUFDNEUsQ0FBQztNQUFFMUMsQ0FBQyxFQUFFbEMsQ0FBQyxDQUFDa0MsQ0FBQztNQUFFQyxDQUFDLEVBQUVuQyxDQUFDLENBQUNtQyxDQUFDO01BQUUwQyxHQUFHLEVBQUU3RSxDQUFDLENBQUM2RTtJQUFJLENBQUM7SUFDM0Q3SixPQUFPLENBQUM4QyxPQUFPLEdBQ2IwRyxJQUFJLEtBQUssUUFBUSxHQUNiO01BQUV1RSxJQUFJLEVBQUUsUUFBUTtNQUFFQyxFQUFFLEVBQUVsUSxDQUFDLENBQUNzRixPQUFPO01BQUU2SyxFQUFFLEVBQUVuUSxDQUFDLENBQUN1RixPQUFPO01BQUUyQixDQUFDLEVBQUVtSixJQUFJO01BQUV4UCxFQUFFO01BQUU4UCxLQUFLLEVBQUU7SUFBTSxDQUFDLEdBQzNFO01BQUVWLElBQUksRUFBRSxRQUFRO01BQUV2RSxJQUFJLEVBQUVqRSxNQUFNO01BQUV5SSxFQUFFLEVBQUVsUSxDQUFDLENBQUNzRixPQUFPO01BQUU2SyxFQUFFLEVBQUVuUSxDQUFDLENBQUN1RixPQUFPO01BQUUyQixDQUFDLEVBQUVtSixJQUFJO01BQUV4UCxFQUFFO01BQUU4UCxLQUFLLEVBQUU7SUFBTSxDQUFDO0VBQ2pHLENBQUMsRUFBRSxFQUFFLENBQUM7RUFFTixNQUFNRSxZQUFZLEdBQUcsSUFBQTdPLGtCQUFXLEVBQzlCLENBQUNuQixFQUFVLEVBQUVpUSxJQUFZLEVBQUU5USxDQUFxQixLQUFLO0lBQ25EQSxDQUFDLENBQUN1USxlQUFlLENBQUMsQ0FBQztJQUNuQnJPLE9BQU8sQ0FBQzhDLE9BQU8sR0FBRztNQUFFaUwsSUFBSSxFQUFFLFNBQVM7TUFBRTNILElBQUksRUFBRXpILEVBQUU7TUFBRWlRLElBQUk7TUFBRUgsS0FBSyxFQUFFO0lBQU0sQ0FBQztJQUNuRSxNQUFNLENBQUNqTCxFQUFFLEVBQUVDLEVBQUUsQ0FBQyxHQUFHTixVQUFVLENBQUNyRixDQUFDLENBQUM7SUFDOUJpRixNQUFNLENBQUM7TUFBRWpCLGNBQWMsRUFBRTtRQUFFc0UsSUFBSSxFQUFFekgsRUFBRTtRQUFFSSxDQUFDLEVBQUV5RSxFQUFFO1FBQUVvRyxDQUFDLEVBQUVuRyxFQUFFO1FBQUVxQyxNQUFNLEVBQUU7TUFBSztJQUFFLENBQUMsQ0FBQztFQUN0RSxDQUFDLEVBQ0QsQ0FBQy9DLE1BQU0sRUFBRUksVUFBVSxDQUNyQixDQUFDO0VBRUQsTUFBTTBMLFFBQVEsR0FBRyxJQUFBL08sa0JBQVcsRUFBRW5CLEVBQWlCLElBQUtvRSxNQUFNLENBQUM7SUFBRW5CLEtBQUssRUFBRWpEO0VBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQ29FLE1BQU0sQ0FBQyxDQUFDO0VBQ3BGLE1BQU0rTCxjQUFjLEdBQUcsSUFBQWhQLGtCQUFXLEVBQUMsTUFBTWlELE1BQU0sQ0FBQztJQUFFcEIsU0FBUyxFQUFFO0VBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQ29CLE1BQU0sQ0FBQyxDQUFDOztFQUU3RTtFQUNBLE1BQU1nTSxNQUFNLEdBQUcsSUFBQWpQLGtCQUFXO0VBQ3hCO0VBQ0E7RUFDQTtFQUNBLE1BQU1pRCxNQUFNLENBQUM7SUFBRXRDLElBQUksRUFBRSxLQUFLO0lBQUVrQixTQUFTLEVBQUUsRUFBRTtJQUFFTSxhQUFhLEVBQUUsS0FBSztJQUFFRSxTQUFTLEVBQUUsSUFBSTtJQUFFTCxjQUFjLEVBQUUsSUFBSTtJQUFFQyxXQUFXLEVBQUUsSUFBSTtJQUFFQyxhQUFhLEVBQUU7RUFBSyxDQUFDLENBQUMsRUFDakosQ0FBQ2UsTUFBTSxDQUNULENBQUM7RUFDRCxNQUFNaU0sT0FBTyxHQUFHLElBQUFsUCxrQkFBVyxFQUFDLE1BQU1pRCxNQUFNLENBQUM7SUFBRXRDLElBQUksRUFBRTtFQUFPLENBQUMsQ0FBQyxFQUFFLENBQUNzQyxNQUFNLENBQUMsQ0FBQztFQUNyRSxNQUFNa00sV0FBVyxHQUFHLElBQUFuUCxrQkFBVyxFQUFDLE1BQU1pRCxNQUFNLENBQUVXLENBQUMsS0FBTTtJQUFFaEQsS0FBSyxFQUFFLENBQUNnRCxDQUFDLENBQUNoRDtFQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQ3FDLE1BQU0sQ0FBQyxDQUFDO0VBQ3JGLE1BQU1tTSxXQUFXLEdBQUcsSUFBQXBQLGtCQUFXLEVBQUMsTUFBTWlELE1BQU0sQ0FBRVcsQ0FBQyxLQUFNO0lBQUV4QixTQUFTLEVBQUUsQ0FBQ3dCLENBQUMsQ0FBQ3hCO0VBQVUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDYSxNQUFNLENBQUMsQ0FBQztFQUM3RixNQUFNb00sU0FBUyxHQUFHLElBQUFyUCxrQkFBVyxFQUFFd0MsTUFBa0IsSUFBS1MsTUFBTSxDQUFDO0lBQUVUO0VBQU8sQ0FBQyxDQUFDLEVBQUUsQ0FBQ1MsTUFBTSxDQUFDLENBQUM7RUFDbkYsTUFBTXFNLGFBQWEsR0FBRyxJQUFBdFAsa0JBQVcsRUFBRWEsRUFBYyxJQUFLb0MsTUFBTSxDQUFDO0lBQUVwQztFQUFHLENBQUMsQ0FBQyxFQUFFLENBQUNvQyxNQUFNLENBQUMsQ0FBQztFQUMvRSxNQUFNc00sUUFBUSxHQUFHLElBQUF2UCxrQkFBVyxFQUFFWSxLQUFjLElBQUtxQyxNQUFNLENBQUM7SUFBRXJDO0VBQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQ3FDLE1BQU0sQ0FBQyxDQUFDO0VBQzdFLE1BQU11TSxjQUFjLEdBQUcsSUFBQXhQLGtCQUFXLEVBQUMsTUFBTWlELE1BQU0sQ0FBQztJQUFFZCxhQUFhLEVBQUU7RUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDYyxNQUFNLENBQUMsQ0FBQztFQUNwRixNQUFNd00sVUFBVSxHQUFHLElBQUF6UCxrQkFBVyxFQUFDLE1BQU1pRCxNQUFNLENBQUM7SUFBRWIsU0FBUyxFQUFFO0VBQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQ2EsTUFBTSxDQUFDLENBQUM7RUFDNUUsTUFBTXlNLGNBQWMsR0FBRyxJQUFBMVAsa0JBQVcsRUFBQyxNQUFNaUQsTUFBTSxDQUFFVyxDQUFDLEtBQU07SUFBRW5CLFlBQVksRUFBRSxDQUFDbUIsQ0FBQyxDQUFDbkI7RUFBYSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUNRLE1BQU0sQ0FBQyxDQUFDO0VBRXRHLE1BQU0wTSxnQkFBZ0IsR0FBRyxJQUFBM1Asa0JBQVcsRUFDakNoQyxDQUFtQixJQUFLO0lBQ3ZCLElBQUk4RSxRQUFRLENBQUNFLE9BQU8sQ0FBQ3JDLElBQUksS0FBSyxNQUFNLEVBQUU7SUFDdEMsTUFBTSxDQUFDK0MsRUFBRSxFQUFFQyxFQUFFLENBQUMsR0FBR04sVUFBVSxDQUFDckYsQ0FBQyxDQUFDO0lBQzlCLE1BQU0sQ0FBQzJMLEVBQUUsRUFBRUMsRUFBRSxDQUFDLEdBQUcsSUFBQWdHLGVBQU8sRUFBQzlNLFFBQVEsQ0FBQ0UsT0FBTyxDQUFDL0IsR0FBRyxFQUFFNkIsUUFBUSxDQUFDRSxPQUFPLENBQUMzQixFQUFFLEVBQUVxQyxFQUFFLEVBQUVDLEVBQUUsQ0FBQztJQUMzRVYsTUFBTSxDQUFDO01BQUVaLFNBQVMsRUFBRTtRQUFFcUIsRUFBRTtRQUFFQyxFQUFFO1FBQUVnRyxFQUFFO1FBQUVDO01BQUc7SUFBRSxDQUFDLENBQUM7RUFDM0MsQ0FBQyxFQUNELENBQUMzRyxNQUFNLEVBQUVJLFVBQVUsQ0FDckIsQ0FBQzs7RUFFRDtFQUNBLE1BQU13TSxPQUFPLEdBQUcsSUFBQTdQLGtCQUFXLEVBQUMsTUFBTTtJQUNoQ2dFLEtBQUssQ0FBQyxrRUFBa0UsRUFBRSxPQUFPLEVBQUU7TUFDakZjLFNBQVMsRUFBRSxTQUFTO01BQ3BCVCxXQUFXLEVBQUUsV0FBVztNQUN4QmtGLFFBQVEsRUFBRUEsQ0FBQSxLQUFNdkYsS0FBSyxDQUFDLHVCQUF1QixFQUFFLE9BQU87SUFDeEQsQ0FBQyxDQUFDO0VBQ0osQ0FBQyxFQUFFLENBQUNBLEtBQUssQ0FBQyxDQUFDO0VBRVgsTUFBTThMLGFBQWEsR0FBRyxJQUFBOVAsa0JBQVcsRUFBQyxNQUFNO0lBQ3RDaUQsTUFBTSxDQUFDO01BQUV0QyxJQUFJLEVBQUUsS0FBSztNQUFFa0IsU0FBUyxFQUFFLEVBQUU7TUFBRU0sYUFBYSxFQUFFO0lBQU0sQ0FBQyxDQUFDO0lBQzVENkIsS0FBSyxDQUFDLHFEQUFxRCxFQUFFLE1BQU0sRUFBRTtNQUFFYyxTQUFTLEVBQUU7SUFBZSxDQUFDLENBQUM7RUFDckcsQ0FBQyxFQUFFLENBQUM3QixNQUFNLEVBQUVlLEtBQUssQ0FBQyxDQUFDOztFQUVuQjtFQUNBLElBQUFqQixnQkFBUyxFQUFDLE1BQU07SUFDZGdOLFFBQVEsQ0FBQ0MsZUFBZSxDQUFDQyxZQUFZLENBQUMsWUFBWSxFQUFFeFAsS0FBSyxDQUFDRyxLQUFLLEdBQUcsT0FBTyxHQUFHLE1BQU0sQ0FBQztFQUNyRixDQUFDLEVBQUUsQ0FBQ0gsS0FBSyxDQUFDRyxLQUFLLENBQUMsQ0FBQztFQUVqQixJQUFBbUMsZ0JBQVMsRUFBQyxNQUFNO0lBQ2QsTUFBTTlDLEVBQUUsR0FBR0wsUUFBUTtJQUNuQixJQUFJLENBQUNLLEVBQUUsRUFBRTtJQUVULE1BQU1pUSxPQUFPLEdBQUdBLENBQUEsS0FBTTtNQUNwQixNQUFNQyxDQUFDLEdBQUdsUSxFQUFFLENBQUNtUSxxQkFBcUIsQ0FBQyxDQUFDO01BQ3BDbk4sTUFBTSxDQUFDO1FBQUU1QixFQUFFLEVBQUU7VUFBRWpELEVBQUUsRUFBRStSLENBQUMsQ0FBQ0UsS0FBSztVQUFFOVIsRUFBRSxFQUFFNFIsQ0FBQyxDQUFDRyxNQUFNO1VBQUU3UixLQUFLLEVBQUUwUixDQUFDLENBQUNJLElBQUk7VUFBRTdSLElBQUksRUFBRXlSLENBQUMsQ0FBQ0s7UUFBSTtNQUFFLENBQUMsQ0FBQztJQUMzRSxDQUFDO0lBQ0ROLE9BQU8sQ0FBQyxDQUFDO0lBQ1QsTUFBTU8sRUFBRSxHQUFHLElBQUlDLGNBQWMsQ0FBQ1IsT0FBTyxDQUFDO0lBQ3RDTyxFQUFFLENBQUNFLE9BQU8sQ0FBQzFRLEVBQUUsQ0FBQztJQUVkLE1BQU0yUSxPQUFPLEdBQUk1UyxDQUFhLElBQUs7TUFDakNBLENBQUMsQ0FBQzZTLGNBQWMsQ0FBQyxDQUFDO01BQ2xCLE1BQU0sQ0FBQ25OLEVBQUUsRUFBRUMsRUFBRSxDQUFDLEdBQUdOLFVBQVUsQ0FBQ3JGLENBQUMsQ0FBQztNQUM5QixJQUFJQSxDQUFDLENBQUM4UyxPQUFPLElBQUk5UyxDQUFDLENBQUMrUyxPQUFPLEVBQUU7UUFDMUIsTUFBTUMsQ0FBQyxHQUFHcEssSUFBSSxDQUFDcUssR0FBRyxDQUFDLENBQUNqVCxDQUFDLENBQUNrVCxNQUFNLEdBQUcsSUFBSSxDQUFDO1FBQ3BDMU4sT0FBTyxDQUFDVixRQUFRLENBQUNFLE9BQU8sQ0FBQy9CLEdBQUcsQ0FBQ0csSUFBSSxHQUFHNFAsQ0FBQyxFQUFFdE4sRUFBRSxFQUFFQyxFQUFFLENBQUM7TUFDaEQsQ0FBQyxNQUFNO1FBQ0xWLE1BQU0sQ0FBRVcsQ0FBQyxLQUFNO1VBQUUzQyxHQUFHLEVBQUU7WUFBRUMsRUFBRSxFQUFFMEMsQ0FBQyxDQUFDM0MsR0FBRyxDQUFDQyxFQUFFLEdBQUdsRCxDQUFDLENBQUNtVCxNQUFNLEdBQUd2TixDQUFDLENBQUMzQyxHQUFHLENBQUNHLElBQUk7WUFBRUQsRUFBRSxFQUFFeUMsQ0FBQyxDQUFDM0MsR0FBRyxDQUFDRSxFQUFFLEdBQUduRCxDQUFDLENBQUNrVCxNQUFNLEdBQUd0TixDQUFDLENBQUMzQyxHQUFHLENBQUNHLElBQUk7WUFBRUEsSUFBSSxFQUFFd0MsQ0FBQyxDQUFDM0MsR0FBRyxDQUFDRztVQUFLO1FBQUUsQ0FBQyxDQUFDLENBQUM7TUFDNUg7SUFDRixDQUFDO0lBQ0RuQixFQUFFLENBQUNtUixnQkFBZ0IsQ0FBQyxPQUFPLEVBQUVSLE9BQU8sRUFBRTtNQUFFUyxPQUFPLEVBQUU7SUFBTSxDQUFDLENBQUM7SUFFekQsTUFBTUMsTUFBTSxHQUFJdFQsQ0FBZSxJQUFLO01BQ2xDLE1BQU11VCxDQUFDLEdBQUdyUixPQUFPLENBQUM4QyxPQUFPO01BQ3pCLElBQUksQ0FBQ3VPLENBQUMsRUFBRTtNQUNSLE1BQU10SCxDQUFDLEdBQUduSCxRQUFRLENBQUNFLE9BQU8sQ0FBQy9CLEdBQUcsQ0FBQ0csSUFBSTtNQUNuQyxJQUFJbVEsQ0FBQyxDQUFDdEQsSUFBSSxLQUFLLEtBQUssRUFBRTtRQUNwQixNQUFNdUQsRUFBRSxHQUFHeFQsQ0FBQyxDQUFDc0YsT0FBTyxHQUFHaU8sQ0FBQyxDQUFDckQsRUFBRTtRQUMzQixNQUFNdUQsRUFBRSxHQUFHelQsQ0FBQyxDQUFDdUYsT0FBTyxHQUFHZ08sQ0FBQyxDQUFDcEQsRUFBRTtRQUMzQmxMLE1BQU0sQ0FBQztVQUFFaEMsR0FBRyxFQUFFO1lBQUVDLEVBQUUsRUFBRXFRLENBQUMsQ0FBQ3JRLEVBQUUsR0FBR3NRLEVBQUUsR0FBR3ZILENBQUM7WUFBRTlJLEVBQUUsRUFBRW9RLENBQUMsQ0FBQ3BRLEVBQUUsR0FBR3NRLEVBQUUsR0FBR3hILENBQUM7WUFBRTdJLElBQUksRUFBRTZJO1VBQUU7UUFBRSxDQUFDLENBQUM7TUFDcEUsQ0FBQyxNQUFNLElBQUlzSCxDQUFDLENBQUN0RCxJQUFJLEtBQUssTUFBTSxFQUFFO1FBQzVCLE1BQU11RCxFQUFFLEdBQUcsQ0FBQ3hULENBQUMsQ0FBQ3NGLE9BQU8sR0FBR2lPLENBQUMsQ0FBQ3JELEVBQUUsSUFBSWpFLENBQUM7UUFDakMsTUFBTXdILEVBQUUsR0FBRyxDQUFDelQsQ0FBQyxDQUFDdUYsT0FBTyxHQUFHZ08sQ0FBQyxDQUFDcEQsRUFBRSxJQUFJbEUsQ0FBQztRQUNqQ3NILENBQUMsQ0FBQzVDLEtBQUssR0FBRyxJQUFJO1FBQ2QxTCxNQUFNLENBQUVXLENBQUMsS0FBTTtVQUNidEMsT0FBTyxFQUFFc0MsQ0FBQyxDQUFDdEMsT0FBTyxDQUFDMkQsR0FBRyxDQUFFQyxDQUFDLElBQ3ZCcU0sQ0FBQyxDQUFDak0sR0FBRyxDQUFDdkcsUUFBUSxDQUFDbUcsQ0FBQyxDQUFDckcsRUFBRSxDQUFDLElBQUkwUyxDQUFDLENBQUM5QyxJQUFJLENBQUN2SixDQUFDLENBQUNyRyxFQUFFLENBQUMsR0FBRztZQUFFLEdBQUdxRyxDQUFDO1lBQUVqRyxDQUFDLEVBQUVzUyxDQUFDLENBQUM5QyxJQUFJLENBQUN2SixDQUFDLENBQUNyRyxFQUFFLENBQUMsQ0FBQ0ksQ0FBQyxHQUFHdVMsRUFBRTtZQUFFMUgsQ0FBQyxFQUFFeUgsQ0FBQyxDQUFDOUMsSUFBSSxDQUFDdkosQ0FBQyxDQUFDckcsRUFBRSxDQUFDLENBQUNpTCxDQUFDLEdBQUcySDtVQUFHLENBQUMsR0FBR3ZNLENBQ3BHO1FBQ0YsQ0FBQyxDQUFDLENBQUM7TUFDTCxDQUFDLE1BQU0sSUFBSXFNLENBQUMsQ0FBQ3RELElBQUksS0FBSyxTQUFTLEVBQUU7UUFDL0IsTUFBTSxDQUFDdkssRUFBRSxFQUFFQyxFQUFFLENBQUMsR0FBR04sVUFBVSxDQUFDckYsQ0FBQyxDQUFDO1FBQzlCLE1BQU1pQixDQUFDLEdBQUcySCxJQUFJLENBQUNHLEdBQUcsQ0FBQ3JELEVBQUUsRUFBRTZOLENBQUMsQ0FBQ3JELEVBQUUsQ0FBQztRQUM1QixNQUFNcEUsQ0FBQyxHQUFHbEQsSUFBSSxDQUFDRyxHQUFHLENBQUNwRCxFQUFFLEVBQUU0TixDQUFDLENBQUNwRCxFQUFFLENBQUM7UUFDNUIsTUFBTS9HLENBQUMsR0FBR1IsSUFBSSxDQUFDOEssR0FBRyxDQUFDaE8sRUFBRSxHQUFHNk4sQ0FBQyxDQUFDckQsRUFBRSxDQUFDO1FBQzdCLE1BQU15RCxFQUFFLEdBQUcvSyxJQUFJLENBQUM4SyxHQUFHLENBQUMvTixFQUFFLEdBQUc0TixDQUFDLENBQUNwRCxFQUFFLENBQUM7UUFDOUIsTUFBTXZLLENBQUMsR0FBR2QsUUFBUSxDQUFDRSxPQUFPO1FBQzFCLE1BQU1wRSxHQUFHLEdBQUcsSUFBQWdULHVCQUFhLEVBQUNoTyxDQUFDLENBQUN0QyxPQUFPLEVBQUVzQyxDQUFDLENBQUMzQyxHQUFHLEVBQUUyQyxDQUFDLENBQUN2QyxFQUFFLEVBQUVwQyxDQUFDLEVBQUU2SyxDQUFDLEVBQUUxQyxDQUFDLEVBQUV1SyxFQUFFLENBQUM7UUFDOUQxTyxNQUFNLENBQUM7VUFBRWxCLE9BQU8sRUFBRTtZQUFFOUMsQ0FBQztZQUFFNkssQ0FBQztZQUFFMUMsQ0FBQztZQUFFQyxDQUFDLEVBQUVzSztVQUFHLENBQUM7VUFBRTlQLFNBQVMsRUFBRTBQLENBQUMsQ0FBQ25ELEdBQUcsR0FBR3lELEtBQUssQ0FBQ3ZMLElBQUksQ0FBQyxJQUFJd0wsR0FBRyxDQUFDUCxDQUFDLENBQUNsRCxJQUFJLENBQUNuUCxNQUFNLENBQUNOLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBR0E7UUFBSSxDQUFDLENBQUM7TUFDM0csQ0FBQyxNQUFNLElBQUkyUyxDQUFDLENBQUN0RCxJQUFJLEtBQUssU0FBUyxFQUFFO1FBQy9CLE1BQU0sQ0FBQ3ZLLEVBQUUsRUFBRUMsRUFBRSxDQUFDLEdBQUdOLFVBQVUsQ0FBQ3JGLENBQUMsQ0FBQztRQUM5QixNQUFNNEYsQ0FBQyxHQUFHZCxRQUFRLENBQUNFLE9BQU87UUFDMUIsTUFBTStPLEdBQUcsR0FBRyxJQUFBQyx1QkFBYSxFQUFDcE8sQ0FBQyxDQUFDdEMsT0FBTyxFQUFFc0MsQ0FBQyxDQUFDM0MsR0FBRyxFQUFFMkMsQ0FBQyxDQUFDdkMsRUFBRSxFQUFFcUMsRUFBRSxFQUFFQyxFQUFFLEVBQUU0TixDQUFDLENBQUNqTCxJQUFJLENBQUM7UUFDakVyRCxNQUFNLENBQUM7VUFBRWpCLGNBQWMsRUFBRTtZQUFFc0UsSUFBSSxFQUFFaUwsQ0FBQyxDQUFDakwsSUFBSTtZQUFFckgsQ0FBQyxFQUFFeUUsRUFBRTtZQUFFb0csQ0FBQyxFQUFFbkcsRUFBRTtZQUFFcUMsTUFBTSxFQUFFK0w7VUFBSTtRQUFFLENBQUMsQ0FBQztNQUN6RSxDQUFDLE1BQU0sSUFBSVIsQ0FBQyxDQUFDdEQsSUFBSSxLQUFLLFFBQVEsSUFBSXNELENBQUMsQ0FBQ3RELElBQUksS0FBSyxRQUFRLEVBQUU7UUFDckRnRSxXQUFXLENBQUNWLENBQUMsRUFBRXZULENBQUMsQ0FBQztNQUNuQjtJQUNGLENBQUM7SUFFRCxNQUFNaVUsV0FBVyxHQUFHQSxDQUFDVixDQUErQyxFQUFFdlQsQ0FBZSxLQUFLO01BQ3hGLE1BQU00RixDQUFDLEdBQUdkLFFBQVEsQ0FBQ0UsT0FBTztNQUMxQixNQUFNaUgsQ0FBQyxHQUFHckcsQ0FBQyxDQUFDM0MsR0FBRyxDQUFDRyxJQUFJO01BQ3BCLE1BQU1vUSxFQUFFLEdBQUcsQ0FBQ3hULENBQUMsQ0FBQ3NGLE9BQU8sR0FBR2lPLENBQUMsQ0FBQ3JELEVBQUUsSUFBSWpFLENBQUM7TUFDakMsTUFBTXdILEVBQUUsR0FBRyxDQUFDelQsQ0FBQyxDQUFDdUYsT0FBTyxHQUFHZ08sQ0FBQyxDQUFDcEQsRUFBRSxJQUFJbEUsQ0FBQztNQUNqQ3NILENBQUMsQ0FBQzVDLEtBQUssR0FBRyxJQUFJO01BQ2QxTCxNQUFNLENBQUV3RSxFQUFFLEtBQU07UUFDZG5HLE9BQU8sRUFBRW1HLEVBQUUsQ0FBQ25HLE9BQU8sQ0FBQzJELEdBQUcsQ0FBRUMsQ0FBQyxJQUFLO1VBQzdCLElBQUlBLENBQUMsQ0FBQ3JHLEVBQUUsS0FBSzBTLENBQUMsQ0FBQzFTLEVBQUUsRUFBRSxPQUFPcUcsQ0FBQztVQUMzQixJQUFJcU0sQ0FBQyxDQUFDdEQsSUFBSSxLQUFLLFFBQVEsRUFBRTtZQUN2QixNQUFNL00sRUFBRSxHQUFHcVEsQ0FBQyxDQUFDck0sQ0FBQyxDQUFDakcsQ0FBQyxHQUFHc1MsQ0FBQyxDQUFDck0sQ0FBQyxDQUFDa0MsQ0FBQyxHQUFHLENBQUM7WUFDNUIsTUFBTWpHLEVBQUUsR0FBR29RLENBQUMsQ0FBQ3JNLENBQUMsQ0FBQzRFLENBQUMsR0FBR3lILENBQUMsQ0FBQ3JNLENBQUMsQ0FBQ21DLENBQUMsR0FBRyxDQUFDO1lBQzVCLE1BQU0sQ0FBQzNELEVBQUUsRUFBRUMsRUFBRSxDQUFDLEdBQUdOLFVBQVUsQ0FBQ3JGLENBQUMsQ0FBQztZQUM5QixNQUFNLENBQUMyTCxFQUFFLEVBQUVDLEVBQUUsQ0FBQyxHQUFHLElBQUFnRyxlQUFPLEVBQUNoTSxDQUFDLENBQUMzQyxHQUFHLEVBQUUyQyxDQUFDLENBQUN2QyxFQUFFLEVBQUVxQyxFQUFFLEVBQUVDLEVBQUUsQ0FBQztZQUM3QyxJQUFJdU8sR0FBRyxHQUFJdEwsSUFBSSxDQUFDdUwsS0FBSyxDQUFDdkksRUFBRSxHQUFHekksRUFBRSxFQUFFd0ksRUFBRSxHQUFHekksRUFBRSxDQUFDLEdBQUcsR0FBRyxHQUFJMEYsSUFBSSxDQUFDd0wsRUFBRSxHQUFHLEVBQUU7WUFDN0QsSUFBSXBVLENBQUMsQ0FBQ2dRLFFBQVEsRUFBRWtFLEdBQUcsR0FBR3RMLElBQUksQ0FBQ3lMLEtBQUssQ0FBQ0gsR0FBRyxHQUFHLEVBQUUsQ0FBQyxHQUFHLEVBQUU7WUFDL0MsT0FBTztjQUFFLEdBQUdoTixDQUFDO2NBQUU2RSxHQUFHLEVBQUVuRCxJQUFJLENBQUN5TCxLQUFLLENBQUNILEdBQUc7WUFBRSxDQUFDO1VBQ3ZDO1VBQ0EsSUFBSWpULENBQUMsR0FBR3NTLENBQUMsQ0FBQ3JNLENBQUMsQ0FBQ2pHLENBQUM7VUFDYixJQUFJNkssQ0FBQyxHQUFHeUgsQ0FBQyxDQUFDck0sQ0FBQyxDQUFDNEUsQ0FBQztVQUNiLElBQUkxQyxDQUFDLEdBQUdtSyxDQUFDLENBQUNyTSxDQUFDLENBQUNrQyxDQUFDO1VBQ2IsSUFBSXVLLEVBQUUsR0FBR0osQ0FBQyxDQUFDck0sQ0FBQyxDQUFDbUMsQ0FBQztVQUNkLE1BQU1pTCxDQUFDLEdBQUdmLENBQUMsQ0FBQzdILElBQUk7VUFDaEIsSUFBSTRJLENBQUMsQ0FBQ3ZULFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBRXFJLENBQUMsR0FBR1IsSUFBSSxDQUFDbUMsR0FBRyxDQUFDLEVBQUUsRUFBRXdJLENBQUMsQ0FBQ3JNLENBQUMsQ0FBQ2tDLENBQUMsR0FBR29LLEVBQUUsQ0FBQztVQUNqRCxJQUFJYyxDQUFDLENBQUN2VCxRQUFRLENBQUMsR0FBRyxDQUFDLEVBQUU0UyxFQUFFLEdBQUcvSyxJQUFJLENBQUNtQyxHQUFHLENBQUMsRUFBRSxFQUFFd0ksQ0FBQyxDQUFDck0sQ0FBQyxDQUFDbUMsQ0FBQyxHQUFHb0ssRUFBRSxDQUFDO1VBQ2xELElBQUlhLENBQUMsQ0FBQ3ZULFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUNuQnFJLENBQUMsR0FBR1IsSUFBSSxDQUFDbUMsR0FBRyxDQUFDLEVBQUUsRUFBRXdJLENBQUMsQ0FBQ3JNLENBQUMsQ0FBQ2tDLENBQUMsR0FBR29LLEVBQUUsQ0FBQztZQUM1QnZTLENBQUMsR0FBR3NTLENBQUMsQ0FBQ3JNLENBQUMsQ0FBQ2pHLENBQUMsSUFBSXNTLENBQUMsQ0FBQ3JNLENBQUMsQ0FBQ2tDLENBQUMsR0FBR0EsQ0FBQyxDQUFDO1VBQ3pCO1VBQ0EsSUFBSWtMLENBQUMsQ0FBQ3ZULFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUNuQjRTLEVBQUUsR0FBRy9LLElBQUksQ0FBQ21DLEdBQUcsQ0FBQyxFQUFFLEVBQUV3SSxDQUFDLENBQUNyTSxDQUFDLENBQUNtQyxDQUFDLEdBQUdvSyxFQUFFLENBQUM7WUFDN0IzSCxDQUFDLEdBQUd5SCxDQUFDLENBQUNyTSxDQUFDLENBQUM0RSxDQUFDLElBQUl5SCxDQUFDLENBQUNyTSxDQUFDLENBQUNtQyxDQUFDLEdBQUdzSyxFQUFFLENBQUM7VUFDMUI7VUFDQSxPQUFPO1lBQUUsR0FBR3pNLENBQUM7WUFBRWpHLENBQUM7WUFBRTZLLENBQUM7WUFBRTFDLENBQUM7WUFBRUMsQ0FBQyxFQUFFc0s7VUFBRyxDQUFDO1FBQ2pDLENBQUM7TUFDSCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRCxNQUFNWSxJQUFJLEdBQUl2VSxDQUFlLElBQUs7TUFDaEMsTUFBTXVULENBQUMsR0FBR3JSLE9BQU8sQ0FBQzhDLE9BQU87TUFDekI5QyxPQUFPLENBQUM4QyxPQUFPLEdBQUcsSUFBSTtNQUN0QixJQUFJLENBQUN1TyxDQUFDLEVBQUU7UUFDTixJQUFJek8sUUFBUSxDQUFDRSxPQUFPLENBQUNOLE9BQU8sRUFBRU8sTUFBTSxDQUFDO1VBQUVQLE9BQU8sRUFBRTtRQUFNLENBQUMsQ0FBQztRQUN4RDtNQUNGO01BQ0EsSUFBSTZPLENBQUMsQ0FBQ3RELElBQUksS0FBSyxLQUFLLEVBQUU7UUFDcEJoTCxNQUFNLENBQUM7VUFBRVAsT0FBTyxFQUFFO1FBQU0sQ0FBQyxDQUFDO01BQzVCLENBQUMsTUFBTSxJQUFJNk8sQ0FBQyxDQUFDdEQsSUFBSSxLQUFLLE1BQU0sSUFBSXNELENBQUMsQ0FBQzVDLEtBQUssRUFBRTtRQUN2QyxNQUFNQSxLQUFLLEdBQUc3TCxRQUFRLENBQUNFLE9BQU8sQ0FBQzFCLE9BQU8sQ0FBQ3RDLE1BQU0sQ0FBRWtHLENBQUMsSUFBS3FNLENBQUMsQ0FBQ2pNLEdBQUcsQ0FBQ3ZHLFFBQVEsQ0FBQ21HLENBQUMsQ0FBQ3JHLEVBQUUsQ0FBQyxDQUFDO1FBQzFFNkYsVUFBVSxDQUFDaUssS0FBSyxFQUFFLG9CQUFvQjRDLENBQUMsQ0FBQ2pNLEdBQUcsQ0FBQ2tDLE1BQU0sR0FBRyxDQUFDLEdBQUcsR0FBRytKLENBQUMsQ0FBQ2pNLEdBQUcsQ0FBQ2tDLE1BQU0sUUFBUSxHQUFHLEdBQUcrSixDQUFDLENBQUNqTSxHQUFHLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDO01BQ3pHLENBQUMsTUFBTSxJQUFJaU0sQ0FBQyxDQUFDdEQsSUFBSSxLQUFLLFNBQVMsRUFBRTtRQUMvQmhMLE1BQU0sQ0FBQztVQUFFbEIsT0FBTyxFQUFFO1FBQUssQ0FBQyxDQUFDO01BQzNCLENBQUMsTUFBTSxJQUFJd1AsQ0FBQyxDQUFDdEQsSUFBSSxLQUFLLFNBQVMsRUFBRTtRQUMvQixNQUFNLENBQUN2SyxFQUFFLEVBQUVDLEVBQUUsQ0FBQyxHQUFHTixVQUFVLENBQUNyRixDQUFDLENBQUM7UUFDOUIsTUFBTTRGLENBQUMsR0FBR2QsUUFBUSxDQUFDRSxPQUFPO1FBQzFCLE1BQU0rTyxHQUFHLEdBQUcsSUFBQUMsdUJBQWEsRUFBQ3BPLENBQUMsQ0FBQ3RDLE9BQU8sRUFBRXNDLENBQUMsQ0FBQzNDLEdBQUcsRUFBRTJDLENBQUMsQ0FBQ3ZDLEVBQUUsRUFBRXFDLEVBQUUsRUFBRUMsRUFBRSxFQUFFNE4sQ0FBQyxDQUFDakwsSUFBSSxDQUFDO1FBQ2pFLElBQUl5TCxHQUFHLEVBQUVuRixhQUFhLENBQUMyRSxDQUFDLENBQUNqTCxJQUFJLEVBQUV5TCxHQUFHLENBQUM7UUFDbkM5TyxNQUFNLENBQUM7VUFBRWpCLGNBQWMsRUFBRTtRQUFLLENBQUMsQ0FBQztNQUNsQyxDQUFDLE1BQU0sSUFBSSxDQUFDdVAsQ0FBQyxDQUFDdEQsSUFBSSxLQUFLLFFBQVEsSUFBSXNELENBQUMsQ0FBQ3RELElBQUksS0FBSyxRQUFRLEtBQUtzRCxDQUFDLENBQUM1QyxLQUFLLEVBQUU7UUFDbEUsTUFBTXpKLENBQUMsR0FBR3BDLFFBQVEsQ0FBQ0UsT0FBTyxDQUFDMUIsT0FBTyxDQUFDcUUsSUFBSSxDQUFFMUcsQ0FBQyxJQUFLQSxDQUFDLENBQUNKLEVBQUUsS0FBSzBTLENBQUMsQ0FBQzFTLEVBQUUsQ0FBQztRQUM3RDZGLFVBQVUsQ0FBQ1EsQ0FBQyxHQUFHLENBQUNBLENBQUMsQ0FBQyxHQUFHLEVBQUUsRUFBRSxpQkFBaUIsQ0FBQztNQUM3QztJQUNGLENBQUM7SUFFRCxNQUFNc04sU0FBUyxHQUFJeFUsQ0FBZ0IsSUFBSztNQUN0QyxNQUFNK0YsQ0FBQyxHQUFHL0YsQ0FBQyxDQUFDZ0ksTUFBNEI7TUFDeEMsSUFBSWpDLENBQUMsS0FBS0EsQ0FBQyxDQUFDME8sT0FBTyxLQUFLLE9BQU8sSUFBSTFPLENBQUMsQ0FBQzBPLE9BQU8sS0FBSyxVQUFVLElBQUkxTyxDQUFDLENBQUMwTyxPQUFPLEtBQUssUUFBUSxJQUFJMU8sQ0FBQyxDQUFDMk8saUJBQWlCLENBQUMsRUFBRTtNQUMvRyxNQUFNOU8sQ0FBQyxHQUFHZCxRQUFRLENBQUNFLE9BQU87TUFDMUIsSUFBSVksQ0FBQyxDQUFDdEIsT0FBTyxFQUFFO1FBQ2IsSUFBSXRFLENBQUMsQ0FBQzJVLEdBQUcsS0FBSyxZQUFZLElBQUkzVSxDQUFDLENBQUMyVSxHQUFHLEtBQUssR0FBRyxFQUFFO1VBQzNDM1UsQ0FBQyxDQUFDNlMsY0FBYyxDQUFDLENBQUM7VUFDbEJsSSxRQUFRLENBQUMsQ0FBQztRQUNaLENBQUMsTUFBTSxJQUFJM0ssQ0FBQyxDQUFDMlUsR0FBRyxLQUFLLFdBQVcsRUFBRTtVQUNoQzdKLFFBQVEsQ0FBQyxDQUFDO1FBQ1osQ0FBQyxNQUFNLElBQUk5SyxDQUFDLENBQUMyVSxHQUFHLEtBQUssUUFBUSxFQUFFO1VBQzdCakssUUFBUSxDQUFDLENBQUM7UUFDWjtRQUNBO01BQ0Y7TUFDQTtNQUNBO01BQ0E7TUFDQSxJQUFJOUUsQ0FBQyxDQUFDM0IsV0FBVyxFQUFFO1FBQ2pCLElBQUlqRSxDQUFDLENBQUMyVSxHQUFHLEtBQUssV0FBVyxJQUFJM1UsQ0FBQyxDQUFDMlUsR0FBRyxLQUFLLFNBQVMsRUFBRTtVQUNoRDNVLENBQUMsQ0FBQzZTLGNBQWMsQ0FBQyxDQUFDO1VBQ2xCbkQsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDdkIsQ0FBQyxNQUFNLElBQUkxUCxDQUFDLENBQUMyVSxHQUFHLEtBQUssWUFBWSxJQUFJM1UsQ0FBQyxDQUFDMlUsR0FBRyxLQUFLLFdBQVcsRUFBRTtVQUMxRDNVLENBQUMsQ0FBQzZTLGNBQWMsQ0FBQyxDQUFDO1VBQ2xCbkQsaUJBQWlCLENBQUMsQ0FBQyxDQUFDO1FBQ3RCLENBQUMsTUFBTSxJQUFJMVAsQ0FBQyxDQUFDMlUsR0FBRyxLQUFLLE9BQU8sRUFBRTtVQUM1QjNVLENBQUMsQ0FBQzZTLGNBQWMsQ0FBQyxDQUFDO1VBQ2xCckQsVUFBVSxDQUFDLElBQUksQ0FBQztRQUNsQixDQUFDLE1BQU0sSUFBSXhQLENBQUMsQ0FBQzJVLEdBQUcsS0FBSyxRQUFRLEVBQUU7VUFDN0IzVSxDQUFDLENBQUM2UyxjQUFjLENBQUMsQ0FBQztVQUNsQnJELFVBQVUsQ0FBQyxLQUFLLENBQUM7UUFDbkI7UUFDQTtNQUNGO01BQ0EsSUFBSXhQLENBQUMsQ0FBQzJVLEdBQUcsS0FBSyxRQUFRLEVBQUUxUCxNQUFNLENBQUM7UUFBRXBCLFNBQVMsRUFBRSxFQUFFO1FBQUVRLFNBQVMsRUFBRSxJQUFJO1FBQUVHLE1BQU0sRUFBRTtNQUFLLENBQUMsQ0FBQztNQUNoRixJQUFJeEUsQ0FBQyxDQUFDMlUsR0FBRyxLQUFLLEdBQUcsRUFBRXJTLFFBQVEsQ0FBQzBDLE9BQU8sR0FBRyxJQUFJO01BQzFDLElBQUlZLENBQUMsQ0FBQ2pELElBQUksS0FBSyxNQUFNLElBQUlpRCxDQUFDLENBQUMvQixTQUFTLENBQUMyRixNQUFNLEVBQUU7UUFDM0MsTUFBTVYsSUFBSSxHQUFHOUksQ0FBQyxDQUFDZ1EsUUFBUSxHQUFHLEVBQUUsR0FBRyxDQUFDO1FBQ2hDLElBQUl3RCxFQUFFLEdBQUcsQ0FBQztRQUNWLElBQUlDLEVBQUUsR0FBRyxDQUFDO1FBQ1YsSUFBSXpULENBQUMsQ0FBQzJVLEdBQUcsS0FBSyxXQUFXLEVBQUVuQixFQUFFLEdBQUcsQ0FBQzFLLElBQUksQ0FBQyxLQUNqQyxJQUFJOUksQ0FBQyxDQUFDMlUsR0FBRyxLQUFLLFlBQVksRUFBRW5CLEVBQUUsR0FBRzFLLElBQUksQ0FBQyxLQUN0QyxJQUFJOUksQ0FBQyxDQUFDMlUsR0FBRyxLQUFLLFNBQVMsRUFBRWxCLEVBQUUsR0FBRyxDQUFDM0ssSUFBSSxDQUFDLEtBQ3BDLElBQUk5SSxDQUFDLENBQUMyVSxHQUFHLEtBQUssV0FBVyxFQUFFbEIsRUFBRSxHQUFHM0ssSUFBSTtRQUN6QyxJQUFJMEssRUFBRSxJQUFJQyxFQUFFLEVBQUU7VUFDWnpULENBQUMsQ0FBQzZTLGNBQWMsQ0FBQyxDQUFDO1VBQ2xCLE1BQU1qUyxHQUFHLEdBQUdnRixDQUFDLENBQUMvQixTQUFTO1VBQ3ZCb0IsTUFBTSxDQUFFd0UsRUFBRSxLQUFNO1lBQUVuRyxPQUFPLEVBQUVtRyxFQUFFLENBQUNuRyxPQUFPLENBQUMyRCxHQUFHLENBQUVDLENBQUMsSUFBTXRHLEdBQUcsQ0FBQ0csUUFBUSxDQUFDbUcsQ0FBQyxDQUFDckcsRUFBRSxDQUFDLElBQUksQ0FBQ3FHLENBQUMsQ0FBQ3NKLE1BQU0sR0FBRztjQUFFLEdBQUd0SixDQUFDO2NBQUVqRyxDQUFDLEVBQUVpRyxDQUFDLENBQUNqRyxDQUFDLEdBQUd1UyxFQUFFO2NBQUUxSCxDQUFDLEVBQUU1RSxDQUFDLENBQUM0RSxDQUFDLEdBQUcySDtZQUFHLENBQUMsR0FBR3ZNLENBQUU7VUFBRSxDQUFDLENBQUMsQ0FBQztVQUNoSUcsWUFBWSxDQUFDekcsR0FBRyxDQUFDO1FBQ25CO1FBQ0EsSUFBSVosQ0FBQyxDQUFDMlUsR0FBRyxLQUFLLFFBQVEsSUFBSTNVLENBQUMsQ0FBQzJVLEdBQUcsS0FBSyxXQUFXLEVBQUV2SixlQUFlLENBQUMsQ0FBQztNQUNwRTtJQUNGLENBQUM7SUFDRCxNQUFNd0osT0FBTyxHQUFJNVUsQ0FBZ0IsSUFBSztNQUNwQyxJQUFJQSxDQUFDLENBQUMyVSxHQUFHLEtBQUssR0FBRyxFQUFFclMsUUFBUSxDQUFDMEMsT0FBTyxHQUFHLEtBQUs7SUFDN0MsQ0FBQztJQUVEK00sUUFBUSxDQUFDcUIsZ0JBQWdCLENBQUMsYUFBYSxFQUFFRSxNQUFNLENBQUM7SUFDaER2QixRQUFRLENBQUNxQixnQkFBZ0IsQ0FBQyxXQUFXLEVBQUVtQixJQUFJLENBQUM7SUFDNUNsVSxNQUFNLENBQUMrUyxnQkFBZ0IsQ0FBQyxTQUFTLEVBQUVvQixTQUFTLENBQUM7SUFDN0NuVSxNQUFNLENBQUMrUyxnQkFBZ0IsQ0FBQyxPQUFPLEVBQUV3QixPQUFPLENBQUM7SUFFekMsT0FBTyxNQUFNO01BQ1gzUyxFQUFFLENBQUM0UyxtQkFBbUIsQ0FBQyxPQUFPLEVBQUVqQyxPQUFPLENBQUM7TUFDeENILEVBQUUsQ0FBQ3FDLFVBQVUsQ0FBQyxDQUFDO01BQ2YvQyxRQUFRLENBQUM4QyxtQkFBbUIsQ0FBQyxhQUFhLEVBQUV2QixNQUFNLENBQUM7TUFDbkR2QixRQUFRLENBQUM4QyxtQkFBbUIsQ0FBQyxXQUFXLEVBQUVOLElBQUksQ0FBQztNQUMvQ2xVLE1BQU0sQ0FBQ3dVLG1CQUFtQixDQUFDLFNBQVMsRUFBRUwsU0FBUyxDQUFDO01BQ2hEblUsTUFBTSxDQUFDd1UsbUJBQW1CLENBQUMsT0FBTyxFQUFFRCxPQUFPLENBQUM7TUFDNUMsSUFBSXhTLFFBQVEsQ0FBQzRDLE9BQU8sRUFBRXFELG9CQUFvQixDQUFDakcsUUFBUSxDQUFDNEMsT0FBTyxDQUFDO0lBQzlELENBQUM7SUFDRDtJQUNBO0lBQ0E7RUFDRixDQUFDLEVBQUUsQ0FBQ3BELFFBQVEsQ0FBQyxDQUFDOztFQUVkO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNFLE1BQU1tVCxvQkFBb0IsR0FBRyxJQUFBL1Msa0JBQVcsRUFDdEMsTUFBT2dULE9BQWUsSUFBdUI7SUFDM0M7SUFDQTtJQUNBO0lBQ0EsSUFBSUMsS0FBSyxHQUFHLElBQUFDLGtDQUFxQixFQUFDRixPQUFPLEVBQUUsSUFBQUcsaUJBQVMsRUFBQyxDQUFDLENBQUM7SUFDdkQsS0FBSyxJQUFJQyxLQUFLLEdBQUcsQ0FBQyxFQUFFLENBQUNILEtBQUssSUFBSUcsS0FBSyxHQUFHLEVBQUUsRUFBRUEsS0FBSyxJQUFJLENBQUMsRUFBRTtNQUNwRCxNQUFNLElBQUlyTyxPQUFPLENBQUVvTCxDQUFDLElBQUs3TCxVQUFVLENBQUM2TCxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7TUFDM0M4QyxLQUFLLEdBQUcsSUFBQUMsa0NBQXFCLEVBQUNGLE9BQU8sRUFBRSxJQUFBRyxpQkFBUyxFQUFDLENBQUMsQ0FBQztJQUNyRDtJQUNBLElBQUksQ0FBQ0YsS0FBSyxFQUFFO01BQ1ZqUCxLQUFLLENBQUMsMERBQTBELEVBQUUsT0FBTyxFQUFFO1FBQUVjLFNBQVMsRUFBRTtNQUFVLENBQUMsQ0FBQztNQUNwRyxPQUFPLEtBQUs7SUFDZDtJQUNBLE1BQU1rQixNQUFNLEdBQUcsSUFBQXFOLGdDQUFtQixFQUFDSixLQUFLLENBQUM7SUFDekMsSUFBSTtNQUNGLElBQUksTUFBTSxJQUFBbkgsdUJBQVcsRUFBQzlGLE1BQU0sQ0FBQyxFQUFFO1FBQzdCLE1BQU1vRixhQUFhLENBQUNwRixNQUFNLENBQUM7TUFDN0IsQ0FBQyxNQUFNO1FBQ0w7UUFDQTtRQUNBekIsUUFBUSxDQUFDdkIsT0FBTyxHQUFHZ0QsTUFBTTtRQUN6QixNQUFNcEMsQ0FBQyxHQUFHZCxRQUFRLENBQUNFLE9BQU87UUFDMUIsTUFBTSxJQUFBc1EscUJBQVMsRUFBQ3ROLE1BQU0sRUFBRTtVQUFFMUUsT0FBTyxFQUFFc0MsQ0FBQyxDQUFDdEMsT0FBTztVQUFFRSxLQUFLLEVBQUVvQyxDQUFDLENBQUNwQyxLQUFLO1VBQUVHLFFBQVEsRUFBRWlDLENBQUMsQ0FBQ2pDO1FBQVMsQ0FBQyxDQUFDO01BQ3ZGO01BQ0FxQyxLQUFLLENBQUMsaUJBQWlCLEVBQUUsT0FBTyxDQUFDO01BQ2pDLE9BQU8sSUFBSTtJQUNiLENBQUMsQ0FBQyxPQUFPaEcsQ0FBQyxFQUFFO01BQ1ZnRyxLQUFLLENBQUMsd0JBQXdCakcsTUFBTSxDQUFDQyxDQUFDLENBQUMsRUFBRSxFQUFFLE9BQU8sRUFBRTtRQUFFOEcsU0FBUyxFQUFFO01BQVUsQ0FBQyxDQUFDO01BQzdFLE9BQU8sS0FBSztJQUNkO0VBQ0YsQ0FBQyxFQUNELENBQUNkLEtBQUssRUFBRW9ILGFBQWEsQ0FDdkIsQ0FBQzs7RUFFRDtFQUNBLElBQUFySSxnQkFBUyxFQUFDLE1BQU07SUFDZCxJQUFJd1EsU0FBUyxHQUFHLEtBQUs7SUFDckIsSUFBSUMsS0FBK0I7SUFDbkMsTUFBTUMsTUFBTSxHQUFHalAsVUFBVSxDQUFDeEIsT0FBTztJQUNqQyxDQUFDLFlBQVk7TUFDWDtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQSxJQUFJMFEsU0FBUyxHQUFHLEtBQUs7TUFDckIsTUFBTS9GLEdBQUcsR0FBRyxNQUFNLElBQUFnRyxpQ0FBb0IsRUFBQyxDQUFDO01BQ3hDLElBQUloRyxHQUFHLEVBQUU7UUFDUCxNQUFNaUcsTUFBTSxHQUFHLE1BQU1iLG9CQUFvQixDQUFDcEYsR0FBRyxDQUFDO1FBQzlDLElBQUlpRyxNQUFNLEVBQUUsTUFBTSxJQUFBQyx5QkFBWSxFQUFDLElBQUksQ0FBQyxDQUFDLEtBQ2hDLE1BQU0sSUFBQUMsNkJBQWdCLEVBQUMsQ0FBQztRQUM3QixJQUFJUCxTQUFTLEVBQUU7UUFDZjtRQUNBO1FBQ0E7UUFDQUcsU0FBUyxHQUFHRSxNQUFNO01BQ3BCO01BRUEsSUFBSSxDQUFDRixTQUFTLEVBQUU7UUFDZCxJQUFJMU4sTUFBbUI7UUFDdkIsSUFBSTtVQUNGO1VBQ0E7VUFDQUEsTUFBTSxHQUFHLE1BQU0sSUFBQStOLDJCQUFlLEVBQUMsQ0FBQztRQUNsQyxDQUFDLENBQUMsTUFBTTtVQUNOLElBQUksQ0FBQ1IsU0FBUyxFQUFFdlAsS0FBSyxDQUFDLGlEQUFpRCxFQUFFLE1BQU0sRUFBRTtZQUFFYyxTQUFTLEVBQUU7VUFBZSxDQUFDLENBQUM7VUFDL0c7UUFDRjtRQUNBLElBQUl5TyxTQUFTLEVBQUU7UUFDZmhQLFFBQVEsQ0FBQ3ZCLE9BQU8sR0FBR2dELE1BQU07UUFDekIsSUFBSTtVQUNGLElBQUksTUFBTSxJQUFBOEYsdUJBQVcsRUFBQzlGLE1BQU0sQ0FBQyxFQUFFO1lBQzdCLE1BQU1xRixLQUFLLEdBQUcsTUFBTSxJQUFBQyxxQkFBUyxFQUFDdEYsTUFBTSxDQUFDO1lBQ3JDLElBQUksQ0FBQ3VOLFNBQVMsRUFBRTtjQUNkdFEsTUFBTSxDQUFDO2dCQUNMM0IsT0FBTyxFQUFFK0osS0FBSyxDQUFDL0osT0FBTztnQkFDdEJFLEtBQUssRUFBRTZKLEtBQUssQ0FBQzdKLEtBQUssQ0FBQ2dHLE1BQU0sR0FBRzZELEtBQUssQ0FBQzdKLEtBQUssR0FBR0MscUJBQVUsQ0FBQ0MsS0FBSyxDQUFDLENBQUM7Z0JBQzVEQyxRQUFRLEVBQUUwSixLQUFLLENBQUMxSixRQUFRLENBQUM2RixNQUFNLEdBQUc2RCxLQUFLLENBQUMxSixRQUFRLEdBQUdDO2NBQ3JELENBQUMsQ0FBQztjQUNGb0MsS0FBSyxDQUFDLCtCQUErQixFQUFFLE9BQU8sQ0FBQztZQUNqRDtVQUNGLENBQUMsTUFBTTtZQUNMO1lBQ0EsTUFBTUosQ0FBQyxHQUFHZCxRQUFRLENBQUNFLE9BQU87WUFDMUIsTUFBTSxJQUFBc1EscUJBQVMsRUFBQ3ROLE1BQU0sRUFBRTtjQUFFMUUsT0FBTyxFQUFFc0MsQ0FBQyxDQUFDdEMsT0FBTztjQUFFRSxLQUFLLEVBQUVvQyxDQUFDLENBQUNwQyxLQUFLO2NBQUVHLFFBQVEsRUFBRWlDLENBQUMsQ0FBQ2pDO1lBQVMsQ0FBQyxDQUFDO1lBQ3JGLElBQUksQ0FBQzRSLFNBQVMsRUFBRXZQLEtBQUssQ0FBQyw4QkFBOEIsRUFBRSxPQUFPLENBQUM7VUFDaEU7UUFDRixDQUFDLENBQUMsT0FBT2hHLENBQUMsRUFBRTtVQUNWLElBQUksQ0FBQ3VWLFNBQVMsRUFBRXZQLEtBQUssQ0FBQyxzQkFBc0JqRyxNQUFNLENBQUNDLENBQUMsQ0FBQyxFQUFFLEVBQUUsT0FBTyxFQUFFO1lBQUU4RyxTQUFTLEVBQUU7VUFBVSxDQUFDLENBQUM7UUFDN0Y7TUFDRjtNQUNBLElBQUl5TyxTQUFTLEVBQUU7TUFDZjtNQUNBO01BQ0EsSUFBSTtRQUNGdFEsTUFBTSxDQUFDO1VBQUVKLE1BQU0sRUFBRSxJQUFBc1EsaUJBQVMsRUFBQztRQUFFLENBQUMsQ0FBQztNQUNqQyxDQUFDLENBQUMsTUFBTTtRQUNOO01BQUE7TUFFRjtNQUNBO01BQ0E7TUFDQTtNQUNBLElBQUk7UUFDRkssS0FBSyxHQUFHLElBQUFRLHNCQUFjLEVBQUMsQ0FBQ25SLE1BQU0sRUFBRXdHLE9BQU8sS0FBSztVQUMxQ3BHLE1BQU0sQ0FBQztZQUFFSjtVQUFPLENBQUMsQ0FBQztVQUNsQixNQUFNb1IsR0FBRyxHQUFHMVAsUUFBUSxDQUFDdkIsT0FBTztVQUM1QixJQUFJLENBQUNpUixHQUFHLEVBQUU7VUFDVixNQUFNQyxDQUFDLEdBQUdyUixNQUFNLENBQUM4QyxJQUFJLENBQUUxRyxDQUFDLElBQU1nVixHQUFHLENBQUNySSxPQUFPLEdBQUczTSxDQUFDLENBQUNKLEVBQUUsS0FBS29WLEdBQUcsQ0FBQ3JJLE9BQU8sR0FBRzNNLENBQUMsQ0FBQ3lOLElBQUksS0FBS3VILEdBQUcsQ0FBQ3JXLElBQUssQ0FBQztVQUN4RixJQUFJc1csQ0FBQyxFQUFFO1lBQ0wsTUFBTXZULElBQUksR0FBR3VULENBQUMsQ0FBQ3ZULElBQUksS0FBSyxJQUFJLEdBQUcsSUFBSSxHQUFHLElBQUk7WUFDMUMsSUFBSUEsSUFBSSxLQUFLc1QsR0FBRyxDQUFDdFQsSUFBSSxFQUFFO2NBQ3JCNEQsUUFBUSxDQUFDdkIsT0FBTyxHQUFHO2dCQUFFLEdBQUdpUixHQUFHO2dCQUFFdFQ7Y0FBSyxDQUFDO2NBQ25DLElBQUlBLElBQUksS0FBSyxJQUFJLEVBQUU7Z0JBQ2pCc0MsTUFBTSxDQUFDO2tCQUFFdEMsSUFBSSxFQUFFLEtBQUs7a0JBQUVrQixTQUFTLEVBQUUsRUFBRTtrQkFBRU0sYUFBYSxFQUFFO2dCQUFNLENBQUMsQ0FBQztnQkFDNUQ2QixLQUFLLENBQUMsbUNBQW1DLEVBQUUsTUFBTSxFQUFFO2tCQUFFYyxTQUFTLEVBQUU7Z0JBQWUsQ0FBQyxDQUFDO2NBQ25GO1lBQ0Y7VUFDRixDQUFDLE1BQU0sSUFBSXVFLE9BQU8sQ0FBQ3hCLElBQUksQ0FBRXNJLENBQUMsSUFBTThELEdBQUcsQ0FBQ3JJLE9BQU8sR0FBR3VFLENBQUMsQ0FBQ3RSLEVBQUUsS0FBS29WLEdBQUcsQ0FBQ3JJLE9BQU8sR0FBR3VFLENBQUMsQ0FBQ3pELElBQUksS0FBS3VILEdBQUcsQ0FBQ3JXLElBQUssQ0FBQyxFQUFFO1lBQzFGMkcsUUFBUSxDQUFDdkIsT0FBTyxHQUFHLElBQUk7WUFDdkJnQixLQUFLLENBQUMsMkJBQTJCLEVBQUUsT0FBTyxFQUFFO2NBQUVjLFNBQVMsRUFBRTtZQUFlLENBQUMsQ0FBQztVQUM1RTtRQUNGLENBQUMsQ0FBQztNQUNKLENBQUMsQ0FBQyxNQUFNO1FBQ047TUFBQTtJQUVKLENBQUMsRUFBRSxDQUFDO0lBQ0osT0FBTyxNQUFNO01BQ1h5TyxTQUFTLEdBQUcsSUFBSTtNQUNoQkMsS0FBSyxHQUFHLENBQUM7TUFDVCxLQUFLLE1BQU1uTSxDQUFDLElBQUlvTSxNQUFNLENBQUNVLE1BQU0sQ0FBQyxDQUFDLEVBQUUzTyxZQUFZLENBQUM2QixDQUFDLENBQUM7TUFDaERvTSxNQUFNLENBQUNXLEtBQUssQ0FBQyxDQUFDO01BQ2QsSUFBSS9ULFNBQVMsQ0FBQzJDLE9BQU8sRUFBRXdDLFlBQVksQ0FBQ25GLFNBQVMsQ0FBQzJDLE9BQU8sQ0FBQztNQUN0RDNDLFNBQVMsQ0FBQzJDLE9BQU8sR0FBRyxJQUFJO0lBQzFCLENBQUM7SUFDRDtJQUNBO0VBQ0YsQ0FBQyxFQUFFLEVBQUUsQ0FBQztFQUVOLE9BQU87SUFDTHZDLEtBQUs7SUFDTFYsY0FBYztJQUNkc1UsU0FBUyxFQUFFOVAsUUFBUSxDQUFDdkIsT0FBTyxFQUFFcEYsSUFBSSxJQUFJLElBQUk7SUFDekN3RixRQUFRO0lBQ1I7SUFDQWtSLE9BQU8sRUFBR2xXLEVBQVUsSUFBSyxJQUFBa1csZUFBTyxFQUFDN1QsS0FBSyxDQUFDUSxHQUFHLEVBQUU3QyxFQUFFLENBQUM7SUFDL0NtVyxPQUFPLEVBQUdoVyxFQUFVLElBQUssSUFBQWdXLGVBQU8sRUFBQzlULEtBQUssQ0FBQ1EsR0FBRyxFQUFFMUMsRUFBRSxDQUFDO0lBQy9DaVcsT0FBTyxFQUFFQSxDQUFDN0ssRUFBVSxFQUFFQyxFQUFVLEtBQUssSUFBQTRLLGVBQU8sRUFBQy9ULEtBQUssQ0FBQ1EsR0FBRyxFQUFFUixLQUFLLENBQUNZLEVBQUUsRUFBRXNJLEVBQUUsRUFBRUMsRUFBRSxDQUFDO0lBQ3pFcEcsT0FBTztJQUNQaVIsU0FBUyxFQUFUQSxpQkFBUztJQUNUMU8sS0FBSztJQUNMMk8sV0FBVyxFQUFYQSxxQkFBVztJQUNYO0lBQ0E3RyxZQUFZO0lBQ1o4QixnQkFBZ0I7SUFDaEJyQixjQUFjO0lBQ2RNLFdBQVc7SUFDWEMsWUFBWTtJQUNaRSxRQUFRO0lBQ1JDLGNBQWM7SUFDZDlGLE1BQU07SUFDTkMsY0FBYztJQUNkO0lBQ0FnRSxZQUFZO0lBQ1pLLFVBQVU7SUFDVkUsaUJBQWlCO0lBQ2pCO0lBQ0F6RSxRQUFRO0lBQ1IwRCxXQUFXO0lBQ1h2RCxlQUFlO0lBQ2ZLLFlBQVk7SUFDWjtJQUNBYyxXQUFXO0lBQ1g4QixTQUFTO0lBQ1ROLFdBQVc7SUFDWE8sUUFBUTtJQUNSTixVQUFVO0lBQ1ZQLFdBQVc7SUFDWGMsUUFBUTtJQUNSO0lBQ0FqRixRQUFRO0lBQ1JLLFVBQVU7SUFDVkcsY0FBYztJQUNkYixXQUFXO0lBQ1h3QixXQUFXO0lBQ1hFLFFBQVE7SUFDUkcsUUFBUTtJQUNSSixRQUFRO0lBQ1JNLFFBQVE7SUFDUjtJQUNBaUcsTUFBTTtJQUNOQyxPQUFPO0lBQ1BDLFdBQVc7SUFDWEMsV0FBVztJQUNYSSxjQUFjO0lBQ2RDLFVBQVU7SUFDVkgsYUFBYTtJQUNiQyxRQUFRO0lBQ1JGLFNBQVM7SUFDVEssY0FBYztJQUNkO0lBQ0ExTCxLQUFLO0lBQ0xGLFlBQVk7SUFDWitMLE9BQU87SUFDUEM7RUFDRixDQUFDO0FBQ0giLCJpZ25vcmVMaXN0IjpbXX0=