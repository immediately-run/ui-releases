var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      code: "code",
      del: "del",
      h1: "h1",
      h2: "h2",
      hr: "hr",
      li: "li",
      p: "p",
      strong: "strong",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "code_spec_references-lodestar",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "code_spec_references-lodestar"
      }), "CODE_SPEC_REFERENCES — Lodestar"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Durable index of ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "non-trivial"
      }), " code↔spec mappings. Seeded by the 2026-06\ncode-verification pass (R3-124; plan ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "08-system-apps.md"
      }), "). Most Lodestar\nspec-refs are trivial inline ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "spec §N"
      }), " comments (the bare ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "spec §N"
      }), " convention =\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "WHITEBOARD_SPEC §N"
      }), ", which lives in the whiteboard-app docs subdir, not the main\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "docs/specs/"
      }), " checkout). This file records only the non-obvious mappings."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "the-importmeta-ban-__wb_dev__-define-claudemd-hard-rule-9",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-importmeta-ban-__wb_dev__-define-claudemd-hard-rule-9"
      }), "The ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "import.meta"
      }), " ban ↔ ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "__WB_DEV__"
      }), " define (CLAUDE.md hard-rule #9)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Why non-obvious:"
      }), " immediately.run transpiles each module to CommonJS and runs\nit as a classic script, where ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "import.meta"
      }), " is a ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["parse-time ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "SyntaxError"
        })]
      }), "\n(\"Cannot use 'import.meta' outside a module\") — it fails before any code runs, so\na ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "?."
      }), " runtime guard cannot save it. Vite replaces ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "import.meta"
      }), " at build time, so\nit looks fine in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "vite dev"
      }), " and only breaks on immediately.run."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["Mapping (verified 2026-06 — correctly implemented; DO NOT reintroduce\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "import.meta"
        }), "):"]
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "vite.config.ts"
        }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "define: { __WB_DEV__: ... }"
        }), " injects a dev-only flag."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/lib/boardStore.ts"
        }), " — reads it behind a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "typeof __WB_DEV__ !== 'undefined'"
        }), "\nguard (declares ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "__WB_DEV__: boolean | undefined"
        }), "). No file in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/"
        }), " writes the\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "import.meta"
        }), " token (only comments mention it)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "the-three-task-invoke-surface",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-three-task-invoke-surface"
      }), "The three-task invoke surface"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Spec:"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "WHITEBOARD_SPEC"
      }), " (+ ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "PICK_FILE_TASK_SPEC"
      }), "). core_concepts §6 (Service)\n/ §5 (display-in-a-region capability). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "package.json"
      }), " declares\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "invokes: pick-file, share-space, edit-file"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Mapping (verified 2026-06):"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "pick-file"
        }), " — fully wired: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/lib/pickFile.ts"
        }), " calls\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "invokeTask<PickFileResult>('pick-file', …)"
        }), ", returns ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "null"
        }), " on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "cancelled"
        }), "\n(callers degrade with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "if (!res) return"
        }), "). This is the live, complete path."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "share-space"
        }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "edit-file"
        }), " — declared as ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "invokes"
        }), " and surfaced as ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "toast\nplaceholders"
        }), " today (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "TopBar.tsx"
        }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "MobileChrome.tsx"
        }), " for share-space;\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Inspector.tsx"
        }), " for edit-file \"Open source\"). They degrade rather than crash\nwhen the task is absent (core_concepts invariant: \"expect absence\"). Recorded as\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "partial / placeholder"
        }), ", not a Done-but-absent gap — the manifest correctly\ndeclares intent and the UI handles absence."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "recorded-findings-code-verification-pass-2026-06",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "recorded-findings-code-verification-pass-2026-06"
      }), "Recorded findings (code-verification pass, 2026-06)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "SDK-version skew — RESOLVED (verified 2026-09-22, R3-737 review):"
        }), " the 2026-06\nentry recorded a pin of ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "0.8.1"
        }), " while others sat lower; the pin has since moved\n(now ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "^0.17.0"
        }), ") and the skew class is fleet-maintenance debt tracked across the\nexample repos, not here. No action in this repo."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Vocabulary:"
        }), " no ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "kernel"
        }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "primary application"
        }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "trust tier"
        }), " in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/"
        }), ";\nuses \"stage app\" correctly. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "main.tsx"
        }), " carries no app logic/CSS."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "requireLatest: \"optimistic\""
          })
        }), " (the default) — appropriate; not a finding."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.del, {
            children: ["BUILD RED on origin/main (pre-existing, SDK-skew) — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "capDir"
            }), " not exported."]
          })
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "RESOLVED (verified 2026-09-22, R3-737 review):"
        }), " the current pin\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "@immediately-run/sdk ^0.17.0"
        }), ") exports ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "capDir"
        }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npm run build"
        }), " is green\non this head — the recorded ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "TS2339"
        }), " no longer reproduces; the entry is kept\nstruck as the resolution record rather than deleted (this file is a ledger)."]
      }), "\n"]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/CODE_SPEC_REFERENCES.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJjb2RlIiwiZGVsIiwiaDEiLCJoMiIsImhyIiwibGkiLCJwIiwic3Ryb25nIiwidWwiLCJfcHJvdmlkZUNvbXBvbmVudHMiLCJjb21wb25lbnRzIiwiSGVhZGluZ0FuY2hvciIsIl9taXNzaW5nTWR4UmVmZXJlbmNlIiwianN4cyIsIkZyYWdtZW50IiwiY2hpbGRyZW4iLCJpZCIsImpzeCIsIk1EWENvbnRlbnQiLCJ3cmFwcGVyIiwiTURYTGF5b3V0IiwiX2MiLCJjb21wb25lbnQiLCJwbGFjZSIsIkVycm9yIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQ09ERV9TUEVDX1JFRkVSRU5DRVMubWQiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgZGVsOiBcImRlbFwiLFxuICAgIGgxOiBcImgxXCIsXG4gICAgaDI6IFwiaDJcIixcbiAgICBocjogXCJoclwiLFxuICAgIGxpOiBcImxpXCIsXG4gICAgcDogXCJwXCIsXG4gICAgc3Ryb25nOiBcInN0cm9uZ1wiLFxuICAgIHVsOiBcInVsXCIsXG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9LCB7SGVhZGluZ0FuY2hvcn0gPSBfY29tcG9uZW50cztcbiAgaWYgKCFIZWFkaW5nQW5jaG9yKSBfbWlzc2luZ01keFJlZmVyZW5jZShcIkhlYWRpbmdBbmNob3JcIiwgdHJ1ZSk7XG4gIHJldHVybiA8PjxfY29tcG9uZW50cy5oMSBpZD1cImNvZGVfc3BlY19yZWZlcmVuY2VzLWxvZGVzdGFyXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJjb2RlX3NwZWNfcmVmZXJlbmNlcy1sb2Rlc3RhclwiIC8+e1wiQ09ERV9TUEVDX1JFRkVSRU5DRVMg4oCUIExvZGVzdGFyXCJ9PC9fY29tcG9uZW50cy5oMT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJEdXJhYmxlIGluZGV4IG9mIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibm9uLXRyaXZpYWxcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgY29kZeKGlHNwZWMgbWFwcGluZ3MuIFNlZWRlZCBieSB0aGUgMjAyNi0wNlxcbmNvZGUtdmVyaWZpY2F0aW9uIHBhc3MgKFIzLTEyNDsgcGxhbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCIwOC1zeXN0ZW0tYXBwcy5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLiBNb3N0IExvZGVzdGFyXFxuc3BlYy1yZWZzIGFyZSB0cml2aWFsIGlubGluZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcGVjIMKnTlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgY29tbWVudHMgKHRoZSBiYXJlIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNwZWMgwqdOXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjb252ZW50aW9uID1cXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJXSElURUJPQVJEX1NQRUMgwqdOXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgd2hpY2ggbGl2ZXMgaW4gdGhlIHdoaXRlYm9hcmQtYXBwIGRvY3Mgc3ViZGlyLCBub3QgdGhlIG1haW5cXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJkb2NzL3NwZWNzL1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgY2hlY2tvdXQpLiBUaGlzIGZpbGUgcmVjb3JkcyBvbmx5IHRoZSBub24tb2J2aW91cyBtYXBwaW5ncy5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwidGhlLWltcG9ydG1ldGEtYmFuLV9fd2JfZGV2X18tZGVmaW5lLWNsYXVkZW1kLWhhcmQtcnVsZS05XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJ0aGUtaW1wb3J0bWV0YS1iYW4tX193Yl9kZXZfXy1kZWZpbmUtY2xhdWRlbWQtaGFyZC1ydWxlLTlcIiAvPntcIlRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJpbXBvcnQubWV0YVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYmFuIOKGlCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJfX1dCX0RFVl9fXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBkZWZpbmUgKENMQVVERS5tZCBoYXJkLXJ1bGUgIzkpXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIldoeSBub24tb2J2aW91czpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgaW1tZWRpYXRlbHkucnVuIHRyYW5zcGlsZXMgZWFjaCBtb2R1bGUgdG8gQ29tbW9uSlMgYW5kIHJ1bnNcXG5pdCBhcyBhIGNsYXNzaWMgc2NyaXB0LCB3aGVyZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJpbXBvcnQubWV0YVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaXMgYSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInBhcnNlLXRpbWUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiU3ludGF4RXJyb3JcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiXFxuKFxcXCJDYW5ub3QgdXNlICdpbXBvcnQubWV0YScgb3V0c2lkZSBhIG1vZHVsZVxcXCIpIOKAlCBpdCBmYWlscyBiZWZvcmUgYW55IGNvZGUgcnVucywgc29cXG5hIFwifTxfY29tcG9uZW50cy5jb2RlPntcIj8uXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBydW50aW1lIGd1YXJkIGNhbm5vdCBzYXZlIGl0LiBWaXRlIHJlcGxhY2VzIFwifTxfY29tcG9uZW50cy5jb2RlPntcImltcG9ydC5tZXRhXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhdCBidWlsZCB0aW1lLCBzb1xcbml0IGxvb2tzIGZpbmUgaW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widml0ZSBkZXZcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFuZCBvbmx5IGJyZWFrcyBvbiBpbW1lZGlhdGVseS5ydW4uXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiTWFwcGluZyAodmVyaWZpZWQgMjAyNi0wNiDigJQgY29ycmVjdGx5IGltcGxlbWVudGVkOyBETyBOT1QgcmVpbnRyb2R1Y2VcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJpbXBvcnQubWV0YVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5jb2RlPntcInZpdGUuY29uZmlnLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZGVmaW5lOiB7IF9fV0JfREVWX186IC4uLiB9XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpbmplY3RzIGEgZGV2LW9ubHkgZmxhZy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuY29kZT57XCJzcmMvbGliL2JvYXJkU3RvcmUudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCByZWFkcyBpdCBiZWhpbmQgYSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ0eXBlb2YgX19XQl9ERVZfXyAhPT0gJ3VuZGVmaW5lZCdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxuZ3VhcmQgKGRlY2xhcmVzIFwifTxfY29tcG9uZW50cy5jb2RlPntcIl9fV0JfREVWX186IGJvb2xlYW4gfCB1bmRlZmluZWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKS4gTm8gZmlsZSBpbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB3cml0ZXMgdGhlXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW1wb3J0Lm1ldGFcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHRva2VuIChvbmx5IGNvbW1lbnRzIG1lbnRpb24gaXQpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJ0aGUtdGhyZWUtdGFzay1pbnZva2Utc3VyZmFjZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwidGhlLXRocmVlLXRhc2staW52b2tlLXN1cmZhY2VcIiAvPntcIlRoZSB0aHJlZS10YXNrIGludm9rZSBzdXJmYWNlXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlNwZWM6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5jb2RlPntcIldISVRFQk9BUkRfU1BFQ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKCsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiUElDS19GSUxFX1RBU0tfU1BFQ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLiBjb3JlX2NvbmNlcHRzIMKnNiAoU2VydmljZSlcXG4vIMKnNSAoZGlzcGxheS1pbi1hLXJlZ2lvbiBjYXBhYmlsaXR5KS4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicGFja2FnZS5qc29uXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBkZWNsYXJlc1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcImludm9rZXM6IHBpY2stZmlsZSwgc2hhcmUtc3BhY2UsIGVkaXQtZmlsZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiTWFwcGluZyAodmVyaWZpZWQgMjAyNi0wNik6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJwaWNrLWZpbGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIGZ1bGx5IHdpcmVkOiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvbGliL3BpY2tGaWxlLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjYWxsc1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcImludm9rZVRhc2s8UGlja0ZpbGVSZXN1bHQ+KCdwaWNrLWZpbGUnLCDigKYpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgcmV0dXJucyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJudWxsXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBvbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjYW5jZWxsZWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxuKGNhbGxlcnMgZGVncmFkZSB3aXRoIFwifTxfY29tcG9uZW50cy5jb2RlPntcImlmICghcmVzKSByZXR1cm5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiKS4gVGhpcyBpcyB0aGUgbGl2ZSwgY29tcGxldGUgcGF0aC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcInNoYXJlLXNwYWNlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIC8gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJlZGl0LWZpbGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIGRlY2xhcmVkIGFzIFwifTxfY29tcG9uZW50cy5jb2RlPntcImludm9rZXNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFuZCBzdXJmYWNlZCBhcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInRvYXN0XFxucGxhY2Vob2xkZXJzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHRvZGF5IChcIn08X2NvbXBvbmVudHMuY29kZT57XCJUb3BCYXIudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAvIFwifTxfY29tcG9uZW50cy5jb2RlPntcIk1vYmlsZUNocm9tZS50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGZvciBzaGFyZS1zcGFjZTtcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJJbnNwZWN0b3IudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBmb3IgZWRpdC1maWxlIFxcXCJPcGVuIHNvdXJjZVxcXCIpLiBUaGV5IGRlZ3JhZGUgcmF0aGVyIHRoYW4gY3Jhc2hcXG53aGVuIHRoZSB0YXNrIGlzIGFic2VudCAoY29yZV9jb25jZXB0cyBpbnZhcmlhbnQ6IFxcXCJleHBlY3QgYWJzZW5jZVxcXCIpLiBSZWNvcmRlZCBhc1xcblwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicGFydGlhbCAvIHBsYWNlaG9sZGVyXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBub3QgYSBEb25lLWJ1dC1hYnNlbnQgZ2FwIOKAlCB0aGUgbWFuaWZlc3QgY29ycmVjdGx5XFxuZGVjbGFyZXMgaW50ZW50IGFuZCB0aGUgVUkgaGFuZGxlcyBhYnNlbmNlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaHIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJyZWNvcmRlZC1maW5kaW5ncy1jb2RlLXZlcmlmaWNhdGlvbi1wYXNzLTIwMjYtMDZcIj48SGVhZGluZ0FuY2hvciBpZD1cInJlY29yZGVkLWZpbmRpbmdzLWNvZGUtdmVyaWZpY2F0aW9uLXBhc3MtMjAyNi0wNlwiIC8+e1wiUmVjb3JkZWQgZmluZGluZ3MgKGNvZGUtdmVyaWZpY2F0aW9uIHBhc3MsIDIwMjYtMDYpXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiU0RLLXZlcnNpb24gc2tldyDigJQgUkVTT0xWRUQgKHZlcmlmaWVkIDIwMjYtMDktMjIsIFIzLTczNyByZXZpZXcpOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB0aGUgMjAyNi0wNlxcbmVudHJ5IHJlY29yZGVkIGEgcGluIG9mIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjAuOC4xXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB3aGlsZSBvdGhlcnMgc2F0IGxvd2VyOyB0aGUgcGluIGhhcyBzaW5jZSBtb3ZlZFxcbihub3cgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiXjAuMTcuMFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpIGFuZCB0aGUgc2tldyBjbGFzcyBpcyBmbGVldC1tYWludGVuYW5jZSBkZWJ0IHRyYWNrZWQgYWNyb3NzIHRoZVxcbmV4YW1wbGUgcmVwb3MsIG5vdCBoZXJlLiBObyBhY3Rpb24gaW4gdGhpcyByZXBvLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVm9jYWJ1bGFyeTpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgbm8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wia2VybmVsXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAvIFwifTxfY29tcG9uZW50cy5jb2RlPntcInByaW1hcnkgYXBwbGljYXRpb25cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIC8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widHJ1c3QgdGllclwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL1wifTwvX2NvbXBvbmVudHMuY29kZT57XCI7XFxudXNlcyBcXFwic3RhZ2UgYXBwXFxcIiBjb3JyZWN0bHkuIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1haW4udHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjYXJyaWVzIG5vIGFwcCBsb2dpYy9DU1MuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz48X2NvbXBvbmVudHMuY29kZT57XCJyZXF1aXJlTGF0ZXN0OiBcXFwib3B0aW1pc3RpY1xcXCJcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICh0aGUgZGVmYXVsdCkg4oCUIGFwcHJvcHJpYXRlOyBub3QgYSBmaW5kaW5nLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+PF9jb21wb25lbnRzLmRlbD57XCJCVUlMRCBSRUQgb24gb3JpZ2luL21haW4gKHByZS1leGlzdGluZywgU0RLLXNrZXcpIOKAlCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjYXBEaXJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG5vdCBleHBvcnRlZC5cIn08L19jb21wb25lbnRzLmRlbD48L19jb21wb25lbnRzLnN0cm9uZz57XCJcXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlJFU09MVkVEICh2ZXJpZmllZCAyMDI2LTA5LTIyLCBSMy03MzcgcmV2aWV3KTpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdGhlIGN1cnJlbnQgcGluXFxuKFwifTxfY29tcG9uZW50cy5jb2RlPntcIkBpbW1lZGlhdGVseS1ydW4vc2RrIF4wLjE3LjBcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSBleHBvcnRzIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNhcERpclwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYW5kIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm5wbSBydW4gYnVpbGRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGlzIGdyZWVuXFxub24gdGhpcyBoZWFkIOKAlCB0aGUgcmVjb3JkZWQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiVFMyMzM5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBubyBsb25nZXIgcmVwcm9kdWNlczsgdGhlIGVudHJ5IGlzIGtlcHRcXG5zdHJ1Y2sgYXMgdGhlIHJlc29sdXRpb24gcmVjb3JkIHJhdGhlciB0aGFuIGRlbGV0ZWQgKHRoaXMgZmlsZSBpcyBhIGxlZGdlcikuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPjwvPjtcbn1cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE1EWENvbnRlbnQocHJvcHMgPSB7fSkge1xuICBjb25zdCB7d3JhcHBlcjogTURYTGF5b3V0fSA9IHtcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH07XG4gIHJldHVybiBNRFhMYXlvdXQgPyA8TURYTGF5b3V0IHsuLi5wcm9wc30+PF9jcmVhdGVNZHhDb250ZW50IHsuLi5wcm9wc30gLz48L01EWExheW91dD4gOiBfY3JlYXRlTWR4Q29udGVudChwcm9wcyk7XG59XG5mdW5jdGlvbiBfbWlzc2luZ01keFJlZmVyZW5jZShpZCwgY29tcG9uZW50LCBwbGFjZSkge1xuICB0aHJvdyBuZXcgRXJyb3IoXCJFeHBlY3RlZCBcIiArIChjb21wb25lbnQgPyBcImNvbXBvbmVudFwiIDogXCJvYmplY3RcIikgKyBcIiBgXCIgKyBpZCArIFwiYCB0byBiZSBkZWZpbmVkOiB5b3UgbGlrZWx5IGZvcmdvdCB0byBpbXBvcnQsIHBhc3MsIG9yIHByb3ZpZGUgaXQuXCIgKyAocGxhY2UgPyBcIlxcbkl04oCZcyByZWZlcmVuY2VkIGluIHlvdXIgY29kZSBhdCBgXCIgKyBwbGFjZSArIFwiYCBpbiBgL2FwcC9DT0RFX1NQRUNfUkVGRVJFTkNFUy5tZGBcIiA6IFwiXCIpKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQXdGLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUZ4RjtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU1DLFdBQVcsR0FBRztNQUNsQkMsSUFBSSxFQUFFLE1BQU07TUFDWkMsR0FBRyxFQUFFLEtBQUs7TUFDVkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsTUFBTSxFQUFFLFFBQVE7TUFDaEJDLEVBQUUsRUFBRSxJQUFJO01BQ1IsR0FBRyxJQUFBQyw2QkFBa0IsRUFBQyxDQUFDO01BQ3ZCLEdBQUdYLEtBQUssQ0FBQ1k7SUFDWCxDQUFDO0lBQUU7TUFBQ0M7SUFBYSxDQUFDLEdBQUdaLFdBQVc7RUFDaEMsSUFBSSxDQUFDWSxhQUFhLEVBQUVDLG9CQUFvQixDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUM7RUFDL0Qsb0JBQU8sSUFBQWhCLFdBQUEsQ0FBQWlCLElBQUEsRUFBQWpCLFdBQUEsQ0FBQWtCLFFBQUE7SUFBQUMsUUFBQSxnQkFBRSxJQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNHLEVBQUU7TUFBQ2MsRUFBRSxFQUFDLCtCQUErQjtNQUFBRCxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQStCLENBQUUsQ0FBQyxFQUFDLGlDQUFpQztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDTyxDQUFDO01BQUFTLFFBQUEsR0FBRSxtQkFBbUIsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDUSxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFhLENBQXFCLENBQUMsRUFBQyxtRkFBbUYsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFlLFFBQUEsRUFBRTtNQUFtQixDQUFtQixDQUFDLEVBQUMsaURBQWlELGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBZSxRQUFBLEVBQUU7TUFBUyxDQUFtQixDQUFDLEVBQUMsc0JBQXNCLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBZSxRQUFBLEVBQUU7TUFBUyxDQUFtQixDQUFDLEVBQUMsaUJBQWlCLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBZSxRQUFBLEVBQUU7TUFBb0IsQ0FBbUIsQ0FBQyxFQUFDLGlFQUFpRSxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLElBQUk7UUFBQWUsUUFBQSxFQUFFO01BQWEsQ0FBbUIsQ0FBQyxFQUFDLDhEQUE4RDtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDSSxFQUFFO01BQUNhLEVBQUUsRUFBQywyREFBMkQ7TUFBQUQsUUFBQSxnQkFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUEyRCxDQUFFLENBQUMsRUFBQyxNQUFNLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBZSxRQUFBLEVBQUU7TUFBYSxDQUFtQixDQUFDLEVBQUMsU0FBUyxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLElBQUk7UUFBQWUsUUFBQSxFQUFFO01BQVksQ0FBbUIsQ0FBQyxFQUFDLGtDQUFrQztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDTyxDQUFDO01BQUFTLFFBQUEsZ0JBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1EsTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBa0IsQ0FBcUIsQ0FBQyxFQUFDLDhGQUE4RixlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLElBQUk7UUFBQWUsUUFBQSxFQUFFO01BQWEsQ0FBbUIsQ0FBQyxFQUFDLFFBQVEsZUFBQyxJQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNRLE1BQU07UUFBQVEsUUFBQSxHQUFFLGFBQWEsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUM7TUFBQSxDQUFvQixDQUFDLEVBQUMsMkZBQTJGLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBZSxRQUFBLEVBQUU7TUFBSSxDQUFtQixDQUFDLEVBQUMsK0NBQStDLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBZSxRQUFBLEVBQUU7TUFBYSxDQUFtQixDQUFDLEVBQUMsdUNBQXVDLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBZSxRQUFBLEVBQUU7TUFBVSxDQUFtQixDQUFDLEVBQUMsc0NBQXNDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDTyxDQUFDO01BQUFTLFFBQUEsZUFBQyxJQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNRLE1BQU07UUFBQVEsUUFBQSxHQUFFLHlFQUF5RSxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLElBQUk7VUFBQWUsUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQyxFQUFDLElBQUk7TUFBQSxDQUFxQjtJQUFDLENBQWUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNTLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNNLEVBQUU7UUFBQVUsUUFBQSxnQkFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFnQixDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLElBQUk7VUFBQWUsUUFBQSxFQUFFO1FBQTZCLENBQW1CLENBQUMsRUFBQywyQkFBMkI7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ00sRUFBRTtRQUFBVSxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLElBQUk7VUFBQWUsUUFBQSxFQUFFO1FBQXVCLENBQW1CLENBQUMsRUFBQyx1QkFBdUIsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFtQyxDQUFtQixDQUFDLEVBQUMsb0JBQW9CLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBaUMsQ0FBbUIsQ0FBQyxFQUFDLGdCQUFnQixlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLElBQUk7VUFBQWUsUUFBQSxFQUFFO1FBQU0sQ0FBbUIsQ0FBQyxFQUFDLGVBQWUsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyxvQ0FBb0M7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDSSxFQUFFO01BQUNhLEVBQUUsRUFBQywrQkFBK0I7TUFBQUQsUUFBQSxnQkFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUErQixDQUFFLENBQUMsRUFBQywrQkFBK0I7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ08sQ0FBQztNQUFBUyxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNRLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQU8sQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFlLFFBQUEsRUFBRTtNQUFpQixDQUFtQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLElBQUk7UUFBQWUsUUFBQSxFQUFFO01BQXFCLENBQW1CLENBQUMsRUFBQyx3RUFBd0UsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFlLFFBQUEsRUFBRTtNQUFjLENBQW1CLENBQUMsRUFBQyxhQUFhLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBZSxRQUFBLEVBQUU7TUFBNEMsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNPLENBQUM7TUFBQVMsUUFBQSxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNRLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQTZCLENBQXFCO0lBQUMsQ0FBZSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ1MsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ00sRUFBRTtRQUFBVSxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNRLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQVcsQ0FBcUIsQ0FBQyxFQUFDLGtCQUFrQixlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLElBQUk7VUFBQWUsUUFBQSxFQUFFO1FBQXFCLENBQW1CLENBQUMsRUFBQyxVQUFVLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBNEMsQ0FBbUIsQ0FBQyxFQUFDLFlBQVksZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFNLENBQW1CLENBQUMsRUFBQyxNQUFNLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsMEJBQTBCLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBa0IsQ0FBbUIsQ0FBQyxFQUFDLHFDQUFxQztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDTSxFQUFFO1FBQUFVLFFBQUEsZ0JBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1EsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBYSxDQUFxQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNRLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQVcsQ0FBcUIsQ0FBQyxFQUFDLGlCQUFpQixlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLElBQUk7VUFBQWUsUUFBQSxFQUFFO1FBQVMsQ0FBbUIsQ0FBQyxFQUFDLG1CQUFtQixlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNRLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQXFCLENBQXFCLENBQUMsRUFBQyxVQUFVLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBWSxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLElBQUk7VUFBQWUsUUFBQSxFQUFFO1FBQWtCLENBQW1CLENBQUMsRUFBQyxxQkFBcUIsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFlLENBQW1CLENBQUMsRUFBQyx1SkFBdUosZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDUSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUF1QixDQUFxQixDQUFDLEVBQUMsbUdBQW1HO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNLLEVBQUUsSUFBRSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFSLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDSSxFQUFFO01BQUNhLEVBQUUsRUFBQyxrREFBa0Q7TUFBQUQsUUFBQSxnQkFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFrRCxDQUFFLENBQUMsRUFBQyxxREFBcUQ7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ1MsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ00sRUFBRTtRQUFBVSxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNRLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQW1FLENBQXFCLENBQUMsRUFBQyx3Q0FBd0MsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFPLENBQW1CLENBQUMsRUFBQyx5REFBeUQsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFTLENBQW1CLENBQUMsRUFBQyxxSEFBcUg7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ00sRUFBRTtRQUFBVSxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNRLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQWEsQ0FBcUIsQ0FBQyxFQUFDLE1BQU0sZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFRLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBcUIsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFZLENBQW1CLENBQUMsRUFBQyxNQUFNLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBTSxDQUFtQixDQUFDLEVBQUMsbUNBQW1DLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBVSxDQUFtQixDQUFDLEVBQUMsNEJBQTRCO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNNLEVBQUU7UUFBQVUsUUFBQSxnQkFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDUSxNQUFNO1VBQUFRLFFBQUEsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO1lBQUFlLFFBQUEsRUFBRTtVQUErQixDQUFtQjtRQUFDLENBQW9CLENBQUMsRUFBQyw4Q0FBOEM7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ00sRUFBRTtRQUFBVSxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNRLE1BQU07VUFBQVEsUUFBQSxlQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ0UsR0FBRztZQUFBYyxRQUFBLEdBQUUsc0RBQXNELGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBZSxRQUFBLEVBQUU7WUFBUSxDQUFtQixDQUFDLEVBQUMsZ0JBQWdCO1VBQUEsQ0FBa0I7UUFBQyxDQUFvQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNRLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQWdELENBQXFCLENBQUMsRUFBQyxxQkFBcUIsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUE4QixDQUFtQixDQUFDLEVBQUMsWUFBWSxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLElBQUk7VUFBQWUsUUFBQSxFQUFFO1FBQVEsQ0FBbUIsQ0FBQyxFQUFDLE9BQU8sZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFlLENBQW1CLENBQUMsRUFBQyx5Q0FBeUMsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFRLENBQW1CLENBQUMsRUFBQyx3SEFBd0g7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUM7RUFBQSxDQUFFLENBQUM7QUFDNzdOO0FBQ2UsU0FBU0csVUFBVUEsQ0FBQ3BCLEtBQUssR0FBRyxDQUFDLENBQUMsRUFBRTtFQUM3QyxNQUFNO0lBQUNxQixPQUFPLEVBQUVDO0VBQVMsQ0FBQyxHQUFHO0lBQzNCLEdBQUcsSUFBQVgsNkJBQWtCLEVBQUMsQ0FBQztJQUN2QixHQUFHWCxLQUFLLENBQUNZO0VBQ1gsQ0FBQztFQUNELE9BQU9VLFNBQVMsZ0JBQUcsSUFBQXhCLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ0csU0FBUztJQUFBLEdBQUt0QixLQUFLO0lBQUFpQixRQUFBLGVBQUUsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ3BCLGlCQUFpQjtNQUFBLEdBQUtDO0lBQUssQ0FBRztFQUFDLENBQVcsQ0FBQyxHQUFHRCxpQkFBaUIsQ0FBQ0MsS0FBSyxDQUFDO0FBQ2xIO0FBQUN1QixFQUFBLEdBTnVCSCxVQUFVO0FBT2xDLFNBQVNOLG9CQUFvQkEsQ0FBQ0ksRUFBRSxFQUFFTSxTQUFTLEVBQUVDLEtBQUssRUFBRTtFQUNsRCxNQUFNLElBQUlDLEtBQUssQ0FBQyxXQUFXLElBQUlGLFNBQVMsR0FBRyxXQUFXLEdBQUcsUUFBUSxDQUFDLEdBQUcsSUFBSSxHQUFHTixFQUFFLEdBQUcsb0VBQW9FLElBQUlPLEtBQUssR0FBRyxxQ0FBcUMsR0FBR0EsS0FBSyxHQUFHLHFDQUFxQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO0FBQy9QO0FBQUMsSUFBQUYsRUFBQTtBQUFBSSxZQUFBLENBQUFKLEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}