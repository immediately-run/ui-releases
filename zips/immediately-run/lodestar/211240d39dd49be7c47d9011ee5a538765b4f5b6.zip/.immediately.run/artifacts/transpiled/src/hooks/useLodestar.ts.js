"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.BUSY_LABELS = void 0;
exports.applySelection = applySelection;
exports.useLodestar = useLodestar;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.find.js");
require("core-js/modules/esnext.iterator.for-each.js");
require("core-js/modules/esnext.iterator.map.js");
require("core-js/modules/esnext.iterator.some.js");
var _react = require("react");
var _camera = require("../lib/camera");
var _geometry = require("../lib/geometry");
var _ids = require("../lib/ids");
var _seedBoard = require("../data/seedBoard");
var _boardStore = require("../lib/boardStore");
var _pickFile = require("../lib/pickFile");
var _mounts = require("@immediately-run/sdk/mounts");
var _openProject = require("../lib/openProject");
// Lodestar's single source of truth: camera, objects, selection, and all
// pointer/keyboard gesture logic. Ported from the design comp's controller into
// one hook so the presentational components stay thin. Geometry gestures write
// "once, on gesture end" (spec §5.1); here the write is an in-memory mutation +
// a saved-toast, the seam where the persistence layer (§2.6 round-trip discipline)
// will attach once the change layer lands.

// Subpath import, not the package barrel: the barrel re-exports `./tasks`,
// whose top-level `addListener` side effect throws `no host transport` at
// module-eval time under local `vite dev`. `/mounts` is side-effect-free.

/** Join a mount root with a (validated, relative) path; collapse double slashes. */
const subPath = (root, rel) => `${root}/${rel}`.replace(/\/+/g, '/');

/** Short ` · code` suffix from a typed platform/fs error, for toast text. */
function codeOf(e) {
  const c = e?.code;
  return c ? ` · ${c}` : '';
}
const initialViewport = () => ({
  vw: typeof window !== 'undefined' ? window.innerWidth : 1440,
  vh: typeof window !== 'undefined' ? window.innerHeight : 900,
  vleft: 0,
  vtop: 0
});

/** The ONE spelling of selection semantics (R3-607, R6): given the current
 *  selection and an id, the next selection for a replace- or toggle-click /
 *  focus. Pure, so the pointer path and the keyboard path cannot drift. */
function applySelection(sel, id, additive) {
  if (additive) return sel.includes(id) ? sel.filter(x => x !== id) : sel.concat(id);
  return sel.includes(id) ? sel : [id];
}
const MOBILE_BREAKPOINT = 720;

// The board-manifest schema version THIS reader understands. A manifest carrying
// a higher `schema:` is from a newer reader — recognised but marked readonly (the
// `readonly` degraded state, spec §2.4) rather than mis-rendered (R3-401).
const SUPPORTED_SCHEMA = 1;

// The usable height a journey-playing rect view fits into: the caption + controls
// take roughly the bottom 240px of an 844px phone viewport (item R3-400), so a
// fitted view must clear that band or the subject hides under the chrome.
const JOURNEY_FIT_INSET = 240;
const prefersReducedMotion = () => {
  try {
    return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  } catch {
    return false;
  }
};

/** The ONE spelling of what each named busy state says on its control
 *  (R-IX-2 / R6): every surface that names a wait reads this map — coupled
 *  surfaces cannot drift apart on a reword. */
const BUSY_LABELS = exports.BUSY_LABELS = {
  'insert-image': 'Adding image…',
  'new-board': 'Creating board…',
  'open-board': 'Opening board…'
};
function useLodestar() {
  // The canvas element arrives via a callback ref (a function, not a ref object
  // read during render) so the listener effect re-runs once it mounts.
  const [canvasEl, setCanvasEl] = (0, _react.useState)(null);
  const registerCanvas = (0, _react.useCallback)(el => setCanvasEl(el), []);
  const dragRef = (0, _react.useRef)(null);
  const tweenRef = (0, _react.useRef)(null);
  const holdTimer = (0, _react.useRef)(null);
  const spaceRef = (0, _react.useRef)(false);
  const toastSeq = (0, _react.useRef)(0);
  // Stable indirection for the dwell auto-advance: `goStep` schedules
  // `playNextRef.current()` so the timer always calls the LATEST playNext
  // (assigned after its useCallback is defined) — breaks the circular dep.
  const playNextRef = (0, _react.useRef)(() => {});
  const [state, setState] = (0, _react.useState)(() => ({
    mode: 'run',
    light: false,
    bg: _seedBoard.BOARD.background,
    title: _seedBoard.BOARD.title,
    cam: {
      cx: 250,
      cy: 150,
      zoom: 0.6
    },
    vp: initialViewport(),
    objects: (0, _seedBoard.seedObjects)(),
    views: _seedBoard.SEED_VIEWS.slice(),
    journeys: _seedBoard.SEED_JOURNEYS,
    selection: [],
    hover: null,
    marquee: null,
    connectPreview: null,
    connectFrom: null,
    connectCursor: null,
    inspectorOpen: false,
    panelOpen: false,
    quickMenu: null,
    journey: null,
    toasts: [],
    screen: null,
    demoMenuOpen: false,
    panning: false,
    reduced: prefersReducedMotion(),
    busy: null,
    mounts: []
  }));

  // Mirror committed state so the document-level handlers branch on fresh values.
  const stateRef = (0, _react.useRef)(state);
  (0, _react.useEffect)(() => {
    stateRef.current = state;
  });
  const update = (0, _react.useCallback)(patch => setState(prev => ({
    ...prev,
    ...(typeof patch === 'function' ? patch(prev) : patch)
  })), []);
  const isMobile = (0, _react.useCallback)(() => state.vp.vw < MOBILE_BREAKPOINT, [state.vp.vw]);

  // ---- camera helpers (read latest viewport from the ref) ----
  const localPoint = (0, _react.useCallback)(e => {
    const vp = stateRef.current.vp;
    return [e.clientX - vp.vleft, e.clientY - vp.vtop];
  }, []);
  const setZoom = (0, _react.useCallback)((nz, lx, ly) => {
    update(s => ({
      cam: (0, _camera.zoomAround)(s.cam, s.vp, nz, lx, ly)
    }));
  }, [update]);

  // ---- toasts ----
  const dismissToast = (0, _react.useCallback)(id => {
    update(s => ({
      toasts: s.toasts.filter(t => t.id !== id)
    }));
  }, [update]);
  const toast = (0, _react.useCallback)((text, icon = 'check', opts = {}) => {
    const id = ++toastSeq.current;
    const t = {
      id,
      text,
      icon,
      ...opts
    };
    update(s => ({
      toasts: s.toasts.concat(t)
    }));
    const ttl = opts.actionLabel ? 9000 : 3500;
    setTimeout(() => dismissToast(id), ttl);
  }, [update, dismissToast]);

  // ---- persistence (the §2.6 round-trip seam, now live) ----
  // The board's durable target (a per-user app space) once resolved; null means
  // we never got one (signed out / declined) and the board is in memory only.
  const boardRef = (0, _react.useRef)(null);
  // Per-object debounce timers so inspector typing / arrow nudges autosave once
  // they settle, not on every keystroke.
  const saveTimers = (0, _react.useRef)(new Map());

  // Write the given objects' files, then report with one toast. With no board
  // the change is in memory only (we keep the optimistic message); a read-only
  // board reports instead of silently dropping the write.
  const commitSave = (0, _react.useCallback)((objs, savedText, savedIcon = 'check') => {
    const t = boardRef.current;
    if (!t) {
      toast(savedText, savedIcon);
      return;
    }
    if (t.mode === 'ro') {
      toast('Read-only board · change not saved', 'lock', {
        iconColor: 'var(--ink-2)'
      });
      return;
    }
    Promise.all(objs.map(o => (0, _boardStore.saveObject)(t, o))).then(() => toast(savedText, savedIcon), e => toast(`Save failed${codeOf(e)}`, 'alert', {
      iconColor: '#caa24a'
    }));
  }, [toast]);

  // Quiet debounced autosave for continuous edits (typing, arrow-key nudges).
  const scheduleSave = (0, _react.useCallback)(ids => {
    const t = boardRef.current;
    if (!t || t.mode === 'ro') return;
    for (const id of ids) {
      const prev = saveTimers.current.get(id);
      if (prev) clearTimeout(prev);
      const handle = window.setTimeout(() => {
        saveTimers.current.delete(id);
        const o = stateRef.current.objects.find(x => x.id === id);
        if (o) (0, _boardStore.saveObject)(t, o).catch(() => undefined);
      }, 500);
      saveTimers.current.set(id, handle);
    }
  }, []);

  // ---- camera animation ----
  const flyTo = (0, _react.useCallback)((target, dur, fitH) => {
    if (!target) return;
    // A view carrying a rect names a REGION, not a magnification: fit it to the
    // usable viewport (R3-400). fitH (when given) is the usable height — the
    // caption band during journey playback — so the subject clears the chrome.
    const dest = (0, _camera.cameraForTarget)(target, stateRef.current.vp.vw, fitH ?? stateRef.current.vp.vh);
    if (tweenRef.current) cancelAnimationFrame(tweenRef.current);
    if (stateRef.current.reduced || !dur) {
      update({
        cam: dest
      });
      return;
    }
    const from = {
      ...stateRef.current.cam
    };
    const t0 = performance.now();
    const ease = p => p < 0.5 ? 4 * p * p * p : 1 - Math.pow(-2 * p + 2, 3) / 2;
    const step = now => {
      const p = Math.min(1, (now - t0) / dur);
      const e = ease(p);
      update({
        cam: {
          cx: from.cx + (dest.cx - from.cx) * e,
          cy: from.cy + (dest.cy - from.cy) * e,
          zoom: from.zoom + (dest.zoom - from.zoom) * e
        }
      });
      if (p < 1) tweenRef.current = requestAnimationFrame(step);
    };
    tweenRef.current = requestAnimationFrame(step);
  }, [update]);

  // ---- views & journeys ----
  const resolveView = (0, _react.useCallback)(v => {
    if (typeof v === 'string') return stateRef.current.views.find(x => x.name === v) ?? null;
    const t = {
      cx: v.cx,
      cy: v.cy,
      zoom: v.zoom
    };
    if (v.w) t.w = v.w;
    if (v.h) t.h = v.h;
    return t;
  }, []);
  const saveView = (0, _react.useCallback)(() => {
    const s = stateRef.current;
    const view = {
      name: `view-${s.views.length + 1}`,
      cx: s.cam.cx,
      cy: s.cam.cy,
      zoom: s.cam.zoom
    };
    update(st => ({
      views: st.views.concat([view])
    }));
    const text = `Saved views/${view.name}.md`;
    const t = boardRef.current;
    if (!t) {
      toast(text, 'save');
      return;
    }
    if (t.mode === 'ro') {
      toast('Read-only board · view not saved', 'lock', {
        iconColor: 'var(--ink-2)'
      });
      return;
    }
    (0, _boardStore.saveView)(t, view).then(() => toast(text, 'save'), e => toast(`Couldn't save view${codeOf(e)}`, 'alert', {
      iconColor: '#caa24a'
    }));
  }, [update, toast]);

  /** Remove a view on the surface that creates them (R3-607, R-IX-5). A
   *  read-only board refuses BEFORE anything drops (the row never vanishes
   *  into a refusal); on writable boards the drop is optimistic and a failed
   *  file removal rolls the view back in. */
  const deleteView = (0, _react.useCallback)(name => {
    const t = boardRef.current;
    const view = stateRef.current.views.find(v => v.name === name);
    if (!view) return;
    if (t && t.mode === 'ro') {
      toast('Read-only board · view not removed', 'lock', {
        iconColor: 'var(--ink-2)'
      });
      return;
    }
    update(s => ({
      views: s.views.filter(v => v.name !== name)
    }));
    if (!t) {
      toast(`Removed views/${name}.md`, 'trash');
      return;
    }
    (0, _boardStore.removeView)(t, name).then(() => toast(`Removed views/${name}.md`, 'trash'), e => {
      // Roll the optimistic drop back — the file survived, so must the row.
      update(s => s.views.some(v => v.name === name) ? {} : {
        views: s.views.concat([view])
      });
      toast(`Couldn't remove view${codeOf(e)}`, 'alert', {
        iconColor: '#caa24a'
      });
    });
  }, [update, toast]);
  const addJourneyStep = (0, _react.useCallback)(jid => {
    const s = stateRef.current;
    const j = s.journeys.find(x => x.id === jid);
    if (!j) return;
    const next = {
      ...j,
      steps: j.steps.concat([{
        view: {
          cx: s.cam.cx,
          cy: s.cam.cy,
          zoom: s.cam.zoom
        }
      }])
    };
    update(st => ({
      journeys: st.journeys.map(x => x.id === jid ? next : x)
    }));
    const text = `Added step ${next.steps.length} to ${j.title} · saved to ${j.id}.mdx`;
    const t = boardRef.current;
    if (!t) {
      toast(text, 'plus');
      return;
    }
    if (t.mode === 'ro') {
      toast('Read-only board · step not saved', 'lock', {
        iconColor: 'var(--ink-2)'
      });
      return;
    }
    (0, _boardStore.saveJourney)(t, next).then(() => toast(text, 'plus'), e => toast(`Couldn't save journey${codeOf(e)}`, 'alert', {
      iconColor: '#caa24a'
    }));
  }, [update, toast]);
  const goStep = (0, _react.useCallback)((j, idx, instant) => {
    const s = j.steps[idx];
    const v = resolveView(s.view);
    if (v) flyTo(v, instant ? 0 : s.duration ?? 800, stateRef.current.vp.vh - JOURNEY_FIT_INSET);
    // Dwell (R3-402): a step carrying `hold` pauses that long after arriving,
    // then AUTO-advances. Cleared by any viewer control (next/prev/seek/exit).
    // Under prefers-reduced-motion the journey stays input-driven — matching
    // flyTo's cut of the tween — so a viewer is never advanced unprompted.
    if (holdTimer.current) {
      clearTimeout(holdTimer.current);
      holdTimer.current = null;
    }
    if (s.hold && !stateRef.current.reduced) {
      holdTimer.current = window.setTimeout(() => playNextRef.current(), s.hold);
    }
  }, [resolveView, flyTo]);
  const playJourney = (0, _react.useCallback)(jid => {
    const j = stateRef.current.journeys.find(x => x.id === jid);
    if (!j) return;
    if (holdTimer.current) {
      clearTimeout(holdTimer.current);
      holdTimer.current = null;
    }
    update({
      journey: {
        jid,
        idx: 0
      },
      panelOpen: false,
      inspectorOpen: false
    });
    goStep(j, 0, true);
  }, [update, goStep]);
  const playExit = (0, _react.useCallback)(() => {
    if (tweenRef.current) cancelAnimationFrame(tweenRef.current);
    if (holdTimer.current) {
      clearTimeout(holdTimer.current);
      holdTimer.current = null;
    }
    update({
      journey: null
    });
  }, [update]);
  const playNext = (0, _react.useCallback)(() => {
    const jr = stateRef.current.journey;
    if (!jr) return;
    if (holdTimer.current) {
      clearTimeout(holdTimer.current);
      holdTimer.current = null;
    }
    const j = stateRef.current.journeys.find(x => x.id === jr.jid);
    if (!j) return;
    const ni = jr.idx + 1;
    if (ni >= j.steps.length) {
      playExit();
      return;
    }
    update({
      journey: {
        ...jr,
        idx: ni
      }
    });
    goStep(j, ni);
  }, [update, goStep, playExit]);
  // Keep the dwell timer's indirection pointed at the current playNext.
  playNextRef.current = playNext;
  const playPrev = (0, _react.useCallback)(() => {
    const jr = stateRef.current.journey;
    if (!jr) return;
    if (holdTimer.current) {
      clearTimeout(holdTimer.current);
      holdTimer.current = null;
    }
    const j = stateRef.current.journeys.find(x => x.id === jr.jid);
    if (!j) return;
    const ni = Math.max(0, jr.idx - 1);
    update({
      journey: {
        ...jr,
        idx: ni
      }
    });
    goStep(j, ni);
  }, [update, goStep]);
  const playSeek = (0, _react.useCallback)(idx => {
    const jr = stateRef.current.journey;
    if (!jr) return;
    if (holdTimer.current) {
      clearTimeout(holdTimer.current);
      holdTimer.current = null;
    }
    const j = stateRef.current.journeys.find(x => x.id === jr.jid);
    if (!j) return;
    update({
      journey: {
        ...jr,
        idx
      }
    });
    goStep(j, idx);
  }, [update, goStep]);

  // ---- mutations ----
  const patchSel = (0, _react.useCallback)(patch => {
    update(s => ({
      objects: s.objects.map(o => s.selection.includes(o.id) ? {
        ...o,
        ...patch
      } : o)
    }));
    scheduleSave(stateRef.current.selection);
  }, [update, scheduleSave]);

  // ---- selection: one action for pointer and keyboard (R3-607) ----
  const select = (0, _react.useCallback)((id, additive = false) => {
    update(s => ({
      selection: applySelection(s.selection, id, additive),
      inspectorOpen: true,
      quickMenu: null
    }));
  }, [update]);

  /** Close the quick-create menu (its Escape/blur path, R3-607). */
  const closeQuickMenu = (0, _react.useCallback)(() => update({
    quickMenu: null
  }), [update]);
  const deleteSelection = (0, _react.useCallback)(() => {
    const sel = stateRef.current.selection.slice();
    if (!sel.length) return;
    const removed = stateRef.current.objects.filter(o => sel.includes(o.id));
    update(s => ({
      objects: s.objects.filter(o => !sel.includes(o.id)),
      selection: []
    }));
    // Delete is a rename into objects/.trash/ with a 10s undo (spec §4.2).
    const t = boardRef.current;
    if (t && t.mode !== 'ro') {
      Promise.all(sel.map(id => (0, _boardStore.trashObject)(t, id))).catch(e => toast(`Delete failed${codeOf(e)}`, 'alert', {
        iconColor: '#caa24a'
      }));
    }
    toast(`${sel.length > 1 ? `${sel.length} objects` : 'Object'} moved to .trash`, 'trash', {
      actionLabel: 'Undo',
      onAction: () => {
        update(s => ({
          objects: s.objects.concat(removed)
        }));
        if (t && t.mode !== 'ro') {
          Promise.all(removed.map(o => (0, _boardStore.restoreObject)(t, o.id))).catch(() => undefined);
        }
      }
    });
  }, [update, toast]);
  const createObject = (0, _react.useCallback)((kind, wx, wy) => {
    const o = {
      id: (0, _ids.generateId)(kind === 'note' ? 'note' : kind),
      kind,
      x: wx - 100,
      y: wy - 74,
      w: 200,
      h: 148,
      rot: 0,
      scale: 1,
      z: 3,
      connections: []
    };
    if (kind === 'note') {
      o.color = 'lemon';
      o.title = 'New note';
    } else if (kind === 'prose') {
      o.title = 'Prose';
      o.body = 'Write here…';
      o.w = 260;
      o.h = 160;
    } else if (kind === 'label') {
      o.title = 'Label';
      o.w = 320;
      o.h = 80;
      o.z = 1;
    } else if (kind === 'shape') {
      o.shape = 'rect';
      o.title = '';
      o.w = 200;
      o.h = 140;
    } else if (kind === 'frame') {
      o.title = 'Frame';
      o.w = 360;
      o.h = 300;
      o.z = 1;
    } else if (kind === 'img') {
      o.loaded = false;
      o.title = 'Image';
    } else if (kind === 'component') {
      o.title = '<Component/>';
    }
    update(s => ({
      objects: s.objects.concat(o),
      selection: [o.id],
      quickMenu: null,
      inspectorOpen: true,
      mode: 'edit'
    }));
    commitSave([o], `Created objects/${o.id}.mdx`, 'plus');
  }, [update, commitSave]);

  // ── pick-file flows (spec §6.1 Open/New board, §4.2 Insert image) ──────────
  // Each invokes the platform picker over a `capDir` of the board's space (the
  // only authority we hold), then maps the returned `(root, relPath)` PATH back
  // onto our OWN mount — re-validating it first (defense in depth, §1.3).

  /** Insert an image: pick a file, copy it into the board's `assets/`, drop an
   *  <Img> object at the world point. Self-contained per §4.2. The pick is
   *  named-busy on the confirming control until it settles (R-IX-2). */
  const insertImage = (0, _react.useCallback)(async (wx, wy) => {
    const target = boardRef.current;
    if (!target) {
      toast('Sign in to insert images into your board.', 'save', {
        iconColor: 'var(--ink-2)'
      });
      return;
    }
    update({
      busy: 'insert-image'
    });
    try {
      const res = await (0, _pickFile.pickFile)({
        mode: 'open-file',
        roots: [await (0, _pickFile.boardSpaceRoot)(target)],
        rootLabels: ['This board’s space'],
        rootModes: [target.mode],
        title: 'Insert image',
        filters: [{
          label: 'Images',
          extensions: ['.png', '.jpg', '.jpeg', '.gif', '.webp', '.svg', '.avif']
        }, {
          label: 'All files',
          extensions: []
        }]
      });
      if (!res) return; // cancelled — no toast spam
      const rel = (0, _pickFile.safeRel)(res.relPath);
      if (!rel) {
        toast('That file can’t be inserted.', 'alert', {
          iconColor: '#caa24a'
        });
        return;
      }
      const name = await (0, _boardStore.copyIntoAssets)(target, rel);
      const o = {
        id: (0, _ids.generateId)('img'),
        kind: 'img',
        x: wx - 130,
        y: wy - 90,
        w: 260,
        h: 180,
        rot: 0,
        scale: 1,
        z: 3,
        title: name,
        body: `<Img src="assets/${name}" />`,
        loaded: true,
        connections: []
      };
      update(s => ({
        objects: s.objects.concat(o),
        selection: [o.id],
        quickMenu: null,
        inspectorOpen: true,
        mode: 'edit',
        screen: null
      }));
      commitSave([o], `Inserted assets/${name}`, 'image');
    } catch (e) {
      toast(`Couldn’t insert image${codeOf(e)}`, 'alert', {
        iconColor: '#caa24a'
      });
    } finally {
      update({
        busy: null
      });
    }
  }, [toast, update, commitSave]);

  /** Re-point the active board to `target` and hydrate the canvas from it. */
  const loadBoardInto = (0, _react.useCallback)(async target => {
    const board = await (0, _boardStore.loadBoard)(target);
    boardRef.current = target;
    // The board.md manifest names the board (spec §2.4) — a board is a folder
    // that can state its own name; fall back to the seed only when absent.
    // A manifest schema newer than this reader marks the board readonly (the
    // `readonly` degraded state), unless the mount itself is already ro.
    const readonly = target.mode === 'ro' || typeof board.schema === 'number' && board.schema > SUPPORTED_SCHEMA;
    update({
      objects: board.objects,
      views: board.views.length ? board.views : _seedBoard.SEED_VIEWS.slice(),
      journeys: board.journeys.length ? board.journeys : _seedBoard.SEED_JOURNEYS,
      bg: board.background ?? stateRef.current.bg,
      title: board.title ?? stateRef.current.title,
      mode: readonly ? 'run' : stateRef.current.mode,
      selection: [],
      // A keyboard connect armed against the previous board must not survive
      // the swap (R3-607 review): its source id is stale the moment objects
      // are replaced.
      connectFrom: null,
      connectCursor: null,
      inspectorOpen: false,
      screen: null
    });
  }, [update]);

  /** Open an existing board folder in `space`: pick a folder, require a board.md,
   *  then load it as the active board. Named-busy while the pick is out. */
  const openBoardIn = (0, _react.useCallback)(async space => {
    update({
      busy: 'open-board'
    });
    try {
      const res = await (0, _pickFile.pickFile)({
        mode: 'open-folder',
        roots: [await (0, _pickFile.boardSpaceRoot)(space)],
        rootLabels: ['Your board space'],
        rootModes: [space.mode],
        title: 'Open board'
      });
      if (!res) return;
      const rel = (0, _pickFile.safeRel)(res.relPath);
      if (!rel) {
        toast('That folder can’t be opened.', 'alert', {
          iconColor: '#caa24a'
        });
        return;
      }
      const candidate = {
        root: subPath(space.root, rel),
        mode: space.mode,
        spaceId: space.spaceId
      };
      if (!(await (0, _boardStore.folderIsBoard)(candidate)) && !(await (0, _boardStore.boardExists)(candidate))) {
        toast('That folder isn’t a board (no board.md). Open folder again to pick another.', 'alert', {
          iconColor: '#caa24a'
        });
        return;
      }
      await loadBoardInto(candidate);
      toast('Board opened.', 'check');
    } catch (e) {
      toast(`Couldn’t open board${codeOf(e)}`, 'alert', {
        iconColor: '#caa24a'
      });
    } finally {
      update({
        busy: null
      });
    }
  }, [toast, update, loadBoardInto]);

  /** Open a SPECIFIC board directory directly (the chooser's rows, R3-607):
   *  no picker — the caller already knows the folder (it listed it). Loads
   *  through the same `loadBoardInto` every open path funnels into. */
  const openBoardAt = (0, _react.useCallback)(async target => {
    update({
      busy: 'open-board'
    });
    try {
      await loadBoardInto(target);
      toast('Board opened.', 'check');
    } catch (e) {
      toast(`Couldn’t open board${codeOf(e)}`, 'alert', {
        iconColor: '#caa24a'
      });
    } finally {
      update({
        busy: null
      });
    }
  }, [toast, update, loadBoardInto]);

  /** New board: pick (or create) a folder in `space`, scaffold board.md, open it.
   *  Named-busy while the pick is out. */
  const newBoardIn = (0, _react.useCallback)(async space => {
    if (space.mode === 'ro') {
      toast('That space is read-only — you can’t create a board there.', 'lock', {
        iconColor: 'var(--ink-2)'
      });
      return;
    }
    update({
      busy: 'new-board'
    });
    try {
      const res = await (0, _pickFile.pickFile)({
        mode: 'open-folder',
        roots: [await (0, _pickFile.boardSpaceRoot)(space)],
        rootLabels: ['Your board space'],
        rootModes: [space.mode],
        title: 'New board · choose a folder',
        allowCreateFolder: true
      });
      if (!res) return;
      const rel = (0, _pickFile.safeRel)(res.relPath);
      if (!rel) {
        toast('That folder can’t be used.', 'alert', {
          iconColor: '#caa24a'
        });
        return;
      }
      const candidate = {
        root: subPath(space.root, rel),
        mode: 'rw',
        spaceId: space.spaceId
      };
      const title = rel.split('/').pop() || 'Untitled board';
      await (0, _boardStore.writeNewBoard)(candidate, title);
      await loadBoardInto(candidate);
      toast('Board created.', 'check');
    } catch (e) {
      toast(`Couldn’t create board${codeOf(e)}`, 'alert', {
        iconColor: '#caa24a'
      });
    } finally {
      update({
        busy: null
      });
    }
  }, [toast, update, loadBoardInto]);

  /** Open / new board against the CURRENT board space (the chooser's footer). */
  const openBoard = (0, _react.useCallback)(() => {
    const space = boardRef.current;
    if (!space) {
      toast('Sign in to open a board from your space.', 'save', {
        iconColor: 'var(--ink-2)'
      });
      return;
    }
    void openBoardIn(space);
  }, [toast, openBoardIn]);
  const newBoard = (0, _react.useCallback)(() => {
    const space = boardRef.current;
    if (!space) {
      toast('Sign in to create a board in your space.', 'save', {
        iconColor: 'var(--ink-2)'
      });
      return;
    }
    void newBoardIn(space);
  }, [toast, newBoardIn]);

  /** "Add a space": the host powerbox grants a NEW space (never this app, §2),
   *  then we offer to open a board in it. */
  const addSpace = (0, _react.useCallback)(async () => {
    try {
      const granted = await (0, _pickFile.requestSpace)();
      if (!granted) return; // cancelled
      const space = {
        root: granted.path,
        mode: granted.mode,
        spaceId: granted.id
      };
      await openBoardIn(space);
    } catch (e) {
      toast(`Couldn’t add a space${codeOf(e)}`, 'alert', {
        iconColor: '#caa24a'
      });
    }
  }, [toast, openBoardIn]);
  const patchObject = (0, _react.useCallback)((id, patch) => {
    update(s => ({
      objects: s.objects.map(o => o.id === id ? {
        ...o,
        ...patch
      } : o)
    }));
    scheduleSave([id]);
  }, [update, scheduleSave]);
  const addConnection = (0, _react.useCallback)((from, to) => {
    const c = {
      to,
      kind: 'arrow',
      style: {
        stroke: 'accent',
        dash: false
      }
    };
    const src = stateRef.current.objects.find(o => o.id === from);
    const updated = src ? {
      ...src,
      connections: src.connections.concat(c)
    } : null;
    update(s => ({
      objects: s.objects.map(o => o.id === from ? {
        ...o,
        connections: o.connections.concat(c)
      } : o)
    }));
    if (updated) commitSave([updated], `Connected ${from} → ${to}`);
  }, [update, commitSave]);

  // ---- keyboard connect (the non-drag path to an edge, R3-607 / 2.5.7) ----
  /** Enter connect-from on the selected object; the cursor starts on the first
   *  other object in stacking order. Arrows then walk the cursor (the overlay
   *  draws it), Enter commits through the same addConnection the drag calls,
   *  Escape cancels. */
  const beginConnect = (0, _react.useCallback)(() => {
    const s = stateRef.current;
    if (s.selection.length !== 1) return;
    const from = s.selection[0];
    const order = s.objects.slice().sort((a, b) => (a.z || 0) - (b.z || 0)).map(o => o.id).filter(id => id !== from);
    update({
      connectFrom: from,
      connectCursor: order[0] ?? null,
      inspectorOpen: false
    });
  }, [update]);
  const endConnect = (0, _react.useCallback)(commit => {
    const s = stateRef.current;
    if (!s.connectFrom) return;
    if (commit && s.connectCursor) addConnection(s.connectFrom, s.connectCursor);
    update({
      connectFrom: null,
      connectCursor: null
    });
  }, [update, addConnection]);
  const moveConnectCursor = (0, _react.useCallback)(dir => {
    update(s => {
      if (!s.connectFrom) return {};
      const order = s.objects.slice().sort((a, b) => (a.z || 0) - (b.z || 0)).map(o => o.id).filter(id => id !== s.connectFrom);
      if (!order.length) return {};
      const idx = order.indexOf(s.connectCursor ?? order[0]);
      return {
        connectCursor: order[(idx + dir + order.length) % order.length]
      };
    });
  }, [update]);

  // ---- pointer gestures ----
  const onCanvasDown = (0, _react.useCallback)(e => {
    const s = stateRef.current;
    if (s.quickMenu) update({
      quickMenu: null
    });
    if (s.demoMenuOpen) update({
      demoMenuOpen: false
    });
    const mid = e.button === 1;
    if (s.mode === 'edit' && !spaceRef.current && !mid && !isMobile()) {
      const [lx, ly] = localPoint(e);
      if (!e.shiftKey) update({
        selection: []
      });
      dragRef.current = {
        type: 'marquee',
        sx: lx,
        sy: ly,
        add: e.shiftKey,
        base: s.selection.slice()
      };
      update({
        marquee: {
          x: lx,
          y: ly,
          w: 0,
          h: 0
        }
      });
    } else {
      dragRef.current = {
        type: 'pan',
        sx: e.clientX,
        sy: e.clientY,
        cx: s.cam.cx,
        cy: s.cam.cy
      };
      update({
        panning: true
      });
    }
  }, [update, isMobile, localPoint]);
  const objPointerDown = (0, _react.useCallback)((id, e) => {
    e.stopPropagation();
    const s = stateRef.current;
    if (s.mode !== 'edit') {
      dragRef.current = {
        type: 'pan',
        sx: e.clientX,
        sy: e.clientY,
        cx: s.cam.cx,
        cy: s.cam.cy
      };
      update({
        panning: true
      });
      return;
    }
    const o = s.objects.find(x => x.id === id);
    if (!o) return;
    // One spelling of selection for pointer and keyboard alike (R3-607).
    const sel = applySelection(s.selection, id, e.shiftKey);
    update({
      selection: sel,
      inspectorOpen: true,
      quickMenu: null
    });
    if (o.locked) return;
    const orig = {};
    s.objects.forEach(x => {
      if (sel.includes(x.id)) orig[x.id] = {
        x: x.x,
        y: x.y
      };
    });
    dragRef.current = {
      type: 'move',
      sx: e.clientX,
      sy: e.clientY,
      ids: sel,
      orig,
      moved: false
    };
  }, [update]);
  const startHandle = (0, _react.useCallback)((kind, handle, e) => {
    e.stopPropagation();
    const s = stateRef.current;
    const id = s.selection[0];
    const o = s.objects.find(x => x.id === id);
    if (!o) return;
    const base = {
      x: o.x,
      y: o.y,
      w: o.w,
      h: o.h,
      rot: o.rot
    };
    dragRef.current = kind === 'rotate' ? {
      type: 'rotate',
      sx: e.clientX,
      sy: e.clientY,
      o: base,
      id,
      moved: false
    } : {
      type: 'resize',
      kind: handle,
      sx: e.clientX,
      sy: e.clientY,
      o: base,
      id,
      moved: false
    };
  }, []);
  const startConnect = (0, _react.useCallback)((id, side, e) => {
    e.stopPropagation();
    dragRef.current = {
      type: 'connect',
      from: id,
      side,
      moved: false
    };
    const [lx, ly] = localPoint(e);
    update({
      connectPreview: {
        from: id,
        x: lx,
        y: ly,
        target: null
      }
    });
  }, [update, localPoint]);
  const setHover = (0, _react.useCallback)(id => update({
    hover: id
  }), [update]);
  const clearSelection = (0, _react.useCallback)(() => update({
    selection: []
  }), [update]);

  // ---- mode / view controls ----
  const setRun = (0, _react.useCallback)(
  // Leaving edit disarms a keyboard connect too (its cursor lives on the
  // edit surface) — connectFrom surviving into run mode would own the
  // arrows of a mode that has no selection (R3-607 review).
  () => update({
    mode: 'run',
    selection: [],
    inspectorOpen: false,
    quickMenu: null,
    connectPreview: null,
    connectFrom: null,
    connectCursor: null
  }), [update]);
  const setEdit = (0, _react.useCallback)(() => update({
    mode: 'edit'
  }), [update]);
  const toggleTheme = (0, _react.useCallback)(() => update(s => ({
    light: !s.light
  })), [update]);
  const togglePanel = (0, _react.useCallback)(() => update(s => ({
    panelOpen: !s.panelOpen
  })), [update]);
  const setScreen = (0, _react.useCallback)(screen => update({
    screen
  }), [update]);
  const setBackground = (0, _react.useCallback)(bg => update({
    bg
  }), [update]);
  const setLight = (0, _react.useCallback)(light => update({
    light
  }), [update]);
  const closeInspector = (0, _react.useCallback)(() => update({
    inspectorOpen: false
  }), [update]);
  const closePanel = (0, _react.useCallback)(() => update({
    panelOpen: false
  }), [update]);
  const toggleDemoMenu = (0, _react.useCallback)(() => update(s => ({
    demoMenuOpen: !s.demoMenuOpen
  })), [update]);
  const onCanvasDblClick = (0, _react.useCallback)(e => {
    if (stateRef.current.mode !== 'edit') return;
    const [lx, ly] = localPoint(e);
    const [wx, wy] = (0, _camera.worldAt)(stateRef.current.cam, stateRef.current.vp, lx, ly);
    update({
      quickMenu: {
        lx,
        ly,
        wx,
        wy
      }
    });
  }, [update, localPoint]);

  // ---- demo scenarios (the design's "demo states" menu) ----
  const demoLWW = (0, _react.useCallback)(() => {
    toast('Note was changed by @dana while you edited — their version kept.', 'alert', {
      iconColor: '#caa24a',
      actionLabel: 'Keep mine',
      onAction: () => toast('Your version restored', 'check')
    });
  }, [toast]);
  const demoDowngrade = (0, _react.useCallback)(() => {
    update({
      mode: 'run',
      selection: [],
      inspectorOpen: false
    });
    toast('Your access changed to read-only. Edit mode closed.', 'lock', {
      iconColor: 'var(--ink-2)'
    });
  }, [update, toast]);

  // ---- effects: measurement + global listeners ----
  (0, _react.useEffect)(() => {
    document.documentElement.setAttribute('data-theme', state.light ? 'light' : 'dark');
  }, [state.light]);
  (0, _react.useEffect)(() => {
    const el = canvasEl;
    if (!el) return;
    const measure = () => {
      const r = el.getBoundingClientRect();
      update({
        vp: {
          vw: r.width,
          vh: r.height,
          vleft: r.left,
          vtop: r.top
        }
      });
    };
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    const onWheel = e => {
      e.preventDefault();
      const [lx, ly] = localPoint(e);
      if (e.ctrlKey || e.metaKey) {
        const f = Math.exp(-e.deltaY * 0.01);
        setZoom(stateRef.current.cam.zoom * f, lx, ly);
      } else {
        update(s => ({
          cam: {
            cx: s.cam.cx + e.deltaX / s.cam.zoom,
            cy: s.cam.cy + e.deltaY / s.cam.zoom,
            zoom: s.cam.zoom
          }
        }));
      }
    };
    el.addEventListener('wheel', onWheel, {
      passive: false
    });
    const onMove = e => {
      const d = dragRef.current;
      if (!d) return;
      const z = stateRef.current.cam.zoom;
      if (d.type === 'pan') {
        const dx = e.clientX - d.sx;
        const dy = e.clientY - d.sy;
        update({
          cam: {
            cx: d.cx - dx / z,
            cy: d.cy - dy / z,
            zoom: z
          }
        });
      } else if (d.type === 'move') {
        const dx = (e.clientX - d.sx) / z;
        const dy = (e.clientY - d.sy) / z;
        d.moved = true;
        update(s => ({
          objects: s.objects.map(o => d.ids.includes(o.id) && d.orig[o.id] ? {
            ...o,
            x: d.orig[o.id].x + dx,
            y: d.orig[o.id].y + dy
          } : o)
        }));
      } else if (d.type === 'marquee') {
        const [lx, ly] = localPoint(e);
        const x = Math.min(lx, d.sx);
        const y = Math.min(ly, d.sy);
        const w = Math.abs(lx - d.sx);
        const hh = Math.abs(ly - d.sy);
        const s = stateRef.current;
        const sel = (0, _geometry.objectsInRect)(s.objects, s.cam, s.vp, x, y, w, hh);
        update({
          marquee: {
            x,
            y,
            w,
            h: hh
          },
          selection: d.add ? Array.from(new Set(d.base.concat(sel))) : sel
        });
      } else if (d.type === 'connect') {
        const [lx, ly] = localPoint(e);
        const s = stateRef.current;
        const tgt = (0, _geometry.objectAtLocal)(s.objects, s.cam, s.vp, lx, ly, d.from);
        update({
          connectPreview: {
            from: d.from,
            x: lx,
            y: ly,
            target: tgt
          }
        });
      } else if (d.type === 'resize' || d.type === 'rotate') {
        applyHandle(d, e);
      }
    };
    const applyHandle = (d, e) => {
      const s = stateRef.current;
      const z = s.cam.zoom;
      const dx = (e.clientX - d.sx) / z;
      const dy = (e.clientY - d.sy) / z;
      d.moved = true;
      update(st => ({
        objects: st.objects.map(o => {
          if (o.id !== d.id) return o;
          if (d.type === 'rotate') {
            const cx = d.o.x + d.o.w / 2;
            const cy = d.o.y + d.o.h / 2;
            const [lx, ly] = localPoint(e);
            const [wx, wy] = (0, _camera.worldAt)(s.cam, s.vp, lx, ly);
            let ang = Math.atan2(wy - cy, wx - cx) * 180 / Math.PI + 90;
            if (e.shiftKey) ang = Math.round(ang / 15) * 15;
            return {
              ...o,
              rot: Math.round(ang)
            };
          }
          let x = d.o.x;
          let y = d.o.y;
          let w = d.o.w;
          let hh = d.o.h;
          const k = d.kind;
          if (k.includes('e')) w = Math.max(60, d.o.w + dx);
          if (k.includes('s')) hh = Math.max(48, d.o.h + dy);
          if (k.includes('w')) {
            w = Math.max(60, d.o.w - dx);
            x = d.o.x + (d.o.w - w);
          }
          if (k.includes('n')) {
            hh = Math.max(48, d.o.h - dy);
            y = d.o.y + (d.o.h - hh);
          }
          return {
            ...o,
            x,
            y,
            w,
            h: hh
          };
        })
      }));
    };
    const onUp = e => {
      const d = dragRef.current;
      dragRef.current = null;
      if (!d) {
        if (stateRef.current.panning) update({
          panning: false
        });
        return;
      }
      if (d.type === 'pan') {
        update({
          panning: false
        });
      } else if (d.type === 'move' && d.moved) {
        const moved = stateRef.current.objects.filter(o => d.ids.includes(o.id));
        commitSave(moved, `Moved · saved to ${d.ids.length > 1 ? `${d.ids.length} files` : `${d.ids[0]}.mdx`}`);
      } else if (d.type === 'marquee') {
        update({
          marquee: null
        });
      } else if (d.type === 'connect') {
        const [lx, ly] = localPoint(e);
        const s = stateRef.current;
        const tgt = (0, _geometry.objectAtLocal)(s.objects, s.cam, s.vp, lx, ly, d.from);
        if (tgt) addConnection(d.from, tgt);
        update({
          connectPreview: null
        });
      } else if ((d.type === 'resize' || d.type === 'rotate') && d.moved) {
        const o = stateRef.current.objects.find(x => x.id === d.id);
        commitSave(o ? [o] : [], 'Resized · saved');
      }
    };
    const onKeyDown = e => {
      const t = e.target;
      if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable)) return;
      const s = stateRef.current;
      if (s.journey) {
        if (e.key === 'ArrowRight' || e.key === ' ') {
          e.preventDefault();
          playNext();
        } else if (e.key === 'ArrowLeft') {
          playPrev();
        } else if (e.key === 'Escape') {
          playExit();
        }
        return;
      }
      // Keyboard connect owns the arrows while it is armed (R3-607): arrows
      // walk the target cursor, Enter commits, Escape cancels — never nudging
      // or deleting underneath a live connect.
      if (s.connectFrom) {
        if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
          e.preventDefault();
          moveConnectCursor(-1);
        } else if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
          e.preventDefault();
          moveConnectCursor(1);
        } else if (e.key === 'Enter') {
          e.preventDefault();
          endConnect(true);
        } else if (e.key === 'Escape') {
          e.preventDefault();
          endConnect(false);
        }
        return;
      }
      if (e.key === 'Escape') update({
        selection: [],
        quickMenu: null,
        screen: null
      });
      if (e.key === ' ') spaceRef.current = true;
      if (s.mode === 'edit' && s.selection.length) {
        const step = e.shiftKey ? 10 : 1;
        let dx = 0;
        let dy = 0;
        if (e.key === 'ArrowLeft') dx = -step;else if (e.key === 'ArrowRight') dx = step;else if (e.key === 'ArrowUp') dy = -step;else if (e.key === 'ArrowDown') dy = step;
        if (dx || dy) {
          e.preventDefault();
          const sel = s.selection;
          update(st => ({
            objects: st.objects.map(o => sel.includes(o.id) && !o.locked ? {
              ...o,
              x: o.x + dx,
              y: o.y + dy
            } : o)
          }));
          scheduleSave(sel);
        }
        if (e.key === 'Delete' || e.key === 'Backspace') deleteSelection();
      }
    };
    const onKeyUp = e => {
      if (e.key === ' ') spaceRef.current = false;
    };
    document.addEventListener('pointermove', onMove);
    document.addEventListener('pointerup', onUp);
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    return () => {
      el.removeEventListener('wheel', onWheel);
      ro.disconnect();
      document.removeEventListener('pointermove', onMove);
      document.removeEventListener('pointerup', onUp);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      if (tweenRef.current) cancelAnimationFrame(tweenRef.current);
    };
    // The listeners read the latest state via stateRef, so they install once
    // the canvas mounts; the action callbacks they close over are all stable.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [canvasEl]);

  /**
   * Provider side of `open-project` (SPACES_UI_SPEC §6): given the delegated
   * `capDir`, find the chroot the host mounted for it, hydrate the canvas from
   * it, and arm the durable-board machinery (autosave, downgrade watch) against
   * it. Resolves true once the board is shown, false if the delegated folder
   * never resolved to a mount (the caller then aborts the task). The folder is
   * expected to already be a board (the marker only lives on board folders); an
   * empty one is seeded so the canvas still renders.
   */
  const openDelegatedProject = (0, _react.useCallback)(async dirPath => {
    // The host announces the task chroot as a mount AT the delegated path; it
    // may not be present the instant we read the input, so poll briefly (a few
    // frames) for the mount whose `path` matches.
    let mount = (0, _openProject.resolveDelegatedMount)(dirPath, (0, _mounts.getMounts)());
    for (let tries = 0; !mount && tries < 40; tries += 1) {
      await new Promise(r => setTimeout(r, 50));
      mount = (0, _openProject.resolveDelegatedMount)(dirPath, (0, _mounts.getMounts)());
    }
    if (!mount) {
      toast('Couldn’t open that project — the folder isn’t available.', 'alert', {
        iconColor: '#caa24a'
      });
      return false;
    }
    const target = (0, _openProject.dirCapToBoardTarget)(mount);
    try {
      if (await (0, _boardStore.boardExists)(target)) {
        await loadBoardInto(target);
      } else {
        // The marker said this is a project folder but it has no objects yet:
        // seed it so the user lands on a usable board, not a blank canvas.
        boardRef.current = target;
        const s = stateRef.current;
        await (0, _boardStore.seedBoard)(target, {
          objects: s.objects,
          views: s.views,
          journeys: s.journeys
        });
      }
      toast('Project opened.', 'check');
      return true;
    } catch (e) {
      toast(`Couldn’t open project${codeOf(e)}`, 'alert', {
        iconColor: '#caa24a'
      });
      return false;
    }
  }, [toast, loadBoardInto]);

  // ---- open the durable board space, hydrate (or seed), watch for downgrades ----
  (0, _react.useEffect)(() => {
    let cancelled = false;
    let unsub;
    const timers = saveTimers.current;
    (async () => {
      // ── open-project provider path (SPACES_UI_SPEC §6, Phase 5) ───────────
      // If a file manager launched us via the `open-project` task, it handed a
      // `capDir` for the project folder; the host mounted that folder as a
      // chroot. Load the board from it and complete the task, then arm the same
      // downgrade watch below against the delegated mount. A normal launch (no
      // task input) falls through to the durable-board path unchanged.
      let delegated = false;
      const dir = await (0, _openProject.readOpenProjectInput)();
      if (dir) {
        const opened = await openDelegatedProject(dir);
        if (opened) await (0, _openProject.reportOpened)(true);else await (0, _openProject.abortOpenProject)();
        if (cancelled) return;
        // On success the canvas is chrooted at the project; skip the durable
        // board space. On failure, fall through to the in-memory seed so the
        // canvas still renders something rather than a blank app.
        delegated = opened;
      }
      if (!delegated) {
        let target;
        try {
          // Auto-open the signed-in user's board space. Declined / signed-out
          // rejects with a typed SpaceError — we degrade to the in-memory seed.
          target = await (0, _boardStore.openBoardTarget)();
        } catch (e) {
          // Only `auth-required` is a sign-in problem; anything else is logged
          // with its code and reported as the platform failure it is.
          const failure = (0, _boardStore.classifyBoardTargetFailure)(e);
          if (!cancelled) toast(failure.copy, failure.auth ? 'save' : 'alert', failure.auth ? {
            iconColor: 'var(--ink-2)'
          } : {
            iconColor: '#caa24a'
          });
          return;
        }
        if (cancelled) return;
        boardRef.current = target;
        try {
          if (await (0, _boardStore.boardExists)(target)) {
            const board = await (0, _boardStore.loadBoard)(target);
            if (!cancelled) {
              update({
                objects: board.objects,
                views: board.views.length ? board.views : _seedBoard.SEED_VIEWS.slice(),
                journeys: board.journeys.length ? board.journeys : _seedBoard.SEED_JOURNEYS
              });
              toast('Board loaded from your space.', 'check');
            }
          } else {
            // First run on an empty space: persist the seed demo as the starting board.
            const s = stateRef.current;
            await (0, _boardStore.seedBoard)(target, {
              objects: s.objects,
              views: s.views,
              journeys: s.journeys
            });
            if (!cancelled) toast('Board created in your space.', 'check');
          }
        } catch (e) {
          if (!cancelled) toast(`Couldn't open board${codeOf(e)}`, 'alert', {
            iconColor: '#caa24a'
          });
        }
      }
      if (cancelled) return;
      // Mirror the live mounts into state (the board chooser lists these,
      // R3-607) alongside the downgrade watch below.
      try {
        update({
          mounts: (0, _mounts.getMounts)()
        });
      } catch {
        // No host runtime yet — the list stays empty and the chooser degrades.
      }
      // A live role-downgrade re-announces the mount as `ro`; removal tears it down.
      // The mount service needs the host runtime, which is absent under local
      // `vite dev` — there the board is a static on-disk dir with no role changes,
      // so skip the subscription rather than crash.
      try {
        unsub = (0, _mounts.onMountsChange)((mounts, removed) => {
          update({
            mounts
          });
          const cur = boardRef.current;
          if (!cur) return;
          const m = mounts.find(x => cur.spaceId ? x.id === cur.spaceId : x.path === cur.root);
          if (m) {
            const mode = m.mode === 'ro' ? 'ro' : 'rw';
            if (mode !== cur.mode) {
              boardRef.current = {
                ...cur,
                mode
              };
              if (mode === 'ro') {
                update({
                  mode: 'run',
                  selection: [],
                  inspectorOpen: false
                });
                toast('Your access changed to read-only.', 'lock', {
                  iconColor: 'var(--ink-2)'
                });
              }
            }
          } else if (removed.some(r => cur.spaceId ? r.id === cur.spaceId : r.path === cur.root)) {
            boardRef.current = null;
            toast('Board space disconnected.', 'alert', {
              iconColor: 'var(--ink-2)'
            });
          }
        });
      } catch {
        // No host runtime (local `vite dev`): no live mount updates to track.
      }
    })();
    return () => {
      cancelled = true;
      unsub?.();
      for (const h of timers.values()) clearTimeout(h);
      timers.clear();
      if (holdTimer.current) clearTimeout(holdTimer.current);
      holdTimer.current = null;
    };
    // Runs once on mount; reads live state via stateRef and stable callbacks.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return {
    state,
    registerCanvas,
    boardRoot: boardRef.current?.root ?? null,
    isMobile,
    // camera
    originX: vw => (0, _camera.originX)(state.cam, vw),
    originY: vh => (0, _camera.originY)(state.cam, vh),
    project: (wx, wy) => (0, _camera.project)(state.cam, state.vp, wx, wy),
    setZoom,
    clampZoom: _camera.clampZoom,
    flyTo,
    anchorPoint: _geometry.anchorPoint,
    // gestures
    onCanvasDown,
    onCanvasDblClick,
    objPointerDown,
    startHandle,
    startConnect,
    setHover,
    clearSelection,
    select,
    closeQuickMenu,
    // keyboard connect (the non-drag path)
    beginConnect,
    endConnect,
    moveConnectCursor,
    // mutations
    patchSel,
    patchObject,
    deleteSelection,
    createObject,
    // pick-file flows
    insertImage,
    openBoard,
    openBoardAt,
    newBoard,
    newBoardIn,
    openBoardIn,
    addSpace,
    // views & journeys
    saveView,
    deleteView,
    addJourneyStep,
    resolveView,
    playJourney,
    playNext,
    playPrev,
    playExit,
    playSeek,
    // mode / chrome
    setRun,
    setEdit,
    toggleTheme,
    togglePanel,
    closeInspector,
    closePanel,
    setBackground,
    setLight,
    setScreen,
    toggleDemoMenu,
    // toasts + demo
    toast,
    dismissToast,
    demoLWW,
    demoDowngrade
  };
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX2NhbWVyYSIsIl9nZW9tZXRyeSIsIl9pZHMiLCJfc2VlZEJvYXJkIiwiX2JvYXJkU3RvcmUiLCJfcGlja0ZpbGUiLCJfbW91bnRzIiwiX29wZW5Qcm9qZWN0Iiwic3ViUGF0aCIsInJvb3QiLCJyZWwiLCJyZXBsYWNlIiwiY29kZU9mIiwiZSIsImMiLCJjb2RlIiwiaW5pdGlhbFZpZXdwb3J0IiwidnciLCJ3aW5kb3ciLCJpbm5lcldpZHRoIiwidmgiLCJpbm5lckhlaWdodCIsInZsZWZ0IiwidnRvcCIsImFwcGx5U2VsZWN0aW9uIiwic2VsIiwiaWQiLCJhZGRpdGl2ZSIsImluY2x1ZGVzIiwiZmlsdGVyIiwieCIsImNvbmNhdCIsIk1PQklMRV9CUkVBS1BPSU5UIiwiU1VQUE9SVEVEX1NDSEVNQSIsIkpPVVJORVlfRklUX0lOU0VUIiwicHJlZmVyc1JlZHVjZWRNb3Rpb24iLCJtYXRjaE1lZGlhIiwibWF0Y2hlcyIsIkJVU1lfTEFCRUxTIiwiZXhwb3J0cyIsInVzZUxvZGVzdGFyIiwiY2FudmFzRWwiLCJzZXRDYW52YXNFbCIsInVzZVN0YXRlIiwicmVnaXN0ZXJDYW52YXMiLCJ1c2VDYWxsYmFjayIsImVsIiwiZHJhZ1JlZiIsInVzZVJlZiIsInR3ZWVuUmVmIiwiaG9sZFRpbWVyIiwic3BhY2VSZWYiLCJ0b2FzdFNlcSIsInBsYXlOZXh0UmVmIiwic3RhdGUiLCJzZXRTdGF0ZSIsIm1vZGUiLCJsaWdodCIsImJnIiwiQk9BUkQiLCJiYWNrZ3JvdW5kIiwidGl0bGUiLCJjYW0iLCJjeCIsImN5Iiwiem9vbSIsInZwIiwib2JqZWN0cyIsInNlZWRPYmplY3RzIiwidmlld3MiLCJTRUVEX1ZJRVdTIiwic2xpY2UiLCJqb3VybmV5cyIsIlNFRURfSk9VUk5FWVMiLCJzZWxlY3Rpb24iLCJob3ZlciIsIm1hcnF1ZWUiLCJjb25uZWN0UHJldmlldyIsImNvbm5lY3RGcm9tIiwiY29ubmVjdEN1cnNvciIsImluc3BlY3Rvck9wZW4iLCJwYW5lbE9wZW4iLCJxdWlja01lbnUiLCJqb3VybmV5IiwidG9hc3RzIiwic2NyZWVuIiwiZGVtb01lbnVPcGVuIiwicGFubmluZyIsInJlZHVjZWQiLCJidXN5IiwibW91bnRzIiwic3RhdGVSZWYiLCJ1c2VFZmZlY3QiLCJjdXJyZW50IiwidXBkYXRlIiwicGF0Y2giLCJwcmV2IiwiaXNNb2JpbGUiLCJsb2NhbFBvaW50IiwiY2xpZW50WCIsImNsaWVudFkiLCJzZXRab29tIiwibnoiLCJseCIsImx5IiwicyIsInpvb21Bcm91bmQiLCJkaXNtaXNzVG9hc3QiLCJ0IiwidG9hc3QiLCJ0ZXh0IiwiaWNvbiIsIm9wdHMiLCJ0dGwiLCJhY3Rpb25MYWJlbCIsInNldFRpbWVvdXQiLCJib2FyZFJlZiIsInNhdmVUaW1lcnMiLCJNYXAiLCJjb21taXRTYXZlIiwib2JqcyIsInNhdmVkVGV4dCIsInNhdmVkSWNvbiIsImljb25Db2xvciIsIlByb21pc2UiLCJhbGwiLCJtYXAiLCJvIiwic2F2ZU9iamVjdCIsInRoZW4iLCJzY2hlZHVsZVNhdmUiLCJpZHMiLCJnZXQiLCJjbGVhclRpbWVvdXQiLCJoYW5kbGUiLCJkZWxldGUiLCJmaW5kIiwiY2F0Y2giLCJ1bmRlZmluZWQiLCJzZXQiLCJmbHlUbyIsInRhcmdldCIsImR1ciIsImZpdEgiLCJkZXN0IiwiY2FtZXJhRm9yVGFyZ2V0IiwiY2FuY2VsQW5pbWF0aW9uRnJhbWUiLCJmcm9tIiwidDAiLCJwZXJmb3JtYW5jZSIsIm5vdyIsImVhc2UiLCJwIiwiTWF0aCIsInBvdyIsInN0ZXAiLCJtaW4iLCJyZXF1ZXN0QW5pbWF0aW9uRnJhbWUiLCJyZXNvbHZlVmlldyIsInYiLCJuYW1lIiwidyIsImgiLCJzYXZlVmlldyIsInZpZXciLCJsZW5ndGgiLCJzdCIsInBlcnNpc3RWaWV3IiwiZGVsZXRlVmlldyIsInJlbW92ZVZpZXciLCJzb21lIiwiYWRkSm91cm5leVN0ZXAiLCJqaWQiLCJqIiwibmV4dCIsInN0ZXBzIiwicGVyc2lzdEpvdXJuZXkiLCJnb1N0ZXAiLCJpZHgiLCJpbnN0YW50IiwiZHVyYXRpb24iLCJob2xkIiwicGxheUpvdXJuZXkiLCJwbGF5RXhpdCIsInBsYXlOZXh0IiwianIiLCJuaSIsInBsYXlQcmV2IiwibWF4IiwicGxheVNlZWsiLCJwYXRjaFNlbCIsInNlbGVjdCIsImNsb3NlUXVpY2tNZW51IiwiZGVsZXRlU2VsZWN0aW9uIiwicmVtb3ZlZCIsInRyYXNoT2JqZWN0Iiwib25BY3Rpb24iLCJyZXN0b3JlT2JqZWN0IiwiY3JlYXRlT2JqZWN0Iiwia2luZCIsInd4Iiwid3kiLCJnZW5lcmF0ZUlkIiwieSIsInJvdCIsInNjYWxlIiwieiIsImNvbm5lY3Rpb25zIiwiY29sb3IiLCJib2R5Iiwic2hhcGUiLCJsb2FkZWQiLCJpbnNlcnRJbWFnZSIsInJlcyIsInBpY2tGaWxlIiwicm9vdHMiLCJib2FyZFNwYWNlUm9vdCIsInJvb3RMYWJlbHMiLCJyb290TW9kZXMiLCJmaWx0ZXJzIiwibGFiZWwiLCJleHRlbnNpb25zIiwic2FmZVJlbCIsInJlbFBhdGgiLCJjb3B5SW50b0Fzc2V0cyIsImxvYWRCb2FyZEludG8iLCJib2FyZCIsImxvYWRCb2FyZCIsInJlYWRvbmx5Iiwic2NoZW1hIiwib3BlbkJvYXJkSW4iLCJzcGFjZSIsImNhbmRpZGF0ZSIsInNwYWNlSWQiLCJmb2xkZXJJc0JvYXJkIiwiYm9hcmRFeGlzdHMiLCJvcGVuQm9hcmRBdCIsIm5ld0JvYXJkSW4iLCJhbGxvd0NyZWF0ZUZvbGRlciIsInNwbGl0IiwicG9wIiwid3JpdGVOZXdCb2FyZCIsIm9wZW5Cb2FyZCIsIm5ld0JvYXJkIiwiYWRkU3BhY2UiLCJncmFudGVkIiwicmVxdWVzdFNwYWNlIiwicGF0aCIsInBhdGNoT2JqZWN0IiwiYWRkQ29ubmVjdGlvbiIsInRvIiwic3R5bGUiLCJzdHJva2UiLCJkYXNoIiwic3JjIiwidXBkYXRlZCIsImJlZ2luQ29ubmVjdCIsIm9yZGVyIiwic29ydCIsImEiLCJiIiwiZW5kQ29ubmVjdCIsImNvbW1pdCIsIm1vdmVDb25uZWN0Q3Vyc29yIiwiZGlyIiwiaW5kZXhPZiIsIm9uQ2FudmFzRG93biIsIm1pZCIsImJ1dHRvbiIsInNoaWZ0S2V5IiwidHlwZSIsInN4Iiwic3kiLCJhZGQiLCJiYXNlIiwib2JqUG9pbnRlckRvd24iLCJzdG9wUHJvcGFnYXRpb24iLCJsb2NrZWQiLCJvcmlnIiwiZm9yRWFjaCIsIm1vdmVkIiwic3RhcnRIYW5kbGUiLCJzdGFydENvbm5lY3QiLCJzaWRlIiwic2V0SG92ZXIiLCJjbGVhclNlbGVjdGlvbiIsInNldFJ1biIsInNldEVkaXQiLCJ0b2dnbGVUaGVtZSIsInRvZ2dsZVBhbmVsIiwic2V0U2NyZWVuIiwic2V0QmFja2dyb3VuZCIsInNldExpZ2h0IiwiY2xvc2VJbnNwZWN0b3IiLCJjbG9zZVBhbmVsIiwidG9nZ2xlRGVtb01lbnUiLCJvbkNhbnZhc0RibENsaWNrIiwid29ybGRBdCIsImRlbW9MV1ciLCJkZW1vRG93bmdyYWRlIiwiZG9jdW1lbnQiLCJkb2N1bWVudEVsZW1lbnQiLCJzZXRBdHRyaWJ1dGUiLCJtZWFzdXJlIiwiciIsImdldEJvdW5kaW5nQ2xpZW50UmVjdCIsIndpZHRoIiwiaGVpZ2h0IiwibGVmdCIsInRvcCIsInJvIiwiUmVzaXplT2JzZXJ2ZXIiLCJvYnNlcnZlIiwib25XaGVlbCIsInByZXZlbnREZWZhdWx0IiwiY3RybEtleSIsIm1ldGFLZXkiLCJmIiwiZXhwIiwiZGVsdGFZIiwiZGVsdGFYIiwiYWRkRXZlbnRMaXN0ZW5lciIsInBhc3NpdmUiLCJvbk1vdmUiLCJkIiwiZHgiLCJkeSIsImFicyIsImhoIiwib2JqZWN0c0luUmVjdCIsIkFycmF5IiwiU2V0IiwidGd0Iiwib2JqZWN0QXRMb2NhbCIsImFwcGx5SGFuZGxlIiwiYW5nIiwiYXRhbjIiLCJQSSIsInJvdW5kIiwiayIsIm9uVXAiLCJvbktleURvd24iLCJ0YWdOYW1lIiwiaXNDb250ZW50RWRpdGFibGUiLCJrZXkiLCJvbktleVVwIiwicmVtb3ZlRXZlbnRMaXN0ZW5lciIsImRpc2Nvbm5lY3QiLCJvcGVuRGVsZWdhdGVkUHJvamVjdCIsImRpclBhdGgiLCJtb3VudCIsInJlc29sdmVEZWxlZ2F0ZWRNb3VudCIsImdldE1vdW50cyIsInRyaWVzIiwiZGlyQ2FwVG9Cb2FyZFRhcmdldCIsInNlZWRCb2FyZCIsImNhbmNlbGxlZCIsInVuc3ViIiwidGltZXJzIiwiZGVsZWdhdGVkIiwicmVhZE9wZW5Qcm9qZWN0SW5wdXQiLCJvcGVuZWQiLCJyZXBvcnRPcGVuZWQiLCJhYm9ydE9wZW5Qcm9qZWN0Iiwib3BlbkJvYXJkVGFyZ2V0IiwiZmFpbHVyZSIsImNsYXNzaWZ5Qm9hcmRUYXJnZXRGYWlsdXJlIiwiY29weSIsImF1dGgiLCJvbk1vdW50c0NoYW5nZSIsImN1ciIsIm0iLCJ2YWx1ZXMiLCJjbGVhciIsImJvYXJkUm9vdCIsIm9yaWdpblgiLCJvcmlnaW5ZIiwicHJvamVjdCIsImNsYW1wWm9vbSIsImFuY2hvclBvaW50Il0sInNvdXJjZXMiOlsidXNlTG9kZXN0YXIudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gTG9kZXN0YXIncyBzaW5nbGUgc291cmNlIG9mIHRydXRoOiBjYW1lcmEsIG9iamVjdHMsIHNlbGVjdGlvbiwgYW5kIGFsbFxuLy8gcG9pbnRlci9rZXlib2FyZCBnZXN0dXJlIGxvZ2ljLiBQb3J0ZWQgZnJvbSB0aGUgZGVzaWduIGNvbXAncyBjb250cm9sbGVyIGludG9cbi8vIG9uZSBob29rIHNvIHRoZSBwcmVzZW50YXRpb25hbCBjb21wb25lbnRzIHN0YXkgdGhpbi4gR2VvbWV0cnkgZ2VzdHVyZXMgd3JpdGVcbi8vIFwib25jZSwgb24gZ2VzdHVyZSBlbmRcIiAoc3BlYyDCpzUuMSk7IGhlcmUgdGhlIHdyaXRlIGlzIGFuIGluLW1lbW9yeSBtdXRhdGlvbiArXG4vLyBhIHNhdmVkLXRvYXN0LCB0aGUgc2VhbSB3aGVyZSB0aGUgcGVyc2lzdGVuY2UgbGF5ZXIgKMKnMi42IHJvdW5kLXRyaXAgZGlzY2lwbGluZSlcbi8vIHdpbGwgYXR0YWNoIG9uY2UgdGhlIGNoYW5nZSBsYXllciBsYW5kcy5cblxuaW1wb3J0IHsgdXNlQ2FsbGJhY2ssIHVzZUVmZmVjdCwgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7XG4gIGNhbWVyYUZvclRhcmdldCxcbiAgY2xhbXBab29tLFxuICBvcmlnaW5YLFxuICBvcmlnaW5ZLFxuICBwcm9qZWN0LFxuICB3b3JsZEF0LFxuICB6b29tQXJvdW5kLFxufSBmcm9tICcuLi9saWIvY2FtZXJhJztcbmltcG9ydCB0eXBlIHsgVmlld3BvcnQgfSBmcm9tICcuLi9saWIvY2FtZXJhJztcbmltcG9ydCB7IGFuY2hvclBvaW50LCBvYmplY3RBdExvY2FsLCBvYmplY3RzSW5SZWN0IH0gZnJvbSAnLi4vbGliL2dlb21ldHJ5JztcbmltcG9ydCB7IGdlbmVyYXRlSWQgfSBmcm9tICcuLi9saWIvaWRzJztcbmltcG9ydCB0eXBlIHtcbiAgQmFja2dyb3VuZCxcbiAgQ2FtZXJhLFxuICBDb25uZWN0aW9uLFxuICBKb3VybmV5LFxuICBNb2RlLFxuICBPYmplY3RLaW5kLFxuICBTY3JlZW5LaW5kLFxuICBUb2FzdCxcbiAgVmlldyxcbiAgVmlld1RhcmdldCxcbiAgV09iamVjdCxcbn0gZnJvbSAnLi4vbGliL3R5cGVzJztcbmltcG9ydCB7IEJPQVJELCBTRUVEX0pPVVJORVlTLCBTRUVEX1ZJRVdTLCBzZWVkT2JqZWN0cyB9IGZyb20gJy4uL2RhdGEvc2VlZEJvYXJkJztcbmltcG9ydCB7XG4gIGJvYXJkRXhpc3RzLFxuICBjbGFzc2lmeUJvYXJkVGFyZ2V0RmFpbHVyZSxcbiAgY29weUludG9Bc3NldHMsXG4gIGZvbGRlcklzQm9hcmQsXG4gIGxvYWRCb2FyZCxcbiAgb3BlbkJvYXJkVGFyZ2V0LFxuICByZW1vdmVWaWV3LFxuICByZXN0b3JlT2JqZWN0LFxuICBzYXZlSm91cm5leSBhcyBwZXJzaXN0Sm91cm5leSxcbiAgc2F2ZU9iamVjdCxcbiAgc2F2ZVZpZXcgYXMgcGVyc2lzdFZpZXcsXG4gIHNlZWRCb2FyZCxcbiAgdHJhc2hPYmplY3QsXG4gIHdyaXRlTmV3Qm9hcmQsXG59IGZyb20gJy4uL2xpYi9ib2FyZFN0b3JlJztcbmltcG9ydCB0eXBlIHsgQm9hcmRUYXJnZXQgfSBmcm9tICcuLi9saWIvYm9hcmRTdG9yZSc7XG5pbXBvcnQgeyBib2FyZFNwYWNlUm9vdCwgcGlja0ZpbGUsIHJlcXVlc3RTcGFjZSwgc2FmZVJlbCB9IGZyb20gJy4uL2xpYi9waWNrRmlsZSc7XG4vLyBTdWJwYXRoIGltcG9ydCwgbm90IHRoZSBwYWNrYWdlIGJhcnJlbDogdGhlIGJhcnJlbCByZS1leHBvcnRzIGAuL3Rhc2tzYCxcbi8vIHdob3NlIHRvcC1sZXZlbCBgYWRkTGlzdGVuZXJgIHNpZGUgZWZmZWN0IHRocm93cyBgbm8gaG9zdCB0cmFuc3BvcnRgIGF0XG4vLyBtb2R1bGUtZXZhbCB0aW1lIHVuZGVyIGxvY2FsIGB2aXRlIGRldmAuIGAvbW91bnRzYCBpcyBzaWRlLWVmZmVjdC1mcmVlLlxuaW1wb3J0IHsgZ2V0TW91bnRzLCBvbk1vdW50c0NoYW5nZSB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrL21vdW50cyc7XG5pbXBvcnQgdHlwZSB7IFNhbmRib3hNb3VudCB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrL21vdW50cyc7XG5pbXBvcnQge1xuICBhYm9ydE9wZW5Qcm9qZWN0LFxuICBkaXJDYXBUb0JvYXJkVGFyZ2V0LFxuICByZWFkT3BlblByb2plY3RJbnB1dCxcbiAgcmVwb3J0T3BlbmVkLFxuICByZXNvbHZlRGVsZWdhdGVkTW91bnQsXG59IGZyb20gJy4uL2xpYi9vcGVuUHJvamVjdCc7XG5cbi8qKiBKb2luIGEgbW91bnQgcm9vdCB3aXRoIGEgKHZhbGlkYXRlZCwgcmVsYXRpdmUpIHBhdGg7IGNvbGxhcHNlIGRvdWJsZSBzbGFzaGVzLiAqL1xuY29uc3Qgc3ViUGF0aCA9IChyb290OiBzdHJpbmcsIHJlbDogc3RyaW5nKTogc3RyaW5nID0+IGAke3Jvb3R9LyR7cmVsfWAucmVwbGFjZSgvXFwvKy9nLCAnLycpO1xuXG4vKiogU2hvcnQgYCDCtyBjb2RlYCBzdWZmaXggZnJvbSBhIHR5cGVkIHBsYXRmb3JtL2ZzIGVycm9yLCBmb3IgdG9hc3QgdGV4dC4gKi9cbmZ1bmN0aW9uIGNvZGVPZihlOiB1bmtub3duKTogc3RyaW5nIHtcbiAgY29uc3QgYyA9IChlIGFzIHsgY29kZT86IHN0cmluZyB9IHwgbnVsbCk/LmNvZGU7XG4gIHJldHVybiBjID8gYCDCtyAke2N9YCA6ICcnO1xufVxuXG5pbnRlcmZhY2UgV0JTdGF0ZSB7XG4gIG1vZGU6IE1vZGU7XG4gIGxpZ2h0OiBib29sZWFuO1xuICBiZzogQmFja2dyb3VuZDtcbiAgdGl0bGU6IHN0cmluZztcbiAgY2FtOiBDYW1lcmE7XG4gIHZwOiBWaWV3cG9ydDtcbiAgb2JqZWN0czogV09iamVjdFtdO1xuICB2aWV3czogVmlld1tdO1xuICBqb3VybmV5czogSm91cm5leVtdO1xuICBzZWxlY3Rpb246IHN0cmluZ1tdO1xuICBob3Zlcjogc3RyaW5nIHwgbnVsbDtcbiAgbWFycXVlZTogeyB4OiBudW1iZXI7IHk6IG51bWJlcjsgdzogbnVtYmVyOyBoOiBudW1iZXIgfSB8IG51bGw7XG4gIGNvbm5lY3RQcmV2aWV3OiB7IGZyb206IHN0cmluZzsgeDogbnVtYmVyOyB5OiBudW1iZXI7IHRhcmdldDogc3RyaW5nIHwgbnVsbCB9IHwgbnVsbDtcbiAgLyoqIEtleWJvYXJkIGNvbm5lY3QgbW9kZSAoUjMtNjA3KTogdGhlIHNvdXJjZSBvYmplY3QsIGFuZCB0aGUgY3Vyc29yIG9iamVjdFxuICAgKiAgYXJyb3dzIHdhbGsgYXMgdGhlIGNvbm5lY3QgdGFyZ2V0LiBOdWxsIHdoZW4gbm90IGNvbm5lY3RpbmcuICovXG4gIGNvbm5lY3RGcm9tOiBzdHJpbmcgfCBudWxsO1xuICBjb25uZWN0Q3Vyc29yOiBzdHJpbmcgfCBudWxsO1xuICBpbnNwZWN0b3JPcGVuOiBib29sZWFuO1xuICBwYW5lbE9wZW46IGJvb2xlYW47XG4gIHF1aWNrTWVudTogeyBseDogbnVtYmVyOyBseTogbnVtYmVyOyB3eDogbnVtYmVyOyB3eTogbnVtYmVyIH0gfCBudWxsO1xuICBqb3VybmV5OiB7IGppZDogc3RyaW5nOyBpZHg6IG51bWJlciB9IHwgbnVsbDtcbiAgdG9hc3RzOiBUb2FzdFtdO1xuICBzY3JlZW46IFNjcmVlbktpbmQ7XG4gIGRlbW9NZW51T3BlbjogYm9vbGVhbjtcbiAgcGFubmluZzogYm9vbGVhbjtcbiAgcmVkdWNlZDogYm9vbGVhbjtcbiAgLyoqIFRoZSBuYW1lZCBidXN5IHN0YXRlIG9mIHRoZSBvbmUgbG9uZy1ydW5uaW5nIHBpY2sgZmxvdyAoUi1JWC0yKTogdGhlXG4gICAqICBjb25maXJtaW5nIGNvbnRyb2wgc2hvd3MgdGhpcyBsYWJlbCBhbmQgYXJpYS1idXN5IHVudGlsIGl0IHNldHRsZXMuICovXG4gIGJ1c3k6IG51bGwgfCAnaW5zZXJ0LWltYWdlJyB8ICduZXctYm9hcmQnIHwgJ29wZW4tYm9hcmQnO1xuICAvKiogTGl2ZSBtb3VudHMsIG1pcnJvcmVkIGZyb20gdGhlIGhvc3QgKHRoZSBib2FyZCBjaG9vc2VyIGxpc3RzIHRoZXNlKS4gKi9cbiAgbW91bnRzOiBTYW5kYm94TW91bnRbXTtcbn1cblxudHlwZSBEcmFnID1cbiAgfCB7IHR5cGU6ICdwYW4nOyBzeDogbnVtYmVyOyBzeTogbnVtYmVyOyBjeDogbnVtYmVyOyBjeTogbnVtYmVyIH1cbiAgfCB7IHR5cGU6ICdtb3ZlJzsgc3g6IG51bWJlcjsgc3k6IG51bWJlcjsgaWRzOiBzdHJpbmdbXTsgb3JpZzogUmVjb3JkPHN0cmluZywgeyB4OiBudW1iZXI7IHk6IG51bWJlciB9PjsgbW92ZWQ6IGJvb2xlYW4gfVxuICB8IHsgdHlwZTogJ21hcnF1ZWUnOyBzeDogbnVtYmVyOyBzeTogbnVtYmVyOyBhZGQ6IGJvb2xlYW47IGJhc2U6IHN0cmluZ1tdIH1cbiAgfCB7IHR5cGU6ICdjb25uZWN0JzsgZnJvbTogc3RyaW5nOyBzaWRlOiBzdHJpbmc7IG1vdmVkOiBib29sZWFuIH1cbiAgfCB7IHR5cGU6ICdyZXNpemUnOyBraW5kOiBzdHJpbmc7IHN4OiBudW1iZXI7IHN5OiBudW1iZXI7IG86IHsgeDogbnVtYmVyOyB5OiBudW1iZXI7IHc6IG51bWJlcjsgaDogbnVtYmVyOyByb3Q6IG51bWJlciB9OyBpZDogc3RyaW5nOyBtb3ZlZDogYm9vbGVhbiB9XG4gIHwgeyB0eXBlOiAncm90YXRlJzsgc3g6IG51bWJlcjsgc3k6IG51bWJlcjsgbzogeyB4OiBudW1iZXI7IHk6IG51bWJlcjsgdzogbnVtYmVyOyBoOiBudW1iZXI7IHJvdDogbnVtYmVyIH07IGlkOiBzdHJpbmc7IG1vdmVkOiBib29sZWFuIH1cbiAgfCBudWxsO1xuXG5jb25zdCBpbml0aWFsVmlld3BvcnQgPSAoKTogVmlld3BvcnQgPT4gKHtcbiAgdnc6IHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnID8gd2luZG93LmlubmVyV2lkdGggOiAxNDQwLFxuICB2aDogdHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgPyB3aW5kb3cuaW5uZXJIZWlnaHQgOiA5MDAsXG4gIHZsZWZ0OiAwLFxuICB2dG9wOiAwLFxufSk7XG5cbi8qKiBUaGUgT05FIHNwZWxsaW5nIG9mIHNlbGVjdGlvbiBzZW1hbnRpY3MgKFIzLTYwNywgUjYpOiBnaXZlbiB0aGUgY3VycmVudFxuICogIHNlbGVjdGlvbiBhbmQgYW4gaWQsIHRoZSBuZXh0IHNlbGVjdGlvbiBmb3IgYSByZXBsYWNlLSBvciB0b2dnbGUtY2xpY2sgL1xuICogIGZvY3VzLiBQdXJlLCBzbyB0aGUgcG9pbnRlciBwYXRoIGFuZCB0aGUga2V5Ym9hcmQgcGF0aCBjYW5ub3QgZHJpZnQuICovXG5leHBvcnQgZnVuY3Rpb24gYXBwbHlTZWxlY3Rpb24oc2VsOiBzdHJpbmdbXSwgaWQ6IHN0cmluZywgYWRkaXRpdmU6IGJvb2xlYW4pOiBzdHJpbmdbXSB7XG4gIGlmIChhZGRpdGl2ZSkgcmV0dXJuIHNlbC5pbmNsdWRlcyhpZCkgPyBzZWwuZmlsdGVyKCh4KSA9PiB4ICE9PSBpZCkgOiBzZWwuY29uY2F0KGlkKTtcbiAgcmV0dXJuIHNlbC5pbmNsdWRlcyhpZCkgPyBzZWwgOiBbaWRdO1xufVxuXG5jb25zdCBNT0JJTEVfQlJFQUtQT0lOVCA9IDcyMDtcblxuLy8gVGhlIGJvYXJkLW1hbmlmZXN0IHNjaGVtYSB2ZXJzaW9uIFRISVMgcmVhZGVyIHVuZGVyc3RhbmRzLiBBIG1hbmlmZXN0IGNhcnJ5aW5nXG4vLyBhIGhpZ2hlciBgc2NoZW1hOmAgaXMgZnJvbSBhIG5ld2VyIHJlYWRlciDigJQgcmVjb2duaXNlZCBidXQgbWFya2VkIHJlYWRvbmx5ICh0aGVcbi8vIGByZWFkb25seWAgZGVncmFkZWQgc3RhdGUsIHNwZWMgwqcyLjQpIHJhdGhlciB0aGFuIG1pcy1yZW5kZXJlZCAoUjMtNDAxKS5cbmNvbnN0IFNVUFBPUlRFRF9TQ0hFTUEgPSAxO1xuXG4vLyBUaGUgdXNhYmxlIGhlaWdodCBhIGpvdXJuZXktcGxheWluZyByZWN0IHZpZXcgZml0cyBpbnRvOiB0aGUgY2FwdGlvbiArIGNvbnRyb2xzXG4vLyB0YWtlIHJvdWdobHkgdGhlIGJvdHRvbSAyNDBweCBvZiBhbiA4NDRweCBwaG9uZSB2aWV3cG9ydCAoaXRlbSBSMy00MDApLCBzbyBhXG4vLyBmaXR0ZWQgdmlldyBtdXN0IGNsZWFyIHRoYXQgYmFuZCBvciB0aGUgc3ViamVjdCBoaWRlcyB1bmRlciB0aGUgY2hyb21lLlxuY29uc3QgSk9VUk5FWV9GSVRfSU5TRVQgPSAyNDA7XG5cbmNvbnN0IHByZWZlcnNSZWR1Y2VkTW90aW9uID0gKCk6IGJvb2xlYW4gPT4ge1xuICB0cnkge1xuICAgIHJldHVybiB3aW5kb3cubWF0Y2hNZWRpYSgnKHByZWZlcnMtcmVkdWNlZC1tb3Rpb246IHJlZHVjZSknKS5tYXRjaGVzO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbn07XG5cbi8qKiBUaGUgT05FIHNwZWxsaW5nIG9mIHdoYXQgZWFjaCBuYW1lZCBidXN5IHN0YXRlIHNheXMgb24gaXRzIGNvbnRyb2xcbiAqICAoUi1JWC0yIC8gUjYpOiBldmVyeSBzdXJmYWNlIHRoYXQgbmFtZXMgYSB3YWl0IHJlYWRzIHRoaXMgbWFwIOKAlCBjb3VwbGVkXG4gKiAgc3VyZmFjZXMgY2Fubm90IGRyaWZ0IGFwYXJ0IG9uIGEgcmV3b3JkLiAqL1xuZXhwb3J0IGNvbnN0IEJVU1lfTEFCRUxTID0ge1xuICAnaW5zZXJ0LWltYWdlJzogJ0FkZGluZyBpbWFnZeKApicsXG4gICduZXctYm9hcmQnOiAnQ3JlYXRpbmcgYm9hcmTigKYnLFxuICAnb3Blbi1ib2FyZCc6ICdPcGVuaW5nIGJvYXJk4oCmJyxcbn0gYXMgY29uc3Q7XG5cbmV4cG9ydCBmdW5jdGlvbiB1c2VMb2Rlc3RhcigpIHtcbiAgLy8gVGhlIGNhbnZhcyBlbGVtZW50IGFycml2ZXMgdmlhIGEgY2FsbGJhY2sgcmVmIChhIGZ1bmN0aW9uLCBub3QgYSByZWYgb2JqZWN0XG4gIC8vIHJlYWQgZHVyaW5nIHJlbmRlcikgc28gdGhlIGxpc3RlbmVyIGVmZmVjdCByZS1ydW5zIG9uY2UgaXQgbW91bnRzLlxuICBjb25zdCBbY2FudmFzRWwsIHNldENhbnZhc0VsXSA9IHVzZVN0YXRlPEhUTUxEaXZFbGVtZW50IHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IHJlZ2lzdGVyQ2FudmFzID0gdXNlQ2FsbGJhY2soKGVsOiBIVE1MRGl2RWxlbWVudCB8IG51bGwpID0+IHNldENhbnZhc0VsKGVsKSwgW10pO1xuICBjb25zdCBkcmFnUmVmID0gdXNlUmVmPERyYWc+KG51bGwpO1xuICBjb25zdCB0d2VlblJlZiA9IHVzZVJlZjxudW1iZXIgfCBudWxsPihudWxsKTtcbiAgY29uc3QgaG9sZFRpbWVyID0gdXNlUmVmPG51bWJlciB8IG51bGw+KG51bGwpO1xuICBjb25zdCBzcGFjZVJlZiA9IHVzZVJlZihmYWxzZSk7XG4gIGNvbnN0IHRvYXN0U2VxID0gdXNlUmVmKDApO1xuICAvLyBTdGFibGUgaW5kaXJlY3Rpb24gZm9yIHRoZSBkd2VsbCBhdXRvLWFkdmFuY2U6IGBnb1N0ZXBgIHNjaGVkdWxlc1xuICAvLyBgcGxheU5leHRSZWYuY3VycmVudCgpYCBzbyB0aGUgdGltZXIgYWx3YXlzIGNhbGxzIHRoZSBMQVRFU1QgcGxheU5leHRcbiAgLy8gKGFzc2lnbmVkIGFmdGVyIGl0cyB1c2VDYWxsYmFjayBpcyBkZWZpbmVkKSDigJQgYnJlYWtzIHRoZSBjaXJjdWxhciBkZXAuXG4gIGNvbnN0IHBsYXlOZXh0UmVmID0gdXNlUmVmPCgpID0+IHZvaWQ+KCgpID0+IHt9KTtcblxuICBjb25zdCBbc3RhdGUsIHNldFN0YXRlXSA9IHVzZVN0YXRlPFdCU3RhdGU+KCgpID0+ICh7XG4gICAgbW9kZTogJ3J1bicsXG4gICAgbGlnaHQ6IGZhbHNlLFxuICAgIGJnOiBCT0FSRC5iYWNrZ3JvdW5kLFxuICAgIHRpdGxlOiBCT0FSRC50aXRsZSxcbiAgICBjYW06IHsgY3g6IDI1MCwgY3k6IDE1MCwgem9vbTogMC42IH0sXG4gICAgdnA6IGluaXRpYWxWaWV3cG9ydCgpLFxuICAgIG9iamVjdHM6IHNlZWRPYmplY3RzKCksXG4gICAgdmlld3M6IFNFRURfVklFV1Muc2xpY2UoKSxcbiAgICBqb3VybmV5czogU0VFRF9KT1VSTkVZUyxcbiAgICBzZWxlY3Rpb246IFtdLFxuICAgIGhvdmVyOiBudWxsLFxuICAgIG1hcnF1ZWU6IG51bGwsXG4gICAgY29ubmVjdFByZXZpZXc6IG51bGwsXG4gICAgY29ubmVjdEZyb206IG51bGwsXG4gICAgY29ubmVjdEN1cnNvcjogbnVsbCxcbiAgICBpbnNwZWN0b3JPcGVuOiBmYWxzZSxcbiAgICBwYW5lbE9wZW46IGZhbHNlLFxuICAgIHF1aWNrTWVudTogbnVsbCxcbiAgICBqb3VybmV5OiBudWxsLFxuICAgIHRvYXN0czogW10sXG4gICAgc2NyZWVuOiBudWxsLFxuICAgIGRlbW9NZW51T3BlbjogZmFsc2UsXG4gICAgcGFubmluZzogZmFsc2UsXG4gICAgcmVkdWNlZDogcHJlZmVyc1JlZHVjZWRNb3Rpb24oKSxcbiAgICBidXN5OiBudWxsLFxuICAgIG1vdW50czogW10sXG4gIH0pKTtcblxuICAvLyBNaXJyb3IgY29tbWl0dGVkIHN0YXRlIHNvIHRoZSBkb2N1bWVudC1sZXZlbCBoYW5kbGVycyBicmFuY2ggb24gZnJlc2ggdmFsdWVzLlxuICBjb25zdCBzdGF0ZVJlZiA9IHVzZVJlZihzdGF0ZSk7XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgc3RhdGVSZWYuY3VycmVudCA9IHN0YXRlO1xuICB9KTtcblxuICBjb25zdCB1cGRhdGUgPSB1c2VDYWxsYmFjayhcbiAgICAocGF0Y2g6IFBhcnRpYWw8V0JTdGF0ZT4gfCAoKHM6IFdCU3RhdGUpID0+IFBhcnRpYWw8V0JTdGF0ZT4pKSA9PlxuICAgICAgc2V0U3RhdGUoKHByZXYpID0+ICh7IC4uLnByZXYsIC4uLih0eXBlb2YgcGF0Y2ggPT09ICdmdW5jdGlvbicgPyBwYXRjaChwcmV2KSA6IHBhdGNoKSB9KSksXG4gICAgW10sXG4gICk7XG5cbiAgY29uc3QgaXNNb2JpbGUgPSB1c2VDYWxsYmFjaygoKSA9PiBzdGF0ZS52cC52dyA8IE1PQklMRV9CUkVBS1BPSU5ULCBbc3RhdGUudnAudnddKTtcblxuICAvLyAtLS0tIGNhbWVyYSBoZWxwZXJzIChyZWFkIGxhdGVzdCB2aWV3cG9ydCBmcm9tIHRoZSByZWYpIC0tLS1cbiAgY29uc3QgbG9jYWxQb2ludCA9IHVzZUNhbGxiYWNrKChlOiB7IGNsaWVudFg6IG51bWJlcjsgY2xpZW50WTogbnVtYmVyIH0pOiBbbnVtYmVyLCBudW1iZXJdID0+IHtcbiAgICBjb25zdCB2cCA9IHN0YXRlUmVmLmN1cnJlbnQudnA7XG4gICAgcmV0dXJuIFtlLmNsaWVudFggLSB2cC52bGVmdCwgZS5jbGllbnRZIC0gdnAudnRvcF07XG4gIH0sIFtdKTtcblxuICBjb25zdCBzZXRab29tID0gdXNlQ2FsbGJhY2soKG56OiBudW1iZXIsIGx4PzogbnVtYmVyLCBseT86IG51bWJlcikgPT4ge1xuICAgIHVwZGF0ZSgocykgPT4gKHsgY2FtOiB6b29tQXJvdW5kKHMuY2FtLCBzLnZwLCBueiwgbHgsIGx5KSB9KSk7XG4gIH0sIFt1cGRhdGVdKTtcblxuICAvLyAtLS0tIHRvYXN0cyAtLS0tXG4gIGNvbnN0IGRpc21pc3NUb2FzdCA9IHVzZUNhbGxiYWNrKChpZDogbnVtYmVyKSA9PiB7XG4gICAgdXBkYXRlKChzKSA9PiAoeyB0b2FzdHM6IHMudG9hc3RzLmZpbHRlcigodCkgPT4gdC5pZCAhPT0gaWQpIH0pKTtcbiAgfSwgW3VwZGF0ZV0pO1xuXG4gIGNvbnN0IHRvYXN0ID0gdXNlQ2FsbGJhY2soXG4gICAgKHRleHQ6IHN0cmluZywgaWNvbiA9ICdjaGVjaycsIG9wdHM6IFBhcnRpYWw8VG9hc3Q+ID0ge30pID0+IHtcbiAgICAgIGNvbnN0IGlkID0gKyt0b2FzdFNlcS5jdXJyZW50O1xuICAgICAgY29uc3QgdDogVG9hc3QgPSB7IGlkLCB0ZXh0LCBpY29uLCAuLi5vcHRzIH07XG4gICAgICB1cGRhdGUoKHMpID0+ICh7IHRvYXN0czogcy50b2FzdHMuY29uY2F0KHQpIH0pKTtcbiAgICAgIGNvbnN0IHR0bCA9IG9wdHMuYWN0aW9uTGFiZWwgPyA5MDAwIDogMzUwMDtcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4gZGlzbWlzc1RvYXN0KGlkKSwgdHRsKTtcbiAgICB9LFxuICAgIFt1cGRhdGUsIGRpc21pc3NUb2FzdF0sXG4gICk7XG5cbiAgLy8gLS0tLSBwZXJzaXN0ZW5jZSAodGhlIMKnMi42IHJvdW5kLXRyaXAgc2VhbSwgbm93IGxpdmUpIC0tLS1cbiAgLy8gVGhlIGJvYXJkJ3MgZHVyYWJsZSB0YXJnZXQgKGEgcGVyLXVzZXIgYXBwIHNwYWNlKSBvbmNlIHJlc29sdmVkOyBudWxsIG1lYW5zXG4gIC8vIHdlIG5ldmVyIGdvdCBvbmUgKHNpZ25lZCBvdXQgLyBkZWNsaW5lZCkgYW5kIHRoZSBib2FyZCBpcyBpbiBtZW1vcnkgb25seS5cbiAgY29uc3QgYm9hcmRSZWYgPSB1c2VSZWY8Qm9hcmRUYXJnZXQgfCBudWxsPihudWxsKTtcbiAgLy8gUGVyLW9iamVjdCBkZWJvdW5jZSB0aW1lcnMgc28gaW5zcGVjdG9yIHR5cGluZyAvIGFycm93IG51ZGdlcyBhdXRvc2F2ZSBvbmNlXG4gIC8vIHRoZXkgc2V0dGxlLCBub3Qgb24gZXZlcnkga2V5c3Ryb2tlLlxuICBjb25zdCBzYXZlVGltZXJzID0gdXNlUmVmPE1hcDxzdHJpbmcsIG51bWJlcj4+KG5ldyBNYXAoKSk7XG5cbiAgLy8gV3JpdGUgdGhlIGdpdmVuIG9iamVjdHMnIGZpbGVzLCB0aGVuIHJlcG9ydCB3aXRoIG9uZSB0b2FzdC4gV2l0aCBubyBib2FyZFxuICAvLyB0aGUgY2hhbmdlIGlzIGluIG1lbW9yeSBvbmx5ICh3ZSBrZWVwIHRoZSBvcHRpbWlzdGljIG1lc3NhZ2UpOyBhIHJlYWQtb25seVxuICAvLyBib2FyZCByZXBvcnRzIGluc3RlYWQgb2Ygc2lsZW50bHkgZHJvcHBpbmcgdGhlIHdyaXRlLlxuICBjb25zdCBjb21taXRTYXZlID0gdXNlQ2FsbGJhY2soXG4gICAgKG9ianM6IFdPYmplY3RbXSwgc2F2ZWRUZXh0OiBzdHJpbmcsIHNhdmVkSWNvbiA9ICdjaGVjaycpID0+IHtcbiAgICAgIGNvbnN0IHQgPSBib2FyZFJlZi5jdXJyZW50O1xuICAgICAgaWYgKCF0KSB7XG4gICAgICAgIHRvYXN0KHNhdmVkVGV4dCwgc2F2ZWRJY29uKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgaWYgKHQubW9kZSA9PT0gJ3JvJykge1xuICAgICAgICB0b2FzdCgnUmVhZC1vbmx5IGJvYXJkIMK3IGNoYW5nZSBub3Qgc2F2ZWQnLCAnbG9jaycsIHsgaWNvbkNvbG9yOiAndmFyKC0taW5rLTIpJyB9KTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgUHJvbWlzZS5hbGwob2Jqcy5tYXAoKG8pID0+IHNhdmVPYmplY3QodCwgbykpKS50aGVuKFxuICAgICAgICAoKSA9PiB0b2FzdChzYXZlZFRleHQsIHNhdmVkSWNvbiksXG4gICAgICAgIChlKSA9PiB0b2FzdChgU2F2ZSBmYWlsZWQke2NvZGVPZihlKX1gLCAnYWxlcnQnLCB7IGljb25Db2xvcjogJyNjYWEyNGEnIH0pLFxuICAgICAgKTtcbiAgICB9LFxuICAgIFt0b2FzdF0sXG4gICk7XG5cbiAgLy8gUXVpZXQgZGVib3VuY2VkIGF1dG9zYXZlIGZvciBjb250aW51b3VzIGVkaXRzICh0eXBpbmcsIGFycm93LWtleSBudWRnZXMpLlxuICBjb25zdCBzY2hlZHVsZVNhdmUgPSB1c2VDYWxsYmFjaygoaWRzOiBzdHJpbmdbXSkgPT4ge1xuICAgIGNvbnN0IHQgPSBib2FyZFJlZi5jdXJyZW50O1xuICAgIGlmICghdCB8fCB0Lm1vZGUgPT09ICdybycpIHJldHVybjtcbiAgICBmb3IgKGNvbnN0IGlkIG9mIGlkcykge1xuICAgICAgY29uc3QgcHJldiA9IHNhdmVUaW1lcnMuY3VycmVudC5nZXQoaWQpO1xuICAgICAgaWYgKHByZXYpIGNsZWFyVGltZW91dChwcmV2KTtcbiAgICAgIGNvbnN0IGhhbmRsZSA9IHdpbmRvdy5zZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgc2F2ZVRpbWVycy5jdXJyZW50LmRlbGV0ZShpZCk7XG4gICAgICAgIGNvbnN0IG8gPSBzdGF0ZVJlZi5jdXJyZW50Lm9iamVjdHMuZmluZCgoeCkgPT4geC5pZCA9PT0gaWQpO1xuICAgICAgICBpZiAobykgc2F2ZU9iamVjdCh0LCBvKS5jYXRjaCgoKSA9PiB1bmRlZmluZWQpO1xuICAgICAgfSwgNTAwKTtcbiAgICAgIHNhdmVUaW1lcnMuY3VycmVudC5zZXQoaWQsIGhhbmRsZSk7XG4gICAgfVxuICB9LCBbXSk7XG5cbiAgLy8gLS0tLSBjYW1lcmEgYW5pbWF0aW9uIC0tLS1cbiAgY29uc3QgZmx5VG8gPSB1c2VDYWxsYmFjayhcbiAgICAodGFyZ2V0OiBWaWV3VGFyZ2V0IHwgbnVsbCwgZHVyPzogbnVtYmVyLCBmaXRIPzogbnVtYmVyKSA9PiB7XG4gICAgICBpZiAoIXRhcmdldCkgcmV0dXJuO1xuICAgICAgLy8gQSB2aWV3IGNhcnJ5aW5nIGEgcmVjdCBuYW1lcyBhIFJFR0lPTiwgbm90IGEgbWFnbmlmaWNhdGlvbjogZml0IGl0IHRvIHRoZVxuICAgICAgLy8gdXNhYmxlIHZpZXdwb3J0IChSMy00MDApLiBmaXRIICh3aGVuIGdpdmVuKSBpcyB0aGUgdXNhYmxlIGhlaWdodCDigJQgdGhlXG4gICAgICAvLyBjYXB0aW9uIGJhbmQgZHVyaW5nIGpvdXJuZXkgcGxheWJhY2sg4oCUIHNvIHRoZSBzdWJqZWN0IGNsZWFycyB0aGUgY2hyb21lLlxuICAgICAgY29uc3QgZGVzdCA9IGNhbWVyYUZvclRhcmdldCh0YXJnZXQsIHN0YXRlUmVmLmN1cnJlbnQudnAudncsIGZpdEggPz8gc3RhdGVSZWYuY3VycmVudC52cC52aCk7XG4gICAgICBpZiAodHdlZW5SZWYuY3VycmVudCkgY2FuY2VsQW5pbWF0aW9uRnJhbWUodHdlZW5SZWYuY3VycmVudCk7XG4gICAgICBpZiAoc3RhdGVSZWYuY3VycmVudC5yZWR1Y2VkIHx8ICFkdXIpIHtcbiAgICAgICAgdXBkYXRlKHsgY2FtOiBkZXN0IH0pO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBjb25zdCBmcm9tID0geyAuLi5zdGF0ZVJlZi5jdXJyZW50LmNhbSB9O1xuICAgICAgY29uc3QgdDAgPSBwZXJmb3JtYW5jZS5ub3coKTtcbiAgICAgIGNvbnN0IGVhc2UgPSAocDogbnVtYmVyKSA9PiAocCA8IDAuNSA/IDQgKiBwICogcCAqIHAgOiAxIC0gTWF0aC5wb3coLTIgKiBwICsgMiwgMykgLyAyKTtcbiAgICAgIGNvbnN0IHN0ZXAgPSAobm93OiBudW1iZXIpID0+IHtcbiAgICAgICAgY29uc3QgcCA9IE1hdGgubWluKDEsIChub3cgLSB0MCkgLyBkdXIpO1xuICAgICAgICBjb25zdCBlID0gZWFzZShwKTtcbiAgICAgICAgdXBkYXRlKHtcbiAgICAgICAgICBjYW06IHtcbiAgICAgICAgICAgIGN4OiBmcm9tLmN4ICsgKGRlc3QuY3ggLSBmcm9tLmN4KSAqIGUsXG4gICAgICAgICAgICBjeTogZnJvbS5jeSArIChkZXN0LmN5IC0gZnJvbS5jeSkgKiBlLFxuICAgICAgICAgICAgem9vbTogZnJvbS56b29tICsgKGRlc3Quem9vbSAtIGZyb20uem9vbSkgKiBlLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgICBpZiAocCA8IDEpIHR3ZWVuUmVmLmN1cnJlbnQgPSByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoc3RlcCk7XG4gICAgICB9O1xuICAgICAgdHdlZW5SZWYuY3VycmVudCA9IHJlcXVlc3RBbmltYXRpb25GcmFtZShzdGVwKTtcbiAgICB9LFxuICAgIFt1cGRhdGVdLFxuICApO1xuXG4gIC8vIC0tLS0gdmlld3MgJiBqb3VybmV5cyAtLS0tXG4gIGNvbnN0IHJlc29sdmVWaWV3ID0gdXNlQ2FsbGJhY2soKHY6IFZpZXdUYXJnZXQgfCBzdHJpbmcpID0+IHtcbiAgICBpZiAodHlwZW9mIHYgPT09ICdzdHJpbmcnKSByZXR1cm4gc3RhdGVSZWYuY3VycmVudC52aWV3cy5maW5kKCh4KSA9PiB4Lm5hbWUgPT09IHYpID8/IG51bGw7XG4gICAgY29uc3QgdDogVmlld1RhcmdldCA9IHsgY3g6IHYuY3gsIGN5OiB2LmN5LCB6b29tOiB2Lnpvb20gfTtcbiAgICBpZiAodi53KSB0LncgPSB2Lnc7XG4gICAgaWYgKHYuaCkgdC5oID0gdi5oO1xuICAgIHJldHVybiB0O1xuICB9LCBbXSk7XG5cbiAgY29uc3Qgc2F2ZVZpZXcgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgY29uc3QgcyA9IHN0YXRlUmVmLmN1cnJlbnQ7XG4gICAgY29uc3QgdmlldzogVmlldyA9IHsgbmFtZTogYHZpZXctJHtzLnZpZXdzLmxlbmd0aCArIDF9YCwgY3g6IHMuY2FtLmN4LCBjeTogcy5jYW0uY3ksIHpvb206IHMuY2FtLnpvb20gfTtcbiAgICB1cGRhdGUoKHN0KSA9PiAoeyB2aWV3czogc3Qudmlld3MuY29uY2F0KFt2aWV3XSkgfSkpO1xuICAgIGNvbnN0IHRleHQgPSBgU2F2ZWQgdmlld3MvJHt2aWV3Lm5hbWV9Lm1kYDtcbiAgICBjb25zdCB0ID0gYm9hcmRSZWYuY3VycmVudDtcbiAgICBpZiAoIXQpIHtcbiAgICAgIHRvYXN0KHRleHQsICdzYXZlJyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmICh0Lm1vZGUgPT09ICdybycpIHtcbiAgICAgIHRvYXN0KCdSZWFkLW9ubHkgYm9hcmQgwrcgdmlldyBub3Qgc2F2ZWQnLCAnbG9jaycsIHsgaWNvbkNvbG9yOiAndmFyKC0taW5rLTIpJyB9KTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgcGVyc2lzdFZpZXcodCwgdmlldykudGhlbihcbiAgICAgICgpID0+IHRvYXN0KHRleHQsICdzYXZlJyksXG4gICAgICAoZSkgPT4gdG9hc3QoYENvdWxkbid0IHNhdmUgdmlldyR7Y29kZU9mKGUpfWAsICdhbGVydCcsIHsgaWNvbkNvbG9yOiAnI2NhYTI0YScgfSksXG4gICAgKTtcbiAgfSwgW3VwZGF0ZSwgdG9hc3RdKTtcblxuICAvKiogUmVtb3ZlIGEgdmlldyBvbiB0aGUgc3VyZmFjZSB0aGF0IGNyZWF0ZXMgdGhlbSAoUjMtNjA3LCBSLUlYLTUpLiBBXG4gICAqICByZWFkLW9ubHkgYm9hcmQgcmVmdXNlcyBCRUZPUkUgYW55dGhpbmcgZHJvcHMgKHRoZSByb3cgbmV2ZXIgdmFuaXNoZXNcbiAgICogIGludG8gYSByZWZ1c2FsKTsgb24gd3JpdGFibGUgYm9hcmRzIHRoZSBkcm9wIGlzIG9wdGltaXN0aWMgYW5kIGEgZmFpbGVkXG4gICAqICBmaWxlIHJlbW92YWwgcm9sbHMgdGhlIHZpZXcgYmFjayBpbi4gKi9cbiAgY29uc3QgZGVsZXRlVmlldyA9IHVzZUNhbGxiYWNrKFxuICAgIChuYW1lOiBzdHJpbmcpID0+IHtcbiAgICAgIGNvbnN0IHQgPSBib2FyZFJlZi5jdXJyZW50O1xuICAgICAgY29uc3QgdmlldyA9IHN0YXRlUmVmLmN1cnJlbnQudmlld3MuZmluZCgodikgPT4gdi5uYW1lID09PSBuYW1lKTtcbiAgICAgIGlmICghdmlldykgcmV0dXJuO1xuICAgICAgaWYgKHQgJiYgdC5tb2RlID09PSAncm8nKSB7XG4gICAgICAgIHRvYXN0KCdSZWFkLW9ubHkgYm9hcmQgwrcgdmlldyBub3QgcmVtb3ZlZCcsICdsb2NrJywgeyBpY29uQ29sb3I6ICd2YXIoLS1pbmstMiknIH0pO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICB1cGRhdGUoKHMpID0+ICh7IHZpZXdzOiBzLnZpZXdzLmZpbHRlcigodikgPT4gdi5uYW1lICE9PSBuYW1lKSB9KSk7XG4gICAgICBpZiAoIXQpIHtcbiAgICAgICAgdG9hc3QoYFJlbW92ZWQgdmlld3MvJHtuYW1lfS5tZGAsICd0cmFzaCcpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICByZW1vdmVWaWV3KHQsIG5hbWUpLnRoZW4oXG4gICAgICAgICgpID0+IHRvYXN0KGBSZW1vdmVkIHZpZXdzLyR7bmFtZX0ubWRgLCAndHJhc2gnKSxcbiAgICAgICAgKGUpID0+IHtcbiAgICAgICAgICAvLyBSb2xsIHRoZSBvcHRpbWlzdGljIGRyb3AgYmFjayDigJQgdGhlIGZpbGUgc3Vydml2ZWQsIHNvIG11c3QgdGhlIHJvdy5cbiAgICAgICAgICB1cGRhdGUoKHMpID0+IChzLnZpZXdzLnNvbWUoKHYpID0+IHYubmFtZSA9PT0gbmFtZSkgPyB7fSA6IHsgdmlld3M6IHMudmlld3MuY29uY2F0KFt2aWV3XSkgfSkpO1xuICAgICAgICAgIHRvYXN0KGBDb3VsZG4ndCByZW1vdmUgdmlldyR7Y29kZU9mKGUpfWAsICdhbGVydCcsIHsgaWNvbkNvbG9yOiAnI2NhYTI0YScgfSk7XG4gICAgICAgIH0sXG4gICAgICApO1xuICAgIH0sXG4gICAgW3VwZGF0ZSwgdG9hc3RdLFxuICApO1xuXG4gIGNvbnN0IGFkZEpvdXJuZXlTdGVwID0gdXNlQ2FsbGJhY2soXG4gICAgKGppZDogc3RyaW5nKSA9PiB7XG4gICAgICBjb25zdCBzID0gc3RhdGVSZWYuY3VycmVudDtcbiAgICAgIGNvbnN0IGogPSBzLmpvdXJuZXlzLmZpbmQoKHgpID0+IHguaWQgPT09IGppZCk7XG4gICAgICBpZiAoIWopIHJldHVybjtcbiAgICAgIGNvbnN0IG5leHQ6IEpvdXJuZXkgPSB7IC4uLmosIHN0ZXBzOiBqLnN0ZXBzLmNvbmNhdChbeyB2aWV3OiB7IGN4OiBzLmNhbS5jeCwgY3k6IHMuY2FtLmN5LCB6b29tOiBzLmNhbS56b29tIH0gfV0pIH07XG4gICAgICB1cGRhdGUoKHN0KSA9PiAoeyBqb3VybmV5czogc3Quam91cm5leXMubWFwKCh4KSA9PiAoeC5pZCA9PT0gamlkID8gbmV4dCA6IHgpKSB9KSk7XG4gICAgICBjb25zdCB0ZXh0ID0gYEFkZGVkIHN0ZXAgJHtuZXh0LnN0ZXBzLmxlbmd0aH0gdG8gJHtqLnRpdGxlfSDCtyBzYXZlZCB0byAke2ouaWR9Lm1keGA7XG4gICAgICBjb25zdCB0ID0gYm9hcmRSZWYuY3VycmVudDtcbiAgICAgIGlmICghdCkge1xuICAgICAgICB0b2FzdCh0ZXh0LCAncGx1cycpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAodC5tb2RlID09PSAncm8nKSB7XG4gICAgICAgIHRvYXN0KCdSZWFkLW9ubHkgYm9hcmQgwrcgc3RlcCBub3Qgc2F2ZWQnLCAnbG9jaycsIHsgaWNvbkNvbG9yOiAndmFyKC0taW5rLTIpJyB9KTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgcGVyc2lzdEpvdXJuZXkodCwgbmV4dCkudGhlbihcbiAgICAgICAgKCkgPT4gdG9hc3QodGV4dCwgJ3BsdXMnKSxcbiAgICAgICAgKGUpID0+IHRvYXN0KGBDb3VsZG4ndCBzYXZlIGpvdXJuZXkke2NvZGVPZihlKX1gLCAnYWxlcnQnLCB7IGljb25Db2xvcjogJyNjYWEyNGEnIH0pLFxuICAgICAgKTtcbiAgICB9LFxuICAgIFt1cGRhdGUsIHRvYXN0XSxcbiAgKTtcblxuICBjb25zdCBnb1N0ZXAgPSB1c2VDYWxsYmFjayhcbiAgICAoajogSm91cm5leSwgaWR4OiBudW1iZXIsIGluc3RhbnQ/OiBib29sZWFuKSA9PiB7XG4gICAgICBjb25zdCBzID0gai5zdGVwc1tpZHhdO1xuICAgICAgY29uc3QgdiA9IHJlc29sdmVWaWV3KHMudmlldyk7XG4gICAgICBpZiAodikgZmx5VG8odiwgaW5zdGFudCA/IDAgOiBzLmR1cmF0aW9uID8/IDgwMCwgc3RhdGVSZWYuY3VycmVudC52cC52aCAtIEpPVVJORVlfRklUX0lOU0VUKTtcbiAgICAgIC8vIER3ZWxsIChSMy00MDIpOiBhIHN0ZXAgY2FycnlpbmcgYGhvbGRgIHBhdXNlcyB0aGF0IGxvbmcgYWZ0ZXIgYXJyaXZpbmcsXG4gICAgICAvLyB0aGVuIEFVVE8tYWR2YW5jZXMuIENsZWFyZWQgYnkgYW55IHZpZXdlciBjb250cm9sIChuZXh0L3ByZXYvc2Vlay9leGl0KS5cbiAgICAgIC8vIFVuZGVyIHByZWZlcnMtcmVkdWNlZC1tb3Rpb24gdGhlIGpvdXJuZXkgc3RheXMgaW5wdXQtZHJpdmVuIOKAlCBtYXRjaGluZ1xuICAgICAgLy8gZmx5VG8ncyBjdXQgb2YgdGhlIHR3ZWVuIOKAlCBzbyBhIHZpZXdlciBpcyBuZXZlciBhZHZhbmNlZCB1bnByb21wdGVkLlxuICAgICAgaWYgKGhvbGRUaW1lci5jdXJyZW50KSB7XG4gICAgICAgIGNsZWFyVGltZW91dChob2xkVGltZXIuY3VycmVudCk7XG4gICAgICAgIGhvbGRUaW1lci5jdXJyZW50ID0gbnVsbDtcbiAgICAgIH1cbiAgICAgIGlmIChzLmhvbGQgJiYgIXN0YXRlUmVmLmN1cnJlbnQucmVkdWNlZCkge1xuICAgICAgICBob2xkVGltZXIuY3VycmVudCA9IHdpbmRvdy5zZXRUaW1lb3V0KCgpID0+IHBsYXlOZXh0UmVmLmN1cnJlbnQoKSwgcy5ob2xkKTtcbiAgICAgIH1cbiAgICB9LFxuICAgIFtyZXNvbHZlVmlldywgZmx5VG9dLFxuICApO1xuXG4gIGNvbnN0IHBsYXlKb3VybmV5ID0gdXNlQ2FsbGJhY2soXG4gICAgKGppZDogc3RyaW5nKSA9PiB7XG4gICAgICBjb25zdCBqID0gc3RhdGVSZWYuY3VycmVudC5qb3VybmV5cy5maW5kKCh4KSA9PiB4LmlkID09PSBqaWQpO1xuICAgICAgaWYgKCFqKSByZXR1cm47XG4gICAgICBpZiAoaG9sZFRpbWVyLmN1cnJlbnQpIHtcbiAgICAgICAgY2xlYXJUaW1lb3V0KGhvbGRUaW1lci5jdXJyZW50KTtcbiAgICAgICAgaG9sZFRpbWVyLmN1cnJlbnQgPSBudWxsO1xuICAgICAgfVxuICAgICAgdXBkYXRlKHsgam91cm5leTogeyBqaWQsIGlkeDogMCB9LCBwYW5lbE9wZW46IGZhbHNlLCBpbnNwZWN0b3JPcGVuOiBmYWxzZSB9KTtcbiAgICAgIGdvU3RlcChqLCAwLCB0cnVlKTtcbiAgICB9LFxuICAgIFt1cGRhdGUsIGdvU3RlcF0sXG4gICk7XG5cbiAgY29uc3QgcGxheUV4aXQgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgaWYgKHR3ZWVuUmVmLmN1cnJlbnQpIGNhbmNlbEFuaW1hdGlvbkZyYW1lKHR3ZWVuUmVmLmN1cnJlbnQpO1xuICAgIGlmIChob2xkVGltZXIuY3VycmVudCkge1xuICAgICAgY2xlYXJUaW1lb3V0KGhvbGRUaW1lci5jdXJyZW50KTtcbiAgICAgIGhvbGRUaW1lci5jdXJyZW50ID0gbnVsbDtcbiAgICB9XG4gICAgdXBkYXRlKHsgam91cm5leTogbnVsbCB9KTtcbiAgfSwgW3VwZGF0ZV0pO1xuXG4gIGNvbnN0IHBsYXlOZXh0ID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIGNvbnN0IGpyID0gc3RhdGVSZWYuY3VycmVudC5qb3VybmV5O1xuICAgIGlmICghanIpIHJldHVybjtcbiAgICBpZiAoaG9sZFRpbWVyLmN1cnJlbnQpIHtcbiAgICAgIGNsZWFyVGltZW91dChob2xkVGltZXIuY3VycmVudCk7XG4gICAgICBob2xkVGltZXIuY3VycmVudCA9IG51bGw7XG4gICAgfVxuICAgIGNvbnN0IGogPSBzdGF0ZVJlZi5jdXJyZW50LmpvdXJuZXlzLmZpbmQoKHgpID0+IHguaWQgPT09IGpyLmppZCk7XG4gICAgaWYgKCFqKSByZXR1cm47XG4gICAgY29uc3QgbmkgPSBqci5pZHggKyAxO1xuICAgIGlmIChuaSA+PSBqLnN0ZXBzLmxlbmd0aCkge1xuICAgICAgcGxheUV4aXQoKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdXBkYXRlKHsgam91cm5leTogeyAuLi5qciwgaWR4OiBuaSB9IH0pO1xuICAgIGdvU3RlcChqLCBuaSk7XG4gIH0sIFt1cGRhdGUsIGdvU3RlcCwgcGxheUV4aXRdKTtcbiAgLy8gS2VlcCB0aGUgZHdlbGwgdGltZXIncyBpbmRpcmVjdGlvbiBwb2ludGVkIGF0IHRoZSBjdXJyZW50IHBsYXlOZXh0LlxuICBwbGF5TmV4dFJlZi5jdXJyZW50ID0gcGxheU5leHQ7XG5cbiAgY29uc3QgcGxheVByZXYgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgY29uc3QganIgPSBzdGF0ZVJlZi5jdXJyZW50LmpvdXJuZXk7XG4gICAgaWYgKCFqcikgcmV0dXJuO1xuICAgIGlmIChob2xkVGltZXIuY3VycmVudCkge1xuICAgICAgY2xlYXJUaW1lb3V0KGhvbGRUaW1lci5jdXJyZW50KTtcbiAgICAgIGhvbGRUaW1lci5jdXJyZW50ID0gbnVsbDtcbiAgICB9XG4gICAgY29uc3QgaiA9IHN0YXRlUmVmLmN1cnJlbnQuam91cm5leXMuZmluZCgoeCkgPT4geC5pZCA9PT0ganIuamlkKTtcbiAgICBpZiAoIWopIHJldHVybjtcbiAgICBjb25zdCBuaSA9IE1hdGgubWF4KDAsIGpyLmlkeCAtIDEpO1xuICAgIHVwZGF0ZSh7IGpvdXJuZXk6IHsgLi4uanIsIGlkeDogbmkgfSB9KTtcbiAgICBnb1N0ZXAoaiwgbmkpO1xuICB9LCBbdXBkYXRlLCBnb1N0ZXBdKTtcblxuICBjb25zdCBwbGF5U2VlayA9IHVzZUNhbGxiYWNrKFxuICAgIChpZHg6IG51bWJlcikgPT4ge1xuICAgICAgY29uc3QganIgPSBzdGF0ZVJlZi5jdXJyZW50LmpvdXJuZXk7XG4gICAgICBpZiAoIWpyKSByZXR1cm47XG4gICAgICBpZiAoaG9sZFRpbWVyLmN1cnJlbnQpIHtcbiAgICAgICAgY2xlYXJUaW1lb3V0KGhvbGRUaW1lci5jdXJyZW50KTtcbiAgICAgICAgaG9sZFRpbWVyLmN1cnJlbnQgPSBudWxsO1xuICAgICAgfVxuICAgICAgY29uc3QgaiA9IHN0YXRlUmVmLmN1cnJlbnQuam91cm5leXMuZmluZCgoeCkgPT4geC5pZCA9PT0ganIuamlkKTtcbiAgICAgIGlmICghaikgcmV0dXJuO1xuICAgICAgdXBkYXRlKHsgam91cm5leTogeyAuLi5qciwgaWR4IH0gfSk7XG4gICAgICBnb1N0ZXAoaiwgaWR4KTtcbiAgICB9LFxuICAgIFt1cGRhdGUsIGdvU3RlcF0sXG4gICk7XG5cbiAgLy8gLS0tLSBtdXRhdGlvbnMgLS0tLVxuICBjb25zdCBwYXRjaFNlbCA9IHVzZUNhbGxiYWNrKFxuICAgIChwYXRjaDogUGFydGlhbDxXT2JqZWN0PikgPT4ge1xuICAgICAgdXBkYXRlKChzKSA9PiAoeyBvYmplY3RzOiBzLm9iamVjdHMubWFwKChvKSA9PiAocy5zZWxlY3Rpb24uaW5jbHVkZXMoby5pZCkgPyB7IC4uLm8sIC4uLnBhdGNoIH0gOiBvKSkgfSkpO1xuICAgICAgc2NoZWR1bGVTYXZlKHN0YXRlUmVmLmN1cnJlbnQuc2VsZWN0aW9uKTtcbiAgICB9LFxuICAgIFt1cGRhdGUsIHNjaGVkdWxlU2F2ZV0sXG4gICk7XG5cbiAgLy8gLS0tLSBzZWxlY3Rpb246IG9uZSBhY3Rpb24gZm9yIHBvaW50ZXIgYW5kIGtleWJvYXJkIChSMy02MDcpIC0tLS1cbiAgY29uc3Qgc2VsZWN0ID0gdXNlQ2FsbGJhY2soXG4gICAgKGlkOiBzdHJpbmcsIGFkZGl0aXZlID0gZmFsc2UpID0+IHtcbiAgICAgIHVwZGF0ZSgocykgPT4gKHtcbiAgICAgICAgc2VsZWN0aW9uOiBhcHBseVNlbGVjdGlvbihzLnNlbGVjdGlvbiwgaWQsIGFkZGl0aXZlKSxcbiAgICAgICAgaW5zcGVjdG9yT3BlbjogdHJ1ZSxcbiAgICAgICAgcXVpY2tNZW51OiBudWxsLFxuICAgICAgfSkpO1xuICAgIH0sXG4gICAgW3VwZGF0ZV0sXG4gICk7XG5cbiAgLyoqIENsb3NlIHRoZSBxdWljay1jcmVhdGUgbWVudSAoaXRzIEVzY2FwZS9ibHVyIHBhdGgsIFIzLTYwNykuICovXG4gIGNvbnN0IGNsb3NlUXVpY2tNZW51ID0gdXNlQ2FsbGJhY2soKCkgPT4gdXBkYXRlKHsgcXVpY2tNZW51OiBudWxsIH0pLCBbdXBkYXRlXSk7XG5cbiAgY29uc3QgZGVsZXRlU2VsZWN0aW9uID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIGNvbnN0IHNlbCA9IHN0YXRlUmVmLmN1cnJlbnQuc2VsZWN0aW9uLnNsaWNlKCk7XG4gICAgaWYgKCFzZWwubGVuZ3RoKSByZXR1cm47XG4gICAgY29uc3QgcmVtb3ZlZCA9IHN0YXRlUmVmLmN1cnJlbnQub2JqZWN0cy5maWx0ZXIoKG8pID0+IHNlbC5pbmNsdWRlcyhvLmlkKSk7XG4gICAgdXBkYXRlKChzKSA9PiAoeyBvYmplY3RzOiBzLm9iamVjdHMuZmlsdGVyKChvKSA9PiAhc2VsLmluY2x1ZGVzKG8uaWQpKSwgc2VsZWN0aW9uOiBbXSB9KSk7XG4gICAgLy8gRGVsZXRlIGlzIGEgcmVuYW1lIGludG8gb2JqZWN0cy8udHJhc2gvIHdpdGggYSAxMHMgdW5kbyAoc3BlYyDCpzQuMikuXG4gICAgY29uc3QgdCA9IGJvYXJkUmVmLmN1cnJlbnQ7XG4gICAgaWYgKHQgJiYgdC5tb2RlICE9PSAncm8nKSB7XG4gICAgICBQcm9taXNlLmFsbChzZWwubWFwKChpZCkgPT4gdHJhc2hPYmplY3QodCwgaWQpKSkuY2F0Y2goKGUpID0+XG4gICAgICAgIHRvYXN0KGBEZWxldGUgZmFpbGVkJHtjb2RlT2YoZSl9YCwgJ2FsZXJ0JywgeyBpY29uQ29sb3I6ICcjY2FhMjRhJyB9KSxcbiAgICAgICk7XG4gICAgfVxuICAgIHRvYXN0KGAke3NlbC5sZW5ndGggPiAxID8gYCR7c2VsLmxlbmd0aH0gb2JqZWN0c2AgOiAnT2JqZWN0J30gbW92ZWQgdG8gLnRyYXNoYCwgJ3RyYXNoJywge1xuICAgICAgYWN0aW9uTGFiZWw6ICdVbmRvJyxcbiAgICAgIG9uQWN0aW9uOiAoKSA9PiB7XG4gICAgICAgIHVwZGF0ZSgocykgPT4gKHsgb2JqZWN0czogcy5vYmplY3RzLmNvbmNhdChyZW1vdmVkKSB9KSk7XG4gICAgICAgIGlmICh0ICYmIHQubW9kZSAhPT0gJ3JvJykge1xuICAgICAgICAgIFByb21pc2UuYWxsKHJlbW92ZWQubWFwKChvKSA9PiByZXN0b3JlT2JqZWN0KHQsIG8uaWQpKSkuY2F0Y2goKCkgPT4gdW5kZWZpbmVkKTtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICB9KTtcbiAgfSwgW3VwZGF0ZSwgdG9hc3RdKTtcblxuICBjb25zdCBjcmVhdGVPYmplY3QgPSB1c2VDYWxsYmFjayhcbiAgICAoa2luZDogT2JqZWN0S2luZCwgd3g6IG51bWJlciwgd3k6IG51bWJlcikgPT4ge1xuICAgICAgY29uc3QgbzogV09iamVjdCA9IHtcbiAgICAgICAgaWQ6IGdlbmVyYXRlSWQoa2luZCA9PT0gJ25vdGUnID8gJ25vdGUnIDoga2luZCksXG4gICAgICAgIGtpbmQsXG4gICAgICAgIHg6IHd4IC0gMTAwLFxuICAgICAgICB5OiB3eSAtIDc0LFxuICAgICAgICB3OiAyMDAsXG4gICAgICAgIGg6IDE0OCxcbiAgICAgICAgcm90OiAwLFxuICAgICAgICBzY2FsZTogMSxcbiAgICAgICAgejogMyxcbiAgICAgICAgY29ubmVjdGlvbnM6IFtdLFxuICAgICAgfTtcbiAgICAgIGlmIChraW5kID09PSAnbm90ZScpIHtcbiAgICAgICAgby5jb2xvciA9ICdsZW1vbic7XG4gICAgICAgIG8udGl0bGUgPSAnTmV3IG5vdGUnO1xuICAgICAgfSBlbHNlIGlmIChraW5kID09PSAncHJvc2UnKSB7XG4gICAgICAgIG8udGl0bGUgPSAnUHJvc2UnO1xuICAgICAgICBvLmJvZHkgPSAnV3JpdGUgaGVyZeKApic7XG4gICAgICAgIG8udyA9IDI2MDtcbiAgICAgICAgby5oID0gMTYwO1xuICAgICAgfSBlbHNlIGlmIChraW5kID09PSAnbGFiZWwnKSB7XG4gICAgICAgIG8udGl0bGUgPSAnTGFiZWwnO1xuICAgICAgICBvLncgPSAzMjA7XG4gICAgICAgIG8uaCA9IDgwO1xuICAgICAgICBvLnogPSAxO1xuICAgICAgfSBlbHNlIGlmIChraW5kID09PSAnc2hhcGUnKSB7XG4gICAgICAgIG8uc2hhcGUgPSAncmVjdCc7XG4gICAgICAgIG8udGl0bGUgPSAnJztcbiAgICAgICAgby53ID0gMjAwO1xuICAgICAgICBvLmggPSAxNDA7XG4gICAgICB9IGVsc2UgaWYgKGtpbmQgPT09ICdmcmFtZScpIHtcbiAgICAgICAgby50aXRsZSA9ICdGcmFtZSc7XG4gICAgICAgIG8udyA9IDM2MDtcbiAgICAgICAgby5oID0gMzAwO1xuICAgICAgICBvLnogPSAxO1xuICAgICAgfSBlbHNlIGlmIChraW5kID09PSAnaW1nJykge1xuICAgICAgICBvLmxvYWRlZCA9IGZhbHNlO1xuICAgICAgICBvLnRpdGxlID0gJ0ltYWdlJztcbiAgICAgIH0gZWxzZSBpZiAoa2luZCA9PT0gJ2NvbXBvbmVudCcpIHtcbiAgICAgICAgby50aXRsZSA9ICc8Q29tcG9uZW50Lz4nO1xuICAgICAgfVxuICAgICAgdXBkYXRlKChzKSA9PiAoe1xuICAgICAgICBvYmplY3RzOiBzLm9iamVjdHMuY29uY2F0KG8pLFxuICAgICAgICBzZWxlY3Rpb246IFtvLmlkXSxcbiAgICAgICAgcXVpY2tNZW51OiBudWxsLFxuICAgICAgICBpbnNwZWN0b3JPcGVuOiB0cnVlLFxuICAgICAgICBtb2RlOiAnZWRpdCcsXG4gICAgICB9KSk7XG4gICAgICBjb21taXRTYXZlKFtvXSwgYENyZWF0ZWQgb2JqZWN0cy8ke28uaWR9Lm1keGAsICdwbHVzJyk7XG4gICAgfSxcbiAgICBbdXBkYXRlLCBjb21taXRTYXZlXSxcbiAgKTtcblxuICAvLyDilIDilIAgcGljay1maWxlIGZsb3dzIChzcGVjIMKnNi4xIE9wZW4vTmV3IGJvYXJkLCDCpzQuMiBJbnNlcnQgaW1hZ2UpIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAvLyBFYWNoIGludm9rZXMgdGhlIHBsYXRmb3JtIHBpY2tlciBvdmVyIGEgYGNhcERpcmAgb2YgdGhlIGJvYXJkJ3Mgc3BhY2UgKHRoZVxuICAvLyBvbmx5IGF1dGhvcml0eSB3ZSBob2xkKSwgdGhlbiBtYXBzIHRoZSByZXR1cm5lZCBgKHJvb3QsIHJlbFBhdGgpYCBQQVRIIGJhY2tcbiAgLy8gb250byBvdXIgT1dOIG1vdW50IOKAlCByZS12YWxpZGF0aW5nIGl0IGZpcnN0IChkZWZlbnNlIGluIGRlcHRoLCDCpzEuMykuXG5cbiAgLyoqIEluc2VydCBhbiBpbWFnZTogcGljayBhIGZpbGUsIGNvcHkgaXQgaW50byB0aGUgYm9hcmQncyBgYXNzZXRzL2AsIGRyb3AgYW5cbiAgICogIDxJbWc+IG9iamVjdCBhdCB0aGUgd29ybGQgcG9pbnQuIFNlbGYtY29udGFpbmVkIHBlciDCpzQuMi4gVGhlIHBpY2sgaXNcbiAgICogIG5hbWVkLWJ1c3kgb24gdGhlIGNvbmZpcm1pbmcgY29udHJvbCB1bnRpbCBpdCBzZXR0bGVzIChSLUlYLTIpLiAqL1xuICBjb25zdCBpbnNlcnRJbWFnZSA9IHVzZUNhbGxiYWNrKFxuICAgIGFzeW5jICh3eDogbnVtYmVyLCB3eTogbnVtYmVyKSA9PiB7XG4gICAgICBjb25zdCB0YXJnZXQgPSBib2FyZFJlZi5jdXJyZW50O1xuICAgICAgaWYgKCF0YXJnZXQpIHtcbiAgICAgICAgdG9hc3QoJ1NpZ24gaW4gdG8gaW5zZXJ0IGltYWdlcyBpbnRvIHlvdXIgYm9hcmQuJywgJ3NhdmUnLCB7IGljb25Db2xvcjogJ3ZhcigtLWluay0yKScgfSk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIHVwZGF0ZSh7IGJ1c3k6ICdpbnNlcnQtaW1hZ2UnIH0pO1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgcGlja0ZpbGUoe1xuICAgICAgICAgIG1vZGU6ICdvcGVuLWZpbGUnLFxuICAgICAgICAgIHJvb3RzOiBbYXdhaXQgYm9hcmRTcGFjZVJvb3QodGFyZ2V0KV0sXG4gICAgICAgICAgcm9vdExhYmVsczogWydUaGlzIGJvYXJk4oCZcyBzcGFjZSddLFxuICAgICAgICAgIHJvb3RNb2RlczogW3RhcmdldC5tb2RlXSxcbiAgICAgICAgICB0aXRsZTogJ0luc2VydCBpbWFnZScsXG4gICAgICAgICAgZmlsdGVyczogW1xuICAgICAgICAgICAgeyBsYWJlbDogJ0ltYWdlcycsIGV4dGVuc2lvbnM6IFsnLnBuZycsICcuanBnJywgJy5qcGVnJywgJy5naWYnLCAnLndlYnAnLCAnLnN2ZycsICcuYXZpZiddIH0sXG4gICAgICAgICAgICB7IGxhYmVsOiAnQWxsIGZpbGVzJywgZXh0ZW5zaW9uczogW10gfSxcbiAgICAgICAgICBdLFxuICAgICAgICB9KTtcbiAgICAgICAgaWYgKCFyZXMpIHJldHVybjsgLy8gY2FuY2VsbGVkIOKAlCBubyB0b2FzdCBzcGFtXG4gICAgICAgIGNvbnN0IHJlbCA9IHNhZmVSZWwocmVzLnJlbFBhdGgpO1xuICAgICAgICBpZiAoIXJlbCkge1xuICAgICAgICAgIHRvYXN0KCdUaGF0IGZpbGUgY2Fu4oCZdCBiZSBpbnNlcnRlZC4nLCAnYWxlcnQnLCB7IGljb25Db2xvcjogJyNjYWEyNGEnIH0pO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBuYW1lID0gYXdhaXQgY29weUludG9Bc3NldHModGFyZ2V0LCByZWwpO1xuICAgICAgICBjb25zdCBvOiBXT2JqZWN0ID0ge1xuICAgICAgICAgIGlkOiBnZW5lcmF0ZUlkKCdpbWcnKSxcbiAgICAgICAgICBraW5kOiAnaW1nJyxcbiAgICAgICAgICB4OiB3eCAtIDEzMCxcbiAgICAgICAgICB5OiB3eSAtIDkwLFxuICAgICAgICAgIHc6IDI2MCxcbiAgICAgICAgICBoOiAxODAsXG4gICAgICAgICAgcm90OiAwLFxuICAgICAgICAgIHNjYWxlOiAxLFxuICAgICAgICAgIHo6IDMsXG4gICAgICAgICAgdGl0bGU6IG5hbWUsXG4gICAgICAgICAgYm9keTogYDxJbWcgc3JjPVwiYXNzZXRzLyR7bmFtZX1cIiAvPmAsXG4gICAgICAgICAgbG9hZGVkOiB0cnVlLFxuICAgICAgICAgIGNvbm5lY3Rpb25zOiBbXSxcbiAgICAgICAgfTtcbiAgICAgICAgdXBkYXRlKChzKSA9PiAoe1xuICAgICAgICAgIG9iamVjdHM6IHMub2JqZWN0cy5jb25jYXQobyksXG4gICAgICAgICAgc2VsZWN0aW9uOiBbby5pZF0sXG4gICAgICAgICAgcXVpY2tNZW51OiBudWxsLFxuICAgICAgICAgIGluc3BlY3Rvck9wZW46IHRydWUsXG4gICAgICAgICAgbW9kZTogJ2VkaXQnLFxuICAgICAgICAgIHNjcmVlbjogbnVsbCxcbiAgICAgICAgfSkpO1xuICAgICAgICBjb21taXRTYXZlKFtvXSwgYEluc2VydGVkIGFzc2V0cy8ke25hbWV9YCwgJ2ltYWdlJyk7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIHRvYXN0KGBDb3VsZG7igJl0IGluc2VydCBpbWFnZSR7Y29kZU9mKGUpfWAsICdhbGVydCcsIHsgaWNvbkNvbG9yOiAnI2NhYTI0YScgfSk7XG4gICAgICB9IGZpbmFsbHkge1xuICAgICAgICB1cGRhdGUoeyBidXN5OiBudWxsIH0pO1xuICAgICAgfVxuICAgIH0sXG4gICAgW3RvYXN0LCB1cGRhdGUsIGNvbW1pdFNhdmVdLFxuICApO1xuXG4gIC8qKiBSZS1wb2ludCB0aGUgYWN0aXZlIGJvYXJkIHRvIGB0YXJnZXRgIGFuZCBoeWRyYXRlIHRoZSBjYW52YXMgZnJvbSBpdC4gKi9cbiAgY29uc3QgbG9hZEJvYXJkSW50byA9IHVzZUNhbGxiYWNrKFxuICAgIGFzeW5jICh0YXJnZXQ6IEJvYXJkVGFyZ2V0KSA9PiB7XG4gICAgICBjb25zdCBib2FyZCA9IGF3YWl0IGxvYWRCb2FyZCh0YXJnZXQpO1xuICAgICAgYm9hcmRSZWYuY3VycmVudCA9IHRhcmdldDtcbiAgICAgIC8vIFRoZSBib2FyZC5tZCBtYW5pZmVzdCBuYW1lcyB0aGUgYm9hcmQgKHNwZWMgwqcyLjQpIOKAlCBhIGJvYXJkIGlzIGEgZm9sZGVyXG4gICAgICAvLyB0aGF0IGNhbiBzdGF0ZSBpdHMgb3duIG5hbWU7IGZhbGwgYmFjayB0byB0aGUgc2VlZCBvbmx5IHdoZW4gYWJzZW50LlxuICAgICAgLy8gQSBtYW5pZmVzdCBzY2hlbWEgbmV3ZXIgdGhhbiB0aGlzIHJlYWRlciBtYXJrcyB0aGUgYm9hcmQgcmVhZG9ubHkgKHRoZVxuICAgICAgLy8gYHJlYWRvbmx5YCBkZWdyYWRlZCBzdGF0ZSksIHVubGVzcyB0aGUgbW91bnQgaXRzZWxmIGlzIGFscmVhZHkgcm8uXG4gICAgICBjb25zdCByZWFkb25seSA9IHRhcmdldC5tb2RlID09PSAncm8nIHx8ICh0eXBlb2YgYm9hcmQuc2NoZW1hID09PSAnbnVtYmVyJyAmJiBib2FyZC5zY2hlbWEgPiBTVVBQT1JURURfU0NIRU1BKTtcbiAgICAgIHVwZGF0ZSh7XG4gICAgICAgIG9iamVjdHM6IGJvYXJkLm9iamVjdHMsXG4gICAgICAgIHZpZXdzOiBib2FyZC52aWV3cy5sZW5ndGggPyBib2FyZC52aWV3cyA6IFNFRURfVklFV1Muc2xpY2UoKSxcbiAgICAgICAgam91cm5leXM6IGJvYXJkLmpvdXJuZXlzLmxlbmd0aCA/IGJvYXJkLmpvdXJuZXlzIDogU0VFRF9KT1VSTkVZUyxcbiAgICAgICAgYmc6IGJvYXJkLmJhY2tncm91bmQgPz8gc3RhdGVSZWYuY3VycmVudC5iZyxcbiAgICAgICAgdGl0bGU6IGJvYXJkLnRpdGxlID8/IHN0YXRlUmVmLmN1cnJlbnQudGl0bGUsXG4gICAgICAgIG1vZGU6IHJlYWRvbmx5ID8gJ3J1bicgOiBzdGF0ZVJlZi5jdXJyZW50Lm1vZGUsXG4gICAgICAgIHNlbGVjdGlvbjogW10sXG4gICAgICAgIC8vIEEga2V5Ym9hcmQgY29ubmVjdCBhcm1lZCBhZ2FpbnN0IHRoZSBwcmV2aW91cyBib2FyZCBtdXN0IG5vdCBzdXJ2aXZlXG4gICAgICAgIC8vIHRoZSBzd2FwIChSMy02MDcgcmV2aWV3KTogaXRzIHNvdXJjZSBpZCBpcyBzdGFsZSB0aGUgbW9tZW50IG9iamVjdHNcbiAgICAgICAgLy8gYXJlIHJlcGxhY2VkLlxuICAgICAgICBjb25uZWN0RnJvbTogbnVsbCxcbiAgICAgICAgY29ubmVjdEN1cnNvcjogbnVsbCxcbiAgICAgICAgaW5zcGVjdG9yT3BlbjogZmFsc2UsXG4gICAgICAgIHNjcmVlbjogbnVsbCxcbiAgICAgIH0pO1xuICAgIH0sXG4gICAgW3VwZGF0ZV0sXG4gICk7XG5cbiAgLyoqIE9wZW4gYW4gZXhpc3RpbmcgYm9hcmQgZm9sZGVyIGluIGBzcGFjZWA6IHBpY2sgYSBmb2xkZXIsIHJlcXVpcmUgYSBib2FyZC5tZCxcbiAgICogIHRoZW4gbG9hZCBpdCBhcyB0aGUgYWN0aXZlIGJvYXJkLiBOYW1lZC1idXN5IHdoaWxlIHRoZSBwaWNrIGlzIG91dC4gKi9cbiAgY29uc3Qgb3BlbkJvYXJkSW4gPSB1c2VDYWxsYmFjayhcbiAgICBhc3luYyAoc3BhY2U6IEJvYXJkVGFyZ2V0KSA9PiB7XG4gICAgICB1cGRhdGUoeyBidXN5OiAnb3Blbi1ib2FyZCcgfSk7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBwaWNrRmlsZSh7XG4gICAgICAgICAgbW9kZTogJ29wZW4tZm9sZGVyJyxcbiAgICAgICAgICByb290czogW2F3YWl0IGJvYXJkU3BhY2VSb290KHNwYWNlKV0sXG4gICAgICAgICAgcm9vdExhYmVsczogWydZb3VyIGJvYXJkIHNwYWNlJ10sXG4gICAgICAgICAgcm9vdE1vZGVzOiBbc3BhY2UubW9kZV0sXG4gICAgICAgICAgdGl0bGU6ICdPcGVuIGJvYXJkJyxcbiAgICAgICAgfSk7XG4gICAgICAgIGlmICghcmVzKSByZXR1cm47XG4gICAgICAgIGNvbnN0IHJlbCA9IHNhZmVSZWwocmVzLnJlbFBhdGgpO1xuICAgICAgICBpZiAoIXJlbCkge1xuICAgICAgICAgIHRvYXN0KCdUaGF0IGZvbGRlciBjYW7igJl0IGJlIG9wZW5lZC4nLCAnYWxlcnQnLCB7IGljb25Db2xvcjogJyNjYWEyNGEnIH0pO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBjYW5kaWRhdGU6IEJvYXJkVGFyZ2V0ID0geyByb290OiBzdWJQYXRoKHNwYWNlLnJvb3QsIHJlbCksIG1vZGU6IHNwYWNlLm1vZGUsIHNwYWNlSWQ6IHNwYWNlLnNwYWNlSWQgfTtcbiAgICAgICAgaWYgKCEoYXdhaXQgZm9sZGVySXNCb2FyZChjYW5kaWRhdGUpKSAmJiAhKGF3YWl0IGJvYXJkRXhpc3RzKGNhbmRpZGF0ZSkpKSB7XG4gICAgICAgICAgdG9hc3QoJ1RoYXQgZm9sZGVyIGlzbuKAmXQgYSBib2FyZCAobm8gYm9hcmQubWQpLiBPcGVuIGZvbGRlciBhZ2FpbiB0byBwaWNrIGFub3RoZXIuJywgJ2FsZXJ0Jywge1xuICAgICAgICAgICAgaWNvbkNvbG9yOiAnI2NhYTI0YScsXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGF3YWl0IGxvYWRCb2FyZEludG8oY2FuZGlkYXRlKTtcbiAgICAgICAgdG9hc3QoJ0JvYXJkIG9wZW5lZC4nLCAnY2hlY2snKTtcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgdG9hc3QoYENvdWxkbuKAmXQgb3BlbiBib2FyZCR7Y29kZU9mKGUpfWAsICdhbGVydCcsIHsgaWNvbkNvbG9yOiAnI2NhYTI0YScgfSk7XG4gICAgICB9IGZpbmFsbHkge1xuICAgICAgICB1cGRhdGUoeyBidXN5OiBudWxsIH0pO1xuICAgICAgfVxuICAgIH0sXG4gICAgW3RvYXN0LCB1cGRhdGUsIGxvYWRCb2FyZEludG9dLFxuICApO1xuXG4gIC8qKiBPcGVuIGEgU1BFQ0lGSUMgYm9hcmQgZGlyZWN0b3J5IGRpcmVjdGx5ICh0aGUgY2hvb3NlcidzIHJvd3MsIFIzLTYwNyk6XG4gICAqICBubyBwaWNrZXIg4oCUIHRoZSBjYWxsZXIgYWxyZWFkeSBrbm93cyB0aGUgZm9sZGVyIChpdCBsaXN0ZWQgaXQpLiBMb2Fkc1xuICAgKiAgdGhyb3VnaCB0aGUgc2FtZSBgbG9hZEJvYXJkSW50b2AgZXZlcnkgb3BlbiBwYXRoIGZ1bm5lbHMgaW50by4gKi9cbiAgY29uc3Qgb3BlbkJvYXJkQXQgPSB1c2VDYWxsYmFjayhcbiAgICBhc3luYyAodGFyZ2V0OiBCb2FyZFRhcmdldCkgPT4ge1xuICAgICAgdXBkYXRlKHsgYnVzeTogJ29wZW4tYm9hcmQnIH0pO1xuICAgICAgdHJ5IHtcbiAgICAgICAgYXdhaXQgbG9hZEJvYXJkSW50byh0YXJnZXQpO1xuICAgICAgICB0b2FzdCgnQm9hcmQgb3BlbmVkLicsICdjaGVjaycpO1xuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICB0b2FzdChgQ291bGRu4oCZdCBvcGVuIGJvYXJkJHtjb2RlT2YoZSl9YCwgJ2FsZXJ0JywgeyBpY29uQ29sb3I6ICcjY2FhMjRhJyB9KTtcbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIHVwZGF0ZSh7IGJ1c3k6IG51bGwgfSk7XG4gICAgICB9XG4gICAgfSxcbiAgICBbdG9hc3QsIHVwZGF0ZSwgbG9hZEJvYXJkSW50b10sXG4gICk7XG5cbiAgLyoqIE5ldyBib2FyZDogcGljayAob3IgY3JlYXRlKSBhIGZvbGRlciBpbiBgc3BhY2VgLCBzY2FmZm9sZCBib2FyZC5tZCwgb3BlbiBpdC5cbiAgICogIE5hbWVkLWJ1c3kgd2hpbGUgdGhlIHBpY2sgaXMgb3V0LiAqL1xuICBjb25zdCBuZXdCb2FyZEluID0gdXNlQ2FsbGJhY2soXG4gICAgYXN5bmMgKHNwYWNlOiBCb2FyZFRhcmdldCkgPT4ge1xuICAgICAgaWYgKHNwYWNlLm1vZGUgPT09ICdybycpIHtcbiAgICAgICAgdG9hc3QoJ1RoYXQgc3BhY2UgaXMgcmVhZC1vbmx5IOKAlCB5b3UgY2Fu4oCZdCBjcmVhdGUgYSBib2FyZCB0aGVyZS4nLCAnbG9jaycsIHsgaWNvbkNvbG9yOiAndmFyKC0taW5rLTIpJyB9KTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgdXBkYXRlKHsgYnVzeTogJ25ldy1ib2FyZCcgfSk7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBwaWNrRmlsZSh7XG4gICAgICAgICAgbW9kZTogJ29wZW4tZm9sZGVyJyxcbiAgICAgICAgICByb290czogW2F3YWl0IGJvYXJkU3BhY2VSb290KHNwYWNlKV0sXG4gICAgICAgICAgcm9vdExhYmVsczogWydZb3VyIGJvYXJkIHNwYWNlJ10sXG4gICAgICAgICAgcm9vdE1vZGVzOiBbc3BhY2UubW9kZV0sXG4gICAgICAgICAgdGl0bGU6ICdOZXcgYm9hcmQgwrcgY2hvb3NlIGEgZm9sZGVyJyxcbiAgICAgICAgICBhbGxvd0NyZWF0ZUZvbGRlcjogdHJ1ZSxcbiAgICAgICAgfSk7XG4gICAgICAgIGlmICghcmVzKSByZXR1cm47XG4gICAgICAgIGNvbnN0IHJlbCA9IHNhZmVSZWwocmVzLnJlbFBhdGgpO1xuICAgICAgICBpZiAoIXJlbCkge1xuICAgICAgICAgIHRvYXN0KCdUaGF0IGZvbGRlciBjYW7igJl0IGJlIHVzZWQuJywgJ2FsZXJ0JywgeyBpY29uQ29sb3I6ICcjY2FhMjRhJyB9KTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgY2FuZGlkYXRlOiBCb2FyZFRhcmdldCA9IHsgcm9vdDogc3ViUGF0aChzcGFjZS5yb290LCByZWwpLCBtb2RlOiAncncnLCBzcGFjZUlkOiBzcGFjZS5zcGFjZUlkIH07XG4gICAgICAgIGNvbnN0IHRpdGxlID0gcmVsLnNwbGl0KCcvJykucG9wKCkgfHwgJ1VudGl0bGVkIGJvYXJkJztcbiAgICAgICAgYXdhaXQgd3JpdGVOZXdCb2FyZChjYW5kaWRhdGUsIHRpdGxlKTtcbiAgICAgICAgYXdhaXQgbG9hZEJvYXJkSW50byhjYW5kaWRhdGUpO1xuICAgICAgICB0b2FzdCgnQm9hcmQgY3JlYXRlZC4nLCAnY2hlY2snKTtcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgdG9hc3QoYENvdWxkbuKAmXQgY3JlYXRlIGJvYXJkJHtjb2RlT2YoZSl9YCwgJ2FsZXJ0JywgeyBpY29uQ29sb3I6ICcjY2FhMjRhJyB9KTtcbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIHVwZGF0ZSh7IGJ1c3k6IG51bGwgfSk7XG4gICAgICB9XG4gICAgfSxcbiAgICBbdG9hc3QsIHVwZGF0ZSwgbG9hZEJvYXJkSW50b10sXG4gICk7XG5cbiAgLyoqIE9wZW4gLyBuZXcgYm9hcmQgYWdhaW5zdCB0aGUgQ1VSUkVOVCBib2FyZCBzcGFjZSAodGhlIGNob29zZXIncyBmb290ZXIpLiAqL1xuICBjb25zdCBvcGVuQm9hcmQgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgY29uc3Qgc3BhY2UgPSBib2FyZFJlZi5jdXJyZW50O1xuICAgIGlmICghc3BhY2UpIHtcbiAgICAgIHRvYXN0KCdTaWduIGluIHRvIG9wZW4gYSBib2FyZCBmcm9tIHlvdXIgc3BhY2UuJywgJ3NhdmUnLCB7IGljb25Db2xvcjogJ3ZhcigtLWluay0yKScgfSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHZvaWQgb3BlbkJvYXJkSW4oc3BhY2UpO1xuICB9LCBbdG9hc3QsIG9wZW5Cb2FyZEluXSk7XG5cbiAgY29uc3QgbmV3Qm9hcmQgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgY29uc3Qgc3BhY2UgPSBib2FyZFJlZi5jdXJyZW50O1xuICAgIGlmICghc3BhY2UpIHtcbiAgICAgIHRvYXN0KCdTaWduIGluIHRvIGNyZWF0ZSBhIGJvYXJkIGluIHlvdXIgc3BhY2UuJywgJ3NhdmUnLCB7IGljb25Db2xvcjogJ3ZhcigtLWluay0yKScgfSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHZvaWQgbmV3Qm9hcmRJbihzcGFjZSk7XG4gIH0sIFt0b2FzdCwgbmV3Qm9hcmRJbl0pO1xuXG4gIC8qKiBcIkFkZCBhIHNwYWNlXCI6IHRoZSBob3N0IHBvd2VyYm94IGdyYW50cyBhIE5FVyBzcGFjZSAobmV2ZXIgdGhpcyBhcHAsIMKnMiksXG4gICAqICB0aGVuIHdlIG9mZmVyIHRvIG9wZW4gYSBib2FyZCBpbiBpdC4gKi9cbiAgY29uc3QgYWRkU3BhY2UgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGdyYW50ZWQgPSBhd2FpdCByZXF1ZXN0U3BhY2UoKTtcbiAgICAgIGlmICghZ3JhbnRlZCkgcmV0dXJuOyAvLyBjYW5jZWxsZWRcbiAgICAgIGNvbnN0IHNwYWNlOiBCb2FyZFRhcmdldCA9IHsgcm9vdDogZ3JhbnRlZC5wYXRoLCBtb2RlOiBncmFudGVkLm1vZGUsIHNwYWNlSWQ6IGdyYW50ZWQuaWQgfTtcbiAgICAgIGF3YWl0IG9wZW5Cb2FyZEluKHNwYWNlKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICB0b2FzdChgQ291bGRu4oCZdCBhZGQgYSBzcGFjZSR7Y29kZU9mKGUpfWAsICdhbGVydCcsIHsgaWNvbkNvbG9yOiAnI2NhYTI0YScgfSk7XG4gICAgfVxuICB9LCBbdG9hc3QsIG9wZW5Cb2FyZEluXSk7XG5cbiAgY29uc3QgcGF0Y2hPYmplY3QgPSB1c2VDYWxsYmFjayhcbiAgICAoaWQ6IHN0cmluZywgcGF0Y2g6IFBhcnRpYWw8V09iamVjdD4pID0+IHtcbiAgICAgIHVwZGF0ZSgocykgPT4gKHsgb2JqZWN0czogcy5vYmplY3RzLm1hcCgobykgPT4gKG8uaWQgPT09IGlkID8geyAuLi5vLCAuLi5wYXRjaCB9IDogbykpIH0pKTtcbiAgICAgIHNjaGVkdWxlU2F2ZShbaWRdKTtcbiAgICB9LFxuICAgIFt1cGRhdGUsIHNjaGVkdWxlU2F2ZV0sXG4gICk7XG5cbiAgY29uc3QgYWRkQ29ubmVjdGlvbiA9IHVzZUNhbGxiYWNrKFxuICAgIChmcm9tOiBzdHJpbmcsIHRvOiBzdHJpbmcpID0+IHtcbiAgICAgIGNvbnN0IGM6IENvbm5lY3Rpb24gPSB7IHRvLCBraW5kOiAnYXJyb3cnLCBzdHlsZTogeyBzdHJva2U6ICdhY2NlbnQnLCBkYXNoOiBmYWxzZSB9IH07XG4gICAgICBjb25zdCBzcmMgPSBzdGF0ZVJlZi5jdXJyZW50Lm9iamVjdHMuZmluZCgobykgPT4gby5pZCA9PT0gZnJvbSk7XG4gICAgICBjb25zdCB1cGRhdGVkID0gc3JjID8geyAuLi5zcmMsIGNvbm5lY3Rpb25zOiBzcmMuY29ubmVjdGlvbnMuY29uY2F0KGMpIH0gOiBudWxsO1xuICAgICAgdXBkYXRlKChzKSA9PiAoeyBvYmplY3RzOiBzLm9iamVjdHMubWFwKChvKSA9PiAoby5pZCA9PT0gZnJvbSA/IHsgLi4ubywgY29ubmVjdGlvbnM6IG8uY29ubmVjdGlvbnMuY29uY2F0KGMpIH0gOiBvKSkgfSkpO1xuICAgICAgaWYgKHVwZGF0ZWQpIGNvbW1pdFNhdmUoW3VwZGF0ZWRdLCBgQ29ubmVjdGVkICR7ZnJvbX0g4oaSICR7dG99YCk7XG4gICAgfSxcbiAgICBbdXBkYXRlLCBjb21taXRTYXZlXSxcbiAgKTtcblxuICAvLyAtLS0tIGtleWJvYXJkIGNvbm5lY3QgKHRoZSBub24tZHJhZyBwYXRoIHRvIGFuIGVkZ2UsIFIzLTYwNyAvIDIuNS43KSAtLS0tXG4gIC8qKiBFbnRlciBjb25uZWN0LWZyb20gb24gdGhlIHNlbGVjdGVkIG9iamVjdDsgdGhlIGN1cnNvciBzdGFydHMgb24gdGhlIGZpcnN0XG4gICAqICBvdGhlciBvYmplY3QgaW4gc3RhY2tpbmcgb3JkZXIuIEFycm93cyB0aGVuIHdhbGsgdGhlIGN1cnNvciAodGhlIG92ZXJsYXlcbiAgICogIGRyYXdzIGl0KSwgRW50ZXIgY29tbWl0cyB0aHJvdWdoIHRoZSBzYW1lIGFkZENvbm5lY3Rpb24gdGhlIGRyYWcgY2FsbHMsXG4gICAqICBFc2NhcGUgY2FuY2Vscy4gKi9cbiAgY29uc3QgYmVnaW5Db25uZWN0ID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIGNvbnN0IHMgPSBzdGF0ZVJlZi5jdXJyZW50O1xuICAgIGlmIChzLnNlbGVjdGlvbi5sZW5ndGggIT09IDEpIHJldHVybjtcbiAgICBjb25zdCBmcm9tID0gcy5zZWxlY3Rpb25bMF07XG4gICAgY29uc3Qgb3JkZXIgPSBzLm9iamVjdHMuc2xpY2UoKS5zb3J0KChhLCBiKSA9PiAoYS56IHx8IDApIC0gKGIueiB8fCAwKSkubWFwKChvKSA9PiBvLmlkKS5maWx0ZXIoKGlkKSA9PiBpZCAhPT0gZnJvbSk7XG4gICAgdXBkYXRlKHsgY29ubmVjdEZyb206IGZyb20sIGNvbm5lY3RDdXJzb3I6IG9yZGVyWzBdID8/IG51bGwsIGluc3BlY3Rvck9wZW46IGZhbHNlIH0pO1xuICB9LCBbdXBkYXRlXSk7XG5cbiAgY29uc3QgZW5kQ29ubmVjdCA9IHVzZUNhbGxiYWNrKFxuICAgIChjb21taXQ6IGJvb2xlYW4pID0+IHtcbiAgICAgIGNvbnN0IHMgPSBzdGF0ZVJlZi5jdXJyZW50O1xuICAgICAgaWYgKCFzLmNvbm5lY3RGcm9tKSByZXR1cm47XG4gICAgICBpZiAoY29tbWl0ICYmIHMuY29ubmVjdEN1cnNvcikgYWRkQ29ubmVjdGlvbihzLmNvbm5lY3RGcm9tLCBzLmNvbm5lY3RDdXJzb3IpO1xuICAgICAgdXBkYXRlKHsgY29ubmVjdEZyb206IG51bGwsIGNvbm5lY3RDdXJzb3I6IG51bGwgfSk7XG4gICAgfSxcbiAgICBbdXBkYXRlLCBhZGRDb25uZWN0aW9uXSxcbiAgKTtcblxuICBjb25zdCBtb3ZlQ29ubmVjdEN1cnNvciA9IHVzZUNhbGxiYWNrKFxuICAgIChkaXI6IC0xIHwgMSkgPT4ge1xuICAgICAgdXBkYXRlKChzKSA9PiB7XG4gICAgICAgIGlmICghcy5jb25uZWN0RnJvbSkgcmV0dXJuIHt9O1xuICAgICAgICBjb25zdCBvcmRlciA9IHMub2JqZWN0cy5zbGljZSgpLnNvcnQoKGEsIGIpID0+IChhLnogfHwgMCkgLSAoYi56IHx8IDApKS5tYXAoKG8pID0+IG8uaWQpLmZpbHRlcigoaWQpID0+IGlkICE9PSBzLmNvbm5lY3RGcm9tKTtcbiAgICAgICAgaWYgKCFvcmRlci5sZW5ndGgpIHJldHVybiB7fTtcbiAgICAgICAgY29uc3QgaWR4ID0gb3JkZXIuaW5kZXhPZihzLmNvbm5lY3RDdXJzb3IgPz8gb3JkZXJbMF0pO1xuICAgICAgICByZXR1cm4geyBjb25uZWN0Q3Vyc29yOiBvcmRlclsoaWR4ICsgZGlyICsgb3JkZXIubGVuZ3RoKSAlIG9yZGVyLmxlbmd0aF0gfTtcbiAgICAgIH0pO1xuICAgIH0sXG4gICAgW3VwZGF0ZV0sXG4gICk7XG5cbiAgLy8gLS0tLSBwb2ludGVyIGdlc3R1cmVzIC0tLS1cbiAgY29uc3Qgb25DYW52YXNEb3duID0gdXNlQ2FsbGJhY2soXG4gICAgKGU6IFJlYWN0LlBvaW50ZXJFdmVudCkgPT4ge1xuICAgICAgY29uc3QgcyA9IHN0YXRlUmVmLmN1cnJlbnQ7XG4gICAgICBpZiAocy5xdWlja01lbnUpIHVwZGF0ZSh7IHF1aWNrTWVudTogbnVsbCB9KTtcbiAgICAgIGlmIChzLmRlbW9NZW51T3BlbikgdXBkYXRlKHsgZGVtb01lbnVPcGVuOiBmYWxzZSB9KTtcbiAgICAgIGNvbnN0IG1pZCA9IGUuYnV0dG9uID09PSAxO1xuICAgICAgaWYgKHMubW9kZSA9PT0gJ2VkaXQnICYmICFzcGFjZVJlZi5jdXJyZW50ICYmICFtaWQgJiYgIWlzTW9iaWxlKCkpIHtcbiAgICAgICAgY29uc3QgW2x4LCBseV0gPSBsb2NhbFBvaW50KGUpO1xuICAgICAgICBpZiAoIWUuc2hpZnRLZXkpIHVwZGF0ZSh7IHNlbGVjdGlvbjogW10gfSk7XG4gICAgICAgIGRyYWdSZWYuY3VycmVudCA9IHsgdHlwZTogJ21hcnF1ZWUnLCBzeDogbHgsIHN5OiBseSwgYWRkOiBlLnNoaWZ0S2V5LCBiYXNlOiBzLnNlbGVjdGlvbi5zbGljZSgpIH07XG4gICAgICAgIHVwZGF0ZSh7IG1hcnF1ZWU6IHsgeDogbHgsIHk6IGx5LCB3OiAwLCBoOiAwIH0gfSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBkcmFnUmVmLmN1cnJlbnQgPSB7IHR5cGU6ICdwYW4nLCBzeDogZS5jbGllbnRYLCBzeTogZS5jbGllbnRZLCBjeDogcy5jYW0uY3gsIGN5OiBzLmNhbS5jeSB9O1xuICAgICAgICB1cGRhdGUoeyBwYW5uaW5nOiB0cnVlIH0pO1xuICAgICAgfVxuICAgIH0sXG4gICAgW3VwZGF0ZSwgaXNNb2JpbGUsIGxvY2FsUG9pbnRdLFxuICApO1xuXG4gIGNvbnN0IG9ialBvaW50ZXJEb3duID0gdXNlQ2FsbGJhY2soXG4gICAgKGlkOiBzdHJpbmcsIGU6IFJlYWN0LlBvaW50ZXJFdmVudCkgPT4ge1xuICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgIGNvbnN0IHMgPSBzdGF0ZVJlZi5jdXJyZW50O1xuICAgICAgaWYgKHMubW9kZSAhPT0gJ2VkaXQnKSB7XG4gICAgICAgIGRyYWdSZWYuY3VycmVudCA9IHsgdHlwZTogJ3BhbicsIHN4OiBlLmNsaWVudFgsIHN5OiBlLmNsaWVudFksIGN4OiBzLmNhbS5jeCwgY3k6IHMuY2FtLmN5IH07XG4gICAgICAgIHVwZGF0ZSh7IHBhbm5pbmc6IHRydWUgfSk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IG8gPSBzLm9iamVjdHMuZmluZCgoeCkgPT4geC5pZCA9PT0gaWQpO1xuICAgICAgaWYgKCFvKSByZXR1cm47XG4gICAgICAvLyBPbmUgc3BlbGxpbmcgb2Ygc2VsZWN0aW9uIGZvciBwb2ludGVyIGFuZCBrZXlib2FyZCBhbGlrZSAoUjMtNjA3KS5cbiAgICAgIGNvbnN0IHNlbCA9IGFwcGx5U2VsZWN0aW9uKHMuc2VsZWN0aW9uLCBpZCwgZS5zaGlmdEtleSk7XG4gICAgICB1cGRhdGUoeyBzZWxlY3Rpb246IHNlbCwgaW5zcGVjdG9yT3BlbjogdHJ1ZSwgcXVpY2tNZW51OiBudWxsIH0pO1xuICAgICAgaWYgKG8ubG9ja2VkKSByZXR1cm47XG4gICAgICBjb25zdCBvcmlnOiBSZWNvcmQ8c3RyaW5nLCB7IHg6IG51bWJlcjsgeTogbnVtYmVyIH0+ID0ge307XG4gICAgICBzLm9iamVjdHMuZm9yRWFjaCgoeCkgPT4ge1xuICAgICAgICBpZiAoc2VsLmluY2x1ZGVzKHguaWQpKSBvcmlnW3guaWRdID0geyB4OiB4LngsIHk6IHgueSB9O1xuICAgICAgfSk7XG4gICAgICBkcmFnUmVmLmN1cnJlbnQgPSB7IHR5cGU6ICdtb3ZlJywgc3g6IGUuY2xpZW50WCwgc3k6IGUuY2xpZW50WSwgaWRzOiBzZWwsIG9yaWcsIG1vdmVkOiBmYWxzZSB9O1xuICAgIH0sXG4gICAgW3VwZGF0ZV0sXG4gICk7XG5cbiAgY29uc3Qgc3RhcnRIYW5kbGUgPSB1c2VDYWxsYmFjaygoa2luZDogJ3Jlc2l6ZScgfCAncm90YXRlJywgaGFuZGxlOiBzdHJpbmcsIGU6IFJlYWN0LlBvaW50ZXJFdmVudCkgPT4ge1xuICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgY29uc3QgcyA9IHN0YXRlUmVmLmN1cnJlbnQ7XG4gICAgY29uc3QgaWQgPSBzLnNlbGVjdGlvblswXTtcbiAgICBjb25zdCBvID0gcy5vYmplY3RzLmZpbmQoKHgpID0+IHguaWQgPT09IGlkKTtcbiAgICBpZiAoIW8pIHJldHVybjtcbiAgICBjb25zdCBiYXNlID0geyB4OiBvLngsIHk6IG8ueSwgdzogby53LCBoOiBvLmgsIHJvdDogby5yb3QgfTtcbiAgICBkcmFnUmVmLmN1cnJlbnQgPVxuICAgICAga2luZCA9PT0gJ3JvdGF0ZSdcbiAgICAgICAgPyB7IHR5cGU6ICdyb3RhdGUnLCBzeDogZS5jbGllbnRYLCBzeTogZS5jbGllbnRZLCBvOiBiYXNlLCBpZCwgbW92ZWQ6IGZhbHNlIH1cbiAgICAgICAgOiB7IHR5cGU6ICdyZXNpemUnLCBraW5kOiBoYW5kbGUsIHN4OiBlLmNsaWVudFgsIHN5OiBlLmNsaWVudFksIG86IGJhc2UsIGlkLCBtb3ZlZDogZmFsc2UgfTtcbiAgfSwgW10pO1xuXG4gIGNvbnN0IHN0YXJ0Q29ubmVjdCA9IHVzZUNhbGxiYWNrKFxuICAgIChpZDogc3RyaW5nLCBzaWRlOiBzdHJpbmcsIGU6IFJlYWN0LlBvaW50ZXJFdmVudCkgPT4ge1xuICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgIGRyYWdSZWYuY3VycmVudCA9IHsgdHlwZTogJ2Nvbm5lY3QnLCBmcm9tOiBpZCwgc2lkZSwgbW92ZWQ6IGZhbHNlIH07XG4gICAgICBjb25zdCBbbHgsIGx5XSA9IGxvY2FsUG9pbnQoZSk7XG4gICAgICB1cGRhdGUoeyBjb25uZWN0UHJldmlldzogeyBmcm9tOiBpZCwgeDogbHgsIHk6IGx5LCB0YXJnZXQ6IG51bGwgfSB9KTtcbiAgICB9LFxuICAgIFt1cGRhdGUsIGxvY2FsUG9pbnRdLFxuICApO1xuXG4gIGNvbnN0IHNldEhvdmVyID0gdXNlQ2FsbGJhY2soKGlkOiBzdHJpbmcgfCBudWxsKSA9PiB1cGRhdGUoeyBob3ZlcjogaWQgfSksIFt1cGRhdGVdKTtcbiAgY29uc3QgY2xlYXJTZWxlY3Rpb24gPSB1c2VDYWxsYmFjaygoKSA9PiB1cGRhdGUoeyBzZWxlY3Rpb246IFtdIH0pLCBbdXBkYXRlXSk7XG5cbiAgLy8gLS0tLSBtb2RlIC8gdmlldyBjb250cm9scyAtLS0tXG4gIGNvbnN0IHNldFJ1biA9IHVzZUNhbGxiYWNrKFxuICAgIC8vIExlYXZpbmcgZWRpdCBkaXNhcm1zIGEga2V5Ym9hcmQgY29ubmVjdCB0b28gKGl0cyBjdXJzb3IgbGl2ZXMgb24gdGhlXG4gICAgLy8gZWRpdCBzdXJmYWNlKSDigJQgY29ubmVjdEZyb20gc3Vydml2aW5nIGludG8gcnVuIG1vZGUgd291bGQgb3duIHRoZVxuICAgIC8vIGFycm93cyBvZiBhIG1vZGUgdGhhdCBoYXMgbm8gc2VsZWN0aW9uIChSMy02MDcgcmV2aWV3KS5cbiAgICAoKSA9PiB1cGRhdGUoeyBtb2RlOiAncnVuJywgc2VsZWN0aW9uOiBbXSwgaW5zcGVjdG9yT3BlbjogZmFsc2UsIHF1aWNrTWVudTogbnVsbCwgY29ubmVjdFByZXZpZXc6IG51bGwsIGNvbm5lY3RGcm9tOiBudWxsLCBjb25uZWN0Q3Vyc29yOiBudWxsIH0pLFxuICAgIFt1cGRhdGVdLFxuICApO1xuICBjb25zdCBzZXRFZGl0ID0gdXNlQ2FsbGJhY2soKCkgPT4gdXBkYXRlKHsgbW9kZTogJ2VkaXQnIH0pLCBbdXBkYXRlXSk7XG4gIGNvbnN0IHRvZ2dsZVRoZW1lID0gdXNlQ2FsbGJhY2soKCkgPT4gdXBkYXRlKChzKSA9PiAoeyBsaWdodDogIXMubGlnaHQgfSkpLCBbdXBkYXRlXSk7XG4gIGNvbnN0IHRvZ2dsZVBhbmVsID0gdXNlQ2FsbGJhY2soKCkgPT4gdXBkYXRlKChzKSA9PiAoeyBwYW5lbE9wZW46ICFzLnBhbmVsT3BlbiB9KSksIFt1cGRhdGVdKTtcbiAgY29uc3Qgc2V0U2NyZWVuID0gdXNlQ2FsbGJhY2soKHNjcmVlbjogU2NyZWVuS2luZCkgPT4gdXBkYXRlKHsgc2NyZWVuIH0pLCBbdXBkYXRlXSk7XG4gIGNvbnN0IHNldEJhY2tncm91bmQgPSB1c2VDYWxsYmFjaygoYmc6IEJhY2tncm91bmQpID0+IHVwZGF0ZSh7IGJnIH0pLCBbdXBkYXRlXSk7XG4gIGNvbnN0IHNldExpZ2h0ID0gdXNlQ2FsbGJhY2soKGxpZ2h0OiBib29sZWFuKSA9PiB1cGRhdGUoeyBsaWdodCB9KSwgW3VwZGF0ZV0pO1xuICBjb25zdCBjbG9zZUluc3BlY3RvciA9IHVzZUNhbGxiYWNrKCgpID0+IHVwZGF0ZSh7IGluc3BlY3Rvck9wZW46IGZhbHNlIH0pLCBbdXBkYXRlXSk7XG4gIGNvbnN0IGNsb3NlUGFuZWwgPSB1c2VDYWxsYmFjaygoKSA9PiB1cGRhdGUoeyBwYW5lbE9wZW46IGZhbHNlIH0pLCBbdXBkYXRlXSk7XG4gIGNvbnN0IHRvZ2dsZURlbW9NZW51ID0gdXNlQ2FsbGJhY2soKCkgPT4gdXBkYXRlKChzKSA9PiAoeyBkZW1vTWVudU9wZW46ICFzLmRlbW9NZW51T3BlbiB9KSksIFt1cGRhdGVdKTtcblxuICBjb25zdCBvbkNhbnZhc0RibENsaWNrID0gdXNlQ2FsbGJhY2soXG4gICAgKGU6IFJlYWN0Lk1vdXNlRXZlbnQpID0+IHtcbiAgICAgIGlmIChzdGF0ZVJlZi5jdXJyZW50Lm1vZGUgIT09ICdlZGl0JykgcmV0dXJuO1xuICAgICAgY29uc3QgW2x4LCBseV0gPSBsb2NhbFBvaW50KGUpO1xuICAgICAgY29uc3QgW3d4LCB3eV0gPSB3b3JsZEF0KHN0YXRlUmVmLmN1cnJlbnQuY2FtLCBzdGF0ZVJlZi5jdXJyZW50LnZwLCBseCwgbHkpO1xuICAgICAgdXBkYXRlKHsgcXVpY2tNZW51OiB7IGx4LCBseSwgd3gsIHd5IH0gfSk7XG4gICAgfSxcbiAgICBbdXBkYXRlLCBsb2NhbFBvaW50XSxcbiAgKTtcblxuICAvLyAtLS0tIGRlbW8gc2NlbmFyaW9zICh0aGUgZGVzaWduJ3MgXCJkZW1vIHN0YXRlc1wiIG1lbnUpIC0tLS1cbiAgY29uc3QgZGVtb0xXVyA9IHVzZUNhbGxiYWNrKCgpID0+IHtcbiAgICB0b2FzdCgnTm90ZSB3YXMgY2hhbmdlZCBieSBAZGFuYSB3aGlsZSB5b3UgZWRpdGVkIOKAlCB0aGVpciB2ZXJzaW9uIGtlcHQuJywgJ2FsZXJ0Jywge1xuICAgICAgaWNvbkNvbG9yOiAnI2NhYTI0YScsXG4gICAgICBhY3Rpb25MYWJlbDogJ0tlZXAgbWluZScsXG4gICAgICBvbkFjdGlvbjogKCkgPT4gdG9hc3QoJ1lvdXIgdmVyc2lvbiByZXN0b3JlZCcsICdjaGVjaycpLFxuICAgIH0pO1xuICB9LCBbdG9hc3RdKTtcblxuICBjb25zdCBkZW1vRG93bmdyYWRlID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIHVwZGF0ZSh7IG1vZGU6ICdydW4nLCBzZWxlY3Rpb246IFtdLCBpbnNwZWN0b3JPcGVuOiBmYWxzZSB9KTtcbiAgICB0b2FzdCgnWW91ciBhY2Nlc3MgY2hhbmdlZCB0byByZWFkLW9ubHkuIEVkaXQgbW9kZSBjbG9zZWQuJywgJ2xvY2snLCB7IGljb25Db2xvcjogJ3ZhcigtLWluay0yKScgfSk7XG4gIH0sIFt1cGRhdGUsIHRvYXN0XSk7XG5cbiAgLy8gLS0tLSBlZmZlY3RzOiBtZWFzdXJlbWVudCArIGdsb2JhbCBsaXN0ZW5lcnMgLS0tLVxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5zZXRBdHRyaWJ1dGUoJ2RhdGEtdGhlbWUnLCBzdGF0ZS5saWdodCA/ICdsaWdodCcgOiAnZGFyaycpO1xuICB9LCBbc3RhdGUubGlnaHRdKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IGVsID0gY2FudmFzRWw7XG4gICAgaWYgKCFlbCkgcmV0dXJuO1xuXG4gICAgY29uc3QgbWVhc3VyZSA9ICgpID0+IHtcbiAgICAgIGNvbnN0IHIgPSBlbC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICAgIHVwZGF0ZSh7IHZwOiB7IHZ3OiByLndpZHRoLCB2aDogci5oZWlnaHQsIHZsZWZ0OiByLmxlZnQsIHZ0b3A6IHIudG9wIH0gfSk7XG4gICAgfTtcbiAgICBtZWFzdXJlKCk7XG4gICAgY29uc3Qgcm8gPSBuZXcgUmVzaXplT2JzZXJ2ZXIobWVhc3VyZSk7XG4gICAgcm8ub2JzZXJ2ZShlbCk7XG5cbiAgICBjb25zdCBvbldoZWVsID0gKGU6IFdoZWVsRXZlbnQpID0+IHtcbiAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgIGNvbnN0IFtseCwgbHldID0gbG9jYWxQb2ludChlKTtcbiAgICAgIGlmIChlLmN0cmxLZXkgfHwgZS5tZXRhS2V5KSB7XG4gICAgICAgIGNvbnN0IGYgPSBNYXRoLmV4cCgtZS5kZWx0YVkgKiAwLjAxKTtcbiAgICAgICAgc2V0Wm9vbShzdGF0ZVJlZi5jdXJyZW50LmNhbS56b29tICogZiwgbHgsIGx5KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHVwZGF0ZSgocykgPT4gKHsgY2FtOiB7IGN4OiBzLmNhbS5jeCArIGUuZGVsdGFYIC8gcy5jYW0uem9vbSwgY3k6IHMuY2FtLmN5ICsgZS5kZWx0YVkgLyBzLmNhbS56b29tLCB6b29tOiBzLmNhbS56b29tIH0gfSkpO1xuICAgICAgfVxuICAgIH07XG4gICAgZWwuYWRkRXZlbnRMaXN0ZW5lcignd2hlZWwnLCBvbldoZWVsLCB7IHBhc3NpdmU6IGZhbHNlIH0pO1xuXG4gICAgY29uc3Qgb25Nb3ZlID0gKGU6IFBvaW50ZXJFdmVudCkgPT4ge1xuICAgICAgY29uc3QgZCA9IGRyYWdSZWYuY3VycmVudDtcbiAgICAgIGlmICghZCkgcmV0dXJuO1xuICAgICAgY29uc3QgeiA9IHN0YXRlUmVmLmN1cnJlbnQuY2FtLnpvb207XG4gICAgICBpZiAoZC50eXBlID09PSAncGFuJykge1xuICAgICAgICBjb25zdCBkeCA9IGUuY2xpZW50WCAtIGQuc3g7XG4gICAgICAgIGNvbnN0IGR5ID0gZS5jbGllbnRZIC0gZC5zeTtcbiAgICAgICAgdXBkYXRlKHsgY2FtOiB7IGN4OiBkLmN4IC0gZHggLyB6LCBjeTogZC5jeSAtIGR5IC8geiwgem9vbTogeiB9IH0pO1xuICAgICAgfSBlbHNlIGlmIChkLnR5cGUgPT09ICdtb3ZlJykge1xuICAgICAgICBjb25zdCBkeCA9IChlLmNsaWVudFggLSBkLnN4KSAvIHo7XG4gICAgICAgIGNvbnN0IGR5ID0gKGUuY2xpZW50WSAtIGQuc3kpIC8gejtcbiAgICAgICAgZC5tb3ZlZCA9IHRydWU7XG4gICAgICAgIHVwZGF0ZSgocykgPT4gKHtcbiAgICAgICAgICBvYmplY3RzOiBzLm9iamVjdHMubWFwKChvKSA9PlxuICAgICAgICAgICAgZC5pZHMuaW5jbHVkZXMoby5pZCkgJiYgZC5vcmlnW28uaWRdID8geyAuLi5vLCB4OiBkLm9yaWdbby5pZF0ueCArIGR4LCB5OiBkLm9yaWdbby5pZF0ueSArIGR5IH0gOiBvLFxuICAgICAgICAgICksXG4gICAgICAgIH0pKTtcbiAgICAgIH0gZWxzZSBpZiAoZC50eXBlID09PSAnbWFycXVlZScpIHtcbiAgICAgICAgY29uc3QgW2x4LCBseV0gPSBsb2NhbFBvaW50KGUpO1xuICAgICAgICBjb25zdCB4ID0gTWF0aC5taW4obHgsIGQuc3gpO1xuICAgICAgICBjb25zdCB5ID0gTWF0aC5taW4obHksIGQuc3kpO1xuICAgICAgICBjb25zdCB3ID0gTWF0aC5hYnMobHggLSBkLnN4KTtcbiAgICAgICAgY29uc3QgaGggPSBNYXRoLmFicyhseSAtIGQuc3kpO1xuICAgICAgICBjb25zdCBzID0gc3RhdGVSZWYuY3VycmVudDtcbiAgICAgICAgY29uc3Qgc2VsID0gb2JqZWN0c0luUmVjdChzLm9iamVjdHMsIHMuY2FtLCBzLnZwLCB4LCB5LCB3LCBoaCk7XG4gICAgICAgIHVwZGF0ZSh7IG1hcnF1ZWU6IHsgeCwgeSwgdywgaDogaGggfSwgc2VsZWN0aW9uOiBkLmFkZCA/IEFycmF5LmZyb20obmV3IFNldChkLmJhc2UuY29uY2F0KHNlbCkpKSA6IHNlbCB9KTtcbiAgICAgIH0gZWxzZSBpZiAoZC50eXBlID09PSAnY29ubmVjdCcpIHtcbiAgICAgICAgY29uc3QgW2x4LCBseV0gPSBsb2NhbFBvaW50KGUpO1xuICAgICAgICBjb25zdCBzID0gc3RhdGVSZWYuY3VycmVudDtcbiAgICAgICAgY29uc3QgdGd0ID0gb2JqZWN0QXRMb2NhbChzLm9iamVjdHMsIHMuY2FtLCBzLnZwLCBseCwgbHksIGQuZnJvbSk7XG4gICAgICAgIHVwZGF0ZSh7IGNvbm5lY3RQcmV2aWV3OiB7IGZyb206IGQuZnJvbSwgeDogbHgsIHk6IGx5LCB0YXJnZXQ6IHRndCB9IH0pO1xuICAgICAgfSBlbHNlIGlmIChkLnR5cGUgPT09ICdyZXNpemUnIHx8IGQudHlwZSA9PT0gJ3JvdGF0ZScpIHtcbiAgICAgICAgYXBwbHlIYW5kbGUoZCwgZSk7XG4gICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGFwcGx5SGFuZGxlID0gKGQ6IEV4dHJhY3Q8RHJhZywgeyB0eXBlOiAncmVzaXplJyB8ICdyb3RhdGUnIH0+LCBlOiBQb2ludGVyRXZlbnQpID0+IHtcbiAgICAgIGNvbnN0IHMgPSBzdGF0ZVJlZi5jdXJyZW50O1xuICAgICAgY29uc3QgeiA9IHMuY2FtLnpvb207XG4gICAgICBjb25zdCBkeCA9IChlLmNsaWVudFggLSBkLnN4KSAvIHo7XG4gICAgICBjb25zdCBkeSA9IChlLmNsaWVudFkgLSBkLnN5KSAvIHo7XG4gICAgICBkLm1vdmVkID0gdHJ1ZTtcbiAgICAgIHVwZGF0ZSgoc3QpID0+ICh7XG4gICAgICAgIG9iamVjdHM6IHN0Lm9iamVjdHMubWFwKChvKSA9PiB7XG4gICAgICAgICAgaWYgKG8uaWQgIT09IGQuaWQpIHJldHVybiBvO1xuICAgICAgICAgIGlmIChkLnR5cGUgPT09ICdyb3RhdGUnKSB7XG4gICAgICAgICAgICBjb25zdCBjeCA9IGQuby54ICsgZC5vLncgLyAyO1xuICAgICAgICAgICAgY29uc3QgY3kgPSBkLm8ueSArIGQuby5oIC8gMjtcbiAgICAgICAgICAgIGNvbnN0IFtseCwgbHldID0gbG9jYWxQb2ludChlKTtcbiAgICAgICAgICAgIGNvbnN0IFt3eCwgd3ldID0gd29ybGRBdChzLmNhbSwgcy52cCwgbHgsIGx5KTtcbiAgICAgICAgICAgIGxldCBhbmcgPSAoTWF0aC5hdGFuMih3eSAtIGN5LCB3eCAtIGN4KSAqIDE4MCkgLyBNYXRoLlBJICsgOTA7XG4gICAgICAgICAgICBpZiAoZS5zaGlmdEtleSkgYW5nID0gTWF0aC5yb3VuZChhbmcgLyAxNSkgKiAxNTtcbiAgICAgICAgICAgIHJldHVybiB7IC4uLm8sIHJvdDogTWF0aC5yb3VuZChhbmcpIH07XG4gICAgICAgICAgfVxuICAgICAgICAgIGxldCB4ID0gZC5vLng7XG4gICAgICAgICAgbGV0IHkgPSBkLm8ueTtcbiAgICAgICAgICBsZXQgdyA9IGQuby53O1xuICAgICAgICAgIGxldCBoaCA9IGQuby5oO1xuICAgICAgICAgIGNvbnN0IGsgPSBkLmtpbmQ7XG4gICAgICAgICAgaWYgKGsuaW5jbHVkZXMoJ2UnKSkgdyA9IE1hdGgubWF4KDYwLCBkLm8udyArIGR4KTtcbiAgICAgICAgICBpZiAoay5pbmNsdWRlcygncycpKSBoaCA9IE1hdGgubWF4KDQ4LCBkLm8uaCArIGR5KTtcbiAgICAgICAgICBpZiAoay5pbmNsdWRlcygndycpKSB7XG4gICAgICAgICAgICB3ID0gTWF0aC5tYXgoNjAsIGQuby53IC0gZHgpO1xuICAgICAgICAgICAgeCA9IGQuby54ICsgKGQuby53IC0gdyk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChrLmluY2x1ZGVzKCduJykpIHtcbiAgICAgICAgICAgIGhoID0gTWF0aC5tYXgoNDgsIGQuby5oIC0gZHkpO1xuICAgICAgICAgICAgeSA9IGQuby55ICsgKGQuby5oIC0gaGgpO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4geyAuLi5vLCB4LCB5LCB3LCBoOiBoaCB9O1xuICAgICAgICB9KSxcbiAgICAgIH0pKTtcbiAgICB9O1xuXG4gICAgY29uc3Qgb25VcCA9IChlOiBQb2ludGVyRXZlbnQpID0+IHtcbiAgICAgIGNvbnN0IGQgPSBkcmFnUmVmLmN1cnJlbnQ7XG4gICAgICBkcmFnUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgaWYgKCFkKSB7XG4gICAgICAgIGlmIChzdGF0ZVJlZi5jdXJyZW50LnBhbm5pbmcpIHVwZGF0ZSh7IHBhbm5pbmc6IGZhbHNlIH0pO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAoZC50eXBlID09PSAncGFuJykge1xuICAgICAgICB1cGRhdGUoeyBwYW5uaW5nOiBmYWxzZSB9KTtcbiAgICAgIH0gZWxzZSBpZiAoZC50eXBlID09PSAnbW92ZScgJiYgZC5tb3ZlZCkge1xuICAgICAgICBjb25zdCBtb3ZlZCA9IHN0YXRlUmVmLmN1cnJlbnQub2JqZWN0cy5maWx0ZXIoKG8pID0+IGQuaWRzLmluY2x1ZGVzKG8uaWQpKTtcbiAgICAgICAgY29tbWl0U2F2ZShtb3ZlZCwgYE1vdmVkIMK3IHNhdmVkIHRvICR7ZC5pZHMubGVuZ3RoID4gMSA/IGAke2QuaWRzLmxlbmd0aH0gZmlsZXNgIDogYCR7ZC5pZHNbMF19Lm1keGB9YCk7XG4gICAgICB9IGVsc2UgaWYgKGQudHlwZSA9PT0gJ21hcnF1ZWUnKSB7XG4gICAgICAgIHVwZGF0ZSh7IG1hcnF1ZWU6IG51bGwgfSk7XG4gICAgICB9IGVsc2UgaWYgKGQudHlwZSA9PT0gJ2Nvbm5lY3QnKSB7XG4gICAgICAgIGNvbnN0IFtseCwgbHldID0gbG9jYWxQb2ludChlKTtcbiAgICAgICAgY29uc3QgcyA9IHN0YXRlUmVmLmN1cnJlbnQ7XG4gICAgICAgIGNvbnN0IHRndCA9IG9iamVjdEF0TG9jYWwocy5vYmplY3RzLCBzLmNhbSwgcy52cCwgbHgsIGx5LCBkLmZyb20pO1xuICAgICAgICBpZiAodGd0KSBhZGRDb25uZWN0aW9uKGQuZnJvbSwgdGd0KTtcbiAgICAgICAgdXBkYXRlKHsgY29ubmVjdFByZXZpZXc6IG51bGwgfSk7XG4gICAgICB9IGVsc2UgaWYgKChkLnR5cGUgPT09ICdyZXNpemUnIHx8IGQudHlwZSA9PT0gJ3JvdGF0ZScpICYmIGQubW92ZWQpIHtcbiAgICAgICAgY29uc3QgbyA9IHN0YXRlUmVmLmN1cnJlbnQub2JqZWN0cy5maW5kKCh4KSA9PiB4LmlkID09PSBkLmlkKTtcbiAgICAgICAgY29tbWl0U2F2ZShvID8gW29dIDogW10sICdSZXNpemVkIMK3IHNhdmVkJyk7XG4gICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IG9uS2V5RG93biA9IChlOiBLZXlib2FyZEV2ZW50KSA9PiB7XG4gICAgICBjb25zdCB0ID0gZS50YXJnZXQgYXMgSFRNTEVsZW1lbnQgfCBudWxsO1xuICAgICAgaWYgKHQgJiYgKHQudGFnTmFtZSA9PT0gJ0lOUFVUJyB8fCB0LnRhZ05hbWUgPT09ICdURVhUQVJFQScgfHwgdC50YWdOYW1lID09PSAnU0VMRUNUJyB8fCB0LmlzQ29udGVudEVkaXRhYmxlKSkgcmV0dXJuO1xuICAgICAgY29uc3QgcyA9IHN0YXRlUmVmLmN1cnJlbnQ7XG4gICAgICBpZiAocy5qb3VybmV5KSB7XG4gICAgICAgIGlmIChlLmtleSA9PT0gJ0Fycm93UmlnaHQnIHx8IGUua2V5ID09PSAnICcpIHtcbiAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICAgcGxheU5leHQoKTtcbiAgICAgICAgfSBlbHNlIGlmIChlLmtleSA9PT0gJ0Fycm93TGVmdCcpIHtcbiAgICAgICAgICBwbGF5UHJldigpO1xuICAgICAgICB9IGVsc2UgaWYgKGUua2V5ID09PSAnRXNjYXBlJykge1xuICAgICAgICAgIHBsYXlFeGl0KCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgLy8gS2V5Ym9hcmQgY29ubmVjdCBvd25zIHRoZSBhcnJvd3Mgd2hpbGUgaXQgaXMgYXJtZWQgKFIzLTYwNyk6IGFycm93c1xuICAgICAgLy8gd2FsayB0aGUgdGFyZ2V0IGN1cnNvciwgRW50ZXIgY29tbWl0cywgRXNjYXBlIGNhbmNlbHMg4oCUIG5ldmVyIG51ZGdpbmdcbiAgICAgIC8vIG9yIGRlbGV0aW5nIHVuZGVybmVhdGggYSBsaXZlIGNvbm5lY3QuXG4gICAgICBpZiAocy5jb25uZWN0RnJvbSkge1xuICAgICAgICBpZiAoZS5rZXkgPT09ICdBcnJvd0xlZnQnIHx8IGUua2V5ID09PSAnQXJyb3dVcCcpIHtcbiAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICAgbW92ZUNvbm5lY3RDdXJzb3IoLTEpO1xuICAgICAgICB9IGVsc2UgaWYgKGUua2V5ID09PSAnQXJyb3dSaWdodCcgfHwgZS5rZXkgPT09ICdBcnJvd0Rvd24nKSB7XG4gICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgIG1vdmVDb25uZWN0Q3Vyc29yKDEpO1xuICAgICAgICB9IGVsc2UgaWYgKGUua2V5ID09PSAnRW50ZXInKSB7XG4gICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgIGVuZENvbm5lY3QodHJ1ZSk7XG4gICAgICAgIH0gZWxzZSBpZiAoZS5rZXkgPT09ICdFc2NhcGUnKSB7XG4gICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgIGVuZENvbm5lY3QoZmFsc2UpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGlmIChlLmtleSA9PT0gJ0VzY2FwZScpIHVwZGF0ZSh7IHNlbGVjdGlvbjogW10sIHF1aWNrTWVudTogbnVsbCwgc2NyZWVuOiBudWxsIH0pO1xuICAgICAgaWYgKGUua2V5ID09PSAnICcpIHNwYWNlUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgaWYgKHMubW9kZSA9PT0gJ2VkaXQnICYmIHMuc2VsZWN0aW9uLmxlbmd0aCkge1xuICAgICAgICBjb25zdCBzdGVwID0gZS5zaGlmdEtleSA/IDEwIDogMTtcbiAgICAgICAgbGV0IGR4ID0gMDtcbiAgICAgICAgbGV0IGR5ID0gMDtcbiAgICAgICAgaWYgKGUua2V5ID09PSAnQXJyb3dMZWZ0JykgZHggPSAtc3RlcDtcbiAgICAgICAgZWxzZSBpZiAoZS5rZXkgPT09ICdBcnJvd1JpZ2h0JykgZHggPSBzdGVwO1xuICAgICAgICBlbHNlIGlmIChlLmtleSA9PT0gJ0Fycm93VXAnKSBkeSA9IC1zdGVwO1xuICAgICAgICBlbHNlIGlmIChlLmtleSA9PT0gJ0Fycm93RG93bicpIGR5ID0gc3RlcDtcbiAgICAgICAgaWYgKGR4IHx8IGR5KSB7XG4gICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgIGNvbnN0IHNlbCA9IHMuc2VsZWN0aW9uO1xuICAgICAgICAgIHVwZGF0ZSgoc3QpID0+ICh7IG9iamVjdHM6IHN0Lm9iamVjdHMubWFwKChvKSA9PiAoc2VsLmluY2x1ZGVzKG8uaWQpICYmICFvLmxvY2tlZCA/IHsgLi4ubywgeDogby54ICsgZHgsIHk6IG8ueSArIGR5IH0gOiBvKSkgfSkpO1xuICAgICAgICAgIHNjaGVkdWxlU2F2ZShzZWwpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChlLmtleSA9PT0gJ0RlbGV0ZScgfHwgZS5rZXkgPT09ICdCYWNrc3BhY2UnKSBkZWxldGVTZWxlY3Rpb24oKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IG9uS2V5VXAgPSAoZTogS2V5Ym9hcmRFdmVudCkgPT4ge1xuICAgICAgaWYgKGUua2V5ID09PSAnICcpIHNwYWNlUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICB9O1xuXG4gICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcigncG9pbnRlcm1vdmUnLCBvbk1vdmUpO1xuICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ3BvaW50ZXJ1cCcsIG9uVXApO1xuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdrZXlkb3duJywgb25LZXlEb3duKTtcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigna2V5dXAnLCBvbktleVVwKTtcblxuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBlbC5yZW1vdmVFdmVudExpc3RlbmVyKCd3aGVlbCcsIG9uV2hlZWwpO1xuICAgICAgcm8uZGlzY29ubmVjdCgpO1xuICAgICAgZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcigncG9pbnRlcm1vdmUnLCBvbk1vdmUpO1xuICAgICAgZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcigncG9pbnRlcnVwJywgb25VcCk7XG4gICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcigna2V5ZG93bicsIG9uS2V5RG93bik7XG4gICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcigna2V5dXAnLCBvbktleVVwKTtcbiAgICAgIGlmICh0d2VlblJlZi5jdXJyZW50KSBjYW5jZWxBbmltYXRpb25GcmFtZSh0d2VlblJlZi5jdXJyZW50KTtcbiAgICB9O1xuICAgIC8vIFRoZSBsaXN0ZW5lcnMgcmVhZCB0aGUgbGF0ZXN0IHN0YXRlIHZpYSBzdGF0ZVJlZiwgc28gdGhleSBpbnN0YWxsIG9uY2VcbiAgICAvLyB0aGUgY2FudmFzIG1vdW50czsgdGhlIGFjdGlvbiBjYWxsYmFja3MgdGhleSBjbG9zZSBvdmVyIGFyZSBhbGwgc3RhYmxlLlxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9leGhhdXN0aXZlLWRlcHNcbiAgfSwgW2NhbnZhc0VsXSk7XG5cbiAgLyoqXG4gICAqIFByb3ZpZGVyIHNpZGUgb2YgYG9wZW4tcHJvamVjdGAgKFNQQUNFU19VSV9TUEVDIMKnNik6IGdpdmVuIHRoZSBkZWxlZ2F0ZWRcbiAgICogYGNhcERpcmAsIGZpbmQgdGhlIGNocm9vdCB0aGUgaG9zdCBtb3VudGVkIGZvciBpdCwgaHlkcmF0ZSB0aGUgY2FudmFzIGZyb21cbiAgICogaXQsIGFuZCBhcm0gdGhlIGR1cmFibGUtYm9hcmQgbWFjaGluZXJ5IChhdXRvc2F2ZSwgZG93bmdyYWRlIHdhdGNoKSBhZ2FpbnN0XG4gICAqIGl0LiBSZXNvbHZlcyB0cnVlIG9uY2UgdGhlIGJvYXJkIGlzIHNob3duLCBmYWxzZSBpZiB0aGUgZGVsZWdhdGVkIGZvbGRlclxuICAgKiBuZXZlciByZXNvbHZlZCB0byBhIG1vdW50ICh0aGUgY2FsbGVyIHRoZW4gYWJvcnRzIHRoZSB0YXNrKS4gVGhlIGZvbGRlciBpc1xuICAgKiBleHBlY3RlZCB0byBhbHJlYWR5IGJlIGEgYm9hcmQgKHRoZSBtYXJrZXIgb25seSBsaXZlcyBvbiBib2FyZCBmb2xkZXJzKTsgYW5cbiAgICogZW1wdHkgb25lIGlzIHNlZWRlZCBzbyB0aGUgY2FudmFzIHN0aWxsIHJlbmRlcnMuXG4gICAqL1xuICBjb25zdCBvcGVuRGVsZWdhdGVkUHJvamVjdCA9IHVzZUNhbGxiYWNrKFxuICAgIGFzeW5jIChkaXJQYXRoOiBzdHJpbmcpOiBQcm9taXNlPGJvb2xlYW4+ID0+IHtcbiAgICAgIC8vIFRoZSBob3N0IGFubm91bmNlcyB0aGUgdGFzayBjaHJvb3QgYXMgYSBtb3VudCBBVCB0aGUgZGVsZWdhdGVkIHBhdGg7IGl0XG4gICAgICAvLyBtYXkgbm90IGJlIHByZXNlbnQgdGhlIGluc3RhbnQgd2UgcmVhZCB0aGUgaW5wdXQsIHNvIHBvbGwgYnJpZWZseSAoYSBmZXdcbiAgICAgIC8vIGZyYW1lcykgZm9yIHRoZSBtb3VudCB3aG9zZSBgcGF0aGAgbWF0Y2hlcy5cbiAgICAgIGxldCBtb3VudCA9IHJlc29sdmVEZWxlZ2F0ZWRNb3VudChkaXJQYXRoLCBnZXRNb3VudHMoKSk7XG4gICAgICBmb3IgKGxldCB0cmllcyA9IDA7ICFtb3VudCAmJiB0cmllcyA8IDQwOyB0cmllcyArPSAxKSB7XG4gICAgICAgIGF3YWl0IG5ldyBQcm9taXNlKChyKSA9PiBzZXRUaW1lb3V0KHIsIDUwKSk7XG4gICAgICAgIG1vdW50ID0gcmVzb2x2ZURlbGVnYXRlZE1vdW50KGRpclBhdGgsIGdldE1vdW50cygpKTtcbiAgICAgIH1cbiAgICAgIGlmICghbW91bnQpIHtcbiAgICAgICAgdG9hc3QoJ0NvdWxkbuKAmXQgb3BlbiB0aGF0IHByb2plY3Qg4oCUIHRoZSBmb2xkZXIgaXNu4oCZdCBhdmFpbGFibGUuJywgJ2FsZXJ0JywgeyBpY29uQ29sb3I6ICcjY2FhMjRhJyB9KTtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgICAgY29uc3QgdGFyZ2V0ID0gZGlyQ2FwVG9Cb2FyZFRhcmdldChtb3VudCk7XG4gICAgICB0cnkge1xuICAgICAgICBpZiAoYXdhaXQgYm9hcmRFeGlzdHModGFyZ2V0KSkge1xuICAgICAgICAgIGF3YWl0IGxvYWRCb2FyZEludG8odGFyZ2V0KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAvLyBUaGUgbWFya2VyIHNhaWQgdGhpcyBpcyBhIHByb2plY3QgZm9sZGVyIGJ1dCBpdCBoYXMgbm8gb2JqZWN0cyB5ZXQ6XG4gICAgICAgICAgLy8gc2VlZCBpdCBzbyB0aGUgdXNlciBsYW5kcyBvbiBhIHVzYWJsZSBib2FyZCwgbm90IGEgYmxhbmsgY2FudmFzLlxuICAgICAgICAgIGJvYXJkUmVmLmN1cnJlbnQgPSB0YXJnZXQ7XG4gICAgICAgICAgY29uc3QgcyA9IHN0YXRlUmVmLmN1cnJlbnQ7XG4gICAgICAgICAgYXdhaXQgc2VlZEJvYXJkKHRhcmdldCwgeyBvYmplY3RzOiBzLm9iamVjdHMsIHZpZXdzOiBzLnZpZXdzLCBqb3VybmV5czogcy5qb3VybmV5cyB9KTtcbiAgICAgICAgfVxuICAgICAgICB0b2FzdCgnUHJvamVjdCBvcGVuZWQuJywgJ2NoZWNrJyk7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICB0b2FzdChgQ291bGRu4oCZdCBvcGVuIHByb2plY3Qke2NvZGVPZihlKX1gLCAnYWxlcnQnLCB7IGljb25Db2xvcjogJyNjYWEyNGEnIH0pO1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgfSxcbiAgICBbdG9hc3QsIGxvYWRCb2FyZEludG9dLFxuICApO1xuXG4gIC8vIC0tLS0gb3BlbiB0aGUgZHVyYWJsZSBib2FyZCBzcGFjZSwgaHlkcmF0ZSAob3Igc2VlZCksIHdhdGNoIGZvciBkb3duZ3JhZGVzIC0tLS1cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBsZXQgY2FuY2VsbGVkID0gZmFsc2U7XG4gICAgbGV0IHVuc3ViOiAoKCkgPT4gdm9pZCkgfCB1bmRlZmluZWQ7XG4gICAgY29uc3QgdGltZXJzID0gc2F2ZVRpbWVycy5jdXJyZW50O1xuICAgIChhc3luYyAoKSA9PiB7XG4gICAgICAvLyDilIDilIAgb3Blbi1wcm9qZWN0IHByb3ZpZGVyIHBhdGggKFNQQUNFU19VSV9TUEVDIMKnNiwgUGhhc2UgNSkg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gICAgICAvLyBJZiBhIGZpbGUgbWFuYWdlciBsYXVuY2hlZCB1cyB2aWEgdGhlIGBvcGVuLXByb2plY3RgIHRhc2ssIGl0IGhhbmRlZCBhXG4gICAgICAvLyBgY2FwRGlyYCBmb3IgdGhlIHByb2plY3QgZm9sZGVyOyB0aGUgaG9zdCBtb3VudGVkIHRoYXQgZm9sZGVyIGFzIGFcbiAgICAgIC8vIGNocm9vdC4gTG9hZCB0aGUgYm9hcmQgZnJvbSBpdCBhbmQgY29tcGxldGUgdGhlIHRhc2ssIHRoZW4gYXJtIHRoZSBzYW1lXG4gICAgICAvLyBkb3duZ3JhZGUgd2F0Y2ggYmVsb3cgYWdhaW5zdCB0aGUgZGVsZWdhdGVkIG1vdW50LiBBIG5vcm1hbCBsYXVuY2ggKG5vXG4gICAgICAvLyB0YXNrIGlucHV0KSBmYWxscyB0aHJvdWdoIHRvIHRoZSBkdXJhYmxlLWJvYXJkIHBhdGggdW5jaGFuZ2VkLlxuICAgICAgbGV0IGRlbGVnYXRlZCA9IGZhbHNlO1xuICAgICAgY29uc3QgZGlyID0gYXdhaXQgcmVhZE9wZW5Qcm9qZWN0SW5wdXQoKTtcbiAgICAgIGlmIChkaXIpIHtcbiAgICAgICAgY29uc3Qgb3BlbmVkID0gYXdhaXQgb3BlbkRlbGVnYXRlZFByb2plY3QoZGlyKTtcbiAgICAgICAgaWYgKG9wZW5lZCkgYXdhaXQgcmVwb3J0T3BlbmVkKHRydWUpO1xuICAgICAgICBlbHNlIGF3YWl0IGFib3J0T3BlblByb2plY3QoKTtcbiAgICAgICAgaWYgKGNhbmNlbGxlZCkgcmV0dXJuO1xuICAgICAgICAvLyBPbiBzdWNjZXNzIHRoZSBjYW52YXMgaXMgY2hyb290ZWQgYXQgdGhlIHByb2plY3Q7IHNraXAgdGhlIGR1cmFibGVcbiAgICAgICAgLy8gYm9hcmQgc3BhY2UuIE9uIGZhaWx1cmUsIGZhbGwgdGhyb3VnaCB0byB0aGUgaW4tbWVtb3J5IHNlZWQgc28gdGhlXG4gICAgICAgIC8vIGNhbnZhcyBzdGlsbCByZW5kZXJzIHNvbWV0aGluZyByYXRoZXIgdGhhbiBhIGJsYW5rIGFwcC5cbiAgICAgICAgZGVsZWdhdGVkID0gb3BlbmVkO1xuICAgICAgfVxuXG4gICAgICBpZiAoIWRlbGVnYXRlZCkge1xuICAgICAgICBsZXQgdGFyZ2V0OiBCb2FyZFRhcmdldDtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAvLyBBdXRvLW9wZW4gdGhlIHNpZ25lZC1pbiB1c2VyJ3MgYm9hcmQgc3BhY2UuIERlY2xpbmVkIC8gc2lnbmVkLW91dFxuICAgICAgICAgIC8vIHJlamVjdHMgd2l0aCBhIHR5cGVkIFNwYWNlRXJyb3Ig4oCUIHdlIGRlZ3JhZGUgdG8gdGhlIGluLW1lbW9yeSBzZWVkLlxuICAgICAgICAgIHRhcmdldCA9IGF3YWl0IG9wZW5Cb2FyZFRhcmdldCgpO1xuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgLy8gT25seSBgYXV0aC1yZXF1aXJlZGAgaXMgYSBzaWduLWluIHByb2JsZW07IGFueXRoaW5nIGVsc2UgaXMgbG9nZ2VkXG4gICAgICAgICAgLy8gd2l0aCBpdHMgY29kZSBhbmQgcmVwb3J0ZWQgYXMgdGhlIHBsYXRmb3JtIGZhaWx1cmUgaXQgaXMuXG4gICAgICAgICAgY29uc3QgZmFpbHVyZSA9IGNsYXNzaWZ5Qm9hcmRUYXJnZXRGYWlsdXJlKGUpO1xuICAgICAgICAgIGlmICghY2FuY2VsbGVkKVxuICAgICAgICAgICAgdG9hc3QoXG4gICAgICAgICAgICAgIGZhaWx1cmUuY29weSxcbiAgICAgICAgICAgICAgZmFpbHVyZS5hdXRoID8gJ3NhdmUnIDogJ2FsZXJ0JyxcbiAgICAgICAgICAgICAgZmFpbHVyZS5hdXRoID8geyBpY29uQ29sb3I6ICd2YXIoLS1pbmstMiknIH0gOiB7IGljb25Db2xvcjogJyNjYWEyNGEnIH0sXG4gICAgICAgICAgICApO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoY2FuY2VsbGVkKSByZXR1cm47XG4gICAgICAgIGJvYXJkUmVmLmN1cnJlbnQgPSB0YXJnZXQ7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgaWYgKGF3YWl0IGJvYXJkRXhpc3RzKHRhcmdldCkpIHtcbiAgICAgICAgICAgIGNvbnN0IGJvYXJkID0gYXdhaXQgbG9hZEJvYXJkKHRhcmdldCk7XG4gICAgICAgICAgICBpZiAoIWNhbmNlbGxlZCkge1xuICAgICAgICAgICAgICB1cGRhdGUoe1xuICAgICAgICAgICAgICAgIG9iamVjdHM6IGJvYXJkLm9iamVjdHMsXG4gICAgICAgICAgICAgICAgdmlld3M6IGJvYXJkLnZpZXdzLmxlbmd0aCA/IGJvYXJkLnZpZXdzIDogU0VFRF9WSUVXUy5zbGljZSgpLFxuICAgICAgICAgICAgICAgIGpvdXJuZXlzOiBib2FyZC5qb3VybmV5cy5sZW5ndGggPyBib2FyZC5qb3VybmV5cyA6IFNFRURfSk9VUk5FWVMsXG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICB0b2FzdCgnQm9hcmQgbG9hZGVkIGZyb20geW91ciBzcGFjZS4nLCAnY2hlY2snKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgLy8gRmlyc3QgcnVuIG9uIGFuIGVtcHR5IHNwYWNlOiBwZXJzaXN0IHRoZSBzZWVkIGRlbW8gYXMgdGhlIHN0YXJ0aW5nIGJvYXJkLlxuICAgICAgICAgICAgY29uc3QgcyA9IHN0YXRlUmVmLmN1cnJlbnQ7XG4gICAgICAgICAgICBhd2FpdCBzZWVkQm9hcmQodGFyZ2V0LCB7IG9iamVjdHM6IHMub2JqZWN0cywgdmlld3M6IHMudmlld3MsIGpvdXJuZXlzOiBzLmpvdXJuZXlzIH0pO1xuICAgICAgICAgICAgaWYgKCFjYW5jZWxsZWQpIHRvYXN0KCdCb2FyZCBjcmVhdGVkIGluIHlvdXIgc3BhY2UuJywgJ2NoZWNrJyk7XG4gICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgaWYgKCFjYW5jZWxsZWQpIHRvYXN0KGBDb3VsZG4ndCBvcGVuIGJvYXJkJHtjb2RlT2YoZSl9YCwgJ2FsZXJ0JywgeyBpY29uQ29sb3I6ICcjY2FhMjRhJyB9KTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKGNhbmNlbGxlZCkgcmV0dXJuO1xuICAgICAgLy8gTWlycm9yIHRoZSBsaXZlIG1vdW50cyBpbnRvIHN0YXRlICh0aGUgYm9hcmQgY2hvb3NlciBsaXN0cyB0aGVzZSxcbiAgICAgIC8vIFIzLTYwNykgYWxvbmdzaWRlIHRoZSBkb3duZ3JhZGUgd2F0Y2ggYmVsb3cuXG4gICAgICB0cnkge1xuICAgICAgICB1cGRhdGUoeyBtb3VudHM6IGdldE1vdW50cygpIH0pO1xuICAgICAgfSBjYXRjaCB7XG4gICAgICAgIC8vIE5vIGhvc3QgcnVudGltZSB5ZXQg4oCUIHRoZSBsaXN0IHN0YXlzIGVtcHR5IGFuZCB0aGUgY2hvb3NlciBkZWdyYWRlcy5cbiAgICAgIH1cbiAgICAgIC8vIEEgbGl2ZSByb2xlLWRvd25ncmFkZSByZS1hbm5vdW5jZXMgdGhlIG1vdW50IGFzIGByb2A7IHJlbW92YWwgdGVhcnMgaXQgZG93bi5cbiAgICAgIC8vIFRoZSBtb3VudCBzZXJ2aWNlIG5lZWRzIHRoZSBob3N0IHJ1bnRpbWUsIHdoaWNoIGlzIGFic2VudCB1bmRlciBsb2NhbFxuICAgICAgLy8gYHZpdGUgZGV2YCDigJQgdGhlcmUgdGhlIGJvYXJkIGlzIGEgc3RhdGljIG9uLWRpc2sgZGlyIHdpdGggbm8gcm9sZSBjaGFuZ2VzLFxuICAgICAgLy8gc28gc2tpcCB0aGUgc3Vic2NyaXB0aW9uIHJhdGhlciB0aGFuIGNyYXNoLlxuICAgICAgdHJ5IHtcbiAgICAgICAgdW5zdWIgPSBvbk1vdW50c0NoYW5nZSgobW91bnRzLCByZW1vdmVkKSA9PiB7XG4gICAgICAgICAgdXBkYXRlKHsgbW91bnRzIH0pO1xuICAgICAgICAgIGNvbnN0IGN1ciA9IGJvYXJkUmVmLmN1cnJlbnQ7XG4gICAgICAgICAgaWYgKCFjdXIpIHJldHVybjtcbiAgICAgICAgICBjb25zdCBtID0gbW91bnRzLmZpbmQoKHgpID0+IChjdXIuc3BhY2VJZCA/IHguaWQgPT09IGN1ci5zcGFjZUlkIDogeC5wYXRoID09PSBjdXIucm9vdCkpO1xuICAgICAgICAgIGlmIChtKSB7XG4gICAgICAgICAgICBjb25zdCBtb2RlID0gbS5tb2RlID09PSAncm8nID8gJ3JvJyA6ICdydyc7XG4gICAgICAgICAgICBpZiAobW9kZSAhPT0gY3VyLm1vZGUpIHtcbiAgICAgICAgICAgICAgYm9hcmRSZWYuY3VycmVudCA9IHsgLi4uY3VyLCBtb2RlIH07XG4gICAgICAgICAgICAgIGlmIChtb2RlID09PSAncm8nKSB7XG4gICAgICAgICAgICAgICAgdXBkYXRlKHsgbW9kZTogJ3J1bicsIHNlbGVjdGlvbjogW10sIGluc3BlY3Rvck9wZW46IGZhbHNlIH0pO1xuICAgICAgICAgICAgICAgIHRvYXN0KCdZb3VyIGFjY2VzcyBjaGFuZ2VkIHRvIHJlYWQtb25seS4nLCAnbG9jaycsIHsgaWNvbkNvbG9yOiAndmFyKC0taW5rLTIpJyB9KTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH0gZWxzZSBpZiAocmVtb3ZlZC5zb21lKChyKSA9PiAoY3VyLnNwYWNlSWQgPyByLmlkID09PSBjdXIuc3BhY2VJZCA6IHIucGF0aCA9PT0gY3VyLnJvb3QpKSkge1xuICAgICAgICAgICAgYm9hcmRSZWYuY3VycmVudCA9IG51bGw7XG4gICAgICAgICAgICB0b2FzdCgnQm9hcmQgc3BhY2UgZGlzY29ubmVjdGVkLicsICdhbGVydCcsIHsgaWNvbkNvbG9yOiAndmFyKC0taW5rLTIpJyB9KTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfSBjYXRjaCB7XG4gICAgICAgIC8vIE5vIGhvc3QgcnVudGltZSAobG9jYWwgYHZpdGUgZGV2YCk6IG5vIGxpdmUgbW91bnQgdXBkYXRlcyB0byB0cmFjay5cbiAgICAgIH1cbiAgICB9KSgpO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBjYW5jZWxsZWQgPSB0cnVlO1xuICAgICAgdW5zdWI/LigpO1xuICAgICAgZm9yIChjb25zdCBoIG9mIHRpbWVycy52YWx1ZXMoKSkgY2xlYXJUaW1lb3V0KGgpO1xuICAgICAgdGltZXJzLmNsZWFyKCk7XG4gICAgICBpZiAoaG9sZFRpbWVyLmN1cnJlbnQpIGNsZWFyVGltZW91dChob2xkVGltZXIuY3VycmVudCk7XG4gICAgICBob2xkVGltZXIuY3VycmVudCA9IG51bGw7XG4gICAgfTtcbiAgICAvLyBSdW5zIG9uY2Ugb24gbW91bnQ7IHJlYWRzIGxpdmUgc3RhdGUgdmlhIHN0YXRlUmVmIGFuZCBzdGFibGUgY2FsbGJhY2tzLlxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9leGhhdXN0aXZlLWRlcHNcbiAgfSwgW10pO1xuXG4gIHJldHVybiB7XG4gICAgc3RhdGUsXG4gICAgcmVnaXN0ZXJDYW52YXMsXG4gICAgYm9hcmRSb290OiBib2FyZFJlZi5jdXJyZW50Py5yb290ID8/IG51bGwsXG4gICAgaXNNb2JpbGUsXG4gICAgLy8gY2FtZXJhXG4gICAgb3JpZ2luWDogKHZ3OiBudW1iZXIpID0+IG9yaWdpblgoc3RhdGUuY2FtLCB2dyksXG4gICAgb3JpZ2luWTogKHZoOiBudW1iZXIpID0+IG9yaWdpblkoc3RhdGUuY2FtLCB2aCksXG4gICAgcHJvamVjdDogKHd4OiBudW1iZXIsIHd5OiBudW1iZXIpID0+IHByb2plY3Qoc3RhdGUuY2FtLCBzdGF0ZS52cCwgd3gsIHd5KSxcbiAgICBzZXRab29tLFxuICAgIGNsYW1wWm9vbSxcbiAgICBmbHlUbyxcbiAgICBhbmNob3JQb2ludCxcbiAgICAvLyBnZXN0dXJlc1xuICAgIG9uQ2FudmFzRG93bixcbiAgICBvbkNhbnZhc0RibENsaWNrLFxuICAgIG9ialBvaW50ZXJEb3duLFxuICAgIHN0YXJ0SGFuZGxlLFxuICAgIHN0YXJ0Q29ubmVjdCxcbiAgICBzZXRIb3ZlcixcbiAgICBjbGVhclNlbGVjdGlvbixcbiAgICBzZWxlY3QsXG4gICAgY2xvc2VRdWlja01lbnUsXG4gICAgLy8ga2V5Ym9hcmQgY29ubmVjdCAodGhlIG5vbi1kcmFnIHBhdGgpXG4gICAgYmVnaW5Db25uZWN0LFxuICAgIGVuZENvbm5lY3QsXG4gICAgbW92ZUNvbm5lY3RDdXJzb3IsXG4gICAgLy8gbXV0YXRpb25zXG4gICAgcGF0Y2hTZWwsXG4gICAgcGF0Y2hPYmplY3QsXG4gICAgZGVsZXRlU2VsZWN0aW9uLFxuICAgIGNyZWF0ZU9iamVjdCxcbiAgICAvLyBwaWNrLWZpbGUgZmxvd3NcbiAgICBpbnNlcnRJbWFnZSxcbiAgICBvcGVuQm9hcmQsXG4gICAgb3BlbkJvYXJkQXQsXG4gICAgbmV3Qm9hcmQsXG4gICAgbmV3Qm9hcmRJbixcbiAgICBvcGVuQm9hcmRJbixcbiAgICBhZGRTcGFjZSxcbiAgICAvLyB2aWV3cyAmIGpvdXJuZXlzXG4gICAgc2F2ZVZpZXcsXG4gICAgZGVsZXRlVmlldyxcbiAgICBhZGRKb3VybmV5U3RlcCxcbiAgICByZXNvbHZlVmlldyxcbiAgICBwbGF5Sm91cm5leSxcbiAgICBwbGF5TmV4dCxcbiAgICBwbGF5UHJldixcbiAgICBwbGF5RXhpdCxcbiAgICBwbGF5U2VlayxcbiAgICAvLyBtb2RlIC8gY2hyb21lXG4gICAgc2V0UnVuLFxuICAgIHNldEVkaXQsXG4gICAgdG9nZ2xlVGhlbWUsXG4gICAgdG9nZ2xlUGFuZWwsXG4gICAgY2xvc2VJbnNwZWN0b3IsXG4gICAgY2xvc2VQYW5lbCxcbiAgICBzZXRCYWNrZ3JvdW5kLFxuICAgIHNldExpZ2h0LFxuICAgIHNldFNjcmVlbixcbiAgICB0b2dnbGVEZW1vTWVudSxcbiAgICAvLyB0b2FzdHMgKyBkZW1vXG4gICAgdG9hc3QsXG4gICAgZGlzbWlzc1RvYXN0LFxuICAgIGRlbW9MV1csXG4gICAgZGVtb0Rvd25ncmFkZSxcbiAgfTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7QUFPQSxJQUFBQSxNQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxPQUFBLEdBQUFELE9BQUE7QUFVQSxJQUFBRSxTQUFBLEdBQUFGLE9BQUE7QUFDQSxJQUFBRyxJQUFBLEdBQUFILE9BQUE7QUFjQSxJQUFBSSxVQUFBLEdBQUFKLE9BQUE7QUFDQSxJQUFBSyxXQUFBLEdBQUFMLE9BQUE7QUFpQkEsSUFBQU0sU0FBQSxHQUFBTixPQUFBO0FBSUEsSUFBQU8sT0FBQSxHQUFBUCxPQUFBO0FBRUEsSUFBQVEsWUFBQSxHQUFBUixPQUFBO0FBekRBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUErQ0E7QUFDQTtBQUNBOztBQVdBO0FBQ0EsTUFBTVMsT0FBTyxHQUFHQSxDQUFDQyxJQUFZLEVBQUVDLEdBQVcsS0FBYSxHQUFHRCxJQUFJLElBQUlDLEdBQUcsRUFBRSxDQUFDQyxPQUFPLENBQUMsTUFBTSxFQUFFLEdBQUcsQ0FBQzs7QUFFNUY7QUFDQSxTQUFTQyxNQUFNQSxDQUFDQyxDQUFVLEVBQVU7RUFDbEMsTUFBTUMsQ0FBQyxHQUFJRCxDQUFDLEVBQStCRSxJQUFJO0VBQy9DLE9BQU9ELENBQUMsR0FBRyxNQUFNQSxDQUFDLEVBQUUsR0FBRyxFQUFFO0FBQzNCO0FBNkNBLE1BQU1FLGVBQWUsR0FBR0EsQ0FBQSxNQUFpQjtFQUN2Q0MsRUFBRSxFQUFFLE9BQU9DLE1BQU0sS0FBSyxXQUFXLEdBQUdBLE1BQU0sQ0FBQ0MsVUFBVSxHQUFHLElBQUk7RUFDNURDLEVBQUUsRUFBRSxPQUFPRixNQUFNLEtBQUssV0FBVyxHQUFHQSxNQUFNLENBQUNHLFdBQVcsR0FBRyxHQUFHO0VBQzVEQyxLQUFLLEVBQUUsQ0FBQztFQUNSQyxJQUFJLEVBQUU7QUFDUixDQUFDLENBQUM7O0FBRUY7QUFDQTtBQUNBO0FBQ08sU0FBU0MsY0FBY0EsQ0FBQ0MsR0FBYSxFQUFFQyxFQUFVLEVBQUVDLFFBQWlCLEVBQVk7RUFDckYsSUFBSUEsUUFBUSxFQUFFLE9BQU9GLEdBQUcsQ0FBQ0csUUFBUSxDQUFDRixFQUFFLENBQUMsR0FBR0QsR0FBRyxDQUFDSSxNQUFNLENBQUVDLENBQUMsSUFBS0EsQ0FBQyxLQUFLSixFQUFFLENBQUMsR0FBR0QsR0FBRyxDQUFDTSxNQUFNLENBQUNMLEVBQUUsQ0FBQztFQUNwRixPQUFPRCxHQUFHLENBQUNHLFFBQVEsQ0FBQ0YsRUFBRSxDQUFDLEdBQUdELEdBQUcsR0FBRyxDQUFDQyxFQUFFLENBQUM7QUFDdEM7QUFFQSxNQUFNTSxpQkFBaUIsR0FBRyxHQUFHOztBQUU3QjtBQUNBO0FBQ0E7QUFDQSxNQUFNQyxnQkFBZ0IsR0FBRyxDQUFDOztBQUUxQjtBQUNBO0FBQ0E7QUFDQSxNQUFNQyxpQkFBaUIsR0FBRyxHQUFHO0FBRTdCLE1BQU1DLG9CQUFvQixHQUFHQSxDQUFBLEtBQWU7RUFDMUMsSUFBSTtJQUNGLE9BQU9qQixNQUFNLENBQUNrQixVQUFVLENBQUMsa0NBQWtDLENBQUMsQ0FBQ0MsT0FBTztFQUN0RSxDQUFDLENBQUMsTUFBTTtJQUNOLE9BQU8sS0FBSztFQUNkO0FBQ0YsQ0FBQzs7QUFFRDtBQUNBO0FBQ0E7QUFDTyxNQUFNQyxXQUFXLEdBQUFDLE9BQUEsQ0FBQUQsV0FBQSxHQUFHO0VBQ3pCLGNBQWMsRUFBRSxlQUFlO0VBQy9CLFdBQVcsRUFBRSxpQkFBaUI7RUFDOUIsWUFBWSxFQUFFO0FBQ2hCLENBQVU7QUFFSCxTQUFTRSxXQUFXQSxDQUFBLEVBQUc7RUFDNUI7RUFDQTtFQUNBLE1BQU0sQ0FBQ0MsUUFBUSxFQUFFQyxXQUFXLENBQUMsR0FBRyxJQUFBQyxlQUFRLEVBQXdCLElBQUksQ0FBQztFQUNyRSxNQUFNQyxjQUFjLEdBQUcsSUFBQUMsa0JBQVcsRUFBRUMsRUFBeUIsSUFBS0osV0FBVyxDQUFDSSxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUM7RUFDdEYsTUFBTUMsT0FBTyxHQUFHLElBQUFDLGFBQU0sRUFBTyxJQUFJLENBQUM7RUFDbEMsTUFBTUMsUUFBUSxHQUFHLElBQUFELGFBQU0sRUFBZ0IsSUFBSSxDQUFDO0VBQzVDLE1BQU1FLFNBQVMsR0FBRyxJQUFBRixhQUFNLEVBQWdCLElBQUksQ0FBQztFQUM3QyxNQUFNRyxRQUFRLEdBQUcsSUFBQUgsYUFBTSxFQUFDLEtBQUssQ0FBQztFQUM5QixNQUFNSSxRQUFRLEdBQUcsSUFBQUosYUFBTSxFQUFDLENBQUMsQ0FBQztFQUMxQjtFQUNBO0VBQ0E7RUFDQSxNQUFNSyxXQUFXLEdBQUcsSUFBQUwsYUFBTSxFQUFhLE1BQU0sQ0FBQyxDQUFDLENBQUM7RUFFaEQsTUFBTSxDQUFDTSxLQUFLLEVBQUVDLFFBQVEsQ0FBQyxHQUFHLElBQUFaLGVBQVEsRUFBVSxPQUFPO0lBQ2pEYSxJQUFJLEVBQUUsS0FBSztJQUNYQyxLQUFLLEVBQUUsS0FBSztJQUNaQyxFQUFFLEVBQUVDLGdCQUFLLENBQUNDLFVBQVU7SUFDcEJDLEtBQUssRUFBRUYsZ0JBQUssQ0FBQ0UsS0FBSztJQUNsQkMsR0FBRyxFQUFFO01BQUVDLEVBQUUsRUFBRSxHQUFHO01BQUVDLEVBQUUsRUFBRSxHQUFHO01BQUVDLElBQUksRUFBRTtJQUFJLENBQUM7SUFDcENDLEVBQUUsRUFBRWxELGVBQWUsQ0FBQyxDQUFDO0lBQ3JCbUQsT0FBTyxFQUFFLElBQUFDLHNCQUFXLEVBQUMsQ0FBQztJQUN0QkMsS0FBSyxFQUFFQyxxQkFBVSxDQUFDQyxLQUFLLENBQUMsQ0FBQztJQUN6QkMsUUFBUSxFQUFFQyx3QkFBYTtJQUN2QkMsU0FBUyxFQUFFLEVBQUU7SUFDYkMsS0FBSyxFQUFFLElBQUk7SUFDWEMsT0FBTyxFQUFFLElBQUk7SUFDYkMsY0FBYyxFQUFFLElBQUk7SUFDcEJDLFdBQVcsRUFBRSxJQUFJO0lBQ2pCQyxhQUFhLEVBQUUsSUFBSTtJQUNuQkMsYUFBYSxFQUFFLEtBQUs7SUFDcEJDLFNBQVMsRUFBRSxLQUFLO0lBQ2hCQyxTQUFTLEVBQUUsSUFBSTtJQUNmQyxPQUFPLEVBQUUsSUFBSTtJQUNiQyxNQUFNLEVBQUUsRUFBRTtJQUNWQyxNQUFNLEVBQUUsSUFBSTtJQUNaQyxZQUFZLEVBQUUsS0FBSztJQUNuQkMsT0FBTyxFQUFFLEtBQUs7SUFDZEMsT0FBTyxFQUFFckQsb0JBQW9CLENBQUMsQ0FBQztJQUMvQnNELElBQUksRUFBRSxJQUFJO0lBQ1ZDLE1BQU0sRUFBRTtFQUNWLENBQUMsQ0FBQyxDQUFDOztFQUVIO0VBQ0EsTUFBTUMsUUFBUSxHQUFHLElBQUEzQyxhQUFNLEVBQUNNLEtBQUssQ0FBQztFQUM5QixJQUFBc0MsZ0JBQVMsRUFBQyxNQUFNO0lBQ2RELFFBQVEsQ0FBQ0UsT0FBTyxHQUFHdkMsS0FBSztFQUMxQixDQUFDLENBQUM7RUFFRixNQUFNd0MsTUFBTSxHQUFHLElBQUFqRCxrQkFBVyxFQUN2QmtELEtBQTRELElBQzNEeEMsUUFBUSxDQUFFeUMsSUFBSSxLQUFNO0lBQUUsR0FBR0EsSUFBSTtJQUFFLElBQUksT0FBT0QsS0FBSyxLQUFLLFVBQVUsR0FBR0EsS0FBSyxDQUFDQyxJQUFJLENBQUMsR0FBR0QsS0FBSztFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQzNGLEVBQ0YsQ0FBQztFQUVELE1BQU1FLFFBQVEsR0FBRyxJQUFBcEQsa0JBQVcsRUFBQyxNQUFNUyxLQUFLLENBQUNZLEVBQUUsQ0FBQ2pELEVBQUUsR0FBR2UsaUJBQWlCLEVBQUUsQ0FBQ3NCLEtBQUssQ0FBQ1ksRUFBRSxDQUFDakQsRUFBRSxDQUFDLENBQUM7O0VBRWxGO0VBQ0EsTUFBTWlGLFVBQVUsR0FBRyxJQUFBckQsa0JBQVcsRUFBRWhDLENBQXVDLElBQXVCO0lBQzVGLE1BQU1xRCxFQUFFLEdBQUd5QixRQUFRLENBQUNFLE9BQU8sQ0FBQzNCLEVBQUU7SUFDOUIsT0FBTyxDQUFDckQsQ0FBQyxDQUFDc0YsT0FBTyxHQUFHakMsRUFBRSxDQUFDNUMsS0FBSyxFQUFFVCxDQUFDLENBQUN1RixPQUFPLEdBQUdsQyxFQUFFLENBQUMzQyxJQUFJLENBQUM7RUFDcEQsQ0FBQyxFQUFFLEVBQUUsQ0FBQztFQUVOLE1BQU04RSxPQUFPLEdBQUcsSUFBQXhELGtCQUFXLEVBQUMsQ0FBQ3lELEVBQVUsRUFBRUMsRUFBVyxFQUFFQyxFQUFXLEtBQUs7SUFDcEVWLE1BQU0sQ0FBRVcsQ0FBQyxLQUFNO01BQUUzQyxHQUFHLEVBQUUsSUFBQTRDLGtCQUFVLEVBQUNELENBQUMsQ0FBQzNDLEdBQUcsRUFBRTJDLENBQUMsQ0FBQ3ZDLEVBQUUsRUFBRW9DLEVBQUUsRUFBRUMsRUFBRSxFQUFFQyxFQUFFO0lBQUUsQ0FBQyxDQUFDLENBQUM7RUFDL0QsQ0FBQyxFQUFFLENBQUNWLE1BQU0sQ0FBQyxDQUFDOztFQUVaO0VBQ0EsTUFBTWEsWUFBWSxHQUFHLElBQUE5RCxrQkFBVyxFQUFFbkIsRUFBVSxJQUFLO0lBQy9Db0UsTUFBTSxDQUFFVyxDQUFDLEtBQU07TUFBRXJCLE1BQU0sRUFBRXFCLENBQUMsQ0FBQ3JCLE1BQU0sQ0FBQ3ZELE1BQU0sQ0FBRStFLENBQUMsSUFBS0EsQ0FBQyxDQUFDbEYsRUFBRSxLQUFLQSxFQUFFO0lBQUUsQ0FBQyxDQUFDLENBQUM7RUFDbEUsQ0FBQyxFQUFFLENBQUNvRSxNQUFNLENBQUMsQ0FBQztFQUVaLE1BQU1lLEtBQUssR0FBRyxJQUFBaEUsa0JBQVcsRUFDdkIsQ0FBQ2lFLElBQVksRUFBRUMsSUFBSSxHQUFHLE9BQU8sRUFBRUMsSUFBb0IsR0FBRyxDQUFDLENBQUMsS0FBSztJQUMzRCxNQUFNdEYsRUFBRSxHQUFHLEVBQUUwQixRQUFRLENBQUN5QyxPQUFPO0lBQzdCLE1BQU1lLENBQVEsR0FBRztNQUFFbEYsRUFBRTtNQUFFb0YsSUFBSTtNQUFFQyxJQUFJO01BQUUsR0FBR0M7SUFBSyxDQUFDO0lBQzVDbEIsTUFBTSxDQUFFVyxDQUFDLEtBQU07TUFBRXJCLE1BQU0sRUFBRXFCLENBQUMsQ0FBQ3JCLE1BQU0sQ0FBQ3JELE1BQU0sQ0FBQzZFLENBQUM7SUFBRSxDQUFDLENBQUMsQ0FBQztJQUMvQyxNQUFNSyxHQUFHLEdBQUdELElBQUksQ0FBQ0UsV0FBVyxHQUFHLElBQUksR0FBRyxJQUFJO0lBQzFDQyxVQUFVLENBQUMsTUFBTVIsWUFBWSxDQUFDakYsRUFBRSxDQUFDLEVBQUV1RixHQUFHLENBQUM7RUFDekMsQ0FBQyxFQUNELENBQUNuQixNQUFNLEVBQUVhLFlBQVksQ0FDdkIsQ0FBQzs7RUFFRDtFQUNBO0VBQ0E7RUFDQSxNQUFNUyxRQUFRLEdBQUcsSUFBQXBFLGFBQU0sRUFBcUIsSUFBSSxDQUFDO0VBQ2pEO0VBQ0E7RUFDQSxNQUFNcUUsVUFBVSxHQUFHLElBQUFyRSxhQUFNLEVBQXNCLElBQUlzRSxHQUFHLENBQUMsQ0FBQyxDQUFDOztFQUV6RDtFQUNBO0VBQ0E7RUFDQSxNQUFNQyxVQUFVLEdBQUcsSUFBQTFFLGtCQUFXLEVBQzVCLENBQUMyRSxJQUFlLEVBQUVDLFNBQWlCLEVBQUVDLFNBQVMsR0FBRyxPQUFPLEtBQUs7SUFDM0QsTUFBTWQsQ0FBQyxHQUFHUSxRQUFRLENBQUN2QixPQUFPO0lBQzFCLElBQUksQ0FBQ2UsQ0FBQyxFQUFFO01BQ05DLEtBQUssQ0FBQ1ksU0FBUyxFQUFFQyxTQUFTLENBQUM7TUFDM0I7SUFDRjtJQUNBLElBQUlkLENBQUMsQ0FBQ3BELElBQUksS0FBSyxJQUFJLEVBQUU7TUFDbkJxRCxLQUFLLENBQUMsb0NBQW9DLEVBQUUsTUFBTSxFQUFFO1FBQUVjLFNBQVMsRUFBRTtNQUFlLENBQUMsQ0FBQztNQUNsRjtJQUNGO0lBQ0FDLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDTCxJQUFJLENBQUNNLEdBQUcsQ0FBRUMsQ0FBQyxJQUFLLElBQUFDLHNCQUFVLEVBQUNwQixDQUFDLEVBQUVtQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUNFLElBQUksQ0FDakQsTUFBTXBCLEtBQUssQ0FBQ1ksU0FBUyxFQUFFQyxTQUFTLENBQUMsRUFDaEM3RyxDQUFDLElBQUtnRyxLQUFLLENBQUMsY0FBY2pHLE1BQU0sQ0FBQ0MsQ0FBQyxDQUFDLEVBQUUsRUFBRSxPQUFPLEVBQUU7TUFBRThHLFNBQVMsRUFBRTtJQUFVLENBQUMsQ0FDM0UsQ0FBQztFQUNILENBQUMsRUFDRCxDQUFDZCxLQUFLLENBQ1IsQ0FBQzs7RUFFRDtFQUNBLE1BQU1xQixZQUFZLEdBQUcsSUFBQXJGLGtCQUFXLEVBQUVzRixHQUFhLElBQUs7SUFDbEQsTUFBTXZCLENBQUMsR0FBR1EsUUFBUSxDQUFDdkIsT0FBTztJQUMxQixJQUFJLENBQUNlLENBQUMsSUFBSUEsQ0FBQyxDQUFDcEQsSUFBSSxLQUFLLElBQUksRUFBRTtJQUMzQixLQUFLLE1BQU05QixFQUFFLElBQUl5RyxHQUFHLEVBQUU7TUFDcEIsTUFBTW5DLElBQUksR0FBR3FCLFVBQVUsQ0FBQ3hCLE9BQU8sQ0FBQ3VDLEdBQUcsQ0FBQzFHLEVBQUUsQ0FBQztNQUN2QyxJQUFJc0UsSUFBSSxFQUFFcUMsWUFBWSxDQUFDckMsSUFBSSxDQUFDO01BQzVCLE1BQU1zQyxNQUFNLEdBQUdwSCxNQUFNLENBQUNpRyxVQUFVLENBQUMsTUFBTTtRQUNyQ0UsVUFBVSxDQUFDeEIsT0FBTyxDQUFDMEMsTUFBTSxDQUFDN0csRUFBRSxDQUFDO1FBQzdCLE1BQU1xRyxDQUFDLEdBQUdwQyxRQUFRLENBQUNFLE9BQU8sQ0FBQzFCLE9BQU8sQ0FBQ3FFLElBQUksQ0FBRTFHLENBQUMsSUFBS0EsQ0FBQyxDQUFDSixFQUFFLEtBQUtBLEVBQUUsQ0FBQztRQUMzRCxJQUFJcUcsQ0FBQyxFQUFFLElBQUFDLHNCQUFVLEVBQUNwQixDQUFDLEVBQUVtQixDQUFDLENBQUMsQ0FBQ1UsS0FBSyxDQUFDLE1BQU1DLFNBQVMsQ0FBQztNQUNoRCxDQUFDLEVBQUUsR0FBRyxDQUFDO01BQ1ByQixVQUFVLENBQUN4QixPQUFPLENBQUM4QyxHQUFHLENBQUNqSCxFQUFFLEVBQUU0RyxNQUFNLENBQUM7SUFDcEM7RUFDRixDQUFDLEVBQUUsRUFBRSxDQUFDOztFQUVOO0VBQ0EsTUFBTU0sS0FBSyxHQUFHLElBQUEvRixrQkFBVyxFQUN2QixDQUFDZ0csTUFBeUIsRUFBRUMsR0FBWSxFQUFFQyxJQUFhLEtBQUs7SUFDMUQsSUFBSSxDQUFDRixNQUFNLEVBQUU7SUFDYjtJQUNBO0lBQ0E7SUFDQSxNQUFNRyxJQUFJLEdBQUcsSUFBQUMsdUJBQWUsRUFBQ0osTUFBTSxFQUFFbEQsUUFBUSxDQUFDRSxPQUFPLENBQUMzQixFQUFFLENBQUNqRCxFQUFFLEVBQUU4SCxJQUFJLElBQUlwRCxRQUFRLENBQUNFLE9BQU8sQ0FBQzNCLEVBQUUsQ0FBQzlDLEVBQUUsQ0FBQztJQUM1RixJQUFJNkIsUUFBUSxDQUFDNEMsT0FBTyxFQUFFcUQsb0JBQW9CLENBQUNqRyxRQUFRLENBQUM0QyxPQUFPLENBQUM7SUFDNUQsSUFBSUYsUUFBUSxDQUFDRSxPQUFPLENBQUNMLE9BQU8sSUFBSSxDQUFDc0QsR0FBRyxFQUFFO01BQ3BDaEQsTUFBTSxDQUFDO1FBQUVoQyxHQUFHLEVBQUVrRjtNQUFLLENBQUMsQ0FBQztNQUNyQjtJQUNGO0lBQ0EsTUFBTUcsSUFBSSxHQUFHO01BQUUsR0FBR3hELFFBQVEsQ0FBQ0UsT0FBTyxDQUFDL0I7SUFBSSxDQUFDO0lBQ3hDLE1BQU1zRixFQUFFLEdBQUdDLFdBQVcsQ0FBQ0MsR0FBRyxDQUFDLENBQUM7SUFDNUIsTUFBTUMsSUFBSSxHQUFJQyxDQUFTLElBQU1BLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxHQUFHQSxDQUFDLEdBQUdBLENBQUMsR0FBR0EsQ0FBQyxHQUFHLENBQUMsR0FBR0MsSUFBSSxDQUFDQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUdGLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBRTtJQUN2RixNQUFNRyxJQUFJLEdBQUlMLEdBQVcsSUFBSztNQUM1QixNQUFNRSxDQUFDLEdBQUdDLElBQUksQ0FBQ0csR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDTixHQUFHLEdBQUdGLEVBQUUsSUFBSU4sR0FBRyxDQUFDO01BQ3ZDLE1BQU1qSSxDQUFDLEdBQUcwSSxJQUFJLENBQUNDLENBQUMsQ0FBQztNQUNqQjFELE1BQU0sQ0FBQztRQUNMaEMsR0FBRyxFQUFFO1VBQ0hDLEVBQUUsRUFBRW9GLElBQUksQ0FBQ3BGLEVBQUUsR0FBRyxDQUFDaUYsSUFBSSxDQUFDakYsRUFBRSxHQUFHb0YsSUFBSSxDQUFDcEYsRUFBRSxJQUFJbEQsQ0FBQztVQUNyQ21ELEVBQUUsRUFBRW1GLElBQUksQ0FBQ25GLEVBQUUsR0FBRyxDQUFDZ0YsSUFBSSxDQUFDaEYsRUFBRSxHQUFHbUYsSUFBSSxDQUFDbkYsRUFBRSxJQUFJbkQsQ0FBQztVQUNyQ29ELElBQUksRUFBRWtGLElBQUksQ0FBQ2xGLElBQUksR0FBRyxDQUFDK0UsSUFBSSxDQUFDL0UsSUFBSSxHQUFHa0YsSUFBSSxDQUFDbEYsSUFBSSxJQUFJcEQ7UUFDOUM7TUFDRixDQUFDLENBQUM7TUFDRixJQUFJMkksQ0FBQyxHQUFHLENBQUMsRUFBRXZHLFFBQVEsQ0FBQzRDLE9BQU8sR0FBR2dFLHFCQUFxQixDQUFDRixJQUFJLENBQUM7SUFDM0QsQ0FBQztJQUNEMUcsUUFBUSxDQUFDNEMsT0FBTyxHQUFHZ0UscUJBQXFCLENBQUNGLElBQUksQ0FBQztFQUNoRCxDQUFDLEVBQ0QsQ0FBQzdELE1BQU0sQ0FDVCxDQUFDOztFQUVEO0VBQ0EsTUFBTWdFLFdBQVcsR0FBRyxJQUFBakgsa0JBQVcsRUFBRWtILENBQXNCLElBQUs7SUFDMUQsSUFBSSxPQUFPQSxDQUFDLEtBQUssUUFBUSxFQUFFLE9BQU9wRSxRQUFRLENBQUNFLE9BQU8sQ0FBQ3hCLEtBQUssQ0FBQ21FLElBQUksQ0FBRTFHLENBQUMsSUFBS0EsQ0FBQyxDQUFDa0ksSUFBSSxLQUFLRCxDQUFDLENBQUMsSUFBSSxJQUFJO0lBQzFGLE1BQU1uRCxDQUFhLEdBQUc7TUFBRTdDLEVBQUUsRUFBRWdHLENBQUMsQ0FBQ2hHLEVBQUU7TUFBRUMsRUFBRSxFQUFFK0YsQ0FBQyxDQUFDL0YsRUFBRTtNQUFFQyxJQUFJLEVBQUU4RixDQUFDLENBQUM5RjtJQUFLLENBQUM7SUFDMUQsSUFBSThGLENBQUMsQ0FBQ0UsQ0FBQyxFQUFFckQsQ0FBQyxDQUFDcUQsQ0FBQyxHQUFHRixDQUFDLENBQUNFLENBQUM7SUFDbEIsSUFBSUYsQ0FBQyxDQUFDRyxDQUFDLEVBQUV0RCxDQUFDLENBQUNzRCxDQUFDLEdBQUdILENBQUMsQ0FBQ0csQ0FBQztJQUNsQixPQUFPdEQsQ0FBQztFQUNWLENBQUMsRUFBRSxFQUFFLENBQUM7RUFFTixNQUFNdUQsUUFBUSxHQUFHLElBQUF0SCxrQkFBVyxFQUFDLE1BQU07SUFDakMsTUFBTTRELENBQUMsR0FBR2QsUUFBUSxDQUFDRSxPQUFPO0lBQzFCLE1BQU11RSxJQUFVLEdBQUc7TUFBRUosSUFBSSxFQUFFLFFBQVF2RCxDQUFDLENBQUNwQyxLQUFLLENBQUNnRyxNQUFNLEdBQUcsQ0FBQyxFQUFFO01BQUV0RyxFQUFFLEVBQUUwQyxDQUFDLENBQUMzQyxHQUFHLENBQUNDLEVBQUU7TUFBRUMsRUFBRSxFQUFFeUMsQ0FBQyxDQUFDM0MsR0FBRyxDQUFDRSxFQUFFO01BQUVDLElBQUksRUFBRXdDLENBQUMsQ0FBQzNDLEdBQUcsQ0FBQ0c7SUFBSyxDQUFDO0lBQ3ZHNkIsTUFBTSxDQUFFd0UsRUFBRSxLQUFNO01BQUVqRyxLQUFLLEVBQUVpRyxFQUFFLENBQUNqRyxLQUFLLENBQUN0QyxNQUFNLENBQUMsQ0FBQ3FJLElBQUksQ0FBQztJQUFFLENBQUMsQ0FBQyxDQUFDO0lBQ3BELE1BQU10RCxJQUFJLEdBQUcsZUFBZXNELElBQUksQ0FBQ0osSUFBSSxLQUFLO0lBQzFDLE1BQU1wRCxDQUFDLEdBQUdRLFFBQVEsQ0FBQ3ZCLE9BQU87SUFDMUIsSUFBSSxDQUFDZSxDQUFDLEVBQUU7TUFDTkMsS0FBSyxDQUFDQyxJQUFJLEVBQUUsTUFBTSxDQUFDO01BQ25CO0lBQ0Y7SUFDQSxJQUFJRixDQUFDLENBQUNwRCxJQUFJLEtBQUssSUFBSSxFQUFFO01BQ25CcUQsS0FBSyxDQUFDLGtDQUFrQyxFQUFFLE1BQU0sRUFBRTtRQUFFYyxTQUFTLEVBQUU7TUFBZSxDQUFDLENBQUM7TUFDaEY7SUFDRjtJQUNBLElBQUE0QyxvQkFBVyxFQUFDM0QsQ0FBQyxFQUFFd0QsSUFBSSxDQUFDLENBQUNuQyxJQUFJLENBQ3ZCLE1BQU1wQixLQUFLLENBQUNDLElBQUksRUFBRSxNQUFNLENBQUMsRUFDeEJqRyxDQUFDLElBQUtnRyxLQUFLLENBQUMscUJBQXFCakcsTUFBTSxDQUFDQyxDQUFDLENBQUMsRUFBRSxFQUFFLE9BQU8sRUFBRTtNQUFFOEcsU0FBUyxFQUFFO0lBQVUsQ0FBQyxDQUNsRixDQUFDO0VBQ0gsQ0FBQyxFQUFFLENBQUM3QixNQUFNLEVBQUVlLEtBQUssQ0FBQyxDQUFDOztFQUVuQjtBQUNGO0FBQ0E7QUFDQTtFQUNFLE1BQU0yRCxVQUFVLEdBQUcsSUFBQTNILGtCQUFXLEVBQzNCbUgsSUFBWSxJQUFLO0lBQ2hCLE1BQU1wRCxDQUFDLEdBQUdRLFFBQVEsQ0FBQ3ZCLE9BQU87SUFDMUIsTUFBTXVFLElBQUksR0FBR3pFLFFBQVEsQ0FBQ0UsT0FBTyxDQUFDeEIsS0FBSyxDQUFDbUUsSUFBSSxDQUFFdUIsQ0FBQyxJQUFLQSxDQUFDLENBQUNDLElBQUksS0FBS0EsSUFBSSxDQUFDO0lBQ2hFLElBQUksQ0FBQ0ksSUFBSSxFQUFFO0lBQ1gsSUFBSXhELENBQUMsSUFBSUEsQ0FBQyxDQUFDcEQsSUFBSSxLQUFLLElBQUksRUFBRTtNQUN4QnFELEtBQUssQ0FBQyxvQ0FBb0MsRUFBRSxNQUFNLEVBQUU7UUFBRWMsU0FBUyxFQUFFO01BQWUsQ0FBQyxDQUFDO01BQ2xGO0lBQ0Y7SUFDQTdCLE1BQU0sQ0FBRVcsQ0FBQyxLQUFNO01BQUVwQyxLQUFLLEVBQUVvQyxDQUFDLENBQUNwQyxLQUFLLENBQUN4QyxNQUFNLENBQUVrSSxDQUFDLElBQUtBLENBQUMsQ0FBQ0MsSUFBSSxLQUFLQSxJQUFJO0lBQUUsQ0FBQyxDQUFDLENBQUM7SUFDbEUsSUFBSSxDQUFDcEQsQ0FBQyxFQUFFO01BQ05DLEtBQUssQ0FBQyxpQkFBaUJtRCxJQUFJLEtBQUssRUFBRSxPQUFPLENBQUM7TUFDMUM7SUFDRjtJQUNBLElBQUFTLHNCQUFVLEVBQUM3RCxDQUFDLEVBQUVvRCxJQUFJLENBQUMsQ0FBQy9CLElBQUksQ0FDdEIsTUFBTXBCLEtBQUssQ0FBQyxpQkFBaUJtRCxJQUFJLEtBQUssRUFBRSxPQUFPLENBQUMsRUFDL0NuSixDQUFDLElBQUs7TUFDTDtNQUNBaUYsTUFBTSxDQUFFVyxDQUFDLElBQU1BLENBQUMsQ0FBQ3BDLEtBQUssQ0FBQ3FHLElBQUksQ0FBRVgsQ0FBQyxJQUFLQSxDQUFDLENBQUNDLElBQUksS0FBS0EsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUc7UUFBRTNGLEtBQUssRUFBRW9DLENBQUMsQ0FBQ3BDLEtBQUssQ0FBQ3RDLE1BQU0sQ0FBQyxDQUFDcUksSUFBSSxDQUFDO01BQUUsQ0FBRSxDQUFDO01BQzlGdkQsS0FBSyxDQUFDLHVCQUF1QmpHLE1BQU0sQ0FBQ0MsQ0FBQyxDQUFDLEVBQUUsRUFBRSxPQUFPLEVBQUU7UUFBRThHLFNBQVMsRUFBRTtNQUFVLENBQUMsQ0FBQztJQUM5RSxDQUNGLENBQUM7RUFDSCxDQUFDLEVBQ0QsQ0FBQzdCLE1BQU0sRUFBRWUsS0FBSyxDQUNoQixDQUFDO0VBRUQsTUFBTThELGNBQWMsR0FBRyxJQUFBOUgsa0JBQVcsRUFDL0IrSCxHQUFXLElBQUs7SUFDZixNQUFNbkUsQ0FBQyxHQUFHZCxRQUFRLENBQUNFLE9BQU87SUFDMUIsTUFBTWdGLENBQUMsR0FBR3BFLENBQUMsQ0FBQ2pDLFFBQVEsQ0FBQ2dFLElBQUksQ0FBRTFHLENBQUMsSUFBS0EsQ0FBQyxDQUFDSixFQUFFLEtBQUtrSixHQUFHLENBQUM7SUFDOUMsSUFBSSxDQUFDQyxDQUFDLEVBQUU7SUFDUixNQUFNQyxJQUFhLEdBQUc7TUFBRSxHQUFHRCxDQUFDO01BQUVFLEtBQUssRUFBRUYsQ0FBQyxDQUFDRSxLQUFLLENBQUNoSixNQUFNLENBQUMsQ0FBQztRQUFFcUksSUFBSSxFQUFFO1VBQUVyRyxFQUFFLEVBQUUwQyxDQUFDLENBQUMzQyxHQUFHLENBQUNDLEVBQUU7VUFBRUMsRUFBRSxFQUFFeUMsQ0FBQyxDQUFDM0MsR0FBRyxDQUFDRSxFQUFFO1VBQUVDLElBQUksRUFBRXdDLENBQUMsQ0FBQzNDLEdBQUcsQ0FBQ0c7UUFBSztNQUFFLENBQUMsQ0FBQztJQUFFLENBQUM7SUFDbkg2QixNQUFNLENBQUV3RSxFQUFFLEtBQU07TUFBRTlGLFFBQVEsRUFBRThGLEVBQUUsQ0FBQzlGLFFBQVEsQ0FBQ3NELEdBQUcsQ0FBRWhHLENBQUMsSUFBTUEsQ0FBQyxDQUFDSixFQUFFLEtBQUtrSixHQUFHLEdBQUdFLElBQUksR0FBR2hKLENBQUU7SUFBRSxDQUFDLENBQUMsQ0FBQztJQUNqRixNQUFNZ0YsSUFBSSxHQUFHLGNBQWNnRSxJQUFJLENBQUNDLEtBQUssQ0FBQ1YsTUFBTSxPQUFPUSxDQUFDLENBQUNoSCxLQUFLLGVBQWVnSCxDQUFDLENBQUNuSixFQUFFLE1BQU07SUFDbkYsTUFBTWtGLENBQUMsR0FBR1EsUUFBUSxDQUFDdkIsT0FBTztJQUMxQixJQUFJLENBQUNlLENBQUMsRUFBRTtNQUNOQyxLQUFLLENBQUNDLElBQUksRUFBRSxNQUFNLENBQUM7TUFDbkI7SUFDRjtJQUNBLElBQUlGLENBQUMsQ0FBQ3BELElBQUksS0FBSyxJQUFJLEVBQUU7TUFDbkJxRCxLQUFLLENBQUMsa0NBQWtDLEVBQUUsTUFBTSxFQUFFO1FBQUVjLFNBQVMsRUFBRTtNQUFlLENBQUMsQ0FBQztNQUNoRjtJQUNGO0lBQ0EsSUFBQXFELHVCQUFjLEVBQUNwRSxDQUFDLEVBQUVrRSxJQUFJLENBQUMsQ0FBQzdDLElBQUksQ0FDMUIsTUFBTXBCLEtBQUssQ0FBQ0MsSUFBSSxFQUFFLE1BQU0sQ0FBQyxFQUN4QmpHLENBQUMsSUFBS2dHLEtBQUssQ0FBQyx3QkFBd0JqRyxNQUFNLENBQUNDLENBQUMsQ0FBQyxFQUFFLEVBQUUsT0FBTyxFQUFFO01BQUU4RyxTQUFTLEVBQUU7SUFBVSxDQUFDLENBQ3JGLENBQUM7RUFDSCxDQUFDLEVBQ0QsQ0FBQzdCLE1BQU0sRUFBRWUsS0FBSyxDQUNoQixDQUFDO0VBRUQsTUFBTW9FLE1BQU0sR0FBRyxJQUFBcEksa0JBQVcsRUFDeEIsQ0FBQ2dJLENBQVUsRUFBRUssR0FBVyxFQUFFQyxPQUFpQixLQUFLO0lBQzlDLE1BQU0xRSxDQUFDLEdBQUdvRSxDQUFDLENBQUNFLEtBQUssQ0FBQ0csR0FBRyxDQUFDO0lBQ3RCLE1BQU1uQixDQUFDLEdBQUdELFdBQVcsQ0FBQ3JELENBQUMsQ0FBQzJELElBQUksQ0FBQztJQUM3QixJQUFJTCxDQUFDLEVBQUVuQixLQUFLLENBQUNtQixDQUFDLEVBQUVvQixPQUFPLEdBQUcsQ0FBQyxHQUFHMUUsQ0FBQyxDQUFDMkUsUUFBUSxJQUFJLEdBQUcsRUFBRXpGLFFBQVEsQ0FBQ0UsT0FBTyxDQUFDM0IsRUFBRSxDQUFDOUMsRUFBRSxHQUFHYyxpQkFBaUIsQ0FBQztJQUM1RjtJQUNBO0lBQ0E7SUFDQTtJQUNBLElBQUlnQixTQUFTLENBQUMyQyxPQUFPLEVBQUU7TUFDckJ3QyxZQUFZLENBQUNuRixTQUFTLENBQUMyQyxPQUFPLENBQUM7TUFDL0IzQyxTQUFTLENBQUMyQyxPQUFPLEdBQUcsSUFBSTtJQUMxQjtJQUNBLElBQUlZLENBQUMsQ0FBQzRFLElBQUksSUFBSSxDQUFDMUYsUUFBUSxDQUFDRSxPQUFPLENBQUNMLE9BQU8sRUFBRTtNQUN2Q3RDLFNBQVMsQ0FBQzJDLE9BQU8sR0FBRzNFLE1BQU0sQ0FBQ2lHLFVBQVUsQ0FBQyxNQUFNOUQsV0FBVyxDQUFDd0MsT0FBTyxDQUFDLENBQUMsRUFBRVksQ0FBQyxDQUFDNEUsSUFBSSxDQUFDO0lBQzVFO0VBQ0YsQ0FBQyxFQUNELENBQUN2QixXQUFXLEVBQUVsQixLQUFLLENBQ3JCLENBQUM7RUFFRCxNQUFNMEMsV0FBVyxHQUFHLElBQUF6SSxrQkFBVyxFQUM1QitILEdBQVcsSUFBSztJQUNmLE1BQU1DLENBQUMsR0FBR2xGLFFBQVEsQ0FBQ0UsT0FBTyxDQUFDckIsUUFBUSxDQUFDZ0UsSUFBSSxDQUFFMUcsQ0FBQyxJQUFLQSxDQUFDLENBQUNKLEVBQUUsS0FBS2tKLEdBQUcsQ0FBQztJQUM3RCxJQUFJLENBQUNDLENBQUMsRUFBRTtJQUNSLElBQUkzSCxTQUFTLENBQUMyQyxPQUFPLEVBQUU7TUFDckJ3QyxZQUFZLENBQUNuRixTQUFTLENBQUMyQyxPQUFPLENBQUM7TUFDL0IzQyxTQUFTLENBQUMyQyxPQUFPLEdBQUcsSUFBSTtJQUMxQjtJQUNBQyxNQUFNLENBQUM7TUFBRVgsT0FBTyxFQUFFO1FBQUV5RixHQUFHO1FBQUVNLEdBQUcsRUFBRTtNQUFFLENBQUM7TUFBRWpHLFNBQVMsRUFBRSxLQUFLO01BQUVELGFBQWEsRUFBRTtJQUFNLENBQUMsQ0FBQztJQUM1RWlHLE1BQU0sQ0FBQ0osQ0FBQyxFQUFFLENBQUMsRUFBRSxJQUFJLENBQUM7RUFDcEIsQ0FBQyxFQUNELENBQUMvRSxNQUFNLEVBQUVtRixNQUFNLENBQ2pCLENBQUM7RUFFRCxNQUFNTSxRQUFRLEdBQUcsSUFBQTFJLGtCQUFXLEVBQUMsTUFBTTtJQUNqQyxJQUFJSSxRQUFRLENBQUM0QyxPQUFPLEVBQUVxRCxvQkFBb0IsQ0FBQ2pHLFFBQVEsQ0FBQzRDLE9BQU8sQ0FBQztJQUM1RCxJQUFJM0MsU0FBUyxDQUFDMkMsT0FBTyxFQUFFO01BQ3JCd0MsWUFBWSxDQUFDbkYsU0FBUyxDQUFDMkMsT0FBTyxDQUFDO01BQy9CM0MsU0FBUyxDQUFDMkMsT0FBTyxHQUFHLElBQUk7SUFDMUI7SUFDQUMsTUFBTSxDQUFDO01BQUVYLE9BQU8sRUFBRTtJQUFLLENBQUMsQ0FBQztFQUMzQixDQUFDLEVBQUUsQ0FBQ1csTUFBTSxDQUFDLENBQUM7RUFFWixNQUFNMEYsUUFBUSxHQUFHLElBQUEzSSxrQkFBVyxFQUFDLE1BQU07SUFDakMsTUFBTTRJLEVBQUUsR0FBRzlGLFFBQVEsQ0FBQ0UsT0FBTyxDQUFDVixPQUFPO0lBQ25DLElBQUksQ0FBQ3NHLEVBQUUsRUFBRTtJQUNULElBQUl2SSxTQUFTLENBQUMyQyxPQUFPLEVBQUU7TUFDckJ3QyxZQUFZLENBQUNuRixTQUFTLENBQUMyQyxPQUFPLENBQUM7TUFDL0IzQyxTQUFTLENBQUMyQyxPQUFPLEdBQUcsSUFBSTtJQUMxQjtJQUNBLE1BQU1nRixDQUFDLEdBQUdsRixRQUFRLENBQUNFLE9BQU8sQ0FBQ3JCLFFBQVEsQ0FBQ2dFLElBQUksQ0FBRTFHLENBQUMsSUFBS0EsQ0FBQyxDQUFDSixFQUFFLEtBQUsrSixFQUFFLENBQUNiLEdBQUcsQ0FBQztJQUNoRSxJQUFJLENBQUNDLENBQUMsRUFBRTtJQUNSLE1BQU1hLEVBQUUsR0FBR0QsRUFBRSxDQUFDUCxHQUFHLEdBQUcsQ0FBQztJQUNyQixJQUFJUSxFQUFFLElBQUliLENBQUMsQ0FBQ0UsS0FBSyxDQUFDVixNQUFNLEVBQUU7TUFDeEJrQixRQUFRLENBQUMsQ0FBQztNQUNWO0lBQ0Y7SUFDQXpGLE1BQU0sQ0FBQztNQUFFWCxPQUFPLEVBQUU7UUFBRSxHQUFHc0csRUFBRTtRQUFFUCxHQUFHLEVBQUVRO01BQUc7SUFBRSxDQUFDLENBQUM7SUFDdkNULE1BQU0sQ0FBQ0osQ0FBQyxFQUFFYSxFQUFFLENBQUM7RUFDZixDQUFDLEVBQUUsQ0FBQzVGLE1BQU0sRUFBRW1GLE1BQU0sRUFBRU0sUUFBUSxDQUFDLENBQUM7RUFDOUI7RUFDQWxJLFdBQVcsQ0FBQ3dDLE9BQU8sR0FBRzJGLFFBQVE7RUFFOUIsTUFBTUcsUUFBUSxHQUFHLElBQUE5SSxrQkFBVyxFQUFDLE1BQU07SUFDakMsTUFBTTRJLEVBQUUsR0FBRzlGLFFBQVEsQ0FBQ0UsT0FBTyxDQUFDVixPQUFPO0lBQ25DLElBQUksQ0FBQ3NHLEVBQUUsRUFBRTtJQUNULElBQUl2SSxTQUFTLENBQUMyQyxPQUFPLEVBQUU7TUFDckJ3QyxZQUFZLENBQUNuRixTQUFTLENBQUMyQyxPQUFPLENBQUM7TUFDL0IzQyxTQUFTLENBQUMyQyxPQUFPLEdBQUcsSUFBSTtJQUMxQjtJQUNBLE1BQU1nRixDQUFDLEdBQUdsRixRQUFRLENBQUNFLE9BQU8sQ0FBQ3JCLFFBQVEsQ0FBQ2dFLElBQUksQ0FBRTFHLENBQUMsSUFBS0EsQ0FBQyxDQUFDSixFQUFFLEtBQUsrSixFQUFFLENBQUNiLEdBQUcsQ0FBQztJQUNoRSxJQUFJLENBQUNDLENBQUMsRUFBRTtJQUNSLE1BQU1hLEVBQUUsR0FBR2pDLElBQUksQ0FBQ21DLEdBQUcsQ0FBQyxDQUFDLEVBQUVILEVBQUUsQ0FBQ1AsR0FBRyxHQUFHLENBQUMsQ0FBQztJQUNsQ3BGLE1BQU0sQ0FBQztNQUFFWCxPQUFPLEVBQUU7UUFBRSxHQUFHc0csRUFBRTtRQUFFUCxHQUFHLEVBQUVRO01BQUc7SUFBRSxDQUFDLENBQUM7SUFDdkNULE1BQU0sQ0FBQ0osQ0FBQyxFQUFFYSxFQUFFLENBQUM7RUFDZixDQUFDLEVBQUUsQ0FBQzVGLE1BQU0sRUFBRW1GLE1BQU0sQ0FBQyxDQUFDO0VBRXBCLE1BQU1ZLFFBQVEsR0FBRyxJQUFBaEosa0JBQVcsRUFDekJxSSxHQUFXLElBQUs7SUFDZixNQUFNTyxFQUFFLEdBQUc5RixRQUFRLENBQUNFLE9BQU8sQ0FBQ1YsT0FBTztJQUNuQyxJQUFJLENBQUNzRyxFQUFFLEVBQUU7SUFDVCxJQUFJdkksU0FBUyxDQUFDMkMsT0FBTyxFQUFFO01BQ3JCd0MsWUFBWSxDQUFDbkYsU0FBUyxDQUFDMkMsT0FBTyxDQUFDO01BQy9CM0MsU0FBUyxDQUFDMkMsT0FBTyxHQUFHLElBQUk7SUFDMUI7SUFDQSxNQUFNZ0YsQ0FBQyxHQUFHbEYsUUFBUSxDQUFDRSxPQUFPLENBQUNyQixRQUFRLENBQUNnRSxJQUFJLENBQUUxRyxDQUFDLElBQUtBLENBQUMsQ0FBQ0osRUFBRSxLQUFLK0osRUFBRSxDQUFDYixHQUFHLENBQUM7SUFDaEUsSUFBSSxDQUFDQyxDQUFDLEVBQUU7SUFDUi9FLE1BQU0sQ0FBQztNQUFFWCxPQUFPLEVBQUU7UUFBRSxHQUFHc0csRUFBRTtRQUFFUDtNQUFJO0lBQUUsQ0FBQyxDQUFDO0lBQ25DRCxNQUFNLENBQUNKLENBQUMsRUFBRUssR0FBRyxDQUFDO0VBQ2hCLENBQUMsRUFDRCxDQUFDcEYsTUFBTSxFQUFFbUYsTUFBTSxDQUNqQixDQUFDOztFQUVEO0VBQ0EsTUFBTWEsUUFBUSxHQUFHLElBQUFqSixrQkFBVyxFQUN6QmtELEtBQXVCLElBQUs7SUFDM0JELE1BQU0sQ0FBRVcsQ0FBQyxLQUFNO01BQUV0QyxPQUFPLEVBQUVzQyxDQUFDLENBQUN0QyxPQUFPLENBQUMyRCxHQUFHLENBQUVDLENBQUMsSUFBTXRCLENBQUMsQ0FBQy9CLFNBQVMsQ0FBQzlDLFFBQVEsQ0FBQ21HLENBQUMsQ0FBQ3JHLEVBQUUsQ0FBQyxHQUFHO1FBQUUsR0FBR3FHLENBQUM7UUFBRSxHQUFHaEM7TUFBTSxDQUFDLEdBQUdnQyxDQUFFO0lBQUUsQ0FBQyxDQUFDLENBQUM7SUFDekdHLFlBQVksQ0FBQ3ZDLFFBQVEsQ0FBQ0UsT0FBTyxDQUFDbkIsU0FBUyxDQUFDO0VBQzFDLENBQUMsRUFDRCxDQUFDb0IsTUFBTSxFQUFFb0MsWUFBWSxDQUN2QixDQUFDOztFQUVEO0VBQ0EsTUFBTTZELE1BQU0sR0FBRyxJQUFBbEosa0JBQVcsRUFDeEIsQ0FBQ25CLEVBQVUsRUFBRUMsUUFBUSxHQUFHLEtBQUssS0FBSztJQUNoQ21FLE1BQU0sQ0FBRVcsQ0FBQyxLQUFNO01BQ2IvQixTQUFTLEVBQUVsRCxjQUFjLENBQUNpRixDQUFDLENBQUMvQixTQUFTLEVBQUVoRCxFQUFFLEVBQUVDLFFBQVEsQ0FBQztNQUNwRHFELGFBQWEsRUFBRSxJQUFJO01BQ25CRSxTQUFTLEVBQUU7SUFDYixDQUFDLENBQUMsQ0FBQztFQUNMLENBQUMsRUFDRCxDQUFDWSxNQUFNLENBQ1QsQ0FBQzs7RUFFRDtFQUNBLE1BQU1rRyxjQUFjLEdBQUcsSUFBQW5KLGtCQUFXLEVBQUMsTUFBTWlELE1BQU0sQ0FBQztJQUFFWixTQUFTLEVBQUU7RUFBSyxDQUFDLENBQUMsRUFBRSxDQUFDWSxNQUFNLENBQUMsQ0FBQztFQUUvRSxNQUFNbUcsZUFBZSxHQUFHLElBQUFwSixrQkFBVyxFQUFDLE1BQU07SUFDeEMsTUFBTXBCLEdBQUcsR0FBR2tFLFFBQVEsQ0FBQ0UsT0FBTyxDQUFDbkIsU0FBUyxDQUFDSCxLQUFLLENBQUMsQ0FBQztJQUM5QyxJQUFJLENBQUM5QyxHQUFHLENBQUM0SSxNQUFNLEVBQUU7SUFDakIsTUFBTTZCLE9BQU8sR0FBR3ZHLFFBQVEsQ0FBQ0UsT0FBTyxDQUFDMUIsT0FBTyxDQUFDdEMsTUFBTSxDQUFFa0csQ0FBQyxJQUFLdEcsR0FBRyxDQUFDRyxRQUFRLENBQUNtRyxDQUFDLENBQUNyRyxFQUFFLENBQUMsQ0FBQztJQUMxRW9FLE1BQU0sQ0FBRVcsQ0FBQyxLQUFNO01BQUV0QyxPQUFPLEVBQUVzQyxDQUFDLENBQUN0QyxPQUFPLENBQUN0QyxNQUFNLENBQUVrRyxDQUFDLElBQUssQ0FBQ3RHLEdBQUcsQ0FBQ0csUUFBUSxDQUFDbUcsQ0FBQyxDQUFDckcsRUFBRSxDQUFDLENBQUM7TUFBRWdELFNBQVMsRUFBRTtJQUFHLENBQUMsQ0FBQyxDQUFDO0lBQ3pGO0lBQ0EsTUFBTWtDLENBQUMsR0FBR1EsUUFBUSxDQUFDdkIsT0FBTztJQUMxQixJQUFJZSxDQUFDLElBQUlBLENBQUMsQ0FBQ3BELElBQUksS0FBSyxJQUFJLEVBQUU7TUFDeEJvRSxPQUFPLENBQUNDLEdBQUcsQ0FBQ3BHLEdBQUcsQ0FBQ3FHLEdBQUcsQ0FBRXBHLEVBQUUsSUFBSyxJQUFBeUssdUJBQVcsRUFBQ3ZGLENBQUMsRUFBRWxGLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQytHLEtBQUssQ0FBRTVILENBQUMsSUFDdkRnRyxLQUFLLENBQUMsZ0JBQWdCakcsTUFBTSxDQUFDQyxDQUFDLENBQUMsRUFBRSxFQUFFLE9BQU8sRUFBRTtRQUFFOEcsU0FBUyxFQUFFO01BQVUsQ0FBQyxDQUN0RSxDQUFDO0lBQ0g7SUFDQWQsS0FBSyxDQUFDLEdBQUdwRixHQUFHLENBQUM0SSxNQUFNLEdBQUcsQ0FBQyxHQUFHLEdBQUc1SSxHQUFHLENBQUM0SSxNQUFNLFVBQVUsR0FBRyxRQUFRLGtCQUFrQixFQUFFLE9BQU8sRUFBRTtNQUN2Rm5ELFdBQVcsRUFBRSxNQUFNO01BQ25Ca0YsUUFBUSxFQUFFQSxDQUFBLEtBQU07UUFDZHRHLE1BQU0sQ0FBRVcsQ0FBQyxLQUFNO1VBQUV0QyxPQUFPLEVBQUVzQyxDQUFDLENBQUN0QyxPQUFPLENBQUNwQyxNQUFNLENBQUNtSyxPQUFPO1FBQUUsQ0FBQyxDQUFDLENBQUM7UUFDdkQsSUFBSXRGLENBQUMsSUFBSUEsQ0FBQyxDQUFDcEQsSUFBSSxLQUFLLElBQUksRUFBRTtVQUN4Qm9FLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDcUUsT0FBTyxDQUFDcEUsR0FBRyxDQUFFQyxDQUFDLElBQUssSUFBQXNFLHlCQUFhLEVBQUN6RixDQUFDLEVBQUVtQixDQUFDLENBQUNyRyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMrRyxLQUFLLENBQUMsTUFBTUMsU0FBUyxDQUFDO1FBQ2hGO01BQ0Y7SUFDRixDQUFDLENBQUM7RUFDSixDQUFDLEVBQUUsQ0FBQzVDLE1BQU0sRUFBRWUsS0FBSyxDQUFDLENBQUM7RUFFbkIsTUFBTXlGLFlBQVksR0FBRyxJQUFBekosa0JBQVcsRUFDOUIsQ0FBQzBKLElBQWdCLEVBQUVDLEVBQVUsRUFBRUMsRUFBVSxLQUFLO0lBQzVDLE1BQU0xRSxDQUFVLEdBQUc7TUFDakJyRyxFQUFFLEVBQUUsSUFBQWdMLGVBQVUsRUFBQ0gsSUFBSSxLQUFLLE1BQU0sR0FBRyxNQUFNLEdBQUdBLElBQUksQ0FBQztNQUMvQ0EsSUFBSTtNQUNKekssQ0FBQyxFQUFFMEssRUFBRSxHQUFHLEdBQUc7TUFDWEcsQ0FBQyxFQUFFRixFQUFFLEdBQUcsRUFBRTtNQUNWeEMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsQ0FBQyxFQUFFLEdBQUc7TUFDTjBDLEdBQUcsRUFBRSxDQUFDO01BQ05DLEtBQUssRUFBRSxDQUFDO01BQ1JDLENBQUMsRUFBRSxDQUFDO01BQ0pDLFdBQVcsRUFBRTtJQUNmLENBQUM7SUFDRCxJQUFJUixJQUFJLEtBQUssTUFBTSxFQUFFO01BQ25CeEUsQ0FBQyxDQUFDaUYsS0FBSyxHQUFHLE9BQU87TUFDakJqRixDQUFDLENBQUNsRSxLQUFLLEdBQUcsVUFBVTtJQUN0QixDQUFDLE1BQU0sSUFBSTBJLElBQUksS0FBSyxPQUFPLEVBQUU7TUFDM0J4RSxDQUFDLENBQUNsRSxLQUFLLEdBQUcsT0FBTztNQUNqQmtFLENBQUMsQ0FBQ2tGLElBQUksR0FBRyxhQUFhO01BQ3RCbEYsQ0FBQyxDQUFDa0MsQ0FBQyxHQUFHLEdBQUc7TUFDVGxDLENBQUMsQ0FBQ21DLENBQUMsR0FBRyxHQUFHO0lBQ1gsQ0FBQyxNQUFNLElBQUlxQyxJQUFJLEtBQUssT0FBTyxFQUFFO01BQzNCeEUsQ0FBQyxDQUFDbEUsS0FBSyxHQUFHLE9BQU87TUFDakJrRSxDQUFDLENBQUNrQyxDQUFDLEdBQUcsR0FBRztNQUNUbEMsQ0FBQyxDQUFDbUMsQ0FBQyxHQUFHLEVBQUU7TUFDUm5DLENBQUMsQ0FBQytFLENBQUMsR0FBRyxDQUFDO0lBQ1QsQ0FBQyxNQUFNLElBQUlQLElBQUksS0FBSyxPQUFPLEVBQUU7TUFDM0J4RSxDQUFDLENBQUNtRixLQUFLLEdBQUcsTUFBTTtNQUNoQm5GLENBQUMsQ0FBQ2xFLEtBQUssR0FBRyxFQUFFO01BQ1prRSxDQUFDLENBQUNrQyxDQUFDLEdBQUcsR0FBRztNQUNUbEMsQ0FBQyxDQUFDbUMsQ0FBQyxHQUFHLEdBQUc7SUFDWCxDQUFDLE1BQU0sSUFBSXFDLElBQUksS0FBSyxPQUFPLEVBQUU7TUFDM0J4RSxDQUFDLENBQUNsRSxLQUFLLEdBQUcsT0FBTztNQUNqQmtFLENBQUMsQ0FBQ2tDLENBQUMsR0FBRyxHQUFHO01BQ1RsQyxDQUFDLENBQUNtQyxDQUFDLEdBQUcsR0FBRztNQUNUbkMsQ0FBQyxDQUFDK0UsQ0FBQyxHQUFHLENBQUM7SUFDVCxDQUFDLE1BQU0sSUFBSVAsSUFBSSxLQUFLLEtBQUssRUFBRTtNQUN6QnhFLENBQUMsQ0FBQ29GLE1BQU0sR0FBRyxLQUFLO01BQ2hCcEYsQ0FBQyxDQUFDbEUsS0FBSyxHQUFHLE9BQU87SUFDbkIsQ0FBQyxNQUFNLElBQUkwSSxJQUFJLEtBQUssV0FBVyxFQUFFO01BQy9CeEUsQ0FBQyxDQUFDbEUsS0FBSyxHQUFHLGNBQWM7SUFDMUI7SUFDQWlDLE1BQU0sQ0FBRVcsQ0FBQyxLQUFNO01BQ2J0QyxPQUFPLEVBQUVzQyxDQUFDLENBQUN0QyxPQUFPLENBQUNwQyxNQUFNLENBQUNnRyxDQUFDLENBQUM7TUFDNUJyRCxTQUFTLEVBQUUsQ0FBQ3FELENBQUMsQ0FBQ3JHLEVBQUUsQ0FBQztNQUNqQndELFNBQVMsRUFBRSxJQUFJO01BQ2ZGLGFBQWEsRUFBRSxJQUFJO01BQ25CeEIsSUFBSSxFQUFFO0lBQ1IsQ0FBQyxDQUFDLENBQUM7SUFDSCtELFVBQVUsQ0FBQyxDQUFDUSxDQUFDLENBQUMsRUFBRSxtQkFBbUJBLENBQUMsQ0FBQ3JHLEVBQUUsTUFBTSxFQUFFLE1BQU0sQ0FBQztFQUN4RCxDQUFDLEVBQ0QsQ0FBQ29FLE1BQU0sRUFBRXlCLFVBQVUsQ0FDckIsQ0FBQzs7RUFFRDtFQUNBO0VBQ0E7RUFDQTs7RUFFQTtBQUNGO0FBQ0E7RUFDRSxNQUFNNkYsV0FBVyxHQUFHLElBQUF2SyxrQkFBVyxFQUM3QixPQUFPMkosRUFBVSxFQUFFQyxFQUFVLEtBQUs7SUFDaEMsTUFBTTVELE1BQU0sR0FBR3pCLFFBQVEsQ0FBQ3ZCLE9BQU87SUFDL0IsSUFBSSxDQUFDZ0QsTUFBTSxFQUFFO01BQ1hoQyxLQUFLLENBQUMsMkNBQTJDLEVBQUUsTUFBTSxFQUFFO1FBQUVjLFNBQVMsRUFBRTtNQUFlLENBQUMsQ0FBQztNQUN6RjtJQUNGO0lBQ0E3QixNQUFNLENBQUM7TUFBRUwsSUFBSSxFQUFFO0lBQWUsQ0FBQyxDQUFDO0lBQ2hDLElBQUk7TUFDRixNQUFNNEgsR0FBRyxHQUFHLE1BQU0sSUFBQUMsa0JBQVEsRUFBQztRQUN6QjlKLElBQUksRUFBRSxXQUFXO1FBQ2pCK0osS0FBSyxFQUFFLENBQUMsTUFBTSxJQUFBQyx3QkFBYyxFQUFDM0UsTUFBTSxDQUFDLENBQUM7UUFDckM0RSxVQUFVLEVBQUUsQ0FBQyxvQkFBb0IsQ0FBQztRQUNsQ0MsU0FBUyxFQUFFLENBQUM3RSxNQUFNLENBQUNyRixJQUFJLENBQUM7UUFDeEJLLEtBQUssRUFBRSxjQUFjO1FBQ3JCOEosT0FBTyxFQUFFLENBQ1A7VUFBRUMsS0FBSyxFQUFFLFFBQVE7VUFBRUMsVUFBVSxFQUFFLENBQUMsTUFBTSxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsT0FBTztRQUFFLENBQUMsRUFDNUY7VUFBRUQsS0FBSyxFQUFFLFdBQVc7VUFBRUMsVUFBVSxFQUFFO1FBQUcsQ0FBQztNQUUxQyxDQUFDLENBQUM7TUFDRixJQUFJLENBQUNSLEdBQUcsRUFBRSxPQUFPLENBQUM7TUFDbEIsTUFBTTNNLEdBQUcsR0FBRyxJQUFBb04saUJBQU8sRUFBQ1QsR0FBRyxDQUFDVSxPQUFPLENBQUM7TUFDaEMsSUFBSSxDQUFDck4sR0FBRyxFQUFFO1FBQ1JtRyxLQUFLLENBQUMsOEJBQThCLEVBQUUsT0FBTyxFQUFFO1VBQUVjLFNBQVMsRUFBRTtRQUFVLENBQUMsQ0FBQztRQUN4RTtNQUNGO01BQ0EsTUFBTXFDLElBQUksR0FBRyxNQUFNLElBQUFnRSwwQkFBYyxFQUFDbkYsTUFBTSxFQUFFbkksR0FBRyxDQUFDO01BQzlDLE1BQU1xSCxDQUFVLEdBQUc7UUFDakJyRyxFQUFFLEVBQUUsSUFBQWdMLGVBQVUsRUFBQyxLQUFLLENBQUM7UUFDckJILElBQUksRUFBRSxLQUFLO1FBQ1h6SyxDQUFDLEVBQUUwSyxFQUFFLEdBQUcsR0FBRztRQUNYRyxDQUFDLEVBQUVGLEVBQUUsR0FBRyxFQUFFO1FBQ1Z4QyxDQUFDLEVBQUUsR0FBRztRQUNOQyxDQUFDLEVBQUUsR0FBRztRQUNOMEMsR0FBRyxFQUFFLENBQUM7UUFDTkMsS0FBSyxFQUFFLENBQUM7UUFDUkMsQ0FBQyxFQUFFLENBQUM7UUFDSmpKLEtBQUssRUFBRW1HLElBQUk7UUFDWGlELElBQUksRUFBRSxvQkFBb0JqRCxJQUFJLE1BQU07UUFDcENtRCxNQUFNLEVBQUUsSUFBSTtRQUNaSixXQUFXLEVBQUU7TUFDZixDQUFDO01BQ0RqSCxNQUFNLENBQUVXLENBQUMsS0FBTTtRQUNidEMsT0FBTyxFQUFFc0MsQ0FBQyxDQUFDdEMsT0FBTyxDQUFDcEMsTUFBTSxDQUFDZ0csQ0FBQyxDQUFDO1FBQzVCckQsU0FBUyxFQUFFLENBQUNxRCxDQUFDLENBQUNyRyxFQUFFLENBQUM7UUFDakJ3RCxTQUFTLEVBQUUsSUFBSTtRQUNmRixhQUFhLEVBQUUsSUFBSTtRQUNuQnhCLElBQUksRUFBRSxNQUFNO1FBQ1o2QixNQUFNLEVBQUU7TUFDVixDQUFDLENBQUMsQ0FBQztNQUNIa0MsVUFBVSxDQUFDLENBQUNRLENBQUMsQ0FBQyxFQUFFLG1CQUFtQmlDLElBQUksRUFBRSxFQUFFLE9BQU8sQ0FBQztJQUNyRCxDQUFDLENBQUMsT0FBT25KLENBQUMsRUFBRTtNQUNWZ0csS0FBSyxDQUFDLHdCQUF3QmpHLE1BQU0sQ0FBQ0MsQ0FBQyxDQUFDLEVBQUUsRUFBRSxPQUFPLEVBQUU7UUFBRThHLFNBQVMsRUFBRTtNQUFVLENBQUMsQ0FBQztJQUMvRSxDQUFDLFNBQVM7TUFDUjdCLE1BQU0sQ0FBQztRQUFFTCxJQUFJLEVBQUU7TUFBSyxDQUFDLENBQUM7SUFDeEI7RUFDRixDQUFDLEVBQ0QsQ0FBQ29CLEtBQUssRUFBRWYsTUFBTSxFQUFFeUIsVUFBVSxDQUM1QixDQUFDOztFQUVEO0VBQ0EsTUFBTTBHLGFBQWEsR0FBRyxJQUFBcEwsa0JBQVcsRUFDL0IsTUFBT2dHLE1BQW1CLElBQUs7SUFDN0IsTUFBTXFGLEtBQUssR0FBRyxNQUFNLElBQUFDLHFCQUFTLEVBQUN0RixNQUFNLENBQUM7SUFDckN6QixRQUFRLENBQUN2QixPQUFPLEdBQUdnRCxNQUFNO0lBQ3pCO0lBQ0E7SUFDQTtJQUNBO0lBQ0EsTUFBTXVGLFFBQVEsR0FBR3ZGLE1BQU0sQ0FBQ3JGLElBQUksS0FBSyxJQUFJLElBQUssT0FBTzBLLEtBQUssQ0FBQ0csTUFBTSxLQUFLLFFBQVEsSUFBSUgsS0FBSyxDQUFDRyxNQUFNLEdBQUdwTSxnQkFBaUI7SUFDOUc2RCxNQUFNLENBQUM7TUFDTDNCLE9BQU8sRUFBRStKLEtBQUssQ0FBQy9KLE9BQU87TUFDdEJFLEtBQUssRUFBRTZKLEtBQUssQ0FBQzdKLEtBQUssQ0FBQ2dHLE1BQU0sR0FBRzZELEtBQUssQ0FBQzdKLEtBQUssR0FBR0MscUJBQVUsQ0FBQ0MsS0FBSyxDQUFDLENBQUM7TUFDNURDLFFBQVEsRUFBRTBKLEtBQUssQ0FBQzFKLFFBQVEsQ0FBQzZGLE1BQU0sR0FBRzZELEtBQUssQ0FBQzFKLFFBQVEsR0FBR0Msd0JBQWE7TUFDaEVmLEVBQUUsRUFBRXdLLEtBQUssQ0FBQ3RLLFVBQVUsSUFBSStCLFFBQVEsQ0FBQ0UsT0FBTyxDQUFDbkMsRUFBRTtNQUMzQ0csS0FBSyxFQUFFcUssS0FBSyxDQUFDckssS0FBSyxJQUFJOEIsUUFBUSxDQUFDRSxPQUFPLENBQUNoQyxLQUFLO01BQzVDTCxJQUFJLEVBQUU0SyxRQUFRLEdBQUcsS0FBSyxHQUFHekksUUFBUSxDQUFDRSxPQUFPLENBQUNyQyxJQUFJO01BQzlDa0IsU0FBUyxFQUFFLEVBQUU7TUFDYjtNQUNBO01BQ0E7TUFDQUksV0FBVyxFQUFFLElBQUk7TUFDakJDLGFBQWEsRUFBRSxJQUFJO01BQ25CQyxhQUFhLEVBQUUsS0FBSztNQUNwQkssTUFBTSxFQUFFO0lBQ1YsQ0FBQyxDQUFDO0VBQ0osQ0FBQyxFQUNELENBQUNTLE1BQU0sQ0FDVCxDQUFDOztFQUVEO0FBQ0Y7RUFDRSxNQUFNd0ksV0FBVyxHQUFHLElBQUF6TCxrQkFBVyxFQUM3QixNQUFPMEwsS0FBa0IsSUFBSztJQUM1QnpJLE1BQU0sQ0FBQztNQUFFTCxJQUFJLEVBQUU7SUFBYSxDQUFDLENBQUM7SUFDOUIsSUFBSTtNQUNGLE1BQU00SCxHQUFHLEdBQUcsTUFBTSxJQUFBQyxrQkFBUSxFQUFDO1FBQ3pCOUosSUFBSSxFQUFFLGFBQWE7UUFDbkIrSixLQUFLLEVBQUUsQ0FBQyxNQUFNLElBQUFDLHdCQUFjLEVBQUNlLEtBQUssQ0FBQyxDQUFDO1FBQ3BDZCxVQUFVLEVBQUUsQ0FBQyxrQkFBa0IsQ0FBQztRQUNoQ0MsU0FBUyxFQUFFLENBQUNhLEtBQUssQ0FBQy9LLElBQUksQ0FBQztRQUN2QkssS0FBSyxFQUFFO01BQ1QsQ0FBQyxDQUFDO01BQ0YsSUFBSSxDQUFDd0osR0FBRyxFQUFFO01BQ1YsTUFBTTNNLEdBQUcsR0FBRyxJQUFBb04saUJBQU8sRUFBQ1QsR0FBRyxDQUFDVSxPQUFPLENBQUM7TUFDaEMsSUFBSSxDQUFDck4sR0FBRyxFQUFFO1FBQ1JtRyxLQUFLLENBQUMsOEJBQThCLEVBQUUsT0FBTyxFQUFFO1VBQUVjLFNBQVMsRUFBRTtRQUFVLENBQUMsQ0FBQztRQUN4RTtNQUNGO01BQ0EsTUFBTTZHLFNBQXNCLEdBQUc7UUFBRS9OLElBQUksRUFBRUQsT0FBTyxDQUFDK04sS0FBSyxDQUFDOU4sSUFBSSxFQUFFQyxHQUFHLENBQUM7UUFBRThDLElBQUksRUFBRStLLEtBQUssQ0FBQy9LLElBQUk7UUFBRWlMLE9BQU8sRUFBRUYsS0FBSyxDQUFDRTtNQUFRLENBQUM7TUFDM0csSUFBSSxFQUFFLE1BQU0sSUFBQUMseUJBQWEsRUFBQ0YsU0FBUyxDQUFDLENBQUMsSUFBSSxFQUFFLE1BQU0sSUFBQUcsdUJBQVcsRUFBQ0gsU0FBUyxDQUFDLENBQUMsRUFBRTtRQUN4RTNILEtBQUssQ0FBQyw2RUFBNkUsRUFBRSxPQUFPLEVBQUU7VUFDNUZjLFNBQVMsRUFBRTtRQUNiLENBQUMsQ0FBQztRQUNGO01BQ0Y7TUFDQSxNQUFNc0csYUFBYSxDQUFDTyxTQUFTLENBQUM7TUFDOUIzSCxLQUFLLENBQUMsZUFBZSxFQUFFLE9BQU8sQ0FBQztJQUNqQyxDQUFDLENBQUMsT0FBT2hHLENBQUMsRUFBRTtNQUNWZ0csS0FBSyxDQUFDLHNCQUFzQmpHLE1BQU0sQ0FBQ0MsQ0FBQyxDQUFDLEVBQUUsRUFBRSxPQUFPLEVBQUU7UUFBRThHLFNBQVMsRUFBRTtNQUFVLENBQUMsQ0FBQztJQUM3RSxDQUFDLFNBQVM7TUFDUjdCLE1BQU0sQ0FBQztRQUFFTCxJQUFJLEVBQUU7TUFBSyxDQUFDLENBQUM7SUFDeEI7RUFDRixDQUFDLEVBQ0QsQ0FBQ29CLEtBQUssRUFBRWYsTUFBTSxFQUFFbUksYUFBYSxDQUMvQixDQUFDOztFQUVEO0FBQ0Y7QUFDQTtFQUNFLE1BQU1XLFdBQVcsR0FBRyxJQUFBL0wsa0JBQVcsRUFDN0IsTUFBT2dHLE1BQW1CLElBQUs7SUFDN0IvQyxNQUFNLENBQUM7TUFBRUwsSUFBSSxFQUFFO0lBQWEsQ0FBQyxDQUFDO0lBQzlCLElBQUk7TUFDRixNQUFNd0ksYUFBYSxDQUFDcEYsTUFBTSxDQUFDO01BQzNCaEMsS0FBSyxDQUFDLGVBQWUsRUFBRSxPQUFPLENBQUM7SUFDakMsQ0FBQyxDQUFDLE9BQU9oRyxDQUFDLEVBQUU7TUFDVmdHLEtBQUssQ0FBQyxzQkFBc0JqRyxNQUFNLENBQUNDLENBQUMsQ0FBQyxFQUFFLEVBQUUsT0FBTyxFQUFFO1FBQUU4RyxTQUFTLEVBQUU7TUFBVSxDQUFDLENBQUM7SUFDN0UsQ0FBQyxTQUFTO01BQ1I3QixNQUFNLENBQUM7UUFBRUwsSUFBSSxFQUFFO01BQUssQ0FBQyxDQUFDO0lBQ3hCO0VBQ0YsQ0FBQyxFQUNELENBQUNvQixLQUFLLEVBQUVmLE1BQU0sRUFBRW1JLGFBQWEsQ0FDL0IsQ0FBQzs7RUFFRDtBQUNGO0VBQ0UsTUFBTVksVUFBVSxHQUFHLElBQUFoTSxrQkFBVyxFQUM1QixNQUFPMEwsS0FBa0IsSUFBSztJQUM1QixJQUFJQSxLQUFLLENBQUMvSyxJQUFJLEtBQUssSUFBSSxFQUFFO01BQ3ZCcUQsS0FBSyxDQUFDLDJEQUEyRCxFQUFFLE1BQU0sRUFBRTtRQUFFYyxTQUFTLEVBQUU7TUFBZSxDQUFDLENBQUM7TUFDekc7SUFDRjtJQUNBN0IsTUFBTSxDQUFDO01BQUVMLElBQUksRUFBRTtJQUFZLENBQUMsQ0FBQztJQUM3QixJQUFJO01BQ0YsTUFBTTRILEdBQUcsR0FBRyxNQUFNLElBQUFDLGtCQUFRLEVBQUM7UUFDekI5SixJQUFJLEVBQUUsYUFBYTtRQUNuQitKLEtBQUssRUFBRSxDQUFDLE1BQU0sSUFBQUMsd0JBQWMsRUFBQ2UsS0FBSyxDQUFDLENBQUM7UUFDcENkLFVBQVUsRUFBRSxDQUFDLGtCQUFrQixDQUFDO1FBQ2hDQyxTQUFTLEVBQUUsQ0FBQ2EsS0FBSyxDQUFDL0ssSUFBSSxDQUFDO1FBQ3ZCSyxLQUFLLEVBQUUsNkJBQTZCO1FBQ3BDaUwsaUJBQWlCLEVBQUU7TUFDckIsQ0FBQyxDQUFDO01BQ0YsSUFBSSxDQUFDekIsR0FBRyxFQUFFO01BQ1YsTUFBTTNNLEdBQUcsR0FBRyxJQUFBb04saUJBQU8sRUFBQ1QsR0FBRyxDQUFDVSxPQUFPLENBQUM7TUFDaEMsSUFBSSxDQUFDck4sR0FBRyxFQUFFO1FBQ1JtRyxLQUFLLENBQUMsNEJBQTRCLEVBQUUsT0FBTyxFQUFFO1VBQUVjLFNBQVMsRUFBRTtRQUFVLENBQUMsQ0FBQztRQUN0RTtNQUNGO01BQ0EsTUFBTTZHLFNBQXNCLEdBQUc7UUFBRS9OLElBQUksRUFBRUQsT0FBTyxDQUFDK04sS0FBSyxDQUFDOU4sSUFBSSxFQUFFQyxHQUFHLENBQUM7UUFBRThDLElBQUksRUFBRSxJQUFJO1FBQUVpTCxPQUFPLEVBQUVGLEtBQUssQ0FBQ0U7TUFBUSxDQUFDO01BQ3JHLE1BQU01SyxLQUFLLEdBQUduRCxHQUFHLENBQUNxTyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUNDLEdBQUcsQ0FBQyxDQUFDLElBQUksZ0JBQWdCO01BQ3RELE1BQU0sSUFBQUMseUJBQWEsRUFBQ1QsU0FBUyxFQUFFM0ssS0FBSyxDQUFDO01BQ3JDLE1BQU1vSyxhQUFhLENBQUNPLFNBQVMsQ0FBQztNQUM5QjNILEtBQUssQ0FBQyxnQkFBZ0IsRUFBRSxPQUFPLENBQUM7SUFDbEMsQ0FBQyxDQUFDLE9BQU9oRyxDQUFDLEVBQUU7TUFDVmdHLEtBQUssQ0FBQyx3QkFBd0JqRyxNQUFNLENBQUNDLENBQUMsQ0FBQyxFQUFFLEVBQUUsT0FBTyxFQUFFO1FBQUU4RyxTQUFTLEVBQUU7TUFBVSxDQUFDLENBQUM7SUFDL0UsQ0FBQyxTQUFTO01BQ1I3QixNQUFNLENBQUM7UUFBRUwsSUFBSSxFQUFFO01BQUssQ0FBQyxDQUFDO0lBQ3hCO0VBQ0YsQ0FBQyxFQUNELENBQUNvQixLQUFLLEVBQUVmLE1BQU0sRUFBRW1JLGFBQWEsQ0FDL0IsQ0FBQzs7RUFFRDtFQUNBLE1BQU1pQixTQUFTLEdBQUcsSUFBQXJNLGtCQUFXLEVBQUMsTUFBTTtJQUNsQyxNQUFNMEwsS0FBSyxHQUFHbkgsUUFBUSxDQUFDdkIsT0FBTztJQUM5QixJQUFJLENBQUMwSSxLQUFLLEVBQUU7TUFDVjFILEtBQUssQ0FBQywwQ0FBMEMsRUFBRSxNQUFNLEVBQUU7UUFBRWMsU0FBUyxFQUFFO01BQWUsQ0FBQyxDQUFDO01BQ3hGO0lBQ0Y7SUFDQSxLQUFLMkcsV0FBVyxDQUFDQyxLQUFLLENBQUM7RUFDekIsQ0FBQyxFQUFFLENBQUMxSCxLQUFLLEVBQUV5SCxXQUFXLENBQUMsQ0FBQztFQUV4QixNQUFNYSxRQUFRLEdBQUcsSUFBQXRNLGtCQUFXLEVBQUMsTUFBTTtJQUNqQyxNQUFNMEwsS0FBSyxHQUFHbkgsUUFBUSxDQUFDdkIsT0FBTztJQUM5QixJQUFJLENBQUMwSSxLQUFLLEVBQUU7TUFDVjFILEtBQUssQ0FBQywwQ0FBMEMsRUFBRSxNQUFNLEVBQUU7UUFBRWMsU0FBUyxFQUFFO01BQWUsQ0FBQyxDQUFDO01BQ3hGO0lBQ0Y7SUFDQSxLQUFLa0gsVUFBVSxDQUFDTixLQUFLLENBQUM7RUFDeEIsQ0FBQyxFQUFFLENBQUMxSCxLQUFLLEVBQUVnSSxVQUFVLENBQUMsQ0FBQzs7RUFFdkI7QUFDRjtFQUNFLE1BQU1PLFFBQVEsR0FBRyxJQUFBdk0sa0JBQVcsRUFBQyxZQUFZO0lBQ3ZDLElBQUk7TUFDRixNQUFNd00sT0FBTyxHQUFHLE1BQU0sSUFBQUMsc0JBQVksRUFBQyxDQUFDO01BQ3BDLElBQUksQ0FBQ0QsT0FBTyxFQUFFLE9BQU8sQ0FBQztNQUN0QixNQUFNZCxLQUFrQixHQUFHO1FBQUU5TixJQUFJLEVBQUU0TyxPQUFPLENBQUNFLElBQUk7UUFBRS9MLElBQUksRUFBRTZMLE9BQU8sQ0FBQzdMLElBQUk7UUFBRWlMLE9BQU8sRUFBRVksT0FBTyxDQUFDM047TUFBRyxDQUFDO01BQzFGLE1BQU00TSxXQUFXLENBQUNDLEtBQUssQ0FBQztJQUMxQixDQUFDLENBQUMsT0FBTzFOLENBQUMsRUFBRTtNQUNWZ0csS0FBSyxDQUFDLHVCQUF1QmpHLE1BQU0sQ0FBQ0MsQ0FBQyxDQUFDLEVBQUUsRUFBRSxPQUFPLEVBQUU7UUFBRThHLFNBQVMsRUFBRTtNQUFVLENBQUMsQ0FBQztJQUM5RTtFQUNGLENBQUMsRUFBRSxDQUFDZCxLQUFLLEVBQUV5SCxXQUFXLENBQUMsQ0FBQztFQUV4QixNQUFNa0IsV0FBVyxHQUFHLElBQUEzTSxrQkFBVyxFQUM3QixDQUFDbkIsRUFBVSxFQUFFcUUsS0FBdUIsS0FBSztJQUN2Q0QsTUFBTSxDQUFFVyxDQUFDLEtBQU07TUFBRXRDLE9BQU8sRUFBRXNDLENBQUMsQ0FBQ3RDLE9BQU8sQ0FBQzJELEdBQUcsQ0FBRUMsQ0FBQyxJQUFNQSxDQUFDLENBQUNyRyxFQUFFLEtBQUtBLEVBQUUsR0FBRztRQUFFLEdBQUdxRyxDQUFDO1FBQUUsR0FBR2hDO01BQU0sQ0FBQyxHQUFHZ0MsQ0FBRTtJQUFFLENBQUMsQ0FBQyxDQUFDO0lBQzFGRyxZQUFZLENBQUMsQ0FBQ3hHLEVBQUUsQ0FBQyxDQUFDO0VBQ3BCLENBQUMsRUFDRCxDQUFDb0UsTUFBTSxFQUFFb0MsWUFBWSxDQUN2QixDQUFDO0VBRUQsTUFBTXVILGFBQWEsR0FBRyxJQUFBNU0sa0JBQVcsRUFDL0IsQ0FBQ3NHLElBQVksRUFBRXVHLEVBQVUsS0FBSztJQUM1QixNQUFNNU8sQ0FBYSxHQUFHO01BQUU0TyxFQUFFO01BQUVuRCxJQUFJLEVBQUUsT0FBTztNQUFFb0QsS0FBSyxFQUFFO1FBQUVDLE1BQU0sRUFBRSxRQUFRO1FBQUVDLElBQUksRUFBRTtNQUFNO0lBQUUsQ0FBQztJQUNyRixNQUFNQyxHQUFHLEdBQUduSyxRQUFRLENBQUNFLE9BQU8sQ0FBQzFCLE9BQU8sQ0FBQ3FFLElBQUksQ0FBRVQsQ0FBQyxJQUFLQSxDQUFDLENBQUNyRyxFQUFFLEtBQUt5SCxJQUFJLENBQUM7SUFDL0QsTUFBTTRHLE9BQU8sR0FBR0QsR0FBRyxHQUFHO01BQUUsR0FBR0EsR0FBRztNQUFFL0MsV0FBVyxFQUFFK0MsR0FBRyxDQUFDL0MsV0FBVyxDQUFDaEwsTUFBTSxDQUFDakIsQ0FBQztJQUFFLENBQUMsR0FBRyxJQUFJO0lBQy9FZ0YsTUFBTSxDQUFFVyxDQUFDLEtBQU07TUFBRXRDLE9BQU8sRUFBRXNDLENBQUMsQ0FBQ3RDLE9BQU8sQ0FBQzJELEdBQUcsQ0FBRUMsQ0FBQyxJQUFNQSxDQUFDLENBQUNyRyxFQUFFLEtBQUt5SCxJQUFJLEdBQUc7UUFBRSxHQUFHcEIsQ0FBQztRQUFFZ0YsV0FBVyxFQUFFaEYsQ0FBQyxDQUFDZ0YsV0FBVyxDQUFDaEwsTUFBTSxDQUFDakIsQ0FBQztNQUFFLENBQUMsR0FBR2lILENBQUU7SUFBRSxDQUFDLENBQUMsQ0FBQztJQUN4SCxJQUFJZ0ksT0FBTyxFQUFFeEksVUFBVSxDQUFDLENBQUN3SSxPQUFPLENBQUMsRUFBRSxhQUFhNUcsSUFBSSxNQUFNdUcsRUFBRSxFQUFFLENBQUM7RUFDakUsQ0FBQyxFQUNELENBQUM1SixNQUFNLEVBQUV5QixVQUFVLENBQ3JCLENBQUM7O0VBRUQ7RUFDQTtBQUNGO0FBQ0E7QUFDQTtFQUNFLE1BQU15SSxZQUFZLEdBQUcsSUFBQW5OLGtCQUFXLEVBQUMsTUFBTTtJQUNyQyxNQUFNNEQsQ0FBQyxHQUFHZCxRQUFRLENBQUNFLE9BQU87SUFDMUIsSUFBSVksQ0FBQyxDQUFDL0IsU0FBUyxDQUFDMkYsTUFBTSxLQUFLLENBQUMsRUFBRTtJQUM5QixNQUFNbEIsSUFBSSxHQUFHMUMsQ0FBQyxDQUFDL0IsU0FBUyxDQUFDLENBQUMsQ0FBQztJQUMzQixNQUFNdUwsS0FBSyxHQUFHeEosQ0FBQyxDQUFDdEMsT0FBTyxDQUFDSSxLQUFLLENBQUMsQ0FBQyxDQUFDMkwsSUFBSSxDQUFDLENBQUNDLENBQUMsRUFBRUMsQ0FBQyxLQUFLLENBQUNELENBQUMsQ0FBQ3JELENBQUMsSUFBSSxDQUFDLEtBQUtzRCxDQUFDLENBQUN0RCxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQ2hGLEdBQUcsQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUNyRyxFQUFFLENBQUMsQ0FBQ0csTUFBTSxDQUFFSCxFQUFFLElBQUtBLEVBQUUsS0FBS3lILElBQUksQ0FBQztJQUNwSHJELE1BQU0sQ0FBQztNQUFFaEIsV0FBVyxFQUFFcUUsSUFBSTtNQUFFcEUsYUFBYSxFQUFFa0wsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUk7TUFBRWpMLGFBQWEsRUFBRTtJQUFNLENBQUMsQ0FBQztFQUN0RixDQUFDLEVBQUUsQ0FBQ2MsTUFBTSxDQUFDLENBQUM7RUFFWixNQUFNdUssVUFBVSxHQUFHLElBQUF4TixrQkFBVyxFQUMzQnlOLE1BQWUsSUFBSztJQUNuQixNQUFNN0osQ0FBQyxHQUFHZCxRQUFRLENBQUNFLE9BQU87SUFDMUIsSUFBSSxDQUFDWSxDQUFDLENBQUMzQixXQUFXLEVBQUU7SUFDcEIsSUFBSXdMLE1BQU0sSUFBSTdKLENBQUMsQ0FBQzFCLGFBQWEsRUFBRTBLLGFBQWEsQ0FBQ2hKLENBQUMsQ0FBQzNCLFdBQVcsRUFBRTJCLENBQUMsQ0FBQzFCLGFBQWEsQ0FBQztJQUM1RWUsTUFBTSxDQUFDO01BQUVoQixXQUFXLEVBQUUsSUFBSTtNQUFFQyxhQUFhLEVBQUU7SUFBSyxDQUFDLENBQUM7RUFDcEQsQ0FBQyxFQUNELENBQUNlLE1BQU0sRUFBRTJKLGFBQWEsQ0FDeEIsQ0FBQztFQUVELE1BQU1jLGlCQUFpQixHQUFHLElBQUExTixrQkFBVyxFQUNsQzJOLEdBQVcsSUFBSztJQUNmMUssTUFBTSxDQUFFVyxDQUFDLElBQUs7TUFDWixJQUFJLENBQUNBLENBQUMsQ0FBQzNCLFdBQVcsRUFBRSxPQUFPLENBQUMsQ0FBQztNQUM3QixNQUFNbUwsS0FBSyxHQUFHeEosQ0FBQyxDQUFDdEMsT0FBTyxDQUFDSSxLQUFLLENBQUMsQ0FBQyxDQUFDMkwsSUFBSSxDQUFDLENBQUNDLENBQUMsRUFBRUMsQ0FBQyxLQUFLLENBQUNELENBQUMsQ0FBQ3JELENBQUMsSUFBSSxDQUFDLEtBQUtzRCxDQUFDLENBQUN0RCxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQ2hGLEdBQUcsQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUNyRyxFQUFFLENBQUMsQ0FBQ0csTUFBTSxDQUFFSCxFQUFFLElBQUtBLEVBQUUsS0FBSytFLENBQUMsQ0FBQzNCLFdBQVcsQ0FBQztNQUM3SCxJQUFJLENBQUNtTCxLQUFLLENBQUM1RixNQUFNLEVBQUUsT0FBTyxDQUFDLENBQUM7TUFDNUIsTUFBTWEsR0FBRyxHQUFHK0UsS0FBSyxDQUFDUSxPQUFPLENBQUNoSyxDQUFDLENBQUMxQixhQUFhLElBQUlrTCxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7TUFDdEQsT0FBTztRQUFFbEwsYUFBYSxFQUFFa0wsS0FBSyxDQUFDLENBQUMvRSxHQUFHLEdBQUdzRixHQUFHLEdBQUdQLEtBQUssQ0FBQzVGLE1BQU0sSUFBSTRGLEtBQUssQ0FBQzVGLE1BQU07TUFBRSxDQUFDO0lBQzVFLENBQUMsQ0FBQztFQUNKLENBQUMsRUFDRCxDQUFDdkUsTUFBTSxDQUNULENBQUM7O0VBRUQ7RUFDQSxNQUFNNEssWUFBWSxHQUFHLElBQUE3TixrQkFBVyxFQUM3QmhDLENBQXFCLElBQUs7SUFDekIsTUFBTTRGLENBQUMsR0FBR2QsUUFBUSxDQUFDRSxPQUFPO0lBQzFCLElBQUlZLENBQUMsQ0FBQ3ZCLFNBQVMsRUFBRVksTUFBTSxDQUFDO01BQUVaLFNBQVMsRUFBRTtJQUFLLENBQUMsQ0FBQztJQUM1QyxJQUFJdUIsQ0FBQyxDQUFDbkIsWUFBWSxFQUFFUSxNQUFNLENBQUM7TUFBRVIsWUFBWSxFQUFFO0lBQU0sQ0FBQyxDQUFDO0lBQ25ELE1BQU1xTCxHQUFHLEdBQUc5UCxDQUFDLENBQUMrUCxNQUFNLEtBQUssQ0FBQztJQUMxQixJQUFJbkssQ0FBQyxDQUFDakQsSUFBSSxLQUFLLE1BQU0sSUFBSSxDQUFDTCxRQUFRLENBQUMwQyxPQUFPLElBQUksQ0FBQzhLLEdBQUcsSUFBSSxDQUFDMUssUUFBUSxDQUFDLENBQUMsRUFBRTtNQUNqRSxNQUFNLENBQUNNLEVBQUUsRUFBRUMsRUFBRSxDQUFDLEdBQUdOLFVBQVUsQ0FBQ3JGLENBQUMsQ0FBQztNQUM5QixJQUFJLENBQUNBLENBQUMsQ0FBQ2dRLFFBQVEsRUFBRS9LLE1BQU0sQ0FBQztRQUFFcEIsU0FBUyxFQUFFO01BQUcsQ0FBQyxDQUFDO01BQzFDM0IsT0FBTyxDQUFDOEMsT0FBTyxHQUFHO1FBQUVpTCxJQUFJLEVBQUUsU0FBUztRQUFFQyxFQUFFLEVBQUV4SyxFQUFFO1FBQUV5SyxFQUFFLEVBQUV4SyxFQUFFO1FBQUV5SyxHQUFHLEVBQUVwUSxDQUFDLENBQUNnUSxRQUFRO1FBQUVLLElBQUksRUFBRXpLLENBQUMsQ0FBQy9CLFNBQVMsQ0FBQ0gsS0FBSyxDQUFDO01BQUUsQ0FBQztNQUNqR3VCLE1BQU0sQ0FBQztRQUFFbEIsT0FBTyxFQUFFO1VBQUU5QyxDQUFDLEVBQUV5RSxFQUFFO1VBQUVvRyxDQUFDLEVBQUVuRyxFQUFFO1VBQUV5RCxDQUFDLEVBQUUsQ0FBQztVQUFFQyxDQUFDLEVBQUU7UUFBRTtNQUFFLENBQUMsQ0FBQztJQUNuRCxDQUFDLE1BQU07TUFDTG5ILE9BQU8sQ0FBQzhDLE9BQU8sR0FBRztRQUFFaUwsSUFBSSxFQUFFLEtBQUs7UUFBRUMsRUFBRSxFQUFFbFEsQ0FBQyxDQUFDc0YsT0FBTztRQUFFNkssRUFBRSxFQUFFblEsQ0FBQyxDQUFDdUYsT0FBTztRQUFFckMsRUFBRSxFQUFFMEMsQ0FBQyxDQUFDM0MsR0FBRyxDQUFDQyxFQUFFO1FBQUVDLEVBQUUsRUFBRXlDLENBQUMsQ0FBQzNDLEdBQUcsQ0FBQ0U7TUFBRyxDQUFDO01BQzNGOEIsTUFBTSxDQUFDO1FBQUVQLE9BQU8sRUFBRTtNQUFLLENBQUMsQ0FBQztJQUMzQjtFQUNGLENBQUMsRUFDRCxDQUFDTyxNQUFNLEVBQUVHLFFBQVEsRUFBRUMsVUFBVSxDQUMvQixDQUFDO0VBRUQsTUFBTWlMLGNBQWMsR0FBRyxJQUFBdE8sa0JBQVcsRUFDaEMsQ0FBQ25CLEVBQVUsRUFBRWIsQ0FBcUIsS0FBSztJQUNyQ0EsQ0FBQyxDQUFDdVEsZUFBZSxDQUFDLENBQUM7SUFDbkIsTUFBTTNLLENBQUMsR0FBR2QsUUFBUSxDQUFDRSxPQUFPO0lBQzFCLElBQUlZLENBQUMsQ0FBQ2pELElBQUksS0FBSyxNQUFNLEVBQUU7TUFDckJULE9BQU8sQ0FBQzhDLE9BQU8sR0FBRztRQUFFaUwsSUFBSSxFQUFFLEtBQUs7UUFBRUMsRUFBRSxFQUFFbFEsQ0FBQyxDQUFDc0YsT0FBTztRQUFFNkssRUFBRSxFQUFFblEsQ0FBQyxDQUFDdUYsT0FBTztRQUFFckMsRUFBRSxFQUFFMEMsQ0FBQyxDQUFDM0MsR0FBRyxDQUFDQyxFQUFFO1FBQUVDLEVBQUUsRUFBRXlDLENBQUMsQ0FBQzNDLEdBQUcsQ0FBQ0U7TUFBRyxDQUFDO01BQzNGOEIsTUFBTSxDQUFDO1FBQUVQLE9BQU8sRUFBRTtNQUFLLENBQUMsQ0FBQztNQUN6QjtJQUNGO0lBQ0EsTUFBTXdDLENBQUMsR0FBR3RCLENBQUMsQ0FBQ3RDLE9BQU8sQ0FBQ3FFLElBQUksQ0FBRTFHLENBQUMsSUFBS0EsQ0FBQyxDQUFDSixFQUFFLEtBQUtBLEVBQUUsQ0FBQztJQUM1QyxJQUFJLENBQUNxRyxDQUFDLEVBQUU7SUFDUjtJQUNBLE1BQU10RyxHQUFHLEdBQUdELGNBQWMsQ0FBQ2lGLENBQUMsQ0FBQy9CLFNBQVMsRUFBRWhELEVBQUUsRUFBRWIsQ0FBQyxDQUFDZ1EsUUFBUSxDQUFDO0lBQ3ZEL0ssTUFBTSxDQUFDO01BQUVwQixTQUFTLEVBQUVqRCxHQUFHO01BQUV1RCxhQUFhLEVBQUUsSUFBSTtNQUFFRSxTQUFTLEVBQUU7SUFBSyxDQUFDLENBQUM7SUFDaEUsSUFBSTZDLENBQUMsQ0FBQ3NKLE1BQU0sRUFBRTtJQUNkLE1BQU1DLElBQThDLEdBQUcsQ0FBQyxDQUFDO0lBQ3pEN0ssQ0FBQyxDQUFDdEMsT0FBTyxDQUFDb04sT0FBTyxDQUFFelAsQ0FBQyxJQUFLO01BQ3ZCLElBQUlMLEdBQUcsQ0FBQ0csUUFBUSxDQUFDRSxDQUFDLENBQUNKLEVBQUUsQ0FBQyxFQUFFNFAsSUFBSSxDQUFDeFAsQ0FBQyxDQUFDSixFQUFFLENBQUMsR0FBRztRQUFFSSxDQUFDLEVBQUVBLENBQUMsQ0FBQ0EsQ0FBQztRQUFFNkssQ0FBQyxFQUFFN0ssQ0FBQyxDQUFDNks7TUFBRSxDQUFDO0lBQ3pELENBQUMsQ0FBQztJQUNGNUosT0FBTyxDQUFDOEMsT0FBTyxHQUFHO01BQUVpTCxJQUFJLEVBQUUsTUFBTTtNQUFFQyxFQUFFLEVBQUVsUSxDQUFDLENBQUNzRixPQUFPO01BQUU2SyxFQUFFLEVBQUVuUSxDQUFDLENBQUN1RixPQUFPO01BQUUrQixHQUFHLEVBQUUxRyxHQUFHO01BQUU2UCxJQUFJO01BQUVFLEtBQUssRUFBRTtJQUFNLENBQUM7RUFDaEcsQ0FBQyxFQUNELENBQUMxTCxNQUFNLENBQ1QsQ0FBQztFQUVELE1BQU0yTCxXQUFXLEdBQUcsSUFBQTVPLGtCQUFXLEVBQUMsQ0FBQzBKLElBQXlCLEVBQUVqRSxNQUFjLEVBQUV6SCxDQUFxQixLQUFLO0lBQ3BHQSxDQUFDLENBQUN1USxlQUFlLENBQUMsQ0FBQztJQUNuQixNQUFNM0ssQ0FBQyxHQUFHZCxRQUFRLENBQUNFLE9BQU87SUFDMUIsTUFBTW5FLEVBQUUsR0FBRytFLENBQUMsQ0FBQy9CLFNBQVMsQ0FBQyxDQUFDLENBQUM7SUFDekIsTUFBTXFELENBQUMsR0FBR3RCLENBQUMsQ0FBQ3RDLE9BQU8sQ0FBQ3FFLElBQUksQ0FBRTFHLENBQUMsSUFBS0EsQ0FBQyxDQUFDSixFQUFFLEtBQUtBLEVBQUUsQ0FBQztJQUM1QyxJQUFJLENBQUNxRyxDQUFDLEVBQUU7SUFDUixNQUFNbUosSUFBSSxHQUFHO01BQUVwUCxDQUFDLEVBQUVpRyxDQUFDLENBQUNqRyxDQUFDO01BQUU2SyxDQUFDLEVBQUU1RSxDQUFDLENBQUM0RSxDQUFDO01BQUUxQyxDQUFDLEVBQUVsQyxDQUFDLENBQUNrQyxDQUFDO01BQUVDLENBQUMsRUFBRW5DLENBQUMsQ0FBQ21DLENBQUM7TUFBRTBDLEdBQUcsRUFBRTdFLENBQUMsQ0FBQzZFO0lBQUksQ0FBQztJQUMzRDdKLE9BQU8sQ0FBQzhDLE9BQU8sR0FDYjBHLElBQUksS0FBSyxRQUFRLEdBQ2I7TUFBRXVFLElBQUksRUFBRSxRQUFRO01BQUVDLEVBQUUsRUFBRWxRLENBQUMsQ0FBQ3NGLE9BQU87TUFBRTZLLEVBQUUsRUFBRW5RLENBQUMsQ0FBQ3VGLE9BQU87TUFBRTJCLENBQUMsRUFBRW1KLElBQUk7TUFBRXhQLEVBQUU7TUFBRThQLEtBQUssRUFBRTtJQUFNLENBQUMsR0FDM0U7TUFBRVYsSUFBSSxFQUFFLFFBQVE7TUFBRXZFLElBQUksRUFBRWpFLE1BQU07TUFBRXlJLEVBQUUsRUFBRWxRLENBQUMsQ0FBQ3NGLE9BQU87TUFBRTZLLEVBQUUsRUFBRW5RLENBQUMsQ0FBQ3VGLE9BQU87TUFBRTJCLENBQUMsRUFBRW1KLElBQUk7TUFBRXhQLEVBQUU7TUFBRThQLEtBQUssRUFBRTtJQUFNLENBQUM7RUFDakcsQ0FBQyxFQUFFLEVBQUUsQ0FBQztFQUVOLE1BQU1FLFlBQVksR0FBRyxJQUFBN08sa0JBQVcsRUFDOUIsQ0FBQ25CLEVBQVUsRUFBRWlRLElBQVksRUFBRTlRLENBQXFCLEtBQUs7SUFDbkRBLENBQUMsQ0FBQ3VRLGVBQWUsQ0FBQyxDQUFDO0lBQ25Cck8sT0FBTyxDQUFDOEMsT0FBTyxHQUFHO01BQUVpTCxJQUFJLEVBQUUsU0FBUztNQUFFM0gsSUFBSSxFQUFFekgsRUFBRTtNQUFFaVEsSUFBSTtNQUFFSCxLQUFLLEVBQUU7SUFBTSxDQUFDO0lBQ25FLE1BQU0sQ0FBQ2pMLEVBQUUsRUFBRUMsRUFBRSxDQUFDLEdBQUdOLFVBQVUsQ0FBQ3JGLENBQUMsQ0FBQztJQUM5QmlGLE1BQU0sQ0FBQztNQUFFakIsY0FBYyxFQUFFO1FBQUVzRSxJQUFJLEVBQUV6SCxFQUFFO1FBQUVJLENBQUMsRUFBRXlFLEVBQUU7UUFBRW9HLENBQUMsRUFBRW5HLEVBQUU7UUFBRXFDLE1BQU0sRUFBRTtNQUFLO0lBQUUsQ0FBQyxDQUFDO0VBQ3RFLENBQUMsRUFDRCxDQUFDL0MsTUFBTSxFQUFFSSxVQUFVLENBQ3JCLENBQUM7RUFFRCxNQUFNMEwsUUFBUSxHQUFHLElBQUEvTyxrQkFBVyxFQUFFbkIsRUFBaUIsSUFBS29FLE1BQU0sQ0FBQztJQUFFbkIsS0FBSyxFQUFFakQ7RUFBRyxDQUFDLENBQUMsRUFBRSxDQUFDb0UsTUFBTSxDQUFDLENBQUM7RUFDcEYsTUFBTStMLGNBQWMsR0FBRyxJQUFBaFAsa0JBQVcsRUFBQyxNQUFNaUQsTUFBTSxDQUFDO0lBQUVwQixTQUFTLEVBQUU7RUFBRyxDQUFDLENBQUMsRUFBRSxDQUFDb0IsTUFBTSxDQUFDLENBQUM7O0VBRTdFO0VBQ0EsTUFBTWdNLE1BQU0sR0FBRyxJQUFBalAsa0JBQVc7RUFDeEI7RUFDQTtFQUNBO0VBQ0EsTUFBTWlELE1BQU0sQ0FBQztJQUFFdEMsSUFBSSxFQUFFLEtBQUs7SUFBRWtCLFNBQVMsRUFBRSxFQUFFO0lBQUVNLGFBQWEsRUFBRSxLQUFLO0lBQUVFLFNBQVMsRUFBRSxJQUFJO0lBQUVMLGNBQWMsRUFBRSxJQUFJO0lBQUVDLFdBQVcsRUFBRSxJQUFJO0lBQUVDLGFBQWEsRUFBRTtFQUFLLENBQUMsQ0FBQyxFQUNqSixDQUFDZSxNQUFNLENBQ1QsQ0FBQztFQUNELE1BQU1pTSxPQUFPLEdBQUcsSUFBQWxQLGtCQUFXLEVBQUMsTUFBTWlELE1BQU0sQ0FBQztJQUFFdEMsSUFBSSxFQUFFO0VBQU8sQ0FBQyxDQUFDLEVBQUUsQ0FBQ3NDLE1BQU0sQ0FBQyxDQUFDO0VBQ3JFLE1BQU1rTSxXQUFXLEdBQUcsSUFBQW5QLGtCQUFXLEVBQUMsTUFBTWlELE1BQU0sQ0FBRVcsQ0FBQyxLQUFNO0lBQUVoRCxLQUFLLEVBQUUsQ0FBQ2dELENBQUMsQ0FBQ2hEO0VBQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDcUMsTUFBTSxDQUFDLENBQUM7RUFDckYsTUFBTW1NLFdBQVcsR0FBRyxJQUFBcFAsa0JBQVcsRUFBQyxNQUFNaUQsTUFBTSxDQUFFVyxDQUFDLEtBQU07SUFBRXhCLFNBQVMsRUFBRSxDQUFDd0IsQ0FBQyxDQUFDeEI7RUFBVSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUNhLE1BQU0sQ0FBQyxDQUFDO0VBQzdGLE1BQU1vTSxTQUFTLEdBQUcsSUFBQXJQLGtCQUFXLEVBQUV3QyxNQUFrQixJQUFLUyxNQUFNLENBQUM7SUFBRVQ7RUFBTyxDQUFDLENBQUMsRUFBRSxDQUFDUyxNQUFNLENBQUMsQ0FBQztFQUNuRixNQUFNcU0sYUFBYSxHQUFHLElBQUF0UCxrQkFBVyxFQUFFYSxFQUFjLElBQUtvQyxNQUFNLENBQUM7SUFBRXBDO0VBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQ29DLE1BQU0sQ0FBQyxDQUFDO0VBQy9FLE1BQU1zTSxRQUFRLEdBQUcsSUFBQXZQLGtCQUFXLEVBQUVZLEtBQWMsSUFBS3FDLE1BQU0sQ0FBQztJQUFFckM7RUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDcUMsTUFBTSxDQUFDLENBQUM7RUFDN0UsTUFBTXVNLGNBQWMsR0FBRyxJQUFBeFAsa0JBQVcsRUFBQyxNQUFNaUQsTUFBTSxDQUFDO0lBQUVkLGFBQWEsRUFBRTtFQUFNLENBQUMsQ0FBQyxFQUFFLENBQUNjLE1BQU0sQ0FBQyxDQUFDO0VBQ3BGLE1BQU13TSxVQUFVLEdBQUcsSUFBQXpQLGtCQUFXLEVBQUMsTUFBTWlELE1BQU0sQ0FBQztJQUFFYixTQUFTLEVBQUU7RUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDYSxNQUFNLENBQUMsQ0FBQztFQUM1RSxNQUFNeU0sY0FBYyxHQUFHLElBQUExUCxrQkFBVyxFQUFDLE1BQU1pRCxNQUFNLENBQUVXLENBQUMsS0FBTTtJQUFFbkIsWUFBWSxFQUFFLENBQUNtQixDQUFDLENBQUNuQjtFQUFhLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQ1EsTUFBTSxDQUFDLENBQUM7RUFFdEcsTUFBTTBNLGdCQUFnQixHQUFHLElBQUEzUCxrQkFBVyxFQUNqQ2hDLENBQW1CLElBQUs7SUFDdkIsSUFBSThFLFFBQVEsQ0FBQ0UsT0FBTyxDQUFDckMsSUFBSSxLQUFLLE1BQU0sRUFBRTtJQUN0QyxNQUFNLENBQUMrQyxFQUFFLEVBQUVDLEVBQUUsQ0FBQyxHQUFHTixVQUFVLENBQUNyRixDQUFDLENBQUM7SUFDOUIsTUFBTSxDQUFDMkwsRUFBRSxFQUFFQyxFQUFFLENBQUMsR0FBRyxJQUFBZ0csZUFBTyxFQUFDOU0sUUFBUSxDQUFDRSxPQUFPLENBQUMvQixHQUFHLEVBQUU2QixRQUFRLENBQUNFLE9BQU8sQ0FBQzNCLEVBQUUsRUFBRXFDLEVBQUUsRUFBRUMsRUFBRSxDQUFDO0lBQzNFVixNQUFNLENBQUM7TUFBRVosU0FBUyxFQUFFO1FBQUVxQixFQUFFO1FBQUVDLEVBQUU7UUFBRWdHLEVBQUU7UUFBRUM7TUFBRztJQUFFLENBQUMsQ0FBQztFQUMzQyxDQUFDLEVBQ0QsQ0FBQzNHLE1BQU0sRUFBRUksVUFBVSxDQUNyQixDQUFDOztFQUVEO0VBQ0EsTUFBTXdNLE9BQU8sR0FBRyxJQUFBN1Asa0JBQVcsRUFBQyxNQUFNO0lBQ2hDZ0UsS0FBSyxDQUFDLGtFQUFrRSxFQUFFLE9BQU8sRUFBRTtNQUNqRmMsU0FBUyxFQUFFLFNBQVM7TUFDcEJULFdBQVcsRUFBRSxXQUFXO01BQ3hCa0YsUUFBUSxFQUFFQSxDQUFBLEtBQU12RixLQUFLLENBQUMsdUJBQXVCLEVBQUUsT0FBTztJQUN4RCxDQUFDLENBQUM7RUFDSixDQUFDLEVBQUUsQ0FBQ0EsS0FBSyxDQUFDLENBQUM7RUFFWCxNQUFNOEwsYUFBYSxHQUFHLElBQUE5UCxrQkFBVyxFQUFDLE1BQU07SUFDdENpRCxNQUFNLENBQUM7TUFBRXRDLElBQUksRUFBRSxLQUFLO01BQUVrQixTQUFTLEVBQUUsRUFBRTtNQUFFTSxhQUFhLEVBQUU7SUFBTSxDQUFDLENBQUM7SUFDNUQ2QixLQUFLLENBQUMscURBQXFELEVBQUUsTUFBTSxFQUFFO01BQUVjLFNBQVMsRUFBRTtJQUFlLENBQUMsQ0FBQztFQUNyRyxDQUFDLEVBQUUsQ0FBQzdCLE1BQU0sRUFBRWUsS0FBSyxDQUFDLENBQUM7O0VBRW5CO0VBQ0EsSUFBQWpCLGdCQUFTLEVBQUMsTUFBTTtJQUNkZ04sUUFBUSxDQUFDQyxlQUFlLENBQUNDLFlBQVksQ0FBQyxZQUFZLEVBQUV4UCxLQUFLLENBQUNHLEtBQUssR0FBRyxPQUFPLEdBQUcsTUFBTSxDQUFDO0VBQ3JGLENBQUMsRUFBRSxDQUFDSCxLQUFLLENBQUNHLEtBQUssQ0FBQyxDQUFDO0VBRWpCLElBQUFtQyxnQkFBUyxFQUFDLE1BQU07SUFDZCxNQUFNOUMsRUFBRSxHQUFHTCxRQUFRO0lBQ25CLElBQUksQ0FBQ0ssRUFBRSxFQUFFO0lBRVQsTUFBTWlRLE9BQU8sR0FBR0EsQ0FBQSxLQUFNO01BQ3BCLE1BQU1DLENBQUMsR0FBR2xRLEVBQUUsQ0FBQ21RLHFCQUFxQixDQUFDLENBQUM7TUFDcENuTixNQUFNLENBQUM7UUFBRTVCLEVBQUUsRUFBRTtVQUFFakQsRUFBRSxFQUFFK1IsQ0FBQyxDQUFDRSxLQUFLO1VBQUU5UixFQUFFLEVBQUU0UixDQUFDLENBQUNHLE1BQU07VUFBRTdSLEtBQUssRUFBRTBSLENBQUMsQ0FBQ0ksSUFBSTtVQUFFN1IsSUFBSSxFQUFFeVIsQ0FBQyxDQUFDSztRQUFJO01BQUUsQ0FBQyxDQUFDO0lBQzNFLENBQUM7SUFDRE4sT0FBTyxDQUFDLENBQUM7SUFDVCxNQUFNTyxFQUFFLEdBQUcsSUFBSUMsY0FBYyxDQUFDUixPQUFPLENBQUM7SUFDdENPLEVBQUUsQ0FBQ0UsT0FBTyxDQUFDMVEsRUFBRSxDQUFDO0lBRWQsTUFBTTJRLE9BQU8sR0FBSTVTLENBQWEsSUFBSztNQUNqQ0EsQ0FBQyxDQUFDNlMsY0FBYyxDQUFDLENBQUM7TUFDbEIsTUFBTSxDQUFDbk4sRUFBRSxFQUFFQyxFQUFFLENBQUMsR0FBR04sVUFBVSxDQUFDckYsQ0FBQyxDQUFDO01BQzlCLElBQUlBLENBQUMsQ0FBQzhTLE9BQU8sSUFBSTlTLENBQUMsQ0FBQytTLE9BQU8sRUFBRTtRQUMxQixNQUFNQyxDQUFDLEdBQUdwSyxJQUFJLENBQUNxSyxHQUFHLENBQUMsQ0FBQ2pULENBQUMsQ0FBQ2tULE1BQU0sR0FBRyxJQUFJLENBQUM7UUFDcEMxTixPQUFPLENBQUNWLFFBQVEsQ0FBQ0UsT0FBTyxDQUFDL0IsR0FBRyxDQUFDRyxJQUFJLEdBQUc0UCxDQUFDLEVBQUV0TixFQUFFLEVBQUVDLEVBQUUsQ0FBQztNQUNoRCxDQUFDLE1BQU07UUFDTFYsTUFBTSxDQUFFVyxDQUFDLEtBQU07VUFBRTNDLEdBQUcsRUFBRTtZQUFFQyxFQUFFLEVBQUUwQyxDQUFDLENBQUMzQyxHQUFHLENBQUNDLEVBQUUsR0FBR2xELENBQUMsQ0FBQ21ULE1BQU0sR0FBR3ZOLENBQUMsQ0FBQzNDLEdBQUcsQ0FBQ0csSUFBSTtZQUFFRCxFQUFFLEVBQUV5QyxDQUFDLENBQUMzQyxHQUFHLENBQUNFLEVBQUUsR0FBR25ELENBQUMsQ0FBQ2tULE1BQU0sR0FBR3ROLENBQUMsQ0FBQzNDLEdBQUcsQ0FBQ0csSUFBSTtZQUFFQSxJQUFJLEVBQUV3QyxDQUFDLENBQUMzQyxHQUFHLENBQUNHO1VBQUs7UUFBRSxDQUFDLENBQUMsQ0FBQztNQUM1SDtJQUNGLENBQUM7SUFDRG5CLEVBQUUsQ0FBQ21SLGdCQUFnQixDQUFDLE9BQU8sRUFBRVIsT0FBTyxFQUFFO01BQUVTLE9BQU8sRUFBRTtJQUFNLENBQUMsQ0FBQztJQUV6RCxNQUFNQyxNQUFNLEdBQUl0VCxDQUFlLElBQUs7TUFDbEMsTUFBTXVULENBQUMsR0FBR3JSLE9BQU8sQ0FBQzhDLE9BQU87TUFDekIsSUFBSSxDQUFDdU8sQ0FBQyxFQUFFO01BQ1IsTUFBTXRILENBQUMsR0FBR25ILFFBQVEsQ0FBQ0UsT0FBTyxDQUFDL0IsR0FBRyxDQUFDRyxJQUFJO01BQ25DLElBQUltUSxDQUFDLENBQUN0RCxJQUFJLEtBQUssS0FBSyxFQUFFO1FBQ3BCLE1BQU11RCxFQUFFLEdBQUd4VCxDQUFDLENBQUNzRixPQUFPLEdBQUdpTyxDQUFDLENBQUNyRCxFQUFFO1FBQzNCLE1BQU11RCxFQUFFLEdBQUd6VCxDQUFDLENBQUN1RixPQUFPLEdBQUdnTyxDQUFDLENBQUNwRCxFQUFFO1FBQzNCbEwsTUFBTSxDQUFDO1VBQUVoQyxHQUFHLEVBQUU7WUFBRUMsRUFBRSxFQUFFcVEsQ0FBQyxDQUFDclEsRUFBRSxHQUFHc1EsRUFBRSxHQUFHdkgsQ0FBQztZQUFFOUksRUFBRSxFQUFFb1EsQ0FBQyxDQUFDcFEsRUFBRSxHQUFHc1EsRUFBRSxHQUFHeEgsQ0FBQztZQUFFN0ksSUFBSSxFQUFFNkk7VUFBRTtRQUFFLENBQUMsQ0FBQztNQUNwRSxDQUFDLE1BQU0sSUFBSXNILENBQUMsQ0FBQ3RELElBQUksS0FBSyxNQUFNLEVBQUU7UUFDNUIsTUFBTXVELEVBQUUsR0FBRyxDQUFDeFQsQ0FBQyxDQUFDc0YsT0FBTyxHQUFHaU8sQ0FBQyxDQUFDckQsRUFBRSxJQUFJakUsQ0FBQztRQUNqQyxNQUFNd0gsRUFBRSxHQUFHLENBQUN6VCxDQUFDLENBQUN1RixPQUFPLEdBQUdnTyxDQUFDLENBQUNwRCxFQUFFLElBQUlsRSxDQUFDO1FBQ2pDc0gsQ0FBQyxDQUFDNUMsS0FBSyxHQUFHLElBQUk7UUFDZDFMLE1BQU0sQ0FBRVcsQ0FBQyxLQUFNO1VBQ2J0QyxPQUFPLEVBQUVzQyxDQUFDLENBQUN0QyxPQUFPLENBQUMyRCxHQUFHLENBQUVDLENBQUMsSUFDdkJxTSxDQUFDLENBQUNqTSxHQUFHLENBQUN2RyxRQUFRLENBQUNtRyxDQUFDLENBQUNyRyxFQUFFLENBQUMsSUFBSTBTLENBQUMsQ0FBQzlDLElBQUksQ0FBQ3ZKLENBQUMsQ0FBQ3JHLEVBQUUsQ0FBQyxHQUFHO1lBQUUsR0FBR3FHLENBQUM7WUFBRWpHLENBQUMsRUFBRXNTLENBQUMsQ0FBQzlDLElBQUksQ0FBQ3ZKLENBQUMsQ0FBQ3JHLEVBQUUsQ0FBQyxDQUFDSSxDQUFDLEdBQUd1UyxFQUFFO1lBQUUxSCxDQUFDLEVBQUV5SCxDQUFDLENBQUM5QyxJQUFJLENBQUN2SixDQUFDLENBQUNyRyxFQUFFLENBQUMsQ0FBQ2lMLENBQUMsR0FBRzJIO1VBQUcsQ0FBQyxHQUFHdk0sQ0FDcEc7UUFDRixDQUFDLENBQUMsQ0FBQztNQUNMLENBQUMsTUFBTSxJQUFJcU0sQ0FBQyxDQUFDdEQsSUFBSSxLQUFLLFNBQVMsRUFBRTtRQUMvQixNQUFNLENBQUN2SyxFQUFFLEVBQUVDLEVBQUUsQ0FBQyxHQUFHTixVQUFVLENBQUNyRixDQUFDLENBQUM7UUFDOUIsTUFBTWlCLENBQUMsR0FBRzJILElBQUksQ0FBQ0csR0FBRyxDQUFDckQsRUFBRSxFQUFFNk4sQ0FBQyxDQUFDckQsRUFBRSxDQUFDO1FBQzVCLE1BQU1wRSxDQUFDLEdBQUdsRCxJQUFJLENBQUNHLEdBQUcsQ0FBQ3BELEVBQUUsRUFBRTROLENBQUMsQ0FBQ3BELEVBQUUsQ0FBQztRQUM1QixNQUFNL0csQ0FBQyxHQUFHUixJQUFJLENBQUM4SyxHQUFHLENBQUNoTyxFQUFFLEdBQUc2TixDQUFDLENBQUNyRCxFQUFFLENBQUM7UUFDN0IsTUFBTXlELEVBQUUsR0FBRy9LLElBQUksQ0FBQzhLLEdBQUcsQ0FBQy9OLEVBQUUsR0FBRzROLENBQUMsQ0FBQ3BELEVBQUUsQ0FBQztRQUM5QixNQUFNdkssQ0FBQyxHQUFHZCxRQUFRLENBQUNFLE9BQU87UUFDMUIsTUFBTXBFLEdBQUcsR0FBRyxJQUFBZ1QsdUJBQWEsRUFBQ2hPLENBQUMsQ0FBQ3RDLE9BQU8sRUFBRXNDLENBQUMsQ0FBQzNDLEdBQUcsRUFBRTJDLENBQUMsQ0FBQ3ZDLEVBQUUsRUFBRXBDLENBQUMsRUFBRTZLLENBQUMsRUFBRTFDLENBQUMsRUFBRXVLLEVBQUUsQ0FBQztRQUM5RDFPLE1BQU0sQ0FBQztVQUFFbEIsT0FBTyxFQUFFO1lBQUU5QyxDQUFDO1lBQUU2SyxDQUFDO1lBQUUxQyxDQUFDO1lBQUVDLENBQUMsRUFBRXNLO1VBQUcsQ0FBQztVQUFFOVAsU0FBUyxFQUFFMFAsQ0FBQyxDQUFDbkQsR0FBRyxHQUFHeUQsS0FBSyxDQUFDdkwsSUFBSSxDQUFDLElBQUl3TCxHQUFHLENBQUNQLENBQUMsQ0FBQ2xELElBQUksQ0FBQ25QLE1BQU0sQ0FBQ04sR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHQTtRQUFJLENBQUMsQ0FBQztNQUMzRyxDQUFDLE1BQU0sSUFBSTJTLENBQUMsQ0FBQ3RELElBQUksS0FBSyxTQUFTLEVBQUU7UUFDL0IsTUFBTSxDQUFDdkssRUFBRSxFQUFFQyxFQUFFLENBQUMsR0FBR04sVUFBVSxDQUFDckYsQ0FBQyxDQUFDO1FBQzlCLE1BQU00RixDQUFDLEdBQUdkLFFBQVEsQ0FBQ0UsT0FBTztRQUMxQixNQUFNK08sR0FBRyxHQUFHLElBQUFDLHVCQUFhLEVBQUNwTyxDQUFDLENBQUN0QyxPQUFPLEVBQUVzQyxDQUFDLENBQUMzQyxHQUFHLEVBQUUyQyxDQUFDLENBQUN2QyxFQUFFLEVBQUVxQyxFQUFFLEVBQUVDLEVBQUUsRUFBRTROLENBQUMsQ0FBQ2pMLElBQUksQ0FBQztRQUNqRXJELE1BQU0sQ0FBQztVQUFFakIsY0FBYyxFQUFFO1lBQUVzRSxJQUFJLEVBQUVpTCxDQUFDLENBQUNqTCxJQUFJO1lBQUVySCxDQUFDLEVBQUV5RSxFQUFFO1lBQUVvRyxDQUFDLEVBQUVuRyxFQUFFO1lBQUVxQyxNQUFNLEVBQUUrTDtVQUFJO1FBQUUsQ0FBQyxDQUFDO01BQ3pFLENBQUMsTUFBTSxJQUFJUixDQUFDLENBQUN0RCxJQUFJLEtBQUssUUFBUSxJQUFJc0QsQ0FBQyxDQUFDdEQsSUFBSSxLQUFLLFFBQVEsRUFBRTtRQUNyRGdFLFdBQVcsQ0FBQ1YsQ0FBQyxFQUFFdlQsQ0FBQyxDQUFDO01BQ25CO0lBQ0YsQ0FBQztJQUVELE1BQU1pVSxXQUFXLEdBQUdBLENBQUNWLENBQStDLEVBQUV2VCxDQUFlLEtBQUs7TUFDeEYsTUFBTTRGLENBQUMsR0FBR2QsUUFBUSxDQUFDRSxPQUFPO01BQzFCLE1BQU1pSCxDQUFDLEdBQUdyRyxDQUFDLENBQUMzQyxHQUFHLENBQUNHLElBQUk7TUFDcEIsTUFBTW9RLEVBQUUsR0FBRyxDQUFDeFQsQ0FBQyxDQUFDc0YsT0FBTyxHQUFHaU8sQ0FBQyxDQUFDckQsRUFBRSxJQUFJakUsQ0FBQztNQUNqQyxNQUFNd0gsRUFBRSxHQUFHLENBQUN6VCxDQUFDLENBQUN1RixPQUFPLEdBQUdnTyxDQUFDLENBQUNwRCxFQUFFLElBQUlsRSxDQUFDO01BQ2pDc0gsQ0FBQyxDQUFDNUMsS0FBSyxHQUFHLElBQUk7TUFDZDFMLE1BQU0sQ0FBRXdFLEVBQUUsS0FBTTtRQUNkbkcsT0FBTyxFQUFFbUcsRUFBRSxDQUFDbkcsT0FBTyxDQUFDMkQsR0FBRyxDQUFFQyxDQUFDLElBQUs7VUFDN0IsSUFBSUEsQ0FBQyxDQUFDckcsRUFBRSxLQUFLMFMsQ0FBQyxDQUFDMVMsRUFBRSxFQUFFLE9BQU9xRyxDQUFDO1VBQzNCLElBQUlxTSxDQUFDLENBQUN0RCxJQUFJLEtBQUssUUFBUSxFQUFFO1lBQ3ZCLE1BQU0vTSxFQUFFLEdBQUdxUSxDQUFDLENBQUNyTSxDQUFDLENBQUNqRyxDQUFDLEdBQUdzUyxDQUFDLENBQUNyTSxDQUFDLENBQUNrQyxDQUFDLEdBQUcsQ0FBQztZQUM1QixNQUFNakcsRUFBRSxHQUFHb1EsQ0FBQyxDQUFDck0sQ0FBQyxDQUFDNEUsQ0FBQyxHQUFHeUgsQ0FBQyxDQUFDck0sQ0FBQyxDQUFDbUMsQ0FBQyxHQUFHLENBQUM7WUFDNUIsTUFBTSxDQUFDM0QsRUFBRSxFQUFFQyxFQUFFLENBQUMsR0FBR04sVUFBVSxDQUFDckYsQ0FBQyxDQUFDO1lBQzlCLE1BQU0sQ0FBQzJMLEVBQUUsRUFBRUMsRUFBRSxDQUFDLEdBQUcsSUFBQWdHLGVBQU8sRUFBQ2hNLENBQUMsQ0FBQzNDLEdBQUcsRUFBRTJDLENBQUMsQ0FBQ3ZDLEVBQUUsRUFBRXFDLEVBQUUsRUFBRUMsRUFBRSxDQUFDO1lBQzdDLElBQUl1TyxHQUFHLEdBQUl0TCxJQUFJLENBQUN1TCxLQUFLLENBQUN2SSxFQUFFLEdBQUd6SSxFQUFFLEVBQUV3SSxFQUFFLEdBQUd6SSxFQUFFLENBQUMsR0FBRyxHQUFHLEdBQUkwRixJQUFJLENBQUN3TCxFQUFFLEdBQUcsRUFBRTtZQUM3RCxJQUFJcFUsQ0FBQyxDQUFDZ1EsUUFBUSxFQUFFa0UsR0FBRyxHQUFHdEwsSUFBSSxDQUFDeUwsS0FBSyxDQUFDSCxHQUFHLEdBQUcsRUFBRSxDQUFDLEdBQUcsRUFBRTtZQUMvQyxPQUFPO2NBQUUsR0FBR2hOLENBQUM7Y0FBRTZFLEdBQUcsRUFBRW5ELElBQUksQ0FBQ3lMLEtBQUssQ0FBQ0gsR0FBRztZQUFFLENBQUM7VUFDdkM7VUFDQSxJQUFJalQsQ0FBQyxHQUFHc1MsQ0FBQyxDQUFDck0sQ0FBQyxDQUFDakcsQ0FBQztVQUNiLElBQUk2SyxDQUFDLEdBQUd5SCxDQUFDLENBQUNyTSxDQUFDLENBQUM0RSxDQUFDO1VBQ2IsSUFBSTFDLENBQUMsR0FBR21LLENBQUMsQ0FBQ3JNLENBQUMsQ0FBQ2tDLENBQUM7VUFDYixJQUFJdUssRUFBRSxHQUFHSixDQUFDLENBQUNyTSxDQUFDLENBQUNtQyxDQUFDO1VBQ2QsTUFBTWlMLENBQUMsR0FBR2YsQ0FBQyxDQUFDN0gsSUFBSTtVQUNoQixJQUFJNEksQ0FBQyxDQUFDdlQsUUFBUSxDQUFDLEdBQUcsQ0FBQyxFQUFFcUksQ0FBQyxHQUFHUixJQUFJLENBQUNtQyxHQUFHLENBQUMsRUFBRSxFQUFFd0ksQ0FBQyxDQUFDck0sQ0FBQyxDQUFDa0MsQ0FBQyxHQUFHb0ssRUFBRSxDQUFDO1VBQ2pELElBQUljLENBQUMsQ0FBQ3ZULFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBRTRTLEVBQUUsR0FBRy9LLElBQUksQ0FBQ21DLEdBQUcsQ0FBQyxFQUFFLEVBQUV3SSxDQUFDLENBQUNyTSxDQUFDLENBQUNtQyxDQUFDLEdBQUdvSyxFQUFFLENBQUM7VUFDbEQsSUFBSWEsQ0FBQyxDQUFDdlQsUUFBUSxDQUFDLEdBQUcsQ0FBQyxFQUFFO1lBQ25CcUksQ0FBQyxHQUFHUixJQUFJLENBQUNtQyxHQUFHLENBQUMsRUFBRSxFQUFFd0ksQ0FBQyxDQUFDck0sQ0FBQyxDQUFDa0MsQ0FBQyxHQUFHb0ssRUFBRSxDQUFDO1lBQzVCdlMsQ0FBQyxHQUFHc1MsQ0FBQyxDQUFDck0sQ0FBQyxDQUFDakcsQ0FBQyxJQUFJc1MsQ0FBQyxDQUFDck0sQ0FBQyxDQUFDa0MsQ0FBQyxHQUFHQSxDQUFDLENBQUM7VUFDekI7VUFDQSxJQUFJa0wsQ0FBQyxDQUFDdlQsUUFBUSxDQUFDLEdBQUcsQ0FBQyxFQUFFO1lBQ25CNFMsRUFBRSxHQUFHL0ssSUFBSSxDQUFDbUMsR0FBRyxDQUFDLEVBQUUsRUFBRXdJLENBQUMsQ0FBQ3JNLENBQUMsQ0FBQ21DLENBQUMsR0FBR29LLEVBQUUsQ0FBQztZQUM3QjNILENBQUMsR0FBR3lILENBQUMsQ0FBQ3JNLENBQUMsQ0FBQzRFLENBQUMsSUFBSXlILENBQUMsQ0FBQ3JNLENBQUMsQ0FBQ21DLENBQUMsR0FBR3NLLEVBQUUsQ0FBQztVQUMxQjtVQUNBLE9BQU87WUFBRSxHQUFHek0sQ0FBQztZQUFFakcsQ0FBQztZQUFFNkssQ0FBQztZQUFFMUMsQ0FBQztZQUFFQyxDQUFDLEVBQUVzSztVQUFHLENBQUM7UUFDakMsQ0FBQztNQUNILENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVELE1BQU1ZLElBQUksR0FBSXZVLENBQWUsSUFBSztNQUNoQyxNQUFNdVQsQ0FBQyxHQUFHclIsT0FBTyxDQUFDOEMsT0FBTztNQUN6QjlDLE9BQU8sQ0FBQzhDLE9BQU8sR0FBRyxJQUFJO01BQ3RCLElBQUksQ0FBQ3VPLENBQUMsRUFBRTtRQUNOLElBQUl6TyxRQUFRLENBQUNFLE9BQU8sQ0FBQ04sT0FBTyxFQUFFTyxNQUFNLENBQUM7VUFBRVAsT0FBTyxFQUFFO1FBQU0sQ0FBQyxDQUFDO1FBQ3hEO01BQ0Y7TUFDQSxJQUFJNk8sQ0FBQyxDQUFDdEQsSUFBSSxLQUFLLEtBQUssRUFBRTtRQUNwQmhMLE1BQU0sQ0FBQztVQUFFUCxPQUFPLEVBQUU7UUFBTSxDQUFDLENBQUM7TUFDNUIsQ0FBQyxNQUFNLElBQUk2TyxDQUFDLENBQUN0RCxJQUFJLEtBQUssTUFBTSxJQUFJc0QsQ0FBQyxDQUFDNUMsS0FBSyxFQUFFO1FBQ3ZDLE1BQU1BLEtBQUssR0FBRzdMLFFBQVEsQ0FBQ0UsT0FBTyxDQUFDMUIsT0FBTyxDQUFDdEMsTUFBTSxDQUFFa0csQ0FBQyxJQUFLcU0sQ0FBQyxDQUFDak0sR0FBRyxDQUFDdkcsUUFBUSxDQUFDbUcsQ0FBQyxDQUFDckcsRUFBRSxDQUFDLENBQUM7UUFDMUU2RixVQUFVLENBQUNpSyxLQUFLLEVBQUUsb0JBQW9CNEMsQ0FBQyxDQUFDak0sR0FBRyxDQUFDa0MsTUFBTSxHQUFHLENBQUMsR0FBRyxHQUFHK0osQ0FBQyxDQUFDak0sR0FBRyxDQUFDa0MsTUFBTSxRQUFRLEdBQUcsR0FBRytKLENBQUMsQ0FBQ2pNLEdBQUcsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUM7TUFDekcsQ0FBQyxNQUFNLElBQUlpTSxDQUFDLENBQUN0RCxJQUFJLEtBQUssU0FBUyxFQUFFO1FBQy9CaEwsTUFBTSxDQUFDO1VBQUVsQixPQUFPLEVBQUU7UUFBSyxDQUFDLENBQUM7TUFDM0IsQ0FBQyxNQUFNLElBQUl3UCxDQUFDLENBQUN0RCxJQUFJLEtBQUssU0FBUyxFQUFFO1FBQy9CLE1BQU0sQ0FBQ3ZLLEVBQUUsRUFBRUMsRUFBRSxDQUFDLEdBQUdOLFVBQVUsQ0FBQ3JGLENBQUMsQ0FBQztRQUM5QixNQUFNNEYsQ0FBQyxHQUFHZCxRQUFRLENBQUNFLE9BQU87UUFDMUIsTUFBTStPLEdBQUcsR0FBRyxJQUFBQyx1QkFBYSxFQUFDcE8sQ0FBQyxDQUFDdEMsT0FBTyxFQUFFc0MsQ0FBQyxDQUFDM0MsR0FBRyxFQUFFMkMsQ0FBQyxDQUFDdkMsRUFBRSxFQUFFcUMsRUFBRSxFQUFFQyxFQUFFLEVBQUU0TixDQUFDLENBQUNqTCxJQUFJLENBQUM7UUFDakUsSUFBSXlMLEdBQUcsRUFBRW5GLGFBQWEsQ0FBQzJFLENBQUMsQ0FBQ2pMLElBQUksRUFBRXlMLEdBQUcsQ0FBQztRQUNuQzlPLE1BQU0sQ0FBQztVQUFFakIsY0FBYyxFQUFFO1FBQUssQ0FBQyxDQUFDO01BQ2xDLENBQUMsTUFBTSxJQUFJLENBQUN1UCxDQUFDLENBQUN0RCxJQUFJLEtBQUssUUFBUSxJQUFJc0QsQ0FBQyxDQUFDdEQsSUFBSSxLQUFLLFFBQVEsS0FBS3NELENBQUMsQ0FBQzVDLEtBQUssRUFBRTtRQUNsRSxNQUFNekosQ0FBQyxHQUFHcEMsUUFBUSxDQUFDRSxPQUFPLENBQUMxQixPQUFPLENBQUNxRSxJQUFJLENBQUUxRyxDQUFDLElBQUtBLENBQUMsQ0FBQ0osRUFBRSxLQUFLMFMsQ0FBQyxDQUFDMVMsRUFBRSxDQUFDO1FBQzdENkYsVUFBVSxDQUFDUSxDQUFDLEdBQUcsQ0FBQ0EsQ0FBQyxDQUFDLEdBQUcsRUFBRSxFQUFFLGlCQUFpQixDQUFDO01BQzdDO0lBQ0YsQ0FBQztJQUVELE1BQU1zTixTQUFTLEdBQUl4VSxDQUFnQixJQUFLO01BQ3RDLE1BQU0rRixDQUFDLEdBQUcvRixDQUFDLENBQUNnSSxNQUE0QjtNQUN4QyxJQUFJakMsQ0FBQyxLQUFLQSxDQUFDLENBQUMwTyxPQUFPLEtBQUssT0FBTyxJQUFJMU8sQ0FBQyxDQUFDME8sT0FBTyxLQUFLLFVBQVUsSUFBSTFPLENBQUMsQ0FBQzBPLE9BQU8sS0FBSyxRQUFRLElBQUkxTyxDQUFDLENBQUMyTyxpQkFBaUIsQ0FBQyxFQUFFO01BQy9HLE1BQU05TyxDQUFDLEdBQUdkLFFBQVEsQ0FBQ0UsT0FBTztNQUMxQixJQUFJWSxDQUFDLENBQUN0QixPQUFPLEVBQUU7UUFDYixJQUFJdEUsQ0FBQyxDQUFDMlUsR0FBRyxLQUFLLFlBQVksSUFBSTNVLENBQUMsQ0FBQzJVLEdBQUcsS0FBSyxHQUFHLEVBQUU7VUFDM0MzVSxDQUFDLENBQUM2UyxjQUFjLENBQUMsQ0FBQztVQUNsQmxJLFFBQVEsQ0FBQyxDQUFDO1FBQ1osQ0FBQyxNQUFNLElBQUkzSyxDQUFDLENBQUMyVSxHQUFHLEtBQUssV0FBVyxFQUFFO1VBQ2hDN0osUUFBUSxDQUFDLENBQUM7UUFDWixDQUFDLE1BQU0sSUFBSTlLLENBQUMsQ0FBQzJVLEdBQUcsS0FBSyxRQUFRLEVBQUU7VUFDN0JqSyxRQUFRLENBQUMsQ0FBQztRQUNaO1FBQ0E7TUFDRjtNQUNBO01BQ0E7TUFDQTtNQUNBLElBQUk5RSxDQUFDLENBQUMzQixXQUFXLEVBQUU7UUFDakIsSUFBSWpFLENBQUMsQ0FBQzJVLEdBQUcsS0FBSyxXQUFXLElBQUkzVSxDQUFDLENBQUMyVSxHQUFHLEtBQUssU0FBUyxFQUFFO1VBQ2hEM1UsQ0FBQyxDQUFDNlMsY0FBYyxDQUFDLENBQUM7VUFDbEJuRCxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN2QixDQUFDLE1BQU0sSUFBSTFQLENBQUMsQ0FBQzJVLEdBQUcsS0FBSyxZQUFZLElBQUkzVSxDQUFDLENBQUMyVSxHQUFHLEtBQUssV0FBVyxFQUFFO1VBQzFEM1UsQ0FBQyxDQUFDNlMsY0FBYyxDQUFDLENBQUM7VUFDbEJuRCxpQkFBaUIsQ0FBQyxDQUFDLENBQUM7UUFDdEIsQ0FBQyxNQUFNLElBQUkxUCxDQUFDLENBQUMyVSxHQUFHLEtBQUssT0FBTyxFQUFFO1VBQzVCM1UsQ0FBQyxDQUFDNlMsY0FBYyxDQUFDLENBQUM7VUFDbEJyRCxVQUFVLENBQUMsSUFBSSxDQUFDO1FBQ2xCLENBQUMsTUFBTSxJQUFJeFAsQ0FBQyxDQUFDMlUsR0FBRyxLQUFLLFFBQVEsRUFBRTtVQUM3QjNVLENBQUMsQ0FBQzZTLGNBQWMsQ0FBQyxDQUFDO1VBQ2xCckQsVUFBVSxDQUFDLEtBQUssQ0FBQztRQUNuQjtRQUNBO01BQ0Y7TUFDQSxJQUFJeFAsQ0FBQyxDQUFDMlUsR0FBRyxLQUFLLFFBQVEsRUFBRTFQLE1BQU0sQ0FBQztRQUFFcEIsU0FBUyxFQUFFLEVBQUU7UUFBRVEsU0FBUyxFQUFFLElBQUk7UUFBRUcsTUFBTSxFQUFFO01BQUssQ0FBQyxDQUFDO01BQ2hGLElBQUl4RSxDQUFDLENBQUMyVSxHQUFHLEtBQUssR0FBRyxFQUFFclMsUUFBUSxDQUFDMEMsT0FBTyxHQUFHLElBQUk7TUFDMUMsSUFBSVksQ0FBQyxDQUFDakQsSUFBSSxLQUFLLE1BQU0sSUFBSWlELENBQUMsQ0FBQy9CLFNBQVMsQ0FBQzJGLE1BQU0sRUFBRTtRQUMzQyxNQUFNVixJQUFJLEdBQUc5SSxDQUFDLENBQUNnUSxRQUFRLEdBQUcsRUFBRSxHQUFHLENBQUM7UUFDaEMsSUFBSXdELEVBQUUsR0FBRyxDQUFDO1FBQ1YsSUFBSUMsRUFBRSxHQUFHLENBQUM7UUFDVixJQUFJelQsQ0FBQyxDQUFDMlUsR0FBRyxLQUFLLFdBQVcsRUFBRW5CLEVBQUUsR0FBRyxDQUFDMUssSUFBSSxDQUFDLEtBQ2pDLElBQUk5SSxDQUFDLENBQUMyVSxHQUFHLEtBQUssWUFBWSxFQUFFbkIsRUFBRSxHQUFHMUssSUFBSSxDQUFDLEtBQ3RDLElBQUk5SSxDQUFDLENBQUMyVSxHQUFHLEtBQUssU0FBUyxFQUFFbEIsRUFBRSxHQUFHLENBQUMzSyxJQUFJLENBQUMsS0FDcEMsSUFBSTlJLENBQUMsQ0FBQzJVLEdBQUcsS0FBSyxXQUFXLEVBQUVsQixFQUFFLEdBQUczSyxJQUFJO1FBQ3pDLElBQUkwSyxFQUFFLElBQUlDLEVBQUUsRUFBRTtVQUNaelQsQ0FBQyxDQUFDNlMsY0FBYyxDQUFDLENBQUM7VUFDbEIsTUFBTWpTLEdBQUcsR0FBR2dGLENBQUMsQ0FBQy9CLFNBQVM7VUFDdkJvQixNQUFNLENBQUV3RSxFQUFFLEtBQU07WUFBRW5HLE9BQU8sRUFBRW1HLEVBQUUsQ0FBQ25HLE9BQU8sQ0FBQzJELEdBQUcsQ0FBRUMsQ0FBQyxJQUFNdEcsR0FBRyxDQUFDRyxRQUFRLENBQUNtRyxDQUFDLENBQUNyRyxFQUFFLENBQUMsSUFBSSxDQUFDcUcsQ0FBQyxDQUFDc0osTUFBTSxHQUFHO2NBQUUsR0FBR3RKLENBQUM7Y0FBRWpHLENBQUMsRUFBRWlHLENBQUMsQ0FBQ2pHLENBQUMsR0FBR3VTLEVBQUU7Y0FBRTFILENBQUMsRUFBRTVFLENBQUMsQ0FBQzRFLENBQUMsR0FBRzJIO1lBQUcsQ0FBQyxHQUFHdk0sQ0FBRTtVQUFFLENBQUMsQ0FBQyxDQUFDO1VBQ2hJRyxZQUFZLENBQUN6RyxHQUFHLENBQUM7UUFDbkI7UUFDQSxJQUFJWixDQUFDLENBQUMyVSxHQUFHLEtBQUssUUFBUSxJQUFJM1UsQ0FBQyxDQUFDMlUsR0FBRyxLQUFLLFdBQVcsRUFBRXZKLGVBQWUsQ0FBQyxDQUFDO01BQ3BFO0lBQ0YsQ0FBQztJQUNELE1BQU13SixPQUFPLEdBQUk1VSxDQUFnQixJQUFLO01BQ3BDLElBQUlBLENBQUMsQ0FBQzJVLEdBQUcsS0FBSyxHQUFHLEVBQUVyUyxRQUFRLENBQUMwQyxPQUFPLEdBQUcsS0FBSztJQUM3QyxDQUFDO0lBRUQrTSxRQUFRLENBQUNxQixnQkFBZ0IsQ0FBQyxhQUFhLEVBQUVFLE1BQU0sQ0FBQztJQUNoRHZCLFFBQVEsQ0FBQ3FCLGdCQUFnQixDQUFDLFdBQVcsRUFBRW1CLElBQUksQ0FBQztJQUM1Q2xVLE1BQU0sQ0FBQytTLGdCQUFnQixDQUFDLFNBQVMsRUFBRW9CLFNBQVMsQ0FBQztJQUM3Q25VLE1BQU0sQ0FBQytTLGdCQUFnQixDQUFDLE9BQU8sRUFBRXdCLE9BQU8sQ0FBQztJQUV6QyxPQUFPLE1BQU07TUFDWDNTLEVBQUUsQ0FBQzRTLG1CQUFtQixDQUFDLE9BQU8sRUFBRWpDLE9BQU8sQ0FBQztNQUN4Q0gsRUFBRSxDQUFDcUMsVUFBVSxDQUFDLENBQUM7TUFDZi9DLFFBQVEsQ0FBQzhDLG1CQUFtQixDQUFDLGFBQWEsRUFBRXZCLE1BQU0sQ0FBQztNQUNuRHZCLFFBQVEsQ0FBQzhDLG1CQUFtQixDQUFDLFdBQVcsRUFBRU4sSUFBSSxDQUFDO01BQy9DbFUsTUFBTSxDQUFDd1UsbUJBQW1CLENBQUMsU0FBUyxFQUFFTCxTQUFTLENBQUM7TUFDaERuVSxNQUFNLENBQUN3VSxtQkFBbUIsQ0FBQyxPQUFPLEVBQUVELE9BQU8sQ0FBQztNQUM1QyxJQUFJeFMsUUFBUSxDQUFDNEMsT0FBTyxFQUFFcUQsb0JBQW9CLENBQUNqRyxRQUFRLENBQUM0QyxPQUFPLENBQUM7SUFDOUQsQ0FBQztJQUNEO0lBQ0E7SUFDQTtFQUNGLENBQUMsRUFBRSxDQUFDcEQsUUFBUSxDQUFDLENBQUM7O0VBRWQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0UsTUFBTW1ULG9CQUFvQixHQUFHLElBQUEvUyxrQkFBVyxFQUN0QyxNQUFPZ1QsT0FBZSxJQUF1QjtJQUMzQztJQUNBO0lBQ0E7SUFDQSxJQUFJQyxLQUFLLEdBQUcsSUFBQUMsa0NBQXFCLEVBQUNGLE9BQU8sRUFBRSxJQUFBRyxpQkFBUyxFQUFDLENBQUMsQ0FBQztJQUN2RCxLQUFLLElBQUlDLEtBQUssR0FBRyxDQUFDLEVBQUUsQ0FBQ0gsS0FBSyxJQUFJRyxLQUFLLEdBQUcsRUFBRSxFQUFFQSxLQUFLLElBQUksQ0FBQyxFQUFFO01BQ3BELE1BQU0sSUFBSXJPLE9BQU8sQ0FBRW9MLENBQUMsSUFBSzdMLFVBQVUsQ0FBQzZMLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztNQUMzQzhDLEtBQUssR0FBRyxJQUFBQyxrQ0FBcUIsRUFBQ0YsT0FBTyxFQUFFLElBQUFHLGlCQUFTLEVBQUMsQ0FBQyxDQUFDO0lBQ3JEO0lBQ0EsSUFBSSxDQUFDRixLQUFLLEVBQUU7TUFDVmpQLEtBQUssQ0FBQywwREFBMEQsRUFBRSxPQUFPLEVBQUU7UUFBRWMsU0FBUyxFQUFFO01BQVUsQ0FBQyxDQUFDO01BQ3BHLE9BQU8sS0FBSztJQUNkO0lBQ0EsTUFBTWtCLE1BQU0sR0FBRyxJQUFBcU4sZ0NBQW1CLEVBQUNKLEtBQUssQ0FBQztJQUN6QyxJQUFJO01BQ0YsSUFBSSxNQUFNLElBQUFuSCx1QkFBVyxFQUFDOUYsTUFBTSxDQUFDLEVBQUU7UUFDN0IsTUFBTW9GLGFBQWEsQ0FBQ3BGLE1BQU0sQ0FBQztNQUM3QixDQUFDLE1BQU07UUFDTDtRQUNBO1FBQ0F6QixRQUFRLENBQUN2QixPQUFPLEdBQUdnRCxNQUFNO1FBQ3pCLE1BQU1wQyxDQUFDLEdBQUdkLFFBQVEsQ0FBQ0UsT0FBTztRQUMxQixNQUFNLElBQUFzUSxxQkFBUyxFQUFDdE4sTUFBTSxFQUFFO1VBQUUxRSxPQUFPLEVBQUVzQyxDQUFDLENBQUN0QyxPQUFPO1VBQUVFLEtBQUssRUFBRW9DLENBQUMsQ0FBQ3BDLEtBQUs7VUFBRUcsUUFBUSxFQUFFaUMsQ0FBQyxDQUFDakM7UUFBUyxDQUFDLENBQUM7TUFDdkY7TUFDQXFDLEtBQUssQ0FBQyxpQkFBaUIsRUFBRSxPQUFPLENBQUM7TUFDakMsT0FBTyxJQUFJO0lBQ2IsQ0FBQyxDQUFDLE9BQU9oRyxDQUFDLEVBQUU7TUFDVmdHLEtBQUssQ0FBQyx3QkFBd0JqRyxNQUFNLENBQUNDLENBQUMsQ0FBQyxFQUFFLEVBQUUsT0FBTyxFQUFFO1FBQUU4RyxTQUFTLEVBQUU7TUFBVSxDQUFDLENBQUM7TUFDN0UsT0FBTyxLQUFLO0lBQ2Q7RUFDRixDQUFDLEVBQ0QsQ0FBQ2QsS0FBSyxFQUFFb0gsYUFBYSxDQUN2QixDQUFDOztFQUVEO0VBQ0EsSUFBQXJJLGdCQUFTLEVBQUMsTUFBTTtJQUNkLElBQUl3USxTQUFTLEdBQUcsS0FBSztJQUNyQixJQUFJQyxLQUErQjtJQUNuQyxNQUFNQyxNQUFNLEdBQUdqUCxVQUFVLENBQUN4QixPQUFPO0lBQ2pDLENBQUMsWUFBWTtNQUNYO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBLElBQUkwUSxTQUFTLEdBQUcsS0FBSztNQUNyQixNQUFNL0YsR0FBRyxHQUFHLE1BQU0sSUFBQWdHLGlDQUFvQixFQUFDLENBQUM7TUFDeEMsSUFBSWhHLEdBQUcsRUFBRTtRQUNQLE1BQU1pRyxNQUFNLEdBQUcsTUFBTWIsb0JBQW9CLENBQUNwRixHQUFHLENBQUM7UUFDOUMsSUFBSWlHLE1BQU0sRUFBRSxNQUFNLElBQUFDLHlCQUFZLEVBQUMsSUFBSSxDQUFDLENBQUMsS0FDaEMsTUFBTSxJQUFBQyw2QkFBZ0IsRUFBQyxDQUFDO1FBQzdCLElBQUlQLFNBQVMsRUFBRTtRQUNmO1FBQ0E7UUFDQTtRQUNBRyxTQUFTLEdBQUdFLE1BQU07TUFDcEI7TUFFQSxJQUFJLENBQUNGLFNBQVMsRUFBRTtRQUNkLElBQUkxTixNQUFtQjtRQUN2QixJQUFJO1VBQ0Y7VUFDQTtVQUNBQSxNQUFNLEdBQUcsTUFBTSxJQUFBK04sMkJBQWUsRUFBQyxDQUFDO1FBQ2xDLENBQUMsQ0FBQyxPQUFPL1YsQ0FBQyxFQUFFO1VBQ1Y7VUFDQTtVQUNBLE1BQU1nVyxPQUFPLEdBQUcsSUFBQUMsc0NBQTBCLEVBQUNqVyxDQUFDLENBQUM7VUFDN0MsSUFBSSxDQUFDdVYsU0FBUyxFQUNadlAsS0FBSyxDQUNIZ1EsT0FBTyxDQUFDRSxJQUFJLEVBQ1pGLE9BQU8sQ0FBQ0csSUFBSSxHQUFHLE1BQU0sR0FBRyxPQUFPLEVBQy9CSCxPQUFPLENBQUNHLElBQUksR0FBRztZQUFFclAsU0FBUyxFQUFFO1VBQWUsQ0FBQyxHQUFHO1lBQUVBLFNBQVMsRUFBRTtVQUFVLENBQ3hFLENBQUM7VUFDSDtRQUNGO1FBQ0EsSUFBSXlPLFNBQVMsRUFBRTtRQUNmaFAsUUFBUSxDQUFDdkIsT0FBTyxHQUFHZ0QsTUFBTTtRQUN6QixJQUFJO1VBQ0YsSUFBSSxNQUFNLElBQUE4Rix1QkFBVyxFQUFDOUYsTUFBTSxDQUFDLEVBQUU7WUFDN0IsTUFBTXFGLEtBQUssR0FBRyxNQUFNLElBQUFDLHFCQUFTLEVBQUN0RixNQUFNLENBQUM7WUFDckMsSUFBSSxDQUFDdU4sU0FBUyxFQUFFO2NBQ2R0USxNQUFNLENBQUM7Z0JBQ0wzQixPQUFPLEVBQUUrSixLQUFLLENBQUMvSixPQUFPO2dCQUN0QkUsS0FBSyxFQUFFNkosS0FBSyxDQUFDN0osS0FBSyxDQUFDZ0csTUFBTSxHQUFHNkQsS0FBSyxDQUFDN0osS0FBSyxHQUFHQyxxQkFBVSxDQUFDQyxLQUFLLENBQUMsQ0FBQztnQkFDNURDLFFBQVEsRUFBRTBKLEtBQUssQ0FBQzFKLFFBQVEsQ0FBQzZGLE1BQU0sR0FBRzZELEtBQUssQ0FBQzFKLFFBQVEsR0FBR0M7Y0FDckQsQ0FBQyxDQUFDO2NBQ0ZvQyxLQUFLLENBQUMsK0JBQStCLEVBQUUsT0FBTyxDQUFDO1lBQ2pEO1VBQ0YsQ0FBQyxNQUFNO1lBQ0w7WUFDQSxNQUFNSixDQUFDLEdBQUdkLFFBQVEsQ0FBQ0UsT0FBTztZQUMxQixNQUFNLElBQUFzUSxxQkFBUyxFQUFDdE4sTUFBTSxFQUFFO2NBQUUxRSxPQUFPLEVBQUVzQyxDQUFDLENBQUN0QyxPQUFPO2NBQUVFLEtBQUssRUFBRW9DLENBQUMsQ0FBQ3BDLEtBQUs7Y0FBRUcsUUFBUSxFQUFFaUMsQ0FBQyxDQUFDakM7WUFBUyxDQUFDLENBQUM7WUFDckYsSUFBSSxDQUFDNFIsU0FBUyxFQUFFdlAsS0FBSyxDQUFDLDhCQUE4QixFQUFFLE9BQU8sQ0FBQztVQUNoRTtRQUNGLENBQUMsQ0FBQyxPQUFPaEcsQ0FBQyxFQUFFO1VBQ1YsSUFBSSxDQUFDdVYsU0FBUyxFQUFFdlAsS0FBSyxDQUFDLHNCQUFzQmpHLE1BQU0sQ0FBQ0MsQ0FBQyxDQUFDLEVBQUUsRUFBRSxPQUFPLEVBQUU7WUFBRThHLFNBQVMsRUFBRTtVQUFVLENBQUMsQ0FBQztRQUM3RjtNQUNGO01BQ0EsSUFBSXlPLFNBQVMsRUFBRTtNQUNmO01BQ0E7TUFDQSxJQUFJO1FBQ0Z0USxNQUFNLENBQUM7VUFBRUosTUFBTSxFQUFFLElBQUFzUSxpQkFBUyxFQUFDO1FBQUUsQ0FBQyxDQUFDO01BQ2pDLENBQUMsQ0FBQyxNQUFNO1FBQ047TUFBQTtNQUVGO01BQ0E7TUFDQTtNQUNBO01BQ0EsSUFBSTtRQUNGSyxLQUFLLEdBQUcsSUFBQVksc0JBQWMsRUFBQyxDQUFDdlIsTUFBTSxFQUFFd0csT0FBTyxLQUFLO1VBQzFDcEcsTUFBTSxDQUFDO1lBQUVKO1VBQU8sQ0FBQyxDQUFDO1VBQ2xCLE1BQU13UixHQUFHLEdBQUc5UCxRQUFRLENBQUN2QixPQUFPO1VBQzVCLElBQUksQ0FBQ3FSLEdBQUcsRUFBRTtVQUNWLE1BQU1DLENBQUMsR0FBR3pSLE1BQU0sQ0FBQzhDLElBQUksQ0FBRTFHLENBQUMsSUFBTW9WLEdBQUcsQ0FBQ3pJLE9BQU8sR0FBRzNNLENBQUMsQ0FBQ0osRUFBRSxLQUFLd1YsR0FBRyxDQUFDekksT0FBTyxHQUFHM00sQ0FBQyxDQUFDeU4sSUFBSSxLQUFLMkgsR0FBRyxDQUFDelcsSUFBSyxDQUFDO1VBQ3hGLElBQUkwVyxDQUFDLEVBQUU7WUFDTCxNQUFNM1QsSUFBSSxHQUFHMlQsQ0FBQyxDQUFDM1QsSUFBSSxLQUFLLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSTtZQUMxQyxJQUFJQSxJQUFJLEtBQUswVCxHQUFHLENBQUMxVCxJQUFJLEVBQUU7Y0FDckI0RCxRQUFRLENBQUN2QixPQUFPLEdBQUc7Z0JBQUUsR0FBR3FSLEdBQUc7Z0JBQUUxVDtjQUFLLENBQUM7Y0FDbkMsSUFBSUEsSUFBSSxLQUFLLElBQUksRUFBRTtnQkFDakJzQyxNQUFNLENBQUM7a0JBQUV0QyxJQUFJLEVBQUUsS0FBSztrQkFBRWtCLFNBQVMsRUFBRSxFQUFFO2tCQUFFTSxhQUFhLEVBQUU7Z0JBQU0sQ0FBQyxDQUFDO2dCQUM1RDZCLEtBQUssQ0FBQyxtQ0FBbUMsRUFBRSxNQUFNLEVBQUU7a0JBQUVjLFNBQVMsRUFBRTtnQkFBZSxDQUFDLENBQUM7Y0FDbkY7WUFDRjtVQUNGLENBQUMsTUFBTSxJQUFJdUUsT0FBTyxDQUFDeEIsSUFBSSxDQUFFc0ksQ0FBQyxJQUFNa0UsR0FBRyxDQUFDekksT0FBTyxHQUFHdUUsQ0FBQyxDQUFDdFIsRUFBRSxLQUFLd1YsR0FBRyxDQUFDekksT0FBTyxHQUFHdUUsQ0FBQyxDQUFDekQsSUFBSSxLQUFLMkgsR0FBRyxDQUFDelcsSUFBSyxDQUFDLEVBQUU7WUFDMUYyRyxRQUFRLENBQUN2QixPQUFPLEdBQUcsSUFBSTtZQUN2QmdCLEtBQUssQ0FBQywyQkFBMkIsRUFBRSxPQUFPLEVBQUU7Y0FBRWMsU0FBUyxFQUFFO1lBQWUsQ0FBQyxDQUFDO1VBQzVFO1FBQ0YsQ0FBQyxDQUFDO01BQ0osQ0FBQyxDQUFDLE1BQU07UUFDTjtNQUFBO0lBRUosQ0FBQyxFQUFFLENBQUM7SUFDSixPQUFPLE1BQU07TUFDWHlPLFNBQVMsR0FBRyxJQUFJO01BQ2hCQyxLQUFLLEdBQUcsQ0FBQztNQUNULEtBQUssTUFBTW5NLENBQUMsSUFBSW9NLE1BQU0sQ0FBQ2MsTUFBTSxDQUFDLENBQUMsRUFBRS9PLFlBQVksQ0FBQzZCLENBQUMsQ0FBQztNQUNoRG9NLE1BQU0sQ0FBQ2UsS0FBSyxDQUFDLENBQUM7TUFDZCxJQUFJblUsU0FBUyxDQUFDMkMsT0FBTyxFQUFFd0MsWUFBWSxDQUFDbkYsU0FBUyxDQUFDMkMsT0FBTyxDQUFDO01BQ3REM0MsU0FBUyxDQUFDMkMsT0FBTyxHQUFHLElBQUk7SUFDMUIsQ0FBQztJQUNEO0lBQ0E7RUFDRixDQUFDLEVBQUUsRUFBRSxDQUFDO0VBRU4sT0FBTztJQUNMdkMsS0FBSztJQUNMVixjQUFjO0lBQ2QwVSxTQUFTLEVBQUVsUSxRQUFRLENBQUN2QixPQUFPLEVBQUVwRixJQUFJLElBQUksSUFBSTtJQUN6Q3dGLFFBQVE7SUFDUjtJQUNBc1IsT0FBTyxFQUFHdFcsRUFBVSxJQUFLLElBQUFzVyxlQUFPLEVBQUNqVSxLQUFLLENBQUNRLEdBQUcsRUFBRTdDLEVBQUUsQ0FBQztJQUMvQ3VXLE9BQU8sRUFBR3BXLEVBQVUsSUFBSyxJQUFBb1csZUFBTyxFQUFDbFUsS0FBSyxDQUFDUSxHQUFHLEVBQUUxQyxFQUFFLENBQUM7SUFDL0NxVyxPQUFPLEVBQUVBLENBQUNqTCxFQUFVLEVBQUVDLEVBQVUsS0FBSyxJQUFBZ0wsZUFBTyxFQUFDblUsS0FBSyxDQUFDUSxHQUFHLEVBQUVSLEtBQUssQ0FBQ1ksRUFBRSxFQUFFc0ksRUFBRSxFQUFFQyxFQUFFLENBQUM7SUFDekVwRyxPQUFPO0lBQ1BxUixTQUFTLEVBQVRBLGlCQUFTO0lBQ1Q5TyxLQUFLO0lBQ0wrTyxXQUFXLEVBQVhBLHFCQUFXO0lBQ1g7SUFDQWpILFlBQVk7SUFDWjhCLGdCQUFnQjtJQUNoQnJCLGNBQWM7SUFDZE0sV0FBVztJQUNYQyxZQUFZO0lBQ1pFLFFBQVE7SUFDUkMsY0FBYztJQUNkOUYsTUFBTTtJQUNOQyxjQUFjO0lBQ2Q7SUFDQWdFLFlBQVk7SUFDWkssVUFBVTtJQUNWRSxpQkFBaUI7SUFDakI7SUFDQXpFLFFBQVE7SUFDUjBELFdBQVc7SUFDWHZELGVBQWU7SUFDZkssWUFBWTtJQUNaO0lBQ0FjLFdBQVc7SUFDWDhCLFNBQVM7SUFDVE4sV0FBVztJQUNYTyxRQUFRO0lBQ1JOLFVBQVU7SUFDVlAsV0FBVztJQUNYYyxRQUFRO0lBQ1I7SUFDQWpGLFFBQVE7SUFDUkssVUFBVTtJQUNWRyxjQUFjO0lBQ2RiLFdBQVc7SUFDWHdCLFdBQVc7SUFDWEUsUUFBUTtJQUNSRyxRQUFRO0lBQ1JKLFFBQVE7SUFDUk0sUUFBUTtJQUNSO0lBQ0FpRyxNQUFNO0lBQ05DLE9BQU87SUFDUEMsV0FBVztJQUNYQyxXQUFXO0lBQ1hJLGNBQWM7SUFDZEMsVUFBVTtJQUNWSCxhQUFhO0lBQ2JDLFFBQVE7SUFDUkYsU0FBUztJQUNUSyxjQUFjO0lBQ2Q7SUFDQTFMLEtBQUs7SUFDTEYsWUFBWTtJQUNaK0wsT0FBTztJQUNQQztFQUNGLENBQUM7QUFDSCIsImlnbm9yZUxpc3QiOltdfQ==