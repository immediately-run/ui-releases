var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      blockquote: "blockquote",
      code: "code",
      del: "del",
      em: "em",
      h1: "h1",
      h2: "h2",
      hr: "hr",
      li: "li",
      ol: "ol",
      p: "p",
      strong: "strong",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "lodestar-agent-authoring-proposal",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "lodestar-agent-authoring-proposal"
      }), "Lodestar — agent authoring (proposal)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Status:"
      }), " design note (proposal) · ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Updated:"
      }), " 2026-06-26\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Platform source of truth:"
      }), " the immediately-run ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "docs"
      }), " repo,\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "specs/AGENT_AUTHORING_ARCHITECTURE.md"
      }), " — the cross-app architecture. This note is the\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Lodestar-specific"
      }), " application of it. (Grove is the sibling application; see\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "grove/docs/product-defs/grove-agent-authoring.md"
      }), ".)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["First-class agent authoring is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "aspirational"
      }), " for Lodestar today (there is no agent, no\nchat, no diagnostics wired). This note records the target architecture so the build order is\ndeliberate."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "why-lodestar-is-the-clean-exemplar",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "why-lodestar-is-the-clean-exemplar"
      }), "Why Lodestar is the clean exemplar"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Lodestar's substrate is already the shape the model wants:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Filesystem ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "is"
          }), " the document."]
        }), " One file per object (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "objects/{id}.mdx"
        }), " — YAML frontmatter", "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
          children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: ["MDX body), a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "board.md"
            }), " manifest, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "views/"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "journeys/"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "assets/"
            }), ", in a mounted board\nspace (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/lib/boardStore.ts"
            }), "). Agent-legible by construction (the README's \"an agent that\nhas never heard of this app\" can read the MDX)."]
          }), "\n"]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Minimal capabilities."
        }), " Lodestar reads/writes only its own board data; it invokes\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "pick-file"
        }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "share-space"
        }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "edit-file"
        }), " and provides ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "open-project"
        }), ". It never holds\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "llm:chat"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "net:fetch"
        }), ", secrets, or foreign-mount authority."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Document and engine already separate."
        }), " The ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "board"
        }), " lives in a mount (FS 2); Lodestar's\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "source"
        }), " is its repo (FS 1). The agent authors the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "document"
        }), "; the engine is a fixed,\nforkable app it never touches. (This is the cleaner form of the \"no engine/content\ncapability border\": there is no caps border — everything inline runs with Lodestar's\nminimal caps — only a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "substrate"
        }), " tier, document vs engine source.)"]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "So there is little to un-build. The model lands almost verbatim; what's missing are enabling\npieces, listed as deltas below."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "the-model-applied-to-lodestar",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-model-applied-to-lodestar"
      }), "The model, applied to Lodestar"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "The agent is an externalized mini-app, not ambient in Lodestar."
      }), " Because it needs\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "llm:chat"
      }), ", it runs as a separate host-brokered app with its ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "own appKey"
      }), ", under the tight\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "self-authoring agent principal"
      }), " — ceiling ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "{ chat(), diagnostics:read (subject), render:read (subject), ipc → Lodestar }"
      }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "nothing else"
      }), " (no ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "net:fetch"
      }), ", no secrets, no\nforeign mounts, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "no board write"
      }), "). Its ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "rw"
      }), " reach, when it has any, is scoped to the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "board\nmount"
      }), " — it structurally cannot touch Lodestar's engine source."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "The agent proposes; Lodestar applies."
      }), " The agent emits semantic patches over the IPC edge;\nLodestar — which owns the object model — validates and writes:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "patch(objectId, fieldOps)"
        }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.em, {
          children: ["set ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "body"
          }), " of object O"]
        }), "; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "move/resize"
        }), " (geometry); ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.em, {
          children: ["add a\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "connection"
          })]
        }), "; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "retag"
        }), "; ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.em, {
          children: ["create object ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "{ kind, x, y, w, h, body, … }"
          })]
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "putAsset(path, bytes)"
        }), " — an image (whole-file; no merge)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The agent never holds a board-write capability; Lodestar is the gatekeeper that validates\nagainst the object schema and applies through the conflict chain. Lodestar writes the board\nvia its ordinary ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "rw mount grant"
      }), " (the board mount today) — collaborator-gated, revocable,\nnot a standing app capability."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Observe + context."
      }), " Context is re-derived from files (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "board.md"
      }), " + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "objects/*.mdx"
      }), ") plus\nlive IPC deltas (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "selected objects, viewport rect, zoom"
      }), "). Observation is subject-scoped:\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "diagnostics:read"
      }), " for object-body MDX compile/transpile errors (once MDX-from-mount lands), and\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "render:read"
      }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "screenshot-leaning, because a canvas is visual"
      }), " — for the \"does it look\nright\" check. The loop: read context → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "chat()"
      }), " → emit ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "patch"
      }), " → Lodestar validates + merges"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["writes → host re-reads → diagnostics (± snapshot) → repeat; landing is a separate gated\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "contribute"
        }), "/save step."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "capability-using-objects-host-brokered-mini-apps-composited-at-rest",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "capability-using-objects-host-brokered-mini-apps-composited-at-rest"
      }), "Capability-using objects: host-brokered mini-apps, composited at rest"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["An object that needs an elevated capability (an AI widget, a network-fetching report, a\nwritable foreign mount) does ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "not"
      }), " run inline. It runs as a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "host-owned mini-app sibling"
      }), ",\ncomposited over the object's rectangle — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "never"
      }), " a Lodestar-owned ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "<iframe>"
      }), " (which would\nput Lodestar in the mini-app's TCB; today's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "embed"
      }), " object does exactly this and must be\nre-architected)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Composition is one-shot, at a settled transform."
      }), " Rather than track an affine per frame as\nthe canvas pans/zooms/rotates, show the existing ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "placeholder"
      }), " (the click-to-load preview\ncard) during motion, and overlay the live iframe ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "only when the camera rests"
      }), " — computing the\nscreen rect from the existing ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "project(cam, vp, …)"
      }), ". This sidesteps the hardest part of canvas\ncomposition (per-frame affine tracking) and composes with \"preview-until-run\": the placeholder\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "is"
      }), " the preview. It requires a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "camera-settled event"
      }), ", which does not exist today\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "flyTo()"
      }), " completes but fires no callback)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "conflicts-the-agent-is-just-another-writer",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "conflicts-the-agent-is-just-another-writer"
      }), "Conflicts: the agent is just another writer"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Scope is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "light async collaboration"
      }), ", not real-time multi-cursor (that would need a CRDT/OT\nsubstrate and break the file-writer model). Agent patches, local direct manipulation, and a\nremote collaborator all become writes to the board mount, surfaced by ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "onFsChange"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.em, {
          children: ["(Superseded 2026-06-27 by ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "AGENT_AUTHORING_ARCHITECTURE.md"
          }), " §7.2 — the field-merge, chained\nresolvers, and per-author undo below are ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "retired for V1"
          }), ". V1 conflict is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "file-level"
          }), ", two\nexisting mechanisms: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "buffer.ts"
          }), " block-on-dirty (open text) + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "RemoteOverwriteEmitter"
          }), "\n(closed-file/delete/binary). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "Field-aware merge"
          }), " (geometry last-write-per-field, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "connections"
          }), "\nset-union, body 3-way, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "tags"
          }), " set) is the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "deferred V2 CRDT track"
          }), " — so the \"field is the unit\nof conflict\" framing is a V2 property; in V1 a same-", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "object"
          }), "-file overlap (e.g. a drag's geometry\nvs. an agent's body rewrite) is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "whole-file LWW"
          }), ", recoverable-post-hoc, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "not"
          }), " field-merged.\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "Undo is per-working-tree-timeline, not per-author"
          }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "FILESYSTEM_SPEC §5"
          }), " tracks no provenance).\nThe direct-manipulation rw board writer is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "not"
          }), " serialized by the single-author lease — that\nlease bounds ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "agents"
          }), ", not FS 2.)"]
        })
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "File-per-object partitions most conflict away"
        }), " — two writers on different objects never\nconflict."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.del, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "Within an object, merge by field"
          }), " … ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "Chained resolvers"
          }), " … ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "per-author-scoped undo"
          })]
        }), " →\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "V1 is file-level"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "buffer.ts"
        }), " open-text + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "RemoteOverwriteEmitter"
        }), "); field-merge/resolvers\ndeferred V2; undo is per-working-tree-timeline (see the superseding note above). The durable\nterminal is git PR (git board) or detect-after-clobber (non-git); semantic staleness is caught at\nhuman review of the save/publish diff."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Crucially, making the agent's writes appear live needs the ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["same ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "onFsChange"
        }), "-driven per-object\nre-read"]
      }), " that multiplayer needs — build it once, it serves both."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "deltas-in-dependency-order",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "deltas-in-dependency-order"
      }), "Deltas, in dependency order"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "MDX-from-mount gate"
        }), " — compile + render object bodies inline (today bodies are static\ntext; the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "component"
        }), " kind is a stub). The enabling step for inline content-logic; safe by\nthe no-standing-high-stakes-authority invariant. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "This delta is not Lodestar-private:"
        }), "\nit is the platform-general capability specced once in the docs repo's\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "specs/MDX_FROM_MOUNT_SPEC.md"
        }), ", shared with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Grove"
        }), "'s dispatched-wiki consumer. The\nPhase-0 pipeline spike (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "WHITEBOARD_SPEC §11"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "MDX_FROM_MOUNT_SPEC §3"
        }), ") settles the\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Include"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "dynamicImport"
        }), "-vs-runtime-", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "evaluate()"
        }), " choice for ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "both"
        }), " consumers at once —\nrun it once, both ride it."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "onFsChange"
          }), "-driven per-object re-read"]
        }), " — live external writes (absent today). Serves both\nagent authoring and multiplayer; required for the loop to close."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Re-architect ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "embed"
          }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "component"
          }), " → host-brokered mini-app"]
        }), " — move iframe ownership to the\nhost; reuse the click-to-load placeholder as the preview."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Camera-settled event + static-affine region composition"
        }), " — overlay the live mini-app only\nat rest, via ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "project(cam, vp, …)"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The self-authoring agent mini-app"
        }), " + observe/context contract, scoped to the board mount;\nthe patch interface as the agent↔Lodestar protocol."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Undo + per-object conflict handling"
        }), " — benign single-user gaps become requirements once an\nagent is a concurrent writer."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Where it fights today:"
      }), " no inline content-logic until (1); the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "embed"
      }), " iframe-ownership is a\nTCB-model violation to undo, not extend (3); no live fs resync (2); no undo/conflict model (6).\nNone contradicts the model — they are its build order."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "open-questions",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "open-questions"
      }), "Open questions"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Patch vocabulary"
        }), " — the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "fieldOps"
        }), " for objects (geometry, body, connections, tags) and how\nLodestar registers its resolver + schema with the host."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Camera-settled signal"
        }), " — debounce on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "cam"
        }), " stabilizing + interaction-idle; and the\ncoordinate/occlusion contract for the host overlay."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Render snapshot"
        }), " — screenshot vs. per-object render check; size bounds; pull cadence."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Multiplayer convergence"
        }), " — whether the same ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "onFsChange"
        }), " re-read + conflict chain is the\nwhole multiplayer story for light async collaboration, or a single-merge-authority is needed\nfor non-git boards."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["See ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "specs/AGENT_AUTHORING_ARCHITECTURE.md"
      }), " in the docs repo for the platform-level model, the\nself-authoring agent principal, and the consolidated platform deltas."]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/AGENT_AUTHORING.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJibG9ja3F1b3RlIiwiY29kZSIsImRlbCIsImVtIiwiaDEiLCJoMiIsImhyIiwibGkiLCJvbCIsInAiLCJzdHJvbmciLCJ1bCIsIl9wcm92aWRlQ29tcG9uZW50cyIsImNvbXBvbmVudHMiLCJIZWFkaW5nQW5jaG9yIiwiX21pc3NpbmdNZHhSZWZlcmVuY2UiLCJqc3hzIiwiRnJhZ21lbnQiLCJjaGlsZHJlbiIsImlkIiwianN4IiwiTURYQ29udGVudCIsIndyYXBwZXIiLCJNRFhMYXlvdXQiLCJfYyIsImNvbXBvbmVudCIsInBsYWNlIiwiRXJyb3IiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBR0VOVF9BVVRIT1JJTkcubWQiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgYmxvY2txdW90ZTogXCJibG9ja3F1b3RlXCIsXG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgZGVsOiBcImRlbFwiLFxuICAgIGVtOiBcImVtXCIsXG4gICAgaDE6IFwiaDFcIixcbiAgICBoMjogXCJoMlwiLFxuICAgIGhyOiBcImhyXCIsXG4gICAgbGk6IFwibGlcIixcbiAgICBvbDogXCJvbFwiLFxuICAgIHA6IFwicFwiLFxuICAgIHN0cm9uZzogXCJzdHJvbmdcIixcbiAgICB1bDogXCJ1bFwiLFxuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfSwge0hlYWRpbmdBbmNob3J9ID0gX2NvbXBvbmVudHM7XG4gIGlmICghSGVhZGluZ0FuY2hvcikgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJIZWFkaW5nQW5jaG9yXCIsIHRydWUpO1xuICByZXR1cm4gPD48X2NvbXBvbmVudHMuaDEgaWQ9XCJsb2Rlc3Rhci1hZ2VudC1hdXRob3JpbmctcHJvcG9zYWxcIj48SGVhZGluZ0FuY2hvciBpZD1cImxvZGVzdGFyLWFnZW50LWF1dGhvcmluZy1wcm9wb3NhbFwiIC8+e1wiTG9kZXN0YXIg4oCUIGFnZW50IGF1dGhvcmluZyAocHJvcG9zYWwpXCJ9PC9fY29tcG9uZW50cy5oMT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlN0YXR1czpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgZGVzaWduIG5vdGUgKHByb3Bvc2FsKSDCtyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlVwZGF0ZWQ6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIDIwMjYtMDYtMjZcXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlBsYXRmb3JtIHNvdXJjZSBvZiB0cnV0aDpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdGhlIGltbWVkaWF0ZWx5LXJ1biBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImRvY3NcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgcmVwbyxcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJzcGVjcy9BR0VOVF9BVVRIT1JJTkdfQVJDSElURUNUVVJFLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgdGhlIGNyb3NzLWFwcCBhcmNoaXRlY3R1cmUuIFRoaXMgbm90ZSBpcyB0aGVcXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIkxvZGVzdGFyLXNwZWNpZmljXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGFwcGxpY2F0aW9uIG9mIGl0LiAoR3JvdmUgaXMgdGhlIHNpYmxpbmcgYXBwbGljYXRpb247IHNlZVxcblwifTxfY29tcG9uZW50cy5jb2RlPntcImdyb3ZlL2RvY3MvcHJvZHVjdC1kZWZzL2dyb3ZlLWFnZW50LWF1dGhvcmluZy5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuKVwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJGaXJzdC1jbGFzcyBhZ2VudCBhdXRob3JpbmcgaXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJhc3BpcmF0aW9uYWxcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgZm9yIExvZGVzdGFyIHRvZGF5ICh0aGVyZSBpcyBubyBhZ2VudCwgbm9cXG5jaGF0LCBubyBkaWFnbm9zdGljcyB3aXJlZCkuIFRoaXMgbm90ZSByZWNvcmRzIHRoZSB0YXJnZXQgYXJjaGl0ZWN0dXJlIHNvIHRoZSBidWlsZCBvcmRlciBpc1xcbmRlbGliZXJhdGUuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5ociAvPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cIndoeS1sb2Rlc3Rhci1pcy10aGUtY2xlYW4tZXhlbXBsYXJcIj48SGVhZGluZ0FuY2hvciBpZD1cIndoeS1sb2Rlc3Rhci1pcy10aGUtY2xlYW4tZXhlbXBsYXJcIiAvPntcIldoeSBMb2Rlc3RhciBpcyB0aGUgY2xlYW4gZXhlbXBsYXJcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkxvZGVzdGFyJ3Mgc3Vic3RyYXRlIGlzIGFscmVhZHkgdGhlIHNoYXBlIHRoZSBtb2RlbCB3YW50czpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkZpbGVzeXN0ZW0gXCJ9PF9jb21wb25lbnRzLmVtPntcImlzXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgdGhlIGRvY3VtZW50LlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBPbmUgZmlsZSBwZXIgb2JqZWN0IChcIn08X2NvbXBvbmVudHMuY29kZT57XCJvYmplY3RzL3tpZH0ubWR4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgWUFNTCBmcm9udG1hdHRlclwifXtcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiTURYIGJvZHkpLCBhIFwifTxfY29tcG9uZW50cy5jb2RlPntcImJvYXJkLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBtYW5pZmVzdCwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widmlld3MvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiam91cm5leXMvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYXNzZXRzL1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGluIGEgbW91bnRlZCBib2FyZFxcbnNwYWNlIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvbGliL2JvYXJkU3RvcmUudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKS4gQWdlbnQtbGVnaWJsZSBieSBjb25zdHJ1Y3Rpb24gKHRoZSBSRUFETUUncyBcXFwiYW4gYWdlbnQgdGhhdFxcbmhhcyBuZXZlciBoZWFyZCBvZiB0aGlzIGFwcFxcXCIgY2FuIHJlYWQgdGhlIE1EWCkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiTWluaW1hbCBjYXBhYmlsaXRpZXMuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIExvZGVzdGFyIHJlYWRzL3dyaXRlcyBvbmx5IGl0cyBvd24gYm9hcmQgZGF0YTsgaXQgaW52b2tlc1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcInBpY2stZmlsZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgLyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzaGFyZS1zcGFjZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgLyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJlZGl0LWZpbGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFuZCBwcm92aWRlcyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJvcGVuLXByb2plY3RcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLiBJdCBuZXZlciBob2xkc1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcImxsbTpjaGF0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibmV0OmZldGNoXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgc2VjcmV0cywgb3IgZm9yZWlnbi1tb3VudCBhdXRob3JpdHkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJEb2N1bWVudCBhbmQgZW5naW5lIGFscmVhZHkgc2VwYXJhdGUuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImJvYXJkXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGxpdmVzIGluIGEgbW91bnQgKEZTIDIpOyBMb2Rlc3RhcidzXFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJzb3VyY2VcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgaXMgaXRzIHJlcG8gKEZTIDEpLiBUaGUgYWdlbnQgYXV0aG9ycyB0aGUgXCJ9PF9jb21wb25lbnRzLmVtPntcImRvY3VtZW50XCJ9PC9fY29tcG9uZW50cy5lbT57XCI7IHRoZSBlbmdpbmUgaXMgYSBmaXhlZCxcXG5mb3JrYWJsZSBhcHAgaXQgbmV2ZXIgdG91Y2hlcy4gKFRoaXMgaXMgdGhlIGNsZWFuZXIgZm9ybSBvZiB0aGUgXFxcIm5vIGVuZ2luZS9jb250ZW50XFxuY2FwYWJpbGl0eSBib3JkZXJcXFwiOiB0aGVyZSBpcyBubyBjYXBzIGJvcmRlciDigJQgZXZlcnl0aGluZyBpbmxpbmUgcnVucyB3aXRoIExvZGVzdGFyJ3NcXG5taW5pbWFsIGNhcHMg4oCUIG9ubHkgYSBcIn08X2NvbXBvbmVudHMuZW0+e1wic3Vic3RyYXRlXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgdGllciwgZG9jdW1lbnQgdnMgZW5naW5lIHNvdXJjZS4pXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlNvIHRoZXJlIGlzIGxpdHRsZSB0byB1bi1idWlsZC4gVGhlIG1vZGVsIGxhbmRzIGFsbW9zdCB2ZXJiYXRpbTsgd2hhdCdzIG1pc3NpbmcgYXJlIGVuYWJsaW5nXFxucGllY2VzLCBsaXN0ZWQgYXMgZGVsdGFzIGJlbG93LlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaHIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJ0aGUtbW9kZWwtYXBwbGllZC10by1sb2Rlc3RhclwiPjxIZWFkaW5nQW5jaG9yIGlkPVwidGhlLW1vZGVsLWFwcGxpZWQtdG8tbG9kZXN0YXJcIiAvPntcIlRoZSBtb2RlbCwgYXBwbGllZCB0byBMb2Rlc3RhclwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgYWdlbnQgaXMgYW4gZXh0ZXJuYWxpemVkIG1pbmktYXBwLCBub3QgYW1iaWVudCBpbiBMb2Rlc3Rhci5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgQmVjYXVzZSBpdCBuZWVkc1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcImxsbTpjaGF0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgaXQgcnVucyBhcyBhIHNlcGFyYXRlIGhvc3QtYnJva2VyZWQgYXBwIHdpdGggaXRzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wib3duIGFwcEtleVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgdW5kZXIgdGhlIHRpZ2h0XFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJzZWxmLWF1dGhvcmluZyBhZ2VudCBwcmluY2lwYWxcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIGNlaWxpbmcgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wieyBjaGF0KCksIGRpYWdub3N0aWNzOnJlYWQgKHN1YmplY3QpLCByZW5kZXI6cmVhZCAoc3ViamVjdCksIGlwYyDihpIgTG9kZXN0YXIgfVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYW5kIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibm90aGluZyBlbHNlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChubyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJuZXQ6ZmV0Y2hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBubyBzZWNyZXRzLCBub1xcbmZvcmVpZ24gbW91bnRzLCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vIGJvYXJkIHdyaXRlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiKS4gSXRzIFwifTxfY29tcG9uZW50cy5jb2RlPntcInJ3XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiByZWFjaCwgd2hlbiBpdCBoYXMgYW55LCBpcyBzY29wZWQgdG8gdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiYm9hcmRcXG5tb3VudFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgaXQgc3RydWN0dXJhbGx5IGNhbm5vdCB0b3VjaCBMb2Rlc3RhcidzIGVuZ2luZSBzb3VyY2UuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVGhlIGFnZW50IHByb3Bvc2VzOyBMb2Rlc3RhciBhcHBsaWVzLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGUgYWdlbnQgZW1pdHMgc2VtYW50aWMgcGF0Y2hlcyBvdmVyIHRoZSBJUEMgZWRnZTtcXG5Mb2Rlc3RhciDigJQgd2hpY2ggb3ducyB0aGUgb2JqZWN0IG1vZGVsIOKAlCB2YWxpZGF0ZXMgYW5kIHdyaXRlczpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuY29kZT57XCJwYXRjaChvYmplY3RJZCwgZmllbGRPcHMpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgXCJ9PF9jb21wb25lbnRzLmVtPntcInNldCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJib2R5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBvZiBvYmplY3QgT1wifTwvX2NvbXBvbmVudHMuZW0+e1wiOyBcIn08X2NvbXBvbmVudHMuZW0+e1wibW92ZS9yZXNpemVcIn08L19jb21wb25lbnRzLmVtPntcIiAoZ2VvbWV0cnkpOyBcIn08X2NvbXBvbmVudHMuZW0+e1wiYWRkIGFcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJjb25uZWN0aW9uXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuZW0+e1wiOyBcIn08X2NvbXBvbmVudHMuZW0+e1wicmV0YWdcIn08L19jb21wb25lbnRzLmVtPntcIjsgXCJ9PF9jb21wb25lbnRzLmVtPntcImNyZWF0ZSBvYmplY3QgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wieyBraW5kLCB4LCB5LCB3LCBoLCBib2R5LCDigKYgfVwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLmVtPntcIi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuY29kZT57XCJwdXRBc3NldChwYXRoLCBieXRlcylcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCBhbiBpbWFnZSAod2hvbGUtZmlsZTsgbm8gbWVyZ2UpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgYWdlbnQgbmV2ZXIgaG9sZHMgYSBib2FyZC13cml0ZSBjYXBhYmlsaXR5OyBMb2Rlc3RhciBpcyB0aGUgZ2F0ZWtlZXBlciB0aGF0IHZhbGlkYXRlc1xcbmFnYWluc3QgdGhlIG9iamVjdCBzY2hlbWEgYW5kIGFwcGxpZXMgdGhyb3VnaCB0aGUgY29uZmxpY3QgY2hhaW4uIExvZGVzdGFyIHdyaXRlcyB0aGUgYm9hcmRcXG52aWEgaXRzIG9yZGluYXJ5IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicncgbW91bnQgZ3JhbnRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHRoZSBib2FyZCBtb3VudCB0b2RheSkg4oCUIGNvbGxhYm9yYXRvci1nYXRlZCwgcmV2b2NhYmxlLFxcbm5vdCBhIHN0YW5kaW5nIGFwcCBjYXBhYmlsaXR5LlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIk9ic2VydmUgKyBjb250ZXh0LlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBDb250ZXh0IGlzIHJlLWRlcml2ZWQgZnJvbSBmaWxlcyAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYm9hcmQubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wib2JqZWN0cy8qLm1keFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpIHBsdXNcXG5saXZlIElQQyBkZWx0YXMgKFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wic2VsZWN0ZWQgb2JqZWN0cywgdmlld3BvcnQgcmVjdCwgem9vbVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIikuIE9ic2VydmF0aW9uIGlzIHN1YmplY3Qtc2NvcGVkOlxcblwifTxfY29tcG9uZW50cy5jb2RlPntcImRpYWdub3N0aWNzOnJlYWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGZvciBvYmplY3QtYm9keSBNRFggY29tcGlsZS90cmFuc3BpbGUgZXJyb3JzIChvbmNlIE1EWC1mcm9tLW1vdW50IGxhbmRzKSwgYW5kXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicmVuZGVyOnJlYWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInNjcmVlbnNob3QtbGVhbmluZywgYmVjYXVzZSBhIGNhbnZhcyBpcyB2aXN1YWxcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIGZvciB0aGUgXFxcImRvZXMgaXQgbG9va1xcbnJpZ2h0XFxcIiBjaGVjay4gVGhlIGxvb3A6IHJlYWQgY29udGV4dCDihpIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2hhdCgpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDihpIgZW1pdCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJwYXRjaFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oaSIExvZGVzdGFyIHZhbGlkYXRlcyArIG1lcmdlc1wifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIndyaXRlcyDihpIgaG9zdCByZS1yZWFkcyDihpIgZGlhZ25vc3RpY3MgKMKxIHNuYXBzaG90KSDihpIgcmVwZWF0OyBsYW5kaW5nIGlzIGEgc2VwYXJhdGUgZ2F0ZWRcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJjb250cmlidXRlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9zYXZlIHN0ZXAuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5ociAvPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cImNhcGFiaWxpdHktdXNpbmctb2JqZWN0cy1ob3N0LWJyb2tlcmVkLW1pbmktYXBwcy1jb21wb3NpdGVkLWF0LXJlc3RcIj48SGVhZGluZ0FuY2hvciBpZD1cImNhcGFiaWxpdHktdXNpbmctb2JqZWN0cy1ob3N0LWJyb2tlcmVkLW1pbmktYXBwcy1jb21wb3NpdGVkLWF0LXJlc3RcIiAvPntcIkNhcGFiaWxpdHktdXNpbmcgb2JqZWN0czogaG9zdC1icm9rZXJlZCBtaW5pLWFwcHMsIGNvbXBvc2l0ZWQgYXQgcmVzdFwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiQW4gb2JqZWN0IHRoYXQgbmVlZHMgYW4gZWxldmF0ZWQgY2FwYWJpbGl0eSAoYW4gQUkgd2lkZ2V0LCBhIG5ldHdvcmstZmV0Y2hpbmcgcmVwb3J0LCBhXFxud3JpdGFibGUgZm9yZWlnbiBtb3VudCkgZG9lcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBydW4gaW5saW5lLiBJdCBydW5zIGFzIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJob3N0LW93bmVkIG1pbmktYXBwIHNpYmxpbmdcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIsXFxuY29tcG9zaXRlZCBvdmVyIHRoZSBvYmplY3QncyByZWN0YW5nbGUg4oCUIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibmV2ZXJcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYSBMb2Rlc3Rhci1vd25lZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCI8aWZyYW1lPlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKHdoaWNoIHdvdWxkXFxucHV0IExvZGVzdGFyIGluIHRoZSBtaW5pLWFwcCdzIFRDQjsgdG9kYXkncyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJlbWJlZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgb2JqZWN0IGRvZXMgZXhhY3RseSB0aGlzIGFuZCBtdXN0IGJlXFxucmUtYXJjaGl0ZWN0ZWQpLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkNvbXBvc2l0aW9uIGlzIG9uZS1zaG90LCBhdCBhIHNldHRsZWQgdHJhbnNmb3JtLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBSYXRoZXIgdGhhbiB0cmFjayBhbiBhZmZpbmUgcGVyIGZyYW1lIGFzXFxudGhlIGNhbnZhcyBwYW5zL3pvb21zL3JvdGF0ZXMsIHNob3cgdGhlIGV4aXN0aW5nIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicGxhY2Vob2xkZXJcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHRoZSBjbGljay10by1sb2FkIHByZXZpZXdcXG5jYXJkKSBkdXJpbmcgbW90aW9uLCBhbmQgb3ZlcmxheSB0aGUgbGl2ZSBpZnJhbWUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJvbmx5IHdoZW4gdGhlIGNhbWVyYSByZXN0c1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgY29tcHV0aW5nIHRoZVxcbnNjcmVlbiByZWN0IGZyb20gdGhlIGV4aXN0aW5nIFwifTxfY29tcG9uZW50cy5jb2RlPntcInByb2plY3QoY2FtLCB2cCwg4oCmKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuIFRoaXMgc2lkZXN0ZXBzIHRoZSBoYXJkZXN0IHBhcnQgb2YgY2FudmFzXFxuY29tcG9zaXRpb24gKHBlci1mcmFtZSBhZmZpbmUgdHJhY2tpbmcpIGFuZCBjb21wb3NlcyB3aXRoIFxcXCJwcmV2aWV3LXVudGlsLXJ1blxcXCI6IHRoZSBwbGFjZWhvbGRlclxcblwifTxfY29tcG9uZW50cy5lbT57XCJpc1wifTwvX2NvbXBvbmVudHMuZW0+e1wiIHRoZSBwcmV2aWV3LiBJdCByZXF1aXJlcyBhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiY2FtZXJhLXNldHRsZWQgZXZlbnRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIsIHdoaWNoIGRvZXMgbm90IGV4aXN0IHRvZGF5XFxuKFwifTxfY29tcG9uZW50cy5jb2RlPntcImZseVRvKClcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNvbXBsZXRlcyBidXQgZmlyZXMgbm8gY2FsbGJhY2spLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaHIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJjb25mbGljdHMtdGhlLWFnZW50LWlzLWp1c3QtYW5vdGhlci13cml0ZXJcIj48SGVhZGluZ0FuY2hvciBpZD1cImNvbmZsaWN0cy10aGUtYWdlbnQtaXMtanVzdC1hbm90aGVyLXdyaXRlclwiIC8+e1wiQ29uZmxpY3RzOiB0aGUgYWdlbnQgaXMganVzdCBhbm90aGVyIHdyaXRlclwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiU2NvcGUgaXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJsaWdodCBhc3luYyBjb2xsYWJvcmF0aW9uXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBub3QgcmVhbC10aW1lIG11bHRpLWN1cnNvciAodGhhdCB3b3VsZCBuZWVkIGEgQ1JEVC9PVFxcbnN1YnN0cmF0ZSBhbmQgYnJlYWsgdGhlIGZpbGUtd3JpdGVyIG1vZGVsKS4gQWdlbnQgcGF0Y2hlcywgbG9jYWwgZGlyZWN0IG1hbmlwdWxhdGlvbiwgYW5kIGFcXG5yZW1vdGUgY29sbGFib3JhdG9yIGFsbCBiZWNvbWUgd3JpdGVzIHRvIHRoZSBib2FyZCBtb3VudCwgc3VyZmFjZWQgYnkgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wib25Gc0NoYW5nZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5lbT57XCIoU3VwZXJzZWRlZCAyMDI2LTA2LTI3IGJ5IFwifTxfY29tcG9uZW50cy5jb2RlPntcIkFHRU5UX0FVVEhPUklOR19BUkNISVRFQ1RVUkUubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIMKnNy4yIOKAlCB0aGUgZmllbGQtbWVyZ2UsIGNoYWluZWRcXG5yZXNvbHZlcnMsIGFuZCBwZXItYXV0aG9yIHVuZG8gYmVsb3cgYXJlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicmV0aXJlZCBmb3IgVjFcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIuIFYxIGNvbmZsaWN0IGlzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZmlsZS1sZXZlbFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgdHdvXFxuZXhpc3RpbmcgbWVjaGFuaXNtczogXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYnVmZmVyLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBibG9jay1vbi1kaXJ0eSAob3BlbiB0ZXh0KSArIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlJlbW90ZU92ZXJ3cml0ZUVtaXR0ZXJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxuKGNsb3NlZC1maWxlL2RlbGV0ZS9iaW5hcnkpLiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIkZpZWxkLWF3YXJlIG1lcmdlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChnZW9tZXRyeSBsYXN0LXdyaXRlLXBlci1maWVsZCwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY29ubmVjdGlvbnNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxuc2V0LXVuaW9uLCBib2R5IDMtd2F5LCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ0YWdzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBzZXQpIGlzIHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImRlZmVycmVkIFYyIENSRFQgdHJhY2tcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHNvIHRoZSBcXFwiZmllbGQgaXMgdGhlIHVuaXRcXG5vZiBjb25mbGljdFxcXCIgZnJhbWluZyBpcyBhIFYyIHByb3BlcnR5OyBpbiBWMSBhIHNhbWUtXCJ9PF9jb21wb25lbnRzLmVtPntcIm9iamVjdFwifTwvX2NvbXBvbmVudHMuZW0+e1wiLWZpbGUgb3ZlcmxhcCAoZS5nLiBhIGRyYWcncyBnZW9tZXRyeVxcbnZzLiBhbiBhZ2VudCdzIGJvZHkgcmV3cml0ZSkgaXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ3aG9sZS1maWxlIExXV1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgcmVjb3ZlcmFibGUtcG9zdC1ob2MsIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibm90XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGZpZWxkLW1lcmdlZC5cXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlVuZG8gaXMgcGVyLXdvcmtpbmctdHJlZS10aW1lbGluZSwgbm90IHBlci1hdXRob3JcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIkZJTEVTWVNURU1fU1BFQyDCpzVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHRyYWNrcyBubyBwcm92ZW5hbmNlKS5cXG5UaGUgZGlyZWN0LW1hbmlwdWxhdGlvbiBydyBib2FyZCB3cml0ZXIgaXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJub3RcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgc2VyaWFsaXplZCBieSB0aGUgc2luZ2xlLWF1dGhvciBsZWFzZSDigJQgdGhhdFxcbmxlYXNlIGJvdW5kcyBcIn08X2NvbXBvbmVudHMuZW0+e1wiYWdlbnRzXCJ9PC9fY29tcG9uZW50cy5lbT57XCIsIG5vdCBGUyAyLilcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08L19jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkZpbGUtcGVyLW9iamVjdCBwYXJ0aXRpb25zIG1vc3QgY29uZmxpY3QgYXdheVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgdHdvIHdyaXRlcnMgb24gZGlmZmVyZW50IG9iamVjdHMgbmV2ZXJcXG5jb25mbGljdC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuZGVsPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiV2l0aGluIGFuIG9iamVjdCwgbWVyZ2UgYnkgZmllbGRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCmIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiQ2hhaW5lZCByZXNvbHZlcnNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCmIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicGVyLWF1dGhvci1zY29wZWQgdW5kb1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMuZGVsPntcIiDihpJcXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlYxIGlzIGZpbGUtbGV2ZWxcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcImJ1ZmZlci50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgb3Blbi10ZXh0ICsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiUmVtb3RlT3ZlcndyaXRlRW1pdHRlclwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpOyBmaWVsZC1tZXJnZS9yZXNvbHZlcnNcXG5kZWZlcnJlZCBWMjsgdW5kbyBpcyBwZXItd29ya2luZy10cmVlLXRpbWVsaW5lIChzZWUgdGhlIHN1cGVyc2VkaW5nIG5vdGUgYWJvdmUpLiBUaGUgZHVyYWJsZVxcbnRlcm1pbmFsIGlzIGdpdCBQUiAoZ2l0IGJvYXJkKSBvciBkZXRlY3QtYWZ0ZXItY2xvYmJlciAobm9uLWdpdCk7IHNlbWFudGljIHN0YWxlbmVzcyBpcyBjYXVnaHQgYXRcXG5odW1hbiByZXZpZXcgb2YgdGhlIHNhdmUvcHVibGlzaCBkaWZmLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJDcnVjaWFsbHksIG1ha2luZyB0aGUgYWdlbnQncyB3cml0ZXMgYXBwZWFyIGxpdmUgbmVlZHMgdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wic2FtZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJvbkZzQ2hhbmdlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi1kcml2ZW4gcGVyLW9iamVjdFxcbnJlLXJlYWRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdGhhdCBtdWx0aXBsYXllciBuZWVkcyDigJQgYnVpbGQgaXQgb25jZSwgaXQgc2VydmVzIGJvdGguXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5ociAvPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cImRlbHRhcy1pbi1kZXBlbmRlbmN5LW9yZGVyXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJkZWx0YXMtaW4tZGVwZW5kZW5jeS1vcmRlclwiIC8+e1wiRGVsdGFzLCBpbiBkZXBlbmRlbmN5IG9yZGVyXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMub2w+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiTURYLWZyb20tbW91bnQgZ2F0ZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgY29tcGlsZSArIHJlbmRlciBvYmplY3QgYm9kaWVzIGlubGluZSAodG9kYXkgYm9kaWVzIGFyZSBzdGF0aWNcXG50ZXh0OyB0aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY29tcG9uZW50XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBraW5kIGlzIGEgc3R1YikuIFRoZSBlbmFibGluZyBzdGVwIGZvciBpbmxpbmUgY29udGVudC1sb2dpYzsgc2FmZSBieVxcbnRoZSBuby1zdGFuZGluZy1oaWdoLXN0YWtlcy1hdXRob3JpdHkgaW52YXJpYW50LiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlRoaXMgZGVsdGEgaXMgbm90IExvZGVzdGFyLXByaXZhdGU6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiXFxuaXQgaXMgdGhlIHBsYXRmb3JtLWdlbmVyYWwgY2FwYWJpbGl0eSBzcGVjY2VkIG9uY2UgaW4gdGhlIGRvY3MgcmVwbydzXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3BlY3MvTURYX0ZST01fTU9VTlRfU1BFQy5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIHNoYXJlZCB3aXRoIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiR3JvdmVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIncyBkaXNwYXRjaGVkLXdpa2kgY29uc3VtZXIuIFRoZVxcblBoYXNlLTAgcGlwZWxpbmUgc3Bpa2UgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIldISVRFQk9BUkRfU1BFQyDCpzExXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiTURYX0ZST01fTU9VTlRfU1BFQyDCpzNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSBzZXR0bGVzIHRoZVxcblwifTxfY29tcG9uZW50cy5jb2RlPntcIkluY2x1ZGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcImR5bmFtaWNJbXBvcnRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLXZzLXJ1bnRpbWUtXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZXZhbHVhdGUoKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgY2hvaWNlIGZvciBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImJvdGhcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgY29uc3VtZXJzIGF0IG9uY2Ug4oCUXFxucnVuIGl0IG9uY2UsIGJvdGggcmlkZSBpdC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPjxfY29tcG9uZW50cy5jb2RlPntcIm9uRnNDaGFuZ2VcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLWRyaXZlbiBwZXItb2JqZWN0IHJlLXJlYWRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIGxpdmUgZXh0ZXJuYWwgd3JpdGVzIChhYnNlbnQgdG9kYXkpLiBTZXJ2ZXMgYm90aFxcbmFnZW50IGF1dGhvcmluZyBhbmQgbXVsdGlwbGF5ZXI7IHJlcXVpcmVkIGZvciB0aGUgbG9vcCB0byBjbG9zZS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlJlLWFyY2hpdGVjdCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJlbWJlZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY29tcG9uZW50XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDihpIgaG9zdC1icm9rZXJlZCBtaW5pLWFwcFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgbW92ZSBpZnJhbWUgb3duZXJzaGlwIHRvIHRoZVxcbmhvc3Q7IHJldXNlIHRoZSBjbGljay10by1sb2FkIHBsYWNlaG9sZGVyIGFzIHRoZSBwcmV2aWV3LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQ2FtZXJhLXNldHRsZWQgZXZlbnQgKyBzdGF0aWMtYWZmaW5lIHJlZ2lvbiBjb21wb3NpdGlvblwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgb3ZlcmxheSB0aGUgbGl2ZSBtaW5pLWFwcCBvbmx5XFxuYXQgcmVzdCwgdmlhIFwifTxfY29tcG9uZW50cy5jb2RlPntcInByb2plY3QoY2FtLCB2cCwg4oCmKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgc2VsZi1hdXRob3JpbmcgYWdlbnQgbWluaS1hcHBcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKyBvYnNlcnZlL2NvbnRleHQgY29udHJhY3QsIHNjb3BlZCB0byB0aGUgYm9hcmQgbW91bnQ7XFxudGhlIHBhdGNoIGludGVyZmFjZSBhcyB0aGUgYWdlbnTihpRMb2Rlc3RhciBwcm90b2NvbC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlVuZG8gKyBwZXItb2JqZWN0IGNvbmZsaWN0IGhhbmRsaW5nXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBiZW5pZ24gc2luZ2xlLXVzZXIgZ2FwcyBiZWNvbWUgcmVxdWlyZW1lbnRzIG9uY2UgYW5cXG5hZ2VudCBpcyBhIGNvbmN1cnJlbnQgd3JpdGVyLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIldoZXJlIGl0IGZpZ2h0cyB0b2RheTpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgbm8gaW5saW5lIGNvbnRlbnQtbG9naWMgdW50aWwgKDEpOyB0aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZW1iZWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGlmcmFtZS1vd25lcnNoaXAgaXMgYVxcblRDQi1tb2RlbCB2aW9sYXRpb24gdG8gdW5kbywgbm90IGV4dGVuZCAoMyk7IG5vIGxpdmUgZnMgcmVzeW5jICgyKTsgbm8gdW5kby9jb25mbGljdCBtb2RlbCAoNikuXFxuTm9uZSBjb250cmFkaWN0cyB0aGUgbW9kZWwg4oCUIHRoZXkgYXJlIGl0cyBidWlsZCBvcmRlci5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmhyIC8+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwib3Blbi1xdWVzdGlvbnNcIj48SGVhZGluZ0FuY2hvciBpZD1cIm9wZW4tcXVlc3Rpb25zXCIgLz57XCJPcGVuIHF1ZXN0aW9uc1wifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlBhdGNoIHZvY2FidWxhcnlcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmaWVsZE9wc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZm9yIG9iamVjdHMgKGdlb21ldHJ5LCBib2R5LCBjb25uZWN0aW9ucywgdGFncykgYW5kIGhvd1xcbkxvZGVzdGFyIHJlZ2lzdGVycyBpdHMgcmVzb2x2ZXIgKyBzY2hlbWEgd2l0aCB0aGUgaG9zdC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkNhbWVyYS1zZXR0bGVkIHNpZ25hbFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgZGVib3VuY2Ugb24gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2FtXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBzdGFiaWxpemluZyArIGludGVyYWN0aW9uLWlkbGU7IGFuZCB0aGVcXG5jb29yZGluYXRlL29jY2x1c2lvbiBjb250cmFjdCBmb3IgdGhlIGhvc3Qgb3ZlcmxheS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlJlbmRlciBzbmFwc2hvdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgc2NyZWVuc2hvdCB2cy4gcGVyLW9iamVjdCByZW5kZXIgY2hlY2s7IHNpemUgYm91bmRzOyBwdWxsIGNhZGVuY2UuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJNdWx0aXBsYXllciBjb252ZXJnZW5jZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgd2hldGhlciB0aGUgc2FtZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJvbkZzQ2hhbmdlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiByZS1yZWFkICsgY29uZmxpY3QgY2hhaW4gaXMgdGhlXFxud2hvbGUgbXVsdGlwbGF5ZXIgc3RvcnkgZm9yIGxpZ2h0IGFzeW5jIGNvbGxhYm9yYXRpb24sIG9yIGEgc2luZ2xlLW1lcmdlLWF1dGhvcml0eSBpcyBuZWVkZWRcXG5mb3Igbm9uLWdpdCBib2FyZHMuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlNlZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcGVjcy9BR0VOVF9BVVRIT1JJTkdfQVJDSElURUNUVVJFLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpbiB0aGUgZG9jcyByZXBvIGZvciB0aGUgcGxhdGZvcm0tbGV2ZWwgbW9kZWwsIHRoZVxcbnNlbGYtYXV0aG9yaW5nIGFnZW50IHByaW5jaXBhbCwgYW5kIHRoZSBjb25zb2xpZGF0ZWQgcGxhdGZvcm0gZGVsdGFzLlwifTwvX2NvbXBvbmVudHMucD48Lz47XG59XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNRFhDb250ZW50KHByb3BzID0ge30pIHtcbiAgY29uc3Qge3dyYXBwZXI6IE1EWExheW91dH0gPSB7XG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9O1xuICByZXR1cm4gTURYTGF5b3V0ID8gPE1EWExheW91dCB7Li4ucHJvcHN9PjxfY3JlYXRlTWR4Q29udGVudCB7Li4ucHJvcHN9IC8+PC9NRFhMYXlvdXQ+IDogX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpO1xufVxuZnVuY3Rpb24gX21pc3NpbmdNZHhSZWZlcmVuY2UoaWQsIGNvbXBvbmVudCwgcGxhY2UpIHtcbiAgdGhyb3cgbmV3IEVycm9yKFwiRXhwZWN0ZWQgXCIgKyAoY29tcG9uZW50ID8gXCJjb21wb25lbnRcIiA6IFwib2JqZWN0XCIpICsgXCIgYFwiICsgaWQgKyBcImAgdG8gYmUgZGVmaW5lZDogeW91IGxpa2VseSBmb3Jnb3QgdG8gaW1wb3J0LCBwYXNzLCBvciBwcm92aWRlIGl0LlwiICsgKHBsYWNlID8gXCJcXG5JdOKAmXMgcmVmZXJlbmNlZCBpbiB5b3VyIGNvZGUgYXQgYFwiICsgcGxhY2UgKyBcImAgaW4gYC9hcHAvQUdFTlRfQVVUSE9SSU5HLm1kYFwiIDogXCJcIikpO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFFQSxJQUFBQSxZQUFBLEdBQUFDLE9BQUE7QUFBd0YsSUFBQUMsV0FBQSxHQUFBRCxPQUFBO0FBRnhGO0FBQ0E7O0FBRUEsU0FBU0UsaUJBQWlCQSxDQUFDQyxLQUFLLEVBQUU7RUFDaEMsTUFBTUMsV0FBVyxHQUFHO01BQ2xCQyxVQUFVLEVBQUUsWUFBWTtNQUN4QkMsSUFBSSxFQUFFLE1BQU07TUFDWkMsR0FBRyxFQUFFLEtBQUs7TUFDVkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsTUFBTSxFQUFFLFFBQVE7TUFDaEJDLEVBQUUsRUFBRSxJQUFJO01BQ1IsR0FBRyxJQUFBQyw2QkFBa0IsRUFBQyxDQUFDO01BQ3ZCLEdBQUdkLEtBQUssQ0FBQ2U7SUFDWCxDQUFDO0lBQUU7TUFBQ0M7SUFBYSxDQUFDLEdBQUdmLFdBQVc7RUFDaEMsSUFBSSxDQUFDZSxhQUFhLEVBQUVDLG9CQUFvQixDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUM7RUFDL0Qsb0JBQU8sSUFBQW5CLFdBQUEsQ0FBQW9CLElBQUEsRUFBQXBCLFdBQUEsQ0FBQXFCLFFBQUE7SUFBQUMsUUFBQSxnQkFBRSxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDSyxFQUFFO01BQUNlLEVBQUUsRUFBQyxtQ0FBbUM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFtQyxDQUFFLENBQUMsRUFBQyx1Q0FBdUM7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNVLENBQUM7TUFBQVMsUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFTLENBQXFCLENBQUMsRUFBQyw0QkFBNEIsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFVLENBQXFCLENBQUMsRUFBQyxlQUFlLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBMkIsQ0FBcUIsQ0FBQyxFQUFDLHVCQUF1QixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQU0sQ0FBcUIsQ0FBQyxFQUFDLFVBQVUsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1FBQUFpQixRQUFBLEVBQUU7TUFBdUMsQ0FBbUIsQ0FBQyxFQUFDLG1EQUFtRCxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQW1CLENBQXFCLENBQUMsRUFBQyw4REFBOEQsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1FBQUFpQixRQUFBLEVBQUU7TUFBa0QsQ0FBbUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNVLENBQUM7TUFBQVMsUUFBQSxHQUFFLGlDQUFpQyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQWMsQ0FBcUIsQ0FBQyxFQUFDLHVKQUF1SjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ08sRUFBRSxJQUFFLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQVYsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTSxFQUFFO01BQUNjLEVBQUUsRUFBQyxvQ0FBb0M7TUFBQUQsUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFvQyxDQUFFLENBQUMsRUFBQyxvQ0FBb0M7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNVLENBQUM7TUFBQVMsUUFBQSxFQUFFO0lBQTRELENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1ksRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNRLEVBQUU7UUFBQVcsUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsR0FBRSxhQUFhLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0ksRUFBRTtZQUFBZSxRQUFBLEVBQUU7VUFBSSxDQUFpQixDQUFDLEVBQUMsZ0JBQWdCO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLHdCQUF3QixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFrQixDQUFtQixDQUFDLEVBQUMscUJBQXFCLEVBQUUsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNZLEVBQUU7VUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDUSxFQUFFO1lBQUFXLFFBQUEsR0FBRSxlQUFlLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBaUIsUUFBQSxFQUFFO1lBQVUsQ0FBbUIsQ0FBQyxFQUFDLGFBQWEsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO2NBQUFpQixRQUFBLEVBQUU7WUFBUSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7Y0FBQWlCLFFBQUEsRUFBRTtZQUFXLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBaUIsUUFBQSxFQUFFO1lBQVMsQ0FBbUIsQ0FBQyxFQUFDLCtCQUErQixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7Y0FBQWlCLFFBQUEsRUFBRTtZQUF1QixDQUFtQixDQUFDLEVBQUMsa0hBQWtIO1VBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7UUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBVyxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQXVCLENBQXFCLENBQUMsRUFBQyw4REFBOEQsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLGdCQUFnQixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUMsRUFBQyxvQkFBb0IsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBVSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyx3Q0FBd0M7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNRLEVBQUU7UUFBQVcsUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUF1QyxDQUFxQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQU8sQ0FBcUIsQ0FBQyxFQUFDLHdDQUF3QyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQVEsQ0FBcUIsQ0FBQyxFQUFDLDZDQUE2QyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNJLEVBQUU7VUFBQWUsUUFBQSxFQUFFO1FBQVUsQ0FBaUIsQ0FBQyxFQUFDLDhOQUE4TixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNJLEVBQUU7VUFBQWUsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLG9DQUFvQztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVSxDQUFDO01BQUFTLFFBQUEsRUFBRTtJQUErSCxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNPLEVBQUUsSUFBRSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFWLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDYyxFQUFFLEVBQUMsK0JBQStCO01BQUFELFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBK0IsQ0FBRSxDQUFDLEVBQUMsZ0NBQWdDO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDVSxDQUFDO01BQUFTLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBaUUsQ0FBcUIsQ0FBQyxFQUFDLHFCQUFxQixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUFVLENBQW1CLENBQUMsRUFBQyxxREFBcUQsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFZLENBQXFCLENBQUMsRUFBQyxxQkFBcUIsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFnQyxDQUFxQixDQUFDLEVBQUMsYUFBYSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUErRSxDQUFtQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQWMsQ0FBcUIsQ0FBQyxFQUFDLE9BQU8sZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1FBQUFpQixRQUFBLEVBQUU7TUFBVyxDQUFtQixDQUFDLEVBQUMsb0NBQW9DLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBZ0IsQ0FBcUIsQ0FBQyxFQUFDLFNBQVMsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1FBQUFpQixRQUFBLEVBQUU7TUFBSSxDQUFtQixDQUFDLEVBQUMsNENBQTRDLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBYyxDQUFxQixDQUFDLEVBQUMsMkRBQTJEO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDVSxDQUFDO01BQUFTLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBdUMsQ0FBcUIsQ0FBQyxFQUFDLHNIQUFzSDtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1ksRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNRLEVBQUU7UUFBQVcsUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBMkIsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDSSxFQUFFO1VBQUFlLFFBQUEsR0FBRSxNQUFNLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBaUIsUUFBQSxFQUFFO1VBQU0sQ0FBbUIsQ0FBQyxFQUFDLGNBQWM7UUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNJLEVBQUU7VUFBQWUsUUFBQSxFQUFFO1FBQWEsQ0FBaUIsQ0FBQyxFQUFDLGVBQWUsZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDSSxFQUFFO1VBQUFlLFFBQUEsR0FBRSxTQUFTLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBaUIsUUFBQSxFQUFFO1VBQVksQ0FBbUIsQ0FBQztRQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0ksRUFBRTtVQUFBZSxRQUFBLEVBQUU7UUFBTyxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNJLEVBQUU7VUFBQWUsUUFBQSxHQUFFLGdCQUFnQixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7WUFBQWlCLFFBQUEsRUFBRTtVQUErQixDQUFtQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxFQUFDLEdBQUc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNRLEVBQUU7UUFBQVcsUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBdUIsQ0FBbUIsQ0FBQyxFQUFDLHFDQUFxQztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDVSxDQUFDO01BQUFTLFFBQUEsR0FBRSwyTUFBMk0sZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFnQixDQUFxQixDQUFDLEVBQUMsMkZBQTJGO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDVSxDQUFDO01BQUFTLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBb0IsQ0FBcUIsQ0FBQyxFQUFDLHFDQUFxQyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUFVLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBaUIsUUFBQSxFQUFFO01BQWUsQ0FBbUIsQ0FBQyxFQUFDLDJCQUEyQixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQXVDLENBQXFCLENBQUMsRUFBQyxxQ0FBcUMsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1FBQUFpQixRQUFBLEVBQUU7TUFBa0IsQ0FBbUIsQ0FBQyxFQUFDLGtGQUFrRixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUFhLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBZ0QsQ0FBcUIsQ0FBQyxFQUFDLHFFQUFxRSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUFRLENBQW1CLENBQUMsRUFBQyxVQUFVLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBaUIsUUFBQSxFQUFFO01BQU8sQ0FBbUIsQ0FBQyxFQUFDLGdDQUFnQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1ksRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNRLEVBQUU7UUFBQVcsUUFBQSxHQUFFLDJGQUEyRixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFZLENBQW1CLENBQUMsRUFBQyxhQUFhO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNPLEVBQUUsSUFBRSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFWLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDYyxFQUFFLEVBQUMscUVBQXFFO01BQUFELFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBcUUsQ0FBRSxDQUFDLEVBQUMsdUVBQXVFO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDVSxDQUFDO01BQUFTLFFBQUEsR0FBRSx3SEFBd0gsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFLLENBQXFCLENBQUMsRUFBQyw0QkFBNEIsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUE2QixDQUFxQixDQUFDLEVBQUMsOENBQThDLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBTyxDQUFxQixDQUFDLEVBQUMsb0JBQW9CLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBaUIsUUFBQSxFQUFFO01BQVUsQ0FBbUIsQ0FBQyxFQUFDLDZEQUE2RCxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUFPLENBQW1CLENBQUMsRUFBQyx5REFBeUQ7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNVLENBQUM7TUFBQVMsUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFrRCxDQUFxQixDQUFDLEVBQUMsOEZBQThGLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBYSxDQUFxQixDQUFDLEVBQUMsZ0ZBQWdGLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBNEIsQ0FBcUIsQ0FBQyxFQUFDLGtEQUFrRCxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUFxQixDQUFtQixDQUFDLEVBQUMsaUpBQWlKLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0ksRUFBRTtRQUFBZSxRQUFBLEVBQUU7TUFBSSxDQUFpQixDQUFDLEVBQUMsOEJBQThCLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBc0IsQ0FBcUIsQ0FBQyxFQUFDLGlDQUFpQyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUFTLENBQW1CLENBQUMsRUFBQyxvQ0FBb0M7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNPLEVBQUUsSUFBRSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFWLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDYyxFQUFFLEVBQUMsNENBQTRDO01BQUFELFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBNEMsQ0FBRSxDQUFDLEVBQUMsNkNBQTZDO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDVSxDQUFDO01BQUFTLFFBQUEsR0FBRSxXQUFXLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBMkIsQ0FBcUIsQ0FBQyxFQUFDLDhOQUE4TixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUFZLENBQW1CLENBQUMsRUFBQyxHQUFHO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDQyxVQUFVO01BQUFrQixRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNVLENBQUM7UUFBQVMsUUFBQSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNJLEVBQUU7VUFBQWUsUUFBQSxHQUFFLDRCQUE0QixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7WUFBQWlCLFFBQUEsRUFBRTtVQUFpQyxDQUFtQixDQUFDLEVBQUMsNkVBQTZFLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtZQUFBUSxRQUFBLEVBQUU7VUFBZ0IsQ0FBcUIsQ0FBQyxFQUFDLG1CQUFtQixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07WUFBQVEsUUFBQSxFQUFFO1VBQVksQ0FBcUIsQ0FBQyxFQUFDLDhCQUE4QixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7WUFBQWlCLFFBQUEsRUFBRTtVQUFXLENBQW1CLENBQUMsRUFBQyxnQ0FBZ0MsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1lBQUFpQixRQUFBLEVBQUU7VUFBd0IsQ0FBbUIsQ0FBQyxFQUFDLGlDQUFpQyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07WUFBQVEsUUFBQSxFQUFFO1VBQW1CLENBQXFCLENBQUMsRUFBQyxtQ0FBbUMsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1lBQUFpQixRQUFBLEVBQUU7VUFBYSxDQUFtQixDQUFDLEVBQUMsMkJBQTJCLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBaUIsUUFBQSxFQUFFO1VBQU0sQ0FBbUIsQ0FBQyxFQUFDLGVBQWUsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1lBQUFRLFFBQUEsRUFBRTtVQUF3QixDQUFxQixDQUFDLEVBQUMsc0ZBQXNGLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0ksRUFBRTtZQUFBZSxRQUFBLEVBQUU7VUFBUSxDQUFpQixDQUFDLEVBQUMseUVBQXlFLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtZQUFBUSxRQUFBLEVBQUU7VUFBZ0IsQ0FBcUIsQ0FBQyxFQUFDLDBCQUEwQixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07WUFBQVEsUUFBQSxFQUFFO1VBQUssQ0FBcUIsQ0FBQyxFQUFDLGtCQUFrQixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07WUFBQVEsUUFBQSxFQUFFO1VBQW1ELENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBaUIsUUFBQSxFQUFFO1VBQW9CLENBQW1CLENBQUMsRUFBQyxzRUFBc0UsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1lBQUFRLFFBQUEsRUFBRTtVQUFLLENBQXFCLENBQUMsRUFBQyw4REFBOEQsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDSSxFQUFFO1lBQUFlLFFBQUEsRUFBRTtVQUFRLENBQWlCLENBQUMsRUFBQyxjQUFjO1FBQUEsQ0FBaUI7TUFBQyxDQUFlLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBeUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDWSxFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBVyxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQStDLENBQXFCLENBQUMsRUFBQyxzREFBc0Q7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNRLEVBQUU7UUFBQVcsUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDRyxHQUFHO1VBQUFnQixRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07WUFBQVEsUUFBQSxFQUFFO1VBQWtDLENBQXFCLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtZQUFBUSxRQUFBLEVBQUU7VUFBbUIsQ0FBcUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1lBQUFRLFFBQUEsRUFBRTtVQUF3QixDQUFxQixDQUFDO1FBQUEsQ0FBaUIsQ0FBQyxFQUFDLE1BQU0sZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFrQixDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyxlQUFlLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQXdCLENBQW1CLENBQUMsRUFBQyxtUUFBbVE7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBUyxRQUFBLEdBQUUsNkRBQTZELGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBUSxRQUFBLEdBQUUsT0FBTyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFZLENBQW1CLENBQUMsRUFBQyw2QkFBNkI7TUFBQSxDQUFxQixDQUFDLEVBQUMsMERBQTBEO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDTyxFQUFFLElBQUUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBVixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNNLEVBQUU7TUFBQ2MsRUFBRSxFQUFDLDRCQUE0QjtNQUFBRCxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQTRCLENBQUUsQ0FBQyxFQUFDLDZCQUE2QjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1MsRUFBRTtNQUFBVSxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNRLEVBQUU7UUFBQVcsUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFxQixDQUFxQixDQUFDLEVBQUMsK0VBQStFLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLDBIQUEwSCxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQXFDLENBQXFCLENBQUMsRUFBQywyRUFBMkUsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBOEIsQ0FBbUIsQ0FBQyxFQUFDLGdCQUFnQixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQU8sQ0FBcUIsQ0FBQyxFQUFDLDREQUE0RCxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFxQixDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUF3QixDQUFtQixDQUFDLEVBQUMsaUJBQWlCLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQVMsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBZSxDQUFtQixDQUFDLEVBQUMsY0FBYyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFZLENBQW1CLENBQUMsRUFBQyxjQUFjLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBTSxDQUFxQixDQUFDLEVBQUMsa0RBQWtEO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDUSxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7WUFBQWlCLFFBQUEsRUFBRTtVQUFZLENBQW1CLENBQUMsRUFBQyw0QkFBNEI7UUFBQSxDQUFxQixDQUFDLEVBQUMsdUhBQXVIO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDUSxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEdBQUUsZUFBZSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7WUFBQWlCLFFBQUEsRUFBRTtVQUFPLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBaUIsUUFBQSxFQUFFO1VBQVcsQ0FBbUIsQ0FBQyxFQUFDLDJCQUEyQjtRQUFBLENBQXFCLENBQUMsRUFBQyw0RkFBNEY7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNRLEVBQUU7UUFBQVcsUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUF5RCxDQUFxQixDQUFDLEVBQUMsa0RBQWtELGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQXFCLENBQW1CLENBQUMsRUFBQyxHQUFHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDUSxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBbUMsQ0FBcUIsQ0FBQyxFQUFDLDhHQUE4RztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBVyxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQXFDLENBQXFCLENBQUMsRUFBQyx1RkFBdUY7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBUyxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQXdCLENBQXFCLENBQUMsRUFBQywwQ0FBMEMsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRSxJQUFJO1FBQUFpQixRQUFBLEVBQUU7TUFBTyxDQUFtQixDQUFDLEVBQUMsaUxBQWlMO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDTyxFQUFFLElBQUUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBVixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNNLEVBQUU7TUFBQ2MsRUFBRSxFQUFDLGdCQUFnQjtNQUFBRCxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQWdCLENBQUUsQ0FBQyxFQUFDLGdCQUFnQjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1MsRUFBRTtNQUFBVSxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNRLEVBQUU7UUFBQVcsUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFrQixDQUFxQixDQUFDLEVBQUMsU0FBUyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNFLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQyxtSEFBbUg7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNRLEVBQUU7UUFBQVcsUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUF1QixDQUFxQixDQUFDLEVBQUMsaUJBQWlCLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQUssQ0FBbUIsQ0FBQyxFQUFDLCtGQUErRjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBVyxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQWlCLENBQXFCLENBQUMsRUFBQyx1RUFBdUU7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNRLEVBQUU7UUFBQVcsUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUF5QixDQUFxQixDQUFDLEVBQUMsc0JBQXNCLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQVksQ0FBbUIsQ0FBQyxFQUFDLHFKQUFxSjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDVSxDQUFDO01BQUFTLFFBQUEsR0FBRSxNQUFNLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBaUIsUUFBQSxFQUFFO01BQXVDLENBQW1CLENBQUMsRUFBQyw0SEFBNEg7SUFBQSxDQUFnQixDQUFDO0VBQUEsQ0FBRSxDQUFDO0FBQ2praUI7QUFDZSxTQUFTRyxVQUFVQSxDQUFDdkIsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFO0VBQzdDLE1BQU07SUFBQ3dCLE9BQU8sRUFBRUM7RUFBUyxDQUFDLEdBQUc7SUFDM0IsR0FBRyxJQUFBWCw2QkFBa0IsRUFBQyxDQUFDO0lBQ3ZCLEdBQUdkLEtBQUssQ0FBQ2U7RUFDWCxDQUFDO0VBQ0QsT0FBT1UsU0FBUyxnQkFBRyxJQUFBM0IsV0FBQSxDQUFBd0IsR0FBQSxFQUFDRyxTQUFTO0lBQUEsR0FBS3pCLEtBQUs7SUFBQW9CLFFBQUEsZUFBRSxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDdkIsaUJBQWlCO01BQUEsR0FBS0M7SUFBSyxDQUFHO0VBQUMsQ0FBVyxDQUFDLEdBQUdELGlCQUFpQixDQUFDQyxLQUFLLENBQUM7QUFDbEg7QUFBQzBCLEVBQUEsR0FOdUJILFVBQVU7QUFPbEMsU0FBU04sb0JBQW9CQSxDQUFDSSxFQUFFLEVBQUVNLFNBQVMsRUFBRUMsS0FBSyxFQUFFO0VBQ2xELE1BQU0sSUFBSUMsS0FBSyxDQUFDLFdBQVcsSUFBSUYsU0FBUyxHQUFHLFdBQVcsR0FBRyxRQUFRLENBQUMsR0FBRyxJQUFJLEdBQUdOLEVBQUUsR0FBRyxvRUFBb0UsSUFBSU8sS0FBSyxHQUFHLHFDQUFxQyxHQUFHQSxLQUFLLEdBQUcsZ0NBQWdDLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDMVA7QUFBQyxJQUFBRixFQUFBO0FBQUFJLFlBQUEsQ0FBQUosRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}