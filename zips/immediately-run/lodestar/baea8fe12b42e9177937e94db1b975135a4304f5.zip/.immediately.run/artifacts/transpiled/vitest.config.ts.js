"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _config = require("vitest/config");
// Vitest config for the whiteboard app's unit tests (R3-398, R3-399). Pure
// `src/lib/` logic tests run in the node environment; component tests opt into
// jsdom with a `// @vitest-environment jsdom` docblock (like file-explorer).
var _default = exports.default = (0, _config.defineConfig)({
  test: {
    environment: 'node',
    include: ['src/**/*.test.{ts,tsx}'],
    setupFiles: ['./src/test/setup.ts']
  }
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY29uZmlnIiwicmVxdWlyZSIsIl9kZWZhdWx0IiwiZXhwb3J0cyIsImRlZmF1bHQiLCJkZWZpbmVDb25maWciLCJ0ZXN0IiwiZW52aXJvbm1lbnQiLCJpbmNsdWRlIiwic2V0dXBGaWxlcyJdLCJzb3VyY2VzIjpbInZpdGVzdC5jb25maWcudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgZGVmaW5lQ29uZmlnIH0gZnJvbSAndml0ZXN0L2NvbmZpZyc7XG5cbi8vIFZpdGVzdCBjb25maWcgZm9yIHRoZSB3aGl0ZWJvYXJkIGFwcCdzIHVuaXQgdGVzdHMgKFIzLTM5OCwgUjMtMzk5KS4gUHVyZVxuLy8gYHNyYy9saWIvYCBsb2dpYyB0ZXN0cyBydW4gaW4gdGhlIG5vZGUgZW52aXJvbm1lbnQ7IGNvbXBvbmVudCB0ZXN0cyBvcHQgaW50b1xuLy8ganNkb20gd2l0aCBhIGAvLyBAdml0ZXN0LWVudmlyb25tZW50IGpzZG9tYCBkb2NibG9jayAobGlrZSBmaWxlLWV4cGxvcmVyKS5cbmV4cG9ydCBkZWZhdWx0IGRlZmluZUNvbmZpZyh7XG4gIHRlc3Q6IHtcbiAgICBlbnZpcm9ubWVudDogJ25vZGUnLFxuICAgIGluY2x1ZGU6IFsnc3JjLyoqLyoudGVzdC57dHMsdHN4fSddLFxuICAgIHNldHVwRmlsZXM6IFsnLi9zcmMvdGVzdC9zZXR1cC50cyddLFxuICB9LFxufSk7XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUFBLElBQUFBLE9BQUEsR0FBQUMsT0FBQTtBQUVBO0FBQ0E7QUFDQTtBQUFBLElBQUFDLFFBQUEsR0FBQUMsT0FBQSxDQUFBQyxPQUFBLEdBQ2UsSUFBQUMsb0JBQVksRUFBQztFQUMxQkMsSUFBSSxFQUFFO0lBQ0pDLFdBQVcsRUFBRSxNQUFNO0lBQ25CQyxPQUFPLEVBQUUsQ0FBQyx3QkFBd0IsQ0FBQztJQUNuQ0MsVUFBVSxFQUFFLENBQUMscUJBQXFCO0VBQ3BDO0FBQ0YsQ0FBQyxDQUFDIiwiaWdub3JlTGlzdCI6W119