var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _Icon = _interopRequireDefault(require("../Icon"));
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// A board-authored React component that threw. Per spec §3.2 each object body
// renders inside an error boundary: a throwing component shows an error chip
// with the message and NEVER takes down the canvas. (The message, never a stack
// trace — DESIGN_BRIEF §1.)

function ComponentError({
  o
}) {
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    style: {
      position: 'absolute',
      inset: 0,
      borderRadius: 12,
      overflow: 'hidden',
      background: 'color-mix(in oklab, #e0484f 12%, var(--panel))',
      border: '1px solid color-mix(in oklab, #e0484f 40%, var(--line))',
      padding: 14,
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    },
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 7,
        color: '#e0707a',
        font: 'var(--mono-xs)',
        letterSpacing: '.04em'
      },
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
        name: "alert",
        size: 14,
        strokeWidth: 1.75
      }), o.title]
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      style: {
        font: 'var(--mono-sm)',
        color: 'var(--ink-2)',
        textWrap: 'pretty'
      },
      children: o.error
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      style: {
        marginTop: 'auto',
        font: 'var(--mono-xs)',
        color: 'var(--ink-3)'
      },
      children: "Component threw \u2014 canvas kept rendering."
    })]
  });
}
_c = ComponentError;
var _default = exports.default = ComponentError;
var _c;
$RefreshReg$(_c, "ComponentError");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfSWNvbiIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJlIiwiX19lc01vZHVsZSIsImRlZmF1bHQiLCJDb21wb25lbnRFcnJvciIsIm8iLCJqc3hzIiwic3R5bGUiLCJwb3NpdGlvbiIsImluc2V0IiwiYm9yZGVyUmFkaXVzIiwib3ZlcmZsb3ciLCJiYWNrZ3JvdW5kIiwiYm9yZGVyIiwicGFkZGluZyIsImRpc3BsYXkiLCJmbGV4RGlyZWN0aW9uIiwiZ2FwIiwiY2hpbGRyZW4iLCJhbGlnbkl0ZW1zIiwiY29sb3IiLCJmb250IiwibGV0dGVyU3BhY2luZyIsImpzeCIsIm5hbWUiLCJzaXplIiwic3Ryb2tlV2lkdGgiLCJ0aXRsZSIsInRleHRXcmFwIiwiZXJyb3IiLCJtYXJnaW5Ub3AiLCJfYyIsIl9kZWZhdWx0IiwiZXhwb3J0cyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkNvbXBvbmVudEVycm9yLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBBIGJvYXJkLWF1dGhvcmVkIFJlYWN0IGNvbXBvbmVudCB0aGF0IHRocmV3LiBQZXIgc3BlYyDCpzMuMiBlYWNoIG9iamVjdCBib2R5XG4vLyByZW5kZXJzIGluc2lkZSBhbiBlcnJvciBib3VuZGFyeTogYSB0aHJvd2luZyBjb21wb25lbnQgc2hvd3MgYW4gZXJyb3IgY2hpcFxuLy8gd2l0aCB0aGUgbWVzc2FnZSBhbmQgTkVWRVIgdGFrZXMgZG93biB0aGUgY2FudmFzLiAoVGhlIG1lc3NhZ2UsIG5ldmVyIGEgc3RhY2tcbi8vIHRyYWNlIOKAlCBERVNJR05fQlJJRUYgwqcxLilcblxuaW1wb3J0IEljb24gZnJvbSAnLi4vSWNvbic7XG5pbXBvcnQgdHlwZSB7IFdPYmplY3QgfSBmcm9tICcuLi8uLi9saWIvdHlwZXMnO1xuXG5mdW5jdGlvbiBDb21wb25lbnRFcnJvcih7IG8gfTogeyBvOiBXT2JqZWN0IH0pIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2XG4gICAgICBzdHlsZT17e1xuICAgICAgICBwb3NpdGlvbjogJ2Fic29sdXRlJyxcbiAgICAgICAgaW5zZXQ6IDAsXG4gICAgICAgIGJvcmRlclJhZGl1czogMTIsXG4gICAgICAgIG92ZXJmbG93OiAnaGlkZGVuJyxcbiAgICAgICAgYmFja2dyb3VuZDogJ2NvbG9yLW1peChpbiBva2xhYiwgI2UwNDg0ZiAxMiUsIHZhcigtLXBhbmVsKSknLFxuICAgICAgICBib3JkZXI6ICcxcHggc29saWQgY29sb3ItbWl4KGluIG9rbGFiLCAjZTA0ODRmIDQwJSwgdmFyKC0tbGluZSkpJyxcbiAgICAgICAgcGFkZGluZzogMTQsXG4gICAgICAgIGRpc3BsYXk6ICdmbGV4JyxcbiAgICAgICAgZmxleERpcmVjdGlvbjogJ2NvbHVtbicsXG4gICAgICAgIGdhcDogOCxcbiAgICAgIH19XG4gICAgPlxuICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBnYXA6IDcsIGNvbG9yOiAnI2UwNzA3YScsIGZvbnQ6ICd2YXIoLS1tb25vLXhzKScsIGxldHRlclNwYWNpbmc6ICcuMDRlbScgfX0+XG4gICAgICAgIDxJY29uIG5hbWU9XCJhbGVydFwiIHNpemU9ezE0fSBzdHJva2VXaWR0aD17MS43NX0gLz5cbiAgICAgICAge28udGl0bGV9XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXYgc3R5bGU9e3sgZm9udDogJ3ZhcigtLW1vbm8tc20pJywgY29sb3I6ICd2YXIoLS1pbmstMiknLCB0ZXh0V3JhcDogJ3ByZXR0eScgfX0+e28uZXJyb3J9PC9kaXY+XG4gICAgICA8ZGl2IHN0eWxlPXt7IG1hcmdpblRvcDogJ2F1dG8nLCBmb250OiAndmFyKC0tbW9uby14cyknLCBjb2xvcjogJ3ZhcigtLWluay0zKScgfX0+Q29tcG9uZW50IHRocmV3IOKAlCBjYW52YXMga2VwdCByZW5kZXJpbmcuPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IENvbXBvbmVudEVycm9yO1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFLQSxJQUFBQSxLQUFBLEdBQUFDLHNCQUFBLENBQUFDLE9BQUE7QUFBMkIsSUFBQUMsV0FBQSxHQUFBRCxPQUFBO0FBQUEsU0FBQUQsdUJBQUFHLENBQUEsV0FBQUEsQ0FBQSxJQUFBQSxDQUFBLENBQUFDLFVBQUEsR0FBQUQsQ0FBQSxLQUFBRSxPQUFBLEVBQUFGLENBQUE7QUFMM0I7QUFDQTtBQUNBO0FBQ0E7O0FBS0EsU0FBU0csY0FBY0EsQ0FBQztFQUFFQztBQUFrQixDQUFDLEVBQUU7RUFDN0Msb0JBQ0UsSUFBQUwsV0FBQSxDQUFBTSxJQUFBO0lBQ0VDLEtBQUssRUFBRTtNQUNMQyxRQUFRLEVBQUUsVUFBVTtNQUNwQkMsS0FBSyxFQUFFLENBQUM7TUFDUkMsWUFBWSxFQUFFLEVBQUU7TUFDaEJDLFFBQVEsRUFBRSxRQUFRO01BQ2xCQyxVQUFVLEVBQUUsZ0RBQWdEO01BQzVEQyxNQUFNLEVBQUUseURBQXlEO01BQ2pFQyxPQUFPLEVBQUUsRUFBRTtNQUNYQyxPQUFPLEVBQUUsTUFBTTtNQUNmQyxhQUFhLEVBQUUsUUFBUTtNQUN2QkMsR0FBRyxFQUFFO0lBQ1AsQ0FBRTtJQUFBQyxRQUFBLGdCQUVGLElBQUFsQixXQUFBLENBQUFNLElBQUE7TUFBS0MsS0FBSyxFQUFFO1FBQUVRLE9BQU8sRUFBRSxNQUFNO1FBQUVJLFVBQVUsRUFBRSxRQUFRO1FBQUVGLEdBQUcsRUFBRSxDQUFDO1FBQUVHLEtBQUssRUFBRSxTQUFTO1FBQUVDLElBQUksRUFBRSxnQkFBZ0I7UUFBRUMsYUFBYSxFQUFFO01BQVEsQ0FBRTtNQUFBSixRQUFBLGdCQUM5SCxJQUFBbEIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDMUIsS0FBQSxDQUFBTSxPQUFJO1FBQUNxQixJQUFJLEVBQUMsT0FBTztRQUFDQyxJQUFJLEVBQUUsRUFBRztRQUFDQyxXQUFXLEVBQUU7TUFBSyxDQUFFLENBQUMsRUFDakRyQixDQUFDLENBQUNzQixLQUFLO0lBQUEsQ0FDTCxDQUFDLGVBQ04sSUFBQTNCLFdBQUEsQ0FBQXVCLEdBQUE7TUFBS2hCLEtBQUssRUFBRTtRQUFFYyxJQUFJLEVBQUUsZ0JBQWdCO1FBQUVELEtBQUssRUFBRSxjQUFjO1FBQUVRLFFBQVEsRUFBRTtNQUFTLENBQUU7TUFBQVYsUUFBQSxFQUFFYixDQUFDLENBQUN3QjtJQUFLLENBQU0sQ0FBQyxlQUNsRyxJQUFBN0IsV0FBQSxDQUFBdUIsR0FBQTtNQUFLaEIsS0FBSyxFQUFFO1FBQUV1QixTQUFTLEVBQUUsTUFBTTtRQUFFVCxJQUFJLEVBQUUsZ0JBQWdCO1FBQUVELEtBQUssRUFBRTtNQUFlLENBQUU7TUFBQUYsUUFBQSxFQUFDO0lBQXdDLENBQUssQ0FBQztFQUFBLENBQzdILENBQUM7QUFFVjtBQUFDYSxFQUFBLEdBeEJRM0IsY0FBYztBQUFBLElBQUE0QixRQUFBLEdBQUFDLE9BQUEsQ0FBQTlCLE9BQUEsR0EwQlJDLGNBQWM7QUFBQSxJQUFBMkIsRUFBQTtBQUFBRyxZQUFBLENBQUFILEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}