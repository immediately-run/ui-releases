var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.find.js");
require("core-js/modules/esnext.iterator.map.js");
var _useLodestarCtx = require("../hooks/useLodestarCtx");
var _Icon = _interopRequireDefault(require("./Icon"));
var _seedBoard = require("../data/seedBoard");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The edit-mode inspector: a right-side panel on desktop, a bottom sheet on
// mobile. Covers the frontmatter-shaped edits (title, tags, note color, lock,
// hidden, z-order, raw geometry) plus "Open source", which hands a single object
// file to the existing edit-file task (spec §4.2). With nothing selected it edits
// board-level settings (background, theme); with many, a bulk delete.
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
const fl = {
  font: 'var(--mono-xs)',
  letterSpacing: '.05em',
  textTransform: 'uppercase',
  color: 'var(--ink-3)'
};
const inp = {
  width: '100%',
  padding: '8px 10px',
  background: 'var(--bg)',
  border: '1px solid var(--line-2)',
  borderRadius: 8,
  color: 'var(--ink)',
  font: 'var(--body-sm)'
};
const seg = on => ({
  flex: 1,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  gap: 5,
  padding: '7px 8px',
  background: on ? 'color-mix(in oklab, var(--accent-2) 28%, var(--panel))' : 'var(--bg)',
  border: `1px solid ${on ? 'color-mix(in oklab, var(--accent-2) 55%, var(--line-2))' : 'var(--line-2)'}`,
  borderRadius: 8,
  color: 'var(--ink)',
  font: 'var(--body-sm)',
  cursor: 'pointer',
  textTransform: 'capitalize'
});
const toggleBtn = on => ({
  flex: 1,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  gap: 6,
  padding: 9,
  background: on ? 'color-mix(in oklab, var(--accent) 22%, var(--panel))' : 'var(--bg)',
  border: `1px solid ${on ? 'color-mix(in oklab, var(--accent) 50%, var(--line-2))' : 'var(--line-2)'}`,
  borderRadius: 8,
  color: 'var(--ink)',
  font: 'var(--label)',
  cursor: 'pointer'
});
const btnGhost = {
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  gap: 7,
  padding: 10,
  background: 'var(--bg)',
  border: '1px solid var(--line-2)',
  borderRadius: 9,
  color: 'var(--ink)',
  font: 'var(--label)',
  cursor: 'pointer'
};
const btnDanger = {
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  gap: 7,
  padding: 10,
  background: 'color-mix(in oklab, #e0484f 12%, var(--panel))',
  border: '1px solid color-mix(in oklab, #e0484f 35%, var(--line))',
  borderRadius: 9,
  color: '#e07078',
  font: 'var(--label)',
  cursor: 'pointer'
};
function Field({
  label,
  children
}) {
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("label", {
    style: {
      display: 'block'
    },
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      style: fl,
      children: label
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      style: {
        marginTop: 6
      },
      children: children
    })]
  });
}
_c = Field;
function Inspector() {
  _s();
  const wb = (0, _useLodestarCtx.useWb)();
  const {
    inspectorOpen,
    selection,
    objects,
    views,
    journeys,
    bg,
    light
  } = wb.state;
  if (!inspectorOpen) return null;
  const mobile = wb.isMobile();
  const head = (title, sub) => /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '16px 18px 12px',
      borderBottom: '1px solid var(--line)'
    },
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        style: {
          font: '700 16px/1 var(--disp)',
          color: 'var(--ink)',
          textTransform: 'capitalize'
        },
        children: title
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        style: {
          font: 'var(--mono-xs)',
          color: 'var(--ink-3)',
          marginTop: 4
        },
        children: sub
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
      onClick: wb.closeInspector,
      style: {
        display: 'flex',
        padding: 5,
        background: 'none',
        border: 'none',
        color: 'var(--ink-3)',
        cursor: 'pointer'
      },
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
        name: "x",
        size: 16
      })
    })]
  });
  let body;
  const sel = selection.length === 1 ? objects.find(o => o.id === selection[0]) ?? null : null;
  if (selection.length > 1) {
    body = /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      style: {
        padding: 18,
        display: 'flex',
        flexDirection: 'column',
        gap: 14
      },
      children: [head(`${selection.length} objects selected`, 'multi'), /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
        onClick: wb.deleteSelection,
        style: btnDanger,
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
          name: "trash",
          size: 15,
          strokeWidth: 1.75
        }), "Delete selection"]
      })]
    });
  } else if (!sel) {
    body = /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      style: {
        display: 'flex',
        flexDirection: 'column'
      },
      children: [head('Board', 'board'), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        style: {
          padding: '4px 18px 18px',
          display: 'flex',
          flexDirection: 'column',
          gap: 16
        },
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(Field, {
          label: "Title",
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)("input", {
            defaultValue: "Q3 planning",
            style: inp
          })
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
            style: fl,
            children: "Background"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
            style: {
              display: 'flex',
              gap: 6,
              marginTop: 7
            },
            children: ['grid', 'dots', 'plain'].map(b => /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
              onClick: () => wb.setBackground(b),
              style: seg(bg === b),
              children: b
            }, b))
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
            style: fl,
            children: "Theme"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
            style: {
              display: 'flex',
              gap: 6,
              marginTop: 7
            },
            children: [['dark', false], ['light', true]].map(([lbl, v]) => /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
              onClick: () => wb.setLight(v),
              style: seg(light === v),
              children: lbl
            }, lbl))
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
          style: {
            font: 'var(--mono-xs)',
            color: 'var(--ink-3)',
            lineHeight: 1.6,
            paddingTop: 4,
            borderTop: '1px solid var(--line)'
          },
          children: `${objects.length} objects · ${views.length} views · ${journeys.length} journeys`
        })]
      })]
    });
  } else {
    const isNote = sel.kind === 'note';
    body = /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      style: {
        display: 'flex',
        flexDirection: 'column'
      },
      children: [head(sel.kind, sel.id), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        style: {
          padding: '4px 18px 18px',
          display: 'flex',
          flexDirection: 'column',
          gap: 15
        },
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(Field, {
          label: "Title",
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)("input", {
            value: sel.title || '',
            onChange: e => wb.patchSel({
              title: e.target.value
            }),
            style: inp
          })
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)(Field, {
          label: "Tags",
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)("input", {
            value: sel.tags || '',
            placeholder: "comma, separated",
            onChange: e => wb.patchSel({
              tags: e.target.value
            }),
            style: inp
          })
        }), isNote ? /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
            style: fl,
            children: "Note color"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
            style: {
              display: 'flex',
              flexWrap: 'wrap',
              gap: 7,
              marginTop: 8
            },
            children: _seedBoard.NOTE_COLORS.map(c => /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
              title: c,
              onClick: () => wb.patchSel({
                color: c
              }),
              style: {
                width: 30,
                height: 30,
                borderRadius: 8,
                background: `var(--n-${c})`,
                border: sel.color === c ? '2px solid var(--ink)' : '1px solid rgba(0,0,0,.15)',
                cursor: 'pointer',
                boxShadow: sel.color === c ? '0 0 0 2px var(--bg), 0 0 0 3px var(--accent)' : 'none'
              }
            }, c))
          })]
        }) : null, /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
          style: {
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            gap: 10
          },
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(Field, {
            label: "X",
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)("input", {
              type: "number",
              value: Math.round(sel.x),
              onChange: e => wb.patchSel({
                x: +e.target.value
              }),
              style: inp
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(Field, {
            label: "Y",
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)("input", {
              type: "number",
              value: Math.round(sel.y),
              onChange: e => wb.patchSel({
                y: +e.target.value
              }),
              style: inp
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(Field, {
            label: "W",
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)("input", {
              type: "number",
              value: Math.round(sel.w),
              onChange: e => wb.patchSel({
                w: +e.target.value
              }),
              style: inp
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(Field, {
            label: "H",
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)("input", {
              type: "number",
              value: Math.round(sel.h),
              onChange: e => wb.patchSel({
                h: +e.target.value
              }),
              style: inp
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)(Field, {
          label: "Rotation",
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)("input", {
            type: "number",
            "aria-label": "Rotation in degrees",
            value: Math.round(sel.rot || 0),
            onChange: e => wb.patchSel({
              rot: +e.target.value
            }),
            style: inp
          })
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
          onClick: wb.beginConnect,
          disabled: selection.length !== 1,
          title: selection.length !== 1 ? 'Connect needs exactly one object selected' : 'Arrows pick the target · Enter connects · Escape cancels',
          style: selection.length !== 1 ? {
            ...btnGhost,
            opacity: 0.55,
            cursor: 'default'
          } : btnGhost,
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
            name: "refresh",
            size: 14,
            strokeWidth: 1.75
          }), "Connect from here\u2026"]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
            style: fl,
            children: "Stacking"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
            style: {
              display: 'flex',
              gap: 6,
              marginTop: 7
            },
            children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
              onClick: () => wb.patchSel({
                z: (sel.z || 0) + 1
              }),
              style: seg(false),
              children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
                name: "arrowUp",
                size: 14,
                strokeWidth: 1.75
              }), "Up"]
            }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
              onClick: () => wb.patchSel({
                z: Math.max(0, (sel.z || 0) - 1)
              }),
              style: seg(false),
              children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
                name: "arrowDown",
                size: 14,
                strokeWidth: 1.75
              }), "Down"]
            }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
              onClick: () => wb.patchSel({
                z: 99
              }),
              style: seg(false),
              children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
                name: "bringFront",
                size: 14,
                strokeWidth: 1.5
              }), "Front"]
            })]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
          style: {
            display: 'flex',
            gap: 8
          },
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
            onClick: () => wb.patchSel({
              locked: !sel.locked
            }),
            style: toggleBtn(!!sel.locked),
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
              name: "lock",
              size: 14,
              strokeWidth: 1.75
            }), sel.locked ? 'Locked' : 'Lock']
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
            onClick: () => wb.patchSel({
              hidden: !sel.hidden
            }),
            style: toggleBtn(!!sel.hidden),
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
              name: "eyeOff",
              size: 14,
              strokeWidth: 1.75
            }), sel.hidden ? 'Hidden' : 'Hide']
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
          onClick: () => wb.toast(`Opening ${sel.id}.mdx in edit-file…`, 'pencil'),
          style: btnGhost,
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
            name: "pencil",
            size: 14,
            strokeWidth: 1.75
          }), "Open source"]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
          onClick: wb.deleteSelection,
          style: btnDanger,
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
            name: "trash",
            size: 14,
            strokeWidth: 1.75
          }), "Delete"]
        })]
      })]
    });
  }
  const wrapStyle = mobile ? {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    maxHeight: '64%',
    background: 'color-mix(in oklab, var(--panel) 97%, transparent)',
    borderTop: '1px solid var(--line-2)',
    borderRadius: '18px 18px 0 0',
    zIndex: 46,
    backdropFilter: 'blur(14px)',
    boxShadow: '0 -12px 34px rgba(0,0,0,.4)',
    overflowY: 'auto',
    display: 'flex',
    flexDirection: 'column'
  } : {
    position: 'absolute',
    top: 72,
    right: 16,
    bottom: 16,
    width: 312,
    background: 'color-mix(in oklab, var(--panel) 94%, transparent)',
    border: '1px solid var(--line)',
    borderRadius: 'var(--r-xl)',
    zIndex: 38,
    backdropFilter: 'blur(14px)',
    boxShadow: 'var(--shadow-pop)',
    overflowY: 'auto',
    display: 'flex',
    flexDirection: 'column'
  };
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    className: "wb-scroll",
    style: wrapStyle,
    children: body
  });
}
_s(Inspector, "VeUy8AIV4bR/U9OnzH43HThc4KU=", false, function () {
  return [_useLodestarCtx.useWb];
});
_c2 = Inspector;
var _default = exports.default = Inspector;
var _c, _c2;
$RefreshReg$(_c, "Field");
$RefreshReg$(_c2, "Inspector");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdXNlTG9kZXN0YXJDdHgiLCJyZXF1aXJlIiwiX0ljb24iLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX3NlZWRCb2FyZCIsIl9qc3hSdW50aW1lIiwiX3MiLCIkUmVmcmVzaFNpZyQiLCJlIiwiX19lc01vZHVsZSIsImRlZmF1bHQiLCJmbCIsImZvbnQiLCJsZXR0ZXJTcGFjaW5nIiwidGV4dFRyYW5zZm9ybSIsImNvbG9yIiwiaW5wIiwid2lkdGgiLCJwYWRkaW5nIiwiYmFja2dyb3VuZCIsImJvcmRlciIsImJvcmRlclJhZGl1cyIsInNlZyIsIm9uIiwiZmxleCIsImRpc3BsYXkiLCJhbGlnbkl0ZW1zIiwianVzdGlmeUNvbnRlbnQiLCJnYXAiLCJjdXJzb3IiLCJ0b2dnbGVCdG4iLCJidG5HaG9zdCIsImJ0bkRhbmdlciIsIkZpZWxkIiwibGFiZWwiLCJjaGlsZHJlbiIsImpzeHMiLCJzdHlsZSIsImpzeCIsIm1hcmdpblRvcCIsIl9jIiwiSW5zcGVjdG9yIiwid2IiLCJ1c2VXYiIsImluc3BlY3Rvck9wZW4iLCJzZWxlY3Rpb24iLCJvYmplY3RzIiwidmlld3MiLCJqb3VybmV5cyIsImJnIiwibGlnaHQiLCJzdGF0ZSIsIm1vYmlsZSIsImlzTW9iaWxlIiwiaGVhZCIsInRpdGxlIiwic3ViIiwiYm9yZGVyQm90dG9tIiwib25DbGljayIsImNsb3NlSW5zcGVjdG9yIiwibmFtZSIsInNpemUiLCJib2R5Iiwic2VsIiwibGVuZ3RoIiwiZmluZCIsIm8iLCJpZCIsImZsZXhEaXJlY3Rpb24iLCJkZWxldGVTZWxlY3Rpb24iLCJzdHJva2VXaWR0aCIsImRlZmF1bHRWYWx1ZSIsIm1hcCIsImIiLCJzZXRCYWNrZ3JvdW5kIiwibGJsIiwidiIsInNldExpZ2h0IiwibGluZUhlaWdodCIsInBhZGRpbmdUb3AiLCJib3JkZXJUb3AiLCJpc05vdGUiLCJraW5kIiwidmFsdWUiLCJvbkNoYW5nZSIsInBhdGNoU2VsIiwidGFyZ2V0IiwidGFncyIsInBsYWNlaG9sZGVyIiwiZmxleFdyYXAiLCJOT1RFX0NPTE9SUyIsImMiLCJoZWlnaHQiLCJib3hTaGFkb3ciLCJncmlkVGVtcGxhdGVDb2x1bW5zIiwidHlwZSIsIk1hdGgiLCJyb3VuZCIsIngiLCJ5IiwidyIsImgiLCJyb3QiLCJiZWdpbkNvbm5lY3QiLCJkaXNhYmxlZCIsIm9wYWNpdHkiLCJ6IiwibWF4IiwibG9ja2VkIiwiaGlkZGVuIiwidG9hc3QiLCJ3cmFwU3R5bGUiLCJwb3NpdGlvbiIsImxlZnQiLCJyaWdodCIsImJvdHRvbSIsIm1heEhlaWdodCIsInpJbmRleCIsImJhY2tkcm9wRmlsdGVyIiwib3ZlcmZsb3dZIiwidG9wIiwiY2xhc3NOYW1lIiwiX2MyIiwiX2RlZmF1bHQiLCJleHBvcnRzIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiSW5zcGVjdG9yLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBUaGUgZWRpdC1tb2RlIGluc3BlY3RvcjogYSByaWdodC1zaWRlIHBhbmVsIG9uIGRlc2t0b3AsIGEgYm90dG9tIHNoZWV0IG9uXG4vLyBtb2JpbGUuIENvdmVycyB0aGUgZnJvbnRtYXR0ZXItc2hhcGVkIGVkaXRzICh0aXRsZSwgdGFncywgbm90ZSBjb2xvciwgbG9jayxcbi8vIGhpZGRlbiwgei1vcmRlciwgcmF3IGdlb21ldHJ5KSBwbHVzIFwiT3BlbiBzb3VyY2VcIiwgd2hpY2ggaGFuZHMgYSBzaW5nbGUgb2JqZWN0XG4vLyBmaWxlIHRvIHRoZSBleGlzdGluZyBlZGl0LWZpbGUgdGFzayAoc3BlYyDCpzQuMikuIFdpdGggbm90aGluZyBzZWxlY3RlZCBpdCBlZGl0c1xuLy8gYm9hcmQtbGV2ZWwgc2V0dGluZ3MgKGJhY2tncm91bmQsIHRoZW1lKTsgd2l0aCBtYW55LCBhIGJ1bGsgZGVsZXRlLlxuXG5pbXBvcnQgeyB1c2VXYiB9IGZyb20gJy4uL2hvb2tzL3VzZUxvZGVzdGFyQ3R4JztcbmltcG9ydCBJY29uIGZyb20gJy4vSWNvbic7XG5pbXBvcnQgeyBOT1RFX0NPTE9SUyB9IGZyb20gJy4uL2RhdGEvc2VlZEJvYXJkJztcbmltcG9ydCB0eXBlIHsgQmFja2dyb3VuZCwgV09iamVjdCB9IGZyb20gJy4uL2xpYi90eXBlcyc7XG5cbmNvbnN0IGZsOiBSZWFjdC5DU1NQcm9wZXJ0aWVzID0geyBmb250OiAndmFyKC0tbW9uby14cyknLCBsZXR0ZXJTcGFjaW5nOiAnLjA1ZW0nLCB0ZXh0VHJhbnNmb3JtOiAndXBwZXJjYXNlJywgY29sb3I6ICd2YXIoLS1pbmstMyknIH07XG5jb25zdCBpbnA6IFJlYWN0LkNTU1Byb3BlcnRpZXMgPSB7IHdpZHRoOiAnMTAwJScsIHBhZGRpbmc6ICc4cHggMTBweCcsIGJhY2tncm91bmQ6ICd2YXIoLS1iZyknLCBib3JkZXI6ICcxcHggc29saWQgdmFyKC0tbGluZS0yKScsIGJvcmRlclJhZGl1czogOCwgY29sb3I6ICd2YXIoLS1pbmspJywgZm9udDogJ3ZhcigtLWJvZHktc20pJyB9O1xuY29uc3Qgc2VnID0gKG9uOiBib29sZWFuKTogUmVhY3QuQ1NTUHJvcGVydGllcyA9PiAoe1xuICBmbGV4OiAxLFxuICBkaXNwbGF5OiAnZmxleCcsXG4gIGFsaWduSXRlbXM6ICdjZW50ZXInLFxuICBqdXN0aWZ5Q29udGVudDogJ2NlbnRlcicsXG4gIGdhcDogNSxcbiAgcGFkZGluZzogJzdweCA4cHgnLFxuICBiYWNrZ3JvdW5kOiBvbiA/ICdjb2xvci1taXgoaW4gb2tsYWIsIHZhcigtLWFjY2VudC0yKSAyOCUsIHZhcigtLXBhbmVsKSknIDogJ3ZhcigtLWJnKScsXG4gIGJvcmRlcjogYDFweCBzb2xpZCAke29uID8gJ2NvbG9yLW1peChpbiBva2xhYiwgdmFyKC0tYWNjZW50LTIpIDU1JSwgdmFyKC0tbGluZS0yKSknIDogJ3ZhcigtLWxpbmUtMiknfWAsXG4gIGJvcmRlclJhZGl1czogOCxcbiAgY29sb3I6ICd2YXIoLS1pbmspJyxcbiAgZm9udDogJ3ZhcigtLWJvZHktc20pJyxcbiAgY3Vyc29yOiAncG9pbnRlcicsXG4gIHRleHRUcmFuc2Zvcm06ICdjYXBpdGFsaXplJyxcbn0pO1xuY29uc3QgdG9nZ2xlQnRuID0gKG9uOiBib29sZWFuKTogUmVhY3QuQ1NTUHJvcGVydGllcyA9PiAoe1xuICBmbGV4OiAxLFxuICBkaXNwbGF5OiAnZmxleCcsXG4gIGFsaWduSXRlbXM6ICdjZW50ZXInLFxuICBqdXN0aWZ5Q29udGVudDogJ2NlbnRlcicsXG4gIGdhcDogNixcbiAgcGFkZGluZzogOSxcbiAgYmFja2dyb3VuZDogb24gPyAnY29sb3ItbWl4KGluIG9rbGFiLCB2YXIoLS1hY2NlbnQpIDIyJSwgdmFyKC0tcGFuZWwpKScgOiAndmFyKC0tYmcpJyxcbiAgYm9yZGVyOiBgMXB4IHNvbGlkICR7b24gPyAnY29sb3ItbWl4KGluIG9rbGFiLCB2YXIoLS1hY2NlbnQpIDUwJSwgdmFyKC0tbGluZS0yKSknIDogJ3ZhcigtLWxpbmUtMiknfWAsXG4gIGJvcmRlclJhZGl1czogOCxcbiAgY29sb3I6ICd2YXIoLS1pbmspJyxcbiAgZm9udDogJ3ZhcigtLWxhYmVsKScsXG4gIGN1cnNvcjogJ3BvaW50ZXInLFxufSk7XG5jb25zdCBidG5HaG9zdDogUmVhY3QuQ1NTUHJvcGVydGllcyA9IHsgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywganVzdGlmeUNvbnRlbnQ6ICdjZW50ZXInLCBnYXA6IDcsIHBhZGRpbmc6IDEwLCBiYWNrZ3JvdW5kOiAndmFyKC0tYmcpJywgYm9yZGVyOiAnMXB4IHNvbGlkIHZhcigtLWxpbmUtMiknLCBib3JkZXJSYWRpdXM6IDksIGNvbG9yOiAndmFyKC0taW5rKScsIGZvbnQ6ICd2YXIoLS1sYWJlbCknLCBjdXJzb3I6ICdwb2ludGVyJyB9O1xuY29uc3QgYnRuRGFuZ2VyOiBSZWFjdC5DU1NQcm9wZXJ0aWVzID0geyBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBqdXN0aWZ5Q29udGVudDogJ2NlbnRlcicsIGdhcDogNywgcGFkZGluZzogMTAsIGJhY2tncm91bmQ6ICdjb2xvci1taXgoaW4gb2tsYWIsICNlMDQ4NGYgMTIlLCB2YXIoLS1wYW5lbCkpJywgYm9yZGVyOiAnMXB4IHNvbGlkIGNvbG9yLW1peChpbiBva2xhYiwgI2UwNDg0ZiAzNSUsIHZhcigtLWxpbmUpKScsIGJvcmRlclJhZGl1czogOSwgY29sb3I6ICcjZTA3MDc4JywgZm9udDogJ3ZhcigtLWxhYmVsKScsIGN1cnNvcjogJ3BvaW50ZXInIH07XG5cbmZ1bmN0aW9uIEZpZWxkKHsgbGFiZWwsIGNoaWxkcmVuIH06IHsgbGFiZWw6IHN0cmluZzsgY2hpbGRyZW46IFJlYWN0LlJlYWN0Tm9kZSB9KSB7XG4gIHJldHVybiAoXG4gICAgPGxhYmVsIHN0eWxlPXt7IGRpc3BsYXk6ICdibG9jaycgfX0+XG4gICAgICA8ZGl2IHN0eWxlPXtmbH0+e2xhYmVsfTwvZGl2PlxuICAgICAgPGRpdiBzdHlsZT17eyBtYXJnaW5Ub3A6IDYgfX0+e2NoaWxkcmVufTwvZGl2PlxuICAgIDwvbGFiZWw+XG4gICk7XG59XG5cbmZ1bmN0aW9uIEluc3BlY3RvcigpIHtcbiAgY29uc3Qgd2IgPSB1c2VXYigpO1xuICBjb25zdCB7IGluc3BlY3Rvck9wZW4sIHNlbGVjdGlvbiwgb2JqZWN0cywgdmlld3MsIGpvdXJuZXlzLCBiZywgbGlnaHQgfSA9IHdiLnN0YXRlO1xuICBpZiAoIWluc3BlY3Rvck9wZW4pIHJldHVybiBudWxsO1xuICBjb25zdCBtb2JpbGUgPSB3Yi5pc01vYmlsZSgpO1xuXG4gIGNvbnN0IGhlYWQgPSAodGl0bGU6IHN0cmluZywgc3ViOiBzdHJpbmcpID0+IChcbiAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGp1c3RpZnlDb250ZW50OiAnc3BhY2UtYmV0d2VlbicsIHBhZGRpbmc6ICcxNnB4IDE4cHggMTJweCcsIGJvcmRlckJvdHRvbTogJzFweCBzb2xpZCB2YXIoLS1saW5lKScgfX0+XG4gICAgICA8ZGl2PlxuICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnQ6ICc3MDAgMTZweC8xIHZhcigtLWRpc3ApJywgY29sb3I6ICd2YXIoLS1pbmspJywgdGV4dFRyYW5zZm9ybTogJ2NhcGl0YWxpemUnIH19Pnt0aXRsZX08L2Rpdj5cbiAgICAgICAgPGRpdiBzdHlsZT17eyBmb250OiAndmFyKC0tbW9uby14cyknLCBjb2xvcjogJ3ZhcigtLWluay0zKScsIG1hcmdpblRvcDogNCB9fT57c3VifTwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgICA8YnV0dG9uIG9uQ2xpY2s9e3diLmNsb3NlSW5zcGVjdG9yfSBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIHBhZGRpbmc6IDUsIGJhY2tncm91bmQ6ICdub25lJywgYm9yZGVyOiAnbm9uZScsIGNvbG9yOiAndmFyKC0taW5rLTMpJywgY3Vyc29yOiAncG9pbnRlcicgfX0+XG4gICAgICAgIDxJY29uIG5hbWU9XCJ4XCIgc2l6ZT17MTZ9IC8+XG4gICAgICA8L2J1dHRvbj5cbiAgICA8L2Rpdj5cbiAgKTtcblxuICBsZXQgYm9keTogUmVhY3QuUmVhY3ROb2RlO1xuICBjb25zdCBzZWw6IFdPYmplY3QgfCBudWxsID0gc2VsZWN0aW9uLmxlbmd0aCA9PT0gMSA/IG9iamVjdHMuZmluZCgobykgPT4gby5pZCA9PT0gc2VsZWN0aW9uWzBdKSA/PyBudWxsIDogbnVsbDtcblxuICBpZiAoc2VsZWN0aW9uLmxlbmd0aCA+IDEpIHtcbiAgICBib2R5ID0gKFxuICAgICAgPGRpdiBzdHlsZT17eyBwYWRkaW5nOiAxOCwgZGlzcGxheTogJ2ZsZXgnLCBmbGV4RGlyZWN0aW9uOiAnY29sdW1uJywgZ2FwOiAxNCB9fT5cbiAgICAgICAge2hlYWQoYCR7c2VsZWN0aW9uLmxlbmd0aH0gb2JqZWN0cyBzZWxlY3RlZGAsICdtdWx0aScpfVxuICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e3diLmRlbGV0ZVNlbGVjdGlvbn0gc3R5bGU9e2J0bkRhbmdlcn0+XG4gICAgICAgICAgPEljb24gbmFtZT1cInRyYXNoXCIgc2l6ZT17MTV9IHN0cm9rZVdpZHRoPXsxLjc1fSAvPlxuICAgICAgICAgIERlbGV0ZSBzZWxlY3Rpb25cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICApO1xuICB9IGVsc2UgaWYgKCFzZWwpIHtcbiAgICBib2R5ID0gKFxuICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGZsZXhEaXJlY3Rpb246ICdjb2x1bW4nIH19PlxuICAgICAgICB7aGVhZCgnQm9hcmQnLCAnYm9hcmQnKX1cbiAgICAgICAgPGRpdiBzdHlsZT17eyBwYWRkaW5nOiAnNHB4IDE4cHggMThweCcsIGRpc3BsYXk6ICdmbGV4JywgZmxleERpcmVjdGlvbjogJ2NvbHVtbicsIGdhcDogMTYgfX0+XG4gICAgICAgICAgPEZpZWxkIGxhYmVsPVwiVGl0bGVcIj5cbiAgICAgICAgICAgIDxpbnB1dCBkZWZhdWx0VmFsdWU9XCJRMyBwbGFubmluZ1wiIHN0eWxlPXtpbnB9IC8+XG4gICAgICAgICAgPC9GaWVsZD5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGRpdiBzdHlsZT17Zmx9PkJhY2tncm91bmQ8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBnYXA6IDYsIG1hcmdpblRvcDogNyB9fT5cbiAgICAgICAgICAgICAgeyhbJ2dyaWQnLCAnZG90cycsICdwbGFpbiddIGFzIEJhY2tncm91bmRbXSkubWFwKChiKSA9PiAoXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBrZXk9e2J9IG9uQ2xpY2s9eygpID0+IHdiLnNldEJhY2tncm91bmQoYil9IHN0eWxlPXtzZWcoYmcgPT09IGIpfT5cbiAgICAgICAgICAgICAgICAgIHtifVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXtmbH0+VGhlbWU8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBnYXA6IDYsIG1hcmdpblRvcDogNyB9fT5cbiAgICAgICAgICAgICAgeyhbWydkYXJrJywgZmFsc2VdLCBbJ2xpZ2h0JywgdHJ1ZV1dIGFzIFtzdHJpbmcsIGJvb2xlYW5dW10pLm1hcCgoW2xibCwgdl0pID0+IChcbiAgICAgICAgICAgICAgICA8YnV0dG9uIGtleT17bGJsfSBvbkNsaWNrPXsoKSA9PiB3Yi5zZXRMaWdodCh2KX0gc3R5bGU9e3NlZyhsaWdodCA9PT0gdil9PlxuICAgICAgICAgICAgICAgICAge2xibH1cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnQ6ICd2YXIoLS1tb25vLXhzKScsIGNvbG9yOiAndmFyKC0taW5rLTMpJywgbGluZUhlaWdodDogMS42LCBwYWRkaW5nVG9wOiA0LCBib3JkZXJUb3A6ICcxcHggc29saWQgdmFyKC0tbGluZSknIH19PlxuICAgICAgICAgICAge2Ake29iamVjdHMubGVuZ3RofSBvYmplY3RzIMK3ICR7dmlld3MubGVuZ3RofSB2aWV3cyDCtyAke2pvdXJuZXlzLmxlbmd0aH0gam91cm5leXNgfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgICk7XG4gIH0gZWxzZSB7XG4gICAgY29uc3QgaXNOb3RlID0gc2VsLmtpbmQgPT09ICdub3RlJztcbiAgICBib2R5ID0gKFxuICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGZsZXhEaXJlY3Rpb246ICdjb2x1bW4nIH19PlxuICAgICAgICB7aGVhZChzZWwua2luZCwgc2VsLmlkKX1cbiAgICAgICAgPGRpdiBzdHlsZT17eyBwYWRkaW5nOiAnNHB4IDE4cHggMThweCcsIGRpc3BsYXk6ICdmbGV4JywgZmxleERpcmVjdGlvbjogJ2NvbHVtbicsIGdhcDogMTUgfX0+XG4gICAgICAgICAgPEZpZWxkIGxhYmVsPVwiVGl0bGVcIj5cbiAgICAgICAgICAgIDxpbnB1dCB2YWx1ZT17c2VsLnRpdGxlIHx8ICcnfSBvbkNoYW5nZT17KGUpID0+IHdiLnBhdGNoU2VsKHsgdGl0bGU6IGUudGFyZ2V0LnZhbHVlIH0pfSBzdHlsZT17aW5wfSAvPlxuICAgICAgICAgIDwvRmllbGQ+XG4gICAgICAgICAgPEZpZWxkIGxhYmVsPVwiVGFnc1wiPlxuICAgICAgICAgICAgPGlucHV0IHZhbHVlPXtzZWwudGFncyB8fCAnJ30gcGxhY2Vob2xkZXI9XCJjb21tYSwgc2VwYXJhdGVkXCIgb25DaGFuZ2U9eyhlKSA9PiB3Yi5wYXRjaFNlbCh7IHRhZ3M6IGUudGFyZ2V0LnZhbHVlIH0pfSBzdHlsZT17aW5wfSAvPlxuICAgICAgICAgIDwvRmllbGQ+XG4gICAgICAgICAge2lzTm90ZSA/IChcbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxkaXYgc3R5bGU9e2ZsfT5Ob3RlIGNvbG9yPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBmbGV4V3JhcDogJ3dyYXAnLCBnYXA6IDcsIG1hcmdpblRvcDogOCB9fT5cbiAgICAgICAgICAgICAgICB7Tk9URV9DT0xPUlMubWFwKChjKSA9PiAoXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIGtleT17Y31cbiAgICAgICAgICAgICAgICAgICAgdGl0bGU9e2N9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHdiLnBhdGNoU2VsKHsgY29sb3I6IGMgfSl9XG4gICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDMwLFxuICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogMzAsXG4gICAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiA4LFxuICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IGB2YXIoLS1uLSR7Y30pYCxcbiAgICAgICAgICAgICAgICAgICAgICBib3JkZXI6IHNlbC5jb2xvciA9PT0gYyA/ICcycHggc29saWQgdmFyKC0taW5rKScgOiAnMXB4IHNvbGlkIHJnYmEoMCwwLDAsLjE1KScsXG4gICAgICAgICAgICAgICAgICAgICAgY3Vyc29yOiAncG9pbnRlcicsXG4gICAgICAgICAgICAgICAgICAgICAgYm94U2hhZG93OiBzZWwuY29sb3IgPT09IGMgPyAnMCAwIDAgMnB4IHZhcigtLWJnKSwgMCAwIDAgM3B4IHZhcigtLWFjY2VudCknIDogJ25vbmUnLFxuICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApIDogbnVsbH1cbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6ICdncmlkJywgZ3JpZFRlbXBsYXRlQ29sdW1uczogJzFmciAxZnInLCBnYXA6IDEwIH19PlxuICAgICAgICAgICAgPEZpZWxkIGxhYmVsPVwiWFwiPlxuICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cIm51bWJlclwiIHZhbHVlPXtNYXRoLnJvdW5kKHNlbC54KX0gb25DaGFuZ2U9eyhlKSA9PiB3Yi5wYXRjaFNlbCh7IHg6ICtlLnRhcmdldC52YWx1ZSB9KX0gc3R5bGU9e2lucH0gLz5cbiAgICAgICAgICAgIDwvRmllbGQ+XG4gICAgICAgICAgICA8RmllbGQgbGFiZWw9XCJZXCI+XG4gICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwibnVtYmVyXCIgdmFsdWU9e01hdGgucm91bmQoc2VsLnkpfSBvbkNoYW5nZT17KGUpID0+IHdiLnBhdGNoU2VsKHsgeTogK2UudGFyZ2V0LnZhbHVlIH0pfSBzdHlsZT17aW5wfSAvPlxuICAgICAgICAgICAgPC9GaWVsZD5cbiAgICAgICAgICAgIDxGaWVsZCBsYWJlbD1cIldcIj5cbiAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJudW1iZXJcIiB2YWx1ZT17TWF0aC5yb3VuZChzZWwudyl9IG9uQ2hhbmdlPXsoZSkgPT4gd2IucGF0Y2hTZWwoeyB3OiArZS50YXJnZXQudmFsdWUgfSl9IHN0eWxlPXtpbnB9IC8+XG4gICAgICAgICAgICA8L0ZpZWxkPlxuICAgICAgICAgICAgPEZpZWxkIGxhYmVsPVwiSFwiPlxuICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cIm51bWJlclwiIHZhbHVlPXtNYXRoLnJvdW5kKHNlbC5oKX0gb25DaGFuZ2U9eyhlKSA9PiB3Yi5wYXRjaFNlbCh7IGg6ICtlLnRhcmdldC52YWx1ZSB9KX0gc3R5bGU9e2lucH0gLz5cbiAgICAgICAgICAgIDwvRmllbGQ+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPEZpZWxkIGxhYmVsPVwiUm90YXRpb25cIj5cbiAgICAgICAgICAgIHsvKiBUaGUgc2FtZSB0cmFuc2Zvcm0gdGhlIHJvdGF0ZSBoYW5kbGUgZHJhZ3MgKFIzLTYwNyk6IG9uZSBhY3Rpb24sXG4gICAgICAgICAgICAgICAgdHdvIHRyaWdnZXJzIOKAlCB0aGUgZmllbGQgYW5kIHRoZSBoYW5kbGUgYm90aCB3cml0ZSBgcm90YC4gKi99XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXG4gICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJSb3RhdGlvbiBpbiBkZWdyZWVzXCJcbiAgICAgICAgICAgICAgdmFsdWU9e01hdGgucm91bmQoc2VsLnJvdCB8fCAwKX1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB3Yi5wYXRjaFNlbCh7IHJvdDogK2UudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICBzdHlsZT17aW5wfVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L0ZpZWxkPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9e3diLmJlZ2luQ29ubmVjdH1cbiAgICAgICAgICAgIGRpc2FibGVkPXtzZWxlY3Rpb24ubGVuZ3RoICE9PSAxfVxuICAgICAgICAgICAgdGl0bGU9e3NlbGVjdGlvbi5sZW5ndGggIT09IDEgPyAnQ29ubmVjdCBuZWVkcyBleGFjdGx5IG9uZSBvYmplY3Qgc2VsZWN0ZWQnIDogJ0Fycm93cyBwaWNrIHRoZSB0YXJnZXQgwrcgRW50ZXIgY29ubmVjdHMgwrcgRXNjYXBlIGNhbmNlbHMnfVxuICAgICAgICAgICAgc3R5bGU9e3NlbGVjdGlvbi5sZW5ndGggIT09IDEgPyB7IC4uLmJ0bkdob3N0LCBvcGFjaXR5OiAwLjU1LCBjdXJzb3I6ICdkZWZhdWx0JyB9IDogYnRuR2hvc3R9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPEljb24gbmFtZT1cInJlZnJlc2hcIiBzaXplPXsxNH0gc3Ryb2tlV2lkdGg9ezEuNzV9IC8+XG4gICAgICAgICAgICBDb25uZWN0IGZyb20gaGVyZeKAplxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXtmbH0+U3RhY2tpbmc8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBnYXA6IDYsIG1hcmdpblRvcDogNyB9fT5cbiAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiB3Yi5wYXRjaFNlbCh7IHo6IChzZWwueiB8fCAwKSArIDEgfSl9IHN0eWxlPXtzZWcoZmFsc2UpfT5cbiAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiYXJyb3dVcFwiIHNpemU9ezE0fSBzdHJva2VXaWR0aD17MS43NX0gLz5cbiAgICAgICAgICAgICAgICBVcFxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiB3Yi5wYXRjaFNlbCh7IHo6IE1hdGgubWF4KDAsIChzZWwueiB8fCAwKSAtIDEpIH0pfSBzdHlsZT17c2VnKGZhbHNlKX0+XG4gICAgICAgICAgICAgICAgPEljb24gbmFtZT1cImFycm93RG93blwiIHNpemU9ezE0fSBzdHJva2VXaWR0aD17MS43NX0gLz5cbiAgICAgICAgICAgICAgICBEb3duXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHdiLnBhdGNoU2VsKHsgejogOTkgfSl9IHN0eWxlPXtzZWcoZmFsc2UpfT5cbiAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiYnJpbmdGcm9udFwiIHNpemU9ezE0fSBzdHJva2VXaWR0aD17MS41fSAvPlxuICAgICAgICAgICAgICAgIEZyb250XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGdhcDogOCB9fT5cbiAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gd2IucGF0Y2hTZWwoeyBsb2NrZWQ6ICFzZWwubG9ja2VkIH0pfSBzdHlsZT17dG9nZ2xlQnRuKCEhc2VsLmxvY2tlZCl9PlxuICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwibG9ja1wiIHNpemU9ezE0fSBzdHJva2VXaWR0aD17MS43NX0gLz5cbiAgICAgICAgICAgICAge3NlbC5sb2NrZWQgPyAnTG9ja2VkJyA6ICdMb2NrJ31cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiB3Yi5wYXRjaFNlbCh7IGhpZGRlbjogIXNlbC5oaWRkZW4gfSl9IHN0eWxlPXt0b2dnbGVCdG4oISFzZWwuaGlkZGVuKX0+XG4gICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJleWVPZmZcIiBzaXplPXsxNH0gc3Ryb2tlV2lkdGg9ezEuNzV9IC8+XG4gICAgICAgICAgICAgIHtzZWwuaGlkZGVuID8gJ0hpZGRlbicgOiAnSGlkZSd9XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHdiLnRvYXN0KGBPcGVuaW5nICR7c2VsLmlkfS5tZHggaW4gZWRpdC1maWxl4oCmYCwgJ3BlbmNpbCcpfSBzdHlsZT17YnRuR2hvc3R9PlxuICAgICAgICAgICAgPEljb24gbmFtZT1cInBlbmNpbFwiIHNpemU9ezE0fSBzdHJva2VXaWR0aD17MS43NX0gLz5cbiAgICAgICAgICAgIE9wZW4gc291cmNlXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXt3Yi5kZWxldGVTZWxlY3Rpb259IHN0eWxlPXtidG5EYW5nZXJ9PlxuICAgICAgICAgICAgPEljb24gbmFtZT1cInRyYXNoXCIgc2l6ZT17MTR9IHN0cm9rZVdpZHRoPXsxLjc1fSAvPlxuICAgICAgICAgICAgRGVsZXRlXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgKTtcbiAgfVxuXG4gIGNvbnN0IHdyYXBTdHlsZTogUmVhY3QuQ1NTUHJvcGVydGllcyA9IG1vYmlsZVxuICAgID8ge1xuICAgICAgICBwb3NpdGlvbjogJ2Fic29sdXRlJyxcbiAgICAgICAgbGVmdDogMCxcbiAgICAgICAgcmlnaHQ6IDAsXG4gICAgICAgIGJvdHRvbTogMCxcbiAgICAgICAgbWF4SGVpZ2h0OiAnNjQlJyxcbiAgICAgICAgYmFja2dyb3VuZDogJ2NvbG9yLW1peChpbiBva2xhYiwgdmFyKC0tcGFuZWwpIDk3JSwgdHJhbnNwYXJlbnQpJyxcbiAgICAgICAgYm9yZGVyVG9wOiAnMXB4IHNvbGlkIHZhcigtLWxpbmUtMiknLFxuICAgICAgICBib3JkZXJSYWRpdXM6ICcxOHB4IDE4cHggMCAwJyxcbiAgICAgICAgekluZGV4OiA0NixcbiAgICAgICAgYmFja2Ryb3BGaWx0ZXI6ICdibHVyKDE0cHgpJyxcbiAgICAgICAgYm94U2hhZG93OiAnMCAtMTJweCAzNHB4IHJnYmEoMCwwLDAsLjQpJyxcbiAgICAgICAgb3ZlcmZsb3dZOiAnYXV0bycsXG4gICAgICAgIGRpc3BsYXk6ICdmbGV4JyxcbiAgICAgICAgZmxleERpcmVjdGlvbjogJ2NvbHVtbicsXG4gICAgICB9XG4gICAgOiB7XG4gICAgICAgIHBvc2l0aW9uOiAnYWJzb2x1dGUnLFxuICAgICAgICB0b3A6IDcyLFxuICAgICAgICByaWdodDogMTYsXG4gICAgICAgIGJvdHRvbTogMTYsXG4gICAgICAgIHdpZHRoOiAzMTIsXG4gICAgICAgIGJhY2tncm91bmQ6ICdjb2xvci1taXgoaW4gb2tsYWIsIHZhcigtLXBhbmVsKSA5NCUsIHRyYW5zcGFyZW50KScsXG4gICAgICAgIGJvcmRlcjogJzFweCBzb2xpZCB2YXIoLS1saW5lKScsXG4gICAgICAgIGJvcmRlclJhZGl1czogJ3ZhcigtLXIteGwpJyxcbiAgICAgICAgekluZGV4OiAzOCxcbiAgICAgICAgYmFja2Ryb3BGaWx0ZXI6ICdibHVyKDE0cHgpJyxcbiAgICAgICAgYm94U2hhZG93OiAndmFyKC0tc2hhZG93LXBvcCknLFxuICAgICAgICBvdmVyZmxvd1k6ICdhdXRvJyxcbiAgICAgICAgZGlzcGxheTogJ2ZsZXgnLFxuICAgICAgICBmbGV4RGlyZWN0aW9uOiAnY29sdW1uJyxcbiAgICAgIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIndiLXNjcm9sbFwiIHN0eWxlPXt3cmFwU3R5bGV9PlxuICAgICAge2JvZHl9XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IEluc3BlY3RvcjtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBTUEsSUFBQUEsZUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsS0FBQSxHQUFBQyxzQkFBQSxDQUFBRixPQUFBO0FBQ0EsSUFBQUcsVUFBQSxHQUFBSCxPQUFBO0FBQWdELElBQUFJLFdBQUEsR0FBQUosT0FBQTtBQUFBLElBQUFLLEVBQUEsR0FBQUMsWUFBQSxJQVJoRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQUEsU0FBQUosdUJBQUFLLENBQUEsV0FBQUEsQ0FBQSxJQUFBQSxDQUFBLENBQUFDLFVBQUEsR0FBQUQsQ0FBQSxLQUFBRSxPQUFBLEVBQUFGLENBQUE7QUFPQSxNQUFNRyxFQUF1QixHQUFHO0VBQUVDLElBQUksRUFBRSxnQkFBZ0I7RUFBRUMsYUFBYSxFQUFFLE9BQU87RUFBRUMsYUFBYSxFQUFFLFdBQVc7RUFBRUMsS0FBSyxFQUFFO0FBQWUsQ0FBQztBQUNySSxNQUFNQyxHQUF3QixHQUFHO0VBQUVDLEtBQUssRUFBRSxNQUFNO0VBQUVDLE9BQU8sRUFBRSxVQUFVO0VBQUVDLFVBQVUsRUFBRSxXQUFXO0VBQUVDLE1BQU0sRUFBRSx5QkFBeUI7RUFBRUMsWUFBWSxFQUFFLENBQUM7RUFBRU4sS0FBSyxFQUFFLFlBQVk7RUFBRUgsSUFBSSxFQUFFO0FBQWlCLENBQUM7QUFDak0sTUFBTVUsR0FBRyxHQUFJQyxFQUFXLEtBQTJCO0VBQ2pEQyxJQUFJLEVBQUUsQ0FBQztFQUNQQyxPQUFPLEVBQUUsTUFBTTtFQUNmQyxVQUFVLEVBQUUsUUFBUTtFQUNwQkMsY0FBYyxFQUFFLFFBQVE7RUFDeEJDLEdBQUcsRUFBRSxDQUFDO0VBQ05WLE9BQU8sRUFBRSxTQUFTO0VBQ2xCQyxVQUFVLEVBQUVJLEVBQUUsR0FBRyx3REFBd0QsR0FBRyxXQUFXO0VBQ3ZGSCxNQUFNLEVBQUUsYUFBYUcsRUFBRSxHQUFHLHlEQUF5RCxHQUFHLGVBQWUsRUFBRTtFQUN2R0YsWUFBWSxFQUFFLENBQUM7RUFDZk4sS0FBSyxFQUFFLFlBQVk7RUFDbkJILElBQUksRUFBRSxnQkFBZ0I7RUFDdEJpQixNQUFNLEVBQUUsU0FBUztFQUNqQmYsYUFBYSxFQUFFO0FBQ2pCLENBQUMsQ0FBQztBQUNGLE1BQU1nQixTQUFTLEdBQUlQLEVBQVcsS0FBMkI7RUFDdkRDLElBQUksRUFBRSxDQUFDO0VBQ1BDLE9BQU8sRUFBRSxNQUFNO0VBQ2ZDLFVBQVUsRUFBRSxRQUFRO0VBQ3BCQyxjQUFjLEVBQUUsUUFBUTtFQUN4QkMsR0FBRyxFQUFFLENBQUM7RUFDTlYsT0FBTyxFQUFFLENBQUM7RUFDVkMsVUFBVSxFQUFFSSxFQUFFLEdBQUcsc0RBQXNELEdBQUcsV0FBVztFQUNyRkgsTUFBTSxFQUFFLGFBQWFHLEVBQUUsR0FBRyx1REFBdUQsR0FBRyxlQUFlLEVBQUU7RUFDckdGLFlBQVksRUFBRSxDQUFDO0VBQ2ZOLEtBQUssRUFBRSxZQUFZO0VBQ25CSCxJQUFJLEVBQUUsY0FBYztFQUNwQmlCLE1BQU0sRUFBRTtBQUNWLENBQUMsQ0FBQztBQUNGLE1BQU1FLFFBQTZCLEdBQUc7RUFBRU4sT0FBTyxFQUFFLE1BQU07RUFBRUMsVUFBVSxFQUFFLFFBQVE7RUFBRUMsY0FBYyxFQUFFLFFBQVE7RUFBRUMsR0FBRyxFQUFFLENBQUM7RUFBRVYsT0FBTyxFQUFFLEVBQUU7RUFBRUMsVUFBVSxFQUFFLFdBQVc7RUFBRUMsTUFBTSxFQUFFLHlCQUF5QjtFQUFFQyxZQUFZLEVBQUUsQ0FBQztFQUFFTixLQUFLLEVBQUUsWUFBWTtFQUFFSCxJQUFJLEVBQUUsY0FBYztFQUFFaUIsTUFBTSxFQUFFO0FBQVUsQ0FBQztBQUN6USxNQUFNRyxTQUE4QixHQUFHO0VBQUVQLE9BQU8sRUFBRSxNQUFNO0VBQUVDLFVBQVUsRUFBRSxRQUFRO0VBQUVDLGNBQWMsRUFBRSxRQUFRO0VBQUVDLEdBQUcsRUFBRSxDQUFDO0VBQUVWLE9BQU8sRUFBRSxFQUFFO0VBQUVDLFVBQVUsRUFBRSxnREFBZ0Q7RUFBRUMsTUFBTSxFQUFFLHlEQUF5RDtFQUFFQyxZQUFZLEVBQUUsQ0FBQztFQUFFTixLQUFLLEVBQUUsU0FBUztFQUFFSCxJQUFJLEVBQUUsY0FBYztFQUFFaUIsTUFBTSxFQUFFO0FBQVUsQ0FBQztBQUU1VSxTQUFTSSxLQUFLQSxDQUFDO0VBQUVDLEtBQUs7RUFBRUM7QUFBdUQsQ0FBQyxFQUFFO0VBQ2hGLG9CQUNFLElBQUE5QixXQUFBLENBQUErQixJQUFBO0lBQU9DLEtBQUssRUFBRTtNQUFFWixPQUFPLEVBQUU7SUFBUSxDQUFFO0lBQUFVLFFBQUEsZ0JBQ2pDLElBQUE5QixXQUFBLENBQUFpQyxHQUFBO01BQUtELEtBQUssRUFBRTFCLEVBQUc7TUFBQXdCLFFBQUEsRUFBRUQ7SUFBSyxDQUFNLENBQUMsZUFDN0IsSUFBQTdCLFdBQUEsQ0FBQWlDLEdBQUE7TUFBS0QsS0FBSyxFQUFFO1FBQUVFLFNBQVMsRUFBRTtNQUFFLENBQUU7TUFBQUosUUFBQSxFQUFFQTtJQUFRLENBQU0sQ0FBQztFQUFBLENBQ3pDLENBQUM7QUFFWjtBQUFDSyxFQUFBLEdBUFFQLEtBQUs7QUFTZCxTQUFTUSxTQUFTQSxDQUFBLEVBQUc7RUFBQW5DLEVBQUE7RUFDbkIsTUFBTW9DLEVBQUUsR0FBRyxJQUFBQyxxQkFBSyxFQUFDLENBQUM7RUFDbEIsTUFBTTtJQUFFQyxhQUFhO0lBQUVDLFNBQVM7SUFBRUMsT0FBTztJQUFFQyxLQUFLO0lBQUVDLFFBQVE7SUFBRUMsRUFBRTtJQUFFQztFQUFNLENBQUMsR0FBR1IsRUFBRSxDQUFDUyxLQUFLO0VBQ2xGLElBQUksQ0FBQ1AsYUFBYSxFQUFFLE9BQU8sSUFBSTtFQUMvQixNQUFNUSxNQUFNLEdBQUdWLEVBQUUsQ0FBQ1csUUFBUSxDQUFDLENBQUM7RUFFNUIsTUFBTUMsSUFBSSxHQUFHQSxDQUFDQyxLQUFhLEVBQUVDLEdBQVcsa0JBQ3RDLElBQUFuRCxXQUFBLENBQUErQixJQUFBO0lBQUtDLEtBQUssRUFBRTtNQUFFWixPQUFPLEVBQUUsTUFBTTtNQUFFQyxVQUFVLEVBQUUsUUFBUTtNQUFFQyxjQUFjLEVBQUUsZUFBZTtNQUFFVCxPQUFPLEVBQUUsZ0JBQWdCO01BQUV1QyxZQUFZLEVBQUU7SUFBd0IsQ0FBRTtJQUFBdEIsUUFBQSxnQkFDdkosSUFBQTlCLFdBQUEsQ0FBQStCLElBQUE7TUFBQUQsUUFBQSxnQkFDRSxJQUFBOUIsV0FBQSxDQUFBaUMsR0FBQTtRQUFLRCxLQUFLLEVBQUU7VUFBRXpCLElBQUksRUFBRSx3QkFBd0I7VUFBRUcsS0FBSyxFQUFFLFlBQVk7VUFBRUQsYUFBYSxFQUFFO1FBQWEsQ0FBRTtRQUFBcUIsUUFBQSxFQUFFb0I7TUFBSyxDQUFNLENBQUMsZUFDL0csSUFBQWxELFdBQUEsQ0FBQWlDLEdBQUE7UUFBS0QsS0FBSyxFQUFFO1VBQUV6QixJQUFJLEVBQUUsZ0JBQWdCO1VBQUVHLEtBQUssRUFBRSxjQUFjO1VBQUV3QixTQUFTLEVBQUU7UUFBRSxDQUFFO1FBQUFKLFFBQUEsRUFBRXFCO01BQUcsQ0FBTSxDQUFDO0lBQUEsQ0FDckYsQ0FBQyxlQUNOLElBQUFuRCxXQUFBLENBQUFpQyxHQUFBO01BQVFvQixPQUFPLEVBQUVoQixFQUFFLENBQUNpQixjQUFlO01BQUN0QixLQUFLLEVBQUU7UUFBRVosT0FBTyxFQUFFLE1BQU07UUFBRVAsT0FBTyxFQUFFLENBQUM7UUFBRUMsVUFBVSxFQUFFLE1BQU07UUFBRUMsTUFBTSxFQUFFLE1BQU07UUFBRUwsS0FBSyxFQUFFLGNBQWM7UUFBRWMsTUFBTSxFQUFFO01BQVUsQ0FBRTtNQUFBTSxRQUFBLGVBQ3ZKLElBQUE5QixXQUFBLENBQUFpQyxHQUFBLEVBQUNwQyxLQUFBLENBQUFRLE9BQUk7UUFBQ2tELElBQUksRUFBQyxHQUFHO1FBQUNDLElBQUksRUFBRTtNQUFHLENBQUU7SUFBQyxDQUNyQixDQUFDO0VBQUEsQ0FDTixDQUNOO0VBRUQsSUFBSUMsSUFBcUI7RUFDekIsTUFBTUMsR0FBbUIsR0FBR2xCLFNBQVMsQ0FBQ21CLE1BQU0sS0FBSyxDQUFDLEdBQUdsQixPQUFPLENBQUNtQixJQUFJLENBQUVDLENBQUMsSUFBS0EsQ0FBQyxDQUFDQyxFQUFFLEtBQUt0QixTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxJQUFJLEdBQUcsSUFBSTtFQUU5RyxJQUFJQSxTQUFTLENBQUNtQixNQUFNLEdBQUcsQ0FBQyxFQUFFO0lBQ3hCRixJQUFJLGdCQUNGLElBQUF6RCxXQUFBLENBQUErQixJQUFBO01BQUtDLEtBQUssRUFBRTtRQUFFbkIsT0FBTyxFQUFFLEVBQUU7UUFBRU8sT0FBTyxFQUFFLE1BQU07UUFBRTJDLGFBQWEsRUFBRSxRQUFRO1FBQUV4QyxHQUFHLEVBQUU7TUFBRyxDQUFFO01BQUFPLFFBQUEsR0FDNUVtQixJQUFJLENBQUMsR0FBR1QsU0FBUyxDQUFDbUIsTUFBTSxtQkFBbUIsRUFBRSxPQUFPLENBQUMsZUFDdEQsSUFBQTNELFdBQUEsQ0FBQStCLElBQUE7UUFBUXNCLE9BQU8sRUFBRWhCLEVBQUUsQ0FBQzJCLGVBQWdCO1FBQUNoQyxLQUFLLEVBQUVMLFNBQVU7UUFBQUcsUUFBQSxnQkFDcEQsSUFBQTlCLFdBQUEsQ0FBQWlDLEdBQUEsRUFBQ3BDLEtBQUEsQ0FBQVEsT0FBSTtVQUFDa0QsSUFBSSxFQUFDLE9BQU87VUFBQ0MsSUFBSSxFQUFFLEVBQUc7VUFBQ1MsV0FBVyxFQUFFO1FBQUssQ0FBRSxDQUFDLG9CQUVwRDtNQUFBLENBQVEsQ0FBQztJQUFBLENBQ04sQ0FDTjtFQUNILENBQUMsTUFBTSxJQUFJLENBQUNQLEdBQUcsRUFBRTtJQUNmRCxJQUFJLGdCQUNGLElBQUF6RCxXQUFBLENBQUErQixJQUFBO01BQUtDLEtBQUssRUFBRTtRQUFFWixPQUFPLEVBQUUsTUFBTTtRQUFFMkMsYUFBYSxFQUFFO01BQVMsQ0FBRTtNQUFBakMsUUFBQSxHQUN0RG1CLElBQUksQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDLGVBQ3ZCLElBQUFqRCxXQUFBLENBQUErQixJQUFBO1FBQUtDLEtBQUssRUFBRTtVQUFFbkIsT0FBTyxFQUFFLGVBQWU7VUFBRU8sT0FBTyxFQUFFLE1BQU07VUFBRTJDLGFBQWEsRUFBRSxRQUFRO1VBQUV4QyxHQUFHLEVBQUU7UUFBRyxDQUFFO1FBQUFPLFFBQUEsZ0JBQzFGLElBQUE5QixXQUFBLENBQUFpQyxHQUFBLEVBQUNMLEtBQUs7VUFBQ0MsS0FBSyxFQUFDLE9BQU87VUFBQUMsUUFBQSxlQUNsQixJQUFBOUIsV0FBQSxDQUFBaUMsR0FBQTtZQUFPaUMsWUFBWSxFQUFDLGFBQWE7WUFBQ2xDLEtBQUssRUFBRXJCO1VBQUksQ0FBRTtRQUFDLENBQzNDLENBQUMsZUFDUixJQUFBWCxXQUFBLENBQUErQixJQUFBO1VBQUFELFFBQUEsZ0JBQ0UsSUFBQTlCLFdBQUEsQ0FBQWlDLEdBQUE7WUFBS0QsS0FBSyxFQUFFMUIsRUFBRztZQUFBd0IsUUFBQSxFQUFDO1VBQVUsQ0FBSyxDQUFDLGVBQ2hDLElBQUE5QixXQUFBLENBQUFpQyxHQUFBO1lBQUtELEtBQUssRUFBRTtjQUFFWixPQUFPLEVBQUUsTUFBTTtjQUFFRyxHQUFHLEVBQUUsQ0FBQztjQUFFVyxTQUFTLEVBQUU7WUFBRSxDQUFFO1lBQUFKLFFBQUEsRUFDbEQsQ0FBQyxNQUFNLEVBQUUsTUFBTSxFQUFFLE9BQU8sQ0FBQyxDQUFrQnFDLEdBQUcsQ0FBRUMsQ0FBQyxpQkFDakQsSUFBQXBFLFdBQUEsQ0FBQWlDLEdBQUE7Y0FBZ0JvQixPQUFPLEVBQUVBLENBQUEsS0FBTWhCLEVBQUUsQ0FBQ2dDLGFBQWEsQ0FBQ0QsQ0FBQyxDQUFFO2NBQUNwQyxLQUFLLEVBQUVmLEdBQUcsQ0FBQzJCLEVBQUUsS0FBS3dCLENBQUMsQ0FBRTtjQUFBdEMsUUFBQSxFQUN0RXNDO1lBQUMsR0FEU0EsQ0FFTCxDQUNUO1VBQUMsQ0FDQyxDQUFDO1FBQUEsQ0FDSCxDQUFDLGVBQ04sSUFBQXBFLFdBQUEsQ0FBQStCLElBQUE7VUFBQUQsUUFBQSxnQkFDRSxJQUFBOUIsV0FBQSxDQUFBaUMsR0FBQTtZQUFLRCxLQUFLLEVBQUUxQixFQUFHO1lBQUF3QixRQUFBLEVBQUM7VUFBSyxDQUFLLENBQUMsZUFDM0IsSUFBQTlCLFdBQUEsQ0FBQWlDLEdBQUE7WUFBS0QsS0FBSyxFQUFFO2NBQUVaLE9BQU8sRUFBRSxNQUFNO2NBQUVHLEdBQUcsRUFBRSxDQUFDO2NBQUVXLFNBQVMsRUFBRTtZQUFFLENBQUU7WUFBQUosUUFBQSxFQUNsRCxDQUFDLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQXlCcUMsR0FBRyxDQUFDLENBQUMsQ0FBQ0csR0FBRyxFQUFFQyxDQUFDLENBQUMsa0JBQ3hFLElBQUF2RSxXQUFBLENBQUFpQyxHQUFBO2NBQWtCb0IsT0FBTyxFQUFFQSxDQUFBLEtBQU1oQixFQUFFLENBQUNtQyxRQUFRLENBQUNELENBQUMsQ0FBRTtjQUFDdkMsS0FBSyxFQUFFZixHQUFHLENBQUM0QixLQUFLLEtBQUswQixDQUFDLENBQUU7Y0FBQXpDLFFBQUEsRUFDdEV3QztZQUFHLEdBRE9BLEdBRUwsQ0FDVDtVQUFDLENBQ0MsQ0FBQztRQUFBLENBQ0gsQ0FBQyxlQUNOLElBQUF0RSxXQUFBLENBQUFpQyxHQUFBO1VBQUtELEtBQUssRUFBRTtZQUFFekIsSUFBSSxFQUFFLGdCQUFnQjtZQUFFRyxLQUFLLEVBQUUsY0FBYztZQUFFK0QsVUFBVSxFQUFFLEdBQUc7WUFBRUMsVUFBVSxFQUFFLENBQUM7WUFBRUMsU0FBUyxFQUFFO1VBQXdCLENBQUU7VUFBQTdDLFFBQUEsRUFDL0gsR0FBR1csT0FBTyxDQUFDa0IsTUFBTSxjQUFjakIsS0FBSyxDQUFDaUIsTUFBTSxZQUFZaEIsUUFBUSxDQUFDZ0IsTUFBTTtRQUFXLENBQy9FLENBQUM7TUFBQSxDQUNILENBQUM7SUFBQSxDQUNILENBQ047RUFDSCxDQUFDLE1BQU07SUFDTCxNQUFNaUIsTUFBTSxHQUFHbEIsR0FBRyxDQUFDbUIsSUFBSSxLQUFLLE1BQU07SUFDbENwQixJQUFJLGdCQUNGLElBQUF6RCxXQUFBLENBQUErQixJQUFBO01BQUtDLEtBQUssRUFBRTtRQUFFWixPQUFPLEVBQUUsTUFBTTtRQUFFMkMsYUFBYSxFQUFFO01BQVMsQ0FBRTtNQUFBakMsUUFBQSxHQUN0RG1CLElBQUksQ0FBQ1MsR0FBRyxDQUFDbUIsSUFBSSxFQUFFbkIsR0FBRyxDQUFDSSxFQUFFLENBQUMsZUFDdkIsSUFBQTlELFdBQUEsQ0FBQStCLElBQUE7UUFBS0MsS0FBSyxFQUFFO1VBQUVuQixPQUFPLEVBQUUsZUFBZTtVQUFFTyxPQUFPLEVBQUUsTUFBTTtVQUFFMkMsYUFBYSxFQUFFLFFBQVE7VUFBRXhDLEdBQUcsRUFBRTtRQUFHLENBQUU7UUFBQU8sUUFBQSxnQkFDMUYsSUFBQTlCLFdBQUEsQ0FBQWlDLEdBQUEsRUFBQ0wsS0FBSztVQUFDQyxLQUFLLEVBQUMsT0FBTztVQUFBQyxRQUFBLGVBQ2xCLElBQUE5QixXQUFBLENBQUFpQyxHQUFBO1lBQU82QyxLQUFLLEVBQUVwQixHQUFHLENBQUNSLEtBQUssSUFBSSxFQUFHO1lBQUM2QixRQUFRLEVBQUc1RSxDQUFDLElBQUtrQyxFQUFFLENBQUMyQyxRQUFRLENBQUM7Y0FBRTlCLEtBQUssRUFBRS9DLENBQUMsQ0FBQzhFLE1BQU0sQ0FBQ0g7WUFBTSxDQUFDLENBQUU7WUFBQzlDLEtBQUssRUFBRXJCO1VBQUksQ0FBRTtRQUFDLENBQ2pHLENBQUMsZUFDUixJQUFBWCxXQUFBLENBQUFpQyxHQUFBLEVBQUNMLEtBQUs7VUFBQ0MsS0FBSyxFQUFDLE1BQU07VUFBQUMsUUFBQSxlQUNqQixJQUFBOUIsV0FBQSxDQUFBaUMsR0FBQTtZQUFPNkMsS0FBSyxFQUFFcEIsR0FBRyxDQUFDd0IsSUFBSSxJQUFJLEVBQUc7WUFBQ0MsV0FBVyxFQUFDLGtCQUFrQjtZQUFDSixRQUFRLEVBQUc1RSxDQUFDLElBQUtrQyxFQUFFLENBQUMyQyxRQUFRLENBQUM7Y0FBRUUsSUFBSSxFQUFFL0UsQ0FBQyxDQUFDOEUsTUFBTSxDQUFDSDtZQUFNLENBQUMsQ0FBRTtZQUFDOUMsS0FBSyxFQUFFckI7VUFBSSxDQUFFO1FBQUMsQ0FDOUgsQ0FBQyxFQUNQaUUsTUFBTSxnQkFDTCxJQUFBNUUsV0FBQSxDQUFBK0IsSUFBQTtVQUFBRCxRQUFBLGdCQUNFLElBQUE5QixXQUFBLENBQUFpQyxHQUFBO1lBQUtELEtBQUssRUFBRTFCLEVBQUc7WUFBQXdCLFFBQUEsRUFBQztVQUFVLENBQUssQ0FBQyxlQUNoQyxJQUFBOUIsV0FBQSxDQUFBaUMsR0FBQTtZQUFLRCxLQUFLLEVBQUU7Y0FBRVosT0FBTyxFQUFFLE1BQU07Y0FBRWdFLFFBQVEsRUFBRSxNQUFNO2NBQUU3RCxHQUFHLEVBQUUsQ0FBQztjQUFFVyxTQUFTLEVBQUU7WUFBRSxDQUFFO1lBQUFKLFFBQUEsRUFDckV1RCxzQkFBVyxDQUFDbEIsR0FBRyxDQUFFbUIsQ0FBQyxpQkFDakIsSUFBQXRGLFdBQUEsQ0FBQWlDLEdBQUE7Y0FFRWlCLEtBQUssRUFBRW9DLENBQUU7Y0FDVGpDLE9BQU8sRUFBRUEsQ0FBQSxLQUFNaEIsRUFBRSxDQUFDMkMsUUFBUSxDQUFDO2dCQUFFdEUsS0FBSyxFQUFFNEU7Y0FBRSxDQUFDLENBQUU7Y0FDekN0RCxLQUFLLEVBQUU7Z0JBQ0xwQixLQUFLLEVBQUUsRUFBRTtnQkFDVDJFLE1BQU0sRUFBRSxFQUFFO2dCQUNWdkUsWUFBWSxFQUFFLENBQUM7Z0JBQ2ZGLFVBQVUsRUFBRSxXQUFXd0UsQ0FBQyxHQUFHO2dCQUMzQnZFLE1BQU0sRUFBRTJDLEdBQUcsQ0FBQ2hELEtBQUssS0FBSzRFLENBQUMsR0FBRyxzQkFBc0IsR0FBRywyQkFBMkI7Z0JBQzlFOUQsTUFBTSxFQUFFLFNBQVM7Z0JBQ2pCZ0UsU0FBUyxFQUFFOUIsR0FBRyxDQUFDaEQsS0FBSyxLQUFLNEUsQ0FBQyxHQUFHLDhDQUE4QyxHQUFHO2NBQ2hGO1lBQUUsR0FYR0EsQ0FZTixDQUNGO1VBQUMsQ0FDQyxDQUFDO1FBQUEsQ0FDSCxDQUFDLEdBQ0osSUFBSSxlQUNSLElBQUF0RixXQUFBLENBQUErQixJQUFBO1VBQUtDLEtBQUssRUFBRTtZQUFFWixPQUFPLEVBQUUsTUFBTTtZQUFFcUUsbUJBQW1CLEVBQUUsU0FBUztZQUFFbEUsR0FBRyxFQUFFO1VBQUcsQ0FBRTtVQUFBTyxRQUFBLGdCQUN2RSxJQUFBOUIsV0FBQSxDQUFBaUMsR0FBQSxFQUFDTCxLQUFLO1lBQUNDLEtBQUssRUFBQyxHQUFHO1lBQUFDLFFBQUEsZUFDZCxJQUFBOUIsV0FBQSxDQUFBaUMsR0FBQTtjQUFPeUQsSUFBSSxFQUFDLFFBQVE7Y0FBQ1osS0FBSyxFQUFFYSxJQUFJLENBQUNDLEtBQUssQ0FBQ2xDLEdBQUcsQ0FBQ21DLENBQUMsQ0FBRTtjQUFDZCxRQUFRLEVBQUc1RSxDQUFDLElBQUtrQyxFQUFFLENBQUMyQyxRQUFRLENBQUM7Z0JBQUVhLENBQUMsRUFBRSxDQUFDMUYsQ0FBQyxDQUFDOEUsTUFBTSxDQUFDSDtjQUFNLENBQUMsQ0FBRTtjQUFDOUMsS0FBSyxFQUFFckI7WUFBSSxDQUFFO1VBQUMsQ0FDOUcsQ0FBQyxlQUNSLElBQUFYLFdBQUEsQ0FBQWlDLEdBQUEsRUFBQ0wsS0FBSztZQUFDQyxLQUFLLEVBQUMsR0FBRztZQUFBQyxRQUFBLGVBQ2QsSUFBQTlCLFdBQUEsQ0FBQWlDLEdBQUE7Y0FBT3lELElBQUksRUFBQyxRQUFRO2NBQUNaLEtBQUssRUFBRWEsSUFBSSxDQUFDQyxLQUFLLENBQUNsQyxHQUFHLENBQUNvQyxDQUFDLENBQUU7Y0FBQ2YsUUFBUSxFQUFHNUUsQ0FBQyxJQUFLa0MsRUFBRSxDQUFDMkMsUUFBUSxDQUFDO2dCQUFFYyxDQUFDLEVBQUUsQ0FBQzNGLENBQUMsQ0FBQzhFLE1BQU0sQ0FBQ0g7Y0FBTSxDQUFDLENBQUU7Y0FBQzlDLEtBQUssRUFBRXJCO1lBQUksQ0FBRTtVQUFDLENBQzlHLENBQUMsZUFDUixJQUFBWCxXQUFBLENBQUFpQyxHQUFBLEVBQUNMLEtBQUs7WUFBQ0MsS0FBSyxFQUFDLEdBQUc7WUFBQUMsUUFBQSxlQUNkLElBQUE5QixXQUFBLENBQUFpQyxHQUFBO2NBQU95RCxJQUFJLEVBQUMsUUFBUTtjQUFDWixLQUFLLEVBQUVhLElBQUksQ0FBQ0MsS0FBSyxDQUFDbEMsR0FBRyxDQUFDcUMsQ0FBQyxDQUFFO2NBQUNoQixRQUFRLEVBQUc1RSxDQUFDLElBQUtrQyxFQUFFLENBQUMyQyxRQUFRLENBQUM7Z0JBQUVlLENBQUMsRUFBRSxDQUFDNUYsQ0FBQyxDQUFDOEUsTUFBTSxDQUFDSDtjQUFNLENBQUMsQ0FBRTtjQUFDOUMsS0FBSyxFQUFFckI7WUFBSSxDQUFFO1VBQUMsQ0FDOUcsQ0FBQyxlQUNSLElBQUFYLFdBQUEsQ0FBQWlDLEdBQUEsRUFBQ0wsS0FBSztZQUFDQyxLQUFLLEVBQUMsR0FBRztZQUFBQyxRQUFBLGVBQ2QsSUFBQTlCLFdBQUEsQ0FBQWlDLEdBQUE7Y0FBT3lELElBQUksRUFBQyxRQUFRO2NBQUNaLEtBQUssRUFBRWEsSUFBSSxDQUFDQyxLQUFLLENBQUNsQyxHQUFHLENBQUNzQyxDQUFDLENBQUU7Y0FBQ2pCLFFBQVEsRUFBRzVFLENBQUMsSUFBS2tDLEVBQUUsQ0FBQzJDLFFBQVEsQ0FBQztnQkFBRWdCLENBQUMsRUFBRSxDQUFDN0YsQ0FBQyxDQUFDOEUsTUFBTSxDQUFDSDtjQUFNLENBQUMsQ0FBRTtjQUFDOUMsS0FBSyxFQUFFckI7WUFBSSxDQUFFO1VBQUMsQ0FDOUcsQ0FBQztRQUFBLENBQ0wsQ0FBQyxlQUNOLElBQUFYLFdBQUEsQ0FBQWlDLEdBQUEsRUFBQ0wsS0FBSztVQUFDQyxLQUFLLEVBQUMsVUFBVTtVQUFBQyxRQUFBLGVBR3JCLElBQUE5QixXQUFBLENBQUFpQyxHQUFBO1lBQ0V5RCxJQUFJLEVBQUMsUUFBUTtZQUNiLGNBQVcscUJBQXFCO1lBQ2hDWixLQUFLLEVBQUVhLElBQUksQ0FBQ0MsS0FBSyxDQUFDbEMsR0FBRyxDQUFDdUMsR0FBRyxJQUFJLENBQUMsQ0FBRTtZQUNoQ2xCLFFBQVEsRUFBRzVFLENBQUMsSUFBS2tDLEVBQUUsQ0FBQzJDLFFBQVEsQ0FBQztjQUFFaUIsR0FBRyxFQUFFLENBQUM5RixDQUFDLENBQUM4RSxNQUFNLENBQUNIO1lBQU0sQ0FBQyxDQUFFO1lBQ3ZEOUMsS0FBSyxFQUFFckI7VUFBSSxDQUNaO1FBQUMsQ0FDRyxDQUFDLGVBQ1IsSUFBQVgsV0FBQSxDQUFBK0IsSUFBQTtVQUNFc0IsT0FBTyxFQUFFaEIsRUFBRSxDQUFDNkQsWUFBYTtVQUN6QkMsUUFBUSxFQUFFM0QsU0FBUyxDQUFDbUIsTUFBTSxLQUFLLENBQUU7VUFDakNULEtBQUssRUFBRVYsU0FBUyxDQUFDbUIsTUFBTSxLQUFLLENBQUMsR0FBRywyQ0FBMkMsR0FBRywwREFBMkQ7VUFDekkzQixLQUFLLEVBQUVRLFNBQVMsQ0FBQ21CLE1BQU0sS0FBSyxDQUFDLEdBQUc7WUFBRSxHQUFHakMsUUFBUTtZQUFFMEUsT0FBTyxFQUFFLElBQUk7WUFBRTVFLE1BQU0sRUFBRTtVQUFVLENBQUMsR0FBR0UsUUFBUztVQUFBSSxRQUFBLGdCQUU3RixJQUFBOUIsV0FBQSxDQUFBaUMsR0FBQSxFQUFDcEMsS0FBQSxDQUFBUSxPQUFJO1lBQUNrRCxJQUFJLEVBQUMsU0FBUztZQUFDQyxJQUFJLEVBQUUsRUFBRztZQUFDUyxXQUFXLEVBQUU7VUFBSyxDQUFFLENBQUMsMkJBRXREO1FBQUEsQ0FBUSxDQUFDLGVBQ1QsSUFBQWpFLFdBQUEsQ0FBQStCLElBQUE7VUFBQUQsUUFBQSxnQkFDRSxJQUFBOUIsV0FBQSxDQUFBaUMsR0FBQTtZQUFLRCxLQUFLLEVBQUUxQixFQUFHO1lBQUF3QixRQUFBLEVBQUM7VUFBUSxDQUFLLENBQUMsZUFDOUIsSUFBQTlCLFdBQUEsQ0FBQStCLElBQUE7WUFBS0MsS0FBSyxFQUFFO2NBQUVaLE9BQU8sRUFBRSxNQUFNO2NBQUVHLEdBQUcsRUFBRSxDQUFDO2NBQUVXLFNBQVMsRUFBRTtZQUFFLENBQUU7WUFBQUosUUFBQSxnQkFDcEQsSUFBQTlCLFdBQUEsQ0FBQStCLElBQUE7Y0FBUXNCLE9BQU8sRUFBRUEsQ0FBQSxLQUFNaEIsRUFBRSxDQUFDMkMsUUFBUSxDQUFDO2dCQUFFcUIsQ0FBQyxFQUFFLENBQUMzQyxHQUFHLENBQUMyQyxDQUFDLElBQUksQ0FBQyxJQUFJO2NBQUUsQ0FBQyxDQUFFO2NBQUNyRSxLQUFLLEVBQUVmLEdBQUcsQ0FBQyxLQUFLLENBQUU7Y0FBQWEsUUFBQSxnQkFDN0UsSUFBQTlCLFdBQUEsQ0FBQWlDLEdBQUEsRUFBQ3BDLEtBQUEsQ0FBQVEsT0FBSTtnQkFBQ2tELElBQUksRUFBQyxTQUFTO2dCQUFDQyxJQUFJLEVBQUUsRUFBRztnQkFBQ1MsV0FBVyxFQUFFO2NBQUssQ0FBRSxDQUFDLE1BRXREO1lBQUEsQ0FBUSxDQUFDLGVBQ1QsSUFBQWpFLFdBQUEsQ0FBQStCLElBQUE7Y0FBUXNCLE9BQU8sRUFBRUEsQ0FBQSxLQUFNaEIsRUFBRSxDQUFDMkMsUUFBUSxDQUFDO2dCQUFFcUIsQ0FBQyxFQUFFVixJQUFJLENBQUNXLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQzVDLEdBQUcsQ0FBQzJDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztjQUFFLENBQUMsQ0FBRTtjQUFDckUsS0FBSyxFQUFFZixHQUFHLENBQUMsS0FBSyxDQUFFO2NBQUFhLFFBQUEsZ0JBQzFGLElBQUE5QixXQUFBLENBQUFpQyxHQUFBLEVBQUNwQyxLQUFBLENBQUFRLE9BQUk7Z0JBQUNrRCxJQUFJLEVBQUMsV0FBVztnQkFBQ0MsSUFBSSxFQUFFLEVBQUc7Z0JBQUNTLFdBQVcsRUFBRTtjQUFLLENBQUUsQ0FBQyxRQUV4RDtZQUFBLENBQVEsQ0FBQyxlQUNULElBQUFqRSxXQUFBLENBQUErQixJQUFBO2NBQVFzQixPQUFPLEVBQUVBLENBQUEsS0FBTWhCLEVBQUUsQ0FBQzJDLFFBQVEsQ0FBQztnQkFBRXFCLENBQUMsRUFBRTtjQUFHLENBQUMsQ0FBRTtjQUFDckUsS0FBSyxFQUFFZixHQUFHLENBQUMsS0FBSyxDQUFFO2NBQUFhLFFBQUEsZ0JBQy9ELElBQUE5QixXQUFBLENBQUFpQyxHQUFBLEVBQUNwQyxLQUFBLENBQUFRLE9BQUk7Z0JBQUNrRCxJQUFJLEVBQUMsWUFBWTtnQkFBQ0MsSUFBSSxFQUFFLEVBQUc7Z0JBQUNTLFdBQVcsRUFBRTtjQUFJLENBQUUsQ0FBQyxTQUV4RDtZQUFBLENBQVEsQ0FBQztVQUFBLENBQ04sQ0FBQztRQUFBLENBQ0gsQ0FBQyxlQUNOLElBQUFqRSxXQUFBLENBQUErQixJQUFBO1VBQUtDLEtBQUssRUFBRTtZQUFFWixPQUFPLEVBQUUsTUFBTTtZQUFFRyxHQUFHLEVBQUU7VUFBRSxDQUFFO1VBQUFPLFFBQUEsZ0JBQ3RDLElBQUE5QixXQUFBLENBQUErQixJQUFBO1lBQVFzQixPQUFPLEVBQUVBLENBQUEsS0FBTWhCLEVBQUUsQ0FBQzJDLFFBQVEsQ0FBQztjQUFFdUIsTUFBTSxFQUFFLENBQUM3QyxHQUFHLENBQUM2QztZQUFPLENBQUMsQ0FBRTtZQUFDdkUsS0FBSyxFQUFFUCxTQUFTLENBQUMsQ0FBQyxDQUFDaUMsR0FBRyxDQUFDNkMsTUFBTSxDQUFFO1lBQUF6RSxRQUFBLGdCQUMxRixJQUFBOUIsV0FBQSxDQUFBaUMsR0FBQSxFQUFDcEMsS0FBQSxDQUFBUSxPQUFJO2NBQUNrRCxJQUFJLEVBQUMsTUFBTTtjQUFDQyxJQUFJLEVBQUUsRUFBRztjQUFDUyxXQUFXLEVBQUU7WUFBSyxDQUFFLENBQUMsRUFDaERQLEdBQUcsQ0FBQzZDLE1BQU0sR0FBRyxRQUFRLEdBQUcsTUFBTTtVQUFBLENBQ3pCLENBQUMsZUFDVCxJQUFBdkcsV0FBQSxDQUFBK0IsSUFBQTtZQUFRc0IsT0FBTyxFQUFFQSxDQUFBLEtBQU1oQixFQUFFLENBQUMyQyxRQUFRLENBQUM7Y0FBRXdCLE1BQU0sRUFBRSxDQUFDOUMsR0FBRyxDQUFDOEM7WUFBTyxDQUFDLENBQUU7WUFBQ3hFLEtBQUssRUFBRVAsU0FBUyxDQUFDLENBQUMsQ0FBQ2lDLEdBQUcsQ0FBQzhDLE1BQU0sQ0FBRTtZQUFBMUUsUUFBQSxnQkFDMUYsSUFBQTlCLFdBQUEsQ0FBQWlDLEdBQUEsRUFBQ3BDLEtBQUEsQ0FBQVEsT0FBSTtjQUFDa0QsSUFBSSxFQUFDLFFBQVE7Y0FBQ0MsSUFBSSxFQUFFLEVBQUc7Y0FBQ1MsV0FBVyxFQUFFO1lBQUssQ0FBRSxDQUFDLEVBQ2xEUCxHQUFHLENBQUM4QyxNQUFNLEdBQUcsUUFBUSxHQUFHLE1BQU07VUFBQSxDQUN6QixDQUFDO1FBQUEsQ0FDTixDQUFDLGVBQ04sSUFBQXhHLFdBQUEsQ0FBQStCLElBQUE7VUFBUXNCLE9BQU8sRUFBRUEsQ0FBQSxLQUFNaEIsRUFBRSxDQUFDb0UsS0FBSyxDQUFDLFdBQVcvQyxHQUFHLENBQUNJLEVBQUUsb0JBQW9CLEVBQUUsUUFBUSxDQUFFO1VBQUM5QixLQUFLLEVBQUVOLFFBQVM7VUFBQUksUUFBQSxnQkFDaEcsSUFBQTlCLFdBQUEsQ0FBQWlDLEdBQUEsRUFBQ3BDLEtBQUEsQ0FBQVEsT0FBSTtZQUFDa0QsSUFBSSxFQUFDLFFBQVE7WUFBQ0MsSUFBSSxFQUFFLEVBQUc7WUFBQ1MsV0FBVyxFQUFFO1VBQUssQ0FBRSxDQUFDLGVBRXJEO1FBQUEsQ0FBUSxDQUFDLGVBQ1QsSUFBQWpFLFdBQUEsQ0FBQStCLElBQUE7VUFBUXNCLE9BQU8sRUFBRWhCLEVBQUUsQ0FBQzJCLGVBQWdCO1VBQUNoQyxLQUFLLEVBQUVMLFNBQVU7VUFBQUcsUUFBQSxnQkFDcEQsSUFBQTlCLFdBQUEsQ0FBQWlDLEdBQUEsRUFBQ3BDLEtBQUEsQ0FBQVEsT0FBSTtZQUFDa0QsSUFBSSxFQUFDLE9BQU87WUFBQ0MsSUFBSSxFQUFFLEVBQUc7WUFBQ1MsV0FBVyxFQUFFO1VBQUssQ0FBRSxDQUFDLFVBRXBEO1FBQUEsQ0FBUSxDQUFDO01BQUEsQ0FDTixDQUFDO0lBQUEsQ0FDSCxDQUNOO0VBQ0g7RUFFQSxNQUFNeUMsU0FBOEIsR0FBRzNELE1BQU0sR0FDekM7SUFDRTRELFFBQVEsRUFBRSxVQUFVO0lBQ3BCQyxJQUFJLEVBQUUsQ0FBQztJQUNQQyxLQUFLLEVBQUUsQ0FBQztJQUNSQyxNQUFNLEVBQUUsQ0FBQztJQUNUQyxTQUFTLEVBQUUsS0FBSztJQUNoQmpHLFVBQVUsRUFBRSxvREFBb0Q7SUFDaEU2RCxTQUFTLEVBQUUseUJBQXlCO0lBQ3BDM0QsWUFBWSxFQUFFLGVBQWU7SUFDN0JnRyxNQUFNLEVBQUUsRUFBRTtJQUNWQyxjQUFjLEVBQUUsWUFBWTtJQUM1QnpCLFNBQVMsRUFBRSw2QkFBNkI7SUFDeEMwQixTQUFTLEVBQUUsTUFBTTtJQUNqQjlGLE9BQU8sRUFBRSxNQUFNO0lBQ2YyQyxhQUFhLEVBQUU7RUFDakIsQ0FBQyxHQUNEO0lBQ0U0QyxRQUFRLEVBQUUsVUFBVTtJQUNwQlEsR0FBRyxFQUFFLEVBQUU7SUFDUE4sS0FBSyxFQUFFLEVBQUU7SUFDVEMsTUFBTSxFQUFFLEVBQUU7SUFDVmxHLEtBQUssRUFBRSxHQUFHO0lBQ1ZFLFVBQVUsRUFBRSxvREFBb0Q7SUFDaEVDLE1BQU0sRUFBRSx1QkFBdUI7SUFDL0JDLFlBQVksRUFBRSxhQUFhO0lBQzNCZ0csTUFBTSxFQUFFLEVBQUU7SUFDVkMsY0FBYyxFQUFFLFlBQVk7SUFDNUJ6QixTQUFTLEVBQUUsbUJBQW1CO0lBQzlCMEIsU0FBUyxFQUFFLE1BQU07SUFDakI5RixPQUFPLEVBQUUsTUFBTTtJQUNmMkMsYUFBYSxFQUFFO0VBQ2pCLENBQUM7RUFFTCxvQkFDRSxJQUFBL0QsV0FBQSxDQUFBaUMsR0FBQTtJQUFLbUYsU0FBUyxFQUFDLFdBQVc7SUFBQ3BGLEtBQUssRUFBRTBFLFNBQVU7SUFBQTVFLFFBQUEsRUFDekMyQjtFQUFJLENBQ0YsQ0FBQztBQUVWO0FBQUN4RCxFQUFBLENBck5RbUMsU0FBUztFQUFBLFFBQ0xFLHFCQUFLO0FBQUE7QUFBQStFLEdBQUEsR0FEVGpGLFNBQVM7QUFBQSxJQUFBa0YsUUFBQSxHQUFBQyxPQUFBLENBQUFsSCxPQUFBLEdBdU5IK0IsU0FBUztBQUFBLElBQUFELEVBQUEsRUFBQWtGLEdBQUE7QUFBQUcsWUFBQSxDQUFBckYsRUFBQTtBQUFBcUYsWUFBQSxDQUFBSCxHQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}