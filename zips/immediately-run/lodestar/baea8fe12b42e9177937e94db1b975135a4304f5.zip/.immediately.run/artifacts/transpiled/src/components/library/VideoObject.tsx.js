var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _Icon = _interopRequireDefault(require("../Icon"));
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// Video over an assets/ file — poster + play affordance (spec §3.4).

function VideoObject({
  o
}) {
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    style: {
      position: 'absolute',
      inset: 0,
      borderRadius: 12,
      overflow: 'hidden',
      background: 'linear-gradient(135deg, #1a1230, #0d1622)',
      border: '1px solid var(--line)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    },
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      style: {
        position: 'absolute',
        inset: 0,
        background: 'repeating-linear-gradient(45deg, rgba(255,255,255,.025) 0 8px, transparent 8px 16px)'
      }
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      style: {
        width: 54,
        height: 54,
        borderRadius: '50%',
        background: 'rgba(255,255,255,.92)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        boxShadow: '0 6px 20px rgba(0,0,0,.4)'
      },
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        style: {
          marginLeft: 3,
          color: '#16101a'
        },
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
          name: "play",
          size: 22,
          color: "#16101a",
          strokeWidth: 0
        })
      })
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      style: {
        position: 'absolute',
        bottom: 10,
        left: 12,
        font: 'var(--mono-xs)',
        color: 'rgba(255,255,255,.85)'
      },
      children: o.title
    })]
  });
}
_c = VideoObject;
var _default = exports.default = VideoObject;
var _c;
$RefreshReg$(_c, "VideoObject");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfSWNvbiIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJlIiwiX19lc01vZHVsZSIsImRlZmF1bHQiLCJWaWRlb09iamVjdCIsIm8iLCJqc3hzIiwic3R5bGUiLCJwb3NpdGlvbiIsImluc2V0IiwiYm9yZGVyUmFkaXVzIiwib3ZlcmZsb3ciLCJiYWNrZ3JvdW5kIiwiYm9yZGVyIiwiZGlzcGxheSIsImFsaWduSXRlbXMiLCJqdXN0aWZ5Q29udGVudCIsImNoaWxkcmVuIiwianN4Iiwid2lkdGgiLCJoZWlnaHQiLCJib3hTaGFkb3ciLCJtYXJnaW5MZWZ0IiwiY29sb3IiLCJuYW1lIiwic2l6ZSIsInN0cm9rZVdpZHRoIiwiYm90dG9tIiwibGVmdCIsImZvbnQiLCJ0aXRsZSIsIl9jIiwiX2RlZmF1bHQiLCJleHBvcnRzIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiVmlkZW9PYmplY3QudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIFZpZGVvIG92ZXIgYW4gYXNzZXRzLyBmaWxlIOKAlCBwb3N0ZXIgKyBwbGF5IGFmZm9yZGFuY2UgKHNwZWMgwqczLjQpLlxuXG5pbXBvcnQgSWNvbiBmcm9tICcuLi9JY29uJztcbmltcG9ydCB0eXBlIHsgV09iamVjdCB9IGZyb20gJy4uLy4uL2xpYi90eXBlcyc7XG5cbmZ1bmN0aW9uIFZpZGVvT2JqZWN0KHsgbyB9OiB7IG86IFdPYmplY3QgfSkge1xuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIHN0eWxlPXt7XG4gICAgICAgIHBvc2l0aW9uOiAnYWJzb2x1dGUnLFxuICAgICAgICBpbnNldDogMCxcbiAgICAgICAgYm9yZGVyUmFkaXVzOiAxMixcbiAgICAgICAgb3ZlcmZsb3c6ICdoaWRkZW4nLFxuICAgICAgICBiYWNrZ3JvdW5kOiAnbGluZWFyLWdyYWRpZW50KDEzNWRlZywgIzFhMTIzMCwgIzBkMTYyMiknLFxuICAgICAgICBib3JkZXI6ICcxcHggc29saWQgdmFyKC0tbGluZSknLFxuICAgICAgICBkaXNwbGF5OiAnZmxleCcsXG4gICAgICAgIGFsaWduSXRlbXM6ICdjZW50ZXInLFxuICAgICAgICBqdXN0aWZ5Q29udGVudDogJ2NlbnRlcicsXG4gICAgICB9fVxuICAgID5cbiAgICAgIDxkaXYgc3R5bGU9e3sgcG9zaXRpb246ICdhYnNvbHV0ZScsIGluc2V0OiAwLCBiYWNrZ3JvdW5kOiAncmVwZWF0aW5nLWxpbmVhci1ncmFkaWVudCg0NWRlZywgcmdiYSgyNTUsMjU1LDI1NSwuMDI1KSAwIDhweCwgdHJhbnNwYXJlbnQgOHB4IDE2cHgpJyB9fSAvPlxuICAgICAgPGRpdlxuICAgICAgICBzdHlsZT17e1xuICAgICAgICAgIHdpZHRoOiA1NCxcbiAgICAgICAgICBoZWlnaHQ6IDU0LFxuICAgICAgICAgIGJvcmRlclJhZGl1czogJzUwJScsXG4gICAgICAgICAgYmFja2dyb3VuZDogJ3JnYmEoMjU1LDI1NSwyNTUsLjkyKScsXG4gICAgICAgICAgZGlzcGxheTogJ2ZsZXgnLFxuICAgICAgICAgIGFsaWduSXRlbXM6ICdjZW50ZXInLFxuICAgICAgICAgIGp1c3RpZnlDb250ZW50OiAnY2VudGVyJyxcbiAgICAgICAgICBib3hTaGFkb3c6ICcwIDZweCAyMHB4IHJnYmEoMCwwLDAsLjQpJyxcbiAgICAgICAgfX1cbiAgICAgID5cbiAgICAgICAgPHNwYW4gc3R5bGU9e3sgbWFyZ2luTGVmdDogMywgY29sb3I6ICcjMTYxMDFhJyB9fT5cbiAgICAgICAgICA8SWNvbiBuYW1lPVwicGxheVwiIHNpemU9ezIyfSBjb2xvcj1cIiMxNjEwMWFcIiBzdHJva2VXaWR0aD17MH0gLz5cbiAgICAgICAgPC9zcGFuPlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IHN0eWxlPXt7IHBvc2l0aW9uOiAnYWJzb2x1dGUnLCBib3R0b206IDEwLCBsZWZ0OiAxMiwgZm9udDogJ3ZhcigtLW1vbm8teHMpJywgY29sb3I6ICdyZ2JhKDI1NSwyNTUsMjU1LC44NSknIH19PntvLnRpdGxlfTwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufVxuXG5leHBvcnQgZGVmYXVsdCBWaWRlb09iamVjdDtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsS0FBQSxHQUFBQyxzQkFBQSxDQUFBQyxPQUFBO0FBQTJCLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUFBLFNBQUFELHVCQUFBRyxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBRjNCOztBQUtBLFNBQVNHLFdBQVdBLENBQUM7RUFBRUM7QUFBa0IsQ0FBQyxFQUFFO0VBQzFDLG9CQUNFLElBQUFMLFdBQUEsQ0FBQU0sSUFBQTtJQUNFQyxLQUFLLEVBQUU7TUFDTEMsUUFBUSxFQUFFLFVBQVU7TUFDcEJDLEtBQUssRUFBRSxDQUFDO01BQ1JDLFlBQVksRUFBRSxFQUFFO01BQ2hCQyxRQUFRLEVBQUUsUUFBUTtNQUNsQkMsVUFBVSxFQUFFLDJDQUEyQztNQUN2REMsTUFBTSxFQUFFLHVCQUF1QjtNQUMvQkMsT0FBTyxFQUFFLE1BQU07TUFDZkMsVUFBVSxFQUFFLFFBQVE7TUFDcEJDLGNBQWMsRUFBRTtJQUNsQixDQUFFO0lBQUFDLFFBQUEsZ0JBRUYsSUFBQWpCLFdBQUEsQ0FBQWtCLEdBQUE7TUFBS1gsS0FBSyxFQUFFO1FBQUVDLFFBQVEsRUFBRSxVQUFVO1FBQUVDLEtBQUssRUFBRSxDQUFDO1FBQUVHLFVBQVUsRUFBRTtNQUF1RjtJQUFFLENBQUUsQ0FBQyxlQUN0SixJQUFBWixXQUFBLENBQUFrQixHQUFBO01BQ0VYLEtBQUssRUFBRTtRQUNMWSxLQUFLLEVBQUUsRUFBRTtRQUNUQyxNQUFNLEVBQUUsRUFBRTtRQUNWVixZQUFZLEVBQUUsS0FBSztRQUNuQkUsVUFBVSxFQUFFLHVCQUF1QjtRQUNuQ0UsT0FBTyxFQUFFLE1BQU07UUFDZkMsVUFBVSxFQUFFLFFBQVE7UUFDcEJDLGNBQWMsRUFBRSxRQUFRO1FBQ3hCSyxTQUFTLEVBQUU7TUFDYixDQUFFO01BQUFKLFFBQUEsZUFFRixJQUFBakIsV0FBQSxDQUFBa0IsR0FBQTtRQUFNWCxLQUFLLEVBQUU7VUFBRWUsVUFBVSxFQUFFLENBQUM7VUFBRUMsS0FBSyxFQUFFO1FBQVUsQ0FBRTtRQUFBTixRQUFBLGVBQy9DLElBQUFqQixXQUFBLENBQUFrQixHQUFBLEVBQUNyQixLQUFBLENBQUFNLE9BQUk7VUFBQ3FCLElBQUksRUFBQyxNQUFNO1VBQUNDLElBQUksRUFBRSxFQUFHO1VBQUNGLEtBQUssRUFBQyxTQUFTO1VBQUNHLFdBQVcsRUFBRTtRQUFFLENBQUU7TUFBQyxDQUMxRDtJQUFDLENBQ0osQ0FBQyxlQUNOLElBQUExQixXQUFBLENBQUFrQixHQUFBO01BQUtYLEtBQUssRUFBRTtRQUFFQyxRQUFRLEVBQUUsVUFBVTtRQUFFbUIsTUFBTSxFQUFFLEVBQUU7UUFBRUMsSUFBSSxFQUFFLEVBQUU7UUFBRUMsSUFBSSxFQUFFLGdCQUFnQjtRQUFFTixLQUFLLEVBQUU7TUFBd0IsQ0FBRTtNQUFBTixRQUFBLEVBQUVaLENBQUMsQ0FBQ3lCO0lBQUssQ0FBTSxDQUFDO0VBQUEsQ0FDaEksQ0FBQztBQUVWO0FBQUNDLEVBQUEsR0FuQ1EzQixXQUFXO0FBQUEsSUFBQTRCLFFBQUEsR0FBQUMsT0FBQSxDQUFBOUIsT0FBQSxHQXFDTEMsV0FBVztBQUFBLElBQUEyQixFQUFBO0FBQUFHLFlBQUEsQ0FBQUgsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}