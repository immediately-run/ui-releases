var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _Badges = _interopRequireDefault(require("../Badges"));
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// Plain MDX prose renders as a prose card (spec §3.4). Here the body is seed
// text; once live MDX-from-mount lands (V1 gate) this renders the compiled body.

function ProseCard({
  o
}) {
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'var(--panel)',
      border: '1px solid var(--line)',
      borderRadius: 14,
      padding: '15px 16px',
      display: 'flex',
      flexDirection: 'column',
      gap: 8,
      overflow: 'hidden'
    },
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      style: {
        font: '700 15px/1.1 var(--disp)',
        color: 'var(--ink)'
      },
      children: o.title
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      style: {
        font: 'var(--body-sm)',
        color: 'var(--ink-2)',
        textWrap: 'pretty'
      },
      children: o.body
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_Badges.default, {
      o: o
    })]
  });
}
_c = ProseCard;
var _default = exports.default = ProseCard;
var _c;
$RefreshReg$(_c, "ProseCard");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfQmFkZ2VzIiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsInJlcXVpcmUiLCJfanN4UnVudGltZSIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsIlByb3NlQ2FyZCIsIm8iLCJqc3hzIiwic3R5bGUiLCJwb3NpdGlvbiIsImluc2V0IiwiYmFja2dyb3VuZCIsImJvcmRlciIsImJvcmRlclJhZGl1cyIsInBhZGRpbmciLCJkaXNwbGF5IiwiZmxleERpcmVjdGlvbiIsImdhcCIsIm92ZXJmbG93IiwiY2hpbGRyZW4iLCJqc3giLCJmb250IiwiY29sb3IiLCJ0aXRsZSIsInRleHRXcmFwIiwiYm9keSIsIl9jIiwiX2RlZmF1bHQiLCJleHBvcnRzIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUHJvc2VDYXJkLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBQbGFpbiBNRFggcHJvc2UgcmVuZGVycyBhcyBhIHByb3NlIGNhcmQgKHNwZWMgwqczLjQpLiBIZXJlIHRoZSBib2R5IGlzIHNlZWRcbi8vIHRleHQ7IG9uY2UgbGl2ZSBNRFgtZnJvbS1tb3VudCBsYW5kcyAoVjEgZ2F0ZSkgdGhpcyByZW5kZXJzIHRoZSBjb21waWxlZCBib2R5LlxuXG5pbXBvcnQgQmFkZ2VzIGZyb20gJy4uL0JhZGdlcyc7XG5pbXBvcnQgdHlwZSB7IFdPYmplY3QgfSBmcm9tICcuLi8uLi9saWIvdHlwZXMnO1xuXG5mdW5jdGlvbiBQcm9zZUNhcmQoeyBvIH06IHsgbzogV09iamVjdCB9KSB7XG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgc3R5bGU9e3tcbiAgICAgICAgcG9zaXRpb246ICdhYnNvbHV0ZScsXG4gICAgICAgIGluc2V0OiAwLFxuICAgICAgICBiYWNrZ3JvdW5kOiAndmFyKC0tcGFuZWwpJyxcbiAgICAgICAgYm9yZGVyOiAnMXB4IHNvbGlkIHZhcigtLWxpbmUpJyxcbiAgICAgICAgYm9yZGVyUmFkaXVzOiAxNCxcbiAgICAgICAgcGFkZGluZzogJzE1cHggMTZweCcsXG4gICAgICAgIGRpc3BsYXk6ICdmbGV4JyxcbiAgICAgICAgZmxleERpcmVjdGlvbjogJ2NvbHVtbicsXG4gICAgICAgIGdhcDogOCxcbiAgICAgICAgb3ZlcmZsb3c6ICdoaWRkZW4nLFxuICAgICAgfX1cbiAgICA+XG4gICAgICA8ZGl2IHN0eWxlPXt7IGZvbnQ6ICc3MDAgMTVweC8xLjEgdmFyKC0tZGlzcCknLCBjb2xvcjogJ3ZhcigtLWluayknIH19PntvLnRpdGxlfTwvZGl2PlxuICAgICAgPGRpdiBzdHlsZT17eyBmb250OiAndmFyKC0tYm9keS1zbSknLCBjb2xvcjogJ3ZhcigtLWluay0yKScsIHRleHRXcmFwOiAncHJldHR5JyB9fT57by5ib2R5fTwvZGl2PlxuICAgICAgPEJhZGdlcyBvPXtvfSAvPlxuICAgIDwvZGl2PlxuICApO1xufVxuXG5leHBvcnQgZGVmYXVsdCBQcm9zZUNhcmQ7XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUdBLElBQUFBLE9BQUEsR0FBQUMsc0JBQUEsQ0FBQUMsT0FBQTtBQUErQixJQUFBQyxXQUFBLEdBQUFELE9BQUE7QUFBQSxTQUFBRCx1QkFBQUcsQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQUgvQjtBQUNBOztBQUtBLFNBQVNHLFNBQVNBLENBQUM7RUFBRUM7QUFBa0IsQ0FBQyxFQUFFO0VBQ3hDLG9CQUNFLElBQUFMLFdBQUEsQ0FBQU0sSUFBQTtJQUNFQyxLQUFLLEVBQUU7TUFDTEMsUUFBUSxFQUFFLFVBQVU7TUFDcEJDLEtBQUssRUFBRSxDQUFDO01BQ1JDLFVBQVUsRUFBRSxjQUFjO01BQzFCQyxNQUFNLEVBQUUsdUJBQXVCO01BQy9CQyxZQUFZLEVBQUUsRUFBRTtNQUNoQkMsT0FBTyxFQUFFLFdBQVc7TUFDcEJDLE9BQU8sRUFBRSxNQUFNO01BQ2ZDLGFBQWEsRUFBRSxRQUFRO01BQ3ZCQyxHQUFHLEVBQUUsQ0FBQztNQUNOQyxRQUFRLEVBQUU7SUFDWixDQUFFO0lBQUFDLFFBQUEsZ0JBRUYsSUFBQWxCLFdBQUEsQ0FBQW1CLEdBQUE7TUFBS1osS0FBSyxFQUFFO1FBQUVhLElBQUksRUFBRSwwQkFBMEI7UUFBRUMsS0FBSyxFQUFFO01BQWEsQ0FBRTtNQUFBSCxRQUFBLEVBQUViLENBQUMsQ0FBQ2lCO0lBQUssQ0FBTSxDQUFDLGVBQ3RGLElBQUF0QixXQUFBLENBQUFtQixHQUFBO01BQUtaLEtBQUssRUFBRTtRQUFFYSxJQUFJLEVBQUUsZ0JBQWdCO1FBQUVDLEtBQUssRUFBRSxjQUFjO1FBQUVFLFFBQVEsRUFBRTtNQUFTLENBQUU7TUFBQUwsUUFBQSxFQUFFYixDQUFDLENBQUNtQjtJQUFJLENBQU0sQ0FBQyxlQUNqRyxJQUFBeEIsV0FBQSxDQUFBbUIsR0FBQSxFQUFDdEIsT0FBQSxDQUFBTSxPQUFNO01BQUNFLENBQUMsRUFBRUE7SUFBRSxDQUFFLENBQUM7RUFBQSxDQUNiLENBQUM7QUFFVjtBQUFDb0IsRUFBQSxHQXJCUXJCLFNBQVM7QUFBQSxJQUFBc0IsUUFBQSxHQUFBQyxPQUFBLENBQUF4QixPQUFBLEdBdUJIQyxTQUFTO0FBQUEsSUFBQXFCLEVBQUE7QUFBQUcsWUFBQSxDQUFBSCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}