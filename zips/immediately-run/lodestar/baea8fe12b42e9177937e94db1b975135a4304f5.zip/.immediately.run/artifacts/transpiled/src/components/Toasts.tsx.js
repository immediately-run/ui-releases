var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
var _useLodestarCtx = require("../hooks/useLodestarCtx");
var _Icon = _interopRequireDefault(require("./Icon"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // Bottom-center toast stack: save confirmations, the delete + 10s undo, the
// LWW/merge notice, and the role-downgrade notice (copy in the controller's demo
// scenarios). Non-blocking; an optional action button (e.g. Undo, Keep mine).
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function Toasts() {
  _s();
  const wb = (0, _useLodestarCtx.useWb)();
  const {
    toasts
  } = wb.state;
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    role: "status",
    "aria-live": "polite",
    style: {
      position: 'absolute',
      bottom: 20,
      left: '50%',
      transform: 'translateX(-50%)',
      display: 'flex',
      flexDirection: 'column',
      gap: 8,
      alignItems: 'center',
      zIndex: 60,
      pointerEvents: 'none'
    },
    children: toasts.map(t => {
      const iconColor = t.iconColor || 'var(--accent-pink)';
      return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        style: {
          display: 'flex',
          alignItems: 'center',
          gap: 11,
          padding: '11px 15px',
          background: 'color-mix(in oklab, var(--panel) 94%, transparent)',
          border: '1px solid var(--line-2)',
          borderRadius: 12,
          boxShadow: 'var(--shadow-pop)',
          backdropFilter: 'blur(12px)',
          font: 'var(--body-sm)',
          color: 'var(--ink)',
          pointerEvents: 'auto',
          maxWidth: 'min(440px, 92vw)'
        },
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          style: {
            display: 'inline-flex',
            color: iconColor,
            flex: 'none'
          },
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
            name: t.icon,
            size: 15,
            color: iconColor,
            strokeWidth: 1.75
          })
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          style: {
            flex: 1
          },
          children: t.text
        }), t.actionLabel ? /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          onClick: () => {
            t.onAction?.();
            wb.dismissToast(t.id);
          },
          style: {
            background: 'none',
            border: 'none',
            color: 'var(--accent-pink)',
            font: 'var(--label)',
            cursor: 'pointer',
            padding: '2px 4px',
            minHeight: 24,
            whiteSpace: 'nowrap'
          },
          children: t.actionLabel
        }) : null]
      }, t.id);
    })
  });
}
_s(Toasts, "VeUy8AIV4bR/U9OnzH43HThc4KU=", false, function () {
  return [_useLodestarCtx.useWb];
});
_c = Toasts;
var _default = exports.default = Toasts;
var _c;
$RefreshReg$(_c, "Toasts");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdXNlTG9kZXN0YXJDdHgiLCJyZXF1aXJlIiwiX0ljb24iLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsIlRvYXN0cyIsIndiIiwidXNlV2IiLCJ0b2FzdHMiLCJzdGF0ZSIsImpzeCIsInJvbGUiLCJzdHlsZSIsInBvc2l0aW9uIiwiYm90dG9tIiwibGVmdCIsInRyYW5zZm9ybSIsImRpc3BsYXkiLCJmbGV4RGlyZWN0aW9uIiwiZ2FwIiwiYWxpZ25JdGVtcyIsInpJbmRleCIsInBvaW50ZXJFdmVudHMiLCJjaGlsZHJlbiIsIm1hcCIsInQiLCJpY29uQ29sb3IiLCJqc3hzIiwicGFkZGluZyIsImJhY2tncm91bmQiLCJib3JkZXIiLCJib3JkZXJSYWRpdXMiLCJib3hTaGFkb3ciLCJiYWNrZHJvcEZpbHRlciIsImZvbnQiLCJjb2xvciIsIm1heFdpZHRoIiwiZmxleCIsIm5hbWUiLCJpY29uIiwic2l6ZSIsInN0cm9rZVdpZHRoIiwidGV4dCIsImFjdGlvbkxhYmVsIiwib25DbGljayIsIm9uQWN0aW9uIiwiZGlzbWlzc1RvYXN0IiwiaWQiLCJjdXJzb3IiLCJtaW5IZWlnaHQiLCJ3aGl0ZVNwYWNlIiwiX2MiLCJfZGVmYXVsdCIsImV4cG9ydHMiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJUb2FzdHMudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIEJvdHRvbS1jZW50ZXIgdG9hc3Qgc3RhY2s6IHNhdmUgY29uZmlybWF0aW9ucywgdGhlIGRlbGV0ZSArIDEwcyB1bmRvLCB0aGVcbi8vIExXVy9tZXJnZSBub3RpY2UsIGFuZCB0aGUgcm9sZS1kb3duZ3JhZGUgbm90aWNlIChjb3B5IGluIHRoZSBjb250cm9sbGVyJ3MgZGVtb1xuLy8gc2NlbmFyaW9zKS4gTm9uLWJsb2NraW5nOyBhbiBvcHRpb25hbCBhY3Rpb24gYnV0dG9uIChlLmcuIFVuZG8sIEtlZXAgbWluZSkuXG5cbmltcG9ydCB7IHVzZVdiIH0gZnJvbSAnLi4vaG9va3MvdXNlTG9kZXN0YXJDdHgnO1xuaW1wb3J0IEljb24gZnJvbSAnLi9JY29uJztcblxuZnVuY3Rpb24gVG9hc3RzKCkge1xuICBjb25zdCB3YiA9IHVzZVdiKCk7XG4gIGNvbnN0IHsgdG9hc3RzIH0gPSB3Yi5zdGF0ZTtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IHJvbGU9XCJzdGF0dXNcIiBhcmlhLWxpdmU9XCJwb2xpdGVcIiBzdHlsZT17eyBwb3NpdGlvbjogJ2Fic29sdXRlJywgYm90dG9tOiAyMCwgbGVmdDogJzUwJScsIHRyYW5zZm9ybTogJ3RyYW5zbGF0ZVgoLTUwJSknLCBkaXNwbGF5OiAnZmxleCcsIGZsZXhEaXJlY3Rpb246ICdjb2x1bW4nLCBnYXA6IDgsIGFsaWduSXRlbXM6ICdjZW50ZXInLCB6SW5kZXg6IDYwLCBwb2ludGVyRXZlbnRzOiAnbm9uZScgfX0+XG4gICAgICB7dG9hc3RzLm1hcCgodCkgPT4ge1xuICAgICAgICBjb25zdCBpY29uQ29sb3IgPSB0Lmljb25Db2xvciB8fCAndmFyKC0tYWNjZW50LXBpbmspJztcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICBrZXk9e3QuaWR9XG4gICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICBkaXNwbGF5OiAnZmxleCcsXG4gICAgICAgICAgICAgIGFsaWduSXRlbXM6ICdjZW50ZXInLFxuICAgICAgICAgICAgICBnYXA6IDExLFxuICAgICAgICAgICAgICBwYWRkaW5nOiAnMTFweCAxNXB4JyxcbiAgICAgICAgICAgICAgYmFja2dyb3VuZDogJ2NvbG9yLW1peChpbiBva2xhYiwgdmFyKC0tcGFuZWwpIDk0JSwgdHJhbnNwYXJlbnQpJyxcbiAgICAgICAgICAgICAgYm9yZGVyOiAnMXB4IHNvbGlkIHZhcigtLWxpbmUtMiknLFxuICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6IDEyLFxuICAgICAgICAgICAgICBib3hTaGFkb3c6ICd2YXIoLS1zaGFkb3ctcG9wKScsXG4gICAgICAgICAgICAgIGJhY2tkcm9wRmlsdGVyOiAnYmx1cigxMnB4KScsXG4gICAgICAgICAgICAgIGZvbnQ6ICd2YXIoLS1ib2R5LXNtKScsXG4gICAgICAgICAgICAgIGNvbG9yOiAndmFyKC0taW5rKScsXG4gICAgICAgICAgICAgIHBvaW50ZXJFdmVudHM6ICdhdXRvJyxcbiAgICAgICAgICAgICAgbWF4V2lkdGg6ICdtaW4oNDQwcHgsIDkydncpJyxcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZGlzcGxheTogJ2lubGluZS1mbGV4JywgY29sb3I6IGljb25Db2xvciwgZmxleDogJ25vbmUnIH19PlxuICAgICAgICAgICAgICA8SWNvbiBuYW1lPXt0Lmljb259IHNpemU9ezE1fSBjb2xvcj17aWNvbkNvbG9yfSBzdHJva2VXaWR0aD17MS43NX0gLz5cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGZsZXg6IDEgfX0+e3QudGV4dH08L3NwYW4+XG4gICAgICAgICAgICB7dC5hY3Rpb25MYWJlbCA/IChcbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgIHQub25BY3Rpb24/LigpO1xuICAgICAgICAgICAgICAgICAgd2IuZGlzbWlzc1RvYXN0KHQuaWQpO1xuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgc3R5bGU9e3sgYmFja2dyb3VuZDogJ25vbmUnLCBib3JkZXI6ICdub25lJywgY29sb3I6ICd2YXIoLS1hY2NlbnQtcGluayknLCBmb250OiAndmFyKC0tbGFiZWwpJywgY3Vyc29yOiAncG9pbnRlcicsIHBhZGRpbmc6ICcycHggNHB4JywgbWluSGVpZ2h0OiAyNCwgd2hpdGVTcGFjZTogJ25vd3JhcCcgfX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHt0LmFjdGlvbkxhYmVsfVxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICkgOiBudWxsfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApO1xuICAgICAgfSl9XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IFRvYXN0cztcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFJQSxJQUFBQSxlQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxLQUFBLEdBQUFDLHNCQUFBLENBQUFGLE9BQUE7QUFBMEIsSUFBQUcsV0FBQSxHQUFBSCxPQUFBO0FBQUEsSUFBQUksRUFBQSxHQUFBQyxZQUFBLElBTDFCO0FBQ0E7QUFDQTtBQUFBLFNBQUFILHVCQUFBSSxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBS0EsU0FBU0csTUFBTUEsQ0FBQSxFQUFHO0VBQUFMLEVBQUE7RUFDaEIsTUFBTU0sRUFBRSxHQUFHLElBQUFDLHFCQUFLLEVBQUMsQ0FBQztFQUNsQixNQUFNO0lBQUVDO0VBQU8sQ0FBQyxHQUFHRixFQUFFLENBQUNHLEtBQUs7RUFDM0Isb0JBQ0UsSUFBQVYsV0FBQSxDQUFBVyxHQUFBO0lBQUtDLElBQUksRUFBQyxRQUFRO0lBQUMsYUFBVSxRQUFRO0lBQUNDLEtBQUssRUFBRTtNQUFFQyxRQUFRLEVBQUUsVUFBVTtNQUFFQyxNQUFNLEVBQUUsRUFBRTtNQUFFQyxJQUFJLEVBQUUsS0FBSztNQUFFQyxTQUFTLEVBQUUsa0JBQWtCO01BQUVDLE9BQU8sRUFBRSxNQUFNO01BQUVDLGFBQWEsRUFBRSxRQUFRO01BQUVDLEdBQUcsRUFBRSxDQUFDO01BQUVDLFVBQVUsRUFBRSxRQUFRO01BQUVDLE1BQU0sRUFBRSxFQUFFO01BQUVDLGFBQWEsRUFBRTtJQUFPLENBQUU7SUFBQUMsUUFBQSxFQUN0T2YsTUFBTSxDQUFDZ0IsR0FBRyxDQUFFQyxDQUFDLElBQUs7TUFDakIsTUFBTUMsU0FBUyxHQUFHRCxDQUFDLENBQUNDLFNBQVMsSUFBSSxvQkFBb0I7TUFDckQsb0JBQ0UsSUFBQTNCLFdBQUEsQ0FBQTRCLElBQUE7UUFFRWYsS0FBSyxFQUFFO1VBQ0xLLE9BQU8sRUFBRSxNQUFNO1VBQ2ZHLFVBQVUsRUFBRSxRQUFRO1VBQ3BCRCxHQUFHLEVBQUUsRUFBRTtVQUNQUyxPQUFPLEVBQUUsV0FBVztVQUNwQkMsVUFBVSxFQUFFLG9EQUFvRDtVQUNoRUMsTUFBTSxFQUFFLHlCQUF5QjtVQUNqQ0MsWUFBWSxFQUFFLEVBQUU7VUFDaEJDLFNBQVMsRUFBRSxtQkFBbUI7VUFDOUJDLGNBQWMsRUFBRSxZQUFZO1VBQzVCQyxJQUFJLEVBQUUsZ0JBQWdCO1VBQ3RCQyxLQUFLLEVBQUUsWUFBWTtVQUNuQmIsYUFBYSxFQUFFLE1BQU07VUFDckJjLFFBQVEsRUFBRTtRQUNaLENBQUU7UUFBQWIsUUFBQSxnQkFFRixJQUFBeEIsV0FBQSxDQUFBVyxHQUFBO1VBQU1FLEtBQUssRUFBRTtZQUFFSyxPQUFPLEVBQUUsYUFBYTtZQUFFa0IsS0FBSyxFQUFFVCxTQUFTO1lBQUVXLElBQUksRUFBRTtVQUFPLENBQUU7VUFBQWQsUUFBQSxlQUN0RSxJQUFBeEIsV0FBQSxDQUFBVyxHQUFBLEVBQUNiLEtBQUEsQ0FBQU8sT0FBSTtZQUFDa0MsSUFBSSxFQUFFYixDQUFDLENBQUNjLElBQUs7WUFBQ0MsSUFBSSxFQUFFLEVBQUc7WUFBQ0wsS0FBSyxFQUFFVCxTQUFVO1lBQUNlLFdBQVcsRUFBRTtVQUFLLENBQUU7UUFBQyxDQUNqRSxDQUFDLGVBQ1AsSUFBQTFDLFdBQUEsQ0FBQVcsR0FBQTtVQUFNRSxLQUFLLEVBQUU7WUFBRXlCLElBQUksRUFBRTtVQUFFLENBQUU7VUFBQWQsUUFBQSxFQUFFRSxDQUFDLENBQUNpQjtRQUFJLENBQU8sQ0FBQyxFQUN4Q2pCLENBQUMsQ0FBQ2tCLFdBQVcsZ0JBQ1osSUFBQTVDLFdBQUEsQ0FBQVcsR0FBQTtVQUNFa0MsT0FBTyxFQUFFQSxDQUFBLEtBQU07WUFDYm5CLENBQUMsQ0FBQ29CLFFBQVEsR0FBRyxDQUFDO1lBQ2R2QyxFQUFFLENBQUN3QyxZQUFZLENBQUNyQixDQUFDLENBQUNzQixFQUFFLENBQUM7VUFDdkIsQ0FBRTtVQUNGbkMsS0FBSyxFQUFFO1lBQUVpQixVQUFVLEVBQUUsTUFBTTtZQUFFQyxNQUFNLEVBQUUsTUFBTTtZQUFFSyxLQUFLLEVBQUUsb0JBQW9CO1lBQUVELElBQUksRUFBRSxjQUFjO1lBQUVjLE1BQU0sRUFBRSxTQUFTO1lBQUVwQixPQUFPLEVBQUUsU0FBUztZQUFFcUIsU0FBUyxFQUFFLEVBQUU7WUFBRUMsVUFBVSxFQUFFO1VBQVMsQ0FBRTtVQUFBM0IsUUFBQSxFQUU1S0UsQ0FBQyxDQUFDa0I7UUFBVyxDQUNSLENBQUMsR0FDUCxJQUFJO01BQUEsR0EvQkhsQixDQUFDLENBQUNzQixFQWdDSixDQUFDO0lBRVYsQ0FBQztFQUFDLENBQ0MsQ0FBQztBQUVWO0FBQUMvQyxFQUFBLENBOUNRSyxNQUFNO0VBQUEsUUFDRkUscUJBQUs7QUFBQTtBQUFBNEMsRUFBQSxHQURUOUMsTUFBTTtBQUFBLElBQUErQyxRQUFBLEdBQUFDLE9BQUEsQ0FBQWpELE9BQUEsR0FnREFDLE1BQU07QUFBQSxJQUFBOEMsRUFBQTtBQUFBRyxZQUFBLENBQUFILEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}