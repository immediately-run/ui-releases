var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _useLodestarCtx = require("../hooks/useLodestarCtx");
var _useOverlayDialog = require("../hooks/useOverlayDialog");
var _Icon = _interopRequireDefault(require("./Icon"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // A bottom-left scenario switcher that surfaces the designed states and
// collaboration moments for review — the board chooser, the empty/forbidden
// screens, and the concurrent-edit / role-downgrade toasts. It stands in for
// states the live platform layer (mounts, share-link redemption) will drive once
// wired; it is a dev affordance, not host chrome.
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function DemoMenu() {
  _s();
  const wb = (0, _useLodestarCtx.useWb)();
  const {
    demoMenuOpen
  } = wb.state;
  const closeMenu = () => wb.toggleDemoMenu();
  // The dialog contract (R3-607): focus in, Tab trapped, Escape, focus return —
  // armed while the dropdown is open.
  const dialogRef = (0, _useOverlayDialog.useOverlayDialog)(demoMenuOpen, closeMenu);
  const items = [{
    label: 'Board chooser',
    run: () => setScreen('chooser')
  }, {
    label: 'Empty board (invite)',
    run: () => setScreen('empty')
  }, {
    label: 'No board selected',
    run: () => setScreen('noboard')
  }, {
    label: 'Signed out',
    run: () => setScreen('signedout')
  }, {
    label: 'Not a board (retry)',
    run: () => setScreen('notaboard')
  }, {
    label: 'Simulate concurrent edit',
    run: () => {
      wb.demoLWW();
      wb.toggleDemoMenu();
    }
  }, {
    label: 'Simulate role downgrade',
    run: () => {
      wb.demoDowngrade();
      wb.toggleDemoMenu();
    }
  }];
  function setScreen(k) {
    wb.setScreen(k);
    wb.toggleDemoMenu();
  }
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    style: {
      position: 'absolute',
      bottom: 16,
      left: 16,
      zIndex: 45
    },
    children: [demoMenuOpen ? /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      ref: dialogRef,
      tabIndex: -1,
      style: {
        position: 'absolute',
        bottom: 46,
        left: 0,
        width: 230,
        padding: 6,
        background: 'var(--panel)',
        border: '1px solid var(--line)',
        borderRadius: 14,
        boxShadow: 'var(--shadow-pop)'
      },
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        style: {
          font: 'var(--mono-xs)',
          letterSpacing: '.06em',
          textTransform: 'uppercase',
          color: 'var(--ink-3)',
          padding: '4px 10px 6px'
        },
        children: "States & scenarios"
      }), items.map(d => /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        onClick: d.run,
        style: {
          display: 'block',
          width: '100%',
          padding: '8px 10px',
          background: 'none',
          border: 'none',
          borderRadius: 8,
          color: 'var(--ink)',
          font: 'var(--body-sm)',
          cursor: 'pointer',
          textAlign: 'left'
        },
        children: d.label
      }, d.label))]
    }) : null, /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
      onClick: wb.toggleDemoMenu,
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 7,
        padding: '7px 12px',
        background: 'color-mix(in oklab, var(--panel) 86%, transparent)',
        border: '1px solid var(--line)',
        borderRadius: 'var(--r-pill)',
        color: 'var(--ink-2)',
        font: 'var(--mono-xs)',
        letterSpacing: '.04em',
        cursor: 'pointer',
        backdropFilter: 'blur(10px)',
        textTransform: 'uppercase'
      },
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
        name: "layers",
        size: 13,
        strokeWidth: 1.75
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        children: "Demo states"
      })]
    })]
  });
}
_s(DemoMenu, "pMhplSnczCcvKhkacNYLU2e8wl4=", false, function () {
  return [_useLodestarCtx.useWb, _useOverlayDialog.useOverlayDialog];
});
_c = DemoMenu;
var _default = exports.default = DemoMenu;
var _c;
$RefreshReg$(_c, "DemoMenu");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdXNlTG9kZXN0YXJDdHgiLCJyZXF1aXJlIiwiX3VzZU92ZXJsYXlEaWFsb2ciLCJfSWNvbiIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiRGVtb01lbnUiLCJ3YiIsInVzZVdiIiwiZGVtb01lbnVPcGVuIiwic3RhdGUiLCJjbG9zZU1lbnUiLCJ0b2dnbGVEZW1vTWVudSIsImRpYWxvZ1JlZiIsInVzZU92ZXJsYXlEaWFsb2ciLCJpdGVtcyIsImxhYmVsIiwicnVuIiwic2V0U2NyZWVuIiwiZGVtb0xXVyIsImRlbW9Eb3duZ3JhZGUiLCJrIiwianN4cyIsInN0eWxlIiwicG9zaXRpb24iLCJib3R0b20iLCJsZWZ0IiwiekluZGV4IiwiY2hpbGRyZW4iLCJyZWYiLCJ0YWJJbmRleCIsIndpZHRoIiwicGFkZGluZyIsImJhY2tncm91bmQiLCJib3JkZXIiLCJib3JkZXJSYWRpdXMiLCJib3hTaGFkb3ciLCJqc3giLCJmb250IiwibGV0dGVyU3BhY2luZyIsInRleHRUcmFuc2Zvcm0iLCJjb2xvciIsIm1hcCIsImQiLCJvbkNsaWNrIiwiZGlzcGxheSIsImN1cnNvciIsInRleHRBbGlnbiIsImFsaWduSXRlbXMiLCJnYXAiLCJiYWNrZHJvcEZpbHRlciIsIm5hbWUiLCJzaXplIiwic3Ryb2tlV2lkdGgiLCJfYyIsIl9kZWZhdWx0IiwiZXhwb3J0cyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkRlbW9NZW51LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBBIGJvdHRvbS1sZWZ0IHNjZW5hcmlvIHN3aXRjaGVyIHRoYXQgc3VyZmFjZXMgdGhlIGRlc2lnbmVkIHN0YXRlcyBhbmRcbi8vIGNvbGxhYm9yYXRpb24gbW9tZW50cyBmb3IgcmV2aWV3IOKAlCB0aGUgYm9hcmQgY2hvb3NlciwgdGhlIGVtcHR5L2ZvcmJpZGRlblxuLy8gc2NyZWVucywgYW5kIHRoZSBjb25jdXJyZW50LWVkaXQgLyByb2xlLWRvd25ncmFkZSB0b2FzdHMuIEl0IHN0YW5kcyBpbiBmb3Jcbi8vIHN0YXRlcyB0aGUgbGl2ZSBwbGF0Zm9ybSBsYXllciAobW91bnRzLCBzaGFyZS1saW5rIHJlZGVtcHRpb24pIHdpbGwgZHJpdmUgb25jZVxuLy8gd2lyZWQ7IGl0IGlzIGEgZGV2IGFmZm9yZGFuY2UsIG5vdCBob3N0IGNocm9tZS5cblxuaW1wb3J0IHsgdXNlV2IgfSBmcm9tICcuLi9ob29rcy91c2VMb2Rlc3RhckN0eCc7XG5pbXBvcnQgeyB1c2VPdmVybGF5RGlhbG9nIH0gZnJvbSAnLi4vaG9va3MvdXNlT3ZlcmxheURpYWxvZyc7XG5pbXBvcnQgSWNvbiBmcm9tICcuL0ljb24nO1xuaW1wb3J0IHR5cGUgeyBTY3JlZW5LaW5kIH0gZnJvbSAnLi4vbGliL3R5cGVzJztcblxuZnVuY3Rpb24gRGVtb01lbnUoKSB7XG4gIGNvbnN0IHdiID0gdXNlV2IoKTtcbiAgY29uc3QgeyBkZW1vTWVudU9wZW4gfSA9IHdiLnN0YXRlO1xuICBjb25zdCBjbG9zZU1lbnUgPSAoKSA9PiB3Yi50b2dnbGVEZW1vTWVudSgpO1xuICAvLyBUaGUgZGlhbG9nIGNvbnRyYWN0IChSMy02MDcpOiBmb2N1cyBpbiwgVGFiIHRyYXBwZWQsIEVzY2FwZSwgZm9jdXMgcmV0dXJuIOKAlFxuICAvLyBhcm1lZCB3aGlsZSB0aGUgZHJvcGRvd24gaXMgb3Blbi5cbiAgY29uc3QgZGlhbG9nUmVmID0gdXNlT3ZlcmxheURpYWxvZyhkZW1vTWVudU9wZW4sIGNsb3NlTWVudSk7XG5cbiAgY29uc3QgaXRlbXM6IHsgbGFiZWw6IHN0cmluZzsgcnVuOiAoKSA9PiB2b2lkIH1bXSA9IFtcbiAgICB7IGxhYmVsOiAnQm9hcmQgY2hvb3NlcicsIHJ1bjogKCkgPT4gc2V0U2NyZWVuKCdjaG9vc2VyJykgfSxcbiAgICB7IGxhYmVsOiAnRW1wdHkgYm9hcmQgKGludml0ZSknLCBydW46ICgpID0+IHNldFNjcmVlbignZW1wdHknKSB9LFxuICAgIHsgbGFiZWw6ICdObyBib2FyZCBzZWxlY3RlZCcsIHJ1bjogKCkgPT4gc2V0U2NyZWVuKCdub2JvYXJkJykgfSxcbiAgICB7IGxhYmVsOiAnU2lnbmVkIG91dCcsIHJ1bjogKCkgPT4gc2V0U2NyZWVuKCdzaWduZWRvdXQnKSB9LFxuICAgIHsgbGFiZWw6ICdOb3QgYSBib2FyZCAocmV0cnkpJywgcnVuOiAoKSA9PiBzZXRTY3JlZW4oJ25vdGFib2FyZCcpIH0sXG4gICAgeyBsYWJlbDogJ1NpbXVsYXRlIGNvbmN1cnJlbnQgZWRpdCcsIHJ1bjogKCkgPT4geyB3Yi5kZW1vTFdXKCk7IHdiLnRvZ2dsZURlbW9NZW51KCk7IH0gfSxcbiAgICB7IGxhYmVsOiAnU2ltdWxhdGUgcm9sZSBkb3duZ3JhZGUnLCBydW46ICgpID0+IHsgd2IuZGVtb0Rvd25ncmFkZSgpOyB3Yi50b2dnbGVEZW1vTWVudSgpOyB9IH0sXG4gIF07XG5cbiAgZnVuY3Rpb24gc2V0U2NyZWVuKGs6IFNjcmVlbktpbmQpIHtcbiAgICB3Yi5zZXRTY3JlZW4oayk7XG4gICAgd2IudG9nZ2xlRGVtb01lbnUoKTtcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBzdHlsZT17eyBwb3NpdGlvbjogJ2Fic29sdXRlJywgYm90dG9tOiAxNiwgbGVmdDogMTYsIHpJbmRleDogNDUgfX0+XG4gICAgICB7ZGVtb01lbnVPcGVuID8gKFxuICAgICAgICA8ZGl2IHJlZj17ZGlhbG9nUmVmfSB0YWJJbmRleD17LTF9IHN0eWxlPXt7IHBvc2l0aW9uOiAnYWJzb2x1dGUnLCBib3R0b206IDQ2LCBsZWZ0OiAwLCB3aWR0aDogMjMwLCBwYWRkaW5nOiA2LCBiYWNrZ3JvdW5kOiAndmFyKC0tcGFuZWwpJywgYm9yZGVyOiAnMXB4IHNvbGlkIHZhcigtLWxpbmUpJywgYm9yZGVyUmFkaXVzOiAxNCwgYm94U2hhZG93OiAndmFyKC0tc2hhZG93LXBvcCknIH19PlxuICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udDogJ3ZhcigtLW1vbm8teHMpJywgbGV0dGVyU3BhY2luZzogJy4wNmVtJywgdGV4dFRyYW5zZm9ybTogJ3VwcGVyY2FzZScsIGNvbG9yOiAndmFyKC0taW5rLTMpJywgcGFkZGluZzogJzRweCAxMHB4IDZweCcgfX0+U3RhdGVzICZhbXA7IHNjZW5hcmlvczwvZGl2PlxuICAgICAgICAgIHtpdGVtcy5tYXAoKGQpID0+IChcbiAgICAgICAgICAgIDxidXR0b24ga2V5PXtkLmxhYmVsfSBvbkNsaWNrPXtkLnJ1bn0gc3R5bGU9e3sgZGlzcGxheTogJ2Jsb2NrJywgd2lkdGg6ICcxMDAlJywgcGFkZGluZzogJzhweCAxMHB4JywgYmFja2dyb3VuZDogJ25vbmUnLCBib3JkZXI6ICdub25lJywgYm9yZGVyUmFkaXVzOiA4LCBjb2xvcjogJ3ZhcigtLWluayknLCBmb250OiAndmFyKC0tYm9keS1zbSknLCBjdXJzb3I6ICdwb2ludGVyJywgdGV4dEFsaWduOiAnbGVmdCcgfX0+XG4gICAgICAgICAgICAgIHtkLmxhYmVsfVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgKSA6IG51bGx9XG4gICAgICA8YnV0dG9uXG4gICAgICAgIG9uQ2xpY2s9e3diLnRvZ2dsZURlbW9NZW51fVxuICAgICAgICBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBnYXA6IDcsIHBhZGRpbmc6ICc3cHggMTJweCcsIGJhY2tncm91bmQ6ICdjb2xvci1taXgoaW4gb2tsYWIsIHZhcigtLXBhbmVsKSA4NiUsIHRyYW5zcGFyZW50KScsIGJvcmRlcjogJzFweCBzb2xpZCB2YXIoLS1saW5lKScsIGJvcmRlclJhZGl1czogJ3ZhcigtLXItcGlsbCknLCBjb2xvcjogJ3ZhcigtLWluay0yKScsIGZvbnQ6ICd2YXIoLS1tb25vLXhzKScsIGxldHRlclNwYWNpbmc6ICcuMDRlbScsIGN1cnNvcjogJ3BvaW50ZXInLCBiYWNrZHJvcEZpbHRlcjogJ2JsdXIoMTBweCknLCB0ZXh0VHJhbnNmb3JtOiAndXBwZXJjYXNlJyB9fVxuICAgICAgPlxuICAgICAgICA8SWNvbiBuYW1lPVwibGF5ZXJzXCIgc2l6ZT17MTN9IHN0cm9rZVdpZHRoPXsxLjc1fSAvPlxuICAgICAgICA8c3Bhbj5EZW1vIHN0YXRlczwvc3Bhbj5cbiAgICAgIDwvYnV0dG9uPlxuICAgIDwvZGl2PlxuICApO1xufVxuXG5leHBvcnQgZGVmYXVsdCBEZW1vTWVudTtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBTUEsSUFBQUEsZUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsaUJBQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLEtBQUEsR0FBQUMsc0JBQUEsQ0FBQUgsT0FBQTtBQUEwQixJQUFBSSxXQUFBLEdBQUFKLE9BQUE7QUFBQSxJQUFBSyxFQUFBLEdBQUFDLFlBQUEsSUFSMUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUFBLFNBQUFILHVCQUFBSSxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBT0EsU0FBU0csUUFBUUEsQ0FBQSxFQUFHO0VBQUFMLEVBQUE7RUFDbEIsTUFBTU0sRUFBRSxHQUFHLElBQUFDLHFCQUFLLEVBQUMsQ0FBQztFQUNsQixNQUFNO0lBQUVDO0VBQWEsQ0FBQyxHQUFHRixFQUFFLENBQUNHLEtBQUs7RUFDakMsTUFBTUMsU0FBUyxHQUFHQSxDQUFBLEtBQU1KLEVBQUUsQ0FBQ0ssY0FBYyxDQUFDLENBQUM7RUFDM0M7RUFDQTtFQUNBLE1BQU1DLFNBQVMsR0FBRyxJQUFBQyxrQ0FBZ0IsRUFBQ0wsWUFBWSxFQUFFRSxTQUFTLENBQUM7RUFFM0QsTUFBTUksS0FBMkMsR0FBRyxDQUNsRDtJQUFFQyxLQUFLLEVBQUUsZUFBZTtJQUFFQyxHQUFHLEVBQUVBLENBQUEsS0FBTUMsU0FBUyxDQUFDLFNBQVM7RUFBRSxDQUFDLEVBQzNEO0lBQUVGLEtBQUssRUFBRSxzQkFBc0I7SUFBRUMsR0FBRyxFQUFFQSxDQUFBLEtBQU1DLFNBQVMsQ0FBQyxPQUFPO0VBQUUsQ0FBQyxFQUNoRTtJQUFFRixLQUFLLEVBQUUsbUJBQW1CO0lBQUVDLEdBQUcsRUFBRUEsQ0FBQSxLQUFNQyxTQUFTLENBQUMsU0FBUztFQUFFLENBQUMsRUFDL0Q7SUFBRUYsS0FBSyxFQUFFLFlBQVk7SUFBRUMsR0FBRyxFQUFFQSxDQUFBLEtBQU1DLFNBQVMsQ0FBQyxXQUFXO0VBQUUsQ0FBQyxFQUMxRDtJQUFFRixLQUFLLEVBQUUscUJBQXFCO0lBQUVDLEdBQUcsRUFBRUEsQ0FBQSxLQUFNQyxTQUFTLENBQUMsV0FBVztFQUFFLENBQUMsRUFDbkU7SUFBRUYsS0FBSyxFQUFFLDBCQUEwQjtJQUFFQyxHQUFHLEVBQUVBLENBQUEsS0FBTTtNQUFFVixFQUFFLENBQUNZLE9BQU8sQ0FBQyxDQUFDO01BQUVaLEVBQUUsQ0FBQ0ssY0FBYyxDQUFDLENBQUM7SUFBRTtFQUFFLENBQUMsRUFDeEY7SUFBRUksS0FBSyxFQUFFLHlCQUF5QjtJQUFFQyxHQUFHLEVBQUVBLENBQUEsS0FBTTtNQUFFVixFQUFFLENBQUNhLGFBQWEsQ0FBQyxDQUFDO01BQUViLEVBQUUsQ0FBQ0ssY0FBYyxDQUFDLENBQUM7SUFBRTtFQUFFLENBQUMsQ0FDOUY7RUFFRCxTQUFTTSxTQUFTQSxDQUFDRyxDQUFhLEVBQUU7SUFDaENkLEVBQUUsQ0FBQ1csU0FBUyxDQUFDRyxDQUFDLENBQUM7SUFDZmQsRUFBRSxDQUFDSyxjQUFjLENBQUMsQ0FBQztFQUNyQjtFQUVBLG9CQUNFLElBQUFaLFdBQUEsQ0FBQXNCLElBQUE7SUFBS0MsS0FBSyxFQUFFO01BQUVDLFFBQVEsRUFBRSxVQUFVO01BQUVDLE1BQU0sRUFBRSxFQUFFO01BQUVDLElBQUksRUFBRSxFQUFFO01BQUVDLE1BQU0sRUFBRTtJQUFHLENBQUU7SUFBQUMsUUFBQSxHQUNwRW5CLFlBQVksZ0JBQ1gsSUFBQVQsV0FBQSxDQUFBc0IsSUFBQTtNQUFLTyxHQUFHLEVBQUVoQixTQUFVO01BQUNpQixRQUFRLEVBQUUsQ0FBQyxDQUFFO01BQUNQLEtBQUssRUFBRTtRQUFFQyxRQUFRLEVBQUUsVUFBVTtRQUFFQyxNQUFNLEVBQUUsRUFBRTtRQUFFQyxJQUFJLEVBQUUsQ0FBQztRQUFFSyxLQUFLLEVBQUUsR0FBRztRQUFFQyxPQUFPLEVBQUUsQ0FBQztRQUFFQyxVQUFVLEVBQUUsY0FBYztRQUFFQyxNQUFNLEVBQUUsdUJBQXVCO1FBQUVDLFlBQVksRUFBRSxFQUFFO1FBQUVDLFNBQVMsRUFBRTtNQUFvQixDQUFFO01BQUFSLFFBQUEsZ0JBQzdOLElBQUE1QixXQUFBLENBQUFxQyxHQUFBO1FBQUtkLEtBQUssRUFBRTtVQUFFZSxJQUFJLEVBQUUsZ0JBQWdCO1VBQUVDLGFBQWEsRUFBRSxPQUFPO1VBQUVDLGFBQWEsRUFBRSxXQUFXO1VBQUVDLEtBQUssRUFBRSxjQUFjO1VBQUVULE9BQU8sRUFBRTtRQUFlLENBQUU7UUFBQUosUUFBQSxFQUFDO01BQXNCLENBQUssQ0FBQyxFQUN2S2IsS0FBSyxDQUFDMkIsR0FBRyxDQUFFQyxDQUFDLGlCQUNYLElBQUEzQyxXQUFBLENBQUFxQyxHQUFBO1FBQXNCTyxPQUFPLEVBQUVELENBQUMsQ0FBQzFCLEdBQUk7UUFBQ00sS0FBSyxFQUFFO1VBQUVzQixPQUFPLEVBQUUsT0FBTztVQUFFZCxLQUFLLEVBQUUsTUFBTTtVQUFFQyxPQUFPLEVBQUUsVUFBVTtVQUFFQyxVQUFVLEVBQUUsTUFBTTtVQUFFQyxNQUFNLEVBQUUsTUFBTTtVQUFFQyxZQUFZLEVBQUUsQ0FBQztVQUFFTSxLQUFLLEVBQUUsWUFBWTtVQUFFSCxJQUFJLEVBQUUsZ0JBQWdCO1VBQUVRLE1BQU0sRUFBRSxTQUFTO1VBQUVDLFNBQVMsRUFBRTtRQUFPLENBQUU7UUFBQW5CLFFBQUEsRUFDM09lLENBQUMsQ0FBQzNCO01BQUssR0FERzJCLENBQUMsQ0FBQzNCLEtBRVAsQ0FDVCxDQUFDO0lBQUEsQ0FDQyxDQUFDLEdBQ0osSUFBSSxlQUNSLElBQUFoQixXQUFBLENBQUFzQixJQUFBO01BQ0VzQixPQUFPLEVBQUVyQyxFQUFFLENBQUNLLGNBQWU7TUFDM0JXLEtBQUssRUFBRTtRQUFFc0IsT0FBTyxFQUFFLE1BQU07UUFBRUcsVUFBVSxFQUFFLFFBQVE7UUFBRUMsR0FBRyxFQUFFLENBQUM7UUFBRWpCLE9BQU8sRUFBRSxVQUFVO1FBQUVDLFVBQVUsRUFBRSxvREFBb0Q7UUFBRUMsTUFBTSxFQUFFLHVCQUF1QjtRQUFFQyxZQUFZLEVBQUUsZUFBZTtRQUFFTSxLQUFLLEVBQUUsY0FBYztRQUFFSCxJQUFJLEVBQUUsZ0JBQWdCO1FBQUVDLGFBQWEsRUFBRSxPQUFPO1FBQUVPLE1BQU0sRUFBRSxTQUFTO1FBQUVJLGNBQWMsRUFBRSxZQUFZO1FBQUVWLGFBQWEsRUFBRTtNQUFZLENBQUU7TUFBQVosUUFBQSxnQkFFcFcsSUFBQTVCLFdBQUEsQ0FBQXFDLEdBQUEsRUFBQ3ZDLEtBQUEsQ0FBQU8sT0FBSTtRQUFDOEMsSUFBSSxFQUFDLFFBQVE7UUFBQ0MsSUFBSSxFQUFFLEVBQUc7UUFBQ0MsV0FBVyxFQUFFO01BQUssQ0FBRSxDQUFDLGVBQ25ELElBQUFyRCxXQUFBLENBQUFxQyxHQUFBO1FBQUFULFFBQUEsRUFBTTtNQUFXLENBQU0sQ0FBQztJQUFBLENBQ2xCLENBQUM7RUFBQSxDQUNOLENBQUM7QUFFVjtBQUFDM0IsRUFBQSxDQTVDUUssUUFBUTtFQUFBLFFBQ0pFLHFCQUFLLEVBS0VNLGtDQUFnQjtBQUFBO0FBQUF3QyxFQUFBLEdBTjNCaEQsUUFBUTtBQUFBLElBQUFpRCxRQUFBLEdBQUFDLE9BQUEsQ0FBQW5ELE9BQUEsR0E4Q0ZDLFFBQVE7QUFBQSxJQUFBZ0QsRUFBQTtBQUFBRyxZQUFBLENBQUFILEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}