var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
require("./index.css");
var _Lodestar = _interopRequireDefault(require("./components/Lodestar"));
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// Root component — immediately.run renders the default export of THIS file.
// Global CSS (design tokens, fonts, full-bleed base) is imported here, not in
// main.tsx, because the runtime never loads main.tsx.

function App() {
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_Lodestar.default, {});
}
_c = App;
var _default = exports.default = App;
var _c;
$RefreshReg$(_c, "App");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJyZXF1aXJlIiwiX0xvZGVzdGFyIiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsIl9qc3hSdW50aW1lIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiQXBwIiwianN4IiwiX2MiLCJfZGVmYXVsdCIsImV4cG9ydHMiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBcHAudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIFJvb3QgY29tcG9uZW50IOKAlCBpbW1lZGlhdGVseS5ydW4gcmVuZGVycyB0aGUgZGVmYXVsdCBleHBvcnQgb2YgVEhJUyBmaWxlLlxuLy8gR2xvYmFsIENTUyAoZGVzaWduIHRva2VucywgZm9udHMsIGZ1bGwtYmxlZWQgYmFzZSkgaXMgaW1wb3J0ZWQgaGVyZSwgbm90IGluXG4vLyBtYWluLnRzeCwgYmVjYXVzZSB0aGUgcnVudGltZSBuZXZlciBsb2FkcyBtYWluLnRzeC5cbmltcG9ydCAnLi9pbmRleC5jc3MnO1xuaW1wb3J0IExvZGVzdGFyIGZyb20gJy4vY29tcG9uZW50cy9Mb2Rlc3Rhcic7XG5cbmZ1bmN0aW9uIEFwcCgpIHtcbiAgcmV0dXJuIDxMb2Rlc3RhciAvPjtcbn1cblxuZXhwb3J0IGRlZmF1bHQgQXBwO1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFHQUEsT0FBQTtBQUNBLElBQUFDLFNBQUEsR0FBQUMsc0JBQUEsQ0FBQUYsT0FBQTtBQUE2QyxJQUFBRyxXQUFBLEdBQUFILE9BQUE7QUFBQSxTQUFBRSx1QkFBQUUsQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQUo3QztBQUNBO0FBQ0E7O0FBSUEsU0FBU0csR0FBR0EsQ0FBQSxFQUFHO0VBQ2Isb0JBQU8sSUFBQUosV0FBQSxDQUFBSyxHQUFBLEVBQUNQLFNBQUEsQ0FBQUssT0FBUSxJQUFFLENBQUM7QUFDckI7QUFBQ0csRUFBQSxHQUZRRixHQUFHO0FBQUEsSUFBQUcsUUFBQSxHQUFBQyxPQUFBLENBQUFMLE9BQUEsR0FJR0MsR0FBRztBQUFBLElBQUFFLEVBQUE7QUFBQUcsWUFBQSxDQUFBSCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}