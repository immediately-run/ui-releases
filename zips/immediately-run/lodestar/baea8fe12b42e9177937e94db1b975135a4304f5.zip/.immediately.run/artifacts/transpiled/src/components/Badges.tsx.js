var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _Icon = _interopRequireDefault(require("./Icon"));
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// Per-object status badges — the "designed, not broken" degraded states
// (DESIGN_BRIEF §1): invalid frontmatter, newer-schema read-only, locked, hidden.
// Non-color signifiers (icon + label) per the a11y note.

function Badges({
  o
}) {
  const items = [];
  if (o.warn) items.push(/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
    title: "Invalid frontmatter",
    style: {
      display: 'inline-flex',
      color: '#7a5b00',
      background: 'rgba(255,200,40,.9)',
      borderRadius: 6,
      padding: 2
    },
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
      name: "alert",
      size: 13,
      color: "#3a2c00",
      strokeWidth: 2
    })
  }, "w"));
  if (o.readonly) items.push(/*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
    title: "Newer schema \u2014 read-only",
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 3,
      color: '#2a2330',
      background: 'rgba(255,255,255,.6)',
      borderRadius: 6,
      padding: '2px 5px',
      font: 'var(--mono-xs)'
    },
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
      name: "lock",
      size: 11,
      color: "#2a2330",
      strokeWidth: 2
    }), "read-only"]
  }, "r"));
  if (o.locked) items.push(/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
    title: "Locked",
    style: {
      display: 'inline-flex',
      color: 'var(--note-ink)',
      opacity: 0.6
    },
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
      name: "lock",
      size: 13,
      strokeWidth: 2
    })
  }, "l"));
  if (o.hidden) items.push(/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
    title: "Hidden",
    style: {
      display: 'inline-flex',
      color: 'var(--note-ink)',
      opacity: 0.6
    },
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
      name: "eyeOff",
      size: 13,
      strokeWidth: 2
    })
  }, "h"));
  if (!items.length) return null;
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    style: {
      position: 'absolute',
      top: 8,
      right: 8,
      display: 'flex',
      gap: 5,
      alignItems: 'center'
    },
    children: items
  });
}
_c = Badges;
var _default = exports.default = Badges;
var _c;
$RefreshReg$(_c, "Badges");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfSWNvbiIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJlIiwiX19lc01vZHVsZSIsImRlZmF1bHQiLCJCYWRnZXMiLCJvIiwiaXRlbXMiLCJ3YXJuIiwicHVzaCIsImpzeCIsInRpdGxlIiwic3R5bGUiLCJkaXNwbGF5IiwiY29sb3IiLCJiYWNrZ3JvdW5kIiwiYm9yZGVyUmFkaXVzIiwicGFkZGluZyIsImNoaWxkcmVuIiwibmFtZSIsInNpemUiLCJzdHJva2VXaWR0aCIsInJlYWRvbmx5IiwianN4cyIsImFsaWduSXRlbXMiLCJnYXAiLCJmb250IiwibG9ja2VkIiwib3BhY2l0eSIsImhpZGRlbiIsImxlbmd0aCIsInBvc2l0aW9uIiwidG9wIiwicmlnaHQiLCJfYyIsIl9kZWZhdWx0IiwiZXhwb3J0cyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkJhZGdlcy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gUGVyLW9iamVjdCBzdGF0dXMgYmFkZ2VzIOKAlCB0aGUgXCJkZXNpZ25lZCwgbm90IGJyb2tlblwiIGRlZ3JhZGVkIHN0YXRlc1xuLy8gKERFU0lHTl9CUklFRiDCpzEpOiBpbnZhbGlkIGZyb250bWF0dGVyLCBuZXdlci1zY2hlbWEgcmVhZC1vbmx5LCBsb2NrZWQsIGhpZGRlbi5cbi8vIE5vbi1jb2xvciBzaWduaWZpZXJzIChpY29uICsgbGFiZWwpIHBlciB0aGUgYTExeSBub3RlLlxuXG5pbXBvcnQgSWNvbiBmcm9tICcuL0ljb24nO1xuaW1wb3J0IHR5cGUgeyBXT2JqZWN0IH0gZnJvbSAnLi4vbGliL3R5cGVzJztcblxuZnVuY3Rpb24gQmFkZ2VzKHsgbyB9OiB7IG86IFdPYmplY3QgfSkge1xuICBjb25zdCBpdGVtcyA9IFtdO1xuICBpZiAoby53YXJuKVxuICAgIGl0ZW1zLnB1c2goXG4gICAgICA8c3BhblxuICAgICAgICBrZXk9XCJ3XCJcbiAgICAgICAgdGl0bGU9XCJJbnZhbGlkIGZyb250bWF0dGVyXCJcbiAgICAgICAgc3R5bGU9e3sgZGlzcGxheTogJ2lubGluZS1mbGV4JywgY29sb3I6ICcjN2E1YjAwJywgYmFja2dyb3VuZDogJ3JnYmEoMjU1LDIwMCw0MCwuOSknLCBib3JkZXJSYWRpdXM6IDYsIHBhZGRpbmc6IDIgfX1cbiAgICAgID5cbiAgICAgICAgPEljb24gbmFtZT1cImFsZXJ0XCIgc2l6ZT17MTN9IGNvbG9yPVwiIzNhMmMwMFwiIHN0cm9rZVdpZHRoPXsyfSAvPlxuICAgICAgPC9zcGFuPixcbiAgICApO1xuICBpZiAoby5yZWFkb25seSlcbiAgICBpdGVtcy5wdXNoKFxuICAgICAgPHNwYW5cbiAgICAgICAga2V5PVwiclwiXG4gICAgICAgIHRpdGxlPVwiTmV3ZXIgc2NoZW1hIOKAlCByZWFkLW9ubHlcIlxuICAgICAgICBzdHlsZT17e1xuICAgICAgICAgIGRpc3BsYXk6ICdpbmxpbmUtZmxleCcsXG4gICAgICAgICAgYWxpZ25JdGVtczogJ2NlbnRlcicsXG4gICAgICAgICAgZ2FwOiAzLFxuICAgICAgICAgIGNvbG9yOiAnIzJhMjMzMCcsXG4gICAgICAgICAgYmFja2dyb3VuZDogJ3JnYmEoMjU1LDI1NSwyNTUsLjYpJyxcbiAgICAgICAgICBib3JkZXJSYWRpdXM6IDYsXG4gICAgICAgICAgcGFkZGluZzogJzJweCA1cHgnLFxuICAgICAgICAgIGZvbnQ6ICd2YXIoLS1tb25vLXhzKScsXG4gICAgICAgIH19XG4gICAgICA+XG4gICAgICAgIDxJY29uIG5hbWU9XCJsb2NrXCIgc2l6ZT17MTF9IGNvbG9yPVwiIzJhMjMzMFwiIHN0cm9rZVdpZHRoPXsyfSAvPlxuICAgICAgICByZWFkLW9ubHlcbiAgICAgIDwvc3Bhbj4sXG4gICAgKTtcbiAgaWYgKG8ubG9ja2VkKVxuICAgIGl0ZW1zLnB1c2goXG4gICAgICA8c3BhbiBrZXk9XCJsXCIgdGl0bGU9XCJMb2NrZWRcIiBzdHlsZT17eyBkaXNwbGF5OiAnaW5saW5lLWZsZXgnLCBjb2xvcjogJ3ZhcigtLW5vdGUtaW5rKScsIG9wYWNpdHk6IDAuNiB9fT5cbiAgICAgICAgPEljb24gbmFtZT1cImxvY2tcIiBzaXplPXsxM30gc3Ryb2tlV2lkdGg9ezJ9IC8+XG4gICAgICA8L3NwYW4+LFxuICAgICk7XG4gIGlmIChvLmhpZGRlbilcbiAgICBpdGVtcy5wdXNoKFxuICAgICAgPHNwYW4ga2V5PVwiaFwiIHRpdGxlPVwiSGlkZGVuXCIgc3R5bGU9e3sgZGlzcGxheTogJ2lubGluZS1mbGV4JywgY29sb3I6ICd2YXIoLS1ub3RlLWluayknLCBvcGFjaXR5OiAwLjYgfX0+XG4gICAgICAgIDxJY29uIG5hbWU9XCJleWVPZmZcIiBzaXplPXsxM30gc3Ryb2tlV2lkdGg9ezJ9IC8+XG4gICAgICA8L3NwYW4+LFxuICAgICk7XG4gIGlmICghaXRlbXMubGVuZ3RoKSByZXR1cm4gbnVsbDtcbiAgcmV0dXJuIDxkaXYgc3R5bGU9e3sgcG9zaXRpb246ICdhYnNvbHV0ZScsIHRvcDogOCwgcmlnaHQ6IDgsIGRpc3BsYXk6ICdmbGV4JywgZ2FwOiA1LCBhbGlnbkl0ZW1zOiAnY2VudGVyJyB9fT57aXRlbXN9PC9kaXY+O1xufVxuXG5leHBvcnQgZGVmYXVsdCBCYWRnZXM7XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUlBLElBQUFBLEtBQUEsR0FBQUMsc0JBQUEsQ0FBQUMsT0FBQTtBQUEwQixJQUFBQyxXQUFBLEdBQUFELE9BQUE7QUFBQSxTQUFBRCx1QkFBQUcsQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQUoxQjtBQUNBO0FBQ0E7O0FBS0EsU0FBU0csTUFBTUEsQ0FBQztFQUFFQztBQUFrQixDQUFDLEVBQUU7RUFDckMsTUFBTUMsS0FBSyxHQUFHLEVBQUU7RUFDaEIsSUFBSUQsQ0FBQyxDQUFDRSxJQUFJLEVBQ1JELEtBQUssQ0FBQ0UsSUFBSSxjQUNSLElBQUFSLFdBQUEsQ0FBQVMsR0FBQTtJQUVFQyxLQUFLLEVBQUMscUJBQXFCO0lBQzNCQyxLQUFLLEVBQUU7TUFBRUMsT0FBTyxFQUFFLGFBQWE7TUFBRUMsS0FBSyxFQUFFLFNBQVM7TUFBRUMsVUFBVSxFQUFFLHFCQUFxQjtNQUFFQyxZQUFZLEVBQUUsQ0FBQztNQUFFQyxPQUFPLEVBQUU7SUFBRSxDQUFFO0lBQUFDLFFBQUEsZUFFcEgsSUFBQWpCLFdBQUEsQ0FBQVMsR0FBQSxFQUFDWixLQUFBLENBQUFNLE9BQUk7TUFBQ2UsSUFBSSxFQUFDLE9BQU87TUFBQ0MsSUFBSSxFQUFFLEVBQUc7TUFBQ04sS0FBSyxFQUFDLFNBQVM7TUFBQ08sV0FBVyxFQUFFO0lBQUUsQ0FBRTtFQUFDLEdBSjNELEdBS0EsQ0FDUixDQUFDO0VBQ0gsSUFBSWYsQ0FBQyxDQUFDZ0IsUUFBUSxFQUNaZixLQUFLLENBQUNFLElBQUksY0FDUixJQUFBUixXQUFBLENBQUFzQixJQUFBO0lBRUVaLEtBQUssRUFBQywrQkFBMEI7SUFDaENDLEtBQUssRUFBRTtNQUNMQyxPQUFPLEVBQUUsYUFBYTtNQUN0QlcsVUFBVSxFQUFFLFFBQVE7TUFDcEJDLEdBQUcsRUFBRSxDQUFDO01BQ05YLEtBQUssRUFBRSxTQUFTO01BQ2hCQyxVQUFVLEVBQUUsc0JBQXNCO01BQ2xDQyxZQUFZLEVBQUUsQ0FBQztNQUNmQyxPQUFPLEVBQUUsU0FBUztNQUNsQlMsSUFBSSxFQUFFO0lBQ1IsQ0FBRTtJQUFBUixRQUFBLGdCQUVGLElBQUFqQixXQUFBLENBQUFTLEdBQUEsRUFBQ1osS0FBQSxDQUFBTSxPQUFJO01BQUNlLElBQUksRUFBQyxNQUFNO01BQUNDLElBQUksRUFBRSxFQUFHO01BQUNOLEtBQUssRUFBQyxTQUFTO01BQUNPLFdBQVcsRUFBRTtJQUFFLENBQUUsQ0FBQyxhQUVoRTtFQUFBLEdBZk0sR0FlQSxDQUNSLENBQUM7RUFDSCxJQUFJZixDQUFDLENBQUNxQixNQUFNLEVBQ1ZwQixLQUFLLENBQUNFLElBQUksY0FDUixJQUFBUixXQUFBLENBQUFTLEdBQUE7SUFBY0MsS0FBSyxFQUFDLFFBQVE7SUFBQ0MsS0FBSyxFQUFFO01BQUVDLE9BQU8sRUFBRSxhQUFhO01BQUVDLEtBQUssRUFBRSxpQkFBaUI7TUFBRWMsT0FBTyxFQUFFO0lBQUksQ0FBRTtJQUFBVixRQUFBLGVBQ3JHLElBQUFqQixXQUFBLENBQUFTLEdBQUEsRUFBQ1osS0FBQSxDQUFBTSxPQUFJO01BQUNlLElBQUksRUFBQyxNQUFNO01BQUNDLElBQUksRUFBRSxFQUFHO01BQUNDLFdBQVcsRUFBRTtJQUFFLENBQUU7RUFBQyxHQUR0QyxHQUVKLENBQ1IsQ0FBQztFQUNILElBQUlmLENBQUMsQ0FBQ3VCLE1BQU0sRUFDVnRCLEtBQUssQ0FBQ0UsSUFBSSxjQUNSLElBQUFSLFdBQUEsQ0FBQVMsR0FBQTtJQUFjQyxLQUFLLEVBQUMsUUFBUTtJQUFDQyxLQUFLLEVBQUU7TUFBRUMsT0FBTyxFQUFFLGFBQWE7TUFBRUMsS0FBSyxFQUFFLGlCQUFpQjtNQUFFYyxPQUFPLEVBQUU7SUFBSSxDQUFFO0lBQUFWLFFBQUEsZUFDckcsSUFBQWpCLFdBQUEsQ0FBQVMsR0FBQSxFQUFDWixLQUFBLENBQUFNLE9BQUk7TUFBQ2UsSUFBSSxFQUFDLFFBQVE7TUFBQ0MsSUFBSSxFQUFFLEVBQUc7TUFBQ0MsV0FBVyxFQUFFO0lBQUUsQ0FBRTtFQUFDLEdBRHhDLEdBRUosQ0FDUixDQUFDO0VBQ0gsSUFBSSxDQUFDZCxLQUFLLENBQUN1QixNQUFNLEVBQUUsT0FBTyxJQUFJO0VBQzlCLG9CQUFPLElBQUE3QixXQUFBLENBQUFTLEdBQUE7SUFBS0UsS0FBSyxFQUFFO01BQUVtQixRQUFRLEVBQUUsVUFBVTtNQUFFQyxHQUFHLEVBQUUsQ0FBQztNQUFFQyxLQUFLLEVBQUUsQ0FBQztNQUFFcEIsT0FBTyxFQUFFLE1BQU07TUFBRVksR0FBRyxFQUFFLENBQUM7TUFBRUQsVUFBVSxFQUFFO0lBQVMsQ0FBRTtJQUFBTixRQUFBLEVBQUVYO0VBQUssQ0FBTSxDQUFDO0FBQzdIO0FBQUMyQixFQUFBLEdBOUNRN0IsTUFBTTtBQUFBLElBQUE4QixRQUFBLEdBQUFDLE9BQUEsQ0FBQWhDLE9BQUEsR0FnREFDLE1BQU07QUFBQSxJQUFBNkIsRUFBQTtBQUFBRyxZQUFBLENBQUFILEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}