var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _jsxRuntime = require("react/jsx-runtime");
// A titled grouping rectangle behind its contents (spec §3.4 — visual only; no
// grouping semantics in v1, §9). The title chip rides the top hairline.

function CanvasFrame({
  o
}) {
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    style: {
      position: 'absolute',
      inset: 0,
      border: '1px solid var(--line-2)',
      borderRadius: 14,
      background: 'color-mix(in oklab, var(--panel) 28%, transparent)'
    },
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      style: {
        position: 'absolute',
        top: -13,
        left: 14,
        display: 'flex',
        alignItems: 'center',
        gap: 6,
        padding: '3px 11px',
        background: 'var(--panel)',
        border: '1px solid var(--line-2)',
        borderRadius: 'var(--r-pill)',
        font: 'var(--mono-xs)',
        letterSpacing: '.05em',
        textTransform: 'uppercase',
        color: 'var(--ink-2)'
      },
      children: o.title
    })
  });
}
_c = CanvasFrame;
var _default = exports.default = CanvasFrame;
var _c;
$RefreshReg$(_c, "CanvasFrame");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJDYW52YXNGcmFtZSIsIm8iLCJfanN4UnVudGltZSIsImpzeCIsInN0eWxlIiwicG9zaXRpb24iLCJpbnNldCIsImJvcmRlciIsImJvcmRlclJhZGl1cyIsImJhY2tncm91bmQiLCJjaGlsZHJlbiIsInRvcCIsImxlZnQiLCJkaXNwbGF5IiwiYWxpZ25JdGVtcyIsImdhcCIsInBhZGRpbmciLCJmb250IiwibGV0dGVyU3BhY2luZyIsInRleHRUcmFuc2Zvcm0iLCJjb2xvciIsInRpdGxlIiwiX2MiLCJfZGVmYXVsdCIsImV4cG9ydHMiLCJkZWZhdWx0IiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQ2FudmFzRnJhbWUudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIEEgdGl0bGVkIGdyb3VwaW5nIHJlY3RhbmdsZSBiZWhpbmQgaXRzIGNvbnRlbnRzIChzcGVjIMKnMy40IOKAlCB2aXN1YWwgb25seTsgbm9cbi8vIGdyb3VwaW5nIHNlbWFudGljcyBpbiB2MSwgwqc5KS4gVGhlIHRpdGxlIGNoaXAgcmlkZXMgdGhlIHRvcCBoYWlybGluZS5cblxuaW1wb3J0IHR5cGUgeyBXT2JqZWN0IH0gZnJvbSAnLi4vLi4vbGliL3R5cGVzJztcblxuZnVuY3Rpb24gQ2FudmFzRnJhbWUoeyBvIH06IHsgbzogV09iamVjdCB9KSB7XG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgc3R5bGU9e3tcbiAgICAgICAgcG9zaXRpb246ICdhYnNvbHV0ZScsXG4gICAgICAgIGluc2V0OiAwLFxuICAgICAgICBib3JkZXI6ICcxcHggc29saWQgdmFyKC0tbGluZS0yKScsXG4gICAgICAgIGJvcmRlclJhZGl1czogMTQsXG4gICAgICAgIGJhY2tncm91bmQ6ICdjb2xvci1taXgoaW4gb2tsYWIsIHZhcigtLXBhbmVsKSAyOCUsIHRyYW5zcGFyZW50KScsXG4gICAgICB9fVxuICAgID5cbiAgICAgIDxkaXZcbiAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICBwb3NpdGlvbjogJ2Fic29sdXRlJyxcbiAgICAgICAgICB0b3A6IC0xMyxcbiAgICAgICAgICBsZWZ0OiAxNCxcbiAgICAgICAgICBkaXNwbGF5OiAnZmxleCcsXG4gICAgICAgICAgYWxpZ25JdGVtczogJ2NlbnRlcicsXG4gICAgICAgICAgZ2FwOiA2LFxuICAgICAgICAgIHBhZGRpbmc6ICczcHggMTFweCcsXG4gICAgICAgICAgYmFja2dyb3VuZDogJ3ZhcigtLXBhbmVsKScsXG4gICAgICAgICAgYm9yZGVyOiAnMXB4IHNvbGlkIHZhcigtLWxpbmUtMiknLFxuICAgICAgICAgIGJvcmRlclJhZGl1czogJ3ZhcigtLXItcGlsbCknLFxuICAgICAgICAgIGZvbnQ6ICd2YXIoLS1tb25vLXhzKScsXG4gICAgICAgICAgbGV0dGVyU3BhY2luZzogJy4wNWVtJyxcbiAgICAgICAgICB0ZXh0VHJhbnNmb3JtOiAndXBwZXJjYXNlJyxcbiAgICAgICAgICBjb2xvcjogJ3ZhcigtLWluay0yKScsXG4gICAgICAgIH19XG4gICAgICA+XG4gICAgICAgIHtvLnRpdGxlfVxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IENhbnZhc0ZyYW1lO1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQUE7QUFDQTs7QUFJQSxTQUFTQSxXQUFXQSxDQUFDO0VBQUVDO0FBQWtCLENBQUMsRUFBRTtFQUMxQyxvQkFDRSxJQUFBQyxXQUFBLENBQUFDLEdBQUE7SUFDRUMsS0FBSyxFQUFFO01BQ0xDLFFBQVEsRUFBRSxVQUFVO01BQ3BCQyxLQUFLLEVBQUUsQ0FBQztNQUNSQyxNQUFNLEVBQUUseUJBQXlCO01BQ2pDQyxZQUFZLEVBQUUsRUFBRTtNQUNoQkMsVUFBVSxFQUFFO0lBQ2QsQ0FBRTtJQUFBQyxRQUFBLGVBRUYsSUFBQVIsV0FBQSxDQUFBQyxHQUFBO01BQ0VDLEtBQUssRUFBRTtRQUNMQyxRQUFRLEVBQUUsVUFBVTtRQUNwQk0sR0FBRyxFQUFFLENBQUMsRUFBRTtRQUNSQyxJQUFJLEVBQUUsRUFBRTtRQUNSQyxPQUFPLEVBQUUsTUFBTTtRQUNmQyxVQUFVLEVBQUUsUUFBUTtRQUNwQkMsR0FBRyxFQUFFLENBQUM7UUFDTkMsT0FBTyxFQUFFLFVBQVU7UUFDbkJQLFVBQVUsRUFBRSxjQUFjO1FBQzFCRixNQUFNLEVBQUUseUJBQXlCO1FBQ2pDQyxZQUFZLEVBQUUsZUFBZTtRQUM3QlMsSUFBSSxFQUFFLGdCQUFnQjtRQUN0QkMsYUFBYSxFQUFFLE9BQU87UUFDdEJDLGFBQWEsRUFBRSxXQUFXO1FBQzFCQyxLQUFLLEVBQUU7TUFDVCxDQUFFO01BQUFWLFFBQUEsRUFFRFQsQ0FBQyxDQUFDb0I7SUFBSyxDQUNMO0VBQUMsQ0FDSCxDQUFDO0FBRVY7QUFBQ0MsRUFBQSxHQWpDUXRCLFdBQVc7QUFBQSxJQUFBdUIsUUFBQSxHQUFBQyxPQUFBLENBQUFDLE9BQUEsR0FtQ0x6QixXQUFXO0FBQUEsSUFBQXNCLEVBQUE7QUFBQUksWUFBQSxDQUFBSixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}