var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _jsxRuntime = require("react/jsx-runtime");
// Large canvas text (spec §3.4), painted with the signature gradient.

function CanvasLabel({
  o
}) {
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    style: {
      position: 'absolute',
      inset: 0,
      display: 'flex',
      alignItems: 'center'
    },
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      style: {
        font: '800 76px/.9 var(--disp)',
        letterSpacing: '-.04em',
        background: 'var(--grad)',
        WebkitBackgroundClip: 'text',
        backgroundClip: 'text',
        color: 'transparent',
        whiteSpace: 'nowrap'
      },
      children: o.title
    })
  });
}
_c = CanvasLabel;
var _default = exports.default = CanvasLabel;
var _c;
$RefreshReg$(_c, "CanvasLabel");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJDYW52YXNMYWJlbCIsIm8iLCJfanN4UnVudGltZSIsImpzeCIsInN0eWxlIiwicG9zaXRpb24iLCJpbnNldCIsImRpc3BsYXkiLCJhbGlnbkl0ZW1zIiwiY2hpbGRyZW4iLCJmb250IiwibGV0dGVyU3BhY2luZyIsImJhY2tncm91bmQiLCJXZWJraXRCYWNrZ3JvdW5kQ2xpcCIsImJhY2tncm91bmRDbGlwIiwiY29sb3IiLCJ3aGl0ZVNwYWNlIiwidGl0bGUiLCJfYyIsIl9kZWZhdWx0IiwiZXhwb3J0cyIsImRlZmF1bHQiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJDYW52YXNMYWJlbC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gTGFyZ2UgY2FudmFzIHRleHQgKHNwZWMgwqczLjQpLCBwYWludGVkIHdpdGggdGhlIHNpZ25hdHVyZSBncmFkaWVudC5cblxuaW1wb3J0IHR5cGUgeyBXT2JqZWN0IH0gZnJvbSAnLi4vLi4vbGliL3R5cGVzJztcblxuZnVuY3Rpb24gQ2FudmFzTGFiZWwoeyBvIH06IHsgbzogV09iamVjdCB9KSB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBzdHlsZT17eyBwb3NpdGlvbjogJ2Fic29sdXRlJywgaW5zZXQ6IDAsIGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicgfX0+XG4gICAgICA8ZGl2XG4gICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgZm9udDogJzgwMCA3NnB4Ly45IHZhcigtLWRpc3ApJyxcbiAgICAgICAgICBsZXR0ZXJTcGFjaW5nOiAnLS4wNGVtJyxcbiAgICAgICAgICBiYWNrZ3JvdW5kOiAndmFyKC0tZ3JhZCknLFxuICAgICAgICAgIFdlYmtpdEJhY2tncm91bmRDbGlwOiAndGV4dCcsXG4gICAgICAgICAgYmFja2dyb3VuZENsaXA6ICd0ZXh0JyxcbiAgICAgICAgICBjb2xvcjogJ3RyYW5zcGFyZW50JyxcbiAgICAgICAgICB3aGl0ZVNwYWNlOiAnbm93cmFwJyxcbiAgICAgICAgfX1cbiAgICAgID5cbiAgICAgICAge28udGl0bGV9XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgQ2FudmFzTGFiZWw7XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFBQTs7QUFJQSxTQUFTQSxXQUFXQSxDQUFDO0VBQUVDO0FBQWtCLENBQUMsRUFBRTtFQUMxQyxvQkFDRSxJQUFBQyxXQUFBLENBQUFDLEdBQUE7SUFBS0MsS0FBSyxFQUFFO01BQUVDLFFBQVEsRUFBRSxVQUFVO01BQUVDLEtBQUssRUFBRSxDQUFDO01BQUVDLE9BQU8sRUFBRSxNQUFNO01BQUVDLFVBQVUsRUFBRTtJQUFTLENBQUU7SUFBQUMsUUFBQSxlQUNwRixJQUFBUCxXQUFBLENBQUFDLEdBQUE7TUFDRUMsS0FBSyxFQUFFO1FBQ0xNLElBQUksRUFBRSx5QkFBeUI7UUFDL0JDLGFBQWEsRUFBRSxRQUFRO1FBQ3ZCQyxVQUFVLEVBQUUsYUFBYTtRQUN6QkMsb0JBQW9CLEVBQUUsTUFBTTtRQUM1QkMsY0FBYyxFQUFFLE1BQU07UUFDdEJDLEtBQUssRUFBRSxhQUFhO1FBQ3BCQyxVQUFVLEVBQUU7TUFDZCxDQUFFO01BQUFQLFFBQUEsRUFFRFIsQ0FBQyxDQUFDZ0I7SUFBSyxDQUNMO0VBQUMsQ0FDSCxDQUFDO0FBRVY7QUFBQ0MsRUFBQSxHQWxCUWxCLFdBQVc7QUFBQSxJQUFBbUIsUUFBQSxHQUFBQyxPQUFBLENBQUFDLE9BQUEsR0FvQkxyQixXQUFXO0FBQUEsSUFBQWtCLEVBQUE7QUFBQUksWUFBQSxDQUFBSixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}