var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _useLodestarCtx = require("../../hooks/useLodestarCtx");
var _Icon = _interopRequireDefault(require("../Icon"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The security surface (spec §8.4, DESIGN_BRIEF §1): an external embed renders
// CLICK-TO-LOAD. Nothing reaches the outside site until the viewer deliberately
// acts; the target origin is shown prominently first, and the copy names exactly
// what loading exposes (your IP + that you opened this board). This is the v1
// mitigation for the one residual exfiltration channel.
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function EmbedObject({
  o
}) {
  _s();
  const wb = (0, _useLodestarCtx.useWb)();
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    style: {
      position: 'absolute',
      inset: 0,
      borderRadius: 12,
      overflow: 'hidden',
      background: 'var(--panel-2)',
      border: '1px dashed var(--line-2)',
      padding: 16,
      display: 'flex',
      flexDirection: 'column',
      gap: 10,
      justifyContent: 'center'
    },
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 7,
        color: 'var(--ink-2)',
        font: 'var(--mono-xs)',
        letterSpacing: '.05em',
        textTransform: 'uppercase'
      },
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
        name: "externalLink",
        size: 13,
        strokeWidth: 1.75
      }), "External embed"]
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      style: {
        font: '700 17px/1.1 var(--mono)',
        color: 'var(--ink)',
        wordBreak: 'break-all'
      },
      children: o.origin
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      style: {
        font: 'var(--body-sm)',
        color: 'var(--ink-3)',
        textWrap: 'pretty'
      },
      children: "Loads from an outside site, which can see your IP address and that you opened this board."
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
      onClick: e => {
        e.stopPropagation();
        wb.patchObject(o.id, {
          loadedEmbed: true
        });
      },
      style: {
        alignSelf: 'flex-start',
        display: 'inline-flex',
        alignItems: 'center',
        gap: 7,
        padding: '7px 13px',
        background: o.loadedEmbed ? 'var(--panel)' : 'var(--ink)',
        color: o.loadedEmbed ? 'var(--ink-2)' : 'var(--bg)',
        border: '1px solid var(--line-2)',
        borderRadius: 'var(--r-pill)',
        font: 'var(--label)',
        cursor: 'pointer'
      },
      children: o.loadedEmbed ? 'Loaded' : `Load ${o.origin}`
    })]
  });
}
_s(EmbedObject, "VeUy8AIV4bR/U9OnzH43HThc4KU=", false, function () {
  return [_useLodestarCtx.useWb];
});
_c = EmbedObject;
var _default = exports.default = EmbedObject;
var _c;
$RefreshReg$(_c, "EmbedObject");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdXNlTG9kZXN0YXJDdHgiLCJyZXF1aXJlIiwiX0ljb24iLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsIkVtYmVkT2JqZWN0IiwibyIsIndiIiwidXNlV2IiLCJqc3hzIiwic3R5bGUiLCJwb3NpdGlvbiIsImluc2V0IiwiYm9yZGVyUmFkaXVzIiwib3ZlcmZsb3ciLCJiYWNrZ3JvdW5kIiwiYm9yZGVyIiwicGFkZGluZyIsImRpc3BsYXkiLCJmbGV4RGlyZWN0aW9uIiwiZ2FwIiwianVzdGlmeUNvbnRlbnQiLCJjaGlsZHJlbiIsImFsaWduSXRlbXMiLCJjb2xvciIsImZvbnQiLCJsZXR0ZXJTcGFjaW5nIiwidGV4dFRyYW5zZm9ybSIsImpzeCIsIm5hbWUiLCJzaXplIiwic3Ryb2tlV2lkdGgiLCJ3b3JkQnJlYWsiLCJvcmlnaW4iLCJ0ZXh0V3JhcCIsIm9uQ2xpY2siLCJzdG9wUHJvcGFnYXRpb24iLCJwYXRjaE9iamVjdCIsImlkIiwibG9hZGVkRW1iZWQiLCJhbGlnblNlbGYiLCJjdXJzb3IiLCJfYyIsIl9kZWZhdWx0IiwiZXhwb3J0cyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkVtYmVkT2JqZWN0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBUaGUgc2VjdXJpdHkgc3VyZmFjZSAoc3BlYyDCpzguNCwgREVTSUdOX0JSSUVGIMKnMSk6IGFuIGV4dGVybmFsIGVtYmVkIHJlbmRlcnNcbi8vIENMSUNLLVRPLUxPQUQuIE5vdGhpbmcgcmVhY2hlcyB0aGUgb3V0c2lkZSBzaXRlIHVudGlsIHRoZSB2aWV3ZXIgZGVsaWJlcmF0ZWx5XG4vLyBhY3RzOyB0aGUgdGFyZ2V0IG9yaWdpbiBpcyBzaG93biBwcm9taW5lbnRseSBmaXJzdCwgYW5kIHRoZSBjb3B5IG5hbWVzIGV4YWN0bHlcbi8vIHdoYXQgbG9hZGluZyBleHBvc2VzICh5b3VyIElQICsgdGhhdCB5b3Ugb3BlbmVkIHRoaXMgYm9hcmQpLiBUaGlzIGlzIHRoZSB2MVxuLy8gbWl0aWdhdGlvbiBmb3IgdGhlIG9uZSByZXNpZHVhbCBleGZpbHRyYXRpb24gY2hhbm5lbC5cblxuaW1wb3J0IHsgdXNlV2IgfSBmcm9tICcuLi8uLi9ob29rcy91c2VMb2Rlc3RhckN0eCc7XG5pbXBvcnQgSWNvbiBmcm9tICcuLi9JY29uJztcbmltcG9ydCB0eXBlIHsgV09iamVjdCB9IGZyb20gJy4uLy4uL2xpYi90eXBlcyc7XG5cbmZ1bmN0aW9uIEVtYmVkT2JqZWN0KHsgbyB9OiB7IG86IFdPYmplY3QgfSkge1xuICBjb25zdCB3YiA9IHVzZVdiKCk7XG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgc3R5bGU9e3tcbiAgICAgICAgcG9zaXRpb246ICdhYnNvbHV0ZScsXG4gICAgICAgIGluc2V0OiAwLFxuICAgICAgICBib3JkZXJSYWRpdXM6IDEyLFxuICAgICAgICBvdmVyZmxvdzogJ2hpZGRlbicsXG4gICAgICAgIGJhY2tncm91bmQ6ICd2YXIoLS1wYW5lbC0yKScsXG4gICAgICAgIGJvcmRlcjogJzFweCBkYXNoZWQgdmFyKC0tbGluZS0yKScsXG4gICAgICAgIHBhZGRpbmc6IDE2LFxuICAgICAgICBkaXNwbGF5OiAnZmxleCcsXG4gICAgICAgIGZsZXhEaXJlY3Rpb246ICdjb2x1bW4nLFxuICAgICAgICBnYXA6IDEwLFxuICAgICAgICBqdXN0aWZ5Q29udGVudDogJ2NlbnRlcicsXG4gICAgICB9fVxuICAgID5cbiAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywgZ2FwOiA3LCBjb2xvcjogJ3ZhcigtLWluay0yKScsIGZvbnQ6ICd2YXIoLS1tb25vLXhzKScsIGxldHRlclNwYWNpbmc6ICcuMDVlbScsIHRleHRUcmFuc2Zvcm06ICd1cHBlcmNhc2UnIH19PlxuICAgICAgICA8SWNvbiBuYW1lPVwiZXh0ZXJuYWxMaW5rXCIgc2l6ZT17MTN9IHN0cm9rZVdpZHRoPXsxLjc1fSAvPlxuICAgICAgICBFeHRlcm5hbCBlbWJlZFxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IHN0eWxlPXt7IGZvbnQ6ICc3MDAgMTdweC8xLjEgdmFyKC0tbW9ubyknLCBjb2xvcjogJ3ZhcigtLWluayknLCB3b3JkQnJlYWs6ICdicmVhay1hbGwnIH19PntvLm9yaWdpbn08L2Rpdj5cbiAgICAgIDxkaXYgc3R5bGU9e3sgZm9udDogJ3ZhcigtLWJvZHktc20pJywgY29sb3I6ICd2YXIoLS1pbmstMyknLCB0ZXh0V3JhcDogJ3ByZXR0eScgfX0+XG4gICAgICAgIExvYWRzIGZyb20gYW4gb3V0c2lkZSBzaXRlLCB3aGljaCBjYW4gc2VlIHlvdXIgSVAgYWRkcmVzcyBhbmQgdGhhdCB5b3Ugb3BlbmVkIHRoaXMgYm9hcmQuXG4gICAgICA8L2Rpdj5cbiAgICAgIDxidXR0b25cbiAgICAgICAgb25DbGljaz17KGUpID0+IHtcbiAgICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgICAgIHdiLnBhdGNoT2JqZWN0KG8uaWQsIHsgbG9hZGVkRW1iZWQ6IHRydWUgfSk7XG4gICAgICAgIH19XG4gICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgYWxpZ25TZWxmOiAnZmxleC1zdGFydCcsXG4gICAgICAgICAgZGlzcGxheTogJ2lubGluZS1mbGV4JyxcbiAgICAgICAgICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcbiAgICAgICAgICBnYXA6IDcsXG4gICAgICAgICAgcGFkZGluZzogJzdweCAxM3B4JyxcbiAgICAgICAgICBiYWNrZ3JvdW5kOiBvLmxvYWRlZEVtYmVkID8gJ3ZhcigtLXBhbmVsKScgOiAndmFyKC0taW5rKScsXG4gICAgICAgICAgY29sb3I6IG8ubG9hZGVkRW1iZWQgPyAndmFyKC0taW5rLTIpJyA6ICd2YXIoLS1iZyknLFxuICAgICAgICAgIGJvcmRlcjogJzFweCBzb2xpZCB2YXIoLS1saW5lLTIpJyxcbiAgICAgICAgICBib3JkZXJSYWRpdXM6ICd2YXIoLS1yLXBpbGwpJyxcbiAgICAgICAgICBmb250OiAndmFyKC0tbGFiZWwpJyxcbiAgICAgICAgICBjdXJzb3I6ICdwb2ludGVyJyxcbiAgICAgICAgfX1cbiAgICAgID5cbiAgICAgICAge28ubG9hZGVkRW1iZWQgPyAnTG9hZGVkJyA6IGBMb2FkICR7by5vcmlnaW59YH1cbiAgICAgIDwvYnV0dG9uPlxuICAgIDwvZGl2PlxuICApO1xufVxuXG5leHBvcnQgZGVmYXVsdCBFbWJlZE9iamVjdDtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBTUEsSUFBQUEsZUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsS0FBQSxHQUFBQyxzQkFBQSxDQUFBRixPQUFBO0FBQTJCLElBQUFHLFdBQUEsR0FBQUgsT0FBQTtBQUFBLElBQUFJLEVBQUEsR0FBQUMsWUFBQSxJQVAzQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQUEsU0FBQUgsdUJBQUFJLENBQUEsV0FBQUEsQ0FBQSxJQUFBQSxDQUFBLENBQUFDLFVBQUEsR0FBQUQsQ0FBQSxLQUFBRSxPQUFBLEVBQUFGLENBQUE7QUFNQSxTQUFTRyxXQUFXQSxDQUFDO0VBQUVDO0FBQWtCLENBQUMsRUFBRTtFQUFBTixFQUFBO0VBQzFDLE1BQU1PLEVBQUUsR0FBRyxJQUFBQyxxQkFBSyxFQUFDLENBQUM7RUFDbEIsb0JBQ0UsSUFBQVQsV0FBQSxDQUFBVSxJQUFBO0lBQ0VDLEtBQUssRUFBRTtNQUNMQyxRQUFRLEVBQUUsVUFBVTtNQUNwQkMsS0FBSyxFQUFFLENBQUM7TUFDUkMsWUFBWSxFQUFFLEVBQUU7TUFDaEJDLFFBQVEsRUFBRSxRQUFRO01BQ2xCQyxVQUFVLEVBQUUsZ0JBQWdCO01BQzVCQyxNQUFNLEVBQUUsMEJBQTBCO01BQ2xDQyxPQUFPLEVBQUUsRUFBRTtNQUNYQyxPQUFPLEVBQUUsTUFBTTtNQUNmQyxhQUFhLEVBQUUsUUFBUTtNQUN2QkMsR0FBRyxFQUFFLEVBQUU7TUFDUEMsY0FBYyxFQUFFO0lBQ2xCLENBQUU7SUFBQUMsUUFBQSxnQkFFRixJQUFBdkIsV0FBQSxDQUFBVSxJQUFBO01BQUtDLEtBQUssRUFBRTtRQUFFUSxPQUFPLEVBQUUsTUFBTTtRQUFFSyxVQUFVLEVBQUUsUUFBUTtRQUFFSCxHQUFHLEVBQUUsQ0FBQztRQUFFSSxLQUFLLEVBQUUsY0FBYztRQUFFQyxJQUFJLEVBQUUsZ0JBQWdCO1FBQUVDLGFBQWEsRUFBRSxPQUFPO1FBQUVDLGFBQWEsRUFBRTtNQUFZLENBQUU7TUFBQUwsUUFBQSxnQkFDL0osSUFBQXZCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQy9CLEtBQUEsQ0FBQU8sT0FBSTtRQUFDeUIsSUFBSSxFQUFDLGNBQWM7UUFBQ0MsSUFBSSxFQUFFLEVBQUc7UUFBQ0MsV0FBVyxFQUFFO01BQUssQ0FBRSxDQUFDLGtCQUUzRDtJQUFBLENBQUssQ0FBQyxlQUNOLElBQUFoQyxXQUFBLENBQUE2QixHQUFBO01BQUtsQixLQUFLLEVBQUU7UUFBRWUsSUFBSSxFQUFFLDBCQUEwQjtRQUFFRCxLQUFLLEVBQUUsWUFBWTtRQUFFUSxTQUFTLEVBQUU7TUFBWSxDQUFFO01BQUFWLFFBQUEsRUFBRWhCLENBQUMsQ0FBQzJCO0lBQU0sQ0FBTSxDQUFDLGVBQy9HLElBQUFsQyxXQUFBLENBQUE2QixHQUFBO01BQUtsQixLQUFLLEVBQUU7UUFBRWUsSUFBSSxFQUFFLGdCQUFnQjtRQUFFRCxLQUFLLEVBQUUsY0FBYztRQUFFVSxRQUFRLEVBQUU7TUFBUyxDQUFFO01BQUFaLFFBQUEsRUFBQztJQUVuRixDQUFLLENBQUMsZUFDTixJQUFBdkIsV0FBQSxDQUFBNkIsR0FBQTtNQUNFTyxPQUFPLEVBQUdqQyxDQUFDLElBQUs7UUFDZEEsQ0FBQyxDQUFDa0MsZUFBZSxDQUFDLENBQUM7UUFDbkI3QixFQUFFLENBQUM4QixXQUFXLENBQUMvQixDQUFDLENBQUNnQyxFQUFFLEVBQUU7VUFBRUMsV0FBVyxFQUFFO1FBQUssQ0FBQyxDQUFDO01BQzdDLENBQUU7TUFDRjdCLEtBQUssRUFBRTtRQUNMOEIsU0FBUyxFQUFFLFlBQVk7UUFDdkJ0QixPQUFPLEVBQUUsYUFBYTtRQUN0QkssVUFBVSxFQUFFLFFBQVE7UUFDcEJILEdBQUcsRUFBRSxDQUFDO1FBQ05ILE9BQU8sRUFBRSxVQUFVO1FBQ25CRixVQUFVLEVBQUVULENBQUMsQ0FBQ2lDLFdBQVcsR0FBRyxjQUFjLEdBQUcsWUFBWTtRQUN6RGYsS0FBSyxFQUFFbEIsQ0FBQyxDQUFDaUMsV0FBVyxHQUFHLGNBQWMsR0FBRyxXQUFXO1FBQ25EdkIsTUFBTSxFQUFFLHlCQUF5QjtRQUNqQ0gsWUFBWSxFQUFFLGVBQWU7UUFDN0JZLElBQUksRUFBRSxjQUFjO1FBQ3BCZ0IsTUFBTSxFQUFFO01BQ1YsQ0FBRTtNQUFBbkIsUUFBQSxFQUVEaEIsQ0FBQyxDQUFDaUMsV0FBVyxHQUFHLFFBQVEsR0FBRyxRQUFRakMsQ0FBQyxDQUFDMkIsTUFBTTtJQUFFLENBQ3hDLENBQUM7RUFBQSxDQUNOLENBQUM7QUFFVjtBQUFDakMsRUFBQSxDQWpEUUssV0FBVztFQUFBLFFBQ1BHLHFCQUFLO0FBQUE7QUFBQWtDLEVBQUEsR0FEVHJDLFdBQVc7QUFBQSxJQUFBc0MsUUFBQSxHQUFBQyxPQUFBLENBQUF4QyxPQUFBLEdBbURMQyxXQUFXO0FBQUEsSUFBQXFDLEVBQUE7QUFBQUcsWUFBQSxDQUFBSCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}