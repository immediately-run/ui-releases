var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _useLodestarCtx = require("../hooks/useLodestarCtx");
var _Icon = _interopRequireDefault(require("./Icon"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // Run-first top chrome (DESIGN_BRIEF §1): a board switcher top-left and, on
// desktop, the minimal control cluster top-right — zoom, journeys, theme, the
// run/edit posture toggle (edit only offered when the mount is writable), and
// Share. The edit toggle and Share invoke host-mediated tasks; until those tasks
// exist they surface as toasts (Lodestar holds no sharing authority — §6.3).
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function TopBar() {
  _s();
  const wb = (0, _useLodestarCtx.useWb)();
  const {
    mode,
    light,
    panelOpen,
    cam,
    views,
    title
  } = wb.state;
  const mobile = wb.isMobile();
  const z = cam.zoom;
  const ctrlBtn = on => ({
    display: 'flex',
    padding: 9,
    background: on ? 'color-mix(in oklab, var(--accent-2) 24%, var(--panel))' : 'color-mix(in oklab, var(--panel) 86%, transparent)',
    border: `1px solid ${on ? 'color-mix(in oklab, var(--accent-2) 50%, var(--line-2))' : 'var(--line)'}`,
    borderRadius: 'var(--r-pill)',
    color: 'var(--ink)',
    cursor: 'pointer',
    backdropFilter: 'blur(10px)'
  });
  const modeTab = on => ({
    padding: '7px 15px',
    background: on ? 'var(--ink)' : 'transparent',
    border: 'none',
    borderRadius: 'var(--r-pill)',
    color: on ? 'var(--bg)' : 'var(--ink-2)',
    font: 'var(--label)',
    cursor: 'pointer'
  });
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      style: {
        position: 'absolute',
        top: 16,
        left: 16,
        display: 'flex',
        alignItems: 'center',
        gap: 10,
        zIndex: 40
      },
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
        onClick: () => wb.setScreen('chooser'),
        style: {
          display: 'flex',
          alignItems: 'center',
          gap: 9,
          padding: '8px 13px',
          background: 'color-mix(in oklab, var(--panel) 86%, transparent)',
          border: '1px solid var(--line)',
          borderRadius: 'var(--r-pill)',
          color: 'var(--ink)',
          font: 'var(--label)',
          cursor: 'pointer',
          backdropFilter: 'blur(10px)',
          whiteSpace: 'nowrap'
        },
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          style: {
            width: 18,
            height: 18,
            borderRadius: 5,
            background: 'var(--grad)',
            display: 'inline-block',
            transform: 'rotate(12deg)',
            flex: 'none'
          }
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          children: title
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          style: {
            opacity: 0.55,
            display: 'inline-flex'
          },
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
            name: "chevDown",
            size: 15,
            strokeWidth: 2
          })
        })]
      }), mode === 'edit' && !mobile ? /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        style: {
          display: 'inline-flex',
          alignItems: 'center',
          gap: 6,
          padding: '6px 11px',
          background: 'color-mix(in oklab, var(--accent-2) 22%, var(--panel))',
          border: '1px solid color-mix(in oklab, var(--accent-2) 50%, var(--line-2))',
          borderRadius: 'var(--r-pill)',
          font: 'var(--mono-xs)',
          letterSpacing: '.04em',
          textTransform: 'uppercase',
          color: 'var(--ink)'
        },
        children: "Edit mode"
      }) : null]
    }), !mobile ? /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      style: {
        position: 'absolute',
        top: 16,
        right: 16,
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        zIndex: 40
      },
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        style: {
          display: 'flex',
          alignItems: 'center',
          background: 'color-mix(in oklab, var(--panel) 86%, transparent)',
          border: '1px solid var(--line)',
          borderRadius: 'var(--r-pill)',
          backdropFilter: 'blur(10px)',
          overflow: 'hidden'
        },
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          title: "Zoom out",
          "aria-label": "Zoom out",
          onClick: () => wb.setZoom(z / 1.25),
          style: {
            display: 'flex',
            padding: '8px 10px',
            background: 'none',
            border: 'none',
            color: 'var(--ink-2)',
            cursor: 'pointer'
          },
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
            name: "minus",
            size: 16,
            strokeWidth: 2
          })
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          title: "Reset zoom",
          "aria-label": "Reset zoom",
          onClick: () => wb.flyTo(views[0], 600),
          style: {
            padding: '8px 4px',
            minWidth: 52,
            background: 'none',
            border: 'none',
            color: 'var(--ink)',
            font: 'var(--mono-sm)',
            cursor: 'pointer'
          },
          children: `${Math.round(z * 100)}%`
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          title: "Zoom in",
          "aria-label": "Zoom in",
          onClick: () => wb.setZoom(z * 1.25),
          style: {
            display: 'flex',
            padding: '8px 10px',
            background: 'none',
            border: 'none',
            color: 'var(--ink-2)',
            cursor: 'pointer'
          },
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
            name: "plus",
            size: 16,
            strokeWidth: 2
          })
        })]
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        title: "Journeys & views",
        "aria-label": "Journeys & views",
        onClick: wb.togglePanel,
        style: ctrlBtn(panelOpen),
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
          name: "route",
          size: 18
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        title: "Toggle theme",
        "aria-label": "Toggle theme",
        onClick: wb.toggleTheme,
        style: {
          display: 'flex',
          padding: 9,
          background: 'color-mix(in oklab, var(--panel) 86%, transparent)',
          border: '1px solid var(--line)',
          borderRadius: 'var(--r-pill)',
          color: 'var(--ink-2)',
          cursor: 'pointer',
          backdropFilter: 'blur(10px)'
        },
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
          name: light ? 'moon' : 'sun',
          size: 18
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        style: {
          display: 'flex',
          alignItems: 'center',
          background: 'color-mix(in oklab, var(--panel) 86%, transparent)',
          border: '1px solid var(--line)',
          borderRadius: 'var(--r-pill)',
          backdropFilter: 'blur(10px)',
          padding: 3,
          gap: 2
        },
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          onClick: wb.setRun,
          style: modeTab(mode === 'run'),
          children: "Run"
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          onClick: wb.setEdit,
          style: modeTab(mode === 'edit'),
          children: "Edit"
        })]
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
        onClick: () => wb.toast('Opening share dialog (share-space task)…', 'share'),
        style: {
          display: 'flex',
          alignItems: 'center',
          gap: 7,
          padding: '9px 15px',
          background: 'var(--grad)',
          border: 'none',
          borderRadius: 'var(--r-pill)',
          color: '#1a1020',
          font: 'var(--label)',
          cursor: 'pointer',
          boxShadow: 'var(--glow)'
        },
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
          name: "share",
          size: 16,
          color: "#1a1020"
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
          children: "Share"
        })]
      })]
    }) : null]
  });
}
_s(TopBar, "VeUy8AIV4bR/U9OnzH43HThc4KU=", false, function () {
  return [_useLodestarCtx.useWb];
});
_c = TopBar;
var _default = exports.default = TopBar;
var _c;
$RefreshReg$(_c, "TopBar");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdXNlTG9kZXN0YXJDdHgiLCJyZXF1aXJlIiwiX0ljb24iLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsIlRvcEJhciIsIndiIiwidXNlV2IiLCJtb2RlIiwibGlnaHQiLCJwYW5lbE9wZW4iLCJjYW0iLCJ2aWV3cyIsInRpdGxlIiwic3RhdGUiLCJtb2JpbGUiLCJpc01vYmlsZSIsInoiLCJ6b29tIiwiY3RybEJ0biIsIm9uIiwiZGlzcGxheSIsInBhZGRpbmciLCJiYWNrZ3JvdW5kIiwiYm9yZGVyIiwiYm9yZGVyUmFkaXVzIiwiY29sb3IiLCJjdXJzb3IiLCJiYWNrZHJvcEZpbHRlciIsIm1vZGVUYWIiLCJmb250IiwianN4cyIsIkZyYWdtZW50IiwiY2hpbGRyZW4iLCJzdHlsZSIsInBvc2l0aW9uIiwidG9wIiwibGVmdCIsImFsaWduSXRlbXMiLCJnYXAiLCJ6SW5kZXgiLCJvbkNsaWNrIiwic2V0U2NyZWVuIiwid2hpdGVTcGFjZSIsImpzeCIsIndpZHRoIiwiaGVpZ2h0IiwidHJhbnNmb3JtIiwiZmxleCIsIm9wYWNpdHkiLCJuYW1lIiwic2l6ZSIsInN0cm9rZVdpZHRoIiwibGV0dGVyU3BhY2luZyIsInRleHRUcmFuc2Zvcm0iLCJyaWdodCIsIm92ZXJmbG93Iiwic2V0Wm9vbSIsImZseVRvIiwibWluV2lkdGgiLCJNYXRoIiwicm91bmQiLCJ0b2dnbGVQYW5lbCIsInRvZ2dsZVRoZW1lIiwic2V0UnVuIiwic2V0RWRpdCIsInRvYXN0IiwiYm94U2hhZG93IiwiX2MiLCJfZGVmYXVsdCIsImV4cG9ydHMiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJUb3BCYXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIFJ1bi1maXJzdCB0b3AgY2hyb21lIChERVNJR05fQlJJRUYgwqcxKTogYSBib2FyZCBzd2l0Y2hlciB0b3AtbGVmdCBhbmQsIG9uXG4vLyBkZXNrdG9wLCB0aGUgbWluaW1hbCBjb250cm9sIGNsdXN0ZXIgdG9wLXJpZ2h0IOKAlCB6b29tLCBqb3VybmV5cywgdGhlbWUsIHRoZVxuLy8gcnVuL2VkaXQgcG9zdHVyZSB0b2dnbGUgKGVkaXQgb25seSBvZmZlcmVkIHdoZW4gdGhlIG1vdW50IGlzIHdyaXRhYmxlKSwgYW5kXG4vLyBTaGFyZS4gVGhlIGVkaXQgdG9nZ2xlIGFuZCBTaGFyZSBpbnZva2UgaG9zdC1tZWRpYXRlZCB0YXNrczsgdW50aWwgdGhvc2UgdGFza3Ncbi8vIGV4aXN0IHRoZXkgc3VyZmFjZSBhcyB0b2FzdHMgKExvZGVzdGFyIGhvbGRzIG5vIHNoYXJpbmcgYXV0aG9yaXR5IOKAlCDCpzYuMykuXG5cbmltcG9ydCB7IHVzZVdiIH0gZnJvbSAnLi4vaG9va3MvdXNlTG9kZXN0YXJDdHgnO1xuaW1wb3J0IEljb24gZnJvbSAnLi9JY29uJztcblxuZnVuY3Rpb24gVG9wQmFyKCkge1xuICBjb25zdCB3YiA9IHVzZVdiKCk7XG4gIGNvbnN0IHsgbW9kZSwgbGlnaHQsIHBhbmVsT3BlbiwgY2FtLCB2aWV3cywgdGl0bGUgfSA9IHdiLnN0YXRlO1xuICBjb25zdCBtb2JpbGUgPSB3Yi5pc01vYmlsZSgpO1xuICBjb25zdCB6ID0gY2FtLnpvb207XG5cbiAgY29uc3QgY3RybEJ0biA9IChvbjogYm9vbGVhbik6IFJlYWN0LkNTU1Byb3BlcnRpZXMgPT4gKHtcbiAgICBkaXNwbGF5OiAnZmxleCcsXG4gICAgcGFkZGluZzogOSxcbiAgICBiYWNrZ3JvdW5kOiBvbiA/ICdjb2xvci1taXgoaW4gb2tsYWIsIHZhcigtLWFjY2VudC0yKSAyNCUsIHZhcigtLXBhbmVsKSknIDogJ2NvbG9yLW1peChpbiBva2xhYiwgdmFyKC0tcGFuZWwpIDg2JSwgdHJhbnNwYXJlbnQpJyxcbiAgICBib3JkZXI6IGAxcHggc29saWQgJHtvbiA/ICdjb2xvci1taXgoaW4gb2tsYWIsIHZhcigtLWFjY2VudC0yKSA1MCUsIHZhcigtLWxpbmUtMikpJyA6ICd2YXIoLS1saW5lKSd9YCxcbiAgICBib3JkZXJSYWRpdXM6ICd2YXIoLS1yLXBpbGwpJyxcbiAgICBjb2xvcjogJ3ZhcigtLWluayknLFxuICAgIGN1cnNvcjogJ3BvaW50ZXInLFxuICAgIGJhY2tkcm9wRmlsdGVyOiAnYmx1cigxMHB4KScsXG4gIH0pO1xuICBjb25zdCBtb2RlVGFiID0gKG9uOiBib29sZWFuKTogUmVhY3QuQ1NTUHJvcGVydGllcyA9PiAoe1xuICAgIHBhZGRpbmc6ICc3cHggMTVweCcsXG4gICAgYmFja2dyb3VuZDogb24gPyAndmFyKC0taW5rKScgOiAndHJhbnNwYXJlbnQnLFxuICAgIGJvcmRlcjogJ25vbmUnLFxuICAgIGJvcmRlclJhZGl1czogJ3ZhcigtLXItcGlsbCknLFxuICAgIGNvbG9yOiBvbiA/ICd2YXIoLS1iZyknIDogJ3ZhcigtLWluay0yKScsXG4gICAgZm9udDogJ3ZhcigtLWxhYmVsKScsXG4gICAgY3Vyc29yOiAncG9pbnRlcicsXG4gIH0pO1xuXG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIHsvKiB0b3AtbGVmdDogYm9hcmQgc3dpdGNoZXIgKi99XG4gICAgICA8ZGl2IHN0eWxlPXt7IHBvc2l0aW9uOiAnYWJzb2x1dGUnLCB0b3A6IDE2LCBsZWZ0OiAxNiwgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywgZ2FwOiAxMCwgekluZGV4OiA0MCB9fT5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHdiLnNldFNjcmVlbignY2hvb3NlcicpfVxuICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICBkaXNwbGF5OiAnZmxleCcsXG4gICAgICAgICAgICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcbiAgICAgICAgICAgIGdhcDogOSxcbiAgICAgICAgICAgIHBhZGRpbmc6ICc4cHggMTNweCcsXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiAnY29sb3ItbWl4KGluIG9rbGFiLCB2YXIoLS1wYW5lbCkgODYlLCB0cmFuc3BhcmVudCknLFxuICAgICAgICAgICAgYm9yZGVyOiAnMXB4IHNvbGlkIHZhcigtLWxpbmUpJyxcbiAgICAgICAgICAgIGJvcmRlclJhZGl1czogJ3ZhcigtLXItcGlsbCknLFxuICAgICAgICAgICAgY29sb3I6ICd2YXIoLS1pbmspJyxcbiAgICAgICAgICAgIGZvbnQ6ICd2YXIoLS1sYWJlbCknLFxuICAgICAgICAgICAgY3Vyc29yOiAncG9pbnRlcicsXG4gICAgICAgICAgICBiYWNrZHJvcEZpbHRlcjogJ2JsdXIoMTBweCknLFxuICAgICAgICAgICAgd2hpdGVTcGFjZTogJ25vd3JhcCcsXG4gICAgICAgICAgfX1cbiAgICAgICAgPlxuICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IHdpZHRoOiAxOCwgaGVpZ2h0OiAxOCwgYm9yZGVyUmFkaXVzOiA1LCBiYWNrZ3JvdW5kOiAndmFyKC0tZ3JhZCknLCBkaXNwbGF5OiAnaW5saW5lLWJsb2NrJywgdHJhbnNmb3JtOiAncm90YXRlKDEyZGVnKScsIGZsZXg6ICdub25lJyB9fSAvPlxuICAgICAgICAgIDxzcGFuPnt0aXRsZX08L3NwYW4+XG4gICAgICAgICAgPHNwYW4gc3R5bGU9e3sgb3BhY2l0eTogMC41NSwgZGlzcGxheTogJ2lubGluZS1mbGV4JyB9fT5cbiAgICAgICAgICAgIDxJY29uIG5hbWU9XCJjaGV2RG93blwiIHNpemU9ezE1fSBzdHJva2VXaWR0aD17Mn0gLz5cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgICB7bW9kZSA9PT0gJ2VkaXQnICYmICFtb2JpbGUgPyAoXG4gICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgIGRpc3BsYXk6ICdpbmxpbmUtZmxleCcsXG4gICAgICAgICAgICAgIGFsaWduSXRlbXM6ICdjZW50ZXInLFxuICAgICAgICAgICAgICBnYXA6IDYsXG4gICAgICAgICAgICAgIHBhZGRpbmc6ICc2cHggMTFweCcsXG4gICAgICAgICAgICAgIGJhY2tncm91bmQ6ICdjb2xvci1taXgoaW4gb2tsYWIsIHZhcigtLWFjY2VudC0yKSAyMiUsIHZhcigtLXBhbmVsKSknLFxuICAgICAgICAgICAgICBib3JkZXI6ICcxcHggc29saWQgY29sb3ItbWl4KGluIG9rbGFiLCB2YXIoLS1hY2NlbnQtMikgNTAlLCB2YXIoLS1saW5lLTIpKScsXG4gICAgICAgICAgICAgIGJvcmRlclJhZGl1czogJ3ZhcigtLXItcGlsbCknLFxuICAgICAgICAgICAgICBmb250OiAndmFyKC0tbW9uby14cyknLFxuICAgICAgICAgICAgICBsZXR0ZXJTcGFjaW5nOiAnLjA0ZW0nLFxuICAgICAgICAgICAgICB0ZXh0VHJhbnNmb3JtOiAndXBwZXJjYXNlJyxcbiAgICAgICAgICAgICAgY29sb3I6ICd2YXIoLS1pbmspJyxcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgPlxuICAgICAgICAgICAgRWRpdCBtb2RlXG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICApIDogbnVsbH1cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogdG9wLXJpZ2h0OiBjb250cm9scyAoZGVza3RvcCkgKi99XG4gICAgICB7IW1vYmlsZSA/IChcbiAgICAgICAgPGRpdiBzdHlsZT17eyBwb3NpdGlvbjogJ2Fic29sdXRlJywgdG9wOiAxNiwgcmlnaHQ6IDE2LCBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBnYXA6IDgsIHpJbmRleDogNDAgfX0+XG4gICAgICAgICAgPGRpdlxuICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgZGlzcGxheTogJ2ZsZXgnLFxuICAgICAgICAgICAgICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcbiAgICAgICAgICAgICAgYmFja2dyb3VuZDogJ2NvbG9yLW1peChpbiBva2xhYiwgdmFyKC0tcGFuZWwpIDg2JSwgdHJhbnNwYXJlbnQpJyxcbiAgICAgICAgICAgICAgYm9yZGVyOiAnMXB4IHNvbGlkIHZhcigtLWxpbmUpJyxcbiAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAndmFyKC0tci1waWxsKScsXG4gICAgICAgICAgICAgIGJhY2tkcm9wRmlsdGVyOiAnYmx1cigxMHB4KScsXG4gICAgICAgICAgICAgIG92ZXJmbG93OiAnaGlkZGVuJyxcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPGJ1dHRvbiB0aXRsZT1cIlpvb20gb3V0XCIgYXJpYS1sYWJlbD1cIlpvb20gb3V0XCIgb25DbGljaz17KCkgPT4gd2Iuc2V0Wm9vbSh6IC8gMS4yNSl9IHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywgcGFkZGluZzogJzhweCAxMHB4JywgYmFja2dyb3VuZDogJ25vbmUnLCBib3JkZXI6ICdub25lJywgY29sb3I6ICd2YXIoLS1pbmstMiknLCBjdXJzb3I6ICdwb2ludGVyJyB9fT5cbiAgICAgICAgICAgICAgPEljb24gbmFtZT1cIm1pbnVzXCIgc2l6ZT17MTZ9IHN0cm9rZVdpZHRoPXsyfSAvPlxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8YnV0dG9uIHRpdGxlPVwiUmVzZXQgem9vbVwiIGFyaWEtbGFiZWw9XCJSZXNldCB6b29tXCIgb25DbGljaz17KCkgPT4gd2IuZmx5VG8odmlld3NbMF0sIDYwMCl9IHN0eWxlPXt7IHBhZGRpbmc6ICc4cHggNHB4JywgbWluV2lkdGg6IDUyLCBiYWNrZ3JvdW5kOiAnbm9uZScsIGJvcmRlcjogJ25vbmUnLCBjb2xvcjogJ3ZhcigtLWluayknLCBmb250OiAndmFyKC0tbW9uby1zbSknLCBjdXJzb3I6ICdwb2ludGVyJyB9fT5cbiAgICAgICAgICAgICAge2Ake01hdGgucm91bmQoeiAqIDEwMCl9JWB9XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDxidXR0b24gdGl0bGU9XCJab29tIGluXCIgYXJpYS1sYWJlbD1cIlpvb20gaW5cIiBvbkNsaWNrPXsoKSA9PiB3Yi5zZXRab29tKHogKiAxLjI1KX0gc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBwYWRkaW5nOiAnOHB4IDEwcHgnLCBiYWNrZ3JvdW5kOiAnbm9uZScsIGJvcmRlcjogJ25vbmUnLCBjb2xvcjogJ3ZhcigtLWluay0yKScsIGN1cnNvcjogJ3BvaW50ZXInIH19PlxuICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwicGx1c1wiIHNpemU9ezE2fSBzdHJva2VXaWR0aD17Mn0gLz5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxidXR0b24gdGl0bGU9XCJKb3VybmV5cyAmIHZpZXdzXCIgYXJpYS1sYWJlbD1cIkpvdXJuZXlzICYgdmlld3NcIiBvbkNsaWNrPXt3Yi50b2dnbGVQYW5lbH0gc3R5bGU9e2N0cmxCdG4ocGFuZWxPcGVuKX0+XG4gICAgICAgICAgICA8SWNvbiBuYW1lPVwicm91dGVcIiBzaXplPXsxOH0gLz5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICB0aXRsZT1cIlRvZ2dsZSB0aGVtZVwiXG4gICAgICAgICAgICBhcmlhLWxhYmVsPVwiVG9nZ2xlIHRoZW1lXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9e3diLnRvZ2dsZVRoZW1lfVxuICAgICAgICAgICAgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBwYWRkaW5nOiA5LCBiYWNrZ3JvdW5kOiAnY29sb3ItbWl4KGluIG9rbGFiLCB2YXIoLS1wYW5lbCkgODYlLCB0cmFuc3BhcmVudCknLCBib3JkZXI6ICcxcHggc29saWQgdmFyKC0tbGluZSknLCBib3JkZXJSYWRpdXM6ICd2YXIoLS1yLXBpbGwpJywgY29sb3I6ICd2YXIoLS1pbmstMiknLCBjdXJzb3I6ICdwb2ludGVyJywgYmFja2Ryb3BGaWx0ZXI6ICdibHVyKDEwcHgpJyB9fVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxJY29uIG5hbWU9e2xpZ2h0ID8gJ21vb24nIDogJ3N1bid9IHNpemU9ezE4fSAvPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywgYmFja2dyb3VuZDogJ2NvbG9yLW1peChpbiBva2xhYiwgdmFyKC0tcGFuZWwpIDg2JSwgdHJhbnNwYXJlbnQpJywgYm9yZGVyOiAnMXB4IHNvbGlkIHZhcigtLWxpbmUpJywgYm9yZGVyUmFkaXVzOiAndmFyKC0tci1waWxsKScsIGJhY2tkcm9wRmlsdGVyOiAnYmx1cigxMHB4KScsIHBhZGRpbmc6IDMsIGdhcDogMiB9fT5cbiAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17d2Iuc2V0UnVufSBzdHlsZT17bW9kZVRhYihtb2RlID09PSAncnVuJyl9PlxuICAgICAgICAgICAgICBSdW5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXt3Yi5zZXRFZGl0fSBzdHlsZT17bW9kZVRhYihtb2RlID09PSAnZWRpdCcpfT5cbiAgICAgICAgICAgICAgRWRpdFxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gd2IudG9hc3QoJ09wZW5pbmcgc2hhcmUgZGlhbG9nIChzaGFyZS1zcGFjZSB0YXNrKeKApicsICdzaGFyZScpfVxuICAgICAgICAgICAgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywgZ2FwOiA3LCBwYWRkaW5nOiAnOXB4IDE1cHgnLCBiYWNrZ3JvdW5kOiAndmFyKC0tZ3JhZCknLCBib3JkZXI6ICdub25lJywgYm9yZGVyUmFkaXVzOiAndmFyKC0tci1waWxsKScsIGNvbG9yOiAnIzFhMTAyMCcsIGZvbnQ6ICd2YXIoLS1sYWJlbCknLCBjdXJzb3I6ICdwb2ludGVyJywgYm94U2hhZG93OiAndmFyKC0tZ2xvdyknIH19XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPEljb24gbmFtZT1cInNoYXJlXCIgc2l6ZT17MTZ9IGNvbG9yPVwiIzFhMTAyMFwiIC8+XG4gICAgICAgICAgICA8c3Bhbj5TaGFyZTwvc3Bhbj5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApIDogbnVsbH1cbiAgICA8Lz5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgVG9wQmFyO1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFNQSxJQUFBQSxlQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxLQUFBLEdBQUFDLHNCQUFBLENBQUFGLE9BQUE7QUFBMEIsSUFBQUcsV0FBQSxHQUFBSCxPQUFBO0FBQUEsSUFBQUksRUFBQSxHQUFBQyxZQUFBLElBUDFCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFBQSxTQUFBSCx1QkFBQUksQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQUtBLFNBQVNHLE1BQU1BLENBQUEsRUFBRztFQUFBTCxFQUFBO0VBQ2hCLE1BQU1NLEVBQUUsR0FBRyxJQUFBQyxxQkFBSyxFQUFDLENBQUM7RUFDbEIsTUFBTTtJQUFFQyxJQUFJO0lBQUVDLEtBQUs7SUFBRUMsU0FBUztJQUFFQyxHQUFHO0lBQUVDLEtBQUs7SUFBRUM7RUFBTSxDQUFDLEdBQUdQLEVBQUUsQ0FBQ1EsS0FBSztFQUM5RCxNQUFNQyxNQUFNLEdBQUdULEVBQUUsQ0FBQ1UsUUFBUSxDQUFDLENBQUM7RUFDNUIsTUFBTUMsQ0FBQyxHQUFHTixHQUFHLENBQUNPLElBQUk7RUFFbEIsTUFBTUMsT0FBTyxHQUFJQyxFQUFXLEtBQTJCO0lBQ3JEQyxPQUFPLEVBQUUsTUFBTTtJQUNmQyxPQUFPLEVBQUUsQ0FBQztJQUNWQyxVQUFVLEVBQUVILEVBQUUsR0FBRyx3REFBd0QsR0FBRyxvREFBb0Q7SUFDaElJLE1BQU0sRUFBRSxhQUFhSixFQUFFLEdBQUcseURBQXlELEdBQUcsYUFBYSxFQUFFO0lBQ3JHSyxZQUFZLEVBQUUsZUFBZTtJQUM3QkMsS0FBSyxFQUFFLFlBQVk7SUFDbkJDLE1BQU0sRUFBRSxTQUFTO0lBQ2pCQyxjQUFjLEVBQUU7RUFDbEIsQ0FBQyxDQUFDO0VBQ0YsTUFBTUMsT0FBTyxHQUFJVCxFQUFXLEtBQTJCO0lBQ3JERSxPQUFPLEVBQUUsVUFBVTtJQUNuQkMsVUFBVSxFQUFFSCxFQUFFLEdBQUcsWUFBWSxHQUFHLGFBQWE7SUFDN0NJLE1BQU0sRUFBRSxNQUFNO0lBQ2RDLFlBQVksRUFBRSxlQUFlO0lBQzdCQyxLQUFLLEVBQUVOLEVBQUUsR0FBRyxXQUFXLEdBQUcsY0FBYztJQUN4Q1UsSUFBSSxFQUFFLGNBQWM7SUFDcEJILE1BQU0sRUFBRTtFQUNWLENBQUMsQ0FBQztFQUVGLG9CQUNFLElBQUE1QixXQUFBLENBQUFnQyxJQUFBLEVBQUFoQyxXQUFBLENBQUFpQyxRQUFBO0lBQUFDLFFBQUEsZ0JBRUUsSUFBQWxDLFdBQUEsQ0FBQWdDLElBQUE7TUFBS0csS0FBSyxFQUFFO1FBQUVDLFFBQVEsRUFBRSxVQUFVO1FBQUVDLEdBQUcsRUFBRSxFQUFFO1FBQUVDLElBQUksRUFBRSxFQUFFO1FBQUVoQixPQUFPLEVBQUUsTUFBTTtRQUFFaUIsVUFBVSxFQUFFLFFBQVE7UUFBRUMsR0FBRyxFQUFFLEVBQUU7UUFBRUMsTUFBTSxFQUFFO01BQUcsQ0FBRTtNQUFBUCxRQUFBLGdCQUNsSCxJQUFBbEMsV0FBQSxDQUFBZ0MsSUFBQTtRQUNFVSxPQUFPLEVBQUVBLENBQUEsS0FBTW5DLEVBQUUsQ0FBQ29DLFNBQVMsQ0FBQyxTQUFTLENBQUU7UUFDdkNSLEtBQUssRUFBRTtVQUNMYixPQUFPLEVBQUUsTUFBTTtVQUNmaUIsVUFBVSxFQUFFLFFBQVE7VUFDcEJDLEdBQUcsRUFBRSxDQUFDO1VBQ05qQixPQUFPLEVBQUUsVUFBVTtVQUNuQkMsVUFBVSxFQUFFLG9EQUFvRDtVQUNoRUMsTUFBTSxFQUFFLHVCQUF1QjtVQUMvQkMsWUFBWSxFQUFFLGVBQWU7VUFDN0JDLEtBQUssRUFBRSxZQUFZO1VBQ25CSSxJQUFJLEVBQUUsY0FBYztVQUNwQkgsTUFBTSxFQUFFLFNBQVM7VUFDakJDLGNBQWMsRUFBRSxZQUFZO1VBQzVCZSxVQUFVLEVBQUU7UUFDZCxDQUFFO1FBQUFWLFFBQUEsZ0JBRUYsSUFBQWxDLFdBQUEsQ0FBQTZDLEdBQUE7VUFBTVYsS0FBSyxFQUFFO1lBQUVXLEtBQUssRUFBRSxFQUFFO1lBQUVDLE1BQU0sRUFBRSxFQUFFO1lBQUVyQixZQUFZLEVBQUUsQ0FBQztZQUFFRixVQUFVLEVBQUUsYUFBYTtZQUFFRixPQUFPLEVBQUUsY0FBYztZQUFFMEIsU0FBUyxFQUFFLGVBQWU7WUFBRUMsSUFBSSxFQUFFO1VBQU87UUFBRSxDQUFFLENBQUMsZUFDekosSUFBQWpELFdBQUEsQ0FBQTZDLEdBQUE7VUFBQVgsUUFBQSxFQUFPcEI7UUFBSyxDQUFPLENBQUMsZUFDcEIsSUFBQWQsV0FBQSxDQUFBNkMsR0FBQTtVQUFNVixLQUFLLEVBQUU7WUFBRWUsT0FBTyxFQUFFLElBQUk7WUFBRTVCLE9BQU8sRUFBRTtVQUFjLENBQUU7VUFBQVksUUFBQSxlQUNyRCxJQUFBbEMsV0FBQSxDQUFBNkMsR0FBQSxFQUFDL0MsS0FBQSxDQUFBTyxPQUFJO1lBQUM4QyxJQUFJLEVBQUMsVUFBVTtZQUFDQyxJQUFJLEVBQUUsRUFBRztZQUFDQyxXQUFXLEVBQUU7VUFBRSxDQUFFO1FBQUMsQ0FDOUMsQ0FBQztNQUFBLENBQ0QsQ0FBQyxFQUNSNUMsSUFBSSxLQUFLLE1BQU0sSUFBSSxDQUFDTyxNQUFNLGdCQUN6QixJQUFBaEIsV0FBQSxDQUFBNkMsR0FBQTtRQUNFVixLQUFLLEVBQUU7VUFDTGIsT0FBTyxFQUFFLGFBQWE7VUFDdEJpQixVQUFVLEVBQUUsUUFBUTtVQUNwQkMsR0FBRyxFQUFFLENBQUM7VUFDTmpCLE9BQU8sRUFBRSxVQUFVO1VBQ25CQyxVQUFVLEVBQUUsd0RBQXdEO1VBQ3BFQyxNQUFNLEVBQUUsbUVBQW1FO1VBQzNFQyxZQUFZLEVBQUUsZUFBZTtVQUM3QkssSUFBSSxFQUFFLGdCQUFnQjtVQUN0QnVCLGFBQWEsRUFBRSxPQUFPO1VBQ3RCQyxhQUFhLEVBQUUsV0FBVztVQUMxQjVCLEtBQUssRUFBRTtRQUNULENBQUU7UUFBQU8sUUFBQSxFQUNIO01BRUQsQ0FBTSxDQUFDLEdBQ0wsSUFBSTtJQUFBLENBQ0wsQ0FBQyxFQUdMLENBQUNsQixNQUFNLGdCQUNOLElBQUFoQixXQUFBLENBQUFnQyxJQUFBO01BQUtHLEtBQUssRUFBRTtRQUFFQyxRQUFRLEVBQUUsVUFBVTtRQUFFQyxHQUFHLEVBQUUsRUFBRTtRQUFFbUIsS0FBSyxFQUFFLEVBQUU7UUFBRWxDLE9BQU8sRUFBRSxNQUFNO1FBQUVpQixVQUFVLEVBQUUsUUFBUTtRQUFFQyxHQUFHLEVBQUUsQ0FBQztRQUFFQyxNQUFNLEVBQUU7TUFBRyxDQUFFO01BQUFQLFFBQUEsZ0JBQ2xILElBQUFsQyxXQUFBLENBQUFnQyxJQUFBO1FBQ0VHLEtBQUssRUFBRTtVQUNMYixPQUFPLEVBQUUsTUFBTTtVQUNmaUIsVUFBVSxFQUFFLFFBQVE7VUFDcEJmLFVBQVUsRUFBRSxvREFBb0Q7VUFDaEVDLE1BQU0sRUFBRSx1QkFBdUI7VUFDL0JDLFlBQVksRUFBRSxlQUFlO1VBQzdCRyxjQUFjLEVBQUUsWUFBWTtVQUM1QjRCLFFBQVEsRUFBRTtRQUNaLENBQUU7UUFBQXZCLFFBQUEsZ0JBRUYsSUFBQWxDLFdBQUEsQ0FBQTZDLEdBQUE7VUFBUS9CLEtBQUssRUFBQyxVQUFVO1VBQUMsY0FBVyxVQUFVO1VBQUM0QixPQUFPLEVBQUVBLENBQUEsS0FBTW5DLEVBQUUsQ0FBQ21ELE9BQU8sQ0FBQ3hDLENBQUMsR0FBRyxJQUFJLENBQUU7VUFBQ2lCLEtBQUssRUFBRTtZQUFFYixPQUFPLEVBQUUsTUFBTTtZQUFFQyxPQUFPLEVBQUUsVUFBVTtZQUFFQyxVQUFVLEVBQUUsTUFBTTtZQUFFQyxNQUFNLEVBQUUsTUFBTTtZQUFFRSxLQUFLLEVBQUUsY0FBYztZQUFFQyxNQUFNLEVBQUU7VUFBVSxDQUFFO1VBQUFNLFFBQUEsZUFDaE4sSUFBQWxDLFdBQUEsQ0FBQTZDLEdBQUEsRUFBQy9DLEtBQUEsQ0FBQU8sT0FBSTtZQUFDOEMsSUFBSSxFQUFDLE9BQU87WUFBQ0MsSUFBSSxFQUFFLEVBQUc7WUFBQ0MsV0FBVyxFQUFFO1VBQUUsQ0FBRTtRQUFDLENBQ3pDLENBQUMsZUFDVCxJQUFBckQsV0FBQSxDQUFBNkMsR0FBQTtVQUFRL0IsS0FBSyxFQUFDLFlBQVk7VUFBQyxjQUFXLFlBQVk7VUFBQzRCLE9BQU8sRUFBRUEsQ0FBQSxLQUFNbkMsRUFBRSxDQUFDb0QsS0FBSyxDQUFDOUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBRTtVQUFDc0IsS0FBSyxFQUFFO1lBQUVaLE9BQU8sRUFBRSxTQUFTO1lBQUVxQyxRQUFRLEVBQUUsRUFBRTtZQUFFcEMsVUFBVSxFQUFFLE1BQU07WUFBRUMsTUFBTSxFQUFFLE1BQU07WUFBRUUsS0FBSyxFQUFFLFlBQVk7WUFBRUksSUFBSSxFQUFFLGdCQUFnQjtZQUFFSCxNQUFNLEVBQUU7VUFBVSxDQUFFO1VBQUFNLFFBQUEsRUFDeE8sR0FBRzJCLElBQUksQ0FBQ0MsS0FBSyxDQUFDNUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztRQUFHLENBQ3BCLENBQUMsZUFDVCxJQUFBbEIsV0FBQSxDQUFBNkMsR0FBQTtVQUFRL0IsS0FBSyxFQUFDLFNBQVM7VUFBQyxjQUFXLFNBQVM7VUFBQzRCLE9BQU8sRUFBRUEsQ0FBQSxLQUFNbkMsRUFBRSxDQUFDbUQsT0FBTyxDQUFDeEMsQ0FBQyxHQUFHLElBQUksQ0FBRTtVQUFDaUIsS0FBSyxFQUFFO1lBQUViLE9BQU8sRUFBRSxNQUFNO1lBQUVDLE9BQU8sRUFBRSxVQUFVO1lBQUVDLFVBQVUsRUFBRSxNQUFNO1lBQUVDLE1BQU0sRUFBRSxNQUFNO1lBQUVFLEtBQUssRUFBRSxjQUFjO1lBQUVDLE1BQU0sRUFBRTtVQUFVLENBQUU7VUFBQU0sUUFBQSxlQUM5TSxJQUFBbEMsV0FBQSxDQUFBNkMsR0FBQSxFQUFDL0MsS0FBQSxDQUFBTyxPQUFJO1lBQUM4QyxJQUFJLEVBQUMsTUFBTTtZQUFDQyxJQUFJLEVBQUUsRUFBRztZQUFDQyxXQUFXLEVBQUU7VUFBRSxDQUFFO1FBQUMsQ0FDeEMsQ0FBQztNQUFBLENBQ04sQ0FBQyxlQUNOLElBQUFyRCxXQUFBLENBQUE2QyxHQUFBO1FBQVEvQixLQUFLLEVBQUMsa0JBQWtCO1FBQUMsY0FBVyxrQkFBa0I7UUFBQzRCLE9BQU8sRUFBRW5DLEVBQUUsQ0FBQ3dELFdBQVk7UUFBQzVCLEtBQUssRUFBRWYsT0FBTyxDQUFDVCxTQUFTLENBQUU7UUFBQXVCLFFBQUEsZUFDaEgsSUFBQWxDLFdBQUEsQ0FBQTZDLEdBQUEsRUFBQy9DLEtBQUEsQ0FBQU8sT0FBSTtVQUFDOEMsSUFBSSxFQUFDLE9BQU87VUFBQ0MsSUFBSSxFQUFFO1FBQUcsQ0FBRTtNQUFDLENBQ3pCLENBQUMsZUFDVCxJQUFBcEQsV0FBQSxDQUFBNkMsR0FBQTtRQUNFL0IsS0FBSyxFQUFDLGNBQWM7UUFDcEIsY0FBVyxjQUFjO1FBQ3pCNEIsT0FBTyxFQUFFbkMsRUFBRSxDQUFDeUQsV0FBWTtRQUN4QjdCLEtBQUssRUFBRTtVQUFFYixPQUFPLEVBQUUsTUFBTTtVQUFFQyxPQUFPLEVBQUUsQ0FBQztVQUFFQyxVQUFVLEVBQUUsb0RBQW9EO1VBQUVDLE1BQU0sRUFBRSx1QkFBdUI7VUFBRUMsWUFBWSxFQUFFLGVBQWU7VUFBRUMsS0FBSyxFQUFFLGNBQWM7VUFBRUMsTUFBTSxFQUFFLFNBQVM7VUFBRUMsY0FBYyxFQUFFO1FBQWEsQ0FBRTtRQUFBSyxRQUFBLGVBRWpQLElBQUFsQyxXQUFBLENBQUE2QyxHQUFBLEVBQUMvQyxLQUFBLENBQUFPLE9BQUk7VUFBQzhDLElBQUksRUFBRXpDLEtBQUssR0FBRyxNQUFNLEdBQUcsS0FBTTtVQUFDMEMsSUFBSSxFQUFFO1FBQUcsQ0FBRTtNQUFDLENBQzFDLENBQUMsZUFDVCxJQUFBcEQsV0FBQSxDQUFBZ0MsSUFBQTtRQUFLRyxLQUFLLEVBQUU7VUFBRWIsT0FBTyxFQUFFLE1BQU07VUFBRWlCLFVBQVUsRUFBRSxRQUFRO1VBQUVmLFVBQVUsRUFBRSxvREFBb0Q7VUFBRUMsTUFBTSxFQUFFLHVCQUF1QjtVQUFFQyxZQUFZLEVBQUUsZUFBZTtVQUFFRyxjQUFjLEVBQUUsWUFBWTtVQUFFTixPQUFPLEVBQUUsQ0FBQztVQUFFaUIsR0FBRyxFQUFFO1FBQUUsQ0FBRTtRQUFBTixRQUFBLGdCQUN4TyxJQUFBbEMsV0FBQSxDQUFBNkMsR0FBQTtVQUFRSCxPQUFPLEVBQUVuQyxFQUFFLENBQUMwRCxNQUFPO1VBQUM5QixLQUFLLEVBQUVMLE9BQU8sQ0FBQ3JCLElBQUksS0FBSyxLQUFLLENBQUU7VUFBQXlCLFFBQUEsRUFBQztRQUU1RCxDQUFRLENBQUMsZUFDVCxJQUFBbEMsV0FBQSxDQUFBNkMsR0FBQTtVQUFRSCxPQUFPLEVBQUVuQyxFQUFFLENBQUMyRCxPQUFRO1VBQUMvQixLQUFLLEVBQUVMLE9BQU8sQ0FBQ3JCLElBQUksS0FBSyxNQUFNLENBQUU7VUFBQXlCLFFBQUEsRUFBQztRQUU5RCxDQUFRLENBQUM7TUFBQSxDQUNOLENBQUMsZUFDTixJQUFBbEMsV0FBQSxDQUFBZ0MsSUFBQTtRQUNFVSxPQUFPLEVBQUVBLENBQUEsS0FBTW5DLEVBQUUsQ0FBQzRELEtBQUssQ0FBQywwQ0FBMEMsRUFBRSxPQUFPLENBQUU7UUFDN0VoQyxLQUFLLEVBQUU7VUFBRWIsT0FBTyxFQUFFLE1BQU07VUFBRWlCLFVBQVUsRUFBRSxRQUFRO1VBQUVDLEdBQUcsRUFBRSxDQUFDO1VBQUVqQixPQUFPLEVBQUUsVUFBVTtVQUFFQyxVQUFVLEVBQUUsYUFBYTtVQUFFQyxNQUFNLEVBQUUsTUFBTTtVQUFFQyxZQUFZLEVBQUUsZUFBZTtVQUFFQyxLQUFLLEVBQUUsU0FBUztVQUFFSSxJQUFJLEVBQUUsY0FBYztVQUFFSCxNQUFNLEVBQUUsU0FBUztVQUFFd0MsU0FBUyxFQUFFO1FBQWMsQ0FBRTtRQUFBbEMsUUFBQSxnQkFFN08sSUFBQWxDLFdBQUEsQ0FBQTZDLEdBQUEsRUFBQy9DLEtBQUEsQ0FBQU8sT0FBSTtVQUFDOEMsSUFBSSxFQUFDLE9BQU87VUFBQ0MsSUFBSSxFQUFFLEVBQUc7VUFBQ3pCLEtBQUssRUFBQztRQUFTLENBQUUsQ0FBQyxlQUMvQyxJQUFBM0IsV0FBQSxDQUFBNkMsR0FBQTtVQUFBWCxRQUFBLEVBQU07UUFBSyxDQUFNLENBQUM7TUFBQSxDQUNaLENBQUM7SUFBQSxDQUNOLENBQUMsR0FDSixJQUFJO0VBQUEsQ0FDUixDQUFDO0FBRVA7QUFBQ2pDLEVBQUEsQ0FoSVFLLE1BQU07RUFBQSxRQUNGRSxxQkFBSztBQUFBO0FBQUE2RCxFQUFBLEdBRFQvRCxNQUFNO0FBQUEsSUFBQWdFLFFBQUEsR0FBQUMsT0FBQSxDQUFBbEUsT0FBQSxHQWtJQUMsTUFBTTtBQUFBLElBQUErRCxFQUFBO0FBQUFHLFlBQUEsQ0FBQUgsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}