var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
var _react = require("react");
var _useLodestarCtx = require("../hooks/useLodestarCtx");
var _useOverlayDialog = require("../hooks/useOverlayDialog");
var _boardList = require("../lib/boardList");
var _useLodestar = require("../hooks/useLodestar");
var _Icon = _interopRequireDefault(require("./Icon"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The board chooser (spec §6.1): boards grouped by space, each space showing
// its role (can-edit / read-only). "Add a space" and "Open folder" route to the
// host powerbox / pick-file — space-granting authority stays with the host,
// never the app (the footnote says so out loud). The list is REAL (R3-607):
// the spaces the host granted (the mounts) with the board folders each
// contains — no boards.json metadata exists on the seam yet, so the
// mounts-derived list is the shape (see lib/boardList and the item's
// Hand-off).
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function RoleChip({
  role
}) {
  const rw = role === 'rw';
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 4,
      padding: '3px 9px',
      borderRadius: 'var(--r-pill)',
      font: 'var(--mono-xs)',
      letterSpacing: '.03em',
      whiteSpace: 'nowrap',
      flex: 'none',
      background: rw ? 'color-mix(in oklab, var(--accent-2) 16%, var(--panel))' : 'var(--panel-2)',
      border: `1px solid ${rw ? 'color-mix(in oklab, var(--accent-2) 38%, var(--line))' : 'var(--line-2)'}`,
      color: rw ? 'var(--ink)' : 'var(--ink-2)'
    },
    children: rw ? 'can edit' : /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
        name: "lock",
        size: 11,
        strokeWidth: 2
      }), "read-only"]
    })
  });
}
_c = RoleChip;
function BoardChooser() {
  _s();
  const wb = (0, _useLodestarCtx.useWb)();
  const close = () => wb.setScreen(null);
  // The dialog contract (R3-607): focus in, Tab trapped, Escape, focus return.
  const dialogRef = (0, _useOverlayDialog.useOverlayDialog)(true, close);
  const [spaces, setSpaces] = (0, _react.useState)([]);

  // The real list: enumerate the granted spaces and the boards under each.
  // Re-derived when the mounts change (a granted space appears mid-session).
  // Every failure path is caught INSIDE boardsInMount (an unreadable space
  // degrades to no rows), so this sink is the unreachable last resort — named
  // rather than silently dropped.
  (0, _react.useEffect)(() => {
    let cancelled = false;
    (0, _boardList.listSpacesAndBoards)(wb.state.mounts).then(list => {
      if (!cancelled) setSpaces(list);
    }).catch(() => {
      /* boardsInMount owns the failure modes; nothing sensible to render here */
    });
    return () => {
      cancelled = true;
    };
  }, [wb.state.mounts]);
  const busy = wb.state.busy;
  const busyLabel = busy ? _useLodestar.BUSY_LABELS[busy] : null;
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    style: {
      position: 'absolute',
      inset: 0,
      zIndex: 70,
      background: 'color-mix(in oklab, var(--bg) 92%, transparent)',
      backdropFilter: 'blur(8px)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 24
    },
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
      onClick: close,
      "aria-label": "Close",
      style: {
        position: 'absolute',
        top: 18,
        right: 18,
        display: 'flex',
        padding: 9,
        background: 'var(--panel)',
        border: '1px solid var(--line)',
        borderRadius: '50%',
        color: 'var(--ink-2)',
        cursor: 'pointer'
      },
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
        name: "x",
        size: 18
      })
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      ref: dialogRef,
      tabIndex: -1,
      style: {
        width: 'min(600px, 94vw)',
        maxHeight: '84vh',
        background: 'var(--panel)',
        border: '1px solid var(--line)',
        borderRadius: 18,
        boxShadow: 'var(--shadow-modal)',
        overflow: 'hidden',
        display: 'flex',
        flexDirection: 'column'
      },
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        style: {
          padding: '22px 24px 16px',
          borderBottom: '1px solid var(--line)',
          flex: 'none'
        },
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
          style: {
            font: '800 24px/1 var(--disp)',
            letterSpacing: '-.02em'
          },
          children: "Open a board."
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
          style: {
            font: 'var(--body-sm)',
            color: 'var(--ink-2)',
            marginTop: 6
          },
          children: "Boards live in your spaces \u2014 one space per team. Each space lists its own boards."
        }), busyLabel ? /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
          "aria-live": "polite",
          style: {
            font: 'var(--mono-xs)',
            color: 'var(--accent-violet)',
            marginTop: 8
          },
          children: busyLabel
        }) : null]
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "wb-scroll",
        style: {
          padding: 12,
          display: 'flex',
          flexDirection: 'column',
          gap: 18,
          overflowY: 'auto',
          flex: 1
        },
        children: [spaces.length === 0 ? /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
          style: {
            padding: '18px 12px',
            font: 'var(--body-sm)',
            color: 'var(--ink-2)'
          },
          children: "No spaces yet \u2014 add one below, or open a board folder directly."
        }) : null, spaces.map(sp => /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
          style: {
            display: 'flex',
            flexDirection: 'column',
            gap: 6
          },
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
            style: {
              display: 'flex',
              alignItems: 'center',
              gap: 9,
              padding: '2px 4px'
            },
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
              style: {
                display: 'flex',
                color: 'var(--ink-2)'
              },
              children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
                name: "users",
                size: 15,
                strokeWidth: 1.75
              })
            }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
              style: {
                flex: 1,
                font: '700 13.5px/1 var(--disp)',
                letterSpacing: '.01em',
                color: 'var(--ink)'
              },
              children: sp.label
            }), /*#__PURE__*/(0, _jsxRuntime.jsx)(RoleChip, {
              role: sp.role
            })]
          }), sp.boards.length === 0 ? /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
            style: {
              padding: '2px 12px 6px',
              font: 'var(--mono-xs)',
              color: 'var(--ink-3)'
            },
            children: "No boards in this space yet."
          }) : null, sp.boards.map(b => /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
            "aria-busy": busy === 'open-board',
            disabled: busy !== null,
            onClick: () => {
              // No close() first: the busy state this row enters must be
              // VISIBLE (R-IX-2); loadBoardInto closes the chooser on
              // success, and a failure leaves it open to retry.
              void wb.openBoardAt(b.target);
            },
            style: {
              display: 'flex',
              alignItems: 'center',
              gap: 12,
              padding: '11px 12px',
              background: 'var(--bg)',
              border: '1px solid var(--line)',
              borderRadius: 11,
              cursor: 'pointer',
              textAlign: 'left',
              color: 'var(--ink)'
            },
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
              style: {
                display: 'flex',
                width: 34,
                height: 34,
                borderRadius: 9,
                background: 'var(--panel-2)',
                border: '1px solid var(--line)',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'var(--ink-2)',
                flex: 'none'
              },
              children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
                name: "frame",
                size: 16,
                strokeWidth: 1.75
              })
            }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
              style: {
                flex: 1,
                minWidth: 0
              },
              children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
                style: {
                  font: '600 14.5px/1.2 var(--sans)',
                  overflow: 'hidden',
                  textOverflow: 'ellipsis',
                  whiteSpace: 'nowrap'
                },
                children: b.name
              }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
                style: {
                  font: 'var(--mono-xs)',
                  color: 'var(--ink-3)',
                  marginTop: 3
                },
                children: "board folder"
              })]
            }), sp.role === 'ro' ? /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
              name: "lock",
              size: 14,
              color: "var(--ink-3)",
              strokeWidth: 2
            }) : /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
              name: "chevRight",
              size: 16,
              color: "var(--ink-3)",
              strokeWidth: 1.75
            })]
          }, b.name)), sp.role === 'rw' ? /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
            "aria-busy": busy === 'new-board',
            disabled: busy !== null,
            onClick: () => {
              void wb.newBoardIn({
                root: sp.mount.path,
                mode: 'rw',
                spaceId: sp.mount.id
              });
            },
            style: {
              display: 'flex',
              alignItems: 'center',
              gap: 8,
              padding: '8px 12px',
              background: 'none',
              border: '1px dashed var(--line-2)',
              borderRadius: 11,
              color: 'var(--ink-3)',
              font: 'var(--body-sm)',
              cursor: 'pointer',
              textAlign: 'left'
            },
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
              name: "plus",
              size: 14,
              strokeWidth: 2
            }), `New board in ${sp.label}`]
          }) : null]
        }, sp.mount.path))]
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        style: {
          padding: '12px 14px',
          borderTop: '1px solid var(--line)',
          display: 'flex',
          flexDirection: 'column',
          gap: 9,
          flex: 'none'
        },
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
          style: {
            display: 'flex',
            gap: 8
          },
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
            onClick: () => {
              wb.addSpace();
            },
            style: {
              flex: 1,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 8,
              padding: 12,
              background: 'var(--grad)',
              border: 'none',
              borderRadius: 'var(--r-pill)',
              color: '#1a1020',
              font: 'var(--label)',
              cursor: 'pointer'
            },
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
              name: "userPlus",
              size: 16,
              color: "#1a1020",
              strokeWidth: 1.75
            }), "Add a space\u2026"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
            "aria-busy": busy === 'open-board',
            disabled: busy !== null,
            onClick: () => {
              wb.openBoard();
            },
            style: {
              flex: 'none',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 7,
              padding: '12px 16px',
              background: 'var(--bg)',
              border: '1px solid var(--line-2)',
              borderRadius: 'var(--r-pill)',
              color: 'var(--ink)',
              font: 'var(--label)',
              cursor: 'pointer'
            },
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
              name: "folder",
              size: 16,
              strokeWidth: 1.75
            }), "Open folder\u2026"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
          style: {
            font: 'var(--mono-xs)',
            color: 'var(--ink-3)',
            textAlign: 'center'
          },
          children: "Adding a space is granted by immediately.run \u2014 never by this app."
        })]
      })]
    })]
  });
}
_s(BoardChooser, "X9kvQuwP59GpGa7Rigdj7JDyiuc=", false, function () {
  return [_useLodestarCtx.useWb, _useOverlayDialog.useOverlayDialog];
});
_c2 = BoardChooser;
var _default = exports.default = BoardChooser;
var _c, _c2;
$RefreshReg$(_c, "RoleChip");
$RefreshReg$(_c2, "BoardChooser");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3VzZUxvZGVzdGFyQ3R4IiwiX3VzZU92ZXJsYXlEaWFsb2ciLCJfYm9hcmRMaXN0IiwiX3VzZUxvZGVzdGFyIiwiX0ljb24iLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsIlJvbGVDaGlwIiwicm9sZSIsInJ3IiwianN4Iiwic3R5bGUiLCJkaXNwbGF5IiwiYWxpZ25JdGVtcyIsImdhcCIsInBhZGRpbmciLCJib3JkZXJSYWRpdXMiLCJmb250IiwibGV0dGVyU3BhY2luZyIsIndoaXRlU3BhY2UiLCJmbGV4IiwiYmFja2dyb3VuZCIsImJvcmRlciIsImNvbG9yIiwiY2hpbGRyZW4iLCJqc3hzIiwiRnJhZ21lbnQiLCJuYW1lIiwic2l6ZSIsInN0cm9rZVdpZHRoIiwiX2MiLCJCb2FyZENob29zZXIiLCJ3YiIsInVzZVdiIiwiY2xvc2UiLCJzZXRTY3JlZW4iLCJkaWFsb2dSZWYiLCJ1c2VPdmVybGF5RGlhbG9nIiwic3BhY2VzIiwic2V0U3BhY2VzIiwidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJjYW5jZWxsZWQiLCJsaXN0U3BhY2VzQW5kQm9hcmRzIiwic3RhdGUiLCJtb3VudHMiLCJ0aGVuIiwibGlzdCIsImNhdGNoIiwiYnVzeSIsImJ1c3lMYWJlbCIsIkJVU1lfTEFCRUxTIiwicG9zaXRpb24iLCJpbnNldCIsInpJbmRleCIsImJhY2tkcm9wRmlsdGVyIiwianVzdGlmeUNvbnRlbnQiLCJvbkNsaWNrIiwidG9wIiwicmlnaHQiLCJjdXJzb3IiLCJyZWYiLCJ0YWJJbmRleCIsIndpZHRoIiwibWF4SGVpZ2h0IiwiYm94U2hhZG93Iiwib3ZlcmZsb3ciLCJmbGV4RGlyZWN0aW9uIiwiYm9yZGVyQm90dG9tIiwibWFyZ2luVG9wIiwiY2xhc3NOYW1lIiwib3ZlcmZsb3dZIiwibGVuZ3RoIiwibWFwIiwic3AiLCJsYWJlbCIsImJvYXJkcyIsImIiLCJkaXNhYmxlZCIsIm9wZW5Cb2FyZEF0IiwidGFyZ2V0IiwidGV4dEFsaWduIiwiaGVpZ2h0IiwibWluV2lkdGgiLCJ0ZXh0T3ZlcmZsb3ciLCJuZXdCb2FyZEluIiwicm9vdCIsIm1vdW50IiwicGF0aCIsIm1vZGUiLCJzcGFjZUlkIiwiaWQiLCJib3JkZXJUb3AiLCJhZGRTcGFjZSIsIm9wZW5Cb2FyZCIsIl9jMiIsIl9kZWZhdWx0IiwiZXhwb3J0cyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkJvYXJkQ2hvb3Nlci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gVGhlIGJvYXJkIGNob29zZXIgKHNwZWMgwqc2LjEpOiBib2FyZHMgZ3JvdXBlZCBieSBzcGFjZSwgZWFjaCBzcGFjZSBzaG93aW5nXG4vLyBpdHMgcm9sZSAoY2FuLWVkaXQgLyByZWFkLW9ubHkpLiBcIkFkZCBhIHNwYWNlXCIgYW5kIFwiT3BlbiBmb2xkZXJcIiByb3V0ZSB0byB0aGVcbi8vIGhvc3QgcG93ZXJib3ggLyBwaWNrLWZpbGUg4oCUIHNwYWNlLWdyYW50aW5nIGF1dGhvcml0eSBzdGF5cyB3aXRoIHRoZSBob3N0LFxuLy8gbmV2ZXIgdGhlIGFwcCAodGhlIGZvb3Rub3RlIHNheXMgc28gb3V0IGxvdWQpLiBUaGUgbGlzdCBpcyBSRUFMIChSMy02MDcpOlxuLy8gdGhlIHNwYWNlcyB0aGUgaG9zdCBncmFudGVkICh0aGUgbW91bnRzKSB3aXRoIHRoZSBib2FyZCBmb2xkZXJzIGVhY2hcbi8vIGNvbnRhaW5zIOKAlCBubyBib2FyZHMuanNvbiBtZXRhZGF0YSBleGlzdHMgb24gdGhlIHNlYW0geWV0LCBzbyB0aGVcbi8vIG1vdW50cy1kZXJpdmVkIGxpc3QgaXMgdGhlIHNoYXBlIChzZWUgbGliL2JvYXJkTGlzdCBhbmQgdGhlIGl0ZW0nc1xuLy8gSGFuZC1vZmYpLlxuXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlV2IgfSBmcm9tICcuLi9ob29rcy91c2VMb2Rlc3RhckN0eCc7XG5pbXBvcnQgeyB1c2VPdmVybGF5RGlhbG9nIH0gZnJvbSAnLi4vaG9va3MvdXNlT3ZlcmxheURpYWxvZyc7XG5pbXBvcnQgeyBsaXN0U3BhY2VzQW5kQm9hcmRzIH0gZnJvbSAnLi4vbGliL2JvYXJkTGlzdCc7XG5pbXBvcnQgeyBCVVNZX0xBQkVMUyB9IGZyb20gJy4uL2hvb2tzL3VzZUxvZGVzdGFyJztcbmltcG9ydCB0eXBlIHsgU3BhY2VCb2FyZHMgfSBmcm9tICcuLi9saWIvYm9hcmRMaXN0JztcbmltcG9ydCBJY29uIGZyb20gJy4vSWNvbic7XG5cbmZ1bmN0aW9uIFJvbGVDaGlwKHsgcm9sZSB9OiB7IHJvbGU6ICdydycgfCAncm8nIH0pIHtcbiAgY29uc3QgcncgPSByb2xlID09PSAncncnO1xuICByZXR1cm4gKFxuICAgIDxzcGFuXG4gICAgICBzdHlsZT17e1xuICAgICAgICBkaXNwbGF5OiAnaW5saW5lLWZsZXgnLFxuICAgICAgICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcbiAgICAgICAgZ2FwOiA0LFxuICAgICAgICBwYWRkaW5nOiAnM3B4IDlweCcsXG4gICAgICAgIGJvcmRlclJhZGl1czogJ3ZhcigtLXItcGlsbCknLFxuICAgICAgICBmb250OiAndmFyKC0tbW9uby14cyknLFxuICAgICAgICBsZXR0ZXJTcGFjaW5nOiAnLjAzZW0nLFxuICAgICAgICB3aGl0ZVNwYWNlOiAnbm93cmFwJyxcbiAgICAgICAgZmxleDogJ25vbmUnLFxuICAgICAgICBiYWNrZ3JvdW5kOiBydyA/ICdjb2xvci1taXgoaW4gb2tsYWIsIHZhcigtLWFjY2VudC0yKSAxNiUsIHZhcigtLXBhbmVsKSknIDogJ3ZhcigtLXBhbmVsLTIpJyxcbiAgICAgICAgYm9yZGVyOiBgMXB4IHNvbGlkICR7cncgPyAnY29sb3ItbWl4KGluIG9rbGFiLCB2YXIoLS1hY2NlbnQtMikgMzglLCB2YXIoLS1saW5lKSknIDogJ3ZhcigtLWxpbmUtMiknfWAsXG4gICAgICAgIGNvbG9yOiBydyA/ICd2YXIoLS1pbmspJyA6ICd2YXIoLS1pbmstMiknLFxuICAgICAgfX1cbiAgICA+XG4gICAgICB7cncgPyAnY2FuIGVkaXQnIDogKFxuICAgICAgICA8PlxuICAgICAgICAgIDxJY29uIG5hbWU9XCJsb2NrXCIgc2l6ZT17MTF9IHN0cm9rZVdpZHRoPXsyfSAvPlxuICAgICAgICAgIHJlYWQtb25seVxuICAgICAgICA8Lz5cbiAgICAgICl9XG4gICAgPC9zcGFuPlxuICApO1xufVxuXG5mdW5jdGlvbiBCb2FyZENob29zZXIoKSB7XG4gIGNvbnN0IHdiID0gdXNlV2IoKTtcbiAgY29uc3QgY2xvc2UgPSAoKSA9PiB3Yi5zZXRTY3JlZW4obnVsbCk7XG4gIC8vIFRoZSBkaWFsb2cgY29udHJhY3QgKFIzLTYwNyk6IGZvY3VzIGluLCBUYWIgdHJhcHBlZCwgRXNjYXBlLCBmb2N1cyByZXR1cm4uXG4gIGNvbnN0IGRpYWxvZ1JlZiA9IHVzZU92ZXJsYXlEaWFsb2codHJ1ZSwgY2xvc2UpO1xuICBjb25zdCBbc3BhY2VzLCBzZXRTcGFjZXNdID0gdXNlU3RhdGU8U3BhY2VCb2FyZHNbXT4oW10pO1xuXG4gIC8vIFRoZSByZWFsIGxpc3Q6IGVudW1lcmF0ZSB0aGUgZ3JhbnRlZCBzcGFjZXMgYW5kIHRoZSBib2FyZHMgdW5kZXIgZWFjaC5cbiAgLy8gUmUtZGVyaXZlZCB3aGVuIHRoZSBtb3VudHMgY2hhbmdlIChhIGdyYW50ZWQgc3BhY2UgYXBwZWFycyBtaWQtc2Vzc2lvbikuXG4gIC8vIEV2ZXJ5IGZhaWx1cmUgcGF0aCBpcyBjYXVnaHQgSU5TSURFIGJvYXJkc0luTW91bnQgKGFuIHVucmVhZGFibGUgc3BhY2VcbiAgLy8gZGVncmFkZXMgdG8gbm8gcm93cyksIHNvIHRoaXMgc2luayBpcyB0aGUgdW5yZWFjaGFibGUgbGFzdCByZXNvcnQg4oCUIG5hbWVkXG4gIC8vIHJhdGhlciB0aGFuIHNpbGVudGx5IGRyb3BwZWQuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgbGV0IGNhbmNlbGxlZCA9IGZhbHNlO1xuICAgIGxpc3RTcGFjZXNBbmRCb2FyZHMod2Iuc3RhdGUubW91bnRzKVxuICAgICAgLnRoZW4oKGxpc3QpID0+IHtcbiAgICAgICAgaWYgKCFjYW5jZWxsZWQpIHNldFNwYWNlcyhsaXN0KTtcbiAgICAgIH0pXG4gICAgICAuY2F0Y2goKCkgPT4ge1xuICAgICAgICAvKiBib2FyZHNJbk1vdW50IG93bnMgdGhlIGZhaWx1cmUgbW9kZXM7IG5vdGhpbmcgc2Vuc2libGUgdG8gcmVuZGVyIGhlcmUgKi9cbiAgICAgIH0pO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBjYW5jZWxsZWQgPSB0cnVlO1xuICAgIH07XG4gIH0sIFt3Yi5zdGF0ZS5tb3VudHNdKTtcblxuICBjb25zdCBidXN5ID0gd2Iuc3RhdGUuYnVzeTtcbiAgY29uc3QgYnVzeUxhYmVsID0gYnVzeSA/IEJVU1lfTEFCRUxTW2J1c3ldIDogbnVsbDtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgc3R5bGU9e3sgcG9zaXRpb246ICdhYnNvbHV0ZScsIGluc2V0OiAwLCB6SW5kZXg6IDcwLCBiYWNrZ3JvdW5kOiAnY29sb3ItbWl4KGluIG9rbGFiLCB2YXIoLS1iZykgOTIlLCB0cmFuc3BhcmVudCknLCBiYWNrZHJvcEZpbHRlcjogJ2JsdXIoOHB4KScsIGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGp1c3RpZnlDb250ZW50OiAnY2VudGVyJywgcGFkZGluZzogMjQgfX0+XG4gICAgICA8YnV0dG9uIG9uQ2xpY2s9e2Nsb3NlfSBhcmlhLWxhYmVsPVwiQ2xvc2VcIiBzdHlsZT17eyBwb3NpdGlvbjogJ2Fic29sdXRlJywgdG9wOiAxOCwgcmlnaHQ6IDE4LCBkaXNwbGF5OiAnZmxleCcsIHBhZGRpbmc6IDksIGJhY2tncm91bmQ6ICd2YXIoLS1wYW5lbCknLCBib3JkZXI6ICcxcHggc29saWQgdmFyKC0tbGluZSknLCBib3JkZXJSYWRpdXM6ICc1MCUnLCBjb2xvcjogJ3ZhcigtLWluay0yKScsIGN1cnNvcjogJ3BvaW50ZXInIH19PlxuICAgICAgICA8SWNvbiBuYW1lPVwieFwiIHNpemU9ezE4fSAvPlxuICAgICAgPC9idXR0b24+XG5cbiAgICAgIDxkaXYgcmVmPXtkaWFsb2dSZWZ9IHRhYkluZGV4PXstMX0gc3R5bGU9e3sgd2lkdGg6ICdtaW4oNjAwcHgsIDk0dncpJywgbWF4SGVpZ2h0OiAnODR2aCcsIGJhY2tncm91bmQ6ICd2YXIoLS1wYW5lbCknLCBib3JkZXI6ICcxcHggc29saWQgdmFyKC0tbGluZSknLCBib3JkZXJSYWRpdXM6IDE4LCBib3hTaGFkb3c6ICd2YXIoLS1zaGFkb3ctbW9kYWwpJywgb3ZlcmZsb3c6ICdoaWRkZW4nLCBkaXNwbGF5OiAnZmxleCcsIGZsZXhEaXJlY3Rpb246ICdjb2x1bW4nIH19PlxuICAgICAgICA8ZGl2IHN0eWxlPXt7IHBhZGRpbmc6ICcyMnB4IDI0cHggMTZweCcsIGJvcmRlckJvdHRvbTogJzFweCBzb2xpZCB2YXIoLS1saW5lKScsIGZsZXg6ICdub25lJyB9fT5cbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnQ6ICc4MDAgMjRweC8xIHZhcigtLWRpc3ApJywgbGV0dGVyU3BhY2luZzogJy0uMDJlbScgfX0+T3BlbiBhIGJvYXJkLjwvZGl2PlxuICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udDogJ3ZhcigtLWJvZHktc20pJywgY29sb3I6ICd2YXIoLS1pbmstMiknLCBtYXJnaW5Ub3A6IDYgfX0+Qm9hcmRzIGxpdmUgaW4geW91ciBzcGFjZXMg4oCUIG9uZSBzcGFjZSBwZXIgdGVhbS4gRWFjaCBzcGFjZSBsaXN0cyBpdHMgb3duIGJvYXJkcy48L2Rpdj5cbiAgICAgICAgICB7YnVzeUxhYmVsID8gKFxuICAgICAgICAgICAgPGRpdiBhcmlhLWxpdmU9XCJwb2xpdGVcIiBzdHlsZT17eyBmb250OiAndmFyKC0tbW9uby14cyknLCBjb2xvcjogJ3ZhcigtLWFjY2VudC12aW9sZXQpJywgbWFyZ2luVG9wOiA4IH19PlxuICAgICAgICAgICAgICB7YnVzeUxhYmVsfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSA6IG51bGx9XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwid2Itc2Nyb2xsXCIgc3R5bGU9e3sgcGFkZGluZzogMTIsIGRpc3BsYXk6ICdmbGV4JywgZmxleERpcmVjdGlvbjogJ2NvbHVtbicsIGdhcDogMTgsIG92ZXJmbG93WTogJ2F1dG8nLCBmbGV4OiAxIH19PlxuICAgICAgICAgIHtzcGFjZXMubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBwYWRkaW5nOiAnMThweCAxMnB4JywgZm9udDogJ3ZhcigtLWJvZHktc20pJywgY29sb3I6ICd2YXIoLS1pbmstMiknIH19PlxuICAgICAgICAgICAgICBObyBzcGFjZXMgeWV0IOKAlCBhZGQgb25lIGJlbG93LCBvciBvcGVuIGEgYm9hcmQgZm9sZGVyIGRpcmVjdGx5LlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSA6IG51bGx9XG4gICAgICAgICAge3NwYWNlcy5tYXAoKHNwKSA9PiAoXG4gICAgICAgICAgICA8ZGl2IGtleT17c3AubW91bnQucGF0aH0gc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBmbGV4RGlyZWN0aW9uOiAnY29sdW1uJywgZ2FwOiA2IH19PlxuICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGdhcDogOSwgcGFkZGluZzogJzJweCA0cHgnIH19PlxuICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywgY29sb3I6ICd2YXIoLS1pbmstMiknIH19PlxuICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cInVzZXJzXCIgc2l6ZT17MTV9IHN0cm9rZVdpZHRoPXsxLjc1fSAvPlxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmbGV4OiAxLCBmb250OiAnNzAwIDEzLjVweC8xIHZhcigtLWRpc3ApJywgbGV0dGVyU3BhY2luZzogJy4wMWVtJywgY29sb3I6ICd2YXIoLS1pbmspJyB9fT57c3AubGFiZWx9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDxSb2xlQ2hpcCByb2xlPXtzcC5yb2xlfSAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAge3NwLmJvYXJkcy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBwYWRkaW5nOiAnMnB4IDEycHggNnB4JywgZm9udDogJ3ZhcigtLW1vbm8teHMpJywgY29sb3I6ICd2YXIoLS1pbmstMyknIH19Pk5vIGJvYXJkcyBpbiB0aGlzIHNwYWNlIHlldC48L2Rpdj5cbiAgICAgICAgICAgICAgKSA6IG51bGx9XG4gICAgICAgICAgICAgIHtzcC5ib2FyZHMubWFwKChiKSA9PiAoXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAga2V5PXtiLm5hbWV9XG4gICAgICAgICAgICAgICAgICBhcmlhLWJ1c3k9e2J1c3kgPT09ICdvcGVuLWJvYXJkJ31cbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtidXN5ICE9PSBudWxsfVxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAvLyBObyBjbG9zZSgpIGZpcnN0OiB0aGUgYnVzeSBzdGF0ZSB0aGlzIHJvdyBlbnRlcnMgbXVzdCBiZVxuICAgICAgICAgICAgICAgICAgICAvLyBWSVNJQkxFIChSLUlYLTIpOyBsb2FkQm9hcmRJbnRvIGNsb3NlcyB0aGUgY2hvb3NlciBvblxuICAgICAgICAgICAgICAgICAgICAvLyBzdWNjZXNzLCBhbmQgYSBmYWlsdXJlIGxlYXZlcyBpdCBvcGVuIHRvIHJldHJ5LlxuICAgICAgICAgICAgICAgICAgICB2b2lkIHdiLm9wZW5Cb2FyZEF0KGIudGFyZ2V0KTtcbiAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgICAgICBkaXNwbGF5OiAnZmxleCcsXG4gICAgICAgICAgICAgICAgICAgIGFsaWduSXRlbXM6ICdjZW50ZXInLFxuICAgICAgICAgICAgICAgICAgICBnYXA6IDEyLFxuICAgICAgICAgICAgICAgICAgICBwYWRkaW5nOiAnMTFweCAxMnB4JyxcbiAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogJ3ZhcigtLWJnKScsXG4gICAgICAgICAgICAgICAgICAgIGJvcmRlcjogJzFweCBzb2xpZCB2YXIoLS1saW5lKScsXG4gICAgICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogMTEsXG4gICAgICAgICAgICAgICAgICAgIGN1cnNvcjogJ3BvaW50ZXInLFxuICAgICAgICAgICAgICAgICAgICB0ZXh0QWxpZ246ICdsZWZ0JyxcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6ICd2YXIoLS1pbmspJyxcbiAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCB3aWR0aDogMzQsIGhlaWdodDogMzQsIGJvcmRlclJhZGl1czogOSwgYmFja2dyb3VuZDogJ3ZhcigtLXBhbmVsLTIpJywgYm9yZGVyOiAnMXB4IHNvbGlkIHZhcigtLWxpbmUpJywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGp1c3RpZnlDb250ZW50OiAnY2VudGVyJywgY29sb3I6ICd2YXIoLS1pbmstMiknLCBmbGV4OiAnbm9uZScgfX0+XG4gICAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJmcmFtZVwiIHNpemU9ezE2fSBzdHJva2VXaWR0aD17MS43NX0gLz5cbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGZsZXg6IDEsIG1pbldpZHRoOiAwIH19PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnQ6ICc2MDAgMTQuNXB4LzEuMiB2YXIoLS1zYW5zKScsIG92ZXJmbG93OiAnaGlkZGVuJywgdGV4dE92ZXJmbG93OiAnZWxsaXBzaXMnLCB3aGl0ZVNwYWNlOiAnbm93cmFwJyB9fT57Yi5uYW1lfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnQ6ICd2YXIoLS1tb25vLXhzKScsIGNvbG9yOiAndmFyKC0taW5rLTMpJywgbWFyZ2luVG9wOiAzIH19PmJvYXJkIGZvbGRlcjwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAge3NwLnJvbGUgPT09ICdybycgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJsb2NrXCIgc2l6ZT17MTR9IGNvbG9yPVwidmFyKC0taW5rLTMpXCIgc3Ryb2tlV2lkdGg9ezJ9IC8+XG4gICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiY2hldlJpZ2h0XCIgc2l6ZT17MTZ9IGNvbG9yPVwidmFyKC0taW5rLTMpXCIgc3Ryb2tlV2lkdGg9ezEuNzV9IC8+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAge3NwLnJvbGUgPT09ICdydycgPyAoXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgYXJpYS1idXN5PXtidXN5ID09PSAnbmV3LWJvYXJkJ31cbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtidXN5ICE9PSBudWxsfVxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICB2b2lkIHdiLm5ld0JvYXJkSW4oeyByb290OiBzcC5tb3VudC5wYXRoLCBtb2RlOiAncncnLCBzcGFjZUlkOiBzcC5tb3VudC5pZCB9KTtcbiAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBnYXA6IDgsIHBhZGRpbmc6ICc4cHggMTJweCcsIGJhY2tncm91bmQ6ICdub25lJywgYm9yZGVyOiAnMXB4IGRhc2hlZCB2YXIoLS1saW5lLTIpJywgYm9yZGVyUmFkaXVzOiAxMSwgY29sb3I6ICd2YXIoLS1pbmstMyknLCBmb250OiAndmFyKC0tYm9keS1zbSknLCBjdXJzb3I6ICdwb2ludGVyJywgdGV4dEFsaWduOiAnbGVmdCcgfX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwicGx1c1wiIHNpemU9ezE0fSBzdHJva2VXaWR0aD17Mn0gLz5cbiAgICAgICAgICAgICAgICAgIHtgTmV3IGJvYXJkIGluICR7c3AubGFiZWx9YH1cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgKSA6IG51bGx9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBzdHlsZT17eyBwYWRkaW5nOiAnMTJweCAxNHB4JywgYm9yZGVyVG9wOiAnMXB4IHNvbGlkIHZhcigtLWxpbmUpJywgZGlzcGxheTogJ2ZsZXgnLCBmbGV4RGlyZWN0aW9uOiAnY29sdW1uJywgZ2FwOiA5LCBmbGV4OiAnbm9uZScgfX0+XG4gICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGdhcDogOCB9fT5cbiAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4geyB3Yi5hZGRTcGFjZSgpOyB9fSBzdHlsZT17eyBmbGV4OiAxLCBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBqdXN0aWZ5Q29udGVudDogJ2NlbnRlcicsIGdhcDogOCwgcGFkZGluZzogMTIsIGJhY2tncm91bmQ6ICd2YXIoLS1ncmFkKScsIGJvcmRlcjogJ25vbmUnLCBib3JkZXJSYWRpdXM6ICd2YXIoLS1yLXBpbGwpJywgY29sb3I6ICcjMWExMDIwJywgZm9udDogJ3ZhcigtLWxhYmVsKScsIGN1cnNvcjogJ3BvaW50ZXInIH19PlxuICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwidXNlclBsdXNcIiBzaXplPXsxNn0gY29sb3I9XCIjMWExMDIwXCIgc3Ryb2tlV2lkdGg9ezEuNzV9IC8+XG4gICAgICAgICAgICAgIEFkZCBhIHNwYWNl4oCmXG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDxidXR0b24gYXJpYS1idXN5PXtidXN5ID09PSAnb3Blbi1ib2FyZCd9IGRpc2FibGVkPXtidXN5ICE9PSBudWxsfSBvbkNsaWNrPXsoKSA9PiB7IHdiLm9wZW5Cb2FyZCgpOyB9fSBzdHlsZT17eyBmbGV4OiAnbm9uZScsIGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGp1c3RpZnlDb250ZW50OiAnY2VudGVyJywgZ2FwOiA3LCBwYWRkaW5nOiAnMTJweCAxNnB4JywgYmFja2dyb3VuZDogJ3ZhcigtLWJnKScsIGJvcmRlcjogJzFweCBzb2xpZCB2YXIoLS1saW5lLTIpJywgYm9yZGVyUmFkaXVzOiAndmFyKC0tci1waWxsKScsIGNvbG9yOiAndmFyKC0taW5rKScsIGZvbnQ6ICd2YXIoLS1sYWJlbCknLCBjdXJzb3I6ICdwb2ludGVyJyB9fT5cbiAgICAgICAgICAgICAgPEljb24gbmFtZT1cImZvbGRlclwiIHNpemU9ezE2fSBzdHJva2VXaWR0aD17MS43NX0gLz5cbiAgICAgICAgICAgICAgT3BlbiBmb2xkZXLigKZcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udDogJ3ZhcigtLW1vbm8teHMpJywgY29sb3I6ICd2YXIoLS1pbmstMyknLCB0ZXh0QWxpZ246ICdjZW50ZXInIH19PkFkZGluZyBhIHNwYWNlIGlzIGdyYW50ZWQgYnkgaW1tZWRpYXRlbHkucnVuIOKAlCBuZXZlciBieSB0aGlzIGFwcC48L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgQm9hcmRDaG9vc2VyO1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQVNBLElBQUFBLE1BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLGVBQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLGlCQUFBLEdBQUFGLE9BQUE7QUFDQSxJQUFBRyxVQUFBLEdBQUFILE9BQUE7QUFDQSxJQUFBSSxZQUFBLEdBQUFKLE9BQUE7QUFFQSxJQUFBSyxLQUFBLEdBQUFDLHNCQUFBLENBQUFOLE9BQUE7QUFBMEIsSUFBQU8sV0FBQSxHQUFBUCxPQUFBO0FBQUEsSUFBQVEsRUFBQSxHQUFBQyxZQUFBLElBZjFCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFBQSxTQUFBSCx1QkFBQUksQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQVVBLFNBQVNHLFFBQVFBLENBQUM7RUFBRUM7QUFBNEIsQ0FBQyxFQUFFO0VBQ2pELE1BQU1DLEVBQUUsR0FBR0QsSUFBSSxLQUFLLElBQUk7RUFDeEIsb0JBQ0UsSUFBQVAsV0FBQSxDQUFBUyxHQUFBO0lBQ0VDLEtBQUssRUFBRTtNQUNMQyxPQUFPLEVBQUUsYUFBYTtNQUN0QkMsVUFBVSxFQUFFLFFBQVE7TUFDcEJDLEdBQUcsRUFBRSxDQUFDO01BQ05DLE9BQU8sRUFBRSxTQUFTO01BQ2xCQyxZQUFZLEVBQUUsZUFBZTtNQUM3QkMsSUFBSSxFQUFFLGdCQUFnQjtNQUN0QkMsYUFBYSxFQUFFLE9BQU87TUFDdEJDLFVBQVUsRUFBRSxRQUFRO01BQ3BCQyxJQUFJLEVBQUUsTUFBTTtNQUNaQyxVQUFVLEVBQUVaLEVBQUUsR0FBRyx3REFBd0QsR0FBRyxnQkFBZ0I7TUFDNUZhLE1BQU0sRUFBRSxhQUFhYixFQUFFLEdBQUcsdURBQXVELEdBQUcsZUFBZSxFQUFFO01BQ3JHYyxLQUFLLEVBQUVkLEVBQUUsR0FBRyxZQUFZLEdBQUc7SUFDN0IsQ0FBRTtJQUFBZSxRQUFBLEVBRURmLEVBQUUsR0FBRyxVQUFVLGdCQUNkLElBQUFSLFdBQUEsQ0FBQXdCLElBQUEsRUFBQXhCLFdBQUEsQ0FBQXlCLFFBQUE7TUFBQUYsUUFBQSxnQkFDRSxJQUFBdkIsV0FBQSxDQUFBUyxHQUFBLEVBQUNYLEtBQUEsQ0FBQU8sT0FBSTtRQUFDcUIsSUFBSSxFQUFDLE1BQU07UUFBQ0MsSUFBSSxFQUFFLEVBQUc7UUFBQ0MsV0FBVyxFQUFFO01BQUUsQ0FBRSxDQUFDLGFBRWhEO0lBQUEsQ0FBRTtFQUNILENBQ0csQ0FBQztBQUVYO0FBQUNDLEVBQUEsR0EzQlF2QixRQUFRO0FBNkJqQixTQUFTd0IsWUFBWUEsQ0FBQSxFQUFHO0VBQUE3QixFQUFBO0VBQ3RCLE1BQU04QixFQUFFLEdBQUcsSUFBQUMscUJBQUssRUFBQyxDQUFDO0VBQ2xCLE1BQU1DLEtBQUssR0FBR0EsQ0FBQSxLQUFNRixFQUFFLENBQUNHLFNBQVMsQ0FBQyxJQUFJLENBQUM7RUFDdEM7RUFDQSxNQUFNQyxTQUFTLEdBQUcsSUFBQUMsa0NBQWdCLEVBQUMsSUFBSSxFQUFFSCxLQUFLLENBQUM7RUFDL0MsTUFBTSxDQUFDSSxNQUFNLEVBQUVDLFNBQVMsQ0FBQyxHQUFHLElBQUFDLGVBQVEsRUFBZ0IsRUFBRSxDQUFDOztFQUV2RDtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsSUFBQUMsZ0JBQVMsRUFBQyxNQUFNO0lBQ2QsSUFBSUMsU0FBUyxHQUFHLEtBQUs7SUFDckIsSUFBQUMsOEJBQW1CLEVBQUNYLEVBQUUsQ0FBQ1ksS0FBSyxDQUFDQyxNQUFNLENBQUMsQ0FDakNDLElBQUksQ0FBRUMsSUFBSSxJQUFLO01BQ2QsSUFBSSxDQUFDTCxTQUFTLEVBQUVILFNBQVMsQ0FBQ1EsSUFBSSxDQUFDO0lBQ2pDLENBQUMsQ0FBQyxDQUNEQyxLQUFLLENBQUMsTUFBTTtNQUNYO0lBQUEsQ0FDRCxDQUFDO0lBQ0osT0FBTyxNQUFNO01BQ1hOLFNBQVMsR0FBRyxJQUFJO0lBQ2xCLENBQUM7RUFDSCxDQUFDLEVBQUUsQ0FBQ1YsRUFBRSxDQUFDWSxLQUFLLENBQUNDLE1BQU0sQ0FBQyxDQUFDO0VBRXJCLE1BQU1JLElBQUksR0FBR2pCLEVBQUUsQ0FBQ1ksS0FBSyxDQUFDSyxJQUFJO0VBQzFCLE1BQU1DLFNBQVMsR0FBR0QsSUFBSSxHQUFHRSx3QkFBVyxDQUFDRixJQUFJLENBQUMsR0FBRyxJQUFJO0VBRWpELG9CQUNFLElBQUFoRCxXQUFBLENBQUF3QixJQUFBO0lBQUtkLEtBQUssRUFBRTtNQUFFeUMsUUFBUSxFQUFFLFVBQVU7TUFBRUMsS0FBSyxFQUFFLENBQUM7TUFBRUMsTUFBTSxFQUFFLEVBQUU7TUFBRWpDLFVBQVUsRUFBRSxpREFBaUQ7TUFBRWtDLGNBQWMsRUFBRSxXQUFXO01BQUUzQyxPQUFPLEVBQUUsTUFBTTtNQUFFQyxVQUFVLEVBQUUsUUFBUTtNQUFFMkMsY0FBYyxFQUFFLFFBQVE7TUFBRXpDLE9BQU8sRUFBRTtJQUFHLENBQUU7SUFBQVMsUUFBQSxnQkFDbk8sSUFBQXZCLFdBQUEsQ0FBQVMsR0FBQTtNQUFRK0MsT0FBTyxFQUFFdkIsS0FBTTtNQUFDLGNBQVcsT0FBTztNQUFDdkIsS0FBSyxFQUFFO1FBQUV5QyxRQUFRLEVBQUUsVUFBVTtRQUFFTSxHQUFHLEVBQUUsRUFBRTtRQUFFQyxLQUFLLEVBQUUsRUFBRTtRQUFFL0MsT0FBTyxFQUFFLE1BQU07UUFBRUcsT0FBTyxFQUFFLENBQUM7UUFBRU0sVUFBVSxFQUFFLGNBQWM7UUFBRUMsTUFBTSxFQUFFLHVCQUF1QjtRQUFFTixZQUFZLEVBQUUsS0FBSztRQUFFTyxLQUFLLEVBQUUsY0FBYztRQUFFcUMsTUFBTSxFQUFFO01BQVUsQ0FBRTtNQUFBcEMsUUFBQSxlQUN0UCxJQUFBdkIsV0FBQSxDQUFBUyxHQUFBLEVBQUNYLEtBQUEsQ0FBQU8sT0FBSTtRQUFDcUIsSUFBSSxFQUFDLEdBQUc7UUFBQ0MsSUFBSSxFQUFFO01BQUcsQ0FBRTtJQUFDLENBQ3JCLENBQUMsZUFFVCxJQUFBM0IsV0FBQSxDQUFBd0IsSUFBQTtNQUFLb0MsR0FBRyxFQUFFekIsU0FBVTtNQUFDMEIsUUFBUSxFQUFFLENBQUMsQ0FBRTtNQUFDbkQsS0FBSyxFQUFFO1FBQUVvRCxLQUFLLEVBQUUsa0JBQWtCO1FBQUVDLFNBQVMsRUFBRSxNQUFNO1FBQUUzQyxVQUFVLEVBQUUsY0FBYztRQUFFQyxNQUFNLEVBQUUsdUJBQXVCO1FBQUVOLFlBQVksRUFBRSxFQUFFO1FBQUVpRCxTQUFTLEVBQUUscUJBQXFCO1FBQUVDLFFBQVEsRUFBRSxRQUFRO1FBQUV0RCxPQUFPLEVBQUUsTUFBTTtRQUFFdUQsYUFBYSxFQUFFO01BQVMsQ0FBRTtNQUFBM0MsUUFBQSxnQkFDeFEsSUFBQXZCLFdBQUEsQ0FBQXdCLElBQUE7UUFBS2QsS0FBSyxFQUFFO1VBQUVJLE9BQU8sRUFBRSxnQkFBZ0I7VUFBRXFELFlBQVksRUFBRSx1QkFBdUI7VUFBRWhELElBQUksRUFBRTtRQUFPLENBQUU7UUFBQUksUUFBQSxnQkFDN0YsSUFBQXZCLFdBQUEsQ0FBQVMsR0FBQTtVQUFLQyxLQUFLLEVBQUU7WUFBRU0sSUFBSSxFQUFFLHdCQUF3QjtZQUFFQyxhQUFhLEVBQUU7VUFBUyxDQUFFO1VBQUFNLFFBQUEsRUFBQztRQUFhLENBQUssQ0FBQyxlQUM1RixJQUFBdkIsV0FBQSxDQUFBUyxHQUFBO1VBQUtDLEtBQUssRUFBRTtZQUFFTSxJQUFJLEVBQUUsZ0JBQWdCO1lBQUVNLEtBQUssRUFBRSxjQUFjO1lBQUU4QyxTQUFTLEVBQUU7VUFBRSxDQUFFO1VBQUE3QyxRQUFBLEVBQUM7UUFBaUYsQ0FBSyxDQUFDLEVBQ25LMEIsU0FBUyxnQkFDUixJQUFBakQsV0FBQSxDQUFBUyxHQUFBO1VBQUssYUFBVSxRQUFRO1VBQUNDLEtBQUssRUFBRTtZQUFFTSxJQUFJLEVBQUUsZ0JBQWdCO1lBQUVNLEtBQUssRUFBRSxzQkFBc0I7WUFBRThDLFNBQVMsRUFBRTtVQUFFLENBQUU7VUFBQTdDLFFBQUEsRUFDcEcwQjtRQUFTLENBQ1AsQ0FBQyxHQUNKLElBQUk7TUFBQSxDQUNMLENBQUMsZUFFTixJQUFBakQsV0FBQSxDQUFBd0IsSUFBQTtRQUFLNkMsU0FBUyxFQUFDLFdBQVc7UUFBQzNELEtBQUssRUFBRTtVQUFFSSxPQUFPLEVBQUUsRUFBRTtVQUFFSCxPQUFPLEVBQUUsTUFBTTtVQUFFdUQsYUFBYSxFQUFFLFFBQVE7VUFBRXJELEdBQUcsRUFBRSxFQUFFO1VBQUV5RCxTQUFTLEVBQUUsTUFBTTtVQUFFbkQsSUFBSSxFQUFFO1FBQUUsQ0FBRTtRQUFBSSxRQUFBLEdBQzlIYyxNQUFNLENBQUNrQyxNQUFNLEtBQUssQ0FBQyxnQkFDbEIsSUFBQXZFLFdBQUEsQ0FBQVMsR0FBQTtVQUFLQyxLQUFLLEVBQUU7WUFBRUksT0FBTyxFQUFFLFdBQVc7WUFBRUUsSUFBSSxFQUFFLGdCQUFnQjtZQUFFTSxLQUFLLEVBQUU7VUFBZSxDQUFFO1VBQUFDLFFBQUEsRUFBQztRQUVyRixDQUFLLENBQUMsR0FDSixJQUFJLEVBQ1BjLE1BQU0sQ0FBQ21DLEdBQUcsQ0FBRUMsRUFBRSxpQkFDYixJQUFBekUsV0FBQSxDQUFBd0IsSUFBQTtVQUF5QmQsS0FBSyxFQUFFO1lBQUVDLE9BQU8sRUFBRSxNQUFNO1lBQUV1RCxhQUFhLEVBQUUsUUFBUTtZQUFFckQsR0FBRyxFQUFFO1VBQUUsQ0FBRTtVQUFBVSxRQUFBLGdCQUNuRixJQUFBdkIsV0FBQSxDQUFBd0IsSUFBQTtZQUFLZCxLQUFLLEVBQUU7Y0FBRUMsT0FBTyxFQUFFLE1BQU07Y0FBRUMsVUFBVSxFQUFFLFFBQVE7Y0FBRUMsR0FBRyxFQUFFLENBQUM7Y0FBRUMsT0FBTyxFQUFFO1lBQVUsQ0FBRTtZQUFBUyxRQUFBLGdCQUNoRixJQUFBdkIsV0FBQSxDQUFBUyxHQUFBO2NBQU1DLEtBQUssRUFBRTtnQkFBRUMsT0FBTyxFQUFFLE1BQU07Z0JBQUVXLEtBQUssRUFBRTtjQUFlLENBQUU7Y0FBQUMsUUFBQSxlQUN0RCxJQUFBdkIsV0FBQSxDQUFBUyxHQUFBLEVBQUNYLEtBQUEsQ0FBQU8sT0FBSTtnQkFBQ3FCLElBQUksRUFBQyxPQUFPO2dCQUFDQyxJQUFJLEVBQUUsRUFBRztnQkFBQ0MsV0FBVyxFQUFFO2NBQUssQ0FBRTtZQUFDLENBQzlDLENBQUMsZUFDUCxJQUFBNUIsV0FBQSxDQUFBUyxHQUFBO2NBQU1DLEtBQUssRUFBRTtnQkFBRVMsSUFBSSxFQUFFLENBQUM7Z0JBQUVILElBQUksRUFBRSwwQkFBMEI7Z0JBQUVDLGFBQWEsRUFBRSxPQUFPO2dCQUFFSyxLQUFLLEVBQUU7Y0FBYSxDQUFFO2NBQUFDLFFBQUEsRUFBRWtELEVBQUUsQ0FBQ0M7WUFBSyxDQUFPLENBQUMsZUFDMUgsSUFBQTFFLFdBQUEsQ0FBQVMsR0FBQSxFQUFDSCxRQUFRO2NBQUNDLElBQUksRUFBRWtFLEVBQUUsQ0FBQ2xFO1lBQUssQ0FBRSxDQUFDO1VBQUEsQ0FDeEIsQ0FBQyxFQUNMa0UsRUFBRSxDQUFDRSxNQUFNLENBQUNKLE1BQU0sS0FBSyxDQUFDLGdCQUNyQixJQUFBdkUsV0FBQSxDQUFBUyxHQUFBO1lBQUtDLEtBQUssRUFBRTtjQUFFSSxPQUFPLEVBQUUsY0FBYztjQUFFRSxJQUFJLEVBQUUsZ0JBQWdCO2NBQUVNLEtBQUssRUFBRTtZQUFlLENBQUU7WUFBQUMsUUFBQSxFQUFDO1VBQTRCLENBQUssQ0FBQyxHQUN4SCxJQUFJLEVBQ1BrRCxFQUFFLENBQUNFLE1BQU0sQ0FBQ0gsR0FBRyxDQUFFSSxDQUFDLGlCQUNmLElBQUE1RSxXQUFBLENBQUF3QixJQUFBO1lBRUUsYUFBV3dCLElBQUksS0FBSyxZQUFhO1lBQ2pDNkIsUUFBUSxFQUFFN0IsSUFBSSxLQUFLLElBQUs7WUFDeEJRLE9BQU8sRUFBRUEsQ0FBQSxLQUFNO2NBQ2I7Y0FDQTtjQUNBO2NBQ0EsS0FBS3pCLEVBQUUsQ0FBQytDLFdBQVcsQ0FBQ0YsQ0FBQyxDQUFDRyxNQUFNLENBQUM7WUFDL0IsQ0FBRTtZQUNGckUsS0FBSyxFQUFFO2NBQ0xDLE9BQU8sRUFBRSxNQUFNO2NBQ2ZDLFVBQVUsRUFBRSxRQUFRO2NBQ3BCQyxHQUFHLEVBQUUsRUFBRTtjQUNQQyxPQUFPLEVBQUUsV0FBVztjQUNwQk0sVUFBVSxFQUFFLFdBQVc7Y0FDdkJDLE1BQU0sRUFBRSx1QkFBdUI7Y0FDL0JOLFlBQVksRUFBRSxFQUFFO2NBQ2hCNEMsTUFBTSxFQUFFLFNBQVM7Y0FDakJxQixTQUFTLEVBQUUsTUFBTTtjQUNqQjFELEtBQUssRUFBRTtZQUNULENBQUU7WUFBQUMsUUFBQSxnQkFFRixJQUFBdkIsV0FBQSxDQUFBUyxHQUFBO2NBQU1DLEtBQUssRUFBRTtnQkFBRUMsT0FBTyxFQUFFLE1BQU07Z0JBQUVtRCxLQUFLLEVBQUUsRUFBRTtnQkFBRW1CLE1BQU0sRUFBRSxFQUFFO2dCQUFFbEUsWUFBWSxFQUFFLENBQUM7Z0JBQUVLLFVBQVUsRUFBRSxnQkFBZ0I7Z0JBQUVDLE1BQU0sRUFBRSx1QkFBdUI7Z0JBQUVULFVBQVUsRUFBRSxRQUFRO2dCQUFFMkMsY0FBYyxFQUFFLFFBQVE7Z0JBQUVqQyxLQUFLLEVBQUUsY0FBYztnQkFBRUgsSUFBSSxFQUFFO2NBQU8sQ0FBRTtjQUFBSSxRQUFBLGVBQzNOLElBQUF2QixXQUFBLENBQUFTLEdBQUEsRUFBQ1gsS0FBQSxDQUFBTyxPQUFJO2dCQUFDcUIsSUFBSSxFQUFDLE9BQU87Z0JBQUNDLElBQUksRUFBRSxFQUFHO2dCQUFDQyxXQUFXLEVBQUU7Y0FBSyxDQUFFO1lBQUMsQ0FDOUMsQ0FBQyxlQUNQLElBQUE1QixXQUFBLENBQUF3QixJQUFBO2NBQU1kLEtBQUssRUFBRTtnQkFBRVMsSUFBSSxFQUFFLENBQUM7Z0JBQUUrRCxRQUFRLEVBQUU7Y0FBRSxDQUFFO2NBQUEzRCxRQUFBLGdCQUNwQyxJQUFBdkIsV0FBQSxDQUFBUyxHQUFBO2dCQUFLQyxLQUFLLEVBQUU7a0JBQUVNLElBQUksRUFBRSw0QkFBNEI7a0JBQUVpRCxRQUFRLEVBQUUsUUFBUTtrQkFBRWtCLFlBQVksRUFBRSxVQUFVO2tCQUFFakUsVUFBVSxFQUFFO2dCQUFTLENBQUU7Z0JBQUFLLFFBQUEsRUFBRXFELENBQUMsQ0FBQ2xEO2NBQUksQ0FBTSxDQUFDLGVBQ3RJLElBQUExQixXQUFBLENBQUFTLEdBQUE7Z0JBQUtDLEtBQUssRUFBRTtrQkFBRU0sSUFBSSxFQUFFLGdCQUFnQjtrQkFBRU0sS0FBSyxFQUFFLGNBQWM7a0JBQUU4QyxTQUFTLEVBQUU7Z0JBQUUsQ0FBRTtnQkFBQTdDLFFBQUEsRUFBQztjQUFZLENBQUssQ0FBQztZQUFBLENBQzNGLENBQUMsRUFDTmtELEVBQUUsQ0FBQ2xFLElBQUksS0FBSyxJQUFJLGdCQUNmLElBQUFQLFdBQUEsQ0FBQVMsR0FBQSxFQUFDWCxLQUFBLENBQUFPLE9BQUk7Y0FBQ3FCLElBQUksRUFBQyxNQUFNO2NBQUNDLElBQUksRUFBRSxFQUFHO2NBQUNMLEtBQUssRUFBQyxjQUFjO2NBQUNNLFdBQVcsRUFBRTtZQUFFLENBQUUsQ0FBQyxnQkFFbkUsSUFBQTVCLFdBQUEsQ0FBQVMsR0FBQSxFQUFDWCxLQUFBLENBQUFPLE9BQUk7Y0FBQ3FCLElBQUksRUFBQyxXQUFXO2NBQUNDLElBQUksRUFBRSxFQUFHO2NBQUNMLEtBQUssRUFBQyxjQUFjO2NBQUNNLFdBQVcsRUFBRTtZQUFLLENBQUUsQ0FDM0U7VUFBQSxHQWpDSWdELENBQUMsQ0FBQ2xELElBa0NELENBQ1QsQ0FBQyxFQUNEK0MsRUFBRSxDQUFDbEUsSUFBSSxLQUFLLElBQUksZ0JBQ2YsSUFBQVAsV0FBQSxDQUFBd0IsSUFBQTtZQUNFLGFBQVd3QixJQUFJLEtBQUssV0FBWTtZQUNoQzZCLFFBQVEsRUFBRTdCLElBQUksS0FBSyxJQUFLO1lBQ3hCUSxPQUFPLEVBQUVBLENBQUEsS0FBTTtjQUNiLEtBQUt6QixFQUFFLENBQUNxRCxVQUFVLENBQUM7Z0JBQUVDLElBQUksRUFBRVosRUFBRSxDQUFDYSxLQUFLLENBQUNDLElBQUk7Z0JBQUVDLElBQUksRUFBRSxJQUFJO2dCQUFFQyxPQUFPLEVBQUVoQixFQUFFLENBQUNhLEtBQUssQ0FBQ0k7Y0FBRyxDQUFDLENBQUM7WUFDL0UsQ0FBRTtZQUNGaEYsS0FBSyxFQUFFO2NBQUVDLE9BQU8sRUFBRSxNQUFNO2NBQUVDLFVBQVUsRUFBRSxRQUFRO2NBQUVDLEdBQUcsRUFBRSxDQUFDO2NBQUVDLE9BQU8sRUFBRSxVQUFVO2NBQUVNLFVBQVUsRUFBRSxNQUFNO2NBQUVDLE1BQU0sRUFBRSwwQkFBMEI7Y0FBRU4sWUFBWSxFQUFFLEVBQUU7Y0FBRU8sS0FBSyxFQUFFLGNBQWM7Y0FBRU4sSUFBSSxFQUFFLGdCQUFnQjtjQUFFMkMsTUFBTSxFQUFFLFNBQVM7Y0FBRXFCLFNBQVMsRUFBRTtZQUFPLENBQUU7WUFBQXpELFFBQUEsZ0JBRTdPLElBQUF2QixXQUFBLENBQUFTLEdBQUEsRUFBQ1gsS0FBQSxDQUFBTyxPQUFJO2NBQUNxQixJQUFJLEVBQUMsTUFBTTtjQUFDQyxJQUFJLEVBQUUsRUFBRztjQUFDQyxXQUFXLEVBQUU7WUFBRSxDQUFFLENBQUMsRUFDN0MsZ0JBQWdCNkMsRUFBRSxDQUFDQyxLQUFLLEVBQUU7VUFBQSxDQUNyQixDQUFDLEdBQ1AsSUFBSTtRQUFBLEdBN0RBRCxFQUFFLENBQUNhLEtBQUssQ0FBQ0MsSUE4RGQsQ0FDTixDQUFDO01BQUEsQ0FDQyxDQUFDLGVBRU4sSUFBQXZGLFdBQUEsQ0FBQXdCLElBQUE7UUFBS2QsS0FBSyxFQUFFO1VBQUVJLE9BQU8sRUFBRSxXQUFXO1VBQUU2RSxTQUFTLEVBQUUsdUJBQXVCO1VBQUVoRixPQUFPLEVBQUUsTUFBTTtVQUFFdUQsYUFBYSxFQUFFLFFBQVE7VUFBRXJELEdBQUcsRUFBRSxDQUFDO1VBQUVNLElBQUksRUFBRTtRQUFPLENBQUU7UUFBQUksUUFBQSxnQkFDdkksSUFBQXZCLFdBQUEsQ0FBQXdCLElBQUE7VUFBS2QsS0FBSyxFQUFFO1lBQUVDLE9BQU8sRUFBRSxNQUFNO1lBQUVFLEdBQUcsRUFBRTtVQUFFLENBQUU7VUFBQVUsUUFBQSxnQkFDdEMsSUFBQXZCLFdBQUEsQ0FBQXdCLElBQUE7WUFBUWdDLE9BQU8sRUFBRUEsQ0FBQSxLQUFNO2NBQUV6QixFQUFFLENBQUM2RCxRQUFRLENBQUMsQ0FBQztZQUFFLENBQUU7WUFBQ2xGLEtBQUssRUFBRTtjQUFFUyxJQUFJLEVBQUUsQ0FBQztjQUFFUixPQUFPLEVBQUUsTUFBTTtjQUFFQyxVQUFVLEVBQUUsUUFBUTtjQUFFMkMsY0FBYyxFQUFFLFFBQVE7Y0FBRTFDLEdBQUcsRUFBRSxDQUFDO2NBQUVDLE9BQU8sRUFBRSxFQUFFO2NBQUVNLFVBQVUsRUFBRSxhQUFhO2NBQUVDLE1BQU0sRUFBRSxNQUFNO2NBQUVOLFlBQVksRUFBRSxlQUFlO2NBQUVPLEtBQUssRUFBRSxTQUFTO2NBQUVOLElBQUksRUFBRSxjQUFjO2NBQUUyQyxNQUFNLEVBQUU7WUFBVSxDQUFFO1lBQUFwQyxRQUFBLGdCQUN2UixJQUFBdkIsV0FBQSxDQUFBUyxHQUFBLEVBQUNYLEtBQUEsQ0FBQU8sT0FBSTtjQUFDcUIsSUFBSSxFQUFDLFVBQVU7Y0FBQ0MsSUFBSSxFQUFFLEVBQUc7Y0FBQ0wsS0FBSyxFQUFDLFNBQVM7Y0FBQ00sV0FBVyxFQUFFO1lBQUssQ0FBRSxDQUFDLHFCQUV2RTtVQUFBLENBQVEsQ0FBQyxlQUNULElBQUE1QixXQUFBLENBQUF3QixJQUFBO1lBQVEsYUFBV3dCLElBQUksS0FBSyxZQUFhO1lBQUM2QixRQUFRLEVBQUU3QixJQUFJLEtBQUssSUFBSztZQUFDUSxPQUFPLEVBQUVBLENBQUEsS0FBTTtjQUFFekIsRUFBRSxDQUFDOEQsU0FBUyxDQUFDLENBQUM7WUFBRSxDQUFFO1lBQUNuRixLQUFLLEVBQUU7Y0FBRVMsSUFBSSxFQUFFLE1BQU07Y0FBRVIsT0FBTyxFQUFFLE1BQU07Y0FBRUMsVUFBVSxFQUFFLFFBQVE7Y0FBRTJDLGNBQWMsRUFBRSxRQUFRO2NBQUUxQyxHQUFHLEVBQUUsQ0FBQztjQUFFQyxPQUFPLEVBQUUsV0FBVztjQUFFTSxVQUFVLEVBQUUsV0FBVztjQUFFQyxNQUFNLEVBQUUseUJBQXlCO2NBQUVOLFlBQVksRUFBRSxlQUFlO2NBQUVPLEtBQUssRUFBRSxZQUFZO2NBQUVOLElBQUksRUFBRSxjQUFjO2NBQUUyQyxNQUFNLEVBQUU7WUFBVSxDQUFFO1lBQUFwQyxRQUFBLGdCQUNyWCxJQUFBdkIsV0FBQSxDQUFBUyxHQUFBLEVBQUNYLEtBQUEsQ0FBQU8sT0FBSTtjQUFDcUIsSUFBSSxFQUFDLFFBQVE7Y0FBQ0MsSUFBSSxFQUFFLEVBQUc7Y0FBQ0MsV0FBVyxFQUFFO1lBQUssQ0FBRSxDQUFDLHFCQUVyRDtVQUFBLENBQVEsQ0FBQztRQUFBLENBQ04sQ0FBQyxlQUNOLElBQUE1QixXQUFBLENBQUFTLEdBQUE7VUFBS0MsS0FBSyxFQUFFO1lBQUVNLElBQUksRUFBRSxnQkFBZ0I7WUFBRU0sS0FBSyxFQUFFLGNBQWM7WUFBRTBELFNBQVMsRUFBRTtVQUFTLENBQUU7VUFBQXpELFFBQUEsRUFBQztRQUFpRSxDQUFLLENBQUM7TUFBQSxDQUN4SixDQUFDO0lBQUEsQ0FDSCxDQUFDO0VBQUEsQ0FDSCxDQUFDO0FBRVY7QUFBQ3RCLEVBQUEsQ0F2SVE2QixZQUFZO0VBQUEsUUFDUkUscUJBQUssRUFHRUksa0NBQWdCO0FBQUE7QUFBQTBELEdBQUEsR0FKM0JoRSxZQUFZO0FBQUEsSUFBQWlFLFFBQUEsR0FBQUMsT0FBQSxDQUFBM0YsT0FBQSxHQXlJTnlCLFlBQVk7QUFBQSxJQUFBRCxFQUFBLEVBQUFpRSxHQUFBO0FBQUFHLFlBQUEsQ0FBQXBFLEVBQUE7QUFBQW9FLFlBQUEsQ0FBQUgsR0FBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}