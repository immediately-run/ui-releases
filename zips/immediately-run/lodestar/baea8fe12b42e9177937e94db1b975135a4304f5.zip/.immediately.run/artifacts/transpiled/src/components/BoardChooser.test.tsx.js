var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

var _vitest = require("vitest");
var _react = require("@testing-library/react");
var _useLodestar = require("../hooks/useLodestar");
var _context = require("../lib/context");
var _StateScreens = _interopRequireDefault(require("./StateScreens"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // @vitest-environment jsdom
// The adoption proof (R3-607): the board chooser carries the dialog contract —
// Escape closes it and focus returns to the control that opened it.
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
_vitest.vi.mock('@immediately-run/sdk/mounts', () => ({
  getMounts: () => [],
  onMountsChange: () => () => {},
  openSettings: async () => {
    throw new Error('no host transport');
  }
}));
function Harness() {
  _s();
  const wb = (0, _useLodestar.useLodestar)();
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_context.LodestarContext.Provider, {
    value: wb,
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
      onClick: () => wb.setScreen('chooser'),
      children: "Open chooser"
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_StateScreens.default, {})]
  });
}
_s(Harness, "9OrxXbG+0O8NHxj+P8Jiv+9I85A=", false, function () {
  return [_useLodestar.useLodestar];
});
_c = Harness;
(0, _vitest.describe)('BoardChooser adoption (R3-607)', () => {
  (0, _vitest.it)('Escape closes the chooser and focus returns to the opener', () => {
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(Harness, {}));
    const opener = _react.screen.getByRole('button', {
      name: 'Open chooser'
    });
    opener.focus();
    _react.fireEvent.click(opener);
    // The chooser is up (its heading is rendered).
    (0, _vitest.expect)(_react.screen.getByText('Open a board.')).toBeInTheDocument();
    _react.fireEvent.keyDown(document, {
      key: 'Escape'
    });
    (0, _vitest.expect)(_react.screen.queryByText('Open a board.')).not.toBeInTheDocument();
    (0, _vitest.expect)(document.activeElement).toBe(opener);
  });
});
var _c;
$RefreshReg$(_c, "Harness");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZXN0IiwicmVxdWlyZSIsIl9yZWFjdCIsIl91c2VMb2Rlc3RhciIsIl9jb250ZXh0IiwiX1N0YXRlU2NyZWVucyIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwidmkiLCJtb2NrIiwiZ2V0TW91bnRzIiwib25Nb3VudHNDaGFuZ2UiLCJvcGVuU2V0dGluZ3MiLCJFcnJvciIsIkhhcm5lc3MiLCJ3YiIsInVzZUxvZGVzdGFyIiwianN4cyIsIkxvZGVzdGFyQ29udGV4dCIsIlByb3ZpZGVyIiwidmFsdWUiLCJjaGlsZHJlbiIsImpzeCIsIm9uQ2xpY2siLCJzZXRTY3JlZW4iLCJfYyIsImRlc2NyaWJlIiwiaXQiLCJyZW5kZXIiLCJvcGVuZXIiLCJzY3JlZW4iLCJnZXRCeVJvbGUiLCJuYW1lIiwiZm9jdXMiLCJmaXJlRXZlbnQiLCJjbGljayIsImV4cGVjdCIsImdldEJ5VGV4dCIsInRvQmVJblRoZURvY3VtZW50Iiwia2V5RG93biIsImRvY3VtZW50Iiwia2V5IiwicXVlcnlCeVRleHQiLCJub3QiLCJhY3RpdmVFbGVtZW50IiwidG9CZSIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkJvYXJkQ2hvb3Nlci50ZXN0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBAdml0ZXN0LWVudmlyb25tZW50IGpzZG9tXG4vLyBUaGUgYWRvcHRpb24gcHJvb2YgKFIzLTYwNyk6IHRoZSBib2FyZCBjaG9vc2VyIGNhcnJpZXMgdGhlIGRpYWxvZyBjb250cmFjdCDigJRcbi8vIEVzY2FwZSBjbG9zZXMgaXQgYW5kIGZvY3VzIHJldHVybnMgdG8gdGhlIGNvbnRyb2wgdGhhdCBvcGVuZWQgaXQuXG5pbXBvcnQgeyBkZXNjcmliZSwgZXhwZWN0LCBpdCwgdmkgfSBmcm9tICd2aXRlc3QnO1xuaW1wb3J0IHsgZmlyZUV2ZW50LCByZW5kZXIsIHNjcmVlbiB9IGZyb20gJ0B0ZXN0aW5nLWxpYnJhcnkvcmVhY3QnO1xuXG52aS5tb2NrKCdAaW1tZWRpYXRlbHktcnVuL3Nkay9tb3VudHMnLCAoKSA9PiAoe1xuICBnZXRNb3VudHM6ICgpID0+IFtdLFxuICBvbk1vdW50c0NoYW5nZTogKCkgPT4gKCkgPT4ge30sXG4gIG9wZW5TZXR0aW5nczogYXN5bmMgKCkgPT4ge1xuICAgIHRocm93IG5ldyBFcnJvcignbm8gaG9zdCB0cmFuc3BvcnQnKTtcbiAgfSxcbn0pKTtcblxuaW1wb3J0IHsgdXNlTG9kZXN0YXIgfSBmcm9tICcuLi9ob29rcy91c2VMb2Rlc3Rhcic7XG5pbXBvcnQgeyBMb2Rlc3RhckNvbnRleHQgfSBmcm9tICcuLi9saWIvY29udGV4dCc7XG5pbXBvcnQgU3RhdGVTY3JlZW5zIGZyb20gJy4vU3RhdGVTY3JlZW5zJztcblxuZnVuY3Rpb24gSGFybmVzcygpIHtcbiAgY29uc3Qgd2IgPSB1c2VMb2Rlc3RhcigpO1xuICByZXR1cm4gKFxuICAgIDxMb2Rlc3RhckNvbnRleHQuUHJvdmlkZXIgdmFsdWU9e3difT5cbiAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gd2Iuc2V0U2NyZWVuKCdjaG9vc2VyJyl9Pk9wZW4gY2hvb3NlcjwvYnV0dG9uPlxuICAgICAgPFN0YXRlU2NyZWVucyAvPlxuICAgIDwvTG9kZXN0YXJDb250ZXh0LlByb3ZpZGVyPlxuICApO1xufVxuXG5kZXNjcmliZSgnQm9hcmRDaG9vc2VyIGFkb3B0aW9uIChSMy02MDcpJywgKCkgPT4ge1xuICBpdCgnRXNjYXBlIGNsb3NlcyB0aGUgY2hvb3NlciBhbmQgZm9jdXMgcmV0dXJucyB0byB0aGUgb3BlbmVyJywgKCkgPT4ge1xuICAgIHJlbmRlcig8SGFybmVzcyAvPik7XG4gICAgY29uc3Qgb3BlbmVyID0gc2NyZWVuLmdldEJ5Um9sZSgnYnV0dG9uJywgeyBuYW1lOiAnT3BlbiBjaG9vc2VyJyB9KTtcbiAgICBvcGVuZXIuZm9jdXMoKTtcbiAgICBmaXJlRXZlbnQuY2xpY2sob3BlbmVyKTtcbiAgICAvLyBUaGUgY2hvb3NlciBpcyB1cCAoaXRzIGhlYWRpbmcgaXMgcmVuZGVyZWQpLlxuICAgIGV4cGVjdChzY3JlZW4uZ2V0QnlUZXh0KCdPcGVuIGEgYm9hcmQuJykpLnRvQmVJblRoZURvY3VtZW50KCk7XG4gICAgZmlyZUV2ZW50LmtleURvd24oZG9jdW1lbnQsIHsga2V5OiAnRXNjYXBlJyB9KTtcbiAgICBleHBlY3Qoc2NyZWVuLnF1ZXJ5QnlUZXh0KCdPcGVuIGEgYm9hcmQuJykpLm5vdC50b0JlSW5UaGVEb2N1bWVudCgpO1xuICAgIGV4cGVjdChkb2N1bWVudC5hY3RpdmVFbGVtZW50KS50b0JlKG9wZW5lcik7XG4gIH0pO1xufSk7XG4iXSwibWFwcGluZ3MiOiI7O0FBR0EsSUFBQUEsT0FBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsTUFBQSxHQUFBRCxPQUFBO0FBVUEsSUFBQUUsWUFBQSxHQUFBRixPQUFBO0FBQ0EsSUFBQUcsUUFBQSxHQUFBSCxPQUFBO0FBQ0EsSUFBQUksYUFBQSxHQUFBQyxzQkFBQSxDQUFBTCxPQUFBO0FBQTBDLElBQUFNLFdBQUEsR0FBQU4sT0FBQTtBQUFBLElBQUFPLEVBQUEsR0FBQUMsWUFBQSxJQWhCMUM7QUFDQTtBQUNBO0FBQUEsU0FBQUgsdUJBQUFJLENBQUEsV0FBQUEsQ0FBQSxJQUFBQSxDQUFBLENBQUFDLFVBQUEsR0FBQUQsQ0FBQSxLQUFBRSxPQUFBLEVBQUFGLENBQUE7QUFJQUcsVUFBRSxDQUFDQyxJQUFJLENBQUMsNkJBQTZCLEVBQUUsT0FBTztFQUM1Q0MsU0FBUyxFQUFFQSxDQUFBLEtBQU0sRUFBRTtFQUNuQkMsY0FBYyxFQUFFQSxDQUFBLEtBQU0sTUFBTSxDQUFDLENBQUM7RUFDOUJDLFlBQVksRUFBRSxNQUFBQSxDQUFBLEtBQVk7SUFDeEIsTUFBTSxJQUFJQyxLQUFLLENBQUMsbUJBQW1CLENBQUM7RUFDdEM7QUFDRixDQUFDLENBQUMsQ0FBQztBQU1ILFNBQVNDLE9BQU9BLENBQUEsRUFBRztFQUFBWCxFQUFBO0VBQ2pCLE1BQU1ZLEVBQUUsR0FBRyxJQUFBQyx3QkFBVyxFQUFDLENBQUM7RUFDeEIsb0JBQ0UsSUFBQWQsV0FBQSxDQUFBZSxJQUFBLEVBQUNsQixRQUFBLENBQUFtQixlQUFlLENBQUNDLFFBQVE7SUFBQ0MsS0FBSyxFQUFFTCxFQUFHO0lBQUFNLFFBQUEsZ0JBQ2xDLElBQUFuQixXQUFBLENBQUFvQixHQUFBO01BQVFDLE9BQU8sRUFBRUEsQ0FBQSxLQUFNUixFQUFFLENBQUNTLFNBQVMsQ0FBQyxTQUFTLENBQUU7TUFBQUgsUUFBQSxFQUFDO0lBQVksQ0FBUSxDQUFDLGVBQ3JFLElBQUFuQixXQUFBLENBQUFvQixHQUFBLEVBQUN0QixhQUFBLENBQUFPLE9BQVksSUFBRSxDQUFDO0VBQUEsQ0FDUSxDQUFDO0FBRS9CO0FBQUNKLEVBQUEsQ0FSUVcsT0FBTztFQUFBLFFBQ0hFLHdCQUFXO0FBQUE7QUFBQVMsRUFBQSxHQURmWCxPQUFPO0FBVWhCLElBQUFZLGdCQUFRLEVBQUMsZ0NBQWdDLEVBQUUsTUFBTTtFQUMvQyxJQUFBQyxVQUFFLEVBQUMsMkRBQTJELEVBQUUsTUFBTTtJQUNwRSxJQUFBQyxhQUFNLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQW9CLEdBQUEsRUFBQ1IsT0FBTyxJQUFFLENBQUMsQ0FBQztJQUNuQixNQUFNZSxNQUFNLEdBQUdDLGFBQU0sQ0FBQ0MsU0FBUyxDQUFDLFFBQVEsRUFBRTtNQUFFQyxJQUFJLEVBQUU7SUFBZSxDQUFDLENBQUM7SUFDbkVILE1BQU0sQ0FBQ0ksS0FBSyxDQUFDLENBQUM7SUFDZEMsZ0JBQVMsQ0FBQ0MsS0FBSyxDQUFDTixNQUFNLENBQUM7SUFDdkI7SUFDQSxJQUFBTyxjQUFNLEVBQUNOLGFBQU0sQ0FBQ08sU0FBUyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUNDLGlCQUFpQixDQUFDLENBQUM7SUFDN0RKLGdCQUFTLENBQUNLLE9BQU8sQ0FBQ0MsUUFBUSxFQUFFO01BQUVDLEdBQUcsRUFBRTtJQUFTLENBQUMsQ0FBQztJQUM5QyxJQUFBTCxjQUFNLEVBQUNOLGFBQU0sQ0FBQ1ksV0FBVyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUNDLEdBQUcsQ0FBQ0wsaUJBQWlCLENBQUMsQ0FBQztJQUNuRSxJQUFBRixjQUFNLEVBQUNJLFFBQVEsQ0FBQ0ksYUFBYSxDQUFDLENBQUNDLElBQUksQ0FBQ2hCLE1BQU0sQ0FBQztFQUM3QyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7QUFBQyxJQUFBSixFQUFBO0FBQUFxQixZQUFBLENBQUFyQixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}