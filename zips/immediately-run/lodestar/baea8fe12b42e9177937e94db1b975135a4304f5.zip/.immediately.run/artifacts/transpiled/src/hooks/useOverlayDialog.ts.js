"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useOverlayDialog = useOverlayDialog;
var _react = require("react");
// The dialog contract for the app's hand-rolled overlays (R3-607, R-IX-1):
// focus moves IN on open, Tab is TRAPPED inside, Escape closes, and focus
// RETURNS to the element that opened the dialog. One local spelling for every
// overlay until the SDK ships a host primitive — when it does, this hook's body
// swaps, not its callers.
//
// Region apps have no shared dialog primitive yet (the 2026-09-11 audit's HOST
// gap); one local spelling beats four.

/** Elements that can hold focus inside the overlay. */
const FOCUSABLE = 'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])';

/** Which arm is the freshest (R4): two overlays can be open at once (a quick
 *  menu over a state screen). Each arm takes a number; only the newest one
 *  acts on Escape — one key closes one dialog, never a nested pair at once —
 *  and its cleanup owns the focus return. */
let armedSeq = 0;

/**
 * Wire the dialog contract to an overlay root. Attach the returned ref to the
 * element that bounds the dialog (the panel, not the backdrop — Tab should be
 * trapped by the panel's own controls).
 *
 * @param open   the overlay's open state — the effect arms on true and cleans
 *               up (returning focus) on false/unmount.
 * @param onClose Escape's meaning: close without committing.
 */
function useOverlayDialog(open, onClose) {
  const rootRef = (0, _react.useRef)(null);
  const onCloseRef = (0, _react.useRef)(onClose);
  onCloseRef.current = onClose;
  (0, _react.useEffect)(() => {
    if (!open) return;
    const token = ++armedSeq;
    // The trigger to return to: captured BEFORE focus moves in.
    const trigger = document.activeElement;
    const root = rootRef.current;
    const focusables = root ? [...root.querySelectorAll(FOCUSABLE)] : [];
    // Focus IN: the first control (the close affordance is usually first); a
    // panel with no focusable content takes focus itself so Escape has a home.
    (focusables[0] ?? root)?.focus();
    const onKeyDown = e => {
      // Only the freshest arm acts (see armedSeq): a stale arm that is still
      // unwinding its cleanup must not swallow this key or race the return.
      if (token !== armedSeq) return;
      if (e.key === 'Escape') {
        e.preventDefault();
        e.stopPropagation();
        onCloseRef.current();
        return;
      }
      if (e.key !== 'Tab' || !root) return;
      const list = [...root.querySelectorAll(FOCUSABLE)].filter(el => !el.hasAttribute('disabled'));
      if (!list.length) {
        e.preventDefault();
        return;
      }
      const first = list[0];
      const last = list[list.length - 1];
      const active = document.activeElement;
      if (!root.contains(active)) {
        // Focus escaped the trap somehow (a removed node): pull it back in.
        e.preventDefault();
        first.focus();
      } else if (e.shiftKey && active === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && active === last) {
        e.preventDefault();
        first.focus();
      }
    };
    // Capture phase: the contract runs before any app-level key handling.
    document.addEventListener('keydown', onKeyDown, true);
    return () => {
      document.removeEventListener('keydown', onKeyDown, true);
      // Focus RETURNS to the trigger (R-IX-1). Guarded: the trigger may be gone.
      if (trigger && document.contains(trigger)) trigger.focus();
    };
  }, [open]);
  return rootRef;
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiRk9DVVNBQkxFIiwiYXJtZWRTZXEiLCJ1c2VPdmVybGF5RGlhbG9nIiwib3BlbiIsIm9uQ2xvc2UiLCJyb290UmVmIiwidXNlUmVmIiwib25DbG9zZVJlZiIsImN1cnJlbnQiLCJ1c2VFZmZlY3QiLCJ0b2tlbiIsInRyaWdnZXIiLCJkb2N1bWVudCIsImFjdGl2ZUVsZW1lbnQiLCJyb290IiwiZm9jdXNhYmxlcyIsInF1ZXJ5U2VsZWN0b3JBbGwiLCJmb2N1cyIsIm9uS2V5RG93biIsImUiLCJrZXkiLCJwcmV2ZW50RGVmYXVsdCIsInN0b3BQcm9wYWdhdGlvbiIsImxpc3QiLCJmaWx0ZXIiLCJlbCIsImhhc0F0dHJpYnV0ZSIsImxlbmd0aCIsImZpcnN0IiwibGFzdCIsImFjdGl2ZSIsImNvbnRhaW5zIiwic2hpZnRLZXkiLCJhZGRFdmVudExpc3RlbmVyIiwicmVtb3ZlRXZlbnRMaXN0ZW5lciJdLCJzb3VyY2VzIjpbInVzZU92ZXJsYXlEaWFsb2cudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gVGhlIGRpYWxvZyBjb250cmFjdCBmb3IgdGhlIGFwcCdzIGhhbmQtcm9sbGVkIG92ZXJsYXlzIChSMy02MDcsIFItSVgtMSk6XG4vLyBmb2N1cyBtb3ZlcyBJTiBvbiBvcGVuLCBUYWIgaXMgVFJBUFBFRCBpbnNpZGUsIEVzY2FwZSBjbG9zZXMsIGFuZCBmb2N1c1xuLy8gUkVUVVJOUyB0byB0aGUgZWxlbWVudCB0aGF0IG9wZW5lZCB0aGUgZGlhbG9nLiBPbmUgbG9jYWwgc3BlbGxpbmcgZm9yIGV2ZXJ5XG4vLyBvdmVybGF5IHVudGlsIHRoZSBTREsgc2hpcHMgYSBob3N0IHByaW1pdGl2ZSDigJQgd2hlbiBpdCBkb2VzLCB0aGlzIGhvb2sncyBib2R5XG4vLyBzd2Fwcywgbm90IGl0cyBjYWxsZXJzLlxuLy9cbi8vIFJlZ2lvbiBhcHBzIGhhdmUgbm8gc2hhcmVkIGRpYWxvZyBwcmltaXRpdmUgeWV0ICh0aGUgMjAyNi0wOS0xMSBhdWRpdCdzIEhPU1Rcbi8vIGdhcCk7IG9uZSBsb2NhbCBzcGVsbGluZyBiZWF0cyBmb3VyLlxuXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVJlZiB9IGZyb20gJ3JlYWN0JztcblxuLyoqIEVsZW1lbnRzIHRoYXQgY2FuIGhvbGQgZm9jdXMgaW5zaWRlIHRoZSBvdmVybGF5LiAqL1xuY29uc3QgRk9DVVNBQkxFID1cbiAgJ2FbaHJlZl0sIGJ1dHRvbjpub3QoW2Rpc2FibGVkXSksIGlucHV0Om5vdChbZGlzYWJsZWRdKSwgc2VsZWN0Om5vdChbZGlzYWJsZWRdKSwgdGV4dGFyZWE6bm90KFtkaXNhYmxlZF0pLCBbdGFiaW5kZXhdOm5vdChbdGFiaW5kZXg9XCItMVwiXSknO1xuXG4vKiogV2hpY2ggYXJtIGlzIHRoZSBmcmVzaGVzdCAoUjQpOiB0d28gb3ZlcmxheXMgY2FuIGJlIG9wZW4gYXQgb25jZSAoYSBxdWlja1xuICogIG1lbnUgb3ZlciBhIHN0YXRlIHNjcmVlbikuIEVhY2ggYXJtIHRha2VzIGEgbnVtYmVyOyBvbmx5IHRoZSBuZXdlc3Qgb25lXG4gKiAgYWN0cyBvbiBFc2NhcGUg4oCUIG9uZSBrZXkgY2xvc2VzIG9uZSBkaWFsb2csIG5ldmVyIGEgbmVzdGVkIHBhaXIgYXQgb25jZSDigJRcbiAqICBhbmQgaXRzIGNsZWFudXAgb3ducyB0aGUgZm9jdXMgcmV0dXJuLiAqL1xubGV0IGFybWVkU2VxID0gMDtcblxuLyoqXG4gKiBXaXJlIHRoZSBkaWFsb2cgY29udHJhY3QgdG8gYW4gb3ZlcmxheSByb290LiBBdHRhY2ggdGhlIHJldHVybmVkIHJlZiB0byB0aGVcbiAqIGVsZW1lbnQgdGhhdCBib3VuZHMgdGhlIGRpYWxvZyAodGhlIHBhbmVsLCBub3QgdGhlIGJhY2tkcm9wIOKAlCBUYWIgc2hvdWxkIGJlXG4gKiB0cmFwcGVkIGJ5IHRoZSBwYW5lbCdzIG93biBjb250cm9scykuXG4gKlxuICogQHBhcmFtIG9wZW4gICB0aGUgb3ZlcmxheSdzIG9wZW4gc3RhdGUg4oCUIHRoZSBlZmZlY3QgYXJtcyBvbiB0cnVlIGFuZCBjbGVhbnNcbiAqICAgICAgICAgICAgICAgdXAgKHJldHVybmluZyBmb2N1cykgb24gZmFsc2UvdW5tb3VudC5cbiAqIEBwYXJhbSBvbkNsb3NlIEVzY2FwZSdzIG1lYW5pbmc6IGNsb3NlIHdpdGhvdXQgY29tbWl0dGluZy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVzZU92ZXJsYXlEaWFsb2cob3BlbjogYm9vbGVhbiwgb25DbG9zZTogKCkgPT4gdm9pZCkge1xuICBjb25zdCByb290UmVmID0gdXNlUmVmPEhUTUxEaXZFbGVtZW50IHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IG9uQ2xvc2VSZWYgPSB1c2VSZWYob25DbG9zZSk7XG4gIG9uQ2xvc2VSZWYuY3VycmVudCA9IG9uQ2xvc2U7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIW9wZW4pIHJldHVybjtcbiAgICBjb25zdCB0b2tlbiA9ICsrYXJtZWRTZXE7XG4gICAgLy8gVGhlIHRyaWdnZXIgdG8gcmV0dXJuIHRvOiBjYXB0dXJlZCBCRUZPUkUgZm9jdXMgbW92ZXMgaW4uXG4gICAgY29uc3QgdHJpZ2dlciA9IGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQgYXMgSFRNTEVsZW1lbnQgfCBudWxsO1xuICAgIGNvbnN0IHJvb3QgPSByb290UmVmLmN1cnJlbnQ7XG4gICAgY29uc3QgZm9jdXNhYmxlcyA9IHJvb3QgPyBbLi4ucm9vdC5xdWVyeVNlbGVjdG9yQWxsPEhUTUxFbGVtZW50PihGT0NVU0FCTEUpXSA6IFtdO1xuICAgIC8vIEZvY3VzIElOOiB0aGUgZmlyc3QgY29udHJvbCAodGhlIGNsb3NlIGFmZm9yZGFuY2UgaXMgdXN1YWxseSBmaXJzdCk7IGFcbiAgICAvLyBwYW5lbCB3aXRoIG5vIGZvY3VzYWJsZSBjb250ZW50IHRha2VzIGZvY3VzIGl0c2VsZiBzbyBFc2NhcGUgaGFzIGEgaG9tZS5cbiAgICAoZm9jdXNhYmxlc1swXSA/PyByb290KT8uZm9jdXMoKTtcblxuICAgIGNvbnN0IG9uS2V5RG93biA9IChlOiBLZXlib2FyZEV2ZW50KSA9PiB7XG4gICAgICAvLyBPbmx5IHRoZSBmcmVzaGVzdCBhcm0gYWN0cyAoc2VlIGFybWVkU2VxKTogYSBzdGFsZSBhcm0gdGhhdCBpcyBzdGlsbFxuICAgICAgLy8gdW53aW5kaW5nIGl0cyBjbGVhbnVwIG11c3Qgbm90IHN3YWxsb3cgdGhpcyBrZXkgb3IgcmFjZSB0aGUgcmV0dXJuLlxuICAgICAgaWYgKHRva2VuICE9PSBhcm1lZFNlcSkgcmV0dXJuO1xuICAgICAgaWYgKGUua2V5ID09PSAnRXNjYXBlJykge1xuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICAgIG9uQ2xvc2VSZWYuY3VycmVudCgpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAoZS5rZXkgIT09ICdUYWInIHx8ICFyb290KSByZXR1cm47XG4gICAgICBjb25zdCBsaXN0ID0gWy4uLnJvb3QucXVlcnlTZWxlY3RvckFsbDxIVE1MRWxlbWVudD4oRk9DVVNBQkxFKV0uZmlsdGVyKChlbCkgPT4gIWVsLmhhc0F0dHJpYnV0ZSgnZGlzYWJsZWQnKSk7XG4gICAgICBpZiAoIWxpc3QubGVuZ3RoKSB7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgY29uc3QgZmlyc3QgPSBsaXN0WzBdO1xuICAgICAgY29uc3QgbGFzdCA9IGxpc3RbbGlzdC5sZW5ndGggLSAxXTtcbiAgICAgIGNvbnN0IGFjdGl2ZSA9IGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQ7XG4gICAgICBpZiAoIXJvb3QuY29udGFpbnMoYWN0aXZlKSkge1xuICAgICAgICAvLyBGb2N1cyBlc2NhcGVkIHRoZSB0cmFwIHNvbWVob3cgKGEgcmVtb3ZlZCBub2RlKTogcHVsbCBpdCBiYWNrIGluLlxuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIGZpcnN0LmZvY3VzKCk7XG4gICAgICB9IGVsc2UgaWYgKGUuc2hpZnRLZXkgJiYgYWN0aXZlID09PSBmaXJzdCkge1xuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIGxhc3QuZm9jdXMoKTtcbiAgICAgIH0gZWxzZSBpZiAoIWUuc2hpZnRLZXkgJiYgYWN0aXZlID09PSBsYXN0KSB7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgZmlyc3QuZm9jdXMoKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIC8vIENhcHR1cmUgcGhhc2U6IHRoZSBjb250cmFjdCBydW5zIGJlZm9yZSBhbnkgYXBwLWxldmVsIGtleSBoYW5kbGluZy5cbiAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdrZXlkb3duJywgb25LZXlEb3duLCB0cnVlKTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcigna2V5ZG93bicsIG9uS2V5RG93biwgdHJ1ZSk7XG4gICAgICAvLyBGb2N1cyBSRVRVUk5TIHRvIHRoZSB0cmlnZ2VyIChSLUlYLTEpLiBHdWFyZGVkOiB0aGUgdHJpZ2dlciBtYXkgYmUgZ29uZS5cbiAgICAgIGlmICh0cmlnZ2VyICYmIGRvY3VtZW50LmNvbnRhaW5zKHRyaWdnZXIpKSB0cmlnZ2VyLmZvY3VzKCk7XG4gICAgfTtcbiAgfSwgW29wZW5dKTtcblxuICByZXR1cm4gcm9vdFJlZjtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBU0EsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBVEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFJQTtBQUNBLE1BQU1DLFNBQVMsR0FDYiwySUFBMkk7O0FBRTdJO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSUMsUUFBUSxHQUFHLENBQUM7O0FBRWhCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVNDLGdCQUFnQkEsQ0FBQ0MsSUFBYSxFQUFFQyxPQUFtQixFQUFFO0VBQ25FLE1BQU1DLE9BQU8sR0FBRyxJQUFBQyxhQUFNLEVBQXdCLElBQUksQ0FBQztFQUNuRCxNQUFNQyxVQUFVLEdBQUcsSUFBQUQsYUFBTSxFQUFDRixPQUFPLENBQUM7RUFDbENHLFVBQVUsQ0FBQ0MsT0FBTyxHQUFHSixPQUFPO0VBRTVCLElBQUFLLGdCQUFTLEVBQUMsTUFBTTtJQUNkLElBQUksQ0FBQ04sSUFBSSxFQUFFO0lBQ1gsTUFBTU8sS0FBSyxHQUFHLEVBQUVULFFBQVE7SUFDeEI7SUFDQSxNQUFNVSxPQUFPLEdBQUdDLFFBQVEsQ0FBQ0MsYUFBbUM7SUFDNUQsTUFBTUMsSUFBSSxHQUFHVCxPQUFPLENBQUNHLE9BQU87SUFDNUIsTUFBTU8sVUFBVSxHQUFHRCxJQUFJLEdBQUcsQ0FBQyxHQUFHQSxJQUFJLENBQUNFLGdCQUFnQixDQUFjaEIsU0FBUyxDQUFDLENBQUMsR0FBRyxFQUFFO0lBQ2pGO0lBQ0E7SUFDQSxDQUFDZSxVQUFVLENBQUMsQ0FBQyxDQUFDLElBQUlELElBQUksR0FBR0csS0FBSyxDQUFDLENBQUM7SUFFaEMsTUFBTUMsU0FBUyxHQUFJQyxDQUFnQixJQUFLO01BQ3RDO01BQ0E7TUFDQSxJQUFJVCxLQUFLLEtBQUtULFFBQVEsRUFBRTtNQUN4QixJQUFJa0IsQ0FBQyxDQUFDQyxHQUFHLEtBQUssUUFBUSxFQUFFO1FBQ3RCRCxDQUFDLENBQUNFLGNBQWMsQ0FBQyxDQUFDO1FBQ2xCRixDQUFDLENBQUNHLGVBQWUsQ0FBQyxDQUFDO1FBQ25CZixVQUFVLENBQUNDLE9BQU8sQ0FBQyxDQUFDO1FBQ3BCO01BQ0Y7TUFDQSxJQUFJVyxDQUFDLENBQUNDLEdBQUcsS0FBSyxLQUFLLElBQUksQ0FBQ04sSUFBSSxFQUFFO01BQzlCLE1BQU1TLElBQUksR0FBRyxDQUFDLEdBQUdULElBQUksQ0FBQ0UsZ0JBQWdCLENBQWNoQixTQUFTLENBQUMsQ0FBQyxDQUFDd0IsTUFBTSxDQUFFQyxFQUFFLElBQUssQ0FBQ0EsRUFBRSxDQUFDQyxZQUFZLENBQUMsVUFBVSxDQUFDLENBQUM7TUFDNUcsSUFBSSxDQUFDSCxJQUFJLENBQUNJLE1BQU0sRUFBRTtRQUNoQlIsQ0FBQyxDQUFDRSxjQUFjLENBQUMsQ0FBQztRQUNsQjtNQUNGO01BQ0EsTUFBTU8sS0FBSyxHQUFHTCxJQUFJLENBQUMsQ0FBQyxDQUFDO01BQ3JCLE1BQU1NLElBQUksR0FBR04sSUFBSSxDQUFDQSxJQUFJLENBQUNJLE1BQU0sR0FBRyxDQUFDLENBQUM7TUFDbEMsTUFBTUcsTUFBTSxHQUFHbEIsUUFBUSxDQUFDQyxhQUFhO01BQ3JDLElBQUksQ0FBQ0MsSUFBSSxDQUFDaUIsUUFBUSxDQUFDRCxNQUFNLENBQUMsRUFBRTtRQUMxQjtRQUNBWCxDQUFDLENBQUNFLGNBQWMsQ0FBQyxDQUFDO1FBQ2xCTyxLQUFLLENBQUNYLEtBQUssQ0FBQyxDQUFDO01BQ2YsQ0FBQyxNQUFNLElBQUlFLENBQUMsQ0FBQ2EsUUFBUSxJQUFJRixNQUFNLEtBQUtGLEtBQUssRUFBRTtRQUN6Q1QsQ0FBQyxDQUFDRSxjQUFjLENBQUMsQ0FBQztRQUNsQlEsSUFBSSxDQUFDWixLQUFLLENBQUMsQ0FBQztNQUNkLENBQUMsTUFBTSxJQUFJLENBQUNFLENBQUMsQ0FBQ2EsUUFBUSxJQUFJRixNQUFNLEtBQUtELElBQUksRUFBRTtRQUN6Q1YsQ0FBQyxDQUFDRSxjQUFjLENBQUMsQ0FBQztRQUNsQk8sS0FBSyxDQUFDWCxLQUFLLENBQUMsQ0FBQztNQUNmO0lBQ0YsQ0FBQztJQUNEO0lBQ0FMLFFBQVEsQ0FBQ3FCLGdCQUFnQixDQUFDLFNBQVMsRUFBRWYsU0FBUyxFQUFFLElBQUksQ0FBQztJQUNyRCxPQUFPLE1BQU07TUFDWE4sUUFBUSxDQUFDc0IsbUJBQW1CLENBQUMsU0FBUyxFQUFFaEIsU0FBUyxFQUFFLElBQUksQ0FBQztNQUN4RDtNQUNBLElBQUlQLE9BQU8sSUFBSUMsUUFBUSxDQUFDbUIsUUFBUSxDQUFDcEIsT0FBTyxDQUFDLEVBQUVBLE9BQU8sQ0FBQ00sS0FBSyxDQUFDLENBQUM7SUFDNUQsQ0FBQztFQUNILENBQUMsRUFBRSxDQUFDZCxJQUFJLENBQUMsQ0FBQztFQUVWLE9BQU9FLE9BQU87QUFDaEIiLCJpZ25vcmVMaXN0IjpbXX0=