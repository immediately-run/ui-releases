var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

var _react = require("react");
var _vitest = require("vitest");
var _react2 = require("@testing-library/react");
var _useOverlayDialog = require("./useOverlayDialog");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // @vitest-environment jsdom
// useOverlayDialog (R3-607): the dialog contract with a REAL trigger — focus
// in on open, Tab trapped at the panel's edges, Escape closing, and focus
// returned to the element that opened the dialog.
function Harness() {
  _s();
  const [open, setOpen] = (0, _react.useState)(false);
  const dialogRef = (0, _useOverlayDialog.useOverlayDialog)(open, () => setOpen(false));
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
      onClick: () => setOpen(true),
      children: "Open dialog"
    }), open ? /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      ref: dialogRef,
      tabIndex: -1,
      "data-testid": "panel",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        children: "First"
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        children: "Last"
      })]
    }) : null]
  });
}
_s(Harness, "XDMzf6XT94cZf+G1VHw1nSrYMH0=", false, function () {
  return [_useOverlayDialog.useOverlayDialog];
});
_c = Harness;
(0, _vitest.describe)('useOverlayDialog (R3-607)', () => {
  (0, _vitest.it)('moves focus IN to the first control when the dialog opens', () => {
    (0, _react2.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(Harness, {}));
    _react2.fireEvent.click(_react2.screen.getByRole('button', {
      name: 'Open dialog'
    }));
    (0, _vitest.expect)(document.activeElement).toBe(_react2.screen.getByRole('button', {
      name: 'First'
    }));
  });
  (0, _vitest.it)('traps Tab at the panel edges — forward from last wraps to first', () => {
    (0, _react2.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(Harness, {}));
    _react2.fireEvent.click(_react2.screen.getByRole('button', {
      name: 'Open dialog'
    }));
    const last = _react2.screen.getByRole('button', {
      name: 'Last'
    });
    last.focus();
    _react2.fireEvent.keyDown(document, {
      key: 'Tab'
    });
    (0, _vitest.expect)(document.activeElement).toBe(_react2.screen.getByRole('button', {
      name: 'First'
    }));
  });
  (0, _vitest.it)('traps Shift+Tab at the panel edges — backward from first wraps to last', () => {
    (0, _react2.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(Harness, {}));
    _react2.fireEvent.click(_react2.screen.getByRole('button', {
      name: 'Open dialog'
    }));
    // focus-in put us on First already.
    _react2.fireEvent.keyDown(document, {
      key: 'Tab',
      shiftKey: true
    });
    (0, _vitest.expect)(document.activeElement).toBe(_react2.screen.getByRole('button', {
      name: 'Last'
    }));
  });
  (0, _vitest.it)('Escape closes, and focus RETURNS to the trigger', () => {
    (0, _react2.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(Harness, {}));
    const trigger = _react2.screen.getByRole('button', {
      name: 'Open dialog'
    });
    trigger.focus();
    _react2.fireEvent.click(trigger);
    (0, _vitest.expect)(_react2.screen.getByTestId('panel')).toBeInTheDocument();
    _react2.fireEvent.keyDown(document, {
      key: 'Escape'
    });
    (0, _vitest.expect)(_react2.screen.queryByTestId('panel')).not.toBeInTheDocument();
    (0, _vitest.expect)(document.activeElement).toBe(trigger);
  });
  (0, _vitest.it)('never arms while closed — keys pass through untouched', () => {
    const spy = _vitest.vi.fn();
    (0, _react2.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      onKeyDown: spy,
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(Harness, {})
    }));
    // Dispatched on an element inside the React root (React 17+ delegates at
    // the root container, so a bare document dispatch would never reach it).
    _react2.fireEvent.keyDown(_react2.screen.getByRole('button', {
      name: 'Open dialog'
    }), {
      key: 'Escape'
    });
    (0, _vitest.expect)(spy).toHaveBeenCalled();
    (0, _vitest.expect)(_react2.screen.queryByTestId('panel')).not.toBeInTheDocument();
  });
});
var _c;
$RefreshReg$(_c, "Harness");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3ZpdGVzdCIsIl9yZWFjdDIiLCJfdXNlT3ZlcmxheURpYWxvZyIsIl9qc3hSdW50aW1lIiwiX3MiLCIkUmVmcmVzaFNpZyQiLCJIYXJuZXNzIiwib3BlbiIsInNldE9wZW4iLCJ1c2VTdGF0ZSIsImRpYWxvZ1JlZiIsInVzZU92ZXJsYXlEaWFsb2ciLCJqc3hzIiwiY2hpbGRyZW4iLCJqc3giLCJvbkNsaWNrIiwicmVmIiwidGFiSW5kZXgiLCJfYyIsImRlc2NyaWJlIiwiaXQiLCJyZW5kZXIiLCJmaXJlRXZlbnQiLCJjbGljayIsInNjcmVlbiIsImdldEJ5Um9sZSIsIm5hbWUiLCJleHBlY3QiLCJkb2N1bWVudCIsImFjdGl2ZUVsZW1lbnQiLCJ0b0JlIiwibGFzdCIsImZvY3VzIiwia2V5RG93biIsImtleSIsInNoaWZ0S2V5IiwidHJpZ2dlciIsImdldEJ5VGVzdElkIiwidG9CZUluVGhlRG9jdW1lbnQiLCJxdWVyeUJ5VGVzdElkIiwibm90Iiwic3B5IiwidmkiLCJmbiIsIm9uS2V5RG93biIsInRvSGF2ZUJlZW5DYWxsZWQiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJ1c2VPdmVybGF5RGlhbG9nLnRlc3QudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIEB2aXRlc3QtZW52aXJvbm1lbnQganNkb21cbi8vIHVzZU92ZXJsYXlEaWFsb2cgKFIzLTYwNyk6IHRoZSBkaWFsb2cgY29udHJhY3Qgd2l0aCBhIFJFQUwgdHJpZ2dlciDigJQgZm9jdXNcbi8vIGluIG9uIG9wZW4sIFRhYiB0cmFwcGVkIGF0IHRoZSBwYW5lbCdzIGVkZ2VzLCBFc2NhcGUgY2xvc2luZywgYW5kIGZvY3VzXG4vLyByZXR1cm5lZCB0byB0aGUgZWxlbWVudCB0aGF0IG9wZW5lZCB0aGUgZGlhbG9nLlxuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBkZXNjcmliZSwgZXhwZWN0LCBpdCwgdmkgfSBmcm9tICd2aXRlc3QnO1xuaW1wb3J0IHsgZmlyZUV2ZW50LCByZW5kZXIsIHNjcmVlbiB9IGZyb20gJ0B0ZXN0aW5nLWxpYnJhcnkvcmVhY3QnO1xuaW1wb3J0IHsgdXNlT3ZlcmxheURpYWxvZyB9IGZyb20gJy4vdXNlT3ZlcmxheURpYWxvZyc7XG5cbmZ1bmN0aW9uIEhhcm5lc3MoKSB7XG4gIGNvbnN0IFtvcGVuLCBzZXRPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgZGlhbG9nUmVmID0gdXNlT3ZlcmxheURpYWxvZyhvcGVuLCAoKSA9PiBzZXRPcGVuKGZhbHNlKSk7XG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0T3Blbih0cnVlKX0+T3BlbiBkaWFsb2c8L2J1dHRvbj5cbiAgICAgIHtvcGVuID8gKFxuICAgICAgICA8ZGl2IHJlZj17ZGlhbG9nUmVmfSB0YWJJbmRleD17LTF9IGRhdGEtdGVzdGlkPVwicGFuZWxcIj5cbiAgICAgICAgICA8YnV0dG9uPkZpcnN0PC9idXR0b24+XG4gICAgICAgICAgPGJ1dHRvbj5MYXN0PC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKSA6IG51bGx9XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbmRlc2NyaWJlKCd1c2VPdmVybGF5RGlhbG9nIChSMy02MDcpJywgKCkgPT4ge1xuICBpdCgnbW92ZXMgZm9jdXMgSU4gdG8gdGhlIGZpcnN0IGNvbnRyb2wgd2hlbiB0aGUgZGlhbG9nIG9wZW5zJywgKCkgPT4ge1xuICAgIHJlbmRlcig8SGFybmVzcyAvPik7XG4gICAgZmlyZUV2ZW50LmNsaWNrKHNjcmVlbi5nZXRCeVJvbGUoJ2J1dHRvbicsIHsgbmFtZTogJ09wZW4gZGlhbG9nJyB9KSk7XG4gICAgZXhwZWN0KGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQpLnRvQmUoc2NyZWVuLmdldEJ5Um9sZSgnYnV0dG9uJywgeyBuYW1lOiAnRmlyc3QnIH0pKTtcbiAgfSk7XG5cbiAgaXQoJ3RyYXBzIFRhYiBhdCB0aGUgcGFuZWwgZWRnZXMg4oCUIGZvcndhcmQgZnJvbSBsYXN0IHdyYXBzIHRvIGZpcnN0JywgKCkgPT4ge1xuICAgIHJlbmRlcig8SGFybmVzcyAvPik7XG4gICAgZmlyZUV2ZW50LmNsaWNrKHNjcmVlbi5nZXRCeVJvbGUoJ2J1dHRvbicsIHsgbmFtZTogJ09wZW4gZGlhbG9nJyB9KSk7XG4gICAgY29uc3QgbGFzdCA9IHNjcmVlbi5nZXRCeVJvbGUoJ2J1dHRvbicsIHsgbmFtZTogJ0xhc3QnIH0pO1xuICAgIGxhc3QuZm9jdXMoKTtcbiAgICBmaXJlRXZlbnQua2V5RG93bihkb2N1bWVudCwgeyBrZXk6ICdUYWInIH0pO1xuICAgIGV4cGVjdChkb2N1bWVudC5hY3RpdmVFbGVtZW50KS50b0JlKHNjcmVlbi5nZXRCeVJvbGUoJ2J1dHRvbicsIHsgbmFtZTogJ0ZpcnN0JyB9KSk7XG4gIH0pO1xuXG4gIGl0KCd0cmFwcyBTaGlmdCtUYWIgYXQgdGhlIHBhbmVsIGVkZ2VzIOKAlCBiYWNrd2FyZCBmcm9tIGZpcnN0IHdyYXBzIHRvIGxhc3QnLCAoKSA9PiB7XG4gICAgcmVuZGVyKDxIYXJuZXNzIC8+KTtcbiAgICBmaXJlRXZlbnQuY2xpY2soc2NyZWVuLmdldEJ5Um9sZSgnYnV0dG9uJywgeyBuYW1lOiAnT3BlbiBkaWFsb2cnIH0pKTtcbiAgICAvLyBmb2N1cy1pbiBwdXQgdXMgb24gRmlyc3QgYWxyZWFkeS5cbiAgICBmaXJlRXZlbnQua2V5RG93bihkb2N1bWVudCwgeyBrZXk6ICdUYWInLCBzaGlmdEtleTogdHJ1ZSB9KTtcbiAgICBleHBlY3QoZG9jdW1lbnQuYWN0aXZlRWxlbWVudCkudG9CZShzY3JlZW4uZ2V0QnlSb2xlKCdidXR0b24nLCB7IG5hbWU6ICdMYXN0JyB9KSk7XG4gIH0pO1xuXG4gIGl0KCdFc2NhcGUgY2xvc2VzLCBhbmQgZm9jdXMgUkVUVVJOUyB0byB0aGUgdHJpZ2dlcicsICgpID0+IHtcbiAgICByZW5kZXIoPEhhcm5lc3MgLz4pO1xuICAgIGNvbnN0IHRyaWdnZXIgPSBzY3JlZW4uZ2V0QnlSb2xlKCdidXR0b24nLCB7IG5hbWU6ICdPcGVuIGRpYWxvZycgfSk7XG4gICAgdHJpZ2dlci5mb2N1cygpO1xuICAgIGZpcmVFdmVudC5jbGljayh0cmlnZ2VyKTtcbiAgICBleHBlY3Qoc2NyZWVuLmdldEJ5VGVzdElkKCdwYW5lbCcpKS50b0JlSW5UaGVEb2N1bWVudCgpO1xuICAgIGZpcmVFdmVudC5rZXlEb3duKGRvY3VtZW50LCB7IGtleTogJ0VzY2FwZScgfSk7XG4gICAgZXhwZWN0KHNjcmVlbi5xdWVyeUJ5VGVzdElkKCdwYW5lbCcpKS5ub3QudG9CZUluVGhlRG9jdW1lbnQoKTtcbiAgICBleHBlY3QoZG9jdW1lbnQuYWN0aXZlRWxlbWVudCkudG9CZSh0cmlnZ2VyKTtcbiAgfSk7XG5cbiAgaXQoJ25ldmVyIGFybXMgd2hpbGUgY2xvc2VkIOKAlCBrZXlzIHBhc3MgdGhyb3VnaCB1bnRvdWNoZWQnLCAoKSA9PiB7XG4gICAgY29uc3Qgc3B5ID0gdmkuZm4oKTtcbiAgICByZW5kZXIoXG4gICAgICA8ZGl2IG9uS2V5RG93bj17c3B5fT5cbiAgICAgICAgPEhhcm5lc3MgLz5cbiAgICAgIDwvZGl2PixcbiAgICApO1xuICAgIC8vIERpc3BhdGNoZWQgb24gYW4gZWxlbWVudCBpbnNpZGUgdGhlIFJlYWN0IHJvb3QgKFJlYWN0IDE3KyBkZWxlZ2F0ZXMgYXRcbiAgICAvLyB0aGUgcm9vdCBjb250YWluZXIsIHNvIGEgYmFyZSBkb2N1bWVudCBkaXNwYXRjaCB3b3VsZCBuZXZlciByZWFjaCBpdCkuXG4gICAgZmlyZUV2ZW50LmtleURvd24oc2NyZWVuLmdldEJ5Um9sZSgnYnV0dG9uJywgeyBuYW1lOiAnT3BlbiBkaWFsb2cnIH0pLCB7IGtleTogJ0VzY2FwZScgfSk7XG4gICAgZXhwZWN0KHNweSkudG9IYXZlQmVlbkNhbGxlZCgpO1xuICAgIGV4cGVjdChzY3JlZW4ucXVlcnlCeVRlc3RJZCgncGFuZWwnKSkubm90LnRvQmVJblRoZURvY3VtZW50KCk7XG4gIH0pO1xufSk7XG4iXSwibWFwcGluZ3MiOiI7O0FBSUEsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsT0FBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsT0FBQSxHQUFBRixPQUFBO0FBQ0EsSUFBQUcsaUJBQUEsR0FBQUgsT0FBQTtBQUFzRCxJQUFBSSxXQUFBLEdBQUFKLE9BQUE7QUFBQSxJQUFBSyxFQUFBLEdBQUFDLFlBQUEsSUFQdEQ7QUFDQTtBQUNBO0FBQ0E7QUFNQSxTQUFTQyxPQUFPQSxDQUFBLEVBQUc7RUFBQUYsRUFBQTtFQUNqQixNQUFNLENBQUNHLElBQUksRUFBRUMsT0FBTyxDQUFDLEdBQUcsSUFBQUMsZUFBUSxFQUFDLEtBQUssQ0FBQztFQUN2QyxNQUFNQyxTQUFTLEdBQUcsSUFBQUMsa0NBQWdCLEVBQUNKLElBQUksRUFBRSxNQUFNQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7RUFDOUQsb0JBQ0UsSUFBQUwsV0FBQSxDQUFBUyxJQUFBO0lBQUFDLFFBQUEsZ0JBQ0UsSUFBQVYsV0FBQSxDQUFBVyxHQUFBO01BQVFDLE9BQU8sRUFBRUEsQ0FBQSxLQUFNUCxPQUFPLENBQUMsSUFBSSxDQUFFO01BQUFLLFFBQUEsRUFBQztJQUFXLENBQVEsQ0FBQyxFQUN6RE4sSUFBSSxnQkFDSCxJQUFBSixXQUFBLENBQUFTLElBQUE7TUFBS0ksR0FBRyxFQUFFTixTQUFVO01BQUNPLFFBQVEsRUFBRSxDQUFDLENBQUU7TUFBQyxlQUFZLE9BQU87TUFBQUosUUFBQSxnQkFDcEQsSUFBQVYsV0FBQSxDQUFBVyxHQUFBO1FBQUFELFFBQUEsRUFBUTtNQUFLLENBQVEsQ0FBQyxlQUN0QixJQUFBVixXQUFBLENBQUFXLEdBQUE7UUFBQUQsUUFBQSxFQUFRO01BQUksQ0FBUSxDQUFDO0lBQUEsQ0FDbEIsQ0FBQyxHQUNKLElBQUk7RUFBQSxDQUNMLENBQUM7QUFFVjtBQUFDVCxFQUFBLENBZFFFLE9BQU87RUFBQSxRQUVJSyxrQ0FBZ0I7QUFBQTtBQUFBTyxFQUFBLEdBRjNCWixPQUFPO0FBZ0JoQixJQUFBYSxnQkFBUSxFQUFDLDJCQUEyQixFQUFFLE1BQU07RUFDMUMsSUFBQUMsVUFBRSxFQUFDLDJEQUEyRCxFQUFFLE1BQU07SUFDcEUsSUFBQUMsY0FBTSxlQUFDLElBQUFsQixXQUFBLENBQUFXLEdBQUEsRUFBQ1IsT0FBTyxJQUFFLENBQUMsQ0FBQztJQUNuQmdCLGlCQUFTLENBQUNDLEtBQUssQ0FBQ0MsY0FBTSxDQUFDQyxTQUFTLENBQUMsUUFBUSxFQUFFO01BQUVDLElBQUksRUFBRTtJQUFjLENBQUMsQ0FBQyxDQUFDO0lBQ3BFLElBQUFDLGNBQU0sRUFBQ0MsUUFBUSxDQUFDQyxhQUFhLENBQUMsQ0FBQ0MsSUFBSSxDQUFDTixjQUFNLENBQUNDLFNBQVMsQ0FBQyxRQUFRLEVBQUU7TUFBRUMsSUFBSSxFQUFFO0lBQVEsQ0FBQyxDQUFDLENBQUM7RUFDcEYsQ0FBQyxDQUFDO0VBRUYsSUFBQU4sVUFBRSxFQUFDLGlFQUFpRSxFQUFFLE1BQU07SUFDMUUsSUFBQUMsY0FBTSxlQUFDLElBQUFsQixXQUFBLENBQUFXLEdBQUEsRUFBQ1IsT0FBTyxJQUFFLENBQUMsQ0FBQztJQUNuQmdCLGlCQUFTLENBQUNDLEtBQUssQ0FBQ0MsY0FBTSxDQUFDQyxTQUFTLENBQUMsUUFBUSxFQUFFO01BQUVDLElBQUksRUFBRTtJQUFjLENBQUMsQ0FBQyxDQUFDO0lBQ3BFLE1BQU1LLElBQUksR0FBR1AsY0FBTSxDQUFDQyxTQUFTLENBQUMsUUFBUSxFQUFFO01BQUVDLElBQUksRUFBRTtJQUFPLENBQUMsQ0FBQztJQUN6REssSUFBSSxDQUFDQyxLQUFLLENBQUMsQ0FBQztJQUNaVixpQkFBUyxDQUFDVyxPQUFPLENBQUNMLFFBQVEsRUFBRTtNQUFFTSxHQUFHLEVBQUU7SUFBTSxDQUFDLENBQUM7SUFDM0MsSUFBQVAsY0FBTSxFQUFDQyxRQUFRLENBQUNDLGFBQWEsQ0FBQyxDQUFDQyxJQUFJLENBQUNOLGNBQU0sQ0FBQ0MsU0FBUyxDQUFDLFFBQVEsRUFBRTtNQUFFQyxJQUFJLEVBQUU7SUFBUSxDQUFDLENBQUMsQ0FBQztFQUNwRixDQUFDLENBQUM7RUFFRixJQUFBTixVQUFFLEVBQUMsd0VBQXdFLEVBQUUsTUFBTTtJQUNqRixJQUFBQyxjQUFNLGVBQUMsSUFBQWxCLFdBQUEsQ0FBQVcsR0FBQSxFQUFDUixPQUFPLElBQUUsQ0FBQyxDQUFDO0lBQ25CZ0IsaUJBQVMsQ0FBQ0MsS0FBSyxDQUFDQyxjQUFNLENBQUNDLFNBQVMsQ0FBQyxRQUFRLEVBQUU7TUFBRUMsSUFBSSxFQUFFO0lBQWMsQ0FBQyxDQUFDLENBQUM7SUFDcEU7SUFDQUosaUJBQVMsQ0FBQ1csT0FBTyxDQUFDTCxRQUFRLEVBQUU7TUFBRU0sR0FBRyxFQUFFLEtBQUs7TUFBRUMsUUFBUSxFQUFFO0lBQUssQ0FBQyxDQUFDO0lBQzNELElBQUFSLGNBQU0sRUFBQ0MsUUFBUSxDQUFDQyxhQUFhLENBQUMsQ0FBQ0MsSUFBSSxDQUFDTixjQUFNLENBQUNDLFNBQVMsQ0FBQyxRQUFRLEVBQUU7TUFBRUMsSUFBSSxFQUFFO0lBQU8sQ0FBQyxDQUFDLENBQUM7RUFDbkYsQ0FBQyxDQUFDO0VBRUYsSUFBQU4sVUFBRSxFQUFDLGlEQUFpRCxFQUFFLE1BQU07SUFDMUQsSUFBQUMsY0FBTSxlQUFDLElBQUFsQixXQUFBLENBQUFXLEdBQUEsRUFBQ1IsT0FBTyxJQUFFLENBQUMsQ0FBQztJQUNuQixNQUFNOEIsT0FBTyxHQUFHWixjQUFNLENBQUNDLFNBQVMsQ0FBQyxRQUFRLEVBQUU7TUFBRUMsSUFBSSxFQUFFO0lBQWMsQ0FBQyxDQUFDO0lBQ25FVSxPQUFPLENBQUNKLEtBQUssQ0FBQyxDQUFDO0lBQ2ZWLGlCQUFTLENBQUNDLEtBQUssQ0FBQ2EsT0FBTyxDQUFDO0lBQ3hCLElBQUFULGNBQU0sRUFBQ0gsY0FBTSxDQUFDYSxXQUFXLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQ0MsaUJBQWlCLENBQUMsQ0FBQztJQUN2RGhCLGlCQUFTLENBQUNXLE9BQU8sQ0FBQ0wsUUFBUSxFQUFFO01BQUVNLEdBQUcsRUFBRTtJQUFTLENBQUMsQ0FBQztJQUM5QyxJQUFBUCxjQUFNLEVBQUNILGNBQU0sQ0FBQ2UsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUNDLEdBQUcsQ0FBQ0YsaUJBQWlCLENBQUMsQ0FBQztJQUM3RCxJQUFBWCxjQUFNLEVBQUNDLFFBQVEsQ0FBQ0MsYUFBYSxDQUFDLENBQUNDLElBQUksQ0FBQ00sT0FBTyxDQUFDO0VBQzlDLENBQUMsQ0FBQztFQUVGLElBQUFoQixVQUFFLEVBQUMsdURBQXVELEVBQUUsTUFBTTtJQUNoRSxNQUFNcUIsR0FBRyxHQUFHQyxVQUFFLENBQUNDLEVBQUUsQ0FBQyxDQUFDO0lBQ25CLElBQUF0QixjQUFNLGVBQ0osSUFBQWxCLFdBQUEsQ0FBQVcsR0FBQTtNQUFLOEIsU0FBUyxFQUFFSCxHQUFJO01BQUE1QixRQUFBLGVBQ2xCLElBQUFWLFdBQUEsQ0FBQVcsR0FBQSxFQUFDUixPQUFPLElBQUU7SUFBQyxDQUNSLENBQ1AsQ0FBQztJQUNEO0lBQ0E7SUFDQWdCLGlCQUFTLENBQUNXLE9BQU8sQ0FBQ1QsY0FBTSxDQUFDQyxTQUFTLENBQUMsUUFBUSxFQUFFO01BQUVDLElBQUksRUFBRTtJQUFjLENBQUMsQ0FBQyxFQUFFO01BQUVRLEdBQUcsRUFBRTtJQUFTLENBQUMsQ0FBQztJQUN6RixJQUFBUCxjQUFNLEVBQUNjLEdBQUcsQ0FBQyxDQUFDSSxnQkFBZ0IsQ0FBQyxDQUFDO0lBQzlCLElBQUFsQixjQUFNLEVBQUNILGNBQU0sQ0FBQ2UsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUNDLEdBQUcsQ0FBQ0YsaUJBQWlCLENBQUMsQ0FBQztFQUMvRCxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7QUFBQyxJQUFBcEIsRUFBQTtBQUFBNEIsWUFBQSxDQUFBNUIsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}