var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.find.js");
require("core-js/modules/esnext.iterator.some.js");
var _react = require("@testing-library/react");
var _react2 = require("react");
var _vitest = require("vitest");
var _useLodestar = require("./useLodestar");
var _boardStore = require("../lib/boardStore");
var _openProject = require("../lib/openProject");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // @vitest-environment jsdom
// Post-pick busy states (R3-607 / R-IX-2): the named busy label is set BEFORE
// the awaited pick resolves, cleared after; a rejecting pick lands in the toast
// channel. `pickFile` is the boundary — mocked controllable here; everything
// else is the real controller.
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; }
// Per-case mounts (R3-831): the default is no mounts at all — an ordinary
// launch; the corpus cases push a `type: 'content'` mount in, and the no-host
// case makes the read itself throw (the SDK's transport mount service throws
// 'no host transport' under local vite dev — the branch the corpus read guards).
// Held in an object for the react-hooks globals rule (see `held` below).
const mountsHeld = {
  list: [],
  throws: false
};
_vitest.vi.mock('@immediately-run/sdk/mounts', () => ({
  getMounts: () => {
    if (mountsHeld.throws) throw new Error('no host transport');
    return mountsHeld.list;
  },
  onMountsChange: () => () => {},
  openSettings: async () => {
    throw new Error('no host transport');
  }
}));

// The pick boundary: resolve/reject controlled per-case. `boardSpaceRoot` rides
// the same module and is waited before the pick.
let pickResult = null;
_vitest.vi.mock('../lib/pickFile', () => ({
  pickFile: () => pickResult,
  boardSpaceRoot: async () => '/mem/board',
  requestSpace: async () => null,
  safeRel: s => s
}));

// removeView is the one boardStore function deleteView's new branches ride —
// controllable here, real everywhere else (partial mock over the original).
// boardExists/loadBoard/openBoardTarget are controllable the same way for the
// R3-831 corpus cases: the default is the REAL function, so every other case
// behaves exactly as before.
_vitest.vi.mock('../lib/boardStore', async importOriginal => {
  const orig = await importOriginal();
  return {
    ...orig,
    removeView: _vitest.vi.fn(async () => undefined),
    boardExists: _vitest.vi.fn(orig.boardExists),
    loadBoard: _vitest.vi.fn(orig.loadBoard),
    openBoardTarget: _vitest.vi.fn(orig.openBoardTarget)
  };
});
// Held in an object (not a bare let): the react-hooks globals rule forbids
// reassigning outside-declared variables inside a component.
const held = {
  wb: null
};
function Harness() {
  _s();
  const controller = (0, _useLodestar.useLodestar)();
  // Capture in an EFFECT (the react-hooks immutability rule bans outside
  // writes during render); act flushes effects, so tests read it after render.
  (0, _react2.useEffect)(() => {
    held.wb = controller;
  });
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    children: controller.state.objects.length
  });
}
_s(Harness, "vtKGE7PJHpDN+tlpSLDmkct7hBI=", false, function () {
  return [_useLodestar.useLodestar];
});
_c = Harness;
async function renderWithBoard() {
  (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(Harness, {}));
  const wb = held.wb;
  // Arm a writable board target so insertImage passes its sign-in guard; the
  // real loadBoard tolerates an absent directory (readDirSafe degrades).
  await (0, _react.act)(async () => {
    await wb.openBoardAt({
      root: '/mem/board',
      mode: 'rw'
    });
  });
}

// Every case starts with no mounts (R3-831): a leftover corpus mount from a
// previous case would reroute the next case's boot into the corpus path, and a
// leftover throw would break every read after the no-host case.
(0, _vitest.beforeEach)(() => {
  mountsHeld.list = [];
  mountsHeld.throws = false;
});
// No vitest globals → no RTL auto-cleanup: without this, each case's Harness
// stays mounted with a live boot chain (the R3-831 poll keeps one pending for
// up to a second), and a leaked chain's durable-path calls land in the NEXT
// case's assertions.
(0, _vitest.afterEach)(_react.cleanup);
(0, _vitest.describe)('post-pick busy states (R3-607)', () => {
  (0, _vitest.beforeEach)(() => {
    pickResult = null;
  });
  (0, _vitest.it)('applySelection — the additive branch every shift-click takes (toggle in, toggle out)', async () => {
    await renderWithBoard();
    // The pure spelling both pointer and keyboard share; imported directly so a
    // toggle-branch regression cannot hide behind a render.
    const {
      applySelection
    } = await Promise.resolve().then(() => _interopRequireWildcard(require('./useLodestar')));
    (0, _vitest.expect)(applySelection([], 'a', true)).toEqual(['a']);
    (0, _vitest.expect)(applySelection(['a'], 'b', true)).toEqual(['a', 'b']);
    (0, _vitest.expect)(applySelection(['a', 'b'], 'a', true)).toEqual(['b']); // toggle out
    (0, _vitest.expect)(applySelection(['a'], 'a', false)).toEqual(['a']); // replace keeps
    (0, _vitest.expect)(applySelection(['a'], 'b', false)).toEqual(['b']); // replace swaps
  });
  (0, _vitest.it)('the busy label is set before the pick resolves and cleared after (cancel)', async () => {
    await renderWithBoard();
    const wb = held.wb;
    let resolvePick;
    pickResult = new Promise(res => {
      resolvePick = res;
    });
    let pending;
    await (0, _react.act)(async () => {
      pending = wb.insertImage(0, 0);
    });
    (0, _vitest.expect)(held.wb.state.busy).toBe('insert-image');
    await (0, _react.act)(async () => {
      resolvePick(null); // cancelled — the picker was dismissed
      await pending;
    });
    (0, _vitest.expect)(held.wb.state.busy).toBeNull();
  });
  (0, _vitest.it)('a rejecting pick lands in the toast channel and clears busy', async () => {
    await renderWithBoard();
    const wb = held.wb;
    pickResult = Promise.reject(Object.assign(new Error('picker failed'), {
      code: 'cancelled'
    }));
    let pending;
    // A SYNCHRONOUS act: starts the flow without flushing its microtasks, so
    // the busy state is observable before the rejection is handled.
    (0, _react.act)(() => {
      pending = wb.insertImage(0, 0);
    });
    (0, _vitest.expect)(held.wb.state.busy).toBe('insert-image');
    await (0, _react.act)(async () => {
      await pending;
    });
    (0, _vitest.expect)(held.wb.state.busy).toBeNull();
    (0, _vitest.expect)(held.wb.state.toasts.some(t => t.text.includes('insert image'))).toBe(true);
  });
  (0, _vitest.it)('the keyboard connect path — arm, walk the cursor (with wrap), commit through the real addConnection, cancel', async () => {
    // No board target needed: the connect actions work in memory (the seed
    // board supplies the objects); commitSave's no-board path just toasts.
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(Harness, {}));
    const wb = held.wb;
    const first = wb.state.objects[0];
    await (0, _react.act)(async () => {
      wb.select(first.id);
    });
    await (0, _react.act)(async () => {
      wb.beginConnect();
    });
    // Armed: the source is the selection; the cursor starts on another object.
    const s1 = held.wb.state;
    (0, _vitest.expect)(s1.connectFrom).toBe(first.id);
    (0, _vitest.expect)(s1.connectCursor).not.toBe(first.id);
    (0, _vitest.expect)(s1.connectCursor).toBeTruthy();
    // The walk: arrows move the cursor through the other objects, wrapping at
    // both ends, never landing on the source.
    const others = s1.objects.filter(o => o.id !== first.id).length;
    await (0, _react.act)(async () => {
      for (let i = 0; i < others + 2; i += 1) wb.moveConnectCursor(1);
    });
    (0, _vitest.expect)(held.wb.state.connectCursor).not.toBe(first.id);
    await (0, _react.act)(async () => {
      wb.moveConnectCursor(-1);
    });
    (0, _vitest.expect)(held.wb.state.connectCursor).not.toBe(first.id);
    // Commit: the edge arrives through the same store action the drag calls.
    const target = held.wb.state.connectCursor;
    const before = held.wb.state.objects.find(o => o.id === first.id).connections.length;
    await (0, _react.act)(async () => {
      wb.endConnect(true);
    });
    const src = held.wb.state.objects.find(o => o.id === first.id);
    (0, _vitest.expect)(src.connections.some(c => c.to === target)).toBe(true);
    (0, _vitest.expect)(src.connections.length).toBe(before + 1);
    (0, _vitest.expect)(held.wb.state.connectFrom).toBeNull();
    // Cancel adds nothing: arm again on the (still-selected) source and Escape.
    await (0, _react.act)(async () => {
      wb.beginConnect();
    });
    await (0, _react.act)(async () => {
      wb.endConnect(false);
    });
    const after = held.wb.state.objects.find(o => o.id === first.id).connections.length;
    (0, _vitest.expect)(after).toBe(before + 1);
    (0, _vitest.expect)(held.wb.state.connectFrom).toBeNull();
  });
  (0, _vitest.it)('deleteView on a read-only board refuses BEFORE dropping — the row survives', async () => {
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(Harness, {}));
    await (0, _react.act)(async () => {
      // A read-only board target (the ro guard fires before any state change).
      await held.wb.openBoardAt({
        root: '/mem/ro',
        mode: 'ro'
      });
    });
    const name = held.wb.state.views[0].name;
    await (0, _react.act)(async () => {
      held.wb.deleteView(name);
    });
    (0, _vitest.expect)(held.wb.state.views.some(v => v.name === name)).toBe(true);
    (0, _vitest.expect)(held.wb.state.toasts.some(t => t.text.includes('Read-only board'))).toBe(true);
    (0, _vitest.expect)(_boardStore.removeView).not.toHaveBeenCalled();
  });
  (0, _vitest.it)('deleteView rolls the row back when the file removal fails', async () => {
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(Harness, {}));
    await (0, _react.act)(async () => {
      await held.wb.openBoardAt({
        root: '/mem/board',
        mode: 'rw'
      });
    });
    const name = held.wb.state.views[0].name;
    _vitest.vi.mocked(_boardStore.removeView).mockRejectedValueOnce(Object.assign(new Error('EROFS'), {
      code: 'EROFS'
    }));
    await (0, _react.act)(async () => {
      held.wb.deleteView(name);
    });
    (0, _vitest.expect)(held.wb.state.views.some(v => v.name === name)).toBe(true);
    (0, _vitest.expect)(held.wb.state.toasts.some(t => t.text.includes('remove view'))).toBe(true);
  });
});

// ── URL-dispatched corpus board (R3-831) ─────────────────────────────────────
// A cold URL load into a repo whose marker names open-project dispatches to us
// as the bound viewer with NO task input; the host marks the loaded repo as a
// `type: 'content'` mount available at boot. That mount is the project — the
// board loads from it, and the durable path never opens.
(0, _vitest.describe)('URL-dispatched corpus board (R3-831)', () => {
  (0, _vitest.beforeEach)(() => {
    // Call counts accumulate across the file's earlier cases (module-level
    // mocks); mockReset drops the once-queue too, so an unconsumed queued
    // rejection cannot leak one case forward, and restores the real-function
    // baseline each of these mocks was built on.
    _vitest.vi.mocked(_boardStore.loadBoard).mockReset();
    _vitest.vi.mocked(_boardStore.openBoardTarget).mockReset();
    _vitest.vi.mocked(_boardStore.boardExists).mockReset();
  });
  const CORPUS = {
    path: '/mnt/corpus',
    type: 'content',
    id: 'content:immediately-run/lodestar-sample-project',
    mode: 'ro'
  };
  const NOTE = {
    id: 'note-welcome',
    kind: 'note',
    x: 0,
    y: 0,
    w: 200,
    h: 148,
    rot: 0,
    scale: 1,
    z: 3,
    connections: [],
    title: 'Welcome'
  };
  (0, _vitest.it)('corpusMount keys on the host mark (`type: content`), never on the only foreign mount', () => {
    (0, _vitest.expect)((0, _openProject.corpusMount)([])).toBeNull();
    // A held space is foreign too — keying on "the only foreign mount" would
    // open the wrong board the moment a space is held.
    (0, _vitest.expect)((0, _openProject.corpusMount)([{
      path: '/spaces/x',
      type: 'firestore',
      id: 'space-1',
      mode: 'rw'
    }])).toBeNull();
    (0, _vitest.expect)((0, _openProject.corpusMount)([CORPUS])).toBe(CORPUS);
  });
  (0, _vitest.it)('with no task input, a corpus mount IS the project — the board loads from it, chrooted as mounted', async () => {
    mountsHeld.list = [CORPUS];
    _vitest.vi.mocked(_boardStore.boardExists).mockResolvedValueOnce(true);
    _vitest.vi.mocked(_boardStore.loadBoard).mockResolvedValueOnce({
      objects: [NOTE],
      views: [],
      journeys: [],
      title: 'Sample project'
    });
    // The durable space must never open: the URL named THIS project, so its
    // own board — not the user's space, not the demo seed — is what shows.
    _vitest.vi.mocked(_boardStore.openBoardTarget).mockRejectedValueOnce(new Error('durable space must not open'));
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(Harness, {}));
    await (0, _react.act)(async () => {
      await new Promise(r => setTimeout(r, 0)); // let the boot chain settle
    });
    (0, _vitest.expect)(_boardStore.loadBoard).toHaveBeenCalledWith({
      root: '/mnt/corpus',
      mode: 'ro',
      spaceId: CORPUS.id
    });
    // The durable space must never open — asserted, not queued: the mock's
    // rejection above is swallowed by the durable path's own catch, so only
    // this call-count assertion holds the named guarantee.
    (0, _vitest.expect)(_boardStore.openBoardTarget).not.toHaveBeenCalled();
    (0, _vitest.expect)(held.wb.state.title).toBe('Sample project');
    (0, _vitest.expect)(held.wb.state.objects).toHaveLength(1);
    (0, _vitest.expect)(held.wb.state.objects[0].id).toBe('note-welcome');
  });
  (0, _vitest.it)('a corpus mount whose board fails to load reports and falls through to the durable path', async () => {
    mountsHeld.list = [CORPUS];
    _vitest.vi.mocked(_boardStore.boardExists).mockResolvedValueOnce(true);
    _vitest.vi.mocked(_boardStore.loadBoard).mockRejectedValueOnce(Object.assign(new Error('EROFS'), {
      code: 'EROFS'
    }));
    _vitest.vi.mocked(_boardStore.openBoardTarget).mockRejectedValueOnce(Object.assign(new Error('auth-required'), {
      code: 'auth-required'
    }));
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(Harness, {}));
    await (0, _react.act)(async () => {
      await new Promise(r => setTimeout(r, 0));
    });
    (0, _vitest.expect)(_boardStore.loadBoard).toHaveBeenCalledTimes(1);
    // The failed load fell through: the durable path opened (and here,
    // signed-out, degraded to the in-memory seed — today's behavior).
    (0, _vitest.expect)(_boardStore.openBoardTarget).toHaveBeenCalledTimes(1);
    (0, _vitest.expect)(held.wb.state.toasts.some(t => t.text.includes('Couldn’t open project'))).toBe(true);
  });
  (0, _vitest.it)('a corpus mount with no board files falls through to the durable path unchanged', async () => {
    mountsHeld.list = [CORPUS];
    _vitest.vi.mocked(_boardStore.boardExists).mockResolvedValueOnce(false);
    _vitest.vi.mocked(_boardStore.openBoardTarget).mockRejectedValueOnce(Object.assign(new Error('auth-required'), {
      code: 'auth-required'
    }));
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(Harness, {}));
    await (0, _react.act)(async () => {
      // No corpus: the bounded poll pays its full window before the durable path.
      await new Promise(r => setTimeout(r, _openProject.CORPUS_POLL_TRIES * _openProject.CORPUS_POLL_INTERVAL_MS + 300));
    });
    (0, _vitest.expect)(_boardStore.loadBoard).not.toHaveBeenCalled();
    (0, _vitest.expect)(_boardStore.openBoardTarget).toHaveBeenCalledTimes(1);
  });
  (0, _vitest.it)('an unmounted chain stops before the durable path — the cancelled guard, no leaked board-space open', async () => {
    // No corpus: the poll is pending mid-flight when the component unmounts (a
    // mid-boot navigation). Without the cancelled guard the durable path would
    // still open the user's board space from a gone app.
    const {
      unmount
    } = (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(Harness, {}));
    await (0, _react.act)(async () => {
      await new Promise(r => setTimeout(r, 2 * _openProject.CORPUS_POLL_INTERVAL_MS)); // mid-poll
    });
    unmount();
    await (0, _react.act)(async () => {
      await new Promise(r => setTimeout(r, _openProject.CORPUS_POLL_TRIES * _openProject.CORPUS_POLL_INTERVAL_MS + 300));
    });
    (0, _vitest.expect)(_boardStore.loadBoard).not.toHaveBeenCalled();
    (0, _vitest.expect)(_boardStore.openBoardTarget).not.toHaveBeenCalled();
  });
  (0, _vitest.it)('with no corpus mount and no task input, the durable path answers exactly as before', async () => {
    mountsHeld.list = [];
    _vitest.vi.mocked(_boardStore.openBoardTarget).mockRejectedValueOnce(Object.assign(new Error('auth-required'), {
      code: 'auth-required'
    }));
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(Harness, {}));
    await (0, _react.act)(async () => {
      // No corpus: the bounded poll pays its full window before the durable path.
      await new Promise(r => setTimeout(r, _openProject.CORPUS_POLL_TRIES * _openProject.CORPUS_POLL_INTERVAL_MS + 300));
    });
    (0, _vitest.expect)(_boardStore.loadBoard).not.toHaveBeenCalled();
    (0, _vitest.expect)(_boardStore.openBoardTarget).toHaveBeenCalledTimes(1);
    // Signed out: the in-memory seed stays — the demo board, today's behavior.
    (0, _vitest.expect)(held.wb.state.objects.length).toBeGreaterThan(0);
  });
  (0, _vitest.it)('a corpus mount that arrives late (the mount mirror\'s async replay) is still found — the intermittent race, pinned', async () => {
    // The SDK's mount mirror populates from the host's mount-add re-announcement,
    // asynchronously relative to the boot effect: a one-shot read intermittently
    // missed the corpus and booted the demo board instead (found live on the
    // venue, 2026-10-03). The mount appears ~150ms after boot here — after the
    // first read, inside the bounded poll.
    setTimeout(() => {
      mountsHeld.list = [CORPUS];
    }, 150);
    _vitest.vi.mocked(_boardStore.boardExists).mockResolvedValueOnce(true);
    _vitest.vi.mocked(_boardStore.loadBoard).mockResolvedValueOnce({
      objects: [NOTE],
      views: [],
      journeys: [],
      title: 'Sample project'
    });
    _vitest.vi.mocked(_boardStore.openBoardTarget).mockRejectedValueOnce(new Error('durable space must not open'));
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(Harness, {}));
    await (0, _react.act)(async () => {
      // The mount arrives ~150ms after boot; the poll's window is ample —
      // derived from the named bound, not a private headroom over it.
      await new Promise(r => setTimeout(r, _openProject.CORPUS_POLL_TRIES * _openProject.CORPUS_POLL_INTERVAL_MS));
    });
    (0, _vitest.expect)(_boardStore.loadBoard).toHaveBeenCalledWith({
      root: '/mnt/corpus',
      mode: 'ro',
      spaceId: CORPUS.id
    });
    (0, _vitest.expect)(_boardStore.openBoardTarget).not.toHaveBeenCalled();
    (0, _vitest.expect)(held.wb.state.title).toBe('Sample project');
  });
  (0, _vitest.it)('a corpus mount arriving AFTER unmount is never loaded — the poll\'s cancelled return, pinned', async () => {
    // The poll's isCancelled early-return is the only guard on the corpus side:
    // a mount arriving after the component unmounted would otherwise load a
    // board into a gone app (probe-verified by review round 2: with the check
    // deleted, this case is the one that fails).
    setTimeout(() => {
      mountsHeld.list = [CORPUS];
    }, 6 * _openProject.CORPUS_POLL_INTERVAL_MS); // after the unmount below, inside the window
    _vitest.vi.mocked(_boardStore.boardExists).mockResolvedValueOnce(true);
    _vitest.vi.mocked(_boardStore.loadBoard).mockResolvedValueOnce({
      objects: [NOTE],
      views: [],
      journeys: [],
      title: 'Sample project'
    });
    const {
      unmount
    } = (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(Harness, {}));
    await (0, _react.act)(async () => {
      await new Promise(r => setTimeout(r, 2 * _openProject.CORPUS_POLL_INTERVAL_MS)); // mid-poll, before the arrival
    });
    unmount();
    await (0, _react.act)(async () => {
      await new Promise(r => setTimeout(r, _openProject.CORPUS_POLL_TRIES * _openProject.CORPUS_POLL_INTERVAL_MS + 300));
    });
    (0, _vitest.expect)(_boardStore.loadBoard).not.toHaveBeenCalled();
    (0, _vitest.expect)(_boardStore.openBoardTarget).not.toHaveBeenCalled();
  });
  (0, _vitest.it)('a throwing mounts read (no host, local vite dev) skips the corpus path and the durable path answers exactly', async () => {
    mountsHeld.throws = true;
    _vitest.vi.mocked(_boardStore.openBoardTarget).mockRejectedValueOnce(Object.assign(new Error('auth-required'), {
      code: 'auth-required'
    }));
    (0, _react.render)(/*#__PURE__*/(0, _jsxRuntime.jsx)(Harness, {}));
    await (0, _react.act)(async () => {
      await new Promise(r => setTimeout(r, 0));
    });
    // The corpus read's catch is the branch that keeps every local no-host boot
    // on the durable path: no corpus toast, no loadBoard, the durable answer.
    (0, _vitest.expect)(_boardStore.loadBoard).not.toHaveBeenCalled();
    (0, _vitest.expect)(_boardStore.openBoardTarget).toHaveBeenCalledTimes(1);
    (0, _vitest.expect)(held.wb.state.toasts.some(t => t.text.includes('Couldn’t open project'))).toBe(false);
    (0, _vitest.expect)(held.wb.state.objects.length).toBeGreaterThan(0);
  });
});
var _c;
$RefreshReg$(_c, "Harness");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3JlYWN0MiIsIl92aXRlc3QiLCJfdXNlTG9kZXN0YXIiLCJfYm9hcmRTdG9yZSIsIl9vcGVuUHJvamVjdCIsIl9qc3hSdW50aW1lIiwiX3MiLCIkUmVmcmVzaFNpZyQiLCJfZ2V0UmVxdWlyZVdpbGRjYXJkQ2FjaGUiLCJlIiwiV2Vha01hcCIsInIiLCJ0IiwiX2ludGVyb3BSZXF1aXJlV2lsZGNhcmQiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsImhhcyIsImdldCIsIm4iLCJfX3Byb3RvX18iLCJhIiwiT2JqZWN0IiwiZGVmaW5lUHJvcGVydHkiLCJnZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IiLCJ1IiwiaGFzT3duUHJvcGVydHkiLCJjYWxsIiwiaSIsInNldCIsIm1vdW50c0hlbGQiLCJsaXN0IiwidGhyb3dzIiwidmkiLCJtb2NrIiwiZ2V0TW91bnRzIiwiRXJyb3IiLCJvbk1vdW50c0NoYW5nZSIsIm9wZW5TZXR0aW5ncyIsInBpY2tSZXN1bHQiLCJwaWNrRmlsZSIsImJvYXJkU3BhY2VSb290IiwicmVxdWVzdFNwYWNlIiwic2FmZVJlbCIsInMiLCJpbXBvcnRPcmlnaW5hbCIsIm9yaWciLCJyZW1vdmVWaWV3IiwiZm4iLCJ1bmRlZmluZWQiLCJib2FyZEV4aXN0cyIsImxvYWRCb2FyZCIsIm9wZW5Cb2FyZFRhcmdldCIsImhlbGQiLCJ3YiIsIkhhcm5lc3MiLCJjb250cm9sbGVyIiwidXNlTG9kZXN0YXIiLCJ1c2VFZmZlY3QiLCJqc3giLCJjaGlsZHJlbiIsInN0YXRlIiwib2JqZWN0cyIsImxlbmd0aCIsIl9jIiwicmVuZGVyV2l0aEJvYXJkIiwicmVuZGVyIiwiYWN0Iiwib3BlbkJvYXJkQXQiLCJyb290IiwibW9kZSIsImJlZm9yZUVhY2giLCJhZnRlckVhY2giLCJjbGVhbnVwIiwiZGVzY3JpYmUiLCJpdCIsImFwcGx5U2VsZWN0aW9uIiwiUHJvbWlzZSIsInJlc29sdmUiLCJ0aGVuIiwiZXhwZWN0IiwidG9FcXVhbCIsInJlc29sdmVQaWNrIiwicmVzIiwicGVuZGluZyIsImluc2VydEltYWdlIiwiYnVzeSIsInRvQmUiLCJ0b0JlTnVsbCIsInJlamVjdCIsImFzc2lnbiIsImNvZGUiLCJ0b2FzdHMiLCJzb21lIiwidGV4dCIsImluY2x1ZGVzIiwiZmlyc3QiLCJzZWxlY3QiLCJpZCIsImJlZ2luQ29ubmVjdCIsInMxIiwiY29ubmVjdEZyb20iLCJjb25uZWN0Q3Vyc29yIiwibm90IiwidG9CZVRydXRoeSIsIm90aGVycyIsImZpbHRlciIsIm8iLCJtb3ZlQ29ubmVjdEN1cnNvciIsInRhcmdldCIsImJlZm9yZSIsImZpbmQiLCJjb25uZWN0aW9ucyIsImVuZENvbm5lY3QiLCJzcmMiLCJjIiwidG8iLCJhZnRlciIsIm5hbWUiLCJ2aWV3cyIsImRlbGV0ZVZpZXciLCJ2IiwidG9IYXZlQmVlbkNhbGxlZCIsIm1vY2tlZCIsIm1vY2tSZWplY3RlZFZhbHVlT25jZSIsIm1vY2tSZXNldCIsIkNPUlBVUyIsInBhdGgiLCJ0eXBlIiwiTk9URSIsImtpbmQiLCJ4IiwieSIsInciLCJoIiwicm90Iiwic2NhbGUiLCJ6IiwidGl0bGUiLCJjb3JwdXNNb3VudCIsIm1vY2tSZXNvbHZlZFZhbHVlT25jZSIsImpvdXJuZXlzIiwic2V0VGltZW91dCIsInRvSGF2ZUJlZW5DYWxsZWRXaXRoIiwic3BhY2VJZCIsInRvSGF2ZUxlbmd0aCIsInRvSGF2ZUJlZW5DYWxsZWRUaW1lcyIsIkNPUlBVU19QT0xMX1RSSUVTIiwiQ09SUFVTX1BPTExfSU5URVJWQUxfTVMiLCJ1bm1vdW50IiwidG9CZUdyZWF0ZXJUaGFuIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsidXNlTG9kZXN0YXIudGVzdC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gQHZpdGVzdC1lbnZpcm9ubWVudCBqc2RvbVxuLy8gUG9zdC1waWNrIGJ1c3kgc3RhdGVzIChSMy02MDcgLyBSLUlYLTIpOiB0aGUgbmFtZWQgYnVzeSBsYWJlbCBpcyBzZXQgQkVGT1JFXG4vLyB0aGUgYXdhaXRlZCBwaWNrIHJlc29sdmVzLCBjbGVhcmVkIGFmdGVyOyBhIHJlamVjdGluZyBwaWNrIGxhbmRzIGluIHRoZSB0b2FzdFxuLy8gY2hhbm5lbC4gYHBpY2tGaWxlYCBpcyB0aGUgYm91bmRhcnkg4oCUIG1vY2tlZCBjb250cm9sbGFibGUgaGVyZTsgZXZlcnl0aGluZ1xuLy8gZWxzZSBpcyB0aGUgcmVhbCBjb250cm9sbGVyLlxuaW1wb3J0IHsgYWN0LCBjbGVhbnVwLCByZW5kZXIgfSBmcm9tICdAdGVzdGluZy1saWJyYXJ5L3JlYWN0JztcbmltcG9ydCB7IHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IGRlc2NyaWJlLCBleHBlY3QsIGl0LCB2aSwgYmVmb3JlRWFjaCwgYWZ0ZXJFYWNoIH0gZnJvbSAndml0ZXN0JztcbmltcG9ydCB0eXBlIHsgU2FuZGJveE1vdW50IH0gZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9zZGsvbW91bnRzJztcblxuLy8gUGVyLWNhc2UgbW91bnRzIChSMy04MzEpOiB0aGUgZGVmYXVsdCBpcyBubyBtb3VudHMgYXQgYWxsIOKAlCBhbiBvcmRpbmFyeVxuLy8gbGF1bmNoOyB0aGUgY29ycHVzIGNhc2VzIHB1c2ggYSBgdHlwZTogJ2NvbnRlbnQnYCBtb3VudCBpbiwgYW5kIHRoZSBuby1ob3N0XG4vLyBjYXNlIG1ha2VzIHRoZSByZWFkIGl0c2VsZiB0aHJvdyAodGhlIFNESydzIHRyYW5zcG9ydCBtb3VudCBzZXJ2aWNlIHRocm93c1xuLy8gJ25vIGhvc3QgdHJhbnNwb3J0JyB1bmRlciBsb2NhbCB2aXRlIGRldiDigJQgdGhlIGJyYW5jaCB0aGUgY29ycHVzIHJlYWQgZ3VhcmRzKS5cbi8vIEhlbGQgaW4gYW4gb2JqZWN0IGZvciB0aGUgcmVhY3QtaG9va3MgZ2xvYmFscyBydWxlIChzZWUgYGhlbGRgIGJlbG93KS5cbmNvbnN0IG1vdW50c0hlbGQgPSB7IGxpc3Q6IFtdIGFzIFNhbmRib3hNb3VudFtdLCB0aHJvd3M6IGZhbHNlIH07XG52aS5tb2NrKCdAaW1tZWRpYXRlbHktcnVuL3Nkay9tb3VudHMnLCAoKSA9PiAoe1xuICBnZXRNb3VudHM6ICgpID0+IHtcbiAgICBpZiAobW91bnRzSGVsZC50aHJvd3MpIHRocm93IG5ldyBFcnJvcignbm8gaG9zdCB0cmFuc3BvcnQnKTtcbiAgICByZXR1cm4gbW91bnRzSGVsZC5saXN0O1xuICB9LFxuICBvbk1vdW50c0NoYW5nZTogKCkgPT4gKCkgPT4ge30sXG4gIG9wZW5TZXR0aW5nczogYXN5bmMgKCkgPT4ge1xuICAgIHRocm93IG5ldyBFcnJvcignbm8gaG9zdCB0cmFuc3BvcnQnKTtcbiAgfSxcbn0pKTtcblxuLy8gVGhlIHBpY2sgYm91bmRhcnk6IHJlc29sdmUvcmVqZWN0IGNvbnRyb2xsZWQgcGVyLWNhc2UuIGBib2FyZFNwYWNlUm9vdGAgcmlkZXNcbi8vIHRoZSBzYW1lIG1vZHVsZSBhbmQgaXMgd2FpdGVkIGJlZm9yZSB0aGUgcGljay5cbmxldCBwaWNrUmVzdWx0OiBQcm9taXNlPHsgcmVsUGF0aDogc3RyaW5nIH0gfCBudWxsPiB8IG51bGwgPSBudWxsO1xudmkubW9jaygnLi4vbGliL3BpY2tGaWxlJywgKCkgPT4gKHtcbiAgcGlja0ZpbGU6ICgpID0+IHBpY2tSZXN1bHQsXG4gIGJvYXJkU3BhY2VSb290OiBhc3luYyAoKSA9PiAnL21lbS9ib2FyZCcsXG4gIHJlcXVlc3RTcGFjZTogYXN5bmMgKCkgPT4gbnVsbCxcbiAgc2FmZVJlbDogKHM6IHN0cmluZykgPT4gcyxcbn0pKTtcblxuLy8gcmVtb3ZlVmlldyBpcyB0aGUgb25lIGJvYXJkU3RvcmUgZnVuY3Rpb24gZGVsZXRlVmlldydzIG5ldyBicmFuY2hlcyByaWRlIOKAlFxuLy8gY29udHJvbGxhYmxlIGhlcmUsIHJlYWwgZXZlcnl3aGVyZSBlbHNlIChwYXJ0aWFsIG1vY2sgb3ZlciB0aGUgb3JpZ2luYWwpLlxuLy8gYm9hcmRFeGlzdHMvbG9hZEJvYXJkL29wZW5Cb2FyZFRhcmdldCBhcmUgY29udHJvbGxhYmxlIHRoZSBzYW1lIHdheSBmb3IgdGhlXG4vLyBSMy04MzEgY29ycHVzIGNhc2VzOiB0aGUgZGVmYXVsdCBpcyB0aGUgUkVBTCBmdW5jdGlvbiwgc28gZXZlcnkgb3RoZXIgY2FzZVxuLy8gYmVoYXZlcyBleGFjdGx5IGFzIGJlZm9yZS5cbnZpLm1vY2soJy4uL2xpYi9ib2FyZFN0b3JlJywgYXN5bmMgKGltcG9ydE9yaWdpbmFsKSA9PiB7XG4gIGNvbnN0IG9yaWcgPSBhd2FpdCBpbXBvcnRPcmlnaW5hbDx0eXBlb2YgaW1wb3J0KCcuLi9saWIvYm9hcmRTdG9yZScpPigpO1xuICByZXR1cm4ge1xuICAgIC4uLm9yaWcsXG4gICAgcmVtb3ZlVmlldzogdmkuZm4oYXN5bmMgKCkgPT4gdW5kZWZpbmVkKSxcbiAgICBib2FyZEV4aXN0czogdmkuZm4ob3JpZy5ib2FyZEV4aXN0cyksXG4gICAgbG9hZEJvYXJkOiB2aS5mbihvcmlnLmxvYWRCb2FyZCksXG4gICAgb3BlbkJvYXJkVGFyZ2V0OiB2aS5mbihvcmlnLm9wZW5Cb2FyZFRhcmdldCksXG4gIH07XG59KTtcblxuaW1wb3J0IHsgdXNlTG9kZXN0YXIgfSBmcm9tICcuL3VzZUxvZGVzdGFyJztcbmltcG9ydCB7IGJvYXJkRXhpc3RzLCBsb2FkQm9hcmQsIG9wZW5Cb2FyZFRhcmdldCwgcmVtb3ZlVmlldyB9IGZyb20gJy4uL2xpYi9ib2FyZFN0b3JlJztcbmltcG9ydCB7IENPUlBVU19QT0xMX0lOVEVSVkFMX01TLCBDT1JQVVNfUE9MTF9UUklFUywgY29ycHVzTW91bnQgfSBmcm9tICcuLi9saWIvb3BlblByb2plY3QnO1xuaW1wb3J0IHR5cGUgeyBXT2JqZWN0IH0gZnJvbSAnLi4vbGliL3R5cGVzJztcblxuLy8gSGVsZCBpbiBhbiBvYmplY3QgKG5vdCBhIGJhcmUgbGV0KTogdGhlIHJlYWN0LWhvb2tzIGdsb2JhbHMgcnVsZSBmb3JiaWRzXG4vLyByZWFzc2lnbmluZyBvdXRzaWRlLWRlY2xhcmVkIHZhcmlhYmxlcyBpbnNpZGUgYSBjb21wb25lbnQuXG5jb25zdCBoZWxkID0geyB3YjogbnVsbCBhcyBSZXR1cm5UeXBlPHR5cGVvZiB1c2VMb2Rlc3Rhcj4gfCBudWxsIH07XG5mdW5jdGlvbiBIYXJuZXNzKCkge1xuICBjb25zdCBjb250cm9sbGVyID0gdXNlTG9kZXN0YXIoKTtcbiAgLy8gQ2FwdHVyZSBpbiBhbiBFRkZFQ1QgKHRoZSByZWFjdC1ob29rcyBpbW11dGFiaWxpdHkgcnVsZSBiYW5zIG91dHNpZGVcbiAgLy8gd3JpdGVzIGR1cmluZyByZW5kZXIpOyBhY3QgZmx1c2hlcyBlZmZlY3RzLCBzbyB0ZXN0cyByZWFkIGl0IGFmdGVyIHJlbmRlci5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBoZWxkLndiID0gY29udHJvbGxlcjtcbiAgfSk7XG4gIHJldHVybiA8ZGl2Pntjb250cm9sbGVyLnN0YXRlLm9iamVjdHMubGVuZ3RofTwvZGl2Pjtcbn1cblxuYXN5bmMgZnVuY3Rpb24gcmVuZGVyV2l0aEJvYXJkKCkge1xuICByZW5kZXIoPEhhcm5lc3MgLz4pO1xuICBjb25zdCB3YiA9IGhlbGQud2IhO1xuICAvLyBBcm0gYSB3cml0YWJsZSBib2FyZCB0YXJnZXQgc28gaW5zZXJ0SW1hZ2UgcGFzc2VzIGl0cyBzaWduLWluIGd1YXJkOyB0aGVcbiAgLy8gcmVhbCBsb2FkQm9hcmQgdG9sZXJhdGVzIGFuIGFic2VudCBkaXJlY3RvcnkgKHJlYWREaXJTYWZlIGRlZ3JhZGVzKS5cbiAgYXdhaXQgYWN0KGFzeW5jICgpID0+IHtcbiAgICBhd2FpdCB3Yi5vcGVuQm9hcmRBdCh7IHJvb3Q6ICcvbWVtL2JvYXJkJywgbW9kZTogJ3J3JyB9KTtcbiAgfSk7XG59XG5cbi8vIEV2ZXJ5IGNhc2Ugc3RhcnRzIHdpdGggbm8gbW91bnRzIChSMy04MzEpOiBhIGxlZnRvdmVyIGNvcnB1cyBtb3VudCBmcm9tIGFcbi8vIHByZXZpb3VzIGNhc2Ugd291bGQgcmVyb3V0ZSB0aGUgbmV4dCBjYXNlJ3MgYm9vdCBpbnRvIHRoZSBjb3JwdXMgcGF0aCwgYW5kIGFcbi8vIGxlZnRvdmVyIHRocm93IHdvdWxkIGJyZWFrIGV2ZXJ5IHJlYWQgYWZ0ZXIgdGhlIG5vLWhvc3QgY2FzZS5cbmJlZm9yZUVhY2goKCkgPT4ge1xuICBtb3VudHNIZWxkLmxpc3QgPSBbXTtcbiAgbW91bnRzSGVsZC50aHJvd3MgPSBmYWxzZTtcbn0pO1xuLy8gTm8gdml0ZXN0IGdsb2JhbHMg4oaSIG5vIFJUTCBhdXRvLWNsZWFudXA6IHdpdGhvdXQgdGhpcywgZWFjaCBjYXNlJ3MgSGFybmVzc1xuLy8gc3RheXMgbW91bnRlZCB3aXRoIGEgbGl2ZSBib290IGNoYWluICh0aGUgUjMtODMxIHBvbGwga2VlcHMgb25lIHBlbmRpbmcgZm9yXG4vLyB1cCB0byBhIHNlY29uZCksIGFuZCBhIGxlYWtlZCBjaGFpbidzIGR1cmFibGUtcGF0aCBjYWxscyBsYW5kIGluIHRoZSBORVhUXG4vLyBjYXNlJ3MgYXNzZXJ0aW9ucy5cbmFmdGVyRWFjaChjbGVhbnVwKTtcblxuZGVzY3JpYmUoJ3Bvc3QtcGljayBidXN5IHN0YXRlcyAoUjMtNjA3KScsICgpID0+IHtcbiAgYmVmb3JlRWFjaCgoKSA9PiB7XG4gICAgcGlja1Jlc3VsdCA9IG51bGw7XG4gIH0pO1xuXG4gIGl0KCdhcHBseVNlbGVjdGlvbiDigJQgdGhlIGFkZGl0aXZlIGJyYW5jaCBldmVyeSBzaGlmdC1jbGljayB0YWtlcyAodG9nZ2xlIGluLCB0b2dnbGUgb3V0KScsIGFzeW5jICgpID0+IHtcbiAgICBhd2FpdCByZW5kZXJXaXRoQm9hcmQoKTtcbiAgICAvLyBUaGUgcHVyZSBzcGVsbGluZyBib3RoIHBvaW50ZXIgYW5kIGtleWJvYXJkIHNoYXJlOyBpbXBvcnRlZCBkaXJlY3RseSBzbyBhXG4gICAgLy8gdG9nZ2xlLWJyYW5jaCByZWdyZXNzaW9uIGNhbm5vdCBoaWRlIGJlaGluZCBhIHJlbmRlci5cbiAgICBjb25zdCB7IGFwcGx5U2VsZWN0aW9uIH0gPSBhd2FpdCBpbXBvcnQoJy4vdXNlTG9kZXN0YXInKTtcbiAgICBleHBlY3QoYXBwbHlTZWxlY3Rpb24oW10sICdhJywgdHJ1ZSkpLnRvRXF1YWwoWydhJ10pO1xuICAgIGV4cGVjdChhcHBseVNlbGVjdGlvbihbJ2EnXSwgJ2InLCB0cnVlKSkudG9FcXVhbChbJ2EnLCAnYiddKTtcbiAgICBleHBlY3QoYXBwbHlTZWxlY3Rpb24oWydhJywgJ2InXSwgJ2EnLCB0cnVlKSkudG9FcXVhbChbJ2InXSk7IC8vIHRvZ2dsZSBvdXRcbiAgICBleHBlY3QoYXBwbHlTZWxlY3Rpb24oWydhJ10sICdhJywgZmFsc2UpKS50b0VxdWFsKFsnYSddKTsgLy8gcmVwbGFjZSBrZWVwc1xuICAgIGV4cGVjdChhcHBseVNlbGVjdGlvbihbJ2EnXSwgJ2InLCBmYWxzZSkpLnRvRXF1YWwoWydiJ10pOyAvLyByZXBsYWNlIHN3YXBzXG4gIH0pO1xuXG4gIGl0KCd0aGUgYnVzeSBsYWJlbCBpcyBzZXQgYmVmb3JlIHRoZSBwaWNrIHJlc29sdmVzIGFuZCBjbGVhcmVkIGFmdGVyIChjYW5jZWwpJywgYXN5bmMgKCkgPT4ge1xuICAgIGF3YWl0IHJlbmRlcldpdGhCb2FyZCgpO1xuICAgIGNvbnN0IHdiID0gaGVsZC53YiE7XG4gICAgbGV0IHJlc29sdmVQaWNrITogKHY6IHsgcmVsUGF0aDogc3RyaW5nIH0gfCBudWxsKSA9PiB2b2lkO1xuICAgIHBpY2tSZXN1bHQgPSBuZXcgUHJvbWlzZSgocmVzKSA9PiB7XG4gICAgICByZXNvbHZlUGljayA9IHJlcztcbiAgICB9KTtcbiAgICBsZXQgcGVuZGluZyE6IFByb21pc2U8dm9pZD47XG4gICAgYXdhaXQgYWN0KGFzeW5jICgpID0+IHtcbiAgICAgIHBlbmRpbmcgPSB3Yi5pbnNlcnRJbWFnZSgwLCAwKTtcbiAgICB9KTtcbiAgICBleHBlY3QoaGVsZC53YiEuc3RhdGUuYnVzeSkudG9CZSgnaW5zZXJ0LWltYWdlJyk7XG4gICAgYXdhaXQgYWN0KGFzeW5jICgpID0+IHtcbiAgICAgIHJlc29sdmVQaWNrKG51bGwpOyAvLyBjYW5jZWxsZWQg4oCUIHRoZSBwaWNrZXIgd2FzIGRpc21pc3NlZFxuICAgICAgYXdhaXQgcGVuZGluZztcbiAgICB9KTtcbiAgICBleHBlY3QoaGVsZC53YiEuc3RhdGUuYnVzeSkudG9CZU51bGwoKTtcbiAgfSk7XG5cbiAgaXQoJ2EgcmVqZWN0aW5nIHBpY2sgbGFuZHMgaW4gdGhlIHRvYXN0IGNoYW5uZWwgYW5kIGNsZWFycyBidXN5JywgYXN5bmMgKCkgPT4ge1xuICAgIGF3YWl0IHJlbmRlcldpdGhCb2FyZCgpO1xuICAgIGNvbnN0IHdiID0gaGVsZC53YiE7XG4gICAgcGlja1Jlc3VsdCA9IFByb21pc2UucmVqZWN0KE9iamVjdC5hc3NpZ24obmV3IEVycm9yKCdwaWNrZXIgZmFpbGVkJyksIHsgY29kZTogJ2NhbmNlbGxlZCcgfSkpO1xuICAgIGxldCBwZW5kaW5nITogUHJvbWlzZTx2b2lkPjtcbiAgICAvLyBBIFNZTkNIUk9OT1VTIGFjdDogc3RhcnRzIHRoZSBmbG93IHdpdGhvdXQgZmx1c2hpbmcgaXRzIG1pY3JvdGFza3MsIHNvXG4gICAgLy8gdGhlIGJ1c3kgc3RhdGUgaXMgb2JzZXJ2YWJsZSBiZWZvcmUgdGhlIHJlamVjdGlvbiBpcyBoYW5kbGVkLlxuICAgIGFjdCgoKSA9PiB7XG4gICAgICBwZW5kaW5nID0gd2IuaW5zZXJ0SW1hZ2UoMCwgMCk7XG4gICAgfSk7XG4gICAgZXhwZWN0KGhlbGQud2IhLnN0YXRlLmJ1c3kpLnRvQmUoJ2luc2VydC1pbWFnZScpO1xuICAgIGF3YWl0IGFjdChhc3luYyAoKSA9PiB7XG4gICAgICBhd2FpdCBwZW5kaW5nO1xuICAgIH0pO1xuICAgIGV4cGVjdChoZWxkLndiIS5zdGF0ZS5idXN5KS50b0JlTnVsbCgpO1xuICAgIGV4cGVjdChoZWxkLndiIS5zdGF0ZS50b2FzdHMuc29tZSgodCkgPT4gdC50ZXh0LmluY2x1ZGVzKCdpbnNlcnQgaW1hZ2UnKSkpLnRvQmUodHJ1ZSk7XG4gIH0pO1xuXG4gIGl0KCd0aGUga2V5Ym9hcmQgY29ubmVjdCBwYXRoIOKAlCBhcm0sIHdhbGsgdGhlIGN1cnNvciAod2l0aCB3cmFwKSwgY29tbWl0IHRocm91Z2ggdGhlIHJlYWwgYWRkQ29ubmVjdGlvbiwgY2FuY2VsJywgYXN5bmMgKCkgPT4ge1xuICAgIC8vIE5vIGJvYXJkIHRhcmdldCBuZWVkZWQ6IHRoZSBjb25uZWN0IGFjdGlvbnMgd29yayBpbiBtZW1vcnkgKHRoZSBzZWVkXG4gICAgLy8gYm9hcmQgc3VwcGxpZXMgdGhlIG9iamVjdHMpOyBjb21taXRTYXZlJ3Mgbm8tYm9hcmQgcGF0aCBqdXN0IHRvYXN0cy5cbiAgICByZW5kZXIoPEhhcm5lc3MgLz4pO1xuICAgIGNvbnN0IHdiID0gaGVsZC53YiE7XG4gICAgY29uc3QgZmlyc3QgPSB3Yi5zdGF0ZS5vYmplY3RzWzBdO1xuICAgIGF3YWl0IGFjdChhc3luYyAoKSA9PiB7XG4gICAgICB3Yi5zZWxlY3QoZmlyc3QuaWQpO1xuICAgIH0pO1xuICAgIGF3YWl0IGFjdChhc3luYyAoKSA9PiB7XG4gICAgICB3Yi5iZWdpbkNvbm5lY3QoKTtcbiAgICB9KTtcbiAgICAvLyBBcm1lZDogdGhlIHNvdXJjZSBpcyB0aGUgc2VsZWN0aW9uOyB0aGUgY3Vyc29yIHN0YXJ0cyBvbiBhbm90aGVyIG9iamVjdC5cbiAgICBjb25zdCBzMSA9IGhlbGQud2IhLnN0YXRlO1xuICAgIGV4cGVjdChzMS5jb25uZWN0RnJvbSkudG9CZShmaXJzdC5pZCk7XG4gICAgZXhwZWN0KHMxLmNvbm5lY3RDdXJzb3IpLm5vdC50b0JlKGZpcnN0LmlkKTtcbiAgICBleHBlY3QoczEuY29ubmVjdEN1cnNvcikudG9CZVRydXRoeSgpO1xuICAgIC8vIFRoZSB3YWxrOiBhcnJvd3MgbW92ZSB0aGUgY3Vyc29yIHRocm91Z2ggdGhlIG90aGVyIG9iamVjdHMsIHdyYXBwaW5nIGF0XG4gICAgLy8gYm90aCBlbmRzLCBuZXZlciBsYW5kaW5nIG9uIHRoZSBzb3VyY2UuXG4gICAgY29uc3Qgb3RoZXJzID0gczEub2JqZWN0cy5maWx0ZXIoKG8pID0+IG8uaWQgIT09IGZpcnN0LmlkKS5sZW5ndGg7XG4gICAgYXdhaXQgYWN0KGFzeW5jICgpID0+IHtcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgb3RoZXJzICsgMjsgaSArPSAxKSB3Yi5tb3ZlQ29ubmVjdEN1cnNvcigxKTtcbiAgICB9KTtcbiAgICBleHBlY3QoaGVsZC53YiEuc3RhdGUuY29ubmVjdEN1cnNvcikubm90LnRvQmUoZmlyc3QuaWQpO1xuICAgIGF3YWl0IGFjdChhc3luYyAoKSA9PiB7XG4gICAgICB3Yi5tb3ZlQ29ubmVjdEN1cnNvcigtMSk7XG4gICAgfSk7XG4gICAgZXhwZWN0KGhlbGQud2IhLnN0YXRlLmNvbm5lY3RDdXJzb3IpLm5vdC50b0JlKGZpcnN0LmlkKTtcbiAgICAvLyBDb21taXQ6IHRoZSBlZGdlIGFycml2ZXMgdGhyb3VnaCB0aGUgc2FtZSBzdG9yZSBhY3Rpb24gdGhlIGRyYWcgY2FsbHMuXG4gICAgY29uc3QgdGFyZ2V0ID0gaGVsZC53YiEuc3RhdGUuY29ubmVjdEN1cnNvciE7XG4gICAgY29uc3QgYmVmb3JlID0gaGVsZC53YiEuc3RhdGUub2JqZWN0cy5maW5kKChvKSA9PiBvLmlkID09PSBmaXJzdC5pZCkhLmNvbm5lY3Rpb25zLmxlbmd0aDtcbiAgICBhd2FpdCBhY3QoYXN5bmMgKCkgPT4ge1xuICAgICAgd2IuZW5kQ29ubmVjdCh0cnVlKTtcbiAgICB9KTtcbiAgICBjb25zdCBzcmMgPSBoZWxkLndiIS5zdGF0ZS5vYmplY3RzLmZpbmQoKG8pID0+IG8uaWQgPT09IGZpcnN0LmlkKSE7XG4gICAgZXhwZWN0KHNyYy5jb25uZWN0aW9ucy5zb21lKChjKSA9PiBjLnRvID09PSB0YXJnZXQpKS50b0JlKHRydWUpO1xuICAgIGV4cGVjdChzcmMuY29ubmVjdGlvbnMubGVuZ3RoKS50b0JlKGJlZm9yZSArIDEpO1xuICAgIGV4cGVjdChoZWxkLndiIS5zdGF0ZS5jb25uZWN0RnJvbSkudG9CZU51bGwoKTtcbiAgICAvLyBDYW5jZWwgYWRkcyBub3RoaW5nOiBhcm0gYWdhaW4gb24gdGhlIChzdGlsbC1zZWxlY3RlZCkgc291cmNlIGFuZCBFc2NhcGUuXG4gICAgYXdhaXQgYWN0KGFzeW5jICgpID0+IHtcbiAgICAgIHdiLmJlZ2luQ29ubmVjdCgpO1xuICAgIH0pO1xuICAgIGF3YWl0IGFjdChhc3luYyAoKSA9PiB7XG4gICAgICB3Yi5lbmRDb25uZWN0KGZhbHNlKTtcbiAgICB9KTtcbiAgICBjb25zdCBhZnRlciA9IGhlbGQud2IhLnN0YXRlLm9iamVjdHMuZmluZCgobykgPT4gby5pZCA9PT0gZmlyc3QuaWQpIS5jb25uZWN0aW9ucy5sZW5ndGg7XG4gICAgZXhwZWN0KGFmdGVyKS50b0JlKGJlZm9yZSArIDEpO1xuICAgIGV4cGVjdChoZWxkLndiIS5zdGF0ZS5jb25uZWN0RnJvbSkudG9CZU51bGwoKTtcbiAgfSk7XG5cbiAgaXQoJ2RlbGV0ZVZpZXcgb24gYSByZWFkLW9ubHkgYm9hcmQgcmVmdXNlcyBCRUZPUkUgZHJvcHBpbmcg4oCUIHRoZSByb3cgc3Vydml2ZXMnLCBhc3luYyAoKSA9PiB7XG4gICAgcmVuZGVyKDxIYXJuZXNzIC8+KTtcbiAgICBhd2FpdCBhY3QoYXN5bmMgKCkgPT4ge1xuICAgICAgLy8gQSByZWFkLW9ubHkgYm9hcmQgdGFyZ2V0ICh0aGUgcm8gZ3VhcmQgZmlyZXMgYmVmb3JlIGFueSBzdGF0ZSBjaGFuZ2UpLlxuICAgICAgYXdhaXQgaGVsZC53YiEub3BlbkJvYXJkQXQoeyByb290OiAnL21lbS9ybycsIG1vZGU6ICdybycgfSk7XG4gICAgfSk7XG4gICAgY29uc3QgbmFtZSA9IGhlbGQud2IhLnN0YXRlLnZpZXdzWzBdLm5hbWU7XG4gICAgYXdhaXQgYWN0KGFzeW5jICgpID0+IHtcbiAgICAgIGhlbGQud2IhLmRlbGV0ZVZpZXcobmFtZSk7XG4gICAgfSk7XG4gICAgZXhwZWN0KGhlbGQud2IhLnN0YXRlLnZpZXdzLnNvbWUoKHYpID0+IHYubmFtZSA9PT0gbmFtZSkpLnRvQmUodHJ1ZSk7XG4gICAgZXhwZWN0KGhlbGQud2IhLnN0YXRlLnRvYXN0cy5zb21lKCh0KSA9PiB0LnRleHQuaW5jbHVkZXMoJ1JlYWQtb25seSBib2FyZCcpKSkudG9CZSh0cnVlKTtcbiAgICBleHBlY3QocmVtb3ZlVmlldykubm90LnRvSGF2ZUJlZW5DYWxsZWQoKTtcbiAgfSk7XG5cbiAgaXQoJ2RlbGV0ZVZpZXcgcm9sbHMgdGhlIHJvdyBiYWNrIHdoZW4gdGhlIGZpbGUgcmVtb3ZhbCBmYWlscycsIGFzeW5jICgpID0+IHtcbiAgICByZW5kZXIoPEhhcm5lc3MgLz4pO1xuICAgIGF3YWl0IGFjdChhc3luYyAoKSA9PiB7XG4gICAgICBhd2FpdCBoZWxkLndiIS5vcGVuQm9hcmRBdCh7IHJvb3Q6ICcvbWVtL2JvYXJkJywgbW9kZTogJ3J3JyB9KTtcbiAgICB9KTtcbiAgICBjb25zdCBuYW1lID0gaGVsZC53YiEuc3RhdGUudmlld3NbMF0ubmFtZTtcbiAgICB2aS5tb2NrZWQocmVtb3ZlVmlldykubW9ja1JlamVjdGVkVmFsdWVPbmNlKE9iamVjdC5hc3NpZ24obmV3IEVycm9yKCdFUk9GUycpLCB7IGNvZGU6ICdFUk9GUycgfSkpO1xuICAgIGF3YWl0IGFjdChhc3luYyAoKSA9PiB7XG4gICAgICBoZWxkLndiIS5kZWxldGVWaWV3KG5hbWUpO1xuICAgIH0pO1xuICAgIGV4cGVjdChoZWxkLndiIS5zdGF0ZS52aWV3cy5zb21lKCh2KSA9PiB2Lm5hbWUgPT09IG5hbWUpKS50b0JlKHRydWUpO1xuICAgIGV4cGVjdChoZWxkLndiIS5zdGF0ZS50b2FzdHMuc29tZSgodCkgPT4gdC50ZXh0LmluY2x1ZGVzKCdyZW1vdmUgdmlldycpKSkudG9CZSh0cnVlKTtcbiAgfSk7XG59KTtcblxuLy8g4pSA4pSAIFVSTC1kaXNwYXRjaGVkIGNvcnB1cyBib2FyZCAoUjMtODMxKSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbi8vIEEgY29sZCBVUkwgbG9hZCBpbnRvIGEgcmVwbyB3aG9zZSBtYXJrZXIgbmFtZXMgb3Blbi1wcm9qZWN0IGRpc3BhdGNoZXMgdG8gdXNcbi8vIGFzIHRoZSBib3VuZCB2aWV3ZXIgd2l0aCBOTyB0YXNrIGlucHV0OyB0aGUgaG9zdCBtYXJrcyB0aGUgbG9hZGVkIHJlcG8gYXMgYVxuLy8gYHR5cGU6ICdjb250ZW50J2AgbW91bnQgYXZhaWxhYmxlIGF0IGJvb3QuIFRoYXQgbW91bnQgaXMgdGhlIHByb2plY3Qg4oCUIHRoZVxuLy8gYm9hcmQgbG9hZHMgZnJvbSBpdCwgYW5kIHRoZSBkdXJhYmxlIHBhdGggbmV2ZXIgb3BlbnMuXG5kZXNjcmliZSgnVVJMLWRpc3BhdGNoZWQgY29ycHVzIGJvYXJkIChSMy04MzEpJywgKCkgPT4ge1xuICBiZWZvcmVFYWNoKCgpID0+IHtcbiAgICAvLyBDYWxsIGNvdW50cyBhY2N1bXVsYXRlIGFjcm9zcyB0aGUgZmlsZSdzIGVhcmxpZXIgY2FzZXMgKG1vZHVsZS1sZXZlbFxuICAgIC8vIG1vY2tzKTsgbW9ja1Jlc2V0IGRyb3BzIHRoZSBvbmNlLXF1ZXVlIHRvbywgc28gYW4gdW5jb25zdW1lZCBxdWV1ZWRcbiAgICAvLyByZWplY3Rpb24gY2Fubm90IGxlYWsgb25lIGNhc2UgZm9yd2FyZCwgYW5kIHJlc3RvcmVzIHRoZSByZWFsLWZ1bmN0aW9uXG4gICAgLy8gYmFzZWxpbmUgZWFjaCBvZiB0aGVzZSBtb2NrcyB3YXMgYnVpbHQgb24uXG4gICAgdmkubW9ja2VkKGxvYWRCb2FyZCkubW9ja1Jlc2V0KCk7XG4gICAgdmkubW9ja2VkKG9wZW5Cb2FyZFRhcmdldCkubW9ja1Jlc2V0KCk7XG4gICAgdmkubW9ja2VkKGJvYXJkRXhpc3RzKS5tb2NrUmVzZXQoKTtcbiAgfSk7XG4gIGNvbnN0IENPUlBVUzogU2FuZGJveE1vdW50ID0ge1xuICAgIHBhdGg6ICcvbW50L2NvcnB1cycsXG4gICAgdHlwZTogJ2NvbnRlbnQnLFxuICAgIGlkOiAnY29udGVudDppbW1lZGlhdGVseS1ydW4vbG9kZXN0YXItc2FtcGxlLXByb2plY3QnLFxuICAgIG1vZGU6ICdybycsXG4gIH07XG4gIGNvbnN0IE5PVEU6IFdPYmplY3QgPSB7XG4gICAgaWQ6ICdub3RlLXdlbGNvbWUnLFxuICAgIGtpbmQ6ICdub3RlJyxcbiAgICB4OiAwLFxuICAgIHk6IDAsXG4gICAgdzogMjAwLFxuICAgIGg6IDE0OCxcbiAgICByb3Q6IDAsXG4gICAgc2NhbGU6IDEsXG4gICAgejogMyxcbiAgICBjb25uZWN0aW9uczogW10sXG4gICAgdGl0bGU6ICdXZWxjb21lJyxcbiAgfTtcblxuICBpdCgnY29ycHVzTW91bnQga2V5cyBvbiB0aGUgaG9zdCBtYXJrIChgdHlwZTogY29udGVudGApLCBuZXZlciBvbiB0aGUgb25seSBmb3JlaWduIG1vdW50JywgKCkgPT4ge1xuICAgIGV4cGVjdChjb3JwdXNNb3VudChbXSkpLnRvQmVOdWxsKCk7XG4gICAgLy8gQSBoZWxkIHNwYWNlIGlzIGZvcmVpZ24gdG9vIOKAlCBrZXlpbmcgb24gXCJ0aGUgb25seSBmb3JlaWduIG1vdW50XCIgd291bGRcbiAgICAvLyBvcGVuIHRoZSB3cm9uZyBib2FyZCB0aGUgbW9tZW50IGEgc3BhY2UgaXMgaGVsZC5cbiAgICBleHBlY3QoY29ycHVzTW91bnQoW3sgcGF0aDogJy9zcGFjZXMveCcsIHR5cGU6ICdmaXJlc3RvcmUnLCBpZDogJ3NwYWNlLTEnLCBtb2RlOiAncncnIH1dKSkudG9CZU51bGwoKTtcbiAgICBleHBlY3QoY29ycHVzTW91bnQoW0NPUlBVU10pKS50b0JlKENPUlBVUyk7XG4gIH0pO1xuXG4gIGl0KCd3aXRoIG5vIHRhc2sgaW5wdXQsIGEgY29ycHVzIG1vdW50IElTIHRoZSBwcm9qZWN0IOKAlCB0aGUgYm9hcmQgbG9hZHMgZnJvbSBpdCwgY2hyb290ZWQgYXMgbW91bnRlZCcsIGFzeW5jICgpID0+IHtcbiAgICBtb3VudHNIZWxkLmxpc3QgPSBbQ09SUFVTXTtcbiAgICB2aS5tb2NrZWQoYm9hcmRFeGlzdHMpLm1vY2tSZXNvbHZlZFZhbHVlT25jZSh0cnVlKTtcbiAgICB2aS5tb2NrZWQobG9hZEJvYXJkKS5tb2NrUmVzb2x2ZWRWYWx1ZU9uY2Uoe1xuICAgICAgb2JqZWN0czogW05PVEVdLFxuICAgICAgdmlld3M6IFtdLFxuICAgICAgam91cm5leXM6IFtdLFxuICAgICAgdGl0bGU6ICdTYW1wbGUgcHJvamVjdCcsXG4gICAgfSk7XG4gICAgLy8gVGhlIGR1cmFibGUgc3BhY2UgbXVzdCBuZXZlciBvcGVuOiB0aGUgVVJMIG5hbWVkIFRISVMgcHJvamVjdCwgc28gaXRzXG4gICAgLy8gb3duIGJvYXJkIOKAlCBub3QgdGhlIHVzZXIncyBzcGFjZSwgbm90IHRoZSBkZW1vIHNlZWQg4oCUIGlzIHdoYXQgc2hvd3MuXG4gICAgdmkubW9ja2VkKG9wZW5Cb2FyZFRhcmdldCkubW9ja1JlamVjdGVkVmFsdWVPbmNlKG5ldyBFcnJvcignZHVyYWJsZSBzcGFjZSBtdXN0IG5vdCBvcGVuJykpO1xuICAgIHJlbmRlcig8SGFybmVzcyAvPik7XG4gICAgYXdhaXQgYWN0KGFzeW5jICgpID0+IHtcbiAgICAgIGF3YWl0IG5ldyBQcm9taXNlKChyKSA9PiBzZXRUaW1lb3V0KHIsIDApKTsgLy8gbGV0IHRoZSBib290IGNoYWluIHNldHRsZVxuICAgIH0pO1xuICAgIGV4cGVjdChsb2FkQm9hcmQpLnRvSGF2ZUJlZW5DYWxsZWRXaXRoKHsgcm9vdDogJy9tbnQvY29ycHVzJywgbW9kZTogJ3JvJywgc3BhY2VJZDogQ09SUFVTLmlkIH0pO1xuICAgIC8vIFRoZSBkdXJhYmxlIHNwYWNlIG11c3QgbmV2ZXIgb3BlbiDigJQgYXNzZXJ0ZWQsIG5vdCBxdWV1ZWQ6IHRoZSBtb2NrJ3NcbiAgICAvLyByZWplY3Rpb24gYWJvdmUgaXMgc3dhbGxvd2VkIGJ5IHRoZSBkdXJhYmxlIHBhdGgncyBvd24gY2F0Y2gsIHNvIG9ubHlcbiAgICAvLyB0aGlzIGNhbGwtY291bnQgYXNzZXJ0aW9uIGhvbGRzIHRoZSBuYW1lZCBndWFyYW50ZWUuXG4gICAgZXhwZWN0KG9wZW5Cb2FyZFRhcmdldCkubm90LnRvSGF2ZUJlZW5DYWxsZWQoKTtcbiAgICBleHBlY3QoaGVsZC53YiEuc3RhdGUudGl0bGUpLnRvQmUoJ1NhbXBsZSBwcm9qZWN0Jyk7XG4gICAgZXhwZWN0KGhlbGQud2IhLnN0YXRlLm9iamVjdHMpLnRvSGF2ZUxlbmd0aCgxKTtcbiAgICBleHBlY3QoaGVsZC53YiEuc3RhdGUub2JqZWN0c1swXS5pZCkudG9CZSgnbm90ZS13ZWxjb21lJyk7XG4gIH0pO1xuXG4gIGl0KCdhIGNvcnB1cyBtb3VudCB3aG9zZSBib2FyZCBmYWlscyB0byBsb2FkIHJlcG9ydHMgYW5kIGZhbGxzIHRocm91Z2ggdG8gdGhlIGR1cmFibGUgcGF0aCcsIGFzeW5jICgpID0+IHtcbiAgICBtb3VudHNIZWxkLmxpc3QgPSBbQ09SUFVTXTtcbiAgICB2aS5tb2NrZWQoYm9hcmRFeGlzdHMpLm1vY2tSZXNvbHZlZFZhbHVlT25jZSh0cnVlKTtcbiAgICB2aS5tb2NrZWQobG9hZEJvYXJkKS5tb2NrUmVqZWN0ZWRWYWx1ZU9uY2UoT2JqZWN0LmFzc2lnbihuZXcgRXJyb3IoJ0VST0ZTJyksIHsgY29kZTogJ0VST0ZTJyB9KSk7XG4gICAgdmkubW9ja2VkKG9wZW5Cb2FyZFRhcmdldCkubW9ja1JlamVjdGVkVmFsdWVPbmNlKE9iamVjdC5hc3NpZ24obmV3IEVycm9yKCdhdXRoLXJlcXVpcmVkJyksIHsgY29kZTogJ2F1dGgtcmVxdWlyZWQnIH0pKTtcbiAgICByZW5kZXIoPEhhcm5lc3MgLz4pO1xuICAgIGF3YWl0IGFjdChhc3luYyAoKSA9PiB7XG4gICAgICBhd2FpdCBuZXcgUHJvbWlzZSgocikgPT4gc2V0VGltZW91dChyLCAwKSk7XG4gICAgfSk7XG4gICAgZXhwZWN0KGxvYWRCb2FyZCkudG9IYXZlQmVlbkNhbGxlZFRpbWVzKDEpO1xuICAgIC8vIFRoZSBmYWlsZWQgbG9hZCBmZWxsIHRocm91Z2g6IHRoZSBkdXJhYmxlIHBhdGggb3BlbmVkIChhbmQgaGVyZSxcbiAgICAvLyBzaWduZWQtb3V0LCBkZWdyYWRlZCB0byB0aGUgaW4tbWVtb3J5IHNlZWQg4oCUIHRvZGF5J3MgYmVoYXZpb3IpLlxuICAgIGV4cGVjdChvcGVuQm9hcmRUYXJnZXQpLnRvSGF2ZUJlZW5DYWxsZWRUaW1lcygxKTtcbiAgICBleHBlY3QoaGVsZC53YiEuc3RhdGUudG9hc3RzLnNvbWUoKHQpID0+IHQudGV4dC5pbmNsdWRlcygnQ291bGRu4oCZdCBvcGVuIHByb2plY3QnKSkpLnRvQmUodHJ1ZSk7XG4gIH0pO1xuXG4gIGl0KCdhIGNvcnB1cyBtb3VudCB3aXRoIG5vIGJvYXJkIGZpbGVzIGZhbGxzIHRocm91Z2ggdG8gdGhlIGR1cmFibGUgcGF0aCB1bmNoYW5nZWQnLCBhc3luYyAoKSA9PiB7XG4gICAgbW91bnRzSGVsZC5saXN0ID0gW0NPUlBVU107XG4gICAgdmkubW9ja2VkKGJvYXJkRXhpc3RzKS5tb2NrUmVzb2x2ZWRWYWx1ZU9uY2UoZmFsc2UpO1xuICAgIHZpLm1vY2tlZChvcGVuQm9hcmRUYXJnZXQpLm1vY2tSZWplY3RlZFZhbHVlT25jZShPYmplY3QuYXNzaWduKG5ldyBFcnJvcignYXV0aC1yZXF1aXJlZCcpLCB7IGNvZGU6ICdhdXRoLXJlcXVpcmVkJyB9KSk7XG4gICAgcmVuZGVyKDxIYXJuZXNzIC8+KTtcbiAgICBhd2FpdCBhY3QoYXN5bmMgKCkgPT4ge1xuICAgICAgLy8gTm8gY29ycHVzOiB0aGUgYm91bmRlZCBwb2xsIHBheXMgaXRzIGZ1bGwgd2luZG93IGJlZm9yZSB0aGUgZHVyYWJsZSBwYXRoLlxuICAgICAgYXdhaXQgbmV3IFByb21pc2UoKHIpID0+IHNldFRpbWVvdXQociwgQ09SUFVTX1BPTExfVFJJRVMgKiBDT1JQVVNfUE9MTF9JTlRFUlZBTF9NUyArIDMwMCkpO1xuICAgIH0pO1xuICAgIGV4cGVjdChsb2FkQm9hcmQpLm5vdC50b0hhdmVCZWVuQ2FsbGVkKCk7XG4gICAgZXhwZWN0KG9wZW5Cb2FyZFRhcmdldCkudG9IYXZlQmVlbkNhbGxlZFRpbWVzKDEpO1xuICB9KTtcblxuICBpdCgnYW4gdW5tb3VudGVkIGNoYWluIHN0b3BzIGJlZm9yZSB0aGUgZHVyYWJsZSBwYXRoIOKAlCB0aGUgY2FuY2VsbGVkIGd1YXJkLCBubyBsZWFrZWQgYm9hcmQtc3BhY2Ugb3BlbicsIGFzeW5jICgpID0+IHtcbiAgICAvLyBObyBjb3JwdXM6IHRoZSBwb2xsIGlzIHBlbmRpbmcgbWlkLWZsaWdodCB3aGVuIHRoZSBjb21wb25lbnQgdW5tb3VudHMgKGFcbiAgICAvLyBtaWQtYm9vdCBuYXZpZ2F0aW9uKS4gV2l0aG91dCB0aGUgY2FuY2VsbGVkIGd1YXJkIHRoZSBkdXJhYmxlIHBhdGggd291bGRcbiAgICAvLyBzdGlsbCBvcGVuIHRoZSB1c2VyJ3MgYm9hcmQgc3BhY2UgZnJvbSBhIGdvbmUgYXBwLlxuICAgIGNvbnN0IHsgdW5tb3VudCB9ID0gcmVuZGVyKDxIYXJuZXNzIC8+KTtcbiAgICBhd2FpdCBhY3QoYXN5bmMgKCkgPT4ge1xuICAgICAgYXdhaXQgbmV3IFByb21pc2UoKHIpID0+IHNldFRpbWVvdXQociwgMiAqIENPUlBVU19QT0xMX0lOVEVSVkFMX01TKSk7IC8vIG1pZC1wb2xsXG4gICAgfSk7XG4gICAgdW5tb3VudCgpO1xuICAgIGF3YWl0IGFjdChhc3luYyAoKSA9PiB7XG4gICAgICBhd2FpdCBuZXcgUHJvbWlzZSgocikgPT4gc2V0VGltZW91dChyLCBDT1JQVVNfUE9MTF9UUklFUyAqIENPUlBVU19QT0xMX0lOVEVSVkFMX01TICsgMzAwKSk7XG4gICAgfSk7XG4gICAgZXhwZWN0KGxvYWRCb2FyZCkubm90LnRvSGF2ZUJlZW5DYWxsZWQoKTtcbiAgICBleHBlY3Qob3BlbkJvYXJkVGFyZ2V0KS5ub3QudG9IYXZlQmVlbkNhbGxlZCgpO1xuICB9KTtcblxuICBpdCgnd2l0aCBubyBjb3JwdXMgbW91bnQgYW5kIG5vIHRhc2sgaW5wdXQsIHRoZSBkdXJhYmxlIHBhdGggYW5zd2VycyBleGFjdGx5IGFzIGJlZm9yZScsIGFzeW5jICgpID0+IHtcbiAgICBtb3VudHNIZWxkLmxpc3QgPSBbXTtcbiAgICB2aS5tb2NrZWQob3BlbkJvYXJkVGFyZ2V0KS5tb2NrUmVqZWN0ZWRWYWx1ZU9uY2UoT2JqZWN0LmFzc2lnbihuZXcgRXJyb3IoJ2F1dGgtcmVxdWlyZWQnKSwgeyBjb2RlOiAnYXV0aC1yZXF1aXJlZCcgfSkpO1xuICAgIHJlbmRlcig8SGFybmVzcyAvPik7XG4gICAgYXdhaXQgYWN0KGFzeW5jICgpID0+IHtcbiAgICAgIC8vIE5vIGNvcnB1czogdGhlIGJvdW5kZWQgcG9sbCBwYXlzIGl0cyBmdWxsIHdpbmRvdyBiZWZvcmUgdGhlIGR1cmFibGUgcGF0aC5cbiAgICAgIGF3YWl0IG5ldyBQcm9taXNlKChyKSA9PiBzZXRUaW1lb3V0KHIsIENPUlBVU19QT0xMX1RSSUVTICogQ09SUFVTX1BPTExfSU5URVJWQUxfTVMgKyAzMDApKTtcbiAgICB9KTtcbiAgICBleHBlY3QobG9hZEJvYXJkKS5ub3QudG9IYXZlQmVlbkNhbGxlZCgpO1xuICAgIGV4cGVjdChvcGVuQm9hcmRUYXJnZXQpLnRvSGF2ZUJlZW5DYWxsZWRUaW1lcygxKTtcbiAgICAvLyBTaWduZWQgb3V0OiB0aGUgaW4tbWVtb3J5IHNlZWQgc3RheXMg4oCUIHRoZSBkZW1vIGJvYXJkLCB0b2RheSdzIGJlaGF2aW9yLlxuICAgIGV4cGVjdChoZWxkLndiIS5zdGF0ZS5vYmplY3RzLmxlbmd0aCkudG9CZUdyZWF0ZXJUaGFuKDApO1xuICB9KTtcblxuICBpdCgnYSBjb3JwdXMgbW91bnQgdGhhdCBhcnJpdmVzIGxhdGUgKHRoZSBtb3VudCBtaXJyb3JcXCdzIGFzeW5jIHJlcGxheSkgaXMgc3RpbGwgZm91bmQg4oCUIHRoZSBpbnRlcm1pdHRlbnQgcmFjZSwgcGlubmVkJywgYXN5bmMgKCkgPT4ge1xuICAgIC8vIFRoZSBTREsncyBtb3VudCBtaXJyb3IgcG9wdWxhdGVzIGZyb20gdGhlIGhvc3QncyBtb3VudC1hZGQgcmUtYW5ub3VuY2VtZW50LFxuICAgIC8vIGFzeW5jaHJvbm91c2x5IHJlbGF0aXZlIHRvIHRoZSBib290IGVmZmVjdDogYSBvbmUtc2hvdCByZWFkIGludGVybWl0dGVudGx5XG4gICAgLy8gbWlzc2VkIHRoZSBjb3JwdXMgYW5kIGJvb3RlZCB0aGUgZGVtbyBib2FyZCBpbnN0ZWFkIChmb3VuZCBsaXZlIG9uIHRoZVxuICAgIC8vIHZlbnVlLCAyMDI2LTEwLTAzKS4gVGhlIG1vdW50IGFwcGVhcnMgfjE1MG1zIGFmdGVyIGJvb3QgaGVyZSDigJQgYWZ0ZXIgdGhlXG4gICAgLy8gZmlyc3QgcmVhZCwgaW5zaWRlIHRoZSBib3VuZGVkIHBvbGwuXG4gICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICBtb3VudHNIZWxkLmxpc3QgPSBbQ09SUFVTXTtcbiAgICB9LCAxNTApO1xuICAgIHZpLm1vY2tlZChib2FyZEV4aXN0cykubW9ja1Jlc29sdmVkVmFsdWVPbmNlKHRydWUpO1xuICAgIHZpLm1vY2tlZChsb2FkQm9hcmQpLm1vY2tSZXNvbHZlZFZhbHVlT25jZSh7XG4gICAgICBvYmplY3RzOiBbTk9URV0sXG4gICAgICB2aWV3czogW10sXG4gICAgICBqb3VybmV5czogW10sXG4gICAgICB0aXRsZTogJ1NhbXBsZSBwcm9qZWN0JyxcbiAgICB9KTtcbiAgICB2aS5tb2NrZWQob3BlbkJvYXJkVGFyZ2V0KS5tb2NrUmVqZWN0ZWRWYWx1ZU9uY2UobmV3IEVycm9yKCdkdXJhYmxlIHNwYWNlIG11c3Qgbm90IG9wZW4nKSk7XG4gICAgcmVuZGVyKDxIYXJuZXNzIC8+KTtcbiAgICBhd2FpdCBhY3QoYXN5bmMgKCkgPT4ge1xuICAgICAgLy8gVGhlIG1vdW50IGFycml2ZXMgfjE1MG1zIGFmdGVyIGJvb3Q7IHRoZSBwb2xsJ3Mgd2luZG93IGlzIGFtcGxlIOKAlFxuICAgICAgLy8gZGVyaXZlZCBmcm9tIHRoZSBuYW1lZCBib3VuZCwgbm90IGEgcHJpdmF0ZSBoZWFkcm9vbSBvdmVyIGl0LlxuICAgICAgYXdhaXQgbmV3IFByb21pc2UoKHIpID0+IHNldFRpbWVvdXQociwgQ09SUFVTX1BPTExfVFJJRVMgKiBDT1JQVVNfUE9MTF9JTlRFUlZBTF9NUykpO1xuICAgIH0pO1xuICAgIGV4cGVjdChsb2FkQm9hcmQpLnRvSGF2ZUJlZW5DYWxsZWRXaXRoKHsgcm9vdDogJy9tbnQvY29ycHVzJywgbW9kZTogJ3JvJywgc3BhY2VJZDogQ09SUFVTLmlkIH0pO1xuICAgIGV4cGVjdChvcGVuQm9hcmRUYXJnZXQpLm5vdC50b0hhdmVCZWVuQ2FsbGVkKCk7XG4gICAgZXhwZWN0KGhlbGQud2IhLnN0YXRlLnRpdGxlKS50b0JlKCdTYW1wbGUgcHJvamVjdCcpO1xuICB9KTtcblxuICBpdCgnYSBjb3JwdXMgbW91bnQgYXJyaXZpbmcgQUZURVIgdW5tb3VudCBpcyBuZXZlciBsb2FkZWQg4oCUIHRoZSBwb2xsXFwncyBjYW5jZWxsZWQgcmV0dXJuLCBwaW5uZWQnLCBhc3luYyAoKSA9PiB7XG4gICAgLy8gVGhlIHBvbGwncyBpc0NhbmNlbGxlZCBlYXJseS1yZXR1cm4gaXMgdGhlIG9ubHkgZ3VhcmQgb24gdGhlIGNvcnB1cyBzaWRlOlxuICAgIC8vIGEgbW91bnQgYXJyaXZpbmcgYWZ0ZXIgdGhlIGNvbXBvbmVudCB1bm1vdW50ZWQgd291bGQgb3RoZXJ3aXNlIGxvYWQgYVxuICAgIC8vIGJvYXJkIGludG8gYSBnb25lIGFwcCAocHJvYmUtdmVyaWZpZWQgYnkgcmV2aWV3IHJvdW5kIDI6IHdpdGggdGhlIGNoZWNrXG4gICAgLy8gZGVsZXRlZCwgdGhpcyBjYXNlIGlzIHRoZSBvbmUgdGhhdCBmYWlscykuXG4gICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICBtb3VudHNIZWxkLmxpc3QgPSBbQ09SUFVTXTtcbiAgICB9LCA2ICogQ09SUFVTX1BPTExfSU5URVJWQUxfTVMpOyAvLyBhZnRlciB0aGUgdW5tb3VudCBiZWxvdywgaW5zaWRlIHRoZSB3aW5kb3dcbiAgICB2aS5tb2NrZWQoYm9hcmRFeGlzdHMpLm1vY2tSZXNvbHZlZFZhbHVlT25jZSh0cnVlKTtcbiAgICB2aS5tb2NrZWQobG9hZEJvYXJkKS5tb2NrUmVzb2x2ZWRWYWx1ZU9uY2UoeyBvYmplY3RzOiBbTk9URV0sIHZpZXdzOiBbXSwgam91cm5leXM6IFtdLCB0aXRsZTogJ1NhbXBsZSBwcm9qZWN0JyB9KTtcbiAgICBjb25zdCB7IHVubW91bnQgfSA9IHJlbmRlcig8SGFybmVzcyAvPik7XG4gICAgYXdhaXQgYWN0KGFzeW5jICgpID0+IHtcbiAgICAgIGF3YWl0IG5ldyBQcm9taXNlKChyKSA9PiBzZXRUaW1lb3V0KHIsIDIgKiBDT1JQVVNfUE9MTF9JTlRFUlZBTF9NUykpOyAvLyBtaWQtcG9sbCwgYmVmb3JlIHRoZSBhcnJpdmFsXG4gICAgfSk7XG4gICAgdW5tb3VudCgpO1xuICAgIGF3YWl0IGFjdChhc3luYyAoKSA9PiB7XG4gICAgICBhd2FpdCBuZXcgUHJvbWlzZSgocikgPT4gc2V0VGltZW91dChyLCBDT1JQVVNfUE9MTF9UUklFUyAqIENPUlBVU19QT0xMX0lOVEVSVkFMX01TICsgMzAwKSk7XG4gICAgfSk7XG4gICAgZXhwZWN0KGxvYWRCb2FyZCkubm90LnRvSGF2ZUJlZW5DYWxsZWQoKTtcbiAgICBleHBlY3Qob3BlbkJvYXJkVGFyZ2V0KS5ub3QudG9IYXZlQmVlbkNhbGxlZCgpO1xuICB9KTtcblxuICBpdCgnYSB0aHJvd2luZyBtb3VudHMgcmVhZCAobm8gaG9zdCwgbG9jYWwgdml0ZSBkZXYpIHNraXBzIHRoZSBjb3JwdXMgcGF0aCBhbmQgdGhlIGR1cmFibGUgcGF0aCBhbnN3ZXJzIGV4YWN0bHknLCBhc3luYyAoKSA9PiB7XG4gICAgbW91bnRzSGVsZC50aHJvd3MgPSB0cnVlO1xuICAgIHZpLm1vY2tlZChvcGVuQm9hcmRUYXJnZXQpLm1vY2tSZWplY3RlZFZhbHVlT25jZShPYmplY3QuYXNzaWduKG5ldyBFcnJvcignYXV0aC1yZXF1aXJlZCcpLCB7IGNvZGU6ICdhdXRoLXJlcXVpcmVkJyB9KSk7XG4gICAgcmVuZGVyKDxIYXJuZXNzIC8+KTtcbiAgICBhd2FpdCBhY3QoYXN5bmMgKCkgPT4ge1xuICAgICAgYXdhaXQgbmV3IFByb21pc2UoKHIpID0+IHNldFRpbWVvdXQociwgMCkpO1xuICAgIH0pO1xuICAgIC8vIFRoZSBjb3JwdXMgcmVhZCdzIGNhdGNoIGlzIHRoZSBicmFuY2ggdGhhdCBrZWVwcyBldmVyeSBsb2NhbCBuby1ob3N0IGJvb3RcbiAgICAvLyBvbiB0aGUgZHVyYWJsZSBwYXRoOiBubyBjb3JwdXMgdG9hc3QsIG5vIGxvYWRCb2FyZCwgdGhlIGR1cmFibGUgYW5zd2VyLlxuICAgIGV4cGVjdChsb2FkQm9hcmQpLm5vdC50b0hhdmVCZWVuQ2FsbGVkKCk7XG4gICAgZXhwZWN0KG9wZW5Cb2FyZFRhcmdldCkudG9IYXZlQmVlbkNhbGxlZFRpbWVzKDEpO1xuICAgIGV4cGVjdChoZWxkLndiIS5zdGF0ZS50b2FzdHMuc29tZSgodCkgPT4gdC50ZXh0LmluY2x1ZGVzKCdDb3VsZG7igJl0IG9wZW4gcHJvamVjdCcpKSkudG9CZShmYWxzZSk7XG4gICAgZXhwZWN0KGhlbGQud2IhLnN0YXRlLm9iamVjdHMubGVuZ3RoKS50b0JlR3JlYXRlclRoYW4oMCk7XG4gIH0pO1xufSk7XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUtBLElBQUFBLE1BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLE9BQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLE9BQUEsR0FBQUYsT0FBQTtBQThDQSxJQUFBRyxZQUFBLEdBQUFILE9BQUE7QUFDQSxJQUFBSSxXQUFBLEdBQUFKLE9BQUE7QUFDQSxJQUFBSyxZQUFBLEdBQUFMLE9BQUE7QUFBNkYsSUFBQU0sV0FBQSxHQUFBTixPQUFBO0FBQUEsSUFBQU8sRUFBQSxHQUFBQyxZQUFBLElBdkQ3RjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQUEsU0FBQUMseUJBQUFDLENBQUEsNkJBQUFDLE9BQUEsbUJBQUFDLENBQUEsT0FBQUQsT0FBQSxJQUFBRSxDQUFBLE9BQUFGLE9BQUEsWUFBQUYsd0JBQUEsWUFBQUEsQ0FBQUMsQ0FBQSxXQUFBQSxDQUFBLEdBQUFHLENBQUEsR0FBQUQsQ0FBQSxLQUFBRixDQUFBO0FBQUEsU0FBQUksd0JBQUFKLENBQUEsRUFBQUUsQ0FBQSxTQUFBQSxDQUFBLElBQUFGLENBQUEsSUFBQUEsQ0FBQSxDQUFBSyxVQUFBLFNBQUFMLENBQUEsZUFBQUEsQ0FBQSx1QkFBQUEsQ0FBQSx5QkFBQUEsQ0FBQSxXQUFBTSxPQUFBLEVBQUFOLENBQUEsUUFBQUcsQ0FBQSxHQUFBSix3QkFBQSxDQUFBRyxDQUFBLE9BQUFDLENBQUEsSUFBQUEsQ0FBQSxDQUFBSSxHQUFBLENBQUFQLENBQUEsVUFBQUcsQ0FBQSxDQUFBSyxHQUFBLENBQUFSLENBQUEsT0FBQVMsQ0FBQSxLQUFBQyxTQUFBLFVBQUFDLENBQUEsR0FBQUMsTUFBQSxDQUFBQyxjQUFBLElBQUFELE1BQUEsQ0FBQUUsd0JBQUEsV0FBQUMsQ0FBQSxJQUFBZixDQUFBLG9CQUFBZSxDQUFBLE9BQUFDLGNBQUEsQ0FBQUMsSUFBQSxDQUFBakIsQ0FBQSxFQUFBZSxDQUFBLFNBQUFHLENBQUEsR0FBQVAsQ0FBQSxHQUFBQyxNQUFBLENBQUFFLHdCQUFBLENBQUFkLENBQUEsRUFBQWUsQ0FBQSxVQUFBRyxDQUFBLEtBQUFBLENBQUEsQ0FBQVYsR0FBQSxJQUFBVSxDQUFBLENBQUFDLEdBQUEsSUFBQVAsTUFBQSxDQUFBQyxjQUFBLENBQUFKLENBQUEsRUFBQU0sQ0FBQSxFQUFBRyxDQUFBLElBQUFULENBQUEsQ0FBQU0sQ0FBQSxJQUFBZixDQUFBLENBQUFlLENBQUEsWUFBQU4sQ0FBQSxDQUFBSCxPQUFBLEdBQUFOLENBQUEsRUFBQUcsQ0FBQSxJQUFBQSxDQUFBLENBQUFnQixHQUFBLENBQUFuQixDQUFBLEVBQUFTLENBQUEsR0FBQUEsQ0FBQTtBQU1BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNVyxVQUFVLEdBQUc7RUFBRUMsSUFBSSxFQUFFLEVBQW9CO0VBQUVDLE1BQU0sRUFBRTtBQUFNLENBQUM7QUFDaEVDLFVBQUUsQ0FBQ0MsSUFBSSxDQUFDLDZCQUE2QixFQUFFLE9BQU87RUFDNUNDLFNBQVMsRUFBRUEsQ0FBQSxLQUFNO0lBQ2YsSUFBSUwsVUFBVSxDQUFDRSxNQUFNLEVBQUUsTUFBTSxJQUFJSSxLQUFLLENBQUMsbUJBQW1CLENBQUM7SUFDM0QsT0FBT04sVUFBVSxDQUFDQyxJQUFJO0VBQ3hCLENBQUM7RUFDRE0sY0FBYyxFQUFFQSxDQUFBLEtBQU0sTUFBTSxDQUFDLENBQUM7RUFDOUJDLFlBQVksRUFBRSxNQUFBQSxDQUFBLEtBQVk7SUFDeEIsTUFBTSxJQUFJRixLQUFLLENBQUMsbUJBQW1CLENBQUM7RUFDdEM7QUFDRixDQUFDLENBQUMsQ0FBQzs7QUFFSDtBQUNBO0FBQ0EsSUFBSUcsVUFBc0QsR0FBRyxJQUFJO0FBQ2pFTixVQUFFLENBQUNDLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxPQUFPO0VBQ2hDTSxRQUFRLEVBQUVBLENBQUEsS0FBTUQsVUFBVTtFQUMxQkUsY0FBYyxFQUFFLE1BQUFBLENBQUEsS0FBWSxZQUFZO0VBQ3hDQyxZQUFZLEVBQUUsTUFBQUEsQ0FBQSxLQUFZLElBQUk7RUFDOUJDLE9BQU8sRUFBR0MsQ0FBUyxJQUFLQTtBQUMxQixDQUFDLENBQUMsQ0FBQzs7QUFFSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0FYLFVBQUUsQ0FBQ0MsSUFBSSxDQUFDLG1CQUFtQixFQUFFLE1BQU9XLGNBQWMsSUFBSztFQUNyRCxNQUFNQyxJQUFJLEdBQUcsTUFBTUQsY0FBYyxDQUFxQyxDQUFDO0VBQ3ZFLE9BQU87SUFDTCxHQUFHQyxJQUFJO0lBQ1BDLFVBQVUsRUFBRWQsVUFBRSxDQUFDZSxFQUFFLENBQUMsWUFBWUMsU0FBUyxDQUFDO0lBQ3hDQyxXQUFXLEVBQUVqQixVQUFFLENBQUNlLEVBQUUsQ0FBQ0YsSUFBSSxDQUFDSSxXQUFXLENBQUM7SUFDcENDLFNBQVMsRUFBRWxCLFVBQUUsQ0FBQ2UsRUFBRSxDQUFDRixJQUFJLENBQUNLLFNBQVMsQ0FBQztJQUNoQ0MsZUFBZSxFQUFFbkIsVUFBRSxDQUFDZSxFQUFFLENBQUNGLElBQUksQ0FBQ00sZUFBZTtFQUM3QyxDQUFDO0FBQ0gsQ0FBQyxDQUFDO0FBT0Y7QUFDQTtBQUNBLE1BQU1DLElBQUksR0FBRztFQUFFQyxFQUFFLEVBQUU7QUFBOEMsQ0FBQztBQUNsRSxTQUFTQyxPQUFPQSxDQUFBLEVBQUc7RUFBQWhELEVBQUE7RUFDakIsTUFBTWlELFVBQVUsR0FBRyxJQUFBQyx3QkFBVyxFQUFDLENBQUM7RUFDaEM7RUFDQTtFQUNBLElBQUFDLGlCQUFTLEVBQUMsTUFBTTtJQUNkTCxJQUFJLENBQUNDLEVBQUUsR0FBR0UsVUFBVTtFQUN0QixDQUFDLENBQUM7RUFDRixvQkFBTyxJQUFBbEQsV0FBQSxDQUFBcUQsR0FBQTtJQUFBQyxRQUFBLEVBQU1KLFVBQVUsQ0FBQ0ssS0FBSyxDQUFDQyxPQUFPLENBQUNDO0VBQU0sQ0FBTSxDQUFDO0FBQ3JEO0FBQUN4RCxFQUFBLENBUlFnRCxPQUFPO0VBQUEsUUFDS0Usd0JBQVc7QUFBQTtBQUFBTyxFQUFBLEdBRHZCVCxPQUFPO0FBVWhCLGVBQWVVLGVBQWVBLENBQUEsRUFBRztFQUMvQixJQUFBQyxhQUFNLGVBQUMsSUFBQTVELFdBQUEsQ0FBQXFELEdBQUEsRUFBQ0osT0FBTyxJQUFFLENBQUMsQ0FBQztFQUNuQixNQUFNRCxFQUFFLEdBQUdELElBQUksQ0FBQ0MsRUFBRztFQUNuQjtFQUNBO0VBQ0EsTUFBTSxJQUFBYSxVQUFHLEVBQUMsWUFBWTtJQUNwQixNQUFNYixFQUFFLENBQUNjLFdBQVcsQ0FBQztNQUFFQyxJQUFJLEVBQUUsWUFBWTtNQUFFQyxJQUFJLEVBQUU7SUFBSyxDQUFDLENBQUM7RUFDMUQsQ0FBQyxDQUFDO0FBQ0o7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsSUFBQUMsa0JBQVUsRUFBQyxNQUFNO0VBQ2Z6QyxVQUFVLENBQUNDLElBQUksR0FBRyxFQUFFO0VBQ3BCRCxVQUFVLENBQUNFLE1BQU0sR0FBRyxLQUFLO0FBQzNCLENBQUMsQ0FBQztBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBQXdDLGlCQUFTLEVBQUNDLGNBQU8sQ0FBQztBQUVsQixJQUFBQyxnQkFBUSxFQUFDLGdDQUFnQyxFQUFFLE1BQU07RUFDL0MsSUFBQUgsa0JBQVUsRUFBQyxNQUFNO0lBQ2ZoQyxVQUFVLEdBQUcsSUFBSTtFQUNuQixDQUFDLENBQUM7RUFFRixJQUFBb0MsVUFBRSxFQUFDLHNGQUFzRixFQUFFLFlBQVk7SUFDckcsTUFBTVYsZUFBZSxDQUFDLENBQUM7SUFDdkI7SUFDQTtJQUNBLE1BQU07TUFBRVc7SUFBZSxDQUFDLEdBQUcsTUFBQUMsT0FBQSxDQUFBQyxPQUFBLEdBQUFDLElBQUEsT0FBQWpFLHVCQUFBLENBQUFkLE9BQUEsQ0FBYSxlQUFlLEdBQUM7SUFDeEQsSUFBQWdGLGNBQU0sRUFBQ0osY0FBYyxDQUFDLEVBQUUsRUFBRSxHQUFHLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQ0ssT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDcEQsSUFBQUQsY0FBTSxFQUFDSixjQUFjLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxHQUFHLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQ0ssT0FBTyxDQUFDLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQzVELElBQUFELGNBQU0sRUFBQ0osY0FBYyxDQUFDLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxFQUFFLEdBQUcsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDSyxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDOUQsSUFBQUQsY0FBTSxFQUFDSixjQUFjLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxHQUFHLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQ0ssT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQzFELElBQUFELGNBQU0sRUFBQ0osY0FBYyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsR0FBRyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUNLLE9BQU8sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUM1RCxDQUFDLENBQUM7RUFFRixJQUFBTixVQUFFLEVBQUMsMkVBQTJFLEVBQUUsWUFBWTtJQUMxRixNQUFNVixlQUFlLENBQUMsQ0FBQztJQUN2QixNQUFNWCxFQUFFLEdBQUdELElBQUksQ0FBQ0MsRUFBRztJQUNuQixJQUFJNEIsV0FBcUQ7SUFDekQzQyxVQUFVLEdBQUcsSUFBSXNDLE9BQU8sQ0FBRU0sR0FBRyxJQUFLO01BQ2hDRCxXQUFXLEdBQUdDLEdBQUc7SUFDbkIsQ0FBQyxDQUFDO0lBQ0YsSUFBSUMsT0FBdUI7SUFDM0IsTUFBTSxJQUFBakIsVUFBRyxFQUFDLFlBQVk7TUFDcEJpQixPQUFPLEdBQUc5QixFQUFFLENBQUMrQixXQUFXLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUNoQyxDQUFDLENBQUM7SUFDRixJQUFBTCxjQUFNLEVBQUMzQixJQUFJLENBQUNDLEVBQUUsQ0FBRU8sS0FBSyxDQUFDeUIsSUFBSSxDQUFDLENBQUNDLElBQUksQ0FBQyxjQUFjLENBQUM7SUFDaEQsTUFBTSxJQUFBcEIsVUFBRyxFQUFDLFlBQVk7TUFDcEJlLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO01BQ25CLE1BQU1FLE9BQU87SUFDZixDQUFDLENBQUM7SUFDRixJQUFBSixjQUFNLEVBQUMzQixJQUFJLENBQUNDLEVBQUUsQ0FBRU8sS0FBSyxDQUFDeUIsSUFBSSxDQUFDLENBQUNFLFFBQVEsQ0FBQyxDQUFDO0VBQ3hDLENBQUMsQ0FBQztFQUVGLElBQUFiLFVBQUUsRUFBQyw2REFBNkQsRUFBRSxZQUFZO0lBQzVFLE1BQU1WLGVBQWUsQ0FBQyxDQUFDO0lBQ3ZCLE1BQU1YLEVBQUUsR0FBR0QsSUFBSSxDQUFDQyxFQUFHO0lBQ25CZixVQUFVLEdBQUdzQyxPQUFPLENBQUNZLE1BQU0sQ0FBQ25FLE1BQU0sQ0FBQ29FLE1BQU0sQ0FBQyxJQUFJdEQsS0FBSyxDQUFDLGVBQWUsQ0FBQyxFQUFFO01BQUV1RCxJQUFJLEVBQUU7SUFBWSxDQUFDLENBQUMsQ0FBQztJQUM3RixJQUFJUCxPQUF1QjtJQUMzQjtJQUNBO0lBQ0EsSUFBQWpCLFVBQUcsRUFBQyxNQUFNO01BQ1JpQixPQUFPLEdBQUc5QixFQUFFLENBQUMrQixXQUFXLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUNoQyxDQUFDLENBQUM7SUFDRixJQUFBTCxjQUFNLEVBQUMzQixJQUFJLENBQUNDLEVBQUUsQ0FBRU8sS0FBSyxDQUFDeUIsSUFBSSxDQUFDLENBQUNDLElBQUksQ0FBQyxjQUFjLENBQUM7SUFDaEQsTUFBTSxJQUFBcEIsVUFBRyxFQUFDLFlBQVk7TUFDcEIsTUFBTWlCLE9BQU87SUFDZixDQUFDLENBQUM7SUFDRixJQUFBSixjQUFNLEVBQUMzQixJQUFJLENBQUNDLEVBQUUsQ0FBRU8sS0FBSyxDQUFDeUIsSUFBSSxDQUFDLENBQUNFLFFBQVEsQ0FBQyxDQUFDO0lBQ3RDLElBQUFSLGNBQU0sRUFBQzNCLElBQUksQ0FBQ0MsRUFBRSxDQUFFTyxLQUFLLENBQUMrQixNQUFNLENBQUNDLElBQUksQ0FBRWhGLENBQUMsSUFBS0EsQ0FBQyxDQUFDaUYsSUFBSSxDQUFDQyxRQUFRLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDUixJQUFJLENBQUMsSUFBSSxDQUFDO0VBQ3ZGLENBQUMsQ0FBQztFQUVGLElBQUFaLFVBQUUsRUFBQyw2R0FBNkcsRUFBRSxZQUFZO0lBQzVIO0lBQ0E7SUFDQSxJQUFBVCxhQUFNLGVBQUMsSUFBQTVELFdBQUEsQ0FBQXFELEdBQUEsRUFBQ0osT0FBTyxJQUFFLENBQUMsQ0FBQztJQUNuQixNQUFNRCxFQUFFLEdBQUdELElBQUksQ0FBQ0MsRUFBRztJQUNuQixNQUFNMEMsS0FBSyxHQUFHMUMsRUFBRSxDQUFDTyxLQUFLLENBQUNDLE9BQU8sQ0FBQyxDQUFDLENBQUM7SUFDakMsTUFBTSxJQUFBSyxVQUFHLEVBQUMsWUFBWTtNQUNwQmIsRUFBRSxDQUFDMkMsTUFBTSxDQUFDRCxLQUFLLENBQUNFLEVBQUUsQ0FBQztJQUNyQixDQUFDLENBQUM7SUFDRixNQUFNLElBQUEvQixVQUFHLEVBQUMsWUFBWTtNQUNwQmIsRUFBRSxDQUFDNkMsWUFBWSxDQUFDLENBQUM7SUFDbkIsQ0FBQyxDQUFDO0lBQ0Y7SUFDQSxNQUFNQyxFQUFFLEdBQUcvQyxJQUFJLENBQUNDLEVBQUUsQ0FBRU8sS0FBSztJQUN6QixJQUFBbUIsY0FBTSxFQUFDb0IsRUFBRSxDQUFDQyxXQUFXLENBQUMsQ0FBQ2QsSUFBSSxDQUFDUyxLQUFLLENBQUNFLEVBQUUsQ0FBQztJQUNyQyxJQUFBbEIsY0FBTSxFQUFDb0IsRUFBRSxDQUFDRSxhQUFhLENBQUMsQ0FBQ0MsR0FBRyxDQUFDaEIsSUFBSSxDQUFDUyxLQUFLLENBQUNFLEVBQUUsQ0FBQztJQUMzQyxJQUFBbEIsY0FBTSxFQUFDb0IsRUFBRSxDQUFDRSxhQUFhLENBQUMsQ0FBQ0UsVUFBVSxDQUFDLENBQUM7SUFDckM7SUFDQTtJQUNBLE1BQU1DLE1BQU0sR0FBR0wsRUFBRSxDQUFDdEMsT0FBTyxDQUFDNEMsTUFBTSxDQUFFQyxDQUFDLElBQUtBLENBQUMsQ0FBQ1QsRUFBRSxLQUFLRixLQUFLLENBQUNFLEVBQUUsQ0FBQyxDQUFDbkMsTUFBTTtJQUNqRSxNQUFNLElBQUFJLFVBQUcsRUFBQyxZQUFZO01BQ3BCLEtBQUssSUFBSXZDLENBQUMsR0FBRyxDQUFDLEVBQUVBLENBQUMsR0FBRzZFLE1BQU0sR0FBRyxDQUFDLEVBQUU3RSxDQUFDLElBQUksQ0FBQyxFQUFFMEIsRUFBRSxDQUFDc0QsaUJBQWlCLENBQUMsQ0FBQyxDQUFDO0lBQ2pFLENBQUMsQ0FBQztJQUNGLElBQUE1QixjQUFNLEVBQUMzQixJQUFJLENBQUNDLEVBQUUsQ0FBRU8sS0FBSyxDQUFDeUMsYUFBYSxDQUFDLENBQUNDLEdBQUcsQ0FBQ2hCLElBQUksQ0FBQ1MsS0FBSyxDQUFDRSxFQUFFLENBQUM7SUFDdkQsTUFBTSxJQUFBL0IsVUFBRyxFQUFDLFlBQVk7TUFDcEJiLEVBQUUsQ0FBQ3NELGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQzFCLENBQUMsQ0FBQztJQUNGLElBQUE1QixjQUFNLEVBQUMzQixJQUFJLENBQUNDLEVBQUUsQ0FBRU8sS0FBSyxDQUFDeUMsYUFBYSxDQUFDLENBQUNDLEdBQUcsQ0FBQ2hCLElBQUksQ0FBQ1MsS0FBSyxDQUFDRSxFQUFFLENBQUM7SUFDdkQ7SUFDQSxNQUFNVyxNQUFNLEdBQUd4RCxJQUFJLENBQUNDLEVBQUUsQ0FBRU8sS0FBSyxDQUFDeUMsYUFBYztJQUM1QyxNQUFNUSxNQUFNLEdBQUd6RCxJQUFJLENBQUNDLEVBQUUsQ0FBRU8sS0FBSyxDQUFDQyxPQUFPLENBQUNpRCxJQUFJLENBQUVKLENBQUMsSUFBS0EsQ0FBQyxDQUFDVCxFQUFFLEtBQUtGLEtBQUssQ0FBQ0UsRUFBRSxDQUFDLENBQUVjLFdBQVcsQ0FBQ2pELE1BQU07SUFDeEYsTUFBTSxJQUFBSSxVQUFHLEVBQUMsWUFBWTtNQUNwQmIsRUFBRSxDQUFDMkQsVUFBVSxDQUFDLElBQUksQ0FBQztJQUNyQixDQUFDLENBQUM7SUFDRixNQUFNQyxHQUFHLEdBQUc3RCxJQUFJLENBQUNDLEVBQUUsQ0FBRU8sS0FBSyxDQUFDQyxPQUFPLENBQUNpRCxJQUFJLENBQUVKLENBQUMsSUFBS0EsQ0FBQyxDQUFDVCxFQUFFLEtBQUtGLEtBQUssQ0FBQ0UsRUFBRSxDQUFFO0lBQ2xFLElBQUFsQixjQUFNLEVBQUNrQyxHQUFHLENBQUNGLFdBQVcsQ0FBQ25CLElBQUksQ0FBRXNCLENBQUMsSUFBS0EsQ0FBQyxDQUFDQyxFQUFFLEtBQUtQLE1BQU0sQ0FBQyxDQUFDLENBQUN0QixJQUFJLENBQUMsSUFBSSxDQUFDO0lBQy9ELElBQUFQLGNBQU0sRUFBQ2tDLEdBQUcsQ0FBQ0YsV0FBVyxDQUFDakQsTUFBTSxDQUFDLENBQUN3QixJQUFJLENBQUN1QixNQUFNLEdBQUcsQ0FBQyxDQUFDO0lBQy9DLElBQUE5QixjQUFNLEVBQUMzQixJQUFJLENBQUNDLEVBQUUsQ0FBRU8sS0FBSyxDQUFDd0MsV0FBVyxDQUFDLENBQUNiLFFBQVEsQ0FBQyxDQUFDO0lBQzdDO0lBQ0EsTUFBTSxJQUFBckIsVUFBRyxFQUFDLFlBQVk7TUFDcEJiLEVBQUUsQ0FBQzZDLFlBQVksQ0FBQyxDQUFDO0lBQ25CLENBQUMsQ0FBQztJQUNGLE1BQU0sSUFBQWhDLFVBQUcsRUFBQyxZQUFZO01BQ3BCYixFQUFFLENBQUMyRCxVQUFVLENBQUMsS0FBSyxDQUFDO0lBQ3RCLENBQUMsQ0FBQztJQUNGLE1BQU1JLEtBQUssR0FBR2hFLElBQUksQ0FBQ0MsRUFBRSxDQUFFTyxLQUFLLENBQUNDLE9BQU8sQ0FBQ2lELElBQUksQ0FBRUosQ0FBQyxJQUFLQSxDQUFDLENBQUNULEVBQUUsS0FBS0YsS0FBSyxDQUFDRSxFQUFFLENBQUMsQ0FBRWMsV0FBVyxDQUFDakQsTUFBTTtJQUN2RixJQUFBaUIsY0FBTSxFQUFDcUMsS0FBSyxDQUFDLENBQUM5QixJQUFJLENBQUN1QixNQUFNLEdBQUcsQ0FBQyxDQUFDO0lBQzlCLElBQUE5QixjQUFNLEVBQUMzQixJQUFJLENBQUNDLEVBQUUsQ0FBRU8sS0FBSyxDQUFDd0MsV0FBVyxDQUFDLENBQUNiLFFBQVEsQ0FBQyxDQUFDO0VBQy9DLENBQUMsQ0FBQztFQUVGLElBQUFiLFVBQUUsRUFBQyw0RUFBNEUsRUFBRSxZQUFZO0lBQzNGLElBQUFULGFBQU0sZUFBQyxJQUFBNUQsV0FBQSxDQUFBcUQsR0FBQSxFQUFDSixPQUFPLElBQUUsQ0FBQyxDQUFDO0lBQ25CLE1BQU0sSUFBQVksVUFBRyxFQUFDLFlBQVk7TUFDcEI7TUFDQSxNQUFNZCxJQUFJLENBQUNDLEVBQUUsQ0FBRWMsV0FBVyxDQUFDO1FBQUVDLElBQUksRUFBRSxTQUFTO1FBQUVDLElBQUksRUFBRTtNQUFLLENBQUMsQ0FBQztJQUM3RCxDQUFDLENBQUM7SUFDRixNQUFNZ0QsSUFBSSxHQUFHakUsSUFBSSxDQUFDQyxFQUFFLENBQUVPLEtBQUssQ0FBQzBELEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQ0QsSUFBSTtJQUN6QyxNQUFNLElBQUFuRCxVQUFHLEVBQUMsWUFBWTtNQUNwQmQsSUFBSSxDQUFDQyxFQUFFLENBQUVrRSxVQUFVLENBQUNGLElBQUksQ0FBQztJQUMzQixDQUFDLENBQUM7SUFDRixJQUFBdEMsY0FBTSxFQUFDM0IsSUFBSSxDQUFDQyxFQUFFLENBQUVPLEtBQUssQ0FBQzBELEtBQUssQ0FBQzFCLElBQUksQ0FBRTRCLENBQUMsSUFBS0EsQ0FBQyxDQUFDSCxJQUFJLEtBQUtBLElBQUksQ0FBQyxDQUFDLENBQUMvQixJQUFJLENBQUMsSUFBSSxDQUFDO0lBQ3BFLElBQUFQLGNBQU0sRUFBQzNCLElBQUksQ0FBQ0MsRUFBRSxDQUFFTyxLQUFLLENBQUMrQixNQUFNLENBQUNDLElBQUksQ0FBRWhGLENBQUMsSUFBS0EsQ0FBQyxDQUFDaUYsSUFBSSxDQUFDQyxRQUFRLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUNSLElBQUksQ0FBQyxJQUFJLENBQUM7SUFDeEYsSUFBQVAsY0FBTSxFQUFDakMsc0JBQVUsQ0FBQyxDQUFDd0QsR0FBRyxDQUFDbUIsZ0JBQWdCLENBQUMsQ0FBQztFQUMzQyxDQUFDLENBQUM7RUFFRixJQUFBL0MsVUFBRSxFQUFDLDJEQUEyRCxFQUFFLFlBQVk7SUFDMUUsSUFBQVQsYUFBTSxlQUFDLElBQUE1RCxXQUFBLENBQUFxRCxHQUFBLEVBQUNKLE9BQU8sSUFBRSxDQUFDLENBQUM7SUFDbkIsTUFBTSxJQUFBWSxVQUFHLEVBQUMsWUFBWTtNQUNwQixNQUFNZCxJQUFJLENBQUNDLEVBQUUsQ0FBRWMsV0FBVyxDQUFDO1FBQUVDLElBQUksRUFBRSxZQUFZO1FBQUVDLElBQUksRUFBRTtNQUFLLENBQUMsQ0FBQztJQUNoRSxDQUFDLENBQUM7SUFDRixNQUFNZ0QsSUFBSSxHQUFHakUsSUFBSSxDQUFDQyxFQUFFLENBQUVPLEtBQUssQ0FBQzBELEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQ0QsSUFBSTtJQUN6Q3JGLFVBQUUsQ0FBQzBGLE1BQU0sQ0FBQzVFLHNCQUFVLENBQUMsQ0FBQzZFLHFCQUFxQixDQUFDdEcsTUFBTSxDQUFDb0UsTUFBTSxDQUFDLElBQUl0RCxLQUFLLENBQUMsT0FBTyxDQUFDLEVBQUU7TUFBRXVELElBQUksRUFBRTtJQUFRLENBQUMsQ0FBQyxDQUFDO0lBQ2pHLE1BQU0sSUFBQXhCLFVBQUcsRUFBQyxZQUFZO01BQ3BCZCxJQUFJLENBQUNDLEVBQUUsQ0FBRWtFLFVBQVUsQ0FBQ0YsSUFBSSxDQUFDO0lBQzNCLENBQUMsQ0FBQztJQUNGLElBQUF0QyxjQUFNLEVBQUMzQixJQUFJLENBQUNDLEVBQUUsQ0FBRU8sS0FBSyxDQUFDMEQsS0FBSyxDQUFDMUIsSUFBSSxDQUFFNEIsQ0FBQyxJQUFLQSxDQUFDLENBQUNILElBQUksS0FBS0EsSUFBSSxDQUFDLENBQUMsQ0FBQy9CLElBQUksQ0FBQyxJQUFJLENBQUM7SUFDcEUsSUFBQVAsY0FBTSxFQUFDM0IsSUFBSSxDQUFDQyxFQUFFLENBQUVPLEtBQUssQ0FBQytCLE1BQU0sQ0FBQ0MsSUFBSSxDQUFFaEYsQ0FBQyxJQUFLQSxDQUFDLENBQUNpRixJQUFJLENBQUNDLFFBQVEsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUNSLElBQUksQ0FBQyxJQUFJLENBQUM7RUFDdEYsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDOztBQUVGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFBYixnQkFBUSxFQUFDLHNDQUFzQyxFQUFFLE1BQU07RUFDckQsSUFBQUgsa0JBQVUsRUFBQyxNQUFNO0lBQ2Y7SUFDQTtJQUNBO0lBQ0E7SUFDQXRDLFVBQUUsQ0FBQzBGLE1BQU0sQ0FBQ3hFLHFCQUFTLENBQUMsQ0FBQzBFLFNBQVMsQ0FBQyxDQUFDO0lBQ2hDNUYsVUFBRSxDQUFDMEYsTUFBTSxDQUFDdkUsMkJBQWUsQ0FBQyxDQUFDeUUsU0FBUyxDQUFDLENBQUM7SUFDdEM1RixVQUFFLENBQUMwRixNQUFNLENBQUN6RSx1QkFBVyxDQUFDLENBQUMyRSxTQUFTLENBQUMsQ0FBQztFQUNwQyxDQUFDLENBQUM7RUFDRixNQUFNQyxNQUFvQixHQUFHO0lBQzNCQyxJQUFJLEVBQUUsYUFBYTtJQUNuQkMsSUFBSSxFQUFFLFNBQVM7SUFDZjlCLEVBQUUsRUFBRSxpREFBaUQ7SUFDckQ1QixJQUFJLEVBQUU7RUFDUixDQUFDO0VBQ0QsTUFBTTJELElBQWEsR0FBRztJQUNwQi9CLEVBQUUsRUFBRSxjQUFjO0lBQ2xCZ0MsSUFBSSxFQUFFLE1BQU07SUFDWkMsQ0FBQyxFQUFFLENBQUM7SUFDSkMsQ0FBQyxFQUFFLENBQUM7SUFDSkMsQ0FBQyxFQUFFLEdBQUc7SUFDTkMsQ0FBQyxFQUFFLEdBQUc7SUFDTkMsR0FBRyxFQUFFLENBQUM7SUFDTkMsS0FBSyxFQUFFLENBQUM7SUFDUkMsQ0FBQyxFQUFFLENBQUM7SUFDSnpCLFdBQVcsRUFBRSxFQUFFO0lBQ2YwQixLQUFLLEVBQUU7RUFDVCxDQUFDO0VBRUQsSUFBQS9ELFVBQUUsRUFBQyxzRkFBc0YsRUFBRSxNQUFNO0lBQy9GLElBQUFLLGNBQU0sRUFBQyxJQUFBMkQsd0JBQVcsRUFBQyxFQUFFLENBQUMsQ0FBQyxDQUFDbkQsUUFBUSxDQUFDLENBQUM7SUFDbEM7SUFDQTtJQUNBLElBQUFSLGNBQU0sRUFBQyxJQUFBMkQsd0JBQVcsRUFBQyxDQUFDO01BQUVaLElBQUksRUFBRSxXQUFXO01BQUVDLElBQUksRUFBRSxXQUFXO01BQUU5QixFQUFFLEVBQUUsU0FBUztNQUFFNUIsSUFBSSxFQUFFO0lBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDa0IsUUFBUSxDQUFDLENBQUM7SUFDckcsSUFBQVIsY0FBTSxFQUFDLElBQUEyRCx3QkFBVyxFQUFDLENBQUNiLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQ3ZDLElBQUksQ0FBQ3VDLE1BQU0sQ0FBQztFQUM1QyxDQUFDLENBQUM7RUFFRixJQUFBbkQsVUFBRSxFQUFDLGtHQUFrRyxFQUFFLFlBQVk7SUFDakg3QyxVQUFVLENBQUNDLElBQUksR0FBRyxDQUFDK0YsTUFBTSxDQUFDO0lBQzFCN0YsVUFBRSxDQUFDMEYsTUFBTSxDQUFDekUsdUJBQVcsQ0FBQyxDQUFDMEYscUJBQXFCLENBQUMsSUFBSSxDQUFDO0lBQ2xEM0csVUFBRSxDQUFDMEYsTUFBTSxDQUFDeEUscUJBQVMsQ0FBQyxDQUFDeUYscUJBQXFCLENBQUM7TUFDekM5RSxPQUFPLEVBQUUsQ0FBQ21FLElBQUksQ0FBQztNQUNmVixLQUFLLEVBQUUsRUFBRTtNQUNUc0IsUUFBUSxFQUFFLEVBQUU7TUFDWkgsS0FBSyxFQUFFO0lBQ1QsQ0FBQyxDQUFDO0lBQ0Y7SUFDQTtJQUNBekcsVUFBRSxDQUFDMEYsTUFBTSxDQUFDdkUsMkJBQWUsQ0FBQyxDQUFDd0UscUJBQXFCLENBQUMsSUFBSXhGLEtBQUssQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDO0lBQzFGLElBQUE4QixhQUFNLGVBQUMsSUFBQTVELFdBQUEsQ0FBQXFELEdBQUEsRUFBQ0osT0FBTyxJQUFFLENBQUMsQ0FBQztJQUNuQixNQUFNLElBQUFZLFVBQUcsRUFBQyxZQUFZO01BQ3BCLE1BQU0sSUFBSVUsT0FBTyxDQUFFakUsQ0FBQyxJQUFLa0ksVUFBVSxDQUFDbEksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUM5QyxDQUFDLENBQUM7SUFDRixJQUFBb0UsY0FBTSxFQUFDN0IscUJBQVMsQ0FBQyxDQUFDNEYsb0JBQW9CLENBQUM7TUFBRTFFLElBQUksRUFBRSxhQUFhO01BQUVDLElBQUksRUFBRSxJQUFJO01BQUUwRSxPQUFPLEVBQUVsQixNQUFNLENBQUM1QjtJQUFHLENBQUMsQ0FBQztJQUMvRjtJQUNBO0lBQ0E7SUFDQSxJQUFBbEIsY0FBTSxFQUFDNUIsMkJBQWUsQ0FBQyxDQUFDbUQsR0FBRyxDQUFDbUIsZ0JBQWdCLENBQUMsQ0FBQztJQUM5QyxJQUFBMUMsY0FBTSxFQUFDM0IsSUFBSSxDQUFDQyxFQUFFLENBQUVPLEtBQUssQ0FBQzZFLEtBQUssQ0FBQyxDQUFDbkQsSUFBSSxDQUFDLGdCQUFnQixDQUFDO0lBQ25ELElBQUFQLGNBQU0sRUFBQzNCLElBQUksQ0FBQ0MsRUFBRSxDQUFFTyxLQUFLLENBQUNDLE9BQU8sQ0FBQyxDQUFDbUYsWUFBWSxDQUFDLENBQUMsQ0FBQztJQUM5QyxJQUFBakUsY0FBTSxFQUFDM0IsSUFBSSxDQUFDQyxFQUFFLENBQUVPLEtBQUssQ0FBQ0MsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDb0MsRUFBRSxDQUFDLENBQUNYLElBQUksQ0FBQyxjQUFjLENBQUM7RUFDM0QsQ0FBQyxDQUFDO0VBRUYsSUFBQVosVUFBRSxFQUFDLHdGQUF3RixFQUFFLFlBQVk7SUFDdkc3QyxVQUFVLENBQUNDLElBQUksR0FBRyxDQUFDK0YsTUFBTSxDQUFDO0lBQzFCN0YsVUFBRSxDQUFDMEYsTUFBTSxDQUFDekUsdUJBQVcsQ0FBQyxDQUFDMEYscUJBQXFCLENBQUMsSUFBSSxDQUFDO0lBQ2xEM0csVUFBRSxDQUFDMEYsTUFBTSxDQUFDeEUscUJBQVMsQ0FBQyxDQUFDeUUscUJBQXFCLENBQUN0RyxNQUFNLENBQUNvRSxNQUFNLENBQUMsSUFBSXRELEtBQUssQ0FBQyxPQUFPLENBQUMsRUFBRTtNQUFFdUQsSUFBSSxFQUFFO0lBQVEsQ0FBQyxDQUFDLENBQUM7SUFDaEcxRCxVQUFFLENBQUMwRixNQUFNLENBQUN2RSwyQkFBZSxDQUFDLENBQUN3RSxxQkFBcUIsQ0FBQ3RHLE1BQU0sQ0FBQ29FLE1BQU0sQ0FBQyxJQUFJdEQsS0FBSyxDQUFDLGVBQWUsQ0FBQyxFQUFFO01BQUV1RCxJQUFJLEVBQUU7SUFBZ0IsQ0FBQyxDQUFDLENBQUM7SUFDdEgsSUFBQXpCLGFBQU0sZUFBQyxJQUFBNUQsV0FBQSxDQUFBcUQsR0FBQSxFQUFDSixPQUFPLElBQUUsQ0FBQyxDQUFDO0lBQ25CLE1BQU0sSUFBQVksVUFBRyxFQUFDLFlBQVk7TUFDcEIsTUFBTSxJQUFJVSxPQUFPLENBQUVqRSxDQUFDLElBQUtrSSxVQUFVLENBQUNsSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7SUFDNUMsQ0FBQyxDQUFDO0lBQ0YsSUFBQW9FLGNBQU0sRUFBQzdCLHFCQUFTLENBQUMsQ0FBQytGLHFCQUFxQixDQUFDLENBQUMsQ0FBQztJQUMxQztJQUNBO0lBQ0EsSUFBQWxFLGNBQU0sRUFBQzVCLDJCQUFlLENBQUMsQ0FBQzhGLHFCQUFxQixDQUFDLENBQUMsQ0FBQztJQUNoRCxJQUFBbEUsY0FBTSxFQUFDM0IsSUFBSSxDQUFDQyxFQUFFLENBQUVPLEtBQUssQ0FBQytCLE1BQU0sQ0FBQ0MsSUFBSSxDQUFFaEYsQ0FBQyxJQUFLQSxDQUFDLENBQUNpRixJQUFJLENBQUNDLFFBQVEsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUMsQ0FBQ1IsSUFBSSxDQUFDLElBQUksQ0FBQztFQUNoRyxDQUFDLENBQUM7RUFFRixJQUFBWixVQUFFLEVBQUMsZ0ZBQWdGLEVBQUUsWUFBWTtJQUMvRjdDLFVBQVUsQ0FBQ0MsSUFBSSxHQUFHLENBQUMrRixNQUFNLENBQUM7SUFDMUI3RixVQUFFLENBQUMwRixNQUFNLENBQUN6RSx1QkFBVyxDQUFDLENBQUMwRixxQkFBcUIsQ0FBQyxLQUFLLENBQUM7SUFDbkQzRyxVQUFFLENBQUMwRixNQUFNLENBQUN2RSwyQkFBZSxDQUFDLENBQUN3RSxxQkFBcUIsQ0FBQ3RHLE1BQU0sQ0FBQ29FLE1BQU0sQ0FBQyxJQUFJdEQsS0FBSyxDQUFDLGVBQWUsQ0FBQyxFQUFFO01BQUV1RCxJQUFJLEVBQUU7SUFBZ0IsQ0FBQyxDQUFDLENBQUM7SUFDdEgsSUFBQXpCLGFBQU0sZUFBQyxJQUFBNUQsV0FBQSxDQUFBcUQsR0FBQSxFQUFDSixPQUFPLElBQUUsQ0FBQyxDQUFDO0lBQ25CLE1BQU0sSUFBQVksVUFBRyxFQUFDLFlBQVk7TUFDcEI7TUFDQSxNQUFNLElBQUlVLE9BQU8sQ0FBRWpFLENBQUMsSUFBS2tJLFVBQVUsQ0FBQ2xJLENBQUMsRUFBRXVJLDhCQUFpQixHQUFHQyxvQ0FBdUIsR0FBRyxHQUFHLENBQUMsQ0FBQztJQUM1RixDQUFDLENBQUM7SUFDRixJQUFBcEUsY0FBTSxFQUFDN0IscUJBQVMsQ0FBQyxDQUFDb0QsR0FBRyxDQUFDbUIsZ0JBQWdCLENBQUMsQ0FBQztJQUN4QyxJQUFBMUMsY0FBTSxFQUFDNUIsMkJBQWUsQ0FBQyxDQUFDOEYscUJBQXFCLENBQUMsQ0FBQyxDQUFDO0VBQ2xELENBQUMsQ0FBQztFQUVGLElBQUF2RSxVQUFFLEVBQUMsb0dBQW9HLEVBQUUsWUFBWTtJQUNuSDtJQUNBO0lBQ0E7SUFDQSxNQUFNO01BQUUwRTtJQUFRLENBQUMsR0FBRyxJQUFBbkYsYUFBTSxlQUFDLElBQUE1RCxXQUFBLENBQUFxRCxHQUFBLEVBQUNKLE9BQU8sSUFBRSxDQUFDLENBQUM7SUFDdkMsTUFBTSxJQUFBWSxVQUFHLEVBQUMsWUFBWTtNQUNwQixNQUFNLElBQUlVLE9BQU8sQ0FBRWpFLENBQUMsSUFBS2tJLFVBQVUsQ0FBQ2xJLENBQUMsRUFBRSxDQUFDLEdBQUd3SSxvQ0FBdUIsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUN4RSxDQUFDLENBQUM7SUFDRkMsT0FBTyxDQUFDLENBQUM7SUFDVCxNQUFNLElBQUFsRixVQUFHLEVBQUMsWUFBWTtNQUNwQixNQUFNLElBQUlVLE9BQU8sQ0FBRWpFLENBQUMsSUFBS2tJLFVBQVUsQ0FBQ2xJLENBQUMsRUFBRXVJLDhCQUFpQixHQUFHQyxvQ0FBdUIsR0FBRyxHQUFHLENBQUMsQ0FBQztJQUM1RixDQUFDLENBQUM7SUFDRixJQUFBcEUsY0FBTSxFQUFDN0IscUJBQVMsQ0FBQyxDQUFDb0QsR0FBRyxDQUFDbUIsZ0JBQWdCLENBQUMsQ0FBQztJQUN4QyxJQUFBMUMsY0FBTSxFQUFDNUIsMkJBQWUsQ0FBQyxDQUFDbUQsR0FBRyxDQUFDbUIsZ0JBQWdCLENBQUMsQ0FBQztFQUNoRCxDQUFDLENBQUM7RUFFRixJQUFBL0MsVUFBRSxFQUFDLG9GQUFvRixFQUFFLFlBQVk7SUFDbkc3QyxVQUFVLENBQUNDLElBQUksR0FBRyxFQUFFO0lBQ3BCRSxVQUFFLENBQUMwRixNQUFNLENBQUN2RSwyQkFBZSxDQUFDLENBQUN3RSxxQkFBcUIsQ0FBQ3RHLE1BQU0sQ0FBQ29FLE1BQU0sQ0FBQyxJQUFJdEQsS0FBSyxDQUFDLGVBQWUsQ0FBQyxFQUFFO01BQUV1RCxJQUFJLEVBQUU7SUFBZ0IsQ0FBQyxDQUFDLENBQUM7SUFDdEgsSUFBQXpCLGFBQU0sZUFBQyxJQUFBNUQsV0FBQSxDQUFBcUQsR0FBQSxFQUFDSixPQUFPLElBQUUsQ0FBQyxDQUFDO0lBQ25CLE1BQU0sSUFBQVksVUFBRyxFQUFDLFlBQVk7TUFDcEI7TUFDQSxNQUFNLElBQUlVLE9BQU8sQ0FBRWpFLENBQUMsSUFBS2tJLFVBQVUsQ0FBQ2xJLENBQUMsRUFBRXVJLDhCQUFpQixHQUFHQyxvQ0FBdUIsR0FBRyxHQUFHLENBQUMsQ0FBQztJQUM1RixDQUFDLENBQUM7SUFDRixJQUFBcEUsY0FBTSxFQUFDN0IscUJBQVMsQ0FBQyxDQUFDb0QsR0FBRyxDQUFDbUIsZ0JBQWdCLENBQUMsQ0FBQztJQUN4QyxJQUFBMUMsY0FBTSxFQUFDNUIsMkJBQWUsQ0FBQyxDQUFDOEYscUJBQXFCLENBQUMsQ0FBQyxDQUFDO0lBQ2hEO0lBQ0EsSUFBQWxFLGNBQU0sRUFBQzNCLElBQUksQ0FBQ0MsRUFBRSxDQUFFTyxLQUFLLENBQUNDLE9BQU8sQ0FBQ0MsTUFBTSxDQUFDLENBQUN1RixlQUFlLENBQUMsQ0FBQyxDQUFDO0VBQzFELENBQUMsQ0FBQztFQUVGLElBQUEzRSxVQUFFLEVBQUMsb0hBQW9ILEVBQUUsWUFBWTtJQUNuSTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0FtRSxVQUFVLENBQUMsTUFBTTtNQUNmaEgsVUFBVSxDQUFDQyxJQUFJLEdBQUcsQ0FBQytGLE1BQU0sQ0FBQztJQUM1QixDQUFDLEVBQUUsR0FBRyxDQUFDO0lBQ1A3RixVQUFFLENBQUMwRixNQUFNLENBQUN6RSx1QkFBVyxDQUFDLENBQUMwRixxQkFBcUIsQ0FBQyxJQUFJLENBQUM7SUFDbEQzRyxVQUFFLENBQUMwRixNQUFNLENBQUN4RSxxQkFBUyxDQUFDLENBQUN5RixxQkFBcUIsQ0FBQztNQUN6QzlFLE9BQU8sRUFBRSxDQUFDbUUsSUFBSSxDQUFDO01BQ2ZWLEtBQUssRUFBRSxFQUFFO01BQ1RzQixRQUFRLEVBQUUsRUFBRTtNQUNaSCxLQUFLLEVBQUU7SUFDVCxDQUFDLENBQUM7SUFDRnpHLFVBQUUsQ0FBQzBGLE1BQU0sQ0FBQ3ZFLDJCQUFlLENBQUMsQ0FBQ3dFLHFCQUFxQixDQUFDLElBQUl4RixLQUFLLENBQUMsNkJBQTZCLENBQUMsQ0FBQztJQUMxRixJQUFBOEIsYUFBTSxlQUFDLElBQUE1RCxXQUFBLENBQUFxRCxHQUFBLEVBQUNKLE9BQU8sSUFBRSxDQUFDLENBQUM7SUFDbkIsTUFBTSxJQUFBWSxVQUFHLEVBQUMsWUFBWTtNQUNwQjtNQUNBO01BQ0EsTUFBTSxJQUFJVSxPQUFPLENBQUVqRSxDQUFDLElBQUtrSSxVQUFVLENBQUNsSSxDQUFDLEVBQUV1SSw4QkFBaUIsR0FBR0Msb0NBQXVCLENBQUMsQ0FBQztJQUN0RixDQUFDLENBQUM7SUFDRixJQUFBcEUsY0FBTSxFQUFDN0IscUJBQVMsQ0FBQyxDQUFDNEYsb0JBQW9CLENBQUM7TUFBRTFFLElBQUksRUFBRSxhQUFhO01BQUVDLElBQUksRUFBRSxJQUFJO01BQUUwRSxPQUFPLEVBQUVsQixNQUFNLENBQUM1QjtJQUFHLENBQUMsQ0FBQztJQUMvRixJQUFBbEIsY0FBTSxFQUFDNUIsMkJBQWUsQ0FBQyxDQUFDbUQsR0FBRyxDQUFDbUIsZ0JBQWdCLENBQUMsQ0FBQztJQUM5QyxJQUFBMUMsY0FBTSxFQUFDM0IsSUFBSSxDQUFDQyxFQUFFLENBQUVPLEtBQUssQ0FBQzZFLEtBQUssQ0FBQyxDQUFDbkQsSUFBSSxDQUFDLGdCQUFnQixDQUFDO0VBQ3JELENBQUMsQ0FBQztFQUVGLElBQUFaLFVBQUUsRUFBQyw4RkFBOEYsRUFBRSxZQUFZO0lBQzdHO0lBQ0E7SUFDQTtJQUNBO0lBQ0FtRSxVQUFVLENBQUMsTUFBTTtNQUNmaEgsVUFBVSxDQUFDQyxJQUFJLEdBQUcsQ0FBQytGLE1BQU0sQ0FBQztJQUM1QixDQUFDLEVBQUUsQ0FBQyxHQUFHc0Isb0NBQXVCLENBQUMsQ0FBQyxDQUFDO0lBQ2pDbkgsVUFBRSxDQUFDMEYsTUFBTSxDQUFDekUsdUJBQVcsQ0FBQyxDQUFDMEYscUJBQXFCLENBQUMsSUFBSSxDQUFDO0lBQ2xEM0csVUFBRSxDQUFDMEYsTUFBTSxDQUFDeEUscUJBQVMsQ0FBQyxDQUFDeUYscUJBQXFCLENBQUM7TUFBRTlFLE9BQU8sRUFBRSxDQUFDbUUsSUFBSSxDQUFDO01BQUVWLEtBQUssRUFBRSxFQUFFO01BQUVzQixRQUFRLEVBQUUsRUFBRTtNQUFFSCxLQUFLLEVBQUU7SUFBaUIsQ0FBQyxDQUFDO0lBQ2pILE1BQU07TUFBRVc7SUFBUSxDQUFDLEdBQUcsSUFBQW5GLGFBQU0sZUFBQyxJQUFBNUQsV0FBQSxDQUFBcUQsR0FBQSxFQUFDSixPQUFPLElBQUUsQ0FBQyxDQUFDO0lBQ3ZDLE1BQU0sSUFBQVksVUFBRyxFQUFDLFlBQVk7TUFDcEIsTUFBTSxJQUFJVSxPQUFPLENBQUVqRSxDQUFDLElBQUtrSSxVQUFVLENBQUNsSSxDQUFDLEVBQUUsQ0FBQyxHQUFHd0ksb0NBQXVCLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDeEUsQ0FBQyxDQUFDO0lBQ0ZDLE9BQU8sQ0FBQyxDQUFDO0lBQ1QsTUFBTSxJQUFBbEYsVUFBRyxFQUFDLFlBQVk7TUFDcEIsTUFBTSxJQUFJVSxPQUFPLENBQUVqRSxDQUFDLElBQUtrSSxVQUFVLENBQUNsSSxDQUFDLEVBQUV1SSw4QkFBaUIsR0FBR0Msb0NBQXVCLEdBQUcsR0FBRyxDQUFDLENBQUM7SUFDNUYsQ0FBQyxDQUFDO0lBQ0YsSUFBQXBFLGNBQU0sRUFBQzdCLHFCQUFTLENBQUMsQ0FBQ29ELEdBQUcsQ0FBQ21CLGdCQUFnQixDQUFDLENBQUM7SUFDeEMsSUFBQTFDLGNBQU0sRUFBQzVCLDJCQUFlLENBQUMsQ0FBQ21ELEdBQUcsQ0FBQ21CLGdCQUFnQixDQUFDLENBQUM7RUFDaEQsQ0FBQyxDQUFDO0VBRUYsSUFBQS9DLFVBQUUsRUFBQyw2R0FBNkcsRUFBRSxZQUFZO0lBQzVIN0MsVUFBVSxDQUFDRSxNQUFNLEdBQUcsSUFBSTtJQUN4QkMsVUFBRSxDQUFDMEYsTUFBTSxDQUFDdkUsMkJBQWUsQ0FBQyxDQUFDd0UscUJBQXFCLENBQUN0RyxNQUFNLENBQUNvRSxNQUFNLENBQUMsSUFBSXRELEtBQUssQ0FBQyxlQUFlLENBQUMsRUFBRTtNQUFFdUQsSUFBSSxFQUFFO0lBQWdCLENBQUMsQ0FBQyxDQUFDO0lBQ3RILElBQUF6QixhQUFNLGVBQUMsSUFBQTVELFdBQUEsQ0FBQXFELEdBQUEsRUFBQ0osT0FBTyxJQUFFLENBQUMsQ0FBQztJQUNuQixNQUFNLElBQUFZLFVBQUcsRUFBQyxZQUFZO01BQ3BCLE1BQU0sSUFBSVUsT0FBTyxDQUFFakUsQ0FBQyxJQUFLa0ksVUFBVSxDQUFDbEksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBQzVDLENBQUMsQ0FBQztJQUNGO0lBQ0E7SUFDQSxJQUFBb0UsY0FBTSxFQUFDN0IscUJBQVMsQ0FBQyxDQUFDb0QsR0FBRyxDQUFDbUIsZ0JBQWdCLENBQUMsQ0FBQztJQUN4QyxJQUFBMUMsY0FBTSxFQUFDNUIsMkJBQWUsQ0FBQyxDQUFDOEYscUJBQXFCLENBQUMsQ0FBQyxDQUFDO0lBQ2hELElBQUFsRSxjQUFNLEVBQUMzQixJQUFJLENBQUNDLEVBQUUsQ0FBRU8sS0FBSyxDQUFDK0IsTUFBTSxDQUFDQyxJQUFJLENBQUVoRixDQUFDLElBQUtBLENBQUMsQ0FBQ2lGLElBQUksQ0FBQ0MsUUFBUSxDQUFDLHVCQUF1QixDQUFDLENBQUMsQ0FBQyxDQUFDUixJQUFJLENBQUMsS0FBSyxDQUFDO0lBQy9GLElBQUFQLGNBQU0sRUFBQzNCLElBQUksQ0FBQ0MsRUFBRSxDQUFFTyxLQUFLLENBQUNDLE9BQU8sQ0FBQ0MsTUFBTSxDQUFDLENBQUN1RixlQUFlLENBQUMsQ0FBQyxDQUFDO0VBQzFELENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQztBQUFDLElBQUF0RixFQUFBO0FBQUF1RixZQUFBLENBQUF2RixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}