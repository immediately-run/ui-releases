var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

var _react = require("react");
var _client = require("react-dom/client");
var _App = _interopRequireDefault(require("./App.tsx"));
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// Local-dev / production entry point. immediately.run does NOT use this file —
// it renders the default export of src/App.tsx directly. Keep anything the
// rendered app needs (global CSS imports, context providers) inside App.tsx,
// not here, or it will be missing when the app runs on immediately.run.
(0, _client.createRoot)(document.getElementById('root')).render(/*#__PURE__*/(0, _jsxRuntime.jsx)(_react.StrictMode, {
  children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_App.default, {})
}));
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX2NsaWVudCIsIl9BcHAiLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX2pzeFJ1bnRpbWUiLCJlIiwiX19lc01vZHVsZSIsImRlZmF1bHQiLCJjcmVhdGVSb290IiwiZG9jdW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsInJlbmRlciIsImpzeCIsIlN0cmljdE1vZGUiLCJjaGlsZHJlbiJdLCJzb3VyY2VzIjpbIm1haW4udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFN0cmljdE1vZGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IGNyZWF0ZVJvb3QgfSBmcm9tICdyZWFjdC1kb20vY2xpZW50J1xuaW1wb3J0IEFwcCBmcm9tICcuL0FwcC50c3gnXG5cbi8vIExvY2FsLWRldiAvIHByb2R1Y3Rpb24gZW50cnkgcG9pbnQuIGltbWVkaWF0ZWx5LnJ1biBkb2VzIE5PVCB1c2UgdGhpcyBmaWxlIOKAlFxuLy8gaXQgcmVuZGVycyB0aGUgZGVmYXVsdCBleHBvcnQgb2Ygc3JjL0FwcC50c3ggZGlyZWN0bHkuIEtlZXAgYW55dGhpbmcgdGhlXG4vLyByZW5kZXJlZCBhcHAgbmVlZHMgKGdsb2JhbCBDU1MgaW1wb3J0cywgY29udGV4dCBwcm92aWRlcnMpIGluc2lkZSBBcHAudHN4LFxuLy8gbm90IGhlcmUsIG9yIGl0IHdpbGwgYmUgbWlzc2luZyB3aGVuIHRoZSBhcHAgcnVucyBvbiBpbW1lZGlhdGVseS5ydW4uXG5jcmVhdGVSb290KGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdyb290JykhKS5yZW5kZXIoXG4gIDxTdHJpY3RNb2RlPlxuICAgIDxBcHAgLz5cbiAgPC9TdHJpY3RNb2RlPixcbilcbiJdLCJtYXBwaW5ncyI6Ijs7QUFBQSxJQUFBQSxNQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxPQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxJQUFBLEdBQUFDLHNCQUFBLENBQUFILE9BQUE7QUFBMkIsSUFBQUksV0FBQSxHQUFBSixPQUFBO0FBQUEsU0FBQUcsdUJBQUFFLENBQUEsV0FBQUEsQ0FBQSxJQUFBQSxDQUFBLENBQUFDLFVBQUEsR0FBQUQsQ0FBQSxLQUFBRSxPQUFBLEVBQUFGLENBQUE7QUFFM0I7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFBRyxrQkFBVSxFQUFDQyxRQUFRLENBQUNDLGNBQWMsQ0FBQyxNQUFNLENBQUUsQ0FBQyxDQUFDQyxNQUFNLGNBQ2pELElBQUFQLFdBQUEsQ0FBQVEsR0FBQSxFQUFDYixNQUFBLENBQUFjLFVBQVU7RUFBQUMsUUFBQSxlQUNULElBQUFWLFdBQUEsQ0FBQVEsR0FBQSxFQUFDVixJQUFBLENBQUFLLE9BQUcsSUFBRTtBQUFDLENBQ0csQ0FDZCxDQUFDIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}