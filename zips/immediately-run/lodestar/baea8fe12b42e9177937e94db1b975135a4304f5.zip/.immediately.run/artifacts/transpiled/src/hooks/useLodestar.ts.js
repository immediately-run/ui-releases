"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.BUSY_LABELS = void 0;
exports.applySelection = applySelection;
exports.useLodestar = useLodestar;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.find.js");
require("core-js/modules/esnext.iterator.for-each.js");
require("core-js/modules/esnext.iterator.map.js");
require("core-js/modules/esnext.iterator.some.js");
var _react = require("react");
var _camera = require("../lib/camera");
var _geometry = require("../lib/geometry");
var _ids = require("../lib/ids");
var _seedBoard = require("../data/seedBoard");
var _boardStore = require("../lib/boardStore");
var _pickFile = require("../lib/pickFile");
var _mounts = require("@immediately-run/sdk/mounts");
var _openProject = require("../lib/openProject");
// Lodestar's single source of truth: camera, objects, selection, and all
// pointer/keyboard gesture logic. Ported from the design comp's controller into
// one hook so the presentational components stay thin. Geometry gestures write
// "once, on gesture end" (spec §5.1); here the write is an in-memory mutation +
// a saved-toast, the seam where the persistence layer (§2.6 round-trip discipline)
// will attach once the change layer lands.

// Subpath import, not the package barrel: the barrel re-exports `./tasks`,
// whose top-level `addListener` side effect throws `no host transport` at
// module-eval time under local `vite dev`. `/mounts` is side-effect-free.

/** Join a mount root with a (validated, relative) path; collapse double slashes. */
const subPath = (root, rel) => `${root}/${rel}`.replace(/\/+/g, '/');

/** Short ` · code` suffix from a typed platform/fs error, for toast text. */
function codeOf(e) {
  const c = e?.code;
  return c ? ` · ${c}` : '';
}
const initialViewport = () => ({
  vw: typeof window !== 'undefined' ? window.innerWidth : 1440,
  vh: typeof window !== 'undefined' ? window.innerHeight : 900,
  vleft: 0,
  vtop: 0
});

/** The ONE spelling of selection semantics (R3-607, R6): given the current
 *  selection and an id, the next selection for a replace- or toggle-click /
 *  focus. Pure, so the pointer path and the keyboard path cannot drift. */
function applySelection(sel, id, additive) {
  if (additive) return sel.includes(id) ? sel.filter(x => x !== id) : sel.concat(id);
  return sel.includes(id) ? sel : [id];
}
const MOBILE_BREAKPOINT = 720;

// The board-manifest schema version THIS reader understands. A manifest carrying
// a higher `schema:` is from a newer reader — recognised but marked readonly (the
// `readonly` degraded state, spec §2.4) rather than mis-rendered (R3-401).
const SUPPORTED_SCHEMA = 1;

// The usable height a journey-playing rect view fits into: the caption + controls
// take roughly the bottom 240px of an 844px phone viewport (item R3-400), so a
// fitted view must clear that band or the subject hides under the chrome.
const JOURNEY_FIT_INSET = 240;
const prefersReducedMotion = () => {
  try {
    return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  } catch {
    return false;
  }
};

/** The ONE spelling of what each named busy state says on its control
 *  (R-IX-2 / R6): every surface that names a wait reads this map — coupled
 *  surfaces cannot drift apart on a reword. */
const BUSY_LABELS = exports.BUSY_LABELS = {
  'insert-image': 'Adding image…',
  'new-board': 'Creating board…',
  'open-board': 'Opening board…'
};
function useLodestar() {
  // The canvas element arrives via a callback ref (a function, not a ref object
  // read during render) so the listener effect re-runs once it mounts.
  const [canvasEl, setCanvasEl] = (0, _react.useState)(null);
  const registerCanvas = (0, _react.useCallback)(el => setCanvasEl(el), []);
  const dragRef = (0, _react.useRef)(null);
  const tweenRef = (0, _react.useRef)(null);
  const holdTimer = (0, _react.useRef)(null);
  const spaceRef = (0, _react.useRef)(false);
  const toastSeq = (0, _react.useRef)(0);
  // Stable indirection for the dwell auto-advance: `goStep` schedules
  // `playNextRef.current()` so the timer always calls the LATEST playNext
  // (assigned after its useCallback is defined) — breaks the circular dep.
  const playNextRef = (0, _react.useRef)(() => {});
  const [state, setState] = (0, _react.useState)(() => ({
    mode: 'run',
    light: false,
    bg: _seedBoard.BOARD.background,
    title: _seedBoard.BOARD.title,
    cam: {
      cx: 250,
      cy: 150,
      zoom: 0.6
    },
    vp: initialViewport(),
    objects: (0, _seedBoard.seedObjects)(),
    views: _seedBoard.SEED_VIEWS.slice(),
    journeys: _seedBoard.SEED_JOURNEYS,
    selection: [],
    hover: null,
    marquee: null,
    connectPreview: null,
    connectFrom: null,
    connectCursor: null,
    inspectorOpen: false,
    panelOpen: false,
    quickMenu: null,
    journey: null,
    toasts: [],
    screen: null,
    demoMenuOpen: false,
    panning: false,
    reduced: prefersReducedMotion(),
    busy: null,
    mounts: []
  }));

  // Mirror committed state so the document-level handlers branch on fresh values.
  const stateRef = (0, _react.useRef)(state);
  (0, _react.useEffect)(() => {
    stateRef.current = state;
  });
  const update = (0, _react.useCallback)(patch => setState(prev => ({
    ...prev,
    ...(typeof patch === 'function' ? patch(prev) : patch)
  })), []);
  const isMobile = (0, _react.useCallback)(() => state.vp.vw < MOBILE_BREAKPOINT, [state.vp.vw]);

  // ---- camera helpers (read latest viewport from the ref) ----
  const localPoint = (0, _react.useCallback)(e => {
    const vp = stateRef.current.vp;
    return [e.clientX - vp.vleft, e.clientY - vp.vtop];
  }, []);
  const setZoom = (0, _react.useCallback)((nz, lx, ly) => {
    update(s => ({
      cam: (0, _camera.zoomAround)(s.cam, s.vp, nz, lx, ly)
    }));
  }, [update]);

  // ---- toasts ----
  const dismissToast = (0, _react.useCallback)(id => {
    update(s => ({
      toasts: s.toasts.filter(t => t.id !== id)
    }));
  }, [update]);
  const toast = (0, _react.useCallback)((text, icon = 'check', opts = {}) => {
    const id = ++toastSeq.current;
    const t = {
      id,
      text,
      icon,
      ...opts
    };
    update(s => ({
      toasts: s.toasts.concat(t)
    }));
    const ttl = opts.actionLabel ? 9000 : 3500;
    setTimeout(() => dismissToast(id), ttl);
  }, [update, dismissToast]);

  // ---- persistence (the §2.6 round-trip seam, now live) ----
  // The board's durable target (a per-user app space) once resolved; null means
  // we never got one (signed out / declined) and the board is in memory only.
  const boardRef = (0, _react.useRef)(null);
  // Per-object debounce timers so inspector typing / arrow nudges autosave once
  // they settle, not on every keystroke.
  const saveTimers = (0, _react.useRef)(new Map());

  // Write the given objects' files, then report with one toast. With no board
  // the change is in memory only (we keep the optimistic message); a read-only
  // board reports instead of silently dropping the write.
  const commitSave = (0, _react.useCallback)((objs, savedText, savedIcon = 'check') => {
    const t = boardRef.current;
    if (!t) {
      toast(savedText, savedIcon);
      return;
    }
    if (t.mode === 'ro') {
      toast('Read-only board · change not saved', 'lock', {
        iconColor: 'var(--ink-2)'
      });
      return;
    }
    Promise.all(objs.map(o => (0, _boardStore.saveObject)(t, o))).then(() => toast(savedText, savedIcon), e => toast(`Save failed${codeOf(e)}`, 'alert', {
      iconColor: '#caa24a'
    }));
  }, [toast]);

  // Quiet debounced autosave for continuous edits (typing, arrow-key nudges).
  const scheduleSave = (0, _react.useCallback)(ids => {
    const t = boardRef.current;
    if (!t || t.mode === 'ro') return;
    for (const id of ids) {
      const prev = saveTimers.current.get(id);
      if (prev) clearTimeout(prev);
      const handle = window.setTimeout(() => {
        saveTimers.current.delete(id);
        const o = stateRef.current.objects.find(x => x.id === id);
        if (o) (0, _boardStore.saveObject)(t, o).catch(() => undefined);
      }, 500);
      saveTimers.current.set(id, handle);
    }
  }, []);

  // ---- camera animation ----
  const flyTo = (0, _react.useCallback)((target, dur, fitH) => {
    if (!target) return;
    // A view carrying a rect names a REGION, not a magnification: fit it to the
    // usable viewport (R3-400). fitH (when given) is the usable height — the
    // caption band during journey playback — so the subject clears the chrome.
    const dest = (0, _camera.cameraForTarget)(target, stateRef.current.vp.vw, fitH ?? stateRef.current.vp.vh);
    if (tweenRef.current) cancelAnimationFrame(tweenRef.current);
    if (stateRef.current.reduced || !dur) {
      update({
        cam: dest
      });
      return;
    }
    const from = {
      ...stateRef.current.cam
    };
    const t0 = performance.now();
    const ease = p => p < 0.5 ? 4 * p * p * p : 1 - Math.pow(-2 * p + 2, 3) / 2;
    const step = now => {
      const p = Math.min(1, (now - t0) / dur);
      const e = ease(p);
      update({
        cam: {
          cx: from.cx + (dest.cx - from.cx) * e,
          cy: from.cy + (dest.cy - from.cy) * e,
          zoom: from.zoom + (dest.zoom - from.zoom) * e
        }
      });
      if (p < 1) tweenRef.current = requestAnimationFrame(step);
    };
    tweenRef.current = requestAnimationFrame(step);
  }, [update]);

  // ---- views & journeys ----
  const resolveView = (0, _react.useCallback)(v => {
    if (typeof v === 'string') return stateRef.current.views.find(x => x.name === v) ?? null;
    const t = {
      cx: v.cx,
      cy: v.cy,
      zoom: v.zoom
    };
    if (v.w) t.w = v.w;
    if (v.h) t.h = v.h;
    return t;
  }, []);
  const saveView = (0, _react.useCallback)(() => {
    const s = stateRef.current;
    const view = {
      name: `view-${s.views.length + 1}`,
      cx: s.cam.cx,
      cy: s.cam.cy,
      zoom: s.cam.zoom
    };
    update(st => ({
      views: st.views.concat([view])
    }));
    const text = `Saved views/${view.name}.md`;
    const t = boardRef.current;
    if (!t) {
      toast(text, 'save');
      return;
    }
    if (t.mode === 'ro') {
      toast('Read-only board · view not saved', 'lock', {
        iconColor: 'var(--ink-2)'
      });
      return;
    }
    (0, _boardStore.saveView)(t, view).then(() => toast(text, 'save'), e => toast(`Couldn't save view${codeOf(e)}`, 'alert', {
      iconColor: '#caa24a'
    }));
  }, [update, toast]);

  /** Remove a view on the surface that creates them (R3-607, R-IX-5). A
   *  read-only board refuses BEFORE anything drops (the row never vanishes
   *  into a refusal); on writable boards the drop is optimistic and a failed
   *  file removal rolls the view back in. */
  const deleteView = (0, _react.useCallback)(name => {
    const t = boardRef.current;
    const view = stateRef.current.views.find(v => v.name === name);
    if (!view) return;
    if (t && t.mode === 'ro') {
      toast('Read-only board · view not removed', 'lock', {
        iconColor: 'var(--ink-2)'
      });
      return;
    }
    update(s => ({
      views: s.views.filter(v => v.name !== name)
    }));
    if (!t) {
      toast(`Removed views/${name}.md`, 'trash');
      return;
    }
    (0, _boardStore.removeView)(t, name).then(() => toast(`Removed views/${name}.md`, 'trash'), e => {
      // Roll the optimistic drop back — the file survived, so must the row.
      update(s => s.views.some(v => v.name === name) ? {} : {
        views: s.views.concat([view])
      });
      toast(`Couldn't remove view${codeOf(e)}`, 'alert', {
        iconColor: '#caa24a'
      });
    });
  }, [update, toast]);
  const addJourneyStep = (0, _react.useCallback)(jid => {
    const s = stateRef.current;
    const j = s.journeys.find(x => x.id === jid);
    if (!j) return;
    const next = {
      ...j,
      steps: j.steps.concat([{
        view: {
          cx: s.cam.cx,
          cy: s.cam.cy,
          zoom: s.cam.zoom
        }
      }])
    };
    update(st => ({
      journeys: st.journeys.map(x => x.id === jid ? next : x)
    }));
    const text = `Added step ${next.steps.length} to ${j.title} · saved to ${j.id}.mdx`;
    const t = boardRef.current;
    if (!t) {
      toast(text, 'plus');
      return;
    }
    if (t.mode === 'ro') {
      toast('Read-only board · step not saved', 'lock', {
        iconColor: 'var(--ink-2)'
      });
      return;
    }
    (0, _boardStore.saveJourney)(t, next).then(() => toast(text, 'plus'), e => toast(`Couldn't save journey${codeOf(e)}`, 'alert', {
      iconColor: '#caa24a'
    }));
  }, [update, toast]);
  const goStep = (0, _react.useCallback)((j, idx, instant) => {
    const s = j.steps[idx];
    const v = resolveView(s.view);
    if (v) flyTo(v, instant ? 0 : s.duration ?? 800, stateRef.current.vp.vh - JOURNEY_FIT_INSET);
    // Dwell (R3-402): a step carrying `hold` pauses that long after arriving,
    // then AUTO-advances. Cleared by any viewer control (next/prev/seek/exit).
    // Under prefers-reduced-motion the journey stays input-driven — matching
    // flyTo's cut of the tween — so a viewer is never advanced unprompted.
    if (holdTimer.current) {
      clearTimeout(holdTimer.current);
      holdTimer.current = null;
    }
    if (s.hold && !stateRef.current.reduced) {
      holdTimer.current = window.setTimeout(() => playNextRef.current(), s.hold);
    }
  }, [resolveView, flyTo]);
  const playJourney = (0, _react.useCallback)(jid => {
    const j = stateRef.current.journeys.find(x => x.id === jid);
    if (!j) return;
    if (holdTimer.current) {
      clearTimeout(holdTimer.current);
      holdTimer.current = null;
    }
    update({
      journey: {
        jid,
        idx: 0
      },
      panelOpen: false,
      inspectorOpen: false
    });
    goStep(j, 0, true);
  }, [update, goStep]);
  const playExit = (0, _react.useCallback)(() => {
    if (tweenRef.current) cancelAnimationFrame(tweenRef.current);
    if (holdTimer.current) {
      clearTimeout(holdTimer.current);
      holdTimer.current = null;
    }
    update({
      journey: null
    });
  }, [update]);
  const playNext = (0, _react.useCallback)(() => {
    const jr = stateRef.current.journey;
    if (!jr) return;
    if (holdTimer.current) {
      clearTimeout(holdTimer.current);
      holdTimer.current = null;
    }
    const j = stateRef.current.journeys.find(x => x.id === jr.jid);
    if (!j) return;
    const ni = jr.idx + 1;
    if (ni >= j.steps.length) {
      playExit();
      return;
    }
    update({
      journey: {
        ...jr,
        idx: ni
      }
    });
    goStep(j, ni);
  }, [update, goStep, playExit]);
  // Keep the dwell timer's indirection pointed at the current playNext.
  playNextRef.current = playNext;
  const playPrev = (0, _react.useCallback)(() => {
    const jr = stateRef.current.journey;
    if (!jr) return;
    if (holdTimer.current) {
      clearTimeout(holdTimer.current);
      holdTimer.current = null;
    }
    const j = stateRef.current.journeys.find(x => x.id === jr.jid);
    if (!j) return;
    const ni = Math.max(0, jr.idx - 1);
    update({
      journey: {
        ...jr,
        idx: ni
      }
    });
    goStep(j, ni);
  }, [update, goStep]);
  const playSeek = (0, _react.useCallback)(idx => {
    const jr = stateRef.current.journey;
    if (!jr) return;
    if (holdTimer.current) {
      clearTimeout(holdTimer.current);
      holdTimer.current = null;
    }
    const j = stateRef.current.journeys.find(x => x.id === jr.jid);
    if (!j) return;
    update({
      journey: {
        ...jr,
        idx
      }
    });
    goStep(j, idx);
  }, [update, goStep]);

  // ---- mutations ----
  const patchSel = (0, _react.useCallback)(patch => {
    update(s => ({
      objects: s.objects.map(o => s.selection.includes(o.id) ? {
        ...o,
        ...patch
      } : o)
    }));
    scheduleSave(stateRef.current.selection);
  }, [update, scheduleSave]);

  // ---- selection: one action for pointer and keyboard (R3-607) ----
  const select = (0, _react.useCallback)((id, additive = false) => {
    update(s => ({
      selection: applySelection(s.selection, id, additive),
      inspectorOpen: true,
      quickMenu: null
    }));
  }, [update]);

  /** Close the quick-create menu (its Escape/blur path, R3-607). */
  const closeQuickMenu = (0, _react.useCallback)(() => update({
    quickMenu: null
  }), [update]);
  const deleteSelection = (0, _react.useCallback)(() => {
    const sel = stateRef.current.selection.slice();
    if (!sel.length) return;
    const removed = stateRef.current.objects.filter(o => sel.includes(o.id));
    update(s => ({
      objects: s.objects.filter(o => !sel.includes(o.id)),
      selection: []
    }));
    // Delete is a rename into objects/.trash/ with a 10s undo (spec §4.2).
    const t = boardRef.current;
    if (t && t.mode !== 'ro') {
      Promise.all(sel.map(id => (0, _boardStore.trashObject)(t, id))).catch(e => toast(`Delete failed${codeOf(e)}`, 'alert', {
        iconColor: '#caa24a'
      }));
    }
    toast(`${sel.length > 1 ? `${sel.length} objects` : 'Object'} moved to .trash`, 'trash', {
      actionLabel: 'Undo',
      onAction: () => {
        update(s => ({
          objects: s.objects.concat(removed)
        }));
        if (t && t.mode !== 'ro') {
          Promise.all(removed.map(o => (0, _boardStore.restoreObject)(t, o.id))).catch(() => undefined);
        }
      }
    });
  }, [update, toast]);
  const createObject = (0, _react.useCallback)((kind, wx, wy) => {
    const o = {
      id: (0, _ids.generateId)(kind === 'note' ? 'note' : kind),
      kind,
      x: wx - 100,
      y: wy - 74,
      w: 200,
      h: 148,
      rot: 0,
      scale: 1,
      z: 3,
      connections: []
    };
    if (kind === 'note') {
      o.color = 'lemon';
      o.title = 'New note';
    } else if (kind === 'prose') {
      o.title = 'Prose';
      o.body = 'Write here…';
      o.w = 260;
      o.h = 160;
    } else if (kind === 'label') {
      o.title = 'Label';
      o.w = 320;
      o.h = 80;
      o.z = 1;
    } else if (kind === 'shape') {
      o.shape = 'rect';
      o.title = '';
      o.w = 200;
      o.h = 140;
    } else if (kind === 'frame') {
      o.title = 'Frame';
      o.w = 360;
      o.h = 300;
      o.z = 1;
    } else if (kind === 'img') {
      o.loaded = false;
      o.title = 'Image';
    } else if (kind === 'component') {
      o.title = '<Component/>';
    }
    update(s => ({
      objects: s.objects.concat(o),
      selection: [o.id],
      quickMenu: null,
      inspectorOpen: true,
      mode: 'edit'
    }));
    commitSave([o], `Created objects/${o.id}.mdx`, 'plus');
  }, [update, commitSave]);

  // ── pick-file flows (spec §6.1 Open/New board, §4.2 Insert image) ──────────
  // Each invokes the platform picker over a `capDir` of the board's space (the
  // only authority we hold), then maps the returned `(root, relPath)` PATH back
  // onto our OWN mount — re-validating it first (defense in depth, §1.3).

  /** Insert an image: pick a file, copy it into the board's `assets/`, drop an
   *  <Img> object at the world point. Self-contained per §4.2. The pick is
   *  named-busy on the confirming control until it settles (R-IX-2). */
  const insertImage = (0, _react.useCallback)(async (wx, wy) => {
    const target = boardRef.current;
    if (!target) {
      toast('Sign in to insert images into your board.', 'save', {
        iconColor: 'var(--ink-2)'
      });
      return;
    }
    update({
      busy: 'insert-image'
    });
    try {
      const res = await (0, _pickFile.pickFile)({
        mode: 'open-file',
        roots: [await (0, _pickFile.boardSpaceRoot)(target)],
        rootLabels: ['This board’s space'],
        rootModes: [target.mode],
        title: 'Insert image',
        filters: [{
          label: 'Images',
          extensions: ['.png', '.jpg', '.jpeg', '.gif', '.webp', '.svg', '.avif']
        }, {
          label: 'All files',
          extensions: []
        }]
      });
      if (!res) return; // cancelled — no toast spam
      const rel = (0, _pickFile.safeRel)(res.relPath);
      if (!rel) {
        toast('That file can’t be inserted.', 'alert', {
          iconColor: '#caa24a'
        });
        return;
      }
      const name = await (0, _boardStore.copyIntoAssets)(target, rel);
      const o = {
        id: (0, _ids.generateId)('img'),
        kind: 'img',
        x: wx - 130,
        y: wy - 90,
        w: 260,
        h: 180,
        rot: 0,
        scale: 1,
        z: 3,
        title: name,
        body: `<Img src="assets/${name}" />`,
        loaded: true,
        connections: []
      };
      update(s => ({
        objects: s.objects.concat(o),
        selection: [o.id],
        quickMenu: null,
        inspectorOpen: true,
        mode: 'edit',
        screen: null
      }));
      commitSave([o], `Inserted assets/${name}`, 'image');
    } catch (e) {
      toast(`Couldn’t insert image${codeOf(e)}`, 'alert', {
        iconColor: '#caa24a'
      });
    } finally {
      update({
        busy: null
      });
    }
  }, [toast, update, commitSave]);

  /** Re-point the active board to `target` and hydrate the canvas from it. */
  const loadBoardInto = (0, _react.useCallback)(async target => {
    const board = await (0, _boardStore.loadBoard)(target);
    boardRef.current = target;
    // The board.md manifest names the board (spec §2.4) — a board is a folder
    // that can state its own name; fall back to the seed only when absent.
    // A manifest schema newer than this reader marks the board readonly (the
    // `readonly` degraded state), unless the mount itself is already ro.
    const readonly = target.mode === 'ro' || typeof board.schema === 'number' && board.schema > SUPPORTED_SCHEMA;
    update({
      objects: board.objects,
      views: board.views.length ? board.views : _seedBoard.SEED_VIEWS.slice(),
      journeys: board.journeys.length ? board.journeys : _seedBoard.SEED_JOURNEYS,
      bg: board.background ?? stateRef.current.bg,
      title: board.title ?? stateRef.current.title,
      mode: readonly ? 'run' : stateRef.current.mode,
      selection: [],
      // A keyboard connect armed against the previous board must not survive
      // the swap (R3-607 review): its source id is stale the moment objects
      // are replaced.
      connectFrom: null,
      connectCursor: null,
      inspectorOpen: false,
      screen: null
    });
  }, [update]);

  /** Open an existing board folder in `space`: pick a folder, require a board.md,
   *  then load it as the active board. Named-busy while the pick is out. */
  const openBoardIn = (0, _react.useCallback)(async space => {
    update({
      busy: 'open-board'
    });
    try {
      const res = await (0, _pickFile.pickFile)({
        mode: 'open-folder',
        roots: [await (0, _pickFile.boardSpaceRoot)(space)],
        rootLabels: ['Your board space'],
        rootModes: [space.mode],
        title: 'Open board'
      });
      if (!res) return;
      const rel = (0, _pickFile.safeRel)(res.relPath);
      if (!rel) {
        toast('That folder can’t be opened.', 'alert', {
          iconColor: '#caa24a'
        });
        return;
      }
      const candidate = {
        root: subPath(space.root, rel),
        mode: space.mode,
        spaceId: space.spaceId
      };
      if (!(await (0, _boardStore.folderIsBoard)(candidate)) && !(await (0, _boardStore.boardExists)(candidate))) {
        toast('That folder isn’t a board (no board.md). Open folder again to pick another.', 'alert', {
          iconColor: '#caa24a'
        });
        return;
      }
      await loadBoardInto(candidate);
      toast('Board opened.', 'check');
    } catch (e) {
      toast(`Couldn’t open board${codeOf(e)}`, 'alert', {
        iconColor: '#caa24a'
      });
    } finally {
      update({
        busy: null
      });
    }
  }, [toast, update, loadBoardInto]);

  /** Open a SPECIFIC board directory directly (the chooser's rows, R3-607):
   *  no picker — the caller already knows the folder (it listed it). Loads
   *  through the same `loadBoardInto` every open path funnels into. */
  const openBoardAt = (0, _react.useCallback)(async target => {
    update({
      busy: 'open-board'
    });
    try {
      await loadBoardInto(target);
      toast('Board opened.', 'check');
    } catch (e) {
      toast(`Couldn’t open board${codeOf(e)}`, 'alert', {
        iconColor: '#caa24a'
      });
    } finally {
      update({
        busy: null
      });
    }
  }, [toast, update, loadBoardInto]);

  /** New board: pick (or create) a folder in `space`, scaffold board.md, open it.
   *  Named-busy while the pick is out. */
  const newBoardIn = (0, _react.useCallback)(async space => {
    if (space.mode === 'ro') {
      toast('That space is read-only — you can’t create a board there.', 'lock', {
        iconColor: 'var(--ink-2)'
      });
      return;
    }
    update({
      busy: 'new-board'
    });
    try {
      const res = await (0, _pickFile.pickFile)({
        mode: 'open-folder',
        roots: [await (0, _pickFile.boardSpaceRoot)(space)],
        rootLabels: ['Your board space'],
        rootModes: [space.mode],
        title: 'New board · choose a folder',
        allowCreateFolder: true
      });
      if (!res) return;
      const rel = (0, _pickFile.safeRel)(res.relPath);
      if (!rel) {
        toast('That folder can’t be used.', 'alert', {
          iconColor: '#caa24a'
        });
        return;
      }
      const candidate = {
        root: subPath(space.root, rel),
        mode: 'rw',
        spaceId: space.spaceId
      };
      const title = rel.split('/').pop() || 'Untitled board';
      await (0, _boardStore.writeNewBoard)(candidate, title);
      await loadBoardInto(candidate);
      toast('Board created.', 'check');
    } catch (e) {
      toast(`Couldn’t create board${codeOf(e)}`, 'alert', {
        iconColor: '#caa24a'
      });
    } finally {
      update({
        busy: null
      });
    }
  }, [toast, update, loadBoardInto]);

  /** Open / new board against the CURRENT board space (the chooser's footer). */
  const openBoard = (0, _react.useCallback)(() => {
    const space = boardRef.current;
    if (!space) {
      toast('Sign in to open a board from your space.', 'save', {
        iconColor: 'var(--ink-2)'
      });
      return;
    }
    void openBoardIn(space);
  }, [toast, openBoardIn]);
  const newBoard = (0, _react.useCallback)(() => {
    const space = boardRef.current;
    if (!space) {
      toast('Sign in to create a board in your space.', 'save', {
        iconColor: 'var(--ink-2)'
      });
      return;
    }
    void newBoardIn(space);
  }, [toast, newBoardIn]);

  /** "Add a space": the host powerbox grants a NEW space (never this app, §2),
   *  then we offer to open a board in it. */
  const addSpace = (0, _react.useCallback)(async () => {
    try {
      const granted = await (0, _pickFile.requestSpace)();
      if (!granted) return; // cancelled
      const space = {
        root: granted.path,
        mode: granted.mode,
        spaceId: granted.id
      };
      await openBoardIn(space);
    } catch (e) {
      toast(`Couldn’t add a space${codeOf(e)}`, 'alert', {
        iconColor: '#caa24a'
      });
    }
  }, [toast, openBoardIn]);
  const patchObject = (0, _react.useCallback)((id, patch) => {
    update(s => ({
      objects: s.objects.map(o => o.id === id ? {
        ...o,
        ...patch
      } : o)
    }));
    scheduleSave([id]);
  }, [update, scheduleSave]);
  const addConnection = (0, _react.useCallback)((from, to) => {
    const c = {
      to,
      kind: 'arrow',
      style: {
        stroke: 'accent',
        dash: false
      }
    };
    const src = stateRef.current.objects.find(o => o.id === from);
    const updated = src ? {
      ...src,
      connections: src.connections.concat(c)
    } : null;
    update(s => ({
      objects: s.objects.map(o => o.id === from ? {
        ...o,
        connections: o.connections.concat(c)
      } : o)
    }));
    if (updated) commitSave([updated], `Connected ${from} → ${to}`);
  }, [update, commitSave]);

  // ---- keyboard connect (the non-drag path to an edge, R3-607 / 2.5.7) ----
  /** Enter connect-from on the selected object; the cursor starts on the first
   *  other object in stacking order. Arrows then walk the cursor (the overlay
   *  draws it), Enter commits through the same addConnection the drag calls,
   *  Escape cancels. */
  const beginConnect = (0, _react.useCallback)(() => {
    const s = stateRef.current;
    if (s.selection.length !== 1) return;
    const from = s.selection[0];
    const order = s.objects.slice().sort((a, b) => (a.z || 0) - (b.z || 0)).map(o => o.id).filter(id => id !== from);
    update({
      connectFrom: from,
      connectCursor: order[0] ?? null,
      inspectorOpen: false
    });
  }, [update]);
  const endConnect = (0, _react.useCallback)(commit => {
    const s = stateRef.current;
    if (!s.connectFrom) return;
    if (commit && s.connectCursor) addConnection(s.connectFrom, s.connectCursor);
    update({
      connectFrom: null,
      connectCursor: null
    });
  }, [update, addConnection]);
  const moveConnectCursor = (0, _react.useCallback)(dir => {
    update(s => {
      if (!s.connectFrom) return {};
      const order = s.objects.slice().sort((a, b) => (a.z || 0) - (b.z || 0)).map(o => o.id).filter(id => id !== s.connectFrom);
      if (!order.length) return {};
      const idx = order.indexOf(s.connectCursor ?? order[0]);
      return {
        connectCursor: order[(idx + dir + order.length) % order.length]
      };
    });
  }, [update]);

  // ---- pointer gestures ----
  const onCanvasDown = (0, _react.useCallback)(e => {
    const s = stateRef.current;
    if (s.quickMenu) update({
      quickMenu: null
    });
    if (s.demoMenuOpen) update({
      demoMenuOpen: false
    });
    const mid = e.button === 1;
    if (s.mode === 'edit' && !spaceRef.current && !mid && !isMobile()) {
      const [lx, ly] = localPoint(e);
      if (!e.shiftKey) update({
        selection: []
      });
      dragRef.current = {
        type: 'marquee',
        sx: lx,
        sy: ly,
        add: e.shiftKey,
        base: s.selection.slice()
      };
      update({
        marquee: {
          x: lx,
          y: ly,
          w: 0,
          h: 0
        }
      });
    } else {
      dragRef.current = {
        type: 'pan',
        sx: e.clientX,
        sy: e.clientY,
        cx: s.cam.cx,
        cy: s.cam.cy
      };
      update({
        panning: true
      });
    }
  }, [update, isMobile, localPoint]);
  const objPointerDown = (0, _react.useCallback)((id, e) => {
    e.stopPropagation();
    const s = stateRef.current;
    if (s.mode !== 'edit') {
      dragRef.current = {
        type: 'pan',
        sx: e.clientX,
        sy: e.clientY,
        cx: s.cam.cx,
        cy: s.cam.cy
      };
      update({
        panning: true
      });
      return;
    }
    const o = s.objects.find(x => x.id === id);
    if (!o) return;
    // One spelling of selection for pointer and keyboard alike (R3-607).
    const sel = applySelection(s.selection, id, e.shiftKey);
    update({
      selection: sel,
      inspectorOpen: true,
      quickMenu: null
    });
    if (o.locked) return;
    const orig = {};
    s.objects.forEach(x => {
      if (sel.includes(x.id)) orig[x.id] = {
        x: x.x,
        y: x.y
      };
    });
    dragRef.current = {
      type: 'move',
      sx: e.clientX,
      sy: e.clientY,
      ids: sel,
      orig,
      moved: false
    };
  }, [update]);
  const startHandle = (0, _react.useCallback)((kind, handle, e) => {
    e.stopPropagation();
    const s = stateRef.current;
    const id = s.selection[0];
    const o = s.objects.find(x => x.id === id);
    if (!o) return;
    const base = {
      x: o.x,
      y: o.y,
      w: o.w,
      h: o.h,
      rot: o.rot
    };
    dragRef.current = kind === 'rotate' ? {
      type: 'rotate',
      sx: e.clientX,
      sy: e.clientY,
      o: base,
      id,
      moved: false
    } : {
      type: 'resize',
      kind: handle,
      sx: e.clientX,
      sy: e.clientY,
      o: base,
      id,
      moved: false
    };
  }, []);
  const startConnect = (0, _react.useCallback)((id, side, e) => {
    e.stopPropagation();
    dragRef.current = {
      type: 'connect',
      from: id,
      side,
      moved: false
    };
    const [lx, ly] = localPoint(e);
    update({
      connectPreview: {
        from: id,
        x: lx,
        y: ly,
        target: null
      }
    });
  }, [update, localPoint]);
  const setHover = (0, _react.useCallback)(id => update({
    hover: id
  }), [update]);
  const clearSelection = (0, _react.useCallback)(() => update({
    selection: []
  }), [update]);

  // ---- mode / view controls ----
  const setRun = (0, _react.useCallback)(
  // Leaving edit disarms a keyboard connect too (its cursor lives on the
  // edit surface) — connectFrom surviving into run mode would own the
  // arrows of a mode that has no selection (R3-607 review).
  () => update({
    mode: 'run',
    selection: [],
    inspectorOpen: false,
    quickMenu: null,
    connectPreview: null,
    connectFrom: null,
    connectCursor: null
  }), [update]);
  const setEdit = (0, _react.useCallback)(() => update({
    mode: 'edit'
  }), [update]);
  const toggleTheme = (0, _react.useCallback)(() => update(s => ({
    light: !s.light
  })), [update]);
  const togglePanel = (0, _react.useCallback)(() => update(s => ({
    panelOpen: !s.panelOpen
  })), [update]);
  const setScreen = (0, _react.useCallback)(screen => update({
    screen
  }), [update]);
  const setBackground = (0, _react.useCallback)(bg => update({
    bg
  }), [update]);
  const setLight = (0, _react.useCallback)(light => update({
    light
  }), [update]);
  const closeInspector = (0, _react.useCallback)(() => update({
    inspectorOpen: false
  }), [update]);
  const closePanel = (0, _react.useCallback)(() => update({
    panelOpen: false
  }), [update]);
  const toggleDemoMenu = (0, _react.useCallback)(() => update(s => ({
    demoMenuOpen: !s.demoMenuOpen
  })), [update]);
  const onCanvasDblClick = (0, _react.useCallback)(e => {
    if (stateRef.current.mode !== 'edit') return;
    const [lx, ly] = localPoint(e);
    const [wx, wy] = (0, _camera.worldAt)(stateRef.current.cam, stateRef.current.vp, lx, ly);
    update({
      quickMenu: {
        lx,
        ly,
        wx,
        wy
      }
    });
  }, [update, localPoint]);

  // ---- demo scenarios (the design's "demo states" menu) ----
  const demoLWW = (0, _react.useCallback)(() => {
    toast('Note was changed by @dana while you edited — their version kept.', 'alert', {
      iconColor: '#caa24a',
      actionLabel: 'Keep mine',
      onAction: () => toast('Your version restored', 'check')
    });
  }, [toast]);
  const demoDowngrade = (0, _react.useCallback)(() => {
    update({
      mode: 'run',
      selection: [],
      inspectorOpen: false
    });
    toast('Your access changed to read-only. Edit mode closed.', 'lock', {
      iconColor: 'var(--ink-2)'
    });
  }, [update, toast]);

  // ---- effects: measurement + global listeners ----
  (0, _react.useEffect)(() => {
    document.documentElement.setAttribute('data-theme', state.light ? 'light' : 'dark');
  }, [state.light]);
  (0, _react.useEffect)(() => {
    const el = canvasEl;
    if (!el) return;
    const measure = () => {
      const r = el.getBoundingClientRect();
      update({
        vp: {
          vw: r.width,
          vh: r.height,
          vleft: r.left,
          vtop: r.top
        }
      });
    };
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    const onWheel = e => {
      e.preventDefault();
      const [lx, ly] = localPoint(e);
      if (e.ctrlKey || e.metaKey) {
        const f = Math.exp(-e.deltaY * 0.01);
        setZoom(stateRef.current.cam.zoom * f, lx, ly);
      } else {
        update(s => ({
          cam: {
            cx: s.cam.cx + e.deltaX / s.cam.zoom,
            cy: s.cam.cy + e.deltaY / s.cam.zoom,
            zoom: s.cam.zoom
          }
        }));
      }
    };
    el.addEventListener('wheel', onWheel, {
      passive: false
    });
    const onMove = e => {
      const d = dragRef.current;
      if (!d) return;
      const z = stateRef.current.cam.zoom;
      if (d.type === 'pan') {
        const dx = e.clientX - d.sx;
        const dy = e.clientY - d.sy;
        update({
          cam: {
            cx: d.cx - dx / z,
            cy: d.cy - dy / z,
            zoom: z
          }
        });
      } else if (d.type === 'move') {
        const dx = (e.clientX - d.sx) / z;
        const dy = (e.clientY - d.sy) / z;
        d.moved = true;
        update(s => ({
          objects: s.objects.map(o => d.ids.includes(o.id) && d.orig[o.id] ? {
            ...o,
            x: d.orig[o.id].x + dx,
            y: d.orig[o.id].y + dy
          } : o)
        }));
      } else if (d.type === 'marquee') {
        const [lx, ly] = localPoint(e);
        const x = Math.min(lx, d.sx);
        const y = Math.min(ly, d.sy);
        const w = Math.abs(lx - d.sx);
        const hh = Math.abs(ly - d.sy);
        const s = stateRef.current;
        const sel = (0, _geometry.objectsInRect)(s.objects, s.cam, s.vp, x, y, w, hh);
        update({
          marquee: {
            x,
            y,
            w,
            h: hh
          },
          selection: d.add ? Array.from(new Set(d.base.concat(sel))) : sel
        });
      } else if (d.type === 'connect') {
        const [lx, ly] = localPoint(e);
        const s = stateRef.current;
        const tgt = (0, _geometry.objectAtLocal)(s.objects, s.cam, s.vp, lx, ly, d.from);
        update({
          connectPreview: {
            from: d.from,
            x: lx,
            y: ly,
            target: tgt
          }
        });
      } else if (d.type === 'resize' || d.type === 'rotate') {
        applyHandle(d, e);
      }
    };
    const applyHandle = (d, e) => {
      const s = stateRef.current;
      const z = s.cam.zoom;
      const dx = (e.clientX - d.sx) / z;
      const dy = (e.clientY - d.sy) / z;
      d.moved = true;
      update(st => ({
        objects: st.objects.map(o => {
          if (o.id !== d.id) return o;
          if (d.type === 'rotate') {
            const cx = d.o.x + d.o.w / 2;
            const cy = d.o.y + d.o.h / 2;
            const [lx, ly] = localPoint(e);
            const [wx, wy] = (0, _camera.worldAt)(s.cam, s.vp, lx, ly);
            let ang = Math.atan2(wy - cy, wx - cx) * 180 / Math.PI + 90;
            if (e.shiftKey) ang = Math.round(ang / 15) * 15;
            return {
              ...o,
              rot: Math.round(ang)
            };
          }
          let x = d.o.x;
          let y = d.o.y;
          let w = d.o.w;
          let hh = d.o.h;
          const k = d.kind;
          if (k.includes('e')) w = Math.max(60, d.o.w + dx);
          if (k.includes('s')) hh = Math.max(48, d.o.h + dy);
          if (k.includes('w')) {
            w = Math.max(60, d.o.w - dx);
            x = d.o.x + (d.o.w - w);
          }
          if (k.includes('n')) {
            hh = Math.max(48, d.o.h - dy);
            y = d.o.y + (d.o.h - hh);
          }
          return {
            ...o,
            x,
            y,
            w,
            h: hh
          };
        })
      }));
    };
    const onUp = e => {
      const d = dragRef.current;
      dragRef.current = null;
      if (!d) {
        if (stateRef.current.panning) update({
          panning: false
        });
        return;
      }
      if (d.type === 'pan') {
        update({
          panning: false
        });
      } else if (d.type === 'move' && d.moved) {
        const moved = stateRef.current.objects.filter(o => d.ids.includes(o.id));
        commitSave(moved, `Moved · saved to ${d.ids.length > 1 ? `${d.ids.length} files` : `${d.ids[0]}.mdx`}`);
      } else if (d.type === 'marquee') {
        update({
          marquee: null
        });
      } else if (d.type === 'connect') {
        const [lx, ly] = localPoint(e);
        const s = stateRef.current;
        const tgt = (0, _geometry.objectAtLocal)(s.objects, s.cam, s.vp, lx, ly, d.from);
        if (tgt) addConnection(d.from, tgt);
        update({
          connectPreview: null
        });
      } else if ((d.type === 'resize' || d.type === 'rotate') && d.moved) {
        const o = stateRef.current.objects.find(x => x.id === d.id);
        commitSave(o ? [o] : [], 'Resized · saved');
      }
    };
    const onKeyDown = e => {
      const t = e.target;
      if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable)) return;
      const s = stateRef.current;
      if (s.journey) {
        if (e.key === 'ArrowRight' || e.key === ' ') {
          e.preventDefault();
          playNext();
        } else if (e.key === 'ArrowLeft') {
          playPrev();
        } else if (e.key === 'Escape') {
          playExit();
        }
        return;
      }
      // Keyboard connect owns the arrows while it is armed (R3-607): arrows
      // walk the target cursor, Enter commits, Escape cancels — never nudging
      // or deleting underneath a live connect.
      if (s.connectFrom) {
        if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
          e.preventDefault();
          moveConnectCursor(-1);
        } else if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
          e.preventDefault();
          moveConnectCursor(1);
        } else if (e.key === 'Enter') {
          e.preventDefault();
          endConnect(true);
        } else if (e.key === 'Escape') {
          e.preventDefault();
          endConnect(false);
        }
        return;
      }
      if (e.key === 'Escape') update({
        selection: [],
        quickMenu: null,
        screen: null
      });
      if (e.key === ' ') spaceRef.current = true;
      if (s.mode === 'edit' && s.selection.length) {
        const step = e.shiftKey ? 10 : 1;
        let dx = 0;
        let dy = 0;
        if (e.key === 'ArrowLeft') dx = -step;else if (e.key === 'ArrowRight') dx = step;else if (e.key === 'ArrowUp') dy = -step;else if (e.key === 'ArrowDown') dy = step;
        if (dx || dy) {
          e.preventDefault();
          const sel = s.selection;
          update(st => ({
            objects: st.objects.map(o => sel.includes(o.id) && !o.locked ? {
              ...o,
              x: o.x + dx,
              y: o.y + dy
            } : o)
          }));
          scheduleSave(sel);
        }
        if (e.key === 'Delete' || e.key === 'Backspace') deleteSelection();
      }
    };
    const onKeyUp = e => {
      if (e.key === ' ') spaceRef.current = false;
    };
    document.addEventListener('pointermove', onMove);
    document.addEventListener('pointerup', onUp);
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    return () => {
      el.removeEventListener('wheel', onWheel);
      ro.disconnect();
      document.removeEventListener('pointermove', onMove);
      document.removeEventListener('pointerup', onUp);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      if (tweenRef.current) cancelAnimationFrame(tweenRef.current);
    };
    // The listeners read the latest state via stateRef, so they install once
    // the canvas mounts; the action callbacks they close over are all stable.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [canvasEl]);

  /**
   * Provider side of `open-project` (SPACES_UI_SPEC §6): given the delegated
   * `capDir`, find the chroot the host mounted for it, hydrate the canvas from
   * it, and arm the durable-board machinery (autosave, downgrade watch) against
   * it. Resolves true once the board is shown, false if the delegated folder
   * never resolved to a mount (the caller then aborts the task). The folder is
   * expected to already be a board (the marker only lives on board folders); an
   * empty one is seeded so the canvas still renders.
   */
  const openDelegatedProject = (0, _react.useCallback)(async dirPath => {
    // The host announces the task chroot as a mount AT the delegated path; it
    // may not be present the instant we read the input, so poll briefly (a few
    // frames) for the mount whose `path` matches.
    let mount = (0, _openProject.resolveDelegatedMount)(dirPath, (0, _mounts.getMounts)());
    for (let tries = 0; !mount && tries < 40; tries += 1) {
      await new Promise(r => setTimeout(r, 50));
      mount = (0, _openProject.resolveDelegatedMount)(dirPath, (0, _mounts.getMounts)());
    }
    if (!mount) {
      toast('Couldn’t open that project — the folder isn’t available.', 'alert', {
        iconColor: '#caa24a'
      });
      return false;
    }
    const target = (0, _openProject.dirCapToBoardTarget)(mount);
    try {
      if (await (0, _boardStore.boardExists)(target)) {
        await loadBoardInto(target);
      } else {
        // The marker said this is a project folder but it has no objects yet:
        // seed it so the user lands on a usable board, not a blank canvas.
        boardRef.current = target;
        const s = stateRef.current;
        await (0, _boardStore.seedBoard)(target, {
          objects: s.objects,
          views: s.views,
          journeys: s.journeys
        });
      }
      toast('Project opened.', 'check');
      return true;
    } catch (e) {
      toast(`Couldn’t open project${codeOf(e)}`, 'alert', {
        iconColor: '#caa24a'
      });
      return false;
    }
  }, [toast, loadBoardInto]);

  // ---- open the durable board space, hydrate (or seed), watch for downgrades ----
  (0, _react.useEffect)(() => {
    let cancelled = false;
    let unsub;
    const timers = saveTimers.current;
    (async () => {
      // ── open-project provider path (SPACES_UI_SPEC §6, Phase 5) ───────────
      // If a file manager launched us via the `open-project` task, it handed a
      // `capDir` for the project folder; the host mounted that folder as a
      // chroot. Load the board from it and complete the task, then arm the same
      // downgrade watch below against the delegated mount. A normal launch (no
      // task input) falls through to the durable-board path unchanged.
      let delegated = false;
      const dir = await (0, _openProject.readOpenProjectInput)();
      if (dir) {
        const opened = await openDelegatedProject(dir);
        if (opened) await (0, _openProject.reportOpened)(true);else await (0, _openProject.abortOpenProject)();
        if (cancelled) return;
        // On success the canvas is chrooted at the project; skip the durable
        // board space. On failure, fall through to the in-memory seed so the
        // canvas still renders something rather than a blank app.
        delegated = opened;
      }

      // ── URL-dispatch path (R3-831, REPO_CONTENT_DISPATCH_SPEC §3) ─────────
      // A cold URL load into a repo whose marker names `open-project`
      // dispatches to us as the bound viewer with NO task input: the host
      // mounts the loaded repo as our corpus, marked `type: 'content'`. That
      // mount IS the project the URL opened — load the board from it BEFORE
      // the durable path, so a dispatched project shows its own board, not
      // the demo seed. Chrooted as mounted (ro as dispatched): saving follows
      // whatever the corpus grant allows, like any board target. A corpus
      // with no board files, or a failed load, falls through to the durable
      // path unchanged.
      //
      // The read is a bounded poll (`pollForCorpusMount`, the sibling of the
      // delegated mount's poll above): the SDK's mount mirror populates from
      // the host's mount-add re-announcement asynchronously relative to this
      // effect, and a one-shot read intermittently missed the corpus and
      // booted the demo board instead (found live on the venue, 2026-10-03).
      if (!delegated) {
        let corpus = null;
        try {
          corpus = await (0, _openProject.pollForCorpusMount)(_mounts.getMounts, () => cancelled);
        } catch {
          // No host runtime (local vite dev): no corpus; the durable path answers.
        }
        if (corpus) {
          const target = (0, _openProject.dirCapToBoardTarget)(corpus);
          try {
            if (await (0, _boardStore.boardExists)(target)) {
              await loadBoardInto(target);
              if (!cancelled) toast('Project opened.', 'check');
              delegated = true;
            }
          } catch (e) {
            if (!cancelled) toast(`Couldn’t open project${codeOf(e)}`, 'alert', {
              iconColor: '#caa24a'
            });
          }
        }
      }
      // A cancelled chain (the component unmounted mid-poll, or a corpus load
      // settled after unmount) stops here: the durable path below would open
      // the user's board space and toast into an unmounted canvas.
      if (cancelled) return;
      if (!delegated) {
        let target;
        try {
          // Auto-open the signed-in user's board space. Declined / signed-out
          // rejects with a typed SpaceError — we degrade to the in-memory seed.
          target = await (0, _boardStore.openBoardTarget)();
        } catch (e) {
          // Only `auth-required` is a sign-in problem; anything else is logged
          // with its code and reported as the platform failure it is.
          const failure = (0, _boardStore.classifyBoardTargetFailure)(e);
          if (!cancelled) toast(failure.copy, failure.auth ? 'save' : 'alert', failure.auth ? {
            iconColor: 'var(--ink-2)'
          } : {
            iconColor: '#caa24a'
          });
          return;
        }
        if (cancelled) return;
        boardRef.current = target;
        try {
          if (await (0, _boardStore.boardExists)(target)) {
            const board = await (0, _boardStore.loadBoard)(target);
            if (!cancelled) {
              update({
                objects: board.objects,
                views: board.views.length ? board.views : _seedBoard.SEED_VIEWS.slice(),
                journeys: board.journeys.length ? board.journeys : _seedBoard.SEED_JOURNEYS
              });
              toast('Board loaded from your space.', 'check');
            }
          } else {
            // First run on an empty space: persist the seed demo as the starting board.
            const s = stateRef.current;
            await (0, _boardStore.seedBoard)(target, {
              objects: s.objects,
              views: s.views,
              journeys: s.journeys
            });
            if (!cancelled) toast('Board created in your space.', 'check');
          }
        } catch (e) {
          if (!cancelled) toast(`Couldn't open board${codeOf(e)}`, 'alert', {
            iconColor: '#caa24a'
          });
        }
      }
      if (cancelled) return;
      // Mirror the live mounts into state (the board chooser lists these,
      // R3-607) alongside the downgrade watch below.
      try {
        update({
          mounts: (0, _mounts.getMounts)()
        });
      } catch {
        // No host runtime yet — the list stays empty and the chooser degrades.
      }
      // A live role-downgrade re-announces the mount as `ro`; removal tears it down.
      // The mount service needs the host runtime, which is absent under local
      // `vite dev` — there the board is a static on-disk dir with no role changes,
      // so skip the subscription rather than crash.
      try {
        unsub = (0, _mounts.onMountsChange)((mounts, removed) => {
          update({
            mounts
          });
          const cur = boardRef.current;
          if (!cur) return;
          const m = mounts.find(x => cur.spaceId ? x.id === cur.spaceId : x.path === cur.root);
          if (m) {
            const mode = m.mode === 'ro' ? 'ro' : 'rw';
            if (mode !== cur.mode) {
              boardRef.current = {
                ...cur,
                mode
              };
              if (mode === 'ro') {
                update({
                  mode: 'run',
                  selection: [],
                  inspectorOpen: false
                });
                toast('Your access changed to read-only.', 'lock', {
                  iconColor: 'var(--ink-2)'
                });
              }
            }
          } else if (removed.some(r => cur.spaceId ? r.id === cur.spaceId : r.path === cur.root)) {
            boardRef.current = null;
            toast('Board space disconnected.', 'alert', {
              iconColor: 'var(--ink-2)'
            });
          }
        });
      } catch {
        // No host runtime (local `vite dev`): no live mount updates to track.
      }
    })();
    return () => {
      cancelled = true;
      unsub?.();
      for (const h of timers.values()) clearTimeout(h);
      timers.clear();
      if (holdTimer.current) clearTimeout(holdTimer.current);
      holdTimer.current = null;
    };
    // Runs once on mount; reads live state via stateRef and stable callbacks.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return {
    state,
    registerCanvas,
    boardRoot: boardRef.current?.root ?? null,
    isMobile,
    // camera
    originX: vw => (0, _camera.originX)(state.cam, vw),
    originY: vh => (0, _camera.originY)(state.cam, vh),
    project: (wx, wy) => (0, _camera.project)(state.cam, state.vp, wx, wy),
    setZoom,
    clampZoom: _camera.clampZoom,
    flyTo,
    anchorPoint: _geometry.anchorPoint,
    // gestures
    onCanvasDown,
    onCanvasDblClick,
    objPointerDown,
    startHandle,
    startConnect,
    setHover,
    clearSelection,
    select,
    closeQuickMenu,
    // keyboard connect (the non-drag path)
    beginConnect,
    endConnect,
    moveConnectCursor,
    // mutations
    patchSel,
    patchObject,
    deleteSelection,
    createObject,
    // pick-file flows
    insertImage,
    openBoard,
    openBoardAt,
    newBoard,
    newBoardIn,
    openBoardIn,
    addSpace,
    // views & journeys
    saveView,
    deleteView,
    addJourneyStep,
    resolveView,
    playJourney,
    playNext,
    playPrev,
    playExit,
    playSeek,
    // mode / chrome
    setRun,
    setEdit,
    toggleTheme,
    togglePanel,
    closeInspector,
    closePanel,
    setBackground,
    setLight,
    setScreen,
    toggleDemoMenu,
    // toasts + demo
    toast,
    dismissToast,
    demoLWW,
    demoDowngrade
  };
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX2NhbWVyYSIsIl9nZW9tZXRyeSIsIl9pZHMiLCJfc2VlZEJvYXJkIiwiX2JvYXJkU3RvcmUiLCJfcGlja0ZpbGUiLCJfbW91bnRzIiwiX29wZW5Qcm9qZWN0Iiwic3ViUGF0aCIsInJvb3QiLCJyZWwiLCJyZXBsYWNlIiwiY29kZU9mIiwiZSIsImMiLCJjb2RlIiwiaW5pdGlhbFZpZXdwb3J0IiwidnciLCJ3aW5kb3ciLCJpbm5lcldpZHRoIiwidmgiLCJpbm5lckhlaWdodCIsInZsZWZ0IiwidnRvcCIsImFwcGx5U2VsZWN0aW9uIiwic2VsIiwiaWQiLCJhZGRpdGl2ZSIsImluY2x1ZGVzIiwiZmlsdGVyIiwieCIsImNvbmNhdCIsIk1PQklMRV9CUkVBS1BPSU5UIiwiU1VQUE9SVEVEX1NDSEVNQSIsIkpPVVJORVlfRklUX0lOU0VUIiwicHJlZmVyc1JlZHVjZWRNb3Rpb24iLCJtYXRjaE1lZGlhIiwibWF0Y2hlcyIsIkJVU1lfTEFCRUxTIiwiZXhwb3J0cyIsInVzZUxvZGVzdGFyIiwiY2FudmFzRWwiLCJzZXRDYW52YXNFbCIsInVzZVN0YXRlIiwicmVnaXN0ZXJDYW52YXMiLCJ1c2VDYWxsYmFjayIsImVsIiwiZHJhZ1JlZiIsInVzZVJlZiIsInR3ZWVuUmVmIiwiaG9sZFRpbWVyIiwic3BhY2VSZWYiLCJ0b2FzdFNlcSIsInBsYXlOZXh0UmVmIiwic3RhdGUiLCJzZXRTdGF0ZSIsIm1vZGUiLCJsaWdodCIsImJnIiwiQk9BUkQiLCJiYWNrZ3JvdW5kIiwidGl0bGUiLCJjYW0iLCJjeCIsImN5Iiwiem9vbSIsInZwIiwib2JqZWN0cyIsInNlZWRPYmplY3RzIiwidmlld3MiLCJTRUVEX1ZJRVdTIiwic2xpY2UiLCJqb3VybmV5cyIsIlNFRURfSk9VUk5FWVMiLCJzZWxlY3Rpb24iLCJob3ZlciIsIm1hcnF1ZWUiLCJjb25uZWN0UHJldmlldyIsImNvbm5lY3RGcm9tIiwiY29ubmVjdEN1cnNvciIsImluc3BlY3Rvck9wZW4iLCJwYW5lbE9wZW4iLCJxdWlja01lbnUiLCJqb3VybmV5IiwidG9hc3RzIiwic2NyZWVuIiwiZGVtb01lbnVPcGVuIiwicGFubmluZyIsInJlZHVjZWQiLCJidXN5IiwibW91bnRzIiwic3RhdGVSZWYiLCJ1c2VFZmZlY3QiLCJjdXJyZW50IiwidXBkYXRlIiwicGF0Y2giLCJwcmV2IiwiaXNNb2JpbGUiLCJsb2NhbFBvaW50IiwiY2xpZW50WCIsImNsaWVudFkiLCJzZXRab29tIiwibnoiLCJseCIsImx5IiwicyIsInpvb21Bcm91bmQiLCJkaXNtaXNzVG9hc3QiLCJ0IiwidG9hc3QiLCJ0ZXh0IiwiaWNvbiIsIm9wdHMiLCJ0dGwiLCJhY3Rpb25MYWJlbCIsInNldFRpbWVvdXQiLCJib2FyZFJlZiIsInNhdmVUaW1lcnMiLCJNYXAiLCJjb21taXRTYXZlIiwib2JqcyIsInNhdmVkVGV4dCIsInNhdmVkSWNvbiIsImljb25Db2xvciIsIlByb21pc2UiLCJhbGwiLCJtYXAiLCJvIiwic2F2ZU9iamVjdCIsInRoZW4iLCJzY2hlZHVsZVNhdmUiLCJpZHMiLCJnZXQiLCJjbGVhclRpbWVvdXQiLCJoYW5kbGUiLCJkZWxldGUiLCJmaW5kIiwiY2F0Y2giLCJ1bmRlZmluZWQiLCJzZXQiLCJmbHlUbyIsInRhcmdldCIsImR1ciIsImZpdEgiLCJkZXN0IiwiY2FtZXJhRm9yVGFyZ2V0IiwiY2FuY2VsQW5pbWF0aW9uRnJhbWUiLCJmcm9tIiwidDAiLCJwZXJmb3JtYW5jZSIsIm5vdyIsImVhc2UiLCJwIiwiTWF0aCIsInBvdyIsInN0ZXAiLCJtaW4iLCJyZXF1ZXN0QW5pbWF0aW9uRnJhbWUiLCJyZXNvbHZlVmlldyIsInYiLCJuYW1lIiwidyIsImgiLCJzYXZlVmlldyIsInZpZXciLCJsZW5ndGgiLCJzdCIsInBlcnNpc3RWaWV3IiwiZGVsZXRlVmlldyIsInJlbW92ZVZpZXciLCJzb21lIiwiYWRkSm91cm5leVN0ZXAiLCJqaWQiLCJqIiwibmV4dCIsInN0ZXBzIiwicGVyc2lzdEpvdXJuZXkiLCJnb1N0ZXAiLCJpZHgiLCJpbnN0YW50IiwiZHVyYXRpb24iLCJob2xkIiwicGxheUpvdXJuZXkiLCJwbGF5RXhpdCIsInBsYXlOZXh0IiwianIiLCJuaSIsInBsYXlQcmV2IiwibWF4IiwicGxheVNlZWsiLCJwYXRjaFNlbCIsInNlbGVjdCIsImNsb3NlUXVpY2tNZW51IiwiZGVsZXRlU2VsZWN0aW9uIiwicmVtb3ZlZCIsInRyYXNoT2JqZWN0Iiwib25BY3Rpb24iLCJyZXN0b3JlT2JqZWN0IiwiY3JlYXRlT2JqZWN0Iiwia2luZCIsInd4Iiwid3kiLCJnZW5lcmF0ZUlkIiwieSIsInJvdCIsInNjYWxlIiwieiIsImNvbm5lY3Rpb25zIiwiY29sb3IiLCJib2R5Iiwic2hhcGUiLCJsb2FkZWQiLCJpbnNlcnRJbWFnZSIsInJlcyIsInBpY2tGaWxlIiwicm9vdHMiLCJib2FyZFNwYWNlUm9vdCIsInJvb3RMYWJlbHMiLCJyb290TW9kZXMiLCJmaWx0ZXJzIiwibGFiZWwiLCJleHRlbnNpb25zIiwic2FmZVJlbCIsInJlbFBhdGgiLCJjb3B5SW50b0Fzc2V0cyIsImxvYWRCb2FyZEludG8iLCJib2FyZCIsImxvYWRCb2FyZCIsInJlYWRvbmx5Iiwic2NoZW1hIiwib3BlbkJvYXJkSW4iLCJzcGFjZSIsImNhbmRpZGF0ZSIsInNwYWNlSWQiLCJmb2xkZXJJc0JvYXJkIiwiYm9hcmRFeGlzdHMiLCJvcGVuQm9hcmRBdCIsIm5ld0JvYXJkSW4iLCJhbGxvd0NyZWF0ZUZvbGRlciIsInNwbGl0IiwicG9wIiwid3JpdGVOZXdCb2FyZCIsIm9wZW5Cb2FyZCIsIm5ld0JvYXJkIiwiYWRkU3BhY2UiLCJncmFudGVkIiwicmVxdWVzdFNwYWNlIiwicGF0aCIsInBhdGNoT2JqZWN0IiwiYWRkQ29ubmVjdGlvbiIsInRvIiwic3R5bGUiLCJzdHJva2UiLCJkYXNoIiwic3JjIiwidXBkYXRlZCIsImJlZ2luQ29ubmVjdCIsIm9yZGVyIiwic29ydCIsImEiLCJiIiwiZW5kQ29ubmVjdCIsImNvbW1pdCIsIm1vdmVDb25uZWN0Q3Vyc29yIiwiZGlyIiwiaW5kZXhPZiIsIm9uQ2FudmFzRG93biIsIm1pZCIsImJ1dHRvbiIsInNoaWZ0S2V5IiwidHlwZSIsInN4Iiwic3kiLCJhZGQiLCJiYXNlIiwib2JqUG9pbnRlckRvd24iLCJzdG9wUHJvcGFnYXRpb24iLCJsb2NrZWQiLCJvcmlnIiwiZm9yRWFjaCIsIm1vdmVkIiwic3RhcnRIYW5kbGUiLCJzdGFydENvbm5lY3QiLCJzaWRlIiwic2V0SG92ZXIiLCJjbGVhclNlbGVjdGlvbiIsInNldFJ1biIsInNldEVkaXQiLCJ0b2dnbGVUaGVtZSIsInRvZ2dsZVBhbmVsIiwic2V0U2NyZWVuIiwic2V0QmFja2dyb3VuZCIsInNldExpZ2h0IiwiY2xvc2VJbnNwZWN0b3IiLCJjbG9zZVBhbmVsIiwidG9nZ2xlRGVtb01lbnUiLCJvbkNhbnZhc0RibENsaWNrIiwid29ybGRBdCIsImRlbW9MV1ciLCJkZW1vRG93bmdyYWRlIiwiZG9jdW1lbnQiLCJkb2N1bWVudEVsZW1lbnQiLCJzZXRBdHRyaWJ1dGUiLCJtZWFzdXJlIiwiciIsImdldEJvdW5kaW5nQ2xpZW50UmVjdCIsIndpZHRoIiwiaGVpZ2h0IiwibGVmdCIsInRvcCIsInJvIiwiUmVzaXplT2JzZXJ2ZXIiLCJvYnNlcnZlIiwib25XaGVlbCIsInByZXZlbnREZWZhdWx0IiwiY3RybEtleSIsIm1ldGFLZXkiLCJmIiwiZXhwIiwiZGVsdGFZIiwiZGVsdGFYIiwiYWRkRXZlbnRMaXN0ZW5lciIsInBhc3NpdmUiLCJvbk1vdmUiLCJkIiwiZHgiLCJkeSIsImFicyIsImhoIiwib2JqZWN0c0luUmVjdCIsIkFycmF5IiwiU2V0IiwidGd0Iiwib2JqZWN0QXRMb2NhbCIsImFwcGx5SGFuZGxlIiwiYW5nIiwiYXRhbjIiLCJQSSIsInJvdW5kIiwiayIsIm9uVXAiLCJvbktleURvd24iLCJ0YWdOYW1lIiwiaXNDb250ZW50RWRpdGFibGUiLCJrZXkiLCJvbktleVVwIiwicmVtb3ZlRXZlbnRMaXN0ZW5lciIsImRpc2Nvbm5lY3QiLCJvcGVuRGVsZWdhdGVkUHJvamVjdCIsImRpclBhdGgiLCJtb3VudCIsInJlc29sdmVEZWxlZ2F0ZWRNb3VudCIsImdldE1vdW50cyIsInRyaWVzIiwiZGlyQ2FwVG9Cb2FyZFRhcmdldCIsInNlZWRCb2FyZCIsImNhbmNlbGxlZCIsInVuc3ViIiwidGltZXJzIiwiZGVsZWdhdGVkIiwicmVhZE9wZW5Qcm9qZWN0SW5wdXQiLCJvcGVuZWQiLCJyZXBvcnRPcGVuZWQiLCJhYm9ydE9wZW5Qcm9qZWN0IiwiY29ycHVzIiwicG9sbEZvckNvcnB1c01vdW50Iiwib3BlbkJvYXJkVGFyZ2V0IiwiZmFpbHVyZSIsImNsYXNzaWZ5Qm9hcmRUYXJnZXRGYWlsdXJlIiwiY29weSIsImF1dGgiLCJvbk1vdW50c0NoYW5nZSIsImN1ciIsIm0iLCJ2YWx1ZXMiLCJjbGVhciIsImJvYXJkUm9vdCIsIm9yaWdpblgiLCJvcmlnaW5ZIiwicHJvamVjdCIsImNsYW1wWm9vbSIsImFuY2hvclBvaW50Il0sInNvdXJjZXMiOlsidXNlTG9kZXN0YXIudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gTG9kZXN0YXIncyBzaW5nbGUgc291cmNlIG9mIHRydXRoOiBjYW1lcmEsIG9iamVjdHMsIHNlbGVjdGlvbiwgYW5kIGFsbFxuLy8gcG9pbnRlci9rZXlib2FyZCBnZXN0dXJlIGxvZ2ljLiBQb3J0ZWQgZnJvbSB0aGUgZGVzaWduIGNvbXAncyBjb250cm9sbGVyIGludG9cbi8vIG9uZSBob29rIHNvIHRoZSBwcmVzZW50YXRpb25hbCBjb21wb25lbnRzIHN0YXkgdGhpbi4gR2VvbWV0cnkgZ2VzdHVyZXMgd3JpdGVcbi8vIFwib25jZSwgb24gZ2VzdHVyZSBlbmRcIiAoc3BlYyDCpzUuMSk7IGhlcmUgdGhlIHdyaXRlIGlzIGFuIGluLW1lbW9yeSBtdXRhdGlvbiArXG4vLyBhIHNhdmVkLXRvYXN0LCB0aGUgc2VhbSB3aGVyZSB0aGUgcGVyc2lzdGVuY2UgbGF5ZXIgKMKnMi42IHJvdW5kLXRyaXAgZGlzY2lwbGluZSlcbi8vIHdpbGwgYXR0YWNoIG9uY2UgdGhlIGNoYW5nZSBsYXllciBsYW5kcy5cblxuaW1wb3J0IHsgdXNlQ2FsbGJhY2ssIHVzZUVmZmVjdCwgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7XG4gIGNhbWVyYUZvclRhcmdldCxcbiAgY2xhbXBab29tLFxuICBvcmlnaW5YLFxuICBvcmlnaW5ZLFxuICBwcm9qZWN0LFxuICB3b3JsZEF0LFxuICB6b29tQXJvdW5kLFxufSBmcm9tICcuLi9saWIvY2FtZXJhJztcbmltcG9ydCB0eXBlIHsgVmlld3BvcnQgfSBmcm9tICcuLi9saWIvY2FtZXJhJztcbmltcG9ydCB7IGFuY2hvclBvaW50LCBvYmplY3RBdExvY2FsLCBvYmplY3RzSW5SZWN0IH0gZnJvbSAnLi4vbGliL2dlb21ldHJ5JztcbmltcG9ydCB7IGdlbmVyYXRlSWQgfSBmcm9tICcuLi9saWIvaWRzJztcbmltcG9ydCB0eXBlIHtcbiAgQmFja2dyb3VuZCxcbiAgQ2FtZXJhLFxuICBDb25uZWN0aW9uLFxuICBKb3VybmV5LFxuICBNb2RlLFxuICBPYmplY3RLaW5kLFxuICBTY3JlZW5LaW5kLFxuICBUb2FzdCxcbiAgVmlldyxcbiAgVmlld1RhcmdldCxcbiAgV09iamVjdCxcbn0gZnJvbSAnLi4vbGliL3R5cGVzJztcbmltcG9ydCB7IEJPQVJELCBTRUVEX0pPVVJORVlTLCBTRUVEX1ZJRVdTLCBzZWVkT2JqZWN0cyB9IGZyb20gJy4uL2RhdGEvc2VlZEJvYXJkJztcbmltcG9ydCB7XG4gIGJvYXJkRXhpc3RzLFxuICBjbGFzc2lmeUJvYXJkVGFyZ2V0RmFpbHVyZSxcbiAgY29weUludG9Bc3NldHMsXG4gIGZvbGRlcklzQm9hcmQsXG4gIGxvYWRCb2FyZCxcbiAgb3BlbkJvYXJkVGFyZ2V0LFxuICByZW1vdmVWaWV3LFxuICByZXN0b3JlT2JqZWN0LFxuICBzYXZlSm91cm5leSBhcyBwZXJzaXN0Sm91cm5leSxcbiAgc2F2ZU9iamVjdCxcbiAgc2F2ZVZpZXcgYXMgcGVyc2lzdFZpZXcsXG4gIHNlZWRCb2FyZCxcbiAgdHJhc2hPYmplY3QsXG4gIHdyaXRlTmV3Qm9hcmQsXG59IGZyb20gJy4uL2xpYi9ib2FyZFN0b3JlJztcbmltcG9ydCB0eXBlIHsgQm9hcmRUYXJnZXQgfSBmcm9tICcuLi9saWIvYm9hcmRTdG9yZSc7XG5pbXBvcnQgeyBib2FyZFNwYWNlUm9vdCwgcGlja0ZpbGUsIHJlcXVlc3RTcGFjZSwgc2FmZVJlbCB9IGZyb20gJy4uL2xpYi9waWNrRmlsZSc7XG4vLyBTdWJwYXRoIGltcG9ydCwgbm90IHRoZSBwYWNrYWdlIGJhcnJlbDogdGhlIGJhcnJlbCByZS1leHBvcnRzIGAuL3Rhc2tzYCxcbi8vIHdob3NlIHRvcC1sZXZlbCBgYWRkTGlzdGVuZXJgIHNpZGUgZWZmZWN0IHRocm93cyBgbm8gaG9zdCB0cmFuc3BvcnRgIGF0XG4vLyBtb2R1bGUtZXZhbCB0aW1lIHVuZGVyIGxvY2FsIGB2aXRlIGRldmAuIGAvbW91bnRzYCBpcyBzaWRlLWVmZmVjdC1mcmVlLlxuaW1wb3J0IHsgZ2V0TW91bnRzLCBvbk1vdW50c0NoYW5nZSB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrL21vdW50cyc7XG5pbXBvcnQgdHlwZSB7IFNhbmRib3hNb3VudCB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrL21vdW50cyc7XG5pbXBvcnQge1xuICBhYm9ydE9wZW5Qcm9qZWN0LFxuICBkaXJDYXBUb0JvYXJkVGFyZ2V0LFxuICBwb2xsRm9yQ29ycHVzTW91bnQsXG4gIHJlYWRPcGVuUHJvamVjdElucHV0LFxuICByZXBvcnRPcGVuZWQsXG4gIHJlc29sdmVEZWxlZ2F0ZWRNb3VudCxcbn0gZnJvbSAnLi4vbGliL29wZW5Qcm9qZWN0JztcblxuLyoqIEpvaW4gYSBtb3VudCByb290IHdpdGggYSAodmFsaWRhdGVkLCByZWxhdGl2ZSkgcGF0aDsgY29sbGFwc2UgZG91YmxlIHNsYXNoZXMuICovXG5jb25zdCBzdWJQYXRoID0gKHJvb3Q6IHN0cmluZywgcmVsOiBzdHJpbmcpOiBzdHJpbmcgPT4gYCR7cm9vdH0vJHtyZWx9YC5yZXBsYWNlKC9cXC8rL2csICcvJyk7XG5cbi8qKiBTaG9ydCBgIMK3IGNvZGVgIHN1ZmZpeCBmcm9tIGEgdHlwZWQgcGxhdGZvcm0vZnMgZXJyb3IsIGZvciB0b2FzdCB0ZXh0LiAqL1xuZnVuY3Rpb24gY29kZU9mKGU6IHVua25vd24pOiBzdHJpbmcge1xuICBjb25zdCBjID0gKGUgYXMgeyBjb2RlPzogc3RyaW5nIH0gfCBudWxsKT8uY29kZTtcbiAgcmV0dXJuIGMgPyBgIMK3ICR7Y31gIDogJyc7XG59XG5cbmludGVyZmFjZSBXQlN0YXRlIHtcbiAgbW9kZTogTW9kZTtcbiAgbGlnaHQ6IGJvb2xlYW47XG4gIGJnOiBCYWNrZ3JvdW5kO1xuICB0aXRsZTogc3RyaW5nO1xuICBjYW06IENhbWVyYTtcbiAgdnA6IFZpZXdwb3J0O1xuICBvYmplY3RzOiBXT2JqZWN0W107XG4gIHZpZXdzOiBWaWV3W107XG4gIGpvdXJuZXlzOiBKb3VybmV5W107XG4gIHNlbGVjdGlvbjogc3RyaW5nW107XG4gIGhvdmVyOiBzdHJpbmcgfCBudWxsO1xuICBtYXJxdWVlOiB7IHg6IG51bWJlcjsgeTogbnVtYmVyOyB3OiBudW1iZXI7IGg6IG51bWJlciB9IHwgbnVsbDtcbiAgY29ubmVjdFByZXZpZXc6IHsgZnJvbTogc3RyaW5nOyB4OiBudW1iZXI7IHk6IG51bWJlcjsgdGFyZ2V0OiBzdHJpbmcgfCBudWxsIH0gfCBudWxsO1xuICAvKiogS2V5Ym9hcmQgY29ubmVjdCBtb2RlIChSMy02MDcpOiB0aGUgc291cmNlIG9iamVjdCwgYW5kIHRoZSBjdXJzb3Igb2JqZWN0XG4gICAqICBhcnJvd3Mgd2FsayBhcyB0aGUgY29ubmVjdCB0YXJnZXQuIE51bGwgd2hlbiBub3QgY29ubmVjdGluZy4gKi9cbiAgY29ubmVjdEZyb206IHN0cmluZyB8IG51bGw7XG4gIGNvbm5lY3RDdXJzb3I6IHN0cmluZyB8IG51bGw7XG4gIGluc3BlY3Rvck9wZW46IGJvb2xlYW47XG4gIHBhbmVsT3BlbjogYm9vbGVhbjtcbiAgcXVpY2tNZW51OiB7IGx4OiBudW1iZXI7IGx5OiBudW1iZXI7IHd4OiBudW1iZXI7IHd5OiBudW1iZXIgfSB8IG51bGw7XG4gIGpvdXJuZXk6IHsgamlkOiBzdHJpbmc7IGlkeDogbnVtYmVyIH0gfCBudWxsO1xuICB0b2FzdHM6IFRvYXN0W107XG4gIHNjcmVlbjogU2NyZWVuS2luZDtcbiAgZGVtb01lbnVPcGVuOiBib29sZWFuO1xuICBwYW5uaW5nOiBib29sZWFuO1xuICByZWR1Y2VkOiBib29sZWFuO1xuICAvKiogVGhlIG5hbWVkIGJ1c3kgc3RhdGUgb2YgdGhlIG9uZSBsb25nLXJ1bm5pbmcgcGljayBmbG93IChSLUlYLTIpOiB0aGVcbiAgICogIGNvbmZpcm1pbmcgY29udHJvbCBzaG93cyB0aGlzIGxhYmVsIGFuZCBhcmlhLWJ1c3kgdW50aWwgaXQgc2V0dGxlcy4gKi9cbiAgYnVzeTogbnVsbCB8ICdpbnNlcnQtaW1hZ2UnIHwgJ25ldy1ib2FyZCcgfCAnb3Blbi1ib2FyZCc7XG4gIC8qKiBMaXZlIG1vdW50cywgbWlycm9yZWQgZnJvbSB0aGUgaG9zdCAodGhlIGJvYXJkIGNob29zZXIgbGlzdHMgdGhlc2UpLiAqL1xuICBtb3VudHM6IFNhbmRib3hNb3VudFtdO1xufVxuXG50eXBlIERyYWcgPVxuICB8IHsgdHlwZTogJ3Bhbic7IHN4OiBudW1iZXI7IHN5OiBudW1iZXI7IGN4OiBudW1iZXI7IGN5OiBudW1iZXIgfVxuICB8IHsgdHlwZTogJ21vdmUnOyBzeDogbnVtYmVyOyBzeTogbnVtYmVyOyBpZHM6IHN0cmluZ1tdOyBvcmlnOiBSZWNvcmQ8c3RyaW5nLCB7IHg6IG51bWJlcjsgeTogbnVtYmVyIH0+OyBtb3ZlZDogYm9vbGVhbiB9XG4gIHwgeyB0eXBlOiAnbWFycXVlZSc7IHN4OiBudW1iZXI7IHN5OiBudW1iZXI7IGFkZDogYm9vbGVhbjsgYmFzZTogc3RyaW5nW10gfVxuICB8IHsgdHlwZTogJ2Nvbm5lY3QnOyBmcm9tOiBzdHJpbmc7IHNpZGU6IHN0cmluZzsgbW92ZWQ6IGJvb2xlYW4gfVxuICB8IHsgdHlwZTogJ3Jlc2l6ZSc7IGtpbmQ6IHN0cmluZzsgc3g6IG51bWJlcjsgc3k6IG51bWJlcjsgbzogeyB4OiBudW1iZXI7IHk6IG51bWJlcjsgdzogbnVtYmVyOyBoOiBudW1iZXI7IHJvdDogbnVtYmVyIH07IGlkOiBzdHJpbmc7IG1vdmVkOiBib29sZWFuIH1cbiAgfCB7IHR5cGU6ICdyb3RhdGUnOyBzeDogbnVtYmVyOyBzeTogbnVtYmVyOyBvOiB7IHg6IG51bWJlcjsgeTogbnVtYmVyOyB3OiBudW1iZXI7IGg6IG51bWJlcjsgcm90OiBudW1iZXIgfTsgaWQ6IHN0cmluZzsgbW92ZWQ6IGJvb2xlYW4gfVxuICB8IG51bGw7XG5cbmNvbnN0IGluaXRpYWxWaWV3cG9ydCA9ICgpOiBWaWV3cG9ydCA9PiAoe1xuICB2dzogdHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgPyB3aW5kb3cuaW5uZXJXaWR0aCA6IDE0NDAsXG4gIHZoOiB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyA/IHdpbmRvdy5pbm5lckhlaWdodCA6IDkwMCxcbiAgdmxlZnQ6IDAsXG4gIHZ0b3A6IDAsXG59KTtcblxuLyoqIFRoZSBPTkUgc3BlbGxpbmcgb2Ygc2VsZWN0aW9uIHNlbWFudGljcyAoUjMtNjA3LCBSNik6IGdpdmVuIHRoZSBjdXJyZW50XG4gKiAgc2VsZWN0aW9uIGFuZCBhbiBpZCwgdGhlIG5leHQgc2VsZWN0aW9uIGZvciBhIHJlcGxhY2UtIG9yIHRvZ2dsZS1jbGljayAvXG4gKiAgZm9jdXMuIFB1cmUsIHNvIHRoZSBwb2ludGVyIHBhdGggYW5kIHRoZSBrZXlib2FyZCBwYXRoIGNhbm5vdCBkcmlmdC4gKi9cbmV4cG9ydCBmdW5jdGlvbiBhcHBseVNlbGVjdGlvbihzZWw6IHN0cmluZ1tdLCBpZDogc3RyaW5nLCBhZGRpdGl2ZTogYm9vbGVhbik6IHN0cmluZ1tdIHtcbiAgaWYgKGFkZGl0aXZlKSByZXR1cm4gc2VsLmluY2x1ZGVzKGlkKSA/IHNlbC5maWx0ZXIoKHgpID0+IHggIT09IGlkKSA6IHNlbC5jb25jYXQoaWQpO1xuICByZXR1cm4gc2VsLmluY2x1ZGVzKGlkKSA/IHNlbCA6IFtpZF07XG59XG5cbmNvbnN0IE1PQklMRV9CUkVBS1BPSU5UID0gNzIwO1xuXG4vLyBUaGUgYm9hcmQtbWFuaWZlc3Qgc2NoZW1hIHZlcnNpb24gVEhJUyByZWFkZXIgdW5kZXJzdGFuZHMuIEEgbWFuaWZlc3QgY2Fycnlpbmdcbi8vIGEgaGlnaGVyIGBzY2hlbWE6YCBpcyBmcm9tIGEgbmV3ZXIgcmVhZGVyIOKAlCByZWNvZ25pc2VkIGJ1dCBtYXJrZWQgcmVhZG9ubHkgKHRoZVxuLy8gYHJlYWRvbmx5YCBkZWdyYWRlZCBzdGF0ZSwgc3BlYyDCpzIuNCkgcmF0aGVyIHRoYW4gbWlzLXJlbmRlcmVkIChSMy00MDEpLlxuY29uc3QgU1VQUE9SVEVEX1NDSEVNQSA9IDE7XG5cbi8vIFRoZSB1c2FibGUgaGVpZ2h0IGEgam91cm5leS1wbGF5aW5nIHJlY3QgdmlldyBmaXRzIGludG86IHRoZSBjYXB0aW9uICsgY29udHJvbHNcbi8vIHRha2Ugcm91Z2hseSB0aGUgYm90dG9tIDI0MHB4IG9mIGFuIDg0NHB4IHBob25lIHZpZXdwb3J0IChpdGVtIFIzLTQwMCksIHNvIGFcbi8vIGZpdHRlZCB2aWV3IG11c3QgY2xlYXIgdGhhdCBiYW5kIG9yIHRoZSBzdWJqZWN0IGhpZGVzIHVuZGVyIHRoZSBjaHJvbWUuXG5jb25zdCBKT1VSTkVZX0ZJVF9JTlNFVCA9IDI0MDtcblxuY29uc3QgcHJlZmVyc1JlZHVjZWRNb3Rpb24gPSAoKTogYm9vbGVhbiA9PiB7XG4gIHRyeSB7XG4gICAgcmV0dXJuIHdpbmRvdy5tYXRjaE1lZGlhKCcocHJlZmVycy1yZWR1Y2VkLW1vdGlvbjogcmVkdWNlKScpLm1hdGNoZXM7XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxufTtcblxuLyoqIFRoZSBPTkUgc3BlbGxpbmcgb2Ygd2hhdCBlYWNoIG5hbWVkIGJ1c3kgc3RhdGUgc2F5cyBvbiBpdHMgY29udHJvbFxuICogIChSLUlYLTIgLyBSNik6IGV2ZXJ5IHN1cmZhY2UgdGhhdCBuYW1lcyBhIHdhaXQgcmVhZHMgdGhpcyBtYXAg4oCUIGNvdXBsZWRcbiAqICBzdXJmYWNlcyBjYW5ub3QgZHJpZnQgYXBhcnQgb24gYSByZXdvcmQuICovXG5leHBvcnQgY29uc3QgQlVTWV9MQUJFTFMgPSB7XG4gICdpbnNlcnQtaW1hZ2UnOiAnQWRkaW5nIGltYWdl4oCmJyxcbiAgJ25ldy1ib2FyZCc6ICdDcmVhdGluZyBib2FyZOKApicsXG4gICdvcGVuLWJvYXJkJzogJ09wZW5pbmcgYm9hcmTigKYnLFxufSBhcyBjb25zdDtcblxuZXhwb3J0IGZ1bmN0aW9uIHVzZUxvZGVzdGFyKCkge1xuICAvLyBUaGUgY2FudmFzIGVsZW1lbnQgYXJyaXZlcyB2aWEgYSBjYWxsYmFjayByZWYgKGEgZnVuY3Rpb24sIG5vdCBhIHJlZiBvYmplY3RcbiAgLy8gcmVhZCBkdXJpbmcgcmVuZGVyKSBzbyB0aGUgbGlzdGVuZXIgZWZmZWN0IHJlLXJ1bnMgb25jZSBpdCBtb3VudHMuXG4gIGNvbnN0IFtjYW52YXNFbCwgc2V0Q2FudmFzRWxdID0gdXNlU3RhdGU8SFRNTERpdkVsZW1lbnQgfCBudWxsPihudWxsKTtcbiAgY29uc3QgcmVnaXN0ZXJDYW52YXMgPSB1c2VDYWxsYmFjaygoZWw6IEhUTUxEaXZFbGVtZW50IHwgbnVsbCkgPT4gc2V0Q2FudmFzRWwoZWwpLCBbXSk7XG4gIGNvbnN0IGRyYWdSZWYgPSB1c2VSZWY8RHJhZz4obnVsbCk7XG4gIGNvbnN0IHR3ZWVuUmVmID0gdXNlUmVmPG51bWJlciB8IG51bGw+KG51bGwpO1xuICBjb25zdCBob2xkVGltZXIgPSB1c2VSZWY8bnVtYmVyIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IHNwYWNlUmVmID0gdXNlUmVmKGZhbHNlKTtcbiAgY29uc3QgdG9hc3RTZXEgPSB1c2VSZWYoMCk7XG4gIC8vIFN0YWJsZSBpbmRpcmVjdGlvbiBmb3IgdGhlIGR3ZWxsIGF1dG8tYWR2YW5jZTogYGdvU3RlcGAgc2NoZWR1bGVzXG4gIC8vIGBwbGF5TmV4dFJlZi5jdXJyZW50KClgIHNvIHRoZSB0aW1lciBhbHdheXMgY2FsbHMgdGhlIExBVEVTVCBwbGF5TmV4dFxuICAvLyAoYXNzaWduZWQgYWZ0ZXIgaXRzIHVzZUNhbGxiYWNrIGlzIGRlZmluZWQpIOKAlCBicmVha3MgdGhlIGNpcmN1bGFyIGRlcC5cbiAgY29uc3QgcGxheU5leHRSZWYgPSB1c2VSZWY8KCkgPT4gdm9pZD4oKCkgPT4ge30pO1xuXG4gIGNvbnN0IFtzdGF0ZSwgc2V0U3RhdGVdID0gdXNlU3RhdGU8V0JTdGF0ZT4oKCkgPT4gKHtcbiAgICBtb2RlOiAncnVuJyxcbiAgICBsaWdodDogZmFsc2UsXG4gICAgYmc6IEJPQVJELmJhY2tncm91bmQsXG4gICAgdGl0bGU6IEJPQVJELnRpdGxlLFxuICAgIGNhbTogeyBjeDogMjUwLCBjeTogMTUwLCB6b29tOiAwLjYgfSxcbiAgICB2cDogaW5pdGlhbFZpZXdwb3J0KCksXG4gICAgb2JqZWN0czogc2VlZE9iamVjdHMoKSxcbiAgICB2aWV3czogU0VFRF9WSUVXUy5zbGljZSgpLFxuICAgIGpvdXJuZXlzOiBTRUVEX0pPVVJORVlTLFxuICAgIHNlbGVjdGlvbjogW10sXG4gICAgaG92ZXI6IG51bGwsXG4gICAgbWFycXVlZTogbnVsbCxcbiAgICBjb25uZWN0UHJldmlldzogbnVsbCxcbiAgICBjb25uZWN0RnJvbTogbnVsbCxcbiAgICBjb25uZWN0Q3Vyc29yOiBudWxsLFxuICAgIGluc3BlY3Rvck9wZW46IGZhbHNlLFxuICAgIHBhbmVsT3BlbjogZmFsc2UsXG4gICAgcXVpY2tNZW51OiBudWxsLFxuICAgIGpvdXJuZXk6IG51bGwsXG4gICAgdG9hc3RzOiBbXSxcbiAgICBzY3JlZW46IG51bGwsXG4gICAgZGVtb01lbnVPcGVuOiBmYWxzZSxcbiAgICBwYW5uaW5nOiBmYWxzZSxcbiAgICByZWR1Y2VkOiBwcmVmZXJzUmVkdWNlZE1vdGlvbigpLFxuICAgIGJ1c3k6IG51bGwsXG4gICAgbW91bnRzOiBbXSxcbiAgfSkpO1xuXG4gIC8vIE1pcnJvciBjb21taXR0ZWQgc3RhdGUgc28gdGhlIGRvY3VtZW50LWxldmVsIGhhbmRsZXJzIGJyYW5jaCBvbiBmcmVzaCB2YWx1ZXMuXG4gIGNvbnN0IHN0YXRlUmVmID0gdXNlUmVmKHN0YXRlKTtcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBzdGF0ZVJlZi5jdXJyZW50ID0gc3RhdGU7XG4gIH0pO1xuXG4gIGNvbnN0IHVwZGF0ZSA9IHVzZUNhbGxiYWNrKFxuICAgIChwYXRjaDogUGFydGlhbDxXQlN0YXRlPiB8ICgoczogV0JTdGF0ZSkgPT4gUGFydGlhbDxXQlN0YXRlPikpID0+XG4gICAgICBzZXRTdGF0ZSgocHJldikgPT4gKHsgLi4ucHJldiwgLi4uKHR5cGVvZiBwYXRjaCA9PT0gJ2Z1bmN0aW9uJyA/IHBhdGNoKHByZXYpIDogcGF0Y2gpIH0pKSxcbiAgICBbXSxcbiAgKTtcblxuICBjb25zdCBpc01vYmlsZSA9IHVzZUNhbGxiYWNrKCgpID0+IHN0YXRlLnZwLnZ3IDwgTU9CSUxFX0JSRUFLUE9JTlQsIFtzdGF0ZS52cC52d10pO1xuXG4gIC8vIC0tLS0gY2FtZXJhIGhlbHBlcnMgKHJlYWQgbGF0ZXN0IHZpZXdwb3J0IGZyb20gdGhlIHJlZikgLS0tLVxuICBjb25zdCBsb2NhbFBvaW50ID0gdXNlQ2FsbGJhY2soKGU6IHsgY2xpZW50WDogbnVtYmVyOyBjbGllbnRZOiBudW1iZXIgfSk6IFtudW1iZXIsIG51bWJlcl0gPT4ge1xuICAgIGNvbnN0IHZwID0gc3RhdGVSZWYuY3VycmVudC52cDtcbiAgICByZXR1cm4gW2UuY2xpZW50WCAtIHZwLnZsZWZ0LCBlLmNsaWVudFkgLSB2cC52dG9wXTtcbiAgfSwgW10pO1xuXG4gIGNvbnN0IHNldFpvb20gPSB1c2VDYWxsYmFjaygobno6IG51bWJlciwgbHg/OiBudW1iZXIsIGx5PzogbnVtYmVyKSA9PiB7XG4gICAgdXBkYXRlKChzKSA9PiAoeyBjYW06IHpvb21Bcm91bmQocy5jYW0sIHMudnAsIG56LCBseCwgbHkpIH0pKTtcbiAgfSwgW3VwZGF0ZV0pO1xuXG4gIC8vIC0tLS0gdG9hc3RzIC0tLS1cbiAgY29uc3QgZGlzbWlzc1RvYXN0ID0gdXNlQ2FsbGJhY2soKGlkOiBudW1iZXIpID0+IHtcbiAgICB1cGRhdGUoKHMpID0+ICh7IHRvYXN0czogcy50b2FzdHMuZmlsdGVyKCh0KSA9PiB0LmlkICE9PSBpZCkgfSkpO1xuICB9LCBbdXBkYXRlXSk7XG5cbiAgY29uc3QgdG9hc3QgPSB1c2VDYWxsYmFjayhcbiAgICAodGV4dDogc3RyaW5nLCBpY29uID0gJ2NoZWNrJywgb3B0czogUGFydGlhbDxUb2FzdD4gPSB7fSkgPT4ge1xuICAgICAgY29uc3QgaWQgPSArK3RvYXN0U2VxLmN1cnJlbnQ7XG4gICAgICBjb25zdCB0OiBUb2FzdCA9IHsgaWQsIHRleHQsIGljb24sIC4uLm9wdHMgfTtcbiAgICAgIHVwZGF0ZSgocykgPT4gKHsgdG9hc3RzOiBzLnRvYXN0cy5jb25jYXQodCkgfSkpO1xuICAgICAgY29uc3QgdHRsID0gb3B0cy5hY3Rpb25MYWJlbCA/IDkwMDAgOiAzNTAwO1xuICAgICAgc2V0VGltZW91dCgoKSA9PiBkaXNtaXNzVG9hc3QoaWQpLCB0dGwpO1xuICAgIH0sXG4gICAgW3VwZGF0ZSwgZGlzbWlzc1RvYXN0XSxcbiAgKTtcblxuICAvLyAtLS0tIHBlcnNpc3RlbmNlICh0aGUgwqcyLjYgcm91bmQtdHJpcCBzZWFtLCBub3cgbGl2ZSkgLS0tLVxuICAvLyBUaGUgYm9hcmQncyBkdXJhYmxlIHRhcmdldCAoYSBwZXItdXNlciBhcHAgc3BhY2UpIG9uY2UgcmVzb2x2ZWQ7IG51bGwgbWVhbnNcbiAgLy8gd2UgbmV2ZXIgZ290IG9uZSAoc2lnbmVkIG91dCAvIGRlY2xpbmVkKSBhbmQgdGhlIGJvYXJkIGlzIGluIG1lbW9yeSBvbmx5LlxuICBjb25zdCBib2FyZFJlZiA9IHVzZVJlZjxCb2FyZFRhcmdldCB8IG51bGw+KG51bGwpO1xuICAvLyBQZXItb2JqZWN0IGRlYm91bmNlIHRpbWVycyBzbyBpbnNwZWN0b3IgdHlwaW5nIC8gYXJyb3cgbnVkZ2VzIGF1dG9zYXZlIG9uY2VcbiAgLy8gdGhleSBzZXR0bGUsIG5vdCBvbiBldmVyeSBrZXlzdHJva2UuXG4gIGNvbnN0IHNhdmVUaW1lcnMgPSB1c2VSZWY8TWFwPHN0cmluZywgbnVtYmVyPj4obmV3IE1hcCgpKTtcblxuICAvLyBXcml0ZSB0aGUgZ2l2ZW4gb2JqZWN0cycgZmlsZXMsIHRoZW4gcmVwb3J0IHdpdGggb25lIHRvYXN0LiBXaXRoIG5vIGJvYXJkXG4gIC8vIHRoZSBjaGFuZ2UgaXMgaW4gbWVtb3J5IG9ubHkgKHdlIGtlZXAgdGhlIG9wdGltaXN0aWMgbWVzc2FnZSk7IGEgcmVhZC1vbmx5XG4gIC8vIGJvYXJkIHJlcG9ydHMgaW5zdGVhZCBvZiBzaWxlbnRseSBkcm9wcGluZyB0aGUgd3JpdGUuXG4gIGNvbnN0IGNvbW1pdFNhdmUgPSB1c2VDYWxsYmFjayhcbiAgICAob2JqczogV09iamVjdFtdLCBzYXZlZFRleHQ6IHN0cmluZywgc2F2ZWRJY29uID0gJ2NoZWNrJykgPT4ge1xuICAgICAgY29uc3QgdCA9IGJvYXJkUmVmLmN1cnJlbnQ7XG4gICAgICBpZiAoIXQpIHtcbiAgICAgICAgdG9hc3Qoc2F2ZWRUZXh0LCBzYXZlZEljb24pO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAodC5tb2RlID09PSAncm8nKSB7XG4gICAgICAgIHRvYXN0KCdSZWFkLW9ubHkgYm9hcmQgwrcgY2hhbmdlIG5vdCBzYXZlZCcsICdsb2NrJywgeyBpY29uQ29sb3I6ICd2YXIoLS1pbmstMiknIH0pO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBQcm9taXNlLmFsbChvYmpzLm1hcCgobykgPT4gc2F2ZU9iamVjdCh0LCBvKSkpLnRoZW4oXG4gICAgICAgICgpID0+IHRvYXN0KHNhdmVkVGV4dCwgc2F2ZWRJY29uKSxcbiAgICAgICAgKGUpID0+IHRvYXN0KGBTYXZlIGZhaWxlZCR7Y29kZU9mKGUpfWAsICdhbGVydCcsIHsgaWNvbkNvbG9yOiAnI2NhYTI0YScgfSksXG4gICAgICApO1xuICAgIH0sXG4gICAgW3RvYXN0XSxcbiAgKTtcblxuICAvLyBRdWlldCBkZWJvdW5jZWQgYXV0b3NhdmUgZm9yIGNvbnRpbnVvdXMgZWRpdHMgKHR5cGluZywgYXJyb3cta2V5IG51ZGdlcykuXG4gIGNvbnN0IHNjaGVkdWxlU2F2ZSA9IHVzZUNhbGxiYWNrKChpZHM6IHN0cmluZ1tdKSA9PiB7XG4gICAgY29uc3QgdCA9IGJvYXJkUmVmLmN1cnJlbnQ7XG4gICAgaWYgKCF0IHx8IHQubW9kZSA9PT0gJ3JvJykgcmV0dXJuO1xuICAgIGZvciAoY29uc3QgaWQgb2YgaWRzKSB7XG4gICAgICBjb25zdCBwcmV2ID0gc2F2ZVRpbWVycy5jdXJyZW50LmdldChpZCk7XG4gICAgICBpZiAocHJldikgY2xlYXJUaW1lb3V0KHByZXYpO1xuICAgICAgY29uc3QgaGFuZGxlID0gd2luZG93LnNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICBzYXZlVGltZXJzLmN1cnJlbnQuZGVsZXRlKGlkKTtcbiAgICAgICAgY29uc3QgbyA9IHN0YXRlUmVmLmN1cnJlbnQub2JqZWN0cy5maW5kKCh4KSA9PiB4LmlkID09PSBpZCk7XG4gICAgICAgIGlmIChvKSBzYXZlT2JqZWN0KHQsIG8pLmNhdGNoKCgpID0+IHVuZGVmaW5lZCk7XG4gICAgICB9LCA1MDApO1xuICAgICAgc2F2ZVRpbWVycy5jdXJyZW50LnNldChpZCwgaGFuZGxlKTtcbiAgICB9XG4gIH0sIFtdKTtcblxuICAvLyAtLS0tIGNhbWVyYSBhbmltYXRpb24gLS0tLVxuICBjb25zdCBmbHlUbyA9IHVzZUNhbGxiYWNrKFxuICAgICh0YXJnZXQ6IFZpZXdUYXJnZXQgfCBudWxsLCBkdXI/OiBudW1iZXIsIGZpdEg/OiBudW1iZXIpID0+IHtcbiAgICAgIGlmICghdGFyZ2V0KSByZXR1cm47XG4gICAgICAvLyBBIHZpZXcgY2FycnlpbmcgYSByZWN0IG5hbWVzIGEgUkVHSU9OLCBub3QgYSBtYWduaWZpY2F0aW9uOiBmaXQgaXQgdG8gdGhlXG4gICAgICAvLyB1c2FibGUgdmlld3BvcnQgKFIzLTQwMCkuIGZpdEggKHdoZW4gZ2l2ZW4pIGlzIHRoZSB1c2FibGUgaGVpZ2h0IOKAlCB0aGVcbiAgICAgIC8vIGNhcHRpb24gYmFuZCBkdXJpbmcgam91cm5leSBwbGF5YmFjayDigJQgc28gdGhlIHN1YmplY3QgY2xlYXJzIHRoZSBjaHJvbWUuXG4gICAgICBjb25zdCBkZXN0ID0gY2FtZXJhRm9yVGFyZ2V0KHRhcmdldCwgc3RhdGVSZWYuY3VycmVudC52cC52dywgZml0SCA/PyBzdGF0ZVJlZi5jdXJyZW50LnZwLnZoKTtcbiAgICAgIGlmICh0d2VlblJlZi5jdXJyZW50KSBjYW5jZWxBbmltYXRpb25GcmFtZSh0d2VlblJlZi5jdXJyZW50KTtcbiAgICAgIGlmIChzdGF0ZVJlZi5jdXJyZW50LnJlZHVjZWQgfHwgIWR1cikge1xuICAgICAgICB1cGRhdGUoeyBjYW06IGRlc3QgfSk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGZyb20gPSB7IC4uLnN0YXRlUmVmLmN1cnJlbnQuY2FtIH07XG4gICAgICBjb25zdCB0MCA9IHBlcmZvcm1hbmNlLm5vdygpO1xuICAgICAgY29uc3QgZWFzZSA9IChwOiBudW1iZXIpID0+IChwIDwgMC41ID8gNCAqIHAgKiBwICogcCA6IDEgLSBNYXRoLnBvdygtMiAqIHAgKyAyLCAzKSAvIDIpO1xuICAgICAgY29uc3Qgc3RlcCA9IChub3c6IG51bWJlcikgPT4ge1xuICAgICAgICBjb25zdCBwID0gTWF0aC5taW4oMSwgKG5vdyAtIHQwKSAvIGR1cik7XG4gICAgICAgIGNvbnN0IGUgPSBlYXNlKHApO1xuICAgICAgICB1cGRhdGUoe1xuICAgICAgICAgIGNhbToge1xuICAgICAgICAgICAgY3g6IGZyb20uY3ggKyAoZGVzdC5jeCAtIGZyb20uY3gpICogZSxcbiAgICAgICAgICAgIGN5OiBmcm9tLmN5ICsgKGRlc3QuY3kgLSBmcm9tLmN5KSAqIGUsXG4gICAgICAgICAgICB6b29tOiBmcm9tLnpvb20gKyAoZGVzdC56b29tIC0gZnJvbS56b29tKSAqIGUsXG4gICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIGlmIChwIDwgMSkgdHdlZW5SZWYuY3VycmVudCA9IHJlcXVlc3RBbmltYXRpb25GcmFtZShzdGVwKTtcbiAgICAgIH07XG4gICAgICB0d2VlblJlZi5jdXJyZW50ID0gcmVxdWVzdEFuaW1hdGlvbkZyYW1lKHN0ZXApO1xuICAgIH0sXG4gICAgW3VwZGF0ZV0sXG4gICk7XG5cbiAgLy8gLS0tLSB2aWV3cyAmIGpvdXJuZXlzIC0tLS1cbiAgY29uc3QgcmVzb2x2ZVZpZXcgPSB1c2VDYWxsYmFjaygodjogVmlld1RhcmdldCB8IHN0cmluZykgPT4ge1xuICAgIGlmICh0eXBlb2YgdiA9PT0gJ3N0cmluZycpIHJldHVybiBzdGF0ZVJlZi5jdXJyZW50LnZpZXdzLmZpbmQoKHgpID0+IHgubmFtZSA9PT0gdikgPz8gbnVsbDtcbiAgICBjb25zdCB0OiBWaWV3VGFyZ2V0ID0geyBjeDogdi5jeCwgY3k6IHYuY3ksIHpvb206IHYuem9vbSB9O1xuICAgIGlmICh2LncpIHQudyA9IHYudztcbiAgICBpZiAodi5oKSB0LmggPSB2Lmg7XG4gICAgcmV0dXJuIHQ7XG4gIH0sIFtdKTtcblxuICBjb25zdCBzYXZlVmlldyA9IHVzZUNhbGxiYWNrKCgpID0+IHtcbiAgICBjb25zdCBzID0gc3RhdGVSZWYuY3VycmVudDtcbiAgICBjb25zdCB2aWV3OiBWaWV3ID0geyBuYW1lOiBgdmlldy0ke3Mudmlld3MubGVuZ3RoICsgMX1gLCBjeDogcy5jYW0uY3gsIGN5OiBzLmNhbS5jeSwgem9vbTogcy5jYW0uem9vbSB9O1xuICAgIHVwZGF0ZSgoc3QpID0+ICh7IHZpZXdzOiBzdC52aWV3cy5jb25jYXQoW3ZpZXddKSB9KSk7XG4gICAgY29uc3QgdGV4dCA9IGBTYXZlZCB2aWV3cy8ke3ZpZXcubmFtZX0ubWRgO1xuICAgIGNvbnN0IHQgPSBib2FyZFJlZi5jdXJyZW50O1xuICAgIGlmICghdCkge1xuICAgICAgdG9hc3QodGV4dCwgJ3NhdmUnKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKHQubW9kZSA9PT0gJ3JvJykge1xuICAgICAgdG9hc3QoJ1JlYWQtb25seSBib2FyZCDCtyB2aWV3IG5vdCBzYXZlZCcsICdsb2NrJywgeyBpY29uQ29sb3I6ICd2YXIoLS1pbmstMiknIH0pO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBwZXJzaXN0Vmlldyh0LCB2aWV3KS50aGVuKFxuICAgICAgKCkgPT4gdG9hc3QodGV4dCwgJ3NhdmUnKSxcbiAgICAgIChlKSA9PiB0b2FzdChgQ291bGRuJ3Qgc2F2ZSB2aWV3JHtjb2RlT2YoZSl9YCwgJ2FsZXJ0JywgeyBpY29uQ29sb3I6ICcjY2FhMjRhJyB9KSxcbiAgICApO1xuICB9LCBbdXBkYXRlLCB0b2FzdF0pO1xuXG4gIC8qKiBSZW1vdmUgYSB2aWV3IG9uIHRoZSBzdXJmYWNlIHRoYXQgY3JlYXRlcyB0aGVtIChSMy02MDcsIFItSVgtNSkuIEFcbiAgICogIHJlYWQtb25seSBib2FyZCByZWZ1c2VzIEJFRk9SRSBhbnl0aGluZyBkcm9wcyAodGhlIHJvdyBuZXZlciB2YW5pc2hlc1xuICAgKiAgaW50byBhIHJlZnVzYWwpOyBvbiB3cml0YWJsZSBib2FyZHMgdGhlIGRyb3AgaXMgb3B0aW1pc3RpYyBhbmQgYSBmYWlsZWRcbiAgICogIGZpbGUgcmVtb3ZhbCByb2xscyB0aGUgdmlldyBiYWNrIGluLiAqL1xuICBjb25zdCBkZWxldGVWaWV3ID0gdXNlQ2FsbGJhY2soXG4gICAgKG5hbWU6IHN0cmluZykgPT4ge1xuICAgICAgY29uc3QgdCA9IGJvYXJkUmVmLmN1cnJlbnQ7XG4gICAgICBjb25zdCB2aWV3ID0gc3RhdGVSZWYuY3VycmVudC52aWV3cy5maW5kKCh2KSA9PiB2Lm5hbWUgPT09IG5hbWUpO1xuICAgICAgaWYgKCF2aWV3KSByZXR1cm47XG4gICAgICBpZiAodCAmJiB0Lm1vZGUgPT09ICdybycpIHtcbiAgICAgICAgdG9hc3QoJ1JlYWQtb25seSBib2FyZCDCtyB2aWV3IG5vdCByZW1vdmVkJywgJ2xvY2snLCB7IGljb25Db2xvcjogJ3ZhcigtLWluay0yKScgfSk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIHVwZGF0ZSgocykgPT4gKHsgdmlld3M6IHMudmlld3MuZmlsdGVyKCh2KSA9PiB2Lm5hbWUgIT09IG5hbWUpIH0pKTtcbiAgICAgIGlmICghdCkge1xuICAgICAgICB0b2FzdChgUmVtb3ZlZCB2aWV3cy8ke25hbWV9Lm1kYCwgJ3RyYXNoJyk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIHJlbW92ZVZpZXcodCwgbmFtZSkudGhlbihcbiAgICAgICAgKCkgPT4gdG9hc3QoYFJlbW92ZWQgdmlld3MvJHtuYW1lfS5tZGAsICd0cmFzaCcpLFxuICAgICAgICAoZSkgPT4ge1xuICAgICAgICAgIC8vIFJvbGwgdGhlIG9wdGltaXN0aWMgZHJvcCBiYWNrIOKAlCB0aGUgZmlsZSBzdXJ2aXZlZCwgc28gbXVzdCB0aGUgcm93LlxuICAgICAgICAgIHVwZGF0ZSgocykgPT4gKHMudmlld3Muc29tZSgodikgPT4gdi5uYW1lID09PSBuYW1lKSA/IHt9IDogeyB2aWV3czogcy52aWV3cy5jb25jYXQoW3ZpZXddKSB9KSk7XG4gICAgICAgICAgdG9hc3QoYENvdWxkbid0IHJlbW92ZSB2aWV3JHtjb2RlT2YoZSl9YCwgJ2FsZXJ0JywgeyBpY29uQ29sb3I6ICcjY2FhMjRhJyB9KTtcbiAgICAgICAgfSxcbiAgICAgICk7XG4gICAgfSxcbiAgICBbdXBkYXRlLCB0b2FzdF0sXG4gICk7XG5cbiAgY29uc3QgYWRkSm91cm5leVN0ZXAgPSB1c2VDYWxsYmFjayhcbiAgICAoamlkOiBzdHJpbmcpID0+IHtcbiAgICAgIGNvbnN0IHMgPSBzdGF0ZVJlZi5jdXJyZW50O1xuICAgICAgY29uc3QgaiA9IHMuam91cm5leXMuZmluZCgoeCkgPT4geC5pZCA9PT0gamlkKTtcbiAgICAgIGlmICghaikgcmV0dXJuO1xuICAgICAgY29uc3QgbmV4dDogSm91cm5leSA9IHsgLi4uaiwgc3RlcHM6IGouc3RlcHMuY29uY2F0KFt7IHZpZXc6IHsgY3g6IHMuY2FtLmN4LCBjeTogcy5jYW0uY3ksIHpvb206IHMuY2FtLnpvb20gfSB9XSkgfTtcbiAgICAgIHVwZGF0ZSgoc3QpID0+ICh7IGpvdXJuZXlzOiBzdC5qb3VybmV5cy5tYXAoKHgpID0+ICh4LmlkID09PSBqaWQgPyBuZXh0IDogeCkpIH0pKTtcbiAgICAgIGNvbnN0IHRleHQgPSBgQWRkZWQgc3RlcCAke25leHQuc3RlcHMubGVuZ3RofSB0byAke2oudGl0bGV9IMK3IHNhdmVkIHRvICR7ai5pZH0ubWR4YDtcbiAgICAgIGNvbnN0IHQgPSBib2FyZFJlZi5jdXJyZW50O1xuICAgICAgaWYgKCF0KSB7XG4gICAgICAgIHRvYXN0KHRleHQsICdwbHVzJyk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGlmICh0Lm1vZGUgPT09ICdybycpIHtcbiAgICAgICAgdG9hc3QoJ1JlYWQtb25seSBib2FyZCDCtyBzdGVwIG5vdCBzYXZlZCcsICdsb2NrJywgeyBpY29uQ29sb3I6ICd2YXIoLS1pbmstMiknIH0pO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBwZXJzaXN0Sm91cm5leSh0LCBuZXh0KS50aGVuKFxuICAgICAgICAoKSA9PiB0b2FzdCh0ZXh0LCAncGx1cycpLFxuICAgICAgICAoZSkgPT4gdG9hc3QoYENvdWxkbid0IHNhdmUgam91cm5leSR7Y29kZU9mKGUpfWAsICdhbGVydCcsIHsgaWNvbkNvbG9yOiAnI2NhYTI0YScgfSksXG4gICAgICApO1xuICAgIH0sXG4gICAgW3VwZGF0ZSwgdG9hc3RdLFxuICApO1xuXG4gIGNvbnN0IGdvU3RlcCA9IHVzZUNhbGxiYWNrKFxuICAgIChqOiBKb3VybmV5LCBpZHg6IG51bWJlciwgaW5zdGFudD86IGJvb2xlYW4pID0+IHtcbiAgICAgIGNvbnN0IHMgPSBqLnN0ZXBzW2lkeF07XG4gICAgICBjb25zdCB2ID0gcmVzb2x2ZVZpZXcocy52aWV3KTtcbiAgICAgIGlmICh2KSBmbHlUbyh2LCBpbnN0YW50ID8gMCA6IHMuZHVyYXRpb24gPz8gODAwLCBzdGF0ZVJlZi5jdXJyZW50LnZwLnZoIC0gSk9VUk5FWV9GSVRfSU5TRVQpO1xuICAgICAgLy8gRHdlbGwgKFIzLTQwMik6IGEgc3RlcCBjYXJyeWluZyBgaG9sZGAgcGF1c2VzIHRoYXQgbG9uZyBhZnRlciBhcnJpdmluZyxcbiAgICAgIC8vIHRoZW4gQVVUTy1hZHZhbmNlcy4gQ2xlYXJlZCBieSBhbnkgdmlld2VyIGNvbnRyb2wgKG5leHQvcHJldi9zZWVrL2V4aXQpLlxuICAgICAgLy8gVW5kZXIgcHJlZmVycy1yZWR1Y2VkLW1vdGlvbiB0aGUgam91cm5leSBzdGF5cyBpbnB1dC1kcml2ZW4g4oCUIG1hdGNoaW5nXG4gICAgICAvLyBmbHlUbydzIGN1dCBvZiB0aGUgdHdlZW4g4oCUIHNvIGEgdmlld2VyIGlzIG5ldmVyIGFkdmFuY2VkIHVucHJvbXB0ZWQuXG4gICAgICBpZiAoaG9sZFRpbWVyLmN1cnJlbnQpIHtcbiAgICAgICAgY2xlYXJUaW1lb3V0KGhvbGRUaW1lci5jdXJyZW50KTtcbiAgICAgICAgaG9sZFRpbWVyLmN1cnJlbnQgPSBudWxsO1xuICAgICAgfVxuICAgICAgaWYgKHMuaG9sZCAmJiAhc3RhdGVSZWYuY3VycmVudC5yZWR1Y2VkKSB7XG4gICAgICAgIGhvbGRUaW1lci5jdXJyZW50ID0gd2luZG93LnNldFRpbWVvdXQoKCkgPT4gcGxheU5leHRSZWYuY3VycmVudCgpLCBzLmhvbGQpO1xuICAgICAgfVxuICAgIH0sXG4gICAgW3Jlc29sdmVWaWV3LCBmbHlUb10sXG4gICk7XG5cbiAgY29uc3QgcGxheUpvdXJuZXkgPSB1c2VDYWxsYmFjayhcbiAgICAoamlkOiBzdHJpbmcpID0+IHtcbiAgICAgIGNvbnN0IGogPSBzdGF0ZVJlZi5jdXJyZW50LmpvdXJuZXlzLmZpbmQoKHgpID0+IHguaWQgPT09IGppZCk7XG4gICAgICBpZiAoIWopIHJldHVybjtcbiAgICAgIGlmIChob2xkVGltZXIuY3VycmVudCkge1xuICAgICAgICBjbGVhclRpbWVvdXQoaG9sZFRpbWVyLmN1cnJlbnQpO1xuICAgICAgICBob2xkVGltZXIuY3VycmVudCA9IG51bGw7XG4gICAgICB9XG4gICAgICB1cGRhdGUoeyBqb3VybmV5OiB7IGppZCwgaWR4OiAwIH0sIHBhbmVsT3BlbjogZmFsc2UsIGluc3BlY3Rvck9wZW46IGZhbHNlIH0pO1xuICAgICAgZ29TdGVwKGosIDAsIHRydWUpO1xuICAgIH0sXG4gICAgW3VwZGF0ZSwgZ29TdGVwXSxcbiAgKTtcblxuICBjb25zdCBwbGF5RXhpdCA9IHVzZUNhbGxiYWNrKCgpID0+IHtcbiAgICBpZiAodHdlZW5SZWYuY3VycmVudCkgY2FuY2VsQW5pbWF0aW9uRnJhbWUodHdlZW5SZWYuY3VycmVudCk7XG4gICAgaWYgKGhvbGRUaW1lci5jdXJyZW50KSB7XG4gICAgICBjbGVhclRpbWVvdXQoaG9sZFRpbWVyLmN1cnJlbnQpO1xuICAgICAgaG9sZFRpbWVyLmN1cnJlbnQgPSBudWxsO1xuICAgIH1cbiAgICB1cGRhdGUoeyBqb3VybmV5OiBudWxsIH0pO1xuICB9LCBbdXBkYXRlXSk7XG5cbiAgY29uc3QgcGxheU5leHQgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgY29uc3QganIgPSBzdGF0ZVJlZi5jdXJyZW50LmpvdXJuZXk7XG4gICAgaWYgKCFqcikgcmV0dXJuO1xuICAgIGlmIChob2xkVGltZXIuY3VycmVudCkge1xuICAgICAgY2xlYXJUaW1lb3V0KGhvbGRUaW1lci5jdXJyZW50KTtcbiAgICAgIGhvbGRUaW1lci5jdXJyZW50ID0gbnVsbDtcbiAgICB9XG4gICAgY29uc3QgaiA9IHN0YXRlUmVmLmN1cnJlbnQuam91cm5leXMuZmluZCgoeCkgPT4geC5pZCA9PT0ganIuamlkKTtcbiAgICBpZiAoIWopIHJldHVybjtcbiAgICBjb25zdCBuaSA9IGpyLmlkeCArIDE7XG4gICAgaWYgKG5pID49IGouc3RlcHMubGVuZ3RoKSB7XG4gICAgICBwbGF5RXhpdCgpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB1cGRhdGUoeyBqb3VybmV5OiB7IC4uLmpyLCBpZHg6IG5pIH0gfSk7XG4gICAgZ29TdGVwKGosIG5pKTtcbiAgfSwgW3VwZGF0ZSwgZ29TdGVwLCBwbGF5RXhpdF0pO1xuICAvLyBLZWVwIHRoZSBkd2VsbCB0aW1lcidzIGluZGlyZWN0aW9uIHBvaW50ZWQgYXQgdGhlIGN1cnJlbnQgcGxheU5leHQuXG4gIHBsYXlOZXh0UmVmLmN1cnJlbnQgPSBwbGF5TmV4dDtcblxuICBjb25zdCBwbGF5UHJldiA9IHVzZUNhbGxiYWNrKCgpID0+IHtcbiAgICBjb25zdCBqciA9IHN0YXRlUmVmLmN1cnJlbnQuam91cm5leTtcbiAgICBpZiAoIWpyKSByZXR1cm47XG4gICAgaWYgKGhvbGRUaW1lci5jdXJyZW50KSB7XG4gICAgICBjbGVhclRpbWVvdXQoaG9sZFRpbWVyLmN1cnJlbnQpO1xuICAgICAgaG9sZFRpbWVyLmN1cnJlbnQgPSBudWxsO1xuICAgIH1cbiAgICBjb25zdCBqID0gc3RhdGVSZWYuY3VycmVudC5qb3VybmV5cy5maW5kKCh4KSA9PiB4LmlkID09PSBqci5qaWQpO1xuICAgIGlmICghaikgcmV0dXJuO1xuICAgIGNvbnN0IG5pID0gTWF0aC5tYXgoMCwganIuaWR4IC0gMSk7XG4gICAgdXBkYXRlKHsgam91cm5leTogeyAuLi5qciwgaWR4OiBuaSB9IH0pO1xuICAgIGdvU3RlcChqLCBuaSk7XG4gIH0sIFt1cGRhdGUsIGdvU3RlcF0pO1xuXG4gIGNvbnN0IHBsYXlTZWVrID0gdXNlQ2FsbGJhY2soXG4gICAgKGlkeDogbnVtYmVyKSA9PiB7XG4gICAgICBjb25zdCBqciA9IHN0YXRlUmVmLmN1cnJlbnQuam91cm5leTtcbiAgICAgIGlmICghanIpIHJldHVybjtcbiAgICAgIGlmIChob2xkVGltZXIuY3VycmVudCkge1xuICAgICAgICBjbGVhclRpbWVvdXQoaG9sZFRpbWVyLmN1cnJlbnQpO1xuICAgICAgICBob2xkVGltZXIuY3VycmVudCA9IG51bGw7XG4gICAgICB9XG4gICAgICBjb25zdCBqID0gc3RhdGVSZWYuY3VycmVudC5qb3VybmV5cy5maW5kKCh4KSA9PiB4LmlkID09PSBqci5qaWQpO1xuICAgICAgaWYgKCFqKSByZXR1cm47XG4gICAgICB1cGRhdGUoeyBqb3VybmV5OiB7IC4uLmpyLCBpZHggfSB9KTtcbiAgICAgIGdvU3RlcChqLCBpZHgpO1xuICAgIH0sXG4gICAgW3VwZGF0ZSwgZ29TdGVwXSxcbiAgKTtcblxuICAvLyAtLS0tIG11dGF0aW9ucyAtLS0tXG4gIGNvbnN0IHBhdGNoU2VsID0gdXNlQ2FsbGJhY2soXG4gICAgKHBhdGNoOiBQYXJ0aWFsPFdPYmplY3Q+KSA9PiB7XG4gICAgICB1cGRhdGUoKHMpID0+ICh7IG9iamVjdHM6IHMub2JqZWN0cy5tYXAoKG8pID0+IChzLnNlbGVjdGlvbi5pbmNsdWRlcyhvLmlkKSA/IHsgLi4ubywgLi4ucGF0Y2ggfSA6IG8pKSB9KSk7XG4gICAgICBzY2hlZHVsZVNhdmUoc3RhdGVSZWYuY3VycmVudC5zZWxlY3Rpb24pO1xuICAgIH0sXG4gICAgW3VwZGF0ZSwgc2NoZWR1bGVTYXZlXSxcbiAgKTtcblxuICAvLyAtLS0tIHNlbGVjdGlvbjogb25lIGFjdGlvbiBmb3IgcG9pbnRlciBhbmQga2V5Ym9hcmQgKFIzLTYwNykgLS0tLVxuICBjb25zdCBzZWxlY3QgPSB1c2VDYWxsYmFjayhcbiAgICAoaWQ6IHN0cmluZywgYWRkaXRpdmUgPSBmYWxzZSkgPT4ge1xuICAgICAgdXBkYXRlKChzKSA9PiAoe1xuICAgICAgICBzZWxlY3Rpb246IGFwcGx5U2VsZWN0aW9uKHMuc2VsZWN0aW9uLCBpZCwgYWRkaXRpdmUpLFxuICAgICAgICBpbnNwZWN0b3JPcGVuOiB0cnVlLFxuICAgICAgICBxdWlja01lbnU6IG51bGwsXG4gICAgICB9KSk7XG4gICAgfSxcbiAgICBbdXBkYXRlXSxcbiAgKTtcblxuICAvKiogQ2xvc2UgdGhlIHF1aWNrLWNyZWF0ZSBtZW51IChpdHMgRXNjYXBlL2JsdXIgcGF0aCwgUjMtNjA3KS4gKi9cbiAgY29uc3QgY2xvc2VRdWlja01lbnUgPSB1c2VDYWxsYmFjaygoKSA9PiB1cGRhdGUoeyBxdWlja01lbnU6IG51bGwgfSksIFt1cGRhdGVdKTtcblxuICBjb25zdCBkZWxldGVTZWxlY3Rpb24gPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgY29uc3Qgc2VsID0gc3RhdGVSZWYuY3VycmVudC5zZWxlY3Rpb24uc2xpY2UoKTtcbiAgICBpZiAoIXNlbC5sZW5ndGgpIHJldHVybjtcbiAgICBjb25zdCByZW1vdmVkID0gc3RhdGVSZWYuY3VycmVudC5vYmplY3RzLmZpbHRlcigobykgPT4gc2VsLmluY2x1ZGVzKG8uaWQpKTtcbiAgICB1cGRhdGUoKHMpID0+ICh7IG9iamVjdHM6IHMub2JqZWN0cy5maWx0ZXIoKG8pID0+ICFzZWwuaW5jbHVkZXMoby5pZCkpLCBzZWxlY3Rpb246IFtdIH0pKTtcbiAgICAvLyBEZWxldGUgaXMgYSByZW5hbWUgaW50byBvYmplY3RzLy50cmFzaC8gd2l0aCBhIDEwcyB1bmRvIChzcGVjIMKnNC4yKS5cbiAgICBjb25zdCB0ID0gYm9hcmRSZWYuY3VycmVudDtcbiAgICBpZiAodCAmJiB0Lm1vZGUgIT09ICdybycpIHtcbiAgICAgIFByb21pc2UuYWxsKHNlbC5tYXAoKGlkKSA9PiB0cmFzaE9iamVjdCh0LCBpZCkpKS5jYXRjaCgoZSkgPT5cbiAgICAgICAgdG9hc3QoYERlbGV0ZSBmYWlsZWQke2NvZGVPZihlKX1gLCAnYWxlcnQnLCB7IGljb25Db2xvcjogJyNjYWEyNGEnIH0pLFxuICAgICAgKTtcbiAgICB9XG4gICAgdG9hc3QoYCR7c2VsLmxlbmd0aCA+IDEgPyBgJHtzZWwubGVuZ3RofSBvYmplY3RzYCA6ICdPYmplY3QnfSBtb3ZlZCB0byAudHJhc2hgLCAndHJhc2gnLCB7XG4gICAgICBhY3Rpb25MYWJlbDogJ1VuZG8nLFxuICAgICAgb25BY3Rpb246ICgpID0+IHtcbiAgICAgICAgdXBkYXRlKChzKSA9PiAoeyBvYmplY3RzOiBzLm9iamVjdHMuY29uY2F0KHJlbW92ZWQpIH0pKTtcbiAgICAgICAgaWYgKHQgJiYgdC5tb2RlICE9PSAncm8nKSB7XG4gICAgICAgICAgUHJvbWlzZS5hbGwocmVtb3ZlZC5tYXAoKG8pID0+IHJlc3RvcmVPYmplY3QodCwgby5pZCkpKS5jYXRjaCgoKSA9PiB1bmRlZmluZWQpO1xuICAgICAgICB9XG4gICAgICB9LFxuICAgIH0pO1xuICB9LCBbdXBkYXRlLCB0b2FzdF0pO1xuXG4gIGNvbnN0IGNyZWF0ZU9iamVjdCA9IHVzZUNhbGxiYWNrKFxuICAgIChraW5kOiBPYmplY3RLaW5kLCB3eDogbnVtYmVyLCB3eTogbnVtYmVyKSA9PiB7XG4gICAgICBjb25zdCBvOiBXT2JqZWN0ID0ge1xuICAgICAgICBpZDogZ2VuZXJhdGVJZChraW5kID09PSAnbm90ZScgPyAnbm90ZScgOiBraW5kKSxcbiAgICAgICAga2luZCxcbiAgICAgICAgeDogd3ggLSAxMDAsXG4gICAgICAgIHk6IHd5IC0gNzQsXG4gICAgICAgIHc6IDIwMCxcbiAgICAgICAgaDogMTQ4LFxuICAgICAgICByb3Q6IDAsXG4gICAgICAgIHNjYWxlOiAxLFxuICAgICAgICB6OiAzLFxuICAgICAgICBjb25uZWN0aW9uczogW10sXG4gICAgICB9O1xuICAgICAgaWYgKGtpbmQgPT09ICdub3RlJykge1xuICAgICAgICBvLmNvbG9yID0gJ2xlbW9uJztcbiAgICAgICAgby50aXRsZSA9ICdOZXcgbm90ZSc7XG4gICAgICB9IGVsc2UgaWYgKGtpbmQgPT09ICdwcm9zZScpIHtcbiAgICAgICAgby50aXRsZSA9ICdQcm9zZSc7XG4gICAgICAgIG8uYm9keSA9ICdXcml0ZSBoZXJl4oCmJztcbiAgICAgICAgby53ID0gMjYwO1xuICAgICAgICBvLmggPSAxNjA7XG4gICAgICB9IGVsc2UgaWYgKGtpbmQgPT09ICdsYWJlbCcpIHtcbiAgICAgICAgby50aXRsZSA9ICdMYWJlbCc7XG4gICAgICAgIG8udyA9IDMyMDtcbiAgICAgICAgby5oID0gODA7XG4gICAgICAgIG8ueiA9IDE7XG4gICAgICB9IGVsc2UgaWYgKGtpbmQgPT09ICdzaGFwZScpIHtcbiAgICAgICAgby5zaGFwZSA9ICdyZWN0JztcbiAgICAgICAgby50aXRsZSA9ICcnO1xuICAgICAgICBvLncgPSAyMDA7XG4gICAgICAgIG8uaCA9IDE0MDtcbiAgICAgIH0gZWxzZSBpZiAoa2luZCA9PT0gJ2ZyYW1lJykge1xuICAgICAgICBvLnRpdGxlID0gJ0ZyYW1lJztcbiAgICAgICAgby53ID0gMzYwO1xuICAgICAgICBvLmggPSAzMDA7XG4gICAgICAgIG8ueiA9IDE7XG4gICAgICB9IGVsc2UgaWYgKGtpbmQgPT09ICdpbWcnKSB7XG4gICAgICAgIG8ubG9hZGVkID0gZmFsc2U7XG4gICAgICAgIG8udGl0bGUgPSAnSW1hZ2UnO1xuICAgICAgfSBlbHNlIGlmIChraW5kID09PSAnY29tcG9uZW50Jykge1xuICAgICAgICBvLnRpdGxlID0gJzxDb21wb25lbnQvPic7XG4gICAgICB9XG4gICAgICB1cGRhdGUoKHMpID0+ICh7XG4gICAgICAgIG9iamVjdHM6IHMub2JqZWN0cy5jb25jYXQobyksXG4gICAgICAgIHNlbGVjdGlvbjogW28uaWRdLFxuICAgICAgICBxdWlja01lbnU6IG51bGwsXG4gICAgICAgIGluc3BlY3Rvck9wZW46IHRydWUsXG4gICAgICAgIG1vZGU6ICdlZGl0JyxcbiAgICAgIH0pKTtcbiAgICAgIGNvbW1pdFNhdmUoW29dLCBgQ3JlYXRlZCBvYmplY3RzLyR7by5pZH0ubWR4YCwgJ3BsdXMnKTtcbiAgICB9LFxuICAgIFt1cGRhdGUsIGNvbW1pdFNhdmVdLFxuICApO1xuXG4gIC8vIOKUgOKUgCBwaWNrLWZpbGUgZmxvd3MgKHNwZWMgwqc2LjEgT3Blbi9OZXcgYm9hcmQsIMKnNC4yIEluc2VydCBpbWFnZSkg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIC8vIEVhY2ggaW52b2tlcyB0aGUgcGxhdGZvcm0gcGlja2VyIG92ZXIgYSBgY2FwRGlyYCBvZiB0aGUgYm9hcmQncyBzcGFjZSAodGhlXG4gIC8vIG9ubHkgYXV0aG9yaXR5IHdlIGhvbGQpLCB0aGVuIG1hcHMgdGhlIHJldHVybmVkIGAocm9vdCwgcmVsUGF0aClgIFBBVEggYmFja1xuICAvLyBvbnRvIG91ciBPV04gbW91bnQg4oCUIHJlLXZhbGlkYXRpbmcgaXQgZmlyc3QgKGRlZmVuc2UgaW4gZGVwdGgsIMKnMS4zKS5cblxuICAvKiogSW5zZXJ0IGFuIGltYWdlOiBwaWNrIGEgZmlsZSwgY29weSBpdCBpbnRvIHRoZSBib2FyZCdzIGBhc3NldHMvYCwgZHJvcCBhblxuICAgKiAgPEltZz4gb2JqZWN0IGF0IHRoZSB3b3JsZCBwb2ludC4gU2VsZi1jb250YWluZWQgcGVyIMKnNC4yLiBUaGUgcGljayBpc1xuICAgKiAgbmFtZWQtYnVzeSBvbiB0aGUgY29uZmlybWluZyBjb250cm9sIHVudGlsIGl0IHNldHRsZXMgKFItSVgtMikuICovXG4gIGNvbnN0IGluc2VydEltYWdlID0gdXNlQ2FsbGJhY2soXG4gICAgYXN5bmMgKHd4OiBudW1iZXIsIHd5OiBudW1iZXIpID0+IHtcbiAgICAgIGNvbnN0IHRhcmdldCA9IGJvYXJkUmVmLmN1cnJlbnQ7XG4gICAgICBpZiAoIXRhcmdldCkge1xuICAgICAgICB0b2FzdCgnU2lnbiBpbiB0byBpbnNlcnQgaW1hZ2VzIGludG8geW91ciBib2FyZC4nLCAnc2F2ZScsIHsgaWNvbkNvbG9yOiAndmFyKC0taW5rLTIpJyB9KTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgdXBkYXRlKHsgYnVzeTogJ2luc2VydC1pbWFnZScgfSk7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBwaWNrRmlsZSh7XG4gICAgICAgICAgbW9kZTogJ29wZW4tZmlsZScsXG4gICAgICAgICAgcm9vdHM6IFthd2FpdCBib2FyZFNwYWNlUm9vdCh0YXJnZXQpXSxcbiAgICAgICAgICByb290TGFiZWxzOiBbJ1RoaXMgYm9hcmTigJlzIHNwYWNlJ10sXG4gICAgICAgICAgcm9vdE1vZGVzOiBbdGFyZ2V0Lm1vZGVdLFxuICAgICAgICAgIHRpdGxlOiAnSW5zZXJ0IGltYWdlJyxcbiAgICAgICAgICBmaWx0ZXJzOiBbXG4gICAgICAgICAgICB7IGxhYmVsOiAnSW1hZ2VzJywgZXh0ZW5zaW9uczogWycucG5nJywgJy5qcGcnLCAnLmpwZWcnLCAnLmdpZicsICcud2VicCcsICcuc3ZnJywgJy5hdmlmJ10gfSxcbiAgICAgICAgICAgIHsgbGFiZWw6ICdBbGwgZmlsZXMnLCBleHRlbnNpb25zOiBbXSB9LFxuICAgICAgICAgIF0sXG4gICAgICAgIH0pO1xuICAgICAgICBpZiAoIXJlcykgcmV0dXJuOyAvLyBjYW5jZWxsZWQg4oCUIG5vIHRvYXN0IHNwYW1cbiAgICAgICAgY29uc3QgcmVsID0gc2FmZVJlbChyZXMucmVsUGF0aCk7XG4gICAgICAgIGlmICghcmVsKSB7XG4gICAgICAgICAgdG9hc3QoJ1RoYXQgZmlsZSBjYW7igJl0IGJlIGluc2VydGVkLicsICdhbGVydCcsIHsgaWNvbkNvbG9yOiAnI2NhYTI0YScgfSk7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IG5hbWUgPSBhd2FpdCBjb3B5SW50b0Fzc2V0cyh0YXJnZXQsIHJlbCk7XG4gICAgICAgIGNvbnN0IG86IFdPYmplY3QgPSB7XG4gICAgICAgICAgaWQ6IGdlbmVyYXRlSWQoJ2ltZycpLFxuICAgICAgICAgIGtpbmQ6ICdpbWcnLFxuICAgICAgICAgIHg6IHd4IC0gMTMwLFxuICAgICAgICAgIHk6IHd5IC0gOTAsXG4gICAgICAgICAgdzogMjYwLFxuICAgICAgICAgIGg6IDE4MCxcbiAgICAgICAgICByb3Q6IDAsXG4gICAgICAgICAgc2NhbGU6IDEsXG4gICAgICAgICAgejogMyxcbiAgICAgICAgICB0aXRsZTogbmFtZSxcbiAgICAgICAgICBib2R5OiBgPEltZyBzcmM9XCJhc3NldHMvJHtuYW1lfVwiIC8+YCxcbiAgICAgICAgICBsb2FkZWQ6IHRydWUsXG4gICAgICAgICAgY29ubmVjdGlvbnM6IFtdLFxuICAgICAgICB9O1xuICAgICAgICB1cGRhdGUoKHMpID0+ICh7XG4gICAgICAgICAgb2JqZWN0czogcy5vYmplY3RzLmNvbmNhdChvKSxcbiAgICAgICAgICBzZWxlY3Rpb246IFtvLmlkXSxcbiAgICAgICAgICBxdWlja01lbnU6IG51bGwsXG4gICAgICAgICAgaW5zcGVjdG9yT3BlbjogdHJ1ZSxcbiAgICAgICAgICBtb2RlOiAnZWRpdCcsXG4gICAgICAgICAgc2NyZWVuOiBudWxsLFxuICAgICAgICB9KSk7XG4gICAgICAgIGNvbW1pdFNhdmUoW29dLCBgSW5zZXJ0ZWQgYXNzZXRzLyR7bmFtZX1gLCAnaW1hZ2UnKTtcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgdG9hc3QoYENvdWxkbuKAmXQgaW5zZXJ0IGltYWdlJHtjb2RlT2YoZSl9YCwgJ2FsZXJ0JywgeyBpY29uQ29sb3I6ICcjY2FhMjRhJyB9KTtcbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIHVwZGF0ZSh7IGJ1c3k6IG51bGwgfSk7XG4gICAgICB9XG4gICAgfSxcbiAgICBbdG9hc3QsIHVwZGF0ZSwgY29tbWl0U2F2ZV0sXG4gICk7XG5cbiAgLyoqIFJlLXBvaW50IHRoZSBhY3RpdmUgYm9hcmQgdG8gYHRhcmdldGAgYW5kIGh5ZHJhdGUgdGhlIGNhbnZhcyBmcm9tIGl0LiAqL1xuICBjb25zdCBsb2FkQm9hcmRJbnRvID0gdXNlQ2FsbGJhY2soXG4gICAgYXN5bmMgKHRhcmdldDogQm9hcmRUYXJnZXQpID0+IHtcbiAgICAgIGNvbnN0IGJvYXJkID0gYXdhaXQgbG9hZEJvYXJkKHRhcmdldCk7XG4gICAgICBib2FyZFJlZi5jdXJyZW50ID0gdGFyZ2V0O1xuICAgICAgLy8gVGhlIGJvYXJkLm1kIG1hbmlmZXN0IG5hbWVzIHRoZSBib2FyZCAoc3BlYyDCpzIuNCkg4oCUIGEgYm9hcmQgaXMgYSBmb2xkZXJcbiAgICAgIC8vIHRoYXQgY2FuIHN0YXRlIGl0cyBvd24gbmFtZTsgZmFsbCBiYWNrIHRvIHRoZSBzZWVkIG9ubHkgd2hlbiBhYnNlbnQuXG4gICAgICAvLyBBIG1hbmlmZXN0IHNjaGVtYSBuZXdlciB0aGFuIHRoaXMgcmVhZGVyIG1hcmtzIHRoZSBib2FyZCByZWFkb25seSAodGhlXG4gICAgICAvLyBgcmVhZG9ubHlgIGRlZ3JhZGVkIHN0YXRlKSwgdW5sZXNzIHRoZSBtb3VudCBpdHNlbGYgaXMgYWxyZWFkeSByby5cbiAgICAgIGNvbnN0IHJlYWRvbmx5ID0gdGFyZ2V0Lm1vZGUgPT09ICdybycgfHwgKHR5cGVvZiBib2FyZC5zY2hlbWEgPT09ICdudW1iZXInICYmIGJvYXJkLnNjaGVtYSA+IFNVUFBPUlRFRF9TQ0hFTUEpO1xuICAgICAgdXBkYXRlKHtcbiAgICAgICAgb2JqZWN0czogYm9hcmQub2JqZWN0cyxcbiAgICAgICAgdmlld3M6IGJvYXJkLnZpZXdzLmxlbmd0aCA/IGJvYXJkLnZpZXdzIDogU0VFRF9WSUVXUy5zbGljZSgpLFxuICAgICAgICBqb3VybmV5czogYm9hcmQuam91cm5leXMubGVuZ3RoID8gYm9hcmQuam91cm5leXMgOiBTRUVEX0pPVVJORVlTLFxuICAgICAgICBiZzogYm9hcmQuYmFja2dyb3VuZCA/PyBzdGF0ZVJlZi5jdXJyZW50LmJnLFxuICAgICAgICB0aXRsZTogYm9hcmQudGl0bGUgPz8gc3RhdGVSZWYuY3VycmVudC50aXRsZSxcbiAgICAgICAgbW9kZTogcmVhZG9ubHkgPyAncnVuJyA6IHN0YXRlUmVmLmN1cnJlbnQubW9kZSxcbiAgICAgICAgc2VsZWN0aW9uOiBbXSxcbiAgICAgICAgLy8gQSBrZXlib2FyZCBjb25uZWN0IGFybWVkIGFnYWluc3QgdGhlIHByZXZpb3VzIGJvYXJkIG11c3Qgbm90IHN1cnZpdmVcbiAgICAgICAgLy8gdGhlIHN3YXAgKFIzLTYwNyByZXZpZXcpOiBpdHMgc291cmNlIGlkIGlzIHN0YWxlIHRoZSBtb21lbnQgb2JqZWN0c1xuICAgICAgICAvLyBhcmUgcmVwbGFjZWQuXG4gICAgICAgIGNvbm5lY3RGcm9tOiBudWxsLFxuICAgICAgICBjb25uZWN0Q3Vyc29yOiBudWxsLFxuICAgICAgICBpbnNwZWN0b3JPcGVuOiBmYWxzZSxcbiAgICAgICAgc2NyZWVuOiBudWxsLFxuICAgICAgfSk7XG4gICAgfSxcbiAgICBbdXBkYXRlXSxcbiAgKTtcblxuICAvKiogT3BlbiBhbiBleGlzdGluZyBib2FyZCBmb2xkZXIgaW4gYHNwYWNlYDogcGljayBhIGZvbGRlciwgcmVxdWlyZSBhIGJvYXJkLm1kLFxuICAgKiAgdGhlbiBsb2FkIGl0IGFzIHRoZSBhY3RpdmUgYm9hcmQuIE5hbWVkLWJ1c3kgd2hpbGUgdGhlIHBpY2sgaXMgb3V0LiAqL1xuICBjb25zdCBvcGVuQm9hcmRJbiA9IHVzZUNhbGxiYWNrKFxuICAgIGFzeW5jIChzcGFjZTogQm9hcmRUYXJnZXQpID0+IHtcbiAgICAgIHVwZGF0ZSh7IGJ1c3k6ICdvcGVuLWJvYXJkJyB9KTtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IHBpY2tGaWxlKHtcbiAgICAgICAgICBtb2RlOiAnb3Blbi1mb2xkZXInLFxuICAgICAgICAgIHJvb3RzOiBbYXdhaXQgYm9hcmRTcGFjZVJvb3Qoc3BhY2UpXSxcbiAgICAgICAgICByb290TGFiZWxzOiBbJ1lvdXIgYm9hcmQgc3BhY2UnXSxcbiAgICAgICAgICByb290TW9kZXM6IFtzcGFjZS5tb2RlXSxcbiAgICAgICAgICB0aXRsZTogJ09wZW4gYm9hcmQnLFxuICAgICAgICB9KTtcbiAgICAgICAgaWYgKCFyZXMpIHJldHVybjtcbiAgICAgICAgY29uc3QgcmVsID0gc2FmZVJlbChyZXMucmVsUGF0aCk7XG4gICAgICAgIGlmICghcmVsKSB7XG4gICAgICAgICAgdG9hc3QoJ1RoYXQgZm9sZGVyIGNhbuKAmXQgYmUgb3BlbmVkLicsICdhbGVydCcsIHsgaWNvbkNvbG9yOiAnI2NhYTI0YScgfSk7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGNhbmRpZGF0ZTogQm9hcmRUYXJnZXQgPSB7IHJvb3Q6IHN1YlBhdGgoc3BhY2Uucm9vdCwgcmVsKSwgbW9kZTogc3BhY2UubW9kZSwgc3BhY2VJZDogc3BhY2Uuc3BhY2VJZCB9O1xuICAgICAgICBpZiAoIShhd2FpdCBmb2xkZXJJc0JvYXJkKGNhbmRpZGF0ZSkpICYmICEoYXdhaXQgYm9hcmRFeGlzdHMoY2FuZGlkYXRlKSkpIHtcbiAgICAgICAgICB0b2FzdCgnVGhhdCBmb2xkZXIgaXNu4oCZdCBhIGJvYXJkIChubyBib2FyZC5tZCkuIE9wZW4gZm9sZGVyIGFnYWluIHRvIHBpY2sgYW5vdGhlci4nLCAnYWxlcnQnLCB7XG4gICAgICAgICAgICBpY29uQ29sb3I6ICcjY2FhMjRhJyxcbiAgICAgICAgICB9KTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgYXdhaXQgbG9hZEJvYXJkSW50byhjYW5kaWRhdGUpO1xuICAgICAgICB0b2FzdCgnQm9hcmQgb3BlbmVkLicsICdjaGVjaycpO1xuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICB0b2FzdChgQ291bGRu4oCZdCBvcGVuIGJvYXJkJHtjb2RlT2YoZSl9YCwgJ2FsZXJ0JywgeyBpY29uQ29sb3I6ICcjY2FhMjRhJyB9KTtcbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIHVwZGF0ZSh7IGJ1c3k6IG51bGwgfSk7XG4gICAgICB9XG4gICAgfSxcbiAgICBbdG9hc3QsIHVwZGF0ZSwgbG9hZEJvYXJkSW50b10sXG4gICk7XG5cbiAgLyoqIE9wZW4gYSBTUEVDSUZJQyBib2FyZCBkaXJlY3RvcnkgZGlyZWN0bHkgKHRoZSBjaG9vc2VyJ3Mgcm93cywgUjMtNjA3KTpcbiAgICogIG5vIHBpY2tlciDigJQgdGhlIGNhbGxlciBhbHJlYWR5IGtub3dzIHRoZSBmb2xkZXIgKGl0IGxpc3RlZCBpdCkuIExvYWRzXG4gICAqICB0aHJvdWdoIHRoZSBzYW1lIGBsb2FkQm9hcmRJbnRvYCBldmVyeSBvcGVuIHBhdGggZnVubmVscyBpbnRvLiAqL1xuICBjb25zdCBvcGVuQm9hcmRBdCA9IHVzZUNhbGxiYWNrKFxuICAgIGFzeW5jICh0YXJnZXQ6IEJvYXJkVGFyZ2V0KSA9PiB7XG4gICAgICB1cGRhdGUoeyBidXN5OiAnb3Blbi1ib2FyZCcgfSk7XG4gICAgICB0cnkge1xuICAgICAgICBhd2FpdCBsb2FkQm9hcmRJbnRvKHRhcmdldCk7XG4gICAgICAgIHRvYXN0KCdCb2FyZCBvcGVuZWQuJywgJ2NoZWNrJyk7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIHRvYXN0KGBDb3VsZG7igJl0IG9wZW4gYm9hcmQke2NvZGVPZihlKX1gLCAnYWxlcnQnLCB7IGljb25Db2xvcjogJyNjYWEyNGEnIH0pO1xuICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgdXBkYXRlKHsgYnVzeTogbnVsbCB9KTtcbiAgICAgIH1cbiAgICB9LFxuICAgIFt0b2FzdCwgdXBkYXRlLCBsb2FkQm9hcmRJbnRvXSxcbiAgKTtcblxuICAvKiogTmV3IGJvYXJkOiBwaWNrIChvciBjcmVhdGUpIGEgZm9sZGVyIGluIGBzcGFjZWAsIHNjYWZmb2xkIGJvYXJkLm1kLCBvcGVuIGl0LlxuICAgKiAgTmFtZWQtYnVzeSB3aGlsZSB0aGUgcGljayBpcyBvdXQuICovXG4gIGNvbnN0IG5ld0JvYXJkSW4gPSB1c2VDYWxsYmFjayhcbiAgICBhc3luYyAoc3BhY2U6IEJvYXJkVGFyZ2V0KSA9PiB7XG4gICAgICBpZiAoc3BhY2UubW9kZSA9PT0gJ3JvJykge1xuICAgICAgICB0b2FzdCgnVGhhdCBzcGFjZSBpcyByZWFkLW9ubHkg4oCUIHlvdSBjYW7igJl0IGNyZWF0ZSBhIGJvYXJkIHRoZXJlLicsICdsb2NrJywgeyBpY29uQ29sb3I6ICd2YXIoLS1pbmstMiknIH0pO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICB1cGRhdGUoeyBidXN5OiAnbmV3LWJvYXJkJyB9KTtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IHBpY2tGaWxlKHtcbiAgICAgICAgICBtb2RlOiAnb3Blbi1mb2xkZXInLFxuICAgICAgICAgIHJvb3RzOiBbYXdhaXQgYm9hcmRTcGFjZVJvb3Qoc3BhY2UpXSxcbiAgICAgICAgICByb290TGFiZWxzOiBbJ1lvdXIgYm9hcmQgc3BhY2UnXSxcbiAgICAgICAgICByb290TW9kZXM6IFtzcGFjZS5tb2RlXSxcbiAgICAgICAgICB0aXRsZTogJ05ldyBib2FyZCDCtyBjaG9vc2UgYSBmb2xkZXInLFxuICAgICAgICAgIGFsbG93Q3JlYXRlRm9sZGVyOiB0cnVlLFxuICAgICAgICB9KTtcbiAgICAgICAgaWYgKCFyZXMpIHJldHVybjtcbiAgICAgICAgY29uc3QgcmVsID0gc2FmZVJlbChyZXMucmVsUGF0aCk7XG4gICAgICAgIGlmICghcmVsKSB7XG4gICAgICAgICAgdG9hc3QoJ1RoYXQgZm9sZGVyIGNhbuKAmXQgYmUgdXNlZC4nLCAnYWxlcnQnLCB7IGljb25Db2xvcjogJyNjYWEyNGEnIH0pO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBjYW5kaWRhdGU6IEJvYXJkVGFyZ2V0ID0geyByb290OiBzdWJQYXRoKHNwYWNlLnJvb3QsIHJlbCksIG1vZGU6ICdydycsIHNwYWNlSWQ6IHNwYWNlLnNwYWNlSWQgfTtcbiAgICAgICAgY29uc3QgdGl0bGUgPSByZWwuc3BsaXQoJy8nKS5wb3AoKSB8fCAnVW50aXRsZWQgYm9hcmQnO1xuICAgICAgICBhd2FpdCB3cml0ZU5ld0JvYXJkKGNhbmRpZGF0ZSwgdGl0bGUpO1xuICAgICAgICBhd2FpdCBsb2FkQm9hcmRJbnRvKGNhbmRpZGF0ZSk7XG4gICAgICAgIHRvYXN0KCdCb2FyZCBjcmVhdGVkLicsICdjaGVjaycpO1xuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICB0b2FzdChgQ291bGRu4oCZdCBjcmVhdGUgYm9hcmQke2NvZGVPZihlKX1gLCAnYWxlcnQnLCB7IGljb25Db2xvcjogJyNjYWEyNGEnIH0pO1xuICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgdXBkYXRlKHsgYnVzeTogbnVsbCB9KTtcbiAgICAgIH1cbiAgICB9LFxuICAgIFt0b2FzdCwgdXBkYXRlLCBsb2FkQm9hcmRJbnRvXSxcbiAgKTtcblxuICAvKiogT3BlbiAvIG5ldyBib2FyZCBhZ2FpbnN0IHRoZSBDVVJSRU5UIGJvYXJkIHNwYWNlICh0aGUgY2hvb3NlcidzIGZvb3RlcikuICovXG4gIGNvbnN0IG9wZW5Cb2FyZCA9IHVzZUNhbGxiYWNrKCgpID0+IHtcbiAgICBjb25zdCBzcGFjZSA9IGJvYXJkUmVmLmN1cnJlbnQ7XG4gICAgaWYgKCFzcGFjZSkge1xuICAgICAgdG9hc3QoJ1NpZ24gaW4gdG8gb3BlbiBhIGJvYXJkIGZyb20geW91ciBzcGFjZS4nLCAnc2F2ZScsIHsgaWNvbkNvbG9yOiAndmFyKC0taW5rLTIpJyB9KTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdm9pZCBvcGVuQm9hcmRJbihzcGFjZSk7XG4gIH0sIFt0b2FzdCwgb3BlbkJvYXJkSW5dKTtcblxuICBjb25zdCBuZXdCb2FyZCA9IHVzZUNhbGxiYWNrKCgpID0+IHtcbiAgICBjb25zdCBzcGFjZSA9IGJvYXJkUmVmLmN1cnJlbnQ7XG4gICAgaWYgKCFzcGFjZSkge1xuICAgICAgdG9hc3QoJ1NpZ24gaW4gdG8gY3JlYXRlIGEgYm9hcmQgaW4geW91ciBzcGFjZS4nLCAnc2F2ZScsIHsgaWNvbkNvbG9yOiAndmFyKC0taW5rLTIpJyB9KTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdm9pZCBuZXdCb2FyZEluKHNwYWNlKTtcbiAgfSwgW3RvYXN0LCBuZXdCb2FyZEluXSk7XG5cbiAgLyoqIFwiQWRkIGEgc3BhY2VcIjogdGhlIGhvc3QgcG93ZXJib3ggZ3JhbnRzIGEgTkVXIHNwYWNlIChuZXZlciB0aGlzIGFwcCwgwqcyKSxcbiAgICogIHRoZW4gd2Ugb2ZmZXIgdG8gb3BlbiBhIGJvYXJkIGluIGl0LiAqL1xuICBjb25zdCBhZGRTcGFjZSA9IHVzZUNhbGxiYWNrKGFzeW5jICgpID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgZ3JhbnRlZCA9IGF3YWl0IHJlcXVlc3RTcGFjZSgpO1xuICAgICAgaWYgKCFncmFudGVkKSByZXR1cm47IC8vIGNhbmNlbGxlZFxuICAgICAgY29uc3Qgc3BhY2U6IEJvYXJkVGFyZ2V0ID0geyByb290OiBncmFudGVkLnBhdGgsIG1vZGU6IGdyYW50ZWQubW9kZSwgc3BhY2VJZDogZ3JhbnRlZC5pZCB9O1xuICAgICAgYXdhaXQgb3BlbkJvYXJkSW4oc3BhY2UpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIHRvYXN0KGBDb3VsZG7igJl0IGFkZCBhIHNwYWNlJHtjb2RlT2YoZSl9YCwgJ2FsZXJ0JywgeyBpY29uQ29sb3I6ICcjY2FhMjRhJyB9KTtcbiAgICB9XG4gIH0sIFt0b2FzdCwgb3BlbkJvYXJkSW5dKTtcblxuICBjb25zdCBwYXRjaE9iamVjdCA9IHVzZUNhbGxiYWNrKFxuICAgIChpZDogc3RyaW5nLCBwYXRjaDogUGFydGlhbDxXT2JqZWN0PikgPT4ge1xuICAgICAgdXBkYXRlKChzKSA9PiAoeyBvYmplY3RzOiBzLm9iamVjdHMubWFwKChvKSA9PiAoby5pZCA9PT0gaWQgPyB7IC4uLm8sIC4uLnBhdGNoIH0gOiBvKSkgfSkpO1xuICAgICAgc2NoZWR1bGVTYXZlKFtpZF0pO1xuICAgIH0sXG4gICAgW3VwZGF0ZSwgc2NoZWR1bGVTYXZlXSxcbiAgKTtcblxuICBjb25zdCBhZGRDb25uZWN0aW9uID0gdXNlQ2FsbGJhY2soXG4gICAgKGZyb206IHN0cmluZywgdG86IHN0cmluZykgPT4ge1xuICAgICAgY29uc3QgYzogQ29ubmVjdGlvbiA9IHsgdG8sIGtpbmQ6ICdhcnJvdycsIHN0eWxlOiB7IHN0cm9rZTogJ2FjY2VudCcsIGRhc2g6IGZhbHNlIH0gfTtcbiAgICAgIGNvbnN0IHNyYyA9IHN0YXRlUmVmLmN1cnJlbnQub2JqZWN0cy5maW5kKChvKSA9PiBvLmlkID09PSBmcm9tKTtcbiAgICAgIGNvbnN0IHVwZGF0ZWQgPSBzcmMgPyB7IC4uLnNyYywgY29ubmVjdGlvbnM6IHNyYy5jb25uZWN0aW9ucy5jb25jYXQoYykgfSA6IG51bGw7XG4gICAgICB1cGRhdGUoKHMpID0+ICh7IG9iamVjdHM6IHMub2JqZWN0cy5tYXAoKG8pID0+IChvLmlkID09PSBmcm9tID8geyAuLi5vLCBjb25uZWN0aW9uczogby5jb25uZWN0aW9ucy5jb25jYXQoYykgfSA6IG8pKSB9KSk7XG4gICAgICBpZiAodXBkYXRlZCkgY29tbWl0U2F2ZShbdXBkYXRlZF0sIGBDb25uZWN0ZWQgJHtmcm9tfSDihpIgJHt0b31gKTtcbiAgICB9LFxuICAgIFt1cGRhdGUsIGNvbW1pdFNhdmVdLFxuICApO1xuXG4gIC8vIC0tLS0ga2V5Ym9hcmQgY29ubmVjdCAodGhlIG5vbi1kcmFnIHBhdGggdG8gYW4gZWRnZSwgUjMtNjA3IC8gMi41LjcpIC0tLS1cbiAgLyoqIEVudGVyIGNvbm5lY3QtZnJvbSBvbiB0aGUgc2VsZWN0ZWQgb2JqZWN0OyB0aGUgY3Vyc29yIHN0YXJ0cyBvbiB0aGUgZmlyc3RcbiAgICogIG90aGVyIG9iamVjdCBpbiBzdGFja2luZyBvcmRlci4gQXJyb3dzIHRoZW4gd2FsayB0aGUgY3Vyc29yICh0aGUgb3ZlcmxheVxuICAgKiAgZHJhd3MgaXQpLCBFbnRlciBjb21taXRzIHRocm91Z2ggdGhlIHNhbWUgYWRkQ29ubmVjdGlvbiB0aGUgZHJhZyBjYWxscyxcbiAgICogIEVzY2FwZSBjYW5jZWxzLiAqL1xuICBjb25zdCBiZWdpbkNvbm5lY3QgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgY29uc3QgcyA9IHN0YXRlUmVmLmN1cnJlbnQ7XG4gICAgaWYgKHMuc2VsZWN0aW9uLmxlbmd0aCAhPT0gMSkgcmV0dXJuO1xuICAgIGNvbnN0IGZyb20gPSBzLnNlbGVjdGlvblswXTtcbiAgICBjb25zdCBvcmRlciA9IHMub2JqZWN0cy5zbGljZSgpLnNvcnQoKGEsIGIpID0+IChhLnogfHwgMCkgLSAoYi56IHx8IDApKS5tYXAoKG8pID0+IG8uaWQpLmZpbHRlcigoaWQpID0+IGlkICE9PSBmcm9tKTtcbiAgICB1cGRhdGUoeyBjb25uZWN0RnJvbTogZnJvbSwgY29ubmVjdEN1cnNvcjogb3JkZXJbMF0gPz8gbnVsbCwgaW5zcGVjdG9yT3BlbjogZmFsc2UgfSk7XG4gIH0sIFt1cGRhdGVdKTtcblxuICBjb25zdCBlbmRDb25uZWN0ID0gdXNlQ2FsbGJhY2soXG4gICAgKGNvbW1pdDogYm9vbGVhbikgPT4ge1xuICAgICAgY29uc3QgcyA9IHN0YXRlUmVmLmN1cnJlbnQ7XG4gICAgICBpZiAoIXMuY29ubmVjdEZyb20pIHJldHVybjtcbiAgICAgIGlmIChjb21taXQgJiYgcy5jb25uZWN0Q3Vyc29yKSBhZGRDb25uZWN0aW9uKHMuY29ubmVjdEZyb20sIHMuY29ubmVjdEN1cnNvcik7XG4gICAgICB1cGRhdGUoeyBjb25uZWN0RnJvbTogbnVsbCwgY29ubmVjdEN1cnNvcjogbnVsbCB9KTtcbiAgICB9LFxuICAgIFt1cGRhdGUsIGFkZENvbm5lY3Rpb25dLFxuICApO1xuXG4gIGNvbnN0IG1vdmVDb25uZWN0Q3Vyc29yID0gdXNlQ2FsbGJhY2soXG4gICAgKGRpcjogLTEgfCAxKSA9PiB7XG4gICAgICB1cGRhdGUoKHMpID0+IHtcbiAgICAgICAgaWYgKCFzLmNvbm5lY3RGcm9tKSByZXR1cm4ge307XG4gICAgICAgIGNvbnN0IG9yZGVyID0gcy5vYmplY3RzLnNsaWNlKCkuc29ydCgoYSwgYikgPT4gKGEueiB8fCAwKSAtIChiLnogfHwgMCkpLm1hcCgobykgPT4gby5pZCkuZmlsdGVyKChpZCkgPT4gaWQgIT09IHMuY29ubmVjdEZyb20pO1xuICAgICAgICBpZiAoIW9yZGVyLmxlbmd0aCkgcmV0dXJuIHt9O1xuICAgICAgICBjb25zdCBpZHggPSBvcmRlci5pbmRleE9mKHMuY29ubmVjdEN1cnNvciA/PyBvcmRlclswXSk7XG4gICAgICAgIHJldHVybiB7IGNvbm5lY3RDdXJzb3I6IG9yZGVyWyhpZHggKyBkaXIgKyBvcmRlci5sZW5ndGgpICUgb3JkZXIubGVuZ3RoXSB9O1xuICAgICAgfSk7XG4gICAgfSxcbiAgICBbdXBkYXRlXSxcbiAgKTtcblxuICAvLyAtLS0tIHBvaW50ZXIgZ2VzdHVyZXMgLS0tLVxuICBjb25zdCBvbkNhbnZhc0Rvd24gPSB1c2VDYWxsYmFjayhcbiAgICAoZTogUmVhY3QuUG9pbnRlckV2ZW50KSA9PiB7XG4gICAgICBjb25zdCBzID0gc3RhdGVSZWYuY3VycmVudDtcbiAgICAgIGlmIChzLnF1aWNrTWVudSkgdXBkYXRlKHsgcXVpY2tNZW51OiBudWxsIH0pO1xuICAgICAgaWYgKHMuZGVtb01lbnVPcGVuKSB1cGRhdGUoeyBkZW1vTWVudU9wZW46IGZhbHNlIH0pO1xuICAgICAgY29uc3QgbWlkID0gZS5idXR0b24gPT09IDE7XG4gICAgICBpZiAocy5tb2RlID09PSAnZWRpdCcgJiYgIXNwYWNlUmVmLmN1cnJlbnQgJiYgIW1pZCAmJiAhaXNNb2JpbGUoKSkge1xuICAgICAgICBjb25zdCBbbHgsIGx5XSA9IGxvY2FsUG9pbnQoZSk7XG4gICAgICAgIGlmICghZS5zaGlmdEtleSkgdXBkYXRlKHsgc2VsZWN0aW9uOiBbXSB9KTtcbiAgICAgICAgZHJhZ1JlZi5jdXJyZW50ID0geyB0eXBlOiAnbWFycXVlZScsIHN4OiBseCwgc3k6IGx5LCBhZGQ6IGUuc2hpZnRLZXksIGJhc2U6IHMuc2VsZWN0aW9uLnNsaWNlKCkgfTtcbiAgICAgICAgdXBkYXRlKHsgbWFycXVlZTogeyB4OiBseCwgeTogbHksIHc6IDAsIGg6IDAgfSB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGRyYWdSZWYuY3VycmVudCA9IHsgdHlwZTogJ3BhbicsIHN4OiBlLmNsaWVudFgsIHN5OiBlLmNsaWVudFksIGN4OiBzLmNhbS5jeCwgY3k6IHMuY2FtLmN5IH07XG4gICAgICAgIHVwZGF0ZSh7IHBhbm5pbmc6IHRydWUgfSk7XG4gICAgICB9XG4gICAgfSxcbiAgICBbdXBkYXRlLCBpc01vYmlsZSwgbG9jYWxQb2ludF0sXG4gICk7XG5cbiAgY29uc3Qgb2JqUG9pbnRlckRvd24gPSB1c2VDYWxsYmFjayhcbiAgICAoaWQ6IHN0cmluZywgZTogUmVhY3QuUG9pbnRlckV2ZW50KSA9PiB7XG4gICAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgY29uc3QgcyA9IHN0YXRlUmVmLmN1cnJlbnQ7XG4gICAgICBpZiAocy5tb2RlICE9PSAnZWRpdCcpIHtcbiAgICAgICAgZHJhZ1JlZi5jdXJyZW50ID0geyB0eXBlOiAncGFuJywgc3g6IGUuY2xpZW50WCwgc3k6IGUuY2xpZW50WSwgY3g6IHMuY2FtLmN4LCBjeTogcy5jYW0uY3kgfTtcbiAgICAgICAgdXBkYXRlKHsgcGFubmluZzogdHJ1ZSB9KTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgY29uc3QgbyA9IHMub2JqZWN0cy5maW5kKCh4KSA9PiB4LmlkID09PSBpZCk7XG4gICAgICBpZiAoIW8pIHJldHVybjtcbiAgICAgIC8vIE9uZSBzcGVsbGluZyBvZiBzZWxlY3Rpb24gZm9yIHBvaW50ZXIgYW5kIGtleWJvYXJkIGFsaWtlIChSMy02MDcpLlxuICAgICAgY29uc3Qgc2VsID0gYXBwbHlTZWxlY3Rpb24ocy5zZWxlY3Rpb24sIGlkLCBlLnNoaWZ0S2V5KTtcbiAgICAgIHVwZGF0ZSh7IHNlbGVjdGlvbjogc2VsLCBpbnNwZWN0b3JPcGVuOiB0cnVlLCBxdWlja01lbnU6IG51bGwgfSk7XG4gICAgICBpZiAoby5sb2NrZWQpIHJldHVybjtcbiAgICAgIGNvbnN0IG9yaWc6IFJlY29yZDxzdHJpbmcsIHsgeDogbnVtYmVyOyB5OiBudW1iZXIgfT4gPSB7fTtcbiAgICAgIHMub2JqZWN0cy5mb3JFYWNoKCh4KSA9PiB7XG4gICAgICAgIGlmIChzZWwuaW5jbHVkZXMoeC5pZCkpIG9yaWdbeC5pZF0gPSB7IHg6IHgueCwgeTogeC55IH07XG4gICAgICB9KTtcbiAgICAgIGRyYWdSZWYuY3VycmVudCA9IHsgdHlwZTogJ21vdmUnLCBzeDogZS5jbGllbnRYLCBzeTogZS5jbGllbnRZLCBpZHM6IHNlbCwgb3JpZywgbW92ZWQ6IGZhbHNlIH07XG4gICAgfSxcbiAgICBbdXBkYXRlXSxcbiAgKTtcblxuICBjb25zdCBzdGFydEhhbmRsZSA9IHVzZUNhbGxiYWNrKChraW5kOiAncmVzaXplJyB8ICdyb3RhdGUnLCBoYW5kbGU6IHN0cmluZywgZTogUmVhY3QuUG9pbnRlckV2ZW50KSA9PiB7XG4gICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICBjb25zdCBzID0gc3RhdGVSZWYuY3VycmVudDtcbiAgICBjb25zdCBpZCA9IHMuc2VsZWN0aW9uWzBdO1xuICAgIGNvbnN0IG8gPSBzLm9iamVjdHMuZmluZCgoeCkgPT4geC5pZCA9PT0gaWQpO1xuICAgIGlmICghbykgcmV0dXJuO1xuICAgIGNvbnN0IGJhc2UgPSB7IHg6IG8ueCwgeTogby55LCB3OiBvLncsIGg6IG8uaCwgcm90OiBvLnJvdCB9O1xuICAgIGRyYWdSZWYuY3VycmVudCA9XG4gICAgICBraW5kID09PSAncm90YXRlJ1xuICAgICAgICA/IHsgdHlwZTogJ3JvdGF0ZScsIHN4OiBlLmNsaWVudFgsIHN5OiBlLmNsaWVudFksIG86IGJhc2UsIGlkLCBtb3ZlZDogZmFsc2UgfVxuICAgICAgICA6IHsgdHlwZTogJ3Jlc2l6ZScsIGtpbmQ6IGhhbmRsZSwgc3g6IGUuY2xpZW50WCwgc3k6IGUuY2xpZW50WSwgbzogYmFzZSwgaWQsIG1vdmVkOiBmYWxzZSB9O1xuICB9LCBbXSk7XG5cbiAgY29uc3Qgc3RhcnRDb25uZWN0ID0gdXNlQ2FsbGJhY2soXG4gICAgKGlkOiBzdHJpbmcsIHNpZGU6IHN0cmluZywgZTogUmVhY3QuUG9pbnRlckV2ZW50KSA9PiB7XG4gICAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgZHJhZ1JlZi5jdXJyZW50ID0geyB0eXBlOiAnY29ubmVjdCcsIGZyb206IGlkLCBzaWRlLCBtb3ZlZDogZmFsc2UgfTtcbiAgICAgIGNvbnN0IFtseCwgbHldID0gbG9jYWxQb2ludChlKTtcbiAgICAgIHVwZGF0ZSh7IGNvbm5lY3RQcmV2aWV3OiB7IGZyb206IGlkLCB4OiBseCwgeTogbHksIHRhcmdldDogbnVsbCB9IH0pO1xuICAgIH0sXG4gICAgW3VwZGF0ZSwgbG9jYWxQb2ludF0sXG4gICk7XG5cbiAgY29uc3Qgc2V0SG92ZXIgPSB1c2VDYWxsYmFjaygoaWQ6IHN0cmluZyB8IG51bGwpID0+IHVwZGF0ZSh7IGhvdmVyOiBpZCB9KSwgW3VwZGF0ZV0pO1xuICBjb25zdCBjbGVhclNlbGVjdGlvbiA9IHVzZUNhbGxiYWNrKCgpID0+IHVwZGF0ZSh7IHNlbGVjdGlvbjogW10gfSksIFt1cGRhdGVdKTtcblxuICAvLyAtLS0tIG1vZGUgLyB2aWV3IGNvbnRyb2xzIC0tLS1cbiAgY29uc3Qgc2V0UnVuID0gdXNlQ2FsbGJhY2soXG4gICAgLy8gTGVhdmluZyBlZGl0IGRpc2FybXMgYSBrZXlib2FyZCBjb25uZWN0IHRvbyAoaXRzIGN1cnNvciBsaXZlcyBvbiB0aGVcbiAgICAvLyBlZGl0IHN1cmZhY2UpIOKAlCBjb25uZWN0RnJvbSBzdXJ2aXZpbmcgaW50byBydW4gbW9kZSB3b3VsZCBvd24gdGhlXG4gICAgLy8gYXJyb3dzIG9mIGEgbW9kZSB0aGF0IGhhcyBubyBzZWxlY3Rpb24gKFIzLTYwNyByZXZpZXcpLlxuICAgICgpID0+IHVwZGF0ZSh7IG1vZGU6ICdydW4nLCBzZWxlY3Rpb246IFtdLCBpbnNwZWN0b3JPcGVuOiBmYWxzZSwgcXVpY2tNZW51OiBudWxsLCBjb25uZWN0UHJldmlldzogbnVsbCwgY29ubmVjdEZyb206IG51bGwsIGNvbm5lY3RDdXJzb3I6IG51bGwgfSksXG4gICAgW3VwZGF0ZV0sXG4gICk7XG4gIGNvbnN0IHNldEVkaXQgPSB1c2VDYWxsYmFjaygoKSA9PiB1cGRhdGUoeyBtb2RlOiAnZWRpdCcgfSksIFt1cGRhdGVdKTtcbiAgY29uc3QgdG9nZ2xlVGhlbWUgPSB1c2VDYWxsYmFjaygoKSA9PiB1cGRhdGUoKHMpID0+ICh7IGxpZ2h0OiAhcy5saWdodCB9KSksIFt1cGRhdGVdKTtcbiAgY29uc3QgdG9nZ2xlUGFuZWwgPSB1c2VDYWxsYmFjaygoKSA9PiB1cGRhdGUoKHMpID0+ICh7IHBhbmVsT3BlbjogIXMucGFuZWxPcGVuIH0pKSwgW3VwZGF0ZV0pO1xuICBjb25zdCBzZXRTY3JlZW4gPSB1c2VDYWxsYmFjaygoc2NyZWVuOiBTY3JlZW5LaW5kKSA9PiB1cGRhdGUoeyBzY3JlZW4gfSksIFt1cGRhdGVdKTtcbiAgY29uc3Qgc2V0QmFja2dyb3VuZCA9IHVzZUNhbGxiYWNrKChiZzogQmFja2dyb3VuZCkgPT4gdXBkYXRlKHsgYmcgfSksIFt1cGRhdGVdKTtcbiAgY29uc3Qgc2V0TGlnaHQgPSB1c2VDYWxsYmFjaygobGlnaHQ6IGJvb2xlYW4pID0+IHVwZGF0ZSh7IGxpZ2h0IH0pLCBbdXBkYXRlXSk7XG4gIGNvbnN0IGNsb3NlSW5zcGVjdG9yID0gdXNlQ2FsbGJhY2soKCkgPT4gdXBkYXRlKHsgaW5zcGVjdG9yT3BlbjogZmFsc2UgfSksIFt1cGRhdGVdKTtcbiAgY29uc3QgY2xvc2VQYW5lbCA9IHVzZUNhbGxiYWNrKCgpID0+IHVwZGF0ZSh7IHBhbmVsT3BlbjogZmFsc2UgfSksIFt1cGRhdGVdKTtcbiAgY29uc3QgdG9nZ2xlRGVtb01lbnUgPSB1c2VDYWxsYmFjaygoKSA9PiB1cGRhdGUoKHMpID0+ICh7IGRlbW9NZW51T3BlbjogIXMuZGVtb01lbnVPcGVuIH0pKSwgW3VwZGF0ZV0pO1xuXG4gIGNvbnN0IG9uQ2FudmFzRGJsQ2xpY2sgPSB1c2VDYWxsYmFjayhcbiAgICAoZTogUmVhY3QuTW91c2VFdmVudCkgPT4ge1xuICAgICAgaWYgKHN0YXRlUmVmLmN1cnJlbnQubW9kZSAhPT0gJ2VkaXQnKSByZXR1cm47XG4gICAgICBjb25zdCBbbHgsIGx5XSA9IGxvY2FsUG9pbnQoZSk7XG4gICAgICBjb25zdCBbd3gsIHd5XSA9IHdvcmxkQXQoc3RhdGVSZWYuY3VycmVudC5jYW0sIHN0YXRlUmVmLmN1cnJlbnQudnAsIGx4LCBseSk7XG4gICAgICB1cGRhdGUoeyBxdWlja01lbnU6IHsgbHgsIGx5LCB3eCwgd3kgfSB9KTtcbiAgICB9LFxuICAgIFt1cGRhdGUsIGxvY2FsUG9pbnRdLFxuICApO1xuXG4gIC8vIC0tLS0gZGVtbyBzY2VuYXJpb3MgKHRoZSBkZXNpZ24ncyBcImRlbW8gc3RhdGVzXCIgbWVudSkgLS0tLVxuICBjb25zdCBkZW1vTFdXID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIHRvYXN0KCdOb3RlIHdhcyBjaGFuZ2VkIGJ5IEBkYW5hIHdoaWxlIHlvdSBlZGl0ZWQg4oCUIHRoZWlyIHZlcnNpb24ga2VwdC4nLCAnYWxlcnQnLCB7XG4gICAgICBpY29uQ29sb3I6ICcjY2FhMjRhJyxcbiAgICAgIGFjdGlvbkxhYmVsOiAnS2VlcCBtaW5lJyxcbiAgICAgIG9uQWN0aW9uOiAoKSA9PiB0b2FzdCgnWW91ciB2ZXJzaW9uIHJlc3RvcmVkJywgJ2NoZWNrJyksXG4gICAgfSk7XG4gIH0sIFt0b2FzdF0pO1xuXG4gIGNvbnN0IGRlbW9Eb3duZ3JhZGUgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgdXBkYXRlKHsgbW9kZTogJ3J1bicsIHNlbGVjdGlvbjogW10sIGluc3BlY3Rvck9wZW46IGZhbHNlIH0pO1xuICAgIHRvYXN0KCdZb3VyIGFjY2VzcyBjaGFuZ2VkIHRvIHJlYWQtb25seS4gRWRpdCBtb2RlIGNsb3NlZC4nLCAnbG9jaycsIHsgaWNvbkNvbG9yOiAndmFyKC0taW5rLTIpJyB9KTtcbiAgfSwgW3VwZGF0ZSwgdG9hc3RdKTtcblxuICAvLyAtLS0tIGVmZmVjdHM6IG1lYXN1cmVtZW50ICsgZ2xvYmFsIGxpc3RlbmVycyAtLS0tXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LnNldEF0dHJpYnV0ZSgnZGF0YS10aGVtZScsIHN0YXRlLmxpZ2h0ID8gJ2xpZ2h0JyA6ICdkYXJrJyk7XG4gIH0sIFtzdGF0ZS5saWdodF0pO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgZWwgPSBjYW52YXNFbDtcbiAgICBpZiAoIWVsKSByZXR1cm47XG5cbiAgICBjb25zdCBtZWFzdXJlID0gKCkgPT4ge1xuICAgICAgY29uc3QgciA9IGVsLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgICAgdXBkYXRlKHsgdnA6IHsgdnc6IHIud2lkdGgsIHZoOiByLmhlaWdodCwgdmxlZnQ6IHIubGVmdCwgdnRvcDogci50b3AgfSB9KTtcbiAgICB9O1xuICAgIG1lYXN1cmUoKTtcbiAgICBjb25zdCBybyA9IG5ldyBSZXNpemVPYnNlcnZlcihtZWFzdXJlKTtcbiAgICByby5vYnNlcnZlKGVsKTtcblxuICAgIGNvbnN0IG9uV2hlZWwgPSAoZTogV2hlZWxFdmVudCkgPT4ge1xuICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgY29uc3QgW2x4LCBseV0gPSBsb2NhbFBvaW50KGUpO1xuICAgICAgaWYgKGUuY3RybEtleSB8fCBlLm1ldGFLZXkpIHtcbiAgICAgICAgY29uc3QgZiA9IE1hdGguZXhwKC1lLmRlbHRhWSAqIDAuMDEpO1xuICAgICAgICBzZXRab29tKHN0YXRlUmVmLmN1cnJlbnQuY2FtLnpvb20gKiBmLCBseCwgbHkpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdXBkYXRlKChzKSA9PiAoeyBjYW06IHsgY3g6IHMuY2FtLmN4ICsgZS5kZWx0YVggLyBzLmNhbS56b29tLCBjeTogcy5jYW0uY3kgKyBlLmRlbHRhWSAvIHMuY2FtLnpvb20sIHpvb206IHMuY2FtLnpvb20gfSB9KSk7XG4gICAgICB9XG4gICAgfTtcbiAgICBlbC5hZGRFdmVudExpc3RlbmVyKCd3aGVlbCcsIG9uV2hlZWwsIHsgcGFzc2l2ZTogZmFsc2UgfSk7XG5cbiAgICBjb25zdCBvbk1vdmUgPSAoZTogUG9pbnRlckV2ZW50KSA9PiB7XG4gICAgICBjb25zdCBkID0gZHJhZ1JlZi5jdXJyZW50O1xuICAgICAgaWYgKCFkKSByZXR1cm47XG4gICAgICBjb25zdCB6ID0gc3RhdGVSZWYuY3VycmVudC5jYW0uem9vbTtcbiAgICAgIGlmIChkLnR5cGUgPT09ICdwYW4nKSB7XG4gICAgICAgIGNvbnN0IGR4ID0gZS5jbGllbnRYIC0gZC5zeDtcbiAgICAgICAgY29uc3QgZHkgPSBlLmNsaWVudFkgLSBkLnN5O1xuICAgICAgICB1cGRhdGUoeyBjYW06IHsgY3g6IGQuY3ggLSBkeCAvIHosIGN5OiBkLmN5IC0gZHkgLyB6LCB6b29tOiB6IH0gfSk7XG4gICAgICB9IGVsc2UgaWYgKGQudHlwZSA9PT0gJ21vdmUnKSB7XG4gICAgICAgIGNvbnN0IGR4ID0gKGUuY2xpZW50WCAtIGQuc3gpIC8gejtcbiAgICAgICAgY29uc3QgZHkgPSAoZS5jbGllbnRZIC0gZC5zeSkgLyB6O1xuICAgICAgICBkLm1vdmVkID0gdHJ1ZTtcbiAgICAgICAgdXBkYXRlKChzKSA9PiAoe1xuICAgICAgICAgIG9iamVjdHM6IHMub2JqZWN0cy5tYXAoKG8pID0+XG4gICAgICAgICAgICBkLmlkcy5pbmNsdWRlcyhvLmlkKSAmJiBkLm9yaWdbby5pZF0gPyB7IC4uLm8sIHg6IGQub3JpZ1tvLmlkXS54ICsgZHgsIHk6IGQub3JpZ1tvLmlkXS55ICsgZHkgfSA6IG8sXG4gICAgICAgICAgKSxcbiAgICAgICAgfSkpO1xuICAgICAgfSBlbHNlIGlmIChkLnR5cGUgPT09ICdtYXJxdWVlJykge1xuICAgICAgICBjb25zdCBbbHgsIGx5XSA9IGxvY2FsUG9pbnQoZSk7XG4gICAgICAgIGNvbnN0IHggPSBNYXRoLm1pbihseCwgZC5zeCk7XG4gICAgICAgIGNvbnN0IHkgPSBNYXRoLm1pbihseSwgZC5zeSk7XG4gICAgICAgIGNvbnN0IHcgPSBNYXRoLmFicyhseCAtIGQuc3gpO1xuICAgICAgICBjb25zdCBoaCA9IE1hdGguYWJzKGx5IC0gZC5zeSk7XG4gICAgICAgIGNvbnN0IHMgPSBzdGF0ZVJlZi5jdXJyZW50O1xuICAgICAgICBjb25zdCBzZWwgPSBvYmplY3RzSW5SZWN0KHMub2JqZWN0cywgcy5jYW0sIHMudnAsIHgsIHksIHcsIGhoKTtcbiAgICAgICAgdXBkYXRlKHsgbWFycXVlZTogeyB4LCB5LCB3LCBoOiBoaCB9LCBzZWxlY3Rpb246IGQuYWRkID8gQXJyYXkuZnJvbShuZXcgU2V0KGQuYmFzZS5jb25jYXQoc2VsKSkpIDogc2VsIH0pO1xuICAgICAgfSBlbHNlIGlmIChkLnR5cGUgPT09ICdjb25uZWN0Jykge1xuICAgICAgICBjb25zdCBbbHgsIGx5XSA9IGxvY2FsUG9pbnQoZSk7XG4gICAgICAgIGNvbnN0IHMgPSBzdGF0ZVJlZi5jdXJyZW50O1xuICAgICAgICBjb25zdCB0Z3QgPSBvYmplY3RBdExvY2FsKHMub2JqZWN0cywgcy5jYW0sIHMudnAsIGx4LCBseSwgZC5mcm9tKTtcbiAgICAgICAgdXBkYXRlKHsgY29ubmVjdFByZXZpZXc6IHsgZnJvbTogZC5mcm9tLCB4OiBseCwgeTogbHksIHRhcmdldDogdGd0IH0gfSk7XG4gICAgICB9IGVsc2UgaWYgKGQudHlwZSA9PT0gJ3Jlc2l6ZScgfHwgZC50eXBlID09PSAncm90YXRlJykge1xuICAgICAgICBhcHBseUhhbmRsZShkLCBlKTtcbiAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3QgYXBwbHlIYW5kbGUgPSAoZDogRXh0cmFjdDxEcmFnLCB7IHR5cGU6ICdyZXNpemUnIHwgJ3JvdGF0ZScgfT4sIGU6IFBvaW50ZXJFdmVudCkgPT4ge1xuICAgICAgY29uc3QgcyA9IHN0YXRlUmVmLmN1cnJlbnQ7XG4gICAgICBjb25zdCB6ID0gcy5jYW0uem9vbTtcbiAgICAgIGNvbnN0IGR4ID0gKGUuY2xpZW50WCAtIGQuc3gpIC8gejtcbiAgICAgIGNvbnN0IGR5ID0gKGUuY2xpZW50WSAtIGQuc3kpIC8gejtcbiAgICAgIGQubW92ZWQgPSB0cnVlO1xuICAgICAgdXBkYXRlKChzdCkgPT4gKHtcbiAgICAgICAgb2JqZWN0czogc3Qub2JqZWN0cy5tYXAoKG8pID0+IHtcbiAgICAgICAgICBpZiAoby5pZCAhPT0gZC5pZCkgcmV0dXJuIG87XG4gICAgICAgICAgaWYgKGQudHlwZSA9PT0gJ3JvdGF0ZScpIHtcbiAgICAgICAgICAgIGNvbnN0IGN4ID0gZC5vLnggKyBkLm8udyAvIDI7XG4gICAgICAgICAgICBjb25zdCBjeSA9IGQuby55ICsgZC5vLmggLyAyO1xuICAgICAgICAgICAgY29uc3QgW2x4LCBseV0gPSBsb2NhbFBvaW50KGUpO1xuICAgICAgICAgICAgY29uc3QgW3d4LCB3eV0gPSB3b3JsZEF0KHMuY2FtLCBzLnZwLCBseCwgbHkpO1xuICAgICAgICAgICAgbGV0IGFuZyA9IChNYXRoLmF0YW4yKHd5IC0gY3ksIHd4IC0gY3gpICogMTgwKSAvIE1hdGguUEkgKyA5MDtcbiAgICAgICAgICAgIGlmIChlLnNoaWZ0S2V5KSBhbmcgPSBNYXRoLnJvdW5kKGFuZyAvIDE1KSAqIDE1O1xuICAgICAgICAgICAgcmV0dXJuIHsgLi4ubywgcm90OiBNYXRoLnJvdW5kKGFuZykgfTtcbiAgICAgICAgICB9XG4gICAgICAgICAgbGV0IHggPSBkLm8ueDtcbiAgICAgICAgICBsZXQgeSA9IGQuby55O1xuICAgICAgICAgIGxldCB3ID0gZC5vLnc7XG4gICAgICAgICAgbGV0IGhoID0gZC5vLmg7XG4gICAgICAgICAgY29uc3QgayA9IGQua2luZDtcbiAgICAgICAgICBpZiAoay5pbmNsdWRlcygnZScpKSB3ID0gTWF0aC5tYXgoNjAsIGQuby53ICsgZHgpO1xuICAgICAgICAgIGlmIChrLmluY2x1ZGVzKCdzJykpIGhoID0gTWF0aC5tYXgoNDgsIGQuby5oICsgZHkpO1xuICAgICAgICAgIGlmIChrLmluY2x1ZGVzKCd3JykpIHtcbiAgICAgICAgICAgIHcgPSBNYXRoLm1heCg2MCwgZC5vLncgLSBkeCk7XG4gICAgICAgICAgICB4ID0gZC5vLnggKyAoZC5vLncgLSB3KTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKGsuaW5jbHVkZXMoJ24nKSkge1xuICAgICAgICAgICAgaGggPSBNYXRoLm1heCg0OCwgZC5vLmggLSBkeSk7XG4gICAgICAgICAgICB5ID0gZC5vLnkgKyAoZC5vLmggLSBoaCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiB7IC4uLm8sIHgsIHksIHcsIGg6IGhoIH07XG4gICAgICAgIH0pLFxuICAgICAgfSkpO1xuICAgIH07XG5cbiAgICBjb25zdCBvblVwID0gKGU6IFBvaW50ZXJFdmVudCkgPT4ge1xuICAgICAgY29uc3QgZCA9IGRyYWdSZWYuY3VycmVudDtcbiAgICAgIGRyYWdSZWYuY3VycmVudCA9IG51bGw7XG4gICAgICBpZiAoIWQpIHtcbiAgICAgICAgaWYgKHN0YXRlUmVmLmN1cnJlbnQucGFubmluZykgdXBkYXRlKHsgcGFubmluZzogZmFsc2UgfSk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGlmIChkLnR5cGUgPT09ICdwYW4nKSB7XG4gICAgICAgIHVwZGF0ZSh7IHBhbm5pbmc6IGZhbHNlIH0pO1xuICAgICAgfSBlbHNlIGlmIChkLnR5cGUgPT09ICdtb3ZlJyAmJiBkLm1vdmVkKSB7XG4gICAgICAgIGNvbnN0IG1vdmVkID0gc3RhdGVSZWYuY3VycmVudC5vYmplY3RzLmZpbHRlcigobykgPT4gZC5pZHMuaW5jbHVkZXMoby5pZCkpO1xuICAgICAgICBjb21taXRTYXZlKG1vdmVkLCBgTW92ZWQgwrcgc2F2ZWQgdG8gJHtkLmlkcy5sZW5ndGggPiAxID8gYCR7ZC5pZHMubGVuZ3RofSBmaWxlc2AgOiBgJHtkLmlkc1swXX0ubWR4YH1gKTtcbiAgICAgIH0gZWxzZSBpZiAoZC50eXBlID09PSAnbWFycXVlZScpIHtcbiAgICAgICAgdXBkYXRlKHsgbWFycXVlZTogbnVsbCB9KTtcbiAgICAgIH0gZWxzZSBpZiAoZC50eXBlID09PSAnY29ubmVjdCcpIHtcbiAgICAgICAgY29uc3QgW2x4LCBseV0gPSBsb2NhbFBvaW50KGUpO1xuICAgICAgICBjb25zdCBzID0gc3RhdGVSZWYuY3VycmVudDtcbiAgICAgICAgY29uc3QgdGd0ID0gb2JqZWN0QXRMb2NhbChzLm9iamVjdHMsIHMuY2FtLCBzLnZwLCBseCwgbHksIGQuZnJvbSk7XG4gICAgICAgIGlmICh0Z3QpIGFkZENvbm5lY3Rpb24oZC5mcm9tLCB0Z3QpO1xuICAgICAgICB1cGRhdGUoeyBjb25uZWN0UHJldmlldzogbnVsbCB9KTtcbiAgICAgIH0gZWxzZSBpZiAoKGQudHlwZSA9PT0gJ3Jlc2l6ZScgfHwgZC50eXBlID09PSAncm90YXRlJykgJiYgZC5tb3ZlZCkge1xuICAgICAgICBjb25zdCBvID0gc3RhdGVSZWYuY3VycmVudC5vYmplY3RzLmZpbmQoKHgpID0+IHguaWQgPT09IGQuaWQpO1xuICAgICAgICBjb21taXRTYXZlKG8gPyBbb10gOiBbXSwgJ1Jlc2l6ZWQgwrcgc2F2ZWQnKTtcbiAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3Qgb25LZXlEb3duID0gKGU6IEtleWJvYXJkRXZlbnQpID0+IHtcbiAgICAgIGNvbnN0IHQgPSBlLnRhcmdldCBhcyBIVE1MRWxlbWVudCB8IG51bGw7XG4gICAgICBpZiAodCAmJiAodC50YWdOYW1lID09PSAnSU5QVVQnIHx8IHQudGFnTmFtZSA9PT0gJ1RFWFRBUkVBJyB8fCB0LnRhZ05hbWUgPT09ICdTRUxFQ1QnIHx8IHQuaXNDb250ZW50RWRpdGFibGUpKSByZXR1cm47XG4gICAgICBjb25zdCBzID0gc3RhdGVSZWYuY3VycmVudDtcbiAgICAgIGlmIChzLmpvdXJuZXkpIHtcbiAgICAgICAgaWYgKGUua2V5ID09PSAnQXJyb3dSaWdodCcgfHwgZS5rZXkgPT09ICcgJykge1xuICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICBwbGF5TmV4dCgpO1xuICAgICAgICB9IGVsc2UgaWYgKGUua2V5ID09PSAnQXJyb3dMZWZ0Jykge1xuICAgICAgICAgIHBsYXlQcmV2KCk7XG4gICAgICAgIH0gZWxzZSBpZiAoZS5rZXkgPT09ICdFc2NhcGUnKSB7XG4gICAgICAgICAgcGxheUV4aXQoKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICAvLyBLZXlib2FyZCBjb25uZWN0IG93bnMgdGhlIGFycm93cyB3aGlsZSBpdCBpcyBhcm1lZCAoUjMtNjA3KTogYXJyb3dzXG4gICAgICAvLyB3YWxrIHRoZSB0YXJnZXQgY3Vyc29yLCBFbnRlciBjb21taXRzLCBFc2NhcGUgY2FuY2VscyDigJQgbmV2ZXIgbnVkZ2luZ1xuICAgICAgLy8gb3IgZGVsZXRpbmcgdW5kZXJuZWF0aCBhIGxpdmUgY29ubmVjdC5cbiAgICAgIGlmIChzLmNvbm5lY3RGcm9tKSB7XG4gICAgICAgIGlmIChlLmtleSA9PT0gJ0Fycm93TGVmdCcgfHwgZS5rZXkgPT09ICdBcnJvd1VwJykge1xuICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICBtb3ZlQ29ubmVjdEN1cnNvcigtMSk7XG4gICAgICAgIH0gZWxzZSBpZiAoZS5rZXkgPT09ICdBcnJvd1JpZ2h0JyB8fCBlLmtleSA9PT0gJ0Fycm93RG93bicpIHtcbiAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICAgbW92ZUNvbm5lY3RDdXJzb3IoMSk7XG4gICAgICAgIH0gZWxzZSBpZiAoZS5rZXkgPT09ICdFbnRlcicpIHtcbiAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICAgZW5kQ29ubmVjdCh0cnVlKTtcbiAgICAgICAgfSBlbHNlIGlmIChlLmtleSA9PT0gJ0VzY2FwZScpIHtcbiAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICAgZW5kQ29ubmVjdChmYWxzZSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgaWYgKGUua2V5ID09PSAnRXNjYXBlJykgdXBkYXRlKHsgc2VsZWN0aW9uOiBbXSwgcXVpY2tNZW51OiBudWxsLCBzY3JlZW46IG51bGwgfSk7XG4gICAgICBpZiAoZS5rZXkgPT09ICcgJykgc3BhY2VSZWYuY3VycmVudCA9IHRydWU7XG4gICAgICBpZiAocy5tb2RlID09PSAnZWRpdCcgJiYgcy5zZWxlY3Rpb24ubGVuZ3RoKSB7XG4gICAgICAgIGNvbnN0IHN0ZXAgPSBlLnNoaWZ0S2V5ID8gMTAgOiAxO1xuICAgICAgICBsZXQgZHggPSAwO1xuICAgICAgICBsZXQgZHkgPSAwO1xuICAgICAgICBpZiAoZS5rZXkgPT09ICdBcnJvd0xlZnQnKSBkeCA9IC1zdGVwO1xuICAgICAgICBlbHNlIGlmIChlLmtleSA9PT0gJ0Fycm93UmlnaHQnKSBkeCA9IHN0ZXA7XG4gICAgICAgIGVsc2UgaWYgKGUua2V5ID09PSAnQXJyb3dVcCcpIGR5ID0gLXN0ZXA7XG4gICAgICAgIGVsc2UgaWYgKGUua2V5ID09PSAnQXJyb3dEb3duJykgZHkgPSBzdGVwO1xuICAgICAgICBpZiAoZHggfHwgZHkpIHtcbiAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICAgY29uc3Qgc2VsID0gcy5zZWxlY3Rpb247XG4gICAgICAgICAgdXBkYXRlKChzdCkgPT4gKHsgb2JqZWN0czogc3Qub2JqZWN0cy5tYXAoKG8pID0+IChzZWwuaW5jbHVkZXMoby5pZCkgJiYgIW8ubG9ja2VkID8geyAuLi5vLCB4OiBvLnggKyBkeCwgeTogby55ICsgZHkgfSA6IG8pKSB9KSk7XG4gICAgICAgICAgc2NoZWR1bGVTYXZlKHNlbCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGUua2V5ID09PSAnRGVsZXRlJyB8fCBlLmtleSA9PT0gJ0JhY2tzcGFjZScpIGRlbGV0ZVNlbGVjdGlvbigpO1xuICAgICAgfVxuICAgIH07XG4gICAgY29uc3Qgb25LZXlVcCA9IChlOiBLZXlib2FyZEV2ZW50KSA9PiB7XG4gICAgICBpZiAoZS5rZXkgPT09ICcgJykgc3BhY2VSZWYuY3VycmVudCA9IGZhbHNlO1xuICAgIH07XG5cbiAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdwb2ludGVybW92ZScsIG9uTW92ZSk7XG4gICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcigncG9pbnRlcnVwJywgb25VcCk7XG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ2tleWRvd24nLCBvbktleURvd24pO1xuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdrZXl1cCcsIG9uS2V5VXApO1xuXG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGVsLnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3doZWVsJywgb25XaGVlbCk7XG4gICAgICByby5kaXNjb25uZWN0KCk7XG4gICAgICBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKCdwb2ludGVybW92ZScsIG9uTW92ZSk7XG4gICAgICBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKCdwb2ludGVydXAnLCBvblVwKTtcbiAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdrZXlkb3duJywgb25LZXlEb3duKTtcbiAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdrZXl1cCcsIG9uS2V5VXApO1xuICAgICAgaWYgKHR3ZWVuUmVmLmN1cnJlbnQpIGNhbmNlbEFuaW1hdGlvbkZyYW1lKHR3ZWVuUmVmLmN1cnJlbnQpO1xuICAgIH07XG4gICAgLy8gVGhlIGxpc3RlbmVycyByZWFkIHRoZSBsYXRlc3Qgc3RhdGUgdmlhIHN0YXRlUmVmLCBzbyB0aGV5IGluc3RhbGwgb25jZVxuICAgIC8vIHRoZSBjYW52YXMgbW91bnRzOyB0aGUgYWN0aW9uIGNhbGxiYWNrcyB0aGV5IGNsb3NlIG92ZXIgYXJlIGFsbCBzdGFibGUuXG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWhvb2tzL2V4aGF1c3RpdmUtZGVwc1xuICB9LCBbY2FudmFzRWxdKTtcblxuICAvKipcbiAgICogUHJvdmlkZXIgc2lkZSBvZiBgb3Blbi1wcm9qZWN0YCAoU1BBQ0VTX1VJX1NQRUMgwqc2KTogZ2l2ZW4gdGhlIGRlbGVnYXRlZFxuICAgKiBgY2FwRGlyYCwgZmluZCB0aGUgY2hyb290IHRoZSBob3N0IG1vdW50ZWQgZm9yIGl0LCBoeWRyYXRlIHRoZSBjYW52YXMgZnJvbVxuICAgKiBpdCwgYW5kIGFybSB0aGUgZHVyYWJsZS1ib2FyZCBtYWNoaW5lcnkgKGF1dG9zYXZlLCBkb3duZ3JhZGUgd2F0Y2gpIGFnYWluc3RcbiAgICogaXQuIFJlc29sdmVzIHRydWUgb25jZSB0aGUgYm9hcmQgaXMgc2hvd24sIGZhbHNlIGlmIHRoZSBkZWxlZ2F0ZWQgZm9sZGVyXG4gICAqIG5ldmVyIHJlc29sdmVkIHRvIGEgbW91bnQgKHRoZSBjYWxsZXIgdGhlbiBhYm9ydHMgdGhlIHRhc2spLiBUaGUgZm9sZGVyIGlzXG4gICAqIGV4cGVjdGVkIHRvIGFscmVhZHkgYmUgYSBib2FyZCAodGhlIG1hcmtlciBvbmx5IGxpdmVzIG9uIGJvYXJkIGZvbGRlcnMpOyBhblxuICAgKiBlbXB0eSBvbmUgaXMgc2VlZGVkIHNvIHRoZSBjYW52YXMgc3RpbGwgcmVuZGVycy5cbiAgICovXG4gIGNvbnN0IG9wZW5EZWxlZ2F0ZWRQcm9qZWN0ID0gdXNlQ2FsbGJhY2soXG4gICAgYXN5bmMgKGRpclBhdGg6IHN0cmluZyk6IFByb21pc2U8Ym9vbGVhbj4gPT4ge1xuICAgICAgLy8gVGhlIGhvc3QgYW5ub3VuY2VzIHRoZSB0YXNrIGNocm9vdCBhcyBhIG1vdW50IEFUIHRoZSBkZWxlZ2F0ZWQgcGF0aDsgaXRcbiAgICAgIC8vIG1heSBub3QgYmUgcHJlc2VudCB0aGUgaW5zdGFudCB3ZSByZWFkIHRoZSBpbnB1dCwgc28gcG9sbCBicmllZmx5IChhIGZld1xuICAgICAgLy8gZnJhbWVzKSBmb3IgdGhlIG1vdW50IHdob3NlIGBwYXRoYCBtYXRjaGVzLlxuICAgICAgbGV0IG1vdW50ID0gcmVzb2x2ZURlbGVnYXRlZE1vdW50KGRpclBhdGgsIGdldE1vdW50cygpKTtcbiAgICAgIGZvciAobGV0IHRyaWVzID0gMDsgIW1vdW50ICYmIHRyaWVzIDwgNDA7IHRyaWVzICs9IDEpIHtcbiAgICAgICAgYXdhaXQgbmV3IFByb21pc2UoKHIpID0+IHNldFRpbWVvdXQociwgNTApKTtcbiAgICAgICAgbW91bnQgPSByZXNvbHZlRGVsZWdhdGVkTW91bnQoZGlyUGF0aCwgZ2V0TW91bnRzKCkpO1xuICAgICAgfVxuICAgICAgaWYgKCFtb3VudCkge1xuICAgICAgICB0b2FzdCgnQ291bGRu4oCZdCBvcGVuIHRoYXQgcHJvamVjdCDigJQgdGhlIGZvbGRlciBpc27igJl0IGF2YWlsYWJsZS4nLCAnYWxlcnQnLCB7IGljb25Db2xvcjogJyNjYWEyNGEnIH0pO1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgICBjb25zdCB0YXJnZXQgPSBkaXJDYXBUb0JvYXJkVGFyZ2V0KG1vdW50KTtcbiAgICAgIHRyeSB7XG4gICAgICAgIGlmIChhd2FpdCBib2FyZEV4aXN0cyh0YXJnZXQpKSB7XG4gICAgICAgICAgYXdhaXQgbG9hZEJvYXJkSW50byh0YXJnZXQpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIC8vIFRoZSBtYXJrZXIgc2FpZCB0aGlzIGlzIGEgcHJvamVjdCBmb2xkZXIgYnV0IGl0IGhhcyBubyBvYmplY3RzIHlldDpcbiAgICAgICAgICAvLyBzZWVkIGl0IHNvIHRoZSB1c2VyIGxhbmRzIG9uIGEgdXNhYmxlIGJvYXJkLCBub3QgYSBibGFuayBjYW52YXMuXG4gICAgICAgICAgYm9hcmRSZWYuY3VycmVudCA9IHRhcmdldDtcbiAgICAgICAgICBjb25zdCBzID0gc3RhdGVSZWYuY3VycmVudDtcbiAgICAgICAgICBhd2FpdCBzZWVkQm9hcmQodGFyZ2V0LCB7IG9iamVjdHM6IHMub2JqZWN0cywgdmlld3M6IHMudmlld3MsIGpvdXJuZXlzOiBzLmpvdXJuZXlzIH0pO1xuICAgICAgICB9XG4gICAgICAgIHRvYXN0KCdQcm9qZWN0IG9wZW5lZC4nLCAnY2hlY2snKTtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIHRvYXN0KGBDb3VsZG7igJl0IG9wZW4gcHJvamVjdCR7Y29kZU9mKGUpfWAsICdhbGVydCcsIHsgaWNvbkNvbG9yOiAnI2NhYTI0YScgfSk7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICB9LFxuICAgIFt0b2FzdCwgbG9hZEJvYXJkSW50b10sXG4gICk7XG5cbiAgLy8gLS0tLSBvcGVuIHRoZSBkdXJhYmxlIGJvYXJkIHNwYWNlLCBoeWRyYXRlIChvciBzZWVkKSwgd2F0Y2ggZm9yIGRvd25ncmFkZXMgLS0tLVxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGxldCBjYW5jZWxsZWQgPSBmYWxzZTtcbiAgICBsZXQgdW5zdWI6ICgoKSA9PiB2b2lkKSB8IHVuZGVmaW5lZDtcbiAgICBjb25zdCB0aW1lcnMgPSBzYXZlVGltZXJzLmN1cnJlbnQ7XG4gICAgKGFzeW5jICgpID0+IHtcbiAgICAgIC8vIOKUgOKUgCBvcGVuLXByb2plY3QgcHJvdmlkZXIgcGF0aCAoU1BBQ0VTX1VJX1NQRUMgwqc2LCBQaGFzZSA1KSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgICAgIC8vIElmIGEgZmlsZSBtYW5hZ2VyIGxhdW5jaGVkIHVzIHZpYSB0aGUgYG9wZW4tcHJvamVjdGAgdGFzaywgaXQgaGFuZGVkIGFcbiAgICAgIC8vIGBjYXBEaXJgIGZvciB0aGUgcHJvamVjdCBmb2xkZXI7IHRoZSBob3N0IG1vdW50ZWQgdGhhdCBmb2xkZXIgYXMgYVxuICAgICAgLy8gY2hyb290LiBMb2FkIHRoZSBib2FyZCBmcm9tIGl0IGFuZCBjb21wbGV0ZSB0aGUgdGFzaywgdGhlbiBhcm0gdGhlIHNhbWVcbiAgICAgIC8vIGRvd25ncmFkZSB3YXRjaCBiZWxvdyBhZ2FpbnN0IHRoZSBkZWxlZ2F0ZWQgbW91bnQuIEEgbm9ybWFsIGxhdW5jaCAobm9cbiAgICAgIC8vIHRhc2sgaW5wdXQpIGZhbGxzIHRocm91Z2ggdG8gdGhlIGR1cmFibGUtYm9hcmQgcGF0aCB1bmNoYW5nZWQuXG4gICAgICBsZXQgZGVsZWdhdGVkID0gZmFsc2U7XG4gICAgICBjb25zdCBkaXIgPSBhd2FpdCByZWFkT3BlblByb2plY3RJbnB1dCgpO1xuICAgICAgaWYgKGRpcikge1xuICAgICAgICBjb25zdCBvcGVuZWQgPSBhd2FpdCBvcGVuRGVsZWdhdGVkUHJvamVjdChkaXIpO1xuICAgICAgICBpZiAob3BlbmVkKSBhd2FpdCByZXBvcnRPcGVuZWQodHJ1ZSk7XG4gICAgICAgIGVsc2UgYXdhaXQgYWJvcnRPcGVuUHJvamVjdCgpO1xuICAgICAgICBpZiAoY2FuY2VsbGVkKSByZXR1cm47XG4gICAgICAgIC8vIE9uIHN1Y2Nlc3MgdGhlIGNhbnZhcyBpcyBjaHJvb3RlZCBhdCB0aGUgcHJvamVjdDsgc2tpcCB0aGUgZHVyYWJsZVxuICAgICAgICAvLyBib2FyZCBzcGFjZS4gT24gZmFpbHVyZSwgZmFsbCB0aHJvdWdoIHRvIHRoZSBpbi1tZW1vcnkgc2VlZCBzbyB0aGVcbiAgICAgICAgLy8gY2FudmFzIHN0aWxsIHJlbmRlcnMgc29tZXRoaW5nIHJhdGhlciB0aGFuIGEgYmxhbmsgYXBwLlxuICAgICAgICBkZWxlZ2F0ZWQgPSBvcGVuZWQ7XG4gICAgICB9XG5cbiAgICAgIC8vIOKUgOKUgCBVUkwtZGlzcGF0Y2ggcGF0aCAoUjMtODMxLCBSRVBPX0NPTlRFTlRfRElTUEFUQ0hfU1BFQyDCpzMpIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAgICAgLy8gQSBjb2xkIFVSTCBsb2FkIGludG8gYSByZXBvIHdob3NlIG1hcmtlciBuYW1lcyBgb3Blbi1wcm9qZWN0YFxuICAgICAgLy8gZGlzcGF0Y2hlcyB0byB1cyBhcyB0aGUgYm91bmQgdmlld2VyIHdpdGggTk8gdGFzayBpbnB1dDogdGhlIGhvc3RcbiAgICAgIC8vIG1vdW50cyB0aGUgbG9hZGVkIHJlcG8gYXMgb3VyIGNvcnB1cywgbWFya2VkIGB0eXBlOiAnY29udGVudCdgLiBUaGF0XG4gICAgICAvLyBtb3VudCBJUyB0aGUgcHJvamVjdCB0aGUgVVJMIG9wZW5lZCDigJQgbG9hZCB0aGUgYm9hcmQgZnJvbSBpdCBCRUZPUkVcbiAgICAgIC8vIHRoZSBkdXJhYmxlIHBhdGgsIHNvIGEgZGlzcGF0Y2hlZCBwcm9qZWN0IHNob3dzIGl0cyBvd24gYm9hcmQsIG5vdFxuICAgICAgLy8gdGhlIGRlbW8gc2VlZC4gQ2hyb290ZWQgYXMgbW91bnRlZCAocm8gYXMgZGlzcGF0Y2hlZCk6IHNhdmluZyBmb2xsb3dzXG4gICAgICAvLyB3aGF0ZXZlciB0aGUgY29ycHVzIGdyYW50IGFsbG93cywgbGlrZSBhbnkgYm9hcmQgdGFyZ2V0LiBBIGNvcnB1c1xuICAgICAgLy8gd2l0aCBubyBib2FyZCBmaWxlcywgb3IgYSBmYWlsZWQgbG9hZCwgZmFsbHMgdGhyb3VnaCB0byB0aGUgZHVyYWJsZVxuICAgICAgLy8gcGF0aCB1bmNoYW5nZWQuXG4gICAgICAvL1xuICAgICAgLy8gVGhlIHJlYWQgaXMgYSBib3VuZGVkIHBvbGwgKGBwb2xsRm9yQ29ycHVzTW91bnRgLCB0aGUgc2libGluZyBvZiB0aGVcbiAgICAgIC8vIGRlbGVnYXRlZCBtb3VudCdzIHBvbGwgYWJvdmUpOiB0aGUgU0RLJ3MgbW91bnQgbWlycm9yIHBvcHVsYXRlcyBmcm9tXG4gICAgICAvLyB0aGUgaG9zdCdzIG1vdW50LWFkZCByZS1hbm5vdW5jZW1lbnQgYXN5bmNocm9ub3VzbHkgcmVsYXRpdmUgdG8gdGhpc1xuICAgICAgLy8gZWZmZWN0LCBhbmQgYSBvbmUtc2hvdCByZWFkIGludGVybWl0dGVudGx5IG1pc3NlZCB0aGUgY29ycHVzIGFuZFxuICAgICAgLy8gYm9vdGVkIHRoZSBkZW1vIGJvYXJkIGluc3RlYWQgKGZvdW5kIGxpdmUgb24gdGhlIHZlbnVlLCAyMDI2LTEwLTAzKS5cbiAgICAgIGlmICghZGVsZWdhdGVkKSB7XG4gICAgICAgIGxldCBjb3JwdXM6IFNhbmRib3hNb3VudCB8IG51bGwgPSBudWxsO1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvcnB1cyA9IGF3YWl0IHBvbGxGb3JDb3JwdXNNb3VudChnZXRNb3VudHMsICgpID0+IGNhbmNlbGxlZCk7XG4gICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgIC8vIE5vIGhvc3QgcnVudGltZSAobG9jYWwgdml0ZSBkZXYpOiBubyBjb3JwdXM7IHRoZSBkdXJhYmxlIHBhdGggYW5zd2Vycy5cbiAgICAgICAgfVxuICAgICAgICBpZiAoY29ycHVzKSB7XG4gICAgICAgICAgY29uc3QgdGFyZ2V0ID0gZGlyQ2FwVG9Cb2FyZFRhcmdldChjb3JwdXMpO1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICBpZiAoYXdhaXQgYm9hcmRFeGlzdHModGFyZ2V0KSkge1xuICAgICAgICAgICAgICBhd2FpdCBsb2FkQm9hcmRJbnRvKHRhcmdldCk7XG4gICAgICAgICAgICAgIGlmICghY2FuY2VsbGVkKSB0b2FzdCgnUHJvamVjdCBvcGVuZWQuJywgJ2NoZWNrJyk7XG4gICAgICAgICAgICAgIGRlbGVnYXRlZCA9IHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgaWYgKCFjYW5jZWxsZWQpIHRvYXN0KGBDb3VsZG7igJl0IG9wZW4gcHJvamVjdCR7Y29kZU9mKGUpfWAsICdhbGVydCcsIHsgaWNvbkNvbG9yOiAnI2NhYTI0YScgfSk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICAvLyBBIGNhbmNlbGxlZCBjaGFpbiAodGhlIGNvbXBvbmVudCB1bm1vdW50ZWQgbWlkLXBvbGwsIG9yIGEgY29ycHVzIGxvYWRcbiAgICAgIC8vIHNldHRsZWQgYWZ0ZXIgdW5tb3VudCkgc3RvcHMgaGVyZTogdGhlIGR1cmFibGUgcGF0aCBiZWxvdyB3b3VsZCBvcGVuXG4gICAgICAvLyB0aGUgdXNlcidzIGJvYXJkIHNwYWNlIGFuZCB0b2FzdCBpbnRvIGFuIHVubW91bnRlZCBjYW52YXMuXG4gICAgICBpZiAoY2FuY2VsbGVkKSByZXR1cm47XG5cbiAgICAgIGlmICghZGVsZWdhdGVkKSB7XG4gICAgICAgIGxldCB0YXJnZXQ6IEJvYXJkVGFyZ2V0O1xuICAgICAgICB0cnkge1xuICAgICAgICAgIC8vIEF1dG8tb3BlbiB0aGUgc2lnbmVkLWluIHVzZXIncyBib2FyZCBzcGFjZS4gRGVjbGluZWQgLyBzaWduZWQtb3V0XG4gICAgICAgICAgLy8gcmVqZWN0cyB3aXRoIGEgdHlwZWQgU3BhY2VFcnJvciDigJQgd2UgZGVncmFkZSB0byB0aGUgaW4tbWVtb3J5IHNlZWQuXG4gICAgICAgICAgdGFyZ2V0ID0gYXdhaXQgb3BlbkJvYXJkVGFyZ2V0KCk7XG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAvLyBPbmx5IGBhdXRoLXJlcXVpcmVkYCBpcyBhIHNpZ24taW4gcHJvYmxlbTsgYW55dGhpbmcgZWxzZSBpcyBsb2dnZWRcbiAgICAgICAgICAvLyB3aXRoIGl0cyBjb2RlIGFuZCByZXBvcnRlZCBhcyB0aGUgcGxhdGZvcm0gZmFpbHVyZSBpdCBpcy5cbiAgICAgICAgICBjb25zdCBmYWlsdXJlID0gY2xhc3NpZnlCb2FyZFRhcmdldEZhaWx1cmUoZSk7XG4gICAgICAgICAgaWYgKCFjYW5jZWxsZWQpXG4gICAgICAgICAgICB0b2FzdChcbiAgICAgICAgICAgICAgZmFpbHVyZS5jb3B5LFxuICAgICAgICAgICAgICBmYWlsdXJlLmF1dGggPyAnc2F2ZScgOiAnYWxlcnQnLFxuICAgICAgICAgICAgICBmYWlsdXJlLmF1dGggPyB7IGljb25Db2xvcjogJ3ZhcigtLWluay0yKScgfSA6IHsgaWNvbkNvbG9yOiAnI2NhYTI0YScgfSxcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGlmIChjYW5jZWxsZWQpIHJldHVybjtcbiAgICAgICAgYm9hcmRSZWYuY3VycmVudCA9IHRhcmdldDtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBpZiAoYXdhaXQgYm9hcmRFeGlzdHModGFyZ2V0KSkge1xuICAgICAgICAgICAgY29uc3QgYm9hcmQgPSBhd2FpdCBsb2FkQm9hcmQodGFyZ2V0KTtcbiAgICAgICAgICAgIGlmICghY2FuY2VsbGVkKSB7XG4gICAgICAgICAgICAgIHVwZGF0ZSh7XG4gICAgICAgICAgICAgICAgb2JqZWN0czogYm9hcmQub2JqZWN0cyxcbiAgICAgICAgICAgICAgICB2aWV3czogYm9hcmQudmlld3MubGVuZ3RoID8gYm9hcmQudmlld3MgOiBTRUVEX1ZJRVdTLnNsaWNlKCksXG4gICAgICAgICAgICAgICAgam91cm5leXM6IGJvYXJkLmpvdXJuZXlzLmxlbmd0aCA/IGJvYXJkLmpvdXJuZXlzIDogU0VFRF9KT1VSTkVZUyxcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgIHRvYXN0KCdCb2FyZCBsb2FkZWQgZnJvbSB5b3VyIHNwYWNlLicsICdjaGVjaycpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAvLyBGaXJzdCBydW4gb24gYW4gZW1wdHkgc3BhY2U6IHBlcnNpc3QgdGhlIHNlZWQgZGVtbyBhcyB0aGUgc3RhcnRpbmcgYm9hcmQuXG4gICAgICAgICAgICBjb25zdCBzID0gc3RhdGVSZWYuY3VycmVudDtcbiAgICAgICAgICAgIGF3YWl0IHNlZWRCb2FyZCh0YXJnZXQsIHsgb2JqZWN0czogcy5vYmplY3RzLCB2aWV3czogcy52aWV3cywgam91cm5leXM6IHMuam91cm5leXMgfSk7XG4gICAgICAgICAgICBpZiAoIWNhbmNlbGxlZCkgdG9hc3QoJ0JvYXJkIGNyZWF0ZWQgaW4geW91ciBzcGFjZS4nLCAnY2hlY2snKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICBpZiAoIWNhbmNlbGxlZCkgdG9hc3QoYENvdWxkbid0IG9wZW4gYm9hcmQke2NvZGVPZihlKX1gLCAnYWxlcnQnLCB7IGljb25Db2xvcjogJyNjYWEyNGEnIH0pO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBpZiAoY2FuY2VsbGVkKSByZXR1cm47XG4gICAgICAvLyBNaXJyb3IgdGhlIGxpdmUgbW91bnRzIGludG8gc3RhdGUgKHRoZSBib2FyZCBjaG9vc2VyIGxpc3RzIHRoZXNlLFxuICAgICAgLy8gUjMtNjA3KSBhbG9uZ3NpZGUgdGhlIGRvd25ncmFkZSB3YXRjaCBiZWxvdy5cbiAgICAgIHRyeSB7XG4gICAgICAgIHVwZGF0ZSh7IG1vdW50czogZ2V0TW91bnRzKCkgfSk7XG4gICAgICB9IGNhdGNoIHtcbiAgICAgICAgLy8gTm8gaG9zdCBydW50aW1lIHlldCDigJQgdGhlIGxpc3Qgc3RheXMgZW1wdHkgYW5kIHRoZSBjaG9vc2VyIGRlZ3JhZGVzLlxuICAgICAgfVxuICAgICAgLy8gQSBsaXZlIHJvbGUtZG93bmdyYWRlIHJlLWFubm91bmNlcyB0aGUgbW91bnQgYXMgYHJvYDsgcmVtb3ZhbCB0ZWFycyBpdCBkb3duLlxuICAgICAgLy8gVGhlIG1vdW50IHNlcnZpY2UgbmVlZHMgdGhlIGhvc3QgcnVudGltZSwgd2hpY2ggaXMgYWJzZW50IHVuZGVyIGxvY2FsXG4gICAgICAvLyBgdml0ZSBkZXZgIOKAlCB0aGVyZSB0aGUgYm9hcmQgaXMgYSBzdGF0aWMgb24tZGlzayBkaXIgd2l0aCBubyByb2xlIGNoYW5nZXMsXG4gICAgICAvLyBzbyBza2lwIHRoZSBzdWJzY3JpcHRpb24gcmF0aGVyIHRoYW4gY3Jhc2guXG4gICAgICB0cnkge1xuICAgICAgICB1bnN1YiA9IG9uTW91bnRzQ2hhbmdlKChtb3VudHMsIHJlbW92ZWQpID0+IHtcbiAgICAgICAgICB1cGRhdGUoeyBtb3VudHMgfSk7XG4gICAgICAgICAgY29uc3QgY3VyID0gYm9hcmRSZWYuY3VycmVudDtcbiAgICAgICAgICBpZiAoIWN1cikgcmV0dXJuO1xuICAgICAgICAgIGNvbnN0IG0gPSBtb3VudHMuZmluZCgoeCkgPT4gKGN1ci5zcGFjZUlkID8geC5pZCA9PT0gY3VyLnNwYWNlSWQgOiB4LnBhdGggPT09IGN1ci5yb290KSk7XG4gICAgICAgICAgaWYgKG0pIHtcbiAgICAgICAgICAgIGNvbnN0IG1vZGUgPSBtLm1vZGUgPT09ICdybycgPyAncm8nIDogJ3J3JztcbiAgICAgICAgICAgIGlmIChtb2RlICE9PSBjdXIubW9kZSkge1xuICAgICAgICAgICAgICBib2FyZFJlZi5jdXJyZW50ID0geyAuLi5jdXIsIG1vZGUgfTtcbiAgICAgICAgICAgICAgaWYgKG1vZGUgPT09ICdybycpIHtcbiAgICAgICAgICAgICAgICB1cGRhdGUoeyBtb2RlOiAncnVuJywgc2VsZWN0aW9uOiBbXSwgaW5zcGVjdG9yT3BlbjogZmFsc2UgfSk7XG4gICAgICAgICAgICAgICAgdG9hc3QoJ1lvdXIgYWNjZXNzIGNoYW5nZWQgdG8gcmVhZC1vbmx5LicsICdsb2NrJywgeyBpY29uQ29sb3I6ICd2YXIoLS1pbmstMiknIH0pO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSBlbHNlIGlmIChyZW1vdmVkLnNvbWUoKHIpID0+IChjdXIuc3BhY2VJZCA/IHIuaWQgPT09IGN1ci5zcGFjZUlkIDogci5wYXRoID09PSBjdXIucm9vdCkpKSB7XG4gICAgICAgICAgICBib2FyZFJlZi5jdXJyZW50ID0gbnVsbDtcbiAgICAgICAgICAgIHRvYXN0KCdCb2FyZCBzcGFjZSBkaXNjb25uZWN0ZWQuJywgJ2FsZXJ0JywgeyBpY29uQ29sb3I6ICd2YXIoLS1pbmstMiknIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICB9IGNhdGNoIHtcbiAgICAgICAgLy8gTm8gaG9zdCBydW50aW1lIChsb2NhbCBgdml0ZSBkZXZgKTogbm8gbGl2ZSBtb3VudCB1cGRhdGVzIHRvIHRyYWNrLlxuICAgICAgfVxuICAgIH0pKCk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGNhbmNlbGxlZCA9IHRydWU7XG4gICAgICB1bnN1Yj8uKCk7XG4gICAgICBmb3IgKGNvbnN0IGggb2YgdGltZXJzLnZhbHVlcygpKSBjbGVhclRpbWVvdXQoaCk7XG4gICAgICB0aW1lcnMuY2xlYXIoKTtcbiAgICAgIGlmIChob2xkVGltZXIuY3VycmVudCkgY2xlYXJUaW1lb3V0KGhvbGRUaW1lci5jdXJyZW50KTtcbiAgICAgIGhvbGRUaW1lci5jdXJyZW50ID0gbnVsbDtcbiAgICB9O1xuICAgIC8vIFJ1bnMgb25jZSBvbiBtb3VudDsgcmVhZHMgbGl2ZSBzdGF0ZSB2aWEgc3RhdGVSZWYgYW5kIHN0YWJsZSBjYWxsYmFja3MuXG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWhvb2tzL2V4aGF1c3RpdmUtZGVwc1xuICB9LCBbXSk7XG5cbiAgcmV0dXJuIHtcbiAgICBzdGF0ZSxcbiAgICByZWdpc3RlckNhbnZhcyxcbiAgICBib2FyZFJvb3Q6IGJvYXJkUmVmLmN1cnJlbnQ/LnJvb3QgPz8gbnVsbCxcbiAgICBpc01vYmlsZSxcbiAgICAvLyBjYW1lcmFcbiAgICBvcmlnaW5YOiAodnc6IG51bWJlcikgPT4gb3JpZ2luWChzdGF0ZS5jYW0sIHZ3KSxcbiAgICBvcmlnaW5ZOiAodmg6IG51bWJlcikgPT4gb3JpZ2luWShzdGF0ZS5jYW0sIHZoKSxcbiAgICBwcm9qZWN0OiAod3g6IG51bWJlciwgd3k6IG51bWJlcikgPT4gcHJvamVjdChzdGF0ZS5jYW0sIHN0YXRlLnZwLCB3eCwgd3kpLFxuICAgIHNldFpvb20sXG4gICAgY2xhbXBab29tLFxuICAgIGZseVRvLFxuICAgIGFuY2hvclBvaW50LFxuICAgIC8vIGdlc3R1cmVzXG4gICAgb25DYW52YXNEb3duLFxuICAgIG9uQ2FudmFzRGJsQ2xpY2ssXG4gICAgb2JqUG9pbnRlckRvd24sXG4gICAgc3RhcnRIYW5kbGUsXG4gICAgc3RhcnRDb25uZWN0LFxuICAgIHNldEhvdmVyLFxuICAgIGNsZWFyU2VsZWN0aW9uLFxuICAgIHNlbGVjdCxcbiAgICBjbG9zZVF1aWNrTWVudSxcbiAgICAvLyBrZXlib2FyZCBjb25uZWN0ICh0aGUgbm9uLWRyYWcgcGF0aClcbiAgICBiZWdpbkNvbm5lY3QsXG4gICAgZW5kQ29ubmVjdCxcbiAgICBtb3ZlQ29ubmVjdEN1cnNvcixcbiAgICAvLyBtdXRhdGlvbnNcbiAgICBwYXRjaFNlbCxcbiAgICBwYXRjaE9iamVjdCxcbiAgICBkZWxldGVTZWxlY3Rpb24sXG4gICAgY3JlYXRlT2JqZWN0LFxuICAgIC8vIHBpY2stZmlsZSBmbG93c1xuICAgIGluc2VydEltYWdlLFxuICAgIG9wZW5Cb2FyZCxcbiAgICBvcGVuQm9hcmRBdCxcbiAgICBuZXdCb2FyZCxcbiAgICBuZXdCb2FyZEluLFxuICAgIG9wZW5Cb2FyZEluLFxuICAgIGFkZFNwYWNlLFxuICAgIC8vIHZpZXdzICYgam91cm5leXNcbiAgICBzYXZlVmlldyxcbiAgICBkZWxldGVWaWV3LFxuICAgIGFkZEpvdXJuZXlTdGVwLFxuICAgIHJlc29sdmVWaWV3LFxuICAgIHBsYXlKb3VybmV5LFxuICAgIHBsYXlOZXh0LFxuICAgIHBsYXlQcmV2LFxuICAgIHBsYXlFeGl0LFxuICAgIHBsYXlTZWVrLFxuICAgIC8vIG1vZGUgLyBjaHJvbWVcbiAgICBzZXRSdW4sXG4gICAgc2V0RWRpdCxcbiAgICB0b2dnbGVUaGVtZSxcbiAgICB0b2dnbGVQYW5lbCxcbiAgICBjbG9zZUluc3BlY3RvcixcbiAgICBjbG9zZVBhbmVsLFxuICAgIHNldEJhY2tncm91bmQsXG4gICAgc2V0TGlnaHQsXG4gICAgc2V0U2NyZWVuLFxuICAgIHRvZ2dsZURlbW9NZW51LFxuICAgIC8vIHRvYXN0cyArIGRlbW9cbiAgICB0b2FzdCxcbiAgICBkaXNtaXNzVG9hc3QsXG4gICAgZGVtb0xXVyxcbiAgICBkZW1vRG93bmdyYWRlLFxuICB9O1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7OztBQU9BLElBQUFBLE1BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLE9BQUEsR0FBQUQsT0FBQTtBQVVBLElBQUFFLFNBQUEsR0FBQUYsT0FBQTtBQUNBLElBQUFHLElBQUEsR0FBQUgsT0FBQTtBQWNBLElBQUFJLFVBQUEsR0FBQUosT0FBQTtBQUNBLElBQUFLLFdBQUEsR0FBQUwsT0FBQTtBQWlCQSxJQUFBTSxTQUFBLEdBQUFOLE9BQUE7QUFJQSxJQUFBTyxPQUFBLEdBQUFQLE9BQUE7QUFFQSxJQUFBUSxZQUFBLEdBQUFSLE9BQUE7QUF6REE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQStDQTtBQUNBO0FBQ0E7O0FBWUE7QUFDQSxNQUFNUyxPQUFPLEdBQUdBLENBQUNDLElBQVksRUFBRUMsR0FBVyxLQUFhLEdBQUdELElBQUksSUFBSUMsR0FBRyxFQUFFLENBQUNDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDOztBQUU1RjtBQUNBLFNBQVNDLE1BQU1BLENBQUNDLENBQVUsRUFBVTtFQUNsQyxNQUFNQyxDQUFDLEdBQUlELENBQUMsRUFBK0JFLElBQUk7RUFDL0MsT0FBT0QsQ0FBQyxHQUFHLE1BQU1BLENBQUMsRUFBRSxHQUFHLEVBQUU7QUFDM0I7QUE2Q0EsTUFBTUUsZUFBZSxHQUFHQSxDQUFBLE1BQWlCO0VBQ3ZDQyxFQUFFLEVBQUUsT0FBT0MsTUFBTSxLQUFLLFdBQVcsR0FBR0EsTUFBTSxDQUFDQyxVQUFVLEdBQUcsSUFBSTtFQUM1REMsRUFBRSxFQUFFLE9BQU9GLE1BQU0sS0FBSyxXQUFXLEdBQUdBLE1BQU0sQ0FBQ0csV0FBVyxHQUFHLEdBQUc7RUFDNURDLEtBQUssRUFBRSxDQUFDO0VBQ1JDLElBQUksRUFBRTtBQUNSLENBQUMsQ0FBQzs7QUFFRjtBQUNBO0FBQ0E7QUFDTyxTQUFTQyxjQUFjQSxDQUFDQyxHQUFhLEVBQUVDLEVBQVUsRUFBRUMsUUFBaUIsRUFBWTtFQUNyRixJQUFJQSxRQUFRLEVBQUUsT0FBT0YsR0FBRyxDQUFDRyxRQUFRLENBQUNGLEVBQUUsQ0FBQyxHQUFHRCxHQUFHLENBQUNJLE1BQU0sQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLEtBQUtKLEVBQUUsQ0FBQyxHQUFHRCxHQUFHLENBQUNNLE1BQU0sQ0FBQ0wsRUFBRSxDQUFDO0VBQ3BGLE9BQU9ELEdBQUcsQ0FBQ0csUUFBUSxDQUFDRixFQUFFLENBQUMsR0FBR0QsR0FBRyxHQUFHLENBQUNDLEVBQUUsQ0FBQztBQUN0QztBQUVBLE1BQU1NLGlCQUFpQixHQUFHLEdBQUc7O0FBRTdCO0FBQ0E7QUFDQTtBQUNBLE1BQU1DLGdCQUFnQixHQUFHLENBQUM7O0FBRTFCO0FBQ0E7QUFDQTtBQUNBLE1BQU1DLGlCQUFpQixHQUFHLEdBQUc7QUFFN0IsTUFBTUMsb0JBQW9CLEdBQUdBLENBQUEsS0FBZTtFQUMxQyxJQUFJO0lBQ0YsT0FBT2pCLE1BQU0sQ0FBQ2tCLFVBQVUsQ0FBQyxrQ0FBa0MsQ0FBQyxDQUFDQyxPQUFPO0VBQ3RFLENBQUMsQ0FBQyxNQUFNO0lBQ04sT0FBTyxLQUFLO0VBQ2Q7QUFDRixDQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUNPLE1BQU1DLFdBQVcsR0FBQUMsT0FBQSxDQUFBRCxXQUFBLEdBQUc7RUFDekIsY0FBYyxFQUFFLGVBQWU7RUFDL0IsV0FBVyxFQUFFLGlCQUFpQjtFQUM5QixZQUFZLEVBQUU7QUFDaEIsQ0FBVTtBQUVILFNBQVNFLFdBQVdBLENBQUEsRUFBRztFQUM1QjtFQUNBO0VBQ0EsTUFBTSxDQUFDQyxRQUFRLEVBQUVDLFdBQVcsQ0FBQyxHQUFHLElBQUFDLGVBQVEsRUFBd0IsSUFBSSxDQUFDO0VBQ3JFLE1BQU1DLGNBQWMsR0FBRyxJQUFBQyxrQkFBVyxFQUFFQyxFQUF5QixJQUFLSixXQUFXLENBQUNJLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQztFQUN0RixNQUFNQyxPQUFPLEdBQUcsSUFBQUMsYUFBTSxFQUFPLElBQUksQ0FBQztFQUNsQyxNQUFNQyxRQUFRLEdBQUcsSUFBQUQsYUFBTSxFQUFnQixJQUFJLENBQUM7RUFDNUMsTUFBTUUsU0FBUyxHQUFHLElBQUFGLGFBQU0sRUFBZ0IsSUFBSSxDQUFDO0VBQzdDLE1BQU1HLFFBQVEsR0FBRyxJQUFBSCxhQUFNLEVBQUMsS0FBSyxDQUFDO0VBQzlCLE1BQU1JLFFBQVEsR0FBRyxJQUFBSixhQUFNLEVBQUMsQ0FBQyxDQUFDO0VBQzFCO0VBQ0E7RUFDQTtFQUNBLE1BQU1LLFdBQVcsR0FBRyxJQUFBTCxhQUFNLEVBQWEsTUFBTSxDQUFDLENBQUMsQ0FBQztFQUVoRCxNQUFNLENBQUNNLEtBQUssRUFBRUMsUUFBUSxDQUFDLEdBQUcsSUFBQVosZUFBUSxFQUFVLE9BQU87SUFDakRhLElBQUksRUFBRSxLQUFLO0lBQ1hDLEtBQUssRUFBRSxLQUFLO0lBQ1pDLEVBQUUsRUFBRUMsZ0JBQUssQ0FBQ0MsVUFBVTtJQUNwQkMsS0FBSyxFQUFFRixnQkFBSyxDQUFDRSxLQUFLO0lBQ2xCQyxHQUFHLEVBQUU7TUFBRUMsRUFBRSxFQUFFLEdBQUc7TUFBRUMsRUFBRSxFQUFFLEdBQUc7TUFBRUMsSUFBSSxFQUFFO0lBQUksQ0FBQztJQUNwQ0MsRUFBRSxFQUFFbEQsZUFBZSxDQUFDLENBQUM7SUFDckJtRCxPQUFPLEVBQUUsSUFBQUMsc0JBQVcsRUFBQyxDQUFDO0lBQ3RCQyxLQUFLLEVBQUVDLHFCQUFVLENBQUNDLEtBQUssQ0FBQyxDQUFDO0lBQ3pCQyxRQUFRLEVBQUVDLHdCQUFhO0lBQ3ZCQyxTQUFTLEVBQUUsRUFBRTtJQUNiQyxLQUFLLEVBQUUsSUFBSTtJQUNYQyxPQUFPLEVBQUUsSUFBSTtJQUNiQyxjQUFjLEVBQUUsSUFBSTtJQUNwQkMsV0FBVyxFQUFFLElBQUk7SUFDakJDLGFBQWEsRUFBRSxJQUFJO0lBQ25CQyxhQUFhLEVBQUUsS0FBSztJQUNwQkMsU0FBUyxFQUFFLEtBQUs7SUFDaEJDLFNBQVMsRUFBRSxJQUFJO0lBQ2ZDLE9BQU8sRUFBRSxJQUFJO0lBQ2JDLE1BQU0sRUFBRSxFQUFFO0lBQ1ZDLE1BQU0sRUFBRSxJQUFJO0lBQ1pDLFlBQVksRUFBRSxLQUFLO0lBQ25CQyxPQUFPLEVBQUUsS0FBSztJQUNkQyxPQUFPLEVBQUVyRCxvQkFBb0IsQ0FBQyxDQUFDO0lBQy9Cc0QsSUFBSSxFQUFFLElBQUk7SUFDVkMsTUFBTSxFQUFFO0VBQ1YsQ0FBQyxDQUFDLENBQUM7O0VBRUg7RUFDQSxNQUFNQyxRQUFRLEdBQUcsSUFBQTNDLGFBQU0sRUFBQ00sS0FBSyxDQUFDO0VBQzlCLElBQUFzQyxnQkFBUyxFQUFDLE1BQU07SUFDZEQsUUFBUSxDQUFDRSxPQUFPLEdBQUd2QyxLQUFLO0VBQzFCLENBQUMsQ0FBQztFQUVGLE1BQU13QyxNQUFNLEdBQUcsSUFBQWpELGtCQUFXLEVBQ3ZCa0QsS0FBNEQsSUFDM0R4QyxRQUFRLENBQUV5QyxJQUFJLEtBQU07SUFBRSxHQUFHQSxJQUFJO0lBQUUsSUFBSSxPQUFPRCxLQUFLLEtBQUssVUFBVSxHQUFHQSxLQUFLLENBQUNDLElBQUksQ0FBQyxHQUFHRCxLQUFLO0VBQUUsQ0FBQyxDQUFDLENBQUMsRUFDM0YsRUFDRixDQUFDO0VBRUQsTUFBTUUsUUFBUSxHQUFHLElBQUFwRCxrQkFBVyxFQUFDLE1BQU1TLEtBQUssQ0FBQ1ksRUFBRSxDQUFDakQsRUFBRSxHQUFHZSxpQkFBaUIsRUFBRSxDQUFDc0IsS0FBSyxDQUFDWSxFQUFFLENBQUNqRCxFQUFFLENBQUMsQ0FBQzs7RUFFbEY7RUFDQSxNQUFNaUYsVUFBVSxHQUFHLElBQUFyRCxrQkFBVyxFQUFFaEMsQ0FBdUMsSUFBdUI7SUFDNUYsTUFBTXFELEVBQUUsR0FBR3lCLFFBQVEsQ0FBQ0UsT0FBTyxDQUFDM0IsRUFBRTtJQUM5QixPQUFPLENBQUNyRCxDQUFDLENBQUNzRixPQUFPLEdBQUdqQyxFQUFFLENBQUM1QyxLQUFLLEVBQUVULENBQUMsQ0FBQ3VGLE9BQU8sR0FBR2xDLEVBQUUsQ0FBQzNDLElBQUksQ0FBQztFQUNwRCxDQUFDLEVBQUUsRUFBRSxDQUFDO0VBRU4sTUFBTThFLE9BQU8sR0FBRyxJQUFBeEQsa0JBQVcsRUFBQyxDQUFDeUQsRUFBVSxFQUFFQyxFQUFXLEVBQUVDLEVBQVcsS0FBSztJQUNwRVYsTUFBTSxDQUFFVyxDQUFDLEtBQU07TUFBRTNDLEdBQUcsRUFBRSxJQUFBNEMsa0JBQVUsRUFBQ0QsQ0FBQyxDQUFDM0MsR0FBRyxFQUFFMkMsQ0FBQyxDQUFDdkMsRUFBRSxFQUFFb0MsRUFBRSxFQUFFQyxFQUFFLEVBQUVDLEVBQUU7SUFBRSxDQUFDLENBQUMsQ0FBQztFQUMvRCxDQUFDLEVBQUUsQ0FBQ1YsTUFBTSxDQUFDLENBQUM7O0VBRVo7RUFDQSxNQUFNYSxZQUFZLEdBQUcsSUFBQTlELGtCQUFXLEVBQUVuQixFQUFVLElBQUs7SUFDL0NvRSxNQUFNLENBQUVXLENBQUMsS0FBTTtNQUFFckIsTUFBTSxFQUFFcUIsQ0FBQyxDQUFDckIsTUFBTSxDQUFDdkQsTUFBTSxDQUFFK0UsQ0FBQyxJQUFLQSxDQUFDLENBQUNsRixFQUFFLEtBQUtBLEVBQUU7SUFBRSxDQUFDLENBQUMsQ0FBQztFQUNsRSxDQUFDLEVBQUUsQ0FBQ29FLE1BQU0sQ0FBQyxDQUFDO0VBRVosTUFBTWUsS0FBSyxHQUFHLElBQUFoRSxrQkFBVyxFQUN2QixDQUFDaUUsSUFBWSxFQUFFQyxJQUFJLEdBQUcsT0FBTyxFQUFFQyxJQUFvQixHQUFHLENBQUMsQ0FBQyxLQUFLO0lBQzNELE1BQU10RixFQUFFLEdBQUcsRUFBRTBCLFFBQVEsQ0FBQ3lDLE9BQU87SUFDN0IsTUFBTWUsQ0FBUSxHQUFHO01BQUVsRixFQUFFO01BQUVvRixJQUFJO01BQUVDLElBQUk7TUFBRSxHQUFHQztJQUFLLENBQUM7SUFDNUNsQixNQUFNLENBQUVXLENBQUMsS0FBTTtNQUFFckIsTUFBTSxFQUFFcUIsQ0FBQyxDQUFDckIsTUFBTSxDQUFDckQsTUFBTSxDQUFDNkUsQ0FBQztJQUFFLENBQUMsQ0FBQyxDQUFDO0lBQy9DLE1BQU1LLEdBQUcsR0FBR0QsSUFBSSxDQUFDRSxXQUFXLEdBQUcsSUFBSSxHQUFHLElBQUk7SUFDMUNDLFVBQVUsQ0FBQyxNQUFNUixZQUFZLENBQUNqRixFQUFFLENBQUMsRUFBRXVGLEdBQUcsQ0FBQztFQUN6QyxDQUFDLEVBQ0QsQ0FBQ25CLE1BQU0sRUFBRWEsWUFBWSxDQUN2QixDQUFDOztFQUVEO0VBQ0E7RUFDQTtFQUNBLE1BQU1TLFFBQVEsR0FBRyxJQUFBcEUsYUFBTSxFQUFxQixJQUFJLENBQUM7RUFDakQ7RUFDQTtFQUNBLE1BQU1xRSxVQUFVLEdBQUcsSUFBQXJFLGFBQU0sRUFBc0IsSUFBSXNFLEdBQUcsQ0FBQyxDQUFDLENBQUM7O0VBRXpEO0VBQ0E7RUFDQTtFQUNBLE1BQU1DLFVBQVUsR0FBRyxJQUFBMUUsa0JBQVcsRUFDNUIsQ0FBQzJFLElBQWUsRUFBRUMsU0FBaUIsRUFBRUMsU0FBUyxHQUFHLE9BQU8sS0FBSztJQUMzRCxNQUFNZCxDQUFDLEdBQUdRLFFBQVEsQ0FBQ3ZCLE9BQU87SUFDMUIsSUFBSSxDQUFDZSxDQUFDLEVBQUU7TUFDTkMsS0FBSyxDQUFDWSxTQUFTLEVBQUVDLFNBQVMsQ0FBQztNQUMzQjtJQUNGO0lBQ0EsSUFBSWQsQ0FBQyxDQUFDcEQsSUFBSSxLQUFLLElBQUksRUFBRTtNQUNuQnFELEtBQUssQ0FBQyxvQ0FBb0MsRUFBRSxNQUFNLEVBQUU7UUFBRWMsU0FBUyxFQUFFO01BQWUsQ0FBQyxDQUFDO01BQ2xGO0lBQ0Y7SUFDQUMsT0FBTyxDQUFDQyxHQUFHLENBQUNMLElBQUksQ0FBQ00sR0FBRyxDQUFFQyxDQUFDLElBQUssSUFBQUMsc0JBQVUsRUFBQ3BCLENBQUMsRUFBRW1CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ0UsSUFBSSxDQUNqRCxNQUFNcEIsS0FBSyxDQUFDWSxTQUFTLEVBQUVDLFNBQVMsQ0FBQyxFQUNoQzdHLENBQUMsSUFBS2dHLEtBQUssQ0FBQyxjQUFjakcsTUFBTSxDQUFDQyxDQUFDLENBQUMsRUFBRSxFQUFFLE9BQU8sRUFBRTtNQUFFOEcsU0FBUyxFQUFFO0lBQVUsQ0FBQyxDQUMzRSxDQUFDO0VBQ0gsQ0FBQyxFQUNELENBQUNkLEtBQUssQ0FDUixDQUFDOztFQUVEO0VBQ0EsTUFBTXFCLFlBQVksR0FBRyxJQUFBckYsa0JBQVcsRUFBRXNGLEdBQWEsSUFBSztJQUNsRCxNQUFNdkIsQ0FBQyxHQUFHUSxRQUFRLENBQUN2QixPQUFPO0lBQzFCLElBQUksQ0FBQ2UsQ0FBQyxJQUFJQSxDQUFDLENBQUNwRCxJQUFJLEtBQUssSUFBSSxFQUFFO0lBQzNCLEtBQUssTUFBTTlCLEVBQUUsSUFBSXlHLEdBQUcsRUFBRTtNQUNwQixNQUFNbkMsSUFBSSxHQUFHcUIsVUFBVSxDQUFDeEIsT0FBTyxDQUFDdUMsR0FBRyxDQUFDMUcsRUFBRSxDQUFDO01BQ3ZDLElBQUlzRSxJQUFJLEVBQUVxQyxZQUFZLENBQUNyQyxJQUFJLENBQUM7TUFDNUIsTUFBTXNDLE1BQU0sR0FBR3BILE1BQU0sQ0FBQ2lHLFVBQVUsQ0FBQyxNQUFNO1FBQ3JDRSxVQUFVLENBQUN4QixPQUFPLENBQUMwQyxNQUFNLENBQUM3RyxFQUFFLENBQUM7UUFDN0IsTUFBTXFHLENBQUMsR0FBR3BDLFFBQVEsQ0FBQ0UsT0FBTyxDQUFDMUIsT0FBTyxDQUFDcUUsSUFBSSxDQUFFMUcsQ0FBQyxJQUFLQSxDQUFDLENBQUNKLEVBQUUsS0FBS0EsRUFBRSxDQUFDO1FBQzNELElBQUlxRyxDQUFDLEVBQUUsSUFBQUMsc0JBQVUsRUFBQ3BCLENBQUMsRUFBRW1CLENBQUMsQ0FBQyxDQUFDVSxLQUFLLENBQUMsTUFBTUMsU0FBUyxDQUFDO01BQ2hELENBQUMsRUFBRSxHQUFHLENBQUM7TUFDUHJCLFVBQVUsQ0FBQ3hCLE9BQU8sQ0FBQzhDLEdBQUcsQ0FBQ2pILEVBQUUsRUFBRTRHLE1BQU0sQ0FBQztJQUNwQztFQUNGLENBQUMsRUFBRSxFQUFFLENBQUM7O0VBRU47RUFDQSxNQUFNTSxLQUFLLEdBQUcsSUFBQS9GLGtCQUFXLEVBQ3ZCLENBQUNnRyxNQUF5QixFQUFFQyxHQUFZLEVBQUVDLElBQWEsS0FBSztJQUMxRCxJQUFJLENBQUNGLE1BQU0sRUFBRTtJQUNiO0lBQ0E7SUFDQTtJQUNBLE1BQU1HLElBQUksR0FBRyxJQUFBQyx1QkFBZSxFQUFDSixNQUFNLEVBQUVsRCxRQUFRLENBQUNFLE9BQU8sQ0FBQzNCLEVBQUUsQ0FBQ2pELEVBQUUsRUFBRThILElBQUksSUFBSXBELFFBQVEsQ0FBQ0UsT0FBTyxDQUFDM0IsRUFBRSxDQUFDOUMsRUFBRSxDQUFDO0lBQzVGLElBQUk2QixRQUFRLENBQUM0QyxPQUFPLEVBQUVxRCxvQkFBb0IsQ0FBQ2pHLFFBQVEsQ0FBQzRDLE9BQU8sQ0FBQztJQUM1RCxJQUFJRixRQUFRLENBQUNFLE9BQU8sQ0FBQ0wsT0FBTyxJQUFJLENBQUNzRCxHQUFHLEVBQUU7TUFDcENoRCxNQUFNLENBQUM7UUFBRWhDLEdBQUcsRUFBRWtGO01BQUssQ0FBQyxDQUFDO01BQ3JCO0lBQ0Y7SUFDQSxNQUFNRyxJQUFJLEdBQUc7TUFBRSxHQUFHeEQsUUFBUSxDQUFDRSxPQUFPLENBQUMvQjtJQUFJLENBQUM7SUFDeEMsTUFBTXNGLEVBQUUsR0FBR0MsV0FBVyxDQUFDQyxHQUFHLENBQUMsQ0FBQztJQUM1QixNQUFNQyxJQUFJLEdBQUlDLENBQVMsSUFBTUEsQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDLEdBQUdBLENBQUMsR0FBR0EsQ0FBQyxHQUFHQSxDQUFDLEdBQUcsQ0FBQyxHQUFHQyxJQUFJLENBQUNDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBR0YsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFFO0lBQ3ZGLE1BQU1HLElBQUksR0FBSUwsR0FBVyxJQUFLO01BQzVCLE1BQU1FLENBQUMsR0FBR0MsSUFBSSxDQUFDRyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUNOLEdBQUcsR0FBR0YsRUFBRSxJQUFJTixHQUFHLENBQUM7TUFDdkMsTUFBTWpJLENBQUMsR0FBRzBJLElBQUksQ0FBQ0MsQ0FBQyxDQUFDO01BQ2pCMUQsTUFBTSxDQUFDO1FBQ0xoQyxHQUFHLEVBQUU7VUFDSEMsRUFBRSxFQUFFb0YsSUFBSSxDQUFDcEYsRUFBRSxHQUFHLENBQUNpRixJQUFJLENBQUNqRixFQUFFLEdBQUdvRixJQUFJLENBQUNwRixFQUFFLElBQUlsRCxDQUFDO1VBQ3JDbUQsRUFBRSxFQUFFbUYsSUFBSSxDQUFDbkYsRUFBRSxHQUFHLENBQUNnRixJQUFJLENBQUNoRixFQUFFLEdBQUdtRixJQUFJLENBQUNuRixFQUFFLElBQUluRCxDQUFDO1VBQ3JDb0QsSUFBSSxFQUFFa0YsSUFBSSxDQUFDbEYsSUFBSSxHQUFHLENBQUMrRSxJQUFJLENBQUMvRSxJQUFJLEdBQUdrRixJQUFJLENBQUNsRixJQUFJLElBQUlwRDtRQUM5QztNQUNGLENBQUMsQ0FBQztNQUNGLElBQUkySSxDQUFDLEdBQUcsQ0FBQyxFQUFFdkcsUUFBUSxDQUFDNEMsT0FBTyxHQUFHZ0UscUJBQXFCLENBQUNGLElBQUksQ0FBQztJQUMzRCxDQUFDO0lBQ0QxRyxRQUFRLENBQUM0QyxPQUFPLEdBQUdnRSxxQkFBcUIsQ0FBQ0YsSUFBSSxDQUFDO0VBQ2hELENBQUMsRUFDRCxDQUFDN0QsTUFBTSxDQUNULENBQUM7O0VBRUQ7RUFDQSxNQUFNZ0UsV0FBVyxHQUFHLElBQUFqSCxrQkFBVyxFQUFFa0gsQ0FBc0IsSUFBSztJQUMxRCxJQUFJLE9BQU9BLENBQUMsS0FBSyxRQUFRLEVBQUUsT0FBT3BFLFFBQVEsQ0FBQ0UsT0FBTyxDQUFDeEIsS0FBSyxDQUFDbUUsSUFBSSxDQUFFMUcsQ0FBQyxJQUFLQSxDQUFDLENBQUNrSSxJQUFJLEtBQUtELENBQUMsQ0FBQyxJQUFJLElBQUk7SUFDMUYsTUFBTW5ELENBQWEsR0FBRztNQUFFN0MsRUFBRSxFQUFFZ0csQ0FBQyxDQUFDaEcsRUFBRTtNQUFFQyxFQUFFLEVBQUUrRixDQUFDLENBQUMvRixFQUFFO01BQUVDLElBQUksRUFBRThGLENBQUMsQ0FBQzlGO0lBQUssQ0FBQztJQUMxRCxJQUFJOEYsQ0FBQyxDQUFDRSxDQUFDLEVBQUVyRCxDQUFDLENBQUNxRCxDQUFDLEdBQUdGLENBQUMsQ0FBQ0UsQ0FBQztJQUNsQixJQUFJRixDQUFDLENBQUNHLENBQUMsRUFBRXRELENBQUMsQ0FBQ3NELENBQUMsR0FBR0gsQ0FBQyxDQUFDRyxDQUFDO0lBQ2xCLE9BQU90RCxDQUFDO0VBQ1YsQ0FBQyxFQUFFLEVBQUUsQ0FBQztFQUVOLE1BQU11RCxRQUFRLEdBQUcsSUFBQXRILGtCQUFXLEVBQUMsTUFBTTtJQUNqQyxNQUFNNEQsQ0FBQyxHQUFHZCxRQUFRLENBQUNFLE9BQU87SUFDMUIsTUFBTXVFLElBQVUsR0FBRztNQUFFSixJQUFJLEVBQUUsUUFBUXZELENBQUMsQ0FBQ3BDLEtBQUssQ0FBQ2dHLE1BQU0sR0FBRyxDQUFDLEVBQUU7TUFBRXRHLEVBQUUsRUFBRTBDLENBQUMsQ0FBQzNDLEdBQUcsQ0FBQ0MsRUFBRTtNQUFFQyxFQUFFLEVBQUV5QyxDQUFDLENBQUMzQyxHQUFHLENBQUNFLEVBQUU7TUFBRUMsSUFBSSxFQUFFd0MsQ0FBQyxDQUFDM0MsR0FBRyxDQUFDRztJQUFLLENBQUM7SUFDdkc2QixNQUFNLENBQUV3RSxFQUFFLEtBQU07TUFBRWpHLEtBQUssRUFBRWlHLEVBQUUsQ0FBQ2pHLEtBQUssQ0FBQ3RDLE1BQU0sQ0FBQyxDQUFDcUksSUFBSSxDQUFDO0lBQUUsQ0FBQyxDQUFDLENBQUM7SUFDcEQsTUFBTXRELElBQUksR0FBRyxlQUFlc0QsSUFBSSxDQUFDSixJQUFJLEtBQUs7SUFDMUMsTUFBTXBELENBQUMsR0FBR1EsUUFBUSxDQUFDdkIsT0FBTztJQUMxQixJQUFJLENBQUNlLENBQUMsRUFBRTtNQUNOQyxLQUFLLENBQUNDLElBQUksRUFBRSxNQUFNLENBQUM7TUFDbkI7SUFDRjtJQUNBLElBQUlGLENBQUMsQ0FBQ3BELElBQUksS0FBSyxJQUFJLEVBQUU7TUFDbkJxRCxLQUFLLENBQUMsa0NBQWtDLEVBQUUsTUFBTSxFQUFFO1FBQUVjLFNBQVMsRUFBRTtNQUFlLENBQUMsQ0FBQztNQUNoRjtJQUNGO0lBQ0EsSUFBQTRDLG9CQUFXLEVBQUMzRCxDQUFDLEVBQUV3RCxJQUFJLENBQUMsQ0FBQ25DLElBQUksQ0FDdkIsTUFBTXBCLEtBQUssQ0FBQ0MsSUFBSSxFQUFFLE1BQU0sQ0FBQyxFQUN4QmpHLENBQUMsSUFBS2dHLEtBQUssQ0FBQyxxQkFBcUJqRyxNQUFNLENBQUNDLENBQUMsQ0FBQyxFQUFFLEVBQUUsT0FBTyxFQUFFO01BQUU4RyxTQUFTLEVBQUU7SUFBVSxDQUFDLENBQ2xGLENBQUM7RUFDSCxDQUFDLEVBQUUsQ0FBQzdCLE1BQU0sRUFBRWUsS0FBSyxDQUFDLENBQUM7O0VBRW5CO0FBQ0Y7QUFDQTtBQUNBO0VBQ0UsTUFBTTJELFVBQVUsR0FBRyxJQUFBM0gsa0JBQVcsRUFDM0JtSCxJQUFZLElBQUs7SUFDaEIsTUFBTXBELENBQUMsR0FBR1EsUUFBUSxDQUFDdkIsT0FBTztJQUMxQixNQUFNdUUsSUFBSSxHQUFHekUsUUFBUSxDQUFDRSxPQUFPLENBQUN4QixLQUFLLENBQUNtRSxJQUFJLENBQUV1QixDQUFDLElBQUtBLENBQUMsQ0FBQ0MsSUFBSSxLQUFLQSxJQUFJLENBQUM7SUFDaEUsSUFBSSxDQUFDSSxJQUFJLEVBQUU7SUFDWCxJQUFJeEQsQ0FBQyxJQUFJQSxDQUFDLENBQUNwRCxJQUFJLEtBQUssSUFBSSxFQUFFO01BQ3hCcUQsS0FBSyxDQUFDLG9DQUFvQyxFQUFFLE1BQU0sRUFBRTtRQUFFYyxTQUFTLEVBQUU7TUFBZSxDQUFDLENBQUM7TUFDbEY7SUFDRjtJQUNBN0IsTUFBTSxDQUFFVyxDQUFDLEtBQU07TUFBRXBDLEtBQUssRUFBRW9DLENBQUMsQ0FBQ3BDLEtBQUssQ0FBQ3hDLE1BQU0sQ0FBRWtJLENBQUMsSUFBS0EsQ0FBQyxDQUFDQyxJQUFJLEtBQUtBLElBQUk7SUFBRSxDQUFDLENBQUMsQ0FBQztJQUNsRSxJQUFJLENBQUNwRCxDQUFDLEVBQUU7TUFDTkMsS0FBSyxDQUFDLGlCQUFpQm1ELElBQUksS0FBSyxFQUFFLE9BQU8sQ0FBQztNQUMxQztJQUNGO0lBQ0EsSUFBQVMsc0JBQVUsRUFBQzdELENBQUMsRUFBRW9ELElBQUksQ0FBQyxDQUFDL0IsSUFBSSxDQUN0QixNQUFNcEIsS0FBSyxDQUFDLGlCQUFpQm1ELElBQUksS0FBSyxFQUFFLE9BQU8sQ0FBQyxFQUMvQ25KLENBQUMsSUFBSztNQUNMO01BQ0FpRixNQUFNLENBQUVXLENBQUMsSUFBTUEsQ0FBQyxDQUFDcEMsS0FBSyxDQUFDcUcsSUFBSSxDQUFFWCxDQUFDLElBQUtBLENBQUMsQ0FBQ0MsSUFBSSxLQUFLQSxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRztRQUFFM0YsS0FBSyxFQUFFb0MsQ0FBQyxDQUFDcEMsS0FBSyxDQUFDdEMsTUFBTSxDQUFDLENBQUNxSSxJQUFJLENBQUM7TUFBRSxDQUFFLENBQUM7TUFDOUZ2RCxLQUFLLENBQUMsdUJBQXVCakcsTUFBTSxDQUFDQyxDQUFDLENBQUMsRUFBRSxFQUFFLE9BQU8sRUFBRTtRQUFFOEcsU0FBUyxFQUFFO01BQVUsQ0FBQyxDQUFDO0lBQzlFLENBQ0YsQ0FBQztFQUNILENBQUMsRUFDRCxDQUFDN0IsTUFBTSxFQUFFZSxLQUFLLENBQ2hCLENBQUM7RUFFRCxNQUFNOEQsY0FBYyxHQUFHLElBQUE5SCxrQkFBVyxFQUMvQitILEdBQVcsSUFBSztJQUNmLE1BQU1uRSxDQUFDLEdBQUdkLFFBQVEsQ0FBQ0UsT0FBTztJQUMxQixNQUFNZ0YsQ0FBQyxHQUFHcEUsQ0FBQyxDQUFDakMsUUFBUSxDQUFDZ0UsSUFBSSxDQUFFMUcsQ0FBQyxJQUFLQSxDQUFDLENBQUNKLEVBQUUsS0FBS2tKLEdBQUcsQ0FBQztJQUM5QyxJQUFJLENBQUNDLENBQUMsRUFBRTtJQUNSLE1BQU1DLElBQWEsR0FBRztNQUFFLEdBQUdELENBQUM7TUFBRUUsS0FBSyxFQUFFRixDQUFDLENBQUNFLEtBQUssQ0FBQ2hKLE1BQU0sQ0FBQyxDQUFDO1FBQUVxSSxJQUFJLEVBQUU7VUFBRXJHLEVBQUUsRUFBRTBDLENBQUMsQ0FBQzNDLEdBQUcsQ0FBQ0MsRUFBRTtVQUFFQyxFQUFFLEVBQUV5QyxDQUFDLENBQUMzQyxHQUFHLENBQUNFLEVBQUU7VUFBRUMsSUFBSSxFQUFFd0MsQ0FBQyxDQUFDM0MsR0FBRyxDQUFDRztRQUFLO01BQUUsQ0FBQyxDQUFDO0lBQUUsQ0FBQztJQUNuSDZCLE1BQU0sQ0FBRXdFLEVBQUUsS0FBTTtNQUFFOUYsUUFBUSxFQUFFOEYsRUFBRSxDQUFDOUYsUUFBUSxDQUFDc0QsR0FBRyxDQUFFaEcsQ0FBQyxJQUFNQSxDQUFDLENBQUNKLEVBQUUsS0FBS2tKLEdBQUcsR0FBR0UsSUFBSSxHQUFHaEosQ0FBRTtJQUFFLENBQUMsQ0FBQyxDQUFDO0lBQ2pGLE1BQU1nRixJQUFJLEdBQUcsY0FBY2dFLElBQUksQ0FBQ0MsS0FBSyxDQUFDVixNQUFNLE9BQU9RLENBQUMsQ0FBQ2hILEtBQUssZUFBZWdILENBQUMsQ0FBQ25KLEVBQUUsTUFBTTtJQUNuRixNQUFNa0YsQ0FBQyxHQUFHUSxRQUFRLENBQUN2QixPQUFPO0lBQzFCLElBQUksQ0FBQ2UsQ0FBQyxFQUFFO01BQ05DLEtBQUssQ0FBQ0MsSUFBSSxFQUFFLE1BQU0sQ0FBQztNQUNuQjtJQUNGO0lBQ0EsSUFBSUYsQ0FBQyxDQUFDcEQsSUFBSSxLQUFLLElBQUksRUFBRTtNQUNuQnFELEtBQUssQ0FBQyxrQ0FBa0MsRUFBRSxNQUFNLEVBQUU7UUFBRWMsU0FBUyxFQUFFO01BQWUsQ0FBQyxDQUFDO01BQ2hGO0lBQ0Y7SUFDQSxJQUFBcUQsdUJBQWMsRUFBQ3BFLENBQUMsRUFBRWtFLElBQUksQ0FBQyxDQUFDN0MsSUFBSSxDQUMxQixNQUFNcEIsS0FBSyxDQUFDQyxJQUFJLEVBQUUsTUFBTSxDQUFDLEVBQ3hCakcsQ0FBQyxJQUFLZ0csS0FBSyxDQUFDLHdCQUF3QmpHLE1BQU0sQ0FBQ0MsQ0FBQyxDQUFDLEVBQUUsRUFBRSxPQUFPLEVBQUU7TUFBRThHLFNBQVMsRUFBRTtJQUFVLENBQUMsQ0FDckYsQ0FBQztFQUNILENBQUMsRUFDRCxDQUFDN0IsTUFBTSxFQUFFZSxLQUFLLENBQ2hCLENBQUM7RUFFRCxNQUFNb0UsTUFBTSxHQUFHLElBQUFwSSxrQkFBVyxFQUN4QixDQUFDZ0ksQ0FBVSxFQUFFSyxHQUFXLEVBQUVDLE9BQWlCLEtBQUs7SUFDOUMsTUFBTTFFLENBQUMsR0FBR29FLENBQUMsQ0FBQ0UsS0FBSyxDQUFDRyxHQUFHLENBQUM7SUFDdEIsTUFBTW5CLENBQUMsR0FBR0QsV0FBVyxDQUFDckQsQ0FBQyxDQUFDMkQsSUFBSSxDQUFDO0lBQzdCLElBQUlMLENBQUMsRUFBRW5CLEtBQUssQ0FBQ21CLENBQUMsRUFBRW9CLE9BQU8sR0FBRyxDQUFDLEdBQUcxRSxDQUFDLENBQUMyRSxRQUFRLElBQUksR0FBRyxFQUFFekYsUUFBUSxDQUFDRSxPQUFPLENBQUMzQixFQUFFLENBQUM5QyxFQUFFLEdBQUdjLGlCQUFpQixDQUFDO0lBQzVGO0lBQ0E7SUFDQTtJQUNBO0lBQ0EsSUFBSWdCLFNBQVMsQ0FBQzJDLE9BQU8sRUFBRTtNQUNyQndDLFlBQVksQ0FBQ25GLFNBQVMsQ0FBQzJDLE9BQU8sQ0FBQztNQUMvQjNDLFNBQVMsQ0FBQzJDLE9BQU8sR0FBRyxJQUFJO0lBQzFCO0lBQ0EsSUFBSVksQ0FBQyxDQUFDNEUsSUFBSSxJQUFJLENBQUMxRixRQUFRLENBQUNFLE9BQU8sQ0FBQ0wsT0FBTyxFQUFFO01BQ3ZDdEMsU0FBUyxDQUFDMkMsT0FBTyxHQUFHM0UsTUFBTSxDQUFDaUcsVUFBVSxDQUFDLE1BQU05RCxXQUFXLENBQUN3QyxPQUFPLENBQUMsQ0FBQyxFQUFFWSxDQUFDLENBQUM0RSxJQUFJLENBQUM7SUFDNUU7RUFDRixDQUFDLEVBQ0QsQ0FBQ3ZCLFdBQVcsRUFBRWxCLEtBQUssQ0FDckIsQ0FBQztFQUVELE1BQU0wQyxXQUFXLEdBQUcsSUFBQXpJLGtCQUFXLEVBQzVCK0gsR0FBVyxJQUFLO0lBQ2YsTUFBTUMsQ0FBQyxHQUFHbEYsUUFBUSxDQUFDRSxPQUFPLENBQUNyQixRQUFRLENBQUNnRSxJQUFJLENBQUUxRyxDQUFDLElBQUtBLENBQUMsQ0FBQ0osRUFBRSxLQUFLa0osR0FBRyxDQUFDO0lBQzdELElBQUksQ0FBQ0MsQ0FBQyxFQUFFO0lBQ1IsSUFBSTNILFNBQVMsQ0FBQzJDLE9BQU8sRUFBRTtNQUNyQndDLFlBQVksQ0FBQ25GLFNBQVMsQ0FBQzJDLE9BQU8sQ0FBQztNQUMvQjNDLFNBQVMsQ0FBQzJDLE9BQU8sR0FBRyxJQUFJO0lBQzFCO0lBQ0FDLE1BQU0sQ0FBQztNQUFFWCxPQUFPLEVBQUU7UUFBRXlGLEdBQUc7UUFBRU0sR0FBRyxFQUFFO01BQUUsQ0FBQztNQUFFakcsU0FBUyxFQUFFLEtBQUs7TUFBRUQsYUFBYSxFQUFFO0lBQU0sQ0FBQyxDQUFDO0lBQzVFaUcsTUFBTSxDQUFDSixDQUFDLEVBQUUsQ0FBQyxFQUFFLElBQUksQ0FBQztFQUNwQixDQUFDLEVBQ0QsQ0FBQy9FLE1BQU0sRUFBRW1GLE1BQU0sQ0FDakIsQ0FBQztFQUVELE1BQU1NLFFBQVEsR0FBRyxJQUFBMUksa0JBQVcsRUFBQyxNQUFNO0lBQ2pDLElBQUlJLFFBQVEsQ0FBQzRDLE9BQU8sRUFBRXFELG9CQUFvQixDQUFDakcsUUFBUSxDQUFDNEMsT0FBTyxDQUFDO0lBQzVELElBQUkzQyxTQUFTLENBQUMyQyxPQUFPLEVBQUU7TUFDckJ3QyxZQUFZLENBQUNuRixTQUFTLENBQUMyQyxPQUFPLENBQUM7TUFDL0IzQyxTQUFTLENBQUMyQyxPQUFPLEdBQUcsSUFBSTtJQUMxQjtJQUNBQyxNQUFNLENBQUM7TUFBRVgsT0FBTyxFQUFFO0lBQUssQ0FBQyxDQUFDO0VBQzNCLENBQUMsRUFBRSxDQUFDVyxNQUFNLENBQUMsQ0FBQztFQUVaLE1BQU0wRixRQUFRLEdBQUcsSUFBQTNJLGtCQUFXLEVBQUMsTUFBTTtJQUNqQyxNQUFNNEksRUFBRSxHQUFHOUYsUUFBUSxDQUFDRSxPQUFPLENBQUNWLE9BQU87SUFDbkMsSUFBSSxDQUFDc0csRUFBRSxFQUFFO0lBQ1QsSUFBSXZJLFNBQVMsQ0FBQzJDLE9BQU8sRUFBRTtNQUNyQndDLFlBQVksQ0FBQ25GLFNBQVMsQ0FBQzJDLE9BQU8sQ0FBQztNQUMvQjNDLFNBQVMsQ0FBQzJDLE9BQU8sR0FBRyxJQUFJO0lBQzFCO0lBQ0EsTUFBTWdGLENBQUMsR0FBR2xGLFFBQVEsQ0FBQ0UsT0FBTyxDQUFDckIsUUFBUSxDQUFDZ0UsSUFBSSxDQUFFMUcsQ0FBQyxJQUFLQSxDQUFDLENBQUNKLEVBQUUsS0FBSytKLEVBQUUsQ0FBQ2IsR0FBRyxDQUFDO0lBQ2hFLElBQUksQ0FBQ0MsQ0FBQyxFQUFFO0lBQ1IsTUFBTWEsRUFBRSxHQUFHRCxFQUFFLENBQUNQLEdBQUcsR0FBRyxDQUFDO0lBQ3JCLElBQUlRLEVBQUUsSUFBSWIsQ0FBQyxDQUFDRSxLQUFLLENBQUNWLE1BQU0sRUFBRTtNQUN4QmtCLFFBQVEsQ0FBQyxDQUFDO01BQ1Y7SUFDRjtJQUNBekYsTUFBTSxDQUFDO01BQUVYLE9BQU8sRUFBRTtRQUFFLEdBQUdzRyxFQUFFO1FBQUVQLEdBQUcsRUFBRVE7TUFBRztJQUFFLENBQUMsQ0FBQztJQUN2Q1QsTUFBTSxDQUFDSixDQUFDLEVBQUVhLEVBQUUsQ0FBQztFQUNmLENBQUMsRUFBRSxDQUFDNUYsTUFBTSxFQUFFbUYsTUFBTSxFQUFFTSxRQUFRLENBQUMsQ0FBQztFQUM5QjtFQUNBbEksV0FBVyxDQUFDd0MsT0FBTyxHQUFHMkYsUUFBUTtFQUU5QixNQUFNRyxRQUFRLEdBQUcsSUFBQTlJLGtCQUFXLEVBQUMsTUFBTTtJQUNqQyxNQUFNNEksRUFBRSxHQUFHOUYsUUFBUSxDQUFDRSxPQUFPLENBQUNWLE9BQU87SUFDbkMsSUFBSSxDQUFDc0csRUFBRSxFQUFFO0lBQ1QsSUFBSXZJLFNBQVMsQ0FBQzJDLE9BQU8sRUFBRTtNQUNyQndDLFlBQVksQ0FBQ25GLFNBQVMsQ0FBQzJDLE9BQU8sQ0FBQztNQUMvQjNDLFNBQVMsQ0FBQzJDLE9BQU8sR0FBRyxJQUFJO0lBQzFCO0lBQ0EsTUFBTWdGLENBQUMsR0FBR2xGLFFBQVEsQ0FBQ0UsT0FBTyxDQUFDckIsUUFBUSxDQUFDZ0UsSUFBSSxDQUFFMUcsQ0FBQyxJQUFLQSxDQUFDLENBQUNKLEVBQUUsS0FBSytKLEVBQUUsQ0FBQ2IsR0FBRyxDQUFDO0lBQ2hFLElBQUksQ0FBQ0MsQ0FBQyxFQUFFO0lBQ1IsTUFBTWEsRUFBRSxHQUFHakMsSUFBSSxDQUFDbUMsR0FBRyxDQUFDLENBQUMsRUFBRUgsRUFBRSxDQUFDUCxHQUFHLEdBQUcsQ0FBQyxDQUFDO0lBQ2xDcEYsTUFBTSxDQUFDO01BQUVYLE9BQU8sRUFBRTtRQUFFLEdBQUdzRyxFQUFFO1FBQUVQLEdBQUcsRUFBRVE7TUFBRztJQUFFLENBQUMsQ0FBQztJQUN2Q1QsTUFBTSxDQUFDSixDQUFDLEVBQUVhLEVBQUUsQ0FBQztFQUNmLENBQUMsRUFBRSxDQUFDNUYsTUFBTSxFQUFFbUYsTUFBTSxDQUFDLENBQUM7RUFFcEIsTUFBTVksUUFBUSxHQUFHLElBQUFoSixrQkFBVyxFQUN6QnFJLEdBQVcsSUFBSztJQUNmLE1BQU1PLEVBQUUsR0FBRzlGLFFBQVEsQ0FBQ0UsT0FBTyxDQUFDVixPQUFPO0lBQ25DLElBQUksQ0FBQ3NHLEVBQUUsRUFBRTtJQUNULElBQUl2SSxTQUFTLENBQUMyQyxPQUFPLEVBQUU7TUFDckJ3QyxZQUFZLENBQUNuRixTQUFTLENBQUMyQyxPQUFPLENBQUM7TUFDL0IzQyxTQUFTLENBQUMyQyxPQUFPLEdBQUcsSUFBSTtJQUMxQjtJQUNBLE1BQU1nRixDQUFDLEdBQUdsRixRQUFRLENBQUNFLE9BQU8sQ0FBQ3JCLFFBQVEsQ0FBQ2dFLElBQUksQ0FBRTFHLENBQUMsSUFBS0EsQ0FBQyxDQUFDSixFQUFFLEtBQUsrSixFQUFFLENBQUNiLEdBQUcsQ0FBQztJQUNoRSxJQUFJLENBQUNDLENBQUMsRUFBRTtJQUNSL0UsTUFBTSxDQUFDO01BQUVYLE9BQU8sRUFBRTtRQUFFLEdBQUdzRyxFQUFFO1FBQUVQO01BQUk7SUFBRSxDQUFDLENBQUM7SUFDbkNELE1BQU0sQ0FBQ0osQ0FBQyxFQUFFSyxHQUFHLENBQUM7RUFDaEIsQ0FBQyxFQUNELENBQUNwRixNQUFNLEVBQUVtRixNQUFNLENBQ2pCLENBQUM7O0VBRUQ7RUFDQSxNQUFNYSxRQUFRLEdBQUcsSUFBQWpKLGtCQUFXLEVBQ3pCa0QsS0FBdUIsSUFBSztJQUMzQkQsTUFBTSxDQUFFVyxDQUFDLEtBQU07TUFBRXRDLE9BQU8sRUFBRXNDLENBQUMsQ0FBQ3RDLE9BQU8sQ0FBQzJELEdBQUcsQ0FBRUMsQ0FBQyxJQUFNdEIsQ0FBQyxDQUFDL0IsU0FBUyxDQUFDOUMsUUFBUSxDQUFDbUcsQ0FBQyxDQUFDckcsRUFBRSxDQUFDLEdBQUc7UUFBRSxHQUFHcUcsQ0FBQztRQUFFLEdBQUdoQztNQUFNLENBQUMsR0FBR2dDLENBQUU7SUFBRSxDQUFDLENBQUMsQ0FBQztJQUN6R0csWUFBWSxDQUFDdkMsUUFBUSxDQUFDRSxPQUFPLENBQUNuQixTQUFTLENBQUM7RUFDMUMsQ0FBQyxFQUNELENBQUNvQixNQUFNLEVBQUVvQyxZQUFZLENBQ3ZCLENBQUM7O0VBRUQ7RUFDQSxNQUFNNkQsTUFBTSxHQUFHLElBQUFsSixrQkFBVyxFQUN4QixDQUFDbkIsRUFBVSxFQUFFQyxRQUFRLEdBQUcsS0FBSyxLQUFLO0lBQ2hDbUUsTUFBTSxDQUFFVyxDQUFDLEtBQU07TUFDYi9CLFNBQVMsRUFBRWxELGNBQWMsQ0FBQ2lGLENBQUMsQ0FBQy9CLFNBQVMsRUFBRWhELEVBQUUsRUFBRUMsUUFBUSxDQUFDO01BQ3BEcUQsYUFBYSxFQUFFLElBQUk7TUFDbkJFLFNBQVMsRUFBRTtJQUNiLENBQUMsQ0FBQyxDQUFDO0VBQ0wsQ0FBQyxFQUNELENBQUNZLE1BQU0sQ0FDVCxDQUFDOztFQUVEO0VBQ0EsTUFBTWtHLGNBQWMsR0FBRyxJQUFBbkosa0JBQVcsRUFBQyxNQUFNaUQsTUFBTSxDQUFDO0lBQUVaLFNBQVMsRUFBRTtFQUFLLENBQUMsQ0FBQyxFQUFFLENBQUNZLE1BQU0sQ0FBQyxDQUFDO0VBRS9FLE1BQU1tRyxlQUFlLEdBQUcsSUFBQXBKLGtCQUFXLEVBQUMsTUFBTTtJQUN4QyxNQUFNcEIsR0FBRyxHQUFHa0UsUUFBUSxDQUFDRSxPQUFPLENBQUNuQixTQUFTLENBQUNILEtBQUssQ0FBQyxDQUFDO0lBQzlDLElBQUksQ0FBQzlDLEdBQUcsQ0FBQzRJLE1BQU0sRUFBRTtJQUNqQixNQUFNNkIsT0FBTyxHQUFHdkcsUUFBUSxDQUFDRSxPQUFPLENBQUMxQixPQUFPLENBQUN0QyxNQUFNLENBQUVrRyxDQUFDLElBQUt0RyxHQUFHLENBQUNHLFFBQVEsQ0FBQ21HLENBQUMsQ0FBQ3JHLEVBQUUsQ0FBQyxDQUFDO0lBQzFFb0UsTUFBTSxDQUFFVyxDQUFDLEtBQU07TUFBRXRDLE9BQU8sRUFBRXNDLENBQUMsQ0FBQ3RDLE9BQU8sQ0FBQ3RDLE1BQU0sQ0FBRWtHLENBQUMsSUFBSyxDQUFDdEcsR0FBRyxDQUFDRyxRQUFRLENBQUNtRyxDQUFDLENBQUNyRyxFQUFFLENBQUMsQ0FBQztNQUFFZ0QsU0FBUyxFQUFFO0lBQUcsQ0FBQyxDQUFDLENBQUM7SUFDekY7SUFDQSxNQUFNa0MsQ0FBQyxHQUFHUSxRQUFRLENBQUN2QixPQUFPO0lBQzFCLElBQUllLENBQUMsSUFBSUEsQ0FBQyxDQUFDcEQsSUFBSSxLQUFLLElBQUksRUFBRTtNQUN4Qm9FLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDcEcsR0FBRyxDQUFDcUcsR0FBRyxDQUFFcEcsRUFBRSxJQUFLLElBQUF5Syx1QkFBVyxFQUFDdkYsQ0FBQyxFQUFFbEYsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDK0csS0FBSyxDQUFFNUgsQ0FBQyxJQUN2RGdHLEtBQUssQ0FBQyxnQkFBZ0JqRyxNQUFNLENBQUNDLENBQUMsQ0FBQyxFQUFFLEVBQUUsT0FBTyxFQUFFO1FBQUU4RyxTQUFTLEVBQUU7TUFBVSxDQUFDLENBQ3RFLENBQUM7SUFDSDtJQUNBZCxLQUFLLENBQUMsR0FBR3BGLEdBQUcsQ0FBQzRJLE1BQU0sR0FBRyxDQUFDLEdBQUcsR0FBRzVJLEdBQUcsQ0FBQzRJLE1BQU0sVUFBVSxHQUFHLFFBQVEsa0JBQWtCLEVBQUUsT0FBTyxFQUFFO01BQ3ZGbkQsV0FBVyxFQUFFLE1BQU07TUFDbkJrRixRQUFRLEVBQUVBLENBQUEsS0FBTTtRQUNkdEcsTUFBTSxDQUFFVyxDQUFDLEtBQU07VUFBRXRDLE9BQU8sRUFBRXNDLENBQUMsQ0FBQ3RDLE9BQU8sQ0FBQ3BDLE1BQU0sQ0FBQ21LLE9BQU87UUFBRSxDQUFDLENBQUMsQ0FBQztRQUN2RCxJQUFJdEYsQ0FBQyxJQUFJQSxDQUFDLENBQUNwRCxJQUFJLEtBQUssSUFBSSxFQUFFO1VBQ3hCb0UsT0FBTyxDQUFDQyxHQUFHLENBQUNxRSxPQUFPLENBQUNwRSxHQUFHLENBQUVDLENBQUMsSUFBSyxJQUFBc0UseUJBQWEsRUFBQ3pGLENBQUMsRUFBRW1CLENBQUMsQ0FBQ3JHLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQytHLEtBQUssQ0FBQyxNQUFNQyxTQUFTLENBQUM7UUFDaEY7TUFDRjtJQUNGLENBQUMsQ0FBQztFQUNKLENBQUMsRUFBRSxDQUFDNUMsTUFBTSxFQUFFZSxLQUFLLENBQUMsQ0FBQztFQUVuQixNQUFNeUYsWUFBWSxHQUFHLElBQUF6SixrQkFBVyxFQUM5QixDQUFDMEosSUFBZ0IsRUFBRUMsRUFBVSxFQUFFQyxFQUFVLEtBQUs7SUFDNUMsTUFBTTFFLENBQVUsR0FBRztNQUNqQnJHLEVBQUUsRUFBRSxJQUFBZ0wsZUFBVSxFQUFDSCxJQUFJLEtBQUssTUFBTSxHQUFHLE1BQU0sR0FBR0EsSUFBSSxDQUFDO01BQy9DQSxJQUFJO01BQ0p6SyxDQUFDLEVBQUUwSyxFQUFFLEdBQUcsR0FBRztNQUNYRyxDQUFDLEVBQUVGLEVBQUUsR0FBRyxFQUFFO01BQ1Z4QyxDQUFDLEVBQUUsR0FBRztNQUNOQyxDQUFDLEVBQUUsR0FBRztNQUNOMEMsR0FBRyxFQUFFLENBQUM7TUFDTkMsS0FBSyxFQUFFLENBQUM7TUFDUkMsQ0FBQyxFQUFFLENBQUM7TUFDSkMsV0FBVyxFQUFFO0lBQ2YsQ0FBQztJQUNELElBQUlSLElBQUksS0FBSyxNQUFNLEVBQUU7TUFDbkJ4RSxDQUFDLENBQUNpRixLQUFLLEdBQUcsT0FBTztNQUNqQmpGLENBQUMsQ0FBQ2xFLEtBQUssR0FBRyxVQUFVO0lBQ3RCLENBQUMsTUFBTSxJQUFJMEksSUFBSSxLQUFLLE9BQU8sRUFBRTtNQUMzQnhFLENBQUMsQ0FBQ2xFLEtBQUssR0FBRyxPQUFPO01BQ2pCa0UsQ0FBQyxDQUFDa0YsSUFBSSxHQUFHLGFBQWE7TUFDdEJsRixDQUFDLENBQUNrQyxDQUFDLEdBQUcsR0FBRztNQUNUbEMsQ0FBQyxDQUFDbUMsQ0FBQyxHQUFHLEdBQUc7SUFDWCxDQUFDLE1BQU0sSUFBSXFDLElBQUksS0FBSyxPQUFPLEVBQUU7TUFDM0J4RSxDQUFDLENBQUNsRSxLQUFLLEdBQUcsT0FBTztNQUNqQmtFLENBQUMsQ0FBQ2tDLENBQUMsR0FBRyxHQUFHO01BQ1RsQyxDQUFDLENBQUNtQyxDQUFDLEdBQUcsRUFBRTtNQUNSbkMsQ0FBQyxDQUFDK0UsQ0FBQyxHQUFHLENBQUM7SUFDVCxDQUFDLE1BQU0sSUFBSVAsSUFBSSxLQUFLLE9BQU8sRUFBRTtNQUMzQnhFLENBQUMsQ0FBQ21GLEtBQUssR0FBRyxNQUFNO01BQ2hCbkYsQ0FBQyxDQUFDbEUsS0FBSyxHQUFHLEVBQUU7TUFDWmtFLENBQUMsQ0FBQ2tDLENBQUMsR0FBRyxHQUFHO01BQ1RsQyxDQUFDLENBQUNtQyxDQUFDLEdBQUcsR0FBRztJQUNYLENBQUMsTUFBTSxJQUFJcUMsSUFBSSxLQUFLLE9BQU8sRUFBRTtNQUMzQnhFLENBQUMsQ0FBQ2xFLEtBQUssR0FBRyxPQUFPO01BQ2pCa0UsQ0FBQyxDQUFDa0MsQ0FBQyxHQUFHLEdBQUc7TUFDVGxDLENBQUMsQ0FBQ21DLENBQUMsR0FBRyxHQUFHO01BQ1RuQyxDQUFDLENBQUMrRSxDQUFDLEdBQUcsQ0FBQztJQUNULENBQUMsTUFBTSxJQUFJUCxJQUFJLEtBQUssS0FBSyxFQUFFO01BQ3pCeEUsQ0FBQyxDQUFDb0YsTUFBTSxHQUFHLEtBQUs7TUFDaEJwRixDQUFDLENBQUNsRSxLQUFLLEdBQUcsT0FBTztJQUNuQixDQUFDLE1BQU0sSUFBSTBJLElBQUksS0FBSyxXQUFXLEVBQUU7TUFDL0J4RSxDQUFDLENBQUNsRSxLQUFLLEdBQUcsY0FBYztJQUMxQjtJQUNBaUMsTUFBTSxDQUFFVyxDQUFDLEtBQU07TUFDYnRDLE9BQU8sRUFBRXNDLENBQUMsQ0FBQ3RDLE9BQU8sQ0FBQ3BDLE1BQU0sQ0FBQ2dHLENBQUMsQ0FBQztNQUM1QnJELFNBQVMsRUFBRSxDQUFDcUQsQ0FBQyxDQUFDckcsRUFBRSxDQUFDO01BQ2pCd0QsU0FBUyxFQUFFLElBQUk7TUFDZkYsYUFBYSxFQUFFLElBQUk7TUFDbkJ4QixJQUFJLEVBQUU7SUFDUixDQUFDLENBQUMsQ0FBQztJQUNIK0QsVUFBVSxDQUFDLENBQUNRLENBQUMsQ0FBQyxFQUFFLG1CQUFtQkEsQ0FBQyxDQUFDckcsRUFBRSxNQUFNLEVBQUUsTUFBTSxDQUFDO0VBQ3hELENBQUMsRUFDRCxDQUFDb0UsTUFBTSxFQUFFeUIsVUFBVSxDQUNyQixDQUFDOztFQUVEO0VBQ0E7RUFDQTtFQUNBOztFQUVBO0FBQ0Y7QUFDQTtFQUNFLE1BQU02RixXQUFXLEdBQUcsSUFBQXZLLGtCQUFXLEVBQzdCLE9BQU8ySixFQUFVLEVBQUVDLEVBQVUsS0FBSztJQUNoQyxNQUFNNUQsTUFBTSxHQUFHekIsUUFBUSxDQUFDdkIsT0FBTztJQUMvQixJQUFJLENBQUNnRCxNQUFNLEVBQUU7TUFDWGhDLEtBQUssQ0FBQywyQ0FBMkMsRUFBRSxNQUFNLEVBQUU7UUFBRWMsU0FBUyxFQUFFO01BQWUsQ0FBQyxDQUFDO01BQ3pGO0lBQ0Y7SUFDQTdCLE1BQU0sQ0FBQztNQUFFTCxJQUFJLEVBQUU7SUFBZSxDQUFDLENBQUM7SUFDaEMsSUFBSTtNQUNGLE1BQU00SCxHQUFHLEdBQUcsTUFBTSxJQUFBQyxrQkFBUSxFQUFDO1FBQ3pCOUosSUFBSSxFQUFFLFdBQVc7UUFDakIrSixLQUFLLEVBQUUsQ0FBQyxNQUFNLElBQUFDLHdCQUFjLEVBQUMzRSxNQUFNLENBQUMsQ0FBQztRQUNyQzRFLFVBQVUsRUFBRSxDQUFDLG9CQUFvQixDQUFDO1FBQ2xDQyxTQUFTLEVBQUUsQ0FBQzdFLE1BQU0sQ0FBQ3JGLElBQUksQ0FBQztRQUN4QkssS0FBSyxFQUFFLGNBQWM7UUFDckI4SixPQUFPLEVBQUUsQ0FDUDtVQUFFQyxLQUFLLEVBQUUsUUFBUTtVQUFFQyxVQUFVLEVBQUUsQ0FBQyxNQUFNLEVBQUUsTUFBTSxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxPQUFPO1FBQUUsQ0FBQyxFQUM1RjtVQUFFRCxLQUFLLEVBQUUsV0FBVztVQUFFQyxVQUFVLEVBQUU7UUFBRyxDQUFDO01BRTFDLENBQUMsQ0FBQztNQUNGLElBQUksQ0FBQ1IsR0FBRyxFQUFFLE9BQU8sQ0FBQztNQUNsQixNQUFNM00sR0FBRyxHQUFHLElBQUFvTixpQkFBTyxFQUFDVCxHQUFHLENBQUNVLE9BQU8sQ0FBQztNQUNoQyxJQUFJLENBQUNyTixHQUFHLEVBQUU7UUFDUm1HLEtBQUssQ0FBQyw4QkFBOEIsRUFBRSxPQUFPLEVBQUU7VUFBRWMsU0FBUyxFQUFFO1FBQVUsQ0FBQyxDQUFDO1FBQ3hFO01BQ0Y7TUFDQSxNQUFNcUMsSUFBSSxHQUFHLE1BQU0sSUFBQWdFLDBCQUFjLEVBQUNuRixNQUFNLEVBQUVuSSxHQUFHLENBQUM7TUFDOUMsTUFBTXFILENBQVUsR0FBRztRQUNqQnJHLEVBQUUsRUFBRSxJQUFBZ0wsZUFBVSxFQUFDLEtBQUssQ0FBQztRQUNyQkgsSUFBSSxFQUFFLEtBQUs7UUFDWHpLLENBQUMsRUFBRTBLLEVBQUUsR0FBRyxHQUFHO1FBQ1hHLENBQUMsRUFBRUYsRUFBRSxHQUFHLEVBQUU7UUFDVnhDLENBQUMsRUFBRSxHQUFHO1FBQ05DLENBQUMsRUFBRSxHQUFHO1FBQ04wQyxHQUFHLEVBQUUsQ0FBQztRQUNOQyxLQUFLLEVBQUUsQ0FBQztRQUNSQyxDQUFDLEVBQUUsQ0FBQztRQUNKakosS0FBSyxFQUFFbUcsSUFBSTtRQUNYaUQsSUFBSSxFQUFFLG9CQUFvQmpELElBQUksTUFBTTtRQUNwQ21ELE1BQU0sRUFBRSxJQUFJO1FBQ1pKLFdBQVcsRUFBRTtNQUNmLENBQUM7TUFDRGpILE1BQU0sQ0FBRVcsQ0FBQyxLQUFNO1FBQ2J0QyxPQUFPLEVBQUVzQyxDQUFDLENBQUN0QyxPQUFPLENBQUNwQyxNQUFNLENBQUNnRyxDQUFDLENBQUM7UUFDNUJyRCxTQUFTLEVBQUUsQ0FBQ3FELENBQUMsQ0FBQ3JHLEVBQUUsQ0FBQztRQUNqQndELFNBQVMsRUFBRSxJQUFJO1FBQ2ZGLGFBQWEsRUFBRSxJQUFJO1FBQ25CeEIsSUFBSSxFQUFFLE1BQU07UUFDWjZCLE1BQU0sRUFBRTtNQUNWLENBQUMsQ0FBQyxDQUFDO01BQ0hrQyxVQUFVLENBQUMsQ0FBQ1EsQ0FBQyxDQUFDLEVBQUUsbUJBQW1CaUMsSUFBSSxFQUFFLEVBQUUsT0FBTyxDQUFDO0lBQ3JELENBQUMsQ0FBQyxPQUFPbkosQ0FBQyxFQUFFO01BQ1ZnRyxLQUFLLENBQUMsd0JBQXdCakcsTUFBTSxDQUFDQyxDQUFDLENBQUMsRUFBRSxFQUFFLE9BQU8sRUFBRTtRQUFFOEcsU0FBUyxFQUFFO01BQVUsQ0FBQyxDQUFDO0lBQy9FLENBQUMsU0FBUztNQUNSN0IsTUFBTSxDQUFDO1FBQUVMLElBQUksRUFBRTtNQUFLLENBQUMsQ0FBQztJQUN4QjtFQUNGLENBQUMsRUFDRCxDQUFDb0IsS0FBSyxFQUFFZixNQUFNLEVBQUV5QixVQUFVLENBQzVCLENBQUM7O0VBRUQ7RUFDQSxNQUFNMEcsYUFBYSxHQUFHLElBQUFwTCxrQkFBVyxFQUMvQixNQUFPZ0csTUFBbUIsSUFBSztJQUM3QixNQUFNcUYsS0FBSyxHQUFHLE1BQU0sSUFBQUMscUJBQVMsRUFBQ3RGLE1BQU0sQ0FBQztJQUNyQ3pCLFFBQVEsQ0FBQ3ZCLE9BQU8sR0FBR2dELE1BQU07SUFDekI7SUFDQTtJQUNBO0lBQ0E7SUFDQSxNQUFNdUYsUUFBUSxHQUFHdkYsTUFBTSxDQUFDckYsSUFBSSxLQUFLLElBQUksSUFBSyxPQUFPMEssS0FBSyxDQUFDRyxNQUFNLEtBQUssUUFBUSxJQUFJSCxLQUFLLENBQUNHLE1BQU0sR0FBR3BNLGdCQUFpQjtJQUM5RzZELE1BQU0sQ0FBQztNQUNMM0IsT0FBTyxFQUFFK0osS0FBSyxDQUFDL0osT0FBTztNQUN0QkUsS0FBSyxFQUFFNkosS0FBSyxDQUFDN0osS0FBSyxDQUFDZ0csTUFBTSxHQUFHNkQsS0FBSyxDQUFDN0osS0FBSyxHQUFHQyxxQkFBVSxDQUFDQyxLQUFLLENBQUMsQ0FBQztNQUM1REMsUUFBUSxFQUFFMEosS0FBSyxDQUFDMUosUUFBUSxDQUFDNkYsTUFBTSxHQUFHNkQsS0FBSyxDQUFDMUosUUFBUSxHQUFHQyx3QkFBYTtNQUNoRWYsRUFBRSxFQUFFd0ssS0FBSyxDQUFDdEssVUFBVSxJQUFJK0IsUUFBUSxDQUFDRSxPQUFPLENBQUNuQyxFQUFFO01BQzNDRyxLQUFLLEVBQUVxSyxLQUFLLENBQUNySyxLQUFLLElBQUk4QixRQUFRLENBQUNFLE9BQU8sQ0FBQ2hDLEtBQUs7TUFDNUNMLElBQUksRUFBRTRLLFFBQVEsR0FBRyxLQUFLLEdBQUd6SSxRQUFRLENBQUNFLE9BQU8sQ0FBQ3JDLElBQUk7TUFDOUNrQixTQUFTLEVBQUUsRUFBRTtNQUNiO01BQ0E7TUFDQTtNQUNBSSxXQUFXLEVBQUUsSUFBSTtNQUNqQkMsYUFBYSxFQUFFLElBQUk7TUFDbkJDLGFBQWEsRUFBRSxLQUFLO01BQ3BCSyxNQUFNLEVBQUU7SUFDVixDQUFDLENBQUM7RUFDSixDQUFDLEVBQ0QsQ0FBQ1MsTUFBTSxDQUNULENBQUM7O0VBRUQ7QUFDRjtFQUNFLE1BQU13SSxXQUFXLEdBQUcsSUFBQXpMLGtCQUFXLEVBQzdCLE1BQU8wTCxLQUFrQixJQUFLO0lBQzVCekksTUFBTSxDQUFDO01BQUVMLElBQUksRUFBRTtJQUFhLENBQUMsQ0FBQztJQUM5QixJQUFJO01BQ0YsTUFBTTRILEdBQUcsR0FBRyxNQUFNLElBQUFDLGtCQUFRLEVBQUM7UUFDekI5SixJQUFJLEVBQUUsYUFBYTtRQUNuQitKLEtBQUssRUFBRSxDQUFDLE1BQU0sSUFBQUMsd0JBQWMsRUFBQ2UsS0FBSyxDQUFDLENBQUM7UUFDcENkLFVBQVUsRUFBRSxDQUFDLGtCQUFrQixDQUFDO1FBQ2hDQyxTQUFTLEVBQUUsQ0FBQ2EsS0FBSyxDQUFDL0ssSUFBSSxDQUFDO1FBQ3ZCSyxLQUFLLEVBQUU7TUFDVCxDQUFDLENBQUM7TUFDRixJQUFJLENBQUN3SixHQUFHLEVBQUU7TUFDVixNQUFNM00sR0FBRyxHQUFHLElBQUFvTixpQkFBTyxFQUFDVCxHQUFHLENBQUNVLE9BQU8sQ0FBQztNQUNoQyxJQUFJLENBQUNyTixHQUFHLEVBQUU7UUFDUm1HLEtBQUssQ0FBQyw4QkFBOEIsRUFBRSxPQUFPLEVBQUU7VUFBRWMsU0FBUyxFQUFFO1FBQVUsQ0FBQyxDQUFDO1FBQ3hFO01BQ0Y7TUFDQSxNQUFNNkcsU0FBc0IsR0FBRztRQUFFL04sSUFBSSxFQUFFRCxPQUFPLENBQUMrTixLQUFLLENBQUM5TixJQUFJLEVBQUVDLEdBQUcsQ0FBQztRQUFFOEMsSUFBSSxFQUFFK0ssS0FBSyxDQUFDL0ssSUFBSTtRQUFFaUwsT0FBTyxFQUFFRixLQUFLLENBQUNFO01BQVEsQ0FBQztNQUMzRyxJQUFJLEVBQUUsTUFBTSxJQUFBQyx5QkFBYSxFQUFDRixTQUFTLENBQUMsQ0FBQyxJQUFJLEVBQUUsTUFBTSxJQUFBRyx1QkFBVyxFQUFDSCxTQUFTLENBQUMsQ0FBQyxFQUFFO1FBQ3hFM0gsS0FBSyxDQUFDLDZFQUE2RSxFQUFFLE9BQU8sRUFBRTtVQUM1RmMsU0FBUyxFQUFFO1FBQ2IsQ0FBQyxDQUFDO1FBQ0Y7TUFDRjtNQUNBLE1BQU1zRyxhQUFhLENBQUNPLFNBQVMsQ0FBQztNQUM5QjNILEtBQUssQ0FBQyxlQUFlLEVBQUUsT0FBTyxDQUFDO0lBQ2pDLENBQUMsQ0FBQyxPQUFPaEcsQ0FBQyxFQUFFO01BQ1ZnRyxLQUFLLENBQUMsc0JBQXNCakcsTUFBTSxDQUFDQyxDQUFDLENBQUMsRUFBRSxFQUFFLE9BQU8sRUFBRTtRQUFFOEcsU0FBUyxFQUFFO01BQVUsQ0FBQyxDQUFDO0lBQzdFLENBQUMsU0FBUztNQUNSN0IsTUFBTSxDQUFDO1FBQUVMLElBQUksRUFBRTtNQUFLLENBQUMsQ0FBQztJQUN4QjtFQUNGLENBQUMsRUFDRCxDQUFDb0IsS0FBSyxFQUFFZixNQUFNLEVBQUVtSSxhQUFhLENBQy9CLENBQUM7O0VBRUQ7QUFDRjtBQUNBO0VBQ0UsTUFBTVcsV0FBVyxHQUFHLElBQUEvTCxrQkFBVyxFQUM3QixNQUFPZ0csTUFBbUIsSUFBSztJQUM3Qi9DLE1BQU0sQ0FBQztNQUFFTCxJQUFJLEVBQUU7SUFBYSxDQUFDLENBQUM7SUFDOUIsSUFBSTtNQUNGLE1BQU13SSxhQUFhLENBQUNwRixNQUFNLENBQUM7TUFDM0JoQyxLQUFLLENBQUMsZUFBZSxFQUFFLE9BQU8sQ0FBQztJQUNqQyxDQUFDLENBQUMsT0FBT2hHLENBQUMsRUFBRTtNQUNWZ0csS0FBSyxDQUFDLHNCQUFzQmpHLE1BQU0sQ0FBQ0MsQ0FBQyxDQUFDLEVBQUUsRUFBRSxPQUFPLEVBQUU7UUFBRThHLFNBQVMsRUFBRTtNQUFVLENBQUMsQ0FBQztJQUM3RSxDQUFDLFNBQVM7TUFDUjdCLE1BQU0sQ0FBQztRQUFFTCxJQUFJLEVBQUU7TUFBSyxDQUFDLENBQUM7SUFDeEI7RUFDRixDQUFDLEVBQ0QsQ0FBQ29CLEtBQUssRUFBRWYsTUFBTSxFQUFFbUksYUFBYSxDQUMvQixDQUFDOztFQUVEO0FBQ0Y7RUFDRSxNQUFNWSxVQUFVLEdBQUcsSUFBQWhNLGtCQUFXLEVBQzVCLE1BQU8wTCxLQUFrQixJQUFLO0lBQzVCLElBQUlBLEtBQUssQ0FBQy9LLElBQUksS0FBSyxJQUFJLEVBQUU7TUFDdkJxRCxLQUFLLENBQUMsMkRBQTJELEVBQUUsTUFBTSxFQUFFO1FBQUVjLFNBQVMsRUFBRTtNQUFlLENBQUMsQ0FBQztNQUN6RztJQUNGO0lBQ0E3QixNQUFNLENBQUM7TUFBRUwsSUFBSSxFQUFFO0lBQVksQ0FBQyxDQUFDO0lBQzdCLElBQUk7TUFDRixNQUFNNEgsR0FBRyxHQUFHLE1BQU0sSUFBQUMsa0JBQVEsRUFBQztRQUN6QjlKLElBQUksRUFBRSxhQUFhO1FBQ25CK0osS0FBSyxFQUFFLENBQUMsTUFBTSxJQUFBQyx3QkFBYyxFQUFDZSxLQUFLLENBQUMsQ0FBQztRQUNwQ2QsVUFBVSxFQUFFLENBQUMsa0JBQWtCLENBQUM7UUFDaENDLFNBQVMsRUFBRSxDQUFDYSxLQUFLLENBQUMvSyxJQUFJLENBQUM7UUFDdkJLLEtBQUssRUFBRSw2QkFBNkI7UUFDcENpTCxpQkFBaUIsRUFBRTtNQUNyQixDQUFDLENBQUM7TUFDRixJQUFJLENBQUN6QixHQUFHLEVBQUU7TUFDVixNQUFNM00sR0FBRyxHQUFHLElBQUFvTixpQkFBTyxFQUFDVCxHQUFHLENBQUNVLE9BQU8sQ0FBQztNQUNoQyxJQUFJLENBQUNyTixHQUFHLEVBQUU7UUFDUm1HLEtBQUssQ0FBQyw0QkFBNEIsRUFBRSxPQUFPLEVBQUU7VUFBRWMsU0FBUyxFQUFFO1FBQVUsQ0FBQyxDQUFDO1FBQ3RFO01BQ0Y7TUFDQSxNQUFNNkcsU0FBc0IsR0FBRztRQUFFL04sSUFBSSxFQUFFRCxPQUFPLENBQUMrTixLQUFLLENBQUM5TixJQUFJLEVBQUVDLEdBQUcsQ0FBQztRQUFFOEMsSUFBSSxFQUFFLElBQUk7UUFBRWlMLE9BQU8sRUFBRUYsS0FBSyxDQUFDRTtNQUFRLENBQUM7TUFDckcsTUFBTTVLLEtBQUssR0FBR25ELEdBQUcsQ0FBQ3FPLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQ0MsR0FBRyxDQUFDLENBQUMsSUFBSSxnQkFBZ0I7TUFDdEQsTUFBTSxJQUFBQyx5QkFBYSxFQUFDVCxTQUFTLEVBQUUzSyxLQUFLLENBQUM7TUFDckMsTUFBTW9LLGFBQWEsQ0FBQ08sU0FBUyxDQUFDO01BQzlCM0gsS0FBSyxDQUFDLGdCQUFnQixFQUFFLE9BQU8sQ0FBQztJQUNsQyxDQUFDLENBQUMsT0FBT2hHLENBQUMsRUFBRTtNQUNWZ0csS0FBSyxDQUFDLHdCQUF3QmpHLE1BQU0sQ0FBQ0MsQ0FBQyxDQUFDLEVBQUUsRUFBRSxPQUFPLEVBQUU7UUFBRThHLFNBQVMsRUFBRTtNQUFVLENBQUMsQ0FBQztJQUMvRSxDQUFDLFNBQVM7TUFDUjdCLE1BQU0sQ0FBQztRQUFFTCxJQUFJLEVBQUU7TUFBSyxDQUFDLENBQUM7SUFDeEI7RUFDRixDQUFDLEVBQ0QsQ0FBQ29CLEtBQUssRUFBRWYsTUFBTSxFQUFFbUksYUFBYSxDQUMvQixDQUFDOztFQUVEO0VBQ0EsTUFBTWlCLFNBQVMsR0FBRyxJQUFBck0sa0JBQVcsRUFBQyxNQUFNO0lBQ2xDLE1BQU0wTCxLQUFLLEdBQUduSCxRQUFRLENBQUN2QixPQUFPO0lBQzlCLElBQUksQ0FBQzBJLEtBQUssRUFBRTtNQUNWMUgsS0FBSyxDQUFDLDBDQUEwQyxFQUFFLE1BQU0sRUFBRTtRQUFFYyxTQUFTLEVBQUU7TUFBZSxDQUFDLENBQUM7TUFDeEY7SUFDRjtJQUNBLEtBQUsyRyxXQUFXLENBQUNDLEtBQUssQ0FBQztFQUN6QixDQUFDLEVBQUUsQ0FBQzFILEtBQUssRUFBRXlILFdBQVcsQ0FBQyxDQUFDO0VBRXhCLE1BQU1hLFFBQVEsR0FBRyxJQUFBdE0sa0JBQVcsRUFBQyxNQUFNO0lBQ2pDLE1BQU0wTCxLQUFLLEdBQUduSCxRQUFRLENBQUN2QixPQUFPO0lBQzlCLElBQUksQ0FBQzBJLEtBQUssRUFBRTtNQUNWMUgsS0FBSyxDQUFDLDBDQUEwQyxFQUFFLE1BQU0sRUFBRTtRQUFFYyxTQUFTLEVBQUU7TUFBZSxDQUFDLENBQUM7TUFDeEY7SUFDRjtJQUNBLEtBQUtrSCxVQUFVLENBQUNOLEtBQUssQ0FBQztFQUN4QixDQUFDLEVBQUUsQ0FBQzFILEtBQUssRUFBRWdJLFVBQVUsQ0FBQyxDQUFDOztFQUV2QjtBQUNGO0VBQ0UsTUFBTU8sUUFBUSxHQUFHLElBQUF2TSxrQkFBVyxFQUFDLFlBQVk7SUFDdkMsSUFBSTtNQUNGLE1BQU13TSxPQUFPLEdBQUcsTUFBTSxJQUFBQyxzQkFBWSxFQUFDLENBQUM7TUFDcEMsSUFBSSxDQUFDRCxPQUFPLEVBQUUsT0FBTyxDQUFDO01BQ3RCLE1BQU1kLEtBQWtCLEdBQUc7UUFBRTlOLElBQUksRUFBRTRPLE9BQU8sQ0FBQ0UsSUFBSTtRQUFFL0wsSUFBSSxFQUFFNkwsT0FBTyxDQUFDN0wsSUFBSTtRQUFFaUwsT0FBTyxFQUFFWSxPQUFPLENBQUMzTjtNQUFHLENBQUM7TUFDMUYsTUFBTTRNLFdBQVcsQ0FBQ0MsS0FBSyxDQUFDO0lBQzFCLENBQUMsQ0FBQyxPQUFPMU4sQ0FBQyxFQUFFO01BQ1ZnRyxLQUFLLENBQUMsdUJBQXVCakcsTUFBTSxDQUFDQyxDQUFDLENBQUMsRUFBRSxFQUFFLE9BQU8sRUFBRTtRQUFFOEcsU0FBUyxFQUFFO01BQVUsQ0FBQyxDQUFDO0lBQzlFO0VBQ0YsQ0FBQyxFQUFFLENBQUNkLEtBQUssRUFBRXlILFdBQVcsQ0FBQyxDQUFDO0VBRXhCLE1BQU1rQixXQUFXLEdBQUcsSUFBQTNNLGtCQUFXLEVBQzdCLENBQUNuQixFQUFVLEVBQUVxRSxLQUF1QixLQUFLO0lBQ3ZDRCxNQUFNLENBQUVXLENBQUMsS0FBTTtNQUFFdEMsT0FBTyxFQUFFc0MsQ0FBQyxDQUFDdEMsT0FBTyxDQUFDMkQsR0FBRyxDQUFFQyxDQUFDLElBQU1BLENBQUMsQ0FBQ3JHLEVBQUUsS0FBS0EsRUFBRSxHQUFHO1FBQUUsR0FBR3FHLENBQUM7UUFBRSxHQUFHaEM7TUFBTSxDQUFDLEdBQUdnQyxDQUFFO0lBQUUsQ0FBQyxDQUFDLENBQUM7SUFDMUZHLFlBQVksQ0FBQyxDQUFDeEcsRUFBRSxDQUFDLENBQUM7RUFDcEIsQ0FBQyxFQUNELENBQUNvRSxNQUFNLEVBQUVvQyxZQUFZLENBQ3ZCLENBQUM7RUFFRCxNQUFNdUgsYUFBYSxHQUFHLElBQUE1TSxrQkFBVyxFQUMvQixDQUFDc0csSUFBWSxFQUFFdUcsRUFBVSxLQUFLO0lBQzVCLE1BQU01TyxDQUFhLEdBQUc7TUFBRTRPLEVBQUU7TUFBRW5ELElBQUksRUFBRSxPQUFPO01BQUVvRCxLQUFLLEVBQUU7UUFBRUMsTUFBTSxFQUFFLFFBQVE7UUFBRUMsSUFBSSxFQUFFO01BQU07SUFBRSxDQUFDO0lBQ3JGLE1BQU1DLEdBQUcsR0FBR25LLFFBQVEsQ0FBQ0UsT0FBTyxDQUFDMUIsT0FBTyxDQUFDcUUsSUFBSSxDQUFFVCxDQUFDLElBQUtBLENBQUMsQ0FBQ3JHLEVBQUUsS0FBS3lILElBQUksQ0FBQztJQUMvRCxNQUFNNEcsT0FBTyxHQUFHRCxHQUFHLEdBQUc7TUFBRSxHQUFHQSxHQUFHO01BQUUvQyxXQUFXLEVBQUUrQyxHQUFHLENBQUMvQyxXQUFXLENBQUNoTCxNQUFNLENBQUNqQixDQUFDO0lBQUUsQ0FBQyxHQUFHLElBQUk7SUFDL0VnRixNQUFNLENBQUVXLENBQUMsS0FBTTtNQUFFdEMsT0FBTyxFQUFFc0MsQ0FBQyxDQUFDdEMsT0FBTyxDQUFDMkQsR0FBRyxDQUFFQyxDQUFDLElBQU1BLENBQUMsQ0FBQ3JHLEVBQUUsS0FBS3lILElBQUksR0FBRztRQUFFLEdBQUdwQixDQUFDO1FBQUVnRixXQUFXLEVBQUVoRixDQUFDLENBQUNnRixXQUFXLENBQUNoTCxNQUFNLENBQUNqQixDQUFDO01BQUUsQ0FBQyxHQUFHaUgsQ0FBRTtJQUFFLENBQUMsQ0FBQyxDQUFDO0lBQ3hILElBQUlnSSxPQUFPLEVBQUV4SSxVQUFVLENBQUMsQ0FBQ3dJLE9BQU8sQ0FBQyxFQUFFLGFBQWE1RyxJQUFJLE1BQU11RyxFQUFFLEVBQUUsQ0FBQztFQUNqRSxDQUFDLEVBQ0QsQ0FBQzVKLE1BQU0sRUFBRXlCLFVBQVUsQ0FDckIsQ0FBQzs7RUFFRDtFQUNBO0FBQ0Y7QUFDQTtBQUNBO0VBQ0UsTUFBTXlJLFlBQVksR0FBRyxJQUFBbk4sa0JBQVcsRUFBQyxNQUFNO0lBQ3JDLE1BQU00RCxDQUFDLEdBQUdkLFFBQVEsQ0FBQ0UsT0FBTztJQUMxQixJQUFJWSxDQUFDLENBQUMvQixTQUFTLENBQUMyRixNQUFNLEtBQUssQ0FBQyxFQUFFO0lBQzlCLE1BQU1sQixJQUFJLEdBQUcxQyxDQUFDLENBQUMvQixTQUFTLENBQUMsQ0FBQyxDQUFDO0lBQzNCLE1BQU11TCxLQUFLLEdBQUd4SixDQUFDLENBQUN0QyxPQUFPLENBQUNJLEtBQUssQ0FBQyxDQUFDLENBQUMyTCxJQUFJLENBQUMsQ0FBQ0MsQ0FBQyxFQUFFQyxDQUFDLEtBQUssQ0FBQ0QsQ0FBQyxDQUFDckQsQ0FBQyxJQUFJLENBQUMsS0FBS3NELENBQUMsQ0FBQ3RELENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDaEYsR0FBRyxDQUFFQyxDQUFDLElBQUtBLENBQUMsQ0FBQ3JHLEVBQUUsQ0FBQyxDQUFDRyxNQUFNLENBQUVILEVBQUUsSUFBS0EsRUFBRSxLQUFLeUgsSUFBSSxDQUFDO0lBQ3BIckQsTUFBTSxDQUFDO01BQUVoQixXQUFXLEVBQUVxRSxJQUFJO01BQUVwRSxhQUFhLEVBQUVrTCxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSTtNQUFFakwsYUFBYSxFQUFFO0lBQU0sQ0FBQyxDQUFDO0VBQ3RGLENBQUMsRUFBRSxDQUFDYyxNQUFNLENBQUMsQ0FBQztFQUVaLE1BQU11SyxVQUFVLEdBQUcsSUFBQXhOLGtCQUFXLEVBQzNCeU4sTUFBZSxJQUFLO0lBQ25CLE1BQU03SixDQUFDLEdBQUdkLFFBQVEsQ0FBQ0UsT0FBTztJQUMxQixJQUFJLENBQUNZLENBQUMsQ0FBQzNCLFdBQVcsRUFBRTtJQUNwQixJQUFJd0wsTUFBTSxJQUFJN0osQ0FBQyxDQUFDMUIsYUFBYSxFQUFFMEssYUFBYSxDQUFDaEosQ0FBQyxDQUFDM0IsV0FBVyxFQUFFMkIsQ0FBQyxDQUFDMUIsYUFBYSxDQUFDO0lBQzVFZSxNQUFNLENBQUM7TUFBRWhCLFdBQVcsRUFBRSxJQUFJO01BQUVDLGFBQWEsRUFBRTtJQUFLLENBQUMsQ0FBQztFQUNwRCxDQUFDLEVBQ0QsQ0FBQ2UsTUFBTSxFQUFFMkosYUFBYSxDQUN4QixDQUFDO0VBRUQsTUFBTWMsaUJBQWlCLEdBQUcsSUFBQTFOLGtCQUFXLEVBQ2xDMk4sR0FBVyxJQUFLO0lBQ2YxSyxNQUFNLENBQUVXLENBQUMsSUFBSztNQUNaLElBQUksQ0FBQ0EsQ0FBQyxDQUFDM0IsV0FBVyxFQUFFLE9BQU8sQ0FBQyxDQUFDO01BQzdCLE1BQU1tTCxLQUFLLEdBQUd4SixDQUFDLENBQUN0QyxPQUFPLENBQUNJLEtBQUssQ0FBQyxDQUFDLENBQUMyTCxJQUFJLENBQUMsQ0FBQ0MsQ0FBQyxFQUFFQyxDQUFDLEtBQUssQ0FBQ0QsQ0FBQyxDQUFDckQsQ0FBQyxJQUFJLENBQUMsS0FBS3NELENBQUMsQ0FBQ3RELENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDaEYsR0FBRyxDQUFFQyxDQUFDLElBQUtBLENBQUMsQ0FBQ3JHLEVBQUUsQ0FBQyxDQUFDRyxNQUFNLENBQUVILEVBQUUsSUFBS0EsRUFBRSxLQUFLK0UsQ0FBQyxDQUFDM0IsV0FBVyxDQUFDO01BQzdILElBQUksQ0FBQ21MLEtBQUssQ0FBQzVGLE1BQU0sRUFBRSxPQUFPLENBQUMsQ0FBQztNQUM1QixNQUFNYSxHQUFHLEdBQUcrRSxLQUFLLENBQUNRLE9BQU8sQ0FBQ2hLLENBQUMsQ0FBQzFCLGFBQWEsSUFBSWtMLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztNQUN0RCxPQUFPO1FBQUVsTCxhQUFhLEVBQUVrTCxLQUFLLENBQUMsQ0FBQy9FLEdBQUcsR0FBR3NGLEdBQUcsR0FBR1AsS0FBSyxDQUFDNUYsTUFBTSxJQUFJNEYsS0FBSyxDQUFDNUYsTUFBTTtNQUFFLENBQUM7SUFDNUUsQ0FBQyxDQUFDO0VBQ0osQ0FBQyxFQUNELENBQUN2RSxNQUFNLENBQ1QsQ0FBQzs7RUFFRDtFQUNBLE1BQU00SyxZQUFZLEdBQUcsSUFBQTdOLGtCQUFXLEVBQzdCaEMsQ0FBcUIsSUFBSztJQUN6QixNQUFNNEYsQ0FBQyxHQUFHZCxRQUFRLENBQUNFLE9BQU87SUFDMUIsSUFBSVksQ0FBQyxDQUFDdkIsU0FBUyxFQUFFWSxNQUFNLENBQUM7TUFBRVosU0FBUyxFQUFFO0lBQUssQ0FBQyxDQUFDO0lBQzVDLElBQUl1QixDQUFDLENBQUNuQixZQUFZLEVBQUVRLE1BQU0sQ0FBQztNQUFFUixZQUFZLEVBQUU7SUFBTSxDQUFDLENBQUM7SUFDbkQsTUFBTXFMLEdBQUcsR0FBRzlQLENBQUMsQ0FBQytQLE1BQU0sS0FBSyxDQUFDO0lBQzFCLElBQUluSyxDQUFDLENBQUNqRCxJQUFJLEtBQUssTUFBTSxJQUFJLENBQUNMLFFBQVEsQ0FBQzBDLE9BQU8sSUFBSSxDQUFDOEssR0FBRyxJQUFJLENBQUMxSyxRQUFRLENBQUMsQ0FBQyxFQUFFO01BQ2pFLE1BQU0sQ0FBQ00sRUFBRSxFQUFFQyxFQUFFLENBQUMsR0FBR04sVUFBVSxDQUFDckYsQ0FBQyxDQUFDO01BQzlCLElBQUksQ0FBQ0EsQ0FBQyxDQUFDZ1EsUUFBUSxFQUFFL0ssTUFBTSxDQUFDO1FBQUVwQixTQUFTLEVBQUU7TUFBRyxDQUFDLENBQUM7TUFDMUMzQixPQUFPLENBQUM4QyxPQUFPLEdBQUc7UUFBRWlMLElBQUksRUFBRSxTQUFTO1FBQUVDLEVBQUUsRUFBRXhLLEVBQUU7UUFBRXlLLEVBQUUsRUFBRXhLLEVBQUU7UUFBRXlLLEdBQUcsRUFBRXBRLENBQUMsQ0FBQ2dRLFFBQVE7UUFBRUssSUFBSSxFQUFFekssQ0FBQyxDQUFDL0IsU0FBUyxDQUFDSCxLQUFLLENBQUM7TUFBRSxDQUFDO01BQ2pHdUIsTUFBTSxDQUFDO1FBQUVsQixPQUFPLEVBQUU7VUFBRTlDLENBQUMsRUFBRXlFLEVBQUU7VUFBRW9HLENBQUMsRUFBRW5HLEVBQUU7VUFBRXlELENBQUMsRUFBRSxDQUFDO1VBQUVDLENBQUMsRUFBRTtRQUFFO01BQUUsQ0FBQyxDQUFDO0lBQ25ELENBQUMsTUFBTTtNQUNMbkgsT0FBTyxDQUFDOEMsT0FBTyxHQUFHO1FBQUVpTCxJQUFJLEVBQUUsS0FBSztRQUFFQyxFQUFFLEVBQUVsUSxDQUFDLENBQUNzRixPQUFPO1FBQUU2SyxFQUFFLEVBQUVuUSxDQUFDLENBQUN1RixPQUFPO1FBQUVyQyxFQUFFLEVBQUUwQyxDQUFDLENBQUMzQyxHQUFHLENBQUNDLEVBQUU7UUFBRUMsRUFBRSxFQUFFeUMsQ0FBQyxDQUFDM0MsR0FBRyxDQUFDRTtNQUFHLENBQUM7TUFDM0Y4QixNQUFNLENBQUM7UUFBRVAsT0FBTyxFQUFFO01BQUssQ0FBQyxDQUFDO0lBQzNCO0VBQ0YsQ0FBQyxFQUNELENBQUNPLE1BQU0sRUFBRUcsUUFBUSxFQUFFQyxVQUFVLENBQy9CLENBQUM7RUFFRCxNQUFNaUwsY0FBYyxHQUFHLElBQUF0TyxrQkFBVyxFQUNoQyxDQUFDbkIsRUFBVSxFQUFFYixDQUFxQixLQUFLO0lBQ3JDQSxDQUFDLENBQUN1USxlQUFlLENBQUMsQ0FBQztJQUNuQixNQUFNM0ssQ0FBQyxHQUFHZCxRQUFRLENBQUNFLE9BQU87SUFDMUIsSUFBSVksQ0FBQyxDQUFDakQsSUFBSSxLQUFLLE1BQU0sRUFBRTtNQUNyQlQsT0FBTyxDQUFDOEMsT0FBTyxHQUFHO1FBQUVpTCxJQUFJLEVBQUUsS0FBSztRQUFFQyxFQUFFLEVBQUVsUSxDQUFDLENBQUNzRixPQUFPO1FBQUU2SyxFQUFFLEVBQUVuUSxDQUFDLENBQUN1RixPQUFPO1FBQUVyQyxFQUFFLEVBQUUwQyxDQUFDLENBQUMzQyxHQUFHLENBQUNDLEVBQUU7UUFBRUMsRUFBRSxFQUFFeUMsQ0FBQyxDQUFDM0MsR0FBRyxDQUFDRTtNQUFHLENBQUM7TUFDM0Y4QixNQUFNLENBQUM7UUFBRVAsT0FBTyxFQUFFO01BQUssQ0FBQyxDQUFDO01BQ3pCO0lBQ0Y7SUFDQSxNQUFNd0MsQ0FBQyxHQUFHdEIsQ0FBQyxDQUFDdEMsT0FBTyxDQUFDcUUsSUFBSSxDQUFFMUcsQ0FBQyxJQUFLQSxDQUFDLENBQUNKLEVBQUUsS0FBS0EsRUFBRSxDQUFDO0lBQzVDLElBQUksQ0FBQ3FHLENBQUMsRUFBRTtJQUNSO0lBQ0EsTUFBTXRHLEdBQUcsR0FBR0QsY0FBYyxDQUFDaUYsQ0FBQyxDQUFDL0IsU0FBUyxFQUFFaEQsRUFBRSxFQUFFYixDQUFDLENBQUNnUSxRQUFRLENBQUM7SUFDdkQvSyxNQUFNLENBQUM7TUFBRXBCLFNBQVMsRUFBRWpELEdBQUc7TUFBRXVELGFBQWEsRUFBRSxJQUFJO01BQUVFLFNBQVMsRUFBRTtJQUFLLENBQUMsQ0FBQztJQUNoRSxJQUFJNkMsQ0FBQyxDQUFDc0osTUFBTSxFQUFFO0lBQ2QsTUFBTUMsSUFBOEMsR0FBRyxDQUFDLENBQUM7SUFDekQ3SyxDQUFDLENBQUN0QyxPQUFPLENBQUNvTixPQUFPLENBQUV6UCxDQUFDLElBQUs7TUFDdkIsSUFBSUwsR0FBRyxDQUFDRyxRQUFRLENBQUNFLENBQUMsQ0FBQ0osRUFBRSxDQUFDLEVBQUU0UCxJQUFJLENBQUN4UCxDQUFDLENBQUNKLEVBQUUsQ0FBQyxHQUFHO1FBQUVJLENBQUMsRUFBRUEsQ0FBQyxDQUFDQSxDQUFDO1FBQUU2SyxDQUFDLEVBQUU3SyxDQUFDLENBQUM2SztNQUFFLENBQUM7SUFDekQsQ0FBQyxDQUFDO0lBQ0Y1SixPQUFPLENBQUM4QyxPQUFPLEdBQUc7TUFBRWlMLElBQUksRUFBRSxNQUFNO01BQUVDLEVBQUUsRUFBRWxRLENBQUMsQ0FBQ3NGLE9BQU87TUFBRTZLLEVBQUUsRUFBRW5RLENBQUMsQ0FBQ3VGLE9BQU87TUFBRStCLEdBQUcsRUFBRTFHLEdBQUc7TUFBRTZQLElBQUk7TUFBRUUsS0FBSyxFQUFFO0lBQU0sQ0FBQztFQUNoRyxDQUFDLEVBQ0QsQ0FBQzFMLE1BQU0sQ0FDVCxDQUFDO0VBRUQsTUFBTTJMLFdBQVcsR0FBRyxJQUFBNU8sa0JBQVcsRUFBQyxDQUFDMEosSUFBeUIsRUFBRWpFLE1BQWMsRUFBRXpILENBQXFCLEtBQUs7SUFDcEdBLENBQUMsQ0FBQ3VRLGVBQWUsQ0FBQyxDQUFDO0lBQ25CLE1BQU0zSyxDQUFDLEdBQUdkLFFBQVEsQ0FBQ0UsT0FBTztJQUMxQixNQUFNbkUsRUFBRSxHQUFHK0UsQ0FBQyxDQUFDL0IsU0FBUyxDQUFDLENBQUMsQ0FBQztJQUN6QixNQUFNcUQsQ0FBQyxHQUFHdEIsQ0FBQyxDQUFDdEMsT0FBTyxDQUFDcUUsSUFBSSxDQUFFMUcsQ0FBQyxJQUFLQSxDQUFDLENBQUNKLEVBQUUsS0FBS0EsRUFBRSxDQUFDO0lBQzVDLElBQUksQ0FBQ3FHLENBQUMsRUFBRTtJQUNSLE1BQU1tSixJQUFJLEdBQUc7TUFBRXBQLENBQUMsRUFBRWlHLENBQUMsQ0FBQ2pHLENBQUM7TUFBRTZLLENBQUMsRUFBRTVFLENBQUMsQ0FBQzRFLENBQUM7TUFBRTFDLENBQUMsRUFBRWxDLENBQUMsQ0FBQ2tDLENBQUM7TUFBRUMsQ0FBQyxFQUFFbkMsQ0FBQyxDQUFDbUMsQ0FBQztNQUFFMEMsR0FBRyxFQUFFN0UsQ0FBQyxDQUFDNkU7SUFBSSxDQUFDO0lBQzNEN0osT0FBTyxDQUFDOEMsT0FBTyxHQUNiMEcsSUFBSSxLQUFLLFFBQVEsR0FDYjtNQUFFdUUsSUFBSSxFQUFFLFFBQVE7TUFBRUMsRUFBRSxFQUFFbFEsQ0FBQyxDQUFDc0YsT0FBTztNQUFFNkssRUFBRSxFQUFFblEsQ0FBQyxDQUFDdUYsT0FBTztNQUFFMkIsQ0FBQyxFQUFFbUosSUFBSTtNQUFFeFAsRUFBRTtNQUFFOFAsS0FBSyxFQUFFO0lBQU0sQ0FBQyxHQUMzRTtNQUFFVixJQUFJLEVBQUUsUUFBUTtNQUFFdkUsSUFBSSxFQUFFakUsTUFBTTtNQUFFeUksRUFBRSxFQUFFbFEsQ0FBQyxDQUFDc0YsT0FBTztNQUFFNkssRUFBRSxFQUFFblEsQ0FBQyxDQUFDdUYsT0FBTztNQUFFMkIsQ0FBQyxFQUFFbUosSUFBSTtNQUFFeFAsRUFBRTtNQUFFOFAsS0FBSyxFQUFFO0lBQU0sQ0FBQztFQUNqRyxDQUFDLEVBQUUsRUFBRSxDQUFDO0VBRU4sTUFBTUUsWUFBWSxHQUFHLElBQUE3TyxrQkFBVyxFQUM5QixDQUFDbkIsRUFBVSxFQUFFaVEsSUFBWSxFQUFFOVEsQ0FBcUIsS0FBSztJQUNuREEsQ0FBQyxDQUFDdVEsZUFBZSxDQUFDLENBQUM7SUFDbkJyTyxPQUFPLENBQUM4QyxPQUFPLEdBQUc7TUFBRWlMLElBQUksRUFBRSxTQUFTO01BQUUzSCxJQUFJLEVBQUV6SCxFQUFFO01BQUVpUSxJQUFJO01BQUVILEtBQUssRUFBRTtJQUFNLENBQUM7SUFDbkUsTUFBTSxDQUFDakwsRUFBRSxFQUFFQyxFQUFFLENBQUMsR0FBR04sVUFBVSxDQUFDckYsQ0FBQyxDQUFDO0lBQzlCaUYsTUFBTSxDQUFDO01BQUVqQixjQUFjLEVBQUU7UUFBRXNFLElBQUksRUFBRXpILEVBQUU7UUFBRUksQ0FBQyxFQUFFeUUsRUFBRTtRQUFFb0csQ0FBQyxFQUFFbkcsRUFBRTtRQUFFcUMsTUFBTSxFQUFFO01BQUs7SUFBRSxDQUFDLENBQUM7RUFDdEUsQ0FBQyxFQUNELENBQUMvQyxNQUFNLEVBQUVJLFVBQVUsQ0FDckIsQ0FBQztFQUVELE1BQU0wTCxRQUFRLEdBQUcsSUFBQS9PLGtCQUFXLEVBQUVuQixFQUFpQixJQUFLb0UsTUFBTSxDQUFDO0lBQUVuQixLQUFLLEVBQUVqRDtFQUFHLENBQUMsQ0FBQyxFQUFFLENBQUNvRSxNQUFNLENBQUMsQ0FBQztFQUNwRixNQUFNK0wsY0FBYyxHQUFHLElBQUFoUCxrQkFBVyxFQUFDLE1BQU1pRCxNQUFNLENBQUM7SUFBRXBCLFNBQVMsRUFBRTtFQUFHLENBQUMsQ0FBQyxFQUFFLENBQUNvQixNQUFNLENBQUMsQ0FBQzs7RUFFN0U7RUFDQSxNQUFNZ00sTUFBTSxHQUFHLElBQUFqUCxrQkFBVztFQUN4QjtFQUNBO0VBQ0E7RUFDQSxNQUFNaUQsTUFBTSxDQUFDO0lBQUV0QyxJQUFJLEVBQUUsS0FBSztJQUFFa0IsU0FBUyxFQUFFLEVBQUU7SUFBRU0sYUFBYSxFQUFFLEtBQUs7SUFBRUUsU0FBUyxFQUFFLElBQUk7SUFBRUwsY0FBYyxFQUFFLElBQUk7SUFBRUMsV0FBVyxFQUFFLElBQUk7SUFBRUMsYUFBYSxFQUFFO0VBQUssQ0FBQyxDQUFDLEVBQ2pKLENBQUNlLE1BQU0sQ0FDVCxDQUFDO0VBQ0QsTUFBTWlNLE9BQU8sR0FBRyxJQUFBbFAsa0JBQVcsRUFBQyxNQUFNaUQsTUFBTSxDQUFDO0lBQUV0QyxJQUFJLEVBQUU7RUFBTyxDQUFDLENBQUMsRUFBRSxDQUFDc0MsTUFBTSxDQUFDLENBQUM7RUFDckUsTUFBTWtNLFdBQVcsR0FBRyxJQUFBblAsa0JBQVcsRUFBQyxNQUFNaUQsTUFBTSxDQUFFVyxDQUFDLEtBQU07SUFBRWhELEtBQUssRUFBRSxDQUFDZ0QsQ0FBQyxDQUFDaEQ7RUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUNxQyxNQUFNLENBQUMsQ0FBQztFQUNyRixNQUFNbU0sV0FBVyxHQUFHLElBQUFwUCxrQkFBVyxFQUFDLE1BQU1pRCxNQUFNLENBQUVXLENBQUMsS0FBTTtJQUFFeEIsU0FBUyxFQUFFLENBQUN3QixDQUFDLENBQUN4QjtFQUFVLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQ2EsTUFBTSxDQUFDLENBQUM7RUFDN0YsTUFBTW9NLFNBQVMsR0FBRyxJQUFBclAsa0JBQVcsRUFBRXdDLE1BQWtCLElBQUtTLE1BQU0sQ0FBQztJQUFFVDtFQUFPLENBQUMsQ0FBQyxFQUFFLENBQUNTLE1BQU0sQ0FBQyxDQUFDO0VBQ25GLE1BQU1xTSxhQUFhLEdBQUcsSUFBQXRQLGtCQUFXLEVBQUVhLEVBQWMsSUFBS29DLE1BQU0sQ0FBQztJQUFFcEM7RUFBRyxDQUFDLENBQUMsRUFBRSxDQUFDb0MsTUFBTSxDQUFDLENBQUM7RUFDL0UsTUFBTXNNLFFBQVEsR0FBRyxJQUFBdlAsa0JBQVcsRUFBRVksS0FBYyxJQUFLcUMsTUFBTSxDQUFDO0lBQUVyQztFQUFNLENBQUMsQ0FBQyxFQUFFLENBQUNxQyxNQUFNLENBQUMsQ0FBQztFQUM3RSxNQUFNdU0sY0FBYyxHQUFHLElBQUF4UCxrQkFBVyxFQUFDLE1BQU1pRCxNQUFNLENBQUM7SUFBRWQsYUFBYSxFQUFFO0VBQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQ2MsTUFBTSxDQUFDLENBQUM7RUFDcEYsTUFBTXdNLFVBQVUsR0FBRyxJQUFBelAsa0JBQVcsRUFBQyxNQUFNaUQsTUFBTSxDQUFDO0lBQUViLFNBQVMsRUFBRTtFQUFNLENBQUMsQ0FBQyxFQUFFLENBQUNhLE1BQU0sQ0FBQyxDQUFDO0VBQzVFLE1BQU15TSxjQUFjLEdBQUcsSUFBQTFQLGtCQUFXLEVBQUMsTUFBTWlELE1BQU0sQ0FBRVcsQ0FBQyxLQUFNO0lBQUVuQixZQUFZLEVBQUUsQ0FBQ21CLENBQUMsQ0FBQ25CO0VBQWEsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDUSxNQUFNLENBQUMsQ0FBQztFQUV0RyxNQUFNME0sZ0JBQWdCLEdBQUcsSUFBQTNQLGtCQUFXLEVBQ2pDaEMsQ0FBbUIsSUFBSztJQUN2QixJQUFJOEUsUUFBUSxDQUFDRSxPQUFPLENBQUNyQyxJQUFJLEtBQUssTUFBTSxFQUFFO0lBQ3RDLE1BQU0sQ0FBQytDLEVBQUUsRUFBRUMsRUFBRSxDQUFDLEdBQUdOLFVBQVUsQ0FBQ3JGLENBQUMsQ0FBQztJQUM5QixNQUFNLENBQUMyTCxFQUFFLEVBQUVDLEVBQUUsQ0FBQyxHQUFHLElBQUFnRyxlQUFPLEVBQUM5TSxRQUFRLENBQUNFLE9BQU8sQ0FBQy9CLEdBQUcsRUFBRTZCLFFBQVEsQ0FBQ0UsT0FBTyxDQUFDM0IsRUFBRSxFQUFFcUMsRUFBRSxFQUFFQyxFQUFFLENBQUM7SUFDM0VWLE1BQU0sQ0FBQztNQUFFWixTQUFTLEVBQUU7UUFBRXFCLEVBQUU7UUFBRUMsRUFBRTtRQUFFZ0csRUFBRTtRQUFFQztNQUFHO0lBQUUsQ0FBQyxDQUFDO0VBQzNDLENBQUMsRUFDRCxDQUFDM0csTUFBTSxFQUFFSSxVQUFVLENBQ3JCLENBQUM7O0VBRUQ7RUFDQSxNQUFNd00sT0FBTyxHQUFHLElBQUE3UCxrQkFBVyxFQUFDLE1BQU07SUFDaENnRSxLQUFLLENBQUMsa0VBQWtFLEVBQUUsT0FBTyxFQUFFO01BQ2pGYyxTQUFTLEVBQUUsU0FBUztNQUNwQlQsV0FBVyxFQUFFLFdBQVc7TUFDeEJrRixRQUFRLEVBQUVBLENBQUEsS0FBTXZGLEtBQUssQ0FBQyx1QkFBdUIsRUFBRSxPQUFPO0lBQ3hELENBQUMsQ0FBQztFQUNKLENBQUMsRUFBRSxDQUFDQSxLQUFLLENBQUMsQ0FBQztFQUVYLE1BQU04TCxhQUFhLEdBQUcsSUFBQTlQLGtCQUFXLEVBQUMsTUFBTTtJQUN0Q2lELE1BQU0sQ0FBQztNQUFFdEMsSUFBSSxFQUFFLEtBQUs7TUFBRWtCLFNBQVMsRUFBRSxFQUFFO01BQUVNLGFBQWEsRUFBRTtJQUFNLENBQUMsQ0FBQztJQUM1RDZCLEtBQUssQ0FBQyxxREFBcUQsRUFBRSxNQUFNLEVBQUU7TUFBRWMsU0FBUyxFQUFFO0lBQWUsQ0FBQyxDQUFDO0VBQ3JHLENBQUMsRUFBRSxDQUFDN0IsTUFBTSxFQUFFZSxLQUFLLENBQUMsQ0FBQzs7RUFFbkI7RUFDQSxJQUFBakIsZ0JBQVMsRUFBQyxNQUFNO0lBQ2RnTixRQUFRLENBQUNDLGVBQWUsQ0FBQ0MsWUFBWSxDQUFDLFlBQVksRUFBRXhQLEtBQUssQ0FBQ0csS0FBSyxHQUFHLE9BQU8sR0FBRyxNQUFNLENBQUM7RUFDckYsQ0FBQyxFQUFFLENBQUNILEtBQUssQ0FBQ0csS0FBSyxDQUFDLENBQUM7RUFFakIsSUFBQW1DLGdCQUFTLEVBQUMsTUFBTTtJQUNkLE1BQU05QyxFQUFFLEdBQUdMLFFBQVE7SUFDbkIsSUFBSSxDQUFDSyxFQUFFLEVBQUU7SUFFVCxNQUFNaVEsT0FBTyxHQUFHQSxDQUFBLEtBQU07TUFDcEIsTUFBTUMsQ0FBQyxHQUFHbFEsRUFBRSxDQUFDbVEscUJBQXFCLENBQUMsQ0FBQztNQUNwQ25OLE1BQU0sQ0FBQztRQUFFNUIsRUFBRSxFQUFFO1VBQUVqRCxFQUFFLEVBQUUrUixDQUFDLENBQUNFLEtBQUs7VUFBRTlSLEVBQUUsRUFBRTRSLENBQUMsQ0FBQ0csTUFBTTtVQUFFN1IsS0FBSyxFQUFFMFIsQ0FBQyxDQUFDSSxJQUFJO1VBQUU3UixJQUFJLEVBQUV5UixDQUFDLENBQUNLO1FBQUk7TUFBRSxDQUFDLENBQUM7SUFDM0UsQ0FBQztJQUNETixPQUFPLENBQUMsQ0FBQztJQUNULE1BQU1PLEVBQUUsR0FBRyxJQUFJQyxjQUFjLENBQUNSLE9BQU8sQ0FBQztJQUN0Q08sRUFBRSxDQUFDRSxPQUFPLENBQUMxUSxFQUFFLENBQUM7SUFFZCxNQUFNMlEsT0FBTyxHQUFJNVMsQ0FBYSxJQUFLO01BQ2pDQSxDQUFDLENBQUM2UyxjQUFjLENBQUMsQ0FBQztNQUNsQixNQUFNLENBQUNuTixFQUFFLEVBQUVDLEVBQUUsQ0FBQyxHQUFHTixVQUFVLENBQUNyRixDQUFDLENBQUM7TUFDOUIsSUFBSUEsQ0FBQyxDQUFDOFMsT0FBTyxJQUFJOVMsQ0FBQyxDQUFDK1MsT0FBTyxFQUFFO1FBQzFCLE1BQU1DLENBQUMsR0FBR3BLLElBQUksQ0FBQ3FLLEdBQUcsQ0FBQyxDQUFDalQsQ0FBQyxDQUFDa1QsTUFBTSxHQUFHLElBQUksQ0FBQztRQUNwQzFOLE9BQU8sQ0FBQ1YsUUFBUSxDQUFDRSxPQUFPLENBQUMvQixHQUFHLENBQUNHLElBQUksR0FBRzRQLENBQUMsRUFBRXROLEVBQUUsRUFBRUMsRUFBRSxDQUFDO01BQ2hELENBQUMsTUFBTTtRQUNMVixNQUFNLENBQUVXLENBQUMsS0FBTTtVQUFFM0MsR0FBRyxFQUFFO1lBQUVDLEVBQUUsRUFBRTBDLENBQUMsQ0FBQzNDLEdBQUcsQ0FBQ0MsRUFBRSxHQUFHbEQsQ0FBQyxDQUFDbVQsTUFBTSxHQUFHdk4sQ0FBQyxDQUFDM0MsR0FBRyxDQUFDRyxJQUFJO1lBQUVELEVBQUUsRUFBRXlDLENBQUMsQ0FBQzNDLEdBQUcsQ0FBQ0UsRUFBRSxHQUFHbkQsQ0FBQyxDQUFDa1QsTUFBTSxHQUFHdE4sQ0FBQyxDQUFDM0MsR0FBRyxDQUFDRyxJQUFJO1lBQUVBLElBQUksRUFBRXdDLENBQUMsQ0FBQzNDLEdBQUcsQ0FBQ0c7VUFBSztRQUFFLENBQUMsQ0FBQyxDQUFDO01BQzVIO0lBQ0YsQ0FBQztJQUNEbkIsRUFBRSxDQUFDbVIsZ0JBQWdCLENBQUMsT0FBTyxFQUFFUixPQUFPLEVBQUU7TUFBRVMsT0FBTyxFQUFFO0lBQU0sQ0FBQyxDQUFDO0lBRXpELE1BQU1DLE1BQU0sR0FBSXRULENBQWUsSUFBSztNQUNsQyxNQUFNdVQsQ0FBQyxHQUFHclIsT0FBTyxDQUFDOEMsT0FBTztNQUN6QixJQUFJLENBQUN1TyxDQUFDLEVBQUU7TUFDUixNQUFNdEgsQ0FBQyxHQUFHbkgsUUFBUSxDQUFDRSxPQUFPLENBQUMvQixHQUFHLENBQUNHLElBQUk7TUFDbkMsSUFBSW1RLENBQUMsQ0FBQ3RELElBQUksS0FBSyxLQUFLLEVBQUU7UUFDcEIsTUFBTXVELEVBQUUsR0FBR3hULENBQUMsQ0FBQ3NGLE9BQU8sR0FBR2lPLENBQUMsQ0FBQ3JELEVBQUU7UUFDM0IsTUFBTXVELEVBQUUsR0FBR3pULENBQUMsQ0FBQ3VGLE9BQU8sR0FBR2dPLENBQUMsQ0FBQ3BELEVBQUU7UUFDM0JsTCxNQUFNLENBQUM7VUFBRWhDLEdBQUcsRUFBRTtZQUFFQyxFQUFFLEVBQUVxUSxDQUFDLENBQUNyUSxFQUFFLEdBQUdzUSxFQUFFLEdBQUd2SCxDQUFDO1lBQUU5SSxFQUFFLEVBQUVvUSxDQUFDLENBQUNwUSxFQUFFLEdBQUdzUSxFQUFFLEdBQUd4SCxDQUFDO1lBQUU3SSxJQUFJLEVBQUU2STtVQUFFO1FBQUUsQ0FBQyxDQUFDO01BQ3BFLENBQUMsTUFBTSxJQUFJc0gsQ0FBQyxDQUFDdEQsSUFBSSxLQUFLLE1BQU0sRUFBRTtRQUM1QixNQUFNdUQsRUFBRSxHQUFHLENBQUN4VCxDQUFDLENBQUNzRixPQUFPLEdBQUdpTyxDQUFDLENBQUNyRCxFQUFFLElBQUlqRSxDQUFDO1FBQ2pDLE1BQU13SCxFQUFFLEdBQUcsQ0FBQ3pULENBQUMsQ0FBQ3VGLE9BQU8sR0FBR2dPLENBQUMsQ0FBQ3BELEVBQUUsSUFBSWxFLENBQUM7UUFDakNzSCxDQUFDLENBQUM1QyxLQUFLLEdBQUcsSUFBSTtRQUNkMUwsTUFBTSxDQUFFVyxDQUFDLEtBQU07VUFDYnRDLE9BQU8sRUFBRXNDLENBQUMsQ0FBQ3RDLE9BQU8sQ0FBQzJELEdBQUcsQ0FBRUMsQ0FBQyxJQUN2QnFNLENBQUMsQ0FBQ2pNLEdBQUcsQ0FBQ3ZHLFFBQVEsQ0FBQ21HLENBQUMsQ0FBQ3JHLEVBQUUsQ0FBQyxJQUFJMFMsQ0FBQyxDQUFDOUMsSUFBSSxDQUFDdkosQ0FBQyxDQUFDckcsRUFBRSxDQUFDLEdBQUc7WUFBRSxHQUFHcUcsQ0FBQztZQUFFakcsQ0FBQyxFQUFFc1MsQ0FBQyxDQUFDOUMsSUFBSSxDQUFDdkosQ0FBQyxDQUFDckcsRUFBRSxDQUFDLENBQUNJLENBQUMsR0FBR3VTLEVBQUU7WUFBRTFILENBQUMsRUFBRXlILENBQUMsQ0FBQzlDLElBQUksQ0FBQ3ZKLENBQUMsQ0FBQ3JHLEVBQUUsQ0FBQyxDQUFDaUwsQ0FBQyxHQUFHMkg7VUFBRyxDQUFDLEdBQUd2TSxDQUNwRztRQUNGLENBQUMsQ0FBQyxDQUFDO01BQ0wsQ0FBQyxNQUFNLElBQUlxTSxDQUFDLENBQUN0RCxJQUFJLEtBQUssU0FBUyxFQUFFO1FBQy9CLE1BQU0sQ0FBQ3ZLLEVBQUUsRUFBRUMsRUFBRSxDQUFDLEdBQUdOLFVBQVUsQ0FBQ3JGLENBQUMsQ0FBQztRQUM5QixNQUFNaUIsQ0FBQyxHQUFHMkgsSUFBSSxDQUFDRyxHQUFHLENBQUNyRCxFQUFFLEVBQUU2TixDQUFDLENBQUNyRCxFQUFFLENBQUM7UUFDNUIsTUFBTXBFLENBQUMsR0FBR2xELElBQUksQ0FBQ0csR0FBRyxDQUFDcEQsRUFBRSxFQUFFNE4sQ0FBQyxDQUFDcEQsRUFBRSxDQUFDO1FBQzVCLE1BQU0vRyxDQUFDLEdBQUdSLElBQUksQ0FBQzhLLEdBQUcsQ0FBQ2hPLEVBQUUsR0FBRzZOLENBQUMsQ0FBQ3JELEVBQUUsQ0FBQztRQUM3QixNQUFNeUQsRUFBRSxHQUFHL0ssSUFBSSxDQUFDOEssR0FBRyxDQUFDL04sRUFBRSxHQUFHNE4sQ0FBQyxDQUFDcEQsRUFBRSxDQUFDO1FBQzlCLE1BQU12SyxDQUFDLEdBQUdkLFFBQVEsQ0FBQ0UsT0FBTztRQUMxQixNQUFNcEUsR0FBRyxHQUFHLElBQUFnVCx1QkFBYSxFQUFDaE8sQ0FBQyxDQUFDdEMsT0FBTyxFQUFFc0MsQ0FBQyxDQUFDM0MsR0FBRyxFQUFFMkMsQ0FBQyxDQUFDdkMsRUFBRSxFQUFFcEMsQ0FBQyxFQUFFNkssQ0FBQyxFQUFFMUMsQ0FBQyxFQUFFdUssRUFBRSxDQUFDO1FBQzlEMU8sTUFBTSxDQUFDO1VBQUVsQixPQUFPLEVBQUU7WUFBRTlDLENBQUM7WUFBRTZLLENBQUM7WUFBRTFDLENBQUM7WUFBRUMsQ0FBQyxFQUFFc0s7VUFBRyxDQUFDO1VBQUU5UCxTQUFTLEVBQUUwUCxDQUFDLENBQUNuRCxHQUFHLEdBQUd5RCxLQUFLLENBQUN2TCxJQUFJLENBQUMsSUFBSXdMLEdBQUcsQ0FBQ1AsQ0FBQyxDQUFDbEQsSUFBSSxDQUFDblAsTUFBTSxDQUFDTixHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUdBO1FBQUksQ0FBQyxDQUFDO01BQzNHLENBQUMsTUFBTSxJQUFJMlMsQ0FBQyxDQUFDdEQsSUFBSSxLQUFLLFNBQVMsRUFBRTtRQUMvQixNQUFNLENBQUN2SyxFQUFFLEVBQUVDLEVBQUUsQ0FBQyxHQUFHTixVQUFVLENBQUNyRixDQUFDLENBQUM7UUFDOUIsTUFBTTRGLENBQUMsR0FBR2QsUUFBUSxDQUFDRSxPQUFPO1FBQzFCLE1BQU0rTyxHQUFHLEdBQUcsSUFBQUMsdUJBQWEsRUFBQ3BPLENBQUMsQ0FBQ3RDLE9BQU8sRUFBRXNDLENBQUMsQ0FBQzNDLEdBQUcsRUFBRTJDLENBQUMsQ0FBQ3ZDLEVBQUUsRUFBRXFDLEVBQUUsRUFBRUMsRUFBRSxFQUFFNE4sQ0FBQyxDQUFDakwsSUFBSSxDQUFDO1FBQ2pFckQsTUFBTSxDQUFDO1VBQUVqQixjQUFjLEVBQUU7WUFBRXNFLElBQUksRUFBRWlMLENBQUMsQ0FBQ2pMLElBQUk7WUFBRXJILENBQUMsRUFBRXlFLEVBQUU7WUFBRW9HLENBQUMsRUFBRW5HLEVBQUU7WUFBRXFDLE1BQU0sRUFBRStMO1VBQUk7UUFBRSxDQUFDLENBQUM7TUFDekUsQ0FBQyxNQUFNLElBQUlSLENBQUMsQ0FBQ3RELElBQUksS0FBSyxRQUFRLElBQUlzRCxDQUFDLENBQUN0RCxJQUFJLEtBQUssUUFBUSxFQUFFO1FBQ3JEZ0UsV0FBVyxDQUFDVixDQUFDLEVBQUV2VCxDQUFDLENBQUM7TUFDbkI7SUFDRixDQUFDO0lBRUQsTUFBTWlVLFdBQVcsR0FBR0EsQ0FBQ1YsQ0FBK0MsRUFBRXZULENBQWUsS0FBSztNQUN4RixNQUFNNEYsQ0FBQyxHQUFHZCxRQUFRLENBQUNFLE9BQU87TUFDMUIsTUFBTWlILENBQUMsR0FBR3JHLENBQUMsQ0FBQzNDLEdBQUcsQ0FBQ0csSUFBSTtNQUNwQixNQUFNb1EsRUFBRSxHQUFHLENBQUN4VCxDQUFDLENBQUNzRixPQUFPLEdBQUdpTyxDQUFDLENBQUNyRCxFQUFFLElBQUlqRSxDQUFDO01BQ2pDLE1BQU13SCxFQUFFLEdBQUcsQ0FBQ3pULENBQUMsQ0FBQ3VGLE9BQU8sR0FBR2dPLENBQUMsQ0FBQ3BELEVBQUUsSUFBSWxFLENBQUM7TUFDakNzSCxDQUFDLENBQUM1QyxLQUFLLEdBQUcsSUFBSTtNQUNkMUwsTUFBTSxDQUFFd0UsRUFBRSxLQUFNO1FBQ2RuRyxPQUFPLEVBQUVtRyxFQUFFLENBQUNuRyxPQUFPLENBQUMyRCxHQUFHLENBQUVDLENBQUMsSUFBSztVQUM3QixJQUFJQSxDQUFDLENBQUNyRyxFQUFFLEtBQUswUyxDQUFDLENBQUMxUyxFQUFFLEVBQUUsT0FBT3FHLENBQUM7VUFDM0IsSUFBSXFNLENBQUMsQ0FBQ3RELElBQUksS0FBSyxRQUFRLEVBQUU7WUFDdkIsTUFBTS9NLEVBQUUsR0FBR3FRLENBQUMsQ0FBQ3JNLENBQUMsQ0FBQ2pHLENBQUMsR0FBR3NTLENBQUMsQ0FBQ3JNLENBQUMsQ0FBQ2tDLENBQUMsR0FBRyxDQUFDO1lBQzVCLE1BQU1qRyxFQUFFLEdBQUdvUSxDQUFDLENBQUNyTSxDQUFDLENBQUM0RSxDQUFDLEdBQUd5SCxDQUFDLENBQUNyTSxDQUFDLENBQUNtQyxDQUFDLEdBQUcsQ0FBQztZQUM1QixNQUFNLENBQUMzRCxFQUFFLEVBQUVDLEVBQUUsQ0FBQyxHQUFHTixVQUFVLENBQUNyRixDQUFDLENBQUM7WUFDOUIsTUFBTSxDQUFDMkwsRUFBRSxFQUFFQyxFQUFFLENBQUMsR0FBRyxJQUFBZ0csZUFBTyxFQUFDaE0sQ0FBQyxDQUFDM0MsR0FBRyxFQUFFMkMsQ0FBQyxDQUFDdkMsRUFBRSxFQUFFcUMsRUFBRSxFQUFFQyxFQUFFLENBQUM7WUFDN0MsSUFBSXVPLEdBQUcsR0FBSXRMLElBQUksQ0FBQ3VMLEtBQUssQ0FBQ3ZJLEVBQUUsR0FBR3pJLEVBQUUsRUFBRXdJLEVBQUUsR0FBR3pJLEVBQUUsQ0FBQyxHQUFHLEdBQUcsR0FBSTBGLElBQUksQ0FBQ3dMLEVBQUUsR0FBRyxFQUFFO1lBQzdELElBQUlwVSxDQUFDLENBQUNnUSxRQUFRLEVBQUVrRSxHQUFHLEdBQUd0TCxJQUFJLENBQUN5TCxLQUFLLENBQUNILEdBQUcsR0FBRyxFQUFFLENBQUMsR0FBRyxFQUFFO1lBQy9DLE9BQU87Y0FBRSxHQUFHaE4sQ0FBQztjQUFFNkUsR0FBRyxFQUFFbkQsSUFBSSxDQUFDeUwsS0FBSyxDQUFDSCxHQUFHO1lBQUUsQ0FBQztVQUN2QztVQUNBLElBQUlqVCxDQUFDLEdBQUdzUyxDQUFDLENBQUNyTSxDQUFDLENBQUNqRyxDQUFDO1VBQ2IsSUFBSTZLLENBQUMsR0FBR3lILENBQUMsQ0FBQ3JNLENBQUMsQ0FBQzRFLENBQUM7VUFDYixJQUFJMUMsQ0FBQyxHQUFHbUssQ0FBQyxDQUFDck0sQ0FBQyxDQUFDa0MsQ0FBQztVQUNiLElBQUl1SyxFQUFFLEdBQUdKLENBQUMsQ0FBQ3JNLENBQUMsQ0FBQ21DLENBQUM7VUFDZCxNQUFNaUwsQ0FBQyxHQUFHZixDQUFDLENBQUM3SCxJQUFJO1VBQ2hCLElBQUk0SSxDQUFDLENBQUN2VCxRQUFRLENBQUMsR0FBRyxDQUFDLEVBQUVxSSxDQUFDLEdBQUdSLElBQUksQ0FBQ21DLEdBQUcsQ0FBQyxFQUFFLEVBQUV3SSxDQUFDLENBQUNyTSxDQUFDLENBQUNrQyxDQUFDLEdBQUdvSyxFQUFFLENBQUM7VUFDakQsSUFBSWMsQ0FBQyxDQUFDdlQsUUFBUSxDQUFDLEdBQUcsQ0FBQyxFQUFFNFMsRUFBRSxHQUFHL0ssSUFBSSxDQUFDbUMsR0FBRyxDQUFDLEVBQUUsRUFBRXdJLENBQUMsQ0FBQ3JNLENBQUMsQ0FBQ21DLENBQUMsR0FBR29LLEVBQUUsQ0FBQztVQUNsRCxJQUFJYSxDQUFDLENBQUN2VCxRQUFRLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDbkJxSSxDQUFDLEdBQUdSLElBQUksQ0FBQ21DLEdBQUcsQ0FBQyxFQUFFLEVBQUV3SSxDQUFDLENBQUNyTSxDQUFDLENBQUNrQyxDQUFDLEdBQUdvSyxFQUFFLENBQUM7WUFDNUJ2UyxDQUFDLEdBQUdzUyxDQUFDLENBQUNyTSxDQUFDLENBQUNqRyxDQUFDLElBQUlzUyxDQUFDLENBQUNyTSxDQUFDLENBQUNrQyxDQUFDLEdBQUdBLENBQUMsQ0FBQztVQUN6QjtVQUNBLElBQUlrTCxDQUFDLENBQUN2VCxRQUFRLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDbkI0UyxFQUFFLEdBQUcvSyxJQUFJLENBQUNtQyxHQUFHLENBQUMsRUFBRSxFQUFFd0ksQ0FBQyxDQUFDck0sQ0FBQyxDQUFDbUMsQ0FBQyxHQUFHb0ssRUFBRSxDQUFDO1lBQzdCM0gsQ0FBQyxHQUFHeUgsQ0FBQyxDQUFDck0sQ0FBQyxDQUFDNEUsQ0FBQyxJQUFJeUgsQ0FBQyxDQUFDck0sQ0FBQyxDQUFDbUMsQ0FBQyxHQUFHc0ssRUFBRSxDQUFDO1VBQzFCO1VBQ0EsT0FBTztZQUFFLEdBQUd6TSxDQUFDO1lBQUVqRyxDQUFDO1lBQUU2SyxDQUFDO1lBQUUxQyxDQUFDO1lBQUVDLENBQUMsRUFBRXNLO1VBQUcsQ0FBQztRQUNqQyxDQUFDO01BQ0gsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQsTUFBTVksSUFBSSxHQUFJdlUsQ0FBZSxJQUFLO01BQ2hDLE1BQU11VCxDQUFDLEdBQUdyUixPQUFPLENBQUM4QyxPQUFPO01BQ3pCOUMsT0FBTyxDQUFDOEMsT0FBTyxHQUFHLElBQUk7TUFDdEIsSUFBSSxDQUFDdU8sQ0FBQyxFQUFFO1FBQ04sSUFBSXpPLFFBQVEsQ0FBQ0UsT0FBTyxDQUFDTixPQUFPLEVBQUVPLE1BQU0sQ0FBQztVQUFFUCxPQUFPLEVBQUU7UUFBTSxDQUFDLENBQUM7UUFDeEQ7TUFDRjtNQUNBLElBQUk2TyxDQUFDLENBQUN0RCxJQUFJLEtBQUssS0FBSyxFQUFFO1FBQ3BCaEwsTUFBTSxDQUFDO1VBQUVQLE9BQU8sRUFBRTtRQUFNLENBQUMsQ0FBQztNQUM1QixDQUFDLE1BQU0sSUFBSTZPLENBQUMsQ0FBQ3RELElBQUksS0FBSyxNQUFNLElBQUlzRCxDQUFDLENBQUM1QyxLQUFLLEVBQUU7UUFDdkMsTUFBTUEsS0FBSyxHQUFHN0wsUUFBUSxDQUFDRSxPQUFPLENBQUMxQixPQUFPLENBQUN0QyxNQUFNLENBQUVrRyxDQUFDLElBQUtxTSxDQUFDLENBQUNqTSxHQUFHLENBQUN2RyxRQUFRLENBQUNtRyxDQUFDLENBQUNyRyxFQUFFLENBQUMsQ0FBQztRQUMxRTZGLFVBQVUsQ0FBQ2lLLEtBQUssRUFBRSxvQkFBb0I0QyxDQUFDLENBQUNqTSxHQUFHLENBQUNrQyxNQUFNLEdBQUcsQ0FBQyxHQUFHLEdBQUcrSixDQUFDLENBQUNqTSxHQUFHLENBQUNrQyxNQUFNLFFBQVEsR0FBRyxHQUFHK0osQ0FBQyxDQUFDak0sR0FBRyxDQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztNQUN6RyxDQUFDLE1BQU0sSUFBSWlNLENBQUMsQ0FBQ3RELElBQUksS0FBSyxTQUFTLEVBQUU7UUFDL0JoTCxNQUFNLENBQUM7VUFBRWxCLE9BQU8sRUFBRTtRQUFLLENBQUMsQ0FBQztNQUMzQixDQUFDLE1BQU0sSUFBSXdQLENBQUMsQ0FBQ3RELElBQUksS0FBSyxTQUFTLEVBQUU7UUFDL0IsTUFBTSxDQUFDdkssRUFBRSxFQUFFQyxFQUFFLENBQUMsR0FBR04sVUFBVSxDQUFDckYsQ0FBQyxDQUFDO1FBQzlCLE1BQU00RixDQUFDLEdBQUdkLFFBQVEsQ0FBQ0UsT0FBTztRQUMxQixNQUFNK08sR0FBRyxHQUFHLElBQUFDLHVCQUFhLEVBQUNwTyxDQUFDLENBQUN0QyxPQUFPLEVBQUVzQyxDQUFDLENBQUMzQyxHQUFHLEVBQUUyQyxDQUFDLENBQUN2QyxFQUFFLEVBQUVxQyxFQUFFLEVBQUVDLEVBQUUsRUFBRTROLENBQUMsQ0FBQ2pMLElBQUksQ0FBQztRQUNqRSxJQUFJeUwsR0FBRyxFQUFFbkYsYUFBYSxDQUFDMkUsQ0FBQyxDQUFDakwsSUFBSSxFQUFFeUwsR0FBRyxDQUFDO1FBQ25DOU8sTUFBTSxDQUFDO1VBQUVqQixjQUFjLEVBQUU7UUFBSyxDQUFDLENBQUM7TUFDbEMsQ0FBQyxNQUFNLElBQUksQ0FBQ3VQLENBQUMsQ0FBQ3RELElBQUksS0FBSyxRQUFRLElBQUlzRCxDQUFDLENBQUN0RCxJQUFJLEtBQUssUUFBUSxLQUFLc0QsQ0FBQyxDQUFDNUMsS0FBSyxFQUFFO1FBQ2xFLE1BQU16SixDQUFDLEdBQUdwQyxRQUFRLENBQUNFLE9BQU8sQ0FBQzFCLE9BQU8sQ0FBQ3FFLElBQUksQ0FBRTFHLENBQUMsSUFBS0EsQ0FBQyxDQUFDSixFQUFFLEtBQUswUyxDQUFDLENBQUMxUyxFQUFFLENBQUM7UUFDN0Q2RixVQUFVLENBQUNRLENBQUMsR0FBRyxDQUFDQSxDQUFDLENBQUMsR0FBRyxFQUFFLEVBQUUsaUJBQWlCLENBQUM7TUFDN0M7SUFDRixDQUFDO0lBRUQsTUFBTXNOLFNBQVMsR0FBSXhVLENBQWdCLElBQUs7TUFDdEMsTUFBTStGLENBQUMsR0FBRy9GLENBQUMsQ0FBQ2dJLE1BQTRCO01BQ3hDLElBQUlqQyxDQUFDLEtBQUtBLENBQUMsQ0FBQzBPLE9BQU8sS0FBSyxPQUFPLElBQUkxTyxDQUFDLENBQUMwTyxPQUFPLEtBQUssVUFBVSxJQUFJMU8sQ0FBQyxDQUFDME8sT0FBTyxLQUFLLFFBQVEsSUFBSTFPLENBQUMsQ0FBQzJPLGlCQUFpQixDQUFDLEVBQUU7TUFDL0csTUFBTTlPLENBQUMsR0FBR2QsUUFBUSxDQUFDRSxPQUFPO01BQzFCLElBQUlZLENBQUMsQ0FBQ3RCLE9BQU8sRUFBRTtRQUNiLElBQUl0RSxDQUFDLENBQUMyVSxHQUFHLEtBQUssWUFBWSxJQUFJM1UsQ0FBQyxDQUFDMlUsR0FBRyxLQUFLLEdBQUcsRUFBRTtVQUMzQzNVLENBQUMsQ0FBQzZTLGNBQWMsQ0FBQyxDQUFDO1VBQ2xCbEksUUFBUSxDQUFDLENBQUM7UUFDWixDQUFDLE1BQU0sSUFBSTNLLENBQUMsQ0FBQzJVLEdBQUcsS0FBSyxXQUFXLEVBQUU7VUFDaEM3SixRQUFRLENBQUMsQ0FBQztRQUNaLENBQUMsTUFBTSxJQUFJOUssQ0FBQyxDQUFDMlUsR0FBRyxLQUFLLFFBQVEsRUFBRTtVQUM3QmpLLFFBQVEsQ0FBQyxDQUFDO1FBQ1o7UUFDQTtNQUNGO01BQ0E7TUFDQTtNQUNBO01BQ0EsSUFBSTlFLENBQUMsQ0FBQzNCLFdBQVcsRUFBRTtRQUNqQixJQUFJakUsQ0FBQyxDQUFDMlUsR0FBRyxLQUFLLFdBQVcsSUFBSTNVLENBQUMsQ0FBQzJVLEdBQUcsS0FBSyxTQUFTLEVBQUU7VUFDaEQzVSxDQUFDLENBQUM2UyxjQUFjLENBQUMsQ0FBQztVQUNsQm5ELGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3ZCLENBQUMsTUFBTSxJQUFJMVAsQ0FBQyxDQUFDMlUsR0FBRyxLQUFLLFlBQVksSUFBSTNVLENBQUMsQ0FBQzJVLEdBQUcsS0FBSyxXQUFXLEVBQUU7VUFDMUQzVSxDQUFDLENBQUM2UyxjQUFjLENBQUMsQ0FBQztVQUNsQm5ELGlCQUFpQixDQUFDLENBQUMsQ0FBQztRQUN0QixDQUFDLE1BQU0sSUFBSTFQLENBQUMsQ0FBQzJVLEdBQUcsS0FBSyxPQUFPLEVBQUU7VUFDNUIzVSxDQUFDLENBQUM2UyxjQUFjLENBQUMsQ0FBQztVQUNsQnJELFVBQVUsQ0FBQyxJQUFJLENBQUM7UUFDbEIsQ0FBQyxNQUFNLElBQUl4UCxDQUFDLENBQUMyVSxHQUFHLEtBQUssUUFBUSxFQUFFO1VBQzdCM1UsQ0FBQyxDQUFDNlMsY0FBYyxDQUFDLENBQUM7VUFDbEJyRCxVQUFVLENBQUMsS0FBSyxDQUFDO1FBQ25CO1FBQ0E7TUFDRjtNQUNBLElBQUl4UCxDQUFDLENBQUMyVSxHQUFHLEtBQUssUUFBUSxFQUFFMVAsTUFBTSxDQUFDO1FBQUVwQixTQUFTLEVBQUUsRUFBRTtRQUFFUSxTQUFTLEVBQUUsSUFBSTtRQUFFRyxNQUFNLEVBQUU7TUFBSyxDQUFDLENBQUM7TUFDaEYsSUFBSXhFLENBQUMsQ0FBQzJVLEdBQUcsS0FBSyxHQUFHLEVBQUVyUyxRQUFRLENBQUMwQyxPQUFPLEdBQUcsSUFBSTtNQUMxQyxJQUFJWSxDQUFDLENBQUNqRCxJQUFJLEtBQUssTUFBTSxJQUFJaUQsQ0FBQyxDQUFDL0IsU0FBUyxDQUFDMkYsTUFBTSxFQUFFO1FBQzNDLE1BQU1WLElBQUksR0FBRzlJLENBQUMsQ0FBQ2dRLFFBQVEsR0FBRyxFQUFFLEdBQUcsQ0FBQztRQUNoQyxJQUFJd0QsRUFBRSxHQUFHLENBQUM7UUFDVixJQUFJQyxFQUFFLEdBQUcsQ0FBQztRQUNWLElBQUl6VCxDQUFDLENBQUMyVSxHQUFHLEtBQUssV0FBVyxFQUFFbkIsRUFBRSxHQUFHLENBQUMxSyxJQUFJLENBQUMsS0FDakMsSUFBSTlJLENBQUMsQ0FBQzJVLEdBQUcsS0FBSyxZQUFZLEVBQUVuQixFQUFFLEdBQUcxSyxJQUFJLENBQUMsS0FDdEMsSUFBSTlJLENBQUMsQ0FBQzJVLEdBQUcsS0FBSyxTQUFTLEVBQUVsQixFQUFFLEdBQUcsQ0FBQzNLLElBQUksQ0FBQyxLQUNwQyxJQUFJOUksQ0FBQyxDQUFDMlUsR0FBRyxLQUFLLFdBQVcsRUFBRWxCLEVBQUUsR0FBRzNLLElBQUk7UUFDekMsSUFBSTBLLEVBQUUsSUFBSUMsRUFBRSxFQUFFO1VBQ1p6VCxDQUFDLENBQUM2UyxjQUFjLENBQUMsQ0FBQztVQUNsQixNQUFNalMsR0FBRyxHQUFHZ0YsQ0FBQyxDQUFDL0IsU0FBUztVQUN2Qm9CLE1BQU0sQ0FBRXdFLEVBQUUsS0FBTTtZQUFFbkcsT0FBTyxFQUFFbUcsRUFBRSxDQUFDbkcsT0FBTyxDQUFDMkQsR0FBRyxDQUFFQyxDQUFDLElBQU10RyxHQUFHLENBQUNHLFFBQVEsQ0FBQ21HLENBQUMsQ0FBQ3JHLEVBQUUsQ0FBQyxJQUFJLENBQUNxRyxDQUFDLENBQUNzSixNQUFNLEdBQUc7Y0FBRSxHQUFHdEosQ0FBQztjQUFFakcsQ0FBQyxFQUFFaUcsQ0FBQyxDQUFDakcsQ0FBQyxHQUFHdVMsRUFBRTtjQUFFMUgsQ0FBQyxFQUFFNUUsQ0FBQyxDQUFDNEUsQ0FBQyxHQUFHMkg7WUFBRyxDQUFDLEdBQUd2TSxDQUFFO1VBQUUsQ0FBQyxDQUFDLENBQUM7VUFDaElHLFlBQVksQ0FBQ3pHLEdBQUcsQ0FBQztRQUNuQjtRQUNBLElBQUlaLENBQUMsQ0FBQzJVLEdBQUcsS0FBSyxRQUFRLElBQUkzVSxDQUFDLENBQUMyVSxHQUFHLEtBQUssV0FBVyxFQUFFdkosZUFBZSxDQUFDLENBQUM7TUFDcEU7SUFDRixDQUFDO0lBQ0QsTUFBTXdKLE9BQU8sR0FBSTVVLENBQWdCLElBQUs7TUFDcEMsSUFBSUEsQ0FBQyxDQUFDMlUsR0FBRyxLQUFLLEdBQUcsRUFBRXJTLFFBQVEsQ0FBQzBDLE9BQU8sR0FBRyxLQUFLO0lBQzdDLENBQUM7SUFFRCtNLFFBQVEsQ0FBQ3FCLGdCQUFnQixDQUFDLGFBQWEsRUFBRUUsTUFBTSxDQUFDO0lBQ2hEdkIsUUFBUSxDQUFDcUIsZ0JBQWdCLENBQUMsV0FBVyxFQUFFbUIsSUFBSSxDQUFDO0lBQzVDbFUsTUFBTSxDQUFDK1MsZ0JBQWdCLENBQUMsU0FBUyxFQUFFb0IsU0FBUyxDQUFDO0lBQzdDblUsTUFBTSxDQUFDK1MsZ0JBQWdCLENBQUMsT0FBTyxFQUFFd0IsT0FBTyxDQUFDO0lBRXpDLE9BQU8sTUFBTTtNQUNYM1MsRUFBRSxDQUFDNFMsbUJBQW1CLENBQUMsT0FBTyxFQUFFakMsT0FBTyxDQUFDO01BQ3hDSCxFQUFFLENBQUNxQyxVQUFVLENBQUMsQ0FBQztNQUNmL0MsUUFBUSxDQUFDOEMsbUJBQW1CLENBQUMsYUFBYSxFQUFFdkIsTUFBTSxDQUFDO01BQ25EdkIsUUFBUSxDQUFDOEMsbUJBQW1CLENBQUMsV0FBVyxFQUFFTixJQUFJLENBQUM7TUFDL0NsVSxNQUFNLENBQUN3VSxtQkFBbUIsQ0FBQyxTQUFTLEVBQUVMLFNBQVMsQ0FBQztNQUNoRG5VLE1BQU0sQ0FBQ3dVLG1CQUFtQixDQUFDLE9BQU8sRUFBRUQsT0FBTyxDQUFDO01BQzVDLElBQUl4UyxRQUFRLENBQUM0QyxPQUFPLEVBQUVxRCxvQkFBb0IsQ0FBQ2pHLFFBQVEsQ0FBQzRDLE9BQU8sQ0FBQztJQUM5RCxDQUFDO0lBQ0Q7SUFDQTtJQUNBO0VBQ0YsQ0FBQyxFQUFFLENBQUNwRCxRQUFRLENBQUMsQ0FBQzs7RUFFZDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDRSxNQUFNbVQsb0JBQW9CLEdBQUcsSUFBQS9TLGtCQUFXLEVBQ3RDLE1BQU9nVCxPQUFlLElBQXVCO0lBQzNDO0lBQ0E7SUFDQTtJQUNBLElBQUlDLEtBQUssR0FBRyxJQUFBQyxrQ0FBcUIsRUFBQ0YsT0FBTyxFQUFFLElBQUFHLGlCQUFTLEVBQUMsQ0FBQyxDQUFDO0lBQ3ZELEtBQUssSUFBSUMsS0FBSyxHQUFHLENBQUMsRUFBRSxDQUFDSCxLQUFLLElBQUlHLEtBQUssR0FBRyxFQUFFLEVBQUVBLEtBQUssSUFBSSxDQUFDLEVBQUU7TUFDcEQsTUFBTSxJQUFJck8sT0FBTyxDQUFFb0wsQ0FBQyxJQUFLN0wsVUFBVSxDQUFDNkwsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO01BQzNDOEMsS0FBSyxHQUFHLElBQUFDLGtDQUFxQixFQUFDRixPQUFPLEVBQUUsSUFBQUcsaUJBQVMsRUFBQyxDQUFDLENBQUM7SUFDckQ7SUFDQSxJQUFJLENBQUNGLEtBQUssRUFBRTtNQUNWalAsS0FBSyxDQUFDLDBEQUEwRCxFQUFFLE9BQU8sRUFBRTtRQUFFYyxTQUFTLEVBQUU7TUFBVSxDQUFDLENBQUM7TUFDcEcsT0FBTyxLQUFLO0lBQ2Q7SUFDQSxNQUFNa0IsTUFBTSxHQUFHLElBQUFxTixnQ0FBbUIsRUFBQ0osS0FBSyxDQUFDO0lBQ3pDLElBQUk7TUFDRixJQUFJLE1BQU0sSUFBQW5ILHVCQUFXLEVBQUM5RixNQUFNLENBQUMsRUFBRTtRQUM3QixNQUFNb0YsYUFBYSxDQUFDcEYsTUFBTSxDQUFDO01BQzdCLENBQUMsTUFBTTtRQUNMO1FBQ0E7UUFDQXpCLFFBQVEsQ0FBQ3ZCLE9BQU8sR0FBR2dELE1BQU07UUFDekIsTUFBTXBDLENBQUMsR0FBR2QsUUFBUSxDQUFDRSxPQUFPO1FBQzFCLE1BQU0sSUFBQXNRLHFCQUFTLEVBQUN0TixNQUFNLEVBQUU7VUFBRTFFLE9BQU8sRUFBRXNDLENBQUMsQ0FBQ3RDLE9BQU87VUFBRUUsS0FBSyxFQUFFb0MsQ0FBQyxDQUFDcEMsS0FBSztVQUFFRyxRQUFRLEVBQUVpQyxDQUFDLENBQUNqQztRQUFTLENBQUMsQ0FBQztNQUN2RjtNQUNBcUMsS0FBSyxDQUFDLGlCQUFpQixFQUFFLE9BQU8sQ0FBQztNQUNqQyxPQUFPLElBQUk7SUFDYixDQUFDLENBQUMsT0FBT2hHLENBQUMsRUFBRTtNQUNWZ0csS0FBSyxDQUFDLHdCQUF3QmpHLE1BQU0sQ0FBQ0MsQ0FBQyxDQUFDLEVBQUUsRUFBRSxPQUFPLEVBQUU7UUFBRThHLFNBQVMsRUFBRTtNQUFVLENBQUMsQ0FBQztNQUM3RSxPQUFPLEtBQUs7SUFDZDtFQUNGLENBQUMsRUFDRCxDQUFDZCxLQUFLLEVBQUVvSCxhQUFhLENBQ3ZCLENBQUM7O0VBRUQ7RUFDQSxJQUFBckksZ0JBQVMsRUFBQyxNQUFNO0lBQ2QsSUFBSXdRLFNBQVMsR0FBRyxLQUFLO0lBQ3JCLElBQUlDLEtBQStCO0lBQ25DLE1BQU1DLE1BQU0sR0FBR2pQLFVBQVUsQ0FBQ3hCLE9BQU87SUFDakMsQ0FBQyxZQUFZO01BQ1g7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0EsSUFBSTBRLFNBQVMsR0FBRyxLQUFLO01BQ3JCLE1BQU0vRixHQUFHLEdBQUcsTUFBTSxJQUFBZ0csaUNBQW9CLEVBQUMsQ0FBQztNQUN4QyxJQUFJaEcsR0FBRyxFQUFFO1FBQ1AsTUFBTWlHLE1BQU0sR0FBRyxNQUFNYixvQkFBb0IsQ0FBQ3BGLEdBQUcsQ0FBQztRQUM5QyxJQUFJaUcsTUFBTSxFQUFFLE1BQU0sSUFBQUMseUJBQVksRUFBQyxJQUFJLENBQUMsQ0FBQyxLQUNoQyxNQUFNLElBQUFDLDZCQUFnQixFQUFDLENBQUM7UUFDN0IsSUFBSVAsU0FBUyxFQUFFO1FBQ2Y7UUFDQTtRQUNBO1FBQ0FHLFNBQVMsR0FBR0UsTUFBTTtNQUNwQjs7TUFFQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBLElBQUksQ0FBQ0YsU0FBUyxFQUFFO1FBQ2QsSUFBSUssTUFBMkIsR0FBRyxJQUFJO1FBQ3RDLElBQUk7VUFDRkEsTUFBTSxHQUFHLE1BQU0sSUFBQUMsK0JBQWtCLEVBQUNiLGlCQUFTLEVBQUUsTUFBTUksU0FBUyxDQUFDO1FBQy9ELENBQUMsQ0FBQyxNQUFNO1VBQ047UUFBQTtRQUVGLElBQUlRLE1BQU0sRUFBRTtVQUNWLE1BQU0vTixNQUFNLEdBQUcsSUFBQXFOLGdDQUFtQixFQUFDVSxNQUFNLENBQUM7VUFDMUMsSUFBSTtZQUNGLElBQUksTUFBTSxJQUFBakksdUJBQVcsRUFBQzlGLE1BQU0sQ0FBQyxFQUFFO2NBQzdCLE1BQU1vRixhQUFhLENBQUNwRixNQUFNLENBQUM7Y0FDM0IsSUFBSSxDQUFDdU4sU0FBUyxFQUFFdlAsS0FBSyxDQUFDLGlCQUFpQixFQUFFLE9BQU8sQ0FBQztjQUNqRDBQLFNBQVMsR0FBRyxJQUFJO1lBQ2xCO1VBQ0YsQ0FBQyxDQUFDLE9BQU8xVixDQUFDLEVBQUU7WUFDVixJQUFJLENBQUN1VixTQUFTLEVBQUV2UCxLQUFLLENBQUMsd0JBQXdCakcsTUFBTSxDQUFDQyxDQUFDLENBQUMsRUFBRSxFQUFFLE9BQU8sRUFBRTtjQUFFOEcsU0FBUyxFQUFFO1lBQVUsQ0FBQyxDQUFDO1VBQy9GO1FBQ0Y7TUFDRjtNQUNBO01BQ0E7TUFDQTtNQUNBLElBQUl5TyxTQUFTLEVBQUU7TUFFZixJQUFJLENBQUNHLFNBQVMsRUFBRTtRQUNkLElBQUkxTixNQUFtQjtRQUN2QixJQUFJO1VBQ0Y7VUFDQTtVQUNBQSxNQUFNLEdBQUcsTUFBTSxJQUFBaU8sMkJBQWUsRUFBQyxDQUFDO1FBQ2xDLENBQUMsQ0FBQyxPQUFPalcsQ0FBQyxFQUFFO1VBQ1Y7VUFDQTtVQUNBLE1BQU1rVyxPQUFPLEdBQUcsSUFBQUMsc0NBQTBCLEVBQUNuVyxDQUFDLENBQUM7VUFDN0MsSUFBSSxDQUFDdVYsU0FBUyxFQUNadlAsS0FBSyxDQUNIa1EsT0FBTyxDQUFDRSxJQUFJLEVBQ1pGLE9BQU8sQ0FBQ0csSUFBSSxHQUFHLE1BQU0sR0FBRyxPQUFPLEVBQy9CSCxPQUFPLENBQUNHLElBQUksR0FBRztZQUFFdlAsU0FBUyxFQUFFO1VBQWUsQ0FBQyxHQUFHO1lBQUVBLFNBQVMsRUFBRTtVQUFVLENBQ3hFLENBQUM7VUFDSDtRQUNGO1FBQ0EsSUFBSXlPLFNBQVMsRUFBRTtRQUNmaFAsUUFBUSxDQUFDdkIsT0FBTyxHQUFHZ0QsTUFBTTtRQUN6QixJQUFJO1VBQ0YsSUFBSSxNQUFNLElBQUE4Rix1QkFBVyxFQUFDOUYsTUFBTSxDQUFDLEVBQUU7WUFDN0IsTUFBTXFGLEtBQUssR0FBRyxNQUFNLElBQUFDLHFCQUFTLEVBQUN0RixNQUFNLENBQUM7WUFDckMsSUFBSSxDQUFDdU4sU0FBUyxFQUFFO2NBQ2R0USxNQUFNLENBQUM7Z0JBQ0wzQixPQUFPLEVBQUUrSixLQUFLLENBQUMvSixPQUFPO2dCQUN0QkUsS0FBSyxFQUFFNkosS0FBSyxDQUFDN0osS0FBSyxDQUFDZ0csTUFBTSxHQUFHNkQsS0FBSyxDQUFDN0osS0FBSyxHQUFHQyxxQkFBVSxDQUFDQyxLQUFLLENBQUMsQ0FBQztnQkFDNURDLFFBQVEsRUFBRTBKLEtBQUssQ0FBQzFKLFFBQVEsQ0FBQzZGLE1BQU0sR0FBRzZELEtBQUssQ0FBQzFKLFFBQVEsR0FBR0M7Y0FDckQsQ0FBQyxDQUFDO2NBQ0ZvQyxLQUFLLENBQUMsK0JBQStCLEVBQUUsT0FBTyxDQUFDO1lBQ2pEO1VBQ0YsQ0FBQyxNQUFNO1lBQ0w7WUFDQSxNQUFNSixDQUFDLEdBQUdkLFFBQVEsQ0FBQ0UsT0FBTztZQUMxQixNQUFNLElBQUFzUSxxQkFBUyxFQUFDdE4sTUFBTSxFQUFFO2NBQUUxRSxPQUFPLEVBQUVzQyxDQUFDLENBQUN0QyxPQUFPO2NBQUVFLEtBQUssRUFBRW9DLENBQUMsQ0FBQ3BDLEtBQUs7Y0FBRUcsUUFBUSxFQUFFaUMsQ0FBQyxDQUFDakM7WUFBUyxDQUFDLENBQUM7WUFDckYsSUFBSSxDQUFDNFIsU0FBUyxFQUFFdlAsS0FBSyxDQUFDLDhCQUE4QixFQUFFLE9BQU8sQ0FBQztVQUNoRTtRQUNGLENBQUMsQ0FBQyxPQUFPaEcsQ0FBQyxFQUFFO1VBQ1YsSUFBSSxDQUFDdVYsU0FBUyxFQUFFdlAsS0FBSyxDQUFDLHNCQUFzQmpHLE1BQU0sQ0FBQ0MsQ0FBQyxDQUFDLEVBQUUsRUFBRSxPQUFPLEVBQUU7WUFBRThHLFNBQVMsRUFBRTtVQUFVLENBQUMsQ0FBQztRQUM3RjtNQUNGO01BQ0EsSUFBSXlPLFNBQVMsRUFBRTtNQUNmO01BQ0E7TUFDQSxJQUFJO1FBQ0Z0USxNQUFNLENBQUM7VUFBRUosTUFBTSxFQUFFLElBQUFzUSxpQkFBUyxFQUFDO1FBQUUsQ0FBQyxDQUFDO01BQ2pDLENBQUMsQ0FBQyxNQUFNO1FBQ047TUFBQTtNQUVGO01BQ0E7TUFDQTtNQUNBO01BQ0EsSUFBSTtRQUNGSyxLQUFLLEdBQUcsSUFBQWMsc0JBQWMsRUFBQyxDQUFDelIsTUFBTSxFQUFFd0csT0FBTyxLQUFLO1VBQzFDcEcsTUFBTSxDQUFDO1lBQUVKO1VBQU8sQ0FBQyxDQUFDO1VBQ2xCLE1BQU0wUixHQUFHLEdBQUdoUSxRQUFRLENBQUN2QixPQUFPO1VBQzVCLElBQUksQ0FBQ3VSLEdBQUcsRUFBRTtVQUNWLE1BQU1DLENBQUMsR0FBRzNSLE1BQU0sQ0FBQzhDLElBQUksQ0FBRTFHLENBQUMsSUFBTXNWLEdBQUcsQ0FBQzNJLE9BQU8sR0FBRzNNLENBQUMsQ0FBQ0osRUFBRSxLQUFLMFYsR0FBRyxDQUFDM0ksT0FBTyxHQUFHM00sQ0FBQyxDQUFDeU4sSUFBSSxLQUFLNkgsR0FBRyxDQUFDM1csSUFBSyxDQUFDO1VBQ3hGLElBQUk0VyxDQUFDLEVBQUU7WUFDTCxNQUFNN1QsSUFBSSxHQUFHNlQsQ0FBQyxDQUFDN1QsSUFBSSxLQUFLLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSTtZQUMxQyxJQUFJQSxJQUFJLEtBQUs0VCxHQUFHLENBQUM1VCxJQUFJLEVBQUU7Y0FDckI0RCxRQUFRLENBQUN2QixPQUFPLEdBQUc7Z0JBQUUsR0FBR3VSLEdBQUc7Z0JBQUU1VDtjQUFLLENBQUM7Y0FDbkMsSUFBSUEsSUFBSSxLQUFLLElBQUksRUFBRTtnQkFDakJzQyxNQUFNLENBQUM7a0JBQUV0QyxJQUFJLEVBQUUsS0FBSztrQkFBRWtCLFNBQVMsRUFBRSxFQUFFO2tCQUFFTSxhQUFhLEVBQUU7Z0JBQU0sQ0FBQyxDQUFDO2dCQUM1RDZCLEtBQUssQ0FBQyxtQ0FBbUMsRUFBRSxNQUFNLEVBQUU7a0JBQUVjLFNBQVMsRUFBRTtnQkFBZSxDQUFDLENBQUM7Y0FDbkY7WUFDRjtVQUNGLENBQUMsTUFBTSxJQUFJdUUsT0FBTyxDQUFDeEIsSUFBSSxDQUFFc0ksQ0FBQyxJQUFNb0UsR0FBRyxDQUFDM0ksT0FBTyxHQUFHdUUsQ0FBQyxDQUFDdFIsRUFBRSxLQUFLMFYsR0FBRyxDQUFDM0ksT0FBTyxHQUFHdUUsQ0FBQyxDQUFDekQsSUFBSSxLQUFLNkgsR0FBRyxDQUFDM1csSUFBSyxDQUFDLEVBQUU7WUFDMUYyRyxRQUFRLENBQUN2QixPQUFPLEdBQUcsSUFBSTtZQUN2QmdCLEtBQUssQ0FBQywyQkFBMkIsRUFBRSxPQUFPLEVBQUU7Y0FBRWMsU0FBUyxFQUFFO1lBQWUsQ0FBQyxDQUFDO1VBQzVFO1FBQ0YsQ0FBQyxDQUFDO01BQ0osQ0FBQyxDQUFDLE1BQU07UUFDTjtNQUFBO0lBRUosQ0FBQyxFQUFFLENBQUM7SUFDSixPQUFPLE1BQU07TUFDWHlPLFNBQVMsR0FBRyxJQUFJO01BQ2hCQyxLQUFLLEdBQUcsQ0FBQztNQUNULEtBQUssTUFBTW5NLENBQUMsSUFBSW9NLE1BQU0sQ0FBQ2dCLE1BQU0sQ0FBQyxDQUFDLEVBQUVqUCxZQUFZLENBQUM2QixDQUFDLENBQUM7TUFDaERvTSxNQUFNLENBQUNpQixLQUFLLENBQUMsQ0FBQztNQUNkLElBQUlyVSxTQUFTLENBQUMyQyxPQUFPLEVBQUV3QyxZQUFZLENBQUNuRixTQUFTLENBQUMyQyxPQUFPLENBQUM7TUFDdEQzQyxTQUFTLENBQUMyQyxPQUFPLEdBQUcsSUFBSTtJQUMxQixDQUFDO0lBQ0Q7SUFDQTtFQUNGLENBQUMsRUFBRSxFQUFFLENBQUM7RUFFTixPQUFPO0lBQ0x2QyxLQUFLO0lBQ0xWLGNBQWM7SUFDZDRVLFNBQVMsRUFBRXBRLFFBQVEsQ0FBQ3ZCLE9BQU8sRUFBRXBGLElBQUksSUFBSSxJQUFJO0lBQ3pDd0YsUUFBUTtJQUNSO0lBQ0F3UixPQUFPLEVBQUd4VyxFQUFVLElBQUssSUFBQXdXLGVBQU8sRUFBQ25VLEtBQUssQ0FBQ1EsR0FBRyxFQUFFN0MsRUFBRSxDQUFDO0lBQy9DeVcsT0FBTyxFQUFHdFcsRUFBVSxJQUFLLElBQUFzVyxlQUFPLEVBQUNwVSxLQUFLLENBQUNRLEdBQUcsRUFBRTFDLEVBQUUsQ0FBQztJQUMvQ3VXLE9BQU8sRUFBRUEsQ0FBQ25MLEVBQVUsRUFBRUMsRUFBVSxLQUFLLElBQUFrTCxlQUFPLEVBQUNyVSxLQUFLLENBQUNRLEdBQUcsRUFBRVIsS0FBSyxDQUFDWSxFQUFFLEVBQUVzSSxFQUFFLEVBQUVDLEVBQUUsQ0FBQztJQUN6RXBHLE9BQU87SUFDUHVSLFNBQVMsRUFBVEEsaUJBQVM7SUFDVGhQLEtBQUs7SUFDTGlQLFdBQVcsRUFBWEEscUJBQVc7SUFDWDtJQUNBbkgsWUFBWTtJQUNaOEIsZ0JBQWdCO0lBQ2hCckIsY0FBYztJQUNkTSxXQUFXO0lBQ1hDLFlBQVk7SUFDWkUsUUFBUTtJQUNSQyxjQUFjO0lBQ2Q5RixNQUFNO0lBQ05DLGNBQWM7SUFDZDtJQUNBZ0UsWUFBWTtJQUNaSyxVQUFVO0lBQ1ZFLGlCQUFpQjtJQUNqQjtJQUNBekUsUUFBUTtJQUNSMEQsV0FBVztJQUNYdkQsZUFBZTtJQUNmSyxZQUFZO0lBQ1o7SUFDQWMsV0FBVztJQUNYOEIsU0FBUztJQUNUTixXQUFXO0lBQ1hPLFFBQVE7SUFDUk4sVUFBVTtJQUNWUCxXQUFXO0lBQ1hjLFFBQVE7SUFDUjtJQUNBakYsUUFBUTtJQUNSSyxVQUFVO0lBQ1ZHLGNBQWM7SUFDZGIsV0FBVztJQUNYd0IsV0FBVztJQUNYRSxRQUFRO0lBQ1JHLFFBQVE7SUFDUkosUUFBUTtJQUNSTSxRQUFRO0lBQ1I7SUFDQWlHLE1BQU07SUFDTkMsT0FBTztJQUNQQyxXQUFXO0lBQ1hDLFdBQVc7SUFDWEksY0FBYztJQUNkQyxVQUFVO0lBQ1ZILGFBQWE7SUFDYkMsUUFBUTtJQUNSRixTQUFTO0lBQ1RLLGNBQWM7SUFDZDtJQUNBMUwsS0FBSztJQUNMRixZQUFZO0lBQ1orTCxPQUFPO0lBQ1BDO0VBQ0YsQ0FBQztBQUNIIiwiaWdub3JlTGlzdCI6W119