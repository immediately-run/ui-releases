var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _StickyNote = _interopRequireDefault(require("./library/StickyNote"));
var _ProseCard = _interopRequireDefault(require("./library/ProseCard"));
var _CanvasLabel = _interopRequireDefault(require("./library/CanvasLabel"));
var _CanvasFrame = _interopRequireDefault(require("./library/CanvasFrame"));
var _ShapeObject = _interopRequireDefault(require("./library/ShapeObject"));
var _ImageObject = _interopRequireDefault(require("./library/ImageObject"));
var _VideoObject = _interopRequireDefault(require("./library/VideoObject"));
var _EmbedObject = _interopRequireDefault(require("./library/EmbedObject"));
var _ComponentError = _interopRequireDefault(require("./library/ComponentError"));
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// Dispatches an object to its built-in library component by `kind`. This is the
// seam where, once the V1 MDX-from-mount gate is settled (spec §3.2), the body
// becomes the compiled MDX of `objects/<id>.mdx` with the library injected into
// scope — the kinds below stay as the presentation hints and fallbacks.

function ObjectBody({
  o,
  boardRoot,
  objects
}) {
  switch (o.kind) {
    case 'note':
      return /*#__PURE__*/(0, _jsxRuntime.jsx)(_StickyNote.default, {
        o: o,
        objects: objects
      });
    case 'prose':
      return /*#__PURE__*/(0, _jsxRuntime.jsx)(_ProseCard.default, {
        o: o
      });
    case 'label':
      return /*#__PURE__*/(0, _jsxRuntime.jsx)(_CanvasLabel.default, {
        o: o
      });
    case 'frame':
      return /*#__PURE__*/(0, _jsxRuntime.jsx)(_CanvasFrame.default, {
        o: o
      });
    case 'shape':
      return /*#__PURE__*/(0, _jsxRuntime.jsx)(_ShapeObject.default, {
        o: o
      });
    case 'img':
      return /*#__PURE__*/(0, _jsxRuntime.jsx)(_ImageObject.default, {
        o: o,
        boardRoot: boardRoot
      });
    case 'video':
      return /*#__PURE__*/(0, _jsxRuntime.jsx)(_VideoObject.default, {
        o: o
      });
    case 'embed':
      return /*#__PURE__*/(0, _jsxRuntime.jsx)(_EmbedObject.default, {
        o: o
      });
    case 'component':
      return /*#__PURE__*/(0, _jsxRuntime.jsx)(_ComponentError.default, {
        o: o
      });
    default:
      return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        style: {
          position: 'absolute',
          inset: 0,
          background: 'var(--panel)',
          border: '1px solid var(--line)',
          borderRadius: 12
        }
      });
  }
}
_c = ObjectBody;
var _default = exports.default = ObjectBody;
var _c;
$RefreshReg$(_c, "ObjectBody");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfU3RpY2t5Tm90ZSIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJyZXF1aXJlIiwiX1Byb3NlQ2FyZCIsIl9DYW52YXNMYWJlbCIsIl9DYW52YXNGcmFtZSIsIl9TaGFwZU9iamVjdCIsIl9JbWFnZU9iamVjdCIsIl9WaWRlb09iamVjdCIsIl9FbWJlZE9iamVjdCIsIl9Db21wb25lbnRFcnJvciIsIl9qc3hSdW50aW1lIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiT2JqZWN0Qm9keSIsIm8iLCJib2FyZFJvb3QiLCJvYmplY3RzIiwia2luZCIsImpzeCIsInN0eWxlIiwicG9zaXRpb24iLCJpbnNldCIsImJhY2tncm91bmQiLCJib3JkZXIiLCJib3JkZXJSYWRpdXMiLCJfYyIsIl9kZWZhdWx0IiwiZXhwb3J0cyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIk9iamVjdEJvZHkudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIERpc3BhdGNoZXMgYW4gb2JqZWN0IHRvIGl0cyBidWlsdC1pbiBsaWJyYXJ5IGNvbXBvbmVudCBieSBga2luZGAuIFRoaXMgaXMgdGhlXG4vLyBzZWFtIHdoZXJlLCBvbmNlIHRoZSBWMSBNRFgtZnJvbS1tb3VudCBnYXRlIGlzIHNldHRsZWQgKHNwZWMgwqczLjIpLCB0aGUgYm9keVxuLy8gYmVjb21lcyB0aGUgY29tcGlsZWQgTURYIG9mIGBvYmplY3RzLzxpZD4ubWR4YCB3aXRoIHRoZSBsaWJyYXJ5IGluamVjdGVkIGludG9cbi8vIHNjb3BlIOKAlCB0aGUga2luZHMgYmVsb3cgc3RheSBhcyB0aGUgcHJlc2VudGF0aW9uIGhpbnRzIGFuZCBmYWxsYmFja3MuXG5cbmltcG9ydCBTdGlja3lOb3RlIGZyb20gJy4vbGlicmFyeS9TdGlja3lOb3RlJztcbmltcG9ydCBQcm9zZUNhcmQgZnJvbSAnLi9saWJyYXJ5L1Byb3NlQ2FyZCc7XG5pbXBvcnQgQ2FudmFzTGFiZWwgZnJvbSAnLi9saWJyYXJ5L0NhbnZhc0xhYmVsJztcbmltcG9ydCBDYW52YXNGcmFtZSBmcm9tICcuL2xpYnJhcnkvQ2FudmFzRnJhbWUnO1xuaW1wb3J0IFNoYXBlT2JqZWN0IGZyb20gJy4vbGlicmFyeS9TaGFwZU9iamVjdCc7XG5pbXBvcnQgSW1hZ2VPYmplY3QgZnJvbSAnLi9saWJyYXJ5L0ltYWdlT2JqZWN0JztcbmltcG9ydCBWaWRlb09iamVjdCBmcm9tICcuL2xpYnJhcnkvVmlkZW9PYmplY3QnO1xuaW1wb3J0IEVtYmVkT2JqZWN0IGZyb20gJy4vbGlicmFyeS9FbWJlZE9iamVjdCc7XG5pbXBvcnQgQ29tcG9uZW50RXJyb3IgZnJvbSAnLi9saWJyYXJ5L0NvbXBvbmVudEVycm9yJztcbmltcG9ydCB0eXBlIHsgV09iamVjdCB9IGZyb20gJy4uL2xpYi90eXBlcyc7XG5cbmZ1bmN0aW9uIE9iamVjdEJvZHkoeyBvLCBib2FyZFJvb3QsIG9iamVjdHMgfTogeyBvOiBXT2JqZWN0OyBib2FyZFJvb3Q6IHN0cmluZyB8IG51bGw7IG9iamVjdHM6IFdPYmplY3RbXSB9KSB7XG4gIHN3aXRjaCAoby5raW5kKSB7XG4gICAgY2FzZSAnbm90ZSc6XG4gICAgICByZXR1cm4gPFN0aWNreU5vdGUgbz17b30gb2JqZWN0cz17b2JqZWN0c30gLz47XG4gICAgY2FzZSAncHJvc2UnOlxuICAgICAgcmV0dXJuIDxQcm9zZUNhcmQgbz17b30gLz47XG4gICAgY2FzZSAnbGFiZWwnOlxuICAgICAgcmV0dXJuIDxDYW52YXNMYWJlbCBvPXtvfSAvPjtcbiAgICBjYXNlICdmcmFtZSc6XG4gICAgICByZXR1cm4gPENhbnZhc0ZyYW1lIG89e299IC8+O1xuICAgIGNhc2UgJ3NoYXBlJzpcbiAgICAgIHJldHVybiA8U2hhcGVPYmplY3Qgbz17b30gLz47XG4gICAgY2FzZSAnaW1nJzpcbiAgICAgIHJldHVybiA8SW1hZ2VPYmplY3Qgbz17b30gYm9hcmRSb290PXtib2FyZFJvb3R9IC8+O1xuICAgIGNhc2UgJ3ZpZGVvJzpcbiAgICAgIHJldHVybiA8VmlkZW9PYmplY3Qgbz17b30gLz47XG4gICAgY2FzZSAnZW1iZWQnOlxuICAgICAgcmV0dXJuIDxFbWJlZE9iamVjdCBvPXtvfSAvPjtcbiAgICBjYXNlICdjb21wb25lbnQnOlxuICAgICAgcmV0dXJuIDxDb21wb25lbnRFcnJvciBvPXtvfSAvPjtcbiAgICBkZWZhdWx0OlxuICAgICAgcmV0dXJuIDxkaXYgc3R5bGU9e3sgcG9zaXRpb246ICdhYnNvbHV0ZScsIGluc2V0OiAwLCBiYWNrZ3JvdW5kOiAndmFyKC0tcGFuZWwpJywgYm9yZGVyOiAnMXB4IHNvbGlkIHZhcigtLWxpbmUpJywgYm9yZGVyUmFkaXVzOiAxMiB9fSAvPjtcbiAgfVxufVxuXG5leHBvcnQgZGVmYXVsdCBPYmplY3RCb2R5O1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFLQSxJQUFBQSxXQUFBLEdBQUFDLHNCQUFBLENBQUFDLE9BQUE7QUFDQSxJQUFBQyxVQUFBLEdBQUFGLHNCQUFBLENBQUFDLE9BQUE7QUFDQSxJQUFBRSxZQUFBLEdBQUFILHNCQUFBLENBQUFDLE9BQUE7QUFDQSxJQUFBRyxZQUFBLEdBQUFKLHNCQUFBLENBQUFDLE9BQUE7QUFDQSxJQUFBSSxZQUFBLEdBQUFMLHNCQUFBLENBQUFDLE9BQUE7QUFDQSxJQUFBSyxZQUFBLEdBQUFOLHNCQUFBLENBQUFDLE9BQUE7QUFDQSxJQUFBTSxZQUFBLEdBQUFQLHNCQUFBLENBQUFDLE9BQUE7QUFDQSxJQUFBTyxZQUFBLEdBQUFSLHNCQUFBLENBQUFDLE9BQUE7QUFDQSxJQUFBUSxlQUFBLEdBQUFULHNCQUFBLENBQUFDLE9BQUE7QUFBc0QsSUFBQVMsV0FBQSxHQUFBVCxPQUFBO0FBQUEsU0FBQUQsdUJBQUFXLENBQUEsV0FBQUEsQ0FBQSxJQUFBQSxDQUFBLENBQUFDLFVBQUEsR0FBQUQsQ0FBQSxLQUFBRSxPQUFBLEVBQUFGLENBQUE7QUFidEQ7QUFDQTtBQUNBO0FBQ0E7O0FBYUEsU0FBU0csVUFBVUEsQ0FBQztFQUFFQyxDQUFDO0VBQUVDLFNBQVM7RUFBRUM7QUFBc0UsQ0FBQyxFQUFFO0VBQzNHLFFBQVFGLENBQUMsQ0FBQ0csSUFBSTtJQUNaLEtBQUssTUFBTTtNQUNULG9CQUFPLElBQUFSLFdBQUEsQ0FBQVMsR0FBQSxFQUFDcEIsV0FBQSxDQUFBYyxPQUFVO1FBQUNFLENBQUMsRUFBRUEsQ0FBRTtRQUFDRSxPQUFPLEVBQUVBO01BQVEsQ0FBRSxDQUFDO0lBQy9DLEtBQUssT0FBTztNQUNWLG9CQUFPLElBQUFQLFdBQUEsQ0FBQVMsR0FBQSxFQUFDakIsVUFBQSxDQUFBVyxPQUFTO1FBQUNFLENBQUMsRUFBRUE7TUFBRSxDQUFFLENBQUM7SUFDNUIsS0FBSyxPQUFPO01BQ1Ysb0JBQU8sSUFBQUwsV0FBQSxDQUFBUyxHQUFBLEVBQUNoQixZQUFBLENBQUFVLE9BQVc7UUFBQ0UsQ0FBQyxFQUFFQTtNQUFFLENBQUUsQ0FBQztJQUM5QixLQUFLLE9BQU87TUFDVixvQkFBTyxJQUFBTCxXQUFBLENBQUFTLEdBQUEsRUFBQ2YsWUFBQSxDQUFBUyxPQUFXO1FBQUNFLENBQUMsRUFBRUE7TUFBRSxDQUFFLENBQUM7SUFDOUIsS0FBSyxPQUFPO01BQ1Ysb0JBQU8sSUFBQUwsV0FBQSxDQUFBUyxHQUFBLEVBQUNkLFlBQUEsQ0FBQVEsT0FBVztRQUFDRSxDQUFDLEVBQUVBO01BQUUsQ0FBRSxDQUFDO0lBQzlCLEtBQUssS0FBSztNQUNSLG9CQUFPLElBQUFMLFdBQUEsQ0FBQVMsR0FBQSxFQUFDYixZQUFBLENBQUFPLE9BQVc7UUFBQ0UsQ0FBQyxFQUFFQSxDQUFFO1FBQUNDLFNBQVMsRUFBRUE7TUFBVSxDQUFFLENBQUM7SUFDcEQsS0FBSyxPQUFPO01BQ1Ysb0JBQU8sSUFBQU4sV0FBQSxDQUFBUyxHQUFBLEVBQUNaLFlBQUEsQ0FBQU0sT0FBVztRQUFDRSxDQUFDLEVBQUVBO01BQUUsQ0FBRSxDQUFDO0lBQzlCLEtBQUssT0FBTztNQUNWLG9CQUFPLElBQUFMLFdBQUEsQ0FBQVMsR0FBQSxFQUFDWCxZQUFBLENBQUFLLE9BQVc7UUFBQ0UsQ0FBQyxFQUFFQTtNQUFFLENBQUUsQ0FBQztJQUM5QixLQUFLLFdBQVc7TUFDZCxvQkFBTyxJQUFBTCxXQUFBLENBQUFTLEdBQUEsRUFBQ1YsZUFBQSxDQUFBSSxPQUFjO1FBQUNFLENBQUMsRUFBRUE7TUFBRSxDQUFFLENBQUM7SUFDakM7TUFDRSxvQkFBTyxJQUFBTCxXQUFBLENBQUFTLEdBQUE7UUFBS0MsS0FBSyxFQUFFO1VBQUVDLFFBQVEsRUFBRSxVQUFVO1VBQUVDLEtBQUssRUFBRSxDQUFDO1VBQUVDLFVBQVUsRUFBRSxjQUFjO1VBQUVDLE1BQU0sRUFBRSx1QkFBdUI7VUFBRUMsWUFBWSxFQUFFO1FBQUc7TUFBRSxDQUFFLENBQUM7RUFDNUk7QUFDRjtBQUFDQyxFQUFBLEdBdkJRWixVQUFVO0FBQUEsSUFBQWEsUUFBQSxHQUFBQyxPQUFBLENBQUFmLE9BQUEsR0F5QkpDLFVBQVU7QUFBQSxJQUFBWSxFQUFBO0FBQUFHLFlBQUEsQ0FBQUgsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}