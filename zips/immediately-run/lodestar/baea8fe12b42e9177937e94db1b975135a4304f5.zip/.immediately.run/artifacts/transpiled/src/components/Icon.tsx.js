var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _iconPaths = require("../data/iconPaths");
var _jsxRuntime = require("react/jsx-runtime");
// A single inline Lucide icon. Strokes use currentColor by default so icons take
// the color of their surrounding text. Path data lives in `data/iconPaths.ts`.

function Icon({
  name,
  size = 18,
  color = 'currentColor',
  strokeWidth = 1.75
}) {
  const d = _iconPaths.iconPaths[name] ?? '';
  return /*#__PURE__*/(0, _jsxRuntime.jsx)("svg", {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: color,
    strokeWidth: strokeWidth,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: {
      display: 'block',
      flex: 'none'
    },
    dangerouslySetInnerHTML: {
      __html: d
    }
  });
}
_c = Icon;
var _default = exports.default = Icon;
var _c;
$RefreshReg$(_c, "Icon");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfaWNvblBhdGhzIiwicmVxdWlyZSIsIl9qc3hSdW50aW1lIiwiSWNvbiIsIm5hbWUiLCJzaXplIiwiY29sb3IiLCJzdHJva2VXaWR0aCIsImQiLCJpY29uUGF0aHMiLCJqc3giLCJ3aWR0aCIsImhlaWdodCIsInZpZXdCb3giLCJmaWxsIiwic3Ryb2tlIiwic3Ryb2tlTGluZWNhcCIsInN0cm9rZUxpbmVqb2luIiwic3R5bGUiLCJkaXNwbGF5IiwiZmxleCIsImRhbmdlcm91c2x5U2V0SW5uZXJIVE1MIiwiX19odG1sIiwiX2MiLCJfZGVmYXVsdCIsImV4cG9ydHMiLCJkZWZhdWx0IiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiSWNvbi50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gQSBzaW5nbGUgaW5saW5lIEx1Y2lkZSBpY29uLiBTdHJva2VzIHVzZSBjdXJyZW50Q29sb3IgYnkgZGVmYXVsdCBzbyBpY29ucyB0YWtlXG4vLyB0aGUgY29sb3Igb2YgdGhlaXIgc3Vycm91bmRpbmcgdGV4dC4gUGF0aCBkYXRhIGxpdmVzIGluIGBkYXRhL2ljb25QYXRocy50c2AuXG5cbmltcG9ydCB7IGljb25QYXRocyB9IGZyb20gJy4uL2RhdGEvaWNvblBhdGhzJztcblxuaW50ZXJmYWNlIEljb25Qcm9wcyB7XG4gIG5hbWU6IGtleW9mIHR5cGVvZiBpY29uUGF0aHMgfCBzdHJpbmc7XG4gIHNpemU/OiBudW1iZXI7XG4gIGNvbG9yPzogc3RyaW5nO1xuICBzdHJva2VXaWR0aD86IG51bWJlcjtcbn1cblxuZnVuY3Rpb24gSWNvbih7IG5hbWUsIHNpemUgPSAxOCwgY29sb3IgPSAnY3VycmVudENvbG9yJywgc3Ryb2tlV2lkdGggPSAxLjc1IH06IEljb25Qcm9wcykge1xuICBjb25zdCBkID0gaWNvblBhdGhzW25hbWVdID8/ICcnO1xuICByZXR1cm4gKFxuICAgIDxzdmdcbiAgICAgIHdpZHRoPXtzaXplfVxuICAgICAgaGVpZ2h0PXtzaXplfVxuICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXG4gICAgICBmaWxsPVwibm9uZVwiXG4gICAgICBzdHJva2U9e2NvbG9yfVxuICAgICAgc3Ryb2tlV2lkdGg9e3N0cm9rZVdpZHRofVxuICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcbiAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxuICAgICAgc3R5bGU9e3sgZGlzcGxheTogJ2Jsb2NrJywgZmxleDogJ25vbmUnIH19XG4gICAgICBkYW5nZXJvdXNseVNldElubmVySFRNTD17eyBfX2h0bWw6IGQgfX1cbiAgICAvPlxuICApO1xufVxuXG5leHBvcnQgZGVmYXVsdCBJY29uO1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFHQSxJQUFBQSxVQUFBLEdBQUFDLE9BQUE7QUFBOEMsSUFBQUMsV0FBQSxHQUFBRCxPQUFBO0FBSDlDO0FBQ0E7O0FBV0EsU0FBU0UsSUFBSUEsQ0FBQztFQUFFQyxJQUFJO0VBQUVDLElBQUksR0FBRyxFQUFFO0VBQUVDLEtBQUssR0FBRyxjQUFjO0VBQUVDLFdBQVcsR0FBRztBQUFnQixDQUFDLEVBQUU7RUFDeEYsTUFBTUMsQ0FBQyxHQUFHQyxvQkFBUyxDQUFDTCxJQUFJLENBQUMsSUFBSSxFQUFFO0VBQy9CLG9CQUNFLElBQUFGLFdBQUEsQ0FBQVEsR0FBQTtJQUNFQyxLQUFLLEVBQUVOLElBQUs7SUFDWk8sTUFBTSxFQUFFUCxJQUFLO0lBQ2JRLE9BQU8sRUFBQyxXQUFXO0lBQ25CQyxJQUFJLEVBQUMsTUFBTTtJQUNYQyxNQUFNLEVBQUVULEtBQU07SUFDZEMsV0FBVyxFQUFFQSxXQUFZO0lBQ3pCUyxhQUFhLEVBQUMsT0FBTztJQUNyQkMsY0FBYyxFQUFDLE9BQU87SUFDdEJDLEtBQUssRUFBRTtNQUFFQyxPQUFPLEVBQUUsT0FBTztNQUFFQyxJQUFJLEVBQUU7SUFBTyxDQUFFO0lBQzFDQyx1QkFBdUIsRUFBRTtNQUFFQyxNQUFNLEVBQUVkO0lBQUU7RUFBRSxDQUN4QyxDQUFDO0FBRU47QUFBQ2UsRUFBQSxHQWhCUXBCLElBQUk7QUFBQSxJQUFBcUIsUUFBQSxHQUFBQyxPQUFBLENBQUFDLE9BQUEsR0FrQkV2QixJQUFJO0FBQUEsSUFBQW9CLEVBQUE7QUFBQUksWUFBQSxDQUFBSixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}