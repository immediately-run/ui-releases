var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _useLodestarCtx = require("../hooks/useLodestarCtx");
var _useLodestar = require("../hooks/useLodestar");
var _useOverlayDialog = require("../hooks/useOverlayDialog");
var _BoardChooser = _interopRequireDefault(require("./BoardChooser"));
var _Icon = _interopRequireDefault(require("./Icon"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The designed empty/forbidden states (spec §6.1, DESIGN_BRIEF §3): empty board
// (invites the first note), no board selected, signed out, and the "not a board"
// retry after picking a folder with no board.md. The chooser is its own modal.
// These never imitate host chrome — sign-in itself is host-driven (the copy says
// so); this only frames the app-side states around it.
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function StateScreens() {
  _s();
  const wb = (0, _useLodestarCtx.useWb)();
  const screen = wb.state.screen;
  const closeScreen = () => wb.setScreen(null);
  // The dialog contract (R3-607): focus in, Tab trapped, Escape, focus return.
  // The chooser screen delegates to BoardChooser, which carries its own.
  const dialogRef = (0, _useOverlayDialog.useOverlayDialog)(!!screen && screen !== 'chooser', closeScreen);
  if (!screen) return null;
  if (screen === 'chooser') return /*#__PURE__*/(0, _jsxRuntime.jsx)(_BoardChooser.default, {});
  const close = () => wb.setScreen(null);
  const emptyArt = (icon, size, amber = false) => /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
    style: {
      width: 88,
      height: 88,
      borderRadius: 24,
      background: amber ? 'color-mix(in oklab, #caa24a 16%, var(--panel))' : 'color-mix(in oklab, var(--accent-2) 14%, var(--panel))',
      border: `1px solid ${amber ? 'color-mix(in oklab, #caa24a 40%, var(--line))' : 'var(--line-2)'}`,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: amber ? '#caa24a' : 'var(--accent-violet)',
      marginBottom: 6
    },
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
      name: icon,
      size: size,
      strokeWidth: 1.5
    })
  });

  // `key` is required because the same helper renders sibling buttons in an array.
  // `busyFor` (when given) names the flow this button starts: while it runs the
  // button shows the named busy label with aria-busy, and NO close-first — the
  // surface that names the wait must survive the wait (R-IX-2); the flow itself
  // closes the screen on success.
  const primary = (key, label, icon, onClick = close, busyFlow) => {
    const busy = busyFlow !== undefined && wb.state.busy === busyFlow;
    return /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
      "aria-busy": busy || undefined,
      disabled: busy,
      onClick: onClick,
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        padding: '12px 20px',
        background: 'var(--grad)',
        border: 'none',
        borderRadius: 'var(--r-pill)',
        color: '#1a1020',
        font: 'var(--label)',
        cursor: busy ? 'default' : 'pointer',
        boxShadow: 'var(--glow)',
        whiteSpace: 'nowrap'
      },
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
        name: icon,
        size: 16,
        color: "#1a1020",
        strokeWidth: icon === 'chevRight' || icon === 'plusBig' ? 2 : 1.75
      }), busy ? _useLodestar.BUSY_LABELS[busyFlow] : label]
    }, key);
  };
  const secondary = (key, label, onClick = close, busyFlow) => {
    const busy = busyFlow !== undefined && wb.state.busy === busyFlow;
    return /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
      "aria-busy": busy || undefined,
      disabled: busy,
      onClick: onClick,
      style: {
        padding: '12px 20px',
        background: 'var(--bg)',
        border: '1px solid var(--line-2)',
        borderRadius: 'var(--r-pill)',
        color: 'var(--ink)',
        font: 'var(--label)',
        cursor: busy ? 'default' : 'pointer',
        whiteSpace: 'nowrap'
      },
      children: busy ? _useLodestar.BUSY_LABELS[busyFlow] : label
    }, key);
  };
  // An instant action closes its screen first (nothing is awaited); a pick
  // flow does NOT — its named busy renders on the button that started it, and
  // the flow closes the screen on success (R-IX-2).
  const instant = fn => () => {
    close();
    fn();
  };
  const flow = fn => () => {
    fn();
  };
  const content = {
    empty: {
      art: emptyArt('sticky', 40),
      title: 'An empty board.',
      body: 'Double-click anywhere to drop your first note — or pick an image. Every object you add becomes one file in this folder.',
      actions: [primary('add-note', 'Add a note', 'plusBig', instant(() => wb.createObject('note', wb.state.cam.cx, wb.state.cam.cy))), secondary('insert-image', 'Insert image…', flow(() => wb.insertImage(0, 0)), 'insert-image')]
    },
    noboard: {
      art: emptyArt('inbox', 38),
      title: 'No board selected.',
      body: 'Choose a board to open, or start a new one. Your boards live across your team spaces.',
      actions: [primary('open-board', 'Open a board…', 'folder', flow(wb.openBoard), 'open-board')]
    },
    signedout: {
      art: emptyArt('lock', 34),
      title: 'Sign in to load your boards.',
      body: 'Boards live in a shared space. Signing in is handled by immediately.run — this app never asks for credentials itself.',
      actions: [primary('continue', 'Continue', 'chevRight')]
    },
    notaboard: {
      art: emptyArt('alert', 38, true),
      title: 'Not a board.',
      body: 'That folder has no board.md, so there is nothing to render. Pick a different folder, or create a board here.',
      actions: [primary('create-board', 'Create board here…', 'plusBig', flow(wb.newBoard), 'new-board'), secondary('pick-another', 'Pick another…', flow(wb.openBoard), 'open-board')]
    }
  };
  const c = content[screen];
  if (!c) return null;
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    style: {
      position: 'absolute',
      inset: 0,
      zIndex: 70,
      background: 'color-mix(in oklab, var(--bg) 92%, transparent)',
      backdropFilter: 'blur(8px)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 24
    },
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
      onClick: closeScreen,
      "aria-label": "Close",
      style: {
        position: 'absolute',
        top: 18,
        right: 18,
        display: 'flex',
        padding: 9,
        background: 'var(--panel)',
        border: '1px solid var(--line)',
        borderRadius: '50%',
        color: 'var(--ink-2)',
        cursor: 'pointer'
      },
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
        name: "x",
        size: 18
      })
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      ref: dialogRef,
      tabIndex: -1,
      style: {
        width: 'min(460px, 94vw)',
        textAlign: 'center',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 16
      },
      children: [c.art, /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        style: {
          font: '800 30px/1 var(--disp)',
          letterSpacing: '-.03em'
        },
        children: c.title
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        style: {
          font: 'var(--body)',
          color: 'var(--ink-2)',
          maxWidth: 380,
          textWrap: 'pretty'
        },
        children: c.body
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        style: {
          display: 'flex',
          gap: 10,
          marginTop: 4
        },
        children: c.actions
      })]
    })]
  });
}
_s(StateScreens, "pMhplSnczCcvKhkacNYLU2e8wl4=", false, function () {
  return [_useLodestarCtx.useWb, _useOverlayDialog.useOverlayDialog];
});
_c = StateScreens;
var _default = exports.default = StateScreens;
var _c;
$RefreshReg$(_c, "StateScreens");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdXNlTG9kZXN0YXJDdHgiLCJyZXF1aXJlIiwiX3VzZUxvZGVzdGFyIiwiX3VzZU92ZXJsYXlEaWFsb2ciLCJfQm9hcmRDaG9vc2VyIiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsIl9JY29uIiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsIlN0YXRlU2NyZWVucyIsIndiIiwidXNlV2IiLCJzY3JlZW4iLCJzdGF0ZSIsImNsb3NlU2NyZWVuIiwic2V0U2NyZWVuIiwiZGlhbG9nUmVmIiwidXNlT3ZlcmxheURpYWxvZyIsImpzeCIsImNsb3NlIiwiZW1wdHlBcnQiLCJpY29uIiwic2l6ZSIsImFtYmVyIiwic3R5bGUiLCJ3aWR0aCIsImhlaWdodCIsImJvcmRlclJhZGl1cyIsImJhY2tncm91bmQiLCJib3JkZXIiLCJkaXNwbGF5IiwiYWxpZ25JdGVtcyIsImp1c3RpZnlDb250ZW50IiwiY29sb3IiLCJtYXJnaW5Cb3R0b20iLCJjaGlsZHJlbiIsIm5hbWUiLCJzdHJva2VXaWR0aCIsInByaW1hcnkiLCJrZXkiLCJsYWJlbCIsIm9uQ2xpY2siLCJidXN5RmxvdyIsImJ1c3kiLCJ1bmRlZmluZWQiLCJqc3hzIiwiZGlzYWJsZWQiLCJnYXAiLCJwYWRkaW5nIiwiZm9udCIsImN1cnNvciIsImJveFNoYWRvdyIsIndoaXRlU3BhY2UiLCJCVVNZX0xBQkVMUyIsInNlY29uZGFyeSIsImluc3RhbnQiLCJmbiIsImZsb3ciLCJjb250ZW50IiwiZW1wdHkiLCJhcnQiLCJ0aXRsZSIsImJvZHkiLCJhY3Rpb25zIiwiY3JlYXRlT2JqZWN0IiwiY2FtIiwiY3giLCJjeSIsImluc2VydEltYWdlIiwibm9ib2FyZCIsIm9wZW5Cb2FyZCIsInNpZ25lZG91dCIsIm5vdGFib2FyZCIsIm5ld0JvYXJkIiwiYyIsInBvc2l0aW9uIiwiaW5zZXQiLCJ6SW5kZXgiLCJiYWNrZHJvcEZpbHRlciIsInRvcCIsInJpZ2h0IiwicmVmIiwidGFiSW5kZXgiLCJ0ZXh0QWxpZ24iLCJmbGV4RGlyZWN0aW9uIiwibGV0dGVyU3BhY2luZyIsIm1heFdpZHRoIiwidGV4dFdyYXAiLCJtYXJnaW5Ub3AiLCJfYyIsIl9kZWZhdWx0IiwiZXhwb3J0cyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlN0YXRlU2NyZWVucy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gVGhlIGRlc2lnbmVkIGVtcHR5L2ZvcmJpZGRlbiBzdGF0ZXMgKHNwZWMgwqc2LjEsIERFU0lHTl9CUklFRiDCpzMpOiBlbXB0eSBib2FyZFxuLy8gKGludml0ZXMgdGhlIGZpcnN0IG5vdGUpLCBubyBib2FyZCBzZWxlY3RlZCwgc2lnbmVkIG91dCwgYW5kIHRoZSBcIm5vdCBhIGJvYXJkXCJcbi8vIHJldHJ5IGFmdGVyIHBpY2tpbmcgYSBmb2xkZXIgd2l0aCBubyBib2FyZC5tZC4gVGhlIGNob29zZXIgaXMgaXRzIG93biBtb2RhbC5cbi8vIFRoZXNlIG5ldmVyIGltaXRhdGUgaG9zdCBjaHJvbWUg4oCUIHNpZ24taW4gaXRzZWxmIGlzIGhvc3QtZHJpdmVuICh0aGUgY29weSBzYXlzXG4vLyBzbyk7IHRoaXMgb25seSBmcmFtZXMgdGhlIGFwcC1zaWRlIHN0YXRlcyBhcm91bmQgaXQuXG5cbmltcG9ydCB7IHVzZVdiIH0gZnJvbSAnLi4vaG9va3MvdXNlTG9kZXN0YXJDdHgnO1xuaW1wb3J0IHsgQlVTWV9MQUJFTFMgfSBmcm9tICcuLi9ob29rcy91c2VMb2Rlc3Rhcic7XG5pbXBvcnQgeyB1c2VPdmVybGF5RGlhbG9nIH0gZnJvbSAnLi4vaG9va3MvdXNlT3ZlcmxheURpYWxvZyc7XG5pbXBvcnQgQm9hcmRDaG9vc2VyIGZyb20gJy4vQm9hcmRDaG9vc2VyJztcbmltcG9ydCBJY29uIGZyb20gJy4vSWNvbic7XG5cbmZ1bmN0aW9uIFN0YXRlU2NyZWVucygpIHtcbiAgY29uc3Qgd2IgPSB1c2VXYigpO1xuICBjb25zdCBzY3JlZW4gPSB3Yi5zdGF0ZS5zY3JlZW47XG4gIGNvbnN0IGNsb3NlU2NyZWVuID0gKCkgPT4gd2Iuc2V0U2NyZWVuKG51bGwpO1xuICAvLyBUaGUgZGlhbG9nIGNvbnRyYWN0IChSMy02MDcpOiBmb2N1cyBpbiwgVGFiIHRyYXBwZWQsIEVzY2FwZSwgZm9jdXMgcmV0dXJuLlxuICAvLyBUaGUgY2hvb3NlciBzY3JlZW4gZGVsZWdhdGVzIHRvIEJvYXJkQ2hvb3Nlciwgd2hpY2ggY2FycmllcyBpdHMgb3duLlxuICBjb25zdCBkaWFsb2dSZWYgPSB1c2VPdmVybGF5RGlhbG9nKCEhc2NyZWVuICYmIHNjcmVlbiAhPT0gJ2Nob29zZXInLCBjbG9zZVNjcmVlbik7XG4gIGlmICghc2NyZWVuKSByZXR1cm4gbnVsbDtcbiAgaWYgKHNjcmVlbiA9PT0gJ2Nob29zZXInKSByZXR1cm4gPEJvYXJkQ2hvb3NlciAvPjtcblxuICBjb25zdCBjbG9zZSA9ICgpID0+IHdiLnNldFNjcmVlbihudWxsKTtcblxuICBjb25zdCBlbXB0eUFydCA9IChpY29uOiBzdHJpbmcsIHNpemU6IG51bWJlciwgYW1iZXIgPSBmYWxzZSkgPT4gKFxuICAgIDxkaXZcbiAgICAgIHN0eWxlPXt7XG4gICAgICAgIHdpZHRoOiA4OCxcbiAgICAgICAgaGVpZ2h0OiA4OCxcbiAgICAgICAgYm9yZGVyUmFkaXVzOiAyNCxcbiAgICAgICAgYmFja2dyb3VuZDogYW1iZXIgPyAnY29sb3ItbWl4KGluIG9rbGFiLCAjY2FhMjRhIDE2JSwgdmFyKC0tcGFuZWwpKScgOiAnY29sb3ItbWl4KGluIG9rbGFiLCB2YXIoLS1hY2NlbnQtMikgMTQlLCB2YXIoLS1wYW5lbCkpJyxcbiAgICAgICAgYm9yZGVyOiBgMXB4IHNvbGlkICR7YW1iZXIgPyAnY29sb3ItbWl4KGluIG9rbGFiLCAjY2FhMjRhIDQwJSwgdmFyKC0tbGluZSkpJyA6ICd2YXIoLS1saW5lLTIpJ31gLFxuICAgICAgICBkaXNwbGF5OiAnZmxleCcsXG4gICAgICAgIGFsaWduSXRlbXM6ICdjZW50ZXInLFxuICAgICAgICBqdXN0aWZ5Q29udGVudDogJ2NlbnRlcicsXG4gICAgICAgIGNvbG9yOiBhbWJlciA/ICcjY2FhMjRhJyA6ICd2YXIoLS1hY2NlbnQtdmlvbGV0KScsXG4gICAgICAgIG1hcmdpbkJvdHRvbTogNixcbiAgICAgIH19XG4gICAgPlxuICAgICAgPEljb24gbmFtZT17aWNvbn0gc2l6ZT17c2l6ZX0gc3Ryb2tlV2lkdGg9ezEuNX0gLz5cbiAgICA8L2Rpdj5cbiAgKTtcblxuICAvLyBga2V5YCBpcyByZXF1aXJlZCBiZWNhdXNlIHRoZSBzYW1lIGhlbHBlciByZW5kZXJzIHNpYmxpbmcgYnV0dG9ucyBpbiBhbiBhcnJheS5cbiAgLy8gYGJ1c3lGb3JgICh3aGVuIGdpdmVuKSBuYW1lcyB0aGUgZmxvdyB0aGlzIGJ1dHRvbiBzdGFydHM6IHdoaWxlIGl0IHJ1bnMgdGhlXG4gIC8vIGJ1dHRvbiBzaG93cyB0aGUgbmFtZWQgYnVzeSBsYWJlbCB3aXRoIGFyaWEtYnVzeSwgYW5kIE5PIGNsb3NlLWZpcnN0IOKAlCB0aGVcbiAgLy8gc3VyZmFjZSB0aGF0IG5hbWVzIHRoZSB3YWl0IG11c3Qgc3Vydml2ZSB0aGUgd2FpdCAoUi1JWC0yKTsgdGhlIGZsb3cgaXRzZWxmXG4gIC8vIGNsb3NlcyB0aGUgc2NyZWVuIG9uIHN1Y2Nlc3MuXG4gIGNvbnN0IHByaW1hcnkgPSAoXG4gICAga2V5OiBzdHJpbmcsXG4gICAgbGFiZWw6IHN0cmluZyxcbiAgICBpY29uOiBzdHJpbmcsXG4gICAgb25DbGljazogKCkgPT4gdm9pZCA9IGNsb3NlLFxuICAgIGJ1c3lGbG93Pzoga2V5b2YgdHlwZW9mIEJVU1lfTEFCRUxTLFxuICApID0+IHtcbiAgICBjb25zdCBidXN5ID0gYnVzeUZsb3cgIT09IHVuZGVmaW5lZCAmJiB3Yi5zdGF0ZS5idXN5ID09PSBidXN5RmxvdztcbiAgICByZXR1cm4gKFxuICAgICAgPGJ1dHRvblxuICAgICAgICBrZXk9e2tleX1cbiAgICAgICAgYXJpYS1idXN5PXtidXN5IHx8IHVuZGVmaW5lZH1cbiAgICAgICAgZGlzYWJsZWQ9e2J1c3l9XG4gICAgICAgIG9uQ2xpY2s9e29uQ2xpY2t9XG4gICAgICAgIHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGdhcDogOCwgcGFkZGluZzogJzEycHggMjBweCcsIGJhY2tncm91bmQ6ICd2YXIoLS1ncmFkKScsIGJvcmRlcjogJ25vbmUnLCBib3JkZXJSYWRpdXM6ICd2YXIoLS1yLXBpbGwpJywgY29sb3I6ICcjMWExMDIwJywgZm9udDogJ3ZhcigtLWxhYmVsKScsIGN1cnNvcjogYnVzeSA/ICdkZWZhdWx0JyA6ICdwb2ludGVyJywgYm94U2hhZG93OiAndmFyKC0tZ2xvdyknLCB3aGl0ZVNwYWNlOiAnbm93cmFwJyB9fVxuICAgICAgPlxuICAgICAgICA8SWNvbiBuYW1lPXtpY29ufSBzaXplPXsxNn0gY29sb3I9XCIjMWExMDIwXCIgc3Ryb2tlV2lkdGg9e2ljb24gPT09ICdjaGV2UmlnaHQnIHx8IGljb24gPT09ICdwbHVzQmlnJyA/IDIgOiAxLjc1fSAvPlxuICAgICAgICB7YnVzeSA/IEJVU1lfTEFCRUxTW2J1c3lGbG93IV0gOiBsYWJlbH1cbiAgICAgIDwvYnV0dG9uPlxuICAgICk7XG4gIH07XG4gIGNvbnN0IHNlY29uZGFyeSA9IChrZXk6IHN0cmluZywgbGFiZWw6IHN0cmluZywgb25DbGljazogKCkgPT4gdm9pZCA9IGNsb3NlLCBidXN5Rmxvdz86IGtleW9mIHR5cGVvZiBCVVNZX0xBQkVMUykgPT4ge1xuICAgIGNvbnN0IGJ1c3kgPSBidXN5RmxvdyAhPT0gdW5kZWZpbmVkICYmIHdiLnN0YXRlLmJ1c3kgPT09IGJ1c3lGbG93O1xuICAgIHJldHVybiAoXG4gICAgICA8YnV0dG9uIGtleT17a2V5fSBhcmlhLWJ1c3k9e2J1c3kgfHwgdW5kZWZpbmVkfSBkaXNhYmxlZD17YnVzeX0gb25DbGljaz17b25DbGlja30gc3R5bGU9e3sgcGFkZGluZzogJzEycHggMjBweCcsIGJhY2tncm91bmQ6ICd2YXIoLS1iZyknLCBib3JkZXI6ICcxcHggc29saWQgdmFyKC0tbGluZS0yKScsIGJvcmRlclJhZGl1czogJ3ZhcigtLXItcGlsbCknLCBjb2xvcjogJ3ZhcigtLWluayknLCBmb250OiAndmFyKC0tbGFiZWwpJywgY3Vyc29yOiBidXN5ID8gJ2RlZmF1bHQnIDogJ3BvaW50ZXInLCB3aGl0ZVNwYWNlOiAnbm93cmFwJyB9fT5cbiAgICAgICAge2J1c3kgPyBCVVNZX0xBQkVMU1tidXN5RmxvdyFdIDogbGFiZWx9XG4gICAgICA8L2J1dHRvbj5cbiAgICApO1xuICB9O1xuICAvLyBBbiBpbnN0YW50IGFjdGlvbiBjbG9zZXMgaXRzIHNjcmVlbiBmaXJzdCAobm90aGluZyBpcyBhd2FpdGVkKTsgYSBwaWNrXG4gIC8vIGZsb3cgZG9lcyBOT1Qg4oCUIGl0cyBuYW1lZCBidXN5IHJlbmRlcnMgb24gdGhlIGJ1dHRvbiB0aGF0IHN0YXJ0ZWQgaXQsIGFuZFxuICAvLyB0aGUgZmxvdyBjbG9zZXMgdGhlIHNjcmVlbiBvbiBzdWNjZXNzIChSLUlYLTIpLlxuICBjb25zdCBpbnN0YW50ID0gKGZuOiAoKSA9PiB2b2lkKSA9PiAoKSA9PiB7XG4gICAgY2xvc2UoKTtcbiAgICBmbigpO1xuICB9O1xuICBjb25zdCBmbG93ID0gKGZuOiAoKSA9PiB2b2lkKSA9PiAoKSA9PiB7XG4gICAgZm4oKTtcbiAgfTtcblxuICBjb25zdCBjb250ZW50OiBSZWNvcmQ8c3RyaW5nLCB7IGFydDogUmVhY3QuUmVhY3ROb2RlOyB0aXRsZTogc3RyaW5nOyBib2R5OiBzdHJpbmc7IGFjdGlvbnM6IFJlYWN0LlJlYWN0Tm9kZVtdIH0+ID0ge1xuICAgIGVtcHR5OiB7XG4gICAgICBhcnQ6IGVtcHR5QXJ0KCdzdGlja3knLCA0MCksXG4gICAgICB0aXRsZTogJ0FuIGVtcHR5IGJvYXJkLicsXG4gICAgICBib2R5OiAnRG91YmxlLWNsaWNrIGFueXdoZXJlIHRvIGRyb3AgeW91ciBmaXJzdCBub3RlIOKAlCBvciBwaWNrIGFuIGltYWdlLiBFdmVyeSBvYmplY3QgeW91IGFkZCBiZWNvbWVzIG9uZSBmaWxlIGluIHRoaXMgZm9sZGVyLicsXG4gICAgICBhY3Rpb25zOiBbXG4gICAgICAgIHByaW1hcnkoJ2FkZC1ub3RlJywgJ0FkZCBhIG5vdGUnLCAncGx1c0JpZycsIGluc3RhbnQoKCkgPT4gd2IuY3JlYXRlT2JqZWN0KCdub3RlJywgd2Iuc3RhdGUuY2FtLmN4LCB3Yi5zdGF0ZS5jYW0uY3kpKSksXG4gICAgICAgIHNlY29uZGFyeSgnaW5zZXJ0LWltYWdlJywgJ0luc2VydCBpbWFnZeKApicsIGZsb3coKCkgPT4gd2IuaW5zZXJ0SW1hZ2UoMCwgMCkpLCAnaW5zZXJ0LWltYWdlJyksXG4gICAgICBdLFxuICAgIH0sXG4gICAgbm9ib2FyZDoge1xuICAgICAgYXJ0OiBlbXB0eUFydCgnaW5ib3gnLCAzOCksXG4gICAgICB0aXRsZTogJ05vIGJvYXJkIHNlbGVjdGVkLicsXG4gICAgICBib2R5OiAnQ2hvb3NlIGEgYm9hcmQgdG8gb3Blbiwgb3Igc3RhcnQgYSBuZXcgb25lLiBZb3VyIGJvYXJkcyBsaXZlIGFjcm9zcyB5b3VyIHRlYW0gc3BhY2VzLicsXG4gICAgICBhY3Rpb25zOiBbcHJpbWFyeSgnb3Blbi1ib2FyZCcsICdPcGVuIGEgYm9hcmTigKYnLCAnZm9sZGVyJywgZmxvdyh3Yi5vcGVuQm9hcmQpLCAnb3Blbi1ib2FyZCcpXSxcbiAgICB9LFxuICAgIHNpZ25lZG91dDoge1xuICAgICAgYXJ0OiBlbXB0eUFydCgnbG9jaycsIDM0KSxcbiAgICAgIHRpdGxlOiAnU2lnbiBpbiB0byBsb2FkIHlvdXIgYm9hcmRzLicsXG4gICAgICBib2R5OiAnQm9hcmRzIGxpdmUgaW4gYSBzaGFyZWQgc3BhY2UuIFNpZ25pbmcgaW4gaXMgaGFuZGxlZCBieSBpbW1lZGlhdGVseS5ydW4g4oCUIHRoaXMgYXBwIG5ldmVyIGFza3MgZm9yIGNyZWRlbnRpYWxzIGl0c2VsZi4nLFxuICAgICAgYWN0aW9uczogW3ByaW1hcnkoJ2NvbnRpbnVlJywgJ0NvbnRpbnVlJywgJ2NoZXZSaWdodCcpXSxcbiAgICB9LFxuICAgIG5vdGFib2FyZDoge1xuICAgICAgYXJ0OiBlbXB0eUFydCgnYWxlcnQnLCAzOCwgdHJ1ZSksXG4gICAgICB0aXRsZTogJ05vdCBhIGJvYXJkLicsXG4gICAgICBib2R5OiAnVGhhdCBmb2xkZXIgaGFzIG5vIGJvYXJkLm1kLCBzbyB0aGVyZSBpcyBub3RoaW5nIHRvIHJlbmRlci4gUGljayBhIGRpZmZlcmVudCBmb2xkZXIsIG9yIGNyZWF0ZSBhIGJvYXJkIGhlcmUuJyxcbiAgICAgIGFjdGlvbnM6IFtcbiAgICAgICAgcHJpbWFyeSgnY3JlYXRlLWJvYXJkJywgJ0NyZWF0ZSBib2FyZCBoZXJl4oCmJywgJ3BsdXNCaWcnLCBmbG93KHdiLm5ld0JvYXJkKSwgJ25ldy1ib2FyZCcpLFxuICAgICAgICBzZWNvbmRhcnkoJ3BpY2stYW5vdGhlcicsICdQaWNrIGFub3RoZXLigKYnLCBmbG93KHdiLm9wZW5Cb2FyZCksICdvcGVuLWJvYXJkJyksXG4gICAgICBdLFxuICAgIH0sXG4gIH07XG5cbiAgY29uc3QgYyA9IGNvbnRlbnRbc2NyZWVuXTtcbiAgaWYgKCFjKSByZXR1cm4gbnVsbDtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgc3R5bGU9e3sgcG9zaXRpb246ICdhYnNvbHV0ZScsIGluc2V0OiAwLCB6SW5kZXg6IDcwLCBiYWNrZ3JvdW5kOiAnY29sb3ItbWl4KGluIG9rbGFiLCB2YXIoLS1iZykgOTIlLCB0cmFuc3BhcmVudCknLCBiYWNrZHJvcEZpbHRlcjogJ2JsdXIoOHB4KScsIGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGp1c3RpZnlDb250ZW50OiAnY2VudGVyJywgcGFkZGluZzogMjQgfX0+XG4gICAgICA8YnV0dG9uIG9uQ2xpY2s9e2Nsb3NlU2NyZWVufSBhcmlhLWxhYmVsPVwiQ2xvc2VcIiBzdHlsZT17eyBwb3NpdGlvbjogJ2Fic29sdXRlJywgdG9wOiAxOCwgcmlnaHQ6IDE4LCBkaXNwbGF5OiAnZmxleCcsIHBhZGRpbmc6IDksIGJhY2tncm91bmQ6ICd2YXIoLS1wYW5lbCknLCBib3JkZXI6ICcxcHggc29saWQgdmFyKC0tbGluZSknLCBib3JkZXJSYWRpdXM6ICc1MCUnLCBjb2xvcjogJ3ZhcigtLWluay0yKScsIGN1cnNvcjogJ3BvaW50ZXInIH19PlxuICAgICAgICA8SWNvbiBuYW1lPVwieFwiIHNpemU9ezE4fSAvPlxuICAgICAgPC9idXR0b24+XG4gICAgICA8ZGl2IHJlZj17ZGlhbG9nUmVmfSB0YWJJbmRleD17LTF9IHN0eWxlPXt7IHdpZHRoOiAnbWluKDQ2MHB4LCA5NHZ3KScsIHRleHRBbGlnbjogJ2NlbnRlcicsIGRpc3BsYXk6ICdmbGV4JywgZmxleERpcmVjdGlvbjogJ2NvbHVtbicsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBnYXA6IDE2IH19PlxuICAgICAgICB7Yy5hcnR9XG4gICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udDogJzgwMCAzMHB4LzEgdmFyKC0tZGlzcCknLCBsZXR0ZXJTcGFjaW5nOiAnLS4wM2VtJyB9fT57Yy50aXRsZX08L2Rpdj5cbiAgICAgICAgPGRpdiBzdHlsZT17eyBmb250OiAndmFyKC0tYm9keSknLCBjb2xvcjogJ3ZhcigtLWluay0yKScsIG1heFdpZHRoOiAzODAsIHRleHRXcmFwOiAncHJldHR5JyB9fT57Yy5ib2R5fTwvZGl2PlxuICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywgZ2FwOiAxMCwgbWFyZ2luVG9wOiA0IH19PntjLmFjdGlvbnN9PC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgU3RhdGVTY3JlZW5zO1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFNQSxJQUFBQSxlQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxZQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxpQkFBQSxHQUFBRixPQUFBO0FBQ0EsSUFBQUcsYUFBQSxHQUFBQyxzQkFBQSxDQUFBSixPQUFBO0FBQ0EsSUFBQUssS0FBQSxHQUFBRCxzQkFBQSxDQUFBSixPQUFBO0FBQTBCLElBQUFNLFdBQUEsR0FBQU4sT0FBQTtBQUFBLElBQUFPLEVBQUEsR0FBQUMsWUFBQSxJQVYxQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQUEsU0FBQUosdUJBQUFLLENBQUEsV0FBQUEsQ0FBQSxJQUFBQSxDQUFBLENBQUFDLFVBQUEsR0FBQUQsQ0FBQSxLQUFBRSxPQUFBLEVBQUFGLENBQUE7QUFRQSxTQUFTRyxZQUFZQSxDQUFBLEVBQUc7RUFBQUwsRUFBQTtFQUN0QixNQUFNTSxFQUFFLEdBQUcsSUFBQUMscUJBQUssRUFBQyxDQUFDO0VBQ2xCLE1BQU1DLE1BQU0sR0FBR0YsRUFBRSxDQUFDRyxLQUFLLENBQUNELE1BQU07RUFDOUIsTUFBTUUsV0FBVyxHQUFHQSxDQUFBLEtBQU1KLEVBQUUsQ0FBQ0ssU0FBUyxDQUFDLElBQUksQ0FBQztFQUM1QztFQUNBO0VBQ0EsTUFBTUMsU0FBUyxHQUFHLElBQUFDLGtDQUFnQixFQUFDLENBQUMsQ0FBQ0wsTUFBTSxJQUFJQSxNQUFNLEtBQUssU0FBUyxFQUFFRSxXQUFXLENBQUM7RUFDakYsSUFBSSxDQUFDRixNQUFNLEVBQUUsT0FBTyxJQUFJO0VBQ3hCLElBQUlBLE1BQU0sS0FBSyxTQUFTLEVBQUUsb0JBQU8sSUFBQVQsV0FBQSxDQUFBZSxHQUFBLEVBQUNsQixhQUFBLENBQUFRLE9BQVksSUFBRSxDQUFDO0VBRWpELE1BQU1XLEtBQUssR0FBR0EsQ0FBQSxLQUFNVCxFQUFFLENBQUNLLFNBQVMsQ0FBQyxJQUFJLENBQUM7RUFFdEMsTUFBTUssUUFBUSxHQUFHQSxDQUFDQyxJQUFZLEVBQUVDLElBQVksRUFBRUMsS0FBSyxHQUFHLEtBQUssa0JBQ3pELElBQUFwQixXQUFBLENBQUFlLEdBQUE7SUFDRU0sS0FBSyxFQUFFO01BQ0xDLEtBQUssRUFBRSxFQUFFO01BQ1RDLE1BQU0sRUFBRSxFQUFFO01BQ1ZDLFlBQVksRUFBRSxFQUFFO01BQ2hCQyxVQUFVLEVBQUVMLEtBQUssR0FBRyxnREFBZ0QsR0FBRyx3REFBd0Q7TUFDL0hNLE1BQU0sRUFBRSxhQUFhTixLQUFLLEdBQUcsK0NBQStDLEdBQUcsZUFBZSxFQUFFO01BQ2hHTyxPQUFPLEVBQUUsTUFBTTtNQUNmQyxVQUFVLEVBQUUsUUFBUTtNQUNwQkMsY0FBYyxFQUFFLFFBQVE7TUFDeEJDLEtBQUssRUFBRVYsS0FBSyxHQUFHLFNBQVMsR0FBRyxzQkFBc0I7TUFDakRXLFlBQVksRUFBRTtJQUNoQixDQUFFO0lBQUFDLFFBQUEsZUFFRixJQUFBaEMsV0FBQSxDQUFBZSxHQUFBLEVBQUNoQixLQUFBLENBQUFNLE9BQUk7TUFBQzRCLElBQUksRUFBRWYsSUFBSztNQUFDQyxJQUFJLEVBQUVBLElBQUs7TUFBQ2UsV0FBVyxFQUFFO0lBQUksQ0FBRTtFQUFDLENBQy9DLENBQ047O0VBRUQ7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU1DLE9BQU8sR0FBR0EsQ0FDZEMsR0FBVyxFQUNYQyxLQUFhLEVBQ2JuQixJQUFZLEVBQ1pvQixPQUFtQixHQUFHdEIsS0FBSyxFQUMzQnVCLFFBQW1DLEtBQ2hDO0lBQ0gsTUFBTUMsSUFBSSxHQUFHRCxRQUFRLEtBQUtFLFNBQVMsSUFBSWxDLEVBQUUsQ0FBQ0csS0FBSyxDQUFDOEIsSUFBSSxLQUFLRCxRQUFRO0lBQ2pFLG9CQUNFLElBQUF2QyxXQUFBLENBQUEwQyxJQUFBO01BRUUsYUFBV0YsSUFBSSxJQUFJQyxTQUFVO01BQzdCRSxRQUFRLEVBQUVILElBQUs7TUFDZkYsT0FBTyxFQUFFQSxPQUFRO01BQ2pCakIsS0FBSyxFQUFFO1FBQUVNLE9BQU8sRUFBRSxNQUFNO1FBQUVDLFVBQVUsRUFBRSxRQUFRO1FBQUVnQixHQUFHLEVBQUUsQ0FBQztRQUFFQyxPQUFPLEVBQUUsV0FBVztRQUFFcEIsVUFBVSxFQUFFLGFBQWE7UUFBRUMsTUFBTSxFQUFFLE1BQU07UUFBRUYsWUFBWSxFQUFFLGVBQWU7UUFBRU0sS0FBSyxFQUFFLFNBQVM7UUFBRWdCLElBQUksRUFBRSxjQUFjO1FBQUVDLE1BQU0sRUFBRVAsSUFBSSxHQUFHLFNBQVMsR0FBRyxTQUFTO1FBQUVRLFNBQVMsRUFBRSxhQUFhO1FBQUVDLFVBQVUsRUFBRTtNQUFTLENBQUU7TUFBQWpCLFFBQUEsZ0JBRXZSLElBQUFoQyxXQUFBLENBQUFlLEdBQUEsRUFBQ2hCLEtBQUEsQ0FBQU0sT0FBSTtRQUFDNEIsSUFBSSxFQUFFZixJQUFLO1FBQUNDLElBQUksRUFBRSxFQUFHO1FBQUNXLEtBQUssRUFBQyxTQUFTO1FBQUNJLFdBQVcsRUFBRWhCLElBQUksS0FBSyxXQUFXLElBQUlBLElBQUksS0FBSyxTQUFTLEdBQUcsQ0FBQyxHQUFHO01BQUssQ0FBRSxDQUFDLEVBQ2pIc0IsSUFBSSxHQUFHVSx3QkFBVyxDQUFDWCxRQUFRLENBQUUsR0FBR0YsS0FBSztJQUFBLEdBUGpDRCxHQVFDLENBQUM7RUFFYixDQUFDO0VBQ0QsTUFBTWUsU0FBUyxHQUFHQSxDQUFDZixHQUFXLEVBQUVDLEtBQWEsRUFBRUMsT0FBbUIsR0FBR3RCLEtBQUssRUFBRXVCLFFBQW1DLEtBQUs7SUFDbEgsTUFBTUMsSUFBSSxHQUFHRCxRQUFRLEtBQUtFLFNBQVMsSUFBSWxDLEVBQUUsQ0FBQ0csS0FBSyxDQUFDOEIsSUFBSSxLQUFLRCxRQUFRO0lBQ2pFLG9CQUNFLElBQUF2QyxXQUFBLENBQUFlLEdBQUE7TUFBa0IsYUFBV3lCLElBQUksSUFBSUMsU0FBVTtNQUFDRSxRQUFRLEVBQUVILElBQUs7TUFBQ0YsT0FBTyxFQUFFQSxPQUFRO01BQUNqQixLQUFLLEVBQUU7UUFBRXdCLE9BQU8sRUFBRSxXQUFXO1FBQUVwQixVQUFVLEVBQUUsV0FBVztRQUFFQyxNQUFNLEVBQUUseUJBQXlCO1FBQUVGLFlBQVksRUFBRSxlQUFlO1FBQUVNLEtBQUssRUFBRSxZQUFZO1FBQUVnQixJQUFJLEVBQUUsY0FBYztRQUFFQyxNQUFNLEVBQUVQLElBQUksR0FBRyxTQUFTLEdBQUcsU0FBUztRQUFFUyxVQUFVLEVBQUU7TUFBUyxDQUFFO01BQUFqQixRQUFBLEVBQ2pUUSxJQUFJLEdBQUdVLHdCQUFXLENBQUNYLFFBQVEsQ0FBRSxHQUFHRjtJQUFLLEdBRDNCRCxHQUVMLENBQUM7RUFFYixDQUFDO0VBQ0Q7RUFDQTtFQUNBO0VBQ0EsTUFBTWdCLE9BQU8sR0FBSUMsRUFBYyxJQUFLLE1BQU07SUFDeENyQyxLQUFLLENBQUMsQ0FBQztJQUNQcUMsRUFBRSxDQUFDLENBQUM7RUFDTixDQUFDO0VBQ0QsTUFBTUMsSUFBSSxHQUFJRCxFQUFjLElBQUssTUFBTTtJQUNyQ0EsRUFBRSxDQUFDLENBQUM7RUFDTixDQUFDO0VBRUQsTUFBTUUsT0FBMEcsR0FBRztJQUNqSEMsS0FBSyxFQUFFO01BQ0xDLEdBQUcsRUFBRXhDLFFBQVEsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDO01BQzNCeUMsS0FBSyxFQUFFLGlCQUFpQjtNQUN4QkMsSUFBSSxFQUFFLHlIQUF5SDtNQUMvSEMsT0FBTyxFQUFFLENBQ1B6QixPQUFPLENBQUMsVUFBVSxFQUFFLFlBQVksRUFBRSxTQUFTLEVBQUVpQixPQUFPLENBQUMsTUFBTTdDLEVBQUUsQ0FBQ3NELFlBQVksQ0FBQyxNQUFNLEVBQUV0RCxFQUFFLENBQUNHLEtBQUssQ0FBQ29ELEdBQUcsQ0FBQ0MsRUFBRSxFQUFFeEQsRUFBRSxDQUFDRyxLQUFLLENBQUNvRCxHQUFHLENBQUNFLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFDdEhiLFNBQVMsQ0FBQyxjQUFjLEVBQUUsZUFBZSxFQUFFRyxJQUFJLENBQUMsTUFBTS9DLEVBQUUsQ0FBQzBELFdBQVcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxjQUFjLENBQUM7SUFFaEcsQ0FBQztJQUNEQyxPQUFPLEVBQUU7TUFDUFQsR0FBRyxFQUFFeEMsUUFBUSxDQUFDLE9BQU8sRUFBRSxFQUFFLENBQUM7TUFDMUJ5QyxLQUFLLEVBQUUsb0JBQW9CO01BQzNCQyxJQUFJLEVBQUUsdUZBQXVGO01BQzdGQyxPQUFPLEVBQUUsQ0FBQ3pCLE9BQU8sQ0FBQyxZQUFZLEVBQUUsZUFBZSxFQUFFLFFBQVEsRUFBRW1CLElBQUksQ0FBQy9DLEVBQUUsQ0FBQzRELFNBQVMsQ0FBQyxFQUFFLFlBQVksQ0FBQztJQUM5RixDQUFDO0lBQ0RDLFNBQVMsRUFBRTtNQUNUWCxHQUFHLEVBQUV4QyxRQUFRLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQztNQUN6QnlDLEtBQUssRUFBRSw4QkFBOEI7TUFDckNDLElBQUksRUFBRSx1SEFBdUg7TUFDN0hDLE9BQU8sRUFBRSxDQUFDekIsT0FBTyxDQUFDLFVBQVUsRUFBRSxVQUFVLEVBQUUsV0FBVyxDQUFDO0lBQ3hELENBQUM7SUFDRGtDLFNBQVMsRUFBRTtNQUNUWixHQUFHLEVBQUV4QyxRQUFRLENBQUMsT0FBTyxFQUFFLEVBQUUsRUFBRSxJQUFJLENBQUM7TUFDaEN5QyxLQUFLLEVBQUUsY0FBYztNQUNyQkMsSUFBSSxFQUFFLDhHQUE4RztNQUNwSEMsT0FBTyxFQUFFLENBQ1B6QixPQUFPLENBQUMsY0FBYyxFQUFFLG9CQUFvQixFQUFFLFNBQVMsRUFBRW1CLElBQUksQ0FBQy9DLEVBQUUsQ0FBQytELFFBQVEsQ0FBQyxFQUFFLFdBQVcsQ0FBQyxFQUN4Rm5CLFNBQVMsQ0FBQyxjQUFjLEVBQUUsZUFBZSxFQUFFRyxJQUFJLENBQUMvQyxFQUFFLENBQUM0RCxTQUFTLENBQUMsRUFBRSxZQUFZLENBQUM7SUFFaEY7RUFDRixDQUFDO0VBRUQsTUFBTUksQ0FBQyxHQUFHaEIsT0FBTyxDQUFDOUMsTUFBTSxDQUFDO0VBQ3pCLElBQUksQ0FBQzhELENBQUMsRUFBRSxPQUFPLElBQUk7RUFFbkIsb0JBQ0UsSUFBQXZFLFdBQUEsQ0FBQTBDLElBQUE7SUFBS3JCLEtBQUssRUFBRTtNQUFFbUQsUUFBUSxFQUFFLFVBQVU7TUFBRUMsS0FBSyxFQUFFLENBQUM7TUFBRUMsTUFBTSxFQUFFLEVBQUU7TUFBRWpELFVBQVUsRUFBRSxpREFBaUQ7TUFBRWtELGNBQWMsRUFBRSxXQUFXO01BQUVoRCxPQUFPLEVBQUUsTUFBTTtNQUFFQyxVQUFVLEVBQUUsUUFBUTtNQUFFQyxjQUFjLEVBQUUsUUFBUTtNQUFFZ0IsT0FBTyxFQUFFO0lBQUcsQ0FBRTtJQUFBYixRQUFBLGdCQUNuTyxJQUFBaEMsV0FBQSxDQUFBZSxHQUFBO01BQVF1QixPQUFPLEVBQUUzQixXQUFZO01BQUMsY0FBVyxPQUFPO01BQUNVLEtBQUssRUFBRTtRQUFFbUQsUUFBUSxFQUFFLFVBQVU7UUFBRUksR0FBRyxFQUFFLEVBQUU7UUFBRUMsS0FBSyxFQUFFLEVBQUU7UUFBRWxELE9BQU8sRUFBRSxNQUFNO1FBQUVrQixPQUFPLEVBQUUsQ0FBQztRQUFFcEIsVUFBVSxFQUFFLGNBQWM7UUFBRUMsTUFBTSxFQUFFLHVCQUF1QjtRQUFFRixZQUFZLEVBQUUsS0FBSztRQUFFTSxLQUFLLEVBQUUsY0FBYztRQUFFaUIsTUFBTSxFQUFFO01BQVUsQ0FBRTtNQUFBZixRQUFBLGVBQzVQLElBQUFoQyxXQUFBLENBQUFlLEdBQUEsRUFBQ2hCLEtBQUEsQ0FBQU0sT0FBSTtRQUFDNEIsSUFBSSxFQUFDLEdBQUc7UUFBQ2QsSUFBSSxFQUFFO01BQUcsQ0FBRTtJQUFDLENBQ3JCLENBQUMsZUFDVCxJQUFBbkIsV0FBQSxDQUFBMEMsSUFBQTtNQUFLb0MsR0FBRyxFQUFFakUsU0FBVTtNQUFDa0UsUUFBUSxFQUFFLENBQUMsQ0FBRTtNQUFDMUQsS0FBSyxFQUFFO1FBQUVDLEtBQUssRUFBRSxrQkFBa0I7UUFBRTBELFNBQVMsRUFBRSxRQUFRO1FBQUVyRCxPQUFPLEVBQUUsTUFBTTtRQUFFc0QsYUFBYSxFQUFFLFFBQVE7UUFBRXJELFVBQVUsRUFBRSxRQUFRO1FBQUVnQixHQUFHLEVBQUU7TUFBRyxDQUFFO01BQUFaLFFBQUEsR0FDbkt1QyxDQUFDLENBQUNkLEdBQUcsZUFDTixJQUFBekQsV0FBQSxDQUFBZSxHQUFBO1FBQUtNLEtBQUssRUFBRTtVQUFFeUIsSUFBSSxFQUFFLHdCQUF3QjtVQUFFb0MsYUFBYSxFQUFFO1FBQVMsQ0FBRTtRQUFBbEQsUUFBQSxFQUFFdUMsQ0FBQyxDQUFDYjtNQUFLLENBQU0sQ0FBQyxlQUN4RixJQUFBMUQsV0FBQSxDQUFBZSxHQUFBO1FBQUtNLEtBQUssRUFBRTtVQUFFeUIsSUFBSSxFQUFFLGFBQWE7VUFBRWhCLEtBQUssRUFBRSxjQUFjO1VBQUVxRCxRQUFRLEVBQUUsR0FBRztVQUFFQyxRQUFRLEVBQUU7UUFBUyxDQUFFO1FBQUFwRCxRQUFBLEVBQUV1QyxDQUFDLENBQUNaO01BQUksQ0FBTSxDQUFDLGVBQzdHLElBQUEzRCxXQUFBLENBQUFlLEdBQUE7UUFBS00sS0FBSyxFQUFFO1VBQUVNLE9BQU8sRUFBRSxNQUFNO1VBQUVpQixHQUFHLEVBQUUsRUFBRTtVQUFFeUMsU0FBUyxFQUFFO1FBQUUsQ0FBRTtRQUFBckQsUUFBQSxFQUFFdUMsQ0FBQyxDQUFDWDtNQUFPLENBQU0sQ0FBQztJQUFBLENBQ3RFLENBQUM7RUFBQSxDQUNILENBQUM7QUFFVjtBQUFDM0QsRUFBQSxDQTdIUUssWUFBWTtFQUFBLFFBQ1JFLHFCQUFLLEVBS0VNLGtDQUFnQjtBQUFBO0FBQUF3RSxFQUFBLEdBTjNCaEYsWUFBWTtBQUFBLElBQUFpRixRQUFBLEdBQUFDLE9BQUEsQ0FBQW5GLE9BQUEsR0ErSE5DLFlBQVk7QUFBQSxJQUFBZ0YsRUFBQTtBQUFBRyxZQUFBLENBQUFILEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}