var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _useLodestar = require("../hooks/useLodestar");
var _context = require("../lib/context");
var _Canvas = _interopRequireDefault(require("./Canvas"));
var _TopBar = _interopRequireDefault(require("./TopBar"));
var _EditToolbar = _interopRequireDefault(require("./EditToolbar"));
var _Inspector = _interopRequireDefault(require("./Inspector"));
var _JourneysPanel = _interopRequireDefault(require("./JourneysPanel"));
var _QuickCreateMenu = _interopRequireDefault(require("./QuickCreateMenu"));
var _Playback = _interopRequireDefault(require("./Playback"));
var _Toasts = _interopRequireDefault(require("./Toasts"));
var _DemoMenu = _interopRequireDefault(require("./DemoMenu"));
var _MobileChrome = _interopRequireDefault(require("./MobileChrome"));
var _StateScreens = _interopRequireDefault(require("./StateScreens"));
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // The app root: instantiates the controller once, provides it to the tree, and
// lays out the canvas + every chrome surface. Each surface decides its own
// visibility (mode, mobile, open/closed) so this stays a flat composition.
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function Lodestar() {
  _s();
  const wb = (0, _useLodestar.useLodestar)();
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(_context.LodestarContext.Provider, {
    value: wb,
    children: /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      style: {
        position: 'absolute',
        inset: 0,
        background: 'var(--bg)',
        color: 'var(--ink)',
        font: '400 16px/1.5 var(--sans)',
        overflow: 'hidden',
        userSelect: 'none'
      },
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Canvas.default, {}), /*#__PURE__*/(0, _jsxRuntime.jsx)(_TopBar.default, {}), /*#__PURE__*/(0, _jsxRuntime.jsx)(_EditToolbar.default, {}), /*#__PURE__*/(0, _jsxRuntime.jsx)(_Inspector.default, {}), /*#__PURE__*/(0, _jsxRuntime.jsx)(_JourneysPanel.default, {}), /*#__PURE__*/(0, _jsxRuntime.jsx)(_QuickCreateMenu.default, {}), /*#__PURE__*/(0, _jsxRuntime.jsx)(_Playback.default, {}), /*#__PURE__*/(0, _jsxRuntime.jsx)(_Toasts.default, {}), /*#__PURE__*/(0, _jsxRuntime.jsx)(_DemoMenu.default, {}), /*#__PURE__*/(0, _jsxRuntime.jsx)(_MobileChrome.default, {}), /*#__PURE__*/(0, _jsxRuntime.jsx)(_StateScreens.default, {})]
    })
  });
}
_s(Lodestar, "9OrxXbG+0O8NHxj+P8Jiv+9I85A=", false, function () {
  return [_useLodestar.useLodestar];
});
_c = Lodestar;
var _default = exports.default = Lodestar;
var _c;
$RefreshReg$(_c, "Lodestar");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdXNlTG9kZXN0YXIiLCJyZXF1aXJlIiwiX2NvbnRleHQiLCJfQ2FudmFzIiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsIl9Ub3BCYXIiLCJfRWRpdFRvb2xiYXIiLCJfSW5zcGVjdG9yIiwiX0pvdXJuZXlzUGFuZWwiLCJfUXVpY2tDcmVhdGVNZW51IiwiX1BsYXliYWNrIiwiX1RvYXN0cyIsIl9EZW1vTWVudSIsIl9Nb2JpbGVDaHJvbWUiLCJfU3RhdGVTY3JlZW5zIiwiX2pzeFJ1bnRpbWUiLCJfcyIsIiRSZWZyZXNoU2lnJCIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsIkxvZGVzdGFyIiwid2IiLCJ1c2VMb2Rlc3RhciIsImpzeCIsIkxvZGVzdGFyQ29udGV4dCIsIlByb3ZpZGVyIiwidmFsdWUiLCJjaGlsZHJlbiIsImpzeHMiLCJzdHlsZSIsInBvc2l0aW9uIiwiaW5zZXQiLCJiYWNrZ3JvdW5kIiwiY29sb3IiLCJmb250Iiwib3ZlcmZsb3ciLCJ1c2VyU2VsZWN0IiwiX2MiLCJfZGVmYXVsdCIsImV4cG9ydHMiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJMb2Rlc3Rhci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gVGhlIGFwcCByb290OiBpbnN0YW50aWF0ZXMgdGhlIGNvbnRyb2xsZXIgb25jZSwgcHJvdmlkZXMgaXQgdG8gdGhlIHRyZWUsIGFuZFxuLy8gbGF5cyBvdXQgdGhlIGNhbnZhcyArIGV2ZXJ5IGNocm9tZSBzdXJmYWNlLiBFYWNoIHN1cmZhY2UgZGVjaWRlcyBpdHMgb3duXG4vLyB2aXNpYmlsaXR5IChtb2RlLCBtb2JpbGUsIG9wZW4vY2xvc2VkKSBzbyB0aGlzIHN0YXlzIGEgZmxhdCBjb21wb3NpdGlvbi5cblxuaW1wb3J0IHsgdXNlTG9kZXN0YXIgfSBmcm9tICcuLi9ob29rcy91c2VMb2Rlc3Rhcic7XG5pbXBvcnQgeyBMb2Rlc3RhckNvbnRleHQgfSBmcm9tICcuLi9saWIvY29udGV4dCc7XG5pbXBvcnQgQ2FudmFzIGZyb20gJy4vQ2FudmFzJztcbmltcG9ydCBUb3BCYXIgZnJvbSAnLi9Ub3BCYXInO1xuaW1wb3J0IEVkaXRUb29sYmFyIGZyb20gJy4vRWRpdFRvb2xiYXInO1xuaW1wb3J0IEluc3BlY3RvciBmcm9tICcuL0luc3BlY3Rvcic7XG5pbXBvcnQgSm91cm5leXNQYW5lbCBmcm9tICcuL0pvdXJuZXlzUGFuZWwnO1xuaW1wb3J0IFF1aWNrQ3JlYXRlTWVudSBmcm9tICcuL1F1aWNrQ3JlYXRlTWVudSc7XG5pbXBvcnQgUGxheWJhY2sgZnJvbSAnLi9QbGF5YmFjayc7XG5pbXBvcnQgVG9hc3RzIGZyb20gJy4vVG9hc3RzJztcbmltcG9ydCBEZW1vTWVudSBmcm9tICcuL0RlbW9NZW51JztcbmltcG9ydCBNb2JpbGVDaHJvbWUgZnJvbSAnLi9Nb2JpbGVDaHJvbWUnO1xuaW1wb3J0IFN0YXRlU2NyZWVucyBmcm9tICcuL1N0YXRlU2NyZWVucyc7XG5cbmZ1bmN0aW9uIExvZGVzdGFyKCkge1xuICBjb25zdCB3YiA9IHVzZUxvZGVzdGFyKCk7XG4gIHJldHVybiAoXG4gICAgPExvZGVzdGFyQ29udGV4dC5Qcm92aWRlciB2YWx1ZT17d2J9PlxuICAgICAgPGRpdiBzdHlsZT17eyBwb3NpdGlvbjogJ2Fic29sdXRlJywgaW5zZXQ6IDAsIGJhY2tncm91bmQ6ICd2YXIoLS1iZyknLCBjb2xvcjogJ3ZhcigtLWluayknLCBmb250OiAnNDAwIDE2cHgvMS41IHZhcigtLXNhbnMpJywgb3ZlcmZsb3c6ICdoaWRkZW4nLCB1c2VyU2VsZWN0OiAnbm9uZScgfX0+XG4gICAgICAgIDxDYW52YXMgLz5cbiAgICAgICAgPFRvcEJhciAvPlxuICAgICAgICA8RWRpdFRvb2xiYXIgLz5cbiAgICAgICAgPEluc3BlY3RvciAvPlxuICAgICAgICA8Sm91cm5leXNQYW5lbCAvPlxuICAgICAgICA8UXVpY2tDcmVhdGVNZW51IC8+XG4gICAgICAgIDxQbGF5YmFjayAvPlxuICAgICAgICA8VG9hc3RzIC8+XG4gICAgICAgIDxEZW1vTWVudSAvPlxuICAgICAgICA8TW9iaWxlQ2hyb21lIC8+XG4gICAgICAgIDxTdGF0ZVNjcmVlbnMgLz5cbiAgICAgIDwvZGl2PlxuICAgIDwvTG9kZXN0YXJDb250ZXh0LlByb3ZpZGVyPlxuICApO1xufVxuXG5leHBvcnQgZGVmYXVsdCBMb2Rlc3RhcjtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBSUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsUUFBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsT0FBQSxHQUFBQyxzQkFBQSxDQUFBSCxPQUFBO0FBQ0EsSUFBQUksT0FBQSxHQUFBRCxzQkFBQSxDQUFBSCxPQUFBO0FBQ0EsSUFBQUssWUFBQSxHQUFBRixzQkFBQSxDQUFBSCxPQUFBO0FBQ0EsSUFBQU0sVUFBQSxHQUFBSCxzQkFBQSxDQUFBSCxPQUFBO0FBQ0EsSUFBQU8sY0FBQSxHQUFBSixzQkFBQSxDQUFBSCxPQUFBO0FBQ0EsSUFBQVEsZ0JBQUEsR0FBQUwsc0JBQUEsQ0FBQUgsT0FBQTtBQUNBLElBQUFTLFNBQUEsR0FBQU4sc0JBQUEsQ0FBQUgsT0FBQTtBQUNBLElBQUFVLE9BQUEsR0FBQVAsc0JBQUEsQ0FBQUgsT0FBQTtBQUNBLElBQUFXLFNBQUEsR0FBQVIsc0JBQUEsQ0FBQUgsT0FBQTtBQUNBLElBQUFZLGFBQUEsR0FBQVQsc0JBQUEsQ0FBQUgsT0FBQTtBQUNBLElBQUFhLGFBQUEsR0FBQVYsc0JBQUEsQ0FBQUgsT0FBQTtBQUEwQyxJQUFBYyxXQUFBLEdBQUFkLE9BQUE7QUFBQSxJQUFBZSxFQUFBLEdBQUFDLFlBQUEsSUFoQjFDO0FBQ0E7QUFDQTtBQUFBLFNBQUFiLHVCQUFBYyxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBZ0JBLFNBQVNHLFFBQVFBLENBQUEsRUFBRztFQUFBTCxFQUFBO0VBQ2xCLE1BQU1NLEVBQUUsR0FBRyxJQUFBQyx3QkFBVyxFQUFDLENBQUM7RUFDeEIsb0JBQ0UsSUFBQVIsV0FBQSxDQUFBUyxHQUFBLEVBQUN0QixRQUFBLENBQUF1QixlQUFlLENBQUNDLFFBQVE7SUFBQ0MsS0FBSyxFQUFFTCxFQUFHO0lBQUFNLFFBQUEsZUFDbEMsSUFBQWIsV0FBQSxDQUFBYyxJQUFBO01BQUtDLEtBQUssRUFBRTtRQUFFQyxRQUFRLEVBQUUsVUFBVTtRQUFFQyxLQUFLLEVBQUUsQ0FBQztRQUFFQyxVQUFVLEVBQUUsV0FBVztRQUFFQyxLQUFLLEVBQUUsWUFBWTtRQUFFQyxJQUFJLEVBQUUsMEJBQTBCO1FBQUVDLFFBQVEsRUFBRSxRQUFRO1FBQUVDLFVBQVUsRUFBRTtNQUFPLENBQUU7TUFBQVQsUUFBQSxnQkFDckssSUFBQWIsV0FBQSxDQUFBUyxHQUFBLEVBQUNyQixPQUFBLENBQUFpQixPQUFNLElBQUUsQ0FBQyxlQUNWLElBQUFMLFdBQUEsQ0FBQVMsR0FBQSxFQUFDbkIsT0FBQSxDQUFBZSxPQUFNLElBQUUsQ0FBQyxlQUNWLElBQUFMLFdBQUEsQ0FBQVMsR0FBQSxFQUFDbEIsWUFBQSxDQUFBYyxPQUFXLElBQUUsQ0FBQyxlQUNmLElBQUFMLFdBQUEsQ0FBQVMsR0FBQSxFQUFDakIsVUFBQSxDQUFBYSxPQUFTLElBQUUsQ0FBQyxlQUNiLElBQUFMLFdBQUEsQ0FBQVMsR0FBQSxFQUFDaEIsY0FBQSxDQUFBWSxPQUFhLElBQUUsQ0FBQyxlQUNqQixJQUFBTCxXQUFBLENBQUFTLEdBQUEsRUFBQ2YsZ0JBQUEsQ0FBQVcsT0FBZSxJQUFFLENBQUMsZUFDbkIsSUFBQUwsV0FBQSxDQUFBUyxHQUFBLEVBQUNkLFNBQUEsQ0FBQVUsT0FBUSxJQUFFLENBQUMsZUFDWixJQUFBTCxXQUFBLENBQUFTLEdBQUEsRUFBQ2IsT0FBQSxDQUFBUyxPQUFNLElBQUUsQ0FBQyxlQUNWLElBQUFMLFdBQUEsQ0FBQVMsR0FBQSxFQUFDWixTQUFBLENBQUFRLE9BQVEsSUFBRSxDQUFDLGVBQ1osSUFBQUwsV0FBQSxDQUFBUyxHQUFBLEVBQUNYLGFBQUEsQ0FBQU8sT0FBWSxJQUFFLENBQUMsZUFDaEIsSUFBQUwsV0FBQSxDQUFBUyxHQUFBLEVBQUNWLGFBQUEsQ0FBQU0sT0FBWSxJQUFFLENBQUM7SUFBQSxDQUNiO0VBQUMsQ0FDa0IsQ0FBQztBQUUvQjtBQUFDSixFQUFBLENBbkJRSyxRQUFRO0VBQUEsUUFDSkUsd0JBQVc7QUFBQTtBQUFBZSxFQUFBLEdBRGZqQixRQUFRO0FBQUEsSUFBQWtCLFFBQUEsR0FBQUMsT0FBQSxDQUFBcEIsT0FBQSxHQXFCRkMsUUFBUTtBQUFBLElBQUFpQixFQUFBO0FBQUFHLFlBQUEsQ0FBQUgsRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}