var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.find.js");
require("core-js/modules/esnext.iterator.map.js");
var _react = require("react");
var _useLodestarCtx = require("../hooks/useLodestarCtx");
var _Icon = _interopRequireDefault(require("./Icon"));
var _journey = require("../lib/journey");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(),
  _s2 = $RefreshSig$(); // Journeys & views panel. Run mode: play a journey, jump to a saved view. Edit
// mode adds list-based journey authoring (steps with missing-view warnings,
// add-current-view) and "save view" — deliberately humble, no timeline UI
// (spec §4.3, DESIGN_BRIEF §4). Views carry their destroy (R3-607, R-IX-5): an
// inline confirm on the row, the same surface that creates them.
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
const fl = {
  font: 'var(--mono-xs)',
  letterSpacing: '.05em',
  textTransform: 'uppercase',
  color: 'var(--ink-3)'
};
const miniBtn = {
  display: 'inline-flex',
  alignItems: 'center',
  gap: 5,
  padding: '4px 9px',
  background: 'var(--bg)',
  border: '1px solid var(--line-2)',
  borderRadius: 'var(--r-pill)',
  color: 'var(--ink-2)',
  font: 'var(--mono-xs)',
  cursor: 'pointer'
};
function JourneysPanel() {
  _s();
  const wb = (0, _useLodestarCtx.useWb)();
  const {
    panelOpen,
    inspectorOpen,
    journeys,
    views,
    mode
  } = wb.state;
  if (!panelOpen) return null;
  const edit = mode === 'edit';
  const mobile = wb.isMobile();
  const wrapStyle = mobile ? {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    maxHeight: '64%',
    background: 'color-mix(in oklab, var(--panel) 97%, transparent)',
    borderTop: '1px solid var(--line-2)',
    borderRadius: '18px 18px 0 0',
    zIndex: 47,
    backdropFilter: 'blur(14px)',
    boxShadow: '0 -12px 34px rgba(0,0,0,.4)',
    overflowY: 'auto'
  } : {
    position: 'absolute',
    top: 72,
    right: inspectorOpen ? 340 : 16,
    bottom: 16,
    width: 300,
    background: 'color-mix(in oklab, var(--panel) 94%, transparent)',
    border: '1px solid var(--line)',
    borderRadius: 'var(--r-xl)',
    zIndex: 39,
    backdropFilter: 'blur(14px)',
    boxShadow: 'var(--shadow-pop)',
    overflowY: 'auto'
  };
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    className: "wb-scroll",
    style: wrapStyle,
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '16px 18px 12px',
        borderBottom: '1px solid var(--line)'
      },
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        style: {
          font: '700 16px/1 var(--disp)'
        },
        children: "Journeys & views"
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        onClick: wb.closePanel,
        style: {
          display: 'flex',
          padding: 5,
          background: 'none',
          border: 'none',
          color: 'var(--ink-3)',
          cursor: 'pointer'
        },
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
          name: "x",
          size: 16
        })
      })]
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      style: {
        padding: '14px 16px',
        display: 'flex',
        flexDirection: 'column',
        gap: 8
      },
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        style: {
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between'
        },
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
          style: fl,
          children: "Journeys"
        }), edit ? /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          onClick: () => wb.toast('Add a journey (authoring)', 'plus'),
          style: miniBtn,
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
            name: "plus",
            size: 13,
            strokeWidth: 2
          })
        }) : null]
      }), journeys.map(j => /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        style: {
          border: '1px solid var(--line)',
          borderRadius: 12,
          overflow: 'hidden',
          background: 'var(--bg)'
        },
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
          onClick: () => wb.playJourney(j.id),
          style: {
            display: 'flex',
            alignItems: 'center',
            gap: 10,
            width: '100%',
            padding: '11px 12px',
            background: 'none',
            border: 'none',
            color: 'var(--ink)',
            cursor: 'pointer',
            textAlign: 'left'
          },
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
            style: {
              display: 'flex',
              width: 30,
              height: 30,
              borderRadius: 8,
              background: 'var(--grad)',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#1a1020',
              flex: 'none'
            },
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
              name: "play",
              size: 14,
              color: "#1a1020",
              strokeWidth: 0
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
            style: {
              flex: 1
            },
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
              style: {
                font: '600 14px/1.2 var(--sans)'
              },
              children: j.title
            }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
              style: {
                font: 'var(--mono-xs)',
                color: 'var(--ink-3)',
                marginTop: 2
              },
              children: `${j.steps.length} steps`
            })]
          })]
        }), edit ? /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
          style: {
            padding: '0 10px 10px',
            display: 'flex',
            flexDirection: 'column',
            gap: 5
          },
          children: [j.steps.map((s, i) => /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
            style: {
              display: 'flex',
              alignItems: 'center',
              gap: 8,
              padding: '6px 8px',
              background: 'var(--panel)',
              border: '1px solid var(--line)',
              borderRadius: 8
            },
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
              style: {
                font: 'var(--mono-xs)',
                color: 'var(--ink-3)',
                width: 16
              },
              children: i + 1
            }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
              style: {
                flex: 1,
                font: 'var(--body-sm)',
                color: 'var(--ink-2)',
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                whiteSpace: 'nowrap'
              },
              children: typeof s.view === 'string' ? s.view : 'inline'
            }), wb.resolveView(s.view) ? null : /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
              title: "Missing view",
              style: {
                display: 'flex',
                color: '#caa24a'
              },
              children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
                name: "alert",
                size: 13,
                strokeWidth: 2
              })
            }), (0, _journey.implausibleDuration)(s.duration) ? /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
              title: `duration ${s.duration}ms is too small for a camera flight — unit error or typo (R3-402)`,
              style: {
                display: 'flex',
                color: '#caa24a'
              },
              children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
                name: "alert",
                size: 13,
                strokeWidth: 2
              })
            }) : null, /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
              style: {
                font: 'var(--mono-xs)',
                color: 'var(--ink-3)'
              },
              children: s.hold ? `hold ${s.hold}ms` : `${s.duration || 800}ms fly`
            })]
          }, i)), /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
            onClick: () => wb.addJourneyStep(j.id),
            style: {
              ...miniBtn,
              justifyContent: 'center',
              padding: 6
            },
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
              name: "plus",
              size: 13,
              strokeWidth: 2
            }), "Add current view"]
          })]
        }) : null]
      }, j.id))]
    }), /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      style: {
        padding: '4px 16px 18px',
        display: 'flex',
        flexDirection: 'column',
        gap: 8
      },
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        style: {
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between'
        },
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
          style: fl,
          children: "Views"
        }), edit ? /*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
          onClick: wb.saveView,
          style: miniBtn,
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
            name: "save",
            size: 13,
            strokeWidth: 1.75
          }), "Save"]
        }) : null]
      }), views.map(v => /*#__PURE__*/(0, _jsxRuntime.jsx)(ViewRow, {
        name: v.name,
        zoom: Math.round(v.zoom * 100)
      }, v.name))]
    })]
  });
}

/** One view row: jump to it, and (edit mode) remove it with an inline confirm —
 *  the LinkedIdentitiesCard shape: the affordance turns into its own
 *  confirmation rather than a dialog for a one-word decision. */
_s(JourneysPanel, "VeUy8AIV4bR/U9OnzH43HThc4KU=", false, function () {
  return [_useLodestarCtx.useWb];
});
_c = JourneysPanel;
function ViewRow({
  name,
  zoom
}) {
  _s2();
  const wb = (0, _useLodestarCtx.useWb)();
  const edit = wb.state.mode === 'edit';
  const [confirming, setConfirming] = (0, _react.useState)(false);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6
    },
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
      onClick: () => {
        setConfirming(false);
        const v = wb.state.views.find(x => x.name === name);
        if (v) wb.flyTo(v, 800);
      },
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 9,
        flex: 1,
        minWidth: 0,
        padding: '9px 11px',
        background: 'var(--bg)',
        border: '1px solid var(--line)',
        borderRadius: 9,
        color: 'var(--ink)',
        cursor: 'pointer',
        textAlign: 'left'
      },
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
        name: "inbox",
        size: 14,
        color: "var(--ink-3)",
        strokeWidth: 1.75
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        style: {
          flex: 1,
          font: 'var(--body-sm)',
          overflow: 'hidden',
          textOverflow: 'ellipsis',
          whiteSpace: 'nowrap'
        },
        children: name
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("span", {
        style: {
          font: 'var(--mono-xs)',
          color: 'var(--ink-3)'
        },
        children: `${zoom}%`
      })]
    }), edit ? confirming ? /*#__PURE__*/(0, _jsxRuntime.jsxs)("span", {
      style: {
        display: 'flex',
        gap: 4,
        flex: 'none'
      },
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("button", {
        onClick: () => {
          setConfirming(false);
          wb.deleteView(name);
        },
        "aria-label": `Confirm removing view ${name}`,
        style: {
          ...miniBtn,
          color: '#e07078',
          borderColor: 'color-mix(in oklab, #e0484f 35%, var(--line))'
        },
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
          name: "trash",
          size: 13,
          strokeWidth: 2
        }), "Remove"]
      }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
        onClick: () => setConfirming(false),
        style: miniBtn,
        children: "Keep"
      })]
    }) : /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
      onClick: () => setConfirming(true),
      "aria-label": `Remove view ${name}`,
      style: {
        ...miniBtn,
        padding: '6px 8px'
      },
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
        name: "trash",
        size: 13,
        strokeWidth: 1.75
      })
    }) : null]
  });
}
_s2(ViewRow, "uDwPgq7hrQvcbQseQdMBGsJKyqg=", false, function () {
  return [_useLodestarCtx.useWb];
});
_c2 = ViewRow;
var _default = exports.default = JourneysPanel;
var _c, _c2;
$RefreshReg$(_c, "JourneysPanel");
$RefreshReg$(_c2, "ViewRow");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3VzZUxvZGVzdGFyQ3R4IiwiX0ljb24iLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX2pvdXJuZXkiLCJfanN4UnVudGltZSIsIl9zIiwiJFJlZnJlc2hTaWckIiwiX3MyIiwiZSIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiZmwiLCJmb250IiwibGV0dGVyU3BhY2luZyIsInRleHRUcmFuc2Zvcm0iLCJjb2xvciIsIm1pbmlCdG4iLCJkaXNwbGF5IiwiYWxpZ25JdGVtcyIsImdhcCIsInBhZGRpbmciLCJiYWNrZ3JvdW5kIiwiYm9yZGVyIiwiYm9yZGVyUmFkaXVzIiwiY3Vyc29yIiwiSm91cm5leXNQYW5lbCIsIndiIiwidXNlV2IiLCJwYW5lbE9wZW4iLCJpbnNwZWN0b3JPcGVuIiwiam91cm5leXMiLCJ2aWV3cyIsIm1vZGUiLCJzdGF0ZSIsImVkaXQiLCJtb2JpbGUiLCJpc01vYmlsZSIsIndyYXBTdHlsZSIsInBvc2l0aW9uIiwibGVmdCIsInJpZ2h0IiwiYm90dG9tIiwibWF4SGVpZ2h0IiwiYm9yZGVyVG9wIiwiekluZGV4IiwiYmFja2Ryb3BGaWx0ZXIiLCJib3hTaGFkb3ciLCJvdmVyZmxvd1kiLCJ0b3AiLCJ3aWR0aCIsImpzeHMiLCJjbGFzc05hbWUiLCJzdHlsZSIsImNoaWxkcmVuIiwianVzdGlmeUNvbnRlbnQiLCJib3JkZXJCb3R0b20iLCJqc3giLCJvbkNsaWNrIiwiY2xvc2VQYW5lbCIsIm5hbWUiLCJzaXplIiwiZmxleERpcmVjdGlvbiIsInRvYXN0Iiwic3Ryb2tlV2lkdGgiLCJtYXAiLCJqIiwib3ZlcmZsb3ciLCJwbGF5Sm91cm5leSIsImlkIiwidGV4dEFsaWduIiwiaGVpZ2h0IiwiZmxleCIsInRpdGxlIiwibWFyZ2luVG9wIiwic3RlcHMiLCJsZW5ndGgiLCJzIiwiaSIsInRleHRPdmVyZmxvdyIsIndoaXRlU3BhY2UiLCJ2aWV3IiwicmVzb2x2ZVZpZXciLCJpbXBsYXVzaWJsZUR1cmF0aW9uIiwiZHVyYXRpb24iLCJob2xkIiwiYWRkSm91cm5leVN0ZXAiLCJzYXZlVmlldyIsInYiLCJWaWV3Um93Iiwiem9vbSIsIk1hdGgiLCJyb3VuZCIsIl9jIiwiY29uZmlybWluZyIsInNldENvbmZpcm1pbmciLCJ1c2VTdGF0ZSIsImZpbmQiLCJ4IiwiZmx5VG8iLCJtaW5XaWR0aCIsImRlbGV0ZVZpZXciLCJib3JkZXJDb2xvciIsIl9jMiIsIl9kZWZhdWx0IiwiZXhwb3J0cyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkpvdXJuZXlzUGFuZWwudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIEpvdXJuZXlzICYgdmlld3MgcGFuZWwuIFJ1biBtb2RlOiBwbGF5IGEgam91cm5leSwganVtcCB0byBhIHNhdmVkIHZpZXcuIEVkaXRcbi8vIG1vZGUgYWRkcyBsaXN0LWJhc2VkIGpvdXJuZXkgYXV0aG9yaW5nIChzdGVwcyB3aXRoIG1pc3NpbmctdmlldyB3YXJuaW5ncyxcbi8vIGFkZC1jdXJyZW50LXZpZXcpIGFuZCBcInNhdmUgdmlld1wiIOKAlCBkZWxpYmVyYXRlbHkgaHVtYmxlLCBubyB0aW1lbGluZSBVSVxuLy8gKHNwZWMgwqc0LjMsIERFU0lHTl9CUklFRiDCpzQpLiBWaWV3cyBjYXJyeSB0aGVpciBkZXN0cm95IChSMy02MDcsIFItSVgtNSk6IGFuXG4vLyBpbmxpbmUgY29uZmlybSBvbiB0aGUgcm93LCB0aGUgc2FtZSBzdXJmYWNlIHRoYXQgY3JlYXRlcyB0aGVtLlxuXG5pbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZVdiIH0gZnJvbSAnLi4vaG9va3MvdXNlTG9kZXN0YXJDdHgnO1xuaW1wb3J0IEljb24gZnJvbSAnLi9JY29uJztcbmltcG9ydCB7IGltcGxhdXNpYmxlRHVyYXRpb24gfSBmcm9tICcuLi9saWIvam91cm5leSc7XG5cbmNvbnN0IGZsOiBSZWFjdC5DU1NQcm9wZXJ0aWVzID0geyBmb250OiAndmFyKC0tbW9uby14cyknLCBsZXR0ZXJTcGFjaW5nOiAnLjA1ZW0nLCB0ZXh0VHJhbnNmb3JtOiAndXBwZXJjYXNlJywgY29sb3I6ICd2YXIoLS1pbmstMyknIH07XG5jb25zdCBtaW5pQnRuOiBSZWFjdC5DU1NQcm9wZXJ0aWVzID0geyBkaXNwbGF5OiAnaW5saW5lLWZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywgZ2FwOiA1LCBwYWRkaW5nOiAnNHB4IDlweCcsIGJhY2tncm91bmQ6ICd2YXIoLS1iZyknLCBib3JkZXI6ICcxcHggc29saWQgdmFyKC0tbGluZS0yKScsIGJvcmRlclJhZGl1czogJ3ZhcigtLXItcGlsbCknLCBjb2xvcjogJ3ZhcigtLWluay0yKScsIGZvbnQ6ICd2YXIoLS1tb25vLXhzKScsIGN1cnNvcjogJ3BvaW50ZXInIH07XG5cbmZ1bmN0aW9uIEpvdXJuZXlzUGFuZWwoKSB7XG4gIGNvbnN0IHdiID0gdXNlV2IoKTtcbiAgY29uc3QgeyBwYW5lbE9wZW4sIGluc3BlY3Rvck9wZW4sIGpvdXJuZXlzLCB2aWV3cywgbW9kZSB9ID0gd2Iuc3RhdGU7XG4gIGlmICghcGFuZWxPcGVuKSByZXR1cm4gbnVsbDtcbiAgY29uc3QgZWRpdCA9IG1vZGUgPT09ICdlZGl0JztcbiAgY29uc3QgbW9iaWxlID0gd2IuaXNNb2JpbGUoKTtcblxuICBjb25zdCB3cmFwU3R5bGU6IFJlYWN0LkNTU1Byb3BlcnRpZXMgPSBtb2JpbGVcbiAgICA/IHsgcG9zaXRpb246ICdhYnNvbHV0ZScsIGxlZnQ6IDAsIHJpZ2h0OiAwLCBib3R0b206IDAsIG1heEhlaWdodDogJzY0JScsIGJhY2tncm91bmQ6ICdjb2xvci1taXgoaW4gb2tsYWIsIHZhcigtLXBhbmVsKSA5NyUsIHRyYW5zcGFyZW50KScsIGJvcmRlclRvcDogJzFweCBzb2xpZCB2YXIoLS1saW5lLTIpJywgYm9yZGVyUmFkaXVzOiAnMThweCAxOHB4IDAgMCcsIHpJbmRleDogNDcsIGJhY2tkcm9wRmlsdGVyOiAnYmx1cigxNHB4KScsIGJveFNoYWRvdzogJzAgLTEycHggMzRweCByZ2JhKDAsMCwwLC40KScsIG92ZXJmbG93WTogJ2F1dG8nIH1cbiAgICA6IHsgcG9zaXRpb246ICdhYnNvbHV0ZScsIHRvcDogNzIsIHJpZ2h0OiBpbnNwZWN0b3JPcGVuID8gMzQwIDogMTYsIGJvdHRvbTogMTYsIHdpZHRoOiAzMDAsIGJhY2tncm91bmQ6ICdjb2xvci1taXgoaW4gb2tsYWIsIHZhcigtLXBhbmVsKSA5NCUsIHRyYW5zcGFyZW50KScsIGJvcmRlcjogJzFweCBzb2xpZCB2YXIoLS1saW5lKScsIGJvcmRlclJhZGl1czogJ3ZhcigtLXIteGwpJywgekluZGV4OiAzOSwgYmFja2Ryb3BGaWx0ZXI6ICdibHVyKDE0cHgpJywgYm94U2hhZG93OiAndmFyKC0tc2hhZG93LXBvcCknLCBvdmVyZmxvd1k6ICdhdXRvJyB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJ3Yi1zY3JvbGxcIiBzdHlsZT17d3JhcFN0eWxlfT5cbiAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywganVzdGlmeUNvbnRlbnQ6ICdzcGFjZS1iZXR3ZWVuJywgcGFkZGluZzogJzE2cHggMThweCAxMnB4JywgYm9yZGVyQm90dG9tOiAnMXB4IHNvbGlkIHZhcigtLWxpbmUpJyB9fT5cbiAgICAgICAgPGRpdiBzdHlsZT17eyBmb250OiAnNzAwIDE2cHgvMSB2YXIoLS1kaXNwKScgfX0+Sm91cm5leXMgJmFtcDsgdmlld3M8L2Rpdj5cbiAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXt3Yi5jbG9zZVBhbmVsfSBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIHBhZGRpbmc6IDUsIGJhY2tncm91bmQ6ICdub25lJywgYm9yZGVyOiAnbm9uZScsIGNvbG9yOiAndmFyKC0taW5rLTMpJywgY3Vyc29yOiAncG9pbnRlcicgfX0+XG4gICAgICAgICAgPEljb24gbmFtZT1cInhcIiBzaXplPXsxNn0gLz5cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBzdHlsZT17eyBwYWRkaW5nOiAnMTRweCAxNnB4JywgZGlzcGxheTogJ2ZsZXgnLCBmbGV4RGlyZWN0aW9uOiAnY29sdW1uJywgZ2FwOiA4IH19PlxuICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGp1c3RpZnlDb250ZW50OiAnc3BhY2UtYmV0d2VlbicgfX0+XG4gICAgICAgICAgPGRpdiBzdHlsZT17Zmx9PkpvdXJuZXlzPC9kaXY+XG4gICAgICAgICAge2VkaXQgPyAoXG4gICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHdiLnRvYXN0KCdBZGQgYSBqb3VybmV5IChhdXRob3JpbmcpJywgJ3BsdXMnKX0gc3R5bGU9e21pbmlCdG59PlxuICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwicGx1c1wiIHNpemU9ezEzfSBzdHJva2VXaWR0aD17Mn0gLz5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICkgOiBudWxsfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICAge2pvdXJuZXlzLm1hcCgoaikgPT4gKFxuICAgICAgICAgIDxkaXYga2V5PXtqLmlkfSBzdHlsZT17eyBib3JkZXI6ICcxcHggc29saWQgdmFyKC0tbGluZSknLCBib3JkZXJSYWRpdXM6IDEyLCBvdmVyZmxvdzogJ2hpZGRlbicsIGJhY2tncm91bmQ6ICd2YXIoLS1iZyknIH19PlxuICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiB3Yi5wbGF5Sm91cm5leShqLmlkKX0gc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywgZ2FwOiAxMCwgd2lkdGg6ICcxMDAlJywgcGFkZGluZzogJzExcHggMTJweCcsIGJhY2tncm91bmQ6ICdub25lJywgYm9yZGVyOiAnbm9uZScsIGNvbG9yOiAndmFyKC0taW5rKScsIGN1cnNvcjogJ3BvaW50ZXInLCB0ZXh0QWxpZ246ICdsZWZ0JyB9fT5cbiAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCB3aWR0aDogMzAsIGhlaWdodDogMzAsIGJvcmRlclJhZGl1czogOCwgYmFja2dyb3VuZDogJ3ZhcigtLWdyYWQpJywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGp1c3RpZnlDb250ZW50OiAnY2VudGVyJywgY29sb3I6ICcjMWExMDIwJywgZmxleDogJ25vbmUnIH19PlxuICAgICAgICAgICAgICAgIDxJY29uIG5hbWU9XCJwbGF5XCIgc2l6ZT17MTR9IGNvbG9yPVwiIzFhMTAyMFwiIHN0cm9rZVdpZHRoPXswfSAvPlxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGZsZXg6IDEgfX0+XG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250OiAnNjAwIDE0cHgvMS4yIHZhcigtLXNhbnMpJyB9fT57ai50aXRsZX08L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnQ6ICd2YXIoLS1tb25vLXhzKScsIGNvbG9yOiAndmFyKC0taW5rLTMpJywgbWFyZ2luVG9wOiAyIH19PntgJHtqLnN0ZXBzLmxlbmd0aH0gc3RlcHNgfTwvZGl2PlxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIHtlZGl0ID8gKFxuICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IHBhZGRpbmc6ICcwIDEwcHggMTBweCcsIGRpc3BsYXk6ICdmbGV4JywgZmxleERpcmVjdGlvbjogJ2NvbHVtbicsIGdhcDogNSB9fT5cbiAgICAgICAgICAgICAgICB7ai5zdGVwcy5tYXAoKHMsIGkpID0+IChcbiAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpfSBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBnYXA6IDgsIHBhZGRpbmc6ICc2cHggOHB4JywgYmFja2dyb3VuZDogJ3ZhcigtLXBhbmVsKScsIGJvcmRlcjogJzFweCBzb2xpZCB2YXIoLS1saW5lKScsIGJvcmRlclJhZGl1czogOCB9fT5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udDogJ3ZhcigtLW1vbm8teHMpJywgY29sb3I6ICd2YXIoLS1pbmstMyknLCB3aWR0aDogMTYgfX0+e2kgKyAxfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZmxleDogMSwgZm9udDogJ3ZhcigtLWJvZHktc20pJywgY29sb3I6ICd2YXIoLS1pbmstMiknLCBvdmVyZmxvdzogJ2hpZGRlbicsIHRleHRPdmVyZmxvdzogJ2VsbGlwc2lzJywgd2hpdGVTcGFjZTogJ25vd3JhcCcgfX0+XG4gICAgICAgICAgICAgICAgICAgICAge3R5cGVvZiBzLnZpZXcgPT09ICdzdHJpbmcnID8gcy52aWV3IDogJ2lubGluZSd9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAge3diLnJlc29sdmVWaWV3KHMudmlldykgPyBudWxsIDogKFxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIHRpdGxlPVwiTWlzc2luZyB2aWV3XCIgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBjb2xvcjogJyNjYWEyNGEnIH19PlxuICAgICAgICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cImFsZXJ0XCIgc2l6ZT17MTN9IHN0cm9rZVdpZHRoPXsyfSAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAge2ltcGxhdXNpYmxlRHVyYXRpb24ocy5kdXJhdGlvbikgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPXtgZHVyYXRpb24gJHtzLmR1cmF0aW9ufW1zIGlzIHRvbyBzbWFsbCBmb3IgYSBjYW1lcmEgZmxpZ2h0IOKAlCB1bml0IGVycm9yIG9yIHR5cG8gKFIzLTQwMilgfVxuICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBjb2xvcjogJyNjYWEyNGEnIH19XG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cImFsZXJ0XCIgc2l6ZT17MTN9IHN0cm9rZVdpZHRoPXsyfSAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgKSA6IG51bGx9XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnQ6ICd2YXIoLS1tb25vLXhzKScsIGNvbG9yOiAndmFyKC0taW5rLTMpJyB9fT5cbiAgICAgICAgICAgICAgICAgICAgICB7cy5ob2xkID8gYGhvbGQgJHtzLmhvbGR9bXNgIDogYCR7cy5kdXJhdGlvbiB8fCA4MDB9bXMgZmx5YH1cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiB3Yi5hZGRKb3VybmV5U3RlcChqLmlkKX0gc3R5bGU9e3sgLi4ubWluaUJ0biwganVzdGlmeUNvbnRlbnQ6ICdjZW50ZXInLCBwYWRkaW5nOiA2IH19PlxuICAgICAgICAgICAgICAgICAgPEljb24gbmFtZT1cInBsdXNcIiBzaXplPXsxM30gc3Ryb2tlV2lkdGg9ezJ9IC8+XG4gICAgICAgICAgICAgICAgICBBZGQgY3VycmVudCB2aWV3XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSA6IG51bGx9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICkpfVxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgc3R5bGU9e3sgcGFkZGluZzogJzRweCAxNnB4IDE4cHgnLCBkaXNwbGF5OiAnZmxleCcsIGZsZXhEaXJlY3Rpb246ICdjb2x1bW4nLCBnYXA6IDggfX0+XG4gICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywganVzdGlmeUNvbnRlbnQ6ICdzcGFjZS1iZXR3ZWVuJyB9fT5cbiAgICAgICAgICA8ZGl2IHN0eWxlPXtmbH0+Vmlld3M8L2Rpdj5cbiAgICAgICAgICB7ZWRpdCA/IChcbiAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17d2Iuc2F2ZVZpZXd9IHN0eWxlPXttaW5pQnRufT5cbiAgICAgICAgICAgICAgPEljb24gbmFtZT1cInNhdmVcIiBzaXplPXsxM30gc3Ryb2tlV2lkdGg9ezEuNzV9IC8+XG4gICAgICAgICAgICAgIFNhdmVcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICkgOiBudWxsfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICAge3ZpZXdzLm1hcCgodikgPT4gKFxuICAgICAgICAgIDxWaWV3Um93IGtleT17di5uYW1lfSBuYW1lPXt2Lm5hbWV9IHpvb209e01hdGgucm91bmQodi56b29tICogMTAwKX0gLz5cbiAgICAgICAgKSl9XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuLyoqIE9uZSB2aWV3IHJvdzoganVtcCB0byBpdCwgYW5kIChlZGl0IG1vZGUpIHJlbW92ZSBpdCB3aXRoIGFuIGlubGluZSBjb25maXJtIOKAlFxuICogIHRoZSBMaW5rZWRJZGVudGl0aWVzQ2FyZCBzaGFwZTogdGhlIGFmZm9yZGFuY2UgdHVybnMgaW50byBpdHMgb3duXG4gKiAgY29uZmlybWF0aW9uIHJhdGhlciB0aGFuIGEgZGlhbG9nIGZvciBhIG9uZS13b3JkIGRlY2lzaW9uLiAqL1xuZnVuY3Rpb24gVmlld1Jvdyh7IG5hbWUsIHpvb20gfTogeyBuYW1lOiBzdHJpbmc7IHpvb206IG51bWJlciB9KSB7XG4gIGNvbnN0IHdiID0gdXNlV2IoKTtcbiAgY29uc3QgZWRpdCA9IHdiLnN0YXRlLm1vZGUgPT09ICdlZGl0JztcbiAgY29uc3QgW2NvbmZpcm1pbmcsIHNldENvbmZpcm1pbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICByZXR1cm4gKFxuICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywgZ2FwOiA2IH19PlxuICAgICAgPGJ1dHRvblxuICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgc2V0Q29uZmlybWluZyhmYWxzZSk7XG4gICAgICAgICAgY29uc3QgdiA9IHdiLnN0YXRlLnZpZXdzLmZpbmQoKHgpID0+IHgubmFtZSA9PT0gbmFtZSk7XG4gICAgICAgICAgaWYgKHYpIHdiLmZseVRvKHYsIDgwMCk7XG4gICAgICAgIH19XG4gICAgICAgIHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGdhcDogOSwgZmxleDogMSwgbWluV2lkdGg6IDAsIHBhZGRpbmc6ICc5cHggMTFweCcsIGJhY2tncm91bmQ6ICd2YXIoLS1iZyknLCBib3JkZXI6ICcxcHggc29saWQgdmFyKC0tbGluZSknLCBib3JkZXJSYWRpdXM6IDksIGNvbG9yOiAndmFyKC0taW5rKScsIGN1cnNvcjogJ3BvaW50ZXInLCB0ZXh0QWxpZ246ICdsZWZ0JyB9fVxuICAgICAgPlxuICAgICAgICA8SWNvbiBuYW1lPVwiaW5ib3hcIiBzaXplPXsxNH0gY29sb3I9XCJ2YXIoLS1pbmstMylcIiBzdHJva2VXaWR0aD17MS43NX0gLz5cbiAgICAgICAgPHNwYW4gc3R5bGU9e3sgZmxleDogMSwgZm9udDogJ3ZhcigtLWJvZHktc20pJywgb3ZlcmZsb3c6ICdoaWRkZW4nLCB0ZXh0T3ZlcmZsb3c6ICdlbGxpcHNpcycsIHdoaXRlU3BhY2U6ICdub3dyYXAnIH19PntuYW1lfTwvc3Bhbj5cbiAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udDogJ3ZhcigtLW1vbm8teHMpJywgY29sb3I6ICd2YXIoLS1pbmstMyknIH19PntgJHt6b29tfSVgfTwvc3Bhbj5cbiAgICAgIDwvYnV0dG9uPlxuICAgICAge2VkaXQgPyAoXG4gICAgICAgIGNvbmZpcm1pbmcgPyAoXG4gICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBnYXA6IDQsIGZsZXg6ICdub25lJyB9fT5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgIHNldENvbmZpcm1pbmcoZmFsc2UpO1xuICAgICAgICAgICAgICAgIHdiLmRlbGV0ZVZpZXcobmFtZSk7XG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgIGFyaWEtbGFiZWw9e2BDb25maXJtIHJlbW92aW5nIHZpZXcgJHtuYW1lfWB9XG4gICAgICAgICAgICAgIHN0eWxlPXt7IC4uLm1pbmlCdG4sIGNvbG9yOiAnI2UwNzA3OCcsIGJvcmRlckNvbG9yOiAnY29sb3ItbWl4KGluIG9rbGFiLCAjZTA0ODRmIDM1JSwgdmFyKC0tbGluZSkpJyB9fVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwidHJhc2hcIiBzaXplPXsxM30gc3Ryb2tlV2lkdGg9ezJ9IC8+XG4gICAgICAgICAgICAgIFJlbW92ZVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldENvbmZpcm1pbmcoZmFsc2UpfSBzdHlsZT17bWluaUJ0bn0+XG4gICAgICAgICAgICAgIEtlZXBcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgKSA6IChcbiAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldENvbmZpcm1pbmcodHJ1ZSl9IGFyaWEtbGFiZWw9e2BSZW1vdmUgdmlldyAke25hbWV9YH0gc3R5bGU9e3sgLi4ubWluaUJ0biwgcGFkZGluZzogJzZweCA4cHgnIH19PlxuICAgICAgICAgICAgPEljb24gbmFtZT1cInRyYXNoXCIgc2l6ZT17MTN9IHN0cm9rZVdpZHRoPXsxLjc1fSAvPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICApXG4gICAgICApIDogbnVsbH1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgSm91cm5leXNQYW5lbDtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBTUEsSUFBQUEsTUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsZUFBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsS0FBQSxHQUFBQyxzQkFBQSxDQUFBSCxPQUFBO0FBQ0EsSUFBQUksUUFBQSxHQUFBSixPQUFBO0FBQXFELElBQUFLLFdBQUEsR0FBQUwsT0FBQTtBQUFBLElBQUFNLEVBQUEsR0FBQUMsWUFBQTtFQUFBQyxHQUFBLEdBQUFELFlBQUEsSUFUckQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUFBLFNBQUFKLHVCQUFBTSxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBT0EsTUFBTUcsRUFBdUIsR0FBRztFQUFFQyxJQUFJLEVBQUUsZ0JBQWdCO0VBQUVDLGFBQWEsRUFBRSxPQUFPO0VBQUVDLGFBQWEsRUFBRSxXQUFXO0VBQUVDLEtBQUssRUFBRTtBQUFlLENBQUM7QUFDckksTUFBTUMsT0FBNEIsR0FBRztFQUFFQyxPQUFPLEVBQUUsYUFBYTtFQUFFQyxVQUFVLEVBQUUsUUFBUTtFQUFFQyxHQUFHLEVBQUUsQ0FBQztFQUFFQyxPQUFPLEVBQUUsU0FBUztFQUFFQyxVQUFVLEVBQUUsV0FBVztFQUFFQyxNQUFNLEVBQUUseUJBQXlCO0VBQUVDLFlBQVksRUFBRSxlQUFlO0VBQUVSLEtBQUssRUFBRSxjQUFjO0VBQUVILElBQUksRUFBRSxnQkFBZ0I7RUFBRVksTUFBTSxFQUFFO0FBQVUsQ0FBQztBQUU5USxTQUFTQyxhQUFhQSxDQUFBLEVBQUc7RUFBQXBCLEVBQUE7RUFDdkIsTUFBTXFCLEVBQUUsR0FBRyxJQUFBQyxxQkFBSyxFQUFDLENBQUM7RUFDbEIsTUFBTTtJQUFFQyxTQUFTO0lBQUVDLGFBQWE7SUFBRUMsUUFBUTtJQUFFQyxLQUFLO0lBQUVDO0VBQUssQ0FBQyxHQUFHTixFQUFFLENBQUNPLEtBQUs7RUFDcEUsSUFBSSxDQUFDTCxTQUFTLEVBQUUsT0FBTyxJQUFJO0VBQzNCLE1BQU1NLElBQUksR0FBR0YsSUFBSSxLQUFLLE1BQU07RUFDNUIsTUFBTUcsTUFBTSxHQUFHVCxFQUFFLENBQUNVLFFBQVEsQ0FBQyxDQUFDO0VBRTVCLE1BQU1DLFNBQThCLEdBQUdGLE1BQU0sR0FDekM7SUFBRUcsUUFBUSxFQUFFLFVBQVU7SUFBRUMsSUFBSSxFQUFFLENBQUM7SUFBRUMsS0FBSyxFQUFFLENBQUM7SUFBRUMsTUFBTSxFQUFFLENBQUM7SUFBRUMsU0FBUyxFQUFFLEtBQUs7SUFBRXJCLFVBQVUsRUFBRSxvREFBb0Q7SUFBRXNCLFNBQVMsRUFBRSx5QkFBeUI7SUFBRXBCLFlBQVksRUFBRSxlQUFlO0lBQUVxQixNQUFNLEVBQUUsRUFBRTtJQUFFQyxjQUFjLEVBQUUsWUFBWTtJQUFFQyxTQUFTLEVBQUUsNkJBQTZCO0lBQUVDLFNBQVMsRUFBRTtFQUFPLENBQUMsR0FDdFQ7SUFBRVQsUUFBUSxFQUFFLFVBQVU7SUFBRVUsR0FBRyxFQUFFLEVBQUU7SUFBRVIsS0FBSyxFQUFFWCxhQUFhLEdBQUcsR0FBRyxHQUFHLEVBQUU7SUFBRVksTUFBTSxFQUFFLEVBQUU7SUFBRVEsS0FBSyxFQUFFLEdBQUc7SUFBRTVCLFVBQVUsRUFBRSxvREFBb0Q7SUFBRUMsTUFBTSxFQUFFLHVCQUF1QjtJQUFFQyxZQUFZLEVBQUUsYUFBYTtJQUFFcUIsTUFBTSxFQUFFLEVBQUU7SUFBRUMsY0FBYyxFQUFFLFlBQVk7SUFBRUMsU0FBUyxFQUFFLG1CQUFtQjtJQUFFQyxTQUFTLEVBQUU7RUFBTyxDQUFDO0VBRTNULG9CQUNFLElBQUEzQyxXQUFBLENBQUE4QyxJQUFBO0lBQUtDLFNBQVMsRUFBQyxXQUFXO0lBQUNDLEtBQUssRUFBRWYsU0FBVTtJQUFBZ0IsUUFBQSxnQkFDMUMsSUFBQWpELFdBQUEsQ0FBQThDLElBQUE7TUFBS0UsS0FBSyxFQUFFO1FBQUVuQyxPQUFPLEVBQUUsTUFBTTtRQUFFQyxVQUFVLEVBQUUsUUFBUTtRQUFFb0MsY0FBYyxFQUFFLGVBQWU7UUFBRWxDLE9BQU8sRUFBRSxnQkFBZ0I7UUFBRW1DLFlBQVksRUFBRTtNQUF3QixDQUFFO01BQUFGLFFBQUEsZ0JBQ3ZKLElBQUFqRCxXQUFBLENBQUFvRCxHQUFBO1FBQUtKLEtBQUssRUFBRTtVQUFFeEMsSUFBSSxFQUFFO1FBQXlCLENBQUU7UUFBQXlDLFFBQUEsRUFBQztNQUFvQixDQUFLLENBQUMsZUFDMUUsSUFBQWpELFdBQUEsQ0FBQW9ELEdBQUE7UUFBUUMsT0FBTyxFQUFFL0IsRUFBRSxDQUFDZ0MsVUFBVztRQUFDTixLQUFLLEVBQUU7VUFBRW5DLE9BQU8sRUFBRSxNQUFNO1VBQUVHLE9BQU8sRUFBRSxDQUFDO1VBQUVDLFVBQVUsRUFBRSxNQUFNO1VBQUVDLE1BQU0sRUFBRSxNQUFNO1VBQUVQLEtBQUssRUFBRSxjQUFjO1VBQUVTLE1BQU0sRUFBRTtRQUFVLENBQUU7UUFBQTZCLFFBQUEsZUFDbkosSUFBQWpELFdBQUEsQ0FBQW9ELEdBQUEsRUFBQ3ZELEtBQUEsQ0FBQVMsT0FBSTtVQUFDaUQsSUFBSSxFQUFDLEdBQUc7VUFBQ0MsSUFBSSxFQUFFO1FBQUcsQ0FBRTtNQUFDLENBQ3JCLENBQUM7SUFBQSxDQUNOLENBQUMsZUFFTixJQUFBeEQsV0FBQSxDQUFBOEMsSUFBQTtNQUFLRSxLQUFLLEVBQUU7UUFBRWhDLE9BQU8sRUFBRSxXQUFXO1FBQUVILE9BQU8sRUFBRSxNQUFNO1FBQUU0QyxhQUFhLEVBQUUsUUFBUTtRQUFFMUMsR0FBRyxFQUFFO01BQUUsQ0FBRTtNQUFBa0MsUUFBQSxnQkFDckYsSUFBQWpELFdBQUEsQ0FBQThDLElBQUE7UUFBS0UsS0FBSyxFQUFFO1VBQUVuQyxPQUFPLEVBQUUsTUFBTTtVQUFFQyxVQUFVLEVBQUUsUUFBUTtVQUFFb0MsY0FBYyxFQUFFO1FBQWdCLENBQUU7UUFBQUQsUUFBQSxnQkFDckYsSUFBQWpELFdBQUEsQ0FBQW9ELEdBQUE7VUFBS0osS0FBSyxFQUFFekMsRUFBRztVQUFBMEMsUUFBQSxFQUFDO1FBQVEsQ0FBSyxDQUFDLEVBQzdCbkIsSUFBSSxnQkFDSCxJQUFBOUIsV0FBQSxDQUFBb0QsR0FBQTtVQUFRQyxPQUFPLEVBQUVBLENBQUEsS0FBTS9CLEVBQUUsQ0FBQ29DLEtBQUssQ0FBQywyQkFBMkIsRUFBRSxNQUFNLENBQUU7VUFBQ1YsS0FBSyxFQUFFcEMsT0FBUTtVQUFBcUMsUUFBQSxlQUNuRixJQUFBakQsV0FBQSxDQUFBb0QsR0FBQSxFQUFDdkQsS0FBQSxDQUFBUyxPQUFJO1lBQUNpRCxJQUFJLEVBQUMsTUFBTTtZQUFDQyxJQUFJLEVBQUUsRUFBRztZQUFDRyxXQUFXLEVBQUU7VUFBRSxDQUFFO1FBQUMsQ0FDeEMsQ0FBQyxHQUNQLElBQUk7TUFBQSxDQUNMLENBQUMsRUFDTGpDLFFBQVEsQ0FBQ2tDLEdBQUcsQ0FBRUMsQ0FBQyxpQkFDZCxJQUFBN0QsV0FBQSxDQUFBOEMsSUFBQTtRQUFnQkUsS0FBSyxFQUFFO1VBQUU5QixNQUFNLEVBQUUsdUJBQXVCO1VBQUVDLFlBQVksRUFBRSxFQUFFO1VBQUUyQyxRQUFRLEVBQUUsUUFBUTtVQUFFN0MsVUFBVSxFQUFFO1FBQVksQ0FBRTtRQUFBZ0MsUUFBQSxnQkFDeEgsSUFBQWpELFdBQUEsQ0FBQThDLElBQUE7VUFBUU8sT0FBTyxFQUFFQSxDQUFBLEtBQU0vQixFQUFFLENBQUN5QyxXQUFXLENBQUNGLENBQUMsQ0FBQ0csRUFBRSxDQUFFO1VBQUNoQixLQUFLLEVBQUU7WUFBRW5DLE9BQU8sRUFBRSxNQUFNO1lBQUVDLFVBQVUsRUFBRSxRQUFRO1lBQUVDLEdBQUcsRUFBRSxFQUFFO1lBQUU4QixLQUFLLEVBQUUsTUFBTTtZQUFFN0IsT0FBTyxFQUFFLFdBQVc7WUFBRUMsVUFBVSxFQUFFLE1BQU07WUFBRUMsTUFBTSxFQUFFLE1BQU07WUFBRVAsS0FBSyxFQUFFLFlBQVk7WUFBRVMsTUFBTSxFQUFFLFNBQVM7WUFBRTZDLFNBQVMsRUFBRTtVQUFPLENBQUU7VUFBQWhCLFFBQUEsZ0JBQ3pPLElBQUFqRCxXQUFBLENBQUFvRCxHQUFBO1lBQU1KLEtBQUssRUFBRTtjQUFFbkMsT0FBTyxFQUFFLE1BQU07Y0FBRWdDLEtBQUssRUFBRSxFQUFFO2NBQUVxQixNQUFNLEVBQUUsRUFBRTtjQUFFL0MsWUFBWSxFQUFFLENBQUM7Y0FBRUYsVUFBVSxFQUFFLGFBQWE7Y0FBRUgsVUFBVSxFQUFFLFFBQVE7Y0FBRW9DLGNBQWMsRUFBRSxRQUFRO2NBQUV2QyxLQUFLLEVBQUUsU0FBUztjQUFFd0QsSUFBSSxFQUFFO1lBQU8sQ0FBRTtZQUFBbEIsUUFBQSxlQUNsTCxJQUFBakQsV0FBQSxDQUFBb0QsR0FBQSxFQUFDdkQsS0FBQSxDQUFBUyxPQUFJO2NBQUNpRCxJQUFJLEVBQUMsTUFBTTtjQUFDQyxJQUFJLEVBQUUsRUFBRztjQUFDN0MsS0FBSyxFQUFDLFNBQVM7Y0FBQ2dELFdBQVcsRUFBRTtZQUFFLENBQUU7VUFBQyxDQUMxRCxDQUFDLGVBQ1AsSUFBQTNELFdBQUEsQ0FBQThDLElBQUE7WUFBTUUsS0FBSyxFQUFFO2NBQUVtQixJQUFJLEVBQUU7WUFBRSxDQUFFO1lBQUFsQixRQUFBLGdCQUN2QixJQUFBakQsV0FBQSxDQUFBb0QsR0FBQTtjQUFLSixLQUFLLEVBQUU7Z0JBQUV4QyxJQUFJLEVBQUU7Y0FBMkIsQ0FBRTtjQUFBeUMsUUFBQSxFQUFFWSxDQUFDLENBQUNPO1lBQUssQ0FBTSxDQUFDLGVBQ2pFLElBQUFwRSxXQUFBLENBQUFvRCxHQUFBO2NBQUtKLEtBQUssRUFBRTtnQkFBRXhDLElBQUksRUFBRSxnQkFBZ0I7Z0JBQUVHLEtBQUssRUFBRSxjQUFjO2dCQUFFMEQsU0FBUyxFQUFFO2NBQUUsQ0FBRTtjQUFBcEIsUUFBQSxFQUFFLEdBQUdZLENBQUMsQ0FBQ1MsS0FBSyxDQUFDQyxNQUFNO1lBQVEsQ0FBTSxDQUFDO1VBQUEsQ0FDMUcsQ0FBQztRQUFBLENBQ0QsQ0FBQyxFQUNSekMsSUFBSSxnQkFDSCxJQUFBOUIsV0FBQSxDQUFBOEMsSUFBQTtVQUFLRSxLQUFLLEVBQUU7WUFBRWhDLE9BQU8sRUFBRSxhQUFhO1lBQUVILE9BQU8sRUFBRSxNQUFNO1lBQUU0QyxhQUFhLEVBQUUsUUFBUTtZQUFFMUMsR0FBRyxFQUFFO1VBQUUsQ0FBRTtVQUFBa0MsUUFBQSxHQUN0RlksQ0FBQyxDQUFDUyxLQUFLLENBQUNWLEdBQUcsQ0FBQyxDQUFDWSxDQUFDLEVBQUVDLENBQUMsa0JBQ2hCLElBQUF6RSxXQUFBLENBQUE4QyxJQUFBO1lBQWFFLEtBQUssRUFBRTtjQUFFbkMsT0FBTyxFQUFFLE1BQU07Y0FBRUMsVUFBVSxFQUFFLFFBQVE7Y0FBRUMsR0FBRyxFQUFFLENBQUM7Y0FBRUMsT0FBTyxFQUFFLFNBQVM7Y0FBRUMsVUFBVSxFQUFFLGNBQWM7Y0FBRUMsTUFBTSxFQUFFLHVCQUF1QjtjQUFFQyxZQUFZLEVBQUU7WUFBRSxDQUFFO1lBQUE4QixRQUFBLGdCQUN0SyxJQUFBakQsV0FBQSxDQUFBb0QsR0FBQTtjQUFNSixLQUFLLEVBQUU7Z0JBQUV4QyxJQUFJLEVBQUUsZ0JBQWdCO2dCQUFFRyxLQUFLLEVBQUUsY0FBYztnQkFBRWtDLEtBQUssRUFBRTtjQUFHLENBQUU7Y0FBQUksUUFBQSxFQUFFd0IsQ0FBQyxHQUFHO1lBQUMsQ0FBTyxDQUFDLGVBQ3pGLElBQUF6RSxXQUFBLENBQUFvRCxHQUFBO2NBQU1KLEtBQUssRUFBRTtnQkFBRW1CLElBQUksRUFBRSxDQUFDO2dCQUFFM0QsSUFBSSxFQUFFLGdCQUFnQjtnQkFBRUcsS0FBSyxFQUFFLGNBQWM7Z0JBQUVtRCxRQUFRLEVBQUUsUUFBUTtnQkFBRVksWUFBWSxFQUFFLFVBQVU7Z0JBQUVDLFVBQVUsRUFBRTtjQUFTLENBQUU7Y0FBQTFCLFFBQUEsRUFDekksT0FBT3VCLENBQUMsQ0FBQ0ksSUFBSSxLQUFLLFFBQVEsR0FBR0osQ0FBQyxDQUFDSSxJQUFJLEdBQUc7WUFBUSxDQUMzQyxDQUFDLEVBQ050RCxFQUFFLENBQUN1RCxXQUFXLENBQUNMLENBQUMsQ0FBQ0ksSUFBSSxDQUFDLEdBQUcsSUFBSSxnQkFDNUIsSUFBQTVFLFdBQUEsQ0FBQW9ELEdBQUE7Y0FBTWdCLEtBQUssRUFBQyxjQUFjO2NBQUNwQixLQUFLLEVBQUU7Z0JBQUVuQyxPQUFPLEVBQUUsTUFBTTtnQkFBRUYsS0FBSyxFQUFFO2NBQVUsQ0FBRTtjQUFBc0MsUUFBQSxlQUN0RSxJQUFBakQsV0FBQSxDQUFBb0QsR0FBQSxFQUFDdkQsS0FBQSxDQUFBUyxPQUFJO2dCQUFDaUQsSUFBSSxFQUFDLE9BQU87Z0JBQUNDLElBQUksRUFBRSxFQUFHO2dCQUFDRyxXQUFXLEVBQUU7Y0FBRSxDQUFFO1lBQUMsQ0FDM0MsQ0FDUCxFQUNBLElBQUFtQiw0QkFBbUIsRUFBQ04sQ0FBQyxDQUFDTyxRQUFRLENBQUMsZ0JBQzlCLElBQUEvRSxXQUFBLENBQUFvRCxHQUFBO2NBQ0VnQixLQUFLLEVBQUUsWUFBWUksQ0FBQyxDQUFDTyxRQUFRLG1FQUFvRTtjQUNqRy9CLEtBQUssRUFBRTtnQkFBRW5DLE9BQU8sRUFBRSxNQUFNO2dCQUFFRixLQUFLLEVBQUU7Y0FBVSxDQUFFO2NBQUFzQyxRQUFBLGVBRTdDLElBQUFqRCxXQUFBLENBQUFvRCxHQUFBLEVBQUN2RCxLQUFBLENBQUFTLE9BQUk7Z0JBQUNpRCxJQUFJLEVBQUMsT0FBTztnQkFBQ0MsSUFBSSxFQUFFLEVBQUc7Z0JBQUNHLFdBQVcsRUFBRTtjQUFFLENBQUU7WUFBQyxDQUMzQyxDQUFDLEdBQ0wsSUFBSSxlQUNSLElBQUEzRCxXQUFBLENBQUFvRCxHQUFBO2NBQU1KLEtBQUssRUFBRTtnQkFBRXhDLElBQUksRUFBRSxnQkFBZ0I7Z0JBQUVHLEtBQUssRUFBRTtjQUFlLENBQUU7Y0FBQXNDLFFBQUEsRUFDNUR1QixDQUFDLENBQUNRLElBQUksR0FBRyxRQUFRUixDQUFDLENBQUNRLElBQUksSUFBSSxHQUFHLEdBQUdSLENBQUMsQ0FBQ08sUUFBUSxJQUFJLEdBQUc7WUFBUSxDQUN2RCxDQUFDO1VBQUEsR0FwQkNOLENBcUJMLENBQ04sQ0FBQyxlQUNGLElBQUF6RSxXQUFBLENBQUE4QyxJQUFBO1lBQVFPLE9BQU8sRUFBRUEsQ0FBQSxLQUFNL0IsRUFBRSxDQUFDMkQsY0FBYyxDQUFDcEIsQ0FBQyxDQUFDRyxFQUFFLENBQUU7WUFBQ2hCLEtBQUssRUFBRTtjQUFFLEdBQUdwQyxPQUFPO2NBQUVzQyxjQUFjLEVBQUUsUUFBUTtjQUFFbEMsT0FBTyxFQUFFO1lBQUUsQ0FBRTtZQUFBaUMsUUFBQSxnQkFDMUcsSUFBQWpELFdBQUEsQ0FBQW9ELEdBQUEsRUFBQ3ZELEtBQUEsQ0FBQVMsT0FBSTtjQUFDaUQsSUFBSSxFQUFDLE1BQU07Y0FBQ0MsSUFBSSxFQUFFLEVBQUc7Y0FBQ0csV0FBVyxFQUFFO1lBQUUsQ0FBRSxDQUFDLG9CQUVoRDtVQUFBLENBQVEsQ0FBQztRQUFBLENBQ04sQ0FBQyxHQUNKLElBQUk7TUFBQSxHQXpDQUUsQ0FBQyxDQUFDRyxFQTBDUCxDQUNOLENBQUM7SUFBQSxDQUNDLENBQUMsZUFFTixJQUFBaEUsV0FBQSxDQUFBOEMsSUFBQTtNQUFLRSxLQUFLLEVBQUU7UUFBRWhDLE9BQU8sRUFBRSxlQUFlO1FBQUVILE9BQU8sRUFBRSxNQUFNO1FBQUU0QyxhQUFhLEVBQUUsUUFBUTtRQUFFMUMsR0FBRyxFQUFFO01BQUUsQ0FBRTtNQUFBa0MsUUFBQSxnQkFDekYsSUFBQWpELFdBQUEsQ0FBQThDLElBQUE7UUFBS0UsS0FBSyxFQUFFO1VBQUVuQyxPQUFPLEVBQUUsTUFBTTtVQUFFQyxVQUFVLEVBQUUsUUFBUTtVQUFFb0MsY0FBYyxFQUFFO1FBQWdCLENBQUU7UUFBQUQsUUFBQSxnQkFDckYsSUFBQWpELFdBQUEsQ0FBQW9ELEdBQUE7VUFBS0osS0FBSyxFQUFFekMsRUFBRztVQUFBMEMsUUFBQSxFQUFDO1FBQUssQ0FBSyxDQUFDLEVBQzFCbkIsSUFBSSxnQkFDSCxJQUFBOUIsV0FBQSxDQUFBOEMsSUFBQTtVQUFRTyxPQUFPLEVBQUUvQixFQUFFLENBQUM0RCxRQUFTO1VBQUNsQyxLQUFLLEVBQUVwQyxPQUFRO1VBQUFxQyxRQUFBLGdCQUMzQyxJQUFBakQsV0FBQSxDQUFBb0QsR0FBQSxFQUFDdkQsS0FBQSxDQUFBUyxPQUFJO1lBQUNpRCxJQUFJLEVBQUMsTUFBTTtZQUFDQyxJQUFJLEVBQUUsRUFBRztZQUFDRyxXQUFXLEVBQUU7VUFBSyxDQUFFLENBQUMsUUFFbkQ7UUFBQSxDQUFRLENBQUMsR0FDUCxJQUFJO01BQUEsQ0FDTCxDQUFDLEVBQ0xoQyxLQUFLLENBQUNpQyxHQUFHLENBQUV1QixDQUFDLGlCQUNYLElBQUFuRixXQUFBLENBQUFvRCxHQUFBLEVBQUNnQyxPQUFPO1FBQWM3QixJQUFJLEVBQUU0QixDQUFDLENBQUM1QixJQUFLO1FBQUM4QixJQUFJLEVBQUVDLElBQUksQ0FBQ0MsS0FBSyxDQUFDSixDQUFDLENBQUNFLElBQUksR0FBRyxHQUFHO01BQUUsR0FBckRGLENBQUMsQ0FBQzVCLElBQXFELENBQ3RFLENBQUM7SUFBQSxDQUNDLENBQUM7RUFBQSxDQUNILENBQUM7QUFFVjs7QUFFQTtBQUNBO0FBQ0E7QUFGQXRELEVBQUEsQ0E5RlNvQixhQUFhO0VBQUEsUUFDVEUscUJBQUs7QUFBQTtBQUFBaUUsRUFBQSxHQURUbkUsYUFBYTtBQWlHdEIsU0FBUytELE9BQU9BLENBQUM7RUFBRTdCLElBQUk7RUFBRThCO0FBQXFDLENBQUMsRUFBRTtFQUFBbEYsR0FBQTtFQUMvRCxNQUFNbUIsRUFBRSxHQUFHLElBQUFDLHFCQUFLLEVBQUMsQ0FBQztFQUNsQixNQUFNTyxJQUFJLEdBQUdSLEVBQUUsQ0FBQ08sS0FBSyxDQUFDRCxJQUFJLEtBQUssTUFBTTtFQUNyQyxNQUFNLENBQUM2RCxVQUFVLEVBQUVDLGFBQWEsQ0FBQyxHQUFHLElBQUFDLGVBQVEsRUFBQyxLQUFLLENBQUM7RUFDbkQsb0JBQ0UsSUFBQTNGLFdBQUEsQ0FBQThDLElBQUE7SUFBS0UsS0FBSyxFQUFFO01BQUVuQyxPQUFPLEVBQUUsTUFBTTtNQUFFQyxVQUFVLEVBQUUsUUFBUTtNQUFFQyxHQUFHLEVBQUU7SUFBRSxDQUFFO0lBQUFrQyxRQUFBLGdCQUM1RCxJQUFBakQsV0FBQSxDQUFBOEMsSUFBQTtNQUNFTyxPQUFPLEVBQUVBLENBQUEsS0FBTTtRQUNicUMsYUFBYSxDQUFDLEtBQUssQ0FBQztRQUNwQixNQUFNUCxDQUFDLEdBQUc3RCxFQUFFLENBQUNPLEtBQUssQ0FBQ0YsS0FBSyxDQUFDaUUsSUFBSSxDQUFFQyxDQUFDLElBQUtBLENBQUMsQ0FBQ3RDLElBQUksS0FBS0EsSUFBSSxDQUFDO1FBQ3JELElBQUk0QixDQUFDLEVBQUU3RCxFQUFFLENBQUN3RSxLQUFLLENBQUNYLENBQUMsRUFBRSxHQUFHLENBQUM7TUFDekIsQ0FBRTtNQUNGbkMsS0FBSyxFQUFFO1FBQUVuQyxPQUFPLEVBQUUsTUFBTTtRQUFFQyxVQUFVLEVBQUUsUUFBUTtRQUFFQyxHQUFHLEVBQUUsQ0FBQztRQUFFb0QsSUFBSSxFQUFFLENBQUM7UUFBRTRCLFFBQVEsRUFBRSxDQUFDO1FBQUUvRSxPQUFPLEVBQUUsVUFBVTtRQUFFQyxVQUFVLEVBQUUsV0FBVztRQUFFQyxNQUFNLEVBQUUsdUJBQXVCO1FBQUVDLFlBQVksRUFBRSxDQUFDO1FBQUVSLEtBQUssRUFBRSxZQUFZO1FBQUVTLE1BQU0sRUFBRSxTQUFTO1FBQUU2QyxTQUFTLEVBQUU7TUFBTyxDQUFFO01BQUFoQixRQUFBLGdCQUUxTyxJQUFBakQsV0FBQSxDQUFBb0QsR0FBQSxFQUFDdkQsS0FBQSxDQUFBUyxPQUFJO1FBQUNpRCxJQUFJLEVBQUMsT0FBTztRQUFDQyxJQUFJLEVBQUUsRUFBRztRQUFDN0MsS0FBSyxFQUFDLGNBQWM7UUFBQ2dELFdBQVcsRUFBRTtNQUFLLENBQUUsQ0FBQyxlQUN2RSxJQUFBM0QsV0FBQSxDQUFBb0QsR0FBQTtRQUFNSixLQUFLLEVBQUU7VUFBRW1CLElBQUksRUFBRSxDQUFDO1VBQUUzRCxJQUFJLEVBQUUsZ0JBQWdCO1VBQUVzRCxRQUFRLEVBQUUsUUFBUTtVQUFFWSxZQUFZLEVBQUUsVUFBVTtVQUFFQyxVQUFVLEVBQUU7UUFBUyxDQUFFO1FBQUExQixRQUFBLEVBQUVNO01BQUksQ0FBTyxDQUFDLGVBQ25JLElBQUF2RCxXQUFBLENBQUFvRCxHQUFBO1FBQU1KLEtBQUssRUFBRTtVQUFFeEMsSUFBSSxFQUFFLGdCQUFnQjtVQUFFRyxLQUFLLEVBQUU7UUFBZSxDQUFFO1FBQUFzQyxRQUFBLEVBQUUsR0FBR29DLElBQUk7TUFBRyxDQUFPLENBQUM7SUFBQSxDQUM3RSxDQUFDLEVBQ1J2RCxJQUFJLEdBQ0gyRCxVQUFVLGdCQUNSLElBQUF6RixXQUFBLENBQUE4QyxJQUFBO01BQU1FLEtBQUssRUFBRTtRQUFFbkMsT0FBTyxFQUFFLE1BQU07UUFBRUUsR0FBRyxFQUFFLENBQUM7UUFBRW9ELElBQUksRUFBRTtNQUFPLENBQUU7TUFBQWxCLFFBQUEsZ0JBQ3JELElBQUFqRCxXQUFBLENBQUE4QyxJQUFBO1FBQ0VPLE9BQU8sRUFBRUEsQ0FBQSxLQUFNO1VBQ2JxQyxhQUFhLENBQUMsS0FBSyxDQUFDO1VBQ3BCcEUsRUFBRSxDQUFDMEUsVUFBVSxDQUFDekMsSUFBSSxDQUFDO1FBQ3JCLENBQUU7UUFDRixjQUFZLHlCQUF5QkEsSUFBSSxFQUFHO1FBQzVDUCxLQUFLLEVBQUU7VUFBRSxHQUFHcEMsT0FBTztVQUFFRCxLQUFLLEVBQUUsU0FBUztVQUFFc0YsV0FBVyxFQUFFO1FBQWdELENBQUU7UUFBQWhELFFBQUEsZ0JBRXRHLElBQUFqRCxXQUFBLENBQUFvRCxHQUFBLEVBQUN2RCxLQUFBLENBQUFTLE9BQUk7VUFBQ2lELElBQUksRUFBQyxPQUFPO1VBQUNDLElBQUksRUFBRSxFQUFHO1VBQUNHLFdBQVcsRUFBRTtRQUFFLENBQUUsQ0FBQyxVQUVqRDtNQUFBLENBQVEsQ0FBQyxlQUNULElBQUEzRCxXQUFBLENBQUFvRCxHQUFBO1FBQVFDLE9BQU8sRUFBRUEsQ0FBQSxLQUFNcUMsYUFBYSxDQUFDLEtBQUssQ0FBRTtRQUFDMUMsS0FBSyxFQUFFcEMsT0FBUTtRQUFBcUMsUUFBQSxFQUFDO01BRTdELENBQVEsQ0FBQztJQUFBLENBQ0wsQ0FBQyxnQkFFUCxJQUFBakQsV0FBQSxDQUFBb0QsR0FBQTtNQUFRQyxPQUFPLEVBQUVBLENBQUEsS0FBTXFDLGFBQWEsQ0FBQyxJQUFJLENBQUU7TUFBQyxjQUFZLGVBQWVuQyxJQUFJLEVBQUc7TUFBQ1AsS0FBSyxFQUFFO1FBQUUsR0FBR3BDLE9BQU87UUFBRUksT0FBTyxFQUFFO01BQVUsQ0FBRTtNQUFBaUMsUUFBQSxlQUN2SCxJQUFBakQsV0FBQSxDQUFBb0QsR0FBQSxFQUFDdkQsS0FBQSxDQUFBUyxPQUFJO1FBQUNpRCxJQUFJLEVBQUMsT0FBTztRQUFDQyxJQUFJLEVBQUUsRUFBRztRQUFDRyxXQUFXLEVBQUU7TUFBSyxDQUFFO0lBQUMsQ0FDNUMsQ0FDVCxHQUNDLElBQUk7RUFBQSxDQUNMLENBQUM7QUFFVjtBQUFDeEQsR0FBQSxDQTVDUWlGLE9BQU87RUFBQSxRQUNIN0QscUJBQUs7QUFBQTtBQUFBMkUsR0FBQSxHQURUZCxPQUFPO0FBQUEsSUFBQWUsUUFBQSxHQUFBQyxPQUFBLENBQUE5RixPQUFBLEdBOENEZSxhQUFhO0FBQUEsSUFBQW1FLEVBQUEsRUFBQVUsR0FBQTtBQUFBRyxZQUFBLENBQUFiLEVBQUE7QUFBQWEsWUFBQSxDQUFBSCxHQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}