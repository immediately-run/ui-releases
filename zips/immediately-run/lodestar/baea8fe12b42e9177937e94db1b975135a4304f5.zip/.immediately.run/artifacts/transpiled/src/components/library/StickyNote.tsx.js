var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _Badges = _interopRequireDefault(require("../Badges"));
var _color = require("../../lib/color");
var _geometry = require("../../lib/geometry");
var _jsxRuntime = require("react/jsx-runtime");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// THE signature object (DESIGN_BRIEF §1): a colored note card with the brand's
// asymmetric dog-ear corner and cheap hard-offset shadow. Color is a palette
// token (`var(--n-<color>)`), never hex-in-place.

function StickyNote({
  o,
  objects
}) {
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: (0, _color.noteColorToken)(o.color),
      color: 'var(--note-ink)',
      borderRadius: '2px 2px 2px 16px',
      padding: '14px 15px',
      boxShadow: 'var(--note-shadow)',
      display: 'flex',
      flexDirection: 'column',
      gap: 7,
      overflow: 'hidden'
    },
    children: [o.tags && !(0, _geometry.tagChipSuppressed)(o, objects) ? /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      style: {
        font: 'var(--mono-xs)',
        letterSpacing: '.05em',
        textTransform: 'uppercase',
        opacity: 0.5
      },
      children: `#${o.tags}`
    }) : null, /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      style: {
        font: '600 16.5px/1.3 var(--sans)',
        textWrap: 'pretty'
      },
      children: o.title
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_Badges.default, {
      o: o
    })]
  });
}
_c = StickyNote;
var _default = exports.default = StickyNote;
var _c;
$RefreshReg$(_c, "StickyNote");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfQmFkZ2VzIiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsInJlcXVpcmUiLCJfY29sb3IiLCJfZ2VvbWV0cnkiLCJfanN4UnVudGltZSIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsIlN0aWNreU5vdGUiLCJvIiwib2JqZWN0cyIsImpzeHMiLCJzdHlsZSIsInBvc2l0aW9uIiwiaW5zZXQiLCJiYWNrZ3JvdW5kIiwibm90ZUNvbG9yVG9rZW4iLCJjb2xvciIsImJvcmRlclJhZGl1cyIsInBhZGRpbmciLCJib3hTaGFkb3ciLCJkaXNwbGF5IiwiZmxleERpcmVjdGlvbiIsImdhcCIsIm92ZXJmbG93IiwiY2hpbGRyZW4iLCJ0YWdzIiwidGFnQ2hpcFN1cHByZXNzZWQiLCJqc3giLCJmb250IiwibGV0dGVyU3BhY2luZyIsInRleHRUcmFuc2Zvcm0iLCJvcGFjaXR5IiwidGV4dFdyYXAiLCJ0aXRsZSIsIl9jIiwiX2RlZmF1bHQiLCJleHBvcnRzIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiU3RpY2t5Tm90ZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gVEhFIHNpZ25hdHVyZSBvYmplY3QgKERFU0lHTl9CUklFRiDCpzEpOiBhIGNvbG9yZWQgbm90ZSBjYXJkIHdpdGggdGhlIGJyYW5kJ3Ncbi8vIGFzeW1tZXRyaWMgZG9nLWVhciBjb3JuZXIgYW5kIGNoZWFwIGhhcmQtb2Zmc2V0IHNoYWRvdy4gQ29sb3IgaXMgYSBwYWxldHRlXG4vLyB0b2tlbiAoYHZhcigtLW4tPGNvbG9yPilgKSwgbmV2ZXIgaGV4LWluLXBsYWNlLlxuXG5pbXBvcnQgQmFkZ2VzIGZyb20gJy4uL0JhZGdlcyc7XG5pbXBvcnQgdHlwZSB7IFdPYmplY3QgfSBmcm9tICcuLi8uLi9saWIvdHlwZXMnO1xuaW1wb3J0IHsgbm90ZUNvbG9yVG9rZW4gfSBmcm9tICcuLi8uLi9saWIvY29sb3InO1xuaW1wb3J0IHsgdGFnQ2hpcFN1cHByZXNzZWQgfSBmcm9tICcuLi8uLi9saWIvZ2VvbWV0cnknO1xuXG5mdW5jdGlvbiBTdGlja3lOb3RlKHsgbywgb2JqZWN0cyB9OiB7IG86IFdPYmplY3Q7IG9iamVjdHM6IFdPYmplY3RbXSB9KSB7XG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgc3R5bGU9e3tcbiAgICAgICAgcG9zaXRpb246ICdhYnNvbHV0ZScsXG4gICAgICAgIGluc2V0OiAwLFxuICAgICAgICBiYWNrZ3JvdW5kOiBub3RlQ29sb3JUb2tlbihvLmNvbG9yKSxcbiAgICAgICAgY29sb3I6ICd2YXIoLS1ub3RlLWluayknLFxuICAgICAgICBib3JkZXJSYWRpdXM6ICcycHggMnB4IDJweCAxNnB4JyxcbiAgICAgICAgcGFkZGluZzogJzE0cHggMTVweCcsXG4gICAgICAgIGJveFNoYWRvdzogJ3ZhcigtLW5vdGUtc2hhZG93KScsXG4gICAgICAgIGRpc3BsYXk6ICdmbGV4JyxcbiAgICAgICAgZmxleERpcmVjdGlvbjogJ2NvbHVtbicsXG4gICAgICAgIGdhcDogNyxcbiAgICAgICAgb3ZlcmZsb3c6ICdoaWRkZW4nLFxuICAgICAgfX1cbiAgICA+XG4gICAgICB7by50YWdzICYmICF0YWdDaGlwU3VwcHJlc3NlZChvLCBvYmplY3RzKSA/IChcbiAgICAgICAgPGRpdiBzdHlsZT17eyBmb250OiAndmFyKC0tbW9uby14cyknLCBsZXR0ZXJTcGFjaW5nOiAnLjA1ZW0nLCB0ZXh0VHJhbnNmb3JtOiAndXBwZXJjYXNlJywgb3BhY2l0eTogMC41IH19PlxuICAgICAgICAgIHtgIyR7by50YWdzfWB9XG4gICAgICAgIDwvZGl2PlxuICAgICAgKSA6IG51bGx9XG4gICAgICA8ZGl2IHN0eWxlPXt7IGZvbnQ6ICc2MDAgMTYuNXB4LzEuMyB2YXIoLS1zYW5zKScsIHRleHRXcmFwOiAncHJldHR5JyB9fT57by50aXRsZX08L2Rpdj5cbiAgICAgIDxCYWRnZXMgbz17b30gLz5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgU3RpY2t5Tm90ZTtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBSUEsSUFBQUEsT0FBQSxHQUFBQyxzQkFBQSxDQUFBQyxPQUFBO0FBRUEsSUFBQUMsTUFBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsU0FBQSxHQUFBRixPQUFBO0FBQXVELElBQUFHLFdBQUEsR0FBQUgsT0FBQTtBQUFBLFNBQUFELHVCQUFBSyxDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBUHZEO0FBQ0E7QUFDQTs7QUFPQSxTQUFTRyxVQUFVQSxDQUFDO0VBQUVDLENBQUM7RUFBRUM7QUFBNEMsQ0FBQyxFQUFFO0VBQ3RFLG9CQUNFLElBQUFOLFdBQUEsQ0FBQU8sSUFBQTtJQUNFQyxLQUFLLEVBQUU7TUFDTEMsUUFBUSxFQUFFLFVBQVU7TUFDcEJDLEtBQUssRUFBRSxDQUFDO01BQ1JDLFVBQVUsRUFBRSxJQUFBQyxxQkFBYyxFQUFDUCxDQUFDLENBQUNRLEtBQUssQ0FBQztNQUNuQ0EsS0FBSyxFQUFFLGlCQUFpQjtNQUN4QkMsWUFBWSxFQUFFLGtCQUFrQjtNQUNoQ0MsT0FBTyxFQUFFLFdBQVc7TUFDcEJDLFNBQVMsRUFBRSxvQkFBb0I7TUFDL0JDLE9BQU8sRUFBRSxNQUFNO01BQ2ZDLGFBQWEsRUFBRSxRQUFRO01BQ3ZCQyxHQUFHLEVBQUUsQ0FBQztNQUNOQyxRQUFRLEVBQUU7SUFDWixDQUFFO0lBQUFDLFFBQUEsR0FFRGhCLENBQUMsQ0FBQ2lCLElBQUksSUFBSSxDQUFDLElBQUFDLDJCQUFpQixFQUFDbEIsQ0FBQyxFQUFFQyxPQUFPLENBQUMsZ0JBQ3ZDLElBQUFOLFdBQUEsQ0FBQXdCLEdBQUE7TUFBS2hCLEtBQUssRUFBRTtRQUFFaUIsSUFBSSxFQUFFLGdCQUFnQjtRQUFFQyxhQUFhLEVBQUUsT0FBTztRQUFFQyxhQUFhLEVBQUUsV0FBVztRQUFFQyxPQUFPLEVBQUU7TUFBSSxDQUFFO01BQUFQLFFBQUEsRUFDdEcsSUFBSWhCLENBQUMsQ0FBQ2lCLElBQUk7SUFBRSxDQUNWLENBQUMsR0FDSixJQUFJLGVBQ1IsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUE7TUFBS2hCLEtBQUssRUFBRTtRQUFFaUIsSUFBSSxFQUFFLDRCQUE0QjtRQUFFSSxRQUFRLEVBQUU7TUFBUyxDQUFFO01BQUFSLFFBQUEsRUFBRWhCLENBQUMsQ0FBQ3lCO0lBQUssQ0FBTSxDQUFDLGVBQ3ZGLElBQUE5QixXQUFBLENBQUF3QixHQUFBLEVBQUM3QixPQUFBLENBQUFRLE9BQU07TUFBQ0UsQ0FBQyxFQUFFQTtJQUFFLENBQUUsQ0FBQztFQUFBLENBQ2IsQ0FBQztBQUVWO0FBQUMwQixFQUFBLEdBMUJRM0IsVUFBVTtBQUFBLElBQUE0QixRQUFBLEdBQUFDLE9BQUEsQ0FBQTlCLE9BQUEsR0E0QkpDLFVBQVU7QUFBQSxJQUFBMkIsRUFBQTtBQUFBRyxZQUFBLENBQUFILEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}