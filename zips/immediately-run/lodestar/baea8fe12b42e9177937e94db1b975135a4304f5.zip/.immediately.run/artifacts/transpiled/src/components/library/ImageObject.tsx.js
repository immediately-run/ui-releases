var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _react = require("react");
var _fs = _interopRequireDefault(require("fs"));
var _Icon = _interopRequireDefault(require("../Icon"));
var _imgRef = require("../../lib/imgRef");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // Image from assets/, lazy-loaded with a shimmer skeleton first (spec §3.4,
// DESIGN_BRIEF §1 loading state). The asset bytes live behind the sandbox
// filesystem — an opaque origin, no URL to fetch — so the component reads them
// through the same `fs` the store uses and hands the renderer an object URL,
// revoked on unmount. `loaded` is authored in the file as a claim about the
// asset; a renderer that knows reads the file itself and derives the state, so
// this component keys off the read result, not the claim (R3-399).
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function ImageObject({
  o,
  boardRoot
}) {
  _s();
  const rel = (0, _imgRef.imgAssetRef)(o);
  const path = rel && boardRoot ? `${boardRoot}/${rel}`.replace(/\/+/g, '/') : null;
  const [img, setImg] = (0, _react.useState)({
    path,
    status: 'loading'
  });
  (0, _react.useEffect)(() => {
    if (!path) return;
    let disposed = false;
    let objectUrl = null;
    _fs.default.promises.readFile(path).then(data => {
      if (disposed) return;
      objectUrl = URL.createObjectURL(new Blob([new Uint8Array(data)]));
      setImg({
        path,
        status: 'ready',
        url: objectUrl
      });
    }).catch(() => {
      if (!disposed) setImg({
        path,
        status: 'missing'
      });
    });
    return () => {
      disposed = true;
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, [path]);

  // No reference (or no board root yet) → the missing-asset placeholder; a
  // reference whose read hasn't resolved for THIS path → the loading shimmer.
  const current = img.path === path ? img : {
    path,
    status: 'loading'
  };
  if (current.status === 'ready') {
    return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      style: {
        position: 'absolute',
        inset: 0,
        borderRadius: 12,
        overflow: 'hidden',
        background: 'var(--panel)',
        border: '1px solid var(--line)'
      },
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)("img", {
        src: current.url,
        alt: o.title || 'image',
        draggable: false,
        style: {
          position: 'absolute',
          inset: 0,
          width: '100%',
          height: '100%',
          objectFit: 'cover',
          display: 'block'
        }
      })
    });
  }
  if (current.status === 'missing' || !path) {
    return /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      style: {
        position: 'absolute',
        inset: 0,
        borderRadius: 12,
        overflow: 'hidden',
        background: 'var(--panel)',
        border: '1px solid var(--line)'
      },
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        style: {
          position: 'absolute',
          inset: 0,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: 'var(--ink-3)'
        },
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
          name: "image",
          size: 30,
          strokeWidth: 1.5
        })
      })
    });
  }
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    style: {
      position: 'absolute',
      inset: 0,
      borderRadius: 12,
      overflow: 'hidden',
      background: 'var(--panel)',
      border: '1px solid var(--line)'
    },
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      style: {
        position: 'absolute',
        inset: 0,
        background: 'linear-gradient(100deg, transparent 20%, color-mix(in oklab, var(--ink) 8%, transparent) 50%, transparent 80%)',
        backgroundSize: '200% 100%',
        animation: 'wb-shimmer 1.4s linear infinite'
      }
    }), /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      style: {
        position: 'absolute',
        inset: 0,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        color: 'var(--ink-3)'
      },
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_Icon.default, {
        name: "image",
        size: 30,
        strokeWidth: 1.5
      })
    })]
  });
}
_s(ImageObject, "s7Jioi0LnzalVmB9v/ADfUI/09E=");
_c = ImageObject;
var _default = exports.default = ImageObject;
var _c;
$RefreshReg$(_c, "ImageObject");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX2ZzIiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsIl9JY29uIiwiX2ltZ1JlZiIsIl9qc3hSdW50aW1lIiwiX3MiLCIkUmVmcmVzaFNpZyQiLCJlIiwiX19lc01vZHVsZSIsImRlZmF1bHQiLCJJbWFnZU9iamVjdCIsIm8iLCJib2FyZFJvb3QiLCJyZWwiLCJpbWdBc3NldFJlZiIsInBhdGgiLCJyZXBsYWNlIiwiaW1nIiwic2V0SW1nIiwidXNlU3RhdGUiLCJzdGF0dXMiLCJ1c2VFZmZlY3QiLCJkaXNwb3NlZCIsIm9iamVjdFVybCIsImZzIiwicHJvbWlzZXMiLCJyZWFkRmlsZSIsInRoZW4iLCJkYXRhIiwiVVJMIiwiY3JlYXRlT2JqZWN0VVJMIiwiQmxvYiIsIlVpbnQ4QXJyYXkiLCJ1cmwiLCJjYXRjaCIsInJldm9rZU9iamVjdFVSTCIsImN1cnJlbnQiLCJqc3giLCJzdHlsZSIsInBvc2l0aW9uIiwiaW5zZXQiLCJib3JkZXJSYWRpdXMiLCJvdmVyZmxvdyIsImJhY2tncm91bmQiLCJib3JkZXIiLCJjaGlsZHJlbiIsInNyYyIsImFsdCIsInRpdGxlIiwiZHJhZ2dhYmxlIiwid2lkdGgiLCJoZWlnaHQiLCJvYmplY3RGaXQiLCJkaXNwbGF5IiwiYWxpZ25JdGVtcyIsImp1c3RpZnlDb250ZW50IiwiY29sb3IiLCJuYW1lIiwic2l6ZSIsInN0cm9rZVdpZHRoIiwianN4cyIsImJhY2tncm91bmRTaXplIiwiYW5pbWF0aW9uIiwiX2MiLCJfZGVmYXVsdCIsImV4cG9ydHMiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJJbWFnZU9iamVjdC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gSW1hZ2UgZnJvbSBhc3NldHMvLCBsYXp5LWxvYWRlZCB3aXRoIGEgc2hpbW1lciBza2VsZXRvbiBmaXJzdCAoc3BlYyDCpzMuNCxcbi8vIERFU0lHTl9CUklFRiDCpzEgbG9hZGluZyBzdGF0ZSkuIFRoZSBhc3NldCBieXRlcyBsaXZlIGJlaGluZCB0aGUgc2FuZGJveFxuLy8gZmlsZXN5c3RlbSDigJQgYW4gb3BhcXVlIG9yaWdpbiwgbm8gVVJMIHRvIGZldGNoIOKAlCBzbyB0aGUgY29tcG9uZW50IHJlYWRzIHRoZW1cbi8vIHRocm91Z2ggdGhlIHNhbWUgYGZzYCB0aGUgc3RvcmUgdXNlcyBhbmQgaGFuZHMgdGhlIHJlbmRlcmVyIGFuIG9iamVjdCBVUkwsXG4vLyByZXZva2VkIG9uIHVubW91bnQuIGBsb2FkZWRgIGlzIGF1dGhvcmVkIGluIHRoZSBmaWxlIGFzIGEgY2xhaW0gYWJvdXQgdGhlXG4vLyBhc3NldDsgYSByZW5kZXJlciB0aGF0IGtub3dzIHJlYWRzIHRoZSBmaWxlIGl0c2VsZiBhbmQgZGVyaXZlcyB0aGUgc3RhdGUsIHNvXG4vLyB0aGlzIGNvbXBvbmVudCBrZXlzIG9mZiB0aGUgcmVhZCByZXN1bHQsIG5vdCB0aGUgY2xhaW0gKFIzLTM5OSkuXG5cbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgZnMgZnJvbSAnZnMnO1xuaW1wb3J0IEljb24gZnJvbSAnLi4vSWNvbic7XG5pbXBvcnQgdHlwZSB7IFdPYmplY3QgfSBmcm9tICcuLi8uLi9saWIvdHlwZXMnO1xuaW1wb3J0IHsgaW1nQXNzZXRSZWYgfSBmcm9tICcuLi8uLi9saWIvaW1nUmVmJztcblxudHlwZSBJbWdTdGF0ZSA9XG4gIHwgeyBwYXRoOiBzdHJpbmc7IHN0YXR1czogJ3JlYWR5JzsgdXJsOiBzdHJpbmcgfVxuICB8IHsgcGF0aDogc3RyaW5nOyBzdGF0dXM6ICdtaXNzaW5nJyB9XG4gIHwgeyBwYXRoOiBzdHJpbmcgfCBudWxsOyBzdGF0dXM6ICdsb2FkaW5nJyB9O1xuXG5mdW5jdGlvbiBJbWFnZU9iamVjdCh7IG8sIGJvYXJkUm9vdCB9OiB7IG86IFdPYmplY3Q7IGJvYXJkUm9vdDogc3RyaW5nIHwgbnVsbCB9KSB7XG4gIGNvbnN0IHJlbCA9IGltZ0Fzc2V0UmVmKG8pO1xuICBjb25zdCBwYXRoID0gcmVsICYmIGJvYXJkUm9vdCA/IGAke2JvYXJkUm9vdH0vJHtyZWx9YC5yZXBsYWNlKC9cXC8rL2csICcvJykgOiBudWxsO1xuICBjb25zdCBbaW1nLCBzZXRJbWddID0gdXNlU3RhdGU8SW1nU3RhdGU+KHsgcGF0aCwgc3RhdHVzOiAnbG9hZGluZycgfSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIXBhdGgpIHJldHVybjtcbiAgICBsZXQgZGlzcG9zZWQgPSBmYWxzZTtcbiAgICBsZXQgb2JqZWN0VXJsOiBzdHJpbmcgfCBudWxsID0gbnVsbDtcbiAgICBmcy5wcm9taXNlc1xuICAgICAgLnJlYWRGaWxlKHBhdGgpXG4gICAgICAudGhlbigoZGF0YSkgPT4ge1xuICAgICAgICBpZiAoZGlzcG9zZWQpIHJldHVybjtcbiAgICAgICAgb2JqZWN0VXJsID0gVVJMLmNyZWF0ZU9iamVjdFVSTChuZXcgQmxvYihbbmV3IFVpbnQ4QXJyYXkoZGF0YSldKSk7XG4gICAgICAgIHNldEltZyh7IHBhdGgsIHN0YXR1czogJ3JlYWR5JywgdXJsOiBvYmplY3RVcmwgfSk7XG4gICAgICB9KVxuICAgICAgLmNhdGNoKCgpID0+IHtcbiAgICAgICAgaWYgKCFkaXNwb3NlZCkgc2V0SW1nKHsgcGF0aCwgc3RhdHVzOiAnbWlzc2luZycgfSk7XG4gICAgICB9KTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgZGlzcG9zZWQgPSB0cnVlO1xuICAgICAgaWYgKG9iamVjdFVybCkgVVJMLnJldm9rZU9iamVjdFVSTChvYmplY3RVcmwpO1xuICAgIH07XG4gIH0sIFtwYXRoXSk7XG5cbiAgLy8gTm8gcmVmZXJlbmNlIChvciBubyBib2FyZCByb290IHlldCkg4oaSIHRoZSBtaXNzaW5nLWFzc2V0IHBsYWNlaG9sZGVyOyBhXG4gIC8vIHJlZmVyZW5jZSB3aG9zZSByZWFkIGhhc24ndCByZXNvbHZlZCBmb3IgVEhJUyBwYXRoIOKGkiB0aGUgbG9hZGluZyBzaGltbWVyLlxuICBjb25zdCBjdXJyZW50ID0gaW1nLnBhdGggPT09IHBhdGggPyBpbWcgOiB7IHBhdGgsIHN0YXR1czogJ2xvYWRpbmcnIGFzIGNvbnN0IH07XG5cbiAgaWYgKGN1cnJlbnQuc3RhdHVzID09PSAncmVhZHknKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXZcbiAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICBwb3NpdGlvbjogJ2Fic29sdXRlJyxcbiAgICAgICAgICBpbnNldDogMCxcbiAgICAgICAgICBib3JkZXJSYWRpdXM6IDEyLFxuICAgICAgICAgIG92ZXJmbG93OiAnaGlkZGVuJyxcbiAgICAgICAgICBiYWNrZ3JvdW5kOiAndmFyKC0tcGFuZWwpJyxcbiAgICAgICAgICBib3JkZXI6ICcxcHggc29saWQgdmFyKC0tbGluZSknLFxuICAgICAgICB9fVxuICAgICAgPlxuICAgICAgICA8aW1nXG4gICAgICAgICAgc3JjPXtjdXJyZW50LnVybH1cbiAgICAgICAgICBhbHQ9e28udGl0bGUgfHwgJ2ltYWdlJ31cbiAgICAgICAgICBkcmFnZ2FibGU9e2ZhbHNlfVxuICAgICAgICAgIHN0eWxlPXt7IHBvc2l0aW9uOiAnYWJzb2x1dGUnLCBpbnNldDogMCwgd2lkdGg6ICcxMDAlJywgaGVpZ2h0OiAnMTAwJScsIG9iamVjdEZpdDogJ2NvdmVyJywgZGlzcGxheTogJ2Jsb2NrJyB9fVxuICAgICAgICAvPlxuICAgICAgPC9kaXY+XG4gICAgKTtcbiAgfVxuXG4gIGlmIChjdXJyZW50LnN0YXR1cyA9PT0gJ21pc3NpbmcnIHx8ICFwYXRoKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXZcbiAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICBwb3NpdGlvbjogJ2Fic29sdXRlJyxcbiAgICAgICAgICBpbnNldDogMCxcbiAgICAgICAgICBib3JkZXJSYWRpdXM6IDEyLFxuICAgICAgICAgIG92ZXJmbG93OiAnaGlkZGVuJyxcbiAgICAgICAgICBiYWNrZ3JvdW5kOiAndmFyKC0tcGFuZWwpJyxcbiAgICAgICAgICBib3JkZXI6ICcxcHggc29saWQgdmFyKC0tbGluZSknLFxuICAgICAgICB9fVxuICAgICAgPlxuICAgICAgICA8ZGl2XG4gICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgIHBvc2l0aW9uOiAnYWJzb2x1dGUnLFxuICAgICAgICAgICAgaW5zZXQ6IDAsXG4gICAgICAgICAgICBkaXNwbGF5OiAnZmxleCcsXG4gICAgICAgICAgICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcbiAgICAgICAgICAgIGp1c3RpZnlDb250ZW50OiAnY2VudGVyJyxcbiAgICAgICAgICAgIGNvbG9yOiAndmFyKC0taW5rLTMpJyxcbiAgICAgICAgICB9fVxuICAgICAgICA+XG4gICAgICAgICAgPEljb24gbmFtZT1cImltYWdlXCIgc2l6ZT17MzB9IHN0cm9rZVdpZHRoPXsxLjV9IC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgKTtcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgc3R5bGU9e3tcbiAgICAgICAgcG9zaXRpb246ICdhYnNvbHV0ZScsXG4gICAgICAgIGluc2V0OiAwLFxuICAgICAgICBib3JkZXJSYWRpdXM6IDEyLFxuICAgICAgICBvdmVyZmxvdzogJ2hpZGRlbicsXG4gICAgICAgIGJhY2tncm91bmQ6ICd2YXIoLS1wYW5lbCknLFxuICAgICAgICBib3JkZXI6ICcxcHggc29saWQgdmFyKC0tbGluZSknLFxuICAgICAgfX1cbiAgICA+XG4gICAgICA8ZGl2XG4gICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgcG9zaXRpb246ICdhYnNvbHV0ZScsXG4gICAgICAgICAgaW5zZXQ6IDAsXG4gICAgICAgICAgYmFja2dyb3VuZDogJ2xpbmVhci1ncmFkaWVudCgxMDBkZWcsIHRyYW5zcGFyZW50IDIwJSwgY29sb3ItbWl4KGluIG9rbGFiLCB2YXIoLS1pbmspIDglLCB0cmFuc3BhcmVudCkgNTAlLCB0cmFuc3BhcmVudCA4MCUpJyxcbiAgICAgICAgICBiYWNrZ3JvdW5kU2l6ZTogJzIwMCUgMTAwJScsXG4gICAgICAgICAgYW5pbWF0aW9uOiAnd2Itc2hpbW1lciAxLjRzIGxpbmVhciBpbmZpbml0ZScsXG4gICAgICAgIH19XG4gICAgICAvPlxuICAgICAgPGRpdiBzdHlsZT17eyBwb3NpdGlvbjogJ2Fic29sdXRlJywgaW5zZXQ6IDAsIGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGp1c3RpZnlDb250ZW50OiAnY2VudGVyJywgY29sb3I6ICd2YXIoLS1pbmstMyknIH19PlxuICAgICAgICA8SWNvbiBuYW1lPVwiaW1hZ2VcIiBzaXplPXszMH0gc3Ryb2tlV2lkdGg9ezEuNX0gLz5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufVxuXG5leHBvcnQgZGVmYXVsdCBJbWFnZU9iamVjdDsiXSwibWFwcGluZ3MiOiI7Ozs7OztBQVFBLElBQUFBLE1BQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLEdBQUEsR0FBQUMsc0JBQUEsQ0FBQUYsT0FBQTtBQUNBLElBQUFHLEtBQUEsR0FBQUQsc0JBQUEsQ0FBQUYsT0FBQTtBQUVBLElBQUFJLE9BQUEsR0FBQUosT0FBQTtBQUErQyxJQUFBSyxXQUFBLEdBQUFMLE9BQUE7QUFBQSxJQUFBTSxFQUFBLEdBQUFDLFlBQUEsSUFaL0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFBQSxTQUFBTCx1QkFBQU0sQ0FBQSxXQUFBQSxDQUFBLElBQUFBLENBQUEsQ0FBQUMsVUFBQSxHQUFBRCxDQUFBLEtBQUFFLE9BQUEsRUFBQUYsQ0FBQTtBQWFBLFNBQVNHLFdBQVdBLENBQUM7RUFBRUMsQ0FBQztFQUFFQztBQUFvRCxDQUFDLEVBQUU7RUFBQVAsRUFBQTtFQUMvRSxNQUFNUSxHQUFHLEdBQUcsSUFBQUMsbUJBQVcsRUFBQ0gsQ0FBQyxDQUFDO0VBQzFCLE1BQU1JLElBQUksR0FBR0YsR0FBRyxJQUFJRCxTQUFTLEdBQUcsR0FBR0EsU0FBUyxJQUFJQyxHQUFHLEVBQUUsQ0FBQ0csT0FBTyxDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsR0FBRyxJQUFJO0VBQ2pGLE1BQU0sQ0FBQ0MsR0FBRyxFQUFFQyxNQUFNLENBQUMsR0FBRyxJQUFBQyxlQUFRLEVBQVc7SUFBRUosSUFBSTtJQUFFSyxNQUFNLEVBQUU7RUFBVSxDQUFDLENBQUM7RUFFckUsSUFBQUMsZ0JBQVMsRUFBQyxNQUFNO0lBQ2QsSUFBSSxDQUFDTixJQUFJLEVBQUU7SUFDWCxJQUFJTyxRQUFRLEdBQUcsS0FBSztJQUNwQixJQUFJQyxTQUF3QixHQUFHLElBQUk7SUFDbkNDLFdBQUUsQ0FBQ0MsUUFBUSxDQUNSQyxRQUFRLENBQUNYLElBQUksQ0FBQyxDQUNkWSxJQUFJLENBQUVDLElBQUksSUFBSztNQUNkLElBQUlOLFFBQVEsRUFBRTtNQUNkQyxTQUFTLEdBQUdNLEdBQUcsQ0FBQ0MsZUFBZSxDQUFDLElBQUlDLElBQUksQ0FBQyxDQUFDLElBQUlDLFVBQVUsQ0FBQ0osSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO01BQ2pFVixNQUFNLENBQUM7UUFBRUgsSUFBSTtRQUFFSyxNQUFNLEVBQUUsT0FBTztRQUFFYSxHQUFHLEVBQUVWO01BQVUsQ0FBQyxDQUFDO0lBQ25ELENBQUMsQ0FBQyxDQUNEVyxLQUFLLENBQUMsTUFBTTtNQUNYLElBQUksQ0FBQ1osUUFBUSxFQUFFSixNQUFNLENBQUM7UUFBRUgsSUFBSTtRQUFFSyxNQUFNLEVBQUU7TUFBVSxDQUFDLENBQUM7SUFDcEQsQ0FBQyxDQUFDO0lBQ0osT0FBTyxNQUFNO01BQ1hFLFFBQVEsR0FBRyxJQUFJO01BQ2YsSUFBSUMsU0FBUyxFQUFFTSxHQUFHLENBQUNNLGVBQWUsQ0FBQ1osU0FBUyxDQUFDO0lBQy9DLENBQUM7RUFDSCxDQUFDLEVBQUUsQ0FBQ1IsSUFBSSxDQUFDLENBQUM7O0VBRVY7RUFDQTtFQUNBLE1BQU1xQixPQUFPLEdBQUduQixHQUFHLENBQUNGLElBQUksS0FBS0EsSUFBSSxHQUFHRSxHQUFHLEdBQUc7SUFBRUYsSUFBSTtJQUFFSyxNQUFNLEVBQUU7RUFBbUIsQ0FBQztFQUU5RSxJQUFJZ0IsT0FBTyxDQUFDaEIsTUFBTSxLQUFLLE9BQU8sRUFBRTtJQUM5QixvQkFDRSxJQUFBaEIsV0FBQSxDQUFBaUMsR0FBQTtNQUNFQyxLQUFLLEVBQUU7UUFDTEMsUUFBUSxFQUFFLFVBQVU7UUFDcEJDLEtBQUssRUFBRSxDQUFDO1FBQ1JDLFlBQVksRUFBRSxFQUFFO1FBQ2hCQyxRQUFRLEVBQUUsUUFBUTtRQUNsQkMsVUFBVSxFQUFFLGNBQWM7UUFDMUJDLE1BQU0sRUFBRTtNQUNWLENBQUU7TUFBQUMsUUFBQSxlQUVGLElBQUF6QyxXQUFBLENBQUFpQyxHQUFBO1FBQ0VTLEdBQUcsRUFBRVYsT0FBTyxDQUFDSCxHQUFJO1FBQ2pCYyxHQUFHLEVBQUVwQyxDQUFDLENBQUNxQyxLQUFLLElBQUksT0FBUTtRQUN4QkMsU0FBUyxFQUFFLEtBQU07UUFDakJYLEtBQUssRUFBRTtVQUFFQyxRQUFRLEVBQUUsVUFBVTtVQUFFQyxLQUFLLEVBQUUsQ0FBQztVQUFFVSxLQUFLLEVBQUUsTUFBTTtVQUFFQyxNQUFNLEVBQUUsTUFBTTtVQUFFQyxTQUFTLEVBQUUsT0FBTztVQUFFQyxPQUFPLEVBQUU7UUFBUTtNQUFFLENBQ2hIO0lBQUMsQ0FDQyxDQUFDO0VBRVY7RUFFQSxJQUFJakIsT0FBTyxDQUFDaEIsTUFBTSxLQUFLLFNBQVMsSUFBSSxDQUFDTCxJQUFJLEVBQUU7SUFDekMsb0JBQ0UsSUFBQVgsV0FBQSxDQUFBaUMsR0FBQTtNQUNFQyxLQUFLLEVBQUU7UUFDTEMsUUFBUSxFQUFFLFVBQVU7UUFDcEJDLEtBQUssRUFBRSxDQUFDO1FBQ1JDLFlBQVksRUFBRSxFQUFFO1FBQ2hCQyxRQUFRLEVBQUUsUUFBUTtRQUNsQkMsVUFBVSxFQUFFLGNBQWM7UUFDMUJDLE1BQU0sRUFBRTtNQUNWLENBQUU7TUFBQUMsUUFBQSxlQUVGLElBQUF6QyxXQUFBLENBQUFpQyxHQUFBO1FBQ0VDLEtBQUssRUFBRTtVQUNMQyxRQUFRLEVBQUUsVUFBVTtVQUNwQkMsS0FBSyxFQUFFLENBQUM7VUFDUmEsT0FBTyxFQUFFLE1BQU07VUFDZkMsVUFBVSxFQUFFLFFBQVE7VUFDcEJDLGNBQWMsRUFBRSxRQUFRO1VBQ3hCQyxLQUFLLEVBQUU7UUFDVCxDQUFFO1FBQUFYLFFBQUEsZUFFRixJQUFBekMsV0FBQSxDQUFBaUMsR0FBQSxFQUFDbkMsS0FBQSxDQUFBTyxPQUFJO1VBQUNnRCxJQUFJLEVBQUMsT0FBTztVQUFDQyxJQUFJLEVBQUUsRUFBRztVQUFDQyxXQUFXLEVBQUU7UUFBSSxDQUFFO01BQUMsQ0FDOUM7SUFBQyxDQUNILENBQUM7RUFFVjtFQUVBLG9CQUNFLElBQUF2RCxXQUFBLENBQUF3RCxJQUFBO0lBQ0V0QixLQUFLLEVBQUU7TUFDTEMsUUFBUSxFQUFFLFVBQVU7TUFDcEJDLEtBQUssRUFBRSxDQUFDO01BQ1JDLFlBQVksRUFBRSxFQUFFO01BQ2hCQyxRQUFRLEVBQUUsUUFBUTtNQUNsQkMsVUFBVSxFQUFFLGNBQWM7TUFDMUJDLE1BQU0sRUFBRTtJQUNWLENBQUU7SUFBQUMsUUFBQSxnQkFFRixJQUFBekMsV0FBQSxDQUFBaUMsR0FBQTtNQUNFQyxLQUFLLEVBQUU7UUFDTEMsUUFBUSxFQUFFLFVBQVU7UUFDcEJDLEtBQUssRUFBRSxDQUFDO1FBQ1JHLFVBQVUsRUFBRSxnSEFBZ0g7UUFDNUhrQixjQUFjLEVBQUUsV0FBVztRQUMzQkMsU0FBUyxFQUFFO01BQ2I7SUFBRSxDQUNILENBQUMsZUFDRixJQUFBMUQsV0FBQSxDQUFBaUMsR0FBQTtNQUFLQyxLQUFLLEVBQUU7UUFBRUMsUUFBUSxFQUFFLFVBQVU7UUFBRUMsS0FBSyxFQUFFLENBQUM7UUFBRWEsT0FBTyxFQUFFLE1BQU07UUFBRUMsVUFBVSxFQUFFLFFBQVE7UUFBRUMsY0FBYyxFQUFFLFFBQVE7UUFBRUMsS0FBSyxFQUFFO01BQWUsQ0FBRTtNQUFBWCxRQUFBLGVBQ3JJLElBQUF6QyxXQUFBLENBQUFpQyxHQUFBLEVBQUNuQyxLQUFBLENBQUFPLE9BQUk7UUFBQ2dELElBQUksRUFBQyxPQUFPO1FBQUNDLElBQUksRUFBRSxFQUFHO1FBQUNDLFdBQVcsRUFBRTtNQUFJLENBQUU7SUFBQyxDQUM5QyxDQUFDO0VBQUEsQ0FDSCxDQUFDO0FBRVY7QUFBQ3RELEVBQUEsQ0F4R1FLLFdBQVc7QUFBQXFELEVBQUEsR0FBWHJELFdBQVc7QUFBQSxJQUFBc0QsUUFBQSxHQUFBQyxPQUFBLENBQUF4RCxPQUFBLEdBMEdMQyxXQUFXO0FBQUEsSUFBQXFELEVBQUE7QUFBQUcsWUFBQSxDQUFBSCxFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}