var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _color = require("../../lib/color");
var _jsxRuntime = require("react/jsx-runtime");
// rect / ellipse / diamond with token-based fill + stroke (spec §3.4). A shape
// honours its authored `color` through the shared note palette (R3-398); a shape
// with no color keeps the platform's historical accent appearance exactly.

function ShapeObject({
  o
}) {
  const {
    fill,
    stroke
  } = (0, _color.shapeColor)(o.color);
  const base = {
    position: 'absolute',
    inset: 0,
    background: fill,
    border: `1.5px solid ${stroke}`
  };
  let inner;
  if (o.shape === 'ellipse') inner = {
    ...base,
    borderRadius: '50%'
  };else if (o.shape === 'diamond') inner = {
    ...base,
    clipPath: 'polygon(50% 0, 100% 50%, 50% 100%, 0 50%)'
  };else inner = {
    ...base,
    borderRadius: 10
  };
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
    style: {
      position: 'absolute',
      inset: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    },
    children: [/*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      style: inner
    }), o.title ? /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      style: {
        position: 'relative',
        font: '700 17px/1.1 var(--disp)',
        color: 'var(--ink)'
      },
      children: o.title
    }) : null]
  });
}
_c = ShapeObject;
var _default = exports.default = ShapeObject;
var _c;
$RefreshReg$(_c, "ShapeObject");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY29sb3IiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJTaGFwZU9iamVjdCIsIm8iLCJmaWxsIiwic3Ryb2tlIiwic2hhcGVDb2xvciIsImNvbG9yIiwiYmFzZSIsInBvc2l0aW9uIiwiaW5zZXQiLCJiYWNrZ3JvdW5kIiwiYm9yZGVyIiwiaW5uZXIiLCJzaGFwZSIsImJvcmRlclJhZGl1cyIsImNsaXBQYXRoIiwianN4cyIsInN0eWxlIiwiZGlzcGxheSIsImFsaWduSXRlbXMiLCJqdXN0aWZ5Q29udGVudCIsImNoaWxkcmVuIiwianN4IiwidGl0bGUiLCJmb250IiwiX2MiLCJfZGVmYXVsdCIsImV4cG9ydHMiLCJkZWZhdWx0IiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiU2hhcGVPYmplY3QudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIHJlY3QgLyBlbGxpcHNlIC8gZGlhbW9uZCB3aXRoIHRva2VuLWJhc2VkIGZpbGwgKyBzdHJva2UgKHNwZWMgwqczLjQpLiBBIHNoYXBlXG4vLyBob25vdXJzIGl0cyBhdXRob3JlZCBgY29sb3JgIHRocm91Z2ggdGhlIHNoYXJlZCBub3RlIHBhbGV0dGUgKFIzLTM5OCk7IGEgc2hhcGVcbi8vIHdpdGggbm8gY29sb3Iga2VlcHMgdGhlIHBsYXRmb3JtJ3MgaGlzdG9yaWNhbCBhY2NlbnQgYXBwZWFyYW5jZSBleGFjdGx5LlxuXG5pbXBvcnQgdHlwZSB7IFdPYmplY3QgfSBmcm9tICcuLi8uLi9saWIvdHlwZXMnO1xuaW1wb3J0IHsgc2hhcGVDb2xvciB9IGZyb20gJy4uLy4uL2xpYi9jb2xvcic7XG5cbmZ1bmN0aW9uIFNoYXBlT2JqZWN0KHsgbyB9OiB7IG86IFdPYmplY3QgfSkge1xuICBjb25zdCB7IGZpbGwsIHN0cm9rZSB9ID0gc2hhcGVDb2xvcihvLmNvbG9yKTtcbiAgY29uc3QgYmFzZTogUmVhY3QuQ1NTUHJvcGVydGllcyA9IHsgcG9zaXRpb246ICdhYnNvbHV0ZScsIGluc2V0OiAwLCBiYWNrZ3JvdW5kOiBmaWxsLCBib3JkZXI6IGAxLjVweCBzb2xpZCAke3N0cm9rZX1gIH07XG4gIGxldCBpbm5lcjogUmVhY3QuQ1NTUHJvcGVydGllcztcbiAgaWYgKG8uc2hhcGUgPT09ICdlbGxpcHNlJykgaW5uZXIgPSB7IC4uLmJhc2UsIGJvcmRlclJhZGl1czogJzUwJScgfTtcbiAgZWxzZSBpZiAoby5zaGFwZSA9PT0gJ2RpYW1vbmQnKSBpbm5lciA9IHsgLi4uYmFzZSwgY2xpcFBhdGg6ICdwb2x5Z29uKDUwJSAwLCAxMDAlIDUwJSwgNTAlIDEwMCUsIDAgNTAlKScgfTtcbiAgZWxzZSBpbm5lciA9IHsgLi4uYmFzZSwgYm9yZGVyUmFkaXVzOiAxMCB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBzdHlsZT17eyBwb3NpdGlvbjogJ2Fic29sdXRlJywgaW5zZXQ6IDAsIGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGp1c3RpZnlDb250ZW50OiAnY2VudGVyJyB9fT5cbiAgICAgIDxkaXYgc3R5bGU9e2lubmVyfSAvPlxuICAgICAge28udGl0bGUgPyAoXG4gICAgICAgIDxkaXYgc3R5bGU9e3sgcG9zaXRpb246ICdyZWxhdGl2ZScsIGZvbnQ6ICc3MDAgMTdweC8xLjEgdmFyKC0tZGlzcCknLCBjb2xvcjogJ3ZhcigtLWluayknIH19PntvLnRpdGxlfTwvZGl2PlxuICAgICAgKSA6IG51bGx9XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IFNoYXBlT2JqZWN0O1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFLQSxJQUFBQSxNQUFBLEdBQUFDLE9BQUE7QUFBNkMsSUFBQUMsV0FBQSxHQUFBRCxPQUFBO0FBTDdDO0FBQ0E7QUFDQTs7QUFLQSxTQUFTRSxXQUFXQSxDQUFDO0VBQUVDO0FBQWtCLENBQUMsRUFBRTtFQUMxQyxNQUFNO0lBQUVDLElBQUk7SUFBRUM7RUFBTyxDQUFDLEdBQUcsSUFBQUMsaUJBQVUsRUFBQ0gsQ0FBQyxDQUFDSSxLQUFLLENBQUM7RUFDNUMsTUFBTUMsSUFBeUIsR0FBRztJQUFFQyxRQUFRLEVBQUUsVUFBVTtJQUFFQyxLQUFLLEVBQUUsQ0FBQztJQUFFQyxVQUFVLEVBQUVQLElBQUk7SUFBRVEsTUFBTSxFQUFFLGVBQWVQLE1BQU07RUFBRyxDQUFDO0VBQ3ZILElBQUlRLEtBQTBCO0VBQzlCLElBQUlWLENBQUMsQ0FBQ1csS0FBSyxLQUFLLFNBQVMsRUFBRUQsS0FBSyxHQUFHO0lBQUUsR0FBR0wsSUFBSTtJQUFFTyxZQUFZLEVBQUU7RUFBTSxDQUFDLENBQUMsS0FDL0QsSUFBSVosQ0FBQyxDQUFDVyxLQUFLLEtBQUssU0FBUyxFQUFFRCxLQUFLLEdBQUc7SUFBRSxHQUFHTCxJQUFJO0lBQUVRLFFBQVEsRUFBRTtFQUE0QyxDQUFDLENBQUMsS0FDdEdILEtBQUssR0FBRztJQUFFLEdBQUdMLElBQUk7SUFBRU8sWUFBWSxFQUFFO0VBQUcsQ0FBQztFQUUxQyxvQkFDRSxJQUFBZCxXQUFBLENBQUFnQixJQUFBO0lBQUtDLEtBQUssRUFBRTtNQUFFVCxRQUFRLEVBQUUsVUFBVTtNQUFFQyxLQUFLLEVBQUUsQ0FBQztNQUFFUyxPQUFPLEVBQUUsTUFBTTtNQUFFQyxVQUFVLEVBQUUsUUFBUTtNQUFFQyxjQUFjLEVBQUU7SUFBUyxDQUFFO0lBQUFDLFFBQUEsZ0JBQzlHLElBQUFyQixXQUFBLENBQUFzQixHQUFBO01BQUtMLEtBQUssRUFBRUw7SUFBTSxDQUFFLENBQUMsRUFDcEJWLENBQUMsQ0FBQ3FCLEtBQUssZ0JBQ04sSUFBQXZCLFdBQUEsQ0FBQXNCLEdBQUE7TUFBS0wsS0FBSyxFQUFFO1FBQUVULFFBQVEsRUFBRSxVQUFVO1FBQUVnQixJQUFJLEVBQUUsMEJBQTBCO1FBQUVsQixLQUFLLEVBQUU7TUFBYSxDQUFFO01BQUFlLFFBQUEsRUFBRW5CLENBQUMsQ0FBQ3FCO0lBQUssQ0FBTSxDQUFDLEdBQzFHLElBQUk7RUFBQSxDQUNMLENBQUM7QUFFVjtBQUFDRSxFQUFBLEdBaEJReEIsV0FBVztBQUFBLElBQUF5QixRQUFBLEdBQUFDLE9BQUEsQ0FBQUMsT0FBQSxHQWtCTDNCLFdBQVc7QUFBQSxJQUFBd0IsRUFBQTtBQUFBSSxZQUFBLENBQUFKLEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}