"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _vite = require("vite");
var _pluginReact = _interopRequireDefault(require("@vitejs/plugin-react"));
var _rollup = _interopRequireDefault(require("@mdx-js/rollup"));
var _devFs = require("@immediately-run/dev-fs");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
// MDX must run before @vitejs/plugin-react so the JSX it emits is handled by
// React's transform (Fast Refresh included). immediately.run processes .mdx
// natively; this wiring keeps the local `vite dev`/`build` in sync.
//
// devFs() (@immediately-run/dev-fs) makes `import ... from 'fs'` work during
// local `vite dev`, bridging the same async ZenFS surface immediately.run
// provides to your real disk. It is dev-only and absent from production builds.
// https://vite.dev/config/
var _default = exports.default = (0, _vite.defineConfig)(({
  command
}) => ({
  // `__WB_DEV__` is true under `vite dev` (command === 'serve'), false in a
  // production build. boardStore.ts reads it instead of `import.meta.env.DEV`,
  // because immediately.run transpiles modules to CommonJS where `import.meta`
  // is a parse-time error. immediately.run never runs Vite, so the identifier is
  // absent there and a `typeof` guard treats it as falsy.
  define: {
    __WB_DEV__: JSON.stringify(command === 'serve')
  },
  plugins: [(0, _devFs.devFs)(), {
    enforce: 'pre',
    ...(0, _rollup.default)()
  }, (0, _pluginReact.default)()],
  // `fs` is host-provided at runtime (ZenFS in the sandbox, the devFs bridge under
  // `vite dev`). devFs is dev-only, so leave the bare specifier external in the
  // production build — immediately.run resolves it from its runtime, and the local
  // build stays a pure type/sanity check.
  build: {
    rollupOptions: {
      external: ['fs', 'node:fs']
    }
  }
}));
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZSIsInJlcXVpcmUiLCJfcGx1Z2luUmVhY3QiLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwiX3JvbGx1cCIsIl9kZXZGcyIsImUiLCJfX2VzTW9kdWxlIiwiZGVmYXVsdCIsIl9kZWZhdWx0IiwiZXhwb3J0cyIsImRlZmluZUNvbmZpZyIsImNvbW1hbmQiLCJkZWZpbmUiLCJfX1dCX0RFVl9fIiwiSlNPTiIsInN0cmluZ2lmeSIsInBsdWdpbnMiLCJkZXZGcyIsImVuZm9yY2UiLCJtZHgiLCJyZWFjdCIsImJ1aWxkIiwicm9sbHVwT3B0aW9ucyIsImV4dGVybmFsIl0sInNvdXJjZXMiOlsidml0ZS5jb25maWcudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgZGVmaW5lQ29uZmlnIH0gZnJvbSAndml0ZSdcbmltcG9ydCByZWFjdCBmcm9tICdAdml0ZWpzL3BsdWdpbi1yZWFjdCdcbmltcG9ydCBtZHggZnJvbSAnQG1keC1qcy9yb2xsdXAnXG5pbXBvcnQgeyBkZXZGcyB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vZGV2LWZzJ1xuXG4vLyBNRFggbXVzdCBydW4gYmVmb3JlIEB2aXRlanMvcGx1Z2luLXJlYWN0IHNvIHRoZSBKU1ggaXQgZW1pdHMgaXMgaGFuZGxlZCBieVxuLy8gUmVhY3QncyB0cmFuc2Zvcm0gKEZhc3QgUmVmcmVzaCBpbmNsdWRlZCkuIGltbWVkaWF0ZWx5LnJ1biBwcm9jZXNzZXMgLm1keFxuLy8gbmF0aXZlbHk7IHRoaXMgd2lyaW5nIGtlZXBzIHRoZSBsb2NhbCBgdml0ZSBkZXZgL2BidWlsZGAgaW4gc3luYy5cbi8vXG4vLyBkZXZGcygpIChAaW1tZWRpYXRlbHktcnVuL2Rldi1mcykgbWFrZXMgYGltcG9ydCAuLi4gZnJvbSAnZnMnYCB3b3JrIGR1cmluZ1xuLy8gbG9jYWwgYHZpdGUgZGV2YCwgYnJpZGdpbmcgdGhlIHNhbWUgYXN5bmMgWmVuRlMgc3VyZmFjZSBpbW1lZGlhdGVseS5ydW5cbi8vIHByb3ZpZGVzIHRvIHlvdXIgcmVhbCBkaXNrLiBJdCBpcyBkZXYtb25seSBhbmQgYWJzZW50IGZyb20gcHJvZHVjdGlvbiBidWlsZHMuXG4vLyBodHRwczovL3ZpdGUuZGV2L2NvbmZpZy9cbmV4cG9ydCBkZWZhdWx0IGRlZmluZUNvbmZpZygoeyBjb21tYW5kIH0pID0+ICh7XG4gIC8vIGBfX1dCX0RFVl9fYCBpcyB0cnVlIHVuZGVyIGB2aXRlIGRldmAgKGNvbW1hbmQgPT09ICdzZXJ2ZScpLCBmYWxzZSBpbiBhXG4gIC8vIHByb2R1Y3Rpb24gYnVpbGQuIGJvYXJkU3RvcmUudHMgcmVhZHMgaXQgaW5zdGVhZCBvZiBgaW1wb3J0Lm1ldGEuZW52LkRFVmAsXG4gIC8vIGJlY2F1c2UgaW1tZWRpYXRlbHkucnVuIHRyYW5zcGlsZXMgbW9kdWxlcyB0byBDb21tb25KUyB3aGVyZSBgaW1wb3J0Lm1ldGFgXG4gIC8vIGlzIGEgcGFyc2UtdGltZSBlcnJvci4gaW1tZWRpYXRlbHkucnVuIG5ldmVyIHJ1bnMgVml0ZSwgc28gdGhlIGlkZW50aWZpZXIgaXNcbiAgLy8gYWJzZW50IHRoZXJlIGFuZCBhIGB0eXBlb2ZgIGd1YXJkIHRyZWF0cyBpdCBhcyBmYWxzeS5cbiAgZGVmaW5lOiB7IF9fV0JfREVWX186IEpTT04uc3RyaW5naWZ5KGNvbW1hbmQgPT09ICdzZXJ2ZScpIH0sXG4gIHBsdWdpbnM6IFtcbiAgICBkZXZGcygpLFxuICAgIHsgZW5mb3JjZTogJ3ByZScsIC4uLm1keCgpIH0sXG4gICAgcmVhY3QoKSxcbiAgXSxcbiAgLy8gYGZzYCBpcyBob3N0LXByb3ZpZGVkIGF0IHJ1bnRpbWUgKFplbkZTIGluIHRoZSBzYW5kYm94LCB0aGUgZGV2RnMgYnJpZGdlIHVuZGVyXG4gIC8vIGB2aXRlIGRldmApLiBkZXZGcyBpcyBkZXYtb25seSwgc28gbGVhdmUgdGhlIGJhcmUgc3BlY2lmaWVyIGV4dGVybmFsIGluIHRoZVxuICAvLyBwcm9kdWN0aW9uIGJ1aWxkIOKAlCBpbW1lZGlhdGVseS5ydW4gcmVzb2x2ZXMgaXQgZnJvbSBpdHMgcnVudGltZSwgYW5kIHRoZSBsb2NhbFxuICAvLyBidWlsZCBzdGF5cyBhIHB1cmUgdHlwZS9zYW5pdHkgY2hlY2suXG4gIGJ1aWxkOiB7XG4gICAgcm9sbHVwT3B0aW9uczogeyBleHRlcm5hbDogWydmcycsICdub2RlOmZzJ10gfSxcbiAgfSxcbn0pKVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFBQSxJQUFBQSxLQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxZQUFBLEdBQUFDLHNCQUFBLENBQUFGLE9BQUE7QUFDQSxJQUFBRyxPQUFBLEdBQUFELHNCQUFBLENBQUFGLE9BQUE7QUFDQSxJQUFBSSxNQUFBLEdBQUFKLE9BQUE7QUFBK0MsU0FBQUUsdUJBQUFHLENBQUEsV0FBQUEsQ0FBQSxJQUFBQSxDQUFBLENBQUFDLFVBQUEsR0FBQUQsQ0FBQSxLQUFBRSxPQUFBLEVBQUFGLENBQUE7QUFFL0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUFBLElBQUFHLFFBQUEsR0FBQUMsT0FBQSxDQUFBRixPQUFBLEdBQ2UsSUFBQUcsa0JBQVksRUFBQyxDQUFDO0VBQUVDO0FBQVEsQ0FBQyxNQUFNO0VBQzVDO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQUMsTUFBTSxFQUFFO0lBQUVDLFVBQVUsRUFBRUMsSUFBSSxDQUFDQyxTQUFTLENBQUNKLE9BQU8sS0FBSyxPQUFPO0VBQUUsQ0FBQztFQUMzREssT0FBTyxFQUFFLENBQ1AsSUFBQUMsWUFBSyxFQUFDLENBQUMsRUFDUDtJQUFFQyxPQUFPLEVBQUUsS0FBSztJQUFFLEdBQUcsSUFBQUMsZUFBRyxFQUFDO0VBQUUsQ0FBQyxFQUM1QixJQUFBQyxvQkFBSyxFQUFDLENBQUMsQ0FDUjtFQUNEO0VBQ0E7RUFDQTtFQUNBO0VBQ0FDLEtBQUssRUFBRTtJQUNMQyxhQUFhLEVBQUU7TUFBRUMsUUFBUSxFQUFFLENBQUMsSUFBSSxFQUFFLFNBQVM7SUFBRTtFQUMvQztBQUNGLENBQUMsQ0FBQyxDQUFDIiwiaWdub3JlTGlzdCI6W119