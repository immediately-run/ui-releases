var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
    code: "code",
    p: "p",
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
    children: ["This folder is a whiteboard project. A file manager that reads its\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
      children: "immediately.run.json"
    }), " marker offers \"Open project,\" which launches the\nwhiteboard with this folder already mounted."]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJjb2RlIiwicCIsIl9wcm92aWRlQ29tcG9uZW50cyIsImNvbXBvbmVudHMiLCJqc3hzIiwiY2hpbGRyZW4iLCJqc3giLCJNRFhDb250ZW50Iiwid3JhcHBlciIsIk1EWExheW91dCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsibm90ZS13ZWxjb21lLm1keCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKkBqc3hSdW50aW1lIGF1dG9tYXRpYyovXG4vKkBqc3hJbXBvcnRTb3VyY2UgcmVhY3QqL1xuaW1wb3J0IHt1c2VNRFhDb21wb25lbnRzIGFzIF9wcm92aWRlQ29tcG9uZW50c30gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrL01EWFByb3ZpZGVyXCI7XG5mdW5jdGlvbiBfY3JlYXRlTWR4Q29udGVudChwcm9wcykge1xuICBjb25zdCBfY29tcG9uZW50cyA9IHtcbiAgICBjb2RlOiBcImNvZGVcIixcbiAgICBwOiBcInBcIixcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH07XG4gIHJldHVybiA8X2NvbXBvbmVudHMucD57XCJUaGlzIGZvbGRlciBpcyBhIHdoaXRlYm9hcmQgcHJvamVjdC4gQSBmaWxlIG1hbmFnZXIgdGhhdCByZWFkcyBpdHNcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJpbW1lZGlhdGVseS5ydW4uanNvblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgbWFya2VyIG9mZmVycyBcXFwiT3BlbiBwcm9qZWN0LFxcXCIgd2hpY2ggbGF1bmNoZXMgdGhlXFxud2hpdGVib2FyZCB3aXRoIHRoaXMgZm9sZGVyIGFscmVhZHkgbW91bnRlZC5cIn08L19jb21wb25lbnRzLnA+O1xufVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTURYQ29udGVudChwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHt3cmFwcGVyOiBNRFhMYXlvdXR9ID0ge1xuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfTtcbiAgcmV0dXJuIE1EWExheW91dCA/IDxNRFhMYXlvdXQgey4uLnByb3BzfT48X2NyZWF0ZU1keENvbnRlbnQgey4uLnByb3BzfSAvPjwvTURYTGF5b3V0PiA6IF9jcmVhdGVNZHhDb250ZW50KHByb3BzKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQXdGLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUZ4RjtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU1DLFdBQVcsR0FBRztJQUNsQkMsSUFBSSxFQUFFLE1BQU07SUFDWkMsQ0FBQyxFQUFFLEdBQUc7SUFDTixHQUFHLElBQUFDLDZCQUFrQixFQUFDLENBQUM7SUFDdkIsR0FBR0osS0FBSyxDQUFDSztFQUNYLENBQUM7RUFDRCxvQkFBTyxJQUFBUCxXQUFBLENBQUFRLElBQUEsRUFBQ0wsV0FBVyxDQUFDRSxDQUFDO0lBQUFJLFFBQUEsR0FBRSxzRUFBc0UsZUFBQyxJQUFBVCxXQUFBLENBQUFVLEdBQUEsRUFBQ1AsV0FBVyxDQUFDQyxJQUFJO01BQUFLLFFBQUEsRUFBRTtJQUFzQixDQUFtQixDQUFDLEVBQUMsbUdBQW1HO0VBQUEsQ0FBZ0IsQ0FBQztBQUNsUjtBQUNlLFNBQVNFLFVBQVVBLENBQUNULEtBQUssR0FBRyxDQUFDLENBQUMsRUFBRTtFQUM3QyxNQUFNO0lBQUNVLE9BQU8sRUFBRUM7RUFBUyxDQUFDLEdBQUc7SUFDM0IsR0FBRyxJQUFBUCw2QkFBa0IsRUFBQyxDQUFDO0lBQ3ZCLEdBQUdKLEtBQUssQ0FBQ0s7RUFDWCxDQUFDO0VBQ0QsT0FBT00sU0FBUyxnQkFBRyxJQUFBYixXQUFBLENBQUFVLEdBQUEsRUFBQ0csU0FBUztJQUFBLEdBQUtYLEtBQUs7SUFBQU8sUUFBQSxlQUFFLElBQUFULFdBQUEsQ0FBQVUsR0FBQSxFQUFDVCxpQkFBaUI7TUFBQSxHQUFLQztJQUFLLENBQUc7RUFBQyxDQUFXLENBQUMsR0FBR0QsaUJBQWlCLENBQUNDLEtBQUssQ0FBQztBQUNsSDtBQUFDWSxFQUFBLEdBTnVCSCxVQUFVO0FBQUEsSUFBQUcsRUFBQTtBQUFBQyxZQUFBLENBQUFELEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}