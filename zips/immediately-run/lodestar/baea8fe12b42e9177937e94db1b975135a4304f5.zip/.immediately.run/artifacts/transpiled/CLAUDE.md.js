var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      li: "li",
      ol: "ol",
      p: "p",
      pre: "pre",
      strong: "strong",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "working-in-this-repo",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "working-in-this-repo"
      }), "Working in this repo"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["This is an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "immediately.run app"
      }), ": React + TypeScript that loads from GitHub and\ntranspiles in the browser (no server, no build step at runtime). Keep the rules\nbelow or the app breaks ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "only"
      }), " on immediately.run while still looking fine in\nlocal ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "vite dev"
      }), " — the most common silent failure."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "hard-rules-these-break-immediatelyrun-if-violated",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "hard-rules-these-break-immediatelyrun-if-violated"
      }), "Hard rules (these break immediately.run if violated)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "src/App.tsx"
          }), " is the entry point."]
        }), " immediately.run renders its ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "default\nexport"
        }), ". ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/main.tsx"
        }), " is for local dev/build only and is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "ignored"
        }), " at\nruntime — never put CSS imports, providers, or app logic there."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Import global CSS from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "App.tsx"
          })]
        }), ", not from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "main.tsx"
        }), ". Anything the\nrendered tree needs (CSS, context providers) must be reachable from\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "App.tsx"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "A file that exports a React component exports ONLY components."
        }), " No mixing a\ncomponent with named exports of data/constants/helpers. (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "interface"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "type"
        }), "\nare erased at compile time and are fine.) This is the React Fast Refresh rule;\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npm run lint"
        }), " enforces it. Put data in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/data/"
        }), ", hooks in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/hooks/"
        }), ",\nutilities in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/lib/"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "One component per file, default-exported"
        }), ", named for what it renders."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["CSS lives in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: ".css"
          }), " files imported from TypeScript"]
        }), " — not in giant\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<style>"
        }), " blocks or inline ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "style={{}}"
        }), " for the bulk of styling."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Fonts via CSS ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "@import"
          })]
        }), " as the first line of the CSS file, not ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<link>"
        }), "\ntags in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "index.html"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Import local assets"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "import logo from './assets/logo.png'"
        }), "); don't\nreference server paths that won't exist in the sandbox."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "No Node / build-time-only APIs"
        }), " in the rendered tree — it runs in a browser\niframe. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "localStorage"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "document"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "window"
        }), ", and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "fetch"
        }), " are available."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Never write the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "import.meta"
          }), " token"]
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "import.meta.env"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "import.meta.url"
        }), ",\neven ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "typeof import.meta"
        }), "). Vite replaces it at build time, so it looks fine in\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "vite dev"
        }), " — but immediately.run transpiles each module to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "CommonJS"
        }), " and\nruns it as a classic script, where ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "import.meta"
        }), " is a ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["parse-time\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "SyntaxError"
          }), " (\"Cannot use 'import.meta' outside a module\")"]
        }), ". It fails before\nany code runs, so a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "?."
        }), " runtime guard can't save it. For dev-only branches,\ninject a flag via Vite ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "define"
        }), " and read it behind a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "typeof"
        }), " guard (see\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "__WB_DEV__"
        }), " in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "vite.config.ts"
        }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/lib/boardStore.ts"
        }), ")."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "MDX is only for long-form prose"
        }), " (articles, guides). Structured/repeated\ndata stays as typed arrays in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/data/"
        }), ". If you add ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".mdx"
        }), ", the Vite plugin\nand ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/mdx.d.ts"
        }), " shim are already wired up."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "loading-caching-on-immediatelyrun",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "loading-caching-on-immediatelyrun"
      }), "Loading & caching on immediately.run"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: ".github/workflows/cache.yml"
      }), " publishes a pre-cached zip of this repo to its own\nGitHub Pages on each push to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "main"
      }), ", so immediately.run loads fast and within\nanonymous rate limits. It needs Pages ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Source: GitHub Actions"
      }), " enabled once in\nrepo settings. Don't move the cache to a different path or hostname — the client\ndiscovers it by convention at\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "https://<owner>.github.io/<repo>/cached_repositories/main.zip"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "\"immediately.run\": { \"requireLatest\": \"...\" }"
      }), " in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "package.json"
      }), " controls\nfreshness. It is a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "string enum"
      }), ", not a boolean: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "\"stale_ok\""
      }), " (always serve\nthe cache, fastest, offline-friendly), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "\"optimistic\""
      }), " (the default — serve\ncache, check in background), or ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "\"strict\""
      }), " (always run the newest commit, at\nthe cost of a freshness check on launch). Leave it unset unless\nto-the-commit freshness matters; the default is fast and works offline."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "design-system",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "design-system"
      }), "Design system"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["This brand is: cool near-black canvas · magenta↔violet signature gradient ·\nGabarito display type · Space Mono details · hairline borders · hard-offset hover\nshadows · sentence case · headlines end on a period · ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "no emoji"
      }), ". Dark is the\ndefault; a light theme is wired via ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "data-theme=\"light\""
      }), " on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "<html>"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Pull tokens from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "src/index.css"
          })]
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--bg"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--panel"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--ink"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--accent"
        }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--grad"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--r-lg"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--shadow-card"
        }), ", the type families, etc.) instead of\nhard-coding colors, radii, or fonts."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["Apply the signature gradient to text with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "className=\"grad-text\""
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["For icons beyond the unicode set (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "→ ★ ● ☀ ☾"
        }), "), use\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "https://lucide.dev",
          children: "Lucide"
        }), " at 16–24px, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "currentColor"
        }), ". No emoji."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "platform-security-model-what-your-app-can-and-cant-do",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "platform-security-model-what-your-app-can-and-cant-do"
      }), "Platform security model (what your app can and can't do)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Your app runs in a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "sandboxed iframe with an opaque origin"
      }), ". The rules below\nfollow from that and from the platform capability model\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "docs/specs/UI_AS_APPS_SPEC.md"
      }), " §8 in the docs repo). Violations don't just\nbreak your app — calls fail with typed errors, and trying to work around them\nreads as hostile. (Enforcement is rolling out per the spec's §10 ladder —\nitems 4, 6 and 8 describe machinery that is specified but not yet live; write\nnew code as if they're enforced and it will keep working as they land.)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["All platform interaction goes through ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "@immediately-run/sdk"
          }), "."]
        }), " There is\nno other channel: no shared storage with other apps, no reaching sibling\niframes, no postMessage of your own to the parent."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Never handle user credentials."
        }), " You will never see the user's GitHub\ntoken, API keys, or any secret — sign-in and privileged actions are\nhost-driven. Call protocol methods reactively, gated on\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "getAuthState().status === 'signed-in'"
        }), "; never store or request tokens."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The filesystem you see is the filesystem you got."
        }), " Mounts the host gives\nyou (your app's spaces, granted folders) are your whole world — outside\npaths don't exist, and a grant may be read-only. Don't probe for escapes\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".."
        }), ", absolute paths); writes to read-only mounts fail with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "EROFS"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Access to more data is asked for, not taken."
        }), " Need another space or\nfolder? Call the SDK request method and the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "user"
        }), " picks in host UI. Expect\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "{ ok: false, code: 'cancelled' | 'forbidden' }"
        }), " and handle it gracefully."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Handle typed errors everywhere."
        }), " Platform calls reply\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "{ ok: false, code, message }"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "forbidden"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "auth-required"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "cancelled"
        }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "invalid-params"
        }), ", …). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "forbidden"
        }), " means your app lacks that capability —\nthat's policy, not a bug to retry around."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Declare what you invoke and provide."
        }), " Cross-app tasks go in\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "package.json"
        }), " under ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "\"immediately.run\""
        }), ": ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "\"invokes\""
        }), " for task contracts\nyou call, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "\"provides\""
        }), " for ones you implement. Undeclared invocations are\nrejected."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Don't imitate host chrome."
        }), " Never render fake sign-in prompts, consent\ndialogs, or the platform's seam/header UI. The host draws those; imitations\nare treated as spoofing."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "If you embed an LLM agent, its tool list is your catalog."
        }), " Use the\nSDK-provided method catalog as the agent's tools — it is pre-filtered to\nyour app's grants, so the agent can't exceed what your app may do. Don't\nhand-roll tools that shell around the SDK."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Expect cancellation and absence."
        }), " Interactive flows can resolve\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "cancelled"
        }), "; capabilities can be absent on a fork of your app. Degrade\nfeatures, don't crash."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "verify-before-youre-done",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "verify-before-youre-done"
      }), "Verify before you're done"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-bash",
        children: "npm run build   # must pass with no type errors\nnpm run lint    # must pass — this is the cheapest proof the Fast Refresh rule holds\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Then eyeball the page (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "npm run dev"
      }), ") and click any interactive controls."]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/CLAUDE.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiY29kZSIsImVtIiwiaDEiLCJoMiIsImxpIiwib2wiLCJwIiwicHJlIiwic3Ryb25nIiwidWwiLCJfcHJvdmlkZUNvbXBvbmVudHMiLCJjb21wb25lbnRzIiwiSGVhZGluZ0FuY2hvciIsIl9taXNzaW5nTWR4UmVmZXJlbmNlIiwianN4cyIsIkZyYWdtZW50IiwiY2hpbGRyZW4iLCJpZCIsImpzeCIsImhyZWYiLCJjbGFzc05hbWUiLCJNRFhDb250ZW50Iiwid3JhcHBlciIsIk1EWExheW91dCIsIl9jIiwiY29tcG9uZW50IiwicGxhY2UiLCJFcnJvciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkNMQVVERS5tZCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKkBqc3hSdW50aW1lIGF1dG9tYXRpYyovXG4vKkBqc3hJbXBvcnRTb3VyY2UgcmVhY3QqL1xuaW1wb3J0IHt1c2VNRFhDb21wb25lbnRzIGFzIF9wcm92aWRlQ29tcG9uZW50c30gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrL01EWFByb3ZpZGVyXCI7XG5mdW5jdGlvbiBfY3JlYXRlTWR4Q29udGVudChwcm9wcykge1xuICBjb25zdCBfY29tcG9uZW50cyA9IHtcbiAgICBhOiBcImFcIixcbiAgICBjb2RlOiBcImNvZGVcIixcbiAgICBlbTogXCJlbVwiLFxuICAgIGgxOiBcImgxXCIsXG4gICAgaDI6IFwiaDJcIixcbiAgICBsaTogXCJsaVwiLFxuICAgIG9sOiBcIm9sXCIsXG4gICAgcDogXCJwXCIsXG4gICAgcHJlOiBcInByZVwiLFxuICAgIHN0cm9uZzogXCJzdHJvbmdcIixcbiAgICB1bDogXCJ1bFwiLFxuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfSwge0hlYWRpbmdBbmNob3J9ID0gX2NvbXBvbmVudHM7XG4gIGlmICghSGVhZGluZ0FuY2hvcikgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJIZWFkaW5nQW5jaG9yXCIsIHRydWUpO1xuICByZXR1cm4gPD48X2NvbXBvbmVudHMuaDEgaWQ9XCJ3b3JraW5nLWluLXRoaXMtcmVwb1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwid29ya2luZy1pbi10aGlzLXJlcG9cIiAvPntcIldvcmtpbmcgaW4gdGhpcyByZXBvXCJ9PC9fY29tcG9uZW50cy5oMT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGlzIGlzIGFuIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiaW1tZWRpYXRlbHkucnVuIGFwcFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIjogUmVhY3QgKyBUeXBlU2NyaXB0IHRoYXQgbG9hZHMgZnJvbSBHaXRIdWIgYW5kXFxudHJhbnNwaWxlcyBpbiB0aGUgYnJvd3NlciAobm8gc2VydmVyLCBubyBidWlsZCBzdGVwIGF0IHJ1bnRpbWUpLiBLZWVwIHRoZSBydWxlc1xcbmJlbG93IG9yIHRoZSBhcHAgYnJlYWtzIFwifTxfY29tcG9uZW50cy5lbT57XCJvbmx5XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgb24gaW1tZWRpYXRlbHkucnVuIHdoaWxlIHN0aWxsIGxvb2tpbmcgZmluZSBpblxcbmxvY2FsIFwifTxfY29tcG9uZW50cy5jb2RlPntcInZpdGUgZGV2XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgdGhlIG1vc3QgY29tbW9uIHNpbGVudCBmYWlsdXJlLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJoYXJkLXJ1bGVzLXRoZXNlLWJyZWFrLWltbWVkaWF0ZWx5cnVuLWlmLXZpb2xhdGVkXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJoYXJkLXJ1bGVzLXRoZXNlLWJyZWFrLWltbWVkaWF0ZWx5cnVuLWlmLXZpb2xhdGVkXCIgLz57XCJIYXJkIHJ1bGVzICh0aGVzZSBicmVhayBpbW1lZGlhdGVseS5ydW4gaWYgdmlvbGF0ZWQpXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMub2w+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL0FwcC50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGlzIHRoZSBlbnRyeSBwb2ludC5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgaW1tZWRpYXRlbHkucnVuIHJlbmRlcnMgaXRzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZGVmYXVsdFxcbmV4cG9ydFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIi4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL21haW4udHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpcyBmb3IgbG9jYWwgZGV2L2J1aWxkIG9ubHkgYW5kIGlzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiaWdub3JlZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBhdFxcbnJ1bnRpbWUg4oCUIG5ldmVyIHB1dCBDU1MgaW1wb3J0cywgcHJvdmlkZXJzLCBvciBhcHAgbG9naWMgdGhlcmUuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJJbXBvcnQgZ2xvYmFsIENTUyBmcm9tIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkFwcC50c3hcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBub3QgZnJvbSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJtYWluLnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuIEFueXRoaW5nIHRoZVxcbnJlbmRlcmVkIHRyZWUgbmVlZHMgKENTUywgY29udGV4dCBwcm92aWRlcnMpIG11c3QgYmUgcmVhY2hhYmxlIGZyb21cXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJBcHAudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkEgZmlsZSB0aGF0IGV4cG9ydHMgYSBSZWFjdCBjb21wb25lbnQgZXhwb3J0cyBPTkxZIGNvbXBvbmVudHMuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIE5vIG1peGluZyBhXFxuY29tcG9uZW50IHdpdGggbmFtZWQgZXhwb3J0cyBvZiBkYXRhL2NvbnN0YW50cy9oZWxwZXJzLiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW50ZXJmYWNlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJ0eXBlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIlxcbmFyZSBlcmFzZWQgYXQgY29tcGlsZSB0aW1lIGFuZCBhcmUgZmluZS4pIFRoaXMgaXMgdGhlIFJlYWN0IEZhc3QgUmVmcmVzaCBydWxlO1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcIm5wbSBydW4gbGludFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZW5mb3JjZXMgaXQuIFB1dCBkYXRhIGluIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9kYXRhL1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGhvb2tzIGluIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9ob29rcy9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLFxcbnV0aWxpdGllcyBpbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvbGliL1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJPbmUgY29tcG9uZW50IHBlciBmaWxlLCBkZWZhdWx0LWV4cG9ydGVkXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBuYW1lZCBmb3Igd2hhdCBpdCByZW5kZXJzLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQ1NTIGxpdmVzIGluIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi5jc3NcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGZpbGVzIGltcG9ydGVkIGZyb20gVHlwZVNjcmlwdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgbm90IGluIGdpYW50XFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiPHN0eWxlPlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYmxvY2tzIG9yIGlubGluZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzdHlsZT17e319XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBmb3IgdGhlIGJ1bGsgb2Ygc3R5bGluZy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkZvbnRzIHZpYSBDU1MgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQGltcG9ydFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnN0cm9uZz57XCIgYXMgdGhlIGZpcnN0IGxpbmUgb2YgdGhlIENTUyBmaWxlLCBub3QgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiPGxpbms+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIlxcbnRhZ3MgaW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW5kZXguaHRtbFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJJbXBvcnQgbG9jYWwgYXNzZXRzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJpbXBvcnQgbG9nbyBmcm9tICcuL2Fzc2V0cy9sb2dvLnBuZydcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKTsgZG9uJ3RcXG5yZWZlcmVuY2Ugc2VydmVyIHBhdGhzIHRoYXQgd29uJ3QgZXhpc3QgaW4gdGhlIHNhbmRib3guXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJObyBOb2RlIC8gYnVpbGQtdGltZS1vbmx5IEFQSXNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgaW4gdGhlIHJlbmRlcmVkIHRyZWUg4oCUIGl0IHJ1bnMgaW4gYSBicm93c2VyXFxuaWZyYW1lLiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJsb2NhbFN0b3JhZ2VcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJkb2N1bWVudFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIndpbmRvd1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGFuZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmZXRjaFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYXJlIGF2YWlsYWJsZS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIk5ldmVyIHdyaXRlIHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJpbXBvcnQubWV0YVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdG9rZW5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcImltcG9ydC5tZXRhLmVudlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcImltcG9ydC5tZXRhLnVybFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsXFxuZXZlbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ0eXBlb2YgaW1wb3J0Lm1ldGFcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKS4gVml0ZSByZXBsYWNlcyBpdCBhdCBidWlsZCB0aW1lLCBzbyBpdCBsb29rcyBmaW5lIGluXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widml0ZSBkZXZcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCBidXQgaW1tZWRpYXRlbHkucnVuIHRyYW5zcGlsZXMgZWFjaCBtb2R1bGUgdG8gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJDb21tb25KU1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBhbmRcXG5ydW5zIGl0IGFzIGEgY2xhc3NpYyBzY3JpcHQsIHdoZXJlIFwifTxfY29tcG9uZW50cy5jb2RlPntcImltcG9ydC5tZXRhXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpcyBhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicGFyc2UtdGltZVxcblwifTxfY29tcG9uZW50cy5jb2RlPntcIlN5bnRheEVycm9yXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoXFxcIkNhbm5vdCB1c2UgJ2ltcG9ydC5tZXRhJyBvdXRzaWRlIGEgbW9kdWxlXFxcIilcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIuIEl0IGZhaWxzIGJlZm9yZVxcbmFueSBjb2RlIHJ1bnMsIHNvIGEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiPy5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHJ1bnRpbWUgZ3VhcmQgY2FuJ3Qgc2F2ZSBpdC4gRm9yIGRldi1vbmx5IGJyYW5jaGVzLFxcbmluamVjdCBhIGZsYWcgdmlhIFZpdGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZGVmaW5lXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhbmQgcmVhZCBpdCBiZWhpbmQgYSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ0eXBlb2ZcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGd1YXJkIChzZWVcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJfX1dCX0RFVl9fXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ2aXRlLmNvbmZpZy50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgLyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvbGliL2JvYXJkU3RvcmUudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIk1EWCBpcyBvbmx5IGZvciBsb25nLWZvcm0gcHJvc2VcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKGFydGljbGVzLCBndWlkZXMpLiBTdHJ1Y3R1cmVkL3JlcGVhdGVkXFxuZGF0YSBzdGF5cyBhcyB0eXBlZCBhcnJheXMgaW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2RhdGEvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi4gSWYgeW91IGFkZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCIubWR4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgdGhlIFZpdGUgcGx1Z2luXFxuYW5kIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9tZHguZC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgc2hpbSBhcmUgYWxyZWFkeSB3aXJlZCB1cC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMub2w+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwibG9hZGluZy1jYWNoaW5nLW9uLWltbWVkaWF0ZWx5cnVuXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJsb2FkaW5nLWNhY2hpbmctb24taW1tZWRpYXRlbHlydW5cIiAvPntcIkxvYWRpbmcgJiBjYWNoaW5nIG9uIGltbWVkaWF0ZWx5LnJ1blwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLmNvZGU+e1wiLmdpdGh1Yi93b3JrZmxvd3MvY2FjaGUueW1sXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBwdWJsaXNoZXMgYSBwcmUtY2FjaGVkIHppcCBvZiB0aGlzIHJlcG8gdG8gaXRzIG93blxcbkdpdEh1YiBQYWdlcyBvbiBlYWNoIHB1c2ggdG8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibWFpblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIHNvIGltbWVkaWF0ZWx5LnJ1biBsb2FkcyBmYXN0IGFuZCB3aXRoaW5cXG5hbm9ueW1vdXMgcmF0ZSBsaW1pdHMuIEl0IG5lZWRzIFBhZ2VzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiU291cmNlOiBHaXRIdWIgQWN0aW9uc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBlbmFibGVkIG9uY2UgaW5cXG5yZXBvIHNldHRpbmdzLiBEb24ndCBtb3ZlIHRoZSBjYWNoZSB0byBhIGRpZmZlcmVudCBwYXRoIG9yIGhvc3RuYW1lIOKAlCB0aGUgY2xpZW50XFxuZGlzY292ZXJzIGl0IGJ5IGNvbnZlbnRpb24gYXRcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJodHRwczovLzxvd25lcj4uZ2l0aHViLmlvLzxyZXBvPi9jYWNoZWRfcmVwb3NpdG9yaWVzL21haW4uemlwXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLmNvZGU+e1wiXFxcImltbWVkaWF0ZWx5LnJ1blxcXCI6IHsgXFxcInJlcXVpcmVMYXRlc3RcXFwiOiBcXFwiLi4uXFxcIiB9XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJwYWNrYWdlLmpzb25cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNvbnRyb2xzXFxuZnJlc2huZXNzLiBJdCBpcyBhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wic3RyaW5nIGVudW1cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIsIG5vdCBhIGJvb2xlYW46IFwifTxfY29tcG9uZW50cy5jb2RlPntcIlxcXCJzdGFsZV9va1xcXCJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChhbHdheXMgc2VydmVcXG50aGUgY2FjaGUsIGZhc3Rlc3QsIG9mZmxpbmUtZnJpZW5kbHkpLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJcXFwib3B0aW1pc3RpY1xcXCJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICh0aGUgZGVmYXVsdCDigJQgc2VydmVcXG5jYWNoZSwgY2hlY2sgaW4gYmFja2dyb3VuZCksIG9yIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlxcXCJzdHJpY3RcXFwiXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoYWx3YXlzIHJ1biB0aGUgbmV3ZXN0IGNvbW1pdCwgYXRcXG50aGUgY29zdCBvZiBhIGZyZXNobmVzcyBjaGVjayBvbiBsYXVuY2gpLiBMZWF2ZSBpdCB1bnNldCB1bmxlc3NcXG50by10aGUtY29tbWl0IGZyZXNobmVzcyBtYXR0ZXJzOyB0aGUgZGVmYXVsdCBpcyBmYXN0IGFuZCB3b3JrcyBvZmZsaW5lLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJkZXNpZ24tc3lzdGVtXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJkZXNpZ24tc3lzdGVtXCIgLz57XCJEZXNpZ24gc3lzdGVtXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGlzIGJyYW5kIGlzOiBjb29sIG5lYXItYmxhY2sgY2FudmFzIMK3IG1hZ2VudGHihpR2aW9sZXQgc2lnbmF0dXJlIGdyYWRpZW50IMK3XFxuR2FiYXJpdG8gZGlzcGxheSB0eXBlIMK3IFNwYWNlIE1vbm8gZGV0YWlscyDCtyBoYWlybGluZSBib3JkZXJzIMK3IGhhcmQtb2Zmc2V0IGhvdmVyXFxuc2hhZG93cyDCtyBzZW50ZW5jZSBjYXNlIMK3IGhlYWRsaW5lcyBlbmQgb24gYSBwZXJpb2QgwrcgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJubyBlbW9qaVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIi4gRGFyayBpcyB0aGVcXG5kZWZhdWx0OyBhIGxpZ2h0IHRoZW1lIGlzIHdpcmVkIHZpYSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJkYXRhLXRoZW1lPVxcXCJsaWdodFxcXCJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG9uIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjxodG1sPlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJQdWxsIHRva2VucyBmcm9tIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9pbmRleC5jc3NcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChcIn08X2NvbXBvbmVudHMuY29kZT57XCItLWJnXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1wYW5lbFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi0taW5rXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1hY2NlbnRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcIi0tZ3JhZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi0tci1sZ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi0tc2hhZG93LWNhcmRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCB0aGUgdHlwZSBmYW1pbGllcywgZXRjLikgaW5zdGVhZCBvZlxcbmhhcmQtY29kaW5nIGNvbG9ycywgcmFkaWksIG9yIGZvbnRzLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIkFwcGx5IHRoZSBzaWduYXR1cmUgZ3JhZGllbnQgdG8gdGV4dCB3aXRoIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNsYXNzTmFtZT1cXFwiZ3JhZC10ZXh0XFxcIlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiRm9yIGljb25zIGJleW9uZCB0aGUgdW5pY29kZSBzZXQgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIuKGkiDimIUg4pePIOKYgCDimL5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSwgdXNlXFxuXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cImh0dHBzOi8vbHVjaWRlLmRldlwiPntcIkx1Y2lkZVwifTwvX2NvbXBvbmVudHMuYT57XCIgYXQgMTbigJMyNHB4LCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjdXJyZW50Q29sb3JcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLiBObyBlbW9qaS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwicGxhdGZvcm0tc2VjdXJpdHktbW9kZWwtd2hhdC15b3VyLWFwcC1jYW4tYW5kLWNhbnQtZG9cIj48SGVhZGluZ0FuY2hvciBpZD1cInBsYXRmb3JtLXNlY3VyaXR5LW1vZGVsLXdoYXQteW91ci1hcHAtY2FuLWFuZC1jYW50LWRvXCIgLz57XCJQbGF0Zm9ybSBzZWN1cml0eSBtb2RlbCAod2hhdCB5b3VyIGFwcCBjYW4gYW5kIGNhbid0IGRvKVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiWW91ciBhcHAgcnVucyBpbiBhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wic2FuZGJveGVkIGlmcmFtZSB3aXRoIGFuIG9wYXF1ZSBvcmlnaW5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIuIFRoZSBydWxlcyBiZWxvd1xcbmZvbGxvdyBmcm9tIHRoYXQgYW5kIGZyb20gdGhlIHBsYXRmb3JtIGNhcGFiaWxpdHkgbW9kZWxcXG4oXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZG9jcy9zcGVjcy9VSV9BU19BUFBTX1NQRUMubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIMKnOCBpbiB0aGUgZG9jcyByZXBvKS4gVmlvbGF0aW9ucyBkb24ndCBqdXN0XFxuYnJlYWsgeW91ciBhcHAg4oCUIGNhbGxzIGZhaWwgd2l0aCB0eXBlZCBlcnJvcnMsIGFuZCB0cnlpbmcgdG8gd29yayBhcm91bmQgdGhlbVxcbnJlYWRzIGFzIGhvc3RpbGUuIChFbmZvcmNlbWVudCBpcyByb2xsaW5nIG91dCBwZXIgdGhlIHNwZWMncyDCpzEwIGxhZGRlciDigJRcXG5pdGVtcyA0LCA2IGFuZCA4IGRlc2NyaWJlIG1hY2hpbmVyeSB0aGF0IGlzIHNwZWNpZmllZCBidXQgbm90IHlldCBsaXZlOyB3cml0ZVxcbm5ldyBjb2RlIGFzIGlmIHRoZXkncmUgZW5mb3JjZWQgYW5kIGl0IHdpbGwga2VlcCB3b3JraW5nIGFzIHRoZXkgbGFuZC4pXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJBbGwgcGxhdGZvcm0gaW50ZXJhY3Rpb24gZ29lcyB0aHJvdWdoIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkBpbW1lZGlhdGVseS1ydW4vc2RrXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhlcmUgaXNcXG5ubyBvdGhlciBjaGFubmVsOiBubyBzaGFyZWQgc3RvcmFnZSB3aXRoIG90aGVyIGFwcHMsIG5vIHJlYWNoaW5nIHNpYmxpbmdcXG5pZnJhbWVzLCBubyBwb3N0TWVzc2FnZSBvZiB5b3VyIG93biB0byB0aGUgcGFyZW50LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiTmV2ZXIgaGFuZGxlIHVzZXIgY3JlZGVudGlhbHMuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFlvdSB3aWxsIG5ldmVyIHNlZSB0aGUgdXNlcidzIEdpdEh1YlxcbnRva2VuLCBBUEkga2V5cywgb3IgYW55IHNlY3JldCDigJQgc2lnbi1pbiBhbmQgcHJpdmlsZWdlZCBhY3Rpb25zIGFyZVxcbmhvc3QtZHJpdmVuLiBDYWxsIHByb3RvY29sIG1ldGhvZHMgcmVhY3RpdmVseSwgZ2F0ZWQgb25cXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJnZXRBdXRoU3RhdGUoKS5zdGF0dXMgPT09ICdzaWduZWQtaW4nXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjsgbmV2ZXIgc3RvcmUgb3IgcmVxdWVzdCB0b2tlbnMuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgZmlsZXN5c3RlbSB5b3Ugc2VlIGlzIHRoZSBmaWxlc3lzdGVtIHlvdSBnb3QuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIE1vdW50cyB0aGUgaG9zdCBnaXZlc1xcbnlvdSAoeW91ciBhcHAncyBzcGFjZXMsIGdyYW50ZWQgZm9sZGVycykgYXJlIHlvdXIgd2hvbGUgd29ybGQg4oCUIG91dHNpZGVcXG5wYXRocyBkb24ndCBleGlzdCwgYW5kIGEgZ3JhbnQgbWF5IGJlIHJlYWQtb25seS4gRG9uJ3QgcHJvYmUgZm9yIGVzY2FwZXNcXG4oXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLi5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBhYnNvbHV0ZSBwYXRocyk7IHdyaXRlcyB0byByZWFkLW9ubHkgbW91bnRzIGZhaWwgd2l0aCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJFUk9GU1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJBY2Nlc3MgdG8gbW9yZSBkYXRhIGlzIGFza2VkIGZvciwgbm90IHRha2VuLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBOZWVkIGFub3RoZXIgc3BhY2Ugb3JcXG5mb2xkZXI/IENhbGwgdGhlIFNESyByZXF1ZXN0IG1ldGhvZCBhbmQgdGhlIFwifTxfY29tcG9uZW50cy5lbT57XCJ1c2VyXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgcGlja3MgaW4gaG9zdCBVSS4gRXhwZWN0XFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wieyBvazogZmFsc2UsIGNvZGU6ICdjYW5jZWxsZWQnIHwgJ2ZvcmJpZGRlbicgfVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYW5kIGhhbmRsZSBpdCBncmFjZWZ1bGx5LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiSGFuZGxlIHR5cGVkIGVycm9ycyBldmVyeXdoZXJlLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBQbGF0Zm9ybSBjYWxscyByZXBseVxcblwifTxfY29tcG9uZW50cy5jb2RlPntcInsgb2s6IGZhbHNlLCBjb2RlLCBtZXNzYWdlIH1cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJmb3JiaWRkZW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJhdXRoLXJlcXVpcmVkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2FuY2VsbGVkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIixcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJpbnZhbGlkLXBhcmFtc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIOKApikuIFwifTxfY29tcG9uZW50cy5jb2RlPntcImZvcmJpZGRlblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgbWVhbnMgeW91ciBhcHAgbGFja3MgdGhhdCBjYXBhYmlsaXR5IOKAlFxcbnRoYXQncyBwb2xpY3ksIG5vdCBhIGJ1ZyB0byByZXRyeSBhcm91bmQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJEZWNsYXJlIHdoYXQgeW91IGludm9rZSBhbmQgcHJvdmlkZS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgQ3Jvc3MtYXBwIHRhc2tzIGdvIGluXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicGFja2FnZS5qc29uXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB1bmRlciBcIn08X2NvbXBvbmVudHMuY29kZT57XCJcXFwiaW1tZWRpYXRlbHkucnVuXFxcIlwifTwvX2NvbXBvbmVudHMuY29kZT57XCI6IFwifTxfY29tcG9uZW50cy5jb2RlPntcIlxcXCJpbnZva2VzXFxcIlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZm9yIHRhc2sgY29udHJhY3RzXFxueW91IGNhbGwsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlxcXCJwcm92aWRlc1xcXCJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGZvciBvbmVzIHlvdSBpbXBsZW1lbnQuIFVuZGVjbGFyZWQgaW52b2NhdGlvbnMgYXJlXFxucmVqZWN0ZWQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJEb24ndCBpbWl0YXRlIGhvc3QgY2hyb21lLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBOZXZlciByZW5kZXIgZmFrZSBzaWduLWluIHByb21wdHMsIGNvbnNlbnRcXG5kaWFsb2dzLCBvciB0aGUgcGxhdGZvcm0ncyBzZWFtL2hlYWRlciBVSS4gVGhlIGhvc3QgZHJhd3MgdGhvc2U7IGltaXRhdGlvbnNcXG5hcmUgdHJlYXRlZCBhcyBzcG9vZmluZy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIklmIHlvdSBlbWJlZCBhbiBMTE0gYWdlbnQsIGl0cyB0b29sIGxpc3QgaXMgeW91ciBjYXRhbG9nLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBVc2UgdGhlXFxuU0RLLXByb3ZpZGVkIG1ldGhvZCBjYXRhbG9nIGFzIHRoZSBhZ2VudCdzIHRvb2xzIOKAlCBpdCBpcyBwcmUtZmlsdGVyZWQgdG9cXG55b3VyIGFwcCdzIGdyYW50cywgc28gdGhlIGFnZW50IGNhbid0IGV4Y2VlZCB3aGF0IHlvdXIgYXBwIG1heSBkby4gRG9uJ3RcXG5oYW5kLXJvbGwgdG9vbHMgdGhhdCBzaGVsbCBhcm91bmQgdGhlIFNESy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkV4cGVjdCBjYW5jZWxsYXRpb24gYW5kIGFic2VuY2UuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIEludGVyYWN0aXZlIGZsb3dzIGNhbiByZXNvbHZlXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2FuY2VsbGVkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjsgY2FwYWJpbGl0aWVzIGNhbiBiZSBhYnNlbnQgb24gYSBmb3JrIG9mIHlvdXIgYXBwLiBEZWdyYWRlXFxuZmVhdHVyZXMsIGRvbid0IGNyYXNoLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJ2ZXJpZnktYmVmb3JlLXlvdXJlLWRvbmVcIj48SGVhZGluZ0FuY2hvciBpZD1cInZlcmlmeS1iZWZvcmUteW91cmUtZG9uZVwiIC8+e1wiVmVyaWZ5IGJlZm9yZSB5b3UncmUgZG9uZVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnByZT48X2NvbXBvbmVudHMuY29kZSBjbGFzc05hbWU9XCJsYW5ndWFnZS1iYXNoXCI+e1wibnBtIHJ1biBidWlsZCAgICMgbXVzdCBwYXNzIHdpdGggbm8gdHlwZSBlcnJvcnNcXG5ucG0gcnVuIGxpbnQgICAgIyBtdXN0IHBhc3Mg4oCUIHRoaXMgaXMgdGhlIGNoZWFwZXN0IHByb29mIHRoZSBGYXN0IFJlZnJlc2ggcnVsZSBob2xkc1xcblwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnByZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGVuIGV5ZWJhbGwgdGhlIHBhZ2UgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIm5wbSBydW4gZGV2XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikgYW5kIGNsaWNrIGFueSBpbnRlcmFjdGl2ZSBjb250cm9scy5cIn08L19jb21wb25lbnRzLnA+PC8+O1xufVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTURYQ29udGVudChwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHt3cmFwcGVyOiBNRFhMYXlvdXR9ID0ge1xuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfTtcbiAgcmV0dXJuIE1EWExheW91dCA/IDxNRFhMYXlvdXQgey4uLnByb3BzfT48X2NyZWF0ZU1keENvbnRlbnQgey4uLnByb3BzfSAvPjwvTURYTGF5b3V0PiA6IF9jcmVhdGVNZHhDb250ZW50KHByb3BzKTtcbn1cbmZ1bmN0aW9uIF9taXNzaW5nTWR4UmVmZXJlbmNlKGlkLCBjb21wb25lbnQsIHBsYWNlKSB7XG4gIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIFwiICsgKGNvbXBvbmVudCA/IFwiY29tcG9uZW50XCIgOiBcIm9iamVjdFwiKSArIFwiIGBcIiArIGlkICsgXCJgIHRvIGJlIGRlZmluZWQ6IHlvdSBsaWtlbHkgZm9yZ290IHRvIGltcG9ydCwgcGFzcywgb3IgcHJvdmlkZSBpdC5cIiArIChwbGFjZSA/IFwiXFxuSXTigJlzIHJlZmVyZW5jZWQgaW4geW91ciBjb2RlIGF0IGBcIiArIHBsYWNlICsgXCJgIGluIGAvYXBwL0NMQVVERS5tZGBcIiA6IFwiXCIpKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQXdGLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUZ4RjtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU1DLFdBQVcsR0FBRztNQUNsQkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsSUFBSSxFQUFFLE1BQU07TUFDWkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsR0FBRyxFQUFFLEtBQUs7TUFDVkMsTUFBTSxFQUFFLFFBQVE7TUFDaEJDLEVBQUUsRUFBRSxJQUFJO01BQ1IsR0FBRyxJQUFBQyw2QkFBa0IsRUFBQyxDQUFDO01BQ3ZCLEdBQUdiLEtBQUssQ0FBQ2M7SUFDWCxDQUFDO0lBQUU7TUFBQ0M7SUFBYSxDQUFDLEdBQUdkLFdBQVc7RUFDaEMsSUFBSSxDQUFDYyxhQUFhLEVBQUVDLG9CQUFvQixDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUM7RUFDL0Qsb0JBQU8sSUFBQWxCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQW5CLFdBQUEsQ0FBQW9CLFFBQUE7SUFBQUMsUUFBQSxnQkFBRSxJQUFBckIsV0FBQSxDQUFBbUIsSUFBQSxFQUFDaEIsV0FBVyxDQUFDSSxFQUFFO01BQUNlLEVBQUUsRUFBQyxzQkFBc0I7TUFBQUQsUUFBQSxnQkFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFzQixDQUFFLENBQUMsRUFBQyxzQkFBc0I7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNRLENBQUM7TUFBQVUsUUFBQSxHQUFFLGFBQWEsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDVSxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFxQixDQUFxQixDQUFDLEVBQUMsNEpBQTRKLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBZSxRQUFBLEVBQUU7TUFBTSxDQUFpQixDQUFDLEVBQUMseURBQXlELGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQVUsQ0FBbUIsQ0FBQyxFQUFDLG9DQUFvQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDYyxFQUFFLEVBQUMsbURBQW1EO01BQUFELFFBQUEsZ0JBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBbUQsQ0FBRSxDQUFDLEVBQUMsc0RBQXNEO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBbUIsSUFBQSxFQUFDaEIsV0FBVyxDQUFDTyxFQUFFO01BQUFXLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ00sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUFyQixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNVLE1BQU07VUFBQVEsUUFBQSxnQkFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1lBQUFnQixRQUFBLEVBQUU7VUFBYSxDQUFtQixDQUFDLEVBQUMsc0JBQXNCO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLCtCQUErQixlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNVLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQWlCLENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLHNDQUFzQyxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNVLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQVMsQ0FBcUIsQ0FBQyxFQUFDLHNFQUFzRTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ00sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUFyQixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNVLE1BQU07VUFBQVEsUUFBQSxHQUFFLHlCQUF5QixlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7WUFBQWdCLFFBQUEsRUFBRTtVQUFTLENBQW1CLENBQUM7UUFBQSxDQUFvQixDQUFDLEVBQUMsYUFBYSxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQyx1RkFBdUYsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBUyxDQUFtQixDQUFDLEVBQUMsR0FBRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ00sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNVLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQWdFLENBQXFCLENBQUMsRUFBQyx5RUFBeUUsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFNLENBQW1CLENBQUMsRUFBQyxvRkFBb0YsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBYyxDQUFtQixDQUFDLEVBQUMsNEJBQTRCLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLGFBQWEsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBWSxDQUFtQixDQUFDLEVBQUMsa0JBQWtCLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVUsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNNLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDVSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUEwQyxDQUFxQixDQUFDLEVBQUMsOEJBQThCO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBbUIsSUFBQSxFQUFDaEIsV0FBVyxDQUFDTSxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXJCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBUSxRQUFBLEdBQUUsZUFBZSxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7WUFBQWdCLFFBQUEsRUFBRTtVQUFNLENBQW1CLENBQUMsRUFBQyxpQ0FBaUM7UUFBQSxDQUFxQixDQUFDLEVBQUMsbUJBQW1CLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVMsQ0FBbUIsQ0FBQyxFQUFDLG9CQUFvQixlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFZLENBQW1CLENBQUMsRUFBQywyQkFBMkI7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNNLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBckIsV0FBQSxDQUFBbUIsSUFBQSxFQUFDaEIsV0FBVyxDQUFDVSxNQUFNO1VBQUFRLFFBQUEsR0FBRSxnQkFBZ0IsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1lBQUFnQixRQUFBLEVBQUU7VUFBUyxDQUFtQixDQUFDO1FBQUEsQ0FBb0IsQ0FBQyxFQUFDLDBDQUEwQyxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFRLENBQW1CLENBQUMsRUFBQyxZQUFZLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVksQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNNLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDVSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFxQixDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFzQyxDQUFtQixDQUFDLEVBQUMsbUVBQW1FO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBbUIsSUFBQSxFQUFDaEIsV0FBVyxDQUFDTSxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBZ0MsQ0FBcUIsQ0FBQyxFQUFDLHdEQUF3RCxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVUsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsUUFBUSxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFPLENBQW1CLENBQUMsRUFBQyxpQkFBaUI7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNNLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBckIsV0FBQSxDQUFBbUIsSUFBQSxFQUFDaEIsV0FBVyxDQUFDVSxNQUFNO1VBQUFRLFFBQUEsR0FBRSxrQkFBa0IsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1lBQUFnQixRQUFBLEVBQUU7VUFBYSxDQUFtQixDQUFDLEVBQUMsUUFBUTtRQUFBLENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWlCLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWlCLENBQW1CLENBQUMsRUFBQyxVQUFVLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQW9CLENBQW1CLENBQUMsRUFBQywwREFBMEQsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBVSxDQUFtQixDQUFDLEVBQUMsbURBQW1ELGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBVSxDQUFxQixDQUFDLEVBQUMsMkNBQTJDLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQyxFQUFDLFFBQVEsZUFBQyxJQUFBckIsV0FBQSxDQUFBbUIsSUFBQSxFQUFDaEIsV0FBVyxDQUFDVSxNQUFNO1VBQUFRLFFBQUEsR0FBRSxjQUFjLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBZ0IsUUFBQSxFQUFFO1VBQWEsQ0FBbUIsQ0FBQyxFQUFDLGtEQUFrRDtRQUFBLENBQXFCLENBQUMsRUFBQyx5Q0FBeUMsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBSSxDQUFtQixDQUFDLEVBQUMsK0VBQStFLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVEsQ0FBbUIsQ0FBQyxFQUFDLHdCQUF3QixlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFRLENBQW1CLENBQUMsRUFBQyxlQUFlLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVksQ0FBbUIsQ0FBQyxFQUFDLE1BQU0sZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBdUIsQ0FBbUIsQ0FBQyxFQUFDLElBQUk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNNLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDVSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFpQyxDQUFxQixDQUFDLEVBQUMsMEVBQTBFLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLGVBQWUsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBTSxDQUFtQixDQUFDLEVBQUMseUJBQXlCLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLDZCQUE2QjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBbUIsSUFBQSxFQUFDaEIsV0FBVyxDQUFDSyxFQUFFO01BQUNjLEVBQUUsRUFBQyxtQ0FBbUM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFtQyxDQUFFLENBQUMsRUFBQyxzQ0FBc0M7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNRLENBQUM7TUFBQVUsUUFBQSxnQkFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBNkIsQ0FBbUIsQ0FBQyxFQUFDLG9GQUFvRixlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFNLENBQW1CLENBQUMsRUFBQyxvRkFBb0YsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDVSxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUF3QixDQUFxQixDQUFDLEVBQUMscUlBQXFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQStELENBQW1CLENBQUMsRUFBQyxHQUFHO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBbUIsSUFBQSxFQUFDaEIsV0FBVyxDQUFDUSxDQUFDO01BQUFVLFFBQUEsZ0JBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQXFELENBQW1CLENBQUMsRUFBQyxNQUFNLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQWMsQ0FBbUIsQ0FBQyxFQUFDLGdDQUFnQyxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNVLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQWEsQ0FBcUIsQ0FBQyxFQUFDLG1CQUFtQixlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFjLENBQW1CLENBQUMsRUFBQyx5REFBeUQsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLHlEQUF5RCxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFZLENBQW1CLENBQUMsRUFBQyw4S0FBOEs7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNLLEVBQUU7TUFBQ2MsRUFBRSxFQUFDLGVBQWU7TUFBQUQsUUFBQSxnQkFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFlLENBQUUsQ0FBQyxFQUFDLGVBQWU7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNRLENBQUM7TUFBQVUsUUFBQSxHQUFFLHdOQUF3TixlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNVLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQVUsQ0FBcUIsQ0FBQyxFQUFDLHFEQUFxRCxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFzQixDQUFtQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFRLENBQW1CLENBQUMsRUFBQyxHQUFHO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBbUIsSUFBQSxFQUFDaEIsV0FBVyxDQUFDVyxFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ00sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUFyQixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNVLE1BQU07VUFBQVEsUUFBQSxHQUFFLG1CQUFtQixlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7WUFBQWdCLFFBQUEsRUFBRTtVQUFlLENBQW1CLENBQUM7UUFBQSxDQUFvQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFNLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVMsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBTyxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVEsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFlLENBQW1CLENBQUMsRUFBQyw2RUFBNkU7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNNLEVBQUU7UUFBQVksUUFBQSxHQUFFLDRDQUE0QyxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUF5QixDQUFtQixDQUFDLEVBQUMsR0FBRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ00sRUFBRTtRQUFBWSxRQUFBLEdBQUUsb0NBQW9DLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLFVBQVUsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDQyxDQUFDO1VBQUNvQixJQUFJLEVBQUMsb0JBQW9CO1VBQUFILFFBQUEsRUFBRTtRQUFRLENBQWdCLENBQUMsRUFBQyxlQUFlLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLGFBQWE7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDYyxFQUFFLEVBQUMsdURBQXVEO01BQUFELFFBQUEsZ0JBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBdUQsQ0FBRSxDQUFDLEVBQUMsMERBQTBEO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBbUIsSUFBQSxFQUFDaEIsV0FBVyxDQUFDUSxDQUFDO01BQUFVLFFBQUEsR0FBRSxxQkFBcUIsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDVSxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUF3QyxDQUFxQixDQUFDLEVBQUMsK0VBQStFLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQStCLENBQW1CLENBQUMsRUFBQyxnV0FBZ1c7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNPLEVBQUU7TUFBQVcsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBbUIsSUFBQSxFQUFDaEIsV0FBVyxDQUFDTSxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXJCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBUSxRQUFBLEdBQUUsd0NBQXdDLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBZ0IsUUFBQSxFQUFFO1VBQXNCLENBQW1CLENBQUMsRUFBQyxHQUFHO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLHlJQUF5STtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ00sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNVLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQWdDLENBQXFCLENBQUMsRUFBQyx1S0FBdUssZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBdUMsQ0FBbUIsQ0FBQyxFQUFDLGtDQUFrQztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ00sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNVLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQW1ELENBQXFCLENBQUMsRUFBQyw4S0FBOEssZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBSSxDQUFtQixDQUFDLEVBQUMsMERBQTBELGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQU8sQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNNLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDVSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUE4QyxDQUFxQixDQUFDLEVBQUMsc0VBQXNFLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBZSxRQUFBLEVBQUU7UUFBTSxDQUFpQixDQUFDLEVBQUMsNkJBQTZCLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWdELENBQW1CLENBQUMsRUFBQyw0QkFBNEI7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNNLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDVSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFpQyxDQUFxQixDQUFDLEVBQUMseUJBQXlCLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQThCLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBZSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWdCLENBQW1CLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLG9GQUFvRjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ00sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNVLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQXNDLENBQXFCLENBQUMsRUFBQywwQkFBMEIsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBYyxDQUFtQixDQUFDLEVBQUMsU0FBUyxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFxQixDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyxpQ0FBaUMsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBYyxDQUFtQixDQUFDLEVBQUMsZ0VBQWdFO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBbUIsSUFBQSxFQUFDaEIsV0FBVyxDQUFDTSxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBNEIsQ0FBcUIsQ0FBQyxFQUFDLG9KQUFvSjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ00sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNVLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQTJELENBQXFCLENBQUMsRUFBQywwTUFBME07TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNNLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDVSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFrQyxDQUFxQixDQUFDLEVBQUMsa0NBQWtDLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLHFGQUFxRjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBbUIsSUFBQSxFQUFDaEIsV0FBVyxDQUFDSyxFQUFFO01BQUNjLEVBQUUsRUFBQywwQkFBMEI7TUFBQUQsUUFBQSxnQkFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUEwQixDQUFFLENBQUMsRUFBQywyQkFBMkI7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNTLEdBQUc7TUFBQVMsUUFBQSxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7UUFBQ29CLFNBQVMsRUFBQyxlQUFlO1FBQUFKLFFBQUEsRUFBRTtNQUF5SSxDQUFtQjtJQUFDLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ1EsQ0FBQztNQUFBVSxRQUFBLEdBQUUseUJBQXlCLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQWEsQ0FBbUIsQ0FBQyxFQUFDLHVDQUF1QztJQUFBLENBQWdCLENBQUM7RUFBQSxDQUFFLENBQUM7QUFDcGpiO0FBQ2UsU0FBU0ssVUFBVUEsQ0FBQ3hCLEtBQUssR0FBRyxDQUFDLENBQUMsRUFBRTtFQUM3QyxNQUFNO0lBQUN5QixPQUFPLEVBQUVDO0VBQVMsQ0FBQyxHQUFHO0lBQzNCLEdBQUcsSUFBQWIsNkJBQWtCLEVBQUMsQ0FBQztJQUN2QixHQUFHYixLQUFLLENBQUNjO0VBQ1gsQ0FBQztFQUNELE9BQU9ZLFNBQVMsZ0JBQUcsSUFBQTVCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ0ssU0FBUztJQUFBLEdBQUsxQixLQUFLO0lBQUFtQixRQUFBLGVBQUUsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3RCLGlCQUFpQjtNQUFBLEdBQUtDO0lBQUssQ0FBRztFQUFDLENBQVcsQ0FBQyxHQUFHRCxpQkFBaUIsQ0FBQ0MsS0FBSyxDQUFDO0FBQ2xIO0FBQUMyQixFQUFBLEdBTnVCSCxVQUFVO0FBT2xDLFNBQVNSLG9CQUFvQkEsQ0FBQ0ksRUFBRSxFQUFFUSxTQUFTLEVBQUVDLEtBQUssRUFBRTtFQUNsRCxNQUFNLElBQUlDLEtBQUssQ0FBQyxXQUFXLElBQUlGLFNBQVMsR0FBRyxXQUFXLEdBQUcsUUFBUSxDQUFDLEdBQUcsSUFBSSxHQUFHUixFQUFFLEdBQUcsb0VBQW9FLElBQUlTLEtBQUssR0FBRyxxQ0FBcUMsR0FBR0EsS0FBSyxHQUFHLHVCQUF1QixHQUFHLEVBQUUsQ0FBQyxDQUFDO0FBQ2pQO0FBQUMsSUFBQUYsRUFBQTtBQUFBSSxZQUFBLENBQUFKLEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}