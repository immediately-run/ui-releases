var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      code: "code",
      del: "del",
      h1: "h1",
      h2: "h2",
      hr: "hr",
      li: "li",
      p: "p",
      strong: "strong",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "code_spec_references-lodestar",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "code_spec_references-lodestar"
      }), "CODE_SPEC_REFERENCES — Lodestar"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Durable index of ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "non-trivial"
      }), " code↔spec mappings. Seeded by the 2026-06\ncode-verification pass (R3-124; plan ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "08-system-apps.md"
      }), "). Most Lodestar\nspec-refs are trivial inline ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "spec §N"
      }), " comments (the bare ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "spec §N"
      }), " convention =\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "WHITEBOARD_SPEC §N"
      }), ", which lives in the whiteboard-app docs subdir, not the main\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "docs/specs/"
      }), " checkout). This file records only the non-obvious mappings."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "the-importmeta-ban-__wb_dev__-define-claudemd-hard-rule-9",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-importmeta-ban-__wb_dev__-define-claudemd-hard-rule-9"
      }), "The ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "import.meta"
      }), " ban ↔ ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "__WB_DEV__"
      }), " define (CLAUDE.md hard-rule #9)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Why non-obvious:"
      }), " immediately.run transpiles each module to CommonJS and runs\nit as a classic script, where ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "import.meta"
      }), " is a ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["parse-time ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "SyntaxError"
        })]
      }), "\n(\"Cannot use 'import.meta' outside a module\") — it fails before any code runs, so\na ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "?."
      }), " runtime guard cannot save it. Vite replaces ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "import.meta"
      }), " at build time, so\nit looks fine in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "vite dev"
      }), " and only breaks on immediately.run."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["Mapping (verified 2026-06 — correctly implemented; DO NOT reintroduce\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "import.meta"
        }), "):"]
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "vite.config.ts"
        }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "define: { __WB_DEV__: ... }"
        }), " injects a dev-only flag."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/lib/boardStore.ts"
        }), " — reads it behind a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "typeof __WB_DEV__ !== 'undefined'"
        }), "\nguard (declares ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "__WB_DEV__: boolean | undefined"
        }), "). No file in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/"
        }), " writes the\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "import.meta"
        }), " token (only comments mention it)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "the-three-task-invoke-surface",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-three-task-invoke-surface"
      }), "The three-task invoke surface"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Spec:"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "WHITEBOARD_SPEC"
      }), " (+ ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "PICK_FILE_TASK_SPEC"
      }), "). core_concepts §6 (Service)\n/ §5 (display-in-a-region capability). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "package.json"
      }), " declares\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "invokes: pick-file, share-space, edit-file"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Mapping (verified 2026-06):"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "pick-file"
        }), " — fully wired: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/lib/pickFile.ts"
        }), " calls\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "invokeTask<PickFileResult>('pick-file', …)"
        }), ", returns ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "null"
        }), " on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "cancelled"
        }), "\n(callers degrade with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "if (!res) return"
        }), "). This is the live, complete path."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "share-space"
        }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "edit-file"
        }), " — declared as ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "invokes"
        }), " and surfaced as ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "toast\nplaceholders"
        }), " today (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "TopBar.tsx"
        }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "MobileChrome.tsx"
        }), " for share-space;\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Inspector.tsx"
        }), " for edit-file \"Open source\"). They degrade rather than crash\nwhen the task is absent (core_concepts invariant: \"expect absence\"). Recorded as\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "partial / placeholder"
        }), ", not a Done-but-absent gap — the manifest correctly\ndeclares intent and the UI handles absence."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "recorded-findings-code-verification-pass-2026-06",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "recorded-findings-code-verification-pass-2026-06"
      }), "Recorded findings (code-verification pass, 2026-06)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.del, {
            children: "SDK-version skew"
          }), " — RESOLVED (verified 2026-09-22, R3-737 review;\nre-verified 2026-09-29, R3-832):"]
        }), " the 2026-06 entry recorded a pin of ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "0.8.1"
        }), "\nwhile others sat lower; the pin moved to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "^0.17.0"
        }), " and is now ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["exact\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "0.74.1"
          })]
        }), " — the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "^0.17.0"
        }), " range floor-resolved to 0.17.0 in the sandbox and\nits ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "waitForMount"
        }), " TDZ bug broke board persistence on prod (R3-832), so the\n\"no action in this repo\" verdict did not survive contact; the skew class is\notherwise fleet-maintenance debt tracked across the example repos, not here."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Vocabulary:"
        }), " no ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "kernel"
        }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "primary application"
        }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "trust tier"
        }), " in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/"
        }), ";\nuses \"stage app\" correctly. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "main.tsx"
        }), " carries no app logic/CSS."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "requireLatest: \"optimistic\""
          })
        }), " (the default) — appropriate; not a finding."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.del, {
            children: ["BUILD RED on origin/main (pre-existing, SDK-skew) — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "capDir"
            }), " not exported."]
          })
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "RESOLVED (verified 2026-09-22, R3-737 review; re-verified 2026-09-29, R3-832):"
        }), "\nthe pinned SDK (now exact ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "0.74.1"
        }), ") exports ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "capDir"
        }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npm run build"
        }), " is\ngreen on this head — the recorded ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "TS2339"
        }), " no longer reproduces; the entry is\nkept struck as the resolution record rather than deleted (this file is a\nledger)."]
      }), "\n"]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/CODE_SPEC_REFERENCES.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJjb2RlIiwiZGVsIiwiaDEiLCJoMiIsImhyIiwibGkiLCJwIiwic3Ryb25nIiwidWwiLCJfcHJvdmlkZUNvbXBvbmVudHMiLCJjb21wb25lbnRzIiwiSGVhZGluZ0FuY2hvciIsIl9taXNzaW5nTWR4UmVmZXJlbmNlIiwianN4cyIsIkZyYWdtZW50IiwiY2hpbGRyZW4iLCJpZCIsImpzeCIsIk1EWENvbnRlbnQiLCJ3cmFwcGVyIiwiTURYTGF5b3V0IiwiX2MiLCJjb21wb25lbnQiLCJwbGFjZSIsIkVycm9yIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQ09ERV9TUEVDX1JFRkVSRU5DRVMubWQiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgZGVsOiBcImRlbFwiLFxuICAgIGgxOiBcImgxXCIsXG4gICAgaDI6IFwiaDJcIixcbiAgICBocjogXCJoclwiLFxuICAgIGxpOiBcImxpXCIsXG4gICAgcDogXCJwXCIsXG4gICAgc3Ryb25nOiBcInN0cm9uZ1wiLFxuICAgIHVsOiBcInVsXCIsXG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9LCB7SGVhZGluZ0FuY2hvcn0gPSBfY29tcG9uZW50cztcbiAgaWYgKCFIZWFkaW5nQW5jaG9yKSBfbWlzc2luZ01keFJlZmVyZW5jZShcIkhlYWRpbmdBbmNob3JcIiwgdHJ1ZSk7XG4gIHJldHVybiA8PjxfY29tcG9uZW50cy5oMSBpZD1cImNvZGVfc3BlY19yZWZlcmVuY2VzLWxvZGVzdGFyXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJjb2RlX3NwZWNfcmVmZXJlbmNlcy1sb2Rlc3RhclwiIC8+e1wiQ09ERV9TUEVDX1JFRkVSRU5DRVMg4oCUIExvZGVzdGFyXCJ9PC9fY29tcG9uZW50cy5oMT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJEdXJhYmxlIGluZGV4IG9mIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibm9uLXRyaXZpYWxcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgY29kZeKGlHNwZWMgbWFwcGluZ3MuIFNlZWRlZCBieSB0aGUgMjAyNi0wNlxcbmNvZGUtdmVyaWZpY2F0aW9uIHBhc3MgKFIzLTEyNDsgcGxhbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCIwOC1zeXN0ZW0tYXBwcy5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLiBNb3N0IExvZGVzdGFyXFxuc3BlYy1yZWZzIGFyZSB0cml2aWFsIGlubGluZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcGVjIMKnTlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgY29tbWVudHMgKHRoZSBiYXJlIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNwZWMgwqdOXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjb252ZW50aW9uID1cXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJXSElURUJPQVJEX1NQRUMgwqdOXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgd2hpY2ggbGl2ZXMgaW4gdGhlIHdoaXRlYm9hcmQtYXBwIGRvY3Mgc3ViZGlyLCBub3QgdGhlIG1haW5cXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJkb2NzL3NwZWNzL1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgY2hlY2tvdXQpLiBUaGlzIGZpbGUgcmVjb3JkcyBvbmx5IHRoZSBub24tb2J2aW91cyBtYXBwaW5ncy5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwidGhlLWltcG9ydG1ldGEtYmFuLV9fd2JfZGV2X18tZGVmaW5lLWNsYXVkZW1kLWhhcmQtcnVsZS05XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJ0aGUtaW1wb3J0bWV0YS1iYW4tX193Yl9kZXZfXy1kZWZpbmUtY2xhdWRlbWQtaGFyZC1ydWxlLTlcIiAvPntcIlRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJpbXBvcnQubWV0YVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYmFuIOKGlCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJfX1dCX0RFVl9fXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBkZWZpbmUgKENMQVVERS5tZCBoYXJkLXJ1bGUgIzkpXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIldoeSBub24tb2J2aW91czpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgaW1tZWRpYXRlbHkucnVuIHRyYW5zcGlsZXMgZWFjaCBtb2R1bGUgdG8gQ29tbW9uSlMgYW5kIHJ1bnNcXG5pdCBhcyBhIGNsYXNzaWMgc2NyaXB0LCB3aGVyZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJpbXBvcnQubWV0YVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaXMgYSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInBhcnNlLXRpbWUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiU3ludGF4RXJyb3JcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiXFxuKFxcXCJDYW5ub3QgdXNlICdpbXBvcnQubWV0YScgb3V0c2lkZSBhIG1vZHVsZVxcXCIpIOKAlCBpdCBmYWlscyBiZWZvcmUgYW55IGNvZGUgcnVucywgc29cXG5hIFwifTxfY29tcG9uZW50cy5jb2RlPntcIj8uXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBydW50aW1lIGd1YXJkIGNhbm5vdCBzYXZlIGl0LiBWaXRlIHJlcGxhY2VzIFwifTxfY29tcG9uZW50cy5jb2RlPntcImltcG9ydC5tZXRhXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhdCBidWlsZCB0aW1lLCBzb1xcbml0IGxvb2tzIGZpbmUgaW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widml0ZSBkZXZcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFuZCBvbmx5IGJyZWFrcyBvbiBpbW1lZGlhdGVseS5ydW4uXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiTWFwcGluZyAodmVyaWZpZWQgMjAyNi0wNiDigJQgY29ycmVjdGx5IGltcGxlbWVudGVkOyBETyBOT1QgcmVpbnRyb2R1Y2VcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJpbXBvcnQubWV0YVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5jb2RlPntcInZpdGUuY29uZmlnLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZGVmaW5lOiB7IF9fV0JfREVWX186IC4uLiB9XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpbmplY3RzIGEgZGV2LW9ubHkgZmxhZy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuY29kZT57XCJzcmMvbGliL2JvYXJkU3RvcmUudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCByZWFkcyBpdCBiZWhpbmQgYSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ0eXBlb2YgX19XQl9ERVZfXyAhPT0gJ3VuZGVmaW5lZCdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxuZ3VhcmQgKGRlY2xhcmVzIFwifTxfY29tcG9uZW50cy5jb2RlPntcIl9fV0JfREVWX186IGJvb2xlYW4gfCB1bmRlZmluZWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKS4gTm8gZmlsZSBpbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB3cml0ZXMgdGhlXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW1wb3J0Lm1ldGFcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHRva2VuIChvbmx5IGNvbW1lbnRzIG1lbnRpb24gaXQpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJ0aGUtdGhyZWUtdGFzay1pbnZva2Utc3VyZmFjZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwidGhlLXRocmVlLXRhc2staW52b2tlLXN1cmZhY2VcIiAvPntcIlRoZSB0aHJlZS10YXNrIGludm9rZSBzdXJmYWNlXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlNwZWM6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5jb2RlPntcIldISVRFQk9BUkRfU1BFQ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKCsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiUElDS19GSUxFX1RBU0tfU1BFQ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLiBjb3JlX2NvbmNlcHRzIMKnNiAoU2VydmljZSlcXG4vIMKnNSAoZGlzcGxheS1pbi1hLXJlZ2lvbiBjYXBhYmlsaXR5KS4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicGFja2FnZS5qc29uXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBkZWNsYXJlc1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcImludm9rZXM6IHBpY2stZmlsZSwgc2hhcmUtc3BhY2UsIGVkaXQtZmlsZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiTWFwcGluZyAodmVyaWZpZWQgMjAyNi0wNik6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJwaWNrLWZpbGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIGZ1bGx5IHdpcmVkOiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvbGliL3BpY2tGaWxlLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjYWxsc1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcImludm9rZVRhc2s8UGlja0ZpbGVSZXN1bHQ+KCdwaWNrLWZpbGUnLCDigKYpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgcmV0dXJucyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJudWxsXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBvbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjYW5jZWxsZWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxuKGNhbGxlcnMgZGVncmFkZSB3aXRoIFwifTxfY29tcG9uZW50cy5jb2RlPntcImlmICghcmVzKSByZXR1cm5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiKS4gVGhpcyBpcyB0aGUgbGl2ZSwgY29tcGxldGUgcGF0aC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcInNoYXJlLXNwYWNlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIC8gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJlZGl0LWZpbGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIGRlY2xhcmVkIGFzIFwifTxfY29tcG9uZW50cy5jb2RlPntcImludm9rZXNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFuZCBzdXJmYWNlZCBhcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInRvYXN0XFxucGxhY2Vob2xkZXJzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHRvZGF5IChcIn08X2NvbXBvbmVudHMuY29kZT57XCJUb3BCYXIudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAvIFwifTxfY29tcG9uZW50cy5jb2RlPntcIk1vYmlsZUNocm9tZS50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGZvciBzaGFyZS1zcGFjZTtcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJJbnNwZWN0b3IudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBmb3IgZWRpdC1maWxlIFxcXCJPcGVuIHNvdXJjZVxcXCIpLiBUaGV5IGRlZ3JhZGUgcmF0aGVyIHRoYW4gY3Jhc2hcXG53aGVuIHRoZSB0YXNrIGlzIGFic2VudCAoY29yZV9jb25jZXB0cyBpbnZhcmlhbnQ6IFxcXCJleHBlY3QgYWJzZW5jZVxcXCIpLiBSZWNvcmRlZCBhc1xcblwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicGFydGlhbCAvIHBsYWNlaG9sZGVyXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBub3QgYSBEb25lLWJ1dC1hYnNlbnQgZ2FwIOKAlCB0aGUgbWFuaWZlc3QgY29ycmVjdGx5XFxuZGVjbGFyZXMgaW50ZW50IGFuZCB0aGUgVUkgaGFuZGxlcyBhYnNlbmNlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaHIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJyZWNvcmRlZC1maW5kaW5ncy1jb2RlLXZlcmlmaWNhdGlvbi1wYXNzLTIwMjYtMDZcIj48SGVhZGluZ0FuY2hvciBpZD1cInJlY29yZGVkLWZpbmRpbmdzLWNvZGUtdmVyaWZpY2F0aW9uLXBhc3MtMjAyNi0wNlwiIC8+e1wiUmVjb3JkZWQgZmluZGluZ3MgKGNvZGUtdmVyaWZpY2F0aW9uIHBhc3MsIDIwMjYtMDYpXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+PF9jb21wb25lbnRzLmRlbD57XCJTREstdmVyc2lvbiBza2V3XCJ9PC9fY29tcG9uZW50cy5kZWw+e1wiIOKAlCBSRVNPTFZFRCAodmVyaWZpZWQgMjAyNi0wOS0yMiwgUjMtNzM3IHJldmlldztcXG5yZS12ZXJpZmllZCAyMDI2LTA5LTI5LCBSMy04MzIpOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB0aGUgMjAyNi0wNiBlbnRyeSByZWNvcmRlZCBhIHBpbiBvZiBcIn08X2NvbXBvbmVudHMuY29kZT57XCIwLjguMVwifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG53aGlsZSBvdGhlcnMgc2F0IGxvd2VyOyB0aGUgcGluIG1vdmVkIHRvIFwifTxfY29tcG9uZW50cy5jb2RlPntcIl4wLjE3LjBcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFuZCBpcyBub3cgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJleGFjdFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcIjAuNzQuMVwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJeMC4xNy4wXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiByYW5nZSBmbG9vci1yZXNvbHZlZCB0byAwLjE3LjAgaW4gdGhlIHNhbmRib3ggYW5kXFxuaXRzIFwifTxfY29tcG9uZW50cy5jb2RlPntcIndhaXRGb3JNb3VudFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgVERaIGJ1ZyBicm9rZSBib2FyZCBwZXJzaXN0ZW5jZSBvbiBwcm9kIChSMy04MzIpLCBzbyB0aGVcXG5cXFwibm8gYWN0aW9uIGluIHRoaXMgcmVwb1xcXCIgdmVyZGljdCBkaWQgbm90IHN1cnZpdmUgY29udGFjdDsgdGhlIHNrZXcgY2xhc3MgaXNcXG5vdGhlcndpc2UgZmxlZXQtbWFpbnRlbmFuY2UgZGVidCB0cmFja2VkIGFjcm9zcyB0aGUgZXhhbXBsZSByZXBvcywgbm90IGhlcmUuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJWb2NhYnVsYXJ5OlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBubyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJrZXJuZWxcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIC8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicHJpbWFyeSBhcHBsaWNhdGlvblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgLyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ0cnVzdCB0aWVyXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjtcXG51c2VzIFxcXCJzdGFnZSBhcHBcXFwiIGNvcnJlY3RseS4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibWFpbi50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNhcnJpZXMgbm8gYXBwIGxvZ2ljL0NTUy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPjxfY29tcG9uZW50cy5jb2RlPntcInJlcXVpcmVMYXRlc3Q6IFxcXCJvcHRpbWlzdGljXFxcIlwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHRoZSBkZWZhdWx0KSDigJQgYXBwcm9wcmlhdGU7IG5vdCBhIGZpbmRpbmcuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz48X2NvbXBvbmVudHMuZGVsPntcIkJVSUxEIFJFRCBvbiBvcmlnaW4vbWFpbiAocHJlLWV4aXN0aW5nLCBTREstc2tldykg4oCUIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNhcERpclwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgbm90IGV4cG9ydGVkLlwifTwvX2NvbXBvbmVudHMuZGVsPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIlxcblwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiUkVTT0xWRUQgKHZlcmlmaWVkIDIwMjYtMDktMjIsIFIzLTczNyByZXZpZXc7IHJlLXZlcmlmaWVkIDIwMjYtMDktMjksIFIzLTgzMik6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiXFxudGhlIHBpbm5lZCBTREsgKG5vdyBleGFjdCBcIn08X2NvbXBvbmVudHMuY29kZT57XCIwLjc0LjFcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSBleHBvcnRzIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNhcERpclwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYW5kIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm5wbSBydW4gYnVpbGRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGlzXFxuZ3JlZW4gb24gdGhpcyBoZWFkIOKAlCB0aGUgcmVjb3JkZWQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiVFMyMzM5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBubyBsb25nZXIgcmVwcm9kdWNlczsgdGhlIGVudHJ5IGlzXFxua2VwdCBzdHJ1Y2sgYXMgdGhlIHJlc29sdXRpb24gcmVjb3JkIHJhdGhlciB0aGFuIGRlbGV0ZWQgKHRoaXMgZmlsZSBpcyBhXFxubGVkZ2VyKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+PC8+O1xufVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTURYQ29udGVudChwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHt3cmFwcGVyOiBNRFhMYXlvdXR9ID0ge1xuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfTtcbiAgcmV0dXJuIE1EWExheW91dCA/IDxNRFhMYXlvdXQgey4uLnByb3BzfT48X2NyZWF0ZU1keENvbnRlbnQgey4uLnByb3BzfSAvPjwvTURYTGF5b3V0PiA6IF9jcmVhdGVNZHhDb250ZW50KHByb3BzKTtcbn1cbmZ1bmN0aW9uIF9taXNzaW5nTWR4UmVmZXJlbmNlKGlkLCBjb21wb25lbnQsIHBsYWNlKSB7XG4gIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIFwiICsgKGNvbXBvbmVudCA/IFwiY29tcG9uZW50XCIgOiBcIm9iamVjdFwiKSArIFwiIGBcIiArIGlkICsgXCJgIHRvIGJlIGRlZmluZWQ6IHlvdSBsaWtlbHkgZm9yZ290IHRvIGltcG9ydCwgcGFzcywgb3IgcHJvdmlkZSBpdC5cIiArIChwbGFjZSA/IFwiXFxuSXTigJlzIHJlZmVyZW5jZWQgaW4geW91ciBjb2RlIGF0IGBcIiArIHBsYWNlICsgXCJgIGluIGAvYXBwL0NPREVfU1BFQ19SRUZFUkVOQ0VTLm1kYFwiIDogXCJcIikpO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFFQSxJQUFBQSxZQUFBLEdBQUFDLE9BQUE7QUFBd0YsSUFBQUMsV0FBQSxHQUFBRCxPQUFBO0FBRnhGO0FBQ0E7O0FBRUEsU0FBU0UsaUJBQWlCQSxDQUFDQyxLQUFLLEVBQUU7RUFDaEMsTUFBTUMsV0FBVyxHQUFHO01BQ2xCQyxJQUFJLEVBQUUsTUFBTTtNQUNaQyxHQUFHLEVBQUUsS0FBSztNQUNWQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxDQUFDLEVBQUUsR0FBRztNQUNOQyxNQUFNLEVBQUUsUUFBUTtNQUNoQkMsRUFBRSxFQUFFLElBQUk7TUFDUixHQUFHLElBQUFDLDZCQUFrQixFQUFDLENBQUM7TUFDdkIsR0FBR1gsS0FBSyxDQUFDWTtJQUNYLENBQUM7SUFBRTtNQUFDQztJQUFhLENBQUMsR0FBR1osV0FBVztFQUNoQyxJQUFJLENBQUNZLGFBQWEsRUFBRUMsb0JBQW9CLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQztFQUMvRCxvQkFBTyxJQUFBaEIsV0FBQSxDQUFBaUIsSUFBQSxFQUFBakIsV0FBQSxDQUFBa0IsUUFBQTtJQUFBQyxRQUFBLGdCQUFFLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ0csRUFBRTtNQUFDYyxFQUFFLEVBQUMsK0JBQStCO01BQUFELFFBQUEsZ0JBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBK0IsQ0FBRSxDQUFDLEVBQUMsaUNBQWlDO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNPLENBQUM7TUFBQVMsUUFBQSxHQUFFLG1CQUFtQixlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNRLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQWEsQ0FBcUIsQ0FBQyxFQUFDLG1GQUFtRixlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLElBQUk7UUFBQWUsUUFBQSxFQUFFO01BQW1CLENBQW1CLENBQUMsRUFBQyxpREFBaUQsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFlLFFBQUEsRUFBRTtNQUFTLENBQW1CLENBQUMsRUFBQyxzQkFBc0IsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFlLFFBQUEsRUFBRTtNQUFTLENBQW1CLENBQUMsRUFBQyxpQkFBaUIsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFlLFFBQUEsRUFBRTtNQUFvQixDQUFtQixDQUFDLEVBQUMsaUVBQWlFLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBZSxRQUFBLEVBQUU7TUFBYSxDQUFtQixDQUFDLEVBQUMsOERBQThEO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNJLEVBQUU7TUFBQ2EsRUFBRSxFQUFDLDJEQUEyRDtNQUFBRCxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQTJELENBQUUsQ0FBQyxFQUFDLE1BQU0sZUFBQyxJQUFBcEIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFlLFFBQUEsRUFBRTtNQUFhLENBQW1CLENBQUMsRUFBQyxTQUFTLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBZSxRQUFBLEVBQUU7TUFBWSxDQUFtQixDQUFDLEVBQUMsa0NBQWtDO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNPLENBQUM7TUFBQVMsUUFBQSxnQkFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDUSxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFrQixDQUFxQixDQUFDLEVBQUMsOEZBQThGLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBZSxRQUFBLEVBQUU7TUFBYSxDQUFtQixDQUFDLEVBQUMsUUFBUSxlQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ1EsTUFBTTtRQUFBUSxRQUFBLEdBQUUsYUFBYSxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLElBQUk7VUFBQWUsUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQztNQUFBLENBQW9CLENBQUMsRUFBQywyRkFBMkYsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFlLFFBQUEsRUFBRTtNQUFJLENBQW1CLENBQUMsRUFBQywrQ0FBK0MsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFlLFFBQUEsRUFBRTtNQUFhLENBQW1CLENBQUMsRUFBQyx1Q0FBdUMsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFlLFFBQUEsRUFBRTtNQUFVLENBQW1CLENBQUMsRUFBQyxzQ0FBc0M7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNPLENBQUM7TUFBQVMsUUFBQSxlQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ1EsTUFBTTtRQUFBUSxRQUFBLEdBQUUseUVBQXlFLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBYSxDQUFtQixDQUFDLEVBQUMsSUFBSTtNQUFBLENBQXFCO0lBQUMsQ0FBZSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ1MsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ00sRUFBRTtRQUFBVSxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLElBQUk7VUFBQWUsUUFBQSxFQUFFO1FBQWdCLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBNkIsQ0FBbUIsQ0FBQyxFQUFDLDJCQUEyQjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDTSxFQUFFO1FBQUFVLFFBQUEsZ0JBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBdUIsQ0FBbUIsQ0FBQyxFQUFDLHVCQUF1QixlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLElBQUk7VUFBQWUsUUFBQSxFQUFFO1FBQW1DLENBQW1CLENBQUMsRUFBQyxvQkFBb0IsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFpQyxDQUFtQixDQUFDLEVBQUMsZ0JBQWdCLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBTSxDQUFtQixDQUFDLEVBQUMsZUFBZSxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLElBQUk7VUFBQWUsUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQyxFQUFDLG9DQUFvQztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNJLEVBQUU7TUFBQ2EsRUFBRSxFQUFDLCtCQUErQjtNQUFBRCxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQStCLENBQUUsQ0FBQyxFQUFDLCtCQUErQjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDTyxDQUFDO01BQUFTLFFBQUEsZ0JBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1EsTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBTyxDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLElBQUk7UUFBQWUsUUFBQSxFQUFFO01BQWlCLENBQW1CLENBQUMsRUFBQyxNQUFNLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBZSxRQUFBLEVBQUU7TUFBcUIsQ0FBbUIsQ0FBQyxFQUFDLHdFQUF3RSxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLElBQUk7UUFBQWUsUUFBQSxFQUFFO01BQWMsQ0FBbUIsQ0FBQyxFQUFDLGFBQWEsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFlLFFBQUEsRUFBRTtNQUE0QyxDQUFtQixDQUFDLEVBQUMsR0FBRztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ08sQ0FBQztNQUFBUyxRQUFBLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1EsTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBNkIsQ0FBcUI7SUFBQyxDQUFlLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDUyxFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDTSxFQUFFO1FBQUFVLFFBQUEsZ0JBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1EsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBVyxDQUFxQixDQUFDLEVBQUMsa0JBQWtCLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBcUIsQ0FBbUIsQ0FBQyxFQUFDLFVBQVUsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUE0QyxDQUFtQixDQUFDLEVBQUMsWUFBWSxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLElBQUk7VUFBQWUsUUFBQSxFQUFFO1FBQU0sQ0FBbUIsQ0FBQyxFQUFDLE1BQU0sZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQywwQkFBMEIsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFrQixDQUFtQixDQUFDLEVBQUMscUNBQXFDO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNNLEVBQUU7UUFBQVUsUUFBQSxnQkFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDUSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFhLENBQXFCLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1EsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBVyxDQUFxQixDQUFDLEVBQUMsaUJBQWlCLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBUyxDQUFtQixDQUFDLEVBQUMsbUJBQW1CLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1EsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBcUIsQ0FBcUIsQ0FBQyxFQUFDLFVBQVUsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFZLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBa0IsQ0FBbUIsQ0FBQyxFQUFDLHFCQUFxQixlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLElBQUk7VUFBQWUsUUFBQSxFQUFFO1FBQWUsQ0FBbUIsQ0FBQyxFQUFDLHVKQUF1SixlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNRLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQXVCLENBQXFCLENBQUMsRUFBQyxtR0FBbUc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0ssRUFBRSxJQUFFLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQVIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNJLEVBQUU7TUFBQ2EsRUFBRSxFQUFDLGtEQUFrRDtNQUFBRCxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQWtELENBQUUsQ0FBQyxFQUFDLHFEQUFxRDtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDUyxFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDTSxFQUFFO1FBQUFVLFFBQUEsZ0JBQUMsSUFBQW5CLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDUSxNQUFNO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0UsR0FBRztZQUFBYyxRQUFBLEVBQUU7VUFBa0IsQ0FBa0IsQ0FBQyxFQUFDLG9GQUFvRjtRQUFBLENBQXFCLENBQUMsRUFBQyx1Q0FBdUMsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFPLENBQW1CLENBQUMsRUFBQyw2Q0FBNkMsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFTLENBQW1CLENBQUMsRUFBQyxjQUFjLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQWlCLElBQUEsRUFBQ2QsV0FBVyxDQUFDUSxNQUFNO1VBQUFRLFFBQUEsR0FBRSxTQUFTLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtZQUFBZSxRQUFBLEVBQUU7VUFBUSxDQUFtQixDQUFDO1FBQUEsQ0FBb0IsQ0FBQyxFQUFDLFNBQVMsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFTLENBQW1CLENBQUMsRUFBQywwREFBMEQsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUMsRUFBQyx3TkFBd047TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ00sRUFBRTtRQUFBVSxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNRLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQWEsQ0FBcUIsQ0FBQyxFQUFDLE1BQU0sZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFRLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBcUIsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFZLENBQW1CLENBQUMsRUFBQyxNQUFNLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBTSxDQUFtQixDQUFDLEVBQUMsbUNBQW1DLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBVSxDQUFtQixDQUFDLEVBQUMsNEJBQTRCO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBbkIsV0FBQSxDQUFBaUIsSUFBQSxFQUFDZCxXQUFXLENBQUNNLEVBQUU7UUFBQVUsUUFBQSxnQkFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDUSxNQUFNO1VBQUFRLFFBQUEsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO1lBQUFlLFFBQUEsRUFBRTtVQUErQixDQUFtQjtRQUFDLENBQW9CLENBQUMsRUFBQyw4Q0FBOEM7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ00sRUFBRTtRQUFBVSxRQUFBLGdCQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNRLE1BQU07VUFBQVEsUUFBQSxlQUFDLElBQUFuQixXQUFBLENBQUFpQixJQUFBLEVBQUNkLFdBQVcsQ0FBQ0UsR0FBRztZQUFBYyxRQUFBLEdBQUUsc0RBQXNELGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBZSxRQUFBLEVBQUU7WUFBUSxDQUFtQixDQUFDLEVBQUMsZ0JBQWdCO1VBQUEsQ0FBa0I7UUFBQyxDQUFvQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNRLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQWdGLENBQXFCLENBQUMsRUFBQyw4QkFBOEIsZUFBQyxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDbEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFRLENBQW1CLENBQUMsRUFBQyxZQUFZLGVBQUMsSUFBQW5CLFdBQUEsQ0FBQXFCLEdBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLElBQUk7VUFBQWUsUUFBQSxFQUFFO1FBQWUsQ0FBbUIsQ0FBQyxFQUFDLHlDQUF5QyxlQUFDLElBQUFuQixXQUFBLENBQUFxQixHQUFBLEVBQUNsQixXQUFXLENBQUNDLElBQUk7VUFBQWUsUUFBQSxFQUFFO1FBQVEsQ0FBbUIsQ0FBQyxFQUFDLHlIQUF5SDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQztFQUFBLENBQUUsQ0FBQztBQUM5NE87QUFDZSxTQUFTRyxVQUFVQSxDQUFDcEIsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFO0VBQzdDLE1BQU07SUFBQ3FCLE9BQU8sRUFBRUM7RUFBUyxDQUFDLEdBQUc7SUFDM0IsR0FBRyxJQUFBWCw2QkFBa0IsRUFBQyxDQUFDO0lBQ3ZCLEdBQUdYLEtBQUssQ0FBQ1k7RUFDWCxDQUFDO0VBQ0QsT0FBT1UsU0FBUyxnQkFBRyxJQUFBeEIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDRyxTQUFTO0lBQUEsR0FBS3RCLEtBQUs7SUFBQWlCLFFBQUEsZUFBRSxJQUFBbkIsV0FBQSxDQUFBcUIsR0FBQSxFQUFDcEIsaUJBQWlCO01BQUEsR0FBS0M7SUFBSyxDQUFHO0VBQUMsQ0FBVyxDQUFDLEdBQUdELGlCQUFpQixDQUFDQyxLQUFLLENBQUM7QUFDbEg7QUFBQ3VCLEVBQUEsR0FOdUJILFVBQVU7QUFPbEMsU0FBU04sb0JBQW9CQSxDQUFDSSxFQUFFLEVBQUVNLFNBQVMsRUFBRUMsS0FBSyxFQUFFO0VBQ2xELE1BQU0sSUFBSUMsS0FBSyxDQUFDLFdBQVcsSUFBSUYsU0FBUyxHQUFHLFdBQVcsR0FBRyxRQUFRLENBQUMsR0FBRyxJQUFJLEdBQUdOLEVBQUUsR0FBRyxvRUFBb0UsSUFBSU8sS0FBSyxHQUFHLHFDQUFxQyxHQUFHQSxLQUFLLEdBQUcscUNBQXFDLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDL1A7QUFBQyxJQUFBRixFQUFBO0FBQUFJLFlBQUEsQ0FBQUosRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}