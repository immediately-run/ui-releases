var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      h3: "h3",
      li: "li",
      p: "p",
      pre: "pre",
      strong: "strong",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "lodestar",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "lodestar"
      }), "Lodestar"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["An infinite-canvas collaborative board where ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "every canvas object is one\nMDX file"
      }), " in a shared space — an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "https://immediately.run",
        children: "immediately.run"
      }), " app.\nSticky notes, prose, images, video, shapes, and live React components live on a\nzoomable/pannable stage; saved camera ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "views"
      }), " chain into guided ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "journeys"
      }), "\nthat are the headline experience for anyone who opens a read-only share link\n(often on a phone). There is no database and no opaque document format: a board\nis a folder you can read, diff, and edit with any tool — including an agent that\nhas never heard of this app."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Specs live in the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "immediately-run/docs"
      }), " repo (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "WHITEBOARD_SPEC.md"
      }), " is the\nanchor); this repo is the app."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "whats-here-today",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "whats-here-today"
      }), "What's here today"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The full canvas experience, built faithfully from the Claude Design asset bundle\nand driven by an in-memory demo board (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/data/seedBoard.ts"
      }), ") that exercises\nevery object kind and degraded state:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Run mode"
        }), " — pan (drag / wheel / pinch), zoom ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "[0.02, 8]"
        }), ", grid/dots/plain\nbackgrounds that track the camera, journeys list + full-screen ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "playback"
        }), "\n(keyboard + tap-zone driven, with a reduced-motion cut)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Edit mode"
        }), " — select / multi-select / marquee, move, resize + rotate handles,\ndrag-to-connect anchors, an inspector (title, tags, note color, geometry,\nz-order, lock/hide), quick-create on double-click, delete with 10s undo."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The built-in component library"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/components/library/"
        }), ") — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "StickyNote"
        }), ",\nprose, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Label"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Frame"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Shape"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Img"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Video"
        }), ", the click-to-load ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Embed"
        }), "\nsecurity surface, and the component-error chip."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Connections"
        }), " — directed arrows / lines with auto edge anchors, midpoint\nlabels, and dangling-edge warnings."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "State screens"
        }), " — board chooser, the four empty/forbidden states, and the\nconcurrent-edit (LWW) + role-downgrade toasts (try the \"Demo states\" menu,\nbottom-left)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Mobile"
        }), " — first-class run mode + playback; edit is select/move/inspector."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "architecture",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "architecture"
      }), "Architecture"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/hooks/useLodestar.ts"
        }), " — the controller: camera, store, and all\npointer/keyboard gestures. The single seam where the persistence and change\nlayers attach."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/lib/"
        }), " — pure helpers: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "camera.ts"
        }), " (projection/zoom math), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "geometry.ts"
        }), "\n(hit-testing, connection anchors), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "types.ts"
        }), " (the document model, shaped to\nthe ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "whiteboard:"
        }), " frontmatter namespace), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ids.ts"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/components/"
        }), " — the canvas (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Canvas"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ObjectFrame"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Connections"
        }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "SelectionOverlay"
        }), ") and chrome (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "TopBar"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Inspector"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "JourneysPanel"
        }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Playback"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "StateScreens"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "MobileChrome"
        }), ", …), wired through context."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "not-yet-wired-separate-gated-platform-deltas",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "not-yet-wired-separate-gated-platform-deltas"
      }), "Not yet wired (separate, gated platform deltas)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Per the spec's dependency table (§11), these depend on capabilities in other\nrepos and are deliberately left as integration seams; the Share / Insert-image /\nOpen-source actions currently surface the task invocation as a toast:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["live space mounts + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "boards.json"
        }), " discovery, MDX-from-mount compilation (the\nV1 gate), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "PollSource"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "WatchSource"
        }), " change intake (D5);"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "pick-file"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "share-space"
        }), ", and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "edit-file"
        }), " task integrations (D1–D3);"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: "anonymous share links end to end (D4)."
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "package.json"
      }), " manifest declares exactly the three tasks the spec's §7\nnames — no capability is added ahead of a spec change."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "open-a-folder-as-a-whiteboard-project-open-project",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "open-a-folder-as-a-whiteboard-project-open-project"
      }), "Open a folder ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "as"
      }), " a whiteboard project (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "open-project"
      }), ")"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Lodestar ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "provides"
      }), " the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "open-project"
      }), " task contract (SPACES_UI_SPEC §6,\nspaces-ui Phase 5). A folder declares that it is a whiteboard project with an\nin-directory marker — the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "immediately.run"
      }), " field of its ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "package.json"
      }), ", or a\nsmall ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "immediately.run.json"
      }), " at the folder root:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-jsonc",
        children: "// immediately.run.json  (a whiteboard project folder)\n{\n  \"opensWith\": { \"task\": \"open-project\", \"version\": \"1.0\" },\n  \"kind\": \"whiteboard-project\"\n}\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["A file manager that finds that marker on a readable folder offers ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "\"Open\nproject.\""
      }), " Choosing it invokes the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "open-project"
      }), " contract, delegating the\nfolder as a directory capability (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "capDir"
      }), ") — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "narrowing a grant the file\nmanager already holds, no new authority, no consent prompt"
      }), " (R-SPACES-9/11). The\nhost resolves the bound provider (Lodestar by default, user-overridable),\nmounts the folder as a task-scoped chroot, and launches the app. On boot the\napp reads ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "useTaskInput()"
      }), ", locates that mount, loads the board from it,\nand calls ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "completeTask({ opened: true })"
      }), ". A normal launch (no task input) is\nunaffected — it opens the user's durable board space as before."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["A runnable demo project folder lives in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "fixtures/sample-project/"
      }), " (the marker\nplus a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "board.md"
      }), " and two object files). The provider logic is in\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/lib/openProject.ts"
      }), ", wired into the controller's boot effect in\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/hooks/useLodestar.ts"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "develop",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "develop"
      }), "Develop"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-bash",
        children: "npm install\nnpm run dev     # vite — eyeball the canvas\nnpm run build   # tsc -b && vite build (must pass)\nnpm run lint    # eslint (must pass — Fast Refresh rule is load-bearing here)\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["See ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "CLAUDE.md"
      }), " for the immediately.run authoring rules this repo follows."]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/README.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiY29kZSIsImVtIiwiaDEiLCJoMiIsImgzIiwibGkiLCJwIiwicHJlIiwic3Ryb25nIiwidWwiLCJfcHJvdmlkZUNvbXBvbmVudHMiLCJjb21wb25lbnRzIiwiSGVhZGluZ0FuY2hvciIsIl9taXNzaW5nTWR4UmVmZXJlbmNlIiwianN4cyIsIkZyYWdtZW50IiwiY2hpbGRyZW4iLCJpZCIsImpzeCIsImhyZWYiLCJjbGFzc05hbWUiLCJNRFhDb250ZW50Iiwid3JhcHBlciIsIk1EWExheW91dCIsIl9jIiwiY29tcG9uZW50IiwicGxhY2UiLCJFcnJvciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlJFQURNRS5tZCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKkBqc3hSdW50aW1lIGF1dG9tYXRpYyovXG4vKkBqc3hJbXBvcnRTb3VyY2UgcmVhY3QqL1xuaW1wb3J0IHt1c2VNRFhDb21wb25lbnRzIGFzIF9wcm92aWRlQ29tcG9uZW50c30gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrL01EWFByb3ZpZGVyXCI7XG5mdW5jdGlvbiBfY3JlYXRlTWR4Q29udGVudChwcm9wcykge1xuICBjb25zdCBfY29tcG9uZW50cyA9IHtcbiAgICBhOiBcImFcIixcbiAgICBjb2RlOiBcImNvZGVcIixcbiAgICBlbTogXCJlbVwiLFxuICAgIGgxOiBcImgxXCIsXG4gICAgaDI6IFwiaDJcIixcbiAgICBoMzogXCJoM1wiLFxuICAgIGxpOiBcImxpXCIsXG4gICAgcDogXCJwXCIsXG4gICAgcHJlOiBcInByZVwiLFxuICAgIHN0cm9uZzogXCJzdHJvbmdcIixcbiAgICB1bDogXCJ1bFwiLFxuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfSwge0hlYWRpbmdBbmNob3J9ID0gX2NvbXBvbmVudHM7XG4gIGlmICghSGVhZGluZ0FuY2hvcikgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJIZWFkaW5nQW5jaG9yXCIsIHRydWUpO1xuICByZXR1cm4gPD48X2NvbXBvbmVudHMuaDEgaWQ9XCJsb2Rlc3RhclwiPjxIZWFkaW5nQW5jaG9yIGlkPVwibG9kZXN0YXJcIiAvPntcIkxvZGVzdGFyXCJ9PC9fY29tcG9uZW50cy5oMT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJBbiBpbmZpbml0ZS1jYW52YXMgY29sbGFib3JhdGl2ZSBib2FyZCB3aGVyZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImV2ZXJ5IGNhbnZhcyBvYmplY3QgaXMgb25lXFxuTURYIGZpbGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgaW4gYSBzaGFyZWQgc3BhY2Ug4oCUIGFuIFwifTxfY29tcG9uZW50cy5hIGhyZWY9XCJodHRwczovL2ltbWVkaWF0ZWx5LnJ1blwiPntcImltbWVkaWF0ZWx5LnJ1blwifTwvX2NvbXBvbmVudHMuYT57XCIgYXBwLlxcblN0aWNreSBub3RlcywgcHJvc2UsIGltYWdlcywgdmlkZW8sIHNoYXBlcywgYW5kIGxpdmUgUmVhY3QgY29tcG9uZW50cyBsaXZlIG9uIGFcXG56b29tYWJsZS9wYW5uYWJsZSBzdGFnZTsgc2F2ZWQgY2FtZXJhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1widmlld3NcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgY2hhaW4gaW50byBndWlkZWQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJqb3VybmV5c1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIlxcbnRoYXQgYXJlIHRoZSBoZWFkbGluZSBleHBlcmllbmNlIGZvciBhbnlvbmUgd2hvIG9wZW5zIGEgcmVhZC1vbmx5IHNoYXJlIGxpbmtcXG4ob2Z0ZW4gb24gYSBwaG9uZSkuIFRoZXJlIGlzIG5vIGRhdGFiYXNlIGFuZCBubyBvcGFxdWUgZG9jdW1lbnQgZm9ybWF0OiBhIGJvYXJkXFxuaXMgYSBmb2xkZXIgeW91IGNhbiByZWFkLCBkaWZmLCBhbmQgZWRpdCB3aXRoIGFueSB0b29sIOKAlCBpbmNsdWRpbmcgYW4gYWdlbnQgdGhhdFxcbmhhcyBuZXZlciBoZWFyZCBvZiB0aGlzIGFwcC5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiU3BlY3MgbGl2ZSBpbiB0aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW1tZWRpYXRlbHktcnVuL2RvY3NcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHJlcG8gKFwifTxfY29tcG9uZW50cy5jb2RlPntcIldISVRFQk9BUkRfU1BFQy5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaXMgdGhlXFxuYW5jaG9yKTsgdGhpcyByZXBvIGlzIHRoZSBhcHAuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cIndoYXRzLWhlcmUtdG9kYXlcIj48SGVhZGluZ0FuY2hvciBpZD1cIndoYXRzLWhlcmUtdG9kYXlcIiAvPntcIldoYXQncyBoZXJlIHRvZGF5XCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgZnVsbCBjYW52YXMgZXhwZXJpZW5jZSwgYnVpbHQgZmFpdGhmdWxseSBmcm9tIHRoZSBDbGF1ZGUgRGVzaWduIGFzc2V0IGJ1bmRsZVxcbmFuZCBkcml2ZW4gYnkgYW4gaW4tbWVtb3J5IGRlbW8gYm9hcmQgKFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9kYXRhL3NlZWRCb2FyZC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpIHRoYXQgZXhlcmNpc2VzXFxuZXZlcnkgb2JqZWN0IGtpbmQgYW5kIGRlZ3JhZGVkIHN0YXRlOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUnVuIG1vZGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHBhbiAoZHJhZyAvIHdoZWVsIC8gcGluY2gpLCB6b29tIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlswLjAyLCA4XVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGdyaWQvZG90cy9wbGFpblxcbmJhY2tncm91bmRzIHRoYXQgdHJhY2sgdGhlIGNhbWVyYSwgam91cm5leXMgbGlzdCArIGZ1bGwtc2NyZWVuIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicGxheWJhY2tcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCJcXG4oa2V5Ym9hcmQgKyB0YXAtem9uZSBkcml2ZW4sIHdpdGggYSByZWR1Y2VkLW1vdGlvbiBjdXQpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRWRpdCBtb2RlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBzZWxlY3QgLyBtdWx0aS1zZWxlY3QgLyBtYXJxdWVlLCBtb3ZlLCByZXNpemUgKyByb3RhdGUgaGFuZGxlcyxcXG5kcmFnLXRvLWNvbm5lY3QgYW5jaG9ycywgYW4gaW5zcGVjdG9yICh0aXRsZSwgdGFncywgbm90ZSBjb2xvciwgZ2VvbWV0cnksXFxuei1vcmRlciwgbG9jay9oaWRlKSwgcXVpY2stY3JlYXRlIG9uIGRvdWJsZS1jbGljaywgZGVsZXRlIHdpdGggMTBzIHVuZG8uXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgYnVpbHQtaW4gY29tcG9uZW50IGxpYnJhcnlcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9jb21wb25lbnRzL2xpYnJhcnkvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikg4oCUIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlN0aWNreU5vdGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLFxcbnByb3NlLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJMYWJlbFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkZyYW1lXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiU2hhcGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJJbWdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJWaWRlb1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIHRoZSBjbGljay10by1sb2FkIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkVtYmVkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIlxcbnNlY3VyaXR5IHN1cmZhY2UsIGFuZCB0aGUgY29tcG9uZW50LWVycm9yIGNoaXAuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJDb25uZWN0aW9uc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgZGlyZWN0ZWQgYXJyb3dzIC8gbGluZXMgd2l0aCBhdXRvIGVkZ2UgYW5jaG9ycywgbWlkcG9pbnRcXG5sYWJlbHMsIGFuZCBkYW5nbGluZy1lZGdlIHdhcm5pbmdzLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiU3RhdGUgc2NyZWVuc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgYm9hcmQgY2hvb3NlciwgdGhlIGZvdXIgZW1wdHkvZm9yYmlkZGVuIHN0YXRlcywgYW5kIHRoZVxcbmNvbmN1cnJlbnQtZWRpdCAoTFdXKSArIHJvbGUtZG93bmdyYWRlIHRvYXN0cyAodHJ5IHRoZSBcXFwiRGVtbyBzdGF0ZXNcXFwiIG1lbnUsXFxuYm90dG9tLWxlZnQpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiTW9iaWxlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBmaXJzdC1jbGFzcyBydW4gbW9kZSArIHBsYXliYWNrOyBlZGl0IGlzIHNlbGVjdC9tb3ZlL2luc3BlY3Rvci5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwiYXJjaGl0ZWN0dXJlXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJhcmNoaXRlY3R1cmVcIiAvPntcIkFyY2hpdGVjdHVyZVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuY29kZT57XCJzcmMvaG9va3MvdXNlTG9kZXN0YXIudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCB0aGUgY29udHJvbGxlcjogY2FtZXJhLCBzdG9yZSwgYW5kIGFsbFxcbnBvaW50ZXIva2V5Ym9hcmQgZ2VzdHVyZXMuIFRoZSBzaW5nbGUgc2VhbSB3aGVyZSB0aGUgcGVyc2lzdGVuY2UgYW5kIGNoYW5nZVxcbmxheWVycyBhdHRhY2guXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2xpYi9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCBwdXJlIGhlbHBlcnM6IFwifTxfY29tcG9uZW50cy5jb2RlPntcImNhbWVyYS50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKHByb2plY3Rpb24vem9vbSBtYXRoKSwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZ2VvbWV0cnkudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxuKGhpdC10ZXN0aW5nLCBjb25uZWN0aW9uIGFuY2hvcnMpLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ0eXBlcy50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKHRoZSBkb2N1bWVudCBtb2RlbCwgc2hhcGVkIHRvXFxudGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcIndoaXRlYm9hcmQ6XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBmcm9udG1hdHRlciBuYW1lc3BhY2UpLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJpZHMudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5jb2RlPntcInNyYy9jb21wb25lbnRzL1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIHRoZSBjYW52YXMgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIkNhbnZhc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIk9iamVjdEZyYW1lXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQ29ubmVjdGlvbnNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcIlNlbGVjdGlvbk92ZXJsYXlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSBhbmQgY2hyb21lIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJUb3BCYXJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJJbnNwZWN0b3JcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJKb3VybmV5c1BhbmVsXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIixcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJQbGF5YmFja1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlN0YXRlU2NyZWVuc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIk1vYmlsZUNocm9tZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIOKApiksIHdpcmVkIHRocm91Z2ggY29udGV4dC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwibm90LXlldC13aXJlZC1zZXBhcmF0ZS1nYXRlZC1wbGF0Zm9ybS1kZWx0YXNcIj48SGVhZGluZ0FuY2hvciBpZD1cIm5vdC15ZXQtd2lyZWQtc2VwYXJhdGUtZ2F0ZWQtcGxhdGZvcm0tZGVsdGFzXCIgLz57XCJOb3QgeWV0IHdpcmVkIChzZXBhcmF0ZSwgZ2F0ZWQgcGxhdGZvcm0gZGVsdGFzKVwifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiUGVyIHRoZSBzcGVjJ3MgZGVwZW5kZW5jeSB0YWJsZSAowqcxMSksIHRoZXNlIGRlcGVuZCBvbiBjYXBhYmlsaXRpZXMgaW4gb3RoZXJcXG5yZXBvcyBhbmQgYXJlIGRlbGliZXJhdGVseSBsZWZ0IGFzIGludGVncmF0aW9uIHNlYW1zOyB0aGUgU2hhcmUgLyBJbnNlcnQtaW1hZ2UgL1xcbk9wZW4tc291cmNlIGFjdGlvbnMgY3VycmVudGx5IHN1cmZhY2UgdGhlIHRhc2sgaW52b2NhdGlvbiBhcyBhIHRvYXN0OlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcImxpdmUgc3BhY2UgbW91bnRzICsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYm9hcmRzLmpzb25cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGRpc2NvdmVyeSwgTURYLWZyb20tbW91bnQgY29tcGlsYXRpb24gKHRoZVxcblYxIGdhdGUpLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJQb2xsU291cmNlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJXYXRjaFNvdXJjZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgY2hhbmdlIGludGFrZSAoRDUpO1wifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcInRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJwaWNrLWZpbGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzaGFyZS1zcGFjZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGFuZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJlZGl0LWZpbGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHRhc2sgaW50ZWdyYXRpb25zIChEMeKAk0QzKTtcIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJhbm9ueW1vdXMgc2hhcmUgbGlua3MgZW5kIHRvIGVuZCAoRDQpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicGFja2FnZS5qc29uXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBtYW5pZmVzdCBkZWNsYXJlcyBleGFjdGx5IHRoZSB0aHJlZSB0YXNrcyB0aGUgc3BlYydzIMKnN1xcbm5hbWVzIOKAlCBubyBjYXBhYmlsaXR5IGlzIGFkZGVkIGFoZWFkIG9mIGEgc3BlYyBjaGFuZ2UuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cIm9wZW4tYS1mb2xkZXItYXMtYS13aGl0ZWJvYXJkLXByb2plY3Qtb3Blbi1wcm9qZWN0XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJvcGVuLWEtZm9sZGVyLWFzLWEtd2hpdGVib2FyZC1wcm9qZWN0LW9wZW4tcHJvamVjdFwiIC8+e1wiT3BlbiBhIGZvbGRlciBcIn08X2NvbXBvbmVudHMuZW0+e1wiYXNcIn08L19jb21wb25lbnRzLmVtPntcIiBhIHdoaXRlYm9hcmQgcHJvamVjdCAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wib3Blbi1wcm9qZWN0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIilcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkxvZGVzdGFyIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicHJvdmlkZXNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm9wZW4tcHJvamVjdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdGFzayBjb250cmFjdCAoU1BBQ0VTX1VJX1NQRUMgwqc2LFxcbnNwYWNlcy11aSBQaGFzZSA1KS4gQSBmb2xkZXIgZGVjbGFyZXMgdGhhdCBpdCBpcyBhIHdoaXRlYm9hcmQgcHJvamVjdCB3aXRoIGFuXFxuaW4tZGlyZWN0b3J5IG1hcmtlciDigJQgdGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcImltbWVkaWF0ZWx5LnJ1blwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZmllbGQgb2YgaXRzIFwifTxfY29tcG9uZW50cy5jb2RlPntcInBhY2thZ2UuanNvblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIG9yIGFcXG5zbWFsbCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJpbW1lZGlhdGVseS5ydW4uanNvblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYXQgdGhlIGZvbGRlciByb290OlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucHJlPjxfY29tcG9uZW50cy5jb2RlIGNsYXNzTmFtZT1cImxhbmd1YWdlLWpzb25jXCI+e1wiLy8gaW1tZWRpYXRlbHkucnVuLmpzb24gIChhIHdoaXRlYm9hcmQgcHJvamVjdCBmb2xkZXIpXFxue1xcbiAgXFxcIm9wZW5zV2l0aFxcXCI6IHsgXFxcInRhc2tcXFwiOiBcXFwib3Blbi1wcm9qZWN0XFxcIiwgXFxcInZlcnNpb25cXFwiOiBcXFwiMS4wXFxcIiB9LFxcbiAgXFxcImtpbmRcXFwiOiBcXFwid2hpdGVib2FyZC1wcm9qZWN0XFxcIlxcbn1cXG5cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5wcmU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiQSBmaWxlIG1hbmFnZXIgdGhhdCBmaW5kcyB0aGF0IG1hcmtlciBvbiBhIHJlYWRhYmxlIGZvbGRlciBvZmZlcnMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJcXFwiT3BlblxcbnByb2plY3QuXFxcIlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBDaG9vc2luZyBpdCBpbnZva2VzIHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJvcGVuLXByb2plY3RcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNvbnRyYWN0LCBkZWxlZ2F0aW5nIHRoZVxcbmZvbGRlciBhcyBhIGRpcmVjdG9yeSBjYXBhYmlsaXR5IChcIn08X2NvbXBvbmVudHMuY29kZT57XCJjYXBEaXJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSDigJQgXCJ9PF9jb21wb25lbnRzLmVtPntcIm5hcnJvd2luZyBhIGdyYW50IHRoZSBmaWxlXFxubWFuYWdlciBhbHJlYWR5IGhvbGRzLCBubyBuZXcgYXV0aG9yaXR5LCBubyBjb25zZW50IHByb21wdFwifTwvX2NvbXBvbmVudHMuZW0+e1wiIChSLVNQQUNFUy05LzExKS4gVGhlXFxuaG9zdCByZXNvbHZlcyB0aGUgYm91bmQgcHJvdmlkZXIgKExvZGVzdGFyIGJ5IGRlZmF1bHQsIHVzZXItb3ZlcnJpZGFibGUpLFxcbm1vdW50cyB0aGUgZm9sZGVyIGFzIGEgdGFzay1zY29wZWQgY2hyb290LCBhbmQgbGF1bmNoZXMgdGhlIGFwcC4gT24gYm9vdCB0aGVcXG5hcHAgcmVhZHMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widXNlVGFza0lucHV0KClcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBsb2NhdGVzIHRoYXQgbW91bnQsIGxvYWRzIHRoZSBib2FyZCBmcm9tIGl0LFxcbmFuZCBjYWxscyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjb21wbGV0ZVRhc2soeyBvcGVuZWQ6IHRydWUgfSlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLiBBIG5vcm1hbCBsYXVuY2ggKG5vIHRhc2sgaW5wdXQpIGlzXFxudW5hZmZlY3RlZCDigJQgaXQgb3BlbnMgdGhlIHVzZXIncyBkdXJhYmxlIGJvYXJkIHNwYWNlIGFzIGJlZm9yZS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiQSBydW5uYWJsZSBkZW1vIHByb2plY3QgZm9sZGVyIGxpdmVzIGluIFwifTxfY29tcG9uZW50cy5jb2RlPntcImZpeHR1cmVzL3NhbXBsZS1wcm9qZWN0L1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKHRoZSBtYXJrZXJcXG5wbHVzIGEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYm9hcmQubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFuZCB0d28gb2JqZWN0IGZpbGVzKS4gVGhlIHByb3ZpZGVyIGxvZ2ljIGlzIGluXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2xpYi9vcGVuUHJvamVjdC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIHdpcmVkIGludG8gdGhlIGNvbnRyb2xsZXIncyBib290IGVmZmVjdCBpblxcblwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9ob29rcy91c2VMb2Rlc3Rhci50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cImRldmVsb3BcIj48SGVhZGluZ0FuY2hvciBpZD1cImRldmVsb3BcIiAvPntcIkRldmVsb3BcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wcmU+PF9jb21wb25lbnRzLmNvZGUgY2xhc3NOYW1lPVwibGFuZ3VhZ2UtYmFzaFwiPntcIm5wbSBpbnN0YWxsXFxubnBtIHJ1biBkZXYgICAgICMgdml0ZSDigJQgZXllYmFsbCB0aGUgY2FudmFzXFxubnBtIHJ1biBidWlsZCAgICMgdHNjIC1iICYmIHZpdGUgYnVpbGQgKG11c3QgcGFzcylcXG5ucG0gcnVuIGxpbnQgICAgIyBlc2xpbnQgKG11c3QgcGFzcyDigJQgRmFzdCBSZWZyZXNoIHJ1bGUgaXMgbG9hZC1iZWFyaW5nIGhlcmUpXFxuXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMucHJlPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlNlZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJDTEFVREUubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGZvciB0aGUgaW1tZWRpYXRlbHkucnVuIGF1dGhvcmluZyBydWxlcyB0aGlzIHJlcG8gZm9sbG93cy5cIn08L19jb21wb25lbnRzLnA+PC8+O1xufVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTURYQ29udGVudChwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHt3cmFwcGVyOiBNRFhMYXlvdXR9ID0ge1xuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfTtcbiAgcmV0dXJuIE1EWExheW91dCA/IDxNRFhMYXlvdXQgey4uLnByb3BzfT48X2NyZWF0ZU1keENvbnRlbnQgey4uLnByb3BzfSAvPjwvTURYTGF5b3V0PiA6IF9jcmVhdGVNZHhDb250ZW50KHByb3BzKTtcbn1cbmZ1bmN0aW9uIF9taXNzaW5nTWR4UmVmZXJlbmNlKGlkLCBjb21wb25lbnQsIHBsYWNlKSB7XG4gIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIFwiICsgKGNvbXBvbmVudCA/IFwiY29tcG9uZW50XCIgOiBcIm9iamVjdFwiKSArIFwiIGBcIiArIGlkICsgXCJgIHRvIGJlIGRlZmluZWQ6IHlvdSBsaWtlbHkgZm9yZ290IHRvIGltcG9ydCwgcGFzcywgb3IgcHJvdmlkZSBpdC5cIiArIChwbGFjZSA/IFwiXFxuSXTigJlzIHJlZmVyZW5jZWQgaW4geW91ciBjb2RlIGF0IGBcIiArIHBsYWNlICsgXCJgIGluIGAvYXBwL1JFQURNRS5tZGBcIiA6IFwiXCIpKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQXdGLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUZ4RjtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU1DLFdBQVcsR0FBRztNQUNsQkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsSUFBSSxFQUFFLE1BQU07TUFDWkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsR0FBRyxFQUFFLEtBQUs7TUFDVkMsTUFBTSxFQUFFLFFBQVE7TUFDaEJDLEVBQUUsRUFBRSxJQUFJO01BQ1IsR0FBRyxJQUFBQyw2QkFBa0IsRUFBQyxDQUFDO01BQ3ZCLEdBQUdiLEtBQUssQ0FBQ2M7SUFDWCxDQUFDO0lBQUU7TUFBQ0M7SUFBYSxDQUFDLEdBQUdkLFdBQVc7RUFDaEMsSUFBSSxDQUFDYyxhQUFhLEVBQUVDLG9CQUFvQixDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUM7RUFDL0Qsb0JBQU8sSUFBQWxCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQW5CLFdBQUEsQ0FBQW9CLFFBQUE7SUFBQUMsUUFBQSxnQkFBRSxJQUFBckIsV0FBQSxDQUFBbUIsSUFBQSxFQUFDaEIsV0FBVyxDQUFDSSxFQUFFO01BQUNlLEVBQUUsRUFBQyxVQUFVO01BQUFELFFBQUEsZ0JBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBVSxDQUFFLENBQUMsRUFBQyxVQUFVO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBbUIsSUFBQSxFQUFDaEIsV0FBVyxDQUFDUSxDQUFDO01BQUFVLFFBQUEsR0FBRSwrQ0FBK0MsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDVSxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFzQyxDQUFxQixDQUFDLEVBQUMsMEJBQTBCLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0MsQ0FBQztRQUFDb0IsSUFBSSxFQUFDLHlCQUF5QjtRQUFBSCxRQUFBLEVBQUU7TUFBaUIsQ0FBZ0IsQ0FBQyxFQUFDLGdJQUFnSSxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNVLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQU8sQ0FBcUIsQ0FBQyxFQUFDLHFCQUFxQixlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNVLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQVUsQ0FBcUIsQ0FBQyxFQUFDLGlSQUFpUjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ1EsQ0FBQztNQUFBVSxRQUFBLEdBQUUsb0JBQW9CLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQXNCLENBQW1CLENBQUMsRUFBQyxTQUFTLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQW9CLENBQW1CLENBQUMsRUFBQyx5Q0FBeUM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNLLEVBQUU7TUFBQ2MsRUFBRSxFQUFDLGtCQUFrQjtNQUFBRCxRQUFBLGdCQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQWtCLENBQUUsQ0FBQyxFQUFDLG1CQUFtQjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ1EsQ0FBQztNQUFBVSxRQUFBLEdBQUUsMkhBQTJILGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQXVCLENBQW1CLENBQUMsRUFBQyx5REFBeUQ7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNXLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBbUIsSUFBQSxFQUFDaEIsV0FBVyxDQUFDTyxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBVSxDQUFxQixDQUFDLEVBQUMsc0NBQXNDLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLG9GQUFvRixlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNVLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQVUsQ0FBcUIsQ0FBQyxFQUFDLDREQUE0RDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBVyxRQUFBLGdCQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNVLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQVcsQ0FBcUIsQ0FBQyxFQUFDLHlOQUF5TjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBVyxRQUFBLGdCQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNVLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQWdDLENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQXlCLENBQW1CLENBQUMsRUFBQyxNQUFNLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVksQ0FBbUIsQ0FBQyxFQUFDLFlBQVksZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBTyxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFPLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQU8sQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBSyxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFPLENBQW1CLENBQUMsRUFBQyxzQkFBc0IsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBTyxDQUFtQixDQUFDLEVBQUMsbURBQW1EO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBbUIsSUFBQSxFQUFDaEIsV0FBVyxDQUFDTyxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBYSxDQUFxQixDQUFDLEVBQUMsa0dBQWtHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBbUIsSUFBQSxFQUFDaEIsV0FBVyxDQUFDTyxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBZSxDQUFxQixDQUFDLEVBQUMseUpBQXlKO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBbUIsSUFBQSxFQUFDaEIsV0FBVyxDQUFDTyxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBUSxDQUFxQixDQUFDLEVBQUMsb0VBQW9FO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNLLEVBQUU7TUFBQ2MsRUFBRSxFQUFDLGNBQWM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFjLENBQUUsQ0FBQyxFQUFDLGNBQWM7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNXLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBbUIsSUFBQSxFQUFDaEIsV0FBVyxDQUFDTyxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQTBCLENBQW1CLENBQUMsRUFBQyx3SUFBd0k7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNPLEVBQUU7UUFBQVcsUUFBQSxnQkFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBVSxDQUFtQixDQUFDLEVBQUMsbUJBQW1CLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLDJCQUEyQixlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyx1Q0FBdUMsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBVSxDQUFtQixDQUFDLEVBQUMsdUNBQXVDLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQyxFQUFDLDJCQUEyQixlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFRLENBQW1CLENBQUMsRUFBQyxHQUFHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBbUIsSUFBQSxFQUFDaEIsV0FBVyxDQUFDTyxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWlCLENBQW1CLENBQUMsRUFBQyxpQkFBaUIsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBa0IsQ0FBbUIsQ0FBQyxFQUFDLGdCQUFnQixlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFRLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBZSxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBYyxDQUFtQixDQUFDLEVBQUMsOEJBQThCO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNNLEVBQUU7TUFBQ2EsRUFBRSxFQUFDLDhDQUE4QztNQUFBRCxRQUFBLGdCQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQThDLENBQUUsQ0FBQyxFQUFDLGlEQUFpRDtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1EsQ0FBQztNQUFBVSxRQUFBLEVBQUU7SUFBdU8sQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBbUIsSUFBQSxFQUFDaEIsV0FBVyxDQUFDVyxFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBVyxRQUFBLEdBQUUsc0JBQXNCLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQyxFQUFDLHlEQUF5RCxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFZLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQyxFQUFDLHNCQUFzQjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBVyxRQUFBLEdBQUUsTUFBTSxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQyxFQUFDLFFBQVEsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsNkJBQTZCO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDTyxFQUFFO1FBQUFXLFFBQUEsRUFBRTtNQUF3QyxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ1EsQ0FBQztNQUFBVSxRQUFBLEdBQUUsTUFBTSxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFjLENBQW1CLENBQUMsRUFBQyxrSEFBa0g7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNLLEVBQUU7TUFBQ2MsRUFBRSxFQUFDLG9EQUFvRDtNQUFBRCxRQUFBLGdCQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQW9ELENBQUUsQ0FBQyxFQUFDLGdCQUFnQixlQUFDLElBQUF0QixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNHLEVBQUU7UUFBQWUsUUFBQSxFQUFFO01BQUksQ0FBaUIsQ0FBQyxFQUFDLHlCQUF5QixlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFjLENBQW1CLENBQUMsRUFBQyxHQUFHO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBbUIsSUFBQSxFQUFDaEIsV0FBVyxDQUFDUSxDQUFDO01BQUFVLFFBQUEsR0FBRSxXQUFXLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1UsTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBVSxDQUFxQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFjLENBQW1CLENBQUMsRUFBQywrSUFBK0ksZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBaUIsQ0FBbUIsQ0FBQyxFQUFDLGdCQUFnQixlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFjLENBQW1CLENBQUMsRUFBQyxnQkFBZ0IsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBc0IsQ0FBbUIsQ0FBQyxFQUFDLHNCQUFzQjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1MsR0FBRztNQUFBUyxRQUFBLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFDb0IsU0FBUyxFQUFDLGdCQUFnQjtRQUFBSixRQUFBLEVBQUU7TUFBNEssQ0FBbUI7SUFBQyxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNRLENBQUM7TUFBQVUsUUFBQSxHQUFFLG9FQUFvRSxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNVLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQW9CLENBQXFCLENBQUMsRUFBQywyQkFBMkIsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBYyxDQUFtQixDQUFDLEVBQUMsK0RBQStELGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQVEsQ0FBbUIsQ0FBQyxFQUFDLE1BQU0sZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRyxFQUFFO1FBQUFlLFFBQUEsRUFBRTtNQUF3RixDQUFpQixDQUFDLEVBQUMsNExBQTRMLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQWdCLENBQW1CLENBQUMsRUFBQyw0REFBNEQsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBZ0MsQ0FBbUIsQ0FBQyxFQUFDLHVHQUF1RztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ1EsQ0FBQztNQUFBVSxRQUFBLEdBQUUsMENBQTBDLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQTBCLENBQW1CLENBQUMsRUFBQyx1QkFBdUIsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBVSxDQUFtQixDQUFDLEVBQUMsb0RBQW9ELGVBQUMsSUFBQXJCLFdBQUEsQ0FBQXVCLEdBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQXdCLENBQW1CLENBQUMsRUFBQyxnREFBZ0QsZUFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDcEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBMEIsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFtQixJQUFBLEVBQUNoQixXQUFXLENBQUNLLEVBQUU7TUFBQ2MsRUFBRSxFQUFDLFNBQVM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBckIsV0FBQSxDQUFBdUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFTLENBQUUsQ0FBQyxFQUFDLFNBQVM7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNTLEdBQUc7TUFBQVMsUUFBQSxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7UUFBQ29CLFNBQVMsRUFBQyxlQUFlO1FBQUFKLFFBQUEsRUFBRTtNQUErTCxDQUFtQjtJQUFDLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQW1CLElBQUEsRUFBQ2hCLFdBQVcsQ0FBQ1EsQ0FBQztNQUFBVSxRQUFBLEdBQUUsTUFBTSxlQUFDLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUNwQixXQUFXLENBQUNFLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFXLENBQW1CLENBQUMsRUFBQyw2REFBNkQ7SUFBQSxDQUFnQixDQUFDO0VBQUEsQ0FBRSxDQUFDO0FBQ242UztBQUNlLFNBQVNLLFVBQVVBLENBQUN4QixLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUU7RUFDN0MsTUFBTTtJQUFDeUIsT0FBTyxFQUFFQztFQUFTLENBQUMsR0FBRztJQUMzQixHQUFHLElBQUFiLDZCQUFrQixFQUFDLENBQUM7SUFDdkIsR0FBR2IsS0FBSyxDQUFDYztFQUNYLENBQUM7RUFDRCxPQUFPWSxTQUFTLGdCQUFHLElBQUE1QixXQUFBLENBQUF1QixHQUFBLEVBQUNLLFNBQVM7SUFBQSxHQUFLMUIsS0FBSztJQUFBbUIsUUFBQSxlQUFFLElBQUFyQixXQUFBLENBQUF1QixHQUFBLEVBQUN0QixpQkFBaUI7TUFBQSxHQUFLQztJQUFLLENBQUc7RUFBQyxDQUFXLENBQUMsR0FBR0QsaUJBQWlCLENBQUNDLEtBQUssQ0FBQztBQUNsSDtBQUFDMkIsRUFBQSxHQU51QkgsVUFBVTtBQU9sQyxTQUFTUixvQkFBb0JBLENBQUNJLEVBQUUsRUFBRVEsU0FBUyxFQUFFQyxLQUFLLEVBQUU7RUFDbEQsTUFBTSxJQUFJQyxLQUFLLENBQUMsV0FBVyxJQUFJRixTQUFTLEdBQUcsV0FBVyxHQUFHLFFBQVEsQ0FBQyxHQUFHLElBQUksR0FBR1IsRUFBRSxHQUFHLG9FQUFvRSxJQUFJUyxLQUFLLEdBQUcscUNBQXFDLEdBQUdBLEtBQUssR0FBRyx1QkFBdUIsR0FBRyxFQUFFLENBQUMsQ0FBQztBQUNqUDtBQUFDLElBQUFGLEVBQUE7QUFBQUksWUFBQSxDQUFBSixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}