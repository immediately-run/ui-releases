var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      code: "code",
      del: "del",
      em: "em",
      h1: "h1",
      h2: "h2",
      h3: "h3",
      li: "li",
      p: "p",
      pre: "pre",
      strong: "strong",
      table: "table",
      tbody: "tbody",
      td: "td",
      th: "th",
      thead: "thead",
      tr: "tr",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "document_navigator-implementation-status",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "document_navigator-implementation-status"
      }), "DOCUMENT_NAVIGATOR — implementation status"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Status:"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Part A implemented (R3-446); Part B's contract established + build landed (R3-447), live gates green on the rw dispatch shape (2026-10-01)"
      }), " ·\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Updated:"
      }), " 2026-10-01"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["This document is the single implementation-status source for\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "docs/specs/DOCUMENT_NAVIGATOR_SPEC.md"
      }), "; where they disagree, this document governs."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "part-a-the-authoring-vocabulary-shipped-2026-08-28",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "part-a-the-authoring-vocabulary-shipped-2026-08-28"
      }), "Part A — the authoring vocabulary (shipped 2026-08-28)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/app/vocabulary.ts"
        }), " — the pure derivation: every catalog entry with its typed\nattributes (base + per-variant, variant-labelled) and a usage snippet built per the\nspec's §1.1 per-shape rules (variant discriminators, child rules, the Show*\nthresholds, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "literal-array"
        }), " placeholders)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/app/VocabularySection.tsx"
        }), " — the panel section: collapsible per entry, a\nwidgets/display/all filter, and a guarded copy affordance."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["Wired into ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/app/WorkbookPanel.tsx"
        }), "; the report header button is now\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Workbook"
        }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Close workbook"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/App.tsx"
        }), ")."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "gate-coverage",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "gate-coverage"
      }), "Gate coverage"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Gate"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Test"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-A1"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/app/vocabulary.test.ts"
            }), " — enumerates ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "componentNames"
            }), ", never a literal list"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-A2"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["same — widget/container markers; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "Chart"
            }), "'s discriminator and its per-variant ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "x"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "y"
            }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "histogram.value"
            })]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-A3"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["same — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "every"
            }), " snippet parsed by the real ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "parseTemplate"
            }), " and run through the real ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "validateTemplate"
            }), ", asserting zero error diagnostics, one test per catalog entry (19 of them) so a future entry cannot regress silently"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-A4"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["same — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "widgets"
            }), " = ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "WIDGETS"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "components"
            }), " = its exact complement, unset = all"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-A5"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/app/VocabularySection.test.tsx"
            }), " — static render with no host transport"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-A6"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["the header strings in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/App.tsx"
            })]
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "All 19 snippets validate on the first implementation"
      }), " — the spec's §1.1 per-shape\nrules were sufficient, including the seven entries the adversarial pass identified as\nimpossible under the draft's attribute-only recipe (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "Chart"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "Map"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "Facets"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "Params"
      }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ShowAbove"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ShowBelow"
      }), ", and the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "literal-array"
      }), " carriers)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "also-landed-with-part-a",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "also-landed-with-part-a"
      }), "Also landed with Part A"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "A platform guard against the DN-R5 hazard"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/app/platformGuards.test.ts"
        }), "): no\nmodule may ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "statically value-import"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "@immediately-run/sdk"
        }), " or ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "…/tasks"
        }), ", which\nregister a host listener at module load and throw with no transport. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "import type"
        }), ",\nthe ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "mounts"
        }), " subpath and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "await import()"
        }), " are all correctly not matched — proven by\nfault injection over five cases, not by inspection. This guard exists ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "before"
        }), " Part B\nneeds it, so the mistake cannot be made later."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["A lint-red ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "main"
          }), " fixed"]
        }), " — R3-427 shipped an unused-binding error because the\nverification command piped ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npm run lint"
        }), " into ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "tail"
        }), ", and a pipeline's exit status is\nthe ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "last"
        }), " command's, so the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "&&"
        }), " chain continued past a failing gate. Fixed here, and\nthe lesson is worth keeping: ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["never pipe a gate into ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "tail"
          }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "head"
          }), " in a chained\nverification"]
        }), " — capture to a file and check the exit code."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "part-b-the-edit-affordance-r3-447-the-contract-established-the-build-landed",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "part-b-the-edit-affordance-r3-447-the-contract-established-the-build-landed"
      }), "Part B — the edit affordance (R3-447: the contract established, the build landed)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Phase 1 — the preconditions, established 2026-09-22"
      }), " (the worker-VM agent venue:\ncurrent-main dev host + staging backend/Firestore, the real repo-load dispatch, a\nworkbook corpus repo dispatched by URL; browser-driven observation off the live\nchannel, per the spec's rule — an injected port cannot falsify a question about the\nhost):"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "#"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Answer (with how it was established)"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "P1"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["A ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "type: 'content'"
            }), " dispatch mount carries ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "id"
            }), " in the ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
              children: ["universal ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                children: "scheme:locator"
              }), " form"]
            }), " — observed live as ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "content:immediately-run-worker/r3-447-workbook"
            }), " (the frame's own mount service, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "getMounts()"
            }), "). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "capFile"
            }), "'s ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "mountId"
            }), " is therefore addressed with the descriptor's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "id"
            }), " verbatim; the host's grant lookup is an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "exact match"
            }), " on it (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "taskInvocation.ts"
            }), " → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "grantFor"
            }), "), and no fallback is documented — a path-shaped or bare ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "mountId"
            }), " would refuse ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "forbidden"
            }), ", which is why the door fails closed on an id-less mount rather than making a doomed call. The unqualified form is not what the host mints."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "P2"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["The mount ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
              children: ["reports ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                children: "mode"
              })]
            }), " — observed live as ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "'rw'"
            }), " on the repo-load dispatch (writes land in the corpus mount; proposing back to the source repo stays unwired, the RCD §5.1 disclosure) — and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                children: "rules: null"
              })
            }), " (no rules). The editability derivation therefore keys on the ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
              children: ["positive ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                children: "rw"
              }), " check"]
            }), " R-EFE-1 prescribes; the draft's \"absent ⇒ writable\" inversion (DN-R2) is dead, and the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "subtree"
            }), "-comparability question (DN-R3) dissolves — there are no rules to compare. This repo's dispatch fixtures stamp ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "mode: 'ro'"
            }), "; the live repo-load mount stamps ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "rw"
            }), " — the fixtures model the task-invocation shape, not this one."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "P3"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Both channels are real and shaped as §4.2 handles them."
            }), " Documented half (the host's task contract, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "taskContracts.ts"
            }), "): ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "edit-file"
            }), " returns ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "{ saved: boolean }"
            }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "saved: false"
            }), " is the result-carried refusal, and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "invokeTask"
            }), " throws machine ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: ".code"
            }), " rejections (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "cancelled"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "forbidden"
            }), ", …). Live half (a real invocation from the dispatched frame): exercised by the gates below — it required P4's grant first, which is the sequencing finding, not a gap."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "P4"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "NO — and deliberately so."
            }), " The build-default binding (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "site-main"
            }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "registry/defaults.ts"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "task.open-workbook"
            }), ") omitted ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "task:invoke"
            }), " with a comment naming this milestone as the moment to add it; the frame's live grant-filtered catalog carried no task verb. The grant half is site-main's R3-447 registry diff (this milestone); the manifest ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "invokes"
            }), " declaration (this repo) is the self-restriction half — G-DN-B10 asserts both."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "P5"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "The dispatched shape is reachable and renders."
            }), " Driven live: a workbook corpus repo (the Meridian seed as real files + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "immediately.run.json"
            }), " marker ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "opensWith: open-workbook@1.0"
            }), ") dispatched by URL through the real repo-load branch — stock reckoner from the registry binding rendered the report (nav, growth-composition sections, the workbook panel). The honest sequencing notes: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "no workbook corpus repo existed"
            }), " (the corpus is content work, not platform work — the spike's corpus is temporary), and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "no user-facing caller invokes the task"
            }), " (the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "opensWith"
            }), " marker's only reader is the URL route; the folder-trigger caller is R3-267) — the URL route is the reachable shape."]
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Phase 2 — built"
      }), " (the same item): the inspector's per-row edit door (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ValueInspector"
      }), "),\nthe §4.3 path gate (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "documentPaths"
      }), "), the door itself (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "useEditFile"
      }), " — lazy import, both\nrefusal channels, the session-scoped latch, the host-less no-op, the §4.4 staleness\nsignal), the staleness notice + reload (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "DocumentChangedNotice"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "useReport.reload"
      }), "),\nthe ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "invokes"
      }), " declaration, and site-main's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "task:invoke"
      }), " grant. Q6 (the consumer\ninspector's door) resolves per the item's own Phase-2 surface (\"the inspector's formula\nand test rows\"); Q3 (reload vs change-watch) resolves to the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "reload affordance"
      }), " — a\nchange-watch needs an fs watch the task-delegated export does not carry\n(SPACES_UI §6.6 / R3-732's seam)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "gate-coverage-1",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "gate-coverage-1"
      }), "Gate coverage"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Gate"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Test"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-B1"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "dispatch.test.ts"
            }), " — the ok resolution carries the live mount (id/mode provenance); the live descriptor read on the venue (above)"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-B2"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "useEditFile.test.ts"
            }), " — writability by the positive ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "rw"
            }), " check (ro/absent are not doors)"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-B3"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "documentPaths.test.ts"
            }), " — segment-boundary traversal refusal; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "useEditFile.test.ts"
            }), " — a failing path never constructs the delegation"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-B4"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "useEditFile.test.ts"
            }), " — the call addresses the descriptor id (universal form); an id-less mount is not a door (fail-closed — the host's exact-match grant lookup has no documented fallback); the live invocation gate below"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-B5"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "useEditFile.test.ts"
            }), " — both channels: thrown ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "cancelled"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "forbidden"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "timeout"
            }), ", the result-carried ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "{saved:false}"
            }), " refusal, the host-less no-op; the live gate below"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-B6"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "ValueInspector.test.tsx"
            }), " — absent unless writable (per row), present beside both anchors, the disclosure at the button, the click hands the row's path; the live gate below"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-B7"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "documentPaths.test.ts"
            }), " — traversal-shaped ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "manifest.worksheets"
            }), " paths never reach ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "capFile"
            })]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-B8"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["the pre-existing ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "platformGuards.test.ts"
            }), " (no static tasks import) + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "useEditFile.test.ts"
            }), "'s host-less no-op case"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-B9"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "DocumentChangedNotice.test.tsx"
            }), " + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "useReport.test.tsx"
            }), " (the reload); the live gate below"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-B10"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "package.json"
            }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "invokes"
            }), " (this repo) + site-main's registry diff and its exact-list test"]
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["The host-exercised halves (P1–P4's live legs: a real ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "edit-file"
        }), " invocation from the\ndispatched frame — the door visible on the dispatched shape, the overlay opening, both\nrefusal channels observed on the real gate, the staleness affordance after a save) run\non the venue against the merged mains before R3-447 archives; the unit halves above are\nin-repo and green."]
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "open-residuals",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "open-residuals"
      }), "Open residuals"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "edit-table"
        }), " is now specified"]
      }), " (2026-08-29) — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "EDIT_TABLE_TASK_SPEC.mdx"
      }), " in the docs\nrepo, proposal rev 2 after an adversarial pass. It is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "blocked on P1–P5 above plus two\nof its own"
      }), " (", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.del, {
        children: ["P6: task-delegation mounts are announced with no ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "mode"
        })]
      }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["closed\n2026-09-29 by the R3-754 probe below: the delegation mount announces ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "mode: 'ro'"
        })]
      }), "\n(the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "min(caller grant, cap, contract)"
      }), " stamp, site-main ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "mintDelegations.ts"
      }), "), so the\nread-only rule IS implementable; P7: Reckoner has no fs watch, so the autosave safety argument\nhas no consumer). R3-447's host spike therefore unblocks both surfaces, not just\nPart B — worth knowing before scoping it. The 2026-08-29 review also confirmed the\nseed-vs-mount wall applies to fixtures exactly as it does to worksheets: on the\nbundled-seed path there is no file to delegate, only a string in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/seed/"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Spec §6 (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "edit-table"
      }), ", open-at-line, Delta B, click-to-insert, own-source editing) and\n§11 Q1–Q7 — including the two the review surfaced as real decisions rather than\ndeferrals: whether the consumer-visible inspector carries an authoring door (Q6), and\nthe template-file edit row without which \"copy the snippet, open the template\" has no\ndoor (Q7)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "the-second-dispatch-shapes-descriptor-r3-754-probed-live-2026-09-29",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-second-dispatch-shapes-descriptor-r3-754-probed-live-2026-09-29"
      }), "The second dispatch shape's descriptor (R3-754, probed live 2026-09-29)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Probed on the venue (staging composition, driven Chromium, the venue identity signed\nin): the corpus open in the editor, file-explorer's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "opensWith"
      }), " affordance on the\ncorpus root (\"Open as workbook\"), the task overlay running reckoner. The frame's own\nmount set, read from the callee:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-json",
        children: "{ \"id\": \"/task/task-1/dir\", \"path\": \"/task/task-1/dir\",\n  \"type\": \"task-delegation\", \"mode\": \"ro\", \"rules\": null }\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["with the task input ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "{ task: 'open-workbook', params: { dir: '/task/task-1/dir' } }"
      }), " —\nthe host REWRITES the caller's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "dir"
      }), " to the minted chroot path, and the mount's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "id"
      }), "\nis that same path (NOT the universal ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "scheme:locator"
      }), " form P1 established for\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "type: 'content'"
      }), " mounts — the two shapes address differently, and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "dispatch.ts"
      }), "'s\ntask branch addresses the delegation by the path-form id it arrives with)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The mode is ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ro"
        }), " even when the caller's session holds the corpus read-write"]
      }), " (the\nedit session's worktree): ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "panel.files"
      }), "'s published port of the worktree is itself\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ro"
      }), ", so ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "min(…)"
      }), " clamps to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ro"
      }), " regardless of the session's writability. The edit\ndoor therefore stays dark on every dispatch-driven open — by design, pending R3-797 —\nand the URL/task dispatch shapes are recorded ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "view-only"
      }), " (the owner's 2026-09-28\ndecision (c) on R3-754)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "the-live-gates-2026-09-22-the-venue-run-against-both-merged-mains-two-pass-one-is-a-finding",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-live-gates-2026-09-22-the-venue-run-against-both-merged-mains-two-pass-one-is-a-finding"
      }), "The live gates (2026-09-22, the venue run against BOTH merged mains) — two pass, one is a FINDING"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Driven on the worker-VM venue with site-main at 60ddd0a and reckoner@main at 2925fa4\n(both PRs merged), the corpus dispatched by URL:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "G-DN-B6 live: PASS."
        }), " The door renders beside both ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "file:line"
        }), " anchors\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "worksheets/review.sheet.js:3"
        }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ":107"
        }), ") on the dispatched shape, with the RCD\n§5.1 disclosure on the button title AND the visible note line."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "G-DN-B5 live (the forbidden channel): PASS."
        }), " A refused invocation draws exactly\none plain message (\"This document can't be edited here.\") and latches the door off —\nobserved live, matching §4.2 to the letter."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "G-DN-B4 live (the successful invocation): BLOCKED BY A FINDING, not a bug in this\nrepo's half."
        }), " The invocation refuses ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "forbidden — 'protocol-task.invoke' requires the 'task:invoke' capability; this app's grant does not hold it"
        }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "despite\nsite-main#584 being merged and the venue serving it"
        }), ". Root cause (code + live):\nthe URL repo-load dispatch resolves the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "viewer's repo"
        }), " from the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "task.open-workbook"
        }), "\nbinding, but the frame's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "grant"
        }), " is the preview/stage grant — the registry row's\ncapabilities never flow to the repo-load-dispatched frame. The task-invocation shape\n(where the binding's grant does apply) is unreachable twice over: no user-facing\ncaller exists (R3-267), and this repo's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "dispatch.ts"
        }), " v1 deliberately resolves only\nthe repo-load shape. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The affordance is therefore unreachable on both dispatch\nshapes — DN-R12's failure mode reborn at the invocation layer."
        }), " The fix is a\ndesign decision the owner owns (the repo-load dispatch minting the viewer's grant\nfrom the task binding; or the preview grant widening; or shipping the task-shape\ncaller); recorded in R3-447's roadmap status, which stays ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "in-progress, unarchived"
        }), "."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "the-live-gates-on-the-rw-dispatch-shape-2026-10-01-the-venue-r3-797s-grant-edit-file10-the-remaining-halves-pass",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-live-gates-on-the-rw-dispatch-shape-2026-10-01-the-venue-r3-797s-grant-edit-file10-the-remaining-halves-pass"
      }), "The live gates on the rw dispatch shape (2026-10-01, the venue; R3-797's grant + edit-file#10) — the remaining halves PASS"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Driven on the worker-VM venue (staging composition; site-main main 096ce08; STOCK\nreckoner; corpus ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "immediately-run-worker/r3-447-workbook"
      }), " URL-dispatched, the corpus\npublishing ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "rw"
      }), " since R3-797), with the empty-read blocker root-caused and fixed\nfirst:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The 2026-09-22 B4 finding is resolved in two layers."
        }), " The grant layer was fixed by\nR3-754 (grant flows to the dispatched frame) and R3-797 (the corpus publishes ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "rw"
        }), "\nunder dispatch). The layer those legs exposed — the edit-file overlay rendering\n\"New or unreadable file — starting empty\" on a healthy delegation — was ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "app-side,\nnot host-side"
        }), ": the edit-file app's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/fs.ts"
        }), " read\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "module.evaluation.module.bundler.fs"
        }), ", the object the SDK's fs module names as the\ndocumented WRONG one (no ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "promises"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "stat"
        }), "). Every read threw before any RPC left\nthe frame (proven by a host-side op trace: zero ops after the edit click), and the\ncallee's catch rendered the empty state. The same chroot path read through the\nsupported surface (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "__sandpackSharedFs"
        }), ") returned the file's bytes. Fixed in\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "edit-file#10"
        }), " (delegate to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "@immediately-run/sdk/fs"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "sandboxFs()"
        }), "; SDK pinned\n0.75.0 — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "^0.13.0"
        }), " predates the SDK's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "/fs"
        }), " subpath, so the bump was forced)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "G-DN-B4 live (read + save + value provenance): PASS."
        }), " The edit chip on\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "review.total"
        }), "'s inspector opens the overlay, which now READS\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "worksheets/review.sheet.js"
        }), " (real bytes). A probe edit (the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "total"
        }), " formula ×2)\nsaved through the delegation — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "completeTask({saved:true})"
        }), ", overlay closed — and a\nre-opened editor showed the SAVED bytes. After reload the report rendered the\ndoubled figure (409,994 → 819,988): the save landed in the corpus mount and the\nreport's re-read sees it. The original bytes were saved back and the report\nre-verified at 409,994 (the venue drive is byte-net-zero; the corpus repo itself\nnever receives the write — the CoW overlay is the save target, RCD §5.1 as\ndisclosed)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "G-DN-B5 live (the cancel channel, on the rw shape): PASS."
        }), " Dismissing the editor\n(Cancel) is silent — no notice — and does NOT latch the door (the chips stay\nrendered, matching the §4.2 latch's mount-state keying). The forbidden channel\npassed live 2026-09-22 (above) and is unchanged by the rw shape."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "G-DN-B9 live (staleness + reload): PASS."
        }), " The save flipped the §4.4 signal: the\nnotice rendered (\"The mounted document changed after this report was rendered — the\nfigures below are stale.\") with the Reload affordance, and Reload re-read the\ndocument through the same mount resolution (the doubled value rendered)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "G-DN-B6 live on the rw shape: PASS (re-run)."
        }), " Both ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "edit"
        }), " chips render beside the\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "file:line"
        }), " anchors with the RCD §5.1 disclosure on the title AND the note line."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Every Part B gate is now covered: the gates whose evidence is host questions\n(P1–P4, established live 2026-09-22) back B1–B4, B6 and B10; B4/B5/B6/B9 have the\nlive venue legs recorded here and on 2026-09-22; B1–B3, B7, B8 and B10 carry their\nunit halves per the table above. B5's three named elements beyond the thrown\nchannels: the result-carried ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "{saved:false}"
      }), " refusal is live-unexercised (no\nshipped callee path produces it — cancel throws ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "cancelled"
      }), ", an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ro"
      }), " mount never\nrenders the door) but unit-asserted directly on its own §4.2 branch\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "useEditFile.test.tsx"
      }), ", the REFUSED_MESSAGE + mount-state latch case);\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "no-such-task"
      }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "timeout"
      }), " were never observed live and ride the §4.2 generic\nname-the-code branch, proxied unit-side by the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "timeout"
      }), " case\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "useEditFile.test.tsx"
      }), ")."]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/status/DOCUMENT_NAVIGATOR_STATUS.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJjb2RlIiwiZGVsIiwiZW0iLCJoMSIsImgyIiwiaDMiLCJsaSIsInAiLCJwcmUiLCJzdHJvbmciLCJ0YWJsZSIsInRib2R5IiwidGQiLCJ0aCIsInRoZWFkIiwidHIiLCJ1bCIsIl9wcm92aWRlQ29tcG9uZW50cyIsImNvbXBvbmVudHMiLCJIZWFkaW5nQW5jaG9yIiwiX21pc3NpbmdNZHhSZWZlcmVuY2UiLCJqc3hzIiwiRnJhZ21lbnQiLCJjaGlsZHJlbiIsImlkIiwianN4IiwiY2xhc3NOYW1lIiwiTURYQ29udGVudCIsIndyYXBwZXIiLCJNRFhMYXlvdXQiLCJfYyIsImNvbXBvbmVudCIsInBsYWNlIiwiRXJyb3IiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJET0NVTUVOVF9OQVZJR0FUT1JfU1RBVFVTLm1kIl0sInNvdXJjZXNDb250ZW50IjpbIi8qQGpzeFJ1bnRpbWUgYXV0b21hdGljKi9cbi8qQGpzeEltcG9ydFNvdXJjZSByZWFjdCovXG5pbXBvcnQge3VzZU1EWENvbXBvbmVudHMgYXMgX3Byb3ZpZGVDb21wb25lbnRzfSBmcm9tIFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGsvTURYUHJvdmlkZXJcIjtcbmZ1bmN0aW9uIF9jcmVhdGVNZHhDb250ZW50KHByb3BzKSB7XG4gIGNvbnN0IF9jb21wb25lbnRzID0ge1xuICAgIGNvZGU6IFwiY29kZVwiLFxuICAgIGRlbDogXCJkZWxcIixcbiAgICBlbTogXCJlbVwiLFxuICAgIGgxOiBcImgxXCIsXG4gICAgaDI6IFwiaDJcIixcbiAgICBoMzogXCJoM1wiLFxuICAgIGxpOiBcImxpXCIsXG4gICAgcDogXCJwXCIsXG4gICAgcHJlOiBcInByZVwiLFxuICAgIHN0cm9uZzogXCJzdHJvbmdcIixcbiAgICB0YWJsZTogXCJ0YWJsZVwiLFxuICAgIHRib2R5OiBcInRib2R5XCIsXG4gICAgdGQ6IFwidGRcIixcbiAgICB0aDogXCJ0aFwiLFxuICAgIHRoZWFkOiBcInRoZWFkXCIsXG4gICAgdHI6IFwidHJcIixcbiAgICB1bDogXCJ1bFwiLFxuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfSwge0hlYWRpbmdBbmNob3J9ID0gX2NvbXBvbmVudHM7XG4gIGlmICghSGVhZGluZ0FuY2hvcikgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJIZWFkaW5nQW5jaG9yXCIsIHRydWUpO1xuICByZXR1cm4gPD48X2NvbXBvbmVudHMuaDEgaWQ9XCJkb2N1bWVudF9uYXZpZ2F0b3ItaW1wbGVtZW50YXRpb24tc3RhdHVzXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJkb2N1bWVudF9uYXZpZ2F0b3ItaW1wbGVtZW50YXRpb24tc3RhdHVzXCIgLz57XCJET0NVTUVOVF9OQVZJR0FUT1Ig4oCUIGltcGxlbWVudGF0aW9uIHN0YXR1c1wifTwvX2NvbXBvbmVudHMuaDE+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJTdGF0dXM6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiUGFydCBBIGltcGxlbWVudGVkIChSMy00NDYpOyBQYXJ0IEIncyBjb250cmFjdCBlc3RhYmxpc2hlZCArIGJ1aWxkIGxhbmRlZCAoUjMtNDQ3KSwgbGl2ZSBnYXRlcyBncmVlbiBvbiB0aGUgcncgZGlzcGF0Y2ggc2hhcGUgKDIwMjYtMTAtMDEpXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIMK3XFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJVcGRhdGVkOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAyMDI2LTEwLTAxXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoaXMgZG9jdW1lbnQgaXMgdGhlIHNpbmdsZSBpbXBsZW1lbnRhdGlvbi1zdGF0dXMgc291cmNlIGZvclxcblwifTxfY29tcG9uZW50cy5jb2RlPntcImRvY3Mvc3BlY3MvRE9DVU1FTlRfTkFWSUdBVE9SX1NQRUMubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiOyB3aGVyZSB0aGV5IGRpc2FncmVlLCB0aGlzIGRvY3VtZW50IGdvdmVybnMuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInBhcnQtYS10aGUtYXV0aG9yaW5nLXZvY2FidWxhcnktc2hpcHBlZC0yMDI2LTA4LTI4XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJwYXJ0LWEtdGhlLWF1dGhvcmluZy12b2NhYnVsYXJ5LXNoaXBwZWQtMjAyNi0wOC0yOFwiIC8+e1wiUGFydCBBIOKAlCB0aGUgYXV0aG9yaW5nIHZvY2FidWxhcnkgKHNoaXBwZWQgMjAyNi0wOC0yOClcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2FwcC92b2NhYnVsYXJ5LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgdGhlIHB1cmUgZGVyaXZhdGlvbjogZXZlcnkgY2F0YWxvZyBlbnRyeSB3aXRoIGl0cyB0eXBlZFxcbmF0dHJpYnV0ZXMgKGJhc2UgKyBwZXItdmFyaWFudCwgdmFyaWFudC1sYWJlbGxlZCkgYW5kIGEgdXNhZ2Ugc25pcHBldCBidWlsdCBwZXIgdGhlXFxuc3BlYydzIMKnMS4xIHBlci1zaGFwZSBydWxlcyAodmFyaWFudCBkaXNjcmltaW5hdG9ycywgY2hpbGQgcnVsZXMsIHRoZSBTaG93KlxcbnRocmVzaG9sZHMsIFwifTxfY29tcG9uZW50cy5jb2RlPntcImxpdGVyYWwtYXJyYXlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHBsYWNlaG9sZGVycykuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2FwcC9Wb2NhYnVsYXJ5U2VjdGlvbi50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCB0aGUgcGFuZWwgc2VjdGlvbjogY29sbGFwc2libGUgcGVyIGVudHJ5LCBhXFxud2lkZ2V0cy9kaXNwbGF5L2FsbCBmaWx0ZXIsIGFuZCBhIGd1YXJkZWQgY29weSBhZmZvcmRhbmNlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIldpcmVkIGludG8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2FwcC9Xb3JrYm9va1BhbmVsLnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCI7IHRoZSByZXBvcnQgaGVhZGVyIGJ1dHRvbiBpcyBub3dcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJXb3JrYm9va1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgLyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJDbG9zZSB3b3JrYm9va1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9BcHAudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cImdhdGUtY292ZXJhZ2VcIj48SGVhZGluZ0FuY2hvciBpZD1cImdhdGUtY292ZXJhZ2VcIiAvPntcIkdhdGUgY292ZXJhZ2VcIn08L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy50YWJsZT48X2NvbXBvbmVudHMudGhlYWQ+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50aD57XCJHYXRlXCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGg+e1wiVGVzdFwifTwvX2NvbXBvbmVudHMudGg+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50Ym9keT48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkctRE4tQTFcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJzcmMvYXBwL3ZvY2FidWxhcnkudGVzdC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIGVudW1lcmF0ZXMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY29tcG9uZW50TmFtZXNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBuZXZlciBhIGxpdGVyYWwgbGlzdFwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkctRE4tQTJcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJzYW1lIOKAlCB3aWRnZXQvY29udGFpbmVyIG1hcmtlcnM7IFwifTxfY29tcG9uZW50cy5jb2RlPntcIkNoYXJ0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIidzIGRpc2NyaW1pbmF0b3IgYW5kIGl0cyBwZXItdmFyaWFudCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJ5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhbmQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaGlzdG9ncmFtLnZhbHVlXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkctRE4tQTNcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJzYW1lIOKAlCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImV2ZXJ5XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHNuaXBwZXQgcGFyc2VkIGJ5IHRoZSByZWFsIFwifTxfY29tcG9uZW50cy5jb2RlPntcInBhcnNlVGVtcGxhdGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFuZCBydW4gdGhyb3VnaCB0aGUgcmVhbCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ2YWxpZGF0ZVRlbXBsYXRlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgYXNzZXJ0aW5nIHplcm8gZXJyb3IgZGlhZ25vc3RpY3MsIG9uZSB0ZXN0IHBlciBjYXRhbG9nIGVudHJ5ICgxOSBvZiB0aGVtKSBzbyBhIGZ1dHVyZSBlbnRyeSBjYW5ub3QgcmVncmVzcyBzaWxlbnRseVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkctRE4tQTRcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJzYW1lIOKAlCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ3aWRnZXRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiA9IFwifTxfY29tcG9uZW50cy5jb2RlPntcIldJREdFVFNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjb21wb25lbnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiA9IGl0cyBleGFjdCBjb21wbGVtZW50LCB1bnNldCA9IGFsbFwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkctRE4tQTVcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJzcmMvYXBwL1ZvY2FidWxhcnlTZWN0aW9uLnRlc3QudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgc3RhdGljIHJlbmRlciB3aXRoIG5vIGhvc3QgdHJhbnNwb3J0XCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiRy1ETi1BNlwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcInRoZSBoZWFkZXIgc3RyaW5ncyBpbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvQXBwLnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50Ym9keT48L19jb21wb25lbnRzLnRhYmxlPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQWxsIDE5IHNuaXBwZXRzIHZhbGlkYXRlIG9uIHRoZSBmaXJzdCBpbXBsZW1lbnRhdGlvblwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgdGhlIHNwZWMncyDCpzEuMSBwZXItc2hhcGVcXG5ydWxlcyB3ZXJlIHN1ZmZpY2llbnQsIGluY2x1ZGluZyB0aGUgc2V2ZW4gZW50cmllcyB0aGUgYWR2ZXJzYXJpYWwgcGFzcyBpZGVudGlmaWVkIGFzXFxuaW1wb3NzaWJsZSB1bmRlciB0aGUgZHJhZnQncyBhdHRyaWJ1dGUtb25seSByZWNpcGUgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIkNoYXJ0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiTWFwXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRmFjZXRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiUGFyYW1zXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIixcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJTaG93QWJvdmVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJTaG93QmVsb3dcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBhbmQgdGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcImxpdGVyYWwtYXJyYXlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNhcnJpZXJzKS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwiYWxzby1sYW5kZWQtd2l0aC1wYXJ0LWFcIj48SGVhZGluZ0FuY2hvciBpZD1cImFsc28tbGFuZGVkLXdpdGgtcGFydC1hXCIgLz57XCJBbHNvIGxhbmRlZCB3aXRoIFBhcnQgQVwifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkEgcGxhdGZvcm0gZ3VhcmQgYWdhaW5zdCB0aGUgRE4tUjUgaGF6YXJkXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvYXBwL3BsYXRmb3JtR3VhcmRzLnRlc3QudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKTogbm9cXG5tb2R1bGUgbWF5IFwifTxfY29tcG9uZW50cy5lbT57XCJzdGF0aWNhbGx5IHZhbHVlLWltcG9ydFwifTwvX2NvbXBvbmVudHMuZW0+e1wiIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkBpbW1lZGlhdGVseS1ydW4vc2RrXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBvciBcIn08X2NvbXBvbmVudHMuY29kZT57XCLigKYvdGFza3NcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCB3aGljaFxcbnJlZ2lzdGVyIGEgaG9zdCBsaXN0ZW5lciBhdCBtb2R1bGUgbG9hZCBhbmQgdGhyb3cgd2l0aCBubyB0cmFuc3BvcnQuIFwifTxfY29tcG9uZW50cy5jb2RlPntcImltcG9ydCB0eXBlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIixcXG50aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibW91bnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBzdWJwYXRoIGFuZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJhd2FpdCBpbXBvcnQoKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYXJlIGFsbCBjb3JyZWN0bHkgbm90IG1hdGNoZWQg4oCUIHByb3ZlbiBieVxcbmZhdWx0IGluamVjdGlvbiBvdmVyIGZpdmUgY2FzZXMsIG5vdCBieSBpbnNwZWN0aW9uLiBUaGlzIGd1YXJkIGV4aXN0cyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImJlZm9yZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBQYXJ0IEJcXG5uZWVkcyBpdCwgc28gdGhlIG1pc3Rha2UgY2Fubm90IGJlIG1hZGUgbGF0ZXIuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJBIGxpbnQtcmVkIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1haW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGZpeGVkXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBSMy00Mjcgc2hpcHBlZCBhbiB1bnVzZWQtYmluZGluZyBlcnJvciBiZWNhdXNlIHRoZVxcbnZlcmlmaWNhdGlvbiBjb21tYW5kIHBpcGVkIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm5wbSBydW4gbGludFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaW50byBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ0YWlsXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgYW5kIGEgcGlwZWxpbmUncyBleGl0IHN0YXR1cyBpc1xcbnRoZSBcIn08X2NvbXBvbmVudHMuZW0+e1wibGFzdFwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGNvbW1hbmQncywgc28gdGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcIiYmXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjaGFpbiBjb250aW51ZWQgcGFzdCBhIGZhaWxpbmcgZ2F0ZS4gRml4ZWQgaGVyZSwgYW5kXFxudGhlIGxlc3NvbiBpcyB3b3J0aCBrZWVwaW5nOiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5ldmVyIHBpcGUgYSBnYXRlIGludG8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widGFpbFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaGVhZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaW4gYSBjaGFpbmVkXFxudmVyaWZpY2F0aW9uXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBjYXB0dXJlIHRvIGEgZmlsZSBhbmQgY2hlY2sgdGhlIGV4aXQgY29kZS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwicGFydC1iLXRoZS1lZGl0LWFmZm9yZGFuY2UtcjMtNDQ3LXRoZS1jb250cmFjdC1lc3RhYmxpc2hlZC10aGUtYnVpbGQtbGFuZGVkXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJwYXJ0LWItdGhlLWVkaXQtYWZmb3JkYW5jZS1yMy00NDctdGhlLWNvbnRyYWN0LWVzdGFibGlzaGVkLXRoZS1idWlsZC1sYW5kZWRcIiAvPntcIlBhcnQgQiDigJQgdGhlIGVkaXQgYWZmb3JkYW5jZSAoUjMtNDQ3OiB0aGUgY29udHJhY3QgZXN0YWJsaXNoZWQsIHRoZSBidWlsZCBsYW5kZWQpXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlBoYXNlIDEg4oCUIHRoZSBwcmVjb25kaXRpb25zLCBlc3RhYmxpc2hlZCAyMDI2LTA5LTIyXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICh0aGUgd29ya2VyLVZNIGFnZW50IHZlbnVlOlxcbmN1cnJlbnQtbWFpbiBkZXYgaG9zdCArIHN0YWdpbmcgYmFja2VuZC9GaXJlc3RvcmUsIHRoZSByZWFsIHJlcG8tbG9hZCBkaXNwYXRjaCwgYVxcbndvcmtib29rIGNvcnB1cyByZXBvIGRpc3BhdGNoZWQgYnkgVVJMOyBicm93c2VyLWRyaXZlbiBvYnNlcnZhdGlvbiBvZmYgdGhlIGxpdmVcXG5jaGFubmVsLCBwZXIgdGhlIHNwZWMncyBydWxlIOKAlCBhbiBpbmplY3RlZCBwb3J0IGNhbm5vdCBmYWxzaWZ5IGEgcXVlc3Rpb24gYWJvdXQgdGhlXFxuaG9zdCk6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy50YWJsZT48X2NvbXBvbmVudHMudGhlYWQ+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50aD57XCIjXCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGg+e1wiQW5zd2VyICh3aXRoIGhvdyBpdCB3YXMgZXN0YWJsaXNoZWQpXCJ9PC9fY29tcG9uZW50cy50aD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGhlYWQ+PF9jb21wb25lbnRzLnRib2R5PjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiUDFcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJBIFwifTxfY29tcG9uZW50cy5jb2RlPntcInR5cGU6ICdjb250ZW50J1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZGlzcGF0Y2ggbW91bnQgY2FycmllcyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJpZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaW4gdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1widW5pdmVyc2FsIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNjaGVtZTpsb2NhdG9yXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBmb3JtXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBvYnNlcnZlZCBsaXZlIGFzIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNvbnRlbnQ6aW1tZWRpYXRlbHktcnVuLXdvcmtlci9yMy00NDctd29ya2Jvb2tcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICh0aGUgZnJhbWUncyBvd24gbW91bnQgc2VydmljZSwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZ2V0TW91bnRzKClcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKS4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2FwRmlsZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIncyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJtb3VudElkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpcyB0aGVyZWZvcmUgYWRkcmVzc2VkIHdpdGggdGhlIGRlc2NyaXB0b3IncyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJpZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdmVyYmF0aW07IHRoZSBob3N0J3MgZ3JhbnQgbG9va3VwIGlzIGFuIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZXhhY3QgbWF0Y2hcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgb24gaXQgKFwifTxfY29tcG9uZW50cy5jb2RlPntcInRhc2tJbnZvY2F0aW9uLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDihpIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZ3JhbnRGb3JcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSwgYW5kIG5vIGZhbGxiYWNrIGlzIGRvY3VtZW50ZWQg4oCUIGEgcGF0aC1zaGFwZWQgb3IgYmFyZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJtb3VudElkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB3b3VsZCByZWZ1c2UgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZm9yYmlkZGVuXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgd2hpY2ggaXMgd2h5IHRoZSBkb29yIGZhaWxzIGNsb3NlZCBvbiBhbiBpZC1sZXNzIG1vdW50IHJhdGhlciB0aGFuIG1ha2luZyBhIGRvb21lZCBjYWxsLiBUaGUgdW5xdWFsaWZpZWQgZm9ybSBpcyBub3Qgd2hhdCB0aGUgaG9zdCBtaW50cy5cIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJQMlwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIlRoZSBtb3VudCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInJlcG9ydHMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibW9kZVwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIG9ic2VydmVkIGxpdmUgYXMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiJ3J3J1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgb24gdGhlIHJlcG8tbG9hZCBkaXNwYXRjaCAod3JpdGVzIGxhbmQgaW4gdGhlIGNvcnB1cyBtb3VudDsgcHJvcG9zaW5nIGJhY2sgdG8gdGhlIHNvdXJjZSByZXBvIHN0YXlzIHVud2lyZWQsIHRoZSBSQ0Qgwqc1LjEgZGlzY2xvc3VyZSkg4oCUIGFuZCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPjxfY29tcG9uZW50cy5jb2RlPntcInJ1bGVzOiBudWxsXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAobm8gcnVsZXMpLiBUaGUgZWRpdGFiaWxpdHkgZGVyaXZhdGlvbiB0aGVyZWZvcmUga2V5cyBvbiB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJwb3NpdGl2ZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyd1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgY2hlY2tcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgUi1FRkUtMSBwcmVzY3JpYmVzOyB0aGUgZHJhZnQncyBcXFwiYWJzZW50IOKHkiB3cml0YWJsZVxcXCIgaW52ZXJzaW9uIChETi1SMikgaXMgZGVhZCwgYW5kIHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzdWJ0cmVlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi1jb21wYXJhYmlsaXR5IHF1ZXN0aW9uIChETi1SMykgZGlzc29sdmVzIOKAlCB0aGVyZSBhcmUgbm8gcnVsZXMgdG8gY29tcGFyZS4gVGhpcyByZXBvJ3MgZGlzcGF0Y2ggZml4dHVyZXMgc3RhbXAgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibW9kZTogJ3JvJ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCI7IHRoZSBsaXZlIHJlcG8tbG9hZCBtb3VudCBzdGFtcHMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicndcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCB0aGUgZml4dHVyZXMgbW9kZWwgdGhlIHRhc2staW52b2NhdGlvbiBzaGFwZSwgbm90IHRoaXMgb25lLlwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIlAzXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnN0cm9uZz57XCJCb3RoIGNoYW5uZWxzIGFyZSByZWFsIGFuZCBzaGFwZWQgYXMgwqc0LjIgaGFuZGxlcyB0aGVtLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBEb2N1bWVudGVkIGhhbGYgKHRoZSBob3N0J3MgdGFzayBjb250cmFjdCwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widGFza0NvbnRyYWN0cy50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpOiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJlZGl0LWZpbGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHJldHVybnMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wieyBzYXZlZDogYm9vbGVhbiB9XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic2F2ZWQ6IGZhbHNlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpcyB0aGUgcmVzdWx0LWNhcnJpZWQgcmVmdXNhbCwgYW5kIFwifTxfY29tcG9uZW50cy5jb2RlPntcImludm9rZVRhc2tcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHRocm93cyBtYWNoaW5lIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi5jb2RlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiByZWplY3Rpb25zIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJjYW5jZWxsZWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmb3JiaWRkZW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCDigKYpLiBMaXZlIGhhbGYgKGEgcmVhbCBpbnZvY2F0aW9uIGZyb20gdGhlIGRpc3BhdGNoZWQgZnJhbWUpOiBleGVyY2lzZWQgYnkgdGhlIGdhdGVzIGJlbG93IOKAlCBpdCByZXF1aXJlZCBQNCdzIGdyYW50IGZpcnN0LCB3aGljaCBpcyB0aGUgc2VxdWVuY2luZyBmaW5kaW5nLCBub3QgYSBnYXAuXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiUDRcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIk5PIOKAlCBhbmQgZGVsaWJlcmF0ZWx5IHNvLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGUgYnVpbGQtZGVmYXVsdCBiaW5kaW5nIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJzaXRlLW1haW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIFwifTxfY29tcG9uZW50cy5jb2RlPntcInJlZ2lzdHJ5L2RlZmF1bHRzLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widGFzay5vcGVuLXdvcmtib29rXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikgb21pdHRlZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ0YXNrOmludm9rZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgd2l0aCBhIGNvbW1lbnQgbmFtaW5nIHRoaXMgbWlsZXN0b25lIGFzIHRoZSBtb21lbnQgdG8gYWRkIGl0OyB0aGUgZnJhbWUncyBsaXZlIGdyYW50LWZpbHRlcmVkIGNhdGFsb2cgY2FycmllZCBubyB0YXNrIHZlcmIuIFRoZSBncmFudCBoYWxmIGlzIHNpdGUtbWFpbidzIFIzLTQ0NyByZWdpc3RyeSBkaWZmICh0aGlzIG1pbGVzdG9uZSk7IHRoZSBtYW5pZmVzdCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJpbnZva2VzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBkZWNsYXJhdGlvbiAodGhpcyByZXBvKSBpcyB0aGUgc2VsZi1yZXN0cmljdGlvbiBoYWxmIOKAlCBHLUROLUIxMCBhc3NlcnRzIGJvdGguXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiUDVcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlRoZSBkaXNwYXRjaGVkIHNoYXBlIGlzIHJlYWNoYWJsZSBhbmQgcmVuZGVycy5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgRHJpdmVuIGxpdmU6IGEgd29ya2Jvb2sgY29ycHVzIHJlcG8gKHRoZSBNZXJpZGlhbiBzZWVkIGFzIHJlYWwgZmlsZXMgKyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJpbW1lZGlhdGVseS5ydW4uanNvblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgbWFya2VyIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm9wZW5zV2l0aDogb3Blbi13b3JrYm9va0AxLjBcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSBkaXNwYXRjaGVkIGJ5IFVSTCB0aHJvdWdoIHRoZSByZWFsIHJlcG8tbG9hZCBicmFuY2gg4oCUIHN0b2NrIHJlY2tvbmVyIGZyb20gdGhlIHJlZ2lzdHJ5IGJpbmRpbmcgcmVuZGVyZWQgdGhlIHJlcG9ydCAobmF2LCBncm93dGgtY29tcG9zaXRpb24gc2VjdGlvbnMsIHRoZSB3b3JrYm9vayBwYW5lbCkuIFRoZSBob25lc3Qgc2VxdWVuY2luZyBub3RlczogXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJubyB3b3JrYm9vayBjb3JwdXMgcmVwbyBleGlzdGVkXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICh0aGUgY29ycHVzIGlzIGNvbnRlbnQgd29yaywgbm90IHBsYXRmb3JtIHdvcmsg4oCUIHRoZSBzcGlrZSdzIGNvcnB1cyBpcyB0ZW1wb3JhcnkpLCBhbmQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJubyB1c2VyLWZhY2luZyBjYWxsZXIgaW52b2tlcyB0aGUgdGFza1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAodGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm9wZW5zV2l0aFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgbWFya2VyJ3Mgb25seSByZWFkZXIgaXMgdGhlIFVSTCByb3V0ZTsgdGhlIGZvbGRlci10cmlnZ2VyIGNhbGxlciBpcyBSMy0yNjcpIOKAlCB0aGUgVVJMIHJvdXRlIGlzIHRoZSByZWFjaGFibGUgc2hhcGUuXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGJvZHk+PC9fY29tcG9uZW50cy50YWJsZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlBoYXNlIDIg4oCUIGJ1aWx0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICh0aGUgc2FtZSBpdGVtKTogdGhlIGluc3BlY3RvcidzIHBlci1yb3cgZWRpdCBkb29yIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJWYWx1ZUluc3BlY3RvclwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLFxcbnRoZSDCpzQuMyBwYXRoIGdhdGUgKFwifTxfY29tcG9uZW50cy5jb2RlPntcImRvY3VtZW50UGF0aHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSwgdGhlIGRvb3IgaXRzZWxmIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJ1c2VFZGl0RmlsZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIGxhenkgaW1wb3J0LCBib3RoXFxucmVmdXNhbCBjaGFubmVscywgdGhlIHNlc3Npb24tc2NvcGVkIGxhdGNoLCB0aGUgaG9zdC1sZXNzIG5vLW9wLCB0aGUgwqc0LjQgc3RhbGVuZXNzXFxuc2lnbmFsKSwgdGhlIHN0YWxlbmVzcyBub3RpY2UgKyByZWxvYWQgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIkRvY3VtZW50Q2hhbmdlZE5vdGljZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcInVzZVJlcG9ydC5yZWxvYWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSxcXG50aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW52b2tlc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZGVjbGFyYXRpb24sIGFuZCBzaXRlLW1haW4ncyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ0YXNrOmludm9rZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZ3JhbnQuIFE2ICh0aGUgY29uc3VtZXJcXG5pbnNwZWN0b3IncyBkb29yKSByZXNvbHZlcyBwZXIgdGhlIGl0ZW0ncyBvd24gUGhhc2UtMiBzdXJmYWNlIChcXFwidGhlIGluc3BlY3RvcidzIGZvcm11bGFcXG5hbmQgdGVzdCByb3dzXFxcIik7IFEzIChyZWxvYWQgdnMgY2hhbmdlLXdhdGNoKSByZXNvbHZlcyB0byB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJyZWxvYWQgYWZmb3JkYW5jZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgYVxcbmNoYW5nZS13YXRjaCBuZWVkcyBhbiBmcyB3YXRjaCB0aGUgdGFzay1kZWxlZ2F0ZWQgZXhwb3J0IGRvZXMgbm90IGNhcnJ5XFxuKFNQQUNFU19VSSDCpzYuNiAvIFIzLTczMidzIHNlYW0pLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCJnYXRlLWNvdmVyYWdlLTFcIj48SGVhZGluZ0FuY2hvciBpZD1cImdhdGUtY292ZXJhZ2UtMVwiIC8+e1wiR2F0ZSBjb3ZlcmFnZVwifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnRhYmxlPjxfY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRoPntcIkdhdGVcIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aD57XCJUZXN0XCJ9PC9fY29tcG9uZW50cy50aD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGhlYWQ+PF9jb21wb25lbnRzLnRib2R5PjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiRy1ETi1CMVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcImRpc3BhdGNoLnRlc3QudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCB0aGUgb2sgcmVzb2x1dGlvbiBjYXJyaWVzIHRoZSBsaXZlIG1vdW50IChpZC9tb2RlIHByb3ZlbmFuY2UpOyB0aGUgbGl2ZSBkZXNjcmlwdG9yIHJlYWQgb24gdGhlIHZlbnVlIChhYm92ZSlcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJHLUROLUIyXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1widXNlRWRpdEZpbGUudGVzdC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIHdyaXRhYmlsaXR5IGJ5IHRoZSBwb3NpdGl2ZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyd1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgY2hlY2sgKHJvL2Fic2VudCBhcmUgbm90IGRvb3JzKVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkctRE4tQjNcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJkb2N1bWVudFBhdGhzLnRlc3QudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCBzZWdtZW50LWJvdW5kYXJ5IHRyYXZlcnNhbCByZWZ1c2FsOyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ1c2VFZGl0RmlsZS50ZXN0LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgYSBmYWlsaW5nIHBhdGggbmV2ZXIgY29uc3RydWN0cyB0aGUgZGVsZWdhdGlvblwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkctRE4tQjRcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJ1c2VFZGl0RmlsZS50ZXN0LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgdGhlIGNhbGwgYWRkcmVzc2VzIHRoZSBkZXNjcmlwdG9yIGlkICh1bml2ZXJzYWwgZm9ybSk7IGFuIGlkLWxlc3MgbW91bnQgaXMgbm90IGEgZG9vciAoZmFpbC1jbG9zZWQg4oCUIHRoZSBob3N0J3MgZXhhY3QtbWF0Y2ggZ3JhbnQgbG9va3VwIGhhcyBubyBkb2N1bWVudGVkIGZhbGxiYWNrKTsgdGhlIGxpdmUgaW52b2NhdGlvbiBnYXRlIGJlbG93XCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiRy1ETi1CNVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcInVzZUVkaXRGaWxlLnRlc3QudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCBib3RoIGNoYW5uZWxzOiB0aHJvd24gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2FuY2VsbGVkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJmb3JiaWRkZW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcInRpbWVvdXRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCB0aGUgcmVzdWx0LWNhcnJpZWQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wie3NhdmVkOmZhbHNlfVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcmVmdXNhbCwgdGhlIGhvc3QtbGVzcyBuby1vcDsgdGhlIGxpdmUgZ2F0ZSBiZWxvd1wifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkctRE4tQjZcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJWYWx1ZUluc3BlY3Rvci50ZXN0LnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIGFic2VudCB1bmxlc3Mgd3JpdGFibGUgKHBlciByb3cpLCBwcmVzZW50IGJlc2lkZSBib3RoIGFuY2hvcnMsIHRoZSBkaXNjbG9zdXJlIGF0IHRoZSBidXR0b24sIHRoZSBjbGljayBoYW5kcyB0aGUgcm93J3MgcGF0aDsgdGhlIGxpdmUgZ2F0ZSBiZWxvd1wifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkctRE4tQjdcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJkb2N1bWVudFBhdGhzLnRlc3QudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCB0cmF2ZXJzYWwtc2hhcGVkIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1hbmlmZXN0LndvcmtzaGVldHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHBhdGhzIG5ldmVyIHJlYWNoIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNhcEZpbGVcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiRy1ETi1COFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcInRoZSBwcmUtZXhpc3RpbmcgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicGxhdGZvcm1HdWFyZHMudGVzdC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKG5vIHN0YXRpYyB0YXNrcyBpbXBvcnQpICsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widXNlRWRpdEZpbGUudGVzdC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIncyBob3N0LWxlc3Mgbm8tb3AgY2FzZVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkctRE4tQjlcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJEb2N1bWVudENoYW5nZWROb3RpY2UudGVzdC50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widXNlUmVwb3J0LnRlc3QudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAodGhlIHJlbG9hZCk7IHRoZSBsaXZlIGdhdGUgYmVsb3dcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJHLUROLUIxMFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcInBhY2thZ2UuanNvblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW52b2tlc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKHRoaXMgcmVwbykgKyBzaXRlLW1haW4ncyByZWdpc3RyeSBkaWZmIGFuZCBpdHMgZXhhY3QtbGlzdCB0ZXN0XCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGJvZHk+PC9fY29tcG9uZW50cy50YWJsZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlRoZSBob3N0LWV4ZXJjaXNlZCBoYWx2ZXMgKFAx4oCTUDQncyBsaXZlIGxlZ3M6IGEgcmVhbCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJlZGl0LWZpbGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGludm9jYXRpb24gZnJvbSB0aGVcXG5kaXNwYXRjaGVkIGZyYW1lIOKAlCB0aGUgZG9vciB2aXNpYmxlIG9uIHRoZSBkaXNwYXRjaGVkIHNoYXBlLCB0aGUgb3ZlcmxheSBvcGVuaW5nLCBib3RoXFxucmVmdXNhbCBjaGFubmVscyBvYnNlcnZlZCBvbiB0aGUgcmVhbCBnYXRlLCB0aGUgc3RhbGVuZXNzIGFmZm9yZGFuY2UgYWZ0ZXIgYSBzYXZlKSBydW5cXG5vbiB0aGUgdmVudWUgYWdhaW5zdCB0aGUgbWVyZ2VkIG1haW5zIGJlZm9yZSBSMy00NDcgYXJjaGl2ZXM7IHRoZSB1bml0IGhhbHZlcyBhYm92ZSBhcmVcXG5pbi1yZXBvIGFuZCBncmVlbi5cIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwib3Blbi1yZXNpZHVhbHNcIj48SGVhZGluZ0FuY2hvciBpZD1cIm9wZW4tcmVzaWR1YWxzXCIgLz57XCJPcGVuIHJlc2lkdWFsc1wifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz48X2NvbXBvbmVudHMuY29kZT57XCJlZGl0LXRhYmxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpcyBub3cgc3BlY2lmaWVkXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICgyMDI2LTA4LTI5KSDigJQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRURJVF9UQUJMRV9UQVNLX1NQRUMubWR4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpbiB0aGUgZG9jc1xcbnJlcG8sIHByb3Bvc2FsIHJldiAyIGFmdGVyIGFuIGFkdmVyc2FyaWFsIHBhc3MuIEl0IGlzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiYmxvY2tlZCBvbiBQMeKAk1A1IGFib3ZlIHBsdXMgdHdvXFxub2YgaXRzIG93blwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoXCJ9PF9jb21wb25lbnRzLmRlbD57XCJQNjogdGFzay1kZWxlZ2F0aW9uIG1vdW50cyBhcmUgYW5ub3VuY2VkIHdpdGggbm8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibW9kZVwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLmRlbD57XCIg4oCUIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiY2xvc2VkXFxuMjAyNi0wOS0yOSBieSB0aGUgUjMtNzU0IHByb2JlIGJlbG93OiB0aGUgZGVsZWdhdGlvbiBtb3VudCBhbm5vdW5jZXMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibW9kZTogJ3JvJ1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnN0cm9uZz57XCJcXG4odGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1pbihjYWxsZXIgZ3JhbnQsIGNhcCwgY29udHJhY3QpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBzdGFtcCwgc2l0ZS1tYWluIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1pbnREZWxlZ2F0aW9ucy50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLCBzbyB0aGVcXG5yZWFkLW9ubHkgcnVsZSBJUyBpbXBsZW1lbnRhYmxlOyBQNzogUmVja29uZXIgaGFzIG5vIGZzIHdhdGNoLCBzbyB0aGUgYXV0b3NhdmUgc2FmZXR5IGFyZ3VtZW50XFxuaGFzIG5vIGNvbnN1bWVyKS4gUjMtNDQ3J3MgaG9zdCBzcGlrZSB0aGVyZWZvcmUgdW5ibG9ja3MgYm90aCBzdXJmYWNlcywgbm90IGp1c3RcXG5QYXJ0IEIg4oCUIHdvcnRoIGtub3dpbmcgYmVmb3JlIHNjb3BpbmcgaXQuIFRoZSAyMDI2LTA4LTI5IHJldmlldyBhbHNvIGNvbmZpcm1lZCB0aGVcXG5zZWVkLXZzLW1vdW50IHdhbGwgYXBwbGllcyB0byBmaXh0dXJlcyBleGFjdGx5IGFzIGl0IGRvZXMgdG8gd29ya3NoZWV0czogb24gdGhlXFxuYnVuZGxlZC1zZWVkIHBhdGggdGhlcmUgaXMgbm8gZmlsZSB0byBkZWxlZ2F0ZSwgb25seSBhIHN0cmluZyBpbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvc2VlZC9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJTcGVjIMKnNiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZWRpdC10YWJsZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIG9wZW4tYXQtbGluZSwgRGVsdGEgQiwgY2xpY2stdG8taW5zZXJ0LCBvd24tc291cmNlIGVkaXRpbmcpIGFuZFxcbsKnMTEgUTHigJNRNyDigJQgaW5jbHVkaW5nIHRoZSB0d28gdGhlIHJldmlldyBzdXJmYWNlZCBhcyByZWFsIGRlY2lzaW9ucyByYXRoZXIgdGhhblxcbmRlZmVycmFsczogd2hldGhlciB0aGUgY29uc3VtZXItdmlzaWJsZSBpbnNwZWN0b3IgY2FycmllcyBhbiBhdXRob3JpbmcgZG9vciAoUTYpLCBhbmRcXG50aGUgdGVtcGxhdGUtZmlsZSBlZGl0IHJvdyB3aXRob3V0IHdoaWNoIFxcXCJjb3B5IHRoZSBzbmlwcGV0LCBvcGVuIHRoZSB0ZW1wbGF0ZVxcXCIgaGFzIG5vXFxuZG9vciAoUTcpLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCJ0aGUtc2Vjb25kLWRpc3BhdGNoLXNoYXBlcy1kZXNjcmlwdG9yLXIzLTc1NC1wcm9iZWQtbGl2ZS0yMDI2LTA5LTI5XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJ0aGUtc2Vjb25kLWRpc3BhdGNoLXNoYXBlcy1kZXNjcmlwdG9yLXIzLTc1NC1wcm9iZWQtbGl2ZS0yMDI2LTA5LTI5XCIgLz57XCJUaGUgc2Vjb25kIGRpc3BhdGNoIHNoYXBlJ3MgZGVzY3JpcHRvciAoUjMtNzU0LCBwcm9iZWQgbGl2ZSAyMDI2LTA5LTI5KVwifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiUHJvYmVkIG9uIHRoZSB2ZW51ZSAoc3RhZ2luZyBjb21wb3NpdGlvbiwgZHJpdmVuIENocm9taXVtLCB0aGUgdmVudWUgaWRlbnRpdHkgc2lnbmVkXFxuaW4pOiB0aGUgY29ycHVzIG9wZW4gaW4gdGhlIGVkaXRvciwgZmlsZS1leHBsb3JlcidzIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm9wZW5zV2l0aFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYWZmb3JkYW5jZSBvbiB0aGVcXG5jb3JwdXMgcm9vdCAoXFxcIk9wZW4gYXMgd29ya2Jvb2tcXFwiKSwgdGhlIHRhc2sgb3ZlcmxheSBydW5uaW5nIHJlY2tvbmVyLiBUaGUgZnJhbWUncyBvd25cXG5tb3VudCBzZXQsIHJlYWQgZnJvbSB0aGUgY2FsbGVlOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucHJlPjxfY29tcG9uZW50cy5jb2RlIGNsYXNzTmFtZT1cImxhbmd1YWdlLWpzb25cIj57XCJ7IFxcXCJpZFxcXCI6IFxcXCIvdGFzay90YXNrLTEvZGlyXFxcIiwgXFxcInBhdGhcXFwiOiBcXFwiL3Rhc2svdGFzay0xL2RpclxcXCIsXFxuICBcXFwidHlwZVxcXCI6IFxcXCJ0YXNrLWRlbGVnYXRpb25cXFwiLCBcXFwibW9kZVxcXCI6IFxcXCJyb1xcXCIsIFxcXCJydWxlc1xcXCI6IG51bGwgfVxcblwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnByZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJ3aXRoIHRoZSB0YXNrIGlucHV0IFwifTxfY29tcG9uZW50cy5jb2RlPntcInsgdGFzazogJ29wZW4td29ya2Jvb2snLCBwYXJhbXM6IHsgZGlyOiAnL3Rhc2svdGFzay0xL2RpcicgfSB9XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJRcXG50aGUgaG9zdCBSRVdSSVRFUyB0aGUgY2FsbGVyJ3MgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZGlyXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB0byB0aGUgbWludGVkIGNocm9vdCBwYXRoLCBhbmQgdGhlIG1vdW50J3MgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxuaXMgdGhhdCBzYW1lIHBhdGggKE5PVCB0aGUgdW5pdmVyc2FsIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNjaGVtZTpsb2NhdG9yXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBmb3JtIFAxIGVzdGFibGlzaGVkIGZvclxcblwifTxfY29tcG9uZW50cy5jb2RlPntcInR5cGU6ICdjb250ZW50J1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgbW91bnRzIOKAlCB0aGUgdHdvIHNoYXBlcyBhZGRyZXNzIGRpZmZlcmVudGx5LCBhbmQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZGlzcGF0Y2gudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiJ3NcXG50YXNrIGJyYW5jaCBhZGRyZXNzZXMgdGhlIGRlbGVnYXRpb24gYnkgdGhlIHBhdGgtZm9ybSBpZCBpdCBhcnJpdmVzIHdpdGgpLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgbW9kZSBpcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPjxfY29tcG9uZW50cy5jb2RlPntcInJvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBldmVuIHdoZW4gdGhlIGNhbGxlcidzIHNlc3Npb24gaG9sZHMgdGhlIGNvcnB1cyByZWFkLXdyaXRlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICh0aGVcXG5lZGl0IHNlc3Npb24ncyB3b3JrdHJlZSk6IFwifTxfY29tcG9uZW50cy5jb2RlPntcInBhbmVsLmZpbGVzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIidzIHB1Ymxpc2hlZCBwb3J0IG9mIHRoZSB3b3JrdHJlZSBpcyBpdHNlbGZcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJyb1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIHNvIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1pbijigKYpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjbGFtcHMgdG8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicm9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHJlZ2FyZGxlc3Mgb2YgdGhlIHNlc3Npb24ncyB3cml0YWJpbGl0eS4gVGhlIGVkaXRcXG5kb29yIHRoZXJlZm9yZSBzdGF5cyBkYXJrIG9uIGV2ZXJ5IGRpc3BhdGNoLWRyaXZlbiBvcGVuIOKAlCBieSBkZXNpZ24sIHBlbmRpbmcgUjMtNzk3IOKAlFxcbmFuZCB0aGUgVVJML3Rhc2sgZGlzcGF0Y2ggc2hhcGVzIGFyZSByZWNvcmRlZCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInZpZXctb25seVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAodGhlIG93bmVyJ3MgMjAyNi0wOS0yOFxcbmRlY2lzaW9uIChjKSBvbiBSMy03NTQpLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCJ0aGUtbGl2ZS1nYXRlcy0yMDI2LTA5LTIyLXRoZS12ZW51ZS1ydW4tYWdhaW5zdC1ib3RoLW1lcmdlZC1tYWlucy10d28tcGFzcy1vbmUtaXMtYS1maW5kaW5nXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJ0aGUtbGl2ZS1nYXRlcy0yMDI2LTA5LTIyLXRoZS12ZW51ZS1ydW4tYWdhaW5zdC1ib3RoLW1lcmdlZC1tYWlucy10d28tcGFzcy1vbmUtaXMtYS1maW5kaW5nXCIgLz57XCJUaGUgbGl2ZSBnYXRlcyAoMjAyNi0wOS0yMiwgdGhlIHZlbnVlIHJ1biBhZ2FpbnN0IEJPVEggbWVyZ2VkIG1haW5zKSDigJQgdHdvIHBhc3MsIG9uZSBpcyBhIEZJTkRJTkdcIn08L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkRyaXZlbiBvbiB0aGUgd29ya2VyLVZNIHZlbnVlIHdpdGggc2l0ZS1tYWluIGF0IDYwZGRkMGEgYW5kIHJlY2tvbmVyQG1haW4gYXQgMjkyNWZhNFxcbihib3RoIFBScyBtZXJnZWQpLCB0aGUgY29ycHVzIGRpc3BhdGNoZWQgYnkgVVJMOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRy1ETi1CNiBsaXZlOiBQQVNTLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGUgZG9vciByZW5kZXJzIGJlc2lkZSBib3RoIFwifTxfY29tcG9uZW50cy5jb2RlPntcImZpbGU6bGluZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYW5jaG9yc1xcbihcIn08X2NvbXBvbmVudHMuY29kZT57XCJ3b3Jrc2hlZXRzL3Jldmlldy5zaGVldC5qczozXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhbmQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiOjEwN1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpIG9uIHRoZSBkaXNwYXRjaGVkIHNoYXBlLCB3aXRoIHRoZSBSQ0RcXG7CpzUuMSBkaXNjbG9zdXJlIG9uIHRoZSBidXR0b24gdGl0bGUgQU5EIHRoZSB2aXNpYmxlIG5vdGUgbGluZS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkctRE4tQjUgbGl2ZSAodGhlIGZvcmJpZGRlbiBjaGFubmVsKTogUEFTUy5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgQSByZWZ1c2VkIGludm9jYXRpb24gZHJhd3MgZXhhY3RseVxcbm9uZSBwbGFpbiBtZXNzYWdlIChcXFwiVGhpcyBkb2N1bWVudCBjYW4ndCBiZSBlZGl0ZWQgaGVyZS5cXFwiKSBhbmQgbGF0Y2hlcyB0aGUgZG9vciBvZmYg4oCUXFxub2JzZXJ2ZWQgbGl2ZSwgbWF0Y2hpbmcgwqc0LjIgdG8gdGhlIGxldHRlci5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkctRE4tQjQgbGl2ZSAodGhlIHN1Y2Nlc3NmdWwgaW52b2NhdGlvbik6IEJMT0NLRUQgQlkgQSBGSU5ESU5HLCBub3QgYSBidWcgaW4gdGhpc1xcbnJlcG8ncyBoYWxmLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGUgaW52b2NhdGlvbiByZWZ1c2VzIFwifTxfY29tcG9uZW50cy5jb2RlPntcImZvcmJpZGRlbiDigJQgJ3Byb3RvY29sLXRhc2suaW52b2tlJyByZXF1aXJlcyB0aGUgJ3Rhc2s6aW52b2tlJyBjYXBhYmlsaXR5OyB0aGlzIGFwcCdzIGdyYW50IGRvZXMgbm90IGhvbGQgaXRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImRlc3BpdGVcXG5zaXRlLW1haW4jNTg0IGJlaW5nIG1lcmdlZCBhbmQgdGhlIHZlbnVlIHNlcnZpbmcgaXRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIuIFJvb3QgY2F1c2UgKGNvZGUgKyBsaXZlKTpcXG50aGUgVVJMIHJlcG8tbG9hZCBkaXNwYXRjaCByZXNvbHZlcyB0aGUgXCJ9PF9jb21wb25lbnRzLmVtPntcInZpZXdlcidzIHJlcG9cIn08L19jb21wb25lbnRzLmVtPntcIiBmcm9tIHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ0YXNrLm9wZW4td29ya2Jvb2tcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxuYmluZGluZywgYnV0IHRoZSBmcmFtZSdzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZ3JhbnRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgaXMgdGhlIHByZXZpZXcvc3RhZ2UgZ3JhbnQg4oCUIHRoZSByZWdpc3RyeSByb3cnc1xcbmNhcGFiaWxpdGllcyBuZXZlciBmbG93IHRvIHRoZSByZXBvLWxvYWQtZGlzcGF0Y2hlZCBmcmFtZS4gVGhlIHRhc2staW52b2NhdGlvbiBzaGFwZVxcbih3aGVyZSB0aGUgYmluZGluZydzIGdyYW50IGRvZXMgYXBwbHkpIGlzIHVucmVhY2hhYmxlIHR3aWNlIG92ZXI6IG5vIHVzZXItZmFjaW5nXFxuY2FsbGVyIGV4aXN0cyAoUjMtMjY3KSwgYW5kIHRoaXMgcmVwbydzIFwifTxfY29tcG9uZW50cy5jb2RlPntcImRpc3BhdGNoLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB2MSBkZWxpYmVyYXRlbHkgcmVzb2x2ZXMgb25seVxcbnRoZSByZXBvLWxvYWQgc2hhcGUuIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiVGhlIGFmZm9yZGFuY2UgaXMgdGhlcmVmb3JlIHVucmVhY2hhYmxlIG9uIGJvdGggZGlzcGF0Y2hcXG5zaGFwZXMg4oCUIEROLVIxMidzIGZhaWx1cmUgbW9kZSByZWJvcm4gYXQgdGhlIGludm9jYXRpb24gbGF5ZXIuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRoZSBmaXggaXMgYVxcbmRlc2lnbiBkZWNpc2lvbiB0aGUgb3duZXIgb3ducyAodGhlIHJlcG8tbG9hZCBkaXNwYXRjaCBtaW50aW5nIHRoZSB2aWV3ZXIncyBncmFudFxcbmZyb20gdGhlIHRhc2sgYmluZGluZzsgb3IgdGhlIHByZXZpZXcgZ3JhbnQgd2lkZW5pbmc7IG9yIHNoaXBwaW5nIHRoZSB0YXNrLXNoYXBlXFxuY2FsbGVyKTsgcmVjb3JkZWQgaW4gUjMtNDQ3J3Mgcm9hZG1hcCBzdGF0dXMsIHdoaWNoIHN0YXlzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiaW4tcHJvZ3Jlc3MsIHVuYXJjaGl2ZWRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cInRoZS1saXZlLWdhdGVzLW9uLXRoZS1ydy1kaXNwYXRjaC1zaGFwZS0yMDI2LTEwLTAxLXRoZS12ZW51ZS1yMy03OTdzLWdyYW50LWVkaXQtZmlsZTEwLXRoZS1yZW1haW5pbmctaGFsdmVzLXBhc3NcIj48SGVhZGluZ0FuY2hvciBpZD1cInRoZS1saXZlLWdhdGVzLW9uLXRoZS1ydy1kaXNwYXRjaC1zaGFwZS0yMDI2LTEwLTAxLXRoZS12ZW51ZS1yMy03OTdzLWdyYW50LWVkaXQtZmlsZTEwLXRoZS1yZW1haW5pbmctaGFsdmVzLXBhc3NcIiAvPntcIlRoZSBsaXZlIGdhdGVzIG9uIHRoZSBydyBkaXNwYXRjaCBzaGFwZSAoMjAyNi0xMC0wMSwgdGhlIHZlbnVlOyBSMy03OTcncyBncmFudCArIGVkaXQtZmlsZSMxMCkg4oCUIHRoZSByZW1haW5pbmcgaGFsdmVzIFBBU1NcIn08L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkRyaXZlbiBvbiB0aGUgd29ya2VyLVZNIHZlbnVlIChzdGFnaW5nIGNvbXBvc2l0aW9uOyBzaXRlLW1haW4gbWFpbiAwOTZjZTA4OyBTVE9DS1xcbnJlY2tvbmVyOyBjb3JwdXMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW1tZWRpYXRlbHktcnVuLXdvcmtlci9yMy00NDctd29ya2Jvb2tcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIFVSTC1kaXNwYXRjaGVkLCB0aGUgY29ycHVzXFxucHVibGlzaGluZyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInJ3XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHNpbmNlIFIzLTc5NyksIHdpdGggdGhlIGVtcHR5LXJlYWQgYmxvY2tlciByb290LWNhdXNlZCBhbmQgZml4ZWRcXG5maXJzdDpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlRoZSAyMDI2LTA5LTIyIEI0IGZpbmRpbmcgaXMgcmVzb2x2ZWQgaW4gdHdvIGxheWVycy5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhlIGdyYW50IGxheWVyIHdhcyBmaXhlZCBieVxcblIzLTc1NCAoZ3JhbnQgZmxvd3MgdG8gdGhlIGRpc3BhdGNoZWQgZnJhbWUpIGFuZCBSMy03OTcgKHRoZSBjb3JwdXMgcHVibGlzaGVzIFwifTxfY29tcG9uZW50cy5jb2RlPntcInJ3XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIlxcbnVuZGVyIGRpc3BhdGNoKS4gVGhlIGxheWVyIHRob3NlIGxlZ3MgZXhwb3NlZCDigJQgdGhlIGVkaXQtZmlsZSBvdmVybGF5IHJlbmRlcmluZ1xcblxcXCJOZXcgb3IgdW5yZWFkYWJsZSBmaWxlIOKAlCBzdGFydGluZyBlbXB0eVxcXCIgb24gYSBoZWFsdGh5IGRlbGVnYXRpb24g4oCUIHdhcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImFwcC1zaWRlLFxcbm5vdCBob3N0LXNpZGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCI6IHRoZSBlZGl0LWZpbGUgYXBwJ3MgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2ZzLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiByZWFkXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibW9kdWxlLmV2YWx1YXRpb24ubW9kdWxlLmJ1bmRsZXIuZnNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCB0aGUgb2JqZWN0IHRoZSBTREsncyBmcyBtb2R1bGUgbmFtZXMgYXMgdGhlXFxuZG9jdW1lbnRlZCBXUk9ORyBvbmUgKG5vIFwifTxfY29tcG9uZW50cy5jb2RlPntcInByb21pc2VzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJzdGF0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikuIEV2ZXJ5IHJlYWQgdGhyZXcgYmVmb3JlIGFueSBSUEMgbGVmdFxcbnRoZSBmcmFtZSAocHJvdmVuIGJ5IGEgaG9zdC1zaWRlIG9wIHRyYWNlOiB6ZXJvIG9wcyBhZnRlciB0aGUgZWRpdCBjbGljayksIGFuZCB0aGVcXG5jYWxsZWUncyBjYXRjaCByZW5kZXJlZCB0aGUgZW1wdHkgc3RhdGUuIFRoZSBzYW1lIGNocm9vdCBwYXRoIHJlYWQgdGhyb3VnaCB0aGVcXG5zdXBwb3J0ZWQgc3VyZmFjZSAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiX19zYW5kcGFja1NoYXJlZEZzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikgcmV0dXJuZWQgdGhlIGZpbGUncyBieXRlcy4gRml4ZWQgaW5cXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImVkaXQtZmlsZSMxMFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoZGVsZWdhdGUgdG8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQGltbWVkaWF0ZWx5LXJ1bi9zZGsvZnNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNhbmRib3hGcygpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjsgU0RLIHBpbm5lZFxcbjAuNzUuMCDigJQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiXjAuMTMuMFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcHJlZGF0ZXMgdGhlIFNESydzIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi9mc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgc3VicGF0aCwgc28gdGhlIGJ1bXAgd2FzIGZvcmNlZCkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJHLUROLUI0IGxpdmUgKHJlYWQgKyBzYXZlICsgdmFsdWUgcHJvdmVuYW5jZSk6IFBBU1MuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRoZSBlZGl0IGNoaXAgb25cXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJyZXZpZXcudG90YWxcIn08L19jb21wb25lbnRzLmNvZGU+e1wiJ3MgaW5zcGVjdG9yIG9wZW5zIHRoZSBvdmVybGF5LCB3aGljaCBub3cgUkVBRFNcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJ3b3Jrc2hlZXRzL3Jldmlldy5zaGVldC5qc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKHJlYWwgYnl0ZXMpLiBBIHByb2JlIGVkaXQgKHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ0b3RhbFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZm9ybXVsYSDDlzIpXFxuc2F2ZWQgdGhyb3VnaCB0aGUgZGVsZWdhdGlvbiDigJQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY29tcGxldGVUYXNrKHtzYXZlZDp0cnVlfSlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBvdmVybGF5IGNsb3NlZCDigJQgYW5kIGFcXG5yZS1vcGVuZWQgZWRpdG9yIHNob3dlZCB0aGUgU0FWRUQgYnl0ZXMuIEFmdGVyIHJlbG9hZCB0aGUgcmVwb3J0IHJlbmRlcmVkIHRoZVxcbmRvdWJsZWQgZmlndXJlICg0MDksOTk0IOKGkiA4MTksOTg4KTogdGhlIHNhdmUgbGFuZGVkIGluIHRoZSBjb3JwdXMgbW91bnQgYW5kIHRoZVxcbnJlcG9ydCdzIHJlLXJlYWQgc2VlcyBpdC4gVGhlIG9yaWdpbmFsIGJ5dGVzIHdlcmUgc2F2ZWQgYmFjayBhbmQgdGhlIHJlcG9ydFxcbnJlLXZlcmlmaWVkIGF0IDQwOSw5OTQgKHRoZSB2ZW51ZSBkcml2ZSBpcyBieXRlLW5ldC16ZXJvOyB0aGUgY29ycHVzIHJlcG8gaXRzZWxmXFxubmV2ZXIgcmVjZWl2ZXMgdGhlIHdyaXRlIOKAlCB0aGUgQ29XIG92ZXJsYXkgaXMgdGhlIHNhdmUgdGFyZ2V0LCBSQ0Qgwqc1LjEgYXNcXG5kaXNjbG9zZWQpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRy1ETi1CNSBsaXZlICh0aGUgY2FuY2VsIGNoYW5uZWwsIG9uIHRoZSBydyBzaGFwZSk6IFBBU1MuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIERpc21pc3NpbmcgdGhlIGVkaXRvclxcbihDYW5jZWwpIGlzIHNpbGVudCDigJQgbm8gbm90aWNlIOKAlCBhbmQgZG9lcyBOT1QgbGF0Y2ggdGhlIGRvb3IgKHRoZSBjaGlwcyBzdGF5XFxucmVuZGVyZWQsIG1hdGNoaW5nIHRoZSDCpzQuMiBsYXRjaCdzIG1vdW50LXN0YXRlIGtleWluZykuIFRoZSBmb3JiaWRkZW4gY2hhbm5lbFxcbnBhc3NlZCBsaXZlIDIwMjYtMDktMjIgKGFib3ZlKSBhbmQgaXMgdW5jaGFuZ2VkIGJ5IHRoZSBydyBzaGFwZS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkctRE4tQjkgbGl2ZSAoc3RhbGVuZXNzICsgcmVsb2FkKTogUEFTUy5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhlIHNhdmUgZmxpcHBlZCB0aGUgwqc0LjQgc2lnbmFsOiB0aGVcXG5ub3RpY2UgcmVuZGVyZWQgKFxcXCJUaGUgbW91bnRlZCBkb2N1bWVudCBjaGFuZ2VkIGFmdGVyIHRoaXMgcmVwb3J0IHdhcyByZW5kZXJlZCDigJQgdGhlXFxuZmlndXJlcyBiZWxvdyBhcmUgc3RhbGUuXFxcIikgd2l0aCB0aGUgUmVsb2FkIGFmZm9yZGFuY2UsIGFuZCBSZWxvYWQgcmUtcmVhZCB0aGVcXG5kb2N1bWVudCB0aHJvdWdoIHRoZSBzYW1lIG1vdW50IHJlc29sdXRpb24gKHRoZSBkb3VibGVkIHZhbHVlIHJlbmRlcmVkKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkctRE4tQjYgbGl2ZSBvbiB0aGUgcncgc2hhcGU6IFBBU1MgKHJlLXJ1bikuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIEJvdGggXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZWRpdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgY2hpcHMgcmVuZGVyIGJlc2lkZSB0aGVcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJmaWxlOmxpbmVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFuY2hvcnMgd2l0aCB0aGUgUkNEIMKnNS4xIGRpc2Nsb3N1cmUgb24gdGhlIHRpdGxlIEFORCB0aGUgbm90ZSBsaW5lLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJFdmVyeSBQYXJ0IEIgZ2F0ZSBpcyBub3cgY292ZXJlZDogdGhlIGdhdGVzIHdob3NlIGV2aWRlbmNlIGlzIGhvc3QgcXVlc3Rpb25zXFxuKFAx4oCTUDQsIGVzdGFibGlzaGVkIGxpdmUgMjAyNi0wOS0yMikgYmFjayBCMeKAk0I0LCBCNiBhbmQgQjEwOyBCNC9CNS9CNi9COSBoYXZlIHRoZVxcbmxpdmUgdmVudWUgbGVncyByZWNvcmRlZCBoZXJlIGFuZCBvbiAyMDI2LTA5LTIyOyBCMeKAk0IzLCBCNywgQjggYW5kIEIxMCBjYXJyeSB0aGVpclxcbnVuaXQgaGFsdmVzIHBlciB0aGUgdGFibGUgYWJvdmUuIEI1J3MgdGhyZWUgbmFtZWQgZWxlbWVudHMgYmV5b25kIHRoZSB0aHJvd25cXG5jaGFubmVsczogdGhlIHJlc3VsdC1jYXJyaWVkIFwifTxfY29tcG9uZW50cy5jb2RlPntcIntzYXZlZDpmYWxzZX1cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHJlZnVzYWwgaXMgbGl2ZS11bmV4ZXJjaXNlZCAobm9cXG5zaGlwcGVkIGNhbGxlZSBwYXRoIHByb2R1Y2VzIGl0IOKAlCBjYW5jZWwgdGhyb3dzIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNhbmNlbGxlZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGFuIFwifTxfY29tcG9uZW50cy5jb2RlPntcInJvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBtb3VudCBuZXZlclxcbnJlbmRlcnMgdGhlIGRvb3IpIGJ1dCB1bml0LWFzc2VydGVkIGRpcmVjdGx5IG9uIGl0cyBvd24gwqc0LjIgYnJhbmNoXFxuKFwifTxfY29tcG9uZW50cy5jb2RlPntcInVzZUVkaXRGaWxlLnRlc3QudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgdGhlIFJFRlVTRURfTUVTU0FHRSArIG1vdW50LXN0YXRlIGxhdGNoIGNhc2UpO1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcIm5vLXN1Y2gtdGFza1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYW5kIFwifTxfY29tcG9uZW50cy5jb2RlPntcInRpbWVvdXRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHdlcmUgbmV2ZXIgb2JzZXJ2ZWQgbGl2ZSBhbmQgcmlkZSB0aGUgwqc0LjIgZ2VuZXJpY1xcbm5hbWUtdGhlLWNvZGUgYnJhbmNoLCBwcm94aWVkIHVuaXQtc2lkZSBieSB0aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widGltZW91dFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgY2FzZVxcbihcIn08X2NvbXBvbmVudHMuY29kZT57XCJ1c2VFZGl0RmlsZS50ZXN0LnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLlwifTwvX2NvbXBvbmVudHMucD48Lz47XG59XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNRFhDb250ZW50KHByb3BzID0ge30pIHtcbiAgY29uc3Qge3dyYXBwZXI6IE1EWExheW91dH0gPSB7XG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9O1xuICByZXR1cm4gTURYTGF5b3V0ID8gPE1EWExheW91dCB7Li4ucHJvcHN9PjxfY3JlYXRlTWR4Q29udGVudCB7Li4ucHJvcHN9IC8+PC9NRFhMYXlvdXQ+IDogX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpO1xufVxuZnVuY3Rpb24gX21pc3NpbmdNZHhSZWZlcmVuY2UoaWQsIGNvbXBvbmVudCwgcGxhY2UpIHtcbiAgdGhyb3cgbmV3IEVycm9yKFwiRXhwZWN0ZWQgXCIgKyAoY29tcG9uZW50ID8gXCJjb21wb25lbnRcIiA6IFwib2JqZWN0XCIpICsgXCIgYFwiICsgaWQgKyBcImAgdG8gYmUgZGVmaW5lZDogeW91IGxpa2VseSBmb3Jnb3QgdG8gaW1wb3J0LCBwYXNzLCBvciBwcm92aWRlIGl0LlwiICsgKHBsYWNlID8gXCJcXG5JdOKAmXMgcmVmZXJlbmNlZCBpbiB5b3VyIGNvZGUgYXQgYFwiICsgcGxhY2UgKyBcImAgaW4gYC9hcHAvZG9jcy9zdGF0dXMvRE9DVU1FTlRfTkFWSUdBVE9SX1NUQVRVUy5tZGBcIiA6IFwiXCIpKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQXdGLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUZ4RjtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU1DLFdBQVcsR0FBRztNQUNsQkMsSUFBSSxFQUFFLE1BQU07TUFDWkMsR0FBRyxFQUFFLEtBQUs7TUFDVkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsR0FBRyxFQUFFLEtBQUs7TUFDVkMsTUFBTSxFQUFFLFFBQVE7TUFDaEJDLEtBQUssRUFBRSxPQUFPO01BQ2RDLEtBQUssRUFBRSxPQUFPO01BQ2RDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEtBQUssRUFBRSxPQUFPO01BQ2RDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1IsR0FBRyxJQUFBQyw2QkFBa0IsRUFBQyxDQUFDO01BQ3ZCLEdBQUduQixLQUFLLENBQUNvQjtJQUNYLENBQUM7SUFBRTtNQUFDQztJQUFhLENBQUMsR0FBR3BCLFdBQVc7RUFDaEMsSUFBSSxDQUFDb0IsYUFBYSxFQUFFQyxvQkFBb0IsQ0FBQyxlQUFlLEVBQUUsSUFBSSxDQUFDO0VBQy9ELG9CQUFPLElBQUF4QixXQUFBLENBQUF5QixJQUFBLEVBQUF6QixXQUFBLENBQUEwQixRQUFBO0lBQUFDLFFBQUEsZ0JBQUUsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0ksRUFBRTtNQUFDcUIsRUFBRSxFQUFDLDBDQUEwQztNQUFBRCxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQTBDLENBQUUsQ0FBQyxFQUFDLDRDQUE0QztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1EsQ0FBQztNQUFBZ0IsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFTLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBNEksQ0FBcUIsQ0FBQyxFQUFDLE1BQU0sZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFVLENBQXFCLENBQUMsRUFBQyxhQUFhO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDUSxDQUFDO01BQUFnQixRQUFBLEdBQUUsZ0VBQWdFLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQXVDLENBQW1CLENBQUMsRUFBQywrQ0FBK0M7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNLLEVBQUU7TUFBQ29CLEVBQUUsRUFBQyxvREFBb0Q7TUFBQUQsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFvRCxDQUFFLENBQUMsRUFBQyx3REFBd0Q7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNpQixFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBdUIsQ0FBbUIsQ0FBQyxFQUFDLDRPQUE0TyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFlLENBQW1CLENBQUMsRUFBQyxpQkFBaUI7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNPLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQStCLENBQW1CLENBQUMsRUFBQyw0R0FBNEc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNPLEVBQUU7UUFBQWlCLFFBQUEsR0FBRSxhQUFhLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQTJCLENBQW1CLENBQUMsRUFBQyxxQ0FBcUMsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBVSxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFnQixDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyxJQUFJO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNNLEVBQUU7TUFBQ21CLEVBQUUsRUFBQyxlQUFlO01BQUFELFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBZSxDQUFFLENBQUMsRUFBQyxlQUFlO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDVyxLQUFLO01BQUFhLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2UsS0FBSztRQUFBUyxRQUFBLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2dCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDYyxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFNLENBQWlCLENBQUMsbUJBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNjLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQU0sQ0FBaUIsQ0FBQztRQUFBLENBQWdCO01BQUMsQ0FBbUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksS0FBSztRQUFBWSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNnQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBUyxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQTRCLENBQW1CLENBQUMsRUFBQyxnQkFBZ0IsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLHdCQUF3QjtVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDZ0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQVMsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEdBQUUsbUNBQW1DLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQU8sQ0FBbUIsQ0FBQyxFQUFDLHVDQUF1QyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFHLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQUcsQ0FBbUIsQ0FBQyxFQUFDLE9BQU8sZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBaUIsQ0FBbUIsQ0FBQztVQUFBLENBQWdCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDZ0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQVMsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEdBQUUsU0FBUyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQU8sQ0FBcUIsQ0FBQyxFQUFDLDhCQUE4QixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFlLENBQW1CLENBQUMsRUFBQyw0QkFBNEIsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBa0IsQ0FBbUIsQ0FBQyxFQUFDLHVIQUF1SDtVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDZ0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQVMsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEdBQUUsU0FBUyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFTLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQVMsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBWSxDQUFtQixDQUFDLEVBQUMsc0NBQXNDO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNnQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBUyxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQW9DLENBQW1CLENBQUMsRUFBQyx5Q0FBeUM7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2dCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFTLENBQWlCLENBQUMsbUJBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxHQUFFLHdCQUF3QixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFhLENBQW1CLENBQUM7VUFBQSxDQUFnQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQztNQUFBLENBQW1CLENBQUM7SUFBQSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNRLENBQUM7TUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBc0QsQ0FBcUIsQ0FBQyxFQUFDLDJLQUEySyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFPLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQUssQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBUSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFRLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQVcsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBVyxDQUFtQixDQUFDLEVBQUMsWUFBWSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFlLENBQW1CLENBQUMsRUFBQyxhQUFhO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDTSxFQUFFO01BQUNtQixFQUFFLEVBQUMseUJBQXlCO01BQUFELFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBeUIsQ0FBRSxDQUFDLEVBQUMseUJBQXlCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDaUIsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNPLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBMkMsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBZ0MsQ0FBbUIsQ0FBQyxFQUFDLG9CQUFvQixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNHLEVBQUU7VUFBQXFCLFFBQUEsRUFBRTtRQUF5QixDQUFpQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFzQixDQUFtQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFTLENBQW1CLENBQUMsRUFBQyxnRkFBZ0YsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBYSxDQUFtQixDQUFDLEVBQUMsU0FBUyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFRLENBQW1CLENBQUMsRUFBQyxlQUFlLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQWdCLENBQW1CLENBQUMsRUFBQyxvSEFBb0gsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFRLENBQXFCLENBQUMsRUFBQyx5REFBeUQ7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNPLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBYyxRQUFBLEdBQUUsYUFBYSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7WUFBQXVCLFFBQUEsRUFBRTtVQUFNLENBQW1CLENBQUMsRUFBQyxRQUFRO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLG9GQUFvRixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQU0sQ0FBbUIsQ0FBQyxFQUFDLHlDQUF5QyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNHLEVBQUU7VUFBQXFCLFFBQUEsRUFBRTtRQUFNLENBQWlCLENBQUMsRUFBQyxxQkFBcUIsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBSSxDQUFtQixDQUFDLEVBQUMsc0ZBQXNGLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBYyxRQUFBLEdBQUUseUJBQXlCLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtZQUFBdUIsUUFBQSxFQUFFO1VBQU0sQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1lBQUF1QixRQUFBLEVBQUU7VUFBTSxDQUFtQixDQUFDLEVBQUMsNkJBQTZCO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLCtDQUErQztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDSyxFQUFFO01BQUNvQixFQUFFLEVBQUMsNkVBQTZFO01BQUFELFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBNkUsQ0FBRSxDQUFDLEVBQUMsbUZBQW1GO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDUSxDQUFDO01BQUFnQixRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQXFELENBQXFCLENBQUMsRUFBQywrUkFBK1I7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNXLEtBQUs7TUFBQWEsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDZSxLQUFLO1FBQUFTLFFBQUEsZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDZ0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNjLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQUcsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBc0MsQ0FBaUIsQ0FBQztRQUFBLENBQWdCO01BQUMsQ0FBbUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksS0FBSztRQUFBWSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNnQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBSSxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQWlCLENBQW1CLENBQUMsRUFBQywwQkFBMEIsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBSSxDQUFtQixDQUFDLEVBQUMsVUFBVSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNVLE1BQU07Y0FBQWMsUUFBQSxHQUFFLFlBQVksZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2dCQUFBdUIsUUFBQSxFQUFFO2NBQWdCLENBQW1CLENBQUMsRUFBQyxPQUFPO1lBQUEsQ0FBcUIsQ0FBQyxFQUFDLHNCQUFzQixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFnRCxDQUFtQixDQUFDLEVBQUMsbUNBQW1DLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQWEsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBUyxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFTLENBQW1CLENBQUMsRUFBQyxnREFBZ0QsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBSSxDQUFtQixDQUFDLEVBQUMsMkNBQTJDLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBYSxDQUFxQixDQUFDLEVBQUMsVUFBVSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFtQixDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFVLENBQW1CLENBQUMsRUFBQywyREFBMkQsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBUyxDQUFtQixDQUFDLEVBQUMsZ0JBQWdCLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQVcsQ0FBbUIsQ0FBQyxFQUFDLDZJQUE2STtVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDZ0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQUksQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEdBQUUsWUFBWSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNVLE1BQU07Y0FBQWMsUUFBQSxHQUFFLFVBQVUsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2dCQUFBdUIsUUFBQSxFQUFFO2NBQU0sQ0FBbUIsQ0FBQztZQUFBLENBQW9CLENBQUMsRUFBQyxzQkFBc0IsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBTSxDQUFtQixDQUFDLEVBQUMsK0lBQStJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtjQUFBYyxRQUFBLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtnQkFBQXVCLFFBQUEsRUFBRTtjQUFhLENBQW1CO1lBQUMsQ0FBb0IsQ0FBQyxFQUFDLGdFQUFnRSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNVLE1BQU07Y0FBQWMsUUFBQSxHQUFFLFdBQVcsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2dCQUFBdUIsUUFBQSxFQUFFO2NBQUksQ0FBbUIsQ0FBQyxFQUFDLFFBQVE7WUFBQSxDQUFxQixDQUFDLEVBQUMsNEZBQTRGLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQVMsQ0FBbUIsQ0FBQyxFQUFDLGlIQUFpSCxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFZLENBQW1CLENBQUMsRUFBQyxvQ0FBb0MsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBSSxDQUFtQixDQUFDLEVBQUMsZ0VBQWdFO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNnQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBSSxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBeUQsQ0FBcUIsQ0FBQyxFQUFDLDhDQUE4QyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFrQixDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFXLENBQW1CLENBQUMsRUFBQyxXQUFXLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQW9CLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQWMsQ0FBbUIsQ0FBQyxFQUFDLHNDQUFzQyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFZLENBQW1CLENBQUMsRUFBQyxrQkFBa0IsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBTyxDQUFtQixDQUFDLEVBQUMsZUFBZSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFXLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQVcsQ0FBbUIsQ0FBQyxFQUFDLHlLQUF5SztVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDZ0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQUksQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQTJCLENBQXFCLENBQUMsRUFBQyw4QkFBOEIsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBVyxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFzQixDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFvQixDQUFtQixDQUFDLEVBQUMsWUFBWSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFhLENBQW1CLENBQUMsRUFBQyxpTkFBaU4sZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBUyxDQUFtQixDQUFDLEVBQUMsZ0ZBQWdGO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNnQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBSSxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBZ0QsQ0FBcUIsQ0FBQyxFQUFDLDBFQUEwRSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFzQixDQUFtQixDQUFDLEVBQUMsVUFBVSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUE4QixDQUFtQixDQUFDLEVBQUMsNE1BQTRNLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBaUMsQ0FBcUIsQ0FBQyxFQUFDLDBGQUEwRixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQXdDLENBQXFCLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQVcsQ0FBbUIsQ0FBQyxFQUFDLHNIQUFzSDtVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDO01BQUEsQ0FBbUIsQ0FBQztJQUFBLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1EsQ0FBQztNQUFBZ0IsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFpQixDQUFxQixDQUFDLEVBQUMsdURBQXVELGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQWdCLENBQW1CLENBQUMsRUFBQywwQkFBMEIsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBZSxDQUFtQixDQUFDLEVBQUMsc0JBQXNCLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQWEsQ0FBbUIsQ0FBQyxFQUFDLHFKQUFxSixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUF1QixDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFrQixDQUFtQixDQUFDLEVBQUMsVUFBVSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFTLENBQW1CLENBQUMsRUFBQyxnQ0FBZ0MsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBYSxDQUFtQixDQUFDLEVBQUMsb0xBQW9MLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBbUIsQ0FBcUIsQ0FBQyxFQUFDLGtIQUFrSDtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDbUIsRUFBRSxFQUFDLGlCQUFpQjtNQUFBRCxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQWlCLENBQUUsQ0FBQyxFQUFDLGVBQWU7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNXLEtBQUs7TUFBQWEsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDZSxLQUFLO1FBQUFTLFFBQUEsZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDZ0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNjLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQU0sQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBTSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0I7TUFBQyxDQUFtQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDWSxLQUFLO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2dCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFTLENBQWlCLENBQUMsbUJBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBa0IsQ0FBbUIsQ0FBQyxFQUFDLGlIQUFpSDtVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDZ0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQVMsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFxQixDQUFtQixDQUFDLEVBQUMsaUNBQWlDLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQUksQ0FBbUIsQ0FBQyxFQUFDLGtDQUFrQztVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDZ0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQVMsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUF1QixDQUFtQixDQUFDLEVBQUMseUNBQXlDLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQXFCLENBQW1CLENBQUMsRUFBQyxtREFBbUQ7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2dCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFTLENBQWlCLENBQUMsbUJBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBcUIsQ0FBbUIsQ0FBQyxFQUFDLHlNQUF5TTtVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDZ0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQVMsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFxQixDQUFtQixDQUFDLEVBQUMsMkJBQTJCLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQVcsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBVyxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFTLENBQW1CLENBQUMsRUFBQyx1QkFBdUIsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBZSxDQUFtQixDQUFDLEVBQUMsb0RBQW9EO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNnQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBUyxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQXlCLENBQW1CLENBQUMsRUFBQyxxSkFBcUo7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2dCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFTLENBQWlCLENBQUMsbUJBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBdUIsQ0FBbUIsQ0FBQyxFQUFDLHNCQUFzQixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFxQixDQUFtQixDQUFDLEVBQUMscUJBQXFCLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQVMsQ0FBbUIsQ0FBQztVQUFBLENBQWdCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDZ0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQVMsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEdBQUUsbUJBQW1CLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQXdCLENBQW1CLENBQUMsRUFBQyw4QkFBOEIsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBcUIsQ0FBbUIsQ0FBQyxFQUFDLHlCQUF5QjtVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDZ0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQVMsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFnQyxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFvQixDQUFtQixDQUFDLEVBQUMsb0NBQW9DO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNnQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBVSxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQWMsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBUyxDQUFtQixDQUFDLEVBQUMsa0VBQWtFO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUM7TUFBQSxDQUFtQixDQUFDO0lBQUEsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDUSxDQUFDO01BQUFnQixRQUFBLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1UsTUFBTTtRQUFBYyxRQUFBLEdBQUUsdURBQXVELGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLG1UQUFtVDtNQUFBLENBQXFCO0lBQUMsQ0FBZSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNLLEVBQUU7TUFBQ29CLEVBQUUsRUFBQyxnQkFBZ0I7TUFBQUQsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFnQixDQUFFLENBQUMsRUFBQyxnQkFBZ0I7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNRLENBQUM7TUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1UsTUFBTTtRQUFBYyxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFZLENBQW1CLENBQUMsRUFBQyxtQkFBbUI7TUFBQSxDQUFxQixDQUFDLEVBQUMsa0JBQWtCLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQTBCLENBQW1CLENBQUMsRUFBQyxzRUFBc0UsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUE2QyxDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNFLEdBQUc7UUFBQXNCLFFBQUEsR0FBRSxtREFBbUQsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBTSxDQUFtQixDQUFDO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDVSxNQUFNO1FBQUFjLFFBQUEsR0FBRSwrRUFBK0UsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBWSxDQUFtQixDQUFDO01BQUEsQ0FBb0IsQ0FBQyxFQUFDLFNBQVMsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBa0MsQ0FBbUIsQ0FBQyxFQUFDLG9CQUFvQixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFvQixDQUFtQixDQUFDLEVBQUMscWFBQXFhLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQVcsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNRLENBQUM7TUFBQWdCLFFBQUEsR0FBRSxXQUFXLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQVksQ0FBbUIsQ0FBQyxFQUFDLGdWQUFnVjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDbUIsRUFBRSxFQUFDLHFFQUFxRTtNQUFBRCxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQXFFLENBQUUsQ0FBQyxFQUFDLHlFQUF5RTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1EsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLDRJQUE0SSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFXLENBQW1CLENBQUMsRUFBQyw4SUFBOEk7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNTLEdBQUc7TUFBQWUsUUFBQSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7UUFBQzBCLFNBQVMsRUFBQyxlQUFlO1FBQUFILFFBQUEsRUFBRTtNQUF5SSxDQUFtQjtJQUFDLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1EsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLHNCQUFzQixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFnRSxDQUFtQixDQUFDLEVBQUMscUNBQXFDLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQUssQ0FBbUIsQ0FBQyxFQUFDLDhDQUE4QyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFJLENBQW1CLENBQUMsRUFBQyx5Q0FBeUMsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLDRCQUE0QixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFpQixDQUFtQixDQUFDLEVBQUMsb0RBQW9ELGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQWEsQ0FBbUIsQ0FBQyxFQUFDLGdGQUFnRjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1EsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLGNBQWMsZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDVSxNQUFNO1FBQUFjLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQUksQ0FBbUIsQ0FBQyxFQUFDLDZEQUE2RDtNQUFBLENBQXFCLENBQUMsRUFBQyxtQ0FBbUMsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBYSxDQUFtQixDQUFDLEVBQUMsK0NBQStDLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQUksQ0FBbUIsQ0FBQyxFQUFDLE9BQU8sZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBUSxDQUFtQixDQUFDLEVBQUMsYUFBYSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFJLENBQW1CLENBQUMsRUFBQywyTEFBMkwsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFXLENBQXFCLENBQUMsRUFBQyxvREFBb0Q7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNNLEVBQUU7TUFBQ21CLEVBQUUsRUFBQyw2RkFBNkY7TUFBQUQsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUE2RixDQUFFLENBQUMsRUFBQyxtR0FBbUc7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNRLENBQUM7TUFBQWdCLFFBQUEsRUFBRTtJQUF3SSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNpQixFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFxQixDQUFxQixDQUFDLEVBQUMsZ0NBQWdDLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLGFBQWEsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBOEIsQ0FBbUIsQ0FBQyxFQUFDLE9BQU8sZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBTSxDQUFtQixDQUFDLEVBQUMseUdBQXlHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDTyxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTZDLENBQXFCLENBQUMsRUFBQywwS0FBMEs7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNPLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBaUcsQ0FBcUIsQ0FBQyxFQUFDLDBCQUEwQixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUE2RyxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQThELENBQXFCLENBQUMsRUFBQyx1RUFBdUUsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRyxFQUFFO1VBQUFxQixRQUFBLEVBQUU7UUFBZSxDQUFpQixDQUFDLEVBQUMsWUFBWSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFvQixDQUFtQixDQUFDLEVBQUMsNkJBQTZCLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBTyxDQUFxQixDQUFDLEVBQUMsb1FBQW9RLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQyxFQUFDLHVEQUF1RCxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTBILENBQXFCLENBQUMsRUFBQyxnUEFBZ1AsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUF5QixDQUFxQixDQUFDLEVBQUMsR0FBRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDTSxFQUFFO01BQUNtQixFQUFFLEVBQUMsa0hBQWtIO01BQUFELFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBa0gsQ0FBRSxDQUFDLEVBQUMsNEhBQTRIO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDUSxDQUFDO01BQUFnQixRQUFBLEdBQUUsc0dBQXNHLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQXdDLENBQW1CLENBQUMsRUFBQywwQ0FBMEMsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFJLENBQXFCLENBQUMsRUFBQywyRUFBMkU7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNpQixFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFzRCxDQUFxQixDQUFDLEVBQUMsK0dBQStHLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQUksQ0FBbUIsQ0FBQyxFQUFDLCtKQUErSixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTBCLENBQXFCLENBQUMsRUFBQyx3QkFBd0IsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsU0FBUyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFxQyxDQUFtQixDQUFDLEVBQUMsMEVBQTBFLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQVUsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBTSxDQUFtQixDQUFDLEVBQUMsa09BQWtPLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQW9CLENBQW1CLENBQUMsRUFBQyx5Q0FBeUMsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFjLENBQXFCLENBQUMsRUFBQyxnQkFBZ0IsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBeUIsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBYSxDQUFtQixDQUFDLEVBQUMseUJBQXlCLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQVMsQ0FBbUIsQ0FBQyxFQUFDLHNCQUFzQixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFLLENBQW1CLENBQUMsRUFBQyxvQ0FBb0M7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNPLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBc0QsQ0FBcUIsQ0FBQyxFQUFDLHFCQUFxQixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUMsRUFBQyxtREFBbUQsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBNEIsQ0FBbUIsQ0FBQyxFQUFDLG1DQUFtQyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFPLENBQW1CLENBQUMsRUFBQywrQ0FBK0MsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBNEIsQ0FBbUIsQ0FBQyxFQUFDLGtiQUFrYjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUEyRCxDQUFxQixDQUFDLEVBQUMsd1BBQXdQO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDTyxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTBDLENBQXFCLENBQUMsRUFBQyx3UkFBd1I7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNPLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBOEMsQ0FBcUIsQ0FBQyxFQUFDLFFBQVEsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBTSxDQUFtQixDQUFDLEVBQUMsNEJBQTRCLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLHVFQUF1RTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDUSxDQUFDO01BQUFnQixRQUFBLEdBQUUsa1dBQWtXLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQWUsQ0FBbUIsQ0FBQyxFQUFDLG9GQUFvRixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFXLENBQW1CLENBQUMsRUFBQyxPQUFPLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQUksQ0FBbUIsQ0FBQyxFQUFDLHNGQUFzRixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFzQixDQUFtQixDQUFDLEVBQUMsb0RBQW9ELGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQWMsQ0FBbUIsQ0FBQyxFQUFDLE9BQU8sZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBUyxDQUFtQixDQUFDLEVBQUMsc0dBQXNHLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQVMsQ0FBbUIsQ0FBQyxFQUFDLFVBQVUsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBc0IsQ0FBbUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFnQixDQUFDO0VBQUEsQ0FBRSxDQUFDO0FBQ2hrOUI7QUFDZSxTQUFTSSxVQUFVQSxDQUFDN0IsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFO0VBQzdDLE1BQU07SUFBQzhCLE9BQU8sRUFBRUM7RUFBUyxDQUFDLEdBQUc7SUFDM0IsR0FBRyxJQUFBWiw2QkFBa0IsRUFBQyxDQUFDO0lBQ3ZCLEdBQUduQixLQUFLLENBQUNvQjtFQUNYLENBQUM7RUFDRCxPQUFPVyxTQUFTLGdCQUFHLElBQUFqQyxXQUFBLENBQUE2QixHQUFBLEVBQUNJLFNBQVM7SUFBQSxHQUFLL0IsS0FBSztJQUFBeUIsUUFBQSxlQUFFLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUM1QixpQkFBaUI7TUFBQSxHQUFLQztJQUFLLENBQUc7RUFBQyxDQUFXLENBQUMsR0FBR0QsaUJBQWlCLENBQUNDLEtBQUssQ0FBQztBQUNsSDtBQUFDZ0MsRUFBQSxHQU51QkgsVUFBVTtBQU9sQyxTQUFTUCxvQkFBb0JBLENBQUNJLEVBQUUsRUFBRU8sU0FBUyxFQUFFQyxLQUFLLEVBQUU7RUFDbEQsTUFBTSxJQUFJQyxLQUFLLENBQUMsV0FBVyxJQUFJRixTQUFTLEdBQUcsV0FBVyxHQUFHLFFBQVEsQ0FBQyxHQUFHLElBQUksR0FBR1AsRUFBRSxHQUFHLG9FQUFvRSxJQUFJUSxLQUFLLEdBQUcscUNBQXFDLEdBQUdBLEtBQUssR0FBRyxzREFBc0QsR0FBRyxFQUFFLENBQUMsQ0FBQztBQUNoUjtBQUFDLElBQUFGLEVBQUE7QUFBQUksWUFBQSxDQUFBSixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}