var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      code: "code",
      del: "del",
      em: "em",
      h1: "h1",
      h2: "h2",
      h3: "h3",
      li: "li",
      p: "p",
      pre: "pre",
      strong: "strong",
      table: "table",
      tbody: "tbody",
      td: "td",
      th: "th",
      thead: "thead",
      tr: "tr",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "document_navigator-implementation-status",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "document_navigator-implementation-status"
      }), "DOCUMENT_NAVIGATOR — implementation status"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Status:"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Part A implemented (R3-446); Part B's contract established + build landed (R3-447)"
      }), " ·\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Updated:"
      }), " 2026-09-22"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["This document is the single implementation-status source for\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "docs/specs/DOCUMENT_NAVIGATOR_SPEC.md"
      }), "; where they disagree, this document governs."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "part-a-the-authoring-vocabulary-shipped-2026-08-28",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "part-a-the-authoring-vocabulary-shipped-2026-08-28"
      }), "Part A — the authoring vocabulary (shipped 2026-08-28)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/app/vocabulary.ts"
        }), " — the pure derivation: every catalog entry with its typed\nattributes (base + per-variant, variant-labelled) and a usage snippet built per the\nspec's §1.1 per-shape rules (variant discriminators, child rules, the Show*\nthresholds, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "literal-array"
        }), " placeholders)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/app/VocabularySection.tsx"
        }), " — the panel section: collapsible per entry, a\nwidgets/display/all filter, and a guarded copy affordance."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["Wired into ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/app/WorkbookPanel.tsx"
        }), "; the report header button is now\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Workbook"
        }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Close workbook"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/App.tsx"
        }), ")."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "gate-coverage",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "gate-coverage"
      }), "Gate coverage"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Gate"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Test"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-A1"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/app/vocabulary.test.ts"
            }), " — enumerates ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "componentNames"
            }), ", never a literal list"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-A2"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["same — widget/container markers; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "Chart"
            }), "'s discriminator and its per-variant ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "x"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "y"
            }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "histogram.value"
            })]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-A3"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["same — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "every"
            }), " snippet parsed by the real ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "parseTemplate"
            }), " and run through the real ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "validateTemplate"
            }), ", asserting zero error diagnostics, one test per catalog entry (19 of them) so a future entry cannot regress silently"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-A4"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["same — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "widgets"
            }), " = ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "WIDGETS"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "components"
            }), " = its exact complement, unset = all"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-A5"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/app/VocabularySection.test.tsx"
            }), " — static render with no host transport"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-A6"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["the header strings in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/App.tsx"
            })]
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "All 19 snippets validate on the first implementation"
      }), " — the spec's §1.1 per-shape\nrules were sufficient, including the seven entries the adversarial pass identified as\nimpossible under the draft's attribute-only recipe (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "Chart"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "Map"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "Facets"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "Params"
      }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ShowAbove"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ShowBelow"
      }), ", and the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "literal-array"
      }), " carriers)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "also-landed-with-part-a",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "also-landed-with-part-a"
      }), "Also landed with Part A"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "A platform guard against the DN-R5 hazard"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/app/platformGuards.test.ts"
        }), "): no\nmodule may ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "statically value-import"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "@immediately-run/sdk"
        }), " or ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "…/tasks"
        }), ", which\nregister a host listener at module load and throw with no transport. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "import type"
        }), ",\nthe ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "mounts"
        }), " subpath and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "await import()"
        }), " are all correctly not matched — proven by\nfault injection over five cases, not by inspection. This guard exists ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "before"
        }), " Part B\nneeds it, so the mistake cannot be made later."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["A lint-red ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "main"
          }), " fixed"]
        }), " — R3-427 shipped an unused-binding error because the\nverification command piped ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npm run lint"
        }), " into ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "tail"
        }), ", and a pipeline's exit status is\nthe ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "last"
        }), " command's, so the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "&&"
        }), " chain continued past a failing gate. Fixed here, and\nthe lesson is worth keeping: ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["never pipe a gate into ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "tail"
          }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "head"
          }), " in a chained\nverification"]
        }), " — capture to a file and check the exit code."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "part-b-the-edit-affordance-r3-447-the-contract-established-the-build-landed",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "part-b-the-edit-affordance-r3-447-the-contract-established-the-build-landed"
      }), "Part B — the edit affordance (R3-447: the contract established, the build landed)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Phase 1 — the preconditions, established 2026-09-22"
      }), " (the worker-VM agent venue:\ncurrent-main dev host + staging backend/Firestore, the real repo-load dispatch, a\nworkbook corpus repo dispatched by URL; browser-driven observation off the live\nchannel, per the spec's rule — an injected port cannot falsify a question about the\nhost):"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "#"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Answer (with how it was established)"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "P1"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["A ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "type: 'content'"
            }), " dispatch mount carries ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "id"
            }), " in the ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
              children: ["universal ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                children: "scheme:locator"
              }), " form"]
            }), " — observed live as ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "content:immediately-run-worker/r3-447-workbook"
            }), " (the frame's own mount service, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "getMounts()"
            }), "). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "capFile"
            }), "'s ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "mountId"
            }), " is therefore addressed with the descriptor's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "id"
            }), " verbatim; the host's grant lookup is an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "exact match"
            }), " on it (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "taskInvocation.ts"
            }), " → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "grantFor"
            }), "), and no fallback is documented — a path-shaped or bare ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "mountId"
            }), " would refuse ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "forbidden"
            }), ", which is why the door fails closed on an id-less mount rather than making a doomed call. The unqualified form is not what the host mints."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "P2"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["The mount ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
              children: ["reports ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                children: "mode"
              })]
            }), " — observed live as ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "'rw'"
            }), " on the repo-load dispatch (writes land in the corpus mount; proposing back to the source repo stays unwired, the RCD §5.1 disclosure) — and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                children: "rules: null"
              })
            }), " (no rules). The editability derivation therefore keys on the ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
              children: ["positive ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                children: "rw"
              }), " check"]
            }), " R-EFE-1 prescribes; the draft's \"absent ⇒ writable\" inversion (DN-R2) is dead, and the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "subtree"
            }), "-comparability question (DN-R3) dissolves — there are no rules to compare. This repo's dispatch fixtures stamp ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "mode: 'ro'"
            }), "; the live repo-load mount stamps ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "rw"
            }), " — the fixtures model the task-invocation shape, not this one."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "P3"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Both channels are real and shaped as §4.2 handles them."
            }), " Documented half (the host's task contract, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "taskContracts.ts"
            }), "): ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "edit-file"
            }), " returns ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "{ saved: boolean }"
            }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "saved: false"
            }), " is the result-carried refusal, and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "invokeTask"
            }), " throws machine ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: ".code"
            }), " rejections (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "cancelled"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "forbidden"
            }), ", …). Live half (a real invocation from the dispatched frame): exercised by the gates below — it required P4's grant first, which is the sequencing finding, not a gap."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "P4"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "NO — and deliberately so."
            }), " The build-default binding (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "site-main"
            }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "registry/defaults.ts"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "task.open-workbook"
            }), ") omitted ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "task:invoke"
            }), " with a comment naming this milestone as the moment to add it; the frame's live grant-filtered catalog carried no task verb. The grant half is site-main's R3-447 registry diff (this milestone); the manifest ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "invokes"
            }), " declaration (this repo) is the self-restriction half — G-DN-B10 asserts both."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "P5"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "The dispatched shape is reachable and renders."
            }), " Driven live: a workbook corpus repo (the Meridian seed as real files + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "immediately.run.json"
            }), " marker ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "opensWith: open-workbook@1.0"
            }), ") dispatched by URL through the real repo-load branch — stock reckoner from the registry binding rendered the report (nav, growth-composition sections, the workbook panel). The honest sequencing notes: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "no workbook corpus repo existed"
            }), " (the corpus is content work, not platform work — the spike's corpus is temporary), and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "no user-facing caller invokes the task"
            }), " (the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "opensWith"
            }), " marker's only reader is the URL route; the folder-trigger caller is R3-267) — the URL route is the reachable shape."]
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Phase 2 — built"
      }), " (the same item): the inspector's per-row edit door (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ValueInspector"
      }), "),\nthe §4.3 path gate (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "documentPaths"
      }), "), the door itself (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "useEditFile"
      }), " — lazy import, both\nrefusal channels, the session-scoped latch, the host-less no-op, the §4.4 staleness\nsignal), the staleness notice + reload (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "DocumentChangedNotice"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "useReport.reload"
      }), "),\nthe ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "invokes"
      }), " declaration, and site-main's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "task:invoke"
      }), " grant. Q6 (the consumer\ninspector's door) resolves per the item's own Phase-2 surface (\"the inspector's formula\nand test rows\"); Q3 (reload vs change-watch) resolves to the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "reload affordance"
      }), " — a\nchange-watch needs an fs watch the task-delegated export does not carry\n(SPACES_UI §6.6 / R3-732's seam)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "gate-coverage-1",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "gate-coverage-1"
      }), "Gate coverage"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Gate"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Test"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-B1"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "dispatch.test.ts"
            }), " — the ok resolution carries the live mount (id/mode provenance); the live descriptor read on the venue (above)"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-B2"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "useEditFile.test.ts"
            }), " — writability by the positive ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "rw"
            }), " check (ro/absent are not doors)"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-B3"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "documentPaths.test.ts"
            }), " — segment-boundary traversal refusal; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "useEditFile.test.ts"
            }), " — a failing path never constructs the delegation"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-B4"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "useEditFile.test.ts"
            }), " — the call addresses the descriptor id (universal form); an id-less mount is not a door (fail-closed — the host's exact-match grant lookup has no documented fallback); the live invocation gate below"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-B5"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "useEditFile.test.ts"
            }), " — both channels: thrown ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "cancelled"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "forbidden"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "timeout"
            }), ", the result-carried ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "{saved:false}"
            }), " refusal, the host-less no-op; the live gate below"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-B6"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "ValueInspector.test.tsx"
            }), " — absent unless writable (per row), present beside both anchors, the disclosure at the button, the click hands the row's path; the live gate below"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-B7"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "documentPaths.test.ts"
            }), " — traversal-shaped ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "manifest.worksheets"
            }), " paths never reach ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "capFile"
            })]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-B8"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["the pre-existing ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "platformGuards.test.ts"
            }), " (no static tasks import) + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "useEditFile.test.ts"
            }), "'s host-less no-op case"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-B9"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "DocumentChangedNotice.test.tsx"
            }), " + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "useReport.test.tsx"
            }), " (the reload); the live gate below"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-B10"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "package.json"
            }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "invokes"
            }), " (this repo) + site-main's registry diff and its exact-list test"]
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["The host-exercised halves (P1–P4's live legs: a real ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "edit-file"
        }), " invocation from the\ndispatched frame — the door visible on the dispatched shape, the overlay opening, both\nrefusal channels observed on the real gate, the staleness affordance after a save) run\non the venue against the merged mains before R3-447 archives; the unit halves above are\nin-repo and green."]
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "open-residuals",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "open-residuals"
      }), "Open residuals"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "edit-table"
        }), " is now specified"]
      }), " (2026-08-29) — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "EDIT_TABLE_TASK_SPEC.mdx"
      }), " in the docs\nrepo, proposal rev 2 after an adversarial pass. It is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "blocked on P1–P5 above plus two\nof its own"
      }), " (", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.del, {
        children: ["P6: task-delegation mounts are announced with no ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "mode"
        })]
      }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["closed\n2026-09-29 by the R3-754 probe below: the delegation mount announces ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "mode: 'ro'"
        })]
      }), "\n(the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "min(caller grant, cap, contract)"
      }), " stamp, site-main ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "mintDelegations.ts"
      }), "), so the\nread-only rule IS implementable; P7: Reckoner has no fs watch, so the autosave safety argument\nhas no consumer). R3-447's host spike therefore unblocks both surfaces, not just\nPart B — worth knowing before scoping it. The 2026-08-29 review also confirmed the\nseed-vs-mount wall applies to fixtures exactly as it does to worksheets: on the\nbundled-seed path there is no file to delegate, only a string in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/seed/"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Spec §6 (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "edit-table"
      }), ", open-at-line, Delta B, click-to-insert, own-source editing) and\n§11 Q1–Q7 — including the two the review surfaced as real decisions rather than\ndeferrals: whether the consumer-visible inspector carries an authoring door (Q6), and\nthe template-file edit row without which \"copy the snippet, open the template\" has no\ndoor (Q7)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "the-second-dispatch-shapes-descriptor-r3-754-probed-live-2026-09-29",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-second-dispatch-shapes-descriptor-r3-754-probed-live-2026-09-29"
      }), "The second dispatch shape's descriptor (R3-754, probed live 2026-09-29)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Probed on the venue (staging composition, driven Chromium, the venue identity signed\nin): the corpus open in the editor, file-explorer's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "opensWith"
      }), " affordance on the\ncorpus root (\"Open as workbook\"), the task overlay running reckoner. The frame's own\nmount set, read from the callee:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-json",
        children: "{ \"id\": \"/task/task-1/dir\", \"path\": \"/task/task-1/dir\",\n  \"type\": \"task-delegation\", \"mode\": \"ro\", \"rules\": null }\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["with the task input ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "{ task: 'open-workbook', params: { dir: '/task/task-1/dir' } }"
      }), " —\nthe host REWRITES the caller's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "dir"
      }), " to the minted chroot path, and the mount's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "id"
      }), "\nis that same path (NOT the universal ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "scheme:locator"
      }), " form P1 established for\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "type: 'content'"
      }), " mounts — the two shapes address differently, and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "dispatch.ts"
      }), "'s\ntask branch addresses the delegation by the path-form id it arrives with)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The mode is ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ro"
        }), " even when the caller's session holds the corpus read-write"]
      }), " (the\nedit session's worktree): ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "panel.files"
      }), "'s published port of the worktree is itself\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ro"
      }), ", so ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "min(…)"
      }), " clamps to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ro"
      }), " regardless of the session's writability. The edit\ndoor therefore stays dark on every dispatch-driven open — by design, pending R3-797 —\nand the URL/task dispatch shapes are recorded ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "view-only"
      }), " (the owner's 2026-09-28\ndecision (c) on R3-754)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "the-live-gates-2026-09-22-the-venue-run-against-both-merged-mains-two-pass-one-is-a-finding",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-live-gates-2026-09-22-the-venue-run-against-both-merged-mains-two-pass-one-is-a-finding"
      }), "The live gates (2026-09-22, the venue run against BOTH merged mains) — two pass, one is a FINDING"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Driven on the worker-VM venue with site-main at 60ddd0a and reckoner@main at 2925fa4\n(both PRs merged), the corpus dispatched by URL:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "G-DN-B6 live: PASS."
        }), " The door renders beside both ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "file:line"
        }), " anchors\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "worksheets/review.sheet.js:3"
        }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ":107"
        }), ") on the dispatched shape, with the RCD\n§5.1 disclosure on the button title AND the visible note line."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "G-DN-B5 live (the forbidden channel): PASS."
        }), " A refused invocation draws exactly\none plain message (\"This document can't be edited here.\") and latches the door off —\nobserved live, matching §4.2 to the letter."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "G-DN-B4 live (the successful invocation): BLOCKED BY A FINDING, not a bug in this\nrepo's half."
        }), " The invocation refuses ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "forbidden — 'protocol-task.invoke' requires the 'task:invoke' capability; this app's grant does not hold it"
        }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "despite\nsite-main#584 being merged and the venue serving it"
        }), ". Root cause (code + live):\nthe URL repo-load dispatch resolves the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "viewer's repo"
        }), " from the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "task.open-workbook"
        }), "\nbinding, but the frame's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "grant"
        }), " is the preview/stage grant — the registry row's\ncapabilities never flow to the repo-load-dispatched frame. The task-invocation shape\n(where the binding's grant does apply) is unreachable twice over: no user-facing\ncaller exists (R3-267), and this repo's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "dispatch.ts"
        }), " v1 deliberately resolves only\nthe repo-load shape. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The affordance is therefore unreachable on both dispatch\nshapes — DN-R12's failure mode reborn at the invocation layer."
        }), " The fix is a\ndesign decision the owner owns (the repo-load dispatch minting the viewer's grant\nfrom the task binding; or the preview grant widening; or shipping the task-shape\ncaller); recorded in R3-447's roadmap status, which stays ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "in-progress, unarchived"
        }), "."]
      }), "\n"]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/status/DOCUMENT_NAVIGATOR_STATUS.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJjb2RlIiwiZGVsIiwiZW0iLCJoMSIsImgyIiwiaDMiLCJsaSIsInAiLCJwcmUiLCJzdHJvbmciLCJ0YWJsZSIsInRib2R5IiwidGQiLCJ0aCIsInRoZWFkIiwidHIiLCJ1bCIsIl9wcm92aWRlQ29tcG9uZW50cyIsImNvbXBvbmVudHMiLCJIZWFkaW5nQW5jaG9yIiwiX21pc3NpbmdNZHhSZWZlcmVuY2UiLCJqc3hzIiwiRnJhZ21lbnQiLCJjaGlsZHJlbiIsImlkIiwianN4IiwiY2xhc3NOYW1lIiwiTURYQ29udGVudCIsIndyYXBwZXIiLCJNRFhMYXlvdXQiLCJfYyIsImNvbXBvbmVudCIsInBsYWNlIiwiRXJyb3IiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJET0NVTUVOVF9OQVZJR0FUT1JfU1RBVFVTLm1kIl0sInNvdXJjZXNDb250ZW50IjpbIi8qQGpzeFJ1bnRpbWUgYXV0b21hdGljKi9cbi8qQGpzeEltcG9ydFNvdXJjZSByZWFjdCovXG5pbXBvcnQge3VzZU1EWENvbXBvbmVudHMgYXMgX3Byb3ZpZGVDb21wb25lbnRzfSBmcm9tIFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGsvTURYUHJvdmlkZXJcIjtcbmZ1bmN0aW9uIF9jcmVhdGVNZHhDb250ZW50KHByb3BzKSB7XG4gIGNvbnN0IF9jb21wb25lbnRzID0ge1xuICAgIGNvZGU6IFwiY29kZVwiLFxuICAgIGRlbDogXCJkZWxcIixcbiAgICBlbTogXCJlbVwiLFxuICAgIGgxOiBcImgxXCIsXG4gICAgaDI6IFwiaDJcIixcbiAgICBoMzogXCJoM1wiLFxuICAgIGxpOiBcImxpXCIsXG4gICAgcDogXCJwXCIsXG4gICAgcHJlOiBcInByZVwiLFxuICAgIHN0cm9uZzogXCJzdHJvbmdcIixcbiAgICB0YWJsZTogXCJ0YWJsZVwiLFxuICAgIHRib2R5OiBcInRib2R5XCIsXG4gICAgdGQ6IFwidGRcIixcbiAgICB0aDogXCJ0aFwiLFxuICAgIHRoZWFkOiBcInRoZWFkXCIsXG4gICAgdHI6IFwidHJcIixcbiAgICB1bDogXCJ1bFwiLFxuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfSwge0hlYWRpbmdBbmNob3J9ID0gX2NvbXBvbmVudHM7XG4gIGlmICghSGVhZGluZ0FuY2hvcikgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJIZWFkaW5nQW5jaG9yXCIsIHRydWUpO1xuICByZXR1cm4gPD48X2NvbXBvbmVudHMuaDEgaWQ9XCJkb2N1bWVudF9uYXZpZ2F0b3ItaW1wbGVtZW50YXRpb24tc3RhdHVzXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJkb2N1bWVudF9uYXZpZ2F0b3ItaW1wbGVtZW50YXRpb24tc3RhdHVzXCIgLz57XCJET0NVTUVOVF9OQVZJR0FUT1Ig4oCUIGltcGxlbWVudGF0aW9uIHN0YXR1c1wifTwvX2NvbXBvbmVudHMuaDE+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJTdGF0dXM6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiUGFydCBBIGltcGxlbWVudGVkIChSMy00NDYpOyBQYXJ0IEIncyBjb250cmFjdCBlc3RhYmxpc2hlZCArIGJ1aWxkIGxhbmRlZCAoUjMtNDQ3KVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDCt1xcblwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiVXBkYXRlZDpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgMjAyNi0wOS0yMlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGlzIGRvY3VtZW50IGlzIHRoZSBzaW5nbGUgaW1wbGVtZW50YXRpb24tc3RhdHVzIHNvdXJjZSBmb3JcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJkb2NzL3NwZWNzL0RPQ1VNRU5UX05BVklHQVRPUl9TUEVDLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjsgd2hlcmUgdGhleSBkaXNhZ3JlZSwgdGhpcyBkb2N1bWVudCBnb3Zlcm5zLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJwYXJ0LWEtdGhlLWF1dGhvcmluZy12b2NhYnVsYXJ5LXNoaXBwZWQtMjAyNi0wOC0yOFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwicGFydC1hLXRoZS1hdXRob3Jpbmctdm9jYWJ1bGFyeS1zaGlwcGVkLTIwMjYtMDgtMjhcIiAvPntcIlBhcnQgQSDigJQgdGhlIGF1dGhvcmluZyB2b2NhYnVsYXJ5IChzaGlwcGVkIDIwMjYtMDgtMjgpXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5jb2RlPntcInNyYy9hcHAvdm9jYWJ1bGFyeS50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIHRoZSBwdXJlIGRlcml2YXRpb246IGV2ZXJ5IGNhdGFsb2cgZW50cnkgd2l0aCBpdHMgdHlwZWRcXG5hdHRyaWJ1dGVzIChiYXNlICsgcGVyLXZhcmlhbnQsIHZhcmlhbnQtbGFiZWxsZWQpIGFuZCBhIHVzYWdlIHNuaXBwZXQgYnVpbHQgcGVyIHRoZVxcbnNwZWMncyDCpzEuMSBwZXItc2hhcGUgcnVsZXMgKHZhcmlhbnQgZGlzY3JpbWluYXRvcnMsIGNoaWxkIHJ1bGVzLCB0aGUgU2hvdypcXG50aHJlc2hvbGRzLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJsaXRlcmFsLWFycmF5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBwbGFjZWhvbGRlcnMpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5jb2RlPntcInNyYy9hcHAvVm9jYWJ1bGFyeVNlY3Rpb24udHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgdGhlIHBhbmVsIHNlY3Rpb246IGNvbGxhcHNpYmxlIHBlciBlbnRyeSwgYVxcbndpZGdldHMvZGlzcGxheS9hbGwgZmlsdGVyLCBhbmQgYSBndWFyZGVkIGNvcHkgYWZmb3JkYW5jZS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJXaXJlZCBpbnRvIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9hcHAvV29ya2Jvb2tQYW5lbC50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiOyB0aGUgcmVwb3J0IGhlYWRlciBidXR0b24gaXMgbm93XFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiV29ya2Jvb2tcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIC8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQ2xvc2Ugd29ya2Jvb2tcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvQXBwLnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCJnYXRlLWNvdmVyYWdlXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJnYXRlLWNvdmVyYWdlXCIgLz57XCJHYXRlIGNvdmVyYWdlXCJ9PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMudGFibGU+PF9jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGg+e1wiR2F0ZVwifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIlRlc3RcIn08L19jb21wb25lbnRzLnRoPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudGJvZHk+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJHLUROLUExXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2FwcC92b2NhYnVsYXJ5LnRlc3QudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCBlbnVtZXJhdGVzIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNvbXBvbmVudE5hbWVzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgbmV2ZXIgYSBsaXRlcmFsIGxpc3RcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJHLUROLUEyXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wic2FtZSDigJQgd2lkZ2V0L2NvbnRhaW5lciBtYXJrZXJzOyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJDaGFydFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIncyBkaXNjcmltaW5hdG9yIGFuZCBpdHMgcGVyLXZhcmlhbnQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wieFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wieVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYW5kIFwifTxfY29tcG9uZW50cy5jb2RlPntcImhpc3RvZ3JhbS52YWx1ZVwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJHLUROLUEzXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wic2FtZSDigJQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJldmVyeVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBzbmlwcGV0IHBhcnNlZCBieSB0aGUgcmVhbCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJwYXJzZVRlbXBsYXRlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhbmQgcnVuIHRocm91Z2ggdGhlIHJlYWwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widmFsaWRhdGVUZW1wbGF0ZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGFzc2VydGluZyB6ZXJvIGVycm9yIGRpYWdub3N0aWNzLCBvbmUgdGVzdCBwZXIgY2F0YWxvZyBlbnRyeSAoMTkgb2YgdGhlbSkgc28gYSBmdXR1cmUgZW50cnkgY2Fubm90IHJlZ3Jlc3Mgc2lsZW50bHlcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJHLUROLUE0XCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wic2FtZSDigJQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wid2lkZ2V0c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgPSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJXSURHRVRTXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY29tcG9uZW50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgPSBpdHMgZXhhY3QgY29tcGxlbWVudCwgdW5zZXQgPSBhbGxcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJHLUROLUE1XCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2FwcC9Wb2NhYnVsYXJ5U2VjdGlvbi50ZXN0LnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIHN0YXRpYyByZW5kZXIgd2l0aCBubyBob3N0IHRyYW5zcG9ydFwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkctRE4tQTZcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJ0aGUgaGVhZGVyIHN0cmluZ3MgaW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL0FwcC50c3hcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGJvZHk+PC9fY29tcG9uZW50cy50YWJsZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkFsbCAxOSBzbmlwcGV0cyB2YWxpZGF0ZSBvbiB0aGUgZmlyc3QgaW1wbGVtZW50YXRpb25cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHRoZSBzcGVjJ3MgwqcxLjEgcGVyLXNoYXBlXFxucnVsZXMgd2VyZSBzdWZmaWNpZW50LCBpbmNsdWRpbmcgdGhlIHNldmVuIGVudHJpZXMgdGhlIGFkdmVyc2FyaWFsIHBhc3MgaWRlbnRpZmllZCBhc1xcbmltcG9zc2libGUgdW5kZXIgdGhlIGRyYWZ0J3MgYXR0cmlidXRlLW9ubHkgcmVjaXBlIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJDaGFydFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIk1hcFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkZhY2V0c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlBhcmFtc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiU2hvd0Fib3ZlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiU2hvd0JlbG93XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgYW5kIHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJsaXRlcmFsLWFycmF5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjYXJyaWVycykuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cImFsc28tbGFuZGVkLXdpdGgtcGFydC1hXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJhbHNvLWxhbmRlZC13aXRoLXBhcnQtYVwiIC8+e1wiQWxzbyBsYW5kZWQgd2l0aCBQYXJ0IEFcIn08L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJBIHBsYXRmb3JtIGd1YXJkIGFnYWluc3QgdGhlIEROLVI1IGhhemFyZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2FwcC9wbGF0Zm9ybUd1YXJkcy50ZXN0LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIik6IG5vXFxubW9kdWxlIG1heSBcIn08X2NvbXBvbmVudHMuZW0+e1wic3RhdGljYWxseSB2YWx1ZS1pbXBvcnRcIn08L19jb21wb25lbnRzLmVtPntcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJAaW1tZWRpYXRlbHktcnVuL3Nka1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgb3IgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wi4oCmL3Rhc2tzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgd2hpY2hcXG5yZWdpc3RlciBhIGhvc3QgbGlzdGVuZXIgYXQgbW9kdWxlIGxvYWQgYW5kIHRocm93IHdpdGggbm8gdHJhbnNwb3J0LiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJpbXBvcnQgdHlwZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsXFxudGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1vdW50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgc3VicGF0aCBhbmQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYXdhaXQgaW1wb3J0KClcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFyZSBhbGwgY29ycmVjdGx5IG5vdCBtYXRjaGVkIOKAlCBwcm92ZW4gYnlcXG5mYXVsdCBpbmplY3Rpb24gb3ZlciBmaXZlIGNhc2VzLCBub3QgYnkgaW5zcGVjdGlvbi4gVGhpcyBndWFyZCBleGlzdHMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJiZWZvcmVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgUGFydCBCXFxubmVlZHMgaXQsIHNvIHRoZSBtaXN0YWtlIGNhbm5vdCBiZSBtYWRlIGxhdGVyLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQSBsaW50LXJlZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJtYWluXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBmaXhlZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgUjMtNDI3IHNoaXBwZWQgYW4gdW51c2VkLWJpbmRpbmcgZXJyb3IgYmVjYXVzZSB0aGVcXG52ZXJpZmljYXRpb24gY29tbWFuZCBwaXBlZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJucG0gcnVuIGxpbnRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGludG8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widGFpbFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGFuZCBhIHBpcGVsaW5lJ3MgZXhpdCBzdGF0dXMgaXNcXG50aGUgXCJ9PF9jb21wb25lbnRzLmVtPntcImxhc3RcIn08L19jb21wb25lbnRzLmVtPntcIiBjb21tYW5kJ3MsIHNvIHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCImJlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgY2hhaW4gY29udGludWVkIHBhc3QgYSBmYWlsaW5nIGdhdGUuIEZpeGVkIGhlcmUsIGFuZFxcbnRoZSBsZXNzb24gaXMgd29ydGgga2VlcGluZzogXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJuZXZlciBwaXBlIGEgZ2F0ZSBpbnRvIFwifTxfY29tcG9uZW50cy5jb2RlPntcInRhaWxcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcImhlYWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGluIGEgY2hhaW5lZFxcbnZlcmlmaWNhdGlvblwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgY2FwdHVyZSB0byBhIGZpbGUgYW5kIGNoZWNrIHRoZSBleGl0IGNvZGUuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInBhcnQtYi10aGUtZWRpdC1hZmZvcmRhbmNlLXIzLTQ0Ny10aGUtY29udHJhY3QtZXN0YWJsaXNoZWQtdGhlLWJ1aWxkLWxhbmRlZFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwicGFydC1iLXRoZS1lZGl0LWFmZm9yZGFuY2UtcjMtNDQ3LXRoZS1jb250cmFjdC1lc3RhYmxpc2hlZC10aGUtYnVpbGQtbGFuZGVkXCIgLz57XCJQYXJ0IEIg4oCUIHRoZSBlZGl0IGFmZm9yZGFuY2UgKFIzLTQ0NzogdGhlIGNvbnRyYWN0IGVzdGFibGlzaGVkLCB0aGUgYnVpbGQgbGFuZGVkKVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJQaGFzZSAxIOKAlCB0aGUgcHJlY29uZGl0aW9ucywgZXN0YWJsaXNoZWQgMjAyNi0wOS0yMlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAodGhlIHdvcmtlci1WTSBhZ2VudCB2ZW51ZTpcXG5jdXJyZW50LW1haW4gZGV2IGhvc3QgKyBzdGFnaW5nIGJhY2tlbmQvRmlyZXN0b3JlLCB0aGUgcmVhbCByZXBvLWxvYWQgZGlzcGF0Y2gsIGFcXG53b3JrYm9vayBjb3JwdXMgcmVwbyBkaXNwYXRjaGVkIGJ5IFVSTDsgYnJvd3Nlci1kcml2ZW4gb2JzZXJ2YXRpb24gb2ZmIHRoZSBsaXZlXFxuY2hhbm5lbCwgcGVyIHRoZSBzcGVjJ3MgcnVsZSDigJQgYW4gaW5qZWN0ZWQgcG9ydCBjYW5ub3QgZmFsc2lmeSBhIHF1ZXN0aW9uIGFib3V0IHRoZVxcbmhvc3QpOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudGFibGU+PF9jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGg+e1wiI1wifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIkFuc3dlciAod2l0aCBob3cgaXQgd2FzIGVzdGFibGlzaGVkKVwifTwvX2NvbXBvbmVudHMudGg+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50Ym9keT48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIlAxXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiQSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ0eXBlOiAnY29udGVudCdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGRpc3BhdGNoIG1vdW50IGNhcnJpZXMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGluIHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInVuaXZlcnNhbCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzY2hlbWU6bG9jYXRvclwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZm9ybVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgb2JzZXJ2ZWQgbGl2ZSBhcyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjb250ZW50OmltbWVkaWF0ZWx5LXJ1bi13b3JrZXIvcjMtNDQ3LXdvcmtib29rXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAodGhlIGZyYW1lJ3Mgb3duIG1vdW50IHNlcnZpY2UsIFwifTxfY29tcG9uZW50cy5jb2RlPntcImdldE1vdW50cygpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikuIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNhcEZpbGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiJ3MgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibW91bnRJZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaXMgdGhlcmVmb3JlIGFkZHJlc3NlZCB3aXRoIHRoZSBkZXNjcmlwdG9yJ3MgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHZlcmJhdGltOyB0aGUgaG9zdCdzIGdyYW50IGxvb2t1cCBpcyBhbiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImV4YWN0IG1hdGNoXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIG9uIGl0IChcIn08X2NvbXBvbmVudHMuY29kZT57XCJ0YXNrSW52b2NhdGlvbi50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oaSIFwifTxfY29tcG9uZW50cy5jb2RlPntcImdyYW50Rm9yXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiksIGFuZCBubyBmYWxsYmFjayBpcyBkb2N1bWVudGVkIOKAlCBhIHBhdGgtc2hhcGVkIG9yIGJhcmUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibW91bnRJZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgd291bGQgcmVmdXNlIFwifTxfY29tcG9uZW50cy5jb2RlPntcImZvcmJpZGRlblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIHdoaWNoIGlzIHdoeSB0aGUgZG9vciBmYWlscyBjbG9zZWQgb24gYW4gaWQtbGVzcyBtb3VudCByYXRoZXIgdGhhbiBtYWtpbmcgYSBkb29tZWQgY2FsbC4gVGhlIHVucXVhbGlmaWVkIGZvcm0gaXMgbm90IHdoYXQgdGhlIGhvc3QgbWludHMuXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiUDJcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJUaGUgbW91bnQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJyZXBvcnRzIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1vZGVcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBvYnNlcnZlZCBsaXZlIGFzIFwifTxfY29tcG9uZW50cy5jb2RlPntcIidydydcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG9uIHRoZSByZXBvLWxvYWQgZGlzcGF0Y2ggKHdyaXRlcyBsYW5kIGluIHRoZSBjb3JwdXMgbW91bnQ7IHByb3Bvc2luZyBiYWNrIHRvIHRoZSBzb3VyY2UgcmVwbyBzdGF5cyB1bndpcmVkLCB0aGUgUkNEIMKnNS4xIGRpc2Nsb3N1cmUpIOKAlCBhbmQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz48X2NvbXBvbmVudHMuY29kZT57XCJydWxlczogbnVsbFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnN0cm9uZz57XCIgKG5vIHJ1bGVzKS4gVGhlIGVkaXRhYmlsaXR5IGRlcml2YXRpb24gdGhlcmVmb3JlIGtleXMgb24gdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicG9zaXRpdmUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicndcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNoZWNrXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFItRUZFLTEgcHJlc2NyaWJlczsgdGhlIGRyYWZ0J3MgXFxcImFic2VudCDih5Igd3JpdGFibGVcXFwiIGludmVyc2lvbiAoRE4tUjIpIGlzIGRlYWQsIGFuZCB0aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3VidHJlZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCItY29tcGFyYWJpbGl0eSBxdWVzdGlvbiAoRE4tUjMpIGRpc3NvbHZlcyDigJQgdGhlcmUgYXJlIG5vIHJ1bGVzIHRvIGNvbXBhcmUuIFRoaXMgcmVwbydzIGRpc3BhdGNoIGZpeHR1cmVzIHN0YW1wIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1vZGU6ICdybydcIn08L19jb21wb25lbnRzLmNvZGU+e1wiOyB0aGUgbGl2ZSByZXBvLWxvYWQgbW91bnQgc3RhbXBzIFwifTxfY29tcG9uZW50cy5jb2RlPntcInJ3XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgdGhlIGZpeHR1cmVzIG1vZGVsIHRoZSB0YXNrLWludm9jYXRpb24gc2hhcGUsIG5vdCB0aGlzIG9uZS5cIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJQM1wifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQm90aCBjaGFubmVscyBhcmUgcmVhbCBhbmQgc2hhcGVkIGFzIMKnNC4yIGhhbmRsZXMgdGhlbS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgRG9jdW1lbnRlZCBoYWxmICh0aGUgaG9zdCdzIHRhc2sgY29udHJhY3QsIFwifTxfY29tcG9uZW50cy5jb2RlPntcInRhc2tDb250cmFjdHMudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKTogXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZWRpdC1maWxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiByZXR1cm5zIFwifTxfY29tcG9uZW50cy5jb2RlPntcInsgc2F2ZWQ6IGJvb2xlYW4gfVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNhdmVkOiBmYWxzZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaXMgdGhlIHJlc3VsdC1jYXJyaWVkIHJlZnVzYWwsIGFuZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJpbnZva2VUYXNrXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB0aHJvd3MgbWFjaGluZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCIuY29kZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcmVqZWN0aW9ucyAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2FuY2VsbGVkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZm9yYmlkZGVuXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwg4oCmKS4gTGl2ZSBoYWxmIChhIHJlYWwgaW52b2NhdGlvbiBmcm9tIHRoZSBkaXNwYXRjaGVkIGZyYW1lKTogZXhlcmNpc2VkIGJ5IHRoZSBnYXRlcyBiZWxvdyDigJQgaXQgcmVxdWlyZWQgUDQncyBncmFudCBmaXJzdCwgd2hpY2ggaXMgdGhlIHNlcXVlbmNpbmcgZmluZGluZywgbm90IGEgZ2FwLlwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIlA0XCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnN0cm9uZz57XCJOTyDigJQgYW5kIGRlbGliZXJhdGVseSBzby5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhlIGJ1aWxkLWRlZmF1bHQgYmluZGluZyAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic2l0ZS1tYWluXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyZWdpc3RyeS9kZWZhdWx0cy50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcInRhc2sub3Blbi13b3JrYm9va1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpIG9taXR0ZWQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widGFzazppbnZva2VcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHdpdGggYSBjb21tZW50IG5hbWluZyB0aGlzIG1pbGVzdG9uZSBhcyB0aGUgbW9tZW50IHRvIGFkZCBpdDsgdGhlIGZyYW1lJ3MgbGl2ZSBncmFudC1maWx0ZXJlZCBjYXRhbG9nIGNhcnJpZWQgbm8gdGFzayB2ZXJiLiBUaGUgZ3JhbnQgaGFsZiBpcyBzaXRlLW1haW4ncyBSMy00NDcgcmVnaXN0cnkgZGlmZiAodGhpcyBtaWxlc3RvbmUpOyB0aGUgbWFuaWZlc3QgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW52b2tlc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZGVjbGFyYXRpb24gKHRoaXMgcmVwbykgaXMgdGhlIHNlbGYtcmVzdHJpY3Rpb24gaGFsZiDigJQgRy1ETi1CMTAgYXNzZXJ0cyBib3RoLlwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIlA1XCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgZGlzcGF0Y2hlZCBzaGFwZSBpcyByZWFjaGFibGUgYW5kIHJlbmRlcnMuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIERyaXZlbiBsaXZlOiBhIHdvcmtib29rIGNvcnB1cyByZXBvICh0aGUgTWVyaWRpYW4gc2VlZCBhcyByZWFsIGZpbGVzICsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW1tZWRpYXRlbHkucnVuLmpzb25cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG1hcmtlciBcIn08X2NvbXBvbmVudHMuY29kZT57XCJvcGVuc1dpdGg6IG9wZW4td29ya2Jvb2tAMS4wXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikgZGlzcGF0Y2hlZCBieSBVUkwgdGhyb3VnaCB0aGUgcmVhbCByZXBvLWxvYWQgYnJhbmNoIOKAlCBzdG9jayByZWNrb25lciBmcm9tIHRoZSByZWdpc3RyeSBiaW5kaW5nIHJlbmRlcmVkIHRoZSByZXBvcnQgKG5hdiwgZ3Jvd3RoLWNvbXBvc2l0aW9uIHNlY3Rpb25zLCB0aGUgd29ya2Jvb2sgcGFuZWwpLiBUaGUgaG9uZXN0IHNlcXVlbmNpbmcgbm90ZXM6IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibm8gd29ya2Jvb2sgY29ycHVzIHJlcG8gZXhpc3RlZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAodGhlIGNvcnB1cyBpcyBjb250ZW50IHdvcmssIG5vdCBwbGF0Zm9ybSB3b3JrIOKAlCB0aGUgc3Bpa2UncyBjb3JwdXMgaXMgdGVtcG9yYXJ5KSwgYW5kIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibm8gdXNlci1mYWNpbmcgY2FsbGVyIGludm9rZXMgdGhlIHRhc2tcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJvcGVuc1dpdGhcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG1hcmtlcidzIG9ubHkgcmVhZGVyIGlzIHRoZSBVUkwgcm91dGU7IHRoZSBmb2xkZXItdHJpZ2dlciBjYWxsZXIgaXMgUjMtMjY3KSDigJQgdGhlIFVSTCByb3V0ZSBpcyB0aGUgcmVhY2hhYmxlIHNoYXBlLlwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRib2R5PjwvX2NvbXBvbmVudHMudGFibGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJQaGFzZSAyIOKAlCBidWlsdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAodGhlIHNhbWUgaXRlbSk6IHRoZSBpbnNwZWN0b3IncyBwZXItcm93IGVkaXQgZG9vciAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiVmFsdWVJbnNwZWN0b3JcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSxcXG50aGUgwqc0LjMgcGF0aCBnYXRlIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJkb2N1bWVudFBhdGhzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiksIHRoZSBkb29yIGl0c2VsZiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widXNlRWRpdEZpbGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCBsYXp5IGltcG9ydCwgYm90aFxcbnJlZnVzYWwgY2hhbm5lbHMsIHRoZSBzZXNzaW9uLXNjb3BlZCBsYXRjaCwgdGhlIGhvc3QtbGVzcyBuby1vcCwgdGhlIMKnNC40IHN0YWxlbmVzc1xcbnNpZ25hbCksIHRoZSBzdGFsZW5lc3Mgbm90aWNlICsgcmVsb2FkIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJEb2N1bWVudENoYW5nZWROb3RpY2VcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ1c2VSZXBvcnQucmVsb2FkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiksXFxudGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcImludm9rZXNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGRlY2xhcmF0aW9uLCBhbmQgc2l0ZS1tYWluJ3MgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widGFzazppbnZva2VcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGdyYW50LiBRNiAodGhlIGNvbnN1bWVyXFxuaW5zcGVjdG9yJ3MgZG9vcikgcmVzb2x2ZXMgcGVyIHRoZSBpdGVtJ3Mgb3duIFBoYXNlLTIgc3VyZmFjZSAoXFxcInRoZSBpbnNwZWN0b3IncyBmb3JtdWxhXFxuYW5kIHRlc3Qgcm93c1xcXCIpOyBRMyAocmVsb2FkIHZzIGNoYW5nZS13YXRjaCkgcmVzb2x2ZXMgdG8gdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicmVsb2FkIGFmZm9yZGFuY2VcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIGFcXG5jaGFuZ2Utd2F0Y2ggbmVlZHMgYW4gZnMgd2F0Y2ggdGhlIHRhc2stZGVsZWdhdGVkIGV4cG9ydCBkb2VzIG5vdCBjYXJyeVxcbihTUEFDRVNfVUkgwqc2LjYgLyBSMy03MzIncyBzZWFtKS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwiZ2F0ZS1jb3ZlcmFnZS0xXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJnYXRlLWNvdmVyYWdlLTFcIiAvPntcIkdhdGUgY292ZXJhZ2VcIn08L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy50YWJsZT48X2NvbXBvbmVudHMudGhlYWQ+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50aD57XCJHYXRlXCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGg+e1wiVGVzdFwifTwvX2NvbXBvbmVudHMudGg+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50Ym9keT48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkctRE4tQjFcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJkaXNwYXRjaC50ZXN0LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgdGhlIG9rIHJlc29sdXRpb24gY2FycmllcyB0aGUgbGl2ZSBtb3VudCAoaWQvbW9kZSBwcm92ZW5hbmNlKTsgdGhlIGxpdmUgZGVzY3JpcHRvciByZWFkIG9uIHRoZSB2ZW51ZSAoYWJvdmUpXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiRy1ETi1CMlwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcInVzZUVkaXRGaWxlLnRlc3QudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCB3cml0YWJpbGl0eSBieSB0aGUgcG9zaXRpdmUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicndcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNoZWNrIChyby9hYnNlbnQgYXJlIG5vdCBkb29ycylcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJHLUROLUIzXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiZG9jdW1lbnRQYXRocy50ZXN0LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgc2VnbWVudC1ib3VuZGFyeSB0cmF2ZXJzYWwgcmVmdXNhbDsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widXNlRWRpdEZpbGUudGVzdC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIGEgZmFpbGluZyBwYXRoIG5ldmVyIGNvbnN0cnVjdHMgdGhlIGRlbGVnYXRpb25cIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJHLUROLUI0XCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1widXNlRWRpdEZpbGUudGVzdC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIHRoZSBjYWxsIGFkZHJlc3NlcyB0aGUgZGVzY3JpcHRvciBpZCAodW5pdmVyc2FsIGZvcm0pOyBhbiBpZC1sZXNzIG1vdW50IGlzIG5vdCBhIGRvb3IgKGZhaWwtY2xvc2VkIOKAlCB0aGUgaG9zdCdzIGV4YWN0LW1hdGNoIGdyYW50IGxvb2t1cCBoYXMgbm8gZG9jdW1lbnRlZCBmYWxsYmFjayk7IHRoZSBsaXZlIGludm9jYXRpb24gZ2F0ZSBiZWxvd1wifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkctRE4tQjVcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJ1c2VFZGl0RmlsZS50ZXN0LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgYm90aCBjaGFubmVsczogdGhyb3duIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNhbmNlbGxlZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZm9yYmlkZGVuXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJ0aW1lb3V0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgdGhlIHJlc3VsdC1jYXJyaWVkIFwifTxfY29tcG9uZW50cy5jb2RlPntcIntzYXZlZDpmYWxzZX1cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHJlZnVzYWwsIHRoZSBob3N0LWxlc3Mgbm8tb3A7IHRoZSBsaXZlIGdhdGUgYmVsb3dcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJHLUROLUI2XCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiVmFsdWVJbnNwZWN0b3IudGVzdC50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCBhYnNlbnQgdW5sZXNzIHdyaXRhYmxlIChwZXIgcm93KSwgcHJlc2VudCBiZXNpZGUgYm90aCBhbmNob3JzLCB0aGUgZGlzY2xvc3VyZSBhdCB0aGUgYnV0dG9uLCB0aGUgY2xpY2sgaGFuZHMgdGhlIHJvdydzIHBhdGg7IHRoZSBsaXZlIGdhdGUgYmVsb3dcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJHLUROLUI3XCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiZG9jdW1lbnRQYXRocy50ZXN0LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgdHJhdmVyc2FsLXNoYXBlZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJtYW5pZmVzdC53b3Jrc2hlZXRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBwYXRocyBuZXZlciByZWFjaCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjYXBGaWxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkctRE4tQjhcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJ0aGUgcHJlLWV4aXN0aW5nIFwifTxfY29tcG9uZW50cy5jb2RlPntcInBsYXRmb3JtR3VhcmRzLnRlc3QudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChubyBzdGF0aWMgdGFza3MgaW1wb3J0KSArIFwifTxfY29tcG9uZW50cy5jb2RlPntcInVzZUVkaXRGaWxlLnRlc3QudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiJ3MgaG9zdC1sZXNzIG5vLW9wIGNhc2VcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJHLUROLUI5XCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiRG9jdW1lbnRDaGFuZ2VkTm90aWNlLnRlc3QudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiArIFwifTxfY29tcG9uZW50cy5jb2RlPntcInVzZVJlcG9ydC50ZXN0LnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKHRoZSByZWxvYWQpOyB0aGUgbGl2ZSBnYXRlIGJlbG93XCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiRy1ETi1CMTBcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJwYWNrYWdlLmpzb25cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIFwifTxfY29tcG9uZW50cy5jb2RlPntcImludm9rZXNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICh0aGlzIHJlcG8pICsgc2l0ZS1tYWluJ3MgcmVnaXN0cnkgZGlmZiBhbmQgaXRzIGV4YWN0LWxpc3QgdGVzdFwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRib2R5PjwvX2NvbXBvbmVudHMudGFibGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgaG9zdC1leGVyY2lzZWQgaGFsdmVzIChQMeKAk1A0J3MgbGl2ZSBsZWdzOiBhIHJlYWwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZWRpdC1maWxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpbnZvY2F0aW9uIGZyb20gdGhlXFxuZGlzcGF0Y2hlZCBmcmFtZSDigJQgdGhlIGRvb3IgdmlzaWJsZSBvbiB0aGUgZGlzcGF0Y2hlZCBzaGFwZSwgdGhlIG92ZXJsYXkgb3BlbmluZywgYm90aFxcbnJlZnVzYWwgY2hhbm5lbHMgb2JzZXJ2ZWQgb24gdGhlIHJlYWwgZ2F0ZSwgdGhlIHN0YWxlbmVzcyBhZmZvcmRhbmNlIGFmdGVyIGEgc2F2ZSkgcnVuXFxub24gdGhlIHZlbnVlIGFnYWluc3QgdGhlIG1lcmdlZCBtYWlucyBiZWZvcmUgUjMtNDQ3IGFyY2hpdmVzOyB0aGUgdW5pdCBoYWx2ZXMgYWJvdmUgYXJlXFxuaW4tcmVwbyBhbmQgZ3JlZW4uXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cIm9wZW4tcmVzaWR1YWxzXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJvcGVuLXJlc2lkdWFsc1wiIC8+e1wiT3BlbiByZXNpZHVhbHNcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+PF9jb21wb25lbnRzLmNvZGU+e1wiZWRpdC10YWJsZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaXMgbm93IHNwZWNpZmllZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoMjAyNi0wOC0yOSkg4oCUIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkVESVRfVEFCTEVfVEFTS19TUEVDLm1keFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaW4gdGhlIGRvY3NcXG5yZXBvLCBwcm9wb3NhbCByZXYgMiBhZnRlciBhbiBhZHZlcnNhcmlhbCBwYXNzLiBJdCBpcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImJsb2NrZWQgb24gUDHigJNQNSBhYm92ZSBwbHVzIHR3b1xcbm9mIGl0cyBvd25cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKFwifTxfY29tcG9uZW50cy5kZWw+e1wiUDY6IHRhc2stZGVsZWdhdGlvbiBtb3VudHMgYXJlIGFubm91bmNlZCB3aXRoIG5vIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1vZGVcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5kZWw+e1wiIOKAlCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImNsb3NlZFxcbjIwMjYtMDktMjkgYnkgdGhlIFIzLTc1NCBwcm9iZSBiZWxvdzogdGhlIGRlbGVnYXRpb24gbW91bnQgYW5ub3VuY2VzIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1vZGU6ICdybydcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiXFxuKHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJtaW4oY2FsbGVyIGdyYW50LCBjYXAsIGNvbnRyYWN0KVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgc3RhbXAsIHNpdGUtbWFpbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJtaW50RGVsZWdhdGlvbnMudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSwgc28gdGhlXFxucmVhZC1vbmx5IHJ1bGUgSVMgaW1wbGVtZW50YWJsZTsgUDc6IFJlY2tvbmVyIGhhcyBubyBmcyB3YXRjaCwgc28gdGhlIGF1dG9zYXZlIHNhZmV0eSBhcmd1bWVudFxcbmhhcyBubyBjb25zdW1lcikuIFIzLTQ0NydzIGhvc3Qgc3Bpa2UgdGhlcmVmb3JlIHVuYmxvY2tzIGJvdGggc3VyZmFjZXMsIG5vdCBqdXN0XFxuUGFydCBCIOKAlCB3b3J0aCBrbm93aW5nIGJlZm9yZSBzY29waW5nIGl0LiBUaGUgMjAyNi0wOC0yOSByZXZpZXcgYWxzbyBjb25maXJtZWQgdGhlXFxuc2VlZC12cy1tb3VudCB3YWxsIGFwcGxpZXMgdG8gZml4dHVyZXMgZXhhY3RseSBhcyBpdCBkb2VzIHRvIHdvcmtzaGVldHM6IG9uIHRoZVxcbmJ1bmRsZWQtc2VlZCBwYXRoIHRoZXJlIGlzIG5vIGZpbGUgdG8gZGVsZWdhdGUsIG9ubHkgYSBzdHJpbmcgaW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL3NlZWQvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiU3BlYyDCpzYgKFwifTxfY29tcG9uZW50cy5jb2RlPntcImVkaXQtdGFibGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBvcGVuLWF0LWxpbmUsIERlbHRhIEIsIGNsaWNrLXRvLWluc2VydCwgb3duLXNvdXJjZSBlZGl0aW5nKSBhbmRcXG7CpzExIFEx4oCTUTcg4oCUIGluY2x1ZGluZyB0aGUgdHdvIHRoZSByZXZpZXcgc3VyZmFjZWQgYXMgcmVhbCBkZWNpc2lvbnMgcmF0aGVyIHRoYW5cXG5kZWZlcnJhbHM6IHdoZXRoZXIgdGhlIGNvbnN1bWVyLXZpc2libGUgaW5zcGVjdG9yIGNhcnJpZXMgYW4gYXV0aG9yaW5nIGRvb3IgKFE2KSwgYW5kXFxudGhlIHRlbXBsYXRlLWZpbGUgZWRpdCByb3cgd2l0aG91dCB3aGljaCBcXFwiY29weSB0aGUgc25pcHBldCwgb3BlbiB0aGUgdGVtcGxhdGVcXFwiIGhhcyBub1xcbmRvb3IgKFE3KS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwidGhlLXNlY29uZC1kaXNwYXRjaC1zaGFwZXMtZGVzY3JpcHRvci1yMy03NTQtcHJvYmVkLWxpdmUtMjAyNi0wOS0yOVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwidGhlLXNlY29uZC1kaXNwYXRjaC1zaGFwZXMtZGVzY3JpcHRvci1yMy03NTQtcHJvYmVkLWxpdmUtMjAyNi0wOS0yOVwiIC8+e1wiVGhlIHNlY29uZCBkaXNwYXRjaCBzaGFwZSdzIGRlc2NyaXB0b3IgKFIzLTc1NCwgcHJvYmVkIGxpdmUgMjAyNi0wOS0yOSlcIn08L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlByb2JlZCBvbiB0aGUgdmVudWUgKHN0YWdpbmcgY29tcG9zaXRpb24sIGRyaXZlbiBDaHJvbWl1bSwgdGhlIHZlbnVlIGlkZW50aXR5IHNpZ25lZFxcbmluKTogdGhlIGNvcnB1cyBvcGVuIGluIHRoZSBlZGl0b3IsIGZpbGUtZXhwbG9yZXIncyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJvcGVuc1dpdGhcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFmZm9yZGFuY2Ugb24gdGhlXFxuY29ycHVzIHJvb3QgKFxcXCJPcGVuIGFzIHdvcmtib29rXFxcIiksIHRoZSB0YXNrIG92ZXJsYXkgcnVubmluZyByZWNrb25lci4gVGhlIGZyYW1lJ3Mgb3duXFxubW91bnQgc2V0LCByZWFkIGZyb20gdGhlIGNhbGxlZTpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnByZT48X2NvbXBvbmVudHMuY29kZSBjbGFzc05hbWU9XCJsYW5ndWFnZS1qc29uXCI+e1wieyBcXFwiaWRcXFwiOiBcXFwiL3Rhc2svdGFzay0xL2RpclxcXCIsIFxcXCJwYXRoXFxcIjogXFxcIi90YXNrL3Rhc2stMS9kaXJcXFwiLFxcbiAgXFxcInR5cGVcXFwiOiBcXFwidGFzay1kZWxlZ2F0aW9uXFxcIiwgXFxcIm1vZGVcXFwiOiBcXFwicm9cXFwiLCBcXFwicnVsZXNcXFwiOiBudWxsIH1cXG5cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5wcmU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wid2l0aCB0aGUgdGFzayBpbnB1dCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ7IHRhc2s6ICdvcGVuLXdvcmtib29rJywgcGFyYW1zOiB7IGRpcjogJy90YXNrL3Rhc2stMS9kaXInIH0gfVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUXFxudGhlIGhvc3QgUkVXUklURVMgdGhlIGNhbGxlcidzIFwifTxfY29tcG9uZW50cy5jb2RlPntcImRpclwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdG8gdGhlIG1pbnRlZCBjaHJvb3QgcGF0aCwgYW5kIHRoZSBtb3VudCdzIFwifTxfY29tcG9uZW50cy5jb2RlPntcImlkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIlxcbmlzIHRoYXQgc2FtZSBwYXRoIChOT1QgdGhlIHVuaXZlcnNhbCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzY2hlbWU6bG9jYXRvclwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZm9ybSBQMSBlc3RhYmxpc2hlZCBmb3JcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJ0eXBlOiAnY29udGVudCdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG1vdW50cyDigJQgdGhlIHR3byBzaGFwZXMgYWRkcmVzcyBkaWZmZXJlbnRseSwgYW5kIFwifTxfY29tcG9uZW50cy5jb2RlPntcImRpc3BhdGNoLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIidzXFxudGFzayBicmFuY2ggYWRkcmVzc2VzIHRoZSBkZWxlZ2F0aW9uIGJ5IHRoZSBwYXRoLWZvcm0gaWQgaXQgYXJyaXZlcyB3aXRoKS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIG1vZGUgaXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz48X2NvbXBvbmVudHMuY29kZT57XCJyb1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZXZlbiB3aGVuIHRoZSBjYWxsZXIncyBzZXNzaW9uIGhvbGRzIHRoZSBjb3JwdXMgcmVhZC13cml0ZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAodGhlXFxuZWRpdCBzZXNzaW9uJ3Mgd29ya3RyZWUpOiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJwYW5lbC5maWxlc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIncyBwdWJsaXNoZWQgcG9ydCBvZiB0aGUgd29ya3RyZWUgaXMgaXRzZWxmXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicm9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBzbyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJtaW4o4oCmKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgY2xhbXBzIHRvIFwifTxfY29tcG9uZW50cy5jb2RlPntcInJvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiByZWdhcmRsZXNzIG9mIHRoZSBzZXNzaW9uJ3Mgd3JpdGFiaWxpdHkuIFRoZSBlZGl0XFxuZG9vciB0aGVyZWZvcmUgc3RheXMgZGFyayBvbiBldmVyeSBkaXNwYXRjaC1kcml2ZW4gb3BlbiDigJQgYnkgZGVzaWduLCBwZW5kaW5nIFIzLTc5NyDigJRcXG5hbmQgdGhlIFVSTC90YXNrIGRpc3BhdGNoIHNoYXBlcyBhcmUgcmVjb3JkZWQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ2aWV3LW9ubHlcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHRoZSBvd25lcidzIDIwMjYtMDktMjhcXG5kZWNpc2lvbiAoYykgb24gUjMtNzU0KS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwidGhlLWxpdmUtZ2F0ZXMtMjAyNi0wOS0yMi10aGUtdmVudWUtcnVuLWFnYWluc3QtYm90aC1tZXJnZWQtbWFpbnMtdHdvLXBhc3Mtb25lLWlzLWEtZmluZGluZ1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwidGhlLWxpdmUtZ2F0ZXMtMjAyNi0wOS0yMi10aGUtdmVudWUtcnVuLWFnYWluc3QtYm90aC1tZXJnZWQtbWFpbnMtdHdvLXBhc3Mtb25lLWlzLWEtZmluZGluZ1wiIC8+e1wiVGhlIGxpdmUgZ2F0ZXMgKDIwMjYtMDktMjIsIHRoZSB2ZW51ZSBydW4gYWdhaW5zdCBCT1RIIG1lcmdlZCBtYWlucykg4oCUIHR3byBwYXNzLCBvbmUgaXMgYSBGSU5ESU5HXCJ9PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJEcml2ZW4gb24gdGhlIHdvcmtlci1WTSB2ZW51ZSB3aXRoIHNpdGUtbWFpbiBhdCA2MGRkZDBhIGFuZCByZWNrb25lckBtYWluIGF0IDI5MjVmYTRcXG4oYm90aCBQUnMgbWVyZ2VkKSwgdGhlIGNvcnB1cyBkaXNwYXRjaGVkIGJ5IFVSTDpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkctRE4tQjYgbGl2ZTogUEFTUy5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhlIGRvb3IgcmVuZGVycyBiZXNpZGUgYm90aCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmaWxlOmxpbmVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFuY2hvcnNcXG4oXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wid29ya3NoZWV0cy9yZXZpZXcuc2hlZXQuanM6M1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYW5kIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjoxMDdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSBvbiB0aGUgZGlzcGF0Y2hlZCBzaGFwZSwgd2l0aCB0aGUgUkNEXFxuwqc1LjEgZGlzY2xvc3VyZSBvbiB0aGUgYnV0dG9uIHRpdGxlIEFORCB0aGUgdmlzaWJsZSBub3RlIGxpbmUuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJHLUROLUI1IGxpdmUgKHRoZSBmb3JiaWRkZW4gY2hhbm5lbCk6IFBBU1MuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIEEgcmVmdXNlZCBpbnZvY2F0aW9uIGRyYXdzIGV4YWN0bHlcXG5vbmUgcGxhaW4gbWVzc2FnZSAoXFxcIlRoaXMgZG9jdW1lbnQgY2FuJ3QgYmUgZWRpdGVkIGhlcmUuXFxcIikgYW5kIGxhdGNoZXMgdGhlIGRvb3Igb2ZmIOKAlFxcbm9ic2VydmVkIGxpdmUsIG1hdGNoaW5nIMKnNC4yIHRvIHRoZSBsZXR0ZXIuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJHLUROLUI0IGxpdmUgKHRoZSBzdWNjZXNzZnVsIGludm9jYXRpb24pOiBCTE9DS0VEIEJZIEEgRklORElORywgbm90IGEgYnVnIGluIHRoaXNcXG5yZXBvJ3MgaGFsZi5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhlIGludm9jYXRpb24gcmVmdXNlcyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmb3JiaWRkZW4g4oCUICdwcm90b2NvbC10YXNrLmludm9rZScgcmVxdWlyZXMgdGhlICd0YXNrOmludm9rZScgY2FwYWJpbGl0eTsgdGhpcyBhcHAncyBncmFudCBkb2VzIG5vdCBob2xkIGl0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJkZXNwaXRlXFxuc2l0ZS1tYWluIzU4NCBiZWluZyBtZXJnZWQgYW5kIHRoZSB2ZW51ZSBzZXJ2aW5nIGl0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLiBSb290IGNhdXNlIChjb2RlICsgbGl2ZSk6XFxudGhlIFVSTCByZXBvLWxvYWQgZGlzcGF0Y2ggcmVzb2x2ZXMgdGhlIFwifTxfY29tcG9uZW50cy5lbT57XCJ2aWV3ZXIncyByZXBvXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgZnJvbSB0aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widGFzay5vcGVuLXdvcmtib29rXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIlxcbmJpbmRpbmcsIGJ1dCB0aGUgZnJhbWUncyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImdyYW50XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGlzIHRoZSBwcmV2aWV3L3N0YWdlIGdyYW50IOKAlCB0aGUgcmVnaXN0cnkgcm93J3NcXG5jYXBhYmlsaXRpZXMgbmV2ZXIgZmxvdyB0byB0aGUgcmVwby1sb2FkLWRpc3BhdGNoZWQgZnJhbWUuIFRoZSB0YXNrLWludm9jYXRpb24gc2hhcGVcXG4od2hlcmUgdGhlIGJpbmRpbmcncyBncmFudCBkb2VzIGFwcGx5KSBpcyB1bnJlYWNoYWJsZSB0d2ljZSBvdmVyOiBubyB1c2VyLWZhY2luZ1xcbmNhbGxlciBleGlzdHMgKFIzLTI2NyksIGFuZCB0aGlzIHJlcG8ncyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJkaXNwYXRjaC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdjEgZGVsaWJlcmF0ZWx5IHJlc29sdmVzIG9ubHlcXG50aGUgcmVwby1sb2FkIHNoYXBlLiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlRoZSBhZmZvcmRhbmNlIGlzIHRoZXJlZm9yZSB1bnJlYWNoYWJsZSBvbiBib3RoIGRpc3BhdGNoXFxuc2hhcGVzIOKAlCBETi1SMTIncyBmYWlsdXJlIG1vZGUgcmVib3JuIGF0IHRoZSBpbnZvY2F0aW9uIGxheWVyLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGUgZml4IGlzIGFcXG5kZXNpZ24gZGVjaXNpb24gdGhlIG93bmVyIG93bnMgKHRoZSByZXBvLWxvYWQgZGlzcGF0Y2ggbWludGluZyB0aGUgdmlld2VyJ3MgZ3JhbnRcXG5mcm9tIHRoZSB0YXNrIGJpbmRpbmc7IG9yIHRoZSBwcmV2aWV3IGdyYW50IHdpZGVuaW5nOyBvciBzaGlwcGluZyB0aGUgdGFzay1zaGFwZVxcbmNhbGxlcik7IHJlY29yZGVkIGluIFIzLTQ0NydzIHJvYWRtYXAgc3RhdHVzLCB3aGljaCBzdGF5cyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImluLXByb2dyZXNzLCB1bmFyY2hpdmVkXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD48Lz47XG59XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNRFhDb250ZW50KHByb3BzID0ge30pIHtcbiAgY29uc3Qge3dyYXBwZXI6IE1EWExheW91dH0gPSB7XG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9O1xuICByZXR1cm4gTURYTGF5b3V0ID8gPE1EWExheW91dCB7Li4ucHJvcHN9PjxfY3JlYXRlTWR4Q29udGVudCB7Li4ucHJvcHN9IC8+PC9NRFhMYXlvdXQ+IDogX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpO1xufVxuZnVuY3Rpb24gX21pc3NpbmdNZHhSZWZlcmVuY2UoaWQsIGNvbXBvbmVudCwgcGxhY2UpIHtcbiAgdGhyb3cgbmV3IEVycm9yKFwiRXhwZWN0ZWQgXCIgKyAoY29tcG9uZW50ID8gXCJjb21wb25lbnRcIiA6IFwib2JqZWN0XCIpICsgXCIgYFwiICsgaWQgKyBcImAgdG8gYmUgZGVmaW5lZDogeW91IGxpa2VseSBmb3Jnb3QgdG8gaW1wb3J0LCBwYXNzLCBvciBwcm92aWRlIGl0LlwiICsgKHBsYWNlID8gXCJcXG5JdOKAmXMgcmVmZXJlbmNlZCBpbiB5b3VyIGNvZGUgYXQgYFwiICsgcGxhY2UgKyBcImAgaW4gYC9hcHAvZG9jcy9zdGF0dXMvRE9DVU1FTlRfTkFWSUdBVE9SX1NUQVRVUy5tZGBcIiA6IFwiXCIpKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQXdGLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUZ4RjtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU1DLFdBQVcsR0FBRztNQUNsQkMsSUFBSSxFQUFFLE1BQU07TUFDWkMsR0FBRyxFQUFFLEtBQUs7TUFDVkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsR0FBRyxFQUFFLEtBQUs7TUFDVkMsTUFBTSxFQUFFLFFBQVE7TUFDaEJDLEtBQUssRUFBRSxPQUFPO01BQ2RDLEtBQUssRUFBRSxPQUFPO01BQ2RDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEtBQUssRUFBRSxPQUFPO01BQ2RDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1IsR0FBRyxJQUFBQyw2QkFBa0IsRUFBQyxDQUFDO01BQ3ZCLEdBQUduQixLQUFLLENBQUNvQjtJQUNYLENBQUM7SUFBRTtNQUFDQztJQUFhLENBQUMsR0FBR3BCLFdBQVc7RUFDaEMsSUFBSSxDQUFDb0IsYUFBYSxFQUFFQyxvQkFBb0IsQ0FBQyxlQUFlLEVBQUUsSUFBSSxDQUFDO0VBQy9ELG9CQUFPLElBQUF4QixXQUFBLENBQUF5QixJQUFBLEVBQUF6QixXQUFBLENBQUEwQixRQUFBO0lBQUFDLFFBQUEsZ0JBQUUsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0ksRUFBRTtNQUFDcUIsRUFBRSxFQUFDLDBDQUEwQztNQUFBRCxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQTBDLENBQUUsQ0FBQyxFQUFDLDRDQUE0QztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1EsQ0FBQztNQUFBZ0IsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFTLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBb0YsQ0FBcUIsQ0FBQyxFQUFDLE1BQU0sZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFVLENBQXFCLENBQUMsRUFBQyxhQUFhO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDUSxDQUFDO01BQUFnQixRQUFBLEdBQUUsZ0VBQWdFLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQXVDLENBQW1CLENBQUMsRUFBQywrQ0FBK0M7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNLLEVBQUU7TUFBQ29CLEVBQUUsRUFBQyxvREFBb0Q7TUFBQUQsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFvRCxDQUFFLENBQUMsRUFBQyx3REFBd0Q7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNpQixFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBdUIsQ0FBbUIsQ0FBQyxFQUFDLDRPQUE0TyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFlLENBQW1CLENBQUMsRUFBQyxpQkFBaUI7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNPLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQStCLENBQW1CLENBQUMsRUFBQyw0R0FBNEc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNPLEVBQUU7UUFBQWlCLFFBQUEsR0FBRSxhQUFhLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQTJCLENBQW1CLENBQUMsRUFBQyxxQ0FBcUMsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBVSxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFnQixDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyxJQUFJO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNNLEVBQUU7TUFBQ21CLEVBQUUsRUFBQyxlQUFlO01BQUFELFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBZSxDQUFFLENBQUMsRUFBQyxlQUFlO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDVyxLQUFLO01BQUFhLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2UsS0FBSztRQUFBUyxRQUFBLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2dCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDYyxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFNLENBQWlCLENBQUMsbUJBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNjLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQU0sQ0FBaUIsQ0FBQztRQUFBLENBQWdCO01BQUMsQ0FBbUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksS0FBSztRQUFBWSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNnQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBUyxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQTRCLENBQW1CLENBQUMsRUFBQyxnQkFBZ0IsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLHdCQUF3QjtVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDZ0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQVMsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEdBQUUsbUNBQW1DLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQU8sQ0FBbUIsQ0FBQyxFQUFDLHVDQUF1QyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFHLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQUcsQ0FBbUIsQ0FBQyxFQUFDLE9BQU8sZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBaUIsQ0FBbUIsQ0FBQztVQUFBLENBQWdCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDZ0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQVMsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEdBQUUsU0FBUyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQU8sQ0FBcUIsQ0FBQyxFQUFDLDhCQUE4QixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFlLENBQW1CLENBQUMsRUFBQyw0QkFBNEIsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBa0IsQ0FBbUIsQ0FBQyxFQUFDLHVIQUF1SDtVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDZ0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQVMsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEdBQUUsU0FBUyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFTLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQVMsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBWSxDQUFtQixDQUFDLEVBQUMsc0NBQXNDO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNnQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBUyxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQW9DLENBQW1CLENBQUMsRUFBQyx5Q0FBeUM7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2dCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFTLENBQWlCLENBQUMsbUJBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxHQUFFLHdCQUF3QixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFhLENBQW1CLENBQUM7VUFBQSxDQUFnQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQztNQUFBLENBQW1CLENBQUM7SUFBQSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNRLENBQUM7TUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBc0QsQ0FBcUIsQ0FBQyxFQUFDLDJLQUEySyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFPLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQUssQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBUSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFRLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQVcsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBVyxDQUFtQixDQUFDLEVBQUMsWUFBWSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFlLENBQW1CLENBQUMsRUFBQyxhQUFhO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDTSxFQUFFO01BQUNtQixFQUFFLEVBQUMseUJBQXlCO01BQUFELFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBeUIsQ0FBRSxDQUFDLEVBQUMseUJBQXlCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDaUIsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNPLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBMkMsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBZ0MsQ0FBbUIsQ0FBQyxFQUFDLG9CQUFvQixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNHLEVBQUU7VUFBQXFCLFFBQUEsRUFBRTtRQUF5QixDQUFpQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFzQixDQUFtQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFTLENBQW1CLENBQUMsRUFBQyxnRkFBZ0YsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBYSxDQUFtQixDQUFDLEVBQUMsU0FBUyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFRLENBQW1CLENBQUMsRUFBQyxlQUFlLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQWdCLENBQW1CLENBQUMsRUFBQyxvSEFBb0gsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFRLENBQXFCLENBQUMsRUFBQyx5REFBeUQ7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNPLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBYyxRQUFBLEdBQUUsYUFBYSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7WUFBQXVCLFFBQUEsRUFBRTtVQUFNLENBQW1CLENBQUMsRUFBQyxRQUFRO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLG9GQUFvRixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQU0sQ0FBbUIsQ0FBQyxFQUFDLHlDQUF5QyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNHLEVBQUU7VUFBQXFCLFFBQUEsRUFBRTtRQUFNLENBQWlCLENBQUMsRUFBQyxxQkFBcUIsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBSSxDQUFtQixDQUFDLEVBQUMsc0ZBQXNGLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBYyxRQUFBLEdBQUUseUJBQXlCLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtZQUFBdUIsUUFBQSxFQUFFO1VBQU0sQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1lBQUF1QixRQUFBLEVBQUU7VUFBTSxDQUFtQixDQUFDLEVBQUMsNkJBQTZCO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLCtDQUErQztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDSyxFQUFFO01BQUNvQixFQUFFLEVBQUMsNkVBQTZFO01BQUFELFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBNkUsQ0FBRSxDQUFDLEVBQUMsbUZBQW1GO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDUSxDQUFDO01BQUFnQixRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQXFELENBQXFCLENBQUMsRUFBQywrUkFBK1I7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNXLEtBQUs7TUFBQWEsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDZSxLQUFLO1FBQUFTLFFBQUEsZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDZ0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNjLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQUcsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBc0MsQ0FBaUIsQ0FBQztRQUFBLENBQWdCO01BQUMsQ0FBbUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksS0FBSztRQUFBWSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNnQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBSSxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQWlCLENBQW1CLENBQUMsRUFBQywwQkFBMEIsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBSSxDQUFtQixDQUFDLEVBQUMsVUFBVSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNVLE1BQU07Y0FBQWMsUUFBQSxHQUFFLFlBQVksZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2dCQUFBdUIsUUFBQSxFQUFFO2NBQWdCLENBQW1CLENBQUMsRUFBQyxPQUFPO1lBQUEsQ0FBcUIsQ0FBQyxFQUFDLHNCQUFzQixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFnRCxDQUFtQixDQUFDLEVBQUMsbUNBQW1DLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQWEsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBUyxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFTLENBQW1CLENBQUMsRUFBQyxnREFBZ0QsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBSSxDQUFtQixDQUFDLEVBQUMsMkNBQTJDLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBYSxDQUFxQixDQUFDLEVBQUMsVUFBVSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFtQixDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFVLENBQW1CLENBQUMsRUFBQywyREFBMkQsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBUyxDQUFtQixDQUFDLEVBQUMsZ0JBQWdCLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQVcsQ0FBbUIsQ0FBQyxFQUFDLDZJQUE2STtVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDZ0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQUksQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEdBQUUsWUFBWSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNVLE1BQU07Y0FBQWMsUUFBQSxHQUFFLFVBQVUsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2dCQUFBdUIsUUFBQSxFQUFFO2NBQU0sQ0FBbUIsQ0FBQztZQUFBLENBQW9CLENBQUMsRUFBQyxzQkFBc0IsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBTSxDQUFtQixDQUFDLEVBQUMsK0lBQStJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtjQUFBYyxRQUFBLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtnQkFBQXVCLFFBQUEsRUFBRTtjQUFhLENBQW1CO1lBQUMsQ0FBb0IsQ0FBQyxFQUFDLGdFQUFnRSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNVLE1BQU07Y0FBQWMsUUFBQSxHQUFFLFdBQVcsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2dCQUFBdUIsUUFBQSxFQUFFO2NBQUksQ0FBbUIsQ0FBQyxFQUFDLFFBQVE7WUFBQSxDQUFxQixDQUFDLEVBQUMsNEZBQTRGLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQVMsQ0FBbUIsQ0FBQyxFQUFDLGlIQUFpSCxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFZLENBQW1CLENBQUMsRUFBQyxvQ0FBb0MsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBSSxDQUFtQixDQUFDLEVBQUMsZ0VBQWdFO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNnQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBSSxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBeUQsQ0FBcUIsQ0FBQyxFQUFDLDhDQUE4QyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFrQixDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFXLENBQW1CLENBQUMsRUFBQyxXQUFXLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQW9CLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQWMsQ0FBbUIsQ0FBQyxFQUFDLHNDQUFzQyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFZLENBQW1CLENBQUMsRUFBQyxrQkFBa0IsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBTyxDQUFtQixDQUFDLEVBQUMsZUFBZSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFXLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQVcsQ0FBbUIsQ0FBQyxFQUFDLHlLQUF5SztVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDZ0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQUksQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQTJCLENBQXFCLENBQUMsRUFBQyw4QkFBOEIsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBVyxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFzQixDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFvQixDQUFtQixDQUFDLEVBQUMsWUFBWSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFhLENBQW1CLENBQUMsRUFBQyxpTkFBaU4sZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBUyxDQUFtQixDQUFDLEVBQUMsZ0ZBQWdGO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNnQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBSSxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBZ0QsQ0FBcUIsQ0FBQyxFQUFDLDBFQUEwRSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFzQixDQUFtQixDQUFDLEVBQUMsVUFBVSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUE4QixDQUFtQixDQUFDLEVBQUMsNE1BQTRNLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBaUMsQ0FBcUIsQ0FBQyxFQUFDLDBGQUEwRixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQXdDLENBQXFCLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQVcsQ0FBbUIsQ0FBQyxFQUFDLHNIQUFzSDtVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDO01BQUEsQ0FBbUIsQ0FBQztJQUFBLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1EsQ0FBQztNQUFBZ0IsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFpQixDQUFxQixDQUFDLEVBQUMsdURBQXVELGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQWdCLENBQW1CLENBQUMsRUFBQywwQkFBMEIsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBZSxDQUFtQixDQUFDLEVBQUMsc0JBQXNCLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQWEsQ0FBbUIsQ0FBQyxFQUFDLHFKQUFxSixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUF1QixDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFrQixDQUFtQixDQUFDLEVBQUMsVUFBVSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFTLENBQW1CLENBQUMsRUFBQyxnQ0FBZ0MsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBYSxDQUFtQixDQUFDLEVBQUMsb0xBQW9MLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBbUIsQ0FBcUIsQ0FBQyxFQUFDLGtIQUFrSDtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDbUIsRUFBRSxFQUFDLGlCQUFpQjtNQUFBRCxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQWlCLENBQUUsQ0FBQyxFQUFDLGVBQWU7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNXLEtBQUs7TUFBQWEsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDZSxLQUFLO1FBQUFTLFFBQUEsZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDZ0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNjLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQU0sQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBTSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0I7TUFBQyxDQUFtQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDWSxLQUFLO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2dCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFTLENBQWlCLENBQUMsbUJBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBa0IsQ0FBbUIsQ0FBQyxFQUFDLGlIQUFpSDtVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDZ0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQVMsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFxQixDQUFtQixDQUFDLEVBQUMsaUNBQWlDLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQUksQ0FBbUIsQ0FBQyxFQUFDLGtDQUFrQztVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDZ0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQVMsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUF1QixDQUFtQixDQUFDLEVBQUMseUNBQXlDLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQXFCLENBQW1CLENBQUMsRUFBQyxtREFBbUQ7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2dCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFTLENBQWlCLENBQUMsbUJBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBcUIsQ0FBbUIsQ0FBQyxFQUFDLHlNQUF5TTtVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDZ0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQVMsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFxQixDQUFtQixDQUFDLEVBQUMsMkJBQTJCLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQVcsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBVyxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFTLENBQW1CLENBQUMsRUFBQyx1QkFBdUIsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBZSxDQUFtQixDQUFDLEVBQUMsb0RBQW9EO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNnQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBUyxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQXlCLENBQW1CLENBQUMsRUFBQyxxSkFBcUo7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2dCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFTLENBQWlCLENBQUMsbUJBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBdUIsQ0FBbUIsQ0FBQyxFQUFDLHNCQUFzQixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFxQixDQUFtQixDQUFDLEVBQUMscUJBQXFCLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQVMsQ0FBbUIsQ0FBQztVQUFBLENBQWdCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDZ0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQVMsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEdBQUUsbUJBQW1CLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQXdCLENBQW1CLENBQUMsRUFBQyw4QkFBOEIsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBcUIsQ0FBbUIsQ0FBQyxFQUFDLHlCQUF5QjtVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDZ0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQVMsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFnQyxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFvQixDQUFtQixDQUFDLEVBQUMsb0NBQW9DO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNnQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBVSxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQWMsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBUyxDQUFtQixDQUFDLEVBQUMsa0VBQWtFO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUM7TUFBQSxDQUFtQixDQUFDO0lBQUEsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDUSxDQUFDO01BQUFnQixRQUFBLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1UsTUFBTTtRQUFBYyxRQUFBLEdBQUUsdURBQXVELGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLG1UQUFtVDtNQUFBLENBQXFCO0lBQUMsQ0FBZSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNLLEVBQUU7TUFBQ29CLEVBQUUsRUFBQyxnQkFBZ0I7TUFBQUQsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFnQixDQUFFLENBQUMsRUFBQyxnQkFBZ0I7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNRLENBQUM7TUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1UsTUFBTTtRQUFBYyxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFZLENBQW1CLENBQUMsRUFBQyxtQkFBbUI7TUFBQSxDQUFxQixDQUFDLEVBQUMsa0JBQWtCLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQTBCLENBQW1CLENBQUMsRUFBQyxzRUFBc0UsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUE2QyxDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNFLEdBQUc7UUFBQXNCLFFBQUEsR0FBRSxtREFBbUQsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBTSxDQUFtQixDQUFDO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDVSxNQUFNO1FBQUFjLFFBQUEsR0FBRSwrRUFBK0UsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBWSxDQUFtQixDQUFDO01BQUEsQ0FBb0IsQ0FBQyxFQUFDLFNBQVMsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBa0MsQ0FBbUIsQ0FBQyxFQUFDLG9CQUFvQixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFvQixDQUFtQixDQUFDLEVBQUMscWFBQXFhLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQVcsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNRLENBQUM7TUFBQWdCLFFBQUEsR0FBRSxXQUFXLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQVksQ0FBbUIsQ0FBQyxFQUFDLGdWQUFnVjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDbUIsRUFBRSxFQUFDLHFFQUFxRTtNQUFBRCxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQXFFLENBQUUsQ0FBQyxFQUFDLHlFQUF5RTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1EsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLDRJQUE0SSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFXLENBQW1CLENBQUMsRUFBQyw4SUFBOEk7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNTLEdBQUc7TUFBQWUsUUFBQSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7UUFBQzBCLFNBQVMsRUFBQyxlQUFlO1FBQUFILFFBQUEsRUFBRTtNQUF5SSxDQUFtQjtJQUFDLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1EsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLHNCQUFzQixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFnRSxDQUFtQixDQUFDLEVBQUMscUNBQXFDLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQUssQ0FBbUIsQ0FBQyxFQUFDLDhDQUE4QyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFJLENBQW1CLENBQUMsRUFBQyx5Q0FBeUMsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLDRCQUE0QixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFpQixDQUFtQixDQUFDLEVBQUMsb0RBQW9ELGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQWEsQ0FBbUIsQ0FBQyxFQUFDLGdGQUFnRjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1EsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLGNBQWMsZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDVSxNQUFNO1FBQUFjLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQUksQ0FBbUIsQ0FBQyxFQUFDLDZEQUE2RDtNQUFBLENBQXFCLENBQUMsRUFBQyxtQ0FBbUMsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBYSxDQUFtQixDQUFDLEVBQUMsK0NBQStDLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQUksQ0FBbUIsQ0FBQyxFQUFDLE9BQU8sZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBUSxDQUFtQixDQUFDLEVBQUMsYUFBYSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFJLENBQW1CLENBQUMsRUFBQywyTEFBMkwsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFXLENBQXFCLENBQUMsRUFBQyxvREFBb0Q7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNNLEVBQUU7TUFBQ21CLEVBQUUsRUFBQyw2RkFBNkY7TUFBQUQsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUE2RixDQUFFLENBQUMsRUFBQyxtR0FBbUc7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNRLENBQUM7TUFBQWdCLFFBQUEsRUFBRTtJQUF3SSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNpQixFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFxQixDQUFxQixDQUFDLEVBQUMsZ0NBQWdDLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLGFBQWEsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBOEIsQ0FBbUIsQ0FBQyxFQUFDLE9BQU8sZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDQyxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBTSxDQUFtQixDQUFDLEVBQUMseUdBQXlHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDTyxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTZDLENBQXFCLENBQUMsRUFBQywwS0FBMEs7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNPLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBaUcsQ0FBcUIsQ0FBQyxFQUFDLDBCQUEwQixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUE2RyxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQThELENBQXFCLENBQUMsRUFBQyx1RUFBdUUsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRyxFQUFFO1VBQUFxQixRQUFBLEVBQUU7UUFBZSxDQUFpQixDQUFDLEVBQUMsWUFBWSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNDLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFvQixDQUFtQixDQUFDLEVBQUMsNkJBQTZCLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBTyxDQUFxQixDQUFDLEVBQUMsb1FBQW9RLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQyxFQUFDLHVEQUF1RCxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTBILENBQXFCLENBQUMsRUFBQyxnUEFBZ1AsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUF5QixDQUFxQixDQUFDLEVBQUMsR0FBRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQztFQUFBLENBQUUsQ0FBQztBQUN2OHhCO0FBQ2UsU0FBU0ksVUFBVUEsQ0FBQzdCLEtBQUssR0FBRyxDQUFDLENBQUMsRUFBRTtFQUM3QyxNQUFNO0lBQUM4QixPQUFPLEVBQUVDO0VBQVMsQ0FBQyxHQUFHO0lBQzNCLEdBQUcsSUFBQVosNkJBQWtCLEVBQUMsQ0FBQztJQUN2QixHQUFHbkIsS0FBSyxDQUFDb0I7RUFDWCxDQUFDO0VBQ0QsT0FBT1csU0FBUyxnQkFBRyxJQUFBakMsV0FBQSxDQUFBNkIsR0FBQSxFQUFDSSxTQUFTO0lBQUEsR0FBSy9CLEtBQUs7SUFBQXlCLFFBQUEsZUFBRSxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDNUIsaUJBQWlCO01BQUEsR0FBS0M7SUFBSyxDQUFHO0VBQUMsQ0FBVyxDQUFDLEdBQUdELGlCQUFpQixDQUFDQyxLQUFLLENBQUM7QUFDbEg7QUFBQ2dDLEVBQUEsR0FOdUJILFVBQVU7QUFPbEMsU0FBU1Asb0JBQW9CQSxDQUFDSSxFQUFFLEVBQUVPLFNBQVMsRUFBRUMsS0FBSyxFQUFFO0VBQ2xELE1BQU0sSUFBSUMsS0FBSyxDQUFDLFdBQVcsSUFBSUYsU0FBUyxHQUFHLFdBQVcsR0FBRyxRQUFRLENBQUMsR0FBRyxJQUFJLEdBQUdQLEVBQUUsR0FBRyxvRUFBb0UsSUFBSVEsS0FBSyxHQUFHLHFDQUFxQyxHQUFHQSxLQUFLLEdBQUcsc0RBQXNELEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDaFI7QUFBQyxJQUFBRixFQUFBO0FBQUFJLFlBQUEsQ0FBQUosRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}