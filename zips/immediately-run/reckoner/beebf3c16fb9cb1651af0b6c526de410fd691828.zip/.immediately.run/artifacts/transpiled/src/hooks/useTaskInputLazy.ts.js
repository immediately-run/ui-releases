"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useTaskInputLazy = useTaskInputLazy;
var _react = require("react");
var _sdkTransportError = require("../app/sdkTransportError.ts");
function _getRequireWildcardCache(e) { if ("function" != typeof WeakMap) return null; var r = new WeakMap(), t = new WeakMap(); return (_getRequireWildcardCache = function (e) { return e ? t : r; })(e); }
function _interopRequireWildcard(e, r) { if (!r && e && e.__esModule) return e; if (null === e || "object" != typeof e && "function" != typeof e) return { default: e }; var t = _getRequireWildcardCache(r); if (t && t.has(e)) return t.get(e); var n = { __proto__: null }, a = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var u in e) if ("default" !== u && {}.hasOwnProperty.call(e, u)) { var i = a ? Object.getOwnPropertyDescriptor(e, u) : null; i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u]; } return n.default = e, t && t.set(e, n), n; } // The callee's task input, read WITHOUT a static value import of the SDK task
// surface: `@immediately-run/sdk/tasks` registers its `task-input` listener at
// module load, and this repo's platform guard (`src/app/platformGuards.test.ts`,
// DOCUMENT_NAVIGATOR_SPEC §4.1/DN-R5) keeps that surface behind dynamic imports
// forever — the same discipline `useEditFile` applies to `invokeTask`.
//
// The SDK exports no change-subscription for task input other than its own
// `useTaskInput` hook (static-import-only), and the host's delivery is TWO
// complementary re-send mitigations for the one-shot `task-input` wire message
// racing the callee's boot: R3-550's `taskInputGate` (merged, live on site-main
// main — taskInputDelivery.ts wired in SandboxListener.ts; re-sends on the first
// wire request after `success`, for callees that make one) and the bounded 1s/4s
// ladder past the compile edges (site-main#589's SandboxListener, unmerged as of
// this head — for callees, like this one, whose boot issues no post-`success`
// wire request at all: mounts read the injected local service, this poll is
// local, boot providers are receive-only). A short bounded
// poll — first read immediately, then 500ms until the input arrives or 30s pass —
// is the lazy-safe equivalent of the subscription: it settles past both
// mechanisms' windows and then stops forever. Off-host (plain `vite dev`,
// vitest) the dynamic import is safe (SDK R3-421) and the input stays null; the
// poll expires silently.
const POLL_INTERVAL_MS = 500;
const POLL_MAX_TRIES = 60; // 30s — comfortably past the host's delivery mitigations
// (compile-edge re-sends, the 1s/4s ladder, the post-`success` gate), without
// polling for the frame's life.

function useTaskInputLazy() {
  const [input, setInput] = (0, _react.useState)(null);
  (0, _react.useEffect)(() => {
    let alive = true;
    let tries = 0;
    const read = () => {
      void Promise.resolve().then(() => _interopRequireWildcard(require('@immediately-run/sdk/tasks'))).then(m => {
        if (!alive) return;
        const t = m.getTaskInput();
        if (t) {
          setInput(t);
          window.clearInterval(iv);
        }
      }).catch(e => {
        if (!alive) return;
        // DEFENSIVE (review round 4): pre-R3-421 SDKs threw the discriminated
        // no-host-transport error at module load off-host; since SDK R3-421
        // (≥0.57.3) the load resolves and `getTaskInput()` returns null, so the
        // benign off-host path is import-resolves/null and this branch is
        // unreachable from the real producer today. It stays because a thrown
        // no-host-transport remains the BENIGN shape should an older SDK or a
        // torn-down frame produce one. Any OTHER rejection (an on-host
        // module-eval failure, a half-torn-down frame) is a real fault in a
        // dispatched task frame — surface it rather than let the frame render
        // the demo document with no signal while the caller's overlay waits on
        // a completeTask that never comes. The discrimination lives in ONE home
        // (sdkTransportError.ts) shared with useEditFile §4.1.
        if (!(0, _sdkTransportError.isNoHostTransport)(e)) console.warn('[reckoner] task-input read failed:', e);
      });
    };
    const iv = window.setInterval(() => {
      tries += 1;
      if (tries > POLL_MAX_TRIES) {
        window.clearInterval(iv);
        return;
      }
      read();
    }, POLL_INTERVAL_MS);
    read();
    return () => {
      alive = false;
      window.clearInterval(iv);
    };
  }, []);
  return input;
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX3Nka1RyYW5zcG9ydEVycm9yIiwiX2dldFJlcXVpcmVXaWxkY2FyZENhY2hlIiwiZSIsIldlYWtNYXAiLCJyIiwidCIsIl9pbnRlcm9wUmVxdWlyZVdpbGRjYXJkIiwiX19lc01vZHVsZSIsImRlZmF1bHQiLCJoYXMiLCJnZXQiLCJuIiwiX19wcm90b19fIiwiYSIsIk9iamVjdCIsImRlZmluZVByb3BlcnR5IiwiZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yIiwidSIsImhhc093blByb3BlcnR5IiwiY2FsbCIsImkiLCJzZXQiLCJQT0xMX0lOVEVSVkFMX01TIiwiUE9MTF9NQVhfVFJJRVMiLCJ1c2VUYXNrSW5wdXRMYXp5IiwiaW5wdXQiLCJzZXRJbnB1dCIsInVzZVN0YXRlIiwidXNlRWZmZWN0IiwiYWxpdmUiLCJ0cmllcyIsInJlYWQiLCJQcm9taXNlIiwicmVzb2x2ZSIsInRoZW4iLCJtIiwiZ2V0VGFza0lucHV0Iiwid2luZG93IiwiY2xlYXJJbnRlcnZhbCIsIml2IiwiY2F0Y2giLCJpc05vSG9zdFRyYW5zcG9ydCIsImNvbnNvbGUiLCJ3YXJuIiwic2V0SW50ZXJ2YWwiXSwic291cmNlcyI6WyJ1c2VUYXNrSW5wdXRMYXp5LnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIFRoZSBjYWxsZWUncyB0YXNrIGlucHV0LCByZWFkIFdJVEhPVVQgYSBzdGF0aWMgdmFsdWUgaW1wb3J0IG9mIHRoZSBTREsgdGFza1xuLy8gc3VyZmFjZTogYEBpbW1lZGlhdGVseS1ydW4vc2RrL3Rhc2tzYCByZWdpc3RlcnMgaXRzIGB0YXNrLWlucHV0YCBsaXN0ZW5lciBhdFxuLy8gbW9kdWxlIGxvYWQsIGFuZCB0aGlzIHJlcG8ncyBwbGF0Zm9ybSBndWFyZCAoYHNyYy9hcHAvcGxhdGZvcm1HdWFyZHMudGVzdC50c2AsXG4vLyBET0NVTUVOVF9OQVZJR0FUT1JfU1BFQyDCpzQuMS9ETi1SNSkga2VlcHMgdGhhdCBzdXJmYWNlIGJlaGluZCBkeW5hbWljIGltcG9ydHNcbi8vIGZvcmV2ZXIg4oCUIHRoZSBzYW1lIGRpc2NpcGxpbmUgYHVzZUVkaXRGaWxlYCBhcHBsaWVzIHRvIGBpbnZva2VUYXNrYC5cbi8vXG4vLyBUaGUgU0RLIGV4cG9ydHMgbm8gY2hhbmdlLXN1YnNjcmlwdGlvbiBmb3IgdGFzayBpbnB1dCBvdGhlciB0aGFuIGl0cyBvd25cbi8vIGB1c2VUYXNrSW5wdXRgIGhvb2sgKHN0YXRpYy1pbXBvcnQtb25seSksIGFuZCB0aGUgaG9zdCdzIGRlbGl2ZXJ5IGlzIFRXT1xuLy8gY29tcGxlbWVudGFyeSByZS1zZW5kIG1pdGlnYXRpb25zIGZvciB0aGUgb25lLXNob3QgYHRhc2staW5wdXRgIHdpcmUgbWVzc2FnZVxuLy8gcmFjaW5nIHRoZSBjYWxsZWUncyBib290OiBSMy01NTAncyBgdGFza0lucHV0R2F0ZWAgKG1lcmdlZCwgbGl2ZSBvbiBzaXRlLW1haW5cbi8vIG1haW4g4oCUIHRhc2tJbnB1dERlbGl2ZXJ5LnRzIHdpcmVkIGluIFNhbmRib3hMaXN0ZW5lci50czsgcmUtc2VuZHMgb24gdGhlIGZpcnN0XG4vLyB3aXJlIHJlcXVlc3QgYWZ0ZXIgYHN1Y2Nlc3NgLCBmb3IgY2FsbGVlcyB0aGF0IG1ha2Ugb25lKSBhbmQgdGhlIGJvdW5kZWQgMXMvNHNcbi8vIGxhZGRlciBwYXN0IHRoZSBjb21waWxlIGVkZ2VzIChzaXRlLW1haW4jNTg5J3MgU2FuZGJveExpc3RlbmVyLCB1bm1lcmdlZCBhcyBvZlxuLy8gdGhpcyBoZWFkIOKAlCBmb3IgY2FsbGVlcywgbGlrZSB0aGlzIG9uZSwgd2hvc2UgYm9vdCBpc3N1ZXMgbm8gcG9zdC1gc3VjY2Vzc2Bcbi8vIHdpcmUgcmVxdWVzdCBhdCBhbGw6IG1vdW50cyByZWFkIHRoZSBpbmplY3RlZCBsb2NhbCBzZXJ2aWNlLCB0aGlzIHBvbGwgaXNcbi8vIGxvY2FsLCBib290IHByb3ZpZGVycyBhcmUgcmVjZWl2ZS1vbmx5KS4gQSBzaG9ydCBib3VuZGVkXG4vLyBwb2xsIOKAlCBmaXJzdCByZWFkIGltbWVkaWF0ZWx5LCB0aGVuIDUwMG1zIHVudGlsIHRoZSBpbnB1dCBhcnJpdmVzIG9yIDMwcyBwYXNzIOKAlFxuLy8gaXMgdGhlIGxhenktc2FmZSBlcXVpdmFsZW50IG9mIHRoZSBzdWJzY3JpcHRpb246IGl0IHNldHRsZXMgcGFzdCBib3RoXG4vLyBtZWNoYW5pc21zJyB3aW5kb3dzIGFuZCB0aGVuIHN0b3BzIGZvcmV2ZXIuIE9mZi1ob3N0IChwbGFpbiBgdml0ZSBkZXZgLFxuLy8gdml0ZXN0KSB0aGUgZHluYW1pYyBpbXBvcnQgaXMgc2FmZSAoU0RLIFIzLTQyMSkgYW5kIHRoZSBpbnB1dCBzdGF5cyBudWxsOyB0aGVcbi8vIHBvbGwgZXhwaXJlcyBzaWxlbnRseS5cblxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB0eXBlIHsgVGFza0lucHV0IH0gZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9zZGsvdGFza3MnO1xuaW1wb3J0IHsgaXNOb0hvc3RUcmFuc3BvcnQgfSBmcm9tICcuLi9hcHAvc2RrVHJhbnNwb3J0RXJyb3IudHMnO1xuXG5jb25zdCBQT0xMX0lOVEVSVkFMX01TID0gNTAwO1xuY29uc3QgUE9MTF9NQVhfVFJJRVMgPSA2MDsgLy8gMzBzIOKAlCBjb21mb3J0YWJseSBwYXN0IHRoZSBob3N0J3MgZGVsaXZlcnkgbWl0aWdhdGlvbnNcbi8vIChjb21waWxlLWVkZ2UgcmUtc2VuZHMsIHRoZSAxcy80cyBsYWRkZXIsIHRoZSBwb3N0LWBzdWNjZXNzYCBnYXRlKSwgd2l0aG91dFxuLy8gcG9sbGluZyBmb3IgdGhlIGZyYW1lJ3MgbGlmZS5cblxuZXhwb3J0IGZ1bmN0aW9uIHVzZVRhc2tJbnB1dExhenkoKTogVGFza0lucHV0IHwgbnVsbCB7XG4gIGNvbnN0IFtpbnB1dCwgc2V0SW5wdXRdID0gdXNlU3RhdGU8VGFza0lucHV0IHwgbnVsbD4obnVsbCk7XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgbGV0IGFsaXZlID0gdHJ1ZTtcbiAgICBsZXQgdHJpZXMgPSAwO1xuICAgIGNvbnN0IHJlYWQgPSAoKTogdm9pZCA9PiB7XG4gICAgICB2b2lkIGltcG9ydCgnQGltbWVkaWF0ZWx5LXJ1bi9zZGsvdGFza3MnKVxuICAgICAgICAudGhlbigobSkgPT4ge1xuICAgICAgICAgIGlmICghYWxpdmUpIHJldHVybjtcbiAgICAgICAgICBjb25zdCB0ID0gbS5nZXRUYXNrSW5wdXQoKTtcbiAgICAgICAgICBpZiAodCkge1xuICAgICAgICAgICAgc2V0SW5wdXQodCk7XG4gICAgICAgICAgICB3aW5kb3cuY2xlYXJJbnRlcnZhbChpdik7XG4gICAgICAgICAgfVxuICAgICAgICB9KVxuICAgICAgICAuY2F0Y2goKGU6IHVua25vd24pID0+IHtcbiAgICAgICAgICBpZiAoIWFsaXZlKSByZXR1cm47XG4gICAgICAgICAgLy8gREVGRU5TSVZFIChyZXZpZXcgcm91bmQgNCk6IHByZS1SMy00MjEgU0RLcyB0aHJldyB0aGUgZGlzY3JpbWluYXRlZFxuICAgICAgICAgIC8vIG5vLWhvc3QtdHJhbnNwb3J0IGVycm9yIGF0IG1vZHVsZSBsb2FkIG9mZi1ob3N0OyBzaW5jZSBTREsgUjMtNDIxXG4gICAgICAgICAgLy8gKOKJpTAuNTcuMykgdGhlIGxvYWQgcmVzb2x2ZXMgYW5kIGBnZXRUYXNrSW5wdXQoKWAgcmV0dXJucyBudWxsLCBzbyB0aGVcbiAgICAgICAgICAvLyBiZW5pZ24gb2ZmLWhvc3QgcGF0aCBpcyBpbXBvcnQtcmVzb2x2ZXMvbnVsbCBhbmQgdGhpcyBicmFuY2ggaXNcbiAgICAgICAgICAvLyB1bnJlYWNoYWJsZSBmcm9tIHRoZSByZWFsIHByb2R1Y2VyIHRvZGF5LiBJdCBzdGF5cyBiZWNhdXNlIGEgdGhyb3duXG4gICAgICAgICAgLy8gbm8taG9zdC10cmFuc3BvcnQgcmVtYWlucyB0aGUgQkVOSUdOIHNoYXBlIHNob3VsZCBhbiBvbGRlciBTREsgb3IgYVxuICAgICAgICAgIC8vIHRvcm4tZG93biBmcmFtZSBwcm9kdWNlIG9uZS4gQW55IE9USEVSIHJlamVjdGlvbiAoYW4gb24taG9zdFxuICAgICAgICAgIC8vIG1vZHVsZS1ldmFsIGZhaWx1cmUsIGEgaGFsZi10b3JuLWRvd24gZnJhbWUpIGlzIGEgcmVhbCBmYXVsdCBpbiBhXG4gICAgICAgICAgLy8gZGlzcGF0Y2hlZCB0YXNrIGZyYW1lIOKAlCBzdXJmYWNlIGl0IHJhdGhlciB0aGFuIGxldCB0aGUgZnJhbWUgcmVuZGVyXG4gICAgICAgICAgLy8gdGhlIGRlbW8gZG9jdW1lbnQgd2l0aCBubyBzaWduYWwgd2hpbGUgdGhlIGNhbGxlcidzIG92ZXJsYXkgd2FpdHMgb25cbiAgICAgICAgICAvLyBhIGNvbXBsZXRlVGFzayB0aGF0IG5ldmVyIGNvbWVzLiBUaGUgZGlzY3JpbWluYXRpb24gbGl2ZXMgaW4gT05FIGhvbWVcbiAgICAgICAgICAvLyAoc2RrVHJhbnNwb3J0RXJyb3IudHMpIHNoYXJlZCB3aXRoIHVzZUVkaXRGaWxlIMKnNC4xLlxuICAgICAgICAgIGlmICghaXNOb0hvc3RUcmFuc3BvcnQoZSkpIGNvbnNvbGUud2FybignW3JlY2tvbmVyXSB0YXNrLWlucHV0IHJlYWQgZmFpbGVkOicsIGUpO1xuICAgICAgICB9KTtcbiAgICB9O1xuICAgIGNvbnN0IGl2ID0gd2luZG93LnNldEludGVydmFsKCgpID0+IHtcbiAgICAgIHRyaWVzICs9IDE7XG4gICAgICBpZiAodHJpZXMgPiBQT0xMX01BWF9UUklFUykge1xuICAgICAgICB3aW5kb3cuY2xlYXJJbnRlcnZhbChpdik7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIHJlYWQoKTtcbiAgICB9LCBQT0xMX0lOVEVSVkFMX01TKTtcbiAgICByZWFkKCk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGFsaXZlID0gZmFsc2U7XG4gICAgICB3aW5kb3cuY2xlYXJJbnRlcnZhbChpdik7XG4gICAgfTtcbiAgfSwgW10pO1xuICByZXR1cm4gaW5wdXQ7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQXNCQSxJQUFBQSxNQUFBLEdBQUFDLE9BQUE7QUFFQSxJQUFBQyxrQkFBQSxHQUFBRCxPQUFBO0FBQWdFLFNBQUFFLHlCQUFBQyxDQUFBLDZCQUFBQyxPQUFBLG1CQUFBQyxDQUFBLE9BQUFELE9BQUEsSUFBQUUsQ0FBQSxPQUFBRixPQUFBLFlBQUFGLHdCQUFBLFlBQUFBLENBQUFDLENBQUEsV0FBQUEsQ0FBQSxHQUFBRyxDQUFBLEdBQUFELENBQUEsS0FBQUYsQ0FBQTtBQUFBLFNBQUFJLHdCQUFBSixDQUFBLEVBQUFFLENBQUEsU0FBQUEsQ0FBQSxJQUFBRixDQUFBLElBQUFBLENBQUEsQ0FBQUssVUFBQSxTQUFBTCxDQUFBLGVBQUFBLENBQUEsdUJBQUFBLENBQUEseUJBQUFBLENBQUEsV0FBQU0sT0FBQSxFQUFBTixDQUFBLFFBQUFHLENBQUEsR0FBQUosd0JBQUEsQ0FBQUcsQ0FBQSxPQUFBQyxDQUFBLElBQUFBLENBQUEsQ0FBQUksR0FBQSxDQUFBUCxDQUFBLFVBQUFHLENBQUEsQ0FBQUssR0FBQSxDQUFBUixDQUFBLE9BQUFTLENBQUEsS0FBQUMsU0FBQSxVQUFBQyxDQUFBLEdBQUFDLE1BQUEsQ0FBQUMsY0FBQSxJQUFBRCxNQUFBLENBQUFFLHdCQUFBLFdBQUFDLENBQUEsSUFBQWYsQ0FBQSxvQkFBQWUsQ0FBQSxPQUFBQyxjQUFBLENBQUFDLElBQUEsQ0FBQWpCLENBQUEsRUFBQWUsQ0FBQSxTQUFBRyxDQUFBLEdBQUFQLENBQUEsR0FBQUMsTUFBQSxDQUFBRSx3QkFBQSxDQUFBZCxDQUFBLEVBQUFlLENBQUEsVUFBQUcsQ0FBQSxLQUFBQSxDQUFBLENBQUFWLEdBQUEsSUFBQVUsQ0FBQSxDQUFBQyxHQUFBLElBQUFQLE1BQUEsQ0FBQUMsY0FBQSxDQUFBSixDQUFBLEVBQUFNLENBQUEsRUFBQUcsQ0FBQSxJQUFBVCxDQUFBLENBQUFNLENBQUEsSUFBQWYsQ0FBQSxDQUFBZSxDQUFBLFlBQUFOLENBQUEsQ0FBQUgsT0FBQSxHQUFBTixDQUFBLEVBQUFHLENBQUEsSUFBQUEsQ0FBQSxDQUFBZ0IsR0FBQSxDQUFBbkIsQ0FBQSxFQUFBUyxDQUFBLEdBQUFBLENBQUEsSUF4QmhFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQU1BLE1BQU1XLGdCQUFnQixHQUFHLEdBQUc7QUFDNUIsTUFBTUMsY0FBYyxHQUFHLEVBQUUsQ0FBQyxDQUFDO0FBQzNCO0FBQ0E7O0FBRU8sU0FBU0MsZ0JBQWdCQSxDQUFBLEVBQXFCO0VBQ25ELE1BQU0sQ0FBQ0MsS0FBSyxFQUFFQyxRQUFRLENBQUMsR0FBRyxJQUFBQyxlQUFRLEVBQW1CLElBQUksQ0FBQztFQUMxRCxJQUFBQyxnQkFBUyxFQUFDLE1BQU07SUFDZCxJQUFJQyxLQUFLLEdBQUcsSUFBSTtJQUNoQixJQUFJQyxLQUFLLEdBQUcsQ0FBQztJQUNiLE1BQU1DLElBQUksR0FBR0EsQ0FBQSxLQUFZO01BQ3ZCLEtBQUtDLE9BQUEsQ0FBQUMsT0FBQSxHQUFBQyxJQUFBLE9BQUE1Qix1QkFBQSxDQUFBUCxPQUFBLENBQU8sNEJBQTRCLElBQ3JDbUMsSUFBSSxDQUFFQyxDQUFDLElBQUs7UUFDWCxJQUFJLENBQUNOLEtBQUssRUFBRTtRQUNaLE1BQU14QixDQUFDLEdBQUc4QixDQUFDLENBQUNDLFlBQVksQ0FBQyxDQUFDO1FBQzFCLElBQUkvQixDQUFDLEVBQUU7VUFDTHFCLFFBQVEsQ0FBQ3JCLENBQUMsQ0FBQztVQUNYZ0MsTUFBTSxDQUFDQyxhQUFhLENBQUNDLEVBQUUsQ0FBQztRQUMxQjtNQUNGLENBQUMsQ0FBQyxDQUNEQyxLQUFLLENBQUV0QyxDQUFVLElBQUs7UUFDckIsSUFBSSxDQUFDMkIsS0FBSyxFQUFFO1FBQ1o7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0EsSUFBSSxDQUFDLElBQUFZLG9DQUFpQixFQUFDdkMsQ0FBQyxDQUFDLEVBQUV3QyxPQUFPLENBQUNDLElBQUksQ0FBQyxvQ0FBb0MsRUFBRXpDLENBQUMsQ0FBQztNQUNsRixDQUFDLENBQUM7SUFDTixDQUFDO0lBQ0QsTUFBTXFDLEVBQUUsR0FBR0YsTUFBTSxDQUFDTyxXQUFXLENBQUMsTUFBTTtNQUNsQ2QsS0FBSyxJQUFJLENBQUM7TUFDVixJQUFJQSxLQUFLLEdBQUdQLGNBQWMsRUFBRTtRQUMxQmMsTUFBTSxDQUFDQyxhQUFhLENBQUNDLEVBQUUsQ0FBQztRQUN4QjtNQUNGO01BQ0FSLElBQUksQ0FBQyxDQUFDO0lBQ1IsQ0FBQyxFQUFFVCxnQkFBZ0IsQ0FBQztJQUNwQlMsSUFBSSxDQUFDLENBQUM7SUFDTixPQUFPLE1BQU07TUFDWEYsS0FBSyxHQUFHLEtBQUs7TUFDYlEsTUFBTSxDQUFDQyxhQUFhLENBQUNDLEVBQUUsQ0FBQztJQUMxQixDQUFDO0VBQ0gsQ0FBQyxFQUFFLEVBQUUsQ0FBQztFQUNOLE9BQU9kLEtBQUs7QUFDZCIsImlnbm9yZUxpc3QiOltdfQ==