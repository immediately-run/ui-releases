"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.TASK_DELEGATION_MOUNT_TYPE = exports.OPEN_WORKBOOK_TASK = exports.CONTENT_MOUNT_TYPE = void 0;
exports.resolveWorkbookMount = resolveWorkbookMount;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
// The `open-workbook` provider — Reckoner as a dispatched viewer (the R3-169 pattern,
// after Grove's `open-wiki`). A repo whose `immediately.run.json` marker declares
// `opensWith: { task: "open-workbook" }` is dispatched by the host: the corpus is
// mounted for us (the mount IS the grant — everything here is downstream of authority
// we never asked for and cannot widen) and this app renders it instead of the bundled
// demo document.
//
// Two dispatch shapes resolve here (R3-754):
//
//   • v1, the REPO-LOAD shape — the URL named a workbook repo; the mount carries
//     `type: 'content'` (R3-172 — same discovery rule as Grove's).
//   • v2, the TASK-INVOCATION shape — another app (file-explorer's folder
//     affordance, R3-267) `invokeTask`-ed this contract with a `dir` capability.
//     Probed live on the venue before coding (R3-754's P1/P2 discipline — the
//     second host contract, not a guess): `getTaskInput()` returns
//     `{ task: 'open-workbook', params: { dir: '/task/<slot>/dir' } }` — the host
//     REWRITES the caller's `dir` param to the minted chroot path — and the
//     delegation arrives as the one mount
//     `{ path: '/task/<slot>/dir', type: 'task-delegation', id: <same>, mode }`,
//     `mode` being `min(caller grant, cap, contract)` (an `ro` caller folder
//     yields an `ro` delegation; the edit door's positive-`rw` gate follows).
//
// The marker names the CONTRACT, never this app, so a rebind to a fork keeps
// working either way.

/** The contract this app provides (package.json `provides` must match). */
const OPEN_WORKBOOK_TASK = exports.OPEN_WORKBOOK_TASK = 'open-workbook';

/** The mount `type` the host stamps on a corpus it dispatched by repo load (R3-172). */
const CONTENT_MOUNT_TYPE = exports.CONTENT_MOUNT_TYPE = 'content';

/** The mount `type` the host stamps on a task-delegated chroot (R3-754, probed live). */
const TASK_DELEGATION_MOUNT_TYPE = exports.TASK_DELEGATION_MOUNT_TYPE = 'task-delegation';
/**
 * Where the dispatched workbook lives, from the mount set (+ the task input, for
 * the task-invocation shape) — pure, so the whole resolution is testable without a
 * host. A repo-load dispatch is the one mount marked `type: 'content'` (keyed on
 * the mark, NOT on "the only foreign mount" — that guess reads wrong the moment
 * the viewer also holds a space or a worktree). A task-invocation dispatch is the
 * one `task-delegation` mount at the input's rewritten `dir` path — keyed on the
 * task input, the task shape's mark, with the same no-guessing discipline. Two
 * marked mounts (either shape), or one of EACH shape claiming the same frame, is
 * a host bug we refuse rather than paper over.
 *
 * The ok variant carries the MOUNT itself (not just its path) since R3-447: Part B's
 * edit affordance derives writability from `mode` (the positive `rw` check R-EFE-1
 * prescribes — never "absent ⇒ writable") and addresses its `capFile` delegation with
 * the descriptor's `id`, which the live host contract established as the universal
 * `scheme:locator` form (`content:owner/repo`) for repo-load and as the chroot path
 * (`/task/<slot>/dir`) for the task shape. The host's grant lookup matches that
 * id exactly; there is no fallback, so the door fails closed on a mount without one.
 */
function resolveWorkbookMount(mounts, taskInput) {
  const marked = mounts.filter(m => m.type === CONTENT_MOUNT_TYPE);

  // The task-invocation shape: keyed on the input (this frame was invoked AS this
  // contract), matched against the delegation the host minted for the `dir` param.
  // An input for any other task, or one whose `dir` finds no matching delegation,
  // resolves nothing here — the repo-load mark below is then the only shape left.
  let taskMatch = [];
  if (taskInput && taskInput.task === OPEN_WORKBOOK_TASK) {
    const dir = taskInput.params?.dir;
    if (typeof dir === 'string') {
      taskMatch = mounts.filter(m => m.type === TASK_DELEGATION_MOUNT_TYPE && (m.path === dir || m.id === dir));
      if (taskMatch.length > 1) return {
        ok: false,
        reason: 'ambiguous'
      };
    }
  }
  if (taskMatch.length === 1) {
    // Both shapes claiming one frame cannot both be the document — refuse.
    if (marked.length > 0) return {
      ok: false,
      reason: 'ambiguous'
    };
    return {
      ok: true,
      root: taskMatch[0].path,
      via: 'task-invocation',
      mount: taskMatch[0]
    };
  }
  if (marked.length === 1) return {
    ok: true,
    root: marked[0].path,
    via: 'repo-load',
    mount: marked[0]
  };
  if (marked.length > 1) return {
    ok: false,
    reason: 'ambiguous'
  };
  return {
    ok: false,
    reason: 'not-dispatched'
  };
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJPUEVOX1dPUktCT09LX1RBU0siLCJleHBvcnRzIiwiQ09OVEVOVF9NT1VOVF9UWVBFIiwiVEFTS19ERUxFR0FUSU9OX01PVU5UX1RZUEUiLCJyZXNvbHZlV29ya2Jvb2tNb3VudCIsIm1vdW50cyIsInRhc2tJbnB1dCIsIm1hcmtlZCIsImZpbHRlciIsIm0iLCJ0eXBlIiwidGFza01hdGNoIiwidGFzayIsImRpciIsInBhcmFtcyIsInBhdGgiLCJpZCIsImxlbmd0aCIsIm9rIiwicmVhc29uIiwicm9vdCIsInZpYSIsIm1vdW50Il0sInNvdXJjZXMiOlsiZGlzcGF0Y2gudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gVGhlIGBvcGVuLXdvcmtib29rYCBwcm92aWRlciDigJQgUmVja29uZXIgYXMgYSBkaXNwYXRjaGVkIHZpZXdlciAodGhlIFIzLTE2OSBwYXR0ZXJuLFxuLy8gYWZ0ZXIgR3JvdmUncyBgb3Blbi13aWtpYCkuIEEgcmVwbyB3aG9zZSBgaW1tZWRpYXRlbHkucnVuLmpzb25gIG1hcmtlciBkZWNsYXJlc1xuLy8gYG9wZW5zV2l0aDogeyB0YXNrOiBcIm9wZW4td29ya2Jvb2tcIiB9YCBpcyBkaXNwYXRjaGVkIGJ5IHRoZSBob3N0OiB0aGUgY29ycHVzIGlzXG4vLyBtb3VudGVkIGZvciB1cyAodGhlIG1vdW50IElTIHRoZSBncmFudCDigJQgZXZlcnl0aGluZyBoZXJlIGlzIGRvd25zdHJlYW0gb2YgYXV0aG9yaXR5XG4vLyB3ZSBuZXZlciBhc2tlZCBmb3IgYW5kIGNhbm5vdCB3aWRlbikgYW5kIHRoaXMgYXBwIHJlbmRlcnMgaXQgaW5zdGVhZCBvZiB0aGUgYnVuZGxlZFxuLy8gZGVtbyBkb2N1bWVudC5cbi8vXG4vLyBUd28gZGlzcGF0Y2ggc2hhcGVzIHJlc29sdmUgaGVyZSAoUjMtNzU0KTpcbi8vXG4vLyAgIOKAoiB2MSwgdGhlIFJFUE8tTE9BRCBzaGFwZSDigJQgdGhlIFVSTCBuYW1lZCBhIHdvcmtib29rIHJlcG87IHRoZSBtb3VudCBjYXJyaWVzXG4vLyAgICAgYHR5cGU6ICdjb250ZW50J2AgKFIzLTE3MiDigJQgc2FtZSBkaXNjb3ZlcnkgcnVsZSBhcyBHcm92ZSdzKS5cbi8vICAg4oCiIHYyLCB0aGUgVEFTSy1JTlZPQ0FUSU9OIHNoYXBlIOKAlCBhbm90aGVyIGFwcCAoZmlsZS1leHBsb3JlcidzIGZvbGRlclxuLy8gICAgIGFmZm9yZGFuY2UsIFIzLTI2NykgYGludm9rZVRhc2tgLWVkIHRoaXMgY29udHJhY3Qgd2l0aCBhIGBkaXJgIGNhcGFiaWxpdHkuXG4vLyAgICAgUHJvYmVkIGxpdmUgb24gdGhlIHZlbnVlIGJlZm9yZSBjb2RpbmcgKFIzLTc1NCdzIFAxL1AyIGRpc2NpcGxpbmUg4oCUIHRoZVxuLy8gICAgIHNlY29uZCBob3N0IGNvbnRyYWN0LCBub3QgYSBndWVzcyk6IGBnZXRUYXNrSW5wdXQoKWAgcmV0dXJuc1xuLy8gICAgIGB7IHRhc2s6ICdvcGVuLXdvcmtib29rJywgcGFyYW1zOiB7IGRpcjogJy90YXNrLzxzbG90Pi9kaXInIH0gfWAg4oCUIHRoZSBob3N0XG4vLyAgICAgUkVXUklURVMgdGhlIGNhbGxlcidzIGBkaXJgIHBhcmFtIHRvIHRoZSBtaW50ZWQgY2hyb290IHBhdGgg4oCUIGFuZCB0aGVcbi8vICAgICBkZWxlZ2F0aW9uIGFycml2ZXMgYXMgdGhlIG9uZSBtb3VudFxuLy8gICAgIGB7IHBhdGg6ICcvdGFzay88c2xvdD4vZGlyJywgdHlwZTogJ3Rhc2stZGVsZWdhdGlvbicsIGlkOiA8c2FtZT4sIG1vZGUgfWAsXG4vLyAgICAgYG1vZGVgIGJlaW5nIGBtaW4oY2FsbGVyIGdyYW50LCBjYXAsIGNvbnRyYWN0KWAgKGFuIGByb2AgY2FsbGVyIGZvbGRlclxuLy8gICAgIHlpZWxkcyBhbiBgcm9gIGRlbGVnYXRpb247IHRoZSBlZGl0IGRvb3IncyBwb3NpdGl2ZS1gcndgIGdhdGUgZm9sbG93cykuXG4vL1xuLy8gVGhlIG1hcmtlciBuYW1lcyB0aGUgQ09OVFJBQ1QsIG5ldmVyIHRoaXMgYXBwLCBzbyBhIHJlYmluZCB0byBhIGZvcmsga2VlcHNcbi8vIHdvcmtpbmcgZWl0aGVyIHdheS5cblxuaW1wb3J0IHR5cGUgeyBTYW5kYm94TW91bnQgfSBmcm9tICdAaW1tZWRpYXRlbHktcnVuL3Nkayc7XG5pbXBvcnQgdHlwZSB7IFRhc2tJbnB1dCB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrL3Rhc2tzJztcblxuLyoqIFRoZSBjb250cmFjdCB0aGlzIGFwcCBwcm92aWRlcyAocGFja2FnZS5qc29uIGBwcm92aWRlc2AgbXVzdCBtYXRjaCkuICovXG5leHBvcnQgY29uc3QgT1BFTl9XT1JLQk9PS19UQVNLID0gJ29wZW4td29ya2Jvb2snO1xuXG4vKiogVGhlIG1vdW50IGB0eXBlYCB0aGUgaG9zdCBzdGFtcHMgb24gYSBjb3JwdXMgaXQgZGlzcGF0Y2hlZCBieSByZXBvIGxvYWQgKFIzLTE3MikuICovXG5leHBvcnQgY29uc3QgQ09OVEVOVF9NT1VOVF9UWVBFID0gJ2NvbnRlbnQnO1xuXG4vKiogVGhlIG1vdW50IGB0eXBlYCB0aGUgaG9zdCBzdGFtcHMgb24gYSB0YXNrLWRlbGVnYXRlZCBjaHJvb3QgKFIzLTc1NCwgcHJvYmVkIGxpdmUpLiAqL1xuZXhwb3J0IGNvbnN0IFRBU0tfREVMRUdBVElPTl9NT1VOVF9UWVBFID0gJ3Rhc2stZGVsZWdhdGlvbic7XG5cbmV4cG9ydCB0eXBlIFdvcmtib29rUmVzb2x1dGlvbiA9XG4gIHwgeyBvazogdHJ1ZTsgcm9vdDogc3RyaW5nOyB2aWE6ICdyZXBvLWxvYWQnIHwgJ3Rhc2staW52b2NhdGlvbic7IG1vdW50OiBTYW5kYm94TW91bnQgfVxuICB8IHsgb2s6IGZhbHNlOyByZWFzb246ICdub3QtZGlzcGF0Y2hlZCcgfCAnYW1iaWd1b3VzJyB9O1xuXG4vKipcbiAqIFdoZXJlIHRoZSBkaXNwYXRjaGVkIHdvcmtib29rIGxpdmVzLCBmcm9tIHRoZSBtb3VudCBzZXQgKCsgdGhlIHRhc2sgaW5wdXQsIGZvclxuICogdGhlIHRhc2staW52b2NhdGlvbiBzaGFwZSkg4oCUIHB1cmUsIHNvIHRoZSB3aG9sZSByZXNvbHV0aW9uIGlzIHRlc3RhYmxlIHdpdGhvdXQgYVxuICogaG9zdC4gQSByZXBvLWxvYWQgZGlzcGF0Y2ggaXMgdGhlIG9uZSBtb3VudCBtYXJrZWQgYHR5cGU6ICdjb250ZW50J2AgKGtleWVkIG9uXG4gKiB0aGUgbWFyaywgTk9UIG9uIFwidGhlIG9ubHkgZm9yZWlnbiBtb3VudFwiIOKAlCB0aGF0IGd1ZXNzIHJlYWRzIHdyb25nIHRoZSBtb21lbnRcbiAqIHRoZSB2aWV3ZXIgYWxzbyBob2xkcyBhIHNwYWNlIG9yIGEgd29ya3RyZWUpLiBBIHRhc2staW52b2NhdGlvbiBkaXNwYXRjaCBpcyB0aGVcbiAqIG9uZSBgdGFzay1kZWxlZ2F0aW9uYCBtb3VudCBhdCB0aGUgaW5wdXQncyByZXdyaXR0ZW4gYGRpcmAgcGF0aCDigJQga2V5ZWQgb24gdGhlXG4gKiB0YXNrIGlucHV0LCB0aGUgdGFzayBzaGFwZSdzIG1hcmssIHdpdGggdGhlIHNhbWUgbm8tZ3Vlc3NpbmcgZGlzY2lwbGluZS4gVHdvXG4gKiBtYXJrZWQgbW91bnRzIChlaXRoZXIgc2hhcGUpLCBvciBvbmUgb2YgRUFDSCBzaGFwZSBjbGFpbWluZyB0aGUgc2FtZSBmcmFtZSwgaXNcbiAqIGEgaG9zdCBidWcgd2UgcmVmdXNlIHJhdGhlciB0aGFuIHBhcGVyIG92ZXIuXG4gKlxuICogVGhlIG9rIHZhcmlhbnQgY2FycmllcyB0aGUgTU9VTlQgaXRzZWxmIChub3QganVzdCBpdHMgcGF0aCkgc2luY2UgUjMtNDQ3OiBQYXJ0IEInc1xuICogZWRpdCBhZmZvcmRhbmNlIGRlcml2ZXMgd3JpdGFiaWxpdHkgZnJvbSBgbW9kZWAgKHRoZSBwb3NpdGl2ZSBgcndgIGNoZWNrIFItRUZFLTFcbiAqIHByZXNjcmliZXMg4oCUIG5ldmVyIFwiYWJzZW50IOKHkiB3cml0YWJsZVwiKSBhbmQgYWRkcmVzc2VzIGl0cyBgY2FwRmlsZWAgZGVsZWdhdGlvbiB3aXRoXG4gKiB0aGUgZGVzY3JpcHRvcidzIGBpZGAsIHdoaWNoIHRoZSBsaXZlIGhvc3QgY29udHJhY3QgZXN0YWJsaXNoZWQgYXMgdGhlIHVuaXZlcnNhbFxuICogYHNjaGVtZTpsb2NhdG9yYCBmb3JtIChgY29udGVudDpvd25lci9yZXBvYCkgZm9yIHJlcG8tbG9hZCBhbmQgYXMgdGhlIGNocm9vdCBwYXRoXG4gKiAoYC90YXNrLzxzbG90Pi9kaXJgKSBmb3IgdGhlIHRhc2sgc2hhcGUuIFRoZSBob3N0J3MgZ3JhbnQgbG9va3VwIG1hdGNoZXMgdGhhdFxuICogaWQgZXhhY3RseTsgdGhlcmUgaXMgbm8gZmFsbGJhY2ssIHNvIHRoZSBkb29yIGZhaWxzIGNsb3NlZCBvbiBhIG1vdW50IHdpdGhvdXQgb25lLlxuICovXG5leHBvcnQgZnVuY3Rpb24gcmVzb2x2ZVdvcmtib29rTW91bnQoXG4gIG1vdW50czogcmVhZG9ubHkgU2FuZGJveE1vdW50W10sXG4gIHRhc2tJbnB1dD86IFRhc2tJbnB1dCB8IG51bGwsXG4pOiBXb3JrYm9va1Jlc29sdXRpb24ge1xuICBjb25zdCBtYXJrZWQgPSBtb3VudHMuZmlsdGVyKChtKSA9PiBtLnR5cGUgPT09IENPTlRFTlRfTU9VTlRfVFlQRSk7XG5cbiAgLy8gVGhlIHRhc2staW52b2NhdGlvbiBzaGFwZToga2V5ZWQgb24gdGhlIGlucHV0ICh0aGlzIGZyYW1lIHdhcyBpbnZva2VkIEFTIHRoaXNcbiAgLy8gY29udHJhY3QpLCBtYXRjaGVkIGFnYWluc3QgdGhlIGRlbGVnYXRpb24gdGhlIGhvc3QgbWludGVkIGZvciB0aGUgYGRpcmAgcGFyYW0uXG4gIC8vIEFuIGlucHV0IGZvciBhbnkgb3RoZXIgdGFzaywgb3Igb25lIHdob3NlIGBkaXJgIGZpbmRzIG5vIG1hdGNoaW5nIGRlbGVnYXRpb24sXG4gIC8vIHJlc29sdmVzIG5vdGhpbmcgaGVyZSDigJQgdGhlIHJlcG8tbG9hZCBtYXJrIGJlbG93IGlzIHRoZW4gdGhlIG9ubHkgc2hhcGUgbGVmdC5cbiAgbGV0IHRhc2tNYXRjaDogcmVhZG9ubHkgU2FuZGJveE1vdW50W10gPSBbXTtcbiAgaWYgKHRhc2tJbnB1dCAmJiB0YXNrSW5wdXQudGFzayA9PT0gT1BFTl9XT1JLQk9PS19UQVNLKSB7XG4gICAgY29uc3QgZGlyID0gdGFza0lucHV0LnBhcmFtcz8uZGlyO1xuICAgIGlmICh0eXBlb2YgZGlyID09PSAnc3RyaW5nJykge1xuICAgICAgdGFza01hdGNoID0gbW91bnRzLmZpbHRlcihcbiAgICAgICAgKG0pID0+IG0udHlwZSA9PT0gVEFTS19ERUxFR0FUSU9OX01PVU5UX1RZUEUgJiYgKG0ucGF0aCA9PT0gZGlyIHx8IG0uaWQgPT09IGRpciksXG4gICAgICApO1xuICAgICAgaWYgKHRhc2tNYXRjaC5sZW5ndGggPiAxKSByZXR1cm4geyBvazogZmFsc2UsIHJlYXNvbjogJ2FtYmlndW91cycgfTtcbiAgICB9XG4gIH1cblxuICBpZiAodGFza01hdGNoLmxlbmd0aCA9PT0gMSkge1xuICAgIC8vIEJvdGggc2hhcGVzIGNsYWltaW5nIG9uZSBmcmFtZSBjYW5ub3QgYm90aCBiZSB0aGUgZG9jdW1lbnQg4oCUIHJlZnVzZS5cbiAgICBpZiAobWFya2VkLmxlbmd0aCA+IDApIHJldHVybiB7IG9rOiBmYWxzZSwgcmVhc29uOiAnYW1iaWd1b3VzJyB9O1xuICAgIHJldHVybiB7IG9rOiB0cnVlLCByb290OiB0YXNrTWF0Y2hbMF0ucGF0aCwgdmlhOiAndGFzay1pbnZvY2F0aW9uJywgbW91bnQ6IHRhc2tNYXRjaFswXSB9O1xuICB9XG4gIGlmIChtYXJrZWQubGVuZ3RoID09PSAxKSByZXR1cm4geyBvazogdHJ1ZSwgcm9vdDogbWFya2VkWzBdLnBhdGgsIHZpYTogJ3JlcG8tbG9hZCcsIG1vdW50OiBtYXJrZWRbMF0gfTtcbiAgaWYgKG1hcmtlZC5sZW5ndGggPiAxKSByZXR1cm4geyBvazogZmFsc2UsIHJlYXNvbjogJ2FtYmlndW91cycgfTtcbiAgcmV0dXJuIHsgb2s6IGZhbHNlLCByZWFzb246ICdub3QtZGlzcGF0Y2hlZCcgfTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUtBO0FBQ08sTUFBTUEsa0JBQWtCLEdBQUFDLE9BQUEsQ0FBQUQsa0JBQUEsR0FBRyxlQUFlOztBQUVqRDtBQUNPLE1BQU1FLGtCQUFrQixHQUFBRCxPQUFBLENBQUFDLGtCQUFBLEdBQUcsU0FBUzs7QUFFM0M7QUFDTyxNQUFNQywwQkFBMEIsR0FBQUYsT0FBQSxDQUFBRSwwQkFBQSxHQUFHLGlCQUFpQjtBQU0zRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVNDLG9CQUFvQkEsQ0FDbENDLE1BQStCLEVBQy9CQyxTQUE0QixFQUNSO0VBQ3BCLE1BQU1DLE1BQU0sR0FBR0YsTUFBTSxDQUFDRyxNQUFNLENBQUVDLENBQUMsSUFBS0EsQ0FBQyxDQUFDQyxJQUFJLEtBQUtSLGtCQUFrQixDQUFDOztFQUVsRTtFQUNBO0VBQ0E7RUFDQTtFQUNBLElBQUlTLFNBQWtDLEdBQUcsRUFBRTtFQUMzQyxJQUFJTCxTQUFTLElBQUlBLFNBQVMsQ0FBQ00sSUFBSSxLQUFLWixrQkFBa0IsRUFBRTtJQUN0RCxNQUFNYSxHQUFHLEdBQUdQLFNBQVMsQ0FBQ1EsTUFBTSxFQUFFRCxHQUFHO0lBQ2pDLElBQUksT0FBT0EsR0FBRyxLQUFLLFFBQVEsRUFBRTtNQUMzQkYsU0FBUyxHQUFHTixNQUFNLENBQUNHLE1BQU0sQ0FDdEJDLENBQUMsSUFBS0EsQ0FBQyxDQUFDQyxJQUFJLEtBQUtQLDBCQUEwQixLQUFLTSxDQUFDLENBQUNNLElBQUksS0FBS0YsR0FBRyxJQUFJSixDQUFDLENBQUNPLEVBQUUsS0FBS0gsR0FBRyxDQUNqRixDQUFDO01BQ0QsSUFBSUYsU0FBUyxDQUFDTSxNQUFNLEdBQUcsQ0FBQyxFQUFFLE9BQU87UUFBRUMsRUFBRSxFQUFFLEtBQUs7UUFBRUMsTUFBTSxFQUFFO01BQVksQ0FBQztJQUNyRTtFQUNGO0VBRUEsSUFBSVIsU0FBUyxDQUFDTSxNQUFNLEtBQUssQ0FBQyxFQUFFO0lBQzFCO0lBQ0EsSUFBSVYsTUFBTSxDQUFDVSxNQUFNLEdBQUcsQ0FBQyxFQUFFLE9BQU87TUFBRUMsRUFBRSxFQUFFLEtBQUs7TUFBRUMsTUFBTSxFQUFFO0lBQVksQ0FBQztJQUNoRSxPQUFPO01BQUVELEVBQUUsRUFBRSxJQUFJO01BQUVFLElBQUksRUFBRVQsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDSSxJQUFJO01BQUVNLEdBQUcsRUFBRSxpQkFBaUI7TUFBRUMsS0FBSyxFQUFFWCxTQUFTLENBQUMsQ0FBQztJQUFFLENBQUM7RUFDM0Y7RUFDQSxJQUFJSixNQUFNLENBQUNVLE1BQU0sS0FBSyxDQUFDLEVBQUUsT0FBTztJQUFFQyxFQUFFLEVBQUUsSUFBSTtJQUFFRSxJQUFJLEVBQUViLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQ1EsSUFBSTtJQUFFTSxHQUFHLEVBQUUsV0FBVztJQUFFQyxLQUFLLEVBQUVmLE1BQU0sQ0FBQyxDQUFDO0VBQUUsQ0FBQztFQUN0RyxJQUFJQSxNQUFNLENBQUNVLE1BQU0sR0FBRyxDQUFDLEVBQUUsT0FBTztJQUFFQyxFQUFFLEVBQUUsS0FBSztJQUFFQyxNQUFNLEVBQUU7RUFBWSxDQUFDO0VBQ2hFLE9BQU87SUFBRUQsRUFBRSxFQUFFLEtBQUs7SUFBRUMsTUFBTSxFQUFFO0VBQWlCLENBQUM7QUFDaEQiLCJpZ25vcmVMaXN0IjpbXX0=