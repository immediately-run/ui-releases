"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useMounts = useMounts;
var _react = require("react");
var _mounts = require("@immediately-run/sdk/mounts");
// The live mount set for the dispatched-workbook flow (open-workbook provider). The
// host's repo-load dispatch mounts the corpus BEFORE the viewer runs, but a mount can
// also be announced a beat after boot — so this observes `onMountsChange`. Honest
// trigger story (review round 4, correcting a false latch claim): there IS no latch —
// every `onMountsChange` hands a fresh array and the consumer's effect rebuilds on
// identity (a rebuild is a FULL cold session rebuild — it discards in-session param
// writes and spins a fresh engine worker; observed rarely enough in practice that no
// one has measured it, which is not the same as cheap), and the resolution REFUSES
// two content mounts rather than latching one (dispatch.ts).

// The per-module subpath, deliberately: the SDK root pulls in `tasks.ts`, whose
// load-time listener is the side effect the §4.1/DN-R5 discipline keeps behind
// dynamic imports. (Accuracy, review round 5: since SDK R3-421 / ≥0.57.3 the
// listener's registration is try/catch-wrapped, so the load no longer THROWS
// off-host — the discipline stands on the side-effect, not on the throw.)

/** A snapshot of the mount set that re-renders on change; empty under vite dev. */
function useMounts() {
  const [mounts, setMounts] = (0, _react.useState)(() => {
    try {
      return [...(0, _mounts.getMounts)()];
    } catch {
      return []; // no host runtime (vite dev) — the seed document flow
    }
  });
  (0, _react.useEffect)(() => {
    try {
      return (0, _mounts.onMountsChange)(next => setMounts([...next]));
    } catch {
      return undefined; // no host runtime — nothing to observe
    }
  }, []);
  return mounts;
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcmVhY3QiLCJyZXF1aXJlIiwiX21vdW50cyIsInVzZU1vdW50cyIsIm1vdW50cyIsInNldE1vdW50cyIsInVzZVN0YXRlIiwiZ2V0TW91bnRzIiwidXNlRWZmZWN0Iiwib25Nb3VudHNDaGFuZ2UiLCJuZXh0IiwidW5kZWZpbmVkIl0sInNvdXJjZXMiOlsidXNlTW91bnRzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIFRoZSBsaXZlIG1vdW50IHNldCBmb3IgdGhlIGRpc3BhdGNoZWQtd29ya2Jvb2sgZmxvdyAob3Blbi13b3JrYm9vayBwcm92aWRlcikuIFRoZVxuLy8gaG9zdCdzIHJlcG8tbG9hZCBkaXNwYXRjaCBtb3VudHMgdGhlIGNvcnB1cyBCRUZPUkUgdGhlIHZpZXdlciBydW5zLCBidXQgYSBtb3VudCBjYW5cbi8vIGFsc28gYmUgYW5ub3VuY2VkIGEgYmVhdCBhZnRlciBib290IOKAlCBzbyB0aGlzIG9ic2VydmVzIGBvbk1vdW50c0NoYW5nZWAuIEhvbmVzdFxuLy8gdHJpZ2dlciBzdG9yeSAocmV2aWV3IHJvdW5kIDQsIGNvcnJlY3RpbmcgYSBmYWxzZSBsYXRjaCBjbGFpbSk6IHRoZXJlIElTIG5vIGxhdGNoIOKAlFxuLy8gZXZlcnkgYG9uTW91bnRzQ2hhbmdlYCBoYW5kcyBhIGZyZXNoIGFycmF5IGFuZCB0aGUgY29uc3VtZXIncyBlZmZlY3QgcmVidWlsZHMgb25cbi8vIGlkZW50aXR5IChhIHJlYnVpbGQgaXMgYSBGVUxMIGNvbGQgc2Vzc2lvbiByZWJ1aWxkIOKAlCBpdCBkaXNjYXJkcyBpbi1zZXNzaW9uIHBhcmFtXG4vLyB3cml0ZXMgYW5kIHNwaW5zIGEgZnJlc2ggZW5naW5lIHdvcmtlcjsgb2JzZXJ2ZWQgcmFyZWx5IGVub3VnaCBpbiBwcmFjdGljZSB0aGF0IG5vXG4vLyBvbmUgaGFzIG1lYXN1cmVkIGl0LCB3aGljaCBpcyBub3QgdGhlIHNhbWUgYXMgY2hlYXApLCBhbmQgdGhlIHJlc29sdXRpb24gUkVGVVNFU1xuLy8gdHdvIGNvbnRlbnQgbW91bnRzIHJhdGhlciB0aGFuIGxhdGNoaW5nIG9uZSAoZGlzcGF0Y2gudHMpLlxuXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuLy8gVGhlIHBlci1tb2R1bGUgc3VicGF0aCwgZGVsaWJlcmF0ZWx5OiB0aGUgU0RLIHJvb3QgcHVsbHMgaW4gYHRhc2tzLnRzYCwgd2hvc2Vcbi8vIGxvYWQtdGltZSBsaXN0ZW5lciBpcyB0aGUgc2lkZSBlZmZlY3QgdGhlIMKnNC4xL0ROLVI1IGRpc2NpcGxpbmUga2VlcHMgYmVoaW5kXG4vLyBkeW5hbWljIGltcG9ydHMuIChBY2N1cmFjeSwgcmV2aWV3IHJvdW5kIDU6IHNpbmNlIFNESyBSMy00MjEgLyDiiaUwLjU3LjMgdGhlXG4vLyBsaXN0ZW5lcidzIHJlZ2lzdHJhdGlvbiBpcyB0cnkvY2F0Y2gtd3JhcHBlZCwgc28gdGhlIGxvYWQgbm8gbG9uZ2VyIFRIUk9XU1xuLy8gb2ZmLWhvc3Qg4oCUIHRoZSBkaXNjaXBsaW5lIHN0YW5kcyBvbiB0aGUgc2lkZS1lZmZlY3QsIG5vdCBvbiB0aGUgdGhyb3cuKVxuaW1wb3J0IHsgZ2V0TW91bnRzLCBvbk1vdW50c0NoYW5nZSB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrL21vdW50cyc7XG5pbXBvcnQgdHlwZSB7IFNhbmRib3hNb3VudCB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrL21vdW50cyc7XG5cbi8qKiBBIHNuYXBzaG90IG9mIHRoZSBtb3VudCBzZXQgdGhhdCByZS1yZW5kZXJzIG9uIGNoYW5nZTsgZW1wdHkgdW5kZXIgdml0ZSBkZXYuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlTW91bnRzKCk6IHJlYWRvbmx5IFNhbmRib3hNb3VudFtdIHtcbiAgY29uc3QgW21vdW50cywgc2V0TW91bnRzXSA9IHVzZVN0YXRlPHJlYWRvbmx5IFNhbmRib3hNb3VudFtdPigoKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIHJldHVybiBbLi4uZ2V0TW91bnRzKCldO1xuICAgIH0gY2F0Y2gge1xuICAgICAgcmV0dXJuIFtdOyAvLyBubyBob3N0IHJ1bnRpbWUgKHZpdGUgZGV2KSDigJQgdGhlIHNlZWQgZG9jdW1lbnQgZmxvd1xuICAgIH1cbiAgfSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICB0cnkge1xuICAgICAgcmV0dXJuIG9uTW91bnRzQ2hhbmdlKChuZXh0KSA9PiBzZXRNb3VudHMoWy4uLm5leHRdKSk7XG4gICAgfSBjYXRjaCB7XG4gICAgICByZXR1cm4gdW5kZWZpbmVkOyAvLyBubyBob3N0IHJ1bnRpbWUg4oCUIG5vdGhpbmcgdG8gb2JzZXJ2ZVxuICAgIH1cbiAgfSwgW10pO1xuXG4gIHJldHVybiBtb3VudHM7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQVVBLElBQUFBLE1BQUEsR0FBQUMsT0FBQTtBQU1BLElBQUFDLE9BQUEsR0FBQUQsT0FBQTtBQWhCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFJQTtBQUNPLFNBQVNFLFNBQVNBLENBQUEsRUFBNEI7RUFDbkQsTUFBTSxDQUFDQyxNQUFNLEVBQUVDLFNBQVMsQ0FBQyxHQUFHLElBQUFDLGVBQVEsRUFBMEIsTUFBTTtJQUNsRSxJQUFJO01BQ0YsT0FBTyxDQUFDLEdBQUcsSUFBQUMsaUJBQVMsRUFBQyxDQUFDLENBQUM7SUFDekIsQ0FBQyxDQUFDLE1BQU07TUFDTixPQUFPLEVBQUUsQ0FBQyxDQUFDO0lBQ2I7RUFDRixDQUFDLENBQUM7RUFFRixJQUFBQyxnQkFBUyxFQUFDLE1BQU07SUFDZCxJQUFJO01BQ0YsT0FBTyxJQUFBQyxzQkFBYyxFQUFFQyxJQUFJLElBQUtMLFNBQVMsQ0FBQyxDQUFDLEdBQUdLLElBQUksQ0FBQyxDQUFDLENBQUM7SUFDdkQsQ0FBQyxDQUFDLE1BQU07TUFDTixPQUFPQyxTQUFTLENBQUMsQ0FBQztJQUNwQjtFQUNGLENBQUMsRUFBRSxFQUFFLENBQUM7RUFFTixPQUFPUCxNQUFNO0FBQ2YiLCJpZ25vcmVMaXN0IjpbXX0=