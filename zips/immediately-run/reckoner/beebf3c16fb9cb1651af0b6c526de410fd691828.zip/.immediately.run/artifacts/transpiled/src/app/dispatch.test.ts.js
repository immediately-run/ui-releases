"use strict";

var _vitest = require("vitest");
var _dispatch = require("./dispatch.ts");
// The open-workbook dispatched flow (R3-169 pattern, after Grove's open-wiki):
// resolution from the mount set, and the full session over a real mounted document
// (the DCF notebook's shape — the same `loadDocument` pipeline as the seed, but read
// from the filesystem port instead of embedded constants).

const mount = over => ({
  id: 'm',
  path: '/x',
  type: 'app',
  ...over
});
(0, _vitest.describe)('resolveWorkbookMount', () => {
  (0, _vitest.it)('the repo-load mark: the one mount typed "content" is the workbook root, and the ok variant carries the mount itself (Part B, R3-447)', () => {
    const wb = mount({
      id: 'content:o/r',
      path: '/task/7/dir',
      type: 'content',
      mode: 'ro'
    });
    const mounts = [mount({
      id: 'app',
      path: '/app',
      type: 'app'
    }), wb];
    (0, _vitest.expect)((0, _dispatch.resolveWorkbookMount)(mounts)).toEqual({
      ok: true,
      root: '/task/7/dir',
      via: 'repo-load',
      mount: wb
    });
  });
  (0, _vitest.it)('the carried mount is what the edit door addresses: id and mode come from the live descriptor (G-DN-B1)', () => {
    const r = (0, _dispatch.resolveWorkbookMount)([mount({
      id: 'content:owner/repo',
      path: '/mnt/h',
      type: 'content',
      mode: 'rw'
    })]);
    if (!r.ok) throw new Error('expected ok');
    (0, _vitest.expect)(r.mount.id).toBe('content:owner/repo');
    (0, _vitest.expect)(r.mount.mode).toBe('rw');
  });
  (0, _vitest.it)('foreign mounts WITHOUT the mark are not guessed at (a space, a worktree)', () => {
    const mounts = [mount({
      id: 'app',
      path: '/app',
      type: 'app'
    }), mount({
      id: 'space',
      path: '/space/abc',
      type: 'space'
    }), mount({
      id: 'wt',
      path: '/wt/1',
      type: 'worktree'
    })];
    (0, _vitest.expect)((0, _dispatch.resolveWorkbookMount)(mounts)).toEqual({
      ok: false,
      reason: 'not-dispatched'
    });
  });
  (0, _vitest.it)('no mounts → the seed document flow', () => {
    (0, _vitest.expect)((0, _dispatch.resolveWorkbookMount)([])).toEqual({
      ok: false,
      reason: 'not-dispatched'
    });
  });
  (0, _vitest.it)('two marked mounts is a host bug we refuse, not paper over', () => {
    const mounts = [mount({
      id: 'a',
      path: '/a',
      type: 'content'
    }), mount({
      id: 'b',
      path: '/b',
      type: 'content'
    })];
    (0, _vitest.expect)((0, _dispatch.resolveWorkbookMount)(mounts)).toEqual({
      ok: false,
      reason: 'ambiguous'
    });
  });
});

// The task-invocation shape (R3-754), against the PROBED live contract: the input
// `{ task: 'open-workbook', params: { dir: '/task/task-1/dir' } }` (the host
// rewrites `dir` to the minted chroot path) + the one `task-delegation` mount at
// that path. Fixtures below are the venue-captured descriptor verbatim.
(0, _vitest.describe)('resolveWorkbookMount — the task-invocation shape (R3-754)', () => {
  const probedInput = {
    task: 'open-workbook',
    params: {
      dir: '/task/task-1/dir'
    }
  };
  const probedDelegation = mount({
    id: '/task/task-1/dir',
    path: '/task/task-1/dir',
    type: 'task-delegation',
    mode: 'ro'
  });
  (0, _vitest.it)('the probed contract resolves: the delegation at the input’s dir, via task-invocation, carrying the mount', () => {
    const mounts = [mount({
      id: 'app',
      path: '/app',
      type: 'app'
    }), probedDelegation];
    (0, _vitest.expect)((0, _dispatch.resolveWorkbookMount)(mounts, probedInput)).toEqual({
      ok: true,
      root: '/task/task-1/dir',
      via: 'task-invocation',
      mount: probedDelegation
    });
  });
  (0, _vitest.it)('the carried mount keeps the probed mode — an ro caller folder yields an ro delegation (the door’s positive-rw gate reads it, never inverted)', () => {
    const r = (0, _dispatch.resolveWorkbookMount)([probedDelegation], probedInput);
    if (!r.ok) throw new Error('expected ok');
    (0, _vitest.expect)(r.mount.mode).toBe('ro');
    const rw = mount({
      id: '/task/task-1/dir',
      path: '/task/task-1/dir',
      type: 'task-delegation',
      mode: 'rw'
    });
    const r2 = (0, _dispatch.resolveWorkbookMount)([rw], probedInput);
    if (!r2.ok) throw new Error('expected ok');
    (0, _vitest.expect)(r2.mount.mode).toBe('rw');
  });
  (0, _vitest.it)('a delegation mount whose id (not path) matches the dir also resolves', () => {
    const byId = mount({
      id: '/task/task-1/dir',
      path: '/mnt/other',
      type: 'task-delegation',
      mode: 'ro'
    });
    const r = (0, _dispatch.resolveWorkbookMount)([byId], probedInput);
    if (!r.ok) throw new Error('expected ok');
    (0, _vitest.expect)(r.mount).toBe(byId);
  });
  (0, _vitest.it)('a task-delegation mount WITHOUT the input is not guessed at — the input is the task shape’s mark', () => {
    (0, _vitest.expect)((0, _dispatch.resolveWorkbookMount)([probedDelegation])).toEqual({
      ok: false,
      reason: 'not-dispatched'
    });
    (0, _vitest.expect)((0, _dispatch.resolveWorkbookMount)([probedDelegation], null)).toEqual({
      ok: false,
      reason: 'not-dispatched'
    });
  });
  (0, _vitest.it)('an input for a different task resolves nothing here', () => {
    const other = {
      task: 'open-wiki',
      params: {
        dir: '/task/task-1/dir'
      }
    };
    (0, _vitest.expect)((0, _dispatch.resolveWorkbookMount)([probedDelegation], other)).toEqual({
      ok: false,
      reason: 'not-dispatched'
    });
  });
  (0, _vitest.it)('an input whose dir finds no matching delegation falls through to the repo-load mark, else not-dispatched', () => {
    (0, _vitest.expect)((0, _dispatch.resolveWorkbookMount)([mount({
      id: 'app',
      path: '/app',
      type: 'app'
    })], probedInput)).toEqual({
      ok: false,
      reason: 'not-dispatched'
    });
    const wb = mount({
      id: 'content:o/r',
      path: '/mnt/h',
      type: 'content',
      mode: 'rw'
    });
    (0, _vitest.expect)((0, _dispatch.resolveWorkbookMount)([wb], probedInput)).toEqual({
      ok: true,
      root: '/mnt/h',
      via: 'repo-load',
      mount: wb
    });
  });
  (0, _vitest.it)('a non-string dir param is ignored, not crashed on', () => {
    (0, _vitest.expect)((0, _dispatch.resolveWorkbookMount)([probedDelegation], {
      task: 'open-workbook',
      params: {
        dir: 42
      }
    })).toEqual({
      ok: false,
      reason: 'not-dispatched'
    });
    (0, _vitest.expect)((0, _dispatch.resolveWorkbookMount)([probedDelegation], {
      task: 'open-workbook',
      params: {}
    })).toEqual({
      ok: false,
      reason: 'not-dispatched'
    });
  });
  (0, _vitest.it)('two delegations at the input’s dir is a host bug we refuse', () => {
    const dup = mount({
      id: '/task/task-1/dir',
      path: '/task/task-1/dir',
      type: 'task-delegation',
      mode: 'rw'
    });
    (0, _vitest.expect)((0, _dispatch.resolveWorkbookMount)([probedDelegation, dup], probedInput)).toEqual({
      ok: false,
      reason: 'ambiguous'
    });
  });
  (0, _vitest.it)('both shapes claiming one frame (a content mark AND a matched delegation) is refused, not picked between', () => {
    const wb = mount({
      id: 'content:o/r',
      path: '/mnt/h',
      type: 'content',
      mode: 'rw'
    });
    (0, _vitest.expect)((0, _dispatch.resolveWorkbookMount)([wb, probedDelegation], probedInput)).toEqual({
      ok: false,
      reason: 'ambiguous'
    });
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZXN0IiwicmVxdWlyZSIsIl9kaXNwYXRjaCIsIm1vdW50Iiwib3ZlciIsImlkIiwicGF0aCIsInR5cGUiLCJkZXNjcmliZSIsIml0Iiwid2IiLCJtb2RlIiwibW91bnRzIiwiZXhwZWN0IiwicmVzb2x2ZVdvcmtib29rTW91bnQiLCJ0b0VxdWFsIiwib2siLCJyb290IiwidmlhIiwiciIsIkVycm9yIiwidG9CZSIsInJlYXNvbiIsInByb2JlZElucHV0IiwidGFzayIsInBhcmFtcyIsImRpciIsInByb2JlZERlbGVnYXRpb24iLCJydyIsInIyIiwiYnlJZCIsIm90aGVyIiwiZHVwIl0sInNvdXJjZXMiOlsiZGlzcGF0Y2gudGVzdC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBUaGUgb3Blbi13b3JrYm9vayBkaXNwYXRjaGVkIGZsb3cgKFIzLTE2OSBwYXR0ZXJuLCBhZnRlciBHcm92ZSdzIG9wZW4td2lraSk6XG4vLyByZXNvbHV0aW9uIGZyb20gdGhlIG1vdW50IHNldCwgYW5kIHRoZSBmdWxsIHNlc3Npb24gb3ZlciBhIHJlYWwgbW91bnRlZCBkb2N1bWVudFxuLy8gKHRoZSBEQ0Ygbm90ZWJvb2sncyBzaGFwZSDigJQgdGhlIHNhbWUgYGxvYWREb2N1bWVudGAgcGlwZWxpbmUgYXMgdGhlIHNlZWQsIGJ1dCByZWFkXG4vLyBmcm9tIHRoZSBmaWxlc3lzdGVtIHBvcnQgaW5zdGVhZCBvZiBlbWJlZGRlZCBjb25zdGFudHMpLlxuXG5pbXBvcnQgeyBkZXNjcmliZSwgaXQsIGV4cGVjdCB9IGZyb20gJ3ZpdGVzdCc7XG5pbXBvcnQgeyByZXNvbHZlV29ya2Jvb2tNb3VudCB9IGZyb20gJy4vZGlzcGF0Y2gudHMnO1xuaW1wb3J0IHR5cGUgeyBTYW5kYm94TW91bnQgfSBmcm9tICdAaW1tZWRpYXRlbHktcnVuL3Nkayc7XG5cbmNvbnN0IG1vdW50ID0gKG92ZXI6IFBhcnRpYWw8U2FuZGJveE1vdW50Pik6IFNhbmRib3hNb3VudCA9PlxuICAoeyBpZDogJ20nLCBwYXRoOiAnL3gnLCB0eXBlOiAnYXBwJywgLi4ub3ZlciB9KSBhcyBTYW5kYm94TW91bnQ7XG5cbmRlc2NyaWJlKCdyZXNvbHZlV29ya2Jvb2tNb3VudCcsICgpID0+IHtcbiAgaXQoJ3RoZSByZXBvLWxvYWQgbWFyazogdGhlIG9uZSBtb3VudCB0eXBlZCBcImNvbnRlbnRcIiBpcyB0aGUgd29ya2Jvb2sgcm9vdCwgYW5kIHRoZSBvayB2YXJpYW50IGNhcnJpZXMgdGhlIG1vdW50IGl0c2VsZiAoUGFydCBCLCBSMy00NDcpJywgKCkgPT4ge1xuICAgIGNvbnN0IHdiID0gbW91bnQoeyBpZDogJ2NvbnRlbnQ6by9yJywgcGF0aDogJy90YXNrLzcvZGlyJywgdHlwZTogJ2NvbnRlbnQnLCBtb2RlOiAncm8nIH0pO1xuICAgIGNvbnN0IG1vdW50cyA9IFttb3VudCh7IGlkOiAnYXBwJywgcGF0aDogJy9hcHAnLCB0eXBlOiAnYXBwJyB9KSwgd2JdO1xuICAgIGV4cGVjdChyZXNvbHZlV29ya2Jvb2tNb3VudChtb3VudHMpKS50b0VxdWFsKHsgb2s6IHRydWUsIHJvb3Q6ICcvdGFzay83L2RpcicsIHZpYTogJ3JlcG8tbG9hZCcsIG1vdW50OiB3YiB9KTtcbiAgfSk7XG5cbiAgaXQoJ3RoZSBjYXJyaWVkIG1vdW50IGlzIHdoYXQgdGhlIGVkaXQgZG9vciBhZGRyZXNzZXM6IGlkIGFuZCBtb2RlIGNvbWUgZnJvbSB0aGUgbGl2ZSBkZXNjcmlwdG9yIChHLUROLUIxKScsICgpID0+IHtcbiAgICBjb25zdCByID0gcmVzb2x2ZVdvcmtib29rTW91bnQoW1xuICAgICAgbW91bnQoeyBpZDogJ2NvbnRlbnQ6b3duZXIvcmVwbycsIHBhdGg6ICcvbW50L2gnLCB0eXBlOiAnY29udGVudCcsIG1vZGU6ICdydycgfSksXG4gICAgXSk7XG4gICAgaWYgKCFyLm9rKSB0aHJvdyBuZXcgRXJyb3IoJ2V4cGVjdGVkIG9rJyk7XG4gICAgZXhwZWN0KHIubW91bnQuaWQpLnRvQmUoJ2NvbnRlbnQ6b3duZXIvcmVwbycpO1xuICAgIGV4cGVjdChyLm1vdW50Lm1vZGUpLnRvQmUoJ3J3Jyk7XG4gIH0pO1xuXG4gIGl0KCdmb3JlaWduIG1vdW50cyBXSVRIT1VUIHRoZSBtYXJrIGFyZSBub3QgZ3Vlc3NlZCBhdCAoYSBzcGFjZSwgYSB3b3JrdHJlZSknLCAoKSA9PiB7XG4gICAgY29uc3QgbW91bnRzID0gW1xuICAgICAgbW91bnQoeyBpZDogJ2FwcCcsIHBhdGg6ICcvYXBwJywgdHlwZTogJ2FwcCcgfSksXG4gICAgICBtb3VudCh7IGlkOiAnc3BhY2UnLCBwYXRoOiAnL3NwYWNlL2FiYycsIHR5cGU6ICdzcGFjZScgfSksXG4gICAgICBtb3VudCh7IGlkOiAnd3QnLCBwYXRoOiAnL3d0LzEnLCB0eXBlOiAnd29ya3RyZWUnIH0pLFxuICAgIF07XG4gICAgZXhwZWN0KHJlc29sdmVXb3JrYm9va01vdW50KG1vdW50cykpLnRvRXF1YWwoeyBvazogZmFsc2UsIHJlYXNvbjogJ25vdC1kaXNwYXRjaGVkJyB9KTtcbiAgfSk7XG5cbiAgaXQoJ25vIG1vdW50cyDihpIgdGhlIHNlZWQgZG9jdW1lbnQgZmxvdycsICgpID0+IHtcbiAgICBleHBlY3QocmVzb2x2ZVdvcmtib29rTW91bnQoW10pKS50b0VxdWFsKHsgb2s6IGZhbHNlLCByZWFzb246ICdub3QtZGlzcGF0Y2hlZCcgfSk7XG4gIH0pO1xuXG4gIGl0KCd0d28gbWFya2VkIG1vdW50cyBpcyBhIGhvc3QgYnVnIHdlIHJlZnVzZSwgbm90IHBhcGVyIG92ZXInLCAoKSA9PiB7XG4gICAgY29uc3QgbW91bnRzID0gW1xuICAgICAgbW91bnQoeyBpZDogJ2EnLCBwYXRoOiAnL2EnLCB0eXBlOiAnY29udGVudCcgfSksXG4gICAgICBtb3VudCh7IGlkOiAnYicsIHBhdGg6ICcvYicsIHR5cGU6ICdjb250ZW50JyB9KSxcbiAgICBdO1xuICAgIGV4cGVjdChyZXNvbHZlV29ya2Jvb2tNb3VudChtb3VudHMpKS50b0VxdWFsKHsgb2s6IGZhbHNlLCByZWFzb246ICdhbWJpZ3VvdXMnIH0pO1xuICB9KTtcbn0pO1xuXG4vLyBUaGUgdGFzay1pbnZvY2F0aW9uIHNoYXBlIChSMy03NTQpLCBhZ2FpbnN0IHRoZSBQUk9CRUQgbGl2ZSBjb250cmFjdDogdGhlIGlucHV0XG4vLyBgeyB0YXNrOiAnb3Blbi13b3JrYm9vaycsIHBhcmFtczogeyBkaXI6ICcvdGFzay90YXNrLTEvZGlyJyB9IH1gICh0aGUgaG9zdFxuLy8gcmV3cml0ZXMgYGRpcmAgdG8gdGhlIG1pbnRlZCBjaHJvb3QgcGF0aCkgKyB0aGUgb25lIGB0YXNrLWRlbGVnYXRpb25gIG1vdW50IGF0XG4vLyB0aGF0IHBhdGguIEZpeHR1cmVzIGJlbG93IGFyZSB0aGUgdmVudWUtY2FwdHVyZWQgZGVzY3JpcHRvciB2ZXJiYXRpbS5cbmRlc2NyaWJlKCdyZXNvbHZlV29ya2Jvb2tNb3VudCDigJQgdGhlIHRhc2staW52b2NhdGlvbiBzaGFwZSAoUjMtNzU0KScsICgpID0+IHtcbiAgY29uc3QgcHJvYmVkSW5wdXQgPSB7IHRhc2s6ICdvcGVuLXdvcmtib29rJywgcGFyYW1zOiB7IGRpcjogJy90YXNrL3Rhc2stMS9kaXInIH0gfTtcbiAgY29uc3QgcHJvYmVkRGVsZWdhdGlvbiA9IG1vdW50KHtcbiAgICBpZDogJy90YXNrL3Rhc2stMS9kaXInLFxuICAgIHBhdGg6ICcvdGFzay90YXNrLTEvZGlyJyxcbiAgICB0eXBlOiAndGFzay1kZWxlZ2F0aW9uJyxcbiAgICBtb2RlOiAncm8nLFxuICB9KTtcblxuICBpdCgndGhlIHByb2JlZCBjb250cmFjdCByZXNvbHZlczogdGhlIGRlbGVnYXRpb24gYXQgdGhlIGlucHV04oCZcyBkaXIsIHZpYSB0YXNrLWludm9jYXRpb24sIGNhcnJ5aW5nIHRoZSBtb3VudCcsICgpID0+IHtcbiAgICBjb25zdCBtb3VudHMgPSBbbW91bnQoeyBpZDogJ2FwcCcsIHBhdGg6ICcvYXBwJywgdHlwZTogJ2FwcCcgfSksIHByb2JlZERlbGVnYXRpb25dO1xuICAgIGV4cGVjdChyZXNvbHZlV29ya2Jvb2tNb3VudChtb3VudHMsIHByb2JlZElucHV0KSkudG9FcXVhbCh7XG4gICAgICBvazogdHJ1ZSxcbiAgICAgIHJvb3Q6ICcvdGFzay90YXNrLTEvZGlyJyxcbiAgICAgIHZpYTogJ3Rhc2staW52b2NhdGlvbicsXG4gICAgICBtb3VudDogcHJvYmVkRGVsZWdhdGlvbixcbiAgICB9KTtcbiAgfSk7XG5cbiAgaXQoJ3RoZSBjYXJyaWVkIG1vdW50IGtlZXBzIHRoZSBwcm9iZWQgbW9kZSDigJQgYW4gcm8gY2FsbGVyIGZvbGRlciB5aWVsZHMgYW4gcm8gZGVsZWdhdGlvbiAodGhlIGRvb3LigJlzIHBvc2l0aXZlLXJ3IGdhdGUgcmVhZHMgaXQsIG5ldmVyIGludmVydGVkKScsICgpID0+IHtcbiAgICBjb25zdCByID0gcmVzb2x2ZVdvcmtib29rTW91bnQoW3Byb2JlZERlbGVnYXRpb25dLCBwcm9iZWRJbnB1dCk7XG4gICAgaWYgKCFyLm9rKSB0aHJvdyBuZXcgRXJyb3IoJ2V4cGVjdGVkIG9rJyk7XG4gICAgZXhwZWN0KHIubW91bnQubW9kZSkudG9CZSgncm8nKTtcbiAgICBjb25zdCBydyA9IG1vdW50KHsgaWQ6ICcvdGFzay90YXNrLTEvZGlyJywgcGF0aDogJy90YXNrL3Rhc2stMS9kaXInLCB0eXBlOiAndGFzay1kZWxlZ2F0aW9uJywgbW9kZTogJ3J3JyB9KTtcbiAgICBjb25zdCByMiA9IHJlc29sdmVXb3JrYm9va01vdW50KFtyd10sIHByb2JlZElucHV0KTtcbiAgICBpZiAoIXIyLm9rKSB0aHJvdyBuZXcgRXJyb3IoJ2V4cGVjdGVkIG9rJyk7XG4gICAgZXhwZWN0KHIyLm1vdW50Lm1vZGUpLnRvQmUoJ3J3Jyk7XG4gIH0pO1xuXG4gIGl0KCdhIGRlbGVnYXRpb24gbW91bnQgd2hvc2UgaWQgKG5vdCBwYXRoKSBtYXRjaGVzIHRoZSBkaXIgYWxzbyByZXNvbHZlcycsICgpID0+IHtcbiAgICBjb25zdCBieUlkID0gbW91bnQoeyBpZDogJy90YXNrL3Rhc2stMS9kaXInLCBwYXRoOiAnL21udC9vdGhlcicsIHR5cGU6ICd0YXNrLWRlbGVnYXRpb24nLCBtb2RlOiAncm8nIH0pO1xuICAgIGNvbnN0IHIgPSByZXNvbHZlV29ya2Jvb2tNb3VudChbYnlJZF0sIHByb2JlZElucHV0KTtcbiAgICBpZiAoIXIub2spIHRocm93IG5ldyBFcnJvcignZXhwZWN0ZWQgb2snKTtcbiAgICBleHBlY3Qoci5tb3VudCkudG9CZShieUlkKTtcbiAgfSk7XG5cbiAgaXQoJ2EgdGFzay1kZWxlZ2F0aW9uIG1vdW50IFdJVEhPVVQgdGhlIGlucHV0IGlzIG5vdCBndWVzc2VkIGF0IOKAlCB0aGUgaW5wdXQgaXMgdGhlIHRhc2sgc2hhcGXigJlzIG1hcmsnLCAoKSA9PiB7XG4gICAgZXhwZWN0KHJlc29sdmVXb3JrYm9va01vdW50KFtwcm9iZWREZWxlZ2F0aW9uXSkpLnRvRXF1YWwoeyBvazogZmFsc2UsIHJlYXNvbjogJ25vdC1kaXNwYXRjaGVkJyB9KTtcbiAgICBleHBlY3QocmVzb2x2ZVdvcmtib29rTW91bnQoW3Byb2JlZERlbGVnYXRpb25dLCBudWxsKSkudG9FcXVhbCh7IG9rOiBmYWxzZSwgcmVhc29uOiAnbm90LWRpc3BhdGNoZWQnIH0pO1xuICB9KTtcblxuICBpdCgnYW4gaW5wdXQgZm9yIGEgZGlmZmVyZW50IHRhc2sgcmVzb2x2ZXMgbm90aGluZyBoZXJlJywgKCkgPT4ge1xuICAgIGNvbnN0IG90aGVyID0geyB0YXNrOiAnb3Blbi13aWtpJywgcGFyYW1zOiB7IGRpcjogJy90YXNrL3Rhc2stMS9kaXInIH0gfTtcbiAgICBleHBlY3QocmVzb2x2ZVdvcmtib29rTW91bnQoW3Byb2JlZERlbGVnYXRpb25dLCBvdGhlcikpLnRvRXF1YWwoeyBvazogZmFsc2UsIHJlYXNvbjogJ25vdC1kaXNwYXRjaGVkJyB9KTtcbiAgfSk7XG5cbiAgaXQoJ2FuIGlucHV0IHdob3NlIGRpciBmaW5kcyBubyBtYXRjaGluZyBkZWxlZ2F0aW9uIGZhbGxzIHRocm91Z2ggdG8gdGhlIHJlcG8tbG9hZCBtYXJrLCBlbHNlIG5vdC1kaXNwYXRjaGVkJywgKCkgPT4ge1xuICAgIGV4cGVjdChyZXNvbHZlV29ya2Jvb2tNb3VudChbbW91bnQoeyBpZDogJ2FwcCcsIHBhdGg6ICcvYXBwJywgdHlwZTogJ2FwcCcgfSldLCBwcm9iZWRJbnB1dCkpLnRvRXF1YWwoe1xuICAgICAgb2s6IGZhbHNlLFxuICAgICAgcmVhc29uOiAnbm90LWRpc3BhdGNoZWQnLFxuICAgIH0pO1xuICAgIGNvbnN0IHdiID0gbW91bnQoeyBpZDogJ2NvbnRlbnQ6by9yJywgcGF0aDogJy9tbnQvaCcsIHR5cGU6ICdjb250ZW50JywgbW9kZTogJ3J3JyB9KTtcbiAgICBleHBlY3QocmVzb2x2ZVdvcmtib29rTW91bnQoW3diXSwgcHJvYmVkSW5wdXQpKS50b0VxdWFsKHsgb2s6IHRydWUsIHJvb3Q6ICcvbW50L2gnLCB2aWE6ICdyZXBvLWxvYWQnLCBtb3VudDogd2IgfSk7XG4gIH0pO1xuXG4gIGl0KCdhIG5vbi1zdHJpbmcgZGlyIHBhcmFtIGlzIGlnbm9yZWQsIG5vdCBjcmFzaGVkIG9uJywgKCkgPT4ge1xuICAgIGV4cGVjdChyZXNvbHZlV29ya2Jvb2tNb3VudChbcHJvYmVkRGVsZWdhdGlvbl0sIHsgdGFzazogJ29wZW4td29ya2Jvb2snLCBwYXJhbXM6IHsgZGlyOiA0MiB9IH0pKS50b0VxdWFsKHtcbiAgICAgIG9rOiBmYWxzZSxcbiAgICAgIHJlYXNvbjogJ25vdC1kaXNwYXRjaGVkJyxcbiAgICB9KTtcbiAgICBleHBlY3QocmVzb2x2ZVdvcmtib29rTW91bnQoW3Byb2JlZERlbGVnYXRpb25dLCB7IHRhc2s6ICdvcGVuLXdvcmtib29rJywgcGFyYW1zOiB7fSB9KSkudG9FcXVhbCh7XG4gICAgICBvazogZmFsc2UsXG4gICAgICByZWFzb246ICdub3QtZGlzcGF0Y2hlZCcsXG4gICAgfSk7XG4gIH0pO1xuXG4gIGl0KCd0d28gZGVsZWdhdGlvbnMgYXQgdGhlIGlucHV04oCZcyBkaXIgaXMgYSBob3N0IGJ1ZyB3ZSByZWZ1c2UnLCAoKSA9PiB7XG4gICAgY29uc3QgZHVwID0gbW91bnQoeyBpZDogJy90YXNrL3Rhc2stMS9kaXInLCBwYXRoOiAnL3Rhc2svdGFzay0xL2RpcicsIHR5cGU6ICd0YXNrLWRlbGVnYXRpb24nLCBtb2RlOiAncncnIH0pO1xuICAgIGV4cGVjdChyZXNvbHZlV29ya2Jvb2tNb3VudChbcHJvYmVkRGVsZWdhdGlvbiwgZHVwXSwgcHJvYmVkSW5wdXQpKS50b0VxdWFsKHsgb2s6IGZhbHNlLCByZWFzb246ICdhbWJpZ3VvdXMnIH0pO1xuICB9KTtcblxuICBpdCgnYm90aCBzaGFwZXMgY2xhaW1pbmcgb25lIGZyYW1lIChhIGNvbnRlbnQgbWFyayBBTkQgYSBtYXRjaGVkIGRlbGVnYXRpb24pIGlzIHJlZnVzZWQsIG5vdCBwaWNrZWQgYmV0d2VlbicsICgpID0+IHtcbiAgICBjb25zdCB3YiA9IG1vdW50KHsgaWQ6ICdjb250ZW50Om8vcicsIHBhdGg6ICcvbW50L2gnLCB0eXBlOiAnY29udGVudCcsIG1vZGU6ICdydycgfSk7XG4gICAgZXhwZWN0KHJlc29sdmVXb3JrYm9va01vdW50KFt3YiwgcHJvYmVkRGVsZWdhdGlvbl0sIHByb2JlZElucHV0KSkudG9FcXVhbCh7IG9rOiBmYWxzZSwgcmVhc29uOiAnYW1iaWd1b3VzJyB9KTtcbiAgfSk7XG59KTtcbiJdLCJtYXBwaW5ncyI6Ijs7QUFLQSxJQUFBQSxPQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxTQUFBLEdBQUFELE9BQUE7QUFOQTtBQUNBO0FBQ0E7QUFDQTs7QUFNQSxNQUFNRSxLQUFLLEdBQUlDLElBQTJCLEtBQ3ZDO0VBQUVDLEVBQUUsRUFBRSxHQUFHO0VBQUVDLElBQUksRUFBRSxJQUFJO0VBQUVDLElBQUksRUFBRSxLQUFLO0VBQUUsR0FBR0g7QUFBSyxDQUFDLENBQWlCO0FBRWpFLElBQUFJLGdCQUFRLEVBQUMsc0JBQXNCLEVBQUUsTUFBTTtFQUNyQyxJQUFBQyxVQUFFLEVBQUMsc0lBQXNJLEVBQUUsTUFBTTtJQUMvSSxNQUFNQyxFQUFFLEdBQUdQLEtBQUssQ0FBQztNQUFFRSxFQUFFLEVBQUUsYUFBYTtNQUFFQyxJQUFJLEVBQUUsYUFBYTtNQUFFQyxJQUFJLEVBQUUsU0FBUztNQUFFSSxJQUFJLEVBQUU7SUFBSyxDQUFDLENBQUM7SUFDekYsTUFBTUMsTUFBTSxHQUFHLENBQUNULEtBQUssQ0FBQztNQUFFRSxFQUFFLEVBQUUsS0FBSztNQUFFQyxJQUFJLEVBQUUsTUFBTTtNQUFFQyxJQUFJLEVBQUU7SUFBTSxDQUFDLENBQUMsRUFBRUcsRUFBRSxDQUFDO0lBQ3BFLElBQUFHLGNBQU0sRUFBQyxJQUFBQyw4QkFBb0IsRUFBQ0YsTUFBTSxDQUFDLENBQUMsQ0FBQ0csT0FBTyxDQUFDO01BQUVDLEVBQUUsRUFBRSxJQUFJO01BQUVDLElBQUksRUFBRSxhQUFhO01BQUVDLEdBQUcsRUFBRSxXQUFXO01BQUVmLEtBQUssRUFBRU87SUFBRyxDQUFDLENBQUM7RUFDOUcsQ0FBQyxDQUFDO0VBRUYsSUFBQUQsVUFBRSxFQUFDLHdHQUF3RyxFQUFFLE1BQU07SUFDakgsTUFBTVUsQ0FBQyxHQUFHLElBQUFMLDhCQUFvQixFQUFDLENBQzdCWCxLQUFLLENBQUM7TUFBRUUsRUFBRSxFQUFFLG9CQUFvQjtNQUFFQyxJQUFJLEVBQUUsUUFBUTtNQUFFQyxJQUFJLEVBQUUsU0FBUztNQUFFSSxJQUFJLEVBQUU7SUFBSyxDQUFDLENBQUMsQ0FDakYsQ0FBQztJQUNGLElBQUksQ0FBQ1EsQ0FBQyxDQUFDSCxFQUFFLEVBQUUsTUFBTSxJQUFJSSxLQUFLLENBQUMsYUFBYSxDQUFDO0lBQ3pDLElBQUFQLGNBQU0sRUFBQ00sQ0FBQyxDQUFDaEIsS0FBSyxDQUFDRSxFQUFFLENBQUMsQ0FBQ2dCLElBQUksQ0FBQyxvQkFBb0IsQ0FBQztJQUM3QyxJQUFBUixjQUFNLEVBQUNNLENBQUMsQ0FBQ2hCLEtBQUssQ0FBQ1EsSUFBSSxDQUFDLENBQUNVLElBQUksQ0FBQyxJQUFJLENBQUM7RUFDakMsQ0FBQyxDQUFDO0VBRUYsSUFBQVosVUFBRSxFQUFDLDBFQUEwRSxFQUFFLE1BQU07SUFDbkYsTUFBTUcsTUFBTSxHQUFHLENBQ2JULEtBQUssQ0FBQztNQUFFRSxFQUFFLEVBQUUsS0FBSztNQUFFQyxJQUFJLEVBQUUsTUFBTTtNQUFFQyxJQUFJLEVBQUU7SUFBTSxDQUFDLENBQUMsRUFDL0NKLEtBQUssQ0FBQztNQUFFRSxFQUFFLEVBQUUsT0FBTztNQUFFQyxJQUFJLEVBQUUsWUFBWTtNQUFFQyxJQUFJLEVBQUU7SUFBUSxDQUFDLENBQUMsRUFDekRKLEtBQUssQ0FBQztNQUFFRSxFQUFFLEVBQUUsSUFBSTtNQUFFQyxJQUFJLEVBQUUsT0FBTztNQUFFQyxJQUFJLEVBQUU7SUFBVyxDQUFDLENBQUMsQ0FDckQ7SUFDRCxJQUFBTSxjQUFNLEVBQUMsSUFBQUMsOEJBQW9CLEVBQUNGLE1BQU0sQ0FBQyxDQUFDLENBQUNHLE9BQU8sQ0FBQztNQUFFQyxFQUFFLEVBQUUsS0FBSztNQUFFTSxNQUFNLEVBQUU7SUFBaUIsQ0FBQyxDQUFDO0VBQ3ZGLENBQUMsQ0FBQztFQUVGLElBQUFiLFVBQUUsRUFBQyxvQ0FBb0MsRUFBRSxNQUFNO0lBQzdDLElBQUFJLGNBQU0sRUFBQyxJQUFBQyw4QkFBb0IsRUFBQyxFQUFFLENBQUMsQ0FBQyxDQUFDQyxPQUFPLENBQUM7TUFBRUMsRUFBRSxFQUFFLEtBQUs7TUFBRU0sTUFBTSxFQUFFO0lBQWlCLENBQUMsQ0FBQztFQUNuRixDQUFDLENBQUM7RUFFRixJQUFBYixVQUFFLEVBQUMsMkRBQTJELEVBQUUsTUFBTTtJQUNwRSxNQUFNRyxNQUFNLEdBQUcsQ0FDYlQsS0FBSyxDQUFDO01BQUVFLEVBQUUsRUFBRSxHQUFHO01BQUVDLElBQUksRUFBRSxJQUFJO01BQUVDLElBQUksRUFBRTtJQUFVLENBQUMsQ0FBQyxFQUMvQ0osS0FBSyxDQUFDO01BQUVFLEVBQUUsRUFBRSxHQUFHO01BQUVDLElBQUksRUFBRSxJQUFJO01BQUVDLElBQUksRUFBRTtJQUFVLENBQUMsQ0FBQyxDQUNoRDtJQUNELElBQUFNLGNBQU0sRUFBQyxJQUFBQyw4QkFBb0IsRUFBQ0YsTUFBTSxDQUFDLENBQUMsQ0FBQ0csT0FBTyxDQUFDO01BQUVDLEVBQUUsRUFBRSxLQUFLO01BQUVNLE1BQU0sRUFBRTtJQUFZLENBQUMsQ0FBQztFQUNsRixDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7O0FBRUY7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFBZCxnQkFBUSxFQUFDLDJEQUEyRCxFQUFFLE1BQU07RUFDMUUsTUFBTWUsV0FBVyxHQUFHO0lBQUVDLElBQUksRUFBRSxlQUFlO0lBQUVDLE1BQU0sRUFBRTtNQUFFQyxHQUFHLEVBQUU7SUFBbUI7RUFBRSxDQUFDO0VBQ2xGLE1BQU1DLGdCQUFnQixHQUFHeEIsS0FBSyxDQUFDO0lBQzdCRSxFQUFFLEVBQUUsa0JBQWtCO0lBQ3RCQyxJQUFJLEVBQUUsa0JBQWtCO0lBQ3hCQyxJQUFJLEVBQUUsaUJBQWlCO0lBQ3ZCSSxJQUFJLEVBQUU7RUFDUixDQUFDLENBQUM7RUFFRixJQUFBRixVQUFFLEVBQUMsMEdBQTBHLEVBQUUsTUFBTTtJQUNuSCxNQUFNRyxNQUFNLEdBQUcsQ0FBQ1QsS0FBSyxDQUFDO01BQUVFLEVBQUUsRUFBRSxLQUFLO01BQUVDLElBQUksRUFBRSxNQUFNO01BQUVDLElBQUksRUFBRTtJQUFNLENBQUMsQ0FBQyxFQUFFb0IsZ0JBQWdCLENBQUM7SUFDbEYsSUFBQWQsY0FBTSxFQUFDLElBQUFDLDhCQUFvQixFQUFDRixNQUFNLEVBQUVXLFdBQVcsQ0FBQyxDQUFDLENBQUNSLE9BQU8sQ0FBQztNQUN4REMsRUFBRSxFQUFFLElBQUk7TUFDUkMsSUFBSSxFQUFFLGtCQUFrQjtNQUN4QkMsR0FBRyxFQUFFLGlCQUFpQjtNQUN0QmYsS0FBSyxFQUFFd0I7SUFDVCxDQUFDLENBQUM7RUFDSixDQUFDLENBQUM7RUFFRixJQUFBbEIsVUFBRSxFQUFDLDhJQUE4SSxFQUFFLE1BQU07SUFDdkosTUFBTVUsQ0FBQyxHQUFHLElBQUFMLDhCQUFvQixFQUFDLENBQUNhLGdCQUFnQixDQUFDLEVBQUVKLFdBQVcsQ0FBQztJQUMvRCxJQUFJLENBQUNKLENBQUMsQ0FBQ0gsRUFBRSxFQUFFLE1BQU0sSUFBSUksS0FBSyxDQUFDLGFBQWEsQ0FBQztJQUN6QyxJQUFBUCxjQUFNLEVBQUNNLENBQUMsQ0FBQ2hCLEtBQUssQ0FBQ1EsSUFBSSxDQUFDLENBQUNVLElBQUksQ0FBQyxJQUFJLENBQUM7SUFDL0IsTUFBTU8sRUFBRSxHQUFHekIsS0FBSyxDQUFDO01BQUVFLEVBQUUsRUFBRSxrQkFBa0I7TUFBRUMsSUFBSSxFQUFFLGtCQUFrQjtNQUFFQyxJQUFJLEVBQUUsaUJBQWlCO01BQUVJLElBQUksRUFBRTtJQUFLLENBQUMsQ0FBQztJQUMzRyxNQUFNa0IsRUFBRSxHQUFHLElBQUFmLDhCQUFvQixFQUFDLENBQUNjLEVBQUUsQ0FBQyxFQUFFTCxXQUFXLENBQUM7SUFDbEQsSUFBSSxDQUFDTSxFQUFFLENBQUNiLEVBQUUsRUFBRSxNQUFNLElBQUlJLEtBQUssQ0FBQyxhQUFhLENBQUM7SUFDMUMsSUFBQVAsY0FBTSxFQUFDZ0IsRUFBRSxDQUFDMUIsS0FBSyxDQUFDUSxJQUFJLENBQUMsQ0FBQ1UsSUFBSSxDQUFDLElBQUksQ0FBQztFQUNsQyxDQUFDLENBQUM7RUFFRixJQUFBWixVQUFFLEVBQUMsc0VBQXNFLEVBQUUsTUFBTTtJQUMvRSxNQUFNcUIsSUFBSSxHQUFHM0IsS0FBSyxDQUFDO01BQUVFLEVBQUUsRUFBRSxrQkFBa0I7TUFBRUMsSUFBSSxFQUFFLFlBQVk7TUFBRUMsSUFBSSxFQUFFLGlCQUFpQjtNQUFFSSxJQUFJLEVBQUU7SUFBSyxDQUFDLENBQUM7SUFDdkcsTUFBTVEsQ0FBQyxHQUFHLElBQUFMLDhCQUFvQixFQUFDLENBQUNnQixJQUFJLENBQUMsRUFBRVAsV0FBVyxDQUFDO0lBQ25ELElBQUksQ0FBQ0osQ0FBQyxDQUFDSCxFQUFFLEVBQUUsTUFBTSxJQUFJSSxLQUFLLENBQUMsYUFBYSxDQUFDO0lBQ3pDLElBQUFQLGNBQU0sRUFBQ00sQ0FBQyxDQUFDaEIsS0FBSyxDQUFDLENBQUNrQixJQUFJLENBQUNTLElBQUksQ0FBQztFQUM1QixDQUFDLENBQUM7RUFFRixJQUFBckIsVUFBRSxFQUFDLGtHQUFrRyxFQUFFLE1BQU07SUFDM0csSUFBQUksY0FBTSxFQUFDLElBQUFDLDhCQUFvQixFQUFDLENBQUNhLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDWixPQUFPLENBQUM7TUFBRUMsRUFBRSxFQUFFLEtBQUs7TUFBRU0sTUFBTSxFQUFFO0lBQWlCLENBQUMsQ0FBQztJQUNqRyxJQUFBVCxjQUFNLEVBQUMsSUFBQUMsOEJBQW9CLEVBQUMsQ0FBQ2EsZ0JBQWdCLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDWixPQUFPLENBQUM7TUFBRUMsRUFBRSxFQUFFLEtBQUs7TUFBRU0sTUFBTSxFQUFFO0lBQWlCLENBQUMsQ0FBQztFQUN6RyxDQUFDLENBQUM7RUFFRixJQUFBYixVQUFFLEVBQUMscURBQXFELEVBQUUsTUFBTTtJQUM5RCxNQUFNc0IsS0FBSyxHQUFHO01BQUVQLElBQUksRUFBRSxXQUFXO01BQUVDLE1BQU0sRUFBRTtRQUFFQyxHQUFHLEVBQUU7TUFBbUI7SUFBRSxDQUFDO0lBQ3hFLElBQUFiLGNBQU0sRUFBQyxJQUFBQyw4QkFBb0IsRUFBQyxDQUFDYSxnQkFBZ0IsQ0FBQyxFQUFFSSxLQUFLLENBQUMsQ0FBQyxDQUFDaEIsT0FBTyxDQUFDO01BQUVDLEVBQUUsRUFBRSxLQUFLO01BQUVNLE1BQU0sRUFBRTtJQUFpQixDQUFDLENBQUM7RUFDMUcsQ0FBQyxDQUFDO0VBRUYsSUFBQWIsVUFBRSxFQUFDLDBHQUEwRyxFQUFFLE1BQU07SUFDbkgsSUFBQUksY0FBTSxFQUFDLElBQUFDLDhCQUFvQixFQUFDLENBQUNYLEtBQUssQ0FBQztNQUFFRSxFQUFFLEVBQUUsS0FBSztNQUFFQyxJQUFJLEVBQUUsTUFBTTtNQUFFQyxJQUFJLEVBQUU7SUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFZ0IsV0FBVyxDQUFDLENBQUMsQ0FBQ1IsT0FBTyxDQUFDO01BQ25HQyxFQUFFLEVBQUUsS0FBSztNQUNUTSxNQUFNLEVBQUU7SUFDVixDQUFDLENBQUM7SUFDRixNQUFNWixFQUFFLEdBQUdQLEtBQUssQ0FBQztNQUFFRSxFQUFFLEVBQUUsYUFBYTtNQUFFQyxJQUFJLEVBQUUsUUFBUTtNQUFFQyxJQUFJLEVBQUUsU0FBUztNQUFFSSxJQUFJLEVBQUU7SUFBSyxDQUFDLENBQUM7SUFDcEYsSUFBQUUsY0FBTSxFQUFDLElBQUFDLDhCQUFvQixFQUFDLENBQUNKLEVBQUUsQ0FBQyxFQUFFYSxXQUFXLENBQUMsQ0FBQyxDQUFDUixPQUFPLENBQUM7TUFBRUMsRUFBRSxFQUFFLElBQUk7TUFBRUMsSUFBSSxFQUFFLFFBQVE7TUFBRUMsR0FBRyxFQUFFLFdBQVc7TUFBRWYsS0FBSyxFQUFFTztJQUFHLENBQUMsQ0FBQztFQUNwSCxDQUFDLENBQUM7RUFFRixJQUFBRCxVQUFFLEVBQUMsbURBQW1ELEVBQUUsTUFBTTtJQUM1RCxJQUFBSSxjQUFNLEVBQUMsSUFBQUMsOEJBQW9CLEVBQUMsQ0FBQ2EsZ0JBQWdCLENBQUMsRUFBRTtNQUFFSCxJQUFJLEVBQUUsZUFBZTtNQUFFQyxNQUFNLEVBQUU7UUFBRUMsR0FBRyxFQUFFO01BQUc7SUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDWCxPQUFPLENBQUM7TUFDdkdDLEVBQUUsRUFBRSxLQUFLO01BQ1RNLE1BQU0sRUFBRTtJQUNWLENBQUMsQ0FBQztJQUNGLElBQUFULGNBQU0sRUFBQyxJQUFBQyw4QkFBb0IsRUFBQyxDQUFDYSxnQkFBZ0IsQ0FBQyxFQUFFO01BQUVILElBQUksRUFBRSxlQUFlO01BQUVDLE1BQU0sRUFBRSxDQUFDO0lBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQ1YsT0FBTyxDQUFDO01BQzlGQyxFQUFFLEVBQUUsS0FBSztNQUNUTSxNQUFNLEVBQUU7SUFDVixDQUFDLENBQUM7RUFDSixDQUFDLENBQUM7RUFFRixJQUFBYixVQUFFLEVBQUMsNERBQTRELEVBQUUsTUFBTTtJQUNyRSxNQUFNdUIsR0FBRyxHQUFHN0IsS0FBSyxDQUFDO01BQUVFLEVBQUUsRUFBRSxrQkFBa0I7TUFBRUMsSUFBSSxFQUFFLGtCQUFrQjtNQUFFQyxJQUFJLEVBQUUsaUJBQWlCO01BQUVJLElBQUksRUFBRTtJQUFLLENBQUMsQ0FBQztJQUM1RyxJQUFBRSxjQUFNLEVBQUMsSUFBQUMsOEJBQW9CLEVBQUMsQ0FBQ2EsZ0JBQWdCLEVBQUVLLEdBQUcsQ0FBQyxFQUFFVCxXQUFXLENBQUMsQ0FBQyxDQUFDUixPQUFPLENBQUM7TUFBRUMsRUFBRSxFQUFFLEtBQUs7TUFBRU0sTUFBTSxFQUFFO0lBQVksQ0FBQyxDQUFDO0VBQ2hILENBQUMsQ0FBQztFQUVGLElBQUFiLFVBQUUsRUFBQyx5R0FBeUcsRUFBRSxNQUFNO0lBQ2xILE1BQU1DLEVBQUUsR0FBR1AsS0FBSyxDQUFDO01BQUVFLEVBQUUsRUFBRSxhQUFhO01BQUVDLElBQUksRUFBRSxRQUFRO01BQUVDLElBQUksRUFBRSxTQUFTO01BQUVJLElBQUksRUFBRTtJQUFLLENBQUMsQ0FBQztJQUNwRixJQUFBRSxjQUFNLEVBQUMsSUFBQUMsOEJBQW9CLEVBQUMsQ0FBQ0osRUFBRSxFQUFFaUIsZ0JBQWdCLENBQUMsRUFBRUosV0FBVyxDQUFDLENBQUMsQ0FBQ1IsT0FBTyxDQUFDO01BQUVDLEVBQUUsRUFBRSxLQUFLO01BQUVNLE1BQU0sRUFBRTtJQUFZLENBQUMsQ0FBQztFQUMvRyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMiLCJpZ25vcmVMaXN0IjpbXX0=