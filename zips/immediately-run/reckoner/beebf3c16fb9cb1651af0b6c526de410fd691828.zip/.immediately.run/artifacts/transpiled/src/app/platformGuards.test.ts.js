"use strict";

require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.find.js");
var _vitest = require("vitest");
var _nodeFs = require("node:fs");
var _nodePath = require("node:path");
// Platform guards: source-level invariants that only fail on immediately.run (the
// "works in vite dev, breaks on the platform" trap). Vitest runs in Node; these read the
// repo's own source and fail loudly at test time, not in a user's browser.

/** Modules exempt from each guard, with the reason each is safe. */
const IMPORT_META_EXEMPT = new Set([
// vite-only dev entry — the platform never loads it (entry is App.tsx's default export).
'src/main.tsx',
// the one sanctioned home of import.meta.url, reached only via dynamic import inside
// makeTransport's try/catch, so its parse failure on the platform is catchable.
'src/app/workerUrl.ts']);
function* tsFiles(dir) {
  for (const name of (0, _nodeFs.readdirSync)(dir)) {
    const p = (0, _nodePath.join)(dir, name);
    if ((0, _nodeFs.statSync)(p).isDirectory()) yield* tsFiles(p);else if (/\.(ts|tsx)$/.test(name) && !/\.test\.(ts|tsx)$/.test(name)) yield p;
  }
}

/** Strip line + block comments (crude but sufficient: we only need to not match prose). */
function withoutComments(source) {
  return source.replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|\s)\/\/.*$/gm, '');
}
(0, _vitest.describe)('the immediately.run compatibility guards', () => {
  (0, _vitest.it)('no module the platform loads contains import.meta (outside the two exempt files)', () => {
    const offenders = [];
    for (const path of tsFiles((0, _nodePath.join)(process.cwd(), 'src'))) {
      // Normalize to the repo-relative `src/...` path (the walker yields absolute paths).
      const relFromSrc = `src/${path.split(/[/\\]src[/\\]/)[1]?.replace(/\\/g, '/') ?? ''}`;
      if (IMPORT_META_EXEMPT.has(relFromSrc)) continue;
      if (/import\.meta/.test(withoutComments((0, _nodeFs.readFileSync)(path, 'utf8')))) offenders.push(relFromSrc);
    }
    // Rationale: the platform transpiles ESM→CJS and evaluates classic scripts, where
    // import.meta is a parse-time SyntaxError that kills the whole module — caught live on
    // 2026-08-24 when the reckoner demo first ran on production.
    (0, _vitest.expect)(offenders).toEqual([]);
  });
  (0, _vitest.it)('no module STATICALLY value-imports the SDK task surface (DOCUMENT_NAVIGATOR_SPEC §4.1)', () => {
    const offenders = [];
    for (const path of tsFiles((0, _nodePath.join)(process.cwd(), 'src'))) {
      const relFromSrc = `src/${path.split(/[/\\]src[/\\]/)[1]?.replace(/\\/g, '/') ?? ''}`;
      const source = withoutComments((0, _nodeFs.readFileSync)(path, 'utf8'));
      // `import type … from '@immediately-run/sdk[/tasks]'` is erased at compile time and
      // is fine; a VALUE import of the task surface is not. `await import(...)` is not a
      // static import statement and so never matches.
      const statics = source.match(/^\s*import\s+(?!type\b)[^;]*from\s*['"]@immediately-run\/sdk(?:\/tasks)?['"]/gm) ?? [];
      for (const stmt of statics) {
        // Only the task surface carries the load-time listener; the root barrel re-exports it.
        if (/@immediately-run\/sdk(\/tasks)?['"]$/.test(stmt.trim())) offenders.push(relFromSrc);
      }
    }
    // Rationale: `@immediately-run/sdk/tasks` registers a host listener at module
    // load — the side effect the §4.1/DN-R5 discipline keeps behind `await import()`
    // inside the handler (the pattern makeTransport already uses for workerUrl).
    // (Accuracy, review round 5: since SDK R3-421 / ≥0.57.3 the registration is
    // try/catch-wrapped and no longer throws off-host; pre-R3-421 it white-screened
    // plain `vite dev`, which is the history the discipline was written against.)
    // `mounts` is side-effect-clean and is imported normally in useMounts.ts.
    (0, _vitest.expect)(offenders).toEqual([]);
  });
});

// G-DN-B10's reckoner half (R3-447): the manifest `invokes` declaration is the
// self-restriction that admits the edit-file task — an artifact no test read before,
// so deleting it left every suite green (the "ships dark, permanently" failure mode
// DN-R6 records). Pinned here, beside the other source-level platform contracts.
(0, _vitest.describe)('the manifest declares what it invokes (DOCUMENT_NAVIGATOR_SPEC G-DN-B10)', () => {
  (0, _vitest.it)('package.json declares invokes: edit-file at the contract version 1.0', () => {
    const pkg = JSON.parse((0, _nodeFs.readFileSync)((0, _nodePath.join)(__dirname, '../../package.json'), 'utf8'));
    const invokes = pkg['immediately.run']?.invokes ?? [];
    const editFile = invokes.find(i => i.task === 'edit-file');
    (0, _vitest.expect)(editFile).toMatchObject({
      task: 'edit-file',
      version: '1.0'
    });
  });

  // R3-754: `requests.net:fetch.required:false` is load-bearing the same way — the
  // host's M2 admission computes the REQUIRED-request delta against the binding's
  // snapshot and refuses the task invoke (consent-required, no overlay) when a
  // required request is missing from it; this app renders workbooks without
  // fetching. No test read the `requests` block before, so flipping the flag back
  // re-broke every task invoke with the suite green — the exact ships-dark failure
  // mode DN-R6 records, on the admission leg instead of the invokes leg.
  // (2026-09-29, rebase onto R3-768: the egress was REMOVED wholesale — the report
  // view fetches nothing — so the block is gone rather than flagged. The invariant
  // that matters to admission is "no REQUIRED net:fetch": absent or explicitly
  // non-required both satisfy it; `required: true` fails here.)
  (0, _vitest.it)('package.json declares no REQUIRED net:fetch (the M2 admission leg, R3-754/R3-768)', () => {
    const pkg = JSON.parse((0, _nodeFs.readFileSync)((0, _nodePath.join)(__dirname, '../../package.json'), 'utf8'));
    (0, _vitest.expect)(pkg['immediately.run']?.requests?.['net:fetch']?.required ?? false).toBe(false);
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZXN0IiwicmVxdWlyZSIsIl9ub2RlRnMiLCJfbm9kZVBhdGgiLCJJTVBPUlRfTUVUQV9FWEVNUFQiLCJTZXQiLCJ0c0ZpbGVzIiwiZGlyIiwibmFtZSIsInJlYWRkaXJTeW5jIiwicCIsImpvaW4iLCJzdGF0U3luYyIsImlzRGlyZWN0b3J5IiwidGVzdCIsIndpdGhvdXRDb21tZW50cyIsInNvdXJjZSIsInJlcGxhY2UiLCJkZXNjcmliZSIsIml0Iiwib2ZmZW5kZXJzIiwicGF0aCIsInByb2Nlc3MiLCJjd2QiLCJyZWxGcm9tU3JjIiwic3BsaXQiLCJoYXMiLCJyZWFkRmlsZVN5bmMiLCJwdXNoIiwiZXhwZWN0IiwidG9FcXVhbCIsInN0YXRpY3MiLCJtYXRjaCIsInN0bXQiLCJ0cmltIiwicGtnIiwiSlNPTiIsInBhcnNlIiwiX19kaXJuYW1lIiwiaW52b2tlcyIsImVkaXRGaWxlIiwiZmluZCIsImkiLCJ0YXNrIiwidG9NYXRjaE9iamVjdCIsInZlcnNpb24iLCJyZXF1ZXN0cyIsInJlcXVpcmVkIiwidG9CZSJdLCJzb3VyY2VzIjpbInBsYXRmb3JtR3VhcmRzLnRlc3QudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gUGxhdGZvcm0gZ3VhcmRzOiBzb3VyY2UtbGV2ZWwgaW52YXJpYW50cyB0aGF0IG9ubHkgZmFpbCBvbiBpbW1lZGlhdGVseS5ydW4gKHRoZVxuLy8gXCJ3b3JrcyBpbiB2aXRlIGRldiwgYnJlYWtzIG9uIHRoZSBwbGF0Zm9ybVwiIHRyYXApLiBWaXRlc3QgcnVucyBpbiBOb2RlOyB0aGVzZSByZWFkIHRoZVxuLy8gcmVwbydzIG93biBzb3VyY2UgYW5kIGZhaWwgbG91ZGx5IGF0IHRlc3QgdGltZSwgbm90IGluIGEgdXNlcidzIGJyb3dzZXIuXG5pbXBvcnQgeyBkZXNjcmliZSwgaXQsIGV4cGVjdCB9IGZyb20gJ3ZpdGVzdCc7XG5pbXBvcnQgeyByZWFkRmlsZVN5bmMsIHJlYWRkaXJTeW5jLCBzdGF0U3luYyB9IGZyb20gJ25vZGU6ZnMnO1xuaW1wb3J0IHsgam9pbiB9IGZyb20gJ25vZGU6cGF0aCc7XG5cbi8qKiBNb2R1bGVzIGV4ZW1wdCBmcm9tIGVhY2ggZ3VhcmQsIHdpdGggdGhlIHJlYXNvbiBlYWNoIGlzIHNhZmUuICovXG5jb25zdCBJTVBPUlRfTUVUQV9FWEVNUFQgPSBuZXcgU2V0KFtcbiAgLy8gdml0ZS1vbmx5IGRldiBlbnRyeSDigJQgdGhlIHBsYXRmb3JtIG5ldmVyIGxvYWRzIGl0IChlbnRyeSBpcyBBcHAudHN4J3MgZGVmYXVsdCBleHBvcnQpLlxuICAnc3JjL21haW4udHN4JyxcbiAgLy8gdGhlIG9uZSBzYW5jdGlvbmVkIGhvbWUgb2YgaW1wb3J0Lm1ldGEudXJsLCByZWFjaGVkIG9ubHkgdmlhIGR5bmFtaWMgaW1wb3J0IGluc2lkZVxuICAvLyBtYWtlVHJhbnNwb3J0J3MgdHJ5L2NhdGNoLCBzbyBpdHMgcGFyc2UgZmFpbHVyZSBvbiB0aGUgcGxhdGZvcm0gaXMgY2F0Y2hhYmxlLlxuICAnc3JjL2FwcC93b3JrZXJVcmwudHMnLFxuXSk7XG5cbmZ1bmN0aW9uKiB0c0ZpbGVzKGRpcjogc3RyaW5nKTogR2VuZXJhdG9yPHN0cmluZz4ge1xuICBmb3IgKGNvbnN0IG5hbWUgb2YgcmVhZGRpclN5bmMoZGlyKSkge1xuICAgIGNvbnN0IHAgPSBqb2luKGRpciwgbmFtZSk7XG4gICAgaWYgKHN0YXRTeW5jKHApLmlzRGlyZWN0b3J5KCkpIHlpZWxkKiB0c0ZpbGVzKHApO1xuICAgIGVsc2UgaWYgKC9cXC4odHN8dHN4KSQvLnRlc3QobmFtZSkgJiYgIS9cXC50ZXN0XFwuKHRzfHRzeCkkLy50ZXN0KG5hbWUpKSB5aWVsZCBwO1xuICB9XG59XG5cbi8qKiBTdHJpcCBsaW5lICsgYmxvY2sgY29tbWVudHMgKGNydWRlIGJ1dCBzdWZmaWNpZW50OiB3ZSBvbmx5IG5lZWQgdG8gbm90IG1hdGNoIHByb3NlKS4gKi9cbmZ1bmN0aW9uIHdpdGhvdXRDb21tZW50cyhzb3VyY2U6IHN0cmluZyk6IHN0cmluZyB7XG4gIHJldHVybiBzb3VyY2UucmVwbGFjZSgvXFwvXFwqW1xcc1xcU10qP1xcKlxcLy9nLCAnJykucmVwbGFjZSgvKF58XFxzKVxcL1xcLy4qJC9nbSwgJycpO1xufVxuXG5kZXNjcmliZSgndGhlIGltbWVkaWF0ZWx5LnJ1biBjb21wYXRpYmlsaXR5IGd1YXJkcycsICgpID0+IHtcbiAgaXQoJ25vIG1vZHVsZSB0aGUgcGxhdGZvcm0gbG9hZHMgY29udGFpbnMgaW1wb3J0Lm1ldGEgKG91dHNpZGUgdGhlIHR3byBleGVtcHQgZmlsZXMpJywgKCkgPT4ge1xuICAgIGNvbnN0IG9mZmVuZGVyczogc3RyaW5nW10gPSBbXTtcbiAgICBmb3IgKGNvbnN0IHBhdGggb2YgdHNGaWxlcyhqb2luKHByb2Nlc3MuY3dkKCksICdzcmMnKSkpIHtcbiAgICAgIC8vIE5vcm1hbGl6ZSB0byB0aGUgcmVwby1yZWxhdGl2ZSBgc3JjLy4uLmAgcGF0aCAodGhlIHdhbGtlciB5aWVsZHMgYWJzb2x1dGUgcGF0aHMpLlxuICAgICAgY29uc3QgcmVsRnJvbVNyYyA9IGBzcmMvJHtwYXRoLnNwbGl0KC9bL1xcXFxdc3JjWy9cXFxcXS8pWzFdPy5yZXBsYWNlKC9cXFxcL2csICcvJykgPz8gJyd9YDtcbiAgICAgIGlmIChJTVBPUlRfTUVUQV9FWEVNUFQuaGFzKHJlbEZyb21TcmMpKSBjb250aW51ZTtcbiAgICAgIGlmICgvaW1wb3J0XFwubWV0YS8udGVzdCh3aXRob3V0Q29tbWVudHMocmVhZEZpbGVTeW5jKHBhdGgsICd1dGY4JykpKSkgb2ZmZW5kZXJzLnB1c2gocmVsRnJvbVNyYyk7XG4gICAgfVxuICAgIC8vIFJhdGlvbmFsZTogdGhlIHBsYXRmb3JtIHRyYW5zcGlsZXMgRVNN4oaSQ0pTIGFuZCBldmFsdWF0ZXMgY2xhc3NpYyBzY3JpcHRzLCB3aGVyZVxuICAgIC8vIGltcG9ydC5tZXRhIGlzIGEgcGFyc2UtdGltZSBTeW50YXhFcnJvciB0aGF0IGtpbGxzIHRoZSB3aG9sZSBtb2R1bGUg4oCUIGNhdWdodCBsaXZlIG9uXG4gICAgLy8gMjAyNi0wOC0yNCB3aGVuIHRoZSByZWNrb25lciBkZW1vIGZpcnN0IHJhbiBvbiBwcm9kdWN0aW9uLlxuICAgIGV4cGVjdChvZmZlbmRlcnMpLnRvRXF1YWwoW10pO1xuICB9KTtcblxuICBpdCgnbm8gbW9kdWxlIFNUQVRJQ0FMTFkgdmFsdWUtaW1wb3J0cyB0aGUgU0RLIHRhc2sgc3VyZmFjZSAoRE9DVU1FTlRfTkFWSUdBVE9SX1NQRUMgwqc0LjEpJywgKCkgPT4ge1xuICAgIGNvbnN0IG9mZmVuZGVyczogc3RyaW5nW10gPSBbXTtcbiAgICBmb3IgKGNvbnN0IHBhdGggb2YgdHNGaWxlcyhqb2luKHByb2Nlc3MuY3dkKCksICdzcmMnKSkpIHtcbiAgICAgIGNvbnN0IHJlbEZyb21TcmMgPSBgc3JjLyR7cGF0aC5zcGxpdCgvWy9cXFxcXXNyY1svXFxcXF0vKVsxXT8ucmVwbGFjZSgvXFxcXC9nLCAnLycpID8/ICcnfWA7XG4gICAgICBjb25zdCBzb3VyY2UgPSB3aXRob3V0Q29tbWVudHMocmVhZEZpbGVTeW5jKHBhdGgsICd1dGY4JykpO1xuICAgICAgLy8gYGltcG9ydCB0eXBlIOKApiBmcm9tICdAaW1tZWRpYXRlbHktcnVuL3Nka1svdGFza3NdJ2AgaXMgZXJhc2VkIGF0IGNvbXBpbGUgdGltZSBhbmRcbiAgICAgIC8vIGlzIGZpbmU7IGEgVkFMVUUgaW1wb3J0IG9mIHRoZSB0YXNrIHN1cmZhY2UgaXMgbm90LiBgYXdhaXQgaW1wb3J0KC4uLilgIGlzIG5vdCBhXG4gICAgICAvLyBzdGF0aWMgaW1wb3J0IHN0YXRlbWVudCBhbmQgc28gbmV2ZXIgbWF0Y2hlcy5cbiAgICAgIGNvbnN0IHN0YXRpY3MgPSBzb3VyY2UubWF0Y2goL15cXHMqaW1wb3J0XFxzKyg/IXR5cGVcXGIpW147XSpmcm9tXFxzKlsnXCJdQGltbWVkaWF0ZWx5LXJ1blxcL3Nkayg/OlxcL3Rhc2tzKT9bJ1wiXS9nbSkgPz8gW107XG4gICAgICBmb3IgKGNvbnN0IHN0bXQgb2Ygc3RhdGljcykge1xuICAgICAgICAvLyBPbmx5IHRoZSB0YXNrIHN1cmZhY2UgY2FycmllcyB0aGUgbG9hZC10aW1lIGxpc3RlbmVyOyB0aGUgcm9vdCBiYXJyZWwgcmUtZXhwb3J0cyBpdC5cbiAgICAgICAgaWYgKC9AaW1tZWRpYXRlbHktcnVuXFwvc2RrKFxcL3Rhc2tzKT9bJ1wiXSQvLnRlc3Qoc3RtdC50cmltKCkpKSBvZmZlbmRlcnMucHVzaChyZWxGcm9tU3JjKTtcbiAgICAgIH1cbiAgICB9XG4gICAgLy8gUmF0aW9uYWxlOiBgQGltbWVkaWF0ZWx5LXJ1bi9zZGsvdGFza3NgIHJlZ2lzdGVycyBhIGhvc3QgbGlzdGVuZXIgYXQgbW9kdWxlXG4gICAgLy8gbG9hZCDigJQgdGhlIHNpZGUgZWZmZWN0IHRoZSDCpzQuMS9ETi1SNSBkaXNjaXBsaW5lIGtlZXBzIGJlaGluZCBgYXdhaXQgaW1wb3J0KClgXG4gICAgLy8gaW5zaWRlIHRoZSBoYW5kbGVyICh0aGUgcGF0dGVybiBtYWtlVHJhbnNwb3J0IGFscmVhZHkgdXNlcyBmb3Igd29ya2VyVXJsKS5cbiAgICAvLyAoQWNjdXJhY3ksIHJldmlldyByb3VuZCA1OiBzaW5jZSBTREsgUjMtNDIxIC8g4omlMC41Ny4zIHRoZSByZWdpc3RyYXRpb24gaXNcbiAgICAvLyB0cnkvY2F0Y2gtd3JhcHBlZCBhbmQgbm8gbG9uZ2VyIHRocm93cyBvZmYtaG9zdDsgcHJlLVIzLTQyMSBpdCB3aGl0ZS1zY3JlZW5lZFxuICAgIC8vIHBsYWluIGB2aXRlIGRldmAsIHdoaWNoIGlzIHRoZSBoaXN0b3J5IHRoZSBkaXNjaXBsaW5lIHdhcyB3cml0dGVuIGFnYWluc3QuKVxuICAgIC8vIGBtb3VudHNgIGlzIHNpZGUtZWZmZWN0LWNsZWFuIGFuZCBpcyBpbXBvcnRlZCBub3JtYWxseSBpbiB1c2VNb3VudHMudHMuXG4gICAgZXhwZWN0KG9mZmVuZGVycykudG9FcXVhbChbXSk7XG4gIH0pO1xufSk7XG5cbi8vIEctRE4tQjEwJ3MgcmVja29uZXIgaGFsZiAoUjMtNDQ3KTogdGhlIG1hbmlmZXN0IGBpbnZva2VzYCBkZWNsYXJhdGlvbiBpcyB0aGVcbi8vIHNlbGYtcmVzdHJpY3Rpb24gdGhhdCBhZG1pdHMgdGhlIGVkaXQtZmlsZSB0YXNrIOKAlCBhbiBhcnRpZmFjdCBubyB0ZXN0IHJlYWQgYmVmb3JlLFxuLy8gc28gZGVsZXRpbmcgaXQgbGVmdCBldmVyeSBzdWl0ZSBncmVlbiAodGhlIFwic2hpcHMgZGFyaywgcGVybWFuZW50bHlcIiBmYWlsdXJlIG1vZGVcbi8vIEROLVI2IHJlY29yZHMpLiBQaW5uZWQgaGVyZSwgYmVzaWRlIHRoZSBvdGhlciBzb3VyY2UtbGV2ZWwgcGxhdGZvcm0gY29udHJhY3RzLlxuZGVzY3JpYmUoJ3RoZSBtYW5pZmVzdCBkZWNsYXJlcyB3aGF0IGl0IGludm9rZXMgKERPQ1VNRU5UX05BVklHQVRPUl9TUEVDIEctRE4tQjEwKScsICgpID0+IHtcbiAgaXQoJ3BhY2thZ2UuanNvbiBkZWNsYXJlcyBpbnZva2VzOiBlZGl0LWZpbGUgYXQgdGhlIGNvbnRyYWN0IHZlcnNpb24gMS4wJywgKCkgPT4ge1xuICAgIGNvbnN0IHBrZyA9IEpTT04ucGFyc2UocmVhZEZpbGVTeW5jKGpvaW4oX19kaXJuYW1lLCAnLi4vLi4vcGFja2FnZS5qc29uJyksICd1dGY4JykpIGFzIHtcbiAgICAgICdpbW1lZGlhdGVseS5ydW4nPzogeyBpbnZva2VzPzogeyB0YXNrOiBzdHJpbmc7IHZlcnNpb246IHN0cmluZyB9W10gfTtcbiAgICB9O1xuICAgIGNvbnN0IGludm9rZXMgPSBwa2dbJ2ltbWVkaWF0ZWx5LnJ1biddPy5pbnZva2VzID8/IFtdO1xuICAgIGNvbnN0IGVkaXRGaWxlID0gaW52b2tlcy5maW5kKChpKSA9PiBpLnRhc2sgPT09ICdlZGl0LWZpbGUnKTtcbiAgICBleHBlY3QoZWRpdEZpbGUpLnRvTWF0Y2hPYmplY3QoeyB0YXNrOiAnZWRpdC1maWxlJywgdmVyc2lvbjogJzEuMCcgfSk7XG4gIH0pO1xuXG4gIC8vIFIzLTc1NDogYHJlcXVlc3RzLm5ldDpmZXRjaC5yZXF1aXJlZDpmYWxzZWAgaXMgbG9hZC1iZWFyaW5nIHRoZSBzYW1lIHdheSDigJQgdGhlXG4gIC8vIGhvc3QncyBNMiBhZG1pc3Npb24gY29tcHV0ZXMgdGhlIFJFUVVJUkVELXJlcXVlc3QgZGVsdGEgYWdhaW5zdCB0aGUgYmluZGluZydzXG4gIC8vIHNuYXBzaG90IGFuZCByZWZ1c2VzIHRoZSB0YXNrIGludm9rZSAoY29uc2VudC1yZXF1aXJlZCwgbm8gb3ZlcmxheSkgd2hlbiBhXG4gIC8vIHJlcXVpcmVkIHJlcXVlc3QgaXMgbWlzc2luZyBmcm9tIGl0OyB0aGlzIGFwcCByZW5kZXJzIHdvcmtib29rcyB3aXRob3V0XG4gIC8vIGZldGNoaW5nLiBObyB0ZXN0IHJlYWQgdGhlIGByZXF1ZXN0c2AgYmxvY2sgYmVmb3JlLCBzbyBmbGlwcGluZyB0aGUgZmxhZyBiYWNrXG4gIC8vIHJlLWJyb2tlIGV2ZXJ5IHRhc2sgaW52b2tlIHdpdGggdGhlIHN1aXRlIGdyZWVuIOKAlCB0aGUgZXhhY3Qgc2hpcHMtZGFyayBmYWlsdXJlXG4gIC8vIG1vZGUgRE4tUjYgcmVjb3Jkcywgb24gdGhlIGFkbWlzc2lvbiBsZWcgaW5zdGVhZCBvZiB0aGUgaW52b2tlcyBsZWcuXG4gIC8vICgyMDI2LTA5LTI5LCByZWJhc2Ugb250byBSMy03Njg6IHRoZSBlZ3Jlc3Mgd2FzIFJFTU9WRUQgd2hvbGVzYWxlIOKAlCB0aGUgcmVwb3J0XG4gIC8vIHZpZXcgZmV0Y2hlcyBub3RoaW5nIOKAlCBzbyB0aGUgYmxvY2sgaXMgZ29uZSByYXRoZXIgdGhhbiBmbGFnZ2VkLiBUaGUgaW52YXJpYW50XG4gIC8vIHRoYXQgbWF0dGVycyB0byBhZG1pc3Npb24gaXMgXCJubyBSRVFVSVJFRCBuZXQ6ZmV0Y2hcIjogYWJzZW50IG9yIGV4cGxpY2l0bHlcbiAgLy8gbm9uLXJlcXVpcmVkIGJvdGggc2F0aXNmeSBpdDsgYHJlcXVpcmVkOiB0cnVlYCBmYWlscyBoZXJlLilcbiAgaXQoJ3BhY2thZ2UuanNvbiBkZWNsYXJlcyBubyBSRVFVSVJFRCBuZXQ6ZmV0Y2ggKHRoZSBNMiBhZG1pc3Npb24gbGVnLCBSMy03NTQvUjMtNzY4KScsICgpID0+IHtcbiAgICBjb25zdCBwa2cgPSBKU09OLnBhcnNlKHJlYWRGaWxlU3luYyhqb2luKF9fZGlybmFtZSwgJy4uLy4uL3BhY2thZ2UuanNvbicpLCAndXRmOCcpKSBhcyB7XG4gICAgICAnaW1tZWRpYXRlbHkucnVuJz86IHsgcmVxdWVzdHM/OiBSZWNvcmQ8c3RyaW5nLCB7IHJlcXVpcmVkPzogYm9vbGVhbiB9PiB9O1xuICAgIH07XG4gICAgZXhwZWN0KHBrZ1snaW1tZWRpYXRlbHkucnVuJ10/LnJlcXVlc3RzPy5bJ25ldDpmZXRjaCddPy5yZXF1aXJlZCA/PyBmYWxzZSkudG9CZShmYWxzZSk7XG4gIH0pO1xufSk7XG4iXSwibWFwcGluZ3MiOiI7Ozs7QUFHQSxJQUFBQSxPQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxPQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxTQUFBLEdBQUFGLE9BQUE7QUFMQTtBQUNBO0FBQ0E7O0FBS0E7QUFDQSxNQUFNRyxrQkFBa0IsR0FBRyxJQUFJQyxHQUFHLENBQUM7QUFDakM7QUFDQSxjQUFjO0FBQ2Q7QUFDQTtBQUNBLHNCQUFzQixDQUN2QixDQUFDO0FBRUYsVUFBVUMsT0FBT0EsQ0FBQ0MsR0FBVyxFQUFxQjtFQUNoRCxLQUFLLE1BQU1DLElBQUksSUFBSSxJQUFBQyxtQkFBVyxFQUFDRixHQUFHLENBQUMsRUFBRTtJQUNuQyxNQUFNRyxDQUFDLEdBQUcsSUFBQUMsY0FBSSxFQUFDSixHQUFHLEVBQUVDLElBQUksQ0FBQztJQUN6QixJQUFJLElBQUFJLGdCQUFRLEVBQUNGLENBQUMsQ0FBQyxDQUFDRyxXQUFXLENBQUMsQ0FBQyxFQUFFLE9BQU9QLE9BQU8sQ0FBQ0ksQ0FBQyxDQUFDLENBQUMsS0FDNUMsSUFBSSxhQUFhLENBQUNJLElBQUksQ0FBQ04sSUFBSSxDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQ00sSUFBSSxDQUFDTixJQUFJLENBQUMsRUFBRSxNQUFNRSxDQUFDO0VBQy9FO0FBQ0Y7O0FBRUE7QUFDQSxTQUFTSyxlQUFlQSxDQUFDQyxNQUFjLEVBQVU7RUFDL0MsT0FBT0EsTUFBTSxDQUFDQyxPQUFPLENBQUMsbUJBQW1CLEVBQUUsRUFBRSxDQUFDLENBQUNBLE9BQU8sQ0FBQyxpQkFBaUIsRUFBRSxFQUFFLENBQUM7QUFDL0U7QUFFQSxJQUFBQyxnQkFBUSxFQUFDLDBDQUEwQyxFQUFFLE1BQU07RUFDekQsSUFBQUMsVUFBRSxFQUFDLGtGQUFrRixFQUFFLE1BQU07SUFDM0YsTUFBTUMsU0FBbUIsR0FBRyxFQUFFO0lBQzlCLEtBQUssTUFBTUMsSUFBSSxJQUFJZixPQUFPLENBQUMsSUFBQUssY0FBSSxFQUFDVyxPQUFPLENBQUNDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUMsRUFBRTtNQUN0RDtNQUNBLE1BQU1DLFVBQVUsR0FBRyxPQUFPSCxJQUFJLENBQUNJLEtBQUssQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRVIsT0FBTyxDQUFDLEtBQUssRUFBRSxHQUFHLENBQUMsSUFBSSxFQUFFLEVBQUU7TUFDckYsSUFBSWIsa0JBQWtCLENBQUNzQixHQUFHLENBQUNGLFVBQVUsQ0FBQyxFQUFFO01BQ3hDLElBQUksY0FBYyxDQUFDVixJQUFJLENBQUNDLGVBQWUsQ0FBQyxJQUFBWSxvQkFBWSxFQUFDTixJQUFJLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFRCxTQUFTLENBQUNRLElBQUksQ0FBQ0osVUFBVSxDQUFDO0lBQ2xHO0lBQ0E7SUFDQTtJQUNBO0lBQ0EsSUFBQUssY0FBTSxFQUFDVCxTQUFTLENBQUMsQ0FBQ1UsT0FBTyxDQUFDLEVBQUUsQ0FBQztFQUMvQixDQUFDLENBQUM7RUFFRixJQUFBWCxVQUFFLEVBQUMsd0ZBQXdGLEVBQUUsTUFBTTtJQUNqRyxNQUFNQyxTQUFtQixHQUFHLEVBQUU7SUFDOUIsS0FBSyxNQUFNQyxJQUFJLElBQUlmLE9BQU8sQ0FBQyxJQUFBSyxjQUFJLEVBQUNXLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQyxFQUFFO01BQ3RELE1BQU1DLFVBQVUsR0FBRyxPQUFPSCxJQUFJLENBQUNJLEtBQUssQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRVIsT0FBTyxDQUFDLEtBQUssRUFBRSxHQUFHLENBQUMsSUFBSSxFQUFFLEVBQUU7TUFDckYsTUFBTUQsTUFBTSxHQUFHRCxlQUFlLENBQUMsSUFBQVksb0JBQVksRUFBQ04sSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUFDO01BQzFEO01BQ0E7TUFDQTtNQUNBLE1BQU1VLE9BQU8sR0FBR2YsTUFBTSxDQUFDZ0IsS0FBSyxDQUFDLGdGQUFnRixDQUFDLElBQUksRUFBRTtNQUNwSCxLQUFLLE1BQU1DLElBQUksSUFBSUYsT0FBTyxFQUFFO1FBQzFCO1FBQ0EsSUFBSSxzQ0FBc0MsQ0FBQ2pCLElBQUksQ0FBQ21CLElBQUksQ0FBQ0MsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFZCxTQUFTLENBQUNRLElBQUksQ0FBQ0osVUFBVSxDQUFDO01BQzFGO0lBQ0Y7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBLElBQUFLLGNBQU0sRUFBQ1QsU0FBUyxDQUFDLENBQUNVLE9BQU8sQ0FBQyxFQUFFLENBQUM7RUFDL0IsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDOztBQUVGO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBQVosZ0JBQVEsRUFBQywwRUFBMEUsRUFBRSxNQUFNO0VBQ3pGLElBQUFDLFVBQUUsRUFBQyxzRUFBc0UsRUFBRSxNQUFNO0lBQy9FLE1BQU1nQixHQUFHLEdBQUdDLElBQUksQ0FBQ0MsS0FBSyxDQUFDLElBQUFWLG9CQUFZLEVBQUMsSUFBQWhCLGNBQUksRUFBQzJCLFNBQVMsRUFBRSxvQkFBb0IsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUVqRjtJQUNELE1BQU1DLE9BQU8sR0FBR0osR0FBRyxDQUFDLGlCQUFpQixDQUFDLEVBQUVJLE9BQU8sSUFBSSxFQUFFO0lBQ3JELE1BQU1DLFFBQVEsR0FBR0QsT0FBTyxDQUFDRSxJQUFJLENBQUVDLENBQUMsSUFBS0EsQ0FBQyxDQUFDQyxJQUFJLEtBQUssV0FBVyxDQUFDO0lBQzVELElBQUFkLGNBQU0sRUFBQ1csUUFBUSxDQUFDLENBQUNJLGFBQWEsQ0FBQztNQUFFRCxJQUFJLEVBQUUsV0FBVztNQUFFRSxPQUFPLEVBQUU7SUFBTSxDQUFDLENBQUM7RUFDdkUsQ0FBQyxDQUFDOztFQUVGO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxJQUFBMUIsVUFBRSxFQUFDLG1GQUFtRixFQUFFLE1BQU07SUFDNUYsTUFBTWdCLEdBQUcsR0FBR0MsSUFBSSxDQUFDQyxLQUFLLENBQUMsSUFBQVYsb0JBQVksRUFBQyxJQUFBaEIsY0FBSSxFQUFDMkIsU0FBUyxFQUFFLG9CQUFvQixDQUFDLEVBQUUsTUFBTSxDQUFDLENBRWpGO0lBQ0QsSUFBQVQsY0FBTSxFQUFDTSxHQUFHLENBQUMsaUJBQWlCLENBQUMsRUFBRVcsUUFBUSxHQUFHLFdBQVcsQ0FBQyxFQUFFQyxRQUFRLElBQUksS0FBSyxDQUFDLENBQUNDLElBQUksQ0FBQyxLQUFLLENBQUM7RUFDeEYsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDIiwiaWdub3JlTGlzdCI6W119