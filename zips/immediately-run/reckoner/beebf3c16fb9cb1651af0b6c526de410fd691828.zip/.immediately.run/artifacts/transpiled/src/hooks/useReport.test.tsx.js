var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

var _vitest = require("vitest");
var _react = require("react");
var _client = require("react-dom/client");
var _useReport = require("./useReport.ts");
var _seeds = require("../seed/seeds.ts");
var _s2 = $RefreshSig$(); // The report hook's reload half (DOCUMENT_NAVIGATOR_SPEC §4.4, R3-447): the session
// reads the document once, so `reload()` must rebuild it through the same mount
// resolution. The session builder is mocked (its real pipeline has its own suite);
// what this pins is the LIFECYCLE: one build per mount/seed state, and one MORE on
// reload — with nothing remounting.
//
// R3-768 also freezes the hook's feed surface: no seed starts a `FeedRuntime`. That
// invariant is asserted here too — a reintroduced feed path would construct the module
// and fail the guardrail.
// @vitest-environment happy-dom
globalThis.IS_REACT_ACT_ENVIRONMENT = true;
const buildReportSession = _vitest.vi.fn();
_vitest.vi.mock('../app/reportSession.ts', async importOriginal => {
  const real = await importOriginal();
  return {
    ...real,
    buildReportSession: (...a) => buildReportSession(...a)
  };
});

// R3-768 guardrail: the hook must never construct a FeedRuntime (no bundled seed reads
// a live feed). If this is ever instantiated, a feed path was reintroduced.
const FeedRuntime = _vitest.vi.fn();
_vitest.vi.mock('../feed/index.ts', () => ({
  FeedRuntime
}));
const mounts = [];
const session = {
  title: 't',
  tick: 0
};
buildReportSession.mockResolvedValue(session);
let handle = null;
function mountHook(seed) {
  const container = document.createElement('div');
  document.body.appendChild(container);
  const root = (0, _client.createRoot)(container);
  (0, _react.act)(() => {
    var _s = $RefreshSig$();
    _s(root.render(/*#__PURE__*/_s(/*#__PURE__*/(0, _react.createElement)(_s(() => {
      _s();
      handle = {
        state: (0, _useReport.useReport)(seed, mounts)
      };
      return null;
    }, "qJi67n2yF61wlcp+6C6QRdyr6+c=", false, function () {
      return [_useReport.useReport];
    })), "qJi67n2yF61wlcp+6C6QRdyr6+c=", false, function () {
      return [useReport];
    })), "qJi67n2yF61wlcp+6C6QRdyr6+c=", false, function () {
      return [useReport];
    });
  });
}
(0, _vitest.describe)('useReport — reload (§4.4)', () => {
  (0, _vitest.it)('builds once for a stable mount set, and once more on reload()', async () => {
    mountHook(_seeds.MERIDIAN_SEED);
    // flush the async build
    await (0, _react.act)(async () => {});
    (0, _vitest.expect)(buildReportSession).toHaveBeenCalledTimes(1);
    (0, _react.act)(() => handle.state.reload());
    await (0, _react.act)(async () => {});
    (0, _vitest.expect)(buildReportSession).toHaveBeenCalledTimes(2);
    (0, _vitest.expect)(handle.state.reload).toBeTypeOf('function');
  });
  (0, _vitest.it)('never constructs a FeedRuntime for any bundled seed (R3-768)', async () => {
    mountHook(_seeds.MERIDIAN_SEED);
    await (0, _react.act)(async () => {});
    mountHook(_seeds.CALDERA_SEED);
    await (0, _react.act)(async () => {});
    (0, _vitest.expect)(FeedRuntime).not.toHaveBeenCalled();
  });
});

// The R3-754 handoff: the task input must ride through the hook into the session
// builder, and its arrival (the host's re-send ladder lands it AFTER the delegation
// mount) must trigger the rebuild. Both cases render a STABLE component identity so
// a re-render is a re-render, not a remount — the second build has to come from the
// deps/dispatch-key flip, not from a fresh hook.
//
// (Rebase note, 2026-09-29: the PR's third case — "the resolved task shape keeps the
// demo feed off the mounted workbook" — is dropped here as subsumed: R3-768 removed
// the feed runtimes wholesale, and the guardrail above asserts no FeedRuntime is EVER
// constructed. Review round 3 then found the dispatchKey memo itself redundant — its
// only post-R3-768 consumer was the effect deps array that already holds the memo's
// inputs — and it was deleted (mutation-tested behaviour-identical), so the property
// the third case pinned no longer exists to test. The handoff tests below pin what
// remains: the input rides into the session builder, and its late arrival rebuilds.)
const TASK_DIR = '/task/task-1/dir';
const taskMounts = [{
  id: TASK_DIR,
  path: TASK_DIR,
  type: 'task-delegation',
  mode: 'ro'
}];
const taskInput = {
  task: 'open-workbook',
  params: {
    dir: TASK_DIR
  }
};
function Probe(props) {
  _s2();
  (0, _useReport.useReport)(props.s, props.m, props.t);
  return null;
}
_s2(Probe, "qJi67n2yF61wlcp+6C6QRdyr6+c=", false, function () {
  return [_useReport.useReport];
});
_c = Probe;
(0, _vitest.describe)('useReport — the task-input handoff (R3-754)', () => {
  (0, _vitest.it)('the input rides into buildReportSession as the 4th argument — dropping it there fails here', async () => {
    buildReportSession.mockClear();
    const container = document.createElement('div');
    document.body.appendChild(container);
    const root = (0, _client.createRoot)(container);
    (0, _react.act)(() => {
      root.render(/*#__PURE__*/(0, _react.createElement)(Probe, {
        s: _seeds.MERIDIAN_SEED,
        m: taskMounts,
        t: taskInput
      }));
    });
    await (0, _react.act)(async () => {});
    (0, _vitest.expect)(buildReportSession).toHaveBeenCalledTimes(1);
    (0, _vitest.expect)(buildReportSession.mock.calls[0]).toEqual([undefined, _seeds.MERIDIAN_SEED, taskMounts, taskInput]);
    (0, _react.act)(() => root.unmount());
  });
  (0, _vitest.it)('the input arriving AFTER the first build rebuilds once more, carrying it', async () => {
    buildReportSession.mockClear();
    const container = document.createElement('div');
    document.body.appendChild(container);
    const root = (0, _client.createRoot)(container);
    (0, _react.act)(() => {
      root.render(/*#__PURE__*/(0, _react.createElement)(Probe, {
        s: _seeds.MERIDIAN_SEED,
        m: taskMounts,
        t: null
      }));
    });
    await (0, _react.act)(async () => {});
    (0, _vitest.expect)(buildReportSession).toHaveBeenCalledTimes(1);
    (0, _react.act)(() => {
      root.render(/*#__PURE__*/(0, _react.createElement)(Probe, {
        s: _seeds.MERIDIAN_SEED,
        m: taskMounts,
        t: taskInput
      }));
    });
    await (0, _react.act)(async () => {});
    (0, _vitest.expect)(buildReportSession).toHaveBeenCalledTimes(2);
    (0, _vitest.expect)(buildReportSession.mock.calls[1]).toEqual([undefined, _seeds.MERIDIAN_SEED, taskMounts, taskInput]);
    (0, _react.act)(() => root.unmount());
  });
});
var _c;
$RefreshReg$(_c, "Probe");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfdml0ZXN0IiwicmVxdWlyZSIsIl9yZWFjdCIsIl9jbGllbnQiLCJfdXNlUmVwb3J0IiwiX3NlZWRzIiwiX3MyIiwiJFJlZnJlc2hTaWckIiwiZ2xvYmFsVGhpcyIsIklTX1JFQUNUX0FDVF9FTlZJUk9OTUVOVCIsImJ1aWxkUmVwb3J0U2Vzc2lvbiIsInZpIiwiZm4iLCJtb2NrIiwiaW1wb3J0T3JpZ2luYWwiLCJyZWFsIiwiYSIsIkZlZWRSdW50aW1lIiwibW91bnRzIiwic2Vzc2lvbiIsInRpdGxlIiwidGljayIsIm1vY2tSZXNvbHZlZFZhbHVlIiwiaGFuZGxlIiwibW91bnRIb29rIiwic2VlZCIsImNvbnRhaW5lciIsImRvY3VtZW50IiwiY3JlYXRlRWxlbWVudCIsImJvZHkiLCJhcHBlbmRDaGlsZCIsInJvb3QiLCJjcmVhdGVSb290IiwiYWN0IiwiX3MiLCJyZW5kZXIiLCJzdGF0ZSIsInVzZVJlcG9ydCIsImRlc2NyaWJlIiwiaXQiLCJNRVJJRElBTl9TRUVEIiwiZXhwZWN0IiwidG9IYXZlQmVlbkNhbGxlZFRpbWVzIiwicmVsb2FkIiwidG9CZVR5cGVPZiIsIkNBTERFUkFfU0VFRCIsIm5vdCIsInRvSGF2ZUJlZW5DYWxsZWQiLCJUQVNLX0RJUiIsInRhc2tNb3VudHMiLCJpZCIsInBhdGgiLCJ0eXBlIiwibW9kZSIsInRhc2tJbnB1dCIsInRhc2siLCJwYXJhbXMiLCJkaXIiLCJQcm9iZSIsInByb3BzIiwicyIsIm0iLCJ0IiwiX2MiLCJtb2NrQ2xlYXIiLCJjYWxscyIsInRvRXF1YWwiLCJ1bmRlZmluZWQiLCJ1bm1vdW50IiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsidXNlUmVwb3J0LnRlc3QudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIFRoZSByZXBvcnQgaG9vaydzIHJlbG9hZCBoYWxmIChET0NVTUVOVF9OQVZJR0FUT1JfU1BFQyDCpzQuNCwgUjMtNDQ3KTogdGhlIHNlc3Npb25cbi8vIHJlYWRzIHRoZSBkb2N1bWVudCBvbmNlLCBzbyBgcmVsb2FkKClgIG11c3QgcmVidWlsZCBpdCB0aHJvdWdoIHRoZSBzYW1lIG1vdW50XG4vLyByZXNvbHV0aW9uLiBUaGUgc2Vzc2lvbiBidWlsZGVyIGlzIG1vY2tlZCAoaXRzIHJlYWwgcGlwZWxpbmUgaGFzIGl0cyBvd24gc3VpdGUpO1xuLy8gd2hhdCB0aGlzIHBpbnMgaXMgdGhlIExJRkVDWUNMRTogb25lIGJ1aWxkIHBlciBtb3VudC9zZWVkIHN0YXRlLCBhbmQgb25lIE1PUkUgb25cbi8vIHJlbG9hZCDigJQgd2l0aCBub3RoaW5nIHJlbW91bnRpbmcuXG4vL1xuLy8gUjMtNzY4IGFsc28gZnJlZXplcyB0aGUgaG9vaydzIGZlZWQgc3VyZmFjZTogbm8gc2VlZCBzdGFydHMgYSBgRmVlZFJ1bnRpbWVgLiBUaGF0XG4vLyBpbnZhcmlhbnQgaXMgYXNzZXJ0ZWQgaGVyZSB0b28g4oCUIGEgcmVpbnRyb2R1Y2VkIGZlZWQgcGF0aCB3b3VsZCBjb25zdHJ1Y3QgdGhlIG1vZHVsZVxuLy8gYW5kIGZhaWwgdGhlIGd1YXJkcmFpbC5cbi8vIEB2aXRlc3QtZW52aXJvbm1lbnQgaGFwcHktZG9tXG5pbXBvcnQgeyBkZXNjcmliZSwgaXQsIGV4cGVjdCwgdmkgfSBmcm9tICd2aXRlc3QnO1xuaW1wb3J0IHsgYWN0LCBjcmVhdGVFbGVtZW50IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgY3JlYXRlUm9vdCwgdHlwZSBSb290IH0gZnJvbSAncmVhY3QtZG9tL2NsaWVudCc7XG5pbXBvcnQgeyB1c2VSZXBvcnQsIHR5cGUgUmVwb3J0U3RhdGUgfSBmcm9tICcuL3VzZVJlcG9ydC50cyc7XG5pbXBvcnQgeyBNRVJJRElBTl9TRUVELCBDQUxERVJBX1NFRUQsIHR5cGUgU2VlZERvY3VtZW50IH0gZnJvbSAnLi4vc2VlZC9zZWVkcy50cyc7XG5pbXBvcnQgdHlwZSB7IFJlcG9ydFNlc3Npb24gfSBmcm9tICcuLi9hcHAvcmVwb3J0U2Vzc2lvbi50cyc7XG5pbXBvcnQgdHlwZSB7IFNhbmRib3hNb3VudCB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrJztcbmltcG9ydCB0eXBlIHsgVGFza0lucHV0IH0gZnJvbSAnQGltbWVkaWF0ZWx5LXJ1bi9zZGsvdGFza3MnO1xuXG4oZ2xvYmFsVGhpcyBhcyB1bmtub3duIGFzIHsgSVNfUkVBQ1RfQUNUX0VOVklST05NRU5UOiBib29sZWFuIH0pLklTX1JFQUNUX0FDVF9FTlZJUk9OTUVOVCA9IHRydWU7XG5cbmNvbnN0IGJ1aWxkUmVwb3J0U2Vzc2lvbiA9IHZpLmZuKCk7XG52aS5tb2NrKCcuLi9hcHAvcmVwb3J0U2Vzc2lvbi50cycsIGFzeW5jIChpbXBvcnRPcmlnaW5hbCkgPT4ge1xuICBjb25zdCByZWFsID0gKGF3YWl0IGltcG9ydE9yaWdpbmFsPHR5cGVvZiBpbXBvcnQoJy4uL2FwcC9yZXBvcnRTZXNzaW9uLnRzJyk+KCkpIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICByZXR1cm4geyAuLi5yZWFsLCBidWlsZFJlcG9ydFNlc3Npb246ICguLi5hOiB1bmtub3duW10pID0+IGJ1aWxkUmVwb3J0U2Vzc2lvbiguLi5hKSB9O1xufSk7XG5cbi8vIFIzLTc2OCBndWFyZHJhaWw6IHRoZSBob29rIG11c3QgbmV2ZXIgY29uc3RydWN0IGEgRmVlZFJ1bnRpbWUgKG5vIGJ1bmRsZWQgc2VlZCByZWFkc1xuLy8gYSBsaXZlIGZlZWQpLiBJZiB0aGlzIGlzIGV2ZXIgaW5zdGFudGlhdGVkLCBhIGZlZWQgcGF0aCB3YXMgcmVpbnRyb2R1Y2VkLlxuY29uc3QgRmVlZFJ1bnRpbWUgPSB2aS5mbigpO1xudmkubW9jaygnLi4vZmVlZC9pbmRleC50cycsICgpID0+ICh7IEZlZWRSdW50aW1lIH0pKTtcblxuY29uc3QgbW91bnRzOiByZWFkb25seSBpbXBvcnQoJ0BpbW1lZGlhdGVseS1ydW4vc2RrJykuU2FuZGJveE1vdW50W10gPSBbXTtcbmNvbnN0IHNlc3Npb24gPSB7IHRpdGxlOiAndCcsIHRpY2s6IDAgfSBhcyB1bmtub3duIGFzIFJlcG9ydFNlc3Npb247XG5idWlsZFJlcG9ydFNlc3Npb24ubW9ja1Jlc29sdmVkVmFsdWUoc2Vzc2lvbik7XG5cbmludGVyZmFjZSBIYW5kbGUge1xuICBzdGF0ZTogUmVwb3J0U3RhdGUgJiB7IHJlbG9hZDogKCkgPT4gdm9pZCB9O1xufVxuXG5sZXQgaGFuZGxlOiBIYW5kbGUgfCBudWxsID0gbnVsbDtcblxuZnVuY3Rpb24gbW91bnRIb29rKHNlZWQ6IFNlZWREb2N1bWVudCk6IHZvaWQge1xuICBjb25zdCBjb250YWluZXIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChjb250YWluZXIpO1xuICBjb25zdCByb290OiBSb290ID0gY3JlYXRlUm9vdChjb250YWluZXIpO1xuICBhY3QoKCkgPT4ge1xuICAgIHJvb3QucmVuZGVyKFxuICAgICAgY3JlYXRlRWxlbWVudCgoKSA9PiB7XG4gICAgICAgIGhhbmRsZSA9IHsgc3RhdGU6IHVzZVJlcG9ydChzZWVkLCBtb3VudHMpIH07XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgICAgfSksXG4gICAgKTtcbiAgfSk7XG59XG5cbmRlc2NyaWJlKCd1c2VSZXBvcnQg4oCUIHJlbG9hZCAowqc0LjQpJywgKCkgPT4ge1xuICBpdCgnYnVpbGRzIG9uY2UgZm9yIGEgc3RhYmxlIG1vdW50IHNldCwgYW5kIG9uY2UgbW9yZSBvbiByZWxvYWQoKScsIGFzeW5jICgpID0+IHtcbiAgICBtb3VudEhvb2soTUVSSURJQU5fU0VFRCk7XG4gICAgLy8gZmx1c2ggdGhlIGFzeW5jIGJ1aWxkXG4gICAgYXdhaXQgYWN0KGFzeW5jICgpID0+IHt9KTtcbiAgICBleHBlY3QoYnVpbGRSZXBvcnRTZXNzaW9uKS50b0hhdmVCZWVuQ2FsbGVkVGltZXMoMSk7XG4gICAgYWN0KCgpID0+IGhhbmRsZSEuc3RhdGUucmVsb2FkKCkpO1xuICAgIGF3YWl0IGFjdChhc3luYyAoKSA9PiB7fSk7XG4gICAgZXhwZWN0KGJ1aWxkUmVwb3J0U2Vzc2lvbikudG9IYXZlQmVlbkNhbGxlZFRpbWVzKDIpO1xuICAgIGV4cGVjdChoYW5kbGUhLnN0YXRlLnJlbG9hZCkudG9CZVR5cGVPZignZnVuY3Rpb24nKTtcbiAgfSk7XG5cbiAgaXQoJ25ldmVyIGNvbnN0cnVjdHMgYSBGZWVkUnVudGltZSBmb3IgYW55IGJ1bmRsZWQgc2VlZCAoUjMtNzY4KScsIGFzeW5jICgpID0+IHtcbiAgICBtb3VudEhvb2soTUVSSURJQU5fU0VFRCk7XG4gICAgYXdhaXQgYWN0KGFzeW5jICgpID0+IHt9KTtcbiAgICBtb3VudEhvb2soQ0FMREVSQV9TRUVEKTtcbiAgICBhd2FpdCBhY3QoYXN5bmMgKCkgPT4ge30pO1xuICAgIGV4cGVjdChGZWVkUnVudGltZSkubm90LnRvSGF2ZUJlZW5DYWxsZWQoKTtcbiAgfSk7XG59KTtcblxuLy8gVGhlIFIzLTc1NCBoYW5kb2ZmOiB0aGUgdGFzayBpbnB1dCBtdXN0IHJpZGUgdGhyb3VnaCB0aGUgaG9vayBpbnRvIHRoZSBzZXNzaW9uXG4vLyBidWlsZGVyLCBhbmQgaXRzIGFycml2YWwgKHRoZSBob3N0J3MgcmUtc2VuZCBsYWRkZXIgbGFuZHMgaXQgQUZURVIgdGhlIGRlbGVnYXRpb25cbi8vIG1vdW50KSBtdXN0IHRyaWdnZXIgdGhlIHJlYnVpbGQuIEJvdGggY2FzZXMgcmVuZGVyIGEgU1RBQkxFIGNvbXBvbmVudCBpZGVudGl0eSBzb1xuLy8gYSByZS1yZW5kZXIgaXMgYSByZS1yZW5kZXIsIG5vdCBhIHJlbW91bnQg4oCUIHRoZSBzZWNvbmQgYnVpbGQgaGFzIHRvIGNvbWUgZnJvbSB0aGVcbi8vIGRlcHMvZGlzcGF0Y2gta2V5IGZsaXAsIG5vdCBmcm9tIGEgZnJlc2ggaG9vay5cbi8vXG4vLyAoUmViYXNlIG5vdGUsIDIwMjYtMDktMjk6IHRoZSBQUidzIHRoaXJkIGNhc2Ug4oCUIFwidGhlIHJlc29sdmVkIHRhc2sgc2hhcGUga2VlcHMgdGhlXG4vLyBkZW1vIGZlZWQgb2ZmIHRoZSBtb3VudGVkIHdvcmtib29rXCIg4oCUIGlzIGRyb3BwZWQgaGVyZSBhcyBzdWJzdW1lZDogUjMtNzY4IHJlbW92ZWRcbi8vIHRoZSBmZWVkIHJ1bnRpbWVzIHdob2xlc2FsZSwgYW5kIHRoZSBndWFyZHJhaWwgYWJvdmUgYXNzZXJ0cyBubyBGZWVkUnVudGltZSBpcyBFVkVSXG4vLyBjb25zdHJ1Y3RlZC4gUmV2aWV3IHJvdW5kIDMgdGhlbiBmb3VuZCB0aGUgZGlzcGF0Y2hLZXkgbWVtbyBpdHNlbGYgcmVkdW5kYW50IOKAlCBpdHNcbi8vIG9ubHkgcG9zdC1SMy03NjggY29uc3VtZXIgd2FzIHRoZSBlZmZlY3QgZGVwcyBhcnJheSB0aGF0IGFscmVhZHkgaG9sZHMgdGhlIG1lbW8nc1xuLy8gaW5wdXRzIOKAlCBhbmQgaXQgd2FzIGRlbGV0ZWQgKG11dGF0aW9uLXRlc3RlZCBiZWhhdmlvdXItaWRlbnRpY2FsKSwgc28gdGhlIHByb3BlcnR5XG4vLyB0aGUgdGhpcmQgY2FzZSBwaW5uZWQgbm8gbG9uZ2VyIGV4aXN0cyB0byB0ZXN0LiBUaGUgaGFuZG9mZiB0ZXN0cyBiZWxvdyBwaW4gd2hhdFxuLy8gcmVtYWluczogdGhlIGlucHV0IHJpZGVzIGludG8gdGhlIHNlc3Npb24gYnVpbGRlciwgYW5kIGl0cyBsYXRlIGFycml2YWwgcmVidWlsZHMuKVxuY29uc3QgVEFTS19ESVIgPSAnL3Rhc2svdGFzay0xL2Rpcic7XG5jb25zdCB0YXNrTW91bnRzID0gW1xuICB7IGlkOiBUQVNLX0RJUiwgcGF0aDogVEFTS19ESVIsIHR5cGU6ICd0YXNrLWRlbGVnYXRpb24nLCBtb2RlOiAncm8nIH0sXG5dIGFzIHVua25vd24gYXMgU2FuZGJveE1vdW50W107XG5jb25zdCB0YXNrSW5wdXQgPSB7IHRhc2s6ICdvcGVuLXdvcmtib29rJywgcGFyYW1zOiB7IGRpcjogVEFTS19ESVIgfSB9IGFzIFRhc2tJbnB1dDtcblxuZnVuY3Rpb24gUHJvYmUocHJvcHM6IHsgczogU2VlZERvY3VtZW50OyBtOiByZWFkb25seSBTYW5kYm94TW91bnRbXTsgdDogVGFza0lucHV0IHwgbnVsbCB9KTogbnVsbCB7XG4gIHVzZVJlcG9ydChwcm9wcy5zLCBwcm9wcy5tLCBwcm9wcy50KTtcbiAgcmV0dXJuIG51bGw7XG59XG5cbmRlc2NyaWJlKCd1c2VSZXBvcnQg4oCUIHRoZSB0YXNrLWlucHV0IGhhbmRvZmYgKFIzLTc1NCknLCAoKSA9PiB7XG4gIGl0KCd0aGUgaW5wdXQgcmlkZXMgaW50byBidWlsZFJlcG9ydFNlc3Npb24gYXMgdGhlIDR0aCBhcmd1bWVudCDigJQgZHJvcHBpbmcgaXQgdGhlcmUgZmFpbHMgaGVyZScsIGFzeW5jICgpID0+IHtcbiAgICBidWlsZFJlcG9ydFNlc3Npb24ubW9ja0NsZWFyKCk7XG4gICAgY29uc3QgY29udGFpbmVyID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChjb250YWluZXIpO1xuICAgIGNvbnN0IHJvb3Q6IFJvb3QgPSBjcmVhdGVSb290KGNvbnRhaW5lcik7XG4gICAgYWN0KCgpID0+IHtcbiAgICAgIHJvb3QucmVuZGVyKGNyZWF0ZUVsZW1lbnQoUHJvYmUsIHsgczogTUVSSURJQU5fU0VFRCwgbTogdGFza01vdW50cywgdDogdGFza0lucHV0IH0pKTtcbiAgICB9KTtcbiAgICBhd2FpdCBhY3QoYXN5bmMgKCkgPT4ge30pO1xuICAgIGV4cGVjdChidWlsZFJlcG9ydFNlc3Npb24pLnRvSGF2ZUJlZW5DYWxsZWRUaW1lcygxKTtcbiAgICBleHBlY3QoYnVpbGRSZXBvcnRTZXNzaW9uLm1vY2suY2FsbHNbMF0pLnRvRXF1YWwoW3VuZGVmaW5lZCwgTUVSSURJQU5fU0VFRCwgdGFza01vdW50cywgdGFza0lucHV0XSk7XG4gICAgYWN0KCgpID0+IHJvb3QudW5tb3VudCgpKTtcbiAgfSk7XG5cbiAgaXQoJ3RoZSBpbnB1dCBhcnJpdmluZyBBRlRFUiB0aGUgZmlyc3QgYnVpbGQgcmVidWlsZHMgb25jZSBtb3JlLCBjYXJyeWluZyBpdCcsIGFzeW5jICgpID0+IHtcbiAgICBidWlsZFJlcG9ydFNlc3Npb24ubW9ja0NsZWFyKCk7XG4gICAgY29uc3QgY29udGFpbmVyID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChjb250YWluZXIpO1xuICAgIGNvbnN0IHJvb3Q6IFJvb3QgPSBjcmVhdGVSb290KGNvbnRhaW5lcik7XG4gICAgYWN0KCgpID0+IHtcbiAgICAgIHJvb3QucmVuZGVyKGNyZWF0ZUVsZW1lbnQoUHJvYmUsIHsgczogTUVSSURJQU5fU0VFRCwgbTogdGFza01vdW50cywgdDogbnVsbCB9KSk7XG4gICAgfSk7XG4gICAgYXdhaXQgYWN0KGFzeW5jICgpID0+IHt9KTtcbiAgICBleHBlY3QoYnVpbGRSZXBvcnRTZXNzaW9uKS50b0hhdmVCZWVuQ2FsbGVkVGltZXMoMSk7XG4gICAgYWN0KCgpID0+IHtcbiAgICAgIHJvb3QucmVuZGVyKGNyZWF0ZUVsZW1lbnQoUHJvYmUsIHsgczogTUVSSURJQU5fU0VFRCwgbTogdGFza01vdW50cywgdDogdGFza0lucHV0IH0pKTtcbiAgICB9KTtcbiAgICBhd2FpdCBhY3QoYXN5bmMgKCkgPT4ge30pO1xuICAgIGV4cGVjdChidWlsZFJlcG9ydFNlc3Npb24pLnRvSGF2ZUJlZW5DYWxsZWRUaW1lcygyKTtcbiAgICBleHBlY3QoYnVpbGRSZXBvcnRTZXNzaW9uLm1vY2suY2FsbHNbMV0pLnRvRXF1YWwoW3VuZGVmaW5lZCwgTUVSSURJQU5fU0VFRCwgdGFza01vdW50cywgdGFza0lucHV0XSk7XG4gICAgYWN0KCgpID0+IHJvb3QudW5tb3VudCgpKTtcbiAgfSk7XG59KTtcbiJdLCJtYXBwaW5ncyI6Ijs7QUFVQSxJQUFBQSxPQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxNQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxPQUFBLEdBQUFGLE9BQUE7QUFDQSxJQUFBRyxVQUFBLEdBQUFILE9BQUE7QUFDQSxJQUFBSSxNQUFBLEdBQUFKLE9BQUE7QUFBa0YsSUFBQUssR0FBQSxHQUFBQyxZQUFBLElBZGxGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBVUNDLFVBQVUsQ0FBc0RDLHdCQUF3QixHQUFHLElBQUk7QUFFaEcsTUFBTUMsa0JBQWtCLEdBQUdDLFVBQUUsQ0FBQ0MsRUFBRSxDQUFDLENBQUM7QUFDbENELFVBQUUsQ0FBQ0UsSUFBSSxDQUFDLHlCQUF5QixFQUFFLE1BQU9DLGNBQWMsSUFBSztFQUMzRCxNQUFNQyxJQUFJLEdBQUksTUFBTUQsY0FBYyxDQUEyQyxDQUE2QjtFQUMxRyxPQUFPO0lBQUUsR0FBR0MsSUFBSTtJQUFFTCxrQkFBa0IsRUFBRUEsQ0FBQyxHQUFHTSxDQUFZLEtBQUtOLGtCQUFrQixDQUFDLEdBQUdNLENBQUM7RUFBRSxDQUFDO0FBQ3ZGLENBQUMsQ0FBQzs7QUFFRjtBQUNBO0FBQ0EsTUFBTUMsV0FBVyxHQUFHTixVQUFFLENBQUNDLEVBQUUsQ0FBQyxDQUFDO0FBQzNCRCxVQUFFLENBQUNFLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxPQUFPO0VBQUVJO0FBQVksQ0FBQyxDQUFDLENBQUM7QUFFcEQsTUFBTUMsTUFBOEQsR0FBRyxFQUFFO0FBQ3pFLE1BQU1DLE9BQU8sR0FBRztFQUFFQyxLQUFLLEVBQUUsR0FBRztFQUFFQyxJQUFJLEVBQUU7QUFBRSxDQUE2QjtBQUNuRVgsa0JBQWtCLENBQUNZLGlCQUFpQixDQUFDSCxPQUFPLENBQUM7QUFNN0MsSUFBSUksTUFBcUIsR0FBRyxJQUFJO0FBRWhDLFNBQVNDLFNBQVNBLENBQUNDLElBQWtCLEVBQVE7RUFDM0MsTUFBTUMsU0FBUyxHQUFHQyxRQUFRLENBQUNDLGFBQWEsQ0FBQyxLQUFLLENBQUM7RUFDL0NELFFBQVEsQ0FBQ0UsSUFBSSxDQUFDQyxXQUFXLENBQUNKLFNBQVMsQ0FBQztFQUNwQyxNQUFNSyxJQUFVLEdBQUcsSUFBQUMsa0JBQVUsRUFBQ04sU0FBUyxDQUFDO0VBQ3hDLElBQUFPLFVBQUcsRUFBQyxNQUFNO0lBQUEsSUFBQUMsRUFBQSxHQUFBM0IsWUFBQTtJQUNSMkIsRUFBQSxDQUFBSCxJQUFJLENBQUNJLE1BQU0sY0FBQUQsRUFBQSxjQUNULElBQUFOLG9CQUFhLEVBQUFNLEVBQUEsQ0FBQyxNQUFNO01BQUFBLEVBQUE7TUFDbEJYLE1BQU0sR0FBRztRQUFFYSxLQUFLLEVBQUUsSUFBQUMsb0JBQVMsRUFBQ1osSUFBSSxFQUFFUCxNQUFNO01BQUUsQ0FBQztNQUMzQyxPQUFPLElBQUk7SUFDYixDQUFDO01BQUEsUUFGbUJtQixvQkFBUztJQUFBLEVBRTVCLENBQUM7TUFBQSxRQUZrQkEsU0FBUztJQUFBLEVBRy9CLENBQUM7TUFBQSxRQUhxQkEsU0FBUztJQUFBO0VBSWpDLENBQUMsQ0FBQztBQUNKO0FBRUEsSUFBQUMsZ0JBQVEsRUFBQywyQkFBMkIsRUFBRSxNQUFNO0VBQzFDLElBQUFDLFVBQUUsRUFBQywrREFBK0QsRUFBRSxZQUFZO0lBQzlFZixTQUFTLENBQUNnQixvQkFBYSxDQUFDO0lBQ3hCO0lBQ0EsTUFBTSxJQUFBUCxVQUFHLEVBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztJQUN6QixJQUFBUSxjQUFNLEVBQUMvQixrQkFBa0IsQ0FBQyxDQUFDZ0MscUJBQXFCLENBQUMsQ0FBQyxDQUFDO0lBQ25ELElBQUFULFVBQUcsRUFBQyxNQUFNVixNQUFNLENBQUVhLEtBQUssQ0FBQ08sTUFBTSxDQUFDLENBQUMsQ0FBQztJQUNqQyxNQUFNLElBQUFWLFVBQUcsRUFBQyxZQUFZLENBQUMsQ0FBQyxDQUFDO0lBQ3pCLElBQUFRLGNBQU0sRUFBQy9CLGtCQUFrQixDQUFDLENBQUNnQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUM7SUFDbkQsSUFBQUQsY0FBTSxFQUFDbEIsTUFBTSxDQUFFYSxLQUFLLENBQUNPLE1BQU0sQ0FBQyxDQUFDQyxVQUFVLENBQUMsVUFBVSxDQUFDO0VBQ3JELENBQUMsQ0FBQztFQUVGLElBQUFMLFVBQUUsRUFBQyw4REFBOEQsRUFBRSxZQUFZO0lBQzdFZixTQUFTLENBQUNnQixvQkFBYSxDQUFDO0lBQ3hCLE1BQU0sSUFBQVAsVUFBRyxFQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7SUFDekJULFNBQVMsQ0FBQ3FCLG1CQUFZLENBQUM7SUFDdkIsTUFBTSxJQUFBWixVQUFHLEVBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztJQUN6QixJQUFBUSxjQUFNLEVBQUN4QixXQUFXLENBQUMsQ0FBQzZCLEdBQUcsQ0FBQ0MsZ0JBQWdCLENBQUMsQ0FBQztFQUM1QyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7O0FBRUY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU1DLFFBQVEsR0FBRyxrQkFBa0I7QUFDbkMsTUFBTUMsVUFBVSxHQUFHLENBQ2pCO0VBQUVDLEVBQUUsRUFBRUYsUUFBUTtFQUFFRyxJQUFJLEVBQUVILFFBQVE7RUFBRUksSUFBSSxFQUFFLGlCQUFpQjtFQUFFQyxJQUFJLEVBQUU7QUFBSyxDQUFDLENBQ3pDO0FBQzlCLE1BQU1DLFNBQVMsR0FBRztFQUFFQyxJQUFJLEVBQUUsZUFBZTtFQUFFQyxNQUFNLEVBQUU7SUFBRUMsR0FBRyxFQUFFVDtFQUFTO0FBQUUsQ0FBYztBQUVuRixTQUFTVSxLQUFLQSxDQUFDQyxLQUEyRSxFQUFRO0VBQUFyRCxHQUFBO0VBQ2hHLElBQUErQixvQkFBUyxFQUFDc0IsS0FBSyxDQUFDQyxDQUFDLEVBQUVELEtBQUssQ0FBQ0UsQ0FBQyxFQUFFRixLQUFLLENBQUNHLENBQUMsQ0FBQztFQUNwQyxPQUFPLElBQUk7QUFDYjtBQUFDeEQsR0FBQSxDQUhRb0QsS0FBSztFQUFBLFFBQ1pyQixvQkFBUztBQUFBO0FBQUEwQixFQUFBLEdBREZMLEtBQUs7QUFLZCxJQUFBcEIsZ0JBQVEsRUFBQyw2Q0FBNkMsRUFBRSxNQUFNO0VBQzVELElBQUFDLFVBQUUsRUFBQyw0RkFBNEYsRUFBRSxZQUFZO0lBQzNHN0Isa0JBQWtCLENBQUNzRCxTQUFTLENBQUMsQ0FBQztJQUM5QixNQUFNdEMsU0FBUyxHQUFHQyxRQUFRLENBQUNDLGFBQWEsQ0FBQyxLQUFLLENBQUM7SUFDL0NELFFBQVEsQ0FBQ0UsSUFBSSxDQUFDQyxXQUFXLENBQUNKLFNBQVMsQ0FBQztJQUNwQyxNQUFNSyxJQUFVLEdBQUcsSUFBQUMsa0JBQVUsRUFBQ04sU0FBUyxDQUFDO0lBQ3hDLElBQUFPLFVBQUcsRUFBQyxNQUFNO01BQ1JGLElBQUksQ0FBQ0ksTUFBTSxjQUFDLElBQUFQLG9CQUFhLEVBQUM4QixLQUFLLEVBQUU7UUFBRUUsQ0FBQyxFQUFFcEIsb0JBQWE7UUFBRXFCLENBQUMsRUFBRVosVUFBVTtRQUFFYSxDQUFDLEVBQUVSO01BQVUsQ0FBQyxDQUFDLENBQUM7SUFDdEYsQ0FBQyxDQUFDO0lBQ0YsTUFBTSxJQUFBckIsVUFBRyxFQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7SUFDekIsSUFBQVEsY0FBTSxFQUFDL0Isa0JBQWtCLENBQUMsQ0FBQ2dDLHFCQUFxQixDQUFDLENBQUMsQ0FBQztJQUNuRCxJQUFBRCxjQUFNLEVBQUMvQixrQkFBa0IsQ0FBQ0csSUFBSSxDQUFDb0QsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUNDLE9BQU8sQ0FBQyxDQUFDQyxTQUFTLEVBQUUzQixvQkFBYSxFQUFFUyxVQUFVLEVBQUVLLFNBQVMsQ0FBQyxDQUFDO0lBQ25HLElBQUFyQixVQUFHLEVBQUMsTUFBTUYsSUFBSSxDQUFDcUMsT0FBTyxDQUFDLENBQUMsQ0FBQztFQUMzQixDQUFDLENBQUM7RUFFRixJQUFBN0IsVUFBRSxFQUFDLDBFQUEwRSxFQUFFLFlBQVk7SUFDekY3QixrQkFBa0IsQ0FBQ3NELFNBQVMsQ0FBQyxDQUFDO0lBQzlCLE1BQU10QyxTQUFTLEdBQUdDLFFBQVEsQ0FBQ0MsYUFBYSxDQUFDLEtBQUssQ0FBQztJQUMvQ0QsUUFBUSxDQUFDRSxJQUFJLENBQUNDLFdBQVcsQ0FBQ0osU0FBUyxDQUFDO0lBQ3BDLE1BQU1LLElBQVUsR0FBRyxJQUFBQyxrQkFBVSxFQUFDTixTQUFTLENBQUM7SUFDeEMsSUFBQU8sVUFBRyxFQUFDLE1BQU07TUFDUkYsSUFBSSxDQUFDSSxNQUFNLGNBQUMsSUFBQVAsb0JBQWEsRUFBQzhCLEtBQUssRUFBRTtRQUFFRSxDQUFDLEVBQUVwQixvQkFBYTtRQUFFcUIsQ0FBQyxFQUFFWixVQUFVO1FBQUVhLENBQUMsRUFBRTtNQUFLLENBQUMsQ0FBQyxDQUFDO0lBQ2pGLENBQUMsQ0FBQztJQUNGLE1BQU0sSUFBQTdCLFVBQUcsRUFBQyxZQUFZLENBQUMsQ0FBQyxDQUFDO0lBQ3pCLElBQUFRLGNBQU0sRUFBQy9CLGtCQUFrQixDQUFDLENBQUNnQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUM7SUFDbkQsSUFBQVQsVUFBRyxFQUFDLE1BQU07TUFDUkYsSUFBSSxDQUFDSSxNQUFNLGNBQUMsSUFBQVAsb0JBQWEsRUFBQzhCLEtBQUssRUFBRTtRQUFFRSxDQUFDLEVBQUVwQixvQkFBYTtRQUFFcUIsQ0FBQyxFQUFFWixVQUFVO1FBQUVhLENBQUMsRUFBRVI7TUFBVSxDQUFDLENBQUMsQ0FBQztJQUN0RixDQUFDLENBQUM7SUFDRixNQUFNLElBQUFyQixVQUFHLEVBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztJQUN6QixJQUFBUSxjQUFNLEVBQUMvQixrQkFBa0IsQ0FBQyxDQUFDZ0MscUJBQXFCLENBQUMsQ0FBQyxDQUFDO0lBQ25ELElBQUFELGNBQU0sRUFBQy9CLGtCQUFrQixDQUFDRyxJQUFJLENBQUNvRCxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ0MsT0FBTyxDQUFDLENBQUNDLFNBQVMsRUFBRTNCLG9CQUFhLEVBQUVTLFVBQVUsRUFBRUssU0FBUyxDQUFDLENBQUM7SUFDbkcsSUFBQXJCLFVBQUcsRUFBQyxNQUFNRixJQUFJLENBQUNxQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0VBQzNCLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQztBQUFDLElBQUFMLEVBQUE7QUFBQU0sWUFBQSxDQUFBTixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}