var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.filter.js");
require("core-js/modules/esnext.iterator.find.js");
require("core-js/modules/esnext.iterator.map.js");
require("core-js/modules/esnext.iterator.some.js");
require("./index.css");
require("./app/report-page.css");
var _react = require("react");
var _useReport = require("./hooks/useReport.ts");
var _seeds = require("./seed/seeds.ts");
var _useAppPath = require("./hooks/useAppPath.ts");
var _DocumentNav = _interopRequireDefault(require("./app/DocumentNav.tsx"));
var _DocumentChangedNotice = _interopRequireDefault(require("./app/DocumentChangedNotice.tsx"));
var _useMounts = require("./hooks/useMounts.ts");
var _useTaskInputLazy = require("./hooks/useTaskInputLazy.ts");
var _dispatch = require("./app/dispatch.ts");
var _useEditFile = require("./hooks/useEditFile.ts");
var _index2 = require("./report/index.ts");
var _WorkbookPanel = _interopRequireDefault(require("./app/WorkbookPanel.tsx"));
var _ValueInspector = _interopRequireDefault(require("./app/ValueInspector.tsx"));
var _WhatIfPanel = _interopRequireDefault(require("./app/WhatIfPanel.tsx"));
var _AuthorsView = _interopRequireDefault(require("./app/AuthorsView.tsx"));
var _useOverlayDialog = require("./app/useOverlayDialog.ts");
var _useVerdicts = require("./hooks/useVerdicts.ts");
var _jsxRuntime = require("react/jsx-runtime");
var _s = $RefreshSig$(); // Root component — the default export of THIS file is what renders. immediately.run reaches it
// through `src/platform.tsx` (`package.json` → `main`), which exists only to call
// `boot({ children: <App /> })` so the app owns a path space (R3-553); `src/main.tsx` is the
// `vite dev` entry and is ignored at runtime (ARCHITECTURE_PLAN §2.1, §7). Reckoner opens a document and renders it as a static report with zero prompts:
// the hook loads the bundled demo document, runs the SES-confined engine, and hands the render
// surface a Bindings port over the results. Global CSS is imported here (not main.tsx), which
// immediately.run's runtime ignores.
//
// The inspected cell is app-level state shared by the two doors into the value inspector:
// the workbook panel's cards (author surface) and V3's on-pixel affordance on bound report
// elements (hover-reveal / long-press) — both open the same docked inspector.
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
function App() {
  _s();
  // The app-space PATH picks the bundled document (`/caldera`; `/` is the Meridian
  // monthly review), falling back to the legacy `?doc=` query — which the host forwards only
  // at boot, so it cannot survive navigation and is compatibility only (R3-553). The picked
  // seed is a module constant, so the reference is stable across renders.
  const appPath = (0, _useAppPath.useAppPath)();
  const hostLoc = (0, _useAppPath.useHostLocation)();
  const mounts = (0, _useMounts.useMounts)();
  // The task-invocation shape (R3-754): when this frame is an `open-workbook`
  // callee, the host's rewritten `dir` param + the minted `task-delegation` mount
  // are the dispatch — the input read lazily (the SDK task surface stays behind
  // dynamic imports, platformGuards.test.ts).
  const taskInput = (0, _useTaskInputLazy.useTaskInputLazy)();
  const seed = (0, _seeds.seedForBoot)(appPath, window.location);
  const report = (0, _useReport.useReport)(seed, mounts, taskInput);
  // Part B (R3-447): the dispatched workbook's edit door. The mount the resolution
  // carries is the whole contract — writability by the positive `rw` check, and the
  // `capFile` address from the descriptor's id — the universal `scheme:locator` form
  // on the repo-load shape, the chroot path on the task-invocation shape (the two
  // forms probed live; DOCUMENT_NAVIGATOR_STATUS.md). Absent (never disabled) in the
  // seed flow and on any non-`rw` mount.
  const dispatch = (0, _dispatch.resolveWorkbookMount)(mounts, taskInput);
  const editFile = (0, _useEditFile.useEditFile)(dispatch.ok ? dispatch.mount : null);
  const [reviewOpen, setReviewOpen] = (0, _react.useState)(false);
  const [inspected, setInspected] = (0, _react.useState)(null);
  // What-if buffer text is SESSION-SCOPED app state (WHATIF_SHADOW_EVALUATION_SPEC §1.4):
  // closing a panel must never destroy typed source, so the per-cell variants and the
  // scratch pad's buffer live here, above the panels' mount/unmount lifecycle.
  const [variants, setVariants] = (0, _react.useState)({});
  const [scratchText, setScratchText] = (0, _react.useState)('');
  // The what-if section is collapsed by default (spec §1.1, amended 2026-08-28): the
  // formula row's "what if →" affordance opens it, and it stays open on its own whenever
  // the cell's variant text differs from the document formula — typed source never hides.
  // Keyed by cell id rather than reset in an effect: navigating to another cell makes
  // the door closed again by derivation (react-hooks/set-state-in-effect stays happy).
  const [whatIfOpenFor, setWhatIfOpenFor] = (0, _react.useState)(null);
  // The author's view (AUTHORS_VIEW_SPEC §1.2): opened from the workbook panel (its
  // door), rendered in place of the report with an explicit way back. Component state,
  // not a route.
  const [authorsOpen, setAuthorsOpen] = (0, _react.useState)(false);
  const title = report.status === 'ready' ? report.session.title : undefined;
  (0, _react.useEffect)(() => {
    if (title !== undefined) document.title = title;
  }, [title]);
  const inspectedCell = report.status === 'ready' && inspected !== null ? report.session.engine.cells().find(c => c.id === inspected) ?? null : null;

  // V3's inspection port: bound elements offer hover/long-press inspection of the CELL they
  // display (externals — params/fixtures — have no inspector card, so no affordance there).
  const inspection = (0, _react.useMemo)(() => report.status === 'ready' ? {
    onInspect: setInspected,
    canInspect: source => report.session.engine.cells().some(c => c.id === source)
  } : null, [report]);
  const verdicts = (0, _useVerdicts.useVerdicts)(report.status === 'ready' ? report.session.engine : null, report.status === 'ready' ? report.tick : 0);

  // The inspector dock's dialog contract (R3-610) — focus in on open, Tab wrap, keyed
  // close, focus back to the card or report affordance that opened it — lives in one
  // hook; `enabled` flips with the dock's own conditional mount, so the effect and the
  // element appear together.
  const inspectorRef = (0, _useOverlayDialog.useOverlayDialog)(() => setInspected(null), {
    enabled: inspectedCell !== null
  });
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)("main", {
    className: "rk-page",
    children: [report.status === 'loading' && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
      className: "rk-page-note",
      children: "Loading report\u2026"
    }), report.status === 'error' && /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
      className: "rk-page-note rk-page-error",
      children: ["Could not load the report: ", report.message]
    }), report.status === 'ready' && /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)("header", {
        className: "rk-page-head",
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_DocumentNav.default, {
          loc: hostLoc,
          current: seed
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("h1", {
          className: "grad-text",
          children: report.session.title
        }), /*#__PURE__*/(0, _jsxRuntime.jsx)("button", {
          type: "button",
          className: "rk-review-toggle",
          onClick: () => setReviewOpen(v => !v),
          children: reviewOpen ? 'Close workbook' : 'Workbook'
        })]
      }), editFile.edited && /*#__PURE__*/(0, _jsxRuntime.jsx)(_DocumentChangedNotice.default, {
        onReload: () => {
          report.reload();
          editFile.clearStale();
        }
      }), editFile.notice !== null && /*#__PURE__*/(0, _jsxRuntime.jsx)("div", {
        className: "rk-stale rk-stale--note",
        role: "status",
        children: editFile.notice
      }), authorsOpen ? /*#__PURE__*/(0, _jsxRuntime.jsx)(_AuthorsView.default, {
        session: report.session,
        bindings: report.bindings,
        verdicts: verdicts.results,
        onClose: () => setAuthorsOpen(false)
      }) : /*#__PURE__*/(0, _jsxRuntime.jsx)(_index2.ReportView, {
        nodes: report.session.nodes,
        bindings: report.bindings,
        inspection: inspection ?? undefined
      }), reviewOpen && /*#__PURE__*/(0, _jsxRuntime.jsx)(_WorkbookPanel.default, {
        session: report.session,
        verdicts: verdicts,
        onInspect: setInspected,
        onClose: () => setReviewOpen(false),
        onOpenAuthors: () => {
          setReviewOpen(false);
          setAuthorsOpen(true);
        },
        scratchText: scratchText,
        onScratchChange: setScratchText
      }), inspectedCell !== null && /*#__PURE__*/(0, _jsxRuntime.jsxs)("div", {
        className: "rk-inspector-dock",
        role: "dialog",
        "aria-modal": "true",
        "aria-label": "Value inspector",
        ref: inspectorRef,
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_ValueInspector.default, {
          cell: inspectedCell,
          cells: report.session.engine.cells(),
          tests: report.session.engine.tests().filter(t => t.subject === inspectedCell.id),
          verdicts: verdicts.results,
          result: report.session.engine.result(inspectedCell.id),
          onNavigate: setInspected,
          onClose: () => setInspected(null),
          onWhatIf: () => setWhatIfOpenFor(inspectedCell.id),
          worksheetPaths: Object.fromEntries(report.session.loaded.worksheets.map(w => [w.name, w.path])),
          canEditPath: editFile.canEditPath,
          onEdit: editFile.onEdit
        }), (whatIfOpenFor === inspectedCell.id || variants[inspectedCell.id] !== undefined && variants[inspectedCell.id] !== inspectedCell.formulaSource) && /*#__PURE__*/(0, _jsxRuntime.jsx)(_WhatIfPanel.default, {
          session: report.session,
          cell: inspectedCell,
          baseVerdicts: verdicts.results,
          text: variants[inspectedCell.id] ?? inspectedCell.formulaSource,
          onTextChange: (cellId, text) => setVariants(v => ({
            ...v,
            [cellId]: text
          }))
        })]
      })]
    })]
  });
}
_s(App, "/PQyd7JD314qvn3Iaf3gPe444NQ=", false, function () {
  return [_useAppPath.useAppPath, _useAppPath.useHostLocation, _useMounts.useMounts, _useTaskInputLazy.useTaskInputLazy, _useReport.useReport, _useEditFile.useEditFile, _useVerdicts.useVerdicts, _useOverlayDialog.useOverlayDialog];
});
_c = App;
var _default = exports.default = App;
var _c;
$RefreshReg$(_c, "App");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJyZXF1aXJlIiwiX3JlYWN0IiwiX3VzZVJlcG9ydCIsIl9zZWVkcyIsIl91c2VBcHBQYXRoIiwiX0RvY3VtZW50TmF2IiwiX2ludGVyb3BSZXF1aXJlRGVmYXVsdCIsIl9Eb2N1bWVudENoYW5nZWROb3RpY2UiLCJfdXNlTW91bnRzIiwiX3VzZVRhc2tJbnB1dExhenkiLCJfZGlzcGF0Y2giLCJfdXNlRWRpdEZpbGUiLCJfaW5kZXgyIiwiX1dvcmtib29rUGFuZWwiLCJfVmFsdWVJbnNwZWN0b3IiLCJfV2hhdElmUGFuZWwiLCJfQXV0aG9yc1ZpZXciLCJfdXNlT3ZlcmxheURpYWxvZyIsIl91c2VWZXJkaWN0cyIsIl9qc3hSdW50aW1lIiwiX3MiLCIkUmVmcmVzaFNpZyQiLCJlIiwiX19lc01vZHVsZSIsImRlZmF1bHQiLCJBcHAiLCJhcHBQYXRoIiwidXNlQXBwUGF0aCIsImhvc3RMb2MiLCJ1c2VIb3N0TG9jYXRpb24iLCJtb3VudHMiLCJ1c2VNb3VudHMiLCJ0YXNrSW5wdXQiLCJ1c2VUYXNrSW5wdXRMYXp5Iiwic2VlZCIsInNlZWRGb3JCb290Iiwid2luZG93IiwibG9jYXRpb24iLCJyZXBvcnQiLCJ1c2VSZXBvcnQiLCJkaXNwYXRjaCIsInJlc29sdmVXb3JrYm9va01vdW50IiwiZWRpdEZpbGUiLCJ1c2VFZGl0RmlsZSIsIm9rIiwibW91bnQiLCJyZXZpZXdPcGVuIiwic2V0UmV2aWV3T3BlbiIsInVzZVN0YXRlIiwiaW5zcGVjdGVkIiwic2V0SW5zcGVjdGVkIiwidmFyaWFudHMiLCJzZXRWYXJpYW50cyIsInNjcmF0Y2hUZXh0Iiwic2V0U2NyYXRjaFRleHQiLCJ3aGF0SWZPcGVuRm9yIiwic2V0V2hhdElmT3BlbkZvciIsImF1dGhvcnNPcGVuIiwic2V0QXV0aG9yc09wZW4iLCJ0aXRsZSIsInN0YXR1cyIsInNlc3Npb24iLCJ1bmRlZmluZWQiLCJ1c2VFZmZlY3QiLCJkb2N1bWVudCIsImluc3BlY3RlZENlbGwiLCJlbmdpbmUiLCJjZWxscyIsImZpbmQiLCJjIiwiaWQiLCJpbnNwZWN0aW9uIiwidXNlTWVtbyIsIm9uSW5zcGVjdCIsImNhbkluc3BlY3QiLCJzb3VyY2UiLCJzb21lIiwidmVyZGljdHMiLCJ1c2VWZXJkaWN0cyIsInRpY2siLCJpbnNwZWN0b3JSZWYiLCJ1c2VPdmVybGF5RGlhbG9nIiwiZW5hYmxlZCIsImpzeHMiLCJjbGFzc05hbWUiLCJjaGlsZHJlbiIsImpzeCIsIm1lc3NhZ2UiLCJGcmFnbWVudCIsImxvYyIsImN1cnJlbnQiLCJ0eXBlIiwib25DbGljayIsInYiLCJlZGl0ZWQiLCJvblJlbG9hZCIsInJlbG9hZCIsImNsZWFyU3RhbGUiLCJub3RpY2UiLCJyb2xlIiwiYmluZGluZ3MiLCJyZXN1bHRzIiwib25DbG9zZSIsIlJlcG9ydFZpZXciLCJub2RlcyIsIm9uT3BlbkF1dGhvcnMiLCJvblNjcmF0Y2hDaGFuZ2UiLCJyZWYiLCJjZWxsIiwidGVzdHMiLCJmaWx0ZXIiLCJ0Iiwic3ViamVjdCIsInJlc3VsdCIsIm9uTmF2aWdhdGUiLCJvbldoYXRJZiIsIndvcmtzaGVldFBhdGhzIiwiT2JqZWN0IiwiZnJvbUVudHJpZXMiLCJsb2FkZWQiLCJ3b3Jrc2hlZXRzIiwibWFwIiwidyIsIm5hbWUiLCJwYXRoIiwiY2FuRWRpdFBhdGgiLCJvbkVkaXQiLCJmb3JtdWxhU291cmNlIiwiYmFzZVZlcmRpY3RzIiwidGV4dCIsIm9uVGV4dENoYW5nZSIsImNlbGxJZCIsIl9jIiwiX2RlZmF1bHQiLCJleHBvcnRzIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQXBwLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBSb290IGNvbXBvbmVudCDigJQgdGhlIGRlZmF1bHQgZXhwb3J0IG9mIFRISVMgZmlsZSBpcyB3aGF0IHJlbmRlcnMuIGltbWVkaWF0ZWx5LnJ1biByZWFjaGVzIGl0XG4vLyB0aHJvdWdoIGBzcmMvcGxhdGZvcm0udHN4YCAoYHBhY2thZ2UuanNvbmAg4oaSIGBtYWluYCksIHdoaWNoIGV4aXN0cyBvbmx5IHRvIGNhbGxcbi8vIGBib290KHsgY2hpbGRyZW46IDxBcHAgLz4gfSlgIHNvIHRoZSBhcHAgb3ducyBhIHBhdGggc3BhY2UgKFIzLTU1Myk7IGBzcmMvbWFpbi50c3hgIGlzIHRoZVxuLy8gYHZpdGUgZGV2YCBlbnRyeSBhbmQgaXMgaWdub3JlZCBhdCBydW50aW1lIChBUkNISVRFQ1RVUkVfUExBTiDCpzIuMSwgwqc3KS4gUmVja29uZXIgb3BlbnMgYSBkb2N1bWVudCBhbmQgcmVuZGVycyBpdCBhcyBhIHN0YXRpYyByZXBvcnQgd2l0aCB6ZXJvIHByb21wdHM6XG4vLyB0aGUgaG9vayBsb2FkcyB0aGUgYnVuZGxlZCBkZW1vIGRvY3VtZW50LCBydW5zIHRoZSBTRVMtY29uZmluZWQgZW5naW5lLCBhbmQgaGFuZHMgdGhlIHJlbmRlclxuLy8gc3VyZmFjZSBhIEJpbmRpbmdzIHBvcnQgb3ZlciB0aGUgcmVzdWx0cy4gR2xvYmFsIENTUyBpcyBpbXBvcnRlZCBoZXJlIChub3QgbWFpbi50c3gpLCB3aGljaFxuLy8gaW1tZWRpYXRlbHkucnVuJ3MgcnVudGltZSBpZ25vcmVzLlxuLy9cbi8vIFRoZSBpbnNwZWN0ZWQgY2VsbCBpcyBhcHAtbGV2ZWwgc3RhdGUgc2hhcmVkIGJ5IHRoZSB0d28gZG9vcnMgaW50byB0aGUgdmFsdWUgaW5zcGVjdG9yOlxuLy8gdGhlIHdvcmtib29rIHBhbmVsJ3MgY2FyZHMgKGF1dGhvciBzdXJmYWNlKSBhbmQgVjMncyBvbi1waXhlbCBhZmZvcmRhbmNlIG9uIGJvdW5kIHJlcG9ydFxuLy8gZWxlbWVudHMgKGhvdmVyLXJldmVhbCAvIGxvbmctcHJlc3MpIOKAlCBib3RoIG9wZW4gdGhlIHNhbWUgZG9ja2VkIGluc3BlY3Rvci5cbmltcG9ydCAnLi9pbmRleC5jc3MnO1xuaW1wb3J0ICcuL2FwcC9yZXBvcnQtcGFnZS5jc3MnO1xuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VNZW1vLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZVJlcG9ydCB9IGZyb20gJy4vaG9va3MvdXNlUmVwb3J0LnRzJztcbmltcG9ydCB7IHNlZWRGb3JCb290IH0gZnJvbSAnLi9zZWVkL3NlZWRzLnRzJztcbmltcG9ydCB7IHVzZUFwcFBhdGgsIHVzZUhvc3RMb2NhdGlvbiB9IGZyb20gJy4vaG9va3MvdXNlQXBwUGF0aC50cyc7XG5pbXBvcnQgRG9jdW1lbnROYXYgZnJvbSAnLi9hcHAvRG9jdW1lbnROYXYudHN4JztcbmltcG9ydCBEb2N1bWVudENoYW5nZWROb3RpY2UgZnJvbSAnLi9hcHAvRG9jdW1lbnRDaGFuZ2VkTm90aWNlLnRzeCc7XG5pbXBvcnQgeyB1c2VNb3VudHMgfSBmcm9tICcuL2hvb2tzL3VzZU1vdW50cy50cyc7XG5pbXBvcnQgeyB1c2VUYXNrSW5wdXRMYXp5IH0gZnJvbSAnLi9ob29rcy91c2VUYXNrSW5wdXRMYXp5LnRzJztcbmltcG9ydCB7IHJlc29sdmVXb3JrYm9va01vdW50IH0gZnJvbSAnLi9hcHAvZGlzcGF0Y2gudHMnO1xuaW1wb3J0IHsgdXNlRWRpdEZpbGUgfSBmcm9tICcuL2hvb2tzL3VzZUVkaXRGaWxlLnRzJztcbmltcG9ydCB7IFJlcG9ydFZpZXcgfSBmcm9tICcuL3JlcG9ydC9pbmRleC50cyc7XG5pbXBvcnQgV29ya2Jvb2tQYW5lbCBmcm9tICcuL2FwcC9Xb3JrYm9va1BhbmVsLnRzeCc7XG5pbXBvcnQgVmFsdWVJbnNwZWN0b3IgZnJvbSAnLi9hcHAvVmFsdWVJbnNwZWN0b3IudHN4JztcbmltcG9ydCBXaGF0SWZQYW5lbCBmcm9tICcuL2FwcC9XaGF0SWZQYW5lbC50c3gnO1xuaW1wb3J0IEF1dGhvcnNWaWV3IGZyb20gJy4vYXBwL0F1dGhvcnNWaWV3LnRzeCc7XG5pbXBvcnQgeyB1c2VPdmVybGF5RGlhbG9nIH0gZnJvbSAnLi9hcHAvdXNlT3ZlcmxheURpYWxvZy50cyc7XG5pbXBvcnQgeyB1c2VWZXJkaWN0cyB9IGZyb20gJy4vaG9va3MvdXNlVmVyZGljdHMudHMnO1xuXG5mdW5jdGlvbiBBcHAoKSB7XG4gIC8vIFRoZSBhcHAtc3BhY2UgUEFUSCBwaWNrcyB0aGUgYnVuZGxlZCBkb2N1bWVudCAoYC9jYWxkZXJhYDsgYC9gIGlzIHRoZSBNZXJpZGlhblxuICAvLyBtb250aGx5IHJldmlldyksIGZhbGxpbmcgYmFjayB0byB0aGUgbGVnYWN5IGA/ZG9jPWAgcXVlcnkg4oCUIHdoaWNoIHRoZSBob3N0IGZvcndhcmRzIG9ubHlcbiAgLy8gYXQgYm9vdCwgc28gaXQgY2Fubm90IHN1cnZpdmUgbmF2aWdhdGlvbiBhbmQgaXMgY29tcGF0aWJpbGl0eSBvbmx5IChSMy01NTMpLiBUaGUgcGlja2VkXG4gIC8vIHNlZWQgaXMgYSBtb2R1bGUgY29uc3RhbnQsIHNvIHRoZSByZWZlcmVuY2UgaXMgc3RhYmxlIGFjcm9zcyByZW5kZXJzLlxuICBjb25zdCBhcHBQYXRoID0gdXNlQXBwUGF0aCgpO1xuICBjb25zdCBob3N0TG9jID0gdXNlSG9zdExvY2F0aW9uKCk7XG4gIGNvbnN0IG1vdW50cyA9IHVzZU1vdW50cygpO1xuICAvLyBUaGUgdGFzay1pbnZvY2F0aW9uIHNoYXBlIChSMy03NTQpOiB3aGVuIHRoaXMgZnJhbWUgaXMgYW4gYG9wZW4td29ya2Jvb2tgXG4gIC8vIGNhbGxlZSwgdGhlIGhvc3QncyByZXdyaXR0ZW4gYGRpcmAgcGFyYW0gKyB0aGUgbWludGVkIGB0YXNrLWRlbGVnYXRpb25gIG1vdW50XG4gIC8vIGFyZSB0aGUgZGlzcGF0Y2gg4oCUIHRoZSBpbnB1dCByZWFkIGxhemlseSAodGhlIFNESyB0YXNrIHN1cmZhY2Ugc3RheXMgYmVoaW5kXG4gIC8vIGR5bmFtaWMgaW1wb3J0cywgcGxhdGZvcm1HdWFyZHMudGVzdC50cykuXG4gIGNvbnN0IHRhc2tJbnB1dCA9IHVzZVRhc2tJbnB1dExhenkoKTtcbiAgY29uc3Qgc2VlZCA9IHNlZWRGb3JCb290KGFwcFBhdGgsIHdpbmRvdy5sb2NhdGlvbik7XG4gIGNvbnN0IHJlcG9ydCA9IHVzZVJlcG9ydChzZWVkLCBtb3VudHMsIHRhc2tJbnB1dCk7XG4gIC8vIFBhcnQgQiAoUjMtNDQ3KTogdGhlIGRpc3BhdGNoZWQgd29ya2Jvb2sncyBlZGl0IGRvb3IuIFRoZSBtb3VudCB0aGUgcmVzb2x1dGlvblxuICAvLyBjYXJyaWVzIGlzIHRoZSB3aG9sZSBjb250cmFjdCDigJQgd3JpdGFiaWxpdHkgYnkgdGhlIHBvc2l0aXZlIGByd2AgY2hlY2ssIGFuZCB0aGVcbiAgLy8gYGNhcEZpbGVgIGFkZHJlc3MgZnJvbSB0aGUgZGVzY3JpcHRvcidzIGlkIOKAlCB0aGUgdW5pdmVyc2FsIGBzY2hlbWU6bG9jYXRvcmAgZm9ybVxuICAvLyBvbiB0aGUgcmVwby1sb2FkIHNoYXBlLCB0aGUgY2hyb290IHBhdGggb24gdGhlIHRhc2staW52b2NhdGlvbiBzaGFwZSAodGhlIHR3b1xuICAvLyBmb3JtcyBwcm9iZWQgbGl2ZTsgRE9DVU1FTlRfTkFWSUdBVE9SX1NUQVRVUy5tZCkuIEFic2VudCAobmV2ZXIgZGlzYWJsZWQpIGluIHRoZVxuICAvLyBzZWVkIGZsb3cgYW5kIG9uIGFueSBub24tYHJ3YCBtb3VudC5cbiAgY29uc3QgZGlzcGF0Y2ggPSByZXNvbHZlV29ya2Jvb2tNb3VudChtb3VudHMsIHRhc2tJbnB1dCk7XG4gIGNvbnN0IGVkaXRGaWxlID0gdXNlRWRpdEZpbGUoZGlzcGF0Y2gub2sgPyBkaXNwYXRjaC5tb3VudCA6IG51bGwpO1xuICBjb25zdCBbcmV2aWV3T3Blbiwgc2V0UmV2aWV3T3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtpbnNwZWN0ZWQsIHNldEluc3BlY3RlZF0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgLy8gV2hhdC1pZiBidWZmZXIgdGV4dCBpcyBTRVNTSU9OLVNDT1BFRCBhcHAgc3RhdGUgKFdIQVRJRl9TSEFET1dfRVZBTFVBVElPTl9TUEVDIMKnMS40KTpcbiAgLy8gY2xvc2luZyBhIHBhbmVsIG11c3QgbmV2ZXIgZGVzdHJveSB0eXBlZCBzb3VyY2UsIHNvIHRoZSBwZXItY2VsbCB2YXJpYW50cyBhbmQgdGhlXG4gIC8vIHNjcmF0Y2ggcGFkJ3MgYnVmZmVyIGxpdmUgaGVyZSwgYWJvdmUgdGhlIHBhbmVscycgbW91bnQvdW5tb3VudCBsaWZlY3ljbGUuXG4gIGNvbnN0IFt2YXJpYW50cywgc2V0VmFyaWFudHNdID0gdXNlU3RhdGU8UmVjb3JkPHN0cmluZywgc3RyaW5nPj4oe30pO1xuICBjb25zdCBbc2NyYXRjaFRleHQsIHNldFNjcmF0Y2hUZXh0XSA9IHVzZVN0YXRlKCcnKTtcbiAgLy8gVGhlIHdoYXQtaWYgc2VjdGlvbiBpcyBjb2xsYXBzZWQgYnkgZGVmYXVsdCAoc3BlYyDCpzEuMSwgYW1lbmRlZCAyMDI2LTA4LTI4KTogdGhlXG4gIC8vIGZvcm11bGEgcm93J3MgXCJ3aGF0IGlmIOKGklwiIGFmZm9yZGFuY2Ugb3BlbnMgaXQsIGFuZCBpdCBzdGF5cyBvcGVuIG9uIGl0cyBvd24gd2hlbmV2ZXJcbiAgLy8gdGhlIGNlbGwncyB2YXJpYW50IHRleHQgZGlmZmVycyBmcm9tIHRoZSBkb2N1bWVudCBmb3JtdWxhIOKAlCB0eXBlZCBzb3VyY2UgbmV2ZXIgaGlkZXMuXG4gIC8vIEtleWVkIGJ5IGNlbGwgaWQgcmF0aGVyIHRoYW4gcmVzZXQgaW4gYW4gZWZmZWN0OiBuYXZpZ2F0aW5nIHRvIGFub3RoZXIgY2VsbCBtYWtlc1xuICAvLyB0aGUgZG9vciBjbG9zZWQgYWdhaW4gYnkgZGVyaXZhdGlvbiAocmVhY3QtaG9va3Mvc2V0LXN0YXRlLWluLWVmZmVjdCBzdGF5cyBoYXBweSkuXG4gIGNvbnN0IFt3aGF0SWZPcGVuRm9yLCBzZXRXaGF0SWZPcGVuRm9yXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICAvLyBUaGUgYXV0aG9yJ3MgdmlldyAoQVVUSE9SU19WSUVXX1NQRUMgwqcxLjIpOiBvcGVuZWQgZnJvbSB0aGUgd29ya2Jvb2sgcGFuZWwgKGl0c1xuICAvLyBkb29yKSwgcmVuZGVyZWQgaW4gcGxhY2Ugb2YgdGhlIHJlcG9ydCB3aXRoIGFuIGV4cGxpY2l0IHdheSBiYWNrLiBDb21wb25lbnQgc3RhdGUsXG4gIC8vIG5vdCBhIHJvdXRlLlxuICBjb25zdCBbYXV0aG9yc09wZW4sIHNldEF1dGhvcnNPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgdGl0bGUgPSByZXBvcnQuc3RhdHVzID09PSAncmVhZHknID8gcmVwb3J0LnNlc3Npb24udGl0bGUgOiB1bmRlZmluZWQ7XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKHRpdGxlICE9PSB1bmRlZmluZWQpIGRvY3VtZW50LnRpdGxlID0gdGl0bGU7XG4gIH0sIFt0aXRsZV0pO1xuXG4gIGNvbnN0IGluc3BlY3RlZENlbGwgPVxuICAgIHJlcG9ydC5zdGF0dXMgPT09ICdyZWFkeScgJiYgaW5zcGVjdGVkICE9PSBudWxsXG4gICAgICA/IHJlcG9ydC5zZXNzaW9uLmVuZ2luZS5jZWxscygpLmZpbmQoKGMpID0+IGMuaWQgPT09IGluc3BlY3RlZCkgPz8gbnVsbFxuICAgICAgOiBudWxsO1xuXG4gIC8vIFYzJ3MgaW5zcGVjdGlvbiBwb3J0OiBib3VuZCBlbGVtZW50cyBvZmZlciBob3Zlci9sb25nLXByZXNzIGluc3BlY3Rpb24gb2YgdGhlIENFTEwgdGhleVxuICAvLyBkaXNwbGF5IChleHRlcm5hbHMg4oCUIHBhcmFtcy9maXh0dXJlcyDigJQgaGF2ZSBubyBpbnNwZWN0b3IgY2FyZCwgc28gbm8gYWZmb3JkYW5jZSB0aGVyZSkuXG4gIGNvbnN0IGluc3BlY3Rpb24gPSB1c2VNZW1vKFxuICAgICgpID0+XG4gICAgICByZXBvcnQuc3RhdHVzID09PSAncmVhZHknXG4gICAgICAgID8ge1xuICAgICAgICAgICAgb25JbnNwZWN0OiBzZXRJbnNwZWN0ZWQsXG4gICAgICAgICAgICBjYW5JbnNwZWN0OiAoc291cmNlOiBzdHJpbmcpID0+IHJlcG9ydC5zZXNzaW9uLmVuZ2luZS5jZWxscygpLnNvbWUoKGMpID0+IGMuaWQgPT09IHNvdXJjZSksXG4gICAgICAgICAgfVxuICAgICAgICA6IG51bGwsXG4gICAgW3JlcG9ydF0sXG4gICk7XG5cbiAgY29uc3QgdmVyZGljdHMgPSB1c2VWZXJkaWN0cyhcbiAgICByZXBvcnQuc3RhdHVzID09PSAncmVhZHknID8gcmVwb3J0LnNlc3Npb24uZW5naW5lIDogbnVsbCxcbiAgICByZXBvcnQuc3RhdHVzID09PSAncmVhZHknID8gcmVwb3J0LnRpY2sgOiAwLFxuICApO1xuXG4gIC8vIFRoZSBpbnNwZWN0b3IgZG9jaydzIGRpYWxvZyBjb250cmFjdCAoUjMtNjEwKSDigJQgZm9jdXMgaW4gb24gb3BlbiwgVGFiIHdyYXAsIGtleWVkXG4gIC8vIGNsb3NlLCBmb2N1cyBiYWNrIHRvIHRoZSBjYXJkIG9yIHJlcG9ydCBhZmZvcmRhbmNlIHRoYXQgb3BlbmVkIGl0IOKAlCBsaXZlcyBpbiBvbmVcbiAgLy8gaG9vazsgYGVuYWJsZWRgIGZsaXBzIHdpdGggdGhlIGRvY2sncyBvd24gY29uZGl0aW9uYWwgbW91bnQsIHNvIHRoZSBlZmZlY3QgYW5kIHRoZVxuICAvLyBlbGVtZW50IGFwcGVhciB0b2dldGhlci5cbiAgY29uc3QgaW5zcGVjdG9yUmVmID0gdXNlT3ZlcmxheURpYWxvZzxIVE1MRGl2RWxlbWVudD4oKCkgPT4gc2V0SW5zcGVjdGVkKG51bGwpLCB7XG4gICAgZW5hYmxlZDogaW5zcGVjdGVkQ2VsbCAhPT0gbnVsbCxcbiAgfSk7XG5cbiAgcmV0dXJuIChcbiAgICA8bWFpbiBjbGFzc05hbWU9XCJyay1wYWdlXCI+XG4gICAgICB7cmVwb3J0LnN0YXR1cyA9PT0gJ2xvYWRpbmcnICYmIDxkaXYgY2xhc3NOYW1lPVwicmstcGFnZS1ub3RlXCI+TG9hZGluZyByZXBvcnTigKY8L2Rpdj59XG4gICAgICB7cmVwb3J0LnN0YXR1cyA9PT0gJ2Vycm9yJyAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmstcGFnZS1ub3RlIHJrLXBhZ2UtZXJyb3JcIj5Db3VsZCBub3QgbG9hZCB0aGUgcmVwb3J0OiB7cmVwb3J0Lm1lc3NhZ2V9PC9kaXY+XG4gICAgICApfVxuICAgICAge3JlcG9ydC5zdGF0dXMgPT09ICdyZWFkeScgJiYgKFxuICAgICAgICA8PlxuICAgICAgICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwicmstcGFnZS1oZWFkXCI+XG4gICAgICAgICAgICA8RG9jdW1lbnROYXYgbG9jPXtob3N0TG9jfSBjdXJyZW50PXtzZWVkfSAvPlxuICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cImdyYWQtdGV4dFwiPntyZXBvcnQuc2Vzc2lvbi50aXRsZX08L2gxPlxuICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwicmstcmV2aWV3LXRvZ2dsZVwiIG9uQ2xpY2s9eygpID0+IHNldFJldmlld09wZW4oKHYpID0+ICF2KX0+XG4gICAgICAgICAgICAgIHtyZXZpZXdPcGVuID8gJ0Nsb3NlIHdvcmtib29rJyA6ICdXb3JrYm9vayd9XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2hlYWRlcj5cbiAgICAgICAgICB7ZWRpdEZpbGUuZWRpdGVkICYmIChcbiAgICAgICAgICAgIDxEb2N1bWVudENoYW5nZWROb3RpY2VcbiAgICAgICAgICAgICAgb25SZWxvYWQ9eygpID0+IHtcbiAgICAgICAgICAgICAgICByZXBvcnQucmVsb2FkKCk7XG4gICAgICAgICAgICAgICAgZWRpdEZpbGUuY2xlYXJTdGFsZSgpO1xuICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICApfVxuICAgICAgICAgIHtlZGl0RmlsZS5ub3RpY2UgIT09IG51bGwgJiYgPGRpdiBjbGFzc05hbWU9XCJyay1zdGFsZSByay1zdGFsZS0tbm90ZVwiIHJvbGU9XCJzdGF0dXNcIj57ZWRpdEZpbGUubm90aWNlfTwvZGl2Pn1cbiAgICAgICAgICB7YXV0aG9yc09wZW4gPyAoXG4gICAgICAgICAgICA8QXV0aG9yc1ZpZXdcbiAgICAgICAgICAgICAgc2Vzc2lvbj17cmVwb3J0LnNlc3Npb259XG4gICAgICAgICAgICAgIGJpbmRpbmdzPXtyZXBvcnQuYmluZGluZ3N9XG4gICAgICAgICAgICAgIHZlcmRpY3RzPXt2ZXJkaWN0cy5yZXN1bHRzfVxuICAgICAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRBdXRob3JzT3BlbihmYWxzZSl9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICA8UmVwb3J0VmlldyBub2Rlcz17cmVwb3J0LnNlc3Npb24ubm9kZXN9IGJpbmRpbmdzPXtyZXBvcnQuYmluZGluZ3N9IGluc3BlY3Rpb249e2luc3BlY3Rpb24gPz8gdW5kZWZpbmVkfSAvPlxuICAgICAgICAgICl9XG4gICAgICAgICAge3Jldmlld09wZW4gJiYgKFxuICAgICAgICAgICAgPFdvcmtib29rUGFuZWxcbiAgICAgICAgICAgICAgc2Vzc2lvbj17cmVwb3J0LnNlc3Npb259XG4gICAgICAgICAgICAgIHZlcmRpY3RzPXt2ZXJkaWN0c31cbiAgICAgICAgICAgICAgb25JbnNwZWN0PXtzZXRJbnNwZWN0ZWR9XG4gICAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldFJldmlld09wZW4oZmFsc2UpfVxuICAgICAgICAgICAgICBvbk9wZW5BdXRob3JzPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgc2V0UmV2aWV3T3BlbihmYWxzZSk7XG4gICAgICAgICAgICAgICAgc2V0QXV0aG9yc09wZW4odHJ1ZSk7XG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgIHNjcmF0Y2hUZXh0PXtzY3JhdGNoVGV4dH1cbiAgICAgICAgICAgICAgb25TY3JhdGNoQ2hhbmdlPXtzZXRTY3JhdGNoVGV4dH1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgKX1cbiAgICAgICAgICB7aW5zcGVjdGVkQ2VsbCAhPT0gbnVsbCAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJrLWluc3BlY3Rvci1kb2NrXCIgcm9sZT1cImRpYWxvZ1wiIGFyaWEtbW9kYWw9XCJ0cnVlXCIgYXJpYS1sYWJlbD1cIlZhbHVlIGluc3BlY3RvclwiIHJlZj17aW5zcGVjdG9yUmVmfT5cbiAgICAgICAgICAgICAgPFZhbHVlSW5zcGVjdG9yXG4gICAgICAgICAgICAgICAgY2VsbD17aW5zcGVjdGVkQ2VsbH1cbiAgICAgICAgICAgICAgICBjZWxscz17cmVwb3J0LnNlc3Npb24uZW5naW5lLmNlbGxzKCl9XG4gICAgICAgICAgICAgICAgdGVzdHM9e3JlcG9ydC5zZXNzaW9uLmVuZ2luZS50ZXN0cygpLmZpbHRlcigodCkgPT4gdC5zdWJqZWN0ID09PSBpbnNwZWN0ZWRDZWxsLmlkKX1cbiAgICAgICAgICAgICAgICB2ZXJkaWN0cz17dmVyZGljdHMucmVzdWx0c31cbiAgICAgICAgICAgICAgICByZXN1bHQ9e3JlcG9ydC5zZXNzaW9uLmVuZ2luZS5yZXN1bHQoaW5zcGVjdGVkQ2VsbC5pZCl9XG4gICAgICAgICAgICAgICAgb25OYXZpZ2F0ZT17c2V0SW5zcGVjdGVkfVxuICAgICAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldEluc3BlY3RlZChudWxsKX1cbiAgICAgICAgICAgICAgICBvbldoYXRJZj17KCkgPT4gc2V0V2hhdElmT3BlbkZvcihpbnNwZWN0ZWRDZWxsLmlkKX1cbiAgICAgICAgICAgICAgICB3b3Jrc2hlZXRQYXRocz17T2JqZWN0LmZyb21FbnRyaWVzKHJlcG9ydC5zZXNzaW9uLmxvYWRlZC53b3Jrc2hlZXRzLm1hcCgodykgPT4gW3cubmFtZSwgdy5wYXRoXSkpfVxuICAgICAgICAgICAgICAgIGNhbkVkaXRQYXRoPXtlZGl0RmlsZS5jYW5FZGl0UGF0aH1cbiAgICAgICAgICAgICAgICBvbkVkaXQ9e2VkaXRGaWxlLm9uRWRpdH1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgeyh3aGF0SWZPcGVuRm9yID09PSBpbnNwZWN0ZWRDZWxsLmlkIHx8XG4gICAgICAgICAgICAgICAgKHZhcmlhbnRzW2luc3BlY3RlZENlbGwuaWRdICE9PSB1bmRlZmluZWQgJiZcbiAgICAgICAgICAgICAgICAgIHZhcmlhbnRzW2luc3BlY3RlZENlbGwuaWRdICE9PSBpbnNwZWN0ZWRDZWxsLmZvcm11bGFTb3VyY2UpKSAmJiAoXG4gICAgICAgICAgICAgICAgPFdoYXRJZlBhbmVsXG4gICAgICAgICAgICAgICAgICBzZXNzaW9uPXtyZXBvcnQuc2Vzc2lvbn1cbiAgICAgICAgICAgICAgICAgIGNlbGw9e2luc3BlY3RlZENlbGx9XG4gICAgICAgICAgICAgICAgICBiYXNlVmVyZGljdHM9e3ZlcmRpY3RzLnJlc3VsdHN9XG4gICAgICAgICAgICAgICAgICB0ZXh0PXt2YXJpYW50c1tpbnNwZWN0ZWRDZWxsLmlkXSA/PyBpbnNwZWN0ZWRDZWxsLmZvcm11bGFTb3VyY2V9XG4gICAgICAgICAgICAgICAgICBvblRleHRDaGFuZ2U9eyhjZWxsSWQsIHRleHQpID0+IHNldFZhcmlhbnRzKCh2KSA9PiAoeyAuLi52LCBbY2VsbElkXTogdGV4dCB9KSl9XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG4gICAgICAgIDwvPlxuICAgICAgKX1cbiAgICA8L21haW4+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IEFwcDtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7QUFXQUEsT0FBQTtBQUNBQSxPQUFBO0FBQ0EsSUFBQUMsTUFBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsVUFBQSxHQUFBRixPQUFBO0FBQ0EsSUFBQUcsTUFBQSxHQUFBSCxPQUFBO0FBQ0EsSUFBQUksV0FBQSxHQUFBSixPQUFBO0FBQ0EsSUFBQUssWUFBQSxHQUFBQyxzQkFBQSxDQUFBTixPQUFBO0FBQ0EsSUFBQU8sc0JBQUEsR0FBQUQsc0JBQUEsQ0FBQU4sT0FBQTtBQUNBLElBQUFRLFVBQUEsR0FBQVIsT0FBQTtBQUNBLElBQUFTLGlCQUFBLEdBQUFULE9BQUE7QUFDQSxJQUFBVSxTQUFBLEdBQUFWLE9BQUE7QUFDQSxJQUFBVyxZQUFBLEdBQUFYLE9BQUE7QUFDQSxJQUFBWSxPQUFBLEdBQUFaLE9BQUE7QUFDQSxJQUFBYSxjQUFBLEdBQUFQLHNCQUFBLENBQUFOLE9BQUE7QUFDQSxJQUFBYyxlQUFBLEdBQUFSLHNCQUFBLENBQUFOLE9BQUE7QUFDQSxJQUFBZSxZQUFBLEdBQUFULHNCQUFBLENBQUFOLE9BQUE7QUFDQSxJQUFBZ0IsWUFBQSxHQUFBVixzQkFBQSxDQUFBTixPQUFBO0FBQ0EsSUFBQWlCLGlCQUFBLEdBQUFqQixPQUFBO0FBQ0EsSUFBQWtCLFlBQUEsR0FBQWxCLE9BQUE7QUFBcUQsSUFBQW1CLFdBQUEsR0FBQW5CLE9BQUE7QUFBQSxJQUFBb0IsRUFBQSxHQUFBQyxZQUFBLElBN0JyRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQUEsU0FBQWYsdUJBQUFnQixDQUFBLFdBQUFBLENBQUEsSUFBQUEsQ0FBQSxDQUFBQyxVQUFBLEdBQUFELENBQUEsS0FBQUUsT0FBQSxFQUFBRixDQUFBO0FBcUJBLFNBQVNHLEdBQUdBLENBQUEsRUFBRztFQUFBTCxFQUFBO0VBQ2I7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNTSxPQUFPLEdBQUcsSUFBQUMsc0JBQVUsRUFBQyxDQUFDO0VBQzVCLE1BQU1DLE9BQU8sR0FBRyxJQUFBQywyQkFBZSxFQUFDLENBQUM7RUFDakMsTUFBTUMsTUFBTSxHQUFHLElBQUFDLG9CQUFTLEVBQUMsQ0FBQztFQUMxQjtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU1DLFNBQVMsR0FBRyxJQUFBQyxrQ0FBZ0IsRUFBQyxDQUFDO0VBQ3BDLE1BQU1DLElBQUksR0FBRyxJQUFBQyxrQkFBVyxFQUFDVCxPQUFPLEVBQUVVLE1BQU0sQ0FBQ0MsUUFBUSxDQUFDO0VBQ2xELE1BQU1DLE1BQU0sR0FBRyxJQUFBQyxvQkFBUyxFQUFDTCxJQUFJLEVBQUVKLE1BQU0sRUFBRUUsU0FBUyxDQUFDO0VBQ2pEO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU1RLFFBQVEsR0FBRyxJQUFBQyw4QkFBb0IsRUFBQ1gsTUFBTSxFQUFFRSxTQUFTLENBQUM7RUFDeEQsTUFBTVUsUUFBUSxHQUFHLElBQUFDLHdCQUFXLEVBQUNILFFBQVEsQ0FBQ0ksRUFBRSxHQUFHSixRQUFRLENBQUNLLEtBQUssR0FBRyxJQUFJLENBQUM7RUFDakUsTUFBTSxDQUFDQyxVQUFVLEVBQUVDLGFBQWEsQ0FBQyxHQUFHLElBQUFDLGVBQVEsRUFBQyxLQUFLLENBQUM7RUFDbkQsTUFBTSxDQUFDQyxTQUFTLEVBQUVDLFlBQVksQ0FBQyxHQUFHLElBQUFGLGVBQVEsRUFBZ0IsSUFBSSxDQUFDO0VBQy9EO0VBQ0E7RUFDQTtFQUNBLE1BQU0sQ0FBQ0csUUFBUSxFQUFFQyxXQUFXLENBQUMsR0FBRyxJQUFBSixlQUFRLEVBQXlCLENBQUMsQ0FBQyxDQUFDO0VBQ3BFLE1BQU0sQ0FBQ0ssV0FBVyxFQUFFQyxjQUFjLENBQUMsR0FBRyxJQUFBTixlQUFRLEVBQUMsRUFBRSxDQUFDO0VBQ2xEO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNLENBQUNPLGFBQWEsRUFBRUMsZ0JBQWdCLENBQUMsR0FBRyxJQUFBUixlQUFRLEVBQWdCLElBQUksQ0FBQztFQUN2RTtFQUNBO0VBQ0E7RUFDQSxNQUFNLENBQUNTLFdBQVcsRUFBRUMsY0FBYyxDQUFDLEdBQUcsSUFBQVYsZUFBUSxFQUFDLEtBQUssQ0FBQztFQUNyRCxNQUFNVyxLQUFLLEdBQUdyQixNQUFNLENBQUNzQixNQUFNLEtBQUssT0FBTyxHQUFHdEIsTUFBTSxDQUFDdUIsT0FBTyxDQUFDRixLQUFLLEdBQUdHLFNBQVM7RUFDMUUsSUFBQUMsZ0JBQVMsRUFBQyxNQUFNO0lBQ2QsSUFBSUosS0FBSyxLQUFLRyxTQUFTLEVBQUVFLFFBQVEsQ0FBQ0wsS0FBSyxHQUFHQSxLQUFLO0VBQ2pELENBQUMsRUFBRSxDQUFDQSxLQUFLLENBQUMsQ0FBQztFQUVYLE1BQU1NLGFBQWEsR0FDakIzQixNQUFNLENBQUNzQixNQUFNLEtBQUssT0FBTyxJQUFJWCxTQUFTLEtBQUssSUFBSSxHQUMzQ1gsTUFBTSxDQUFDdUIsT0FBTyxDQUFDSyxNQUFNLENBQUNDLEtBQUssQ0FBQyxDQUFDLENBQUNDLElBQUksQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUNDLEVBQUUsS0FBS3JCLFNBQVMsQ0FBQyxJQUFJLElBQUksR0FDckUsSUFBSTs7RUFFVjtFQUNBO0VBQ0EsTUFBTXNCLFVBQVUsR0FBRyxJQUFBQyxjQUFPLEVBQ3hCLE1BQ0VsQyxNQUFNLENBQUNzQixNQUFNLEtBQUssT0FBTyxHQUNyQjtJQUNFYSxTQUFTLEVBQUV2QixZQUFZO0lBQ3ZCd0IsVUFBVSxFQUFHQyxNQUFjLElBQUtyQyxNQUFNLENBQUN1QixPQUFPLENBQUNLLE1BQU0sQ0FBQ0MsS0FBSyxDQUFDLENBQUMsQ0FBQ1MsSUFBSSxDQUFFUCxDQUFDLElBQUtBLENBQUMsQ0FBQ0MsRUFBRSxLQUFLSyxNQUFNO0VBQzNGLENBQUMsR0FDRCxJQUFJLEVBQ1YsQ0FBQ3JDLE1BQU0sQ0FDVCxDQUFDO0VBRUQsTUFBTXVDLFFBQVEsR0FBRyxJQUFBQyx3QkFBVyxFQUMxQnhDLE1BQU0sQ0FBQ3NCLE1BQU0sS0FBSyxPQUFPLEdBQUd0QixNQUFNLENBQUN1QixPQUFPLENBQUNLLE1BQU0sR0FBRyxJQUFJLEVBQ3hENUIsTUFBTSxDQUFDc0IsTUFBTSxLQUFLLE9BQU8sR0FBR3RCLE1BQU0sQ0FBQ3lDLElBQUksR0FBRyxDQUM1QyxDQUFDOztFQUVEO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsTUFBTUMsWUFBWSxHQUFHLElBQUFDLGtDQUFnQixFQUFpQixNQUFNL0IsWUFBWSxDQUFDLElBQUksQ0FBQyxFQUFFO0lBQzlFZ0MsT0FBTyxFQUFFakIsYUFBYSxLQUFLO0VBQzdCLENBQUMsQ0FBQztFQUVGLG9CQUNFLElBQUE5QyxXQUFBLENBQUFnRSxJQUFBO0lBQU1DLFNBQVMsRUFBQyxTQUFTO0lBQUFDLFFBQUEsR0FDdEIvQyxNQUFNLENBQUNzQixNQUFNLEtBQUssU0FBUyxpQkFBSSxJQUFBekMsV0FBQSxDQUFBbUUsR0FBQTtNQUFLRixTQUFTLEVBQUMsY0FBYztNQUFBQyxRQUFBLEVBQUM7SUFBZSxDQUFLLENBQUMsRUFDbEYvQyxNQUFNLENBQUNzQixNQUFNLEtBQUssT0FBTyxpQkFDeEIsSUFBQXpDLFdBQUEsQ0FBQWdFLElBQUE7TUFBS0MsU0FBUyxFQUFDLDRCQUE0QjtNQUFBQyxRQUFBLEdBQUMsNkJBQTJCLEVBQUMvQyxNQUFNLENBQUNpRCxPQUFPO0lBQUEsQ0FBTSxDQUM3RixFQUNBakQsTUFBTSxDQUFDc0IsTUFBTSxLQUFLLE9BQU8saUJBQ3hCLElBQUF6QyxXQUFBLENBQUFnRSxJQUFBLEVBQUFoRSxXQUFBLENBQUFxRSxRQUFBO01BQUFILFFBQUEsZ0JBQ0UsSUFBQWxFLFdBQUEsQ0FBQWdFLElBQUE7UUFBUUMsU0FBUyxFQUFDLGNBQWM7UUFBQUMsUUFBQSxnQkFDOUIsSUFBQWxFLFdBQUEsQ0FBQW1FLEdBQUEsRUFBQ2pGLFlBQUEsQ0FBQW1CLE9BQVc7VUFBQ2lFLEdBQUcsRUFBRTdELE9BQVE7VUFBQzhELE9BQU8sRUFBRXhEO1FBQUssQ0FBRSxDQUFDLGVBQzVDLElBQUFmLFdBQUEsQ0FBQW1FLEdBQUE7VUFBSUYsU0FBUyxFQUFDLFdBQVc7VUFBQUMsUUFBQSxFQUFFL0MsTUFBTSxDQUFDdUIsT0FBTyxDQUFDRjtRQUFLLENBQUssQ0FBQyxlQUNyRCxJQUFBeEMsV0FBQSxDQUFBbUUsR0FBQTtVQUFRSyxJQUFJLEVBQUMsUUFBUTtVQUFDUCxTQUFTLEVBQUMsa0JBQWtCO1VBQUNRLE9BQU8sRUFBRUEsQ0FBQSxLQUFNN0MsYUFBYSxDQUFFOEMsQ0FBQyxJQUFLLENBQUNBLENBQUMsQ0FBRTtVQUFBUixRQUFBLEVBQ3hGdkMsVUFBVSxHQUFHLGdCQUFnQixHQUFHO1FBQVUsQ0FDckMsQ0FBQztNQUFBLENBQ0gsQ0FBQyxFQUNSSixRQUFRLENBQUNvRCxNQUFNLGlCQUNkLElBQUEzRSxXQUFBLENBQUFtRSxHQUFBLEVBQUMvRSxzQkFBQSxDQUFBaUIsT0FBcUI7UUFDcEJ1RSxRQUFRLEVBQUVBLENBQUEsS0FBTTtVQUNkekQsTUFBTSxDQUFDMEQsTUFBTSxDQUFDLENBQUM7VUFDZnRELFFBQVEsQ0FBQ3VELFVBQVUsQ0FBQyxDQUFDO1FBQ3ZCO01BQUUsQ0FDSCxDQUNGLEVBQ0F2RCxRQUFRLENBQUN3RCxNQUFNLEtBQUssSUFBSSxpQkFBSSxJQUFBL0UsV0FBQSxDQUFBbUUsR0FBQTtRQUFLRixTQUFTLEVBQUMseUJBQXlCO1FBQUNlLElBQUksRUFBQyxRQUFRO1FBQUFkLFFBQUEsRUFBRTNDLFFBQVEsQ0FBQ3dEO01BQU0sQ0FBTSxDQUFDLEVBQzFHekMsV0FBVyxnQkFDVixJQUFBdEMsV0FBQSxDQUFBbUUsR0FBQSxFQUFDdEUsWUFBQSxDQUFBUSxPQUFXO1FBQ1ZxQyxPQUFPLEVBQUV2QixNQUFNLENBQUN1QixPQUFRO1FBQ3hCdUMsUUFBUSxFQUFFOUQsTUFBTSxDQUFDOEQsUUFBUztRQUMxQnZCLFFBQVEsRUFBRUEsUUFBUSxDQUFDd0IsT0FBUTtRQUMzQkMsT0FBTyxFQUFFQSxDQUFBLEtBQU01QyxjQUFjLENBQUMsS0FBSztNQUFFLENBQ3RDLENBQUMsZ0JBRUYsSUFBQXZDLFdBQUEsQ0FBQW1FLEdBQUEsRUFBQzFFLE9BQUEsQ0FBQTJGLFVBQVU7UUFBQ0MsS0FBSyxFQUFFbEUsTUFBTSxDQUFDdUIsT0FBTyxDQUFDMkMsS0FBTTtRQUFDSixRQUFRLEVBQUU5RCxNQUFNLENBQUM4RCxRQUFTO1FBQUM3QixVQUFVLEVBQUVBLFVBQVUsSUFBSVQ7TUFBVSxDQUFFLENBQzNHLEVBQ0FoQixVQUFVLGlCQUNULElBQUEzQixXQUFBLENBQUFtRSxHQUFBLEVBQUN6RSxjQUFBLENBQUFXLE9BQWE7UUFDWnFDLE9BQU8sRUFBRXZCLE1BQU0sQ0FBQ3VCLE9BQVE7UUFDeEJnQixRQUFRLEVBQUVBLFFBQVM7UUFDbkJKLFNBQVMsRUFBRXZCLFlBQWE7UUFDeEJvRCxPQUFPLEVBQUVBLENBQUEsS0FBTXZELGFBQWEsQ0FBQyxLQUFLLENBQUU7UUFDcEMwRCxhQUFhLEVBQUVBLENBQUEsS0FBTTtVQUNuQjFELGFBQWEsQ0FBQyxLQUFLLENBQUM7VUFDcEJXLGNBQWMsQ0FBQyxJQUFJLENBQUM7UUFDdEIsQ0FBRTtRQUNGTCxXQUFXLEVBQUVBLFdBQVk7UUFDekJxRCxlQUFlLEVBQUVwRDtNQUFlLENBQ2pDLENBQ0YsRUFDQVcsYUFBYSxLQUFLLElBQUksaUJBQ3JCLElBQUE5QyxXQUFBLENBQUFnRSxJQUFBO1FBQUtDLFNBQVMsRUFBQyxtQkFBbUI7UUFBQ2UsSUFBSSxFQUFDLFFBQVE7UUFBQyxjQUFXLE1BQU07UUFBQyxjQUFXLGlCQUFpQjtRQUFDUSxHQUFHLEVBQUUzQixZQUFhO1FBQUFLLFFBQUEsZ0JBQ2hILElBQUFsRSxXQUFBLENBQUFtRSxHQUFBLEVBQUN4RSxlQUFBLENBQUFVLE9BQWM7VUFDYm9GLElBQUksRUFBRTNDLGFBQWM7VUFDcEJFLEtBQUssRUFBRTdCLE1BQU0sQ0FBQ3VCLE9BQU8sQ0FBQ0ssTUFBTSxDQUFDQyxLQUFLLENBQUMsQ0FBRTtVQUNyQzBDLEtBQUssRUFBRXZFLE1BQU0sQ0FBQ3VCLE9BQU8sQ0FBQ0ssTUFBTSxDQUFDMkMsS0FBSyxDQUFDLENBQUMsQ0FBQ0MsTUFBTSxDQUFFQyxDQUFDLElBQUtBLENBQUMsQ0FBQ0MsT0FBTyxLQUFLL0MsYUFBYSxDQUFDSyxFQUFFLENBQUU7VUFDbkZPLFFBQVEsRUFBRUEsUUFBUSxDQUFDd0IsT0FBUTtVQUMzQlksTUFBTSxFQUFFM0UsTUFBTSxDQUFDdUIsT0FBTyxDQUFDSyxNQUFNLENBQUMrQyxNQUFNLENBQUNoRCxhQUFhLENBQUNLLEVBQUUsQ0FBRTtVQUN2RDRDLFVBQVUsRUFBRWhFLFlBQWE7VUFDekJvRCxPQUFPLEVBQUVBLENBQUEsS0FBTXBELFlBQVksQ0FBQyxJQUFJLENBQUU7VUFDbENpRSxRQUFRLEVBQUVBLENBQUEsS0FBTTNELGdCQUFnQixDQUFDUyxhQUFhLENBQUNLLEVBQUUsQ0FBRTtVQUNuRDhDLGNBQWMsRUFBRUMsTUFBTSxDQUFDQyxXQUFXLENBQUNoRixNQUFNLENBQUN1QixPQUFPLENBQUMwRCxNQUFNLENBQUNDLFVBQVUsQ0FBQ0MsR0FBRyxDQUFFQyxDQUFDLElBQUssQ0FBQ0EsQ0FBQyxDQUFDQyxJQUFJLEVBQUVELENBQUMsQ0FBQ0UsSUFBSSxDQUFDLENBQUMsQ0FBRTtVQUNsR0MsV0FBVyxFQUFFbkYsUUFBUSxDQUFDbUYsV0FBWTtVQUNsQ0MsTUFBTSxFQUFFcEYsUUFBUSxDQUFDb0Y7UUFBTyxDQUN6QixDQUFDLEVBQ0QsQ0FBQ3ZFLGFBQWEsS0FBS1UsYUFBYSxDQUFDSyxFQUFFLElBQ2pDbkIsUUFBUSxDQUFDYyxhQUFhLENBQUNLLEVBQUUsQ0FBQyxLQUFLUixTQUFTLElBQ3ZDWCxRQUFRLENBQUNjLGFBQWEsQ0FBQ0ssRUFBRSxDQUFDLEtBQUtMLGFBQWEsQ0FBQzhELGFBQWMsa0JBQzdELElBQUE1RyxXQUFBLENBQUFtRSxHQUFBLEVBQUN2RSxZQUFBLENBQUFTLE9BQVc7VUFDVnFDLE9BQU8sRUFBRXZCLE1BQU0sQ0FBQ3VCLE9BQVE7VUFDeEIrQyxJQUFJLEVBQUUzQyxhQUFjO1VBQ3BCK0QsWUFBWSxFQUFFbkQsUUFBUSxDQUFDd0IsT0FBUTtVQUMvQjRCLElBQUksRUFBRTlFLFFBQVEsQ0FBQ2MsYUFBYSxDQUFDSyxFQUFFLENBQUMsSUFBSUwsYUFBYSxDQUFDOEQsYUFBYztVQUNoRUcsWUFBWSxFQUFFQSxDQUFDQyxNQUFNLEVBQUVGLElBQUksS0FBSzdFLFdBQVcsQ0FBRXlDLENBQUMsS0FBTTtZQUFFLEdBQUdBLENBQUM7WUFBRSxDQUFDc0MsTUFBTSxHQUFHRjtVQUFLLENBQUMsQ0FBQztRQUFFLENBQ2hGLENBQ0Y7TUFBQSxDQUNFLENBQ047SUFBQSxDQUNELENBQ0g7RUFBQSxDQUNHLENBQUM7QUFFWDtBQUFDN0csRUFBQSxDQTVKUUssR0FBRztFQUFBLFFBS01FLHNCQUFVLEVBQ1ZFLDJCQUFlLEVBQ2hCRSxvQkFBUyxFQUtORSxrQ0FBZ0IsRUFFbkJNLG9CQUFTLEVBUVBJLHdCQUFXLEVBeUNYbUMsd0JBQVcsRUFTUEcsa0NBQWdCO0FBQUE7QUFBQW1ELEVBQUEsR0F4RTlCM0csR0FBRztBQUFBLElBQUE0RyxRQUFBLEdBQUFDLE9BQUEsQ0FBQTlHLE9BQUEsR0E4SkdDLEdBQUc7QUFBQSxJQUFBMkcsRUFBQTtBQUFBRyxZQUFBLENBQUFILEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}