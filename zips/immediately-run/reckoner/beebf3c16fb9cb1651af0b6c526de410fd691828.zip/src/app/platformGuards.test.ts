// Platform guards: source-level invariants that only fail on immediately.run (the
// "works in vite dev, breaks on the platform" trap). Vitest runs in Node; these read the
// repo's own source and fail loudly at test time, not in a user's browser.
import { describe, it, expect } from 'vitest';
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';

/** Modules exempt from each guard, with the reason each is safe. */
const IMPORT_META_EXEMPT = new Set([
  // vite-only dev entry — the platform never loads it (entry is App.tsx's default export).
  'src/main.tsx',
  // the one sanctioned home of import.meta.url, reached only via dynamic import inside
  // makeTransport's try/catch, so its parse failure on the platform is catchable.
  'src/app/workerUrl.ts',
]);

function* tsFiles(dir: string): Generator<string> {
  for (const name of readdirSync(dir)) {
    const p = join(dir, name);
    if (statSync(p).isDirectory()) yield* tsFiles(p);
    else if (/\.(ts|tsx)$/.test(name) && !/\.test\.(ts|tsx)$/.test(name)) yield p;
  }
}

/** Strip line + block comments (crude but sufficient: we only need to not match prose). */
function withoutComments(source: string): string {
  return source.replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|\s)\/\/.*$/gm, '');
}

describe('the immediately.run compatibility guards', () => {
  it('no module the platform loads contains import.meta (outside the two exempt files)', () => {
    const offenders: string[] = [];
    for (const path of tsFiles(join(process.cwd(), 'src'))) {
      // Normalize to the repo-relative `src/...` path (the walker yields absolute paths).
      const relFromSrc = `src/${path.split(/[/\\]src[/\\]/)[1]?.replace(/\\/g, '/') ?? ''}`;
      if (IMPORT_META_EXEMPT.has(relFromSrc)) continue;
      if (/import\.meta/.test(withoutComments(readFileSync(path, 'utf8')))) offenders.push(relFromSrc);
    }
    // Rationale: the platform transpiles ESM→CJS and evaluates classic scripts, where
    // import.meta is a parse-time SyntaxError that kills the whole module — caught live on
    // 2026-08-24 when the reckoner demo first ran on production.
    expect(offenders).toEqual([]);
  });

  it('no module STATICALLY value-imports the SDK task surface (DOCUMENT_NAVIGATOR_SPEC §4.1)', () => {
    const offenders: string[] = [];
    for (const path of tsFiles(join(process.cwd(), 'src'))) {
      const relFromSrc = `src/${path.split(/[/\\]src[/\\]/)[1]?.replace(/\\/g, '/') ?? ''}`;
      const source = withoutComments(readFileSync(path, 'utf8'));
      // `import type … from '@immediately-run/sdk[/tasks]'` is erased at compile time and
      // is fine; a VALUE import of the task surface is not. `await import(...)` is not a
      // static import statement and so never matches.
      const statics = source.match(/^\s*import\s+(?!type\b)[^;]*from\s*['"]@immediately-run\/sdk(?:\/tasks)?['"]/gm) ?? [];
      for (const stmt of statics) {
        // Only the task surface carries the load-time listener; the root barrel re-exports it.
        if (/@immediately-run\/sdk(\/tasks)?['"]$/.test(stmt.trim())) offenders.push(relFromSrc);
      }
    }
    // Rationale: `@immediately-run/sdk/tasks` registers a host listener at module
    // load — the side effect the §4.1/DN-R5 discipline keeps behind `await import()`
    // inside the handler (the pattern makeTransport already uses for workerUrl).
    // (Accuracy, review round 5: since SDK R3-421 / ≥0.57.3 the registration is
    // try/catch-wrapped and no longer throws off-host; pre-R3-421 it white-screened
    // plain `vite dev`, which is the history the discipline was written against.)
    // `mounts` is side-effect-clean and is imported normally in useMounts.ts.
    expect(offenders).toEqual([]);
  });
});

// G-DN-B10's reckoner half (R3-447): the manifest `invokes` declaration is the
// self-restriction that admits the edit-file task — an artifact no test read before,
// so deleting it left every suite green (the "ships dark, permanently" failure mode
// DN-R6 records). Pinned here, beside the other source-level platform contracts.
describe('the manifest declares what it invokes (DOCUMENT_NAVIGATOR_SPEC G-DN-B10)', () => {
  it('package.json declares invokes: edit-file at the contract version 1.0', () => {
    const pkg = JSON.parse(readFileSync(join(__dirname, '../../package.json'), 'utf8')) as {
      'immediately.run'?: { invokes?: { task: string; version: string }[] };
    };
    const invokes = pkg['immediately.run']?.invokes ?? [];
    const editFile = invokes.find((i) => i.task === 'edit-file');
    expect(editFile).toMatchObject({ task: 'edit-file', version: '1.0' });
  });

  // R3-754: `requests.net:fetch.required:false` is load-bearing the same way — the
  // host's M2 admission computes the REQUIRED-request delta against the binding's
  // snapshot and refuses the task invoke (consent-required, no overlay) when a
  // required request is missing from it; this app renders workbooks without
  // fetching. No test read the `requests` block before, so flipping the flag back
  // re-broke every task invoke with the suite green — the exact ships-dark failure
  // mode DN-R6 records, on the admission leg instead of the invokes leg.
  // (2026-09-29, rebase onto R3-768: the egress was REMOVED wholesale — the report
  // view fetches nothing — so the block is gone rather than flagged. The invariant
  // that matters to admission is "no REQUIRED net:fetch": absent or explicitly
  // non-required both satisfy it; `required: true` fails here.)
  it('package.json declares no REQUIRED net:fetch (the M2 admission leg, R3-754/R3-768)', () => {
    const pkg = JSON.parse(readFileSync(join(__dirname, '../../package.json'), 'utf8')) as {
      'immediately.run'?: { requests?: Record<string, { required?: boolean }> };
    };
    expect(pkg['immediately.run']?.requests?.['net:fetch']?.required ?? false).toBe(false);
  });
});
