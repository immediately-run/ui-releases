// Build the dependency graph from a workbook of registered cells (ARCHITECTURE_PLAN §4.2,
// F1/C-4). Each cell/test becomes a node; its declared inputs become internal edges (to
// other cells) or external inputs (feeds/fixtures/static/params). A `<worksheet>.*`
// wildcard is expanded to every cell of that worksheet at build time, so the conservative
// dependency set is **statically enumerable** — the invariant the SCC cycle check and the
// deadlock-freedom argument rest on.
//
// Two enumerability invariants are enforced fail-closed (C-4): (a) a worksheet may not be
// named a reserved namespace (`params`/`feeds`/…) — that would let a cell masquerade as a
// leaf input and hide a producer edge from the static SCC; (b) namespace tokens come from
// `parseInput` and are already compile-time literals, so nothing here resolves a wildcard
// from a runtime value.

import type {
  DependencyGraph,
  GraphDiagnostic,
  GraphNode,
  InputResolver,
  NodeDef,
  Workbook,
} from './types.ts';
import type { InputSpec } from '../stdlib/inputs.ts';
import { FEED_BUFFER_PREFIX } from './resolve.ts';

const RESERVED = new Set(['feeds', 'fixtures', 'static', 'params']);

/** The reserved local-input name under which a test node receives its subject's value. */
export const SUBJECT_INPUT = '$subject';

export function buildGraph(workbook: Workbook): DependencyGraph {
  const diagnostics: GraphDiagnostic[] = [];
  const worksheets = new Map<string, string[]>();
  const defsById = new Map<string, { worksheet: string; cell: string; def: NodeDef }>();

  // Pass 1 — enumerate nodes and per-worksheet cell lists.
  for (const [worksheet, cells] of Object.entries(workbook)) {
    if (RESERVED.has(worksheet)) {
      diagnostics.push({
        severity: 'error',
        id: worksheet,
        message: `worksheet "${worksheet}" collides with a reserved namespace; rename it.`,
      });
    }
    const names: string[] = [];
    for (const [cell, def] of Object.entries(cells)) {
      const id = `${worksheet}.${cell}`;
      names.push(id);
      defsById.set(id, { worksheet, cell, def });
    }
    worksheets.set(worksheet, names);
  }

  const has = (id: string): boolean => defsById.has(id);
  const nodes = new Map<string, GraphNode>();
  const externalInputs = new Set<string>();

  // Pass 2 — classify each node's inputs into internal edges + external inputs.
  for (const [id, { worksheet, cell, def }] of defsById) {
    const deps = new Set<string>();
    const externals = new Set<string>();
    const resolvers: InputResolver[] = [];

    for (const [name, spec] of Object.entries(def.inputs) as [string, InputSpec][]) {
      classifyInput(name, spec, { id, deps, externals, resolvers, worksheets, has, diagnostics });
    }

    // A test also depends on its subject cell (so it re-runs when the subject changes).
    if (def.kind === 'test') {
      const subject = def.subject;
      if (has(subject)) {
        deps.add(subject);
        resolvers.push({ name: SUBJECT_INPUT, kind: 'cell', nodeId: subject });
      } else {
        diagnostics.push({ severity: 'error', id, message: `test subject "${subject}" does not exist.` });
      }
    }

    for (const key of externals) externalInputs.add(key);
    nodes.set(id, {
      id,
      worksheet,
      cell,
      kind: def.kind,
      def,
      deps: [...deps],
      externals: [...externals],
      resolvers,
    });
  }

  return { nodes, worksheets, externalInputs, diagnostics };
}

/**
 * Every windowed input declared in the workbook (`{ feed, window }` sites), for the
 * edit-time buffer-coverage diagnostic (`checkBufferCoversWindows`). Structurally the
 * feed layer's `WindowDecl` — declared here so the engine never imports the feed layer.
 */
export function declaredWindows(graph: DependencyGraph): { feed: string; window: string; site: string }[] {
  const out: { feed: string; window: string; site: string }[] = [];
  for (const node of graph.nodes.values()) {
    for (const r of node.resolvers) {
      if (r.kind === 'windowed-feed') out.push({ feed: r.feed, window: r.window, site: node.id });
    }
  }
  return out;
}

interface ClassifyCtx {
  id: string;
  deps: Set<string>;
  externals: Set<string>;
  resolvers: InputResolver[];
  worksheets: Map<string, string[]>;
  has: (id: string) => boolean;
  diagnostics: GraphDiagnostic[];
}

function classifyInput(name: string, spec: InputSpec, ctx: ClassifyCtx): void {
  if (spec.feed !== undefined) {
    // The windowed-feed object form: the cell reads the feed's *retained rows* (not the
    // snapshot), so its external key is the buffer external the feed runtime publishes
    // alongside `feeds.<name>` — that key changing is what dirties the cell. The resolver
    // also reads the clock (`params.now`, falling back to the newest retained event time),
    // so a windowed input structurally depends on `params.now` too: a clock-only update must
    // advance the window. (Unconditional — whether the app supplies `params.now` is a
    // runtime fact the graph cannot know; an external that never changes never dirties.)
    ctx.externals.add(`${FEED_BUFFER_PREFIX}${spec.feed}`);
    ctx.externals.add('params.now');
    ctx.resolvers.push({ name, kind: 'windowed-feed', feed: spec.feed, window: spec.window!, by: spec.by! });
    return;
  }
  if (spec.namespace !== 'worksheet') {
    ctx.externals.add(spec.dependency);
    ctx.resolvers.push({ name, kind: 'external', key: spec.dependency });
    return;
  }

  const worksheet = spec.worksheet!;
  if (spec.wildcard) {
    const cells = ctx.worksheets.get(worksheet);
    if (cells === undefined) {
      ctx.diagnostics.push({
        severity: 'error',
        id: ctx.id,
        message: `input "${name}" references unknown worksheet "${worksheet}".`,
      });
      ctx.resolvers.push({ name, kind: 'wildcard', worksheet });
      return;
    }
    for (const dep of cells) if (dep !== ctx.id) ctx.deps.add(dep);
    ctx.resolvers.push({ name, kind: 'wildcard', worksheet });
    return;
  }

  const nodeId = `${worksheet}.${spec.cell}`;
  if (!ctx.has(nodeId)) {
    ctx.diagnostics.push({
      severity: 'error',
      id: ctx.id,
      message: `input "${name}" references unknown cell "${nodeId}".`,
    });
  } else {
    ctx.deps.add(nodeId);
  }
  ctx.resolvers.push({ name, kind: 'cell', nodeId });
}

/**
 * Resolvers for a declared-inputs map held by a *non-graph* consumer — the test runner's
 * fixture substitution (a test's declared inputs resolve against the same published state
 * a cell's do). Unresolvable references come back as diagnostics for the caller to surface;
 * they are the same errors `buildGraph` would emit for a cell. `graph` is the structural
 * minimum the classifier needs (an id→node map for cell-existence checks + the worksheet
 * lists), so the async engine can pass its descriptor maps directly.
 */
export function resolversFor(
  inputs: Record<string, InputSpec>,
  graph: { nodes: Map<string, unknown>; worksheets: Map<string, string[]> },
): { resolvers: InputResolver[]; diagnostics: string[] } {
  const diagnostics: GraphDiagnostic[] = [];
  const resolvers: InputResolver[] = [];
  for (const [name, spec] of Object.entries(inputs)) {
    classifyInput(name, spec, {
      id: '(test inputs)',
      deps: new Set(),
      externals: new Set(),
      resolvers,
      worksheets: graph.worksheets,
      has: (id) => graph.nodes.has(id),
      diagnostics,
    });
  }
  return { resolvers, diagnostics: diagnostics.map((d) => d.message) };
}
