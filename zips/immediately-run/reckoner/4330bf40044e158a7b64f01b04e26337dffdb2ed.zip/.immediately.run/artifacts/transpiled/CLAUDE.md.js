var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      blockquote: "blockquote",
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      li: "li",
      ol: "ol",
      p: "p",
      pre: "pre",
      strong: "strong",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "working-in-this-repo",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "working-in-this-repo"
      }), "Working in this repo"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["This is an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "immediately.run app"
      }), ": React + TypeScript that loads from GitHub and\ntranspiles in the browser (no server, no build step at runtime). Keep the rules\nbelow or the app breaks ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "only"
      }), " on immediately.run while still looking fine in\nlocal ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "vite dev"
      }), " — the most common silent failure."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "hard-rules-these-break-immediatelyrun-if-violated",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "hard-rules-these-break-immediatelyrun-if-violated"
      }), "Hard rules (these break immediately.run if violated)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/platform.tsx"
            }), " is the entry point immediately.run runs"]
          }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "package.json"
          }), " →\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "main"
          }), "); it does nothing but ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "boot({ children: <App /> })"
          }), ", so ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/App.tsx"
            }), " is\nstill where the app begins"]
          }), " and its default export is what renders. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "src/main.tsx"
          }), "\nis for local dev/build only and is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "ignored"
          }), " at runtime — never put CSS imports,\nproviders, or app logic in it."]
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
          children: ["The two entries stay APART on purpose: importing the SDK's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "boot"
          }), " reaches for the\nhost transport at module load, which throws under ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "vite dev"
          }), " where there is no host.\nSo ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "main.tsx"
          }), " must never import from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "@immediately-run/sdk"
          }), " at all, and code that\nneeds the SDK imports the narrow subpaths (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "/boot"
          }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "/routing"
          }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "/urlUtils"
          }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "/TinkerableContext"
          }), ") rather than the package root. Without ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "main"
          }), ", the host serves\nits own read-only boot default and the app owns no path space — every deep link\n404s (R3-553)."]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
            children: ["Import global CSS from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "App.tsx"
            })]
          }), ", not from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "main.tsx"
          }), ". Anything the\nrendered tree needs (CSS, context providers) must be reachable from\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "App.tsx"
          }), "."]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "A file that exports a React component exports ONLY components."
          }), " No mixing a\ncomponent with named exports of data/constants/helpers. (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "interface"
          }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "type"
          }), "\nare erased at compile time and are fine.) This is the React Fast Refresh rule;\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "npm run lint"
          }), " enforces it. Put data in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "src/data/"
          }), ", hooks in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "src/hooks/"
          }), ",\nutilities in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "src/lib/"
          }), "."]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "One component per file, default-exported"
          }), ", named for what it renders."]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
            children: ["CSS lives in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: ".css"
            }), " files imported from TypeScript"]
          }), " — not in giant\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "<style>"
          }), " blocks or inline ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "style={{}}"
          }), " for the bulk of styling."]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
            children: ["Fonts via CSS ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "@import"
            })]
          }), " as the first line of the CSS file, not ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "<link>"
          }), "\ntags in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "index.html"
          }), "."]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "Import local assets"
          }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "import logo from './assets/logo.png'"
          }), "); don't\nreference server paths that won't exist in the sandbox."]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "No Node / build-time-only APIs"
          }), " in the rendered tree — it runs in a browser\niframe. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "document"
          }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "window"
          }), ", and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "fetch"
          }), " are available. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "Web storage is\nnot"
          }), ": ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "localStorage"
          }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "sessionStorage"
          }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "indexedDB"
          }), " and the Cache API are\nall unavailable — apps run at an opaque origin (a sandboxed iframe without\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "allow-same-origin"
          }), "; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "BROWSER_CAPABILITIES_SPEC"
          }), " §1 in the docs repo), where\neven ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "reading"
          }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "localStorage"
          }), " throws ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "SecurityError"
          }), ", so a\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "typeof localStorage === 'undefined'"
          }), " guard does NOT work (the throw is on\naccess, not on the value). State goes to the mounts instead:"]
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
          children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Device-local, rebuildable state"
            }), " (caches, drafts, scroll positions,\ncheckpoints): the mount from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "await openLocalStore()"
            }), " in\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "@immediately-run/sdk"
            }), " — per device, never synced, evictable by the\nbrowser under storage pressure."]
          }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Synced state"
            }), ": ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "openSettings()"
            }), "."]
          }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
            children: ["Both need a signed-in user: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "openLocalStore()"
            }), " rejects ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "auth-required"
            }), "\nwhen signed out, so the app degrades to in-memory state rather than\ncrashing (platform security model rule 9). Treat persistence as optional\nand keep the app fully usable without it."]
          }), "\n"]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "MDX is only for long-form prose"
          }), " (articles, guides). Structured/repeated\ndata stays as typed arrays in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "src/data/"
          }), ". If you add ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: ".mdx"
          }), ", the Vite plugin\nand ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "src/mdx.d.ts"
          }), " shim are already wired up."]
        }), "\n"]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "loading-caching-on-immediatelyrun",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "loading-caching-on-immediatelyrun"
      }), "Loading & caching on immediately.run"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: ".github/workflows/cache.yml"
      }), " publishes a pre-cached zip of this repo to its own\nGitHub Pages on each push to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "main"
      }), ", so immediately.run loads fast and within\nanonymous rate limits. To enable it on a repo in your own account/org, turn Pages\non once — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Settings → Pages → Source: GitHub Actions"
      }), " — then push to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "main"
      }), "; no\ntokens or secrets. (immediately-run org repos self-provision Pages on the first\nrun via the org's internal deploy GitHub App, which external repos don't have and\ndon't need — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "cache.yml"
      }), " falls back to the manual step for them.) Don't move the\ncache to a different path or hostname — the client discovers it by convention at\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "https://<owner>.github.io/<repo>/cached_repositories/main.zip"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "\"immediately.run\": { \"requireLatest\": \"...\" }"
      }), " in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "package.json"
      }), " controls\nfreshness. It is a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "string enum"
      }), ", not a boolean: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "\"stale_ok\""
      }), " (always serve\nthe cache, fastest, offline-friendly), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "\"optimistic\""
      }), " (the default — serve\ncache, check in background), or ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "\"strict\""
      }), " (always run the newest commit, at\nthe cost of a freshness check on launch). Leave it unset unless\nto-the-commit freshness matters; the default is fast and works offline."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "design-system",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "design-system"
      }), "Design system"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["This brand is: cool near-black canvas · magenta↔violet signature gradient ·\nGabarito display type · Space Mono details · hairline borders · hard-offset hover\nshadows · sentence case · headlines end on a period · ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "no emoji"
      }), ". Dark is the\ndefault; a light theme is wired via ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "data-theme=\"light\""
      }), " on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "<html>"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Pull tokens from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "src/index.css"
          })]
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--bg"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--panel"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--ink"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--accent"
        }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--grad"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--r-lg"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "--shadow-card"
        }), ", the type families, etc.) instead of\nhard-coding colors, radii, or fonts."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["Apply the signature gradient to text with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "className=\"grad-text\""
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["For icons beyond the unicode set (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "→ ★ ● ☀ ☾"
        }), "), use\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "https://lucide.dev",
          children: "Lucide"
        }), " at 16–24px, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "currentColor"
        }), ". No emoji."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "finding-the-sdk-api-read-this-before-guessing-imports",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "finding-the-sdk-api-read-this-before-guessing-imports"
      }), "Finding the SDK API (read this before guessing imports)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Everything the platform offers comes from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "@immediately-run/sdk"
      }), ". Don't guess\nexport names or signatures — look them up. The package ships full API docs,\nfetchable in one request and optimized for both humans and coding agents:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "llms.txt"
          })
        }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "https://immediately-run.github.io/immediately-run-sdk/llms.txt",
          children: "https://immediately-run.github.io/immediately-run-sdk/llms.txt"
        }), " —\na concise map of every export grouped by module, with its kind, import path,\nand a one-line description. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Start here."
        })]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "api.json"
          })
        }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "https://immediately-run.github.io/immediately-run-sdk/api.json",
          children: "https://immediately-run.github.io/immediately-run-sdk/api.json"
        }), " —\nthe complete TypeDoc model (exact signatures, parameters, types) when you need\nmore than the one-liners."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "HTML reference"
        }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "https://immediately-run.github.io/immediately-run-sdk/",
          children: "https://immediately-run.github.io/immediately-run-sdk/"
        }), " —\nhuman-browsable."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Once installed, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "node_modules/@immediately-run/sdk"
      }), " ships ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: ".d.ts"
      }), " carrying the\nsame JSDoc, so your editor/agent reads the typed API inline with no network. All\nexports are importable from the package root (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "@immediately-run/sdk"
      }), ") or a\nper-module subpath (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "@immediately-run/sdk/hooks"
      }), ")."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "platform-security-model-what-your-app-can-and-cant-do",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "platform-security-model-what-your-app-can-and-cant-do"
      }), "Platform security model (what your app can and can't do)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Your app runs in a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "sandboxed iframe with an opaque origin"
      }), ". The rules below\nfollow from that and from the platform capability model\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "docs/specs/UI_AS_APPS_SPEC.md"
      }), " §8 in the docs repo). Violations don't just\nbreak your app — calls fail with typed errors, and trying to work around them\nreads as hostile. (Enforcement is rolling out per the spec's §10 ladder —\nitems 4, 6 and 8 describe machinery that is specified but not yet live; write\nnew code as if they're enforced and it will keep working as they land.)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["All platform interaction goes through ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "@immediately-run/sdk"
          }), "."]
        }), " There is\nno other channel: no shared storage with other apps, no reaching sibling\niframes, no postMessage of your own to the parent."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Never handle user credentials."
        }), " You will never see the user's GitHub\ntoken, API keys, or any secret — sign-in and privileged actions are\nhost-driven. Call protocol methods reactively, gated on\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "getAuthState().status === 'signed-in'"
        }), "; never store or request tokens."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The filesystem you see is the filesystem you got."
        }), " Mounts the host gives\nyou (your app's spaces, granted folders) are your whole world — outside\npaths don't exist, and a grant may be read-only. Don't probe for escapes\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".."
        }), ", absolute paths); writes to read-only mounts fail with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "EROFS"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Access to more data is asked for, not taken."
        }), " Need another space or\nfolder? Call the SDK request method and the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "user"
        }), " picks in host UI. Expect\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "{ ok: false, code: 'cancelled' | 'forbidden' }"
        }), " and handle it gracefully."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Handle typed errors everywhere."
        }), " Platform calls reply\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "{ ok: false, code, message }"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "forbidden"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "auth-required"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "cancelled"
        }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "invalid-params"
        }), ", …). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "forbidden"
        }), " means your app lacks that capability —\nthat's policy, not a bug to retry around."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Declare what you invoke and provide."
        }), " Cross-app tasks go in\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "package.json"
        }), " under ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "\"immediately.run\""
        }), ": ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "\"invokes\""
        }), " for task contracts\nyou call, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "\"provides\""
        }), " for ones you implement. Undeclared invocations are\nrejected."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Don't imitate host chrome."
        }), " Never render fake sign-in prompts, consent\ndialogs, or the platform's seam/header UI. The host draws those; imitations\nare treated as spoofing."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "If you embed an LLM agent, its tool list is your catalog."
        }), " Use the\nSDK-provided method catalog as the agent's tools — it is pre-filtered to\nyour app's grants, so the agent can't exceed what your app may do. Don't\nhand-roll tools that shell around the SDK."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Expect cancellation and absence."
        }), " Interactive flows can resolve\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "cancelled"
        }), "; capabilities can be absent on a fork of your app. Degrade\nfeatures, don't crash."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "editing-delegate-to-the-platform-editor",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "editing-delegate-to-the-platform-editor"
      }), "Editing: delegate to the platform editor"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Your app's default text/code/file editing experience is the platform editor,\nnot a bespoke in-app editor."
      }), " When the thing the user edits ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "is"
      }), " a file (a\nMarkdown/MDX note, a JSON config, a source module, a CSV), hand that file to the\nplatform's editing surface instead of shipping your own ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "<textarea>"
      }), " or code\neditor. This is the same instinct as not reimplementing sign-in or PR review:\nthere is already a good, forkable, mobile-capable, agent-readable editor — use it.\n(Full rationale and the proposed platform additions are in\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "docs/specs/EDITOR_FIRST_EDITING_SPEC.md"
      }), ".)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Edit a file in one of your mounts via the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "edit-file"
          }), " task."]
        }), " Delegate a\ncapability for exactly that one file; the host opens the editor and tears the\ndelegation down when done. No consent prompt — you're narrowing a grant you\nalready hold:", "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            className: "language-ts",
            children: "import { invokeTask, capFile } from '@immediately-run/sdk';\nawait invokeTask('edit-file', {\n  file: capFile({ mountId: 'space:abc', relPath: 'notes/idea.mdx' }, { mode: 'rw' }),\n});\n"
          })
        }), "\n", "This is exactly how the whiteboard's \"Open source\" button works."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Offer \"edit\" as an affordance on the item, not a mode of your app."
        }), " Select\nan object / focus a row → an edit icon that opens ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "that"
        }), " file. Keep your\nrun-mode UI free of editor chrome (run-mode comes first)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Gate the affordance on writability."
        }), " Show it only when the mount is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "rw"
        }), ";\nre-evaluate on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "onMountsChange"
        }), " and hide it on a role downgrade. Never show a\nbutton that comes back ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "read-only"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "forbidden"
        }), ", and never surface ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "EROFS"
        }), " as UX."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "A few typed fields is a form, not an editor."
        }), " An inspector that sets a\ncolor, tags, or a lock toggle should be inline UI. Reach for the platform\neditor for the free-form body / the whole file."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Build a real in-app editor only with a stated reason"
        }), " — the content isn't a\nfile the platform editor can edit (freehand drawing, a node graph,\ndirect-manipulation geometry), or a measured UX need the platform editor can't\nmeet. Write the reason down; convenience is not a reason."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Known gap (don't paper over it with a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "<textarea>"
          }), "):"]
        }), " opening a specific\nmounted file in the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "main"
        }), " editor (vs. the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "edit-file"
        }), " overlay) from a\nstandalone app isn't supported yet — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "EDITOR_FIRST_EDITING_SPEC.md"
        }), " §6\nDelta B; the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "edit-file"
        }), " overlay covers mounted files meanwhile. (The other\nhalf of the old gap list is CLOSED: since Delta A landed 2026-06-13, a\npresent-mode app CAN summon the edit experience on its own source via the\nSDK ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "requestEdit()"
        }), " — own-source edits land in the CoW overlay, and the\ncapability owner confirmed baseline-when-self-scoped on 2026-08-28.)"]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "verify-before-youre-done",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "verify-before-youre-done"
      }), "Verify before you're done"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-bash",
        children: "npm run build   # must pass with no type errors\nnpm run lint    # must pass — this is the cheapest proof the Fast Refresh rule holds\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Then eyeball the page (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "npm run dev"
      }), ") and click any interactive controls."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "debugging-on-immediatelyrun-not-just-vite-dev",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "debugging-on-immediatelyrun-not-just-vite-dev"
      }), "Debugging on immediately.run (not just ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "vite dev"
      }), ")"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "vite dev"
      }), " proves your app renders, but the failure mode this whole file warns about\n— ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "\"works locally, breaks on immediately.run\""
      }), " — only shows up ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "running inside the\nhost"
      }), ": the sandboxed iframe, the SDK channel, the capability gate. Debug there too."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Drive a real browser with Chrome DevTools MCP."
        }), " The ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "mcp__chrome-devtools__*"
        }), "\ntools navigate the page, take an accessibility ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "snapshot"
        }), " (element ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "uid"
        }), "s to\nclick/fill), run JS with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "evaluate_script"
          })
        }), ", and read the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "console"
        }), " +\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "network"
        }), " — which is where SDK ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "{ ok: false, code }"
        }), " replies and sandbox errors\nactually surface. Reproduce, then ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "list_console_messages"
        }), " /\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "list_network_requests"
        }), "; don't guess from the rendered DOM alone."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Run your app ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "on the host"
          }), ", with no commit, via the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "local"
          }), " provider."]
        }), " Mount\nyour working tree into the real host and edit live:", "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            className: "language-bash",
            children: "immediately.run dev . --origin https://local.immediately.run --json\n# → open the printed /edit/local/<name>-<hash8>/.../live#ir-endpoint=…&ir-token=… link\n"
          })
        }), "\n", "Edits on disk hot-reload in the host preview, so you exercise the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "real"
        }), " SDK +\ncapability path (consent prompts, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "forbidden"
        }), ", mounts) instead of a local stub. A\ndev-served app gets a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "fresh appKey"
        }), " with no prior grants — handy for testing\nyour first-run consent flow honestly. (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "@immediately-run/cli"
        }), ", Node ≥ 18, git\nrepo.)"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Always use ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "https://local.immediately.run"
          }), ", never ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "localhost"
          })]
        }), " — config is\nkeyed by hostname and only the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "*.immediately.run"
        }), " origin is fully wired\n(sandbox + backend + auth allowlist)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "A passkey / Touch-ID prompt can't be automated"
        }), " — the first secret unseal or\nsign-in raises a native dialog; hand that step to a human, or reload after it's\ncached."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: ["The platform repo also ships a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "window.__irTest"
        }), " host hook for scripting\nspace/share drills, but that is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "host-internal"
        }), " (dev builds of immediately.run\nitself) — not something your app uses or should rely on. The full platform-side\nworkflow lives in the docs repo's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "tutorials/browser_debugging/"
        }), "."]
      }), "\n"]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/CLAUDE.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiYmxvY2txdW90ZSIsImNvZGUiLCJlbSIsImgxIiwiaDIiLCJsaSIsIm9sIiwicCIsInByZSIsInN0cm9uZyIsInVsIiwiX3Byb3ZpZGVDb21wb25lbnRzIiwiY29tcG9uZW50cyIsIkhlYWRpbmdBbmNob3IiLCJfbWlzc2luZ01keFJlZmVyZW5jZSIsImpzeHMiLCJGcmFnbWVudCIsImNoaWxkcmVuIiwiaWQiLCJqc3giLCJocmVmIiwiY2xhc3NOYW1lIiwiTURYQ29udGVudCIsIndyYXBwZXIiLCJNRFhMYXlvdXQiLCJfYyIsImNvbXBvbmVudCIsInBsYWNlIiwiRXJyb3IiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJDTEFVREUubWQiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgYTogXCJhXCIsXG4gICAgYmxvY2txdW90ZTogXCJibG9ja3F1b3RlXCIsXG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgZW06IFwiZW1cIixcbiAgICBoMTogXCJoMVwiLFxuICAgIGgyOiBcImgyXCIsXG4gICAgbGk6IFwibGlcIixcbiAgICBvbDogXCJvbFwiLFxuICAgIHA6IFwicFwiLFxuICAgIHByZTogXCJwcmVcIixcbiAgICBzdHJvbmc6IFwic3Ryb25nXCIsXG4gICAgdWw6IFwidWxcIixcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH0sIHtIZWFkaW5nQW5jaG9yfSA9IF9jb21wb25lbnRzO1xuICBpZiAoIUhlYWRpbmdBbmNob3IpIF9taXNzaW5nTWR4UmVmZXJlbmNlKFwiSGVhZGluZ0FuY2hvclwiLCB0cnVlKTtcbiAgcmV0dXJuIDw+PF9jb21wb25lbnRzLmgxIGlkPVwid29ya2luZy1pbi10aGlzLXJlcG9cIj48SGVhZGluZ0FuY2hvciBpZD1cIndvcmtpbmctaW4tdGhpcy1yZXBvXCIgLz57XCJXb3JraW5nIGluIHRoaXMgcmVwb1wifTwvX2NvbXBvbmVudHMuaDE+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhpcyBpcyBhbiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImltbWVkaWF0ZWx5LnJ1biBhcHBcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCI6IFJlYWN0ICsgVHlwZVNjcmlwdCB0aGF0IGxvYWRzIGZyb20gR2l0SHViIGFuZFxcbnRyYW5zcGlsZXMgaW4gdGhlIGJyb3dzZXIgKG5vIHNlcnZlciwgbm8gYnVpbGQgc3RlcCBhdCBydW50aW1lKS4gS2VlcCB0aGUgcnVsZXNcXG5iZWxvdyBvciB0aGUgYXBwIGJyZWFrcyBcIn08X2NvbXBvbmVudHMuZW0+e1wib25seVwifTwvX2NvbXBvbmVudHMuZW0+e1wiIG9uIGltbWVkaWF0ZWx5LnJ1biB3aGlsZSBzdGlsbCBsb29raW5nIGZpbmUgaW5cXG5sb2NhbCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ2aXRlIGRldlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIHRoZSBtb3N0IGNvbW1vbiBzaWxlbnQgZmFpbHVyZS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwiaGFyZC1ydWxlcy10aGVzZS1icmVhay1pbW1lZGlhdGVseXJ1bi1pZi12aW9sYXRlZFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiaGFyZC1ydWxlcy10aGVzZS1icmVhay1pbW1lZGlhdGVseXJ1bi1pZi12aW9sYXRlZFwiIC8+e1wiSGFyZCBydWxlcyAodGhlc2UgYnJlYWsgaW1tZWRpYXRlbHkucnVuIGlmIHZpb2xhdGVkKVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPjxfY29tcG9uZW50cy5jb2RlPntcInNyYy9wbGF0Zm9ybS50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGlzIHRoZSBlbnRyeSBwb2ludCBpbW1lZGlhdGVseS5ydW4gcnVuc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicGFja2FnZS5qc29uXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDihpJcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJtYWluXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIik7IGl0IGRvZXMgbm90aGluZyBidXQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYm9vdCh7IGNoaWxkcmVuOiA8QXBwIC8+IH0pXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgc28gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz48X2NvbXBvbmVudHMuY29kZT57XCJzcmMvQXBwLnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaXNcXG5zdGlsbCB3aGVyZSB0aGUgYXBwIGJlZ2luc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBhbmQgaXRzIGRlZmF1bHQgZXhwb3J0IGlzIHdoYXQgcmVuZGVycy4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL21haW4udHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIlxcbmlzIGZvciBsb2NhbCBkZXYvYnVpbGQgb25seSBhbmQgaXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJpZ25vcmVkXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGF0IHJ1bnRpbWUg4oCUIG5ldmVyIHB1dCBDU1MgaW1wb3J0cyxcXG5wcm92aWRlcnMsIG9yIGFwcCBsb2dpYyBpbiBpdC5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIHR3byBlbnRyaWVzIHN0YXkgQVBBUlQgb24gcHVycG9zZTogaW1wb3J0aW5nIHRoZSBTREsncyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJib290XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiByZWFjaGVzIGZvciB0aGVcXG5ob3N0IHRyYW5zcG9ydCBhdCBtb2R1bGUgbG9hZCwgd2hpY2ggdGhyb3dzIHVuZGVyIFwifTxfY29tcG9uZW50cy5jb2RlPntcInZpdGUgZGV2XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB3aGVyZSB0aGVyZSBpcyBubyBob3N0LlxcblNvIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1haW4udHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBtdXN0IG5ldmVyIGltcG9ydCBmcm9tIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkBpbW1lZGlhdGVseS1ydW4vc2RrXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhdCBhbGwsIGFuZCBjb2RlIHRoYXRcXG5uZWVkcyB0aGUgU0RLIGltcG9ydHMgdGhlIG5hcnJvdyBzdWJwYXRocyAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiL2Jvb3RcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCIvcm91dGluZ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi91cmxVdGlsc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiL1RpbmtlcmFibGVDb250ZXh0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikgcmF0aGVyIHRoYW4gdGhlIHBhY2thZ2Ugcm9vdC4gV2l0aG91dCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJtYWluXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgdGhlIGhvc3Qgc2VydmVzXFxuaXRzIG93biByZWFkLW9ubHkgYm9vdCBkZWZhdWx0IGFuZCB0aGUgYXBwIG93bnMgbm8gcGF0aCBzcGFjZSDigJQgZXZlcnkgZGVlcCBsaW5rXFxuNDA0cyAoUjMtNTUzKS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJJbXBvcnQgZ2xvYmFsIENTUyBmcm9tIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkFwcC50c3hcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBub3QgZnJvbSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJtYWluLnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuIEFueXRoaW5nIHRoZVxcbnJlbmRlcmVkIHRyZWUgbmVlZHMgKENTUywgY29udGV4dCBwcm92aWRlcnMpIG11c3QgYmUgcmVhY2hhYmxlIGZyb21cXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJBcHAudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJBIGZpbGUgdGhhdCBleHBvcnRzIGEgUmVhY3QgY29tcG9uZW50IGV4cG9ydHMgT05MWSBjb21wb25lbnRzLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBObyBtaXhpbmcgYVxcbmNvbXBvbmVudCB3aXRoIG5hbWVkIGV4cG9ydHMgb2YgZGF0YS9jb25zdGFudHMvaGVscGVycy4gKFwifTxfY29tcG9uZW50cy5jb2RlPntcImludGVyZmFjZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widHlwZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG5hcmUgZXJhc2VkIGF0IGNvbXBpbGUgdGltZSBhbmQgYXJlIGZpbmUuKSBUaGlzIGlzIHRoZSBSZWFjdCBGYXN0IFJlZnJlc2ggcnVsZTtcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJucG0gcnVuIGxpbnRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGVuZm9yY2VzIGl0LiBQdXQgZGF0YSBpbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvZGF0YS9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBob29rcyBpbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvaG9va3MvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIixcXG51dGlsaXRpZXMgaW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2xpYi9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIk9uZSBjb21wb25lbnQgcGVyIGZpbGUsIGRlZmF1bHQtZXhwb3J0ZWRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIsIG5hbWVkIGZvciB3aGF0IGl0IHJlbmRlcnMuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQ1NTIGxpdmVzIGluIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi5jc3NcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGZpbGVzIGltcG9ydGVkIGZyb20gVHlwZVNjcmlwdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgbm90IGluIGdpYW50XFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiPHN0eWxlPlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYmxvY2tzIG9yIGlubGluZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzdHlsZT17e319XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBmb3IgdGhlIGJ1bGsgb2Ygc3R5bGluZy5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJGb250cyB2aWEgQ1NTIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkBpbXBvcnRcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGFzIHRoZSBmaXJzdCBsaW5lIG9mIHRoZSBDU1MgZmlsZSwgbm90IFwifTxfY29tcG9uZW50cy5jb2RlPntcIjxsaW5rPlwifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG50YWdzIGluIFwifTxfY29tcG9uZW50cy5jb2RlPntcImluZGV4Lmh0bWxcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkltcG9ydCBsb2NhbCBhc3NldHNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcImltcG9ydCBsb2dvIGZyb20gJy4vYXNzZXRzL2xvZ28ucG5nJ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpOyBkb24ndFxcbnJlZmVyZW5jZSBzZXJ2ZXIgcGF0aHMgdGhhdCB3b24ndCBleGlzdCBpbiB0aGUgc2FuZGJveC5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJObyBOb2RlIC8gYnVpbGQtdGltZS1vbmx5IEFQSXNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgaW4gdGhlIHJlbmRlcmVkIHRyZWUg4oCUIGl0IHJ1bnMgaW4gYSBicm93c2VyXFxuaWZyYW1lLiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJkb2N1bWVudFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIndpbmRvd1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGFuZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmZXRjaFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYXJlIGF2YWlsYWJsZS4gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJXZWIgc3RvcmFnZSBpc1xcbm5vdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIjogXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibG9jYWxTdG9yYWdlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic2Vzc2lvblN0b3JhZ2VcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJpbmRleGVkREJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFuZCB0aGUgQ2FjaGUgQVBJIGFyZVxcbmFsbCB1bmF2YWlsYWJsZSDigJQgYXBwcyBydW4gYXQgYW4gb3BhcXVlIG9yaWdpbiAoYSBzYW5kYm94ZWQgaWZyYW1lIHdpdGhvdXRcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJhbGxvdy1zYW1lLW9yaWdpblwifTwvX2NvbXBvbmVudHMuY29kZT57XCI7IFwifTxfY29tcG9uZW50cy5jb2RlPntcIkJST1dTRVJfQ0FQQUJJTElUSUVTX1NQRUNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIMKnMSBpbiB0aGUgZG9jcyByZXBvKSwgd2hlcmVcXG5ldmVuIFwifTxfY29tcG9uZW50cy5lbT57XCJyZWFkaW5nXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibG9jYWxTdG9yYWdlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB0aHJvd3MgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiU2VjdXJpdHlFcnJvclwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIHNvIGFcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJ0eXBlb2YgbG9jYWxTdG9yYWdlID09PSAndW5kZWZpbmVkJ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZ3VhcmQgZG9lcyBOT1Qgd29yayAodGhlIHRocm93IGlzIG9uXFxuYWNjZXNzLCBub3Qgb24gdGhlIHZhbHVlKS4gU3RhdGUgZ29lcyB0byB0aGUgbW91bnRzIGluc3RlYWQ6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJEZXZpY2UtbG9jYWwsIHJlYnVpbGRhYmxlIHN0YXRlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChjYWNoZXMsIGRyYWZ0cywgc2Nyb2xsIHBvc2l0aW9ucyxcXG5jaGVja3BvaW50cyk6IHRoZSBtb3VudCBmcm9tIFwifTxfY29tcG9uZW50cy5jb2RlPntcImF3YWl0IG9wZW5Mb2NhbFN0b3JlKClcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGluXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQGltbWVkaWF0ZWx5LXJ1bi9zZGtcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCBwZXIgZGV2aWNlLCBuZXZlciBzeW5jZWQsIGV2aWN0YWJsZSBieSB0aGVcXG5icm93c2VyIHVuZGVyIHN0b3JhZ2UgcHJlc3N1cmUuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJTeW5jZWQgc3RhdGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCI6IFwifTxfY29tcG9uZW50cy5jb2RlPntcIm9wZW5TZXR0aW5ncygpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJCb3RoIG5lZWQgYSBzaWduZWQtaW4gdXNlcjogXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wib3BlbkxvY2FsU3RvcmUoKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcmVqZWN0cyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJhdXRoLXJlcXVpcmVkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIlxcbndoZW4gc2lnbmVkIG91dCwgc28gdGhlIGFwcCBkZWdyYWRlcyB0byBpbi1tZW1vcnkgc3RhdGUgcmF0aGVyIHRoYW5cXG5jcmFzaGluZyAocGxhdGZvcm0gc2VjdXJpdHkgbW9kZWwgcnVsZSA5KS4gVHJlYXQgcGVyc2lzdGVuY2UgYXMgb3B0aW9uYWxcXG5hbmQga2VlcCB0aGUgYXBwIGZ1bGx5IHVzYWJsZSB3aXRob3V0IGl0LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIk1EWCBpcyBvbmx5IGZvciBsb25nLWZvcm0gcHJvc2VcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKGFydGljbGVzLCBndWlkZXMpLiBTdHJ1Y3R1cmVkL3JlcGVhdGVkXFxuZGF0YSBzdGF5cyBhcyB0eXBlZCBhcnJheXMgaW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2RhdGEvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi4gSWYgeW91IGFkZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCIubWR4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgdGhlIFZpdGUgcGx1Z2luXFxuYW5kIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9tZHguZC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgc2hpbSBhcmUgYWxyZWFkeSB3aXJlZCB1cC5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cImxvYWRpbmctY2FjaGluZy1vbi1pbW1lZGlhdGVseXJ1blwiPjxIZWFkaW5nQW5jaG9yIGlkPVwibG9hZGluZy1jYWNoaW5nLW9uLWltbWVkaWF0ZWx5cnVuXCIgLz57XCJMb2FkaW5nICYgY2FjaGluZyBvbiBpbW1lZGlhdGVseS5ydW5cIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5jb2RlPntcIi5naXRodWIvd29ya2Zsb3dzL2NhY2hlLnltbFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcHVibGlzaGVzIGEgcHJlLWNhY2hlZCB6aXAgb2YgdGhpcyByZXBvIHRvIGl0cyBvd25cXG5HaXRIdWIgUGFnZXMgb24gZWFjaCBwdXNoIHRvIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1haW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBzbyBpbW1lZGlhdGVseS5ydW4gbG9hZHMgZmFzdCBhbmQgd2l0aGluXFxuYW5vbnltb3VzIHJhdGUgbGltaXRzLiBUbyBlbmFibGUgaXQgb24gYSByZXBvIGluIHlvdXIgb3duIGFjY291bnQvb3JnLCB0dXJuIFBhZ2VzXFxub24gb25jZSDigJQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJTZXR0aW5ncyDihpIgUGFnZXMg4oaSIFNvdXJjZTogR2l0SHViIEFjdGlvbnNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHRoZW4gcHVzaCB0byBcIn08X2NvbXBvbmVudHMuY29kZT57XCJtYWluXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjsgbm9cXG50b2tlbnMgb3Igc2VjcmV0cy4gKGltbWVkaWF0ZWx5LXJ1biBvcmcgcmVwb3Mgc2VsZi1wcm92aXNpb24gUGFnZXMgb24gdGhlIGZpcnN0XFxucnVuIHZpYSB0aGUgb3JnJ3MgaW50ZXJuYWwgZGVwbG95IEdpdEh1YiBBcHAsIHdoaWNoIGV4dGVybmFsIHJlcG9zIGRvbid0IGhhdmUgYW5kXFxuZG9uJ3QgbmVlZCDigJQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2FjaGUueW1sXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBmYWxscyBiYWNrIHRvIHRoZSBtYW51YWwgc3RlcCBmb3IgdGhlbS4pIERvbid0IG1vdmUgdGhlXFxuY2FjaGUgdG8gYSBkaWZmZXJlbnQgcGF0aCBvciBob3N0bmFtZSDigJQgdGhlIGNsaWVudCBkaXNjb3ZlcnMgaXQgYnkgY29udmVudGlvbiBhdFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcImh0dHBzOi8vPG93bmVyPi5naXRodWIuaW8vPHJlcG8+L2NhY2hlZF9yZXBvc2l0b3JpZXMvbWFpbi56aXBcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuY29kZT57XCJcXFwiaW1tZWRpYXRlbHkucnVuXFxcIjogeyBcXFwicmVxdWlyZUxhdGVzdFxcXCI6IFxcXCIuLi5cXFwiIH1cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGluIFwifTxfY29tcG9uZW50cy5jb2RlPntcInBhY2thZ2UuanNvblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgY29udHJvbHNcXG5mcmVzaG5lc3MuIEl0IGlzIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJzdHJpbmcgZW51bVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgbm90IGEgYm9vbGVhbjogXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiXFxcInN0YWxlX29rXFxcIlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKGFsd2F5cyBzZXJ2ZVxcbnRoZSBjYWNoZSwgZmFzdGVzdCwgb2ZmbGluZS1mcmllbmRseSksIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlxcXCJvcHRpbWlzdGljXFxcIlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKHRoZSBkZWZhdWx0IOKAlCBzZXJ2ZVxcbmNhY2hlLCBjaGVjayBpbiBiYWNrZ3JvdW5kKSwgb3IgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiXFxcInN0cmljdFxcXCJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChhbHdheXMgcnVuIHRoZSBuZXdlc3QgY29tbWl0LCBhdFxcbnRoZSBjb3N0IG9mIGEgZnJlc2huZXNzIGNoZWNrIG9uIGxhdW5jaCkuIExlYXZlIGl0IHVuc2V0IHVubGVzc1xcbnRvLXRoZS1jb21taXQgZnJlc2huZXNzIG1hdHRlcnM7IHRoZSBkZWZhdWx0IGlzIGZhc3QgYW5kIHdvcmtzIG9mZmxpbmUuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cImRlc2lnbi1zeXN0ZW1cIj48SGVhZGluZ0FuY2hvciBpZD1cImRlc2lnbi1zeXN0ZW1cIiAvPntcIkRlc2lnbiBzeXN0ZW1cIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoaXMgYnJhbmQgaXM6IGNvb2wgbmVhci1ibGFjayBjYW52YXMgwrcgbWFnZW50YeKGlHZpb2xldCBzaWduYXR1cmUgZ3JhZGllbnQgwrdcXG5HYWJhcml0byBkaXNwbGF5IHR5cGUgwrcgU3BhY2UgTW9ubyBkZXRhaWxzIMK3IGhhaXJsaW5lIGJvcmRlcnMgwrcgaGFyZC1vZmZzZXQgaG92ZXJcXG5zaGFkb3dzIMK3IHNlbnRlbmNlIGNhc2UgwrcgaGVhZGxpbmVzIGVuZCBvbiBhIHBlcmlvZCDCtyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vIGVtb2ppXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLiBEYXJrIGlzIHRoZVxcbmRlZmF1bHQ7IGEgbGlnaHQgdGhlbWUgaXMgd2lyZWQgdmlhIFwifTxfY29tcG9uZW50cy5jb2RlPntcImRhdGEtdGhlbWU9XFxcImxpZ2h0XFxcIlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgb24gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiPGh0bWw+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlB1bGwgdG9rZW5zIGZyb20gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2luZGV4LmNzc1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnN0cm9uZz57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIi0tYmdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCItLXBhbmVsXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1pbmtcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCItLWFjY2VudFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1ncmFkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1yLWxnXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1zaGFkb3ctY2FyZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIHRoZSB0eXBlIGZhbWlsaWVzLCBldGMuKSBpbnN0ZWFkIG9mXFxuaGFyZC1jb2RpbmcgY29sb3JzLCByYWRpaSwgb3IgZm9udHMuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiQXBwbHkgdGhlIHNpZ25hdHVyZSBncmFkaWVudCB0byB0ZXh0IHdpdGggXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2xhc3NOYW1lPVxcXCJncmFkLXRleHRcXFwiXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJGb3IgaWNvbnMgYmV5b25kIHRoZSB1bmljb2RlIHNldCAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wi4oaSIOKYhSDil48g4piAIOKYvlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLCB1c2VcXG5cIn08X2NvbXBvbmVudHMuYSBocmVmPVwiaHR0cHM6Ly9sdWNpZGUuZGV2XCI+e1wiTHVjaWRlXCJ9PC9fY29tcG9uZW50cy5hPntcIiBhdCAxNuKAkzI0cHgsIFwifTxfY29tcG9uZW50cy5jb2RlPntcImN1cnJlbnRDb2xvclwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuIE5vIGVtb2ppLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJmaW5kaW5nLXRoZS1zZGstYXBpLXJlYWQtdGhpcy1iZWZvcmUtZ3Vlc3NpbmctaW1wb3J0c1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwiZmluZGluZy10aGUtc2RrLWFwaS1yZWFkLXRoaXMtYmVmb3JlLWd1ZXNzaW5nLWltcG9ydHNcIiAvPntcIkZpbmRpbmcgdGhlIFNESyBBUEkgKHJlYWQgdGhpcyBiZWZvcmUgZ3Vlc3NpbmcgaW1wb3J0cylcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkV2ZXJ5dGhpbmcgdGhlIHBsYXRmb3JtIG9mZmVycyBjb21lcyBmcm9tIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkBpbW1lZGlhdGVseS1ydW4vc2RrXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi4gRG9uJ3QgZ3Vlc3NcXG5leHBvcnQgbmFtZXMgb3Igc2lnbmF0dXJlcyDigJQgbG9vayB0aGVtIHVwLiBUaGUgcGFja2FnZSBzaGlwcyBmdWxsIEFQSSBkb2NzLFxcbmZldGNoYWJsZSBpbiBvbmUgcmVxdWVzdCBhbmQgb3B0aW1pemVkIGZvciBib3RoIGh1bWFucyBhbmQgY29kaW5nIGFnZW50czpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPjxfY29tcG9uZW50cy5jb2RlPntcImxsbXMudHh0XCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cImh0dHBzOi8vaW1tZWRpYXRlbHktcnVuLmdpdGh1Yi5pby9pbW1lZGlhdGVseS1ydW4tc2RrL2xsbXMudHh0XCI+e1wiaHR0cHM6Ly9pbW1lZGlhdGVseS1ydW4uZ2l0aHViLmlvL2ltbWVkaWF0ZWx5LXJ1bi1zZGsvbGxtcy50eHRcIn08L19jb21wb25lbnRzLmE+e1wiIOKAlFxcbmEgY29uY2lzZSBtYXAgb2YgZXZlcnkgZXhwb3J0IGdyb3VwZWQgYnkgbW9kdWxlLCB3aXRoIGl0cyBraW5kLCBpbXBvcnQgcGF0aCxcXG5hbmQgYSBvbmUtbGluZSBkZXNjcmlwdGlvbi4gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJTdGFydCBoZXJlLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+PF9jb21wb25lbnRzLmNvZGU+e1wiYXBpLmpzb25cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBcIn08X2NvbXBvbmVudHMuYSBocmVmPVwiaHR0cHM6Ly9pbW1lZGlhdGVseS1ydW4uZ2l0aHViLmlvL2ltbWVkaWF0ZWx5LXJ1bi1zZGsvYXBpLmpzb25cIj57XCJodHRwczovL2ltbWVkaWF0ZWx5LXJ1bi5naXRodWIuaW8vaW1tZWRpYXRlbHktcnVuLXNkay9hcGkuanNvblwifTwvX2NvbXBvbmVudHMuYT57XCIg4oCUXFxudGhlIGNvbXBsZXRlIFR5cGVEb2MgbW9kZWwgKGV4YWN0IHNpZ25hdHVyZXMsIHBhcmFtZXRlcnMsIHR5cGVzKSB3aGVuIHlvdSBuZWVkXFxubW9yZSB0aGFuIHRoZSBvbmUtbGluZXJzLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiSFRNTCByZWZlcmVuY2VcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIFwifTxfY29tcG9uZW50cy5hIGhyZWY9XCJodHRwczovL2ltbWVkaWF0ZWx5LXJ1bi5naXRodWIuaW8vaW1tZWRpYXRlbHktcnVuLXNkay9cIj57XCJodHRwczovL2ltbWVkaWF0ZWx5LXJ1bi5naXRodWIuaW8vaW1tZWRpYXRlbHktcnVuLXNkay9cIn08L19jb21wb25lbnRzLmE+e1wiIOKAlFxcbmh1bWFuLWJyb3dzYWJsZS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiT25jZSBpbnN0YWxsZWQsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm5vZGVfbW9kdWxlcy9AaW1tZWRpYXRlbHktcnVuL3Nka1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgc2hpcHMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLmQudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNhcnJ5aW5nIHRoZVxcbnNhbWUgSlNEb2MsIHNvIHlvdXIgZWRpdG9yL2FnZW50IHJlYWRzIHRoZSB0eXBlZCBBUEkgaW5saW5lIHdpdGggbm8gbmV0d29yay4gQWxsXFxuZXhwb3J0cyBhcmUgaW1wb3J0YWJsZSBmcm9tIHRoZSBwYWNrYWdlIHJvb3QgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIkBpbW1lZGlhdGVseS1ydW4vc2RrXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikgb3IgYVxcbnBlci1tb2R1bGUgc3VicGF0aCAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQGltbWVkaWF0ZWx5LXJ1bi9zZGsvaG9va3NcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwicGxhdGZvcm0tc2VjdXJpdHktbW9kZWwtd2hhdC15b3VyLWFwcC1jYW4tYW5kLWNhbnQtZG9cIj48SGVhZGluZ0FuY2hvciBpZD1cInBsYXRmb3JtLXNlY3VyaXR5LW1vZGVsLXdoYXQteW91ci1hcHAtY2FuLWFuZC1jYW50LWRvXCIgLz57XCJQbGF0Zm9ybSBzZWN1cml0eSBtb2RlbCAod2hhdCB5b3VyIGFwcCBjYW4gYW5kIGNhbid0IGRvKVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiWW91ciBhcHAgcnVucyBpbiBhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wic2FuZGJveGVkIGlmcmFtZSB3aXRoIGFuIG9wYXF1ZSBvcmlnaW5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIuIFRoZSBydWxlcyBiZWxvd1xcbmZvbGxvdyBmcm9tIHRoYXQgYW5kIGZyb20gdGhlIHBsYXRmb3JtIGNhcGFiaWxpdHkgbW9kZWxcXG4oXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZG9jcy9zcGVjcy9VSV9BU19BUFBTX1NQRUMubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIMKnOCBpbiB0aGUgZG9jcyByZXBvKS4gVmlvbGF0aW9ucyBkb24ndCBqdXN0XFxuYnJlYWsgeW91ciBhcHAg4oCUIGNhbGxzIGZhaWwgd2l0aCB0eXBlZCBlcnJvcnMsIGFuZCB0cnlpbmcgdG8gd29yayBhcm91bmQgdGhlbVxcbnJlYWRzIGFzIGhvc3RpbGUuIChFbmZvcmNlbWVudCBpcyByb2xsaW5nIG91dCBwZXIgdGhlIHNwZWMncyDCpzEwIGxhZGRlciDigJRcXG5pdGVtcyA0LCA2IGFuZCA4IGRlc2NyaWJlIG1hY2hpbmVyeSB0aGF0IGlzIHNwZWNpZmllZCBidXQgbm90IHlldCBsaXZlOyB3cml0ZVxcbm5ldyBjb2RlIGFzIGlmIHRoZXkncmUgZW5mb3JjZWQgYW5kIGl0IHdpbGwga2VlcCB3b3JraW5nIGFzIHRoZXkgbGFuZC4pXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJBbGwgcGxhdGZvcm0gaW50ZXJhY3Rpb24gZ29lcyB0aHJvdWdoIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkBpbW1lZGlhdGVseS1ydW4vc2RrXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhlcmUgaXNcXG5ubyBvdGhlciBjaGFubmVsOiBubyBzaGFyZWQgc3RvcmFnZSB3aXRoIG90aGVyIGFwcHMsIG5vIHJlYWNoaW5nIHNpYmxpbmdcXG5pZnJhbWVzLCBubyBwb3N0TWVzc2FnZSBvZiB5b3VyIG93biB0byB0aGUgcGFyZW50LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiTmV2ZXIgaGFuZGxlIHVzZXIgY3JlZGVudGlhbHMuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFlvdSB3aWxsIG5ldmVyIHNlZSB0aGUgdXNlcidzIEdpdEh1YlxcbnRva2VuLCBBUEkga2V5cywgb3IgYW55IHNlY3JldCDigJQgc2lnbi1pbiBhbmQgcHJpdmlsZWdlZCBhY3Rpb25zIGFyZVxcbmhvc3QtZHJpdmVuLiBDYWxsIHByb3RvY29sIG1ldGhvZHMgcmVhY3RpdmVseSwgZ2F0ZWQgb25cXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJnZXRBdXRoU3RhdGUoKS5zdGF0dXMgPT09ICdzaWduZWQtaW4nXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjsgbmV2ZXIgc3RvcmUgb3IgcmVxdWVzdCB0b2tlbnMuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgZmlsZXN5c3RlbSB5b3Ugc2VlIGlzIHRoZSBmaWxlc3lzdGVtIHlvdSBnb3QuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIE1vdW50cyB0aGUgaG9zdCBnaXZlc1xcbnlvdSAoeW91ciBhcHAncyBzcGFjZXMsIGdyYW50ZWQgZm9sZGVycykgYXJlIHlvdXIgd2hvbGUgd29ybGQg4oCUIG91dHNpZGVcXG5wYXRocyBkb24ndCBleGlzdCwgYW5kIGEgZ3JhbnQgbWF5IGJlIHJlYWQtb25seS4gRG9uJ3QgcHJvYmUgZm9yIGVzY2FwZXNcXG4oXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLi5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBhYnNvbHV0ZSBwYXRocyk7IHdyaXRlcyB0byByZWFkLW9ubHkgbW91bnRzIGZhaWwgd2l0aCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJFUk9GU1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJBY2Nlc3MgdG8gbW9yZSBkYXRhIGlzIGFza2VkIGZvciwgbm90IHRha2VuLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBOZWVkIGFub3RoZXIgc3BhY2Ugb3JcXG5mb2xkZXI/IENhbGwgdGhlIFNESyByZXF1ZXN0IG1ldGhvZCBhbmQgdGhlIFwifTxfY29tcG9uZW50cy5lbT57XCJ1c2VyXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgcGlja3MgaW4gaG9zdCBVSS4gRXhwZWN0XFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wieyBvazogZmFsc2UsIGNvZGU6ICdjYW5jZWxsZWQnIHwgJ2ZvcmJpZGRlbicgfVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYW5kIGhhbmRsZSBpdCBncmFjZWZ1bGx5LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiSGFuZGxlIHR5cGVkIGVycm9ycyBldmVyeXdoZXJlLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBQbGF0Zm9ybSBjYWxscyByZXBseVxcblwifTxfY29tcG9uZW50cy5jb2RlPntcInsgb2s6IGZhbHNlLCBjb2RlLCBtZXNzYWdlIH1cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJmb3JiaWRkZW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJhdXRoLXJlcXVpcmVkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2FuY2VsbGVkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIixcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJpbnZhbGlkLXBhcmFtc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIOKApikuIFwifTxfY29tcG9uZW50cy5jb2RlPntcImZvcmJpZGRlblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgbWVhbnMgeW91ciBhcHAgbGFja3MgdGhhdCBjYXBhYmlsaXR5IOKAlFxcbnRoYXQncyBwb2xpY3ksIG5vdCBhIGJ1ZyB0byByZXRyeSBhcm91bmQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJEZWNsYXJlIHdoYXQgeW91IGludm9rZSBhbmQgcHJvdmlkZS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgQ3Jvc3MtYXBwIHRhc2tzIGdvIGluXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicGFja2FnZS5qc29uXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB1bmRlciBcIn08X2NvbXBvbmVudHMuY29kZT57XCJcXFwiaW1tZWRpYXRlbHkucnVuXFxcIlwifTwvX2NvbXBvbmVudHMuY29kZT57XCI6IFwifTxfY29tcG9uZW50cy5jb2RlPntcIlxcXCJpbnZva2VzXFxcIlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZm9yIHRhc2sgY29udHJhY3RzXFxueW91IGNhbGwsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlxcXCJwcm92aWRlc1xcXCJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGZvciBvbmVzIHlvdSBpbXBsZW1lbnQuIFVuZGVjbGFyZWQgaW52b2NhdGlvbnMgYXJlXFxucmVqZWN0ZWQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJEb24ndCBpbWl0YXRlIGhvc3QgY2hyb21lLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBOZXZlciByZW5kZXIgZmFrZSBzaWduLWluIHByb21wdHMsIGNvbnNlbnRcXG5kaWFsb2dzLCBvciB0aGUgcGxhdGZvcm0ncyBzZWFtL2hlYWRlciBVSS4gVGhlIGhvc3QgZHJhd3MgdGhvc2U7IGltaXRhdGlvbnNcXG5hcmUgdHJlYXRlZCBhcyBzcG9vZmluZy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIklmIHlvdSBlbWJlZCBhbiBMTE0gYWdlbnQsIGl0cyB0b29sIGxpc3QgaXMgeW91ciBjYXRhbG9nLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBVc2UgdGhlXFxuU0RLLXByb3ZpZGVkIG1ldGhvZCBjYXRhbG9nIGFzIHRoZSBhZ2VudCdzIHRvb2xzIOKAlCBpdCBpcyBwcmUtZmlsdGVyZWQgdG9cXG55b3VyIGFwcCdzIGdyYW50cywgc28gdGhlIGFnZW50IGNhbid0IGV4Y2VlZCB3aGF0IHlvdXIgYXBwIG1heSBkby4gRG9uJ3RcXG5oYW5kLXJvbGwgdG9vbHMgdGhhdCBzaGVsbCBhcm91bmQgdGhlIFNESy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkV4cGVjdCBjYW5jZWxsYXRpb24gYW5kIGFic2VuY2UuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIEludGVyYWN0aXZlIGZsb3dzIGNhbiByZXNvbHZlXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2FuY2VsbGVkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjsgY2FwYWJpbGl0aWVzIGNhbiBiZSBhYnNlbnQgb24gYSBmb3JrIG9mIHlvdXIgYXBwLiBEZWdyYWRlXFxuZmVhdHVyZXMsIGRvbid0IGNyYXNoLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJlZGl0aW5nLWRlbGVnYXRlLXRvLXRoZS1wbGF0Zm9ybS1lZGl0b3JcIj48SGVhZGluZ0FuY2hvciBpZD1cImVkaXRpbmctZGVsZWdhdGUtdG8tdGhlLXBsYXRmb3JtLWVkaXRvclwiIC8+e1wiRWRpdGluZzogZGVsZWdhdGUgdG8gdGhlIHBsYXRmb3JtIGVkaXRvclwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJZb3VyIGFwcCdzIGRlZmF1bHQgdGV4dC9jb2RlL2ZpbGUgZWRpdGluZyBleHBlcmllbmNlIGlzIHRoZSBwbGF0Zm9ybSBlZGl0b3IsXFxubm90IGEgYmVzcG9rZSBpbi1hcHAgZWRpdG9yLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBXaGVuIHRoZSB0aGluZyB0aGUgdXNlciBlZGl0cyBcIn08X2NvbXBvbmVudHMuZW0+e1wiaXNcIn08L19jb21wb25lbnRzLmVtPntcIiBhIGZpbGUgKGFcXG5NYXJrZG93bi9NRFggbm90ZSwgYSBKU09OIGNvbmZpZywgYSBzb3VyY2UgbW9kdWxlLCBhIENTViksIGhhbmQgdGhhdCBmaWxlIHRvIHRoZVxcbnBsYXRmb3JtJ3MgZWRpdGluZyBzdXJmYWNlIGluc3RlYWQgb2Ygc2hpcHBpbmcgeW91ciBvd24gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiPHRleHRhcmVhPlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgb3IgY29kZVxcbmVkaXRvci4gVGhpcyBpcyB0aGUgc2FtZSBpbnN0aW5jdCBhcyBub3QgcmVpbXBsZW1lbnRpbmcgc2lnbi1pbiBvciBQUiByZXZpZXc6XFxudGhlcmUgaXMgYWxyZWFkeSBhIGdvb2QsIGZvcmthYmxlLCBtb2JpbGUtY2FwYWJsZSwgYWdlbnQtcmVhZGFibGUgZWRpdG9yIOKAlCB1c2UgaXQuXFxuKEZ1bGwgcmF0aW9uYWxlIGFuZCB0aGUgcHJvcG9zZWQgcGxhdGZvcm0gYWRkaXRpb25zIGFyZSBpblxcblwifTxfY29tcG9uZW50cy5jb2RlPntcImRvY3Mvc3BlY3MvRURJVE9SX0ZJUlNUX0VESVRJTkdfU1BFQy5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuKVwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMub2w+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRWRpdCBhIGZpbGUgaW4gb25lIG9mIHlvdXIgbW91bnRzIHZpYSB0aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZWRpdC1maWxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB0YXNrLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBEZWxlZ2F0ZSBhXFxuY2FwYWJpbGl0eSBmb3IgZXhhY3RseSB0aGF0IG9uZSBmaWxlOyB0aGUgaG9zdCBvcGVucyB0aGUgZWRpdG9yIGFuZCB0ZWFycyB0aGVcXG5kZWxlZ2F0aW9uIGRvd24gd2hlbiBkb25lLiBObyBjb25zZW50IHByb21wdCDigJQgeW91J3JlIG5hcnJvd2luZyBhIGdyYW50IHlvdVxcbmFscmVhZHkgaG9sZDpcIn17XCJcXG5cIn08X2NvbXBvbmVudHMucHJlPjxfY29tcG9uZW50cy5jb2RlIGNsYXNzTmFtZT1cImxhbmd1YWdlLXRzXCI+e1wiaW1wb3J0IHsgaW52b2tlVGFzaywgY2FwRmlsZSB9IGZyb20gJ0BpbW1lZGlhdGVseS1ydW4vc2RrJztcXG5hd2FpdCBpbnZva2VUYXNrKCdlZGl0LWZpbGUnLCB7XFxuICBmaWxlOiBjYXBGaWxlKHsgbW91bnRJZDogJ3NwYWNlOmFiYycsIHJlbFBhdGg6ICdub3Rlcy9pZGVhLm1keCcgfSwgeyBtb2RlOiAncncnIH0pLFxcbn0pO1xcblwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnByZT57XCJcXG5cIn17XCJUaGlzIGlzIGV4YWN0bHkgaG93IHRoZSB3aGl0ZWJvYXJkJ3MgXFxcIk9wZW4gc291cmNlXFxcIiBidXR0b24gd29ya3MuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJPZmZlciBcXFwiZWRpdFxcXCIgYXMgYW4gYWZmb3JkYW5jZSBvbiB0aGUgaXRlbSwgbm90IGEgbW9kZSBvZiB5b3VyIGFwcC5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgU2VsZWN0XFxuYW4gb2JqZWN0IC8gZm9jdXMgYSByb3cg4oaSIGFuIGVkaXQgaWNvbiB0aGF0IG9wZW5zIFwifTxfY29tcG9uZW50cy5lbT57XCJ0aGF0XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgZmlsZS4gS2VlcCB5b3VyXFxucnVuLW1vZGUgVUkgZnJlZSBvZiBlZGl0b3IgY2hyb21lIChydW4tbW9kZSBjb21lcyBmaXJzdCkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJHYXRlIHRoZSBhZmZvcmRhbmNlIG9uIHdyaXRhYmlsaXR5LlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBTaG93IGl0IG9ubHkgd2hlbiB0aGUgbW91bnQgaXMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicndcIn08L19jb21wb25lbnRzLmNvZGU+e1wiO1xcbnJlLWV2YWx1YXRlIG9uIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm9uTW91bnRzQ2hhbmdlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhbmQgaGlkZSBpdCBvbiBhIHJvbGUgZG93bmdyYWRlLiBOZXZlciBzaG93IGFcXG5idXR0b24gdGhhdCBjb21lcyBiYWNrIFwifTxfY29tcG9uZW50cy5jb2RlPntcInJlYWQtb25seVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZm9yYmlkZGVuXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgYW5kIG5ldmVyIHN1cmZhY2UgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRVJPRlNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFzIFVYLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQSBmZXcgdHlwZWQgZmllbGRzIGlzIGEgZm9ybSwgbm90IGFuIGVkaXRvci5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgQW4gaW5zcGVjdG9yIHRoYXQgc2V0cyBhXFxuY29sb3IsIHRhZ3MsIG9yIGEgbG9jayB0b2dnbGUgc2hvdWxkIGJlIGlubGluZSBVSS4gUmVhY2ggZm9yIHRoZSBwbGF0Zm9ybVxcbmVkaXRvciBmb3IgdGhlIGZyZWUtZm9ybSBib2R5IC8gdGhlIHdob2xlIGZpbGUuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJCdWlsZCBhIHJlYWwgaW4tYXBwIGVkaXRvciBvbmx5IHdpdGggYSBzdGF0ZWQgcmVhc29uXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCB0aGUgY29udGVudCBpc24ndCBhXFxuZmlsZSB0aGUgcGxhdGZvcm0gZWRpdG9yIGNhbiBlZGl0IChmcmVlaGFuZCBkcmF3aW5nLCBhIG5vZGUgZ3JhcGgsXFxuZGlyZWN0LW1hbmlwdWxhdGlvbiBnZW9tZXRyeSksIG9yIGEgbWVhc3VyZWQgVVggbmVlZCB0aGUgcGxhdGZvcm0gZWRpdG9yIGNhbid0XFxubWVldC4gV3JpdGUgdGhlIHJlYXNvbiBkb3duOyBjb252ZW5pZW5jZSBpcyBub3QgYSByZWFzb24uXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJLbm93biBnYXAgKGRvbid0IHBhcGVyIG92ZXIgaXQgd2l0aCBhIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjx0ZXh0YXJlYT5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiKTpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgb3BlbmluZyBhIHNwZWNpZmljXFxubW91bnRlZCBmaWxlIGluIHRoZSBcIn08X2NvbXBvbmVudHMuZW0+e1wibWFpblwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGVkaXRvciAodnMuIHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJlZGl0LWZpbGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG92ZXJsYXkpIGZyb20gYVxcbnN0YW5kYWxvbmUgYXBwIGlzbid0IHN1cHBvcnRlZCB5ZXQg4oCUIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkVESVRPUl9GSVJTVF9FRElUSU5HX1NQRUMubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIMKnNlxcbkRlbHRhIEI7IHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJlZGl0LWZpbGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG92ZXJsYXkgY292ZXJzIG1vdW50ZWQgZmlsZXMgbWVhbndoaWxlLiAoVGhlIG90aGVyXFxuaGFsZiBvZiB0aGUgb2xkIGdhcCBsaXN0IGlzIENMT1NFRDogc2luY2UgRGVsdGEgQSBsYW5kZWQgMjAyNi0wNi0xMywgYVxcbnByZXNlbnQtbW9kZSBhcHAgQ0FOIHN1bW1vbiB0aGUgZWRpdCBleHBlcmllbmNlIG9uIGl0cyBvd24gc291cmNlIHZpYSB0aGVcXG5TREsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicmVxdWVzdEVkaXQoKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIG93bi1zb3VyY2UgZWRpdHMgbGFuZCBpbiB0aGUgQ29XIG92ZXJsYXksIGFuZCB0aGVcXG5jYXBhYmlsaXR5IG93bmVyIGNvbmZpcm1lZCBiYXNlbGluZS13aGVuLXNlbGYtc2NvcGVkIG9uIDIwMjYtMDgtMjguKVwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJ2ZXJpZnktYmVmb3JlLXlvdXJlLWRvbmVcIj48SGVhZGluZ0FuY2hvciBpZD1cInZlcmlmeS1iZWZvcmUteW91cmUtZG9uZVwiIC8+e1wiVmVyaWZ5IGJlZm9yZSB5b3UncmUgZG9uZVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnByZT48X2NvbXBvbmVudHMuY29kZSBjbGFzc05hbWU9XCJsYW5ndWFnZS1iYXNoXCI+e1wibnBtIHJ1biBidWlsZCAgICMgbXVzdCBwYXNzIHdpdGggbm8gdHlwZSBlcnJvcnNcXG5ucG0gcnVuIGxpbnQgICAgIyBtdXN0IHBhc3Mg4oCUIHRoaXMgaXMgdGhlIGNoZWFwZXN0IHByb29mIHRoZSBGYXN0IFJlZnJlc2ggcnVsZSBob2xkc1xcblwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnByZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGVuIGV5ZWJhbGwgdGhlIHBhZ2UgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIm5wbSBydW4gZGV2XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikgYW5kIGNsaWNrIGFueSBpbnRlcmFjdGl2ZSBjb250cm9scy5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwiZGVidWdnaW5nLW9uLWltbWVkaWF0ZWx5cnVuLW5vdC1qdXN0LXZpdGUtZGV2XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJkZWJ1Z2dpbmctb24taW1tZWRpYXRlbHlydW4tbm90LWp1c3Qtdml0ZS1kZXZcIiAvPntcIkRlYnVnZ2luZyBvbiBpbW1lZGlhdGVseS5ydW4gKG5vdCBqdXN0IFwifTxfY29tcG9uZW50cy5jb2RlPntcInZpdGUgZGV2XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIilcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5jb2RlPntcInZpdGUgZGV2XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBwcm92ZXMgeW91ciBhcHAgcmVuZGVycywgYnV0IHRoZSBmYWlsdXJlIG1vZGUgdGhpcyB3aG9sZSBmaWxlIHdhcm5zIGFib3V0XFxu4oCUIFwifTxfY29tcG9uZW50cy5lbT57XCJcXFwid29ya3MgbG9jYWxseSwgYnJlYWtzIG9uIGltbWVkaWF0ZWx5LnJ1blxcXCJcIn08L19jb21wb25lbnRzLmVtPntcIiDigJQgb25seSBzaG93cyB1cCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInJ1bm5pbmcgaW5zaWRlIHRoZVxcbmhvc3RcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCI6IHRoZSBzYW5kYm94ZWQgaWZyYW1lLCB0aGUgU0RLIGNoYW5uZWwsIHRoZSBjYXBhYmlsaXR5IGdhdGUuIERlYnVnIHRoZXJlIHRvby5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkRyaXZlIGEgcmVhbCBicm93c2VyIHdpdGggQ2hyb21lIERldlRvb2xzIE1DUC5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1jcF9fY2hyb21lLWRldnRvb2xzX18qXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIlxcbnRvb2xzIG5hdmlnYXRlIHRoZSBwYWdlLCB0YWtlIGFuIGFjY2Vzc2liaWxpdHkgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJzbmFwc2hvdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoZWxlbWVudCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ1aWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wicyB0b1xcbmNsaWNrL2ZpbGwpLCBydW4gSlMgd2l0aCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPjxfY29tcG9uZW50cy5jb2RlPntcImV2YWx1YXRlX3NjcmlwdFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnN0cm9uZz57XCIsIGFuZCByZWFkIHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImNvbnNvbGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgK1xcblwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibmV0d29ya1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgd2hpY2ggaXMgd2hlcmUgU0RLIFwifTxfY29tcG9uZW50cy5jb2RlPntcInsgb2s6IGZhbHNlLCBjb2RlIH1cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHJlcGxpZXMgYW5kIHNhbmRib3ggZXJyb3JzXFxuYWN0dWFsbHkgc3VyZmFjZS4gUmVwcm9kdWNlLCB0aGVuIFwifTxfY29tcG9uZW50cy5jb2RlPntcImxpc3RfY29uc29sZV9tZXNzYWdlc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgL1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcImxpc3RfbmV0d29ya19yZXF1ZXN0c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCI7IGRvbid0IGd1ZXNzIGZyb20gdGhlIHJlbmRlcmVkIERPTSBhbG9uZS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlJ1biB5b3VyIGFwcCBcIn08X2NvbXBvbmVudHMuZW0+e1wib24gdGhlIGhvc3RcIn08L19jb21wb25lbnRzLmVtPntcIiwgd2l0aCBubyBjb21taXQsIHZpYSB0aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibG9jYWxcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHByb3ZpZGVyLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBNb3VudFxcbnlvdXIgd29ya2luZyB0cmVlIGludG8gdGhlIHJlYWwgaG9zdCBhbmQgZWRpdCBsaXZlOlwifXtcIlxcblwifTxfY29tcG9uZW50cy5wcmU+PF9jb21wb25lbnRzLmNvZGUgY2xhc3NOYW1lPVwibGFuZ3VhZ2UtYmFzaFwiPntcImltbWVkaWF0ZWx5LnJ1biBkZXYgLiAtLW9yaWdpbiBodHRwczovL2xvY2FsLmltbWVkaWF0ZWx5LnJ1biAtLWpzb25cXG4jIOKGkiBvcGVuIHRoZSBwcmludGVkIC9lZGl0L2xvY2FsLzxuYW1lPi08aGFzaDg+Ly4uLi9saXZlI2lyLWVuZHBvaW50PeKApiZpci10b2tlbj3igKYgbGlua1xcblwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnByZT57XCJcXG5cIn17XCJFZGl0cyBvbiBkaXNrIGhvdC1yZWxvYWQgaW4gdGhlIGhvc3QgcHJldmlldywgc28geW91IGV4ZXJjaXNlIHRoZSBcIn08X2NvbXBvbmVudHMuZW0+e1wicmVhbFwifTwvX2NvbXBvbmVudHMuZW0+e1wiIFNESyArXFxuY2FwYWJpbGl0eSBwYXRoIChjb25zZW50IHByb21wdHMsIFwifTxfY29tcG9uZW50cy5jb2RlPntcImZvcmJpZGRlblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIG1vdW50cykgaW5zdGVhZCBvZiBhIGxvY2FsIHN0dWIuIEFcXG5kZXYtc2VydmVkIGFwcCBnZXRzIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJmcmVzaCBhcHBLZXlcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgd2l0aCBubyBwcmlvciBncmFudHMg4oCUIGhhbmR5IGZvciB0ZXN0aW5nXFxueW91ciBmaXJzdC1ydW4gY29uc2VudCBmbG93IGhvbmVzdGx5LiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQGltbWVkaWF0ZWx5LXJ1bi9jbGlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBOb2RlIOKJpSAxOCwgZ2l0XFxucmVwby4pXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJBbHdheXMgdXNlIFwifTxfY29tcG9uZW50cy5jb2RlPntcImh0dHBzOi8vbG9jYWwuaW1tZWRpYXRlbHkucnVuXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgbmV2ZXIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibG9jYWxob3N0XCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgY29uZmlnIGlzXFxua2V5ZWQgYnkgaG9zdG5hbWUgYW5kIG9ubHkgdGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcIiouaW1tZWRpYXRlbHkucnVuXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBvcmlnaW4gaXMgZnVsbHkgd2lyZWRcXG4oc2FuZGJveCArIGJhY2tlbmQgKyBhdXRoIGFsbG93bGlzdCkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJBIHBhc3NrZXkgLyBUb3VjaC1JRCBwcm9tcHQgY2FuJ3QgYmUgYXV0b21hdGVkXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCB0aGUgZmlyc3Qgc2VjcmV0IHVuc2VhbCBvclxcbnNpZ24taW4gcmFpc2VzIGEgbmF0aXZlIGRpYWxvZzsgaGFuZCB0aGF0IHN0ZXAgdG8gYSBodW1hbiwgb3IgcmVsb2FkIGFmdGVyIGl0J3NcXG5jYWNoZWQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSBwbGF0Zm9ybSByZXBvIGFsc28gc2hpcHMgYSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ3aW5kb3cuX19pclRlc3RcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGhvc3QgaG9vayBmb3Igc2NyaXB0aW5nXFxuc3BhY2Uvc2hhcmUgZHJpbGxzLCBidXQgdGhhdCBpcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImhvc3QtaW50ZXJuYWxcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKGRldiBidWlsZHMgb2YgaW1tZWRpYXRlbHkucnVuXFxuaXRzZWxmKSDigJQgbm90IHNvbWV0aGluZyB5b3VyIGFwcCB1c2VzIG9yIHNob3VsZCByZWx5IG9uLiBUaGUgZnVsbCBwbGF0Zm9ybS1zaWRlXFxud29ya2Zsb3cgbGl2ZXMgaW4gdGhlIGRvY3MgcmVwbydzIFwifTxfY29tcG9uZW50cy5jb2RlPntcInR1dG9yaWFscy9icm93c2VyX2RlYnVnZ2luZy9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08L19jb21wb25lbnRzLmJsb2NrcXVvdGU+PC8+O1xufVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTURYQ29udGVudChwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHt3cmFwcGVyOiBNRFhMYXlvdXR9ID0ge1xuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfTtcbiAgcmV0dXJuIE1EWExheW91dCA/IDxNRFhMYXlvdXQgey4uLnByb3BzfT48X2NyZWF0ZU1keENvbnRlbnQgey4uLnByb3BzfSAvPjwvTURYTGF5b3V0PiA6IF9jcmVhdGVNZHhDb250ZW50KHByb3BzKTtcbn1cbmZ1bmN0aW9uIF9taXNzaW5nTWR4UmVmZXJlbmNlKGlkLCBjb21wb25lbnQsIHBsYWNlKSB7XG4gIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIFwiICsgKGNvbXBvbmVudCA/IFwiY29tcG9uZW50XCIgOiBcIm9iamVjdFwiKSArIFwiIGBcIiArIGlkICsgXCJgIHRvIGJlIGRlZmluZWQ6IHlvdSBsaWtlbHkgZm9yZ290IHRvIGltcG9ydCwgcGFzcywgb3IgcHJvdmlkZSBpdC5cIiArIChwbGFjZSA/IFwiXFxuSXTigJlzIHJlZmVyZW5jZWQgaW4geW91ciBjb2RlIGF0IGBcIiArIHBsYWNlICsgXCJgIGluIGAvYXBwL0NMQVVERS5tZGBcIiA6IFwiXCIpKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQXdGLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUZ4RjtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU1DLFdBQVcsR0FBRztNQUNsQkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsVUFBVSxFQUFFLFlBQVk7TUFDeEJDLElBQUksRUFBRSxNQUFNO01BQ1pDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLENBQUMsRUFBRSxHQUFHO01BQ05DLEdBQUcsRUFBRSxLQUFLO01BQ1ZDLE1BQU0sRUFBRSxRQUFRO01BQ2hCQyxFQUFFLEVBQUUsSUFBSTtNQUNSLEdBQUcsSUFBQUMsNkJBQWtCLEVBQUMsQ0FBQztNQUN2QixHQUFHZCxLQUFLLENBQUNlO0lBQ1gsQ0FBQztJQUFFO01BQUNDO0lBQWEsQ0FBQyxHQUFHZixXQUFXO0VBQ2hDLElBQUksQ0FBQ2UsYUFBYSxFQUFFQyxvQkFBb0IsQ0FBQyxlQUFlLEVBQUUsSUFBSSxDQUFDO0VBQy9ELG9CQUFPLElBQUFuQixXQUFBLENBQUFvQixJQUFBLEVBQUFwQixXQUFBLENBQUFxQixRQUFBO0lBQUFDLFFBQUEsZ0JBQUUsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDZSxFQUFFLEVBQUMsc0JBQXNCO01BQUFELFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBc0IsQ0FBRSxDQUFDLEVBQUMsc0JBQXNCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDUyxDQUFDO01BQUFVLFFBQUEsR0FBRSxhQUFhLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBcUIsQ0FBcUIsQ0FBQyxFQUFDLDRKQUE0SixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNJLEVBQUU7UUFBQWUsUUFBQSxFQUFFO01BQU0sQ0FBaUIsQ0FBQyxFQUFDLHlEQUF5RCxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFVLENBQW1CLENBQUMsRUFBQyxvQ0FBb0M7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNNLEVBQUU7TUFBQ2MsRUFBRSxFQUFDLG1EQUFtRDtNQUFBRCxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQW1ELENBQUUsQ0FBQyxFQUFDLHNEQUFzRDtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1EsRUFBRTtNQUFBVyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDUyxDQUFDO1VBQUFVLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1csTUFBTTtZQUFBUSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7Y0FBQWdCLFFBQUEsRUFBRTtZQUFrQixDQUFtQixDQUFDLEVBQUMsMENBQTBDO1VBQUEsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1lBQUFnQixRQUFBLEVBQUU7VUFBYyxDQUFtQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7WUFBQWdCLFFBQUEsRUFBRTtVQUFNLENBQW1CLENBQUMsRUFBQyx5QkFBeUIsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1lBQUFnQixRQUFBLEVBQUU7VUFBNkIsQ0FBbUIsQ0FBQyxFQUFDLE9BQU8sZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDVyxNQUFNO1lBQUFRLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBZ0IsUUFBQSxFQUFFO1lBQWEsQ0FBbUIsQ0FBQyxFQUFDLGlDQUFpQztVQUFBLENBQXFCLENBQUMsRUFBQywyQ0FBMkMsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1lBQUFnQixRQUFBLEVBQUU7VUFBYyxDQUFtQixDQUFDLEVBQUMsdUNBQXVDLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtZQUFBUSxRQUFBLEVBQUU7VUFBUyxDQUFxQixDQUFDLEVBQUMsc0VBQXNFO1FBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDUyxDQUFDO1VBQUFVLFFBQUEsR0FBRSw2REFBNkQsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1lBQUFnQixRQUFBLEVBQUU7VUFBTSxDQUFtQixDQUFDLEVBQUMsc0VBQXNFLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBZ0IsUUFBQSxFQUFFO1VBQVUsQ0FBbUIsQ0FBQyxFQUFDLCtCQUErQixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7WUFBQWdCLFFBQUEsRUFBRTtVQUFVLENBQW1CLENBQUMsRUFBQywwQkFBMEIsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1lBQUFnQixRQUFBLEVBQUU7VUFBc0IsQ0FBbUIsQ0FBQyxFQUFDLHFFQUFxRSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7WUFBQWdCLFFBQUEsRUFBRTtVQUFPLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBZ0IsUUFBQSxFQUFFO1VBQVUsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1lBQUFnQixRQUFBLEVBQUU7VUFBVyxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7WUFBQWdCLFFBQUEsRUFBRTtVQUFvQixDQUFtQixDQUFDLEVBQUMsMENBQTBDLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBZ0IsUUFBQSxFQUFFO1VBQU0sQ0FBbUIsQ0FBQyxFQUFDLG9IQUFvSDtRQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1FBQUFZLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1MsQ0FBQztVQUFBVSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNXLE1BQU07WUFBQVEsUUFBQSxHQUFFLHlCQUF5QixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7Y0FBQWdCLFFBQUEsRUFBRTtZQUFTLENBQW1CLENBQUM7VUFBQSxDQUFvQixDQUFDLEVBQUMsYUFBYSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7WUFBQWdCLFFBQUEsRUFBRTtVQUFVLENBQW1CLENBQUMsRUFBQyx1RkFBdUYsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1lBQUFnQixRQUFBLEVBQUU7VUFBUyxDQUFtQixDQUFDLEVBQUMsR0FBRztRQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1FBQUFZLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1MsQ0FBQztVQUFBVSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07WUFBQVEsUUFBQSxFQUFFO1VBQWdFLENBQXFCLENBQUMsRUFBQyx5RUFBeUUsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1lBQUFnQixRQUFBLEVBQUU7VUFBVyxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7WUFBQWdCLFFBQUEsRUFBRTtVQUFNLENBQW1CLENBQUMsRUFBQyxvRkFBb0YsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1lBQUFnQixRQUFBLEVBQUU7VUFBYyxDQUFtQixDQUFDLEVBQUMsNEJBQTRCLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBZ0IsUUFBQSxFQUFFO1VBQVcsQ0FBbUIsQ0FBQyxFQUFDLGFBQWEsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1lBQUFnQixRQUFBLEVBQUU7VUFBWSxDQUFtQixDQUFDLEVBQUMsa0JBQWtCLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBZ0IsUUFBQSxFQUFFO1VBQVUsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7UUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBWSxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNTLENBQUM7VUFBQVUsUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1lBQUFRLFFBQUEsRUFBRTtVQUEwQyxDQUFxQixDQUFDLEVBQUMsOEJBQThCO1FBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDUyxDQUFDO1VBQUFVLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1csTUFBTTtZQUFBUSxRQUFBLEdBQUUsZUFBZSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7Y0FBQWdCLFFBQUEsRUFBRTtZQUFNLENBQW1CLENBQUMsRUFBQyxpQ0FBaUM7VUFBQSxDQUFxQixDQUFDLEVBQUMsbUJBQW1CLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBZ0IsUUFBQSxFQUFFO1VBQVMsQ0FBbUIsQ0FBQyxFQUFDLG9CQUFvQixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7WUFBQWdCLFFBQUEsRUFBRTtVQUFZLENBQW1CLENBQUMsRUFBQywyQkFBMkI7UUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBWSxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNTLENBQUM7VUFBQVUsUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDVyxNQUFNO1lBQUFRLFFBQUEsR0FBRSxnQkFBZ0IsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO2NBQUFnQixRQUFBLEVBQUU7WUFBUyxDQUFtQixDQUFDO1VBQUEsQ0FBb0IsQ0FBQyxFQUFDLDBDQUEwQyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7WUFBQWdCLFFBQUEsRUFBRTtVQUFRLENBQW1CLENBQUMsRUFBQyxZQUFZLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBZ0IsUUFBQSxFQUFFO1VBQVksQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7UUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBWSxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNTLENBQUM7VUFBQVUsUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1lBQUFRLFFBQUEsRUFBRTtVQUFxQixDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7WUFBQWdCLFFBQUEsRUFBRTtVQUFzQyxDQUFtQixDQUFDLEVBQUMsbUVBQW1FO1FBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDUyxDQUFDO1VBQUFVLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtZQUFBUSxRQUFBLEVBQUU7VUFBZ0MsQ0FBcUIsQ0FBQyxFQUFDLHdEQUF3RCxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7WUFBQWdCLFFBQUEsRUFBRTtVQUFVLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBZ0IsUUFBQSxFQUFFO1VBQVEsQ0FBbUIsQ0FBQyxFQUFDLFFBQVEsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1lBQUFnQixRQUFBLEVBQUU7VUFBTyxDQUFtQixDQUFDLEVBQUMsa0JBQWtCLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtZQUFBUSxRQUFBLEVBQUU7VUFBcUIsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1lBQUFnQixRQUFBLEVBQUU7VUFBYyxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7WUFBQWdCLFFBQUEsRUFBRTtVQUFnQixDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7WUFBQWdCLFFBQUEsRUFBRTtVQUFXLENBQW1CLENBQUMsRUFBQyxzR0FBc0csZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1lBQUFnQixRQUFBLEVBQUU7VUFBbUIsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1lBQUFnQixRQUFBLEVBQUU7VUFBMkIsQ0FBbUIsQ0FBQyxFQUFDLHFDQUFxQyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNJLEVBQUU7WUFBQWUsUUFBQSxFQUFFO1VBQVMsQ0FBaUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1lBQUFnQixRQUFBLEVBQUU7VUFBYyxDQUFtQixDQUFDLEVBQUMsVUFBVSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7WUFBQWdCLFFBQUEsRUFBRTtVQUFlLENBQW1CLENBQUMsRUFBQyxVQUFVLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBZ0IsUUFBQSxFQUFFO1VBQXFDLENBQW1CLENBQUMsRUFBQyxxR0FBcUc7UUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNZLEVBQUU7VUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1lBQUFZLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtjQUFBUSxRQUFBLEVBQUU7WUFBaUMsQ0FBcUIsQ0FBQyxFQUFDLG9FQUFvRSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7Y0FBQWdCLFFBQUEsRUFBRTtZQUF3QixDQUFtQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7Y0FBQWdCLFFBQUEsRUFBRTtZQUFzQixDQUFtQixDQUFDLEVBQUMsZ0ZBQWdGO1VBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1lBQUFZLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtjQUFBUSxRQUFBLEVBQUU7WUFBYyxDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7Y0FBQWdCLFFBQUEsRUFBRTtZQUFnQixDQUFtQixDQUFDLEVBQUMsR0FBRztVQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtZQUFBWSxRQUFBLEdBQUUsOEJBQThCLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBZ0IsUUFBQSxFQUFFO1lBQWtCLENBQW1CLENBQUMsRUFBQyxXQUFXLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBZ0IsUUFBQSxFQUFFO1lBQWUsQ0FBbUIsQ0FBQyxFQUFDLDRMQUE0TDtVQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO1FBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDUyxDQUFDO1VBQUFVLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtZQUFBUSxRQUFBLEVBQUU7VUFBaUMsQ0FBcUIsQ0FBQyxFQUFDLDBFQUEwRSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7WUFBQWdCLFFBQUEsRUFBRTtVQUFXLENBQW1CLENBQUMsRUFBQyxlQUFlLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBZ0IsUUFBQSxFQUFFO1VBQU0sQ0FBbUIsQ0FBQyxFQUFDLHlCQUF5QixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7WUFBQWdCLFFBQUEsRUFBRTtVQUFjLENBQW1CLENBQUMsRUFBQyw2QkFBNkI7UUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTSxFQUFFO01BQUNjLEVBQUUsRUFBQyxtQ0FBbUM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFtQyxDQUFFLENBQUMsRUFBQyxzQ0FBc0M7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNTLENBQUM7TUFBQVUsUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBNkIsQ0FBbUIsQ0FBQyxFQUFDLG9GQUFvRixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFNLENBQW1CLENBQUMsRUFBQywySUFBMkksZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUEyQyxDQUFxQixDQUFDLEVBQUMsa0JBQWtCLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQU0sQ0FBbUIsQ0FBQyxFQUFDLHlMQUF5TCxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFXLENBQW1CLENBQUMsRUFBQyw4SUFBOEksZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBK0QsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNTLENBQUM7TUFBQVUsUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBcUQsQ0FBbUIsQ0FBQyxFQUFDLE1BQU0sZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBYyxDQUFtQixDQUFDLEVBQUMsZ0NBQWdDLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBYSxDQUFxQixDQUFDLEVBQUMsbUJBQW1CLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQWMsQ0FBbUIsQ0FBQyxFQUFDLHlEQUF5RCxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFnQixDQUFtQixDQUFDLEVBQUMseURBQXlELGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQVksQ0FBbUIsQ0FBQyxFQUFDLDhLQUE4SztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDYyxFQUFFLEVBQUMsZUFBZTtNQUFBRCxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQWUsQ0FBRSxDQUFDLEVBQUMsZUFBZTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBVSxRQUFBLEdBQUUsd05BQXdOLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBVSxDQUFxQixDQUFDLEVBQUMscURBQXFELGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQXNCLENBQW1CLENBQUMsRUFBQyxNQUFNLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQVEsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNZLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEdBQUUsbUJBQW1CLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBZ0IsUUFBQSxFQUFFO1VBQWUsQ0FBbUIsQ0FBQztRQUFBLENBQW9CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQU0sQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBUyxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFPLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVUsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFRLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWUsQ0FBbUIsQ0FBQyxFQUFDLDZFQUE2RTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBWSxRQUFBLEdBQUUsNENBQTRDLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQXlCLENBQW1CLENBQUMsRUFBQyxHQUFHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1FBQUFZLFFBQUEsR0FBRSxvQ0FBb0MsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsVUFBVSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNDLENBQUM7VUFBQ3FCLElBQUksRUFBQyxvQkFBb0I7VUFBQUgsUUFBQSxFQUFFO1FBQVEsQ0FBZ0IsQ0FBQyxFQUFDLGVBQWUsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBYyxDQUFtQixDQUFDLEVBQUMsYUFBYTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTSxFQUFFO01BQUNjLEVBQUUsRUFBQyx1REFBdUQ7TUFBQUQsUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUF1RCxDQUFFLENBQUMsRUFBQyx5REFBeUQ7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNTLENBQUM7TUFBQVUsUUFBQSxHQUFFLDRDQUE0QyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFzQixDQUFtQixDQUFDLEVBQUMsdUtBQXVLO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDWSxFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7WUFBQWdCLFFBQUEsRUFBRTtVQUFVLENBQW1CO1FBQUMsQ0FBb0IsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDQyxDQUFDO1VBQUNxQixJQUFJLEVBQUMsZ0VBQWdFO1VBQUFILFFBQUEsRUFBRTtRQUFnRSxDQUFnQixDQUFDLEVBQUMsZ0hBQWdILGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBYSxDQUFxQixDQUFDO01BQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBZ0IsUUFBQSxFQUFFO1VBQVUsQ0FBbUI7UUFBQyxDQUFvQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNDLENBQUM7VUFBQ3FCLElBQUksRUFBQyxnRUFBZ0U7VUFBQUgsUUFBQSxFQUFFO1FBQWdFLENBQWdCLENBQUMsRUFBQywrR0FBK0c7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFnQixDQUFxQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNDLENBQUM7VUFBQ3FCLElBQUksRUFBQyx3REFBd0Q7VUFBQUgsUUFBQSxFQUFFO1FBQXdELENBQWdCLENBQUMsRUFBQyxzQkFBc0I7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBVSxRQUFBLEdBQUUsa0JBQWtCLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQW1DLENBQW1CLENBQUMsRUFBQyxTQUFTLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQU8sQ0FBbUIsQ0FBQyxFQUFDLGlKQUFpSixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFzQixDQUFtQixDQUFDLEVBQUMsOEJBQThCLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQTRCLENBQW1CLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTSxFQUFFO01BQUNjLEVBQUUsRUFBQyx1REFBdUQ7TUFBQUQsUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUF1RCxDQUFFLENBQUMsRUFBQywwREFBMEQ7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNTLENBQUM7TUFBQVUsUUFBQSxHQUFFLHFCQUFxQixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQXdDLENBQXFCLENBQUMsRUFBQywrRUFBK0UsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBK0IsQ0FBbUIsQ0FBQyxFQUFDLGdXQUFnVztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1EsRUFBRTtNQUFBVyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsR0FBRSx3Q0FBd0MsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1lBQUFnQixRQUFBLEVBQUU7VUFBc0IsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7UUFBQSxDQUFxQixDQUFDLEVBQUMseUlBQXlJO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBZ0MsQ0FBcUIsQ0FBQyxFQUFDLHVLQUF1SyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUF1QyxDQUFtQixDQUFDLEVBQUMsa0NBQWtDO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBbUQsQ0FBcUIsQ0FBQyxFQUFDLDhLQUE4SyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFJLENBQW1CLENBQUMsRUFBQywwREFBMEQsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBTyxDQUFtQixDQUFDLEVBQUMsR0FBRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQThDLENBQXFCLENBQUMsRUFBQyxzRUFBc0UsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDSSxFQUFFO1VBQUFlLFFBQUEsRUFBRTtRQUFNLENBQWlCLENBQUMsRUFBQyw2QkFBNkIsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBZ0QsQ0FBbUIsQ0FBQyxFQUFDLDRCQUE0QjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQWlDLENBQXFCLENBQUMsRUFBQyx5QkFBeUIsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBOEIsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFlLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLFFBQVEsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsb0ZBQW9GO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBc0MsQ0FBcUIsQ0FBQyxFQUFDLDBCQUEwQixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUMsRUFBQyxTQUFTLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQXFCLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQyxFQUFDLGlDQUFpQyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUMsRUFBQyxnRUFBZ0U7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUE0QixDQUFxQixDQUFDLEVBQUMsb0pBQW9KO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBMkQsQ0FBcUIsQ0FBQyxFQUFDLDBNQUEwTTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQWtDLENBQXFCLENBQUMsRUFBQyxrQ0FBa0MsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMscUZBQXFGO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNNLEVBQUU7TUFBQ2MsRUFBRSxFQUFDLHlDQUF5QztNQUFBRCxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQXlDLENBQUUsQ0FBQyxFQUFDLDBDQUEwQztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBVSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQTRHLENBQXFCLENBQUMsRUFBQyxpQ0FBaUMsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDSSxFQUFFO1FBQUFlLFFBQUEsRUFBRTtNQUFJLENBQWlCLENBQUMsRUFBQyx3SkFBd0osZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBWSxDQUFtQixDQUFDLEVBQUMsMk9BQTJPLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBZ0IsUUFBQSxFQUFFO01BQXlDLENBQW1CLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDUSxFQUFFO01BQUFXLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxHQUFFLDRDQUE0QyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7WUFBQWdCLFFBQUEsRUFBRTtVQUFXLENBQW1CLENBQUMsRUFBQyxRQUFRO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLHdMQUF3TCxFQUFFLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVSxHQUFHO1VBQUFTLFFBQUEsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1lBQUNvQixTQUFTLEVBQUMsYUFBYTtZQUFBSixRQUFBLEVBQUU7VUFBNEwsQ0FBbUI7UUFBQyxDQUFpQixDQUFDLEVBQUMsSUFBSSxFQUFFLG9FQUFvRTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQXNFLENBQXFCLENBQUMsRUFBQyw2REFBNkQsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDSSxFQUFFO1VBQUFlLFFBQUEsRUFBRTtRQUFNLENBQWlCLENBQUMsRUFBQyw2RUFBNkU7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFxQyxDQUFxQixDQUFDLEVBQUMsa0NBQWtDLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQUksQ0FBbUIsQ0FBQyxFQUFDLG9CQUFvQixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFnQixDQUFtQixDQUFDLEVBQUMseUVBQXlFLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsc0JBQXNCLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQU8sQ0FBbUIsQ0FBQyxFQUFDLFNBQVM7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUE4QyxDQUFxQixDQUFDLEVBQUMsdUpBQXVKO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBc0QsQ0FBcUIsQ0FBQyxFQUFDLHVPQUF1TztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxHQUFFLHdDQUF3QyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7WUFBQWdCLFFBQUEsRUFBRTtVQUFZLENBQW1CLENBQUMsRUFBQyxJQUFJO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLDJDQUEyQyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNJLEVBQUU7VUFBQWUsUUFBQSxFQUFFO1FBQU0sQ0FBaUIsQ0FBQyxFQUFDLG1CQUFtQixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyx5REFBeUQsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBOEIsQ0FBbUIsQ0FBQyxFQUFDLG9CQUFvQixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyw4TUFBOE0sZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBZSxDQUFtQixDQUFDLEVBQUMsNEhBQTRIO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNNLEVBQUU7TUFBQ2MsRUFBRSxFQUFDLDBCQUEwQjtNQUFBRCxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQTBCLENBQUUsQ0FBQyxFQUFDLDJCQUEyQjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1UsR0FBRztNQUFBUyxRQUFBLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtRQUFDb0IsU0FBUyxFQUFDLGVBQWU7UUFBQUosUUFBQSxFQUFFO01BQXlJLENBQW1CO0lBQUMsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDUyxDQUFDO01BQUFVLFFBQUEsR0FBRSx5QkFBeUIsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBYSxDQUFtQixDQUFDLEVBQUMsdUNBQXVDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTSxFQUFFO01BQUNjLEVBQUUsRUFBQywrQ0FBK0M7TUFBQUQsUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUErQyxDQUFFLENBQUMsRUFBQyx5Q0FBeUMsZUFBQyxJQUFBdkIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1FBQUFnQixRQUFBLEVBQUU7TUFBVSxDQUFtQixDQUFDLEVBQUMsR0FBRztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBVSxRQUFBLGdCQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7UUFBQWdCLFFBQUEsRUFBRTtNQUFVLENBQW1CLENBQUMsRUFBQyxnRkFBZ0YsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDSSxFQUFFO1FBQUFlLFFBQUEsRUFBRTtNQUE4QyxDQUFpQixDQUFDLEVBQUMsbUJBQW1CLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBMEIsQ0FBcUIsQ0FBQyxFQUFDLGdGQUFnRjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1ksRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFnRCxDQUFxQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUF5QixDQUFtQixDQUFDLEVBQUMsbURBQW1ELGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBVSxDQUFxQixDQUFDLEVBQUMsWUFBWSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFLLENBQW1CLENBQUMsRUFBQyxpQ0FBaUMsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1lBQUFnQixRQUFBLEVBQUU7VUFBaUIsQ0FBbUI7UUFBQyxDQUFvQixDQUFDLEVBQUMsaUJBQWlCLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBUyxDQUFxQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQVMsQ0FBcUIsQ0FBQyxFQUFDLHdCQUF3QixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFxQixDQUFtQixDQUFDLEVBQUMsaUVBQWlFLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQXVCLENBQW1CLENBQUMsRUFBQyxNQUFNLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQXVCLENBQW1CLENBQUMsRUFBQyw0Q0FBNEM7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsR0FBRSxlQUFlLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0ksRUFBRTtZQUFBZSxRQUFBLEVBQUU7VUFBYSxDQUFpQixDQUFDLEVBQUMsNEJBQTRCLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBZ0IsUUFBQSxFQUFFO1VBQU8sQ0FBbUIsQ0FBQyxFQUFDLFlBQVk7UUFBQSxDQUFxQixDQUFDLEVBQUMsNkRBQTZELEVBQUUsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNVLEdBQUc7VUFBQVMsUUFBQSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7WUFBQ29CLFNBQVMsRUFBQyxlQUFlO1lBQUFKLFFBQUEsRUFBRTtVQUErSixDQUFtQjtRQUFDLENBQWlCLENBQUMsRUFBQyxJQUFJLEVBQUUsb0VBQW9FLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0ksRUFBRTtVQUFBZSxRQUFBLEVBQUU7UUFBTSxDQUFpQixDQUFDLEVBQUMsNENBQTRDLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLDhEQUE4RCxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNXLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQWMsQ0FBcUIsQ0FBQyxFQUFDLG9GQUFvRixlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7VUFBQWdCLFFBQUEsRUFBRTtRQUFzQixDQUFtQixDQUFDLEVBQUMsMEJBQTBCO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdEIsV0FBQSxDQUFBb0IsSUFBQSxFQUFDakIsV0FBVyxDQUFDTyxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBUSxRQUFBLEdBQUUsYUFBYSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7WUFBQWdCLFFBQUEsRUFBRTtVQUErQixDQUFtQixDQUFDLEVBQUMsVUFBVSxlQUFDLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUNyQixXQUFXLENBQUNHLElBQUk7WUFBQWdCLFFBQUEsRUFBRTtVQUFXLENBQW1CLENBQUM7UUFBQSxDQUFvQixDQUFDLEVBQUMsK0NBQStDLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQW1CLENBQW1CLENBQUMsRUFBQywrREFBK0Q7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNPLEVBQUU7UUFBQVksUUFBQSxnQkFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFnRCxDQUFxQixDQUFDLEVBQUMseUhBQXlIO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF0QixXQUFBLENBQUFvQixJQUFBLEVBQUNqQixXQUFXLENBQUNFLFVBQVU7TUFBQWlCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQW9CLElBQUEsRUFBQ2pCLFdBQVcsQ0FBQ1MsQ0FBQztRQUFBVSxRQUFBLEdBQUUsaUNBQWlDLGVBQUMsSUFBQXRCLFdBQUEsQ0FBQXdCLEdBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBZ0IsUUFBQSxFQUFFO1FBQWlCLENBQW1CLENBQUMsRUFBQyw0REFBNEQsZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDVyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFlLENBQXFCLENBQUMsRUFBQyxzSkFBc0osZUFBQyxJQUFBdEIsV0FBQSxDQUFBd0IsR0FBQSxFQUFDckIsV0FBVyxDQUFDRyxJQUFJO1VBQUFnQixRQUFBLEVBQUU7UUFBOEIsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7TUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQXlCLENBQUM7RUFBQSxDQUFFLENBQUM7QUFDbnEwQjtBQUNlLFNBQVNLLFVBQVVBLENBQUN6QixLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUU7RUFDN0MsTUFBTTtJQUFDMEIsT0FBTyxFQUFFQztFQUFTLENBQUMsR0FBRztJQUMzQixHQUFHLElBQUFiLDZCQUFrQixFQUFDLENBQUM7SUFDdkIsR0FBR2QsS0FBSyxDQUFDZTtFQUNYLENBQUM7RUFDRCxPQUFPWSxTQUFTLGdCQUFHLElBQUE3QixXQUFBLENBQUF3QixHQUFBLEVBQUNLLFNBQVM7SUFBQSxHQUFLM0IsS0FBSztJQUFBb0IsUUFBQSxlQUFFLElBQUF0QixXQUFBLENBQUF3QixHQUFBLEVBQUN2QixpQkFBaUI7TUFBQSxHQUFLQztJQUFLLENBQUc7RUFBQyxDQUFXLENBQUMsR0FBR0QsaUJBQWlCLENBQUNDLEtBQUssQ0FBQztBQUNsSDtBQUFDNEIsRUFBQSxHQU51QkgsVUFBVTtBQU9sQyxTQUFTUixvQkFBb0JBLENBQUNJLEVBQUUsRUFBRVEsU0FBUyxFQUFFQyxLQUFLLEVBQUU7RUFDbEQsTUFBTSxJQUFJQyxLQUFLLENBQUMsV0FBVyxJQUFJRixTQUFTLEdBQUcsV0FBVyxHQUFHLFFBQVEsQ0FBQyxHQUFHLElBQUksR0FBR1IsRUFBRSxHQUFHLG9FQUFvRSxJQUFJUyxLQUFLLEdBQUcscUNBQXFDLEdBQUdBLEtBQUssR0FBRyx1QkFBdUIsR0FBRyxFQUFFLENBQUMsQ0FBQztBQUNqUDtBQUFDLElBQUFGLEVBQUE7QUFBQUksWUFBQSxDQUFBSixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}