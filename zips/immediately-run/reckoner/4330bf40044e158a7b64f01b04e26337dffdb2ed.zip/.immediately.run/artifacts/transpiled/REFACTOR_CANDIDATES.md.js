var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      p: "p",
      strong: "strong",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "refactor-findings-new-project-template",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "refactor-findings-new-project-template"
      }), "REFACTOR / FINDINGS — new-project-template"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Recorded by the 2026-06 code-verification pass (R3-124; plan ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "08-system-apps.md"
      }), ").\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Record only — nothing actioned."
      }), " This is the scaffold every \"Create\" app forks,\nso it has 0 spec-refs by design (it is the starting point) and a violation here\nwould be high-signal."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-r3",
      "data-slug": "r3-122-schema-on-the-immediatelyrun-manifest-field-blocked-record",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-r3"
      }), "R3-122 — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "$schema"
      }), " on the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "immediately.run"
      }), " manifest field (BLOCKED, record)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "package.json"
      }), " has ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["no ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "immediately.run"
        }), " config object at all"]
      }), " (the field is\nabsent), so there is no ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "$schema"
      }), " either. R3-122's exit criterion includes\n\"", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "$schema"
      }), " referenced in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "new-project-template"
      }), "\"."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Status: blocked on the site-main half."
      }), " The template is the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "consumer"
      }), " of a\ngenerated JSON Schema that site-main must publish first (the schema is generated\nfrom + drift-gated against the Zod source of truth ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "immediatelyRunConfig.ts"
      }), "). No\npublished schema URL exists in this environment (site-main is not in this\ncheckout). ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["Do NOT invent a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "$schema"
        }), " URL."]
      }), " When site-main publishes the schema\nURL, adding the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "$schema"
      }), " line (and a minimal ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "immediately.run"
      }), " object to hang it\non) is a one-line change gated on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "npm run build && npm run lint"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["→ Roadmap dependency: template ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "$schema"
      }), " lands when the published schema URL exists."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "test-toolchain-scaffold-delta-proposedunscheduled-record",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "test-toolchain-scaffold-delta-proposedunscheduled-record"
      }), "Test-toolchain scaffold delta (proposed/unscheduled, record)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The template ships ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "no test setup"
      }), " — no ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "vitest"
      }), " dep, no ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "test"
      }), " script, no\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/test/"
      }), " — unlike file-explorer / agent-demo (which carry ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "vitest ^4.1.8"
      }), " +\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "\"test\": \"vitest run\""
      }), "). The APP_ONBOARDING / future test-toolchain delta proposes\nthe scaffold include a session-runnable test toolchain (vitest + a\nSessionStart-hook-friendly ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "npm test"
      }), ") so Created apps can run tests in web\nsessions (cross-ref the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "session-start-hook"
      }), " skill — the mechanism that ensures\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "npm test"
      }), "/lint run in web sessions)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Status: proposed, unscheduled"
      }), " (APP_ONBOARDING_SPEC is a proposal with no\nstatus doc). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Do NOT scaffold tests in this pass"
      }), " — recorded as a gap/candidate."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sdk-version-skew-record-only",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sdk-version-skew-record-only"
      }), "SDK-version skew (record only)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Pins ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "@immediately-run/sdk"
      }), " at ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "0.8.1"
        })
      }), " (fleet spread: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "0.2.8"
      }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "0.8.1"
      }), " /\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "0.11.0"
      }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "^0.12.0"
      }), "). Coordinated fleet bump is owed; do not bump here."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "claudemd-scaffold-conformance-verified",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "claudemd-scaffold-conformance-verified"
      }), "CLAUDE.md / scaffold conformance (verified)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Confirm at execution: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/App.tsx"
      }), " is the entry (CSS imported from it, not\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "main.tsx"
      }), "), MDX shim wired (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/mdx.d.ts"
      }), "). The CLAUDE.md \"Editing: delegate to\nthe platform editor\" section is consistent with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "EDITOR_FIRST_EDITING_SPEC"
      }), ".\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "dev/fsSmokeTest.ts"
      }), " (if present) must be dev-only, not in the rendered tree."]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/REFACTOR_CANDIDATES.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJjb2RlIiwiZW0iLCJoMSIsImgyIiwicCIsInN0cm9uZyIsIl9wcm92aWRlQ29tcG9uZW50cyIsImNvbXBvbmVudHMiLCJIZWFkaW5nQW5jaG9yIiwiX21pc3NpbmdNZHhSZWZlcmVuY2UiLCJqc3hzIiwiRnJhZ21lbnQiLCJjaGlsZHJlbiIsImlkIiwianN4IiwiTURYQ29udGVudCIsIndyYXBwZXIiLCJNRFhMYXlvdXQiLCJfYyIsImNvbXBvbmVudCIsInBsYWNlIiwiRXJyb3IiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJSRUZBQ1RPUl9DQU5ESURBVEVTLm1kIl0sInNvdXJjZXNDb250ZW50IjpbIi8qQGpzeFJ1bnRpbWUgYXV0b21hdGljKi9cbi8qQGpzeEltcG9ydFNvdXJjZSByZWFjdCovXG5pbXBvcnQge3VzZU1EWENvbXBvbmVudHMgYXMgX3Byb3ZpZGVDb21wb25lbnRzfSBmcm9tIFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGsvTURYUHJvdmlkZXJcIjtcbmZ1bmN0aW9uIF9jcmVhdGVNZHhDb250ZW50KHByb3BzKSB7XG4gIGNvbnN0IF9jb21wb25lbnRzID0ge1xuICAgIGNvZGU6IFwiY29kZVwiLFxuICAgIGVtOiBcImVtXCIsXG4gICAgaDE6IFwiaDFcIixcbiAgICBoMjogXCJoMlwiLFxuICAgIHA6IFwicFwiLFxuICAgIHN0cm9uZzogXCJzdHJvbmdcIixcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH0sIHtIZWFkaW5nQW5jaG9yfSA9IF9jb21wb25lbnRzO1xuICBpZiAoIUhlYWRpbmdBbmNob3IpIF9taXNzaW5nTWR4UmVmZXJlbmNlKFwiSGVhZGluZ0FuY2hvclwiLCB0cnVlKTtcbiAgcmV0dXJuIDw+PF9jb21wb25lbnRzLmgxIGlkPVwicmVmYWN0b3ItZmluZGluZ3MtbmV3LXByb2plY3QtdGVtcGxhdGVcIj48SGVhZGluZ0FuY2hvciBpZD1cInJlZmFjdG9yLWZpbmRpbmdzLW5ldy1wcm9qZWN0LXRlbXBsYXRlXCIgLz57XCJSRUZBQ1RPUiAvIEZJTkRJTkdTIOKAlCBuZXctcHJvamVjdC10ZW1wbGF0ZVwifTwvX2NvbXBvbmVudHMuaDE+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiUmVjb3JkZWQgYnkgdGhlIDIwMjYtMDYgY29kZS12ZXJpZmljYXRpb24gcGFzcyAoUjMtMTI0OyBwbGFuIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjA4LXN5c3RlbS1hcHBzLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikuXFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJSZWNvcmQgb25seSDigJQgbm90aGluZyBhY3Rpb25lZC5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhpcyBpcyB0aGUgc2NhZmZvbGQgZXZlcnkgXFxcIkNyZWF0ZVxcXCIgYXBwIGZvcmtzLFxcbnNvIGl0IGhhcyAwIHNwZWMtcmVmcyBieSBkZXNpZ24gKGl0IGlzIHRoZSBzdGFydGluZyBwb2ludCkgYW5kIGEgdmlvbGF0aW9uIGhlcmVcXG53b3VsZCBiZSBoaWdoLXNpZ25hbC5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLXIzXCIgZGF0YS1zbHVnPVwicjMtMTIyLXNjaGVtYS1vbi10aGUtaW1tZWRpYXRlbHlydW4tbWFuaWZlc3QtZmllbGQtYmxvY2tlZC1yZWNvcmRcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy1yM1wiIC8+e1wiUjMtMTIyIOKAlCBcIn08X2NvbXBvbmVudHMuY29kZT57XCIkc2NoZW1hXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBvbiB0aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW1tZWRpYXRlbHkucnVuXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBtYW5pZmVzdCBmaWVsZCAoQkxPQ0tFRCwgcmVjb3JkKVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLmNvZGU+e1wicGFja2FnZS5qc29uXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBoYXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJubyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJpbW1lZGlhdGVseS5ydW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNvbmZpZyBvYmplY3QgYXQgYWxsXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICh0aGUgZmllbGQgaXNcXG5hYnNlbnQpLCBzbyB0aGVyZSBpcyBubyBcIn08X2NvbXBvbmVudHMuY29kZT57XCIkc2NoZW1hXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBlaXRoZXIuIFIzLTEyMidzIGV4aXQgY3JpdGVyaW9uIGluY2x1ZGVzXFxuXFxcIlwifTxfY29tcG9uZW50cy5jb2RlPntcIiRzY2hlbWFcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHJlZmVyZW5jZWQgaW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibmV3LXByb2plY3QtdGVtcGxhdGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxcIi5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJTdGF0dXM6IGJsb2NrZWQgb24gdGhlIHNpdGUtbWFpbiBoYWxmLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGUgdGVtcGxhdGUgaXMgdGhlIFwifTxfY29tcG9uZW50cy5lbT57XCJjb25zdW1lclwifTwvX2NvbXBvbmVudHMuZW0+e1wiIG9mIGFcXG5nZW5lcmF0ZWQgSlNPTiBTY2hlbWEgdGhhdCBzaXRlLW1haW4gbXVzdCBwdWJsaXNoIGZpcnN0ICh0aGUgc2NoZW1hIGlzIGdlbmVyYXRlZFxcbmZyb20gKyBkcmlmdC1nYXRlZCBhZ2FpbnN0IHRoZSBab2Qgc291cmNlIG9mIHRydXRoIFwifTxfY29tcG9uZW50cy5jb2RlPntcImltbWVkaWF0ZWx5UnVuQ29uZmlnLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikuIE5vXFxucHVibGlzaGVkIHNjaGVtYSBVUkwgZXhpc3RzIGluIHRoaXMgZW52aXJvbm1lbnQgKHNpdGUtbWFpbiBpcyBub3QgaW4gdGhpc1xcbmNoZWNrb3V0KS4gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJEbyBOT1QgaW52ZW50IGEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiJHNjaGVtYVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgVVJMLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBXaGVuIHNpdGUtbWFpbiBwdWJsaXNoZXMgdGhlIHNjaGVtYVxcblVSTCwgYWRkaW5nIHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCIkc2NoZW1hXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBsaW5lIChhbmQgYSBtaW5pbWFsIFwifTxfY29tcG9uZW50cy5jb2RlPntcImltbWVkaWF0ZWx5LnJ1blwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgb2JqZWN0IHRvIGhhbmcgaXRcXG5vbikgaXMgYSBvbmUtbGluZSBjaGFuZ2UgZ2F0ZWQgb24gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibnBtIHJ1biBidWlsZCAmJiBucG0gcnVuIGxpbnRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCLihpIgUm9hZG1hcCBkZXBlbmRlbmN5OiB0ZW1wbGF0ZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCIkc2NoZW1hXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBsYW5kcyB3aGVuIHRoZSBwdWJsaXNoZWQgc2NoZW1hIFVSTCBleGlzdHMuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInRlc3QtdG9vbGNoYWluLXNjYWZmb2xkLWRlbHRhLXByb3Bvc2VkdW5zY2hlZHVsZWQtcmVjb3JkXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJ0ZXN0LXRvb2xjaGFpbi1zY2FmZm9sZC1kZWx0YS1wcm9wb3NlZHVuc2NoZWR1bGVkLXJlY29yZFwiIC8+e1wiVGVzdC10b29sY2hhaW4gc2NhZmZvbGQgZGVsdGEgKHByb3Bvc2VkL3Vuc2NoZWR1bGVkLCByZWNvcmQpXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgdGVtcGxhdGUgc2hpcHMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJubyB0ZXN0IHNldHVwXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBubyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ2aXRlc3RcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGRlcCwgbm8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widGVzdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgc2NyaXB0LCBub1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy90ZXN0L1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIHVubGlrZSBmaWxlLWV4cGxvcmVyIC8gYWdlbnQtZGVtbyAod2hpY2ggY2FycnkgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widml0ZXN0IF40LjEuOFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgK1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcIlxcXCJ0ZXN0XFxcIjogXFxcInZpdGVzdCBydW5cXFwiXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikuIFRoZSBBUFBfT05CT0FSRElORyAvIGZ1dHVyZSB0ZXN0LXRvb2xjaGFpbiBkZWx0YSBwcm9wb3Nlc1xcbnRoZSBzY2FmZm9sZCBpbmNsdWRlIGEgc2Vzc2lvbi1ydW5uYWJsZSB0ZXN0IHRvb2xjaGFpbiAodml0ZXN0ICsgYVxcblNlc3Npb25TdGFydC1ob29rLWZyaWVuZGx5IFwifTxfY29tcG9uZW50cy5jb2RlPntcIm5wbSB0ZXN0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikgc28gQ3JlYXRlZCBhcHBzIGNhbiBydW4gdGVzdHMgaW4gd2ViXFxuc2Vzc2lvbnMgKGNyb3NzLXJlZiB0aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic2Vzc2lvbi1zdGFydC1ob29rXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBza2lsbCDigJQgdGhlIG1lY2hhbmlzbSB0aGF0IGVuc3VyZXNcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJucG0gdGVzdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvbGludCBydW4gaW4gd2ViIHNlc3Npb25zKS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJTdGF0dXM6IHByb3Bvc2VkLCB1bnNjaGVkdWxlZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoQVBQX09OQk9BUkRJTkdfU1BFQyBpcyBhIHByb3Bvc2FsIHdpdGggbm9cXG5zdGF0dXMgZG9jKS4gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJEbyBOT1Qgc2NhZmZvbGQgdGVzdHMgaW4gdGhpcyBwYXNzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCByZWNvcmRlZCBhcyBhIGdhcC9jYW5kaWRhdGUuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInNkay12ZXJzaW9uLXNrZXctcmVjb3JkLW9ubHlcIj48SGVhZGluZ0FuY2hvciBpZD1cInNkay12ZXJzaW9uLXNrZXctcmVjb3JkLW9ubHlcIiAvPntcIlNESy12ZXJzaW9uIHNrZXcgKHJlY29yZCBvbmx5KVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiUGlucyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJAaW1tZWRpYXRlbHktcnVuL3Nka1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYXQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz48X2NvbXBvbmVudHMuY29kZT57XCIwLjguMVwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnN0cm9uZz57XCIgKGZsZWV0IHNwcmVhZDogXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiMC4yLjhcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIC8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiMC44LjFcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIC9cXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCIwLjExLjBcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIC8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiXjAuMTIuMFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLiBDb29yZGluYXRlZCBmbGVldCBidW1wIGlzIG93ZWQ7IGRvIG5vdCBidW1wIGhlcmUuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cImNsYXVkZW1kLXNjYWZmb2xkLWNvbmZvcm1hbmNlLXZlcmlmaWVkXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJjbGF1ZGVtZC1zY2FmZm9sZC1jb25mb3JtYW5jZS12ZXJpZmllZFwiIC8+e1wiQ0xBVURFLm1kIC8gc2NhZmZvbGQgY29uZm9ybWFuY2UgKHZlcmlmaWVkKVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiQ29uZmlybSBhdCBleGVjdXRpb246IFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9BcHAudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpcyB0aGUgZW50cnkgKENTUyBpbXBvcnRlZCBmcm9tIGl0LCBub3RcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJtYWluLnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLCBNRFggc2hpbSB3aXJlZCAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL21keC5kLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikuIFRoZSBDTEFVREUubWQgXFxcIkVkaXRpbmc6IGRlbGVnYXRlIHRvXFxudGhlIHBsYXRmb3JtIGVkaXRvclxcXCIgc2VjdGlvbiBpcyBjb25zaXN0ZW50IHdpdGggXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRURJVE9SX0ZJUlNUX0VESVRJTkdfU1BFQ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIuXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZGV2L2ZzU21va2VUZXN0LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoaWYgcHJlc2VudCkgbXVzdCBiZSBkZXYtb25seSwgbm90IGluIHRoZSByZW5kZXJlZCB0cmVlLlwifTwvX2NvbXBvbmVudHMucD48Lz47XG59XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNRFhDb250ZW50KHByb3BzID0ge30pIHtcbiAgY29uc3Qge3dyYXBwZXI6IE1EWExheW91dH0gPSB7XG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9O1xuICByZXR1cm4gTURYTGF5b3V0ID8gPE1EWExheW91dCB7Li4ucHJvcHN9PjxfY3JlYXRlTWR4Q29udGVudCB7Li4ucHJvcHN9IC8+PC9NRFhMYXlvdXQ+IDogX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpO1xufVxuZnVuY3Rpb24gX21pc3NpbmdNZHhSZWZlcmVuY2UoaWQsIGNvbXBvbmVudCwgcGxhY2UpIHtcbiAgdGhyb3cgbmV3IEVycm9yKFwiRXhwZWN0ZWQgXCIgKyAoY29tcG9uZW50ID8gXCJjb21wb25lbnRcIiA6IFwib2JqZWN0XCIpICsgXCIgYFwiICsgaWQgKyBcImAgdG8gYmUgZGVmaW5lZDogeW91IGxpa2VseSBmb3Jnb3QgdG8gaW1wb3J0LCBwYXNzLCBvciBwcm92aWRlIGl0LlwiICsgKHBsYWNlID8gXCJcXG5JdOKAmXMgcmVmZXJlbmNlZCBpbiB5b3VyIGNvZGUgYXQgYFwiICsgcGxhY2UgKyBcImAgaW4gYC9hcHAvUkVGQUNUT1JfQ0FORElEQVRFUy5tZGBcIiA6IFwiXCIpKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQXdGLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUZ4RjtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU1DLFdBQVcsR0FBRztNQUNsQkMsSUFBSSxFQUFFLE1BQU07TUFDWkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsTUFBTSxFQUFFLFFBQVE7TUFDaEIsR0FBRyxJQUFBQyw2QkFBa0IsRUFBQyxDQUFDO01BQ3ZCLEdBQUdSLEtBQUssQ0FBQ1M7SUFDWCxDQUFDO0lBQUU7TUFBQ0M7SUFBYSxDQUFDLEdBQUdULFdBQVc7RUFDaEMsSUFBSSxDQUFDUyxhQUFhLEVBQUVDLG9CQUFvQixDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUM7RUFDL0Qsb0JBQU8sSUFBQWIsV0FBQSxDQUFBYyxJQUFBLEVBQUFkLFdBQUEsQ0FBQWUsUUFBQTtJQUFBQyxRQUFBLGdCQUFFLElBQUFoQixXQUFBLENBQUFjLElBQUEsRUFBQ1gsV0FBVyxDQUFDRyxFQUFFO01BQUNXLEVBQUUsRUFBQyx3Q0FBd0M7TUFBQUQsUUFBQSxnQkFBQyxJQUFBaEIsV0FBQSxDQUFBa0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUF3QyxDQUFFLENBQUMsRUFBQyw0Q0FBNEM7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFqQixXQUFBLENBQUFjLElBQUEsRUFBQ1gsV0FBVyxDQUFDSyxDQUFDO01BQUFRLFFBQUEsR0FBRSwrREFBK0QsZUFBQyxJQUFBaEIsV0FBQSxDQUFBa0IsR0FBQSxFQUFDZixXQUFXLENBQUNDLElBQUk7UUFBQVksUUFBQSxFQUFFO01BQW1CLENBQW1CLENBQUMsRUFBQyxNQUFNLGVBQUMsSUFBQWhCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ2YsV0FBVyxDQUFDTSxNQUFNO1FBQUFPLFFBQUEsRUFBRTtNQUFpQyxDQUFxQixDQUFDLEVBQUMsMkpBQTJKO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBaEIsV0FBQSxDQUFBYyxJQUFBLEVBQUNYLFdBQVcsQ0FBQ0ksRUFBRTtNQUFDVSxFQUFFLEVBQUMsUUFBUTtNQUFDLGFBQVUsbUVBQW1FO01BQUFELFFBQUEsZ0JBQUMsSUFBQWhCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBUSxDQUFFLENBQUMsRUFBQyxXQUFXLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ2YsV0FBVyxDQUFDQyxJQUFJO1FBQUFZLFFBQUEsRUFBRTtNQUFTLENBQW1CLENBQUMsRUFBQyxVQUFVLGVBQUMsSUFBQWhCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ2YsV0FBVyxDQUFDQyxJQUFJO1FBQUFZLFFBQUEsRUFBRTtNQUFpQixDQUFtQixDQUFDLEVBQUMsbUNBQW1DO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBaEIsV0FBQSxDQUFBYyxJQUFBLEVBQUNYLFdBQVcsQ0FBQ0ssQ0FBQztNQUFBUSxRQUFBLGdCQUFDLElBQUFoQixXQUFBLENBQUFrQixHQUFBLEVBQUNmLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBWSxRQUFBLEVBQUU7TUFBYyxDQUFtQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUFoQixXQUFBLENBQUFjLElBQUEsRUFBQ1gsV0FBVyxDQUFDTSxNQUFNO1FBQUFPLFFBQUEsR0FBRSxLQUFLLGVBQUMsSUFBQWhCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ2YsV0FBVyxDQUFDQyxJQUFJO1VBQUFZLFFBQUEsRUFBRTtRQUFpQixDQUFtQixDQUFDLEVBQUMsdUJBQXVCO01BQUEsQ0FBcUIsQ0FBQyxFQUFDLDBDQUEwQyxlQUFDLElBQUFoQixXQUFBLENBQUFrQixHQUFBLEVBQUNmLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBWSxRQUFBLEVBQUU7TUFBUyxDQUFtQixDQUFDLEVBQUMsK0NBQStDLGVBQUMsSUFBQWhCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ2YsV0FBVyxDQUFDQyxJQUFJO1FBQUFZLFFBQUEsRUFBRTtNQUFTLENBQW1CLENBQUMsRUFBQyxpQkFBaUIsZUFBQyxJQUFBaEIsV0FBQSxDQUFBa0IsR0FBQSxFQUFDZixXQUFXLENBQUNDLElBQUk7UUFBQVksUUFBQSxFQUFFO01BQXNCLENBQW1CLENBQUMsRUFBQyxLQUFLO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBaEIsV0FBQSxDQUFBYyxJQUFBLEVBQUNYLFdBQVcsQ0FBQ0ssQ0FBQztNQUFBUSxRQUFBLGdCQUFDLElBQUFoQixXQUFBLENBQUFrQixHQUFBLEVBQUNmLFdBQVcsQ0FBQ00sTUFBTTtRQUFBTyxRQUFBLEVBQUU7TUFBd0MsQ0FBcUIsQ0FBQyxFQUFDLHVCQUF1QixlQUFDLElBQUFoQixXQUFBLENBQUFrQixHQUFBLEVBQUNmLFdBQVcsQ0FBQ0UsRUFBRTtRQUFBVyxRQUFBLEVBQUU7TUFBVSxDQUFpQixDQUFDLEVBQUMsOElBQThJLGVBQUMsSUFBQWhCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ2YsV0FBVyxDQUFDQyxJQUFJO1FBQUFZLFFBQUEsRUFBRTtNQUF5QixDQUFtQixDQUFDLEVBQUMsK0ZBQStGLGVBQUMsSUFBQWhCLFdBQUEsQ0FBQWMsSUFBQSxFQUFDWCxXQUFXLENBQUNNLE1BQU07UUFBQU8sUUFBQSxHQUFFLGtCQUFrQixlQUFDLElBQUFoQixXQUFBLENBQUFrQixHQUFBLEVBQUNmLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBWSxRQUFBLEVBQUU7UUFBUyxDQUFtQixDQUFDLEVBQUMsT0FBTztNQUFBLENBQXFCLENBQUMsRUFBQyx3REFBd0QsZUFBQyxJQUFBaEIsV0FBQSxDQUFBa0IsR0FBQSxFQUFDZixXQUFXLENBQUNDLElBQUk7UUFBQVksUUFBQSxFQUFFO01BQVMsQ0FBbUIsQ0FBQyxFQUFDLHVCQUF1QixlQUFDLElBQUFoQixXQUFBLENBQUFrQixHQUFBLEVBQUNmLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBWSxRQUFBLEVBQUU7TUFBaUIsQ0FBbUIsQ0FBQyxFQUFDLHdEQUF3RCxlQUFDLElBQUFoQixXQUFBLENBQUFrQixHQUFBLEVBQUNmLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBWSxRQUFBLEVBQUU7TUFBK0IsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFoQixXQUFBLENBQUFjLElBQUEsRUFBQ1gsV0FBVyxDQUFDSyxDQUFDO01BQUFRLFFBQUEsR0FBRSxpQ0FBaUMsZUFBQyxJQUFBaEIsV0FBQSxDQUFBa0IsR0FBQSxFQUFDZixXQUFXLENBQUNDLElBQUk7UUFBQVksUUFBQSxFQUFFO01BQVMsQ0FBbUIsQ0FBQyxFQUFDLDhDQUE4QztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWhCLFdBQUEsQ0FBQWMsSUFBQSxFQUFDWCxXQUFXLENBQUNJLEVBQUU7TUFBQ1UsRUFBRSxFQUFDLDBEQUEwRDtNQUFBRCxRQUFBLGdCQUFDLElBQUFoQixXQUFBLENBQUFrQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQTBELENBQUUsQ0FBQyxFQUFDLDhEQUE4RDtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWpCLFdBQUEsQ0FBQWMsSUFBQSxFQUFDWCxXQUFXLENBQUNLLENBQUM7TUFBQVEsUUFBQSxHQUFFLHFCQUFxQixlQUFDLElBQUFoQixXQUFBLENBQUFrQixHQUFBLEVBQUNmLFdBQVcsQ0FBQ00sTUFBTTtRQUFBTyxRQUFBLEVBQUU7TUFBZSxDQUFxQixDQUFDLEVBQUMsUUFBUSxlQUFDLElBQUFoQixXQUFBLENBQUFrQixHQUFBLEVBQUNmLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBWSxRQUFBLEVBQUU7TUFBUSxDQUFtQixDQUFDLEVBQUMsV0FBVyxlQUFDLElBQUFoQixXQUFBLENBQUFrQixHQUFBLEVBQUNmLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBWSxRQUFBLEVBQUU7TUFBTSxDQUFtQixDQUFDLEVBQUMsZUFBZSxlQUFDLElBQUFoQixXQUFBLENBQUFrQixHQUFBLEVBQUNmLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBWSxRQUFBLEVBQUU7TUFBVyxDQUFtQixDQUFDLEVBQUMsb0RBQW9ELGVBQUMsSUFBQWhCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ2YsV0FBVyxDQUFDQyxJQUFJO1FBQUFZLFFBQUEsRUFBRTtNQUFlLENBQW1CLENBQUMsRUFBQyxNQUFNLGVBQUMsSUFBQWhCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ2YsV0FBVyxDQUFDQyxJQUFJO1FBQUFZLFFBQUEsRUFBRTtNQUEwQixDQUFtQixDQUFDLEVBQUMsK0pBQStKLGVBQUMsSUFBQWhCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ2YsV0FBVyxDQUFDQyxJQUFJO1FBQUFZLFFBQUEsRUFBRTtNQUFVLENBQW1CLENBQUMsRUFBQyxrRUFBa0UsZUFBQyxJQUFBaEIsV0FBQSxDQUFBa0IsR0FBQSxFQUFDZixXQUFXLENBQUNDLElBQUk7UUFBQVksUUFBQSxFQUFFO01BQW9CLENBQW1CLENBQUMsRUFBQyx1Q0FBdUMsZUFBQyxJQUFBaEIsV0FBQSxDQUFBa0IsR0FBQSxFQUFDZixXQUFXLENBQUNDLElBQUk7UUFBQVksUUFBQSxFQUFFO01BQVUsQ0FBbUIsQ0FBQyxFQUFDLDZCQUE2QjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQWhCLFdBQUEsQ0FBQWMsSUFBQSxFQUFDWCxXQUFXLENBQUNLLENBQUM7TUFBQVEsUUFBQSxnQkFBQyxJQUFBaEIsV0FBQSxDQUFBa0IsR0FBQSxFQUFDZixXQUFXLENBQUNNLE1BQU07UUFBQU8sUUFBQSxFQUFFO01BQStCLENBQXFCLENBQUMsRUFBQyw0REFBNEQsZUFBQyxJQUFBaEIsV0FBQSxDQUFBa0IsR0FBQSxFQUFDZixXQUFXLENBQUNNLE1BQU07UUFBQU8sUUFBQSxFQUFFO01BQW9DLENBQXFCLENBQUMsRUFBQyxpQ0FBaUM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFoQixXQUFBLENBQUFjLElBQUEsRUFBQ1gsV0FBVyxDQUFDSSxFQUFFO01BQUNVLEVBQUUsRUFBQyw4QkFBOEI7TUFBQUQsUUFBQSxnQkFBQyxJQUFBaEIsV0FBQSxDQUFBa0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUE4QixDQUFFLENBQUMsRUFBQyxnQ0FBZ0M7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFqQixXQUFBLENBQUFjLElBQUEsRUFBQ1gsV0FBVyxDQUFDSyxDQUFDO01BQUFRLFFBQUEsR0FBRSxPQUFPLGVBQUMsSUFBQWhCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ2YsV0FBVyxDQUFDQyxJQUFJO1FBQUFZLFFBQUEsRUFBRTtNQUFzQixDQUFtQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUFoQixXQUFBLENBQUFrQixHQUFBLEVBQUNmLFdBQVcsQ0FBQ00sTUFBTTtRQUFBTyxRQUFBLGVBQUMsSUFBQWhCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ2YsV0FBVyxDQUFDQyxJQUFJO1VBQUFZLFFBQUEsRUFBRTtRQUFPLENBQW1CO01BQUMsQ0FBb0IsQ0FBQyxFQUFDLGtCQUFrQixlQUFDLElBQUFoQixXQUFBLENBQUFrQixHQUFBLEVBQUNmLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBWSxRQUFBLEVBQUU7TUFBTyxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUFoQixXQUFBLENBQUFrQixHQUFBLEVBQUNmLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBWSxRQUFBLEVBQUU7TUFBTyxDQUFtQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUFoQixXQUFBLENBQUFrQixHQUFBLEVBQUNmLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBWSxRQUFBLEVBQUU7TUFBUSxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUFoQixXQUFBLENBQUFrQixHQUFBLEVBQUNmLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBWSxRQUFBLEVBQUU7TUFBUyxDQUFtQixDQUFDLEVBQUMsc0RBQXNEO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBaEIsV0FBQSxDQUFBYyxJQUFBLEVBQUNYLFdBQVcsQ0FBQ0ksRUFBRTtNQUFDVSxFQUFFLEVBQUMsd0NBQXdDO01BQUFELFFBQUEsZ0JBQUMsSUFBQWhCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBd0MsQ0FBRSxDQUFDLEVBQUMsNkNBQTZDO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBakIsV0FBQSxDQUFBYyxJQUFBLEVBQUNYLFdBQVcsQ0FBQ0ssQ0FBQztNQUFBUSxRQUFBLEdBQUUsd0JBQXdCLGVBQUMsSUFBQWhCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ2YsV0FBVyxDQUFDQyxJQUFJO1FBQUFZLFFBQUEsRUFBRTtNQUFhLENBQW1CLENBQUMsRUFBQyw0Q0FBNEMsZUFBQyxJQUFBaEIsV0FBQSxDQUFBa0IsR0FBQSxFQUFDZixXQUFXLENBQUNDLElBQUk7UUFBQVksUUFBQSxFQUFFO01BQVUsQ0FBbUIsQ0FBQyxFQUFDLHFCQUFxQixlQUFDLElBQUFoQixXQUFBLENBQUFrQixHQUFBLEVBQUNmLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBWSxRQUFBLEVBQUU7TUFBYyxDQUFtQixDQUFDLEVBQUMsNEZBQTRGLGVBQUMsSUFBQWhCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ2YsV0FBVyxDQUFDQyxJQUFJO1FBQUFZLFFBQUEsRUFBRTtNQUEyQixDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUFoQixXQUFBLENBQUFrQixHQUFBLEVBQUNmLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBWSxRQUFBLEVBQUU7TUFBb0IsQ0FBbUIsQ0FBQyxFQUFDLDJEQUEyRDtJQUFBLENBQWdCLENBQUM7RUFBQSxDQUFFLENBQUM7QUFDL3hLO0FBQ2UsU0FBU0csVUFBVUEsQ0FBQ2pCLEtBQUssR0FBRyxDQUFDLENBQUMsRUFBRTtFQUM3QyxNQUFNO0lBQUNrQixPQUFPLEVBQUVDO0VBQVMsQ0FBQyxHQUFHO0lBQzNCLEdBQUcsSUFBQVgsNkJBQWtCLEVBQUMsQ0FBQztJQUN2QixHQUFHUixLQUFLLENBQUNTO0VBQ1gsQ0FBQztFQUNELE9BQU9VLFNBQVMsZ0JBQUcsSUFBQXJCLFdBQUEsQ0FBQWtCLEdBQUEsRUFBQ0csU0FBUztJQUFBLEdBQUtuQixLQUFLO0lBQUFjLFFBQUEsZUFBRSxJQUFBaEIsV0FBQSxDQUFBa0IsR0FBQSxFQUFDakIsaUJBQWlCO01BQUEsR0FBS0M7SUFBSyxDQUFHO0VBQUMsQ0FBVyxDQUFDLEdBQUdELGlCQUFpQixDQUFDQyxLQUFLLENBQUM7QUFDbEg7QUFBQ29CLEVBQUEsR0FOdUJILFVBQVU7QUFPbEMsU0FBU04sb0JBQW9CQSxDQUFDSSxFQUFFLEVBQUVNLFNBQVMsRUFBRUMsS0FBSyxFQUFFO0VBQ2xELE1BQU0sSUFBSUMsS0FBSyxDQUFDLFdBQVcsSUFBSUYsU0FBUyxHQUFHLFdBQVcsR0FBRyxRQUFRLENBQUMsR0FBRyxJQUFJLEdBQUdOLEVBQUUsR0FBRyxvRUFBb0UsSUFBSU8sS0FBSyxHQUFHLHFDQUFxQyxHQUFHQSxLQUFLLEdBQUcsb0NBQW9DLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDOVA7QUFBQyxJQUFBRixFQUFBO0FBQUFJLFlBQUEsQ0FBQUosRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}