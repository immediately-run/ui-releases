var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      blockquote: "blockquote",
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      h3: "h3",
      li: "li",
      ol: "ol",
      p: "p",
      pre: "pre",
      strong: "strong",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "immediatelyrun-starter-template",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "immediatelyrun-starter-template"
      }), "immediately.run — starter template"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["A ready-to-run starter for building apps on\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "https://immediately.run",
        children: "immediately.run"
      }), ": React + TypeScript + Vite, wired to\nthe brand design system, with the project layout immediately.run expects."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "try-it-instantly",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "try-it-instantly"
      }), "Try it instantly"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Try this template on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "https://immediately.run/present/github/immediately-run/new-project-template/main/files/src/App.tsx",
        children: "immediately.run"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The Reckoner demo documents also run from this repo's main (zip-cached, no GitHub API\ndependency): the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "https://immediately.run/present/github/immediately-run/reckoner/main/",
        children: "Meridian monthly review"
      }), "\n(the default) and the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "https://immediately.run/present/github/immediately-run/reckoner/main/caldera",
        children: "Caldera LBO workbook"
      }), ".\n(The platform-usage workbook lives in its own repo, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "https://github.com/immediately-run/usage-workbook",
        children: "immediately-run/usage-workbook"
      }), ".)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Each document has its own path, and the switcher above the title moves between them —\nthe outer address bar follows, so Back works and a link is worth copying. The older\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "…/files/src/App.tsx?doc=caldera"
      }), " form still resolves; the path form is the one to share."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: ["Using this as a starting point for your own app? After you push to your repo,\nupdate the link above to\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "https://immediately.run/present/github/<owner>/<repo>/<ref>/files/src/App.tsx"
        }), "."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "use-this-template",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "use-this-template"
      }), "Use this template"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: "Create a new repo from this template (or copy the files)."
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npm install"
        })
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npm run dev"
        }), " and start editing ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/App.tsx"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: "Push to GitHub and open it on immediately.run with the link above."
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "fast-loading-on-immediatelyrun-auto-cache",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "fast-loading-on-immediatelyrun-auto-cache"
      }), "Fast loading on immediately.run (auto-cache)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["immediately.run normally reads your sources from the GitHub API, which is slow\nand rate-limited for anonymous visitors. This template ships a GitHub Action\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "./.github/workflows/cache.yml",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".github/workflows/cache.yml"
        })
      }), ") that, on every\npush to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "main"
      }), ", builds a pre-cached zip of your repo and publishes it to your\nrepo's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "own GitHub Pages"
      }), ". immediately.run finds it automatically at\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "https://<owner>.github.io/<repo>/cached_repositories/main.zip"
      }), " and loads from\nthere — falling back to the API if it's missing."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "The cache also embeds a manifest sidecar, so visitors can push edits back to\nGitHub even when the app was loaded from the zip."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "enable-the-cache-one-time",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "enable-the-cache-one-time"
      }), "Enable the cache (one-time)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["For a repo in your ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "own"
      }), " GitHub account or org, there's a single one-time step:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Settings → Pages → Build and deployment → Source: GitHub Actions."
        })
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["Push to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "main"
        }), " (or re-run the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Cache for immediately.run"
        }), " workflow from the\nActions tab)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["That's it — no tokens and no secrets to configure. The workflow builds the zip and\npublishes it to your repo's Pages; immediately.run finds it automatically on the\nnext load. The first publish can lag a push by up to ~10 minutes of GitHub Pages\nCDN caching. If the app still loads from the API, check that the workflow run\nsucceeded and that Pages shows a green ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "github-pages"
      }), " deployment."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "immediately-run org repos"
        }), " skip even that step: the org's internal ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "deploy\nGitHub App"
        }), " self-provisions Pages on the first run (it holds Pages +\nAdministration write and its ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "DEPLOY_APP_ID"
        }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "DEPLOY_APP_PRIVATE_KEY"
        }), " are org\nsecrets). That App is org-internal — repos outside the org neither have nor need\nit, and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "cache.yml"
        }), " automatically falls back to the manual step above."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "always-run-the-newest-commit",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "always-run-the-newest-commit"
      }), "Always run the newest commit"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["By default the cached version is served even if it's a few minutes behind\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "main"
      }), ". If your app must always reflect the very latest commit, add this to\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "package.json"
      }), ":"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-jsonc",
        children: "{\n  \"immediately.run\": {\n    \"requireLatest\": true\n  }\n}\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "immediately.run still boots instantly from the cache, then checks in the\nbackground (one API request) whether the cache is current and, if not, reloads\nfrom GitHub."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "how-its-organized",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "how-its-organized"
      }), "How it's organized"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["immediately.run renders the ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["default export of ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/App.tsx"
        })]
      }), " — that's the\nentry point, not ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "main.tsx"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/\n  main.tsx              # local vite dev/build entry only — immediately.run IGNORES this\n  App.tsx               # ROOT: default export + imports the global CSS\n  index.css             # fonts, design tokens (dark + light), resets\n  App.css               # layout + component styles\n  mdx.d.ts              # type shim so `import X from './x.mdx'` works\n  components/           # one default-exported React component per file\n  data/                 # typed data arrays (NO components/JSX here)\n  hooks/                # custom hooks (NO components here)\n  assets/               # images you import, e.g. import logo from './assets/logo.png'\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The included page shows the core patterns: a data array mapped to cards\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "data/features.ts"
      }), " → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "components/Features.tsx"
      }), "), a custom hook\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "hooks/useTheme.ts"
      }), " → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "components/ThemeSwitch.tsx"
      }), "), and local React state\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "components/Counter.tsx"
      }), ")."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "filesystem-access-fs",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "filesystem-access-fs"
      }), "Filesystem access (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "fs"
      }), ")"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["immediately.run apps can read and write a filesystem by importing ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "fs"
      }), " (async\nonly — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "fs.promises.*"
      }), " and callback style). This template has local-dev support\nfor it built in via ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "https://github.com/immediately-run/dev-fs",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "@immediately-run/dev-fs"
        })
      }), ",\na Vite plugin (already wired into ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "vite.config.ts"
      }), ") that bridges the same\nfilesystem to your real local disk during ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "vite dev"
      }), ". See that repo for the\nsupported API and details."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-ts",
        children: "import fs from 'fs'\n\nawait fs.promises.writeFile('/data/notes.txt', 'hello', 'utf8')\nconst text = await fs.promises.readFile('/data/notes.txt', 'utf8')\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "main.tsx"
      }), " runs a one-off round-trip smoke test in dev — check the browser\nconsole for the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "[dev-fs]"
      }), " group, and delete it freely."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "the-rules-that-keep-it-working-on-immediatelyrun",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-rules-that-keep-it-working-on-immediatelyrun"
      }), "The rules that keep it working on immediately.run"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["See ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "./CLAUDE.md",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "CLAUDE.md"
        })
      }), " for the full list. The essentials:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Global CSS is imported from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "App.tsx"
          }), ", never only from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "main.tsx"
          }), "."]
        })
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["A file that exports a component exports ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "only"
          }), " components"]
        }), " — data, consts,\nand helpers go in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "data/"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "hooks/"
        }), ", or ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "lib/"
        }), ". ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npm run lint"
        }), " enforces this."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Pull colors, fonts, radii, and shadows from the tokens in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "index.css"
          })]
        }), "\nrather than hard-coding values."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "develop",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "develop"
      }), "Develop"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Requires Node.js 20.19+ or 22.12+."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-bash",
        children: "npm install\nnpm run dev      # local dev server\nnpm run build    # tsc -b && vite build — must pass with no type errors\nnpm run lint     # eslint — enforces the React Fast Refresh / HMR rule\nnpm run preview  # serve the production build\n"
      })
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/README.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiYmxvY2txdW90ZSIsImNvZGUiLCJlbSIsImgxIiwiaDIiLCJoMyIsImxpIiwib2wiLCJwIiwicHJlIiwic3Ryb25nIiwidWwiLCJfcHJvdmlkZUNvbXBvbmVudHMiLCJjb21wb25lbnRzIiwiSGVhZGluZ0FuY2hvciIsIl9taXNzaW5nTWR4UmVmZXJlbmNlIiwianN4cyIsIkZyYWdtZW50IiwiY2hpbGRyZW4iLCJpZCIsImpzeCIsImhyZWYiLCJjbGFzc05hbWUiLCJNRFhDb250ZW50Iiwid3JhcHBlciIsIk1EWExheW91dCIsIl9jIiwiY29tcG9uZW50IiwicGxhY2UiLCJFcnJvciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlJFQURNRS5tZCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKkBqc3hSdW50aW1lIGF1dG9tYXRpYyovXG4vKkBqc3hJbXBvcnRTb3VyY2UgcmVhY3QqL1xuaW1wb3J0IHt1c2VNRFhDb21wb25lbnRzIGFzIF9wcm92aWRlQ29tcG9uZW50c30gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrL01EWFByb3ZpZGVyXCI7XG5mdW5jdGlvbiBfY3JlYXRlTWR4Q29udGVudChwcm9wcykge1xuICBjb25zdCBfY29tcG9uZW50cyA9IHtcbiAgICBhOiBcImFcIixcbiAgICBibG9ja3F1b3RlOiBcImJsb2NrcXVvdGVcIixcbiAgICBjb2RlOiBcImNvZGVcIixcbiAgICBlbTogXCJlbVwiLFxuICAgIGgxOiBcImgxXCIsXG4gICAgaDI6IFwiaDJcIixcbiAgICBoMzogXCJoM1wiLFxuICAgIGxpOiBcImxpXCIsXG4gICAgb2w6IFwib2xcIixcbiAgICBwOiBcInBcIixcbiAgICBwcmU6IFwicHJlXCIsXG4gICAgc3Ryb25nOiBcInN0cm9uZ1wiLFxuICAgIHVsOiBcInVsXCIsXG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9LCB7SGVhZGluZ0FuY2hvcn0gPSBfY29tcG9uZW50cztcbiAgaWYgKCFIZWFkaW5nQW5jaG9yKSBfbWlzc2luZ01keFJlZmVyZW5jZShcIkhlYWRpbmdBbmNob3JcIiwgdHJ1ZSk7XG4gIHJldHVybiA8PjxfY29tcG9uZW50cy5oMSBpZD1cImltbWVkaWF0ZWx5cnVuLXN0YXJ0ZXItdGVtcGxhdGVcIj48SGVhZGluZ0FuY2hvciBpZD1cImltbWVkaWF0ZWx5cnVuLXN0YXJ0ZXItdGVtcGxhdGVcIiAvPntcImltbWVkaWF0ZWx5LnJ1biDigJQgc3RhcnRlciB0ZW1wbGF0ZVwifTwvX2NvbXBvbmVudHMuaDE+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiQSByZWFkeS10by1ydW4gc3RhcnRlciBmb3IgYnVpbGRpbmcgYXBwcyBvblxcblwifTxfY29tcG9uZW50cy5hIGhyZWY9XCJodHRwczovL2ltbWVkaWF0ZWx5LnJ1blwiPntcImltbWVkaWF0ZWx5LnJ1blwifTwvX2NvbXBvbmVudHMuYT57XCI6IFJlYWN0ICsgVHlwZVNjcmlwdCArIFZpdGUsIHdpcmVkIHRvXFxudGhlIGJyYW5kIGRlc2lnbiBzeXN0ZW0sIHdpdGggdGhlIHByb2plY3QgbGF5b3V0IGltbWVkaWF0ZWx5LnJ1biBleHBlY3RzLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJ0cnktaXQtaW5zdGFudGx5XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJ0cnktaXQtaW5zdGFudGx5XCIgLz57XCJUcnkgaXQgaW5zdGFudGx5XCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUcnkgdGhpcyB0ZW1wbGF0ZSBvbiBcIn08X2NvbXBvbmVudHMuYSBocmVmPVwiaHR0cHM6Ly9pbW1lZGlhdGVseS5ydW4vcHJlc2VudC9naXRodWIvaW1tZWRpYXRlbHktcnVuL25ldy1wcm9qZWN0LXRlbXBsYXRlL21haW4vZmlsZXMvc3JjL0FwcC50c3hcIj57XCJpbW1lZGlhdGVseS5ydW5cIn08L19jb21wb25lbnRzLmE+PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSBSZWNrb25lciBkZW1vIGRvY3VtZW50cyBhbHNvIHJ1biBmcm9tIHRoaXMgcmVwbydzIG1haW4gKHppcC1jYWNoZWQsIG5vIEdpdEh1YiBBUElcXG5kZXBlbmRlbmN5KTogdGhlIFwifTxfY29tcG9uZW50cy5hIGhyZWY9XCJodHRwczovL2ltbWVkaWF0ZWx5LnJ1bi9wcmVzZW50L2dpdGh1Yi9pbW1lZGlhdGVseS1ydW4vcmVja29uZXIvbWFpbi9cIj57XCJNZXJpZGlhbiBtb250aGx5IHJldmlld1wifTwvX2NvbXBvbmVudHMuYT57XCJcXG4odGhlIGRlZmF1bHQpIGFuZCB0aGUgXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cImh0dHBzOi8vaW1tZWRpYXRlbHkucnVuL3ByZXNlbnQvZ2l0aHViL2ltbWVkaWF0ZWx5LXJ1bi9yZWNrb25lci9tYWluL2NhbGRlcmFcIj57XCJDYWxkZXJhIExCTyB3b3JrYm9va1wifTwvX2NvbXBvbmVudHMuYT57XCIuXFxuKFRoZSBwbGF0Zm9ybS11c2FnZSB3b3JrYm9vayBsaXZlcyBpbiBpdHMgb3duIHJlcG8sIFwifTxfY29tcG9uZW50cy5hIGhyZWY9XCJodHRwczovL2dpdGh1Yi5jb20vaW1tZWRpYXRlbHktcnVuL3VzYWdlLXdvcmtib29rXCI+e1wiaW1tZWRpYXRlbHktcnVuL3VzYWdlLXdvcmtib29rXCJ9PC9fY29tcG9uZW50cy5hPntcIi4pXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkVhY2ggZG9jdW1lbnQgaGFzIGl0cyBvd24gcGF0aCwgYW5kIHRoZSBzd2l0Y2hlciBhYm92ZSB0aGUgdGl0bGUgbW92ZXMgYmV0d2VlbiB0aGVtIOKAlFxcbnRoZSBvdXRlciBhZGRyZXNzIGJhciBmb2xsb3dzLCBzbyBCYWNrIHdvcmtzIGFuZCBhIGxpbmsgaXMgd29ydGggY29weWluZy4gVGhlIG9sZGVyXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wi4oCmL2ZpbGVzL3NyYy9BcHAudHN4P2RvYz1jYWxkZXJhXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBmb3JtIHN0aWxsIHJlc29sdmVzOyB0aGUgcGF0aCBmb3JtIGlzIHRoZSBvbmUgdG8gc2hhcmUuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlVzaW5nIHRoaXMgYXMgYSBzdGFydGluZyBwb2ludCBmb3IgeW91ciBvd24gYXBwPyBBZnRlciB5b3UgcHVzaCB0byB5b3VyIHJlcG8sXFxudXBkYXRlIHRoZSBsaW5rIGFib3ZlIHRvXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaHR0cHM6Ly9pbW1lZGlhdGVseS5ydW4vcHJlc2VudC9naXRodWIvPG93bmVyPi88cmVwbz4vPHJlZj4vZmlsZXMvc3JjL0FwcC50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08L19jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwidXNlLXRoaXMtdGVtcGxhdGVcIj48SGVhZGluZ0FuY2hvciBpZD1cInVzZS10aGlzLXRlbXBsYXRlXCIgLz57XCJVc2UgdGhpcyB0ZW1wbGF0ZVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJDcmVhdGUgYSBuZXcgcmVwbyBmcm9tIHRoaXMgdGVtcGxhdGUgKG9yIGNvcHkgdGhlIGZpbGVzKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuY29kZT57XCJucG0gaW5zdGFsbFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuY29kZT57XCJucG0gcnVuIGRldlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYW5kIHN0YXJ0IGVkaXRpbmcgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL0FwcC50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIlB1c2ggdG8gR2l0SHViIGFuZCBvcGVuIGl0IG9uIGltbWVkaWF0ZWx5LnJ1biB3aXRoIHRoZSBsaW5rIGFib3ZlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJmYXN0LWxvYWRpbmctb24taW1tZWRpYXRlbHlydW4tYXV0by1jYWNoZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiZmFzdC1sb2FkaW5nLW9uLWltbWVkaWF0ZWx5cnVuLWF1dG8tY2FjaGVcIiAvPntcIkZhc3QgbG9hZGluZyBvbiBpbW1lZGlhdGVseS5ydW4gKGF1dG8tY2FjaGUpXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJpbW1lZGlhdGVseS5ydW4gbm9ybWFsbHkgcmVhZHMgeW91ciBzb3VyY2VzIGZyb20gdGhlIEdpdEh1YiBBUEksIHdoaWNoIGlzIHNsb3dcXG5hbmQgcmF0ZS1saW1pdGVkIGZvciBhbm9ueW1vdXMgdmlzaXRvcnMuIFRoaXMgdGVtcGxhdGUgc2hpcHMgYSBHaXRIdWIgQWN0aW9uXFxuKFwifTxfY29tcG9uZW50cy5hIGhyZWY9XCIuLy5naXRodWIvd29ya2Zsb3dzL2NhY2hlLnltbFwiPjxfY29tcG9uZW50cy5jb2RlPntcIi5naXRodWIvd29ya2Zsb3dzL2NhY2hlLnltbFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLmE+e1wiKSB0aGF0LCBvbiBldmVyeVxcbnB1c2ggdG8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibWFpblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGJ1aWxkcyBhIHByZS1jYWNoZWQgemlwIG9mIHlvdXIgcmVwbyBhbmQgcHVibGlzaGVzIGl0IHRvIHlvdXJcXG5yZXBvJ3MgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJvd24gR2l0SHViIFBhZ2VzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLiBpbW1lZGlhdGVseS5ydW4gZmluZHMgaXQgYXV0b21hdGljYWxseSBhdFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcImh0dHBzOi8vPG93bmVyPi5naXRodWIuaW8vPHJlcG8+L2NhY2hlZF9yZXBvc2l0b3JpZXMvbWFpbi56aXBcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFuZCBsb2FkcyBmcm9tXFxudGhlcmUg4oCUIGZhbGxpbmcgYmFjayB0byB0aGUgQVBJIGlmIGl0J3MgbWlzc2luZy5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIGNhY2hlIGFsc28gZW1iZWRzIGEgbWFuaWZlc3Qgc2lkZWNhciwgc28gdmlzaXRvcnMgY2FuIHB1c2ggZWRpdHMgYmFjayB0b1xcbkdpdEh1YiBldmVuIHdoZW4gdGhlIGFwcCB3YXMgbG9hZGVkIGZyb20gdGhlIHppcC5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwiZW5hYmxlLXRoZS1jYWNoZS1vbmUtdGltZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiZW5hYmxlLXRoZS1jYWNoZS1vbmUtdGltZVwiIC8+e1wiRW5hYmxlIHRoZSBjYWNoZSAob25lLXRpbWUpXCJ9PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJGb3IgYSByZXBvIGluIHlvdXIgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJvd25cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgR2l0SHViIGFjY291bnQgb3Igb3JnLCB0aGVyZSdzIGEgc2luZ2xlIG9uZS10aW1lIHN0ZXA6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJTZXR0aW5ncyDihpIgUGFnZXMg4oaSIEJ1aWxkIGFuZCBkZXBsb3ltZW50IOKGkiBTb3VyY2U6IEdpdEh1YiBBY3Rpb25zLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIlB1c2ggdG8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibWFpblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKG9yIHJlLXJ1biB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJDYWNoZSBmb3IgaW1tZWRpYXRlbHkucnVuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHdvcmtmbG93IGZyb20gdGhlXFxuQWN0aW9ucyB0YWIpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGF0J3MgaXQg4oCUIG5vIHRva2VucyBhbmQgbm8gc2VjcmV0cyB0byBjb25maWd1cmUuIFRoZSB3b3JrZmxvdyBidWlsZHMgdGhlIHppcCBhbmRcXG5wdWJsaXNoZXMgaXQgdG8geW91ciByZXBvJ3MgUGFnZXM7IGltbWVkaWF0ZWx5LnJ1biBmaW5kcyBpdCBhdXRvbWF0aWNhbGx5IG9uIHRoZVxcbm5leHQgbG9hZC4gVGhlIGZpcnN0IHB1Ymxpc2ggY2FuIGxhZyBhIHB1c2ggYnkgdXAgdG8gfjEwIG1pbnV0ZXMgb2YgR2l0SHViIFBhZ2VzXFxuQ0ROIGNhY2hpbmcuIElmIHRoZSBhcHAgc3RpbGwgbG9hZHMgZnJvbSB0aGUgQVBJLCBjaGVjayB0aGF0IHRoZSB3b3JrZmxvdyBydW5cXG5zdWNjZWVkZWQgYW5kIHRoYXQgUGFnZXMgc2hvd3MgYSBncmVlbiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImdpdGh1Yi1wYWdlc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBkZXBsb3ltZW50LlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuYmxvY2txdW90ZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcImltbWVkaWF0ZWx5LXJ1biBvcmcgcmVwb3NcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgc2tpcCBldmVuIHRoYXQgc3RlcDogdGhlIG9yZydzIGludGVybmFsIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZGVwbG95XFxuR2l0SHViIEFwcFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBzZWxmLXByb3Zpc2lvbnMgUGFnZXMgb24gdGhlIGZpcnN0IHJ1biAoaXQgaG9sZHMgUGFnZXMgK1xcbkFkbWluaXN0cmF0aW9uIHdyaXRlIGFuZCBpdHMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiREVQTE9ZX0FQUF9JRFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgLyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJERVBMT1lfQVBQX1BSSVZBVEVfS0VZXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhcmUgb3JnXFxuc2VjcmV0cykuIFRoYXQgQXBwIGlzIG9yZy1pbnRlcm5hbCDigJQgcmVwb3Mgb3V0c2lkZSB0aGUgb3JnIG5laXRoZXIgaGF2ZSBub3IgbmVlZFxcbml0LCBhbmQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2FjaGUueW1sXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhdXRvbWF0aWNhbGx5IGZhbGxzIGJhY2sgdG8gdGhlIG1hbnVhbCBzdGVwIGFib3ZlLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08L19jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwiYWx3YXlzLXJ1bi10aGUtbmV3ZXN0LWNvbW1pdFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiYWx3YXlzLXJ1bi10aGUtbmV3ZXN0LWNvbW1pdFwiIC8+e1wiQWx3YXlzIHJ1biB0aGUgbmV3ZXN0IGNvbW1pdFwifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiQnkgZGVmYXVsdCB0aGUgY2FjaGVkIHZlcnNpb24gaXMgc2VydmVkIGV2ZW4gaWYgaXQncyBhIGZldyBtaW51dGVzIGJlaGluZFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcIm1haW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLiBJZiB5b3VyIGFwcCBtdXN0IGFsd2F5cyByZWZsZWN0IHRoZSB2ZXJ5IGxhdGVzdCBjb21taXQsIGFkZCB0aGlzIHRvXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicGFja2FnZS5qc29uXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnByZT48X2NvbXBvbmVudHMuY29kZSBjbGFzc05hbWU9XCJsYW5ndWFnZS1qc29uY1wiPntcIntcXG4gIFxcXCJpbW1lZGlhdGVseS5ydW5cXFwiOiB7XFxuICAgIFxcXCJyZXF1aXJlTGF0ZXN0XFxcIjogdHJ1ZVxcbiAgfVxcbn1cXG5cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5wcmU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiaW1tZWRpYXRlbHkucnVuIHN0aWxsIGJvb3RzIGluc3RhbnRseSBmcm9tIHRoZSBjYWNoZSwgdGhlbiBjaGVja3MgaW4gdGhlXFxuYmFja2dyb3VuZCAob25lIEFQSSByZXF1ZXN0KSB3aGV0aGVyIHRoZSBjYWNoZSBpcyBjdXJyZW50IGFuZCwgaWYgbm90LCByZWxvYWRzXFxuZnJvbSBHaXRIdWIuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cImhvdy1pdHMtb3JnYW5pemVkXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJob3ctaXRzLW9yZ2FuaXplZFwiIC8+e1wiSG93IGl0J3Mgb3JnYW5pemVkXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJpbW1lZGlhdGVseS5ydW4gcmVuZGVycyB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJkZWZhdWx0IGV4cG9ydCBvZiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvQXBwLnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHRoYXQncyB0aGVcXG5lbnRyeSBwb2ludCwgbm90IFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1haW4udHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnByZT48X2NvbXBvbmVudHMuY29kZT57XCJzcmMvXFxuICBtYWluLnRzeCAgICAgICAgICAgICAgIyBsb2NhbCB2aXRlIGRldi9idWlsZCBlbnRyeSBvbmx5IOKAlCBpbW1lZGlhdGVseS5ydW4gSUdOT1JFUyB0aGlzXFxuICBBcHAudHN4ICAgICAgICAgICAgICAgIyBST09UOiBkZWZhdWx0IGV4cG9ydCArIGltcG9ydHMgdGhlIGdsb2JhbCBDU1NcXG4gIGluZGV4LmNzcyAgICAgICAgICAgICAjIGZvbnRzLCBkZXNpZ24gdG9rZW5zIChkYXJrICsgbGlnaHQpLCByZXNldHNcXG4gIEFwcC5jc3MgICAgICAgICAgICAgICAjIGxheW91dCArIGNvbXBvbmVudCBzdHlsZXNcXG4gIG1keC5kLnRzICAgICAgICAgICAgICAjIHR5cGUgc2hpbSBzbyBgaW1wb3J0IFggZnJvbSAnLi94Lm1keCdgIHdvcmtzXFxuICBjb21wb25lbnRzLyAgICAgICAgICAgIyBvbmUgZGVmYXVsdC1leHBvcnRlZCBSZWFjdCBjb21wb25lbnQgcGVyIGZpbGVcXG4gIGRhdGEvICAgICAgICAgICAgICAgICAjIHR5cGVkIGRhdGEgYXJyYXlzIChOTyBjb21wb25lbnRzL0pTWCBoZXJlKVxcbiAgaG9va3MvICAgICAgICAgICAgICAgICMgY3VzdG9tIGhvb2tzIChOTyBjb21wb25lbnRzIGhlcmUpXFxuICBhc3NldHMvICAgICAgICAgICAgICAgIyBpbWFnZXMgeW91IGltcG9ydCwgZS5nLiBpbXBvcnQgbG9nbyBmcm9tICcuL2Fzc2V0cy9sb2dvLnBuZydcXG5cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5wcmU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIGluY2x1ZGVkIHBhZ2Ugc2hvd3MgdGhlIGNvcmUgcGF0dGVybnM6IGEgZGF0YSBhcnJheSBtYXBwZWQgdG8gY2FyZHNcXG4oXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZGF0YS9mZWF0dXJlcy50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oaSIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNvbXBvbmVudHMvRmVhdHVyZXMudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiksIGEgY3VzdG9tIGhvb2tcXG4oXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaG9va3MvdXNlVGhlbWUudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKGkiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjb21wb25lbnRzL1RoZW1lU3dpdGNoLnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLCBhbmQgbG9jYWwgUmVhY3Qgc3RhdGVcXG4oXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY29tcG9uZW50cy9Db3VudGVyLnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJmaWxlc3lzdGVtLWFjY2Vzcy1mc1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwiZmlsZXN5c3RlbS1hY2Nlc3MtZnNcIiAvPntcIkZpbGVzeXN0ZW0gYWNjZXNzIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJmc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJpbW1lZGlhdGVseS5ydW4gYXBwcyBjYW4gcmVhZCBhbmQgd3JpdGUgYSBmaWxlc3lzdGVtIGJ5IGltcG9ydGluZyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKGFzeW5jXFxub25seSDigJQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZnMucHJvbWlzZXMuKlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYW5kIGNhbGxiYWNrIHN0eWxlKS4gVGhpcyB0ZW1wbGF0ZSBoYXMgbG9jYWwtZGV2IHN1cHBvcnRcXG5mb3IgaXQgYnVpbHQgaW4gdmlhIFwifTxfY29tcG9uZW50cy5hIGhyZWY9XCJodHRwczovL2dpdGh1Yi5jb20vaW1tZWRpYXRlbHktcnVuL2Rldi1mc1wiPjxfY29tcG9uZW50cy5jb2RlPntcIkBpbW1lZGlhdGVseS1ydW4vZGV2LWZzXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuYT57XCIsXFxuYSBWaXRlIHBsdWdpbiAoYWxyZWFkeSB3aXJlZCBpbnRvIFwifTxfY29tcG9uZW50cy5jb2RlPntcInZpdGUuY29uZmlnLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikgdGhhdCBicmlkZ2VzIHRoZSBzYW1lXFxuZmlsZXN5c3RlbSB0byB5b3VyIHJlYWwgbG9jYWwgZGlzayBkdXJpbmcgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widml0ZSBkZXZcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLiBTZWUgdGhhdCByZXBvIGZvciB0aGVcXG5zdXBwb3J0ZWQgQVBJIGFuZCBkZXRhaWxzLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucHJlPjxfY29tcG9uZW50cy5jb2RlIGNsYXNzTmFtZT1cImxhbmd1YWdlLXRzXCI+e1wiaW1wb3J0IGZzIGZyb20gJ2ZzJ1xcblxcbmF3YWl0IGZzLnByb21pc2VzLndyaXRlRmlsZSgnL2RhdGEvbm90ZXMudHh0JywgJ2hlbGxvJywgJ3V0ZjgnKVxcbmNvbnN0IHRleHQgPSBhd2FpdCBmcy5wcm9taXNlcy5yZWFkRmlsZSgnL2RhdGEvbm90ZXMudHh0JywgJ3V0ZjgnKVxcblwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnByZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuY29kZT57XCJtYWluLnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcnVucyBhIG9uZS1vZmYgcm91bmQtdHJpcCBzbW9rZSB0ZXN0IGluIGRldiDigJQgY2hlY2sgdGhlIGJyb3dzZXJcXG5jb25zb2xlIGZvciB0aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiW2Rldi1mc11cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGdyb3VwLCBhbmQgZGVsZXRlIGl0IGZyZWVseS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwidGhlLXJ1bGVzLXRoYXQta2VlcC1pdC13b3JraW5nLW9uLWltbWVkaWF0ZWx5cnVuXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJ0aGUtcnVsZXMtdGhhdC1rZWVwLWl0LXdvcmtpbmctb24taW1tZWRpYXRlbHlydW5cIiAvPntcIlRoZSBydWxlcyB0aGF0IGtlZXAgaXQgd29ya2luZyBvbiBpbW1lZGlhdGVseS5ydW5cIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlNlZSBcIn08X2NvbXBvbmVudHMuYSBocmVmPVwiLi9DTEFVREUubWRcIj48X2NvbXBvbmVudHMuY29kZT57XCJDTEFVREUubWRcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5hPntcIiBmb3IgdGhlIGZ1bGwgbGlzdC4gVGhlIGVzc2VudGlhbHM6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJHbG9iYWwgQ1NTIGlzIGltcG9ydGVkIGZyb20gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQXBwLnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIG5ldmVyIG9ubHkgZnJvbSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJtYWluLnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJBIGZpbGUgdGhhdCBleHBvcnRzIGEgY29tcG9uZW50IGV4cG9ydHMgXCJ9PF9jb21wb25lbnRzLmVtPntcIm9ubHlcIn08L19jb21wb25lbnRzLmVtPntcIiBjb21wb25lbnRzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBkYXRhLCBjb25zdHMsXFxuYW5kIGhlbHBlcnMgZ28gaW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZGF0YS9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJob29rcy9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBvciBcIn08X2NvbXBvbmVudHMuY29kZT57XCJsaWIvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibnBtIHJ1biBsaW50XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBlbmZvcmNlcyB0aGlzLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUHVsbCBjb2xvcnMsIGZvbnRzLCByYWRpaSwgYW5kIHNoYWRvd3MgZnJvbSB0aGUgdG9rZW5zIGluIFwifTxfY29tcG9uZW50cy5jb2RlPntcImluZGV4LmNzc1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnN0cm9uZz57XCJcXG5yYXRoZXIgdGhhbiBoYXJkLWNvZGluZyB2YWx1ZXMuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cImRldmVsb3BcIj48SGVhZGluZ0FuY2hvciBpZD1cImRldmVsb3BcIiAvPntcIkRldmVsb3BcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlJlcXVpcmVzIE5vZGUuanMgMjAuMTkrIG9yIDIyLjEyKy5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnByZT48X2NvbXBvbmVudHMuY29kZSBjbGFzc05hbWU9XCJsYW5ndWFnZS1iYXNoXCI+e1wibnBtIGluc3RhbGxcXG5ucG0gcnVuIGRldiAgICAgICMgbG9jYWwgZGV2IHNlcnZlclxcbm5wbSBydW4gYnVpbGQgICAgIyB0c2MgLWIgJiYgdml0ZSBidWlsZCDigJQgbXVzdCBwYXNzIHdpdGggbm8gdHlwZSBlcnJvcnNcXG5ucG0gcnVuIGxpbnQgICAgICMgZXNsaW50IOKAlCBlbmZvcmNlcyB0aGUgUmVhY3QgRmFzdCBSZWZyZXNoIC8gSE1SIHJ1bGVcXG5ucG0gcnVuIHByZXZpZXcgICMgc2VydmUgdGhlIHByb2R1Y3Rpb24gYnVpbGRcXG5cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5wcmU+PC8+O1xufVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTURYQ29udGVudChwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHt3cmFwcGVyOiBNRFhMYXlvdXR9ID0ge1xuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfTtcbiAgcmV0dXJuIE1EWExheW91dCA/IDxNRFhMYXlvdXQgey4uLnByb3BzfT48X2NyZWF0ZU1keENvbnRlbnQgey4uLnByb3BzfSAvPjwvTURYTGF5b3V0PiA6IF9jcmVhdGVNZHhDb250ZW50KHByb3BzKTtcbn1cbmZ1bmN0aW9uIF9taXNzaW5nTWR4UmVmZXJlbmNlKGlkLCBjb21wb25lbnQsIHBsYWNlKSB7XG4gIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIFwiICsgKGNvbXBvbmVudCA/IFwiY29tcG9uZW50XCIgOiBcIm9iamVjdFwiKSArIFwiIGBcIiArIGlkICsgXCJgIHRvIGJlIGRlZmluZWQ6IHlvdSBsaWtlbHkgZm9yZ290IHRvIGltcG9ydCwgcGFzcywgb3IgcHJvdmlkZSBpdC5cIiArIChwbGFjZSA/IFwiXFxuSXTigJlzIHJlZmVyZW5jZWQgaW4geW91ciBjb2RlIGF0IGBcIiArIHBsYWNlICsgXCJgIGluIGAvYXBwL1JFQURNRS5tZGBcIiA6IFwiXCIpKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQXdGLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUZ4RjtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU1DLFdBQVcsR0FBRztNQUNsQkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsVUFBVSxFQUFFLFlBQVk7TUFDeEJDLElBQUksRUFBRSxNQUFNO01BQ1pDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLENBQUMsRUFBRSxHQUFHO01BQ05DLEdBQUcsRUFBRSxLQUFLO01BQ1ZDLE1BQU0sRUFBRSxRQUFRO01BQ2hCQyxFQUFFLEVBQUUsSUFBSTtNQUNSLEdBQUcsSUFBQUMsNkJBQWtCLEVBQUMsQ0FBQztNQUN2QixHQUFHZixLQUFLLENBQUNnQjtJQUNYLENBQUM7SUFBRTtNQUFDQztJQUFhLENBQUMsR0FBR2hCLFdBQVc7RUFDaEMsSUFBSSxDQUFDZ0IsYUFBYSxFQUFFQyxvQkFBb0IsQ0FBQyxlQUFlLEVBQUUsSUFBSSxDQUFDO0VBQy9ELG9CQUFPLElBQUFwQixXQUFBLENBQUFxQixJQUFBLEVBQUFyQixXQUFBLENBQUFzQixRQUFBO0lBQUFDLFFBQUEsZ0JBQUUsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDZ0IsRUFBRSxFQUFDLGlDQUFpQztNQUFBRCxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQWlDLENBQUUsQ0FBQyxFQUFDLG9DQUFvQztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBVSxRQUFBLEdBQUUsK0NBQStDLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0MsQ0FBQztRQUFDc0IsSUFBSSxFQUFDLHlCQUF5QjtRQUFBSCxRQUFBLEVBQUU7TUFBaUIsQ0FBZ0IsQ0FBQyxFQUFDLGtIQUFrSDtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDZSxFQUFFLEVBQUMsa0JBQWtCO01BQUFELFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBa0IsQ0FBRSxDQUFDLEVBQUMsa0JBQWtCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBeEIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDVSxDQUFDO01BQUFVLFFBQUEsR0FBRSx1QkFBdUIsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDQyxDQUFDO1FBQUNzQixJQUFJLEVBQUMsb0dBQW9HO1FBQUFILFFBQUEsRUFBRTtNQUFpQixDQUFnQixDQUFDO0lBQUEsQ0FBZSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNVLENBQUM7TUFBQVUsUUFBQSxHQUFFLDBHQUEwRyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNDLENBQUM7UUFBQ3NCLElBQUksRUFBQyx1RUFBdUU7UUFBQUgsUUFBQSxFQUFFO01BQXlCLENBQWdCLENBQUMsRUFBQywwQkFBMEIsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDQyxDQUFDO1FBQUNzQixJQUFJLEVBQUMsOEVBQThFO1FBQUFILFFBQUEsRUFBRTtNQUFzQixDQUFnQixDQUFDLEVBQUMseURBQXlELGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0MsQ0FBQztRQUFDc0IsSUFBSSxFQUFDLG1EQUFtRDtRQUFBSCxRQUFBLEVBQUU7TUFBZ0MsQ0FBZ0IsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNVLENBQUM7TUFBQVUsUUFBQSxHQUFFLDhLQUE4SyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUFpQyxDQUFtQixDQUFDLEVBQUMsMERBQTBEO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDRSxVQUFVO01BQUFrQixRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNVLENBQUM7UUFBQVUsUUFBQSxHQUFFLDJHQUEyRyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUErRSxDQUFtQixDQUFDLEVBQUMsR0FBRztNQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBeUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDTSxFQUFFO01BQUNlLEVBQUUsRUFBQyxtQkFBbUI7TUFBQUQsUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFtQixDQUFFLENBQUMsRUFBQyxtQkFBbUI7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF4QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNTLEVBQUU7TUFBQVcsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFZLFFBQUEsRUFBRTtNQUEyRCxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNRLEVBQUU7UUFBQVksUUFBQSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFhLENBQW1CO01BQUMsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQyxFQUFDLHFCQUFxQixlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyxHQUFHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFZLFFBQUEsRUFBRTtNQUFvRSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDZSxFQUFFLEVBQUMsMkNBQTJDO01BQUFELFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBMkMsQ0FBRSxDQUFDLEVBQUMsOENBQThDO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBeEIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDVSxDQUFDO01BQUFVLFFBQUEsR0FBRSxpS0FBaUssZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDQyxDQUFDO1FBQUNzQixJQUFJLEVBQUMsK0JBQStCO1FBQUFILFFBQUEsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBNkIsQ0FBbUI7TUFBQyxDQUFlLENBQUMsRUFBQyw0QkFBNEIsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1FBQUFpQixRQUFBLEVBQUU7TUFBTSxDQUFtQixDQUFDLEVBQUMsMEVBQTBFLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBa0IsQ0FBcUIsQ0FBQyxFQUFDLCtDQUErQyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUErRCxDQUFtQixDQUFDLEVBQUMsbUVBQW1FO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDVSxDQUFDO01BQUFVLFFBQUEsRUFBRTtJQUFpSSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNPLEVBQUU7TUFBQ2MsRUFBRSxFQUFDLDJCQUEyQjtNQUFBRCxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQTJCLENBQUUsQ0FBQyxFQUFDLDZCQUE2QjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBVSxRQUFBLEdBQUUscUJBQXFCLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBSyxDQUFxQixDQUFDLEVBQUMseURBQXlEO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDUyxFQUFFO01BQUFXLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBWSxRQUFBLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBbUUsQ0FBcUI7TUFBQyxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNRLEVBQUU7UUFBQVksUUFBQSxHQUFFLFVBQVUsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBTSxDQUFtQixDQUFDLEVBQUMsa0JBQWtCLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBMkIsQ0FBcUIsQ0FBQyxFQUFDLG1DQUFtQztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDVSxDQUFDO01BQUFVLFFBQUEsR0FBRSxnWEFBZ1gsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFjLENBQXFCLENBQUMsRUFBQyxjQUFjO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDRSxVQUFVO01BQUFrQixRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNVLENBQUM7UUFBQVUsUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUEyQixDQUFxQixDQUFDLEVBQUMsMkNBQTJDLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBb0IsQ0FBcUIsQ0FBQyxFQUFDLDBGQUEwRixlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFlLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQXdCLENBQW1CLENBQUMsRUFBQyxzR0FBc0csZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMscURBQXFEO01BQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUF5QixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNPLEVBQUU7TUFBQ2MsRUFBRSxFQUFDLDhCQUE4QjtNQUFBRCxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQThCLENBQUUsQ0FBQyxFQUFDLDhCQUE4QjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBVSxRQUFBLEdBQUUsNkVBQTZFLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBaUIsUUFBQSxFQUFFO01BQU0sQ0FBbUIsQ0FBQyxFQUFDLHlFQUF5RSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUFjLENBQW1CLENBQUMsRUFBQyxHQUFHO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDVyxHQUFHO01BQUFTLFFBQUEsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1FBQUNxQixTQUFTLEVBQUMsZ0JBQWdCO1FBQUFKLFFBQUEsRUFBRTtNQUFvRSxDQUFtQjtJQUFDLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBVSxRQUFBLEVBQUU7SUFBd0ssQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDTSxFQUFFO01BQUNlLEVBQUUsRUFBQyxtQkFBbUI7TUFBQUQsUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFtQixDQUFFLENBQUMsRUFBQyxvQkFBb0I7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF4QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNVLENBQUM7TUFBQVUsUUFBQSxHQUFFLDhCQUE4QixlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNZLE1BQU07UUFBQVEsUUFBQSxHQUFFLG9CQUFvQixlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUM7TUFBQSxDQUFvQixDQUFDLEVBQUMsa0NBQWtDLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBaUIsUUFBQSxFQUFFO01BQVUsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNXLEdBQUc7TUFBQVMsUUFBQSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUFtcEIsQ0FBbUI7SUFBQyxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNVLENBQUM7TUFBQVUsUUFBQSxHQUFFLDRFQUE0RSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUFrQixDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUF5QixDQUFtQixDQUFDLEVBQUMscUJBQXFCLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBaUIsUUFBQSxFQUFFO01BQW1CLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBaUIsUUFBQSxFQUFFO01BQTRCLENBQW1CLENBQUMsRUFBQyw2QkFBNkIsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1FBQUFpQixRQUFBLEVBQUU7TUFBd0IsQ0FBbUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNNLEVBQUU7TUFBQ2UsRUFBRSxFQUFDLHNCQUFzQjtNQUFBRCxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQXNCLENBQUUsQ0FBQyxFQUFDLHFCQUFxQixlQUFDLElBQUF4QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUFJLENBQW1CLENBQUMsRUFBQyxHQUFHO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDVSxDQUFDO01BQUFVLFFBQUEsR0FBRSxvRUFBb0UsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1FBQUFpQixRQUFBLEVBQUU7TUFBSSxDQUFtQixDQUFDLEVBQUMsa0JBQWtCLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBaUIsUUFBQSxFQUFFO01BQWUsQ0FBbUIsQ0FBQyxFQUFDLGlGQUFpRixlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNDLENBQUM7UUFBQ3NCLElBQUksRUFBQywyQ0FBMkM7UUFBQUgsUUFBQSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUF5QixDQUFtQjtNQUFDLENBQWUsQ0FBQyxFQUFDLHVDQUF1QyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUFnQixDQUFtQixDQUFDLEVBQUMscUVBQXFFLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBaUIsUUFBQSxFQUFFO01BQVUsQ0FBbUIsQ0FBQyxFQUFDLHFEQUFxRDtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1csR0FBRztNQUFBUyxRQUFBLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtRQUFDcUIsU0FBUyxFQUFDLGFBQWE7UUFBQUosUUFBQSxFQUFFO01BQThKLENBQW1CO0lBQUMsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDVSxDQUFDO01BQUFVLFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBaUIsUUFBQSxFQUFFO01BQVUsQ0FBbUIsQ0FBQyxFQUFDLG9GQUFvRixlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7UUFBQWlCLFFBQUEsRUFBRTtNQUFVLENBQW1CLENBQUMsRUFBQywrQkFBK0I7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNNLEVBQUU7TUFBQ2UsRUFBRSxFQUFDLGtEQUFrRDtNQUFBRCxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQWtELENBQUUsQ0FBQyxFQUFDLG1EQUFtRDtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBVSxRQUFBLEdBQUUsTUFBTSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNDLENBQUM7UUFBQ3NCLElBQUksRUFBQyxhQUFhO1FBQUFILFFBQUEsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBVyxDQUFtQjtNQUFDLENBQWUsQ0FBQyxFQUFDLHFDQUFxQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ2EsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNRLEVBQUU7UUFBQVksUUFBQSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNZLE1BQU07VUFBQVEsUUFBQSxHQUFFLDhCQUE4QixlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7WUFBQWlCLFFBQUEsRUFBRTtVQUFTLENBQW1CLENBQUMsRUFBQyxvQkFBb0IsZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1lBQUFpQixRQUFBLEVBQUU7VUFBVSxDQUFtQixDQUFDLEVBQUMsR0FBRztRQUFBLENBQXFCO01BQUMsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBcUIsSUFBQSxFQUFDbEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBUSxRQUFBLEdBQUUsMENBQTBDLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0ksRUFBRTtZQUFBZ0IsUUFBQSxFQUFFO1VBQU0sQ0FBaUIsQ0FBQyxFQUFDLGFBQWE7UUFBQSxDQUFxQixDQUFDLEVBQUMsc0NBQXNDLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQU8sQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDdEIsV0FBVyxDQUFDRyxJQUFJO1VBQUFpQixRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7VUFBQWlCLFFBQUEsRUFBRTtRQUFNLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBaUIsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLGlCQUFpQjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXFCLElBQUEsRUFBQ2xCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBWSxRQUFBLGdCQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNZLE1BQU07VUFBQVEsUUFBQSxHQUFFLDREQUE0RCxlQUFDLElBQUF2QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNHLElBQUk7WUFBQWlCLFFBQUEsRUFBRTtVQUFXLENBQW1CLENBQUM7UUFBQSxDQUFvQixDQUFDLEVBQUMsbUNBQW1DO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF2QixXQUFBLENBQUFxQixJQUFBLEVBQUNsQixXQUFXLENBQUNNLEVBQUU7TUFBQ2UsRUFBRSxFQUFDLFNBQVM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBdkIsV0FBQSxDQUFBeUIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFTLENBQUUsQ0FBQyxFQUFDLFNBQVM7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF4QixXQUFBLENBQUF5QixHQUFBLEVBQUN0QixXQUFXLENBQUNVLENBQUM7TUFBQVUsUUFBQSxFQUFFO0lBQW9DLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1csR0FBRztNQUFBUyxRQUFBLGVBQUMsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0csSUFBSTtRQUFDcUIsU0FBUyxFQUFDLGVBQWU7UUFBQUosUUFBQSxFQUFFO01BQW9QLENBQW1CO0lBQUMsQ0FBaUIsQ0FBQztFQUFBLENBQUUsQ0FBQztBQUNyeVc7QUFDZSxTQUFTSyxVQUFVQSxDQUFDMUIsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFO0VBQzdDLE1BQU07SUFBQzJCLE9BQU8sRUFBRUM7RUFBUyxDQUFDLEdBQUc7SUFDM0IsR0FBRyxJQUFBYiw2QkFBa0IsRUFBQyxDQUFDO0lBQ3ZCLEdBQUdmLEtBQUssQ0FBQ2dCO0VBQ1gsQ0FBQztFQUNELE9BQU9ZLFNBQVMsZ0JBQUcsSUFBQTlCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ0ssU0FBUztJQUFBLEdBQUs1QixLQUFLO0lBQUFxQixRQUFBLGVBQUUsSUFBQXZCLFdBQUEsQ0FBQXlCLEdBQUEsRUFBQ3hCLGlCQUFpQjtNQUFBLEdBQUtDO0lBQUssQ0FBRztFQUFDLENBQVcsQ0FBQyxHQUFHRCxpQkFBaUIsQ0FBQ0MsS0FBSyxDQUFDO0FBQ2xIO0FBQUM2QixFQUFBLEdBTnVCSCxVQUFVO0FBT2xDLFNBQVNSLG9CQUFvQkEsQ0FBQ0ksRUFBRSxFQUFFUSxTQUFTLEVBQUVDLEtBQUssRUFBRTtFQUNsRCxNQUFNLElBQUlDLEtBQUssQ0FBQyxXQUFXLElBQUlGLFNBQVMsR0FBRyxXQUFXLEdBQUcsUUFBUSxDQUFDLEdBQUcsSUFBSSxHQUFHUixFQUFFLEdBQUcsb0VBQW9FLElBQUlTLEtBQUssR0FBRyxxQ0FBcUMsR0FBR0EsS0FBSyxHQUFHLHVCQUF1QixHQUFHLEVBQUUsQ0FBQyxDQUFDO0FBQ2pQO0FBQUMsSUFBQUYsRUFBQTtBQUFBSSxZQUFBLENBQUFKLEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}