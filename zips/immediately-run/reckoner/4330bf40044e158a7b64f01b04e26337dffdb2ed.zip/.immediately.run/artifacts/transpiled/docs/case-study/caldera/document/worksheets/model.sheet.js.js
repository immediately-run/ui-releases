var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.sponsor_irr = exports.sponsor_equity = exports.sources_uses_row = exports.sources_uses = exports.sensitivity = exports.returns_avg = exports.returns = exports.operating = exports.moic = exports.ltm_ebitda = exports.debt_schedule_avg = exports.debt_schedule = exports.breakeven_exit_multiple = void 0;
require("core-js/modules/esnext.iterator.constructor.js");
require("core-js/modules/esnext.iterator.map.js");
require("core-js/modules/esnext.iterator.reduce.js");
var _stdlib = require("@reckoner/stdlib");
// Caldera Components LBO — the model worksheet.
//
// Structure mirrors the Excel "before" (caldera_lbo.xlsx) tab for tab:
//   Assumptions        → fixtures.assumptions + the three params.* deal knobs
//   Operating_Model    → `ltm_ebitda`, `operating`
//   Sources_Uses       → `sources_uses`
//   Debt_Schedule      → `debt_schedule` (begin-balance interest) and
//                        `debt_schedule_avg` (average-balance interest — Excel's
//                        iterative-calc circular reference, here an explicit,
//                        per-year converged fixed point inside one cell)
//   Sens_Models/grid   → `sensitivity` (25 full model re-runs)
//   Returns            → `returns`, `sponsor_irr`, `moic`, `breakeven_exit_multiple`
//
// Naming note: a worksheet export shadows any same-named stdlib callable in module
// scope (the import is stripped; stdlib functions arrive as compartment globals) —
// hence `sponsor_irr`, not `irr`, for the scalar tile.
//
// Everything below is pure: plain values in, plain values out, no ambient
// anything. The module-scope helpers are the "model as a function" the
// sensitivity grid needs — a cell cannot re-run other cells, so the model must
// decompose into callable pure functions (the architectural finding this case
// study exists to document).

const YEARS_ORDER = "year";

// ── module-scope model helpers (shared by cells and the grid) ────────────────
// (The hand-rolled npv/irrBisect that lived here is R3-376's receipt: the stdlib's
// irr() replaced it, deleted rather than kept.)

// The operating build: segment revenue paths (base × the compounded growth factors via
// cumprod), margin-weighted EBITDA, D&A / capex / ΔNWC per year. Fluent stdlib throughout.
function buildOperating(hist, plan, yearPlan, a) {
  const baseTotal = hist.reduce((acc, h) => acc + h.fy2026, 0);
  const paths = (0, _stdlib.table)(hist).join(plan, {
    on: "segment"
  }).derive({
    growth_factor: r => 1 + r.growth
  }).scan({
    factor_path: (0, _stdlib.cumprod)("growth_factor")
  }, {
    partitionBy: "segment",
    orderBy: YEARS_ORDER
  }).derive({
    seg_revenue: r => r.fy2026 * r.factor_path,
    seg_ebitda: r => r.fy2026 * r.factor_path * r.margin
  }).groupBy("year").rollup({
    revenue: (0, _stdlib.sum)("seg_revenue"),
    ebitda: (0, _stdlib.sum)("seg_ebitda")
  }).rows();
  return (0, _stdlib.table)(paths).sort(YEARS_ORDER).lag("revenue", {
    as: "prior_revenue",
    fill: baseTotal
  }).join(yearPlan, {
    on: "year"
  }).derive({
    da: r => a.da_pct * r.revenue,
    capex: r => r.capex_pct * r.revenue,
    delta_nwc: r => a.nwc_pct * (r.revenue - r.prior_revenue)
  }).rows().map(r => ({
    year: r.year,
    revenue: r.revenue,
    ebitda: r.ebitda,
    da: r.da,
    capex: r.capex,
    delta_nwc: r.delta_nwc
  }));
}
function sourcesUses(ltm, a, entryMultiple, tlbTurns) {
  const ev = entryMultiple * ltm;
  const purchase_equity = ev - a.existing_debt + a.existing_cash;
  const tlb0 = tlbTurns * ltm;
  const mezz0 = a.mezz_turns * ltm;
  const txn_fees = a.txn_fee_pct * ev;
  const fin_fees = a.fin_fee_pct * (tlb0 + mezz0);
  const uses = purchase_equity + a.existing_debt + txn_fees + fin_fees;
  const cash_used = a.existing_cash - a.min_cash;
  const sponsor_equity = uses - tlb0 - mezz0 - cash_used;
  return {
    entry_ev: ev,
    purchase_equity,
    tlb0,
    mezz0,
    txn_fees,
    fin_fees,
    uses,
    cash_used,
    sponsor_equity,
    sources: tlb0 + mezz0 + cash_used + sponsor_equity
  };
}

// One year of the debt waterfall given opening balances. mode "begin" charges
// interest on beginning balances; mode "avg" on average balances, where `est`
// is the current fixed-point estimate of the ending balances (the caller
// iterates). Mirrors generate.py `year_pass` operation for operation.
function yearPass(op, a, su, bal, mode) {
  let e_tlb, e_mezz, e_rev, e_undrawn;
  if (mode === "begin") {
    e_tlb = bal.tlb;
    e_mezz = bal.mezz;
    e_rev = bal.rev;
    e_undrawn = Math.max(0, a.revolver_capacity - bal.rev);
  } else {
    e_tlb = (bal.tlb + bal.est.tlb) / 2;
    e_mezz = (bal.mezz + bal.est.mezz) / 2;
    e_rev = (bal.rev + bal.est.rev) / 2;
    e_undrawn = Math.max(0, (a.revolver_capacity - bal.rev + a.revolver_capacity - bal.est.rev) / 2);
  }
  const interest = a.tlb_rate * e_tlb + a.mezz_cash_rate * e_mezz + a.revolver_rate * e_rev + a.commitment_fee * e_undrawn;
  const ebt = op.ebitda - op.da - interest;
  const tax = Math.max(0, ebt * a.tax_rate);
  const ni = ebt - tax;
  const cfadr = ni + op.da - op.capex - op.delta_nwc;
  const rev_repay = Math.min(bal.rev, Math.max(0, cfadr));
  const rev_draw = Math.min(Math.max(0, a.revolver_capacity - bal.rev), Math.max(0, -cfadr));
  const res1 = cfadr - rev_repay + rev_draw;
  const mand = Math.min(a.tlb_amort_pct * su.tlb0, bal.tlb);
  let res2 = res1 - mand;
  const draw2 = Math.min(Math.max(0, a.revolver_capacity - (bal.rev + rev_draw)), Math.max(0, -res2));
  res2 = res2 + draw2;
  const sweep = Math.min(a.cash_sweep_pct * Math.max(0, res2), bal.tlb - mand);
  const end = {
    rev: bal.rev + rev_draw + draw2 - rev_repay,
    tlb: bal.tlb - mand - sweep,
    mezz: bal.mezz * (1 + a.mezz_pik_rate),
    cash: bal.cash + res2 - sweep
  };
  return {
    begin: {
      rev: bal.rev,
      tlb: bal.tlb,
      mezz: bal.mezz,
      cash: bal.cash
    },
    interest,
    ebt,
    tax,
    ni,
    cfadr,
    mand,
    sweep,
    retained: res2 - sweep,
    rev_draw: rev_draw + draw2,
    rev_repay,
    end
  };
}

// The 5-year roll-forward on the stdlib's multi-state primitive (R3-375): the
// state tuple {rev, tlb, mezz, cash} evolves through each year's waterfall —
// the structure Excel unrolls across columns. 'avg' mode iterates each year's
// step to a fixed point (Excel's iterative-calc circular reference, explicit).
function scheduleYears(ops, a, su, mode) {
  let iterations = 0;
  return (0, _stdlib.rollforward)(ops, {
    orderBy: YEARS_ORDER,
    begin: {
      rev: 0,
      tlb: su.tlb0,
      mezz: su.mezz0,
      cash: a.min_cash
    },
    step: (op, bal) => {
      let out;
      if (mode === "begin") {
        out = yearPass(op, a, su, bal, "begin");
      } else {
        // The within-year fixed point on the stdlib's fixpoint helper (R3-378):
        // iterate the average-balance estimate until it stops moving, then take
        // one final pass at the converged state so the year's output columns are
        // exactly consistent with it. Non-convergence surfaces as a thrown error
        // — visible, the opposite of Excel's silent iterative calc.
        const trial = {
          rev: bal.rev,
          tlb: bal.tlb,
          mezz: bal.mezz,
          cash: bal.cash,
          est: null
        };
        let lastOut = null;
        const fp = (0, _stdlib.fixpoint)({
          rev: bal.rev,
          tlb: bal.tlb,
          mezz: bal.mezz,
          cash: bal.cash
        }, est => {
          trial.est = est;
          const pass = yearPass(op, a, su, trial, "avg");
          lastOut = pass;
          return pass.end;
        }, {
          tol: 1e-12,
          maxIterations: 200
        });
        if (!fp.converged) {
          throw new Error("average-balance interest did not converge in year " + op.year);
        }
        iterations += fp.iterations;
        out = lastOut;
      }
      const netDebt = out.end.tlb + out.end.mezz + out.end.rev - out.end.cash;
      return {
        out: {
          interest: out.interest,
          cfadr: out.cfadr,
          mand: out.mand,
          sweep: out.sweep,
          retained: out.retained,
          rev_draw: out.rev_draw,
          rev_repay: out.rev_repay,
          net_debt: netDebt,
          leverage: netDebt / op.ebitda,
          coverage: op.ebitda / out.interest,
          iterations
        },
        next: out.end
      };
    }
  });
}

// The whole model as one pure function of the fixtures + overrides — what the
// sensitivity grid maps over and the breakeven goal-seek bisects on. This
// decomposition is *forced* by Reckoner's no-ambient-registry rule: a cell
// cannot re-run other cells with different params, so the model must be a
// function before it can be swept.
function runModel(a, hist, plan, yearPlan, o) {
  const overrides = o || {};
  const ltm = hist.reduce((acc, h) => acc + h.fy2026 * h.margin_fy2026, 0);
  const ops = buildOperating(hist, plan, yearPlan, a);
  const su = sourcesUses(ltm, a, overrides.entry_multiple === undefined ? a.entry_multiple : overrides.entry_multiple, overrides.tlb_turns === undefined ? a.tlb_turns : overrides.tlb_turns);
  const sched = scheduleYears(ops, a, su, "begin");
  const last = ops[ops.length - 1];
  const lastS = sched[sched.length - 1];
  const exitMultiple = overrides.exit_multiple === undefined ? a.exit_multiple : overrides.exit_multiple;
  const exit_ev = exitMultiple * last.ebitda;
  const exit_equity = exit_ev - lastS.net_debt;
  const flows = [-su.sponsor_equity].concat(Array(a.hold_years - 1).fill(0)).concat([exit_equity]);
  return {
    su,
    exit_ev,
    net_debt: lastS.net_debt,
    exit_equity,
    moic: exit_equity / su.sponsor_equity,
    irr: (0, _stdlib.irr)(flows)
  };
}

// Goal seek: the exit multiple at which IRR = hurdle (IRR is increasing in it).
// Excel does this interactively (Data → What-If → Goal Seek); here it is an
// explicit bisection, so it recomputes with the model and is testable.
function breakevenExitMultiple(a, hist, plan, yearPlan, hurdle) {
  // Goal seek on the stdlib's solve (R3-381): IRR is increasing in the exit
  // multiple, so the bracket is monotone and bisection is exact.
  return (0, _stdlib.solve)(m => runModel(a, hist, plan, yearPlan, {
    exit_multiple: m
  }).irr, hurdle, 4.0, 12.0);
}

// ── cells ─────────────────────────────────────────────────────────────────────

const ltm_ebitda = exports.ltm_ebitda = (0, _stdlib.cell)({
  doc: "LTM (FY2026) EBITDA at close, EUR m — the entry multiple's base",
  inputs: {
    hist: "fixtures.historical_segments"
  },
  formula: ({
    hist
  }) => hist.reduce((acc, h) => acc + h.fy2026 * h.margin_fy2026, 0)
});
const operating = exports.operating = (0, _stdlib.cell)({
  doc: "Five-year operating build: revenue by chained segment growth, margin-weighted EBITDA, D&A, capex, ΔNWC — one row per year FY2027–FY2031",
  inputs: {
    hist: "fixtures.historical_segments",
    plan: "fixtures.ops_plan",
    yearPlan: "fixtures.year_plan",
    a: "fixtures.assumptions"
  },
  formula: ({
    hist,
    plan,
    yearPlan,
    a
  }) => buildOperating(hist, plan, yearPlan, a[0])
});
const sources_uses = exports.sources_uses = (0, _stdlib.cell)({
  doc: "Sources & uses at close (EUR m): entry EV, purchase equity, fees, funded debt, and the sponsor equity plug. The interactive deal knobs are params",
  inputs: {
    ltm: "model.ltm_ebitda",
    a: "fixtures.assumptions",
    entry: "params.entry_multiple",
    tlbTurns: "params.tlb_turns"
  },
  formula: ({
    ltm,
    a,
    entry,
    tlbTurns
  }) => sourcesUses(ltm, a[0], entry, tlbTurns)
});

// One-row projection of sources_uses shaped for the conservation test:
// components (debt + cash + equity) must sum to total uses, row-wise.
const sources_uses_row = exports.sources_uses_row = (0, _stdlib.cell)({
  doc: "Sources & uses as a single conservation row: tlb0 + mezz0 + cash_used + sponsor_equity = uses",
  inputs: {
    su: "model.sources_uses"
  },
  formula: ({
    su
  }) => [{
    tlb0: su.tlb0,
    mezz0: su.mezz0,
    cash_used: su.cash_used,
    sponsor_equity: su.sponsor_equity,
    uses_total: su.uses
  }]
});
const debt_schedule = exports.debt_schedule = (0, _stdlib.cell)({
  doc: "Debt schedule FY2027–FY2031, interest on beginning balances (no circularity): revolver draw/repay, TLB mandatory amortisation + 75% cash sweep, mezzanine PIK accrual, cash build, leverage and coverage",
  inputs: {
    ops: "model.operating",
    su: "model.sources_uses",
    a: "fixtures.assumptions"
  },
  formula: ({
    ops,
    su,
    a
  }) => scheduleYears(ops, a[0], su, "begin")
});
const debt_schedule_avg = exports.debt_schedule_avg = (0, _stdlib.cell)({
  doc: "Debt schedule with interest on AVERAGE balances — Excel's iterative-calc circular reference, expressed as an explicit per-year fixed point converged to 1e-12; rows carry the iteration count",
  inputs: {
    ops: "model.operating",
    su: "model.sources_uses",
    a: "fixtures.assumptions"
  },
  formula: ({
    ops,
    su,
    a
  }) => scheduleYears(ops, a[0], su, "avg")
});
const returns = exports.returns = (0, _stdlib.cell)({
  doc: "Exit returns at FY2031: exit EV at the exit multiple, less net debt, → sponsor equity value, MOIC and IRR (bisection on the annual flows)",
  inputs: {
    ops: "model.operating",
    sched: "model.debt_schedule",
    su: "model.sources_uses",
    a: "fixtures.assumptions",
    exit: "params.exit_multiple"
  },
  formula: ({
    ops,
    sched,
    su,
    a,
    exit
  }) => {
    const last = ops[ops.length - 1];
    const lastS = sched[sched.length - 1];
    const exit_ev = exit * last.ebitda;
    const exit_equity = exit_ev - lastS.net_debt;
    const flows = [-su.sponsor_equity].concat(Array(a[0].hold_years - 1).fill(0)).concat([exit_equity]);
    return {
      exit_ev,
      net_debt: lastS.net_debt,
      exit_equity,
      sponsor_equity: su.sponsor_equity,
      moic: exit_equity / su.sponsor_equity,
      irr: (0, _stdlib.irr)(flows)
    };
  }
});
const returns_avg = exports.returns_avg = (0, _stdlib.cell)({
  doc: "Exit returns under the average-balance (converged circular) debt schedule — the answer Excel's iterative sheet would give",
  inputs: {
    ops: "model.operating",
    sched: "model.debt_schedule_avg",
    su: "model.sources_uses",
    a: "fixtures.assumptions",
    exit: "params.exit_multiple"
  },
  formula: ({
    ops,
    sched,
    su,
    a,
    exit
  }) => {
    const last = ops[ops.length - 1];
    const lastS = sched[sched.length - 1];
    const exit_ev = exit * last.ebitda;
    const exit_equity = exit_ev - lastS.net_debt;
    const flows = [-su.sponsor_equity].concat(Array(a[0].hold_years - 1).fill(0)).concat([exit_equity]);
    return {
      exit_ev,
      exit_equity,
      irr: (0, _stdlib.irr)(flows),
      moic: exit_equity / su.sponsor_equity
    };
  }
});

// Thin named scalars the template and tests bind to.
const sponsor_irr = exports.sponsor_irr = (0, _stdlib.cell)({
  doc: "Base-case sponsor IRR as a scalar, for the Kpi tile",
  inputs: {
    r: "model.returns"
  },
  formula: ({
    r
  }) => r.irr
});
const moic = exports.moic = (0, _stdlib.cell)({
  doc: "Base-case sponsor MOIC (x) as a scalar, for the Kpi tile",
  inputs: {
    r: "model.returns"
  },
  formula: ({
    r
  }) => r.moic
});
const sponsor_equity = exports.sponsor_equity = (0, _stdlib.cell)({
  doc: "Sponsor equity cheque at close (EUR m), for the Kpi tile",
  inputs: {
    su: "model.sources_uses"
  },
  formula: ({
    su
  }) => su.sponsor_equity
});
const sensitivity = exports.sensitivity = (0, _stdlib.cell)({
  doc: "Two-way sensitivity: sponsor IRR and MOIC for exit multiple 7.0–9.0x × TLB leverage 4.0–6.0x — 25 full model re-runs over the base fixtures (not the live params)",
  inputs: {
    a: "fixtures.assumptions",
    hist: "fixtures.historical_segments",
    plan: "fixtures.ops_plan",
    yearPlan: "fixtures.year_plan"
  },
  formula: ({
    a,
    hist,
    plan,
    yearPlan
  }) => {
    const exitMults = [7.0, 7.5, 8.0, 8.5, 9.0];
    const levs = [4.0, 4.5, 5.0, 5.5, 6.0];
    const rows = [];
    for (const exit_m of exitMults) {
      for (const lev of levs) {
        const r = runModel(a[0], hist, plan, yearPlan, {
          exit_multiple: exit_m,
          tlb_turns: lev
        });
        rows.push({
          exit_multiple: exit_m,
          tlb_turns: lev,
          sponsor_equity: r.su.sponsor_equity,
          exit_equity: r.exit_equity,
          moic: r.moic,
          irr: r.irr
        });
      }
    }
    return rows;
  }
});
const breakeven_exit_multiple = exports.breakeven_exit_multiple = (0, _stdlib.cell)({
  doc: "Goal seek: the exit multiple at which the sponsor IRR equals the 20% hurdle (IRR is monotone in the exit multiple)",
  inputs: {
    a: "fixtures.assumptions",
    hist: "fixtures.historical_segments",
    plan: "fixtures.ops_plan",
    yearPlan: "fixtures.year_plan"
  },
  formula: ({
    a,
    hist,
    plan,
    yearPlan
  }) => breakevenExitMultiple(a[0], hist, plan, yearPlan, a[0].hurdle_irr)
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfc3RkbGliIiwicmVxdWlyZSIsIllFQVJTX09SREVSIiwiYnVpbGRPcGVyYXRpbmciLCJoaXN0IiwicGxhbiIsInllYXJQbGFuIiwiYSIsImJhc2VUb3RhbCIsInJlZHVjZSIsImFjYyIsImgiLCJmeTIwMjYiLCJwYXRocyIsInRhYmxlIiwiam9pbiIsIm9uIiwiZGVyaXZlIiwiZ3Jvd3RoX2ZhY3RvciIsInIiLCJncm93dGgiLCJzY2FuIiwiZmFjdG9yX3BhdGgiLCJjdW1wcm9kIiwicGFydGl0aW9uQnkiLCJvcmRlckJ5Iiwic2VnX3JldmVudWUiLCJzZWdfZWJpdGRhIiwibWFyZ2luIiwiZ3JvdXBCeSIsInJvbGx1cCIsInJldmVudWUiLCJzdW0iLCJlYml0ZGEiLCJyb3dzIiwic29ydCIsImxhZyIsImFzIiwiZmlsbCIsImRhIiwiZGFfcGN0IiwiY2FwZXgiLCJjYXBleF9wY3QiLCJkZWx0YV9ud2MiLCJud2NfcGN0IiwicHJpb3JfcmV2ZW51ZSIsIm1hcCIsInllYXIiLCJzb3VyY2VzVXNlcyIsImx0bSIsImVudHJ5TXVsdGlwbGUiLCJ0bGJUdXJucyIsImV2IiwicHVyY2hhc2VfZXF1aXR5IiwiZXhpc3RpbmdfZGVidCIsImV4aXN0aW5nX2Nhc2giLCJ0bGIwIiwibWV6ejAiLCJtZXp6X3R1cm5zIiwidHhuX2ZlZXMiLCJ0eG5fZmVlX3BjdCIsImZpbl9mZWVzIiwiZmluX2ZlZV9wY3QiLCJ1c2VzIiwiY2FzaF91c2VkIiwibWluX2Nhc2giLCJzcG9uc29yX2VxdWl0eSIsImVudHJ5X2V2Iiwic291cmNlcyIsInllYXJQYXNzIiwib3AiLCJzdSIsImJhbCIsIm1vZGUiLCJlX3RsYiIsImVfbWV6eiIsImVfcmV2IiwiZV91bmRyYXduIiwidGxiIiwibWV6eiIsInJldiIsIk1hdGgiLCJtYXgiLCJyZXZvbHZlcl9jYXBhY2l0eSIsImVzdCIsImludGVyZXN0IiwidGxiX3JhdGUiLCJtZXp6X2Nhc2hfcmF0ZSIsInJldm9sdmVyX3JhdGUiLCJjb21taXRtZW50X2ZlZSIsImVidCIsInRheCIsInRheF9yYXRlIiwibmkiLCJjZmFkciIsInJldl9yZXBheSIsIm1pbiIsInJldl9kcmF3IiwicmVzMSIsIm1hbmQiLCJ0bGJfYW1vcnRfcGN0IiwicmVzMiIsImRyYXcyIiwic3dlZXAiLCJjYXNoX3N3ZWVwX3BjdCIsImVuZCIsIm1lenpfcGlrX3JhdGUiLCJjYXNoIiwiYmVnaW4iLCJyZXRhaW5lZCIsInNjaGVkdWxlWWVhcnMiLCJvcHMiLCJpdGVyYXRpb25zIiwicm9sbGZvcndhcmQiLCJzdGVwIiwib3V0IiwidHJpYWwiLCJsYXN0T3V0IiwiZnAiLCJmaXhwb2ludCIsInBhc3MiLCJ0b2wiLCJtYXhJdGVyYXRpb25zIiwiY29udmVyZ2VkIiwiRXJyb3IiLCJuZXREZWJ0IiwibmV0X2RlYnQiLCJsZXZlcmFnZSIsImNvdmVyYWdlIiwibmV4dCIsInJ1bk1vZGVsIiwibyIsIm92ZXJyaWRlcyIsIm1hcmdpbl9meTIwMjYiLCJlbnRyeV9tdWx0aXBsZSIsInVuZGVmaW5lZCIsInRsYl90dXJucyIsInNjaGVkIiwibGFzdCIsImxlbmd0aCIsImxhc3RTIiwiZXhpdE11bHRpcGxlIiwiZXhpdF9tdWx0aXBsZSIsImV4aXRfZXYiLCJleGl0X2VxdWl0eSIsImZsb3dzIiwiY29uY2F0IiwiQXJyYXkiLCJob2xkX3llYXJzIiwibW9pYyIsImlyciIsImJyZWFrZXZlbkV4aXRNdWx0aXBsZSIsImh1cmRsZSIsInNvbHZlIiwibSIsImx0bV9lYml0ZGEiLCJleHBvcnRzIiwiY2VsbCIsImRvYyIsImlucHV0cyIsImZvcm11bGEiLCJvcGVyYXRpbmciLCJzb3VyY2VzX3VzZXMiLCJlbnRyeSIsInNvdXJjZXNfdXNlc19yb3ciLCJ1c2VzX3RvdGFsIiwiZGVidF9zY2hlZHVsZSIsImRlYnRfc2NoZWR1bGVfYXZnIiwicmV0dXJucyIsImV4aXQiLCJyZXR1cm5zX2F2ZyIsInNwb25zb3JfaXJyIiwic2Vuc2l0aXZpdHkiLCJleGl0TXVsdHMiLCJsZXZzIiwiZXhpdF9tIiwibGV2IiwicHVzaCIsImJyZWFrZXZlbl9leGl0X211bHRpcGxlIiwiaHVyZGxlX2lyciJdLCJzb3VyY2VzIjpbIm1vZGVsLnNoZWV0LmpzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNlbGwsIHRhYmxlLCByb2xsZm9yd2FyZCwgY3VtcHJvZCwgaXJyLCBzb2x2ZSwgZml4cG9pbnQsIHN1bSB9IGZyb20gXCJAcmVja29uZXIvc3RkbGliXCI7XG5cbi8vIENhbGRlcmEgQ29tcG9uZW50cyBMQk8g4oCUIHRoZSBtb2RlbCB3b3Jrc2hlZXQuXG4vL1xuLy8gU3RydWN0dXJlIG1pcnJvcnMgdGhlIEV4Y2VsIFwiYmVmb3JlXCIgKGNhbGRlcmFfbGJvLnhsc3gpIHRhYiBmb3IgdGFiOlxuLy8gICBBc3N1bXB0aW9ucyAgICAgICAg4oaSIGZpeHR1cmVzLmFzc3VtcHRpb25zICsgdGhlIHRocmVlIHBhcmFtcy4qIGRlYWwga25vYnNcbi8vICAgT3BlcmF0aW5nX01vZGVsICAgIOKGkiBgbHRtX2ViaXRkYWAsIGBvcGVyYXRpbmdgXG4vLyAgIFNvdXJjZXNfVXNlcyAgICAgICDihpIgYHNvdXJjZXNfdXNlc2Bcbi8vICAgRGVidF9TY2hlZHVsZSAgICAgIOKGkiBgZGVidF9zY2hlZHVsZWAgKGJlZ2luLWJhbGFuY2UgaW50ZXJlc3QpIGFuZFxuLy8gICAgICAgICAgICAgICAgICAgICAgICBgZGVidF9zY2hlZHVsZV9hdmdgIChhdmVyYWdlLWJhbGFuY2UgaW50ZXJlc3Qg4oCUIEV4Y2VsJ3Ncbi8vICAgICAgICAgICAgICAgICAgICAgICAgaXRlcmF0aXZlLWNhbGMgY2lyY3VsYXIgcmVmZXJlbmNlLCBoZXJlIGFuIGV4cGxpY2l0LFxuLy8gICAgICAgICAgICAgICAgICAgICAgICBwZXIteWVhciBjb252ZXJnZWQgZml4ZWQgcG9pbnQgaW5zaWRlIG9uZSBjZWxsKVxuLy8gICBTZW5zX01vZGVscy9ncmlkICAg4oaSIGBzZW5zaXRpdml0eWAgKDI1IGZ1bGwgbW9kZWwgcmUtcnVucylcbi8vICAgUmV0dXJucyAgICAgICAgICAgIOKGkiBgcmV0dXJuc2AsIGBzcG9uc29yX2lycmAsIGBtb2ljYCwgYGJyZWFrZXZlbl9leGl0X211bHRpcGxlYFxuLy9cbi8vIE5hbWluZyBub3RlOiBhIHdvcmtzaGVldCBleHBvcnQgc2hhZG93cyBhbnkgc2FtZS1uYW1lZCBzdGRsaWIgY2FsbGFibGUgaW4gbW9kdWxlXG4vLyBzY29wZSAodGhlIGltcG9ydCBpcyBzdHJpcHBlZDsgc3RkbGliIGZ1bmN0aW9ucyBhcnJpdmUgYXMgY29tcGFydG1lbnQgZ2xvYmFscykg4oCUXG4vLyBoZW5jZSBgc3BvbnNvcl9pcnJgLCBub3QgYGlycmAsIGZvciB0aGUgc2NhbGFyIHRpbGUuXG4vL1xuLy8gRXZlcnl0aGluZyBiZWxvdyBpcyBwdXJlOiBwbGFpbiB2YWx1ZXMgaW4sIHBsYWluIHZhbHVlcyBvdXQsIG5vIGFtYmllbnRcbi8vIGFueXRoaW5nLiBUaGUgbW9kdWxlLXNjb3BlIGhlbHBlcnMgYXJlIHRoZSBcIm1vZGVsIGFzIGEgZnVuY3Rpb25cIiB0aGVcbi8vIHNlbnNpdGl2aXR5IGdyaWQgbmVlZHMg4oCUIGEgY2VsbCBjYW5ub3QgcmUtcnVuIG90aGVyIGNlbGxzLCBzbyB0aGUgbW9kZWwgbXVzdFxuLy8gZGVjb21wb3NlIGludG8gY2FsbGFibGUgcHVyZSBmdW5jdGlvbnMgKHRoZSBhcmNoaXRlY3R1cmFsIGZpbmRpbmcgdGhpcyBjYXNlXG4vLyBzdHVkeSBleGlzdHMgdG8gZG9jdW1lbnQpLlxuXG5jb25zdCBZRUFSU19PUkRFUiA9IFwieWVhclwiO1xuXG4vLyDilIDilIAgbW9kdWxlLXNjb3BlIG1vZGVsIGhlbHBlcnMgKHNoYXJlZCBieSBjZWxscyBhbmQgdGhlIGdyaWQpIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuLy8gKFRoZSBoYW5kLXJvbGxlZCBucHYvaXJyQmlzZWN0IHRoYXQgbGl2ZWQgaGVyZSBpcyBSMy0zNzYncyByZWNlaXB0OiB0aGUgc3RkbGliJ3Ncbi8vIGlycigpIHJlcGxhY2VkIGl0LCBkZWxldGVkIHJhdGhlciB0aGFuIGtlcHQuKVxuXG4vLyBUaGUgb3BlcmF0aW5nIGJ1aWxkOiBzZWdtZW50IHJldmVudWUgcGF0aHMgKGJhc2Ugw5cgdGhlIGNvbXBvdW5kZWQgZ3Jvd3RoIGZhY3RvcnMgdmlhXG4vLyBjdW1wcm9kKSwgbWFyZ2luLXdlaWdodGVkIEVCSVREQSwgRCZBIC8gY2FwZXggLyDOlE5XQyBwZXIgeWVhci4gRmx1ZW50IHN0ZGxpYiB0aHJvdWdob3V0LlxuZnVuY3Rpb24gYnVpbGRPcGVyYXRpbmcoaGlzdCwgcGxhbiwgeWVhclBsYW4sIGEpIHtcbiAgY29uc3QgYmFzZVRvdGFsID0gaGlzdC5yZWR1Y2UoKGFjYywgaCkgPT4gYWNjICsgaC5meTIwMjYsIDApO1xuICBjb25zdCBwYXRocyA9IHRhYmxlKGhpc3QpXG4gICAgLmpvaW4ocGxhbiwgeyBvbjogXCJzZWdtZW50XCIgfSlcbiAgICAuZGVyaXZlKHsgZ3Jvd3RoX2ZhY3RvcjogKHIpID0+IDEgKyByLmdyb3d0aCB9KVxuICAgIC5zY2FuKFxuICAgICAgeyBmYWN0b3JfcGF0aDogY3VtcHJvZChcImdyb3d0aF9mYWN0b3JcIikgfSxcbiAgICAgIHsgcGFydGl0aW9uQnk6IFwic2VnbWVudFwiLCBvcmRlckJ5OiBZRUFSU19PUkRFUiB9LFxuICAgIClcbiAgICAuZGVyaXZlKHsgc2VnX3JldmVudWU6IChyKSA9PiByLmZ5MjAyNiAqIHIuZmFjdG9yX3BhdGgsIHNlZ19lYml0ZGE6IChyKSA9PiByLmZ5MjAyNiAqIHIuZmFjdG9yX3BhdGggKiByLm1hcmdpbiB9KVxuICAgIC5ncm91cEJ5KFwieWVhclwiKVxuICAgIC5yb2xsdXAoeyByZXZlbnVlOiBzdW0oXCJzZWdfcmV2ZW51ZVwiKSwgZWJpdGRhOiBzdW0oXCJzZWdfZWJpdGRhXCIpIH0pXG4gICAgLnJvd3MoKTtcbiAgcmV0dXJuIHRhYmxlKHBhdGhzKVxuICAgIC5zb3J0KFlFQVJTX09SREVSKVxuICAgIC5sYWcoXCJyZXZlbnVlXCIsIHsgYXM6IFwicHJpb3JfcmV2ZW51ZVwiLCBmaWxsOiBiYXNlVG90YWwgfSlcbiAgICAuam9pbih5ZWFyUGxhbiwgeyBvbjogXCJ5ZWFyXCIgfSlcbiAgICAuZGVyaXZlKHtcbiAgICAgIGRhOiAocikgPT4gYS5kYV9wY3QgKiByLnJldmVudWUsXG4gICAgICBjYXBleDogKHIpID0+IHIuY2FwZXhfcGN0ICogci5yZXZlbnVlLFxuICAgICAgZGVsdGFfbndjOiAocikgPT4gYS5ud2NfcGN0ICogKHIucmV2ZW51ZSAtIHIucHJpb3JfcmV2ZW51ZSksXG4gICAgfSlcbiAgICAucm93cygpXG4gICAgLm1hcCgocikgPT4gKHtcbiAgICAgIHllYXI6IHIueWVhciwgcmV2ZW51ZTogci5yZXZlbnVlLCBlYml0ZGE6IHIuZWJpdGRhLFxuICAgICAgZGE6IHIuZGEsIGNhcGV4OiByLmNhcGV4LCBkZWx0YV9ud2M6IHIuZGVsdGFfbndjLFxuICAgIH0pKTtcbn1cblxuZnVuY3Rpb24gc291cmNlc1VzZXMobHRtLCBhLCBlbnRyeU11bHRpcGxlLCB0bGJUdXJucykge1xuICBjb25zdCBldiA9IGVudHJ5TXVsdGlwbGUgKiBsdG07XG4gIGNvbnN0IHB1cmNoYXNlX2VxdWl0eSA9IGV2IC0gYS5leGlzdGluZ19kZWJ0ICsgYS5leGlzdGluZ19jYXNoO1xuICBjb25zdCB0bGIwID0gdGxiVHVybnMgKiBsdG07XG4gIGNvbnN0IG1lenowID0gYS5tZXp6X3R1cm5zICogbHRtO1xuICBjb25zdCB0eG5fZmVlcyA9IGEudHhuX2ZlZV9wY3QgKiBldjtcbiAgY29uc3QgZmluX2ZlZXMgPSBhLmZpbl9mZWVfcGN0ICogKHRsYjAgKyBtZXp6MCk7XG4gIGNvbnN0IHVzZXMgPSBwdXJjaGFzZV9lcXVpdHkgKyBhLmV4aXN0aW5nX2RlYnQgKyB0eG5fZmVlcyArIGZpbl9mZWVzO1xuICBjb25zdCBjYXNoX3VzZWQgPSBhLmV4aXN0aW5nX2Nhc2ggLSBhLm1pbl9jYXNoO1xuICBjb25zdCBzcG9uc29yX2VxdWl0eSA9IHVzZXMgLSB0bGIwIC0gbWV6ejAgLSBjYXNoX3VzZWQ7XG4gIHJldHVybiB7XG4gICAgZW50cnlfZXY6IGV2LCBwdXJjaGFzZV9lcXVpdHksIHRsYjAsIG1lenowLCB0eG5fZmVlcywgZmluX2ZlZXMsXG4gICAgdXNlcywgY2FzaF91c2VkLCBzcG9uc29yX2VxdWl0eSwgc291cmNlczogdGxiMCArIG1lenowICsgY2FzaF91c2VkICsgc3BvbnNvcl9lcXVpdHksXG4gIH07XG59XG5cbi8vIE9uZSB5ZWFyIG9mIHRoZSBkZWJ0IHdhdGVyZmFsbCBnaXZlbiBvcGVuaW5nIGJhbGFuY2VzLiBtb2RlIFwiYmVnaW5cIiBjaGFyZ2VzXG4vLyBpbnRlcmVzdCBvbiBiZWdpbm5pbmcgYmFsYW5jZXM7IG1vZGUgXCJhdmdcIiBvbiBhdmVyYWdlIGJhbGFuY2VzLCB3aGVyZSBgZXN0YFxuLy8gaXMgdGhlIGN1cnJlbnQgZml4ZWQtcG9pbnQgZXN0aW1hdGUgb2YgdGhlIGVuZGluZyBiYWxhbmNlcyAodGhlIGNhbGxlclxuLy8gaXRlcmF0ZXMpLiBNaXJyb3JzIGdlbmVyYXRlLnB5IGB5ZWFyX3Bhc3NgIG9wZXJhdGlvbiBmb3Igb3BlcmF0aW9uLlxuZnVuY3Rpb24geWVhclBhc3Mob3AsIGEsIHN1LCBiYWwsIG1vZGUpIHtcbiAgbGV0IGVfdGxiLCBlX21lenosIGVfcmV2LCBlX3VuZHJhd247XG4gIGlmIChtb2RlID09PSBcImJlZ2luXCIpIHtcbiAgICBlX3RsYiA9IGJhbC50bGI7IGVfbWV6eiA9IGJhbC5tZXp6OyBlX3JldiA9IGJhbC5yZXY7XG4gICAgZV91bmRyYXduID0gTWF0aC5tYXgoMCwgYS5yZXZvbHZlcl9jYXBhY2l0eSAtIGJhbC5yZXYpO1xuICB9IGVsc2Uge1xuICAgIGVfdGxiID0gKGJhbC50bGIgKyBiYWwuZXN0LnRsYikgLyAyO1xuICAgIGVfbWV6eiA9IChiYWwubWV6eiArIGJhbC5lc3QubWV6eikgLyAyO1xuICAgIGVfcmV2ID0gKGJhbC5yZXYgKyBiYWwuZXN0LnJldikgLyAyO1xuICAgIGVfdW5kcmF3biA9IE1hdGgubWF4KDAsIChhLnJldm9sdmVyX2NhcGFjaXR5IC0gYmFsLnJldiArIGEucmV2b2x2ZXJfY2FwYWNpdHkgLSBiYWwuZXN0LnJldikgLyAyKTtcbiAgfVxuICBjb25zdCBpbnRlcmVzdCA9IGEudGxiX3JhdGUgKiBlX3RsYiArIGEubWV6el9jYXNoX3JhdGUgKiBlX21lenogKyBhLnJldm9sdmVyX3JhdGUgKiBlX3JldiArIGEuY29tbWl0bWVudF9mZWUgKiBlX3VuZHJhd247XG4gIGNvbnN0IGVidCA9IG9wLmViaXRkYSAtIG9wLmRhIC0gaW50ZXJlc3Q7XG4gIGNvbnN0IHRheCA9IE1hdGgubWF4KDAsIGVidCAqIGEudGF4X3JhdGUpO1xuICBjb25zdCBuaSA9IGVidCAtIHRheDtcbiAgY29uc3QgY2ZhZHIgPSBuaSArIG9wLmRhIC0gb3AuY2FwZXggLSBvcC5kZWx0YV9ud2M7XG4gIGNvbnN0IHJldl9yZXBheSA9IE1hdGgubWluKGJhbC5yZXYsIE1hdGgubWF4KDAsIGNmYWRyKSk7XG4gIGNvbnN0IHJldl9kcmF3ID0gTWF0aC5taW4oTWF0aC5tYXgoMCwgYS5yZXZvbHZlcl9jYXBhY2l0eSAtIGJhbC5yZXYpLCBNYXRoLm1heCgwLCAtY2ZhZHIpKTtcbiAgY29uc3QgcmVzMSA9IGNmYWRyIC0gcmV2X3JlcGF5ICsgcmV2X2RyYXc7XG4gIGNvbnN0IG1hbmQgPSBNYXRoLm1pbihhLnRsYl9hbW9ydF9wY3QgKiBzdS50bGIwLCBiYWwudGxiKTtcbiAgbGV0IHJlczIgPSByZXMxIC0gbWFuZDtcbiAgY29uc3QgZHJhdzIgPSBNYXRoLm1pbihNYXRoLm1heCgwLCBhLnJldm9sdmVyX2NhcGFjaXR5IC0gKGJhbC5yZXYgKyByZXZfZHJhdykpLCBNYXRoLm1heCgwLCAtcmVzMikpO1xuICByZXMyID0gcmVzMiArIGRyYXcyO1xuICBjb25zdCBzd2VlcCA9IE1hdGgubWluKGEuY2FzaF9zd2VlcF9wY3QgKiBNYXRoLm1heCgwLCByZXMyKSwgYmFsLnRsYiAtIG1hbmQpO1xuICBjb25zdCBlbmQgPSB7XG4gICAgcmV2OiBiYWwucmV2ICsgcmV2X2RyYXcgKyBkcmF3MiAtIHJldl9yZXBheSxcbiAgICB0bGI6IGJhbC50bGIgLSBtYW5kIC0gc3dlZXAsXG4gICAgbWV6ejogYmFsLm1lenogKiAoMSArIGEubWV6el9waWtfcmF0ZSksXG4gICAgY2FzaDogYmFsLmNhc2ggKyByZXMyIC0gc3dlZXAsXG4gIH07XG4gIHJldHVybiB7XG4gICAgYmVnaW46IHsgcmV2OiBiYWwucmV2LCB0bGI6IGJhbC50bGIsIG1leno6IGJhbC5tZXp6LCBjYXNoOiBiYWwuY2FzaCB9LFxuICAgIGludGVyZXN0LCBlYnQsIHRheCwgbmksIGNmYWRyLCBtYW5kLCBzd2VlcCwgcmV0YWluZWQ6IHJlczIgLSBzd2VlcCxcbiAgICByZXZfZHJhdzogcmV2X2RyYXcgKyBkcmF3MiwgcmV2X3JlcGF5LCBlbmQsXG4gIH07XG59XG5cbi8vIFRoZSA1LXllYXIgcm9sbC1mb3J3YXJkIG9uIHRoZSBzdGRsaWIncyBtdWx0aS1zdGF0ZSBwcmltaXRpdmUgKFIzLTM3NSk6IHRoZVxuLy8gc3RhdGUgdHVwbGUge3JldiwgdGxiLCBtZXp6LCBjYXNofSBldm9sdmVzIHRocm91Z2ggZWFjaCB5ZWFyJ3Mgd2F0ZXJmYWxsIOKAlFxuLy8gdGhlIHN0cnVjdHVyZSBFeGNlbCB1bnJvbGxzIGFjcm9zcyBjb2x1bW5zLiAnYXZnJyBtb2RlIGl0ZXJhdGVzIGVhY2ggeWVhcidzXG4vLyBzdGVwIHRvIGEgZml4ZWQgcG9pbnQgKEV4Y2VsJ3MgaXRlcmF0aXZlLWNhbGMgY2lyY3VsYXIgcmVmZXJlbmNlLCBleHBsaWNpdCkuXG5mdW5jdGlvbiBzY2hlZHVsZVllYXJzKG9wcywgYSwgc3UsIG1vZGUpIHtcbiAgbGV0IGl0ZXJhdGlvbnMgPSAwO1xuICByZXR1cm4gcm9sbGZvcndhcmQob3BzLCB7XG4gICAgb3JkZXJCeTogWUVBUlNfT1JERVIsXG4gICAgYmVnaW46IHsgcmV2OiAwLCB0bGI6IHN1LnRsYjAsIG1leno6IHN1Lm1lenowLCBjYXNoOiBhLm1pbl9jYXNoIH0sXG4gICAgc3RlcDogKG9wLCBiYWwpID0+IHtcbiAgICAgIGxldCBvdXQ7XG4gICAgICBpZiAobW9kZSA9PT0gXCJiZWdpblwiKSB7XG4gICAgICAgIG91dCA9IHllYXJQYXNzKG9wLCBhLCBzdSwgYmFsLCBcImJlZ2luXCIpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy8gVGhlIHdpdGhpbi15ZWFyIGZpeGVkIHBvaW50IG9uIHRoZSBzdGRsaWIncyBmaXhwb2ludCBoZWxwZXIgKFIzLTM3OCk6XG4gICAgICAgIC8vIGl0ZXJhdGUgdGhlIGF2ZXJhZ2UtYmFsYW5jZSBlc3RpbWF0ZSB1bnRpbCBpdCBzdG9wcyBtb3ZpbmcsIHRoZW4gdGFrZVxuICAgICAgICAvLyBvbmUgZmluYWwgcGFzcyBhdCB0aGUgY29udmVyZ2VkIHN0YXRlIHNvIHRoZSB5ZWFyJ3Mgb3V0cHV0IGNvbHVtbnMgYXJlXG4gICAgICAgIC8vIGV4YWN0bHkgY29uc2lzdGVudCB3aXRoIGl0LiBOb24tY29udmVyZ2VuY2Ugc3VyZmFjZXMgYXMgYSB0aHJvd24gZXJyb3JcbiAgICAgICAgLy8g4oCUIHZpc2libGUsIHRoZSBvcHBvc2l0ZSBvZiBFeGNlbCdzIHNpbGVudCBpdGVyYXRpdmUgY2FsYy5cbiAgICAgICAgY29uc3QgdHJpYWwgPSB7IHJldjogYmFsLnJldiwgdGxiOiBiYWwudGxiLCBtZXp6OiBiYWwubWV6eiwgY2FzaDogYmFsLmNhc2gsIGVzdDogbnVsbCB9O1xuICAgICAgICBsZXQgbGFzdE91dCA9IG51bGw7XG4gICAgICAgIGNvbnN0IGZwID0gZml4cG9pbnQoXG4gICAgICAgICAgeyByZXY6IGJhbC5yZXYsIHRsYjogYmFsLnRsYiwgbWV6ejogYmFsLm1lenosIGNhc2g6IGJhbC5jYXNoIH0sXG4gICAgICAgICAgKGVzdCkgPT4ge1xuICAgICAgICAgICAgdHJpYWwuZXN0ID0gZXN0O1xuICAgICAgICAgICAgY29uc3QgcGFzcyA9IHllYXJQYXNzKG9wLCBhLCBzdSwgdHJpYWwsIFwiYXZnXCIpO1xuICAgICAgICAgICAgbGFzdE91dCA9IHBhc3M7XG4gICAgICAgICAgICByZXR1cm4gcGFzcy5lbmQ7XG4gICAgICAgICAgfSxcbiAgICAgICAgICB7IHRvbDogMWUtMTIsIG1heEl0ZXJhdGlvbnM6IDIwMCB9LFxuICAgICAgICApO1xuICAgICAgICBpZiAoIWZwLmNvbnZlcmdlZCkge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcImF2ZXJhZ2UtYmFsYW5jZSBpbnRlcmVzdCBkaWQgbm90IGNvbnZlcmdlIGluIHllYXIgXCIgKyBvcC55ZWFyKTtcbiAgICAgICAgfVxuICAgICAgICBpdGVyYXRpb25zICs9IGZwLml0ZXJhdGlvbnM7XG4gICAgICAgIG91dCA9IGxhc3RPdXQ7XG4gICAgICB9XG4gICAgICBjb25zdCBuZXREZWJ0ID0gb3V0LmVuZC50bGIgKyBvdXQuZW5kLm1lenogKyBvdXQuZW5kLnJldiAtIG91dC5lbmQuY2FzaDtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIG91dDoge1xuICAgICAgICAgIGludGVyZXN0OiBvdXQuaW50ZXJlc3QsIGNmYWRyOiBvdXQuY2ZhZHIsIG1hbmQ6IG91dC5tYW5kLCBzd2VlcDogb3V0LnN3ZWVwLFxuICAgICAgICAgIHJldGFpbmVkOiBvdXQucmV0YWluZWQsIHJldl9kcmF3OiBvdXQucmV2X2RyYXcsIHJldl9yZXBheTogb3V0LnJldl9yZXBheSxcbiAgICAgICAgICBuZXRfZGVidDogbmV0RGVidCwgbGV2ZXJhZ2U6IG5ldERlYnQgLyBvcC5lYml0ZGEsIGNvdmVyYWdlOiBvcC5lYml0ZGEgLyBvdXQuaW50ZXJlc3QsXG4gICAgICAgICAgaXRlcmF0aW9ucyxcbiAgICAgICAgfSxcbiAgICAgICAgbmV4dDogb3V0LmVuZCxcbiAgICAgIH07XG4gICAgfSxcbiAgfSk7XG59XG5cbi8vIFRoZSB3aG9sZSBtb2RlbCBhcyBvbmUgcHVyZSBmdW5jdGlvbiBvZiB0aGUgZml4dHVyZXMgKyBvdmVycmlkZXMg4oCUIHdoYXQgdGhlXG4vLyBzZW5zaXRpdml0eSBncmlkIG1hcHMgb3ZlciBhbmQgdGhlIGJyZWFrZXZlbiBnb2FsLXNlZWsgYmlzZWN0cyBvbi4gVGhpc1xuLy8gZGVjb21wb3NpdGlvbiBpcyAqZm9yY2VkKiBieSBSZWNrb25lcidzIG5vLWFtYmllbnQtcmVnaXN0cnkgcnVsZTogYSBjZWxsXG4vLyBjYW5ub3QgcmUtcnVuIG90aGVyIGNlbGxzIHdpdGggZGlmZmVyZW50IHBhcmFtcywgc28gdGhlIG1vZGVsIG11c3QgYmUgYVxuLy8gZnVuY3Rpb24gYmVmb3JlIGl0IGNhbiBiZSBzd2VwdC5cbmZ1bmN0aW9uIHJ1bk1vZGVsKGEsIGhpc3QsIHBsYW4sIHllYXJQbGFuLCBvKSB7XG4gIGNvbnN0IG92ZXJyaWRlcyA9IG8gfHwge307XG4gIGNvbnN0IGx0bSA9IGhpc3QucmVkdWNlKChhY2MsIGgpID0+IGFjYyArIGguZnkyMDI2ICogaC5tYXJnaW5fZnkyMDI2LCAwKTtcbiAgY29uc3Qgb3BzID0gYnVpbGRPcGVyYXRpbmcoaGlzdCwgcGxhbiwgeWVhclBsYW4sIGEpO1xuICBjb25zdCBzdSA9IHNvdXJjZXNVc2VzKGx0bSwgYSxcbiAgICBvdmVycmlkZXMuZW50cnlfbXVsdGlwbGUgPT09IHVuZGVmaW5lZCA/IGEuZW50cnlfbXVsdGlwbGUgOiBvdmVycmlkZXMuZW50cnlfbXVsdGlwbGUsXG4gICAgb3ZlcnJpZGVzLnRsYl90dXJucyA9PT0gdW5kZWZpbmVkID8gYS50bGJfdHVybnMgOiBvdmVycmlkZXMudGxiX3R1cm5zKTtcbiAgY29uc3Qgc2NoZWQgPSBzY2hlZHVsZVllYXJzKG9wcywgYSwgc3UsIFwiYmVnaW5cIik7XG4gIGNvbnN0IGxhc3QgPSBvcHNbb3BzLmxlbmd0aCAtIDFdO1xuICBjb25zdCBsYXN0UyA9IHNjaGVkW3NjaGVkLmxlbmd0aCAtIDFdO1xuICBjb25zdCBleGl0TXVsdGlwbGUgPSBvdmVycmlkZXMuZXhpdF9tdWx0aXBsZSA9PT0gdW5kZWZpbmVkID8gYS5leGl0X211bHRpcGxlIDogb3ZlcnJpZGVzLmV4aXRfbXVsdGlwbGU7XG4gIGNvbnN0IGV4aXRfZXYgPSBleGl0TXVsdGlwbGUgKiBsYXN0LmViaXRkYTtcbiAgY29uc3QgZXhpdF9lcXVpdHkgPSBleGl0X2V2IC0gbGFzdFMubmV0X2RlYnQ7XG4gIGNvbnN0IGZsb3dzID0gWy1zdS5zcG9uc29yX2VxdWl0eV0uY29uY2F0KEFycmF5KGEuaG9sZF95ZWFycyAtIDEpLmZpbGwoMCkpLmNvbmNhdChbZXhpdF9lcXVpdHldKTtcbiAgcmV0dXJuIHtcbiAgICBzdSwgZXhpdF9ldiwgbmV0X2RlYnQ6IGxhc3RTLm5ldF9kZWJ0LCBleGl0X2VxdWl0eSxcbiAgICBtb2ljOiBleGl0X2VxdWl0eSAvIHN1LnNwb25zb3JfZXF1aXR5LCBpcnI6IGlycihmbG93cyksXG4gIH07XG59XG5cbi8vIEdvYWwgc2VlazogdGhlIGV4aXQgbXVsdGlwbGUgYXQgd2hpY2ggSVJSID0gaHVyZGxlIChJUlIgaXMgaW5jcmVhc2luZyBpbiBpdCkuXG4vLyBFeGNlbCBkb2VzIHRoaXMgaW50ZXJhY3RpdmVseSAoRGF0YSDihpIgV2hhdC1JZiDihpIgR29hbCBTZWVrKTsgaGVyZSBpdCBpcyBhblxuLy8gZXhwbGljaXQgYmlzZWN0aW9uLCBzbyBpdCByZWNvbXB1dGVzIHdpdGggdGhlIG1vZGVsIGFuZCBpcyB0ZXN0YWJsZS5cbmZ1bmN0aW9uIGJyZWFrZXZlbkV4aXRNdWx0aXBsZShhLCBoaXN0LCBwbGFuLCB5ZWFyUGxhbiwgaHVyZGxlKSB7XG4gIC8vIEdvYWwgc2VlayBvbiB0aGUgc3RkbGliJ3Mgc29sdmUgKFIzLTM4MSk6IElSUiBpcyBpbmNyZWFzaW5nIGluIHRoZSBleGl0XG4gIC8vIG11bHRpcGxlLCBzbyB0aGUgYnJhY2tldCBpcyBtb25vdG9uZSBhbmQgYmlzZWN0aW9uIGlzIGV4YWN0LlxuICByZXR1cm4gc29sdmUoKG0pID0+IHJ1bk1vZGVsKGEsIGhpc3QsIHBsYW4sIHllYXJQbGFuLCB7IGV4aXRfbXVsdGlwbGU6IG0gfSkuaXJyLCBodXJkbGUsIDQuMCwgMTIuMCk7XG59XG5cbi8vIOKUgOKUgCBjZWxscyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuZXhwb3J0IGNvbnN0IGx0bV9lYml0ZGEgPSBjZWxsKHtcbiAgZG9jOiBcIkxUTSAoRlkyMDI2KSBFQklUREEgYXQgY2xvc2UsIEVVUiBtIOKAlCB0aGUgZW50cnkgbXVsdGlwbGUncyBiYXNlXCIsXG4gIGlucHV0czogeyBoaXN0OiBcImZpeHR1cmVzLmhpc3RvcmljYWxfc2VnbWVudHNcIiB9LFxuICBmb3JtdWxhOiAoeyBoaXN0IH0pID0+IGhpc3QucmVkdWNlKChhY2MsIGgpID0+IGFjYyArIGguZnkyMDI2ICogaC5tYXJnaW5fZnkyMDI2LCAwKSxcbn0pO1xuXG5leHBvcnQgY29uc3Qgb3BlcmF0aW5nID0gY2VsbCh7XG4gIGRvYzogXCJGaXZlLXllYXIgb3BlcmF0aW5nIGJ1aWxkOiByZXZlbnVlIGJ5IGNoYWluZWQgc2VnbWVudCBncm93dGgsIG1hcmdpbi13ZWlnaHRlZCBFQklUREEsIEQmQSwgY2FwZXgsIM6UTldDIOKAlCBvbmUgcm93IHBlciB5ZWFyIEZZMjAyN+KAk0ZZMjAzMVwiLFxuICBpbnB1dHM6IHtcbiAgICBoaXN0OiBcImZpeHR1cmVzLmhpc3RvcmljYWxfc2VnbWVudHNcIixcbiAgICBwbGFuOiBcImZpeHR1cmVzLm9wc19wbGFuXCIsXG4gICAgeWVhclBsYW46IFwiZml4dHVyZXMueWVhcl9wbGFuXCIsXG4gICAgYTogXCJmaXh0dXJlcy5hc3N1bXB0aW9uc1wiLFxuICB9LFxuICBmb3JtdWxhOiAoeyBoaXN0LCBwbGFuLCB5ZWFyUGxhbiwgYSB9KSA9PiBidWlsZE9wZXJhdGluZyhoaXN0LCBwbGFuLCB5ZWFyUGxhbiwgYVswXSksXG59KTtcblxuZXhwb3J0IGNvbnN0IHNvdXJjZXNfdXNlcyA9IGNlbGwoe1xuICBkb2M6IFwiU291cmNlcyAmIHVzZXMgYXQgY2xvc2UgKEVVUiBtKTogZW50cnkgRVYsIHB1cmNoYXNlIGVxdWl0eSwgZmVlcywgZnVuZGVkIGRlYnQsIGFuZCB0aGUgc3BvbnNvciBlcXVpdHkgcGx1Zy4gVGhlIGludGVyYWN0aXZlIGRlYWwga25vYnMgYXJlIHBhcmFtc1wiLFxuICBpbnB1dHM6IHsgbHRtOiBcIm1vZGVsLmx0bV9lYml0ZGFcIiwgYTogXCJmaXh0dXJlcy5hc3N1bXB0aW9uc1wiLCBlbnRyeTogXCJwYXJhbXMuZW50cnlfbXVsdGlwbGVcIiwgdGxiVHVybnM6IFwicGFyYW1zLnRsYl90dXJuc1wiIH0sXG4gIGZvcm11bGE6ICh7IGx0bSwgYSwgZW50cnksIHRsYlR1cm5zIH0pID0+IHNvdXJjZXNVc2VzKGx0bSwgYVswXSwgZW50cnksIHRsYlR1cm5zKSxcbn0pO1xuXG4vLyBPbmUtcm93IHByb2plY3Rpb24gb2Ygc291cmNlc191c2VzIHNoYXBlZCBmb3IgdGhlIGNvbnNlcnZhdGlvbiB0ZXN0OlxuLy8gY29tcG9uZW50cyAoZGVidCArIGNhc2ggKyBlcXVpdHkpIG11c3Qgc3VtIHRvIHRvdGFsIHVzZXMsIHJvdy13aXNlLlxuZXhwb3J0IGNvbnN0IHNvdXJjZXNfdXNlc19yb3cgPSBjZWxsKHtcbiAgZG9jOiBcIlNvdXJjZXMgJiB1c2VzIGFzIGEgc2luZ2xlIGNvbnNlcnZhdGlvbiByb3c6IHRsYjAgKyBtZXp6MCArIGNhc2hfdXNlZCArIHNwb25zb3JfZXF1aXR5ID0gdXNlc1wiLFxuICBpbnB1dHM6IHsgc3U6IFwibW9kZWwuc291cmNlc191c2VzXCIgfSxcbiAgZm9ybXVsYTogKHsgc3UgfSkgPT4gW3tcbiAgICB0bGIwOiBzdS50bGIwLCBtZXp6MDogc3UubWV6ejAsIGNhc2hfdXNlZDogc3UuY2FzaF91c2VkLFxuICAgIHNwb25zb3JfZXF1aXR5OiBzdS5zcG9uc29yX2VxdWl0eSwgdXNlc190b3RhbDogc3UudXNlcyxcbiAgfV0sXG59KTtcblxuZXhwb3J0IGNvbnN0IGRlYnRfc2NoZWR1bGUgPSBjZWxsKHtcbiAgZG9jOiBcIkRlYnQgc2NoZWR1bGUgRlkyMDI34oCTRlkyMDMxLCBpbnRlcmVzdCBvbiBiZWdpbm5pbmcgYmFsYW5jZXMgKG5vIGNpcmN1bGFyaXR5KTogcmV2b2x2ZXIgZHJhdy9yZXBheSwgVExCIG1hbmRhdG9yeSBhbW9ydGlzYXRpb24gKyA3NSUgY2FzaCBzd2VlcCwgbWV6emFuaW5lIFBJSyBhY2NydWFsLCBjYXNoIGJ1aWxkLCBsZXZlcmFnZSBhbmQgY292ZXJhZ2VcIixcbiAgaW5wdXRzOiB7IG9wczogXCJtb2RlbC5vcGVyYXRpbmdcIiwgc3U6IFwibW9kZWwuc291cmNlc191c2VzXCIsIGE6IFwiZml4dHVyZXMuYXNzdW1wdGlvbnNcIiB9LFxuICBmb3JtdWxhOiAoeyBvcHMsIHN1LCBhIH0pID0+IHNjaGVkdWxlWWVhcnMob3BzLCBhWzBdLCBzdSwgXCJiZWdpblwiKSxcbn0pO1xuXG5leHBvcnQgY29uc3QgZGVidF9zY2hlZHVsZV9hdmcgPSBjZWxsKHtcbiAgZG9jOiBcIkRlYnQgc2NoZWR1bGUgd2l0aCBpbnRlcmVzdCBvbiBBVkVSQUdFIGJhbGFuY2VzIOKAlCBFeGNlbCdzIGl0ZXJhdGl2ZS1jYWxjIGNpcmN1bGFyIHJlZmVyZW5jZSwgZXhwcmVzc2VkIGFzIGFuIGV4cGxpY2l0IHBlci15ZWFyIGZpeGVkIHBvaW50IGNvbnZlcmdlZCB0byAxZS0xMjsgcm93cyBjYXJyeSB0aGUgaXRlcmF0aW9uIGNvdW50XCIsXG4gIGlucHV0czogeyBvcHM6IFwibW9kZWwub3BlcmF0aW5nXCIsIHN1OiBcIm1vZGVsLnNvdXJjZXNfdXNlc1wiLCBhOiBcImZpeHR1cmVzLmFzc3VtcHRpb25zXCIgfSxcbiAgZm9ybXVsYTogKHsgb3BzLCBzdSwgYSB9KSA9PiBzY2hlZHVsZVllYXJzKG9wcywgYVswXSwgc3UsIFwiYXZnXCIpLFxufSk7XG5cbmV4cG9ydCBjb25zdCByZXR1cm5zID0gY2VsbCh7XG4gIGRvYzogXCJFeGl0IHJldHVybnMgYXQgRlkyMDMxOiBleGl0IEVWIGF0IHRoZSBleGl0IG11bHRpcGxlLCBsZXNzIG5ldCBkZWJ0LCDihpIgc3BvbnNvciBlcXVpdHkgdmFsdWUsIE1PSUMgYW5kIElSUiAoYmlzZWN0aW9uIG9uIHRoZSBhbm51YWwgZmxvd3MpXCIsXG4gIGlucHV0czoge1xuICAgIG9wczogXCJtb2RlbC5vcGVyYXRpbmdcIiwgc2NoZWQ6IFwibW9kZWwuZGVidF9zY2hlZHVsZVwiLCBzdTogXCJtb2RlbC5zb3VyY2VzX3VzZXNcIixcbiAgICBhOiBcImZpeHR1cmVzLmFzc3VtcHRpb25zXCIsIGV4aXQ6IFwicGFyYW1zLmV4aXRfbXVsdGlwbGVcIixcbiAgfSxcbiAgZm9ybXVsYTogKHsgb3BzLCBzY2hlZCwgc3UsIGEsIGV4aXQgfSkgPT4ge1xuICAgIGNvbnN0IGxhc3QgPSBvcHNbb3BzLmxlbmd0aCAtIDFdO1xuICAgIGNvbnN0IGxhc3RTID0gc2NoZWRbc2NoZWQubGVuZ3RoIC0gMV07XG4gICAgY29uc3QgZXhpdF9ldiA9IGV4aXQgKiBsYXN0LmViaXRkYTtcbiAgICBjb25zdCBleGl0X2VxdWl0eSA9IGV4aXRfZXYgLSBsYXN0Uy5uZXRfZGVidDtcbiAgICBjb25zdCBmbG93cyA9IFstc3Uuc3BvbnNvcl9lcXVpdHldLmNvbmNhdChBcnJheShhWzBdLmhvbGRfeWVhcnMgLSAxKS5maWxsKDApKS5jb25jYXQoW2V4aXRfZXF1aXR5XSk7XG4gICAgcmV0dXJuIHtcbiAgICAgIGV4aXRfZXYsIG5ldF9kZWJ0OiBsYXN0Uy5uZXRfZGVidCwgZXhpdF9lcXVpdHksIHNwb25zb3JfZXF1aXR5OiBzdS5zcG9uc29yX2VxdWl0eSxcbiAgICAgIG1vaWM6IGV4aXRfZXF1aXR5IC8gc3Uuc3BvbnNvcl9lcXVpdHksIGlycjogaXJyKGZsb3dzKSxcbiAgICB9O1xuICB9LFxufSk7XG5cbmV4cG9ydCBjb25zdCByZXR1cm5zX2F2ZyA9IGNlbGwoe1xuICBkb2M6IFwiRXhpdCByZXR1cm5zIHVuZGVyIHRoZSBhdmVyYWdlLWJhbGFuY2UgKGNvbnZlcmdlZCBjaXJjdWxhcikgZGVidCBzY2hlZHVsZSDigJQgdGhlIGFuc3dlciBFeGNlbCdzIGl0ZXJhdGl2ZSBzaGVldCB3b3VsZCBnaXZlXCIsXG4gIGlucHV0czoge1xuICAgIG9wczogXCJtb2RlbC5vcGVyYXRpbmdcIiwgc2NoZWQ6IFwibW9kZWwuZGVidF9zY2hlZHVsZV9hdmdcIiwgc3U6IFwibW9kZWwuc291cmNlc191c2VzXCIsXG4gICAgYTogXCJmaXh0dXJlcy5hc3N1bXB0aW9uc1wiLCBleGl0OiBcInBhcmFtcy5leGl0X211bHRpcGxlXCIsXG4gIH0sXG4gIGZvcm11bGE6ICh7IG9wcywgc2NoZWQsIHN1LCBhLCBleGl0IH0pID0+IHtcbiAgICBjb25zdCBsYXN0ID0gb3BzW29wcy5sZW5ndGggLSAxXTtcbiAgICBjb25zdCBsYXN0UyA9IHNjaGVkW3NjaGVkLmxlbmd0aCAtIDFdO1xuICAgIGNvbnN0IGV4aXRfZXYgPSBleGl0ICogbGFzdC5lYml0ZGE7XG4gICAgY29uc3QgZXhpdF9lcXVpdHkgPSBleGl0X2V2IC0gbGFzdFMubmV0X2RlYnQ7XG4gICAgY29uc3QgZmxvd3MgPSBbLXN1LnNwb25zb3JfZXF1aXR5XS5jb25jYXQoQXJyYXkoYVswXS5ob2xkX3llYXJzIC0gMSkuZmlsbCgwKSkuY29uY2F0KFtleGl0X2VxdWl0eV0pO1xuICAgIHJldHVybiB7IGV4aXRfZXYsIGV4aXRfZXF1aXR5LCBpcnI6IGlycihmbG93cyksIG1vaWM6IGV4aXRfZXF1aXR5IC8gc3Uuc3BvbnNvcl9lcXVpdHkgfTtcbiAgfSxcbn0pO1xuXG4vLyBUaGluIG5hbWVkIHNjYWxhcnMgdGhlIHRlbXBsYXRlIGFuZCB0ZXN0cyBiaW5kIHRvLlxuZXhwb3J0IGNvbnN0IHNwb25zb3JfaXJyID0gY2VsbCh7XG4gIGRvYzogXCJCYXNlLWNhc2Ugc3BvbnNvciBJUlIgYXMgYSBzY2FsYXIsIGZvciB0aGUgS3BpIHRpbGVcIixcbiAgaW5wdXRzOiB7IHI6IFwibW9kZWwucmV0dXJuc1wiIH0sXG4gIGZvcm11bGE6ICh7IHIgfSkgPT4gci5pcnIsXG59KTtcblxuZXhwb3J0IGNvbnN0IG1vaWMgPSBjZWxsKHtcbiAgZG9jOiBcIkJhc2UtY2FzZSBzcG9uc29yIE1PSUMgKHgpIGFzIGEgc2NhbGFyLCBmb3IgdGhlIEtwaSB0aWxlXCIsXG4gIGlucHV0czogeyByOiBcIm1vZGVsLnJldHVybnNcIiB9LFxuICBmb3JtdWxhOiAoeyByIH0pID0+IHIubW9pYyxcbn0pO1xuXG5leHBvcnQgY29uc3Qgc3BvbnNvcl9lcXVpdHkgPSBjZWxsKHtcbiAgZG9jOiBcIlNwb25zb3IgZXF1aXR5IGNoZXF1ZSBhdCBjbG9zZSAoRVVSIG0pLCBmb3IgdGhlIEtwaSB0aWxlXCIsXG4gIGlucHV0czogeyBzdTogXCJtb2RlbC5zb3VyY2VzX3VzZXNcIiB9LFxuICBmb3JtdWxhOiAoeyBzdSB9KSA9PiBzdS5zcG9uc29yX2VxdWl0eSxcbn0pO1xuXG5leHBvcnQgY29uc3Qgc2Vuc2l0aXZpdHkgPSBjZWxsKHtcbiAgZG9jOiBcIlR3by13YXkgc2Vuc2l0aXZpdHk6IHNwb25zb3IgSVJSIGFuZCBNT0lDIGZvciBleGl0IG11bHRpcGxlIDcuMOKAkzkuMHggw5cgVExCIGxldmVyYWdlIDQuMOKAkzYuMHgg4oCUIDI1IGZ1bGwgbW9kZWwgcmUtcnVucyBvdmVyIHRoZSBiYXNlIGZpeHR1cmVzIChub3QgdGhlIGxpdmUgcGFyYW1zKVwiLFxuICBpbnB1dHM6IHtcbiAgICBhOiBcImZpeHR1cmVzLmFzc3VtcHRpb25zXCIsIGhpc3Q6IFwiZml4dHVyZXMuaGlzdG9yaWNhbF9zZWdtZW50c1wiLFxuICAgIHBsYW46IFwiZml4dHVyZXMub3BzX3BsYW5cIiwgeWVhclBsYW46IFwiZml4dHVyZXMueWVhcl9wbGFuXCIsXG4gIH0sXG4gIGZvcm11bGE6ICh7IGEsIGhpc3QsIHBsYW4sIHllYXJQbGFuIH0pID0+IHtcbiAgICBjb25zdCBleGl0TXVsdHMgPSBbNy4wLCA3LjUsIDguMCwgOC41LCA5LjBdO1xuICAgIGNvbnN0IGxldnMgPSBbNC4wLCA0LjUsIDUuMCwgNS41LCA2LjBdO1xuICAgIGNvbnN0IHJvd3MgPSBbXTtcbiAgICBmb3IgKGNvbnN0IGV4aXRfbSBvZiBleGl0TXVsdHMpIHtcbiAgICAgIGZvciAoY29uc3QgbGV2IG9mIGxldnMpIHtcbiAgICAgICAgY29uc3QgciA9IHJ1bk1vZGVsKGFbMF0sIGhpc3QsIHBsYW4sIHllYXJQbGFuLCB7IGV4aXRfbXVsdGlwbGU6IGV4aXRfbSwgdGxiX3R1cm5zOiBsZXYgfSk7XG4gICAgICAgIHJvd3MucHVzaCh7XG4gICAgICAgICAgZXhpdF9tdWx0aXBsZTogZXhpdF9tLCB0bGJfdHVybnM6IGxldixcbiAgICAgICAgICBzcG9uc29yX2VxdWl0eTogci5zdS5zcG9uc29yX2VxdWl0eSwgZXhpdF9lcXVpdHk6IHIuZXhpdF9lcXVpdHksXG4gICAgICAgICAgbW9pYzogci5tb2ljLCBpcnI6IHIuaXJyLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHJvd3M7XG4gIH0sXG59KTtcblxuZXhwb3J0IGNvbnN0IGJyZWFrZXZlbl9leGl0X211bHRpcGxlID0gY2VsbCh7XG4gIGRvYzogXCJHb2FsIHNlZWs6IHRoZSBleGl0IG11bHRpcGxlIGF0IHdoaWNoIHRoZSBzcG9uc29yIElSUiBlcXVhbHMgdGhlIDIwJSBodXJkbGUgKElSUiBpcyBtb25vdG9uZSBpbiB0aGUgZXhpdCBtdWx0aXBsZSlcIixcbiAgaW5wdXRzOiB7XG4gICAgYTogXCJmaXh0dXJlcy5hc3N1bXB0aW9uc1wiLCBoaXN0OiBcImZpeHR1cmVzLmhpc3RvcmljYWxfc2VnbWVudHNcIixcbiAgICBwbGFuOiBcImZpeHR1cmVzLm9wc19wbGFuXCIsIHllYXJQbGFuOiBcImZpeHR1cmVzLnllYXJfcGxhblwiLFxuICB9LFxuICBmb3JtdWxhOiAoeyBhLCBoaXN0LCBwbGFuLCB5ZWFyUGxhbiB9KSA9PiBicmVha2V2ZW5FeGl0TXVsdGlwbGUoYVswXSwgaGlzdCwgcGxhbiwgeWVhclBsYW4sIGFbMF0uaHVyZGxlX2lyciksXG59KTtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQUEsSUFBQUEsT0FBQSxHQUFBQyxPQUFBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsTUFBTUMsV0FBVyxHQUFHLE1BQU07O0FBRTFCO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsU0FBU0MsY0FBY0EsQ0FBQ0MsSUFBSSxFQUFFQyxJQUFJLEVBQUVDLFFBQVEsRUFBRUMsQ0FBQyxFQUFFO0VBQy9DLE1BQU1DLFNBQVMsR0FBR0osSUFBSSxDQUFDSyxNQUFNLENBQUMsQ0FBQ0MsR0FBRyxFQUFFQyxDQUFDLEtBQUtELEdBQUcsR0FBR0MsQ0FBQyxDQUFDQyxNQUFNLEVBQUUsQ0FBQyxDQUFDO0VBQzVELE1BQU1DLEtBQUssR0FBRyxJQUFBQyxhQUFLLEVBQUNWLElBQUksQ0FBQyxDQUN0QlcsSUFBSSxDQUFDVixJQUFJLEVBQUU7SUFBRVcsRUFBRSxFQUFFO0VBQVUsQ0FBQyxDQUFDLENBQzdCQyxNQUFNLENBQUM7SUFBRUMsYUFBYSxFQUFHQyxDQUFDLElBQUssQ0FBQyxHQUFHQSxDQUFDLENBQUNDO0VBQU8sQ0FBQyxDQUFDLENBQzlDQyxJQUFJLENBQ0g7SUFBRUMsV0FBVyxFQUFFLElBQUFDLGVBQU8sRUFBQyxlQUFlO0VBQUUsQ0FBQyxFQUN6QztJQUFFQyxXQUFXLEVBQUUsU0FBUztJQUFFQyxPQUFPLEVBQUV2QjtFQUFZLENBQ2pELENBQUMsQ0FDQWUsTUFBTSxDQUFDO0lBQUVTLFdBQVcsRUFBR1AsQ0FBQyxJQUFLQSxDQUFDLENBQUNQLE1BQU0sR0FBR08sQ0FBQyxDQUFDRyxXQUFXO0lBQUVLLFVBQVUsRUFBR1IsQ0FBQyxJQUFLQSxDQUFDLENBQUNQLE1BQU0sR0FBR08sQ0FBQyxDQUFDRyxXQUFXLEdBQUdILENBQUMsQ0FBQ1M7RUFBTyxDQUFDLENBQUMsQ0FDaEhDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FDZkMsTUFBTSxDQUFDO0lBQUVDLE9BQU8sRUFBRSxJQUFBQyxXQUFHLEVBQUMsYUFBYSxDQUFDO0lBQUVDLE1BQU0sRUFBRSxJQUFBRCxXQUFHLEVBQUMsWUFBWTtFQUFFLENBQUMsQ0FBQyxDQUNsRUUsSUFBSSxDQUFDLENBQUM7RUFDVCxPQUFPLElBQUFwQixhQUFLLEVBQUNELEtBQUssQ0FBQyxDQUNoQnNCLElBQUksQ0FBQ2pDLFdBQVcsQ0FBQyxDQUNqQmtDLEdBQUcsQ0FBQyxTQUFTLEVBQUU7SUFBRUMsRUFBRSxFQUFFLGVBQWU7SUFBRUMsSUFBSSxFQUFFOUI7RUFBVSxDQUFDLENBQUMsQ0FDeERPLElBQUksQ0FBQ1QsUUFBUSxFQUFFO0lBQUVVLEVBQUUsRUFBRTtFQUFPLENBQUMsQ0FBQyxDQUM5QkMsTUFBTSxDQUFDO0lBQ05zQixFQUFFLEVBQUdwQixDQUFDLElBQUtaLENBQUMsQ0FBQ2lDLE1BQU0sR0FBR3JCLENBQUMsQ0FBQ1ksT0FBTztJQUMvQlUsS0FBSyxFQUFHdEIsQ0FBQyxJQUFLQSxDQUFDLENBQUN1QixTQUFTLEdBQUd2QixDQUFDLENBQUNZLE9BQU87SUFDckNZLFNBQVMsRUFBR3hCLENBQUMsSUFBS1osQ0FBQyxDQUFDcUMsT0FBTyxJQUFJekIsQ0FBQyxDQUFDWSxPQUFPLEdBQUdaLENBQUMsQ0FBQzBCLGFBQWE7RUFDNUQsQ0FBQyxDQUFDLENBQ0RYLElBQUksQ0FBQyxDQUFDLENBQ05ZLEdBQUcsQ0FBRTNCLENBQUMsS0FBTTtJQUNYNEIsSUFBSSxFQUFFNUIsQ0FBQyxDQUFDNEIsSUFBSTtJQUFFaEIsT0FBTyxFQUFFWixDQUFDLENBQUNZLE9BQU87SUFBRUUsTUFBTSxFQUFFZCxDQUFDLENBQUNjLE1BQU07SUFDbERNLEVBQUUsRUFBRXBCLENBQUMsQ0FBQ29CLEVBQUU7SUFBRUUsS0FBSyxFQUFFdEIsQ0FBQyxDQUFDc0IsS0FBSztJQUFFRSxTQUFTLEVBQUV4QixDQUFDLENBQUN3QjtFQUN6QyxDQUFDLENBQUMsQ0FBQztBQUNQO0FBRUEsU0FBU0ssV0FBV0EsQ0FBQ0MsR0FBRyxFQUFFMUMsQ0FBQyxFQUFFMkMsYUFBYSxFQUFFQyxRQUFRLEVBQUU7RUFDcEQsTUFBTUMsRUFBRSxHQUFHRixhQUFhLEdBQUdELEdBQUc7RUFDOUIsTUFBTUksZUFBZSxHQUFHRCxFQUFFLEdBQUc3QyxDQUFDLENBQUMrQyxhQUFhLEdBQUcvQyxDQUFDLENBQUNnRCxhQUFhO0VBQzlELE1BQU1DLElBQUksR0FBR0wsUUFBUSxHQUFHRixHQUFHO0VBQzNCLE1BQU1RLEtBQUssR0FBR2xELENBQUMsQ0FBQ21ELFVBQVUsR0FBR1QsR0FBRztFQUNoQyxNQUFNVSxRQUFRLEdBQUdwRCxDQUFDLENBQUNxRCxXQUFXLEdBQUdSLEVBQUU7RUFDbkMsTUFBTVMsUUFBUSxHQUFHdEQsQ0FBQyxDQUFDdUQsV0FBVyxJQUFJTixJQUFJLEdBQUdDLEtBQUssQ0FBQztFQUMvQyxNQUFNTSxJQUFJLEdBQUdWLGVBQWUsR0FBRzlDLENBQUMsQ0FBQytDLGFBQWEsR0FBR0ssUUFBUSxHQUFHRSxRQUFRO0VBQ3BFLE1BQU1HLFNBQVMsR0FBR3pELENBQUMsQ0FBQ2dELGFBQWEsR0FBR2hELENBQUMsQ0FBQzBELFFBQVE7RUFDOUMsTUFBTUMsY0FBYyxHQUFHSCxJQUFJLEdBQUdQLElBQUksR0FBR0MsS0FBSyxHQUFHTyxTQUFTO0VBQ3RELE9BQU87SUFDTEcsUUFBUSxFQUFFZixFQUFFO0lBQUVDLGVBQWU7SUFBRUcsSUFBSTtJQUFFQyxLQUFLO0lBQUVFLFFBQVE7SUFBRUUsUUFBUTtJQUM5REUsSUFBSTtJQUFFQyxTQUFTO0lBQUVFLGNBQWM7SUFBRUUsT0FBTyxFQUFFWixJQUFJLEdBQUdDLEtBQUssR0FBR08sU0FBUyxHQUFHRTtFQUN2RSxDQUFDO0FBQ0g7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTRyxRQUFRQSxDQUFDQyxFQUFFLEVBQUUvRCxDQUFDLEVBQUVnRSxFQUFFLEVBQUVDLEdBQUcsRUFBRUMsSUFBSSxFQUFFO0VBQ3RDLElBQUlDLEtBQUssRUFBRUMsTUFBTSxFQUFFQyxLQUFLLEVBQUVDLFNBQVM7RUFDbkMsSUFBSUosSUFBSSxLQUFLLE9BQU8sRUFBRTtJQUNwQkMsS0FBSyxHQUFHRixHQUFHLENBQUNNLEdBQUc7SUFBRUgsTUFBTSxHQUFHSCxHQUFHLENBQUNPLElBQUk7SUFBRUgsS0FBSyxHQUFHSixHQUFHLENBQUNRLEdBQUc7SUFDbkRILFNBQVMsR0FBR0ksSUFBSSxDQUFDQyxHQUFHLENBQUMsQ0FBQyxFQUFFM0UsQ0FBQyxDQUFDNEUsaUJBQWlCLEdBQUdYLEdBQUcsQ0FBQ1EsR0FBRyxDQUFDO0VBQ3hELENBQUMsTUFBTTtJQUNMTixLQUFLLEdBQUcsQ0FBQ0YsR0FBRyxDQUFDTSxHQUFHLEdBQUdOLEdBQUcsQ0FBQ1ksR0FBRyxDQUFDTixHQUFHLElBQUksQ0FBQztJQUNuQ0gsTUFBTSxHQUFHLENBQUNILEdBQUcsQ0FBQ08sSUFBSSxHQUFHUCxHQUFHLENBQUNZLEdBQUcsQ0FBQ0wsSUFBSSxJQUFJLENBQUM7SUFDdENILEtBQUssR0FBRyxDQUFDSixHQUFHLENBQUNRLEdBQUcsR0FBR1IsR0FBRyxDQUFDWSxHQUFHLENBQUNKLEdBQUcsSUFBSSxDQUFDO0lBQ25DSCxTQUFTLEdBQUdJLElBQUksQ0FBQ0MsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDM0UsQ0FBQyxDQUFDNEUsaUJBQWlCLEdBQUdYLEdBQUcsQ0FBQ1EsR0FBRyxHQUFHekUsQ0FBQyxDQUFDNEUsaUJBQWlCLEdBQUdYLEdBQUcsQ0FBQ1ksR0FBRyxDQUFDSixHQUFHLElBQUksQ0FBQyxDQUFDO0VBQ2xHO0VBQ0EsTUFBTUssUUFBUSxHQUFHOUUsQ0FBQyxDQUFDK0UsUUFBUSxHQUFHWixLQUFLLEdBQUduRSxDQUFDLENBQUNnRixjQUFjLEdBQUdaLE1BQU0sR0FBR3BFLENBQUMsQ0FBQ2lGLGFBQWEsR0FBR1osS0FBSyxHQUFHckUsQ0FBQyxDQUFDa0YsY0FBYyxHQUFHWixTQUFTO0VBQ3hILE1BQU1hLEdBQUcsR0FBR3BCLEVBQUUsQ0FBQ3JDLE1BQU0sR0FBR3FDLEVBQUUsQ0FBQy9CLEVBQUUsR0FBRzhDLFFBQVE7RUFDeEMsTUFBTU0sR0FBRyxHQUFHVixJQUFJLENBQUNDLEdBQUcsQ0FBQyxDQUFDLEVBQUVRLEdBQUcsR0FBR25GLENBQUMsQ0FBQ3FGLFFBQVEsQ0FBQztFQUN6QyxNQUFNQyxFQUFFLEdBQUdILEdBQUcsR0FBR0MsR0FBRztFQUNwQixNQUFNRyxLQUFLLEdBQUdELEVBQUUsR0FBR3ZCLEVBQUUsQ0FBQy9CLEVBQUUsR0FBRytCLEVBQUUsQ0FBQzdCLEtBQUssR0FBRzZCLEVBQUUsQ0FBQzNCLFNBQVM7RUFDbEQsTUFBTW9ELFNBQVMsR0FBR2QsSUFBSSxDQUFDZSxHQUFHLENBQUN4QixHQUFHLENBQUNRLEdBQUcsRUFBRUMsSUFBSSxDQUFDQyxHQUFHLENBQUMsQ0FBQyxFQUFFWSxLQUFLLENBQUMsQ0FBQztFQUN2RCxNQUFNRyxRQUFRLEdBQUdoQixJQUFJLENBQUNlLEdBQUcsQ0FBQ2YsSUFBSSxDQUFDQyxHQUFHLENBQUMsQ0FBQyxFQUFFM0UsQ0FBQyxDQUFDNEUsaUJBQWlCLEdBQUdYLEdBQUcsQ0FBQ1EsR0FBRyxDQUFDLEVBQUVDLElBQUksQ0FBQ0MsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDWSxLQUFLLENBQUMsQ0FBQztFQUMxRixNQUFNSSxJQUFJLEdBQUdKLEtBQUssR0FBR0MsU0FBUyxHQUFHRSxRQUFRO0VBQ3pDLE1BQU1FLElBQUksR0FBR2xCLElBQUksQ0FBQ2UsR0FBRyxDQUFDekYsQ0FBQyxDQUFDNkYsYUFBYSxHQUFHN0IsRUFBRSxDQUFDZixJQUFJLEVBQUVnQixHQUFHLENBQUNNLEdBQUcsQ0FBQztFQUN6RCxJQUFJdUIsSUFBSSxHQUFHSCxJQUFJLEdBQUdDLElBQUk7RUFDdEIsTUFBTUcsS0FBSyxHQUFHckIsSUFBSSxDQUFDZSxHQUFHLENBQUNmLElBQUksQ0FBQ0MsR0FBRyxDQUFDLENBQUMsRUFBRTNFLENBQUMsQ0FBQzRFLGlCQUFpQixJQUFJWCxHQUFHLENBQUNRLEdBQUcsR0FBR2lCLFFBQVEsQ0FBQyxDQUFDLEVBQUVoQixJQUFJLENBQUNDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQ21CLElBQUksQ0FBQyxDQUFDO0VBQ25HQSxJQUFJLEdBQUdBLElBQUksR0FBR0MsS0FBSztFQUNuQixNQUFNQyxLQUFLLEdBQUd0QixJQUFJLENBQUNlLEdBQUcsQ0FBQ3pGLENBQUMsQ0FBQ2lHLGNBQWMsR0FBR3ZCLElBQUksQ0FBQ0MsR0FBRyxDQUFDLENBQUMsRUFBRW1CLElBQUksQ0FBQyxFQUFFN0IsR0FBRyxDQUFDTSxHQUFHLEdBQUdxQixJQUFJLENBQUM7RUFDNUUsTUFBTU0sR0FBRyxHQUFHO0lBQ1Z6QixHQUFHLEVBQUVSLEdBQUcsQ0FBQ1EsR0FBRyxHQUFHaUIsUUFBUSxHQUFHSyxLQUFLLEdBQUdQLFNBQVM7SUFDM0NqQixHQUFHLEVBQUVOLEdBQUcsQ0FBQ00sR0FBRyxHQUFHcUIsSUFBSSxHQUFHSSxLQUFLO0lBQzNCeEIsSUFBSSxFQUFFUCxHQUFHLENBQUNPLElBQUksSUFBSSxDQUFDLEdBQUd4RSxDQUFDLENBQUNtRyxhQUFhLENBQUM7SUFDdENDLElBQUksRUFBRW5DLEdBQUcsQ0FBQ21DLElBQUksR0FBR04sSUFBSSxHQUFHRTtFQUMxQixDQUFDO0VBQ0QsT0FBTztJQUNMSyxLQUFLLEVBQUU7TUFBRTVCLEdBQUcsRUFBRVIsR0FBRyxDQUFDUSxHQUFHO01BQUVGLEdBQUcsRUFBRU4sR0FBRyxDQUFDTSxHQUFHO01BQUVDLElBQUksRUFBRVAsR0FBRyxDQUFDTyxJQUFJO01BQUU0QixJQUFJLEVBQUVuQyxHQUFHLENBQUNtQztJQUFLLENBQUM7SUFDckV0QixRQUFRO0lBQUVLLEdBQUc7SUFBRUMsR0FBRztJQUFFRSxFQUFFO0lBQUVDLEtBQUs7SUFBRUssSUFBSTtJQUFFSSxLQUFLO0lBQUVNLFFBQVEsRUFBRVIsSUFBSSxHQUFHRSxLQUFLO0lBQ2xFTixRQUFRLEVBQUVBLFFBQVEsR0FBR0ssS0FBSztJQUFFUCxTQUFTO0lBQUVVO0VBQ3pDLENBQUM7QUFDSDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVNLLGFBQWFBLENBQUNDLEdBQUcsRUFBRXhHLENBQUMsRUFBRWdFLEVBQUUsRUFBRUUsSUFBSSxFQUFFO0VBQ3ZDLElBQUl1QyxVQUFVLEdBQUcsQ0FBQztFQUNsQixPQUFPLElBQUFDLG1CQUFXLEVBQUNGLEdBQUcsRUFBRTtJQUN0QnRGLE9BQU8sRUFBRXZCLFdBQVc7SUFDcEIwRyxLQUFLLEVBQUU7TUFBRTVCLEdBQUcsRUFBRSxDQUFDO01BQUVGLEdBQUcsRUFBRVAsRUFBRSxDQUFDZixJQUFJO01BQUV1QixJQUFJLEVBQUVSLEVBQUUsQ0FBQ2QsS0FBSztNQUFFa0QsSUFBSSxFQUFFcEcsQ0FBQyxDQUFDMEQ7SUFBUyxDQUFDO0lBQ2pFaUQsSUFBSSxFQUFFQSxDQUFDNUMsRUFBRSxFQUFFRSxHQUFHLEtBQUs7TUFDakIsSUFBSTJDLEdBQUc7TUFDUCxJQUFJMUMsSUFBSSxLQUFLLE9BQU8sRUFBRTtRQUNwQjBDLEdBQUcsR0FBRzlDLFFBQVEsQ0FBQ0MsRUFBRSxFQUFFL0QsQ0FBQyxFQUFFZ0UsRUFBRSxFQUFFQyxHQUFHLEVBQUUsT0FBTyxDQUFDO01BQ3pDLENBQUMsTUFBTTtRQUNMO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQSxNQUFNNEMsS0FBSyxHQUFHO1VBQUVwQyxHQUFHLEVBQUVSLEdBQUcsQ0FBQ1EsR0FBRztVQUFFRixHQUFHLEVBQUVOLEdBQUcsQ0FBQ00sR0FBRztVQUFFQyxJQUFJLEVBQUVQLEdBQUcsQ0FBQ08sSUFBSTtVQUFFNEIsSUFBSSxFQUFFbkMsR0FBRyxDQUFDbUMsSUFBSTtVQUFFdkIsR0FBRyxFQUFFO1FBQUssQ0FBQztRQUN2RixJQUFJaUMsT0FBTyxHQUFHLElBQUk7UUFDbEIsTUFBTUMsRUFBRSxHQUFHLElBQUFDLGdCQUFRLEVBQ2pCO1VBQUV2QyxHQUFHLEVBQUVSLEdBQUcsQ0FBQ1EsR0FBRztVQUFFRixHQUFHLEVBQUVOLEdBQUcsQ0FBQ00sR0FBRztVQUFFQyxJQUFJLEVBQUVQLEdBQUcsQ0FBQ08sSUFBSTtVQUFFNEIsSUFBSSxFQUFFbkMsR0FBRyxDQUFDbUM7UUFBSyxDQUFDLEVBQzdEdkIsR0FBRyxJQUFLO1VBQ1BnQyxLQUFLLENBQUNoQyxHQUFHLEdBQUdBLEdBQUc7VUFDZixNQUFNb0MsSUFBSSxHQUFHbkQsUUFBUSxDQUFDQyxFQUFFLEVBQUUvRCxDQUFDLEVBQUVnRSxFQUFFLEVBQUU2QyxLQUFLLEVBQUUsS0FBSyxDQUFDO1VBQzlDQyxPQUFPLEdBQUdHLElBQUk7VUFDZCxPQUFPQSxJQUFJLENBQUNmLEdBQUc7UUFDakIsQ0FBQyxFQUNEO1VBQUVnQixHQUFHLEVBQUUsS0FBSztVQUFFQyxhQUFhLEVBQUU7UUFBSSxDQUNuQyxDQUFDO1FBQ0QsSUFBSSxDQUFDSixFQUFFLENBQUNLLFNBQVMsRUFBRTtVQUNqQixNQUFNLElBQUlDLEtBQUssQ0FBQyxvREFBb0QsR0FBR3RELEVBQUUsQ0FBQ3ZCLElBQUksQ0FBQztRQUNqRjtRQUNBaUUsVUFBVSxJQUFJTSxFQUFFLENBQUNOLFVBQVU7UUFDM0JHLEdBQUcsR0FBR0UsT0FBTztNQUNmO01BQ0EsTUFBTVEsT0FBTyxHQUFHVixHQUFHLENBQUNWLEdBQUcsQ0FBQzNCLEdBQUcsR0FBR3FDLEdBQUcsQ0FBQ1YsR0FBRyxDQUFDMUIsSUFBSSxHQUFHb0MsR0FBRyxDQUFDVixHQUFHLENBQUN6QixHQUFHLEdBQUdtQyxHQUFHLENBQUNWLEdBQUcsQ0FBQ0UsSUFBSTtNQUN2RSxPQUFPO1FBQ0xRLEdBQUcsRUFBRTtVQUNIOUIsUUFBUSxFQUFFOEIsR0FBRyxDQUFDOUIsUUFBUTtVQUFFUyxLQUFLLEVBQUVxQixHQUFHLENBQUNyQixLQUFLO1VBQUVLLElBQUksRUFBRWdCLEdBQUcsQ0FBQ2hCLElBQUk7VUFBRUksS0FBSyxFQUFFWSxHQUFHLENBQUNaLEtBQUs7VUFDMUVNLFFBQVEsRUFBRU0sR0FBRyxDQUFDTixRQUFRO1VBQUVaLFFBQVEsRUFBRWtCLEdBQUcsQ0FBQ2xCLFFBQVE7VUFBRUYsU0FBUyxFQUFFb0IsR0FBRyxDQUFDcEIsU0FBUztVQUN4RStCLFFBQVEsRUFBRUQsT0FBTztVQUFFRSxRQUFRLEVBQUVGLE9BQU8sR0FBR3ZELEVBQUUsQ0FBQ3JDLE1BQU07VUFBRStGLFFBQVEsRUFBRTFELEVBQUUsQ0FBQ3JDLE1BQU0sR0FBR2tGLEdBQUcsQ0FBQzlCLFFBQVE7VUFDcEYyQjtRQUNGLENBQUM7UUFDRGlCLElBQUksRUFBRWQsR0FBRyxDQUFDVjtNQUNaLENBQUM7SUFDSDtFQUNGLENBQUMsQ0FBQztBQUNKOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTeUIsUUFBUUEsQ0FBQzNILENBQUMsRUFBRUgsSUFBSSxFQUFFQyxJQUFJLEVBQUVDLFFBQVEsRUFBRTZILENBQUMsRUFBRTtFQUM1QyxNQUFNQyxTQUFTLEdBQUdELENBQUMsSUFBSSxDQUFDLENBQUM7RUFDekIsTUFBTWxGLEdBQUcsR0FBRzdDLElBQUksQ0FBQ0ssTUFBTSxDQUFDLENBQUNDLEdBQUcsRUFBRUMsQ0FBQyxLQUFLRCxHQUFHLEdBQUdDLENBQUMsQ0FBQ0MsTUFBTSxHQUFHRCxDQUFDLENBQUMwSCxhQUFhLEVBQUUsQ0FBQyxDQUFDO0VBQ3hFLE1BQU10QixHQUFHLEdBQUc1RyxjQUFjLENBQUNDLElBQUksRUFBRUMsSUFBSSxFQUFFQyxRQUFRLEVBQUVDLENBQUMsQ0FBQztFQUNuRCxNQUFNZ0UsRUFBRSxHQUFHdkIsV0FBVyxDQUFDQyxHQUFHLEVBQUUxQyxDQUFDLEVBQzNCNkgsU0FBUyxDQUFDRSxjQUFjLEtBQUtDLFNBQVMsR0FBR2hJLENBQUMsQ0FBQytILGNBQWMsR0FBR0YsU0FBUyxDQUFDRSxjQUFjLEVBQ3BGRixTQUFTLENBQUNJLFNBQVMsS0FBS0QsU0FBUyxHQUFHaEksQ0FBQyxDQUFDaUksU0FBUyxHQUFHSixTQUFTLENBQUNJLFNBQVMsQ0FBQztFQUN4RSxNQUFNQyxLQUFLLEdBQUczQixhQUFhLENBQUNDLEdBQUcsRUFBRXhHLENBQUMsRUFBRWdFLEVBQUUsRUFBRSxPQUFPLENBQUM7RUFDaEQsTUFBTW1FLElBQUksR0FBRzNCLEdBQUcsQ0FBQ0EsR0FBRyxDQUFDNEIsTUFBTSxHQUFHLENBQUMsQ0FBQztFQUNoQyxNQUFNQyxLQUFLLEdBQUdILEtBQUssQ0FBQ0EsS0FBSyxDQUFDRSxNQUFNLEdBQUcsQ0FBQyxDQUFDO0VBQ3JDLE1BQU1FLFlBQVksR0FBR1QsU0FBUyxDQUFDVSxhQUFhLEtBQUtQLFNBQVMsR0FBR2hJLENBQUMsQ0FBQ3VJLGFBQWEsR0FBR1YsU0FBUyxDQUFDVSxhQUFhO0VBQ3RHLE1BQU1DLE9BQU8sR0FBR0YsWUFBWSxHQUFHSCxJQUFJLENBQUN6RyxNQUFNO0VBQzFDLE1BQU0rRyxXQUFXLEdBQUdELE9BQU8sR0FBR0gsS0FBSyxDQUFDZCxRQUFRO0VBQzVDLE1BQU1tQixLQUFLLEdBQUcsQ0FBQyxDQUFDMUUsRUFBRSxDQUFDTCxjQUFjLENBQUMsQ0FBQ2dGLE1BQU0sQ0FBQ0MsS0FBSyxDQUFDNUksQ0FBQyxDQUFDNkksVUFBVSxHQUFHLENBQUMsQ0FBQyxDQUFDOUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM0RyxNQUFNLENBQUMsQ0FBQ0YsV0FBVyxDQUFDLENBQUM7RUFDaEcsT0FBTztJQUNMekUsRUFBRTtJQUFFd0UsT0FBTztJQUFFakIsUUFBUSxFQUFFYyxLQUFLLENBQUNkLFFBQVE7SUFBRWtCLFdBQVc7SUFDbERLLElBQUksRUFBRUwsV0FBVyxHQUFHekUsRUFBRSxDQUFDTCxjQUFjO0lBQUVvRixHQUFHLEVBQUUsSUFBQUEsV0FBRyxFQUFDTCxLQUFLO0VBQ3ZELENBQUM7QUFDSDs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxTQUFTTSxxQkFBcUJBLENBQUNoSixDQUFDLEVBQUVILElBQUksRUFBRUMsSUFBSSxFQUFFQyxRQUFRLEVBQUVrSixNQUFNLEVBQUU7RUFDOUQ7RUFDQTtFQUNBLE9BQU8sSUFBQUMsYUFBSyxFQUFFQyxDQUFDLElBQUt4QixRQUFRLENBQUMzSCxDQUFDLEVBQUVILElBQUksRUFBRUMsSUFBSSxFQUFFQyxRQUFRLEVBQUU7SUFBRXdJLGFBQWEsRUFBRVk7RUFBRSxDQUFDLENBQUMsQ0FBQ0osR0FBRyxFQUFFRSxNQUFNLEVBQUUsR0FBRyxFQUFFLElBQUksQ0FBQztBQUNyRzs7QUFFQTs7QUFFTyxNQUFNRyxVQUFVLEdBQUFDLE9BQUEsQ0FBQUQsVUFBQSxHQUFHLElBQUFFLFlBQUksRUFBQztFQUM3QkMsR0FBRyxFQUFFLGlFQUFpRTtFQUN0RUMsTUFBTSxFQUFFO0lBQUUzSixJQUFJLEVBQUU7RUFBK0IsQ0FBQztFQUNoRDRKLE9BQU8sRUFBRUEsQ0FBQztJQUFFNUo7RUFBSyxDQUFDLEtBQUtBLElBQUksQ0FBQ0ssTUFBTSxDQUFDLENBQUNDLEdBQUcsRUFBRUMsQ0FBQyxLQUFLRCxHQUFHLEdBQUdDLENBQUMsQ0FBQ0MsTUFBTSxHQUFHRCxDQUFDLENBQUMwSCxhQUFhLEVBQUUsQ0FBQztBQUNwRixDQUFDLENBQUM7QUFFSyxNQUFNNEIsU0FBUyxHQUFBTCxPQUFBLENBQUFLLFNBQUEsR0FBRyxJQUFBSixZQUFJLEVBQUM7RUFDNUJDLEdBQUcsRUFBRSx5SUFBeUk7RUFDOUlDLE1BQU0sRUFBRTtJQUNOM0osSUFBSSxFQUFFLDhCQUE4QjtJQUNwQ0MsSUFBSSxFQUFFLG1CQUFtQjtJQUN6QkMsUUFBUSxFQUFFLG9CQUFvQjtJQUM5QkMsQ0FBQyxFQUFFO0VBQ0wsQ0FBQztFQUNEeUosT0FBTyxFQUFFQSxDQUFDO0lBQUU1SixJQUFJO0lBQUVDLElBQUk7SUFBRUMsUUFBUTtJQUFFQztFQUFFLENBQUMsS0FBS0osY0FBYyxDQUFDQyxJQUFJLEVBQUVDLElBQUksRUFBRUMsUUFBUSxFQUFFQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JGLENBQUMsQ0FBQztBQUVLLE1BQU0ySixZQUFZLEdBQUFOLE9BQUEsQ0FBQU0sWUFBQSxHQUFHLElBQUFMLFlBQUksRUFBQztFQUMvQkMsR0FBRyxFQUFFLG1KQUFtSjtFQUN4SkMsTUFBTSxFQUFFO0lBQUU5RyxHQUFHLEVBQUUsa0JBQWtCO0lBQUUxQyxDQUFDLEVBQUUsc0JBQXNCO0lBQUU0SixLQUFLLEVBQUUsdUJBQXVCO0lBQUVoSCxRQUFRLEVBQUU7RUFBbUIsQ0FBQztFQUM1SDZHLE9BQU8sRUFBRUEsQ0FBQztJQUFFL0csR0FBRztJQUFFMUMsQ0FBQztJQUFFNEosS0FBSztJQUFFaEg7RUFBUyxDQUFDLEtBQUtILFdBQVcsQ0FBQ0MsR0FBRyxFQUFFMUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFNEosS0FBSyxFQUFFaEgsUUFBUTtBQUNsRixDQUFDLENBQUM7O0FBRUY7QUFDQTtBQUNPLE1BQU1pSCxnQkFBZ0IsR0FBQVIsT0FBQSxDQUFBUSxnQkFBQSxHQUFHLElBQUFQLFlBQUksRUFBQztFQUNuQ0MsR0FBRyxFQUFFLCtGQUErRjtFQUNwR0MsTUFBTSxFQUFFO0lBQUV4RixFQUFFLEVBQUU7RUFBcUIsQ0FBQztFQUNwQ3lGLE9BQU8sRUFBRUEsQ0FBQztJQUFFekY7RUFBRyxDQUFDLEtBQUssQ0FBQztJQUNwQmYsSUFBSSxFQUFFZSxFQUFFLENBQUNmLElBQUk7SUFBRUMsS0FBSyxFQUFFYyxFQUFFLENBQUNkLEtBQUs7SUFBRU8sU0FBUyxFQUFFTyxFQUFFLENBQUNQLFNBQVM7SUFDdkRFLGNBQWMsRUFBRUssRUFBRSxDQUFDTCxjQUFjO0lBQUVtRyxVQUFVLEVBQUU5RixFQUFFLENBQUNSO0VBQ3BELENBQUM7QUFDSCxDQUFDLENBQUM7QUFFSyxNQUFNdUcsYUFBYSxHQUFBVixPQUFBLENBQUFVLGFBQUEsR0FBRyxJQUFBVCxZQUFJLEVBQUM7RUFDaENDLEdBQUcsRUFBRSwwTUFBME07RUFDL01DLE1BQU0sRUFBRTtJQUFFaEQsR0FBRyxFQUFFLGlCQUFpQjtJQUFFeEMsRUFBRSxFQUFFLG9CQUFvQjtJQUFFaEUsQ0FBQyxFQUFFO0VBQXVCLENBQUM7RUFDdkZ5SixPQUFPLEVBQUVBLENBQUM7SUFBRWpELEdBQUc7SUFBRXhDLEVBQUU7SUFBRWhFO0VBQUUsQ0FBQyxLQUFLdUcsYUFBYSxDQUFDQyxHQUFHLEVBQUV4RyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUVnRSxFQUFFLEVBQUUsT0FBTztBQUNuRSxDQUFDLENBQUM7QUFFSyxNQUFNZ0csaUJBQWlCLEdBQUFYLE9BQUEsQ0FBQVcsaUJBQUEsR0FBRyxJQUFBVixZQUFJLEVBQUM7RUFDcENDLEdBQUcsRUFBRSwrTEFBK0w7RUFDcE1DLE1BQU0sRUFBRTtJQUFFaEQsR0FBRyxFQUFFLGlCQUFpQjtJQUFFeEMsRUFBRSxFQUFFLG9CQUFvQjtJQUFFaEUsQ0FBQyxFQUFFO0VBQXVCLENBQUM7RUFDdkZ5SixPQUFPLEVBQUVBLENBQUM7SUFBRWpELEdBQUc7SUFBRXhDLEVBQUU7SUFBRWhFO0VBQUUsQ0FBQyxLQUFLdUcsYUFBYSxDQUFDQyxHQUFHLEVBQUV4RyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUVnRSxFQUFFLEVBQUUsS0FBSztBQUNqRSxDQUFDLENBQUM7QUFFSyxNQUFNaUcsT0FBTyxHQUFBWixPQUFBLENBQUFZLE9BQUEsR0FBRyxJQUFBWCxZQUFJLEVBQUM7RUFDMUJDLEdBQUcsRUFBRSwySUFBMkk7RUFDaEpDLE1BQU0sRUFBRTtJQUNOaEQsR0FBRyxFQUFFLGlCQUFpQjtJQUFFMEIsS0FBSyxFQUFFLHFCQUFxQjtJQUFFbEUsRUFBRSxFQUFFLG9CQUFvQjtJQUM5RWhFLENBQUMsRUFBRSxzQkFBc0I7SUFBRWtLLElBQUksRUFBRTtFQUNuQyxDQUFDO0VBQ0RULE9BQU8sRUFBRUEsQ0FBQztJQUFFakQsR0FBRztJQUFFMEIsS0FBSztJQUFFbEUsRUFBRTtJQUFFaEUsQ0FBQztJQUFFa0s7RUFBSyxDQUFDLEtBQUs7SUFDeEMsTUFBTS9CLElBQUksR0FBRzNCLEdBQUcsQ0FBQ0EsR0FBRyxDQUFDNEIsTUFBTSxHQUFHLENBQUMsQ0FBQztJQUNoQyxNQUFNQyxLQUFLLEdBQUdILEtBQUssQ0FBQ0EsS0FBSyxDQUFDRSxNQUFNLEdBQUcsQ0FBQyxDQUFDO0lBQ3JDLE1BQU1JLE9BQU8sR0FBRzBCLElBQUksR0FBRy9CLElBQUksQ0FBQ3pHLE1BQU07SUFDbEMsTUFBTStHLFdBQVcsR0FBR0QsT0FBTyxHQUFHSCxLQUFLLENBQUNkLFFBQVE7SUFDNUMsTUFBTW1CLEtBQUssR0FBRyxDQUFDLENBQUMxRSxFQUFFLENBQUNMLGNBQWMsQ0FBQyxDQUFDZ0YsTUFBTSxDQUFDQyxLQUFLLENBQUM1SSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM2SSxVQUFVLEdBQUcsQ0FBQyxDQUFDLENBQUM5RyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzRHLE1BQU0sQ0FBQyxDQUFDRixXQUFXLENBQUMsQ0FBQztJQUNuRyxPQUFPO01BQ0xELE9BQU87TUFBRWpCLFFBQVEsRUFBRWMsS0FBSyxDQUFDZCxRQUFRO01BQUVrQixXQUFXO01BQUU5RSxjQUFjLEVBQUVLLEVBQUUsQ0FBQ0wsY0FBYztNQUNqRm1GLElBQUksRUFBRUwsV0FBVyxHQUFHekUsRUFBRSxDQUFDTCxjQUFjO01BQUVvRixHQUFHLEVBQUUsSUFBQUEsV0FBRyxFQUFDTCxLQUFLO0lBQ3ZELENBQUM7RUFDSDtBQUNGLENBQUMsQ0FBQztBQUVLLE1BQU15QixXQUFXLEdBQUFkLE9BQUEsQ0FBQWMsV0FBQSxHQUFHLElBQUFiLFlBQUksRUFBQztFQUM5QkMsR0FBRyxFQUFFLDJIQUEySDtFQUNoSUMsTUFBTSxFQUFFO0lBQ05oRCxHQUFHLEVBQUUsaUJBQWlCO0lBQUUwQixLQUFLLEVBQUUseUJBQXlCO0lBQUVsRSxFQUFFLEVBQUUsb0JBQW9CO0lBQ2xGaEUsQ0FBQyxFQUFFLHNCQUFzQjtJQUFFa0ssSUFBSSxFQUFFO0VBQ25DLENBQUM7RUFDRFQsT0FBTyxFQUFFQSxDQUFDO0lBQUVqRCxHQUFHO0lBQUUwQixLQUFLO0lBQUVsRSxFQUFFO0lBQUVoRSxDQUFDO0lBQUVrSztFQUFLLENBQUMsS0FBSztJQUN4QyxNQUFNL0IsSUFBSSxHQUFHM0IsR0FBRyxDQUFDQSxHQUFHLENBQUM0QixNQUFNLEdBQUcsQ0FBQyxDQUFDO0lBQ2hDLE1BQU1DLEtBQUssR0FBR0gsS0FBSyxDQUFDQSxLQUFLLENBQUNFLE1BQU0sR0FBRyxDQUFDLENBQUM7SUFDckMsTUFBTUksT0FBTyxHQUFHMEIsSUFBSSxHQUFHL0IsSUFBSSxDQUFDekcsTUFBTTtJQUNsQyxNQUFNK0csV0FBVyxHQUFHRCxPQUFPLEdBQUdILEtBQUssQ0FBQ2QsUUFBUTtJQUM1QyxNQUFNbUIsS0FBSyxHQUFHLENBQUMsQ0FBQzFFLEVBQUUsQ0FBQ0wsY0FBYyxDQUFDLENBQUNnRixNQUFNLENBQUNDLEtBQUssQ0FBQzVJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzZJLFVBQVUsR0FBRyxDQUFDLENBQUMsQ0FBQzlHLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDNEcsTUFBTSxDQUFDLENBQUNGLFdBQVcsQ0FBQyxDQUFDO0lBQ25HLE9BQU87TUFBRUQsT0FBTztNQUFFQyxXQUFXO01BQUVNLEdBQUcsRUFBRSxJQUFBQSxXQUFHLEVBQUNMLEtBQUssQ0FBQztNQUFFSSxJQUFJLEVBQUVMLFdBQVcsR0FBR3pFLEVBQUUsQ0FBQ0w7SUFBZSxDQUFDO0VBQ3pGO0FBQ0YsQ0FBQyxDQUFDOztBQUVGO0FBQ08sTUFBTXlHLFdBQVcsR0FBQWYsT0FBQSxDQUFBZSxXQUFBLEdBQUcsSUFBQWQsWUFBSSxFQUFDO0VBQzlCQyxHQUFHLEVBQUUscURBQXFEO0VBQzFEQyxNQUFNLEVBQUU7SUFBRTVJLENBQUMsRUFBRTtFQUFnQixDQUFDO0VBQzlCNkksT0FBTyxFQUFFQSxDQUFDO0lBQUU3STtFQUFFLENBQUMsS0FBS0EsQ0FBQyxDQUFDbUk7QUFDeEIsQ0FBQyxDQUFDO0FBRUssTUFBTUQsSUFBSSxHQUFBTyxPQUFBLENBQUFQLElBQUEsR0FBRyxJQUFBUSxZQUFJLEVBQUM7RUFDdkJDLEdBQUcsRUFBRSwwREFBMEQ7RUFDL0RDLE1BQU0sRUFBRTtJQUFFNUksQ0FBQyxFQUFFO0VBQWdCLENBQUM7RUFDOUI2SSxPQUFPLEVBQUVBLENBQUM7SUFBRTdJO0VBQUUsQ0FBQyxLQUFLQSxDQUFDLENBQUNrSTtBQUN4QixDQUFDLENBQUM7QUFFSyxNQUFNbkYsY0FBYyxHQUFBMEYsT0FBQSxDQUFBMUYsY0FBQSxHQUFHLElBQUEyRixZQUFJLEVBQUM7RUFDakNDLEdBQUcsRUFBRSwwREFBMEQ7RUFDL0RDLE1BQU0sRUFBRTtJQUFFeEYsRUFBRSxFQUFFO0VBQXFCLENBQUM7RUFDcEN5RixPQUFPLEVBQUVBLENBQUM7SUFBRXpGO0VBQUcsQ0FBQyxLQUFLQSxFQUFFLENBQUNMO0FBQzFCLENBQUMsQ0FBQztBQUVLLE1BQU0wRyxXQUFXLEdBQUFoQixPQUFBLENBQUFnQixXQUFBLEdBQUcsSUFBQWYsWUFBSSxFQUFDO0VBQzlCQyxHQUFHLEVBQUUsbUtBQW1LO0VBQ3hLQyxNQUFNLEVBQUU7SUFDTnhKLENBQUMsRUFBRSxzQkFBc0I7SUFBRUgsSUFBSSxFQUFFLDhCQUE4QjtJQUMvREMsSUFBSSxFQUFFLG1CQUFtQjtJQUFFQyxRQUFRLEVBQUU7RUFDdkMsQ0FBQztFQUNEMEosT0FBTyxFQUFFQSxDQUFDO0lBQUV6SixDQUFDO0lBQUVILElBQUk7SUFBRUMsSUFBSTtJQUFFQztFQUFTLENBQUMsS0FBSztJQUN4QyxNQUFNdUssU0FBUyxHQUFHLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsQ0FBQztJQUMzQyxNQUFNQyxJQUFJLEdBQUcsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxDQUFDO0lBQ3RDLE1BQU01SSxJQUFJLEdBQUcsRUFBRTtJQUNmLEtBQUssTUFBTTZJLE1BQU0sSUFBSUYsU0FBUyxFQUFFO01BQzlCLEtBQUssTUFBTUcsR0FBRyxJQUFJRixJQUFJLEVBQUU7UUFDdEIsTUFBTTNKLENBQUMsR0FBRytHLFFBQVEsQ0FBQzNILENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRUgsSUFBSSxFQUFFQyxJQUFJLEVBQUVDLFFBQVEsRUFBRTtVQUFFd0ksYUFBYSxFQUFFaUMsTUFBTTtVQUFFdkMsU0FBUyxFQUFFd0M7UUFBSSxDQUFDLENBQUM7UUFDekY5SSxJQUFJLENBQUMrSSxJQUFJLENBQUM7VUFDUm5DLGFBQWEsRUFBRWlDLE1BQU07VUFBRXZDLFNBQVMsRUFBRXdDLEdBQUc7VUFDckM5RyxjQUFjLEVBQUUvQyxDQUFDLENBQUNvRCxFQUFFLENBQUNMLGNBQWM7VUFBRThFLFdBQVcsRUFBRTdILENBQUMsQ0FBQzZILFdBQVc7VUFDL0RLLElBQUksRUFBRWxJLENBQUMsQ0FBQ2tJLElBQUk7VUFBRUMsR0FBRyxFQUFFbkksQ0FBQyxDQUFDbUk7UUFDdkIsQ0FBQyxDQUFDO01BQ0o7SUFDRjtJQUNBLE9BQU9wSCxJQUFJO0VBQ2I7QUFDRixDQUFDLENBQUM7QUFFSyxNQUFNZ0osdUJBQXVCLEdBQUF0QixPQUFBLENBQUFzQix1QkFBQSxHQUFHLElBQUFyQixZQUFJLEVBQUM7RUFDMUNDLEdBQUcsRUFBRSxvSEFBb0g7RUFDekhDLE1BQU0sRUFBRTtJQUNOeEosQ0FBQyxFQUFFLHNCQUFzQjtJQUFFSCxJQUFJLEVBQUUsOEJBQThCO0lBQy9EQyxJQUFJLEVBQUUsbUJBQW1CO0lBQUVDLFFBQVEsRUFBRTtFQUN2QyxDQUFDO0VBQ0QwSixPQUFPLEVBQUVBLENBQUM7SUFBRXpKLENBQUM7SUFBRUgsSUFBSTtJQUFFQyxJQUFJO0lBQUVDO0VBQVMsQ0FBQyxLQUFLaUoscUJBQXFCLENBQUNoSixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUVILElBQUksRUFBRUMsSUFBSSxFQUFFQyxRQUFRLEVBQUVDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzRLLFVBQVU7QUFDN0csQ0FBQyxDQUFDIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}