var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      blockquote: "blockquote",
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      h3: "h3",
      hr: "hr",
      li: "li",
      ol: "ol",
      p: "p",
      pre: "pre",
      strong: "strong",
      table: "table",
      tbody: "tbody",
      td: "td",
      th: "th",
      thead: "thead",
      tr: "tr",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "immediatelyrun-connector-egress-fixing-host-fixed-fetch-targets-for-the-dumb-pipe-connector",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "immediatelyrun-connector-egress-fixing-host-fixed-fetch-targets-for-the-dumb-pipe-connector"
      }), "immediately.run Connector Egress-Fixing — host-fixed fetch targets for the dumb-pipe connector"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Status:"
      }), " proposal / draft — addresses ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "REPORTING_SPREADSHEET_SPEC.md"
      }), " §12 ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Q3"
      }), "; the D2 M0 design-sprint output of ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "../ARCHITECTURE_PLAN.md"
      }), " §9/§10, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "revised after adversarial-review-2"
      }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "../ADVERSARIAL_REVIEW_2.md"
      }), " §A). The reach-fixing core is sound; three additions were forced by the pass — a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "pinned egress path for secret-bearing feeds"
      }), " (§3.1, the built proxy is bypassed on the secret path), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "host-minted opaque cursors + request-body cap"
      }), " (§2, closing the connector-authored write channels), and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "write-sink consent"
      }), " (§2.1, for the author-hostile-template threat egress-fixing does not touch). The honest Q2 answer is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "does not suffice to call the connector safe"
      }), " — bounded, not eliminated. Design only; nothing here is built. · ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Updated:"
      }), " 2026-07-09"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["The single implementation-status source for this spec is\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "docs/status/CONNECTOR_EGRESS_FIXING_STATUS.md"
          })]
        }), " (to be created when build starts) —\nwhere this document and that one disagree, the status doc governs."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Reads first:"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "REPORTING_SPREADSHEET_SPEC.md"
        }), " §3.1 (reach-not-egress), §3.2 (the\nno-both invariant is an app discipline that ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "falls back onto this mechanism"
        }), " against a\nmetacircular-connector fork — RB-1), §4.5 (connector = dumb pipe), §12 Q2/Q3;\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "UI_AS_APPS_SPEC.md"
        }), " §5.11 (host-proxied ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "net:fetch"
        }), "); ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "HOST_ORIGIN_HARDENING_SPEC.md"
        }), "\n§2.1 (the parent-fetch classes; server-side proxy); ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "SECRETS_SPEC.md"
        }), " §6 (use-not-read\nsecret injection); ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "TRUST_AND_SAFETY_SPEC.md"
        }), " TS-4 (body-exfil residual), TS-5b\n(read+egress combo). Companion: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "../ADVERSARIAL_REVIEW_1.md"
        }), " (D2 is one of two\nundesigned deltas gating live)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-0",
      "data-slug": "0-the-finding-that-reframes-q3-normative-intent",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-0"
      }), "0. The finding that reframes Q3  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative intent)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Q3 has been described as \"UNDESIGNED — the single most load-bearing gap.\" Reading the code\nsharpens ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "and complicates"
      }), " that: ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["an SSRF/DNS-rebinding/redirect-resistant egress proxy\nexists on the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "server"
        }), " path"]
      }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "immediately-run-backend/src/netFetch.ts"
      }), " resolves a hostname\nto ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "all"
      }), " its addresses, rejects if ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "any"
      }), " is private/loopback/link-local/metadata, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "pins"
      }), "\nthe connection to the validated addresses (an undici ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "Agent"
      }), " whose ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "lookup"
      }), " returns only\nthose), follows redirects ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "manual"
      }), " with a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "per-hop re-resolve + re-validate"
      }), " under a hop cap,\nforwards ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "no"
      }), " IR credentials, and size-bounds the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "response"
      }), " body. The host (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "site-main"
      }), ")\ncomputes a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "manifest ∩ grant"
        })
      }), " allowlist (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "netFetchPolicy.ts"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "effectiveAllowlist"
      }), ")."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Adversarial-review-2 correction (D2-F5) — do NOT claim \"reuse the built pinning proxy\nunchanged.\""
        }), " The connector's dangerous feeds carry an injected secret (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "injectSecret"
        }), "), and\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "netFetchHandler.ts"
        }), " issues secret-bearing requests ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "browser-direct"
        }), ", deliberately ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "not"
        }), "\nthrough the server proxy (\"the value must never hit the server\"). The browser path\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "netFetchProxy.ts"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "performGuardedFetch"
        }), ") does ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "no DNS resolution and no pinning"
        }), " — so for\nexactly the feeds that make the connector a TS-5b hazard, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "DNS-rebinding is NOT contained."
        }), "\nThis spec therefore has real work beyond the target-fixing layer: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "a pinned egress path for\nsecret-bearing connector feeds"
        }), " (§3.1). The general (non-secret) feed does use the pinned\nserver path — but its backend-unreachable fallback also drops pinning. Two shipped-code bugs\nin the blocklist were also found: IPv6 link-local matched ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "fe80"
        }), "-only (misses ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "fe80::/10"
        }), "),\nand hex IPv4-mapped IPv6 unmatched — filed separately."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["So D2 is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "not"
      }), " \"build Smokescreen,\" but it is also ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "not"
      }), " \"the proxy is done, just add\ntarget-fixing.\" The genuinely-undesigned core is the ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["difference between an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "allowlist"
        }), " and a\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "fixed target"
        })]
      }), ", and it now has three parts (target-fixing §2, a pinned secret path §3.1, and\nwrite-sink consent §2.1) — that difference is the whole of Q3:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "net:fetch"
          }), " (built):"]
        }), " the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "app"
        }), " passes a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "URL"
        }), " on each call; the host checks it\nagainst the allowlist. Within the allowlisted host set, the app chooses freely — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "which"
        }), "\nhost, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "what"
        }), " path, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "what"
        }), " request body, on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "every"
        }), " call."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["So D2 is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "not"
      }), " \"build Smokescreen.\" The SSRF layer is built for the general ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "net:fetch"
      }), "\npath. What is genuinely undesigned is the ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["difference between an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "allowlist"
        }), " and a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "fixed\ntarget"
        })]
      }), " — and that difference is the whole of Q3:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "net:fetch"
          }), " (built):"]
        }), " the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "app"
        }), " passes a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "URL"
        }), " on each call; the host checks it\nagainst the allowlist. Within the allowlisted host set, the app chooses freely — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "which"
        }), "\nhost, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "what"
        }), " path, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "what"
        }), " request body, on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "every"
        }), " call."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Connector egress-", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "fixing"
          }), " (this spec):"]
        }), " a connector may be a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "metacircular\ninterpreter"
        }), " (RB-1) — its own logic, and therefore ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "which allowlisted host it calls and\nwhat it puts in the body"
        }), ", can be attacker-controlled by the very bytes it fetched. An\nallowlist that bounds the host ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "set"
        }), " does ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "not"
        }), " bound this: the connector still has\nper-call choice ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "inside"
        }), " the set, and the request ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "body"
        }), " is wide open (TS-4). The\nconnector must therefore ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "not choose URLs at all"
        }), "."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "The mechanism in one sentence:"
      }), " the connector's fetch targets are ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "derived by the host\nfrom the trusted feed configuration at grant time"
      }), ", and the connector can only ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "fire\npre-registered request templates with bounded data-plane parameters"
      }), " — it never passes a\nURL, a host, a path, or a free-form body to the fetch layer. \"Dumb pipe with host-fixed\ntargets\" (spec §4.5) becomes concrete: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "the pipe's shape is fixed by trusted config; the\nconnector only pumps it."
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-1",
      "data-slug": "1-trust-split-feed-config-is-trusted-feed-content-is-not-normative",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-1"
      }), "1. Trust split: feed ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "config"
      }), " is trusted, feed ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "content"
      }), " is not  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "This mechanism rests entirely on the spec §4.5 / §3.4 split, so it is restated as the load-\nbearing premise:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "feeds/*.feed.json"
          }), " is trusted configuration"]
        }), ", authored by the document author (or the\nuser, via the gated feed-config write path — plan §8.2), reviewed as a diff, and carrying\nthe auth secret ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "reference"
        }), " (never a value). It declares the request shape."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Fetched bytes are untrusted content."
        }), " They may be adversarial (a calendar others write\ninto; an API compromised upstream). They flow ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "into"
        }), " the sheet as tainted data; they\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "never"
        }), " flow ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "back out"
        }), " as a fetch decision."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The egress-fixing invariant is exactly: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "a fetch target and request body are a pure function\nof trusted feed config + bounded, host-minted cursor state; never a function of fetched\ncontent."
      }), " If that function ever takes a byte the connector fetched as input to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "where the next\nrequest goes or what its body carries"
      }), ", the pipe has become agentic and the invariant is\nbroken."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "\"Trusted config\" is not \"benign config\" (adversarial-review-2 D2-F4)."
        }), " The invariant\nabove contains a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "compromised connector"
        }), ". It does ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "nothing"
        }), " against a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "hostile document\nauthor"
        }), " whose config declares the exfil target itself — a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "POST"
        }), " feed to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "evil.com"
        }), " with a\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "bodyTemplate"
        }), " full of cell references pumps the sheet out, and egress-fixing \"faithfully\"\npins to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "evil.com"
        }), ". Config is trusted for ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "integrity"
        }), " (the connector can't change it), not\nfor ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "intent"
        }), " (the author might be hostile). The only thing between an author-hostile template\nand exfil is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "consent legibility"
        }), ", which §2.1 now makes load-bearing — because the connector\nis a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "write-sink"
        }), ", not only a read-source, and the powerbox has historically rendered the\ntwo identically."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-2",
      "data-slug": "2-the-request-template-what-fixed-means-concretely-proposal-owned-by-d2",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-2"
      }), "2. The request template — what \"fixed\" means concretely  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(proposal — owned by D2)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["A feed definition compiles, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "host-side at grant time"
      }), ", to a frozen ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "request template"
      }), "\nthe connector references by opaque ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "feed-instance id"
      }), ", never by URL:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-jsonc",
        children: "// feeds/orders.feed.json  — trusted config (the ONLY place a URL/host/path appears)\n{\n  \"id\": \"orders\",\n  \"request\": {\n    \"origin\": \"https://api.example.com\",         // fixed; the connector never sees a URL\n    \"pathTemplate\": \"/v2/orders\",                 // fixed path (no interpolation of content)\n    \"method\": \"GET\",\n    \"query\": {\n      \"since\": { \"param\": \"cursor\", \"type\": \"iso8601\" },   // a BOUNDED data-plane slot\n      \"limit\": { \"const\": 500 }\n    },\n    \"injectSecret\": { \"family\": \"example\", \"type\": \"api-key\" }, // SECRETS_SPEC §6, host-injected\n    \"bodyTemplate\": null                           // GET; see §4 for the POST case\n  },\n  \"schedule\": { \"mode\": \"poll\", \"everyMs\": 60000 },\n  \"retention\": { \"keepLast\": 5000 }\n}\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The host derives from this: the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "effective allowlist"
      }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "{origin, paths:['/v2/orders'], methods:['GET']}"
      }), " — feeding the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "existing"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "netFetchPolicy"
      }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "netFetch.ts"
      }), " stack unchanged),\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "and"
      }), " the frozen template. The connector's only egress call is:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-ts",
        children: "// what the connector may do — no URL, no host, no path, no free body\nhostFeedFetch(feedInstanceId, { cursor: lastSeenIso });   // params validated against the template's typed slots\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The host constructs the actual request from the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "template + validated params"
      }), ", runs it\nthrough the built SSRF-pinning proxy (§0), and returns the bytes to the connector as tainted\ndata. Rules that make the fix real:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "No URL surface."
        }), " The connector API takes a feed-instance id + a typed param object.\nThere is no code path from the connector to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "fetch(url)"
        }), " — the general ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "net:fetch"
        }), "\ncapability is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "not granted"
        }), " to the connector realm (it holds only ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "feed:fetch"
        }), ", a\ndistinct, template-bound capability). A connector that tries ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "fetch()"
        }), " gets ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "forbidden"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Params are bounded data-plane slots, not target selectors, and carry no\nconnector-authored bytes"
        }), " (tightened, review-2 D2-F1/F2). A slot is typed (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "iso8601"
        }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "int(0..N)"
        }), ", an enum) and appears ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "only"
        }), " in the positions the template marks — a\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "query"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "bodyTemplate"
        }), " value, never the origin, host, path, or a new query ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "key"
        }), ". A slot's\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "information content is bounded and declared"
        }), ", and the host enforces the type, so it cannot\ncarry an arbitrary payload. ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Pagination cursors are host-minted and opaque ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "to the\nconnector"
          })]
        }), " (review-2 D2-F2 resolves the §1 contradiction): the connector never supplies\nor reads cursor bytes — the host extracts the next-page token from the response per a\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "config-declared"
        }), " extraction rule (e.g. a JSONPath in the feed config, itself trusted\nconfig, not connector logic) and round-trips it. A connector-supplied or\nconnector-round-tripped cursor is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "forbidden"
        }), ", because it is either connector-authored\nexfil or a function of fetched content — both break §1. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "(Honest cost: the host must know\neach API's pagination shape via config; a feed whose pagination cannot be expressed as a\ndeclarative extraction rule is not expressible as a fixed feed — that is the price of the\ninvariant, not a gap in it.)"
        })]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The request body is fully templated; there is a body-size cap"
        }), " (review-2 D2-F1). For a\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "POST"
        }), " feed, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "bodyTemplate"
        }), " fixes the body; only typed slots vary; and the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "request"
        }), " body\nis size-capped host-side (the built proxy caps only the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "response"
        }), "). No connector-authored\nfree body ever leaves."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The template is frozen at grant time."
        }), " Editing ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "feeds/*.feed.json"
        }), " is the gated\nfeed-config write (plan §8.2, TS-19b) and re-derives the allowlist + re-consents if the\norigin/secret set widened. A running connector cannot mutate its own template."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "One connector instance per tier-class, per feed set"
        }), " (spec §4.5 / plan §9): the\ninstance's grant is the union of ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "its"
        }), " feeds' templates and nothing else; two instances\nof one connector ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "appKey"
        }), " share no source grant (the D1/D8 per-instance delegation gate).\nThe per-instance fetch budget is keyed on a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "host-minted"
        }), " instance id (a\nconnector-supplied id would let it mint fresh buckets, review-2 D2-F1)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-2-1",
      "data-slug": "21-write-sink-consent-a-feed-that-writes-is-not-a-feed-that-reads-normative-review-2-d2-f4",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-2-1"
      }), "2.1 Write-sink consent — a feed that writes is not a feed that reads  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative — review-2 D2-F4)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Egress-fixing pins the target to the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "config's"
      }), " declared origin; against a hostile author that\norigin ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "is"
      }), " the attack (§1). The only defense is consent legibility, so it is made\nload-bearing here, not left to the generic powerbox:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The consent surface must distinguish a write-sink from a read-source."
        }), " A feed whose\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "method"
        }), " is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "POST"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "PUT"
        }), " or whose ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "bodyTemplate"
        }), " is non-null is an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "outbound"
        }), " feed; the\nhost consent must say so in plain language (\"this feed ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "sends"
        }), " data to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "evil.com"
        }), "\"), not\nrender it identically to an ingest feed."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "It must show what leaves:"
        }), " the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "bodyTemplate"
        }), "'s ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "cell references"
        }), " (which cells' values\nare sent) and the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "egress volume"
        }), " (per the budget), so the user consents to the actual\noutbound reach, not an abstract \"activate feed.\""]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "This reduces to the already-booked, still-unvalidated reach-consent-legibility residual"
        }), "\n(spec §3.1/RB-6) — but on the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "write"
        }), " axis, which no aggregate-reach view yet surfaces.\nUntil the reach view covers write-sinks (plan D6 + the E3 efficacy study, which now must\ninclude an outbound-feed comprehension arm), a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "POST"
        }), "-with-cell-body feed is a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "named\nresidual"
        }), ", not a contained threat. Egress-fixing does not defend the user against their own\ndocument's author; consent legibility is the only thing that does, and it is unvalidated."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-3",
      "data-slug": "3-the-layered-stack-built-new-reference-for-the-built-layers-proposal-for-the-new",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-3"
      }), "3. The layered stack (built + new)  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(reference for the built layers, proposal for the new)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Egress-fixing is defense-in-depth; only the top layer is new."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Layer"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "State"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "What it stops"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Target-fixing / request templating"
            }), " (§2)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "NEW (D2)"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["A metacircular connector choosing ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
              children: "which host / path / body"
            }), " — the per-call choice an allowlist leaves open. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "The load-bearing new layer."
            })]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Per-instance fetch ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "budgets"
            }), " (rate + volume), the anomaly tripwire"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["partial (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "backend/src/rateLimit.ts"
            }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "consume"
            }), " exists; per-feed-instance keying is new)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Slow-drip body-exfil (§4) and runaway loops — a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
              children: "tripwire"
            }), ", not a wall"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "manifest ∩ grant"
            }), " allowlist"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "built"
            }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "netFetchPolicy.ts"
            }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "effectiveAllowlist"
            }), ")"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Fetching an origin outside the derived set"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Resolve-", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "all"
            }), " + reject-if-any-private + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "pin"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
              children: ["built for the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
                children: "non-secret"
              }), " server path"]
            }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "netFetch.ts"
            }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "resolveAndValidate"
            }), " + pinning ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "Agent"
            }), "); ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "NOT on the secret/browser-direct path"
            }), " (review-2 D2-F5) → §3.1"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["DNS-rebinding onto a private/metadata IP (T16) — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
              children: "contained only where the pinned path runs"
            })]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Per-hop redirect ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "re-resolve + re-validate"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "manual"
            }), ", hop-capped"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "built (server path)"
            }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "netFetch.ts"
            }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "DEFAULT_MAX_REDIRECTS"
            }), ")"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "A redirect bouncing to a non-fixed host (T40)"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["No IR credential forwarding; size-bounded ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "response"
            }), " body"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "built"
            }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "netFetch.ts"
            }), ") — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "request-body cap is NEW"
            }), " (§2 rule 3)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Stealing IR cookies; unbounded read; unbounded write"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["CSP ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "connect-src"
            }), " on the connector frame"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "built-adjacent"
            }), " (per-frame CSP, plan D5)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Browser-native defense-in-depth if the connector tries a direct socket"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Secret ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "injection"
            }), " host-side, use-not-read (SECRETS_SPEC §6)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "built"
            }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "netFetchPolicy"
            }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "injectSecret"
            }), ") — but \"never read\" is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "header-only"
            }), " (review-2 D2-F3)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "The connector reading the secret value from headers; injecting it into a non-templated request"
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-3-1",
      "data-slug": "31-a-pinned-egress-path-for-secret-bearing-feeds-built-was-proposal-review-2-d2-f5-see-the-settlement-note-below",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-3-1"
      }), "3.1 A pinned egress path for secret-bearing feeds  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(BUILT — was proposal, review-2 D2-F5; see the settlement note below)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The connector's secret-bearing feeds currently route browser-direct (unpinned) so the secret\nvalue never reaches the server. That trade — secret-confidentiality vs. rebind-resistance —\nmust be resolved ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "for the connector"
      }), ", because its secret feeds are exactly the dangerous ones.\nOptions, to settle in build:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "(a) Server-side injection into the pinned path."
        }), " Route connector feeds through the pinned\nserver proxy and inject the secret ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "server-side"
        }), " at the proxy (the value reaches the\nserver, which already holds far more sensitive material and never returns it to the app).\nThis gets pinning + per-hop redirect re-validation for secret feeds; the cost is the secret\ntransiting the server boundary — acceptable for the connector's own bound host, gated by the\nfeed's trusted config."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "(b) Resolve-and-pin on the browser path."
        }), " Add DNS resolution + private-range rejection +\nconnection pinning to the browser-direct path. Browsers cannot resolve DNS or pin a socket,\nso this is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "not achievable"
        }), " in-tab — which is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "why"
        }), " the server path exists. Rejected as\ninfeasible; recorded so it is not re-proposed."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Decision direction:"
      }), " (a). The connector realm's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "feed:fetch"
      }), " runs through the pinned server\nproxy with server-side secret injection; the browser-direct unpinned path is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "not"
      }), " used for\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "feed:fetch"
      }), ". Until this ships, secret-bearing feeds have ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "no rebind protection"
      }), " and the spec\nsays so."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.em, {
        children: ["(Settled and built, 2026-08-27 — (a), signed off by the repository owner; see\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "docs/status/CONNECTOR_EGRESS_FIXING_STATUS.md"
        }), ", which governs implementation status. Two\ncorrections and one gap, from the adversarial pass this path was owed:)"]
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Correction — this is a routing change, not a custody change."
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "SECRETS_SPEC §2.1"
      }), " C1/C5 separate\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "custody"
      }), " (where key material ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "lives"
      }), ") from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "routing"
      }), " (which network path a request takes).\nOption (a) keeps custody at ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "client-sealed"
      }), " and moves only routing, landing in cell ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "T1"
      }), " —\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "unsealed in the parent window, sent to the backend per request, injected upstream, never stored;\nseen in transit only"
      }), ". T1 is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "specified and already shipped"
      }), " for LLM keys\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "streamViaBackendProxy"
      }), ", described in its own source as \"the single place in the host that\ndeliberately sends a user's key to our server\"). The genuine custody change is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "platform-held"
      }), " /\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "T2"
      }), " — a different cell, behind its own KMS + never-return + rotation criteria. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "(a) is not\nthat"
      }), ", and arguing it as such points at the wrong gate: what it needs is a C2 enumeration edit\nplus the C6 routing disclosure."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Gap — the eligibility check C2 requires does not exist."
      }), " C2 enumerates the backend-proxied\ncarve-out ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "by resource kind"
      }), " and says widening it \"is a spec edit somebody has to write, not a\njudgement call at a call site\". §3.1 widened it to a second consumer and no such edit was written;\nnor does any layer check the kind. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "feedTemplate.ts"
      }), " types the selector\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "injectSecret?: { family?: string; type?: string }"
      }), " — a free-form string, not ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "SecretType"
      }), " — and\ncopies it through unvalidated, while validating data-plane slot types strictly in the same\ncompiler. And the realistic path is an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "omitted"
      }), " type rather than a declared one:\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "matchesSelector"
      }), " treats a missing ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "type"
      }), " as ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "match every kind"
      }), ", so\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "injectSecret: { family: \"acme\" }"
      }), " can select an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "oauth-refresh"
      }), " record — a whole-identity,\nauto-refreshing credential C2 excludes ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "unconditionally"
      }), " — and route it through the server\nboundary. The rule and the fix are ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "SECRETS_SPEC §2.1"
      }), " C2 (as amended) and roadmap ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "R3-394"
      }), ":\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "api-key"
      }), " compiles, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "oauth-refresh"
      }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "bearer-token"
      }), " are refused ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "at template compile"
      }), ", an\nomitted kind is not a wildcard on this path, and an ineligible feed is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "refused rather than\ndowngraded"
      }), " to browser-direct."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-4",
      "data-slug": "4-the-residual-named-honestly-request-body-param-exfiltration-ts-4-normative-intent",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-4"
      }), "4. The residual, named honestly — request-body / param exfiltration (TS-4)  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative intent)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The report (RQ-E1) and spec (TS-4) name the residual: ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["data can leave in the request ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "body"
        }), "\nor a bounded param to a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "legitimately allowlisted"
        }), " host."]
      }), " Egress rules cannot close this.\nReview-2 corrected the earlier draft's framing, which ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "understated the magnitude"
      }), ":"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The write channel is fast, not a slow drip"
        }), " (review-2 D2-F1). The per-instance budget\nbounds ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "requests-per-time"
        }), ", not ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "bits-per-request"
        }), ", and the leak completes ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "at declared\ncadence"
        }), ", so the \"N× cadence\" frequency tripwire never fires. A single constrained ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "iso8601"
        }), "\nslot controls ~30–50 bits/request → a 256-bit secret drains in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "~6–9 on-cadence requests"
        }), "\n(minutes, indistinguishable from normal polling). The tightenings in §2 (host-minted opaque\ncursors, request-body cap, host-minted instance id) ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "remove the unbounded channels"
        }), " (the\nconnector-round-tripped cursor and the free body), leaving only the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "declared typed-slot\nentropy"
        }), " — still nonzero, still fast relative to a secret, honestly stated as:\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "\"consented reach; write-to-fixed-host at declared-slot-entropy per request, completing\nwithin minutes; frequency-tripwired only.\""
        }), " Not \"slow param drip.\""]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "What actually bounds it"
        }), " is not the egress rule but the pair the report already named:\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "output tiering"
        }), " (data reaching the connector is already M3-tainted — what it can exfil is\ndata the user consented the connector to reach) + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "write-sink consent"
        }), " (§2.1 — the user saw\nthat this feed sends data outbound). Neither is a wall; both are the accepted\nreach-not-egress posture."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The honest answer to spec ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Q2"
      }), " (is the backstop pair sufficient?): ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["no single mechanism\nsuffices, and the residual is a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "fast"
        }), " write channel, not a negligible one."]
      }), " Egress-fixing\nbounds ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "reach"
      }), " (which host/path — genuinely contained, §5) and removes the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "unbounded"
      }), " write\nchannels; it bounds the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "residual"
      }), " write channel only to declared-slot entropy, backstopped by\ntiering + consent legibility (both unvalidated). It does ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "not"
      }), " make a compromised connector,\nor a hostile author (§2.1), zero-exfil."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-5",
      "data-slug": "5-adversarial-pass-the-metacircular-connector-attack-walked-normative-intent",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-5"
      }), "5. Adversarial pass — the metacircular-connector attack, walked  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative intent)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The threat (spec §3.2 RB-1): the connector is a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "metacircular interpreter"
      }), " — it fetches\nbytes and those bytes are, in effect, a program steering the connector. Walk every move."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "\"Fetch a new host.\""
        }), " The connector's fetched bytes tell it to fetch\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "https://evil.test/steal"
        }), ". → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Contained."
        }), " There is no URL surface (§2 rule 1); the\nconnector can only fire ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "hostFeedFetch(id, params)"
        }), ", and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "id"
        }), " resolves to a frozen\ntemplate whose origin is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "api.example.com"
        }), ". ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "evil.test"
        }), " is unnameable — the same\n\"undeclared reads are unnameable\" move as the formula engine, applied to egress."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "\"Redirect me there.\""
        }), " The allowlisted origin (or adversarial content presented as a\nresponse) issues a 302 to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "evil.test"
        }), ". → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Contained (built, T40)."
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "redirect:'manual'"
        }), ";\nthe host re-resolves + re-validates the next hop against the allowlist and refuses."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "\"Rebind DNS.\""
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "api.example.com"
        }), " re-resolves to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "169.254.169.254"
        }), " (metadata) between\ncheck and connect. → ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Contained ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "only once §3.1 ships"
          }), " (review-2 D2-F5)."]
        }), " The pinned\nserver path contains it (resolve-all + reject-if-any-private + pin). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "But today a\nsecret-bearing feed routes browser-direct and is NOT pinned"
        }), " — so until §3.1 (server-side\nsecret injection on the pinned path), this move is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "open for the dangerous feeds."
        }), " Honest\nstatus: contained on the non-secret path, open on the secret path, closed everywhere by §3.1."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "\"Pick a different allowlisted host.\""
        }), " The connector has two feeds and content steers\nit to send feed-A's data to feed-B's origin. → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Contained."
        }), " Each ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "feed:fetch(id,…)"
        }), " is\nbound to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "one"
        }), " template; there is no call that takes data-for-A and a target-of-B. The\nparam slots can't carry a host. Cross-feed mixing would require encoding A's payload into\nB's typed slots — bounded to declared-slot entropy (→ §4)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "\"Stuff exfil in the body / round-trip a fat cursor.\""
        }), " Content steers the connector to\nPOST the sheet's secrets, or to round-trip a giant \"cursor.\" → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Unbounded channels closed\n(review-2 D2-F1/F2); residual bounded to slot entropy."
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "bodyTemplate"
        }), " is fixed with a\nrequest-body cap (§2 rule 3); cursors are host-minted and opaque-to-connector (§2 rule 2),\nso the connector-authored free body and the round-tripped-cursor channels are ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "gone"
        }), ". What\nremains is declared typed-slot entropy — fast relative to a secret but no longer unbounded\n(§4, the honest residual)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "\"Steal the secret value.\""
        }), " → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Contained for headers; body-reflection is the residual\n(review-2 D2-F3)."
        }), " The secret is injected by reference and the connector cannot read it from\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "headers"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "stripInjectedFromResponse"
        }), "). ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["But a malicious allowlisted host can reflect the\ntoken in its response ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "body"
          }), ","]
        }), " which the connector reads as data. With server-side injection\n(§3.1) the value never reaches the connector's frame at all for the request, but the\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "reflected"
        }), " value in a response body is a property of a malicious bound host and is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "not"
        }), "\nclosed — named residual (narrow: needs a malicious host that already holds the user's key)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "\"Loop to amplify.\""
        }), " Fire the template a million times. → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Tripwired, weakly (review-2\nD2-F1)."
        }), " The per-instance budget flags ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "frequency"
        }), " anomalies, but the §4 leak completes ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "at\ncadence"
        }), " in minutes, which the tripwire never sees; and the underlying limiter is per-uid and\nfails open. The budget is a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "backstop against runaway loops, not against the on-cadence\ndrain"
        }), " — stated honestly, not as containment."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "\"Mutate my own template.\""
        }), " → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Contained."
        }), " Host-frozen at grant time (§2 rule 4); a\nwidening is a gated feed-config write with re-consent, which the connector realm cannot\nperform on itself."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "\"Be a hostile author, not a hostile connector\" (review-2 D2-F4)."
        }), " The ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "author"
        }), " declares\na ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "POST"
        }), " feed to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "evil.com"
        }), " with a cell-reference ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "bodyTemplate"
        }), ". → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "NOT contained by\negress-fixing"
        }), " — it pins faithfully to the author's chosen exfil host. The only defense is\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "write-sink consent legibility (§2.1)"
        }), ", which is unvalidated. This is the biggest residual\nand it is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "outside"
        }), " the compromised-connector threat the rest of this pass addresses."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Verdict of the pass:"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "reach"
      }), "-fixing is sound — moves 1, 4, 8 fully contained by the new\ntarget-fixing layer, move 2 by the built redirect re-validation. But: move 3 is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "open on the\nsecret path until §3.1"
      }), "; move 5's unbounded channels are closed but a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "fast"
      }), " slot-entropy\nresidual remains (move 7's tripwire does not catch it); move 6 has a body-reflection residual;\nand move 9 (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "author-hostile template"
      }), ") is not an egress problem at all — it rides consent\nlegibility that is unvalidated. So the answer to spec Q2 is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "the triple does NOT suffice to\ncall the connector safe"
      }), ": it bounds a metacircular ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "connector"
      }), " to \"consented reach,\nfast-slot-entropy write, weakly-frequency-tripwired,\" and it does ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "not"
      }), " bound a hostile\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "author"
      }), " except via unvalidated write-sink consent. The\nplan and spec must keep stating that residual; they must ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "not"
      }), " upgrade this to \"safe.\""]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-6",
      "data-slug": "6-load-bearing-assumptions-code-anchors",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-6"
      }), "6. Load-bearing assumptions & code anchors"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "depends-on-today-verified-against-code-2026-07-09-re-checked-by-scriptscheck-spec-anchorsmjs",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "depends-on-today-verified-against-code-2026-07-09-re-checked-by-scriptscheck-spec-anchorsmjs"
      }), "Depends-on-today (verified against code 2026-07-09; re-checked by ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "scripts/check-spec-anchors.mjs"
      }), ")"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Assumption (existing behavior the design rests on)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Anchor (repo-relative file)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Token (grep-stable)"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["The server-side proxy resolves + validates + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "pins"
            }), " to validated addresses"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "immediately-run-backend/src/netFetch.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "resolveAndValidate"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Redirects are followed ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "manual"
            }), " with a per-hop re-validate under a hop cap"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "immediately-run-backend/src/netFetch.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "DEFAULT_MAX_REDIRECTS"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Resolved-IP blocklist covers private/loopback/link-local/metadata"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "immediately-run-backend/src/netFetch.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "isBlockedIp"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["The effective allowlist is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "manifest ∩ grant"
            }), ", re-checked host-side"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "immediately-run-site-main/src/registry/netFetchPolicy.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "effectiveAllowlist"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Secret injection is host-side, by reference, use-not-read"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "immediately-run-site-main/src/registry/netFetchPolicy.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "injectSecret"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "A guarded fetch is issued from the host, not the app frame"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "immediately-run-site-main/src/editor/netFetchHandler.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "performGuardedFetch"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Per-request budget/rate machinery exists to key per-instance"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "immediately-run-backend/src/rateLimit.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "consume"
            })
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "must-establish-new-invariants-the-implementation-creates",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "must-establish-new-invariants-the-implementation-creates"
      }), "Must-establish (new invariants the implementation creates)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "New invariant"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Proven by (gate test)"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["The connector realm holds ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "feed:fetch"
            }), " (template-bound), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "not"
            }), " general ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "net:fetch"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["connector-caps gate: a connector calling ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "fetch()"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "net:fetch"
            }), " gets ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "forbidden"
            })]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "A fetch target is a pure function of frozen feed config + typed params; never of fetched content"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "egress-fixing gate: a hostile connector harness (metacircular) cannot cause a request to any host/path outside its feed templates, incl. via redirect/rebinding/param injection (moves 1–4, 8 of §5)"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Data-plane params can occupy only template-marked slots and cannot carry a host/path/new key"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["param-confinement test: a param containing a URL/host/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "../"
            }), " path/new query key is rejected ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "invalid-params"
            }), ", never fetched"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "The request body is templated AND size-capped; cursors are host-minted opaque"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["body-fix test: a connector cannot emit a request body outside ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "bodyTemplate"
            }), "+slots, cannot exceed the request-body cap, and cannot supply/round-trip a cursor (review-2 D2-F1/F2)"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Secret-bearing feeds run on the pinned server path"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["secret-pin gate: a secret feed whose host rebinds to a private/metadata IP is refused (review-2 D2-F5, §3.1) — proves the browser-direct unpinned path is not used for ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "feed:fetch"
            })]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "A write-sink feed is consented as outbound, showing body cell-refs + volume"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["write-sink-consent gate: a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "POST"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "bodyTemplate"
            }), " feed's consent surface names it outbound and lists the cells sent (review-2 D2-F4, §2.1); a read feed does not"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Per-feed-instance budget keyed on a host-minted id; bounds runaway loops (not the on-cadence drain)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["budget test: a connector-supplied instance id cannot mint a fresh bucket; N× cadence trips; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "the honest limit — an at-cadence drain is NOT caught — is documented"
            }), " (review-2 D2-F1)"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Template is frozen at grant time; a running connector cannot widen it"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "template-immutability test: a connector self-widening its origin set is refused; a config edit re-consents"
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-7",
      "data-slug": "7-decisions-rejected-alternatives",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-7"
      }), "7. Decisions & rejected alternatives"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Target-fixing by host-constructed request templates keyed by feed-instance id; the\nconnector never passes a URL."
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " giving the connector general ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "net:fetch"
        }), " with\na tight allowlist (leaves per-call host/path/body choice open to a metacircular fork — the\nexact RB-1 hole); an agentic connector that computes its own targets (spec §4.5 rejects)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Reuse the built SSRF-pinning proxy for the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "non-secret"
          }), " path; add a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "pinned secret path"
          }), "\nvia server-side injection (§3.1, review-2 D2-F5)."]
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " the earlier \"reuse\nunchanged\" claim (false — secret feeds route browser-direct/unpinned); resolve-and-pin in the\nbrowser (infeasible in-tab)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Cursors host-minted and opaque-to-connector; request body fully templated + size-capped\n(review-2 D2-F1/F2)."
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " the earlier \"opaque cursor the host round-trips\" slot (a\nconnector-round-tripped cursor is either connector-authored exfil or a function of fetched\ncontent — both break §1); an uncapped request body."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Write-sink consent: a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "POST"
          }), "/body feed is consented as outbound, showing cell-refs +\nvolume (§2.1, review-2 D2-F4)."]
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " trusting \"feed config is benign\" (it is trusted\nfor integrity, not intent — a hostile author's template is the attack); rendering a\nwrite-sink identically to a read-source in the powerbox."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["State the residual as a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "fast"
          }), " write channel, backstopped by tiering + consent, never\n\"safe\" (review-2 D2-F1)."]
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " the earlier \"slow param drip\" framing (the drain\ncompletes at cadence in minutes); claiming egress-fixing makes a compromised connector ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "or a\nhostile author"
        }), " zero-exfil (the honest Q2 answer is \"does not suffice to call safe\")."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-8",
      "data-slug": "8-open-questions",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-8"
      }), "8. Open questions"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "OQ-1 (feeds spec home)."
        }), " The request-template schema (§2) is the connector's contract\nand may deserve its own ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "CONNECTOR_FEEDS_SPEC"
        }), " rather than living in the Reckoner plan —\ndecide when D2 build starts."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "OQ-2 (streaming/subscription feeds)."
        }), " §2 shows the poll case. A long-lived\nsubscription (WebSocket/SSE) is still template-fixed for the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "connect"
        }), " target, but the\nper-message data plane needs the same \"no target influence from content\" proof — spell it\nout before building the subscription mode (interacts with plan RQ-C1/§5.2)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "OQ-3 (Q2 sufficiency, escalated to the third fresh-agent pass)."
        }), " §5 argues the\ntriple bounds the fork; the spec's requested third adversarial pass should attack §5's\nmoves 5/7 specifically — is param-entropy + budget a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "tolerable"
        }), " covert channel for the\nM3-reach the connector already has, or does a specific feed pattern make it unacceptable?"]
      }), "\n"]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/specs/CONNECTOR_EGRESS_FIXING_SPEC.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJibG9ja3F1b3RlIiwiY29kZSIsImVtIiwiaDEiLCJoMiIsImgzIiwiaHIiLCJsaSIsIm9sIiwicCIsInByZSIsInN0cm9uZyIsInRhYmxlIiwidGJvZHkiLCJ0ZCIsInRoIiwidGhlYWQiLCJ0ciIsInVsIiwiX3Byb3ZpZGVDb21wb25lbnRzIiwiY29tcG9uZW50cyIsIkhlYWRpbmdBbmNob3IiLCJfbWlzc2luZ01keFJlZmVyZW5jZSIsImpzeHMiLCJGcmFnbWVudCIsImNoaWxkcmVuIiwiaWQiLCJqc3giLCJjbGFzc05hbWUiLCJNRFhDb250ZW50Iiwid3JhcHBlciIsIk1EWExheW91dCIsIl9jIiwiY29tcG9uZW50IiwicGxhY2UiLCJFcnJvciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkNPTk5FQ1RPUl9FR1JFU1NfRklYSU5HX1NQRUMubWQiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgYmxvY2txdW90ZTogXCJibG9ja3F1b3RlXCIsXG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgZW06IFwiZW1cIixcbiAgICBoMTogXCJoMVwiLFxuICAgIGgyOiBcImgyXCIsXG4gICAgaDM6IFwiaDNcIixcbiAgICBocjogXCJoclwiLFxuICAgIGxpOiBcImxpXCIsXG4gICAgb2w6IFwib2xcIixcbiAgICBwOiBcInBcIixcbiAgICBwcmU6IFwicHJlXCIsXG4gICAgc3Ryb25nOiBcInN0cm9uZ1wiLFxuICAgIHRhYmxlOiBcInRhYmxlXCIsXG4gICAgdGJvZHk6IFwidGJvZHlcIixcbiAgICB0ZDogXCJ0ZFwiLFxuICAgIHRoOiBcInRoXCIsXG4gICAgdGhlYWQ6IFwidGhlYWRcIixcbiAgICB0cjogXCJ0clwiLFxuICAgIHVsOiBcInVsXCIsXG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9LCB7SGVhZGluZ0FuY2hvcn0gPSBfY29tcG9uZW50cztcbiAgaWYgKCFIZWFkaW5nQW5jaG9yKSBfbWlzc2luZ01keFJlZmVyZW5jZShcIkhlYWRpbmdBbmNob3JcIiwgdHJ1ZSk7XG4gIHJldHVybiA8PjxfY29tcG9uZW50cy5oMSBpZD1cImltbWVkaWF0ZWx5cnVuLWNvbm5lY3Rvci1lZ3Jlc3MtZml4aW5nLWhvc3QtZml4ZWQtZmV0Y2gtdGFyZ2V0cy1mb3ItdGhlLWR1bWItcGlwZS1jb25uZWN0b3JcIj48SGVhZGluZ0FuY2hvciBpZD1cImltbWVkaWF0ZWx5cnVuLWNvbm5lY3Rvci1lZ3Jlc3MtZml4aW5nLWhvc3QtZml4ZWQtZmV0Y2gtdGFyZ2V0cy1mb3ItdGhlLWR1bWItcGlwZS1jb25uZWN0b3JcIiAvPntcImltbWVkaWF0ZWx5LnJ1biBDb25uZWN0b3IgRWdyZXNzLUZpeGluZyDigJQgaG9zdC1maXhlZCBmZXRjaCB0YXJnZXRzIGZvciB0aGUgZHVtYi1waXBlIGNvbm5lY3RvclwifTwvX2NvbXBvbmVudHMuaDE+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJTdGF0dXM6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHByb3Bvc2FsIC8gZHJhZnQg4oCUIGFkZHJlc3NlcyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJSRVBPUlRJTkdfU1BSRUFEU0hFRVRfU1BFQy5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgwqcxMiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlEzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiOyB0aGUgRDIgTTAgZGVzaWduLXNwcmludCBvdXRwdXQgb2YgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLi4vQVJDSElURUNUVVJFX1BMQU4ubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIMKnOS/CpzEwLCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInJldmlzZWQgYWZ0ZXIgYWR2ZXJzYXJpYWwtcmV2aWV3LTJcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIi4uL0FEVkVSU0FSSUFMX1JFVklFV18yLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDCp0EpLiBUaGUgcmVhY2gtZml4aW5nIGNvcmUgaXMgc291bmQ7IHRocmVlIGFkZGl0aW9ucyB3ZXJlIGZvcmNlZCBieSB0aGUgcGFzcyDigJQgYSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInBpbm5lZCBlZ3Jlc3MgcGF0aCBmb3Igc2VjcmV0LWJlYXJpbmcgZmVlZHNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKMKnMy4xLCB0aGUgYnVpbHQgcHJveHkgaXMgYnlwYXNzZWQgb24gdGhlIHNlY3JldCBwYXRoKSwgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJob3N0LW1pbnRlZCBvcGFxdWUgY3Vyc29ycyArIHJlcXVlc3QtYm9keSBjYXBcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKMKnMiwgY2xvc2luZyB0aGUgY29ubmVjdG9yLWF1dGhvcmVkIHdyaXRlIGNoYW5uZWxzKSwgYW5kIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wid3JpdGUtc2luayBjb25zZW50XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICjCpzIuMSwgZm9yIHRoZSBhdXRob3ItaG9zdGlsZS10ZW1wbGF0ZSB0aHJlYXQgZWdyZXNzLWZpeGluZyBkb2VzIG5vdCB0b3VjaCkuIFRoZSBob25lc3QgUTIgYW5zd2VyIGlzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZG9lcyBub3Qgc3VmZmljZSB0byBjYWxsIHRoZSBjb25uZWN0b3Igc2FmZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgYm91bmRlZCwgbm90IGVsaW1pbmF0ZWQuIERlc2lnbiBvbmx5OyBub3RoaW5nIGhlcmUgaXMgYnVpbHQuIMK3IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiVXBkYXRlZDpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgMjAyNi0wNy0wOVwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuYmxvY2txdW90ZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlRoZSBzaW5nbGUgaW1wbGVtZW50YXRpb24tc3RhdHVzIHNvdXJjZSBmb3IgdGhpcyBzcGVjIGlzXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZG9jcy9zdGF0dXMvQ09OTkVDVE9SX0VHUkVTU19GSVhJTkdfU1RBVFVTLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAodG8gYmUgY3JlYXRlZCB3aGVuIGJ1aWxkIHN0YXJ0cykg4oCUXFxud2hlcmUgdGhpcyBkb2N1bWVudCBhbmQgdGhhdCBvbmUgZGlzYWdyZWUsIHRoZSBzdGF0dXMgZG9jIGdvdmVybnMuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTwvX2NvbXBvbmVudHMuYmxvY2txdW90ZT57XCJcXG5cIn08X2NvbXBvbmVudHMuYmxvY2txdW90ZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlJlYWRzIGZpcnN0OlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJSRVBPUlRJTkdfU1BSRUFEU0hFRVRfU1BFQy5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgwqczLjEgKHJlYWNoLW5vdC1lZ3Jlc3MpLCDCpzMuMiAodGhlXFxubm8tYm90aCBpbnZhcmlhbnQgaXMgYW4gYXBwIGRpc2NpcGxpbmUgdGhhdCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImZhbGxzIGJhY2sgb250byB0aGlzIG1lY2hhbmlzbVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBhZ2FpbnN0IGFcXG5tZXRhY2lyY3VsYXItY29ubmVjdG9yIGZvcmsg4oCUIFJCLTEpLCDCpzQuNSAoY29ubmVjdG9yID0gZHVtYiBwaXBlKSwgwqcxMiBRMi9RMztcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJVSV9BU19BUFBTX1NQRUMubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIMKnNS4xMSAoaG9zdC1wcm94aWVkIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm5ldDpmZXRjaFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpOyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJIT1NUX09SSUdJTl9IQVJERU5JTkdfU1BFQy5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG7CpzIuMSAodGhlIHBhcmVudC1mZXRjaCBjbGFzc2VzOyBzZXJ2ZXItc2lkZSBwcm94eSk7IFwifTxfY29tcG9uZW50cy5jb2RlPntcIlNFQ1JFVFNfU1BFQy5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgwqc2ICh1c2Utbm90LXJlYWRcXG5zZWNyZXQgaW5qZWN0aW9uKTsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiVFJVU1RfQU5EX1NBRkVUWV9TUEVDLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBUUy00IChib2R5LWV4ZmlsIHJlc2lkdWFsKSwgVFMtNWJcXG4ocmVhZCtlZ3Jlc3MgY29tYm8pLiBDb21wYW5pb246IFwifTxfY29tcG9uZW50cy5jb2RlPntcIi4uL0FEVkVSU0FSSUFMX1JFVklFV18xLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoRDIgaXMgb25lIG9mIHR3b1xcbnVuZGVzaWduZWQgZGVsdGFzIGdhdGluZyBsaXZlKS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5ociAvPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInNlYy0wXCIgZGF0YS1zbHVnPVwiMC10aGUtZmluZGluZy10aGF0LXJlZnJhbWVzLXEzLW5vcm1hdGl2ZS1pbnRlbnRcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy0wXCIgLz57XCIwLiBUaGUgZmluZGluZyB0aGF0IHJlZnJhbWVzIFEzICBcIn08X2NvbXBvbmVudHMuZW0+e1wiKG5vcm1hdGl2ZSBpbnRlbnQpXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlEzIGhhcyBiZWVuIGRlc2NyaWJlZCBhcyBcXFwiVU5ERVNJR05FRCDigJQgdGhlIHNpbmdsZSBtb3N0IGxvYWQtYmVhcmluZyBnYXAuXFxcIiBSZWFkaW5nIHRoZSBjb2RlXFxuc2hhcnBlbnMgXCJ9PF9jb21wb25lbnRzLmVtPntcImFuZCBjb21wbGljYXRlc1wifTwvX2NvbXBvbmVudHMuZW0+e1wiIHRoYXQ6IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiYW4gU1NSRi9ETlMtcmViaW5kaW5nL3JlZGlyZWN0LXJlc2lzdGFudCBlZ3Jlc3MgcHJveHlcXG5leGlzdHMgb24gdGhlIFwifTxfY29tcG9uZW50cy5lbT57XCJzZXJ2ZXJcIn08L19jb21wb25lbnRzLmVtPntcIiBwYXRoXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJpbW1lZGlhdGVseS1ydW4tYmFja2VuZC9zcmMvbmV0RmV0Y2gudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHJlc29sdmVzIGEgaG9zdG5hbWVcXG50byBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImFsbFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBpdHMgYWRkcmVzc2VzLCByZWplY3RzIGlmIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiYW55XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGlzIHByaXZhdGUvbG9vcGJhY2svbGluay1sb2NhbC9tZXRhZGF0YSwgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJwaW5zXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiXFxudGhlIGNvbm5lY3Rpb24gdG8gdGhlIHZhbGlkYXRlZCBhZGRyZXNzZXMgKGFuIHVuZGljaSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJBZ2VudFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgd2hvc2UgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibG9va3VwXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiByZXR1cm5zIG9ubHlcXG50aG9zZSksIGZvbGxvd3MgcmVkaXJlY3RzIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1hbnVhbFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgd2l0aCBhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicGVyLWhvcCByZS1yZXNvbHZlICsgcmUtdmFsaWRhdGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdW5kZXIgYSBob3AgY2FwLFxcbmZvcndhcmRzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibm9cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgSVIgY3JlZGVudGlhbHMsIGFuZCBzaXplLWJvdW5kcyB0aGUgXCJ9PF9jb21wb25lbnRzLmVtPntcInJlc3BvbnNlXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgYm9keS4gVGhlIGhvc3QgKFwifTxfY29tcG9uZW50cy5jb2RlPntcInNpdGUtbWFpblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpXFxuY29tcHV0ZXMgYSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPjxfY29tcG9uZW50cy5jb2RlPntcIm1hbmlmZXN0IOKIqSBncmFudFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnN0cm9uZz57XCIgYWxsb3dsaXN0IChcIn08X2NvbXBvbmVudHMuY29kZT57XCJuZXRGZXRjaFBvbGljeS50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZWZmZWN0aXZlQWxsb3dsaXN0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQWR2ZXJzYXJpYWwtcmV2aWV3LTIgY29ycmVjdGlvbiAoRDItRjUpIOKAlCBkbyBOT1QgY2xhaW0gXFxcInJldXNlIHRoZSBidWlsdCBwaW5uaW5nIHByb3h5XFxudW5jaGFuZ2VkLlxcXCJcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhlIGNvbm5lY3RvcidzIGRhbmdlcm91cyBmZWVkcyBjYXJyeSBhbiBpbmplY3RlZCBzZWNyZXQgKFwifTxfY29tcG9uZW50cy5jb2RlPntcImluamVjdFNlY3JldFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLCBhbmRcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJuZXRGZXRjaEhhbmRsZXIudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGlzc3VlcyBzZWNyZXQtYmVhcmluZyByZXF1ZXN0cyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImJyb3dzZXItZGlyZWN0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBkZWxpYmVyYXRlbHkgXCJ9PF9jb21wb25lbnRzLmVtPntcIm5vdFwifTwvX2NvbXBvbmVudHMuZW0+e1wiXFxudGhyb3VnaCB0aGUgc2VydmVyIHByb3h5IChcXFwidGhlIHZhbHVlIG11c3QgbmV2ZXIgaGl0IHRoZSBzZXJ2ZXJcXFwiKS4gVGhlIGJyb3dzZXIgcGF0aFxcbihcIn08X2NvbXBvbmVudHMuY29kZT57XCJuZXRGZXRjaFByb3h5LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJwZXJmb3JtR3VhcmRlZEZldGNoXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikgZG9lcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vIEROUyByZXNvbHV0aW9uIGFuZCBubyBwaW5uaW5nXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBzbyBmb3JcXG5leGFjdGx5IHRoZSBmZWVkcyB0aGF0IG1ha2UgdGhlIGNvbm5lY3RvciBhIFRTLTViIGhhemFyZCwgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJETlMtcmViaW5kaW5nIGlzIE5PVCBjb250YWluZWQuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiXFxuVGhpcyBzcGVjIHRoZXJlZm9yZSBoYXMgcmVhbCB3b3JrIGJleW9uZCB0aGUgdGFyZ2V0LWZpeGluZyBsYXllcjogXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJhIHBpbm5lZCBlZ3Jlc3MgcGF0aCBmb3JcXG5zZWNyZXQtYmVhcmluZyBjb25uZWN0b3IgZmVlZHNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKMKnMy4xKS4gVGhlIGdlbmVyYWwgKG5vbi1zZWNyZXQpIGZlZWQgZG9lcyB1c2UgdGhlIHBpbm5lZFxcbnNlcnZlciBwYXRoIOKAlCBidXQgaXRzIGJhY2tlbmQtdW5yZWFjaGFibGUgZmFsbGJhY2sgYWxzbyBkcm9wcyBwaW5uaW5nLiBUd28gc2hpcHBlZC1jb2RlIGJ1Z3NcXG5pbiB0aGUgYmxvY2tsaXN0IHdlcmUgYWxzbyBmb3VuZDogSVB2NiBsaW5rLWxvY2FsIG1hdGNoZWQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZmU4MFwifTwvX2NvbXBvbmVudHMuY29kZT57XCItb25seSAobWlzc2VzIFwifTxfY29tcG9uZW50cy5jb2RlPntcImZlODA6Oi8xMFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLFxcbmFuZCBoZXggSVB2NC1tYXBwZWQgSVB2NiB1bm1hdGNoZWQg4oCUIGZpbGVkIHNlcGFyYXRlbHkuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTwvX2NvbXBvbmVudHMuYmxvY2txdW90ZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJTbyBEMiBpcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcXFwiYnVpbGQgU21va2VzY3JlZW4sXFxcIiBidXQgaXQgaXMgYWxzbyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcXFwidGhlIHByb3h5IGlzIGRvbmUsIGp1c3QgYWRkXFxudGFyZ2V0LWZpeGluZy5cXFwiIFRoZSBnZW51aW5lbHktdW5kZXNpZ25lZCBjb3JlIGlzIHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImRpZmZlcmVuY2UgYmV0d2VlbiBhbiBcIn08X2NvbXBvbmVudHMuZW0+e1wiYWxsb3dsaXN0XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgYW5kIGFcXG5cIn08X2NvbXBvbmVudHMuZW0+e1wiZml4ZWQgdGFyZ2V0XCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLnN0cm9uZz57XCIsIGFuZCBpdCBub3cgaGFzIHRocmVlIHBhcnRzICh0YXJnZXQtZml4aW5nIMKnMiwgYSBwaW5uZWQgc2VjcmV0IHBhdGggwqczLjEsIGFuZFxcbndyaXRlLXNpbmsgY29uc2VudCDCpzIuMSkg4oCUIHRoYXQgZGlmZmVyZW5jZSBpcyB0aGUgd2hvbGUgb2YgUTM6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz48X2NvbXBvbmVudHMuY29kZT57XCJuZXQ6ZmV0Y2hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChidWlsdCk6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHRoZSBcIn08X2NvbXBvbmVudHMuZW0+e1wiYXBwXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgcGFzc2VzIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJVUkxcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgb24gZWFjaCBjYWxsOyB0aGUgaG9zdCBjaGVja3MgaXRcXG5hZ2FpbnN0IHRoZSBhbGxvd2xpc3QuIFdpdGhpbiB0aGUgYWxsb3dsaXN0ZWQgaG9zdCBzZXQsIHRoZSBhcHAgY2hvb3NlcyBmcmVlbHkg4oCUIFwifTxfY29tcG9uZW50cy5lbT57XCJ3aGljaFwifTwvX2NvbXBvbmVudHMuZW0+e1wiXFxuaG9zdCwgXCJ9PF9jb21wb25lbnRzLmVtPntcIndoYXRcIn08L19jb21wb25lbnRzLmVtPntcIiBwYXRoLCBcIn08X2NvbXBvbmVudHMuZW0+e1wid2hhdFwifTwvX2NvbXBvbmVudHMuZW0+e1wiIHJlcXVlc3QgYm9keSwgb24gXCJ9PF9jb21wb25lbnRzLmVtPntcImV2ZXJ5XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgY2FsbC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiU28gRDIgaXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJub3RcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXFxcImJ1aWxkIFNtb2tlc2NyZWVuLlxcXCIgVGhlIFNTUkYgbGF5ZXIgaXMgYnVpbHQgZm9yIHRoZSBnZW5lcmFsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm5ldDpmZXRjaFwifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG5wYXRoLiBXaGF0IGlzIGdlbnVpbmVseSB1bmRlc2lnbmVkIGlzIHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImRpZmZlcmVuY2UgYmV0d2VlbiBhbiBcIn08X2NvbXBvbmVudHMuZW0+e1wiYWxsb3dsaXN0XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgYW5kIGEgXCJ9PF9jb21wb25lbnRzLmVtPntcImZpeGVkXFxudGFyZ2V0XCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIGFuZCB0aGF0IGRpZmZlcmVuY2UgaXMgdGhlIHdob2xlIG9mIFEzOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+PF9jb21wb25lbnRzLmNvZGU+e1wibmV0OmZldGNoXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoYnVpbHQpOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB0aGUgXCJ9PF9jb21wb25lbnRzLmVtPntcImFwcFwifTwvX2NvbXBvbmVudHMuZW0+e1wiIHBhc3NlcyBhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiVVJMXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIG9uIGVhY2ggY2FsbDsgdGhlIGhvc3QgY2hlY2tzIGl0XFxuYWdhaW5zdCB0aGUgYWxsb3dsaXN0LiBXaXRoaW4gdGhlIGFsbG93bGlzdGVkIGhvc3Qgc2V0LCB0aGUgYXBwIGNob29zZXMgZnJlZWx5IOKAlCBcIn08X2NvbXBvbmVudHMuZW0+e1wid2hpY2hcIn08L19jb21wb25lbnRzLmVtPntcIlxcbmhvc3QsIFwifTxfY29tcG9uZW50cy5lbT57XCJ3aGF0XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgcGF0aCwgXCJ9PF9jb21wb25lbnRzLmVtPntcIndoYXRcIn08L19jb21wb25lbnRzLmVtPntcIiByZXF1ZXN0IGJvZHksIG9uIFwifTxfY29tcG9uZW50cy5lbT57XCJldmVyeVwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGNhbGwuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJDb25uZWN0b3IgZWdyZXNzLVwifTxfY29tcG9uZW50cy5lbT57XCJmaXhpbmdcIn08L19jb21wb25lbnRzLmVtPntcIiAodGhpcyBzcGVjKTpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYSBjb25uZWN0b3IgbWF5IGJlIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJtZXRhY2lyY3VsYXJcXG5pbnRlcnByZXRlclwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoUkItMSkg4oCUIGl0cyBvd24gbG9naWMsIGFuZCB0aGVyZWZvcmUgXCJ9PF9jb21wb25lbnRzLmVtPntcIndoaWNoIGFsbG93bGlzdGVkIGhvc3QgaXQgY2FsbHMgYW5kXFxud2hhdCBpdCBwdXRzIGluIHRoZSBib2R5XCJ9PC9fY29tcG9uZW50cy5lbT57XCIsIGNhbiBiZSBhdHRhY2tlci1jb250cm9sbGVkIGJ5IHRoZSB2ZXJ5IGJ5dGVzIGl0IGZldGNoZWQuIEFuXFxuYWxsb3dsaXN0IHRoYXQgYm91bmRzIHRoZSBob3N0IFwifTxfY29tcG9uZW50cy5lbT57XCJzZXRcIn08L19jb21wb25lbnRzLmVtPntcIiBkb2VzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibm90XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGJvdW5kIHRoaXM6IHRoZSBjb25uZWN0b3Igc3RpbGwgaGFzXFxucGVyLWNhbGwgY2hvaWNlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiaW5zaWRlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHRoZSBzZXQsIGFuZCB0aGUgcmVxdWVzdCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImJvZHlcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgaXMgd2lkZSBvcGVuIChUUy00KS4gVGhlXFxuY29ubmVjdG9yIG11c3QgdGhlcmVmb3JlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibm90IGNob29zZSBVUkxzIGF0IGFsbFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgbWVjaGFuaXNtIGluIG9uZSBzZW50ZW5jZTpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdGhlIGNvbm5lY3RvcidzIGZldGNoIHRhcmdldHMgYXJlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZGVyaXZlZCBieSB0aGUgaG9zdFxcbmZyb20gdGhlIHRydXN0ZWQgZmVlZCBjb25maWd1cmF0aW9uIGF0IGdyYW50IHRpbWVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIsIGFuZCB0aGUgY29ubmVjdG9yIGNhbiBvbmx5IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZmlyZVxcbnByZS1yZWdpc3RlcmVkIHJlcXVlc3QgdGVtcGxhdGVzIHdpdGggYm91bmRlZCBkYXRhLXBsYW5lIHBhcmFtZXRlcnNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIGl0IG5ldmVyIHBhc3NlcyBhXFxuVVJMLCBhIGhvc3QsIGEgcGF0aCwgb3IgYSBmcmVlLWZvcm0gYm9keSB0byB0aGUgZmV0Y2ggbGF5ZXIuIFxcXCJEdW1iIHBpcGUgd2l0aCBob3N0LWZpeGVkXFxudGFyZ2V0c1xcXCIgKHNwZWMgwqc0LjUpIGJlY29tZXMgY29uY3JldGU6IFwifTxfY29tcG9uZW50cy5lbT57XCJ0aGUgcGlwZSdzIHNoYXBlIGlzIGZpeGVkIGJ5IHRydXN0ZWQgY29uZmlnOyB0aGVcXG5jb25uZWN0b3Igb25seSBwdW1wcyBpdC5cIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaHIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtMVwiIGRhdGEtc2x1Zz1cIjEtdHJ1c3Qtc3BsaXQtZmVlZC1jb25maWctaXMtdHJ1c3RlZC1mZWVkLWNvbnRlbnQtaXMtbm90LW5vcm1hdGl2ZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTFcIiAvPntcIjEuIFRydXN0IHNwbGl0OiBmZWVkIFwifTxfY29tcG9uZW50cy5lbT57XCJjb25maWdcIn08L19jb21wb25lbnRzLmVtPntcIiBpcyB0cnVzdGVkLCBmZWVkIFwifTxfY29tcG9uZW50cy5lbT57XCJjb250ZW50XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgaXMgbm90ICBcIn08X2NvbXBvbmVudHMuZW0+e1wiKG5vcm1hdGl2ZSlcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhpcyBtZWNoYW5pc20gcmVzdHMgZW50aXJlbHkgb24gdGhlIHNwZWMgwqc0LjUgLyDCpzMuNCBzcGxpdCwgc28gaXQgaXMgcmVzdGF0ZWQgYXMgdGhlIGxvYWQtXFxuYmVhcmluZyBwcmVtaXNlOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+PF9jb21wb25lbnRzLmNvZGU+e1wiZmVlZHMvKi5mZWVkLmpzb25cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGlzIHRydXN0ZWQgY29uZmlndXJhdGlvblwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgYXV0aG9yZWQgYnkgdGhlIGRvY3VtZW50IGF1dGhvciAob3IgdGhlXFxudXNlciwgdmlhIHRoZSBnYXRlZCBmZWVkLWNvbmZpZyB3cml0ZSBwYXRoIOKAlCBwbGFuIMKnOC4yKSwgcmV2aWV3ZWQgYXMgYSBkaWZmLCBhbmQgY2FycnlpbmdcXG50aGUgYXV0aCBzZWNyZXQgXCJ9PF9jb21wb25lbnRzLmVtPntcInJlZmVyZW5jZVwifTwvX2NvbXBvbmVudHMuZW0+e1wiIChuZXZlciBhIHZhbHVlKS4gSXQgZGVjbGFyZXMgdGhlIHJlcXVlc3Qgc2hhcGUuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJGZXRjaGVkIGJ5dGVzIGFyZSB1bnRydXN0ZWQgY29udGVudC5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhleSBtYXkgYmUgYWR2ZXJzYXJpYWwgKGEgY2FsZW5kYXIgb3RoZXJzIHdyaXRlXFxuaW50bzsgYW4gQVBJIGNvbXByb21pc2VkIHVwc3RyZWFtKS4gVGhleSBmbG93IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiaW50b1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB0aGUgc2hlZXQgYXMgdGFpbnRlZCBkYXRhOyB0aGV5XFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJuZXZlclwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBmbG93IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiYmFjayBvdXRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYXMgYSBmZXRjaCBkZWNpc2lvbi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIGVncmVzcy1maXhpbmcgaW52YXJpYW50IGlzIGV4YWN0bHk6IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiYSBmZXRjaCB0YXJnZXQgYW5kIHJlcXVlc3QgYm9keSBhcmUgYSBwdXJlIGZ1bmN0aW9uXFxub2YgdHJ1c3RlZCBmZWVkIGNvbmZpZyArIGJvdW5kZWQsIGhvc3QtbWludGVkIGN1cnNvciBzdGF0ZTsgbmV2ZXIgYSBmdW5jdGlvbiBvZiBmZXRjaGVkXFxuY29udGVudC5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgSWYgdGhhdCBmdW5jdGlvbiBldmVyIHRha2VzIGEgYnl0ZSB0aGUgY29ubmVjdG9yIGZldGNoZWQgYXMgaW5wdXQgdG8gXCJ9PF9jb21wb25lbnRzLmVtPntcIndoZXJlIHRoZSBuZXh0XFxucmVxdWVzdCBnb2VzIG9yIHdoYXQgaXRzIGJvZHkgY2Fycmllc1wifTwvX2NvbXBvbmVudHMuZW0+e1wiLCB0aGUgcGlwZSBoYXMgYmVjb21lIGFnZW50aWMgYW5kIHRoZSBpbnZhcmlhbnQgaXNcXG5icm9rZW4uXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiXFxcIlRydXN0ZWQgY29uZmlnXFxcIiBpcyBub3QgXFxcImJlbmlnbiBjb25maWdcXFwiIChhZHZlcnNhcmlhbC1yZXZpZXctMiBEMi1GNCkuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRoZSBpbnZhcmlhbnRcXG5hYm92ZSBjb250YWlucyBhIFwifTxfY29tcG9uZW50cy5lbT57XCJjb21wcm9taXNlZCBjb25uZWN0b3JcIn08L19jb21wb25lbnRzLmVtPntcIi4gSXQgZG9lcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vdGhpbmdcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYWdhaW5zdCBhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiaG9zdGlsZSBkb2N1bWVudFxcbmF1dGhvclwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB3aG9zZSBjb25maWcgZGVjbGFyZXMgdGhlIGV4ZmlsIHRhcmdldCBpdHNlbGYg4oCUIGEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiUE9TVFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZmVlZCB0byBcIn08X2NvbXBvbmVudHMuY29kZT57XCJldmlsLmNvbVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgd2l0aCBhXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYm9keVRlbXBsYXRlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBmdWxsIG9mIGNlbGwgcmVmZXJlbmNlcyBwdW1wcyB0aGUgc2hlZXQgb3V0LCBhbmQgZWdyZXNzLWZpeGluZyBcXFwiZmFpdGhmdWxseVxcXCJcXG5waW5zIHRvIFwifTxfY29tcG9uZW50cy5jb2RlPntcImV2aWwuY29tXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi4gQ29uZmlnIGlzIHRydXN0ZWQgZm9yIFwifTxfY29tcG9uZW50cy5lbT57XCJpbnRlZ3JpdHlcIn08L19jb21wb25lbnRzLmVtPntcIiAodGhlIGNvbm5lY3RvciBjYW4ndCBjaGFuZ2UgaXQpLCBub3RcXG5mb3IgXCJ9PF9jb21wb25lbnRzLmVtPntcImludGVudFwifTwvX2NvbXBvbmVudHMuZW0+e1wiICh0aGUgYXV0aG9yIG1pZ2h0IGJlIGhvc3RpbGUpLiBUaGUgb25seSB0aGluZyBiZXR3ZWVuIGFuIGF1dGhvci1ob3N0aWxlIHRlbXBsYXRlXFxuYW5kIGV4ZmlsIGlzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiY29uc2VudCBsZWdpYmlsaXR5XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCB3aGljaCDCpzIuMSBub3cgbWFrZXMgbG9hZC1iZWFyaW5nIOKAlCBiZWNhdXNlIHRoZSBjb25uZWN0b3JcXG5pcyBhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wid3JpdGUtc2lua1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgbm90IG9ubHkgYSByZWFkLXNvdXJjZSwgYW5kIHRoZSBwb3dlcmJveCBoYXMgaGlzdG9yaWNhbGx5IHJlbmRlcmVkIHRoZVxcbnR3byBpZGVudGljYWxseS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInNlYy0yXCIgZGF0YS1zbHVnPVwiMi10aGUtcmVxdWVzdC10ZW1wbGF0ZS13aGF0LWZpeGVkLW1lYW5zLWNvbmNyZXRlbHktcHJvcG9zYWwtb3duZWQtYnktZDJcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy0yXCIgLz57XCIyLiBUaGUgcmVxdWVzdCB0ZW1wbGF0ZSDigJQgd2hhdCBcXFwiZml4ZWRcXFwiIG1lYW5zIGNvbmNyZXRlbHkgIFwifTxfY29tcG9uZW50cy5lbT57XCIocHJvcG9zYWwg4oCUIG93bmVkIGJ5IEQyKVwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJBIGZlZWQgZGVmaW5pdGlvbiBjb21waWxlcywgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJob3N0LXNpZGUgYXQgZ3JhbnQgdGltZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgdG8gYSBmcm96ZW4gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJyZXF1ZXN0IHRlbXBsYXRlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiXFxudGhlIGNvbm5lY3RvciByZWZlcmVuY2VzIGJ5IG9wYXF1ZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImZlZWQtaW5zdGFuY2UgaWRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIsIG5ldmVyIGJ5IFVSTDpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnByZT48X2NvbXBvbmVudHMuY29kZSBjbGFzc05hbWU9XCJsYW5ndWFnZS1qc29uY1wiPntcIi8vIGZlZWRzL29yZGVycy5mZWVkLmpzb24gIOKAlCB0cnVzdGVkIGNvbmZpZyAodGhlIE9OTFkgcGxhY2UgYSBVUkwvaG9zdC9wYXRoIGFwcGVhcnMpXFxue1xcbiAgXFxcImlkXFxcIjogXFxcIm9yZGVyc1xcXCIsXFxuICBcXFwicmVxdWVzdFxcXCI6IHtcXG4gICAgXFxcIm9yaWdpblxcXCI6IFxcXCJodHRwczovL2FwaS5leGFtcGxlLmNvbVxcXCIsICAgICAgICAgLy8gZml4ZWQ7IHRoZSBjb25uZWN0b3IgbmV2ZXIgc2VlcyBhIFVSTFxcbiAgICBcXFwicGF0aFRlbXBsYXRlXFxcIjogXFxcIi92Mi9vcmRlcnNcXFwiLCAgICAgICAgICAgICAgICAgLy8gZml4ZWQgcGF0aCAobm8gaW50ZXJwb2xhdGlvbiBvZiBjb250ZW50KVxcbiAgICBcXFwibWV0aG9kXFxcIjogXFxcIkdFVFxcXCIsXFxuICAgIFxcXCJxdWVyeVxcXCI6IHtcXG4gICAgICBcXFwic2luY2VcXFwiOiB7IFxcXCJwYXJhbVxcXCI6IFxcXCJjdXJzb3JcXFwiLCBcXFwidHlwZVxcXCI6IFxcXCJpc284NjAxXFxcIiB9LCAgIC8vIGEgQk9VTkRFRCBkYXRhLXBsYW5lIHNsb3RcXG4gICAgICBcXFwibGltaXRcXFwiOiB7IFxcXCJjb25zdFxcXCI6IDUwMCB9XFxuICAgIH0sXFxuICAgIFxcXCJpbmplY3RTZWNyZXRcXFwiOiB7IFxcXCJmYW1pbHlcXFwiOiBcXFwiZXhhbXBsZVxcXCIsIFxcXCJ0eXBlXFxcIjogXFxcImFwaS1rZXlcXFwiIH0sIC8vIFNFQ1JFVFNfU1BFQyDCpzYsIGhvc3QtaW5qZWN0ZWRcXG4gICAgXFxcImJvZHlUZW1wbGF0ZVxcXCI6IG51bGwgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBHRVQ7IHNlZSDCpzQgZm9yIHRoZSBQT1NUIGNhc2VcXG4gIH0sXFxuICBcXFwic2NoZWR1bGVcXFwiOiB7IFxcXCJtb2RlXFxcIjogXFxcInBvbGxcXFwiLCBcXFwiZXZlcnlNc1xcXCI6IDYwMDAwIH0sXFxuICBcXFwicmV0ZW50aW9uXFxcIjogeyBcXFwia2VlcExhc3RcXFwiOiA1MDAwIH1cXG59XFxuXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMucHJlPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSBob3N0IGRlcml2ZXMgZnJvbSB0aGlzOiB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJlZmZlY3RpdmUgYWxsb3dsaXN0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJ7b3JpZ2luLCBwYXRoczpbJy92Mi9vcmRlcnMnXSwgbWV0aG9kczpbJ0dFVCddfVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIGZlZWRpbmcgdGhlIFwifTxfY29tcG9uZW50cy5lbT57XCJleGlzdGluZ1wifTwvX2NvbXBvbmVudHMuZW0+e1wiIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm5ldEZldGNoUG9saWN5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJuZXRGZXRjaC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgc3RhY2sgdW5jaGFuZ2VkKSxcXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImFuZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB0aGUgZnJvemVuIHRlbXBsYXRlLiBUaGUgY29ubmVjdG9yJ3Mgb25seSBlZ3Jlc3MgY2FsbCBpczpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnByZT48X2NvbXBvbmVudHMuY29kZSBjbGFzc05hbWU9XCJsYW5ndWFnZS10c1wiPntcIi8vIHdoYXQgdGhlIGNvbm5lY3RvciBtYXkgZG8g4oCUIG5vIFVSTCwgbm8gaG9zdCwgbm8gcGF0aCwgbm8gZnJlZSBib2R5XFxuaG9zdEZlZWRGZXRjaChmZWVkSW5zdGFuY2VJZCwgeyBjdXJzb3I6IGxhc3RTZWVuSXNvIH0pOyAgIC8vIHBhcmFtcyB2YWxpZGF0ZWQgYWdhaW5zdCB0aGUgdGVtcGxhdGUncyB0eXBlZCBzbG90c1xcblwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnByZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgaG9zdCBjb25zdHJ1Y3RzIHRoZSBhY3R1YWwgcmVxdWVzdCBmcm9tIHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInRlbXBsYXRlICsgdmFsaWRhdGVkIHBhcmFtc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgcnVucyBpdFxcbnRocm91Z2ggdGhlIGJ1aWx0IFNTUkYtcGlubmluZyBwcm94eSAowqcwKSwgYW5kIHJldHVybnMgdGhlIGJ5dGVzIHRvIHRoZSBjb25uZWN0b3IgYXMgdGFpbnRlZFxcbmRhdGEuIFJ1bGVzIHRoYXQgbWFrZSB0aGUgZml4IHJlYWw6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJObyBVUkwgc3VyZmFjZS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhlIGNvbm5lY3RvciBBUEkgdGFrZXMgYSBmZWVkLWluc3RhbmNlIGlkICsgYSB0eXBlZCBwYXJhbSBvYmplY3QuXFxuVGhlcmUgaXMgbm8gY29kZSBwYXRoIGZyb20gdGhlIGNvbm5lY3RvciB0byBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmZXRjaCh1cmwpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgdGhlIGdlbmVyYWwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibmV0OmZldGNoXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIlxcbmNhcGFiaWxpdHkgaXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJub3QgZ3JhbnRlZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB0byB0aGUgY29ubmVjdG9yIHJlYWxtIChpdCBob2xkcyBvbmx5IFwifTxfY29tcG9uZW50cy5jb2RlPntcImZlZWQ6ZmV0Y2hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBhXFxuZGlzdGluY3QsIHRlbXBsYXRlLWJvdW5kIGNhcGFiaWxpdHkpLiBBIGNvbm5lY3RvciB0aGF0IHRyaWVzIFwifTxfY29tcG9uZW50cy5jb2RlPntcImZldGNoKClcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGdldHMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZm9yYmlkZGVuXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlBhcmFtcyBhcmUgYm91bmRlZCBkYXRhLXBsYW5lIHNsb3RzLCBub3QgdGFyZ2V0IHNlbGVjdG9ycywgYW5kIGNhcnJ5IG5vXFxuY29ubmVjdG9yLWF1dGhvcmVkIGJ5dGVzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICh0aWdodGVuZWQsIHJldmlldy0yIEQyLUYxL0YyKS4gQSBzbG90IGlzIHR5cGVkIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJpc284NjAxXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIixcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJpbnQoMC4uTilcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBhbiBlbnVtKSBhbmQgYXBwZWFycyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm9ubHlcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgaW4gdGhlIHBvc2l0aW9ucyB0aGUgdGVtcGxhdGUgbWFya3Mg4oCUIGFcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJxdWVyeVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYm9keVRlbXBsYXRlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB2YWx1ZSwgbmV2ZXIgdGhlIG9yaWdpbiwgaG9zdCwgcGF0aCwgb3IgYSBuZXcgcXVlcnkgXCJ9PF9jb21wb25lbnRzLmVtPntcImtleVwifTwvX2NvbXBvbmVudHMuZW0+e1wiLiBBIHNsb3Qnc1xcblwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiaW5mb3JtYXRpb24gY29udGVudCBpcyBib3VuZGVkIGFuZCBkZWNsYXJlZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgYW5kIHRoZSBob3N0IGVuZm9yY2VzIHRoZSB0eXBlLCBzbyBpdCBjYW5ub3RcXG5jYXJyeSBhbiBhcmJpdHJhcnkgcGF5bG9hZC4gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJQYWdpbmF0aW9uIGN1cnNvcnMgYXJlIGhvc3QtbWludGVkIGFuZCBvcGFxdWUgXCJ9PF9jb21wb25lbnRzLmVtPntcInRvIHRoZVxcbmNvbm5lY3RvclwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChyZXZpZXctMiBEMi1GMiByZXNvbHZlcyB0aGUgwqcxIGNvbnRyYWRpY3Rpb24pOiB0aGUgY29ubmVjdG9yIG5ldmVyIHN1cHBsaWVzXFxub3IgcmVhZHMgY3Vyc29yIGJ5dGVzIOKAlCB0aGUgaG9zdCBleHRyYWN0cyB0aGUgbmV4dC1wYWdlIHRva2VuIGZyb20gdGhlIHJlc3BvbnNlIHBlciBhXFxuXCJ9PF9jb21wb25lbnRzLmVtPntcImNvbmZpZy1kZWNsYXJlZFwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGV4dHJhY3Rpb24gcnVsZSAoZS5nLiBhIEpTT05QYXRoIGluIHRoZSBmZWVkIGNvbmZpZywgaXRzZWxmIHRydXN0ZWRcXG5jb25maWcsIG5vdCBjb25uZWN0b3IgbG9naWMpIGFuZCByb3VuZC10cmlwcyBpdC4gQSBjb25uZWN0b3Itc3VwcGxpZWQgb3JcXG5jb25uZWN0b3Itcm91bmQtdHJpcHBlZCBjdXJzb3IgaXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJmb3JiaWRkZW5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIsIGJlY2F1c2UgaXQgaXMgZWl0aGVyIGNvbm5lY3Rvci1hdXRob3JlZFxcbmV4ZmlsIG9yIGEgZnVuY3Rpb24gb2YgZmV0Y2hlZCBjb250ZW50IOKAlCBib3RoIGJyZWFrIMKnMS4gXCJ9PF9jb21wb25lbnRzLmVtPntcIihIb25lc3QgY29zdDogdGhlIGhvc3QgbXVzdCBrbm93XFxuZWFjaCBBUEkncyBwYWdpbmF0aW9uIHNoYXBlIHZpYSBjb25maWc7IGEgZmVlZCB3aG9zZSBwYWdpbmF0aW9uIGNhbm5vdCBiZSBleHByZXNzZWQgYXMgYVxcbmRlY2xhcmF0aXZlIGV4dHJhY3Rpb24gcnVsZSBpcyBub3QgZXhwcmVzc2libGUgYXMgYSBmaXhlZCBmZWVkIOKAlCB0aGF0IGlzIHRoZSBwcmljZSBvZiB0aGVcXG5pbnZhcmlhbnQsIG5vdCBhIGdhcCBpbiBpdC4pXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlRoZSByZXF1ZXN0IGJvZHkgaXMgZnVsbHkgdGVtcGxhdGVkOyB0aGVyZSBpcyBhIGJvZHktc2l6ZSBjYXBcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHJldmlldy0yIEQyLUYxKS4gRm9yIGFcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJQT1NUXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBmZWVkLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJib2R5VGVtcGxhdGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGZpeGVzIHRoZSBib2R5OyBvbmx5IHR5cGVkIHNsb3RzIHZhcnk7IGFuZCB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJyZXF1ZXN0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGJvZHlcXG5pcyBzaXplLWNhcHBlZCBob3N0LXNpZGUgKHRoZSBidWlsdCBwcm94eSBjYXBzIG9ubHkgdGhlIFwifTxfY29tcG9uZW50cy5lbT57XCJyZXNwb25zZVwifTwvX2NvbXBvbmVudHMuZW0+e1wiKS4gTm8gY29ubmVjdG9yLWF1dGhvcmVkXFxuZnJlZSBib2R5IGV2ZXIgbGVhdmVzLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVGhlIHRlbXBsYXRlIGlzIGZyb3plbiBhdCBncmFudCB0aW1lLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBFZGl0aW5nIFwifTxfY29tcG9uZW50cy5jb2RlPntcImZlZWRzLyouZmVlZC5qc29uXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpcyB0aGUgZ2F0ZWRcXG5mZWVkLWNvbmZpZyB3cml0ZSAocGxhbiDCpzguMiwgVFMtMTliKSBhbmQgcmUtZGVyaXZlcyB0aGUgYWxsb3dsaXN0ICsgcmUtY29uc2VudHMgaWYgdGhlXFxub3JpZ2luL3NlY3JldCBzZXQgd2lkZW5lZC4gQSBydW5uaW5nIGNvbm5lY3RvciBjYW5ub3QgbXV0YXRlIGl0cyBvd24gdGVtcGxhdGUuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJPbmUgY29ubmVjdG9yIGluc3RhbmNlIHBlciB0aWVyLWNsYXNzLCBwZXIgZmVlZCBzZXRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHNwZWMgwqc0LjUgLyBwbGFuIMKnOSk6IHRoZVxcbmluc3RhbmNlJ3MgZ3JhbnQgaXMgdGhlIHVuaW9uIG9mIFwifTxfY29tcG9uZW50cy5lbT57XCJpdHNcIn08L19jb21wb25lbnRzLmVtPntcIiBmZWVkcycgdGVtcGxhdGVzIGFuZCBub3RoaW5nIGVsc2U7IHR3byBpbnN0YW5jZXNcXG5vZiBvbmUgY29ubmVjdG9yIFwifTxfY29tcG9uZW50cy5jb2RlPntcImFwcEtleVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgc2hhcmUgbm8gc291cmNlIGdyYW50ICh0aGUgRDEvRDggcGVyLWluc3RhbmNlIGRlbGVnYXRpb24gZ2F0ZSkuXFxuVGhlIHBlci1pbnN0YW5jZSBmZXRjaCBidWRnZXQgaXMga2V5ZWQgb24gYSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImhvc3QtbWludGVkXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGluc3RhbmNlIGlkIChhXFxuY29ubmVjdG9yLXN1cHBsaWVkIGlkIHdvdWxkIGxldCBpdCBtaW50IGZyZXNoIGJ1Y2tldHMsIHJldmlldy0yIEQyLUYxKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMub2w+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwic2VjLTItMVwiIGRhdGEtc2x1Zz1cIjIxLXdyaXRlLXNpbmstY29uc2VudC1hLWZlZWQtdGhhdC13cml0ZXMtaXMtbm90LWEtZmVlZC10aGF0LXJlYWRzLW5vcm1hdGl2ZS1yZXZpZXctMi1kMi1mNFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTItMVwiIC8+e1wiMi4xIFdyaXRlLXNpbmsgY29uc2VudCDigJQgYSBmZWVkIHRoYXQgd3JpdGVzIGlzIG5vdCBhIGZlZWQgdGhhdCByZWFkcyAgXCJ9PF9jb21wb25lbnRzLmVtPntcIihub3JtYXRpdmUg4oCUIHJldmlldy0yIEQyLUY0KVwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJFZ3Jlc3MtZml4aW5nIHBpbnMgdGhlIHRhcmdldCB0byB0aGUgXCJ9PF9jb21wb25lbnRzLmVtPntcImNvbmZpZydzXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgZGVjbGFyZWQgb3JpZ2luOyBhZ2FpbnN0IGEgaG9zdGlsZSBhdXRob3IgdGhhdFxcbm9yaWdpbiBcIn08X2NvbXBvbmVudHMuZW0+e1wiaXNcIn08L19jb21wb25lbnRzLmVtPntcIiB0aGUgYXR0YWNrICjCpzEpLiBUaGUgb25seSBkZWZlbnNlIGlzIGNvbnNlbnQgbGVnaWJpbGl0eSwgc28gaXQgaXMgbWFkZVxcbmxvYWQtYmVhcmluZyBoZXJlLCBub3QgbGVmdCB0byB0aGUgZ2VuZXJpYyBwb3dlcmJveDpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlRoZSBjb25zZW50IHN1cmZhY2UgbXVzdCBkaXN0aW5ndWlzaCBhIHdyaXRlLXNpbmsgZnJvbSBhIHJlYWQtc291cmNlLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBBIGZlZWQgd2hvc2VcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJtZXRob2RcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGlzIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlBPU1RcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcIlBVVFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgb3Igd2hvc2UgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYm9keVRlbXBsYXRlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpcyBub24tbnVsbCBpcyBhbiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm91dGJvdW5kXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGZlZWQ7IHRoZVxcbmhvc3QgY29uc2VudCBtdXN0IHNheSBzbyBpbiBwbGFpbiBsYW5ndWFnZSAoXFxcInRoaXMgZmVlZCBcIn08X2NvbXBvbmVudHMuZW0+e1wic2VuZHNcIn08L19jb21wb25lbnRzLmVtPntcIiBkYXRhIHRvIFwifTxfY29tcG9uZW50cy5jb2RlPntcImV2aWwuY29tXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIlxcXCIpLCBub3RcXG5yZW5kZXIgaXQgaWRlbnRpY2FsbHkgdG8gYW4gaW5nZXN0IGZlZWQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJJdCBtdXN0IHNob3cgd2hhdCBsZWF2ZXM6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJib2R5VGVtcGxhdGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiJ3MgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJjZWxsIHJlZmVyZW5jZXNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHdoaWNoIGNlbGxzJyB2YWx1ZXNcXG5hcmUgc2VudCkgYW5kIHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImVncmVzcyB2b2x1bWVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHBlciB0aGUgYnVkZ2V0KSwgc28gdGhlIHVzZXIgY29uc2VudHMgdG8gdGhlIGFjdHVhbFxcbm91dGJvdW5kIHJlYWNoLCBub3QgYW4gYWJzdHJhY3QgXFxcImFjdGl2YXRlIGZlZWQuXFxcIlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVGhpcyByZWR1Y2VzIHRvIHRoZSBhbHJlYWR5LWJvb2tlZCwgc3RpbGwtdW52YWxpZGF0ZWQgcmVhY2gtY29uc2VudC1sZWdpYmlsaXR5IHJlc2lkdWFsXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiXFxuKHNwZWMgwqczLjEvUkItNikg4oCUIGJ1dCBvbiB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ3cml0ZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBheGlzLCB3aGljaCBubyBhZ2dyZWdhdGUtcmVhY2ggdmlldyB5ZXQgc3VyZmFjZXMuXFxuVW50aWwgdGhlIHJlYWNoIHZpZXcgY292ZXJzIHdyaXRlLXNpbmtzIChwbGFuIEQ2ICsgdGhlIEUzIGVmZmljYWN5IHN0dWR5LCB3aGljaCBub3cgbXVzdFxcbmluY2x1ZGUgYW4gb3V0Ym91bmQtZmVlZCBjb21wcmVoZW5zaW9uIGFybSksIGEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiUE9TVFwifTwvX2NvbXBvbmVudHMuY29kZT57XCItd2l0aC1jZWxsLWJvZHkgZmVlZCBpcyBhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibmFtZWRcXG5yZXNpZHVhbFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgbm90IGEgY29udGFpbmVkIHRocmVhdC4gRWdyZXNzLWZpeGluZyBkb2VzIG5vdCBkZWZlbmQgdGhlIHVzZXIgYWdhaW5zdCB0aGVpciBvd25cXG5kb2N1bWVudCdzIGF1dGhvcjsgY29uc2VudCBsZWdpYmlsaXR5IGlzIHRoZSBvbmx5IHRoaW5nIHRoYXQgZG9lcywgYW5kIGl0IGlzIHVudmFsaWRhdGVkLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtM1wiIGRhdGEtc2x1Zz1cIjMtdGhlLWxheWVyZWQtc3RhY2stYnVpbHQtbmV3LXJlZmVyZW5jZS1mb3ItdGhlLWJ1aWx0LWxheWVycy1wcm9wb3NhbC1mb3ItdGhlLW5ld1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTNcIiAvPntcIjMuIFRoZSBsYXllcmVkIHN0YWNrIChidWlsdCArIG5ldykgIFwifTxfY29tcG9uZW50cy5lbT57XCIocmVmZXJlbmNlIGZvciB0aGUgYnVpbHQgbGF5ZXJzLCBwcm9wb3NhbCBmb3IgdGhlIG5ldylcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiRWdyZXNzLWZpeGluZyBpcyBkZWZlbnNlLWluLWRlcHRoOyBvbmx5IHRoZSB0b3AgbGF5ZXIgaXMgbmV3LlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudGFibGU+PF9jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGg+e1wiTGF5ZXJcIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aD57XCJTdGF0ZVwifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIldoYXQgaXQgc3RvcHNcIn08L19jb21wb25lbnRzLnRoPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudGJvZHk+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlRhcmdldC1maXhpbmcgLyByZXF1ZXN0IHRlbXBsYXRpbmdcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKMKnMilcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIk5FVyAoRDIpXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiQSBtZXRhY2lyY3VsYXIgY29ubmVjdG9yIGNob29zaW5nIFwifTxfY29tcG9uZW50cy5lbT57XCJ3aGljaCBob3N0IC8gcGF0aCAvIGJvZHlcIn08L19jb21wb25lbnRzLmVtPntcIiDigJQgdGhlIHBlci1jYWxsIGNob2ljZSBhbiBhbGxvd2xpc3QgbGVhdmVzIG9wZW4uIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiVGhlIGxvYWQtYmVhcmluZyBuZXcgbGF5ZXIuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiUGVyLWluc3RhbmNlIGZldGNoIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiYnVkZ2V0c1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAocmF0ZSArIHZvbHVtZSksIHRoZSBhbm9tYWx5IHRyaXB3aXJlXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wicGFydGlhbCAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYmFja2VuZC9zcmMvcmF0ZUxpbWl0LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjb25zdW1lXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBleGlzdHM7IHBlci1mZWVkLWluc3RhbmNlIGtleWluZyBpcyBuZXcpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiU2xvdy1kcmlwIGJvZHktZXhmaWwgKMKnNCkgYW5kIHJ1bmF3YXkgbG9vcHMg4oCUIGEgXCJ9PF9jb21wb25lbnRzLmVtPntcInRyaXB3aXJlXCJ9PC9fY29tcG9uZW50cy5lbT57XCIsIG5vdCBhIHdhbGxcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJtYW5pZmVzdCDiiKkgZ3JhbnRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFsbG93bGlzdFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiYnVpbHRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIm5ldEZldGNoUG9saWN5LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJlZmZlY3RpdmVBbGxvd2xpc3RcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIkZldGNoaW5nIGFuIG9yaWdpbiBvdXRzaWRlIHRoZSBkZXJpdmVkIHNldFwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIlJlc29sdmUtXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJhbGxcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKyByZWplY3QtaWYtYW55LXByaXZhdGUgKyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInBpblwifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiYnVpbHQgZm9yIHRoZSBcIn08X2NvbXBvbmVudHMuZW0+e1wibm9uLXNlY3JldFwifTwvX2NvbXBvbmVudHMuZW0+e1wiIHNlcnZlciBwYXRoXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJuZXRGZXRjaC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicmVzb2x2ZUFuZFZhbGlkYXRlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiArIHBpbm5pbmcgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQWdlbnRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKTsgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJOT1Qgb24gdGhlIHNlY3JldC9icm93c2VyLWRpcmVjdCBwYXRoXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChyZXZpZXctMiBEMi1GNSkg4oaSIMKnMy4xXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiRE5TLXJlYmluZGluZyBvbnRvIGEgcHJpdmF0ZS9tZXRhZGF0YSBJUCAoVDE2KSDigJQgXCJ9PF9jb21wb25lbnRzLmVtPntcImNvbnRhaW5lZCBvbmx5IHdoZXJlIHRoZSBwaW5uZWQgcGF0aCBydW5zXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJQZXItaG9wIHJlZGlyZWN0IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicmUtcmVzb2x2ZSArIHJlLXZhbGlkYXRlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJtYW51YWxcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBob3AtY2FwcGVkXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnN0cm9uZz57XCJidWlsdCAoc2VydmVyIHBhdGgpXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJuZXRGZXRjaC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiREVGQVVMVF9NQVhfUkVESVJFQ1RTXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIilcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJBIHJlZGlyZWN0IGJvdW5jaW5nIHRvIGEgbm9uLWZpeGVkIGhvc3QgKFQ0MClcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJObyBJUiBjcmVkZW50aWFsIGZvcndhcmRpbmc7IHNpemUtYm91bmRlZCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInJlc3BvbnNlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGJvZHlcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcImJ1aWx0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJuZXRGZXRjaC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpIOKAlCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInJlcXVlc3QtYm9keSBjYXAgaXMgTkVXXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICjCpzIgcnVsZSAzKVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIlN0ZWFsaW5nIElSIGNvb2tpZXM7IHVuYm91bmRlZCByZWFkOyB1bmJvdW5kZWQgd3JpdGVcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJDU1AgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY29ubmVjdC1zcmNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG9uIHRoZSBjb25uZWN0b3IgZnJhbWVcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcImJ1aWx0LWFkamFjZW50XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChwZXItZnJhbWUgQ1NQLCBwbGFuIEQ1KVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIkJyb3dzZXItbmF0aXZlIGRlZmVuc2UtaW4tZGVwdGggaWYgdGhlIGNvbm5lY3RvciB0cmllcyBhIGRpcmVjdCBzb2NrZXRcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJTZWNyZXQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJpbmplY3Rpb25cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgaG9zdC1zaWRlLCB1c2Utbm90LXJlYWQgKFNFQ1JFVFNfU1BFQyDCpzYpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnN0cm9uZz57XCJidWlsdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibmV0RmV0Y2hQb2xpY3lcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIFwifTxfY29tcG9uZW50cy5jb2RlPntcImluamVjdFNlY3JldFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpIOKAlCBidXQgXFxcIm5ldmVyIHJlYWRcXFwiIGlzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiaGVhZGVyLW9ubHlcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHJldmlldy0yIEQyLUYzKVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIlRoZSBjb25uZWN0b3IgcmVhZGluZyB0aGUgc2VjcmV0IHZhbHVlIGZyb20gaGVhZGVyczsgaW5qZWN0aW5nIGl0IGludG8gYSBub24tdGVtcGxhdGVkIHJlcXVlc3RcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50Ym9keT48L19jb21wb25lbnRzLnRhYmxlPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cInNlYy0zLTFcIiBkYXRhLXNsdWc9XCIzMS1hLXBpbm5lZC1lZ3Jlc3MtcGF0aC1mb3Itc2VjcmV0LWJlYXJpbmctZmVlZHMtYnVpbHQtd2FzLXByb3Bvc2FsLXJldmlldy0yLWQyLWY1LXNlZS10aGUtc2V0dGxlbWVudC1ub3RlLWJlbG93XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtMy0xXCIgLz57XCIzLjEgQSBwaW5uZWQgZWdyZXNzIHBhdGggZm9yIHNlY3JldC1iZWFyaW5nIGZlZWRzICBcIn08X2NvbXBvbmVudHMuZW0+e1wiKEJVSUxUIOKAlCB3YXMgcHJvcG9zYWwsIHJldmlldy0yIEQyLUY1OyBzZWUgdGhlIHNldHRsZW1lbnQgbm90ZSBiZWxvdylcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIGNvbm5lY3RvcidzIHNlY3JldC1iZWFyaW5nIGZlZWRzIGN1cnJlbnRseSByb3V0ZSBicm93c2VyLWRpcmVjdCAodW5waW5uZWQpIHNvIHRoZSBzZWNyZXRcXG52YWx1ZSBuZXZlciByZWFjaGVzIHRoZSBzZXJ2ZXIuIFRoYXQgdHJhZGUg4oCUIHNlY3JldC1jb25maWRlbnRpYWxpdHkgdnMuIHJlYmluZC1yZXNpc3RhbmNlIOKAlFxcbm11c3QgYmUgcmVzb2x2ZWQgXCJ9PF9jb21wb25lbnRzLmVtPntcImZvciB0aGUgY29ubmVjdG9yXCJ9PC9fY29tcG9uZW50cy5lbT57XCIsIGJlY2F1c2UgaXRzIHNlY3JldCBmZWVkcyBhcmUgZXhhY3RseSB0aGUgZGFuZ2Vyb3VzIG9uZXMuXFxuT3B0aW9ucywgdG8gc2V0dGxlIGluIGJ1aWxkOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiKGEpIFNlcnZlci1zaWRlIGluamVjdGlvbiBpbnRvIHRoZSBwaW5uZWQgcGF0aC5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgUm91dGUgY29ubmVjdG9yIGZlZWRzIHRocm91Z2ggdGhlIHBpbm5lZFxcbnNlcnZlciBwcm94eSBhbmQgaW5qZWN0IHRoZSBzZWNyZXQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJzZXJ2ZXItc2lkZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBhdCB0aGUgcHJveHkgKHRoZSB2YWx1ZSByZWFjaGVzIHRoZVxcbnNlcnZlciwgd2hpY2ggYWxyZWFkeSBob2xkcyBmYXIgbW9yZSBzZW5zaXRpdmUgbWF0ZXJpYWwgYW5kIG5ldmVyIHJldHVybnMgaXQgdG8gdGhlIGFwcCkuXFxuVGhpcyBnZXRzIHBpbm5pbmcgKyBwZXItaG9wIHJlZGlyZWN0IHJlLXZhbGlkYXRpb24gZm9yIHNlY3JldCBmZWVkczsgdGhlIGNvc3QgaXMgdGhlIHNlY3JldFxcbnRyYW5zaXRpbmcgdGhlIHNlcnZlciBib3VuZGFyeSDigJQgYWNjZXB0YWJsZSBmb3IgdGhlIGNvbm5lY3RvcidzIG93biBib3VuZCBob3N0LCBnYXRlZCBieSB0aGVcXG5mZWVkJ3MgdHJ1c3RlZCBjb25maWcuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCIoYikgUmVzb2x2ZS1hbmQtcGluIG9uIHRoZSBicm93c2VyIHBhdGguXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIEFkZCBETlMgcmVzb2x1dGlvbiArIHByaXZhdGUtcmFuZ2UgcmVqZWN0aW9uICtcXG5jb25uZWN0aW9uIHBpbm5pbmcgdG8gdGhlIGJyb3dzZXItZGlyZWN0IHBhdGguIEJyb3dzZXJzIGNhbm5vdCByZXNvbHZlIEROUyBvciBwaW4gYSBzb2NrZXQsXFxuc28gdGhpcyBpcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vdCBhY2hpZXZhYmxlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGluLXRhYiDigJQgd2hpY2ggaXMgXCJ9PF9jb21wb25lbnRzLmVtPntcIndoeVwifTwvX2NvbXBvbmVudHMuZW0+e1wiIHRoZSBzZXJ2ZXIgcGF0aCBleGlzdHMuIFJlamVjdGVkIGFzXFxuaW5mZWFzaWJsZTsgcmVjb3JkZWQgc28gaXQgaXMgbm90IHJlLXByb3Bvc2VkLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkRlY2lzaW9uIGRpcmVjdGlvbjpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKGEpLiBUaGUgY29ubmVjdG9yIHJlYWxtJ3MgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZmVlZDpmZXRjaFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcnVucyB0aHJvdWdoIHRoZSBwaW5uZWQgc2VydmVyXFxucHJveHkgd2l0aCBzZXJ2ZXItc2lkZSBzZWNyZXQgaW5qZWN0aW9uOyB0aGUgYnJvd3Nlci1kaXJlY3QgdW5waW5uZWQgcGF0aCBpcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB1c2VkIGZvclxcblwifTxfY29tcG9uZW50cy5jb2RlPntcImZlZWQ6ZmV0Y2hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLiBVbnRpbCB0aGlzIHNoaXBzLCBzZWNyZXQtYmVhcmluZyBmZWVkcyBoYXZlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibm8gcmViaW5kIHByb3RlY3Rpb25cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYW5kIHRoZSBzcGVjXFxuc2F5cyBzby5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLmVtPntcIihTZXR0bGVkIGFuZCBidWlsdCwgMjAyNi0wOC0yNyDigJQgKGEpLCBzaWduZWQgb2ZmIGJ5IHRoZSByZXBvc2l0b3J5IG93bmVyOyBzZWVcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJkb2NzL3N0YXR1cy9DT05ORUNUT1JfRUdSRVNTX0ZJWElOR19TVEFUVVMubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCB3aGljaCBnb3Zlcm5zIGltcGxlbWVudGF0aW9uIHN0YXR1cy4gVHdvXFxuY29ycmVjdGlvbnMgYW5kIG9uZSBnYXAsIGZyb20gdGhlIGFkdmVyc2FyaWFsIHBhc3MgdGhpcyBwYXRoIHdhcyBvd2VkOilcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkNvcnJlY3Rpb24g4oCUIHRoaXMgaXMgYSByb3V0aW5nIGNoYW5nZSwgbm90IGEgY3VzdG9keSBjaGFuZ2UuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlNFQ1JFVFNfU1BFQyDCpzIuMVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgQzEvQzUgc2VwYXJhdGVcXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImN1c3RvZHlcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHdoZXJlIGtleSBtYXRlcmlhbCBcIn08X2NvbXBvbmVudHMuZW0+e1wibGl2ZXNcIn08L19jb21wb25lbnRzLmVtPntcIikgZnJvbSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInJvdXRpbmdcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHdoaWNoIG5ldHdvcmsgcGF0aCBhIHJlcXVlc3QgdGFrZXMpLlxcbk9wdGlvbiAoYSkga2VlcHMgY3VzdG9keSBhdCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjbGllbnQtc2VhbGVkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhbmQgbW92ZXMgb25seSByb3V0aW5nLCBsYW5kaW5nIGluIGNlbGwgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJUMVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJRcXG5cIn08X2NvbXBvbmVudHMuZW0+e1widW5zZWFsZWQgaW4gdGhlIHBhcmVudCB3aW5kb3csIHNlbnQgdG8gdGhlIGJhY2tlbmQgcGVyIHJlcXVlc3QsIGluamVjdGVkIHVwc3RyZWFtLCBuZXZlciBzdG9yZWQ7XFxuc2VlbiBpbiB0cmFuc2l0IG9ubHlcIn08L19jb21wb25lbnRzLmVtPntcIi4gVDEgaXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJzcGVjaWZpZWQgYW5kIGFscmVhZHkgc2hpcHBlZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBmb3IgTExNIGtleXNcXG4oXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3RyZWFtVmlhQmFja2VuZFByb3h5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgZGVzY3JpYmVkIGluIGl0cyBvd24gc291cmNlIGFzIFxcXCJ0aGUgc2luZ2xlIHBsYWNlIGluIHRoZSBob3N0IHRoYXRcXG5kZWxpYmVyYXRlbHkgc2VuZHMgYSB1c2VyJ3Mga2V5IHRvIG91ciBzZXJ2ZXJcXFwiKS4gVGhlIGdlbnVpbmUgY3VzdG9keSBjaGFuZ2UgaXMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicGxhdGZvcm0taGVsZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgL1xcblwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiVDJcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIGEgZGlmZmVyZW50IGNlbGwsIGJlaGluZCBpdHMgb3duIEtNUyArIG5ldmVyLXJldHVybiArIHJvdGF0aW9uIGNyaXRlcmlhLiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIihhKSBpcyBub3RcXG50aGF0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBhbmQgYXJndWluZyBpdCBhcyBzdWNoIHBvaW50cyBhdCB0aGUgd3JvbmcgZ2F0ZTogd2hhdCBpdCBuZWVkcyBpcyBhIEMyIGVudW1lcmF0aW9uIGVkaXRcXG5wbHVzIHRoZSBDNiByb3V0aW5nIGRpc2Nsb3N1cmUuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiR2FwIOKAlCB0aGUgZWxpZ2liaWxpdHkgY2hlY2sgQzIgcmVxdWlyZXMgZG9lcyBub3QgZXhpc3QuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIEMyIGVudW1lcmF0ZXMgdGhlIGJhY2tlbmQtcHJveGllZFxcbmNhcnZlLW91dCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImJ5IHJlc291cmNlIGtpbmRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYW5kIHNheXMgd2lkZW5pbmcgaXQgXFxcImlzIGEgc3BlYyBlZGl0IHNvbWVib2R5IGhhcyB0byB3cml0ZSwgbm90IGFcXG5qdWRnZW1lbnQgY2FsbCBhdCBhIGNhbGwgc2l0ZVxcXCIuIMKnMy4xIHdpZGVuZWQgaXQgdG8gYSBzZWNvbmQgY29uc3VtZXIgYW5kIG5vIHN1Y2ggZWRpdCB3YXMgd3JpdHRlbjtcXG5ub3IgZG9lcyBhbnkgbGF5ZXIgY2hlY2sgdGhlIGtpbmQuIFwifTxfY29tcG9uZW50cy5jb2RlPntcImZlZWRUZW1wbGF0ZS50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdHlwZXMgdGhlIHNlbGVjdG9yXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW5qZWN0U2VjcmV0PzogeyBmYW1pbHk/OiBzdHJpbmc7IHR5cGU/OiBzdHJpbmcgfVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIGEgZnJlZS1mb3JtIHN0cmluZywgbm90IFwifTxfY29tcG9uZW50cy5jb2RlPntcIlNlY3JldFR5cGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCBhbmRcXG5jb3BpZXMgaXQgdGhyb3VnaCB1bnZhbGlkYXRlZCwgd2hpbGUgdmFsaWRhdGluZyBkYXRhLXBsYW5lIHNsb3QgdHlwZXMgc3RyaWN0bHkgaW4gdGhlIHNhbWVcXG5jb21waWxlci4gQW5kIHRoZSByZWFsaXN0aWMgcGF0aCBpcyBhbiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm9taXR0ZWRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdHlwZSByYXRoZXIgdGhhbiBhIGRlY2xhcmVkIG9uZTpcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJtYXRjaGVzU2VsZWN0b3JcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHRyZWF0cyBhIG1pc3NpbmcgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widHlwZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYXMgXCJ9PF9jb21wb25lbnRzLmVtPntcIm1hdGNoIGV2ZXJ5IGtpbmRcIn08L19jb21wb25lbnRzLmVtPntcIiwgc29cXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJpbmplY3RTZWNyZXQ6IHsgZmFtaWx5OiBcXFwiYWNtZVxcXCIgfVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgY2FuIHNlbGVjdCBhbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJvYXV0aC1yZWZyZXNoXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiByZWNvcmQg4oCUIGEgd2hvbGUtaWRlbnRpdHksXFxuYXV0by1yZWZyZXNoaW5nIGNyZWRlbnRpYWwgQzIgZXhjbHVkZXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ1bmNvbmRpdGlvbmFsbHlcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIGFuZCByb3V0ZSBpdCB0aHJvdWdoIHRoZSBzZXJ2ZXJcXG5ib3VuZGFyeS4gVGhlIHJ1bGUgYW5kIHRoZSBmaXggYXJlIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlNFQ1JFVFNfU1BFQyDCpzIuMVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgQzIgKGFzIGFtZW5kZWQpIGFuZCByb2FkbWFwIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiUjMtMzk0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiOlxcblwifTxfY29tcG9uZW50cy5jb2RlPntcImFwaS1rZXlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNvbXBpbGVzLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJvYXV0aC1yZWZyZXNoXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhbmQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYmVhcmVyLXRva2VuXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhcmUgcmVmdXNlZCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImF0IHRlbXBsYXRlIGNvbXBpbGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIsIGFuXFxub21pdHRlZCBraW5kIGlzIG5vdCBhIHdpbGRjYXJkIG9uIHRoaXMgcGF0aCwgYW5kIGFuIGluZWxpZ2libGUgZmVlZCBpcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInJlZnVzZWQgcmF0aGVyIHRoYW5cXG5kb3duZ3JhZGVkXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHRvIGJyb3dzZXItZGlyZWN0LlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtNFwiIGRhdGEtc2x1Zz1cIjQtdGhlLXJlc2lkdWFsLW5hbWVkLWhvbmVzdGx5LXJlcXVlc3QtYm9keS1wYXJhbS1leGZpbHRyYXRpb24tdHMtNC1ub3JtYXRpdmUtaW50ZW50XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtNFwiIC8+e1wiNC4gVGhlIHJlc2lkdWFsLCBuYW1lZCBob25lc3RseSDigJQgcmVxdWVzdC1ib2R5IC8gcGFyYW0gZXhmaWx0cmF0aW9uIChUUy00KSAgXCJ9PF9jb21wb25lbnRzLmVtPntcIihub3JtYXRpdmUgaW50ZW50KVwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgcmVwb3J0IChSUS1FMSkgYW5kIHNwZWMgKFRTLTQpIG5hbWUgdGhlIHJlc2lkdWFsOiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImRhdGEgY2FuIGxlYXZlIGluIHRoZSByZXF1ZXN0IFwifTxfY29tcG9uZW50cy5lbT57XCJib2R5XCJ9PC9fY29tcG9uZW50cy5lbT57XCJcXG5vciBhIGJvdW5kZWQgcGFyYW0gdG8gYSBcIn08X2NvbXBvbmVudHMuZW0+e1wibGVnaXRpbWF0ZWx5IGFsbG93bGlzdGVkXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgaG9zdC5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgRWdyZXNzIHJ1bGVzIGNhbm5vdCBjbG9zZSB0aGlzLlxcblJldmlldy0yIGNvcnJlY3RlZCB0aGUgZWFybGllciBkcmFmdCdzIGZyYW1pbmcsIHdoaWNoIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1widW5kZXJzdGF0ZWQgdGhlIG1hZ25pdHVkZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIjpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlRoZSB3cml0ZSBjaGFubmVsIGlzIGZhc3QsIG5vdCBhIHNsb3cgZHJpcFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAocmV2aWV3LTIgRDItRjEpLiBUaGUgcGVyLWluc3RhbmNlIGJ1ZGdldFxcbmJvdW5kcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInJlcXVlc3RzLXBlci10aW1lXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBub3QgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJiaXRzLXBlci1yZXF1ZXN0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBhbmQgdGhlIGxlYWsgY29tcGxldGVzIFwifTxfY29tcG9uZW50cy5lbT57XCJhdCBkZWNsYXJlZFxcbmNhZGVuY2VcIn08L19jb21wb25lbnRzLmVtPntcIiwgc28gdGhlIFxcXCJOw5cgY2FkZW5jZVxcXCIgZnJlcXVlbmN5IHRyaXB3aXJlIG5ldmVyIGZpcmVzLiBBIHNpbmdsZSBjb25zdHJhaW5lZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJpc284NjAxXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIlxcbnNsb3QgY29udHJvbHMgfjMw4oCTNTAgYml0cy9yZXF1ZXN0IOKGkiBhIDI1Ni1iaXQgc2VjcmV0IGRyYWlucyBpbiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIn424oCTOSBvbi1jYWRlbmNlIHJlcXVlc3RzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiXFxuKG1pbnV0ZXMsIGluZGlzdGluZ3Vpc2hhYmxlIGZyb20gbm9ybWFsIHBvbGxpbmcpLiBUaGUgdGlnaHRlbmluZ3MgaW4gwqcyIChob3N0LW1pbnRlZCBvcGFxdWVcXG5jdXJzb3JzLCByZXF1ZXN0LWJvZHkgY2FwLCBob3N0LW1pbnRlZCBpbnN0YW5jZSBpZCkgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJyZW1vdmUgdGhlIHVuYm91bmRlZCBjaGFubmVsc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAodGhlXFxuY29ubmVjdG9yLXJvdW5kLXRyaXBwZWQgY3Vyc29yIGFuZCB0aGUgZnJlZSBib2R5KSwgbGVhdmluZyBvbmx5IHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImRlY2xhcmVkIHR5cGVkLXNsb3RcXG5lbnRyb3B5XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBzdGlsbCBub256ZXJvLCBzdGlsbCBmYXN0IHJlbGF0aXZlIHRvIGEgc2VjcmV0LCBob25lc3RseSBzdGF0ZWQgYXM6XFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJcXFwiY29uc2VudGVkIHJlYWNoOyB3cml0ZS10by1maXhlZC1ob3N0IGF0IGRlY2xhcmVkLXNsb3QtZW50cm9weSBwZXIgcmVxdWVzdCwgY29tcGxldGluZ1xcbndpdGhpbiBtaW51dGVzOyBmcmVxdWVuY3ktdHJpcHdpcmVkIG9ubHkuXFxcIlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBOb3QgXFxcInNsb3cgcGFyYW0gZHJpcC5cXFwiXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJXaGF0IGFjdHVhbGx5IGJvdW5kcyBpdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBpcyBub3QgdGhlIGVncmVzcyBydWxlIGJ1dCB0aGUgcGFpciB0aGUgcmVwb3J0IGFscmVhZHkgbmFtZWQ6XFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJvdXRwdXQgdGllcmluZ1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoZGF0YSByZWFjaGluZyB0aGUgY29ubmVjdG9yIGlzIGFscmVhZHkgTTMtdGFpbnRlZCDigJQgd2hhdCBpdCBjYW4gZXhmaWwgaXNcXG5kYXRhIHRoZSB1c2VyIGNvbnNlbnRlZCB0aGUgY29ubmVjdG9yIHRvIHJlYWNoKSArIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wid3JpdGUtc2luayBjb25zZW50XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICjCpzIuMSDigJQgdGhlIHVzZXIgc2F3XFxudGhhdCB0aGlzIGZlZWQgc2VuZHMgZGF0YSBvdXRib3VuZCkuIE5laXRoZXIgaXMgYSB3YWxsOyBib3RoIGFyZSB0aGUgYWNjZXB0ZWRcXG5yZWFjaC1ub3QtZWdyZXNzIHBvc3R1cmUuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSBob25lc3QgYW5zd2VyIHRvIHNwZWMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJRMlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoaXMgdGhlIGJhY2tzdG9wIHBhaXIgc3VmZmljaWVudD8pOiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vIHNpbmdsZSBtZWNoYW5pc21cXG5zdWZmaWNlcywgYW5kIHRoZSByZXNpZHVhbCBpcyBhIFwifTxfY29tcG9uZW50cy5lbT57XCJmYXN0XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgd3JpdGUgY2hhbm5lbCwgbm90IGEgbmVnbGlnaWJsZSBvbmUuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIEVncmVzcy1maXhpbmdcXG5ib3VuZHMgXCJ9PF9jb21wb25lbnRzLmVtPntcInJlYWNoXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgKHdoaWNoIGhvc3QvcGF0aCDigJQgZ2VudWluZWx5IGNvbnRhaW5lZCwgwqc1KSBhbmQgcmVtb3ZlcyB0aGUgXCJ9PF9jb21wb25lbnRzLmVtPntcInVuYm91bmRlZFwifTwvX2NvbXBvbmVudHMuZW0+e1wiIHdyaXRlXFxuY2hhbm5lbHM7IGl0IGJvdW5kcyB0aGUgXCJ9PF9jb21wb25lbnRzLmVtPntcInJlc2lkdWFsXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgd3JpdGUgY2hhbm5lbCBvbmx5IHRvIGRlY2xhcmVkLXNsb3QgZW50cm9weSwgYmFja3N0b3BwZWQgYnlcXG50aWVyaW5nICsgY29uc2VudCBsZWdpYmlsaXR5IChib3RoIHVudmFsaWRhdGVkKS4gSXQgZG9lcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBtYWtlIGEgY29tcHJvbWlzZWQgY29ubmVjdG9yLFxcbm9yIGEgaG9zdGlsZSBhdXRob3IgKMKnMi4xKSwgemVyby1leGZpbC5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTVcIiBkYXRhLXNsdWc9XCI1LWFkdmVyc2FyaWFsLXBhc3MtdGhlLW1ldGFjaXJjdWxhci1jb25uZWN0b3ItYXR0YWNrLXdhbGtlZC1ub3JtYXRpdmUtaW50ZW50XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtNVwiIC8+e1wiNS4gQWR2ZXJzYXJpYWwgcGFzcyDigJQgdGhlIG1ldGFjaXJjdWxhci1jb25uZWN0b3IgYXR0YWNrLCB3YWxrZWQgIFwifTxfY29tcG9uZW50cy5lbT57XCIobm9ybWF0aXZlIGludGVudClcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIHRocmVhdCAoc3BlYyDCpzMuMiBSQi0xKTogdGhlIGNvbm5lY3RvciBpcyBhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibWV0YWNpcmN1bGFyIGludGVycHJldGVyXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBpdCBmZXRjaGVzXFxuYnl0ZXMgYW5kIHRob3NlIGJ5dGVzIGFyZSwgaW4gZWZmZWN0LCBhIHByb2dyYW0gc3RlZXJpbmcgdGhlIGNvbm5lY3Rvci4gV2FsayBldmVyeSBtb3ZlLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMub2w+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiXFxcIkZldGNoIGEgbmV3IGhvc3QuXFxcIlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGUgY29ubmVjdG9yJ3MgZmV0Y2hlZCBieXRlcyB0ZWxsIGl0IHRvIGZldGNoXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaHR0cHM6Ly9ldmlsLnRlc3Qvc3RlYWxcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLiDihpIgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJDb250YWluZWQuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRoZXJlIGlzIG5vIFVSTCBzdXJmYWNlICjCpzIgcnVsZSAxKTsgdGhlXFxuY29ubmVjdG9yIGNhbiBvbmx5IGZpcmUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaG9zdEZlZWRGZXRjaChpZCwgcGFyYW1zKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGFuZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJpZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcmVzb2x2ZXMgdG8gYSBmcm96ZW5cXG50ZW1wbGF0ZSB3aG9zZSBvcmlnaW4gaXMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYXBpLmV4YW1wbGUuY29tXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZXZpbC50ZXN0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpcyB1bm5hbWVhYmxlIOKAlCB0aGUgc2FtZVxcblxcXCJ1bmRlY2xhcmVkIHJlYWRzIGFyZSB1bm5hbWVhYmxlXFxcIiBtb3ZlIGFzIHRoZSBmb3JtdWxhIGVuZ2luZSwgYXBwbGllZCB0byBlZ3Jlc3MuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJcXFwiUmVkaXJlY3QgbWUgdGhlcmUuXFxcIlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGUgYWxsb3dsaXN0ZWQgb3JpZ2luIChvciBhZHZlcnNhcmlhbCBjb250ZW50IHByZXNlbnRlZCBhcyBhXFxucmVzcG9uc2UpIGlzc3VlcyBhIDMwMiB0byBcIn08X2NvbXBvbmVudHMuY29kZT57XCJldmlsLnRlc3RcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLiDihpIgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJDb250YWluZWQgKGJ1aWx0LCBUNDApLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyZWRpcmVjdDonbWFudWFsJ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCI7XFxudGhlIGhvc3QgcmUtcmVzb2x2ZXMgKyByZS12YWxpZGF0ZXMgdGhlIG5leHQgaG9wIGFnYWluc3QgdGhlIGFsbG93bGlzdCBhbmQgcmVmdXNlcy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlxcXCJSZWJpbmQgRE5TLlxcXCJcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYXBpLmV4YW1wbGUuY29tXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiByZS1yZXNvbHZlcyB0byBcIn08X2NvbXBvbmVudHMuY29kZT57XCIxNjkuMjU0LjE2OS4yNTRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChtZXRhZGF0YSkgYmV0d2VlblxcbmNoZWNrIGFuZCBjb25uZWN0LiDihpIgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJDb250YWluZWQgXCJ9PF9jb21wb25lbnRzLmVtPntcIm9ubHkgb25jZSDCpzMuMSBzaGlwc1wifTwvX2NvbXBvbmVudHMuZW0+e1wiIChyZXZpZXctMiBEMi1GNSkuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRoZSBwaW5uZWRcXG5zZXJ2ZXIgcGF0aCBjb250YWlucyBpdCAocmVzb2x2ZS1hbGwgKyByZWplY3QtaWYtYW55LXByaXZhdGUgKyBwaW4pLiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIkJ1dCB0b2RheSBhXFxuc2VjcmV0LWJlYXJpbmcgZmVlZCByb3V0ZXMgYnJvd3Nlci1kaXJlY3QgYW5kIGlzIE5PVCBwaW5uZWRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHNvIHVudGlsIMKnMy4xIChzZXJ2ZXItc2lkZVxcbnNlY3JldCBpbmplY3Rpb24gb24gdGhlIHBpbm5lZCBwYXRoKSwgdGhpcyBtb3ZlIGlzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wib3BlbiBmb3IgdGhlIGRhbmdlcm91cyBmZWVkcy5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgSG9uZXN0XFxuc3RhdHVzOiBjb250YWluZWQgb24gdGhlIG5vbi1zZWNyZXQgcGF0aCwgb3BlbiBvbiB0aGUgc2VjcmV0IHBhdGgsIGNsb3NlZCBldmVyeXdoZXJlIGJ5IMKnMy4xLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiXFxcIlBpY2sgYSBkaWZmZXJlbnQgYWxsb3dsaXN0ZWQgaG9zdC5cXFwiXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRoZSBjb25uZWN0b3IgaGFzIHR3byBmZWVkcyBhbmQgY29udGVudCBzdGVlcnNcXG5pdCB0byBzZW5kIGZlZWQtQSdzIGRhdGEgdG8gZmVlZC1CJ3Mgb3JpZ2luLiDihpIgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJDb250YWluZWQuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIEVhY2ggXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZmVlZDpmZXRjaChpZCzigKYpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpc1xcbmJvdW5kIHRvIFwifTxfY29tcG9uZW50cy5lbT57XCJvbmVcIn08L19jb21wb25lbnRzLmVtPntcIiB0ZW1wbGF0ZTsgdGhlcmUgaXMgbm8gY2FsbCB0aGF0IHRha2VzIGRhdGEtZm9yLUEgYW5kIGEgdGFyZ2V0LW9mLUIuIFRoZVxcbnBhcmFtIHNsb3RzIGNhbid0IGNhcnJ5IGEgaG9zdC4gQ3Jvc3MtZmVlZCBtaXhpbmcgd291bGQgcmVxdWlyZSBlbmNvZGluZyBBJ3MgcGF5bG9hZCBpbnRvXFxuQidzIHR5cGVkIHNsb3RzIOKAlCBib3VuZGVkIHRvIGRlY2xhcmVkLXNsb3QgZW50cm9weSAo4oaSIMKnNCkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJcXFwiU3R1ZmYgZXhmaWwgaW4gdGhlIGJvZHkgLyByb3VuZC10cmlwIGEgZmF0IGN1cnNvci5cXFwiXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIENvbnRlbnQgc3RlZXJzIHRoZSBjb25uZWN0b3IgdG9cXG5QT1NUIHRoZSBzaGVldCdzIHNlY3JldHMsIG9yIHRvIHJvdW5kLXRyaXAgYSBnaWFudCBcXFwiY3Vyc29yLlxcXCIg4oaSIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiVW5ib3VuZGVkIGNoYW5uZWxzIGNsb3NlZFxcbihyZXZpZXctMiBEMi1GMS9GMik7IHJlc2lkdWFsIGJvdW5kZWQgdG8gc2xvdCBlbnRyb3B5LlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJib2R5VGVtcGxhdGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGlzIGZpeGVkIHdpdGggYVxcbnJlcXVlc3QtYm9keSBjYXAgKMKnMiBydWxlIDMpOyBjdXJzb3JzIGFyZSBob3N0LW1pbnRlZCBhbmQgb3BhcXVlLXRvLWNvbm5lY3RvciAowqcyIHJ1bGUgMiksXFxuc28gdGhlIGNvbm5lY3Rvci1hdXRob3JlZCBmcmVlIGJvZHkgYW5kIHRoZSByb3VuZC10cmlwcGVkLWN1cnNvciBjaGFubmVscyBhcmUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJnb25lXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLiBXaGF0XFxucmVtYWlucyBpcyBkZWNsYXJlZCB0eXBlZC1zbG90IGVudHJvcHkg4oCUIGZhc3QgcmVsYXRpdmUgdG8gYSBzZWNyZXQgYnV0IG5vIGxvbmdlciB1bmJvdW5kZWRcXG4owqc0LCB0aGUgaG9uZXN0IHJlc2lkdWFsKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlxcXCJTdGVhbCB0aGUgc2VjcmV0IHZhbHVlLlxcXCJcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oaSIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiQ29udGFpbmVkIGZvciBoZWFkZXJzOyBib2R5LXJlZmxlY3Rpb24gaXMgdGhlIHJlc2lkdWFsXFxuKHJldmlldy0yIEQyLUYzKS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhlIHNlY3JldCBpcyBpbmplY3RlZCBieSByZWZlcmVuY2UgYW5kIHRoZSBjb25uZWN0b3IgY2Fubm90IHJlYWQgaXQgZnJvbVxcblwifTxfY29tcG9uZW50cy5lbT57XCJoZWFkZXJzXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcInN0cmlwSW5qZWN0ZWRGcm9tUmVzcG9uc2VcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKS4gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJCdXQgYSBtYWxpY2lvdXMgYWxsb3dsaXN0ZWQgaG9zdCBjYW4gcmVmbGVjdCB0aGVcXG50b2tlbiBpbiBpdHMgcmVzcG9uc2UgXCJ9PF9jb21wb25lbnRzLmVtPntcImJvZHlcIn08L19jb21wb25lbnRzLmVtPntcIixcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgd2hpY2ggdGhlIGNvbm5lY3RvciByZWFkcyBhcyBkYXRhLiBXaXRoIHNlcnZlci1zaWRlIGluamVjdGlvblxcbijCpzMuMSkgdGhlIHZhbHVlIG5ldmVyIHJlYWNoZXMgdGhlIGNvbm5lY3RvcidzIGZyYW1lIGF0IGFsbCBmb3IgdGhlIHJlcXVlc3QsIGJ1dCB0aGVcXG5cIn08X2NvbXBvbmVudHMuZW0+e1wicmVmbGVjdGVkXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgdmFsdWUgaW4gYSByZXNwb25zZSBib2R5IGlzIGEgcHJvcGVydHkgb2YgYSBtYWxpY2lvdXMgYm91bmQgaG9zdCBhbmQgaXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJub3RcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCJcXG5jbG9zZWQg4oCUIG5hbWVkIHJlc2lkdWFsIChuYXJyb3c6IG5lZWRzIGEgbWFsaWNpb3VzIGhvc3QgdGhhdCBhbHJlYWR5IGhvbGRzIHRoZSB1c2VyJ3Mga2V5KS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlxcXCJMb29wIHRvIGFtcGxpZnkuXFxcIlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBGaXJlIHRoZSB0ZW1wbGF0ZSBhIG1pbGxpb24gdGltZXMuIOKGkiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlRyaXB3aXJlZCwgd2Vha2x5IChyZXZpZXctMlxcbkQyLUYxKS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhlIHBlci1pbnN0YW5jZSBidWRnZXQgZmxhZ3MgXCJ9PF9jb21wb25lbnRzLmVtPntcImZyZXF1ZW5jeVwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGFub21hbGllcywgYnV0IHRoZSDCpzQgbGVhayBjb21wbGV0ZXMgXCJ9PF9jb21wb25lbnRzLmVtPntcImF0XFxuY2FkZW5jZVwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGluIG1pbnV0ZXMsIHdoaWNoIHRoZSB0cmlwd2lyZSBuZXZlciBzZWVzOyBhbmQgdGhlIHVuZGVybHlpbmcgbGltaXRlciBpcyBwZXItdWlkIGFuZFxcbmZhaWxzIG9wZW4uIFRoZSBidWRnZXQgaXMgYSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImJhY2tzdG9wIGFnYWluc3QgcnVuYXdheSBsb29wcywgbm90IGFnYWluc3QgdGhlIG9uLWNhZGVuY2VcXG5kcmFpblwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgc3RhdGVkIGhvbmVzdGx5LCBub3QgYXMgY29udGFpbm1lbnQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJcXFwiTXV0YXRlIG15IG93biB0ZW1wbGF0ZS5cXFwiXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKGkiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIkNvbnRhaW5lZC5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgSG9zdC1mcm96ZW4gYXQgZ3JhbnQgdGltZSAowqcyIHJ1bGUgNCk7IGFcXG53aWRlbmluZyBpcyBhIGdhdGVkIGZlZWQtY29uZmlnIHdyaXRlIHdpdGggcmUtY29uc2VudCwgd2hpY2ggdGhlIGNvbm5lY3RvciByZWFsbSBjYW5ub3RcXG5wZXJmb3JtIG9uIGl0c2VsZi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlxcXCJCZSBhIGhvc3RpbGUgYXV0aG9yLCBub3QgYSBob3N0aWxlIGNvbm5lY3RvclxcXCIgKHJldmlldy0yIEQyLUY0KS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhlIFwifTxfY29tcG9uZW50cy5lbT57XCJhdXRob3JcIn08L19jb21wb25lbnRzLmVtPntcIiBkZWNsYXJlc1xcbmEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiUE9TVFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZmVlZCB0byBcIn08X2NvbXBvbmVudHMuY29kZT57XCJldmlsLmNvbVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgd2l0aCBhIGNlbGwtcmVmZXJlbmNlIFwifTxfY29tcG9uZW50cy5jb2RlPntcImJvZHlUZW1wbGF0ZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuIOKGkiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIk5PVCBjb250YWluZWQgYnlcXG5lZ3Jlc3MtZml4aW5nXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBpdCBwaW5zIGZhaXRoZnVsbHkgdG8gdGhlIGF1dGhvcidzIGNob3NlbiBleGZpbCBob3N0LiBUaGUgb25seSBkZWZlbnNlIGlzXFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ3cml0ZS1zaW5rIGNvbnNlbnQgbGVnaWJpbGl0eSAowqcyLjEpXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCB3aGljaCBpcyB1bnZhbGlkYXRlZC4gVGhpcyBpcyB0aGUgYmlnZ2VzdCByZXNpZHVhbFxcbmFuZCBpdCBpcyBcIn08X2NvbXBvbmVudHMuZW0+e1wib3V0c2lkZVwifTwvX2NvbXBvbmVudHMuZW0+e1wiIHRoZSBjb21wcm9taXNlZC1jb25uZWN0b3IgdGhyZWF0IHRoZSByZXN0IG9mIHRoaXMgcGFzcyBhZGRyZXNzZXMuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVmVyZGljdCBvZiB0aGUgcGFzczpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXCJ9PF9jb21wb25lbnRzLmVtPntcInJlYWNoXCJ9PC9fY29tcG9uZW50cy5lbT57XCItZml4aW5nIGlzIHNvdW5kIOKAlCBtb3ZlcyAxLCA0LCA4IGZ1bGx5IGNvbnRhaW5lZCBieSB0aGUgbmV3XFxudGFyZ2V0LWZpeGluZyBsYXllciwgbW92ZSAyIGJ5IHRoZSBidWlsdCByZWRpcmVjdCByZS12YWxpZGF0aW9uLiBCdXQ6IG1vdmUgMyBpcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm9wZW4gb24gdGhlXFxuc2VjcmV0IHBhdGggdW50aWwgwqczLjFcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCI7IG1vdmUgNSdzIHVuYm91bmRlZCBjaGFubmVscyBhcmUgY2xvc2VkIGJ1dCBhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZmFzdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBzbG90LWVudHJvcHlcXG5yZXNpZHVhbCByZW1haW5zIChtb3ZlIDcncyB0cmlwd2lyZSBkb2VzIG5vdCBjYXRjaCBpdCk7IG1vdmUgNiBoYXMgYSBib2R5LXJlZmxlY3Rpb24gcmVzaWR1YWw7XFxuYW5kIG1vdmUgOSAoXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJhdXRob3ItaG9zdGlsZSB0ZW1wbGF0ZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIikgaXMgbm90IGFuIGVncmVzcyBwcm9ibGVtIGF0IGFsbCDigJQgaXQgcmlkZXMgY29uc2VudFxcbmxlZ2liaWxpdHkgdGhhdCBpcyB1bnZhbGlkYXRlZC4gU28gdGhlIGFuc3dlciB0byBzcGVjIFEyIGlzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1widGhlIHRyaXBsZSBkb2VzIE5PVCBzdWZmaWNlIHRvXFxuY2FsbCB0aGUgY29ubmVjdG9yIHNhZmVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCI6IGl0IGJvdW5kcyBhIG1ldGFjaXJjdWxhciBcIn08X2NvbXBvbmVudHMuZW0+e1wiY29ubmVjdG9yXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgdG8gXFxcImNvbnNlbnRlZCByZWFjaCxcXG5mYXN0LXNsb3QtZW50cm9weSB3cml0ZSwgd2Vha2x5LWZyZXF1ZW5jeS10cmlwd2lyZWQsXFxcIiBhbmQgaXQgZG9lcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBib3VuZCBhIGhvc3RpbGVcXG5cIn08X2NvbXBvbmVudHMuZW0+e1wiYXV0aG9yXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgZXhjZXB0IHZpYSB1bnZhbGlkYXRlZCB3cml0ZS1zaW5rIGNvbnNlbnQuIFRoZVxcbnBsYW4gYW5kIHNwZWMgbXVzdCBrZWVwIHN0YXRpbmcgdGhhdCByZXNpZHVhbDsgdGhleSBtdXN0IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibm90XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHVwZ3JhZGUgdGhpcyB0byBcXFwic2FmZS5cXFwiXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInNlYy02XCIgZGF0YS1zbHVnPVwiNi1sb2FkLWJlYXJpbmctYXNzdW1wdGlvbnMtY29kZS1hbmNob3JzXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtNlwiIC8+e1wiNi4gTG9hZC1iZWFyaW5nIGFzc3VtcHRpb25zICYgY29kZSBhbmNob3JzXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCJkZXBlbmRzLW9uLXRvZGF5LXZlcmlmaWVkLWFnYWluc3QtY29kZS0yMDI2LTA3LTA5LXJlLWNoZWNrZWQtYnktc2NyaXB0c2NoZWNrLXNwZWMtYW5jaG9yc21qc1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwiZGVwZW5kcy1vbi10b2RheS12ZXJpZmllZC1hZ2FpbnN0LWNvZGUtMjAyNi0wNy0wOS1yZS1jaGVja2VkLWJ5LXNjcmlwdHNjaGVjay1zcGVjLWFuY2hvcnNtanNcIiAvPntcIkRlcGVuZHMtb24tdG9kYXkgKHZlcmlmaWVkIGFnYWluc3QgY29kZSAyMDI2LTA3LTA5OyByZS1jaGVja2VkIGJ5IFwifTxfY29tcG9uZW50cy5jb2RlPntcInNjcmlwdHMvY2hlY2stc3BlYy1hbmNob3JzLm1qc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpXCJ9PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMudGFibGU+PF9jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGg+e1wiQXNzdW1wdGlvbiAoZXhpc3RpbmcgYmVoYXZpb3IgdGhlIGRlc2lnbiByZXN0cyBvbilcIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aD57XCJBbmNob3IgKHJlcG8tcmVsYXRpdmUgZmlsZSlcIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aD57XCJUb2tlbiAoZ3JlcC1zdGFibGUpXCJ9PC9fY29tcG9uZW50cy50aD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGhlYWQ+PF9jb21wb25lbnRzLnRib2R5PjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiVGhlIHNlcnZlci1zaWRlIHByb3h5IHJlc29sdmVzICsgdmFsaWRhdGVzICsgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJwaW5zXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHRvIHZhbGlkYXRlZCBhZGRyZXNzZXNcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJpbW1lZGlhdGVseS1ydW4tYmFja2VuZC9zcmMvbmV0RmV0Y2gudHNcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wicmVzb2x2ZUFuZFZhbGlkYXRlXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIlJlZGlyZWN0cyBhcmUgZm9sbG93ZWQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibWFudWFsXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB3aXRoIGEgcGVyLWhvcCByZS12YWxpZGF0ZSB1bmRlciBhIGhvcCBjYXBcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJpbW1lZGlhdGVseS1ydW4tYmFja2VuZC9zcmMvbmV0RmV0Y2gudHNcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiREVGQVVMVF9NQVhfUkVESVJFQ1RTXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIlJlc29sdmVkLUlQIGJsb2NrbGlzdCBjb3ZlcnMgcHJpdmF0ZS9sb29wYmFjay9saW5rLWxvY2FsL21ldGFkYXRhXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiaW1tZWRpYXRlbHktcnVuLWJhY2tlbmQvc3JjL25ldEZldGNoLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcImlzQmxvY2tlZElwXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIlRoZSBlZmZlY3RpdmUgYWxsb3dsaXN0IGlzIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1hbmlmZXN0IOKIqSBncmFudFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIHJlLWNoZWNrZWQgaG9zdC1zaWRlXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiaW1tZWRpYXRlbHktcnVuLXNpdGUtbWFpbi9zcmMvcmVnaXN0cnkvbmV0RmV0Y2hQb2xpY3kudHNcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiZWZmZWN0aXZlQWxsb3dsaXN0XCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIlNlY3JldCBpbmplY3Rpb24gaXMgaG9zdC1zaWRlLCBieSByZWZlcmVuY2UsIHVzZS1ub3QtcmVhZFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcImltbWVkaWF0ZWx5LXJ1bi1zaXRlLW1haW4vc3JjL3JlZ2lzdHJ5L25ldEZldGNoUG9saWN5LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcImluamVjdFNlY3JldFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJBIGd1YXJkZWQgZmV0Y2ggaXMgaXNzdWVkIGZyb20gdGhlIGhvc3QsIG5vdCB0aGUgYXBwIGZyYW1lXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiaW1tZWRpYXRlbHktcnVuLXNpdGUtbWFpbi9zcmMvZWRpdG9yL25ldEZldGNoSGFuZGxlci50c1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJwZXJmb3JtR3VhcmRlZEZldGNoXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIlBlci1yZXF1ZXN0IGJ1ZGdldC9yYXRlIG1hY2hpbmVyeSBleGlzdHMgdG8ga2V5IHBlci1pbnN0YW5jZVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcImltbWVkaWF0ZWx5LXJ1bi1iYWNrZW5kL3NyYy9yYXRlTGltaXQudHNcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiY29uc3VtZVwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50Ym9keT48L19jb21wb25lbnRzLnRhYmxlPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cIm11c3QtZXN0YWJsaXNoLW5ldy1pbnZhcmlhbnRzLXRoZS1pbXBsZW1lbnRhdGlvbi1jcmVhdGVzXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJtdXN0LWVzdGFibGlzaC1uZXctaW52YXJpYW50cy10aGUtaW1wbGVtZW50YXRpb24tY3JlYXRlc1wiIC8+e1wiTXVzdC1lc3RhYmxpc2ggKG5ldyBpbnZhcmlhbnRzIHRoZSBpbXBsZW1lbnRhdGlvbiBjcmVhdGVzKVwifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnRhYmxlPjxfY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRoPntcIk5ldyBpbnZhcmlhbnRcIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aD57XCJQcm92ZW4gYnkgKGdhdGUgdGVzdClcIn08L19jb21wb25lbnRzLnRoPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudGJvZHk+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJUaGUgY29ubmVjdG9yIHJlYWxtIGhvbGRzIFwifTxfY29tcG9uZW50cy5jb2RlPntcImZlZWQ6ZmV0Y2hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICh0ZW1wbGF0ZS1ib3VuZCksIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibm90XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGdlbmVyYWwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibmV0OmZldGNoXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcImNvbm5lY3Rvci1jYXBzIGdhdGU6IGEgY29ubmVjdG9yIGNhbGxpbmcgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZmV0Y2goKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibmV0OmZldGNoXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBnZXRzIFwifTxfY29tcG9uZW50cy5jb2RlPntcImZvcmJpZGRlblwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJBIGZldGNoIHRhcmdldCBpcyBhIHB1cmUgZnVuY3Rpb24gb2YgZnJvemVuIGZlZWQgY29uZmlnICsgdHlwZWQgcGFyYW1zOyBuZXZlciBvZiBmZXRjaGVkIGNvbnRlbnRcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJlZ3Jlc3MtZml4aW5nIGdhdGU6IGEgaG9zdGlsZSBjb25uZWN0b3IgaGFybmVzcyAobWV0YWNpcmN1bGFyKSBjYW5ub3QgY2F1c2UgYSByZXF1ZXN0IHRvIGFueSBob3N0L3BhdGggb3V0c2lkZSBpdHMgZmVlZCB0ZW1wbGF0ZXMsIGluY2wuIHZpYSByZWRpcmVjdC9yZWJpbmRpbmcvcGFyYW0gaW5qZWN0aW9uIChtb3ZlcyAx4oCTNCwgOCBvZiDCpzUpXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiRGF0YS1wbGFuZSBwYXJhbXMgY2FuIG9jY3VweSBvbmx5IHRlbXBsYXRlLW1hcmtlZCBzbG90cyBhbmQgY2Fubm90IGNhcnJ5IGEgaG9zdC9wYXRoL25ldyBrZXlcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJwYXJhbS1jb25maW5lbWVudCB0ZXN0OiBhIHBhcmFtIGNvbnRhaW5pbmcgYSBVUkwvaG9zdC9cIn08X2NvbXBvbmVudHMuY29kZT57XCIuLi9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHBhdGgvbmV3IHF1ZXJ5IGtleSBpcyByZWplY3RlZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJpbnZhbGlkLXBhcmFtc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIG5ldmVyIGZldGNoZWRcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJUaGUgcmVxdWVzdCBib2R5IGlzIHRlbXBsYXRlZCBBTkQgc2l6ZS1jYXBwZWQ7IGN1cnNvcnMgYXJlIGhvc3QtbWludGVkIG9wYXF1ZVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcImJvZHktZml4IHRlc3Q6IGEgY29ubmVjdG9yIGNhbm5vdCBlbWl0IGEgcmVxdWVzdCBib2R5IG91dHNpZGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYm9keVRlbXBsYXRlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIitzbG90cywgY2Fubm90IGV4Y2VlZCB0aGUgcmVxdWVzdC1ib2R5IGNhcCwgYW5kIGNhbm5vdCBzdXBwbHkvcm91bmQtdHJpcCBhIGN1cnNvciAocmV2aWV3LTIgRDItRjEvRjIpXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiU2VjcmV0LWJlYXJpbmcgZmVlZHMgcnVuIG9uIHRoZSBwaW5uZWQgc2VydmVyIHBhdGhcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJzZWNyZXQtcGluIGdhdGU6IGEgc2VjcmV0IGZlZWQgd2hvc2UgaG9zdCByZWJpbmRzIHRvIGEgcHJpdmF0ZS9tZXRhZGF0YSBJUCBpcyByZWZ1c2VkIChyZXZpZXctMiBEMi1GNSwgwqczLjEpIOKAlCBwcm92ZXMgdGhlIGJyb3dzZXItZGlyZWN0IHVucGlubmVkIHBhdGggaXMgbm90IHVzZWQgZm9yIFwifTxfY29tcG9uZW50cy5jb2RlPntcImZlZWQ6ZmV0Y2hcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiQSB3cml0ZS1zaW5rIGZlZWQgaXMgY29uc2VudGVkIGFzIG91dGJvdW5kLCBzaG93aW5nIGJvZHkgY2VsbC1yZWZzICsgdm9sdW1lXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wid3JpdGUtc2luay1jb25zZW50IGdhdGU6IGEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiUE9TVFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYm9keVRlbXBsYXRlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBmZWVkJ3MgY29uc2VudCBzdXJmYWNlIG5hbWVzIGl0IG91dGJvdW5kIGFuZCBsaXN0cyB0aGUgY2VsbHMgc2VudCAocmV2aWV3LTIgRDItRjQsIMKnMi4xKTsgYSByZWFkIGZlZWQgZG9lcyBub3RcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJQZXItZmVlZC1pbnN0YW5jZSBidWRnZXQga2V5ZWQgb24gYSBob3N0LW1pbnRlZCBpZDsgYm91bmRzIHJ1bmF3YXkgbG9vcHMgKG5vdCB0aGUgb24tY2FkZW5jZSBkcmFpbilcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJidWRnZXQgdGVzdDogYSBjb25uZWN0b3Itc3VwcGxpZWQgaW5zdGFuY2UgaWQgY2Fubm90IG1pbnQgYSBmcmVzaCBidWNrZXQ7IE7DlyBjYWRlbmNlIHRyaXBzOyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInRoZSBob25lc3QgbGltaXQg4oCUIGFuIGF0LWNhZGVuY2UgZHJhaW4gaXMgTk9UIGNhdWdodCDigJQgaXMgZG9jdW1lbnRlZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAocmV2aWV3LTIgRDItRjEpXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiVGVtcGxhdGUgaXMgZnJvemVuIGF0IGdyYW50IHRpbWU7IGEgcnVubmluZyBjb25uZWN0b3IgY2Fubm90IHdpZGVuIGl0XCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1widGVtcGxhdGUtaW1tdXRhYmlsaXR5IHRlc3Q6IGEgY29ubmVjdG9yIHNlbGYtd2lkZW5pbmcgaXRzIG9yaWdpbiBzZXQgaXMgcmVmdXNlZDsgYSBjb25maWcgZWRpdCByZS1jb25zZW50c1wifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRib2R5PjwvX2NvbXBvbmVudHMudGFibGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTdcIiBkYXRhLXNsdWc9XCI3LWRlY2lzaW9ucy1yZWplY3RlZC1hbHRlcm5hdGl2ZXNcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy03XCIgLz57XCI3LiBEZWNpc2lvbnMgJiByZWplY3RlZCBhbHRlcm5hdGl2ZXNcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUYXJnZXQtZml4aW5nIGJ5IGhvc3QtY29uc3RydWN0ZWQgcmVxdWVzdCB0ZW1wbGF0ZXMga2V5ZWQgYnkgZmVlZC1pbnN0YW5jZSBpZDsgdGhlXFxuY29ubmVjdG9yIG5ldmVyIHBhc3NlcyBhIFVSTC5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXCJ9PF9jb21wb25lbnRzLmVtPntcIlJlamVjdGVkOlwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGdpdmluZyB0aGUgY29ubmVjdG9yIGdlbmVyYWwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibmV0OmZldGNoXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB3aXRoXFxuYSB0aWdodCBhbGxvd2xpc3QgKGxlYXZlcyBwZXItY2FsbCBob3N0L3BhdGgvYm9keSBjaG9pY2Ugb3BlbiB0byBhIG1ldGFjaXJjdWxhciBmb3JrIOKAlCB0aGVcXG5leGFjdCBSQi0xIGhvbGUpOyBhbiBhZ2VudGljIGNvbm5lY3RvciB0aGF0IGNvbXB1dGVzIGl0cyBvd24gdGFyZ2V0cyAoc3BlYyDCpzQuNSByZWplY3RzKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlJldXNlIHRoZSBidWlsdCBTU1JGLXBpbm5pbmcgcHJveHkgZm9yIHRoZSBcIn08X2NvbXBvbmVudHMuZW0+e1wibm9uLXNlY3JldFwifTwvX2NvbXBvbmVudHMuZW0+e1wiIHBhdGg7IGFkZCBhIFwifTxfY29tcG9uZW50cy5lbT57XCJwaW5uZWQgc2VjcmV0IHBhdGhcIn08L19jb21wb25lbnRzLmVtPntcIlxcbnZpYSBzZXJ2ZXItc2lkZSBpbmplY3Rpb24gKMKnMy4xLCByZXZpZXctMiBEMi1GNSkuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5lbT57XCJSZWplY3RlZDpcIn08L19jb21wb25lbnRzLmVtPntcIiB0aGUgZWFybGllciBcXFwicmV1c2VcXG51bmNoYW5nZWRcXFwiIGNsYWltIChmYWxzZSDigJQgc2VjcmV0IGZlZWRzIHJvdXRlIGJyb3dzZXItZGlyZWN0L3VucGlubmVkKTsgcmVzb2x2ZS1hbmQtcGluIGluIHRoZVxcbmJyb3dzZXIgKGluZmVhc2libGUgaW4tdGFiKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkN1cnNvcnMgaG9zdC1taW50ZWQgYW5kIG9wYXF1ZS10by1jb25uZWN0b3I7IHJlcXVlc3QgYm9keSBmdWxseSB0ZW1wbGF0ZWQgKyBzaXplLWNhcHBlZFxcbihyZXZpZXctMiBEMi1GMS9GMikuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5lbT57XCJSZWplY3RlZDpcIn08L19jb21wb25lbnRzLmVtPntcIiB0aGUgZWFybGllciBcXFwib3BhcXVlIGN1cnNvciB0aGUgaG9zdCByb3VuZC10cmlwc1xcXCIgc2xvdCAoYVxcbmNvbm5lY3Rvci1yb3VuZC10cmlwcGVkIGN1cnNvciBpcyBlaXRoZXIgY29ubmVjdG9yLWF1dGhvcmVkIGV4ZmlsIG9yIGEgZnVuY3Rpb24gb2YgZmV0Y2hlZFxcbmNvbnRlbnQg4oCUIGJvdGggYnJlYWsgwqcxKTsgYW4gdW5jYXBwZWQgcmVxdWVzdCBib2R5LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiV3JpdGUtc2luayBjb25zZW50OiBhIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlBPU1RcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL2JvZHkgZmVlZCBpcyBjb25zZW50ZWQgYXMgb3V0Ym91bmQsIHNob3dpbmcgY2VsbC1yZWZzICtcXG52b2x1bWUgKMKnMi4xLCByZXZpZXctMiBEMi1GNCkuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5lbT57XCJSZWplY3RlZDpcIn08L19jb21wb25lbnRzLmVtPntcIiB0cnVzdGluZyBcXFwiZmVlZCBjb25maWcgaXMgYmVuaWduXFxcIiAoaXQgaXMgdHJ1c3RlZFxcbmZvciBpbnRlZ3JpdHksIG5vdCBpbnRlbnQg4oCUIGEgaG9zdGlsZSBhdXRob3IncyB0ZW1wbGF0ZSBpcyB0aGUgYXR0YWNrKTsgcmVuZGVyaW5nIGFcXG53cml0ZS1zaW5rIGlkZW50aWNhbGx5IHRvIGEgcmVhZC1zb3VyY2UgaW4gdGhlIHBvd2VyYm94LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiU3RhdGUgdGhlIHJlc2lkdWFsIGFzIGEgXCJ9PF9jb21wb25lbnRzLmVtPntcImZhc3RcIn08L19jb21wb25lbnRzLmVtPntcIiB3cml0ZSBjaGFubmVsLCBiYWNrc3RvcHBlZCBieSB0aWVyaW5nICsgY29uc2VudCwgbmV2ZXJcXG5cXFwic2FmZVxcXCIgKHJldmlldy0yIEQyLUYxKS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXCJ9PF9jb21wb25lbnRzLmVtPntcIlJlamVjdGVkOlwifTwvX2NvbXBvbmVudHMuZW0+e1wiIHRoZSBlYXJsaWVyIFxcXCJzbG93IHBhcmFtIGRyaXBcXFwiIGZyYW1pbmcgKHRoZSBkcmFpblxcbmNvbXBsZXRlcyBhdCBjYWRlbmNlIGluIG1pbnV0ZXMpOyBjbGFpbWluZyBlZ3Jlc3MtZml4aW5nIG1ha2VzIGEgY29tcHJvbWlzZWQgY29ubmVjdG9yIFwifTxfY29tcG9uZW50cy5lbT57XCJvciBhXFxuaG9zdGlsZSBhdXRob3JcIn08L19jb21wb25lbnRzLmVtPntcIiB6ZXJvLWV4ZmlsICh0aGUgaG9uZXN0IFEyIGFuc3dlciBpcyBcXFwiZG9lcyBub3Qgc3VmZmljZSB0byBjYWxsIHNhZmVcXFwiKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLThcIiBkYXRhLXNsdWc9XCI4LW9wZW4tcXVlc3Rpb25zXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtOFwiIC8+e1wiOC4gT3BlbiBxdWVzdGlvbnNcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJPUS0xIChmZWVkcyBzcGVjIGhvbWUpLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGUgcmVxdWVzdC10ZW1wbGF0ZSBzY2hlbWEgKMKnMikgaXMgdGhlIGNvbm5lY3RvcidzIGNvbnRyYWN0XFxuYW5kIG1heSBkZXNlcnZlIGl0cyBvd24gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQ09OTkVDVE9SX0ZFRURTX1NQRUNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHJhdGhlciB0aGFuIGxpdmluZyBpbiB0aGUgUmVja29uZXIgcGxhbiDigJRcXG5kZWNpZGUgd2hlbiBEMiBidWlsZCBzdGFydHMuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJPUS0yIChzdHJlYW1pbmcvc3Vic2NyaXB0aW9uIGZlZWRzKS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgwqcyIHNob3dzIHRoZSBwb2xsIGNhc2UuIEEgbG9uZy1saXZlZFxcbnN1YnNjcmlwdGlvbiAoV2ViU29ja2V0L1NTRSkgaXMgc3RpbGwgdGVtcGxhdGUtZml4ZWQgZm9yIHRoZSBcIn08X2NvbXBvbmVudHMuZW0+e1wiY29ubmVjdFwifTwvX2NvbXBvbmVudHMuZW0+e1wiIHRhcmdldCwgYnV0IHRoZVxcbnBlci1tZXNzYWdlIGRhdGEgcGxhbmUgbmVlZHMgdGhlIHNhbWUgXFxcIm5vIHRhcmdldCBpbmZsdWVuY2UgZnJvbSBjb250ZW50XFxcIiBwcm9vZiDigJQgc3BlbGwgaXRcXG5vdXQgYmVmb3JlIGJ1aWxkaW5nIHRoZSBzdWJzY3JpcHRpb24gbW9kZSAoaW50ZXJhY3RzIHdpdGggcGxhbiBSUS1DMS/CpzUuMikuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJPUS0zIChRMiBzdWZmaWNpZW5jeSwgZXNjYWxhdGVkIHRvIHRoZSB0aGlyZCBmcmVzaC1hZ2VudCBwYXNzKS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgwqc1IGFyZ3VlcyB0aGVcXG50cmlwbGUgYm91bmRzIHRoZSBmb3JrOyB0aGUgc3BlYydzIHJlcXVlc3RlZCB0aGlyZCBhZHZlcnNhcmlhbCBwYXNzIHNob3VsZCBhdHRhY2sgwqc1J3NcXG5tb3ZlcyA1Lzcgc3BlY2lmaWNhbGx5IOKAlCBpcyBwYXJhbS1lbnRyb3B5ICsgYnVkZ2V0IGEgXCJ9PF9jb21wb25lbnRzLmVtPntcInRvbGVyYWJsZVwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGNvdmVydCBjaGFubmVsIGZvciB0aGVcXG5NMy1yZWFjaCB0aGUgY29ubmVjdG9yIGFscmVhZHkgaGFzLCBvciBkb2VzIGEgc3BlY2lmaWMgZmVlZCBwYXR0ZXJuIG1ha2UgaXQgdW5hY2NlcHRhYmxlP1wifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD48Lz47XG59XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNRFhDb250ZW50KHByb3BzID0ge30pIHtcbiAgY29uc3Qge3dyYXBwZXI6IE1EWExheW91dH0gPSB7XG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9O1xuICByZXR1cm4gTURYTGF5b3V0ID8gPE1EWExheW91dCB7Li4ucHJvcHN9PjxfY3JlYXRlTWR4Q29udGVudCB7Li4ucHJvcHN9IC8+PC9NRFhMYXlvdXQ+IDogX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpO1xufVxuZnVuY3Rpb24gX21pc3NpbmdNZHhSZWZlcmVuY2UoaWQsIGNvbXBvbmVudCwgcGxhY2UpIHtcbiAgdGhyb3cgbmV3IEVycm9yKFwiRXhwZWN0ZWQgXCIgKyAoY29tcG9uZW50ID8gXCJjb21wb25lbnRcIiA6IFwib2JqZWN0XCIpICsgXCIgYFwiICsgaWQgKyBcImAgdG8gYmUgZGVmaW5lZDogeW91IGxpa2VseSBmb3Jnb3QgdG8gaW1wb3J0LCBwYXNzLCBvciBwcm92aWRlIGl0LlwiICsgKHBsYWNlID8gXCJcXG5JdOKAmXMgcmVmZXJlbmNlZCBpbiB5b3VyIGNvZGUgYXQgYFwiICsgcGxhY2UgKyBcImAgaW4gYC9hcHAvZG9jcy9zcGVjcy9DT05ORUNUT1JfRUdSRVNTX0ZJWElOR19TUEVDLm1kYFwiIDogXCJcIikpO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFFQSxJQUFBQSxZQUFBLEdBQUFDLE9BQUE7QUFBd0YsSUFBQUMsV0FBQSxHQUFBRCxPQUFBO0FBRnhGO0FBQ0E7O0FBRUEsU0FBU0UsaUJBQWlCQSxDQUFDQyxLQUFLLEVBQUU7RUFDaEMsTUFBTUMsV0FBVyxHQUFHO01BQ2xCQyxVQUFVLEVBQUUsWUFBWTtNQUN4QkMsSUFBSSxFQUFFLE1BQU07TUFDWkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsR0FBRyxFQUFFLEtBQUs7TUFDVkMsTUFBTSxFQUFFLFFBQVE7TUFDaEJDLEtBQUssRUFBRSxPQUFPO01BQ2RDLEtBQUssRUFBRSxPQUFPO01BQ2RDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEtBQUssRUFBRSxPQUFPO01BQ2RDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1IsR0FBRyxJQUFBQyw2QkFBa0IsRUFBQyxDQUFDO01BQ3ZCLEdBQUdyQixLQUFLLENBQUNzQjtJQUNYLENBQUM7SUFBRTtNQUFDQztJQUFhLENBQUMsR0FBR3RCLFdBQVc7RUFDaEMsSUFBSSxDQUFDc0IsYUFBYSxFQUFFQyxvQkFBb0IsQ0FBQyxlQUFlLEVBQUUsSUFBSSxDQUFDO0VBQy9ELG9CQUFPLElBQUExQixXQUFBLENBQUEyQixJQUFBLEVBQUEzQixXQUFBLENBQUE0QixRQUFBO0lBQUFDLFFBQUEsZ0JBQUUsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0ksRUFBRTtNQUFDdUIsRUFBRSxFQUFDLDZGQUE2RjtNQUFBRCxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQTZGLENBQUUsQ0FBQyxFQUFDLGdHQUFnRztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFTLENBQXFCLENBQUMsRUFBQyxnQ0FBZ0MsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBK0IsQ0FBbUIsQ0FBQyxFQUFDLE9BQU8sZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFJLENBQXFCLENBQUMsRUFBQyxzQ0FBc0MsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBeUIsQ0FBbUIsQ0FBQyxFQUFDLFdBQVcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFvQyxDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUE0QixDQUFtQixDQUFDLEVBQUMsb0ZBQW9GLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBNkMsQ0FBcUIsQ0FBQyxFQUFDLDJEQUEyRCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQStDLENBQXFCLENBQUMsRUFBQyw0REFBNEQsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFvQixDQUFxQixDQUFDLEVBQUMsd0dBQXdHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBNkMsQ0FBcUIsQ0FBQyxFQUFDLG9FQUFvRSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVUsQ0FBcUIsQ0FBQyxFQUFDLGFBQWE7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNDLFVBQVU7TUFBQXlCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztRQUFBZ0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsR0FBRSw0REFBNEQsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1lBQUF3QixRQUFBLEVBQUU7VUFBK0MsQ0FBbUIsQ0FBQztRQUFBLENBQW9CLENBQUMsRUFBQywwR0FBMEc7TUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQXlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsVUFBVTtNQUFBeUIsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDVSxDQUFDO1FBQUFnQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWMsQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBK0IsQ0FBbUIsQ0FBQyxFQUFDLG1GQUFtRixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWdDLENBQXFCLENBQUMsRUFBQyw2RkFBNkYsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBb0IsQ0FBbUIsQ0FBQyxFQUFDLHVCQUF1QixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQStCLENBQW1CLENBQUMsRUFBQyx3REFBd0QsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBaUIsQ0FBbUIsQ0FBQyxFQUFDLHdDQUF3QyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUEwQixDQUFtQixDQUFDLEVBQUMsc0VBQXNFLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQTRCLENBQW1CLENBQUMsRUFBQyxxREFBcUQ7TUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQXlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ08sRUFBRSxJQUFFLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQVYsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDSyxFQUFFO01BQUNzQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUsaURBQWlEO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQyxtQ0FBbUMsZUFBQyxJQUFBOUIsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1FBQUF1QixRQUFBLEVBQUU7TUFBb0IsQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLHlHQUF5RyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUFpQixDQUFpQixDQUFDLEVBQUMsU0FBUyxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxHQUFFLHVFQUF1RSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFRLENBQWlCLENBQUMsRUFBQyxPQUFPO01BQUEsQ0FBcUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBeUMsQ0FBbUIsQ0FBQyxFQUFDLDJCQUEyQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQUssQ0FBcUIsQ0FBQyxFQUFDLDZCQUE2QixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQUssQ0FBcUIsQ0FBQyxFQUFDLDRDQUE0QyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQU0sQ0FBcUIsQ0FBQyxFQUFDLHlEQUF5RCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFPLENBQW1CLENBQUMsRUFBQyxTQUFTLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQVEsQ0FBbUIsQ0FBQyxFQUFDLDJDQUEyQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFRLENBQW1CLENBQUMsRUFBQyxVQUFVLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBa0MsQ0FBcUIsQ0FBQyxFQUFDLDhCQUE4QixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQUksQ0FBcUIsQ0FBQyxFQUFDLHVDQUF1QyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUFVLENBQWlCLENBQUMsRUFBQyxtQkFBbUIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBVyxDQUFtQixDQUFDLEVBQUMsZ0JBQWdCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQWtCLENBQW1CO01BQUMsQ0FBb0IsQ0FBQyxFQUFDLGNBQWMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBbUIsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBb0IsQ0FBbUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNDLFVBQVU7TUFBQXlCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztRQUFBZ0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFzRyxDQUFxQixDQUFDLEVBQUMsNkRBQTZELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLFVBQVUsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBb0IsQ0FBbUIsQ0FBQyxFQUFDLGtDQUFrQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWdCLENBQXFCLENBQUMsRUFBQyxpQkFBaUIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBSyxDQUFpQixDQUFDLEVBQUMsMkZBQTJGLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQWtCLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQXFCLENBQW1CLENBQUMsRUFBQyxTQUFTLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBa0MsQ0FBcUIsQ0FBQyxFQUFDLHVFQUF1RSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWlDLENBQXFCLENBQUMsRUFBQyxzRUFBc0UsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUEwRCxDQUFxQixDQUFDLEVBQUMsc05BQXNOLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQU0sQ0FBbUIsQ0FBQyxFQUFDLGdCQUFnQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyw0REFBNEQ7TUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQXlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLFdBQVcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFLLENBQXFCLENBQUMsRUFBQyx5Q0FBeUMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFLLENBQXFCLENBQUMsRUFBQyx3RkFBd0YsZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsR0FBRSx3QkFBd0IsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBVyxDQUFpQixDQUFDLEVBQUMsVUFBVSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFjLENBQWlCLENBQUM7TUFBQSxDQUFvQixDQUFDLEVBQUMsZ0pBQWdKO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDbUIsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7WUFBQXdCLFFBQUEsRUFBRTtVQUFXLENBQW1CLENBQUMsRUFBQyxXQUFXO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLE9BQU8sZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBSyxDQUFpQixDQUFDLEVBQUMsWUFBWSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQUssQ0FBcUIsQ0FBQyxFQUFDLHNIQUFzSCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFPLENBQWlCLENBQUMsRUFBQyxVQUFVLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQU0sQ0FBaUIsQ0FBQyxFQUFDLFNBQVMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBTSxDQUFpQixDQUFDLEVBQUMsb0JBQW9CLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQU8sQ0FBaUIsQ0FBQyxFQUFDLFFBQVE7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLFdBQVcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFLLENBQXFCLENBQUMsRUFBQyxrRUFBa0UsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBVyxDQUFtQixDQUFDLEVBQUMsOENBQThDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEdBQUUsd0JBQXdCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLFNBQVMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBZSxDQUFpQixDQUFDO01BQUEsQ0FBb0IsQ0FBQyxFQUFDLDRDQUE0QztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ21CLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1lBQUF3QixRQUFBLEVBQUU7VUFBVyxDQUFtQixDQUFDLEVBQUMsV0FBVztRQUFBLENBQXFCLENBQUMsRUFBQyxPQUFPLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQUssQ0FBaUIsQ0FBQyxFQUFDLFlBQVksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFLLENBQXFCLENBQUMsRUFBQyxzSEFBc0gsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBTyxDQUFpQixDQUFDLEVBQUMsVUFBVSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFNLENBQWlCLENBQUMsRUFBQyxTQUFTLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQU0sQ0FBaUIsQ0FBQyxFQUFDLG9CQUFvQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFPLENBQWlCLENBQUMsRUFBQyxRQUFRO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxHQUFFLG1CQUFtQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7WUFBQXVCLFFBQUEsRUFBRTtVQUFRLENBQWlCLENBQUMsRUFBQyxlQUFlO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLHdCQUF3QixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTJCLENBQXFCLENBQUMsRUFBQyx5Q0FBeUMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBK0QsQ0FBaUIsQ0FBQyxFQUFDLGdHQUFnRyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFLLENBQWlCLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBSyxDQUFxQixDQUFDLEVBQUMsd0RBQXdELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBUSxDQUFxQixDQUFDLEVBQUMsNEJBQTRCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBTSxDQUFxQixDQUFDLEVBQUMsc0RBQXNELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBd0IsQ0FBcUIsQ0FBQyxFQUFDLEdBQUc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFnQyxDQUFxQixDQUFDLEVBQUMscUNBQXFDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBd0UsQ0FBcUIsQ0FBQyxFQUFDLCtCQUErQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQTJFLENBQXFCLENBQUMsRUFBQywwSkFBMEosZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1FBQUF1QixRQUFBLEVBQUU7TUFBNEUsQ0FBaUIsQ0FBQztJQUFBLENBQWUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDTyxFQUFFLElBQUUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBVixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNLLEVBQUU7TUFBQ3NCLEVBQUUsRUFBQyxPQUFPO01BQUMsYUFBVSxvRUFBb0U7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLHVCQUF1QixlQUFDLElBQUE5QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUFRLENBQWlCLENBQUMsRUFBQyxvQkFBb0IsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1FBQUF1QixRQUFBLEVBQUU7TUFBUyxDQUFpQixDQUFDLEVBQUMsV0FBVyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUFhLENBQWlCLENBQUM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNVLENBQUM7TUFBQWdCLFFBQUEsRUFBRTtJQUErRyxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNtQixFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBd0IsUUFBQSxFQUFFO1VBQW1CLENBQW1CLENBQUMsRUFBQywyQkFBMkI7UUFBQSxDQUFxQixDQUFDLEVBQUMsd0pBQXdKLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLGtEQUFrRDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFzQyxDQUFxQixDQUFDLEVBQUMsbUdBQW1HLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBTSxDQUFxQixDQUFDLEVBQUMsb0NBQW9DLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBTyxDQUFxQixDQUFDLEVBQUMsUUFBUSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQVUsQ0FBcUIsQ0FBQyxFQUFDLHVCQUF1QjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLEdBQUUsMENBQTBDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBd0osQ0FBcUIsQ0FBQyxFQUFDLHdFQUF3RSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUF1RCxDQUFpQixDQUFDLEVBQUMsNkRBQTZEO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDQyxVQUFVO01BQUF5QixRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNVLENBQUM7UUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBMkUsQ0FBcUIsQ0FBQyxFQUFDLG1DQUFtQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUF1QixDQUFpQixDQUFDLEVBQUMsWUFBWSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQVMsQ0FBcUIsQ0FBQyxFQUFDLGFBQWEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUEwQixDQUFxQixDQUFDLEVBQUMscURBQXFELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQU0sQ0FBbUIsQ0FBQyxFQUFDLFdBQVcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBVSxDQUFtQixDQUFDLEVBQUMsV0FBVyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUMsRUFBQywwRkFBMEYsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBVSxDQUFtQixDQUFDLEVBQUMsMEJBQTBCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLDZDQUE2QyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFRLENBQWlCLENBQUMsRUFBQyxrR0FBa0csZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFvQixDQUFxQixDQUFDLEVBQUMsb0VBQW9FLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBWSxDQUFxQixDQUFDLEVBQUMsNEZBQTRGO01BQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUF5QixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNLLEVBQUU7TUFBQ3NCLEVBQUUsRUFBQyxPQUFPO01BQUMsYUFBVSx5RUFBeUU7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLDZEQUE2RCxlQUFDLElBQUE5QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUEwQixDQUFpQixDQUFDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLEdBQUUsOEJBQThCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBeUIsQ0FBcUIsQ0FBQyxFQUFDLGdCQUFnQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQWtCLENBQXFCLENBQUMsRUFBQyx1Q0FBdUMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFrQixDQUFxQixDQUFDLEVBQUMsaUJBQWlCO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDVyxHQUFHO01BQUFlLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUMyQixTQUFTLEVBQUMsZ0JBQWdCO1FBQUFILFFBQUEsRUFBRTtNQUFxekIsQ0FBbUI7SUFBQyxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNVLENBQUM7TUFBQWdCLFFBQUEsR0FBRSxrQ0FBa0MsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFxQixDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFpRCxDQUFtQixDQUFDLEVBQUMsaUJBQWlCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQVUsQ0FBaUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBYSxDQUFtQixDQUFDLEVBQUMsc0JBQXNCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBSyxDQUFxQixDQUFDLEVBQUMsNERBQTREO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDVyxHQUFHO01BQUFlLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUMyQixTQUFTLEVBQUMsYUFBYTtRQUFBSCxRQUFBLEVBQUU7TUFBMkwsQ0FBbUI7SUFBQyxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNVLENBQUM7TUFBQWdCLFFBQUEsR0FBRSxrREFBa0QsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUE2QixDQUFxQixDQUFDLEVBQUMsOElBQThJO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUyxFQUFFO01BQUFpQixRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBaUIsQ0FBcUIsQ0FBQyxFQUFDLG1IQUFtSCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFZLENBQW1CLENBQUMsRUFBQyxpQkFBaUIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsa0JBQWtCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBYSxDQUFxQixDQUFDLEVBQUMseUNBQXlDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQVksQ0FBbUIsQ0FBQyxFQUFDLG9FQUFvRSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFTLENBQW1CLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBbUcsQ0FBcUIsQ0FBQyxFQUFDLG9EQUFvRCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFTLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLHlCQUF5QixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQU0sQ0FBcUIsQ0FBQyxFQUFDLDRDQUE0QyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFPLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLHVEQUF1RCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFLLENBQWlCLENBQUMsRUFBQyxjQUFjLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBNkMsQ0FBcUIsQ0FBQyxFQUFDLDhFQUE4RSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxHQUFFLGdEQUFnRCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7WUFBQXVCLFFBQUEsRUFBRTtVQUFtQixDQUFpQixDQUFDO1FBQUEsQ0FBb0IsQ0FBQyxFQUFDLHdLQUF3SyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFpQixDQUFpQixDQUFDLEVBQUMsb0xBQW9MLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBVyxDQUFxQixDQUFDLEVBQUMscUdBQXFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQXFQLENBQWlCLENBQUM7TUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBK0QsQ0FBcUIsQ0FBQyxFQUFDLDRCQUE0QixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFNLENBQW1CLENBQUMsRUFBQyxTQUFTLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLGtEQUFrRCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQVMsQ0FBcUIsQ0FBQyxFQUFDLGlFQUFpRSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFVLENBQWlCLENBQUMsRUFBQyxrREFBa0Q7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBdUMsQ0FBcUIsQ0FBQyxFQUFDLFdBQVcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBbUIsQ0FBbUIsQ0FBQyxFQUFDLHdMQUF3TDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFxRCxDQUFxQixDQUFDLEVBQUMsZ0VBQWdFLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQUssQ0FBaUIsQ0FBQyxFQUFDLHNFQUFzRSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFRLENBQW1CLENBQUMsRUFBQyxnSEFBZ0gsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFhLENBQXFCLENBQUMsRUFBQywwRkFBMEY7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDcUIsRUFBRSxFQUFDLFNBQVM7TUFBQyxhQUFVLDRGQUE0RjtNQUFBRCxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVMsQ0FBRSxDQUFDLEVBQUMsd0VBQXdFLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQThCLENBQWlCLENBQUM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNVLENBQUM7TUFBQWdCLFFBQUEsR0FBRSx1Q0FBdUMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1FBQUF1QixRQUFBLEVBQUU7TUFBVSxDQUFpQixDQUFDLEVBQUMsMERBQTBELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQUksQ0FBaUIsQ0FBQyxFQUFDLCtIQUErSDtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ21CLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXVFLENBQXFCLENBQUMsRUFBQyxpQkFBaUIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFNLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQUssQ0FBbUIsQ0FBQyxFQUFDLFlBQVksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBYyxDQUFtQixDQUFDLEVBQUMscUJBQXFCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBVSxDQUFxQixDQUFDLEVBQUMsc0VBQXNFLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQU8sQ0FBaUIsQ0FBQyxFQUFDLFdBQVcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBVSxDQUFtQixDQUFDLEVBQUMsb0RBQW9EO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTJCLENBQXFCLENBQUMsRUFBQyxPQUFPLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFpQixDQUFxQixDQUFDLEVBQUMsMkNBQTJDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBZSxDQUFxQixDQUFDLEVBQUMsMkdBQTJHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXlGLENBQXFCLENBQUMsRUFBQyxrQ0FBa0MsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFPLENBQXFCLENBQUMsRUFBQywrTEFBK0wsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBTSxDQUFtQixDQUFDLEVBQUMsNEJBQTRCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBaUIsQ0FBcUIsQ0FBQyxFQUFDLCtLQUErSztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDSyxFQUFFO01BQUNzQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUsbUZBQW1GO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQyxzQ0FBc0MsZUFBQyxJQUFBOUIsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1FBQUF1QixRQUFBLEVBQUU7TUFBd0QsQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxFQUFFO0lBQStELENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2EsS0FBSztNQUFBYSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNpQixLQUFLO1FBQUFTLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNnQixFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFPLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNnQixFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFPLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNnQixFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFlLENBQWlCLENBQUM7UUFBQSxDQUFnQjtNQUFDLENBQW1CLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNjLEtBQUs7UUFBQVksUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFvQyxDQUFxQixDQUFDLEVBQUMsT0FBTztVQUFBLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQVUsQ0FBcUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsR0FBRSxvQ0FBb0MsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO2NBQUF1QixRQUFBLEVBQUU7WUFBMEIsQ0FBaUIsQ0FBQyxFQUFDLG1EQUFtRCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQTZCLENBQXFCLENBQUM7VUFBQSxDQUFnQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsR0FBRSxxQkFBcUIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFTLENBQXFCLENBQUMsRUFBQyx3Q0FBd0M7VUFBQSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsR0FBRSxXQUFXLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQTBCLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQVMsQ0FBbUIsQ0FBQyxFQUFDLDJDQUEyQztVQUFBLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxHQUFFLGtEQUFrRCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7Y0FBQXVCLFFBQUEsRUFBRTtZQUFVLENBQWlCLENBQUMsRUFBQyxjQUFjO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFrQixDQUFtQixDQUFDLEVBQUMsWUFBWTtVQUFBLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFPLENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQW1CLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQW9CLENBQW1CLENBQUMsRUFBQyxHQUFHO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBNEMsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEdBQUUsVUFBVSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQUssQ0FBcUIsQ0FBQyxFQUFDLDZCQUE2QixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQUssQ0FBcUIsQ0FBQztVQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDWSxNQUFNO2NBQUFjLFFBQUEsR0FBRSxnQkFBZ0IsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO2dCQUFBdUIsUUFBQSxFQUFFO2NBQVksQ0FBaUIsQ0FBQyxFQUFDLGNBQWM7WUFBQSxDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFhLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQW9CLENBQW1CLENBQUMsRUFBQyxhQUFhLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQU8sQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUF1QyxDQUFxQixDQUFDLEVBQUMsMEJBQTBCO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEdBQUUsbURBQW1ELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtjQUFBdUIsUUFBQSxFQUFFO1lBQTJDLENBQWlCLENBQUM7VUFBQSxDQUFnQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsR0FBRSxtQkFBbUIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUEwQixDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFRLENBQW1CLENBQUMsRUFBQyxjQUFjO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQXFCLENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQWEsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBdUIsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7VUFBQSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUErQyxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsR0FBRSw0Q0FBNEMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFVLENBQXFCLENBQUMsRUFBQyxPQUFPO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQU8sQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBYSxDQUFtQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQXlCLENBQXFCLENBQUMsRUFBQyxjQUFjO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBc0QsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEdBQUUsTUFBTSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFhLENBQW1CLENBQUMsRUFBQyx5QkFBeUI7VUFBQSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBZ0IsQ0FBcUIsQ0FBQyxFQUFDLDJCQUEyQjtVQUFBLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQXdFLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxHQUFFLFNBQVMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFXLENBQXFCLENBQUMsRUFBQyw0Q0FBNEM7VUFBQSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBTyxDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFnQixDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFjLENBQW1CLENBQUMsRUFBQyw0QkFBNEIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFhLENBQXFCLENBQUMsRUFBQyxtQkFBbUI7VUFBQSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFnRyxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQztNQUFBLENBQW1CLENBQUM7SUFBQSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNNLEVBQUU7TUFBQ3FCLEVBQUUsRUFBQyxTQUFTO01BQUMsYUFBVSxrSEFBa0g7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFTLENBQUUsQ0FBQyxFQUFDLHFEQUFxRCxlQUFDLElBQUE5QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUF1RSxDQUFpQixDQUFDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLEdBQUUsOE1BQThNLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQW1CLENBQWlCLENBQUMsRUFBQywwRkFBMEY7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNtQixFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFpRCxDQUFxQixDQUFDLEVBQUMsZ0ZBQWdGLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBYSxDQUFxQixDQUFDLEVBQUMsb1ZBQW9WO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTBDLENBQXFCLENBQUMsRUFBQywySkFBMkosZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFnQixDQUFxQixDQUFDLEVBQUMscUJBQXFCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQUssQ0FBaUIsQ0FBQyxFQUFDLHNGQUFzRjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQXFCLENBQXFCLENBQUMsRUFBQyw4QkFBOEIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBWSxDQUFtQixDQUFDLEVBQUMsZ0hBQWdILGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBSyxDQUFxQixDQUFDLEVBQUMsYUFBYSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFZLENBQW1CLENBQUMsRUFBQyxnREFBZ0QsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFzQixDQUFxQixDQUFDLEVBQUMseUJBQXlCO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxHQUFFLGlGQUFpRixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUErQyxDQUFtQixDQUFDLEVBQUMscUhBQXFIO01BQUEsQ0FBaUI7SUFBQyxDQUFlLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUE4RCxDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFtQixDQUFtQixDQUFDLEVBQUMsbUJBQW1CLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBUyxDQUFxQixDQUFDLEVBQUMsdUJBQXVCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQU8sQ0FBaUIsQ0FBQyxFQUFDLFNBQVMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFTLENBQXFCLENBQUMsRUFBQyxzRUFBc0UsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBZSxDQUFtQixDQUFDLEVBQUMsMkNBQTJDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBSSxDQUFxQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUF3SCxDQUFpQixDQUFDLEVBQUMsVUFBVSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQStCLENBQXFCLENBQUMsRUFBQyxrQkFBa0IsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBdUIsQ0FBbUIsQ0FBQyxFQUFDLHdKQUF3SixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFlLENBQW1CLENBQUMsRUFBQyxNQUFNLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBSSxDQUFxQixDQUFDLEVBQUMsOEVBQThFLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBa0IsQ0FBcUIsQ0FBQyxFQUFDLDRIQUE0SDtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUF5RCxDQUFxQixDQUFDLEVBQUMsZ0RBQWdELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBa0IsQ0FBcUIsQ0FBQyxFQUFDLCtNQUErTSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFpQixDQUFtQixDQUFDLEVBQUMsdUJBQXVCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQW1ELENBQW1CLENBQUMsRUFBQyw2QkFBNkIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBWSxDQUFtQixDQUFDLEVBQUMsNklBQTZJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBUyxDQUFxQixDQUFDLEVBQUMscUNBQXFDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQWlCLENBQW1CLENBQUMsRUFBQyxvQkFBb0IsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBTSxDQUFtQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUFrQixDQUFpQixDQUFDLEVBQUMsUUFBUSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFvQyxDQUFtQixDQUFDLEVBQUMsaUJBQWlCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQWUsQ0FBbUIsQ0FBQyxFQUFDLHNFQUFzRSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQWlCLENBQXFCLENBQUMsRUFBQyx5RUFBeUUsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBbUIsQ0FBbUIsQ0FBQyxFQUFDLCtCQUErQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVEsQ0FBcUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBUyxDQUFtQixDQUFDLEVBQUMsYUFBYSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFlLENBQW1CLENBQUMsRUFBQyxPQUFPLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQWMsQ0FBbUIsQ0FBQyxFQUFDLGVBQWUsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFxQixDQUFxQixDQUFDLEVBQUMsK0VBQStFLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBaUMsQ0FBcUIsQ0FBQyxFQUFDLHFCQUFxQjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDc0IsRUFBRSxFQUFDLE9BQU87TUFBQyxhQUFVLHFGQUFxRjtNQUFBRCxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMsOEVBQThFLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQW9CLENBQWlCLENBQUM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNVLENBQUM7TUFBQWdCLFFBQUEsR0FBRSx3REFBd0QsZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsR0FBRSxnQ0FBZ0MsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBTSxDQUFpQixDQUFDLEVBQUMsNEJBQTRCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQTBCLENBQWlCLENBQUMsRUFBQyxRQUFRO01BQUEsQ0FBcUIsQ0FBQyxFQUFDLDBGQUEwRixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQTJCLENBQXFCLENBQUMsRUFBQyxHQUFHO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDbUIsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBNEMsQ0FBcUIsQ0FBQyxFQUFDLHFEQUFxRCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQW1CLENBQXFCLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBa0IsQ0FBcUIsQ0FBQyxFQUFDLDJCQUEyQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFzQixDQUFpQixDQUFDLEVBQUMsK0VBQStFLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQVMsQ0FBbUIsQ0FBQyxFQUFDLG1FQUFtRSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTBCLENBQXFCLENBQUMsRUFBQyxxSkFBcUosZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUErQixDQUFxQixDQUFDLEVBQUMsNkVBQTZFLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBOEIsQ0FBcUIsQ0FBQyxFQUFDLDBFQUEwRSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXNJLENBQXFCLENBQUMsRUFBQywyQkFBMkI7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBeUIsQ0FBcUIsQ0FBQyxFQUFDLGtFQUFrRSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWdCLENBQXFCLENBQUMsRUFBQyxnSUFBZ0ksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFvQixDQUFxQixDQUFDLEVBQUMsaUlBQWlJO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNVLENBQUM7TUFBQWdCLFFBQUEsR0FBRSw0QkFBNEIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFJLENBQXFCLENBQUMsRUFBQyx1Q0FBdUMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsR0FBRSx1REFBdUQsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBTSxDQUFpQixDQUFDLEVBQUMsdUNBQXVDO01BQUEsQ0FBcUIsQ0FBQyxFQUFDLHlCQUF5QixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUFPLENBQWlCLENBQUMsRUFBQywrREFBK0QsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1FBQUF1QixRQUFBLEVBQUU7TUFBVyxDQUFpQixDQUFDLEVBQUMsa0NBQWtDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQVUsQ0FBaUIsQ0FBQyxFQUFDLHlIQUF5SCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQUssQ0FBcUIsQ0FBQyxFQUFDLHlFQUF5RTtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDc0IsRUFBRSxFQUFDLE9BQU87TUFBQyxhQUFVLDhFQUE4RTtNQUFBRCxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMsbUVBQW1FLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQW9CLENBQWlCLENBQUM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNVLENBQUM7TUFBQWdCLFFBQUEsR0FBRSxrREFBa0QsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUEwQixDQUFxQixDQUFDLEVBQUMseUdBQXlHO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUyxFQUFFO01BQUFpQixRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBdUIsQ0FBcUIsQ0FBQyxFQUFDLG1EQUFtRCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUF5QixDQUFtQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQVksQ0FBcUIsQ0FBQyxFQUFDLHFFQUFxRSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUEyQixDQUFtQixDQUFDLEVBQUMsUUFBUSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFJLENBQW1CLENBQUMsRUFBQyxrREFBa0QsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBaUIsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsK0dBQStHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXdCLENBQXFCLENBQUMsRUFBQyw0RkFBNEYsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXlCLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQW1CLENBQW1CLENBQUMsRUFBQyx3RkFBd0Y7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBaUIsQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBaUIsQ0FBbUIsQ0FBQyxFQUFDLGtCQUFrQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFpQixDQUFtQixDQUFDLEVBQUMsNENBQTRDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEdBQUUsWUFBWSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7WUFBQXVCLFFBQUEsRUFBRTtVQUFzQixDQUFpQixDQUFDLEVBQUMsb0JBQW9CO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLG9GQUFvRixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTBFLENBQXFCLENBQUMsRUFBQyxvRkFBb0YsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUErQixDQUFxQixDQUFDLEVBQUMsd0dBQXdHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXdDLENBQXFCLENBQUMsRUFBQyxrR0FBa0csZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFZLENBQXFCLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQWtCLENBQW1CLENBQUMsRUFBQyxnQkFBZ0IsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBSyxDQUFpQixDQUFDLEVBQUMsaU9BQWlPO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXdELENBQXFCLENBQUMsRUFBQyxxR0FBcUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFtRixDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUMsRUFBQyw4TEFBOEwsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFNLENBQXFCLENBQUMsRUFBQyxnSUFBZ0k7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBNkIsQ0FBcUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUEyRSxDQUFxQixDQUFDLEVBQUMsOEVBQThFLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQVMsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBMkIsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsR0FBRSwwRUFBMEUsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1lBQUF1QixRQUFBLEVBQUU7VUFBTSxDQUFpQixDQUFDLEVBQUMsR0FBRztRQUFBLENBQXFCLENBQUMsRUFBQyx3SkFBd0osZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBVyxDQUFpQixDQUFDLEVBQUMsMkVBQTJFLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBSyxDQUFxQixDQUFDLEVBQUMsK0ZBQStGO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXNCLENBQXFCLENBQUMsRUFBQyx3Q0FBd0MsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFzQyxDQUFxQixDQUFDLEVBQUMsaUNBQWlDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLHdDQUF3QyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFhLENBQWlCLENBQUMsRUFBQyxxSEFBcUgsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFtRSxDQUFxQixDQUFDLEVBQUMseUNBQXlDO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTZCLENBQXFCLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBWSxDQUFxQixDQUFDLEVBQUMsd0pBQXdKO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQW9FLENBQXFCLENBQUMsRUFBQyxPQUFPLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQVEsQ0FBaUIsQ0FBQyxFQUFDLGVBQWUsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBTSxDQUFtQixDQUFDLEVBQUMsV0FBVyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQyx5QkFBeUIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBYyxDQUFtQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWlDLENBQXFCLENBQUMsRUFBQyxnRkFBZ0YsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFzQyxDQUFxQixDQUFDLEVBQUMsa0VBQWtFLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQVMsQ0FBaUIsQ0FBQyxFQUFDLG9FQUFvRTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQXNCLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQU8sQ0FBaUIsQ0FBQyxFQUFDLCtJQUErSSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQXFDLENBQXFCLENBQUMsRUFBQyxpREFBaUQsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFNLENBQXFCLENBQUMsRUFBQyw2SEFBNkgsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUF5QixDQUFxQixDQUFDLEVBQUMsb0hBQW9ILGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBeUQsQ0FBcUIsQ0FBQyxFQUFDLDZCQUE2QixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUFXLENBQWlCLENBQUMsRUFBQyw2RkFBNkYsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFLLENBQXFCLENBQUMsRUFBQyxvQkFBb0IsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1FBQUF1QixRQUFBLEVBQUU7TUFBUSxDQUFpQixDQUFDLEVBQUMsNEdBQTRHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBSyxDQUFxQixDQUFDLEVBQUMsNEJBQTRCO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDSyxFQUFFO01BQUNzQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUseUNBQXlDO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQyw0Q0FBNEM7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNNLEVBQUU7TUFBQ3FCLEVBQUUsRUFBQyw4RkFBOEY7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUE4RixDQUFFLENBQUMsRUFBQyxvRUFBb0UsZUFBQyxJQUFBOUIsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBZ0MsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNhLEtBQUs7TUFBQWEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDaUIsS0FBSztRQUFBUyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBb0QsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQTZCLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNnQixFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFxQixDQUFpQixDQUFDO1FBQUEsQ0FBZ0I7TUFBQyxDQUFtQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDYyxLQUFLO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsR0FBRSwrQ0FBK0MsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFNLENBQXFCLENBQUMsRUFBQyx5QkFBeUI7VUFBQSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBeUMsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBb0IsQ0FBbUI7VUFBQyxDQUFnQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsR0FBRSx5QkFBeUIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBUSxDQUFtQixDQUFDLEVBQUMsNkNBQTZDO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQXlDLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQXVCLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBbUUsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQXlDLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQWEsQ0FBbUI7VUFBQyxDQUFnQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsR0FBRSw2QkFBNkIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBa0IsQ0FBbUIsQ0FBQyxFQUFDLHdCQUF3QjtVQUFBLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUEwRCxDQUFtQjtVQUFDLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFvQixDQUFtQjtVQUFDLENBQWdCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQTJELENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUEwRCxDQUFtQjtVQUFDLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFjLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBNEQsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQXlELENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQXFCLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBOEQsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQTBDLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQVMsQ0FBbUI7VUFBQyxDQUFnQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQztNQUFBLENBQW1CLENBQUM7SUFBQSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNNLEVBQUU7TUFBQ3FCLEVBQUUsRUFBQywwREFBMEQ7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUEwRCxDQUFFLENBQUMsRUFBQyw0REFBNEQ7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNhLEtBQUs7TUFBQWEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDaUIsS0FBSztRQUFBUyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBZSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBdUIsQ0FBaUIsQ0FBQztRQUFBLENBQWdCO01BQUMsQ0FBbUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2MsS0FBSztRQUFBWSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEdBQUUsNEJBQTRCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQVksQ0FBbUIsQ0FBQyxFQUFDLHFCQUFxQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQUssQ0FBcUIsQ0FBQyxFQUFDLFdBQVcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBVyxDQUFtQixDQUFDO1VBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEdBQUUsMkNBQTJDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQVMsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBVyxDQUFtQixDQUFDLEVBQUMsUUFBUSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFXLENBQW1CLENBQUM7VUFBQSxDQUFnQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFrRyxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFzTSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUE4RixDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsR0FBRSx3REFBd0QsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBSyxDQUFtQixDQUFDLEVBQUMsa0NBQWtDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQWdCLENBQW1CLENBQUMsRUFBQyxpQkFBaUI7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUErRSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsR0FBRSxnRUFBZ0UsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBYyxDQUFtQixDQUFDLEVBQUMsdUdBQXVHO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBb0QsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEdBQUUseUtBQXlLLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQVksQ0FBbUIsQ0FBQztVQUFBLENBQWdCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQTZFLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxHQUFFLDZCQUE2QixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFNLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQWMsQ0FBbUIsQ0FBQyxFQUFDLGlIQUFpSDtVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQXFHLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxHQUFFLDhGQUE4RixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQXNFLENBQXFCLENBQUMsRUFBQyxtQkFBbUI7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUF1RSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUE0RyxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQztNQUFBLENBQW1CLENBQUM7SUFBQSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNLLEVBQUU7TUFBQ3NCLEVBQUUsRUFBQyxPQUFPO01BQUMsYUFBVSxtQ0FBbUM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLHNDQUFzQztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ21CLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQW1ILENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLGdDQUFnQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyw4TEFBOEw7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEdBQUUsNkNBQTZDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtZQUFBdUIsUUFBQSxFQUFFO1VBQVksQ0FBaUIsQ0FBQyxFQUFDLGVBQWUsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1lBQUF1QixRQUFBLEVBQUU7VUFBb0IsQ0FBaUIsQ0FBQyxFQUFDLHFEQUFxRDtRQUFBLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLG9KQUFvSjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUErRyxDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFXLENBQWlCLENBQUMsRUFBQyw4TUFBOE07TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEdBQUUsd0JBQXdCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBd0IsUUFBQSxFQUFFO1VBQU0sQ0FBbUIsQ0FBQyxFQUFDLDBGQUEwRjtRQUFBLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLG1NQUFtTTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsR0FBRSwwQkFBMEIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1lBQUF1QixRQUFBLEVBQUU7VUFBTSxDQUFpQixDQUFDLEVBQUMscUZBQXFGO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBVyxDQUFpQixDQUFDLEVBQUMsOElBQThJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQXNCLENBQWlCLENBQUMsRUFBQywwRUFBMEU7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDc0IsRUFBRSxFQUFDLE9BQU87TUFBQyxhQUFVLGtCQUFrQjtNQUFBRCxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMsbUJBQW1CO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDbUIsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBeUIsQ0FBcUIsQ0FBQyxFQUFDLHlGQUF5RixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFzQixDQUFtQixDQUFDLEVBQUMsMEVBQTBFO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXNDLENBQXFCLENBQUMsRUFBQyxzR0FBc0csZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBUyxDQUFpQixDQUFDLEVBQUMsNExBQTRMO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWlFLENBQXFCLENBQUMsRUFBQywrSkFBK0osZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBVyxDQUFpQixDQUFDLEVBQUMsb0hBQW9IO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDO0VBQUEsQ0FBRSxDQUFDO0FBQzFweEQ7QUFDZSxTQUFTSSxVQUFVQSxDQUFDL0IsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFO0VBQzdDLE1BQU07SUFBQ2dDLE9BQU8sRUFBRUM7RUFBUyxDQUFDLEdBQUc7SUFDM0IsR0FBRyxJQUFBWiw2QkFBa0IsRUFBQyxDQUFDO0lBQ3ZCLEdBQUdyQixLQUFLLENBQUNzQjtFQUNYLENBQUM7RUFDRCxPQUFPVyxTQUFTLGdCQUFHLElBQUFuQyxXQUFBLENBQUErQixHQUFBLEVBQUNJLFNBQVM7SUFBQSxHQUFLakMsS0FBSztJQUFBMkIsUUFBQSxlQUFFLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM5QixpQkFBaUI7TUFBQSxHQUFLQztJQUFLLENBQUc7RUFBQyxDQUFXLENBQUMsR0FBR0QsaUJBQWlCLENBQUNDLEtBQUssQ0FBQztBQUNsSDtBQUFDa0MsRUFBQSxHQU51QkgsVUFBVTtBQU9sQyxTQUFTUCxvQkFBb0JBLENBQUNJLEVBQUUsRUFBRU8sU0FBUyxFQUFFQyxLQUFLLEVBQUU7RUFDbEQsTUFBTSxJQUFJQyxLQUFLLENBQUMsV0FBVyxJQUFJRixTQUFTLEdBQUcsV0FBVyxHQUFHLFFBQVEsQ0FBQyxHQUFHLElBQUksR0FBR1AsRUFBRSxHQUFHLG9FQUFvRSxJQUFJUSxLQUFLLEdBQUcscUNBQXFDLEdBQUdBLEtBQUssR0FBRyx3REFBd0QsR0FBRyxFQUFFLENBQUMsQ0FBQztBQUNsUjtBQUFDLElBQUFGLEVBQUE7QUFBQUksWUFBQSxDQUFBSixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}