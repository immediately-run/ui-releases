var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      h3: "h3",
      li: "li",
      p: "p",
      strong: "strong",
      table: "table",
      tbody: "tbody",
      td: "td",
      th: "th",
      thead: "thead",
      tr: "tr",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "document_navigator-implementation-status",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "document_navigator-implementation-status"
      }), "DOCUMENT_NAVIGATOR — implementation status"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Status:"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Part A implemented (R3-446); Part B's contract established + build landed (R3-447)"
      }), " ·\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Updated:"
      }), " 2026-09-22"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["This document is the single implementation-status source for\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "docs/specs/DOCUMENT_NAVIGATOR_SPEC.md"
      }), "; where they disagree, this document governs."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "part-a-the-authoring-vocabulary-shipped-2026-08-28",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "part-a-the-authoring-vocabulary-shipped-2026-08-28"
      }), "Part A — the authoring vocabulary (shipped 2026-08-28)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/app/vocabulary.ts"
        }), " — the pure derivation: every catalog entry with its typed\nattributes (base + per-variant, variant-labelled) and a usage snippet built per the\nspec's §1.1 per-shape rules (variant discriminators, child rules, the Show*\nthresholds, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "literal-array"
        }), " placeholders)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/app/VocabularySection.tsx"
        }), " — the panel section: collapsible per entry, a\nwidgets/display/all filter, and a guarded copy affordance."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["Wired into ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/app/WorkbookPanel.tsx"
        }), "; the report header button is now\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Workbook"
        }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Close workbook"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/App.tsx"
        }), ")."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "gate-coverage",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "gate-coverage"
      }), "Gate coverage"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Gate"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Test"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-A1"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/app/vocabulary.test.ts"
            }), " — enumerates ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "componentNames"
            }), ", never a literal list"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-A2"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["same — widget/container markers; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "Chart"
            }), "'s discriminator and its per-variant ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "x"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "y"
            }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "histogram.value"
            })]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-A3"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["same — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "every"
            }), " snippet parsed by the real ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "parseTemplate"
            }), " and run through the real ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "validateTemplate"
            }), ", asserting zero error diagnostics, one test per catalog entry (19 of them) so a future entry cannot regress silently"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-A4"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["same — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "widgets"
            }), " = ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "WIDGETS"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "components"
            }), " = its exact complement, unset = all"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-A5"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/app/VocabularySection.test.tsx"
            }), " — static render with no host transport"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-A6"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["the header strings in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/App.tsx"
            })]
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "All 19 snippets validate on the first implementation"
      }), " — the spec's §1.1 per-shape\nrules were sufficient, including the seven entries the adversarial pass identified as\nimpossible under the draft's attribute-only recipe (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "Chart"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "Map"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "Facets"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "Params"
      }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ShowAbove"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ShowBelow"
      }), ", and the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "literal-array"
      }), " carriers)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "also-landed-with-part-a",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "also-landed-with-part-a"
      }), "Also landed with Part A"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "A platform guard against the DN-R5 hazard"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/app/platformGuards.test.ts"
        }), "): no\nmodule may ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "statically value-import"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "@immediately-run/sdk"
        }), " or ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "…/tasks"
        }), ", which\nregister a host listener at module load and throw with no transport. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "import type"
        }), ",\nthe ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "mounts"
        }), " subpath and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "await import()"
        }), " are all correctly not matched — proven by\nfault injection over five cases, not by inspection. This guard exists ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "before"
        }), " Part B\nneeds it, so the mistake cannot be made later."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["A lint-red ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "main"
          }), " fixed"]
        }), " — R3-427 shipped an unused-binding error because the\nverification command piped ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npm run lint"
        }), " into ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "tail"
        }), ", and a pipeline's exit status is\nthe ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "last"
        }), " command's, so the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "&&"
        }), " chain continued past a failing gate. Fixed here, and\nthe lesson is worth keeping: ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["never pipe a gate into ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "tail"
          }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "head"
          }), " in a chained\nverification"]
        }), " — capture to a file and check the exit code."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "part-b-the-edit-affordance-r3-447-the-contract-established-the-build-landed",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "part-b-the-edit-affordance-r3-447-the-contract-established-the-build-landed"
      }), "Part B — the edit affordance (R3-447: the contract established, the build landed)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Phase 1 — the preconditions, established 2026-09-22"
      }), " (the worker-VM agent venue:\ncurrent-main dev host + staging backend/Firestore, the real repo-load dispatch, a\nworkbook corpus repo dispatched by URL; browser-driven observation off the live\nchannel, per the spec's rule — an injected port cannot falsify a question about the\nhost):"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "#"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Answer (with how it was established)"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "P1"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["A ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "type: 'content'"
            }), " dispatch mount carries ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "id"
            }), " in the ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
              children: ["universal ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                children: "scheme:locator"
              }), " form"]
            }), " — observed live as ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "content:immediately-run-worker/r3-447-workbook"
            }), " (the frame's own mount service, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "getMounts()"
            }), "). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "capFile"
            }), "'s ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "mountId"
            }), " is therefore addressed with the descriptor's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "id"
            }), " verbatim; the host's grant lookup is an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "exact match"
            }), " on it (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "taskInvocation.ts"
            }), " → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "grantFor"
            }), "), and no fallback is documented — a path-shaped or bare ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "mountId"
            }), " would refuse ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "forbidden"
            }), ", which is why the door fails closed on an id-less mount rather than making a doomed call. The unqualified form is not what the host mints."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "P2"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["The mount ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
              children: ["reports ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                children: "mode"
              })]
            }), " — observed live as ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "'rw'"
            }), " on the repo-load dispatch (writes land in the corpus mount; proposing back to the source repo stays unwired, the RCD §5.1 disclosure) — and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                children: "rules: null"
              })
            }), " (no rules). The editability derivation therefore keys on the ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
              children: ["positive ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                children: "rw"
              }), " check"]
            }), " R-EFE-1 prescribes; the draft's \"absent ⇒ writable\" inversion (DN-R2) is dead, and the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "subtree"
            }), "-comparability question (DN-R3) dissolves — there are no rules to compare. This repo's dispatch fixtures stamp ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "mode: 'ro'"
            }), "; the live repo-load mount stamps ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "rw"
            }), " — the fixtures model the task-invocation shape, not this one."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "P3"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Both channels are real and shaped as §4.2 handles them."
            }), " Documented half (the host's task contract, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "taskContracts.ts"
            }), "): ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "edit-file"
            }), " returns ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "{ saved: boolean }"
            }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "saved: false"
            }), " is the result-carried refusal, and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "invokeTask"
            }), " throws machine ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: ".code"
            }), " rejections (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "cancelled"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "forbidden"
            }), ", …). Live half (a real invocation from the dispatched frame): exercised by the gates below — it required P4's grant first, which is the sequencing finding, not a gap."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "P4"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "NO — and deliberately so."
            }), " The build-default binding (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "site-main"
            }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "registry/defaults.ts"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "task.open-workbook"
            }), ") omitted ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "task:invoke"
            }), " with a comment naming this milestone as the moment to add it; the frame's live grant-filtered catalog carried no task verb. The grant half is site-main's R3-447 registry diff (this milestone); the manifest ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "invokes"
            }), " declaration (this repo) is the self-restriction half — G-DN-B10 asserts both."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "P5"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "The dispatched shape is reachable and renders."
            }), " Driven live: a workbook corpus repo (the Meridian seed as real files + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "immediately.run.json"
            }), " marker ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "opensWith: open-workbook@1.0"
            }), ") dispatched by URL through the real repo-load branch — stock reckoner from the registry binding rendered the report (nav, growth-composition sections, the workbook panel). The honest sequencing notes: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "no workbook corpus repo existed"
            }), " (the corpus is content work, not platform work — the spike's corpus is temporary), and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "no user-facing caller invokes the task"
            }), " (the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "opensWith"
            }), " marker's only reader is the URL route; the folder-trigger caller is R3-267) — the URL route is the reachable shape."]
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Phase 2 — built"
      }), " (the same item): the inspector's per-row edit door (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ValueInspector"
      }), "),\nthe §4.3 path gate (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "documentPaths"
      }), "), the door itself (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "useEditFile"
      }), " — lazy import, both\nrefusal channels, the session-scoped latch, the host-less no-op, the §4.4 staleness\nsignal), the staleness notice + reload (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "DocumentChangedNotice"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "useReport.reload"
      }), "),\nthe ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "invokes"
      }), " declaration, and site-main's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "task:invoke"
      }), " grant. Q6 (the consumer\ninspector's door) resolves per the item's own Phase-2 surface (\"the inspector's formula\nand test rows\"); Q3 (reload vs change-watch) resolves to the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "reload affordance"
      }), " — a\nchange-watch needs an fs watch the task-delegated export does not carry\n(SPACES_UI §6.6 / R3-732's seam)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "gate-coverage-1",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "gate-coverage-1"
      }), "Gate coverage"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Gate"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Test"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-B1"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "dispatch.test.ts"
            }), " — the ok resolution carries the live mount (id/mode provenance); the live descriptor read on the venue (above)"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-B2"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "useEditFile.test.ts"
            }), " — writability by the positive ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "rw"
            }), " check (ro/absent are not doors)"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-B3"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "documentPaths.test.ts"
            }), " — segment-boundary traversal refusal; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "useEditFile.test.ts"
            }), " — a failing path never constructs the delegation"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-B4"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "useEditFile.test.ts"
            }), " — the call addresses the descriptor id (universal form); an id-less mount is not a door (fail-closed — the host's exact-match grant lookup has no documented fallback); the live invocation gate below"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-B5"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "useEditFile.test.ts"
            }), " — both channels: thrown ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "cancelled"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "forbidden"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "timeout"
            }), ", the result-carried ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "{saved:false}"
            }), " refusal, the host-less no-op; the live gate below"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-B6"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "ValueInspector.test.tsx"
            }), " — absent unless writable (per row), present beside both anchors, the disclosure at the button, the click hands the row's path; the live gate below"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-B7"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "documentPaths.test.ts"
            }), " — traversal-shaped ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "manifest.worksheets"
            }), " paths never reach ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "capFile"
            })]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-B8"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["the pre-existing ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "platformGuards.test.ts"
            }), " (no static tasks import) + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "useEditFile.test.ts"
            }), "'s host-less no-op case"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-B9"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "DocumentChangedNotice.test.tsx"
            }), " + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "useReport.test.tsx"
            }), " (the reload); the live gate below"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-B10"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "package.json"
            }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "invokes"
            }), " (this repo) + site-main's registry diff and its exact-list test"]
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["The host-exercised halves (P1–P4's live legs: a real ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "edit-file"
        }), " invocation from the\ndispatched frame — the door visible on the dispatched shape, the overlay opening, both\nrefusal channels observed on the real gate, the staleness affordance after a save) run\non the venue against the merged mains before R3-447 archives; the unit halves above are\nin-repo and green."]
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "open-residuals",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "open-residuals"
      }), "Open residuals"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "edit-table"
        }), " is now specified"]
      }), " (2026-08-29) — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "EDIT_TABLE_TASK_SPEC.mdx"
      }), " in the docs\nrepo, proposal rev 2 after an adversarial pass. It is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "blocked on P1–P5 above plus two\nof its own"
      }), " (P6: task-delegation mounts are announced with no ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "mode"
      }), ", so the read-only\nrule is unimplementable; P7: Reckoner has no fs watch, so the autosave safety argument\nhas no consumer). R3-447's host spike therefore unblocks both surfaces, not just Part B —\nworth knowing before scoping it. The review also confirmed the seed-vs-mount wall applies\nto fixtures exactly as it does to worksheets: on the bundled-seed path there is no file\nto delegate, only a string in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/seed/"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Spec §6 (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "edit-table"
      }), ", open-at-line, Delta B, click-to-insert, own-source editing) and\n§11 Q1–Q7 — including the two the review surfaced as real decisions rather than\ndeferrals: whether the consumer-visible inspector carries an authoring door (Q6), and\nthe template-file edit row without which \"copy the snippet, open the template\" has no\ndoor (Q7)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "the-live-gates-2026-09-22-the-venue-run-against-both-merged-mains-two-pass-one-is-a-finding",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-live-gates-2026-09-22-the-venue-run-against-both-merged-mains-two-pass-one-is-a-finding"
      }), "The live gates (2026-09-22, the venue run against BOTH merged mains) — two pass, one is a FINDING"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Driven on the worker-VM venue with site-main at 60ddd0a and reckoner@main at 2925fa4\n(both PRs merged), the corpus dispatched by URL:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "G-DN-B6 live: PASS."
        }), " The door renders beside both ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "file:line"
        }), " anchors\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "worksheets/review.sheet.js:3"
        }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ":107"
        }), ") on the dispatched shape, with the RCD\n§5.1 disclosure on the button title AND the visible note line."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "G-DN-B5 live (the forbidden channel): PASS."
        }), " A refused invocation draws exactly\none plain message (\"This document can't be edited here.\") and latches the door off —\nobserved live, matching §4.2 to the letter."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "G-DN-B4 live (the successful invocation): BLOCKED BY A FINDING, not a bug in this\nrepo's half."
        }), " The invocation refuses ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "forbidden — 'protocol-task.invoke' requires the 'task:invoke' capability; this app's grant does not hold it"
        }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "despite\nsite-main#584 being merged and the venue serving it"
        }), ". Root cause (code + live):\nthe URL repo-load dispatch resolves the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "viewer's repo"
        }), " from the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "task.open-workbook"
        }), "\nbinding, but the frame's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "grant"
        }), " is the preview/stage grant — the registry row's\ncapabilities never flow to the repo-load-dispatched frame. The task-invocation shape\n(where the binding's grant does apply) is unreachable twice over: no user-facing\ncaller exists (R3-267), and this repo's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "dispatch.ts"
        }), " v1 deliberately resolves only\nthe repo-load shape. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The affordance is therefore unreachable on both dispatch\nshapes — DN-R12's failure mode reborn at the invocation layer."
        }), " The fix is a\ndesign decision the owner owns (the repo-load dispatch minting the viewer's grant\nfrom the task binding; or the preview grant widening; or shipping the task-shape\ncaller); recorded in R3-447's roadmap status, which stays ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "in-progress, unarchived"
        }), "."]
      }), "\n"]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/status/DOCUMENT_NAVIGATOR_STATUS.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJjb2RlIiwiZW0iLCJoMSIsImgyIiwiaDMiLCJsaSIsInAiLCJzdHJvbmciLCJ0YWJsZSIsInRib2R5IiwidGQiLCJ0aCIsInRoZWFkIiwidHIiLCJ1bCIsIl9wcm92aWRlQ29tcG9uZW50cyIsImNvbXBvbmVudHMiLCJIZWFkaW5nQW5jaG9yIiwiX21pc3NpbmdNZHhSZWZlcmVuY2UiLCJqc3hzIiwiRnJhZ21lbnQiLCJjaGlsZHJlbiIsImlkIiwianN4IiwiTURYQ29udGVudCIsIndyYXBwZXIiLCJNRFhMYXlvdXQiLCJfYyIsImNvbXBvbmVudCIsInBsYWNlIiwiRXJyb3IiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJET0NVTUVOVF9OQVZJR0FUT1JfU1RBVFVTLm1kIl0sInNvdXJjZXNDb250ZW50IjpbIi8qQGpzeFJ1bnRpbWUgYXV0b21hdGljKi9cbi8qQGpzeEltcG9ydFNvdXJjZSByZWFjdCovXG5pbXBvcnQge3VzZU1EWENvbXBvbmVudHMgYXMgX3Byb3ZpZGVDb21wb25lbnRzfSBmcm9tIFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGsvTURYUHJvdmlkZXJcIjtcbmZ1bmN0aW9uIF9jcmVhdGVNZHhDb250ZW50KHByb3BzKSB7XG4gIGNvbnN0IF9jb21wb25lbnRzID0ge1xuICAgIGNvZGU6IFwiY29kZVwiLFxuICAgIGVtOiBcImVtXCIsXG4gICAgaDE6IFwiaDFcIixcbiAgICBoMjogXCJoMlwiLFxuICAgIGgzOiBcImgzXCIsXG4gICAgbGk6IFwibGlcIixcbiAgICBwOiBcInBcIixcbiAgICBzdHJvbmc6IFwic3Ryb25nXCIsXG4gICAgdGFibGU6IFwidGFibGVcIixcbiAgICB0Ym9keTogXCJ0Ym9keVwiLFxuICAgIHRkOiBcInRkXCIsXG4gICAgdGg6IFwidGhcIixcbiAgICB0aGVhZDogXCJ0aGVhZFwiLFxuICAgIHRyOiBcInRyXCIsXG4gICAgdWw6IFwidWxcIixcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH0sIHtIZWFkaW5nQW5jaG9yfSA9IF9jb21wb25lbnRzO1xuICBpZiAoIUhlYWRpbmdBbmNob3IpIF9taXNzaW5nTWR4UmVmZXJlbmNlKFwiSGVhZGluZ0FuY2hvclwiLCB0cnVlKTtcbiAgcmV0dXJuIDw+PF9jb21wb25lbnRzLmgxIGlkPVwiZG9jdW1lbnRfbmF2aWdhdG9yLWltcGxlbWVudGF0aW9uLXN0YXR1c1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwiZG9jdW1lbnRfbmF2aWdhdG9yLWltcGxlbWVudGF0aW9uLXN0YXR1c1wiIC8+e1wiRE9DVU1FTlRfTkFWSUdBVE9SIOKAlCBpbXBsZW1lbnRhdGlvbiBzdGF0dXNcIn08L19jb21wb25lbnRzLmgxPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiU3RhdHVzOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlBhcnQgQSBpbXBsZW1lbnRlZCAoUjMtNDQ2KTsgUGFydCBCJ3MgY29udHJhY3QgZXN0YWJsaXNoZWQgKyBidWlsZCBsYW5kZWQgKFIzLTQ0NylcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgwrdcXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlVwZGF0ZWQ6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIDIwMjYtMDktMjJcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhpcyBkb2N1bWVudCBpcyB0aGUgc2luZ2xlIGltcGxlbWVudGF0aW9uLXN0YXR1cyBzb3VyY2UgZm9yXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZG9jcy9zcGVjcy9ET0NVTUVOVF9OQVZJR0FUT1JfU1BFQy5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCI7IHdoZXJlIHRoZXkgZGlzYWdyZWUsIHRoaXMgZG9jdW1lbnQgZ292ZXJucy5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwicGFydC1hLXRoZS1hdXRob3Jpbmctdm9jYWJ1bGFyeS1zaGlwcGVkLTIwMjYtMDgtMjhcIj48SGVhZGluZ0FuY2hvciBpZD1cInBhcnQtYS10aGUtYXV0aG9yaW5nLXZvY2FidWxhcnktc2hpcHBlZC0yMDI2LTA4LTI4XCIgLz57XCJQYXJ0IEEg4oCUIHRoZSBhdXRob3Jpbmcgdm9jYWJ1bGFyeSAoc2hpcHBlZCAyMDI2LTA4LTI4KVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuY29kZT57XCJzcmMvYXBwL3ZvY2FidWxhcnkudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCB0aGUgcHVyZSBkZXJpdmF0aW9uOiBldmVyeSBjYXRhbG9nIGVudHJ5IHdpdGggaXRzIHR5cGVkXFxuYXR0cmlidXRlcyAoYmFzZSArIHBlci12YXJpYW50LCB2YXJpYW50LWxhYmVsbGVkKSBhbmQgYSB1c2FnZSBzbmlwcGV0IGJ1aWx0IHBlciB0aGVcXG5zcGVjJ3MgwqcxLjEgcGVyLXNoYXBlIHJ1bGVzICh2YXJpYW50IGRpc2NyaW1pbmF0b3JzLCBjaGlsZCBydWxlcywgdGhlIFNob3cqXFxudGhyZXNob2xkcywgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibGl0ZXJhbC1hcnJheVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcGxhY2Vob2xkZXJzKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuY29kZT57XCJzcmMvYXBwL1ZvY2FidWxhcnlTZWN0aW9uLnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIHRoZSBwYW5lbCBzZWN0aW9uOiBjb2xsYXBzaWJsZSBwZXIgZW50cnksIGFcXG53aWRnZXRzL2Rpc3BsYXkvYWxsIGZpbHRlciwgYW5kIGEgZ3VhcmRlZCBjb3B5IGFmZm9yZGFuY2UuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiV2lyZWQgaW50byBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvYXBwL1dvcmtib29rUGFuZWwudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjsgdGhlIHJlcG9ydCBoZWFkZXIgYnV0dG9uIGlzIG5vd1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcIldvcmtib29rXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAvIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkNsb3NlIHdvcmtib29rXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL0FwcC50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwiZ2F0ZS1jb3ZlcmFnZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiZ2F0ZS1jb3ZlcmFnZVwiIC8+e1wiR2F0ZSBjb3ZlcmFnZVwifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnRhYmxlPjxfY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRoPntcIkdhdGVcIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aD57XCJUZXN0XCJ9PC9fY29tcG9uZW50cy50aD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGhlYWQ+PF9jb21wb25lbnRzLnRib2R5PjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiRy1ETi1BMVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcInNyYy9hcHAvdm9jYWJ1bGFyeS50ZXN0LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgZW51bWVyYXRlcyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjb21wb25lbnROYW1lc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIG5ldmVyIGEgbGl0ZXJhbCBsaXN0XCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiRy1ETi1BMlwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcInNhbWUg4oCUIHdpZGdldC9jb250YWluZXIgbWFya2VyczsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQ2hhcnRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiJ3MgZGlzY3JpbWluYXRvciBhbmQgaXRzIHBlci12YXJpYW50IFwifTxfY29tcG9uZW50cy5jb2RlPntcInhcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcInlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFuZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJoaXN0b2dyYW0udmFsdWVcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiRy1ETi1BM1wifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcInNhbWUg4oCUIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZXZlcnlcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgc25pcHBldCBwYXJzZWQgYnkgdGhlIHJlYWwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicGFyc2VUZW1wbGF0ZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYW5kIHJ1biB0aHJvdWdoIHRoZSByZWFsIFwifTxfY29tcG9uZW50cy5jb2RlPntcInZhbGlkYXRlVGVtcGxhdGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBhc3NlcnRpbmcgemVybyBlcnJvciBkaWFnbm9zdGljcywgb25lIHRlc3QgcGVyIGNhdGFsb2cgZW50cnkgKDE5IG9mIHRoZW0pIHNvIGEgZnV0dXJlIGVudHJ5IGNhbm5vdCByZWdyZXNzIHNpbGVudGx5XCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiRy1ETi1BNFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcInNhbWUg4oCUIFwifTxfY29tcG9uZW50cy5jb2RlPntcIndpZGdldHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiID0gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiV0lER0VUU1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNvbXBvbmVudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiID0gaXRzIGV4YWN0IGNvbXBsZW1lbnQsIHVuc2V0ID0gYWxsXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiRy1ETi1BNVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcInNyYy9hcHAvVm9jYWJ1bGFyeVNlY3Rpb24udGVzdC50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCBzdGF0aWMgcmVuZGVyIHdpdGggbm8gaG9zdCB0cmFuc3BvcnRcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJHLUROLUE2XCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1widGhlIGhlYWRlciBzdHJpbmdzIGluIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9BcHAudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRib2R5PjwvX2NvbXBvbmVudHMudGFibGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJBbGwgMTkgc25pcHBldHMgdmFsaWRhdGUgb24gdGhlIGZpcnN0IGltcGxlbWVudGF0aW9uXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCB0aGUgc3BlYydzIMKnMS4xIHBlci1zaGFwZVxcbnJ1bGVzIHdlcmUgc3VmZmljaWVudCwgaW5jbHVkaW5nIHRoZSBzZXZlbiBlbnRyaWVzIHRoZSBhZHZlcnNhcmlhbCBwYXNzIGlkZW50aWZpZWQgYXNcXG5pbXBvc3NpYmxlIHVuZGVyIHRoZSBkcmFmdCdzIGF0dHJpYnV0ZS1vbmx5IHJlY2lwZSAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQ2hhcnRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJNYXBcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJGYWNldHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJQYXJhbXNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcIlNob3dBYm92ZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlNob3dCZWxvd1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGFuZCB0aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibGl0ZXJhbC1hcnJheVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgY2FycmllcnMpLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCJhbHNvLWxhbmRlZC13aXRoLXBhcnQtYVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiYWxzby1sYW5kZWQtd2l0aC1wYXJ0LWFcIiAvPntcIkFsc28gbGFuZGVkIHdpdGggUGFydCBBXCJ9PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQSBwbGF0Zm9ybSBndWFyZCBhZ2FpbnN0IHRoZSBETi1SNSBoYXphcmRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9hcHAvcGxhdGZvcm1HdWFyZHMudGVzdC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpOiBub1xcbm1vZHVsZSBtYXkgXCJ9PF9jb21wb25lbnRzLmVtPntcInN0YXRpY2FsbHkgdmFsdWUtaW1wb3J0XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQGltbWVkaWF0ZWx5LXJ1bi9zZGtcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG9yIFwifTxfY29tcG9uZW50cy5jb2RlPntcIuKApi90YXNrc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIHdoaWNoXFxucmVnaXN0ZXIgYSBob3N0IGxpc3RlbmVyIGF0IG1vZHVsZSBsb2FkIGFuZCB0aHJvdyB3aXRoIG5vIHRyYW5zcG9ydC4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW1wb3J0IHR5cGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLFxcbnRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJtb3VudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHN1YnBhdGggYW5kIFwifTxfY29tcG9uZW50cy5jb2RlPntcImF3YWl0IGltcG9ydCgpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhcmUgYWxsIGNvcnJlY3RseSBub3QgbWF0Y2hlZCDigJQgcHJvdmVuIGJ5XFxuZmF1bHQgaW5qZWN0aW9uIG92ZXIgZml2ZSBjYXNlcywgbm90IGJ5IGluc3BlY3Rpb24uIFRoaXMgZ3VhcmQgZXhpc3RzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiYmVmb3JlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFBhcnQgQlxcbm5lZWRzIGl0LCBzbyB0aGUgbWlzdGFrZSBjYW5ub3QgYmUgbWFkZSBsYXRlci5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkEgbGludC1yZWQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibWFpblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZml4ZWRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIFIzLTQyNyBzaGlwcGVkIGFuIHVudXNlZC1iaW5kaW5nIGVycm9yIGJlY2F1c2UgdGhlXFxudmVyaWZpY2F0aW9uIGNvbW1hbmQgcGlwZWQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibnBtIHJ1biBsaW50XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpbnRvIFwifTxfY29tcG9uZW50cy5jb2RlPntcInRhaWxcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBhbmQgYSBwaXBlbGluZSdzIGV4aXQgc3RhdHVzIGlzXFxudGhlIFwifTxfY29tcG9uZW50cy5lbT57XCJsYXN0XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgY29tbWFuZCdzLCBzbyB0aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiJiZcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNoYWluIGNvbnRpbnVlZCBwYXN0IGEgZmFpbGluZyBnYXRlLiBGaXhlZCBoZXJlLCBhbmRcXG50aGUgbGVzc29uIGlzIHdvcnRoIGtlZXBpbmc6IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibmV2ZXIgcGlwZSBhIGdhdGUgaW50byBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ0YWlsXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJoZWFkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpbiBhIGNoYWluZWRcXG52ZXJpZmljYXRpb25cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIGNhcHR1cmUgdG8gYSBmaWxlIGFuZCBjaGVjayB0aGUgZXhpdCBjb2RlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJwYXJ0LWItdGhlLWVkaXQtYWZmb3JkYW5jZS1yMy00NDctdGhlLWNvbnRyYWN0LWVzdGFibGlzaGVkLXRoZS1idWlsZC1sYW5kZWRcIj48SGVhZGluZ0FuY2hvciBpZD1cInBhcnQtYi10aGUtZWRpdC1hZmZvcmRhbmNlLXIzLTQ0Ny10aGUtY29udHJhY3QtZXN0YWJsaXNoZWQtdGhlLWJ1aWxkLWxhbmRlZFwiIC8+e1wiUGFydCBCIOKAlCB0aGUgZWRpdCBhZmZvcmRhbmNlIChSMy00NDc6IHRoZSBjb250cmFjdCBlc3RhYmxpc2hlZCwgdGhlIGJ1aWxkIGxhbmRlZClcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUGhhc2UgMSDigJQgdGhlIHByZWNvbmRpdGlvbnMsIGVzdGFibGlzaGVkIDIwMjYtMDktMjJcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHRoZSB3b3JrZXItVk0gYWdlbnQgdmVudWU6XFxuY3VycmVudC1tYWluIGRldiBob3N0ICsgc3RhZ2luZyBiYWNrZW5kL0ZpcmVzdG9yZSwgdGhlIHJlYWwgcmVwby1sb2FkIGRpc3BhdGNoLCBhXFxud29ya2Jvb2sgY29ycHVzIHJlcG8gZGlzcGF0Y2hlZCBieSBVUkw7IGJyb3dzZXItZHJpdmVuIG9ic2VydmF0aW9uIG9mZiB0aGUgbGl2ZVxcbmNoYW5uZWwsIHBlciB0aGUgc3BlYydzIHJ1bGUg4oCUIGFuIGluamVjdGVkIHBvcnQgY2Fubm90IGZhbHNpZnkgYSBxdWVzdGlvbiBhYm91dCB0aGVcXG5ob3N0KTpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnRhYmxlPjxfY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRoPntcIiNcIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aD57XCJBbnN3ZXIgKHdpdGggaG93IGl0IHdhcyBlc3RhYmxpc2hlZClcIn08L19jb21wb25lbnRzLnRoPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudGJvZHk+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJQMVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIkEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widHlwZTogJ2NvbnRlbnQnXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBkaXNwYXRjaCBtb3VudCBjYXJyaWVzIFwifTxfY29tcG9uZW50cy5jb2RlPntcImlkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpbiB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ1bml2ZXJzYWwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic2NoZW1lOmxvY2F0b3JcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGZvcm1cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIG9ic2VydmVkIGxpdmUgYXMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY29udGVudDppbW1lZGlhdGVseS1ydW4td29ya2VyL3IzLTQ0Ny13b3JrYm9va1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKHRoZSBmcmFtZSdzIG93biBtb3VudCBzZXJ2aWNlLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJnZXRNb3VudHMoKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjYXBGaWxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIidzIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1vdW50SWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGlzIHRoZXJlZm9yZSBhZGRyZXNzZWQgd2l0aCB0aGUgZGVzY3JpcHRvcidzIFwifTxfY29tcG9uZW50cy5jb2RlPntcImlkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB2ZXJiYXRpbTsgdGhlIGhvc3QncyBncmFudCBsb29rdXAgaXMgYW4gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJleGFjdCBtYXRjaFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBvbiBpdCAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widGFza0ludm9jYXRpb24udHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKGkiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJncmFudEZvclwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLCBhbmQgbm8gZmFsbGJhY2sgaXMgZG9jdW1lbnRlZCDigJQgYSBwYXRoLXNoYXBlZCBvciBiYXJlIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1vdW50SWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHdvdWxkIHJlZnVzZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmb3JiaWRkZW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCB3aGljaCBpcyB3aHkgdGhlIGRvb3IgZmFpbHMgY2xvc2VkIG9uIGFuIGlkLWxlc3MgbW91bnQgcmF0aGVyIHRoYW4gbWFraW5nIGEgZG9vbWVkIGNhbGwuIFRoZSB1bnF1YWxpZmllZCBmb3JtIGlzIG5vdCB3aGF0IHRoZSBob3N0IG1pbnRzLlwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIlAyXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiVGhlIG1vdW50IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicmVwb3J0cyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJtb2RlXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgb2JzZXJ2ZWQgbGl2ZSBhcyBcIn08X2NvbXBvbmVudHMuY29kZT57XCIncncnXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBvbiB0aGUgcmVwby1sb2FkIGRpc3BhdGNoICh3cml0ZXMgbGFuZCBpbiB0aGUgY29ycHVzIG1vdW50OyBwcm9wb3NpbmcgYmFjayB0byB0aGUgc291cmNlIHJlcG8gc3RheXMgdW53aXJlZCwgdGhlIFJDRCDCpzUuMSBkaXNjbG9zdXJlKSDigJQgYW5kIFwifTxfY29tcG9uZW50cy5zdHJvbmc+PF9jb21wb25lbnRzLmNvZGU+e1wicnVsZXM6IG51bGxcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChubyBydWxlcykuIFRoZSBlZGl0YWJpbGl0eSBkZXJpdmF0aW9uIHRoZXJlZm9yZSBrZXlzIG9uIHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInBvc2l0aXZlIFwifTxfY29tcG9uZW50cy5jb2RlPntcInJ3XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjaGVja1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBSLUVGRS0xIHByZXNjcmliZXM7IHRoZSBkcmFmdCdzIFxcXCJhYnNlbnQg4oeSIHdyaXRhYmxlXFxcIiBpbnZlcnNpb24gKEROLVIyKSBpcyBkZWFkLCBhbmQgdGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcInN1YnRyZWVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLWNvbXBhcmFiaWxpdHkgcXVlc3Rpb24gKEROLVIzKSBkaXNzb2x2ZXMg4oCUIHRoZXJlIGFyZSBubyBydWxlcyB0byBjb21wYXJlLiBUaGlzIHJlcG8ncyBkaXNwYXRjaCBmaXh0dXJlcyBzdGFtcCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJtb2RlOiAncm8nXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjsgdGhlIGxpdmUgcmVwby1sb2FkIG1vdW50IHN0YW1wcyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyd1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIHRoZSBmaXh0dXJlcyBtb2RlbCB0aGUgdGFzay1pbnZvY2F0aW9uIHNoYXBlLCBub3QgdGhpcyBvbmUuXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiUDNcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkJvdGggY2hhbm5lbHMgYXJlIHJlYWwgYW5kIHNoYXBlZCBhcyDCpzQuMiBoYW5kbGVzIHRoZW0uXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIERvY3VtZW50ZWQgaGFsZiAodGhlIGhvc3QncyB0YXNrIGNvbnRyYWN0LCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ0YXNrQ29udHJhY3RzLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIik6IFwifTxfY29tcG9uZW50cy5jb2RlPntcImVkaXQtZmlsZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcmV0dXJucyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ7IHNhdmVkOiBib29sZWFuIH1cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzYXZlZDogZmFsc2VcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGlzIHRoZSByZXN1bHQtY2FycmllZCByZWZ1c2FsLCBhbmQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW52b2tlVGFza1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdGhyb3dzIG1hY2hpbmUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLmNvZGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHJlamVjdGlvbnMgKFwifTxfY29tcG9uZW50cy5jb2RlPntcImNhbmNlbGxlZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcImZvcmJpZGRlblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIOKApikuIExpdmUgaGFsZiAoYSByZWFsIGludm9jYXRpb24gZnJvbSB0aGUgZGlzcGF0Y2hlZCBmcmFtZSk6IGV4ZXJjaXNlZCBieSB0aGUgZ2F0ZXMgYmVsb3cg4oCUIGl0IHJlcXVpcmVkIFA0J3MgZ3JhbnQgZmlyc3QsIHdoaWNoIGlzIHRoZSBzZXF1ZW5jaW5nIGZpbmRpbmcsIG5vdCBhIGdhcC5cIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJQNFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiTk8g4oCUIGFuZCBkZWxpYmVyYXRlbHkgc28uXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRoZSBidWlsZC1kZWZhdWx0IGJpbmRpbmcgKFwifTxfY29tcG9uZW50cy5jb2RlPntcInNpdGUtbWFpblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicmVnaXN0cnkvZGVmYXVsdHMudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ0YXNrLm9wZW4td29ya2Jvb2tcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSBvbWl0dGVkIFwifTxfY29tcG9uZW50cy5jb2RlPntcInRhc2s6aW52b2tlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB3aXRoIGEgY29tbWVudCBuYW1pbmcgdGhpcyBtaWxlc3RvbmUgYXMgdGhlIG1vbWVudCB0byBhZGQgaXQ7IHRoZSBmcmFtZSdzIGxpdmUgZ3JhbnQtZmlsdGVyZWQgY2F0YWxvZyBjYXJyaWVkIG5vIHRhc2sgdmVyYi4gVGhlIGdyYW50IGhhbGYgaXMgc2l0ZS1tYWluJ3MgUjMtNDQ3IHJlZ2lzdHJ5IGRpZmYgKHRoaXMgbWlsZXN0b25lKTsgdGhlIG1hbmlmZXN0IFwifTxfY29tcG9uZW50cy5jb2RlPntcImludm9rZXNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGRlY2xhcmF0aW9uICh0aGlzIHJlcG8pIGlzIHRoZSBzZWxmLXJlc3RyaWN0aW9uIGhhbGYg4oCUIEctRE4tQjEwIGFzc2VydHMgYm90aC5cIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJQNVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVGhlIGRpc3BhdGNoZWQgc2hhcGUgaXMgcmVhY2hhYmxlIGFuZCByZW5kZXJzLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBEcml2ZW4gbGl2ZTogYSB3b3JrYm9vayBjb3JwdXMgcmVwbyAodGhlIE1lcmlkaWFuIHNlZWQgYXMgcmVhbCBmaWxlcyArIFwifTxfY29tcG9uZW50cy5jb2RlPntcImltbWVkaWF0ZWx5LnJ1bi5qc29uXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBtYXJrZXIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wib3BlbnNXaXRoOiBvcGVuLXdvcmtib29rQDEuMFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpIGRpc3BhdGNoZWQgYnkgVVJMIHRocm91Z2ggdGhlIHJlYWwgcmVwby1sb2FkIGJyYW5jaCDigJQgc3RvY2sgcmVja29uZXIgZnJvbSB0aGUgcmVnaXN0cnkgYmluZGluZyByZW5kZXJlZCB0aGUgcmVwb3J0IChuYXYsIGdyb3d0aC1jb21wb3NpdGlvbiBzZWN0aW9ucywgdGhlIHdvcmtib29rIHBhbmVsKS4gVGhlIGhvbmVzdCBzZXF1ZW5jaW5nIG5vdGVzOiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vIHdvcmtib29rIGNvcnB1cyByZXBvIGV4aXN0ZWRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHRoZSBjb3JwdXMgaXMgY29udGVudCB3b3JrLCBub3QgcGxhdGZvcm0gd29yayDigJQgdGhlIHNwaWtlJ3MgY29ycHVzIGlzIHRlbXBvcmFyeSksIGFuZCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vIHVzZXItZmFjaW5nIGNhbGxlciBpbnZva2VzIHRoZSB0YXNrXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICh0aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wib3BlbnNXaXRoXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBtYXJrZXIncyBvbmx5IHJlYWRlciBpcyB0aGUgVVJMIHJvdXRlOyB0aGUgZm9sZGVyLXRyaWdnZXIgY2FsbGVyIGlzIFIzLTI2Nykg4oCUIHRoZSBVUkwgcm91dGUgaXMgdGhlIHJlYWNoYWJsZSBzaGFwZS5cIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50Ym9keT48L19jb21wb25lbnRzLnRhYmxlPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUGhhc2UgMiDigJQgYnVpbHRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHRoZSBzYW1lIGl0ZW0pOiB0aGUgaW5zcGVjdG9yJ3MgcGVyLXJvdyBlZGl0IGRvb3IgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIlZhbHVlSW5zcGVjdG9yXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiksXFxudGhlIMKnNC4zIHBhdGggZ2F0ZSAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZG9jdW1lbnRQYXRoc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLCB0aGUgZG9vciBpdHNlbGYgKFwifTxfY29tcG9uZW50cy5jb2RlPntcInVzZUVkaXRGaWxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgbGF6eSBpbXBvcnQsIGJvdGhcXG5yZWZ1c2FsIGNoYW5uZWxzLCB0aGUgc2Vzc2lvbi1zY29wZWQgbGF0Y2gsIHRoZSBob3N0LWxlc3Mgbm8tb3AsIHRoZSDCpzQuNCBzdGFsZW5lc3NcXG5zaWduYWwpLCB0aGUgc3RhbGVuZXNzIG5vdGljZSArIHJlbG9hZCAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRG9jdW1lbnRDaGFuZ2VkTm90aWNlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widXNlUmVwb3J0LnJlbG9hZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLFxcbnRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJpbnZva2VzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBkZWNsYXJhdGlvbiwgYW5kIHNpdGUtbWFpbidzIFwifTxfY29tcG9uZW50cy5jb2RlPntcInRhc2s6aW52b2tlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBncmFudC4gUTYgKHRoZSBjb25zdW1lclxcbmluc3BlY3RvcidzIGRvb3IpIHJlc29sdmVzIHBlciB0aGUgaXRlbSdzIG93biBQaGFzZS0yIHN1cmZhY2UgKFxcXCJ0aGUgaW5zcGVjdG9yJ3MgZm9ybXVsYVxcbmFuZCB0ZXN0IHJvd3NcXFwiKTsgUTMgKHJlbG9hZCB2cyBjaGFuZ2Utd2F0Y2gpIHJlc29sdmVzIHRvIHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInJlbG9hZCBhZmZvcmRhbmNlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBhXFxuY2hhbmdlLXdhdGNoIG5lZWRzIGFuIGZzIHdhdGNoIHRoZSB0YXNrLWRlbGVnYXRlZCBleHBvcnQgZG9lcyBub3QgY2FycnlcXG4oU1BBQ0VTX1VJIMKnNi42IC8gUjMtNzMyJ3Mgc2VhbSkuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cImdhdGUtY292ZXJhZ2UtMVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiZ2F0ZS1jb3ZlcmFnZS0xXCIgLz57XCJHYXRlIGNvdmVyYWdlXCJ9PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMudGFibGU+PF9jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGg+e1wiR2F0ZVwifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIlRlc3RcIn08L19jb21wb25lbnRzLnRoPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudGJvZHk+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJHLUROLUIxXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiZGlzcGF0Y2gudGVzdC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIHRoZSBvayByZXNvbHV0aW9uIGNhcnJpZXMgdGhlIGxpdmUgbW91bnQgKGlkL21vZGUgcHJvdmVuYW5jZSk7IHRoZSBsaXZlIGRlc2NyaXB0b3IgcmVhZCBvbiB0aGUgdmVudWUgKGFib3ZlKVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkctRE4tQjJcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJ1c2VFZGl0RmlsZS50ZXN0LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgd3JpdGFiaWxpdHkgYnkgdGhlIHBvc2l0aXZlIFwifTxfY29tcG9uZW50cy5jb2RlPntcInJ3XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjaGVjayAocm8vYWJzZW50IGFyZSBub3QgZG9vcnMpXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiRy1ETi1CM1wifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcImRvY3VtZW50UGF0aHMudGVzdC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIHNlZ21lbnQtYm91bmRhcnkgdHJhdmVyc2FsIHJlZnVzYWw7IFwifTxfY29tcG9uZW50cy5jb2RlPntcInVzZUVkaXRGaWxlLnRlc3QudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCBhIGZhaWxpbmcgcGF0aCBuZXZlciBjb25zdHJ1Y3RzIHRoZSBkZWxlZ2F0aW9uXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiRy1ETi1CNFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcInVzZUVkaXRGaWxlLnRlc3QudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCB0aGUgY2FsbCBhZGRyZXNzZXMgdGhlIGRlc2NyaXB0b3IgaWQgKHVuaXZlcnNhbCBmb3JtKTsgYW4gaWQtbGVzcyBtb3VudCBpcyBub3QgYSBkb29yIChmYWlsLWNsb3NlZCDigJQgdGhlIGhvc3QncyBleGFjdC1tYXRjaCBncmFudCBsb29rdXAgaGFzIG5vIGRvY3VtZW50ZWQgZmFsbGJhY2spOyB0aGUgbGl2ZSBpbnZvY2F0aW9uIGdhdGUgYmVsb3dcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJHLUROLUI1XCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1widXNlRWRpdEZpbGUudGVzdC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIGJvdGggY2hhbm5lbHM6IHRocm93biBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjYW5jZWxsZWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcImZvcmJpZGRlblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widGltZW91dFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIHRoZSByZXN1bHQtY2FycmllZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ7c2F2ZWQ6ZmFsc2V9XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiByZWZ1c2FsLCB0aGUgaG9zdC1sZXNzIG5vLW9wOyB0aGUgbGl2ZSBnYXRlIGJlbG93XCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiRy1ETi1CNlwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcIlZhbHVlSW5zcGVjdG9yLnRlc3QudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgYWJzZW50IHVubGVzcyB3cml0YWJsZSAocGVyIHJvdyksIHByZXNlbnQgYmVzaWRlIGJvdGggYW5jaG9ycywgdGhlIGRpc2Nsb3N1cmUgYXQgdGhlIGJ1dHRvbiwgdGhlIGNsaWNrIGhhbmRzIHRoZSByb3cncyBwYXRoOyB0aGUgbGl2ZSBnYXRlIGJlbG93XCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiRy1ETi1CN1wifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcImRvY3VtZW50UGF0aHMudGVzdC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIHRyYXZlcnNhbC1zaGFwZWQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibWFuaWZlc3Qud29ya3NoZWV0c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcGF0aHMgbmV2ZXIgcmVhY2ggXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2FwRmlsZVwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJHLUROLUI4XCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1widGhlIHByZS1leGlzdGluZyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJwbGF0Zm9ybUd1YXJkcy50ZXN0LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAobm8gc3RhdGljIHRhc2tzIGltcG9ydCkgKyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ1c2VFZGl0RmlsZS50ZXN0LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIidzIGhvc3QtbGVzcyBuby1vcCBjYXNlXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiRy1ETi1COVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcIkRvY3VtZW50Q2hhbmdlZE5vdGljZS50ZXN0LnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ1c2VSZXBvcnQudGVzdC50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICh0aGUgcmVsb2FkKTsgdGhlIGxpdmUgZ2F0ZSBiZWxvd1wifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkctRE4tQjEwXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wicGFja2FnZS5qc29uXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJpbnZva2VzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAodGhpcyByZXBvKSArIHNpdGUtbWFpbidzIHJlZ2lzdHJ5IGRpZmYgYW5kIGl0cyBleGFjdC1saXN0IHRlc3RcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50Ym9keT48L19jb21wb25lbnRzLnRhYmxlPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVGhlIGhvc3QtZXhlcmNpc2VkIGhhbHZlcyAoUDHigJNQNCdzIGxpdmUgbGVnczogYSByZWFsIFwifTxfY29tcG9uZW50cy5jb2RlPntcImVkaXQtZmlsZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaW52b2NhdGlvbiBmcm9tIHRoZVxcbmRpc3BhdGNoZWQgZnJhbWUg4oCUIHRoZSBkb29yIHZpc2libGUgb24gdGhlIGRpc3BhdGNoZWQgc2hhcGUsIHRoZSBvdmVybGF5IG9wZW5pbmcsIGJvdGhcXG5yZWZ1c2FsIGNoYW5uZWxzIG9ic2VydmVkIG9uIHRoZSByZWFsIGdhdGUsIHRoZSBzdGFsZW5lc3MgYWZmb3JkYW5jZSBhZnRlciBhIHNhdmUpIHJ1blxcbm9uIHRoZSB2ZW51ZSBhZ2FpbnN0IHRoZSBtZXJnZWQgbWFpbnMgYmVmb3JlIFIzLTQ0NyBhcmNoaXZlczsgdGhlIHVuaXQgaGFsdmVzIGFib3ZlIGFyZVxcbmluLXJlcG8gYW5kIGdyZWVuLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJvcGVuLXJlc2lkdWFsc1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwib3Blbi1yZXNpZHVhbHNcIiAvPntcIk9wZW4gcmVzaWR1YWxzXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPjxfY29tcG9uZW50cy5jb2RlPntcImVkaXQtdGFibGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGlzIG5vdyBzcGVjaWZpZWRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKDIwMjYtMDgtMjkpIOKAlCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJFRElUX1RBQkxFX1RBU0tfU1BFQy5tZHhcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGluIHRoZSBkb2NzXFxucmVwbywgcHJvcG9zYWwgcmV2IDIgYWZ0ZXIgYW4gYWR2ZXJzYXJpYWwgcGFzcy4gSXQgaXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJibG9ja2VkIG9uIFAx4oCTUDUgYWJvdmUgcGx1cyB0d29cXG5vZiBpdHMgb3duXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChQNjogdGFzay1kZWxlZ2F0aW9uIG1vdW50cyBhcmUgYW5ub3VuY2VkIHdpdGggbm8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibW9kZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIHNvIHRoZSByZWFkLW9ubHlcXG5ydWxlIGlzIHVuaW1wbGVtZW50YWJsZTsgUDc6IFJlY2tvbmVyIGhhcyBubyBmcyB3YXRjaCwgc28gdGhlIGF1dG9zYXZlIHNhZmV0eSBhcmd1bWVudFxcbmhhcyBubyBjb25zdW1lcikuIFIzLTQ0NydzIGhvc3Qgc3Bpa2UgdGhlcmVmb3JlIHVuYmxvY2tzIGJvdGggc3VyZmFjZXMsIG5vdCBqdXN0IFBhcnQgQiDigJRcXG53b3J0aCBrbm93aW5nIGJlZm9yZSBzY29waW5nIGl0LiBUaGUgcmV2aWV3IGFsc28gY29uZmlybWVkIHRoZSBzZWVkLXZzLW1vdW50IHdhbGwgYXBwbGllc1xcbnRvIGZpeHR1cmVzIGV4YWN0bHkgYXMgaXQgZG9lcyB0byB3b3Jrc2hlZXRzOiBvbiB0aGUgYnVuZGxlZC1zZWVkIHBhdGggdGhlcmUgaXMgbm8gZmlsZVxcbnRvIGRlbGVnYXRlLCBvbmx5IGEgc3RyaW5nIGluIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9zZWVkL1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlNwZWMgwqc2IChcIn08X2NvbXBvbmVudHMuY29kZT57XCJlZGl0LXRhYmxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgb3Blbi1hdC1saW5lLCBEZWx0YSBCLCBjbGljay10by1pbnNlcnQsIG93bi1zb3VyY2UgZWRpdGluZykgYW5kXFxuwqcxMSBRMeKAk1E3IOKAlCBpbmNsdWRpbmcgdGhlIHR3byB0aGUgcmV2aWV3IHN1cmZhY2VkIGFzIHJlYWwgZGVjaXNpb25zIHJhdGhlciB0aGFuXFxuZGVmZXJyYWxzOiB3aGV0aGVyIHRoZSBjb25zdW1lci12aXNpYmxlIGluc3BlY3RvciBjYXJyaWVzIGFuIGF1dGhvcmluZyBkb29yIChRNiksIGFuZFxcbnRoZSB0ZW1wbGF0ZS1maWxlIGVkaXQgcm93IHdpdGhvdXQgd2hpY2ggXFxcImNvcHkgdGhlIHNuaXBwZXQsIG9wZW4gdGhlIHRlbXBsYXRlXFxcIiBoYXMgbm9cXG5kb29yIChRNykuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cInRoZS1saXZlLWdhdGVzLTIwMjYtMDktMjItdGhlLXZlbnVlLXJ1bi1hZ2FpbnN0LWJvdGgtbWVyZ2VkLW1haW5zLXR3by1wYXNzLW9uZS1pcy1hLWZpbmRpbmdcIj48SGVhZGluZ0FuY2hvciBpZD1cInRoZS1saXZlLWdhdGVzLTIwMjYtMDktMjItdGhlLXZlbnVlLXJ1bi1hZ2FpbnN0LWJvdGgtbWVyZ2VkLW1haW5zLXR3by1wYXNzLW9uZS1pcy1hLWZpbmRpbmdcIiAvPntcIlRoZSBsaXZlIGdhdGVzICgyMDI2LTA5LTIyLCB0aGUgdmVudWUgcnVuIGFnYWluc3QgQk9USCBtZXJnZWQgbWFpbnMpIOKAlCB0d28gcGFzcywgb25lIGlzIGEgRklORElOR1wifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiRHJpdmVuIG9uIHRoZSB3b3JrZXItVk0gdmVudWUgd2l0aCBzaXRlLW1haW4gYXQgNjBkZGQwYSBhbmQgcmVja29uZXJAbWFpbiBhdCAyOTI1ZmE0XFxuKGJvdGggUFJzIG1lcmdlZCksIHRoZSBjb3JwdXMgZGlzcGF0Y2hlZCBieSBVUkw6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJHLUROLUI2IGxpdmU6IFBBU1MuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRoZSBkb29yIHJlbmRlcnMgYmVzaWRlIGJvdGggXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZmlsZTpsaW5lXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhbmNob3JzXFxuKFwifTxfY29tcG9uZW50cy5jb2RlPntcIndvcmtzaGVldHMvcmV2aWV3LnNoZWV0LmpzOjNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFuZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCI6MTA3XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikgb24gdGhlIGRpc3BhdGNoZWQgc2hhcGUsIHdpdGggdGhlIFJDRFxcbsKnNS4xIGRpc2Nsb3N1cmUgb24gdGhlIGJ1dHRvbiB0aXRsZSBBTkQgdGhlIHZpc2libGUgbm90ZSBsaW5lLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRy1ETi1CNSBsaXZlICh0aGUgZm9yYmlkZGVuIGNoYW5uZWwpOiBQQVNTLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBBIHJlZnVzZWQgaW52b2NhdGlvbiBkcmF3cyBleGFjdGx5XFxub25lIHBsYWluIG1lc3NhZ2UgKFxcXCJUaGlzIGRvY3VtZW50IGNhbid0IGJlIGVkaXRlZCBoZXJlLlxcXCIpIGFuZCBsYXRjaGVzIHRoZSBkb29yIG9mZiDigJRcXG5vYnNlcnZlZCBsaXZlLCBtYXRjaGluZyDCpzQuMiB0byB0aGUgbGV0dGVyLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRy1ETi1CNCBsaXZlICh0aGUgc3VjY2Vzc2Z1bCBpbnZvY2F0aW9uKTogQkxPQ0tFRCBCWSBBIEZJTkRJTkcsIG5vdCBhIGJ1ZyBpbiB0aGlzXFxucmVwbydzIGhhbGYuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRoZSBpbnZvY2F0aW9uIHJlZnVzZXMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZm9yYmlkZGVuIOKAlCAncHJvdG9jb2wtdGFzay5pbnZva2UnIHJlcXVpcmVzIHRoZSAndGFzazppbnZva2UnIGNhcGFiaWxpdHk7IHRoaXMgYXBwJ3MgZ3JhbnQgZG9lcyBub3QgaG9sZCBpdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZGVzcGl0ZVxcbnNpdGUtbWFpbiM1ODQgYmVpbmcgbWVyZ2VkIGFuZCB0aGUgdmVudWUgc2VydmluZyBpdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIi4gUm9vdCBjYXVzZSAoY29kZSArIGxpdmUpOlxcbnRoZSBVUkwgcmVwby1sb2FkIGRpc3BhdGNoIHJlc29sdmVzIHRoZSBcIn08X2NvbXBvbmVudHMuZW0+e1widmlld2VyJ3MgcmVwb1wifTwvX2NvbXBvbmVudHMuZW0+e1wiIGZyb20gdGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcInRhc2sub3Blbi13b3JrYm9va1wifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG5iaW5kaW5nLCBidXQgdGhlIGZyYW1lJ3MgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJncmFudFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBpcyB0aGUgcHJldmlldy9zdGFnZSBncmFudCDigJQgdGhlIHJlZ2lzdHJ5IHJvdydzXFxuY2FwYWJpbGl0aWVzIG5ldmVyIGZsb3cgdG8gdGhlIHJlcG8tbG9hZC1kaXNwYXRjaGVkIGZyYW1lLiBUaGUgdGFzay1pbnZvY2F0aW9uIHNoYXBlXFxuKHdoZXJlIHRoZSBiaW5kaW5nJ3MgZ3JhbnQgZG9lcyBhcHBseSkgaXMgdW5yZWFjaGFibGUgdHdpY2Ugb3Zlcjogbm8gdXNlci1mYWNpbmdcXG5jYWxsZXIgZXhpc3RzIChSMy0yNjcpLCBhbmQgdGhpcyByZXBvJ3MgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZGlzcGF0Y2gudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHYxIGRlbGliZXJhdGVseSByZXNvbHZlcyBvbmx5XFxudGhlIHJlcG8tbG9hZCBzaGFwZS4gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgYWZmb3JkYW5jZSBpcyB0aGVyZWZvcmUgdW5yZWFjaGFibGUgb24gYm90aCBkaXNwYXRjaFxcbnNoYXBlcyDigJQgRE4tUjEyJ3MgZmFpbHVyZSBtb2RlIHJlYm9ybiBhdCB0aGUgaW52b2NhdGlvbiBsYXllci5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhlIGZpeCBpcyBhXFxuZGVzaWduIGRlY2lzaW9uIHRoZSBvd25lciBvd25zICh0aGUgcmVwby1sb2FkIGRpc3BhdGNoIG1pbnRpbmcgdGhlIHZpZXdlcidzIGdyYW50XFxuZnJvbSB0aGUgdGFzayBiaW5kaW5nOyBvciB0aGUgcHJldmlldyBncmFudCB3aWRlbmluZzsgb3Igc2hpcHBpbmcgdGhlIHRhc2stc2hhcGVcXG5jYWxsZXIpOyByZWNvcmRlZCBpbiBSMy00NDcncyByb2FkbWFwIHN0YXR1cywgd2hpY2ggc3RheXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJpbi1wcm9ncmVzcywgdW5hcmNoaXZlZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+PC8+O1xufVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTURYQ29udGVudChwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHt3cmFwcGVyOiBNRFhMYXlvdXR9ID0ge1xuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfTtcbiAgcmV0dXJuIE1EWExheW91dCA/IDxNRFhMYXlvdXQgey4uLnByb3BzfT48X2NyZWF0ZU1keENvbnRlbnQgey4uLnByb3BzfSAvPjwvTURYTGF5b3V0PiA6IF9jcmVhdGVNZHhDb250ZW50KHByb3BzKTtcbn1cbmZ1bmN0aW9uIF9taXNzaW5nTWR4UmVmZXJlbmNlKGlkLCBjb21wb25lbnQsIHBsYWNlKSB7XG4gIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIFwiICsgKGNvbXBvbmVudCA/IFwiY29tcG9uZW50XCIgOiBcIm9iamVjdFwiKSArIFwiIGBcIiArIGlkICsgXCJgIHRvIGJlIGRlZmluZWQ6IHlvdSBsaWtlbHkgZm9yZ290IHRvIGltcG9ydCwgcGFzcywgb3IgcHJvdmlkZSBpdC5cIiArIChwbGFjZSA/IFwiXFxuSXTigJlzIHJlZmVyZW5jZWQgaW4geW91ciBjb2RlIGF0IGBcIiArIHBsYWNlICsgXCJgIGluIGAvYXBwL2RvY3Mvc3RhdHVzL0RPQ1VNRU5UX05BVklHQVRPUl9TVEFUVVMubWRgXCIgOiBcIlwiKSk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUVBLElBQUFBLFlBQUEsR0FBQUMsT0FBQTtBQUF3RixJQUFBQyxXQUFBLEdBQUFELE9BQUE7QUFGeEY7QUFDQTs7QUFFQSxTQUFTRSxpQkFBaUJBLENBQUNDLEtBQUssRUFBRTtFQUNoQyxNQUFNQyxXQUFXLEdBQUc7TUFDbEJDLElBQUksRUFBRSxNQUFNO01BQ1pDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLENBQUMsRUFBRSxHQUFHO01BQ05DLE1BQU0sRUFBRSxRQUFRO01BQ2hCQyxLQUFLLEVBQUUsT0FBTztNQUNkQyxLQUFLLEVBQUUsT0FBTztNQUNkQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxLQUFLLEVBQUUsT0FBTztNQUNkQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSLEdBQUcsSUFBQUMsNkJBQWtCLEVBQUMsQ0FBQztNQUN2QixHQUFHakIsS0FBSyxDQUFDa0I7SUFDWCxDQUFDO0lBQUU7TUFBQ0M7SUFBYSxDQUFDLEdBQUdsQixXQUFXO0VBQ2hDLElBQUksQ0FBQ2tCLGFBQWEsRUFBRUMsb0JBQW9CLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQztFQUMvRCxvQkFBTyxJQUFBdEIsV0FBQSxDQUFBdUIsSUFBQSxFQUFBdkIsV0FBQSxDQUFBd0IsUUFBQTtJQUFBQyxRQUFBLGdCQUFFLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNHLEVBQUU7TUFBQ29CLEVBQUUsRUFBQywwQ0FBMEM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUEwQyxDQUFFLENBQUMsRUFBQyw0Q0FBNEM7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNPLENBQUM7TUFBQWUsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDUSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFTLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBb0YsQ0FBcUIsQ0FBQyxFQUFDLE1BQU0sZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDUSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFVLENBQXFCLENBQUMsRUFBQyxhQUFhO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDTyxDQUFDO01BQUFlLFFBQUEsR0FBRSxnRUFBZ0UsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBdUMsQ0FBbUIsQ0FBQyxFQUFDLCtDQUErQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0ksRUFBRTtNQUFDbUIsRUFBRSxFQUFDLG9EQUFvRDtNQUFBRCxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQW9ELENBQUUsQ0FBQyxFQUFDLHdEQUF3RDtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ2UsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNNLEVBQUU7UUFBQWdCLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQXVCLENBQW1CLENBQUMsRUFBQyw0T0FBNE8sZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBZSxDQUFtQixDQUFDLEVBQUMsaUJBQWlCO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDTSxFQUFFO1FBQUFnQixRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUErQixDQUFtQixDQUFDLEVBQUMsNEdBQTRHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDTSxFQUFFO1FBQUFnQixRQUFBLEdBQUUsYUFBYSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUEyQixDQUFtQixDQUFDLEVBQUMscUNBQXFDLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQVUsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBYSxDQUFtQixDQUFDLEVBQUMsSUFBSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDSyxFQUFFO01BQUNrQixFQUFFLEVBQUMsZUFBZTtNQUFBRCxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQWUsQ0FBRSxDQUFDLEVBQUMsZUFBZTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1MsS0FBSztNQUFBYSxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNhLEtBQUs7UUFBQVMsUUFBQSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNjLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDWSxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFNLENBQWlCLENBQUMsbUJBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNZLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQU0sQ0FBaUIsQ0FBQztRQUFBLENBQWdCO01BQUMsQ0FBbUIsQ0FBQyxtQkFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1UsS0FBSztRQUFBWSxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNjLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDVyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFTLENBQWlCLENBQUMsbUJBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNXLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBNEIsQ0FBbUIsQ0FBQyxFQUFDLGdCQUFnQixlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUFnQixDQUFtQixDQUFDLEVBQUMsd0JBQXdCO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNjLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDVyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFTLENBQWlCLENBQUMsbUJBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNXLEVBQUU7WUFBQVcsUUFBQSxHQUFFLG1DQUFtQyxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUFPLENBQW1CLENBQUMsRUFBQyx1Q0FBdUMsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBRyxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUFHLENBQW1CLENBQUMsRUFBQyxPQUFPLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQWlCLENBQW1CLENBQUM7VUFBQSxDQUFnQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ2MsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNXLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQVMsQ0FBaUIsQ0FBQyxtQkFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1csRUFBRTtZQUFBVyxRQUFBLEdBQUUsU0FBUyxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNRLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQU8sQ0FBcUIsQ0FBQyxFQUFDLDhCQUE4QixlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUFlLENBQW1CLENBQUMsRUFBQyw0QkFBNEIsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBa0IsQ0FBbUIsQ0FBQyxFQUFDLHVIQUF1SDtVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDYyxFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1csRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBUyxDQUFpQixDQUFDLG1CQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDVyxFQUFFO1lBQUFXLFFBQUEsR0FBRSxTQUFTLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQVMsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBUyxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUFZLENBQW1CLENBQUMsRUFBQyxzQ0FBc0M7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ2MsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNXLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQVMsQ0FBaUIsQ0FBQyxtQkFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1csRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUFvQyxDQUFtQixDQUFDLEVBQUMseUNBQXlDO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNjLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDVyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFTLENBQWlCLENBQUMsbUJBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNXLEVBQUU7WUFBQVcsUUFBQSxHQUFFLHdCQUF3QixlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUFhLENBQW1CLENBQUM7VUFBQSxDQUFnQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQztNQUFBLENBQW1CLENBQUM7SUFBQSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNPLENBQUM7TUFBQWUsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDUSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFzRCxDQUFxQixDQUFDLEVBQUMsMktBQTJLLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQU8sQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBSyxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFRLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQVEsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBVyxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFXLENBQW1CLENBQUMsRUFBQyxZQUFZLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQWUsQ0FBbUIsQ0FBQyxFQUFDLGFBQWE7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNLLEVBQUU7TUFBQ2tCLEVBQUUsRUFBQyx5QkFBeUI7TUFBQUQsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUF5QixDQUFFLENBQUMsRUFBQyx5QkFBeUI7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNlLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDTSxFQUFFO1FBQUFnQixRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNRLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTJDLENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQWdDLENBQW1CLENBQUMsRUFBQyxvQkFBb0IsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRSxFQUFFO1VBQUFvQixRQUFBLEVBQUU7UUFBeUIsQ0FBaUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBc0IsQ0FBbUIsQ0FBQyxFQUFDLE1BQU0sZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBUyxDQUFtQixDQUFDLEVBQUMsZ0ZBQWdGLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQyxFQUFDLFNBQVMsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsZUFBZSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFnQixDQUFtQixDQUFDLEVBQUMsb0hBQW9ILGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBUSxDQUFxQixDQUFDLEVBQUMseURBQXlEO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDTSxFQUFFO1FBQUFnQixRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNRLE1BQU07VUFBQWMsUUFBQSxHQUFFLGFBQWEsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1lBQUFxQixRQUFBLEVBQUU7VUFBTSxDQUFtQixDQUFDLEVBQUMsUUFBUTtRQUFBLENBQXFCLENBQUMsRUFBQyxvRkFBb0YsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBYyxDQUFtQixDQUFDLEVBQUMsUUFBUSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFNLENBQW1CLENBQUMsRUFBQyx5Q0FBeUMsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRSxFQUFFO1VBQUFvQixRQUFBLEVBQUU7UUFBTSxDQUFpQixDQUFDLEVBQUMscUJBQXFCLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQUksQ0FBbUIsQ0FBQyxFQUFDLHNGQUFzRixlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNRLE1BQU07VUFBQWMsUUFBQSxHQUFFLHlCQUF5QixlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7WUFBQXFCLFFBQUEsRUFBRTtVQUFNLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtZQUFBcUIsUUFBQSxFQUFFO1VBQU0sQ0FBbUIsQ0FBQyxFQUFDLDZCQUE2QjtRQUFBLENBQXFCLENBQUMsRUFBQywrQ0FBK0M7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0ksRUFBRTtNQUFDbUIsRUFBRSxFQUFDLDZFQUE2RTtNQUFBRCxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQTZFLENBQUUsQ0FBQyxFQUFDLG1GQUFtRjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ08sQ0FBQztNQUFBZSxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNRLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQXFELENBQXFCLENBQUMsRUFBQywrUkFBK1I7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNTLEtBQUs7TUFBQWEsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDYSxLQUFLO1FBQUFTLFFBQUEsZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDYyxFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBRyxDQUFpQixDQUFDLG1CQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDWSxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFzQyxDQUFpQixDQUFDO1FBQUEsQ0FBZ0I7TUFBQyxDQUFtQixDQUFDLG1CQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDVSxLQUFLO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ2MsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNXLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQUksQ0FBaUIsQ0FBQyxtQkFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1csRUFBRTtZQUFBVyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUFpQixDQUFtQixDQUFDLEVBQUMsMEJBQTBCLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQUksQ0FBbUIsQ0FBQyxFQUFDLFVBQVUsZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDUSxNQUFNO2NBQUFjLFFBQUEsR0FBRSxZQUFZLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtnQkFBQXFCLFFBQUEsRUFBRTtjQUFnQixDQUFtQixDQUFDLEVBQUMsT0FBTztZQUFBLENBQXFCLENBQUMsRUFBQyxzQkFBc0IsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBZ0QsQ0FBbUIsQ0FBQyxFQUFDLG1DQUFtQyxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUFhLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQVMsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBUyxDQUFtQixDQUFDLEVBQUMsZ0RBQWdELGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQUksQ0FBbUIsQ0FBQyxFQUFDLDJDQUEyQyxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNRLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQWEsQ0FBcUIsQ0FBQyxFQUFDLFVBQVUsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBbUIsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBVSxDQUFtQixDQUFDLEVBQUMsMkRBQTJELGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQVMsQ0FBbUIsQ0FBQyxFQUFDLGdCQUFnQixlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUFXLENBQW1CLENBQUMsRUFBQyw2SUFBNkk7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ2MsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNXLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQUksQ0FBaUIsQ0FBQyxtQkFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1csRUFBRTtZQUFBVyxRQUFBLEdBQUUsWUFBWSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNRLE1BQU07Y0FBQWMsUUFBQSxHQUFFLFVBQVUsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO2dCQUFBcUIsUUFBQSxFQUFFO2NBQU0sQ0FBbUIsQ0FBQztZQUFBLENBQW9CLENBQUMsRUFBQyxzQkFBc0IsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBTSxDQUFtQixDQUFDLEVBQUMsK0lBQStJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsTUFBTTtjQUFBYyxRQUFBLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtnQkFBQXFCLFFBQUEsRUFBRTtjQUFhLENBQW1CO1lBQUMsQ0FBb0IsQ0FBQyxFQUFDLGdFQUFnRSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNRLE1BQU07Y0FBQWMsUUFBQSxHQUFFLFdBQVcsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO2dCQUFBcUIsUUFBQSxFQUFFO2NBQUksQ0FBbUIsQ0FBQyxFQUFDLFFBQVE7WUFBQSxDQUFxQixDQUFDLEVBQUMsNEZBQTRGLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQVMsQ0FBbUIsQ0FBQyxFQUFDLGlIQUFpSCxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUFZLENBQW1CLENBQUMsRUFBQyxvQ0FBb0MsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBSSxDQUFtQixDQUFDLEVBQUMsZ0VBQWdFO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNjLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDVyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFJLENBQWlCLENBQUMsbUJBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNXLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDUSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUF5RCxDQUFxQixDQUFDLEVBQUMsOENBQThDLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQWtCLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQVcsQ0FBbUIsQ0FBQyxFQUFDLFdBQVcsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBb0IsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBYyxDQUFtQixDQUFDLEVBQUMsc0NBQXNDLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQVksQ0FBbUIsQ0FBQyxFQUFDLGtCQUFrQixlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUFPLENBQW1CLENBQUMsRUFBQyxlQUFlLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQVcsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBVyxDQUFtQixDQUFDLEVBQUMseUtBQXlLO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNjLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDVyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFJLENBQWlCLENBQUMsbUJBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNXLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDUSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUEyQixDQUFxQixDQUFDLEVBQUMsOEJBQThCLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQVcsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBc0IsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBb0IsQ0FBbUIsQ0FBQyxFQUFDLFlBQVksZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBYSxDQUFtQixDQUFDLEVBQUMsaU5BQWlOLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQVMsQ0FBbUIsQ0FBQyxFQUFDLGdGQUFnRjtVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDYyxFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1csRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBSSxDQUFpQixDQUFDLG1CQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDVyxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBZ0QsQ0FBcUIsQ0FBQyxFQUFDLDBFQUEwRSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUFzQixDQUFtQixDQUFDLEVBQUMsVUFBVSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUE4QixDQUFtQixDQUFDLEVBQUMsNE1BQTRNLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBaUMsQ0FBcUIsQ0FBQyxFQUFDLDBGQUEwRixlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNRLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQXdDLENBQXFCLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQVcsQ0FBbUIsQ0FBQyxFQUFDLHNIQUFzSDtVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDO01BQUEsQ0FBbUIsQ0FBQztJQUFBLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ08sQ0FBQztNQUFBZSxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNRLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQWlCLENBQXFCLENBQUMsRUFBQyx1REFBdUQsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLDBCQUEwQixlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFlLENBQW1CLENBQUMsRUFBQyxzQkFBc0IsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBYSxDQUFtQixDQUFDLEVBQUMscUpBQXFKLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQXVCLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQWtCLENBQW1CLENBQUMsRUFBQyxVQUFVLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQVMsQ0FBbUIsQ0FBQyxFQUFDLGdDQUFnQyxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFhLENBQW1CLENBQUMsRUFBQyxvTEFBb0wsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDUSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFtQixDQUFxQixDQUFDLEVBQUMsa0hBQWtIO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDSyxFQUFFO01BQUNrQixFQUFFLEVBQUMsaUJBQWlCO01BQUFELFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBaUIsQ0FBRSxDQUFDLEVBQUMsZUFBZTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1MsS0FBSztNQUFBYSxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNhLEtBQUs7UUFBQVMsUUFBQSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNjLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDWSxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFNLENBQWlCLENBQUMsbUJBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNZLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQU0sQ0FBaUIsQ0FBQztRQUFBLENBQWdCO01BQUMsQ0FBbUIsQ0FBQyxtQkFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1UsS0FBSztRQUFBWSxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNjLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDVyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFTLENBQWlCLENBQUMsbUJBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNXLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBa0IsQ0FBbUIsQ0FBQyxFQUFDLGlIQUFpSDtVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDYyxFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1csRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBUyxDQUFpQixDQUFDLG1CQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDVyxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQXFCLENBQW1CLENBQUMsRUFBQyxpQ0FBaUMsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBSSxDQUFtQixDQUFDLEVBQUMsa0NBQWtDO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNjLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDVyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFTLENBQWlCLENBQUMsbUJBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNXLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBdUIsQ0FBbUIsQ0FBQyxFQUFDLHlDQUF5QyxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUFxQixDQUFtQixDQUFDLEVBQUMsbURBQW1EO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNjLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDVyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFTLENBQWlCLENBQUMsbUJBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNXLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBcUIsQ0FBbUIsQ0FBQyxFQUFDLHlNQUF5TTtVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDYyxFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1csRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBUyxDQUFpQixDQUFDLG1CQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDVyxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQXFCLENBQW1CLENBQUMsRUFBQywyQkFBMkIsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBVyxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUFXLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQVMsQ0FBbUIsQ0FBQyxFQUFDLHVCQUF1QixlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUFlLENBQW1CLENBQUMsRUFBQyxvREFBb0Q7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ2MsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNXLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQVMsQ0FBaUIsQ0FBQyxtQkFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1csRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUF5QixDQUFtQixDQUFDLEVBQUMscUpBQXFKO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNjLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDVyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFTLENBQWlCLENBQUMsbUJBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNXLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBdUIsQ0FBbUIsQ0FBQyxFQUFDLHNCQUFzQixlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUFxQixDQUFtQixDQUFDLEVBQUMscUJBQXFCLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQVMsQ0FBbUIsQ0FBQztVQUFBLENBQWdCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDYyxFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1csRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBUyxDQUFpQixDQUFDLG1CQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDVyxFQUFFO1lBQUFXLFFBQUEsR0FBRSxtQkFBbUIsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBd0IsQ0FBbUIsQ0FBQyxFQUFDLDhCQUE4QixlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUFxQixDQUFtQixDQUFDLEVBQUMseUJBQXlCO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNjLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDVyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFTLENBQWlCLENBQUMsbUJBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNXLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBZ0MsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBb0IsQ0FBbUIsQ0FBQyxFQUFDLG9DQUFvQztVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDYyxFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1csRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBVSxDQUFpQixDQUFDLG1CQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDVyxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQWMsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBUyxDQUFtQixDQUFDLEVBQUMsa0VBQWtFO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUM7TUFBQSxDQUFtQixDQUFDO0lBQUEsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDTyxDQUFDO01BQUFlLFFBQUEsZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDUSxNQUFNO1FBQUFjLFFBQUEsR0FBRSx1REFBdUQsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsbVRBQW1UO01BQUEsQ0FBcUI7SUFBQyxDQUFlLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0ksRUFBRTtNQUFDbUIsRUFBRSxFQUFDLGdCQUFnQjtNQUFBRCxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQWdCLENBQUUsQ0FBQyxFQUFDLGdCQUFnQjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ08sQ0FBQztNQUFBZSxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNRLE1BQU07UUFBQWMsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBWSxDQUFtQixDQUFDLEVBQUMsbUJBQW1CO01BQUEsQ0FBcUIsQ0FBQyxFQUFDLGtCQUFrQixlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUEwQixDQUFtQixDQUFDLEVBQUMsc0VBQXNFLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBNkMsQ0FBcUIsQ0FBQyxFQUFDLHFEQUFxRCxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFNLENBQW1CLENBQUMsRUFBQywyWkFBMlosZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBVyxDQUFtQixDQUFDLEVBQUMsR0FBRztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ08sQ0FBQztNQUFBZSxRQUFBLEdBQUUsV0FBVyxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFZLENBQW1CLENBQUMsRUFBQyxnVkFBZ1Y7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNLLEVBQUU7TUFBQ2tCLEVBQUUsRUFBQyw2RkFBNkY7TUFBQUQsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUE2RixDQUFFLENBQUMsRUFBQyxtR0FBbUc7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNPLENBQUM7TUFBQWUsUUFBQSxFQUFFO0lBQXdJLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ2UsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNNLEVBQUU7UUFBQWdCLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBcUIsQ0FBcUIsQ0FBQyxFQUFDLGdDQUFnQyxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyxhQUFhLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQThCLENBQW1CLENBQUMsRUFBQyxPQUFPLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQU0sQ0FBbUIsQ0FBQyxFQUFDLHlHQUF5RztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ00sRUFBRTtRQUFBZ0IsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDUSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUE2QyxDQUFxQixDQUFDLEVBQUMsMEtBQTBLO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDTSxFQUFFO1FBQUFnQixRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNRLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWlHLENBQXFCLENBQUMsRUFBQywwQkFBMEIsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBNkcsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDUSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUE4RCxDQUFxQixDQUFDLEVBQUMsdUVBQXVFLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0UsRUFBRTtVQUFBb0IsUUFBQSxFQUFFO1FBQWUsQ0FBaUIsQ0FBQyxFQUFDLFlBQVksZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDQyxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBb0IsQ0FBbUIsQ0FBQyxFQUFDLDZCQUE2QixlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNRLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQU8sQ0FBcUIsQ0FBQyxFQUFDLG9RQUFvUSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyx1REFBdUQsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDUSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUEwSCxDQUFxQixDQUFDLEVBQUMsZ1BBQWdQLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBeUIsQ0FBcUIsQ0FBQyxFQUFDLEdBQUc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUM7RUFBQSxDQUFFLENBQUM7QUFDbHVzQjtBQUNlLFNBQVNHLFVBQVVBLENBQUMxQixLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUU7RUFDN0MsTUFBTTtJQUFDMkIsT0FBTyxFQUFFQztFQUFTLENBQUMsR0FBRztJQUMzQixHQUFHLElBQUFYLDZCQUFrQixFQUFDLENBQUM7SUFDdkIsR0FBR2pCLEtBQUssQ0FBQ2tCO0VBQ1gsQ0FBQztFQUNELE9BQU9VLFNBQVMsZ0JBQUcsSUFBQTlCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ0csU0FBUztJQUFBLEdBQUs1QixLQUFLO0lBQUF1QixRQUFBLGVBQUUsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQzFCLGlCQUFpQjtNQUFBLEdBQUtDO0lBQUssQ0FBRztFQUFDLENBQVcsQ0FBQyxHQUFHRCxpQkFBaUIsQ0FBQ0MsS0FBSyxDQUFDO0FBQ2xIO0FBQUM2QixFQUFBLEdBTnVCSCxVQUFVO0FBT2xDLFNBQVNOLG9CQUFvQkEsQ0FBQ0ksRUFBRSxFQUFFTSxTQUFTLEVBQUVDLEtBQUssRUFBRTtFQUNsRCxNQUFNLElBQUlDLEtBQUssQ0FBQyxXQUFXLElBQUlGLFNBQVMsR0FBRyxXQUFXLEdBQUcsUUFBUSxDQUFDLEdBQUcsSUFBSSxHQUFHTixFQUFFLEdBQUcsb0VBQW9FLElBQUlPLEtBQUssR0FBRyxxQ0FBcUMsR0FBR0EsS0FBSyxHQUFHLHNEQUFzRCxHQUFHLEVBQUUsQ0FBQyxDQUFDO0FBQ2hSO0FBQUMsSUFBQUYsRUFBQTtBQUFBSSxZQUFBLENBQUFKLEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}