var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      blockquote: "blockquote",
      code: "code",
      del: "del",
      em: "em",
      h1: "h1",
      h2: "h2",
      li: "li",
      p: "p",
      strong: "strong",
      table: "table",
      tbody: "tbody",
      td: "td",
      th: "th",
      thead: "thead",
      tr: "tr",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "whatif_shadow_evaluation-implementation-status",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "whatif_shadow_evaluation-implementation-status"
      }), "WHATIF_SHADOW_EVALUATION — implementation status"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Status:"
      }), " implemented at the deliverable level (R3-395, R3-396, R3-397) · ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Updated:"
      }), " 2026-08-28"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.em, {
          children: ["2026-08-28 — what-if panel collapsed by default (spec §1.1 amendment): the formula\nrow gained the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "what if →"
          }), " door, the section auto-reopens while a variant differs from\nthe document formula, and the duplicate formula rendering user feedback flagged is gone."]
        })
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["This document is the single implementation-status source for\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "docs/specs/WHATIF_SHADOW_EVALUATION_SPEC.md"
      }), "; where they disagree, this document governs."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "shipped-2026-08-27",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "shipped-2026-08-27"
      }), "Shipped (2026-08-27)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "R3-395 — shadow-run core."
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "AsyncEngine.settledSnapshot()"
        }), " (quiescent, coherent,\nstructured-clone-copied ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "(pass, externals)"
        }), " pair — spec §2.1), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "WorkerTransport.dispose()"
        }), "\n(both transports), the line-anchored worksheet transform (spec §3.3), the\nunique-occurrence splice with typed refusals (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/engine/shadow.ts"
        }), "), source patching\n(variants + the reserved ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "scratch"
        }), " worksheet), the dependents closure, the\npinned-baseline value/verdict diffs, the shadow xref re-validation and the\ndurable-subject scratch-test refusal (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/app/whatif.ts"
        }), "), and session retention of\nsources / loaded document / runtime feeds (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/app/reportSession.ts"
        }), ")."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "R3-396 — the what-if panel."
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/app/WhatIfPanel.tsx"
        }), " (effectful shell) +\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/app/WhatIfResult.tsx"
        }), " (pure readout) under the value inspector dock; App-owned\nper-cell variant text (spec §1.4); explicit Run through ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/hooks/useShadowRunner.ts"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "R3-397 — the scratch pad."
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/app/ScratchPad.tsx"
        }), " in the workbook panel: buffer\neditor, Run, scratch cards through ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "WorkbookPanelBody"
        }), ", collision disable, surfaced\ndiagnostics/refusals, arm-then-confirm Clear, guarded Copy; App-owned buffer text."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "gate-coverage",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "gate-coverage"
      }), "Gate coverage"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Gate"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Test"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-WIF-1"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/engine/shadow.test.ts"
            }), " (splice: unique / not-found / identical / substring)"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-WIF-1a"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/engine/compartment.test.ts"
            }), " (line-anchored transform round-trip)"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-WIF-2"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/app/whatif.test.ts"
            }), " (base bit-identical; row-mutating variant contained)"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-WIF-3"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/app/whatif.test.ts"
            }), " (settled coherence; feed buffers present; copies)"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-WIF-4"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/app/whatif.test.ts"
            }), " (delta ⊆ closure; moving-base zero-delta)"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-WIF-5"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/app/whatif.test.ts"
            }), " (scratch additive over values and cards)"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-WIF-6"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/app/whatif.test.ts"
            }), " (variant flips shadow verdict; base untouched)"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-WIF-6a"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/app/whatif.test.ts"
            }), " (durable-subject scratch test refused)"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-WIF-7"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/engine/workerTransport.test.ts"
            }), " (dispose delivers/accepts nothing)"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-WIF-8"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/engine/shadow.test.ts"
            }), " + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/app/ScratchPad.test.tsx"
            }), " (collision refused/disabled)"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-WIF-9"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/app/whatifCaldera.test.ts"
            }), " (real Caldera doc; oracle-matched outside closure)"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-WIF-10"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/app/whatif.test.ts"
            }), " (typo'd external → visible diagnostic)"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-WIF-11"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["App-owned buffer state (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/App.tsx"
            }), ") + arm-then-confirm Clear (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "ScratchPad.tsx"
            }), "); surface halves render-tested in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "ScratchPad.test.tsx"
            })]
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "measurements",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "measurements"
      }), "Measurements"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Node harness (indicative only, not a browser claim — spec §2.3):"
        }), " a full shadow run\nover the Caldera LBO document (build + pass incl. the 25-run sensitivity grid and the\ngoal-seek + suite) completes in ~130 ms inside the vitest harness. The browser-side\nmeasurement the spec books before any continuous-evaluation mode (Q1) remains ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "open"
        }), "."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "open-residuals-unchanged-from-the-spec",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "open-residuals-unchanged-from-the-spec"
      }), "Open residuals (unchanged from the spec)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: "In-process transport: no realm isolation/lockdown, and a synchronously divergent\nvariant is unrecoverable (spec §5 — named residual; self-resolves with real workers\nin-platform; Q7 books the lockdown alternative)."
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.del, {
          children: "Splice refusal rate on short/duplicated formulas"
        }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "closed 2026-08-28 by R3-427"
        }), ":\ndescriptors carry declaration-block spans; the splice patches within the varied cell's\nown block (cross-cell duplicates/substrings no longer refuse), and the inspector shows\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "file:line"
        }), " for formulas and tests. Open-at-line ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "links"
        }), " still ride the navigator work", "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
          children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
            children: "the editor line-hint delta."
          }), "\n"]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: "Scratch-text reload persistence; apply/promote; sweeps; the structured mobile variant\nflow (Q6); ad-hoc scratch tests on durable subjects (Q5)."
      }), "\n"]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/status/WHATIF_SHADOW_EVALUATION_STATUS.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJibG9ja3F1b3RlIiwiY29kZSIsImRlbCIsImVtIiwiaDEiLCJoMiIsImxpIiwicCIsInN0cm9uZyIsInRhYmxlIiwidGJvZHkiLCJ0ZCIsInRoIiwidGhlYWQiLCJ0ciIsInVsIiwiX3Byb3ZpZGVDb21wb25lbnRzIiwiY29tcG9uZW50cyIsIkhlYWRpbmdBbmNob3IiLCJfbWlzc2luZ01keFJlZmVyZW5jZSIsImpzeHMiLCJGcmFnbWVudCIsImNoaWxkcmVuIiwiaWQiLCJqc3giLCJNRFhDb250ZW50Iiwid3JhcHBlciIsIk1EWExheW91dCIsIl9jIiwiY29tcG9uZW50IiwicGxhY2UiLCJFcnJvciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIldIQVRJRl9TSEFET1dfRVZBTFVBVElPTl9TVEFUVVMubWQiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgYmxvY2txdW90ZTogXCJibG9ja3F1b3RlXCIsXG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgZGVsOiBcImRlbFwiLFxuICAgIGVtOiBcImVtXCIsXG4gICAgaDE6IFwiaDFcIixcbiAgICBoMjogXCJoMlwiLFxuICAgIGxpOiBcImxpXCIsXG4gICAgcDogXCJwXCIsXG4gICAgc3Ryb25nOiBcInN0cm9uZ1wiLFxuICAgIHRhYmxlOiBcInRhYmxlXCIsXG4gICAgdGJvZHk6IFwidGJvZHlcIixcbiAgICB0ZDogXCJ0ZFwiLFxuICAgIHRoOiBcInRoXCIsXG4gICAgdGhlYWQ6IFwidGhlYWRcIixcbiAgICB0cjogXCJ0clwiLFxuICAgIHVsOiBcInVsXCIsXG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9LCB7SGVhZGluZ0FuY2hvcn0gPSBfY29tcG9uZW50cztcbiAgaWYgKCFIZWFkaW5nQW5jaG9yKSBfbWlzc2luZ01keFJlZmVyZW5jZShcIkhlYWRpbmdBbmNob3JcIiwgdHJ1ZSk7XG4gIHJldHVybiA8PjxfY29tcG9uZW50cy5oMSBpZD1cIndoYXRpZl9zaGFkb3dfZXZhbHVhdGlvbi1pbXBsZW1lbnRhdGlvbi1zdGF0dXNcIj48SGVhZGluZ0FuY2hvciBpZD1cIndoYXRpZl9zaGFkb3dfZXZhbHVhdGlvbi1pbXBsZW1lbnRhdGlvbi1zdGF0dXNcIiAvPntcIldIQVRJRl9TSEFET1dfRVZBTFVBVElPTiDigJQgaW1wbGVtZW50YXRpb24gc3RhdHVzXCJ9PC9fY29tcG9uZW50cy5oMT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlN0YXR1czpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgaW1wbGVtZW50ZWQgYXQgdGhlIGRlbGl2ZXJhYmxlIGxldmVsIChSMy0zOTUsIFIzLTM5NiwgUjMtMzk3KSDCtyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlVwZGF0ZWQ6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIDIwMjYtMDgtMjhcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLmVtPntcIjIwMjYtMDgtMjgg4oCUIHdoYXQtaWYgcGFuZWwgY29sbGFwc2VkIGJ5IGRlZmF1bHQgKHNwZWMgwqcxLjEgYW1lbmRtZW50KTogdGhlIGZvcm11bGFcXG5yb3cgZ2FpbmVkIHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ3aGF0IGlmIOKGklwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZG9vciwgdGhlIHNlY3Rpb24gYXV0by1yZW9wZW5zIHdoaWxlIGEgdmFyaWFudCBkaWZmZXJzIGZyb21cXG50aGUgZG9jdW1lbnQgZm9ybXVsYSwgYW5kIHRoZSBkdXBsaWNhdGUgZm9ybXVsYSByZW5kZXJpbmcgdXNlciBmZWVkYmFjayBmbGFnZ2VkIGlzIGdvbmUuXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoaXMgZG9jdW1lbnQgaXMgdGhlIHNpbmdsZSBpbXBsZW1lbnRhdGlvbi1zdGF0dXMgc291cmNlIGZvclxcblwifTxfY29tcG9uZW50cy5jb2RlPntcImRvY3Mvc3BlY3MvV0hBVElGX1NIQURPV19FVkFMVUFUSU9OX1NQRUMubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiOyB3aGVyZSB0aGV5IGRpc2FncmVlLCB0aGlzIGRvY3VtZW50IGdvdmVybnMuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInNoaXBwZWQtMjAyNi0wOC0yN1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2hpcHBlZC0yMDI2LTA4LTI3XCIgLz57XCJTaGlwcGVkICgyMDI2LTA4LTI3KVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlIzLTM5NSDigJQgc2hhZG93LXJ1biBjb3JlLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJBc3luY0VuZ2luZS5zZXR0bGVkU25hcHNob3QoKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKHF1aWVzY2VudCwgY29oZXJlbnQsXFxuc3RydWN0dXJlZC1jbG9uZS1jb3BpZWQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiKHBhc3MsIGV4dGVybmFscylcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHBhaXIg4oCUIHNwZWMgwqcyLjEpLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJXb3JrZXJUcmFuc3BvcnQuZGlzcG9zZSgpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIlxcbihib3RoIHRyYW5zcG9ydHMpLCB0aGUgbGluZS1hbmNob3JlZCB3b3Jrc2hlZXQgdHJhbnNmb3JtIChzcGVjIMKnMy4zKSwgdGhlXFxudW5pcXVlLW9jY3VycmVuY2Ugc3BsaWNlIHdpdGggdHlwZWQgcmVmdXNhbHMgKFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9lbmdpbmUvc2hhZG93LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiksIHNvdXJjZSBwYXRjaGluZ1xcbih2YXJpYW50cyArIHRoZSByZXNlcnZlZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzY3JhdGNoXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB3b3Jrc2hlZXQpLCB0aGUgZGVwZW5kZW50cyBjbG9zdXJlLCB0aGVcXG5waW5uZWQtYmFzZWxpbmUgdmFsdWUvdmVyZGljdCBkaWZmcywgdGhlIHNoYWRvdyB4cmVmIHJlLXZhbGlkYXRpb24gYW5kIHRoZVxcbmR1cmFibGUtc3ViamVjdCBzY3JhdGNoLXRlc3QgcmVmdXNhbCAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2FwcC93aGF0aWYudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSwgYW5kIHNlc3Npb24gcmV0ZW50aW9uIG9mXFxuc291cmNlcyAvIGxvYWRlZCBkb2N1bWVudCAvIHJ1bnRpbWUgZmVlZHMgKFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9hcHAvcmVwb3J0U2Vzc2lvbi50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUjMtMzk2IOKAlCB0aGUgd2hhdC1pZiBwYW5lbC5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2FwcC9XaGF0SWZQYW5lbC50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChlZmZlY3RmdWwgc2hlbGwpICtcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvYXBwL1doYXRJZlJlc3VsdC50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChwdXJlIHJlYWRvdXQpIHVuZGVyIHRoZSB2YWx1ZSBpbnNwZWN0b3IgZG9jazsgQXBwLW93bmVkXFxucGVyLWNlbGwgdmFyaWFudCB0ZXh0IChzcGVjIMKnMS40KTsgZXhwbGljaXQgUnVuIHRocm91Z2ggXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2hvb2tzL3VzZVNoYWRvd1J1bm5lci50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJSMy0zOTcg4oCUIHRoZSBzY3JhdGNoIHBhZC5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2FwcC9TY3JhdGNoUGFkLnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaW4gdGhlIHdvcmtib29rIHBhbmVsOiBidWZmZXJcXG5lZGl0b3IsIFJ1biwgc2NyYXRjaCBjYXJkcyB0aHJvdWdoIFwifTxfY29tcG9uZW50cy5jb2RlPntcIldvcmtib29rUGFuZWxCb2R5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgY29sbGlzaW9uIGRpc2FibGUsIHN1cmZhY2VkXFxuZGlhZ25vc3RpY3MvcmVmdXNhbHMsIGFybS10aGVuLWNvbmZpcm0gQ2xlYXIsIGd1YXJkZWQgQ29weTsgQXBwLW93bmVkIGJ1ZmZlciB0ZXh0LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJnYXRlLWNvdmVyYWdlXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJnYXRlLWNvdmVyYWdlXCIgLz57XCJHYXRlIGNvdmVyYWdlXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMudGFibGU+PF9jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGg+e1wiR2F0ZVwifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIlRlc3RcIn08L19jb21wb25lbnRzLnRoPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudGJvZHk+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJHLVdJRi0xXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2VuZ2luZS9zaGFkb3cudGVzdC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKHNwbGljZTogdW5pcXVlIC8gbm90LWZvdW5kIC8gaWRlbnRpY2FsIC8gc3Vic3RyaW5nKVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkctV0lGLTFhXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2VuZ2luZS9jb21wYXJ0bWVudC50ZXN0LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAobGluZS1hbmNob3JlZCB0cmFuc2Zvcm0gcm91bmQtdHJpcClcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJHLVdJRi0yXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2FwcC93aGF0aWYudGVzdC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKGJhc2UgYml0LWlkZW50aWNhbDsgcm93LW11dGF0aW5nIHZhcmlhbnQgY29udGFpbmVkKVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkctV0lGLTNcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJzcmMvYXBwL3doYXRpZi50ZXN0LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoc2V0dGxlZCBjb2hlcmVuY2U7IGZlZWQgYnVmZmVycyBwcmVzZW50OyBjb3BpZXMpXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiRy1XSUYtNFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcInNyYy9hcHAvd2hhdGlmLnRlc3QudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChkZWx0YSDiioYgY2xvc3VyZTsgbW92aW5nLWJhc2UgemVyby1kZWx0YSlcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJHLVdJRi01XCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2FwcC93aGF0aWYudGVzdC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKHNjcmF0Y2ggYWRkaXRpdmUgb3ZlciB2YWx1ZXMgYW5kIGNhcmRzKVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkctV0lGLTZcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJzcmMvYXBwL3doYXRpZi50ZXN0LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAodmFyaWFudCBmbGlwcyBzaGFkb3cgdmVyZGljdDsgYmFzZSB1bnRvdWNoZWQpXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiRy1XSUYtNmFcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJzcmMvYXBwL3doYXRpZi50ZXN0LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoZHVyYWJsZS1zdWJqZWN0IHNjcmF0Y2ggdGVzdCByZWZ1c2VkKVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkctV0lGLTdcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJzcmMvZW5naW5lL3dvcmtlclRyYW5zcG9ydC50ZXN0LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoZGlzcG9zZSBkZWxpdmVycy9hY2NlcHRzIG5vdGhpbmcpXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiRy1XSUYtOFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcInNyYy9lbmdpbmUvc2hhZG93LnRlc3QudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2FwcC9TY3JhdGNoUGFkLnRlc3QudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoY29sbGlzaW9uIHJlZnVzZWQvZGlzYWJsZWQpXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiRy1XSUYtOVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcInNyYy9hcHAvd2hhdGlmQ2FsZGVyYS50ZXN0LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAocmVhbCBDYWxkZXJhIGRvYzsgb3JhY2xlLW1hdGNoZWQgb3V0c2lkZSBjbG9zdXJlKVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkctV0lGLTEwXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2FwcC93aGF0aWYudGVzdC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKHR5cG8nZCBleHRlcm5hbCDihpIgdmlzaWJsZSBkaWFnbm9zdGljKVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkctV0lGLTExXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiQXBwLW93bmVkIGJ1ZmZlciBzdGF0ZSAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL0FwcC50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSArIGFybS10aGVuLWNvbmZpcm0gQ2xlYXIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIlNjcmF0Y2hQYWQudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIik7IHN1cmZhY2UgaGFsdmVzIHJlbmRlci10ZXN0ZWQgaW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiU2NyYXRjaFBhZC50ZXN0LnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50Ym9keT48L19jb21wb25lbnRzLnRhYmxlPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cIm1lYXN1cmVtZW50c1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwibWVhc3VyZW1lbnRzXCIgLz57XCJNZWFzdXJlbWVudHNcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJOb2RlIGhhcm5lc3MgKGluZGljYXRpdmUgb25seSwgbm90IGEgYnJvd3NlciBjbGFpbSDigJQgc3BlYyDCpzIuMyk6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGEgZnVsbCBzaGFkb3cgcnVuXFxub3ZlciB0aGUgQ2FsZGVyYSBMQk8gZG9jdW1lbnQgKGJ1aWxkICsgcGFzcyBpbmNsLiB0aGUgMjUtcnVuIHNlbnNpdGl2aXR5IGdyaWQgYW5kIHRoZVxcbmdvYWwtc2VlayArIHN1aXRlKSBjb21wbGV0ZXMgaW4gfjEzMCBtcyBpbnNpZGUgdGhlIHZpdGVzdCBoYXJuZXNzLiBUaGUgYnJvd3Nlci1zaWRlXFxubWVhc3VyZW1lbnQgdGhlIHNwZWMgYm9va3MgYmVmb3JlIGFueSBjb250aW51b3VzLWV2YWx1YXRpb24gbW9kZSAoUTEpIHJlbWFpbnMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJvcGVuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJvcGVuLXJlc2lkdWFscy11bmNoYW5nZWQtZnJvbS10aGUtc3BlY1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwib3Blbi1yZXNpZHVhbHMtdW5jaGFuZ2VkLWZyb20tdGhlLXNwZWNcIiAvPntcIk9wZW4gcmVzaWR1YWxzICh1bmNoYW5nZWQgZnJvbSB0aGUgc3BlYylcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiSW4tcHJvY2VzcyB0cmFuc3BvcnQ6IG5vIHJlYWxtIGlzb2xhdGlvbi9sb2NrZG93biwgYW5kIGEgc3luY2hyb25vdXNseSBkaXZlcmdlbnRcXG52YXJpYW50IGlzIHVucmVjb3ZlcmFibGUgKHNwZWMgwqc1IOKAlCBuYW1lZCByZXNpZHVhbDsgc2VsZi1yZXNvbHZlcyB3aXRoIHJlYWwgd29ya2Vyc1xcbmluLXBsYXRmb3JtOyBRNyBib29rcyB0aGUgbG9ja2Rvd24gYWx0ZXJuYXRpdmUpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5kZWw+e1wiU3BsaWNlIHJlZnVzYWwgcmF0ZSBvbiBzaG9ydC9kdXBsaWNhdGVkIGZvcm11bGFzXCJ9PC9fY29tcG9uZW50cy5kZWw+e1wiIOKAlCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImNsb3NlZCAyMDI2LTA4LTI4IGJ5IFIzLTQyN1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIjpcXG5kZXNjcmlwdG9ycyBjYXJyeSBkZWNsYXJhdGlvbi1ibG9jayBzcGFuczsgdGhlIHNwbGljZSBwYXRjaGVzIHdpdGhpbiB0aGUgdmFyaWVkIGNlbGwnc1xcbm93biBibG9jayAoY3Jvc3MtY2VsbCBkdXBsaWNhdGVzL3N1YnN0cmluZ3Mgbm8gbG9uZ2VyIHJlZnVzZSksIGFuZCB0aGUgaW5zcGVjdG9yIHNob3dzXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZmlsZTpsaW5lXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBmb3IgZm9ybXVsYXMgYW5kIHRlc3RzLiBPcGVuLWF0LWxpbmUgXCJ9PF9jb21wb25lbnRzLmVtPntcImxpbmtzXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgc3RpbGwgcmlkZSB0aGUgbmF2aWdhdG9yIHdvcmtcIn17XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcInRoZSBlZGl0b3IgbGluZS1oaW50IGRlbHRhLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJTY3JhdGNoLXRleHQgcmVsb2FkIHBlcnNpc3RlbmNlOyBhcHBseS9wcm9tb3RlOyBzd2VlcHM7IHRoZSBzdHJ1Y3R1cmVkIG1vYmlsZSB2YXJpYW50XFxuZmxvdyAoUTYpOyBhZC1ob2Mgc2NyYXRjaCB0ZXN0cyBvbiBkdXJhYmxlIHN1YmplY3RzIChRNSkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPjwvPjtcbn1cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE1EWENvbnRlbnQocHJvcHMgPSB7fSkge1xuICBjb25zdCB7d3JhcHBlcjogTURYTGF5b3V0fSA9IHtcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH07XG4gIHJldHVybiBNRFhMYXlvdXQgPyA8TURYTGF5b3V0IHsuLi5wcm9wc30+PF9jcmVhdGVNZHhDb250ZW50IHsuLi5wcm9wc30gLz48L01EWExheW91dD4gOiBfY3JlYXRlTWR4Q29udGVudChwcm9wcyk7XG59XG5mdW5jdGlvbiBfbWlzc2luZ01keFJlZmVyZW5jZShpZCwgY29tcG9uZW50LCBwbGFjZSkge1xuICB0aHJvdyBuZXcgRXJyb3IoXCJFeHBlY3RlZCBcIiArIChjb21wb25lbnQgPyBcImNvbXBvbmVudFwiIDogXCJvYmplY3RcIikgKyBcIiBgXCIgKyBpZCArIFwiYCB0byBiZSBkZWZpbmVkOiB5b3UgbGlrZWx5IGZvcmdvdCB0byBpbXBvcnQsIHBhc3MsIG9yIHByb3ZpZGUgaXQuXCIgKyAocGxhY2UgPyBcIlxcbkl04oCZcyByZWZlcmVuY2VkIGluIHlvdXIgY29kZSBhdCBgXCIgKyBwbGFjZSArIFwiYCBpbiBgL2FwcC9kb2NzL3N0YXR1cy9XSEFUSUZfU0hBRE9XX0VWQUxVQVRJT05fU1RBVFVTLm1kYFwiIDogXCJcIikpO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFFQSxJQUFBQSxZQUFBLEdBQUFDLE9BQUE7QUFBd0YsSUFBQUMsV0FBQSxHQUFBRCxPQUFBO0FBRnhGO0FBQ0E7O0FBRUEsU0FBU0UsaUJBQWlCQSxDQUFDQyxLQUFLLEVBQUU7RUFDaEMsTUFBTUMsV0FBVyxHQUFHO01BQ2xCQyxVQUFVLEVBQUUsWUFBWTtNQUN4QkMsSUFBSSxFQUFFLE1BQU07TUFDWkMsR0FBRyxFQUFFLEtBQUs7TUFDVkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsTUFBTSxFQUFFLFFBQVE7TUFDaEJDLEtBQUssRUFBRSxPQUFPO01BQ2RDLEtBQUssRUFBRSxPQUFPO01BQ2RDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEtBQUssRUFBRSxPQUFPO01BQ2RDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1IsR0FBRyxJQUFBQyw2QkFBa0IsRUFBQyxDQUFDO01BQ3ZCLEdBQUdsQixLQUFLLENBQUNtQjtJQUNYLENBQUM7SUFBRTtNQUFDQztJQUFhLENBQUMsR0FBR25CLFdBQVc7RUFDaEMsSUFBSSxDQUFDbUIsYUFBYSxFQUFFQyxvQkFBb0IsQ0FBQyxlQUFlLEVBQUUsSUFBSSxDQUFDO0VBQy9ELG9CQUFPLElBQUF2QixXQUFBLENBQUF3QixJQUFBLEVBQUF4QixXQUFBLENBQUF5QixRQUFBO0lBQUFDLFFBQUEsZ0JBQUUsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDbUIsRUFBRSxFQUFDLGdEQUFnRDtNQUFBRCxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQWdELENBQUUsQ0FBQyxFQUFDLGtEQUFrRDtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1EsQ0FBQztNQUFBZSxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVMsQ0FBcUIsQ0FBQyxFQUFDLG1FQUFtRSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVUsQ0FBcUIsQ0FBQyxFQUFDLGFBQWE7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNDLFVBQVU7TUFBQXNCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1EsQ0FBQztRQUFBZSxRQUFBLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0ksRUFBRTtVQUFBbUIsUUFBQSxHQUFFLHFHQUFxRyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7WUFBQXFCLFFBQUEsRUFBRTtVQUFXLENBQW1CLENBQUMsRUFBQyx3SkFBd0o7UUFBQSxDQUFpQjtNQUFDLENBQWUsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUF5QixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNRLENBQUM7TUFBQWUsUUFBQSxHQUFFLGdFQUFnRSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUE2QyxDQUFtQixDQUFDLEVBQUMsK0NBQStDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDTSxFQUFFO01BQUNrQixFQUFFLEVBQUMsb0JBQW9CO01BQUFELFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBb0IsQ0FBRSxDQUFDLEVBQUMsc0JBQXNCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDZ0IsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNPLEVBQUU7UUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBMkIsQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBK0IsQ0FBbUIsQ0FBQyxFQUFDLGtEQUFrRCxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFtQixDQUFtQixDQUFDLEVBQUMsc0JBQXNCLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQTJCLENBQW1CLENBQUMsRUFBQyw2SEFBNkgsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBc0IsQ0FBbUIsQ0FBQyxFQUFDLCtDQUErQyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFTLENBQW1CLENBQUMsRUFBQyw4SkFBOEosZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBbUIsQ0FBbUIsQ0FBQyxFQUFDLDBFQUEwRSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUEwQixDQUFtQixDQUFDLEVBQUMsSUFBSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBZ0IsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUE2QixDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUF5QixDQUFtQixDQUFDLEVBQUMsd0JBQXdCLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQTBCLENBQW1CLENBQUMsRUFBQyxxSEFBcUgsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBOEIsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNPLEVBQUU7UUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBMkIsQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBd0IsQ0FBbUIsQ0FBQyxFQUFDLHFFQUFxRSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFtQixDQUFtQixDQUFDLEVBQUMsbUhBQW1IO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNNLEVBQUU7TUFBQ2tCLEVBQUUsRUFBQyxlQUFlO01BQUFELFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBZSxDQUFFLENBQUMsRUFBQyxlQUFlO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDVSxLQUFLO01BQUFhLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ2MsS0FBSztRQUFBUyxRQUFBLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ2UsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNhLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQU0sQ0FBaUIsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBTSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0I7TUFBQyxDQUFtQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDVyxLQUFLO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ2UsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQVMsQ0FBaUIsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUEyQixDQUFtQixDQUFDLEVBQUMsdURBQXVEO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNlLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFVLENBQWlCLENBQUMsbUJBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBZ0MsQ0FBbUIsQ0FBQyxFQUFDLHVDQUF1QztVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDZSxFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBUyxDQUFpQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQXdCLENBQW1CLENBQUMsRUFBQyx1REFBdUQ7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ2UsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQVMsQ0FBaUIsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUF3QixDQUFtQixDQUFDLEVBQUMsb0RBQW9EO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNlLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFTLENBQWlCLENBQUMsbUJBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBd0IsQ0FBbUIsQ0FBQyxFQUFDLDRDQUE0QztVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDZSxFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBUyxDQUFpQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQXdCLENBQW1CLENBQUMsRUFBQywyQ0FBMkM7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ2UsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQVMsQ0FBaUIsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUF3QixDQUFtQixDQUFDLEVBQUMsaURBQWlEO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNlLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFVLENBQWlCLENBQUMsbUJBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBd0IsQ0FBbUIsQ0FBQyxFQUFDLHlDQUF5QztVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDZSxFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBUyxDQUFpQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQW9DLENBQW1CLENBQUMsRUFBQyxxQ0FBcUM7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ2UsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQVMsQ0FBaUIsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUEyQixDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUE2QixDQUFtQixDQUFDLEVBQUMsK0JBQStCO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNlLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFTLENBQWlCLENBQUMsbUJBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBK0IsQ0FBbUIsQ0FBQyxFQUFDLHFEQUFxRDtVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDZSxFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBVSxDQUFpQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQXdCLENBQW1CLENBQUMsRUFBQyx5Q0FBeUM7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ2UsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQVUsQ0FBaUIsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLEdBQUUsMEJBQTBCLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQWEsQ0FBbUIsQ0FBQyxFQUFDLDhCQUE4QixlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUFnQixDQUFtQixDQUFDLEVBQUMscUNBQXFDLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQXFCLENBQW1CLENBQUM7VUFBQSxDQUFnQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQztNQUFBLENBQW1CLENBQUM7SUFBQSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNNLEVBQUU7TUFBQ2tCLEVBQUUsRUFBQyxjQUFjO01BQUFELFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBYyxDQUFFLENBQUMsRUFBQyxjQUFjO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDZ0IsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNPLEVBQUU7UUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBa0UsQ0FBcUIsQ0FBQyxFQUFDLGdSQUFnUixlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQU0sQ0FBcUIsQ0FBQyxFQUFDLEdBQUc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDa0IsRUFBRSxFQUFDLHdDQUF3QztNQUFBRCxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQXdDLENBQUUsQ0FBQyxFQUFDLDBDQUEwQztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ2dCLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDTyxFQUFFO1FBQUFnQixRQUFBLEVBQUU7TUFBeU4sQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDTyxFQUFFO1FBQUFnQixRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNHLEdBQUc7VUFBQW9CLFFBQUEsRUFBRTtRQUFrRCxDQUFrQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTZCLENBQXFCLENBQUMsRUFBQyxxTEFBcUwsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsd0NBQXdDLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0ksRUFBRTtVQUFBbUIsUUFBQSxFQUFFO1FBQU8sQ0FBaUIsQ0FBQyxFQUFDLGdDQUFnQyxFQUFFLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDZ0IsRUFBRTtVQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNPLEVBQUU7WUFBQWdCLFFBQUEsRUFBRTtVQUE2QixDQUFpQixDQUFDLEVBQUMsSUFBSTtRQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDTyxFQUFFO1FBQUFnQixRQUFBLEVBQUU7TUFBa0osQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDO0VBQUEsQ0FBRSxDQUFDO0FBQ24rUTtBQUNlLFNBQVNHLFVBQVVBLENBQUMzQixLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUU7RUFDN0MsTUFBTTtJQUFDNEIsT0FBTyxFQUFFQztFQUFTLENBQUMsR0FBRztJQUMzQixHQUFHLElBQUFYLDZCQUFrQixFQUFDLENBQUM7SUFDdkIsR0FBR2xCLEtBQUssQ0FBQ21CO0VBQ1gsQ0FBQztFQUNELE9BQU9VLFNBQVMsZ0JBQUcsSUFBQS9CLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ0csU0FBUztJQUFBLEdBQUs3QixLQUFLO0lBQUF3QixRQUFBLGVBQUUsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQzNCLGlCQUFpQjtNQUFBLEdBQUtDO0lBQUssQ0FBRztFQUFDLENBQVcsQ0FBQyxHQUFHRCxpQkFBaUIsQ0FBQ0MsS0FBSyxDQUFDO0FBQ2xIO0FBQUM4QixFQUFBLEdBTnVCSCxVQUFVO0FBT2xDLFNBQVNOLG9CQUFvQkEsQ0FBQ0ksRUFBRSxFQUFFTSxTQUFTLEVBQUVDLEtBQUssRUFBRTtFQUNsRCxNQUFNLElBQUlDLEtBQUssQ0FBQyxXQUFXLElBQUlGLFNBQVMsR0FBRyxXQUFXLEdBQUcsUUFBUSxDQUFDLEdBQUcsSUFBSSxHQUFHTixFQUFFLEdBQUcsb0VBQW9FLElBQUlPLEtBQUssR0FBRyxxQ0FBcUMsR0FBR0EsS0FBSyxHQUFHLDREQUE0RCxHQUFHLEVBQUUsQ0FBQyxDQUFDO0FBQ3RSO0FBQUMsSUFBQUYsRUFBQTtBQUFBSSxZQUFBLENBQUFKLEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}