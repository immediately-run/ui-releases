var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      blockquote: "blockquote",
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      h3: "h3",
      hr: "hr",
      li: "li",
      ol: "ol",
      p: "p",
      pre: "pre",
      strong: "strong",
      table: "table",
      tbody: "tbody",
      td: "td",
      th: "th",
      thead: "thead",
      tr: "tr",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "reckoner-lbo-gap-closure-plan",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "reckoner-lbo-gap-closure-plan"
      }), "Reckoner — LBO gap-closure plan"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Status:"
      }), " plan / proposal — sequenced work items W1–W10 across milestones M0–M4, derived from the Caldera case study's gap analysis (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "LBO_CASE_STUDY_GAP_ANALYSIS.md"
      }), ", merged 2026-08-27); nothing here is scheduled · ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Updated:"
      }), " 2026-08-27"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Reads first:"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "LBO_CASE_STUDY_GAP_ANALYSIS.md",
          children: "LBO_CASE_STUDY_GAP_ANALYSIS.md"
        }), "\n(the gaps G1–G9 this plan closes), the case study itself\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "case-study/caldera/",
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "case-study/caldera/"
          })
        }), " + its proof harness\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/document/calderaCaseStudy.test.ts"
        }), " — the standing acceptance corpus for\nmost items below), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "ARCHITECTURE_PLAN.md",
          children: "ARCHITECTURE_PLAN.md"
        }), " §3.2 (the\ncommitted stdlib, additive-only forever), §6 (testing architecture),\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "specs/DOCUMENT_VERSIONING_SPEC.md",
          children: "DOCUMENT_VERSIONING_SPEC.md"
        }), " (the compat\nenvelope every stdlib/catalog addition rides), and the current wiring the\nitems touch: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/engine/testrunner.ts"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/engine/asyncEngine.ts"
        }), "\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "runTests"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "#inputsFor"
        }), "), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/engine/worker/engineWorker.ts"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "runSuites"
        }), "),\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/stdlib/relations.ts"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/document/manifest.ts"
        }), "."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["This plan turns the gap analysis into buildable, gated work. Ordering principle:\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "bug-level fixes before primitives before designs before measures"
      }), " — G6 is a\nwiring bug against the architecture plan's own §3.1 example and unblocks the\nholdout-test pattern everything else wants to use; the stdlib additions (G5, G2)\nare additive and cheap ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "now"
      }), " but permanent once frozen, so they come early; the\nconverged-cell design (G1) and the sweep-construct decision (G4) are gated on\ncheap predecessors that may make the expensive version unnecessary."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-0",
      "data-slug": "0-summary",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-0"
      }), "0 — Summary"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "#"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Gap"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Item"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Kind"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Milestone"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Size"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Exit gate (one-line)"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "W1"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G6"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Wire ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "substituteInputs"
            }), " into the test run"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "build"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "M0"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "S"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "a holdout + a fixture-oracle test in Caldera pass through the real engine"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "W2"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G7"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Tolerant invariance comparisons; selective ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "scaleInvariance"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "build"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "M0"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "S"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "adversarial float-reorder fixture passes; Caldera invariance tests unchanged-green"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "W3"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G5"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "rollforward"
            }), " + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "cumprod"
            }), " stdlib primitives"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "build"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "M1"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "M"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Caldera debt schedule + growth paths expressed with them, oracle-green"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "W4"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G2"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Financial family: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "irr"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "npv"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "xirr"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "build"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "M1"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "S–M"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Caldera returns use ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "irr"
            }), "; parity vs the hand-rolled bisection"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "W5"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G9"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Assumptions-as-params (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "paramRefs"
            }), " in the manifest)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "build"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "M2"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "M"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "tax_rate"
            }), " flipped live in the running app; only dependents recompute"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "W6"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G1a"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["stdlib ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "fixpoint"
            }), " helper (formalize the intra-cell loop)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "build"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "M2"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "S"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "debt_schedule_avg"
            }), " uses ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "fixpoint"
            }), "; convergence test unchanged"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "W7"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G1b"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Converged-cell design spike → spec"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "design"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "M3"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "M"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "spec reviewed; go/no-go on the cell kind (helper-only is a live option)"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "W8"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G4"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Sweep idiom: measure-first via the assistant"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "measure"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "M3"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "S"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "agent authors the sensitivity cell from self-descriptions alone, or the construct is justified"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "W9"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G3"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "solve"
            }), " (1-D monotone bisection helper)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "build"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "M4"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "S"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "breakeven_exit_multiple"
            }), " uses ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "solve"
            }), "; parity vs hand-rolled"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "W10"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G8"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Display formats (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "multiple"
            }), ", units, column formats)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "build"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "M4"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "S"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "the deal summary renders 2.75x / EUR m / (1,234) without bespoke cells"
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Dependency edges: W1 → (W2, W3, W4 …everything that writes tests, practically);\nW6 → W7; W4 → W9 (shared bracketing semantics); W3/W4 → W8 (the idiom needs the\nprimitives it teaches). W5 is independent."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-1",
      "data-slug": "1-work-items",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-1"
      }), "1 — Work items"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-w1",
      "data-slug": "w1-wire-test-declared-inputs-into-the-test-run-g6-build-s",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-w1"
      }), "W1 — Wire test-declared inputs into the test run (G6, build, S)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Problem."
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "testrunner.ts"
      }), " implements ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "substituteInputs"
      }), " — a test's declared\ninputs substitute for the subject's same-named inputs, unknown names fail — but\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "AsyncEngine.runTests"
      }), " builds one ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "SuiteContext"
      }), " per ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "subject"
      }), " with only\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "#inputsFor(subject)"
      }), ", and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "engineWorker.runSuites"
      }), " never calls\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "substituteInputs"
      }), ". A test can only see subject-live inputs; the holdout pattern\n(ARCHITECTURE_PLAN §3.1's first example) and fixture-fed oracles are\nunwritable. Receipt: the Caldera oracle had to be inlined as constants\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "checks.sheet.js"
      }), " GAP note)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Approach."
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["Host side: resolve each test's declared input paths (externals + published\nresults — the same resolution machinery ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "#inputsFor"
        }), " uses, lifted to operate\non a test's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "InputSpec"
        }), "s). Unresolvable reference ⇒ that test's outcome is a\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "failing"
        }), " record with the message, never a silent ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "null"
        }), " (mirrors\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "TestRunContext.error"
        }), ")."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["Protocol: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "SuiteContext"
        }), " gains per-test inputs (e.g. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "tests: {id, inputs}[]"
        }), ") — an internal host↔worker shape change, no document-format\nimpact."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["Worker side: for each test, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "substituteInputs(testInputs, subjectInputs)"
        }), "\nthen ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "runTest"
        }), " with the substituted set; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "reevaluate"
        }), " for invariance\nrelations applies transforms to the substituted inputs (so a holdout test +\na metamorphic relation compose)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Exit gates."
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["A ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "holdout test"
        }), " in Caldera: subject ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "model.operating"
        }), ", inputs substituting\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "plan"
        }), " with a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "fixtures.ops_plan_holdout"
        }), " variant (a genuinely different\nplan), asserting oracle values generated for that variant — passes through\nthe real ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "AsyncEngine.runTests"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["The ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "oracle test"
        }), " rewritten to read ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "fixtures.expected_values"
        }), " through\ntest inputs; the inlined constants in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "checks.sheet.js"
        }), " deleted."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["A test declaring a name the subject does not declare fails with\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "substituteInputs"
        }), "' message (unit test in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "testrunner.test.ts"
        }), ")."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["Verdict surface (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "suiteReport.ts"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "useVerdicts"
        }), ") unchanged — this is\ninvisible plumbing below it."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-w2",
      "data-slug": "w2-tolerant-invariance-comparisons-g7-build-s",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-w2"
      }), "W2 — Tolerant invariance comparisons (G7, build, S)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Problem."
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "permutationInvariance"
      }), " compares via strict ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "deepEqual"
      }), "; row\nreordering reorders float summation, which can differ in the last ulp (benign\nin Caldera's values — by luck). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "scaleInvariance"
      }), " scales ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "every"
      }), " numeric leaf,\nso any input carrying rates/percentages (margins, growth) breaks it — i.e. most\nfinancial inputs, permanently."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Approach."
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["Both relations accept an optional ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "tol"
        }), " (default a tiny relative tolerance,\ne.g. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "{rel: 1e-12}"
        }), ") and compare numeric leaves with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "expectClose"
        }), " semantics,\nstructure strictly. A dated note in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "relations.ts"
        }), " records this as a bugfix\nto a mis-designed comparison — behavior change inside additive-only, which\nthe spec permits for ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "corrections"
        }), " but requires recording."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "scaleInvariance"
        }), " gains ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "leaves?: string[]"
        }), " (or ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "except: string[]"
        }), ") naming\nwhich fields participate in scaling; default stays all-leaves for\nbackward compatibility."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Exit gates."
      }), " An adversarial unit test: rows whose reordered sum differs by\n1 ulp passes ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "permutationInvariance"
      }), " and would have failed ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "deepEqual"
      }), "; a\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "scaleInvariance({leaves: ['fy2026']})"
      }), " test over a rate-bearing fixture;\nall Caldera invariance tests stay green without modification."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-w3",
      "data-slug": "w3-rollforward-cumprod-stdlib-primitives-g5-build-m",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-w3"
      }), "W3 — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "rollforward"
      }), " + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "cumprod"
      }), " stdlib primitives (G5, build, M)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Problem."
      }), " The debt schedule — co-evolving balances, one year feeding the\nnext — is THE most repeated structure in financial modeling (debt, NWC, PP&E,\nCAGR bridges). The ordered family (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "cumsum"
      }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "cummax"
      }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "cummin"
      }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ema"
      }), ") is\nsingle-state; Caldera needed a custom packed-state ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ScanOp"
      }), " + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "derive"
      }), "-unpack —\nexpressible but undiscoverable, precisely the \"hand-rolled loop the design\nexists to prevent\" (ADVERSARIAL_REVIEW_1 DSL-1). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "cumprod"
      }), " (growth paths) is\nmissing for the same reason."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "API sketch"
      }), " (spec-by-example: the Caldera debt schedule):"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-js",
        children: "rollforward(ops, {\n  orderBy: \"year\",                      // required — window semantics need order (scan's lesson)\n  begin: { rev: 0, tlb: su.tlb0, mezz: su.mezz0, cash: a.min_cash },\n  step: (row, bal) => {\n    // …the waterfall…\n    return { out: { interest, cfadr, mand, sweep, /* … */ },\n             next: { rev, tlb, mezz, cash } };\n  },\n})\n// → ops rows ∪ out columns ∪ next-as-end columns; `next` is the begin of the following row.\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Decisions to make at implementation: output shape (flatten ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "out.*"
      }), " and\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "next.*"
      }), ", vs nested like the packed-scan workaround — flatten, it killed the\nunpack step); whether ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "begin"
      }), " may reference the first row; null semantics (a\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "next"
      }), " containing NaN/Infinity ⇒ ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "null"
      }), " per DSL-6, not silent poison); the\nself-description text steering authors away from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "scan"
      }), " for multi-state folds."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Exit gates."
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "rollforward.test.ts"
        }), " unit suite incl. empty-rows, one-row, and\nNaN-in-state cases."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Port-forward:"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "model.sheet.js"
        }), "'s ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "scheduleYears"
        }), " and the growth-path\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "scan"
        }), " rewritten on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "rollforward"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "cumprod"
        }), "; the case study stays green\nagainst the Python oracle untouched — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "the specification tests are the\nrefactor safety net, which is the quiet argument for tested formulas."
        })]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: "Catalog self-descriptions with 1–2 worked examples (RQ-A5), and the\ncatalog gate test extended."
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-w4",
      "data-slug": "w4-financial-function-family-irr-npv-xirr-g2-build-sm",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-w4"
      }), "W4 — Financial function family: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "irr"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "npv"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "xirr"
      }), " (G2, build, S–M)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Problem."
      }), " No financial callables; every finance user re-derives IRR by\nhand (Caldera: a 15-line bisection, exact to 1e-12 — good code that nobody\nshould have to write twice)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Approach."
      }), " Minimal set first: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "irr(flows, opts?)"
      }), " (bracketed bisection —\ndeterministic, no Newton convergence surprises; documents the single-sign-change\nassumption and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "throws visibly"
      }), " on unbracketed flows rather than returning\ngarbage), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "npv(rate, flows)"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "xirr(dated rows, {by: 'date'})"
      }), " (the one real\ndesign question: date parsing rides the pure ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "dates.ts"
      }), " helpers). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "pmt"
      }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "rate"
      }), "\ndeferred until a case study needs them (additive-only means additions are\nalways possible; the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "ceiling"
      }), " is the cost, see risk)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Risk."
      }), " RQ-A5's ~20-callable ceiling is already strained; this plan adds\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "rollforward"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "cumprod"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "fixpoint"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "solve"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "irr"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "npv"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "xirr"
      }), ". The\ndefense is the same as the review-1 window-family additions: each replaces a\nhand-rolled loop class, it does not add surface for its own sake. Record the\nceiling re-count in the W3/W4 PR descriptions."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Exit gates."
      }), " Caldera ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "returns"
      }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "returns_avg"
      }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "breakeven"
      }), " cells use ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "irr"
      }), ";\nparity test: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "irr"
      }), " vs the hand-rolled bisection over the 25-cell grid to 1e-15;\ncatalog entries; the hand-rolled helpers deleted from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "model.sheet.js"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-w5",
      "data-slug": "w5-assumptions-as-params-g9-build-m",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-w5"
      }), "W5 — Assumptions-as-params (G9, build, M)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Problem."
      }), " The analyst's core loop — change any assumption, watch\neverything recalc — only works for the three declared manifest params. The tax\nrate or sweep percentage cannot be what-iffed without editing a fixture, and\nnothing tells the reader which leaves ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "could"
      }), " be knobs. The biggest\ndaily-friction gap."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Approach."
      }), " Explicit, validated, opt-in: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "reckoner.json"
      }), " gains"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-jsonc",
        children: "\"paramRefs\": {\n  \"tax_rate\":        { \"from\": \"fixtures.assumptions\", \"path\": \"0.tax_rate\" },\n  \"cash_sweep_pct\":  { \"from\": \"fixtures.assumptions\", \"path\": \"0.cash_sweep_pct\" }\n}\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "parseManifest"
        }), " validates shape (additive optional key — format stays 1);\nresolution happens in the loader/app: the param's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "default"
        }), " is read from the\nreferenced leaf; a runtime write ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "shadows"
        }), " the leaf for cells that declared\nthe fixture input, reusing the existing externals/update path — no engine\nchange, the dependency graph already tracks the fixture input."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: "Shadowing rule to decide: replace the leaf inside the injected fixture value\n(structural sharing), so formulas see one coherent frozen snapshot — never a\nsecond ambient channel."
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["xref: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "paramRefs"
        }), " keys count as params for ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "validateExternalReferences"
        }), ";\nunknown ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "from"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "path"
        }), " ⇒ load diagnostic, not silent."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["UI: the params surface lists them with their fixture provenance; templates\nmay bind ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Value source=\"params.tax_rate\""
        }), " or a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Range"
        }), " with declared bounds."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Exit gates."
      }), " In the running app over the Caldera document: flip\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "params.tax_rate"
      }), " 25%→30%, only the dependents of ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "fixtures.assumptions"
      }), "\nrecompute (assert via pass results), IRR visibly moves, the schedule rows\nmatch a Python truth variant generated for 30%; a broken ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "paramRefs"
      }), " entry\nproduces a load diagnostic."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-w6",
      "data-slug": "w6-stdlib-fixpoint-helper-g1a-build-s",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-w6"
      }), "W6 — stdlib ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "fixpoint"
      }), " helper (G1a, build, S)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Problem."
      }), " Convergent (circular) calculations are expressible today only as\na hand-rolled loop inside a formula — correct but undocumented convention,\nwith no standard place for iteration counts and convergence evidence."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Approach."
      }), " Formalize the pattern, change nothing about the graph:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-js",
        children: "fixpoint(initial, step, { tol = 1e-12, maxIterations = 200 })\n// → { converged, iterations, value } — `converged: false` is the VALUE's\n//   responsibility to surface (or a visible error), never silent.\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Pure, additive, self-described. (This is the Caldera avg-balance loop lifted\nverbatim.)"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Exit gates."
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "debt_schedule_avg"
      }), " uses ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "fixpoint"
      }), "; the convergence property\ntest now asserts on the returned ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "iterations"
      }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "converged"
      }), " record; unit tests\nfor non-convergence (oscillating step ⇒ ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "converged: false"
      }), ")."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-w7",
      "data-slug": "w7-converged-cell-design-spike-spec-g1b-design-m",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-w7"
      }), "W7 — Converged-cell design spike → spec (G1b, design, M)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Problem."
      }), " Whether convergence deserves to be a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "cell kind"
      }), " (first-class:\niteration counts on the trace channel, non-convergence a lattice error,\nper-cell budget against the watchdog) or stays a helper (W6) is an open design\nquestion with real information-flow consequences."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Approach."
      }), " Design sprint, not implementation: draft the spec covering —\nthe cell-kind API vs helper-only; where iteration counts + residuals flow\n(ENGINE_INFORMATION_FLOW_SPEC: another ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "(epoch, tier)"
      }), "-tagged channel); the\nfailure story (exceed ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "maxIterations"
      }), " ⇒ visible error on the cell — Excel's\nsilent-iterative-calc failure class, structurally impossible here); versioning\n(a new constructor is a stdlib addition; documents using it bump their derived\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "compat.stdlib"
      }), " floor automatically per DOCUMENT_VERSIONING_SPEC §3).\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Gate:"
      }), " go/no-go with the named criterion — implement the cell kind only if\na real document needs convergence ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "diagnostics"
      }), " (iteration counts surfaced in\nthe review surface, budget accounting), not merely convergence. If W6 has\ncovered every need by then, close this item as ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "helper-only, recorded"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Outcome (2026-08-27, R3-379): helper-only, recorded"
        }), " — the decision, the\npinned idiom, and the three behavioral reopening criteria live in\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "specs/CONVERGENCE_SPEC.md",
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "specs/CONVERGENCE_SPEC.md"
          })
        }), " §4–§6, with the\nadversarial self-review of that decision in §6."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-w8",
      "data-slug": "w8-sweep-construct-measure-first-g4-measure-s",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-w8"
      }), "W8 — Sweep construct: measure-first (G4, measure, S)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Problem."
      }), " Excel's data table is 2 minutes; Reckoner's sensitivity is a\nmodel-as-function decomposition tax. Before building an engine-level\nparametric-cell construct, measure whether the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "assistant idiom"
      }), " already\ncloses the gap."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Approach."
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["Extend ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "docs/assistant/FORMULA_AUTHORING_PROMPT.md"
        }), " with the\nmodel-as-function + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "runModel"
        }), " + sweep idiom (post-W3/W4, so the taught\nprimitives exist), including the anti-pattern note (\"don't re-derive inputs\ninside the sweep; pass the declared inputs through\")."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: "Bake-off in the E-1 style: N agent attempts to author the Caldera\nsensitivity cell from self-descriptions alone, scored on first-attempt\ncorrectness + diff auditability."
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Gate."
      }), " If the idiom authors reliably (the bar E-1 set for the DSL), the\nengine-level construct is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "rejected as unnecessary"
      }), " and recorded here; if not,\nthe failure modes name the requirements for a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "sweep()"
      }), " design spike. Either\nway the decision is measured, not vibes."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-w9",
      "data-slug": "w9-solve-g3-build-s",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-w9"
      }), "W9 — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "solve"
      }), " (G3, build, S)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["1-D monotone goal seek as a pure helper sharing ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "irr"
      }), "'s bracketing semantics\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "solve(fn, target, lo, hi)"
      }), "); exit gate: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "breakeven_exit_multiple"
      }), " uses it,\nparity vs the hand-rolled bisection. Interactive/multi-variate Solver stays a\nnon-goal (§5)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-w10",
      "data-slug": "w10-display-formats-for-finance-g8-build-s",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-w10"
      }), "W10 — Display formats for finance (G8, build, S)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "format"
      }), " enum additions (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "multiple"
      }), "), a units/suffix attribute on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "Kpi"
      }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "Table"
      }), "\ncolumns (e.g. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "unit=\"EUR m\""
      }), ", accounting negatives), riding the catalog-version\nbump per DOCUMENT_VERSIONING_SPEC §3.3. Display-only; anti-affordance review is\na formality. Exit: the deal summary renders 2.75x, EUR m, and parenthesized\nnegatives without bespoke formatting cells."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-2",
      "data-slug": "2-milestones",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-2"
      }), "2 — Milestones"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Milestone"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Items"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Gate"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "M0 — unblock testing"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "W1, W2"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "the holdout + oracle + adversarial-float tests pass through the real engine; verdict surface unchanged"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "M1 — finance stdlib"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "W3, W4"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Caldera port-forwarded onto ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "rollforward"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "cumprod"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "irr"
            }), " with the Python oracle as the only truth; catalog gate extended; ceiling re-count recorded"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "M2 — liveness + convergence"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "W5, W6"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["live ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "tax_rate"
            }), " knob in the app; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "fixpoint"
            }), " carries the avg-balance schedule"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "M3 — designs & measures"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "W7, W8"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "converged-cell go/no-go recorded; sweep-construct decision measured"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "M4 — polish"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "W9, W10"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["goal seek on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "solve"
            }), "; finance-grade rendering"]
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "M0 first and small; M1 is the additive-only-clock item (primitives land early\nor become permanent scars); M2 makes the analyst loop real; M3 spends design\nonly where M2's cheap versions might already suffice; M4 is tail."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-3",
      "data-slug": "3-decisions-rejected-alternatives",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-3"
      }), "3 — Decisions & rejected alternatives"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "W1 before everything."
        }), " A wiring bug against the plan's own spec'd\nexample, and every later item writes tests through the path it fixes.\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " rolling it into W3 — it would blur a bugfix with a primitive."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "rollforward"
          }), " as a primitive, not a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "scan"
          }), " tutorial."]
        }), " The case study\nproves the packed-", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ScanOp"
        }), " escape hatch works; discoverability, not\nexpressibility, is the gap. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " documenting the scan idiom only\n(same class of answer as \"you can hand-roll IRR\")."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Financial family minimal set (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "irr"
          }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "npv"
          }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "xirr"
          }), ")."]
        }), " Additive-only cuts\nboth ways; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "pmt"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "rate"
        }), " wait for a needing case study. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " the full\nExcel financial family up front."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "paramRefs"
          }), " explicit over conventions."]
        }), " An \"assumptions fixture\nauto-exposes every leaf\" convention is zero-config but implicit — the\ngrid's untyped-values sin in new clothes. Explicit refs are diffable,\nvalidatable, and degradable (a broken ref is a diagnostic).\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " the convention; also ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "rejected:"
        }), " params editable without\ndeclaration (destroys the dependency story params exist for)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "fixpoint"
          }), " helper before any converged-cell kind."]
        }), " Ship the cheap,\nadditive formalization; design the cell kind only against a demonstrated\nneed for ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "diagnostics"
        }), ", with the go/no-go criterion named in W7.\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " jumping to the cell kind (engine + spec + versioning cost\nbefore the need is shown)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Sweep: measure before building."
        }), " W8's bake-off decides; the construct is\nthe fallback, not the default. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " designing parametric cells on\nthe assumption agents can't author the idiom."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-4",
      "data-slug": "4-non-goals-v1-of-this-plan",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-4"
      }), "4 — Non-goals (v1 of this plan)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Multi-variate Solver; VBA/macros (never — the security model's point);\nExcel-style free-form layout authoring; pivot tables (reshape covers it);\nlive-feed ingestion changes (the LBO corpus is static by design — Meridian\nalready covers the streaming half)."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-5",
      "data-slug": "5-the-case-study-as-standing-acceptance-corpus",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-5"
      }), "5 — The case study as standing acceptance corpus"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Each primitive item (W3, W4, W6, W9) lands ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "together with its Caldera\nport-forward"
      }), ", and the Python oracle — regenerated by ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "generate.py"
      }), ", asserted\nby ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "calderaCaseStudy.test.ts"
      }), " — is the only truth either side touches. This is\nthe pattern the Meridian study set and the reason these refactors are cheap:\nthe specification tests exist ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "before"
      }), " the refactor, which is the hypothesis's\nproof turning into the hypothesis's dividend."]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/LBO_GAP_CLOSURE_PLAN.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiYmxvY2txdW90ZSIsImNvZGUiLCJlbSIsImgxIiwiaDIiLCJoMyIsImhyIiwibGkiLCJvbCIsInAiLCJwcmUiLCJzdHJvbmciLCJ0YWJsZSIsInRib2R5IiwidGQiLCJ0aCIsInRoZWFkIiwidHIiLCJ1bCIsIl9wcm92aWRlQ29tcG9uZW50cyIsImNvbXBvbmVudHMiLCJIZWFkaW5nQW5jaG9yIiwiX21pc3NpbmdNZHhSZWZlcmVuY2UiLCJqc3hzIiwiRnJhZ21lbnQiLCJjaGlsZHJlbiIsImlkIiwianN4IiwiaHJlZiIsImNsYXNzTmFtZSIsIk1EWENvbnRlbnQiLCJ3cmFwcGVyIiwiTURYTGF5b3V0IiwiX2MiLCJjb21wb25lbnQiLCJwbGFjZSIsIkVycm9yIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiTEJPX0dBUF9DTE9TVVJFX1BMQU4ubWQiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgYTogXCJhXCIsXG4gICAgYmxvY2txdW90ZTogXCJibG9ja3F1b3RlXCIsXG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgZW06IFwiZW1cIixcbiAgICBoMTogXCJoMVwiLFxuICAgIGgyOiBcImgyXCIsXG4gICAgaDM6IFwiaDNcIixcbiAgICBocjogXCJoclwiLFxuICAgIGxpOiBcImxpXCIsXG4gICAgb2w6IFwib2xcIixcbiAgICBwOiBcInBcIixcbiAgICBwcmU6IFwicHJlXCIsXG4gICAgc3Ryb25nOiBcInN0cm9uZ1wiLFxuICAgIHRhYmxlOiBcInRhYmxlXCIsXG4gICAgdGJvZHk6IFwidGJvZHlcIixcbiAgICB0ZDogXCJ0ZFwiLFxuICAgIHRoOiBcInRoXCIsXG4gICAgdGhlYWQ6IFwidGhlYWRcIixcbiAgICB0cjogXCJ0clwiLFxuICAgIHVsOiBcInVsXCIsXG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9LCB7SGVhZGluZ0FuY2hvcn0gPSBfY29tcG9uZW50cztcbiAgaWYgKCFIZWFkaW5nQW5jaG9yKSBfbWlzc2luZ01keFJlZmVyZW5jZShcIkhlYWRpbmdBbmNob3JcIiwgdHJ1ZSk7XG4gIHJldHVybiA8PjxfY29tcG9uZW50cy5oMSBpZD1cInJlY2tvbmVyLWxiby1nYXAtY2xvc3VyZS1wbGFuXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJyZWNrb25lci1sYm8tZ2FwLWNsb3N1cmUtcGxhblwiIC8+e1wiUmVja29uZXIg4oCUIExCTyBnYXAtY2xvc3VyZSBwbGFuXCJ9PC9fY29tcG9uZW50cy5oMT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlN0YXR1czpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgcGxhbiAvIHByb3Bvc2FsIOKAlCBzZXF1ZW5jZWQgd29yayBpdGVtcyBXMeKAk1cxMCBhY3Jvc3MgbWlsZXN0b25lcyBNMOKAk000LCBkZXJpdmVkIGZyb20gdGhlIENhbGRlcmEgY2FzZSBzdHVkeSdzIGdhcCBhbmFseXNpcyAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiTEJPX0NBU0VfU1RVRFlfR0FQX0FOQUxZU0lTLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgbWVyZ2VkIDIwMjYtMDgtMjcpOyBub3RoaW5nIGhlcmUgaXMgc2NoZWR1bGVkIMK3IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiVXBkYXRlZDpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgMjAyNi0wOC0yN1wifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuYmxvY2txdW90ZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlJlYWRzIGZpcnN0OlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuYSBocmVmPVwiTEJPX0NBU0VfU1RVRFlfR0FQX0FOQUxZU0lTLm1kXCI+e1wiTEJPX0NBU0VfU1RVRFlfR0FQX0FOQUxZU0lTLm1kXCJ9PC9fY29tcG9uZW50cy5hPntcIlxcbih0aGUgZ2FwcyBHMeKAk0c5IHRoaXMgcGxhbiBjbG9zZXMpLCB0aGUgY2FzZSBzdHVkeSBpdHNlbGZcXG4oXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cImNhc2Utc3R1ZHkvY2FsZGVyYS9cIj48X2NvbXBvbmVudHMuY29kZT57XCJjYXNlLXN0dWR5L2NhbGRlcmEvXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuYT57XCIgKyBpdHMgcHJvb2YgaGFybmVzc1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9kb2N1bWVudC9jYWxkZXJhQ2FzZVN0dWR5LnRlc3QudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCB0aGUgc3RhbmRpbmcgYWNjZXB0YW5jZSBjb3JwdXMgZm9yXFxubW9zdCBpdGVtcyBiZWxvdyksIFwifTxfY29tcG9uZW50cy5hIGhyZWY9XCJBUkNISVRFQ1RVUkVfUExBTi5tZFwiPntcIkFSQ0hJVEVDVFVSRV9QTEFOLm1kXCJ9PC9fY29tcG9uZW50cy5hPntcIiDCpzMuMiAodGhlXFxuY29tbWl0dGVkIHN0ZGxpYiwgYWRkaXRpdmUtb25seSBmb3JldmVyKSwgwqc2ICh0ZXN0aW5nIGFyY2hpdGVjdHVyZSksXFxuXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cInNwZWNzL0RPQ1VNRU5UX1ZFUlNJT05JTkdfU1BFQy5tZFwiPntcIkRPQ1VNRU5UX1ZFUlNJT05JTkdfU1BFQy5tZFwifTwvX2NvbXBvbmVudHMuYT57XCIgKHRoZSBjb21wYXRcXG5lbnZlbG9wZSBldmVyeSBzdGRsaWIvY2F0YWxvZyBhZGRpdGlvbiByaWRlcyksIGFuZCB0aGUgY3VycmVudCB3aXJpbmcgdGhlXFxuaXRlbXMgdG91Y2g6IFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9lbmdpbmUvdGVzdHJ1bm5lci50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9lbmdpbmUvYXN5bmNFbmdpbmUudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxuKFwifTxfY29tcG9uZW50cy5jb2RlPntcInJ1blRlc3RzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCIjaW5wdXRzRm9yXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiksIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9lbmdpbmUvd29ya2VyL2VuZ2luZVdvcmtlci50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcInJ1blN1aXRlc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9zdGRsaWIvcmVsYXRpb25zLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2RvY3VtZW50L21hbmlmZXN0LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoaXMgcGxhbiB0dXJucyB0aGUgZ2FwIGFuYWx5c2lzIGludG8gYnVpbGRhYmxlLCBnYXRlZCB3b3JrLiBPcmRlcmluZyBwcmluY2lwbGU6XFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJidWctbGV2ZWwgZml4ZXMgYmVmb3JlIHByaW1pdGl2ZXMgYmVmb3JlIGRlc2lnbnMgYmVmb3JlIG1lYXN1cmVzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBHNiBpcyBhXFxud2lyaW5nIGJ1ZyBhZ2FpbnN0IHRoZSBhcmNoaXRlY3R1cmUgcGxhbidzIG93biDCpzMuMSBleGFtcGxlIGFuZCB1bmJsb2NrcyB0aGVcXG5ob2xkb3V0LXRlc3QgcGF0dGVybiBldmVyeXRoaW5nIGVsc2Ugd2FudHMgdG8gdXNlOyB0aGUgc3RkbGliIGFkZGl0aW9ucyAoRzUsIEcyKVxcbmFyZSBhZGRpdGl2ZSBhbmQgY2hlYXAgXCJ9PF9jb21wb25lbnRzLmVtPntcIm5vd1wifTwvX2NvbXBvbmVudHMuZW0+e1wiIGJ1dCBwZXJtYW5lbnQgb25jZSBmcm96ZW4sIHNvIHRoZXkgY29tZSBlYXJseTsgdGhlXFxuY29udmVyZ2VkLWNlbGwgZGVzaWduIChHMSkgYW5kIHRoZSBzd2VlcC1jb25zdHJ1Y3QgZGVjaXNpb24gKEc0KSBhcmUgZ2F0ZWQgb25cXG5jaGVhcCBwcmVkZWNlc3NvcnMgdGhhdCBtYXkgbWFrZSB0aGUgZXhwZW5zaXZlIHZlcnNpb24gdW5uZWNlc3NhcnkuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5ociAvPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInNlYy0wXCIgZGF0YS1zbHVnPVwiMC1zdW1tYXJ5XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtMFwiIC8+e1wiMCDigJQgU3VtbWFyeVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnRhYmxlPjxfY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRoPntcIiNcIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aD57XCJHYXBcIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aD57XCJJdGVtXCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGg+e1wiS2luZFwifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIk1pbGVzdG9uZVwifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIlNpemVcIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aD57XCJFeGl0IGdhdGUgKG9uZS1saW5lKVwifTwvX2NvbXBvbmVudHMudGg+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50Ym9keT48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIlcxXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiRzZcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJXaXJlIFwifTxfY29tcG9uZW50cy5jb2RlPntcInN1YnN0aXR1dGVJbnB1dHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGludG8gdGhlIHRlc3QgcnVuXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiYnVpbGRcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJNMFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIlNcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJhIGhvbGRvdXQgKyBhIGZpeHR1cmUtb3JhY2xlIHRlc3QgaW4gQ2FsZGVyYSBwYXNzIHRocm91Z2ggdGhlIHJlYWwgZW5naW5lXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiVzJcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJHN1wifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIlRvbGVyYW50IGludmFyaWFuY2UgY29tcGFyaXNvbnM7IHNlbGVjdGl2ZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzY2FsZUludmFyaWFuY2VcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiYnVpbGRcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJNMFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIlNcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJhZHZlcnNhcmlhbCBmbG9hdC1yZW9yZGVyIGZpeHR1cmUgcGFzc2VzOyBDYWxkZXJhIGludmFyaWFuY2UgdGVzdHMgdW5jaGFuZ2VkLWdyZWVuXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiVzNcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJHNVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcInJvbGxmb3J3YXJkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiArIFwifTxfY29tcG9uZW50cy5jb2RlPntcImN1bXByb2RcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHN0ZGxpYiBwcmltaXRpdmVzXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiYnVpbGRcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJNMVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIk1cIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJDYWxkZXJhIGRlYnQgc2NoZWR1bGUgKyBncm93dGggcGF0aHMgZXhwcmVzc2VkIHdpdGggdGhlbSwgb3JhY2xlLWdyZWVuXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiVzRcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJHMlwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIkZpbmFuY2lhbCBmYW1pbHk6IFwifTxfY29tcG9uZW50cy5jb2RlPntcImlyclwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm5wdlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcInhpcnJcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiYnVpbGRcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJNMVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIlPigJNNXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiQ2FsZGVyYSByZXR1cm5zIHVzZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJpcnJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiOyBwYXJpdHkgdnMgdGhlIGhhbmQtcm9sbGVkIGJpc2VjdGlvblwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIlc1XCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiRzlcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJBc3N1bXB0aW9ucy1hcy1wYXJhbXMgKFwifTxfY29tcG9uZW50cy5jb2RlPntcInBhcmFtUmVmc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaW4gdGhlIG1hbmlmZXN0KVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcImJ1aWxkXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiTTJcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJNXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1widGF4X3JhdGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGZsaXBwZWQgbGl2ZSBpbiB0aGUgcnVubmluZyBhcHA7IG9ubHkgZGVwZW5kZW50cyByZWNvbXB1dGVcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJXNlwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIkcxYVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcInN0ZGxpYiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmaXhwb2ludFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaGVscGVyIChmb3JtYWxpemUgdGhlIGludHJhLWNlbGwgbG9vcClcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJidWlsZFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIk0yXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiU1wifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcImRlYnRfc2NoZWR1bGVfYXZnXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB1c2VzIFwifTxfY29tcG9uZW50cy5jb2RlPntcImZpeHBvaW50XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjsgY29udmVyZ2VuY2UgdGVzdCB1bmNoYW5nZWRcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJXN1wifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIkcxYlwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIkNvbnZlcmdlZC1jZWxsIGRlc2lnbiBzcGlrZSDihpIgc3BlY1wifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcImRlc2lnblwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIk0zXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiTVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcInNwZWMgcmV2aWV3ZWQ7IGdvL25vLWdvIG9uIHRoZSBjZWxsIGtpbmQgKGhlbHBlci1vbmx5IGlzIGEgbGl2ZSBvcHRpb24pXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiVzhcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJHNFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIlN3ZWVwIGlkaW9tOiBtZWFzdXJlLWZpcnN0IHZpYSB0aGUgYXNzaXN0YW50XCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wibWVhc3VyZVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIk0zXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiU1wifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcImFnZW50IGF1dGhvcnMgdGhlIHNlbnNpdGl2aXR5IGNlbGwgZnJvbSBzZWxmLWRlc2NyaXB0aW9ucyBhbG9uZSwgb3IgdGhlIGNvbnN0cnVjdCBpcyBqdXN0aWZpZWRcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJXOVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIkczXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wic29sdmVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICgxLUQgbW9ub3RvbmUgYmlzZWN0aW9uIGhlbHBlcilcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJidWlsZFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIk00XCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiU1wifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcImJyZWFrZXZlbl9leGl0X211bHRpcGxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB1c2VzIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNvbHZlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjsgcGFyaXR5IHZzIGhhbmQtcm9sbGVkXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiVzEwXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiRzhcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJEaXNwbGF5IGZvcm1hdHMgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIm11bHRpcGxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgdW5pdHMsIGNvbHVtbiBmb3JtYXRzKVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcImJ1aWxkXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiTTRcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJTXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1widGhlIGRlYWwgc3VtbWFyeSByZW5kZXJzIDIuNzV4IC8gRVVSIG0gLyAoMSwyMzQpIHdpdGhvdXQgYmVzcG9rZSBjZWxsc1wifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRib2R5PjwvX2NvbXBvbmVudHMudGFibGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiRGVwZW5kZW5jeSBlZGdlczogVzEg4oaSIChXMiwgVzMsIFc0IOKApmV2ZXJ5dGhpbmcgdGhhdCB3cml0ZXMgdGVzdHMsIHByYWN0aWNhbGx5KTtcXG5XNiDihpIgVzc7IFc0IOKGkiBXOSAoc2hhcmVkIGJyYWNrZXRpbmcgc2VtYW50aWNzKTsgVzMvVzQg4oaSIFc4ICh0aGUgaWRpb20gbmVlZHMgdGhlXFxucHJpbWl0aXZlcyBpdCB0ZWFjaGVzKS4gVzUgaXMgaW5kZXBlbmRlbnQuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5ociAvPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInNlYy0xXCIgZGF0YS1zbHVnPVwiMS13b3JrLWl0ZW1zXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtMVwiIC8+e1wiMSDigJQgV29yayBpdGVtc1wifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwic2VjLXcxXCIgZGF0YS1zbHVnPVwidzEtd2lyZS10ZXN0LWRlY2xhcmVkLWlucHV0cy1pbnRvLXRoZS10ZXN0LXJ1bi1nNi1idWlsZC1zXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtdzFcIiAvPntcIlcxIOKAlCBXaXJlIHRlc3QtZGVjbGFyZWQgaW5wdXRzIGludG8gdGhlIHRlc3QgcnVuIChHNiwgYnVpbGQsIFMpXCJ9PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlByb2JsZW0uXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5jb2RlPntcInRlc3RydW5uZXIudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGltcGxlbWVudHMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3Vic3RpdHV0ZUlucHV0c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIGEgdGVzdCdzIGRlY2xhcmVkXFxuaW5wdXRzIHN1YnN0aXR1dGUgZm9yIHRoZSBzdWJqZWN0J3Mgc2FtZS1uYW1lZCBpbnB1dHMsIHVua25vd24gbmFtZXMgZmFpbCDigJQgYnV0XFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQXN5bmNFbmdpbmUucnVuVGVzdHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGJ1aWxkcyBvbmUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiU3VpdGVDb250ZXh0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBwZXIgXCJ9PF9jb21wb25lbnRzLmVtPntcInN1YmplY3RcIn08L19jb21wb25lbnRzLmVtPntcIiB3aXRoIG9ubHlcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCIjaW5wdXRzRm9yKHN1YmplY3QpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgYW5kIFwifTxfY29tcG9uZW50cy5jb2RlPntcImVuZ2luZVdvcmtlci5ydW5TdWl0ZXNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG5ldmVyIGNhbGxzXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3Vic3RpdHV0ZUlucHV0c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIuIEEgdGVzdCBjYW4gb25seSBzZWUgc3ViamVjdC1saXZlIGlucHV0czsgdGhlIGhvbGRvdXQgcGF0dGVyblxcbihBUkNISVRFQ1RVUkVfUExBTiDCpzMuMSdzIGZpcnN0IGV4YW1wbGUpIGFuZCBmaXh0dXJlLWZlZCBvcmFjbGVzIGFyZVxcbnVud3JpdGFibGUuIFJlY2VpcHQ6IHRoZSBDYWxkZXJhIG9yYWNsZSBoYWQgdG8gYmUgaW5saW5lZCBhcyBjb25zdGFudHNcXG4oXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2hlY2tzLnNoZWV0LmpzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBHQVAgbm90ZSkuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQXBwcm9hY2guXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiSG9zdCBzaWRlOiByZXNvbHZlIGVhY2ggdGVzdCdzIGRlY2xhcmVkIGlucHV0IHBhdGhzIChleHRlcm5hbHMgKyBwdWJsaXNoZWRcXG5yZXN1bHRzIOKAlCB0aGUgc2FtZSByZXNvbHV0aW9uIG1hY2hpbmVyeSBcIn08X2NvbXBvbmVudHMuY29kZT57XCIjaW5wdXRzRm9yXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB1c2VzLCBsaWZ0ZWQgdG8gb3BlcmF0ZVxcbm9uIGEgdGVzdCdzIFwifTxfY29tcG9uZW50cy5jb2RlPntcIklucHV0U3BlY1wifTwvX2NvbXBvbmVudHMuY29kZT57XCJzKS4gVW5yZXNvbHZhYmxlIHJlZmVyZW5jZSDih5IgdGhhdCB0ZXN0J3Mgb3V0Y29tZSBpcyBhXFxuXCJ9PF9jb21wb25lbnRzLmVtPntcImZhaWxpbmdcIn08L19jb21wb25lbnRzLmVtPntcIiByZWNvcmQgd2l0aCB0aGUgbWVzc2FnZSwgbmV2ZXIgYSBzaWxlbnQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibnVsbFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKG1pcnJvcnNcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJUZXN0UnVuQ29udGV4dC5lcnJvclwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIlByb3RvY29sOiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJTdWl0ZUNvbnRleHRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGdhaW5zIHBlci10ZXN0IGlucHV0cyAoZS5nLiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ0ZXN0czoge2lkLCBpbnB1dHN9W11cIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSDigJQgYW4gaW50ZXJuYWwgaG9zdOKGlHdvcmtlciBzaGFwZSBjaGFuZ2UsIG5vIGRvY3VtZW50LWZvcm1hdFxcbmltcGFjdC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJXb3JrZXIgc2lkZTogZm9yIGVhY2ggdGVzdCwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3Vic3RpdHV0ZUlucHV0cyh0ZXN0SW5wdXRzLCBzdWJqZWN0SW5wdXRzKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG50aGVuIFwifTxfY29tcG9uZW50cy5jb2RlPntcInJ1blRlc3RcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHdpdGggdGhlIHN1YnN0aXR1dGVkIHNldDsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicmVldmFsdWF0ZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZm9yIGludmFyaWFuY2VcXG5yZWxhdGlvbnMgYXBwbGllcyB0cmFuc2Zvcm1zIHRvIHRoZSBzdWJzdGl0dXRlZCBpbnB1dHMgKHNvIGEgaG9sZG91dCB0ZXN0ICtcXG5hIG1ldGFtb3JwaGljIHJlbGF0aW9uIGNvbXBvc2UpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkV4aXQgZ2F0ZXMuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiQSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImhvbGRvdXQgdGVzdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBpbiBDYWxkZXJhOiBzdWJqZWN0IFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1vZGVsLm9wZXJhdGluZ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGlucHV0cyBzdWJzdGl0dXRpbmdcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJwbGFuXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB3aXRoIGEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZml4dHVyZXMub3BzX3BsYW5faG9sZG91dFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdmFyaWFudCAoYSBnZW51aW5lbHkgZGlmZmVyZW50XFxucGxhbiksIGFzc2VydGluZyBvcmFjbGUgdmFsdWVzIGdlbmVyYXRlZCBmb3IgdGhhdCB2YXJpYW50IOKAlCBwYXNzZXMgdGhyb3VnaFxcbnRoZSByZWFsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkFzeW5jRW5naW5lLnJ1blRlc3RzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJUaGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJvcmFjbGUgdGVzdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiByZXdyaXR0ZW4gdG8gcmVhZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmaXh0dXJlcy5leHBlY3RlZF92YWx1ZXNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHRocm91Z2hcXG50ZXN0IGlucHV0czsgdGhlIGlubGluZWQgY29uc3RhbnRzIGluIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNoZWNrcy5zaGVldC5qc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZGVsZXRlZC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJBIHRlc3QgZGVjbGFyaW5nIGEgbmFtZSB0aGUgc3ViamVjdCBkb2VzIG5vdCBkZWNsYXJlIGZhaWxzIHdpdGhcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJzdWJzdGl0dXRlSW5wdXRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIicgbWVzc2FnZSAodW5pdCB0ZXN0IGluIFwifTxfY29tcG9uZW50cy5jb2RlPntcInRlc3RydW5uZXIudGVzdC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIlZlcmRpY3Qgc3VyZmFjZSAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3VpdGVSZXBvcnQudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ1c2VWZXJkaWN0c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpIHVuY2hhbmdlZCDigJQgdGhpcyBpc1xcbmludmlzaWJsZSBwbHVtYmluZyBiZWxvdyBpdC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMub2w+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwic2VjLXcyXCIgZGF0YS1zbHVnPVwidzItdG9sZXJhbnQtaW52YXJpYW5jZS1jb21wYXJpc29ucy1nNy1idWlsZC1zXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtdzJcIiAvPntcIlcyIOKAlCBUb2xlcmFudCBpbnZhcmlhbmNlIGNvbXBhcmlzb25zIChHNywgYnVpbGQsIFMpXCJ9PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlByb2JsZW0uXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5jb2RlPntcInBlcm11dGF0aW9uSW52YXJpYW5jZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgY29tcGFyZXMgdmlhIHN0cmljdCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJkZWVwRXF1YWxcIn08L19jb21wb25lbnRzLmNvZGU+e1wiOyByb3dcXG5yZW9yZGVyaW5nIHJlb3JkZXJzIGZsb2F0IHN1bW1hdGlvbiwgd2hpY2ggY2FuIGRpZmZlciBpbiB0aGUgbGFzdCB1bHAgKGJlbmlnblxcbmluIENhbGRlcmEncyB2YWx1ZXMg4oCUIGJ5IGx1Y2spLiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzY2FsZUludmFyaWFuY2VcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHNjYWxlcyBcIn08X2NvbXBvbmVudHMuZW0+e1wiZXZlcnlcIn08L19jb21wb25lbnRzLmVtPntcIiBudW1lcmljIGxlYWYsXFxuc28gYW55IGlucHV0IGNhcnJ5aW5nIHJhdGVzL3BlcmNlbnRhZ2VzIChtYXJnaW5zLCBncm93dGgpIGJyZWFrcyBpdCDigJQgaS5lLiBtb3N0XFxuZmluYW5jaWFsIGlucHV0cywgcGVybWFuZW50bHkuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQXBwcm9hY2guXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiQm90aCByZWxhdGlvbnMgYWNjZXB0IGFuIG9wdGlvbmFsIFwifTxfY29tcG9uZW50cy5jb2RlPntcInRvbFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKGRlZmF1bHQgYSB0aW55IHJlbGF0aXZlIHRvbGVyYW5jZSxcXG5lLmcuIFwifTxfY29tcG9uZW50cy5jb2RlPntcIntyZWw6IDFlLTEyfVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpIGFuZCBjb21wYXJlIG51bWVyaWMgbGVhdmVzIHdpdGggXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZXhwZWN0Q2xvc2VcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHNlbWFudGljcyxcXG5zdHJ1Y3R1cmUgc3RyaWN0bHkuIEEgZGF0ZWQgbm90ZSBpbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyZWxhdGlvbnMudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHJlY29yZHMgdGhpcyBhcyBhIGJ1Z2ZpeFxcbnRvIGEgbWlzLWRlc2lnbmVkIGNvbXBhcmlzb24g4oCUIGJlaGF2aW9yIGNoYW5nZSBpbnNpZGUgYWRkaXRpdmUtb25seSwgd2hpY2hcXG50aGUgc3BlYyBwZXJtaXRzIGZvciBcIn08X2NvbXBvbmVudHMuZW0+e1wiY29ycmVjdGlvbnNcIn08L19jb21wb25lbnRzLmVtPntcIiBidXQgcmVxdWlyZXMgcmVjb3JkaW5nLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5jb2RlPntcInNjYWxlSW52YXJpYW5jZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZ2FpbnMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibGVhdmVzPzogc3RyaW5nW11cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChvciBcIn08X2NvbXBvbmVudHMuY29kZT57XCJleGNlcHQ6IHN0cmluZ1tdXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikgbmFtaW5nXFxud2hpY2ggZmllbGRzIHBhcnRpY2lwYXRlIGluIHNjYWxpbmc7IGRlZmF1bHQgc3RheXMgYWxsLWxlYXZlcyBmb3JcXG5iYWNrd2FyZCBjb21wYXRpYmlsaXR5LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkV4aXQgZ2F0ZXMuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIEFuIGFkdmVyc2FyaWFsIHVuaXQgdGVzdDogcm93cyB3aG9zZSByZW9yZGVyZWQgc3VtIGRpZmZlcnMgYnlcXG4xIHVscCBwYXNzZXMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicGVybXV0YXRpb25JbnZhcmlhbmNlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhbmQgd291bGQgaGF2ZSBmYWlsZWQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZGVlcEVxdWFsXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjsgYVxcblwifTxfY29tcG9uZW50cy5jb2RlPntcInNjYWxlSW52YXJpYW5jZSh7bGVhdmVzOiBbJ2Z5MjAyNiddfSlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHRlc3Qgb3ZlciBhIHJhdGUtYmVhcmluZyBmaXh0dXJlO1xcbmFsbCBDYWxkZXJhIGludmFyaWFuY2UgdGVzdHMgc3RheSBncmVlbiB3aXRob3V0IG1vZGlmaWNhdGlvbi5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwic2VjLXczXCIgZGF0YS1zbHVnPVwidzMtcm9sbGZvcndhcmQtY3VtcHJvZC1zdGRsaWItcHJpbWl0aXZlcy1nNS1idWlsZC1tXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtdzNcIiAvPntcIlczIOKAlCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyb2xsZm9yd2FyZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjdW1wcm9kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBzdGRsaWIgcHJpbWl0aXZlcyAoRzUsIGJ1aWxkLCBNKVwifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJQcm9ibGVtLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGUgZGVidCBzY2hlZHVsZSDigJQgY28tZXZvbHZpbmcgYmFsYW5jZXMsIG9uZSB5ZWFyIGZlZWRpbmcgdGhlXFxubmV4dCDigJQgaXMgVEhFIG1vc3QgcmVwZWF0ZWQgc3RydWN0dXJlIGluIGZpbmFuY2lhbCBtb2RlbGluZyAoZGVidCwgTldDLCBQUCZFLFxcbkNBR1IgYnJpZGdlcykuIFRoZSBvcmRlcmVkIGZhbWlseSAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY3Vtc3VtXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJjdW1tYXhcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcImN1bW1pblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZW1hXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikgaXNcXG5zaW5nbGUtc3RhdGU7IENhbGRlcmEgbmVlZGVkIGEgY3VzdG9tIHBhY2tlZC1zdGF0ZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJTY2FuT3BcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZGVyaXZlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi11bnBhY2sg4oCUXFxuZXhwcmVzc2libGUgYnV0IHVuZGlzY292ZXJhYmxlLCBwcmVjaXNlbHkgdGhlIFxcXCJoYW5kLXJvbGxlZCBsb29wIHRoZSBkZXNpZ25cXG5leGlzdHMgdG8gcHJldmVudFxcXCIgKEFEVkVSU0FSSUFMX1JFVklFV18xIERTTC0xKS4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY3VtcHJvZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKGdyb3d0aCBwYXRocykgaXNcXG5taXNzaW5nIGZvciB0aGUgc2FtZSByZWFzb24uXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQVBJIHNrZXRjaFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoc3BlYy1ieS1leGFtcGxlOiB0aGUgQ2FsZGVyYSBkZWJ0IHNjaGVkdWxlKTpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnByZT48X2NvbXBvbmVudHMuY29kZSBjbGFzc05hbWU9XCJsYW5ndWFnZS1qc1wiPntcInJvbGxmb3J3YXJkKG9wcywge1xcbiAgb3JkZXJCeTogXFxcInllYXJcXFwiLCAgICAgICAgICAgICAgICAgICAgICAvLyByZXF1aXJlZCDigJQgd2luZG93IHNlbWFudGljcyBuZWVkIG9yZGVyIChzY2FuJ3MgbGVzc29uKVxcbiAgYmVnaW46IHsgcmV2OiAwLCB0bGI6IHN1LnRsYjAsIG1leno6IHN1Lm1lenowLCBjYXNoOiBhLm1pbl9jYXNoIH0sXFxuICBzdGVwOiAocm93LCBiYWwpID0+IHtcXG4gICAgLy8g4oCmdGhlIHdhdGVyZmFsbOKAplxcbiAgICByZXR1cm4geyBvdXQ6IHsgaW50ZXJlc3QsIGNmYWRyLCBtYW5kLCBzd2VlcCwgLyog4oCmICovIH0sXFxuICAgICAgICAgICAgIG5leHQ6IHsgcmV2LCB0bGIsIG1lenosIGNhc2ggfSB9O1xcbiAgfSxcXG59KVxcbi8vIOKGkiBvcHMgcm93cyDiiKogb3V0IGNvbHVtbnMg4oiqIG5leHQtYXMtZW5kIGNvbHVtbnM7IGBuZXh0YCBpcyB0aGUgYmVnaW4gb2YgdGhlIGZvbGxvd2luZyByb3cuXFxuXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMucHJlPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkRlY2lzaW9ucyB0byBtYWtlIGF0IGltcGxlbWVudGF0aW9uOiBvdXRwdXQgc2hhcGUgKGZsYXR0ZW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wib3V0LipcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFuZFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcIm5leHQuKlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIHZzIG5lc3RlZCBsaWtlIHRoZSBwYWNrZWQtc2NhbiB3b3JrYXJvdW5kIOKAlCBmbGF0dGVuLCBpdCBraWxsZWQgdGhlXFxudW5wYWNrIHN0ZXApOyB3aGV0aGVyIFwifTxfY29tcG9uZW50cy5jb2RlPntcImJlZ2luXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBtYXkgcmVmZXJlbmNlIHRoZSBmaXJzdCByb3c7IG51bGwgc2VtYW50aWNzIChhXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibmV4dFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgY29udGFpbmluZyBOYU4vSW5maW5pdHkg4oeSIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm51bGxcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHBlciBEU0wtNiwgbm90IHNpbGVudCBwb2lzb24pOyB0aGVcXG5zZWxmLWRlc2NyaXB0aW9uIHRleHQgc3RlZXJpbmcgYXV0aG9ycyBhd2F5IGZyb20gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic2NhblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZm9yIG11bHRpLXN0YXRlIGZvbGRzLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkV4aXQgZ2F0ZXMuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLmNvZGU+e1wicm9sbGZvcndhcmQudGVzdC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdW5pdCBzdWl0ZSBpbmNsLiBlbXB0eS1yb3dzLCBvbmUtcm93LCBhbmRcXG5OYU4taW4tc3RhdGUgY2FzZXMuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJQb3J0LWZvcndhcmQ6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1vZGVsLnNoZWV0LmpzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIidzIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNjaGVkdWxlWWVhcnNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFuZCB0aGUgZ3Jvd3RoLXBhdGhcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJzY2FuXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiByZXdyaXR0ZW4gb24gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicm9sbGZvcndhcmRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcImN1bXByb2RcIn08L19jb21wb25lbnRzLmNvZGU+e1wiOyB0aGUgY2FzZSBzdHVkeSBzdGF5cyBncmVlblxcbmFnYWluc3QgdGhlIFB5dGhvbiBvcmFjbGUgdW50b3VjaGVkIOKAlCBcIn08X2NvbXBvbmVudHMuZW0+e1widGhlIHNwZWNpZmljYXRpb24gdGVzdHMgYXJlIHRoZVxcbnJlZmFjdG9yIHNhZmV0eSBuZXQsIHdoaWNoIGlzIHRoZSBxdWlldCBhcmd1bWVudCBmb3IgdGVzdGVkIGZvcm11bGFzLlwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiQ2F0YWxvZyBzZWxmLWRlc2NyaXB0aW9ucyB3aXRoIDHigJMyIHdvcmtlZCBleGFtcGxlcyAoUlEtQTUpLCBhbmQgdGhlXFxuY2F0YWxvZyBnYXRlIHRlc3QgZXh0ZW5kZWQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cInNlYy13NFwiIGRhdGEtc2x1Zz1cInc0LWZpbmFuY2lhbC1mdW5jdGlvbi1mYW1pbHktaXJyLW5wdi14aXJyLWcyLWJ1aWxkLXNtXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtdzRcIiAvPntcIlc0IOKAlCBGaW5hbmNpYWwgZnVuY3Rpb24gZmFtaWx5OiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJpcnJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJucHZcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ4aXJyXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoRzIsIGJ1aWxkLCBT4oCTTSlcIn08L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUHJvYmxlbS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgTm8gZmluYW5jaWFsIGNhbGxhYmxlczsgZXZlcnkgZmluYW5jZSB1c2VyIHJlLWRlcml2ZXMgSVJSIGJ5XFxuaGFuZCAoQ2FsZGVyYTogYSAxNS1saW5lIGJpc2VjdGlvbiwgZXhhY3QgdG8gMWUtMTIg4oCUIGdvb2QgY29kZSB0aGF0IG5vYm9keVxcbnNob3VsZCBoYXZlIHRvIHdyaXRlIHR3aWNlKS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJBcHByb2FjaC5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgTWluaW1hbCBzZXQgZmlyc3Q6IFwifTxfY29tcG9uZW50cy5jb2RlPntcImlycihmbG93cywgb3B0cz8pXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoYnJhY2tldGVkIGJpc2VjdGlvbiDigJRcXG5kZXRlcm1pbmlzdGljLCBubyBOZXd0b24gY29udmVyZ2VuY2Ugc3VycHJpc2VzOyBkb2N1bWVudHMgdGhlIHNpbmdsZS1zaWduLWNoYW5nZVxcbmFzc3VtcHRpb24gYW5kIFwifTxfY29tcG9uZW50cy5lbT57XCJ0aHJvd3MgdmlzaWJseVwifTwvX2NvbXBvbmVudHMuZW0+e1wiIG9uIHVuYnJhY2tldGVkIGZsb3dzIHJhdGhlciB0aGFuIHJldHVybmluZ1xcbmdhcmJhZ2UpLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJucHYocmF0ZSwgZmxvd3MpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wieGlycihkYXRlZCByb3dzLCB7Ynk6ICdkYXRlJ30pXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAodGhlIG9uZSByZWFsXFxuZGVzaWduIHF1ZXN0aW9uOiBkYXRlIHBhcnNpbmcgcmlkZXMgdGhlIHB1cmUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZGF0ZXMudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGhlbHBlcnMpLiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJwbXRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcInJhdGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxuZGVmZXJyZWQgdW50aWwgYSBjYXNlIHN0dWR5IG5lZWRzIHRoZW0gKGFkZGl0aXZlLW9ubHkgbWVhbnMgYWRkaXRpb25zIGFyZVxcbmFsd2F5cyBwb3NzaWJsZTsgdGhlIFwifTxfY29tcG9uZW50cy5lbT57XCJjZWlsaW5nXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgaXMgdGhlIGNvc3QsIHNlZSByaXNrKS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJSaXNrLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBSUS1BNSdzIH4yMC1jYWxsYWJsZSBjZWlsaW5nIGlzIGFscmVhZHkgc3RyYWluZWQ7IHRoaXMgcGxhbiBhZGRzXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicm9sbGZvcndhcmRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjdW1wcm9kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZml4cG9pbnRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzb2x2ZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcImlyclwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm5wdlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcInhpcnJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLiBUaGVcXG5kZWZlbnNlIGlzIHRoZSBzYW1lIGFzIHRoZSByZXZpZXctMSB3aW5kb3ctZmFtaWx5IGFkZGl0aW9uczogZWFjaCByZXBsYWNlcyBhXFxuaGFuZC1yb2xsZWQgbG9vcCBjbGFzcywgaXQgZG9lcyBub3QgYWRkIHN1cmZhY2UgZm9yIGl0cyBvd24gc2FrZS4gUmVjb3JkIHRoZVxcbmNlaWxpbmcgcmUtY291bnQgaW4gdGhlIFczL1c0IFBSIGRlc2NyaXB0aW9ucy5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJFeGl0IGdhdGVzLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBDYWxkZXJhIFwifTxfY29tcG9uZW50cy5jb2RlPntcInJldHVybnNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcInJldHVybnNfYXZnXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJicmVha2V2ZW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNlbGxzIHVzZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJpcnJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiO1xcbnBhcml0eSB0ZXN0OiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJpcnJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHZzIHRoZSBoYW5kLXJvbGxlZCBiaXNlY3Rpb24gb3ZlciB0aGUgMjUtY2VsbCBncmlkIHRvIDFlLTE1O1xcbmNhdGFsb2cgZW50cmllczsgdGhlIGhhbmQtcm9sbGVkIGhlbHBlcnMgZGVsZXRlZCBmcm9tIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1vZGVsLnNoZWV0LmpzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwic2VjLXc1XCIgZGF0YS1zbHVnPVwidzUtYXNzdW1wdGlvbnMtYXMtcGFyYW1zLWc5LWJ1aWxkLW1cIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy13NVwiIC8+e1wiVzUg4oCUIEFzc3VtcHRpb25zLWFzLXBhcmFtcyAoRzksIGJ1aWxkLCBNKVwifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJQcm9ibGVtLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGUgYW5hbHlzdCdzIGNvcmUgbG9vcCDigJQgY2hhbmdlIGFueSBhc3N1bXB0aW9uLCB3YXRjaFxcbmV2ZXJ5dGhpbmcgcmVjYWxjIOKAlCBvbmx5IHdvcmtzIGZvciB0aGUgdGhyZWUgZGVjbGFyZWQgbWFuaWZlc3QgcGFyYW1zLiBUaGUgdGF4XFxucmF0ZSBvciBzd2VlcCBwZXJjZW50YWdlIGNhbm5vdCBiZSB3aGF0LWlmZmVkIHdpdGhvdXQgZWRpdGluZyBhIGZpeHR1cmUsIGFuZFxcbm5vdGhpbmcgdGVsbHMgdGhlIHJlYWRlciB3aGljaCBsZWF2ZXMgXCJ9PF9jb21wb25lbnRzLmVtPntcImNvdWxkXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgYmUga25vYnMuIFRoZSBiaWdnZXN0XFxuZGFpbHktZnJpY3Rpb24gZ2FwLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkFwcHJvYWNoLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBFeHBsaWNpdCwgdmFsaWRhdGVkLCBvcHQtaW46IFwifTxfY29tcG9uZW50cy5jb2RlPntcInJlY2tvbmVyLmpzb25cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGdhaW5zXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wcmU+PF9jb21wb25lbnRzLmNvZGUgY2xhc3NOYW1lPVwibGFuZ3VhZ2UtanNvbmNcIj57XCJcXFwicGFyYW1SZWZzXFxcIjoge1xcbiAgXFxcInRheF9yYXRlXFxcIjogICAgICAgIHsgXFxcImZyb21cXFwiOiBcXFwiZml4dHVyZXMuYXNzdW1wdGlvbnNcXFwiLCBcXFwicGF0aFxcXCI6IFxcXCIwLnRheF9yYXRlXFxcIiB9LFxcbiAgXFxcImNhc2hfc3dlZXBfcGN0XFxcIjogIHsgXFxcImZyb21cXFwiOiBcXFwiZml4dHVyZXMuYXNzdW1wdGlvbnNcXFwiLCBcXFwicGF0aFxcXCI6IFxcXCIwLmNhc2hfc3dlZXBfcGN0XFxcIiB9XFxufVxcblwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnByZT57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5jb2RlPntcInBhcnNlTWFuaWZlc3RcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHZhbGlkYXRlcyBzaGFwZSAoYWRkaXRpdmUgb3B0aW9uYWwga2V5IOKAlCBmb3JtYXQgc3RheXMgMSk7XFxucmVzb2x1dGlvbiBoYXBwZW5zIGluIHRoZSBsb2FkZXIvYXBwOiB0aGUgcGFyYW0ncyBcIn08X2NvbXBvbmVudHMuZW0+e1wiZGVmYXVsdFwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGlzIHJlYWQgZnJvbSB0aGVcXG5yZWZlcmVuY2VkIGxlYWY7IGEgcnVudGltZSB3cml0ZSBcIn08X2NvbXBvbmVudHMuZW0+e1wic2hhZG93c1wifTwvX2NvbXBvbmVudHMuZW0+e1wiIHRoZSBsZWFmIGZvciBjZWxscyB0aGF0IGRlY2xhcmVkXFxudGhlIGZpeHR1cmUgaW5wdXQsIHJldXNpbmcgdGhlIGV4aXN0aW5nIGV4dGVybmFscy91cGRhdGUgcGF0aCDigJQgbm8gZW5naW5lXFxuY2hhbmdlLCB0aGUgZGVwZW5kZW5jeSBncmFwaCBhbHJlYWR5IHRyYWNrcyB0aGUgZml4dHVyZSBpbnB1dC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJTaGFkb3dpbmcgcnVsZSB0byBkZWNpZGU6IHJlcGxhY2UgdGhlIGxlYWYgaW5zaWRlIHRoZSBpbmplY3RlZCBmaXh0dXJlIHZhbHVlXFxuKHN0cnVjdHVyYWwgc2hhcmluZyksIHNvIGZvcm11bGFzIHNlZSBvbmUgY29oZXJlbnQgZnJvemVuIHNuYXBzaG90IOKAlCBuZXZlciBhXFxuc2Vjb25kIGFtYmllbnQgY2hhbm5lbC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJ4cmVmOiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJwYXJhbVJlZnNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGtleXMgY291bnQgYXMgcGFyYW1zIGZvciBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ2YWxpZGF0ZUV4dGVybmFsUmVmZXJlbmNlc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCI7XFxudW5rbm93biBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmcm9tXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJwYXRoXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDih5IgbG9hZCBkaWFnbm9zdGljLCBub3Qgc2lsZW50LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIlVJOiB0aGUgcGFyYW1zIHN1cmZhY2UgbGlzdHMgdGhlbSB3aXRoIHRoZWlyIGZpeHR1cmUgcHJvdmVuYW5jZTsgdGVtcGxhdGVzXFxubWF5IGJpbmQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiVmFsdWUgc291cmNlPVxcXCJwYXJhbXMudGF4X3JhdGVcXFwiXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBvciBhIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlJhbmdlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB3aXRoIGRlY2xhcmVkIGJvdW5kcy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJFeGl0IGdhdGVzLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBJbiB0aGUgcnVubmluZyBhcHAgb3ZlciB0aGUgQ2FsZGVyYSBkb2N1bWVudDogZmxpcFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcInBhcmFtcy50YXhfcmF0ZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgMjUl4oaSMzAlLCBvbmx5IHRoZSBkZXBlbmRlbnRzIG9mIFwifTxfY29tcG9uZW50cy5jb2RlPntcImZpeHR1cmVzLmFzc3VtcHRpb25zXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIlxcbnJlY29tcHV0ZSAoYXNzZXJ0IHZpYSBwYXNzIHJlc3VsdHMpLCBJUlIgdmlzaWJseSBtb3ZlcywgdGhlIHNjaGVkdWxlIHJvd3NcXG5tYXRjaCBhIFB5dGhvbiB0cnV0aCB2YXJpYW50IGdlbmVyYXRlZCBmb3IgMzAlOyBhIGJyb2tlbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJwYXJhbVJlZnNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGVudHJ5XFxucHJvZHVjZXMgYSBsb2FkIGRpYWdub3N0aWMuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cInNlYy13NlwiIGRhdGEtc2x1Zz1cInc2LXN0ZGxpYi1maXhwb2ludC1oZWxwZXItZzFhLWJ1aWxkLXNcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy13NlwiIC8+e1wiVzYg4oCUIHN0ZGxpYiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmaXhwb2ludFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaGVscGVyIChHMWEsIGJ1aWxkLCBTKVwifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJQcm9ibGVtLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBDb252ZXJnZW50IChjaXJjdWxhcikgY2FsY3VsYXRpb25zIGFyZSBleHByZXNzaWJsZSB0b2RheSBvbmx5IGFzXFxuYSBoYW5kLXJvbGxlZCBsb29wIGluc2lkZSBhIGZvcm11bGEg4oCUIGNvcnJlY3QgYnV0IHVuZG9jdW1lbnRlZCBjb252ZW50aW9uLFxcbndpdGggbm8gc3RhbmRhcmQgcGxhY2UgZm9yIGl0ZXJhdGlvbiBjb3VudHMgYW5kIGNvbnZlcmdlbmNlIGV2aWRlbmNlLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkFwcHJvYWNoLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBGb3JtYWxpemUgdGhlIHBhdHRlcm4sIGNoYW5nZSBub3RoaW5nIGFib3V0IHRoZSBncmFwaDpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnByZT48X2NvbXBvbmVudHMuY29kZSBjbGFzc05hbWU9XCJsYW5ndWFnZS1qc1wiPntcImZpeHBvaW50KGluaXRpYWwsIHN0ZXAsIHsgdG9sID0gMWUtMTIsIG1heEl0ZXJhdGlvbnMgPSAyMDAgfSlcXG4vLyDihpIgeyBjb252ZXJnZWQsIGl0ZXJhdGlvbnMsIHZhbHVlIH0g4oCUIGBjb252ZXJnZWQ6IGZhbHNlYCBpcyB0aGUgVkFMVUUnc1xcbi8vICAgcmVzcG9uc2liaWxpdHkgdG8gc3VyZmFjZSAob3IgYSB2aXNpYmxlIGVycm9yKSwgbmV2ZXIgc2lsZW50LlxcblwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnByZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJQdXJlLCBhZGRpdGl2ZSwgc2VsZi1kZXNjcmliZWQuIChUaGlzIGlzIHRoZSBDYWxkZXJhIGF2Zy1iYWxhbmNlIGxvb3AgbGlmdGVkXFxudmVyYmF0aW0uKVwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkV4aXQgZ2F0ZXMuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5jb2RlPntcImRlYnRfc2NoZWR1bGVfYXZnXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB1c2VzIFwifTxfY29tcG9uZW50cy5jb2RlPntcImZpeHBvaW50XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjsgdGhlIGNvbnZlcmdlbmNlIHByb3BlcnR5XFxudGVzdCBub3cgYXNzZXJ0cyBvbiB0aGUgcmV0dXJuZWQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaXRlcmF0aW9uc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY29udmVyZ2VkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiByZWNvcmQ7IHVuaXQgdGVzdHNcXG5mb3Igbm9uLWNvbnZlcmdlbmNlIChvc2NpbGxhdGluZyBzdGVwIOKHkiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjb252ZXJnZWQ6IGZhbHNlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cInNlYy13N1wiIGRhdGEtc2x1Zz1cInc3LWNvbnZlcmdlZC1jZWxsLWRlc2lnbi1zcGlrZS1zcGVjLWcxYi1kZXNpZ24tbVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLXc3XCIgLz57XCJXNyDigJQgQ29udmVyZ2VkLWNlbGwgZGVzaWduIHNwaWtlIOKGkiBzcGVjIChHMWIsIGRlc2lnbiwgTSlcIn08L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUHJvYmxlbS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgV2hldGhlciBjb252ZXJnZW5jZSBkZXNlcnZlcyB0byBiZSBhIFwifTxfY29tcG9uZW50cy5lbT57XCJjZWxsIGtpbmRcIn08L19jb21wb25lbnRzLmVtPntcIiAoZmlyc3QtY2xhc3M6XFxuaXRlcmF0aW9uIGNvdW50cyBvbiB0aGUgdHJhY2UgY2hhbm5lbCwgbm9uLWNvbnZlcmdlbmNlIGEgbGF0dGljZSBlcnJvcixcXG5wZXItY2VsbCBidWRnZXQgYWdhaW5zdCB0aGUgd2F0Y2hkb2cpIG9yIHN0YXlzIGEgaGVscGVyIChXNikgaXMgYW4gb3BlbiBkZXNpZ25cXG5xdWVzdGlvbiB3aXRoIHJlYWwgaW5mb3JtYXRpb24tZmxvdyBjb25zZXF1ZW5jZXMuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQXBwcm9hY2guXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIERlc2lnbiBzcHJpbnQsIG5vdCBpbXBsZW1lbnRhdGlvbjogZHJhZnQgdGhlIHNwZWMgY292ZXJpbmcg4oCUXFxudGhlIGNlbGwta2luZCBBUEkgdnMgaGVscGVyLW9ubHk7IHdoZXJlIGl0ZXJhdGlvbiBjb3VudHMgKyByZXNpZHVhbHMgZmxvd1xcbihFTkdJTkVfSU5GT1JNQVRJT05fRkxPV19TUEVDOiBhbm90aGVyIFwifTxfY29tcG9uZW50cy5jb2RlPntcIihlcG9jaCwgdGllcilcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLXRhZ2dlZCBjaGFubmVsKTsgdGhlXFxuZmFpbHVyZSBzdG9yeSAoZXhjZWVkIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1heEl0ZXJhdGlvbnNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKHkiB2aXNpYmxlIGVycm9yIG9uIHRoZSBjZWxsIOKAlCBFeGNlbCdzXFxuc2lsZW50LWl0ZXJhdGl2ZS1jYWxjIGZhaWx1cmUgY2xhc3MsIHN0cnVjdHVyYWxseSBpbXBvc3NpYmxlIGhlcmUpOyB2ZXJzaW9uaW5nXFxuKGEgbmV3IGNvbnN0cnVjdG9yIGlzIGEgc3RkbGliIGFkZGl0aW9uOyBkb2N1bWVudHMgdXNpbmcgaXQgYnVtcCB0aGVpciBkZXJpdmVkXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY29tcGF0LnN0ZGxpYlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZmxvb3IgYXV0b21hdGljYWxseSBwZXIgRE9DVU1FTlRfVkVSU0lPTklOR19TUEVDIMKnMykuXFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJHYXRlOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBnby9uby1nbyB3aXRoIHRoZSBuYW1lZCBjcml0ZXJpb24g4oCUIGltcGxlbWVudCB0aGUgY2VsbCBraW5kIG9ubHkgaWZcXG5hIHJlYWwgZG9jdW1lbnQgbmVlZHMgY29udmVyZ2VuY2UgXCJ9PF9jb21wb25lbnRzLmVtPntcImRpYWdub3N0aWNzXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgKGl0ZXJhdGlvbiBjb3VudHMgc3VyZmFjZWQgaW5cXG50aGUgcmV2aWV3IHN1cmZhY2UsIGJ1ZGdldCBhY2NvdW50aW5nKSwgbm90IG1lcmVseSBjb252ZXJnZW5jZS4gSWYgVzYgaGFzXFxuY292ZXJlZCBldmVyeSBuZWVkIGJ5IHRoZW4sIGNsb3NlIHRoaXMgaXRlbSBhcyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJoZWxwZXItb25seSwgcmVjb3JkZWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuYmxvY2txdW90ZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIk91dGNvbWUgKDIwMjYtMDgtMjcsIFIzLTM3OSk6IGhlbHBlci1vbmx5LCByZWNvcmRlZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgdGhlIGRlY2lzaW9uLCB0aGVcXG5waW5uZWQgaWRpb20sIGFuZCB0aGUgdGhyZWUgYmVoYXZpb3JhbCByZW9wZW5pbmcgY3JpdGVyaWEgbGl2ZSBpblxcblwifTxfY29tcG9uZW50cy5hIGhyZWY9XCJzcGVjcy9DT05WRVJHRU5DRV9TUEVDLm1kXCI+PF9jb21wb25lbnRzLmNvZGU+e1wic3BlY3MvQ09OVkVSR0VOQ0VfU1BFQy5tZFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLmE+e1wiIMKnNOKAk8KnNiwgd2l0aCB0aGVcXG5hZHZlcnNhcmlhbCBzZWxmLXJldmlldyBvZiB0aGF0IGRlY2lzaW9uIGluIMKnNi5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cInNlYy13OFwiIGRhdGEtc2x1Zz1cInc4LXN3ZWVwLWNvbnN0cnVjdC1tZWFzdXJlLWZpcnN0LWc0LW1lYXN1cmUtc1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLXc4XCIgLz57XCJXOCDigJQgU3dlZXAgY29uc3RydWN0OiBtZWFzdXJlLWZpcnN0IChHNCwgbWVhc3VyZSwgUylcIn08L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUHJvYmxlbS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgRXhjZWwncyBkYXRhIHRhYmxlIGlzIDIgbWludXRlczsgUmVja29uZXIncyBzZW5zaXRpdml0eSBpcyBhXFxubW9kZWwtYXMtZnVuY3Rpb24gZGVjb21wb3NpdGlvbiB0YXguIEJlZm9yZSBidWlsZGluZyBhbiBlbmdpbmUtbGV2ZWxcXG5wYXJhbWV0cmljLWNlbGwgY29uc3RydWN0LCBtZWFzdXJlIHdoZXRoZXIgdGhlIFwifTxfY29tcG9uZW50cy5lbT57XCJhc3Npc3RhbnQgaWRpb21cIn08L19jb21wb25lbnRzLmVtPntcIiBhbHJlYWR5XFxuY2xvc2VzIHRoZSBnYXAuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQXBwcm9hY2guXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiRXh0ZW5kIFwifTxfY29tcG9uZW50cy5jb2RlPntcImRvY3MvYXNzaXN0YW50L0ZPUk1VTEFfQVVUSE9SSU5HX1BST01QVC5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgd2l0aCB0aGVcXG5tb2RlbC1hcy1mdW5jdGlvbiArIFwifTxfY29tcG9uZW50cy5jb2RlPntcInJ1bk1vZGVsXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiArIHN3ZWVwIGlkaW9tIChwb3N0LVczL1c0LCBzbyB0aGUgdGF1Z2h0XFxucHJpbWl0aXZlcyBleGlzdCksIGluY2x1ZGluZyB0aGUgYW50aS1wYXR0ZXJuIG5vdGUgKFxcXCJkb24ndCByZS1kZXJpdmUgaW5wdXRzXFxuaW5zaWRlIHRoZSBzd2VlcDsgcGFzcyB0aGUgZGVjbGFyZWQgaW5wdXRzIHRocm91Z2hcXFwiKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJCYWtlLW9mZiBpbiB0aGUgRS0xIHN0eWxlOiBOIGFnZW50IGF0dGVtcHRzIHRvIGF1dGhvciB0aGUgQ2FsZGVyYVxcbnNlbnNpdGl2aXR5IGNlbGwgZnJvbSBzZWxmLWRlc2NyaXB0aW9ucyBhbG9uZSwgc2NvcmVkIG9uIGZpcnN0LWF0dGVtcHRcXG5jb3JyZWN0bmVzcyArIGRpZmYgYXVkaXRhYmlsaXR5LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkdhdGUuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIElmIHRoZSBpZGlvbSBhdXRob3JzIHJlbGlhYmx5ICh0aGUgYmFyIEUtMSBzZXQgZm9yIHRoZSBEU0wpLCB0aGVcXG5lbmdpbmUtbGV2ZWwgY29uc3RydWN0IGlzIFwifTxfY29tcG9uZW50cy5lbT57XCJyZWplY3RlZCBhcyB1bm5lY2Vzc2FyeVwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGFuZCByZWNvcmRlZCBoZXJlOyBpZiBub3QsXFxudGhlIGZhaWx1cmUgbW9kZXMgbmFtZSB0aGUgcmVxdWlyZW1lbnRzIGZvciBhIFwifTxfY29tcG9uZW50cy5jb2RlPntcInN3ZWVwKClcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGRlc2lnbiBzcGlrZS4gRWl0aGVyXFxud2F5IHRoZSBkZWNpc2lvbiBpcyBtZWFzdXJlZCwgbm90IHZpYmVzLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCJzZWMtdzlcIiBkYXRhLXNsdWc9XCJ3OS1zb2x2ZS1nMy1idWlsZC1zXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtdzlcIiAvPntcIlc5IOKAlCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzb2x2ZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKEczLCBidWlsZCwgUylcIn08L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIjEtRCBtb25vdG9uZSBnb2FsIHNlZWsgYXMgYSBwdXJlIGhlbHBlciBzaGFyaW5nIFwifTxfY29tcG9uZW50cy5jb2RlPntcImlyclwifTwvX2NvbXBvbmVudHMuY29kZT57XCIncyBicmFja2V0aW5nIHNlbWFudGljc1xcbihcIn08X2NvbXBvbmVudHMuY29kZT57XCJzb2x2ZShmbiwgdGFyZ2V0LCBsbywgaGkpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIik7IGV4aXQgZ2F0ZTogXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYnJlYWtldmVuX2V4aXRfbXVsdGlwbGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHVzZXMgaXQsXFxucGFyaXR5IHZzIHRoZSBoYW5kLXJvbGxlZCBiaXNlY3Rpb24uIEludGVyYWN0aXZlL211bHRpLXZhcmlhdGUgU29sdmVyIHN0YXlzIGFcXG5ub24tZ29hbCAowqc1KS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwic2VjLXcxMFwiIGRhdGEtc2x1Zz1cIncxMC1kaXNwbGF5LWZvcm1hdHMtZm9yLWZpbmFuY2UtZzgtYnVpbGQtc1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLXcxMFwiIC8+e1wiVzEwIOKAlCBEaXNwbGF5IGZvcm1hdHMgZm9yIGZpbmFuY2UgKEc4LCBidWlsZCwgUylcIn08L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5jb2RlPntcImZvcm1hdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZW51bSBhZGRpdGlvbnMgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIm11bHRpcGxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiksIGEgdW5pdHMvc3VmZml4IGF0dHJpYnV0ZSBvbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJLcGlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcIlRhYmxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIlxcbmNvbHVtbnMgKGUuZy4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widW5pdD1cXFwiRVVSIG1cXFwiXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgYWNjb3VudGluZyBuZWdhdGl2ZXMpLCByaWRpbmcgdGhlIGNhdGFsb2ctdmVyc2lvblxcbmJ1bXAgcGVyIERPQ1VNRU5UX1ZFUlNJT05JTkdfU1BFQyDCpzMuMy4gRGlzcGxheS1vbmx5OyBhbnRpLWFmZm9yZGFuY2UgcmV2aWV3IGlzXFxuYSBmb3JtYWxpdHkuIEV4aXQ6IHRoZSBkZWFsIHN1bW1hcnkgcmVuZGVycyAyLjc1eCwgRVVSIG0sIGFuZCBwYXJlbnRoZXNpemVkXFxubmVnYXRpdmVzIHdpdGhvdXQgYmVzcG9rZSBmb3JtYXR0aW5nIGNlbGxzLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaHIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtMlwiIGRhdGEtc2x1Zz1cIjItbWlsZXN0b25lc1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTJcIiAvPntcIjIg4oCUIE1pbGVzdG9uZXNcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy50YWJsZT48X2NvbXBvbmVudHMudGhlYWQ+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50aD57XCJNaWxlc3RvbmVcIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aD57XCJJdGVtc1wifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIkdhdGVcIn08L19jb21wb25lbnRzLnRoPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudGJvZHk+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIk0wIOKAlCB1bmJsb2NrIHRlc3RpbmdcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJXMSwgVzJcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJ0aGUgaG9sZG91dCArIG9yYWNsZSArIGFkdmVyc2FyaWFsLWZsb2F0IHRlc3RzIHBhc3MgdGhyb3VnaCB0aGUgcmVhbCBlbmdpbmU7IHZlcmRpY3Qgc3VyZmFjZSB1bmNoYW5nZWRcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIk0xIOKAlCBmaW5hbmNlIHN0ZGxpYlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIlczLCBXNFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIkNhbGRlcmEgcG9ydC1mb3J3YXJkZWQgb250byBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyb2xsZm9yd2FyZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY3VtcHJvZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaXJyXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB3aXRoIHRoZSBQeXRob24gb3JhY2xlIGFzIHRoZSBvbmx5IHRydXRoOyBjYXRhbG9nIGdhdGUgZXh0ZW5kZWQ7IGNlaWxpbmcgcmUtY291bnQgcmVjb3JkZWRcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIk0yIOKAlCBsaXZlbmVzcyArIGNvbnZlcmdlbmNlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiVzUsIFc2XCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wibGl2ZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ0YXhfcmF0ZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIga25vYiBpbiB0aGUgYXBwOyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmaXhwb2ludFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgY2FycmllcyB0aGUgYXZnLWJhbGFuY2Ugc2NoZWR1bGVcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIk0zIOKAlCBkZXNpZ25zICYgbWVhc3VyZXNcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJXNywgVzhcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJjb252ZXJnZWQtY2VsbCBnby9uby1nbyByZWNvcmRlZDsgc3dlZXAtY29uc3RydWN0IGRlY2lzaW9uIG1lYXN1cmVkXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnN0cm9uZz57XCJNNCDigJQgcG9saXNoXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiVzksIFcxMFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcImdvYWwgc2VlayBvbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzb2x2ZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCI7IGZpbmFuY2UtZ3JhZGUgcmVuZGVyaW5nXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGJvZHk+PC9fY29tcG9uZW50cy50YWJsZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJNMCBmaXJzdCBhbmQgc21hbGw7IE0xIGlzIHRoZSBhZGRpdGl2ZS1vbmx5LWNsb2NrIGl0ZW0gKHByaW1pdGl2ZXMgbGFuZCBlYXJseVxcbm9yIGJlY29tZSBwZXJtYW5lbnQgc2NhcnMpOyBNMiBtYWtlcyB0aGUgYW5hbHlzdCBsb29wIHJlYWw7IE0zIHNwZW5kcyBkZXNpZ25cXG5vbmx5IHdoZXJlIE0yJ3MgY2hlYXAgdmVyc2lvbnMgbWlnaHQgYWxyZWFkeSBzdWZmaWNlOyBNNCBpcyB0YWlsLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaHIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtM1wiIGRhdGEtc2x1Zz1cIjMtZGVjaXNpb25zLXJlamVjdGVkLWFsdGVybmF0aXZlc1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTNcIiAvPntcIjMg4oCUIERlY2lzaW9ucyAmIHJlamVjdGVkIGFsdGVybmF0aXZlc1wifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlcxIGJlZm9yZSBldmVyeXRoaW5nLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBBIHdpcmluZyBidWcgYWdhaW5zdCB0aGUgcGxhbidzIG93biBzcGVjJ2RcXG5leGFtcGxlLCBhbmQgZXZlcnkgbGF0ZXIgaXRlbSB3cml0ZXMgdGVzdHMgdGhyb3VnaCB0aGUgcGF0aCBpdCBmaXhlcy5cXG5cIn08X2NvbXBvbmVudHMuZW0+e1wiUmVqZWN0ZWQ6XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgcm9sbGluZyBpdCBpbnRvIFczIOKAlCBpdCB3b3VsZCBibHVyIGEgYnVnZml4IHdpdGggYSBwcmltaXRpdmUuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz48X2NvbXBvbmVudHMuY29kZT57XCJyb2xsZm9yd2FyZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYXMgYSBwcmltaXRpdmUsIG5vdCBhIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNjYW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHR1dG9yaWFsLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGUgY2FzZSBzdHVkeVxcbnByb3ZlcyB0aGUgcGFja2VkLVwifTxfY29tcG9uZW50cy5jb2RlPntcIlNjYW5PcFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZXNjYXBlIGhhdGNoIHdvcmtzOyBkaXNjb3ZlcmFiaWxpdHksIG5vdFxcbmV4cHJlc3NpYmlsaXR5LCBpcyB0aGUgZ2FwLiBcIn08X2NvbXBvbmVudHMuZW0+e1wiUmVqZWN0ZWQ6XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgZG9jdW1lbnRpbmcgdGhlIHNjYW4gaWRpb20gb25seVxcbihzYW1lIGNsYXNzIG9mIGFuc3dlciBhcyBcXFwieW91IGNhbiBoYW5kLXJvbGwgSVJSXFxcIikuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJGaW5hbmNpYWwgZmFtaWx5IG1pbmltYWwgc2V0IChcIn08X2NvbXBvbmVudHMuY29kZT57XCJpcnJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcIm5wdlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wieGlyclwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBBZGRpdGl2ZS1vbmx5IGN1dHNcXG5ib3RoIHdheXM7IFwifTxfY29tcG9uZW50cy5jb2RlPntcInBtdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicmF0ZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgd2FpdCBmb3IgYSBuZWVkaW5nIGNhc2Ugc3R1ZHkuIFwifTxfY29tcG9uZW50cy5lbT57XCJSZWplY3RlZDpcIn08L19jb21wb25lbnRzLmVtPntcIiB0aGUgZnVsbFxcbkV4Y2VsIGZpbmFuY2lhbCBmYW1pbHkgdXAgZnJvbnQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz48X2NvbXBvbmVudHMuY29kZT57XCJwYXJhbVJlZnNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGV4cGxpY2l0IG92ZXIgY29udmVudGlvbnMuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIEFuIFxcXCJhc3N1bXB0aW9ucyBmaXh0dXJlXFxuYXV0by1leHBvc2VzIGV2ZXJ5IGxlYWZcXFwiIGNvbnZlbnRpb24gaXMgemVyby1jb25maWcgYnV0IGltcGxpY2l0IOKAlCB0aGVcXG5ncmlkJ3MgdW50eXBlZC12YWx1ZXMgc2luIGluIG5ldyBjbG90aGVzLiBFeHBsaWNpdCByZWZzIGFyZSBkaWZmYWJsZSxcXG52YWxpZGF0YWJsZSwgYW5kIGRlZ3JhZGFibGUgKGEgYnJva2VuIHJlZiBpcyBhIGRpYWdub3N0aWMpLlxcblwifTxfY29tcG9uZW50cy5lbT57XCJSZWplY3RlZDpcIn08L19jb21wb25lbnRzLmVtPntcIiB0aGUgY29udmVudGlvbjsgYWxzbyBcIn08X2NvbXBvbmVudHMuZW0+e1wicmVqZWN0ZWQ6XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgcGFyYW1zIGVkaXRhYmxlIHdpdGhvdXRcXG5kZWNsYXJhdGlvbiAoZGVzdHJveXMgdGhlIGRlcGVuZGVuY3kgc3RvcnkgcGFyYW1zIGV4aXN0IGZvcikuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz48X2NvbXBvbmVudHMuY29kZT57XCJmaXhwb2ludFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaGVscGVyIGJlZm9yZSBhbnkgY29udmVyZ2VkLWNlbGwga2luZC5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgU2hpcCB0aGUgY2hlYXAsXFxuYWRkaXRpdmUgZm9ybWFsaXphdGlvbjsgZGVzaWduIHRoZSBjZWxsIGtpbmQgb25seSBhZ2FpbnN0IGEgZGVtb25zdHJhdGVkXFxubmVlZCBmb3IgXCJ9PF9jb21wb25lbnRzLmVtPntcImRpYWdub3N0aWNzXCJ9PC9fY29tcG9uZW50cy5lbT57XCIsIHdpdGggdGhlIGdvL25vLWdvIGNyaXRlcmlvbiBuYW1lZCBpbiBXNy5cXG5cIn08X2NvbXBvbmVudHMuZW0+e1wiUmVqZWN0ZWQ6XCJ9PC9fY29tcG9uZW50cy5lbT57XCIganVtcGluZyB0byB0aGUgY2VsbCBraW5kIChlbmdpbmUgKyBzcGVjICsgdmVyc2lvbmluZyBjb3N0XFxuYmVmb3JlIHRoZSBuZWVkIGlzIHNob3duKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlN3ZWVwOiBtZWFzdXJlIGJlZm9yZSBidWlsZGluZy5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVzgncyBiYWtlLW9mZiBkZWNpZGVzOyB0aGUgY29uc3RydWN0IGlzXFxudGhlIGZhbGxiYWNrLCBub3QgdGhlIGRlZmF1bHQuIFwifTxfY29tcG9uZW50cy5lbT57XCJSZWplY3RlZDpcIn08L19jb21wb25lbnRzLmVtPntcIiBkZXNpZ25pbmcgcGFyYW1ldHJpYyBjZWxscyBvblxcbnRoZSBhc3N1bXB0aW9uIGFnZW50cyBjYW4ndCBhdXRob3IgdGhlIGlkaW9tLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtNFwiIGRhdGEtc2x1Zz1cIjQtbm9uLWdvYWxzLXYxLW9mLXRoaXMtcGxhblwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTRcIiAvPntcIjQg4oCUIE5vbi1nb2FscyAodjEgb2YgdGhpcyBwbGFuKVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiTXVsdGktdmFyaWF0ZSBTb2x2ZXI7IFZCQS9tYWNyb3MgKG5ldmVyIOKAlCB0aGUgc2VjdXJpdHkgbW9kZWwncyBwb2ludCk7XFxuRXhjZWwtc3R5bGUgZnJlZS1mb3JtIGxheW91dCBhdXRob3Jpbmc7IHBpdm90IHRhYmxlcyAocmVzaGFwZSBjb3ZlcnMgaXQpO1xcbmxpdmUtZmVlZCBpbmdlc3Rpb24gY2hhbmdlcyAodGhlIExCTyBjb3JwdXMgaXMgc3RhdGljIGJ5IGRlc2lnbiDigJQgTWVyaWRpYW5cXG5hbHJlYWR5IGNvdmVycyB0aGUgc3RyZWFtaW5nIGhhbGYpLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtNVwiIGRhdGEtc2x1Zz1cIjUtdGhlLWNhc2Utc3R1ZHktYXMtc3RhbmRpbmctYWNjZXB0YW5jZS1jb3JwdXNcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy01XCIgLz57XCI1IOKAlCBUaGUgY2FzZSBzdHVkeSBhcyBzdGFuZGluZyBhY2NlcHRhbmNlIGNvcnB1c1wifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiRWFjaCBwcmltaXRpdmUgaXRlbSAoVzMsIFc0LCBXNiwgVzkpIGxhbmRzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1widG9nZXRoZXIgd2l0aCBpdHMgQ2FsZGVyYVxcbnBvcnQtZm9yd2FyZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgYW5kIHRoZSBQeXRob24gb3JhY2xlIOKAlCByZWdlbmVyYXRlZCBieSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJnZW5lcmF0ZS5weVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGFzc2VydGVkXFxuYnkgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2FsZGVyYUNhc2VTdHVkeS50ZXN0LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgaXMgdGhlIG9ubHkgdHJ1dGggZWl0aGVyIHNpZGUgdG91Y2hlcy4gVGhpcyBpc1xcbnRoZSBwYXR0ZXJuIHRoZSBNZXJpZGlhbiBzdHVkeSBzZXQgYW5kIHRoZSByZWFzb24gdGhlc2UgcmVmYWN0b3JzIGFyZSBjaGVhcDpcXG50aGUgc3BlY2lmaWNhdGlvbiB0ZXN0cyBleGlzdCBcIn08X2NvbXBvbmVudHMuZW0+e1wiYmVmb3JlXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgdGhlIHJlZmFjdG9yLCB3aGljaCBpcyB0aGUgaHlwb3RoZXNpcydzXFxucHJvb2YgdHVybmluZyBpbnRvIHRoZSBoeXBvdGhlc2lzJ3MgZGl2aWRlbmQuXCJ9PC9fY29tcG9uZW50cy5wPjwvPjtcbn1cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE1EWENvbnRlbnQocHJvcHMgPSB7fSkge1xuICBjb25zdCB7d3JhcHBlcjogTURYTGF5b3V0fSA9IHtcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH07XG4gIHJldHVybiBNRFhMYXlvdXQgPyA8TURYTGF5b3V0IHsuLi5wcm9wc30+PF9jcmVhdGVNZHhDb250ZW50IHsuLi5wcm9wc30gLz48L01EWExheW91dD4gOiBfY3JlYXRlTWR4Q29udGVudChwcm9wcyk7XG59XG5mdW5jdGlvbiBfbWlzc2luZ01keFJlZmVyZW5jZShpZCwgY29tcG9uZW50LCBwbGFjZSkge1xuICB0aHJvdyBuZXcgRXJyb3IoXCJFeHBlY3RlZCBcIiArIChjb21wb25lbnQgPyBcImNvbXBvbmVudFwiIDogXCJvYmplY3RcIikgKyBcIiBgXCIgKyBpZCArIFwiYCB0byBiZSBkZWZpbmVkOiB5b3UgbGlrZWx5IGZvcmdvdCB0byBpbXBvcnQsIHBhc3MsIG9yIHByb3ZpZGUgaXQuXCIgKyAocGxhY2UgPyBcIlxcbkl04oCZcyByZWZlcmVuY2VkIGluIHlvdXIgY29kZSBhdCBgXCIgKyBwbGFjZSArIFwiYCBpbiBgL2FwcC9kb2NzL0xCT19HQVBfQ0xPU1VSRV9QTEFOLm1kYFwiIDogXCJcIikpO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFFQSxJQUFBQSxZQUFBLEdBQUFDLE9BQUE7QUFBd0YsSUFBQUMsV0FBQSxHQUFBRCxPQUFBO0FBRnhGO0FBQ0E7O0FBRUEsU0FBU0UsaUJBQWlCQSxDQUFDQyxLQUFLLEVBQUU7RUFDaEMsTUFBTUMsV0FBVyxHQUFHO01BQ2xCQyxDQUFDLEVBQUUsR0FBRztNQUNOQyxVQUFVLEVBQUUsWUFBWTtNQUN4QkMsSUFBSSxFQUFFLE1BQU07TUFDWkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsR0FBRyxFQUFFLEtBQUs7TUFDVkMsTUFBTSxFQUFFLFFBQVE7TUFDaEJDLEtBQUssRUFBRSxPQUFPO01BQ2RDLEtBQUssRUFBRSxPQUFPO01BQ2RDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEtBQUssRUFBRSxPQUFPO01BQ2RDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1IsR0FBRyxJQUFBQyw2QkFBa0IsRUFBQyxDQUFDO01BQ3ZCLEdBQUd0QixLQUFLLENBQUN1QjtJQUNYLENBQUM7SUFBRTtNQUFDQztJQUFhLENBQUMsR0FBR3ZCLFdBQVc7RUFDaEMsSUFBSSxDQUFDdUIsYUFBYSxFQUFFQyxvQkFBb0IsQ0FBQyxlQUFlLEVBQUUsSUFBSSxDQUFDO0VBQy9ELG9CQUFPLElBQUEzQixXQUFBLENBQUE0QixJQUFBLEVBQUE1QixXQUFBLENBQUE2QixRQUFBO0lBQUFDLFFBQUEsZ0JBQUUsSUFBQTlCLFdBQUEsQ0FBQTRCLElBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDdUIsRUFBRSxFQUFDLCtCQUErQjtNQUFBRCxRQUFBLGdCQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQStCLENBQUUsQ0FBQyxFQUFDLGlDQUFpQztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQS9CLFdBQUEsQ0FBQTRCLElBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1csQ0FBQztNQUFBZ0IsUUFBQSxnQkFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDYSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFTLENBQXFCLENBQUMsRUFBQyw4SEFBOEgsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBZ0MsQ0FBbUIsQ0FBQyxFQUFDLG9EQUFvRCxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNhLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVUsQ0FBcUIsQ0FBQyxFQUFDLGFBQWE7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNFLFVBQVU7TUFBQXlCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQTRCLElBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1csQ0FBQztRQUFBZ0IsUUFBQSxnQkFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDYSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFjLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0MsQ0FBQztVQUFDNkIsSUFBSSxFQUFDLGdDQUFnQztVQUFBSCxRQUFBLEVBQUU7UUFBZ0MsQ0FBZ0IsQ0FBQyxFQUFDLCtEQUErRCxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNDLENBQUM7VUFBQzZCLElBQUksRUFBQyxxQkFBcUI7VUFBQUgsUUFBQSxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7WUFBQXdCLFFBQUEsRUFBRTtVQUFxQixDQUFtQjtRQUFDLENBQWUsQ0FBQyxFQUFDLHdCQUF3QixlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUF1QyxDQUFtQixDQUFDLEVBQUMsNERBQTRELGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0MsQ0FBQztVQUFDNkIsSUFBSSxFQUFDLHNCQUFzQjtVQUFBSCxRQUFBLEVBQUU7UUFBc0IsQ0FBZ0IsQ0FBQyxFQUFDLG9GQUFvRixlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNDLENBQUM7VUFBQzZCLElBQUksRUFBQyxtQ0FBbUM7VUFBQUgsUUFBQSxFQUFFO1FBQTZCLENBQWdCLENBQUMsRUFBQyx3R0FBd0csZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBMEIsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBMkIsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBVSxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFZLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQW1DLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLE1BQU0sZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBeUIsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBMEIsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7TUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQXlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQTRCLElBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1csQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLG9GQUFvRixlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNhLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQWtFLENBQXFCLENBQUMsRUFBQyxxTUFBcU0sZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDSSxFQUFFO1FBQUF1QixRQUFBLEVBQUU7TUFBSyxDQUFpQixDQUFDLEVBQUMseU1BQXlNO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDUSxFQUFFLElBQUUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBWCxXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNNLEVBQUU7TUFBQ3NCLEVBQUUsRUFBQyxPQUFPO01BQUMsYUFBVSxXQUFXO01BQUFELFFBQUEsZ0JBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQyxhQUFhO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBL0IsV0FBQSxDQUFBNEIsSUFBQSxFQUFDekIsV0FBVyxDQUFDYyxLQUFLO01BQUFhLFFBQUEsZ0JBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2tCLEtBQUs7UUFBQVMsUUFBQSxlQUFDLElBQUE5QixXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNtQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2lCLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQUcsQ0FBaUIsQ0FBQyxtQkFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2lCLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQUssQ0FBaUIsQ0FBQyxtQkFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2lCLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQU0sQ0FBaUIsQ0FBQyxtQkFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2lCLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQU0sQ0FBaUIsQ0FBQyxtQkFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2lCLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQVcsQ0FBaUIsQ0FBQyxtQkFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2lCLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQU0sQ0FBaUIsQ0FBQyxtQkFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2lCLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQXNCLENBQWlCLENBQUM7UUFBQSxDQUFnQjtNQUFDLENBQW1CLENBQUMsbUJBQUE5QixXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNlLEtBQUs7UUFBQVksUUFBQSxnQkFBQyxJQUFBOUIsV0FBQSxDQUFBNEIsSUFBQSxFQUFDekIsV0FBVyxDQUFDbUIsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNnQixFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFJLENBQWlCLENBQUMsbUJBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNnQixFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFJLENBQWlCLENBQUMsbUJBQUE5QixXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNnQixFQUFFO1lBQUFXLFFBQUEsR0FBRSxPQUFPLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQWtCLENBQW1CLENBQUMsRUFBQyxvQkFBb0I7VUFBQSxDQUFpQixDQUFDLG1CQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBTyxDQUFpQixDQUFDLG1CQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBSSxDQUFpQixDQUFDLG1CQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBRyxDQUFpQixDQUFDLG1CQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBMkUsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE5QixXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNtQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQUksQ0FBaUIsQ0FBQyxtQkFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQUksQ0FBaUIsQ0FBQyxtQkFBQTlCLFdBQUEsQ0FBQTRCLElBQUEsRUFBQ3pCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVcsUUFBQSxHQUFFLDZDQUE2QyxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFpQixDQUFtQixDQUFDO1VBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQU8sQ0FBaUIsQ0FBQyxtQkFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQUksQ0FBaUIsQ0FBQyxtQkFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQUcsQ0FBaUIsQ0FBQyxtQkFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQW9GLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBOUIsV0FBQSxDQUFBNEIsSUFBQSxFQUFDekIsV0FBVyxDQUFDbUIsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNnQixFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFJLENBQWlCLENBQUMsbUJBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNnQixFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFJLENBQWlCLENBQUMsbUJBQUE5QixXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNnQixFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQWEsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBUyxDQUFtQixDQUFDLEVBQUMsb0JBQW9CO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQU8sQ0FBaUIsQ0FBQyxtQkFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQUksQ0FBaUIsQ0FBQyxtQkFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQUcsQ0FBaUIsQ0FBQyxtQkFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQXdFLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBOUIsV0FBQSxDQUFBNEIsSUFBQSxFQUFDekIsV0FBVyxDQUFDbUIsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNnQixFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFJLENBQWlCLENBQUMsbUJBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNnQixFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFJLENBQWlCLENBQUMsbUJBQUE5QixXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNnQixFQUFFO1lBQUFXLFFBQUEsR0FBRSxvQkFBb0IsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBSyxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFLLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQU0sQ0FBbUIsQ0FBQztVQUFBLENBQWdCLENBQUMsbUJBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNnQixFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFPLENBQWlCLENBQUMsbUJBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNnQixFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFJLENBQWlCLENBQUMsbUJBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNnQixFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFLLENBQWlCLENBQUMsbUJBQUE5QixXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNnQixFQUFFO1lBQUFXLFFBQUEsR0FBRSxzQkFBc0IsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBSyxDQUFtQixDQUFDLEVBQUMsdUNBQXVDO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE5QixXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNtQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQUksQ0FBaUIsQ0FBQyxtQkFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQUksQ0FBaUIsQ0FBQyxtQkFBQTlCLFdBQUEsQ0FBQTRCLElBQUEsRUFBQ3pCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVcsUUFBQSxHQUFFLHlCQUF5QixlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFXLENBQW1CLENBQUMsRUFBQyxtQkFBbUI7VUFBQSxDQUFpQixDQUFDLG1CQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBTyxDQUFpQixDQUFDLG1CQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBSSxDQUFpQixDQUFDLG1CQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBRyxDQUFpQixDQUFDLG1CQUFBOUIsV0FBQSxDQUFBNEIsSUFBQSxFQUFDekIsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFVLENBQW1CLENBQUMsRUFBQyw2REFBNkQ7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTlCLFdBQUEsQ0FBQTRCLElBQUEsRUFBQ3pCLFdBQVcsQ0FBQ21CLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBSSxDQUFpQixDQUFDLG1CQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBSyxDQUFpQixDQUFDLG1CQUFBOUIsV0FBQSxDQUFBNEIsSUFBQSxFQUFDekIsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVyxRQUFBLEdBQUUsU0FBUyxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFVLENBQW1CLENBQUMsRUFBQyx5Q0FBeUM7VUFBQSxDQUFpQixDQUFDLG1CQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBTyxDQUFpQixDQUFDLG1CQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBSSxDQUFpQixDQUFDLG1CQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBRyxDQUFpQixDQUFDLG1CQUFBOUIsV0FBQSxDQUFBNEIsSUFBQSxFQUFDekIsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFtQixDQUFtQixDQUFDLEVBQUMsUUFBUSxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFVLENBQW1CLENBQUMsRUFBQyw4QkFBOEI7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTlCLFdBQUEsQ0FBQTRCLElBQUEsRUFBQ3pCLFdBQVcsQ0FBQ21CLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBSSxDQUFpQixDQUFDLG1CQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBSyxDQUFpQixDQUFDLG1CQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBb0MsQ0FBaUIsQ0FBQyxtQkFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQVEsQ0FBaUIsQ0FBQyxtQkFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQUksQ0FBaUIsQ0FBQyxtQkFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQUcsQ0FBaUIsQ0FBQyxtQkFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQXlFLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBOUIsV0FBQSxDQUFBNEIsSUFBQSxFQUFDekIsV0FBVyxDQUFDbUIsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNnQixFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFJLENBQWlCLENBQUMsbUJBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNnQixFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFJLENBQWlCLENBQUMsbUJBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNnQixFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUE4QyxDQUFpQixDQUFDLG1CQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBUyxDQUFpQixDQUFDLG1CQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBSSxDQUFpQixDQUFDLG1CQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBRyxDQUFpQixDQUFDLG1CQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBZ0csQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE5QixXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNtQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQUksQ0FBaUIsQ0FBQyxtQkFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQUksQ0FBaUIsQ0FBQyxtQkFBQTlCLFdBQUEsQ0FBQTRCLElBQUEsRUFBQ3pCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBTyxDQUFtQixDQUFDLEVBQUMsa0NBQWtDO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQU8sQ0FBaUIsQ0FBQyxtQkFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQUksQ0FBaUIsQ0FBQyxtQkFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQUcsQ0FBaUIsQ0FBQyxtQkFBQTlCLFdBQUEsQ0FBQTRCLElBQUEsRUFBQ3pCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBeUIsQ0FBbUIsQ0FBQyxFQUFDLFFBQVEsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBTyxDQUFtQixDQUFDLEVBQUMseUJBQXlCO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE5QixXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNtQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQUssQ0FBaUIsQ0FBQyxtQkFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQUksQ0FBaUIsQ0FBQyxtQkFBQTlCLFdBQUEsQ0FBQTRCLElBQUEsRUFBQ3pCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVcsUUFBQSxHQUFFLG1CQUFtQixlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFVLENBQW1CLENBQUMsRUFBQywwQkFBMEI7VUFBQSxDQUFpQixDQUFDLG1CQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBTyxDQUFpQixDQUFDLG1CQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBSSxDQUFpQixDQUFDLG1CQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBRyxDQUFpQixDQUFDLG1CQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBd0UsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUM7TUFBQSxDQUFtQixDQUFDO0lBQUEsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDVyxDQUFDO01BQUFnQixRQUFBLEVBQUU7SUFBOE0sQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDUSxFQUFFLElBQUUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBWCxXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNNLEVBQUU7TUFBQ3NCLEVBQUUsRUFBQyxPQUFPO01BQUMsYUFBVSxjQUFjO01BQUFELFFBQUEsZ0JBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQyxnQkFBZ0I7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEvQixXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNPLEVBQUU7TUFBQ3FCLEVBQUUsRUFBQyxRQUFRO01BQUMsYUFBVSwyREFBMkQ7TUFBQUQsUUFBQSxnQkFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFRLENBQUUsQ0FBQyxFQUFDLGlFQUFpRTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQS9CLFdBQUEsQ0FBQTRCLElBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1csQ0FBQztNQUFBZ0IsUUFBQSxnQkFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDYSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFVLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQWUsQ0FBbUIsQ0FBQyxFQUFDLGNBQWMsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBa0IsQ0FBbUIsQ0FBQyxFQUFDLHlHQUF5RyxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFzQixDQUFtQixDQUFDLEVBQUMsY0FBYyxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFjLENBQW1CLENBQUMsRUFBQyxPQUFPLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0ksRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQVMsQ0FBaUIsQ0FBQyxFQUFDLGNBQWMsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBcUIsQ0FBbUIsQ0FBQyxFQUFDLFFBQVEsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBd0IsQ0FBbUIsQ0FBQyxFQUFDLGdCQUFnQixlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFrQixDQUFtQixDQUFDLEVBQUMsaU5BQWlOLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQWlCLENBQW1CLENBQUMsRUFBQyxhQUFhO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDVyxDQUFDO01BQUFnQixRQUFBLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2EsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBVyxDQUFxQjtJQUFDLENBQWUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBNEIsSUFBQSxFQUFDekIsV0FBVyxDQUFDb0IsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNTLEVBQUU7UUFBQWtCLFFBQUEsR0FBRSxzSEFBc0gsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBWSxDQUFtQixDQUFDLEVBQUMsd0NBQXdDLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLHlEQUF5RCxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNJLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFTLENBQWlCLENBQUMsRUFBQywyQ0FBMkMsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBTSxDQUFtQixDQUFDLEVBQUMsYUFBYSxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFzQixDQUFtQixDQUFDLEVBQUMsSUFBSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQTRCLElBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsRUFBRTtRQUFBa0IsUUFBQSxHQUFFLFlBQVksZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBYyxDQUFtQixDQUFDLEVBQUMsK0JBQStCLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQXVCLENBQW1CLENBQUMsRUFBQyx1RUFBdUU7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNTLEVBQUU7UUFBQWtCLFFBQUEsR0FBRSw4QkFBOEIsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBNkMsQ0FBbUIsQ0FBQyxFQUFDLFNBQVMsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBUyxDQUFtQixDQUFDLEVBQUMsNkJBQTZCLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQVksQ0FBbUIsQ0FBQyxFQUFDLGdJQUFnSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDVyxDQUFDO01BQUFnQixRQUFBLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2EsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBYSxDQUFxQjtJQUFDLENBQWUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBNEIsSUFBQSxFQUFDekIsV0FBVyxDQUFDVSxFQUFFO01BQUFpQixRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNTLEVBQUU7UUFBQWtCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2EsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBYyxDQUFxQixDQUFDLEVBQUMsdUJBQXVCLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQWlCLENBQW1CLENBQUMsRUFBQyx5QkFBeUIsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBTSxDQUFtQixDQUFDLEVBQUMsVUFBVSxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUEyQixDQUFtQixDQUFDLEVBQUMsd0hBQXdILGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQXNCLENBQW1CLENBQUMsRUFBQyxHQUFHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBNEIsSUFBQSxFQUFDekIsV0FBVyxDQUFDUyxFQUFFO1FBQUFrQixRQUFBLEdBQUUsTUFBTSxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNhLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWEsQ0FBcUIsQ0FBQyxFQUFDLHFCQUFxQixlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUEwQixDQUFtQixDQUFDLEVBQUMsa0RBQWtELGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQWlCLENBQW1CLENBQUMsRUFBQyxXQUFXO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBNEIsSUFBQSxFQUFDekIsV0FBVyxDQUFDUyxFQUFFO1FBQUFrQixRQUFBLEdBQUUsbUVBQW1FLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQWtCLENBQW1CLENBQUMsRUFBQywwQkFBMEIsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBb0IsQ0FBbUIsQ0FBQyxFQUFDLElBQUk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNTLEVBQUU7UUFBQWtCLFFBQUEsR0FBRSxtQkFBbUIsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBYSxDQUFtQixDQUFDLEVBQUMscURBQXFEO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNPLEVBQUU7TUFBQ3FCLEVBQUUsRUFBQyxRQUFRO01BQUMsYUFBVSwrQ0FBK0M7TUFBQUQsUUFBQSxnQkFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFRLENBQUUsQ0FBQyxFQUFDLHFEQUFxRDtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQS9CLFdBQUEsQ0FBQTRCLElBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1csQ0FBQztNQUFBZ0IsUUFBQSxnQkFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDYSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFVLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQXVCLENBQW1CLENBQUMsRUFBQyx1QkFBdUIsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBVyxDQUFtQixDQUFDLEVBQUMsd0hBQXdILGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQWlCLENBQW1CLENBQUMsRUFBQyxVQUFVLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0ksRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQU8sQ0FBaUIsQ0FBQyxFQUFDLGlJQUFpSTtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ1csQ0FBQztNQUFBZ0IsUUFBQSxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNhLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVcsQ0FBcUI7SUFBQyxDQUFlLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQTRCLElBQUEsRUFBQ3pCLFdBQVcsQ0FBQ29CLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBNEIsSUFBQSxFQUFDekIsV0FBVyxDQUFDUyxFQUFFO1FBQUFrQixRQUFBLEdBQUUsb0NBQW9DLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQUssQ0FBbUIsQ0FBQyxFQUFDLDZDQUE2QyxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUMsRUFBQyxvQ0FBb0MsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBYSxDQUFtQixDQUFDLEVBQUMsbURBQW1ELGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLDhIQUE4SCxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNJLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFhLENBQWlCLENBQUMsRUFBQywwQkFBMEI7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNTLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQWlCLENBQW1CLENBQUMsRUFBQyxTQUFTLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQW1CLENBQW1CLENBQUMsRUFBQyxPQUFPLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQWtCLENBQW1CLENBQUMsRUFBQyxzR0FBc0c7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQTRCLElBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1csQ0FBQztNQUFBZ0IsUUFBQSxnQkFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDYSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFhLENBQXFCLENBQUMsRUFBQywrRUFBK0UsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBdUIsQ0FBbUIsQ0FBQyxFQUFDLHlCQUF5QixlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFXLENBQW1CLENBQUMsRUFBQyxPQUFPLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQXVDLENBQW1CLENBQUMsRUFBQyxtR0FBbUc7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNPLEVBQUU7TUFBQ3FCLEVBQUUsRUFBQyxRQUFRO01BQUMsYUFBVSxxREFBcUQ7TUFBQUQsUUFBQSxnQkFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFRLENBQUUsQ0FBQyxFQUFDLE9BQU8sZUFBQyxJQUFBL0IsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBYSxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFTLENBQW1CLENBQUMsRUFBQyxtQ0FBbUM7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNXLENBQUM7TUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2EsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBVSxDQUFxQixDQUFDLEVBQUMscUxBQXFMLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQVEsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBUSxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFRLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQUssQ0FBbUIsQ0FBQyxFQUFDLDJEQUEyRCxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFRLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQVEsQ0FBbUIsQ0FBQyxFQUFDLDRJQUE0SSxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFTLENBQW1CLENBQUMsRUFBQyxrREFBa0Q7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNXLENBQUM7TUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2EsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBWSxDQUFxQixDQUFDLEVBQUMsZ0RBQWdEO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDWSxHQUFHO01BQUFlLFFBQUEsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1FBQUM0QixTQUFTLEVBQUMsYUFBYTtRQUFBSixRQUFBLEVBQUU7TUFBd2MsQ0FBbUI7SUFBQyxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNXLENBQUM7TUFBQWdCLFFBQUEsR0FBRSw2REFBNkQsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBTyxDQUFtQixDQUFDLEVBQUMsUUFBUSxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFRLENBQW1CLENBQUMsRUFBQyw4RkFBOEYsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBTyxDQUFtQixDQUFDLEVBQUMsbURBQW1ELGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQU0sQ0FBbUIsQ0FBQyxFQUFDLDZCQUE2QixlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFNLENBQW1CLENBQUMsRUFBQyx3RkFBd0YsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBTSxDQUFtQixDQUFDLEVBQUMseUJBQXlCO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDVyxDQUFDO01BQUFnQixRQUFBLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2EsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBYSxDQUFxQjtJQUFDLENBQWUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBNEIsSUFBQSxFQUFDekIsV0FBVyxDQUFDVSxFQUFFO01BQUFpQixRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNTLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQXFCLENBQW1CLENBQUMsRUFBQyxpRUFBaUU7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNTLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2EsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBZSxDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFnQixDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFlLENBQW1CLENBQUMsRUFBQyx3QkFBd0IsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBTSxDQUFtQixDQUFDLEVBQUMsZ0JBQWdCLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBUyxDQUFtQixDQUFDLEVBQUMsc0VBQXNFLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0ksRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQXdHLENBQWlCLENBQUM7TUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNTLEVBQUU7UUFBQWtCLFFBQUEsRUFBRTtNQUFrRyxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQTRCLElBQUEsRUFBQ3pCLFdBQVcsQ0FBQ08sRUFBRTtNQUFDcUIsRUFBRSxFQUFDLFFBQVE7TUFBQyxhQUFVLHVEQUF1RDtNQUFBRCxRQUFBLGdCQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVEsQ0FBRSxDQUFDLEVBQUMsa0NBQWtDLGVBQUMsSUFBQS9CLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQUssQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBSyxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFNLENBQW1CLENBQUMsRUFBQyxtQkFBbUI7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNXLENBQUM7TUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2EsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBVSxDQUFxQixDQUFDLEVBQUMseUtBQXlLO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBNEIsSUFBQSxFQUFDekIsV0FBVyxDQUFDVyxDQUFDO01BQUFnQixRQUFBLGdCQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNhLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVcsQ0FBcUIsQ0FBQyxFQUFDLHNCQUFzQixlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFtQixDQUFtQixDQUFDLEVBQUMsNEhBQTRILGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0ksRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQWdCLENBQWlCLENBQUMsRUFBQyx5REFBeUQsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBa0IsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBZ0MsQ0FBbUIsQ0FBQyxFQUFDLCtEQUErRCxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFVLENBQW1CLENBQUMsRUFBQyxhQUFhLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQUssQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBTSxDQUFtQixDQUFDLEVBQUMsb0dBQW9HLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0ksRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQVMsQ0FBaUIsQ0FBQyxFQUFDLDBCQUEwQjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQTRCLElBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1csQ0FBQztNQUFBZ0IsUUFBQSxnQkFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDYSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFPLENBQXFCLENBQUMsRUFBQyxxRUFBcUUsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBYSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFTLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQVUsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBTyxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFLLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQUssQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBTSxDQUFtQixDQUFDLEVBQUMsbU5BQW1OO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBNEIsSUFBQSxFQUFDekIsV0FBVyxDQUFDVyxDQUFDO01BQUFnQixRQUFBLGdCQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNhLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQWEsQ0FBcUIsQ0FBQyxFQUFDLFdBQVcsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBUyxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFhLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQVcsQ0FBbUIsQ0FBQyxFQUFDLGFBQWEsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBSyxDQUFtQixDQUFDLEVBQUMsa0JBQWtCLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQUssQ0FBbUIsQ0FBQyxFQUFDLHVIQUF1SCxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFnQixDQUFtQixDQUFDLEVBQUMsR0FBRztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQTRCLElBQUEsRUFBQ3pCLFdBQVcsQ0FBQ08sRUFBRTtNQUFDcUIsRUFBRSxFQUFDLFFBQVE7TUFBQyxhQUFVLHFDQUFxQztNQUFBRCxRQUFBLGdCQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVEsQ0FBRSxDQUFDLEVBQUMsMkNBQTJDO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBL0IsV0FBQSxDQUFBNEIsSUFBQSxFQUFDekIsV0FBVyxDQUFDVyxDQUFDO01BQUFnQixRQUFBLGdCQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNhLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVUsQ0FBcUIsQ0FBQyxFQUFDLCtQQUErUCxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNJLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUFPLENBQWlCLENBQUMsRUFBQyw2Q0FBNkM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNXLENBQUM7TUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2EsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBVyxDQUFxQixDQUFDLEVBQUMsZ0NBQWdDLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQWUsQ0FBbUIsQ0FBQyxFQUFDLFFBQVE7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNZLEdBQUc7TUFBQWUsUUFBQSxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7UUFBQzRCLFNBQVMsRUFBQyxnQkFBZ0I7UUFBQUosUUFBQSxFQUFFO01BQWdOLENBQW1CO0lBQUMsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBNEIsSUFBQSxFQUFDekIsV0FBVyxDQUFDb0IsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNTLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQWUsQ0FBbUIsQ0FBQyxFQUFDLGdIQUFnSCxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNJLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFTLENBQWlCLENBQUMsRUFBQyxzREFBc0QsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDSSxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBUyxDQUFpQixDQUFDLEVBQUMsOEtBQThLO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDUyxFQUFFO1FBQUFrQixRQUFBLEVBQUU7TUFBcUwsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBNEIsSUFBQSxFQUFDekIsV0FBVyxDQUFDUyxFQUFFO1FBQUFrQixRQUFBLEdBQUUsUUFBUSxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyw0QkFBNEIsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBNEIsQ0FBbUIsQ0FBQyxFQUFDLGFBQWEsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBTSxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFNLENBQW1CLENBQUMsRUFBQyxpQ0FBaUM7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNTLEVBQUU7UUFBQWtCLFFBQUEsR0FBRSx1RkFBdUYsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBa0MsQ0FBbUIsQ0FBQyxFQUFDLFFBQVEsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBTyxDQUFtQixDQUFDLEVBQUMsd0JBQXdCO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNXLENBQUM7TUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2EsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBYSxDQUFxQixDQUFDLEVBQUMsdURBQXVELGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQWlCLENBQW1CLENBQUMsRUFBQyxtQ0FBbUMsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBc0IsQ0FBbUIsQ0FBQyxFQUFDLHdJQUF3SSxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFXLENBQW1CLENBQUMsRUFBQyxxQ0FBcUM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNPLEVBQUU7TUFBQ3FCLEVBQUUsRUFBQyxRQUFRO01BQUMsYUFBVSx1Q0FBdUM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFRLENBQUUsQ0FBQyxFQUFDLGNBQWMsZUFBQyxJQUFBL0IsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBVSxDQUFtQixDQUFDLEVBQUMseUJBQXlCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBNEIsSUFBQSxFQUFDekIsV0FBVyxDQUFDVyxDQUFDO01BQUFnQixRQUFBLGdCQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNhLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVUsQ0FBcUIsQ0FBQyxFQUFDLHNOQUFzTjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQTRCLElBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1csQ0FBQztNQUFBZ0IsUUFBQSxnQkFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDYSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFXLENBQXFCLENBQUMsRUFBQyx5REFBeUQ7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNZLEdBQUc7TUFBQWUsUUFBQSxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7UUFBQzRCLFNBQVMsRUFBQyxhQUFhO1FBQUFKLFFBQUEsRUFBRTtNQUFnTixDQUFtQjtJQUFDLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ1csQ0FBQztNQUFBZ0IsUUFBQSxFQUFFO0lBQTBGLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQTRCLElBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1csQ0FBQztNQUFBZ0IsUUFBQSxnQkFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDYSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFhLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQW1CLENBQW1CLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQVUsQ0FBbUIsQ0FBQyxFQUFDLCtEQUErRCxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFZLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQVcsQ0FBbUIsQ0FBQyxFQUFDLCtEQUErRCxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFrQixDQUFtQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQTRCLElBQUEsRUFBQ3pCLFdBQVcsQ0FBQ08sRUFBRTtNQUFDcUIsRUFBRSxFQUFDLFFBQVE7TUFBQyxhQUFVLGtEQUFrRDtNQUFBRCxRQUFBLGdCQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVEsQ0FBRSxDQUFDLEVBQUMsMERBQTBEO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBL0IsV0FBQSxDQUFBNEIsSUFBQSxFQUFDekIsV0FBVyxDQUFDVyxDQUFDO01BQUFnQixRQUFBLGdCQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNhLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVUsQ0FBcUIsQ0FBQyxFQUFDLHdDQUF3QyxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNJLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUFXLENBQWlCLENBQUMsRUFBQyw0TkFBNE47SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNXLENBQUM7TUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2EsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBVyxDQUFxQixDQUFDLEVBQUMsbUxBQW1MLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQWUsQ0FBbUIsQ0FBQyxFQUFDLCtDQUErQyxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFlLENBQW1CLENBQUMsRUFBQywwTUFBME0sZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBZSxDQUFtQixDQUFDLEVBQUMsMERBQTBELGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2EsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBTyxDQUFxQixDQUFDLEVBQUMsMEdBQTBHLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0ksRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQWEsQ0FBaUIsQ0FBQyxFQUFDLDRKQUE0SixlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUF1QixDQUFtQixDQUFDLEVBQUMsR0FBRztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQTRCLElBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsVUFBVTtNQUFBeUIsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBNEIsSUFBQSxFQUFDekIsV0FBVyxDQUFDVyxDQUFDO1FBQUFnQixRQUFBLGdCQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNhLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXFELENBQXFCLENBQUMsRUFBQywyRkFBMkYsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDQyxDQUFDO1VBQUM2QixJQUFJLEVBQUMsMkJBQTJCO1VBQUFILFFBQUEsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1lBQUF3QixRQUFBLEVBQUU7VUFBMkIsQ0FBbUI7UUFBQyxDQUFlLENBQUMsRUFBQyxtRUFBbUU7TUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQXlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQTRCLElBQUEsRUFBQ3pCLFdBQVcsQ0FBQ08sRUFBRTtNQUFDcUIsRUFBRSxFQUFDLFFBQVE7TUFBQyxhQUFVLCtDQUErQztNQUFBRCxRQUFBLGdCQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVEsQ0FBRSxDQUFDLEVBQUMsc0RBQXNEO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBL0IsV0FBQSxDQUFBNEIsSUFBQSxFQUFDekIsV0FBVyxDQUFDVyxDQUFDO01BQUFnQixRQUFBLGdCQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNhLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVUsQ0FBcUIsQ0FBQyxFQUFDLHNMQUFzTCxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNJLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUFpQixDQUFpQixDQUFDLEVBQUMsMkJBQTJCO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDVyxDQUFDO01BQUFnQixRQUFBLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2EsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBVyxDQUFxQjtJQUFDLENBQWUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBNEIsSUFBQSxFQUFDekIsV0FBVyxDQUFDVSxFQUFFO01BQUFpQixRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNTLEVBQUU7UUFBQWtCLFFBQUEsR0FBRSxTQUFTLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQTRDLENBQW1CLENBQUMsRUFBQyxpQ0FBaUMsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBVSxDQUFtQixDQUFDLEVBQUMsaUxBQWlMO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDUyxFQUFFO1FBQUFrQixRQUFBLEVBQUU7TUFBNkssQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNXLENBQUM7TUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2EsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBTyxDQUFxQixDQUFDLEVBQUMsK0ZBQStGLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0ksRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQXlCLENBQWlCLENBQUMsRUFBQyw2RUFBNkUsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBUyxDQUFtQixDQUFDLEVBQUMsaUVBQWlFO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBNEIsSUFBQSxFQUFDekIsV0FBVyxDQUFDTyxFQUFFO01BQUNxQixFQUFFLEVBQUMsUUFBUTtNQUFDLGFBQVUscUJBQXFCO01BQUFELFFBQUEsZ0JBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBUSxDQUFFLENBQUMsRUFBQyxPQUFPLGVBQUMsSUFBQS9CLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQU8sQ0FBbUIsQ0FBQyxFQUFDLGlCQUFpQjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQTRCLElBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1csQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLGtEQUFrRCxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFLLENBQW1CLENBQUMsRUFBQyw0QkFBNEIsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBMkIsQ0FBbUIsQ0FBQyxFQUFDLGdCQUFnQixlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUF5QixDQUFtQixDQUFDLEVBQUMsMEdBQTBHO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBNEIsSUFBQSxFQUFDekIsV0FBVyxDQUFDTyxFQUFFO01BQUNxQixFQUFFLEVBQUMsU0FBUztNQUFDLGFBQVUsNENBQTRDO01BQUFELFFBQUEsZ0JBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBUyxDQUFFLENBQUMsRUFBQyxrREFBa0Q7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEvQixXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNXLENBQUM7TUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQVEsQ0FBbUIsQ0FBQyxFQUFDLG1CQUFtQixlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFVLENBQW1CLENBQUMsRUFBQyxpQ0FBaUMsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBSyxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFPLENBQW1CLENBQUMsRUFBQyxrQkFBa0IsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLGdRQUFnUTtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ1EsRUFBRSxJQUFFLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQVgsV0FBQSxDQUFBNEIsSUFBQSxFQUFDekIsV0FBVyxDQUFDTSxFQUFFO01BQUNzQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUsY0FBYztNQUFBRCxRQUFBLGdCQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMsZ0JBQWdCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBL0IsV0FBQSxDQUFBNEIsSUFBQSxFQUFDekIsV0FBVyxDQUFDYyxLQUFLO01BQUFhLFFBQUEsZ0JBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2tCLEtBQUs7UUFBQVMsUUFBQSxlQUFDLElBQUE5QixXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNtQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2lCLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQVcsQ0FBaUIsQ0FBQyxtQkFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2lCLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQU8sQ0FBaUIsQ0FBQyxtQkFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2lCLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQU0sQ0FBaUIsQ0FBQztRQUFBLENBQWdCO01BQUMsQ0FBbUIsQ0FBQyxtQkFBQTlCLFdBQUEsQ0FBQTRCLElBQUEsRUFBQ3pCLFdBQVcsQ0FBQ2UsS0FBSztRQUFBWSxRQUFBLGdCQUFDLElBQUE5QixXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNtQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNhLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQXNCLENBQXFCO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQVEsQ0FBaUIsQ0FBQyxtQkFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQXdHLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBOUIsV0FBQSxDQUFBNEIsSUFBQSxFQUFDekIsV0FBVyxDQUFDbUIsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNnQixFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDYSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFxQixDQUFxQjtVQUFDLENBQWdCLENBQUMsbUJBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNnQixFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFRLENBQWlCLENBQUMsbUJBQUE5QixXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNnQixFQUFFO1lBQUFXLFFBQUEsR0FBRSw4QkFBOEIsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBYSxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFTLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQUssQ0FBbUIsQ0FBQyxFQUFDLDZGQUE2RjtVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBOUIsV0FBQSxDQUFBNEIsSUFBQSxFQUFDekIsV0FBVyxDQUFDbUIsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNnQixFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDYSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUE2QixDQUFxQjtVQUFDLENBQWdCLENBQUMsbUJBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNnQixFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFRLENBQWlCLENBQUMsbUJBQUE5QixXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNnQixFQUFFO1lBQUFXLFFBQUEsR0FBRSxPQUFPLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQVUsQ0FBbUIsQ0FBQyxFQUFDLG9CQUFvQixlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFVLENBQW1CLENBQUMsRUFBQyxtQ0FBbUM7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTlCLFdBQUEsQ0FBQTRCLElBQUEsRUFBQ3pCLFdBQVcsQ0FBQ21CLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2EsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBeUIsQ0FBcUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBUSxDQUFpQixDQUFDLG1CQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBcUUsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE5QixXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNtQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNhLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQWEsQ0FBcUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBUyxDQUFpQixDQUFDLG1CQUFBOUIsV0FBQSxDQUFBNEIsSUFBQSxFQUFDekIsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVyxRQUFBLEdBQUUsZUFBZSxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFPLENBQW1CLENBQUMsRUFBQywyQkFBMkI7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQztNQUFBLENBQW1CLENBQUM7SUFBQSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNXLENBQUM7TUFBQWdCLFFBQUEsRUFBRTtJQUFnTyxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNRLEVBQUUsSUFBRSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFYLFdBQUEsQ0FBQTRCLElBQUEsRUFBQ3pCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDc0IsRUFBRSxFQUFDLE9BQU87TUFBQyxhQUFVLG1DQUFtQztNQUFBRCxRQUFBLGdCQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMsdUNBQXVDO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBL0IsV0FBQSxDQUFBNEIsSUFBQSxFQUFDekIsV0FBVyxDQUFDb0IsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNTLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ2EsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBdUIsQ0FBcUIsQ0FBQyxFQUFDLHNIQUFzSCxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNJLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFXLENBQWlCLENBQUMsRUFBQyxnRUFBZ0U7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNTLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTlCLFdBQUEsQ0FBQTRCLElBQUEsRUFBQ3pCLFdBQVcsQ0FBQ2EsTUFBTTtVQUFBYyxRQUFBLGdCQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7WUFBQXdCLFFBQUEsRUFBRTtVQUFhLENBQW1CLENBQUMsRUFBQyx5QkFBeUIsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1lBQUF3QixRQUFBLEVBQUU7VUFBTSxDQUFtQixDQUFDLEVBQUMsWUFBWTtRQUFBLENBQXFCLENBQUMsRUFBQyxxQ0FBcUMsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMseUVBQXlFLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0ksRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLHdGQUF3RjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQTRCLElBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBOUIsV0FBQSxDQUFBNEIsSUFBQSxFQUFDekIsV0FBVyxDQUFDYSxNQUFNO1VBQUFjLFFBQUEsR0FBRSxnQ0FBZ0MsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1lBQUF3QixRQUFBLEVBQUU7VUFBSyxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNHLElBQUk7WUFBQXdCLFFBQUEsRUFBRTtVQUFLLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBd0IsUUFBQSxFQUFFO1VBQU0sQ0FBbUIsQ0FBQyxFQUFDLElBQUk7UUFBQSxDQUFxQixDQUFDLEVBQUMsa0NBQWtDLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQUssQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBTSxDQUFtQixDQUFDLEVBQUMsa0NBQWtDLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0ksRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLDZDQUE2QztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQTRCLElBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBOUIsV0FBQSxDQUFBNEIsSUFBQSxFQUFDekIsV0FBVyxDQUFDYSxNQUFNO1VBQUFjLFFBQUEsZ0JBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBd0IsUUFBQSxFQUFFO1VBQVcsQ0FBbUIsQ0FBQyxFQUFDLDZCQUE2QjtRQUFBLENBQXFCLENBQUMsRUFBQyx5T0FBeU8sZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDSSxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBVyxDQUFpQixDQUFDLEVBQUMsd0JBQXdCLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0ksRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLHlGQUF5RjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQTRCLElBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBOUIsV0FBQSxDQUFBNEIsSUFBQSxFQUFDekIsV0FBVyxDQUFDYSxNQUFNO1VBQUFjLFFBQUEsZ0JBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBd0IsUUFBQSxFQUFFO1VBQVUsQ0FBbUIsQ0FBQyxFQUFDLHlDQUF5QztRQUFBLENBQXFCLENBQUMsRUFBQyx1R0FBdUcsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDSSxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBYSxDQUFpQixDQUFDLEVBQUMsOENBQThDLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0ksRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLHdGQUF3RjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQTRCLElBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDYSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFpQyxDQUFxQixDQUFDLEVBQUMsMkVBQTJFLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0ksRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLCtFQUErRTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBNEIsSUFBQSxFQUFDekIsV0FBVyxDQUFDTSxFQUFFO01BQUNzQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUsNkJBQTZCO01BQUFELFFBQUEsZ0JBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQyxpQ0FBaUM7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEvQixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNXLENBQUM7TUFBQWdCLFFBQUEsRUFBRTtJQUFvUSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUE0QixJQUFBLEVBQUN6QixXQUFXLENBQUNNLEVBQUU7TUFBQ3NCLEVBQUUsRUFBQyxPQUFPO01BQUMsYUFBVSxnREFBZ0Q7TUFBQUQsUUFBQSxnQkFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLGtEQUFrRDtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQS9CLFdBQUEsQ0FBQTRCLElBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1csQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLDZDQUE2QyxlQUFDLElBQUE5QixXQUFBLENBQUFnQyxHQUFBLEVBQUM3QixXQUFXLENBQUNhLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQXlDLENBQXFCLENBQUMsRUFBQywyQ0FBMkMsZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDRyxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBYSxDQUFtQixDQUFDLEVBQUMsaUJBQWlCLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQWdDLEdBQUEsRUFBQzdCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQTBCLENBQW1CLENBQUMsRUFBQyxpS0FBaUssZUFBQyxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDN0IsV0FBVyxDQUFDSSxFQUFFO1FBQUF1QixRQUFBLEVBQUU7TUFBUSxDQUFpQixDQUFDLEVBQUMseUZBQXlGO0lBQUEsQ0FBZ0IsQ0FBQztFQUFBLENBQUUsQ0FBQztBQUNob3JDO0FBQ2UsU0FBU0ssVUFBVUEsQ0FBQ2pDLEtBQUssR0FBRyxDQUFDLENBQUMsRUFBRTtFQUM3QyxNQUFNO0lBQUNrQyxPQUFPLEVBQUVDO0VBQVMsQ0FBQyxHQUFHO0lBQzNCLEdBQUcsSUFBQWIsNkJBQWtCLEVBQUMsQ0FBQztJQUN2QixHQUFHdEIsS0FBSyxDQUFDdUI7RUFDWCxDQUFDO0VBQ0QsT0FBT1ksU0FBUyxnQkFBRyxJQUFBckMsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDSyxTQUFTO0lBQUEsR0FBS25DLEtBQUs7SUFBQTRCLFFBQUEsZUFBRSxJQUFBOUIsV0FBQSxDQUFBZ0MsR0FBQSxFQUFDL0IsaUJBQWlCO01BQUEsR0FBS0M7SUFBSyxDQUFHO0VBQUMsQ0FBVyxDQUFDLEdBQUdELGlCQUFpQixDQUFDQyxLQUFLLENBQUM7QUFDbEg7QUFBQ29DLEVBQUEsR0FOdUJILFVBQVU7QUFPbEMsU0FBU1Isb0JBQW9CQSxDQUFDSSxFQUFFLEVBQUVRLFNBQVMsRUFBRUMsS0FBSyxFQUFFO0VBQ2xELE1BQU0sSUFBSUMsS0FBSyxDQUFDLFdBQVcsSUFBSUYsU0FBUyxHQUFHLFdBQVcsR0FBRyxRQUFRLENBQUMsR0FBRyxJQUFJLEdBQUdSLEVBQUUsR0FBRyxvRUFBb0UsSUFBSVMsS0FBSyxHQUFHLHFDQUFxQyxHQUFHQSxLQUFLLEdBQUcsMENBQTBDLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDcFE7QUFBQyxJQUFBRixFQUFBO0FBQUFJLFlBQUEsQ0FBQUosRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}