var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      blockquote: "blockquote",
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      h3: "h3",
      li: "li",
      ol: "ol",
      p: "p",
      strong: "strong",
      table: "table",
      tbody: "tbody",
      td: "td",
      th: "th",
      thead: "thead",
      tr: "tr",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "reckoner-product-definition",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "reckoner-product-definition"
      }), "Reckoner — Product Definition"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Status:"
      }), " draft · ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Updated:"
      }), " 2026-07-09"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: ["Reckoner is the product name for the design explored in the immediately.run platform spec\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "REPORTING_SPREADSHEET_SPEC.md",
          children: "REPORTING_SPREADSHEET_SPEC.md"
        }), " (a copy of\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "docs/specs/REPORTING_SPREADSHEET_SPEC.md"
        }), " from the immediately.run docs repo, which remains\ncanonical). This document describes ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "what Reckoner is"
        }), " for\nusers; the platform spec owns the security architecture, and\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "problem_statement.md",
          children: "problem_statement.md"
        }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "research_proposal.md",
          children: "research_proposal.md"
        }), "\nown what remains unsolved."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "one-paragraph-summary",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "one-paragraph-summary"
      }), "One-paragraph summary"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Reckoner is a dashboard, reporting, and data-analysis application that treats report logic as\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "software"
      }), " rather than as spreadsheet folklore. A Reckoner document pairs two artifacts: a\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "workbook"
      }), " of worksheets — spreadsheet/notebook-like collections of named cells whose\nformulas are ordinary JavaScript/TypeScript, each covered by unit tests — and one or more\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "report templates"
      }), ", written in a non-executable subset of MDX, that lay out charts, tables,\nKPIs, and prose bound to those cells. Data can be ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "static"
      }), " (entered in the sheet), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "pulled"
      }), "\n(looked up from an external source on demand), or ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "live"
      }), " (streamed, with the report updating\nin real time), and viewers can ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "drill into"
      }), " interactive reports without ever touching a\nformula. Because formulas are real code, they are authored primarily by coding agents, tested\nlike code, versioned like code, and reviewed like code — while the report a viewer opens stays\nas safe and as instant as opening a web page."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "why-it-exists",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "why-it-exists"
      }), "Why it exists"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Two observations motivate Reckoner:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Spreadsheets carry an organization's most vital reporting information but give poor means\nto build rich, live, interactive dashboards."
        }), " The grid is a great input surface and a poor\npresentation surface; \"the dashboard\" usually means exporting to a separate BI tool that\nforks the logic."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "A spreadsheet is a programming language with none of the tooling."
        }), " Formulas have no\ntests, no types, no review, no version history at the logic level, and no meaningful way\nfor a coding agent to help. If formulas were JavaScript, report logic would be a\nunit-testable, agent-authorable, diff-reviewable software artifact."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Reckoner is the bet that both problems have the same fix: separate the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "logic"
      }), " (a tested\nworkbook) from the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "presentation"
      }), " (a declarative template), make both plain files in a\nrepository, and let the platform's sandboxing make it safe to share the result with people who\nhave no reason to trust the author."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "core-concepts",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "core-concepts"
      }), "Core concepts"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "workbook-worksheet-cell",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "workbook-worksheet-cell"
      }), "Workbook, worksheet, cell"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["A ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "workbook"
      }), " is the logic layer of a Reckoner document. It contains ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "worksheets"
      }), " — ordered,\nnotebook-like collections of ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "cells"
      }), ". A cell has:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "name"
        }), " (cells are referenced by name, not by grid coordinates — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "revenue.q3"
        }), ", not ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "B7"
        }), ");"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "formula"
        }), ": a JavaScript/TypeScript function of its inputs. Inputs are other cells, static\nvalues, or data feeds. Formulas are pure with respect to their declared inputs — same inputs,\nsame output;"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "tests"
        }), ": unit tests that live beside the formula and run in the same evaluation\nenvironment the formula runs in. A cell without tests is visibly untested, the way uncovered\ncode is visibly uncovered;"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "value"
        }), ": the current result of evaluating the formula over the current inputs. Values are\ncomputed, displayed, and recomputed when inputs change; they are not silently persisted back\ninto the document (see \"Live data and freezing\" below)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Worksheets are files. A workbook is a directory of files. Everything an agent or a human needs\nto understand, test, and change the logic is on disk in a git repository — no opaque binary\ndocument format."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "report-template",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "report-template"
      }), "Report template"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["A ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "report template"
      }), " is the presentation layer: a document written in a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "non-executable\nsubset of MDX"
      }), " that arranges prose, charts, tables, KPI tiles, and layout primitives, and\nbinds them to workbook cells ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "declaratively"
      }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "<Chart source=\"revenue.by_month\" />"
      }), ", never\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "{code()}"
      }), ". The template language deliberately cannot express computation:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: "no expression evaluation, no event handlers, no arbitrary components — a fixed, audited\ncomponent catalog with typed attributes;"
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: "data bindings are attribute references to named cells or feeds, resolved by the renderer;"
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: "unknown components render as a safe placeholder rather than executing anything."
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "This restriction is what makes reports shareable: opening someone else's dashboard renders\ntheir template through a safe renderer without running a single line of their code in the\nviewer's context. Computation lives in the workbook, where it is sandboxed, starved of\ncapabilities, and tested. (The renderer design is the platform's non-executable-MDX safe\nrenderer; see the platform spec §3.4.)"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Interactivity — filtering, drill-down, parameter widgets — is expressed as declarative\ntemplate affordances whose state feeds back into designated ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "input cells"
      }), ", so \"the viewer\npicked region = EMEA\" is just another input the workbook recomputes over."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "data-static-pulled-live",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "data-static-pulled-live"
      }), "Data: static, pulled, live"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Every value in a report is ultimately one of three kinds:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Kind"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Where it lives"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Freshness"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Example"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Static"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "in the worksheet itself"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "changes only when edited"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "budget assumptions, targets, manual entries"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Pulled"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "an external source, fetched on demand"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "as of last lookup"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "a currency rate, a database query result"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Live"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "an external stream"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "continuously updated"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "ops metrics, order flow, sensor data"
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Pulled and live data enter through ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "data connectors"
      }), " — deliberately \"dumb\" ingestion\ncomponents that fetch from configured sources and materialize results where formulas can read\nthem. Connectors are the only part of a Reckoner document that touches the network or\ncredentials, and they are configuration-driven: fetched content never decides what else to\nfetch or where to send anything."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "reports-are-run-mode-first",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "reports-are-run-mode-first"
      }), "Reports are run-mode-first"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Consuming a report is the primary experience, and it is never taxed to improve authoring\n(platform value 2). Concretely:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["A dashboard containing ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "only static data opens instantly with no permission prompts at\nall"
        }), " — the viewer just sees the report."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["Consent UI appears only when the viewer ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "activates a live feed"
        }), " or another elevated\nfeature, and it is scoped to exactly that."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["Reports are first-class on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "mobile"
        }), " (platform value 8): templates degrade to a\nsingle-column reading experience, and drill-down works with touch."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "the-assistant",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-assistant"
      }), "The assistant"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Reckoner embeds a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "coding-agent assistant"
      }), " that authors and modifies formulas, tests, and\ntemplates on the user's behalf. The assistant is a first-class author (platform value 5): the\nexpected workflow for most users is conversational — \"add a cell that computes churn by\ncohort, test it against last quarter's numbers, and put a trend chart in the weekly report\" —\nwith the agent writing the code, running the tests, and showing the result live. The\nassistant's reach is bounded to the current document's content; publishing to a shared space\nor editing app source always passes through an attended, full-diff approval gate."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "who-it-is-for",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "who-it-is-for"
      }), "Who it is for"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Report viewers"
        }), " — the primary audience. They open a link, see a live report, drill into\nit, and never see a formula. Viewing must be as safe as visiting a web page: Reckoner runs\non immediately.run, so the worst a malicious report can do is bounded by the platform's\nsandbox and by whatever the viewer explicitly consented to (nothing, for a static report)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Report authors / analysts"
        }), " — the people accountable for the numbers. They work through\nthe assistant or directly in the workbook, and get software-grade tooling: tests, types,\nversion history, review."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Coding agents"
        }), " — at least as important as human authors. The formula API, the test\nharness, the template component catalog, and the document layout are all designed to be\ndriven from their self-descriptions, with no tribal knowledge."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Organizations"
        }), " — teams that fork Reckoner (or just its component catalog) to encode\nhouse data-visualization style and domain components, then publish internal dashboards over\nshared, access-controlled data."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "what-you-can-do-with-it",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "what-you-can-do-with-it"
      }), "What you can do with it"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Build a live dashboard"
        }), " whose logic is tested JavaScript and whose layout is a readable\nMDX document — both plain files in a git repository, cache-accelerated and instantly\nrunnable on immediately.run."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Share it"
        }), " with anyone. Static reports open with zero friction; live reports ask the\nviewer for exactly the feed access they activate."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Drill in"
        }), ": filter, expand, and re-parameterize interactive reports; the workbook\nrecomputes and the template re-renders live."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Stream data through it"
        }), ": connect a live source once, and every chart bound to it stays\ncurrent."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Delegate the authoring to an agent"
        }), ", with correctness anchored in the unit tests the\nagent writes and runs alongside every formula."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Fork and extend"
        }), ": add custom template components in a fork (component ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "definitions"
        }), " are\napp source; component ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "usages"
        }), " are content) — a report using ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<Timeline>"
        }), " renders fully in\na fork that ships it and degrades gracefully elsewhere."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "deployment-shapes",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "deployment-shapes"
      }), "Deployment shapes"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Reckoner inherits the platform's separation between ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "app code"
      }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "content"
      }), ", giving a\ncontinuum of deployment shapes (platform spec §1):"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Shape"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "App code"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Content (workbook + templates)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Character"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Stock Reckoner + your content"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "the canonical app, unmodified"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "your repo or space"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "portable, cross-org, public-safe"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Org fork + external content"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "your org's fork (custom components, house style)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "shared org space"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "org-customized"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Fused"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "fork with content embedded in the app repo"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["content ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
              children: "is"
            }), " app source"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "purpose-built single dashboard"
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "how-it-runs-the-shape-briefly",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "how-it-runs-the-shape-briefly"
      }), "How it runs (the shape, briefly)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Reckoner is not one program but a small ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "composite"
      }), " of isolated, sandboxed parts, each\nholding only what its job requires (platform spec §2):"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "report view"
        }), " renders templates and results — it executes no content code;"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "formula engine"
        }), " executes formulas and tests — it holds ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "no capabilities at all"
        }), "\n(no network, no filesystem beyond its inputs, no secrets);"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "data connector(s)"
        }), " fetch external data — they hold credentials and network access but\nexecute no content and host no agent;"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "assistant"
        }), " authors content — its tools are confined to this document."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Why it is shaped this way — and what remains genuinely unsolved about making that shape safe\nand pleasant — is the subject of ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "problem_statement.md",
        children: "problem_statement.md"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "what-reckoner-is-not",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "what-reckoner-is-not"
      }), "What Reckoner is not"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Not a spreadsheet grid clone."
        }), " There is no infinite grid of ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "A1"
        }), " coordinates; cells are\nnamed, formulas are functions, and layout belongs to templates. Importing tabular data is\nin scope; emulating Excel is not."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Not a hosted BI service."
        }), " All evaluation and rendering happen client-side in the\nviewer's browser, in immediately.run sandboxes. There is no Reckoner server executing\nformulas or warehousing data."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Not a general notebook."
        }), " Cells are pure formulas over declared inputs, not arbitrary\nstateful scripts with side effects. That restriction is what makes recalculation, testing,\nand safe sharing tractable."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Not a template engine that trusts its input."
        }), " Templates cannot compute; a report you\ndid not write cannot run code in your session by being rendered."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Not a replacement for the platform."
        }), " Sandboxing, consent, identity, sharing, and\ncontribution flows are immediately.run's; Reckoner composes them (platform value 7)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "related-documents",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "related-documents"
      }), "Related documents"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "problem_statement.md",
          children: "problem_statement.md"
        }), " — the three hard problems Reckoner must solve."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "research_proposal.md",
          children: "research_proposal.md"
        }), " — the open research questions and how we\npropose to attack them."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "REPORTING_SPREADSHEET_SPEC.md",
          children: "REPORTING_SPREADSHEET_SPEC.md"
        }), " — the platform-level\nsecurity architecture: the four-realm composite, the reach-not-egress confidentiality\nmodel, taint propagation, and the honest list of unbuilt platform prerequisites.\n(Local copy; the canonical version lives in the immediately.run docs repo at\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "docs/specs/REPORTING_SPREADSHEET_SPEC.md"
        }), ".)"]
      }), "\n"]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/product_definition.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiYmxvY2txdW90ZSIsImNvZGUiLCJlbSIsImgxIiwiaDIiLCJoMyIsImxpIiwib2wiLCJwIiwic3Ryb25nIiwidGFibGUiLCJ0Ym9keSIsInRkIiwidGgiLCJ0aGVhZCIsInRyIiwidWwiLCJfcHJvdmlkZUNvbXBvbmVudHMiLCJjb21wb25lbnRzIiwiSGVhZGluZ0FuY2hvciIsIl9taXNzaW5nTWR4UmVmZXJlbmNlIiwianN4cyIsIkZyYWdtZW50IiwiY2hpbGRyZW4iLCJpZCIsImpzeCIsImhyZWYiLCJNRFhDb250ZW50Iiwid3JhcHBlciIsIk1EWExheW91dCIsIl9jIiwiY29tcG9uZW50IiwicGxhY2UiLCJFcnJvciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbInByb2R1Y3RfZGVmaW5pdGlvbi5tZCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKkBqc3hSdW50aW1lIGF1dG9tYXRpYyovXG4vKkBqc3hJbXBvcnRTb3VyY2UgcmVhY3QqL1xuaW1wb3J0IHt1c2VNRFhDb21wb25lbnRzIGFzIF9wcm92aWRlQ29tcG9uZW50c30gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrL01EWFByb3ZpZGVyXCI7XG5mdW5jdGlvbiBfY3JlYXRlTWR4Q29udGVudChwcm9wcykge1xuICBjb25zdCBfY29tcG9uZW50cyA9IHtcbiAgICBhOiBcImFcIixcbiAgICBibG9ja3F1b3RlOiBcImJsb2NrcXVvdGVcIixcbiAgICBjb2RlOiBcImNvZGVcIixcbiAgICBlbTogXCJlbVwiLFxuICAgIGgxOiBcImgxXCIsXG4gICAgaDI6IFwiaDJcIixcbiAgICBoMzogXCJoM1wiLFxuICAgIGxpOiBcImxpXCIsXG4gICAgb2w6IFwib2xcIixcbiAgICBwOiBcInBcIixcbiAgICBzdHJvbmc6IFwic3Ryb25nXCIsXG4gICAgdGFibGU6IFwidGFibGVcIixcbiAgICB0Ym9keTogXCJ0Ym9keVwiLFxuICAgIHRkOiBcInRkXCIsXG4gICAgdGg6IFwidGhcIixcbiAgICB0aGVhZDogXCJ0aGVhZFwiLFxuICAgIHRyOiBcInRyXCIsXG4gICAgdWw6IFwidWxcIixcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH0sIHtIZWFkaW5nQW5jaG9yfSA9IF9jb21wb25lbnRzO1xuICBpZiAoIUhlYWRpbmdBbmNob3IpIF9taXNzaW5nTWR4UmVmZXJlbmNlKFwiSGVhZGluZ0FuY2hvclwiLCB0cnVlKTtcbiAgcmV0dXJuIDw+PF9jb21wb25lbnRzLmgxIGlkPVwicmVja29uZXItcHJvZHVjdC1kZWZpbml0aW9uXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJyZWNrb25lci1wcm9kdWN0LWRlZmluaXRpb25cIiAvPntcIlJlY2tvbmVyIOKAlCBQcm9kdWN0IERlZmluaXRpb25cIn08L19jb21wb25lbnRzLmgxPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiU3RhdHVzOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBkcmFmdCDCtyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlVwZGF0ZWQ6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIDIwMjYtMDctMDlcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiUmVja29uZXIgaXMgdGhlIHByb2R1Y3QgbmFtZSBmb3IgdGhlIGRlc2lnbiBleHBsb3JlZCBpbiB0aGUgaW1tZWRpYXRlbHkucnVuIHBsYXRmb3JtIHNwZWNcXG5cIn08X2NvbXBvbmVudHMuYSBocmVmPVwiUkVQT1JUSU5HX1NQUkVBRFNIRUVUX1NQRUMubWRcIj57XCJSRVBPUlRJTkdfU1BSRUFEU0hFRVRfU1BFQy5tZFwifTwvX2NvbXBvbmVudHMuYT57XCIgKGEgY29weSBvZlxcblwifTxfY29tcG9uZW50cy5jb2RlPntcImRvY3Mvc3BlY3MvUkVQT1JUSU5HX1NQUkVBRFNIRUVUX1NQRUMubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGZyb20gdGhlIGltbWVkaWF0ZWx5LnJ1biBkb2NzIHJlcG8sIHdoaWNoIHJlbWFpbnNcXG5jYW5vbmljYWwpLiBUaGlzIGRvY3VtZW50IGRlc2NyaWJlcyBcIn08X2NvbXBvbmVudHMuZW0+e1wid2hhdCBSZWNrb25lciBpc1wifTwvX2NvbXBvbmVudHMuZW0+e1wiIGZvclxcbnVzZXJzOyB0aGUgcGxhdGZvcm0gc3BlYyBvd25zIHRoZSBzZWN1cml0eSBhcmNoaXRlY3R1cmUsIGFuZFxcblwifTxfY29tcG9uZW50cy5hIGhyZWY9XCJwcm9ibGVtX3N0YXRlbWVudC5tZFwiPntcInByb2JsZW1fc3RhdGVtZW50Lm1kXCJ9PC9fY29tcG9uZW50cy5hPntcIiAvIFwifTxfY29tcG9uZW50cy5hIGhyZWY9XCJyZXNlYXJjaF9wcm9wb3NhbC5tZFwiPntcInJlc2VhcmNoX3Byb3Bvc2FsLm1kXCJ9PC9fY29tcG9uZW50cy5hPntcIlxcbm93biB3aGF0IHJlbWFpbnMgdW5zb2x2ZWQuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTwvX2NvbXBvbmVudHMuYmxvY2txdW90ZT57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJvbmUtcGFyYWdyYXBoLXN1bW1hcnlcIj48SGVhZGluZ0FuY2hvciBpZD1cIm9uZS1wYXJhZ3JhcGgtc3VtbWFyeVwiIC8+e1wiT25lLXBhcmFncmFwaCBzdW1tYXJ5XCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJSZWNrb25lciBpcyBhIGRhc2hib2FyZCwgcmVwb3J0aW5nLCBhbmQgZGF0YS1hbmFseXNpcyBhcHBsaWNhdGlvbiB0aGF0IHRyZWF0cyByZXBvcnQgbG9naWMgYXNcXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInNvZnR3YXJlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHJhdGhlciB0aGFuIGFzIHNwcmVhZHNoZWV0IGZvbGtsb3JlLiBBIFJlY2tvbmVyIGRvY3VtZW50IHBhaXJzIHR3byBhcnRpZmFjdHM6IGFcXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIndvcmtib29rXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIG9mIHdvcmtzaGVldHMg4oCUIHNwcmVhZHNoZWV0L25vdGVib29rLWxpa2UgY29sbGVjdGlvbnMgb2YgbmFtZWQgY2VsbHMgd2hvc2VcXG5mb3JtdWxhcyBhcmUgb3JkaW5hcnkgSmF2YVNjcmlwdC9UeXBlU2NyaXB0LCBlYWNoIGNvdmVyZWQgYnkgdW5pdCB0ZXN0cyDigJQgYW5kIG9uZSBvciBtb3JlXFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJyZXBvcnQgdGVtcGxhdGVzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCB3cml0dGVuIGluIGEgbm9uLWV4ZWN1dGFibGUgc3Vic2V0IG9mIE1EWCwgdGhhdCBsYXkgb3V0IGNoYXJ0cywgdGFibGVzLFxcbktQSXMsIGFuZCBwcm9zZSBib3VuZCB0byB0aG9zZSBjZWxscy4gRGF0YSBjYW4gYmUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJzdGF0aWNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKGVudGVyZWQgaW4gdGhlIHNoZWV0KSwgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJwdWxsZWRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCJcXG4obG9va2VkIHVwIGZyb20gYW4gZXh0ZXJuYWwgc291cmNlIG9uIGRlbWFuZCksIG9yIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibGl2ZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoc3RyZWFtZWQsIHdpdGggdGhlIHJlcG9ydCB1cGRhdGluZ1xcbmluIHJlYWwgdGltZSksIGFuZCB2aWV3ZXJzIGNhbiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImRyaWxsIGludG9cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgaW50ZXJhY3RpdmUgcmVwb3J0cyB3aXRob3V0IGV2ZXIgdG91Y2hpbmcgYVxcbmZvcm11bGEuIEJlY2F1c2UgZm9ybXVsYXMgYXJlIHJlYWwgY29kZSwgdGhleSBhcmUgYXV0aG9yZWQgcHJpbWFyaWx5IGJ5IGNvZGluZyBhZ2VudHMsIHRlc3RlZFxcbmxpa2UgY29kZSwgdmVyc2lvbmVkIGxpa2UgY29kZSwgYW5kIHJldmlld2VkIGxpa2UgY29kZSDigJQgd2hpbGUgdGhlIHJlcG9ydCBhIHZpZXdlciBvcGVucyBzdGF5c1xcbmFzIHNhZmUgYW5kIGFzIGluc3RhbnQgYXMgb3BlbmluZyBhIHdlYiBwYWdlLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJ3aHktaXQtZXhpc3RzXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJ3aHktaXQtZXhpc3RzXCIgLz57XCJXaHkgaXQgZXhpc3RzXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUd28gb2JzZXJ2YXRpb25zIG1vdGl2YXRlIFJlY2tvbmVyOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMub2w+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiU3ByZWFkc2hlZXRzIGNhcnJ5IGFuIG9yZ2FuaXphdGlvbidzIG1vc3Qgdml0YWwgcmVwb3J0aW5nIGluZm9ybWF0aW9uIGJ1dCBnaXZlIHBvb3IgbWVhbnNcXG50byBidWlsZCByaWNoLCBsaXZlLCBpbnRlcmFjdGl2ZSBkYXNoYm9hcmRzLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGUgZ3JpZCBpcyBhIGdyZWF0IGlucHV0IHN1cmZhY2UgYW5kIGEgcG9vclxcbnByZXNlbnRhdGlvbiBzdXJmYWNlOyBcXFwidGhlIGRhc2hib2FyZFxcXCIgdXN1YWxseSBtZWFucyBleHBvcnRpbmcgdG8gYSBzZXBhcmF0ZSBCSSB0b29sIHRoYXRcXG5mb3JrcyB0aGUgbG9naWMuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJBIHNwcmVhZHNoZWV0IGlzIGEgcHJvZ3JhbW1pbmcgbGFuZ3VhZ2Ugd2l0aCBub25lIG9mIHRoZSB0b29saW5nLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBGb3JtdWxhcyBoYXZlIG5vXFxudGVzdHMsIG5vIHR5cGVzLCBubyByZXZpZXcsIG5vIHZlcnNpb24gaGlzdG9yeSBhdCB0aGUgbG9naWMgbGV2ZWwsIGFuZCBubyBtZWFuaW5nZnVsIHdheVxcbmZvciBhIGNvZGluZyBhZ2VudCB0byBoZWxwLiBJZiBmb3JtdWxhcyB3ZXJlIEphdmFTY3JpcHQsIHJlcG9ydCBsb2dpYyB3b3VsZCBiZSBhXFxudW5pdC10ZXN0YWJsZSwgYWdlbnQtYXV0aG9yYWJsZSwgZGlmZi1yZXZpZXdhYmxlIHNvZnR3YXJlIGFydGlmYWN0LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJSZWNrb25lciBpcyB0aGUgYmV0IHRoYXQgYm90aCBwcm9ibGVtcyBoYXZlIHRoZSBzYW1lIGZpeDogc2VwYXJhdGUgdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibG9naWNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKGEgdGVzdGVkXFxud29ya2Jvb2spIGZyb20gdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicHJlc2VudGF0aW9uXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChhIGRlY2xhcmF0aXZlIHRlbXBsYXRlKSwgbWFrZSBib3RoIHBsYWluIGZpbGVzIGluIGFcXG5yZXBvc2l0b3J5LCBhbmQgbGV0IHRoZSBwbGF0Zm9ybSdzIHNhbmRib3hpbmcgbWFrZSBpdCBzYWZlIHRvIHNoYXJlIHRoZSByZXN1bHQgd2l0aCBwZW9wbGUgd2hvXFxuaGF2ZSBubyByZWFzb24gdG8gdHJ1c3QgdGhlIGF1dGhvci5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwiY29yZS1jb25jZXB0c1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwiY29yZS1jb25jZXB0c1wiIC8+e1wiQ29yZSBjb25jZXB0c1wifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwid29ya2Jvb2std29ya3NoZWV0LWNlbGxcIj48SGVhZGluZ0FuY2hvciBpZD1cIndvcmtib29rLXdvcmtzaGVldC1jZWxsXCIgLz57XCJXb3JrYm9vaywgd29ya3NoZWV0LCBjZWxsXCJ9PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJBIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wid29ya2Jvb2tcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgaXMgdGhlIGxvZ2ljIGxheWVyIG9mIGEgUmVja29uZXIgZG9jdW1lbnQuIEl0IGNvbnRhaW5zIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wid29ya3NoZWV0c1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgb3JkZXJlZCxcXG5ub3RlYm9vay1saWtlIGNvbGxlY3Rpb25zIG9mIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiY2VsbHNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIuIEEgY2VsbCBoYXM6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiYSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5hbWVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKGNlbGxzIGFyZSByZWZlcmVuY2VkIGJ5IG5hbWUsIG5vdCBieSBncmlkIGNvb3JkaW5hdGVzIOKAlCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyZXZlbnVlLnEzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgbm90IFwifTxfY29tcG9uZW50cy5jb2RlPntcIkI3XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIik7XCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiYSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImZvcm11bGFcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCI6IGEgSmF2YVNjcmlwdC9UeXBlU2NyaXB0IGZ1bmN0aW9uIG9mIGl0cyBpbnB1dHMuIElucHV0cyBhcmUgb3RoZXIgY2VsbHMsIHN0YXRpY1xcbnZhbHVlcywgb3IgZGF0YSBmZWVkcy4gRm9ybXVsYXMgYXJlIHB1cmUgd2l0aCByZXNwZWN0IHRvIHRoZWlyIGRlY2xhcmVkIGlucHV0cyDigJQgc2FtZSBpbnB1dHMsXFxuc2FtZSBvdXRwdXQ7XCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJ0ZXN0c1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIjogdW5pdCB0ZXN0cyB0aGF0IGxpdmUgYmVzaWRlIHRoZSBmb3JtdWxhIGFuZCBydW4gaW4gdGhlIHNhbWUgZXZhbHVhdGlvblxcbmVudmlyb25tZW50IHRoZSBmb3JtdWxhIHJ1bnMgaW4uIEEgY2VsbCB3aXRob3V0IHRlc3RzIGlzIHZpc2libHkgdW50ZXN0ZWQsIHRoZSB3YXkgdW5jb3ZlcmVkXFxuY29kZSBpcyB2aXNpYmx5IHVuY292ZXJlZDtcIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1widmFsdWVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCI6IHRoZSBjdXJyZW50IHJlc3VsdCBvZiBldmFsdWF0aW5nIHRoZSBmb3JtdWxhIG92ZXIgdGhlIGN1cnJlbnQgaW5wdXRzLiBWYWx1ZXMgYXJlXFxuY29tcHV0ZWQsIGRpc3BsYXllZCwgYW5kIHJlY29tcHV0ZWQgd2hlbiBpbnB1dHMgY2hhbmdlOyB0aGV5IGFyZSBub3Qgc2lsZW50bHkgcGVyc2lzdGVkIGJhY2tcXG5pbnRvIHRoZSBkb2N1bWVudCAoc2VlIFxcXCJMaXZlIGRhdGEgYW5kIGZyZWV6aW5nXFxcIiBiZWxvdykuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIldvcmtzaGVldHMgYXJlIGZpbGVzLiBBIHdvcmtib29rIGlzIGEgZGlyZWN0b3J5IG9mIGZpbGVzLiBFdmVyeXRoaW5nIGFuIGFnZW50IG9yIGEgaHVtYW4gbmVlZHNcXG50byB1bmRlcnN0YW5kLCB0ZXN0LCBhbmQgY2hhbmdlIHRoZSBsb2dpYyBpcyBvbiBkaXNrIGluIGEgZ2l0IHJlcG9zaXRvcnkg4oCUIG5vIG9wYXF1ZSBiaW5hcnlcXG5kb2N1bWVudCBmb3JtYXQuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cInJlcG9ydC10ZW1wbGF0ZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwicmVwb3J0LXRlbXBsYXRlXCIgLz57XCJSZXBvcnQgdGVtcGxhdGVcIn08L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJyZXBvcnQgdGVtcGxhdGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgaXMgdGhlIHByZXNlbnRhdGlvbiBsYXllcjogYSBkb2N1bWVudCB3cml0dGVuIGluIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJub24tZXhlY3V0YWJsZVxcbnN1YnNldCBvZiBNRFhcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdGhhdCBhcnJhbmdlcyBwcm9zZSwgY2hhcnRzLCB0YWJsZXMsIEtQSSB0aWxlcywgYW5kIGxheW91dCBwcmltaXRpdmVzLCBhbmRcXG5iaW5kcyB0aGVtIHRvIHdvcmtib29rIGNlbGxzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZGVjbGFyYXRpdmVseVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiPENoYXJ0IHNvdXJjZT1cXFwicmV2ZW51ZS5ieV9tb250aFxcXCIgLz5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBuZXZlclxcblwifTxfY29tcG9uZW50cy5jb2RlPntcIntjb2RlKCl9XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi4gVGhlIHRlbXBsYXRlIGxhbmd1YWdlIGRlbGliZXJhdGVseSBjYW5ub3QgZXhwcmVzcyBjb21wdXRhdGlvbjpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJubyBleHByZXNzaW9uIGV2YWx1YXRpb24sIG5vIGV2ZW50IGhhbmRsZXJzLCBubyBhcmJpdHJhcnkgY29tcG9uZW50cyDigJQgYSBmaXhlZCwgYXVkaXRlZFxcbmNvbXBvbmVudCBjYXRhbG9nIHdpdGggdHlwZWQgYXR0cmlidXRlcztcIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJkYXRhIGJpbmRpbmdzIGFyZSBhdHRyaWJ1dGUgcmVmZXJlbmNlcyB0byBuYW1lZCBjZWxscyBvciBmZWVkcywgcmVzb2x2ZWQgYnkgdGhlIHJlbmRlcmVyO1wifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcInVua25vd24gY29tcG9uZW50cyByZW5kZXIgYXMgYSBzYWZlIHBsYWNlaG9sZGVyIHJhdGhlciB0aGFuIGV4ZWN1dGluZyBhbnl0aGluZy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhpcyByZXN0cmljdGlvbiBpcyB3aGF0IG1ha2VzIHJlcG9ydHMgc2hhcmVhYmxlOiBvcGVuaW5nIHNvbWVvbmUgZWxzZSdzIGRhc2hib2FyZCByZW5kZXJzXFxudGhlaXIgdGVtcGxhdGUgdGhyb3VnaCBhIHNhZmUgcmVuZGVyZXIgd2l0aG91dCBydW5uaW5nIGEgc2luZ2xlIGxpbmUgb2YgdGhlaXIgY29kZSBpbiB0aGVcXG52aWV3ZXIncyBjb250ZXh0LiBDb21wdXRhdGlvbiBsaXZlcyBpbiB0aGUgd29ya2Jvb2ssIHdoZXJlIGl0IGlzIHNhbmRib3hlZCwgc3RhcnZlZCBvZlxcbmNhcGFiaWxpdGllcywgYW5kIHRlc3RlZC4gKFRoZSByZW5kZXJlciBkZXNpZ24gaXMgdGhlIHBsYXRmb3JtJ3Mgbm9uLWV4ZWN1dGFibGUtTURYIHNhZmVcXG5yZW5kZXJlcjsgc2VlIHRoZSBwbGF0Zm9ybSBzcGVjIMKnMy40LilcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiSW50ZXJhY3Rpdml0eSDigJQgZmlsdGVyaW5nLCBkcmlsbC1kb3duLCBwYXJhbWV0ZXIgd2lkZ2V0cyDigJQgaXMgZXhwcmVzc2VkIGFzIGRlY2xhcmF0aXZlXFxudGVtcGxhdGUgYWZmb3JkYW5jZXMgd2hvc2Ugc3RhdGUgZmVlZHMgYmFjayBpbnRvIGRlc2lnbmF0ZWQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJpbnB1dCBjZWxsc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgc28gXFxcInRoZSB2aWV3ZXJcXG5waWNrZWQgcmVnaW9uID0gRU1FQVxcXCIgaXMganVzdCBhbm90aGVyIGlucHV0IHRoZSB3b3JrYm9vayByZWNvbXB1dGVzIG92ZXIuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cImRhdGEtc3RhdGljLXB1bGxlZC1saXZlXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJkYXRhLXN0YXRpYy1wdWxsZWQtbGl2ZVwiIC8+e1wiRGF0YTogc3RhdGljLCBwdWxsZWQsIGxpdmVcIn08L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkV2ZXJ5IHZhbHVlIGluIGEgcmVwb3J0IGlzIHVsdGltYXRlbHkgb25lIG9mIHRocmVlIGtpbmRzOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudGFibGU+PF9jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGg+e1wiS2luZFwifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIldoZXJlIGl0IGxpdmVzXCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGg+e1wiRnJlc2huZXNzXCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGg+e1wiRXhhbXBsZVwifTwvX2NvbXBvbmVudHMudGg+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50Ym9keT48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiU3RhdGljXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiaW4gdGhlIHdvcmtzaGVldCBpdHNlbGZcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJjaGFuZ2VzIG9ubHkgd2hlbiBlZGl0ZWRcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJidWRnZXQgYXNzdW1wdGlvbnMsIHRhcmdldHMsIG1hbnVhbCBlbnRyaWVzXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnN0cm9uZz57XCJQdWxsZWRcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJhbiBleHRlcm5hbCBzb3VyY2UsIGZldGNoZWQgb24gZGVtYW5kXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiYXMgb2YgbGFzdCBsb29rdXBcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJhIGN1cnJlbmN5IHJhdGUsIGEgZGF0YWJhc2UgcXVlcnkgcmVzdWx0XCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnN0cm9uZz57XCJMaXZlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiYW4gZXh0ZXJuYWwgc3RyZWFtXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiY29udGludW91c2x5IHVwZGF0ZWRcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJvcHMgbWV0cmljcywgb3JkZXIgZmxvdywgc2Vuc29yIGRhdGFcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50Ym9keT48L19jb21wb25lbnRzLnRhYmxlPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlB1bGxlZCBhbmQgbGl2ZSBkYXRhIGVudGVyIHRocm91Z2ggXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJkYXRhIGNvbm5lY3RvcnNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIGRlbGliZXJhdGVseSBcXFwiZHVtYlxcXCIgaW5nZXN0aW9uXFxuY29tcG9uZW50cyB0aGF0IGZldGNoIGZyb20gY29uZmlndXJlZCBzb3VyY2VzIGFuZCBtYXRlcmlhbGl6ZSByZXN1bHRzIHdoZXJlIGZvcm11bGFzIGNhbiByZWFkXFxudGhlbS4gQ29ubmVjdG9ycyBhcmUgdGhlIG9ubHkgcGFydCBvZiBhIFJlY2tvbmVyIGRvY3VtZW50IHRoYXQgdG91Y2hlcyB0aGUgbmV0d29yayBvclxcbmNyZWRlbnRpYWxzLCBhbmQgdGhleSBhcmUgY29uZmlndXJhdGlvbi1kcml2ZW46IGZldGNoZWQgY29udGVudCBuZXZlciBkZWNpZGVzIHdoYXQgZWxzZSB0b1xcbmZldGNoIG9yIHdoZXJlIHRvIHNlbmQgYW55dGhpbmcuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cInJlcG9ydHMtYXJlLXJ1bi1tb2RlLWZpcnN0XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJyZXBvcnRzLWFyZS1ydW4tbW9kZS1maXJzdFwiIC8+e1wiUmVwb3J0cyBhcmUgcnVuLW1vZGUtZmlyc3RcIn08L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkNvbnN1bWluZyBhIHJlcG9ydCBpcyB0aGUgcHJpbWFyeSBleHBlcmllbmNlLCBhbmQgaXQgaXMgbmV2ZXIgdGF4ZWQgdG8gaW1wcm92ZSBhdXRob3JpbmdcXG4ocGxhdGZvcm0gdmFsdWUgMikuIENvbmNyZXRlbHk6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiQSBkYXNoYm9hcmQgY29udGFpbmluZyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm9ubHkgc3RhdGljIGRhdGEgb3BlbnMgaW5zdGFudGx5IHdpdGggbm8gcGVybWlzc2lvbiBwcm9tcHRzIGF0XFxuYWxsXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCB0aGUgdmlld2VyIGp1c3Qgc2VlcyB0aGUgcmVwb3J0LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIkNvbnNlbnQgVUkgYXBwZWFycyBvbmx5IHdoZW4gdGhlIHZpZXdlciBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImFjdGl2YXRlcyBhIGxpdmUgZmVlZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBvciBhbm90aGVyIGVsZXZhdGVkXFxuZmVhdHVyZSwgYW5kIGl0IGlzIHNjb3BlZCB0byBleGFjdGx5IHRoYXQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiUmVwb3J0cyBhcmUgZmlyc3QtY2xhc3Mgb24gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJtb2JpbGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHBsYXRmb3JtIHZhbHVlIDgpOiB0ZW1wbGF0ZXMgZGVncmFkZSB0byBhXFxuc2luZ2xlLWNvbHVtbiByZWFkaW5nIGV4cGVyaWVuY2UsIGFuZCBkcmlsbC1kb3duIHdvcmtzIHdpdGggdG91Y2guXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cInRoZS1hc3Npc3RhbnRcIj48SGVhZGluZ0FuY2hvciBpZD1cInRoZS1hc3Npc3RhbnRcIiAvPntcIlRoZSBhc3Npc3RhbnRcIn08L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlJlY2tvbmVyIGVtYmVkcyBhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiY29kaW5nLWFnZW50IGFzc2lzdGFudFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB0aGF0IGF1dGhvcnMgYW5kIG1vZGlmaWVzIGZvcm11bGFzLCB0ZXN0cywgYW5kXFxudGVtcGxhdGVzIG9uIHRoZSB1c2VyJ3MgYmVoYWxmLiBUaGUgYXNzaXN0YW50IGlzIGEgZmlyc3QtY2xhc3MgYXV0aG9yIChwbGF0Zm9ybSB2YWx1ZSA1KTogdGhlXFxuZXhwZWN0ZWQgd29ya2Zsb3cgZm9yIG1vc3QgdXNlcnMgaXMgY29udmVyc2F0aW9uYWwg4oCUIFxcXCJhZGQgYSBjZWxsIHRoYXQgY29tcHV0ZXMgY2h1cm4gYnlcXG5jb2hvcnQsIHRlc3QgaXQgYWdhaW5zdCBsYXN0IHF1YXJ0ZXIncyBudW1iZXJzLCBhbmQgcHV0IGEgdHJlbmQgY2hhcnQgaW4gdGhlIHdlZWtseSByZXBvcnRcXFwiIOKAlFxcbndpdGggdGhlIGFnZW50IHdyaXRpbmcgdGhlIGNvZGUsIHJ1bm5pbmcgdGhlIHRlc3RzLCBhbmQgc2hvd2luZyB0aGUgcmVzdWx0IGxpdmUuIFRoZVxcbmFzc2lzdGFudCdzIHJlYWNoIGlzIGJvdW5kZWQgdG8gdGhlIGN1cnJlbnQgZG9jdW1lbnQncyBjb250ZW50OyBwdWJsaXNoaW5nIHRvIGEgc2hhcmVkIHNwYWNlXFxub3IgZWRpdGluZyBhcHAgc291cmNlIGFsd2F5cyBwYXNzZXMgdGhyb3VnaCBhbiBhdHRlbmRlZCwgZnVsbC1kaWZmIGFwcHJvdmFsIGdhdGUuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cIndoby1pdC1pcy1mb3JcIj48SGVhZGluZ0FuY2hvciBpZD1cIndoby1pdC1pcy1mb3JcIiAvPntcIldobyBpdCBpcyBmb3JcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJSZXBvcnQgdmlld2Vyc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgdGhlIHByaW1hcnkgYXVkaWVuY2UuIFRoZXkgb3BlbiBhIGxpbmssIHNlZSBhIGxpdmUgcmVwb3J0LCBkcmlsbCBpbnRvXFxuaXQsIGFuZCBuZXZlciBzZWUgYSBmb3JtdWxhLiBWaWV3aW5nIG11c3QgYmUgYXMgc2FmZSBhcyB2aXNpdGluZyBhIHdlYiBwYWdlOiBSZWNrb25lciBydW5zXFxub24gaW1tZWRpYXRlbHkucnVuLCBzbyB0aGUgd29yc3QgYSBtYWxpY2lvdXMgcmVwb3J0IGNhbiBkbyBpcyBib3VuZGVkIGJ5IHRoZSBwbGF0Zm9ybSdzXFxuc2FuZGJveCBhbmQgYnkgd2hhdGV2ZXIgdGhlIHZpZXdlciBleHBsaWNpdGx5IGNvbnNlbnRlZCB0byAobm90aGluZywgZm9yIGEgc3RhdGljIHJlcG9ydCkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJSZXBvcnQgYXV0aG9ycyAvIGFuYWx5c3RzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCB0aGUgcGVvcGxlIGFjY291bnRhYmxlIGZvciB0aGUgbnVtYmVycy4gVGhleSB3b3JrIHRocm91Z2hcXG50aGUgYXNzaXN0YW50IG9yIGRpcmVjdGx5IGluIHRoZSB3b3JrYm9vaywgYW5kIGdldCBzb2Z0d2FyZS1ncmFkZSB0b29saW5nOiB0ZXN0cywgdHlwZXMsXFxudmVyc2lvbiBoaXN0b3J5LCByZXZpZXcuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJDb2RpbmcgYWdlbnRzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBhdCBsZWFzdCBhcyBpbXBvcnRhbnQgYXMgaHVtYW4gYXV0aG9ycy4gVGhlIGZvcm11bGEgQVBJLCB0aGUgdGVzdFxcbmhhcm5lc3MsIHRoZSB0ZW1wbGF0ZSBjb21wb25lbnQgY2F0YWxvZywgYW5kIHRoZSBkb2N1bWVudCBsYXlvdXQgYXJlIGFsbCBkZXNpZ25lZCB0byBiZVxcbmRyaXZlbiBmcm9tIHRoZWlyIHNlbGYtZGVzY3JpcHRpb25zLCB3aXRoIG5vIHRyaWJhbCBrbm93bGVkZ2UuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJPcmdhbml6YXRpb25zXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCB0ZWFtcyB0aGF0IGZvcmsgUmVja29uZXIgKG9yIGp1c3QgaXRzIGNvbXBvbmVudCBjYXRhbG9nKSB0byBlbmNvZGVcXG5ob3VzZSBkYXRhLXZpc3VhbGl6YXRpb24gc3R5bGUgYW5kIGRvbWFpbiBjb21wb25lbnRzLCB0aGVuIHB1Ymxpc2ggaW50ZXJuYWwgZGFzaGJvYXJkcyBvdmVyXFxuc2hhcmVkLCBhY2Nlc3MtY29udHJvbGxlZCBkYXRhLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJ3aGF0LXlvdS1jYW4tZG8td2l0aC1pdFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwid2hhdC15b3UtY2FuLWRvLXdpdGgtaXRcIiAvPntcIldoYXQgeW91IGNhbiBkbyB3aXRoIGl0XCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQnVpbGQgYSBsaXZlIGRhc2hib2FyZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB3aG9zZSBsb2dpYyBpcyB0ZXN0ZWQgSmF2YVNjcmlwdCBhbmQgd2hvc2UgbGF5b3V0IGlzIGEgcmVhZGFibGVcXG5NRFggZG9jdW1lbnQg4oCUIGJvdGggcGxhaW4gZmlsZXMgaW4gYSBnaXQgcmVwb3NpdG9yeSwgY2FjaGUtYWNjZWxlcmF0ZWQgYW5kIGluc3RhbnRseVxcbnJ1bm5hYmxlIG9uIGltbWVkaWF0ZWx5LnJ1bi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlNoYXJlIGl0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHdpdGggYW55b25lLiBTdGF0aWMgcmVwb3J0cyBvcGVuIHdpdGggemVybyBmcmljdGlvbjsgbGl2ZSByZXBvcnRzIGFzayB0aGVcXG52aWV3ZXIgZm9yIGV4YWN0bHkgdGhlIGZlZWQgYWNjZXNzIHRoZXkgYWN0aXZhdGUuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJEcmlsbCBpblwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIjogZmlsdGVyLCBleHBhbmQsIGFuZCByZS1wYXJhbWV0ZXJpemUgaW50ZXJhY3RpdmUgcmVwb3J0czsgdGhlIHdvcmtib29rXFxucmVjb21wdXRlcyBhbmQgdGhlIHRlbXBsYXRlIHJlLXJlbmRlcnMgbGl2ZS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlN0cmVhbSBkYXRhIHRocm91Z2ggaXRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCI6IGNvbm5lY3QgYSBsaXZlIHNvdXJjZSBvbmNlLCBhbmQgZXZlcnkgY2hhcnQgYm91bmQgdG8gaXQgc3RheXNcXG5jdXJyZW50LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRGVsZWdhdGUgdGhlIGF1dGhvcmluZyB0byBhbiBhZ2VudFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgd2l0aCBjb3JyZWN0bmVzcyBhbmNob3JlZCBpbiB0aGUgdW5pdCB0ZXN0cyB0aGVcXG5hZ2VudCB3cml0ZXMgYW5kIHJ1bnMgYWxvbmdzaWRlIGV2ZXJ5IGZvcm11bGEuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJGb3JrIGFuZCBleHRlbmRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCI6IGFkZCBjdXN0b20gdGVtcGxhdGUgY29tcG9uZW50cyBpbiBhIGZvcmsgKGNvbXBvbmVudCBcIn08X2NvbXBvbmVudHMuZW0+e1wiZGVmaW5pdGlvbnNcIn08L19jb21wb25lbnRzLmVtPntcIiBhcmVcXG5hcHAgc291cmNlOyBjb21wb25lbnQgXCJ9PF9jb21wb25lbnRzLmVtPntcInVzYWdlc1wifTwvX2NvbXBvbmVudHMuZW0+e1wiIGFyZSBjb250ZW50KSDigJQgYSByZXBvcnQgdXNpbmcgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiPFRpbWVsaW5lPlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcmVuZGVycyBmdWxseSBpblxcbmEgZm9yayB0aGF0IHNoaXBzIGl0IGFuZCBkZWdyYWRlcyBncmFjZWZ1bGx5IGVsc2V3aGVyZS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwiZGVwbG95bWVudC1zaGFwZXNcIj48SGVhZGluZ0FuY2hvciBpZD1cImRlcGxveW1lbnQtc2hhcGVzXCIgLz57XCJEZXBsb3ltZW50IHNoYXBlc1wifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiUmVja29uZXIgaW5oZXJpdHMgdGhlIHBsYXRmb3JtJ3Mgc2VwYXJhdGlvbiBiZXR3ZWVuIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiYXBwIGNvZGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYW5kIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiY29udGVudFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgZ2l2aW5nIGFcXG5jb250aW51dW0gb2YgZGVwbG95bWVudCBzaGFwZXMgKHBsYXRmb3JtIHNwZWMgwqcxKTpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnRhYmxlPjxfY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRoPntcIlNoYXBlXCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGg+e1wiQXBwIGNvZGVcIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aD57XCJDb250ZW50ICh3b3JrYm9vayArIHRlbXBsYXRlcylcIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aD57XCJDaGFyYWN0ZXJcIn08L19jb21wb25lbnRzLnRoPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudGJvZHk+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlN0b2NrIFJlY2tvbmVyICsgeW91ciBjb250ZW50XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1widGhlIGNhbm9uaWNhbCBhcHAsIHVubW9kaWZpZWRcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJ5b3VyIHJlcG8gb3Igc3BhY2VcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJwb3J0YWJsZSwgY3Jvc3Mtb3JnLCBwdWJsaWMtc2FmZVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiT3JnIGZvcmsgKyBleHRlcm5hbCBjb250ZW50XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wieW91ciBvcmcncyBmb3JrIChjdXN0b20gY29tcG9uZW50cywgaG91c2Ugc3R5bGUpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wic2hhcmVkIG9yZyBzcGFjZVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIm9yZy1jdXN0b21pemVkXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnN0cm9uZz57XCJGdXNlZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcImZvcmsgd2l0aCBjb250ZW50IGVtYmVkZGVkIGluIHRoZSBhcHAgcmVwb1wifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcImNvbnRlbnQgXCJ9PF9jb21wb25lbnRzLmVtPntcImlzXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgYXBwIHNvdXJjZVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcInB1cnBvc2UtYnVpbHQgc2luZ2xlIGRhc2hib2FyZFwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRib2R5PjwvX2NvbXBvbmVudHMudGFibGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwiaG93LWl0LXJ1bnMtdGhlLXNoYXBlLWJyaWVmbHlcIj48SGVhZGluZ0FuY2hvciBpZD1cImhvdy1pdC1ydW5zLXRoZS1zaGFwZS1icmllZmx5XCIgLz57XCJIb3cgaXQgcnVucyAodGhlIHNoYXBlLCBicmllZmx5KVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiUmVja29uZXIgaXMgbm90IG9uZSBwcm9ncmFtIGJ1dCBhIHNtYWxsIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiY29tcG9zaXRlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIG9mIGlzb2xhdGVkLCBzYW5kYm94ZWQgcGFydHMsIGVhY2hcXG5ob2xkaW5nIG9ubHkgd2hhdCBpdHMgam9iIHJlcXVpcmVzIChwbGF0Zm9ybSBzcGVjIMKnMik6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1widGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicmVwb3J0IHZpZXdcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgcmVuZGVycyB0ZW1wbGF0ZXMgYW5kIHJlc3VsdHMg4oCUIGl0IGV4ZWN1dGVzIG5vIGNvbnRlbnQgY29kZTtcIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJ0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJmb3JtdWxhIGVuZ2luZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBleGVjdXRlcyBmb3JtdWxhcyBhbmQgdGVzdHMg4oCUIGl0IGhvbGRzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibm8gY2FwYWJpbGl0aWVzIGF0IGFsbFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIlxcbihubyBuZXR3b3JrLCBubyBmaWxlc3lzdGVtIGJleW9uZCBpdHMgaW5wdXRzLCBubyBzZWNyZXRzKTtcIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJ0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJkYXRhIGNvbm5lY3RvcihzKVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBmZXRjaCBleHRlcm5hbCBkYXRhIOKAlCB0aGV5IGhvbGQgY3JlZGVudGlhbHMgYW5kIG5ldHdvcmsgYWNjZXNzIGJ1dFxcbmV4ZWN1dGUgbm8gY29udGVudCBhbmQgaG9zdCBubyBhZ2VudDtcIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJ0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJhc3Npc3RhbnRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYXV0aG9ycyBjb250ZW50IOKAlCBpdHMgdG9vbHMgYXJlIGNvbmZpbmVkIHRvIHRoaXMgZG9jdW1lbnQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIldoeSBpdCBpcyBzaGFwZWQgdGhpcyB3YXkg4oCUIGFuZCB3aGF0IHJlbWFpbnMgZ2VudWluZWx5IHVuc29sdmVkIGFib3V0IG1ha2luZyB0aGF0IHNoYXBlIHNhZmVcXG5hbmQgcGxlYXNhbnQg4oCUIGlzIHRoZSBzdWJqZWN0IG9mIFwifTxfY29tcG9uZW50cy5hIGhyZWY9XCJwcm9ibGVtX3N0YXRlbWVudC5tZFwiPntcInByb2JsZW1fc3RhdGVtZW50Lm1kXCJ9PC9fY29tcG9uZW50cy5hPntcIi5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwid2hhdC1yZWNrb25lci1pcy1ub3RcIj48SGVhZGluZ0FuY2hvciBpZD1cIndoYXQtcmVja29uZXItaXMtbm90XCIgLz57XCJXaGF0IFJlY2tvbmVyIGlzIG5vdFwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIk5vdCBhIHNwcmVhZHNoZWV0IGdyaWQgY2xvbmUuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRoZXJlIGlzIG5vIGluZmluaXRlIGdyaWQgb2YgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQTFcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNvb3JkaW5hdGVzOyBjZWxscyBhcmVcXG5uYW1lZCwgZm9ybXVsYXMgYXJlIGZ1bmN0aW9ucywgYW5kIGxheW91dCBiZWxvbmdzIHRvIHRlbXBsYXRlcy4gSW1wb3J0aW5nIHRhYnVsYXIgZGF0YSBpc1xcbmluIHNjb3BlOyBlbXVsYXRpbmcgRXhjZWwgaXMgbm90LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiTm90IGEgaG9zdGVkIEJJIHNlcnZpY2UuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIEFsbCBldmFsdWF0aW9uIGFuZCByZW5kZXJpbmcgaGFwcGVuIGNsaWVudC1zaWRlIGluIHRoZVxcbnZpZXdlcidzIGJyb3dzZXIsIGluIGltbWVkaWF0ZWx5LnJ1biBzYW5kYm94ZXMuIFRoZXJlIGlzIG5vIFJlY2tvbmVyIHNlcnZlciBleGVjdXRpbmdcXG5mb3JtdWxhcyBvciB3YXJlaG91c2luZyBkYXRhLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiTm90IGEgZ2VuZXJhbCBub3RlYm9vay5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgQ2VsbHMgYXJlIHB1cmUgZm9ybXVsYXMgb3ZlciBkZWNsYXJlZCBpbnB1dHMsIG5vdCBhcmJpdHJhcnlcXG5zdGF0ZWZ1bCBzY3JpcHRzIHdpdGggc2lkZSBlZmZlY3RzLiBUaGF0IHJlc3RyaWN0aW9uIGlzIHdoYXQgbWFrZXMgcmVjYWxjdWxhdGlvbiwgdGVzdGluZyxcXG5hbmQgc2FmZSBzaGFyaW5nIHRyYWN0YWJsZS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIk5vdCBhIHRlbXBsYXRlIGVuZ2luZSB0aGF0IHRydXN0cyBpdHMgaW5wdXQuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRlbXBsYXRlcyBjYW5ub3QgY29tcHV0ZTsgYSByZXBvcnQgeW91XFxuZGlkIG5vdCB3cml0ZSBjYW5ub3QgcnVuIGNvZGUgaW4geW91ciBzZXNzaW9uIGJ5IGJlaW5nIHJlbmRlcmVkLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiTm90IGEgcmVwbGFjZW1lbnQgZm9yIHRoZSBwbGF0Zm9ybS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgU2FuZGJveGluZywgY29uc2VudCwgaWRlbnRpdHksIHNoYXJpbmcsIGFuZFxcbmNvbnRyaWJ1dGlvbiBmbG93cyBhcmUgaW1tZWRpYXRlbHkucnVuJ3M7IFJlY2tvbmVyIGNvbXBvc2VzIHRoZW0gKHBsYXRmb3JtIHZhbHVlIDcpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJyZWxhdGVkLWRvY3VtZW50c1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwicmVsYXRlZC1kb2N1bWVudHNcIiAvPntcIlJlbGF0ZWQgZG9jdW1lbnRzXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5hIGhyZWY9XCJwcm9ibGVtX3N0YXRlbWVudC5tZFwiPntcInByb2JsZW1fc3RhdGVtZW50Lm1kXCJ9PC9fY29tcG9uZW50cy5hPntcIiDigJQgdGhlIHRocmVlIGhhcmQgcHJvYmxlbXMgUmVja29uZXIgbXVzdCBzb2x2ZS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuYSBocmVmPVwicmVzZWFyY2hfcHJvcG9zYWwubWRcIj57XCJyZXNlYXJjaF9wcm9wb3NhbC5tZFwifTwvX2NvbXBvbmVudHMuYT57XCIg4oCUIHRoZSBvcGVuIHJlc2VhcmNoIHF1ZXN0aW9ucyBhbmQgaG93IHdlXFxucHJvcG9zZSB0byBhdHRhY2sgdGhlbS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuYSBocmVmPVwiUkVQT1JUSU5HX1NQUkVBRFNIRUVUX1NQRUMubWRcIj57XCJSRVBPUlRJTkdfU1BSRUFEU0hFRVRfU1BFQy5tZFwifTwvX2NvbXBvbmVudHMuYT57XCIg4oCUIHRoZSBwbGF0Zm9ybS1sZXZlbFxcbnNlY3VyaXR5IGFyY2hpdGVjdHVyZTogdGhlIGZvdXItcmVhbG0gY29tcG9zaXRlLCB0aGUgcmVhY2gtbm90LWVncmVzcyBjb25maWRlbnRpYWxpdHlcXG5tb2RlbCwgdGFpbnQgcHJvcGFnYXRpb24sIGFuZCB0aGUgaG9uZXN0IGxpc3Qgb2YgdW5idWlsdCBwbGF0Zm9ybSBwcmVyZXF1aXNpdGVzLlxcbihMb2NhbCBjb3B5OyB0aGUgY2Fub25pY2FsIHZlcnNpb24gbGl2ZXMgaW4gdGhlIGltbWVkaWF0ZWx5LnJ1biBkb2NzIHJlcG8gYXRcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJkb2NzL3NwZWNzL1JFUE9SVElOR19TUFJFQURTSEVFVF9TUEVDLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi4pXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPjwvPjtcbn1cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE1EWENvbnRlbnQocHJvcHMgPSB7fSkge1xuICBjb25zdCB7d3JhcHBlcjogTURYTGF5b3V0fSA9IHtcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH07XG4gIHJldHVybiBNRFhMYXlvdXQgPyA8TURYTGF5b3V0IHsuLi5wcm9wc30+PF9jcmVhdGVNZHhDb250ZW50IHsuLi5wcm9wc30gLz48L01EWExheW91dD4gOiBfY3JlYXRlTWR4Q29udGVudChwcm9wcyk7XG59XG5mdW5jdGlvbiBfbWlzc2luZ01keFJlZmVyZW5jZShpZCwgY29tcG9uZW50LCBwbGFjZSkge1xuICB0aHJvdyBuZXcgRXJyb3IoXCJFeHBlY3RlZCBcIiArIChjb21wb25lbnQgPyBcImNvbXBvbmVudFwiIDogXCJvYmplY3RcIikgKyBcIiBgXCIgKyBpZCArIFwiYCB0byBiZSBkZWZpbmVkOiB5b3UgbGlrZWx5IGZvcmdvdCB0byBpbXBvcnQsIHBhc3MsIG9yIHByb3ZpZGUgaXQuXCIgKyAocGxhY2UgPyBcIlxcbkl04oCZcyByZWZlcmVuY2VkIGluIHlvdXIgY29kZSBhdCBgXCIgKyBwbGFjZSArIFwiYCBpbiBgL2FwcC9kb2NzL3Byb2R1Y3RfZGVmaW5pdGlvbi5tZGBcIiA6IFwiXCIpKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQXdGLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUZ4RjtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU1DLFdBQVcsR0FBRztNQUNsQkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsVUFBVSxFQUFFLFlBQVk7TUFDeEJDLElBQUksRUFBRSxNQUFNO01BQ1pDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLENBQUMsRUFBRSxHQUFHO01BQ05DLE1BQU0sRUFBRSxRQUFRO01BQ2hCQyxLQUFLLEVBQUUsT0FBTztNQUNkQyxLQUFLLEVBQUUsT0FBTztNQUNkQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxLQUFLLEVBQUUsT0FBTztNQUNkQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSLEdBQUcsSUFBQUMsNkJBQWtCLEVBQUMsQ0FBQztNQUN2QixHQUFHcEIsS0FBSyxDQUFDcUI7SUFDWCxDQUFDO0lBQUU7TUFBQ0M7SUFBYSxDQUFDLEdBQUdyQixXQUFXO0VBQ2hDLElBQUksQ0FBQ3FCLGFBQWEsRUFBRUMsb0JBQW9CLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQztFQUMvRCxvQkFBTyxJQUFBekIsV0FBQSxDQUFBMEIsSUFBQSxFQUFBMUIsV0FBQSxDQUFBMkIsUUFBQTtJQUFBQyxRQUFBLGdCQUFFLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNLLEVBQUU7TUFBQ3FCLEVBQUUsRUFBQyw2QkFBNkI7TUFBQUQsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUE2QixDQUFFLENBQUMsRUFBQywrQkFBK0I7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNVLENBQUM7TUFBQWUsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFTLENBQXFCLENBQUMsRUFBQyxXQUFXLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBVSxDQUFxQixDQUFDLEVBQUMsYUFBYTtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ0UsVUFBVTtNQUFBdUIsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDVSxDQUFDO1FBQUFlLFFBQUEsR0FBRSw2RkFBNkYsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDQyxDQUFDO1VBQUMyQixJQUFJLEVBQUMsK0JBQStCO1VBQUFILFFBQUEsRUFBRTtRQUErQixDQUFnQixDQUFDLEVBQUMsZUFBZSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUEwQyxDQUFtQixDQUFDLEVBQUMsMEZBQTBGLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0ksRUFBRTtVQUFBcUIsUUFBQSxFQUFFO1FBQWtCLENBQWlCLENBQUMsRUFBQyxzRUFBc0UsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDQyxDQUFDO1VBQUMyQixJQUFJLEVBQUMsc0JBQXNCO1VBQUFILFFBQUEsRUFBRTtRQUFzQixDQUFnQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNDLENBQUM7VUFBQzJCLElBQUksRUFBQyxzQkFBc0I7VUFBQUgsUUFBQSxFQUFFO1FBQXNCLENBQWdCLENBQUMsRUFBQyw4QkFBOEI7TUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQXlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDb0IsRUFBRSxFQUFDLHVCQUF1QjtNQUFBRCxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQXVCLENBQUUsQ0FBQyxFQUFDLHVCQUF1QjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZSxRQUFBLEdBQUUsaUdBQWlHLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBVSxDQUFxQixDQUFDLEVBQUMsb0ZBQW9GLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBVSxDQUFxQixDQUFDLEVBQUMsMEtBQTBLLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBa0IsQ0FBcUIsQ0FBQyxFQUFDLCtIQUErSCxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVEsQ0FBcUIsQ0FBQyxFQUFDLDJCQUEyQixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVEsQ0FBcUIsQ0FBQyxFQUFDLHNEQUFzRCxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQU0sQ0FBcUIsQ0FBQyxFQUFDLHVFQUF1RSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVksQ0FBcUIsQ0FBQyxFQUFDLDRSQUE0UjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDb0IsRUFBRSxFQUFDLGVBQWU7TUFBQUQsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFlLENBQUUsQ0FBQyxFQUFDLGVBQWU7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNVLENBQUM7TUFBQWUsUUFBQSxFQUFFO0lBQXFDLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1MsRUFBRTtNQUFBZ0IsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXlJLENBQXFCLENBQUMsRUFBQyw2SkFBNko7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBbUUsQ0FBcUIsQ0FBQyxFQUFDLG9RQUFvUTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDVSxDQUFDO01BQUFlLFFBQUEsR0FBRSx5RUFBeUUsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFPLENBQXFCLENBQUMsRUFBQyxpQ0FBaUMsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFjLENBQXFCLENBQUMsRUFBQyw0TEFBNEw7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNNLEVBQUU7TUFBQ29CLEVBQUUsRUFBQyxlQUFlO01BQUFELFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBZSxDQUFFLENBQUMsRUFBQyxlQUFlO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDTyxFQUFFO01BQUNtQixFQUFFLEVBQUMseUJBQXlCO01BQUFELFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBeUIsQ0FBRSxDQUFDLEVBQUMsMkJBQTJCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDVSxDQUFDO01BQUFlLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBVSxDQUFxQixDQUFDLEVBQUMsMERBQTBELGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBWSxDQUFxQixDQUFDLEVBQUMsNENBQTRDLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBTyxDQUFxQixDQUFDLEVBQUMsZUFBZTtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2tCLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQU0sQ0FBcUIsQ0FBQyxFQUFDLDREQUE0RCxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFZLENBQW1CLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQUksQ0FBbUIsQ0FBQyxFQUFDLElBQUk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBUyxDQUFxQixDQUFDLEVBQUMsK0xBQStMO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQU8sQ0FBcUIsQ0FBQyxFQUFDLG9NQUFvTTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFPLENBQXFCLENBQUMsRUFBQyw2T0FBNk87TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZSxRQUFBLEVBQUU7SUFBK00sQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDTyxFQUFFO01BQUNtQixFQUFFLEVBQUMsaUJBQWlCO01BQUFELFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBaUIsQ0FBRSxDQUFDLEVBQUMsaUJBQWlCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDVSxDQUFDO01BQUFlLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBaUIsQ0FBcUIsQ0FBQyxFQUFDLHNEQUFzRCxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQStCLENBQXFCLENBQUMsRUFBQyw0R0FBNEcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFlLENBQXFCLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBc0IsUUFBQSxFQUFFO01BQXVDLENBQW1CLENBQUMsRUFBQyxXQUFXLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBc0IsUUFBQSxFQUFFO01BQVUsQ0FBbUIsQ0FBQyxFQUFDLGtFQUFrRTtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2tCLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLEVBQUU7TUFBbUksQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLEVBQUU7TUFBMkYsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLEVBQUU7TUFBaUYsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNVLENBQUM7TUFBQWUsUUFBQSxFQUFFO0lBQWlaLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZSxRQUFBLEdBQUUsc0pBQXNKLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBYSxDQUFxQixDQUFDLEVBQUMsK0ZBQStGO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDTyxFQUFFO01BQUNtQixFQUFFLEVBQUMseUJBQXlCO01BQUFELFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBeUIsQ0FBRSxDQUFDLEVBQUMsNEJBQTRCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVSxDQUFDO01BQUFlLFFBQUEsRUFBRTtJQUEyRCxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNZLEtBQUs7TUFBQWEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDZ0IsS0FBSztRQUFBUyxRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDZSxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFNLENBQWlCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNlLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQWdCLENBQWlCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNlLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQVcsQ0FBaUIsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBUyxDQUFpQixDQUFDO1FBQUEsQ0FBZ0I7TUFBQyxDQUFtQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDYSxLQUFLO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFRLENBQXFCO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBeUIsQ0FBaUIsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBMEIsQ0FBaUIsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBNkMsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNpQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBUSxDQUFxQjtVQUFDLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQXVDLENBQWlCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQW1CLENBQWlCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQTBDLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDaUIsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQU0sQ0FBcUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFvQixDQUFpQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFzQixDQUFpQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFzQyxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQztNQUFBLENBQW1CLENBQUM7SUFBQSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNVLENBQUM7TUFBQWUsUUFBQSxHQUFFLHFDQUFxQyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQWlCLENBQXFCLENBQUMsRUFBQyx3VkFBd1Y7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNPLEVBQUU7TUFBQ21CLEVBQUUsRUFBQyw0QkFBNEI7TUFBQUQsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUE0QixDQUFFLENBQUMsRUFBQyw0QkFBNEI7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNVLENBQUM7TUFBQWUsUUFBQSxFQUFFO0lBQTJILENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2tCLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLEdBQUUseUJBQXlCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBcUUsQ0FBcUIsQ0FBQyxFQUFDLHFDQUFxQztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxHQUFFLDBDQUEwQyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXVCLENBQXFCLENBQUMsRUFBQyxrRUFBa0U7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsR0FBRSw2QkFBNkIsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFRLENBQXFCLENBQUMsRUFBQyxpSEFBaUg7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ08sRUFBRTtNQUFDbUIsRUFBRSxFQUFDLGVBQWU7TUFBQUQsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFlLENBQUUsQ0FBQyxFQUFDLGVBQWU7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNVLENBQUM7TUFBQWUsUUFBQSxHQUFFLG9CQUFvQixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQXdCLENBQXFCLENBQUMsRUFBQyxpbEJBQWlsQjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDb0IsRUFBRSxFQUFDLGVBQWU7TUFBQUQsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFlLENBQUUsQ0FBQyxFQUFDLGVBQWU7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNrQixFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFnQixDQUFxQixDQUFDLEVBQUMsMlZBQTJWO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTJCLENBQXFCLENBQUMsRUFBQyxrTEFBa0w7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBZSxDQUFxQixDQUFDLEVBQUMsK05BQStOO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWUsQ0FBcUIsQ0FBQyxFQUFDLHFNQUFxTTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDTSxFQUFFO01BQUNvQixFQUFFLEVBQUMseUJBQXlCO01BQUFELFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBeUIsQ0FBRSxDQUFDLEVBQUMseUJBQXlCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDa0IsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBd0IsQ0FBcUIsQ0FBQyxFQUFDLHNMQUFzTDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFVLENBQXFCLENBQUMsRUFBQywrSEFBK0g7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBVSxDQUFxQixDQUFDLEVBQUMsdUhBQXVIO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXdCLENBQXFCLENBQUMsRUFBQywyRUFBMkU7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBb0MsQ0FBcUIsQ0FBQyxFQUFDLG1HQUFtRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFpQixDQUFxQixDQUFDLEVBQUMsd0RBQXdELGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0ksRUFBRTtVQUFBcUIsUUFBQSxFQUFFO1FBQWEsQ0FBaUIsQ0FBQyxFQUFDLDhCQUE4QixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNJLEVBQUU7VUFBQXFCLFFBQUEsRUFBRTtRQUFRLENBQWlCLENBQUMsRUFBQyxpQ0FBaUMsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBWSxDQUFtQixDQUFDLEVBQUMsNEVBQTRFO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNNLEVBQUU7TUFBQ29CLEVBQUUsRUFBQyxtQkFBbUI7TUFBQUQsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFtQixDQUFFLENBQUMsRUFBQyxtQkFBbUI7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNVLENBQUM7TUFBQWUsUUFBQSxHQUFFLHNEQUFzRCxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVUsQ0FBcUIsQ0FBQyxFQUFDLE9BQU8sZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFTLENBQXFCLENBQUMsRUFBQyxnRUFBZ0U7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNZLEtBQUs7TUFBQWEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDZ0IsS0FBSztRQUFBUyxRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDZSxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFPLENBQWlCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNlLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQVUsQ0FBaUIsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBZ0MsQ0FBaUIsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBVyxDQUFpQixDQUFDO1FBQUEsQ0FBZ0I7TUFBQyxDQUFtQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDYSxLQUFLO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUErQixDQUFxQjtVQUFDLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQStCLENBQWlCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQW9CLENBQWlCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQWtDLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDaUIsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQTZCLENBQXFCO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBa0QsQ0FBaUIsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBa0IsQ0FBaUIsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBZ0IsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNpQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBTyxDQUFxQjtVQUFDLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQTRDLENBQWlCLENBQUMsbUJBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxHQUFFLFVBQVUsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDSSxFQUFFO2NBQUFxQixRQUFBLEVBQUU7WUFBSSxDQUFpQixDQUFDLEVBQUMsYUFBYTtVQUFBLENBQWlCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQWdDLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDO01BQUEsQ0FBbUIsQ0FBQztJQUFBLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDb0IsRUFBRSxFQUFDLCtCQUErQjtNQUFBRCxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQStCLENBQUUsQ0FBQyxFQUFDLGtDQUFrQztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZSxRQUFBLEdBQUUsMENBQTBDLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBVyxDQUFxQixDQUFDLEVBQUMsNkZBQTZGO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDa0IsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsR0FBRSxNQUFNLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBYSxDQUFxQixDQUFDLEVBQUMsK0RBQStEO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLEdBQUUsTUFBTSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWdCLENBQXFCLENBQUMsRUFBQywwQ0FBMEMsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUF3QixDQUFxQixDQUFDLEVBQUMsOERBQThEO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLEdBQUUsTUFBTSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQW1CLENBQXFCLENBQUMsRUFBQyw0R0FBNEc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsR0FBRSxNQUFNLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBVyxDQUFxQixDQUFDLEVBQUMsNkRBQTZEO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNVLENBQUM7TUFBQWUsUUFBQSxHQUFFLGlJQUFpSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNDLENBQUM7UUFBQzJCLElBQUksRUFBQyxzQkFBc0I7UUFBQUgsUUFBQSxFQUFFO01BQXNCLENBQWdCLENBQUMsRUFBQyxHQUFHO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDTSxFQUFFO01BQUNvQixFQUFFLEVBQUMsc0JBQXNCO01BQUFELFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBc0IsQ0FBRSxDQUFDLEVBQUMsc0JBQXNCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDa0IsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBK0IsQ0FBcUIsQ0FBQyxFQUFDLGdDQUFnQyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFJLENBQW1CLENBQUMsRUFBQyx1SkFBdUo7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBMEIsQ0FBcUIsQ0FBQyxFQUFDLCtLQUErSztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUF5QixDQUFxQixDQUFDLEVBQUMsdUxBQXVMO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQThDLENBQXFCLENBQUMsRUFBQywyR0FBMkc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBcUMsQ0FBcUIsQ0FBQyxFQUFDLG9JQUFvSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDTSxFQUFFO01BQUNvQixFQUFFLEVBQUMsbUJBQW1CO01BQUFELFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBbUIsQ0FBRSxDQUFDLEVBQUMsbUJBQW1CO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDa0IsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0MsQ0FBQztVQUFDMkIsSUFBSSxFQUFDLHNCQUFzQjtVQUFBSCxRQUFBLEVBQUU7UUFBc0IsQ0FBZ0IsQ0FBQyxFQUFDLGlEQUFpRDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDQyxDQUFDO1VBQUMyQixJQUFJLEVBQUMsc0JBQXNCO1VBQUFILFFBQUEsRUFBRTtRQUFzQixDQUFnQixDQUFDLEVBQUMsb0VBQW9FO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNDLENBQUM7VUFBQzJCLElBQUksRUFBQywrQkFBK0I7VUFBQUgsUUFBQSxFQUFFO1FBQStCLENBQWdCLENBQUMsRUFBQyxnUkFBZ1IsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBMEMsQ0FBbUIsQ0FBQyxFQUFDLElBQUk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUM7RUFBQSxDQUFFLENBQUM7QUFDMXFwQjtBQUNlLFNBQVNJLFVBQVVBLENBQUM5QixLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUU7RUFDN0MsTUFBTTtJQUFDK0IsT0FBTyxFQUFFQztFQUFTLENBQUMsR0FBRztJQUMzQixHQUFHLElBQUFaLDZCQUFrQixFQUFDLENBQUM7SUFDdkIsR0FBR3BCLEtBQUssQ0FBQ3FCO0VBQ1gsQ0FBQztFQUNELE9BQU9XLFNBQVMsZ0JBQUcsSUFBQWxDLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ0ksU0FBUztJQUFBLEdBQUtoQyxLQUFLO0lBQUEwQixRQUFBLGVBQUUsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzdCLGlCQUFpQjtNQUFBLEdBQUtDO0lBQUssQ0FBRztFQUFDLENBQVcsQ0FBQyxHQUFHRCxpQkFBaUIsQ0FBQ0MsS0FBSyxDQUFDO0FBQ2xIO0FBQUNpQyxFQUFBLEdBTnVCSCxVQUFVO0FBT2xDLFNBQVNQLG9CQUFvQkEsQ0FBQ0ksRUFBRSxFQUFFTyxTQUFTLEVBQUVDLEtBQUssRUFBRTtFQUNsRCxNQUFNLElBQUlDLEtBQUssQ0FBQyxXQUFXLElBQUlGLFNBQVMsR0FBRyxXQUFXLEdBQUcsUUFBUSxDQUFDLEdBQUcsSUFBSSxHQUFHUCxFQUFFLEdBQUcsb0VBQW9FLElBQUlRLEtBQUssR0FBRyxxQ0FBcUMsR0FBR0EsS0FBSyxHQUFHLHdDQUF3QyxHQUFHLEVBQUUsQ0FBQyxDQUFDO0FBQ2xRO0FBQUMsSUFBQUYsRUFBQTtBQUFBSSxZQUFBLENBQUFKLEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}