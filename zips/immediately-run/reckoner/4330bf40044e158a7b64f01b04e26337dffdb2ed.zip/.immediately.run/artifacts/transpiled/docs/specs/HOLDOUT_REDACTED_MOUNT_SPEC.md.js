var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      blockquote: "blockquote",
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      h3: "h3",
      hr: "hr",
      li: "li",
      ol: "ol",
      p: "p",
      pre: "pre",
      strong: "strong",
      table: "table",
      tbody: "tbody",
      td: "td",
      th: "th",
      thead: "thead",
      tr: "tr",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "immediatelyrun-holdout-redacted-mount-view-host-enforced-trainholdout-separation-for-inferred-formulas",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "immediatelyrun-holdout-redacted-mount-view-host-enforced-trainholdout-separation-for-inferred-formulas"
      }), "immediately.run Holdout Redacted-Mount View — host-enforced train/holdout separation for inferred formulas"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Status:"
      }), " proposal / draft — the D9 M0 design-sprint output of ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "../ARCHITECTURE_PLAN.md"
      }), " §9. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Re-scoped by adversarial-review-2 (2026-07-09):"
      }), " this mechanism closes the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "trivial"
      }), " direct-read leak (H3) but does ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "not"
      }), " make example-based holdout a correctness proof — the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "test-oracle channel"
      }), " (§5.1) and affine-formula reconstruction (§5) defeat that. Per the user decision, holdout is a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "best-effort regression/tripwire"
      }), "; the load-bearing correctness signal is metamorphic + property + mutation (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ARCHITECTURE_PLAN §6"
      }), "). Design only; nothing here is built. · ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Updated:"
      }), " 2026-07-09"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["The single implementation-status source for this spec is\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "docs/status/HOLDOUT_REDACTED_MOUNT_STATUS.md"
          })]
        }), " (to be created when build starts) —\nwhere this document and that one disagree, the status doc governs."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Reads first:"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "../ARCHITECTURE_PLAN.md"
        }), " §6 (testing / infer-then-fortify),\n§8 (assistant realm, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "rw@self"
        }), "), §3.4 (fixtures), and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ADVERSARIAL_REVIEW_1.md"
        }), " H3;\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "../reckoner_research_report_v2.md"
        }), " RQ-D4/D5 (holdout is the only example-based\ncorrectness weight; fixtures inferred-from certify nothing); ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "UI_AS_APPS_SPEC.md"
        }), " §8.15\n(attenuated delegation, downward-only), §8.7 (mount rule-sets); ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "EDITOR_FIRST_EDITING_SPEC.md"
        }), "\n§3.1 (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "capDir"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "capFile"
        }), " narrowing a held grant with no consent prompt); ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "SECRETS_SPEC.md"
        }), "\n§6 (use-not-read, the analogue for \"author-declares-where, host-resolves-value\")."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-0",
      "data-slug": "0-the-problem-precisely-normative-intent",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-0"
      }), "0. The problem, precisely  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative intent)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Reckoner's mainline authoring workflow is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "infer-then-fortify"
      }), " (plan §6): the assistant\ninfers a formula from observed data, then the platform withholds a slice of rows and emits\nthem as ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "specification"
      }), " tests — the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "only example-based tests that carry correctness\nweight"
      }), " (fixtures a formula was ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "fit to"
      }), " are green by construction, RQ-D4). Two mechanisms\nwere declared \"harness-enforced, not prompt discipline\": ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "holdout"
      }), " (the agent must not see\nthe withheld rows) and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "blind second-agent authoring"
      }), " (a test-writing agent must not see\nthe implementation or fitting data)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Adversarial-review-1 H3 showed neither is enforced."
      }), " The assistant realm holds\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "worktree:rw@self"
      }), " over the document, and the document ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "contains"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "fixtures/"
      }), ". An agent that\ncan ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "readFile('fixtures/orders.frame.json')"
      }), " can read the withheld rows directly. \"The\nharness withholds a slice from you\" is not a property ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "rw@self"
      }), " permits — it is prompt\ndiscipline mislabeled as enforcement, and prompt discipline over a standing read grant\nerodes. This spec closes ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "that"
      }), " leak."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "What this spec does NOT do (adversarial-review-2, load-bearing scope correction)."
        }), " Path\nseparation closes the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "filesystem read"
        }), " — but the agent does not need to read the file. It\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "authors the formula and the assertion that run over the holdout inside the engine, and\nreads their result"
        }), " (§5.1, the test-oracle channel). Holdout is therefore ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "not"
        }), " a\ncorrectness proof and is re-scoped to a best-effort ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "tripwire"
        }), "; the real correctness signal\nis the oracle-free legs (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ARCHITECTURE_PLAN §6"
        }), "). This spec is still worth building — the\ntrivial read and the metadata-probe leaks are real and D9 closes them — but it must be\ndescribed as ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "\"the agent cannot trivially read the holdout,\""
        }), " never ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "\"holdout certifies the\nformula.\""
        })]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "The core move:"
      }), " holdout is not \"ask the agent not to peek.\" It is a ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["host-enforced\nseparation of ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "who can read which path"
        })]
      }), " — the held-out rows live at a path the assistant's\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "authoring read view does not cover"
      }), ", and are resolved into test evaluation only by the\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "engine's host-brokered input injection"
      }), " (which the assistant cannot intercept). The agent\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "names"
      }), " the holdout fixture in a test cell's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "inputs"
      }), "; it never ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "reads"
      }), " its bytes. This is\nthe same shape as ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "SECRETS_SPEC §6"
      }), " (declare-where, host-resolves-value) and the same\nmachinery as ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "§8.15"
      }), " attenuated delegation — not a new trust primitive."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-1",
      "data-slug": "1-two-fixture-origins-only-one-of-which-is-holdout-normative",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-1"
      }), "1. Two fixture origins, only one of which is holdout  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The distinction the design turns on — the assistant may freely read fixtures it ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "captured"
      }), ";\nit must never read fixtures the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "host withheld"
      }), ":"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Captured fixtures"
        }), " (assistant-initiated freeze, plan §5.4/§8.2, gated): the assistant\nsees these rows ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "because it captured them from data it could already read"
        }), ". They are\nregression/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "characterization"
        }), " material and carry ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "no"
        }), " correctness weight. Readable under\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "rw@self"
        }), " — no redaction needed, and redacting them would be theater."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Withheld (holdout) fixtures"
        }), " (host-initiated split during inference): the host carves a\nrandom slice of the inference dataset ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "before the assistant ever receives it"
        }), ", writes it\nto a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "holdout store the assistant is not granted"
        }), ", and emits ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "specification"
        }), " test cells\nreferencing it. These carry the correctness weight and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "must be unreadable"
        }), " by the\nauthoring agent."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The load-bearing consequence: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "inference is a host-mediated operation, not a raw read."
      }), "\nWhen the assistant infers \"a formula over feed ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "orders"
      }), ",\" the host serves it the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "training\nsplit only"
      }), "; the full dataset is never at a path the assistant can ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "readFile"
      }), ". Holdout is\nnot \"attenuate a view the agent already used\" (too late — it would have read everything); it\nis \"the agent's inference input was ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "never"
      }), " the full set, and the complement lives where the\nagent has no scope.\""]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-2",
      "data-slug": "2-the-mount-topology-proposal-owned-by-d9",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-2"
      }), "2. The mount topology  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(proposal — owned by D9)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Three read scopes over one document, minted host-side, reusing ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "scopedFs"
      }), " rule-sets (§8.7):"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "document root (backing fs)\n  worksheets/            ← assistant: rw   | engine: r (host-injected) | 2nd-agent: —\n  templates/             ← assistant: rw   | engine: r                 | 2nd-agent: —\n  fixtures/              ← assistant: rw   | engine: r                 | 2nd-agent: —\n  reckoner.json          ← assistant: rw   | engine: r                 | 2nd-agent: intent only\n  .holdout/              ← assistant: —    | engine: r (injection only) | 2nd-agent: —\n      orders.holdout.frame.json            (host-written; never in the assistant's rule-set)\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: ".holdout/"
          }), " is a distinct scope the assistant's rule-set never includes."]
        }), " By\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "classifyPath"
        }), " (longest-prefix over the granted ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ScopeRule[]"
        }), "), a path under ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".holdout/"
        }), "\nclassifies ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "none"
        }), " for the assistant → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ENOENT"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "forbidden"
        }), ". No new rule ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "kind"
        }), " (no\n\"deny\") is needed — absence from the allow-list is the enforcement, exactly as an\nungranted sibling space is unreachable today."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The engine reads holdout only via host-brokered input injection"
        }), " (plan §4.1): the\nengine does not ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "readFile"
        }), " the mount for cell inputs — the scheduler resolves a test\ncell's declared ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "inputs"
        }), " to immutable snapshots and injects them. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "fixtures.orders_holdout"
        }), "\nresolves, host-side, to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".holdout/orders.holdout.frame.json"
        }), ". The engine holds no egress,\nso holdout data reaching the engine cannot leave (it is already M3-tainted and starved)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The second-agent (blind authoring) scope"
        }), " is narrower still: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "reckoner.json"
        }), " +the target\ncell's ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "doc"
          }), " (stated intent) only"]
        }), " — not ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "worksheets/"
        }), " (implementation) and not\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "fixtures/"
        }), " (fitting data). Same allow-list mechanism, a tighter rule-set."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-3",
      "data-slug": "3-the-readdir-leak-subtlety-why-holdout-must-sit-outside-every-granted-subtree-normative-the-one-non-obvious-correctness-point",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-3"
      }), "3. The readdir-leak subtlety — why ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: ".holdout/"
      }), " must sit outside every granted subtree  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative — the one non-obvious correctness point)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "scopedFs"
      }), " synthesizes a directory listing for a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "strict ancestor"
      }), " of a grant\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "synthesizedChildren"
      }), ", §8.7): reading a granted subtree's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "parent"
      }), " returns the granted\nchildren. This is a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "metadata leak surface"
      }), " for holdout: if ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: ".holdout/"
      }), " were a child of a\npath the assistant can list (e.g. under ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "fixtures/"
      }), "), a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "readdir('fixtures')"
      }), " could reveal\nthe holdout entry's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "existence and name"
      }), " even though its contents are unreadable — and the\nname/row-count alone can leak (how many rows were held out, which feed). Two rules close it:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: ".holdout/"
          }), " is a top-level sibling, never nested under a granted subtree"]
        }), ", so it is\nnever a child in any listing the assistant can synthesize (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "synthesizedChildren"
        }), " only\nemits the granted children of an ancestor, and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".holdout/"
        }), " is granted to no assistant\nrule → never emitted)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["The assistant's root grant is enumerated, not ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "{subtree:'/', mode:'rw'}"
          }), "."]
        }), " A\nwhole-root ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "rw"
        }), " grant makes the document root an ancestor of ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".holdout/"
        }), " and would\nsynthesize it into a root ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "readdir"
        }), ". So the assistant's rule-set is the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "explicit set of\nauthoring subtrees"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "worksheets/"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "templates/"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "fixtures/"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "reckoner.json"
        }), "), never\nthe bare root — and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".holdout/"
        }), " is simply not among them. (This is a narrowing of\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "rw@self"
        }), ", minted downward-only per §8.15; the app never had a legitimate reason to read\nits own ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".holdout/"
        }), ".)"]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Gate test G-HRM-3 asserts that ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "readdir"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "exists"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "stat"
        })]
      }), " at every level the assistant\ncan reach never reveal a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: ".holdout"
      }), " entry."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-3-1",
      "data-slug": "31-the-scopedfs-filter-must-be-deny-by-default-at-the-method-level-normative-review-2-code-gap-ab",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-3-1"
      }), "3.1 The ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "scopedFs"
      }), " filter must be deny-by-default at the method level  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative — review-2 CODE-GAP A/B)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Review-2 found the readdir closure necessary but ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "not sufficient"
      }), ", because ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "filteredFs"
      }), "\ntoday filters ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "only"
      }), " methods in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "WRITE_METHODS ∪ PATH_ARGS"
      }), "; any ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "other"
      }), " method returns the\nraw backing method bound to the un-classified path (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "bind(target)"
      }), "). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "exists"
      }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "existsSync"
      }), " is\nnot in that set, so ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "exists('/.holdout/…')"
      }), " reaches the raw backend and returns ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "true"
      }), " — a live\nexistence oracle that defeats the whole point, and if the ZenFS backend exposes a path-taking\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "openFile"
      }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "readlink"
      }), " (also unmodeled) the same passthrough yields ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "file bytes"
      }), ". Two\nmandatory changes, both ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "fail-closed"
      }), ":"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Deny-by-default:"
        }), " any path-bearing or unmodeled fs method must be classified (and throw\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ENOENT"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "EACCES"
        }), " for a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "none"
        }), " path) or ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "rejected outright"
        }), " — never ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "bind(target)"
        }), " on an\nun-classified path. The allow-list of pass-through methods must be explicit and exclude\neverything that takes or leaks a path (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "exists"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "stat"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "openFile"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "readlink"
        }), ", …)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Never fail open on an empty rule-set:"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "filteredFs"
        }), " currently pushes ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "{subtree:'/', mode:'rw'}"
        }), " for an empty rule-set and short-circuits all filtering (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "wholeRw"
        }), "). The assistant\nrealm must never be minted with an empty or bare-root rule-set, and the primitive must treat\nan empty rule-set as ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "deny-all"
        }), ", not allow-all — so a single mis-mint cannot expose\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".holdout/"
        }), "."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["These are gate tests G-HRM-2 (extended to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "exists"
      }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "stat"
      }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "openFile"
      }), ") and a new ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "G-HRM-7"
      }), "\n(empty rule-set → deny-all). Until they hold, D9 does not even close the metadata leak."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-4",
      "data-slug": "4-when-is-the-assistant-in-the-redacted-view-the-mode-is-host-driven-and-un-escapable-normative",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-4"
      }), "4. When is the assistant in the redacted view? — the mode is host-driven and un-escapable  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "The enforcement is only real if the assistant cannot flip back to an unredacted view\nmid-inference. Three rules:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["The redacted view is the assistant realm's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "standing"
          }), " mount grant, not a mode it\nenters."]
        }), " The assistant realm is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "always"
        }), " minted with the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".holdout/"
        }), "-excluding rule-set;\nthere is no un-redacted profile to escape to. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "rw@self"
        }), " is defined, for this realm, as the\nenumerated authoring subtrees — full stop. (H3's error was treating ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "rw@self"
        }), " as\nwhole-document; D9 defines it as the authoring subtrees.)"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The split is host-performed and pre-agent."
        }), " The host carves train/holdout at inference\nstart from data the assistant has ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "not yet"
        }), " received; the assistant's inference input is\nthe training split only (§1). There is no window in which the agent held the full set."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Re-derivation is host-controlled."
        }), " Re-splitting (a new inference run) re-randomizes\nhost-side; the assistant cannot request \"the holdout rows\" through any API — there is no\nmethod that returns them, and the fixture path is unreadable. The only thing that ever\nconsumes them is engine test-cell evaluation."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "The pre-agent-split precondition, and when it fails (review-2 D9-4 — resolving the old §4.2\nvs OQ-2 contradiction)."
      }), " Rule 2 holds ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "only"
      }), " when the host controls the data before the agent\nsees it. It does ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "not"
      }), " hold in two mainline cases, and the design must detect them rather than\nassert a guarantee it lacks:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Capture-then-infer:"
        }), " the assistant's fixture-capture freeze (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ARCHITECTURE_PLAN §5.4"
        }), ")\nreads feed rows into agent-readable ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "fixtures/"
        }), ". If a formula is later inferred over a feed the\nagent already captured, the \"holdout\" is a subset of already-seen rows — no enforceable split."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Static feeds (an uploaded CSV):"
        }), " there are no fresh rows to withhold; once the agent can\nread (or capture) the dataset, holdout is unenforceable ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "in principle"
        }), "."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Rule:"
      }), " the host tracks whether the agent has had a read path to a feed's rows; if it has, an\ninference over that feed is marked ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "no-enforceable-holdout"
      }), ", the emitted ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "specification"
      }), " test\nis flagged accordingly, and the review surface ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "down-weights it to zero correctness credit"
      }), "\n(it may still serve as a regression tripwire). Holdout credit is granted ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "only"
      }), " for a\nhost-fetched, never-agent-seen split. This makes §4.2's guarantee conditional and honest instead\nof absolute — and it is why the correctness weight lives in the oracle-free legs (§5.3), which do\nnot depend on any pre-agent window."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-5-1",
      "data-slug": "51-the-test-oracle-channel-why-holdout-is-a-tripwire-not-a-proof-normative-the-load-bearing-residual",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-5-1"
      }), "5.1 The test-oracle channel — why holdout is a tripwire, not a proof  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative — the load-bearing residual)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Path separation guards the door the agent does not need. The agent ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "authors the test cell\nthat runs over the holdout"
      }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "inputs: { rows: \"fixtures.orders_holdout\" }"
      }), ", a subject formula\nit wrote) and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "reads that cell's result"
      }), " — and every result surface is a read of the held-out\nrows:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Trace-replay"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ARCHITECTURE_PLAN §4.3"
        }), ") records \"declared inputs → intermediates →\noutput\" as the primary agent-facing debugging surface. A test cell's declared inputs over\nholdout ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "are the held-out rows"
        }), ", handed to the agent verbatim. This is a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "literal read"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Failure diagnostics"
        }), " (\"expected 0, got 48120\") leak the exact held-out aggregate in one\nrun."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Pass/fail bisection:"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "expectClose(holdout_aggregate, X, {rel:1e-6})"
        }), " is a comparator\noracle; the agent packs hundreds of assertions into one full-workbook run (tests are cells,\none tool call) and bisects each value out."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The \"M3-tainted and starved\" backstop (§2) does ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "not"
      }), " close this: the engine's egress\nstarvation stops holdout leaving ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "over the network"
      }), ", but the result must flow engine → host →\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "assistant review surface"
      }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ARCHITECTURE_PLAN §8.3"
      }), " requires showing \"formula + tests +\nresult\"). And for ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "clean-tier fixtures — the mainline shareable-workbook case"
      }), " — the trace is\nnot even tier-suppressed. There is a dilemma the design cannot escape: if results ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "were"
      }), "\ntainted enough to suppress, reading them would taint the assistant every authoring iteration\nand break the loop; if not, the oracle is open. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "D9 does not close the test-oracle channel,"
      }), "\nand a bandwidth-bounded output-channel policy over all test results/traces/diagnostics was\nconsidered and rejected (bigger than path separation, still beaten by §5's reconstruction).\nHence: holdout is a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "tripwire"
      }), " (a later edit that breaks a held-out row is a useful\nregression signal), never a certification."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-5-2",
      "data-slug": "52-reconstruction-is-central-for-the-target-workload-normative-honesty",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-5-2"
      }), "5.2 Reconstruction is central for the target workload  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative — honesty)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The earlier draft filed reconstruction as an adversarial corner. It is the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "center"
      }), ": for the\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "affine/aggregate/lookup formulas Reckoner explicitly targets"
      }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ARCHITECTURE_PLAN §7.1"
      }), "\nsingle aggregates; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "sum"
      }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "join"
      }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "groupBy"
      }), "), the training split ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "determines"
      }), " the holdout outcome\nby ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "ordinary fitting"
      }), " — no adversarial modeling, no distribution work. Two training rows fix a\nlinear formula; the holdout is fully predicted. Holdout has teeth only on\nnonlinear/regime-shift formulas, which are ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "not"
      }), " the scoped workload. So even a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "perfectly\nsealed"
      }), " mechanism proves ~0 bits for the dominant shape."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-5-3",
      "data-slug": "53-the-honest-claim-normative-intent",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-5-3"
      }), "5.3 The honest claim  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative intent)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["D9 closes the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "trivial"
      }), " leaks — the direct ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "readFile"
      }), " (H3) and the metadata-probe\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "exists"
      }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "stat"
      }), ", §3 + the deny-by-default rule below). It does ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "not"
      }), " close the test-oracle\nchannel (§5.1) and adds little for low-parameter formulas (§5.2). Therefore holdout is a\nbest-effort ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "tripwire"
      }), ", the review surface must not promote a holdout-only cell to\n\"validated,\" and the load-bearing correctness signal is the oracle-free legs\n(metamorphic/property/mutation, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ARCHITECTURE_PLAN §6"
      }), "), which need no hidden data and no oracle.\nBlind second-agent authoring carries the additional D9-3 limit (§7): agent-1 authors the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "doc"
      }), "\nagent-2 reads, so a complete intent over-determines the implementation and \"independence\" is a\nweak signal. A compromised ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "host"
      }), " is out of scope (it mints the grants); D9 defends against an\nover-eager or compromised ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "assistant"
      }), ", and only against the trivial read."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-6",
      "data-slug": "6-load-bearing-assumptions-code-anchors",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-6"
      }), "6. Load-bearing assumptions & code anchors"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "depends-on-today-verified-against-code-2026-07-09-re-checked-by-scriptscheck-spec-anchorsmjs",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "depends-on-today-verified-against-code-2026-07-09-re-checked-by-scriptscheck-spec-anchorsmjs"
      }), "Depends-on-today (verified against code 2026-07-09; re-checked by ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "scripts/check-spec-anchors.mjs"
      }), ")"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Assumption (existing behavior the design rests on)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Anchor (repo-relative file)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Token (grep-stable)"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["A mount grant is a rule-set of ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "{subtree, mode}"
            }), "; a path outside all rules is unreachable"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "immediately-run-site-main/src/filesystem/scopedFs.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "classifyPath"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["An ancestor ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "readdir"
            }), " is synthesized to only the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
              children: "granted"
            }), " children (the §3 leak surface)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "immediately-run-site-main/src/filesystem/scopedFs.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "synthesizedChildren"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "A held grant is narrowed downward-only when delegated (chroot inside the caller's subtree; escape → fail-closed)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "immediately-run-site-main/src/editor/task/attenuateDelta.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "DelegatableMount"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["The assistant reads the mount via the SDK fs port (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "readFile"
            }), ") — the surface D9 narrows"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "immediately-run-sdk/src/fs.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "sandboxFs"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Secret values are declared-where / host-resolved, never read by the app (the §0 analogue)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "immediately-run-site-main/src/registry/netFetchPolicy.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "injectSecret"
            })
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "must-establish-new-invariants-the-implementation-creates",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "must-establish-new-invariants-the-implementation-creates"
      }), "Must-establish (new invariants the implementation creates)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "New invariant"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Proven by (gate test)"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["The assistant realm's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "rw@self"
            }), " is the enumerated authoring subtrees, never whole-root"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["G-HRM-1: the assistant's minted rule-set contains no ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "{subtree:'/'}"
            }), " and excludes ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: ".holdout/"
            })]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "A held-out fixture is unreadable AND un-probeable by the assistant"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["G-HRM-2: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "readFile"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "exists"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "stat"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "openFile"
            }), "('.holdout/…') (and any traversal) from the assistant all return ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "none"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "ENOENT"
            }), " under ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "rw@self"
            }), " (review-2 CODE-GAP A)"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Holdout existence/name does not leak via readdir OR metadata"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["G-HRM-3: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "readdir"
            }), " ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
              children: ["and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                children: "exists"
              }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                children: "stat"
              })]
            }), " at every assistant-reachable level never reveal a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: ".holdout"
            }), " entry"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "The engine resolves holdout for test cells without an assistant-visible path"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["G-HRM-4: a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "specification"
            }), " test cell over ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "fixtures.orders_holdout"
            }), " evaluates in the engine; the same name read from the assistant fails"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Holdout credit only for a host-fetched, never-agent-seen split"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-HRM-5: an inference over a feed the agent has read/captured is marked no-enforceable-holdout and down-weighted to zero correctness credit (review-2 D9-4)"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Blind second-agent scope is intent-only"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["G-HRM-6: the second agent can read the target ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "doc"
            }), " but not ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "worksheets/"
            }), " or ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "fixtures/"
            })]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "The fs filter is deny-by-default; an empty rule-set denies all"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-HRM-7: an unmodeled path-bearing method throws; an empty/mis-minted rule-set exposes nothing (review-2 CODE-GAP B)"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Holdout does not promote a cell to \"validated\""
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["G-HRM-8: a cell whose only non-characterization coverage is a holdout ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "specification"
            }), " test renders as ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
              children: "not validated"
            }), "; \"validated\" requires a metamorphic/property leg or a passing mutation score (review-2 D9-1)"]
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-7",
      "data-slug": "7-decisions-rejected-alternatives",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-7"
      }), "7. Decisions & rejected alternatives"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Path-level separation (holdout at an ungranted ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: ".holdout/"
          }), " scope), reusing ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "scopedFs"
          }), "\nallow-list + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "attenuateDelta"
          }), "."]
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "within-file row-level redaction"
        }), " (return\nonly the training rows of ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "fixtures/orders.frame.json"
        }), ") — it needs a new content-aware fs\nfilter, is format-specific (frame JSON, CSV, …), and is far more fragile than \"the bytes\nlive at a path you don't have\"; path-level reuses the exact machinery that already gates\nungranted spaces."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "rw@self"
          }), " for the assistant realm is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "defined"
          }), " as the enumerated authoring subtrees."]
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " treating ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "rw@self"
        }), " as whole-document and bolting on a redaction pass (the H3\nhole — a whole-root grant makes ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".holdout/"
        }), " an ancestor-listable child and invites the\nreaddir leak); a \"deny-rule\" kind in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "scopedFs"
        }), " (absence from the allow-list already\ndenies; a deny-rule adds a second code path to keep consistent)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Holdout resolved only by the engine's host-brokered input injection."
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), "\ngranting the engine a broad fixture read that the assistant could ride; handing holdout to\nthe assistant \"sealed\" (any in-agent seal is defeatable by the agent)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Host-performed, pre-agent split."
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " letting the assistant perform the split\n(it would see the rows first — the whole hole); attenuating ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "after"
        }), " the agent read (too\nlate)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Re-scope holdout to a best-effort tripwire; the oracle-free legs carry correctness\n(review-2 decision, §5.3)."
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " keeping holdout as \"the only example-based\ncorrectness weight\" (the test-oracle channel §5.1 and affine reconstruction §5.2 defeat it);\na bandwidth-bounded output-channel policy over all test results/traces/diagnostics to save it\n(bigger than path separation, still beaten by reconstruction); dropping holdout entirely (the\ntripwire and the trivial-read/metadata-leak closures are still worth D9's cost)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Deny-by-default fs; empty rule-set denies all (review-2 §3.1)."
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " the current\nfail-open method allow-list (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "exists"
        }), "/unmodeled methods pass through) and the empty-rule-set\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "wholeRw"
        }), " short-circuit — both invert defense-in-depth."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Blind second-agent authoring is a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "weak"
          }), " signal (review-2 D9-3)."]
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " claiming\nindependence when ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["agent-1 authors the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "doc"
          }), " agent-2 reads"]
        }), " — a complete intent\nover-determines the implementation, so \"independent reproduction from intent\" is only as\nindependent as the doc is incomplete, which the design cannot enforce. Treat second-agent\ntests as corroboration, not proof."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Name the reconstruction residual; keep metamorphic/mutation as the load-bearing signal."
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " claiming holdout makes inferred formulas correct (RQ-D5 says nothing does);\nclaiming path separation defeats a distribution-modeling agent (it doesn't — and for the\ntarget workload it doesn't even defeat ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "ordinary fitting"
        }), ", §5.2)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-8",
      "data-slug": "8-open-questions",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-8"
      }), "8. Open questions"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "OQ-1 (split granularity)."
        }), " Row-level random holdout is assumed; some feeds want\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "stratified"
        }), " holdout (hold out a whole cohort/month so the test checks generalization\nacross a dimension). Does the host split API expose a stratification key, or is that a\nfuture add? Interacts with the case-study cohort sheet."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "OQ-2 — RESOLVED (review-2 D9-4, §4)."
        }), " Capture-then-infer and static feeds have no\nenforceable holdout; the host marks such inferences ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "no-enforceable-holdout"
        }), " and the review\nsurface grants them zero correctness credit (tripwire only). No longer open."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "OQ-3 (largely answered by review-2; residual for build)."
        }), " Reconstruction was shown\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "central"
        }), ", not a corner (§5.2), and the response is the re-scope, not a stronger seal. The\nresidual for the build: for which — if any — feed/formula shapes is holdout worth the machinery\nat all (nonlinear/regime-shift formulas), versus dropping it and relying wholly on the\noracle-free legs? Settle during M2 against the case study; the mandatory-second-agent gate\n(report RQ-D5 threshold) now attaches to a low mutation score, not to a holdout number."]
      }), "\n"]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/specs/HOLDOUT_REDACTED_MOUNT_SPEC.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJibG9ja3F1b3RlIiwiY29kZSIsImVtIiwiaDEiLCJoMiIsImgzIiwiaHIiLCJsaSIsIm9sIiwicCIsInByZSIsInN0cm9uZyIsInRhYmxlIiwidGJvZHkiLCJ0ZCIsInRoIiwidGhlYWQiLCJ0ciIsInVsIiwiX3Byb3ZpZGVDb21wb25lbnRzIiwiY29tcG9uZW50cyIsIkhlYWRpbmdBbmNob3IiLCJfbWlzc2luZ01keFJlZmVyZW5jZSIsImpzeHMiLCJGcmFnbWVudCIsImNoaWxkcmVuIiwiaWQiLCJqc3giLCJNRFhDb250ZW50Iiwid3JhcHBlciIsIk1EWExheW91dCIsIl9jIiwiY29tcG9uZW50IiwicGxhY2UiLCJFcnJvciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkhPTERPVVRfUkVEQUNURURfTU9VTlRfU1BFQy5tZCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKkBqc3hSdW50aW1lIGF1dG9tYXRpYyovXG4vKkBqc3hJbXBvcnRTb3VyY2UgcmVhY3QqL1xuaW1wb3J0IHt1c2VNRFhDb21wb25lbnRzIGFzIF9wcm92aWRlQ29tcG9uZW50c30gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrL01EWFByb3ZpZGVyXCI7XG5mdW5jdGlvbiBfY3JlYXRlTWR4Q29udGVudChwcm9wcykge1xuICBjb25zdCBfY29tcG9uZW50cyA9IHtcbiAgICBibG9ja3F1b3RlOiBcImJsb2NrcXVvdGVcIixcbiAgICBjb2RlOiBcImNvZGVcIixcbiAgICBlbTogXCJlbVwiLFxuICAgIGgxOiBcImgxXCIsXG4gICAgaDI6IFwiaDJcIixcbiAgICBoMzogXCJoM1wiLFxuICAgIGhyOiBcImhyXCIsXG4gICAgbGk6IFwibGlcIixcbiAgICBvbDogXCJvbFwiLFxuICAgIHA6IFwicFwiLFxuICAgIHByZTogXCJwcmVcIixcbiAgICBzdHJvbmc6IFwic3Ryb25nXCIsXG4gICAgdGFibGU6IFwidGFibGVcIixcbiAgICB0Ym9keTogXCJ0Ym9keVwiLFxuICAgIHRkOiBcInRkXCIsXG4gICAgdGg6IFwidGhcIixcbiAgICB0aGVhZDogXCJ0aGVhZFwiLFxuICAgIHRyOiBcInRyXCIsXG4gICAgdWw6IFwidWxcIixcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH0sIHtIZWFkaW5nQW5jaG9yfSA9IF9jb21wb25lbnRzO1xuICBpZiAoIUhlYWRpbmdBbmNob3IpIF9taXNzaW5nTWR4UmVmZXJlbmNlKFwiSGVhZGluZ0FuY2hvclwiLCB0cnVlKTtcbiAgcmV0dXJuIDw+PF9jb21wb25lbnRzLmgxIGlkPVwiaW1tZWRpYXRlbHlydW4taG9sZG91dC1yZWRhY3RlZC1tb3VudC12aWV3LWhvc3QtZW5mb3JjZWQtdHJhaW5ob2xkb3V0LXNlcGFyYXRpb24tZm9yLWluZmVycmVkLWZvcm11bGFzXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJpbW1lZGlhdGVseXJ1bi1ob2xkb3V0LXJlZGFjdGVkLW1vdW50LXZpZXctaG9zdC1lbmZvcmNlZC10cmFpbmhvbGRvdXQtc2VwYXJhdGlvbi1mb3ItaW5mZXJyZWQtZm9ybXVsYXNcIiAvPntcImltbWVkaWF0ZWx5LnJ1biBIb2xkb3V0IFJlZGFjdGVkLU1vdW50IFZpZXcg4oCUIGhvc3QtZW5mb3JjZWQgdHJhaW4vaG9sZG91dCBzZXBhcmF0aW9uIGZvciBpbmZlcnJlZCBmb3JtdWxhc1wifTwvX2NvbXBvbmVudHMuaDE+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJTdGF0dXM6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHByb3Bvc2FsIC8gZHJhZnQg4oCUIHRoZSBEOSBNMCBkZXNpZ24tc3ByaW50IG91dHB1dCBvZiBcIn08X2NvbXBvbmVudHMuY29kZT57XCIuLi9BUkNISVRFQ1RVUkVfUExBTi5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgwqc5LiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlJlLXNjb3BlZCBieSBhZHZlcnNhcmlhbC1yZXZpZXctMiAoMjAyNi0wNy0wOSk6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHRoaXMgbWVjaGFuaXNtIGNsb3NlcyB0aGUgXCJ9PF9jb21wb25lbnRzLmVtPntcInRyaXZpYWxcIn08L19jb21wb25lbnRzLmVtPntcIiBkaXJlY3QtcmVhZCBsZWFrIChIMykgYnV0IGRvZXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJub3RcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgbWFrZSBleGFtcGxlLWJhc2VkIGhvbGRvdXQgYSBjb3JyZWN0bmVzcyBwcm9vZiDigJQgdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1widGVzdC1vcmFjbGUgY2hhbm5lbFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAowqc1LjEpIGFuZCBhZmZpbmUtZm9ybXVsYSByZWNvbnN0cnVjdGlvbiAowqc1KSBkZWZlYXQgdGhhdC4gUGVyIHRoZSB1c2VyIGRlY2lzaW9uLCBob2xkb3V0IGlzIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJiZXN0LWVmZm9ydCByZWdyZXNzaW9uL3RyaXB3aXJlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiOyB0aGUgbG9hZC1iZWFyaW5nIGNvcnJlY3RuZXNzIHNpZ25hbCBpcyBtZXRhbW9ycGhpYyArIHByb3BlcnR5ICsgbXV0YXRpb24gKFwifTxfY29tcG9uZW50cy5jb2RlPntcIkFSQ0hJVEVDVFVSRV9QTEFOIMKnNlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLiBEZXNpZ24gb25seTsgbm90aGluZyBoZXJlIGlzIGJ1aWx0LiDCtyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlVwZGF0ZWQ6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIDIwMjYtMDctMDlcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgc2luZ2xlIGltcGxlbWVudGF0aW9uLXN0YXR1cyBzb3VyY2UgZm9yIHRoaXMgc3BlYyBpc1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcImRvY3Mvc3RhdHVzL0hPTERPVVRfUkVEQUNURURfTU9VTlRfU1RBVFVTLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAodG8gYmUgY3JlYXRlZCB3aGVuIGJ1aWxkIHN0YXJ0cykg4oCUXFxud2hlcmUgdGhpcyBkb2N1bWVudCBhbmQgdGhhdCBvbmUgZGlzYWdyZWUsIHRoZSBzdGF0dXMgZG9jIGdvdmVybnMuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTwvX2NvbXBvbmVudHMuYmxvY2txdW90ZT57XCJcXG5cIn08X2NvbXBvbmVudHMuYmxvY2txdW90ZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlJlYWRzIGZpcnN0OlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCIuLi9BUkNISVRFQ1RVUkVfUExBTi5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgwqc2ICh0ZXN0aW5nIC8gaW5mZXItdGhlbi1mb3J0aWZ5KSxcXG7CpzggKGFzc2lzdGFudCByZWFsbSwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicndAc2VsZlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLCDCpzMuNCAoZml4dHVyZXMpLCBhbmQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQURWRVJTQVJJQUxfUkVWSUVXXzEubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIEgzO1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcIi4uL3JlY2tvbmVyX3Jlc2VhcmNoX3JlcG9ydF92Mi5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgUlEtRDQvRDUgKGhvbGRvdXQgaXMgdGhlIG9ubHkgZXhhbXBsZS1iYXNlZFxcbmNvcnJlY3RuZXNzIHdlaWdodDsgZml4dHVyZXMgaW5mZXJyZWQtZnJvbSBjZXJ0aWZ5IG5vdGhpbmcpOyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJVSV9BU19BUFBTX1NQRUMubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIMKnOC4xNVxcbihhdHRlbnVhdGVkIGRlbGVnYXRpb24sIGRvd253YXJkLW9ubHkpLCDCpzguNyAobW91bnQgcnVsZS1zZXRzKTsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRURJVE9SX0ZJUlNUX0VESVRJTkdfU1BFQy5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG7CpzMuMSAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2FwRGlyXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJjYXBGaWxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBuYXJyb3dpbmcgYSBoZWxkIGdyYW50IHdpdGggbm8gY29uc2VudCBwcm9tcHQpOyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJTRUNSRVRTX1NQRUMubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxuwqc2ICh1c2Utbm90LXJlYWQsIHRoZSBhbmFsb2d1ZSBmb3IgXFxcImF1dGhvci1kZWNsYXJlcy13aGVyZSwgaG9zdC1yZXNvbHZlcy12YWx1ZVxcXCIpLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08L19jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmhyIC8+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTBcIiBkYXRhLXNsdWc9XCIwLXRoZS1wcm9ibGVtLXByZWNpc2VseS1ub3JtYXRpdmUtaW50ZW50XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtMFwiIC8+e1wiMC4gVGhlIHByb2JsZW0sIHByZWNpc2VseSAgXCJ9PF9jb21wb25lbnRzLmVtPntcIihub3JtYXRpdmUgaW50ZW50KVwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJSZWNrb25lcidzIG1haW5saW5lIGF1dGhvcmluZyB3b3JrZmxvdyBpcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImluZmVyLXRoZW4tZm9ydGlmeVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAocGxhbiDCpzYpOiB0aGUgYXNzaXN0YW50XFxuaW5mZXJzIGEgZm9ybXVsYSBmcm9tIG9ic2VydmVkIGRhdGEsIHRoZW4gdGhlIHBsYXRmb3JtIHdpdGhob2xkcyBhIHNsaWNlIG9mIHJvd3MgYW5kIGVtaXRzXFxudGhlbSBhcyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcGVjaWZpY2F0aW9uXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB0ZXN0cyDigJQgdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wib25seSBleGFtcGxlLWJhc2VkIHRlc3RzIHRoYXQgY2FycnkgY29ycmVjdG5lc3NcXG53ZWlnaHRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKGZpeHR1cmVzIGEgZm9ybXVsYSB3YXMgXCJ9PF9jb21wb25lbnRzLmVtPntcImZpdCB0b1wifTwvX2NvbXBvbmVudHMuZW0+e1wiIGFyZSBncmVlbiBieSBjb25zdHJ1Y3Rpb24sIFJRLUQ0KS4gVHdvIG1lY2hhbmlzbXNcXG53ZXJlIGRlY2xhcmVkIFxcXCJoYXJuZXNzLWVuZm9yY2VkLCBub3QgcHJvbXB0IGRpc2NpcGxpbmVcXFwiOiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImhvbGRvdXRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHRoZSBhZ2VudCBtdXN0IG5vdCBzZWVcXG50aGUgd2l0aGhlbGQgcm93cykgYW5kIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiYmxpbmQgc2Vjb25kLWFnZW50IGF1dGhvcmluZ1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoYSB0ZXN0LXdyaXRpbmcgYWdlbnQgbXVzdCBub3Qgc2VlXFxudGhlIGltcGxlbWVudGF0aW9uIG9yIGZpdHRpbmcgZGF0YSkuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQWR2ZXJzYXJpYWwtcmV2aWV3LTEgSDMgc2hvd2VkIG5laXRoZXIgaXMgZW5mb3JjZWQuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRoZSBhc3Npc3RhbnQgcmVhbG0gaG9sZHNcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJ3b3JrdHJlZTpyd0BzZWxmXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBvdmVyIHRoZSBkb2N1bWVudCwgYW5kIHRoZSBkb2N1bWVudCBcIn08X2NvbXBvbmVudHMuZW0+e1wiY29udGFpbnNcIn08L19jb21wb25lbnRzLmVtPntcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmaXh0dXJlcy9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLiBBbiBhZ2VudCB0aGF0XFxuY2FuIFwifTxfY29tcG9uZW50cy5jb2RlPntcInJlYWRGaWxlKCdmaXh0dXJlcy9vcmRlcnMuZnJhbWUuanNvbicpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjYW4gcmVhZCB0aGUgd2l0aGhlbGQgcm93cyBkaXJlY3RseS4gXFxcIlRoZVxcbmhhcm5lc3Mgd2l0aGhvbGRzIGEgc2xpY2UgZnJvbSB5b3VcXFwiIGlzIG5vdCBhIHByb3BlcnR5IFwifTxfY29tcG9uZW50cy5jb2RlPntcInJ3QHNlbGZcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHBlcm1pdHMg4oCUIGl0IGlzIHByb21wdFxcbmRpc2NpcGxpbmUgbWlzbGFiZWxlZCBhcyBlbmZvcmNlbWVudCwgYW5kIHByb21wdCBkaXNjaXBsaW5lIG92ZXIgYSBzdGFuZGluZyByZWFkIGdyYW50XFxuZXJvZGVzLiBUaGlzIHNwZWMgY2xvc2VzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1widGhhdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBsZWFrLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuYmxvY2txdW90ZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIldoYXQgdGhpcyBzcGVjIGRvZXMgTk9UIGRvIChhZHZlcnNhcmlhbC1yZXZpZXctMiwgbG9hZC1iZWFyaW5nIHNjb3BlIGNvcnJlY3Rpb24pLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBQYXRoXFxuc2VwYXJhdGlvbiBjbG9zZXMgdGhlIFwifTxfY29tcG9uZW50cy5lbT57XCJmaWxlc3lzdGVtIHJlYWRcIn08L19jb21wb25lbnRzLmVtPntcIiDigJQgYnV0IHRoZSBhZ2VudCBkb2VzIG5vdCBuZWVkIHRvIHJlYWQgdGhlIGZpbGUuIEl0XFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJhdXRob3JzIHRoZSBmb3JtdWxhIGFuZCB0aGUgYXNzZXJ0aW9uIHRoYXQgcnVuIG92ZXIgdGhlIGhvbGRvdXQgaW5zaWRlIHRoZSBlbmdpbmUsIGFuZFxcbnJlYWRzIHRoZWlyIHJlc3VsdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAowqc1LjEsIHRoZSB0ZXN0LW9yYWNsZSBjaGFubmVsKS4gSG9sZG91dCBpcyB0aGVyZWZvcmUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJub3RcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYVxcbmNvcnJlY3RuZXNzIHByb29mIGFuZCBpcyByZS1zY29wZWQgdG8gYSBiZXN0LWVmZm9ydCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInRyaXB3aXJlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiOyB0aGUgcmVhbCBjb3JyZWN0bmVzcyBzaWduYWxcXG5pcyB0aGUgb3JhY2xlLWZyZWUgbGVncyAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQVJDSElURUNUVVJFX1BMQU4gwqc2XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikuIFRoaXMgc3BlYyBpcyBzdGlsbCB3b3J0aCBidWlsZGluZyDigJQgdGhlXFxudHJpdmlhbCByZWFkIGFuZCB0aGUgbWV0YWRhdGEtcHJvYmUgbGVha3MgYXJlIHJlYWwgYW5kIEQ5IGNsb3NlcyB0aGVtIOKAlCBidXQgaXQgbXVzdCBiZVxcbmRlc2NyaWJlZCBhcyBcIn08X2NvbXBvbmVudHMuZW0+e1wiXFxcInRoZSBhZ2VudCBjYW5ub3QgdHJpdmlhbGx5IHJlYWQgdGhlIGhvbGRvdXQsXFxcIlwifTwvX2NvbXBvbmVudHMuZW0+e1wiIG5ldmVyIFwifTxfY29tcG9uZW50cy5lbT57XCJcXFwiaG9sZG91dCBjZXJ0aWZpZXMgdGhlXFxuZm9ybXVsYS5cXFwiXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVGhlIGNvcmUgbW92ZTpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgaG9sZG91dCBpcyBub3QgXFxcImFzayB0aGUgYWdlbnQgbm90IHRvIHBlZWsuXFxcIiBJdCBpcyBhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiaG9zdC1lbmZvcmNlZFxcbnNlcGFyYXRpb24gb2YgXCJ9PF9jb21wb25lbnRzLmVtPntcIndobyBjYW4gcmVhZCB3aGljaCBwYXRoXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHRoZSBoZWxkLW91dCByb3dzIGxpdmUgYXQgYSBwYXRoIHRoZSBhc3Npc3RhbnQnc1xcblwifTxfY29tcG9uZW50cy5lbT57XCJhdXRob3JpbmcgcmVhZCB2aWV3IGRvZXMgbm90IGNvdmVyXCJ9PC9fY29tcG9uZW50cy5lbT57XCIsIGFuZCBhcmUgcmVzb2x2ZWQgaW50byB0ZXN0IGV2YWx1YXRpb24gb25seSBieSB0aGVcXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImVuZ2luZSdzIGhvc3QtYnJva2VyZWQgaW5wdXQgaW5qZWN0aW9uXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICh3aGljaCB0aGUgYXNzaXN0YW50IGNhbm5vdCBpbnRlcmNlcHQpLiBUaGUgYWdlbnRcXG5cIn08X2NvbXBvbmVudHMuZW0+e1wibmFtZXNcIn08L19jb21wb25lbnRzLmVtPntcIiB0aGUgaG9sZG91dCBmaXh0dXJlIGluIGEgdGVzdCBjZWxsJ3MgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW5wdXRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjsgaXQgbmV2ZXIgXCJ9PF9jb21wb25lbnRzLmVtPntcInJlYWRzXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgaXRzIGJ5dGVzLiBUaGlzIGlzXFxudGhlIHNhbWUgc2hhcGUgYXMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiU0VDUkVUU19TUEVDIMKnNlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKGRlY2xhcmUtd2hlcmUsIGhvc3QtcmVzb2x2ZXMtdmFsdWUpIGFuZCB0aGUgc2FtZVxcbm1hY2hpbmVyeSBhcyBcIn08X2NvbXBvbmVudHMuY29kZT57XCLCpzguMTVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGF0dGVudWF0ZWQgZGVsZWdhdGlvbiDigJQgbm90IGEgbmV3IHRydXN0IHByaW1pdGl2ZS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmhyIC8+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTFcIiBkYXRhLXNsdWc9XCIxLXR3by1maXh0dXJlLW9yaWdpbnMtb25seS1vbmUtb2Ytd2hpY2gtaXMtaG9sZG91dC1ub3JtYXRpdmVcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy0xXCIgLz57XCIxLiBUd28gZml4dHVyZSBvcmlnaW5zLCBvbmx5IG9uZSBvZiB3aGljaCBpcyBob2xkb3V0ICBcIn08X2NvbXBvbmVudHMuZW0+e1wiKG5vcm1hdGl2ZSlcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIGRpc3RpbmN0aW9uIHRoZSBkZXNpZ24gdHVybnMgb24g4oCUIHRoZSBhc3Npc3RhbnQgbWF5IGZyZWVseSByZWFkIGZpeHR1cmVzIGl0IFwifTxfY29tcG9uZW50cy5lbT57XCJjYXB0dXJlZFwifTwvX2NvbXBvbmVudHMuZW0+e1wiO1xcbml0IG11c3QgbmV2ZXIgcmVhZCBmaXh0dXJlcyB0aGUgXCJ9PF9jb21wb25lbnRzLmVtPntcImhvc3Qgd2l0aGhlbGRcIn08L19jb21wb25lbnRzLmVtPntcIjpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkNhcHR1cmVkIGZpeHR1cmVzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChhc3Npc3RhbnQtaW5pdGlhdGVkIGZyZWV6ZSwgcGxhbiDCpzUuNC/CpzguMiwgZ2F0ZWQpOiB0aGUgYXNzaXN0YW50XFxuc2VlcyB0aGVzZSByb3dzIFwifTxfY29tcG9uZW50cy5lbT57XCJiZWNhdXNlIGl0IGNhcHR1cmVkIHRoZW0gZnJvbSBkYXRhIGl0IGNvdWxkIGFscmVhZHkgcmVhZFwifTwvX2NvbXBvbmVudHMuZW0+e1wiLiBUaGV5IGFyZVxcbnJlZ3Jlc3Npb24vXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2hhcmFjdGVyaXphdGlvblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgbWF0ZXJpYWwgYW5kIGNhcnJ5IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibm9cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgY29ycmVjdG5lc3Mgd2VpZ2h0LiBSZWFkYWJsZSB1bmRlclxcblwifTxfY29tcG9uZW50cy5jb2RlPntcInJ3QHNlbGZcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCBubyByZWRhY3Rpb24gbmVlZGVkLCBhbmQgcmVkYWN0aW5nIHRoZW0gd291bGQgYmUgdGhlYXRlci5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIldpdGhoZWxkIChob2xkb3V0KSBmaXh0dXJlc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoaG9zdC1pbml0aWF0ZWQgc3BsaXQgZHVyaW5nIGluZmVyZW5jZSk6IHRoZSBob3N0IGNhcnZlcyBhXFxucmFuZG9tIHNsaWNlIG9mIHRoZSBpbmZlcmVuY2UgZGF0YXNldCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImJlZm9yZSB0aGUgYXNzaXN0YW50IGV2ZXIgcmVjZWl2ZXMgaXRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIsIHdyaXRlcyBpdFxcbnRvIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJob2xkb3V0IHN0b3JlIHRoZSBhc3Npc3RhbnQgaXMgbm90IGdyYW50ZWRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIsIGFuZCBlbWl0cyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcGVjaWZpY2F0aW9uXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB0ZXN0IGNlbGxzXFxucmVmZXJlbmNpbmcgaXQuIFRoZXNlIGNhcnJ5IHRoZSBjb3JyZWN0bmVzcyB3ZWlnaHQgYW5kIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibXVzdCBiZSB1bnJlYWRhYmxlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGJ5IHRoZVxcbmF1dGhvcmluZyBhZ2VudC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIGxvYWQtYmVhcmluZyBjb25zZXF1ZW5jZTogXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJpbmZlcmVuY2UgaXMgYSBob3N0LW1lZGlhdGVkIG9wZXJhdGlvbiwgbm90IGEgcmF3IHJlYWQuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiXFxuV2hlbiB0aGUgYXNzaXN0YW50IGluZmVycyBcXFwiYSBmb3JtdWxhIG92ZXIgZmVlZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJvcmRlcnNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLFxcXCIgdGhlIGhvc3Qgc2VydmVzIGl0IHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInRyYWluaW5nXFxuc3BsaXQgb25seVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIjsgdGhlIGZ1bGwgZGF0YXNldCBpcyBuZXZlciBhdCBhIHBhdGggdGhlIGFzc2lzdGFudCBjYW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicmVhZEZpbGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLiBIb2xkb3V0IGlzXFxubm90IFxcXCJhdHRlbnVhdGUgYSB2aWV3IHRoZSBhZ2VudCBhbHJlYWR5IHVzZWRcXFwiICh0b28gbGF0ZSDigJQgaXQgd291bGQgaGF2ZSByZWFkIGV2ZXJ5dGhpbmcpOyBpdFxcbmlzIFxcXCJ0aGUgYWdlbnQncyBpbmZlcmVuY2UgaW5wdXQgd2FzIFwifTxfY29tcG9uZW50cy5lbT57XCJuZXZlclwifTwvX2NvbXBvbmVudHMuZW0+e1wiIHRoZSBmdWxsIHNldCwgYW5kIHRoZSBjb21wbGVtZW50IGxpdmVzIHdoZXJlIHRoZVxcbmFnZW50IGhhcyBubyBzY29wZS5cXFwiXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInNlYy0yXCIgZGF0YS1zbHVnPVwiMi10aGUtbW91bnQtdG9wb2xvZ3ktcHJvcG9zYWwtb3duZWQtYnktZDlcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy0yXCIgLz57XCIyLiBUaGUgbW91bnQgdG9wb2xvZ3kgIFwifTxfY29tcG9uZW50cy5lbT57XCIocHJvcG9zYWwg4oCUIG93bmVkIGJ5IEQ5KVwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaHJlZSByZWFkIHNjb3BlcyBvdmVyIG9uZSBkb2N1bWVudCwgbWludGVkIGhvc3Qtc2lkZSwgcmV1c2luZyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzY29wZWRGc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcnVsZS1zZXRzICjCpzguNyk6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wcmU+PF9jb21wb25lbnRzLmNvZGU+e1wiZG9jdW1lbnQgcm9vdCAoYmFja2luZyBmcylcXG4gIHdvcmtzaGVldHMvICAgICAgICAgICAg4oaQIGFzc2lzdGFudDogcncgICB8IGVuZ2luZTogciAoaG9zdC1pbmplY3RlZCkgfCAybmQtYWdlbnQ6IOKAlFxcbiAgdGVtcGxhdGVzLyAgICAgICAgICAgICDihpAgYXNzaXN0YW50OiBydyAgIHwgZW5naW5lOiByICAgICAgICAgICAgICAgICB8IDJuZC1hZ2VudDog4oCUXFxuICBmaXh0dXJlcy8gICAgICAgICAgICAgIOKGkCBhc3Npc3RhbnQ6IHJ3ICAgfCBlbmdpbmU6IHIgICAgICAgICAgICAgICAgIHwgMm5kLWFnZW50OiDigJRcXG4gIHJlY2tvbmVyLmpzb24gICAgICAgICAg4oaQIGFzc2lzdGFudDogcncgICB8IGVuZ2luZTogciAgICAgICAgICAgICAgICAgfCAybmQtYWdlbnQ6IGludGVudCBvbmx5XFxuICAuaG9sZG91dC8gICAgICAgICAgICAgIOKGkCBhc3Npc3RhbnQ6IOKAlCAgICB8IGVuZ2luZTogciAoaW5qZWN0aW9uIG9ubHkpIHwgMm5kLWFnZW50OiDigJRcXG4gICAgICBvcmRlcnMuaG9sZG91dC5mcmFtZS5qc29uICAgICAgICAgICAgKGhvc3Qtd3JpdHRlbjsgbmV2ZXIgaW4gdGhlIGFzc2lzdGFudCdzIHJ1bGUtc2V0KVxcblwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnByZT57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+PF9jb21wb25lbnRzLmNvZGU+e1wiLmhvbGRvdXQvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpcyBhIGRpc3RpbmN0IHNjb3BlIHRoZSBhc3Npc3RhbnQncyBydWxlLXNldCBuZXZlciBpbmNsdWRlcy5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgQnlcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJjbGFzc2lmeVBhdGhcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChsb25nZXN0LXByZWZpeCBvdmVyIHRoZSBncmFudGVkIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlNjb3BlUnVsZVtdXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiksIGEgcGF0aCB1bmRlciBcIn08X2NvbXBvbmVudHMuY29kZT57XCIuaG9sZG91dC9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxuY2xhc3NpZmllcyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJub25lXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBmb3IgdGhlIGFzc2lzdGFudCDihpIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRU5PRU5UXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJmb3JiaWRkZW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLiBObyBuZXcgcnVsZSBcIn08X2NvbXBvbmVudHMuZW0+e1wia2luZFwifTwvX2NvbXBvbmVudHMuZW0+e1wiIChub1xcblxcXCJkZW55XFxcIikgaXMgbmVlZGVkIOKAlCBhYnNlbmNlIGZyb20gdGhlIGFsbG93LWxpc3QgaXMgdGhlIGVuZm9yY2VtZW50LCBleGFjdGx5IGFzIGFuXFxudW5ncmFudGVkIHNpYmxpbmcgc3BhY2UgaXMgdW5yZWFjaGFibGUgdG9kYXkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgZW5naW5lIHJlYWRzIGhvbGRvdXQgb25seSB2aWEgaG9zdC1icm9rZXJlZCBpbnB1dCBpbmplY3Rpb25cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHBsYW4gwqc0LjEpOiB0aGVcXG5lbmdpbmUgZG9lcyBub3QgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicmVhZEZpbGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHRoZSBtb3VudCBmb3IgY2VsbCBpbnB1dHMg4oCUIHRoZSBzY2hlZHVsZXIgcmVzb2x2ZXMgYSB0ZXN0XFxuY2VsbCdzIGRlY2xhcmVkIFwifTxfY29tcG9uZW50cy5jb2RlPntcImlucHV0c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdG8gaW1tdXRhYmxlIHNuYXBzaG90cyBhbmQgaW5qZWN0cyB0aGVtLiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmaXh0dXJlcy5vcmRlcnNfaG9sZG91dFwifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG5yZXNvbHZlcywgaG9zdC1zaWRlLCB0byBcIn08X2NvbXBvbmVudHMuY29kZT57XCIuaG9sZG91dC9vcmRlcnMuaG9sZG91dC5mcmFtZS5qc29uXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi4gVGhlIGVuZ2luZSBob2xkcyBubyBlZ3Jlc3MsXFxuc28gaG9sZG91dCBkYXRhIHJlYWNoaW5nIHRoZSBlbmdpbmUgY2Fubm90IGxlYXZlIChpdCBpcyBhbHJlYWR5IE0zLXRhaW50ZWQgYW5kIHN0YXJ2ZWQpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVGhlIHNlY29uZC1hZ2VudCAoYmxpbmQgYXV0aG9yaW5nKSBzY29wZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBpcyBuYXJyb3dlciBzdGlsbDogXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicmVja29uZXIuanNvblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgK3RoZSB0YXJnZXRcXG5jZWxsJ3MgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz48X2NvbXBvbmVudHMuY29kZT57XCJkb2NcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChzdGF0ZWQgaW50ZW50KSBvbmx5XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBub3QgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wid29ya3NoZWV0cy9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChpbXBsZW1lbnRhdGlvbikgYW5kIG5vdFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcImZpeHR1cmVzL1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKGZpdHRpbmcgZGF0YSkuIFNhbWUgYWxsb3ctbGlzdCBtZWNoYW5pc20sIGEgdGlnaHRlciBydWxlLXNldC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTNcIiBkYXRhLXNsdWc9XCIzLXRoZS1yZWFkZGlyLWxlYWstc3VidGxldHktd2h5LWhvbGRvdXQtbXVzdC1zaXQtb3V0c2lkZS1ldmVyeS1ncmFudGVkLXN1YnRyZWUtbm9ybWF0aXZlLXRoZS1vbmUtbm9uLW9idmlvdXMtY29ycmVjdG5lc3MtcG9pbnRcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy0zXCIgLz57XCIzLiBUaGUgcmVhZGRpci1sZWFrIHN1YnRsZXR5IOKAlCB3aHkgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLmhvbGRvdXQvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBtdXN0IHNpdCBvdXRzaWRlIGV2ZXJ5IGdyYW50ZWQgc3VidHJlZSAgXCJ9PF9jb21wb25lbnRzLmVtPntcIihub3JtYXRpdmUg4oCUIHRoZSBvbmUgbm9uLW9idmlvdXMgY29ycmVjdG5lc3MgcG9pbnQpXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5jb2RlPntcInNjb3BlZEZzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBzeW50aGVzaXplcyBhIGRpcmVjdG9yeSBsaXN0aW5nIGZvciBhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wic3RyaWN0IGFuY2VzdG9yXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIG9mIGEgZ3JhbnRcXG4oXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3ludGhlc2l6ZWRDaGlsZHJlblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIMKnOC43KTogcmVhZGluZyBhIGdyYW50ZWQgc3VidHJlZSdzIFwifTxfY29tcG9uZW50cy5lbT57XCJwYXJlbnRcIn08L19jb21wb25lbnRzLmVtPntcIiByZXR1cm5zIHRoZSBncmFudGVkXFxuY2hpbGRyZW4uIFRoaXMgaXMgYSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm1ldGFkYXRhIGxlYWsgc3VyZmFjZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBmb3IgaG9sZG91dDogaWYgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLmhvbGRvdXQvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB3ZXJlIGEgY2hpbGQgb2YgYVxcbnBhdGggdGhlIGFzc2lzdGFudCBjYW4gbGlzdCAoZS5nLiB1bmRlciBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmaXh0dXJlcy9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSwgYSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyZWFkZGlyKCdmaXh0dXJlcycpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjb3VsZCByZXZlYWxcXG50aGUgaG9sZG91dCBlbnRyeSdzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZXhpc3RlbmNlIGFuZCBuYW1lXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGV2ZW4gdGhvdWdoIGl0cyBjb250ZW50cyBhcmUgdW5yZWFkYWJsZSDigJQgYW5kIHRoZVxcbm5hbWUvcm93LWNvdW50IGFsb25lIGNhbiBsZWFrIChob3cgbWFueSByb3dzIHdlcmUgaGVsZCBvdXQsIHdoaWNoIGZlZWQpLiBUd28gcnVsZXMgY2xvc2UgaXQ6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz48X2NvbXBvbmVudHMuY29kZT57XCIuaG9sZG91dC9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGlzIGEgdG9wLWxldmVsIHNpYmxpbmcsIG5ldmVyIG5lc3RlZCB1bmRlciBhIGdyYW50ZWQgc3VidHJlZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgc28gaXQgaXNcXG5uZXZlciBhIGNoaWxkIGluIGFueSBsaXN0aW5nIHRoZSBhc3Npc3RhbnQgY2FuIHN5bnRoZXNpemUgKFwifTxfY29tcG9uZW50cy5jb2RlPntcInN5bnRoZXNpemVkQ2hpbGRyZW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG9ubHlcXG5lbWl0cyB0aGUgZ3JhbnRlZCBjaGlsZHJlbiBvZiBhbiBhbmNlc3RvciwgYW5kIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi5ob2xkb3V0L1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaXMgZ3JhbnRlZCB0byBubyBhc3Npc3RhbnRcXG5ydWxlIOKGkiBuZXZlciBlbWl0dGVkKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlRoZSBhc3Npc3RhbnQncyByb290IGdyYW50IGlzIGVudW1lcmF0ZWQsIG5vdCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ7c3VidHJlZTonLycsIG1vZGU6J3J3J31cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBBXFxud2hvbGUtcm9vdCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyd1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZ3JhbnQgbWFrZXMgdGhlIGRvY3VtZW50IHJvb3QgYW4gYW5jZXN0b3Igb2YgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLmhvbGRvdXQvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhbmQgd291bGRcXG5zeW50aGVzaXplIGl0IGludG8gYSByb290IFwifTxfY29tcG9uZW50cy5jb2RlPntcInJlYWRkaXJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLiBTbyB0aGUgYXNzaXN0YW50J3MgcnVsZS1zZXQgaXMgdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZXhwbGljaXQgc2V0IG9mXFxuYXV0aG9yaW5nIHN1YnRyZWVzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJ3b3Jrc2hlZXRzL1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcInRlbXBsYXRlcy9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmaXh0dXJlcy9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyZWNrb25lci5qc29uXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiksIG5ldmVyXFxudGhlIGJhcmUgcm9vdCDigJQgYW5kIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi5ob2xkb3V0L1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaXMgc2ltcGx5IG5vdCBhbW9uZyB0aGVtLiAoVGhpcyBpcyBhIG5hcnJvd2luZyBvZlxcblwifTxfY29tcG9uZW50cy5jb2RlPntcInJ3QHNlbGZcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBtaW50ZWQgZG93bndhcmQtb25seSBwZXIgwqc4LjE1OyB0aGUgYXBwIG5ldmVyIGhhZCBhIGxlZ2l0aW1hdGUgcmVhc29uIHRvIHJlYWRcXG5pdHMgb3duIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi5ob2xkb3V0L1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIuKVwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJHYXRlIHRlc3QgRy1IUk0tMyBhc3NlcnRzIHRoYXQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicmVhZGRpclwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJhbmQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZXhpc3RzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJzdGF0XCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBhdCBldmVyeSBsZXZlbCB0aGUgYXNzaXN0YW50XFxuY2FuIHJlYWNoIG5ldmVyIHJldmVhbCBhIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi5ob2xkb3V0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBlbnRyeS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwic2VjLTMtMVwiIGRhdGEtc2x1Zz1cIjMxLXRoZS1zY29wZWRmcy1maWx0ZXItbXVzdC1iZS1kZW55LWJ5LWRlZmF1bHQtYXQtdGhlLW1ldGhvZC1sZXZlbC1ub3JtYXRpdmUtcmV2aWV3LTItY29kZS1nYXAtYWJcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy0zLTFcIiAvPntcIjMuMSBUaGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic2NvcGVkRnNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGZpbHRlciBtdXN0IGJlIGRlbnktYnktZGVmYXVsdCBhdCB0aGUgbWV0aG9kIGxldmVsICBcIn08X2NvbXBvbmVudHMuZW0+e1wiKG5vcm1hdGl2ZSDigJQgcmV2aWV3LTIgQ09ERS1HQVAgQS9CKVwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJSZXZpZXctMiBmb3VuZCB0aGUgcmVhZGRpciBjbG9zdXJlIG5lY2Vzc2FyeSBidXQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJub3Qgc3VmZmljaWVudFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgYmVjYXVzZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmaWx0ZXJlZEZzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIlxcbnRvZGF5IGZpbHRlcnMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJvbmx5XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIG1ldGhvZHMgaW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiV1JJVEVfTUVUSE9EUyDiiKogUEFUSF9BUkdTXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjsgYW55IFwifTxfY29tcG9uZW50cy5lbT57XCJvdGhlclwifTwvX2NvbXBvbmVudHMuZW0+e1wiIG1ldGhvZCByZXR1cm5zIHRoZVxcbnJhdyBiYWNraW5nIG1ldGhvZCBib3VuZCB0byB0aGUgdW4tY2xhc3NpZmllZCBwYXRoIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJiaW5kKHRhcmdldClcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKS4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZXhpc3RzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJleGlzdHNTeW5jXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpc1xcbm5vdCBpbiB0aGF0IHNldCwgc28gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZXhpc3RzKCcvLmhvbGRvdXQv4oCmJylcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHJlYWNoZXMgdGhlIHJhdyBiYWNrZW5kIGFuZCByZXR1cm5zIFwifTxfY29tcG9uZW50cy5jb2RlPntcInRydWVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCBhIGxpdmVcXG5leGlzdGVuY2Ugb3JhY2xlIHRoYXQgZGVmZWF0cyB0aGUgd2hvbGUgcG9pbnQsIGFuZCBpZiB0aGUgWmVuRlMgYmFja2VuZCBleHBvc2VzIGEgcGF0aC10YWtpbmdcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJvcGVuRmlsZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicmVhZGxpbmtcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChhbHNvIHVubW9kZWxlZCkgdGhlIHNhbWUgcGFzc3Rocm91Z2ggeWllbGRzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZmlsZSBieXRlc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIi4gVHdvXFxubWFuZGF0b3J5IGNoYW5nZXMsIGJvdGggXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJmYWlsLWNsb3NlZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIjpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkRlbnktYnktZGVmYXVsdDpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYW55IHBhdGgtYmVhcmluZyBvciB1bm1vZGVsZWQgZnMgbWV0aG9kIG11c3QgYmUgY2xhc3NpZmllZCAoYW5kIHRocm93XFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRU5PRU5UXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJFQUNDRVNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGZvciBhIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm5vbmVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHBhdGgpIG9yIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicmVqZWN0ZWQgb3V0cmlnaHRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIG5ldmVyIFwifTxfY29tcG9uZW50cy5jb2RlPntcImJpbmQodGFyZ2V0KVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgb24gYW5cXG51bi1jbGFzc2lmaWVkIHBhdGguIFRoZSBhbGxvdy1saXN0IG9mIHBhc3MtdGhyb3VnaCBtZXRob2RzIG11c3QgYmUgZXhwbGljaXQgYW5kIGV4Y2x1ZGVcXG5ldmVyeXRoaW5nIHRoYXQgdGFrZXMgb3IgbGVha3MgYSBwYXRoIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJleGlzdHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzdGF0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wib3BlbkZpbGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyZWFkbGlua1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIOKApikuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJOZXZlciBmYWlsIG9wZW4gb24gYW4gZW1wdHkgcnVsZS1zZXQ6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5jb2RlPntcImZpbHRlcmVkRnNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGN1cnJlbnRseSBwdXNoZXMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wie3N1YnRyZWU6Jy8nLCBtb2RlOidydyd9XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBmb3IgYW4gZW1wdHkgcnVsZS1zZXQgYW5kIHNob3J0LWNpcmN1aXRzIGFsbCBmaWx0ZXJpbmcgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIndob2xlUndcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKS4gVGhlIGFzc2lzdGFudFxcbnJlYWxtIG11c3QgbmV2ZXIgYmUgbWludGVkIHdpdGggYW4gZW1wdHkgb3IgYmFyZS1yb290IHJ1bGUtc2V0LCBhbmQgdGhlIHByaW1pdGl2ZSBtdXN0IHRyZWF0XFxuYW4gZW1wdHkgcnVsZS1zZXQgYXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJkZW55LWFsbFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgbm90IGFsbG93LWFsbCDigJQgc28gYSBzaW5nbGUgbWlzLW1pbnQgY2Fubm90IGV4cG9zZVxcblwifTxfY29tcG9uZW50cy5jb2RlPntcIi5ob2xkb3V0L1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZXNlIGFyZSBnYXRlIHRlc3RzIEctSFJNLTIgKGV4dGVuZGVkIHRvIFwifTxfY29tcG9uZW50cy5jb2RlPntcImV4aXN0c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3RhdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wib3BlbkZpbGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSBhbmQgYSBuZXcgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJHLUhSTS03XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiXFxuKGVtcHR5IHJ1bGUtc2V0IOKGkiBkZW55LWFsbCkuIFVudGlsIHRoZXkgaG9sZCwgRDkgZG9lcyBub3QgZXZlbiBjbG9zZSB0aGUgbWV0YWRhdGEgbGVhay5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTRcIiBkYXRhLXNsdWc9XCI0LXdoZW4taXMtdGhlLWFzc2lzdGFudC1pbi10aGUtcmVkYWN0ZWQtdmlldy10aGUtbW9kZS1pcy1ob3N0LWRyaXZlbi1hbmQtdW4tZXNjYXBhYmxlLW5vcm1hdGl2ZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTRcIiAvPntcIjQuIFdoZW4gaXMgdGhlIGFzc2lzdGFudCBpbiB0aGUgcmVkYWN0ZWQgdmlldz8g4oCUIHRoZSBtb2RlIGlzIGhvc3QtZHJpdmVuIGFuZCB1bi1lc2NhcGFibGUgIFwifTxfY29tcG9uZW50cy5lbT57XCIobm9ybWF0aXZlKVwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgZW5mb3JjZW1lbnQgaXMgb25seSByZWFsIGlmIHRoZSBhc3Npc3RhbnQgY2Fubm90IGZsaXAgYmFjayB0byBhbiB1bnJlZGFjdGVkIHZpZXdcXG5taWQtaW5mZXJlbmNlLiBUaHJlZSBydWxlczpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlRoZSByZWRhY3RlZCB2aWV3IGlzIHRoZSBhc3Npc3RhbnQgcmVhbG0ncyBcIn08X2NvbXBvbmVudHMuZW0+e1wic3RhbmRpbmdcIn08L19jb21wb25lbnRzLmVtPntcIiBtb3VudCBncmFudCwgbm90IGEgbW9kZSBpdFxcbmVudGVycy5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhlIGFzc2lzdGFudCByZWFsbSBpcyBcIn08X2NvbXBvbmVudHMuZW0+e1wiYWx3YXlzXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgbWludGVkIHdpdGggdGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi5ob2xkb3V0L1wifTwvX2NvbXBvbmVudHMuY29kZT57XCItZXhjbHVkaW5nIHJ1bGUtc2V0O1xcbnRoZXJlIGlzIG5vIHVuLXJlZGFjdGVkIHByb2ZpbGUgdG8gZXNjYXBlIHRvLiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyd0BzZWxmXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpcyBkZWZpbmVkLCBmb3IgdGhpcyByZWFsbSwgYXMgdGhlXFxuZW51bWVyYXRlZCBhdXRob3Jpbmcgc3VidHJlZXMg4oCUIGZ1bGwgc3RvcC4gKEgzJ3MgZXJyb3Igd2FzIHRyZWF0aW5nIFwifTxfY29tcG9uZW50cy5jb2RlPntcInJ3QHNlbGZcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFzXFxud2hvbGUtZG9jdW1lbnQ7IEQ5IGRlZmluZXMgaXQgYXMgdGhlIGF1dGhvcmluZyBzdWJ0cmVlcy4pXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgc3BsaXQgaXMgaG9zdC1wZXJmb3JtZWQgYW5kIHByZS1hZ2VudC5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhlIGhvc3QgY2FydmVzIHRyYWluL2hvbGRvdXQgYXQgaW5mZXJlbmNlXFxuc3RhcnQgZnJvbSBkYXRhIHRoZSBhc3Npc3RhbnQgaGFzIFwifTxfY29tcG9uZW50cy5lbT57XCJub3QgeWV0XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgcmVjZWl2ZWQ7IHRoZSBhc3Npc3RhbnQncyBpbmZlcmVuY2UgaW5wdXQgaXNcXG50aGUgdHJhaW5pbmcgc3BsaXQgb25seSAowqcxKS4gVGhlcmUgaXMgbm8gd2luZG93IGluIHdoaWNoIHRoZSBhZ2VudCBoZWxkIHRoZSBmdWxsIHNldC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlJlLWRlcml2YXRpb24gaXMgaG9zdC1jb250cm9sbGVkLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBSZS1zcGxpdHRpbmcgKGEgbmV3IGluZmVyZW5jZSBydW4pIHJlLXJhbmRvbWl6ZXNcXG5ob3N0LXNpZGU7IHRoZSBhc3Npc3RhbnQgY2Fubm90IHJlcXVlc3QgXFxcInRoZSBob2xkb3V0IHJvd3NcXFwiIHRocm91Z2ggYW55IEFQSSDigJQgdGhlcmUgaXMgbm9cXG5tZXRob2QgdGhhdCByZXR1cm5zIHRoZW0sIGFuZCB0aGUgZml4dHVyZSBwYXRoIGlzIHVucmVhZGFibGUuIFRoZSBvbmx5IHRoaW5nIHRoYXQgZXZlclxcbmNvbnN1bWVzIHRoZW0gaXMgZW5naW5lIHRlc3QtY2VsbCBldmFsdWF0aW9uLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlRoZSBwcmUtYWdlbnQtc3BsaXQgcHJlY29uZGl0aW9uLCBhbmQgd2hlbiBpdCBmYWlscyAocmV2aWV3LTIgRDktNCDigJQgcmVzb2x2aW5nIHRoZSBvbGQgwqc0LjJcXG52cyBPUS0yIGNvbnRyYWRpY3Rpb24pLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBSdWxlIDIgaG9sZHMgXCJ9PF9jb21wb25lbnRzLmVtPntcIm9ubHlcIn08L19jb21wb25lbnRzLmVtPntcIiB3aGVuIHRoZSBob3N0IGNvbnRyb2xzIHRoZSBkYXRhIGJlZm9yZSB0aGUgYWdlbnRcXG5zZWVzIGl0LiBJdCBkb2VzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibm90XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGhvbGQgaW4gdHdvIG1haW5saW5lIGNhc2VzLCBhbmQgdGhlIGRlc2lnbiBtdXN0IGRldGVjdCB0aGVtIHJhdGhlciB0aGFuXFxuYXNzZXJ0IGEgZ3VhcmFudGVlIGl0IGxhY2tzOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQ2FwdHVyZS10aGVuLWluZmVyOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB0aGUgYXNzaXN0YW50J3MgZml4dHVyZS1jYXB0dXJlIGZyZWV6ZSAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQVJDSElURUNUVVJFX1BMQU4gwqc1LjRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKVxcbnJlYWRzIGZlZWQgcm93cyBpbnRvIGFnZW50LXJlYWRhYmxlIFwifTxfY29tcG9uZW50cy5jb2RlPntcImZpeHR1cmVzL1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIuIElmIGEgZm9ybXVsYSBpcyBsYXRlciBpbmZlcnJlZCBvdmVyIGEgZmVlZCB0aGVcXG5hZ2VudCBhbHJlYWR5IGNhcHR1cmVkLCB0aGUgXFxcImhvbGRvdXRcXFwiIGlzIGEgc3Vic2V0IG9mIGFscmVhZHktc2VlbiByb3dzIOKAlCBubyBlbmZvcmNlYWJsZSBzcGxpdC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlN0YXRpYyBmZWVkcyAoYW4gdXBsb2FkZWQgQ1NWKTpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdGhlcmUgYXJlIG5vIGZyZXNoIHJvd3MgdG8gd2l0aGhvbGQ7IG9uY2UgdGhlIGFnZW50IGNhblxcbnJlYWQgKG9yIGNhcHR1cmUpIHRoZSBkYXRhc2V0LCBob2xkb3V0IGlzIHVuZW5mb3JjZWFibGUgXCJ9PF9jb21wb25lbnRzLmVtPntcImluIHByaW5jaXBsZVwifTwvX2NvbXBvbmVudHMuZW0+e1wiLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlJ1bGU6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHRoZSBob3N0IHRyYWNrcyB3aGV0aGVyIHRoZSBhZ2VudCBoYXMgaGFkIGEgcmVhZCBwYXRoIHRvIGEgZmVlZCdzIHJvd3M7IGlmIGl0IGhhcywgYW5cXG5pbmZlcmVuY2Ugb3ZlciB0aGF0IGZlZWQgaXMgbWFya2VkIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibm8tZW5mb3JjZWFibGUtaG9sZG91dFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgdGhlIGVtaXR0ZWQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3BlY2lmaWNhdGlvblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdGVzdFxcbmlzIGZsYWdnZWQgYWNjb3JkaW5nbHksIGFuZCB0aGUgcmV2aWV3IHN1cmZhY2UgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJkb3duLXdlaWdodHMgaXQgdG8gemVybyBjb3JyZWN0bmVzcyBjcmVkaXRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCJcXG4oaXQgbWF5IHN0aWxsIHNlcnZlIGFzIGEgcmVncmVzc2lvbiB0cmlwd2lyZSkuIEhvbGRvdXQgY3JlZGl0IGlzIGdyYW50ZWQgXCJ9PF9jb21wb25lbnRzLmVtPntcIm9ubHlcIn08L19jb21wb25lbnRzLmVtPntcIiBmb3IgYVxcbmhvc3QtZmV0Y2hlZCwgbmV2ZXItYWdlbnQtc2VlbiBzcGxpdC4gVGhpcyBtYWtlcyDCpzQuMidzIGd1YXJhbnRlZSBjb25kaXRpb25hbCBhbmQgaG9uZXN0IGluc3RlYWRcXG5vZiBhYnNvbHV0ZSDigJQgYW5kIGl0IGlzIHdoeSB0aGUgY29ycmVjdG5lc3Mgd2VpZ2h0IGxpdmVzIGluIHRoZSBvcmFjbGUtZnJlZSBsZWdzICjCpzUuMyksIHdoaWNoIGRvXFxubm90IGRlcGVuZCBvbiBhbnkgcHJlLWFnZW50IHdpbmRvdy5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwic2VjLTUtMVwiIGRhdGEtc2x1Zz1cIjUxLXRoZS10ZXN0LW9yYWNsZS1jaGFubmVsLXdoeS1ob2xkb3V0LWlzLWEtdHJpcHdpcmUtbm90LWEtcHJvb2Ytbm9ybWF0aXZlLXRoZS1sb2FkLWJlYXJpbmctcmVzaWR1YWxcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy01LTFcIiAvPntcIjUuMSBUaGUgdGVzdC1vcmFjbGUgY2hhbm5lbCDigJQgd2h5IGhvbGRvdXQgaXMgYSB0cmlwd2lyZSwgbm90IGEgcHJvb2YgIFwifTxfY29tcG9uZW50cy5lbT57XCIobm9ybWF0aXZlIOKAlCB0aGUgbG9hZC1iZWFyaW5nIHJlc2lkdWFsKVwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJQYXRoIHNlcGFyYXRpb24gZ3VhcmRzIHRoZSBkb29yIHRoZSBhZ2VudCBkb2VzIG5vdCBuZWVkLiBUaGUgYWdlbnQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJhdXRob3JzIHRoZSB0ZXN0IGNlbGxcXG50aGF0IHJ1bnMgb3ZlciB0aGUgaG9sZG91dFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW5wdXRzOiB7IHJvd3M6IFxcXCJmaXh0dXJlcy5vcmRlcnNfaG9sZG91dFxcXCIgfVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGEgc3ViamVjdCBmb3JtdWxhXFxuaXQgd3JvdGUpIGFuZCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInJlYWRzIHRoYXQgY2VsbCdzIHJlc3VsdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgYW5kIGV2ZXJ5IHJlc3VsdCBzdXJmYWNlIGlzIGEgcmVhZCBvZiB0aGUgaGVsZC1vdXRcXG5yb3dzOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVHJhY2UtcmVwbGF5XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJBUkNISVRFQ1RVUkVfUExBTiDCpzQuM1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpIHJlY29yZHMgXFxcImRlY2xhcmVkIGlucHV0cyDihpIgaW50ZXJtZWRpYXRlcyDihpJcXG5vdXRwdXRcXFwiIGFzIHRoZSBwcmltYXJ5IGFnZW50LWZhY2luZyBkZWJ1Z2dpbmcgc3VyZmFjZS4gQSB0ZXN0IGNlbGwncyBkZWNsYXJlZCBpbnB1dHMgb3ZlclxcbmhvbGRvdXQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJhcmUgdGhlIGhlbGQtb3V0IHJvd3NcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIsIGhhbmRlZCB0byB0aGUgYWdlbnQgdmVyYmF0aW0uIFRoaXMgaXMgYSBcIn08X2NvbXBvbmVudHMuZW0+e1wibGl0ZXJhbCByZWFkXCJ9PC9fY29tcG9uZW50cy5lbT57XCIuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJGYWlsdXJlIGRpYWdub3N0aWNzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChcXFwiZXhwZWN0ZWQgMCwgZ290IDQ4MTIwXFxcIikgbGVhayB0aGUgZXhhY3QgaGVsZC1vdXQgYWdncmVnYXRlIGluIG9uZVxcbnJ1bi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlBhc3MvZmFpbCBiaXNlY3Rpb246XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5jb2RlPntcImV4cGVjdENsb3NlKGhvbGRvdXRfYWdncmVnYXRlLCBYLCB7cmVsOjFlLTZ9KVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaXMgYSBjb21wYXJhdG9yXFxub3JhY2xlOyB0aGUgYWdlbnQgcGFja3MgaHVuZHJlZHMgb2YgYXNzZXJ0aW9ucyBpbnRvIG9uZSBmdWxsLXdvcmtib29rIHJ1biAodGVzdHMgYXJlIGNlbGxzLFxcbm9uZSB0b29sIGNhbGwpIGFuZCBiaXNlY3RzIGVhY2ggdmFsdWUgb3V0LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgXFxcIk0zLXRhaW50ZWQgYW5kIHN0YXJ2ZWRcXFwiIGJhY2tzdG9wICjCpzIpIGRvZXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJub3RcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgY2xvc2UgdGhpczogdGhlIGVuZ2luZSdzIGVncmVzc1xcbnN0YXJ2YXRpb24gc3RvcHMgaG9sZG91dCBsZWF2aW5nIFwifTxfY29tcG9uZW50cy5lbT57XCJvdmVyIHRoZSBuZXR3b3JrXCJ9PC9fY29tcG9uZW50cy5lbT57XCIsIGJ1dCB0aGUgcmVzdWx0IG11c3QgZmxvdyBlbmdpbmUg4oaSIGhvc3Qg4oaSXFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJhc3Npc3RhbnQgcmV2aWV3IHN1cmZhY2VcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIkFSQ0hJVEVDVFVSRV9QTEFOIMKnOC4zXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiByZXF1aXJlcyBzaG93aW5nIFxcXCJmb3JtdWxhICsgdGVzdHMgK1xcbnJlc3VsdFxcXCIpLiBBbmQgZm9yIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiY2xlYW4tdGllciBmaXh0dXJlcyDigJQgdGhlIG1haW5saW5lIHNoYXJlYWJsZS13b3JrYm9vayBjYXNlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCB0aGUgdHJhY2UgaXNcXG5ub3QgZXZlbiB0aWVyLXN1cHByZXNzZWQuIFRoZXJlIGlzIGEgZGlsZW1tYSB0aGUgZGVzaWduIGNhbm5vdCBlc2NhcGU6IGlmIHJlc3VsdHMgXCJ9PF9jb21wb25lbnRzLmVtPntcIndlcmVcIn08L19jb21wb25lbnRzLmVtPntcIlxcbnRhaW50ZWQgZW5vdWdoIHRvIHN1cHByZXNzLCByZWFkaW5nIHRoZW0gd291bGQgdGFpbnQgdGhlIGFzc2lzdGFudCBldmVyeSBhdXRob3JpbmcgaXRlcmF0aW9uXFxuYW5kIGJyZWFrIHRoZSBsb29wOyBpZiBub3QsIHRoZSBvcmFjbGUgaXMgb3Blbi4gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJEOSBkb2VzIG5vdCBjbG9zZSB0aGUgdGVzdC1vcmFjbGUgY2hhbm5lbCxcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCJcXG5hbmQgYSBiYW5kd2lkdGgtYm91bmRlZCBvdXRwdXQtY2hhbm5lbCBwb2xpY3kgb3ZlciBhbGwgdGVzdCByZXN1bHRzL3RyYWNlcy9kaWFnbm9zdGljcyB3YXNcXG5jb25zaWRlcmVkIGFuZCByZWplY3RlZCAoYmlnZ2VyIHRoYW4gcGF0aCBzZXBhcmF0aW9uLCBzdGlsbCBiZWF0ZW4gYnkgwqc1J3MgcmVjb25zdHJ1Y3Rpb24pLlxcbkhlbmNlOiBob2xkb3V0IGlzIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ0cmlwd2lyZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoYSBsYXRlciBlZGl0IHRoYXQgYnJlYWtzIGEgaGVsZC1vdXQgcm93IGlzIGEgdXNlZnVsXFxucmVncmVzc2lvbiBzaWduYWwpLCBuZXZlciBhIGNlcnRpZmljYXRpb24uXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cInNlYy01LTJcIiBkYXRhLXNsdWc9XCI1Mi1yZWNvbnN0cnVjdGlvbi1pcy1jZW50cmFsLWZvci10aGUtdGFyZ2V0LXdvcmtsb2FkLW5vcm1hdGl2ZS1ob25lc3R5XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtNS0yXCIgLz57XCI1LjIgUmVjb25zdHJ1Y3Rpb24gaXMgY2VudHJhbCBmb3IgdGhlIHRhcmdldCB3b3JrbG9hZCAgXCJ9PF9jb21wb25lbnRzLmVtPntcIihub3JtYXRpdmUg4oCUIGhvbmVzdHkpXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSBlYXJsaWVyIGRyYWZ0IGZpbGVkIHJlY29uc3RydWN0aW9uIGFzIGFuIGFkdmVyc2FyaWFsIGNvcm5lci4gSXQgaXMgdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiY2VudGVyXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiOiBmb3IgdGhlXFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJhZmZpbmUvYWdncmVnYXRlL2xvb2t1cCBmb3JtdWxhcyBSZWNrb25lciBleHBsaWNpdGx5IHRhcmdldHNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIkFSQ0hJVEVDVFVSRV9QTEFOIMKnNy4xXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIlxcbnNpbmdsZSBhZ2dyZWdhdGVzOyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzdW1cIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcImpvaW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcImdyb3VwQnlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSwgdGhlIHRyYWluaW5nIHNwbGl0IFwifTxfY29tcG9uZW50cy5lbT57XCJkZXRlcm1pbmVzXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgdGhlIGhvbGRvdXQgb3V0Y29tZVxcbmJ5IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wib3JkaW5hcnkgZml0dGluZ1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgbm8gYWR2ZXJzYXJpYWwgbW9kZWxpbmcsIG5vIGRpc3RyaWJ1dGlvbiB3b3JrLiBUd28gdHJhaW5pbmcgcm93cyBmaXggYVxcbmxpbmVhciBmb3JtdWxhOyB0aGUgaG9sZG91dCBpcyBmdWxseSBwcmVkaWN0ZWQuIEhvbGRvdXQgaGFzIHRlZXRoIG9ubHkgb25cXG5ub25saW5lYXIvcmVnaW1lLXNoaWZ0IGZvcm11bGFzLCB3aGljaCBhcmUgXCJ9PF9jb21wb25lbnRzLmVtPntcIm5vdFwifTwvX2NvbXBvbmVudHMuZW0+e1wiIHRoZSBzY29wZWQgd29ya2xvYWQuIFNvIGV2ZW4gYSBcIn08X2NvbXBvbmVudHMuZW0+e1wicGVyZmVjdGx5XFxuc2VhbGVkXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgbWVjaGFuaXNtIHByb3ZlcyB+MCBiaXRzIGZvciB0aGUgZG9taW5hbnQgc2hhcGUuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cInNlYy01LTNcIiBkYXRhLXNsdWc9XCI1My10aGUtaG9uZXN0LWNsYWltLW5vcm1hdGl2ZS1pbnRlbnRcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy01LTNcIiAvPntcIjUuMyBUaGUgaG9uZXN0IGNsYWltICBcIn08X2NvbXBvbmVudHMuZW0+e1wiKG5vcm1hdGl2ZSBpbnRlbnQpXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkQ5IGNsb3NlcyB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ0cml2aWFsXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGxlYWtzIOKAlCB0aGUgZGlyZWN0IFwifTxfY29tcG9uZW50cy5jb2RlPntcInJlYWRGaWxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoSDMpIGFuZCB0aGUgbWV0YWRhdGEtcHJvYmVcXG4oXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZXhpc3RzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJzdGF0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgwqczICsgdGhlIGRlbnktYnktZGVmYXVsdCBydWxlIGJlbG93KS4gSXQgZG9lcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBjbG9zZSB0aGUgdGVzdC1vcmFjbGVcXG5jaGFubmVsICjCpzUuMSkgYW5kIGFkZHMgbGl0dGxlIGZvciBsb3ctcGFyYW1ldGVyIGZvcm11bGFzICjCpzUuMikuIFRoZXJlZm9yZSBob2xkb3V0IGlzIGFcXG5iZXN0LWVmZm9ydCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInRyaXB3aXJlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCB0aGUgcmV2aWV3IHN1cmZhY2UgbXVzdCBub3QgcHJvbW90ZSBhIGhvbGRvdXQtb25seSBjZWxsIHRvXFxuXFxcInZhbGlkYXRlZCxcXFwiIGFuZCB0aGUgbG9hZC1iZWFyaW5nIGNvcnJlY3RuZXNzIHNpZ25hbCBpcyB0aGUgb3JhY2xlLWZyZWUgbGVnc1xcbihtZXRhbW9ycGhpYy9wcm9wZXJ0eS9tdXRhdGlvbiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQVJDSElURUNUVVJFX1BMQU4gwqc2XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiksIHdoaWNoIG5lZWQgbm8gaGlkZGVuIGRhdGEgYW5kIG5vIG9yYWNsZS5cXG5CbGluZCBzZWNvbmQtYWdlbnQgYXV0aG9yaW5nIGNhcnJpZXMgdGhlIGFkZGl0aW9uYWwgRDktMyBsaW1pdCAowqc3KTogYWdlbnQtMSBhdXRob3JzIHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJkb2NcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxuYWdlbnQtMiByZWFkcywgc28gYSBjb21wbGV0ZSBpbnRlbnQgb3Zlci1kZXRlcm1pbmVzIHRoZSBpbXBsZW1lbnRhdGlvbiBhbmQgXFxcImluZGVwZW5kZW5jZVxcXCIgaXMgYVxcbndlYWsgc2lnbmFsLiBBIGNvbXByb21pc2VkIFwifTxfY29tcG9uZW50cy5lbT57XCJob3N0XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgaXMgb3V0IG9mIHNjb3BlIChpdCBtaW50cyB0aGUgZ3JhbnRzKTsgRDkgZGVmZW5kcyBhZ2FpbnN0IGFuXFxub3Zlci1lYWdlciBvciBjb21wcm9taXNlZCBcIn08X2NvbXBvbmVudHMuZW0+e1wiYXNzaXN0YW50XCJ9PC9fY29tcG9uZW50cy5lbT57XCIsIGFuZCBvbmx5IGFnYWluc3QgdGhlIHRyaXZpYWwgcmVhZC5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTZcIiBkYXRhLXNsdWc9XCI2LWxvYWQtYmVhcmluZy1hc3N1bXB0aW9ucy1jb2RlLWFuY2hvcnNcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy02XCIgLz57XCI2LiBMb2FkLWJlYXJpbmcgYXNzdW1wdGlvbnMgJiBjb2RlIGFuY2hvcnNcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cImRlcGVuZHMtb24tdG9kYXktdmVyaWZpZWQtYWdhaW5zdC1jb2RlLTIwMjYtMDctMDktcmUtY2hlY2tlZC1ieS1zY3JpcHRzY2hlY2stc3BlYy1hbmNob3JzbWpzXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJkZXBlbmRzLW9uLXRvZGF5LXZlcmlmaWVkLWFnYWluc3QtY29kZS0yMDI2LTA3LTA5LXJlLWNoZWNrZWQtYnktc2NyaXB0c2NoZWNrLXNwZWMtYW5jaG9yc21qc1wiIC8+e1wiRGVwZW5kcy1vbi10b2RheSAodmVyaWZpZWQgYWdhaW5zdCBjb2RlIDIwMjYtMDctMDk7IHJlLWNoZWNrZWQgYnkgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic2NyaXB0cy9jaGVjay1zcGVjLWFuY2hvcnMubWpzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIilcIn08L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy50YWJsZT48X2NvbXBvbmVudHMudGhlYWQ+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50aD57XCJBc3N1bXB0aW9uIChleGlzdGluZyBiZWhhdmlvciB0aGUgZGVzaWduIHJlc3RzIG9uKVwifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIkFuY2hvciAocmVwby1yZWxhdGl2ZSBmaWxlKVwifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIlRva2VuIChncmVwLXN0YWJsZSlcIn08L19jb21wb25lbnRzLnRoPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudGJvZHk+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJBIG1vdW50IGdyYW50IGlzIGEgcnVsZS1zZXQgb2YgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wie3N1YnRyZWUsIG1vZGV9XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjsgYSBwYXRoIG91dHNpZGUgYWxsIHJ1bGVzIGlzIHVucmVhY2hhYmxlXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiaW1tZWRpYXRlbHktcnVuLXNpdGUtbWFpbi9zcmMvZmlsZXN5c3RlbS9zY29wZWRGcy50c1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJjbGFzc2lmeVBhdGhcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiQW4gYW5jZXN0b3IgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicmVhZGRpclwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaXMgc3ludGhlc2l6ZWQgdG8gb25seSB0aGUgXCJ9PF9jb21wb25lbnRzLmVtPntcImdyYW50ZWRcIn08L19jb21wb25lbnRzLmVtPntcIiBjaGlsZHJlbiAodGhlIMKnMyBsZWFrIHN1cmZhY2UpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiaW1tZWRpYXRlbHktcnVuLXNpdGUtbWFpbi9zcmMvZmlsZXN5c3RlbS9zY29wZWRGcy50c1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJzeW50aGVzaXplZENoaWxkcmVuXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkEgaGVsZCBncmFudCBpcyBuYXJyb3dlZCBkb3dud2FyZC1vbmx5IHdoZW4gZGVsZWdhdGVkIChjaHJvb3QgaW5zaWRlIHRoZSBjYWxsZXIncyBzdWJ0cmVlOyBlc2NhcGUg4oaSIGZhaWwtY2xvc2VkKVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcImltbWVkaWF0ZWx5LXJ1bi1zaXRlLW1haW4vc3JjL2VkaXRvci90YXNrL2F0dGVudWF0ZURlbHRhLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcIkRlbGVnYXRhYmxlTW91bnRcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiVGhlIGFzc2lzdGFudCByZWFkcyB0aGUgbW91bnQgdmlhIHRoZSBTREsgZnMgcG9ydCAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicmVhZEZpbGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSDigJQgdGhlIHN1cmZhY2UgRDkgbmFycm93c1wifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcImltbWVkaWF0ZWx5LXJ1bi1zZGsvc3JjL2ZzLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcInNhbmRib3hGc1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJTZWNyZXQgdmFsdWVzIGFyZSBkZWNsYXJlZC13aGVyZSAvIGhvc3QtcmVzb2x2ZWQsIG5ldmVyIHJlYWQgYnkgdGhlIGFwcCAodGhlIMKnMCBhbmFsb2d1ZSlcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJpbW1lZGlhdGVseS1ydW4tc2l0ZS1tYWluL3NyYy9yZWdpc3RyeS9uZXRGZXRjaFBvbGljeS50c1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJpbmplY3RTZWNyZXRcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGJvZHk+PC9fY29tcG9uZW50cy50YWJsZT57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCJtdXN0LWVzdGFibGlzaC1uZXctaW52YXJpYW50cy10aGUtaW1wbGVtZW50YXRpb24tY3JlYXRlc1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwibXVzdC1lc3RhYmxpc2gtbmV3LWludmFyaWFudHMtdGhlLWltcGxlbWVudGF0aW9uLWNyZWF0ZXNcIiAvPntcIk11c3QtZXN0YWJsaXNoIChuZXcgaW52YXJpYW50cyB0aGUgaW1wbGVtZW50YXRpb24gY3JlYXRlcylcIn08L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy50YWJsZT48X2NvbXBvbmVudHMudGhlYWQ+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50aD57XCJOZXcgaW52YXJpYW50XCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGg+e1wiUHJvdmVuIGJ5IChnYXRlIHRlc3QpXCJ9PC9fY29tcG9uZW50cy50aD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGhlYWQ+PF9jb21wb25lbnRzLnRib2R5PjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiVGhlIGFzc2lzdGFudCByZWFsbSdzIFwifTxfY29tcG9uZW50cy5jb2RlPntcInJ3QHNlbGZcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGlzIHRoZSBlbnVtZXJhdGVkIGF1dGhvcmluZyBzdWJ0cmVlcywgbmV2ZXIgd2hvbGUtcm9vdFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIkctSFJNLTE6IHRoZSBhc3Npc3RhbnQncyBtaW50ZWQgcnVsZS1zZXQgY29udGFpbnMgbm8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wie3N1YnRyZWU6Jy8nfVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYW5kIGV4Y2x1ZGVzIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi5ob2xkb3V0L1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJBIGhlbGQtb3V0IGZpeHR1cmUgaXMgdW5yZWFkYWJsZSBBTkQgdW4tcHJvYmVhYmxlIGJ5IHRoZSBhc3Npc3RhbnRcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJHLUhSTS0yOiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyZWFkRmlsZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZXhpc3RzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJzdGF0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJvcGVuRmlsZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIoJy5ob2xkb3V0L+KApicpIChhbmQgYW55IHRyYXZlcnNhbCkgZnJvbSB0aGUgYXNzaXN0YW50IGFsbCByZXR1cm4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibm9uZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRU5PRU5UXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB1bmRlciBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyd0BzZWxmXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAocmV2aWV3LTIgQ09ERS1HQVAgQSlcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJIb2xkb3V0IGV4aXN0ZW5jZS9uYW1lIGRvZXMgbm90IGxlYWsgdmlhIHJlYWRkaXIgT1IgbWV0YWRhdGFcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJHLUhSTS0zOiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyZWFkZGlyXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImFuZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJleGlzdHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcInN0YXRcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGF0IGV2ZXJ5IGFzc2lzdGFudC1yZWFjaGFibGUgbGV2ZWwgbmV2ZXIgcmV2ZWFsIGEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLmhvbGRvdXRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGVudHJ5XCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiVGhlIGVuZ2luZSByZXNvbHZlcyBob2xkb3V0IGZvciB0ZXN0IGNlbGxzIHdpdGhvdXQgYW4gYXNzaXN0YW50LXZpc2libGUgcGF0aFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIkctSFJNLTQ6IGEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3BlY2lmaWNhdGlvblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdGVzdCBjZWxsIG92ZXIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZml4dHVyZXMub3JkZXJzX2hvbGRvdXRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGV2YWx1YXRlcyBpbiB0aGUgZW5naW5lOyB0aGUgc2FtZSBuYW1lIHJlYWQgZnJvbSB0aGUgYXNzaXN0YW50IGZhaWxzXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiSG9sZG91dCBjcmVkaXQgb25seSBmb3IgYSBob3N0LWZldGNoZWQsIG5ldmVyLWFnZW50LXNlZW4gc3BsaXRcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJHLUhSTS01OiBhbiBpbmZlcmVuY2Ugb3ZlciBhIGZlZWQgdGhlIGFnZW50IGhhcyByZWFkL2NhcHR1cmVkIGlzIG1hcmtlZCBuby1lbmZvcmNlYWJsZS1ob2xkb3V0IGFuZCBkb3duLXdlaWdodGVkIHRvIHplcm8gY29ycmVjdG5lc3MgY3JlZGl0IChyZXZpZXctMiBEOS00KVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkJsaW5kIHNlY29uZC1hZ2VudCBzY29wZSBpcyBpbnRlbnQtb25seVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIkctSFJNLTY6IHRoZSBzZWNvbmQgYWdlbnQgY2FuIHJlYWQgdGhlIHRhcmdldCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJkb2NcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGJ1dCBub3QgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wid29ya3NoZWV0cy9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG9yIFwifTxfY29tcG9uZW50cy5jb2RlPntcImZpeHR1cmVzL1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJUaGUgZnMgZmlsdGVyIGlzIGRlbnktYnktZGVmYXVsdDsgYW4gZW1wdHkgcnVsZS1zZXQgZGVuaWVzIGFsbFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIkctSFJNLTc6IGFuIHVubW9kZWxlZCBwYXRoLWJlYXJpbmcgbWV0aG9kIHRocm93czsgYW4gZW1wdHkvbWlzLW1pbnRlZCBydWxlLXNldCBleHBvc2VzIG5vdGhpbmcgKHJldmlldy0yIENPREUtR0FQIEIpXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiSG9sZG91dCBkb2VzIG5vdCBwcm9tb3RlIGEgY2VsbCB0byBcXFwidmFsaWRhdGVkXFxcIlwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIkctSFJNLTg6IGEgY2VsbCB3aG9zZSBvbmx5IG5vbi1jaGFyYWN0ZXJpemF0aW9uIGNvdmVyYWdlIGlzIGEgaG9sZG91dCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcGVjaWZpY2F0aW9uXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB0ZXN0IHJlbmRlcnMgYXMgXCJ9PF9jb21wb25lbnRzLmVtPntcIm5vdCB2YWxpZGF0ZWRcIn08L19jb21wb25lbnRzLmVtPntcIjsgXFxcInZhbGlkYXRlZFxcXCIgcmVxdWlyZXMgYSBtZXRhbW9ycGhpYy9wcm9wZXJ0eSBsZWcgb3IgYSBwYXNzaW5nIG11dGF0aW9uIHNjb3JlIChyZXZpZXctMiBEOS0xKVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRib2R5PjwvX2NvbXBvbmVudHMudGFibGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTdcIiBkYXRhLXNsdWc9XCI3LWRlY2lzaW9ucy1yZWplY3RlZC1hbHRlcm5hdGl2ZXNcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy03XCIgLz57XCI3LiBEZWNpc2lvbnMgJiByZWplY3RlZCBhbHRlcm5hdGl2ZXNcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJQYXRoLWxldmVsIHNlcGFyYXRpb24gKGhvbGRvdXQgYXQgYW4gdW5ncmFudGVkIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi5ob2xkb3V0L1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgc2NvcGUpLCByZXVzaW5nIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNjb3BlZEZzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIlxcbmFsbG93LWxpc3QgKyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJhdHRlbnVhdGVEZWx0YVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5lbT57XCJSZWplY3RlZDpcIn08L19jb21wb25lbnRzLmVtPntcIiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIndpdGhpbi1maWxlIHJvdy1sZXZlbCByZWRhY3Rpb25cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHJldHVyblxcbm9ubHkgdGhlIHRyYWluaW5nIHJvd3Mgb2YgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZml4dHVyZXMvb3JkZXJzLmZyYW1lLmpzb25cIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSDigJQgaXQgbmVlZHMgYSBuZXcgY29udGVudC1hd2FyZSBmc1xcbmZpbHRlciwgaXMgZm9ybWF0LXNwZWNpZmljIChmcmFtZSBKU09OLCBDU1YsIOKApiksIGFuZCBpcyBmYXIgbW9yZSBmcmFnaWxlIHRoYW4gXFxcInRoZSBieXRlc1xcbmxpdmUgYXQgYSBwYXRoIHlvdSBkb24ndCBoYXZlXFxcIjsgcGF0aC1sZXZlbCByZXVzZXMgdGhlIGV4YWN0IG1hY2hpbmVyeSB0aGF0IGFscmVhZHkgZ2F0ZXNcXG51bmdyYW50ZWQgc3BhY2VzLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+PF9jb21wb25lbnRzLmNvZGU+e1wicndAc2VsZlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZm9yIHRoZSBhc3Npc3RhbnQgcmVhbG0gaXMgXCJ9PF9jb21wb25lbnRzLmVtPntcImRlZmluZWRcIn08L19jb21wb25lbnRzLmVtPntcIiBhcyB0aGUgZW51bWVyYXRlZCBhdXRob3Jpbmcgc3VidHJlZXMuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmVtPntcIlJlamVjdGVkOlwifTwvX2NvbXBvbmVudHMuZW0+e1wiIHRyZWF0aW5nIFwifTxfY29tcG9uZW50cy5jb2RlPntcInJ3QHNlbGZcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFzIHdob2xlLWRvY3VtZW50IGFuZCBib2x0aW5nIG9uIGEgcmVkYWN0aW9uIHBhc3MgKHRoZSBIM1xcbmhvbGUg4oCUIGEgd2hvbGUtcm9vdCBncmFudCBtYWtlcyBcIn08X2NvbXBvbmVudHMuY29kZT57XCIuaG9sZG91dC9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFuIGFuY2VzdG9yLWxpc3RhYmxlIGNoaWxkIGFuZCBpbnZpdGVzIHRoZVxcbnJlYWRkaXIgbGVhayk7IGEgXFxcImRlbnktcnVsZVxcXCIga2luZCBpbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzY29wZWRGc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKGFic2VuY2UgZnJvbSB0aGUgYWxsb3ctbGlzdCBhbHJlYWR5XFxuZGVuaWVzOyBhIGRlbnktcnVsZSBhZGRzIGEgc2Vjb25kIGNvZGUgcGF0aCB0byBrZWVwIGNvbnNpc3RlbnQpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiSG9sZG91dCByZXNvbHZlZCBvbmx5IGJ5IHRoZSBlbmdpbmUncyBob3N0LWJyb2tlcmVkIGlucHV0IGluamVjdGlvbi5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXCJ9PF9jb21wb25lbnRzLmVtPntcIlJlamVjdGVkOlwifTwvX2NvbXBvbmVudHMuZW0+e1wiXFxuZ3JhbnRpbmcgdGhlIGVuZ2luZSBhIGJyb2FkIGZpeHR1cmUgcmVhZCB0aGF0IHRoZSBhc3Npc3RhbnQgY291bGQgcmlkZTsgaGFuZGluZyBob2xkb3V0IHRvXFxudGhlIGFzc2lzdGFudCBcXFwic2VhbGVkXFxcIiAoYW55IGluLWFnZW50IHNlYWwgaXMgZGVmZWF0YWJsZSBieSB0aGUgYWdlbnQpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiSG9zdC1wZXJmb3JtZWQsIHByZS1hZ2VudCBzcGxpdC5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXCJ9PF9jb21wb25lbnRzLmVtPntcIlJlamVjdGVkOlwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGxldHRpbmcgdGhlIGFzc2lzdGFudCBwZXJmb3JtIHRoZSBzcGxpdFxcbihpdCB3b3VsZCBzZWUgdGhlIHJvd3MgZmlyc3Qg4oCUIHRoZSB3aG9sZSBob2xlKTsgYXR0ZW51YXRpbmcgXCJ9PF9jb21wb25lbnRzLmVtPntcImFmdGVyXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgdGhlIGFnZW50IHJlYWQgKHRvb1xcbmxhdGUpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUmUtc2NvcGUgaG9sZG91dCB0byBhIGJlc3QtZWZmb3J0IHRyaXB3aXJlOyB0aGUgb3JhY2xlLWZyZWUgbGVncyBjYXJyeSBjb3JyZWN0bmVzc1xcbihyZXZpZXctMiBkZWNpc2lvbiwgwqc1LjMpLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuZW0+e1wiUmVqZWN0ZWQ6XCJ9PC9fY29tcG9uZW50cy5lbT57XCIga2VlcGluZyBob2xkb3V0IGFzIFxcXCJ0aGUgb25seSBleGFtcGxlLWJhc2VkXFxuY29ycmVjdG5lc3Mgd2VpZ2h0XFxcIiAodGhlIHRlc3Qtb3JhY2xlIGNoYW5uZWwgwqc1LjEgYW5kIGFmZmluZSByZWNvbnN0cnVjdGlvbiDCpzUuMiBkZWZlYXQgaXQpO1xcbmEgYmFuZHdpZHRoLWJvdW5kZWQgb3V0cHV0LWNoYW5uZWwgcG9saWN5IG92ZXIgYWxsIHRlc3QgcmVzdWx0cy90cmFjZXMvZGlhZ25vc3RpY3MgdG8gc2F2ZSBpdFxcbihiaWdnZXIgdGhhbiBwYXRoIHNlcGFyYXRpb24sIHN0aWxsIGJlYXRlbiBieSByZWNvbnN0cnVjdGlvbik7IGRyb3BwaW5nIGhvbGRvdXQgZW50aXJlbHkgKHRoZVxcbnRyaXB3aXJlIGFuZCB0aGUgdHJpdmlhbC1yZWFkL21ldGFkYXRhLWxlYWsgY2xvc3VyZXMgYXJlIHN0aWxsIHdvcnRoIEQ5J3MgY29zdCkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJEZW55LWJ5LWRlZmF1bHQgZnM7IGVtcHR5IHJ1bGUtc2V0IGRlbmllcyBhbGwgKHJldmlldy0yIMKnMy4xKS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXCJ9PF9jb21wb25lbnRzLmVtPntcIlJlamVjdGVkOlwifTwvX2NvbXBvbmVudHMuZW0+e1wiIHRoZSBjdXJyZW50XFxuZmFpbC1vcGVuIG1ldGhvZCBhbGxvdy1saXN0IChcIn08X2NvbXBvbmVudHMuY29kZT57XCJleGlzdHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL3VubW9kZWxlZCBtZXRob2RzIHBhc3MgdGhyb3VnaCkgYW5kIHRoZSBlbXB0eS1ydWxlLXNldFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcIndob2xlUndcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHNob3J0LWNpcmN1aXQg4oCUIGJvdGggaW52ZXJ0IGRlZmVuc2UtaW4tZGVwdGguXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJCbGluZCBzZWNvbmQtYWdlbnQgYXV0aG9yaW5nIGlzIGEgXCJ9PF9jb21wb25lbnRzLmVtPntcIndlYWtcIn08L19jb21wb25lbnRzLmVtPntcIiBzaWduYWwgKHJldmlldy0yIEQ5LTMpLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuZW0+e1wiUmVqZWN0ZWQ6XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgY2xhaW1pbmdcXG5pbmRlcGVuZGVuY2Ugd2hlbiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImFnZW50LTEgYXV0aG9ycyB0aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZG9jXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhZ2VudC0yIHJlYWRzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBhIGNvbXBsZXRlIGludGVudFxcbm92ZXItZGV0ZXJtaW5lcyB0aGUgaW1wbGVtZW50YXRpb24sIHNvIFxcXCJpbmRlcGVuZGVudCByZXByb2R1Y3Rpb24gZnJvbSBpbnRlbnRcXFwiIGlzIG9ubHkgYXNcXG5pbmRlcGVuZGVudCBhcyB0aGUgZG9jIGlzIGluY29tcGxldGUsIHdoaWNoIHRoZSBkZXNpZ24gY2Fubm90IGVuZm9yY2UuIFRyZWF0IHNlY29uZC1hZ2VudFxcbnRlc3RzIGFzIGNvcnJvYm9yYXRpb24sIG5vdCBwcm9vZi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIk5hbWUgdGhlIHJlY29uc3RydWN0aW9uIHJlc2lkdWFsOyBrZWVwIG1ldGFtb3JwaGljL211dGF0aW9uIGFzIHRoZSBsb2FkLWJlYXJpbmcgc2lnbmFsLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIlxcblwifTxfY29tcG9uZW50cy5lbT57XCJSZWplY3RlZDpcIn08L19jb21wb25lbnRzLmVtPntcIiBjbGFpbWluZyBob2xkb3V0IG1ha2VzIGluZmVycmVkIGZvcm11bGFzIGNvcnJlY3QgKFJRLUQ1IHNheXMgbm90aGluZyBkb2VzKTtcXG5jbGFpbWluZyBwYXRoIHNlcGFyYXRpb24gZGVmZWF0cyBhIGRpc3RyaWJ1dGlvbi1tb2RlbGluZyBhZ2VudCAoaXQgZG9lc24ndCDigJQgYW5kIGZvciB0aGVcXG50YXJnZXQgd29ya2xvYWQgaXQgZG9lc24ndCBldmVuIGRlZmVhdCBcIn08X2NvbXBvbmVudHMuZW0+e1wib3JkaW5hcnkgZml0dGluZ1wifTwvX2NvbXBvbmVudHMuZW0+e1wiLCDCpzUuMikuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInNlYy04XCIgZGF0YS1zbHVnPVwiOC1vcGVuLXF1ZXN0aW9uc1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLThcIiAvPntcIjguIE9wZW4gcXVlc3Rpb25zXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiT1EtMSAoc3BsaXQgZ3JhbnVsYXJpdHkpLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBSb3ctbGV2ZWwgcmFuZG9tIGhvbGRvdXQgaXMgYXNzdW1lZDsgc29tZSBmZWVkcyB3YW50XFxuXCJ9PF9jb21wb25lbnRzLmVtPntcInN0cmF0aWZpZWRcIn08L19jb21wb25lbnRzLmVtPntcIiBob2xkb3V0IChob2xkIG91dCBhIHdob2xlIGNvaG9ydC9tb250aCBzbyB0aGUgdGVzdCBjaGVja3MgZ2VuZXJhbGl6YXRpb25cXG5hY3Jvc3MgYSBkaW1lbnNpb24pLiBEb2VzIHRoZSBob3N0IHNwbGl0IEFQSSBleHBvc2UgYSBzdHJhdGlmaWNhdGlvbiBrZXksIG9yIGlzIHRoYXQgYVxcbmZ1dHVyZSBhZGQ/IEludGVyYWN0cyB3aXRoIHRoZSBjYXNlLXN0dWR5IGNvaG9ydCBzaGVldC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIk9RLTIg4oCUIFJFU09MVkVEIChyZXZpZXctMiBEOS00LCDCpzQpLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBDYXB0dXJlLXRoZW4taW5mZXIgYW5kIHN0YXRpYyBmZWVkcyBoYXZlIG5vXFxuZW5mb3JjZWFibGUgaG9sZG91dDsgdGhlIGhvc3QgbWFya3Mgc3VjaCBpbmZlcmVuY2VzIFwifTxfY29tcG9uZW50cy5lbT57XCJuby1lbmZvcmNlYWJsZS1ob2xkb3V0XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgYW5kIHRoZSByZXZpZXdcXG5zdXJmYWNlIGdyYW50cyB0aGVtIHplcm8gY29ycmVjdG5lc3MgY3JlZGl0ICh0cmlwd2lyZSBvbmx5KS4gTm8gbG9uZ2VyIG9wZW4uXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJPUS0zIChsYXJnZWx5IGFuc3dlcmVkIGJ5IHJldmlldy0yOyByZXNpZHVhbCBmb3IgYnVpbGQpLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBSZWNvbnN0cnVjdGlvbiB3YXMgc2hvd25cXG5cIn08X2NvbXBvbmVudHMuZW0+e1wiY2VudHJhbFwifTwvX2NvbXBvbmVudHMuZW0+e1wiLCBub3QgYSBjb3JuZXIgKMKnNS4yKSwgYW5kIHRoZSByZXNwb25zZSBpcyB0aGUgcmUtc2NvcGUsIG5vdCBhIHN0cm9uZ2VyIHNlYWwuIFRoZVxcbnJlc2lkdWFsIGZvciB0aGUgYnVpbGQ6IGZvciB3aGljaCDigJQgaWYgYW55IOKAlCBmZWVkL2Zvcm11bGEgc2hhcGVzIGlzIGhvbGRvdXQgd29ydGggdGhlIG1hY2hpbmVyeVxcbmF0IGFsbCAobm9ubGluZWFyL3JlZ2ltZS1zaGlmdCBmb3JtdWxhcyksIHZlcnN1cyBkcm9wcGluZyBpdCBhbmQgcmVseWluZyB3aG9sbHkgb24gdGhlXFxub3JhY2xlLWZyZWUgbGVncz8gU2V0dGxlIGR1cmluZyBNMiBhZ2FpbnN0IHRoZSBjYXNlIHN0dWR5OyB0aGUgbWFuZGF0b3J5LXNlY29uZC1hZ2VudCBnYXRlXFxuKHJlcG9ydCBSUS1ENSB0aHJlc2hvbGQpIG5vdyBhdHRhY2hlcyB0byBhIGxvdyBtdXRhdGlvbiBzY29yZSwgbm90IHRvIGEgaG9sZG91dCBudW1iZXIuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPjwvPjtcbn1cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE1EWENvbnRlbnQocHJvcHMgPSB7fSkge1xuICBjb25zdCB7d3JhcHBlcjogTURYTGF5b3V0fSA9IHtcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH07XG4gIHJldHVybiBNRFhMYXlvdXQgPyA8TURYTGF5b3V0IHsuLi5wcm9wc30+PF9jcmVhdGVNZHhDb250ZW50IHsuLi5wcm9wc30gLz48L01EWExheW91dD4gOiBfY3JlYXRlTWR4Q29udGVudChwcm9wcyk7XG59XG5mdW5jdGlvbiBfbWlzc2luZ01keFJlZmVyZW5jZShpZCwgY29tcG9uZW50LCBwbGFjZSkge1xuICB0aHJvdyBuZXcgRXJyb3IoXCJFeHBlY3RlZCBcIiArIChjb21wb25lbnQgPyBcImNvbXBvbmVudFwiIDogXCJvYmplY3RcIikgKyBcIiBgXCIgKyBpZCArIFwiYCB0byBiZSBkZWZpbmVkOiB5b3UgbGlrZWx5IGZvcmdvdCB0byBpbXBvcnQsIHBhc3MsIG9yIHByb3ZpZGUgaXQuXCIgKyAocGxhY2UgPyBcIlxcbkl04oCZcyByZWZlcmVuY2VkIGluIHlvdXIgY29kZSBhdCBgXCIgKyBwbGFjZSArIFwiYCBpbiBgL2FwcC9kb2NzL3NwZWNzL0hPTERPVVRfUkVEQUNURURfTU9VTlRfU1BFQy5tZGBcIiA6IFwiXCIpKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQXdGLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUZ4RjtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU1DLFdBQVcsR0FBRztNQUNsQkMsVUFBVSxFQUFFLFlBQVk7TUFDeEJDLElBQUksRUFBRSxNQUFNO01BQ1pDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLENBQUMsRUFBRSxHQUFHO01BQ05DLEdBQUcsRUFBRSxLQUFLO01BQ1ZDLE1BQU0sRUFBRSxRQUFRO01BQ2hCQyxLQUFLLEVBQUUsT0FBTztNQUNkQyxLQUFLLEVBQUUsT0FBTztNQUNkQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxLQUFLLEVBQUUsT0FBTztNQUNkQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSLEdBQUcsSUFBQUMsNkJBQWtCLEVBQUMsQ0FBQztNQUN2QixHQUFHckIsS0FBSyxDQUFDc0I7SUFDWCxDQUFDO0lBQUU7TUFBQ0M7SUFBYSxDQUFDLEdBQUd0QixXQUFXO0VBQ2hDLElBQUksQ0FBQ3NCLGFBQWEsRUFBRUMsb0JBQW9CLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQztFQUMvRCxvQkFBTyxJQUFBMUIsV0FBQSxDQUFBMkIsSUFBQSxFQUFBM0IsV0FBQSxDQUFBNEIsUUFBQTtJQUFBQyxRQUFBLGdCQUFFLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNJLEVBQUU7TUFBQ3VCLEVBQUUsRUFBQyx3R0FBd0c7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUF3RyxDQUFFLENBQUMsRUFBQyw0R0FBNEc7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNVLENBQUM7TUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBUyxDQUFxQixDQUFDLEVBQUMsd0RBQXdELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQXlCLENBQW1CLENBQUMsRUFBQyxPQUFPLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBaUQsQ0FBcUIsQ0FBQyxFQUFDLDZCQUE2QixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUFTLENBQWlCLENBQUMsRUFBQyxrQ0FBa0MsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFLLENBQXFCLENBQUMsRUFBQyx3REFBd0QsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFxQixDQUFxQixDQUFDLEVBQUMsa0dBQWtHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBaUMsQ0FBcUIsQ0FBQyxFQUFDLDhFQUE4RSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFzQixDQUFtQixDQUFDLEVBQUMsMkNBQTJDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBVSxDQUFxQixDQUFDLEVBQUMsYUFBYTtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsVUFBVTtNQUFBeUIsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDVSxDQUFDO1FBQUFnQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxHQUFFLDREQUE0RCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7WUFBQXdCLFFBQUEsRUFBRTtVQUE4QyxDQUFtQixDQUFDO1FBQUEsQ0FBb0IsQ0FBQyxFQUFDLDBHQUEwRztNQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBeUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDQyxVQUFVO01BQUF5QixRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNVLENBQUM7UUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBYyxDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUF5QixDQUFtQixDQUFDLEVBQUMsNERBQTRELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQVMsQ0FBbUIsQ0FBQyxFQUFDLDBCQUEwQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUF5QixDQUFtQixDQUFDLEVBQUMsUUFBUSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFtQyxDQUFtQixDQUFDLEVBQUMsNkdBQTZHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQW9CLENBQW1CLENBQUMsRUFBQywwRUFBMEUsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBOEIsQ0FBbUIsQ0FBQyxFQUFDLFVBQVUsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFTLENBQW1CLENBQUMsRUFBQyxtREFBbUQsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBaUIsQ0FBbUIsQ0FBQyxFQUFDLHVGQUF1RjtNQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBeUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDTyxFQUFFLElBQUUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBVixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNLLEVBQUU7TUFBQ3NCLEVBQUUsRUFBQyxPQUFPO01BQUMsYUFBVSwwQ0FBMEM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLDZCQUE2QixlQUFDLElBQUE5QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUFvQixDQUFpQixDQUFDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLEdBQUUsNENBQTRDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBb0IsQ0FBcUIsQ0FBQyxFQUFDLGlJQUFpSSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFlLENBQW1CLENBQUMsRUFBQyxlQUFlLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBeUQsQ0FBcUIsQ0FBQyxFQUFDLDJCQUEyQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUFRLENBQWlCLENBQUMsRUFBQyxpSEFBaUgsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFTLENBQXFCLENBQUMsRUFBQyxtREFBbUQsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUE4QixDQUFxQixDQUFDLEVBQUMsMkVBQTJFO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQXFELENBQXFCLENBQUMsRUFBQyw4QkFBOEIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBa0IsQ0FBbUIsQ0FBQyxFQUFDLHVDQUF1QyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUFVLENBQWlCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQVcsQ0FBbUIsQ0FBQyxFQUFDLHVCQUF1QixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUF3QyxDQUFtQixDQUFDLEVBQUMsc0dBQXNHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQVMsQ0FBbUIsQ0FBQyxFQUFDLDRJQUE0SSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQU0sQ0FBcUIsQ0FBQyxFQUFDLFFBQVE7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNDLFVBQVU7TUFBQXlCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztRQUFBZ0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFtRixDQUFxQixDQUFDLEVBQUMsK0JBQStCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQWlCLENBQWlCLENBQUMsRUFBQyx1REFBdUQsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUE0RyxDQUFxQixDQUFDLEVBQUMseURBQXlELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBSyxDQUFxQixDQUFDLEVBQUMsMERBQTBELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBVSxDQUFxQixDQUFDLEVBQUMsMERBQTBELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQXNCLENBQW1CLENBQUMsRUFBQyxtSkFBbUosZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBa0QsQ0FBaUIsQ0FBQyxFQUFDLFNBQVMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBcUMsQ0FBaUIsQ0FBQztNQUFBLENBQWUsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUF5QixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNVLENBQUM7TUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBZ0IsQ0FBcUIsQ0FBQyxFQUFDLHlEQUF5RCxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxHQUFFLCtCQUErQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUF5QixDQUFpQixDQUFDO01BQUEsQ0FBb0IsQ0FBQyxFQUFDLHVEQUF1RCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUFvQyxDQUFpQixDQUFDLEVBQUMsdURBQXVELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBd0MsQ0FBcUIsQ0FBQyxFQUFDLHNEQUFzRCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUFPLENBQWlCLENBQUMsRUFBQyx3Q0FBd0MsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBUSxDQUFtQixDQUFDLEVBQUMsYUFBYSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUFPLENBQWlCLENBQUMsRUFBQyx5Q0FBeUMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBaUIsQ0FBbUIsQ0FBQyxFQUFDLG1FQUFtRSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFPLENBQW1CLENBQUMsRUFBQyxxREFBcUQ7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNPLEVBQUUsSUFBRSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFWLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDc0IsRUFBRSxFQUFDLE9BQU87TUFBQyxhQUFVLDhEQUE4RDtNQUFBRCxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMsd0RBQXdELGVBQUMsSUFBQTlCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQWEsQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLGtGQUFrRixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUFVLENBQWlCLENBQUMsRUFBQyxxQ0FBcUMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1FBQUF1QixRQUFBLEVBQUU7TUFBZSxDQUFpQixDQUFDLEVBQUMsR0FBRztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ21CLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQW1CLENBQXFCLENBQUMsRUFBQyx1RkFBdUYsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBMEQsQ0FBaUIsQ0FBQyxFQUFDLHlCQUF5QixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFrQixDQUFtQixDQUFDLEVBQUMsc0JBQXNCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBSSxDQUFxQixDQUFDLEVBQUMsdUNBQXVDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQVMsQ0FBbUIsQ0FBQyxFQUFDLDhEQUE4RDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUE2QixDQUFxQixDQUFDLEVBQUMscUdBQXFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBdUMsQ0FBcUIsQ0FBQyxFQUFDLG9CQUFvQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTRDLENBQXFCLENBQUMsRUFBQyxjQUFjLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQWUsQ0FBbUIsQ0FBQyxFQUFDLHNFQUFzRSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQW9CLENBQXFCLENBQUMsRUFBQywyQkFBMkI7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLGdDQUFnQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQXlELENBQXFCLENBQUMsRUFBQyxvREFBb0QsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBUSxDQUFtQixDQUFDLEVBQUMsNkJBQTZCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBc0IsQ0FBcUIsQ0FBQyxFQUFDLDBEQUEwRCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFVLENBQW1CLENBQUMsRUFBQyxxSkFBcUosZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1FBQUF1QixRQUFBLEVBQUU7TUFBTyxDQUFpQixDQUFDLEVBQUMsMEVBQTBFO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDSyxFQUFFO01BQUNzQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUsMkNBQTJDO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQyx5QkFBeUIsZUFBQyxJQUFBOUIsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1FBQUF1QixRQUFBLEVBQUU7TUFBMEIsQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLGlFQUFpRSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFVLENBQW1CLENBQUMsRUFBQyxvQkFBb0I7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNXLEdBQUc7TUFBQWUsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUEwakIsQ0FBbUI7SUFBQyxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNtQixFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBd0IsUUFBQSxFQUFFO1VBQVcsQ0FBbUIsQ0FBQyxFQUFDLCtEQUErRDtRQUFBLENBQXFCLENBQUMsRUFBQyxPQUFPLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLG9DQUFvQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyxrQkFBa0IsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsZUFBZSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFNLENBQW1CLENBQUMsRUFBQyx1QkFBdUIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyxnQkFBZ0IsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBTSxDQUFpQixDQUFDLEVBQUMsMElBQTBJO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWlFLENBQXFCLENBQUMsRUFBQyxxQ0FBcUMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBVSxDQUFtQixDQUFDLEVBQUMsOEVBQThFLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQVEsQ0FBbUIsQ0FBQyxFQUFDLDRDQUE0QyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUF5QixDQUFtQixDQUFDLEVBQUMsNEJBQTRCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQW9DLENBQW1CLENBQUMsRUFBQyx5SEFBeUg7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBMEMsQ0FBcUIsQ0FBQyxFQUFDLHNCQUFzQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFlLENBQW1CLENBQUMsRUFBQyx1QkFBdUIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBd0IsUUFBQSxFQUFFO1VBQUssQ0FBbUIsQ0FBQyxFQUFDLHVCQUF1QjtRQUFBLENBQXFCLENBQUMsRUFBQyxTQUFTLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQyxFQUFDLDZCQUE2QixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyxpRUFBaUU7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDc0IsRUFBRSxFQUFDLE9BQU87TUFBQyxhQUFVLGdJQUFnSTtNQUFBRCxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMscUNBQXFDLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQVcsQ0FBbUIsQ0FBQyxFQUFDLDJDQUEyQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUFxRCxDQUFpQixDQUFDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFVLENBQW1CLENBQUMsRUFBQyx5Q0FBeUMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFpQixDQUFxQixDQUFDLEVBQUMsZ0JBQWdCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQXFCLENBQW1CLENBQUMsRUFBQyx1Q0FBdUMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1FBQUF1QixRQUFBLEVBQUU7TUFBUSxDQUFpQixDQUFDLEVBQUMsNENBQTRDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBdUIsQ0FBcUIsQ0FBQyxFQUFDLG1CQUFtQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFXLENBQW1CLENBQUMsRUFBQyw4REFBOEQsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBVyxDQUFtQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFxQixDQUFtQixDQUFDLEVBQUMscUNBQXFDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBb0IsQ0FBcUIsQ0FBQyxFQUFDLGtKQUFrSjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1MsRUFBRTtNQUFBaUIsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1lBQUF3QixRQUFBLEVBQUU7VUFBVyxDQUFtQixDQUFDLEVBQUMsK0RBQStEO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLHlFQUF5RSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFxQixDQUFtQixDQUFDLEVBQUMsd0RBQXdELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLHFEQUFxRDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsR0FBRSxnREFBZ0QsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1lBQUF3QixRQUFBLEVBQUU7VUFBMEIsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7UUFBQSxDQUFxQixDQUFDLEVBQUMsaUJBQWlCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQUksQ0FBbUIsQ0FBQyxFQUFDLGdEQUFnRCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyx3Q0FBd0MsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBUyxDQUFtQixDQUFDLEVBQUMsdUNBQXVDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBcUMsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBYSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFZLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBZSxDQUFtQixDQUFDLEVBQUMsZ0NBQWdDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLHNEQUFzRCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFTLENBQW1CLENBQUMsRUFBQywyRkFBMkYsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsSUFBSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLEdBQUUsaUNBQWlDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQVMsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsR0FBRSxNQUFNLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQVEsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBTSxDQUFtQixDQUFDO01BQUEsQ0FBb0IsQ0FBQyxFQUFDLDBEQUEwRCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFVLENBQW1CLENBQUMsRUFBQyxTQUFTO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDTSxFQUFFO01BQUNxQixFQUFFLEVBQUMsU0FBUztNQUFDLGFBQVUsbUdBQW1HO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBUyxDQUFFLENBQUMsRUFBQyxVQUFVLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQVUsQ0FBbUIsQ0FBQyxFQUFDLHVEQUF1RCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUFxQyxDQUFpQixDQUFDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLEdBQUUsbURBQW1ELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBZ0IsQ0FBcUIsQ0FBQyxFQUFDLFlBQVksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBWSxDQUFtQixDQUFDLEVBQUMsa0JBQWtCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBTSxDQUFxQixDQUFDLEVBQUMsY0FBYyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUEyQixDQUFtQixDQUFDLEVBQUMsUUFBUSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUFPLENBQWlCLENBQUMsRUFBQywyRUFBMkUsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBYyxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFRLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQVksQ0FBbUIsQ0FBQyxFQUFDLDJCQUEyQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUF1QixDQUFtQixDQUFDLEVBQUMsdUNBQXVDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQU0sQ0FBbUIsQ0FBQyxFQUFDLDRHQUE0RyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFVLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQVUsQ0FBbUIsQ0FBQyxFQUFDLGdEQUFnRCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVksQ0FBcUIsQ0FBQyxFQUFDLGlDQUFpQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQWEsQ0FBcUIsQ0FBQyxFQUFDLEdBQUc7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNTLEVBQUU7TUFBQWlCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFrQixDQUFxQixDQUFDLEVBQUMsMEVBQTBFLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQVEsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsU0FBUyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFNLENBQW1CLENBQUMsRUFBQyxZQUFZLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBbUIsQ0FBcUIsQ0FBQyxFQUFDLFdBQVcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBYyxDQUFtQixDQUFDLEVBQUMsMElBQTBJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQVEsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBTSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQVUsQ0FBbUIsQ0FBQyxFQUFDLE9BQU87TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBdUMsQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBWSxDQUFtQixDQUFDLEVBQUMsb0JBQW9CLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQTBCLENBQW1CLENBQUMsRUFBQywyREFBMkQsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBUyxDQUFtQixDQUFDLEVBQUMsdUlBQXVJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBVSxDQUFxQixDQUFDLEVBQUMsd0RBQXdELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLDRDQUE0QyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFRLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQU0sQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBVSxDQUFtQixDQUFDLEVBQUMsY0FBYyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVMsQ0FBcUIsQ0FBQyxFQUFDLDJGQUEyRjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDc0IsRUFBRSxFQUFDLE9BQU87TUFBQyxhQUFVLGlHQUFpRztNQUFBRCxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMsNkZBQTZGLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQWEsQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxFQUFFO0lBQW1ILENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1MsRUFBRTtNQUFBaUIsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxHQUFFLDZDQUE2QyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7WUFBQXVCLFFBQUEsRUFBRTtVQUFVLENBQWlCLENBQUMsRUFBQyxzQ0FBc0M7UUFBQSxDQUFxQixDQUFDLEVBQUMsMEJBQTBCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQVEsQ0FBaUIsQ0FBQyxFQUFDLG1CQUFtQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyxzRUFBc0UsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBUyxDQUFtQixDQUFDLEVBQUMsMkdBQTJHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQVMsQ0FBbUIsQ0FBQyxFQUFDLGdFQUFnRTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUE0QyxDQUFxQixDQUFDLEVBQUMsaUZBQWlGLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQVMsQ0FBaUIsQ0FBQyxFQUFDLHVJQUF1STtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFtQyxDQUFxQixDQUFDLEVBQUMsc1JBQXNSO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNVLENBQUM7TUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBc0gsQ0FBcUIsQ0FBQyxFQUFDLGdCQUFnQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUFNLENBQWlCLENBQUMsRUFBQyxzRUFBc0UsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFLLENBQXFCLENBQUMsRUFBQyx3R0FBd0c7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNtQixFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFxQixDQUFxQixDQUFDLEVBQUMsMkNBQTJDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQXdCLENBQW1CLENBQUMsRUFBQyx5Q0FBeUMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsb0pBQW9KO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWlDLENBQXFCLENBQUMsRUFBQyxvSEFBb0gsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBYyxDQUFpQixDQUFDLEVBQUMsR0FBRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQU8sQ0FBcUIsQ0FBQyxFQUFDLDZIQUE2SCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQXdCLENBQXFCLENBQUMsRUFBQyxnQkFBZ0IsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBZSxDQUFtQixDQUFDLEVBQUMsd0RBQXdELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBNEMsQ0FBcUIsQ0FBQyxFQUFDLDZFQUE2RSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUFNLENBQWlCLENBQUMsRUFBQyxrUEFBa1A7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNNLEVBQUU7TUFBQ3FCLEVBQUUsRUFBQyxTQUFTO01BQUMsYUFBVSxzR0FBc0c7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFTLENBQUUsQ0FBQyxFQUFDLHdFQUF3RSxlQUFDLElBQUE5QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUF5QyxDQUFpQixDQUFDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLEdBQUUscUVBQXFFLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBbUQsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBK0MsQ0FBbUIsQ0FBQyxFQUFDLHFDQUFxQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQTBCLENBQXFCLENBQUMsRUFBQyw4REFBOEQ7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNtQixFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFjLENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQXdCLENBQW1CLENBQUMsRUFBQyxxSkFBcUosZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUF1QixDQUFxQixDQUFDLEVBQUMsNENBQTRDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQWMsQ0FBaUIsQ0FBQyxFQUFDLEdBQUc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBcUIsQ0FBcUIsQ0FBQyxFQUFDLDZFQUE2RTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFzQixDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUErQyxDQUFtQixDQUFDLEVBQUMsMkpBQTJKO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNVLENBQUM7TUFBQWdCLFFBQUEsR0FBRSxvREFBb0QsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFLLENBQXFCLENBQUMsRUFBQyxxRUFBcUUsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1FBQUF1QixRQUFBLEVBQUU7TUFBa0IsQ0FBaUIsQ0FBQyxFQUFDLDhDQUE4QyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQTBCLENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQXdCLENBQW1CLENBQUMsRUFBQyw0REFBNEQsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUE0RCxDQUFxQixDQUFDLEVBQUMscUdBQXFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQU0sQ0FBaUIsQ0FBQyxFQUFDLGtKQUFrSixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQTRDLENBQXFCLENBQUMsRUFBQyxpTkFBaU4sZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFVLENBQXFCLENBQUMsRUFBQyxtR0FBbUc7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNNLEVBQUU7TUFBQ3FCLEVBQUUsRUFBQyxTQUFTO01BQUMsYUFBVSx3RUFBd0U7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFTLENBQUUsQ0FBQyxFQUFDLHlEQUF5RCxlQUFDLElBQUE5QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUF1QixDQUFpQixDQUFDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLEdBQUUsNkVBQTZFLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBUSxDQUFxQixDQUFDLEVBQUMsYUFBYSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQThELENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQXdCLENBQW1CLENBQUMsRUFBQyx1QkFBdUIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBSyxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFNLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQVMsQ0FBbUIsQ0FBQyxFQUFDLHdCQUF3QixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUFZLENBQWlCLENBQUMsRUFBQywyQkFBMkIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFrQixDQUFxQixDQUFDLEVBQUMsbU1BQW1NLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQUssQ0FBaUIsQ0FBQyxFQUFDLGtDQUFrQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUFtQixDQUFpQixDQUFDLEVBQUMsbURBQW1EO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDTSxFQUFFO01BQUNxQixFQUFFLEVBQUMsU0FBUztNQUFDLGFBQVUsc0NBQXNDO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBUyxDQUFFLENBQUMsRUFBQyx3QkFBd0IsZUFBQyxJQUFBOUIsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1FBQUF1QixRQUFBLEVBQUU7TUFBb0IsQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLGdCQUFnQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVMsQ0FBcUIsQ0FBQyxFQUFDLHNCQUFzQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFVLENBQW1CLENBQUMsRUFBQyxpQ0FBaUMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBUSxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFNLENBQW1CLENBQUMsRUFBQyxrREFBa0QsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFLLENBQXFCLENBQUMsRUFBQyxnSUFBZ0ksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFVLENBQXFCLENBQUMsRUFBQyxnTEFBZ0wsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBc0IsQ0FBbUIsQ0FBQyxFQUFDLHdJQUF3SSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFLLENBQW1CLENBQUMsRUFBQyxpSUFBaUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1FBQUF1QixRQUFBLEVBQUU7TUFBTSxDQUFpQixDQUFDLEVBQUMsMkZBQTJGLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQVcsQ0FBaUIsQ0FBQyxFQUFDLHNDQUFzQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDc0IsRUFBRSxFQUFDLE9BQU87TUFBQyxhQUFVLHlDQUF5QztNQUFBRCxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMsNENBQTRDO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDTSxFQUFFO01BQUNxQixFQUFFLEVBQUMsOEZBQThGO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBOEYsQ0FBRSxDQUFDLEVBQUMsb0VBQW9FLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQWdDLENBQW1CLENBQUMsRUFBQyxHQUFHO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDYSxLQUFLO01BQUFhLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2lCLEtBQUs7UUFBQVMsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQW9ELENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNnQixFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUE2QixDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBcUIsQ0FBaUIsQ0FBQztRQUFBLENBQWdCO01BQUMsQ0FBbUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2MsS0FBSztRQUFBWSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEdBQUUsaUNBQWlDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQWlCLENBQW1CLENBQUMsRUFBQywyQ0FBMkM7VUFBQSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBc0QsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBYyxDQUFtQjtVQUFDLENBQWdCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxHQUFFLGNBQWMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBUyxDQUFtQixDQUFDLEVBQUMsOEJBQThCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtjQUFBdUIsUUFBQSxFQUFFO1lBQVMsQ0FBaUIsQ0FBQyxFQUFDLGlDQUFpQztVQUFBLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFzRCxDQUFtQjtVQUFDLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFxQixDQUFtQjtVQUFDLENBQWdCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQWtILENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUE2RCxDQUFtQjtVQUFDLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFrQixDQUFtQjtVQUFDLENBQWdCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxHQUFFLHFEQUFxRCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFVLENBQW1CLENBQUMsRUFBQyw0QkFBNEI7VUFBQSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBK0IsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBVyxDQUFtQjtVQUFDLENBQWdCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQTJGLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUEwRCxDQUFtQjtVQUFDLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFjLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQztRQUFBLENBQWdCLENBQUM7TUFBQSxDQUFtQixDQUFDO0lBQUEsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDTSxFQUFFO01BQUNxQixFQUFFLEVBQUMsMERBQTBEO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBMEQsQ0FBRSxDQUFDLEVBQUMsNERBQTREO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDYSxLQUFLO01BQUFhLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2lCLEtBQUs7UUFBQVMsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQWUsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQXVCLENBQWlCLENBQUM7UUFBQSxDQUFnQjtNQUFDLENBQW1CLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNjLEtBQUs7UUFBQVksUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxHQUFFLHdCQUF3QixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFTLENBQW1CLENBQUMsRUFBQyx5REFBeUQ7VUFBQSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsR0FBRSx1REFBdUQsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBZSxDQUFtQixDQUFDLEVBQUMsZ0JBQWdCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQVcsQ0FBbUIsQ0FBQztVQUFBLENBQWdCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQW9FLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxHQUFFLFdBQVcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBVSxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFRLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQU0sQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBVSxDQUFtQixDQUFDLEVBQUMsbUVBQW1FLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQU0sQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBUSxDQUFtQixDQUFDLEVBQUMsU0FBUyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFTLENBQW1CLENBQUMsRUFBQyx3QkFBd0I7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUE4RCxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsR0FBRSxXQUFXLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQVMsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDWSxNQUFNO2NBQUFjLFFBQUEsR0FBRSxNQUFNLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtnQkFBQXdCLFFBQUEsRUFBRTtjQUFRLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtnQkFBQXdCLFFBQUEsRUFBRTtjQUFNLENBQW1CLENBQUM7WUFBQSxDQUFvQixDQUFDLEVBQUMscURBQXFELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQVUsQ0FBbUIsQ0FBQyxFQUFDLFFBQVE7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUE4RSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsR0FBRSxhQUFhLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQWUsQ0FBbUIsQ0FBQyxFQUFDLGtCQUFrQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUF5QixDQUFtQixDQUFDLEVBQUMsdUVBQXVFO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBZ0UsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBNkosQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBeUMsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEdBQUUsZ0RBQWdELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQUssQ0FBbUIsQ0FBQyxFQUFDLFdBQVcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBYSxDQUFtQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFXLENBQW1CLENBQUM7VUFBQSxDQUFnQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFnRSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFzSCxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFrRCxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsR0FBRSx3RUFBd0UsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBZSxDQUFtQixDQUFDLEVBQUMsbUJBQW1CLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtjQUFBdUIsUUFBQSxFQUFFO1lBQWUsQ0FBaUIsQ0FBQyxFQUFDLGlHQUFpRztVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDO01BQUEsQ0FBbUIsQ0FBQztJQUFBLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDc0IsRUFBRSxFQUFDLE9BQU87TUFBQyxhQUFVLG1DQUFtQztNQUFBRCxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMsc0NBQXNDO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDbUIsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEdBQUUsaURBQWlELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBd0IsUUFBQSxFQUFFO1VBQVcsQ0FBbUIsQ0FBQyxFQUFDLG1CQUFtQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7WUFBQXdCLFFBQUEsRUFBRTtVQUFVLENBQW1CLENBQUMsRUFBQyxpQkFBaUIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1lBQUF3QixRQUFBLEVBQUU7VUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7UUFBQSxDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFXLENBQWlCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBaUMsQ0FBcUIsQ0FBQyxFQUFDLHNDQUFzQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUE0QixDQUFtQixDQUFDLEVBQUMsOE9BQThPO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1lBQUF3QixRQUFBLEVBQUU7VUFBUyxDQUFtQixDQUFDLEVBQUMsOEJBQThCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtZQUFBdUIsUUFBQSxFQUFFO1VBQVMsQ0FBaUIsQ0FBQyxFQUFDLHdDQUF3QztRQUFBLENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLFlBQVksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBUyxDQUFtQixDQUFDLEVBQUMsOEZBQThGLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLHNGQUFzRixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQyx5R0FBeUc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBc0UsQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBVyxDQUFpQixDQUFDLEVBQUMsd0tBQXdLO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWtDLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLHdHQUF3RyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFPLENBQWlCLENBQUMsRUFBQyw4QkFBOEI7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBZ0gsQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBVyxDQUFpQixDQUFDLEVBQUMsNlpBQTZaO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWdFLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLDZDQUE2QyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFRLENBQW1CLENBQUMsRUFBQywyREFBMkQsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBUyxDQUFtQixDQUFDLEVBQUMsZ0RBQWdEO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxHQUFFLG9DQUFvQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7WUFBQXVCLFFBQUEsRUFBRTtVQUFNLENBQWlCLENBQUMsRUFBQywwQkFBMEI7UUFBQSxDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFXLENBQWlCLENBQUMsRUFBQywrQkFBK0IsZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsR0FBRSxzQkFBc0IsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1lBQUF3QixRQUFBLEVBQUU7VUFBSyxDQUFtQixDQUFDLEVBQUMsZ0JBQWdCO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLGlQQUFpUDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUF5RixDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFXLENBQWlCLENBQUMsRUFBQyxpTkFBaU4sZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBa0IsQ0FBaUIsQ0FBQyxFQUFDLFVBQVU7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDc0IsRUFBRSxFQUFDLE9BQU87TUFBQyxhQUFVLGtCQUFrQjtNQUFBRCxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMsbUJBQW1CO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDbUIsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBMkIsQ0FBcUIsQ0FBQyxFQUFDLHlEQUF5RCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFZLENBQWlCLENBQUMsRUFBQyw0TkFBNE47TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBc0MsQ0FBcUIsQ0FBQyxFQUFDLG9HQUFvRyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUF3QixDQUFpQixDQUFDLEVBQUMsK0ZBQStGO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTBELENBQXFCLENBQUMsRUFBQyw2QkFBNkIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBUyxDQUFpQixDQUFDLEVBQUMsaWNBQWljO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDO0VBQUEsQ0FBRSxDQUFDO0FBQzM2MEM7QUFDZSxTQUFTRyxVQUFVQSxDQUFDOUIsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFO0VBQzdDLE1BQU07SUFBQytCLE9BQU8sRUFBRUM7RUFBUyxDQUFDLEdBQUc7SUFDM0IsR0FBRyxJQUFBWCw2QkFBa0IsRUFBQyxDQUFDO0lBQ3ZCLEdBQUdyQixLQUFLLENBQUNzQjtFQUNYLENBQUM7RUFDRCxPQUFPVSxTQUFTLGdCQUFHLElBQUFsQyxXQUFBLENBQUErQixHQUFBLEVBQUNHLFNBQVM7SUFBQSxHQUFLaEMsS0FBSztJQUFBMkIsUUFBQSxlQUFFLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM5QixpQkFBaUI7TUFBQSxHQUFLQztJQUFLLENBQUc7RUFBQyxDQUFXLENBQUMsR0FBR0QsaUJBQWlCLENBQUNDLEtBQUssQ0FBQztBQUNsSDtBQUFDaUMsRUFBQSxHQU51QkgsVUFBVTtBQU9sQyxTQUFTTixvQkFBb0JBLENBQUNJLEVBQUUsRUFBRU0sU0FBUyxFQUFFQyxLQUFLLEVBQUU7RUFDbEQsTUFBTSxJQUFJQyxLQUFLLENBQUMsV0FBVyxJQUFJRixTQUFTLEdBQUcsV0FBVyxHQUFHLFFBQVEsQ0FBQyxHQUFHLElBQUksR0FBR04sRUFBRSxHQUFHLG9FQUFvRSxJQUFJTyxLQUFLLEdBQUcscUNBQXFDLEdBQUdBLEtBQUssR0FBRyx1REFBdUQsR0FBRyxFQUFFLENBQUMsQ0FBQztBQUNqUjtBQUFDLElBQUFGLEVBQUE7QUFBQUksWUFBQSxDQUFBSixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}