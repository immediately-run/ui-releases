var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      li: "li",
      p: "p",
      strong: "strong",
      table: "table",
      tbody: "tbody",
      td: "td",
      th: "th",
      thead: "thead",
      tr: "tr",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "authors_view-implementation-status",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "authors_view-implementation-status"
      }), "AUTHORS_VIEW — implementation status"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Status:"
      }), " implemented at the deliverable level (R3-435, R3-436) · ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Updated:"
      }), " 2026-08-28"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["This document is the single implementation-status source for\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "docs/specs/AUTHORS_VIEW_SPEC.md"
      }), "; where they disagree, this document governs."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "shipped-2026-08-28",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "shipped-2026-08-28"
      }), "Shipped (2026-08-28)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "R3-435 — core."
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "(renumbered from R3-433 — id collision with a parallel main allocation; the docs items carry the note)"
        }), " The four reflection components (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "FormulaIndex"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "TestIndex"
        }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "DataInventory"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "SuiteSummary"
        }), ") in the catalog + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "componentMap"
        }), " + render layer\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/report/render/reflectionContext.ts"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "verdictChip.ts"
        }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "components/{FormulaIndex,TestIndex,DataInventory,SuiteSummary}.tsx"
        }), "); the\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ReflectionPort"
        }), " with allowlisted fixture/feed summaries and credential-stripped hosts\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/app/authorsView.ts"
        }), "); template-role selection (reserved ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "authors_view"
        }), " name +\nthe new optional manifest ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "authorsView"
        }), " key), the consumer pick excluding the\nauthor's view, per-template catalog validation, and the §6 consumer-template\ndiagnostic (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/app/reportSession.ts"
        }), ")."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "R3-436 — surface."
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "(renumbered from R3-434 — the same parallel-allocation collision as its sibling)"
        }), " The built-in scaffold with the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "## Decisions."
        }), " convention\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/app/authorsView.ts"
        }), "), the rendered view with its header and Back\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/app/AuthorsView.tsx"
        }), "), the door in the workbook panel, the verdicts hoist —\none app-level ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "useVerdicts"
        }), " now drives the panel, the inspector, and the reflection\nport (G-AV-10; the prior second instantiation in the panel is removed) — and the\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "FORMULA_AUTHORING_PROMPT"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Recording the decision"
        }), " standing duty with its labeled\nprivacy boundary."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "gate-coverage",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "gate-coverage"
      }), "Gate coverage"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Gate"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Test"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-AV-1"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/app/authorsSession.test.ts"
            }), " (scaffold when absent) + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "authorsView.test.tsx"
            }), " (full default render from a live port)"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-AV-2"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "both files (document file replaces default; omitted index stays omitted)"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-AV-3"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "authorsSession.test.ts"
            }), " + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "authorsView.test.tsx"
            }), " (selection; only-authors → empty report)"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-AV-4"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "authorsSession.test.ts"
            }), " (manifest ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "authorsView"
            }), " key)"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-AV-5"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "authorsView.test.tsx"
            }), " (unknown worksheet → broken tile)"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-AV-6"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "authorsView.test.tsx"
            }), " (panel-identical verdict classes; distinct pending; \"Running suites…\")"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-AV-7"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "authorsView.test.tsx"
            }), " (no port → author's-view-only tile, all four components)"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-AV-8"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "authorsView.test.tsx"
            }), " (scaffold parses + validates clean)"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-AV-9"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "authorsView.test.tsx"
            }), " (derived shape; declared tier as plain data; query-string credential, path, and secretRef name never rendered)"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-AV-10"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["By construction: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "WorkbookPanel"
            }), " no longer instantiates ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "useVerdicts"
            }), " — it receives App's single instance as a prop (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/App.tsx"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/app/WorkbookPanel.tsx"
            }), "); the port takes the same object (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "AuthorsView.tsx"
            }), ")."]
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "open-residuals-unchanged-from-the-spec",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "open-residuals-unchanged-from-the-spec"
      }), "Open residuals (unchanged from the spec)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["Materialize-on-customize (needs the write path); ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<Include>"
        }), "; per-cell editor deep\nlinks (R3-427); in-app deep-linking/routing for the view; the Q5 privacy-boundary\nmechanism; shared/anonymous deployment posture follows the workbook panel's."]
      }), "\n"]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/status/AUTHORS_VIEW_STATUS.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJjb2RlIiwiZW0iLCJoMSIsImgyIiwibGkiLCJwIiwic3Ryb25nIiwidGFibGUiLCJ0Ym9keSIsInRkIiwidGgiLCJ0aGVhZCIsInRyIiwidWwiLCJfcHJvdmlkZUNvbXBvbmVudHMiLCJjb21wb25lbnRzIiwiSGVhZGluZ0FuY2hvciIsIl9taXNzaW5nTWR4UmVmZXJlbmNlIiwianN4cyIsIkZyYWdtZW50IiwiY2hpbGRyZW4iLCJpZCIsImpzeCIsIk1EWENvbnRlbnQiLCJ3cmFwcGVyIiwiTURYTGF5b3V0IiwiX2MiLCJjb21wb25lbnQiLCJwbGFjZSIsIkVycm9yIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQVVUSE9SU19WSUVXX1NUQVRVUy5tZCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKkBqc3hSdW50aW1lIGF1dG9tYXRpYyovXG4vKkBqc3hJbXBvcnRTb3VyY2UgcmVhY3QqL1xuaW1wb3J0IHt1c2VNRFhDb21wb25lbnRzIGFzIF9wcm92aWRlQ29tcG9uZW50c30gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrL01EWFByb3ZpZGVyXCI7XG5mdW5jdGlvbiBfY3JlYXRlTWR4Q29udGVudChwcm9wcykge1xuICBjb25zdCBfY29tcG9uZW50cyA9IHtcbiAgICBjb2RlOiBcImNvZGVcIixcbiAgICBlbTogXCJlbVwiLFxuICAgIGgxOiBcImgxXCIsXG4gICAgaDI6IFwiaDJcIixcbiAgICBsaTogXCJsaVwiLFxuICAgIHA6IFwicFwiLFxuICAgIHN0cm9uZzogXCJzdHJvbmdcIixcbiAgICB0YWJsZTogXCJ0YWJsZVwiLFxuICAgIHRib2R5OiBcInRib2R5XCIsXG4gICAgdGQ6IFwidGRcIixcbiAgICB0aDogXCJ0aFwiLFxuICAgIHRoZWFkOiBcInRoZWFkXCIsXG4gICAgdHI6IFwidHJcIixcbiAgICB1bDogXCJ1bFwiLFxuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfSwge0hlYWRpbmdBbmNob3J9ID0gX2NvbXBvbmVudHM7XG4gIGlmICghSGVhZGluZ0FuY2hvcikgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJIZWFkaW5nQW5jaG9yXCIsIHRydWUpO1xuICByZXR1cm4gPD48X2NvbXBvbmVudHMuaDEgaWQ9XCJhdXRob3JzX3ZpZXctaW1wbGVtZW50YXRpb24tc3RhdHVzXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJhdXRob3JzX3ZpZXctaW1wbGVtZW50YXRpb24tc3RhdHVzXCIgLz57XCJBVVRIT1JTX1ZJRVcg4oCUIGltcGxlbWVudGF0aW9uIHN0YXR1c1wifTwvX2NvbXBvbmVudHMuaDE+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJTdGF0dXM6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGltcGxlbWVudGVkIGF0IHRoZSBkZWxpdmVyYWJsZSBsZXZlbCAoUjMtNDM1LCBSMy00MzYpIMK3IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiVXBkYXRlZDpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgMjAyNi0wOC0yOFwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGlzIGRvY3VtZW50IGlzIHRoZSBzaW5nbGUgaW1wbGVtZW50YXRpb24tc3RhdHVzIHNvdXJjZSBmb3JcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJkb2NzL3NwZWNzL0FVVEhPUlNfVklFV19TUEVDLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjsgd2hlcmUgdGhleSBkaXNhZ3JlZSwgdGhpcyBkb2N1bWVudCBnb3Zlcm5zLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzaGlwcGVkLTIwMjYtMDgtMjhcIj48SGVhZGluZ0FuY2hvciBpZD1cInNoaXBwZWQtMjAyNi0wOC0yOFwiIC8+e1wiU2hpcHBlZCAoMjAyNi0wOC0yOClcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJSMy00MzUg4oCUIGNvcmUuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5lbT57XCIocmVudW1iZXJlZCBmcm9tIFIzLTQzMyDigJQgaWQgY29sbGlzaW9uIHdpdGggYSBwYXJhbGxlbCBtYWluIGFsbG9jYXRpb247IHRoZSBkb2NzIGl0ZW1zIGNhcnJ5IHRoZSBub3RlKVwifTwvX2NvbXBvbmVudHMuZW0+e1wiIFRoZSBmb3VyIHJlZmxlY3Rpb24gY29tcG9uZW50cyAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRm9ybXVsYUluZGV4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiVGVzdEluZGV4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIixcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJEYXRhSW52ZW50b3J5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiU3VpdGVTdW1tYXJ5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikgaW4gdGhlIGNhdGFsb2cgKyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjb21wb25lbnRNYXBcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICsgcmVuZGVyIGxheWVyXFxuKFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9yZXBvcnQvcmVuZGVyL3JlZmxlY3Rpb25Db250ZXh0LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widmVyZGljdENoaXAudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcImNvbXBvbmVudHMve0Zvcm11bGFJbmRleCxUZXN0SW5kZXgsRGF0YUludmVudG9yeSxTdWl0ZVN1bW1hcnl9LnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpOyB0aGVcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJSZWZsZWN0aW9uUG9ydFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgd2l0aCBhbGxvd2xpc3RlZCBmaXh0dXJlL2ZlZWQgc3VtbWFyaWVzIGFuZCBjcmVkZW50aWFsLXN0cmlwcGVkIGhvc3RzXFxuKFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9hcHAvYXV0aG9yc1ZpZXcudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKTsgdGVtcGxhdGUtcm9sZSBzZWxlY3Rpb24gKHJlc2VydmVkIFwifTxfY29tcG9uZW50cy5jb2RlPntcImF1dGhvcnNfdmlld1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgbmFtZSArXFxudGhlIG5ldyBvcHRpb25hbCBtYW5pZmVzdCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJhdXRob3JzVmlld1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIga2V5KSwgdGhlIGNvbnN1bWVyIHBpY2sgZXhjbHVkaW5nIHRoZVxcbmF1dGhvcidzIHZpZXcsIHBlci10ZW1wbGF0ZSBjYXRhbG9nIHZhbGlkYXRpb24sIGFuZCB0aGUgwqc2IGNvbnN1bWVyLXRlbXBsYXRlXFxuZGlhZ25vc3RpYyAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2FwcC9yZXBvcnRTZXNzaW9uLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJSMy00MzYg4oCUIHN1cmZhY2UuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5lbT57XCIocmVudW1iZXJlZCBmcm9tIFIzLTQzNCDigJQgdGhlIHNhbWUgcGFyYWxsZWwtYWxsb2NhdGlvbiBjb2xsaXNpb24gYXMgaXRzIHNpYmxpbmcpXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgVGhlIGJ1aWx0LWluIHNjYWZmb2xkIHdpdGggdGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcIiMjIERlY2lzaW9ucy5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNvbnZlbnRpb25cXG4oXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2FwcC9hdXRob3JzVmlldy50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLCB0aGUgcmVuZGVyZWQgdmlldyB3aXRoIGl0cyBoZWFkZXIgYW5kIEJhY2tcXG4oXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2FwcC9BdXRob3JzVmlldy50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSwgdGhlIGRvb3IgaW4gdGhlIHdvcmtib29rIHBhbmVsLCB0aGUgdmVyZGljdHMgaG9pc3Qg4oCUXFxub25lIGFwcC1sZXZlbCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ1c2VWZXJkaWN0c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgbm93IGRyaXZlcyB0aGUgcGFuZWwsIHRoZSBpbnNwZWN0b3IsIGFuZCB0aGUgcmVmbGVjdGlvblxcbnBvcnQgKEctQVYtMTA7IHRoZSBwcmlvciBzZWNvbmQgaW5zdGFudGlhdGlvbiBpbiB0aGUgcGFuZWwgaXMgcmVtb3ZlZCkg4oCUIGFuZCB0aGVcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJGT1JNVUxBX0FVVEhPUklOR19QUk9NUFRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIFwifTxfY29tcG9uZW50cy5lbT57XCJSZWNvcmRpbmcgdGhlIGRlY2lzaW9uXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgc3RhbmRpbmcgZHV0eSB3aXRoIGl0cyBsYWJlbGVkXFxucHJpdmFjeSBib3VuZGFyeS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwiZ2F0ZS1jb3ZlcmFnZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiZ2F0ZS1jb3ZlcmFnZVwiIC8+e1wiR2F0ZSBjb3ZlcmFnZVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnRhYmxlPjxfY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRoPntcIkdhdGVcIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aD57XCJUZXN0XCJ9PC9fY29tcG9uZW50cy50aD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGhlYWQ+PF9jb21wb25lbnRzLnRib2R5PjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiRy1BVi0xXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2FwcC9hdXRob3JzU2Vzc2lvbi50ZXN0LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoc2NhZmZvbGQgd2hlbiBhYnNlbnQpICsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYXV0aG9yc1ZpZXcudGVzdC50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChmdWxsIGRlZmF1bHQgcmVuZGVyIGZyb20gYSBsaXZlIHBvcnQpXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiRy1BVi0yXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiYm90aCBmaWxlcyAoZG9jdW1lbnQgZmlsZSByZXBsYWNlcyBkZWZhdWx0OyBvbWl0dGVkIGluZGV4IHN0YXlzIG9taXR0ZWQpXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiRy1BVi0zXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiYXV0aG9yc1Nlc3Npb24udGVzdC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJhdXRob3JzVmlldy50ZXN0LnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKHNlbGVjdGlvbjsgb25seS1hdXRob3JzIOKGkiBlbXB0eSByZXBvcnQpXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiRy1BVi00XCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiYXV0aG9yc1Nlc3Npb24udGVzdC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKG1hbmlmZXN0IFwifTxfY29tcG9uZW50cy5jb2RlPntcImF1dGhvcnNWaWV3XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBrZXkpXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiRy1BVi01XCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiYXV0aG9yc1ZpZXcudGVzdC50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICh1bmtub3duIHdvcmtzaGVldCDihpIgYnJva2VuIHRpbGUpXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiRy1BVi02XCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiYXV0aG9yc1ZpZXcudGVzdC50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChwYW5lbC1pZGVudGljYWwgdmVyZGljdCBjbGFzc2VzOyBkaXN0aW5jdCBwZW5kaW5nOyBcXFwiUnVubmluZyBzdWl0ZXPigKZcXFwiKVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkctQVYtN1wifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcImF1dGhvcnNWaWV3LnRlc3QudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAobm8gcG9ydCDihpIgYXV0aG9yJ3Mtdmlldy1vbmx5IHRpbGUsIGFsbCBmb3VyIGNvbXBvbmVudHMpXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiRy1BVi04XCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiYXV0aG9yc1ZpZXcudGVzdC50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChzY2FmZm9sZCBwYXJzZXMgKyB2YWxpZGF0ZXMgY2xlYW4pXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiRy1BVi05XCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiYXV0aG9yc1ZpZXcudGVzdC50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChkZXJpdmVkIHNoYXBlOyBkZWNsYXJlZCB0aWVyIGFzIHBsYWluIGRhdGE7IHF1ZXJ5LXN0cmluZyBjcmVkZW50aWFsLCBwYXRoLCBhbmQgc2VjcmV0UmVmIG5hbWUgbmV2ZXIgcmVuZGVyZWQpXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiRy1BVi0xMFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIkJ5IGNvbnN0cnVjdGlvbjogXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiV29ya2Jvb2tQYW5lbFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgbm8gbG9uZ2VyIGluc3RhbnRpYXRlcyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ1c2VWZXJkaWN0c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIGl0IHJlY2VpdmVzIEFwcCdzIHNpbmdsZSBpbnN0YW5jZSBhcyBhIHByb3AgKFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9BcHAudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2FwcC9Xb3JrYm9va1BhbmVsLnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpOyB0aGUgcG9ydCB0YWtlcyB0aGUgc2FtZSBvYmplY3QgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIkF1dGhvcnNWaWV3LnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLlwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRib2R5PjwvX2NvbXBvbmVudHMudGFibGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwib3Blbi1yZXNpZHVhbHMtdW5jaGFuZ2VkLWZyb20tdGhlLXNwZWNcIj48SGVhZGluZ0FuY2hvciBpZD1cIm9wZW4tcmVzaWR1YWxzLXVuY2hhbmdlZC1mcm9tLXRoZS1zcGVjXCIgLz57XCJPcGVuIHJlc2lkdWFscyAodW5jaGFuZ2VkIGZyb20gdGhlIHNwZWMpXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIk1hdGVyaWFsaXplLW9uLWN1c3RvbWl6ZSAobmVlZHMgdGhlIHdyaXRlIHBhdGgpOyBcIn08X2NvbXBvbmVudHMuY29kZT57XCI8SW5jbHVkZT5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiOyBwZXItY2VsbCBlZGl0b3IgZGVlcFxcbmxpbmtzIChSMy00MjcpOyBpbi1hcHAgZGVlcC1saW5raW5nL3JvdXRpbmcgZm9yIHRoZSB2aWV3OyB0aGUgUTUgcHJpdmFjeS1ib3VuZGFyeVxcbm1lY2hhbmlzbTsgc2hhcmVkL2Fub255bW91cyBkZXBsb3ltZW50IHBvc3R1cmUgZm9sbG93cyB0aGUgd29ya2Jvb2sgcGFuZWwncy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+PC8+O1xufVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTURYQ29udGVudChwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHt3cmFwcGVyOiBNRFhMYXlvdXR9ID0ge1xuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfTtcbiAgcmV0dXJuIE1EWExheW91dCA/IDxNRFhMYXlvdXQgey4uLnByb3BzfT48X2NyZWF0ZU1keENvbnRlbnQgey4uLnByb3BzfSAvPjwvTURYTGF5b3V0PiA6IF9jcmVhdGVNZHhDb250ZW50KHByb3BzKTtcbn1cbmZ1bmN0aW9uIF9taXNzaW5nTWR4UmVmZXJlbmNlKGlkLCBjb21wb25lbnQsIHBsYWNlKSB7XG4gIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIFwiICsgKGNvbXBvbmVudCA/IFwiY29tcG9uZW50XCIgOiBcIm9iamVjdFwiKSArIFwiIGBcIiArIGlkICsgXCJgIHRvIGJlIGRlZmluZWQ6IHlvdSBsaWtlbHkgZm9yZ290IHRvIGltcG9ydCwgcGFzcywgb3IgcHJvdmlkZSBpdC5cIiArIChwbGFjZSA/IFwiXFxuSXTigJlzIHJlZmVyZW5jZWQgaW4geW91ciBjb2RlIGF0IGBcIiArIHBsYWNlICsgXCJgIGluIGAvYXBwL2RvY3Mvc3RhdHVzL0FVVEhPUlNfVklFV19TVEFUVVMubWRgXCIgOiBcIlwiKSk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUVBLElBQUFBLFlBQUEsR0FBQUMsT0FBQTtBQUF3RixJQUFBQyxXQUFBLEdBQUFELE9BQUE7QUFGeEY7QUFDQTs7QUFFQSxTQUFTRSxpQkFBaUJBLENBQUNDLEtBQUssRUFBRTtFQUNoQyxNQUFNQyxXQUFXLEdBQUc7TUFDbEJDLElBQUksRUFBRSxNQUFNO01BQ1pDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLENBQUMsRUFBRSxHQUFHO01BQ05DLE1BQU0sRUFBRSxRQUFRO01BQ2hCQyxLQUFLLEVBQUUsT0FBTztNQUNkQyxLQUFLLEVBQUUsT0FBTztNQUNkQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxLQUFLLEVBQUUsT0FBTztNQUNkQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSLEdBQUcsSUFBQUMsNkJBQWtCLEVBQUMsQ0FBQztNQUN2QixHQUFHaEIsS0FBSyxDQUFDaUI7SUFDWCxDQUFDO0lBQUU7TUFBQ0M7SUFBYSxDQUFDLEdBQUdqQixXQUFXO0VBQ2hDLElBQUksQ0FBQ2lCLGFBQWEsRUFBRUMsb0JBQW9CLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQztFQUMvRCxvQkFBTyxJQUFBckIsV0FBQSxDQUFBc0IsSUFBQSxFQUFBdEIsV0FBQSxDQUFBdUIsUUFBQTtJQUFBQyxRQUFBLGdCQUFFLElBQUF4QixXQUFBLENBQUFzQixJQUFBLEVBQUNuQixXQUFXLENBQUNHLEVBQUU7TUFBQ21CLEVBQUUsRUFBQyxvQ0FBb0M7TUFBQUQsUUFBQSxnQkFBQyxJQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFvQyxDQUFFLENBQUMsRUFBQyxzQ0FBc0M7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUFzQixJQUFBLEVBQUNuQixXQUFXLENBQUNNLENBQUM7TUFBQWUsUUFBQSxnQkFBQyxJQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDdkIsV0FBVyxDQUFDTyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFTLENBQXFCLENBQUMsRUFBQywyREFBMkQsZUFBQyxJQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDdkIsV0FBVyxDQUFDTyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFVLENBQXFCLENBQUMsRUFBQyxhQUFhO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBeEIsV0FBQSxDQUFBc0IsSUFBQSxFQUFDbkIsV0FBVyxDQUFDTSxDQUFDO01BQUFlLFFBQUEsR0FBRSxnRUFBZ0UsZUFBQyxJQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDdkIsV0FBVyxDQUFDQyxJQUFJO1FBQUFvQixRQUFBLEVBQUU7TUFBaUMsQ0FBbUIsQ0FBQyxFQUFDLCtDQUErQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQXNCLElBQUEsRUFBQ25CLFdBQVcsQ0FBQ0ksRUFBRTtNQUFDa0IsRUFBRSxFQUFDLG9CQUFvQjtNQUFBRCxRQUFBLGdCQUFDLElBQUF4QixXQUFBLENBQUEwQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQW9CLENBQUUsQ0FBQyxFQUFDLHNCQUFzQjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXNCLElBQUEsRUFBQ25CLFdBQVcsQ0FBQ2MsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUF4QixXQUFBLENBQUFzQixJQUFBLEVBQUNuQixXQUFXLENBQUNLLEVBQUU7UUFBQWdCLFFBQUEsZ0JBQUMsSUFBQXhCLFdBQUEsQ0FBQTBCLEdBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ08sTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBZ0IsQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDdkIsV0FBVyxDQUFDRSxFQUFFO1VBQUFtQixRQUFBLEVBQUU7UUFBd0csQ0FBaUIsQ0FBQyxFQUFDLG1DQUFtQyxlQUFDLElBQUF4QixXQUFBLENBQUEwQixHQUFBLEVBQUN2QixXQUFXLENBQUNDLElBQUk7VUFBQW9CLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQTBCLEdBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBb0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDdkIsV0FBVyxDQUFDQyxJQUFJO1VBQUFvQixRQUFBLEVBQUU7UUFBZSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF4QixXQUFBLENBQUEwQixHQUFBLEVBQUN2QixXQUFXLENBQUNDLElBQUk7VUFBQW9CLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUMsRUFBQyxxQkFBcUIsZUFBQyxJQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDdkIsV0FBVyxDQUFDQyxJQUFJO1VBQUFvQixRQUFBLEVBQUU7UUFBYyxDQUFtQixDQUFDLEVBQUMsb0JBQW9CLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQTBCLEdBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBb0IsUUFBQSxFQUFFO1FBQXdDLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQTBCLEdBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBb0IsUUFBQSxFQUFFO1FBQWdCLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQTBCLEdBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBb0IsUUFBQSxFQUFFO1FBQW9FLENBQW1CLENBQUMsRUFBQyxVQUFVLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQTBCLEdBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBb0IsUUFBQSxFQUFFO1FBQWdCLENBQW1CLENBQUMsRUFBQywyRUFBMkUsZUFBQyxJQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDdkIsV0FBVyxDQUFDQyxJQUFJO1VBQUFvQixRQUFBLEVBQUU7UUFBd0IsQ0FBbUIsQ0FBQyxFQUFDLHVDQUF1QyxlQUFDLElBQUF4QixXQUFBLENBQUEwQixHQUFBLEVBQUN2QixXQUFXLENBQUNDLElBQUk7VUFBQW9CLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUMsRUFBQyxxQ0FBcUMsZUFBQyxJQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDdkIsV0FBVyxDQUFDQyxJQUFJO1VBQUFvQixRQUFBLEVBQUU7UUFBYSxDQUFtQixDQUFDLEVBQUMsb0lBQW9JLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQTBCLEdBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBb0IsUUFBQSxFQUFFO1FBQTBCLENBQW1CLENBQUMsRUFBQyxJQUFJO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBeEIsV0FBQSxDQUFBc0IsSUFBQSxFQUFDbkIsV0FBVyxDQUFDSyxFQUFFO1FBQUFnQixRQUFBLGdCQUFDLElBQUF4QixXQUFBLENBQUEwQixHQUFBLEVBQUN2QixXQUFXLENBQUNPLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQW1CLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQTBCLEdBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ0UsRUFBRTtVQUFBbUIsUUFBQSxFQUFFO1FBQWtGLENBQWlCLENBQUMsRUFBQyxrQ0FBa0MsZUFBQyxJQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDdkIsV0FBVyxDQUFDQyxJQUFJO1VBQUFvQixRQUFBLEVBQUU7UUFBZSxDQUFtQixDQUFDLEVBQUMsZ0JBQWdCLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQTBCLEdBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ0MsSUFBSTtVQUFBb0IsUUFBQSxFQUFFO1FBQXdCLENBQW1CLENBQUMsRUFBQyxrREFBa0QsZUFBQyxJQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDdkIsV0FBVyxDQUFDQyxJQUFJO1VBQUFvQixRQUFBLEVBQUU7UUFBeUIsQ0FBbUIsQ0FBQyxFQUFDLHlFQUF5RSxlQUFDLElBQUF4QixXQUFBLENBQUEwQixHQUFBLEVBQUN2QixXQUFXLENBQUNDLElBQUk7VUFBQW9CLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyw4SUFBOEksZUFBQyxJQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDdkIsV0FBVyxDQUFDQyxJQUFJO1VBQUFvQixRQUFBLEVBQUU7UUFBMEIsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDdkIsV0FBVyxDQUFDRSxFQUFFO1VBQUFtQixRQUFBLEVBQUU7UUFBd0IsQ0FBaUIsQ0FBQyxFQUFDLG9EQUFvRDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBeEIsV0FBQSxDQUFBc0IsSUFBQSxFQUFDbkIsV0FBVyxDQUFDSSxFQUFFO01BQUNrQixFQUFFLEVBQUMsZUFBZTtNQUFBRCxRQUFBLGdCQUFDLElBQUF4QixXQUFBLENBQUEwQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQWUsQ0FBRSxDQUFDLEVBQUMsZUFBZTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXNCLElBQUEsRUFBQ25CLFdBQVcsQ0FBQ1EsS0FBSztNQUFBYSxRQUFBLGdCQUFDLElBQUF4QixXQUFBLENBQUEwQixHQUFBLEVBQUN2QixXQUFXLENBQUNZLEtBQUs7UUFBQVMsUUFBQSxlQUFDLElBQUF4QixXQUFBLENBQUFzQixJQUFBLEVBQUNuQixXQUFXLENBQUNhLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDdkIsV0FBVyxDQUFDVyxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFNLENBQWlCLENBQUMsbUJBQUF4QixXQUFBLENBQUEwQixHQUFBLEVBQUN2QixXQUFXLENBQUNXLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQU0sQ0FBaUIsQ0FBQztRQUFBLENBQWdCO01BQUMsQ0FBbUIsQ0FBQyxtQkFBQXhCLFdBQUEsQ0FBQXNCLElBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsS0FBSztRQUFBWSxRQUFBLGdCQUFDLElBQUF4QixXQUFBLENBQUFzQixJQUFBLEVBQUNuQixXQUFXLENBQUNhLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDdkIsV0FBVyxDQUFDVSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFRLENBQWlCLENBQUMsbUJBQUF4QixXQUFBLENBQUFzQixJQUFBLEVBQUNuQixXQUFXLENBQUNVLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDdkIsV0FBVyxDQUFDQyxJQUFJO2NBQUFvQixRQUFBLEVBQUU7WUFBZ0MsQ0FBbUIsQ0FBQyxFQUFDLDRCQUE0QixlQUFDLElBQUF4QixXQUFBLENBQUEwQixHQUFBLEVBQUN2QixXQUFXLENBQUNDLElBQUk7Y0FBQW9CLFFBQUEsRUFBRTtZQUFzQixDQUFtQixDQUFDLEVBQUMseUNBQXlDO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUF4QixXQUFBLENBQUFzQixJQUFBLEVBQUNuQixXQUFXLENBQUNhLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDdkIsV0FBVyxDQUFDVSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFRLENBQWlCLENBQUMsbUJBQUF4QixXQUFBLENBQUEwQixHQUFBLEVBQUN2QixXQUFXLENBQUNVLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQTBFLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBeEIsV0FBQSxDQUFBc0IsSUFBQSxFQUFDbkIsV0FBVyxDQUFDYSxFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQXhCLFdBQUEsQ0FBQTBCLEdBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBUSxDQUFpQixDQUFDLG1CQUFBeEIsV0FBQSxDQUFBc0IsSUFBQSxFQUFDbkIsV0FBVyxDQUFDVSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQXhCLFdBQUEsQ0FBQTBCLEdBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBb0IsUUFBQSxFQUFFO1lBQXdCLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQTBCLEdBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBb0IsUUFBQSxFQUFFO1lBQXNCLENBQW1CLENBQUMsRUFBQywyQ0FBMkM7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQXhCLFdBQUEsQ0FBQXNCLElBQUEsRUFBQ25CLFdBQVcsQ0FBQ2EsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUF4QixXQUFBLENBQUEwQixHQUFBLEVBQUN2QixXQUFXLENBQUNVLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQVEsQ0FBaUIsQ0FBQyxtQkFBQXhCLFdBQUEsQ0FBQXNCLElBQUEsRUFBQ25CLFdBQVcsQ0FBQ1UsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUF4QixXQUFBLENBQUEwQixHQUFBLEVBQUN2QixXQUFXLENBQUNDLElBQUk7Y0FBQW9CLFFBQUEsRUFBRTtZQUF3QixDQUFtQixDQUFDLEVBQUMsYUFBYSxlQUFDLElBQUF4QixXQUFBLENBQUEwQixHQUFBLEVBQUN2QixXQUFXLENBQUNDLElBQUk7Y0FBQW9CLFFBQUEsRUFBRTtZQUFhLENBQW1CLENBQUMsRUFBQyxPQUFPO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUF4QixXQUFBLENBQUFzQixJQUFBLEVBQUNuQixXQUFXLENBQUNhLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDdkIsV0FBVyxDQUFDVSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFRLENBQWlCLENBQUMsbUJBQUF4QixXQUFBLENBQUFzQixJQUFBLEVBQUNuQixXQUFXLENBQUNVLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDdkIsV0FBVyxDQUFDQyxJQUFJO2NBQUFvQixRQUFBLEVBQUU7WUFBc0IsQ0FBbUIsQ0FBQyxFQUFDLG9DQUFvQztVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBeEIsV0FBQSxDQUFBc0IsSUFBQSxFQUFDbkIsV0FBVyxDQUFDYSxFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQXhCLFdBQUEsQ0FBQTBCLEdBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBUSxDQUFpQixDQUFDLG1CQUFBeEIsV0FBQSxDQUFBc0IsSUFBQSxFQUFDbkIsV0FBVyxDQUFDVSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQXhCLFdBQUEsQ0FBQTBCLEdBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBb0IsUUFBQSxFQUFFO1lBQXNCLENBQW1CLENBQUMsRUFBQywyRUFBMkU7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQXhCLFdBQUEsQ0FBQXNCLElBQUEsRUFBQ25CLFdBQVcsQ0FBQ2EsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUF4QixXQUFBLENBQUEwQixHQUFBLEVBQUN2QixXQUFXLENBQUNVLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQVEsQ0FBaUIsQ0FBQyxtQkFBQXhCLFdBQUEsQ0FBQXNCLElBQUEsRUFBQ25CLFdBQVcsQ0FBQ1UsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUF4QixXQUFBLENBQUEwQixHQUFBLEVBQUN2QixXQUFXLENBQUNDLElBQUk7Y0FBQW9CLFFBQUEsRUFBRTtZQUFzQixDQUFtQixDQUFDLEVBQUMsMkRBQTJEO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUF4QixXQUFBLENBQUFzQixJQUFBLEVBQUNuQixXQUFXLENBQUNhLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDdkIsV0FBVyxDQUFDVSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFRLENBQWlCLENBQUMsbUJBQUF4QixXQUFBLENBQUFzQixJQUFBLEVBQUNuQixXQUFXLENBQUNVLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDdkIsV0FBVyxDQUFDQyxJQUFJO2NBQUFvQixRQUFBLEVBQUU7WUFBc0IsQ0FBbUIsQ0FBQyxFQUFDLHNDQUFzQztVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBeEIsV0FBQSxDQUFBc0IsSUFBQSxFQUFDbkIsV0FBVyxDQUFDYSxFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQXhCLFdBQUEsQ0FBQTBCLEdBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBUSxDQUFpQixDQUFDLG1CQUFBeEIsV0FBQSxDQUFBc0IsSUFBQSxFQUFDbkIsV0FBVyxDQUFDVSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQXhCLFdBQUEsQ0FBQTBCLEdBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBb0IsUUFBQSxFQUFFO1lBQXNCLENBQW1CLENBQUMsRUFBQyxpSEFBaUg7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQXhCLFdBQUEsQ0FBQXNCLElBQUEsRUFBQ25CLFdBQVcsQ0FBQ2EsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUF4QixXQUFBLENBQUEwQixHQUFBLEVBQUN2QixXQUFXLENBQUNVLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQVMsQ0FBaUIsQ0FBQyxtQkFBQXhCLFdBQUEsQ0FBQXNCLElBQUEsRUFBQ25CLFdBQVcsQ0FBQ1UsRUFBRTtZQUFBVyxRQUFBLEdBQUUsbUJBQW1CLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQTBCLEdBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBb0IsUUFBQSxFQUFFO1lBQWUsQ0FBbUIsQ0FBQyxFQUFDLDBCQUEwQixlQUFDLElBQUF4QixXQUFBLENBQUEwQixHQUFBLEVBQUN2QixXQUFXLENBQUNDLElBQUk7Y0FBQW9CLFFBQUEsRUFBRTtZQUFhLENBQW1CLENBQUMsRUFBQyxrREFBa0QsZUFBQyxJQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDdkIsV0FBVyxDQUFDQyxJQUFJO2NBQUFvQixRQUFBLEVBQUU7WUFBYSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF4QixXQUFBLENBQUEwQixHQUFBLEVBQUN2QixXQUFXLENBQUNDLElBQUk7Y0FBQW9CLFFBQUEsRUFBRTtZQUEyQixDQUFtQixDQUFDLEVBQUMscUNBQXFDLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQTBCLEdBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ0MsSUFBSTtjQUFBb0IsUUFBQSxFQUFFO1lBQWlCLENBQW1CLENBQUMsRUFBQyxJQUFJO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUM7TUFBQSxDQUFtQixDQUFDO0lBQUEsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBeEIsV0FBQSxDQUFBc0IsSUFBQSxFQUFDbkIsV0FBVyxDQUFDSSxFQUFFO01BQUNrQixFQUFFLEVBQUMsd0NBQXdDO01BQUFELFFBQUEsZ0JBQUMsSUFBQXhCLFdBQUEsQ0FBQTBCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBd0MsQ0FBRSxDQUFDLEVBQUMsMENBQTBDO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBc0IsSUFBQSxFQUFDbkIsV0FBVyxDQUFDYyxFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXhCLFdBQUEsQ0FBQXNCLElBQUEsRUFBQ25CLFdBQVcsQ0FBQ0ssRUFBRTtRQUFBZ0IsUUFBQSxHQUFFLG1EQUFtRCxlQUFDLElBQUF4QixXQUFBLENBQUEwQixHQUFBLEVBQUN2QixXQUFXLENBQUNDLElBQUk7VUFBQW9CLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyx5TEFBeUw7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUM7RUFBQSxDQUFFLENBQUM7QUFDdHVOO0FBQ2UsU0FBU0csVUFBVUEsQ0FBQ3pCLEtBQUssR0FBRyxDQUFDLENBQUMsRUFBRTtFQUM3QyxNQUFNO0lBQUMwQixPQUFPLEVBQUVDO0VBQVMsQ0FBQyxHQUFHO0lBQzNCLEdBQUcsSUFBQVgsNkJBQWtCLEVBQUMsQ0FBQztJQUN2QixHQUFHaEIsS0FBSyxDQUFDaUI7RUFDWCxDQUFDO0VBQ0QsT0FBT1UsU0FBUyxnQkFBRyxJQUFBN0IsV0FBQSxDQUFBMEIsR0FBQSxFQUFDRyxTQUFTO0lBQUEsR0FBSzNCLEtBQUs7SUFBQXNCLFFBQUEsZUFBRSxJQUFBeEIsV0FBQSxDQUFBMEIsR0FBQSxFQUFDekIsaUJBQWlCO01BQUEsR0FBS0M7SUFBSyxDQUFHO0VBQUMsQ0FBVyxDQUFDLEdBQUdELGlCQUFpQixDQUFDQyxLQUFLLENBQUM7QUFDbEg7QUFBQzRCLEVBQUEsR0FOdUJILFVBQVU7QUFPbEMsU0FBU04sb0JBQW9CQSxDQUFDSSxFQUFFLEVBQUVNLFNBQVMsRUFBRUMsS0FBSyxFQUFFO0VBQ2xELE1BQU0sSUFBSUMsS0FBSyxDQUFDLFdBQVcsSUFBSUYsU0FBUyxHQUFHLFdBQVcsR0FBRyxRQUFRLENBQUMsR0FBRyxJQUFJLEdBQUdOLEVBQUUsR0FBRyxvRUFBb0UsSUFBSU8sS0FBSyxHQUFHLHFDQUFxQyxHQUFHQSxLQUFLLEdBQUcsZ0RBQWdELEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDMVE7QUFBQyxJQUFBRixFQUFBO0FBQUFJLFlBQUEsQ0FBQUosRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}