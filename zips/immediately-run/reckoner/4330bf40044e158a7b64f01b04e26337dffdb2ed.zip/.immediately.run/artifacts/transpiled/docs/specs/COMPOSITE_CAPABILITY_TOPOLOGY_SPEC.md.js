var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      blockquote: "blockquote",
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      h3: "h3",
      hr: "hr",
      li: "li",
      ol: "ol",
      p: "p",
      pre: "pre",
      strong: "strong",
      table: "table",
      tbody: "tbody",
      td: "td",
      th: "th",
      thead: "thead",
      tr: "tr",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "immediatelyrun-composite-capability-lifecycle-topology-how-a-multi-realm-apps-grants-compose",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "immediatelyrun-composite-capability-lifecycle-topology-how-a-multi-realm-apps-grants-compose"
      }), "immediately.run Composite Capability & Lifecycle Topology — how a multi-realm app's grants compose"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Status:"
      }), " proposal / draft — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Spine 2"
      }), " of the Reckoner up-front-design triage\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "../ARCHITECTURE_PLAN.md"
      }), " §0.1), but written as a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "platform"
      }), " spec: it\ngeneralizes to any composite app, with Reckoner as the forcing consumer. It resolves how the\nfour separately-specified deltas — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "D1"
      }), " (per-instance delegation), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "D7/AA-01"
      }), " (program-identity\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "appKey"
      }), "), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "D8"
      }), " (launch-to-run / standing-app lifecycle), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "D9"
      }), " (redacted mount) — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "compose"
      }), "\ninto one grant topology. Rides the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "design-pending D8"
      }), ". Design only; nothing built. · ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Updated:"
      }), " 2026-07-09"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["The single implementation-status source for this spec is\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "docs/status/COMPOSITE_CAPABILITY_TOPOLOGY_STATUS.md"
          })]
        }), " (to be created at build) — where they\ndisagree, the status doc governs."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Reads first:"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "STANDING_APP_LIFECYCLE_SPEC.md"
        }), " §4.1/§5/§5.1/§6.1 (launch, keep-warm,\nteardown, per-instance delegation — the D8 substrate); ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "AGENT_AUTHORING_ARCHITECTURE.md"
        }), " §5/§5.1\n(program identity, AA-01/D7); ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "UI_AS_APPS_SPEC.md"
        }), " §8.15 (attenuated delegation, downward-only),\n§5.7 (task model), §8.1 (downward-only authority); ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "REPORTING_SPREADSHEET_SPEC.md"
        }), " §3.2 (the\nno-both invariant this topology enforces structurally), §6 (the composite), §11 (RS-1/RS-6\ncontainment); ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "../ARCHITECTURE_PLAN.md"
        }), " §2 (the four realms), §9 (the deltas);\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ENGINE_INFORMATION_FLOW_SPEC.md"
        }), " §5 OQ-3 (the \"audience\" principals this spec must make\ndistinguishable). Companion: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "HOLDOUT_REDACTED_MOUNT_SPEC.md"
        }), " (D9, the assistant's mount scope)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-0",
      "data-slug": "0-why-this-is-up-front-and-why-one-spec-normative-intent",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-0"
      }), "0. Why this is up-front, and why one spec  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative intent)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The composite's isolation is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "the"
      }), " confidentiality property (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "REPORTING §3.1"
      }), "): every realm's\n\"it cannot reach X\" claim is a claim about ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "which grant it holds and for how long"
      }), ". Today that\nis specified in four fragments — D1/D7/D8/D9 each design a piece — with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "no single statement of\nwho mints which grant to which realm, at what tier, and over what lifetime."
      }), " Fragmentary\ncapability specs are exactly what failed twice in Reckoner's runtime design (adversarial-review-2);\nthe capability ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "topology"
      }), " is more dangerous to leave fragmentary, because a gap is not a glitch —\nit is a silent authority the isolation model assumed away."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Two facts make this up-front:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "It rides the design-pending D8"
        }), " (launch-to-run / standing-app lifecycle, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "STANDING_APP_LIFECYCLE"
        }), "\nOpen Q#10). Grants have ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "lifetimes"
        }), " tied to member launch/teardown; without the lifecycle\nmodel, \"the connector's grant exists only while its feed is live\" has no mechanism."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["It is the thing that turns the no-both invariant from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "app discipline"
          }), " into ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "host\nenforcement"
          }), "."]
        }), " Pre-D7/D8/D9 the four-realm isolation is a fork-weakenable fiction (the plan\nadmits this, PD-6/M7); the composed topology is what makes it real. Getting the composition\nwrong means the isolation is fiction ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "even after"
        }), " the deltas land."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-1",
      "data-slug": "1-the-composite-is-a-set-of-principals-not-a-principal-normative",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-1"
      }), "1. The composite is a set of principals, not a principal  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["A composite (Reckoner: report-view root + engine + connector + assistant) is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "N distinct\nprogram identities"
      }), ", one ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "appKey"
      }), " per realm (D7/AA-01). Grants ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "key per realm and never\nmerge"
      }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "REPORTING §6"
      }), " RB-1: no composite principal, no merged bundle). Each realm earns its\nown authority; the root ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "launches"
      }), " members but does not ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "lend"
      }), " them its grants ambiently\n(downward-only, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "UI_AS_APPS §8.1"
      }), "). Membership is binding-resolved roles, user-overridable, and\nthe trust badge reflects the actually-bound provider (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "REPORTING §6.1"
      }), ")."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-2",
      "data-slug": "2-the-realm-capability-minting-authority-lifetime-matrix-proposal-the-heart",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-2"
      }), "2. The realm × capability × minting-authority × lifetime matrix  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(proposal — the heart)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["For Reckoner's four realms (the pattern generalizes: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "{holds, minted-by, tier, lifetime}"
      }), " per\nrealm). \"Minted-by\" is the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "only"
      }), " principal that may create the grant; \"lifetime\" is when it\nexists (§3)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Realm (appKey)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Holds"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Minted by"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Tier"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Lifetime"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Report-view (root)"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "rw@self"
            }), " (its source + the document, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "defined as the enumerated authoring subtrees"
            }), ", D9); the composite-root right to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "launch members"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "host, from the user's grant at composite open"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "the document's mount tier"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "the session (open → close)"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Engine"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "nothing"
            }), " — starved by design (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "REPORTING §3.1"
            }), "); input injection is host-brokered, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "not a grant"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["host mints an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "empty bundle"
            }), " (D7 gate: the engine entry point resolves to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "{}"
            }), ")"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "n/a (holds no data-bearing grant)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "launched with the root; warm across recomputes; torn down at close"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Connector"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "feed:fetch"
            }), " (template-bound, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "not"
            }), " general ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "net:fetch"
            }), " — D2), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "secrets:use"
            }), " (use-not-read), per-instance-delegated ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "narrow source reads"
            }), " (D1)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["host, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "per feed-instance, at feed-activation consent"
            }), " (individual, never bundled — RB-3)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "one tier per feed-instance (RQ-E2)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "per feed-instance:"
            }), " launched at activation, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "kept warm"
            }), " while the feed is live (poll/subscription), torn down at deactivation or session end"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Assistant"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "llm:chat"
            }), " (egress), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "rw@self"
            }), " (authoring subtrees; ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
              children: ["further redacted to exclude ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                children: ".holdout/"
              }), " during inference"]
            }), " — D9)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "host, at assistant launch"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["its read tier follows the document; taints on reading M3 (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "§8.1"
            }), ")"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "launched on demand; warm during a session; torn down"
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Minting rules (the invariant behind the matrix):"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Only the host mints a grant to a realm."
        }), " No realm mints for a sibling. The root may\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "attenuate"
        }), " a capability it ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "already holds"
        }), " down to a member (the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "edit-file"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "capDir"
        }), "\npattern, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "§8.15"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "DelegatableMount"
        }), ") — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "downward-only, never amplifying"
        }), " (a member cannot\nreceive more than the root holds; escape → fail-closed)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "A grant's tier is host-authoritative"
        }), " (the mount/feed tier), never content- or\nmember-declared (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ENGINE_INFORMATION_FLOW §3"
        }), ")."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Per-instance grants are keyed on a host-minted instance id"
        }), " (D1 + D2's anti-bucket rule):\ntwo instances of one connector ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "appKey"
        }), " share ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "no"
        }), " source grant."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-3",
      "data-slug": "3-the-lifecycle-state-machine-grants-live-and-die-with-members-normative-the-d8-dependency",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-3"
      }), "3. The lifecycle state machine — grants live and die with members  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative — the D8 dependency)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Every member moves through a host-driven lifecycle; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "a grant exists iff its member is in a live\nstate, and teardown revokes it."
      }), " This is the D8 substrate (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "STANDING_APP_LIFECYCLE §4.1/§6.1"
      }), ")."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "  unlaunched ──launch──► live ──idle──► warm ──resume──► live\n                          │               │\n                          └──teardown─────┴──► torn-down   (grants revoked)\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Report-view root:"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "launch"
        }), " at document open → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "live"
        }), " for the session → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "teardown"
        }), " at\nclose. Its launch is what mints the members' launch right."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Engine:"
        }), " launched with the root (rendering needs it); ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "warm"
        }), " between recomputes (keep-warm\navoids re-", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "lockdown()"
        }), " cost); ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "teardown"
        }), " at close ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "or"
        }), " on the synchronous-runaway rebuild\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ARCHITECTURE_PLAN §4.1"
        }), " — a whole-context teardown that re-launches from host-side state).\nIt holds nothing, so teardown revokes nothing sensitive — but its ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "output channels"
        }), " are\ngoverned separately (Spine 1)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Connector:"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "one lifecycle per feed-instance."
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "launch"
        }), " at feed-activation consent; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "warm"
        }), "\nwhile the feed is live (a poll timer / open subscription must persist — this is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "the"
        }), " reason\nD8 keep-warm is load-bearing here); ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "teardown"
        }), " at feed deactivation or session end, which\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["revokes that instance's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "feed:fetch"
          }), " + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "secrets:use"
          }), " + source-read"]
        }), ". A keep-warm connector\nacross a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "tier change"
        }), " must ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "re-tier or be torn down"
        }), " (ties to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ARCHITECTURE_PLAN §4.2"
        }), " F7:\nan autonomous tier drop re-floors; it cannot silently keep a stale higher grant warm)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Assistant:"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "launch"
        }), " on demand; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "warm"
        }), " during the session; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "teardown"
        }), " on session end. Its\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".holdout/"
        }), "-redaction (D9) is a property of the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "standing"
        }), " grant, not a mode — there is no\nwarm state in which it holds a broader mount (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "HOLDOUT §4"
        }), ")."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "The keep-warm covert-channel note:"
      }), " a member's launch/teardown ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "timing"
      }), " is a ~1-bit\nside-channel (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "STANDING_APP_LIFECYCLE §6.4"
      }), "). Debounce a member's self-exit so it is\nindistinguishable from a user-driven teardown — carried here as a composition requirement, not\nre-derived."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-4",
      "data-slug": "4-how-the-four-deltas-compose-the-point-of-the-spec-normative",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-4"
      }), "4. How the four deltas compose — the point of the spec  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Each delta supplies one axis; the topology is their product, and the no-both invariant\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "REPORTING §3.2"
      }), ") is enforced structurally ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "only when all four hold"
      }), ":"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Delta"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Axis it supplies"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Without it"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "D7 / AA-01"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
              children: "identity"
            }), " — a distinct ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "appKey"
            }), " per realm, so grants key per realm"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["all realms share one ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "appKey"
            }), "; grants ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "bleed"
            }), " (the M7 window: the engine effectively holds the assistant's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "llm:chat"
            }), ")"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "D8"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
              children: "lifetime"
            }), " — per-instance launch / keep-warm / teardown, so a grant exists only while its member does"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["grants have no teardown; a deactivated feed's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "secrets:use"
            }), " persists; keep-warm impossible → no live feeds"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "D1"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
              children: "instance isolation"
            }), " — per-instance delegation, so two instances of one ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "appKey"
            }), " share no source grant"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "one connector's feeds cross-contaminate; over-broad source reads"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "D9"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
              children: "intra-realm scope"
            }), " — the assistant's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "rw@self"
            }), " is the authoring subtrees, redacted during inference"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["the assistant reads ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: ".holdout/"
            }), " and any document path trivially"]
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "The composition invariant:"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.em, {
        children: ["no realm ever simultaneously (a) executes content as code, (b)\nholds a Class-B capability, and (c) hosts an injectable agent — and the grant topology makes each\nof a/b/c a property of a distinct ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "appKey"
        }), " with a bounded lifetime, so a fork cannot merge them."]
      }), "\nThe engine executes content (a) but holds nothing (¬b) and hosts no agent (¬c); the connector\nholds Class-B (b) but executes no content (¬a, D2 target-fixing) and hosts no agent (¬c); the\nassistant hosts an agent (c) but is Class-A only (¬b) and executes no content (¬a). D7 keeps\nthese three ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "appKey"
      }), "s distinct; D8 bounds their lifetimes; D1/D9 scope them. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Pre-any-of-these\nthe invariant is app discipline (fiction); post-all-four it is structural."
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-5",
      "data-slug": "5-adversarial-composition-checks-normative-intent",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-5"
      }), "5. Adversarial composition checks  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative intent)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Engine as confused deputy."
        }), " It holds nothing, so it cannot be steered to egress — but its\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "output"
        }), " is data that could carry M3 tiers/holdout. Contained by ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Spine 1"
        }), " (the channel\ncontract), not by this topology; noted so the boundary is explicit."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Root amplifying a member."
        }), " The root attenuates a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "capDir"
        }), " to a member (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "edit-file"
        }), "); the\nchroot is downward-only and fail-closed (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "attenuateDelta"
        }), "), so a member cannot receive a\ncapability the root lacks. Verified sound in D9's review."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Connector keep-warm across a tier drop."
        }), " The warm instance cannot silently retain a higher\ngrant; the lifecycle forces re-tier or teardown (§3), composing with F7 monotonicity."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The shared-appKey window (pre-D7)."
        }), " Honest fiction, bounded to author's-own-documents-only\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ARCHITECTURE_PLAN"
        }), " R-2/M7); this spec is the definition of when it ends (D7+D8+D9 all live)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Cross-member task invocation."
        }), " A member invoking another (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "§5.7"
        }), ") satisfies the callee's\nrequired delta from the caller's own grants, attenuated (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "§8.15"
        }), ") — never amplified; undeclared\ninvocations rejected (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "REPORTING"
        }), " §6 ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "invokes"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "provides"
        }), ")."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-6",
      "data-slug": "6-load-bearing-assumptions-code-anchors",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-6"
      }), "6. Load-bearing assumptions & code anchors"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "depends-on-today-verified-2026-07-09",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "depends-on-today-verified-2026-07-09"
      }), "Depends-on-today (verified 2026-07-09)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Assumption (existing behavior the design rests on)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Anchor (repo-relative file)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Token (grep-stable)"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Delegation is downward-only, chroot-inside-caller, fail-closed"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "immediately-run-site-main/src/editor/task/attenuateDelta.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "DelegatableMount"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["A capability's effective set is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "manifest ∩ grant"
            }), " (least privilege both ends)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "immediately-run-site-main/src/registry/netFetchPolicy.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "effectiveAllowlist"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "A frame's held capabilities are set host-side per app/consent, not self-declared"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "immediately-run-site-main/src/editor/SandboxListener.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "net:fetch"
            })
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "must-establish-new-invariants-the-implementation-creates",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "must-establish-new-invariants-the-implementation-creates"
      }), "Must-establish (new invariants the implementation creates)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "New invariant"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Proven by (gate test)"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Each realm resolves to a distinct ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "appKey"
            }), "; grants do not merge (D7)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["sibling-isolation gate: two entry points of one repo hold disjoint bundles; the engine resolves to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "{}"
            })]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "A grant exists iff its member is live; teardown revokes it (D8)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["lifetime gate: a deactivated feed-instance's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "secrets:use"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "feed:fetch"
            }), " is revoked; a torn-down member holds nothing"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Per-instance grants share no source across instances of one ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "appKey"
            }), " (D1)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "per-instance gate: two connector instances hold disjoint source grants; instance id is host-minted"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "No realm holds two of {executes content, Class-B cap, injectable agent}"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "no-both gate: the engine/connector/assistant each fail the two-of-three check under a hostile fork"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "The root can attenuate but never amplify a member's grant"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "amplification gate: a member cannot receive a capability the root lacks (fail-closed)"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Member launch/teardown timing is debounced (covert-channel bound)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "timing gate: a member self-exit is indistinguishable from a user teardown"
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-7",
      "data-slug": "7-decisions-rejected-alternatives",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-7"
      }), "7. Decisions & rejected alternatives"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "One topology spec composing D1/D7/D8/D9; the composite is N principals, grants never merge."
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " leaving the four deltas as independent fragments (the isolation property has no\nsingle owner — the gap this spec closes); a composite ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "principal"
        }), " with a merged bundle\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "REPORTING"
        }), " RB-1: a fork lies; grants must key per realm)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Grants have lifetimes tied to member launch/teardown (rides D8)."
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " session-long\nstatic grants (a deactivated feed keeps ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "secrets:use"
        }), "); no keep-warm (no live feeds)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Only the host mints; the root attenuates downward-only."
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " peer-to-peer grant\nlending between realms (amplification path); ambient inheritance from the root."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The no-both invariant is structural only post-D7+D8+D9; honest as app-discipline before."
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " claiming structural isolation before the deltas land (the M7 fiction)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Written as a platform spec, not a Reckoner-internal one."
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " scoping it to Reckoner\n(it generalizes to any composite; Reckoner is the forcing consumer, and D8 is platform work)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-8",
      "data-slug": "8-open-questions",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-8"
      }), "8. Open questions"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "OQ-1 (D8 is design-pending)."
        }), " The launch-to-run / keep-warm / teardown substrate\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "STANDING_APP_LIFECYCLE"
        }), " Open Q#10) is itself not fully designed. This spec ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "assumes"
        }), " its\nshape (per-instance launch, keep-warm, teardown revokes); the D8 design must confirm the\nlifetime semantics this topology rests on, especially keep-warm state isolation across a\ntier change."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "OQ-2 (the composite consent surface)."
        }), " The matrix (§2) says grants are minted \"at\nactivation consent, individual never bundled.\" The ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "aggregate"
        }), " picture — the reach view + the\nwrite-sink consent (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "CONNECTOR_EGRESS_FIXING §2.1"
        }), ") + per-member revoke — is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "REPORTING §6"
        }), "\nD6/RB-6 and unvalidated (the E3 study). Where does the per-realm minting story meet the\naggregate consent UI? Likely: D6 owns the surface, this spec owns what each consent ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "grants"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["OQ-3 (dogfooding recursion, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "ARCHITECTURE_PLAN §0.2"
          }), " S6)."]
        }), " Running the real four-realm\ncomposite ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "in-platform"
        }), " needs this topology built — the recursion. Confirm the in-platform\nhost can express a multi-appKey composite launch before M3, or the dogfooding of the live app\nwaits on it."]
      }), "\n"]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/specs/COMPOSITE_CAPABILITY_TOPOLOGY_SPEC.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJibG9ja3F1b3RlIiwiY29kZSIsImVtIiwiaDEiLCJoMiIsImgzIiwiaHIiLCJsaSIsIm9sIiwicCIsInByZSIsInN0cm9uZyIsInRhYmxlIiwidGJvZHkiLCJ0ZCIsInRoIiwidGhlYWQiLCJ0ciIsInVsIiwiX3Byb3ZpZGVDb21wb25lbnRzIiwiY29tcG9uZW50cyIsIkhlYWRpbmdBbmNob3IiLCJfbWlzc2luZ01keFJlZmVyZW5jZSIsImpzeHMiLCJGcmFnbWVudCIsImNoaWxkcmVuIiwiaWQiLCJqc3giLCJNRFhDb250ZW50Iiwid3JhcHBlciIsIk1EWExheW91dCIsIl9jIiwiY29tcG9uZW50IiwicGxhY2UiLCJFcnJvciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkNPTVBPU0lURV9DQVBBQklMSVRZX1RPUE9MT0dZX1NQRUMubWQiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgYmxvY2txdW90ZTogXCJibG9ja3F1b3RlXCIsXG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgZW06IFwiZW1cIixcbiAgICBoMTogXCJoMVwiLFxuICAgIGgyOiBcImgyXCIsXG4gICAgaDM6IFwiaDNcIixcbiAgICBocjogXCJoclwiLFxuICAgIGxpOiBcImxpXCIsXG4gICAgb2w6IFwib2xcIixcbiAgICBwOiBcInBcIixcbiAgICBwcmU6IFwicHJlXCIsXG4gICAgc3Ryb25nOiBcInN0cm9uZ1wiLFxuICAgIHRhYmxlOiBcInRhYmxlXCIsXG4gICAgdGJvZHk6IFwidGJvZHlcIixcbiAgICB0ZDogXCJ0ZFwiLFxuICAgIHRoOiBcInRoXCIsXG4gICAgdGhlYWQ6IFwidGhlYWRcIixcbiAgICB0cjogXCJ0clwiLFxuICAgIHVsOiBcInVsXCIsXG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9LCB7SGVhZGluZ0FuY2hvcn0gPSBfY29tcG9uZW50cztcbiAgaWYgKCFIZWFkaW5nQW5jaG9yKSBfbWlzc2luZ01keFJlZmVyZW5jZShcIkhlYWRpbmdBbmNob3JcIiwgdHJ1ZSk7XG4gIHJldHVybiA8PjxfY29tcG9uZW50cy5oMSBpZD1cImltbWVkaWF0ZWx5cnVuLWNvbXBvc2l0ZS1jYXBhYmlsaXR5LWxpZmVjeWNsZS10b3BvbG9neS1ob3ctYS1tdWx0aS1yZWFsbS1hcHBzLWdyYW50cy1jb21wb3NlXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJpbW1lZGlhdGVseXJ1bi1jb21wb3NpdGUtY2FwYWJpbGl0eS1saWZlY3ljbGUtdG9wb2xvZ3ktaG93LWEtbXVsdGktcmVhbG0tYXBwcy1ncmFudHMtY29tcG9zZVwiIC8+e1wiaW1tZWRpYXRlbHkucnVuIENvbXBvc2l0ZSBDYXBhYmlsaXR5ICYgTGlmZWN5Y2xlIFRvcG9sb2d5IOKAlCBob3cgYSBtdWx0aS1yZWFsbSBhcHAncyBncmFudHMgY29tcG9zZVwifTwvX2NvbXBvbmVudHMuaDE+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJTdGF0dXM6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHByb3Bvc2FsIC8gZHJhZnQg4oCUIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiU3BpbmUgMlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBvZiB0aGUgUmVja29uZXIgdXAtZnJvbnQtZGVzaWduIHRyaWFnZVxcbihcIn08X2NvbXBvbmVudHMuY29kZT57XCIuLi9BUkNISVRFQ1RVUkVfUExBTi5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgwqcwLjEpLCBidXQgd3JpdHRlbiBhcyBhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicGxhdGZvcm1cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgc3BlYzogaXRcXG5nZW5lcmFsaXplcyB0byBhbnkgY29tcG9zaXRlIGFwcCwgd2l0aCBSZWNrb25lciBhcyB0aGUgZm9yY2luZyBjb25zdW1lci4gSXQgcmVzb2x2ZXMgaG93IHRoZVxcbmZvdXIgc2VwYXJhdGVseS1zcGVjaWZpZWQgZGVsdGFzIOKAlCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIkQxXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChwZXItaW5zdGFuY2UgZGVsZWdhdGlvbiksIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiRDcvQUEtMDFcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHByb2dyYW0taWRlbnRpdHlcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJhcHBLZXlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSwgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJEOFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAobGF1bmNoLXRvLXJ1biAvIHN0YW5kaW5nLWFwcCBsaWZlY3ljbGUpLCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIkQ5XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChyZWRhY3RlZCBtb3VudCkg4oCUIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiY29tcG9zZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIlxcbmludG8gb25lIGdyYW50IHRvcG9sb2d5LiBSaWRlcyB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJkZXNpZ24tcGVuZGluZyBEOFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIi4gRGVzaWduIG9ubHk7IG5vdGhpbmcgYnVpbHQuIMK3IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiVXBkYXRlZDpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgMjAyNi0wNy0wOVwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuYmxvY2txdW90ZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlRoZSBzaW5nbGUgaW1wbGVtZW50YXRpb24tc3RhdHVzIHNvdXJjZSBmb3IgdGhpcyBzcGVjIGlzXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZG9jcy9zdGF0dXMvQ09NUE9TSVRFX0NBUEFCSUxJVFlfVE9QT0xPR1lfU1RBVFVTLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAodG8gYmUgY3JlYXRlZCBhdCBidWlsZCkg4oCUIHdoZXJlIHRoZXlcXG5kaXNhZ3JlZSwgdGhlIHN0YXR1cyBkb2MgZ292ZXJucy5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUmVhZHMgZmlyc3Q6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlNUQU5ESU5HX0FQUF9MSUZFQ1lDTEVfU1BFQy5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgwqc0LjEvwqc1L8KnNS4xL8KnNi4xIChsYXVuY2gsIGtlZXAtd2FybSxcXG50ZWFyZG93biwgcGVyLWluc3RhbmNlIGRlbGVnYXRpb24g4oCUIHRoZSBEOCBzdWJzdHJhdGUpOyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJBR0VOVF9BVVRIT1JJTkdfQVJDSElURUNUVVJFLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDCpzUvwqc1LjFcXG4ocHJvZ3JhbSBpZGVudGl0eSwgQUEtMDEvRDcpOyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJVSV9BU19BUFBTX1NQRUMubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIMKnOC4xNSAoYXR0ZW51YXRlZCBkZWxlZ2F0aW9uLCBkb3dud2FyZC1vbmx5KSxcXG7CpzUuNyAodGFzayBtb2RlbCksIMKnOC4xIChkb3dud2FyZC1vbmx5IGF1dGhvcml0eSk7IFwifTxfY29tcG9uZW50cy5jb2RlPntcIlJFUE9SVElOR19TUFJFQURTSEVFVF9TUEVDLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDCpzMuMiAodGhlXFxubm8tYm90aCBpbnZhcmlhbnQgdGhpcyB0b3BvbG9neSBlbmZvcmNlcyBzdHJ1Y3R1cmFsbHkpLCDCpzYgKHRoZSBjb21wb3NpdGUpLCDCpzExIChSUy0xL1JTLTZcXG5jb250YWlubWVudCk7IFwifTxfY29tcG9uZW50cy5jb2RlPntcIi4uL0FSQ0hJVEVDVFVSRV9QTEFOLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDCpzIgKHRoZSBmb3VyIHJlYWxtcyksIMKnOSAodGhlIGRlbHRhcyk7XFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRU5HSU5FX0lORk9STUFUSU9OX0ZMT1dfU1BFQy5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgwqc1IE9RLTMgKHRoZSBcXFwiYXVkaWVuY2VcXFwiIHByaW5jaXBhbHMgdGhpcyBzcGVjIG11c3QgbWFrZVxcbmRpc3Rpbmd1aXNoYWJsZSkuIENvbXBhbmlvbjogXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiSE9MRE9VVF9SRURBQ1RFRF9NT1VOVF9TUEVDLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoRDksIHRoZSBhc3Npc3RhbnQncyBtb3VudCBzY29wZSkuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTwvX2NvbXBvbmVudHMuYmxvY2txdW90ZT57XCJcXG5cIn08X2NvbXBvbmVudHMuaHIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtMFwiIGRhdGEtc2x1Zz1cIjAtd2h5LXRoaXMtaXMtdXAtZnJvbnQtYW5kLXdoeS1vbmUtc3BlYy1ub3JtYXRpdmUtaW50ZW50XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtMFwiIC8+e1wiMC4gV2h5IHRoaXMgaXMgdXAtZnJvbnQsIGFuZCB3aHkgb25lIHNwZWMgIFwifTxfY29tcG9uZW50cy5lbT57XCIobm9ybWF0aXZlIGludGVudClcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIGNvbXBvc2l0ZSdzIGlzb2xhdGlvbiBpcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInRoZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBjb25maWRlbnRpYWxpdHkgcHJvcGVydHkgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIlJFUE9SVElORyDCpzMuMVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpOiBldmVyeSByZWFsbSdzXFxuXFxcIml0IGNhbm5vdCByZWFjaCBYXFxcIiBjbGFpbSBpcyBhIGNsYWltIGFib3V0IFwifTxfY29tcG9uZW50cy5lbT57XCJ3aGljaCBncmFudCBpdCBob2xkcyBhbmQgZm9yIGhvdyBsb25nXCJ9PC9fY29tcG9uZW50cy5lbT57XCIuIFRvZGF5IHRoYXRcXG5pcyBzcGVjaWZpZWQgaW4gZm91ciBmcmFnbWVudHMg4oCUIEQxL0Q3L0Q4L0Q5IGVhY2ggZGVzaWduIGEgcGllY2Ug4oCUIHdpdGggXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJubyBzaW5nbGUgc3RhdGVtZW50IG9mXFxud2hvIG1pbnRzIHdoaWNoIGdyYW50IHRvIHdoaWNoIHJlYWxtLCBhdCB3aGF0IHRpZXIsIGFuZCBvdmVyIHdoYXQgbGlmZXRpbWUuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIEZyYWdtZW50YXJ5XFxuY2FwYWJpbGl0eSBzcGVjcyBhcmUgZXhhY3RseSB3aGF0IGZhaWxlZCB0d2ljZSBpbiBSZWNrb25lcidzIHJ1bnRpbWUgZGVzaWduIChhZHZlcnNhcmlhbC1yZXZpZXctMik7XFxudGhlIGNhcGFiaWxpdHkgXCJ9PF9jb21wb25lbnRzLmVtPntcInRvcG9sb2d5XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgaXMgbW9yZSBkYW5nZXJvdXMgdG8gbGVhdmUgZnJhZ21lbnRhcnksIGJlY2F1c2UgYSBnYXAgaXMgbm90IGEgZ2xpdGNoIOKAlFxcbml0IGlzIGEgc2lsZW50IGF1dGhvcml0eSB0aGUgaXNvbGF0aW9uIG1vZGVsIGFzc3VtZWQgYXdheS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVHdvIGZhY3RzIG1ha2UgdGhpcyB1cC1mcm9udDpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkl0IHJpZGVzIHRoZSBkZXNpZ24tcGVuZGluZyBEOFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAobGF1bmNoLXRvLXJ1biAvIHN0YW5kaW5nLWFwcCBsaWZlY3ljbGUsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlNUQU5ESU5HX0FQUF9MSUZFQ1lDTEVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxuT3BlbiBRIzEwKS4gR3JhbnRzIGhhdmUgXCJ9PF9jb21wb25lbnRzLmVtPntcImxpZmV0aW1lc1wifTwvX2NvbXBvbmVudHMuZW0+e1wiIHRpZWQgdG8gbWVtYmVyIGxhdW5jaC90ZWFyZG93bjsgd2l0aG91dCB0aGUgbGlmZWN5Y2xlXFxubW9kZWwsIFxcXCJ0aGUgY29ubmVjdG9yJ3MgZ3JhbnQgZXhpc3RzIG9ubHkgd2hpbGUgaXRzIGZlZWQgaXMgbGl2ZVxcXCIgaGFzIG5vIG1lY2hhbmlzbS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkl0IGlzIHRoZSB0aGluZyB0aGF0IHR1cm5zIHRoZSBuby1ib3RoIGludmFyaWFudCBmcm9tIFwifTxfY29tcG9uZW50cy5lbT57XCJhcHAgZGlzY2lwbGluZVwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGludG8gXCJ9PF9jb21wb25lbnRzLmVtPntcImhvc3RcXG5lbmZvcmNlbWVudFwifTwvX2NvbXBvbmVudHMuZW0+e1wiLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBQcmUtRDcvRDgvRDkgdGhlIGZvdXItcmVhbG0gaXNvbGF0aW9uIGlzIGEgZm9yay13ZWFrZW5hYmxlIGZpY3Rpb24gKHRoZSBwbGFuXFxuYWRtaXRzIHRoaXMsIFBELTYvTTcpOyB0aGUgY29tcG9zZWQgdG9wb2xvZ3kgaXMgd2hhdCBtYWtlcyBpdCByZWFsLiBHZXR0aW5nIHRoZSBjb21wb3NpdGlvblxcbndyb25nIG1lYW5zIHRoZSBpc29sYXRpb24gaXMgZmljdGlvbiBcIn08X2NvbXBvbmVudHMuZW0+e1wiZXZlbiBhZnRlclwifTwvX2NvbXBvbmVudHMuZW0+e1wiIHRoZSBkZWx0YXMgbGFuZC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMub2w+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTFcIiBkYXRhLXNsdWc9XCIxLXRoZS1jb21wb3NpdGUtaXMtYS1zZXQtb2YtcHJpbmNpcGFscy1ub3QtYS1wcmluY2lwYWwtbm9ybWF0aXZlXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtMVwiIC8+e1wiMS4gVGhlIGNvbXBvc2l0ZSBpcyBhIHNldCBvZiBwcmluY2lwYWxzLCBub3QgYSBwcmluY2lwYWwgIFwifTxfY29tcG9uZW50cy5lbT57XCIobm9ybWF0aXZlKVwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJBIGNvbXBvc2l0ZSAoUmVja29uZXI6IHJlcG9ydC12aWV3IHJvb3QgKyBlbmdpbmUgKyBjb25uZWN0b3IgKyBhc3Npc3RhbnQpIGlzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiTiBkaXN0aW5jdFxcbnByb2dyYW0gaWRlbnRpdGllc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgb25lIFwifTxfY29tcG9uZW50cy5jb2RlPntcImFwcEtleVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcGVyIHJlYWxtIChENy9BQS0wMSkuIEdyYW50cyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImtleSBwZXIgcmVhbG0gYW5kIG5ldmVyXFxubWVyZ2VcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIlJFUE9SVElORyDCpzZcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIFJCLTE6IG5vIGNvbXBvc2l0ZSBwcmluY2lwYWwsIG5vIG1lcmdlZCBidW5kbGUpLiBFYWNoIHJlYWxtIGVhcm5zIGl0c1xcbm93biBhdXRob3JpdHk7IHRoZSByb290IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibGF1bmNoZXNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgbWVtYmVycyBidXQgZG9lcyBub3QgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJsZW5kXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHRoZW0gaXRzIGdyYW50cyBhbWJpZW50bHlcXG4oZG93bndhcmQtb25seSwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiVUlfQVNfQVBQUyDCpzguMVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLiBNZW1iZXJzaGlwIGlzIGJpbmRpbmctcmVzb2x2ZWQgcm9sZXMsIHVzZXItb3ZlcnJpZGFibGUsIGFuZFxcbnRoZSB0cnVzdCBiYWRnZSByZWZsZWN0cyB0aGUgYWN0dWFsbHktYm91bmQgcHJvdmlkZXIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIlJFUE9SVElORyDCpzYuMVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtMlwiIGRhdGEtc2x1Zz1cIjItdGhlLXJlYWxtLWNhcGFiaWxpdHktbWludGluZy1hdXRob3JpdHktbGlmZXRpbWUtbWF0cml4LXByb3Bvc2FsLXRoZS1oZWFydFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTJcIiAvPntcIjIuIFRoZSByZWFsbSDDlyBjYXBhYmlsaXR5IMOXIG1pbnRpbmctYXV0aG9yaXR5IMOXIGxpZmV0aW1lIG1hdHJpeCAgXCJ9PF9jb21wb25lbnRzLmVtPntcIihwcm9wb3NhbCDigJQgdGhlIGhlYXJ0KVwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJGb3IgUmVja29uZXIncyBmb3VyIHJlYWxtcyAodGhlIHBhdHRlcm4gZ2VuZXJhbGl6ZXM6IFwifTxfY29tcG9uZW50cy5jb2RlPntcIntob2xkcywgbWludGVkLWJ5LCB0aWVyLCBsaWZldGltZX1cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHBlclxcbnJlYWxtKS4gXFxcIk1pbnRlZC1ieVxcXCIgaXMgdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wib25seVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBwcmluY2lwYWwgdGhhdCBtYXkgY3JlYXRlIHRoZSBncmFudDsgXFxcImxpZmV0aW1lXFxcIiBpcyB3aGVuIGl0XFxuZXhpc3RzICjCpzMpLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudGFibGU+PF9jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGg+e1wiUmVhbG0gKGFwcEtleSlcIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aD57XCJIb2xkc1wifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIk1pbnRlZCBieVwifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIlRpZXJcIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aD57XCJMaWZldGltZVwifTwvX2NvbXBvbmVudHMudGg+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50Ym9keT48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUmVwb3J0LXZpZXcgKHJvb3QpXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wicndAc2VsZlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKGl0cyBzb3VyY2UgKyB0aGUgZG9jdW1lbnQsIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZGVmaW5lZCBhcyB0aGUgZW51bWVyYXRlZCBhdXRob3Jpbmcgc3VidHJlZXNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIsIEQ5KTsgdGhlIGNvbXBvc2l0ZS1yb290IHJpZ2h0IHRvIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibGF1bmNoIG1lbWJlcnNcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJob3N0LCBmcm9tIHRoZSB1c2VyJ3MgZ3JhbnQgYXQgY29tcG9zaXRlIG9wZW5cIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJ0aGUgZG9jdW1lbnQncyBtb3VudCB0aWVyXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1widGhlIHNlc3Npb24gKG9wZW4g4oaSIGNsb3NlKVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRW5naW5lXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnN0cm9uZz57XCJub3RoaW5nXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBzdGFydmVkIGJ5IGRlc2lnbiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiUkVQT1JUSU5HIMKnMy4xXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIik7IGlucHV0IGluamVjdGlvbiBpcyBob3N0LWJyb2tlcmVkLCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vdCBhIGdyYW50XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiaG9zdCBtaW50cyBhbiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImVtcHR5IGJ1bmRsZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoRDcgZ2F0ZTogdGhlIGVuZ2luZSBlbnRyeSBwb2ludCByZXNvbHZlcyB0byBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ7fVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wibi9hIChob2xkcyBubyBkYXRhLWJlYXJpbmcgZ3JhbnQpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wibGF1bmNoZWQgd2l0aCB0aGUgcm9vdDsgd2FybSBhY3Jvc3MgcmVjb21wdXRlczsgdG9ybiBkb3duIGF0IGNsb3NlXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnN0cm9uZz57XCJDb25uZWN0b3JcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJmZWVkOmZldGNoXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAodGVtcGxhdGUtYm91bmQsIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibm90XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGdlbmVyYWwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibmV0OmZldGNoXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgRDIpLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzZWNyZXRzOnVzZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKHVzZS1ub3QtcmVhZCksIHBlci1pbnN0YW5jZS1kZWxlZ2F0ZWQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJuYXJyb3cgc291cmNlIHJlYWRzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChEMSlcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJob3N0LCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInBlciBmZWVkLWluc3RhbmNlLCBhdCBmZWVkLWFjdGl2YXRpb24gY29uc2VudFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoaW5kaXZpZHVhbCwgbmV2ZXIgYnVuZGxlZCDigJQgUkItMylcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJvbmUgdGllciBwZXIgZmVlZC1pbnN0YW5jZSAoUlEtRTIpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnN0cm9uZz57XCJwZXIgZmVlZC1pbnN0YW5jZTpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgbGF1bmNoZWQgYXQgYWN0aXZhdGlvbiwgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJrZXB0IHdhcm1cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgd2hpbGUgdGhlIGZlZWQgaXMgbGl2ZSAocG9sbC9zdWJzY3JpcHRpb24pLCB0b3JuIGRvd24gYXQgZGVhY3RpdmF0aW9uIG9yIHNlc3Npb24gZW5kXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnN0cm9uZz57XCJBc3Npc3RhbnRcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJsbG06Y2hhdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKGVncmVzcyksIFwifTxfY29tcG9uZW50cy5jb2RlPntcInJ3QHNlbGZcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChhdXRob3Jpbmcgc3VidHJlZXM7IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZnVydGhlciByZWRhY3RlZCB0byBleGNsdWRlIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi5ob2xkb3V0L1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZHVyaW5nIGluZmVyZW5jZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgRDkpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiaG9zdCwgYXQgYXNzaXN0YW50IGxhdW5jaFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIml0cyByZWFkIHRpZXIgZm9sbG93cyB0aGUgZG9jdW1lbnQ7IHRhaW50cyBvbiByZWFkaW5nIE0zIChcIn08X2NvbXBvbmVudHMuY29kZT57XCLCpzguMVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wibGF1bmNoZWQgb24gZGVtYW5kOyB3YXJtIGR1cmluZyBhIHNlc3Npb247IHRvcm4gZG93blwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRib2R5PjwvX2NvbXBvbmVudHMudGFibGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJNaW50aW5nIHJ1bGVzICh0aGUgaW52YXJpYW50IGJlaGluZCB0aGUgbWF0cml4KTpcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIk9ubHkgdGhlIGhvc3QgbWludHMgYSBncmFudCB0byBhIHJlYWxtLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBObyByZWFsbSBtaW50cyBmb3IgYSBzaWJsaW5nLiBUaGUgcm9vdCBtYXlcXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImF0dGVudWF0ZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBhIGNhcGFiaWxpdHkgaXQgXCJ9PF9jb21wb25lbnRzLmVtPntcImFscmVhZHkgaG9sZHNcIn08L19jb21wb25lbnRzLmVtPntcIiBkb3duIHRvIGEgbWVtYmVyICh0aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZWRpdC1maWxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJjYXBEaXJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxucGF0dGVybiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiwqc4LjE1XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRGVsZWdhdGFibGVNb3VudFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpIOKAlCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImRvd253YXJkLW9ubHksIG5ldmVyIGFtcGxpZnlpbmdcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKGEgbWVtYmVyIGNhbm5vdFxcbnJlY2VpdmUgbW9yZSB0aGFuIHRoZSByb290IGhvbGRzOyBlc2NhcGUg4oaSIGZhaWwtY2xvc2VkKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkEgZ3JhbnQncyB0aWVyIGlzIGhvc3QtYXV0aG9yaXRhdGl2ZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAodGhlIG1vdW50L2ZlZWQgdGllciksIG5ldmVyIGNvbnRlbnQtIG9yXFxubWVtYmVyLWRlY2xhcmVkIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJFTkdJTkVfSU5GT1JNQVRJT05fRkxPVyDCpzNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlBlci1pbnN0YW5jZSBncmFudHMgYXJlIGtleWVkIG9uIGEgaG9zdC1taW50ZWQgaW5zdGFuY2UgaWRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKEQxICsgRDIncyBhbnRpLWJ1Y2tldCBydWxlKTpcXG50d28gaW5zdGFuY2VzIG9mIG9uZSBjb25uZWN0b3IgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYXBwS2V5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBzaGFyZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHNvdXJjZSBncmFudC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTNcIiBkYXRhLXNsdWc9XCIzLXRoZS1saWZlY3ljbGUtc3RhdGUtbWFjaGluZS1ncmFudHMtbGl2ZS1hbmQtZGllLXdpdGgtbWVtYmVycy1ub3JtYXRpdmUtdGhlLWQ4LWRlcGVuZGVuY3lcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy0zXCIgLz57XCIzLiBUaGUgbGlmZWN5Y2xlIHN0YXRlIG1hY2hpbmUg4oCUIGdyYW50cyBsaXZlIGFuZCBkaWUgd2l0aCBtZW1iZXJzICBcIn08X2NvbXBvbmVudHMuZW0+e1wiKG5vcm1hdGl2ZSDigJQgdGhlIEQ4IGRlcGVuZGVuY3kpXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkV2ZXJ5IG1lbWJlciBtb3ZlcyB0aHJvdWdoIGEgaG9zdC1kcml2ZW4gbGlmZWN5Y2xlOyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImEgZ3JhbnQgZXhpc3RzIGlmZiBpdHMgbWVtYmVyIGlzIGluIGEgbGl2ZVxcbnN0YXRlLCBhbmQgdGVhcmRvd24gcmV2b2tlcyBpdC5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhpcyBpcyB0aGUgRDggc3Vic3RyYXRlIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJTVEFORElOR19BUFBfTElGRUNZQ0xFIMKnNC4xL8KnNi4xXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wcmU+PF9jb21wb25lbnRzLmNvZGU+e1wiICB1bmxhdW5jaGVkIOKUgOKUgGxhdW5jaOKUgOKUgOKWuiBsaXZlIOKUgOKUgGlkbGXilIDilIDilrogd2FybSDilIDilIByZXN1bWXilIDilIDilrogbGl2ZVxcbiAgICAgICAgICAgICAgICAgICAgICAgICAg4pSCICAgICAgICAgICAgICAg4pSCXFxuICAgICAgICAgICAgICAgICAgICAgICAgICDilJTilIDilIB0ZWFyZG93buKUgOKUgOKUgOKUgOKUgOKUtOKUgOKUgOKWuiB0b3JuLWRvd24gICAoZ3JhbnRzIHJldm9rZWQpXFxuXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMucHJlPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJSZXBvcnQtdmlldyByb290OlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJsYXVuY2hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGF0IGRvY3VtZW50IG9wZW4g4oaSIFwifTxfY29tcG9uZW50cy5jb2RlPntcImxpdmVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGZvciB0aGUgc2Vzc2lvbiDihpIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widGVhcmRvd25cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGF0XFxuY2xvc2UuIEl0cyBsYXVuY2ggaXMgd2hhdCBtaW50cyB0aGUgbWVtYmVycycgbGF1bmNoIHJpZ2h0LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRW5naW5lOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBsYXVuY2hlZCB3aXRoIHRoZSByb290IChyZW5kZXJpbmcgbmVlZHMgaXQpOyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ3YXJtXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBiZXR3ZWVuIHJlY29tcHV0ZXMgKGtlZXAtd2FybVxcbmF2b2lkcyByZS1cIn08X2NvbXBvbmVudHMuY29kZT57XCJsb2NrZG93bigpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjb3N0KTsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widGVhcmRvd25cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGF0IGNsb3NlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wib3JcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgb24gdGhlIHN5bmNocm9ub3VzLXJ1bmF3YXkgcmVidWlsZFxcbihcIn08X2NvbXBvbmVudHMuY29kZT57XCJBUkNISVRFQ1RVUkVfUExBTiDCpzQuMVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIGEgd2hvbGUtY29udGV4dCB0ZWFyZG93biB0aGF0IHJlLWxhdW5jaGVzIGZyb20gaG9zdC1zaWRlIHN0YXRlKS5cXG5JdCBob2xkcyBub3RoaW5nLCBzbyB0ZWFyZG93biByZXZva2VzIG5vdGhpbmcgc2Vuc2l0aXZlIOKAlCBidXQgaXRzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wib3V0cHV0IGNoYW5uZWxzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGFyZVxcbmdvdmVybmVkIHNlcGFyYXRlbHkgKFNwaW5lIDEpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQ29ubmVjdG9yOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm9uZSBsaWZlY3ljbGUgcGVyIGZlZWQtaW5zdGFuY2UuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5jb2RlPntcImxhdW5jaFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYXQgZmVlZC1hY3RpdmF0aW9uIGNvbnNlbnQ7IFwifTxfY29tcG9uZW50cy5jb2RlPntcIndhcm1cIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxud2hpbGUgdGhlIGZlZWQgaXMgbGl2ZSAoYSBwb2xsIHRpbWVyIC8gb3BlbiBzdWJzY3JpcHRpb24gbXVzdCBwZXJzaXN0IOKAlCB0aGlzIGlzIFwifTxfY29tcG9uZW50cy5lbT57XCJ0aGVcIn08L19jb21wb25lbnRzLmVtPntcIiByZWFzb25cXG5EOCBrZWVwLXdhcm0gaXMgbG9hZC1iZWFyaW5nIGhlcmUpOyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ0ZWFyZG93blwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYXQgZmVlZCBkZWFjdGl2YXRpb24gb3Igc2Vzc2lvbiBlbmQsIHdoaWNoXFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJyZXZva2VzIHRoYXQgaW5zdGFuY2UncyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmZWVkOmZldGNoXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiArIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNlY3JldHM6dXNlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiArIHNvdXJjZS1yZWFkXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLiBBIGtlZXAtd2FybSBjb25uZWN0b3JcXG5hY3Jvc3MgYSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInRpZXIgY2hhbmdlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIG11c3QgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJyZS10aWVyIG9yIGJlIHRvcm4gZG93blwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAodGllcyB0byBcIn08X2NvbXBvbmVudHMuY29kZT57XCJBUkNISVRFQ1RVUkVfUExBTiDCpzQuMlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgRjc6XFxuYW4gYXV0b25vbW91cyB0aWVyIGRyb3AgcmUtZmxvb3JzOyBpdCBjYW5ub3Qgc2lsZW50bHkga2VlcCBhIHN0YWxlIGhpZ2hlciBncmFudCB3YXJtKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkFzc2lzdGFudDpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibGF1bmNoXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBvbiBkZW1hbmQ7IFwifTxfY29tcG9uZW50cy5jb2RlPntcIndhcm1cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGR1cmluZyB0aGUgc2Vzc2lvbjsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widGVhcmRvd25cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG9uIHNlc3Npb24gZW5kLiBJdHNcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCIuaG9sZG91dC9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLXJlZGFjdGlvbiAoRDkpIGlzIGEgcHJvcGVydHkgb2YgdGhlIFwifTxfY29tcG9uZW50cy5lbT57XCJzdGFuZGluZ1wifTwvX2NvbXBvbmVudHMuZW0+e1wiIGdyYW50LCBub3QgYSBtb2RlIOKAlCB0aGVyZSBpcyBub1xcbndhcm0gc3RhdGUgaW4gd2hpY2ggaXQgaG9sZHMgYSBicm9hZGVyIG1vdW50IChcIn08X2NvbXBvbmVudHMuY29kZT57XCJIT0xET1VUIMKnNFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlRoZSBrZWVwLXdhcm0gY292ZXJ0LWNoYW5uZWwgbm90ZTpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYSBtZW1iZXIncyBsYXVuY2gvdGVhcmRvd24gXCJ9PF9jb21wb25lbnRzLmVtPntcInRpbWluZ1wifTwvX2NvbXBvbmVudHMuZW0+e1wiIGlzIGEgfjEtYml0XFxuc2lkZS1jaGFubmVsIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJTVEFORElOR19BUFBfTElGRUNZQ0xFIMKnNi40XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikuIERlYm91bmNlIGEgbWVtYmVyJ3Mgc2VsZi1leGl0IHNvIGl0IGlzXFxuaW5kaXN0aW5ndWlzaGFibGUgZnJvbSBhIHVzZXItZHJpdmVuIHRlYXJkb3duIOKAlCBjYXJyaWVkIGhlcmUgYXMgYSBjb21wb3NpdGlvbiByZXF1aXJlbWVudCwgbm90XFxucmUtZGVyaXZlZC5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTRcIiBkYXRhLXNsdWc9XCI0LWhvdy10aGUtZm91ci1kZWx0YXMtY29tcG9zZS10aGUtcG9pbnQtb2YtdGhlLXNwZWMtbm9ybWF0aXZlXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtNFwiIC8+e1wiNC4gSG93IHRoZSBmb3VyIGRlbHRhcyBjb21wb3NlIOKAlCB0aGUgcG9pbnQgb2YgdGhlIHNwZWMgIFwifTxfY29tcG9uZW50cy5lbT57XCIobm9ybWF0aXZlKVwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJFYWNoIGRlbHRhIHN1cHBsaWVzIG9uZSBheGlzOyB0aGUgdG9wb2xvZ3kgaXMgdGhlaXIgcHJvZHVjdCwgYW5kIHRoZSBuby1ib3RoIGludmFyaWFudFxcbihcIn08X2NvbXBvbmVudHMuY29kZT57XCJSRVBPUlRJTkcgwqczLjJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSBpcyBlbmZvcmNlZCBzdHJ1Y3R1cmFsbHkgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJvbmx5IHdoZW4gYWxsIGZvdXIgaG9sZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIjpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnRhYmxlPjxfY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRoPntcIkRlbHRhXCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGg+e1wiQXhpcyBpdCBzdXBwbGllc1wifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIldpdGhvdXQgaXRcIn08L19jb21wb25lbnRzLnRoPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudGJvZHk+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkQ3IC8gQUEtMDFcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuZW0+e1wiaWRlbnRpdHlcIn08L19jb21wb25lbnRzLmVtPntcIiDigJQgYSBkaXN0aW5jdCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJhcHBLZXlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHBlciByZWFsbSwgc28gZ3JhbnRzIGtleSBwZXIgcmVhbG1cIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJhbGwgcmVhbG1zIHNoYXJlIG9uZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJhcHBLZXlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiOyBncmFudHMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJibGVlZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAodGhlIE03IHdpbmRvdzogdGhlIGVuZ2luZSBlZmZlY3RpdmVseSBob2xkcyB0aGUgYXNzaXN0YW50J3MgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibGxtOmNoYXRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRDhcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuZW0+e1wibGlmZXRpbWVcIn08L19jb21wb25lbnRzLmVtPntcIiDigJQgcGVyLWluc3RhbmNlIGxhdW5jaCAvIGtlZXAtd2FybSAvIHRlYXJkb3duLCBzbyBhIGdyYW50IGV4aXN0cyBvbmx5IHdoaWxlIGl0cyBtZW1iZXIgZG9lc1wifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcImdyYW50cyBoYXZlIG5vIHRlYXJkb3duOyBhIGRlYWN0aXZhdGVkIGZlZWQncyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzZWNyZXRzOnVzZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcGVyc2lzdHM7IGtlZXAtd2FybSBpbXBvc3NpYmxlIOKGkiBubyBsaXZlIGZlZWRzXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnN0cm9uZz57XCJEMVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5lbT57XCJpbnN0YW5jZSBpc29sYXRpb25cIn08L19jb21wb25lbnRzLmVtPntcIiDigJQgcGVyLWluc3RhbmNlIGRlbGVnYXRpb24sIHNvIHR3byBpbnN0YW5jZXMgb2Ygb25lIFwifTxfY29tcG9uZW50cy5jb2RlPntcImFwcEtleVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgc2hhcmUgbm8gc291cmNlIGdyYW50XCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wib25lIGNvbm5lY3RvcidzIGZlZWRzIGNyb3NzLWNvbnRhbWluYXRlOyBvdmVyLWJyb2FkIHNvdXJjZSByZWFkc1wifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRDlcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuZW0+e1wiaW50cmEtcmVhbG0gc2NvcGVcIn08L19jb21wb25lbnRzLmVtPntcIiDigJQgdGhlIGFzc2lzdGFudCdzIFwifTxfY29tcG9uZW50cy5jb2RlPntcInJ3QHNlbGZcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGlzIHRoZSBhdXRob3Jpbmcgc3VidHJlZXMsIHJlZGFjdGVkIGR1cmluZyBpbmZlcmVuY2VcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJ0aGUgYXNzaXN0YW50IHJlYWRzIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi5ob2xkb3V0L1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYW5kIGFueSBkb2N1bWVudCBwYXRoIHRyaXZpYWxseVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRib2R5PjwvX2NvbXBvbmVudHMudGFibGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgY29tcG9zaXRpb24gaW52YXJpYW50OlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuZW0+e1wibm8gcmVhbG0gZXZlciBzaW11bHRhbmVvdXNseSAoYSkgZXhlY3V0ZXMgY29udGVudCBhcyBjb2RlLCAoYilcXG5ob2xkcyBhIENsYXNzLUIgY2FwYWJpbGl0eSwgYW5kIChjKSBob3N0cyBhbiBpbmplY3RhYmxlIGFnZW50IOKAlCBhbmQgdGhlIGdyYW50IHRvcG9sb2d5IG1ha2VzIGVhY2hcXG5vZiBhL2IvYyBhIHByb3BlcnR5IG9mIGEgZGlzdGluY3QgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYXBwS2V5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB3aXRoIGEgYm91bmRlZCBsaWZldGltZSwgc28gYSBmb3JrIGNhbm5vdCBtZXJnZSB0aGVtLlwifTwvX2NvbXBvbmVudHMuZW0+e1wiXFxuVGhlIGVuZ2luZSBleGVjdXRlcyBjb250ZW50IChhKSBidXQgaG9sZHMgbm90aGluZyAowqxiKSBhbmQgaG9zdHMgbm8gYWdlbnQgKMKsYyk7IHRoZSBjb25uZWN0b3JcXG5ob2xkcyBDbGFzcy1CIChiKSBidXQgZXhlY3V0ZXMgbm8gY29udGVudCAowqxhLCBEMiB0YXJnZXQtZml4aW5nKSBhbmQgaG9zdHMgbm8gYWdlbnQgKMKsYyk7IHRoZVxcbmFzc2lzdGFudCBob3N0cyBhbiBhZ2VudCAoYykgYnV0IGlzIENsYXNzLUEgb25seSAowqxiKSBhbmQgZXhlY3V0ZXMgbm8gY29udGVudCAowqxhKS4gRDcga2VlcHNcXG50aGVzZSB0aHJlZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJhcHBLZXlcIn08L19jb21wb25lbnRzLmNvZGU+e1wicyBkaXN0aW5jdDsgRDggYm91bmRzIHRoZWlyIGxpZmV0aW1lczsgRDEvRDkgc2NvcGUgdGhlbS4gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJQcmUtYW55LW9mLXRoZXNlXFxudGhlIGludmFyaWFudCBpcyBhcHAgZGlzY2lwbGluZSAoZmljdGlvbik7IHBvc3QtYWxsLWZvdXIgaXQgaXMgc3RydWN0dXJhbC5cIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTVcIiBkYXRhLXNsdWc9XCI1LWFkdmVyc2FyaWFsLWNvbXBvc2l0aW9uLWNoZWNrcy1ub3JtYXRpdmUtaW50ZW50XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtNVwiIC8+e1wiNS4gQWR2ZXJzYXJpYWwgY29tcG9zaXRpb24gY2hlY2tzICBcIn08X2NvbXBvbmVudHMuZW0+e1wiKG5vcm1hdGl2ZSBpbnRlbnQpXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJFbmdpbmUgYXMgY29uZnVzZWQgZGVwdXR5LlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBJdCBob2xkcyBub3RoaW5nLCBzbyBpdCBjYW5ub3QgYmUgc3RlZXJlZCB0byBlZ3Jlc3Mg4oCUIGJ1dCBpdHNcXG5cIn08X2NvbXBvbmVudHMuZW0+e1wib3V0cHV0XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgaXMgZGF0YSB0aGF0IGNvdWxkIGNhcnJ5IE0zIHRpZXJzL2hvbGRvdXQuIENvbnRhaW5lZCBieSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlNwaW5lIDFcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHRoZSBjaGFubmVsXFxuY29udHJhY3QpLCBub3QgYnkgdGhpcyB0b3BvbG9neTsgbm90ZWQgc28gdGhlIGJvdW5kYXJ5IGlzIGV4cGxpY2l0LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUm9vdCBhbXBsaWZ5aW5nIGEgbWVtYmVyLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGUgcm9vdCBhdHRlbnVhdGVzIGEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2FwRGlyXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB0byBhIG1lbWJlciAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZWRpdC1maWxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIik7IHRoZVxcbmNocm9vdCBpcyBkb3dud2FyZC1vbmx5IGFuZCBmYWlsLWNsb3NlZCAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYXR0ZW51YXRlRGVsdGFcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSwgc28gYSBtZW1iZXIgY2Fubm90IHJlY2VpdmUgYVxcbmNhcGFiaWxpdHkgdGhlIHJvb3QgbGFja3MuIFZlcmlmaWVkIHNvdW5kIGluIEQ5J3MgcmV2aWV3LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQ29ubmVjdG9yIGtlZXAtd2FybSBhY3Jvc3MgYSB0aWVyIGRyb3AuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRoZSB3YXJtIGluc3RhbmNlIGNhbm5vdCBzaWxlbnRseSByZXRhaW4gYSBoaWdoZXJcXG5ncmFudDsgdGhlIGxpZmVjeWNsZSBmb3JjZXMgcmUtdGllciBvciB0ZWFyZG93biAowqczKSwgY29tcG9zaW5nIHdpdGggRjcgbW9ub3RvbmljaXR5LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVGhlIHNoYXJlZC1hcHBLZXkgd2luZG93IChwcmUtRDcpLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBIb25lc3QgZmljdGlvbiwgYm91bmRlZCB0byBhdXRob3Incy1vd24tZG9jdW1lbnRzLW9ubHlcXG4oXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQVJDSElURUNUVVJFX1BMQU5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIFItMi9NNyk7IHRoaXMgc3BlYyBpcyB0aGUgZGVmaW5pdGlvbiBvZiB3aGVuIGl0IGVuZHMgKEQ3K0Q4K0Q5IGFsbCBsaXZlKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkNyb3NzLW1lbWJlciB0YXNrIGludm9jYXRpb24uXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIEEgbWVtYmVyIGludm9raW5nIGFub3RoZXIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIsKnNS43XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikgc2F0aXNmaWVzIHRoZSBjYWxsZWUnc1xcbnJlcXVpcmVkIGRlbHRhIGZyb20gdGhlIGNhbGxlcidzIG93biBncmFudHMsIGF0dGVudWF0ZWQgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIsKnOC4xNVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpIOKAlCBuZXZlciBhbXBsaWZpZWQ7IHVuZGVjbGFyZWRcXG5pbnZvY2F0aW9ucyByZWplY3RlZCAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiUkVQT1JUSU5HXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDCpzYgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW52b2tlc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicHJvdmlkZXNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTZcIiBkYXRhLXNsdWc9XCI2LWxvYWQtYmVhcmluZy1hc3N1bXB0aW9ucy1jb2RlLWFuY2hvcnNcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy02XCIgLz57XCI2LiBMb2FkLWJlYXJpbmcgYXNzdW1wdGlvbnMgJiBjb2RlIGFuY2hvcnNcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cImRlcGVuZHMtb24tdG9kYXktdmVyaWZpZWQtMjAyNi0wNy0wOVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiZGVwZW5kcy1vbi10b2RheS12ZXJpZmllZC0yMDI2LTA3LTA5XCIgLz57XCJEZXBlbmRzLW9uLXRvZGF5ICh2ZXJpZmllZCAyMDI2LTA3LTA5KVwifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnRhYmxlPjxfY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRoPntcIkFzc3VtcHRpb24gKGV4aXN0aW5nIGJlaGF2aW9yIHRoZSBkZXNpZ24gcmVzdHMgb24pXCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGg+e1wiQW5jaG9yIChyZXBvLXJlbGF0aXZlIGZpbGUpXCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGg+e1wiVG9rZW4gKGdyZXAtc3RhYmxlKVwifTwvX2NvbXBvbmVudHMudGg+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50Ym9keT48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkRlbGVnYXRpb24gaXMgZG93bndhcmQtb25seSwgY2hyb290LWluc2lkZS1jYWxsZXIsIGZhaWwtY2xvc2VkXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiaW1tZWRpYXRlbHktcnVuLXNpdGUtbWFpbi9zcmMvZWRpdG9yL3Rhc2svYXR0ZW51YXRlRGVsdGEudHNcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiRGVsZWdhdGFibGVNb3VudFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJBIGNhcGFiaWxpdHkncyBlZmZlY3RpdmUgc2V0IGlzIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1hbmlmZXN0IOKIqSBncmFudFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKGxlYXN0IHByaXZpbGVnZSBib3RoIGVuZHMpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiaW1tZWRpYXRlbHktcnVuLXNpdGUtbWFpbi9zcmMvcmVnaXN0cnkvbmV0RmV0Y2hQb2xpY3kudHNcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiZWZmZWN0aXZlQWxsb3dsaXN0XCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkEgZnJhbWUncyBoZWxkIGNhcGFiaWxpdGllcyBhcmUgc2V0IGhvc3Qtc2lkZSBwZXIgYXBwL2NvbnNlbnQsIG5vdCBzZWxmLWRlY2xhcmVkXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiaW1tZWRpYXRlbHktcnVuLXNpdGUtbWFpbi9zcmMvZWRpdG9yL1NhbmRib3hMaXN0ZW5lci50c1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJuZXQ6ZmV0Y2hcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGJvZHk+PC9fY29tcG9uZW50cy50YWJsZT57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCJtdXN0LWVzdGFibGlzaC1uZXctaW52YXJpYW50cy10aGUtaW1wbGVtZW50YXRpb24tY3JlYXRlc1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwibXVzdC1lc3RhYmxpc2gtbmV3LWludmFyaWFudHMtdGhlLWltcGxlbWVudGF0aW9uLWNyZWF0ZXNcIiAvPntcIk11c3QtZXN0YWJsaXNoIChuZXcgaW52YXJpYW50cyB0aGUgaW1wbGVtZW50YXRpb24gY3JlYXRlcylcIn08L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy50YWJsZT48X2NvbXBvbmVudHMudGhlYWQ+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50aD57XCJOZXcgaW52YXJpYW50XCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGg+e1wiUHJvdmVuIGJ5IChnYXRlIHRlc3QpXCJ9PC9fY29tcG9uZW50cy50aD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGhlYWQ+PF9jb21wb25lbnRzLnRib2R5PjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiRWFjaCByZWFsbSByZXNvbHZlcyB0byBhIGRpc3RpbmN0IFwifTxfY29tcG9uZW50cy5jb2RlPntcImFwcEtleVwifTwvX2NvbXBvbmVudHMuY29kZT57XCI7IGdyYW50cyBkbyBub3QgbWVyZ2UgKEQ3KVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcInNpYmxpbmctaXNvbGF0aW9uIGdhdGU6IHR3byBlbnRyeSBwb2ludHMgb2Ygb25lIHJlcG8gaG9sZCBkaXNqb2ludCBidW5kbGVzOyB0aGUgZW5naW5lIHJlc29sdmVzIHRvIFwifTxfY29tcG9uZW50cy5jb2RlPntcInt9XCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkEgZ3JhbnQgZXhpc3RzIGlmZiBpdHMgbWVtYmVyIGlzIGxpdmU7IHRlYXJkb3duIHJldm9rZXMgaXQgKEQ4KVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcImxpZmV0aW1lIGdhdGU6IGEgZGVhY3RpdmF0ZWQgZmVlZC1pbnN0YW5jZSdzIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNlY3JldHM6dXNlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJmZWVkOmZldGNoXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpcyByZXZva2VkOyBhIHRvcm4tZG93biBtZW1iZXIgaG9sZHMgbm90aGluZ1wifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIlBlci1pbnN0YW5jZSBncmFudHMgc2hhcmUgbm8gc291cmNlIGFjcm9zcyBpbnN0YW5jZXMgb2Ygb25lIFwifTxfY29tcG9uZW50cy5jb2RlPntcImFwcEtleVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKEQxKVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcInBlci1pbnN0YW5jZSBnYXRlOiB0d28gY29ubmVjdG9yIGluc3RhbmNlcyBob2xkIGRpc2pvaW50IHNvdXJjZSBncmFudHM7IGluc3RhbmNlIGlkIGlzIGhvc3QtbWludGVkXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiTm8gcmVhbG0gaG9sZHMgdHdvIG9mIHtleGVjdXRlcyBjb250ZW50LCBDbGFzcy1CIGNhcCwgaW5qZWN0YWJsZSBhZ2VudH1cIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJuby1ib3RoIGdhdGU6IHRoZSBlbmdpbmUvY29ubmVjdG9yL2Fzc2lzdGFudCBlYWNoIGZhaWwgdGhlIHR3by1vZi10aHJlZSBjaGVjayB1bmRlciBhIGhvc3RpbGUgZm9ya1wifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIlRoZSByb290IGNhbiBhdHRlbnVhdGUgYnV0IG5ldmVyIGFtcGxpZnkgYSBtZW1iZXIncyBncmFudFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcImFtcGxpZmljYXRpb24gZ2F0ZTogYSBtZW1iZXIgY2Fubm90IHJlY2VpdmUgYSBjYXBhYmlsaXR5IHRoZSByb290IGxhY2tzIChmYWlsLWNsb3NlZClcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJNZW1iZXIgbGF1bmNoL3RlYXJkb3duIHRpbWluZyBpcyBkZWJvdW5jZWQgKGNvdmVydC1jaGFubmVsIGJvdW5kKVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcInRpbWluZyBnYXRlOiBhIG1lbWJlciBzZWxmLWV4aXQgaXMgaW5kaXN0aW5ndWlzaGFibGUgZnJvbSBhIHVzZXIgdGVhcmRvd25cIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50Ym9keT48L19jb21wb25lbnRzLnRhYmxlPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInNlYy03XCIgZGF0YS1zbHVnPVwiNy1kZWNpc2lvbnMtcmVqZWN0ZWQtYWx0ZXJuYXRpdmVzXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtN1wiIC8+e1wiNy4gRGVjaXNpb25zICYgcmVqZWN0ZWQgYWx0ZXJuYXRpdmVzXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiT25lIHRvcG9sb2d5IHNwZWMgY29tcG9zaW5nIEQxL0Q3L0Q4L0Q5OyB0aGUgY29tcG9zaXRlIGlzIE4gcHJpbmNpcGFscywgZ3JhbnRzIG5ldmVyIG1lcmdlLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIlxcblwifTxfY29tcG9uZW50cy5lbT57XCJSZWplY3RlZDpcIn08L19jb21wb25lbnRzLmVtPntcIiBsZWF2aW5nIHRoZSBmb3VyIGRlbHRhcyBhcyBpbmRlcGVuZGVudCBmcmFnbWVudHMgKHRoZSBpc29sYXRpb24gcHJvcGVydHkgaGFzIG5vXFxuc2luZ2xlIG93bmVyIOKAlCB0aGUgZ2FwIHRoaXMgc3BlYyBjbG9zZXMpOyBhIGNvbXBvc2l0ZSBcIn08X2NvbXBvbmVudHMuZW0+e1wicHJpbmNpcGFsXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgd2l0aCBhIG1lcmdlZCBidW5kbGVcXG4oXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiUkVQT1JUSU5HXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBSQi0xOiBhIGZvcmsgbGllczsgZ3JhbnRzIG11c3Qga2V5IHBlciByZWFsbSkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJHcmFudHMgaGF2ZSBsaWZldGltZXMgdGllZCB0byBtZW1iZXIgbGF1bmNoL3RlYXJkb3duIChyaWRlcyBEOCkuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5lbT57XCJSZWplY3RlZDpcIn08L19jb21wb25lbnRzLmVtPntcIiBzZXNzaW9uLWxvbmdcXG5zdGF0aWMgZ3JhbnRzIChhIGRlYWN0aXZhdGVkIGZlZWQga2VlcHMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic2VjcmV0czp1c2VcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKTsgbm8ga2VlcC13YXJtIChubyBsaXZlIGZlZWRzKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIk9ubHkgdGhlIGhvc3QgbWludHM7IHRoZSByb290IGF0dGVudWF0ZXMgZG93bndhcmQtb25seS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXCJ9PF9jb21wb25lbnRzLmVtPntcIlJlamVjdGVkOlwifTwvX2NvbXBvbmVudHMuZW0+e1wiIHBlZXItdG8tcGVlciBncmFudFxcbmxlbmRpbmcgYmV0d2VlbiByZWFsbXMgKGFtcGxpZmljYXRpb24gcGF0aCk7IGFtYmllbnQgaW5oZXJpdGFuY2UgZnJvbSB0aGUgcm9vdC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlRoZSBuby1ib3RoIGludmFyaWFudCBpcyBzdHJ1Y3R1cmFsIG9ubHkgcG9zdC1ENytEOCtEOTsgaG9uZXN0IGFzIGFwcC1kaXNjaXBsaW5lIGJlZm9yZS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCJcXG5cIn08X2NvbXBvbmVudHMuZW0+e1wiUmVqZWN0ZWQ6XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgY2xhaW1pbmcgc3RydWN0dXJhbCBpc29sYXRpb24gYmVmb3JlIHRoZSBkZWx0YXMgbGFuZCAodGhlIE03IGZpY3Rpb24pLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiV3JpdHRlbiBhcyBhIHBsYXRmb3JtIHNwZWMsIG5vdCBhIFJlY2tvbmVyLWludGVybmFsIG9uZS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXCJ9PF9jb21wb25lbnRzLmVtPntcIlJlamVjdGVkOlwifTwvX2NvbXBvbmVudHMuZW0+e1wiIHNjb3BpbmcgaXQgdG8gUmVja29uZXJcXG4oaXQgZ2VuZXJhbGl6ZXMgdG8gYW55IGNvbXBvc2l0ZTsgUmVja29uZXIgaXMgdGhlIGZvcmNpbmcgY29uc3VtZXIsIGFuZCBEOCBpcyBwbGF0Zm9ybSB3b3JrKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLThcIiBkYXRhLXNsdWc9XCI4LW9wZW4tcXVlc3Rpb25zXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtOFwiIC8+e1wiOC4gT3BlbiBxdWVzdGlvbnNcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJPUS0xIChEOCBpcyBkZXNpZ24tcGVuZGluZykuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRoZSBsYXVuY2gtdG8tcnVuIC8ga2VlcC13YXJtIC8gdGVhcmRvd24gc3Vic3RyYXRlXFxuKFwifTxfY29tcG9uZW50cy5jb2RlPntcIlNUQU5ESU5HX0FQUF9MSUZFQ1lDTEVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIE9wZW4gUSMxMCkgaXMgaXRzZWxmIG5vdCBmdWxseSBkZXNpZ25lZC4gVGhpcyBzcGVjIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiYXNzdW1lc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBpdHNcXG5zaGFwZSAocGVyLWluc3RhbmNlIGxhdW5jaCwga2VlcC13YXJtLCB0ZWFyZG93biByZXZva2VzKTsgdGhlIEQ4IGRlc2lnbiBtdXN0IGNvbmZpcm0gdGhlXFxubGlmZXRpbWUgc2VtYW50aWNzIHRoaXMgdG9wb2xvZ3kgcmVzdHMgb24sIGVzcGVjaWFsbHkga2VlcC13YXJtIHN0YXRlIGlzb2xhdGlvbiBhY3Jvc3MgYVxcbnRpZXIgY2hhbmdlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiT1EtMiAodGhlIGNvbXBvc2l0ZSBjb25zZW50IHN1cmZhY2UpLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGUgbWF0cml4ICjCpzIpIHNheXMgZ3JhbnRzIGFyZSBtaW50ZWQgXFxcImF0XFxuYWN0aXZhdGlvbiBjb25zZW50LCBpbmRpdmlkdWFsIG5ldmVyIGJ1bmRsZWQuXFxcIiBUaGUgXCJ9PF9jb21wb25lbnRzLmVtPntcImFnZ3JlZ2F0ZVwifTwvX2NvbXBvbmVudHMuZW0+e1wiIHBpY3R1cmUg4oCUIHRoZSByZWFjaCB2aWV3ICsgdGhlXFxud3JpdGUtc2luayBjb25zZW50IChcIn08X2NvbXBvbmVudHMuY29kZT57XCJDT05ORUNUT1JfRUdSRVNTX0ZJWElORyDCpzIuMVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpICsgcGVyLW1lbWJlciByZXZva2Ug4oCUIGlzIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlJFUE9SVElORyDCpzZcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxuRDYvUkItNiBhbmQgdW52YWxpZGF0ZWQgKHRoZSBFMyBzdHVkeSkuIFdoZXJlIGRvZXMgdGhlIHBlci1yZWFsbSBtaW50aW5nIHN0b3J5IG1lZXQgdGhlXFxuYWdncmVnYXRlIGNvbnNlbnQgVUk/IExpa2VseTogRDYgb3ducyB0aGUgc3VyZmFjZSwgdGhpcyBzcGVjIG93bnMgd2hhdCBlYWNoIGNvbnNlbnQgXCJ9PF9jb21wb25lbnRzLmVtPntcImdyYW50c1wifTwvX2NvbXBvbmVudHMuZW0+e1wiLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiT1EtMyAoZG9nZm9vZGluZyByZWN1cnNpb24sIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkFSQ0hJVEVDVFVSRV9QTEFOIMKnMC4yXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBTNikuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFJ1bm5pbmcgdGhlIHJlYWwgZm91ci1yZWFsbVxcbmNvbXBvc2l0ZSBcIn08X2NvbXBvbmVudHMuZW0+e1wiaW4tcGxhdGZvcm1cIn08L19jb21wb25lbnRzLmVtPntcIiBuZWVkcyB0aGlzIHRvcG9sb2d5IGJ1aWx0IOKAlCB0aGUgcmVjdXJzaW9uLiBDb25maXJtIHRoZSBpbi1wbGF0Zm9ybVxcbmhvc3QgY2FuIGV4cHJlc3MgYSBtdWx0aS1hcHBLZXkgY29tcG9zaXRlIGxhdW5jaCBiZWZvcmUgTTMsIG9yIHRoZSBkb2dmb29kaW5nIG9mIHRoZSBsaXZlIGFwcFxcbndhaXRzIG9uIGl0LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD48Lz47XG59XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNRFhDb250ZW50KHByb3BzID0ge30pIHtcbiAgY29uc3Qge3dyYXBwZXI6IE1EWExheW91dH0gPSB7XG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9O1xuICByZXR1cm4gTURYTGF5b3V0ID8gPE1EWExheW91dCB7Li4ucHJvcHN9PjxfY3JlYXRlTWR4Q29udGVudCB7Li4ucHJvcHN9IC8+PC9NRFhMYXlvdXQ+IDogX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpO1xufVxuZnVuY3Rpb24gX21pc3NpbmdNZHhSZWZlcmVuY2UoaWQsIGNvbXBvbmVudCwgcGxhY2UpIHtcbiAgdGhyb3cgbmV3IEVycm9yKFwiRXhwZWN0ZWQgXCIgKyAoY29tcG9uZW50ID8gXCJjb21wb25lbnRcIiA6IFwib2JqZWN0XCIpICsgXCIgYFwiICsgaWQgKyBcImAgdG8gYmUgZGVmaW5lZDogeW91IGxpa2VseSBmb3Jnb3QgdG8gaW1wb3J0LCBwYXNzLCBvciBwcm92aWRlIGl0LlwiICsgKHBsYWNlID8gXCJcXG5JdOKAmXMgcmVmZXJlbmNlZCBpbiB5b3VyIGNvZGUgYXQgYFwiICsgcGxhY2UgKyBcImAgaW4gYC9hcHAvZG9jcy9zcGVjcy9DT01QT1NJVEVfQ0FQQUJJTElUWV9UT1BPTE9HWV9TUEVDLm1kYFwiIDogXCJcIikpO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFFQSxJQUFBQSxZQUFBLEdBQUFDLE9BQUE7QUFBd0YsSUFBQUMsV0FBQSxHQUFBRCxPQUFBO0FBRnhGO0FBQ0E7O0FBRUEsU0FBU0UsaUJBQWlCQSxDQUFDQyxLQUFLLEVBQUU7RUFDaEMsTUFBTUMsV0FBVyxHQUFHO01BQ2xCQyxVQUFVLEVBQUUsWUFBWTtNQUN4QkMsSUFBSSxFQUFFLE1BQU07TUFDWkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsR0FBRyxFQUFFLEtBQUs7TUFDVkMsTUFBTSxFQUFFLFFBQVE7TUFDaEJDLEtBQUssRUFBRSxPQUFPO01BQ2RDLEtBQUssRUFBRSxPQUFPO01BQ2RDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEtBQUssRUFBRSxPQUFPO01BQ2RDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1IsR0FBRyxJQUFBQyw2QkFBa0IsRUFBQyxDQUFDO01BQ3ZCLEdBQUdyQixLQUFLLENBQUNzQjtJQUNYLENBQUM7SUFBRTtNQUFDQztJQUFhLENBQUMsR0FBR3RCLFdBQVc7RUFDaEMsSUFBSSxDQUFDc0IsYUFBYSxFQUFFQyxvQkFBb0IsQ0FBQyxlQUFlLEVBQUUsSUFBSSxDQUFDO0VBQy9ELG9CQUFPLElBQUExQixXQUFBLENBQUEyQixJQUFBLEVBQUEzQixXQUFBLENBQUE0QixRQUFBO0lBQUFDLFFBQUEsZ0JBQUUsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0ksRUFBRTtNQUFDdUIsRUFBRSxFQUFDLDhGQUE4RjtNQUFBRCxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQThGLENBQUUsQ0FBQyxFQUFDLG9HQUFvRztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFTLENBQXFCLENBQUMsRUFBQyxzQkFBc0IsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFTLENBQXFCLENBQUMsRUFBQyw0Q0FBNEMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBeUIsQ0FBbUIsQ0FBQyxFQUFDLDJCQUEyQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVUsQ0FBcUIsQ0FBQyxFQUFDLDhJQUE4SSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQUksQ0FBcUIsQ0FBQyxFQUFDLDhCQUE4QixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVUsQ0FBcUIsQ0FBQyxFQUFDLHNCQUFzQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFRLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBSSxDQUFxQixDQUFDLEVBQUMsNkNBQTZDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBSSxDQUFxQixDQUFDLEVBQUMsc0JBQXNCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBUyxDQUFxQixDQUFDLEVBQUMsdUNBQXVDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBbUIsQ0FBcUIsQ0FBQyxFQUFDLGtDQUFrQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVUsQ0FBcUIsQ0FBQyxFQUFDLGFBQWE7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNDLFVBQVU7TUFBQXlCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztRQUFBZ0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsR0FBRSw0REFBNEQsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1lBQUF3QixRQUFBLEVBQUU7VUFBcUQsQ0FBbUIsQ0FBQztRQUFBLENBQW9CLENBQUMsRUFBQywyRUFBMkU7TUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQXlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsVUFBVTtNQUFBeUIsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDVSxDQUFDO1FBQUFnQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWMsQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBZ0MsQ0FBbUIsQ0FBQyxFQUFDLGlHQUFpRyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFpQyxDQUFtQixDQUFDLEVBQUMsMENBQTBDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQW9CLENBQW1CLENBQUMsRUFBQyxxR0FBcUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBK0IsQ0FBbUIsQ0FBQyxFQUFDLHdIQUF3SCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUF5QixDQUFtQixDQUFDLEVBQUMsMkNBQTJDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQWlDLENBQW1CLENBQUMsRUFBQywwRkFBMEYsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBZ0MsQ0FBbUIsQ0FBQyxFQUFDLHFDQUFxQztNQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBeUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDTyxFQUFFLElBQUUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBVixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNLLEVBQUU7TUFBQ3NCLEVBQUUsRUFBQyxPQUFPO01BQUMsYUFBVSwwREFBMEQ7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLDZDQUE2QyxlQUFDLElBQUE5QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUFvQixDQUFpQixDQUFDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLEdBQUUsK0JBQStCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBSyxDQUFxQixDQUFDLEVBQUMsNkJBQTZCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQWdCLENBQW1CLENBQUMsRUFBQyxpRUFBaUUsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1FBQUF1QixRQUFBLEVBQUU7TUFBdUMsQ0FBaUIsQ0FBQyxFQUFDLHdGQUF3RixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQXFHLENBQXFCLENBQUMsRUFBQyxvSUFBb0ksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1FBQUF1QixRQUFBLEVBQUU7TUFBVSxDQUFpQixDQUFDLEVBQUMsc0lBQXNJO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLEVBQUU7SUFBK0IsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUyxFQUFFO01BQUFpQixRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBZ0MsQ0FBcUIsQ0FBQyxFQUFDLDRDQUE0QyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUF3QixDQUFtQixDQUFDLEVBQUMsNEJBQTRCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLCtJQUErSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsR0FBRSx3REFBd0QsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1lBQUF1QixRQUFBLEVBQUU7VUFBZ0IsQ0FBaUIsQ0FBQyxFQUFDLFFBQVEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1lBQUF1QixRQUFBLEVBQUU7VUFBbUIsQ0FBaUIsQ0FBQyxFQUFDLEdBQUc7UUFBQSxDQUFxQixDQUFDLEVBQUMsbU5BQW1OLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQVksQ0FBaUIsQ0FBQyxFQUFDLG1CQUFtQjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDSyxFQUFFO01BQUNzQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUsa0VBQWtFO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQyw0REFBNEQsZUFBQyxJQUFBOUIsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1FBQUF1QixRQUFBLEVBQUU7TUFBYSxDQUFpQixDQUFDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLEdBQUUsK0VBQStFLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBZ0MsQ0FBcUIsQ0FBQyxFQUFDLFFBQVEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBUSxDQUFtQixDQUFDLEVBQUMsZ0NBQWdDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBZ0MsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBYyxDQUFtQixDQUFDLEVBQUMsa0dBQWtHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBVSxDQUFxQixDQUFDLEVBQUMsd0JBQXdCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBTSxDQUFxQixDQUFDLEVBQUMsOENBQThDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQWlCLENBQW1CLENBQUMsRUFBQyx3SEFBd0gsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNLLEVBQUU7TUFBQ3NCLEVBQUUsRUFBQyxPQUFPO01BQUMsYUFBVSw2RUFBNkU7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLG1FQUFtRSxlQUFDLElBQUE5QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUF3QixDQUFpQixDQUFDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLEdBQUUsdURBQXVELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQW9DLENBQW1CLENBQUMsRUFBQyxxQ0FBcUMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFNLENBQXFCLENBQUMsRUFBQyw2RUFBNkU7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNhLEtBQUs7TUFBQWEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDaUIsS0FBSztRQUFBUyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBZ0IsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQU8sQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQVcsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQU0sQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQVUsQ0FBaUIsQ0FBQztRQUFBLENBQWdCO01BQUMsQ0FBbUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2MsS0FBSztRQUFBWSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBb0IsQ0FBcUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQVMsQ0FBbUIsQ0FBQyxFQUFDLCtCQUErQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQThDLENBQXFCLENBQUMsRUFBQyxxQ0FBcUMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFnQixDQUFxQixDQUFDO1VBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBK0MsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBMkIsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBNEIsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBUSxDQUFxQjtVQUFDLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFTLENBQXFCLENBQUMsRUFBQyx3QkFBd0IsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLHVDQUF1QyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQWEsQ0FBcUIsQ0FBQztVQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxHQUFFLGdCQUFnQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQWMsQ0FBcUIsQ0FBQyxFQUFDLGdEQUFnRCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFJLENBQW1CLENBQUMsRUFBQyxHQUFHO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBbUMsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBb0UsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBVyxDQUFxQjtVQUFDLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBWSxDQUFtQixDQUFDLEVBQUMsb0JBQW9CLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBSyxDQUFxQixDQUFDLEVBQUMsV0FBVyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFXLENBQW1CLENBQUMsRUFBQyxVQUFVLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQWEsQ0FBbUIsQ0FBQyxFQUFDLDBDQUEwQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQXFCLENBQXFCLENBQUMsRUFBQyxPQUFPO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEdBQUUsUUFBUSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQStDLENBQXFCLENBQUMsRUFBQyxxQ0FBcUM7VUFBQSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFvQyxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBb0IsQ0FBcUIsQ0FBQyxFQUFDLDJCQUEyQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQVcsQ0FBcUIsQ0FBQyxFQUFDLHVGQUF1RjtVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQVcsQ0FBcUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQVUsQ0FBbUIsQ0FBQyxFQUFDLGFBQWEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBUyxDQUFtQixDQUFDLEVBQUMsd0JBQXdCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1ksTUFBTTtjQUFBYyxRQUFBLEdBQUUsOEJBQThCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtnQkFBQXdCLFFBQUEsRUFBRTtjQUFXLENBQW1CLENBQUMsRUFBQyxtQkFBbUI7WUFBQSxDQUFxQixDQUFDLEVBQUMsUUFBUTtVQUFBLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQTJCLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxHQUFFLDREQUE0RCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFNLENBQW1CLENBQUMsRUFBQyxHQUFHO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBc0QsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUM7TUFBQSxDQUFtQixDQUFDO0lBQUEsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBa0QsQ0FBcUI7SUFBQyxDQUFlLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ21CLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXlDLENBQXFCLENBQUMsRUFBQywrQ0FBK0MsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFXLENBQXFCLENBQUMsRUFBQyxtQkFBbUIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBZSxDQUFpQixDQUFDLEVBQUMseUJBQXlCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsYUFBYSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFPLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQWtCLENBQW1CLENBQUMsRUFBQyxNQUFNLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBaUMsQ0FBcUIsQ0FBQyxFQUFDLDZFQUE2RTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFzQyxDQUFxQixDQUFDLEVBQUMsOERBQThELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQTRCLENBQW1CLENBQUMsRUFBQyxJQUFJO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTRELENBQXFCLENBQUMsRUFBQyxpRUFBaUUsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsU0FBUyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQUksQ0FBcUIsQ0FBQyxFQUFDLGdCQUFnQjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDSyxFQUFFO01BQUNzQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUsNEZBQTRGO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQyxxRUFBcUUsZUFBQyxJQUFBOUIsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1FBQUF1QixRQUFBLEVBQUU7TUFBaUMsQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLHNEQUFzRCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQTZFLENBQXFCLENBQUMsRUFBQyw2QkFBNkIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBa0MsQ0FBbUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNXLEdBQUc7TUFBQWUsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUEyTCxDQUFtQjtJQUFDLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ21CLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQW1CLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQVEsQ0FBbUIsQ0FBQyxFQUFDLHNCQUFzQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFNLENBQW1CLENBQUMsRUFBQyxxQkFBcUIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBVSxDQUFtQixDQUFDLEVBQUMsaUVBQWlFO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQVMsQ0FBcUIsQ0FBQyxFQUFDLGdEQUFnRCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFNLENBQW1CLENBQUMsRUFBQyw0Q0FBNEMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBWSxDQUFtQixDQUFDLEVBQUMsVUFBVSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQyxZQUFZLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBSSxDQUFxQixDQUFDLEVBQUMsd0NBQXdDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQXdCLENBQW1CLENBQUMsRUFBQyx5SUFBeUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFpQixDQUFxQixDQUFDLEVBQUMsc0NBQXNDO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQVksQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFrQyxDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFRLENBQW1CLENBQUMsRUFBQywrQkFBK0IsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBTSxDQUFtQixDQUFDLEVBQUMsb0ZBQW9GLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQUssQ0FBaUIsQ0FBQyxFQUFDLCtDQUErQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQywrQ0FBK0MsZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsR0FBRSwwQkFBMEIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1lBQUF3QixRQUFBLEVBQUU7VUFBWSxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7WUFBQXdCLFFBQUEsRUFBRTtVQUFhLENBQW1CLENBQUMsRUFBQyxnQkFBZ0I7UUFBQSxDQUFxQixDQUFDLEVBQUMsb0NBQW9DLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBYSxDQUFxQixDQUFDLEVBQUMsUUFBUSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXlCLENBQXFCLENBQUMsRUFBQyxZQUFZLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQXdCLENBQW1CLENBQUMsRUFBQyw4RkFBOEY7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBWSxDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFRLENBQW1CLENBQUMsRUFBQyxjQUFjLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQU0sQ0FBbUIsQ0FBQyxFQUFDLHVCQUF1QixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQyx3QkFBd0IsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsdUNBQXVDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQVUsQ0FBaUIsQ0FBQyxFQUFDLGtGQUFrRixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFZLENBQW1CLENBQUMsRUFBQyxJQUFJO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNVLENBQUM7TUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBb0MsQ0FBcUIsQ0FBQyxFQUFDLDhCQUE4QixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUFRLENBQWlCLENBQUMsRUFBQyw4QkFBOEIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBNkIsQ0FBbUIsQ0FBQyxFQUFDLHdKQUF3SjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDc0IsRUFBRSxFQUFDLE9BQU87TUFBQyxhQUFVLCtEQUErRDtNQUFBRCxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMsMERBQTBELGVBQUMsSUFBQTlCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQWEsQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLDJGQUEyRixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFnQixDQUFtQixDQUFDLEVBQUMsNkJBQTZCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBeUIsQ0FBcUIsQ0FBQyxFQUFDLEdBQUc7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNhLEtBQUs7TUFBQWEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDaUIsS0FBSztRQUFBUyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBTyxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBa0IsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQVksQ0FBaUIsQ0FBQztRQUFBLENBQWdCO01BQUMsQ0FBbUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2MsS0FBSztRQUFBWSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBWSxDQUFxQjtVQUFDLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO2NBQUF1QixRQUFBLEVBQUU7WUFBVSxDQUFpQixDQUFDLEVBQUMsZ0JBQWdCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQVEsQ0FBbUIsQ0FBQyxFQUFDLHFDQUFxQztVQUFBLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxHQUFFLHVCQUF1QixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFRLENBQW1CLENBQUMsRUFBQyxXQUFXLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBTyxDQUFxQixDQUFDLEVBQUMsZ0VBQWdFLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQVUsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFJLENBQXFCO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7Y0FBQXVCLFFBQUEsRUFBRTtZQUFVLENBQWlCLENBQUMsRUFBQyw2RkFBNkY7VUFBQSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsR0FBRSxnREFBZ0QsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBYSxDQUFtQixDQUFDLEVBQUMsaURBQWlEO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBSSxDQUFxQjtVQUFDLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO2NBQUF1QixRQUFBLEVBQUU7WUFBb0IsQ0FBaUIsQ0FBQyxFQUFDLHNEQUFzRCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFRLENBQW1CLENBQUMsRUFBQyx3QkFBd0I7VUFBQSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFrRSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFJLENBQXFCO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7Y0FBQXVCLFFBQUEsRUFBRTtZQUFtQixDQUFpQixDQUFDLEVBQUMscUJBQXFCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQVMsQ0FBbUIsQ0FBQyxFQUFDLHVEQUF1RDtVQUFBLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxHQUFFLHNCQUFzQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFXLENBQW1CLENBQUMsRUFBQyxrQ0FBa0M7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQztNQUFBLENBQW1CLENBQUM7SUFBQSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNVLENBQUM7TUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBNEIsQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDRyxFQUFFO1FBQUF1QixRQUFBLEdBQUUsdU1BQXVNLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQVEsQ0FBbUIsQ0FBQyxFQUFDLHdEQUF3RDtNQUFBLENBQWlCLENBQUMsRUFBQyw0U0FBNFMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBUSxDQUFtQixDQUFDLEVBQUMsMkRBQTJELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBOEYsQ0FBcUIsQ0FBQztJQUFBLENBQWUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDSyxFQUFFO01BQUNzQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUsbURBQW1EO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQyxxQ0FBcUMsZUFBQyxJQUFBOUIsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1FBQUF1QixRQUFBLEVBQUU7TUFBb0IsQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ21CLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTRCLENBQXFCLENBQUMsRUFBQyxrRUFBa0UsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBUSxDQUFpQixDQUFDLEVBQUMsMkRBQTJELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBUyxDQUFxQixDQUFDLEVBQUMsb0ZBQW9GO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTJCLENBQXFCLENBQUMsRUFBQyx5QkFBeUIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsZ0JBQWdCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLG1EQUFtRCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFnQixDQUFtQixDQUFDLEVBQUMsNEZBQTRGO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXlDLENBQXFCLENBQUMsRUFBQywySUFBMkk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBb0MsQ0FBcUIsQ0FBQyxFQUFDLDREQUE0RCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFtQixDQUFtQixDQUFDLEVBQUMsNEVBQTRFO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQStCLENBQXFCLENBQUMsRUFBQyw4QkFBOEIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBTSxDQUFtQixDQUFDLEVBQUMscUZBQXFGLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQU8sQ0FBbUIsQ0FBQyxFQUFDLHlEQUF5RCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyxNQUFNLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQVMsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBVSxDQUFtQixDQUFDLEVBQUMsSUFBSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDSyxFQUFFO01BQUNzQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUseUNBQXlDO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQyw0Q0FBNEM7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNNLEVBQUU7TUFBQ3FCLEVBQUUsRUFBQyxzQ0FBc0M7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFzQyxDQUFFLENBQUMsRUFBQyx3Q0FBd0M7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNhLEtBQUs7TUFBQWEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDaUIsS0FBSztRQUFBUyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBb0QsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQTZCLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNnQixFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFxQixDQUFpQixDQUFDO1FBQUEsQ0FBZ0I7TUFBQyxDQUFtQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDYyxLQUFLO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFnRSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBNkQsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBa0IsQ0FBbUI7VUFBQyxDQUFnQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsR0FBRSxrQ0FBa0MsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBa0IsQ0FBbUIsQ0FBQyxFQUFDLDhCQUE4QjtVQUFBLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUEwRCxDQUFtQjtVQUFDLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFvQixDQUFtQjtVQUFDLENBQWdCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQWtGLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUF5RCxDQUFtQjtVQUFDLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFXLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQztRQUFBLENBQWdCLENBQUM7TUFBQSxDQUFtQixDQUFDO0lBQUEsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDTSxFQUFFO01BQUNxQixFQUFFLEVBQUMsMERBQTBEO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBMEQsQ0FBRSxDQUFDLEVBQUMsNERBQTREO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDYSxLQUFLO01BQUFhLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2lCLEtBQUs7UUFBQVMsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQWUsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQXVCLENBQWlCLENBQUM7UUFBQSxDQUFnQjtNQUFDLENBQW1CLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNjLEtBQUs7UUFBQVksUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxHQUFFLG9DQUFvQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFRLENBQW1CLENBQUMsRUFBQyw0QkFBNEI7VUFBQSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsR0FBRSxxR0FBcUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBSSxDQUFtQixDQUFDO1VBQUEsQ0FBZ0IsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBaUUsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEdBQUUsK0NBQStDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQWEsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBWSxDQUFtQixDQUFDLEVBQUMsK0NBQStDO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEdBQUUsOERBQThELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQVEsQ0FBbUIsQ0FBQyxFQUFDLE9BQU87VUFBQSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFvRyxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUF5RSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFvRyxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUEyRCxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUF1RixDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFtRSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUEyRSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQztNQUFBLENBQW1CLENBQUM7SUFBQSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNLLEVBQUU7TUFBQ3NCLEVBQUUsRUFBQyxPQUFPO01BQUMsYUFBVSxtQ0FBbUM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLHNDQUFzQztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ21CLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTZGLENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLDBJQUEwSSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFXLENBQWlCLENBQUMsRUFBQywwQkFBMEIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsaURBQWlEO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWtFLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLHlEQUF5RCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyxrQ0FBa0M7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBeUQsQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBVyxDQUFpQixDQUFDLEVBQUMsc0dBQXNHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTBGLENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLHlFQUF5RTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUEwRCxDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFXLENBQWlCLENBQUMsRUFBQyx3SEFBd0g7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDc0IsRUFBRSxFQUFDLE9BQU87TUFBQyxhQUFVLGtCQUFrQjtNQUFBRCxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMsbUJBQW1CO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDbUIsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBOEIsQ0FBcUIsQ0FBQyxFQUFDLHdEQUF3RCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUF3QixDQUFtQixDQUFDLEVBQUMsc0RBQXNELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBUyxDQUFxQixDQUFDLEVBQUMsd01BQXdNO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXVDLENBQXFCLENBQUMsRUFBQyxvR0FBb0csZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBVyxDQUFpQixDQUFDLEVBQUMsdURBQXVELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQThCLENBQW1CLENBQUMsRUFBQyw2QkFBNkIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBYyxDQUFtQixDQUFDLEVBQUMsaUxBQWlMLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQVEsQ0FBaUIsQ0FBQyxFQUFDLEdBQUc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEdBQUUsOEJBQThCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBd0IsUUFBQSxFQUFFO1VBQXdCLENBQW1CLENBQUMsRUFBQyxPQUFPO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLDBDQUEwQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFhLENBQWlCLENBQUMsRUFBQyxrTEFBa0w7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUM7RUFBQSxDQUFFLENBQUM7QUFDdDA3QjtBQUNlLFNBQVNHLFVBQVVBLENBQUM5QixLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUU7RUFDN0MsTUFBTTtJQUFDK0IsT0FBTyxFQUFFQztFQUFTLENBQUMsR0FBRztJQUMzQixHQUFHLElBQUFYLDZCQUFrQixFQUFDLENBQUM7SUFDdkIsR0FBR3JCLEtBQUssQ0FBQ3NCO0VBQ1gsQ0FBQztFQUNELE9BQU9VLFNBQVMsZ0JBQUcsSUFBQWxDLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ0csU0FBUztJQUFBLEdBQUtoQyxLQUFLO0lBQUEyQixRQUFBLGVBQUUsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzlCLGlCQUFpQjtNQUFBLEdBQUtDO0lBQUssQ0FBRztFQUFDLENBQVcsQ0FBQyxHQUFHRCxpQkFBaUIsQ0FBQ0MsS0FBSyxDQUFDO0FBQ2xIO0FBQUNpQyxFQUFBLEdBTnVCSCxVQUFVO0FBT2xDLFNBQVNOLG9CQUFvQkEsQ0FBQ0ksRUFBRSxFQUFFTSxTQUFTLEVBQUVDLEtBQUssRUFBRTtFQUNsRCxNQUFNLElBQUlDLEtBQUssQ0FBQyxXQUFXLElBQUlGLFNBQVMsR0FBRyxXQUFXLEdBQUcsUUFBUSxDQUFDLEdBQUcsSUFBSSxHQUFHTixFQUFFLEdBQUcsb0VBQW9FLElBQUlPLEtBQUssR0FBRyxxQ0FBcUMsR0FBR0EsS0FBSyxHQUFHLDhEQUE4RCxHQUFHLEVBQUUsQ0FBQyxDQUFDO0FBQ3hSO0FBQUMsSUFBQUYsRUFBQTtBQUFBSSxZQUFBLENBQUFKLEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}