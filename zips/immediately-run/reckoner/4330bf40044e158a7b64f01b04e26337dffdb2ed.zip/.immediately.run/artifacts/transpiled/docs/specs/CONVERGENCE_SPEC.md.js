var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      blockquote: "blockquote",
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      hr: "hr",
      li: "li",
      ol: "ol",
      p: "p",
      pre: "pre",
      strong: "strong",
      table: "table",
      tbody: "tbody",
      td: "td",
      th: "th",
      thead: "thead",
      tr: "tr",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "reckoner-convergence-the-explicit-fixed-point-the-cell-kind-decision-and-the-reopening-criterion",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "reckoner-convergence-the-explicit-fixed-point-the-cell-kind-decision-and-the-reopening-criterion"
      }), "Reckoner Convergence — the explicit fixed point, the cell-kind decision, and the reopening criterion"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Status:"
      }), " proposal — the design spike R3-379 owed; the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "go/no-go is recorded in §4"
      }), " (helper-only, with a named reopening criterion) · ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Updated:"
      }), " 2026-08-27"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Reads first:"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "ENGINE_INFORMATION_FLOW_SPEC.md",
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "ENGINE_INFORMATION_FLOW_SPEC.md"
          })
        }), "\n(the epoch × tier × egress-channel contract any diagnostics channel must ride),\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "../LBO_GAP_CLOSURE_PLAN.md",
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "../LBO_GAP_CLOSURE_PLAN.md"
          })
        }), " §1 W6/W7 (the plan that\nsplit this into helper-first, design-second), the gap analysis\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "../LBO_CASE_STUDY_GAP_ANALYSIS.md",
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "../LBO_CASE_STUDY_GAP_ANALYSIS.md"
          })
        }), " §2 G1 (the\nfinding), and the shipped evidence: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/stdlib/fixpoint.ts"
        }), " (R3-378) + its\nport-forward in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "docs/case-study/caldera/document/worksheets/model.sheet.js"
        }), "\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "debt_schedule_avg"
        }), ")."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-1",
      "data-slug": "1-the-problem-restated-once",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-1"
      }), "1 — The problem, restated once"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Real financial models contain genuinely circular calculations — average-balance\ninterest is the canonical one: interest → cash flow → sweep → ending balance →\ninterest. Excel's answer is iterative-calculation mode: circular references converge\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "invisibly"
      }), ", or silently degrade to zero / oscillate — a famous silent-error class that\ncommercial audit tooling exists specifically to catch. Reckoner's scheduler rejects\ncycles outright (correctly — an acyclic graph is what glitch-free recalc, tier folding,\nand trace replay all rest on), so convergent calculations must be expressed some other\nway."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-2",
      "data-slug": "2-what-already-shipped-the-evidence-this-decision-reads",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-2"
      }), "2 — What already shipped (the evidence this decision reads)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["R3-378 shipped ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "fixpoint(initial, step, {tol, maxIterations}) → { converged, iterations, value }"
      }), " and the Caldera case study's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "debt_schedule_avg"
      }), " uses it:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Convergence"
        }), " — the helper returns the fixed point."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Visible failure"
        }), " — the port ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "throws"
        }), " on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "converged: false"
        }), " (\"average-balance\ninterest did not converge in year N\"), which the engine surfaces as a cell error on\nthe result channel: the opposite of Excel's silent behavior."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Evidence as data"
        }), " — the iteration count travels ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "in the cell's value"
        }), " (the\nschedule rows carry ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "iterations"
        }), "), which means it is inspectable in the value\ninspector, diffable, and — uniquely — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "testable"
        }), ": the case study's\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "sched_avg_converges"
        }), " property test asserts on it."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Budget"
        }), " — a fixed-point loop inside one formula's evaluation is bounded by the\nengine's existing per-eval wall-clock watchdog; a divergent step terminates the eval,\ntrips the circuit breaker, and quarantines the cell exactly like any other runaway\nformula. No new accounting exists or is needed at this scale (200-iteration caps,\nµs-per-step loops)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-3",
      "data-slug": "3-what-a-converged-cell-kind-would-add-honestly",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-3"
      }), "3 — What a converged ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "cell kind"
      }), " would add, honestly"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["A first-class ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "convergedCell({...})"
      }), " constructor could add, beyond §2:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Capability"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Helper-only today"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Cell kind"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Verdict"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Convergence + visible failure"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "✓ (helper + throw convention)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "same"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "no delta"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Iteration counts surfaced"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "as data in the value (testable, diffable)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["on a trace channel (ENGINE_INFORMATION_FLOW ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "(epoch, tier)"
            }), "-tagged)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["the channel is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
              children: "metadata"
            }), "; the data form is strictly more expressive for documents; a channel would matter only for cross-cell dashboards nobody has asked for"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Non-convergence as a lattice error"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "throw → cell error on the result channel (dependents see the propagated error)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "first-class error kind"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "same observable behavior; a new kind adds taxonomy, not behavior"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Budget accounting across many converged cells"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "each eval under the per-eval watchdog; no aggregate view"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "a per-cell iteration budget the scheduler tracks"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "an aggregate view with no consumer; per-eval watchdog already bounds the real risk (runaway)"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Cross-cell dependency on the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
              children: "converged state"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "impossible (intra-cell by design — the graph stays acyclic)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "could publish the fixed point as a cell value others depend on"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["expressible today by splitting the model (one cell converges and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
              children: "returns"
            }), " the state; dependents consume it) — the Caldera port proves the pattern"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Versioning"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "n/a"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["a new constructor = stdlib addition + derived ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "compat.stdlib"
            }), " floor bump for documents using it"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "pure cost until there is a consumer"
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-4",
      "data-slug": "4-the-decision-gono-go-against-the-named-criterion",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-4"
      }), "4 — The decision (go/no-go, against the named criterion)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The criterion set by the plan: ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["implement the cell kind only if a real document needs\nconvergence ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "diagnostics"
        }), " — iteration counts surfaced in the review surface, budget\naccounting — not merely convergence."]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Decision: helper-only, recorded (no-go on the cell kind)."
      }), " The only real consumer\n(Caldera) needs convergence, visible failure, and evidence-as-data — all shipped in\n§2 — and none of the §3 deltas have a consumer. The throw-on-non-convergence\nconvention is hereby pinned as ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "the idiom"
      }), " (see §5) so authors do not re-derive it."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Reopening criterion"
      }), " (any one reopens this decision, as a fresh design item against\nthen-current evidence):"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["A document wants ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "review-surface convergence telemetry for many converged cells at\nonce"
        }), " (a \"how hard did this workbook converge\" surface) — the case where\nthreading counts through values is impractical and a trace channel earns its keep."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["A converged calculation whose step is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "too expensive for one eval budget"
        }), " (e.g.\nper-step cost near the watchdog limit), needing scheduler-visible progress or\nbudget splitting."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["A consumer needs ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "the fixed point as a first-class graph node"
        }), " with its own tier,\nepoch, and dependents — i.e. convergence spanning cells rather than inside one."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-5",
      "data-slug": "5-the-pinned-idiom-normative-while-this-spec-stands",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-5"
      }), "5 — The pinned idiom (normative while this spec stands)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "A convergent calculation is expressed as:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-js",
        children: "import { fixpoint } from \"@reckoner/stdlib\";\n\nconst fp = fixpoint(initialState, step, { tol: 1e-12, maxIterations: 200 });\nif (!fp.converged) throw new Error(\"<what> did not converge <where>\");\n// fp.iterations travels in the VALUE (inspectable, diffable, testable)\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Rules:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Throw on non-convergence"
        }), " — never return the last iterate as if it were the\nanswer; never log-and-continue (there is no console in the compartment by design)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Carry the evidence in the value"
        }), " — iteration counts (and residuals, when the\nauthor has them) are data, not diagnostics; tests can and should assert on them."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The step is pure"
        }), " and must not read anything but its argument (the compartment\nenforces this structurally anyway)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Budget"
        }), ": the default 200-iteration cap stands unless the model justifies more;\nthe per-eval watchdog is the outer bound either way."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-6",
      "data-slug": "6-adversarial-self-review-of-the-decision-the-each-pass-attacks-its-prior-rule",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-6"
      }), "6 — Adversarial self-review of the decision (the each-pass-attacks-its-prior rule)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["Attack 1 — \"helper-only is complacent; Excel users get iteration counts ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "without"
        }), "\nauthoring discipline, so the helper will be misused and non-convergence hidden.\""]
      }), "\nThe attack assumes authors can silently ignore ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "converged: false"
      }), " and return the last\niterate. They can — the helper permits it — which is why §5 pins the throw idiom as\nnormative and why the catalog self-description says it. A cell kind could enforce the\nthrow structurally; that is a real (if small) delta, and it is the strongest argument\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "for"
      }), " the cell kind. Rejected because: the same \"author can write it wrong\" objection\napplies to every stdlib callable (an author can also return ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "0/0"
      }), " as ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "null"
      }), " where a\nthrow was owed); the mitigation is review-surface tests on convergence (exactly what\nCaldera's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "sched_avg_converges"
      }), " demonstrates) plus the pinned idiom, not a new engine\nsurface. Recorded as the likeliest reopening pressure."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Attack 2 — \"iteration counts in values pollute the data model; downstream cells must\nstrip them.\""
      }), " True in principle (a consumer of ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "debt_schedule_avg"
      }), " sees an extra\ncolumn); in practice the counts are additive columns that ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "Table"
      }), "/charts ignore unless\nbound, and the alternative (a side channel) makes them invisible to the one consumer\nthat matters — tests. Standing."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Attack 3 — \"the decision reads one case study; finance has other convergent shapes\n(circular working capital, goal-seek-coupled models) that may want the cell kind.\""
      }), "\nConceded as the honest limit: n=1 consumer. This is exactly why §4's reopening\ncriteria are behavioral (telemetry at scale, step cost, cross-cell fixed points)\nrather than feature-shaped — a second case study with a different shape reopens the\nquestion on evidence, not taste."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-7",
      "data-slug": "7-versioning-note",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-7"
      }), "7 — Versioning note"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["No new constructor ships with this decision, so no stdlib compat consequence beyond\nwhat R3-378 already recorded (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "fixpoint"
      }), " is additive). A future cell kind would be a\nnew callable (additive) whose ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "use"
      }), " in a document derives a higher ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "compat.stdlib"
      }), "\nfloor per ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "DOCUMENT_VERSIONING_SPEC"
      }), " §3 — nothing here pre-decides that API."]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/specs/CONVERGENCE_SPEC.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiYmxvY2txdW90ZSIsImNvZGUiLCJlbSIsImgxIiwiaDIiLCJociIsImxpIiwib2wiLCJwIiwicHJlIiwic3Ryb25nIiwidGFibGUiLCJ0Ym9keSIsInRkIiwidGgiLCJ0aGVhZCIsInRyIiwidWwiLCJfcHJvdmlkZUNvbXBvbmVudHMiLCJjb21wb25lbnRzIiwiSGVhZGluZ0FuY2hvciIsIl9taXNzaW5nTWR4UmVmZXJlbmNlIiwianN4cyIsIkZyYWdtZW50IiwiY2hpbGRyZW4iLCJpZCIsImpzeCIsImhyZWYiLCJjbGFzc05hbWUiLCJNRFhDb250ZW50Iiwid3JhcHBlciIsIk1EWExheW91dCIsIl9jIiwiY29tcG9uZW50IiwicGxhY2UiLCJFcnJvciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkNPTlZFUkdFTkNFX1NQRUMubWQiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgYTogXCJhXCIsXG4gICAgYmxvY2txdW90ZTogXCJibG9ja3F1b3RlXCIsXG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgZW06IFwiZW1cIixcbiAgICBoMTogXCJoMVwiLFxuICAgIGgyOiBcImgyXCIsXG4gICAgaHI6IFwiaHJcIixcbiAgICBsaTogXCJsaVwiLFxuICAgIG9sOiBcIm9sXCIsXG4gICAgcDogXCJwXCIsXG4gICAgcHJlOiBcInByZVwiLFxuICAgIHN0cm9uZzogXCJzdHJvbmdcIixcbiAgICB0YWJsZTogXCJ0YWJsZVwiLFxuICAgIHRib2R5OiBcInRib2R5XCIsXG4gICAgdGQ6IFwidGRcIixcbiAgICB0aDogXCJ0aFwiLFxuICAgIHRoZWFkOiBcInRoZWFkXCIsXG4gICAgdHI6IFwidHJcIixcbiAgICB1bDogXCJ1bFwiLFxuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfSwge0hlYWRpbmdBbmNob3J9ID0gX2NvbXBvbmVudHM7XG4gIGlmICghSGVhZGluZ0FuY2hvcikgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJIZWFkaW5nQW5jaG9yXCIsIHRydWUpO1xuICByZXR1cm4gPD48X2NvbXBvbmVudHMuaDEgaWQ9XCJyZWNrb25lci1jb252ZXJnZW5jZS10aGUtZXhwbGljaXQtZml4ZWQtcG9pbnQtdGhlLWNlbGwta2luZC1kZWNpc2lvbi1hbmQtdGhlLXJlb3BlbmluZy1jcml0ZXJpb25cIj48SGVhZGluZ0FuY2hvciBpZD1cInJlY2tvbmVyLWNvbnZlcmdlbmNlLXRoZS1leHBsaWNpdC1maXhlZC1wb2ludC10aGUtY2VsbC1raW5kLWRlY2lzaW9uLWFuZC10aGUtcmVvcGVuaW5nLWNyaXRlcmlvblwiIC8+e1wiUmVja29uZXIgQ29udmVyZ2VuY2Ug4oCUIHRoZSBleHBsaWNpdCBmaXhlZCBwb2ludCwgdGhlIGNlbGwta2luZCBkZWNpc2lvbiwgYW5kIHRoZSByZW9wZW5pbmcgY3JpdGVyaW9uXCJ9PC9fY29tcG9uZW50cy5oMT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlN0YXR1czpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgcHJvcG9zYWwg4oCUIHRoZSBkZXNpZ24gc3Bpa2UgUjMtMzc5IG93ZWQ7IHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImdvL25vLWdvIGlzIHJlY29yZGVkIGluIMKnNFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoaGVscGVyLW9ubHksIHdpdGggYSBuYW1lZCByZW9wZW5pbmcgY3JpdGVyaW9uKSDCtyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlVwZGF0ZWQ6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIDIwMjYtMDgtMjdcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJSZWFkcyBmaXJzdDpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cIkVOR0lORV9JTkZPUk1BVElPTl9GTE9XX1NQRUMubWRcIj48X2NvbXBvbmVudHMuY29kZT57XCJFTkdJTkVfSU5GT1JNQVRJT05fRkxPV19TUEVDLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuYT57XCJcXG4odGhlIGVwb2NoIMOXIHRpZXIgw5cgZWdyZXNzLWNoYW5uZWwgY29udHJhY3QgYW55IGRpYWdub3N0aWNzIGNoYW5uZWwgbXVzdCByaWRlKSxcXG5cIn08X2NvbXBvbmVudHMuYSBocmVmPVwiLi4vTEJPX0dBUF9DTE9TVVJFX1BMQU4ubWRcIj48X2NvbXBvbmVudHMuY29kZT57XCIuLi9MQk9fR0FQX0NMT1NVUkVfUExBTi5tZFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLmE+e1wiIMKnMSBXNi9XNyAodGhlIHBsYW4gdGhhdFxcbnNwbGl0IHRoaXMgaW50byBoZWxwZXItZmlyc3QsIGRlc2lnbi1zZWNvbmQpLCB0aGUgZ2FwIGFuYWx5c2lzXFxuXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cIi4uL0xCT19DQVNFX1NUVURZX0dBUF9BTkFMWVNJUy5tZFwiPjxfY29tcG9uZW50cy5jb2RlPntcIi4uL0xCT19DQVNFX1NUVURZX0dBUF9BTkFMWVNJUy5tZFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLmE+e1wiIMKnMiBHMSAodGhlXFxuZmluZGluZyksIGFuZCB0aGUgc2hpcHBlZCBldmlkZW5jZTogXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL3N0ZGxpYi9maXhwb2ludC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKFIzLTM3OCkgKyBpdHNcXG5wb3J0LWZvcndhcmQgaW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZG9jcy9jYXNlLXN0dWR5L2NhbGRlcmEvZG9jdW1lbnQvd29ya3NoZWV0cy9tb2RlbC5zaGVldC5qc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG4oXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZGVidF9zY2hlZHVsZV9hdmdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5ociAvPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInNlYy0xXCIgZGF0YS1zbHVnPVwiMS10aGUtcHJvYmxlbS1yZXN0YXRlZC1vbmNlXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtMVwiIC8+e1wiMSDigJQgVGhlIHByb2JsZW0sIHJlc3RhdGVkIG9uY2VcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlJlYWwgZmluYW5jaWFsIG1vZGVscyBjb250YWluIGdlbnVpbmVseSBjaXJjdWxhciBjYWxjdWxhdGlvbnMg4oCUIGF2ZXJhZ2UtYmFsYW5jZVxcbmludGVyZXN0IGlzIHRoZSBjYW5vbmljYWwgb25lOiBpbnRlcmVzdCDihpIgY2FzaCBmbG93IOKGkiBzd2VlcCDihpIgZW5kaW5nIGJhbGFuY2Ug4oaSXFxuaW50ZXJlc3QuIEV4Y2VsJ3MgYW5zd2VyIGlzIGl0ZXJhdGl2ZS1jYWxjdWxhdGlvbiBtb2RlOiBjaXJjdWxhciByZWZlcmVuY2VzIGNvbnZlcmdlXFxuXCJ9PF9jb21wb25lbnRzLmVtPntcImludmlzaWJseVwifTwvX2NvbXBvbmVudHMuZW0+e1wiLCBvciBzaWxlbnRseSBkZWdyYWRlIHRvIHplcm8gLyBvc2NpbGxhdGUg4oCUIGEgZmFtb3VzIHNpbGVudC1lcnJvciBjbGFzcyB0aGF0XFxuY29tbWVyY2lhbCBhdWRpdCB0b29saW5nIGV4aXN0cyBzcGVjaWZpY2FsbHkgdG8gY2F0Y2guIFJlY2tvbmVyJ3Mgc2NoZWR1bGVyIHJlamVjdHNcXG5jeWNsZXMgb3V0cmlnaHQgKGNvcnJlY3RseSDigJQgYW4gYWN5Y2xpYyBncmFwaCBpcyB3aGF0IGdsaXRjaC1mcmVlIHJlY2FsYywgdGllciBmb2xkaW5nLFxcbmFuZCB0cmFjZSByZXBsYXkgYWxsIHJlc3Qgb24pLCBzbyBjb252ZXJnZW50IGNhbGN1bGF0aW9ucyBtdXN0IGJlIGV4cHJlc3NlZCBzb21lIG90aGVyXFxud2F5LlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtMlwiIGRhdGEtc2x1Zz1cIjItd2hhdC1hbHJlYWR5LXNoaXBwZWQtdGhlLWV2aWRlbmNlLXRoaXMtZGVjaXNpb24tcmVhZHNcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy0yXCIgLz57XCIyIOKAlCBXaGF0IGFscmVhZHkgc2hpcHBlZCAodGhlIGV2aWRlbmNlIHRoaXMgZGVjaXNpb24gcmVhZHMpXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJSMy0zNzggc2hpcHBlZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmaXhwb2ludChpbml0aWFsLCBzdGVwLCB7dG9sLCBtYXhJdGVyYXRpb25zfSkg4oaSIHsgY29udmVyZ2VkLCBpdGVyYXRpb25zLCB2YWx1ZSB9XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhbmQgdGhlIENhbGRlcmEgY2FzZSBzdHVkeSdzIFwifTxfY29tcG9uZW50cy5jb2RlPntcImRlYnRfc2NoZWR1bGVfYXZnXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB1c2VzIGl0OlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQ29udmVyZ2VuY2VcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHRoZSBoZWxwZXIgcmV0dXJucyB0aGUgZml4ZWQgcG9pbnQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJWaXNpYmxlIGZhaWx1cmVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHRoZSBwb3J0IFwifTxfY29tcG9uZW50cy5lbT57XCJ0aHJvd3NcIn08L19jb21wb25lbnRzLmVtPntcIiBvbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjb252ZXJnZWQ6IGZhbHNlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoXFxcImF2ZXJhZ2UtYmFsYW5jZVxcbmludGVyZXN0IGRpZCBub3QgY29udmVyZ2UgaW4geWVhciBOXFxcIiksIHdoaWNoIHRoZSBlbmdpbmUgc3VyZmFjZXMgYXMgYSBjZWxsIGVycm9yIG9uXFxudGhlIHJlc3VsdCBjaGFubmVsOiB0aGUgb3Bwb3NpdGUgb2YgRXhjZWwncyBzaWxlbnQgYmVoYXZpb3IuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJFdmlkZW5jZSBhcyBkYXRhXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCB0aGUgaXRlcmF0aW9uIGNvdW50IHRyYXZlbHMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJpbiB0aGUgY2VsbCdzIHZhbHVlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICh0aGVcXG5zY2hlZHVsZSByb3dzIGNhcnJ5IFwifTxfY29tcG9uZW50cy5jb2RlPntcIml0ZXJhdGlvbnNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSwgd2hpY2ggbWVhbnMgaXQgaXMgaW5zcGVjdGFibGUgaW4gdGhlIHZhbHVlXFxuaW5zcGVjdG9yLCBkaWZmYWJsZSwgYW5kIOKAlCB1bmlxdWVseSDigJQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ0ZXN0YWJsZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIjogdGhlIGNhc2Ugc3R1ZHknc1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcInNjaGVkX2F2Z19jb252ZXJnZXNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHByb3BlcnR5IHRlc3QgYXNzZXJ0cyBvbiBpdC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkJ1ZGdldFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgYSBmaXhlZC1wb2ludCBsb29wIGluc2lkZSBvbmUgZm9ybXVsYSdzIGV2YWx1YXRpb24gaXMgYm91bmRlZCBieSB0aGVcXG5lbmdpbmUncyBleGlzdGluZyBwZXItZXZhbCB3YWxsLWNsb2NrIHdhdGNoZG9nOyBhIGRpdmVyZ2VudCBzdGVwIHRlcm1pbmF0ZXMgdGhlIGV2YWwsXFxudHJpcHMgdGhlIGNpcmN1aXQgYnJlYWtlciwgYW5kIHF1YXJhbnRpbmVzIHRoZSBjZWxsIGV4YWN0bHkgbGlrZSBhbnkgb3RoZXIgcnVuYXdheVxcbmZvcm11bGEuIE5vIG5ldyBhY2NvdW50aW5nIGV4aXN0cyBvciBpcyBuZWVkZWQgYXQgdGhpcyBzY2FsZSAoMjAwLWl0ZXJhdGlvbiBjYXBzLFxcbsK1cy1wZXItc3RlcCBsb29wcykuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInNlYy0zXCIgZGF0YS1zbHVnPVwiMy13aGF0LWEtY29udmVyZ2VkLWNlbGwta2luZC13b3VsZC1hZGQtaG9uZXN0bHlcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy0zXCIgLz57XCIzIOKAlCBXaGF0IGEgY29udmVyZ2VkIFwifTxfY29tcG9uZW50cy5lbT57XCJjZWxsIGtpbmRcIn08L19jb21wb25lbnRzLmVtPntcIiB3b3VsZCBhZGQsIGhvbmVzdGx5XCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJBIGZpcnN0LWNsYXNzIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNvbnZlcmdlZENlbGwoey4uLn0pXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjb25zdHJ1Y3RvciBjb3VsZCBhZGQsIGJleW9uZCDCpzI6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy50YWJsZT48X2NvbXBvbmVudHMudGhlYWQ+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50aD57XCJDYXBhYmlsaXR5XCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGg+e1wiSGVscGVyLW9ubHkgdG9kYXlcIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aD57XCJDZWxsIGtpbmRcIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aD57XCJWZXJkaWN0XCJ9PC9fY29tcG9uZW50cy50aD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGhlYWQ+PF9jb21wb25lbnRzLnRib2R5PjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiQ29udmVyZ2VuY2UgKyB2aXNpYmxlIGZhaWx1cmVcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCLinJMgKGhlbHBlciArIHRocm93IGNvbnZlbnRpb24pXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wic2FtZVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIm5vIGRlbHRhXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiSXRlcmF0aW9uIGNvdW50cyBzdXJmYWNlZFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcImFzIGRhdGEgaW4gdGhlIHZhbHVlICh0ZXN0YWJsZSwgZGlmZmFibGUpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wib24gYSB0cmFjZSBjaGFubmVsIChFTkdJTkVfSU5GT1JNQVRJT05fRkxPVyBcIn08X2NvbXBvbmVudHMuY29kZT57XCIoZXBvY2gsIHRpZXIpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi10YWdnZWQpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1widGhlIGNoYW5uZWwgaXMgXCJ9PF9jb21wb25lbnRzLmVtPntcIm1ldGFkYXRhXCJ9PC9fY29tcG9uZW50cy5lbT57XCI7IHRoZSBkYXRhIGZvcm0gaXMgc3RyaWN0bHkgbW9yZSBleHByZXNzaXZlIGZvciBkb2N1bWVudHM7IGEgY2hhbm5lbCB3b3VsZCBtYXR0ZXIgb25seSBmb3IgY3Jvc3MtY2VsbCBkYXNoYm9hcmRzIG5vYm9keSBoYXMgYXNrZWQgZm9yXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiTm9uLWNvbnZlcmdlbmNlIGFzIGEgbGF0dGljZSBlcnJvclwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcInRocm93IOKGkiBjZWxsIGVycm9yIG9uIHRoZSByZXN1bHQgY2hhbm5lbCAoZGVwZW5kZW50cyBzZWUgdGhlIHByb3BhZ2F0ZWQgZXJyb3IpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiZmlyc3QtY2xhc3MgZXJyb3Iga2luZFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcInNhbWUgb2JzZXJ2YWJsZSBiZWhhdmlvcjsgYSBuZXcga2luZCBhZGRzIHRheG9ub215LCBub3QgYmVoYXZpb3JcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJCdWRnZXQgYWNjb3VudGluZyBhY3Jvc3MgbWFueSBjb252ZXJnZWQgY2VsbHNcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJlYWNoIGV2YWwgdW5kZXIgdGhlIHBlci1ldmFsIHdhdGNoZG9nOyBubyBhZ2dyZWdhdGUgdmlld1wifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcImEgcGVyLWNlbGwgaXRlcmF0aW9uIGJ1ZGdldCB0aGUgc2NoZWR1bGVyIHRyYWNrc1wifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcImFuIGFnZ3JlZ2F0ZSB2aWV3IHdpdGggbm8gY29uc3VtZXI7IHBlci1ldmFsIHdhdGNoZG9nIGFscmVhZHkgYm91bmRzIHRoZSByZWFsIHJpc2sgKHJ1bmF3YXkpXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiQ3Jvc3MtY2VsbCBkZXBlbmRlbmN5IG9uIHRoZSBcIn08X2NvbXBvbmVudHMuZW0+e1wiY29udmVyZ2VkIHN0YXRlXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJpbXBvc3NpYmxlIChpbnRyYS1jZWxsIGJ5IGRlc2lnbiDigJQgdGhlIGdyYXBoIHN0YXlzIGFjeWNsaWMpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiY291bGQgcHVibGlzaCB0aGUgZml4ZWQgcG9pbnQgYXMgYSBjZWxsIHZhbHVlIG90aGVycyBkZXBlbmQgb25cIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJleHByZXNzaWJsZSB0b2RheSBieSBzcGxpdHRpbmcgdGhlIG1vZGVsIChvbmUgY2VsbCBjb252ZXJnZXMgYW5kIFwifTxfY29tcG9uZW50cy5lbT57XCJyZXR1cm5zXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgdGhlIHN0YXRlOyBkZXBlbmRlbnRzIGNvbnN1bWUgaXQpIOKAlCB0aGUgQ2FsZGVyYSBwb3J0IHByb3ZlcyB0aGUgcGF0dGVyblwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIlZlcnNpb25pbmdcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJuL2FcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJhIG5ldyBjb25zdHJ1Y3RvciA9IHN0ZGxpYiBhZGRpdGlvbiArIGRlcml2ZWQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY29tcGF0LnN0ZGxpYlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZmxvb3IgYnVtcCBmb3IgZG9jdW1lbnRzIHVzaW5nIGl0XCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wicHVyZSBjb3N0IHVudGlsIHRoZXJlIGlzIGEgY29uc3VtZXJcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50Ym9keT48L19jb21wb25lbnRzLnRhYmxlPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInNlYy00XCIgZGF0YS1zbHVnPVwiNC10aGUtZGVjaXNpb24tZ29uby1nby1hZ2FpbnN0LXRoZS1uYW1lZC1jcml0ZXJpb25cIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy00XCIgLz57XCI0IOKAlCBUaGUgZGVjaXNpb24gKGdvL25vLWdvLCBhZ2FpbnN0IHRoZSBuYW1lZCBjcml0ZXJpb24pXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgY3JpdGVyaW9uIHNldCBieSB0aGUgcGxhbjogXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJpbXBsZW1lbnQgdGhlIGNlbGwga2luZCBvbmx5IGlmIGEgcmVhbCBkb2N1bWVudCBuZWVkc1xcbmNvbnZlcmdlbmNlIFwifTxfY29tcG9uZW50cy5lbT57XCJkaWFnbm9zdGljc1wifTwvX2NvbXBvbmVudHMuZW0+e1wiIOKAlCBpdGVyYXRpb24gY291bnRzIHN1cmZhY2VkIGluIHRoZSByZXZpZXcgc3VyZmFjZSwgYnVkZ2V0XFxuYWNjb3VudGluZyDigJQgbm90IG1lcmVseSBjb252ZXJnZW5jZS5cIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJEZWNpc2lvbjogaGVscGVyLW9ubHksIHJlY29yZGVkIChuby1nbyBvbiB0aGUgY2VsbCBraW5kKS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhlIG9ubHkgcmVhbCBjb25zdW1lclxcbihDYWxkZXJhKSBuZWVkcyBjb252ZXJnZW5jZSwgdmlzaWJsZSBmYWlsdXJlLCBhbmQgZXZpZGVuY2UtYXMtZGF0YSDigJQgYWxsIHNoaXBwZWQgaW5cXG7CpzIg4oCUIGFuZCBub25lIG9mIHRoZSDCpzMgZGVsdGFzIGhhdmUgYSBjb25zdW1lci4gVGhlIHRocm93LW9uLW5vbi1jb252ZXJnZW5jZVxcbmNvbnZlbnRpb24gaXMgaGVyZWJ5IHBpbm5lZCBhcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInRoZSBpZGlvbVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoc2VlIMKnNSkgc28gYXV0aG9ycyBkbyBub3QgcmUtZGVyaXZlIGl0LlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlJlb3BlbmluZyBjcml0ZXJpb25cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKGFueSBvbmUgcmVvcGVucyB0aGlzIGRlY2lzaW9uLCBhcyBhIGZyZXNoIGRlc2lnbiBpdGVtIGFnYWluc3RcXG50aGVuLWN1cnJlbnQgZXZpZGVuY2UpOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMub2w+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIkEgZG9jdW1lbnQgd2FudHMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJyZXZpZXctc3VyZmFjZSBjb252ZXJnZW5jZSB0ZWxlbWV0cnkgZm9yIG1hbnkgY29udmVyZ2VkIGNlbGxzIGF0XFxub25jZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoYSBcXFwiaG93IGhhcmQgZGlkIHRoaXMgd29ya2Jvb2sgY29udmVyZ2VcXFwiIHN1cmZhY2UpIOKAlCB0aGUgY2FzZSB3aGVyZVxcbnRocmVhZGluZyBjb3VudHMgdGhyb3VnaCB2YWx1ZXMgaXMgaW1wcmFjdGljYWwgYW5kIGEgdHJhY2UgY2hhbm5lbCBlYXJucyBpdHMga2VlcC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJBIGNvbnZlcmdlZCBjYWxjdWxhdGlvbiB3aG9zZSBzdGVwIGlzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1widG9vIGV4cGVuc2l2ZSBmb3Igb25lIGV2YWwgYnVkZ2V0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChlLmcuXFxucGVyLXN0ZXAgY29zdCBuZWFyIHRoZSB3YXRjaGRvZyBsaW1pdCksIG5lZWRpbmcgc2NoZWR1bGVyLXZpc2libGUgcHJvZ3Jlc3Mgb3JcXG5idWRnZXQgc3BsaXR0aW5nLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIkEgY29uc3VtZXIgbmVlZHMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ0aGUgZml4ZWQgcG9pbnQgYXMgYSBmaXJzdC1jbGFzcyBncmFwaCBub2RlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHdpdGggaXRzIG93biB0aWVyLFxcbmVwb2NoLCBhbmQgZGVwZW5kZW50cyDigJQgaS5lLiBjb252ZXJnZW5jZSBzcGFubmluZyBjZWxscyByYXRoZXIgdGhhbiBpbnNpZGUgb25lLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtNVwiIGRhdGEtc2x1Zz1cIjUtdGhlLXBpbm5lZC1pZGlvbS1ub3JtYXRpdmUtd2hpbGUtdGhpcy1zcGVjLXN0YW5kc1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTVcIiAvPntcIjUg4oCUIFRoZSBwaW5uZWQgaWRpb20gKG5vcm1hdGl2ZSB3aGlsZSB0aGlzIHNwZWMgc3RhbmRzKVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiQSBjb252ZXJnZW50IGNhbGN1bGF0aW9uIGlzIGV4cHJlc3NlZCBhczpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnByZT48X2NvbXBvbmVudHMuY29kZSBjbGFzc05hbWU9XCJsYW5ndWFnZS1qc1wiPntcImltcG9ydCB7IGZpeHBvaW50IH0gZnJvbSBcXFwiQHJlY2tvbmVyL3N0ZGxpYlxcXCI7XFxuXFxuY29uc3QgZnAgPSBmaXhwb2ludChpbml0aWFsU3RhdGUsIHN0ZXAsIHsgdG9sOiAxZS0xMiwgbWF4SXRlcmF0aW9uczogMjAwIH0pO1xcbmlmICghZnAuY29udmVyZ2VkKSB0aHJvdyBuZXcgRXJyb3IoXFxcIjx3aGF0PiBkaWQgbm90IGNvbnZlcmdlIDx3aGVyZT5cXFwiKTtcXG4vLyBmcC5pdGVyYXRpb25zIHRyYXZlbHMgaW4gdGhlIFZBTFVFIChpbnNwZWN0YWJsZSwgZGlmZmFibGUsIHRlc3RhYmxlKVxcblwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnByZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJSdWxlczpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlRocm93IG9uIG5vbi1jb252ZXJnZW5jZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgbmV2ZXIgcmV0dXJuIHRoZSBsYXN0IGl0ZXJhdGUgYXMgaWYgaXQgd2VyZSB0aGVcXG5hbnN3ZXI7IG5ldmVyIGxvZy1hbmQtY29udGludWUgKHRoZXJlIGlzIG5vIGNvbnNvbGUgaW4gdGhlIGNvbXBhcnRtZW50IGJ5IGRlc2lnbikuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJDYXJyeSB0aGUgZXZpZGVuY2UgaW4gdGhlIHZhbHVlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBpdGVyYXRpb24gY291bnRzIChhbmQgcmVzaWR1YWxzLCB3aGVuIHRoZVxcbmF1dGhvciBoYXMgdGhlbSkgYXJlIGRhdGEsIG5vdCBkaWFnbm9zdGljczsgdGVzdHMgY2FuIGFuZCBzaG91bGQgYXNzZXJ0IG9uIHRoZW0uXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgc3RlcCBpcyBwdXJlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGFuZCBtdXN0IG5vdCByZWFkIGFueXRoaW5nIGJ1dCBpdHMgYXJndW1lbnQgKHRoZSBjb21wYXJ0bWVudFxcbmVuZm9yY2VzIHRoaXMgc3RydWN0dXJhbGx5IGFueXdheSkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJCdWRnZXRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCI6IHRoZSBkZWZhdWx0IDIwMC1pdGVyYXRpb24gY2FwIHN0YW5kcyB1bmxlc3MgdGhlIG1vZGVsIGp1c3RpZmllcyBtb3JlO1xcbnRoZSBwZXItZXZhbCB3YXRjaGRvZyBpcyB0aGUgb3V0ZXIgYm91bmQgZWl0aGVyIHdheS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTZcIiBkYXRhLXNsdWc9XCI2LWFkdmVyc2FyaWFsLXNlbGYtcmV2aWV3LW9mLXRoZS1kZWNpc2lvbi10aGUtZWFjaC1wYXNzLWF0dGFja3MtaXRzLXByaW9yLXJ1bGVcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy02XCIgLz57XCI2IOKAlCBBZHZlcnNhcmlhbCBzZWxmLXJldmlldyBvZiB0aGUgZGVjaXNpb24gKHRoZSBlYWNoLXBhc3MtYXR0YWNrcy1pdHMtcHJpb3IgcnVsZSlcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQXR0YWNrIDEg4oCUIFxcXCJoZWxwZXItb25seSBpcyBjb21wbGFjZW50OyBFeGNlbCB1c2VycyBnZXQgaXRlcmF0aW9uIGNvdW50cyBcIn08X2NvbXBvbmVudHMuZW0+e1wid2l0aG91dFwifTwvX2NvbXBvbmVudHMuZW0+e1wiXFxuYXV0aG9yaW5nIGRpc2NpcGxpbmUsIHNvIHRoZSBoZWxwZXIgd2lsbCBiZSBtaXN1c2VkIGFuZCBub24tY29udmVyZ2VuY2UgaGlkZGVuLlxcXCJcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCJcXG5UaGUgYXR0YWNrIGFzc3VtZXMgYXV0aG9ycyBjYW4gc2lsZW50bHkgaWdub3JlIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNvbnZlcmdlZDogZmFsc2VcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFuZCByZXR1cm4gdGhlIGxhc3RcXG5pdGVyYXRlLiBUaGV5IGNhbiDigJQgdGhlIGhlbHBlciBwZXJtaXRzIGl0IOKAlCB3aGljaCBpcyB3aHkgwqc1IHBpbnMgdGhlIHRocm93IGlkaW9tIGFzXFxubm9ybWF0aXZlIGFuZCB3aHkgdGhlIGNhdGFsb2cgc2VsZi1kZXNjcmlwdGlvbiBzYXlzIGl0LiBBIGNlbGwga2luZCBjb3VsZCBlbmZvcmNlIHRoZVxcbnRocm93IHN0cnVjdHVyYWxseTsgdGhhdCBpcyBhIHJlYWwgKGlmIHNtYWxsKSBkZWx0YSwgYW5kIGl0IGlzIHRoZSBzdHJvbmdlc3QgYXJndW1lbnRcXG5cIn08X2NvbXBvbmVudHMuZW0+e1wiZm9yXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgdGhlIGNlbGwga2luZC4gUmVqZWN0ZWQgYmVjYXVzZTogdGhlIHNhbWUgXFxcImF1dGhvciBjYW4gd3JpdGUgaXQgd3JvbmdcXFwiIG9iamVjdGlvblxcbmFwcGxpZXMgdG8gZXZlcnkgc3RkbGliIGNhbGxhYmxlIChhbiBhdXRob3IgY2FuIGFsc28gcmV0dXJuIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjAvMFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYXMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibnVsbFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgd2hlcmUgYVxcbnRocm93IHdhcyBvd2VkKTsgdGhlIG1pdGlnYXRpb24gaXMgcmV2aWV3LXN1cmZhY2UgdGVzdHMgb24gY29udmVyZ2VuY2UgKGV4YWN0bHkgd2hhdFxcbkNhbGRlcmEncyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzY2hlZF9hdmdfY29udmVyZ2VzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBkZW1vbnN0cmF0ZXMpIHBsdXMgdGhlIHBpbm5lZCBpZGlvbSwgbm90IGEgbmV3IGVuZ2luZVxcbnN1cmZhY2UuIFJlY29yZGVkIGFzIHRoZSBsaWtlbGllc3QgcmVvcGVuaW5nIHByZXNzdXJlLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkF0dGFjayAyIOKAlCBcXFwiaXRlcmF0aW9uIGNvdW50cyBpbiB2YWx1ZXMgcG9sbHV0ZSB0aGUgZGF0YSBtb2RlbDsgZG93bnN0cmVhbSBjZWxscyBtdXN0XFxuc3RyaXAgdGhlbS5cXFwiXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRydWUgaW4gcHJpbmNpcGxlIChhIGNvbnN1bWVyIG9mIFwifTxfY29tcG9uZW50cy5jb2RlPntcImRlYnRfc2NoZWR1bGVfYXZnXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBzZWVzIGFuIGV4dHJhXFxuY29sdW1uKTsgaW4gcHJhY3RpY2UgdGhlIGNvdW50cyBhcmUgYWRkaXRpdmUgY29sdW1ucyB0aGF0IFwifTxfY29tcG9uZW50cy5jb2RlPntcIlRhYmxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9jaGFydHMgaWdub3JlIHVubGVzc1xcbmJvdW5kLCBhbmQgdGhlIGFsdGVybmF0aXZlIChhIHNpZGUgY2hhbm5lbCkgbWFrZXMgdGhlbSBpbnZpc2libGUgdG8gdGhlIG9uZSBjb25zdW1lclxcbnRoYXQgbWF0dGVycyDigJQgdGVzdHMuIFN0YW5kaW5nLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkF0dGFjayAzIOKAlCBcXFwidGhlIGRlY2lzaW9uIHJlYWRzIG9uZSBjYXNlIHN0dWR5OyBmaW5hbmNlIGhhcyBvdGhlciBjb252ZXJnZW50IHNoYXBlc1xcbihjaXJjdWxhciB3b3JraW5nIGNhcGl0YWwsIGdvYWwtc2Vlay1jb3VwbGVkIG1vZGVscykgdGhhdCBtYXkgd2FudCB0aGUgY2VsbCBraW5kLlxcXCJcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCJcXG5Db25jZWRlZCBhcyB0aGUgaG9uZXN0IGxpbWl0OiBuPTEgY29uc3VtZXIuIFRoaXMgaXMgZXhhY3RseSB3aHkgwqc0J3MgcmVvcGVuaW5nXFxuY3JpdGVyaWEgYXJlIGJlaGF2aW9yYWwgKHRlbGVtZXRyeSBhdCBzY2FsZSwgc3RlcCBjb3N0LCBjcm9zcy1jZWxsIGZpeGVkIHBvaW50cylcXG5yYXRoZXIgdGhhbiBmZWF0dXJlLXNoYXBlZCDigJQgYSBzZWNvbmQgY2FzZSBzdHVkeSB3aXRoIGEgZGlmZmVyZW50IHNoYXBlIHJlb3BlbnMgdGhlXFxucXVlc3Rpb24gb24gZXZpZGVuY2UsIG5vdCB0YXN0ZS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTdcIiBkYXRhLXNsdWc9XCI3LXZlcnNpb25pbmctbm90ZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTdcIiAvPntcIjcg4oCUIFZlcnNpb25pbmcgbm90ZVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiTm8gbmV3IGNvbnN0cnVjdG9yIHNoaXBzIHdpdGggdGhpcyBkZWNpc2lvbiwgc28gbm8gc3RkbGliIGNvbXBhdCBjb25zZXF1ZW5jZSBiZXlvbmRcXG53aGF0IFIzLTM3OCBhbHJlYWR5IHJlY29yZGVkIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJmaXhwb2ludFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaXMgYWRkaXRpdmUpLiBBIGZ1dHVyZSBjZWxsIGtpbmQgd291bGQgYmUgYVxcbm5ldyBjYWxsYWJsZSAoYWRkaXRpdmUpIHdob3NlIFwifTxfY29tcG9uZW50cy5lbT57XCJ1c2VcIn08L19jb21wb25lbnRzLmVtPntcIiBpbiBhIGRvY3VtZW50IGRlcml2ZXMgYSBoaWdoZXIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY29tcGF0LnN0ZGxpYlwifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG5mbG9vciBwZXIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRE9DVU1FTlRfVkVSU0lPTklOR19TUEVDXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDCpzMg4oCUIG5vdGhpbmcgaGVyZSBwcmUtZGVjaWRlcyB0aGF0IEFQSS5cIn08L19jb21wb25lbnRzLnA+PC8+O1xufVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTURYQ29udGVudChwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHt3cmFwcGVyOiBNRFhMYXlvdXR9ID0ge1xuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfTtcbiAgcmV0dXJuIE1EWExheW91dCA/IDxNRFhMYXlvdXQgey4uLnByb3BzfT48X2NyZWF0ZU1keENvbnRlbnQgey4uLnByb3BzfSAvPjwvTURYTGF5b3V0PiA6IF9jcmVhdGVNZHhDb250ZW50KHByb3BzKTtcbn1cbmZ1bmN0aW9uIF9taXNzaW5nTWR4UmVmZXJlbmNlKGlkLCBjb21wb25lbnQsIHBsYWNlKSB7XG4gIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIFwiICsgKGNvbXBvbmVudCA/IFwiY29tcG9uZW50XCIgOiBcIm9iamVjdFwiKSArIFwiIGBcIiArIGlkICsgXCJgIHRvIGJlIGRlZmluZWQ6IHlvdSBsaWtlbHkgZm9yZ290IHRvIGltcG9ydCwgcGFzcywgb3IgcHJvdmlkZSBpdC5cIiArIChwbGFjZSA/IFwiXFxuSXTigJlzIHJlZmVyZW5jZWQgaW4geW91ciBjb2RlIGF0IGBcIiArIHBsYWNlICsgXCJgIGluIGAvYXBwL2RvY3Mvc3BlY3MvQ09OVkVSR0VOQ0VfU1BFQy5tZGBcIiA6IFwiXCIpKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQXdGLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUZ4RjtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU1DLFdBQVcsR0FBRztNQUNsQkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsVUFBVSxFQUFFLFlBQVk7TUFDeEJDLElBQUksRUFBRSxNQUFNO01BQ1pDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLENBQUMsRUFBRSxHQUFHO01BQ05DLEdBQUcsRUFBRSxLQUFLO01BQ1ZDLE1BQU0sRUFBRSxRQUFRO01BQ2hCQyxLQUFLLEVBQUUsT0FBTztNQUNkQyxLQUFLLEVBQUUsT0FBTztNQUNkQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxLQUFLLEVBQUUsT0FBTztNQUNkQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSLEdBQUcsSUFBQUMsNkJBQWtCLEVBQUMsQ0FBQztNQUN2QixHQUFHckIsS0FBSyxDQUFDc0I7SUFDWCxDQUFDO0lBQUU7TUFBQ0M7SUFBYSxDQUFDLEdBQUd0QixXQUFXO0VBQ2hDLElBQUksQ0FBQ3NCLGFBQWEsRUFBRUMsb0JBQW9CLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQztFQUMvRCxvQkFBTyxJQUFBMUIsV0FBQSxDQUFBMkIsSUFBQSxFQUFBM0IsV0FBQSxDQUFBNEIsUUFBQTtJQUFBQyxRQUFBLGdCQUFFLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNLLEVBQUU7TUFBQ3NCLEVBQUUsRUFBQyxrR0FBa0c7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFrRyxDQUFFLENBQUMsRUFBQyxzR0FBc0c7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNVLENBQUM7TUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBUyxDQUFxQixDQUFDLEVBQUMsZ0RBQWdELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBNEIsQ0FBcUIsQ0FBQyxFQUFDLHFEQUFxRCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVUsQ0FBcUIsQ0FBQyxFQUFDLGFBQWE7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNFLFVBQVU7TUFBQXdCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztRQUFBZ0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFjLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0MsQ0FBQztVQUFDNEIsSUFBSSxFQUFDLGlDQUFpQztVQUFBSCxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBdUIsUUFBQSxFQUFFO1VBQWlDLENBQW1CO1FBQUMsQ0FBZSxDQUFDLEVBQUMscUZBQXFGLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0MsQ0FBQztVQUFDNEIsSUFBSSxFQUFDLDRCQUE0QjtVQUFBSCxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBdUIsUUFBQSxFQUFFO1VBQTRCLENBQW1CO1FBQUMsQ0FBZSxDQUFDLEVBQUMsNEZBQTRGLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0MsQ0FBQztVQUFDNEIsSUFBSSxFQUFDLG1DQUFtQztVQUFBSCxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBdUIsUUFBQSxFQUFFO1VBQW1DLENBQW1CO1FBQUMsQ0FBZSxDQUFDLEVBQUMsbURBQW1ELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQXdCLENBQW1CLENBQUMsRUFBQyxtQ0FBbUMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBNEQsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBbUIsQ0FBbUIsQ0FBQyxFQUFDLElBQUk7TUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQXlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ08sRUFBRSxJQUFFLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQVYsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDTSxFQUFFO01BQUNxQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUsNkJBQTZCO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQyxnQ0FBZ0M7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNVLENBQUM7TUFBQWdCLFFBQUEsR0FBRSx5UEFBeVAsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDSSxFQUFFO1FBQUFzQixRQUFBLEVBQUU7TUFBVyxDQUFpQixDQUFDLEVBQUMsMFZBQTBWO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDTSxFQUFFO01BQUNxQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUseURBQXlEO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQyw2REFBNkQ7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNVLENBQUM7TUFBQWdCLFFBQUEsR0FBRSxpQkFBaUIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBa0YsQ0FBbUIsQ0FBQyxFQUFDLGdDQUFnQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFtQixDQUFtQixDQUFDLEVBQUMsV0FBVztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ21CLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWEsQ0FBcUIsQ0FBQyxFQUFDLHdDQUF3QztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFpQixDQUFxQixDQUFDLEVBQUMsY0FBYyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNJLEVBQUU7VUFBQXNCLFFBQUEsRUFBRTtRQUFRLENBQWlCLENBQUMsRUFBQyxNQUFNLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQWtCLENBQW1CLENBQUMsRUFBQyx5S0FBeUs7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBa0IsQ0FBcUIsQ0FBQyxFQUFDLGlDQUFpQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXFCLENBQXFCLENBQUMsRUFBQyw2QkFBNkIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBWSxDQUFtQixDQUFDLEVBQUMsdUZBQXVGLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBVSxDQUFxQixDQUFDLEVBQUMsc0JBQXNCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQXFCLENBQW1CLENBQUMsRUFBQywrQkFBK0I7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBUSxDQUFxQixDQUFDLEVBQUMsNFZBQTRWO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNNLEVBQUU7TUFBQ3FCLEVBQUUsRUFBQyxPQUFPO01BQUMsYUFBVSxpREFBaUQ7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLHVCQUF1QixlQUFDLElBQUE5QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNJLEVBQUU7UUFBQXNCLFFBQUEsRUFBRTtNQUFXLENBQWlCLENBQUMsRUFBQyxzQkFBc0I7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNVLENBQUM7TUFBQWdCLFFBQUEsR0FBRSxnQkFBZ0IsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBc0IsQ0FBbUIsQ0FBQyxFQUFDLG9DQUFvQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2EsS0FBSztNQUFBYSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNpQixLQUFLO1FBQUFTLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNnQixFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFZLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNnQixFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFtQixDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBVyxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBUyxDQUFpQixDQUFDO1FBQUEsQ0FBZ0I7TUFBQyxDQUFtQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDYyxLQUFLO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUErQixDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUErQixDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFNLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQVUsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBMkIsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBMkMsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEdBQUUsOENBQThDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQWUsQ0FBbUIsQ0FBQyxFQUFDLFVBQVU7VUFBQSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsR0FBRSxpQkFBaUIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDSSxFQUFFO2NBQUFzQixRQUFBLEVBQUU7WUFBVSxDQUFpQixDQUFDLEVBQUMsdUlBQXVJO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBb0MsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBZ0YsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBd0IsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBa0UsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBK0MsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBMEQsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBa0QsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBOEYsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEdBQUUsK0JBQStCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0ksRUFBRTtjQUFBc0IsUUFBQSxFQUFFO1lBQWlCLENBQWlCLENBQUM7VUFBQSxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUE2RCxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFnRSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsR0FBRSxtRUFBbUUsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDSSxFQUFFO2NBQUFzQixRQUFBLEVBQUU7WUFBUyxDQUFpQixDQUFDLEVBQUMsMEVBQTBFO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBWSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFLLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxHQUFFLGdEQUFnRCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFlLENBQW1CLENBQUMsRUFBQyxvQ0FBb0M7VUFBQSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFxQyxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQztNQUFBLENBQW1CLENBQUM7SUFBQSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNNLEVBQUU7TUFBQ3FCLEVBQUUsRUFBQyxPQUFPO01BQUMsYUFBVSxvREFBb0Q7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLDBEQUEwRDtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLGlDQUFpQyxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxHQUFFLHFFQUFxRSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNJLEVBQUU7VUFBQXNCLFFBQUEsRUFBRTtRQUFhLENBQWlCLENBQUMsRUFBQyxrR0FBa0c7TUFBQSxDQUFxQixDQUFDO0lBQUEsQ0FBZSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNVLENBQUM7TUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBMkQsQ0FBcUIsQ0FBQyxFQUFDLDZOQUE2TixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVcsQ0FBcUIsQ0FBQyxFQUFDLDJDQUEyQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFxQixDQUFxQixDQUFDLEVBQUMsMEZBQTBGO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUyxFQUFFO01BQUFpQixRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsR0FBRSxtQkFBbUIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUF3RSxDQUFxQixDQUFDLEVBQUMsMkpBQTJKO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLEdBQUUsd0NBQXdDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBbUMsQ0FBcUIsQ0FBQyxFQUFDLDBHQUEwRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxHQUFFLG1CQUFtQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTZDLENBQXFCLENBQUMsRUFBQyxzR0FBc0c7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDcUIsRUFBRSxFQUFDLE9BQU87TUFBQyxhQUFVLHFEQUFxRDtNQUFBRCxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMseURBQXlEO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLEVBQUU7SUFBMkMsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDVyxHQUFHO01BQUFlLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxJQUFJO1FBQUMyQixTQUFTLEVBQUMsYUFBYTtRQUFBSixRQUFBLEVBQUU7TUFBcVIsQ0FBbUI7SUFBQyxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNVLENBQUM7TUFBQWdCLFFBQUEsRUFBRTtJQUFRLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ21CLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTBCLENBQXFCLENBQUMsRUFBQyx3SUFBd0k7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBaUMsQ0FBcUIsQ0FBQyxFQUFDLGdJQUFnSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFrQixDQUFxQixDQUFDLEVBQUMsb0dBQW9HO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQVEsQ0FBcUIsQ0FBQyxFQUFDLCtIQUErSDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDTSxFQUFFO01BQUNxQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUsZ0ZBQWdGO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQyxvRkFBb0Y7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNVLENBQUM7TUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEdBQUUsMkVBQTJFLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0ksRUFBRTtVQUFBc0IsUUFBQSxFQUFFO1FBQVMsQ0FBaUIsQ0FBQyxFQUFDLHFGQUFxRjtNQUFBLENBQXFCLENBQUMsRUFBQyxtREFBbUQsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBa0IsQ0FBbUIsQ0FBQyxFQUFDLDJSQUEyUixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNJLEVBQUU7UUFBQXNCLFFBQUEsRUFBRTtNQUFLLENBQWlCLENBQUMsRUFBQyxrSkFBa0osZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBSyxDQUFtQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFNLENBQW1CLENBQUMsRUFBQyw0R0FBNEcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBcUIsQ0FBbUIsQ0FBQyxFQUFDLGdIQUFnSDtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFzRyxDQUFxQixDQUFDLEVBQUMsb0NBQW9DLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQW1CLENBQW1CLENBQUMsRUFBQyw0RUFBNEUsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBTyxDQUFtQixDQUFDLEVBQUMsOElBQThJO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQTBLLENBQXFCLENBQUMsRUFBQywyUkFBMlI7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNNLEVBQUU7TUFBQ3FCLEVBQUUsRUFBQyxPQUFPO01BQUMsYUFBVSxtQkFBbUI7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLHFCQUFxQjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLHFIQUFxSCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFVLENBQW1CLENBQUMsRUFBQyw4RUFBOEUsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDSSxFQUFFO1FBQUFzQixRQUFBLEVBQUU7TUFBSyxDQUFpQixDQUFDLEVBQUMsa0NBQWtDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQWUsQ0FBbUIsQ0FBQyxFQUFDLGNBQWMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBMEIsQ0FBbUIsQ0FBQyxFQUFDLDBDQUEwQztJQUFBLENBQWdCLENBQUM7RUFBQSxDQUFFLENBQUM7QUFDam9kO0FBQ2UsU0FBU0ssVUFBVUEsQ0FBQ2hDLEtBQUssR0FBRyxDQUFDLENBQUMsRUFBRTtFQUM3QyxNQUFNO0lBQUNpQyxPQUFPLEVBQUVDO0VBQVMsQ0FBQyxHQUFHO0lBQzNCLEdBQUcsSUFBQWIsNkJBQWtCLEVBQUMsQ0FBQztJQUN2QixHQUFHckIsS0FBSyxDQUFDc0I7RUFDWCxDQUFDO0VBQ0QsT0FBT1ksU0FBUyxnQkFBRyxJQUFBcEMsV0FBQSxDQUFBK0IsR0FBQSxFQUFDSyxTQUFTO0lBQUEsR0FBS2xDLEtBQUs7SUFBQTJCLFFBQUEsZUFBRSxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDOUIsaUJBQWlCO01BQUEsR0FBS0M7SUFBSyxDQUFHO0VBQUMsQ0FBVyxDQUFDLEdBQUdELGlCQUFpQixDQUFDQyxLQUFLLENBQUM7QUFDbEg7QUFBQ21DLEVBQUEsR0FOdUJILFVBQVU7QUFPbEMsU0FBU1Isb0JBQW9CQSxDQUFDSSxFQUFFLEVBQUVRLFNBQVMsRUFBRUMsS0FBSyxFQUFFO0VBQ2xELE1BQU0sSUFBSUMsS0FBSyxDQUFDLFdBQVcsSUFBSUYsU0FBUyxHQUFHLFdBQVcsR0FBRyxRQUFRLENBQUMsR0FBRyxJQUFJLEdBQUdSLEVBQUUsR0FBRyxvRUFBb0UsSUFBSVMsS0FBSyxHQUFHLHFDQUFxQyxHQUFHQSxLQUFLLEdBQUcsNENBQTRDLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDdFE7QUFBQyxJQUFBRixFQUFBO0FBQUFJLFlBQUEsQ0FBQUosRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}