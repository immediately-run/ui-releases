var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      blockquote: "blockquote",
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      h3: "h3",
      hr: "hr",
      li: "li",
      p: "p",
      strong: "strong",
      table: "table",
      tbody: "tbody",
      td: "td",
      th: "th",
      thead: "thead",
      tr: "tr",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "immediatelyrun-engine-information-flow-the-epoch-tier-egress-channel-contract",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "immediatelyrun-engine-information-flow-the-epoch-tier-egress-channel-contract"
      }), "immediately.run Engine Information-Flow — the epoch × tier × egress-channel contract"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Status:"
      }), " proposal / draft — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Spine 1"
      }), " of the up-front-design triage\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "../ARCHITECTURE_PLAN.md"
      }), " §0.1). The unifying contract the per-channel specs\nlacked: ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["both adversarial-review-2 BLOCKERs (the D9 test-oracle channel and the recalc\nmixed-epoch glitch) were failures of ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "composition"
        }), " across channels reasoned about in\nisolation"]
      }), " — this spec makes the composition explicit. Reckoner-internal; design only,\nnothing built. · ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Updated:"
      }), " 2026-07-09"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["The single implementation-status source for this spec is\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "docs/status/ENGINE_INFORMATION_FLOW_STATUS.md"
          })]
        }), " (to be created at build) — where they\ndisagree, the status doc governs."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Reads first:"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "../ARCHITECTURE_PLAN.md"
        }), " §4 (the engine), §4.2 (scheduler,\ntier fold, common-epoch barrier), §4.3 (diagnostics, trace-replay), §5.2 (frame\npublication), §5.4 (freeze); ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "HOLDOUT_REDACTED_MOUNT_SPEC.md"
        }), " §5.1 (the test-oracle channel\nthis must govern) + §5.3; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "../ADVERSARIAL_REVIEW_2.md"
        }), " §B (D9-1) and §C (C-R-B);\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "TRUST_MODES_SPEC.md"
        }), " §3 (M0–M3 tiers), §4 (personal/shared). Sibling: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "CONNECTOR_EGRESS_FIXING_SPEC.md"
        }), "\n(the connector's egress is the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "other"
        }), " controlled boundary; this spec is the engine's)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-1",
      "data-slug": "1-the-one-principle-normative",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-1"
      }), "1. The one principle  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The formula engine is the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "executor"
      }), " realm: it computes over possibly-M3 data and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "holds\nno capabilities"
      }), ". Its safety rests entirely on what may cross its boundary. So:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Every value that leaves the engine is a controlled channel, and each channel declares —\nand the host enforces — four properties: its ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "epoch"
          }), ", its ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "tier"
          }), ", its ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "audience"
          }), ", and its\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "bandwidth"
          }), "."]
        }), " There is no \"incidental\" egress: a rendered result, a diagnostic record, an\nevaluation trace, a frozen fixture, and a test pass/fail are ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "all"
        }), " channels, and each is\ngoverned by the same four-property contract."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The review-2 failures were the direct consequence of ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "not"
      }), " stating this: the D9 spec governed\nthe ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "file"
      }), " channel (holdout unreadable) while the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "trace"
      }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "verdict"
      }), " channels — which\ncarry the same holdout rows to the same agent — went ungoverned (D9-1); and the recalc design\ngoverned the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "cell→cell"
      }), " epoch (atomic pair) while the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "result"
      }), " channel to a subscriber\nassembled inputs from different epochs (C-R-B). One contract over ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "all"
      }), " channels prevents both."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-2",
      "data-slug": "2-epoch-the-freshnessconsistency-stamp-normative",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-2"
      }), "2. Epoch — the freshness/consistency stamp  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Definition."
        }), " Each feed/param snapshot the host admits carries a monotonic ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "epoch"
        }), " (a\nper-source generation counter; the global order is the vector of per-source epochs). A\nderived value is computed ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "from"
        }), " a specific set of input epochs."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Common-epoch barrier (the glitch-freedom rule, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "ARCHITECTURE_PLAN §4.2"
          }), ")."]
        }), " A cell\npublishes only at the greatest epoch ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "k"
        }), " for which ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "every transitive input has a landed\nresult"
        }), "; faster arms are held to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "k"
        }), ". No downstream value ever mixes epochs of a shared\nancestor."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Epoch is carried on every result record and every derived channel"
        }), " (§4). A late-landing\nasync result from a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "superseded"
        }), " epoch is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "dropped, not published"
        }), " — including on the\ndiagnostic and trace channels (a trace of a superseded evaluation is marked ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "superseded"
        }), ",\nnever replayed as current)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Cost, stated (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "ARCHITECTURE_PLAN §4.1/§5.3"
          }), "):"]
        }), " a cell's freshness equals its slowest\ntransitive path, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "critical-path-depth · max(c,e)"
        }), ". Glitch-freedom is chosen over per-cell\nfreshness (the two are mutually exclusive under a continuous feed); this spec is the reason\nthe choice is coherent across ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "all"
        }), " channels, not just cell→cell."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-3",
      "data-slug": "3-tier-the-trust-label-normative",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-3"
      }), "3. Tier — the trust label  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "tier = floor"
          }), " (greatest lower bound) over transitive input tiers"]
        }), ", computed as a second\nproduct of the same traversal that computes the value (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ARCHITECTURE_PLAN §4.2"
        }), ", RQ-B4)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "(value, tier)"
          }), " is one atomic record"]
        }), " on every channel; a subscriber never sees a value\nfrom one epoch/tier paired with a label from another (§4.2 F4). Early-cutoff equality is over\nthe pair ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "(value-hash, tier)"
        }), " — never value alone (no tier laundering)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Tier is host-authoritative"
        }), ", from the mount tier (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "TRUST_MODES §4"
        }), "); content may not\nself-declare an output tier, and a file's tier tag is advisory display metadata only\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ARCHITECTURE_PLAN §5.4"
        }), ", review-1 L1). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "No channel may emit a value at a tier below its\ninputs' floor"
        }), " — the invariant every channel in §4 inherits."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-4",
      "data-slug": "4-the-channel-inventory-the-contract-table-normative-the-heart-of-this-spec",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-4"
      }), "4. The channel inventory — the contract table  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative — the heart of this spec)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Every engine-boundary channel, with its four properties. \"Audience\" is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "who may read the\npayload"
      }), "; a channel's audience ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "never"
      }), " includes a principal from which its ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "tier"
      }), " or its\nholdout-scope should hide it (§5)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "#"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Channel"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Direction"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Epoch-stamped"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Tier-carried"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Audience"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Bandwidth bound"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "C1"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Result"
            }), " (rendered cell value)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "engine → host result channel → report view"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["yes; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "common-epoch barrier"
            }), " (§2)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["yes; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "(value,tier)"
            }), " atomic"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "viewer"
            }), " (+ author)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "full (the value is the product)"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "C2"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Diagnostics"
            }), " (errors, logs, timings)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["engine → host → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "authoring only"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["yes; marked ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "cancelled"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "superseded"
            }), " if from a dropped epoch"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "inherits the evaluation's tier"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "author only"
            }), ", never shared-view"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["typed, fixed-size, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "rate-capped + sampled"
            }), " (covert-channel bound, RQ-D2)"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "C3"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Trace-replay"
            }), " (declared inputs → intermediates → output)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "engine → host → author / assistant"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "yes; superseded traces never replayed"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "inherits the evaluation's tier"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["author / assistant — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "excluding the authoring agent when the trace's declared inputs are holdout-scoped"
            }), " (§5)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["same caps as C2; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "holdout-derived traces are suppressed to the assistant"
            })]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "C4"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Test verdict"
            }), " (pass/fail + assertion diff)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "engine → host → review surface → assistant"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "yes"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "inherits the subject's tier"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["review surface (human) + assistant — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "but reduced to a boolean, and to validated/pinned status not the numeric diff, when the subject's inputs are holdout-scoped"
            }), " (§5)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "bandwidth-bounded for holdout subjects"
            }), " (defeats the bisection oracle, review-2 D9-1)"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "C5"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Frozen fixture / published frame"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "engine or connector → mount"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "capture epoch recorded (provenance)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "refloor at write"
            }), " (D4), host-enforced; file tag advisory"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "document readers"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "full, but a durable write — gated + tier-consequenced (§5.4)"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "C6"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Param write-back"
            }), " (widget → input cell)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "report view → host → engine"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["mints a new epoch; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "conflated"
            }), " keep-latest (F8)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "n/a (input)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "engine"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "conflated to human/feed rate"
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Reading the table:"
      }), " C1/C6 are the live loop; C2/C3/C4 are the authoring/debug surfaces; C5\nis durability. The two review-2 BLOCKERs are the two shaded cells: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "C3/C4's audience-exclusion\nfor holdout-scoped payloads"
      }), " (the D9 fix, generalized from \"hide the file\" to \"govern the\nchannel\"), and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "C1's epoch stamp + common-epoch barrier"
      }), " (the recalc fix, generalized from\n\"cell→cell\" to \"the result channel to a subscriber\")."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Not a channel — view-layer events."
      }), " A viewport/container ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "resize"
      }), " or a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "device-pixel-ratio"
      }), "\nchange (which drive responsive template adaptation, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ARCHITECTURE_PLAN §3.3.1"
      }), ") are ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "pure\nreport-view events"
      }), ": they re-lay-out and re-render components from data already delivered on C1,\nand they ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "never re-enter the engine"
      }), " — no C1 re-emit, no C6 write, no recompute. Only a\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "params"
      }), " change (C6) recomputes. This keeps responsiveness entirely in the view realm, off the\nengine boundary and the tier fold."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-5",
      "data-slug": "5-the-assistant-is-an-audience-the-holdout-fix-generalized-normative",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-5"
      }), "5. The assistant is an audience — the holdout fix, generalized  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "HOLDOUT_REDACTED_MOUNT_SPEC"
      }), " closed the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "file"
      }), " channel and missed C3/C4. The general rule\nthis spec states once, for all channels:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "A channel whose payload derives from holdout-scoped inputs must not carry that payload to\nthe authoring assistant at a bandwidth that reconstructs the held-out values."
        }), " The ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".holdout/"
        }), "\npath is one instance (C5-read, closed by D9's mount separation); the trace (C3) and the test\nverdict (C4) are the instances D9 missed, closed here:"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
        children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "C3 (trace):"
          }), " a trace whose declared inputs include a holdout-scoped fixture is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "not\ndelivered to the assistant"
          }), " (it may still serve host-side debugging with no agent in the\naudience). The agent authoring a test over holdout gets pass/fail status, never the\ninput-echoing trace."]
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "C4 (verdict):"
          }), " a test verdict whose subject reads holdout is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "reduced"
          }), " for the\nassistant to the review-surface status (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "validated"
          }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "pinned"
          }), ") — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "not"
          }), " the numeric\nassertion diff, and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "rate-bounded"
          }), " so a bisection (author a comparator, read pass/fail,\nnarrow) cannot recover the value across runs."]
        }), "\n"]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["Honest limit (carried from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "HOLDOUT §5"
        }), "):"]
      }), " this raises the oracle's cost; it does ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "not"
      }), "\nmake holdout a correctness proof (the agent still sees the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "training"
      }), " split and, for affine\nformulas, that determines the outcome). Holdout stays a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "tripwire"
      }), "; the load-bearing\ncorrectness signal is the oracle-free legs. This spec's job is only to stop C3/C4 from being a\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "trivial"
      }), " leak the way the file channel was — i.e. to make the mount-separation effort not\npointless."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-6",
      "data-slug": "6-glitch-freedom-is-a-publication-rule-for-all-channels-the-recalc-fix-generalized-normative",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-6"
      }), "6. Glitch-freedom is a publication rule for all channels — the recalc fix, generalized  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The atomic ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "(value, tier, epoch)"
      }), " record and the common-epoch barrier are ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "publication rules\nthat govern every channel in §4, not only cell→cell edges"
      }), ":"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["A ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "subscriber"
        }), " (C1) receives ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "D@k"
        }), " only when the barrier is satisfied — never ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "D"
        }), " computed\nfrom ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "B@e1 + C@e2"
        }), " (review-2 C-R-B)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["A ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "trace"
        }), " (C3) or ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "diagnostic"
        }), " (C2) of a superseded epoch is dropped, so replay never\nreconstructs a phantom or mixed-epoch evaluation."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["A ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "frozen frame"
        }), " (C5) records the epoch it captured, so a later \"what did we report last\nquarter\" (Spine 3 reproducibility) has a consistent cut."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["This is why Spine 1 is a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "contract"
      }), ", not a scheduler detail: the barrier is meaningless if one\nchannel honors it and another doesn't."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-7",
      "data-slug": "7-load-bearing-assumptions-code-anchors",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-7"
      }), "7. Load-bearing assumptions & code anchors"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "depends-on-today-verified-2026-07-09-re-checked-by-scriptscheck-spec-anchorsmjs",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "depends-on-today-verified-2026-07-09-re-checked-by-scriptscheck-spec-anchorsmjs"
      }), "Depends-on-today (verified 2026-07-09; re-checked by ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "scripts/check-spec-anchors.mjs"
      }), ")"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Assumption (existing behavior the design rests on)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Anchor (repo-relative file)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Token (grep-stable)"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Host mount tier is authoritative; the app does not self-declare it"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "immediately-run-site-main/src/filesystem/scopedFs.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "classifyPath"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "An app's fs egress is host-mediated (the surface an audience filter attaches to)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "immediately-run-sdk/src/fs.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "sandboxFs"
            })
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(This is mostly a new contract; the table above is deliberately short — most invariants are\nMust-establish, not Depends-on, and are flagged as proposed rather than asserted as existing.)"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "must-establish-new-invariants-the-implementation-creates",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "must-establish-new-invariants-the-implementation-creates"
      }), "Must-establish (new invariants the implementation creates)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "New invariant"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Proven by (gate test)"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Every engine-boundary channel carries ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "(value, tier, epoch)"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "channel-contract test: each of C1–C6 emits the triple; a payload without it is rejected at the boundary"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["The common-epoch barrier governs the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "result channel to a subscriber"
            }), ", not only cell→cell"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-EIF-1: a shared-ancestor asymmetric-arm diamond never delivers a mixed-epoch result to a subscriber (review-2 C-R-B)"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Superseded-epoch results are dropped on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "every"
            }), " channel (result, diagnostic, trace)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-EIF-2: a late async result / its trace from a superseded epoch is never published or replayed as current"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "No channel emits below the input tier floor"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-EIF-3: a value derived from an M3 input never appears on any channel tagged below M3"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Holdout-scoped payloads are audience-excluded on C3 and bandwidth-bounded on C4"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-EIF-4: an assistant authoring a test over holdout receives no input-echoing trace and cannot bisect the value from verdicts (closes review-2 D9-1)"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Diagnostics/traces are author-only, never shared-view"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-EIF-5: a shared-view session exposes no C2/C3 payload"
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-8",
      "data-slug": "8-decisions-rejected-alternatives",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-8"
      }), "8. Decisions & rejected alternatives"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "One contract over all engine-egress channels (epoch × tier × audience × bandwidth)."
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " per-channel specs (the review-2 failure mode — the file channel governed,\nthe trace/verdict channels not; the cell→cell epoch governed, the subscriber result not)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["The assistant is modeled as an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "audience"
          }), ", and holdout is a channel-level exclusion."]
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " modeling holdout only as a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "filesystem"
        }), " property (D9's original framing — the\nagent doesn't need the file, it needs the trace/verdict)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Glitch-freedom as a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "publication"
          }), " rule binding all channels, not a scheduler-internal\nproperty."]
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " treating the atomic pair as within-cell only (review-2 C-R-B relocated\nthe glitch to the publication boundary)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Traces/verdicts over holdout are suppressed/reduced, not fully blocked."
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), "\nblocking all test output over holdout (breaks the authoring loop — the author must see ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "that"
        }), "\na test failed); leaving them at full bandwidth (the bisection oracle). The reduction is the\nmiddle that keeps the loop while defeating the trivial oracle."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Tier stays host-authoritative on every channel."
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " trusting a content-declared\nor file-tag tier on any egress (laundering)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-9",
      "data-slug": "9-open-questions",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-9"
      }), "9. Open questions"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "OQ-1 (holdout-scope propagation)."
        }), " C3/C4's exclusion keys on \"payload ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "derives from"
        }), "\nholdout-scoped inputs.\" That derivation is exactly the tier fold's traversal — so\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "holdout-scope is a lattice label that rides the same fold as tier"
        }), " (a second bit). Confirm\nit composes (a value touching ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "any"
        }), " holdout input is holdout-scoped) and that it does not\nover-suppress ordinary authoring where no holdout is involved."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "OQ-2 (bandwidth quantification for C4)."
        }), " \"Rate-bounded so bisection cannot recover the\nvalue\" needs a number — how many holdout-subject verdicts per session, before the value's\nentropy is exceeded? Tie to the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "HOLDOUT"
        }), " re-scope: since holdout is only a tripwire, the\nbound can be coarse (a handful of verdicts), not cryptographic."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "OQ-3 (Spine-2 seam)."
        }), " The \"audience\" column names principals (viewer, author, assistant)\nwhose ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "identity"
        }), " is the Spine-2 capability topology. This spec assumes those principals are\ndistinguishable at the boundary; Spine 2 must make that true (the assistant realm is a\ndistinct audience from the report view — which needs AA-01/D7)."]
      }), "\n"]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/specs/ENGINE_INFORMATION_FLOW_SPEC.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJibG9ja3F1b3RlIiwiY29kZSIsImVtIiwiaDEiLCJoMiIsImgzIiwiaHIiLCJsaSIsInAiLCJzdHJvbmciLCJ0YWJsZSIsInRib2R5IiwidGQiLCJ0aCIsInRoZWFkIiwidHIiLCJ1bCIsIl9wcm92aWRlQ29tcG9uZW50cyIsImNvbXBvbmVudHMiLCJIZWFkaW5nQW5jaG9yIiwiX21pc3NpbmdNZHhSZWZlcmVuY2UiLCJqc3hzIiwiRnJhZ21lbnQiLCJjaGlsZHJlbiIsImlkIiwianN4IiwiTURYQ29udGVudCIsIndyYXBwZXIiLCJNRFhMYXlvdXQiLCJfYyIsImNvbXBvbmVudCIsInBsYWNlIiwiRXJyb3IiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJFTkdJTkVfSU5GT1JNQVRJT05fRkxPV19TUEVDLm1kIl0sInNvdXJjZXNDb250ZW50IjpbIi8qQGpzeFJ1bnRpbWUgYXV0b21hdGljKi9cbi8qQGpzeEltcG9ydFNvdXJjZSByZWFjdCovXG5pbXBvcnQge3VzZU1EWENvbXBvbmVudHMgYXMgX3Byb3ZpZGVDb21wb25lbnRzfSBmcm9tIFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGsvTURYUHJvdmlkZXJcIjtcbmZ1bmN0aW9uIF9jcmVhdGVNZHhDb250ZW50KHByb3BzKSB7XG4gIGNvbnN0IF9jb21wb25lbnRzID0ge1xuICAgIGJsb2NrcXVvdGU6IFwiYmxvY2txdW90ZVwiLFxuICAgIGNvZGU6IFwiY29kZVwiLFxuICAgIGVtOiBcImVtXCIsXG4gICAgaDE6IFwiaDFcIixcbiAgICBoMjogXCJoMlwiLFxuICAgIGgzOiBcImgzXCIsXG4gICAgaHI6IFwiaHJcIixcbiAgICBsaTogXCJsaVwiLFxuICAgIHA6IFwicFwiLFxuICAgIHN0cm9uZzogXCJzdHJvbmdcIixcbiAgICB0YWJsZTogXCJ0YWJsZVwiLFxuICAgIHRib2R5OiBcInRib2R5XCIsXG4gICAgdGQ6IFwidGRcIixcbiAgICB0aDogXCJ0aFwiLFxuICAgIHRoZWFkOiBcInRoZWFkXCIsXG4gICAgdHI6IFwidHJcIixcbiAgICB1bDogXCJ1bFwiLFxuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfSwge0hlYWRpbmdBbmNob3J9ID0gX2NvbXBvbmVudHM7XG4gIGlmICghSGVhZGluZ0FuY2hvcikgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJIZWFkaW5nQW5jaG9yXCIsIHRydWUpO1xuICByZXR1cm4gPD48X2NvbXBvbmVudHMuaDEgaWQ9XCJpbW1lZGlhdGVseXJ1bi1lbmdpbmUtaW5mb3JtYXRpb24tZmxvdy10aGUtZXBvY2gtdGllci1lZ3Jlc3MtY2hhbm5lbC1jb250cmFjdFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiaW1tZWRpYXRlbHlydW4tZW5naW5lLWluZm9ybWF0aW9uLWZsb3ctdGhlLWVwb2NoLXRpZXItZWdyZXNzLWNoYW5uZWwtY29udHJhY3RcIiAvPntcImltbWVkaWF0ZWx5LnJ1biBFbmdpbmUgSW5mb3JtYXRpb24tRmxvdyDigJQgdGhlIGVwb2NoIMOXIHRpZXIgw5cgZWdyZXNzLWNoYW5uZWwgY29udHJhY3RcIn08L19jb21wb25lbnRzLmgxPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiU3RhdHVzOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBwcm9wb3NhbCAvIGRyYWZ0IOKAlCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlNwaW5lIDFcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgb2YgdGhlIHVwLWZyb250LWRlc2lnbiB0cmlhZ2VcXG4oXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLi4vQVJDSElURUNUVVJFX1BMQU4ubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIMKnMC4xKS4gVGhlIHVuaWZ5aW5nIGNvbnRyYWN0IHRoZSBwZXItY2hhbm5lbCBzcGVjc1xcbmxhY2tlZDogXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJib3RoIGFkdmVyc2FyaWFsLXJldmlldy0yIEJMT0NLRVJzICh0aGUgRDkgdGVzdC1vcmFjbGUgY2hhbm5lbCBhbmQgdGhlIHJlY2FsY1xcbm1peGVkLWVwb2NoIGdsaXRjaCkgd2VyZSBmYWlsdXJlcyBvZiBcIn08X2NvbXBvbmVudHMuZW0+e1wiY29tcG9zaXRpb25cIn08L19jb21wb25lbnRzLmVtPntcIiBhY3Jvc3MgY2hhbm5lbHMgcmVhc29uZWQgYWJvdXQgaW5cXG5pc29sYXRpb25cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHRoaXMgc3BlYyBtYWtlcyB0aGUgY29tcG9zaXRpb24gZXhwbGljaXQuIFJlY2tvbmVyLWludGVybmFsOyBkZXNpZ24gb25seSxcXG5ub3RoaW5nIGJ1aWx0LiDCtyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlVwZGF0ZWQ6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIDIwMjYtMDctMDlcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgc2luZ2xlIGltcGxlbWVudGF0aW9uLXN0YXR1cyBzb3VyY2UgZm9yIHRoaXMgc3BlYyBpc1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcImRvY3Mvc3RhdHVzL0VOR0lORV9JTkZPUk1BVElPTl9GTE9XX1NUQVRVUy5tZFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHRvIGJlIGNyZWF0ZWQgYXQgYnVpbGQpIOKAlCB3aGVyZSB0aGV5XFxuZGlzYWdyZWUsIHRoZSBzdGF0dXMgZG9jIGdvdmVybnMuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTwvX2NvbXBvbmVudHMuYmxvY2txdW90ZT57XCJcXG5cIn08X2NvbXBvbmVudHMuYmxvY2txdW90ZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlJlYWRzIGZpcnN0OlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCIuLi9BUkNISVRFQ1RVUkVfUExBTi5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgwqc0ICh0aGUgZW5naW5lKSwgwqc0LjIgKHNjaGVkdWxlcixcXG50aWVyIGZvbGQsIGNvbW1vbi1lcG9jaCBiYXJyaWVyKSwgwqc0LjMgKGRpYWdub3N0aWNzLCB0cmFjZS1yZXBsYXkpLCDCpzUuMiAoZnJhbWVcXG5wdWJsaWNhdGlvbiksIMKnNS40IChmcmVlemUpOyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJIT0xET1VUX1JFREFDVEVEX01PVU5UX1NQRUMubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIMKnNS4xICh0aGUgdGVzdC1vcmFjbGUgY2hhbm5lbFxcbnRoaXMgbXVzdCBnb3Zlcm4pICsgwqc1LjM7IFwifTxfY29tcG9uZW50cy5jb2RlPntcIi4uL0FEVkVSU0FSSUFMX1JFVklFV18yLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDCp0IgKEQ5LTEpIGFuZCDCp0MgKEMtUi1CKTtcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJUUlVTVF9NT0RFU19TUEVDLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDCpzMgKE0w4oCTTTMgdGllcnMpLCDCpzQgKHBlcnNvbmFsL3NoYXJlZCkuIFNpYmxpbmc6IFwifTxfY29tcG9uZW50cy5jb2RlPntcIkNPTk5FQ1RPUl9FR1JFU1NfRklYSU5HX1NQRUMubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxuKHRoZSBjb25uZWN0b3IncyBlZ3Jlc3MgaXMgdGhlIFwifTxfY29tcG9uZW50cy5lbT57XCJvdGhlclwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGNvbnRyb2xsZWQgYm91bmRhcnk7IHRoaXMgc3BlYyBpcyB0aGUgZW5naW5lJ3MpLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08L19jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmhyIC8+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTFcIiBkYXRhLXNsdWc9XCIxLXRoZS1vbmUtcHJpbmNpcGxlLW5vcm1hdGl2ZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTFcIiAvPntcIjEuIFRoZSBvbmUgcHJpbmNpcGxlICBcIn08X2NvbXBvbmVudHMuZW0+e1wiKG5vcm1hdGl2ZSlcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIGZvcm11bGEgZW5naW5lIGlzIHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImV4ZWN1dG9yXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHJlYWxtOiBpdCBjb21wdXRlcyBvdmVyIHBvc3NpYmx5LU0zIGRhdGEgYW5kIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiaG9sZHNcXG5ubyBjYXBhYmlsaXRpZXNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIuIEl0cyBzYWZldHkgcmVzdHMgZW50aXJlbHkgb24gd2hhdCBtYXkgY3Jvc3MgaXRzIGJvdW5kYXJ5LiBTbzpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJFdmVyeSB2YWx1ZSB0aGF0IGxlYXZlcyB0aGUgZW5naW5lIGlzIGEgY29udHJvbGxlZCBjaGFubmVsLCBhbmQgZWFjaCBjaGFubmVsIGRlY2xhcmVzIOKAlFxcbmFuZCB0aGUgaG9zdCBlbmZvcmNlcyDigJQgZm91ciBwcm9wZXJ0aWVzOiBpdHMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZXBvY2hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBpdHMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widGllclwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGl0cyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJhdWRpZW5jZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGFuZCBpdHNcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJiYW5kd2lkdGhcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGVyZSBpcyBubyBcXFwiaW5jaWRlbnRhbFxcXCIgZWdyZXNzOiBhIHJlbmRlcmVkIHJlc3VsdCwgYSBkaWFnbm9zdGljIHJlY29yZCwgYW5cXG5ldmFsdWF0aW9uIHRyYWNlLCBhIGZyb3plbiBmaXh0dXJlLCBhbmQgYSB0ZXN0IHBhc3MvZmFpbCBhcmUgXCJ9PF9jb21wb25lbnRzLmVtPntcImFsbFwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGNoYW5uZWxzLCBhbmQgZWFjaCBpc1xcbmdvdmVybmVkIGJ5IHRoZSBzYW1lIGZvdXItcHJvcGVydHkgY29udHJhY3QuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTwvX2NvbXBvbmVudHMuYmxvY2txdW90ZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgcmV2aWV3LTIgZmFpbHVyZXMgd2VyZSB0aGUgZGlyZWN0IGNvbnNlcXVlbmNlIG9mIFwifTxfY29tcG9uZW50cy5lbT57XCJub3RcIn08L19jb21wb25lbnRzLmVtPntcIiBzdGF0aW5nIHRoaXM6IHRoZSBEOSBzcGVjIGdvdmVybmVkXFxudGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZmlsZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBjaGFubmVsIChob2xkb3V0IHVucmVhZGFibGUpIHdoaWxlIHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInRyYWNlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGFuZCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInZlcmRpY3RcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgY2hhbm5lbHMg4oCUIHdoaWNoXFxuY2FycnkgdGhlIHNhbWUgaG9sZG91dCByb3dzIHRvIHRoZSBzYW1lIGFnZW50IOKAlCB3ZW50IHVuZ292ZXJuZWQgKEQ5LTEpOyBhbmQgdGhlIHJlY2FsYyBkZXNpZ25cXG5nb3Zlcm5lZCB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJjZWxs4oaSY2VsbFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBlcG9jaCAoYXRvbWljIHBhaXIpIHdoaWxlIHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInJlc3VsdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBjaGFubmVsIHRvIGEgc3Vic2NyaWJlclxcbmFzc2VtYmxlZCBpbnB1dHMgZnJvbSBkaWZmZXJlbnQgZXBvY2hzIChDLVItQikuIE9uZSBjb250cmFjdCBvdmVyIFwifTxfY29tcG9uZW50cy5lbT57XCJhbGxcIn08L19jb21wb25lbnRzLmVtPntcIiBjaGFubmVscyBwcmV2ZW50cyBib3RoLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtMlwiIGRhdGEtc2x1Zz1cIjItZXBvY2gtdGhlLWZyZXNobmVzc2NvbnNpc3RlbmN5LXN0YW1wLW5vcm1hdGl2ZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTJcIiAvPntcIjIuIEVwb2NoIOKAlCB0aGUgZnJlc2huZXNzL2NvbnNpc3RlbmN5IHN0YW1wICBcIn08X2NvbXBvbmVudHMuZW0+e1wiKG5vcm1hdGl2ZSlcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkRlZmluaXRpb24uXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIEVhY2ggZmVlZC9wYXJhbSBzbmFwc2hvdCB0aGUgaG9zdCBhZG1pdHMgY2FycmllcyBhIG1vbm90b25pYyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImVwb2NoXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChhXFxucGVyLXNvdXJjZSBnZW5lcmF0aW9uIGNvdW50ZXI7IHRoZSBnbG9iYWwgb3JkZXIgaXMgdGhlIHZlY3RvciBvZiBwZXItc291cmNlIGVwb2NocykuIEFcXG5kZXJpdmVkIHZhbHVlIGlzIGNvbXB1dGVkIFwifTxfY29tcG9uZW50cy5lbT57XCJmcm9tXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgYSBzcGVjaWZpYyBzZXQgb2YgaW5wdXQgZXBvY2hzLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQ29tbW9uLWVwb2NoIGJhcnJpZXIgKHRoZSBnbGl0Y2gtZnJlZWRvbSBydWxlLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJBUkNISVRFQ1RVUkVfUExBTiDCpzQuMlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBBIGNlbGxcXG5wdWJsaXNoZXMgb25seSBhdCB0aGUgZ3JlYXRlc3QgZXBvY2ggXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wia1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZm9yIHdoaWNoIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZXZlcnkgdHJhbnNpdGl2ZSBpbnB1dCBoYXMgYSBsYW5kZWRcXG5yZXN1bHRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCI7IGZhc3RlciBhcm1zIGFyZSBoZWxkIHRvIFwifTxfY29tcG9uZW50cy5jb2RlPntcImtcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLiBObyBkb3duc3RyZWFtIHZhbHVlIGV2ZXIgbWl4ZXMgZXBvY2hzIG9mIGEgc2hhcmVkXFxuYW5jZXN0b3IuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJFcG9jaCBpcyBjYXJyaWVkIG9uIGV2ZXJ5IHJlc3VsdCByZWNvcmQgYW5kIGV2ZXJ5IGRlcml2ZWQgY2hhbm5lbFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAowqc0KS4gQSBsYXRlLWxhbmRpbmdcXG5hc3luYyByZXN1bHQgZnJvbSBhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wic3VwZXJzZWRlZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBlcG9jaCBpcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImRyb3BwZWQsIG5vdCBwdWJsaXNoZWRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIGluY2x1ZGluZyBvbiB0aGVcXG5kaWFnbm9zdGljIGFuZCB0cmFjZSBjaGFubmVscyAoYSB0cmFjZSBvZiBhIHN1cGVyc2VkZWQgZXZhbHVhdGlvbiBpcyBtYXJrZWQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3VwZXJzZWRlZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsXFxubmV2ZXIgcmVwbGF5ZWQgYXMgY3VycmVudCkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJDb3N0LCBzdGF0ZWQgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIkFSQ0hJVEVDVFVSRV9QTEFOIMKnNC4xL8KnNS4zXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIik6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGEgY2VsbCdzIGZyZXNobmVzcyBlcXVhbHMgaXRzIHNsb3dlc3RcXG50cmFuc2l0aXZlIHBhdGgsIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNyaXRpY2FsLXBhdGgtZGVwdGggwrcgbWF4KGMsZSlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLiBHbGl0Y2gtZnJlZWRvbSBpcyBjaG9zZW4gb3ZlciBwZXItY2VsbFxcbmZyZXNobmVzcyAodGhlIHR3byBhcmUgbXV0dWFsbHkgZXhjbHVzaXZlIHVuZGVyIGEgY29udGludW91cyBmZWVkKTsgdGhpcyBzcGVjIGlzIHRoZSByZWFzb25cXG50aGUgY2hvaWNlIGlzIGNvaGVyZW50IGFjcm9zcyBcIn08X2NvbXBvbmVudHMuZW0+e1wiYWxsXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgY2hhbm5lbHMsIG5vdCBqdXN0IGNlbGzihpJjZWxsLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtM1wiIGRhdGEtc2x1Zz1cIjMtdGllci10aGUtdHJ1c3QtbGFiZWwtbm9ybWF0aXZlXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtM1wiIC8+e1wiMy4gVGllciDigJQgdGhlIHRydXN0IGxhYmVsICBcIn08X2NvbXBvbmVudHMuZW0+e1wiKG5vcm1hdGl2ZSlcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPjxfY29tcG9uZW50cy5jb2RlPntcInRpZXIgPSBmbG9vclwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKGdyZWF0ZXN0IGxvd2VyIGJvdW5kKSBvdmVyIHRyYW5zaXRpdmUgaW5wdXQgdGllcnNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIsIGNvbXB1dGVkIGFzIGEgc2Vjb25kXFxucHJvZHVjdCBvZiB0aGUgc2FtZSB0cmF2ZXJzYWwgdGhhdCBjb21wdXRlcyB0aGUgdmFsdWUgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIkFSQ0hJVEVDVFVSRV9QTEFOIMKnNC4yXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgUlEtQjQpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+PF9jb21wb25lbnRzLmNvZGU+e1wiKHZhbHVlLCB0aWVyKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaXMgb25lIGF0b21pYyByZWNvcmRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgb24gZXZlcnkgY2hhbm5lbDsgYSBzdWJzY3JpYmVyIG5ldmVyIHNlZXMgYSB2YWx1ZVxcbmZyb20gb25lIGVwb2NoL3RpZXIgcGFpcmVkIHdpdGggYSBsYWJlbCBmcm9tIGFub3RoZXIgKMKnNC4yIEY0KS4gRWFybHktY3V0b2ZmIGVxdWFsaXR5IGlzIG92ZXJcXG50aGUgcGFpciBcIn08X2NvbXBvbmVudHMuY29kZT57XCIodmFsdWUtaGFzaCwgdGllcilcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCBuZXZlciB2YWx1ZSBhbG9uZSAobm8gdGllciBsYXVuZGVyaW5nKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlRpZXIgaXMgaG9zdC1hdXRob3JpdGF0aXZlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBmcm9tIHRoZSBtb3VudCB0aWVyIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJUUlVTVF9NT0RFUyDCpzRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKTsgY29udGVudCBtYXkgbm90XFxuc2VsZi1kZWNsYXJlIGFuIG91dHB1dCB0aWVyLCBhbmQgYSBmaWxlJ3MgdGllciB0YWcgaXMgYWR2aXNvcnkgZGlzcGxheSBtZXRhZGF0YSBvbmx5XFxuKFwifTxfY29tcG9uZW50cy5jb2RlPntcIkFSQ0hJVEVDVFVSRV9QTEFOIMKnNS40XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgcmV2aWV3LTEgTDEpLiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIk5vIGNoYW5uZWwgbWF5IGVtaXQgYSB2YWx1ZSBhdCBhIHRpZXIgYmVsb3cgaXRzXFxuaW5wdXRzJyBmbG9vclwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgdGhlIGludmFyaWFudCBldmVyeSBjaGFubmVsIGluIMKnNCBpbmhlcml0cy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTRcIiBkYXRhLXNsdWc9XCI0LXRoZS1jaGFubmVsLWludmVudG9yeS10aGUtY29udHJhY3QtdGFibGUtbm9ybWF0aXZlLXRoZS1oZWFydC1vZi10aGlzLXNwZWNcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy00XCIgLz57XCI0LiBUaGUgY2hhbm5lbCBpbnZlbnRvcnkg4oCUIHRoZSBjb250cmFjdCB0YWJsZSAgXCJ9PF9jb21wb25lbnRzLmVtPntcIihub3JtYXRpdmUg4oCUIHRoZSBoZWFydCBvZiB0aGlzIHNwZWMpXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkV2ZXJ5IGVuZ2luZS1ib3VuZGFyeSBjaGFubmVsLCB3aXRoIGl0cyBmb3VyIHByb3BlcnRpZXMuIFxcXCJBdWRpZW5jZVxcXCIgaXMgXCJ9PF9jb21wb25lbnRzLmVtPntcIndobyBtYXkgcmVhZCB0aGVcXG5wYXlsb2FkXCJ9PC9fY29tcG9uZW50cy5lbT57XCI7IGEgY2hhbm5lbCdzIGF1ZGllbmNlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibmV2ZXJcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgaW5jbHVkZXMgYSBwcmluY2lwYWwgZnJvbSB3aGljaCBpdHMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widGllclwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgb3IgaXRzXFxuaG9sZG91dC1zY29wZSBzaG91bGQgaGlkZSBpdCAowqc1KS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnRhYmxlPjxfY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRoPntcIiNcIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aD57XCJDaGFubmVsXCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGg+e1wiRGlyZWN0aW9uXCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGg+e1wiRXBvY2gtc3RhbXBlZFwifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIlRpZXItY2FycmllZFwifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIkF1ZGllbmNlXCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGg+e1wiQmFuZHdpZHRoIGJvdW5kXCJ9PC9fY29tcG9uZW50cy50aD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGhlYWQ+PF9jb21wb25lbnRzLnRib2R5PjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiQzFcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlJlc3VsdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAocmVuZGVyZWQgY2VsbCB2YWx1ZSlcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJlbmdpbmUg4oaSIGhvc3QgcmVzdWx0IGNoYW5uZWwg4oaSIHJlcG9ydCB2aWV3XCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wieWVzOyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImNvbW1vbi1lcG9jaCBiYXJyaWVyXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICjCpzIpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wieWVzOyBcIn08X2NvbXBvbmVudHMuY29kZT57XCIodmFsdWUsdGllcilcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGF0b21pY1wifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1widmlld2VyXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICgrIGF1dGhvcilcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJmdWxsICh0aGUgdmFsdWUgaXMgdGhlIHByb2R1Y3QpXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiQzJcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkRpYWdub3N0aWNzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChlcnJvcnMsIGxvZ3MsIHRpbWluZ3MpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiZW5naW5lIOKGkiBob3N0IOKGkiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImF1dGhvcmluZyBvbmx5XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wieWVzOyBtYXJrZWQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2FuY2VsbGVkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJzdXBlcnNlZGVkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpZiBmcm9tIGEgZHJvcHBlZCBlcG9jaFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcImluaGVyaXRzIHRoZSBldmFsdWF0aW9uJ3MgdGllclwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiYXV0aG9yIG9ubHlcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIsIG5ldmVyIHNoYXJlZC12aWV3XCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1widHlwZWQsIGZpeGVkLXNpemUsIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicmF0ZS1jYXBwZWQgKyBzYW1wbGVkXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChjb3ZlcnQtY2hhbm5lbCBib3VuZCwgUlEtRDIpXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiQzNcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlRyYWNlLXJlcGxheVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoZGVjbGFyZWQgaW5wdXRzIOKGkiBpbnRlcm1lZGlhdGVzIOKGkiBvdXRwdXQpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiZW5naW5lIOKGkiBob3N0IOKGkiBhdXRob3IgLyBhc3Npc3RhbnRcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJ5ZXM7IHN1cGVyc2VkZWQgdHJhY2VzIG5ldmVyIHJlcGxheWVkXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiaW5oZXJpdHMgdGhlIGV2YWx1YXRpb24ncyB0aWVyXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiYXV0aG9yIC8gYXNzaXN0YW50IOKAlCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImV4Y2x1ZGluZyB0aGUgYXV0aG9yaW5nIGFnZW50IHdoZW4gdGhlIHRyYWNlJ3MgZGVjbGFyZWQgaW5wdXRzIGFyZSBob2xkb3V0LXNjb3BlZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAowqc1KVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcInNhbWUgY2FwcyBhcyBDMjsgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJob2xkb3V0LWRlcml2ZWQgdHJhY2VzIGFyZSBzdXBwcmVzc2VkIHRvIHRoZSBhc3Npc3RhbnRcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJDNFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVGVzdCB2ZXJkaWN0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChwYXNzL2ZhaWwgKyBhc3NlcnRpb24gZGlmZilcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJlbmdpbmUg4oaSIGhvc3Qg4oaSIHJldmlldyBzdXJmYWNlIOKGkiBhc3Npc3RhbnRcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJ5ZXNcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJpbmhlcml0cyB0aGUgc3ViamVjdCdzIHRpZXJcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJyZXZpZXcgc3VyZmFjZSAoaHVtYW4pICsgYXNzaXN0YW50IOKAlCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImJ1dCByZWR1Y2VkIHRvIGEgYm9vbGVhbiwgYW5kIHRvIHZhbGlkYXRlZC9waW5uZWQgc3RhdHVzIG5vdCB0aGUgbnVtZXJpYyBkaWZmLCB3aGVuIHRoZSBzdWJqZWN0J3MgaW5wdXRzIGFyZSBob2xkb3V0LXNjb3BlZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAowqc1KVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiYmFuZHdpZHRoLWJvdW5kZWQgZm9yIGhvbGRvdXQgc3ViamVjdHNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKGRlZmVhdHMgdGhlIGJpc2VjdGlvbiBvcmFjbGUsIHJldmlldy0yIEQ5LTEpXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiQzVcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkZyb3plbiBmaXh0dXJlIC8gcHVibGlzaGVkIGZyYW1lXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiZW5naW5lIG9yIGNvbm5lY3RvciDihpIgbW91bnRcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJjYXB0dXJlIGVwb2NoIHJlY29yZGVkIChwcm92ZW5hbmNlKVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wicmVmbG9vciBhdCB3cml0ZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoRDQpLCBob3N0LWVuZm9yY2VkOyBmaWxlIHRhZyBhZHZpc29yeVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcImRvY3VtZW50IHJlYWRlcnNcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJmdWxsLCBidXQgYSBkdXJhYmxlIHdyaXRlIOKAlCBnYXRlZCArIHRpZXItY29uc2VxdWVuY2VkICjCpzUuNClcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJDNlwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUGFyYW0gd3JpdGUtYmFja1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAod2lkZ2V0IOKGkiBpbnB1dCBjZWxsKVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcInJlcG9ydCB2aWV3IOKGkiBob3N0IOKGkiBlbmdpbmVcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJtaW50cyBhIG5ldyBlcG9jaDsgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJjb25mbGF0ZWRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIga2VlcC1sYXRlc3QgKEY4KVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIm4vYSAoaW5wdXQpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiZW5naW5lXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiY29uZmxhdGVkIHRvIGh1bWFuL2ZlZWQgcmF0ZVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRib2R5PjwvX2NvbXBvbmVudHMudGFibGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJSZWFkaW5nIHRoZSB0YWJsZTpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgQzEvQzYgYXJlIHRoZSBsaXZlIGxvb3A7IEMyL0MzL0M0IGFyZSB0aGUgYXV0aG9yaW5nL2RlYnVnIHN1cmZhY2VzOyBDNVxcbmlzIGR1cmFiaWxpdHkuIFRoZSB0d28gcmV2aWV3LTIgQkxPQ0tFUnMgYXJlIHRoZSB0d28gc2hhZGVkIGNlbGxzOiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIkMzL0M0J3MgYXVkaWVuY2UtZXhjbHVzaW9uXFxuZm9yIGhvbGRvdXQtc2NvcGVkIHBheWxvYWRzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICh0aGUgRDkgZml4LCBnZW5lcmFsaXplZCBmcm9tIFxcXCJoaWRlIHRoZSBmaWxlXFxcIiB0byBcXFwiZ292ZXJuIHRoZVxcbmNoYW5uZWxcXFwiKSwgYW5kIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiQzEncyBlcG9jaCBzdGFtcCArIGNvbW1vbi1lcG9jaCBiYXJyaWVyXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICh0aGUgcmVjYWxjIGZpeCwgZ2VuZXJhbGl6ZWQgZnJvbVxcblxcXCJjZWxs4oaSY2VsbFxcXCIgdG8gXFxcInRoZSByZXN1bHQgY2hhbm5lbCB0byBhIHN1YnNjcmliZXJcXFwiKS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJOb3QgYSBjaGFubmVsIOKAlCB2aWV3LWxheWVyIGV2ZW50cy5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgQSB2aWV3cG9ydC9jb250YWluZXIgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJyZXNpemVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgb3IgYSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImRldmljZS1waXhlbC1yYXRpb1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIlxcbmNoYW5nZSAod2hpY2ggZHJpdmUgcmVzcG9uc2l2ZSB0ZW1wbGF0ZSBhZGFwdGF0aW9uLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJBUkNISVRFQ1RVUkVfUExBTiDCpzMuMy4xXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikgYXJlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicHVyZVxcbnJlcG9ydC12aWV3IGV2ZW50c1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIjogdGhleSByZS1sYXktb3V0IGFuZCByZS1yZW5kZXIgY29tcG9uZW50cyBmcm9tIGRhdGEgYWxyZWFkeSBkZWxpdmVyZWQgb24gQzEsXFxuYW5kIHRoZXkgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJuZXZlciByZS1lbnRlciB0aGUgZW5naW5lXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBubyBDMSByZS1lbWl0LCBubyBDNiB3cml0ZSwgbm8gcmVjb21wdXRlLiBPbmx5IGFcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJwYXJhbXNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNoYW5nZSAoQzYpIHJlY29tcHV0ZXMuIFRoaXMga2VlcHMgcmVzcG9uc2l2ZW5lc3MgZW50aXJlbHkgaW4gdGhlIHZpZXcgcmVhbG0sIG9mZiB0aGVcXG5lbmdpbmUgYm91bmRhcnkgYW5kIHRoZSB0aWVyIGZvbGQuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInNlYy01XCIgZGF0YS1zbHVnPVwiNS10aGUtYXNzaXN0YW50LWlzLWFuLWF1ZGllbmNlLXRoZS1ob2xkb3V0LWZpeC1nZW5lcmFsaXplZC1ub3JtYXRpdmVcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy01XCIgLz57XCI1LiBUaGUgYXNzaXN0YW50IGlzIGFuIGF1ZGllbmNlIOKAlCB0aGUgaG9sZG91dCBmaXgsIGdlbmVyYWxpemVkICBcIn08X2NvbXBvbmVudHMuZW0+e1wiKG5vcm1hdGl2ZSlcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLmNvZGU+e1wiSE9MRE9VVF9SRURBQ1RFRF9NT1VOVF9TUEVDXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjbG9zZWQgdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZmlsZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBjaGFubmVsIGFuZCBtaXNzZWQgQzMvQzQuIFRoZSBnZW5lcmFsIHJ1bGVcXG50aGlzIHNwZWMgc3RhdGVzIG9uY2UsIGZvciBhbGwgY2hhbm5lbHM6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQSBjaGFubmVsIHdob3NlIHBheWxvYWQgZGVyaXZlcyBmcm9tIGhvbGRvdXQtc2NvcGVkIGlucHV0cyBtdXN0IG5vdCBjYXJyeSB0aGF0IHBheWxvYWQgdG9cXG50aGUgYXV0aG9yaW5nIGFzc2lzdGFudCBhdCBhIGJhbmR3aWR0aCB0aGF0IHJlY29uc3RydWN0cyB0aGUgaGVsZC1vdXQgdmFsdWVzLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLmhvbGRvdXQvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIlxcbnBhdGggaXMgb25lIGluc3RhbmNlIChDNS1yZWFkLCBjbG9zZWQgYnkgRDkncyBtb3VudCBzZXBhcmF0aW9uKTsgdGhlIHRyYWNlIChDMykgYW5kIHRoZSB0ZXN0XFxudmVyZGljdCAoQzQpIGFyZSB0aGUgaW5zdGFuY2VzIEQ5IG1pc3NlZCwgY2xvc2VkIGhlcmU6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJDMyAodHJhY2UpOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBhIHRyYWNlIHdob3NlIGRlY2xhcmVkIGlucHV0cyBpbmNsdWRlIGEgaG9sZG91dC1zY29wZWQgZml4dHVyZSBpcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vdFxcbmRlbGl2ZXJlZCB0byB0aGUgYXNzaXN0YW50XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChpdCBtYXkgc3RpbGwgc2VydmUgaG9zdC1zaWRlIGRlYnVnZ2luZyB3aXRoIG5vIGFnZW50IGluIHRoZVxcbmF1ZGllbmNlKS4gVGhlIGFnZW50IGF1dGhvcmluZyBhIHRlc3Qgb3ZlciBob2xkb3V0IGdldHMgcGFzcy9mYWlsIHN0YXR1cywgbmV2ZXIgdGhlXFxuaW5wdXQtZWNob2luZyB0cmFjZS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkM0ICh2ZXJkaWN0KTpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYSB0ZXN0IHZlcmRpY3Qgd2hvc2Ugc3ViamVjdCByZWFkcyBob2xkb3V0IGlzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicmVkdWNlZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBmb3IgdGhlXFxuYXNzaXN0YW50IHRvIHRoZSByZXZpZXctc3VyZmFjZSBzdGF0dXMgKFwifTxfY29tcG9uZW50cy5jb2RlPntcInZhbGlkYXRlZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicGlubmVkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikg4oCUIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibm90XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHRoZSBudW1lcmljXFxuYXNzZXJ0aW9uIGRpZmYsIGFuZCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInJhdGUtYm91bmRlZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBzbyBhIGJpc2VjdGlvbiAoYXV0aG9yIGEgY29tcGFyYXRvciwgcmVhZCBwYXNzL2ZhaWwsXFxubmFycm93KSBjYW5ub3QgcmVjb3ZlciB0aGUgdmFsdWUgYWNyb3NzIHJ1bnMuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTwvX2NvbXBvbmVudHMuYmxvY2txdW90ZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkhvbmVzdCBsaW1pdCAoY2FycmllZCBmcm9tIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkhPTERPVVQgwqc1XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIik6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHRoaXMgcmFpc2VzIHRoZSBvcmFjbGUncyBjb3N0OyBpdCBkb2VzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibm90XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiXFxubWFrZSBob2xkb3V0IGEgY29ycmVjdG5lc3MgcHJvb2YgKHRoZSBhZ2VudCBzdGlsbCBzZWVzIHRoZSBcIn08X2NvbXBvbmVudHMuZW0+e1widHJhaW5pbmdcIn08L19jb21wb25lbnRzLmVtPntcIiBzcGxpdCBhbmQsIGZvciBhZmZpbmVcXG5mb3JtdWxhcywgdGhhdCBkZXRlcm1pbmVzIHRoZSBvdXRjb21lKS4gSG9sZG91dCBzdGF5cyBhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1widHJpcHdpcmVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCI7IHRoZSBsb2FkLWJlYXJpbmdcXG5jb3JyZWN0bmVzcyBzaWduYWwgaXMgdGhlIG9yYWNsZS1mcmVlIGxlZ3MuIFRoaXMgc3BlYydzIGpvYiBpcyBvbmx5IHRvIHN0b3AgQzMvQzQgZnJvbSBiZWluZyBhXFxuXCJ9PF9jb21wb25lbnRzLmVtPntcInRyaXZpYWxcIn08L19jb21wb25lbnRzLmVtPntcIiBsZWFrIHRoZSB3YXkgdGhlIGZpbGUgY2hhbm5lbCB3YXMg4oCUIGkuZS4gdG8gbWFrZSB0aGUgbW91bnQtc2VwYXJhdGlvbiBlZmZvcnQgbm90XFxucG9pbnRsZXNzLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtNlwiIGRhdGEtc2x1Zz1cIjYtZ2xpdGNoLWZyZWVkb20taXMtYS1wdWJsaWNhdGlvbi1ydWxlLWZvci1hbGwtY2hhbm5lbHMtdGhlLXJlY2FsYy1maXgtZ2VuZXJhbGl6ZWQtbm9ybWF0aXZlXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtNlwiIC8+e1wiNi4gR2xpdGNoLWZyZWVkb20gaXMgYSBwdWJsaWNhdGlvbiBydWxlIGZvciBhbGwgY2hhbm5lbHMg4oCUIHRoZSByZWNhbGMgZml4LCBnZW5lcmFsaXplZCAgXCJ9PF9jb21wb25lbnRzLmVtPntcIihub3JtYXRpdmUpXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSBhdG9taWMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiKHZhbHVlLCB0aWVyLCBlcG9jaClcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHJlY29yZCBhbmQgdGhlIGNvbW1vbi1lcG9jaCBiYXJyaWVyIGFyZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInB1YmxpY2F0aW9uIHJ1bGVzXFxudGhhdCBnb3Zlcm4gZXZlcnkgY2hhbm5lbCBpbiDCpzQsIG5vdCBvbmx5IGNlbGzihpJjZWxsIGVkZ2VzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIkEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJzdWJzY3JpYmVyXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChDMSkgcmVjZWl2ZXMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiREBrXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBvbmx5IHdoZW4gdGhlIGJhcnJpZXIgaXMgc2F0aXNmaWVkIOKAlCBuZXZlciBcIn08X2NvbXBvbmVudHMuY29kZT57XCJEXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjb21wdXRlZFxcbmZyb20gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQkBlMSArIENAZTJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChyZXZpZXctMiBDLVItQikuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiQSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInRyYWNlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChDMykgb3IgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJkaWFnbm9zdGljXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChDMikgb2YgYSBzdXBlcnNlZGVkIGVwb2NoIGlzIGRyb3BwZWQsIHNvIHJlcGxheSBuZXZlclxcbnJlY29uc3RydWN0cyBhIHBoYW50b20gb3IgbWl4ZWQtZXBvY2ggZXZhbHVhdGlvbi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJBIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZnJvemVuIGZyYW1lXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChDNSkgcmVjb3JkcyB0aGUgZXBvY2ggaXQgY2FwdHVyZWQsIHNvIGEgbGF0ZXIgXFxcIndoYXQgZGlkIHdlIHJlcG9ydCBsYXN0XFxucXVhcnRlclxcXCIgKFNwaW5lIDMgcmVwcm9kdWNpYmlsaXR5KSBoYXMgYSBjb25zaXN0ZW50IGN1dC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhpcyBpcyB3aHkgU3BpbmUgMSBpcyBhIFwifTxfY29tcG9uZW50cy5lbT57XCJjb250cmFjdFwifTwvX2NvbXBvbmVudHMuZW0+e1wiLCBub3QgYSBzY2hlZHVsZXIgZGV0YWlsOiB0aGUgYmFycmllciBpcyBtZWFuaW5nbGVzcyBpZiBvbmVcXG5jaGFubmVsIGhvbm9ycyBpdCBhbmQgYW5vdGhlciBkb2Vzbid0LlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtN1wiIGRhdGEtc2x1Zz1cIjctbG9hZC1iZWFyaW5nLWFzc3VtcHRpb25zLWNvZGUtYW5jaG9yc1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTdcIiAvPntcIjcuIExvYWQtYmVhcmluZyBhc3N1bXB0aW9ucyAmIGNvZGUgYW5jaG9yc1wifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwiZGVwZW5kcy1vbi10b2RheS12ZXJpZmllZC0yMDI2LTA3LTA5LXJlLWNoZWNrZWQtYnktc2NyaXB0c2NoZWNrLXNwZWMtYW5jaG9yc21qc1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwiZGVwZW5kcy1vbi10b2RheS12ZXJpZmllZC0yMDI2LTA3LTA5LXJlLWNoZWNrZWQtYnktc2NyaXB0c2NoZWNrLXNwZWMtYW5jaG9yc21qc1wiIC8+e1wiRGVwZW5kcy1vbi10b2RheSAodmVyaWZpZWQgMjAyNi0wNy0wOTsgcmUtY2hlY2tlZCBieSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzY3JpcHRzL2NoZWNrLXNwZWMtYW5jaG9ycy5tanNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKVwifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnRhYmxlPjxfY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRoPntcIkFzc3VtcHRpb24gKGV4aXN0aW5nIGJlaGF2aW9yIHRoZSBkZXNpZ24gcmVzdHMgb24pXCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGg+e1wiQW5jaG9yIChyZXBvLXJlbGF0aXZlIGZpbGUpXCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGg+e1wiVG9rZW4gKGdyZXAtc3RhYmxlKVwifTwvX2NvbXBvbmVudHMudGg+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50Ym9keT48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkhvc3QgbW91bnQgdGllciBpcyBhdXRob3JpdGF0aXZlOyB0aGUgYXBwIGRvZXMgbm90IHNlbGYtZGVjbGFyZSBpdFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcImltbWVkaWF0ZWx5LXJ1bi1zaXRlLW1haW4vc3JjL2ZpbGVzeXN0ZW0vc2NvcGVkRnMudHNcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiY2xhc3NpZnlQYXRoXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkFuIGFwcCdzIGZzIGVncmVzcyBpcyBob3N0LW1lZGlhdGVkICh0aGUgc3VyZmFjZSBhbiBhdWRpZW5jZSBmaWx0ZXIgYXR0YWNoZXMgdG8pXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiaW1tZWRpYXRlbHktcnVuLXNkay9zcmMvZnMudHNcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wic2FuZGJveEZzXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRib2R5PjwvX2NvbXBvbmVudHMudGFibGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLmVtPntcIihUaGlzIGlzIG1vc3RseSBhIG5ldyBjb250cmFjdDsgdGhlIHRhYmxlIGFib3ZlIGlzIGRlbGliZXJhdGVseSBzaG9ydCDigJQgbW9zdCBpbnZhcmlhbnRzIGFyZVxcbk11c3QtZXN0YWJsaXNoLCBub3QgRGVwZW5kcy1vbiwgYW5kIGFyZSBmbGFnZ2VkIGFzIHByb3Bvc2VkIHJhdGhlciB0aGFuIGFzc2VydGVkIGFzIGV4aXN0aW5nLilcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCJtdXN0LWVzdGFibGlzaC1uZXctaW52YXJpYW50cy10aGUtaW1wbGVtZW50YXRpb24tY3JlYXRlc1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwibXVzdC1lc3RhYmxpc2gtbmV3LWludmFyaWFudHMtdGhlLWltcGxlbWVudGF0aW9uLWNyZWF0ZXNcIiAvPntcIk11c3QtZXN0YWJsaXNoIChuZXcgaW52YXJpYW50cyB0aGUgaW1wbGVtZW50YXRpb24gY3JlYXRlcylcIn08L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy50YWJsZT48X2NvbXBvbmVudHMudGhlYWQ+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50aD57XCJOZXcgaW52YXJpYW50XCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGg+e1wiUHJvdmVuIGJ5IChnYXRlIHRlc3QpXCJ9PC9fY29tcG9uZW50cy50aD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGhlYWQ+PF9jb21wb25lbnRzLnRib2R5PjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiRXZlcnkgZW5naW5lLWJvdW5kYXJ5IGNoYW5uZWwgY2FycmllcyBcIn08X2NvbXBvbmVudHMuY29kZT57XCIodmFsdWUsIHRpZXIsIGVwb2NoKVwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJjaGFubmVsLWNvbnRyYWN0IHRlc3Q6IGVhY2ggb2YgQzHigJNDNiBlbWl0cyB0aGUgdHJpcGxlOyBhIHBheWxvYWQgd2l0aG91dCBpdCBpcyByZWplY3RlZCBhdCB0aGUgYm91bmRhcnlcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJUaGUgY29tbW9uLWVwb2NoIGJhcnJpZXIgZ292ZXJucyB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJyZXN1bHQgY2hhbm5lbCB0byBhIHN1YnNjcmliZXJcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIsIG5vdCBvbmx5IGNlbGzihpJjZWxsXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiRy1FSUYtMTogYSBzaGFyZWQtYW5jZXN0b3IgYXN5bW1ldHJpYy1hcm0gZGlhbW9uZCBuZXZlciBkZWxpdmVycyBhIG1peGVkLWVwb2NoIHJlc3VsdCB0byBhIHN1YnNjcmliZXIgKHJldmlldy0yIEMtUi1CKVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIlN1cGVyc2VkZWQtZXBvY2ggcmVzdWx0cyBhcmUgZHJvcHBlZCBvbiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImV2ZXJ5XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGNoYW5uZWwgKHJlc3VsdCwgZGlhZ25vc3RpYywgdHJhY2UpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiRy1FSUYtMjogYSBsYXRlIGFzeW5jIHJlc3VsdCAvIGl0cyB0cmFjZSBmcm9tIGEgc3VwZXJzZWRlZCBlcG9jaCBpcyBuZXZlciBwdWJsaXNoZWQgb3IgcmVwbGF5ZWQgYXMgY3VycmVudFwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIk5vIGNoYW5uZWwgZW1pdHMgYmVsb3cgdGhlIGlucHV0IHRpZXIgZmxvb3JcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJHLUVJRi0zOiBhIHZhbHVlIGRlcml2ZWQgZnJvbSBhbiBNMyBpbnB1dCBuZXZlciBhcHBlYXJzIG9uIGFueSBjaGFubmVsIHRhZ2dlZCBiZWxvdyBNM1wifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkhvbGRvdXQtc2NvcGVkIHBheWxvYWRzIGFyZSBhdWRpZW5jZS1leGNsdWRlZCBvbiBDMyBhbmQgYmFuZHdpZHRoLWJvdW5kZWQgb24gQzRcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJHLUVJRi00OiBhbiBhc3Npc3RhbnQgYXV0aG9yaW5nIGEgdGVzdCBvdmVyIGhvbGRvdXQgcmVjZWl2ZXMgbm8gaW5wdXQtZWNob2luZyB0cmFjZSBhbmQgY2Fubm90IGJpc2VjdCB0aGUgdmFsdWUgZnJvbSB2ZXJkaWN0cyAoY2xvc2VzIHJldmlldy0yIEQ5LTEpXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiRGlhZ25vc3RpY3MvdHJhY2VzIGFyZSBhdXRob3Itb25seSwgbmV2ZXIgc2hhcmVkLXZpZXdcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJHLUVJRi01OiBhIHNoYXJlZC12aWV3IHNlc3Npb24gZXhwb3NlcyBubyBDMi9DMyBwYXlsb2FkXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGJvZHk+PC9fY29tcG9uZW50cy50YWJsZT57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtOFwiIGRhdGEtc2x1Zz1cIjgtZGVjaXNpb25zLXJlamVjdGVkLWFsdGVybmF0aXZlc1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLThcIiAvPntcIjguIERlY2lzaW9ucyAmIHJlamVjdGVkIGFsdGVybmF0aXZlc1wifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIk9uZSBjb250cmFjdCBvdmVyIGFsbCBlbmdpbmUtZWdyZXNzIGNoYW5uZWxzIChlcG9jaCDDlyB0aWVyIMOXIGF1ZGllbmNlIMOXIGJhbmR3aWR0aCkuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmVtPntcIlJlamVjdGVkOlwifTwvX2NvbXBvbmVudHMuZW0+e1wiIHBlci1jaGFubmVsIHNwZWNzICh0aGUgcmV2aWV3LTIgZmFpbHVyZSBtb2RlIOKAlCB0aGUgZmlsZSBjaGFubmVsIGdvdmVybmVkLFxcbnRoZSB0cmFjZS92ZXJkaWN0IGNoYW5uZWxzIG5vdDsgdGhlIGNlbGzihpJjZWxsIGVwb2NoIGdvdmVybmVkLCB0aGUgc3Vic2NyaWJlciByZXN1bHQgbm90KS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlRoZSBhc3Npc3RhbnQgaXMgbW9kZWxlZCBhcyBhbiBcIn08X2NvbXBvbmVudHMuZW0+e1wiYXVkaWVuY2VcIn08L19jb21wb25lbnRzLmVtPntcIiwgYW5kIGhvbGRvdXQgaXMgYSBjaGFubmVsLWxldmVsIGV4Y2x1c2lvbi5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCJcXG5cIn08X2NvbXBvbmVudHMuZW0+e1wiUmVqZWN0ZWQ6XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgbW9kZWxpbmcgaG9sZG91dCBvbmx5IGFzIGEgXCJ9PF9jb21wb25lbnRzLmVtPntcImZpbGVzeXN0ZW1cIn08L19jb21wb25lbnRzLmVtPntcIiBwcm9wZXJ0eSAoRDkncyBvcmlnaW5hbCBmcmFtaW5nIOKAlCB0aGVcXG5hZ2VudCBkb2Vzbid0IG5lZWQgdGhlIGZpbGUsIGl0IG5lZWRzIHRoZSB0cmFjZS92ZXJkaWN0KS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkdsaXRjaC1mcmVlZG9tIGFzIGEgXCJ9PF9jb21wb25lbnRzLmVtPntcInB1YmxpY2F0aW9uXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgcnVsZSBiaW5kaW5nIGFsbCBjaGFubmVscywgbm90IGEgc2NoZWR1bGVyLWludGVybmFsXFxucHJvcGVydHkuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5lbT57XCJSZWplY3RlZDpcIn08L19jb21wb25lbnRzLmVtPntcIiB0cmVhdGluZyB0aGUgYXRvbWljIHBhaXIgYXMgd2l0aGluLWNlbGwgb25seSAocmV2aWV3LTIgQy1SLUIgcmVsb2NhdGVkXFxudGhlIGdsaXRjaCB0byB0aGUgcHVibGljYXRpb24gYm91bmRhcnkpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVHJhY2VzL3ZlcmRpY3RzIG92ZXIgaG9sZG91dCBhcmUgc3VwcHJlc3NlZC9yZWR1Y2VkLCBub3QgZnVsbHkgYmxvY2tlZC5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXCJ9PF9jb21wb25lbnRzLmVtPntcIlJlamVjdGVkOlwifTwvX2NvbXBvbmVudHMuZW0+e1wiXFxuYmxvY2tpbmcgYWxsIHRlc3Qgb3V0cHV0IG92ZXIgaG9sZG91dCAoYnJlYWtzIHRoZSBhdXRob3JpbmcgbG9vcCDigJQgdGhlIGF1dGhvciBtdXN0IHNlZSBcIn08X2NvbXBvbmVudHMuZW0+e1widGhhdFwifTwvX2NvbXBvbmVudHMuZW0+e1wiXFxuYSB0ZXN0IGZhaWxlZCk7IGxlYXZpbmcgdGhlbSBhdCBmdWxsIGJhbmR3aWR0aCAodGhlIGJpc2VjdGlvbiBvcmFjbGUpLiBUaGUgcmVkdWN0aW9uIGlzIHRoZVxcbm1pZGRsZSB0aGF0IGtlZXBzIHRoZSBsb29wIHdoaWxlIGRlZmVhdGluZyB0aGUgdHJpdmlhbCBvcmFjbGUuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaWVyIHN0YXlzIGhvc3QtYXV0aG9yaXRhdGl2ZSBvbiBldmVyeSBjaGFubmVsLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuZW0+e1wiUmVqZWN0ZWQ6XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgdHJ1c3RpbmcgYSBjb250ZW50LWRlY2xhcmVkXFxub3IgZmlsZS10YWcgdGllciBvbiBhbnkgZWdyZXNzIChsYXVuZGVyaW5nKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTlcIiBkYXRhLXNsdWc9XCI5LW9wZW4tcXVlc3Rpb25zXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtOVwiIC8+e1wiOS4gT3BlbiBxdWVzdGlvbnNcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJPUS0xIChob2xkb3V0LXNjb3BlIHByb3BhZ2F0aW9uKS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgQzMvQzQncyBleGNsdXNpb24ga2V5cyBvbiBcXFwicGF5bG9hZCBcIn08X2NvbXBvbmVudHMuZW0+e1wiZGVyaXZlcyBmcm9tXCJ9PC9fY29tcG9uZW50cy5lbT57XCJcXG5ob2xkb3V0LXNjb3BlZCBpbnB1dHMuXFxcIiBUaGF0IGRlcml2YXRpb24gaXMgZXhhY3RseSB0aGUgdGllciBmb2xkJ3MgdHJhdmVyc2FsIOKAlCBzb1xcblwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiaG9sZG91dC1zY29wZSBpcyBhIGxhdHRpY2UgbGFiZWwgdGhhdCByaWRlcyB0aGUgc2FtZSBmb2xkIGFzIHRpZXJcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKGEgc2Vjb25kIGJpdCkuIENvbmZpcm1cXG5pdCBjb21wb3NlcyAoYSB2YWx1ZSB0b3VjaGluZyBcIn08X2NvbXBvbmVudHMuZW0+e1wiYW55XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgaG9sZG91dCBpbnB1dCBpcyBob2xkb3V0LXNjb3BlZCkgYW5kIHRoYXQgaXQgZG9lcyBub3RcXG5vdmVyLXN1cHByZXNzIG9yZGluYXJ5IGF1dGhvcmluZyB3aGVyZSBubyBob2xkb3V0IGlzIGludm9sdmVkLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiT1EtMiAoYmFuZHdpZHRoIHF1YW50aWZpY2F0aW9uIGZvciBDNCkuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFxcXCJSYXRlLWJvdW5kZWQgc28gYmlzZWN0aW9uIGNhbm5vdCByZWNvdmVyIHRoZVxcbnZhbHVlXFxcIiBuZWVkcyBhIG51bWJlciDigJQgaG93IG1hbnkgaG9sZG91dC1zdWJqZWN0IHZlcmRpY3RzIHBlciBzZXNzaW9uLCBiZWZvcmUgdGhlIHZhbHVlJ3NcXG5lbnRyb3B5IGlzIGV4Y2VlZGVkPyBUaWUgdG8gdGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkhPTERPVVRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHJlLXNjb3BlOiBzaW5jZSBob2xkb3V0IGlzIG9ubHkgYSB0cmlwd2lyZSwgdGhlXFxuYm91bmQgY2FuIGJlIGNvYXJzZSAoYSBoYW5kZnVsIG9mIHZlcmRpY3RzKSwgbm90IGNyeXB0b2dyYXBoaWMuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJPUS0zIChTcGluZS0yIHNlYW0pLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGUgXFxcImF1ZGllbmNlXFxcIiBjb2x1bW4gbmFtZXMgcHJpbmNpcGFscyAodmlld2VyLCBhdXRob3IsIGFzc2lzdGFudClcXG53aG9zZSBcIn08X2NvbXBvbmVudHMuZW0+e1wiaWRlbnRpdHlcIn08L19jb21wb25lbnRzLmVtPntcIiBpcyB0aGUgU3BpbmUtMiBjYXBhYmlsaXR5IHRvcG9sb2d5LiBUaGlzIHNwZWMgYXNzdW1lcyB0aG9zZSBwcmluY2lwYWxzIGFyZVxcbmRpc3Rpbmd1aXNoYWJsZSBhdCB0aGUgYm91bmRhcnk7IFNwaW5lIDIgbXVzdCBtYWtlIHRoYXQgdHJ1ZSAodGhlIGFzc2lzdGFudCByZWFsbSBpcyBhXFxuZGlzdGluY3QgYXVkaWVuY2UgZnJvbSB0aGUgcmVwb3J0IHZpZXcg4oCUIHdoaWNoIG5lZWRzIEFBLTAxL0Q3KS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+PC8+O1xufVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTURYQ29udGVudChwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHt3cmFwcGVyOiBNRFhMYXlvdXR9ID0ge1xuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfTtcbiAgcmV0dXJuIE1EWExheW91dCA/IDxNRFhMYXlvdXQgey4uLnByb3BzfT48X2NyZWF0ZU1keENvbnRlbnQgey4uLnByb3BzfSAvPjwvTURYTGF5b3V0PiA6IF9jcmVhdGVNZHhDb250ZW50KHByb3BzKTtcbn1cbmZ1bmN0aW9uIF9taXNzaW5nTWR4UmVmZXJlbmNlKGlkLCBjb21wb25lbnQsIHBsYWNlKSB7XG4gIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIFwiICsgKGNvbXBvbmVudCA/IFwiY29tcG9uZW50XCIgOiBcIm9iamVjdFwiKSArIFwiIGBcIiArIGlkICsgXCJgIHRvIGJlIGRlZmluZWQ6IHlvdSBsaWtlbHkgZm9yZ290IHRvIGltcG9ydCwgcGFzcywgb3IgcHJvdmlkZSBpdC5cIiArIChwbGFjZSA/IFwiXFxuSXTigJlzIHJlZmVyZW5jZWQgaW4geW91ciBjb2RlIGF0IGBcIiArIHBsYWNlICsgXCJgIGluIGAvYXBwL2RvY3Mvc3BlY3MvRU5HSU5FX0lORk9STUFUSU9OX0ZMT1dfU1BFQy5tZGBcIiA6IFwiXCIpKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQXdGLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUZ4RjtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU1DLFdBQVcsR0FBRztNQUNsQkMsVUFBVSxFQUFFLFlBQVk7TUFDeEJDLElBQUksRUFBRSxNQUFNO01BQ1pDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLENBQUMsRUFBRSxHQUFHO01BQ05DLE1BQU0sRUFBRSxRQUFRO01BQ2hCQyxLQUFLLEVBQUUsT0FBTztNQUNkQyxLQUFLLEVBQUUsT0FBTztNQUNkQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxLQUFLLEVBQUUsT0FBTztNQUNkQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSLEdBQUcsSUFBQUMsNkJBQWtCLEVBQUMsQ0FBQztNQUN2QixHQUFHbkIsS0FBSyxDQUFDb0I7SUFDWCxDQUFDO0lBQUU7TUFBQ0M7SUFBYSxDQUFDLEdBQUdwQixXQUFXO0VBQ2hDLElBQUksQ0FBQ29CLGFBQWEsRUFBRUMsb0JBQW9CLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQztFQUMvRCxvQkFBTyxJQUFBeEIsV0FBQSxDQUFBeUIsSUFBQSxFQUFBekIsV0FBQSxDQUFBMEIsUUFBQTtJQUFBQyxRQUFBLGdCQUFFLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNJLEVBQUU7TUFBQ3FCLEVBQUUsRUFBQywrRUFBK0U7TUFBQUQsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUErRSxDQUFFLENBQUMsRUFBQyxzRkFBc0Y7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNTLENBQUM7TUFBQWUsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFTLENBQXFCLENBQUMsRUFBQyxzQkFBc0IsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFTLENBQXFCLENBQUMsRUFBQyxtQ0FBbUMsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRSxJQUFJO1FBQUFzQixRQUFBLEVBQUU7TUFBeUIsQ0FBbUIsQ0FBQyxFQUFDLCtEQUErRCxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNVLE1BQU07UUFBQWMsUUFBQSxHQUFFLHNIQUFzSCxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNHLEVBQUU7VUFBQXFCLFFBQUEsRUFBRTtRQUFhLENBQWlCLENBQUMsRUFBQywrQ0FBK0M7TUFBQSxDQUFxQixDQUFDLEVBQUMsaUdBQWlHLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBVSxDQUFxQixDQUFDLEVBQUMsYUFBYTtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0MsVUFBVTtNQUFBdUIsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDUyxDQUFDO1FBQUFlLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBYyxRQUFBLEdBQUUsNERBQTRELGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBc0IsUUFBQSxFQUFFO1VBQStDLENBQW1CLENBQUM7UUFBQSxDQUFvQixDQUFDLEVBQUMsMkVBQTJFO01BQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUF5QixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNDLFVBQVU7TUFBQXVCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1MsQ0FBQztRQUFBZSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWMsQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRSxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBeUIsQ0FBbUIsQ0FBQyxFQUFDLG9KQUFvSixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNFLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFnQyxDQUFtQixDQUFDLEVBQUMsNERBQTRELGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQTRCLENBQW1CLENBQUMsRUFBQyw4QkFBOEIsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRSxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBcUIsQ0FBbUIsQ0FBQyxFQUFDLG9EQUFvRCxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNFLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFpQyxDQUFtQixDQUFDLEVBQUMsbUNBQW1DLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBcUIsUUFBQSxFQUFFO1FBQU8sQ0FBaUIsQ0FBQyxFQUFDLG1EQUFtRDtNQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBeUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDTyxFQUFFLElBQUUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBVixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNLLEVBQUU7TUFBQ29CLEVBQUUsRUFBQyxPQUFPO01BQUMsYUFBVSwrQkFBK0I7TUFBQUQsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLHdCQUF3QixlQUFDLElBQUE1QixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNHLEVBQUU7UUFBQXFCLFFBQUEsRUFBRTtNQUFhLENBQWlCLENBQUM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNTLENBQUM7TUFBQWUsUUFBQSxHQUFFLDRCQUE0QixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVUsQ0FBcUIsQ0FBQyxFQUFDLGdEQUFnRCxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQXdCLENBQXFCLENBQUMsRUFBQyxpRUFBaUU7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNDLFVBQVU7TUFBQXVCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1MsQ0FBQztRQUFBZSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNVLE1BQU07VUFBQWMsUUFBQSxHQUFFLHdJQUF3SSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNFLElBQUk7WUFBQXNCLFFBQUEsRUFBRTtVQUFPLENBQW1CLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBc0IsUUFBQSxFQUFFO1VBQU0sQ0FBbUIsQ0FBQyxFQUFDLFFBQVEsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRSxJQUFJO1lBQUFzQixRQUFBLEVBQUU7VUFBVSxDQUFtQixDQUFDLEVBQUMsYUFBYSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNFLElBQUk7WUFBQXNCLFFBQUEsRUFBRTtVQUFXLENBQW1CLENBQUMsRUFBQyxHQUFHO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLCtJQUErSSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNHLEVBQUU7VUFBQXFCLFFBQUEsRUFBRTtRQUFLLENBQWlCLENBQUMsRUFBQyxzRUFBc0U7TUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQXlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBZSxRQUFBLEdBQUUsdURBQXVELGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBcUIsUUFBQSxFQUFFO01BQUssQ0FBaUIsQ0FBQyxFQUFDLDJDQUEyQyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQU0sQ0FBcUIsQ0FBQyxFQUFDLDBDQUEwQyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQU8sQ0FBcUIsQ0FBQyxFQUFDLE9BQU8sZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFTLENBQXFCLENBQUMsRUFBQyxpSUFBaUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFXLENBQXFCLENBQUMsRUFBQyxpQ0FBaUMsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFRLENBQXFCLENBQUMsRUFBQyw4RkFBOEYsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRyxFQUFFO1FBQUFxQixRQUFBLEVBQUU7TUFBSyxDQUFpQixDQUFDLEVBQUMsMEJBQTBCO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDSyxFQUFFO01BQUNvQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUsa0RBQWtEO01BQUFELFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQyw4Q0FBOEMsZUFBQyxJQUFBNUIsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRyxFQUFFO1FBQUFxQixRQUFBLEVBQUU7TUFBYSxDQUFpQixDQUFDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDaUIsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNRLEVBQUU7UUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBYSxDQUFxQixDQUFDLEVBQUMsZ0VBQWdFLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBTyxDQUFxQixDQUFDLEVBQUMseUhBQXlILGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBcUIsUUFBQSxFQUFFO1FBQU0sQ0FBaUIsQ0FBQyxFQUFDLGtDQUFrQztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBZ0IsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDVSxNQUFNO1VBQUFjLFFBQUEsR0FBRSxpREFBaUQsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRSxJQUFJO1lBQUFzQixRQUFBLEVBQUU7VUFBd0IsQ0FBbUIsQ0FBQyxFQUFDLElBQUk7UUFBQSxDQUFxQixDQUFDLEVBQUMsZ0RBQWdELGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQUcsQ0FBbUIsQ0FBQyxFQUFDLGFBQWEsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUE2QyxDQUFxQixDQUFDLEVBQUMsNEJBQTRCLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQUcsQ0FBbUIsQ0FBQyxFQUFDLGdFQUFnRTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBZ0IsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFtRSxDQUFxQixDQUFDLEVBQUMsNkNBQTZDLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBWSxDQUFxQixDQUFDLEVBQUMsWUFBWSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXdCLENBQXFCLENBQUMsRUFBQyxtR0FBbUcsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRSxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBWSxDQUFtQixDQUFDLEVBQUMsZ0NBQWdDO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFnQixRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNVLE1BQU07VUFBQWMsUUFBQSxHQUFFLGdCQUFnQixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNFLElBQUk7WUFBQXNCLFFBQUEsRUFBRTtVQUE2QixDQUFtQixDQUFDLEVBQUMsSUFBSTtRQUFBLENBQXFCLENBQUMsRUFBQywyREFBMkQsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRSxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBZ0MsQ0FBbUIsQ0FBQyxFQUFDLHVLQUF1SyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNHLEVBQUU7VUFBQXFCLFFBQUEsRUFBRTtRQUFLLENBQWlCLENBQUMsRUFBQyxnQ0FBZ0M7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDb0IsRUFBRSxFQUFDLE9BQU87TUFBQyxhQUFVLGtDQUFrQztNQUFBRCxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMsNkJBQTZCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBcUIsUUFBQSxFQUFFO01BQWEsQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2lCLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFnQixRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNVLE1BQU07VUFBQWMsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRSxJQUFJO1lBQUFzQixRQUFBLEVBQUU7VUFBYyxDQUFtQixDQUFDLEVBQUMscURBQXFEO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLGlGQUFpRixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNFLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUF3QixDQUFtQixDQUFDLEVBQUMsV0FBVztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBZ0IsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDVSxNQUFNO1VBQUFjLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBc0IsUUFBQSxFQUFFO1VBQWUsQ0FBbUIsQ0FBQyxFQUFDLHVCQUF1QjtRQUFBLENBQXFCLENBQUMsRUFBQyw4SkFBOEosZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRSxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBb0IsQ0FBbUIsQ0FBQyxFQUFDLDRDQUE0QztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBZ0IsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUE0QixDQUFxQixDQUFDLEVBQUMseUJBQXlCLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQWdCLENBQW1CLENBQUMsRUFBQyw2R0FBNkcsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRSxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBd0IsQ0FBbUIsQ0FBQyxFQUFDLGtCQUFrQixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWdFLENBQXFCLENBQUMsRUFBQyxnREFBZ0Q7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDb0IsRUFBRSxFQUFDLE9BQU87TUFBQyxhQUFVLDZFQUE2RTtNQUFBRCxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMsaURBQWlELGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBcUIsUUFBQSxFQUFFO01BQXNDLENBQWlCLENBQUM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNTLENBQUM7TUFBQWUsUUFBQSxHQUFFLDJFQUEyRSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNHLEVBQUU7UUFBQXFCLFFBQUEsRUFBRTtNQUEyQixDQUFpQixDQUFDLEVBQUMseUJBQXlCLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBTyxDQUFxQixDQUFDLEVBQUMsdUNBQXVDLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBc0IsUUFBQSxFQUFFO01BQU0sQ0FBbUIsQ0FBQyxFQUFDLDZDQUE2QztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1csS0FBSztNQUFBYSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNlLEtBQUs7UUFBQVMsUUFBQSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNnQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBRyxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDYyxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFTLENBQWlCLENBQUMsbUJBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNjLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQVcsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBZSxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDYyxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFjLENBQWlCLENBQUMsbUJBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNjLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQVUsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBaUIsQ0FBaUIsQ0FBQztRQUFBLENBQWdCO01BQUMsQ0FBbUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksS0FBSztRQUFBWSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNnQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBSSxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBUSxDQUFxQixDQUFDLEVBQUMsd0JBQXdCO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBNEMsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEdBQUUsT0FBTyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQXNCLENBQXFCLENBQUMsRUFBQyxPQUFPO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEdBQUUsT0FBTyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNFLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFjLENBQW1CLENBQUMsRUFBQyxTQUFTO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQVEsQ0FBcUIsQ0FBQyxFQUFDLGFBQWE7VUFBQSxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFpQyxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2dCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFJLENBQWlCLENBQUMsbUJBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFhLENBQXFCLENBQUMsRUFBQywwQkFBMEI7VUFBQSxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsR0FBRSxrQkFBa0IsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFnQixDQUFxQixDQUFDO1VBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEdBQUUsY0FBYyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNFLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFXLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQVksQ0FBbUIsQ0FBQyxFQUFDLDBCQUEwQjtVQUFBLENBQWlCLENBQUMsbUJBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQWdDLENBQWlCLENBQUMsbUJBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFhLENBQXFCLENBQUMsRUFBQyxxQkFBcUI7VUFBQSxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsR0FBRSxxQkFBcUIsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUF1QixDQUFxQixDQUFDLEVBQUMsZ0NBQWdDO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNnQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBSSxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBYyxDQUFxQixDQUFDLEVBQUMsNkNBQTZDO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBb0MsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBdUMsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBZ0MsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEdBQUUsdUJBQXVCLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBbUYsQ0FBcUIsQ0FBQyxFQUFDLE9BQU87VUFBQSxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsR0FBRSxtQkFBbUIsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUF3RCxDQUFxQixDQUFDO1VBQUEsQ0FBZ0IsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNnQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBSSxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBYyxDQUFxQixDQUFDLEVBQUMsK0JBQStCO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBNEMsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBSyxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUE2QixDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsR0FBRSx1Q0FBdUMsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUE2SCxDQUFxQixDQUFDLEVBQUMsT0FBTztVQUFBLENBQWlCLENBQUMsbUJBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUF3QyxDQUFxQixDQUFDLEVBQUMsZ0RBQWdEO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNnQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBSSxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFrQyxDQUFxQjtVQUFDLENBQWdCLENBQUMsbUJBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQTZCLENBQWlCLENBQUMsbUJBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQXFDLENBQWlCLENBQUMsbUJBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFrQixDQUFxQixDQUFDLEVBQUMseUNBQXlDO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBa0IsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBOEQsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNnQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBSSxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBa0IsQ0FBcUIsQ0FBQyxFQUFDLHdCQUF3QjtVQUFBLENBQWlCLENBQUMsbUJBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQTZCLENBQWlCLENBQUMsbUJBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxHQUFFLHFCQUFxQixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQVcsQ0FBcUIsQ0FBQyxFQUFDLG1CQUFtQjtVQUFBLENBQWlCLENBQUMsbUJBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQWEsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBUSxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUE4QixDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQztNQUFBLENBQW1CLENBQUM7SUFBQSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNTLENBQUM7TUFBQWUsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFvQixDQUFxQixDQUFDLEVBQUMsOElBQThJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBeUQsQ0FBcUIsQ0FBQyxFQUFDLG9GQUFvRixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQXlDLENBQXFCLENBQUMsRUFBQywrRkFBK0Y7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNTLENBQUM7TUFBQWUsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFvQyxDQUFxQixDQUFDLEVBQUMsd0JBQXdCLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBUSxDQUFxQixDQUFDLEVBQUMsUUFBUSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQW9CLENBQXFCLENBQUMsRUFBQyx3REFBd0QsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRSxJQUFJO1FBQUFzQixRQUFBLEVBQUU7TUFBMEIsQ0FBbUIsQ0FBQyxFQUFDLFFBQVEsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUEwQixDQUFxQixDQUFDLEVBQUMsMEZBQTBGLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBMkIsQ0FBcUIsQ0FBQyxFQUFDLHVEQUF1RCxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNFLElBQUk7UUFBQXNCLFFBQUEsRUFBRTtNQUFRLENBQW1CLENBQUMsRUFBQyw0SEFBNEg7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNLLEVBQUU7TUFBQ29CLEVBQUUsRUFBQyxPQUFPO01BQUMsYUFBVSxzRUFBc0U7TUFBQUQsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLGtFQUFrRSxlQUFDLElBQUE1QixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNHLEVBQUU7UUFBQXFCLFFBQUEsRUFBRTtNQUFhLENBQWlCLENBQUM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNTLENBQUM7TUFBQWUsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRSxJQUFJO1FBQUFzQixRQUFBLEVBQUU7TUFBNkIsQ0FBbUIsQ0FBQyxFQUFDLGNBQWMsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFNLENBQXFCLENBQUMsRUFBQyx1RkFBdUY7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNDLFVBQVU7TUFBQXVCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1MsQ0FBQztRQUFBZSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTBLLENBQXFCLENBQUMsRUFBQyxPQUFPLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLHdKQUF3SjtNQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2lCLEVBQUU7UUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDUSxFQUFFO1VBQUFnQixRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07WUFBQWMsUUFBQSxFQUFFO1VBQWEsQ0FBcUIsQ0FBQyxFQUFDLHFFQUFxRSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07WUFBQWMsUUFBQSxFQUFFO1VBQWlDLENBQXFCLENBQUMsRUFBQywwS0FBMEs7UUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNRLEVBQUU7VUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtZQUFBYyxRQUFBLEVBQUU7VUFBZSxDQUFxQixDQUFDLEVBQUMsaURBQWlELGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtZQUFBYyxRQUFBLEVBQUU7VUFBUyxDQUFxQixDQUFDLEVBQUMsb0RBQW9ELGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBc0IsUUFBQSxFQUFFO1VBQVcsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRSxJQUFJO1lBQUFzQixRQUFBLEVBQUU7VUFBUSxDQUFtQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07WUFBQWMsUUFBQSxFQUFFO1VBQUssQ0FBcUIsQ0FBQyxFQUFDLG9DQUFvQyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07WUFBQWMsUUFBQSxFQUFFO1VBQWMsQ0FBcUIsQ0FBQyxFQUFDLHNHQUFzRztRQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUF5QixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNTLENBQUM7TUFBQWUsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDVSxNQUFNO1FBQUFjLFFBQUEsR0FBRSw2QkFBNkIsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRSxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBWSxDQUFtQixDQUFDLEVBQUMsSUFBSTtNQUFBLENBQXFCLENBQUMsRUFBQywwQ0FBMEMsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFLLENBQXFCLENBQUMsRUFBQywrREFBK0QsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRyxFQUFFO1FBQUFxQixRQUFBLEVBQUU7TUFBVSxDQUFpQixDQUFDLEVBQUMsa0ZBQWtGLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBVSxDQUFxQixDQUFDLEVBQUMsc0hBQXNILGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBcUIsUUFBQSxFQUFFO01BQVMsQ0FBaUIsQ0FBQyxFQUFDLCtGQUErRjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDb0IsRUFBRSxFQUFDLE9BQU87TUFBQyxhQUFVLDhGQUE4RjtNQUFBRCxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMsMEZBQTBGLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBcUIsUUFBQSxFQUFFO01BQWEsQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBZSxRQUFBLEdBQUUsYUFBYSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNFLElBQUk7UUFBQXNCLFFBQUEsRUFBRTtNQUFzQixDQUFtQixDQUFDLEVBQUMsMkNBQTJDLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBOEUsQ0FBcUIsQ0FBQyxFQUFDLEdBQUc7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNpQixFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBZ0IsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFZLENBQXFCLENBQUMsRUFBQyxpQkFBaUIsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRSxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBSyxDQUFtQixDQUFDLEVBQUMsOENBQThDLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQUcsQ0FBbUIsQ0FBQyxFQUFDLGtCQUFrQixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNFLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyxvQkFBb0I7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNRLEVBQUU7UUFBQWdCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBTyxDQUFxQixDQUFDLEVBQUMsV0FBVyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQVksQ0FBcUIsQ0FBQyxFQUFDLDRHQUE0RztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBZ0IsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFjLENBQXFCLENBQUMsRUFBQyxzSUFBc0k7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBZSxRQUFBLEdBQUUsMkJBQTJCLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBcUIsUUFBQSxFQUFFO01BQVUsQ0FBaUIsQ0FBQyxFQUFDLHFHQUFxRztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDb0IsRUFBRSxFQUFDLE9BQU87TUFBQyxhQUFVLHlDQUF5QztNQUFBRCxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMsNENBQTRDO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDTSxFQUFFO01BQUNtQixFQUFFLEVBQUMsaUZBQWlGO01BQUFELFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBaUYsQ0FBRSxDQUFDLEVBQUMsdURBQXVELGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBc0IsUUFBQSxFQUFFO01BQWdDLENBQW1CLENBQUMsRUFBQyxHQUFHO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDVyxLQUFLO01BQUFhLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2UsS0FBSztRQUFBUyxRQUFBLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2dCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDYyxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFvRCxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDYyxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUE2QixDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDYyxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFxQixDQUFpQixDQUFDO1FBQUEsQ0FBZ0I7TUFBQyxDQUFtQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDWSxLQUFLO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2dCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFvRSxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRSxJQUFJO2NBQUFzQixRQUFBLEVBQUU7WUFBc0QsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRSxJQUFJO2NBQUFzQixRQUFBLEVBQUU7WUFBYyxDQUFtQjtVQUFDLENBQWdCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDZ0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQWtGLENBQWlCLENBQUMsbUJBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNFLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUErQixDQUFtQjtVQUFDLENBQWdCLENBQUMsbUJBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNFLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFXLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQztRQUFBLENBQWdCLENBQUM7TUFBQSxDQUFtQixDQUFDO0lBQUEsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDUyxDQUFDO01BQUFlLFFBQUEsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRyxFQUFFO1FBQUFxQixRQUFBLEVBQUU7TUFBNkwsQ0FBaUI7SUFBQyxDQUFlLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDbUIsRUFBRSxFQUFDLDBEQUEwRDtNQUFBRCxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQTBELENBQUUsQ0FBQyxFQUFDLDREQUE0RDtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1csS0FBSztNQUFBYSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNlLEtBQUs7UUFBQVMsUUFBQSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNnQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBZSxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDYyxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUF1QixDQUFpQixDQUFDO1FBQUEsQ0FBZ0I7TUFBQyxDQUFtQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDWSxLQUFLO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2dCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsR0FBRSx3Q0FBd0MsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRSxJQUFJO2NBQUFzQixRQUFBLEVBQUU7WUFBc0IsQ0FBbUIsQ0FBQztVQUFBLENBQWdCLENBQUMsbUJBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQXlHLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDZ0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxHQUFFLHVDQUF1QyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQWdDLENBQXFCLENBQUMsRUFBQyxzQkFBc0I7VUFBQSxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUF3SCxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2dCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsR0FBRSwwQ0FBMEMsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFPLENBQXFCLENBQUMsRUFBQyxzQ0FBc0M7VUFBQSxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUE0RyxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2dCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUE2QyxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUF3RixDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2dCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFpRixDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFzSixDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2dCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUF1RCxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUF5RCxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQztNQUFBLENBQW1CLENBQUM7SUFBQSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNLLEVBQUU7TUFBQ29CLEVBQUUsRUFBQyxPQUFPO01BQUMsYUFBVSxtQ0FBbUM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLHNDQUFzQztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2lCLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFnQixRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXFGLENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBcUIsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLHVLQUF1SztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBZ0IsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDVSxNQUFNO1VBQUFjLFFBQUEsR0FBRSxpQ0FBaUMsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRyxFQUFFO1lBQUFxQixRQUFBLEVBQUU7VUFBVSxDQUFpQixDQUFDLEVBQUMsNkNBQTZDO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRyxFQUFFO1VBQUFxQixRQUFBLEVBQUU7UUFBVyxDQUFpQixDQUFDLEVBQUMsOEJBQThCLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBcUIsUUFBQSxFQUFFO1FBQVksQ0FBaUIsQ0FBQyxFQUFDLG1HQUFtRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBZ0IsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDVSxNQUFNO1VBQUFjLFFBQUEsR0FBRSxzQkFBc0IsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRyxFQUFFO1lBQUFxQixRQUFBLEVBQUU7VUFBYSxDQUFpQixDQUFDLEVBQUMsaUVBQWlFO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRyxFQUFFO1VBQUFxQixRQUFBLEVBQUU7UUFBVyxDQUFpQixDQUFDLEVBQUMsbUhBQW1IO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFnQixRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXlFLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBcUIsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLDJGQUEyRixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNHLEVBQUU7VUFBQXFCLFFBQUEsRUFBRTtRQUFNLENBQWlCLENBQUMsRUFBQywrSkFBK0o7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNRLEVBQUU7UUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBaUQsQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRyxFQUFFO1VBQUFxQixRQUFBLEVBQUU7UUFBVyxDQUFpQixDQUFDLEVBQUMsNEVBQTRFO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNLLEVBQUU7TUFBQ29CLEVBQUUsRUFBQyxPQUFPO01BQUMsYUFBVSxrQkFBa0I7TUFBQUQsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLG1CQUFtQjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2lCLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFnQixRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQW1DLENBQXFCLENBQUMsRUFBQyx1Q0FBdUMsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRyxFQUFFO1VBQUFxQixRQUFBLEVBQUU7UUFBYyxDQUFpQixDQUFDLEVBQUMsd0ZBQXdGLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBbUUsQ0FBcUIsQ0FBQyxFQUFDLDBEQUEwRCxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNHLEVBQUU7VUFBQXFCLFFBQUEsRUFBRTtRQUFLLENBQWlCLENBQUMsRUFBQyx3SEFBd0g7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNRLEVBQUU7UUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBeUMsQ0FBcUIsQ0FBQyxFQUFDLCtLQUErSyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNFLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFTLENBQW1CLENBQUMsRUFBQyxtSEFBbUg7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNRLEVBQUU7UUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBc0IsQ0FBcUIsQ0FBQyxFQUFDLCtFQUErRSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNHLEVBQUU7VUFBQXFCLFFBQUEsRUFBRTtRQUFVLENBQWlCLENBQUMsRUFBQyxzT0FBc087TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUM7RUFBQSxDQUFFLENBQUM7QUFDeHAyQjtBQUNlLFNBQVNHLFVBQVVBLENBQUM1QixLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUU7RUFDN0MsTUFBTTtJQUFDNkIsT0FBTyxFQUFFQztFQUFTLENBQUMsR0FBRztJQUMzQixHQUFHLElBQUFYLDZCQUFrQixFQUFDLENBQUM7SUFDdkIsR0FBR25CLEtBQUssQ0FBQ29CO0VBQ1gsQ0FBQztFQUNELE9BQU9VLFNBQVMsZ0JBQUcsSUFBQWhDLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQ0csU0FBUztJQUFBLEdBQUs5QixLQUFLO0lBQUF5QixRQUFBLGVBQUUsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzVCLGlCQUFpQjtNQUFBLEdBQUtDO0lBQUssQ0FBRztFQUFDLENBQVcsQ0FBQyxHQUFHRCxpQkFBaUIsQ0FBQ0MsS0FBSyxDQUFDO0FBQ2xIO0FBQUMrQixFQUFBLEdBTnVCSCxVQUFVO0FBT2xDLFNBQVNOLG9CQUFvQkEsQ0FBQ0ksRUFBRSxFQUFFTSxTQUFTLEVBQUVDLEtBQUssRUFBRTtFQUNsRCxNQUFNLElBQUlDLEtBQUssQ0FBQyxXQUFXLElBQUlGLFNBQVMsR0FBRyxXQUFXLEdBQUcsUUFBUSxDQUFDLEdBQUcsSUFBSSxHQUFHTixFQUFFLEdBQUcsb0VBQW9FLElBQUlPLEtBQUssR0FBRyxxQ0FBcUMsR0FBR0EsS0FBSyxHQUFHLHdEQUF3RCxHQUFHLEVBQUUsQ0FBQyxDQUFDO0FBQ2xSO0FBQUMsSUFBQUYsRUFBQTtBQUFBSSxZQUFBLENBQUFKLEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}