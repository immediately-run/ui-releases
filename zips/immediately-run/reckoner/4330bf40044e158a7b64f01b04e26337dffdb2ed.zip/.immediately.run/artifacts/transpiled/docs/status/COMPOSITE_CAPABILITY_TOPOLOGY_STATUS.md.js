var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      blockquote: "blockquote",
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      li: "li",
      p: "p",
      strong: "strong",
      table: "table",
      tbody: "tbody",
      td: "td",
      th: "th",
      thead: "thead",
      tr: "tr",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "status-composite-capability-lifecycle-topology-d6-surfaces",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "status-composite-capability-lifecycle-topology-d6-surfaces"
      }), "Status — Composite capability & lifecycle topology (D6 surfaces)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Overall: the D6 consent/observability layer is built in BOTH halves — the decisions and the\nsurfaces that render them; the grant/lifecycle substrate it composes over (D1/D7/D8) is not."
      }), "\n· ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Created:"
      }), " 2026-08-27 · ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Updated:"
      }), " 2026-08-27 (roadmap R3-229)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: ["This document is the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "single implementation-status source"
        }), " for\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "../specs/COMPOSITE_CAPABILITY_TOPOLOGY_SPEC.md",
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "specs/COMPOSITE_CAPABILITY_TOPOLOGY_SPEC.md"
          })
        }), "'s\nD6 half. Where the spec and this file disagree, this file governs."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "built-site-mainsrcregistrycompositeconsentts",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "built-site-mainsrcregistrycompositeconsentts"
      }), "Built — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "site-main/src/registry/compositeConsent.ts"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Exit criterion"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "State"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "How it is proven"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Run-mode-first: a static document raises ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "zero"
            }), " powerbox"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "✅"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "planCompositeConsent"
            }), " returns ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "{steps: [], silent: true}"
            }), " when no member requests anything ungranted; asserted for the report-view + starved-engine pair"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Un-bundled elevated line (TS-5b)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "✅"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["one ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "ConsentLine"
            }), " per capability, each flagged ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "separate"
            }), "; a connector gets ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "one step per feed"
            }), ", so three feeds are three decisions"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Desktop and mobile ask the same questions"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "✅"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "the plan is form-factor independent by construction — there is no per-form-factor branch to drift"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Tier badge host-drawn, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "not"
            }), " app-emittable (H2)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "✅"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "hostBadge"
            }), " reads only the host-derived ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "trustMode"
            }), "; a manifest carrying ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "badge"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "tier"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "verified"
            }), " is asserted to be ignored, and the app's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "label"
            }), " stays text next to an unchanged badge"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Aggregate reach view shows the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "new total"
            }), ", not the delta (RB-6)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "✅"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "aggregateReach"
            }), " de-duplicates across existing and incoming sources; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "\"4 sources · 2 elevated\""
            })]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Manifest ↔ launch-graph reconciliation"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "✅"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "reconcileLaunchGraph"
            }), " — an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "undeclared"
            }), " launch fails the gate; a declared-but-not-launched member is reported and does not"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Composite inspector: per-member status, per-member revoke"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "✅"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "inspectComposite"
            }), " — one row per realm, grants never merged; the starved engine is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "shown holding nothing"
            }), " rather than hidden"]
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "built-the-surfaces-site-main378",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "built-the-surfaces-site-main378"
      }), "Built — the surfaces (site-main#378)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "The decisions above are rendered by two components, tested as a separate claim from the plan\nitself: a correct plan can still be drawn as a screen that bundles two grants into one row."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Surface"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Where"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "What the rendering guarantees"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "CompositeConsentDialog"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/editor/spaces/CompositeConsentDialog.tsx"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["a silent plan renders ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "null"
            }), " (run-mode-first made structural, not left to callers); one card per realm; a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "separate"
            }), " line visually detached; a feed step per feed; an outbound feed given chrome an inbound one does not"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "CompositeInspector"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/editor/spaces/CompositeInspector.tsx"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "one row per realm, never merged; a realm holding nothing rendered as \"Can reach nothing\"; per-member revoke whose accessible name carries the realm"
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The hostile-manifest case is rendered in a test rather than argued: a member labelled\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "immediately.run · verified"
      }), " carrying ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "badge: {trustMode: 'M0'}"
      }), " renders that label as text\nbeside an unchanged ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "unverified"
      }), " badge, and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "first-party"
      }), " never appears anywhere."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Mobile is one member per card by construction — the steps are a vertical list, so there is no\nsecond layout that can drift into asking different questions."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "not-built",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "not-built"
      }), "Not built"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "2026-09-25 (roadmap R3-768)."
        }), " Reckoner's report-view egress was removed: the bundled\nusage workbook (R3-349) that hardcoded an analytics origin and forced an app-wide\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "net:fetch"
        }), " request is gone from app code, moved to its own ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "immediately-run/usage-workbook"
        }), "\nrepo with declared ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "feeds/*.feed.json"
        }), " files. The report view now holds no network, as this\nspec's §2 requires; the connector realm that reconnects those feeds is R3-769."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The substrate."
        }), " §2's matrix assumes D7 (a distinct ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "appKey"
        }), " per realm), D8\n(per-instance launch/keep-warm/teardown) and D1 (per-instance delegation). D7 shipped as\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "AA-01 program identity"
        }), " (roadmap R3-162): a distinct ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "appKey"
        }), " per realm now exists, so\nrealm separation is no longer blocked on identity. D8 and D1 are still unbuilt, so today\nthere is nothing to build a real composite plan ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "from"
        }), " — the module is correct and\nunreachable, which is the intended order (enforcement before authority) and worth stating\nplainly rather than implying the surface is live."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "the-exit-criterion-that-is-not-code-and-must-not-be-reported-as-met",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-exit-criterion-that-is-not-code-and-must-not-be-reported-as-met"
      }), "The exit criterion that is NOT code, and must not be reported as met"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "The E3 reach-view efficacy study."
      }), " Now the item's ONLY unmet exit criterion, and the\nreason R3-229 should not be archived on the strength of the surfaces landing. §2.1 and RB-6\nboth mark reach-consent legibility as an open ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "empirical"
      }), " question: whether a user reading \"4 sources · 2 elevated\" understands\ntheir exposure, and whether an outbound-feed line is read as outbound. That is a behavioral\nstudy, it gates M3 sharing, and no unit test substitutes for it. The tests above prove the\nsurface ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "computes"
      }), " the right thing; they say nothing about whether it ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "communicates"
      }), " it,\nand a green suite must not be read as if they did."]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/status/COMPOSITE_CAPABILITY_TOPOLOGY_STATUS.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiYmxvY2txdW90ZSIsImNvZGUiLCJlbSIsImgxIiwiaDIiLCJsaSIsInAiLCJzdHJvbmciLCJ0YWJsZSIsInRib2R5IiwidGQiLCJ0aCIsInRoZWFkIiwidHIiLCJ1bCIsIl9wcm92aWRlQ29tcG9uZW50cyIsImNvbXBvbmVudHMiLCJIZWFkaW5nQW5jaG9yIiwiX21pc3NpbmdNZHhSZWZlcmVuY2UiLCJqc3hzIiwiRnJhZ21lbnQiLCJjaGlsZHJlbiIsImlkIiwianN4IiwiaHJlZiIsIk1EWENvbnRlbnQiLCJ3cmFwcGVyIiwiTURYTGF5b3V0IiwiX2MiLCJjb21wb25lbnQiLCJwbGFjZSIsIkVycm9yIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQ09NUE9TSVRFX0NBUEFCSUxJVFlfVE9QT0xPR1lfU1RBVFVTLm1kIl0sInNvdXJjZXNDb250ZW50IjpbIi8qQGpzeFJ1bnRpbWUgYXV0b21hdGljKi9cbi8qQGpzeEltcG9ydFNvdXJjZSByZWFjdCovXG5pbXBvcnQge3VzZU1EWENvbXBvbmVudHMgYXMgX3Byb3ZpZGVDb21wb25lbnRzfSBmcm9tIFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGsvTURYUHJvdmlkZXJcIjtcbmZ1bmN0aW9uIF9jcmVhdGVNZHhDb250ZW50KHByb3BzKSB7XG4gIGNvbnN0IF9jb21wb25lbnRzID0ge1xuICAgIGE6IFwiYVwiLFxuICAgIGJsb2NrcXVvdGU6IFwiYmxvY2txdW90ZVwiLFxuICAgIGNvZGU6IFwiY29kZVwiLFxuICAgIGVtOiBcImVtXCIsXG4gICAgaDE6IFwiaDFcIixcbiAgICBoMjogXCJoMlwiLFxuICAgIGxpOiBcImxpXCIsXG4gICAgcDogXCJwXCIsXG4gICAgc3Ryb25nOiBcInN0cm9uZ1wiLFxuICAgIHRhYmxlOiBcInRhYmxlXCIsXG4gICAgdGJvZHk6IFwidGJvZHlcIixcbiAgICB0ZDogXCJ0ZFwiLFxuICAgIHRoOiBcInRoXCIsXG4gICAgdGhlYWQ6IFwidGhlYWRcIixcbiAgICB0cjogXCJ0clwiLFxuICAgIHVsOiBcInVsXCIsXG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9LCB7SGVhZGluZ0FuY2hvcn0gPSBfY29tcG9uZW50cztcbiAgaWYgKCFIZWFkaW5nQW5jaG9yKSBfbWlzc2luZ01keFJlZmVyZW5jZShcIkhlYWRpbmdBbmNob3JcIiwgdHJ1ZSk7XG4gIHJldHVybiA8PjxfY29tcG9uZW50cy5oMSBpZD1cInN0YXR1cy1jb21wb3NpdGUtY2FwYWJpbGl0eS1saWZlY3ljbGUtdG9wb2xvZ3ktZDYtc3VyZmFjZXNcIj48SGVhZGluZ0FuY2hvciBpZD1cInN0YXR1cy1jb21wb3NpdGUtY2FwYWJpbGl0eS1saWZlY3ljbGUtdG9wb2xvZ3ktZDYtc3VyZmFjZXNcIiAvPntcIlN0YXR1cyDigJQgQ29tcG9zaXRlIGNhcGFiaWxpdHkgJiBsaWZlY3ljbGUgdG9wb2xvZ3kgKEQ2IHN1cmZhY2VzKVwifTwvX2NvbXBvbmVudHMuaDE+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJPdmVyYWxsOiB0aGUgRDYgY29uc2VudC9vYnNlcnZhYmlsaXR5IGxheWVyIGlzIGJ1aWx0IGluIEJPVEggaGFsdmVzIOKAlCB0aGUgZGVjaXNpb25zIGFuZCB0aGVcXG5zdXJmYWNlcyB0aGF0IHJlbmRlciB0aGVtOyB0aGUgZ3JhbnQvbGlmZWN5Y2xlIHN1YnN0cmF0ZSBpdCBjb21wb3NlcyBvdmVyIChEMS9ENy9EOCkgaXMgbm90LlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIlxcbsK3IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiQ3JlYXRlZDpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgMjAyNi0wOC0yNyDCtyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlVwZGF0ZWQ6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIDIwMjYtMDgtMjcgKHJvYWRtYXAgUjMtMjI5KVwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuYmxvY2txdW90ZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGlzIGRvY3VtZW50IGlzIHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInNpbmdsZSBpbXBsZW1lbnRhdGlvbi1zdGF0dXMgc291cmNlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGZvclxcblwifTxfY29tcG9uZW50cy5hIGhyZWY9XCIuLi9zcGVjcy9DT01QT1NJVEVfQ0FQQUJJTElUWV9UT1BPTE9HWV9TUEVDLm1kXCI+PF9jb21wb25lbnRzLmNvZGU+e1wic3BlY3MvQ09NUE9TSVRFX0NBUEFCSUxJVFlfVE9QT0xPR1lfU1BFQy5tZFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLmE+e1wiJ3NcXG5ENiBoYWxmLiBXaGVyZSB0aGUgc3BlYyBhbmQgdGhpcyBmaWxlIGRpc2FncmVlLCB0aGlzIGZpbGUgZ292ZXJucy5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cImJ1aWx0LXNpdGUtbWFpbnNyY3JlZ2lzdHJ5Y29tcG9zaXRlY29uc2VudHRzXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJidWlsdC1zaXRlLW1haW5zcmNyZWdpc3RyeWNvbXBvc2l0ZWNvbnNlbnR0c1wiIC8+e1wiQnVpbHQg4oCUIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNpdGUtbWFpbi9zcmMvcmVnaXN0cnkvY29tcG9zaXRlQ29uc2VudC50c1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy50YWJsZT48X2NvbXBvbmVudHMudGhlYWQ+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50aD57XCJFeGl0IGNyaXRlcmlvblwifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIlN0YXRlXCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGg+e1wiSG93IGl0IGlzIHByb3ZlblwifTwvX2NvbXBvbmVudHMudGg+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50Ym9keT48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIlJ1bi1tb2RlLWZpcnN0OiBhIHN0YXRpYyBkb2N1bWVudCByYWlzZXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ6ZXJvXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHBvd2VyYm94XCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wi4pyFXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wicGxhbkNvbXBvc2l0ZUNvbnNlbnRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHJldHVybnMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wie3N0ZXBzOiBbXSwgc2lsZW50OiB0cnVlfVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgd2hlbiBubyBtZW1iZXIgcmVxdWVzdHMgYW55dGhpbmcgdW5ncmFudGVkOyBhc3NlcnRlZCBmb3IgdGhlIHJlcG9ydC12aWV3ICsgc3RhcnZlZC1lbmdpbmUgcGFpclwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIlVuLWJ1bmRsZWQgZWxldmF0ZWQgbGluZSAoVFMtNWIpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wi4pyFXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wib25lIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkNvbnNlbnRMaW5lXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBwZXIgY2FwYWJpbGl0eSwgZWFjaCBmbGFnZ2VkIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNlcGFyYXRlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjsgYSBjb25uZWN0b3IgZ2V0cyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm9uZSBzdGVwIHBlciBmZWVkXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBzbyB0aHJlZSBmZWVkcyBhcmUgdGhyZWUgZGVjaXNpb25zXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiRGVza3RvcCBhbmQgbW9iaWxlIGFzayB0aGUgc2FtZSBxdWVzdGlvbnNcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCLinIVcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJ0aGUgcGxhbiBpcyBmb3JtLWZhY3RvciBpbmRlcGVuZGVudCBieSBjb25zdHJ1Y3Rpb24g4oCUIHRoZXJlIGlzIG5vIHBlci1mb3JtLWZhY3RvciBicmFuY2ggdG8gZHJpZnRcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJUaWVyIGJhZGdlIGhvc3QtZHJhd24sIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibm90XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGFwcC1lbWl0dGFibGUgKEgyKVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIuKchVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcImhvc3RCYWRnZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcmVhZHMgb25seSB0aGUgaG9zdC1kZXJpdmVkIFwifTxfY29tcG9uZW50cy5jb2RlPntcInRydXN0TW9kZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCI7IGEgbWFuaWZlc3QgY2FycnlpbmcgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYmFkZ2VcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcInRpZXJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcInZlcmlmaWVkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpcyBhc3NlcnRlZCB0byBiZSBpZ25vcmVkLCBhbmQgdGhlIGFwcCdzIFwifTxfY29tcG9uZW50cy5jb2RlPntcImxhYmVsXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBzdGF5cyB0ZXh0IG5leHQgdG8gYW4gdW5jaGFuZ2VkIGJhZGdlXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiQWdncmVnYXRlIHJlYWNoIHZpZXcgc2hvd3MgdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibmV3IHRvdGFsXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBub3QgdGhlIGRlbHRhIChSQi02KVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIuKchVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcImFnZ3JlZ2F0ZVJlYWNoXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBkZS1kdXBsaWNhdGVzIGFjcm9zcyBleGlzdGluZyBhbmQgaW5jb21pbmcgc291cmNlczsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiXFxcIjQgc291cmNlcyDCtyAyIGVsZXZhdGVkXFxcIlwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJNYW5pZmVzdCDihpQgbGF1bmNoLWdyYXBoIHJlY29uY2lsaWF0aW9uXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wi4pyFXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wicmVjb25jaWxlTGF1bmNoR3JhcGhcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCBhbiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInVuZGVjbGFyZWRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgbGF1bmNoIGZhaWxzIHRoZSBnYXRlOyBhIGRlY2xhcmVkLWJ1dC1ub3QtbGF1bmNoZWQgbWVtYmVyIGlzIHJlcG9ydGVkIGFuZCBkb2VzIG5vdFwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkNvbXBvc2l0ZSBpbnNwZWN0b3I6IHBlci1tZW1iZXIgc3RhdHVzLCBwZXItbWVtYmVyIHJldm9rZVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIuKchVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcImluc3BlY3RDb21wb3NpdGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCBvbmUgcm93IHBlciByZWFsbSwgZ3JhbnRzIG5ldmVyIG1lcmdlZDsgdGhlIHN0YXJ2ZWQgZW5naW5lIGlzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wic2hvd24gaG9sZGluZyBub3RoaW5nXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHJhdGhlciB0aGFuIGhpZGRlblwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRib2R5PjwvX2NvbXBvbmVudHMudGFibGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwiYnVpbHQtdGhlLXN1cmZhY2VzLXNpdGUtbWFpbjM3OFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiYnVpbHQtdGhlLXN1cmZhY2VzLXNpdGUtbWFpbjM3OFwiIC8+e1wiQnVpbHQg4oCUIHRoZSBzdXJmYWNlcyAoc2l0ZS1tYWluIzM3OClcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSBkZWNpc2lvbnMgYWJvdmUgYXJlIHJlbmRlcmVkIGJ5IHR3byBjb21wb25lbnRzLCB0ZXN0ZWQgYXMgYSBzZXBhcmF0ZSBjbGFpbSBmcm9tIHRoZSBwbGFuXFxuaXRzZWxmOiBhIGNvcnJlY3QgcGxhbiBjYW4gc3RpbGwgYmUgZHJhd24gYXMgYSBzY3JlZW4gdGhhdCBidW5kbGVzIHR3byBncmFudHMgaW50byBvbmUgcm93LlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudGFibGU+PF9jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGg+e1wiU3VyZmFjZVwifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIldoZXJlXCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGg+e1wiV2hhdCB0aGUgcmVuZGVyaW5nIGd1YXJhbnRlZXNcIn08L19jb21wb25lbnRzLnRoPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudGJvZHk+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJDb21wb3NpdGVDb25zZW50RGlhbG9nXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcInNyYy9lZGl0b3Ivc3BhY2VzL0NvbXBvc2l0ZUNvbnNlbnREaWFsb2cudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcImEgc2lsZW50IHBsYW4gcmVuZGVycyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJudWxsXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAocnVuLW1vZGUtZmlyc3QgbWFkZSBzdHJ1Y3R1cmFsLCBub3QgbGVmdCB0byBjYWxsZXJzKTsgb25lIGNhcmQgcGVyIHJlYWxtOyBhIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNlcGFyYXRlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBsaW5lIHZpc3VhbGx5IGRldGFjaGVkOyBhIGZlZWQgc3RlcCBwZXIgZmVlZDsgYW4gb3V0Ym91bmQgZmVlZCBnaXZlbiBjaHJvbWUgYW4gaW5ib3VuZCBvbmUgZG9lcyBub3RcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJDb21wb3NpdGVJbnNwZWN0b3JcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2VkaXRvci9zcGFjZXMvQ29tcG9zaXRlSW5zcGVjdG9yLnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJvbmUgcm93IHBlciByZWFsbSwgbmV2ZXIgbWVyZ2VkOyBhIHJlYWxtIGhvbGRpbmcgbm90aGluZyByZW5kZXJlZCBhcyBcXFwiQ2FuIHJlYWNoIG5vdGhpbmdcXFwiOyBwZXItbWVtYmVyIHJldm9rZSB3aG9zZSBhY2Nlc3NpYmxlIG5hbWUgY2FycmllcyB0aGUgcmVhbG1cIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50Ym9keT48L19jb21wb25lbnRzLnRhYmxlPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSBob3N0aWxlLW1hbmlmZXN0IGNhc2UgaXMgcmVuZGVyZWQgaW4gYSB0ZXN0IHJhdGhlciB0aGFuIGFyZ3VlZDogYSBtZW1iZXIgbGFiZWxsZWRcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJpbW1lZGlhdGVseS5ydW4gwrcgdmVyaWZpZWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNhcnJ5aW5nIFwifTxfY29tcG9uZW50cy5jb2RlPntcImJhZGdlOiB7dHJ1c3RNb2RlOiAnTTAnfVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcmVuZGVycyB0aGF0IGxhYmVsIGFzIHRleHRcXG5iZXNpZGUgYW4gdW5jaGFuZ2VkIFwifTxfY29tcG9uZW50cy5jb2RlPntcInVudmVyaWZpZWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGJhZGdlLCBhbmQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZmlyc3QtcGFydHlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG5ldmVyIGFwcGVhcnMgYW55d2hlcmUuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIk1vYmlsZSBpcyBvbmUgbWVtYmVyIHBlciBjYXJkIGJ5IGNvbnN0cnVjdGlvbiDigJQgdGhlIHN0ZXBzIGFyZSBhIHZlcnRpY2FsIGxpc3QsIHNvIHRoZXJlIGlzIG5vXFxuc2Vjb25kIGxheW91dCB0aGF0IGNhbiBkcmlmdCBpbnRvIGFza2luZyBkaWZmZXJlbnQgcXVlc3Rpb25zLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJub3QtYnVpbHRcIj48SGVhZGluZ0FuY2hvciBpZD1cIm5vdC1idWlsdFwiIC8+e1wiTm90IGJ1aWx0XCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMuYmxvY2txdW90ZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIjIwMjYtMDktMjUgKHJvYWRtYXAgUjMtNzY4KS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgUmVja29uZXIncyByZXBvcnQtdmlldyBlZ3Jlc3Mgd2FzIHJlbW92ZWQ6IHRoZSBidW5kbGVkXFxudXNhZ2Ugd29ya2Jvb2sgKFIzLTM0OSkgdGhhdCBoYXJkY29kZWQgYW4gYW5hbHl0aWNzIG9yaWdpbiBhbmQgZm9yY2VkIGFuIGFwcC13aWRlXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibmV0OmZldGNoXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiByZXF1ZXN0IGlzIGdvbmUgZnJvbSBhcHAgY29kZSwgbW92ZWQgdG8gaXRzIG93biBcIn08X2NvbXBvbmVudHMuY29kZT57XCJpbW1lZGlhdGVseS1ydW4vdXNhZ2Utd29ya2Jvb2tcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxucmVwbyB3aXRoIGRlY2xhcmVkIFwifTxfY29tcG9uZW50cy5jb2RlPntcImZlZWRzLyouZmVlZC5qc29uXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBmaWxlcy4gVGhlIHJlcG9ydCB2aWV3IG5vdyBob2xkcyBubyBuZXR3b3JrLCBhcyB0aGlzXFxuc3BlYydzIMKnMiByZXF1aXJlczsgdGhlIGNvbm5lY3RvciByZWFsbSB0aGF0IHJlY29ubmVjdHMgdGhvc2UgZmVlZHMgaXMgUjMtNzY5LlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08L19jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlRoZSBzdWJzdHJhdGUuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIMKnMidzIG1hdHJpeCBhc3N1bWVzIEQ3IChhIGRpc3RpbmN0IFwifTxfY29tcG9uZW50cy5jb2RlPntcImFwcEtleVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcGVyIHJlYWxtKSwgRDhcXG4ocGVyLWluc3RhbmNlIGxhdW5jaC9rZWVwLXdhcm0vdGVhcmRvd24pIGFuZCBEMSAocGVyLWluc3RhbmNlIGRlbGVnYXRpb24pLiBENyBzaGlwcGVkIGFzXFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJBQS0wMSBwcm9ncmFtIGlkZW50aXR5XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChyb2FkbWFwIFIzLTE2Mik6IGEgZGlzdGluY3QgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYXBwS2V5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBwZXIgcmVhbG0gbm93IGV4aXN0cywgc29cXG5yZWFsbSBzZXBhcmF0aW9uIGlzIG5vIGxvbmdlciBibG9ja2VkIG9uIGlkZW50aXR5LiBEOCBhbmQgRDEgYXJlIHN0aWxsIHVuYnVpbHQsIHNvIHRvZGF5XFxudGhlcmUgaXMgbm90aGluZyB0byBidWlsZCBhIHJlYWwgY29tcG9zaXRlIHBsYW4gXCJ9PF9jb21wb25lbnRzLmVtPntcImZyb21cIn08L19jb21wb25lbnRzLmVtPntcIiDigJQgdGhlIG1vZHVsZSBpcyBjb3JyZWN0IGFuZFxcbnVucmVhY2hhYmxlLCB3aGljaCBpcyB0aGUgaW50ZW5kZWQgb3JkZXIgKGVuZm9yY2VtZW50IGJlZm9yZSBhdXRob3JpdHkpIGFuZCB3b3J0aCBzdGF0aW5nXFxucGxhaW5seSByYXRoZXIgdGhhbiBpbXBseWluZyB0aGUgc3VyZmFjZSBpcyBsaXZlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJ0aGUtZXhpdC1jcml0ZXJpb24tdGhhdC1pcy1ub3QtY29kZS1hbmQtbXVzdC1ub3QtYmUtcmVwb3J0ZWQtYXMtbWV0XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJ0aGUtZXhpdC1jcml0ZXJpb24tdGhhdC1pcy1ub3QtY29kZS1hbmQtbXVzdC1ub3QtYmUtcmVwb3J0ZWQtYXMtbWV0XCIgLz57XCJUaGUgZXhpdCBjcml0ZXJpb24gdGhhdCBpcyBOT1QgY29kZSwgYW5kIG11c3Qgbm90IGJlIHJlcG9ydGVkIGFzIG1ldFwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgRTMgcmVhY2gtdmlldyBlZmZpY2FjeSBzdHVkeS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgTm93IHRoZSBpdGVtJ3MgT05MWSB1bm1ldCBleGl0IGNyaXRlcmlvbiwgYW5kIHRoZVxcbnJlYXNvbiBSMy0yMjkgc2hvdWxkIG5vdCBiZSBhcmNoaXZlZCBvbiB0aGUgc3RyZW5ndGggb2YgdGhlIHN1cmZhY2VzIGxhbmRpbmcuIMKnMi4xIGFuZCBSQi02XFxuYm90aCBtYXJrIHJlYWNoLWNvbnNlbnQgbGVnaWJpbGl0eSBhcyBhbiBvcGVuIFwifTxfY29tcG9uZW50cy5lbT57XCJlbXBpcmljYWxcIn08L19jb21wb25lbnRzLmVtPntcIiBxdWVzdGlvbjogd2hldGhlciBhIHVzZXIgcmVhZGluZyBcXFwiNCBzb3VyY2VzIMK3IDIgZWxldmF0ZWRcXFwiIHVuZGVyc3RhbmRzXFxudGhlaXIgZXhwb3N1cmUsIGFuZCB3aGV0aGVyIGFuIG91dGJvdW5kLWZlZWQgbGluZSBpcyByZWFkIGFzIG91dGJvdW5kLiBUaGF0IGlzIGEgYmVoYXZpb3JhbFxcbnN0dWR5LCBpdCBnYXRlcyBNMyBzaGFyaW5nLCBhbmQgbm8gdW5pdCB0ZXN0IHN1YnN0aXR1dGVzIGZvciBpdC4gVGhlIHRlc3RzIGFib3ZlIHByb3ZlIHRoZVxcbnN1cmZhY2UgXCJ9PF9jb21wb25lbnRzLmVtPntcImNvbXB1dGVzXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgdGhlIHJpZ2h0IHRoaW5nOyB0aGV5IHNheSBub3RoaW5nIGFib3V0IHdoZXRoZXIgaXQgXCJ9PF9jb21wb25lbnRzLmVtPntcImNvbW11bmljYXRlc1wifTwvX2NvbXBvbmVudHMuZW0+e1wiIGl0LFxcbmFuZCBhIGdyZWVuIHN1aXRlIG11c3Qgbm90IGJlIHJlYWQgYXMgaWYgdGhleSBkaWQuXCJ9PC9fY29tcG9uZW50cy5wPjwvPjtcbn1cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE1EWENvbnRlbnQocHJvcHMgPSB7fSkge1xuICBjb25zdCB7d3JhcHBlcjogTURYTGF5b3V0fSA9IHtcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH07XG4gIHJldHVybiBNRFhMYXlvdXQgPyA8TURYTGF5b3V0IHsuLi5wcm9wc30+PF9jcmVhdGVNZHhDb250ZW50IHsuLi5wcm9wc30gLz48L01EWExheW91dD4gOiBfY3JlYXRlTWR4Q29udGVudChwcm9wcyk7XG59XG5mdW5jdGlvbiBfbWlzc2luZ01keFJlZmVyZW5jZShpZCwgY29tcG9uZW50LCBwbGFjZSkge1xuICB0aHJvdyBuZXcgRXJyb3IoXCJFeHBlY3RlZCBcIiArIChjb21wb25lbnQgPyBcImNvbXBvbmVudFwiIDogXCJvYmplY3RcIikgKyBcIiBgXCIgKyBpZCArIFwiYCB0byBiZSBkZWZpbmVkOiB5b3UgbGlrZWx5IGZvcmdvdCB0byBpbXBvcnQsIHBhc3MsIG9yIHByb3ZpZGUgaXQuXCIgKyAocGxhY2UgPyBcIlxcbkl04oCZcyByZWZlcmVuY2VkIGluIHlvdXIgY29kZSBhdCBgXCIgKyBwbGFjZSArIFwiYCBpbiBgL2FwcC9kb2NzL3N0YXR1cy9DT01QT1NJVEVfQ0FQQUJJTElUWV9UT1BPTE9HWV9TVEFUVVMubWRgXCIgOiBcIlwiKSk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUVBLElBQUFBLFlBQUEsR0FBQUMsT0FBQTtBQUF3RixJQUFBQyxXQUFBLEdBQUFELE9BQUE7QUFGeEY7QUFDQTs7QUFFQSxTQUFTRSxpQkFBaUJBLENBQUNDLEtBQUssRUFBRTtFQUNoQyxNQUFNQyxXQUFXLEdBQUc7TUFDbEJDLENBQUMsRUFBRSxHQUFHO01BQ05DLFVBQVUsRUFBRSxZQUFZO01BQ3hCQyxJQUFJLEVBQUUsTUFBTTtNQUNaQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxDQUFDLEVBQUUsR0FBRztNQUNOQyxNQUFNLEVBQUUsUUFBUTtNQUNoQkMsS0FBSyxFQUFFLE9BQU87TUFDZEMsS0FBSyxFQUFFLE9BQU87TUFDZEMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsS0FBSyxFQUFFLE9BQU87TUFDZEMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUixHQUFHLElBQUFDLDZCQUFrQixFQUFDLENBQUM7TUFDdkIsR0FBR2xCLEtBQUssQ0FBQ21CO0lBQ1gsQ0FBQztJQUFFO01BQUNDO0lBQWEsQ0FBQyxHQUFHbkIsV0FBVztFQUNoQyxJQUFJLENBQUNtQixhQUFhLEVBQUVDLG9CQUFvQixDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUM7RUFDL0Qsb0JBQU8sSUFBQXZCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQXhCLFdBQUEsQ0FBQXlCLFFBQUE7SUFBQUMsUUFBQSxnQkFBRSxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDSyxFQUFFO01BQUNtQixFQUFFLEVBQUMsNERBQTREO01BQUFELFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBNEQsQ0FBRSxDQUFDLEVBQUMsa0VBQWtFO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDUSxDQUFDO01BQUFlLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBMkwsQ0FBcUIsQ0FBQyxFQUFDLE1BQU0sZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFVLENBQXFCLENBQUMsRUFBQyxnQkFBZ0IsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFVLENBQXFCLENBQUMsRUFBQyw4QkFBOEI7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNFLFVBQVU7TUFBQXFCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1EsQ0FBQztRQUFBZSxRQUFBLEdBQUUsdUJBQXVCLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBcUMsQ0FBcUIsQ0FBQyxFQUFDLFFBQVEsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDQyxDQUFDO1VBQUN5QixJQUFJLEVBQUMsZ0RBQWdEO1VBQUFILFFBQUEsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRyxJQUFJO1lBQUFvQixRQUFBLEVBQUU7VUFBNkMsQ0FBbUI7UUFBQyxDQUFlLENBQUMsRUFBQyx3RUFBd0U7TUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQXlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDa0IsRUFBRSxFQUFDLDhDQUE4QztNQUFBRCxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQThDLENBQUUsQ0FBQyxFQUFDLFVBQVUsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRyxJQUFJO1FBQUFvQixRQUFBLEVBQUU7TUFBNEMsQ0FBbUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1UsS0FBSztNQUFBYSxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNjLEtBQUs7UUFBQVMsUUFBQSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNlLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDYSxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFnQixDQUFpQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDYSxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFPLENBQWlCLENBQUMsbUJBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNhLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQWtCLENBQWlCLENBQUM7UUFBQSxDQUFnQjtNQUFDLENBQW1CLENBQUMsbUJBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNXLEtBQUs7UUFBQVksUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDZSxFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLEdBQUUsMkNBQTJDLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBTSxDQUFxQixDQUFDLEVBQUMsV0FBVztVQUFBLENBQWlCLENBQUMsbUJBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQUcsQ0FBaUIsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNHLElBQUk7Y0FBQW9CLFFBQUEsRUFBRTtZQUFzQixDQUFtQixDQUFDLEVBQUMsV0FBVyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNHLElBQUk7Y0FBQW9CLFFBQUEsRUFBRTtZQUEyQixDQUFtQixDQUFDLEVBQUMsaUdBQWlHO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNlLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFrQyxDQUFpQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFHLENBQWlCLENBQUMsbUJBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxHQUFFLE1BQU0sZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRyxJQUFJO2NBQUFvQixRQUFBLEVBQUU7WUFBYSxDQUFtQixDQUFDLEVBQUMsZ0NBQWdDLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBb0IsUUFBQSxFQUFFO1lBQVUsQ0FBbUIsQ0FBQyxFQUFDLHFCQUFxQixlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQW1CLENBQXFCLENBQUMsRUFBQyxzQ0FBc0M7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ2UsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQTJDLENBQWlCLENBQUMsbUJBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQUcsQ0FBaUIsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBbUcsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNlLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsR0FBRSx5QkFBeUIsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFLLENBQXFCLENBQUMsRUFBQyxxQkFBcUI7VUFBQSxDQUFpQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFHLENBQWlCLENBQUMsbUJBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRyxJQUFJO2NBQUFvQixRQUFBLEVBQUU7WUFBVyxDQUFtQixDQUFDLEVBQUMsK0JBQStCLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBb0IsUUFBQSxFQUFFO1lBQVcsQ0FBbUIsQ0FBQyxFQUFDLHdCQUF3QixlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNHLElBQUk7Y0FBQW9CLFFBQUEsRUFBRTtZQUFPLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBb0IsUUFBQSxFQUFFO1lBQU0sQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRyxJQUFJO2NBQUFvQixRQUFBLEVBQUU7WUFBVSxDQUFtQixDQUFDLEVBQUMsNENBQTRDLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBb0IsUUFBQSxFQUFFO1lBQU8sQ0FBbUIsQ0FBQyxFQUFDLHdDQUF3QztVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDZSxFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLEdBQUUsaUNBQWlDLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBVyxDQUFxQixDQUFDLEVBQUMsd0JBQXdCO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBRyxDQUFpQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBb0IsUUFBQSxFQUFFO1lBQWdCLENBQW1CLENBQUMsRUFBQyx1REFBdUQsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRyxJQUFJO2NBQUFvQixRQUFBLEVBQUU7WUFBNEIsQ0FBbUIsQ0FBQztVQUFBLENBQWdCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDZSxFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBd0MsQ0FBaUIsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBRyxDQUFpQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBb0IsUUFBQSxFQUFFO1lBQXNCLENBQW1CLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBWSxDQUFxQixDQUFDLEVBQUMscUZBQXFGO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNlLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUEyRCxDQUFpQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFHLENBQWlCLENBQUMsbUJBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRyxJQUFJO2NBQUFvQixRQUFBLEVBQUU7WUFBa0IsQ0FBbUIsQ0FBQyxFQUFDLG1FQUFtRSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQXVCLENBQXFCLENBQUMsRUFBQyxxQkFBcUI7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQztNQUFBLENBQW1CLENBQUM7SUFBQSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNNLEVBQUU7TUFBQ2tCLEVBQUUsRUFBQyxpQ0FBaUM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFpQyxDQUFFLENBQUMsRUFBQyxzQ0FBc0M7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNRLENBQUM7TUFBQWUsUUFBQSxFQUFFO0lBQTJMLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1UsS0FBSztNQUFBYSxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNjLEtBQUs7UUFBQVMsUUFBQSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNlLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDYSxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFTLENBQWlCLENBQUMsbUJBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNhLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQU8sQ0FBaUIsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBK0IsQ0FBaUIsQ0FBQztRQUFBLENBQWdCO01BQUMsQ0FBbUIsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1csS0FBSztRQUFBWSxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNlLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRyxJQUFJO2NBQUFvQixRQUFBLEVBQUU7WUFBd0IsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRyxJQUFJO2NBQUFvQixRQUFBLEVBQUU7WUFBOEMsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsR0FBRSx3QkFBd0IsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRyxJQUFJO2NBQUFvQixRQUFBLEVBQUU7WUFBTSxDQUFtQixDQUFDLEVBQUMsZ0ZBQWdGLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBb0IsUUFBQSxFQUFFO1lBQVUsQ0FBbUIsQ0FBQyxFQUFDLHNHQUFzRztVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDZSxFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBb0IsUUFBQSxFQUFFO1lBQW9CLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBb0IsUUFBQSxFQUFFO1lBQTBDLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBdUosQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUM7TUFBQSxDQUFtQixDQUFDO0lBQUEsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDUSxDQUFDO01BQUFlLFFBQUEsR0FBRSx5RkFBeUYsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRyxJQUFJO1FBQUFvQixRQUFBLEVBQUU7TUFBNEIsQ0FBbUIsQ0FBQyxFQUFDLFlBQVksZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRyxJQUFJO1FBQUFvQixRQUFBLEVBQUU7TUFBMEIsQ0FBbUIsQ0FBQyxFQUFDLG1EQUFtRCxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNHLElBQUk7UUFBQW9CLFFBQUEsRUFBRTtNQUFZLENBQW1CLENBQUMsRUFBQyxjQUFjLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBb0IsUUFBQSxFQUFFO01BQWEsQ0FBbUIsQ0FBQyxFQUFDLDBCQUEwQjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1EsQ0FBQztNQUFBZSxRQUFBLEVBQUU7SUFBOEosQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDTSxFQUFFO01BQUNrQixFQUFFLEVBQUMsV0FBVztNQUFBRCxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVcsQ0FBRSxDQUFDLEVBQUMsV0FBVztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0UsVUFBVTtNQUFBcUIsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDUSxDQUFDO1FBQUFlLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBOEIsQ0FBcUIsQ0FBQyxFQUFDLDhJQUE4SSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNHLElBQUk7VUFBQW9CLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyxtREFBbUQsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRyxJQUFJO1VBQUFvQixRQUFBLEVBQUU7UUFBZ0MsQ0FBbUIsQ0FBQyxFQUFDLHVCQUF1QixlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNHLElBQUk7VUFBQW9CLFFBQUEsRUFBRTtRQUFtQixDQUFtQixDQUFDLEVBQUMsdUlBQXVJO01BQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUF5QixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNnQixFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBZ0IsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFnQixDQUFxQixDQUFDLEVBQUMsc0NBQXNDLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBb0IsUUFBQSxFQUFFO1FBQVEsQ0FBbUIsQ0FBQyxFQUFDLDZHQUE2RyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXdCLENBQXFCLENBQUMsRUFBQyxnQ0FBZ0MsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRyxJQUFJO1VBQUFvQixRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsdUtBQXVLLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0ksRUFBRTtVQUFBbUIsUUFBQSxFQUFFO1FBQU0sQ0FBaUIsQ0FBQyxFQUFDLDRLQUE0SztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDTSxFQUFFO01BQUNrQixFQUFFLEVBQUMscUVBQXFFO01BQUFELFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBcUUsQ0FBRSxDQUFDLEVBQUMsc0VBQXNFO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDUSxDQUFDO01BQUFlLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBbUMsQ0FBcUIsQ0FBQyxFQUFDLGlNQUFpTSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNJLEVBQUU7UUFBQW1CLFFBQUEsRUFBRTtNQUFXLENBQWlCLENBQUMsRUFBQyw2UUFBNlEsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDSSxFQUFFO1FBQUFtQixRQUFBLEVBQUU7TUFBVSxDQUFpQixDQUFDLEVBQUMsc0RBQXNELGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0ksRUFBRTtRQUFBbUIsUUFBQSxFQUFFO01BQWMsQ0FBaUIsQ0FBQyxFQUFDLDBEQUEwRDtJQUFBLENBQWdCLENBQUM7RUFBQSxDQUFFLENBQUM7QUFDL3dUO0FBQ2UsU0FBU0ksVUFBVUEsQ0FBQzVCLEtBQUssR0FBRyxDQUFDLENBQUMsRUFBRTtFQUM3QyxNQUFNO0lBQUM2QixPQUFPLEVBQUVDO0VBQVMsQ0FBQyxHQUFHO0lBQzNCLEdBQUcsSUFBQVosNkJBQWtCLEVBQUMsQ0FBQztJQUN2QixHQUFHbEIsS0FBSyxDQUFDbUI7RUFDWCxDQUFDO0VBQ0QsT0FBT1csU0FBUyxnQkFBRyxJQUFBaEMsV0FBQSxDQUFBNEIsR0FBQSxFQUFDSSxTQUFTO0lBQUEsR0FBSzlCLEtBQUs7SUFBQXdCLFFBQUEsZUFBRSxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDM0IsaUJBQWlCO01BQUEsR0FBS0M7SUFBSyxDQUFHO0VBQUMsQ0FBVyxDQUFDLEdBQUdELGlCQUFpQixDQUFDQyxLQUFLLENBQUM7QUFDbEg7QUFBQytCLEVBQUEsR0FOdUJILFVBQVU7QUFPbEMsU0FBU1Asb0JBQW9CQSxDQUFDSSxFQUFFLEVBQUVPLFNBQVMsRUFBRUMsS0FBSyxFQUFFO0VBQ2xELE1BQU0sSUFBSUMsS0FBSyxDQUFDLFdBQVcsSUFBSUYsU0FBUyxHQUFHLFdBQVcsR0FBRyxRQUFRLENBQUMsR0FBRyxJQUFJLEdBQUdQLEVBQUUsR0FBRyxvRUFBb0UsSUFBSVEsS0FBSyxHQUFHLHFDQUFxQyxHQUFHQSxLQUFLLEdBQUcsaUVBQWlFLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDM1I7QUFBQyxJQUFBRixFQUFBO0FBQUFJLFlBQUEsQ0FBQUosRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}