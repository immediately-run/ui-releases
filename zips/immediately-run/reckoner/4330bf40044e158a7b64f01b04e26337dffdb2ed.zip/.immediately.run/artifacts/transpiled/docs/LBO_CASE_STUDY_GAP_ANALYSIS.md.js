var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      h3: "h3",
      hr: "hr",
      li: "li",
      ol: "ol",
      p: "p",
      strong: "strong",
      table: "table",
      tbody: "tbody",
      td: "td",
      th: "th",
      thead: "thead",
      tr: "tr",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "lbo-case-study-reckoner-vs-excel-gap-analysis",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "lbo-case-study-reckoner-vs-excel-gap-analysis"
      }), "LBO case study — Reckoner vs Excel gap analysis"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Status:"
      }), " findings report · ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Updated:"
      }), " 2026-08-27\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Artifact:"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "./case-study/caldera/",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "case-study/caldera/"
        })
      }), " · ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Proof:"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/document/calderaCaseStudy.test.ts"
      }), " (4 tests, green; full suite 363 green, lint + build clean)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The question this study was commissioned to answer: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "what gaps exist between\nwhat Reckoner is currently capable of and what finance people use Excel for —\nand is there evidence for the hypothesis that tested formulas + named values\nbeat a grid of untyped values?"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Method: take the canonical complex financial spreadsheet — a leveraged buyout\nmodel (structure per Macabacus's public LBO template: assumptions → sources &\nuses → operating model → debt schedule → returns → two-way sensitivity) — build\nit ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "twice"
      }), ": as a real Excel workbook (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "caldera_lbo.xlsx"
      }), ", 8 sheets, 963\ncells, 622 live formulas, named ranges, an iterative-calc circular sheet, a\nhand-rolled sensitivity engine, a checks sheet) and as a Reckoner document (2\nworksheets, 13 model cells, 22 test cells, 1 template), both verified against\nan independent Python implementation of the model. Every number in the Reckoner\nport matches the Python truth: schedule rows to 1e-6, IRR to 1e-10, the\nsensitivity grid's center to exact float equality."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-1",
      "data-slug": "1-the-headline-scoreboard",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-1"
      }), "1 — The headline scoreboard"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Excel feature the model uses"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Reckoner disposition"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Verdict"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Named ranges (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "entry_multiple"
            }), " → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "Assumptions!$C$4"
            }), ")"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Names are mandatory: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "params.entry_multiple"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "model.debt_schedule"
            }), ", cell ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "doc"
            }), " strings required by ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "cell()"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Better"
            }), " — intent-carrying names by construction, not opt-in discipline"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Years-across-columns, fill-right"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Rows-per-year + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "orderBy"
            }), " + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "scan"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "lag"
            }), "; dependency-correct by construction"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Equivalent"
            }), " — different orientation, no fill-handle foot-gun"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "SUM"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "SUMPRODUCT"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "MIN"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "MAX"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "IF"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "rollup"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "sum"
            }), " + plain JS ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "Math.min"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "max"
            }), "/conditionals in formulas"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Equivalent"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "INDEX"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "MATCH"
            }), " lookups"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "join"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "asofJoin"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Equivalent"
            }), " (barely needed in an LBO)"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "IRR()"
            }), " over a flows row"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Gap"
            }), " — no financial functions; hand-rolled bisection (~15 lines, exact to 1e-12, unit-testable)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Gap G2"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Circular refs + iterative calc (avg-balance interest)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Cycles rejected by the scheduler; ported as an explicit intra-cell fixed point, converged + property-tested"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Gap G1"
            }), " — expressible, architectural tax; see §3"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["What-If ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "data tables"
            }), " (two-way sensitivity)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["No construct; requires the model decomposed as a pure function, then ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "map"
            }), " over parameter pairs (25 full re-runs)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Gap G4"
            }), " — more rigorous, higher up-front cost"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Goal seek"
            }), " (breakeven exit multiple)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "No interactive solver; 1-D monotone goal seek = bisection over the model-as-function (proven)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Gap G3"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Checks column ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "IF(...,\"OK\",\"BREAK\")"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Typed test cells with mandatory kinds + review-surface verdicts (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "validated"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "pinned"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "untested"
            }), ")"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Categorically better"
            }), " — see §4"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Multi-sheet model organization"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Worksheets as namespaces; every cross-reference a dotted name"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Equivalent-to-better"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Scenario manager"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "params.*"
            }), " + manifest defaults + widget writes"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Equivalent"
            }), " (needs more, see G9)"]
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-2",
      "data-slug": "2-gaps-in-priority-order",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-2"
      }), "2 — Gaps, in priority order"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-g1",
      "data-slug": "g1-circularity-iterative-calculation-the-big-one-conceptually",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-g1"
      }), "G1 — Circularity / iterative calculation (the big one, conceptually)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Real LBO models charge interest on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "average"
      }), " balances, which is circular\n(interest → cash flow → sweep → ending balance → interest). Excel's answer is\niterative-calc mode: circular references silently converge, or silently blow up\nto zero / oscillate — a famous silent-error class that audit tooling exists\nspecifically to catch."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Reckoner's scheduler ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "rejects cycles outright"
      }), " (engine ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "cycles.test.ts"
      }), "), so\nthe port had two options and exercised both:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Avoid"
        }), " (the common simple-model convention): interest on beginning balances —\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "model.debt_schedule"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Make explicit"
        }), ": ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "model.debt_schedule_avg"
        }), " charges interest on average\nbalances via a per-year fixed-point loop ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "inside one cell's formula"
        }), ",\nconverged to 1e-12 (~8 iterations/year), with a property test asserting\nconvergence and an independent-oracle test on the answer (IRR 22.515% vs\nPython's independently-converged 22.515%)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Finding:"
      }), " circularity is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "expressible"
      }), " today but only through a convention\n(inside-one-formula fixed points). The roadmap-shaped fix is a first-class\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "converged/fixed-point cell kind"
      }), " — declare the state, the transition, the\nconvergence tolerance; the engine iterates, reports iteration counts and\nnon-convergence as a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "visible"
      }), " failure instead of Excel's silent one. The\nhonest counter-point: Excel's version is dangerous precisely because it is\ninvisible; Reckoner's explicit version is testable — the gap is ergonomic, not\ncorrectness."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-g2",
      "data-slug": "g2-no-financial-function-library",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-g2"
      }), "G2 — No financial function library"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "irr"
      }), " had to be hand-rolled (bisection; safe here because the flows have one\nsign change, so NPV(r) is monotone). The same is true of NPV, XIRR, PMT, RATE,\netc. — the entire Excel financial family. The hand-rolled version is arguably\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "better"
      }), " (exact, pure, testable, no Newton-method convergence surprises), but\nevery finance user re-derives it. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Recommendation:"
      }), " decide the financial\nfamily early — the stdlib's additive-only freeze (ARCHITECTURE_PLAN §3.2) makes\na missing family permanent until added, which is cheap now and expensive later."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-g3",
      "data-slug": "g3-goal-seek-solver",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-g3"
      }), "G3 — Goal seek / Solver"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Excel's interactive goal seek (\"set IRR to 20% by changing exit multiple\") has\nno Reckoner analogue. The port's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "model.breakeven_exit_multiple"
      }), " proves the 1-D\nmonotone case is a 10-line bisection over the model-as-function. Multi-variate\nSolver-style optimization (e.g., optimal capital structure) is a genuine gap\nwith no clean workaround. Note the precondition both share: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "the model must\nalready be a pure function"
      }), " (see G4)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-g4",
      "data-slug": "g4-data-tables-force-the-model-as-function-decomposition",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-g4"
      }), "G4 — Data tables force the model-as-function decomposition"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Excel's two-way data table is 2 minutes of clicking and re-runs one output over\na hidden parameter space. Reckoner has no such construct; the sensitivity grid\nis ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "runModel(a, hist, plan, yearPlan, {exit_multiple, tlb_turns})"
      }), " mapped over\n25 pairs — 25 ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "full, independent"
      }), " model re-runs as a first-class value you can\ntest (the monotonicity property test does)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "This exposed the deepest structural difference in the port: because a Reckoner\ncell cannot re-run other cells (no ambient registry — by design, RQ-A2), any\nparameter sweep requires the model decomposed into callable pure functions\nfirst. That is an up-front architectural tax Excel never charges — and it pays\nback as: arbitrary sweep dimensions (Excel caps at 2), composable sweeps\n(sweep the sweeps), testable sweeps, and no volatile-function recalc breakage.\nThe Excel \"before\" needed a dedicated hidden 296-cell engine sheet to fake\nthis; the Reckoner version is one cell."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-g5",
      "data-slug": "g5-no-multi-state-roll-forward-primitive-the-stdlibs-biggest-finance-miss",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-g5"
      }), "G5 — No multi-state roll-forward primitive (the stdlib's biggest finance miss)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The debt schedule — beginning balances, interest, mandatory amort, cash sweep,\nending balances, one year feeding the next — is THE most repeated structure in\nfinancial modeling (debt schedules, NWC schedules, PP&E roll-forwards, CAGR\nbridges). The stdlib's ordered family (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "cumsum"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "cummax"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "cummin"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ema"
      }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "lag"
      }), ") is single-state; a debt schedule needs a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "tuple of co-evolving\nbalances"
      }), ". The port used a custom packed-state ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ScanOp"
      }), " (returns the whole\nstate object per row, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "derive"
      }), " unpacks the columns) — expressible, but the\nexact \"hand-rolled loop the design exists to prevent\" (ADVERSARIAL_REVIEW_1\nDSL-1's phrase) in thin disguise. Also missing: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "cumprod"
      }), " (growth paths)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Recommendation:"
      }), " a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "rollforward"
      }), " primitive — declare begin-state columns, a\ntransition function, produce end-state + unpacked per-row columns. This case\nstudy is the spec-by-example for it."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-g6",
      "data-slug": "g6-test-declared-inputs-never-reach-the-test-context-bug-level",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-g6"
      }), "G6 — Test-declared inputs never reach the test context (bug-level)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "testrunner.ts"
      }), " implements ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "substituteInputs"
      }), " — a test's declared inputs\nsubstitute for the subject's same-named inputs (the holdout pattern;\nARCHITECTURE_PLAN §3.1's own first example) — but the M2 wiring\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "AsyncEngine.runTests"
      }), " → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "engineWorker.runSuites"
      }), ") resolves only the\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "subject's"
      }), " live inputs. A test declaring ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "expected: \"fixtures.expected_values\""
      }), "\ngets nothing (and a same-named-but-unknown input should fail substitution).\nConsequence in this port: the Python oracle had to be ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "inlined as constants"
      }), "\nin ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "checks.sheet.js"
      }), " instead of read from a fixture. Same-shaped holdout tests\n(fixture-swaps for the data input) would also fail to see their fixture.\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Recommendation:"
      }), " wire ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "substituteInputs"
      }), " into ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "runSuites"
      }), " — resolve test\ninputs against externals + published results, reject names the subject does\nnot declare."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-g7",
      "data-slug": "g7-invariance-relations-are-float-fragile",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-g7"
      }), "G7 — Invariance relations are float-fragile"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "permutationInvariance"
      }), " compares via strict ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "deepEqual"
      }), "; reordering rows\nreorders float summation, which can differ in the last ulp (it happened not to,\nwith this dataset's benign values — verified green, but by luck). A relation\nwhose honest purpose is \"order doesn't matter\" should tolerance-compare numeric\nleaves. Same class: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "scaleInvariance"
      }), " scales ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "every"
      }), " numeric leaf — unusable on\nany input carrying rates/percentages (margins double too), i.e., unusable on\nmost financial inputs. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Recommendation:"
      }), " numeric-tolerant deep comparison for\ninvariance relations; consider a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "linearLeaves"
      }), " option naming which fields\nscale."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-g8",
      "data-slug": "g8-number-presentation-for-finance-audiences",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-g8"
      }), "G8 — Number presentation for finance audiences"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Units (EUR m), percent formats, multiple suffixes (\"2.75x\"), accounting\nnegatives in parentheses, thousands separators: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "Kpi"
      }), " has a fixed\nformat enum (number/currency/percent); no custom units/suffix. Cosmetic but\nevery finance reader notices on first contact."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-g9",
      "data-slug": "g9-what-if-ergonomics-only-declared-params-are-live",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-g9"
      }), "G9 — What-if ergonomics: only declared params are live"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The analyst's core loop in Excel: click any assumption, type a new value,\nwatch everything recalc, undo. In the port, exactly three knobs are live\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "entry_multiple"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "exit_multiple"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "tlb_turns"
      }), " — manifest ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "params"
      }), " + Range\nwidgets, which work beautifully and are ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "dependency-traced"
      }), "). But the tax rate,\nsweep percentage, or mezzanine pricing cannot be what-iffed without editing a\nfixture — the analyst cannot even see which assumptions ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "could"
      }), " be knobs.\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Recommendation:"
      }), " a document-level affordance to expose any fixture leaf as a\nparam (or an \"assumptions are params\" convention), so the whole assumption\nsurface is live by default. This is the biggest ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "daily-friction"
      }), " gap — bigger\nthan G1, which is rare-but-deep where this is shallow-but-constant."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "notably-not-gaps",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "notably-not-gaps"
      }), "Notably NOT gaps"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Pivot tables"
        }), " — reshape via ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "groupBy"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "rollup"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "pivot"
        }), "; not needed here."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Scenario manager"
        }), " — params + literal option sets cover it."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Auditing toolbar / trace arrows"
        }), " — Reckoner's precedent view over named\ncells is structurally better than tracing ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "G44"
        }), " through 622 formulas;\nyounger, but the right shape."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "VBA/macros"
        }), " — out of scope by design (and the security model's whole\npoint)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Big data"
        }), " — LBO models are small-data/heavy-logic; feeds/streaming are\nReckoner advantages Excel cannot touch, unexercised here by design."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-3",
      "data-slug": "3-the-hypothesis-tested-formulas-named-values-vs-a-grid-of-untyped-values",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-3"
      }), "3 — The hypothesis: tested formulas + named values vs a grid of untyped values"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Evidence ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "for"
      }), ", from this port:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "Names carry intent; the grid carries coordinates."
          }), " Every reference in\nthe port is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "model.debt_schedule"
          }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "checks.sched_covenants"
          }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "params.exit_multiple"
          }), " — and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "cell()"
          }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "refuses to register"
          }), " a cell without\na one-line intent doc (\"specific enough that another agent could write\ntests from it alone\", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "stdlib/cell.ts"
          }), "). The Excel before communicates\nthrough ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "='Debt_Schedule'!G44"
          }), " plus optional cell comments plus tribal\nknowledge. Named ranges exist in Excel and went unused by convention —\noptional discipline loses to mandatory structure."]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "The checks sheet vs the test suite is not a fair fight."
          }), " The Excel\nworkbook's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "Checks"
          }), " sheet holds 25 ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "IF(...,\"OK\",\"BREAK\")"
          }), " text cells that\ngate nothing, are read by no one, and can themselves reference the wrong\ncells. The port's 22 typed test cells check the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "same"
          }), " invariants (sources =\nuses, roll-forward conservation, covenants) ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "plus"
          }), " ones the Excel model\ncannot express cheaply: the sensitivity surface is monotone in both\ndirections, the breakeven sits on the correct side of the base case, the\nfixed point actually converged, segment order does not matter. And the\nverdict taxonomy is doing real work: cells with only oracle tests read\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "pinned"
          }), " (regression evidence, not validation); the load-bearing cells read\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "validated"
          }), " because a metamorphic/property leg exists. Excel has no\nanalogue — a green Checks sheet certifies nothing."]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "Independent verification was cheap because the model is a function."
          }), " The\nPython truth and the JS port reached ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "identical floats"
          }), " (IRR\n0.22387462120837076; grid center exact-equal) through completely different\ndecompositions (columnar unrolling vs functional scan). Cross-implementation\nagreement to the last bit is only available when the computation is pure and\nexplicit — which the grid's side-effectful recalc culture actively resists."]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "The dangerous features are the invisible ones."
          }), " Iterative calc (G1) and\nvolatile data tables are where Excel models rot; the port's equivalents are\nexplicit (a loop you can read, a grid you can test). Where Excel is better,\nit is almost always ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "faster to first number"
          }), ", not ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "safer to wronger numbers"
          }), "."]
        }), "\n"]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Evidence ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "against"
      }), " (honest):"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Time-to-first-what-if."
        }), " Excel: open, type, recalc — zero ceremony. The\nport: params must be declared, fixtures authored, helpers factored. The\nmodel-as-function tax (G4) is real and up-front."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Visual scanning."
        }), " A 5-year columnar model is genuinely readable as a\ngrid; the eye traces columns. The port's tables are as readable, but the\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "authoring"
        }), " surface (JS module) is not a visual object."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Two-minute data tables."
        }), " Until Reckoner grows a sweep construct (or the\nassistant writes the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "runModel"
        }), " + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "map"
        }), " idiom instantly), Excel wins the\nquick sensitivity."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Forty years of muscle memory"
        }), " and an entire profession trained on the\ngrid — a switching cost no feature list removes."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Verdict:"
      }), " the hypothesis survives contact with the canonical complex\nfinancial model, with the strongest form being: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "Reckoner's constraints convert\nExcel's silent failure classes (invisible circularity, unreadable provenance,\nchecks-that-gate-nothing) into visible, testable structure — at the cost of\nup-front decomposition and a missing stdlib/primitives layer (G1–G5, G9) that\nis concrete, enumerable, and mostly additive."
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-4",
      "data-slug": "4-receipts",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-4"
      }), "4 — Receipts"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["Excel before: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "caldera_lbo.xlsx"
        }), " — 8 sheets, 963 cells, 622 formulas; the\ntwo-way sensitivity alone needed a hidden 296-cell engine sheet; the circular\nsheet requires iterative calc enabled; no test can live inside the file."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["Reckoner after: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "document/"
        }), " — 2 worksheets, 13 model cells, 22 test cells,\n41-line template; the same sensitivity is one cell; the same circularity is\none converged cell; the oracle agreement is machine-checked."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["Proof: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npx vitest run src/document/calderaCaseStudy.test.ts"
        }), " — loads the\ndocument through the real loader, runs it in the real SES-compartment engine,\nasserts all schedule years / returns / 25 grid cells against ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "expected.json"
        }), ",\nruns all 22 workbook tests, and asserts ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "validated"
        }), " verdicts for the ten\nload-bearing cells. Full repo suite: 363 tests green; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npm run lint"
        }), " and\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npm run build"
        }), " clean."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-5",
      "data-slug": "5-recommended-follow-ups-roadmap-shaped",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-5"
      }), "5 — Recommended follow-ups (roadmap-shaped)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "G6"
        }), " (wire ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "substituteInputs"
        }), " into ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "runSuites"
        }), ") — bug-level, small, unblocks\nthe plan's own holdout-test pattern. Do first."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "G5"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "rollforward"
        }), " + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "cumprod"
        }), " stdlib primitives) — spec-by-example is\nthis case study; additive-only freeze argues for deciding early."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "G1"
        }), " (converged fixed-point cell kind) — design spike; the explicit-loop\nconvention works until then."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "G9"
        }), " (assumptions-as-params affordance) — the daily-friction gap."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "G2"
        }), " (financial functions family: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "irr"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npv"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "xirr"
        }), " at minimum) —\nadditive-only, so schedule deliberately."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "G4"
        }), " (a sweep/sensitivity construct over model-functions) — or lean on the\nassistant authoring the idiom; measure which."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "G7"
        }), " (tolerant invariance comparisons) — small, hardening."]
      }), "\n"]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/LBO_CASE_STUDY_GAP_ANALYSIS.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiY29kZSIsImVtIiwiaDEiLCJoMiIsImgzIiwiaHIiLCJsaSIsIm9sIiwicCIsInN0cm9uZyIsInRhYmxlIiwidGJvZHkiLCJ0ZCIsInRoIiwidGhlYWQiLCJ0ciIsInVsIiwiX3Byb3ZpZGVDb21wb25lbnRzIiwiY29tcG9uZW50cyIsIkhlYWRpbmdBbmNob3IiLCJfbWlzc2luZ01keFJlZmVyZW5jZSIsImpzeHMiLCJGcmFnbWVudCIsImNoaWxkcmVuIiwiaWQiLCJqc3giLCJocmVmIiwiTURYQ29udGVudCIsIndyYXBwZXIiLCJNRFhMYXlvdXQiLCJfYyIsImNvbXBvbmVudCIsInBsYWNlIiwiRXJyb3IiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJMQk9fQ0FTRV9TVFVEWV9HQVBfQU5BTFlTSVMubWQiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgYTogXCJhXCIsXG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgZW06IFwiZW1cIixcbiAgICBoMTogXCJoMVwiLFxuICAgIGgyOiBcImgyXCIsXG4gICAgaDM6IFwiaDNcIixcbiAgICBocjogXCJoclwiLFxuICAgIGxpOiBcImxpXCIsXG4gICAgb2w6IFwib2xcIixcbiAgICBwOiBcInBcIixcbiAgICBzdHJvbmc6IFwic3Ryb25nXCIsXG4gICAgdGFibGU6IFwidGFibGVcIixcbiAgICB0Ym9keTogXCJ0Ym9keVwiLFxuICAgIHRkOiBcInRkXCIsXG4gICAgdGg6IFwidGhcIixcbiAgICB0aGVhZDogXCJ0aGVhZFwiLFxuICAgIHRyOiBcInRyXCIsXG4gICAgdWw6IFwidWxcIixcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH0sIHtIZWFkaW5nQW5jaG9yfSA9IF9jb21wb25lbnRzO1xuICBpZiAoIUhlYWRpbmdBbmNob3IpIF9taXNzaW5nTWR4UmVmZXJlbmNlKFwiSGVhZGluZ0FuY2hvclwiLCB0cnVlKTtcbiAgcmV0dXJuIDw+PF9jb21wb25lbnRzLmgxIGlkPVwibGJvLWNhc2Utc3R1ZHktcmVja29uZXItdnMtZXhjZWwtZ2FwLWFuYWx5c2lzXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJsYm8tY2FzZS1zdHVkeS1yZWNrb25lci12cy1leGNlbC1nYXAtYW5hbHlzaXNcIiAvPntcIkxCTyBjYXNlIHN0dWR5IOKAlCBSZWNrb25lciB2cyBFeGNlbCBnYXAgYW5hbHlzaXNcIn08L19jb21wb25lbnRzLmgxPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiU3RhdHVzOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBmaW5kaW5ncyByZXBvcnQgwrcgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJVcGRhdGVkOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAyMDI2LTA4LTI3XFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJBcnRpZmFjdDpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cIi4vY2FzZS1zdHVkeS9jYWxkZXJhL1wiPjxfY29tcG9uZW50cy5jb2RlPntcImNhc2Utc3R1ZHkvY2FsZGVyYS9cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5hPntcIiDCtyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlByb29mOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvZG9jdW1lbnQvY2FsZGVyYUNhc2VTdHVkeS50ZXN0LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoNCB0ZXN0cywgZ3JlZW47IGZ1bGwgc3VpdGUgMzYzIGdyZWVuLCBsaW50ICsgYnVpbGQgY2xlYW4pXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSBxdWVzdGlvbiB0aGlzIHN0dWR5IHdhcyBjb21taXNzaW9uZWQgdG8gYW5zd2VyOiBcIn08X2NvbXBvbmVudHMuZW0+e1wid2hhdCBnYXBzIGV4aXN0IGJldHdlZW5cXG53aGF0IFJlY2tvbmVyIGlzIGN1cnJlbnRseSBjYXBhYmxlIG9mIGFuZCB3aGF0IGZpbmFuY2UgcGVvcGxlIHVzZSBFeGNlbCBmb3Ig4oCUXFxuYW5kIGlzIHRoZXJlIGV2aWRlbmNlIGZvciB0aGUgaHlwb3RoZXNpcyB0aGF0IHRlc3RlZCBmb3JtdWxhcyArIG5hbWVkIHZhbHVlc1xcbmJlYXQgYSBncmlkIG9mIHVudHlwZWQgdmFsdWVzP1wifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIk1ldGhvZDogdGFrZSB0aGUgY2Fub25pY2FsIGNvbXBsZXggZmluYW5jaWFsIHNwcmVhZHNoZWV0IOKAlCBhIGxldmVyYWdlZCBidXlvdXRcXG5tb2RlbCAoc3RydWN0dXJlIHBlciBNYWNhYmFjdXMncyBwdWJsaWMgTEJPIHRlbXBsYXRlOiBhc3N1bXB0aW9ucyDihpIgc291cmNlcyAmXFxudXNlcyDihpIgb3BlcmF0aW5nIG1vZGVsIOKGkiBkZWJ0IHNjaGVkdWxlIOKGkiByZXR1cm5zIOKGkiB0d28td2F5IHNlbnNpdGl2aXR5KSDigJQgYnVpbGRcXG5pdCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInR3aWNlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiOiBhcyBhIHJlYWwgRXhjZWwgd29ya2Jvb2sgKFwifTxfY29tcG9uZW50cy5jb2RlPntcImNhbGRlcmFfbGJvLnhsc3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCA4IHNoZWV0cywgOTYzXFxuY2VsbHMsIDYyMiBsaXZlIGZvcm11bGFzLCBuYW1lZCByYW5nZXMsIGFuIGl0ZXJhdGl2ZS1jYWxjIGNpcmN1bGFyIHNoZWV0LCBhXFxuaGFuZC1yb2xsZWQgc2Vuc2l0aXZpdHkgZW5naW5lLCBhIGNoZWNrcyBzaGVldCkgYW5kIGFzIGEgUmVja29uZXIgZG9jdW1lbnQgKDJcXG53b3Jrc2hlZXRzLCAxMyBtb2RlbCBjZWxscywgMjIgdGVzdCBjZWxscywgMSB0ZW1wbGF0ZSksIGJvdGggdmVyaWZpZWQgYWdhaW5zdFxcbmFuIGluZGVwZW5kZW50IFB5dGhvbiBpbXBsZW1lbnRhdGlvbiBvZiB0aGUgbW9kZWwuIEV2ZXJ5IG51bWJlciBpbiB0aGUgUmVja29uZXJcXG5wb3J0IG1hdGNoZXMgdGhlIFB5dGhvbiB0cnV0aDogc2NoZWR1bGUgcm93cyB0byAxZS02LCBJUlIgdG8gMWUtMTAsIHRoZVxcbnNlbnNpdGl2aXR5IGdyaWQncyBjZW50ZXIgdG8gZXhhY3QgZmxvYXQgZXF1YWxpdHkuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5ociAvPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInNlYy0xXCIgZGF0YS1zbHVnPVwiMS10aGUtaGVhZGxpbmUtc2NvcmVib2FyZFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTFcIiAvPntcIjEg4oCUIFRoZSBoZWFkbGluZSBzY29yZWJvYXJkXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMudGFibGU+PF9jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGg+e1wiRXhjZWwgZmVhdHVyZSB0aGUgbW9kZWwgdXNlc1wifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIlJlY2tvbmVyIGRpc3Bvc2l0aW9uXCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGg+e1wiVmVyZGljdFwifTwvX2NvbXBvbmVudHMudGg+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50Ym9keT48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIk5hbWVkIHJhbmdlcyAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZW50cnlfbXVsdGlwbGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKGkiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJBc3N1bXB0aW9ucyEkQyQ0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIilcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJOYW1lcyBhcmUgbWFuZGF0b3J5OiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJwYXJhbXMuZW50cnlfbXVsdGlwbGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJtb2RlbC5kZWJ0X3NjaGVkdWxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgY2VsbCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJkb2NcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHN0cmluZ3MgcmVxdWlyZWQgYnkgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2VsbCgpXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQmV0dGVyXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBpbnRlbnQtY2FycnlpbmcgbmFtZXMgYnkgY29uc3RydWN0aW9uLCBub3Qgb3B0LWluIGRpc2NpcGxpbmVcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJZZWFycy1hY3Jvc3MtY29sdW1ucywgZmlsbC1yaWdodFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIlJvd3MtcGVyLXllYXIgKyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJvcmRlckJ5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiArIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNjYW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcImxhZ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCI7IGRlcGVuZGVuY3ktY29ycmVjdCBieSBjb25zdHJ1Y3Rpb25cIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkVxdWl2YWxlbnRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIGRpZmZlcmVudCBvcmllbnRhdGlvbiwgbm8gZmlsbC1oYW5kbGUgZm9vdC1ndW5cIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJTVU1cIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcIlNVTVBST0RVQ1RcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcIk1JTlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiTUFYXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJJRlwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJyb2xsdXBcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcInN1bVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKyBwbGFpbiBKUyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJNYXRoLm1pblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibWF4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9jb25kaXRpb25hbHMgaW4gZm9ybXVsYXNcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkVxdWl2YWxlbnRcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJJTkRFWFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiTUFUQ0hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGxvb2t1cHNcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJqb2luXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJhc29mSm9pblwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkVxdWl2YWxlbnRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKGJhcmVseSBuZWVkZWQgaW4gYW4gTEJPKVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcIklSUigpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBvdmVyIGEgZmxvd3Mgcm93XCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnN0cm9uZz57XCJHYXBcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIG5vIGZpbmFuY2lhbCBmdW5jdGlvbnM7IGhhbmQtcm9sbGVkIGJpc2VjdGlvbiAofjE1IGxpbmVzLCBleGFjdCB0byAxZS0xMiwgdW5pdC10ZXN0YWJsZSlcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkdhcCBHMlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkNpcmN1bGFyIHJlZnMgKyBpdGVyYXRpdmUgY2FsYyAoYXZnLWJhbGFuY2UgaW50ZXJlc3QpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiQ3ljbGVzIHJlamVjdGVkIGJ5IHRoZSBzY2hlZHVsZXI7IHBvcnRlZCBhcyBhbiBleHBsaWNpdCBpbnRyYS1jZWxsIGZpeGVkIHBvaW50LCBjb252ZXJnZWQgKyBwcm9wZXJ0eS10ZXN0ZWRcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkdhcCBHMVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgZXhwcmVzc2libGUsIGFyY2hpdGVjdHVyYWwgdGF4OyBzZWUgwqczXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiV2hhdC1JZiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImRhdGEgdGFibGVzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICh0d28td2F5IHNlbnNpdGl2aXR5KVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIk5vIGNvbnN0cnVjdDsgcmVxdWlyZXMgdGhlIG1vZGVsIGRlY29tcG9zZWQgYXMgYSBwdXJlIGZ1bmN0aW9uLCB0aGVuIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1hcFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgb3ZlciBwYXJhbWV0ZXIgcGFpcnMgKDI1IGZ1bGwgcmUtcnVucylcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkdhcCBHNFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgbW9yZSByaWdvcm91cywgaGlnaGVyIHVwLWZyb250IGNvc3RcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkdvYWwgc2Vla1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoYnJlYWtldmVuIGV4aXQgbXVsdGlwbGUpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiTm8gaW50ZXJhY3RpdmUgc29sdmVyOyAxLUQgbW9ub3RvbmUgZ29hbCBzZWVrID0gYmlzZWN0aW9uIG92ZXIgdGhlIG1vZGVsLWFzLWZ1bmN0aW9uIChwcm92ZW4pXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnN0cm9uZz57XCJHYXAgRzNcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJDaGVja3MgY29sdW1uIFwifTxfY29tcG9uZW50cy5jb2RlPntcIklGKC4uLixcXFwiT0tcXFwiLFxcXCJCUkVBS1xcXCIpXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIlR5cGVkIHRlc3QgY2VsbHMgd2l0aCBtYW5kYXRvcnkga2luZHMgKyByZXZpZXctc3VyZmFjZSB2ZXJkaWN0cyAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widmFsaWRhdGVkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJwaW5uZWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcInVudGVzdGVkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIilcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkNhdGVnb3JpY2FsbHkgYmV0dGVyXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBzZWUgwqc0XCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiTXVsdGktc2hlZXQgbW9kZWwgb3JnYW5pemF0aW9uXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiV29ya3NoZWV0cyBhcyBuYW1lc3BhY2VzOyBldmVyeSBjcm9zcy1yZWZlcmVuY2UgYSBkb3R0ZWQgbmFtZVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRXF1aXZhbGVudC10by1iZXR0ZXJcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJTY2VuYXJpbyBtYW5hZ2VyXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wicGFyYW1zLipcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICsgbWFuaWZlc3QgZGVmYXVsdHMgKyB3aWRnZXQgd3JpdGVzXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnN0cm9uZz57XCJFcXVpdmFsZW50XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChuZWVkcyBtb3JlLCBzZWUgRzkpXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGJvZHk+PC9fY29tcG9uZW50cy50YWJsZT57XCJcXG5cIn08X2NvbXBvbmVudHMuaHIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtMlwiIGRhdGEtc2x1Zz1cIjItZ2Fwcy1pbi1wcmlvcml0eS1vcmRlclwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTJcIiAvPntcIjIg4oCUIEdhcHMsIGluIHByaW9yaXR5IG9yZGVyXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCJzZWMtZzFcIiBkYXRhLXNsdWc9XCJnMS1jaXJjdWxhcml0eS1pdGVyYXRpdmUtY2FsY3VsYXRpb24tdGhlLWJpZy1vbmUtY29uY2VwdHVhbGx5XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtZzFcIiAvPntcIkcxIOKAlCBDaXJjdWxhcml0eSAvIGl0ZXJhdGl2ZSBjYWxjdWxhdGlvbiAodGhlIGJpZyBvbmUsIGNvbmNlcHR1YWxseSlcIn08L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlJlYWwgTEJPIG1vZGVscyBjaGFyZ2UgaW50ZXJlc3Qgb24gXCJ9PF9jb21wb25lbnRzLmVtPntcImF2ZXJhZ2VcIn08L19jb21wb25lbnRzLmVtPntcIiBiYWxhbmNlcywgd2hpY2ggaXMgY2lyY3VsYXJcXG4oaW50ZXJlc3Qg4oaSIGNhc2ggZmxvdyDihpIgc3dlZXAg4oaSIGVuZGluZyBiYWxhbmNlIOKGkiBpbnRlcmVzdCkuIEV4Y2VsJ3MgYW5zd2VyIGlzXFxuaXRlcmF0aXZlLWNhbGMgbW9kZTogY2lyY3VsYXIgcmVmZXJlbmNlcyBzaWxlbnRseSBjb252ZXJnZSwgb3Igc2lsZW50bHkgYmxvdyB1cFxcbnRvIHplcm8gLyBvc2NpbGxhdGUg4oCUIGEgZmFtb3VzIHNpbGVudC1lcnJvciBjbGFzcyB0aGF0IGF1ZGl0IHRvb2xpbmcgZXhpc3RzXFxuc3BlY2lmaWNhbGx5IHRvIGNhdGNoLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJSZWNrb25lcidzIHNjaGVkdWxlciBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInJlamVjdHMgY3ljbGVzIG91dHJpZ2h0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChlbmdpbmUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY3ljbGVzLnRlc3QudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSwgc29cXG50aGUgcG9ydCBoYWQgdHdvIG9wdGlvbnMgYW5kIGV4ZXJjaXNlZCBib3RoOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5lbT57XCJBdm9pZFwifTwvX2NvbXBvbmVudHMuZW0+e1wiICh0aGUgY29tbW9uIHNpbXBsZS1tb2RlbCBjb252ZW50aW9uKTogaW50ZXJlc3Qgb24gYmVnaW5uaW5nIGJhbGFuY2VzIOKAlFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcIm1vZGVsLmRlYnRfc2NoZWR1bGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5lbT57XCJNYWtlIGV4cGxpY2l0XCJ9PC9fY29tcG9uZW50cy5lbT57XCI6IFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1vZGVsLmRlYnRfc2NoZWR1bGVfYXZnXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjaGFyZ2VzIGludGVyZXN0IG9uIGF2ZXJhZ2VcXG5iYWxhbmNlcyB2aWEgYSBwZXIteWVhciBmaXhlZC1wb2ludCBsb29wIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiaW5zaWRlIG9uZSBjZWxsJ3MgZm9ybXVsYVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIixcXG5jb252ZXJnZWQgdG8gMWUtMTIgKH44IGl0ZXJhdGlvbnMveWVhciksIHdpdGggYSBwcm9wZXJ0eSB0ZXN0IGFzc2VydGluZ1xcbmNvbnZlcmdlbmNlIGFuZCBhbiBpbmRlcGVuZGVudC1vcmFjbGUgdGVzdCBvbiB0aGUgYW5zd2VyIChJUlIgMjIuNTE1JSB2c1xcblB5dGhvbidzIGluZGVwZW5kZW50bHktY29udmVyZ2VkIDIyLjUxNSUpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkZpbmRpbmc6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGNpcmN1bGFyaXR5IGlzIFwifTxfY29tcG9uZW50cy5lbT57XCJleHByZXNzaWJsZVwifTwvX2NvbXBvbmVudHMuZW0+e1wiIHRvZGF5IGJ1dCBvbmx5IHRocm91Z2ggYSBjb252ZW50aW9uXFxuKGluc2lkZS1vbmUtZm9ybXVsYSBmaXhlZCBwb2ludHMpLiBUaGUgcm9hZG1hcC1zaGFwZWQgZml4IGlzIGEgZmlyc3QtY2xhc3NcXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImNvbnZlcmdlZC9maXhlZC1wb2ludCBjZWxsIGtpbmRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIGRlY2xhcmUgdGhlIHN0YXRlLCB0aGUgdHJhbnNpdGlvbiwgdGhlXFxuY29udmVyZ2VuY2UgdG9sZXJhbmNlOyB0aGUgZW5naW5lIGl0ZXJhdGVzLCByZXBvcnRzIGl0ZXJhdGlvbiBjb3VudHMgYW5kXFxubm9uLWNvbnZlcmdlbmNlIGFzIGEgXCJ9PF9jb21wb25lbnRzLmVtPntcInZpc2libGVcIn08L19jb21wb25lbnRzLmVtPntcIiBmYWlsdXJlIGluc3RlYWQgb2YgRXhjZWwncyBzaWxlbnQgb25lLiBUaGVcXG5ob25lc3QgY291bnRlci1wb2ludDogRXhjZWwncyB2ZXJzaW9uIGlzIGRhbmdlcm91cyBwcmVjaXNlbHkgYmVjYXVzZSBpdCBpc1xcbmludmlzaWJsZTsgUmVja29uZXIncyBleHBsaWNpdCB2ZXJzaW9uIGlzIHRlc3RhYmxlIOKAlCB0aGUgZ2FwIGlzIGVyZ29ub21pYywgbm90XFxuY29ycmVjdG5lc3MuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cInNlYy1nMlwiIGRhdGEtc2x1Zz1cImcyLW5vLWZpbmFuY2lhbC1mdW5jdGlvbi1saWJyYXJ5XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtZzJcIiAvPntcIkcyIOKAlCBObyBmaW5hbmNpYWwgZnVuY3Rpb24gbGlicmFyeVwifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLmNvZGU+e1wiaXJyXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBoYWQgdG8gYmUgaGFuZC1yb2xsZWQgKGJpc2VjdGlvbjsgc2FmZSBoZXJlIGJlY2F1c2UgdGhlIGZsb3dzIGhhdmUgb25lXFxuc2lnbiBjaGFuZ2UsIHNvIE5QVihyKSBpcyBtb25vdG9uZSkuIFRoZSBzYW1lIGlzIHRydWUgb2YgTlBWLCBYSVJSLCBQTVQsIFJBVEUsXFxuZXRjLiDigJQgdGhlIGVudGlyZSBFeGNlbCBmaW5hbmNpYWwgZmFtaWx5LiBUaGUgaGFuZC1yb2xsZWQgdmVyc2lvbiBpcyBhcmd1YWJseVxcblwifTxfY29tcG9uZW50cy5lbT57XCJiZXR0ZXJcIn08L19jb21wb25lbnRzLmVtPntcIiAoZXhhY3QsIHB1cmUsIHRlc3RhYmxlLCBubyBOZXd0b24tbWV0aG9kIGNvbnZlcmdlbmNlIHN1cnByaXNlcyksIGJ1dFxcbmV2ZXJ5IGZpbmFuY2UgdXNlciByZS1kZXJpdmVzIGl0LiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlJlY29tbWVuZGF0aW9uOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBkZWNpZGUgdGhlIGZpbmFuY2lhbFxcbmZhbWlseSBlYXJseSDigJQgdGhlIHN0ZGxpYidzIGFkZGl0aXZlLW9ubHkgZnJlZXplIChBUkNISVRFQ1RVUkVfUExBTiDCpzMuMikgbWFrZXNcXG5hIG1pc3NpbmcgZmFtaWx5IHBlcm1hbmVudCB1bnRpbCBhZGRlZCwgd2hpY2ggaXMgY2hlYXAgbm93IGFuZCBleHBlbnNpdmUgbGF0ZXIuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cInNlYy1nM1wiIGRhdGEtc2x1Zz1cImczLWdvYWwtc2Vlay1zb2x2ZXJcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy1nM1wiIC8+e1wiRzMg4oCUIEdvYWwgc2VlayAvIFNvbHZlclwifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiRXhjZWwncyBpbnRlcmFjdGl2ZSBnb2FsIHNlZWsgKFxcXCJzZXQgSVJSIHRvIDIwJSBieSBjaGFuZ2luZyBleGl0IG11bHRpcGxlXFxcIikgaGFzXFxubm8gUmVja29uZXIgYW5hbG9ndWUuIFRoZSBwb3J0J3MgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibW9kZWwuYnJlYWtldmVuX2V4aXRfbXVsdGlwbGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHByb3ZlcyB0aGUgMS1EXFxubW9ub3RvbmUgY2FzZSBpcyBhIDEwLWxpbmUgYmlzZWN0aW9uIG92ZXIgdGhlIG1vZGVsLWFzLWZ1bmN0aW9uLiBNdWx0aS12YXJpYXRlXFxuU29sdmVyLXN0eWxlIG9wdGltaXphdGlvbiAoZS5nLiwgb3B0aW1hbCBjYXBpdGFsIHN0cnVjdHVyZSkgaXMgYSBnZW51aW5lIGdhcFxcbndpdGggbm8gY2xlYW4gd29ya2Fyb3VuZC4gTm90ZSB0aGUgcHJlY29uZGl0aW9uIGJvdGggc2hhcmU6IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1widGhlIG1vZGVsIG11c3RcXG5hbHJlYWR5IGJlIGEgcHVyZSBmdW5jdGlvblwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoc2VlIEc0KS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwic2VjLWc0XCIgZGF0YS1zbHVnPVwiZzQtZGF0YS10YWJsZXMtZm9yY2UtdGhlLW1vZGVsLWFzLWZ1bmN0aW9uLWRlY29tcG9zaXRpb25cIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy1nNFwiIC8+e1wiRzQg4oCUIERhdGEgdGFibGVzIGZvcmNlIHRoZSBtb2RlbC1hcy1mdW5jdGlvbiBkZWNvbXBvc2l0aW9uXCJ9PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJFeGNlbCdzIHR3by13YXkgZGF0YSB0YWJsZSBpcyAyIG1pbnV0ZXMgb2YgY2xpY2tpbmcgYW5kIHJlLXJ1bnMgb25lIG91dHB1dCBvdmVyXFxuYSBoaWRkZW4gcGFyYW1ldGVyIHNwYWNlLiBSZWNrb25lciBoYXMgbm8gc3VjaCBjb25zdHJ1Y3Q7IHRoZSBzZW5zaXRpdml0eSBncmlkXFxuaXMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicnVuTW9kZWwoYSwgaGlzdCwgcGxhbiwgeWVhclBsYW4sIHtleGl0X211bHRpcGxlLCB0bGJfdHVybnN9KVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgbWFwcGVkIG92ZXJcXG4yNSBwYWlycyDigJQgMjUgXCJ9PF9jb21wb25lbnRzLmVtPntcImZ1bGwsIGluZGVwZW5kZW50XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgbW9kZWwgcmUtcnVucyBhcyBhIGZpcnN0LWNsYXNzIHZhbHVlIHlvdSBjYW5cXG50ZXN0ICh0aGUgbW9ub3RvbmljaXR5IHByb3BlcnR5IHRlc3QgZG9lcykuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoaXMgZXhwb3NlZCB0aGUgZGVlcGVzdCBzdHJ1Y3R1cmFsIGRpZmZlcmVuY2UgaW4gdGhlIHBvcnQ6IGJlY2F1c2UgYSBSZWNrb25lclxcbmNlbGwgY2Fubm90IHJlLXJ1biBvdGhlciBjZWxscyAobm8gYW1iaWVudCByZWdpc3RyeSDigJQgYnkgZGVzaWduLCBSUS1BMiksIGFueVxcbnBhcmFtZXRlciBzd2VlcCByZXF1aXJlcyB0aGUgbW9kZWwgZGVjb21wb3NlZCBpbnRvIGNhbGxhYmxlIHB1cmUgZnVuY3Rpb25zXFxuZmlyc3QuIFRoYXQgaXMgYW4gdXAtZnJvbnQgYXJjaGl0ZWN0dXJhbCB0YXggRXhjZWwgbmV2ZXIgY2hhcmdlcyDigJQgYW5kIGl0IHBheXNcXG5iYWNrIGFzOiBhcmJpdHJhcnkgc3dlZXAgZGltZW5zaW9ucyAoRXhjZWwgY2FwcyBhdCAyKSwgY29tcG9zYWJsZSBzd2VlcHNcXG4oc3dlZXAgdGhlIHN3ZWVwcyksIHRlc3RhYmxlIHN3ZWVwcywgYW5kIG5vIHZvbGF0aWxlLWZ1bmN0aW9uIHJlY2FsYyBicmVha2FnZS5cXG5UaGUgRXhjZWwgXFxcImJlZm9yZVxcXCIgbmVlZGVkIGEgZGVkaWNhdGVkIGhpZGRlbiAyOTYtY2VsbCBlbmdpbmUgc2hlZXQgdG8gZmFrZVxcbnRoaXM7IHRoZSBSZWNrb25lciB2ZXJzaW9uIGlzIG9uZSBjZWxsLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCJzZWMtZzVcIiBkYXRhLXNsdWc9XCJnNS1uby1tdWx0aS1zdGF0ZS1yb2xsLWZvcndhcmQtcHJpbWl0aXZlLXRoZS1zdGRsaWJzLWJpZ2dlc3QtZmluYW5jZS1taXNzXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtZzVcIiAvPntcIkc1IOKAlCBObyBtdWx0aS1zdGF0ZSByb2xsLWZvcndhcmQgcHJpbWl0aXZlICh0aGUgc3RkbGliJ3MgYmlnZ2VzdCBmaW5hbmNlIG1pc3MpXCJ9PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgZGVidCBzY2hlZHVsZSDigJQgYmVnaW5uaW5nIGJhbGFuY2VzLCBpbnRlcmVzdCwgbWFuZGF0b3J5IGFtb3J0LCBjYXNoIHN3ZWVwLFxcbmVuZGluZyBiYWxhbmNlcywgb25lIHllYXIgZmVlZGluZyB0aGUgbmV4dCDigJQgaXMgVEhFIG1vc3QgcmVwZWF0ZWQgc3RydWN0dXJlIGluXFxuZmluYW5jaWFsIG1vZGVsaW5nIChkZWJ0IHNjaGVkdWxlcywgTldDIHNjaGVkdWxlcywgUFAmRSByb2xsLWZvcndhcmRzLCBDQUdSXFxuYnJpZGdlcykuIFRoZSBzdGRsaWIncyBvcmRlcmVkIGZhbWlseSAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY3Vtc3VtXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY3VtbWF4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY3VtbWluXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZW1hXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIixcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJsYWdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSBpcyBzaW5nbGUtc3RhdGU7IGEgZGVidCBzY2hlZHVsZSBuZWVkcyBhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1widHVwbGUgb2YgY28tZXZvbHZpbmdcXG5iYWxhbmNlc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIi4gVGhlIHBvcnQgdXNlZCBhIGN1c3RvbSBwYWNrZWQtc3RhdGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiU2Nhbk9wXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAocmV0dXJucyB0aGUgd2hvbGVcXG5zdGF0ZSBvYmplY3QgcGVyIHJvdywgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZGVyaXZlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB1bnBhY2tzIHRoZSBjb2x1bW5zKSDigJQgZXhwcmVzc2libGUsIGJ1dCB0aGVcXG5leGFjdCBcXFwiaGFuZC1yb2xsZWQgbG9vcCB0aGUgZGVzaWduIGV4aXN0cyB0byBwcmV2ZW50XFxcIiAoQURWRVJTQVJJQUxfUkVWSUVXXzFcXG5EU0wtMSdzIHBocmFzZSkgaW4gdGhpbiBkaXNndWlzZS4gQWxzbyBtaXNzaW5nOiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjdW1wcm9kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoZ3Jvd3RoIHBhdGhzKS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJSZWNvbW1lbmRhdGlvbjpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyb2xsZm9yd2FyZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcHJpbWl0aXZlIOKAlCBkZWNsYXJlIGJlZ2luLXN0YXRlIGNvbHVtbnMsIGFcXG50cmFuc2l0aW9uIGZ1bmN0aW9uLCBwcm9kdWNlIGVuZC1zdGF0ZSArIHVucGFja2VkIHBlci1yb3cgY29sdW1ucy4gVGhpcyBjYXNlXFxuc3R1ZHkgaXMgdGhlIHNwZWMtYnktZXhhbXBsZSBmb3IgaXQuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cInNlYy1nNlwiIGRhdGEtc2x1Zz1cImc2LXRlc3QtZGVjbGFyZWQtaW5wdXRzLW5ldmVyLXJlYWNoLXRoZS10ZXN0LWNvbnRleHQtYnVnLWxldmVsXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtZzZcIiAvPntcIkc2IOKAlCBUZXN0LWRlY2xhcmVkIGlucHV0cyBuZXZlciByZWFjaCB0aGUgdGVzdCBjb250ZXh0IChidWctbGV2ZWwpXCJ9PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuY29kZT57XCJ0ZXN0cnVubmVyLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpbXBsZW1lbnRzIFwifTxfY29tcG9uZW50cy5jb2RlPntcInN1YnN0aXR1dGVJbnB1dHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCBhIHRlc3QncyBkZWNsYXJlZCBpbnB1dHNcXG5zdWJzdGl0dXRlIGZvciB0aGUgc3ViamVjdCdzIHNhbWUtbmFtZWQgaW5wdXRzICh0aGUgaG9sZG91dCBwYXR0ZXJuO1xcbkFSQ0hJVEVDVFVSRV9QTEFOIMKnMy4xJ3Mgb3duIGZpcnN0IGV4YW1wbGUpIOKAlCBidXQgdGhlIE0yIHdpcmluZ1xcbihcIn08X2NvbXBvbmVudHMuY29kZT57XCJBc3luY0VuZ2luZS5ydW5UZXN0c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oaSIFwifTxfY29tcG9uZW50cy5jb2RlPntcImVuZ2luZVdvcmtlci5ydW5TdWl0ZXNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSByZXNvbHZlcyBvbmx5IHRoZVxcblwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wic3ViamVjdCdzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGxpdmUgaW5wdXRzLiBBIHRlc3QgZGVjbGFyaW5nIFwifTxfY29tcG9uZW50cy5jb2RlPntcImV4cGVjdGVkOiBcXFwiZml4dHVyZXMuZXhwZWN0ZWRfdmFsdWVzXFxcIlwifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG5nZXRzIG5vdGhpbmcgKGFuZCBhIHNhbWUtbmFtZWQtYnV0LXVua25vd24gaW5wdXQgc2hvdWxkIGZhaWwgc3Vic3RpdHV0aW9uKS5cXG5Db25zZXF1ZW5jZSBpbiB0aGlzIHBvcnQ6IHRoZSBQeXRob24gb3JhY2xlIGhhZCB0byBiZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImlubGluZWQgYXMgY29uc3RhbnRzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiXFxuaW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2hlY2tzLnNoZWV0LmpzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpbnN0ZWFkIG9mIHJlYWQgZnJvbSBhIGZpeHR1cmUuIFNhbWUtc2hhcGVkIGhvbGRvdXQgdGVzdHNcXG4oZml4dHVyZS1zd2FwcyBmb3IgdGhlIGRhdGEgaW5wdXQpIHdvdWxkIGFsc28gZmFpbCB0byBzZWUgdGhlaXIgZml4dHVyZS5cXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlJlY29tbWVuZGF0aW9uOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB3aXJlIFwifTxfY29tcG9uZW50cy5jb2RlPntcInN1YnN0aXR1dGVJbnB1dHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGludG8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicnVuU3VpdGVzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgcmVzb2x2ZSB0ZXN0XFxuaW5wdXRzIGFnYWluc3QgZXh0ZXJuYWxzICsgcHVibGlzaGVkIHJlc3VsdHMsIHJlamVjdCBuYW1lcyB0aGUgc3ViamVjdCBkb2VzXFxubm90IGRlY2xhcmUuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cInNlYy1nN1wiIGRhdGEtc2x1Zz1cImc3LWludmFyaWFuY2UtcmVsYXRpb25zLWFyZS1mbG9hdC1mcmFnaWxlXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtZzdcIiAvPntcIkc3IOKAlCBJbnZhcmlhbmNlIHJlbGF0aW9ucyBhcmUgZmxvYXQtZnJhZ2lsZVwifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLmNvZGU+e1wicGVybXV0YXRpb25JbnZhcmlhbmNlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjb21wYXJlcyB2aWEgc3RyaWN0IFwifTxfY29tcG9uZW50cy5jb2RlPntcImRlZXBFcXVhbFwifTwvX2NvbXBvbmVudHMuY29kZT57XCI7IHJlb3JkZXJpbmcgcm93c1xcbnJlb3JkZXJzIGZsb2F0IHN1bW1hdGlvbiwgd2hpY2ggY2FuIGRpZmZlciBpbiB0aGUgbGFzdCB1bHAgKGl0IGhhcHBlbmVkIG5vdCB0byxcXG53aXRoIHRoaXMgZGF0YXNldCdzIGJlbmlnbiB2YWx1ZXMg4oCUIHZlcmlmaWVkIGdyZWVuLCBidXQgYnkgbHVjaykuIEEgcmVsYXRpb25cXG53aG9zZSBob25lc3QgcHVycG9zZSBpcyBcXFwib3JkZXIgZG9lc24ndCBtYXR0ZXJcXFwiIHNob3VsZCB0b2xlcmFuY2UtY29tcGFyZSBudW1lcmljXFxubGVhdmVzLiBTYW1lIGNsYXNzOiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzY2FsZUludmFyaWFuY2VcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHNjYWxlcyBcIn08X2NvbXBvbmVudHMuZW0+e1wiZXZlcnlcIn08L19jb21wb25lbnRzLmVtPntcIiBudW1lcmljIGxlYWYg4oCUIHVudXNhYmxlIG9uXFxuYW55IGlucHV0IGNhcnJ5aW5nIHJhdGVzL3BlcmNlbnRhZ2VzIChtYXJnaW5zIGRvdWJsZSB0b28pLCBpLmUuLCB1bnVzYWJsZSBvblxcbm1vc3QgZmluYW5jaWFsIGlucHV0cy4gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJSZWNvbW1lbmRhdGlvbjpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgbnVtZXJpYy10b2xlcmFudCBkZWVwIGNvbXBhcmlzb24gZm9yXFxuaW52YXJpYW5jZSByZWxhdGlvbnM7IGNvbnNpZGVyIGEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibGluZWFyTGVhdmVzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBvcHRpb24gbmFtaW5nIHdoaWNoIGZpZWxkc1xcbnNjYWxlLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCJzZWMtZzhcIiBkYXRhLXNsdWc9XCJnOC1udW1iZXItcHJlc2VudGF0aW9uLWZvci1maW5hbmNlLWF1ZGllbmNlc1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLWc4XCIgLz57XCJHOCDigJQgTnVtYmVyIHByZXNlbnRhdGlvbiBmb3IgZmluYW5jZSBhdWRpZW5jZXNcIn08L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlVuaXRzIChFVVIgbSksIHBlcmNlbnQgZm9ybWF0cywgbXVsdGlwbGUgc3VmZml4ZXMgKFxcXCIyLjc1eFxcXCIpLCBhY2NvdW50aW5nXFxubmVnYXRpdmVzIGluIHBhcmVudGhlc2VzLCB0aG91c2FuZHMgc2VwYXJhdG9yczogXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiS3BpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBoYXMgYSBmaXhlZFxcbmZvcm1hdCBlbnVtIChudW1iZXIvY3VycmVuY3kvcGVyY2VudCk7IG5vIGN1c3RvbSB1bml0cy9zdWZmaXguIENvc21ldGljIGJ1dFxcbmV2ZXJ5IGZpbmFuY2UgcmVhZGVyIG5vdGljZXMgb24gZmlyc3QgY29udGFjdC5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwic2VjLWc5XCIgZGF0YS1zbHVnPVwiZzktd2hhdC1pZi1lcmdvbm9taWNzLW9ubHktZGVjbGFyZWQtcGFyYW1zLWFyZS1saXZlXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtZzlcIiAvPntcIkc5IOKAlCBXaGF0LWlmIGVyZ29ub21pY3M6IG9ubHkgZGVjbGFyZWQgcGFyYW1zIGFyZSBsaXZlXCJ9PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgYW5hbHlzdCdzIGNvcmUgbG9vcCBpbiBFeGNlbDogY2xpY2sgYW55IGFzc3VtcHRpb24sIHR5cGUgYSBuZXcgdmFsdWUsXFxud2F0Y2ggZXZlcnl0aGluZyByZWNhbGMsIHVuZG8uIEluIHRoZSBwb3J0LCBleGFjdGx5IHRocmVlIGtub2JzIGFyZSBsaXZlXFxuKFwifTxfY29tcG9uZW50cy5jb2RlPntcImVudHJ5X211bHRpcGxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZXhpdF9tdWx0aXBsZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcInRsYl90dXJuc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIG1hbmlmZXN0IFwifTxfY29tcG9uZW50cy5jb2RlPntcInBhcmFtc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKyBSYW5nZVxcbndpZGdldHMsIHdoaWNoIHdvcmsgYmVhdXRpZnVsbHkgYW5kIGFyZSBcIn08X2NvbXBvbmVudHMuZW0+e1wiZGVwZW5kZW5jeS10cmFjZWRcIn08L19jb21wb25lbnRzLmVtPntcIikuIEJ1dCB0aGUgdGF4IHJhdGUsXFxuc3dlZXAgcGVyY2VudGFnZSwgb3IgbWV6emFuaW5lIHByaWNpbmcgY2Fubm90IGJlIHdoYXQtaWZmZWQgd2l0aG91dCBlZGl0aW5nIGFcXG5maXh0dXJlIOKAlCB0aGUgYW5hbHlzdCBjYW5ub3QgZXZlbiBzZWUgd2hpY2ggYXNzdW1wdGlvbnMgXCJ9PF9jb21wb25lbnRzLmVtPntcImNvdWxkXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgYmUga25vYnMuXFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJSZWNvbW1lbmRhdGlvbjpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYSBkb2N1bWVudC1sZXZlbCBhZmZvcmRhbmNlIHRvIGV4cG9zZSBhbnkgZml4dHVyZSBsZWFmIGFzIGFcXG5wYXJhbSAob3IgYW4gXFxcImFzc3VtcHRpb25zIGFyZSBwYXJhbXNcXFwiIGNvbnZlbnRpb24pLCBzbyB0aGUgd2hvbGUgYXNzdW1wdGlvblxcbnN1cmZhY2UgaXMgbGl2ZSBieSBkZWZhdWx0LiBUaGlzIGlzIHRoZSBiaWdnZXN0IFwifTxfY29tcG9uZW50cy5lbT57XCJkYWlseS1mcmljdGlvblwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGdhcCDigJQgYmlnZ2VyXFxudGhhbiBHMSwgd2hpY2ggaXMgcmFyZS1idXQtZGVlcCB3aGVyZSB0aGlzIGlzIHNoYWxsb3ctYnV0LWNvbnN0YW50LlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCJub3RhYmx5LW5vdC1nYXBzXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJub3RhYmx5LW5vdC1nYXBzXCIgLz57XCJOb3RhYmx5IE5PVCBnYXBzXCJ9PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUGl2b3QgdGFibGVzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCByZXNoYXBlIHZpYSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJncm91cEJ5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJyb2xsdXBcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcInBpdm90XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjsgbm90IG5lZWRlZCBoZXJlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiU2NlbmFyaW8gbWFuYWdlclwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgcGFyYW1zICsgbGl0ZXJhbCBvcHRpb24gc2V0cyBjb3ZlciBpdC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkF1ZGl0aW5nIHRvb2xiYXIgLyB0cmFjZSBhcnJvd3NcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIFJlY2tvbmVyJ3MgcHJlY2VkZW50IHZpZXcgb3ZlciBuYW1lZFxcbmNlbGxzIGlzIHN0cnVjdHVyYWxseSBiZXR0ZXIgdGhhbiB0cmFjaW5nIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkc0NFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdGhyb3VnaCA2MjIgZm9ybXVsYXM7XFxueW91bmdlciwgYnV0IHRoZSByaWdodCBzaGFwZS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlZCQS9tYWNyb3NcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIG91dCBvZiBzY29wZSBieSBkZXNpZ24gKGFuZCB0aGUgc2VjdXJpdHkgbW9kZWwncyB3aG9sZVxcbnBvaW50KS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkJpZyBkYXRhXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBMQk8gbW9kZWxzIGFyZSBzbWFsbC1kYXRhL2hlYXZ5LWxvZ2ljOyBmZWVkcy9zdHJlYW1pbmcgYXJlXFxuUmVja29uZXIgYWR2YW50YWdlcyBFeGNlbCBjYW5ub3QgdG91Y2gsIHVuZXhlcmNpc2VkIGhlcmUgYnkgZGVzaWduLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaHIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtM1wiIGRhdGEtc2x1Zz1cIjMtdGhlLWh5cG90aGVzaXMtdGVzdGVkLWZvcm11bGFzLW5hbWVkLXZhbHVlcy12cy1hLWdyaWQtb2YtdW50eXBlZC12YWx1ZXNcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy0zXCIgLz57XCIzIOKAlCBUaGUgaHlwb3RoZXNpczogdGVzdGVkIGZvcm11bGFzICsgbmFtZWQgdmFsdWVzIHZzIGEgZ3JpZCBvZiB1bnR5cGVkIHZhbHVlc1wifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiRXZpZGVuY2UgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJmb3JcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIsIGZyb20gdGhpcyBwb3J0OlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMub2w+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiTmFtZXMgY2FycnkgaW50ZW50OyB0aGUgZ3JpZCBjYXJyaWVzIGNvb3JkaW5hdGVzLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBFdmVyeSByZWZlcmVuY2UgaW5cXG50aGUgcG9ydCBpcyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJtb2RlbC5kZWJ0X3NjaGVkdWxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2hlY2tzLnNjaGVkX2NvdmVuYW50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicGFyYW1zLmV4aXRfbXVsdGlwbGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCBhbmQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2VsbCgpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBcIn08X2NvbXBvbmVudHMuZW0+e1wicmVmdXNlcyB0byByZWdpc3RlclwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGEgY2VsbCB3aXRob3V0XFxuYSBvbmUtbGluZSBpbnRlbnQgZG9jIChcXFwic3BlY2lmaWMgZW5vdWdoIHRoYXQgYW5vdGhlciBhZ2VudCBjb3VsZCB3cml0ZVxcbnRlc3RzIGZyb20gaXQgYWxvbmVcXFwiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzdGRsaWIvY2VsbC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLiBUaGUgRXhjZWwgYmVmb3JlIGNvbW11bmljYXRlc1xcbnRocm91Z2ggXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiPSdEZWJ0X1NjaGVkdWxlJyFHNDRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHBsdXMgb3B0aW9uYWwgY2VsbCBjb21tZW50cyBwbHVzIHRyaWJhbFxcbmtub3dsZWRnZS4gTmFtZWQgcmFuZ2VzIGV4aXN0IGluIEV4Y2VsIGFuZCB3ZW50IHVudXNlZCBieSBjb252ZW50aW9uIOKAlFxcbm9wdGlvbmFsIGRpc2NpcGxpbmUgbG9zZXMgdG8gbWFuZGF0b3J5IHN0cnVjdHVyZS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgY2hlY2tzIHNoZWV0IHZzIHRoZSB0ZXN0IHN1aXRlIGlzIG5vdCBhIGZhaXIgZmlnaHQuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRoZSBFeGNlbFxcbndvcmtib29rJ3MgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQ2hlY2tzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBzaGVldCBob2xkcyAyNSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJJRiguLi4sXFxcIk9LXFxcIixcXFwiQlJFQUtcXFwiKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdGV4dCBjZWxscyB0aGF0XFxuZ2F0ZSBub3RoaW5nLCBhcmUgcmVhZCBieSBubyBvbmUsIGFuZCBjYW4gdGhlbXNlbHZlcyByZWZlcmVuY2UgdGhlIHdyb25nXFxuY2VsbHMuIFRoZSBwb3J0J3MgMjIgdHlwZWQgdGVzdCBjZWxscyBjaGVjayB0aGUgXCJ9PF9jb21wb25lbnRzLmVtPntcInNhbWVcIn08L19jb21wb25lbnRzLmVtPntcIiBpbnZhcmlhbnRzIChzb3VyY2VzID1cXG51c2VzLCByb2xsLWZvcndhcmQgY29uc2VydmF0aW9uLCBjb3ZlbmFudHMpIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicGx1c1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBvbmVzIHRoZSBFeGNlbCBtb2RlbFxcbmNhbm5vdCBleHByZXNzIGNoZWFwbHk6IHRoZSBzZW5zaXRpdml0eSBzdXJmYWNlIGlzIG1vbm90b25lIGluIGJvdGhcXG5kaXJlY3Rpb25zLCB0aGUgYnJlYWtldmVuIHNpdHMgb24gdGhlIGNvcnJlY3Qgc2lkZSBvZiB0aGUgYmFzZSBjYXNlLCB0aGVcXG5maXhlZCBwb2ludCBhY3R1YWxseSBjb252ZXJnZWQsIHNlZ21lbnQgb3JkZXIgZG9lcyBub3QgbWF0dGVyLiBBbmQgdGhlXFxudmVyZGljdCB0YXhvbm9teSBpcyBkb2luZyByZWFsIHdvcms6IGNlbGxzIHdpdGggb25seSBvcmFjbGUgdGVzdHMgcmVhZFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcInBpbm5lZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKHJlZ3Jlc3Npb24gZXZpZGVuY2UsIG5vdCB2YWxpZGF0aW9uKTsgdGhlIGxvYWQtYmVhcmluZyBjZWxscyByZWFkXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widmFsaWRhdGVkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBiZWNhdXNlIGEgbWV0YW1vcnBoaWMvcHJvcGVydHkgbGVnIGV4aXN0cy4gRXhjZWwgaGFzIG5vXFxuYW5hbG9ndWUg4oCUIGEgZ3JlZW4gQ2hlY2tzIHNoZWV0IGNlcnRpZmllcyBub3RoaW5nLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkluZGVwZW5kZW50IHZlcmlmaWNhdGlvbiB3YXMgY2hlYXAgYmVjYXVzZSB0aGUgbW9kZWwgaXMgYSBmdW5jdGlvbi5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhlXFxuUHl0aG9uIHRydXRoIGFuZCB0aGUgSlMgcG9ydCByZWFjaGVkIFwifTxfY29tcG9uZW50cy5lbT57XCJpZGVudGljYWwgZmxvYXRzXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgKElSUlxcbjAuMjIzODc0NjIxMjA4MzcwNzY7IGdyaWQgY2VudGVyIGV4YWN0LWVxdWFsKSB0aHJvdWdoIGNvbXBsZXRlbHkgZGlmZmVyZW50XFxuZGVjb21wb3NpdGlvbnMgKGNvbHVtbmFyIHVucm9sbGluZyB2cyBmdW5jdGlvbmFsIHNjYW4pLiBDcm9zcy1pbXBsZW1lbnRhdGlvblxcbmFncmVlbWVudCB0byB0aGUgbGFzdCBiaXQgaXMgb25seSBhdmFpbGFibGUgd2hlbiB0aGUgY29tcHV0YXRpb24gaXMgcHVyZSBhbmRcXG5leHBsaWNpdCDigJQgd2hpY2ggdGhlIGdyaWQncyBzaWRlLWVmZmVjdGZ1bCByZWNhbGMgY3VsdHVyZSBhY3RpdmVseSByZXNpc3RzLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlRoZSBkYW5nZXJvdXMgZmVhdHVyZXMgYXJlIHRoZSBpbnZpc2libGUgb25lcy5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgSXRlcmF0aXZlIGNhbGMgKEcxKSBhbmRcXG52b2xhdGlsZSBkYXRhIHRhYmxlcyBhcmUgd2hlcmUgRXhjZWwgbW9kZWxzIHJvdDsgdGhlIHBvcnQncyBlcXVpdmFsZW50cyBhcmVcXG5leHBsaWNpdCAoYSBsb29wIHlvdSBjYW4gcmVhZCwgYSBncmlkIHlvdSBjYW4gdGVzdCkuIFdoZXJlIEV4Y2VsIGlzIGJldHRlcixcXG5pdCBpcyBhbG1vc3QgYWx3YXlzIFwifTxfY29tcG9uZW50cy5lbT57XCJmYXN0ZXIgdG8gZmlyc3QgbnVtYmVyXCJ9PC9fY29tcG9uZW50cy5lbT57XCIsIG5vdCBcIn08X2NvbXBvbmVudHMuZW0+e1wic2FmZXIgdG8gd3JvbmdlciBudW1iZXJzXCJ9PC9fY29tcG9uZW50cy5lbT57XCIuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJFdmlkZW5jZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImFnYWluc3RcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKGhvbmVzdCk6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaW1lLXRvLWZpcnN0LXdoYXQtaWYuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIEV4Y2VsOiBvcGVuLCB0eXBlLCByZWNhbGMg4oCUIHplcm8gY2VyZW1vbnkuIFRoZVxcbnBvcnQ6IHBhcmFtcyBtdXN0IGJlIGRlY2xhcmVkLCBmaXh0dXJlcyBhdXRob3JlZCwgaGVscGVycyBmYWN0b3JlZC4gVGhlXFxubW9kZWwtYXMtZnVuY3Rpb24gdGF4IChHNCkgaXMgcmVhbCBhbmQgdXAtZnJvbnQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJWaXN1YWwgc2Nhbm5pbmcuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIEEgNS15ZWFyIGNvbHVtbmFyIG1vZGVsIGlzIGdlbnVpbmVseSByZWFkYWJsZSBhcyBhXFxuZ3JpZDsgdGhlIGV5ZSB0cmFjZXMgY29sdW1ucy4gVGhlIHBvcnQncyB0YWJsZXMgYXJlIGFzIHJlYWRhYmxlLCBidXQgdGhlXFxuXCJ9PF9jb21wb25lbnRzLmVtPntcImF1dGhvcmluZ1wifTwvX2NvbXBvbmVudHMuZW0+e1wiIHN1cmZhY2UgKEpTIG1vZHVsZSkgaXMgbm90IGEgdmlzdWFsIG9iamVjdC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlR3by1taW51dGUgZGF0YSB0YWJsZXMuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFVudGlsIFJlY2tvbmVyIGdyb3dzIGEgc3dlZXAgY29uc3RydWN0IChvciB0aGVcXG5hc3Npc3RhbnQgd3JpdGVzIHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJydW5Nb2RlbFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJtYXBcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGlkaW9tIGluc3RhbnRseSksIEV4Y2VsIHdpbnMgdGhlXFxucXVpY2sgc2Vuc2l0aXZpdHkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJGb3J0eSB5ZWFycyBvZiBtdXNjbGUgbWVtb3J5XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGFuZCBhbiBlbnRpcmUgcHJvZmVzc2lvbiB0cmFpbmVkIG9uIHRoZVxcbmdyaWQg4oCUIGEgc3dpdGNoaW5nIGNvc3Qgbm8gZmVhdHVyZSBsaXN0IHJlbW92ZXMuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVmVyZGljdDpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdGhlIGh5cG90aGVzaXMgc3Vydml2ZXMgY29udGFjdCB3aXRoIHRoZSBjYW5vbmljYWwgY29tcGxleFxcbmZpbmFuY2lhbCBtb2RlbCwgd2l0aCB0aGUgc3Ryb25nZXN0IGZvcm0gYmVpbmc6IFwifTxfY29tcG9uZW50cy5lbT57XCJSZWNrb25lcidzIGNvbnN0cmFpbnRzIGNvbnZlcnRcXG5FeGNlbCdzIHNpbGVudCBmYWlsdXJlIGNsYXNzZXMgKGludmlzaWJsZSBjaXJjdWxhcml0eSwgdW5yZWFkYWJsZSBwcm92ZW5hbmNlLFxcbmNoZWNrcy10aGF0LWdhdGUtbm90aGluZykgaW50byB2aXNpYmxlLCB0ZXN0YWJsZSBzdHJ1Y3R1cmUg4oCUIGF0IHRoZSBjb3N0IG9mXFxudXAtZnJvbnQgZGVjb21wb3NpdGlvbiBhbmQgYSBtaXNzaW5nIHN0ZGxpYi9wcmltaXRpdmVzIGxheWVyIChHMeKAk0c1LCBHOSkgdGhhdFxcbmlzIGNvbmNyZXRlLCBlbnVtZXJhYmxlLCBhbmQgbW9zdGx5IGFkZGl0aXZlLlwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5ociAvPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInNlYy00XCIgZGF0YS1zbHVnPVwiNC1yZWNlaXB0c1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTRcIiAvPntcIjQg4oCUIFJlY2VpcHRzXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIkV4Y2VsIGJlZm9yZTogXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2FsZGVyYV9sYm8ueGxzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIDggc2hlZXRzLCA5NjMgY2VsbHMsIDYyMiBmb3JtdWxhczsgdGhlXFxudHdvLXdheSBzZW5zaXRpdml0eSBhbG9uZSBuZWVkZWQgYSBoaWRkZW4gMjk2LWNlbGwgZW5naW5lIHNoZWV0OyB0aGUgY2lyY3VsYXJcXG5zaGVldCByZXF1aXJlcyBpdGVyYXRpdmUgY2FsYyBlbmFibGVkOyBubyB0ZXN0IGNhbiBsaXZlIGluc2lkZSB0aGUgZmlsZS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJSZWNrb25lciBhZnRlcjogXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZG9jdW1lbnQvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgMiB3b3Jrc2hlZXRzLCAxMyBtb2RlbCBjZWxscywgMjIgdGVzdCBjZWxscyxcXG40MS1saW5lIHRlbXBsYXRlOyB0aGUgc2FtZSBzZW5zaXRpdml0eSBpcyBvbmUgY2VsbDsgdGhlIHNhbWUgY2lyY3VsYXJpdHkgaXNcXG5vbmUgY29udmVyZ2VkIGNlbGw7IHRoZSBvcmFjbGUgYWdyZWVtZW50IGlzIG1hY2hpbmUtY2hlY2tlZC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJQcm9vZjogXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibnB4IHZpdGVzdCBydW4gc3JjL2RvY3VtZW50L2NhbGRlcmFDYXNlU3R1ZHkudGVzdC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIGxvYWRzIHRoZVxcbmRvY3VtZW50IHRocm91Z2ggdGhlIHJlYWwgbG9hZGVyLCBydW5zIGl0IGluIHRoZSByZWFsIFNFUy1jb21wYXJ0bWVudCBlbmdpbmUsXFxuYXNzZXJ0cyBhbGwgc2NoZWR1bGUgeWVhcnMgLyByZXR1cm5zIC8gMjUgZ3JpZCBjZWxscyBhZ2FpbnN0IFwifTxfY29tcG9uZW50cy5jb2RlPntcImV4cGVjdGVkLmpzb25cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLFxcbnJ1bnMgYWxsIDIyIHdvcmtib29rIHRlc3RzLCBhbmQgYXNzZXJ0cyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ2YWxpZGF0ZWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHZlcmRpY3RzIGZvciB0aGUgdGVuXFxubG9hZC1iZWFyaW5nIGNlbGxzLiBGdWxsIHJlcG8gc3VpdGU6IDM2MyB0ZXN0cyBncmVlbjsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibnBtIHJ1biBsaW50XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhbmRcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJucG0gcnVuIGJ1aWxkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjbGVhbi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTVcIiBkYXRhLXNsdWc9XCI1LXJlY29tbWVuZGVkLWZvbGxvdy11cHMtcm9hZG1hcC1zaGFwZWRcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy01XCIgLz57XCI1IOKAlCBSZWNvbW1lbmRlZCBmb2xsb3ctdXBzIChyb2FkbWFwLXNoYXBlZClcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJHNlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAod2lyZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzdWJzdGl0dXRlSW5wdXRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpbnRvIFwifTxfY29tcG9uZW50cy5jb2RlPntcInJ1blN1aXRlc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpIOKAlCBidWctbGV2ZWwsIHNtYWxsLCB1bmJsb2Nrc1xcbnRoZSBwbGFuJ3Mgb3duIGhvbGRvdXQtdGVzdCBwYXR0ZXJuLiBEbyBmaXJzdC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkc1XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJyb2xsZm9yd2FyZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjdW1wcm9kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBzdGRsaWIgcHJpbWl0aXZlcykg4oCUIHNwZWMtYnktZXhhbXBsZSBpc1xcbnRoaXMgY2FzZSBzdHVkeTsgYWRkaXRpdmUtb25seSBmcmVlemUgYXJndWVzIGZvciBkZWNpZGluZyBlYXJseS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkcxXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChjb252ZXJnZWQgZml4ZWQtcG9pbnQgY2VsbCBraW5kKSDigJQgZGVzaWduIHNwaWtlOyB0aGUgZXhwbGljaXQtbG9vcFxcbmNvbnZlbnRpb24gd29ya3MgdW50aWwgdGhlbi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkc5XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChhc3N1bXB0aW9ucy1hcy1wYXJhbXMgYWZmb3JkYW5jZSkg4oCUIHRoZSBkYWlseS1mcmljdGlvbiBnYXAuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJHMlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoZmluYW5jaWFsIGZ1bmN0aW9ucyBmYW1pbHk6IFwifTxfY29tcG9uZW50cy5jb2RlPntcImlyclwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibnB2XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJ4aXJyXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhdCBtaW5pbXVtKSDigJRcXG5hZGRpdGl2ZS1vbmx5LCBzbyBzY2hlZHVsZSBkZWxpYmVyYXRlbHkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJHNFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoYSBzd2VlcC9zZW5zaXRpdml0eSBjb25zdHJ1Y3Qgb3ZlciBtb2RlbC1mdW5jdGlvbnMpIOKAlCBvciBsZWFuIG9uIHRoZVxcbmFzc2lzdGFudCBhdXRob3JpbmcgdGhlIGlkaW9tOyBtZWFzdXJlIHdoaWNoLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRzdcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHRvbGVyYW50IGludmFyaWFuY2UgY29tcGFyaXNvbnMpIOKAlCBzbWFsbCwgaGFyZGVuaW5nLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5vbD48Lz47XG59XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNRFhDb250ZW50KHByb3BzID0ge30pIHtcbiAgY29uc3Qge3dyYXBwZXI6IE1EWExheW91dH0gPSB7XG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9O1xuICByZXR1cm4gTURYTGF5b3V0ID8gPE1EWExheW91dCB7Li4ucHJvcHN9PjxfY3JlYXRlTWR4Q29udGVudCB7Li4ucHJvcHN9IC8+PC9NRFhMYXlvdXQ+IDogX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpO1xufVxuZnVuY3Rpb24gX21pc3NpbmdNZHhSZWZlcmVuY2UoaWQsIGNvbXBvbmVudCwgcGxhY2UpIHtcbiAgdGhyb3cgbmV3IEVycm9yKFwiRXhwZWN0ZWQgXCIgKyAoY29tcG9uZW50ID8gXCJjb21wb25lbnRcIiA6IFwib2JqZWN0XCIpICsgXCIgYFwiICsgaWQgKyBcImAgdG8gYmUgZGVmaW5lZDogeW91IGxpa2VseSBmb3Jnb3QgdG8gaW1wb3J0LCBwYXNzLCBvciBwcm92aWRlIGl0LlwiICsgKHBsYWNlID8gXCJcXG5JdOKAmXMgcmVmZXJlbmNlZCBpbiB5b3VyIGNvZGUgYXQgYFwiICsgcGxhY2UgKyBcImAgaW4gYC9hcHAvZG9jcy9MQk9fQ0FTRV9TVFVEWV9HQVBfQU5BTFlTSVMubWRgXCIgOiBcIlwiKSk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUVBLElBQUFBLFlBQUEsR0FBQUMsT0FBQTtBQUF3RixJQUFBQyxXQUFBLEdBQUFELE9BQUE7QUFGeEY7QUFDQTs7QUFFQSxTQUFTRSxpQkFBaUJBLENBQUNDLEtBQUssRUFBRTtFQUNoQyxNQUFNQyxXQUFXLEdBQUc7TUFDbEJDLENBQUMsRUFBRSxHQUFHO01BQ05DLElBQUksRUFBRSxNQUFNO01BQ1pDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLENBQUMsRUFBRSxHQUFHO01BQ05DLE1BQU0sRUFBRSxRQUFRO01BQ2hCQyxLQUFLLEVBQUUsT0FBTztNQUNkQyxLQUFLLEVBQUUsT0FBTztNQUNkQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxLQUFLLEVBQUUsT0FBTztNQUNkQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSLEdBQUcsSUFBQUMsNkJBQWtCLEVBQUMsQ0FBQztNQUN2QixHQUFHcEIsS0FBSyxDQUFDcUI7SUFDWCxDQUFDO0lBQUU7TUFBQ0M7SUFBYSxDQUFDLEdBQUdyQixXQUFXO0VBQ2hDLElBQUksQ0FBQ3FCLGFBQWEsRUFBRUMsb0JBQW9CLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQztFQUMvRCxvQkFBTyxJQUFBekIsV0FBQSxDQUFBMEIsSUFBQSxFQUFBMUIsV0FBQSxDQUFBMkIsUUFBQTtJQUFBQyxRQUFBLGdCQUFFLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNJLEVBQUU7TUFBQ3NCLEVBQUUsRUFBQywrQ0FBK0M7TUFBQUQsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUErQyxDQUFFLENBQUMsRUFBQyxpREFBaUQ7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNVLENBQUM7TUFBQWUsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFTLENBQXFCLENBQUMsRUFBQyxxQkFBcUIsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFVLENBQXFCLENBQUMsRUFBQyxlQUFlLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBVyxDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNDLENBQUM7UUFBQzJCLElBQUksRUFBQyx1QkFBdUI7UUFBQUgsUUFBQSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFxQixDQUFtQjtNQUFDLENBQWUsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFRLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQXVDLENBQW1CLENBQUMsRUFBQyw2REFBNkQ7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNVLENBQUM7TUFBQWUsUUFBQSxHQUFFLHNEQUFzRCxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLEVBQUU7UUFBQXNCLFFBQUEsRUFBRTtNQUFzTixDQUFpQixDQUFDO0lBQUEsQ0FBZSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNVLENBQUM7TUFBQWUsUUFBQSxHQUFFLG9QQUFvUCxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQU8sQ0FBcUIsQ0FBQyxFQUFDLDhCQUE4QixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFrQixDQUFtQixDQUFDLEVBQUMsMGNBQTBjO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDTyxFQUFFLElBQUUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBVixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNLLEVBQUU7TUFBQ3FCLEVBQUUsRUFBQyxPQUFPO01BQUMsYUFBVSwyQkFBMkI7TUFBQUQsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLDZCQUE2QjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1ksS0FBSztNQUFBYSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNnQixLQUFLO1FBQUFTLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDaUIsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNlLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQThCLENBQWlCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNlLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQXNCLENBQWlCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNlLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQVMsQ0FBaUIsQ0FBQztRQUFBLENBQWdCO01BQUMsQ0FBbUIsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2EsS0FBSztRQUFBWSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNpQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEdBQUUsZ0JBQWdCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQWdCLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQWtCLENBQW1CLENBQUMsRUFBQyxHQUFHO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEdBQUUsdUJBQXVCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQXVCLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQXFCLENBQW1CLENBQUMsRUFBQyxTQUFTLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQUssQ0FBbUIsQ0FBQyxFQUFDLHVCQUF1QixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFRLENBQW1CLENBQUM7VUFBQSxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBUSxDQUFxQixDQUFDLEVBQUMsaUVBQWlFO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNpQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBa0MsQ0FBaUIsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEdBQUUsa0JBQWtCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQVMsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBTSxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFLLENBQW1CLENBQUMsRUFBQyxzQ0FBc0M7VUFBQSxDQUFpQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBWSxDQUFxQixDQUFDLEVBQUMsbURBQW1EO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNpQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFLLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQVksQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBSyxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFLLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQUksQ0FBbUIsQ0FBQztVQUFBLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBUSxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFLLENBQW1CLENBQUMsRUFBQyxjQUFjLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQVUsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBSyxDQUFtQixDQUFDLEVBQUMsMkJBQTJCO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBWSxDQUFxQjtVQUFDLENBQWdCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDaUIsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBTyxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFPLENBQW1CLENBQUMsRUFBQyxVQUFVO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFNLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQVUsQ0FBbUIsQ0FBQztVQUFBLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFZLENBQXFCLENBQUMsRUFBQyw0QkFBNEI7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQU8sQ0FBbUIsQ0FBQyxFQUFDLG1CQUFtQjtVQUFBLENBQWlCLENBQUMsbUJBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFLLENBQXFCLENBQUMsRUFBQyw2RkFBNkY7VUFBQSxDQUFpQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFRLENBQXFCO1VBQUMsQ0FBZ0IsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNpQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBdUQsQ0FBaUIsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBNkcsQ0FBaUIsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQVEsQ0FBcUIsQ0FBQyxFQUFDLDJDQUEyQztVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDaUIsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxHQUFFLFVBQVUsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFhLENBQXFCLENBQUMsRUFBQyx3QkFBd0I7VUFBQSxDQUFpQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsR0FBRSx1RUFBdUUsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBSyxDQUFtQixDQUFDLEVBQUMseUNBQXlDO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQVEsQ0FBcUIsQ0FBQyxFQUFDLHdDQUF3QztVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDaUIsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFXLENBQXFCLENBQUMsRUFBQyw0QkFBNEI7VUFBQSxDQUFpQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUErRixDQUFpQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFRLENBQXFCO1VBQUMsQ0FBZ0IsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNpQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEdBQUUsZ0JBQWdCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQTBCLENBQW1CLENBQUM7VUFBQSxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsR0FBRSxtRUFBbUUsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBVyxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFRLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQVUsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7VUFBQSxDQUFpQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBc0IsQ0FBcUIsQ0FBQyxFQUFDLFdBQVc7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFnQyxDQUFpQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUErRCxDQUFpQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFzQixDQUFxQjtVQUFDLENBQWdCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDaUIsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQWtCLENBQWlCLENBQUMsbUJBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBVSxDQUFtQixDQUFDLEVBQUMsc0NBQXNDO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQVksQ0FBcUIsQ0FBQyxFQUFDLHVCQUF1QjtVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDO01BQUEsQ0FBbUIsQ0FBQztJQUFBLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ08sRUFBRSxJQUFFLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQVYsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDSyxFQUFFO01BQUNxQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUsMEJBQTBCO01BQUFELFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQyw2QkFBNkI7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNNLEVBQUU7TUFBQ29CLEVBQUUsRUFBQyxRQUFRO01BQUMsYUFBVSwrREFBK0Q7TUFBQUQsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFRLENBQUUsQ0FBQyxFQUFDLHNFQUFzRTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZSxRQUFBLEdBQUUscUNBQXFDLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBc0IsUUFBQSxFQUFFO01BQVMsQ0FBaUIsQ0FBQyxFQUFDLG1TQUFtUztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZSxRQUFBLEdBQUUsdUJBQXVCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBeUIsQ0FBcUIsQ0FBQyxFQUFDLFdBQVcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLHFEQUFxRDtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2tCLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLEVBQUU7VUFBQXNCLFFBQUEsRUFBRTtRQUFPLENBQWlCLENBQUMsRUFBQywyRUFBMkUsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBcUIsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBc0IsUUFBQSxFQUFFO1FBQWUsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBeUIsQ0FBbUIsQ0FBQyxFQUFDLHlFQUF5RSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTJCLENBQXFCLENBQUMsRUFBQyxrTUFBa007TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVUsQ0FBcUIsQ0FBQyxFQUFDLGtCQUFrQixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLEVBQUU7UUFBQXNCLFFBQUEsRUFBRTtNQUFhLENBQWlCLENBQUMsRUFBQyxvSEFBb0gsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFpQyxDQUFxQixDQUFDLEVBQUMsNElBQTRJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBc0IsUUFBQSxFQUFFO01BQVMsQ0FBaUIsQ0FBQyxFQUFDLHVOQUF1TjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDb0IsRUFBRSxFQUFDLFFBQVE7TUFBQyxhQUFVLGtDQUFrQztNQUFBRCxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVEsQ0FBRSxDQUFDLEVBQUMsb0NBQW9DO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDVSxDQUFDO01BQUFlLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQUssQ0FBbUIsQ0FBQyxFQUFDLDBPQUEwTyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLEVBQUU7UUFBQXNCLFFBQUEsRUFBRTtNQUFRLENBQWlCLENBQUMsRUFBQywyR0FBMkcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFpQixDQUFxQixDQUFDLEVBQUMseUxBQXlMO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDTSxFQUFFO01BQUNvQixFQUFFLEVBQUMsUUFBUTtNQUFDLGFBQVUscUJBQXFCO01BQUFELFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBUSxDQUFFLENBQUMsRUFBQyx5QkFBeUI7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNVLENBQUM7TUFBQWUsUUFBQSxHQUFFLHFIQUFxSCxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUErQixDQUFtQixDQUFDLEVBQUMsNk9BQTZPLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBNEMsQ0FBcUIsQ0FBQyxFQUFDLFlBQVk7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNNLEVBQUU7TUFBQ29CLEVBQUUsRUFBQyxRQUFRO01BQUMsYUFBVSwwREFBMEQ7TUFBQUQsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFRLENBQUUsQ0FBQyxFQUFDLDREQUE0RDtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZSxRQUFBLEdBQUUsc0tBQXNLLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQStELENBQW1CLENBQUMsRUFBQyw4QkFBOEIsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxFQUFFO1FBQUFzQixRQUFBLEVBQUU7TUFBbUIsQ0FBaUIsQ0FBQyxFQUFDLDRGQUE0RjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZSxRQUFBLEVBQUU7SUFBMmtCLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDb0IsRUFBRSxFQUFDLFFBQVE7TUFBQyxhQUFVLDJFQUEyRTtNQUFBRCxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVEsQ0FBRSxDQUFDLEVBQUMsZ0ZBQWdGO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDVSxDQUFDO01BQUFlLFFBQUEsR0FBRSxzUkFBc1IsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBUSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFRLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQVEsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBSyxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFLLENBQW1CLENBQUMsRUFBQyw2Q0FBNkMsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFnQyxDQUFxQixDQUFDLEVBQUMsd0NBQXdDLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQVEsQ0FBbUIsQ0FBQyxFQUFDLDZDQUE2QyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFRLENBQW1CLENBQUMsRUFBQywrS0FBK0ssZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBUyxDQUFtQixDQUFDLEVBQUMsa0JBQWtCO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDVSxDQUFDO01BQUFlLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBaUIsQ0FBcUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBYSxDQUFtQixDQUFDLEVBQUMsaUtBQWlLO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDTSxFQUFFO01BQUNvQixFQUFFLEVBQUMsUUFBUTtNQUFDLGFBQVUsZ0VBQWdFO01BQUFELFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBUSxDQUFFLENBQUMsRUFBQyxvRUFBb0U7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNVLENBQUM7TUFBQWUsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBZSxDQUFtQixDQUFDLEVBQUMsY0FBYyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFrQixDQUFtQixDQUFDLEVBQUMsdUtBQXVLLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQXNCLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQXdCLENBQW1CLENBQUMsRUFBQyx1QkFBdUIsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFXLENBQXFCLENBQUMsRUFBQyxpQ0FBaUMsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBd0MsQ0FBbUIsQ0FBQyxFQUFDLHVJQUF1SSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQXNCLENBQXFCLENBQUMsRUFBQyxPQUFPLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQWlCLENBQW1CLENBQUMsRUFBQyx3SUFBd0ksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFpQixDQUFxQixDQUFDLEVBQUMsUUFBUSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFrQixDQUFtQixDQUFDLEVBQUMsUUFBUSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFXLENBQW1CLENBQUMsRUFBQyw0R0FBNEc7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNNLEVBQUU7TUFBQ29CLEVBQUUsRUFBQyxRQUFRO01BQUMsYUFBVSwyQ0FBMkM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFRLENBQUUsQ0FBQyxFQUFDLDZDQUE2QztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUF1QixDQUFtQixDQUFDLEVBQUMsdUJBQXVCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQVcsQ0FBbUIsQ0FBQyxFQUFDLDJSQUEyUixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFpQixDQUFtQixDQUFDLEVBQUMsVUFBVSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLEVBQUU7UUFBQXNCLFFBQUEsRUFBRTtNQUFPLENBQWlCLENBQUMsRUFBQyxvSUFBb0ksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFpQixDQUFxQixDQUFDLEVBQUMsMEVBQTBFLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQWMsQ0FBbUIsQ0FBQyxFQUFDLHFDQUFxQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDb0IsRUFBRSxFQUFDLFFBQVE7TUFBQyxhQUFVLDhDQUE4QztNQUFBRCxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVEsQ0FBRSxDQUFDLEVBQUMsZ0RBQWdEO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDVSxDQUFDO01BQUFlLFFBQUEsR0FBRSw2SEFBNkgsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBSyxDQUFtQixDQUFDLEVBQUMsMklBQTJJO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDTSxFQUFFO01BQUNvQixFQUFFLEVBQUMsUUFBUTtNQUFDLGFBQVUscURBQXFEO01BQUFELFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBUSxDQUFFLENBQUMsRUFBQyx3REFBd0Q7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNVLENBQUM7TUFBQWUsUUFBQSxHQUFFLHdKQUF3SixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFnQixDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFlLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQVcsQ0FBbUIsQ0FBQyxFQUFDLGNBQWMsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBUSxDQUFtQixDQUFDLEVBQUMsb0RBQW9ELGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBc0IsUUFBQSxFQUFFO01BQW1CLENBQWlCLENBQUMsRUFBQywrSkFBK0osZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxFQUFFO1FBQUFzQixRQUFBLEVBQUU7TUFBTyxDQUFpQixDQUFDLEVBQUMsY0FBYyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQWlCLENBQXFCLENBQUMsRUFBQyw4TEFBOEwsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxFQUFFO1FBQUFzQixRQUFBLEVBQUU7TUFBZ0IsQ0FBaUIsQ0FBQyxFQUFDLG9GQUFvRjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDb0IsRUFBRSxFQUFDLGtCQUFrQjtNQUFBRCxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQWtCLENBQUUsQ0FBQyxFQUFDLGtCQUFrQjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2tCLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWMsQ0FBcUIsQ0FBQyxFQUFDLGlCQUFpQixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFTLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQVEsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBTyxDQUFtQixDQUFDLEVBQUMsb0JBQW9CO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWtCLENBQXFCLENBQUMsRUFBQywyQ0FBMkM7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBaUMsQ0FBcUIsQ0FBQyxFQUFDLHFGQUFxRixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFLLENBQW1CLENBQUMsRUFBQyx1REFBdUQ7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBWSxDQUFxQixDQUFDLEVBQUMsb0VBQW9FO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQVUsQ0FBcUIsQ0FBQyxFQUFDLG9JQUFvSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDTyxFQUFFLElBQUUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBVixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNLLEVBQUU7TUFBQ3FCLEVBQUUsRUFBQyxPQUFPO01BQUMsYUFBVSwyRUFBMkU7TUFBQUQsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLGdGQUFnRjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZSxRQUFBLEdBQUUsV0FBVyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQUssQ0FBcUIsQ0FBQyxFQUFDLG1CQUFtQjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1MsRUFBRTtNQUFBZ0IsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNVLENBQUM7VUFBQWUsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1lBQUFjLFFBQUEsRUFBRTtVQUFtRCxDQUFxQixDQUFDLEVBQUMsbUNBQW1DLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBdUIsUUFBQSxFQUFFO1VBQXFCLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBdUIsUUFBQSxFQUFFO1VBQXdCLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBdUIsUUFBQSxFQUFFO1VBQXNCLENBQW1CLENBQUMsRUFBQyxTQUFTLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBdUIsUUFBQSxFQUFFO1VBQVEsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxFQUFFO1lBQUFzQixRQUFBLEVBQUU7VUFBcUIsQ0FBaUIsQ0FBQyxFQUFDLG1IQUFtSCxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7WUFBQXVCLFFBQUEsRUFBRTtVQUFnQixDQUFtQixDQUFDLEVBQUMsNENBQTRDLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBdUIsUUFBQSxFQUFFO1VBQXNCLENBQW1CLENBQUMsRUFBQyxxS0FBcUs7UUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDVSxDQUFDO1VBQUFlLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtZQUFBYyxRQUFBLEVBQUU7VUFBeUQsQ0FBcUIsQ0FBQyxFQUFDLHlCQUF5QixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7WUFBQXVCLFFBQUEsRUFBRTtVQUFRLENBQW1CLENBQUMsRUFBQyxrQkFBa0IsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1lBQUF1QixRQUFBLEVBQUU7VUFBMEIsQ0FBbUIsQ0FBQyxFQUFDLDhJQUE4SSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLEVBQUU7WUFBQXNCLFFBQUEsRUFBRTtVQUFNLENBQWlCLENBQUMsRUFBQyxzRUFBc0UsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1lBQUFjLFFBQUEsRUFBRTtVQUFNLENBQXFCLENBQUMsRUFBQyx3VEFBd1QsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1lBQUF1QixRQUFBLEVBQUU7VUFBUSxDQUFtQixDQUFDLEVBQUMsdUVBQXVFLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBdUIsUUFBQSxFQUFFO1VBQVcsQ0FBbUIsQ0FBQyxFQUFDLDhHQUE4RztRQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNVLENBQUM7VUFBQWUsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1lBQUFjLFFBQUEsRUFBRTtVQUFxRSxDQUFxQixDQUFDLEVBQUMsNkNBQTZDLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csRUFBRTtZQUFBc0IsUUFBQSxFQUFFO1VBQWtCLENBQWlCLENBQUMsRUFBQyw0VEFBNFQ7UUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDVSxDQUFDO1VBQUFlLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtZQUFBYyxRQUFBLEVBQUU7VUFBZ0QsQ0FBcUIsQ0FBQyxFQUFDLDBNQUEwTSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLEVBQUU7WUFBQXNCLFFBQUEsRUFBRTtVQUF3QixDQUFpQixDQUFDLEVBQUMsUUFBUSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLEVBQUU7WUFBQXNCLFFBQUEsRUFBRTtVQUEwQixDQUFpQixDQUFDLEVBQUMsR0FBRztRQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNVLENBQUM7TUFBQWUsUUFBQSxHQUFFLFdBQVcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFTLENBQXFCLENBQUMsRUFBQyxZQUFZO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUyxFQUFFO01BQUFnQixRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBd0IsQ0FBcUIsQ0FBQyxFQUFDLDRLQUE0SztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFrQixDQUFxQixDQUFDLEVBQUMsaUlBQWlJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBc0IsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLDhDQUE4QztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUF5QixDQUFxQixDQUFDLEVBQUMsd0VBQXdFLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQVUsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBSyxDQUFtQixDQUFDLEVBQUMsdURBQXVEO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQThCLENBQXFCLENBQUMsRUFBQyw0RkFBNEY7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVUsQ0FBcUIsQ0FBQyxFQUFDLCtHQUErRyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLEVBQUU7UUFBQXNCLFFBQUEsRUFBRTtNQUEwVCxDQUFpQixDQUFDO0lBQUEsQ0FBZSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNPLEVBQUUsSUFBRSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFWLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDcUIsRUFBRSxFQUFDLE9BQU87TUFBQyxhQUFVLFlBQVk7TUFBQUQsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLGNBQWM7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNrQixFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxHQUFFLGdCQUFnQixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFrQixDQUFtQixDQUFDLEVBQUMsb01BQW9NO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLEdBQUUsa0JBQWtCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLDRMQUE0TDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxHQUFFLFNBQVMsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBc0QsQ0FBbUIsQ0FBQyxFQUFDLDRKQUE0SixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFlLENBQW1CLENBQUMsRUFBQyw2Q0FBNkMsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsK0VBQStFLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLFFBQVEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBZSxDQUFtQixDQUFDLEVBQUMsU0FBUztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDSyxFQUFFO01BQUNxQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUseUNBQXlDO01BQUFELFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQyw2Q0FBNkM7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNTLEVBQUU7TUFBQWdCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFJLENBQXFCLENBQUMsRUFBQyxTQUFTLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQWtCLENBQW1CLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLGdGQUFnRjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFJLENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBUyxDQUFtQixDQUFDLEVBQUMsNEdBQTRHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQUksQ0FBcUIsQ0FBQyxFQUFDLG9HQUFvRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFJLENBQXFCLENBQUMsRUFBQywrREFBK0Q7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBSSxDQUFxQixDQUFDLEVBQUMsZ0NBQWdDLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQUssQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBSyxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFNLENBQW1CLENBQUMsRUFBQywwREFBMEQ7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBSSxDQUFxQixDQUFDLEVBQUMsdUhBQXVIO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQUksQ0FBcUIsQ0FBQyxFQUFDLHdEQUF3RDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQztFQUFBLENBQUUsQ0FBQztBQUNwMDVCO0FBQ2UsU0FBU0ksVUFBVUEsQ0FBQzlCLEtBQUssR0FBRyxDQUFDLENBQUMsRUFBRTtFQUM3QyxNQUFNO0lBQUMrQixPQUFPLEVBQUVDO0VBQVMsQ0FBQyxHQUFHO0lBQzNCLEdBQUcsSUFBQVosNkJBQWtCLEVBQUMsQ0FBQztJQUN2QixHQUFHcEIsS0FBSyxDQUFDcUI7RUFDWCxDQUFDO0VBQ0QsT0FBT1csU0FBUyxnQkFBRyxJQUFBbEMsV0FBQSxDQUFBOEIsR0FBQSxFQUFDSSxTQUFTO0lBQUEsR0FBS2hDLEtBQUs7SUFBQTBCLFFBQUEsZUFBRSxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDN0IsaUJBQWlCO01BQUEsR0FBS0M7SUFBSyxDQUFHO0VBQUMsQ0FBVyxDQUFDLEdBQUdELGlCQUFpQixDQUFDQyxLQUFLLENBQUM7QUFDbEg7QUFBQ2lDLEVBQUEsR0FOdUJILFVBQVU7QUFPbEMsU0FBU1Asb0JBQW9CQSxDQUFDSSxFQUFFLEVBQUVPLFNBQVMsRUFBRUMsS0FBSyxFQUFFO0VBQ2xELE1BQU0sSUFBSUMsS0FBSyxDQUFDLFdBQVcsSUFBSUYsU0FBUyxHQUFHLFdBQVcsR0FBRyxRQUFRLENBQUMsR0FBRyxJQUFJLEdBQUdQLEVBQUUsR0FBRyxvRUFBb0UsSUFBSVEsS0FBSyxHQUFHLHFDQUFxQyxHQUFHQSxLQUFLLEdBQUcsaURBQWlELEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDM1E7QUFBQyxJQUFBRixFQUFBO0FBQUFJLFlBQUEsQ0FBQUosRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}