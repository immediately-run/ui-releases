var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      li: "li",
      p: "p",
      pre: "pre",
      strong: "strong",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "sec-s5",
      "data-slug": "s5-spike-in-platform-dependency-resolution-for-ses-codemirror",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-s5"
      }), "S5 spike — in-platform dependency resolution for SES + CodeMirror"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Status:"
      }), " DONE — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "positive"
      }), " (live-confirmed 2026-07-12). · Axis-2 self-hosting item\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "S5"
      }), " from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "../AXIS2_SELF_HOSTING_WORKITEMS.md",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "../AXIS2_SELF_HOSTING_WORKITEMS.md"
        })
      }), " and\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ARCHITECTURE_PLAN.md"
      }), " §0.2 (S5 was booked as \"spike ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "before"
      }), " M1 source work\")."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "question",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "question"
      }), "Question"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Does immediately.run's in-browser ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "module-fetch path"
      }), " resolve the two dependency families\nthe source realms need — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "SES"
      }), " (Hardened JavaScript, for the formula engine, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ARCHITECTURE_PLAN"
      }), "\n§4) and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "CodeMirror"
      }), " (the editor realm) — and does ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Hardened JS actually run"
      }), " inside the\nsandboxed opaque-origin iframe? S5 was the gate on whether the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "engine realm can be built\nin-platform at all"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "method",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "method"
      }), "Method"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["A minimal immediately.run app (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "scratchpad/ses-spike/"
      }), ") that:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "import 'ses'"
        }), " (the side-effect shim that installs ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "lockdown"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Compartment"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "harden"
        }), ") and\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "import { EditorState } from '@codemirror/state'"
        }), ";"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["at module load — the production engine pattern — calls ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "lockdown()"
        }), ", then checks: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "harden"
        }), "\nis installed, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "new Compartment({x:21}).evaluate('x*2') === 42"
        }), ", an undeclared global is\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "starved"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "new Compartment({}).evaluate('typeof fetch') === 'undefined'"
        }), "), and CodeMirror\nresolved;"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: "logs the result to the console before any React work."
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Served on the real host via the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "local"
      }), " provider\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "immediately.run dev . --origin https://local.immediately.run"
      }), ") and driven headless\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "puppeteer-core"
      }), " → system Chrome, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "--ignore-certificate-errors"
      }), " for the local nginx cert,\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "--disable-features=LocalNetworkAccessChecks,BlockInsecurePrivateNetworkRequests"
      }), " for the\nloopback provider fetch). The app renders in the sandbox's nested iframe; the driver reads the\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "S5-RESULT"
      }), " console marker and the iframe text."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "result-all-pass",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "result-all-pass"
      }), "Result — ALL PASS"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "PASS — lockdown() runs\nPASS — harden installed post-lockdown            (harden=function)\nPASS — Compartment evaluates confined code       (evaluate(\"x*2\")=42)\nPASS — undeclared global starved in compartment  (typeof fetch=undefined)\nPASS — CodeMirror resolves                        (EditorState.create=function)\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Supporting evidence from the sandbox boot log:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Resolution works."
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "[ir-perf:cdn-resolve] fastHits 829 · fallThroughs 82"
        }), " — 829 modules\nresolved on the primary CDN, 82 fell through to the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "esm.sh"
        }), " fallback. COW created\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "/ses"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "/@endo/env-options"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "/@codemirror/state"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "/@marijn/find-cluster-break"
        }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "/scheduler"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "/react"
        }), ", … — i.e. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ses"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["and its ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "@endo/*"
          }), " deps"]
        }), " and the CodeMirror tree\nall resolved."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "loadNodeModules 2133ms → ir.deps (Σ 3191ms)"
        }), "; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "request→interactive 3939ms"
        }), " (cold, uncached)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "verdict",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "verdict"
      }), "Verdict"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "S5 is closed positive."
      }), " The module-fetch path resolves SES + CodeMirror, and a ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["starved\nSES ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Compartment"
        }), " runs in-platform"]
      }), " — the engine realm's core security property (no ambient\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "fetch"
      }), " reachable from confined code) holds inside the sandboxed opaque-origin iframe. The\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "engine realm (SES) and editor realm (CodeMirror) are buildable in-platform."
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Two independent corroborations:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "CodeMirror was already proven"
        }), " before this spike: the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "immediately-run/editor"
        }), " app depends\non the full ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "@codemirror/*"
        }), " set and runs as a production immediately.run app (editor-as-app)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["The resolution path is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "blazingly.io"
        }), " (primary CDN) → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "esm.sh"
        }), " (fallback, which serves\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ses@2.2.0"
        }), " as its ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "assert-shim"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "compartment-shim"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "lockdown-shim"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ses.mjs"
        }), " set); esm.sh is\nalready in the sandbox ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "connect-src"
        }), ", so no CSP change was needed."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "caveats-scope",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "caveats-scope"
      }), "Caveats / scope"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["The spike ran SES in the app's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "render iframe"
        }), " (calling ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "lockdown()"
        }), " there disturbs React\nafter the fact, which is why the result is logged to the console pre-render). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Production\nruns SES in a dedicated worker"
        }), " inside the engine entry-point (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ARCHITECTURE_PLAN"
        }), " §4), so\nlockdown-vs-React coexistence is a non-issue for the real engine — this spike only had to\nprove ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "resolution + Hardened-JS execution"
        }), ", which it did."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["S5 is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "distinct from S4b"
        }), " (an in-platform Node-equivalent CI gate for ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "build"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "lint"
        }), "/\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "vitest"
        }), "/mutation of the TypeScript ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "source"
        }), "). S4b remains a genuine gap; source-level CI\nstays external until it lands. S5 being positive does ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "not"
        }), " close S4b."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "reproduce",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "reproduce"
      }), "Reproduce"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-bash",
        children: "# stack up: sandbox parcel on :1234, site-main on :3000, behind the local nginx\ncd sandbox && npx parcel ./src/index.html --port 1234 &          # (bypasses the stale-dist predev guard)\ncd immediately-run-site-main && BROWSER=none npm start &          # :3000\n# serve the spike app + drive it headless\ncd scratchpad/ses-spike && immediately.run dev . --origin https://local.immediately.run --json\nnode drive.mjs \"<printed /edit/.../live#… url>\"\n"
      })
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/spikes/S5_SES_MODULE_RESOLUTION.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiY29kZSIsImVtIiwiaDEiLCJoMiIsImxpIiwicCIsInByZSIsInN0cm9uZyIsInVsIiwiX3Byb3ZpZGVDb21wb25lbnRzIiwiY29tcG9uZW50cyIsIkhlYWRpbmdBbmNob3IiLCJfbWlzc2luZ01keFJlZmVyZW5jZSIsImpzeHMiLCJGcmFnbWVudCIsImNoaWxkcmVuIiwiaWQiLCJqc3giLCJocmVmIiwiY2xhc3NOYW1lIiwiTURYQ29udGVudCIsIndyYXBwZXIiLCJNRFhMYXlvdXQiLCJfYyIsImNvbXBvbmVudCIsInBsYWNlIiwiRXJyb3IiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJTNV9TRVNfTU9EVUxFX1JFU09MVVRJT04ubWQiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgYTogXCJhXCIsXG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgZW06IFwiZW1cIixcbiAgICBoMTogXCJoMVwiLFxuICAgIGgyOiBcImgyXCIsXG4gICAgbGk6IFwibGlcIixcbiAgICBwOiBcInBcIixcbiAgICBwcmU6IFwicHJlXCIsXG4gICAgc3Ryb25nOiBcInN0cm9uZ1wiLFxuICAgIHVsOiBcInVsXCIsXG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9LCB7SGVhZGluZ0FuY2hvcn0gPSBfY29tcG9uZW50cztcbiAgaWYgKCFIZWFkaW5nQW5jaG9yKSBfbWlzc2luZ01keFJlZmVyZW5jZShcIkhlYWRpbmdBbmNob3JcIiwgdHJ1ZSk7XG4gIHJldHVybiA8PjxfY29tcG9uZW50cy5oMSBpZD1cInNlYy1zNVwiIGRhdGEtc2x1Zz1cInM1LXNwaWtlLWluLXBsYXRmb3JtLWRlcGVuZGVuY3ktcmVzb2x1dGlvbi1mb3Itc2VzLWNvZGVtaXJyb3JcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy1zNVwiIC8+e1wiUzUgc3Bpa2Ug4oCUIGluLXBsYXRmb3JtIGRlcGVuZGVuY3kgcmVzb2x1dGlvbiBmb3IgU0VTICsgQ29kZU1pcnJvclwifTwvX2NvbXBvbmVudHMuaDE+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJTdGF0dXM6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIERPTkUg4oCUIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicG9zaXRpdmVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKGxpdmUtY29uZmlybWVkIDIwMjYtMDctMTIpLiDCtyBBeGlzLTIgc2VsZi1ob3N0aW5nIGl0ZW1cXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlM1XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGZyb20gXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cIi4uL0FYSVMyX1NFTEZfSE9TVElOR19XT1JLSVRFTVMubWRcIj48X2NvbXBvbmVudHMuY29kZT57XCIuLi9BWElTMl9TRUxGX0hPU1RJTkdfV09SS0lURU1TLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuYT57XCIgYW5kXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQVJDSElURUNUVVJFX1BMQU4ubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIMKnMC4yIChTNSB3YXMgYm9va2VkIGFzIFxcXCJzcGlrZSBcIn08X2NvbXBvbmVudHMuZW0+e1wiYmVmb3JlXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgTTEgc291cmNlIHdvcmtcXFwiKS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwicXVlc3Rpb25cIj48SGVhZGluZ0FuY2hvciBpZD1cInF1ZXN0aW9uXCIgLz57XCJRdWVzdGlvblwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiRG9lcyBpbW1lZGlhdGVseS5ydW4ncyBpbi1icm93c2VyIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibW9kdWxlLWZldGNoIHBhdGhcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgcmVzb2x2ZSB0aGUgdHdvIGRlcGVuZGVuY3kgZmFtaWxpZXNcXG50aGUgc291cmNlIHJlYWxtcyBuZWVkIOKAlCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlNFU1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoSGFyZGVuZWQgSmF2YVNjcmlwdCwgZm9yIHRoZSBmb3JtdWxhIGVuZ2luZSwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQVJDSElURUNUVVJFX1BMQU5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxuwqc0KSBhbmQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJDb2RlTWlycm9yXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICh0aGUgZWRpdG9yIHJlYWxtKSDigJQgYW5kIGRvZXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJIYXJkZW5lZCBKUyBhY3R1YWxseSBydW5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgaW5zaWRlIHRoZVxcbnNhbmRib3hlZCBvcGFxdWUtb3JpZ2luIGlmcmFtZT8gUzUgd2FzIHRoZSBnYXRlIG9uIHdoZXRoZXIgdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZW5naW5lIHJlYWxtIGNhbiBiZSBidWlsdFxcbmluLXBsYXRmb3JtIGF0IGFsbFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIi5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwibWV0aG9kXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJtZXRob2RcIiAvPntcIk1ldGhvZFwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiQSBtaW5pbWFsIGltbWVkaWF0ZWx5LnJ1biBhcHAgKFwifTxfY29tcG9uZW50cy5jb2RlPntcInNjcmF0Y2hwYWQvc2VzLXNwaWtlL1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpIHRoYXQ6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLmNvZGU+e1wiaW1wb3J0ICdzZXMnXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAodGhlIHNpZGUtZWZmZWN0IHNoaW0gdGhhdCBpbnN0YWxscyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJsb2NrZG93blwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQ29tcGFydG1lbnRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcImhhcmRlblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpIGFuZFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcImltcG9ydCB7IEVkaXRvclN0YXRlIH0gZnJvbSAnQGNvZGVtaXJyb3Ivc3RhdGUnXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjtcIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJhdCBtb2R1bGUgbG9hZCDigJQgdGhlIHByb2R1Y3Rpb24gZW5naW5lIHBhdHRlcm4g4oCUIGNhbGxzIFwifTxfY29tcG9uZW50cy5jb2RlPntcImxvY2tkb3duKClcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCB0aGVuIGNoZWNrczogXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaGFyZGVuXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIlxcbmlzIGluc3RhbGxlZCwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibmV3IENvbXBhcnRtZW50KHt4OjIxfSkuZXZhbHVhdGUoJ3gqMicpID09PSA0MlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGFuIHVuZGVjbGFyZWQgZ2xvYmFsIGlzXFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJzdGFydmVkXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJuZXcgQ29tcGFydG1lbnQoe30pLmV2YWx1YXRlKCd0eXBlb2YgZmV0Y2gnKSA9PT0gJ3VuZGVmaW5lZCdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSwgYW5kIENvZGVNaXJyb3JcXG5yZXNvbHZlZDtcIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJsb2dzIHRoZSByZXN1bHQgdG8gdGhlIGNvbnNvbGUgYmVmb3JlIGFueSBSZWFjdCB3b3JrLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJTZXJ2ZWQgb24gdGhlIHJlYWwgaG9zdCB2aWEgdGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcImxvY2FsXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBwcm92aWRlclxcbihcIn08X2NvbXBvbmVudHMuY29kZT57XCJpbW1lZGlhdGVseS5ydW4gZGV2IC4gLS1vcmlnaW4gaHR0cHM6Ly9sb2NhbC5pbW1lZGlhdGVseS5ydW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSBhbmQgZHJpdmVuIGhlYWRsZXNzXFxuKFwifTxfY29tcG9uZW50cy5jb2RlPntcInB1cHBldGVlci1jb3JlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDihpIgc3lzdGVtIENocm9tZSwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1pZ25vcmUtY2VydGlmaWNhdGUtZXJyb3JzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBmb3IgdGhlIGxvY2FsIG5naW54IGNlcnQsXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1kaXNhYmxlLWZlYXR1cmVzPUxvY2FsTmV0d29ya0FjY2Vzc0NoZWNrcyxCbG9ja0luc2VjdXJlUHJpdmF0ZU5ldHdvcmtSZXF1ZXN0c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZm9yIHRoZVxcbmxvb3BiYWNrIHByb3ZpZGVyIGZldGNoKS4gVGhlIGFwcCByZW5kZXJzIGluIHRoZSBzYW5kYm94J3MgbmVzdGVkIGlmcmFtZTsgdGhlIGRyaXZlciByZWFkcyB0aGVcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJTNS1SRVNVTFRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNvbnNvbGUgbWFya2VyIGFuZCB0aGUgaWZyYW1lIHRleHQuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInJlc3VsdC1hbGwtcGFzc1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwicmVzdWx0LWFsbC1wYXNzXCIgLz57XCJSZXN1bHQg4oCUIEFMTCBQQVNTXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucHJlPjxfY29tcG9uZW50cy5jb2RlPntcIlBBU1Mg4oCUIGxvY2tkb3duKCkgcnVuc1xcblBBU1Mg4oCUIGhhcmRlbiBpbnN0YWxsZWQgcG9zdC1sb2NrZG93biAgICAgICAgICAgIChoYXJkZW49ZnVuY3Rpb24pXFxuUEFTUyDigJQgQ29tcGFydG1lbnQgZXZhbHVhdGVzIGNvbmZpbmVkIGNvZGUgICAgICAgKGV2YWx1YXRlKFxcXCJ4KjJcXFwiKT00MilcXG5QQVNTIOKAlCB1bmRlY2xhcmVkIGdsb2JhbCBzdGFydmVkIGluIGNvbXBhcnRtZW50ICAodHlwZW9mIGZldGNoPXVuZGVmaW5lZClcXG5QQVNTIOKAlCBDb2RlTWlycm9yIHJlc29sdmVzICAgICAgICAgICAgICAgICAgICAgICAgKEVkaXRvclN0YXRlLmNyZWF0ZT1mdW5jdGlvbilcXG5cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5wcmU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiU3VwcG9ydGluZyBldmlkZW5jZSBmcm9tIHRoZSBzYW5kYm94IGJvb3QgbG9nOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUmVzb2x1dGlvbiB3b3Jrcy5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiW2lyLXBlcmY6Y2RuLXJlc29sdmVdIGZhc3RIaXRzIDgyOSDCtyBmYWxsVGhyb3VnaHMgODJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCA4MjkgbW9kdWxlc1xcbnJlc29sdmVkIG9uIHRoZSBwcmltYXJ5IENETiwgODIgZmVsbCB0aHJvdWdoIHRvIHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImVzbS5zaFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBmYWxsYmFjay4gQ09XIGNyZWF0ZWRcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCIvc2VzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiL0BlbmRvL2Vudi1vcHRpb25zXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiL0Bjb2RlbWlycm9yL3N0YXRlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiL0BtYXJpam4vZmluZC1jbHVzdGVyLWJyZWFrXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIixcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCIvc2NoZWR1bGVyXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiL3JlYWN0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwg4oCmIOKAlCBpLmUuIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNlc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJhbmQgaXRzIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkBlbmRvLypcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGRlcHNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYW5kIHRoZSBDb2RlTWlycm9yIHRyZWVcXG5hbGwgcmVzb2x2ZWQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLmNvZGU+e1wibG9hZE5vZGVNb2R1bGVzIDIxMzNtcyDihpIgaXIuZGVwcyAozqMgMzE5MW1zKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCI7IFwifTxfY29tcG9uZW50cy5jb2RlPntcInJlcXVlc3TihpJpbnRlcmFjdGl2ZSAzOTM5bXNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChjb2xkLCB1bmNhY2hlZCkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInZlcmRpY3RcIj48SGVhZGluZ0FuY2hvciBpZD1cInZlcmRpY3RcIiAvPntcIlZlcmRpY3RcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUzUgaXMgY2xvc2VkIHBvc2l0aXZlLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGUgbW9kdWxlLWZldGNoIHBhdGggcmVzb2x2ZXMgU0VTICsgQ29kZU1pcnJvciwgYW5kIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJzdGFydmVkXFxuU0VTIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkNvbXBhcnRtZW50XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBydW5zIGluLXBsYXRmb3JtXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCB0aGUgZW5naW5lIHJlYWxtJ3MgY29yZSBzZWN1cml0eSBwcm9wZXJ0eSAobm8gYW1iaWVudFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcImZldGNoXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiByZWFjaGFibGUgZnJvbSBjb25maW5lZCBjb2RlKSBob2xkcyBpbnNpZGUgdGhlIHNhbmRib3hlZCBvcGFxdWUtb3JpZ2luIGlmcmFtZS4gVGhlXFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJlbmdpbmUgcmVhbG0gKFNFUykgYW5kIGVkaXRvciByZWFsbSAoQ29kZU1pcnJvcikgYXJlIGJ1aWxkYWJsZSBpbi1wbGF0Zm9ybS5cIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVHdvIGluZGVwZW5kZW50IGNvcnJvYm9yYXRpb25zOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQ29kZU1pcnJvciB3YXMgYWxyZWFkeSBwcm92ZW5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYmVmb3JlIHRoaXMgc3Bpa2U6IHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJpbW1lZGlhdGVseS1ydW4vZWRpdG9yXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhcHAgZGVwZW5kc1xcbm9uIHRoZSBmdWxsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkBjb2RlbWlycm9yLypcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHNldCBhbmQgcnVucyBhcyBhIHByb2R1Y3Rpb24gaW1tZWRpYXRlbHkucnVuIGFwcCAoZWRpdG9yLWFzLWFwcCkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiVGhlIHJlc29sdXRpb24gcGF0aCBpcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImJsYXppbmdseS5pb1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAocHJpbWFyeSBDRE4pIOKGkiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImVzbS5zaFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoZmFsbGJhY2ssIHdoaWNoIHNlcnZlc1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcInNlc0AyLjIuMFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYXMgaXRzIFwifTxfY29tcG9uZW50cy5jb2RlPntcImFzc2VydC1zaGltXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJjb21wYXJ0bWVudC1zaGltXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJsb2NrZG93bi1zaGltXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJzZXMubWpzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBzZXQpOyBlc20uc2ggaXNcXG5hbHJlYWR5IGluIHRoZSBzYW5kYm94IFwifTxfY29tcG9uZW50cy5jb2RlPntcImNvbm5lY3Qtc3JjXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgc28gbm8gQ1NQIGNoYW5nZSB3YXMgbmVlZGVkLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJjYXZlYXRzLXNjb3BlXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJjYXZlYXRzLXNjb3BlXCIgLz57XCJDYXZlYXRzIC8gc2NvcGVcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiVGhlIHNwaWtlIHJhbiBTRVMgaW4gdGhlIGFwcCdzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicmVuZGVyIGlmcmFtZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoY2FsbGluZyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJsb2NrZG93bigpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB0aGVyZSBkaXN0dXJicyBSZWFjdFxcbmFmdGVyIHRoZSBmYWN0LCB3aGljaCBpcyB3aHkgdGhlIHJlc3VsdCBpcyBsb2dnZWQgdG8gdGhlIGNvbnNvbGUgcHJlLXJlbmRlcikuIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiUHJvZHVjdGlvblxcbnJ1bnMgU0VTIGluIGEgZGVkaWNhdGVkIHdvcmtlclwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBpbnNpZGUgdGhlIGVuZ2luZSBlbnRyeS1wb2ludCAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQVJDSElURUNUVVJFX1BMQU5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIMKnNCksIHNvXFxubG9ja2Rvd24tdnMtUmVhY3QgY29leGlzdGVuY2UgaXMgYSBub24taXNzdWUgZm9yIHRoZSByZWFsIGVuZ2luZSDigJQgdGhpcyBzcGlrZSBvbmx5IGhhZCB0b1xcbnByb3ZlIFwifTxfY29tcG9uZW50cy5lbT57XCJyZXNvbHV0aW9uICsgSGFyZGVuZWQtSlMgZXhlY3V0aW9uXCJ9PC9fY29tcG9uZW50cy5lbT57XCIsIHdoaWNoIGl0IGRpZC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJTNSBpcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImRpc3RpbmN0IGZyb20gUzRiXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChhbiBpbi1wbGF0Zm9ybSBOb2RlLWVxdWl2YWxlbnQgQ0kgZ2F0ZSBmb3IgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYnVpbGRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcImxpbnRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcInZpdGVzdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvbXV0YXRpb24gb2YgdGhlIFR5cGVTY3JpcHQgXCJ9PF9jb21wb25lbnRzLmVtPntcInNvdXJjZVwifTwvX2NvbXBvbmVudHMuZW0+e1wiKS4gUzRiIHJlbWFpbnMgYSBnZW51aW5lIGdhcDsgc291cmNlLWxldmVsIENJXFxuc3RheXMgZXh0ZXJuYWwgdW50aWwgaXQgbGFuZHMuIFM1IGJlaW5nIHBvc2l0aXZlIGRvZXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJub3RcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgY2xvc2UgUzRiLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJyZXByb2R1Y2VcIj48SGVhZGluZ0FuY2hvciBpZD1cInJlcHJvZHVjZVwiIC8+e1wiUmVwcm9kdWNlXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucHJlPjxfY29tcG9uZW50cy5jb2RlIGNsYXNzTmFtZT1cImxhbmd1YWdlLWJhc2hcIj57XCIjIHN0YWNrIHVwOiBzYW5kYm94IHBhcmNlbCBvbiA6MTIzNCwgc2l0ZS1tYWluIG9uIDozMDAwLCBiZWhpbmQgdGhlIGxvY2FsIG5naW54XFxuY2Qgc2FuZGJveCAmJiBucHggcGFyY2VsIC4vc3JjL2luZGV4Lmh0bWwgLS1wb3J0IDEyMzQgJiAgICAgICAgICAjIChieXBhc3NlcyB0aGUgc3RhbGUtZGlzdCBwcmVkZXYgZ3VhcmQpXFxuY2QgaW1tZWRpYXRlbHktcnVuLXNpdGUtbWFpbiAmJiBCUk9XU0VSPW5vbmUgbnBtIHN0YXJ0ICYgICAgICAgICAgIyA6MzAwMFxcbiMgc2VydmUgdGhlIHNwaWtlIGFwcCArIGRyaXZlIGl0IGhlYWRsZXNzXFxuY2Qgc2NyYXRjaHBhZC9zZXMtc3Bpa2UgJiYgaW1tZWRpYXRlbHkucnVuIGRldiAuIC0tb3JpZ2luIGh0dHBzOi8vbG9jYWwuaW1tZWRpYXRlbHkucnVuIC0tanNvblxcbm5vZGUgZHJpdmUubWpzIFxcXCI8cHJpbnRlZCAvZWRpdC8uLi4vbGl2ZSPigKYgdXJsPlxcXCJcXG5cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5wcmU+PC8+O1xufVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTURYQ29udGVudChwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHt3cmFwcGVyOiBNRFhMYXlvdXR9ID0ge1xuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfTtcbiAgcmV0dXJuIE1EWExheW91dCA/IDxNRFhMYXlvdXQgey4uLnByb3BzfT48X2NyZWF0ZU1keENvbnRlbnQgey4uLnByb3BzfSAvPjwvTURYTGF5b3V0PiA6IF9jcmVhdGVNZHhDb250ZW50KHByb3BzKTtcbn1cbmZ1bmN0aW9uIF9taXNzaW5nTWR4UmVmZXJlbmNlKGlkLCBjb21wb25lbnQsIHBsYWNlKSB7XG4gIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIFwiICsgKGNvbXBvbmVudCA/IFwiY29tcG9uZW50XCIgOiBcIm9iamVjdFwiKSArIFwiIGBcIiArIGlkICsgXCJgIHRvIGJlIGRlZmluZWQ6IHlvdSBsaWtlbHkgZm9yZ290IHRvIGltcG9ydCwgcGFzcywgb3IgcHJvdmlkZSBpdC5cIiArIChwbGFjZSA/IFwiXFxuSXTigJlzIHJlZmVyZW5jZWQgaW4geW91ciBjb2RlIGF0IGBcIiArIHBsYWNlICsgXCJgIGluIGAvYXBwL2RvY3Mvc3Bpa2VzL1M1X1NFU19NT0RVTEVfUkVTT0xVVElPTi5tZGBcIiA6IFwiXCIpKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQXdGLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUZ4RjtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU1DLFdBQVcsR0FBRztNQUNsQkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsSUFBSSxFQUFFLE1BQU07TUFDWkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsR0FBRyxFQUFFLEtBQUs7TUFDVkMsTUFBTSxFQUFFLFFBQVE7TUFDaEJDLEVBQUUsRUFBRSxJQUFJO01BQ1IsR0FBRyxJQUFBQyw2QkFBa0IsRUFBQyxDQUFDO01BQ3ZCLEdBQUdaLEtBQUssQ0FBQ2E7SUFDWCxDQUFDO0lBQUU7TUFBQ0M7SUFBYSxDQUFDLEdBQUdiLFdBQVc7RUFDaEMsSUFBSSxDQUFDYSxhQUFhLEVBQUVDLG9CQUFvQixDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUM7RUFDL0Qsb0JBQU8sSUFBQWpCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQWxCLFdBQUEsQ0FBQW1CLFFBQUE7SUFBQUMsUUFBQSxnQkFBRSxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNJLEVBQUU7TUFBQ2MsRUFBRSxFQUFDLFFBQVE7TUFBQyxhQUFVLCtEQUErRDtNQUFBRCxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVEsQ0FBRSxDQUFDLEVBQUMsbUVBQW1FO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNPLENBQUM7TUFBQVUsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDUyxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFTLENBQXFCLENBQUMsRUFBQyxVQUFVLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBVSxDQUFxQixDQUFDLEVBQUMsNERBQTRELGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBSSxDQUFxQixDQUFDLEVBQUMsUUFBUSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNDLENBQUM7UUFBQ21CLElBQUksRUFBQyxvQ0FBb0M7UUFBQUgsUUFBQSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNFLElBQUk7VUFBQWUsUUFBQSxFQUFFO1FBQW9DLENBQW1CO01BQUMsQ0FBZSxDQUFDLEVBQUMsUUFBUSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNFLElBQUk7UUFBQWUsUUFBQSxFQUFFO01BQXNCLENBQW1CLENBQUMsRUFBQyxrQ0FBa0MsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRyxFQUFFO1FBQUFjLFFBQUEsRUFBRTtNQUFRLENBQWlCLENBQUMsRUFBQyxxQkFBcUI7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDYSxFQUFFLEVBQUMsVUFBVTtNQUFBRCxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVUsQ0FBRSxDQUFDLEVBQUMsVUFBVTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTyxDQUFDO01BQUFVLFFBQUEsR0FBRSxvQ0FBb0MsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDUyxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFtQixDQUFxQixDQUFDLEVBQUMsaUVBQWlFLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBSyxDQUFxQixDQUFDLEVBQUMsaURBQWlELGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBZSxRQUFBLEVBQUU7TUFBbUIsQ0FBbUIsQ0FBQyxFQUFDLFlBQVksZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDUyxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUFZLENBQXFCLENBQUMsRUFBQyxpQ0FBaUMsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDUyxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUEwQixDQUFxQixDQUFDLEVBQUMsOEVBQThFLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBK0MsQ0FBcUIsQ0FBQyxFQUFDLEdBQUc7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDYSxFQUFFLEVBQUMsUUFBUTtNQUFBRCxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVEsQ0FBRSxDQUFDLEVBQUMsUUFBUTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTyxDQUFDO01BQUFVLFFBQUEsR0FBRSxpQ0FBaUMsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRSxJQUFJO1FBQUFlLFFBQUEsRUFBRTtNQUF1QixDQUFtQixDQUFDLEVBQUMsU0FBUztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDVSxFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTSxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBYyxDQUFtQixDQUFDLEVBQUMsdUNBQXVDLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBVSxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNFLElBQUk7VUFBQWUsUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRSxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFRLENBQW1CLENBQUMsRUFBQyxTQUFTLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBaUQsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ00sRUFBRTtRQUFBVyxRQUFBLEdBQUUseURBQXlELGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBWSxDQUFtQixDQUFDLEVBQUMsaUJBQWlCLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsa0JBQWtCLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBZ0QsQ0FBbUIsQ0FBQyxFQUFDLDZCQUE2QixlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQVMsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRSxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUE4RCxDQUFtQixDQUFDLEVBQUMsOEJBQThCO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDTSxFQUFFO1FBQUFXLFFBQUEsRUFBRTtNQUF1RCxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTyxDQUFDO01BQUFVLFFBQUEsR0FBRSxrQ0FBa0MsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRSxJQUFJO1FBQUFlLFFBQUEsRUFBRTtNQUFPLENBQW1CLENBQUMsRUFBQyxjQUFjLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBZSxRQUFBLEVBQUU7TUFBOEQsQ0FBbUIsQ0FBQyxFQUFDLDBCQUEwQixlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNFLElBQUk7UUFBQWUsUUFBQSxFQUFFO01BQWdCLENBQW1CLENBQUMsRUFBQyxvQkFBb0IsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRSxJQUFJO1FBQUFlLFFBQUEsRUFBRTtNQUE2QixDQUFtQixDQUFDLEVBQUMsOEJBQThCLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBZSxRQUFBLEVBQUU7TUFBaUYsQ0FBbUIsQ0FBQyxFQUFDLDRHQUE0RyxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNFLElBQUk7UUFBQWUsUUFBQSxFQUFFO01BQVcsQ0FBbUIsQ0FBQyxFQUFDLHNDQUFzQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDSyxFQUFFO01BQUNhLEVBQUUsRUFBQyxpQkFBaUI7TUFBQUQsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFpQixDQUFFLENBQUMsRUFBQyxtQkFBbUI7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNRLEdBQUc7TUFBQVMsUUFBQSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNFLElBQUk7UUFBQWUsUUFBQSxFQUFFO01BQW1VLENBQW1CO0lBQUMsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDTyxDQUFDO01BQUFVLFFBQUEsRUFBRTtJQUFnRCxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ1UsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ00sRUFBRTtRQUFBVyxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQW1CLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBc0QsQ0FBbUIsQ0FBQyxFQUFDLHNFQUFzRSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQVEsQ0FBcUIsQ0FBQyxFQUFDLDBCQUEwQixlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNFLElBQUk7VUFBQWUsUUFBQSxFQUFFO1FBQU0sQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRSxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFvQixDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNFLElBQUk7VUFBQWUsUUFBQSxFQUFFO1FBQW9CLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBNkIsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRSxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFZLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsYUFBYSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNFLElBQUk7VUFBQWUsUUFBQSxFQUFFO1FBQUssQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNTLE1BQU07VUFBQVEsUUFBQSxHQUFFLFVBQVUsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRSxJQUFJO1lBQUFlLFFBQUEsRUFBRTtVQUFTLENBQW1CLENBQUMsRUFBQyxPQUFPO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLHlDQUF5QztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTSxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBNkMsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRSxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUE0QixDQUFtQixDQUFDLEVBQUMsb0JBQW9CO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDYSxFQUFFLEVBQUMsU0FBUztNQUFBRCxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVMsQ0FBRSxDQUFDLEVBQUMsU0FBUztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTyxDQUFDO01BQUFVLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBd0IsQ0FBcUIsQ0FBQyxFQUFDLDBEQUEwRCxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBUSxRQUFBLEdBQUUsZUFBZSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNFLElBQUk7VUFBQWUsUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQyxFQUFDLG1CQUFtQjtNQUFBLENBQXFCLENBQUMsRUFBQyw0REFBNEQsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRSxJQUFJO1FBQUFlLFFBQUEsRUFBRTtNQUFPLENBQW1CLENBQUMsRUFBQyx1RkFBdUYsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDUyxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUE2RSxDQUFxQixDQUFDO0lBQUEsQ0FBZSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNPLENBQUM7TUFBQVUsUUFBQSxFQUFFO0lBQWlDLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDVSxFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTSxFQUFFO1FBQUFXLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBK0IsQ0FBcUIsQ0FBQyxFQUFDLDBCQUEwQixlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNFLElBQUk7VUFBQWUsUUFBQSxFQUFFO1FBQXdCLENBQW1CLENBQUMsRUFBQyw0QkFBNEIsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRSxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFlLENBQW1CLENBQUMsRUFBQyxvRUFBb0U7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ00sRUFBRTtRQUFBVyxRQUFBLEdBQUUseUJBQXlCLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBYyxDQUFxQixDQUFDLEVBQUMsbUJBQW1CLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBUSxDQUFxQixDQUFDLEVBQUMsNEJBQTRCLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsVUFBVSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNFLElBQUk7VUFBQWUsUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRSxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFrQixDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNFLElBQUk7VUFBQWUsUUFBQSxFQUFFO1FBQWUsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRSxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFTLENBQW1CLENBQUMsRUFBQywyQ0FBMkMsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRSxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyxnQ0FBZ0M7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDSyxFQUFFO01BQUNhLEVBQUUsRUFBQyxlQUFlO01BQUFELFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBZSxDQUFFLENBQUMsRUFBQyxpQkFBaUI7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ1UsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ00sRUFBRTtRQUFBVyxRQUFBLEdBQUUsaUNBQWlDLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBZSxDQUFxQixDQUFDLEVBQUMsWUFBWSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNFLElBQUk7VUFBQWUsUUFBQSxFQUFFO1FBQVksQ0FBbUIsQ0FBQyxFQUFDLHVHQUF1RyxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQTRDLENBQXFCLENBQUMsRUFBQyxrQ0FBa0MsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRSxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFtQixDQUFtQixDQUFDLEVBQUMsNkdBQTZHLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0csRUFBRTtVQUFBYyxRQUFBLEVBQUU7UUFBb0MsQ0FBaUIsQ0FBQyxFQUFDLGlCQUFpQjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTSxFQUFFO1FBQUFXLFFBQUEsR0FBRSxRQUFRLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBbUIsQ0FBcUIsQ0FBQyxFQUFDLCtDQUErQyxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNFLElBQUk7VUFBQWUsUUFBQSxFQUFFO1FBQU8sQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRSxJQUFJO1VBQUFlLFFBQUEsRUFBRTtRQUFNLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBZSxRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsOEJBQThCLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0csRUFBRTtVQUFBYyxRQUFBLEVBQUU7UUFBUSxDQUFpQixDQUFDLEVBQUMsdUdBQXVHLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBSyxDQUFxQixDQUFDLEVBQUMsYUFBYTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNLLEVBQUU7TUFBQ2EsRUFBRSxFQUFDLFdBQVc7TUFBQUQsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFXLENBQUUsQ0FBQyxFQUFDLFdBQVc7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNRLEdBQUc7TUFBQVMsUUFBQSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNFLElBQUk7UUFBQ21CLFNBQVMsRUFBQyxlQUFlO1FBQUFKLFFBQUEsRUFBRTtNQUF1YyxDQUFtQjtJQUFDLENBQWlCLENBQUM7RUFBQSxDQUFFLENBQUM7QUFDeHFTO0FBQ2UsU0FBU0ssVUFBVUEsQ0FBQ3ZCLEtBQUssR0FBRyxDQUFDLENBQUMsRUFBRTtFQUM3QyxNQUFNO0lBQUN3QixPQUFPLEVBQUVDO0VBQVMsQ0FBQyxHQUFHO0lBQzNCLEdBQUcsSUFBQWIsNkJBQWtCLEVBQUMsQ0FBQztJQUN2QixHQUFHWixLQUFLLENBQUNhO0VBQ1gsQ0FBQztFQUNELE9BQU9ZLFNBQVMsZ0JBQUcsSUFBQTNCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ0ssU0FBUztJQUFBLEdBQUt6QixLQUFLO0lBQUFrQixRQUFBLGVBQUUsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ3JCLGlCQUFpQjtNQUFBLEdBQUtDO0lBQUssQ0FBRztFQUFDLENBQVcsQ0FBQyxHQUFHRCxpQkFBaUIsQ0FBQ0MsS0FBSyxDQUFDO0FBQ2xIO0FBQUMwQixFQUFBLEdBTnVCSCxVQUFVO0FBT2xDLFNBQVNSLG9CQUFvQkEsQ0FBQ0ksRUFBRSxFQUFFUSxTQUFTLEVBQUVDLEtBQUssRUFBRTtFQUNsRCxNQUFNLElBQUlDLEtBQUssQ0FBQyxXQUFXLElBQUlGLFNBQVMsR0FBRyxXQUFXLEdBQUcsUUFBUSxDQUFDLEdBQUcsSUFBSSxHQUFHUixFQUFFLEdBQUcsb0VBQW9FLElBQUlTLEtBQUssR0FBRyxxQ0FBcUMsR0FBR0EsS0FBSyxHQUFHLHFEQUFxRCxHQUFHLEVBQUUsQ0FBQyxDQUFDO0FBQy9RO0FBQUMsSUFBQUYsRUFBQTtBQUFBSSxZQUFBLENBQUFKLEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}