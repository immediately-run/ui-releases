var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      blockquote: "blockquote",
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      hr: "hr",
      li: "li",
      ol: "ol",
      p: "p",
      strong: "strong",
      table: "table",
      tbody: "tbody",
      td: "td",
      th: "th",
      thead: "thead",
      tr: "tr",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "reckoner-axis-2-self-hosting-work-items-dogfooding",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "reckoner-axis-2-self-hosting-work-items-dogfooding"
      }), "Reckoner — Axis-2 self-hosting work items (dogfooding)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Status:"
      }), " work items — the first concrete Axis-2 (dogfooding) tasks from\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ARCHITECTURE_PLAN.md"
      }), " §0.2. Reckoner forces not only the platform's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "runtime"
      }), " capabilities\n(the nine deltas) but its ability to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "host its own development"
      }), ". These are the platform\nself-hosting gaps that keep Reckoner development from being fully in-platform, scoped as\nactionable items. · ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Updated:"
      }), " 2026-08-27"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Reads first:"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ARCHITECTURE_PLAN.md"
        }), " §0.2 (the dogfooding stance + the S1–S6 gradient),\n§10 (the in-platform work-item tags); ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "LOCAL_DEVELOPMENT_SPEC.md"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "EDITOR_AS_APP_SPEC.md"
        }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "AGENT_AUTHORING_ARCHITECTURE.md"
        }), " (the existing in-platform dev loop)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The remaining gating gap is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "S4"
      }), " (an in-platform Node-equivalent CI gate); ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "S3"
      }), "\n(in-platform commit/push) was resolved by reconciliation 2026-07-15 — the loop already ships\non ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "protocol-contribute"
      }), " (see the §S3 correction note). S4 splits into a cheap in-platform\nwin and a hard platform capability. S1/S2/S5/S6 are listed for context with their status."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-s3",
      "data-slug": "s3-in-platform-commit-push-close-the-content-authoring-loop-near-term-high-leverage",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-s3"
      }), "S3 — In-platform commit & push (close the content-authoring loop)  · ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "near-term, high-leverage"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.em, {
          children: ["(Correction, 2026-07-15 — resolves roadmap R3-230 by reconciliation, not new code: the\n\"current state\" below was stale at verification. The write half of VCS already ships on the\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "protocol-contribute"
            })
          }), " surface, not ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "VcsControl"
          }), ": ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "contribute()"
          }), " (SDK) → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "protocol-contribute run"
          }), " (site-main ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "requestDispatcher.ts"
          }), ") → the contribution orchestrator, whose ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "direct-commit"
          }), "\nmode commits the CoW overlay and pushes (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "updateRef"
          }), ") to the mounted/designated branch —\nhost-driven, token host-held, typed error events with non-fast-forward recovery. The editor\naffordance is the activity rail's \"Source\" panel (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "panel.contribute"
          }), ", the contribute-panel app,\nbuild-default ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "contribute:any"
          }), " + first-party ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "contribute:direct"
          }), ") with a commit-message box and\na \"Commit directly\" mode, plus the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "modal.contribute"
          }), " save dialog. The acceptance bullets below\nare therefore met today; extending ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "VcsControl"
          }), " with a parallel ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "commit"
          }), " was rejected — it would\nadd a second write path/gate for an authority whose single chokepoint is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "protocol-contribute"
          }), "\n(docs ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "ways_of_working"
          }), " §2/§5).)"]
        })
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Goal."
      }), " An author editing Reckoner content (worksheets, templates, fixtures, docs) in the\nplatform editor can ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "commit and push to the designated branch without leaving the platform"
      }), " —\nno local git, no terminal."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Current state (verified 2026-07-09)."
      }), " The in-platform dev loop is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "most"
      }), " of the way there:\nthe editor holds an in-browser working tree with a Copy-on-Write overlay\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "LOCAL_DEVELOPMENT_SPEC"
      }), " §6.2), the agent write-port (AA-23) can write to it, and the\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "VcsControl"
      }), " surface (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "immediately-run-site-main/src/editor/requestDispatcher.ts"
      }), " →\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "VcsControl"
      }), ") exposes ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "diff viewing, PR viewing, and working-tree reset"
      }), ". What it does ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "not"
      }), "\nexpose is the write half of VCS."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Gap."
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "VcsControl"
      }), " has ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "refreshDiff"
      }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "refreshPRs"
      }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "resetWorkingTree"
      }), " — but ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["no\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "commit"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "push"
        }), ", or ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "createBranch"
        }), "."]
      }), " The CoW overlay accumulates edits an author cannot land\nfrom inside the platform; committing still requires dropping to local git (the exact \"leave the\nplatform\" step dogfooding is meant to remove)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Deliverable."
      }), " Extend ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "VcsControl"
      }), " (and the host-side VCS channel — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "SandboxListener"
      }), " →\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "CHANNEL.vcs"
      }), ") with a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "host-driven commit + push"
      }), " action: stage the CoW overlay → commit with\na message → push to the session's designated branch, gated on the same auth the platform already\nholds (the user's GitHub identity, host-driven — the app never sees the token, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "§8"
      }), " credential\nrule). Surface it as an editor affordance, not an app-rendered git UI."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Acceptance."
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: "An author edits a worksheet/template/doc in the editor, opens the VCS surface, writes a commit\nmessage, and the change lands on the designated branch — round-trip inside the platform."
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: "The app never handles the token; push uses the host-driven identity."
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: "Reset still works; a failed push surfaces a typed error, not a crash."
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "In-platform tag:"
      }), " ✅ (this ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "is"
      }), " the item that makes S1's content loop fully in-platform).\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Owner:"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "immediately-run-site-main"
      }), " (editor VCS surface). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Depends on:"
      }), " nothing new — the\nworking tree, auth, and VCS channel all exist; this is exposing the write half."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-s4",
      "data-slug": "s4-in-platform-testci-gate-split-cheap-win-now-hard-capability-tracked",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-s4"
      }), "S4 — In-platform test/CI gate  · ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "split: cheap win now, hard capability tracked"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Goal."
      }), " The gates CLAUDE.md requires before \"done\" (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "npm run build"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "npm run lint"
      }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "npm test"
      }), ", mutation testing) are runnable ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "inside the platform"
      }), ", so a dogfooded change can be\nverified without external CI."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Current state."
      }), " Split by what actually needs Node:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Document-level checks are already in-platform (S2)."
        }), " Reckoner's tests-as-cells run ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "in the\nbrowser engine"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ARCHITECTURE_PLAN §6"
        }), "); a full-workbook test run is a browser operation.\nThe ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "runtime"
        }), " \"build\" is the browser transpile (no Node build step at runtime, per the\nimmediately.run model). So a document's correctness gate is in-platform ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "by construction"
        }), " once\nthe engine lands (M1)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Source-level TS CI is a genuine Node gap."
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "tsc"
        }), " type-check, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "eslint"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "vitest"
        }), " over the\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "app/engine source"
        }), ", and Stryker mutation testing are Node processes; nothing runs them\nin-browser today."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Deliverable — two parts:"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "S4a (cheap, now):"
        }), " formalize the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "in-platform document-test gate"
        }), " — a one-action\n\"run this workbook's suite\" in the editor that runs all test-cells in the engine and reports\npass/fail + kind-coverage + (later) mutation score, as the dogfooded equivalent of ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npm test"
        }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "for document content"
        }), ". Rides S2; no new platform capability. Ship with M1/M2."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "S4b (hard, tracked capability):"
        }), " an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "in-platform Node-equivalent runner"
        }), " for source-level\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "build"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "lint"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "unit-test"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "mutation"
        }), " — either a platform-hosted ephemeral Node runner\ntriggered from the editor, or (longer horizon) enough of the toolchain compiled to run in a\nworker. This is a real platform lift; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "until it exists, source-level CI stays external"
        }), " and\nthat is the honest exception the §0.2 ✗ tag marks. Track it as a platform capability, not a\nv1 Reckoner deliverable."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Acceptance."
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "S4a:"
        }), " an author runs the workbook suite from the editor and sees the same\nvalidated/pinned/untested verdicts the review surface shows — no terminal."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "S4b (when built):"
        }), " a source change's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "build"
        }), "+", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "lint"
        }), "+", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "unit-test"
        }), " verdict is available\nin-platform; until then, the plan/status honestly marks source CI as ✗ (external)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "S4a DELIVERED, 2026-08-27 (roadmap R3-231)."
        }), " The workbook panel carries a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Run\nsuite"
        }), " action and a one-line workbook-level summary\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Suite passed — 4 validated · 3 pinned · 3 untested of 10 cells."
        }), "), computed by\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/engine/suiteReport.ts"
        }), " from the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "same"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "SubjectResult.verdict"
        }), " map the cards\nrender. That sameness is the acceptance clause, so it is structural rather than\nincidental: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "classifyCell"
        }), " stays the single owner of the §6 rule and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "summarizeSuite"
        }), "\nonly counts — there is no second classification that could disagree with the cards\nbeneath it. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "useVerdicts"
        }), " gained ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "running"
        }), " + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "rerun"
        }), " so the action re-runs\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "engine.runTests()"
        }), " on demand rather than waiting for a recompute."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: ["Two things it deliberately is not. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Mutation score"
        }), " is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "(later)"
        }), " in this item and is\nan optional field that stays ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "absent"
        }), " until something measures it — never a zero that\nwould read as a measured 0%. And ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "ok"
          }), " means nothing failed, not that the workbook is\ncovered"]
        }), ": an entirely untested workbook is green by that measure, which is honest, and\nis why the coverage counts sit next to it instead of being folded into one number."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "S4b remains ✗ and is not scheduled."
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "tsc"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "eslint"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "vitest"
        }), " and Stryker are Node\nprocesses; nothing runs them in-browser, so source-level CI stays external. That is the\nhonest exception the §0.2 ✗ tag marks, and S4a does not narrow it — a document-test gate\nand a source CI gate answer different questions."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "In-platform tag:"
      }), " S4a ✅ (2026-08-27); S4b ✗ (needs the platform capability).\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Owner:"
      }), " S4a Reckoner (editor integration of the engine test run); S4b ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "immediately-run-site-main"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["platform. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Depends on:"
        }), " S4a → the engine (M1) + S2; S4b → a platform runner (new)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "context-the-rest-of-the-s-series-status-only",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "context-the-rest-of-the-s-series-status-only"
      }), "Context — the rest of the S-series (status only)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "#"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Capability"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "State"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Note"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "S1"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Edit → live-preview loop for content & source"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "✅ exists"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["editor + agent write-port + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "local"
            }), " provider host preview"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "S2"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "In-platform document-test execution"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "◐ by construction at M1"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "tests-as-cells run in the engine; S4a exposes it"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "S3"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "In-platform commit/push"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["✅ ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "delivered"
            }), " (reconciled 2026-07-15)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["ships on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "protocol-contribute"
            }), " + the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "panel.contribute"
            }), " affordance — see the §S3 correction note"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "S4"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "In-platform CI gate"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "S4a ✅ (2026-08-27) / S4b ✗"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "the workbook suite runs from the editor with the review surface's own verdicts; source CI is the tracked gap"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "S5"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Dep resolution for SES / CodeMirror in-platform"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["✅ ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "proven"
            }), " (2026-07-12)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["live spike: the module-fetch path resolves ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "ses"
            }), "+", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "@endo/*"
            }), "+", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "@codemirror/*"
            }), ", and a starved SES ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "Compartment"
            }), " runs in-platform — see ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
              href: "spikes/S5_SES_MODULE_RESOLUTION.md",
              children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                children: "spikes/S5_SES_MODULE_RESOLUTION.md"
              })
            })]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "S6"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Run the real four-realm composite in-platform"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "✗ gated on D1–D9"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["the recursion; resolves as the deltas land (M3) — and needs Spine 2's topology to express a multi-appKey launch (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "COMPOSITE_CAPABILITY_TOPOLOGY_SPEC"
            }), " OQ-3)"]
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "recommended-order",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "recommended-order"
      }), "Recommended order"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "S3"
        }), " — ✅ ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "delivered by reconciliation"
        }), " (2026-07-15): the content-authoring commit/push\nloop already ships on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "protocol-contribute"
        }), " (see the §S3 correction note); no new code."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "S4a"
        }), " — ✅ ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "delivered"
        }), " (2026-08-27, R3-231): the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Run suite"
        }), " action + the\nworkbook-level summary in the review panel, from the review surface's own verdicts."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "S5 spike"
        }), " — ✅ ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "DONE, positive"
        }), " (2026-07-12): the module-fetch path resolves\nSES + CodeMirror and a starved SES ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Compartment"
        }), " runs in-platform, so the engine realm is\nbuildable in-platform. Findings: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "spikes/S5_SES_MODULE_RESOLUTION.md",
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "spikes/S5_SES_MODULE_RESOLUTION.md"
          })
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "S4b / S6"
        }), " — tracked platform capabilities, not v1 Reckoner deliverables; the honest ✗\nitems whose closure is the deeper Axis-2 forcing-function contribution."]
      }), "\n"]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/AXIS2_SELF_HOSTING_WORKITEMS.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiYmxvY2txdW90ZSIsImNvZGUiLCJlbSIsImgxIiwiaDIiLCJociIsImxpIiwib2wiLCJwIiwic3Ryb25nIiwidGFibGUiLCJ0Ym9keSIsInRkIiwidGgiLCJ0aGVhZCIsInRyIiwidWwiLCJfcHJvdmlkZUNvbXBvbmVudHMiLCJjb21wb25lbnRzIiwiSGVhZGluZ0FuY2hvciIsIl9taXNzaW5nTWR4UmVmZXJlbmNlIiwianN4cyIsIkZyYWdtZW50IiwiY2hpbGRyZW4iLCJpZCIsImpzeCIsImhyZWYiLCJNRFhDb250ZW50Iiwid3JhcHBlciIsIk1EWExheW91dCIsIl9jIiwiY29tcG9uZW50IiwicGxhY2UiLCJFcnJvciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkFYSVMyX1NFTEZfSE9TVElOR19XT1JLSVRFTVMubWQiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgYTogXCJhXCIsXG4gICAgYmxvY2txdW90ZTogXCJibG9ja3F1b3RlXCIsXG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgZW06IFwiZW1cIixcbiAgICBoMTogXCJoMVwiLFxuICAgIGgyOiBcImgyXCIsXG4gICAgaHI6IFwiaHJcIixcbiAgICBsaTogXCJsaVwiLFxuICAgIG9sOiBcIm9sXCIsXG4gICAgcDogXCJwXCIsXG4gICAgc3Ryb25nOiBcInN0cm9uZ1wiLFxuICAgIHRhYmxlOiBcInRhYmxlXCIsXG4gICAgdGJvZHk6IFwidGJvZHlcIixcbiAgICB0ZDogXCJ0ZFwiLFxuICAgIHRoOiBcInRoXCIsXG4gICAgdGhlYWQ6IFwidGhlYWRcIixcbiAgICB0cjogXCJ0clwiLFxuICAgIHVsOiBcInVsXCIsXG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9LCB7SGVhZGluZ0FuY2hvcn0gPSBfY29tcG9uZW50cztcbiAgaWYgKCFIZWFkaW5nQW5jaG9yKSBfbWlzc2luZ01keFJlZmVyZW5jZShcIkhlYWRpbmdBbmNob3JcIiwgdHJ1ZSk7XG4gIHJldHVybiA8PjxfY29tcG9uZW50cy5oMSBpZD1cInJlY2tvbmVyLWF4aXMtMi1zZWxmLWhvc3Rpbmctd29yay1pdGVtcy1kb2dmb29kaW5nXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJyZWNrb25lci1heGlzLTItc2VsZi1ob3N0aW5nLXdvcmstaXRlbXMtZG9nZm9vZGluZ1wiIC8+e1wiUmVja29uZXIg4oCUIEF4aXMtMiBzZWxmLWhvc3Rpbmcgd29yayBpdGVtcyAoZG9nZm9vZGluZylcIn08L19jb21wb25lbnRzLmgxPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiU3RhdHVzOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB3b3JrIGl0ZW1zIOKAlCB0aGUgZmlyc3QgY29uY3JldGUgQXhpcy0yIChkb2dmb29kaW5nKSB0YXNrcyBmcm9tXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQVJDSElURUNUVVJFX1BMQU4ubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIMKnMC4yLiBSZWNrb25lciBmb3JjZXMgbm90IG9ubHkgdGhlIHBsYXRmb3JtJ3MgXCJ9PF9jb21wb25lbnRzLmVtPntcInJ1bnRpbWVcIn08L19jb21wb25lbnRzLmVtPntcIiBjYXBhYmlsaXRpZXNcXG4odGhlIG5pbmUgZGVsdGFzKSBidXQgaXRzIGFiaWxpdHkgdG8gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJob3N0IGl0cyBvd24gZGV2ZWxvcG1lbnRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIuIFRoZXNlIGFyZSB0aGUgcGxhdGZvcm1cXG5zZWxmLWhvc3RpbmcgZ2FwcyB0aGF0IGtlZXAgUmVja29uZXIgZGV2ZWxvcG1lbnQgZnJvbSBiZWluZyBmdWxseSBpbi1wbGF0Zm9ybSwgc2NvcGVkIGFzXFxuYWN0aW9uYWJsZSBpdGVtcy4gwrcgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJVcGRhdGVkOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAyMDI2LTA4LTI3XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUmVhZHMgZmlyc3Q6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkFSQ0hJVEVDVFVSRV9QTEFOLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDCpzAuMiAodGhlIGRvZ2Zvb2Rpbmcgc3RhbmNlICsgdGhlIFMx4oCTUzYgZ3JhZGllbnQpLFxcbsKnMTAgKHRoZSBpbi1wbGF0Zm9ybSB3b3JrLWl0ZW0gdGFncyk7IFwifTxfY29tcG9uZW50cy5jb2RlPntcIkxPQ0FMX0RFVkVMT1BNRU5UX1NQRUMubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJFRElUT1JfQVNfQVBQX1NQRUMubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcIkFHRU5UX0FVVEhPUklOR19BUkNISVRFQ1RVUkUubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICh0aGUgZXhpc3RpbmcgaW4tcGxhdGZvcm0gZGV2IGxvb3ApLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08L19jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIHJlbWFpbmluZyBnYXRpbmcgZ2FwIGlzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiUzRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKGFuIGluLXBsYXRmb3JtIE5vZGUtZXF1aXZhbGVudCBDSSBnYXRlKTsgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJTM1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIlxcbihpbi1wbGF0Zm9ybSBjb21taXQvcHVzaCkgd2FzIHJlc29sdmVkIGJ5IHJlY29uY2lsaWF0aW9uIDIwMjYtMDctMTUg4oCUIHRoZSBsb29wIGFscmVhZHkgc2hpcHNcXG5vbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJwcm90b2NvbC1jb250cmlidXRlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoc2VlIHRoZSDCp1MzIGNvcnJlY3Rpb24gbm90ZSkuIFM0IHNwbGl0cyBpbnRvIGEgY2hlYXAgaW4tcGxhdGZvcm1cXG53aW4gYW5kIGEgaGFyZCBwbGF0Zm9ybSBjYXBhYmlsaXR5LiBTMS9TMi9TNS9TNiBhcmUgbGlzdGVkIGZvciBjb250ZXh0IHdpdGggdGhlaXIgc3RhdHVzLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaHIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtczNcIiBkYXRhLXNsdWc9XCJzMy1pbi1wbGF0Zm9ybS1jb21taXQtcHVzaC1jbG9zZS10aGUtY29udGVudC1hdXRob3JpbmctbG9vcC1uZWFyLXRlcm0taGlnaC1sZXZlcmFnZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLXMzXCIgLz57XCJTMyDigJQgSW4tcGxhdGZvcm0gY29tbWl0ICYgcHVzaCAoY2xvc2UgdGhlIGNvbnRlbnQtYXV0aG9yaW5nIGxvb3ApICDCtyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5lYXItdGVybSwgaGlnaC1sZXZlcmFnZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLmVtPntcIihDb3JyZWN0aW9uLCAyMDI2LTA3LTE1IOKAlCByZXNvbHZlcyByb2FkbWFwIFIzLTIzMCBieSByZWNvbmNpbGlhdGlvbiwgbm90IG5ldyBjb2RlOiB0aGVcXG5cXFwiY3VycmVudCBzdGF0ZVxcXCIgYmVsb3cgd2FzIHN0YWxlIGF0IHZlcmlmaWNhdGlvbi4gVGhlIHdyaXRlIGhhbGYgb2YgVkNTIGFscmVhZHkgc2hpcHMgb24gdGhlXFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz48X2NvbXBvbmVudHMuY29kZT57XCJwcm90b2NvbC1jb250cmlidXRlXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBzdXJmYWNlLCBub3QgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiVmNzQ29udHJvbFwifTwvX2NvbXBvbmVudHMuY29kZT57XCI6IFwifTxfY29tcG9uZW50cy5jb2RlPntcImNvbnRyaWJ1dGUoKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKFNESykg4oaSIFwifTxfY29tcG9uZW50cy5jb2RlPntcInByb3RvY29sLWNvbnRyaWJ1dGUgcnVuXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoc2l0ZS1tYWluIFwifTxfY29tcG9uZW50cy5jb2RlPntcInJlcXVlc3REaXNwYXRjaGVyLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikg4oaSIHRoZSBjb250cmlidXRpb24gb3JjaGVzdHJhdG9yLCB3aG9zZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJkaXJlY3QtY29tbWl0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIlxcbm1vZGUgY29tbWl0cyB0aGUgQ29XIG92ZXJsYXkgYW5kIHB1c2hlcyAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widXBkYXRlUmVmXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikgdG8gdGhlIG1vdW50ZWQvZGVzaWduYXRlZCBicmFuY2gg4oCUXFxuaG9zdC1kcml2ZW4sIHRva2VuIGhvc3QtaGVsZCwgdHlwZWQgZXJyb3IgZXZlbnRzIHdpdGggbm9uLWZhc3QtZm9yd2FyZCByZWNvdmVyeS4gVGhlIGVkaXRvclxcbmFmZm9yZGFuY2UgaXMgdGhlIGFjdGl2aXR5IHJhaWwncyBcXFwiU291cmNlXFxcIiBwYW5lbCAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicGFuZWwuY29udHJpYnV0ZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIHRoZSBjb250cmlidXRlLXBhbmVsIGFwcCxcXG5idWlsZC1kZWZhdWx0IFwifTxfY29tcG9uZW50cy5jb2RlPntcImNvbnRyaWJ1dGU6YW55XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiArIGZpcnN0LXBhcnR5IFwifTxfY29tcG9uZW50cy5jb2RlPntcImNvbnRyaWJ1dGU6ZGlyZWN0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikgd2l0aCBhIGNvbW1pdC1tZXNzYWdlIGJveCBhbmRcXG5hIFxcXCJDb21taXQgZGlyZWN0bHlcXFwiIG1vZGUsIHBsdXMgdGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1vZGFsLmNvbnRyaWJ1dGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHNhdmUgZGlhbG9nLiBUaGUgYWNjZXB0YW5jZSBidWxsZXRzIGJlbG93XFxuYXJlIHRoZXJlZm9yZSBtZXQgdG9kYXk7IGV4dGVuZGluZyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJWY3NDb250cm9sXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB3aXRoIGEgcGFyYWxsZWwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY29tbWl0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB3YXMgcmVqZWN0ZWQg4oCUIGl0IHdvdWxkXFxuYWRkIGEgc2Vjb25kIHdyaXRlIHBhdGgvZ2F0ZSBmb3IgYW4gYXV0aG9yaXR5IHdob3NlIHNpbmdsZSBjaG9rZXBvaW50IGlzIFwifTxfY29tcG9uZW50cy5jb2RlPntcInByb3RvY29sLWNvbnRyaWJ1dGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxuKGRvY3MgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wid2F5c19vZl93b3JraW5nXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDCpzIvwqc1KS4pXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiR29hbC5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgQW4gYXV0aG9yIGVkaXRpbmcgUmVja29uZXIgY29udGVudCAod29ya3NoZWV0cywgdGVtcGxhdGVzLCBmaXh0dXJlcywgZG9jcykgaW4gdGhlXFxucGxhdGZvcm0gZWRpdG9yIGNhbiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImNvbW1pdCBhbmQgcHVzaCB0byB0aGUgZGVzaWduYXRlZCBicmFuY2ggd2l0aG91dCBsZWF2aW5nIHRoZSBwbGF0Zm9ybVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJRcXG5ubyBsb2NhbCBnaXQsIG5vIHRlcm1pbmFsLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkN1cnJlbnQgc3RhdGUgKHZlcmlmaWVkIDIwMjYtMDctMDkpLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGUgaW4tcGxhdGZvcm0gZGV2IGxvb3AgaXMgXCJ9PF9jb21wb25lbnRzLmVtPntcIm1vc3RcIn08L19jb21wb25lbnRzLmVtPntcIiBvZiB0aGUgd2F5IHRoZXJlOlxcbnRoZSBlZGl0b3IgaG9sZHMgYW4gaW4tYnJvd3NlciB3b3JraW5nIHRyZWUgd2l0aCBhIENvcHktb24tV3JpdGUgb3ZlcmxheVxcbihcIn08X2NvbXBvbmVudHMuY29kZT57XCJMT0NBTF9ERVZFTE9QTUVOVF9TUEVDXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDCpzYuMiksIHRoZSBhZ2VudCB3cml0ZS1wb3J0IChBQS0yMykgY2FuIHdyaXRlIHRvIGl0LCBhbmQgdGhlXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiVmNzQ29udHJvbFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgc3VyZmFjZSAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW1tZWRpYXRlbHktcnVuLXNpdGUtbWFpbi9zcmMvZWRpdG9yL3JlcXVlc3REaXNwYXRjaGVyLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDihpJcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJWY3NDb250cm9sXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikgZXhwb3NlcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImRpZmYgdmlld2luZywgUFIgdmlld2luZywgYW5kIHdvcmtpbmctdHJlZSByZXNldFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIi4gV2hhdCBpdCBkb2VzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibm90XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiXFxuZXhwb3NlIGlzIHRoZSB3cml0ZSBoYWxmIG9mIFZDUy5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJHYXAuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlZjc0NvbnRyb2xcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGhhcyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyZWZyZXNoRGlmZlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgLyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyZWZyZXNoUFJzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAvIFwifTxfY29tcG9uZW50cy5jb2RlPntcInJlc2V0V29ya2luZ1RyZWVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCBidXQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJub1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcImNvbW1pdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcInB1c2hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBvciBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjcmVhdGVCcmFuY2hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGUgQ29XIG92ZXJsYXkgYWNjdW11bGF0ZXMgZWRpdHMgYW4gYXV0aG9yIGNhbm5vdCBsYW5kXFxuZnJvbSBpbnNpZGUgdGhlIHBsYXRmb3JtOyBjb21taXR0aW5nIHN0aWxsIHJlcXVpcmVzIGRyb3BwaW5nIHRvIGxvY2FsIGdpdCAodGhlIGV4YWN0IFxcXCJsZWF2ZSB0aGVcXG5wbGF0Zm9ybVxcXCIgc3RlcCBkb2dmb29kaW5nIGlzIG1lYW50IHRvIHJlbW92ZSkuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRGVsaXZlcmFibGUuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIEV4dGVuZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJWY3NDb250cm9sXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoYW5kIHRoZSBob3N0LXNpZGUgVkNTIGNoYW5uZWwg4oCUIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlNhbmRib3hMaXN0ZW5lclwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oaSXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQ0hBTk5FTC52Y3NcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSB3aXRoIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJob3N0LWRyaXZlbiBjb21taXQgKyBwdXNoXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGFjdGlvbjogc3RhZ2UgdGhlIENvVyBvdmVybGF5IOKGkiBjb21taXQgd2l0aFxcbmEgbWVzc2FnZSDihpIgcHVzaCB0byB0aGUgc2Vzc2lvbidzIGRlc2lnbmF0ZWQgYnJhbmNoLCBnYXRlZCBvbiB0aGUgc2FtZSBhdXRoIHRoZSBwbGF0Zm9ybSBhbHJlYWR5XFxuaG9sZHMgKHRoZSB1c2VyJ3MgR2l0SHViIGlkZW50aXR5LCBob3N0LWRyaXZlbiDigJQgdGhlIGFwcCBuZXZlciBzZWVzIHRoZSB0b2tlbiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiwqc4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjcmVkZW50aWFsXFxucnVsZSkuIFN1cmZhY2UgaXQgYXMgYW4gZWRpdG9yIGFmZm9yZGFuY2UsIG5vdCBhbiBhcHAtcmVuZGVyZWQgZ2l0IFVJLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkFjY2VwdGFuY2UuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiQW4gYXV0aG9yIGVkaXRzIGEgd29ya3NoZWV0L3RlbXBsYXRlL2RvYyBpbiB0aGUgZWRpdG9yLCBvcGVucyB0aGUgVkNTIHN1cmZhY2UsIHdyaXRlcyBhIGNvbW1pdFxcbm1lc3NhZ2UsIGFuZCB0aGUgY2hhbmdlIGxhbmRzIG9uIHRoZSBkZXNpZ25hdGVkIGJyYW5jaCDigJQgcm91bmQtdHJpcCBpbnNpZGUgdGhlIHBsYXRmb3JtLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIlRoZSBhcHAgbmV2ZXIgaGFuZGxlcyB0aGUgdG9rZW47IHB1c2ggdXNlcyB0aGUgaG9zdC1kcml2ZW4gaWRlbnRpdHkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiUmVzZXQgc3RpbGwgd29ya3M7IGEgZmFpbGVkIHB1c2ggc3VyZmFjZXMgYSB0eXBlZCBlcnJvciwgbm90IGEgY3Jhc2guXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiSW4tcGxhdGZvcm0gdGFnOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDinIUgKHRoaXMgXCJ9PF9jb21wb25lbnRzLmVtPntcImlzXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgdGhlIGl0ZW0gdGhhdCBtYWtlcyBTMSdzIGNvbnRlbnQgbG9vcCBmdWxseSBpbi1wbGF0Zm9ybSkuXFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJPd25lcjpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW1tZWRpYXRlbHktcnVuLXNpdGUtbWFpblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKGVkaXRvciBWQ1Mgc3VyZmFjZSkuIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiRGVwZW5kcyBvbjpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgbm90aGluZyBuZXcg4oCUIHRoZVxcbndvcmtpbmcgdHJlZSwgYXV0aCwgYW5kIFZDUyBjaGFubmVsIGFsbCBleGlzdDsgdGhpcyBpcyBleHBvc2luZyB0aGUgd3JpdGUgaGFsZi5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmhyIC8+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLXM0XCIgZGF0YS1zbHVnPVwiczQtaW4tcGxhdGZvcm0tdGVzdGNpLWdhdGUtc3BsaXQtY2hlYXAtd2luLW5vdy1oYXJkLWNhcGFiaWxpdHktdHJhY2tlZFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLXM0XCIgLz57XCJTNCDigJQgSW4tcGxhdGZvcm0gdGVzdC9DSSBnYXRlICDCtyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInNwbGl0OiBjaGVhcCB3aW4gbm93LCBoYXJkIGNhcGFiaWxpdHkgdHJhY2tlZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJHb2FsLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGUgZ2F0ZXMgQ0xBVURFLm1kIHJlcXVpcmVzIGJlZm9yZSBcXFwiZG9uZVxcXCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIm5wbSBydW4gYnVpbGRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJucG0gcnVuIGxpbnRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcIm5wbSB0ZXN0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgbXV0YXRpb24gdGVzdGluZykgYXJlIHJ1bm5hYmxlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiaW5zaWRlIHRoZSBwbGF0Zm9ybVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgc28gYSBkb2dmb29kZWQgY2hhbmdlIGNhbiBiZVxcbnZlcmlmaWVkIHdpdGhvdXQgZXh0ZXJuYWwgQ0kuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQ3VycmVudCBzdGF0ZS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgU3BsaXQgYnkgd2hhdCBhY3R1YWxseSBuZWVkcyBOb2RlOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRG9jdW1lbnQtbGV2ZWwgY2hlY2tzIGFyZSBhbHJlYWR5IGluLXBsYXRmb3JtIChTMikuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFJlY2tvbmVyJ3MgdGVzdHMtYXMtY2VsbHMgcnVuIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiaW4gdGhlXFxuYnJvd3NlciBlbmdpbmVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIkFSQ0hJVEVDVFVSRV9QTEFOIMKnNlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpOyBhIGZ1bGwtd29ya2Jvb2sgdGVzdCBydW4gaXMgYSBicm93c2VyIG9wZXJhdGlvbi5cXG5UaGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJydW50aW1lXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFxcXCJidWlsZFxcXCIgaXMgdGhlIGJyb3dzZXIgdHJhbnNwaWxlIChubyBOb2RlIGJ1aWxkIHN0ZXAgYXQgcnVudGltZSwgcGVyIHRoZVxcbmltbWVkaWF0ZWx5LnJ1biBtb2RlbCkuIFNvIGEgZG9jdW1lbnQncyBjb3JyZWN0bmVzcyBnYXRlIGlzIGluLXBsYXRmb3JtIFwifTxfY29tcG9uZW50cy5lbT57XCJieSBjb25zdHJ1Y3Rpb25cIn08L19jb21wb25lbnRzLmVtPntcIiBvbmNlXFxudGhlIGVuZ2luZSBsYW5kcyAoTTEpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiU291cmNlLWxldmVsIFRTIENJIGlzIGEgZ2VudWluZSBOb2RlIGdhcC5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widHNjXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB0eXBlLWNoZWNrLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJlc2xpbnRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ2aXRlc3RcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG92ZXIgdGhlXFxuXCJ9PF9jb21wb25lbnRzLmVtPntcImFwcC9lbmdpbmUgc291cmNlXCJ9PC9fY29tcG9uZW50cy5lbT57XCIsIGFuZCBTdHJ5a2VyIG11dGF0aW9uIHRlc3RpbmcgYXJlIE5vZGUgcHJvY2Vzc2VzOyBub3RoaW5nIHJ1bnMgdGhlbVxcbmluLWJyb3dzZXIgdG9kYXkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRGVsaXZlcmFibGUg4oCUIHR3byBwYXJ0czpcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlM0YSAoY2hlYXAsIG5vdyk6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGZvcm1hbGl6ZSB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJpbi1wbGF0Zm9ybSBkb2N1bWVudC10ZXN0IGdhdGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIGEgb25lLWFjdGlvblxcblxcXCJydW4gdGhpcyB3b3JrYm9vaydzIHN1aXRlXFxcIiBpbiB0aGUgZWRpdG9yIHRoYXQgcnVucyBhbGwgdGVzdC1jZWxscyBpbiB0aGUgZW5naW5lIGFuZCByZXBvcnRzXFxucGFzcy9mYWlsICsga2luZC1jb3ZlcmFnZSArIChsYXRlcikgbXV0YXRpb24gc2NvcmUsIGFzIHRoZSBkb2dmb29kZWQgZXF1aXZhbGVudCBvZiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJucG0gdGVzdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImZvciBkb2N1bWVudCBjb250ZW50XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLiBSaWRlcyBTMjsgbm8gbmV3IHBsYXRmb3JtIGNhcGFiaWxpdHkuIFNoaXAgd2l0aCBNMS9NMi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlM0YiAoaGFyZCwgdHJhY2tlZCBjYXBhYmlsaXR5KTpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYW4gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJpbi1wbGF0Zm9ybSBOb2RlLWVxdWl2YWxlbnQgcnVubmVyXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGZvciBzb3VyY2UtbGV2ZWxcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJidWlsZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibGludFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widW5pdC10ZXN0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJtdXRhdGlvblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIGVpdGhlciBhIHBsYXRmb3JtLWhvc3RlZCBlcGhlbWVyYWwgTm9kZSBydW5uZXJcXG50cmlnZ2VyZWQgZnJvbSB0aGUgZWRpdG9yLCBvciAobG9uZ2VyIGhvcml6b24pIGVub3VnaCBvZiB0aGUgdG9vbGNoYWluIGNvbXBpbGVkIHRvIHJ1biBpbiBhXFxud29ya2VyLiBUaGlzIGlzIGEgcmVhbCBwbGF0Zm9ybSBsaWZ0OyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInVudGlsIGl0IGV4aXN0cywgc291cmNlLWxldmVsIENJIHN0YXlzIGV4dGVybmFsXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGFuZFxcbnRoYXQgaXMgdGhlIGhvbmVzdCBleGNlcHRpb24gdGhlIMKnMC4yIOKclyB0YWcgbWFya3MuIFRyYWNrIGl0IGFzIGEgcGxhdGZvcm0gY2FwYWJpbGl0eSwgbm90IGFcXG52MSBSZWNrb25lciBkZWxpdmVyYWJsZS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJBY2NlcHRhbmNlLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUzRhOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBhbiBhdXRob3IgcnVucyB0aGUgd29ya2Jvb2sgc3VpdGUgZnJvbSB0aGUgZWRpdG9yIGFuZCBzZWVzIHRoZSBzYW1lXFxudmFsaWRhdGVkL3Bpbm5lZC91bnRlc3RlZCB2ZXJkaWN0cyB0aGUgcmV2aWV3IHN1cmZhY2Ugc2hvd3Mg4oCUIG5vIHRlcm1pbmFsLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUzRiICh3aGVuIGJ1aWx0KTpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYSBzb3VyY2UgY2hhbmdlJ3MgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYnVpbGRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiK1wifTxfY29tcG9uZW50cy5jb2RlPntcImxpbnRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiK1wifTxfY29tcG9uZW50cy5jb2RlPntcInVuaXQtdGVzdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdmVyZGljdCBpcyBhdmFpbGFibGVcXG5pbi1wbGF0Zm9ybTsgdW50aWwgdGhlbiwgdGhlIHBsYW4vc3RhdHVzIGhvbmVzdGx5IG1hcmtzIHNvdXJjZSBDSSBhcyDinJcgKGV4dGVybmFsKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJTNGEgREVMSVZFUkVELCAyMDI2LTA4LTI3IChyb2FkbWFwIFIzLTIzMSkuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRoZSB3b3JrYm9vayBwYW5lbCBjYXJyaWVzIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJSdW5cXG5zdWl0ZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBhY3Rpb24gYW5kIGEgb25lLWxpbmUgd29ya2Jvb2stbGV2ZWwgc3VtbWFyeVxcbihcIn08X2NvbXBvbmVudHMuY29kZT57XCJTdWl0ZSBwYXNzZWQg4oCUIDQgdmFsaWRhdGVkIMK3IDMgcGlubmVkIMK3IDMgdW50ZXN0ZWQgb2YgMTAgY2VsbHMuXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiksIGNvbXB1dGVkIGJ5XFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2VuZ2luZS9zdWl0ZVJlcG9ydC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZnJvbSB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJzYW1lXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlN1YmplY3RSZXN1bHQudmVyZGljdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgbWFwIHRoZSBjYXJkc1xcbnJlbmRlci4gVGhhdCBzYW1lbmVzcyBpcyB0aGUgYWNjZXB0YW5jZSBjbGF1c2UsIHNvIGl0IGlzIHN0cnVjdHVyYWwgcmF0aGVyIHRoYW5cXG5pbmNpZGVudGFsOiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjbGFzc2lmeUNlbGxcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHN0YXlzIHRoZSBzaW5nbGUgb3duZXIgb2YgdGhlIMKnNiBydWxlIGFuZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzdW1tYXJpemVTdWl0ZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG5vbmx5IGNvdW50cyDigJQgdGhlcmUgaXMgbm8gc2Vjb25kIGNsYXNzaWZpY2F0aW9uIHRoYXQgY291bGQgZGlzYWdyZWUgd2l0aCB0aGUgY2FyZHNcXG5iZW5lYXRoIGl0LiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ1c2VWZXJkaWN0c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZ2FpbmVkIFwifTxfY29tcG9uZW50cy5jb2RlPntcInJ1bm5pbmdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicmVydW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHNvIHRoZSBhY3Rpb24gcmUtcnVuc1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcImVuZ2luZS5ydW5UZXN0cygpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBvbiBkZW1hbmQgcmF0aGVyIHRoYW4gd2FpdGluZyBmb3IgYSByZWNvbXB1dGUuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlR3byB0aGluZ3MgaXQgZGVsaWJlcmF0ZWx5IGlzIG5vdC4gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJNdXRhdGlvbiBzY29yZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBpcyBcIn08X2NvbXBvbmVudHMuY29kZT57XCIobGF0ZXIpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpbiB0aGlzIGl0ZW0gYW5kIGlzXFxuYW4gb3B0aW9uYWwgZmllbGQgdGhhdCBzdGF5cyBcIn08X2NvbXBvbmVudHMuZW0+e1wiYWJzZW50XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgdW50aWwgc29tZXRoaW5nIG1lYXN1cmVzIGl0IOKAlCBuZXZlciBhIHplcm8gdGhhdFxcbndvdWxkIHJlYWQgYXMgYSBtZWFzdXJlZCAwJS4gQW5kIFwifTxfY29tcG9uZW50cy5zdHJvbmc+PF9jb21wb25lbnRzLmNvZGU+e1wib2tcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG1lYW5zIG5vdGhpbmcgZmFpbGVkLCBub3QgdGhhdCB0aGUgd29ya2Jvb2sgaXNcXG5jb3ZlcmVkXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiOiBhbiBlbnRpcmVseSB1bnRlc3RlZCB3b3JrYm9vayBpcyBncmVlbiBieSB0aGF0IG1lYXN1cmUsIHdoaWNoIGlzIGhvbmVzdCwgYW5kXFxuaXMgd2h5IHRoZSBjb3ZlcmFnZSBjb3VudHMgc2l0IG5leHQgdG8gaXQgaW5zdGVhZCBvZiBiZWluZyBmb2xkZWQgaW50byBvbmUgbnVtYmVyLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlM0YiByZW1haW5zIOKclyBhbmQgaXMgbm90IHNjaGVkdWxlZC5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widHNjXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZXNsaW50XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widml0ZXN0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhbmQgU3RyeWtlciBhcmUgTm9kZVxcbnByb2Nlc3Nlczsgbm90aGluZyBydW5zIHRoZW0gaW4tYnJvd3Nlciwgc28gc291cmNlLWxldmVsIENJIHN0YXlzIGV4dGVybmFsLiBUaGF0IGlzIHRoZVxcbmhvbmVzdCBleGNlcHRpb24gdGhlIMKnMC4yIOKclyB0YWcgbWFya3MsIGFuZCBTNGEgZG9lcyBub3QgbmFycm93IGl0IOKAlCBhIGRvY3VtZW50LXRlc3QgZ2F0ZVxcbmFuZCBhIHNvdXJjZSBDSSBnYXRlIGFuc3dlciBkaWZmZXJlbnQgcXVlc3Rpb25zLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08L19jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJJbi1wbGF0Zm9ybSB0YWc6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFM0YSDinIUgKDIwMjYtMDgtMjcpOyBTNGIg4pyXIChuZWVkcyB0aGUgcGxhdGZvcm0gY2FwYWJpbGl0eSkuXFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJPd25lcjpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgUzRhIFJlY2tvbmVyIChlZGl0b3IgaW50ZWdyYXRpb24gb2YgdGhlIGVuZ2luZSB0ZXN0IHJ1bik7IFM0YiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJpbW1lZGlhdGVseS1ydW4tc2l0ZS1tYWluXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcInBsYXRmb3JtLiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIkRlcGVuZHMgb246XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFM0YSDihpIgdGhlIGVuZ2luZSAoTTEpICsgUzI7IFM0YiDihpIgYSBwbGF0Zm9ybSBydW5uZXIgKG5ldykuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5ociAvPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cImNvbnRleHQtdGhlLXJlc3Qtb2YtdGhlLXMtc2VyaWVzLXN0YXR1cy1vbmx5XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJjb250ZXh0LXRoZS1yZXN0LW9mLXRoZS1zLXNlcmllcy1zdGF0dXMtb25seVwiIC8+e1wiQ29udGV4dCDigJQgdGhlIHJlc3Qgb2YgdGhlIFMtc2VyaWVzIChzdGF0dXMgb25seSlcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy50YWJsZT48X2NvbXBvbmVudHMudGhlYWQ+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50aD57XCIjXCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGg+e1wiQ2FwYWJpbGl0eVwifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIlN0YXRlXCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGg+e1wiTm90ZVwifTwvX2NvbXBvbmVudHMudGg+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50Ym9keT48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIlMxXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiRWRpdCDihpIgbGl2ZS1wcmV2aWV3IGxvb3AgZm9yIGNvbnRlbnQgJiBzb3VyY2VcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCLinIUgZXhpc3RzXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiZWRpdG9yICsgYWdlbnQgd3JpdGUtcG9ydCArIFwifTxfY29tcG9uZW50cy5jb2RlPntcImxvY2FsXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBwcm92aWRlciBob3N0IHByZXZpZXdcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJTMlwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIkluLXBsYXRmb3JtIGRvY3VtZW50LXRlc3QgZXhlY3V0aW9uXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wi4peQIGJ5IGNvbnN0cnVjdGlvbiBhdCBNMVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcInRlc3RzLWFzLWNlbGxzIHJ1biBpbiB0aGUgZW5naW5lOyBTNGEgZXhwb3NlcyBpdFwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUzNcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkluLXBsYXRmb3JtIGNvbW1pdC9wdXNoXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wi4pyFIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZGVsaXZlcmVkXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChyZWNvbmNpbGVkIDIwMjYtMDctMTUpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wic2hpcHMgb24gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicHJvdG9jb2wtY29udHJpYnV0ZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKyB0aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicGFuZWwuY29udHJpYnV0ZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYWZmb3JkYW5jZSDigJQgc2VlIHRoZSDCp1MzIGNvcnJlY3Rpb24gbm90ZVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUzRcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkluLXBsYXRmb3JtIENJIGdhdGVcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlM0YSDinIUgKDIwMjYtMDgtMjcpIC8gUzRiIOKcl1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcInRoZSB3b3JrYm9vayBzdWl0ZSBydW5zIGZyb20gdGhlIGVkaXRvciB3aXRoIHRoZSByZXZpZXcgc3VyZmFjZSdzIG93biB2ZXJkaWN0czsgc291cmNlIENJIGlzIHRoZSB0cmFja2VkIGdhcFwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIlM1XCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiRGVwIHJlc29sdXRpb24gZm9yIFNFUyAvIENvZGVNaXJyb3IgaW4tcGxhdGZvcm1cIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCLinIUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJwcm92ZW5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKDIwMjYtMDctMTIpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wibGl2ZSBzcGlrZTogdGhlIG1vZHVsZS1mZXRjaCBwYXRoIHJlc29sdmVzIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNlc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIrXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQGVuZG8vKlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIrXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQGNvZGVtaXJyb3IvKlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGFuZCBhIHN0YXJ2ZWQgU0VTIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkNvbXBhcnRtZW50XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBydW5zIGluLXBsYXRmb3JtIOKAlCBzZWUgXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cInNwaWtlcy9TNV9TRVNfTU9EVUxFX1JFU09MVVRJT04ubWRcIj48X2NvbXBvbmVudHMuY29kZT57XCJzcGlrZXMvUzVfU0VTX01PRFVMRV9SRVNPTFVUSU9OLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuYT48L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJTNlwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIlJ1biB0aGUgcmVhbCBmb3VyLXJlYWxtIGNvbXBvc2l0ZSBpbi1wbGF0Zm9ybVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIuKclyBnYXRlZCBvbiBEMeKAk0Q5XCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1widGhlIHJlY3Vyc2lvbjsgcmVzb2x2ZXMgYXMgdGhlIGRlbHRhcyBsYW5kIChNMykg4oCUIGFuZCBuZWVkcyBTcGluZSAyJ3MgdG9wb2xvZ3kgdG8gZXhwcmVzcyBhIG11bHRpLWFwcEtleSBsYXVuY2ggKFwifTxfY29tcG9uZW50cy5jb2RlPntcIkNPTVBPU0lURV9DQVBBQklMSVRZX1RPUE9MT0dZX1NQRUNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIE9RLTMpXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGJvZHk+PC9fY29tcG9uZW50cy50YWJsZT57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJyZWNvbW1lbmRlZC1vcmRlclwiPjxIZWFkaW5nQW5jaG9yIGlkPVwicmVjb21tZW5kZWQtb3JkZXJcIiAvPntcIlJlY29tbWVuZGVkIG9yZGVyXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMub2w+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUzNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIOKchSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImRlbGl2ZXJlZCBieSByZWNvbmNpbGlhdGlvblwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoMjAyNi0wNy0xNSk6IHRoZSBjb250ZW50LWF1dGhvcmluZyBjb21taXQvcHVzaFxcbmxvb3AgYWxyZWFkeSBzaGlwcyBvbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJwcm90b2NvbC1jb250cmlidXRlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoc2VlIHRoZSDCp1MzIGNvcnJlY3Rpb24gbm90ZSk7IG5vIG5ldyBjb2RlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUzRhXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCDinIUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJkZWxpdmVyZWRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKDIwMjYtMDgtMjcsIFIzLTIzMSk6IHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlJ1biBzdWl0ZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBhY3Rpb24gKyB0aGVcXG53b3JrYm9vay1sZXZlbCBzdW1tYXJ5IGluIHRoZSByZXZpZXcgcGFuZWwsIGZyb20gdGhlIHJldmlldyBzdXJmYWNlJ3Mgb3duIHZlcmRpY3RzLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUzUgc3Bpa2VcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIOKchSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIkRPTkUsIHBvc2l0aXZlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICgyMDI2LTA3LTEyKTogdGhlIG1vZHVsZS1mZXRjaCBwYXRoIHJlc29sdmVzXFxuU0VTICsgQ29kZU1pcnJvciBhbmQgYSBzdGFydmVkIFNFUyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJDb21wYXJ0bWVudFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcnVucyBpbi1wbGF0Zm9ybSwgc28gdGhlIGVuZ2luZSByZWFsbSBpc1xcbmJ1aWxkYWJsZSBpbi1wbGF0Zm9ybS4gRmluZGluZ3M6IFwifTxfY29tcG9uZW50cy5hIGhyZWY9XCJzcGlrZXMvUzVfU0VTX01PRFVMRV9SRVNPTFVUSU9OLm1kXCI+PF9jb21wb25lbnRzLmNvZGU+e1wic3Bpa2VzL1M1X1NFU19NT0RVTEVfUkVTT0xVVElPTi5tZFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLmE+e1wiLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUzRiIC8gUzZcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHRyYWNrZWQgcGxhdGZvcm0gY2FwYWJpbGl0aWVzLCBub3QgdjEgUmVja29uZXIgZGVsaXZlcmFibGVzOyB0aGUgaG9uZXN0IOKcl1xcbml0ZW1zIHdob3NlIGNsb3N1cmUgaXMgdGhlIGRlZXBlciBBeGlzLTIgZm9yY2luZy1mdW5jdGlvbiBjb250cmlidXRpb24uXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLm9sPjwvPjtcbn1cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE1EWENvbnRlbnQocHJvcHMgPSB7fSkge1xuICBjb25zdCB7d3JhcHBlcjogTURYTGF5b3V0fSA9IHtcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH07XG4gIHJldHVybiBNRFhMYXlvdXQgPyA8TURYTGF5b3V0IHsuLi5wcm9wc30+PF9jcmVhdGVNZHhDb250ZW50IHsuLi5wcm9wc30gLz48L01EWExheW91dD4gOiBfY3JlYXRlTWR4Q29udGVudChwcm9wcyk7XG59XG5mdW5jdGlvbiBfbWlzc2luZ01keFJlZmVyZW5jZShpZCwgY29tcG9uZW50LCBwbGFjZSkge1xuICB0aHJvdyBuZXcgRXJyb3IoXCJFeHBlY3RlZCBcIiArIChjb21wb25lbnQgPyBcImNvbXBvbmVudFwiIDogXCJvYmplY3RcIikgKyBcIiBgXCIgKyBpZCArIFwiYCB0byBiZSBkZWZpbmVkOiB5b3UgbGlrZWx5IGZvcmdvdCB0byBpbXBvcnQsIHBhc3MsIG9yIHByb3ZpZGUgaXQuXCIgKyAocGxhY2UgPyBcIlxcbkl04oCZcyByZWZlcmVuY2VkIGluIHlvdXIgY29kZSBhdCBgXCIgKyBwbGFjZSArIFwiYCBpbiBgL2FwcC9kb2NzL0FYSVMyX1NFTEZfSE9TVElOR19XT1JLSVRFTVMubWRgXCIgOiBcIlwiKSk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUVBLElBQUFBLFlBQUEsR0FBQUMsT0FBQTtBQUF3RixJQUFBQyxXQUFBLEdBQUFELE9BQUE7QUFGeEY7QUFDQTs7QUFFQSxTQUFTRSxpQkFBaUJBLENBQUNDLEtBQUssRUFBRTtFQUNoQyxNQUFNQyxXQUFXLEdBQUc7TUFDbEJDLENBQUMsRUFBRSxHQUFHO01BQ05DLFVBQVUsRUFBRSxZQUFZO01BQ3hCQyxJQUFJLEVBQUUsTUFBTTtNQUNaQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxDQUFDLEVBQUUsR0FBRztNQUNOQyxNQUFNLEVBQUUsUUFBUTtNQUNoQkMsS0FBSyxFQUFFLE9BQU87TUFDZEMsS0FBSyxFQUFFLE9BQU87TUFDZEMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsS0FBSyxFQUFFLE9BQU87TUFDZEMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUixHQUFHLElBQUFDLDZCQUFrQixFQUFDLENBQUM7TUFDdkIsR0FBR3BCLEtBQUssQ0FBQ3FCO0lBQ1gsQ0FBQztJQUFFO01BQUNDO0lBQWEsQ0FBQyxHQUFHckIsV0FBVztFQUNoQyxJQUFJLENBQUNxQixhQUFhLEVBQUVDLG9CQUFvQixDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUM7RUFDL0Qsb0JBQU8sSUFBQXpCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQTFCLFdBQUEsQ0FBQTJCLFFBQUE7SUFBQUMsUUFBQSxnQkFBRSxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDSyxFQUFFO01BQUNxQixFQUFFLEVBQUMsb0RBQW9EO01BQUFELFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBb0QsQ0FBRSxDQUFDLEVBQUMsd0RBQXdEO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDVSxDQUFDO01BQUFlLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBUyxDQUFxQixDQUFDLEVBQUMsbUVBQW1FLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBc0IsUUFBQSxFQUFFO01BQXNCLENBQW1CLENBQUMsRUFBQyxpREFBaUQsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDSSxFQUFFO1FBQUFxQixRQUFBLEVBQUU7TUFBUyxDQUFpQixDQUFDLEVBQUMsc0RBQXNELGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBMEIsQ0FBcUIsQ0FBQyxFQUFDLDBJQUEwSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVUsQ0FBcUIsQ0FBQyxFQUFDLGFBQWE7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNFLFVBQVU7TUFBQXVCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1UsQ0FBQztRQUFBZSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWMsQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBc0IsQ0FBbUIsQ0FBQyxFQUFDLDZGQUE2RixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUEyQixDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUF1QixDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFpQyxDQUFtQixDQUFDLEVBQUMsdUNBQXVDO01BQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUF5QixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNVLENBQUM7TUFBQWUsUUFBQSxHQUFFLDhCQUE4QixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQUksQ0FBcUIsQ0FBQyxFQUFDLDZDQUE2QyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQUksQ0FBcUIsQ0FBQyxFQUFDLHFHQUFxRyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7UUFBQXNCLFFBQUEsRUFBRTtNQUFxQixDQUFtQixDQUFDLEVBQUMsK0pBQStKO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDTyxFQUFFLElBQUUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBVixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNNLEVBQUU7TUFBQ29CLEVBQUUsRUFBQyxRQUFRO01BQUMsYUFBVSxxRkFBcUY7TUFBQUQsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFRLENBQUUsQ0FBQyxFQUFDLHVFQUF1RSxlQUFDLElBQUE3QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQTBCLENBQXFCLENBQUM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNFLFVBQVU7TUFBQXVCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1UsQ0FBQztRQUFBZSxRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ0ksRUFBRTtVQUFBcUIsUUFBQSxHQUFFLHlMQUF5TCxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07WUFBQWMsUUFBQSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFxQixDQUFtQjtVQUFDLENBQW9CLENBQUMsRUFBQyxnQkFBZ0IsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1lBQUFzQixRQUFBLEVBQUU7VUFBWSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7WUFBQXNCLFFBQUEsRUFBRTtVQUFjLENBQW1CLENBQUMsRUFBQyxXQUFXLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBc0IsUUFBQSxFQUFFO1VBQXlCLENBQW1CLENBQUMsRUFBQyxjQUFjLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBc0IsUUFBQSxFQUFFO1VBQXNCLENBQW1CLENBQUMsRUFBQywyQ0FBMkMsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1lBQUFzQixRQUFBLEVBQUU7VUFBZSxDQUFtQixDQUFDLEVBQUMsNkNBQTZDLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBc0IsUUFBQSxFQUFFO1VBQVcsQ0FBbUIsQ0FBQyxFQUFDLHlMQUF5TCxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7WUFBQXNCLFFBQUEsRUFBRTtVQUFrQixDQUFtQixDQUFDLEVBQUMsNkNBQTZDLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBc0IsUUFBQSxFQUFFO1VBQWdCLENBQW1CLENBQUMsRUFBQyxpQkFBaUIsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1lBQUFzQixRQUFBLEVBQUU7VUFBbUIsQ0FBbUIsQ0FBQyxFQUFDLHdFQUF3RSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7WUFBQXNCLFFBQUEsRUFBRTtVQUFrQixDQUFtQixDQUFDLEVBQUMsaUZBQWlGLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBc0IsUUFBQSxFQUFFO1VBQVksQ0FBbUIsQ0FBQyxFQUFDLG1CQUFtQixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7WUFBQXNCLFFBQUEsRUFBRTtVQUFRLENBQW1CLENBQUMsRUFBQyxxR0FBcUcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1lBQUFzQixRQUFBLEVBQUU7VUFBcUIsQ0FBbUIsQ0FBQyxFQUFDLFVBQVUsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1lBQUFzQixRQUFBLEVBQUU7VUFBaUIsQ0FBbUIsQ0FBQyxFQUFDLFdBQVc7UUFBQSxDQUFpQjtNQUFDLENBQWUsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUF5QixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNVLENBQUM7TUFBQWUsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFPLENBQXFCLENBQUMsRUFBQywwR0FBMEcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUF1RSxDQUFxQixDQUFDLEVBQUMsZ0NBQWdDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDVSxDQUFDO01BQUFlLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBc0MsQ0FBcUIsQ0FBQyxFQUFDLCtCQUErQixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNJLEVBQUU7UUFBQXFCLFFBQUEsRUFBRTtNQUFNLENBQWlCLENBQUMsRUFBQyxpR0FBaUcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1FBQUFzQixRQUFBLEVBQUU7TUFBd0IsQ0FBbUIsQ0FBQyxFQUFDLGlFQUFpRSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7UUFBQXNCLFFBQUEsRUFBRTtNQUFZLENBQW1CLENBQUMsRUFBQyxZQUFZLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBc0IsUUFBQSxFQUFFO01BQTJELENBQW1CLENBQUMsRUFBQyxNQUFNLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBc0IsUUFBQSxFQUFFO01BQVksQ0FBbUIsQ0FBQyxFQUFDLFlBQVksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFrRCxDQUFxQixDQUFDLEVBQUMsaUJBQWlCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBSyxDQUFxQixDQUFDLEVBQUMsb0NBQW9DO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDVSxDQUFDO01BQUFlLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBTSxDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7UUFBQXNCLFFBQUEsRUFBRTtNQUFZLENBQW1CLENBQUMsRUFBQyxPQUFPLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBc0IsUUFBQSxFQUFFO01BQWEsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1FBQUFzQixRQUFBLEVBQUU7TUFBWSxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7UUFBQXNCLFFBQUEsRUFBRTtNQUFrQixDQUFtQixDQUFDLEVBQUMsU0FBUyxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxHQUFFLE1BQU0sZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFNLENBQW1CLENBQUMsRUFBQyxPQUFPLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7TUFBQSxDQUFxQixDQUFDLEVBQUMsNk1BQTZNO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDVSxDQUFDO01BQUFlLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBYyxDQUFxQixDQUFDLEVBQUMsVUFBVSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7UUFBQXNCLFFBQUEsRUFBRTtNQUFZLENBQW1CLENBQUMsRUFBQyxvQ0FBb0MsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1FBQUFzQixRQUFBLEVBQUU7TUFBaUIsQ0FBbUIsQ0FBQyxFQUFDLE1BQU0sZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1FBQUFzQixRQUFBLEVBQUU7TUFBYSxDQUFtQixDQUFDLEVBQUMsV0FBVyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQTJCLENBQXFCLENBQUMsRUFBQyxpT0FBaU8sZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1FBQUFzQixRQUFBLEVBQUU7TUFBSSxDQUFtQixDQUFDLEVBQUMscUZBQXFGO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVSxDQUFDO01BQUFlLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFhLENBQXFCO0lBQUMsQ0FBZSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNrQixFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxFQUFFO01BQTBMLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxFQUFFO01BQXNFLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxFQUFFO01BQXVFLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDVSxDQUFDO01BQUFlLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBa0IsQ0FBcUIsQ0FBQyxFQUFDLFdBQVcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDSSxFQUFFO1FBQUFxQixRQUFBLEVBQUU7TUFBSSxDQUFpQixDQUFDLEVBQUMsOERBQThELGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBUSxDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7UUFBQXNCLFFBQUEsRUFBRTtNQUEyQixDQUFtQixDQUFDLEVBQUMseUJBQXlCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBYSxDQUFxQixDQUFDLEVBQUMscUdBQXFHO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDTyxFQUFFLElBQUUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBVixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNNLEVBQUU7TUFBQ29CLEVBQUUsRUFBQyxRQUFRO01BQUMsYUFBVSx3RUFBd0U7TUFBQUQsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFRLENBQUUsQ0FBQyxFQUFDLG1DQUFtQyxlQUFDLElBQUE3QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQStDLENBQXFCLENBQUM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNVLENBQUM7TUFBQWUsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFPLENBQXFCLENBQUMsRUFBQyxpREFBaUQsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1FBQUFzQixRQUFBLEVBQUU7TUFBZSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7UUFBQXNCLFFBQUEsRUFBRTtNQUFjLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBc0IsUUFBQSxFQUFFO01BQVUsQ0FBbUIsQ0FBQyxFQUFDLG1DQUFtQyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQXFCLENBQXFCLENBQUMsRUFBQywrREFBK0Q7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNVLENBQUM7TUFBQWUsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFnQixDQUFxQixDQUFDLEVBQUMscUNBQXFDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDa0IsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBcUQsQ0FBcUIsQ0FBQyxFQUFDLGlDQUFpQyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXdCLENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQXNCLENBQW1CLENBQUMsRUFBQywyREFBMkQsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFTLENBQXFCLENBQUMsRUFBQyx1SkFBdUosZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDSSxFQUFFO1VBQUFxQixRQUFBLEVBQUU7UUFBaUIsQ0FBaUIsQ0FBQyxFQUFDLCtCQUErQjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUEyQyxDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFLLENBQW1CLENBQUMsRUFBQyxlQUFlLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQVEsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsYUFBYSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNJLEVBQUU7VUFBQXFCLFFBQUEsRUFBRTtRQUFtQixDQUFpQixDQUFDLEVBQUMseUZBQXlGO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNVLENBQUM7TUFBQWUsUUFBQSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQTBCLENBQXFCO0lBQUMsQ0FBZSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNrQixFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFtQixDQUFxQixDQUFDLEVBQUMsaUJBQWlCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBZ0MsQ0FBcUIsQ0FBQyxFQUFDLHNNQUFzTSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBc0IsQ0FBcUIsQ0FBQyxFQUFDLDBEQUEwRDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFpQyxDQUFxQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQW9DLENBQXFCLENBQUMsRUFBQyxxQkFBcUIsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBTyxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFNLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBVSxDQUFtQixDQUFDLEVBQUMsd0xBQXdMLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBaUQsQ0FBcUIsQ0FBQyxFQUFDLDZIQUE2SDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVSxDQUFDO01BQUFlLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFhLENBQXFCO0lBQUMsQ0FBZSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNrQixFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFNLENBQXFCLENBQUMsRUFBQyxrSkFBa0o7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBbUIsQ0FBcUIsQ0FBQyxFQUFDLHFCQUFxQixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFPLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQU0sQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsMkdBQTJHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNFLFVBQVU7TUFBQXVCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1UsQ0FBQztRQUFBZSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTZDLENBQXFCLENBQUMsRUFBQyxnQ0FBZ0MsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFZLENBQXFCLENBQUMsRUFBQyxrREFBa0QsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBaUUsQ0FBbUIsQ0FBQyxFQUFDLGtCQUFrQixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUEyQixDQUFtQixDQUFDLEVBQUMsWUFBWSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQU0sQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBdUIsQ0FBbUIsQ0FBQyxFQUFDLCtHQUErRyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUMsRUFBQyw2Q0FBNkMsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLG9HQUFvRyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyxVQUFVLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQVMsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBTyxDQUFtQixDQUFDLEVBQUMsMEJBQTBCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQW1CLENBQW1CLENBQUMsRUFBQyxpREFBaUQ7TUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNVLENBQUM7UUFBQWUsUUFBQSxHQUFFLHFDQUFxQyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWdCLENBQXFCLENBQUMsRUFBQyxNQUFNLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQVMsQ0FBbUIsQ0FBQyxFQUFDLHFEQUFxRCxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNJLEVBQUU7VUFBQXFCLFFBQUEsRUFBRTtRQUFRLENBQWlCLENBQUMsRUFBQyxxRkFBcUYsZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBc0IsUUFBQSxFQUFFO1VBQUksQ0FBbUIsQ0FBQyxFQUFDLDBEQUEwRDtRQUFBLENBQXFCLENBQUMsRUFBQyxvS0FBb0s7TUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNVLENBQUM7UUFBQWUsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFxQyxDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFLLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQVEsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsNFBBQTRQO01BQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUF5QixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNVLENBQUM7TUFBQWUsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFrQixDQUFxQixDQUFDLEVBQUMsK0RBQStELGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBUSxDQUFxQixDQUFDLEVBQUMsaUVBQWlFLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBc0IsUUFBQSxFQUFFO01BQTJCLENBQW1CLENBQUM7SUFBQSxDQUFlLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2tCLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLEdBQUUsWUFBWSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWEsQ0FBcUIsQ0FBQyxFQUFDLDZEQUE2RDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDTyxFQUFFLElBQUUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBVixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNNLEVBQUU7TUFBQ29CLEVBQUUsRUFBQyw4Q0FBOEM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUE4QyxDQUFFLENBQUMsRUFBQyxrREFBa0Q7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNZLEtBQUs7TUFBQWEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDZ0IsS0FBSztRQUFBUyxRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDZSxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFHLENBQWlCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNlLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQVksQ0FBaUIsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBTyxDQUFpQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDZSxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFNLENBQWlCLENBQUM7UUFBQSxDQUFnQjtNQUFDLENBQW1CLENBQUMsbUJBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNhLEtBQUs7UUFBQVksUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDaUIsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQUksQ0FBaUIsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBK0MsQ0FBaUIsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBVSxDQUFpQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsR0FBRSw4QkFBOEIsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO2NBQUFzQixRQUFBLEVBQUU7WUFBTyxDQUFtQixDQUFDLEVBQUMsd0JBQXdCO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNpQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBSSxDQUFpQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFxQyxDQUFpQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUF5QixDQUFpQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFrRCxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFJLENBQXFCO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBeUIsQ0FBcUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBVyxDQUFxQixDQUFDLEVBQUMsMEJBQTBCO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEdBQUUsV0FBVyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFxQixDQUFtQixDQUFDLEVBQUMsU0FBUyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFrQixDQUFtQixDQUFDLEVBQUMsMkNBQTJDO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNpQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBSSxDQUFxQjtVQUFDLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQXFCLENBQXFCO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBNEIsQ0FBcUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUE4RyxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFJLENBQWlCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQWlELENBQWlCLENBQUMsbUJBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFRLENBQXFCLENBQUMsRUFBQyxlQUFlO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEdBQUUsNkNBQTZDLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQUssQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO2NBQUFzQixRQUFBLEVBQUU7WUFBUyxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFlLENBQW1CLENBQUMsRUFBQyxzQkFBc0IsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO2NBQUFzQixRQUFBLEVBQUU7WUFBYSxDQUFtQixDQUFDLEVBQUMsMEJBQTBCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0MsQ0FBQztjQUFDMkIsSUFBSSxFQUFDLG9DQUFvQztjQUFBSCxRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtnQkFBQXNCLFFBQUEsRUFBRTtjQUFvQyxDQUFtQjtZQUFDLENBQWUsQ0FBQztVQUFBLENBQWdCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDaUIsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQUksQ0FBaUIsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBK0MsQ0FBaUIsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBa0IsQ0FBaUIsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEdBQUUsbUhBQW1ILGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQW9DLENBQW1CLENBQUMsRUFBQyxRQUFRO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUM7TUFBQSxDQUFtQixDQUFDO0lBQUEsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDTSxFQUFFO01BQUNvQixFQUFFLEVBQUMsbUJBQW1CO01BQUFELFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBbUIsQ0FBRSxDQUFDLEVBQUMsbUJBQW1CO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUyxFQUFFO01BQUFnQixRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBSSxDQUFxQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTZCLENBQXFCLENBQUMsRUFBQywwRUFBMEUsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBcUIsQ0FBbUIsQ0FBQyxFQUFDLDhDQUE4QztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFLLENBQXFCLENBQUMsRUFBQyxPQUFPLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBVyxDQUFxQixDQUFDLEVBQUMsNkJBQTZCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBVyxDQUFxQixDQUFDLEVBQUMsb0dBQW9HO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQVUsQ0FBcUIsQ0FBQyxFQUFDLE9BQU8sZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFnQixDQUFxQixDQUFDLEVBQUMsb0ZBQW9GLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQyxFQUFDLDhFQUE4RSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNDLENBQUM7VUFBQzJCLElBQUksRUFBQyxvQ0FBb0M7VUFBQUgsUUFBQSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7WUFBQXNCLFFBQUEsRUFBRTtVQUFvQyxDQUFtQjtRQUFDLENBQWUsQ0FBQyxFQUFDLEdBQUc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBVSxDQUFxQixDQUFDLEVBQUMsdUpBQXVKO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDO0VBQUEsQ0FBRSxDQUFDO0FBQ2xrb0I7QUFDZSxTQUFTSSxVQUFVQSxDQUFDOUIsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFO0VBQzdDLE1BQU07SUFBQytCLE9BQU8sRUFBRUM7RUFBUyxDQUFDLEdBQUc7SUFDM0IsR0FBRyxJQUFBWiw2QkFBa0IsRUFBQyxDQUFDO0lBQ3ZCLEdBQUdwQixLQUFLLENBQUNxQjtFQUNYLENBQUM7RUFDRCxPQUFPVyxTQUFTLGdCQUFHLElBQUFsQyxXQUFBLENBQUE4QixHQUFBLEVBQUNJLFNBQVM7SUFBQSxHQUFLaEMsS0FBSztJQUFBMEIsUUFBQSxlQUFFLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUM3QixpQkFBaUI7TUFBQSxHQUFLQztJQUFLLENBQUc7RUFBQyxDQUFXLENBQUMsR0FBR0QsaUJBQWlCLENBQUNDLEtBQUssQ0FBQztBQUNsSDtBQUFDaUMsRUFBQSxHQU51QkgsVUFBVTtBQU9sQyxTQUFTUCxvQkFBb0JBLENBQUNJLEVBQUUsRUFBRU8sU0FBUyxFQUFFQyxLQUFLLEVBQUU7RUFDbEQsTUFBTSxJQUFJQyxLQUFLLENBQUMsV0FBVyxJQUFJRixTQUFTLEdBQUcsV0FBVyxHQUFHLFFBQVEsQ0FBQyxHQUFHLElBQUksR0FBR1AsRUFBRSxHQUFHLG9FQUFvRSxJQUFJUSxLQUFLLEdBQUcscUNBQXFDLEdBQUdBLEtBQUssR0FBRyxrREFBa0QsR0FBRyxFQUFFLENBQUMsQ0FBQztBQUM1UTtBQUFDLElBQUFGLEVBQUE7QUFBQUksWUFBQSxDQUFBSixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}