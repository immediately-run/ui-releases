var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      blockquote: "blockquote",
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      h3: "h3",
      hr: "hr",
      li: "li",
      ol: "ol",
      p: "p",
      pre: "pre",
      strong: "strong",
      table: "table",
      tbody: "tbody",
      td: "td",
      th: "th",
      thead: "thead",
      tr: "tr",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "reckoner-document-navigator-the-authoring-vocabulary-and-the-edit-door-it-will-need",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "reckoner-document-navigator-the-authoring-vocabulary-and-the-edit-door-it-will-need"
      }), "Reckoner Document Navigator — the authoring vocabulary, and the edit door it will need"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Status:"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "split"
      }), " after one adversarial pass (§10, DN-R1…R18) — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Part A (the\nvocabulary, §1–§2) is normative and shipped"
      }), "; ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["Part B (the edit affordance, §3–§5) is\na ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "blocked"
        }), " design: it does not ship until §5's four host-contract preconditions are\nestablished."]
      }), " · ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Updated:"
      }), " 2026-08-29"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["The single implementation-status source for this spec is\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "docs/status/DOCUMENT_NAVIGATOR_STATUS.md"
          })]
        }), " — where this document and that one\ndisagree, the status doc governs."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Reads first:"
        }), " the platform's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "EDITOR_FIRST_EDITING_SPEC"
        }), " §1 (delegate, don't\nreimplement), §6 ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "R-EFE-1"
        }), " (the interim caller gate — a ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["positive ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "rw"
          }), " check"]
        }), "; the\nhost's non-editable detection is stubbed) and §7 rule 3; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "UI_AS_APPS_SPEC"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "§5.8"
        }), "\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "invokes"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "provides"
        }), " declaration — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "the"
        }), " home of the least-authority rule) together\nwith its ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "task:invoke"
        }), " requirement; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "REPO_CONTENT_DISPATCH_SPEC"
        }), " §5 (the dispatch\nwrite-paths table and its §5.1 disclosure precedent); ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "AUTHORS_VIEW_SPEC"
        }), " §2/§6 (the\nsibling surface, its additive-forever bar, and the author's-view-only rule this spec\ndeliberately does ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "not"
        }), " extend); ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ARCHITECTURE_PLAN"
        }), " §3.3 (the closed catalog)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-0",
      "data-slug": "0-charter-and-what-the-review-changed-normative",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-0"
      }), "0. Charter — and what the review changed  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Two gaps survive the what-if and author's-view work, both from the owner discussion:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The authoring vocabulary is invisible."
        }), " \"What widgets can I use as input knobs?\"\nhas no answer inside the product, so extending a report by hand is archaeology\nthrough someone else's template."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Correcting something by hand has no in-app door."
        }), " A failing test names its\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "file:line"
        }), " (R3-427) and the next step is still leaving the app. The platform has the\nanswer — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "edit-file"
        }), " delegates one file to the platform editor — and Reckoner never\nopens it."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The draft treated these as one feature. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "The adversarial pass separated them, and the\nseparation is the spec's main content"
      }), " (§10):"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The vocabulary needs no host contract at all"
        }), ", and the draft put it in the wrong\nplace — a permanent ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "catalog component"
        }), ", whose content would be a function of the\nreading app rather than the document, versioned by the document's catalog compat\nrange, and enumerating itself (DN-R14). It is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "panel chrome"
        }), ": computed, always\npresent, no author action required, no additive-forever cost. That is Part A, and it\nships."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The edit affordance rests on four questions about what the host actually provides"
        }), "\n— whether a dispatched content mount carries a delegatable ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "mountId"
        }), ", in which\nnotation; what it reports for ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "mode"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "rules"
        }), "; which channel carries ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "read-only"
        }), "; and\nwhether Reckoner's binding holds ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "task:invoke"
        }), " at all (DN-R1/R2/R4/R6). Every one is\nunanswerable from this repo. Building on four guesses is how a feature ships and never\nworks once. That is Part B, and it ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "waits"
        }), " (§5)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Not here at all"
      }), " (§6): hand-editing fixture rows (the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "edit-table"
      }), " platform contract),\nclick-to-insert template mutation, open-", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "at-line"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "part-a-the-authoring-vocabulary-normative-shipped-2026-08-28",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "part-a-the-authoring-vocabulary-normative-shipped-2026-08-28"
      }), "Part A — the authoring vocabulary  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative — shipped 2026-08-28)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-1",
      "data-slug": "1-the-vocabulary-section-normative",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-1"
      }), "1. The vocabulary section  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The workbook panel gains a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Vocabulary"
      }), " section: every catalog component with its\ntyped attributes (name · type · required · enum values, per-variant attributes included),\na widget/container marker, and a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "copyable usage snippet"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Panel chrome, not a template component (DN-R14)."
        }), " It is computed and unsuppressible\nlike the panel's other sections, needs no author to have placed a tag, adds nothing\npermanent to the closed catalog, carries no document-compat implication, and cannot\nenumerate itself. The author's view and its ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "REFLECTION"
        }), " set are untouched by this\nspec."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Derived from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "catalog.ts"
          }), ", never hand-listed"]
        }), " — a catalog addition appears here for\nfree, the same anti-rot property the author's-view indexes have."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Reachable today."
        }), " The panel works in the bundled-seed shape (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "?doc=caldera"
        }), "), which\nis the shape users can actually run (DN-R12) — so Part A delivers value with Part B\nblocked."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Filters:"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "kind: 'widgets' | 'components' | undefined"
        }), " — widgets only (exactly\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "WIDGETS"
        }), "), non-widget components only, or everything (DN-R17). Rendered as a section\ncontrol, not an attribute (there is no tag to give an attribute to)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-1-1",
      "data-slug": "11-snippets-must-validate-the-whole-point-normative",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-1-1"
      }), "1.1 Snippets must validate — the whole point  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["A snippet that cannot validate teaches the reader that the catalog is broken. The\ngenerator therefore emits, for every entry, a snippet that ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "parses and validates with\nzero error diagnostics"
      }), " (G-DN-A3), which requires more than \"required attributes\":"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Catalog shape"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Rule"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Variants (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "Chart"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "Map"
            }), ")"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["emit the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "discriminator"
            }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "kind"
            }), ") at its first value ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "plus that variant's"
            }), " required attributes — they are not in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "attributes"
            }), " and only become required once ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "kind"
            }), " is present"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "childRule: 'single-chart'"
            }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "Facets"
            }), ")"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["emit with a ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
              children: ["minimal valid ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                children: "Chart"
              }), " child"]
            }), " — a self-closing tag can never validate"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "childRule: 'widgets'"
            }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "Params"
            }), ")"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "emit with a minimal valid widget child"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "ShowAbove"
            }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "ShowBelow"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["emit ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "one threshold"
            }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "width"
            }), ") — the structural rule lives outside the attribute schema, so an attribute-only recipe emits an invalid tag"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "literal-array"
            }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "Table.columns"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "Select.options"
            }), ")"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["emit a literal array placeholder (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "{[\"year\", \"value\"]}"
            }), "), never a string"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "source"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "\"worksheet.cell\""
            }), " · ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "field"
            })]
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["An entry that cannot be made to satisfy this is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "listed without a snippet"
      }), ", naming why\n— never shipped with one that always errors (DN-R8)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-2",
      "data-slug": "2-naming-normative",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-2"
      }), "2. Naming  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The report header's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "Review"
      }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "Close review"
      }), " pair becomes ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Workbook"
        })
      }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Close workbook"
        })
      }), " (both strings, DN-R13). It is the door to the formula, test, data and\nvocabulary surfaces; \"Review\" described only the panel's first feature, and the very\nfirst discoverability complaint of this thread was that nothing said the panel existed.\nThe button is consumer-visible and unchanged in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "behaviour"
      }), ": a viewer who never presses\nit sees exactly what they saw before."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "part-b-the-edit-affordance-design-blocked-on-5",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "part-b-the-edit-affordance-design-blocked-on-5"
      }), "Part B — the edit affordance  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(design; BLOCKED on §5)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-3",
      "data-slug": "3-the-surface-when-it-is-unblocked-proposal-not-built",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-3"
      }), "3. The surface, when it is unblocked  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(proposal — not built)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Where the app already names a file, an ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["edit action beside the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "file:line"
        }), " anchor"]
      }), ":\nthe value inspector's formula row and its test rows. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Absent — not disabled — when the\ndocument is not editable"
      }), "; editor-first §7 rule 3 forbids a control that comes back\nread-only, and a greyed control still claims the action exists here."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Two scope corrections the review forced:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The author's-view index rows are out of Part B's v1 (DN-R10)."
        }), " They carry no\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "file:line"
        }), " anchor today, and giving them one means widening the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ReflectionPort"
        }), " with\na worksheet→path field — a change ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "AUTHORS_VIEW_SPEC"
        }), " §3 governs as a field-by-field\nallowlist. Booked (§11 Q5), not smuggled."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The consumer inspector carrying an authoring door is an open product decision\n(DN-R13)."
        }), " The inspector renders for any report viewer. The formula ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "text"
        }), " is already\nthere, so this is not a new disclosure — but an edit door is a materially different act\nfrom a read view, and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "AUTHORS_VIEW_SPEC"
        }), " §6's precedent (AV-R1) is that \"where an\nauthoring surface may render\" is a product decision to be ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "made"
        }), ", not inferred from\nwhich surfaces happen to hold the data. Q6."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-4",
      "data-slug": "4-the-delegation-as-designed-proposal-not-built",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-4"
      }), "4. The delegation, as designed  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(proposal — not built)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-ts",
        children: "const { invokeTask, capFile } = await import('@immediately-run/sdk/tasks'); // §4.1\nconst result = await invokeTask<EditFileResult>('edit-file', {\n  file: capFile({ mountId, relPath }, { mode: 'rw' }),\n});\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-4-1",
      "data-slug": "41-the-import-must-be-lazy-normative-for-the-implementation-dn-r5",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-4-1"
      }), "4.1 The import must be lazy  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative for the implementation, DN-R5)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "@immediately-run/sdk/tasks"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "registers a host listener at module load"
      }), " and throws with\nno host transport. A static value import white-screens the app under ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "vite dev"
      }), " — the\nrepo already documents exactly this hazard in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "useMounts.ts"
      }), " and dodges it by importing\nthe side-effect-clean ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "mounts"
      }), " subpath. The delegation therefore uses a ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["dynamic\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "import()"
        }), " inside the click handler"]
      }), ", wrapped so a host-less environment is a no-op —\nthe same shape ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "reportSession.ts"
      }), " uses for the worker URL. (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "import type"
      }), " is erased and\nstays fine.)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-4-2",
      "data-slug": "42-both-channels-carry-refusals-dn-r1",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-4-2"
      }), "4.2 Both channels carry refusals  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(DN-R1)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "invokeTask"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "throws"
      }), " with a machine ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: ".code"
      }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "cancelled"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "timeout"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "forbidden"
      }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "no-such-task"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "task-cycle"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "task-depth-exceeded"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "task-version-mismatch"
      }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "invalid-params"
      }), ") ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["and returns ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "res.data"
        }), " unexamined on success"]
      }), " — so a status the host\ncarries ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "in the result"
      }), " is silently discarded by a call that ignores its return value.\nThe draft mapped ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "read-only"
      }), " as a rejection code; it is not one. The implementation must\nbind the result and inspect it, and the exact result contract is §5's precondition P3."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "cancelled"
        }), " → silent (the user dismissed the editor; not an error)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "forbidden"
        }), " / a result-carried refusal → one plain message, and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "stop offering the\naffordance for that mount state"
        }), " so a stale grant cannot produce repeated dead clicks."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["Anything else → a brief message naming the code. Never ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "EROFS"
        }), " prose, never a stack."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-4-3",
      "data-slug": "43-relpath-is-untrusted-author-content-dn-r7",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-4-3"
      }), "4.3 ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "relPath"
      }), " is untrusted author content  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(DN-R7)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "manifest.worksheets"
      }), " is validated only for non-empty-string-ness, and the loader\ncomposes paths without resolving ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: ".."
      }), ". Under repo dispatch the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "author is not the\nviewer"
      }), ", so a hostile workbook could present ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "worksheets/../../../etc/passwd.sheet.js"
      }), "\nas a path to delegate. Whatever the host does with that, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "this app"
      }), " must not construct\nthe delegation: reject ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: ".."
      }), " segments, absolute paths, and anything not under a known\ndocument subdirectory, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "before"
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "capFile"
      }), ". The draft's blanket \"nothing here widens\nauthority\" is true of the capability model and was not true of what this app would have\nhanded it."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-4-4",
      "data-slug": "44-what-happens-after-the-edit-dn-r11",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-4-4"
      }), "4.4 What happens after the edit  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(DN-R11)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "A defect this feature would introduce, not one it inherits."
      }), " The session reads the\ndocument once and the dispatch resolution latches on the first content mount; there is\nno filesystem watch. So: edit, save, return — and the report shows the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "old numbers\nwith no indication they are stale"
      }), ", in a product whose whole proposition is that\ndisplayed figures are current. Part B therefore does not ship without either a\ndocument-changed affordance or an explicit, gated statement that the render is stale.\n\"Whatever reload story the dispatch flow has\" asserted a mechanism that does not exist."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Additionally, per ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "REPO_CONTENT_DISPATCH_SPEC"
      }), " §5.1 and Grove's precedent, the\naffordance must ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "disclose at the button"
      }), " that edits save to the mounted content and\nproposing them back to the source repository is not wired."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-5",
      "data-slug": "5-why-part-b-is-blocked-the-preconditions-normative",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-5"
      }), "5. Why Part B is blocked — the preconditions  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Each is a question about the host that this repo cannot answer, and each would, if\nguessed wrong, produce a feature that ships and never works:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "#"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Precondition"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Why guessing fails"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "P1"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["What a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "type: 'content'"
            }), " dispatch mount carries as ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                children: "id"
              })
            }), ", and whether ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "capFile"
            }), "'s ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "mountId"
            }), " accepts it ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "unqualified"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["The SDK's own examples show ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "id"
            }), " as a bare spaceId but ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "capFile"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "mount"
            }), " taking a universal ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "scheme:locator"
            }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "space:abc"
            }), "). A wrong notation refuses ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "forbidden"
            }), " on every call — which §4.2 would then misdiagnose as a permissions state and permanently suppress (DN-R4)."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "P2"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["What that mount reports for ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                children: "mode"
              })
            }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                children: "rules"
              })
            }), " — and, if ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "rules"
            }), ", whether its \"backend-natural\" ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "subtree"
            }), " paths are comparable to document-relative paths"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["A dispatched content mount is a repo mount, and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "mode"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "rules"
            }), " are documented absent on the primary repo mount. The draft's \"absent ⇒ writable\" ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
              children: ["inverted R-EFE-1's positive ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                children: "rw"
              }), " check"]
            }), " and was the only branch that would ever run; meanwhile this repo's own dispatch fixtures stamp ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "mode: 'ro'"
            }), ". One of those makes the affordance always-on, the other always-off (DN-R2). And ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "subtree"
            }), " is slash-rooted while document paths are not, so the draft's fail-closed prefix match would have disabled editing everywhere the host ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
              children: "did"
            }), " report rules (DN-R3)."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "P3"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Which channel carries a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                children: "read-only"
              })
            }), " refusal for the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "edit-file"
            }), " task — rejection or result — and its exact shape"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "§4.2 exists to handle it; a call that ignores its return value handles nothing (DN-R1)."
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "P4"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Whether Reckoner's registry binding holds ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                children: "task:invoke"
              })
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["The manifest ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "invokes"
            }), " declaration is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
              children: "\"a request and a self-restriction, never a grant\""
            }), "; capabilities come from the host registry, which this repo cannot declare into. Without it every invocation refuses ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "forbidden"
            }), " — the feature ships dark, permanently (DN-R6)."]
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "And one product precondition, P5:"
      }), " whether the dispatched shape is reachable by a\nuser at all today. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "REPO_CONTENT_DISPATCH_SPEC"
      }), " is a proposal, no status doc exists for\nit, and no workbook repo is named — so on the shape users can run (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "?doc=caldera"
      }), "),\nPart B renders nothing anywhere (DN-R12). If nobody can reach the dispatched shape, the\nhonest sequencing is to build that path first, not to ship an invisible affordance\nagainst it."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "The rule:"
      }), " Part B is implemented when P1–P4 are established ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "against a real host"
      }), "\n(a browser-driven observation of a dispatched mount, per this repo's own debugging\nguidance — not another unit test with an injected port), and P5 is answered. Until then\nthis document is the design and R3-447 is the item that establishes the contract."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-6",
      "data-slug": "6-out-of-scope-the-honest-remainder-normative",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-6"
      }), "6. Out of scope — the honest remainder  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Editing fixture rows / tabular data by hand."
        }), " The answer is a platform\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "edit-table"
          })
        }), " task contract (a sibling of ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "edit-file"
        }), ": any app holding a grant on a\nCSV/JSON-rows file delegates it, the host opens a table surface) — not a grid inside\nReckoner, which would need an editor-first §2 justification it does not have, and\nwhich every other tabular app would then need too. ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Written 2026-08-29:\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "docs/content/specs/EDIT_TABLE_TASK_SPEC.mdx"
          }), " (proposal rev 2, post-review)."]
        }), " It is\nblocked on the same P1–P5 this spec's §5 lists, plus two of its own (delegation mounts\nannounce no ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "mode"
        }), "; Reckoner has no fs watch) — so R3-447's host spike unblocks both.\nIts review also found the seed-vs-mount wall applies to fixtures exactly as it does\nhere: on the bundled-seed path there is no file to delegate."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Open-at-line."
        }), " The spans exist (R3-427); ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "edit-file"
        }), " carries no position hint.\nA small SDK/editor delta, booked against ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "EDITOR_FIRST_EDITING_SPEC"
        }), " §6."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Opening a mounted file in the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "main"
          }), " editor"]
        }), " rather than the overlay — Delta B."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Click-to-insert / template mutation."
        }), " Placement, serialization and\nround-trip-through-the-parser are a design of their own; the vocabulary section plus a\ntemplate edit door covers the flow at a fraction of the surface. Note Part B's v1 has\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "no template-file row"
        }), " — the \"copy the snippet, open the template\" flow needs one,\nbooked with Part B (Q7)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "An edit affordance on the app's own source in the fused shape."
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "requestEdit()"
        }), "\nlanded and would work, but \"edit the app you are running\" is a different act from\n\"edit this document's file\"; conflating them in one control is how someone edits the\nwrong thing."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-7",
      "data-slug": "7-gates-normative-for-part-a-part-bs-are-stated-but-unexercised",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-7"
      }), "7. Gates  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative for Part A; Part B's are stated but unexercised)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "part-a-shipped",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "part-a-shipped"
      }), "Part A — shipped"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Gate"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Test"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "G-DN-A1"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["The vocabulary section enumerates ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "every"
            }), " entry in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "catalog.ts"
            }), " — asserted against the catalog itself, never a literal list, so a future catalog addition appears without touching the section."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "G-DN-A2"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Attributes render with name, type, required marker and enum values, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "including per-variant attributes"
            }), " (a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "Chart"
            }), " shows ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "kind"
            }), " and the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "bar"
            }), " variant's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "x"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "y"
            }), "), and widgets are marked as widgets."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "G-DN-A3"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
              children: ["Every generated snippet parses and validates with zero ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                children: "error"
              }), " diagnostics"]
            }), " — the falsifiable form of \"usable\", run over the whole catalog so no entry can regress silently (variants, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "Facets"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "Params"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "Show*"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "Table.columns"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "Select.options"
            }), " all included)."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "G-DN-A4"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["The ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "widgets"
            }), " filter yields exactly ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "WIDGETS"
            }), "; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "components"
            }), " yields exactly the complement; unset yields all — the third case the draft left undefined."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "G-DN-A5"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["The panel renders the section with no document loaded beyond the seed, and with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "no host transport"
            }), " — the vocabulary must not import anything that throws at module load (the §4.1 hazard, asserted for Part A too)."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "G-DN-A6"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["The header button reads ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "Workbook"
            }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "Close workbook"
            }), "."]
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "part-b-stated-unexercised-until-5-clears",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "part-b-stated-unexercised-until-5-clears"
      }), "Part B — stated, unexercised until §5 clears"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["G-DN-B1 mount id/mode/rules provenance · B2 editability derivation against the\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "established"
      }), " semantics · B3 path-notation normalization with segment boundaries · B4\ndelegation shape ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "and value provenance"
      }), " · B5 both refusal channels incl. the\nresult-carried case, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "no-such-task"
      }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "timeout"
      }), " · B6 affordance absent unless writable\n· B7 traversal-shaped ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "manifest.worksheets"
      }), " never reaches ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "capFile"
      }), " · B8 host-less boot\nafter the lazy import · B9 the stale-render affordance · B10 ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "invokes"
      }), " declared ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "and"
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "task:invoke"
      }), " established. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "No Part B gate may be host-free"
      }), " for P1–P4: those are\nquestions about the host, and an injected port cannot falsify them (DN-R17)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-8",
      "data-slug": "8-load-bearing-assumptions-code-anchors-required",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-8"
      }), "8. Load-bearing assumptions & code anchors  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(required)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "depends-on-today-verified-against-this-repos-code",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "depends-on-today-verified-against-this-repos-code"
      }), "Depends-on-today (verified against this repo's code)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Assumption"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Anchor (repo-relative file)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Token (grep-stable)"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "The catalog is a closed typed schema list with variants and child rules"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/report/catalog.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "const COMPONENTS: ComponentSchema[]"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "The widget set is enumerated"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/report/catalog.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "export const WIDGETS"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Validation enforces variant discriminators, child rules and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "literal-array"
            }), " shapes — what §1.1's snippets must satisfy"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/report/validate.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "childRule"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Templates parse to the node model the gate validates through"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/report/parse/mdx.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "export function parseTemplate"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "The workbook panel is the always-present computed surface the section joins"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/app/WorkbookPanel.tsx"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "WorkbookPanelBody"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Document files carry a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "document-relative"
            }), " path (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "worksheets/x.sheet.js"
            }), ") — Part B's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "relPath"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/document/loader.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "path: rel"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "manifest.worksheets"
            }), " is validated only for non-empty strings (why §4.3 exists)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/document/manifest.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "\"worksheets\" must be an array"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "The dispatch keeps only the mount's path today (Part B's P1/P2 change it)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/app/dispatch.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "marked[0].path"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "The SDK's task module registers a listener at import (why §4.1 is lazy)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/hooks/useMounts.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "registers a host listener at module load"
            })
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.em, {
        children: ["(SDK contracts are cited by their published documentation — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "llms.txt"
        }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "api.json"
        }), " at\nthe version this repo depends on — not by ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "node_modules"
        }), " paths: those are gitignored,\nfloat with the dependency range, and are absent on a fresh clone. The draft anchored\nthree rows there and one at a sibling repo; both are outside this table's contract.)"]
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "must-establish-new-invariants-the-implementation-creates",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "must-establish-new-invariants-the-implementation-creates"
      }), "Must-establish (new invariants the implementation creates)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "New invariant"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Proven by"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "The vocabulary section is derived, complete, and filterable"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-A1, G-DN-A2, G-DN-A4"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Every snippet validates"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-A3"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Nothing in the section throws without a host"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-DN-A5"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Part B's P1–P4 host contract"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Not established — §5; R3-447"
            })
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-9",
      "data-slug": "9-decisions-rejected-alternatives-normative-dont-relitigate",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-9"
      }), "9. Decisions & rejected alternatives  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative — don't relitigate)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The vocabulary is panel chrome, not a catalog component (DN-R14)."
        }), " A catalog\naddition is permanent, is versioned by the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "document's"
        }), " compat range, would render\ncontent that is a function of the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "reading app"
        }), " rather than the document (the catalog\nis a fork point), and would enumerate itself. Panel chrome has none of those\nproperties and is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "more"
        }), " discoverable, since no author must place a tag. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), "\nthe draft's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<CatalogIndex />"
        }), " component — and with it the draft's claim that its\nauthor's-view-only gating was \"structural\", which it was not: unlike its siblings it\ndoes not take its data from the reflection port, so withholding the port took nothing\naway (DN-R9)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Ship the vocabulary; block the edit door (DN-R2/R4/R6/R12)."
        }), " Four host-contract\nquestions and one reachability question, none answerable from this repo, each fatal if\nguessed. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " shipping Part B on plausible defaults — the draft's \"absent\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "mode"
        }), " ⇒ writable\" inverted the very guidance it cited, and was the only branch that\nwould have run."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Snippets are gated on validating, not hedged as \"a starting point\" (DN-R8)."
        }), " Seven\nof nineteen entries could not produce a valid snippet under the draft's recipe. A copy\nbutton that always yields red diagnostics is worse than no button. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " the\n\"not a promise of validity\" hedge as cover for known-invalid output."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Data section read-only; the file link is the edit path"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "(owner lean, recorded as\ndefault)"
        }), ". Row editing wants ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "edit-table"
        }), " at the platform (§6). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected for v1:"
        }), " an\nin-app fixture grid."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Catalog + copyable snippet, not click-to-insert"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "(owner lean, recorded as\ndefault)"
        }), ". ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected for v1:"
        }), " insert-on-click."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The vocabulary lives in the workbook panel, not the inspector"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "(the third open\nquestion, decided as the reversible default)"
        }), ". It is reference material read while\nauthoring, not per-value context. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected for v1:"
        }), " a contextual \"this value could be\na slider\" hint — a good idea needing a rule for when it helps rather than intrudes\n(Q4)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Absent affordance, not disabled affordance"
        }), " when not writable (editor-first §7\nrule 3). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " greyed controls with tooltips."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "Review"
          }), " → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "Workbook"
          }), ", both label strings."]
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " a name describing only the\npanel's first feature."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-10",
      "data-slug": "10-adversarial-review-record",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-10"
      }), "10. Adversarial review  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(record)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Pass 1 (2026-08-28, fresh-agent), DN-R1…DN-R18 — folded; four BLOCKERs are why this\ndocument is split rather than revised:"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "DN-R1 [BLOCKER]"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "read-only"
        }), " mapped as an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "invokeTask"
        }), " rejection code; it is not\none, and the draft's call discarded its result → §4.2 rewritten for both channels;\nthe exact contract becomes precondition ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "P3"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "DN-R2 [BLOCKER]"
        }), " \"absent ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "mode"
        }), " ⇒ writable\" ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "inverted"
        }), " R-EFE-1's positive ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "rw"
        }), "\ncheck while citing it as authority, and was the only branch that fires on a repo-backed\ncontent mount (this repo's own fixtures say ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ro"
        }), ") → precondition ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "P2"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "DN-R3 [BLOCKER]"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "MountRule.subtree"
        }), " is slash-rooted and \"backend-natural\";\ndocument paths are not, so the fail-closed prefix match disabled editing wherever rules\nwere reported — and the draft's gate encoded the mismatch → folded into ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "P2"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "DN-R4 [BLOCKER]"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "SandboxMount.id"
        }), " (bare spaceId) is not ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "capFile"
        }), "'s universal\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "scheme:locator"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "mountId"
        }), " → precondition ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "P1"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "DN-R5 [MAJOR]"
        }), " a static SDK ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "tasks"
        }), " import throws at module load (the hazard this\nrepo already documents in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "useMounts.ts"
        }), ") → §4.1 lazy import; G-DN-A5 asserts it for\nPart A too."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "DN-R6 [MAJOR]"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "invokes"
        }), " is half the §5.8 rule; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "task:invoke"
        }), " is host-side and\nunestablished, and the draft's manifest gate tested only the half a unit test can see\n→ precondition ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "P4"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "DN-R7 [MAJOR]"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "relPath"
        }), " built from unvalidated author-controlled manifest content\n→ §4.3 validation before ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "capFile"
        }), "; the \"widens no authority\" claim qualified."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "DN-R8 [MAJOR]"
        }), " the snippet recipe could not emit a valid snippet for 7/19 entries\n→ §1.1's per-shape rules; G-DN-A3 gates on zero error diagnostics."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "DN-R9 [MAJOR]"
        }), " the component's author's-view gating was advisory, not structural →\ndissolved with DN-R14 (no component)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "DN-R10 [MAJOR]"
        }), " author's-view rows referenced a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "file:line"
        }), " anchor that exists only\nin the inspector, and would need an unbooked ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ReflectionPort"
        }), " widening → dropped from\nPart B v1; booked Q5."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "DN-R11 [MAJOR]"
        }), " \"nothing happens after the edit\" concealed a stale-render defect\nthe feature introduces, and omitted RCD §5.1's disclosure-at-the-button → §4.4."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "DN-R12 [MAJOR]"
        }), " Part B renders nothing in the only shape users can reach → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "P5"
        }), ",\nand Part A is sequenced first precisely because it does not."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "DN-R13 [MAJOR]"
        }), " an authoring door on the consumer-visible inspector was never\ndecided → Q6; §2 now specifies both label strings."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "DN-R14 [MAJOR]"
        }), " a permanent catalog entry describing the app rather than the\ndocument → panel chrome (§1, §9)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "DN-R15 [MINOR]"
        }), " anchors into gitignored ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "node_modules"
        }), ", a sibling repo, and a token\nthat matched without supporting its claim → §8 rebuilt."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "DN-R16 [MINOR]"
        }), " §5.8 attributed to the wrong spec → cited to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "UI_AS_APPS_SPEC"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "DN-R17 [MINOR]"
        }), " gate holes (result channel, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "no-such-task"
        }), ", host-less boot, no\nhost-exercised gate) and an undefined ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "components"
        }), " filter → §7."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "DN-R18 [MINOR]"
        }), " spec-form drift (no review-record slot, mis-tagged sections,\n\"verified against code\" over unverified rows) → structure and tags corrected."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-11",
      "data-slug": "11-open-questions",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-11"
      }), "11. Open questions"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Q1"
        }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "edit-table"
        }), ": who owns the platform spec, and does it subsume the fixture\ncase or want a Reckoner-side shape first? ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.em, {
          children: ["(Answered 2026-08-29 on the first half —\nthe spec is written and lives in the docs repo, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "EDIT_TABLE_TASK_SPEC.mdx"
          }), ". It\nsubsumes the fixture case and needs ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "no"
          }), " Reckoner-side shape first; what it needs\nfrom Reckoner is the D7 fs watch and a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "task:invoke"
          }), " binding, both booked there.)"]
        })]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Q2"
        }), " — The ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "edit-file"
        }), " position hint (open-at-line): SDK param vs. task-contract\nversion bump."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Q3"
        }), " — After an edit lands: an explicit reload affordance, or a change-watch on the\nmount? (§4.4 requires one of them before Part B ships.)"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Q4"
        }), " — Contextual vocabulary hints in the inspector — worth it, or noise?"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Q5"
        }), " — Widening ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ReflectionPort"
        }), " with worksheet→path so the author's-view indexes\ncan carry anchors and (later) edit doors — worth the allowlist addition?"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Q6"
        }), " — Does the consumer-visible inspector carry the edit affordance at all?"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Q7"
        }), " — A template-file edit row, without which \"copy the snippet, open the template\"\nhas no door."]
      }), "\n"]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/specs/DOCUMENT_NAVIGATOR_SPEC.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJibG9ja3F1b3RlIiwiY29kZSIsImVtIiwiaDEiLCJoMiIsImgzIiwiaHIiLCJsaSIsIm9sIiwicCIsInByZSIsInN0cm9uZyIsInRhYmxlIiwidGJvZHkiLCJ0ZCIsInRoIiwidGhlYWQiLCJ0ciIsInVsIiwiX3Byb3ZpZGVDb21wb25lbnRzIiwiY29tcG9uZW50cyIsIkhlYWRpbmdBbmNob3IiLCJfbWlzc2luZ01keFJlZmVyZW5jZSIsImpzeHMiLCJGcmFnbWVudCIsImNoaWxkcmVuIiwiaWQiLCJqc3giLCJjbGFzc05hbWUiLCJNRFhDb250ZW50Iiwid3JhcHBlciIsIk1EWExheW91dCIsIl9jIiwiY29tcG9uZW50IiwicGxhY2UiLCJFcnJvciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkRPQ1VNRU5UX05BVklHQVRPUl9TUEVDLm1kIl0sInNvdXJjZXNDb250ZW50IjpbIi8qQGpzeFJ1bnRpbWUgYXV0b21hdGljKi9cbi8qQGpzeEltcG9ydFNvdXJjZSByZWFjdCovXG5pbXBvcnQge3VzZU1EWENvbXBvbmVudHMgYXMgX3Byb3ZpZGVDb21wb25lbnRzfSBmcm9tIFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGsvTURYUHJvdmlkZXJcIjtcbmZ1bmN0aW9uIF9jcmVhdGVNZHhDb250ZW50KHByb3BzKSB7XG4gIGNvbnN0IF9jb21wb25lbnRzID0ge1xuICAgIGJsb2NrcXVvdGU6IFwiYmxvY2txdW90ZVwiLFxuICAgIGNvZGU6IFwiY29kZVwiLFxuICAgIGVtOiBcImVtXCIsXG4gICAgaDE6IFwiaDFcIixcbiAgICBoMjogXCJoMlwiLFxuICAgIGgzOiBcImgzXCIsXG4gICAgaHI6IFwiaHJcIixcbiAgICBsaTogXCJsaVwiLFxuICAgIG9sOiBcIm9sXCIsXG4gICAgcDogXCJwXCIsXG4gICAgcHJlOiBcInByZVwiLFxuICAgIHN0cm9uZzogXCJzdHJvbmdcIixcbiAgICB0YWJsZTogXCJ0YWJsZVwiLFxuICAgIHRib2R5OiBcInRib2R5XCIsXG4gICAgdGQ6IFwidGRcIixcbiAgICB0aDogXCJ0aFwiLFxuICAgIHRoZWFkOiBcInRoZWFkXCIsXG4gICAgdHI6IFwidHJcIixcbiAgICB1bDogXCJ1bFwiLFxuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfSwge0hlYWRpbmdBbmNob3J9ID0gX2NvbXBvbmVudHM7XG4gIGlmICghSGVhZGluZ0FuY2hvcikgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJIZWFkaW5nQW5jaG9yXCIsIHRydWUpO1xuICByZXR1cm4gPD48X2NvbXBvbmVudHMuaDEgaWQ9XCJyZWNrb25lci1kb2N1bWVudC1uYXZpZ2F0b3ItdGhlLWF1dGhvcmluZy12b2NhYnVsYXJ5LWFuZC10aGUtZWRpdC1kb29yLWl0LXdpbGwtbmVlZFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwicmVja29uZXItZG9jdW1lbnQtbmF2aWdhdG9yLXRoZS1hdXRob3Jpbmctdm9jYWJ1bGFyeS1hbmQtdGhlLWVkaXQtZG9vci1pdC13aWxsLW5lZWRcIiAvPntcIlJlY2tvbmVyIERvY3VtZW50IE5hdmlnYXRvciDigJQgdGhlIGF1dGhvcmluZyB2b2NhYnVsYXJ5LCBhbmQgdGhlIGVkaXQgZG9vciBpdCB3aWxsIG5lZWRcIn08L19jb21wb25lbnRzLmgxPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiU3RhdHVzOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInNwbGl0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGFmdGVyIG9uZSBhZHZlcnNhcmlhbCBwYXNzICjCpzEwLCBETi1SMeKAplIxOCkg4oCUIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiUGFydCBBICh0aGVcXG52b2NhYnVsYXJ5LCDCpzHigJPCpzIpIGlzIG5vcm1hdGl2ZSBhbmQgc2hpcHBlZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIjsgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJQYXJ0IEIgKHRoZSBlZGl0IGFmZm9yZGFuY2UsIMKnM+KAk8KnNSkgaXNcXG5hIFwifTxfY29tcG9uZW50cy5lbT57XCJibG9ja2VkXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgZGVzaWduOiBpdCBkb2VzIG5vdCBzaGlwIHVudGlsIMKnNSdzIGZvdXIgaG9zdC1jb250cmFjdCBwcmVjb25kaXRpb25zIGFyZVxcbmVzdGFibGlzaGVkLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDCtyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlVwZGF0ZWQ6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIDIwMjYtMDgtMjlcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgc2luZ2xlIGltcGxlbWVudGF0aW9uLXN0YXR1cyBzb3VyY2UgZm9yIHRoaXMgc3BlYyBpc1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcImRvY3Mvc3RhdHVzL0RPQ1VNRU5UX05BVklHQVRPUl9TVEFUVVMubWRcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCB3aGVyZSB0aGlzIGRvY3VtZW50IGFuZCB0aGF0IG9uZVxcbmRpc2FncmVlLCB0aGUgc3RhdHVzIGRvYyBnb3Zlcm5zLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08L19jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJSZWFkcyBmaXJzdDpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdGhlIHBsYXRmb3JtJ3MgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRURJVE9SX0ZJUlNUX0VESVRJTkdfU1BFQ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgwqcxIChkZWxlZ2F0ZSwgZG9uJ3RcXG5yZWltcGxlbWVudCksIMKnNiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlItRUZFLTFcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHRoZSBpbnRlcmltIGNhbGxlciBnYXRlIOKAlCBhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicG9zaXRpdmUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicndcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNoZWNrXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiOyB0aGVcXG5ob3N0J3Mgbm9uLWVkaXRhYmxlIGRldGVjdGlvbiBpcyBzdHViYmVkKSBhbmQgwqc3IHJ1bGUgMzsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiVUlfQVNfQVBQU19TUEVDXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIsKnNS44XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiXFxuKFwifTxfY29tcG9uZW50cy5jb2RlPntcImludm9rZXNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcInByb3ZpZGVzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBkZWNsYXJhdGlvbiDigJQgXCJ9PF9jb21wb25lbnRzLmVtPntcInRoZVwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGhvbWUgb2YgdGhlIGxlYXN0LWF1dGhvcml0eSBydWxlKSB0b2dldGhlclxcbndpdGggaXRzIFwifTxfY29tcG9uZW50cy5jb2RlPntcInRhc2s6aW52b2tlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiByZXF1aXJlbWVudDsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiUkVQT19DT05URU5UX0RJU1BBVENIX1NQRUNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIMKnNSAodGhlIGRpc3BhdGNoXFxud3JpdGUtcGF0aHMgdGFibGUgYW5kIGl0cyDCpzUuMSBkaXNjbG9zdXJlIHByZWNlZGVudCk7IFwifTxfY29tcG9uZW50cy5jb2RlPntcIkFVVEhPUlNfVklFV19TUEVDXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDCpzIvwqc2ICh0aGVcXG5zaWJsaW5nIHN1cmZhY2UsIGl0cyBhZGRpdGl2ZS1mb3JldmVyIGJhciwgYW5kIHRoZSBhdXRob3Incy12aWV3LW9ubHkgcnVsZSB0aGlzIHNwZWNcXG5kZWxpYmVyYXRlbHkgZG9lcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBleHRlbmQpOyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJBUkNISVRFQ1RVUkVfUExBTlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgwqczLjMgKHRoZSBjbG9zZWQgY2F0YWxvZykuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTwvX2NvbXBvbmVudHMuYmxvY2txdW90ZT57XCJcXG5cIn08X2NvbXBvbmVudHMuaHIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtMFwiIGRhdGEtc2x1Zz1cIjAtY2hhcnRlci1hbmQtd2hhdC10aGUtcmV2aWV3LWNoYW5nZWQtbm9ybWF0aXZlXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtMFwiIC8+e1wiMC4gQ2hhcnRlciDigJQgYW5kIHdoYXQgdGhlIHJldmlldyBjaGFuZ2VkICBcIn08X2NvbXBvbmVudHMuZW0+e1wiKG5vcm1hdGl2ZSlcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVHdvIGdhcHMgc3Vydml2ZSB0aGUgd2hhdC1pZiBhbmQgYXV0aG9yJ3MtdmlldyB3b3JrLCBib3RoIGZyb20gdGhlIG93bmVyIGRpc2N1c3Npb246XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgYXV0aG9yaW5nIHZvY2FidWxhcnkgaXMgaW52aXNpYmxlLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcXFwiV2hhdCB3aWRnZXRzIGNhbiBJIHVzZSBhcyBpbnB1dCBrbm9icz9cXFwiXFxuaGFzIG5vIGFuc3dlciBpbnNpZGUgdGhlIHByb2R1Y3QsIHNvIGV4dGVuZGluZyBhIHJlcG9ydCBieSBoYW5kIGlzIGFyY2hhZW9sb2d5XFxudGhyb3VnaCBzb21lb25lIGVsc2UncyB0ZW1wbGF0ZS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkNvcnJlY3Rpbmcgc29tZXRoaW5nIGJ5IGhhbmQgaGFzIG5vIGluLWFwcCBkb29yLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBBIGZhaWxpbmcgdGVzdCBuYW1lcyBpdHNcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJmaWxlOmxpbmVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChSMy00MjcpIGFuZCB0aGUgbmV4dCBzdGVwIGlzIHN0aWxsIGxlYXZpbmcgdGhlIGFwcC4gVGhlIHBsYXRmb3JtIGhhcyB0aGVcXG5hbnN3ZXIg4oCUIFwifTxfY29tcG9uZW50cy5jb2RlPntcImVkaXQtZmlsZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZGVsZWdhdGVzIG9uZSBmaWxlIHRvIHRoZSBwbGF0Zm9ybSBlZGl0b3Ig4oCUIGFuZCBSZWNrb25lciBuZXZlclxcbm9wZW5zIGl0LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgZHJhZnQgdHJlYXRlZCB0aGVzZSBhcyBvbmUgZmVhdHVyZS4gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgYWR2ZXJzYXJpYWwgcGFzcyBzZXBhcmF0ZWQgdGhlbSwgYW5kIHRoZVxcbnNlcGFyYXRpb24gaXMgdGhlIHNwZWMncyBtYWluIGNvbnRlbnRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKMKnMTApOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVGhlIHZvY2FidWxhcnkgbmVlZHMgbm8gaG9zdCBjb250cmFjdCBhdCBhbGxcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIsIGFuZCB0aGUgZHJhZnQgcHV0IGl0IGluIHRoZSB3cm9uZ1xcbnBsYWNlIOKAlCBhIHBlcm1hbmVudCBcIn08X2NvbXBvbmVudHMuZW0+e1wiY2F0YWxvZyBjb21wb25lbnRcIn08L19jb21wb25lbnRzLmVtPntcIiwgd2hvc2UgY29udGVudCB3b3VsZCBiZSBhIGZ1bmN0aW9uIG9mIHRoZVxcbnJlYWRpbmcgYXBwIHJhdGhlciB0aGFuIHRoZSBkb2N1bWVudCwgdmVyc2lvbmVkIGJ5IHRoZSBkb2N1bWVudCdzIGNhdGFsb2cgY29tcGF0XFxucmFuZ2UsIGFuZCBlbnVtZXJhdGluZyBpdHNlbGYgKEROLVIxNCkuIEl0IGlzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicGFuZWwgY2hyb21lXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiOiBjb21wdXRlZCwgYWx3YXlzXFxucHJlc2VudCwgbm8gYXV0aG9yIGFjdGlvbiByZXF1aXJlZCwgbm8gYWRkaXRpdmUtZm9yZXZlciBjb3N0LiBUaGF0IGlzIFBhcnQgQSwgYW5kIGl0XFxuc2hpcHMuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgZWRpdCBhZmZvcmRhbmNlIHJlc3RzIG9uIGZvdXIgcXVlc3Rpb25zIGFib3V0IHdoYXQgdGhlIGhvc3QgYWN0dWFsbHkgcHJvdmlkZXNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCJcXG7igJQgd2hldGhlciBhIGRpc3BhdGNoZWQgY29udGVudCBtb3VudCBjYXJyaWVzIGEgZGVsZWdhdGFibGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibW91bnRJZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGluIHdoaWNoXFxubm90YXRpb247IHdoYXQgaXQgcmVwb3J0cyBmb3IgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibW9kZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicnVsZXNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiOyB3aGljaCBjaGFubmVsIGNhcnJpZXMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicmVhZC1vbmx5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjsgYW5kXFxud2hldGhlciBSZWNrb25lcidzIGJpbmRpbmcgaG9sZHMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widGFzazppbnZva2VcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGF0IGFsbCAoRE4tUjEvUjIvUjQvUjYpLiBFdmVyeSBvbmUgaXNcXG51bmFuc3dlcmFibGUgZnJvbSB0aGlzIHJlcG8uIEJ1aWxkaW5nIG9uIGZvdXIgZ3Vlc3NlcyBpcyBob3cgYSBmZWF0dXJlIHNoaXBzIGFuZCBuZXZlclxcbndvcmtzIG9uY2UuIFRoYXQgaXMgUGFydCBCLCBhbmQgaXQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ3YWl0c1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAowqc1KS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJOb3QgaGVyZSBhdCBhbGxcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKMKnNik6IGhhbmQtZWRpdGluZyBmaXh0dXJlIHJvd3MgKHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJlZGl0LXRhYmxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBwbGF0Zm9ybSBjb250cmFjdCksXFxuY2xpY2stdG8taW5zZXJ0IHRlbXBsYXRlIG11dGF0aW9uLCBvcGVuLVwifTxfY29tcG9uZW50cy5lbT57XCJhdC1saW5lXCJ9PC9fY29tcG9uZW50cy5lbT57XCIuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5ociAvPntcIlxcblwifTxfY29tcG9uZW50cy5oMSBpZD1cInBhcnQtYS10aGUtYXV0aG9yaW5nLXZvY2FidWxhcnktbm9ybWF0aXZlLXNoaXBwZWQtMjAyNi0wOC0yOFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwicGFydC1hLXRoZS1hdXRob3Jpbmctdm9jYWJ1bGFyeS1ub3JtYXRpdmUtc2hpcHBlZC0yMDI2LTA4LTI4XCIgLz57XCJQYXJ0IEEg4oCUIHRoZSBhdXRob3Jpbmcgdm9jYWJ1bGFyeSAgXCJ9PF9jb21wb25lbnRzLmVtPntcIihub3JtYXRpdmUg4oCUIHNoaXBwZWQgMjAyNi0wOC0yOClcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMuaDE+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTFcIiBkYXRhLXNsdWc9XCIxLXRoZS12b2NhYnVsYXJ5LXNlY3Rpb24tbm9ybWF0aXZlXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtMVwiIC8+e1wiMS4gVGhlIHZvY2FidWxhcnkgc2VjdGlvbiAgXCJ9PF9jb21wb25lbnRzLmVtPntcIihub3JtYXRpdmUpXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSB3b3JrYm9vayBwYW5lbCBnYWlucyBhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiVm9jYWJ1bGFyeVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBzZWN0aW9uOiBldmVyeSBjYXRhbG9nIGNvbXBvbmVudCB3aXRoIGl0c1xcbnR5cGVkIGF0dHJpYnV0ZXMgKG5hbWUgwrcgdHlwZSDCtyByZXF1aXJlZCDCtyBlbnVtIHZhbHVlcywgcGVyLXZhcmlhbnQgYXR0cmlidXRlcyBpbmNsdWRlZCksXFxuYSB3aWRnZXQvY29udGFpbmVyIG1hcmtlciwgYW5kIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJjb3B5YWJsZSB1c2FnZSBzbmlwcGV0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUGFuZWwgY2hyb21lLCBub3QgYSB0ZW1wbGF0ZSBjb21wb25lbnQgKEROLVIxNCkuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIEl0IGlzIGNvbXB1dGVkIGFuZCB1bnN1cHByZXNzaWJsZVxcbmxpa2UgdGhlIHBhbmVsJ3Mgb3RoZXIgc2VjdGlvbnMsIG5lZWRzIG5vIGF1dGhvciB0byBoYXZlIHBsYWNlZCBhIHRhZywgYWRkcyBub3RoaW5nXFxucGVybWFuZW50IHRvIHRoZSBjbG9zZWQgY2F0YWxvZywgY2FycmllcyBubyBkb2N1bWVudC1jb21wYXQgaW1wbGljYXRpb24sIGFuZCBjYW5ub3RcXG5lbnVtZXJhdGUgaXRzZWxmLiBUaGUgYXV0aG9yJ3MgdmlldyBhbmQgaXRzIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlJFRkxFQ1RJT05cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHNldCBhcmUgdW50b3VjaGVkIGJ5IHRoaXNcXG5zcGVjLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRGVyaXZlZCBmcm9tIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNhdGFsb2cudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBuZXZlciBoYW5kLWxpc3RlZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgYSBjYXRhbG9nIGFkZGl0aW9uIGFwcGVhcnMgaGVyZSBmb3JcXG5mcmVlLCB0aGUgc2FtZSBhbnRpLXJvdCBwcm9wZXJ0eSB0aGUgYXV0aG9yJ3MtdmlldyBpbmRleGVzIGhhdmUuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJSZWFjaGFibGUgdG9kYXkuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRoZSBwYW5lbCB3b3JrcyBpbiB0aGUgYnVuZGxlZC1zZWVkIHNoYXBlIChcIn08X2NvbXBvbmVudHMuY29kZT57XCI/ZG9jPWNhbGRlcmFcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSwgd2hpY2hcXG5pcyB0aGUgc2hhcGUgdXNlcnMgY2FuIGFjdHVhbGx5IHJ1biAoRE4tUjEyKSDigJQgc28gUGFydCBBIGRlbGl2ZXJzIHZhbHVlIHdpdGggUGFydCBCXFxuYmxvY2tlZC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkZpbHRlcnM6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5jb2RlPntcImtpbmQ6ICd3aWRnZXRzJyB8ICdjb21wb25lbnRzJyB8IHVuZGVmaW5lZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIHdpZGdldHMgb25seSAoZXhhY3RseVxcblwifTxfY29tcG9uZW50cy5jb2RlPntcIldJREdFVFNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSwgbm9uLXdpZGdldCBjb21wb25lbnRzIG9ubHksIG9yIGV2ZXJ5dGhpbmcgKEROLVIxNykuIFJlbmRlcmVkIGFzIGEgc2VjdGlvblxcbmNvbnRyb2wsIG5vdCBhbiBhdHRyaWJ1dGUgKHRoZXJlIGlzIG5vIHRhZyB0byBnaXZlIGFuIGF0dHJpYnV0ZSB0bykuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cInNlYy0xLTFcIiBkYXRhLXNsdWc9XCIxMS1zbmlwcGV0cy1tdXN0LXZhbGlkYXRlLXRoZS13aG9sZS1wb2ludC1ub3JtYXRpdmVcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy0xLTFcIiAvPntcIjEuMSBTbmlwcGV0cyBtdXN0IHZhbGlkYXRlIOKAlCB0aGUgd2hvbGUgcG9pbnQgIFwifTxfY29tcG9uZW50cy5lbT57XCIobm9ybWF0aXZlKVwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJBIHNuaXBwZXQgdGhhdCBjYW5ub3QgdmFsaWRhdGUgdGVhY2hlcyB0aGUgcmVhZGVyIHRoYXQgdGhlIGNhdGFsb2cgaXMgYnJva2VuLiBUaGVcXG5nZW5lcmF0b3IgdGhlcmVmb3JlIGVtaXRzLCBmb3IgZXZlcnkgZW50cnksIGEgc25pcHBldCB0aGF0IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicGFyc2VzIGFuZCB2YWxpZGF0ZXMgd2l0aFxcbnplcm8gZXJyb3IgZGlhZ25vc3RpY3NcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKEctRE4tQTMpLCB3aGljaCByZXF1aXJlcyBtb3JlIHRoYW4gXFxcInJlcXVpcmVkIGF0dHJpYnV0ZXNcXFwiOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudGFibGU+PF9jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGg+e1wiQ2F0YWxvZyBzaGFwZVwifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIlJ1bGVcIn08L19jb21wb25lbnRzLnRoPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudGJvZHk+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJWYXJpYW50cyAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQ2hhcnRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJNYXBcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcImVtaXQgdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZGlzY3JpbWluYXRvclwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wia2luZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpIGF0IGl0cyBmaXJzdCB2YWx1ZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInBsdXMgdGhhdCB2YXJpYW50J3NcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgcmVxdWlyZWQgYXR0cmlidXRlcyDigJQgdGhleSBhcmUgbm90IGluIFwifTxfY29tcG9uZW50cy5jb2RlPntcImF0dHJpYnV0ZXNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFuZCBvbmx5IGJlY29tZSByZXF1aXJlZCBvbmNlIFwifTxfY29tcG9uZW50cy5jb2RlPntcImtpbmRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGlzIHByZXNlbnRcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJjaGlsZFJ1bGU6ICdzaW5nbGUtY2hhcnQnXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRmFjZXRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIilcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJlbWl0IHdpdGggYSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm1pbmltYWwgdmFsaWQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQ2hhcnRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNoaWxkXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBhIHNlbGYtY2xvc2luZyB0YWcgY2FuIG5ldmVyIHZhbGlkYXRlXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiY2hpbGRSdWxlOiAnd2lkZ2V0cydcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJQYXJhbXNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcImVtaXQgd2l0aCBhIG1pbmltYWwgdmFsaWQgd2lkZ2V0IGNoaWxkXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiU2hvd0Fib3ZlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAvIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlNob3dCZWxvd1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJlbWl0IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wib25lIHRocmVzaG9sZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wid2lkdGhcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSDigJQgdGhlIHN0cnVjdHVyYWwgcnVsZSBsaXZlcyBvdXRzaWRlIHRoZSBhdHRyaWJ1dGUgc2NoZW1hLCBzbyBhbiBhdHRyaWJ1dGUtb25seSByZWNpcGUgZW1pdHMgYW4gaW52YWxpZCB0YWdcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJsaXRlcmFsLWFycmF5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiVGFibGUuY29sdW1uc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlNlbGVjdC5vcHRpb25zXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIilcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJlbWl0IGEgbGl0ZXJhbCBhcnJheSBwbGFjZWhvbGRlciAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wie1tcXFwieWVhclxcXCIsIFxcXCJ2YWx1ZVxcXCJdfVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLCBuZXZlciBhIHN0cmluZ1wifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcInNvdXJjZVwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJcXFwid29ya3NoZWV0LmNlbGxcXFwiXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDCtyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmaWVsZFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50Ym9keT48L19jb21wb25lbnRzLnRhYmxlPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkFuIGVudHJ5IHRoYXQgY2Fubm90IGJlIG1hZGUgdG8gc2F0aXNmeSB0aGlzIGlzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibGlzdGVkIHdpdGhvdXQgYSBzbmlwcGV0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBuYW1pbmcgd2h5XFxu4oCUIG5ldmVyIHNoaXBwZWQgd2l0aCBvbmUgdGhhdCBhbHdheXMgZXJyb3JzIChETi1SOCkuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInNlYy0yXCIgZGF0YS1zbHVnPVwiMi1uYW1pbmctbm9ybWF0aXZlXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtMlwiIC8+e1wiMi4gTmFtaW5nICBcIn08X2NvbXBvbmVudHMuZW0+e1wiKG5vcm1hdGl2ZSlcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIHJlcG9ydCBoZWFkZXIncyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJSZXZpZXdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIC8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQ2xvc2UgcmV2aWV3XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBwYWlyIGJlY29tZXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz48X2NvbXBvbmVudHMuY29kZT57XCJXb3JrYm9va1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnN0cm9uZz57XCIgLyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPjxfY29tcG9uZW50cy5jb2RlPntcIkNsb3NlIHdvcmtib29rXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoYm90aCBzdHJpbmdzLCBETi1SMTMpLiBJdCBpcyB0aGUgZG9vciB0byB0aGUgZm9ybXVsYSwgdGVzdCwgZGF0YSBhbmRcXG52b2NhYnVsYXJ5IHN1cmZhY2VzOyBcXFwiUmV2aWV3XFxcIiBkZXNjcmliZWQgb25seSB0aGUgcGFuZWwncyBmaXJzdCBmZWF0dXJlLCBhbmQgdGhlIHZlcnlcXG5maXJzdCBkaXNjb3ZlcmFiaWxpdHkgY29tcGxhaW50IG9mIHRoaXMgdGhyZWFkIHdhcyB0aGF0IG5vdGhpbmcgc2FpZCB0aGUgcGFuZWwgZXhpc3RlZC5cXG5UaGUgYnV0dG9uIGlzIGNvbnN1bWVyLXZpc2libGUgYW5kIHVuY2hhbmdlZCBpbiBcIn08X2NvbXBvbmVudHMuZW0+e1wiYmVoYXZpb3VyXCJ9PC9fY29tcG9uZW50cy5lbT57XCI6IGEgdmlld2VyIHdobyBuZXZlciBwcmVzc2VzXFxuaXQgc2VlcyBleGFjdGx5IHdoYXQgdGhleSBzYXcgYmVmb3JlLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaHIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDEgaWQ9XCJwYXJ0LWItdGhlLWVkaXQtYWZmb3JkYW5jZS1kZXNpZ24tYmxvY2tlZC1vbi01XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJwYXJ0LWItdGhlLWVkaXQtYWZmb3JkYW5jZS1kZXNpZ24tYmxvY2tlZC1vbi01XCIgLz57XCJQYXJ0IEIg4oCUIHRoZSBlZGl0IGFmZm9yZGFuY2UgIFwifTxfY29tcG9uZW50cy5lbT57XCIoZGVzaWduOyBCTE9DS0VEIG9uIMKnNSlcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMuaDE+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTNcIiBkYXRhLXNsdWc9XCIzLXRoZS1zdXJmYWNlLXdoZW4taXQtaXMtdW5ibG9ja2VkLXByb3Bvc2FsLW5vdC1idWlsdFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTNcIiAvPntcIjMuIFRoZSBzdXJmYWNlLCB3aGVuIGl0IGlzIHVuYmxvY2tlZCAgXCJ9PF9jb21wb25lbnRzLmVtPntcIihwcm9wb3NhbCDigJQgbm90IGJ1aWx0KVwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJXaGVyZSB0aGUgYXBwIGFscmVhZHkgbmFtZXMgYSBmaWxlLCBhbiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImVkaXQgYWN0aW9uIGJlc2lkZSB0aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZmlsZTpsaW5lXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhbmNob3JcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCI6XFxudGhlIHZhbHVlIGluc3BlY3RvcidzIGZvcm11bGEgcm93IGFuZCBpdHMgdGVzdCByb3dzLiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIkFic2VudCDigJQgbm90IGRpc2FibGVkIOKAlCB3aGVuIHRoZVxcbmRvY3VtZW50IGlzIG5vdCBlZGl0YWJsZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIjsgZWRpdG9yLWZpcnN0IMKnNyBydWxlIDMgZm9yYmlkcyBhIGNvbnRyb2wgdGhhdCBjb21lcyBiYWNrXFxucmVhZC1vbmx5LCBhbmQgYSBncmV5ZWQgY29udHJvbCBzdGlsbCBjbGFpbXMgdGhlIGFjdGlvbiBleGlzdHMgaGVyZS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVHdvIHNjb3BlIGNvcnJlY3Rpb25zIHRoZSByZXZpZXcgZm9yY2VkOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVGhlIGF1dGhvcidzLXZpZXcgaW5kZXggcm93cyBhcmUgb3V0IG9mIFBhcnQgQidzIHYxIChETi1SMTApLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGV5IGNhcnJ5IG5vXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZmlsZTpsaW5lXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhbmNob3IgdG9kYXksIGFuZCBnaXZpbmcgdGhlbSBvbmUgbWVhbnMgd2lkZW5pbmcgdGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlJlZmxlY3Rpb25Qb3J0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB3aXRoXFxuYSB3b3Jrc2hlZXTihpJwYXRoIGZpZWxkIOKAlCBhIGNoYW5nZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJBVVRIT1JTX1ZJRVdfU1BFQ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgwqczIGdvdmVybnMgYXMgYSBmaWVsZC1ieS1maWVsZFxcbmFsbG93bGlzdC4gQm9va2VkICjCpzExIFE1KSwgbm90IHNtdWdnbGVkLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVGhlIGNvbnN1bWVyIGluc3BlY3RvciBjYXJyeWluZyBhbiBhdXRob3JpbmcgZG9vciBpcyBhbiBvcGVuIHByb2R1Y3QgZGVjaXNpb25cXG4oRE4tUjEzKS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhlIGluc3BlY3RvciByZW5kZXJzIGZvciBhbnkgcmVwb3J0IHZpZXdlci4gVGhlIGZvcm11bGEgXCJ9PF9jb21wb25lbnRzLmVtPntcInRleHRcIn08L19jb21wb25lbnRzLmVtPntcIiBpcyBhbHJlYWR5XFxudGhlcmUsIHNvIHRoaXMgaXMgbm90IGEgbmV3IGRpc2Nsb3N1cmUg4oCUIGJ1dCBhbiBlZGl0IGRvb3IgaXMgYSBtYXRlcmlhbGx5IGRpZmZlcmVudCBhY3RcXG5mcm9tIGEgcmVhZCB2aWV3LCBhbmQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQVVUSE9SU19WSUVXX1NQRUNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIMKnNidzIHByZWNlZGVudCAoQVYtUjEpIGlzIHRoYXQgXFxcIndoZXJlIGFuXFxuYXV0aG9yaW5nIHN1cmZhY2UgbWF5IHJlbmRlclxcXCIgaXMgYSBwcm9kdWN0IGRlY2lzaW9uIHRvIGJlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibWFkZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgbm90IGluZmVycmVkIGZyb21cXG53aGljaCBzdXJmYWNlcyBoYXBwZW4gdG8gaG9sZCB0aGUgZGF0YS4gUTYuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInNlYy00XCIgZGF0YS1zbHVnPVwiNC10aGUtZGVsZWdhdGlvbi1hcy1kZXNpZ25lZC1wcm9wb3NhbC1ub3QtYnVpbHRcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy00XCIgLz57XCI0LiBUaGUgZGVsZWdhdGlvbiwgYXMgZGVzaWduZWQgIFwifTxfY29tcG9uZW50cy5lbT57XCIocHJvcG9zYWwg4oCUIG5vdCBidWlsdClcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnByZT48X2NvbXBvbmVudHMuY29kZSBjbGFzc05hbWU9XCJsYW5ndWFnZS10c1wiPntcImNvbnN0IHsgaW52b2tlVGFzaywgY2FwRmlsZSB9ID0gYXdhaXQgaW1wb3J0KCdAaW1tZWRpYXRlbHktcnVuL3Nkay90YXNrcycpOyAvLyDCpzQuMVxcbmNvbnN0IHJlc3VsdCA9IGF3YWl0IGludm9rZVRhc2s8RWRpdEZpbGVSZXN1bHQ+KCdlZGl0LWZpbGUnLCB7XFxuICBmaWxlOiBjYXBGaWxlKHsgbW91bnRJZCwgcmVsUGF0aCB9LCB7IG1vZGU6ICdydycgfSksXFxufSk7XFxuXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMucHJlPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cInNlYy00LTFcIiBkYXRhLXNsdWc9XCI0MS10aGUtaW1wb3J0LW11c3QtYmUtbGF6eS1ub3JtYXRpdmUtZm9yLXRoZS1pbXBsZW1lbnRhdGlvbi1kbi1yNVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTQtMVwiIC8+e1wiNC4xIFRoZSBpbXBvcnQgbXVzdCBiZSBsYXp5ICBcIn08X2NvbXBvbmVudHMuZW0+e1wiKG5vcm1hdGl2ZSBmb3IgdGhlIGltcGxlbWVudGF0aW9uLCBETi1SNSlcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLmNvZGU+e1wiQGltbWVkaWF0ZWx5LXJ1bi9zZGsvdGFza3NcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicmVnaXN0ZXJzIGEgaG9zdCBsaXN0ZW5lciBhdCBtb2R1bGUgbG9hZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBhbmQgdGhyb3dzIHdpdGhcXG5ubyBob3N0IHRyYW5zcG9ydC4gQSBzdGF0aWMgdmFsdWUgaW1wb3J0IHdoaXRlLXNjcmVlbnMgdGhlIGFwcCB1bmRlciBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ2aXRlIGRldlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIHRoZVxcbnJlcG8gYWxyZWFkeSBkb2N1bWVudHMgZXhhY3RseSB0aGlzIGhhemFyZCBpbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ1c2VNb3VudHMudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFuZCBkb2RnZXMgaXQgYnkgaW1wb3J0aW5nXFxudGhlIHNpZGUtZWZmZWN0LWNsZWFuIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1vdW50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgc3VicGF0aC4gVGhlIGRlbGVnYXRpb24gdGhlcmVmb3JlIHVzZXMgYSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImR5bmFtaWNcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJpbXBvcnQoKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaW5zaWRlIHRoZSBjbGljayBoYW5kbGVyXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCB3cmFwcGVkIHNvIGEgaG9zdC1sZXNzIGVudmlyb25tZW50IGlzIGEgbm8tb3Ag4oCUXFxudGhlIHNhbWUgc2hhcGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicmVwb3J0U2Vzc2lvbi50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdXNlcyBmb3IgdGhlIHdvcmtlciBVUkwuIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJpbXBvcnQgdHlwZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaXMgZXJhc2VkIGFuZFxcbnN0YXlzIGZpbmUuKVwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCJzZWMtNC0yXCIgZGF0YS1zbHVnPVwiNDItYm90aC1jaGFubmVscy1jYXJyeS1yZWZ1c2Fscy1kbi1yMVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTQtMlwiIC8+e1wiNC4yIEJvdGggY2hhbm5lbHMgY2FycnkgcmVmdXNhbHMgIFwifTxfY29tcG9uZW50cy5lbT57XCIoRE4tUjEpXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5jb2RlPntcImludm9rZVRhc2tcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1widGhyb3dzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHdpdGggYSBtYWNoaW5lIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi5jb2RlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2FuY2VsbGVkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widGltZW91dFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcImZvcmJpZGRlblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibm8tc3VjaC10YXNrXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widGFzay1jeWNsZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcInRhc2stZGVwdGgtZXhjZWVkZWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ0YXNrLXZlcnNpb24tbWlzbWF0Y2hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcImludmFsaWQtcGFyYW1zXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJhbmQgcmV0dXJucyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyZXMuZGF0YVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdW5leGFtaW5lZCBvbiBzdWNjZXNzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBzbyBhIHN0YXR1cyB0aGUgaG9zdFxcbmNhcnJpZXMgXCJ9PF9jb21wb25lbnRzLmVtPntcImluIHRoZSByZXN1bHRcIn08L19jb21wb25lbnRzLmVtPntcIiBpcyBzaWxlbnRseSBkaXNjYXJkZWQgYnkgYSBjYWxsIHRoYXQgaWdub3JlcyBpdHMgcmV0dXJuIHZhbHVlLlxcblRoZSBkcmFmdCBtYXBwZWQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicmVhZC1vbmx5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhcyBhIHJlamVjdGlvbiBjb2RlOyBpdCBpcyBub3Qgb25lLiBUaGUgaW1wbGVtZW50YXRpb24gbXVzdFxcbmJpbmQgdGhlIHJlc3VsdCBhbmQgaW5zcGVjdCBpdCwgYW5kIHRoZSBleGFjdCByZXN1bHQgY29udHJhY3QgaXMgwqc1J3MgcHJlY29uZGl0aW9uIFAzLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5jb2RlPntcImNhbmNlbGxlZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oaSIHNpbGVudCAodGhlIHVzZXIgZGlzbWlzc2VkIHRoZSBlZGl0b3I7IG5vdCBhbiBlcnJvcikuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLmNvZGU+e1wiZm9yYmlkZGVuXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAvIGEgcmVzdWx0LWNhcnJpZWQgcmVmdXNhbCDihpIgb25lIHBsYWluIG1lc3NhZ2UsIGFuZCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInN0b3Agb2ZmZXJpbmcgdGhlXFxuYWZmb3JkYW5jZSBmb3IgdGhhdCBtb3VudCBzdGF0ZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBzbyBhIHN0YWxlIGdyYW50IGNhbm5vdCBwcm9kdWNlIHJlcGVhdGVkIGRlYWQgY2xpY2tzLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIkFueXRoaW5nIGVsc2Ug4oaSIGEgYnJpZWYgbWVzc2FnZSBuYW1pbmcgdGhlIGNvZGUuIE5ldmVyIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkVST0ZTXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBwcm9zZSwgbmV2ZXIgYSBzdGFjay5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwic2VjLTQtM1wiIGRhdGEtc2x1Zz1cIjQzLXJlbHBhdGgtaXMtdW50cnVzdGVkLWF1dGhvci1jb250ZW50LWRuLXI3XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtNC0zXCIgLz57XCI0LjMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicmVsUGF0aFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaXMgdW50cnVzdGVkIGF1dGhvciBjb250ZW50ICBcIn08X2NvbXBvbmVudHMuZW0+e1wiKEROLVI3KVwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuY29kZT57XCJtYW5pZmVzdC53b3Jrc2hlZXRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpcyB2YWxpZGF0ZWQgb25seSBmb3Igbm9uLWVtcHR5LXN0cmluZy1uZXNzLCBhbmQgdGhlIGxvYWRlclxcbmNvbXBvc2VzIHBhdGhzIHdpdGhvdXQgcmVzb2x2aW5nIFwifTxfY29tcG9uZW50cy5jb2RlPntcIi4uXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi4gVW5kZXIgcmVwbyBkaXNwYXRjaCB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJhdXRob3IgaXMgbm90IHRoZVxcbnZpZXdlclwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgc28gYSBob3N0aWxlIHdvcmtib29rIGNvdWxkIHByZXNlbnQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wid29ya3NoZWV0cy8uLi8uLi8uLi9ldGMvcGFzc3dkLnNoZWV0LmpzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIlxcbmFzIGEgcGF0aCB0byBkZWxlZ2F0ZS4gV2hhdGV2ZXIgdGhlIGhvc3QgZG9lcyB3aXRoIHRoYXQsIFwifTxfY29tcG9uZW50cy5lbT57XCJ0aGlzIGFwcFwifTwvX2NvbXBvbmVudHMuZW0+e1wiIG11c3Qgbm90IGNvbnN0cnVjdFxcbnRoZSBkZWxlZ2F0aW9uOiByZWplY3QgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLi5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHNlZ21lbnRzLCBhYnNvbHV0ZSBwYXRocywgYW5kIGFueXRoaW5nIG5vdCB1bmRlciBhIGtub3duXFxuZG9jdW1lbnQgc3ViZGlyZWN0b3J5LCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImJlZm9yZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjYXBGaWxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi4gVGhlIGRyYWZ0J3MgYmxhbmtldCBcXFwibm90aGluZyBoZXJlIHdpZGVuc1xcbmF1dGhvcml0eVxcXCIgaXMgdHJ1ZSBvZiB0aGUgY2FwYWJpbGl0eSBtb2RlbCBhbmQgd2FzIG5vdCB0cnVlIG9mIHdoYXQgdGhpcyBhcHAgd291bGQgaGF2ZVxcbmhhbmRlZCBpdC5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwic2VjLTQtNFwiIGRhdGEtc2x1Zz1cIjQ0LXdoYXQtaGFwcGVucy1hZnRlci10aGUtZWRpdC1kbi1yMTFcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy00LTRcIiAvPntcIjQuNCBXaGF0IGhhcHBlbnMgYWZ0ZXIgdGhlIGVkaXQgIFwifTxfY29tcG9uZW50cy5lbT57XCIoRE4tUjExKVwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkEgZGVmZWN0IHRoaXMgZmVhdHVyZSB3b3VsZCBpbnRyb2R1Y2UsIG5vdCBvbmUgaXQgaW5oZXJpdHMuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRoZSBzZXNzaW9uIHJlYWRzIHRoZVxcbmRvY3VtZW50IG9uY2UgYW5kIHRoZSBkaXNwYXRjaCByZXNvbHV0aW9uIGxhdGNoZXMgb24gdGhlIGZpcnN0IGNvbnRlbnQgbW91bnQ7IHRoZXJlIGlzXFxubm8gZmlsZXN5c3RlbSB3YXRjaC4gU286IGVkaXQsIHNhdmUsIHJldHVybiDigJQgYW5kIHRoZSByZXBvcnQgc2hvd3MgdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wib2xkIG51bWJlcnNcXG53aXRoIG5vIGluZGljYXRpb24gdGhleSBhcmUgc3RhbGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIsIGluIGEgcHJvZHVjdCB3aG9zZSB3aG9sZSBwcm9wb3NpdGlvbiBpcyB0aGF0XFxuZGlzcGxheWVkIGZpZ3VyZXMgYXJlIGN1cnJlbnQuIFBhcnQgQiB0aGVyZWZvcmUgZG9lcyBub3Qgc2hpcCB3aXRob3V0IGVpdGhlciBhXFxuZG9jdW1lbnQtY2hhbmdlZCBhZmZvcmRhbmNlIG9yIGFuIGV4cGxpY2l0LCBnYXRlZCBzdGF0ZW1lbnQgdGhhdCB0aGUgcmVuZGVyIGlzIHN0YWxlLlxcblxcXCJXaGF0ZXZlciByZWxvYWQgc3RvcnkgdGhlIGRpc3BhdGNoIGZsb3cgaGFzXFxcIiBhc3NlcnRlZCBhIG1lY2hhbmlzbSB0aGF0IGRvZXMgbm90IGV4aXN0LlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJBZGRpdGlvbmFsbHksIHBlciBcIn08X2NvbXBvbmVudHMuY29kZT57XCJSRVBPX0NPTlRFTlRfRElTUEFUQ0hfU1BFQ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgwqc1LjEgYW5kIEdyb3ZlJ3MgcHJlY2VkZW50LCB0aGVcXG5hZmZvcmRhbmNlIG11c3QgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJkaXNjbG9zZSBhdCB0aGUgYnV0dG9uXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHRoYXQgZWRpdHMgc2F2ZSB0byB0aGUgbW91bnRlZCBjb250ZW50IGFuZFxcbnByb3Bvc2luZyB0aGVtIGJhY2sgdG8gdGhlIHNvdXJjZSByZXBvc2l0b3J5IGlzIG5vdCB3aXJlZC5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTVcIiBkYXRhLXNsdWc9XCI1LXdoeS1wYXJ0LWItaXMtYmxvY2tlZC10aGUtcHJlY29uZGl0aW9ucy1ub3JtYXRpdmVcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy01XCIgLz57XCI1LiBXaHkgUGFydCBCIGlzIGJsb2NrZWQg4oCUIHRoZSBwcmVjb25kaXRpb25zICBcIn08X2NvbXBvbmVudHMuZW0+e1wiKG5vcm1hdGl2ZSlcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiRWFjaCBpcyBhIHF1ZXN0aW9uIGFib3V0IHRoZSBob3N0IHRoYXQgdGhpcyByZXBvIGNhbm5vdCBhbnN3ZXIsIGFuZCBlYWNoIHdvdWxkLCBpZlxcbmd1ZXNzZWQgd3JvbmcsIHByb2R1Y2UgYSBmZWF0dXJlIHRoYXQgc2hpcHMgYW5kIG5ldmVyIHdvcmtzOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudGFibGU+PF9jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGg+e1wiI1wifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIlByZWNvbmRpdGlvblwifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIldoeSBndWVzc2luZyBmYWlsc1wifTwvX2NvbXBvbmVudHMudGg+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50Ym9keT48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUDFcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJXaGF0IGEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widHlwZTogJ2NvbnRlbnQnXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBkaXNwYXRjaCBtb3VudCBjYXJyaWVzIGFzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+PF9jb21wb25lbnRzLmNvZGU+e1wiaWRcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBhbmQgd2hldGhlciBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjYXBGaWxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIidzIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1vdW50SWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFjY2VwdHMgaXQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ1bnF1YWxpZmllZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIlRoZSBTREsncyBvd24gZXhhbXBsZXMgc2hvdyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJpZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYXMgYSBiYXJlIHNwYWNlSWQgYnV0IFwifTxfY29tcG9uZW50cy5jb2RlPntcImNhcEZpbGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcIm1vdW50XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB0YWtpbmcgYSB1bml2ZXJzYWwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic2NoZW1lOmxvY2F0b3JcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcGFjZTphYmNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKS4gQSB3cm9uZyBub3RhdGlvbiByZWZ1c2VzIFwifTxfY29tcG9uZW50cy5jb2RlPntcImZvcmJpZGRlblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgb24gZXZlcnkgY2FsbCDigJQgd2hpY2ggwqc0LjIgd291bGQgdGhlbiBtaXNkaWFnbm9zZSBhcyBhIHBlcm1pc3Npb25zIHN0YXRlIGFuZCBwZXJtYW5lbnRseSBzdXBwcmVzcyAoRE4tUjQpLlwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUDJcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJXaGF0IHRoYXQgbW91bnQgcmVwb3J0cyBmb3IgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz48X2NvbXBvbmVudHMuY29kZT57XCJtb2RlXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBhbmQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz48X2NvbXBvbmVudHMuY29kZT57XCJydWxlc1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIGFuZCwgaWYgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicnVsZXNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCB3aGV0aGVyIGl0cyBcXFwiYmFja2VuZC1uYXR1cmFsXFxcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzdWJ0cmVlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBwYXRocyBhcmUgY29tcGFyYWJsZSB0byBkb2N1bWVudC1yZWxhdGl2ZSBwYXRoc1wifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIkEgZGlzcGF0Y2hlZCBjb250ZW50IG1vdW50IGlzIGEgcmVwbyBtb3VudCwgYW5kIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1vZGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcInJ1bGVzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhcmUgZG9jdW1lbnRlZCBhYnNlbnQgb24gdGhlIHByaW1hcnkgcmVwbyBtb3VudC4gVGhlIGRyYWZ0J3MgXFxcImFic2VudCDih5Igd3JpdGFibGVcXFwiIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiaW52ZXJ0ZWQgUi1FRkUtMSdzIHBvc2l0aXZlIFwifTxfY29tcG9uZW50cy5jb2RlPntcInJ3XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjaGVja1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBhbmQgd2FzIHRoZSBvbmx5IGJyYW5jaCB0aGF0IHdvdWxkIGV2ZXIgcnVuOyBtZWFud2hpbGUgdGhpcyByZXBvJ3Mgb3duIGRpc3BhdGNoIGZpeHR1cmVzIHN0YW1wIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1vZGU6ICdybydcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLiBPbmUgb2YgdGhvc2UgbWFrZXMgdGhlIGFmZm9yZGFuY2UgYWx3YXlzLW9uLCB0aGUgb3RoZXIgYWx3YXlzLW9mZiAoRE4tUjIpLiBBbmQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3VidHJlZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaXMgc2xhc2gtcm9vdGVkIHdoaWxlIGRvY3VtZW50IHBhdGhzIGFyZSBub3QsIHNvIHRoZSBkcmFmdCdzIGZhaWwtY2xvc2VkIHByZWZpeCBtYXRjaCB3b3VsZCBoYXZlIGRpc2FibGVkIGVkaXRpbmcgZXZlcnl3aGVyZSB0aGUgaG9zdCBcIn08X2NvbXBvbmVudHMuZW0+e1wiZGlkXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgcmVwb3J0IHJ1bGVzIChETi1SMykuXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnN0cm9uZz57XCJQM1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIldoaWNoIGNoYW5uZWwgY2FycmllcyBhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+PF9jb21wb25lbnRzLmNvZGU+e1wicmVhZC1vbmx5XCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiByZWZ1c2FsIGZvciB0aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZWRpdC1maWxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB0YXNrIOKAlCByZWplY3Rpb24gb3IgcmVzdWx0IOKAlCBhbmQgaXRzIGV4YWN0IHNoYXBlXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiwqc0LjIgZXhpc3RzIHRvIGhhbmRsZSBpdDsgYSBjYWxsIHRoYXQgaWdub3JlcyBpdHMgcmV0dXJuIHZhbHVlIGhhbmRsZXMgbm90aGluZyAoRE4tUjEpLlwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUDRcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJXaGV0aGVyIFJlY2tvbmVyJ3MgcmVnaXN0cnkgYmluZGluZyBob2xkcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPjxfY29tcG9uZW50cy5jb2RlPntcInRhc2s6aW52b2tlXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIlRoZSBtYW5pZmVzdCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJpbnZva2VzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBkZWNsYXJhdGlvbiBpcyBcIn08X2NvbXBvbmVudHMuZW0+e1wiXFxcImEgcmVxdWVzdCBhbmQgYSBzZWxmLXJlc3RyaWN0aW9uLCBuZXZlciBhIGdyYW50XFxcIlwifTwvX2NvbXBvbmVudHMuZW0+e1wiOyBjYXBhYmlsaXRpZXMgY29tZSBmcm9tIHRoZSBob3N0IHJlZ2lzdHJ5LCB3aGljaCB0aGlzIHJlcG8gY2Fubm90IGRlY2xhcmUgaW50by4gV2l0aG91dCBpdCBldmVyeSBpbnZvY2F0aW9uIHJlZnVzZXMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZm9yYmlkZGVuXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgdGhlIGZlYXR1cmUgc2hpcHMgZGFyaywgcGVybWFuZW50bHkgKEROLVI2KS5cIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50Ym9keT48L19jb21wb25lbnRzLnRhYmxlPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQW5kIG9uZSBwcm9kdWN0IHByZWNvbmRpdGlvbiwgUDU6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHdoZXRoZXIgdGhlIGRpc3BhdGNoZWQgc2hhcGUgaXMgcmVhY2hhYmxlIGJ5IGFcXG51c2VyIGF0IGFsbCB0b2RheS4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiUkVQT19DT05URU5UX0RJU1BBVENIX1NQRUNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGlzIGEgcHJvcG9zYWwsIG5vIHN0YXR1cyBkb2MgZXhpc3RzIGZvclxcbml0LCBhbmQgbm8gd29ya2Jvb2sgcmVwbyBpcyBuYW1lZCDigJQgc28gb24gdGhlIHNoYXBlIHVzZXJzIGNhbiBydW4gKFwifTxfY29tcG9uZW50cy5jb2RlPntcIj9kb2M9Y2FsZGVyYVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLFxcblBhcnQgQiByZW5kZXJzIG5vdGhpbmcgYW55d2hlcmUgKEROLVIxMikuIElmIG5vYm9keSBjYW4gcmVhY2ggdGhlIGRpc3BhdGNoZWQgc2hhcGUsIHRoZVxcbmhvbmVzdCBzZXF1ZW5jaW5nIGlzIHRvIGJ1aWxkIHRoYXQgcGF0aCBmaXJzdCwgbm90IHRvIHNoaXAgYW4gaW52aXNpYmxlIGFmZm9yZGFuY2VcXG5hZ2FpbnN0IGl0LlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlRoZSBydWxlOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBQYXJ0IEIgaXMgaW1wbGVtZW50ZWQgd2hlbiBQMeKAk1A0IGFyZSBlc3RhYmxpc2hlZCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImFnYWluc3QgYSByZWFsIGhvc3RcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCJcXG4oYSBicm93c2VyLWRyaXZlbiBvYnNlcnZhdGlvbiBvZiBhIGRpc3BhdGNoZWQgbW91bnQsIHBlciB0aGlzIHJlcG8ncyBvd24gZGVidWdnaW5nXFxuZ3VpZGFuY2Ug4oCUIG5vdCBhbm90aGVyIHVuaXQgdGVzdCB3aXRoIGFuIGluamVjdGVkIHBvcnQpLCBhbmQgUDUgaXMgYW5zd2VyZWQuIFVudGlsIHRoZW5cXG50aGlzIGRvY3VtZW50IGlzIHRoZSBkZXNpZ24gYW5kIFIzLTQ0NyBpcyB0aGUgaXRlbSB0aGF0IGVzdGFibGlzaGVzIHRoZSBjb250cmFjdC5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmhyIC8+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTZcIiBkYXRhLXNsdWc9XCI2LW91dC1vZi1zY29wZS10aGUtaG9uZXN0LXJlbWFpbmRlci1ub3JtYXRpdmVcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy02XCIgLz57XCI2LiBPdXQgb2Ygc2NvcGUg4oCUIHRoZSBob25lc3QgcmVtYWluZGVyICBcIn08X2NvbXBvbmVudHMuZW0+e1wiKG5vcm1hdGl2ZSlcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkVkaXRpbmcgZml4dHVyZSByb3dzIC8gdGFidWxhciBkYXRhIGJ5IGhhbmQuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRoZSBhbnN3ZXIgaXMgYSBwbGF0Zm9ybVxcblwifTxfY29tcG9uZW50cy5zdHJvbmc+PF9jb21wb25lbnRzLmNvZGU+e1wiZWRpdC10YWJsZVwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnN0cm9uZz57XCIgdGFzayBjb250cmFjdCAoYSBzaWJsaW5nIG9mIFwifTxfY29tcG9uZW50cy5jb2RlPntcImVkaXQtZmlsZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCI6IGFueSBhcHAgaG9sZGluZyBhIGdyYW50IG9uIGFcXG5DU1YvSlNPTi1yb3dzIGZpbGUgZGVsZWdhdGVzIGl0LCB0aGUgaG9zdCBvcGVucyBhIHRhYmxlIHN1cmZhY2UpIOKAlCBub3QgYSBncmlkIGluc2lkZVxcblJlY2tvbmVyLCB3aGljaCB3b3VsZCBuZWVkIGFuIGVkaXRvci1maXJzdCDCpzIganVzdGlmaWNhdGlvbiBpdCBkb2VzIG5vdCBoYXZlLCBhbmRcXG53aGljaCBldmVyeSBvdGhlciB0YWJ1bGFyIGFwcCB3b3VsZCB0aGVuIG5lZWQgdG9vLiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIldyaXR0ZW4gMjAyNi0wOC0yOTpcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJkb2NzL2NvbnRlbnQvc3BlY3MvRURJVF9UQUJMRV9UQVNLX1NQRUMubWR4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAocHJvcG9zYWwgcmV2IDIsIHBvc3QtcmV2aWV3KS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgSXQgaXNcXG5ibG9ja2VkIG9uIHRoZSBzYW1lIFAx4oCTUDUgdGhpcyBzcGVjJ3Mgwqc1IGxpc3RzLCBwbHVzIHR3byBvZiBpdHMgb3duIChkZWxlZ2F0aW9uIG1vdW50c1xcbmFubm91bmNlIG5vIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1vZGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiOyBSZWNrb25lciBoYXMgbm8gZnMgd2F0Y2gpIOKAlCBzbyBSMy00NDcncyBob3N0IHNwaWtlIHVuYmxvY2tzIGJvdGguXFxuSXRzIHJldmlldyBhbHNvIGZvdW5kIHRoZSBzZWVkLXZzLW1vdW50IHdhbGwgYXBwbGllcyB0byBmaXh0dXJlcyBleGFjdGx5IGFzIGl0IGRvZXNcXG5oZXJlOiBvbiB0aGUgYnVuZGxlZC1zZWVkIHBhdGggdGhlcmUgaXMgbm8gZmlsZSB0byBkZWxlZ2F0ZS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIk9wZW4tYXQtbGluZS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhlIHNwYW5zIGV4aXN0IChSMy00MjcpOyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJlZGl0LWZpbGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNhcnJpZXMgbm8gcG9zaXRpb24gaGludC5cXG5BIHNtYWxsIFNESy9lZGl0b3IgZGVsdGEsIGJvb2tlZCBhZ2FpbnN0IFwifTxfY29tcG9uZW50cy5jb2RlPntcIkVESVRPUl9GSVJTVF9FRElUSU5HX1NQRUNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIMKnNi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIk9wZW5pbmcgYSBtb3VudGVkIGZpbGUgaW4gdGhlIFwifTxfY29tcG9uZW50cy5lbT57XCJtYWluXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgZWRpdG9yXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHJhdGhlciB0aGFuIHRoZSBvdmVybGF5IOKAlCBEZWx0YSBCLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQ2xpY2stdG8taW5zZXJ0IC8gdGVtcGxhdGUgbXV0YXRpb24uXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFBsYWNlbWVudCwgc2VyaWFsaXphdGlvbiBhbmRcXG5yb3VuZC10cmlwLXRocm91Z2gtdGhlLXBhcnNlciBhcmUgYSBkZXNpZ24gb2YgdGhlaXIgb3duOyB0aGUgdm9jYWJ1bGFyeSBzZWN0aW9uIHBsdXMgYVxcbnRlbXBsYXRlIGVkaXQgZG9vciBjb3ZlcnMgdGhlIGZsb3cgYXQgYSBmcmFjdGlvbiBvZiB0aGUgc3VyZmFjZS4gTm90ZSBQYXJ0IEIncyB2MSBoYXNcXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vIHRlbXBsYXRlLWZpbGUgcm93XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCB0aGUgXFxcImNvcHkgdGhlIHNuaXBwZXQsIG9wZW4gdGhlIHRlbXBsYXRlXFxcIiBmbG93IG5lZWRzIG9uZSxcXG5ib29rZWQgd2l0aCBQYXJ0IEIgKFE3KS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkFuIGVkaXQgYWZmb3JkYW5jZSBvbiB0aGUgYXBwJ3Mgb3duIHNvdXJjZSBpbiB0aGUgZnVzZWQgc2hhcGUuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5jb2RlPntcInJlcXVlc3RFZGl0KClcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxubGFuZGVkIGFuZCB3b3VsZCB3b3JrLCBidXQgXFxcImVkaXQgdGhlIGFwcCB5b3UgYXJlIHJ1bm5pbmdcXFwiIGlzIGEgZGlmZmVyZW50IGFjdCBmcm9tXFxuXFxcImVkaXQgdGhpcyBkb2N1bWVudCdzIGZpbGVcXFwiOyBjb25mbGF0aW5nIHRoZW0gaW4gb25lIGNvbnRyb2wgaXMgaG93IHNvbWVvbmUgZWRpdHMgdGhlXFxud3JvbmcgdGhpbmcuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5ociAvPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInNlYy03XCIgZGF0YS1zbHVnPVwiNy1nYXRlcy1ub3JtYXRpdmUtZm9yLXBhcnQtYS1wYXJ0LWJzLWFyZS1zdGF0ZWQtYnV0LXVuZXhlcmNpc2VkXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtN1wiIC8+e1wiNy4gR2F0ZXMgIFwifTxfY29tcG9uZW50cy5lbT57XCIobm9ybWF0aXZlIGZvciBQYXJ0IEE7IFBhcnQgQidzIGFyZSBzdGF0ZWQgYnV0IHVuZXhlcmNpc2VkKVwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCJwYXJ0LWEtc2hpcHBlZFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwicGFydC1hLXNoaXBwZWRcIiAvPntcIlBhcnQgQSDigJQgc2hpcHBlZFwifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnRhYmxlPjxfY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRoPntcIkdhdGVcIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aD57XCJUZXN0XCJ9PC9fY29tcG9uZW50cy50aD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGhlYWQ+PF9jb21wb25lbnRzLnRib2R5PjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnN0cm9uZz57XCJHLUROLUExXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiVGhlIHZvY2FidWxhcnkgc2VjdGlvbiBlbnVtZXJhdGVzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZXZlcnlcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgZW50cnkgaW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2F0YWxvZy50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIGFzc2VydGVkIGFnYWluc3QgdGhlIGNhdGFsb2cgaXRzZWxmLCBuZXZlciBhIGxpdGVyYWwgbGlzdCwgc28gYSBmdXR1cmUgY2F0YWxvZyBhZGRpdGlvbiBhcHBlYXJzIHdpdGhvdXQgdG91Y2hpbmcgdGhlIHNlY3Rpb24uXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnN0cm9uZz57XCJHLUROLUEyXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiQXR0cmlidXRlcyByZW5kZXIgd2l0aCBuYW1lLCB0eXBlLCByZXF1aXJlZCBtYXJrZXIgYW5kIGVudW0gdmFsdWVzLCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImluY2x1ZGluZyBwZXItdmFyaWFudCBhdHRyaWJ1dGVzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChhIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkNoYXJ0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBzaG93cyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJraW5kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhbmQgdGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcImJhclwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdmFyaWFudCdzIFwifTxfY29tcG9uZW50cy5jb2RlPntcInhcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcInlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSwgYW5kIHdpZGdldHMgYXJlIG1hcmtlZCBhcyB3aWRnZXRzLlwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRy1ETi1BM1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRXZlcnkgZ2VuZXJhdGVkIHNuaXBwZXQgcGFyc2VzIGFuZCB2YWxpZGF0ZXMgd2l0aCB6ZXJvIFwifTxfY29tcG9uZW50cy5jb2RlPntcImVycm9yXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBkaWFnbm9zdGljc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgdGhlIGZhbHNpZmlhYmxlIGZvcm0gb2YgXFxcInVzYWJsZVxcXCIsIHJ1biBvdmVyIHRoZSB3aG9sZSBjYXRhbG9nIHNvIG5vIGVudHJ5IGNhbiByZWdyZXNzIHNpbGVudGx5ICh2YXJpYW50cywgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRmFjZXRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiUGFyYW1zXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiU2hvdypcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJUYWJsZS5jb2x1bW5zXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiU2VsZWN0Lm9wdGlvbnNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFsbCBpbmNsdWRlZCkuXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnN0cm9uZz57XCJHLUROLUE0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiVGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcIndpZGdldHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGZpbHRlciB5aWVsZHMgZXhhY3RseSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJXSURHRVRTXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY29tcG9uZW50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgeWllbGRzIGV4YWN0bHkgdGhlIGNvbXBsZW1lbnQ7IHVuc2V0IHlpZWxkcyBhbGwg4oCUIHRoZSB0aGlyZCBjYXNlIHRoZSBkcmFmdCBsZWZ0IHVuZGVmaW5lZC5cIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkctRE4tQTVcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJUaGUgcGFuZWwgcmVuZGVycyB0aGUgc2VjdGlvbiB3aXRoIG5vIGRvY3VtZW50IGxvYWRlZCBiZXlvbmQgdGhlIHNlZWQsIGFuZCB3aXRoIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibm8gaG9zdCB0cmFuc3BvcnRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHRoZSB2b2NhYnVsYXJ5IG11c3Qgbm90IGltcG9ydCBhbnl0aGluZyB0aGF0IHRocm93cyBhdCBtb2R1bGUgbG9hZCAodGhlIMKnNC4xIGhhemFyZCwgYXNzZXJ0ZWQgZm9yIFBhcnQgQSB0b28pLlwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRy1ETi1BNlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIlRoZSBoZWFkZXIgYnV0dG9uIHJlYWRzIFwifTxfY29tcG9uZW50cy5jb2RlPntcIldvcmtib29rXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAvIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkNsb3NlIHdvcmtib29rXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi5cIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50Ym9keT48L19jb21wb25lbnRzLnRhYmxlPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cInBhcnQtYi1zdGF0ZWQtdW5leGVyY2lzZWQtdW50aWwtNS1jbGVhcnNcIj48SGVhZGluZ0FuY2hvciBpZD1cInBhcnQtYi1zdGF0ZWQtdW5leGVyY2lzZWQtdW50aWwtNS1jbGVhcnNcIiAvPntcIlBhcnQgQiDigJQgc3RhdGVkLCB1bmV4ZXJjaXNlZCB1bnRpbCDCpzUgY2xlYXJzXCJ9PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJHLUROLUIxIG1vdW50IGlkL21vZGUvcnVsZXMgcHJvdmVuYW5jZSDCtyBCMiBlZGl0YWJpbGl0eSBkZXJpdmF0aW9uIGFnYWluc3QgdGhlXFxuXCJ9PF9jb21wb25lbnRzLmVtPntcImVzdGFibGlzaGVkXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgc2VtYW50aWNzIMK3IEIzIHBhdGgtbm90YXRpb24gbm9ybWFsaXphdGlvbiB3aXRoIHNlZ21lbnQgYm91bmRhcmllcyDCtyBCNFxcbmRlbGVnYXRpb24gc2hhcGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJhbmQgdmFsdWUgcHJvdmVuYW5jZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDCtyBCNSBib3RoIHJlZnVzYWwgY2hhbm5lbHMgaW5jbC4gdGhlXFxucmVzdWx0LWNhcnJpZWQgY2FzZSwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibm8tc3VjaC10YXNrXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhbmQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widGltZW91dFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgwrcgQjYgYWZmb3JkYW5jZSBhYnNlbnQgdW5sZXNzIHdyaXRhYmxlXFxuwrcgQjcgdHJhdmVyc2FsLXNoYXBlZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJtYW5pZmVzdC53b3Jrc2hlZXRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBuZXZlciByZWFjaGVzIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNhcEZpbGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIMK3IEI4IGhvc3QtbGVzcyBib290XFxuYWZ0ZXIgdGhlIGxhenkgaW1wb3J0IMK3IEI5IHRoZSBzdGFsZS1yZW5kZXIgYWZmb3JkYW5jZSDCtyBCMTAgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW52b2tlc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZGVjbGFyZWQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJhbmRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCJcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJ0YXNrOmludm9rZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZXN0YWJsaXNoZWQuIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiTm8gUGFydCBCIGdhdGUgbWF5IGJlIGhvc3QtZnJlZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBmb3IgUDHigJNQNDogdGhvc2UgYXJlXFxucXVlc3Rpb25zIGFib3V0IHRoZSBob3N0LCBhbmQgYW4gaW5qZWN0ZWQgcG9ydCBjYW5ub3QgZmFsc2lmeSB0aGVtIChETi1SMTcpLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaHIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtOFwiIGRhdGEtc2x1Zz1cIjgtbG9hZC1iZWFyaW5nLWFzc3VtcHRpb25zLWNvZGUtYW5jaG9ycy1yZXF1aXJlZFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLThcIiAvPntcIjguIExvYWQtYmVhcmluZyBhc3N1bXB0aW9ucyAmIGNvZGUgYW5jaG9ycyAgXCJ9PF9jb21wb25lbnRzLmVtPntcIihyZXF1aXJlZClcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwiZGVwZW5kcy1vbi10b2RheS12ZXJpZmllZC1hZ2FpbnN0LXRoaXMtcmVwb3MtY29kZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiZGVwZW5kcy1vbi10b2RheS12ZXJpZmllZC1hZ2FpbnN0LXRoaXMtcmVwb3MtY29kZVwiIC8+e1wiRGVwZW5kcy1vbi10b2RheSAodmVyaWZpZWQgYWdhaW5zdCB0aGlzIHJlcG8ncyBjb2RlKVwifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnRhYmxlPjxfY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRoPntcIkFzc3VtcHRpb25cIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aD57XCJBbmNob3IgKHJlcG8tcmVsYXRpdmUgZmlsZSlcIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aD57XCJUb2tlbiAoZ3JlcC1zdGFibGUpXCJ9PC9fY29tcG9uZW50cy50aD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGhlYWQ+PF9jb21wb25lbnRzLnRib2R5PjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiVGhlIGNhdGFsb2cgaXMgYSBjbG9zZWQgdHlwZWQgc2NoZW1hIGxpc3Qgd2l0aCB2YXJpYW50cyBhbmQgY2hpbGQgcnVsZXNcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJzcmMvcmVwb3J0L2NhdGFsb2cudHNcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiY29uc3QgQ09NUE9ORU5UUzogQ29tcG9uZW50U2NoZW1hW11cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiVGhlIHdpZGdldCBzZXQgaXMgZW51bWVyYXRlZFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcInNyYy9yZXBvcnQvY2F0YWxvZy50c1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJleHBvcnQgY29uc3QgV0lER0VUU1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJWYWxpZGF0aW9uIGVuZm9yY2VzIHZhcmlhbnQgZGlzY3JpbWluYXRvcnMsIGNoaWxkIHJ1bGVzIGFuZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJsaXRlcmFsLWFycmF5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBzaGFwZXMg4oCUIHdoYXQgwqcxLjEncyBzbmlwcGV0cyBtdXN0IHNhdGlzZnlcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJzcmMvcmVwb3J0L3ZhbGlkYXRlLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcImNoaWxkUnVsZVwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJUZW1wbGF0ZXMgcGFyc2UgdG8gdGhlIG5vZGUgbW9kZWwgdGhlIGdhdGUgdmFsaWRhdGVzIHRocm91Z2hcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJzcmMvcmVwb3J0L3BhcnNlL21keC50c1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJleHBvcnQgZnVuY3Rpb24gcGFyc2VUZW1wbGF0ZVwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJUaGUgd29ya2Jvb2sgcGFuZWwgaXMgdGhlIGFsd2F5cy1wcmVzZW50IGNvbXB1dGVkIHN1cmZhY2UgdGhlIHNlY3Rpb24gam9pbnNcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJzcmMvYXBwL1dvcmtib29rUGFuZWwudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcIldvcmtib29rUGFuZWxCb2R5XCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkRvY3VtZW50IGZpbGVzIGNhcnJ5IGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJkb2N1bWVudC1yZWxhdGl2ZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBwYXRoIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJ3b3Jrc2hlZXRzL3guc2hlZXQuanNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSDigJQgUGFydCBCJ3MgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicmVsUGF0aFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJzcmMvZG9jdW1lbnQvbG9hZGVyLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcInBhdGg6IHJlbFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJtYW5pZmVzdC53b3Jrc2hlZXRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpcyB2YWxpZGF0ZWQgb25seSBmb3Igbm9uLWVtcHR5IHN0cmluZ3MgKHdoeSDCpzQuMyBleGlzdHMpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2RvY3VtZW50L21hbmlmZXN0LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcIlxcXCJ3b3Jrc2hlZXRzXFxcIiBtdXN0IGJlIGFuIGFycmF5XCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIlRoZSBkaXNwYXRjaCBrZWVwcyBvbmx5IHRoZSBtb3VudCdzIHBhdGggdG9kYXkgKFBhcnQgQidzIFAxL1AyIGNoYW5nZSBpdClcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJzcmMvYXBwL2Rpc3BhdGNoLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcIm1hcmtlZFswXS5wYXRoXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIlRoZSBTREsncyB0YXNrIG1vZHVsZSByZWdpc3RlcnMgYSBsaXN0ZW5lciBhdCBpbXBvcnQgKHdoeSDCpzQuMSBpcyBsYXp5KVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcInNyYy9ob29rcy91c2VNb3VudHMudHNcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wicmVnaXN0ZXJzIGEgaG9zdCBsaXN0ZW5lciBhdCBtb2R1bGUgbG9hZFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50Ym9keT48L19jb21wb25lbnRzLnRhYmxlPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5lbT57XCIoU0RLIGNvbnRyYWN0cyBhcmUgY2l0ZWQgYnkgdGhlaXIgcHVibGlzaGVkIGRvY3VtZW50YXRpb24g4oCUIFwifTxfY29tcG9uZW50cy5jb2RlPntcImxsbXMudHh0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAvIFwifTxfY29tcG9uZW50cy5jb2RlPntcImFwaS5qc29uXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhdFxcbnRoZSB2ZXJzaW9uIHRoaXMgcmVwbyBkZXBlbmRzIG9uIOKAlCBub3QgYnkgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibm9kZV9tb2R1bGVzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBwYXRoczogdGhvc2UgYXJlIGdpdGlnbm9yZWQsXFxuZmxvYXQgd2l0aCB0aGUgZGVwZW5kZW5jeSByYW5nZSwgYW5kIGFyZSBhYnNlbnQgb24gYSBmcmVzaCBjbG9uZS4gVGhlIGRyYWZ0IGFuY2hvcmVkXFxudGhyZWUgcm93cyB0aGVyZSBhbmQgb25lIGF0IGEgc2libGluZyByZXBvOyBib3RoIGFyZSBvdXRzaWRlIHRoaXMgdGFibGUncyBjb250cmFjdC4pXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwibXVzdC1lc3RhYmxpc2gtbmV3LWludmFyaWFudHMtdGhlLWltcGxlbWVudGF0aW9uLWNyZWF0ZXNcIj48SGVhZGluZ0FuY2hvciBpZD1cIm11c3QtZXN0YWJsaXNoLW5ldy1pbnZhcmlhbnRzLXRoZS1pbXBsZW1lbnRhdGlvbi1jcmVhdGVzXCIgLz57XCJNdXN0LWVzdGFibGlzaCAobmV3IGludmFyaWFudHMgdGhlIGltcGxlbWVudGF0aW9uIGNyZWF0ZXMpXCJ9PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMudGFibGU+PF9jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGg+e1wiTmV3IGludmFyaWFudFwifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIlByb3ZlbiBieVwifTwvX2NvbXBvbmVudHMudGg+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50Ym9keT48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIlRoZSB2b2NhYnVsYXJ5IHNlY3Rpb24gaXMgZGVyaXZlZCwgY29tcGxldGUsIGFuZCBmaWx0ZXJhYmxlXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiRy1ETi1BMSwgRy1ETi1BMiwgRy1ETi1BNFwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkV2ZXJ5IHNuaXBwZXQgdmFsaWRhdGVzXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiRy1ETi1BM1wifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIk5vdGhpbmcgaW4gdGhlIHNlY3Rpb24gdGhyb3dzIHdpdGhvdXQgYSBob3N0XCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiRy1ETi1BNVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIlBhcnQgQidzIFAx4oCTUDQgaG9zdCBjb250cmFjdFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiTm90IGVzdGFibGlzaGVkIOKAlCDCpzU7IFIzLTQ0N1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRib2R5PjwvX2NvbXBvbmVudHMudGFibGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmhyIC8+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTlcIiBkYXRhLXNsdWc9XCI5LWRlY2lzaW9ucy1yZWplY3RlZC1hbHRlcm5hdGl2ZXMtbm9ybWF0aXZlLWRvbnQtcmVsaXRpZ2F0ZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTlcIiAvPntcIjkuIERlY2lzaW9ucyAmIHJlamVjdGVkIGFsdGVybmF0aXZlcyAgXCJ9PF9jb21wb25lbnRzLmVtPntcIihub3JtYXRpdmUg4oCUIGRvbid0IHJlbGl0aWdhdGUpXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgdm9jYWJ1bGFyeSBpcyBwYW5lbCBjaHJvbWUsIG5vdCBhIGNhdGFsb2cgY29tcG9uZW50IChETi1SMTQpLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBBIGNhdGFsb2dcXG5hZGRpdGlvbiBpcyBwZXJtYW5lbnQsIGlzIHZlcnNpb25lZCBieSB0aGUgXCJ9PF9jb21wb25lbnRzLmVtPntcImRvY3VtZW50J3NcIn08L19jb21wb25lbnRzLmVtPntcIiBjb21wYXQgcmFuZ2UsIHdvdWxkIHJlbmRlclxcbmNvbnRlbnQgdGhhdCBpcyBhIGZ1bmN0aW9uIG9mIHRoZSBcIn08X2NvbXBvbmVudHMuZW0+e1wicmVhZGluZyBhcHBcIn08L19jb21wb25lbnRzLmVtPntcIiByYXRoZXIgdGhhbiB0aGUgZG9jdW1lbnQgKHRoZSBjYXRhbG9nXFxuaXMgYSBmb3JrIHBvaW50KSwgYW5kIHdvdWxkIGVudW1lcmF0ZSBpdHNlbGYuIFBhbmVsIGNocm9tZSBoYXMgbm9uZSBvZiB0aG9zZVxcbnByb3BlcnRpZXMgYW5kIGlzIFwifTxfY29tcG9uZW50cy5lbT57XCJtb3JlXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgZGlzY292ZXJhYmxlLCBzaW5jZSBubyBhdXRob3IgbXVzdCBwbGFjZSBhIHRhZy4gXCJ9PF9jb21wb25lbnRzLmVtPntcIlJlamVjdGVkOlwifTwvX2NvbXBvbmVudHMuZW0+e1wiXFxudGhlIGRyYWZ0J3MgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiPENhdGFsb2dJbmRleCAvPlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgY29tcG9uZW50IOKAlCBhbmQgd2l0aCBpdCB0aGUgZHJhZnQncyBjbGFpbSB0aGF0IGl0c1xcbmF1dGhvcidzLXZpZXctb25seSBnYXRpbmcgd2FzIFxcXCJzdHJ1Y3R1cmFsXFxcIiwgd2hpY2ggaXQgd2FzIG5vdDogdW5saWtlIGl0cyBzaWJsaW5ncyBpdFxcbmRvZXMgbm90IHRha2UgaXRzIGRhdGEgZnJvbSB0aGUgcmVmbGVjdGlvbiBwb3J0LCBzbyB3aXRoaG9sZGluZyB0aGUgcG9ydCB0b29rIG5vdGhpbmdcXG5hd2F5IChETi1SOSkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJTaGlwIHRoZSB2b2NhYnVsYXJ5OyBibG9jayB0aGUgZWRpdCBkb29yIChETi1SMi9SNC9SNi9SMTIpLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBGb3VyIGhvc3QtY29udHJhY3RcXG5xdWVzdGlvbnMgYW5kIG9uZSByZWFjaGFiaWxpdHkgcXVlc3Rpb24sIG5vbmUgYW5zd2VyYWJsZSBmcm9tIHRoaXMgcmVwbywgZWFjaCBmYXRhbCBpZlxcbmd1ZXNzZWQuIFwifTxfY29tcG9uZW50cy5lbT57XCJSZWplY3RlZDpcIn08L19jb21wb25lbnRzLmVtPntcIiBzaGlwcGluZyBQYXJ0IEIgb24gcGxhdXNpYmxlIGRlZmF1bHRzIOKAlCB0aGUgZHJhZnQncyBcXFwiYWJzZW50XFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibW9kZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oeSIHdyaXRhYmxlXFxcIiBpbnZlcnRlZCB0aGUgdmVyeSBndWlkYW5jZSBpdCBjaXRlZCwgYW5kIHdhcyB0aGUgb25seSBicmFuY2ggdGhhdFxcbndvdWxkIGhhdmUgcnVuLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiU25pcHBldHMgYXJlIGdhdGVkIG9uIHZhbGlkYXRpbmcsIG5vdCBoZWRnZWQgYXMgXFxcImEgc3RhcnRpbmcgcG9pbnRcXFwiIChETi1SOCkuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFNldmVuXFxub2YgbmluZXRlZW4gZW50cmllcyBjb3VsZCBub3QgcHJvZHVjZSBhIHZhbGlkIHNuaXBwZXQgdW5kZXIgdGhlIGRyYWZ0J3MgcmVjaXBlLiBBIGNvcHlcXG5idXR0b24gdGhhdCBhbHdheXMgeWllbGRzIHJlZCBkaWFnbm9zdGljcyBpcyB3b3JzZSB0aGFuIG5vIGJ1dHRvbi4gXCJ9PF9jb21wb25lbnRzLmVtPntcIlJlamVjdGVkOlwifTwvX2NvbXBvbmVudHMuZW0+e1wiIHRoZVxcblxcXCJub3QgYSBwcm9taXNlIG9mIHZhbGlkaXR5XFxcIiBoZWRnZSBhcyBjb3ZlciBmb3Iga25vd24taW52YWxpZCBvdXRwdXQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJEYXRhIHNlY3Rpb24gcmVhZC1vbmx5OyB0aGUgZmlsZSBsaW5rIGlzIHRoZSBlZGl0IHBhdGhcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXCJ9PF9jb21wb25lbnRzLmVtPntcIihvd25lciBsZWFuLCByZWNvcmRlZCBhc1xcbmRlZmF1bHQpXCJ9PC9fY29tcG9uZW50cy5lbT57XCIuIFJvdyBlZGl0aW5nIHdhbnRzIFwifTxfY29tcG9uZW50cy5jb2RlPntcImVkaXQtdGFibGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGF0IHRoZSBwbGF0Zm9ybSAowqc2KS4gXCJ9PF9jb21wb25lbnRzLmVtPntcIlJlamVjdGVkIGZvciB2MTpcIn08L19jb21wb25lbnRzLmVtPntcIiBhblxcbmluLWFwcCBmaXh0dXJlIGdyaWQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJDYXRhbG9nICsgY29weWFibGUgc25pcHBldCwgbm90IGNsaWNrLXRvLWluc2VydFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuZW0+e1wiKG93bmVyIGxlYW4sIHJlY29yZGVkIGFzXFxuZGVmYXVsdClcIn08L19jb21wb25lbnRzLmVtPntcIi4gXCJ9PF9jb21wb25lbnRzLmVtPntcIlJlamVjdGVkIGZvciB2MTpcIn08L19jb21wb25lbnRzLmVtPntcIiBpbnNlcnQtb24tY2xpY2suXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgdm9jYWJ1bGFyeSBsaXZlcyBpbiB0aGUgd29ya2Jvb2sgcGFuZWwsIG5vdCB0aGUgaW5zcGVjdG9yXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5lbT57XCIodGhlIHRoaXJkIG9wZW5cXG5xdWVzdGlvbiwgZGVjaWRlZCBhcyB0aGUgcmV2ZXJzaWJsZSBkZWZhdWx0KVwifTwvX2NvbXBvbmVudHMuZW0+e1wiLiBJdCBpcyByZWZlcmVuY2UgbWF0ZXJpYWwgcmVhZCB3aGlsZVxcbmF1dGhvcmluZywgbm90IHBlci12YWx1ZSBjb250ZXh0LiBcIn08X2NvbXBvbmVudHMuZW0+e1wiUmVqZWN0ZWQgZm9yIHYxOlwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGEgY29udGV4dHVhbCBcXFwidGhpcyB2YWx1ZSBjb3VsZCBiZVxcbmEgc2xpZGVyXFxcIiBoaW50IOKAlCBhIGdvb2QgaWRlYSBuZWVkaW5nIGEgcnVsZSBmb3Igd2hlbiBpdCBoZWxwcyByYXRoZXIgdGhhbiBpbnRydWRlc1xcbihRNCkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJBYnNlbnQgYWZmb3JkYW5jZSwgbm90IGRpc2FibGVkIGFmZm9yZGFuY2VcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgd2hlbiBub3Qgd3JpdGFibGUgKGVkaXRvci1maXJzdCDCpzdcXG5ydWxlIDMpLiBcIn08X2NvbXBvbmVudHMuZW0+e1wiUmVqZWN0ZWQ6XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgZ3JleWVkIGNvbnRyb2xzIHdpdGggdG9vbHRpcHMuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz48X2NvbXBvbmVudHMuY29kZT57XCJSZXZpZXdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKGkiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJXb3JrYm9va1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGJvdGggbGFiZWwgc3RyaW5ncy5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXCJ9PF9jb21wb25lbnRzLmVtPntcIlJlamVjdGVkOlwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGEgbmFtZSBkZXNjcmliaW5nIG9ubHkgdGhlXFxucGFuZWwncyBmaXJzdCBmZWF0dXJlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaHIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtMTBcIiBkYXRhLXNsdWc9XCIxMC1hZHZlcnNhcmlhbC1yZXZpZXctcmVjb3JkXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtMTBcIiAvPntcIjEwLiBBZHZlcnNhcmlhbCByZXZpZXcgIFwifTxfY29tcG9uZW50cy5lbT57XCIocmVjb3JkKVwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlBhc3MgMSAoMjAyNi0wOC0yOCwgZnJlc2gtYWdlbnQpLCBETi1SMeKApkROLVIxOCDigJQgZm9sZGVkOyBmb3VyIEJMT0NLRVJzIGFyZSB3aHkgdGhpc1xcbmRvY3VtZW50IGlzIHNwbGl0IHJhdGhlciB0aGFuIHJldmlzZWQ6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJETi1SMSBbQkxPQ0tFUl1cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicmVhZC1vbmx5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBtYXBwZWQgYXMgYW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW52b2tlVGFza1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcmVqZWN0aW9uIGNvZGU7IGl0IGlzIG5vdFxcbm9uZSwgYW5kIHRoZSBkcmFmdCdzIGNhbGwgZGlzY2FyZGVkIGl0cyByZXN1bHQg4oaSIMKnNC4yIHJld3JpdHRlbiBmb3IgYm90aCBjaGFubmVscztcXG50aGUgZXhhY3QgY29udHJhY3QgYmVjb21lcyBwcmVjb25kaXRpb24gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJQM1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkROLVIyIFtCTE9DS0VSXVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcXFwiYWJzZW50IFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1vZGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKHkiB3cml0YWJsZVxcXCIgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJpbnZlcnRlZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBSLUVGRS0xJ3MgcG9zaXRpdmUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicndcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxuY2hlY2sgd2hpbGUgY2l0aW5nIGl0IGFzIGF1dGhvcml0eSwgYW5kIHdhcyB0aGUgb25seSBicmFuY2ggdGhhdCBmaXJlcyBvbiBhIHJlcG8tYmFja2VkXFxuY29udGVudCBtb3VudCAodGhpcyByZXBvJ3Mgb3duIGZpeHR1cmVzIHNheSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyb1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpIOKGkiBwcmVjb25kaXRpb24gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJQMlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkROLVIzIFtCTE9DS0VSXVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJNb3VudFJ1bGUuc3VidHJlZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaXMgc2xhc2gtcm9vdGVkIGFuZCBcXFwiYmFja2VuZC1uYXR1cmFsXFxcIjtcXG5kb2N1bWVudCBwYXRocyBhcmUgbm90LCBzbyB0aGUgZmFpbC1jbG9zZWQgcHJlZml4IG1hdGNoIGRpc2FibGVkIGVkaXRpbmcgd2hlcmV2ZXIgcnVsZXNcXG53ZXJlIHJlcG9ydGVkIOKAlCBhbmQgdGhlIGRyYWZ0J3MgZ2F0ZSBlbmNvZGVkIHRoZSBtaXNtYXRjaCDihpIgZm9sZGVkIGludG8gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJQMlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkROLVI0IFtCTE9DS0VSXVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJTYW5kYm94TW91bnQuaWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChiYXJlIHNwYWNlSWQpIGlzIG5vdCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjYXBGaWxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIidzIHVuaXZlcnNhbFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcInNjaGVtZTpsb2NhdG9yXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJtb3VudElkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDihpIgcHJlY29uZGl0aW9uIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiUDFcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJETi1SNSBbTUFKT1JdXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGEgc3RhdGljIFNESyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ0YXNrc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaW1wb3J0IHRocm93cyBhdCBtb2R1bGUgbG9hZCAodGhlIGhhemFyZCB0aGlzXFxucmVwbyBhbHJlYWR5IGRvY3VtZW50cyBpbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ1c2VNb3VudHMudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSDihpIgwqc0LjEgbGF6eSBpbXBvcnQ7IEctRE4tQTUgYXNzZXJ0cyBpdCBmb3JcXG5QYXJ0IEEgdG9vLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRE4tUjYgW01BSk9SXVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJpbnZva2VzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpcyBoYWxmIHRoZSDCpzUuOCBydWxlOyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ0YXNrOmludm9rZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaXMgaG9zdC1zaWRlIGFuZFxcbnVuZXN0YWJsaXNoZWQsIGFuZCB0aGUgZHJhZnQncyBtYW5pZmVzdCBnYXRlIHRlc3RlZCBvbmx5IHRoZSBoYWxmIGEgdW5pdCB0ZXN0IGNhbiBzZWVcXG7ihpIgcHJlY29uZGl0aW9uIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiUDRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJETi1SNyBbTUFKT1JdXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5jb2RlPntcInJlbFBhdGhcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGJ1aWx0IGZyb20gdW52YWxpZGF0ZWQgYXV0aG9yLWNvbnRyb2xsZWQgbWFuaWZlc3QgY29udGVudFxcbuKGkiDCpzQuMyB2YWxpZGF0aW9uIGJlZm9yZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjYXBGaWxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjsgdGhlIFxcXCJ3aWRlbnMgbm8gYXV0aG9yaXR5XFxcIiBjbGFpbSBxdWFsaWZpZWQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJETi1SOCBbTUFKT1JdXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHRoZSBzbmlwcGV0IHJlY2lwZSBjb3VsZCBub3QgZW1pdCBhIHZhbGlkIHNuaXBwZXQgZm9yIDcvMTkgZW50cmllc1xcbuKGkiDCpzEuMSdzIHBlci1zaGFwZSBydWxlczsgRy1ETi1BMyBnYXRlcyBvbiB6ZXJvIGVycm9yIGRpYWdub3N0aWNzLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRE4tUjkgW01BSk9SXVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB0aGUgY29tcG9uZW50J3MgYXV0aG9yJ3MtdmlldyBnYXRpbmcgd2FzIGFkdmlzb3J5LCBub3Qgc3RydWN0dXJhbCDihpJcXG5kaXNzb2x2ZWQgd2l0aCBETi1SMTQgKG5vIGNvbXBvbmVudCkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJETi1SMTAgW01BSk9SXVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBhdXRob3Incy12aWV3IHJvd3MgcmVmZXJlbmNlZCBhIFwifTxfY29tcG9uZW50cy5jb2RlPntcImZpbGU6bGluZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYW5jaG9yIHRoYXQgZXhpc3RzIG9ubHlcXG5pbiB0aGUgaW5zcGVjdG9yLCBhbmQgd291bGQgbmVlZCBhbiB1bmJvb2tlZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJSZWZsZWN0aW9uUG9ydFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgd2lkZW5pbmcg4oaSIGRyb3BwZWQgZnJvbVxcblBhcnQgQiB2MTsgYm9va2VkIFE1LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRE4tUjExIFtNQUpPUl1cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXFxcIm5vdGhpbmcgaGFwcGVucyBhZnRlciB0aGUgZWRpdFxcXCIgY29uY2VhbGVkIGEgc3RhbGUtcmVuZGVyIGRlZmVjdFxcbnRoZSBmZWF0dXJlIGludHJvZHVjZXMsIGFuZCBvbWl0dGVkIFJDRCDCpzUuMSdzIGRpc2Nsb3N1cmUtYXQtdGhlLWJ1dHRvbiDihpIgwqc0LjQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJETi1SMTIgW01BSk9SXVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBQYXJ0IEIgcmVuZGVycyBub3RoaW5nIGluIHRoZSBvbmx5IHNoYXBlIHVzZXJzIGNhbiByZWFjaCDihpIgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJQNVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIixcXG5hbmQgUGFydCBBIGlzIHNlcXVlbmNlZCBmaXJzdCBwcmVjaXNlbHkgYmVjYXVzZSBpdCBkb2VzIG5vdC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkROLVIxMyBbTUFKT1JdXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGFuIGF1dGhvcmluZyBkb29yIG9uIHRoZSBjb25zdW1lci12aXNpYmxlIGluc3BlY3RvciB3YXMgbmV2ZXJcXG5kZWNpZGVkIOKGkiBRNjsgwqcyIG5vdyBzcGVjaWZpZXMgYm90aCBsYWJlbCBzdHJpbmdzLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRE4tUjE0IFtNQUpPUl1cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYSBwZXJtYW5lbnQgY2F0YWxvZyBlbnRyeSBkZXNjcmliaW5nIHRoZSBhcHAgcmF0aGVyIHRoYW4gdGhlXFxuZG9jdW1lbnQg4oaSIHBhbmVsIGNocm9tZSAowqcxLCDCpzkpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRE4tUjE1IFtNSU5PUl1cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYW5jaG9ycyBpbnRvIGdpdGlnbm9yZWQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibm9kZV9tb2R1bGVzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgYSBzaWJsaW5nIHJlcG8sIGFuZCBhIHRva2VuXFxudGhhdCBtYXRjaGVkIHdpdGhvdXQgc3VwcG9ydGluZyBpdHMgY2xhaW0g4oaSIMKnOCByZWJ1aWx0LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRE4tUjE2IFtNSU5PUl1cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgwqc1LjggYXR0cmlidXRlZCB0byB0aGUgd3Jvbmcgc3BlYyDihpIgY2l0ZWQgdG8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiVUlfQVNfQVBQU19TUEVDXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkROLVIxNyBbTUlOT1JdXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGdhdGUgaG9sZXMgKHJlc3VsdCBjaGFubmVsLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJuby1zdWNoLXRhc2tcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBob3N0LWxlc3MgYm9vdCwgbm9cXG5ob3N0LWV4ZXJjaXNlZCBnYXRlKSBhbmQgYW4gdW5kZWZpbmVkIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNvbXBvbmVudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGZpbHRlciDihpIgwqc3LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRE4tUjE4IFtNSU5PUl1cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgc3BlYy1mb3JtIGRyaWZ0IChubyByZXZpZXctcmVjb3JkIHNsb3QsIG1pcy10YWdnZWQgc2VjdGlvbnMsXFxuXFxcInZlcmlmaWVkIGFnYWluc3QgY29kZVxcXCIgb3ZlciB1bnZlcmlmaWVkIHJvd3MpIOKGkiBzdHJ1Y3R1cmUgYW5kIHRhZ3MgY29ycmVjdGVkLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaHIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtMTFcIiBkYXRhLXNsdWc9XCIxMS1vcGVuLXF1ZXN0aW9uc1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTExXCIgLz57XCIxMS4gT3BlbiBxdWVzdGlvbnNcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJRMVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZWRpdC10YWJsZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCI6IHdobyBvd25zIHRoZSBwbGF0Zm9ybSBzcGVjLCBhbmQgZG9lcyBpdCBzdWJzdW1lIHRoZSBmaXh0dXJlXFxuY2FzZSBvciB3YW50IGEgUmVja29uZXItc2lkZSBzaGFwZSBmaXJzdD8gXCJ9PF9jb21wb25lbnRzLmVtPntcIihBbnN3ZXJlZCAyMDI2LTA4LTI5IG9uIHRoZSBmaXJzdCBoYWxmIOKAlFxcbnRoZSBzcGVjIGlzIHdyaXR0ZW4gYW5kIGxpdmVzIGluIHRoZSBkb2NzIHJlcG8sIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkVESVRfVEFCTEVfVEFTS19TUEVDLm1keFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuIEl0XFxuc3Vic3VtZXMgdGhlIGZpeHR1cmUgY2FzZSBhbmQgbmVlZHMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJub1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBSZWNrb25lci1zaWRlIHNoYXBlIGZpcnN0OyB3aGF0IGl0IG5lZWRzXFxuZnJvbSBSZWNrb25lciBpcyB0aGUgRDcgZnMgd2F0Y2ggYW5kIGEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widGFzazppbnZva2VcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGJpbmRpbmcsIGJvdGggYm9va2VkIHRoZXJlLilcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUTJcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIFRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJlZGl0LWZpbGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHBvc2l0aW9uIGhpbnQgKG9wZW4tYXQtbGluZSk6IFNESyBwYXJhbSB2cy4gdGFzay1jb250cmFjdFxcbnZlcnNpb24gYnVtcC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlEzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBBZnRlciBhbiBlZGl0IGxhbmRzOiBhbiBleHBsaWNpdCByZWxvYWQgYWZmb3JkYW5jZSwgb3IgYSBjaGFuZ2Utd2F0Y2ggb24gdGhlXFxubW91bnQ/ICjCpzQuNCByZXF1aXJlcyBvbmUgb2YgdGhlbSBiZWZvcmUgUGFydCBCIHNoaXBzLilcIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlE0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBDb250ZXh0dWFsIHZvY2FidWxhcnkgaGludHMgaW4gdGhlIGluc3BlY3RvciDigJQgd29ydGggaXQsIG9yIG5vaXNlP1wifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUTVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIFdpZGVuaW5nIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlJlZmxlY3Rpb25Qb3J0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB3aXRoIHdvcmtzaGVldOKGknBhdGggc28gdGhlIGF1dGhvcidzLXZpZXcgaW5kZXhlc1xcbmNhbiBjYXJyeSBhbmNob3JzIGFuZCAobGF0ZXIpIGVkaXQgZG9vcnMg4oCUIHdvcnRoIHRoZSBhbGxvd2xpc3QgYWRkaXRpb24/XCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJRNlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgRG9lcyB0aGUgY29uc3VtZXItdmlzaWJsZSBpbnNwZWN0b3IgY2FycnkgdGhlIGVkaXQgYWZmb3JkYW5jZSBhdCBhbGw/XCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJRN1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgQSB0ZW1wbGF0ZS1maWxlIGVkaXQgcm93LCB3aXRob3V0IHdoaWNoIFxcXCJjb3B5IHRoZSBzbmlwcGV0LCBvcGVuIHRoZSB0ZW1wbGF0ZVxcXCJcXG5oYXMgbm8gZG9vci5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+PC8+O1xufVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTURYQ29udGVudChwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHt3cmFwcGVyOiBNRFhMYXlvdXR9ID0ge1xuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfTtcbiAgcmV0dXJuIE1EWExheW91dCA/IDxNRFhMYXlvdXQgey4uLnByb3BzfT48X2NyZWF0ZU1keENvbnRlbnQgey4uLnByb3BzfSAvPjwvTURYTGF5b3V0PiA6IF9jcmVhdGVNZHhDb250ZW50KHByb3BzKTtcbn1cbmZ1bmN0aW9uIF9taXNzaW5nTWR4UmVmZXJlbmNlKGlkLCBjb21wb25lbnQsIHBsYWNlKSB7XG4gIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIFwiICsgKGNvbXBvbmVudCA/IFwiY29tcG9uZW50XCIgOiBcIm9iamVjdFwiKSArIFwiIGBcIiArIGlkICsgXCJgIHRvIGJlIGRlZmluZWQ6IHlvdSBsaWtlbHkgZm9yZ290IHRvIGltcG9ydCwgcGFzcywgb3IgcHJvdmlkZSBpdC5cIiArIChwbGFjZSA/IFwiXFxuSXTigJlzIHJlZmVyZW5jZWQgaW4geW91ciBjb2RlIGF0IGBcIiArIHBsYWNlICsgXCJgIGluIGAvYXBwL2RvY3Mvc3BlY3MvRE9DVU1FTlRfTkFWSUdBVE9SX1NQRUMubWRgXCIgOiBcIlwiKSk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUVBLElBQUFBLFlBQUEsR0FBQUMsT0FBQTtBQUF3RixJQUFBQyxXQUFBLEdBQUFELE9BQUE7QUFGeEY7QUFDQTs7QUFFQSxTQUFTRSxpQkFBaUJBLENBQUNDLEtBQUssRUFBRTtFQUNoQyxNQUFNQyxXQUFXLEdBQUc7TUFDbEJDLFVBQVUsRUFBRSxZQUFZO01BQ3hCQyxJQUFJLEVBQUUsTUFBTTtNQUNaQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxDQUFDLEVBQUUsR0FBRztNQUNOQyxHQUFHLEVBQUUsS0FBSztNQUNWQyxNQUFNLEVBQUUsUUFBUTtNQUNoQkMsS0FBSyxFQUFFLE9BQU87TUFDZEMsS0FBSyxFQUFFLE9BQU87TUFDZEMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsS0FBSyxFQUFFLE9BQU87TUFDZEMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUixHQUFHLElBQUFDLDZCQUFrQixFQUFDLENBQUM7TUFDdkIsR0FBR3JCLEtBQUssQ0FBQ3NCO0lBQ1gsQ0FBQztJQUFFO01BQUNDO0lBQWEsQ0FBQyxHQUFHdEIsV0FBVztFQUNoQyxJQUFJLENBQUNzQixhQUFhLEVBQUVDLG9CQUFvQixDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUM7RUFDL0Qsb0JBQU8sSUFBQTFCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQTNCLFdBQUEsQ0FBQTRCLFFBQUE7SUFBQUMsUUFBQSxnQkFBRSxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDSSxFQUFFO01BQUN1QixFQUFFLEVBQUMscUZBQXFGO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBcUYsQ0FBRSxDQUFDLEVBQUMsd0ZBQXdGO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVMsQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFPLENBQXFCLENBQUMsRUFBQyxpREFBaUQsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUEwRCxDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxHQUFFLDRDQUE0QyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFTLENBQWlCLENBQUMsRUFBQyx5RkFBeUY7TUFBQSxDQUFxQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVUsQ0FBcUIsQ0FBQyxFQUFDLGFBQWE7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNDLFVBQVU7TUFBQXlCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztRQUFBZ0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsR0FBRSw0REFBNEQsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1lBQUF3QixRQUFBLEVBQUU7VUFBMEMsQ0FBbUIsQ0FBQztRQUFBLENBQW9CLENBQUMsRUFBQyx3RUFBd0U7TUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQXlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsVUFBVTtNQUFBeUIsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDVSxDQUFDO1FBQUFnQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWMsQ0FBcUIsQ0FBQyxFQUFDLGtCQUFrQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUEyQixDQUFtQixDQUFDLEVBQUMseUNBQXlDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBUyxDQUFxQixDQUFDLEVBQUMsZ0NBQWdDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEdBQUUsV0FBVyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7WUFBQXdCLFFBQUEsRUFBRTtVQUFJLENBQW1CLENBQUMsRUFBQyxRQUFRO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLGtFQUFrRSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFpQixDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQU0sQ0FBcUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBUyxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQyxpQkFBaUIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBSyxDQUFpQixDQUFDLEVBQUMsd0RBQXdELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQyxFQUFDLGdCQUFnQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUE0QixDQUFtQixDQUFDLEVBQUMsMkVBQTJFLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQW1CLENBQW1CLENBQUMsRUFBQyx1SEFBdUgsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFLLENBQXFCLENBQUMsRUFBQyxZQUFZLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQW1CLENBQW1CLENBQUMsRUFBQyw2QkFBNkI7TUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQXlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ08sRUFBRSxJQUFFLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQVYsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDSyxFQUFFO01BQUNzQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUsaURBQWlEO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQyw0Q0FBNEMsZUFBQyxJQUFBOUIsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1FBQUF1QixRQUFBLEVBQUU7TUFBYSxDQUFpQixDQUFDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLEVBQUU7SUFBc0YsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUyxFQUFFO01BQUFpQixRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBd0MsQ0FBcUIsQ0FBQyxFQUFDLCtKQUErSjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFrRCxDQUFxQixDQUFDLEVBQUMsNkJBQTZCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLHVGQUF1RixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyw0RUFBNEU7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLDBDQUEwQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQXFGLENBQXFCLENBQUMsRUFBQyxTQUFTO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDbUIsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBOEMsQ0FBcUIsQ0FBQyxFQUFDLDJEQUEyRCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFtQixDQUFpQixDQUFDLEVBQUMsOEtBQThLLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBYyxDQUFxQixDQUFDLEVBQUMsa0hBQWtIO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQW1GLENBQXFCLENBQUMsRUFBQywrREFBK0QsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBUyxDQUFtQixDQUFDLEVBQUMsNENBQTRDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQU0sQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBTyxDQUFtQixDQUFDLEVBQUMsMEJBQTBCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLDBDQUEwQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyxxS0FBcUssZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFPLENBQXFCLENBQUMsRUFBQyxRQUFRO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNVLENBQUM7TUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBaUIsQ0FBcUIsQ0FBQyxFQUFDLHdDQUF3QyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFZLENBQW1CLENBQUMsRUFBQyxnRUFBZ0UsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1FBQUF1QixRQUFBLEVBQUU7TUFBUyxDQUFpQixDQUFDLEVBQUMsR0FBRztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ08sRUFBRSxJQUFFLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQVYsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDSSxFQUFFO01BQUN1QixFQUFFLEVBQUMsOERBQThEO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBOEQsQ0FBRSxDQUFDLEVBQUMscUNBQXFDLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQWtDLENBQWlCLENBQUM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNLLEVBQUU7TUFBQ3NCLEVBQUUsRUFBQyxPQUFPO01BQUMsYUFBVSxvQ0FBb0M7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLDZCQUE2QixlQUFDLElBQUE5QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUFhLENBQWlCLENBQUM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNVLENBQUM7TUFBQWdCLFFBQUEsR0FBRSw2QkFBNkIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFZLENBQXFCLENBQUMsRUFBQywwS0FBMEssZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUF3QixDQUFxQixDQUFDLEVBQUMsR0FBRztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ21CLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWtELENBQXFCLENBQUMsRUFBQyw0UEFBNFAsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBWSxDQUFtQixDQUFDLEVBQUMsbUNBQW1DO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxHQUFFLGVBQWUsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1lBQUF3QixRQUFBLEVBQUU7VUFBWSxDQUFtQixDQUFDLEVBQUMscUJBQXFCO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLDBHQUEwRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFrQixDQUFxQixDQUFDLEVBQUMsOENBQThDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLHlHQUF5RztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFVLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQTRDLENBQW1CLENBQUMsRUFBQyw0QkFBNEIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBUyxDQUFtQixDQUFDLEVBQUMsb0pBQW9KO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNNLEVBQUU7TUFBQ3FCLEVBQUUsRUFBQyxTQUFTO01BQUMsYUFBVSxxREFBcUQ7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFTLENBQUUsQ0FBQyxFQUFDLGdEQUFnRCxlQUFDLElBQUE5QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUFhLENBQWlCLENBQUM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNVLENBQUM7TUFBQWdCLFFBQUEsR0FBRSxnSkFBZ0osZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFtRCxDQUFxQixDQUFDLEVBQUMsK0RBQStEO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDYSxLQUFLO01BQUFhLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2lCLEtBQUs7UUFBQVMsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQWUsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQU0sQ0FBaUIsQ0FBQztRQUFBLENBQWdCO01BQUMsQ0FBbUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2MsS0FBSztRQUFBWSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEdBQUUsWUFBWSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFPLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQUssQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7VUFBQSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsR0FBRSxXQUFXLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBZSxDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFNLENBQW1CLENBQUMsRUFBQyx1QkFBdUIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFxQixDQUFxQixDQUFDLEVBQUMseUNBQXlDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQVksQ0FBbUIsQ0FBQyxFQUFDLGlDQUFpQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFNLENBQW1CLENBQUMsRUFBQyxhQUFhO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUEyQixDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFRLENBQW1CLENBQUMsRUFBQyxHQUFHO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEdBQUUsY0FBYyxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNZLE1BQU07Y0FBQWMsUUFBQSxHQUFFLGdCQUFnQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Z0JBQUF3QixRQUFBLEVBQUU7Y0FBTyxDQUFtQixDQUFDLEVBQUMsUUFBUTtZQUFBLENBQXFCLENBQUMsRUFBQywwQ0FBMEM7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQXNCLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQVEsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7VUFBQSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUF3QyxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQVcsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBVyxDQUFtQixDQUFDO1VBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEdBQUUsT0FBTyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQWUsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBTyxDQUFtQixDQUFDLEVBQUMsOEdBQThHO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFlLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQWUsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7VUFBQSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsR0FBRSxvQ0FBb0MsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBeUIsQ0FBbUIsQ0FBQyxFQUFDLG1CQUFtQjtVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFRLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFvQixDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFPLENBQW1CLENBQUM7VUFBQSxDQUFnQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQztNQUFBLENBQW1CLENBQUM7SUFBQSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNVLENBQUM7TUFBQWdCLFFBQUEsR0FBRSxrREFBa0QsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUEwQixDQUFxQixDQUFDLEVBQUMsb0VBQW9FO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDSyxFQUFFO01BQUNzQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUsb0JBQW9CO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQyxhQUFhLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQWEsQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLHNCQUFzQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFRLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQWMsQ0FBbUIsQ0FBQyxFQUFDLGdCQUFnQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFVLENBQW1CO01BQUMsQ0FBb0IsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBZ0IsQ0FBbUI7TUFBQyxDQUFvQixDQUFDLEVBQUMsMlNBQTJTLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQVcsQ0FBaUIsQ0FBQyxFQUFDLHFFQUFxRTtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ08sRUFBRSxJQUFFLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQVYsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDSSxFQUFFO01BQUN1QixFQUFFLEVBQUMsZ0RBQWdEO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBZ0QsQ0FBRSxDQUFDLEVBQUMsZ0NBQWdDLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQXlCLENBQWlCLENBQUM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNLLEVBQUU7TUFBQ3NCLEVBQUUsRUFBQyxPQUFPO01BQUMsYUFBVSx1REFBdUQ7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLHdDQUF3QyxlQUFDLElBQUE5QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUF3QixDQUFpQixDQUFDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLEdBQUUseUNBQXlDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEdBQUUseUJBQXlCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLFNBQVM7TUFBQSxDQUFxQixDQUFDLEVBQUMsMERBQTBELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBNEQsQ0FBcUIsQ0FBQyxFQUFDLGtJQUFrSTtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxFQUFFO0lBQTBDLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ21CLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQStELENBQXFCLENBQUMsRUFBQyxrQkFBa0IsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsd0RBQXdELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQWdCLENBQW1CLENBQUMsRUFBQywyQ0FBMkMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBbUIsQ0FBbUIsQ0FBQyxFQUFDLDRFQUE0RTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUEwRixDQUFxQixDQUFDLEVBQUMsNERBQTRELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQU0sQ0FBaUIsQ0FBQyxFQUFDLDhIQUE4SCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFtQixDQUFtQixDQUFDLEVBQUMseUdBQXlHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBTSxDQUFxQixDQUFDLEVBQUMsa0VBQWtFO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNLLEVBQUU7TUFBQ3NCLEVBQUUsRUFBQyxPQUFPO01BQUMsYUFBVSxpREFBaUQ7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLGtDQUFrQyxlQUFDLElBQUE5QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUF3QixDQUFpQixDQUFDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDVyxHQUFHO01BQUFlLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUMyQixTQUFTLEVBQUMsYUFBYTtRQUFBSCxRQUFBLEVBQUU7TUFBb04sQ0FBbUI7SUFBQyxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNNLEVBQUU7TUFBQ3FCLEVBQUUsRUFBQyxTQUFTO01BQUMsYUFBVSxtRUFBbUU7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFTLENBQUUsQ0FBQyxFQUFDLCtCQUErQixlQUFDLElBQUE5QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUEyQyxDQUFpQixDQUFDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUE0QixDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQTBDLENBQXFCLENBQUMsRUFBQyx5RkFBeUYsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBVSxDQUFtQixDQUFDLEVBQUMsd0RBQXdELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQWMsQ0FBbUIsQ0FBQyxFQUFDLHFEQUFxRCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFRLENBQW1CLENBQUMsRUFBQyw0Q0FBNEMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsR0FBRSxXQUFXLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQVUsQ0FBbUIsQ0FBQyxFQUFDLDJCQUEyQjtNQUFBLENBQXFCLENBQUMsRUFBQyxvRUFBb0UsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBa0IsQ0FBbUIsQ0FBQyxFQUFDLDZCQUE2QixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFhLENBQW1CLENBQUMsRUFBQyw4QkFBOEI7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNNLEVBQUU7TUFBQ3FCLEVBQUUsRUFBQyxTQUFTO01BQUMsYUFBVSx1Q0FBdUM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFTLENBQUUsQ0FBQyxFQUFDLG9DQUFvQyxlQUFDLElBQUE5QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUFTLENBQWlCLENBQUM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNVLENBQUM7TUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQVksQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFRLENBQXFCLENBQUMsRUFBQyxrQkFBa0IsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBTyxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFXLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQVMsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBVyxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFjLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQVksQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBcUIsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBdUIsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsR0FBRSxjQUFjLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQVUsQ0FBbUIsQ0FBQyxFQUFDLHdCQUF3QjtNQUFBLENBQXFCLENBQUMsRUFBQyxtQ0FBbUMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1FBQUF1QixRQUFBLEVBQUU7TUFBZSxDQUFpQixDQUFDLEVBQUMsb0ZBQW9GLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQVcsQ0FBbUIsQ0FBQyxFQUFDLHNKQUFzSjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ21CLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQywwREFBMEQ7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLHVEQUF1RCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQW9ELENBQXFCLENBQUMsRUFBQyx3REFBd0Q7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsR0FBRSx5REFBeUQsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBTyxDQUFtQixDQUFDLEVBQUMsd0JBQXdCO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNNLEVBQUU7TUFBQ3FCLEVBQUUsRUFBQyxTQUFTO01BQUMsYUFBVSw4Q0FBOEM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFTLENBQUUsQ0FBQyxFQUFDLE1BQU0sZUFBQyxJQUFBOUIsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBUyxDQUFtQixDQUFDLEVBQUMsZ0NBQWdDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQVMsQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBcUIsQ0FBbUIsQ0FBQyxFQUFDLGlHQUFpRyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFJLENBQW1CLENBQUMsRUFBQyw0QkFBNEIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUEyQixDQUFxQixDQUFDLEVBQUMsd0NBQXdDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQXlDLENBQW1CLENBQUMsRUFBQyw2REFBNkQsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1FBQUF1QixRQUFBLEVBQUU7TUFBVSxDQUFpQixDQUFDLEVBQUMsOENBQThDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQUksQ0FBbUIsQ0FBQyxFQUFDLG9GQUFvRixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVEsQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBUyxDQUFtQixDQUFDLEVBQUMsbUpBQW1KO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDTSxFQUFFO01BQUNxQixFQUFFLEVBQUMsU0FBUztNQUFDLGFBQVUsdUNBQXVDO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBUyxDQUFFLENBQUMsRUFBQyxtQ0FBbUMsZUFBQyxJQUFBOUIsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1FBQUF1QixRQUFBLEVBQUU7TUFBVSxDQUFpQixDQUFDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQTZELENBQXFCLENBQUMsRUFBQyx5TEFBeUwsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFnRCxDQUFxQixDQUFDLEVBQUMsa1RBQWtUO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLEdBQUUsb0JBQW9CLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQTRCLENBQW1CLENBQUMsRUFBQyxvREFBb0QsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUF3QixDQUFxQixDQUFDLEVBQUMseUdBQXlHO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDSyxFQUFFO01BQUNzQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUscURBQXFEO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQyxnREFBZ0QsZUFBQyxJQUFBOUIsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1FBQUF1QixRQUFBLEVBQUU7TUFBYSxDQUFpQixDQUFDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLEVBQUU7SUFBa0osQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDYSxLQUFLO01BQUFhLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2lCLEtBQUs7UUFBQVMsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQUcsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQWMsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQW9CLENBQWlCLENBQUM7UUFBQSxDQUFnQjtNQUFDLENBQW1CLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNjLEtBQUs7UUFBQVksUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQUksQ0FBcUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsR0FBRSxTQUFTLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQWlCLENBQW1CLENBQUMsRUFBQyw2QkFBNkIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO2NBQUFjLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2dCQUFBd0IsUUFBQSxFQUFFO2NBQUksQ0FBbUI7WUFBQyxDQUFvQixDQUFDLEVBQUMsZ0JBQWdCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQVMsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBUyxDQUFtQixDQUFDLEVBQUMsY0FBYyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQWEsQ0FBcUIsQ0FBQztVQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxHQUFFLDhCQUE4QixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFJLENBQW1CLENBQUMsRUFBQyx5QkFBeUIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBUyxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFPLENBQW1CLENBQUMsRUFBQyxzQkFBc0IsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBVyxDQUFtQixDQUFDLEVBQUMsOEJBQThCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQVcsQ0FBbUIsQ0FBQyxFQUFDLDZHQUE2RztVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQUksQ0FBcUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsR0FBRSw4QkFBOEIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO2NBQUFjLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2dCQUFBd0IsUUFBQSxFQUFFO2NBQU0sQ0FBbUI7WUFBQyxDQUFvQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07Y0FBQWMsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Z0JBQUF3QixRQUFBLEVBQUU7Y0FBTyxDQUFtQjtZQUFDLENBQW9CLENBQUMsRUFBQyxhQUFhLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQU8sQ0FBbUIsQ0FBQyxFQUFDLG9DQUFvQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFTLENBQW1CLENBQUMsRUFBQyxrREFBa0Q7VUFBQSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsR0FBRSxrREFBa0QsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBTSxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFPLENBQW1CLENBQUMsRUFBQyxzRkFBc0YsZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDWSxNQUFNO2NBQUFjLFFBQUEsR0FBRSw4QkFBOEIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2dCQUFBd0IsUUFBQSxFQUFFO2NBQUksQ0FBbUIsQ0FBQyxFQUFDLFFBQVE7WUFBQSxDQUFxQixDQUFDLEVBQUMsa0dBQWtHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQVksQ0FBbUIsQ0FBQyxFQUFDLG1GQUFtRixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFTLENBQW1CLENBQUMsRUFBQyx5SUFBeUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO2NBQUF1QixRQUFBLEVBQUU7WUFBSyxDQUFpQixDQUFDLEVBQUMsd0JBQXdCO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBSSxDQUFxQjtVQUFDLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxHQUFFLDBCQUEwQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07Y0FBQWMsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Z0JBQUF3QixRQUFBLEVBQUU7Y0FBVyxDQUFtQjtZQUFDLENBQW9CLENBQUMsRUFBQyxtQkFBbUIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBVyxDQUFtQixDQUFDLEVBQUMsbURBQW1EO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBeUYsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBSSxDQUFxQjtVQUFDLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxHQUFFLDRDQUE0QyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07Y0FBQWMsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Z0JBQUF3QixRQUFBLEVBQUU7Y0FBYSxDQUFtQjtZQUFDLENBQW9CLENBQUM7VUFBQSxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsR0FBRSxlQUFlLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQVMsQ0FBbUIsQ0FBQyxFQUFDLGtCQUFrQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7Y0FBQXVCLFFBQUEsRUFBRTtZQUFxRCxDQUFpQixDQUFDLEVBQUMsdUhBQXVILGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQVcsQ0FBbUIsQ0FBQyxFQUFDLGlEQUFpRDtVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDO01BQUEsQ0FBbUIsQ0FBQztJQUFBLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFtQyxDQUFxQixDQUFDLEVBQUMsc0VBQXNFLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQTRCLENBQW1CLENBQUMsRUFBQywrR0FBK0csZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBYyxDQUFtQixDQUFDLEVBQUMsOExBQThMO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVcsQ0FBcUIsQ0FBQyxFQUFDLG9EQUFvRCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQXFCLENBQXFCLENBQUMsRUFBQyxrUUFBa1E7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNPLEVBQUUsSUFBRSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFWLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDc0IsRUFBRSxFQUFDLE9BQU87TUFBQyxhQUFVLCtDQUErQztNQUFBRCxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMsMENBQTBDLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQWEsQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ21CLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQThDLENBQXFCLENBQUMsRUFBQyw2QkFBNkIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1lBQUF3QixRQUFBLEVBQUU7VUFBWSxDQUFtQjtRQUFDLENBQW9CLENBQUMsRUFBQywrQkFBK0IsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsOFBBQThQLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEdBQUUsdUJBQXVCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBd0IsUUFBQSxFQUFFO1VBQTZDLENBQW1CLENBQUMsRUFBQyxpQ0FBaUM7UUFBQSxDQUFxQixDQUFDLEVBQUMsOEdBQThHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQU0sQ0FBbUIsQ0FBQyxFQUFDLHdOQUF3TjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFlLENBQXFCLENBQUMsRUFBQyw2QkFBNkIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsdUVBQXVFLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQTJCLENBQW1CLENBQUMsRUFBQyxNQUFNO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxHQUFFLGdDQUFnQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7WUFBQXVCLFFBQUEsRUFBRTtVQUFNLENBQWlCLENBQUMsRUFBQyxTQUFTO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLHFDQUFxQztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFzQyxDQUFxQixDQUFDLEVBQUMsZ05BQWdOLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBc0IsQ0FBcUIsQ0FBQyxFQUFDLDBGQUEwRjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFnRSxDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFlLENBQW1CLENBQUMsRUFBQyw2TEFBNkw7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ08sRUFBRSxJQUFFLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQVYsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDSyxFQUFFO01BQUNzQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUsaUVBQWlFO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQyxZQUFZLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQTZELENBQWlCLENBQUM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNNLEVBQUU7TUFBQ3FCLEVBQUUsRUFBQyxnQkFBZ0I7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFnQixDQUFFLENBQUMsRUFBQyxrQkFBa0I7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNhLEtBQUs7TUFBQWEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDaUIsS0FBSztRQUFBUyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBTSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBTSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0I7TUFBQyxDQUFtQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDYyxLQUFLO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFTLENBQXFCO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEdBQUUsb0NBQW9DLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBTyxDQUFxQixDQUFDLEVBQUMsWUFBWSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFZLENBQW1CLENBQUMsRUFBQyxrSUFBa0k7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFTLENBQXFCO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEdBQUUsc0VBQXNFLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBa0MsQ0FBcUIsQ0FBQyxFQUFDLE1BQU0sZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBTyxDQUFtQixDQUFDLEVBQUMsU0FBUyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFNLENBQW1CLENBQUMsRUFBQyxXQUFXLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQUssQ0FBbUIsQ0FBQyxFQUFDLGFBQWEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBRyxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFHLENBQW1CLENBQUMsRUFBQyx1Q0FBdUM7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFTLENBQXFCO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNZLE1BQU07Y0FBQWMsUUFBQSxHQUFFLHlEQUF5RCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Z0JBQUF3QixRQUFBLEVBQUU7Y0FBTyxDQUFtQixDQUFDLEVBQUMsY0FBYztZQUFBLENBQXFCLENBQUMsRUFBQyxnSEFBZ0gsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBUSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFRLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQU8sQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBZSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFnQixDQUFtQixDQUFDLEVBQUMsaUJBQWlCO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBUyxDQUFxQjtVQUFDLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxHQUFFLE1BQU0sZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBUyxDQUFtQixDQUFDLEVBQUMseUJBQXlCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQVMsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBWSxDQUFtQixDQUFDLEVBQUMsNkZBQTZGO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBUyxDQUFxQjtVQUFDLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxHQUFFLGtGQUFrRixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQW1CLENBQXFCLENBQUMsRUFBQyxtSEFBbUg7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFTLENBQXFCO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEdBQUUsMEJBQTBCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQVUsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQztNQUFBLENBQW1CLENBQUM7SUFBQSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNNLEVBQUU7TUFBQ3FCLEVBQUUsRUFBQywwQ0FBMEM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUEwQyxDQUFFLENBQUMsRUFBQyw4Q0FBOEM7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNVLENBQUM7TUFBQWdCLFFBQUEsR0FBRSxrRkFBa0YsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1FBQUF1QixRQUFBLEVBQUU7TUFBYSxDQUFpQixDQUFDLEVBQUMsNkZBQTZGLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBc0IsQ0FBcUIsQ0FBQyxFQUFDLDhEQUE4RCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFjLENBQW1CLENBQUMsRUFBQyxPQUFPLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQVMsQ0FBbUIsQ0FBQyxFQUFDLGlFQUFpRSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFxQixDQUFtQixDQUFDLEVBQUMsaUJBQWlCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQVMsQ0FBbUIsQ0FBQyxFQUFDLHFGQUFxRixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFTLENBQW1CLENBQUMsRUFBQyxZQUFZLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBSyxDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFhLENBQW1CLENBQUMsRUFBQyxnQkFBZ0IsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFpQyxDQUFxQixDQUFDLEVBQUMscUdBQXFHO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDTyxFQUFFLElBQUUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBVixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNLLEVBQUU7TUFBQ3NCLEVBQUUsRUFBQyxPQUFPO01BQUMsYUFBVSxrREFBa0Q7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLDhDQUE4QyxlQUFDLElBQUE5QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUFZLENBQWlCLENBQUM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNNLEVBQUU7TUFBQ3FCLEVBQUUsRUFBQyxtREFBbUQ7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFtRCxDQUFFLENBQUMsRUFBQyxzREFBc0Q7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNhLEtBQUs7TUFBQWEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDaUIsS0FBSztRQUFBUyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBWSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBNkIsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQXFCLENBQWlCLENBQUM7UUFBQSxDQUFnQjtNQUFDLENBQW1CLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNjLEtBQUs7UUFBQVksUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQXlFLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUF1QixDQUFtQjtVQUFDLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFxQyxDQUFtQjtVQUFDLENBQWdCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQThCLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUF1QixDQUFtQjtVQUFDLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFzQixDQUFtQjtVQUFDLENBQWdCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxHQUFFLDhEQUE4RCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFlLENBQW1CLENBQUMsRUFBQyw2Q0FBNkM7VUFBQSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBd0IsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBVyxDQUFtQjtVQUFDLENBQWdCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQThELENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUF5QixDQUFtQjtVQUFDLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUErQixDQUFtQjtVQUFDLENBQWdCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQTZFLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUEyQixDQUFtQjtVQUFDLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFtQixDQUFtQjtVQUFDLENBQWdCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxHQUFFLHlCQUF5QixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQW1CLENBQXFCLENBQUMsRUFBQyxTQUFTLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQXVCLENBQW1CLENBQUMsRUFBQyxlQUFlLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQVMsQ0FBbUIsQ0FBQztVQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUF3QixDQUFtQjtVQUFDLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFXLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFxQixDQUFtQixDQUFDLEVBQUMsNERBQTREO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQTBCLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQWlDLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBMkUsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQXFCLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQWdCLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBeUUsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQXdCLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQTBDLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQztRQUFBLENBQWdCLENBQUM7TUFBQSxDQUFtQixDQUFDO0lBQUEsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxHQUFFLDhEQUE4RCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQVUsQ0FBbUIsQ0FBQyxFQUFDLGlEQUFpRCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUMsRUFBQywyTUFBMk07TUFBQSxDQUFpQjtJQUFDLENBQWUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDTSxFQUFFO01BQUNxQixFQUFFLEVBQUMsMERBQTBEO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBMEQsQ0FBRSxDQUFDLEVBQUMsNERBQTREO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDYSxLQUFLO01BQUFhLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2lCLEtBQUs7UUFBQVMsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQWUsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQVcsQ0FBaUIsQ0FBQztRQUFBLENBQWdCO01BQUMsQ0FBbUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2MsS0FBSztRQUFBWSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBNkQsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBMkIsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBeUIsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBUyxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUE4QyxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFTLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQThCLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQThCLENBQXFCO1VBQUMsQ0FBZ0IsQ0FBQztRQUFBLENBQWdCLENBQUM7TUFBQSxDQUFtQixDQUFDO0lBQUEsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDTyxFQUFFLElBQUUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBVixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNLLEVBQUU7TUFBQ3NCLEVBQUUsRUFBQyxPQUFPO01BQUMsYUFBVSw2REFBNkQ7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLHdDQUF3QyxlQUFDLElBQUE5QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUFnQyxDQUFpQixDQUFDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDbUIsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBbUUsQ0FBcUIsQ0FBQyxFQUFDLHlEQUF5RCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFZLENBQWlCLENBQUMsRUFBQyxpRUFBaUUsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBYSxDQUFpQixDQUFDLEVBQUMsMElBQTBJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQU0sQ0FBaUIsQ0FBQyxFQUFDLG1EQUFtRCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFXLENBQWlCLENBQUMsRUFBQyxnQkFBZ0IsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBa0IsQ0FBbUIsQ0FBQyxFQUFDLG1QQUFtUDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUE2RCxDQUFxQixDQUFDLEVBQUMsd0hBQXdILGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLGlFQUFpRSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFNLENBQW1CLENBQUMsRUFBQyxrR0FBa0c7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBK0UsQ0FBcUIsQ0FBQyxFQUFDLHFLQUFxSyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFXLENBQWlCLENBQUMsRUFBQyw4RUFBOEU7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBd0QsQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBb0MsQ0FBaUIsQ0FBQyxFQUFDLHNCQUFzQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFZLENBQW1CLENBQUMsRUFBQyx5QkFBeUIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBa0IsQ0FBaUIsQ0FBQyxFQUFDLDJCQUEyQjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFpRCxDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFvQyxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFrQixDQUFpQixDQUFDLEVBQUMsbUJBQW1CO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQStELENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQStELENBQWlCLENBQUMsRUFBQywyRUFBMkUsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBa0IsQ0FBaUIsQ0FBQyxFQUFDLGlJQUFpSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUE0QyxDQUFxQixDQUFDLEVBQUMsZ0RBQWdELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLGlDQUFpQztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBd0IsUUFBQSxFQUFFO1VBQVEsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1lBQUF3QixRQUFBLEVBQUU7VUFBVSxDQUFtQixDQUFDLEVBQUMsdUJBQXVCO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBVyxDQUFpQixDQUFDLEVBQUMscURBQXFEO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNPLEVBQUUsSUFBRSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFWLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDc0IsRUFBRSxFQUFDLFFBQVE7TUFBQyxhQUFVLDhCQUE4QjtNQUFBRCxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVEsQ0FBRSxDQUFDLEVBQUMsMEJBQTBCLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQVUsQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQTZILENBQXFCO0lBQUMsQ0FBZSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNtQixFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFpQixDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyxnQkFBZ0IsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBWSxDQUFtQixDQUFDLEVBQUMsMEpBQTBKLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBSSxDQUFxQixDQUFDLEVBQUMsR0FBRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFpQixDQUFxQixDQUFDLEVBQUMsWUFBWSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFNLENBQW1CLENBQUMsRUFBQyxnQkFBZ0IsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFVLENBQXFCLENBQUMsRUFBQyxzQkFBc0IsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBSSxDQUFtQixDQUFDLEVBQUMseUlBQXlJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQUksQ0FBbUIsQ0FBQyxFQUFDLG1CQUFtQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQUksQ0FBcUIsQ0FBQyxFQUFDLEdBQUc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBaUIsQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBbUIsQ0FBbUIsQ0FBQyxFQUFDLDhNQUE4TSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQUksQ0FBcUIsQ0FBQyxFQUFDLEdBQUc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBaUIsQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBaUIsQ0FBbUIsQ0FBQyxFQUFDLHlCQUF5QixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFTLENBQW1CLENBQUMsRUFBQyxnQkFBZ0IsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBUyxDQUFtQixDQUFDLEVBQUMsa0JBQWtCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBSSxDQUFxQixDQUFDLEVBQUMsR0FBRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFlLENBQXFCLENBQUMsRUFBQyxnQkFBZ0IsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBTyxDQUFtQixDQUFDLEVBQUMsNEVBQTRFLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLDJEQUEyRDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFlLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQVMsQ0FBbUIsQ0FBQyxFQUFDLDBCQUEwQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQywySEFBMkgsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFJLENBQXFCLENBQUMsRUFBQyxHQUFHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWUsQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBUyxDQUFtQixDQUFDLEVBQUMsdUZBQXVGLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQVMsQ0FBbUIsQ0FBQyxFQUFDLGdEQUFnRDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFlLENBQXFCLENBQUMsRUFBQyx5SUFBeUk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBZSxDQUFxQixDQUFDLEVBQUMsNkdBQTZHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWdCLENBQXFCLENBQUMsRUFBQyxtQ0FBbUMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMseUVBQXlFLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQWdCLENBQW1CLENBQUMsRUFBQyxpREFBaUQ7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBZ0IsQ0FBcUIsQ0FBQyxFQUFDLHNKQUFzSjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFnQixDQUFxQixDQUFDLEVBQUMsOERBQThELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBSSxDQUFxQixDQUFDLEVBQUMsaUVBQWlFO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWdCLENBQXFCLENBQUMsRUFBQyxvSEFBb0g7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBZ0IsQ0FBcUIsQ0FBQyxFQUFDLGtHQUFrRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFnQixDQUFxQixDQUFDLEVBQUMsMkJBQTJCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLHdGQUF3RjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFnQixDQUFxQixDQUFDLEVBQUMsZ0RBQWdELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQWlCLENBQW1CLENBQUMsRUFBQyxHQUFHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWdCLENBQXFCLENBQUMsRUFBQywrQkFBK0IsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBYyxDQUFtQixDQUFDLEVBQUMsOERBQThELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQVksQ0FBbUIsQ0FBQyxFQUFDLGVBQWU7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBZ0IsQ0FBcUIsQ0FBQyxFQUFDLGdKQUFnSjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDTyxFQUFFLElBQUUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBVixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNLLEVBQUU7TUFBQ3NCLEVBQUUsRUFBQyxRQUFRO01BQUMsYUFBVSxtQkFBbUI7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFRLENBQUUsQ0FBQyxFQUFDLG9CQUFvQjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ21CLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQUksQ0FBcUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBWSxDQUFtQixDQUFDLEVBQUMsMkdBQTJHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxHQUFFLDRGQUE0RixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7WUFBQXdCLFFBQUEsRUFBRTtVQUEwQixDQUFtQixDQUFDLEVBQUMsNENBQTRDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtZQUFBYyxRQUFBLEVBQUU7VUFBSSxDQUFxQixDQUFDLEVBQUMsb0ZBQW9GLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBd0IsUUFBQSxFQUFFO1VBQWEsQ0FBbUIsQ0FBQyxFQUFDLCtCQUErQjtRQUFBLENBQWlCLENBQUM7TUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBSSxDQUFxQixDQUFDLEVBQUMsU0FBUyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQywyRUFBMkU7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBSSxDQUFxQixDQUFDLEVBQUMsMElBQTBJO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQUksQ0FBcUIsQ0FBQyxFQUFDLHVFQUF1RTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFJLENBQXFCLENBQUMsRUFBQyxjQUFjLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQWdCLENBQW1CLENBQUMsRUFBQyw2SEFBNkg7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBSSxDQUFxQixDQUFDLEVBQUMsMEVBQTBFO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQUksQ0FBcUIsQ0FBQyxFQUFDLGtHQUFrRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQztFQUFBLENBQUUsQ0FBQztBQUM3cG5EO0FBQ2UsU0FBU0ksVUFBVUEsQ0FBQy9CLEtBQUssR0FBRyxDQUFDLENBQUMsRUFBRTtFQUM3QyxNQUFNO0lBQUNnQyxPQUFPLEVBQUVDO0VBQVMsQ0FBQyxHQUFHO0lBQzNCLEdBQUcsSUFBQVosNkJBQWtCLEVBQUMsQ0FBQztJQUN2QixHQUFHckIsS0FBSyxDQUFDc0I7RUFDWCxDQUFDO0VBQ0QsT0FBT1csU0FBUyxnQkFBRyxJQUFBbkMsV0FBQSxDQUFBK0IsR0FBQSxFQUFDSSxTQUFTO0lBQUEsR0FBS2pDLEtBQUs7SUFBQTJCLFFBQUEsZUFBRSxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDOUIsaUJBQWlCO01BQUEsR0FBS0M7SUFBSyxDQUFHO0VBQUMsQ0FBVyxDQUFDLEdBQUdELGlCQUFpQixDQUFDQyxLQUFLLENBQUM7QUFDbEg7QUFBQ2tDLEVBQUEsR0FOdUJILFVBQVU7QUFPbEMsU0FBU1Asb0JBQW9CQSxDQUFDSSxFQUFFLEVBQUVPLFNBQVMsRUFBRUMsS0FBSyxFQUFFO0VBQ2xELE1BQU0sSUFBSUMsS0FBSyxDQUFDLFdBQVcsSUFBSUYsU0FBUyxHQUFHLFdBQVcsR0FBRyxRQUFRLENBQUMsR0FBRyxJQUFJLEdBQUdQLEVBQUUsR0FBRyxvRUFBb0UsSUFBSVEsS0FBSyxHQUFHLHFDQUFxQyxHQUFHQSxLQUFLLEdBQUcsbURBQW1ELEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDN1E7QUFBQyxJQUFBRixFQUFBO0FBQUFJLFlBQUEsQ0FBQUosRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}