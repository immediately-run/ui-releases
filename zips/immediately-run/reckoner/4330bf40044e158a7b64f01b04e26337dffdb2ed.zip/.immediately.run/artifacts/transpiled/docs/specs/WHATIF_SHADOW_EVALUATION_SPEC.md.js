var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      blockquote: "blockquote",
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      h3: "h3",
      hr: "hr",
      li: "li",
      p: "p",
      pre: "pre",
      strong: "strong",
      table: "table",
      tbody: "tbody",
      td: "td",
      th: "th",
      thead: "thead",
      tr: "tr",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "reckoner-what-if-shadow-evaluation-an-ephemeral-counterfactual-work-area-over-the-starved-engine",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "reckoner-what-if-shadow-evaluation-an-ephemeral-counterfactual-work-area-over-the-starved-engine"
      }), "Reckoner What-if Shadow Evaluation — an ephemeral counterfactual work area over the starved engine"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Status:"
      }), " implemented at the deliverable level — the R-6 work-area slice (R3-395…R3-397);\none adversarial pass folded (§11, WIF-R1…R11); residuals live in the status doc. ·\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Updated:"
      }), " 2026-08-27"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.em, {
        children: ["(Implementation note, 2026-08-27 — the design below was authored, adversarially reviewed,\nand then built in the same pass: §§1–6 and the §8 gates are normative and shipped; §7 and\n§12 remain the honest remainder. The earlier ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "proposal"
        }), " markers on built sections were\nreconciled in this edit, per spec_style \"keep status honest\".)"]
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["The single implementation-status source for this spec is\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "docs/status/WHATIF_SHADOW_EVALUATION_STATUS.md"
          })]
        }), " — where this document and that one\ndisagree, the status doc governs."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Reads first:"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ARCHITECTURE_PLAN.md"
        }), " §4.1/§4.2 (the worker-backed engine, watchdog,\nsupersession), §7.1 (the scope cut this spec re-opens a slice of), risk R-6;\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "REPORTING_SPREADSHEET_SPEC.md"
        }), " §3.2 (the starved evaluator), §5 (ephemeral compute /\nRS-10 write-laundering); ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ENGINE_INFORMATION_FLOW_SPEC.md"
        }), " (tiering through the engine);\nthe platform's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "EDITOR_FIRST_EDITING_SPEC.md"
        }), " (why this is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "not"
        }), " an in-app editor\nviolation — its §5 stated-reason rule, satisfied in §6 below)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-0",
      "data-slug": "0-charter-the-gap-and-the-shape-of-the-fix-normative-shipped-2026-08-27",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-0"
      }), "0. Charter — the gap and the shape of the fix  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative — shipped 2026-08-27)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ARCHITECTURE_PLAN §7.1"
      }), " scoped v1 to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "report-authoring and delegation, not ad-hoc\nexploration"
      }), ", and risk ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "R-6"
      }), " booked the consequence honestly: the solo analyst has no\nplace to mess around — no scratch cell, no \"what happens if I change this,\" nothing\nbetween ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "dragging a declared slider"
      }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "forking the repository"
      }), ". The Caldera case study\nmakes the gap concrete: the document itself contains a 25-run sensitivity grid and a\ngoal-seek — reified exploration — but nothing in the product lets an author ask one\ncounterfactual question of their own without editing repository files."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["This spec fills the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "engine-cheap"
      }), " slice of R-6 with one mechanism and two surfaces:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "A shadow session"
        }), ": a second, equally-starved engine instance built over ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "patched"
        }), "\nworksheet sources and a pinned snapshot of the live session's state, whose results are\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "rendered, diffed against that pinned baseline, and discarded — never persisted"
        }), "."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The two surfaces are the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "what-if panel"
      }), " (perturb an existing cell's formula from the\nvalue inspector and watch the downstream neighborhood shift) and the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "scratch pad"
      }), " (an\nunsaved, in-memory worksheet — the notebook work area). Both are strictly opt-in chrome\ninside existing review surfaces; the report a viewer opens is untouched (value 2)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "What this spec deliberately is not:"
      }), " it is not the authoring/persistence path (no file\nwrites, no contribute flow, no \"apply\" — §7), not the R-6 ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "tabular multi-cell inspector"
      }), "\nor ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "range-select-sum"
      }), " (still open), and not a new realm, capability, principal, service,\nor gate (§5)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-1",
      "data-slug": "1-product-surface-normative-shipped-2026-08-27",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-1"
      }), "1. Product surface  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative — shipped 2026-08-27)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-1-1",
      "data-slug": "11-the-what-if-panel-inspector",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-1-1"
      }), "1.1 The what-if panel (inspector)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The value inspector (review surface slice 2) gains a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "\"What if\""
      }), " section for the\ninspected cell:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["an editable ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "variant"
        }), " of the cell's formula source, pre-filled with the current\nformula (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "CellDescriptor.formulaSource"
        }), "). A variant replaces the formula ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "function\nonly"
        }), "; the cell's declared ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "inputs"
        }), " are not editable in v1, so variant formulas compute\nover the same declared inputs (an undeclared name is an ordinary evaluation error);"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Run"
        }), " action: pins a coherent baseline (§2.1), builds the shadow session with the\nvariant spliced in (§3), runs it over the pinned externals, and runs the shadow test\nsuite;"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["a result readout: the cell's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "baseline → shadow value"
        }), ", the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "downstream delta list"
        }), "\n(every dependent cell whose value changed, scoped by the dependents closure — §4), any\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "new errors"
        }), ", and the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "test verdicts that flipped"
        }), ";"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Discard"
        }), " action: shadow results are dropped. Variant ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "text"
        }), " is session-scoped\nstate (§1.4), so closing the inspector does not silently destroy an edited variant."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.em, {
        children: ["(Amendment, 2026-08-28 — collapsed by default. The v1 always-open panel rendered the\nsame formula twice in adjacent boxes — the inspector's read-only FORMULA row (provenance)\nand the pre-filled variant editor — a visual redundancy user feedback flagged on first\ncontact. The section now starts collapsed; the FORMULA row carries a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "what if →"
        }), "\naffordance that opens it (pre-filled at that moment, as before), and it re-opens on its\nown whenever the cell's variant text differs from the document formula, so typed source\nnever hides itself. The pre-fill decision and everything else in this section stand; the\nread-only FORMULA row deliberately stays — letting the editor double as the display would\nmake the document's formula look editable, blurring the real-vs-counterfactual line this\ndesign keeps sharp.)"]
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "The panel is explicit-run (no evaluate-on-keystroke): a run is a full shadow build + pass"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: "suite, its browser-side cost is unmeasured, and on the platform today it shares the\nmain thread (§6) — an explicit action keeps that cost legible and interruptible-by-choice."
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-1-2",
      "data-slug": "12-the-scratch-pad-workbook-panel",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-1-2"
      }), "1.2 The scratch pad (workbook panel)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The workbook panel gains a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "\"Scratch\""
      }), " section: one in-memory worksheet source buffer\nthe author edits freely (cells, tests, cross-sheet inputs — the full worksheet grammar),\nplus ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Run"
      }), ". Running builds the shadow session with the scratch module added as an extra\nworksheet (§3.2) and displays the scratch cells as ordinary workbook cards — value,\nerrors, verdicts — in the same visual language as durable cells, but visibly marked\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "scratch (unsaved)"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Scratch ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "test cells must target scratch subjects"
      }), ": a scratch test whose ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "subject"
      }), " is a\ndurable cell is refused at shadow-build time with a visible message (§4, WIF-R6). Probing\ndurable cells with ad-hoc tests is booked as an open question (Q5), not silently allowed."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The scratch pad is the R-6 \"ephemeral scratch surface\": a notebook-like place to try\nthings whose semantics are exactly worksheet semantics (named, typed, testable cells)\nwith the ceremony removed. Promotion to a durable worksheet file is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "out of scope"
      }), " (§7)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-1-3",
      "data-slug": "13-run-mode-first-value-2",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-1-3"
      }), "1.3 Run-mode-first (value 2)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Neither surface adds a pixel to the report view. Both live behind the existing opt-in\ndoors (the inspector; the workbook panel), which a pure viewer never opens. A static\nreport opens exactly as before — zero prompts, zero chrome."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-1-4",
      "data-slug": "14-ephemeral-results-durable-enough-text-wif-r9",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-1-4"
      }), "1.4 Ephemeral results, durable-enough text (WIF-R9)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Ephemeral ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "results"
      }), " are a security posture; ephemeral ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "user-typed source with zero\nrecovery"
      }), " would be unhandled data loss. v1 requirements:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Buffer text outlives panel visibility."
        }), " The scratch buffer and per-cell variant\ntexts are session-scoped app state: closing/reopening the workbook panel or inspector\ndoes not clear them. A page reload does (persistence is booked, §7, with the\nopaque-origin storage constraint named)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Explicit Clear, confirmed."
        }), " The only way to empty a non-empty scratch buffer is an\nexplicit Clear action with a confirm step."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Copy affordance."
        }), " The scratch pad offers copy-to-clipboard for the buffer text\n(guarded — clipboard access can be absent in the sandboxed iframe; the buffer is a\nplain textarea, so manual select-copy always works as the floor). Copying text touches\nno mount and no RS-10 gate."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-1-5",
      "data-slug": "15-mobile-value-8-wif-r8",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-1-5"
      }), "1.5 Mobile (value 8; WIF-R8)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Honestly scoped rather than omitted: both surfaces ride panels that already stack\nfull-width on small screens. v1 requires: the variant/scratch textareas render at a\nfont-size that avoids focus-zoom, Run/Discard/Copy are reachable without dismissing the\nkeyboard, and the delta list reads as a stacked list (no wide matrix). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Hand-typing\nformula code on a phone is not the target interaction and this spec does not claim it\nis"
      }), ": the mobile-complete counterfactual path remains the report's params widgets; the\nwhat-if and scratch surfaces on mobile are functional-but-keyboard-bound, and a\nstructured (no-code) mobile variant flow is booked value-8 debt (Q6), owned by this spec."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-2",
      "data-slug": "2-the-shadow-session-normative-shipped-2026-08-27",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-2"
      }), "2. The shadow session  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative — shipped 2026-08-27)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["A shadow session is a second ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "AsyncEngine"
      }), " over its own transport, built from the\ndocument's worksheet sources with a patch applied, run once over a pinned baseline:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "shadowRun({\n  sources,            // the live session's retained worksheet sources\n  patch,              // { variants: Map<cellId, formulaSource>, scratch?: string }\n  baseline,           // the pinned { pass, externals } pair (§2.1)\n  transport,          // its own transport — never the base engine's\n}) → { pass, verdicts, diff, diagnostics }\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-2-1",
      "data-slug": "21-the-pinned-baseline-wif-r3",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-2-1"
      }), "2.1 The pinned baseline (WIF-R3)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Under a live feed the base session is a moving target: the feed runtime drives\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "engine.update"
      }), " continuously, a pass ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "clears"
      }), " published results at its start, and a\njust-written external can sit in the pending slot before any pass adopts it. Diffing a\nshadow pass against \"the live engine, whenever the shadow happens to finish\" would\nproduce spurious deltas on every feed-derived cell."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["So Run begins by capturing a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "coherent settled baseline"
      }), " from the base engine — a new\nengine accessor (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "settledSnapshot()"
      }), ", must-establish §9) that:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: "awaits quiescence (no pass in flight, no pending externals — the single-slot\nsupersession loop makes this a bounded wait);"
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["returns the settled pass (results + errors) ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "and"
        }), " the externals that produced it —\nparams, fixtures, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "and retained feed buffers"
        }), " — as one pair;"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "deep-copies the externals"
        }), " (structured clone; the values are structured-clone-safe\nby construction — they cross the worker boundary). This is not hygiene but a\ncorrectness/integrity requirement on the in-process path: without it the shadow's\ncompartments share live Row/array references with the base engine, and a variant\nmutating an input row corrupts the base session's next pass (WIF-R1)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "The shadow runs over the pinned externals; the diff (§4) compares the shadow pass against\nthe pinned pass — never against the live engine. The readout labels its provenance\n(\"baseline as of the run\"). The base session continues advancing underneath; that is\ncorrect and visible, not a race."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-2-2",
      "data-slug": "22-what-holds-today-vs-what-this-adds",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-2-2"
      }), "2.2 What holds today vs what this adds"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Load-bearing properties that hold ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "today"
      }), " (anchors, §9):"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Build-from-sources is the engine's only constructor."
        }), " The worker protocol's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "build"
        }), "\nmessage takes raw source text; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "AsyncEngine"
        }), " re-sends builds routinely (watchdog\nrestarts). A patched build is a normal build."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "A pass is already a full recompute."
        }), " The engine clears results and evaluates every\ncell in topo order on every pass; there is no incremental machinery a shadow bypasses."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The evaluator is starved by construction."
        }), " A worksheet compartment is endowed with\nthe stdlib and nothing else; a second compartment holds the same nothing. (Authority —\nsee §5 for the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "integrity"
        }), " caveat on the in-process path, which is a different axis.)"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Externals flow host→engine only."
        }), " Nothing evaluator-side originates an external;\nparams, fixtures, and feed buffers are all host-written. (The ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "snapshot accessor"
        }), " is\nnew — must-establish, §9 — because feed buffers live only inside the engine, not in the\nsession's record.)"]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["New machinery (must-establish, §9): ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "AsyncEngine.settledSnapshot()"
      }), " (§2.1); session\nretention of worksheet sources, the loaded document, and the runtime-feed list (the\nshadow's cross-reference validation needs the same universe the base validation used,\n§3.2); ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "WorkerTransport.dispose()"
      }), " — terminate without respawn (today's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "restart()"
      }), "\nalways spawns a successor; a discarded shadow must be able to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "stop"
      }), ")."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-2-3",
      "data-slug": "23-cost-honestly-wif-r7",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-2-3"
      }), "2.3 Cost, honestly (WIF-R7)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["A shadow Run is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "more"
      }), " than a params-slider drag: build (fresh compartments per\nworksheet + graph/cycle analysis) ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "+"
      }), " full pass ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "+"
      }), " test suite, where a drag is a\npass only. Its browser-side latency is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "unmeasured"
      }), " — the Caldera document runs today\nonly in the Node test harness, so no interactivity claim is made here. What is claimed:\nthe machinery is exercised over the real Caldera document in the harness (G-WIF-9), the\nexplicit-Run design keeps the unmeasured cost behind a deliberate action, and a browser\nmeasurement is booked as a status-doc item before any continuous-evaluation mode (Q1) is\nconsidered."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-3",
      "data-slug": "3-source-patching-normative-shipped-2026-08-27",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-3"
      }), "3. Source patching  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative — shipped 2026-08-27)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-3-1",
      "data-slug": "31-formula-variants-unique-occurrence-splice",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-3-1"
      }), "3.1 Formula variants — unique-occurrence splice"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["A variant for cell ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ws.name"
      }), " is applied by replacing the cell's current formula text in\nworksheet ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ws"
      }), "'s source with the variant text. The descriptor's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "formulaSource"
      }), " is the\nformula function's own source (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "Function.prototype.toString"
      }), ", preserved by SES), taken\nfrom a compartment evaluation of the worksheet body after a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "line-anchored"
      }), " transform\n(§3.3), so for well-formed sheets it is verbatim file text."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "The splice is defensive, with typed errors (never a silent wrong patch):"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "formula-not-found"
        }), " — the descriptor text does not occur in the sheet source (the\nfidelity assumption broke; refuse rather than guess);"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "formula-ambiguous"
        }), " — the text occurs more than once. This covers ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "both"
        }), " the\nidentical-formula case ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "and"
        }), " the more common substring case: a short formula (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "() => 1"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "(i) => i.x"
        }), ") occurring inside a longer one counts as multiple occurrences and is\nrefused. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "This makes the v1 mechanism honestly partial"
        }), ": cells with very short or\nduplicated formula text will refuse to splice, with the refusal shown as such in the\npanel. The clean successor — a build-time source span on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "CellDescriptor"
        }), " — is booked\n(§10) and becomes v1.5 the moment refusal rates annoy in practice."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.em, {
        children: ["(R3-427 landed, 2026-08-28 — the successor is built: the worker build computes each\ncell's and test's declaration-block span on the raw source (the same line-anchored\nmatches as the §3.3 transform), the splice patches ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "within the varied cell's own\nblock"
        }), " — so cross-cell identical and substring formulas no longer refuse — and the\ntyped refusals remain only for the degenerate within-block cases. Span-less descriptors\nkeep the unique-occurrence fallback above, so a mixed old/new engine is never a silent\nwrong patch. Spans also surface as ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "file:line"
        }), " on the inspector's formula and test rows;\nthe clickable open-at-line rides the navigator work and the editor line-hint delta.)"]
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The patched source then goes through the ordinary build path; a variant that no longer\nparses or breaks the graph surfaces as the ordinary ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "build-error"
      }), " / diagnostics, shown in\nthe panel."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-3-2",
      "data-slug": "32-the-scratch-module-and-cross-reference-validation-wif-r5",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-3-2"
      }), "3.2 The scratch module, and cross-reference validation (WIF-R5)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The scratch buffer is added to the build's sources under a reserved worksheet name\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "scratch"
      }), "). If the document already declares a worksheet named ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "scratch"
      }), ", the pad is\ndisabled with a visible message (collision is refused, not merged; Q2 books the durable\nfix). Scratch cells may declare inputs on any durable cell or external; durable sources\nare patched only by §3.1 splices of existing formulas, so scratch cells cannot become\ninputs of durable cells."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "The shadow build re-runs external cross-reference validation."
      }), " Engine builds do not\nvalidate external references — that runs once at document load — and an absent external\nresolves to a silent ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "null"
      }), ". A scratch cell's typo'd ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "fixtures.exec_sumary"
      }), " must not\nevaluate to confident nonsense: the shadow path re-runs ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "validateExternalReferences"
      }), "\nover the shadow engine's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "externalReferences()"
      }), ", against the same universe the base\nvalidation used (document feeds/fixtures/params + runtime feeds + template widget\nparams), and surfaces the diagnostics in the panel (G-WIF-10)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-3-3",
      "data-slug": "33-the-transform-corrected-wif-r4",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-3-3"
      }), "3.3 The transform, corrected (WIF-R4)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The worksheet-to-compartment transform strips the stdlib import line and rewrites\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "export const"
      }), " to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "const"
      }), ". As shipped, both regexes are ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "unanchored over the whole\nbody"
      }), ": the token sequence ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "export const"
      }), " inside a formula's string literal or comment\nwould be rewritten (making ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "formula.toString()"
      }), " diverge from file text) and would\nsimultaneously collect a phantom export name that breaks the build's register call. This\nspec requires the regexes be ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "line-anchored"
      }), " (a prerequisite fix, G-WIF-1a); the\nresidual — a string literal containing a newline followed by ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "export const"
      }), " — is\naccepted and named, since such a sheet already breaks the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "base"
      }), " build today, before any\nshadow machinery is involved."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-3-4",
      "data-slug": "34-what-patching-cannot-do",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-3-4"
      }), "3.4 What patching cannot do"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["No patch may touch the manifest, fixtures, feeds, templates, or params declarations —\nsources in, sources out, worksheets only. (Externals counterfactuals — \"what if this\nfixture leaf were X\" — already have a live path via ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "engine.update"
      }), " and the paramRefs\nmachinery; widening ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "that"
      }), " into a full externals-override UI is out of scope here.)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-4",
      "data-slug": "4-diffing-the-counterfactual-normative-shipped-2026-08-27",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-4"
      }), "4. Diffing the counterfactual  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative — shipped 2026-08-27)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "The what-if result is computed, not narrated:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Dependents closure"
        }), " — a pure reverse-edge walk over ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "CellDescriptor.deps"
        }), " from the\nvaried cell(s), bounding which cells ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "can"
        }), " have changed. (Wildcard inputs are expanded\ninto ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "deps"
        }), " at build time, so the closure sees them; variants cannot change declared\ninputs (§1.1), so the closure is identical over base and shadow descriptors.)"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Value diff"
        }), " — per cell, compare the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "pinned baseline pass"
        }), "'s published\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "contentKey"
        }), " (a canonical collision-free serialization, not a lossy digest) against\nthe shadow pass's; changed / unchanged / newly-erroring / no-longer-erroring."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Verdict diff"
        }), " — run the shadow engine's test suite (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "runTests"
        }), ") and report subjects\nwhose verdict flipped (pass→fail is the headline; fail→pass is shown too), against the\nbase verdicts already computed by the review surface."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Cells outside the closure are asserted unchanged ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "and"
      }), " verified by the same contentKey\ncomparison in tests (G-WIF-4): topo-order full recompute means an out-of-closure change\nis an engine bug, and the gate would catch it."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The scratch surface reuses the same machinery with an empty variants map. For\npurely-additive scratch runs the readout is the scratch cells' own\nvalues/errors/verdicts, plus two invariants: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "no durable cell's value changed"
      }), "\n(G-WIF-5) and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "no durable subject's verdict changed"
      }), " — guaranteed structurally by\nrefusing scratch tests on durable subjects (§1.2, G-WIF-6a)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-5",
      "data-slug": "5-security-integrity-normative-shipped-2026-08-27",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-5"
      }), "5. Security & integrity  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative — shipped 2026-08-27)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["This spec adds ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "no new capability, principal, service, realm, or gate"
      }), ". It does add\nthe first surface that invites ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "typed-in arbitrary formula code"
      }), ", so the confinement\nstory must be stated per transport, not averaged (WIF-R1/R2):"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Authority (both transports): starved."
        }), " Shadow evaluation runs in SES compartments\nendowed with the stdlib and nothing else — no ambient fetch/DOM/process, same as the\nbase evaluator. A user typing a variant into their own session runs code with less\nreach than the devtools console they already hold; Class-A-bounded, browser-parity."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Isolation/integrity — real-worker transport (local dev, and the platform once it\nevaluates ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "import.meta.url"
          }), "):"]
        }), " the shadow worker is a separate ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "lockdown()"
        }), "-ed realm;\nintrinsics poisoning and runaway divergence are contained and terminable\n(watchdog → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "terminate()"
        }), "), and the base session is structurally unreachable."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Isolation/integrity — in-process fallback (the platform today): weaker, and this\nspec says so."
        }), " The in-process worker runs in the app's own realm, which is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "not"
        }), "\nlocked down; compartment starvation still bounds ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "reachability"
        }), " (no ambient\nauthority), but shared mutable primordials mean a hostile/buggy variant can poison\nintrinsics shared with the base engine and the app UI, and ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["a synchronously divergent\nvariant (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "while(true)"
          }), ") cannot be interrupted at all"]
        }), " — the watchdog is a main-thread\ntimer that never fires; the tab wedges until the browser kills it, base session\nincluded. The same holds for the shadow ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "runTests"
        }), " path. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "These are named residuals,\nnot claims-away"
        }), ": the deep-copied baseline (§2.1) closes the shared-input-mutation\nhole, which is the deliberately-closable part; the intrinsics and divergence residuals\nare accepted for v1 (the base engine already runs document formulas on this path —\nthe marginal exposure is that what-if invites ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "unreviewed typed"
        }), " code) and\nself-resolve when the platform gains real workers. Booked alternative — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "lockdown()"
        }), "\non the main realm — is Q7, with its app-breakage cost to be measured, not assumed."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Ephemeral by construction — RS-10 untouched."
        }), " Shadow results live in the panel and\ndie with it. No persist path, no freeze path, no file write anywhere in this spec; the\nwrite-laundering surface (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "REPORTING_SPREADSHEET_SPEC §5"
        }), ") gains no new entry point.\n(A user hand-copying a number they can already see is browser-parity, not a write\npath.) The one day a \"keep this\" affordance exists (§7), it must route through the\nsame freeze/contribute gates as any other write — that affordance is out of scope\nprecisely so this spec cannot be its back door."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Tiering flows through unchanged."
        }), " The shadow pass folds tiers exactly as the base\npass does; a shadow value derived from an M3 feed buffer displays as such. Nothing is\npersisted, so no refloor question arises."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Shared-document viewers."
        }), " In a future shared context, the what-if panel lets a\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "viewer"
        }), " run their own formula text over data the report already discloses to them\n(Class A) — the authority they already hold; it discloses nothing new and writes\nnothing. The panel MUST still be absent when the inspector itself is absent for a\ngiven deployment shape (Q4)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-6",
      "data-slug": "6-lifecycle-the-editor-first-boundary-normative-shipped-2026-08-27",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-6"
      }), "6. Lifecycle & the editor-first boundary  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative — shipped 2026-08-27)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "One shadow context per surface instance, reused across runs."
        }), " Each Run re-", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "build"
        }), "s\nthe same shadow context (build replaces worker state); ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "dispose()"
        }), " on\nunmount/discard. Run is disabled while a shadow pass is in flight (explicit runs; no\nsupersession machinery needed)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The platform failure mode is stated in §5, not here-hedged:"
        }), " on the in-process\nfallback a divergent variant is unrecoverable. The panel shows a running state; that\nis a UX affordance, not a containment claim."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Why not the platform editor"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "EDITOR_FIRST_EDITING_SPEC"
        }), " §5's stated-reason rule):\nthe thing being edited ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "is not a file"
        }), " — a variant is a counterfactual that must\nnever touch the document, and the scratch buffer is an unsaved evaluation context\nwhose ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "content"
        }), " the user can copy out at will (§1.4). The platform editor's contract\nis editing ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "files in mounts"
        }), "; routing an explicitly-never-persisted buffer through it\nwould create the very write path this design exists to avoid. The moment either\nsurface grows a persistence affordance, that affordance delegates to the platform\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "edit-file"
        }), " / contribute) — recorded here as the standing boundary."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-7",
      "data-slug": "7-out-of-scope-the-honest-remainder-normative-the-booked-remainder-nothing-here-shipped",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-7"
      }), "7. Out of scope — the honest remainder  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative — the booked remainder, nothing here shipped)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Apply / promote."
        }), " Writing a variant back to its worksheet, or a scratch cell into a\ndurable sheet, requires a writable mount and the platform editing path\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "edit-file"
        }), "/contribute) plus the freeze-gate questions of RS-10. Not in this spec;\nthe UI shows ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "why"
        }), " (read-only document) rather than a dead button."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "R-6's other halves."
        }), " The tabular multi-cell inspector and range-select-sum remain\nopen; this spec closes only the scratch/what-if slice."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Externals-override UI"
        }), " (\"what if this fixture were…\") beyond the existing params\npath (§3.4)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Scratch-text persistence across reloads"
        }), " — booked, not designed: any later\npersistence must survive the platform's opaque-origin storage constraints (access can\nthrow; wrap and degrade) and is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "text-only"
        }), " (never results)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Multi-variant compare / sweep UI"
        }), " (vary a cell across N values): the engine cost\nmodel supports it (N shadow passes), but the surface is future work (Q3)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-8",
      "data-slug": "8-gates-normative-the-falsifiable-exit-tests-shipped-2026-08-27",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-8"
      }), "8. Gates  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative — the falsifiable exit tests, shipped 2026-08-27)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Gate"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Test"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "G-WIF-1"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Splicing a variant into a sheet where the formula text occurs exactly once produces a source that builds; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "formula-not-found"
            }), " (zero occurrences) and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "formula-ambiguous"
            }), " (identical-formula ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "and"
            }), " substring cases) are returned as typed errors — never a silent wrong patch."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "G-WIF-1a"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["The worksheet transform is line-anchored: a formula containing the string literal ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "\"export const x\""
            }), " builds, round-trips ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "formulaSource"
            }), " verbatim, and registers no phantom export."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "G-WIF-2"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["A shadow run over a variant changes the varied cell and its dependents in the shadow pass while the ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
              children: ["base engine's published results are ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                children: "contentKey"
              }), "-identical"]
            }), " before/after. On the in-process transport this is additionally exercised with a variant that ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
              children: "mutates its input rows"
            }), " — the deep-copied baseline (§2.1) keeps the base session's next pass unaffected."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "G-WIF-3"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "settledSnapshot()"
            }), " awaits quiescence and returns a coherent pair: a params write issued before the call is reflected in both the externals and the pass; feed-buffer keys present in the engine are present in the snapshot; the returned externals are copies (mutating them does not affect the engine)."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "G-WIF-4"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["The value diff reports exactly the cells whose ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "contentKey"
            }), " differs between the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "pinned"
            }), " baseline pass and the shadow pass; every changed cell is inside the dependents closure of the varied cell(s). Run under concurrent base-engine updates (a ticking feed), a no-variant shadow over the pinned pair reports ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "zero"
            }), " deltas."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "G-WIF-5"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["A scratch-only run leaves every durable cell's shadow value ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "contentKey"
            }), "-equal to the pinned baseline; scratch cells evaluate, error, and test like durable cells."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "G-WIF-6"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Shadow test verdicts: a variant that breaks a subject's test flips that subject's verdict in the shadow suite; the base session's verdicts are untouched."
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "G-WIF-6a"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["A scratch test cell whose ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "subject"
            }), " is a durable cell is refused at shadow-build time with a typed error; durable subjects' verdicts cannot be contaminated by scratch content."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "G-WIF-7"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "dispose()"
            }), " on the shadow transport terminates the worker (real-Worker case) / drops the in-process worker, and a disposed transport delivers no further messages."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "G-WIF-8"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["A worksheet named ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "scratch"
            }), " in the document disables the scratch pad with a visible message (no silent merge, no crash)."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "G-WIF-9"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["A shadow run over the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Caldera case-study document"
            }), " (variant on a model cell) completes in the harness: the varied cell and its dependents change; cells outside the closure match the Python-oracle values unchanged. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
              children: "(Node harness only — no browser-latency claim; the browser measurement is a status-doc item.)"
            })]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "G-WIF-10"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "A scratch cell referencing an undeclared external (typo'd fixture, undeclared feed) produces a visible cross-reference diagnostic in the shadow result — never a silent null-derived value."
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "G-WIF-11"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Scratch/variant buffer text survives closing and reopening its panel; Clear on a non-empty buffer requires a confirm step."
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-9",
      "data-slug": "9-load-bearing-assumptions-code-anchors-required",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-9"
      }), "9. Load-bearing assumptions & code anchors  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(required)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "depends-on-today-verified-against-code",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "depends-on-today-verified-against-code"
      }), "Depends-on-today (verified against code)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Assumption"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Anchor (repo-relative file)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Token (grep-stable)"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "The build message carries raw worksheet sources; rebuild is routine"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/engine/worker/protocol.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "type: 'build'; sources: Record<string, string>"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "The engine re-sends builds after watchdog restarts (build is re-entrant)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/engine/asyncEngine.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "#sendBuild(this.#sources)"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "A pass clears results and re-evaluates every cell (full recompute)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/engine/asyncEngine.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "this.#results = new Map()"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Published results carry a canonical content key usable for diffing"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/engine/hash.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "canonical serialization"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["The worksheet transform rewrites the stdlib import and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "export const"
            }), " (unanchored today — §3.3's prerequisite fix)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/engine/compartment.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "EXPORT_CONST"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "The descriptor's formula text is the function's own source"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/engine/worker/engineWorker.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "formula.toString()"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Dependency edges (wildcards pre-expanded) are serialized on the descriptor"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/engine/graph.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "for (const dep of cells) if (dep !== ctx.id) ctx.deps.add(dep)"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "The suite runs worker-side over host-resolved contexts"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/engine/asyncEngine.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "runTests"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "An absent external resolves to a silent null (why §3.2 must re-validate)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/engine/resolve.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "ext?.value ?? null"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "External cross-reference validation runs at load, not at build"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/app/reportSession.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "xrefDiagnostics"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Params writes flow through ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "engine.update"
            }), " (the live counterfactual precedent)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/app/reportSession.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "session.engine.update"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "The platform falls back to the in-process transport (main-thread posture, §5)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/app/reportSession.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "inMemoryTransport"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "The in-process worker cannot interrupt synchronous divergence"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/engine/workerTransport.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "cannot interrupt a synchronous divergence"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "lockdown()"
            }), " runs only in the real-worker entry"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/entry/engine.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "scope.lockdown"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "The compartment endows stdlib + nothing (starvation)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/engine/compartment.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "new Compartment({ ...stdlib, __register: register })"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Feed buffers are engine-internal externals (why the snapshot must come from the engine)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/engine/resolve.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "FEED_BUFFER_PREFIX"
            })
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "must-establish-new-invariants-the-implementation-creates",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "must-establish-new-invariants-the-implementation-creates"
      }), "Must-establish (new invariants the implementation creates)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "New invariant"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Proven by (gate test)"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "AsyncEngine.settledSnapshot()"
            }), " — quiescent, coherent, deep-copied ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "(pass, externals)"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-WIF-3"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "The session retains sources + loaded document + runtime feeds for patching and re-validation"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-WIF-2, G-WIF-10"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "WorkerTransport.dispose()"
            }), " terminates without respawn"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-WIF-7"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Splice refuses zero/ambiguous occurrence with typed errors"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-WIF-1"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "The transform is line-anchored"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-WIF-1a"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Shadow runs never mutate base-session published state or inputs"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-WIF-2, G-WIF-6"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Scratch runs are additive over durable state — values and verdicts"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-WIF-5, G-WIF-6a"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Shadow builds re-run external cross-reference validation"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-WIF-10"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Buffer text is session-scoped; Clear is confirmed"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-WIF-11"
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-10",
      "data-slug": "10-decisions-rejected-alternatives-normative-dont-relitigate",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-10"
      }), "10. Decisions & rejected alternatives  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative — don’t relitigate)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "A second engine instance, not an in-place mode of the base engine."
        }), " The base\nengine's single-slot supersession and published-state maps are the report's source of\ntruth; threading \"counterfactual\" through them risks exactly the substitute-user-bytes\nclass of bug the editor spec's §6 exists to prevent. Two instances make the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "host-side\nstate"
        }), " separation structural; realm-level isolation is transport-dependent and stated\nper-transport in §5 (WIF-R1 — the earlier \"structural isolation\" phrasing overclaimed).\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "evaluateCounterfactual()"
        }), " mode flag on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "AsyncEngine"
        }), "; save/restore of\npublished maps around a counterfactual pass."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Diff against a pinned settled baseline, never the live engine (WIF-R3)."
        }), " Under a\nticking feed, \"base at shadow-completion time\" produces spurious deltas; a pinned\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "(pass, externals)"
        }), " pair makes the diff a pure function of one epoch. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), "\ndiffing against ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "engine.snapshot()"
        }), " at completion time (partial mid-pass maps, missed\npending externals)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Unique-occurrence text splice, not source spans, for v1 — with the refusal rate\nnamed (WIF-R4)."
        }), " The splice needs zero protocol/worker changes and fails closed\n(typed refusal on zero/ambiguous occurrence, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "including substrings of longer\nformulas"
        }), "). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Booked as the successor, promotion criterion stated:"
        }), " a build-time ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "span"
        }), "\non ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "CellDescriptor"
        }), " becomes the mechanism when refusals annoy in practice."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Scratch is a worksheet, not a REPL."
        }), " One buffer with full worksheet grammar reuses\nthe entire engine/verdict pipeline and keeps the product's named-cell semantics; a\nbespoke expression REPL would be a second evaluation grammar to secure and document.\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " per-probe input boxes; an expression-only evaluator."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Scratch tests may not target durable subjects in v1 (WIF-R6)."
        }), " Refusal is the only\noption that keeps \"scratch is additive\" true for verdicts as well as values without a\ndiff-labeling scheme; the probe-a-durable-cell feature is Q5, to be designed with its\nlabeling, not slipped in. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " silent merge into durable suites (verdict\ncontamination indistinguishable from a real regression)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Explicit Run, not evaluate-on-keystroke."
        }), " A shadow run is build + pass + suite with\nunmeasured browser latency, main-thread on the platform today. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " debounced\ncontinuous evaluation (revisit under Q1 when real workers land and a measurement\nexists)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Ephemeral results; session-scoped text; no apply (WIF-R9)."
        }), " Persistence routes\nexist (edit-file, contribute) and gates exist (RS-10/freeze); wiring them is separate\nwork with its own review. But user-typed ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "text"
        }), " is not a security artifact: it\nsurvives panel close, is copyable, and Clear confirms. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " an apply button\ngated on writability in v1; discard-on-close of typed source."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The panel lives in the inspector / workbook panel, not the report."
        }), " Value 2:\nrun-mode chrome stays clean; the two doors that already mean \"I'm looking behind the\nreport\" are the right doors. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " on-pixel \"try a variant\" affordances in the\nreport view (V3's inspection affordance may ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "open"
        }), " the inspector, which then offers\nwhat-if)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-11",
      "data-slug": "11-adversarial-review-record",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-11"
      }), "11. Adversarial review  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(record)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Pass 1 (2026-08-27, fresh-agent), WIF-R1…WIF-R11 — all folded into this revision:"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "WIF-R1 [BLOCKER]"
        }), " \"structural isolation\" false on the in-process path (shared\nunhardened realm, shared input references) → §5 rewritten per-transport; §2.1\ndeep-copied baseline; G-WIF-2 extended with the input-mutation case; §10 decision\nreworded."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "WIF-R2 [BLOCKER]"
        }), " watchdog cannot interrupt synchronous divergence in-process →\n§5 states the true failure mode as a named residual; the \"budget trips\" claim struck."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "WIF-R3 [BLOCKER]"
        }), " no pinned diff baseline under live feeds; mid-pass/pending-slot\nsnapshot hazards → §2.1 ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "settledSnapshot()"
        }), "; G-WIF-3/G-WIF-4 rewritten (ticking-feed\ngate)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "WIF-R4 [MAJOR]"
        }), " transform \"prefixes\" overclaim + substring-ambiguity omitted →\n§3.3 line-anchoring prerequisite (G-WIF-1a); §3.1 substring case + honest availability\nstatement; anchor row corrected."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "WIF-R5 [MAJOR]"
        }), " scratch externals bypass xref validation (silent nulls) → §3.2\nshadow re-validation; G-WIF-10."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "WIF-R6 [MAJOR]"
        }), " scratch tests can flip durable subjects' verdicts → §1.2/§4\nrefusal rule; G-WIF-6a; Q5 books the feature properly."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "WIF-R7 [MAJOR]"
        }), " false \"Caldera live demo / per drag / proves interactive\" claims;\nunderstated cost → §0/§2.3 corrected (build+pass+suite, unmeasured, Node-harness gate\nG-WIF-9 only)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "WIF-R8 [MAJOR]"
        }), " mobile absent (the RB-4 repeat) → §1.5."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "WIF-R9 [MAJOR]"
        }), " discard-on-close data-loss trap → §1.4 (session-scoped text,\nconfirmed Clear, copy affordance); G-WIF-11."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "WIF-R10 [MINOR]"
        }), " wiki-style ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "[[#sec-N]]"
        }), " anchors unused in this repo → converted\nto plain §N."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "WIF-R11 [MINOR]"
        }), " the externals-snapshot bullet filed under \"holds today\" → §2.2\nreworded to the property that holds; snapshot lives only in must-establish."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-12",
      "data-slug": "12-open-questions",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-12"
      }), "12. Open questions"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Q1"
        }), " — When the platform learns ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "import.meta.url"
        }), " (real workers in-platform), should\nthe shadow default to continuous evaluation? Requires the browser measurement §2.3\nbooks."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Q2"
        }), " — The ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "scratch"
        }), " name collision: rename affordance, or make ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "scratch"
        }), " a reserved\nworksheet name the loader refuses in documents?"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Q3"
        }), " — Multi-variant sweeps (N shadow passes): surface design; whether results\nmemoize across variants sharing a topo-order prefix."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Q4"
        }), " — In a shared/composite deployment, does the what-if panel need a\ndeployment-shape switch, or is inspector-presence the right proxy (§5)?"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Q5"
        }), " — Ad-hoc scratch tests on durable subjects: design the verdict-diff labeling\n(\"new scratch test\" vs \"flipped by variant\") that would make this safe to allow."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Q6"
        }), " — The structured (no-code) mobile variant flow (§1.5's booked value-8 debt)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Q7"
        }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "lockdown()"
        }), " on the main realm for the in-process path: measure what it\nbreaks (React, vendored libs) before deciding."]
      }), "\n"]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/specs/WHATIF_SHADOW_EVALUATION_SPEC.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJibG9ja3F1b3RlIiwiY29kZSIsImVtIiwiaDEiLCJoMiIsImgzIiwiaHIiLCJsaSIsInAiLCJwcmUiLCJzdHJvbmciLCJ0YWJsZSIsInRib2R5IiwidGQiLCJ0aCIsInRoZWFkIiwidHIiLCJ1bCIsIl9wcm92aWRlQ29tcG9uZW50cyIsImNvbXBvbmVudHMiLCJIZWFkaW5nQW5jaG9yIiwiX21pc3NpbmdNZHhSZWZlcmVuY2UiLCJqc3hzIiwiRnJhZ21lbnQiLCJjaGlsZHJlbiIsImlkIiwianN4IiwiTURYQ29udGVudCIsIndyYXBwZXIiLCJNRFhMYXlvdXQiLCJfYyIsImNvbXBvbmVudCIsInBsYWNlIiwiRXJyb3IiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJXSEFUSUZfU0hBRE9XX0VWQUxVQVRJT05fU1BFQy5tZCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKkBqc3hSdW50aW1lIGF1dG9tYXRpYyovXG4vKkBqc3hJbXBvcnRTb3VyY2UgcmVhY3QqL1xuaW1wb3J0IHt1c2VNRFhDb21wb25lbnRzIGFzIF9wcm92aWRlQ29tcG9uZW50c30gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrL01EWFByb3ZpZGVyXCI7XG5mdW5jdGlvbiBfY3JlYXRlTWR4Q29udGVudChwcm9wcykge1xuICBjb25zdCBfY29tcG9uZW50cyA9IHtcbiAgICBibG9ja3F1b3RlOiBcImJsb2NrcXVvdGVcIixcbiAgICBjb2RlOiBcImNvZGVcIixcbiAgICBlbTogXCJlbVwiLFxuICAgIGgxOiBcImgxXCIsXG4gICAgaDI6IFwiaDJcIixcbiAgICBoMzogXCJoM1wiLFxuICAgIGhyOiBcImhyXCIsXG4gICAgbGk6IFwibGlcIixcbiAgICBwOiBcInBcIixcbiAgICBwcmU6IFwicHJlXCIsXG4gICAgc3Ryb25nOiBcInN0cm9uZ1wiLFxuICAgIHRhYmxlOiBcInRhYmxlXCIsXG4gICAgdGJvZHk6IFwidGJvZHlcIixcbiAgICB0ZDogXCJ0ZFwiLFxuICAgIHRoOiBcInRoXCIsXG4gICAgdGhlYWQ6IFwidGhlYWRcIixcbiAgICB0cjogXCJ0clwiLFxuICAgIHVsOiBcInVsXCIsXG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9LCB7SGVhZGluZ0FuY2hvcn0gPSBfY29tcG9uZW50cztcbiAgaWYgKCFIZWFkaW5nQW5jaG9yKSBfbWlzc2luZ01keFJlZmVyZW5jZShcIkhlYWRpbmdBbmNob3JcIiwgdHJ1ZSk7XG4gIHJldHVybiA8PjxfY29tcG9uZW50cy5oMSBpZD1cInJlY2tvbmVyLXdoYXQtaWYtc2hhZG93LWV2YWx1YXRpb24tYW4tZXBoZW1lcmFsLWNvdW50ZXJmYWN0dWFsLXdvcmstYXJlYS1vdmVyLXRoZS1zdGFydmVkLWVuZ2luZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwicmVja29uZXItd2hhdC1pZi1zaGFkb3ctZXZhbHVhdGlvbi1hbi1lcGhlbWVyYWwtY291bnRlcmZhY3R1YWwtd29yay1hcmVhLW92ZXItdGhlLXN0YXJ2ZWQtZW5naW5lXCIgLz57XCJSZWNrb25lciBXaGF0LWlmIFNoYWRvdyBFdmFsdWF0aW9uIOKAlCBhbiBlcGhlbWVyYWwgY291bnRlcmZhY3R1YWwgd29yayBhcmVhIG92ZXIgdGhlIHN0YXJ2ZWQgZW5naW5lXCJ9PC9fY29tcG9uZW50cy5oMT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlN0YXR1czpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgaW1wbGVtZW50ZWQgYXQgdGhlIGRlbGl2ZXJhYmxlIGxldmVsIOKAlCB0aGUgUi02IHdvcmstYXJlYSBzbGljZSAoUjMtMzk14oCmUjMtMzk3KTtcXG5vbmUgYWR2ZXJzYXJpYWwgcGFzcyBmb2xkZWQgKMKnMTEsIFdJRi1SMeKAplIxMSk7IHJlc2lkdWFscyBsaXZlIGluIHRoZSBzdGF0dXMgZG9jLiDCt1xcblwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiVXBkYXRlZDpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgMjAyNi0wOC0yN1wifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuZW0+e1wiKEltcGxlbWVudGF0aW9uIG5vdGUsIDIwMjYtMDgtMjcg4oCUIHRoZSBkZXNpZ24gYmVsb3cgd2FzIGF1dGhvcmVkLCBhZHZlcnNhcmlhbGx5IHJldmlld2VkLFxcbmFuZCB0aGVuIGJ1aWx0IGluIHRoZSBzYW1lIHBhc3M6IMKnwqcx4oCTNiBhbmQgdGhlIMKnOCBnYXRlcyBhcmUgbm9ybWF0aXZlIGFuZCBzaGlwcGVkOyDCpzcgYW5kXFxuwqcxMiByZW1haW4gdGhlIGhvbmVzdCByZW1haW5kZXIuIFRoZSBlYXJsaWVyIFwifTxfY29tcG9uZW50cy5jb2RlPntcInByb3Bvc2FsXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBtYXJrZXJzIG9uIGJ1aWx0IHNlY3Rpb25zIHdlcmVcXG5yZWNvbmNpbGVkIGluIHRoaXMgZWRpdCwgcGVyIHNwZWNfc3R5bGUgXFxcImtlZXAgc3RhdHVzIGhvbmVzdFxcXCIuKVwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVGhlIHNpbmdsZSBpbXBsZW1lbnRhdGlvbi1zdGF0dXMgc291cmNlIGZvciB0aGlzIHNwZWMgaXNcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJkb2NzL3N0YXR1cy9XSEFUSUZfU0hBRE9XX0VWQUxVQVRJT05fU1RBVFVTLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgd2hlcmUgdGhpcyBkb2N1bWVudCBhbmQgdGhhdCBvbmVcXG5kaXNhZ3JlZSwgdGhlIHN0YXR1cyBkb2MgZ292ZXJucy5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUmVhZHMgZmlyc3Q6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkFSQ0hJVEVDVFVSRV9QTEFOLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDCpzQuMS/CpzQuMiAodGhlIHdvcmtlci1iYWNrZWQgZW5naW5lLCB3YXRjaGRvZyxcXG5zdXBlcnNlc3Npb24pLCDCpzcuMSAodGhlIHNjb3BlIGN1dCB0aGlzIHNwZWMgcmUtb3BlbnMgYSBzbGljZSBvZiksIHJpc2sgUi02O1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcIlJFUE9SVElOR19TUFJFQURTSEVFVF9TUEVDLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDCpzMuMiAodGhlIHN0YXJ2ZWQgZXZhbHVhdG9yKSwgwqc1IChlcGhlbWVyYWwgY29tcHV0ZSAvXFxuUlMtMTAgd3JpdGUtbGF1bmRlcmluZyk7IFwifTxfY29tcG9uZW50cy5jb2RlPntcIkVOR0lORV9JTkZPUk1BVElPTl9GTE9XX1NQRUMubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICh0aWVyaW5nIHRocm91Z2ggdGhlIGVuZ2luZSk7XFxudGhlIHBsYXRmb3JtJ3MgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRURJVE9SX0ZJUlNUX0VESVRJTkdfU1BFQy5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKHdoeSB0aGlzIGlzIFwifTxfY29tcG9uZW50cy5lbT57XCJub3RcIn08L19jb21wb25lbnRzLmVtPntcIiBhbiBpbi1hcHAgZWRpdG9yXFxudmlvbGF0aW9uIOKAlCBpdHMgwqc1IHN0YXRlZC1yZWFzb24gcnVsZSwgc2F0aXNmaWVkIGluIMKnNiBiZWxvdykuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTwvX2NvbXBvbmVudHMuYmxvY2txdW90ZT57XCJcXG5cIn08X2NvbXBvbmVudHMuaHIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtMFwiIGRhdGEtc2x1Zz1cIjAtY2hhcnRlci10aGUtZ2FwLWFuZC10aGUtc2hhcGUtb2YtdGhlLWZpeC1ub3JtYXRpdmUtc2hpcHBlZC0yMDI2LTA4LTI3XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtMFwiIC8+e1wiMC4gQ2hhcnRlciDigJQgdGhlIGdhcCBhbmQgdGhlIHNoYXBlIG9mIHRoZSBmaXggIFwifTxfY29tcG9uZW50cy5lbT57XCIobm9ybWF0aXZlIOKAlCBzaGlwcGVkIDIwMjYtMDgtMjcpXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5jb2RlPntcIkFSQ0hJVEVDVFVSRV9QTEFOIMKnNy4xXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBzY29wZWQgdjEgdG8gXCJ9PF9jb21wb25lbnRzLmVtPntcInJlcG9ydC1hdXRob3JpbmcgYW5kIGRlbGVnYXRpb24sIG5vdCBhZC1ob2NcXG5leHBsb3JhdGlvblwifTwvX2NvbXBvbmVudHMuZW0+e1wiLCBhbmQgcmlzayBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlItNlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBib29rZWQgdGhlIGNvbnNlcXVlbmNlIGhvbmVzdGx5OiB0aGUgc29sbyBhbmFseXN0IGhhcyBub1xcbnBsYWNlIHRvIG1lc3MgYXJvdW5kIOKAlCBubyBzY3JhdGNoIGNlbGwsIG5vIFxcXCJ3aGF0IGhhcHBlbnMgaWYgSSBjaGFuZ2UgdGhpcyxcXFwiIG5vdGhpbmdcXG5iZXR3ZWVuIFwifTxfY29tcG9uZW50cy5lbT57XCJkcmFnZ2luZyBhIGRlY2xhcmVkIHNsaWRlclwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGFuZCBcIn08X2NvbXBvbmVudHMuZW0+e1wiZm9ya2luZyB0aGUgcmVwb3NpdG9yeVwifTwvX2NvbXBvbmVudHMuZW0+e1wiLiBUaGUgQ2FsZGVyYSBjYXNlIHN0dWR5XFxubWFrZXMgdGhlIGdhcCBjb25jcmV0ZTogdGhlIGRvY3VtZW50IGl0c2VsZiBjb250YWlucyBhIDI1LXJ1biBzZW5zaXRpdml0eSBncmlkIGFuZCBhXFxuZ29hbC1zZWVrIOKAlCByZWlmaWVkIGV4cGxvcmF0aW9uIOKAlCBidXQgbm90aGluZyBpbiB0aGUgcHJvZHVjdCBsZXRzIGFuIGF1dGhvciBhc2sgb25lXFxuY291bnRlcmZhY3R1YWwgcXVlc3Rpb24gb2YgdGhlaXIgb3duIHdpdGhvdXQgZWRpdGluZyByZXBvc2l0b3J5IGZpbGVzLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGlzIHNwZWMgZmlsbHMgdGhlIFwifTxfY29tcG9uZW50cy5lbT57XCJlbmdpbmUtY2hlYXBcIn08L19jb21wb25lbnRzLmVtPntcIiBzbGljZSBvZiBSLTYgd2l0aCBvbmUgbWVjaGFuaXNtIGFuZCB0d28gc3VyZmFjZXM6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQSBzaGFkb3cgc2Vzc2lvblwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIjogYSBzZWNvbmQsIGVxdWFsbHktc3RhcnZlZCBlbmdpbmUgaW5zdGFuY2UgYnVpbHQgb3ZlciBcIn08X2NvbXBvbmVudHMuZW0+e1wicGF0Y2hlZFwifTwvX2NvbXBvbmVudHMuZW0+e1wiXFxud29ya3NoZWV0IHNvdXJjZXMgYW5kIGEgcGlubmVkIHNuYXBzaG90IG9mIHRoZSBsaXZlIHNlc3Npb24ncyBzdGF0ZSwgd2hvc2UgcmVzdWx0cyBhcmVcXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInJlbmRlcmVkLCBkaWZmZWQgYWdhaW5zdCB0aGF0IHBpbm5lZCBiYXNlbGluZSwgYW5kIGRpc2NhcmRlZCDigJQgbmV2ZXIgcGVyc2lzdGVkXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08L19jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIHR3byBzdXJmYWNlcyBhcmUgdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wid2hhdC1pZiBwYW5lbFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAocGVydHVyYiBhbiBleGlzdGluZyBjZWxsJ3MgZm9ybXVsYSBmcm9tIHRoZVxcbnZhbHVlIGluc3BlY3RvciBhbmQgd2F0Y2ggdGhlIGRvd25zdHJlYW0gbmVpZ2hib3Job29kIHNoaWZ0KSBhbmQgdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wic2NyYXRjaCBwYWRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKGFuXFxudW5zYXZlZCwgaW4tbWVtb3J5IHdvcmtzaGVldCDigJQgdGhlIG5vdGVib29rIHdvcmsgYXJlYSkuIEJvdGggYXJlIHN0cmljdGx5IG9wdC1pbiBjaHJvbWVcXG5pbnNpZGUgZXhpc3RpbmcgcmV2aWV3IHN1cmZhY2VzOyB0aGUgcmVwb3J0IGEgdmlld2VyIG9wZW5zIGlzIHVudG91Y2hlZCAodmFsdWUgMikuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiV2hhdCB0aGlzIHNwZWMgZGVsaWJlcmF0ZWx5IGlzIG5vdDpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgaXQgaXMgbm90IHRoZSBhdXRob3JpbmcvcGVyc2lzdGVuY2UgcGF0aCAobm8gZmlsZVxcbndyaXRlcywgbm8gY29udHJpYnV0ZSBmbG93LCBubyBcXFwiYXBwbHlcXFwiIOKAlCDCpzcpLCBub3QgdGhlIFItNiBcIn08X2NvbXBvbmVudHMuZW0+e1widGFidWxhciBtdWx0aS1jZWxsIGluc3BlY3RvclwifTwvX2NvbXBvbmVudHMuZW0+e1wiXFxub3IgXCJ9PF9jb21wb25lbnRzLmVtPntcInJhbmdlLXNlbGVjdC1zdW1cIn08L19jb21wb25lbnRzLmVtPntcIiAoc3RpbGwgb3BlbiksIGFuZCBub3QgYSBuZXcgcmVhbG0sIGNhcGFiaWxpdHksIHByaW5jaXBhbCwgc2VydmljZSxcXG5vciBnYXRlICjCpzUpLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaHIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtMVwiIGRhdGEtc2x1Zz1cIjEtcHJvZHVjdC1zdXJmYWNlLW5vcm1hdGl2ZS1zaGlwcGVkLTIwMjYtMDgtMjdcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy0xXCIgLz57XCIxLiBQcm9kdWN0IHN1cmZhY2UgIFwifTxfY29tcG9uZW50cy5lbT57XCIobm9ybWF0aXZlIOKAlCBzaGlwcGVkIDIwMjYtMDgtMjcpXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cInNlYy0xLTFcIiBkYXRhLXNsdWc9XCIxMS10aGUtd2hhdC1pZi1wYW5lbC1pbnNwZWN0b3JcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy0xLTFcIiAvPntcIjEuMSBUaGUgd2hhdC1pZiBwYW5lbCAoaW5zcGVjdG9yKVwifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIHZhbHVlIGluc3BlY3RvciAocmV2aWV3IHN1cmZhY2Ugc2xpY2UgMikgZ2FpbnMgYSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlxcXCJXaGF0IGlmXFxcIlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBzZWN0aW9uIGZvciB0aGVcXG5pbnNwZWN0ZWQgY2VsbDpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJhbiBlZGl0YWJsZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInZhcmlhbnRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgb2YgdGhlIGNlbGwncyBmb3JtdWxhIHNvdXJjZSwgcHJlLWZpbGxlZCB3aXRoIHRoZSBjdXJyZW50XFxuZm9ybXVsYSAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQ2VsbERlc2NyaXB0b3IuZm9ybXVsYVNvdXJjZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLiBBIHZhcmlhbnQgcmVwbGFjZXMgdGhlIGZvcm11bGEgXCJ9PF9jb21wb25lbnRzLmVtPntcImZ1bmN0aW9uXFxub25seVwifTwvX2NvbXBvbmVudHMuZW0+e1wiOyB0aGUgY2VsbCdzIGRlY2xhcmVkIFwifTxfY29tcG9uZW50cy5jb2RlPntcImlucHV0c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYXJlIG5vdCBlZGl0YWJsZSBpbiB2MSwgc28gdmFyaWFudCBmb3JtdWxhcyBjb21wdXRlXFxub3ZlciB0aGUgc2FtZSBkZWNsYXJlZCBpbnB1dHMgKGFuIHVuZGVjbGFyZWQgbmFtZSBpcyBhbiBvcmRpbmFyeSBldmFsdWF0aW9uIGVycm9yKTtcIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiUnVuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGFjdGlvbjogcGlucyBhIGNvaGVyZW50IGJhc2VsaW5lICjCpzIuMSksIGJ1aWxkcyB0aGUgc2hhZG93IHNlc3Npb24gd2l0aCB0aGVcXG52YXJpYW50IHNwbGljZWQgaW4gKMKnMyksIHJ1bnMgaXQgb3ZlciB0aGUgcGlubmVkIGV4dGVybmFscywgYW5kIHJ1bnMgdGhlIHNoYWRvdyB0ZXN0XFxuc3VpdGU7XCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiYSByZXN1bHQgcmVhZG91dDogdGhlIGNlbGwncyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImJhc2VsaW5lIOKGkiBzaGFkb3cgdmFsdWVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIsIHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImRvd25zdHJlYW0gZGVsdGEgbGlzdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIlxcbihldmVyeSBkZXBlbmRlbnQgY2VsbCB3aG9zZSB2YWx1ZSBjaGFuZ2VkLCBzY29wZWQgYnkgdGhlIGRlcGVuZGVudHMgY2xvc3VyZSDigJQgwqc0KSwgYW55XFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJuZXcgZXJyb3JzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBhbmQgdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1widGVzdCB2ZXJkaWN0cyB0aGF0IGZsaXBwZWRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCI7XCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiYSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIkRpc2NhcmRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYWN0aW9uOiBzaGFkb3cgcmVzdWx0cyBhcmUgZHJvcHBlZC4gVmFyaWFudCBcIn08X2NvbXBvbmVudHMuZW0+e1widGV4dFwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGlzIHNlc3Npb24tc2NvcGVkXFxuc3RhdGUgKMKnMS40KSwgc28gY2xvc2luZyB0aGUgaW5zcGVjdG9yIGRvZXMgbm90IHNpbGVudGx5IGRlc3Ryb3kgYW4gZWRpdGVkIHZhcmlhbnQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5lbT57XCIoQW1lbmRtZW50LCAyMDI2LTA4LTI4IOKAlCBjb2xsYXBzZWQgYnkgZGVmYXVsdC4gVGhlIHYxIGFsd2F5cy1vcGVuIHBhbmVsIHJlbmRlcmVkIHRoZVxcbnNhbWUgZm9ybXVsYSB0d2ljZSBpbiBhZGphY2VudCBib3hlcyDigJQgdGhlIGluc3BlY3RvcidzIHJlYWQtb25seSBGT1JNVUxBIHJvdyAocHJvdmVuYW5jZSlcXG5hbmQgdGhlIHByZS1maWxsZWQgdmFyaWFudCBlZGl0b3Ig4oCUIGEgdmlzdWFsIHJlZHVuZGFuY3kgdXNlciBmZWVkYmFjayBmbGFnZ2VkIG9uIGZpcnN0XFxuY29udGFjdC4gVGhlIHNlY3Rpb24gbm93IHN0YXJ0cyBjb2xsYXBzZWQ7IHRoZSBGT1JNVUxBIHJvdyBjYXJyaWVzIGEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wid2hhdCBpZiDihpJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxuYWZmb3JkYW5jZSB0aGF0IG9wZW5zIGl0IChwcmUtZmlsbGVkIGF0IHRoYXQgbW9tZW50LCBhcyBiZWZvcmUpLCBhbmQgaXQgcmUtb3BlbnMgb24gaXRzXFxub3duIHdoZW5ldmVyIHRoZSBjZWxsJ3MgdmFyaWFudCB0ZXh0IGRpZmZlcnMgZnJvbSB0aGUgZG9jdW1lbnQgZm9ybXVsYSwgc28gdHlwZWQgc291cmNlXFxubmV2ZXIgaGlkZXMgaXRzZWxmLiBUaGUgcHJlLWZpbGwgZGVjaXNpb24gYW5kIGV2ZXJ5dGhpbmcgZWxzZSBpbiB0aGlzIHNlY3Rpb24gc3RhbmQ7IHRoZVxcbnJlYWQtb25seSBGT1JNVUxBIHJvdyBkZWxpYmVyYXRlbHkgc3RheXMg4oCUIGxldHRpbmcgdGhlIGVkaXRvciBkb3VibGUgYXMgdGhlIGRpc3BsYXkgd291bGRcXG5tYWtlIHRoZSBkb2N1bWVudCdzIGZvcm11bGEgbG9vayBlZGl0YWJsZSwgYmx1cnJpbmcgdGhlIHJlYWwtdnMtY291bnRlcmZhY3R1YWwgbGluZSB0aGlzXFxuZGVzaWduIGtlZXBzIHNoYXJwLilcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgcGFuZWwgaXMgZXhwbGljaXQtcnVuIChubyBldmFsdWF0ZS1vbi1rZXlzdHJva2UpOiBhIHJ1biBpcyBhIGZ1bGwgc2hhZG93IGJ1aWxkICsgcGFzc1wifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcInN1aXRlLCBpdHMgYnJvd3Nlci1zaWRlIGNvc3QgaXMgdW5tZWFzdXJlZCwgYW5kIG9uIHRoZSBwbGF0Zm9ybSB0b2RheSBpdCBzaGFyZXMgdGhlXFxubWFpbiB0aHJlYWQgKMKnNikg4oCUIGFuIGV4cGxpY2l0IGFjdGlvbiBrZWVwcyB0aGF0IGNvc3QgbGVnaWJsZSBhbmQgaW50ZXJydXB0aWJsZS1ieS1jaG9pY2UuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cInNlYy0xLTJcIiBkYXRhLXNsdWc9XCIxMi10aGUtc2NyYXRjaC1wYWQtd29ya2Jvb2stcGFuZWxcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy0xLTJcIiAvPntcIjEuMiBUaGUgc2NyYXRjaCBwYWQgKHdvcmtib29rIHBhbmVsKVwifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIHdvcmtib29rIHBhbmVsIGdhaW5zIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJcXFwiU2NyYXRjaFxcXCJcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgc2VjdGlvbjogb25lIGluLW1lbW9yeSB3b3Jrc2hlZXQgc291cmNlIGJ1ZmZlclxcbnRoZSBhdXRob3IgZWRpdHMgZnJlZWx5IChjZWxscywgdGVzdHMsIGNyb3NzLXNoZWV0IGlucHV0cyDigJQgdGhlIGZ1bGwgd29ya3NoZWV0IGdyYW1tYXIpLFxcbnBsdXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJSdW5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIuIFJ1bm5pbmcgYnVpbGRzIHRoZSBzaGFkb3cgc2Vzc2lvbiB3aXRoIHRoZSBzY3JhdGNoIG1vZHVsZSBhZGRlZCBhcyBhbiBleHRyYVxcbndvcmtzaGVldCAowqczLjIpIGFuZCBkaXNwbGF5cyB0aGUgc2NyYXRjaCBjZWxscyBhcyBvcmRpbmFyeSB3b3JrYm9vayBjYXJkcyDigJQgdmFsdWUsXFxuZXJyb3JzLCB2ZXJkaWN0cyDigJQgaW4gdGhlIHNhbWUgdmlzdWFsIGxhbmd1YWdlIGFzIGR1cmFibGUgY2VsbHMsIGJ1dCB2aXNpYmx5IG1hcmtlZFxcblwifTxfY29tcG9uZW50cy5lbT57XCJzY3JhdGNoICh1bnNhdmVkKVwifTwvX2NvbXBvbmVudHMuZW0+e1wiLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJTY3JhdGNoIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1widGVzdCBjZWxscyBtdXN0IHRhcmdldCBzY3JhdGNoIHN1YmplY3RzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiOiBhIHNjcmF0Y2ggdGVzdCB3aG9zZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzdWJqZWN0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpcyBhXFxuZHVyYWJsZSBjZWxsIGlzIHJlZnVzZWQgYXQgc2hhZG93LWJ1aWxkIHRpbWUgd2l0aCBhIHZpc2libGUgbWVzc2FnZSAowqc0LCBXSUYtUjYpLiBQcm9iaW5nXFxuZHVyYWJsZSBjZWxscyB3aXRoIGFkLWhvYyB0ZXN0cyBpcyBib29rZWQgYXMgYW4gb3BlbiBxdWVzdGlvbiAoUTUpLCBub3Qgc2lsZW50bHkgYWxsb3dlZC5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIHNjcmF0Y2ggcGFkIGlzIHRoZSBSLTYgXFxcImVwaGVtZXJhbCBzY3JhdGNoIHN1cmZhY2VcXFwiOiBhIG5vdGVib29rLWxpa2UgcGxhY2UgdG8gdHJ5XFxudGhpbmdzIHdob3NlIHNlbWFudGljcyBhcmUgZXhhY3RseSB3b3Jrc2hlZXQgc2VtYW50aWNzIChuYW1lZCwgdHlwZWQsIHRlc3RhYmxlIGNlbGxzKVxcbndpdGggdGhlIGNlcmVtb255IHJlbW92ZWQuIFByb21vdGlvbiB0byBhIGR1cmFibGUgd29ya3NoZWV0IGZpbGUgaXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJvdXQgb2Ygc2NvcGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKMKnNykuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cInNlYy0xLTNcIiBkYXRhLXNsdWc9XCIxMy1ydW4tbW9kZS1maXJzdC12YWx1ZS0yXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtMS0zXCIgLz57XCIxLjMgUnVuLW1vZGUtZmlyc3QgKHZhbHVlIDIpXCJ9PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJOZWl0aGVyIHN1cmZhY2UgYWRkcyBhIHBpeGVsIHRvIHRoZSByZXBvcnQgdmlldy4gQm90aCBsaXZlIGJlaGluZCB0aGUgZXhpc3Rpbmcgb3B0LWluXFxuZG9vcnMgKHRoZSBpbnNwZWN0b3I7IHRoZSB3b3JrYm9vayBwYW5lbCksIHdoaWNoIGEgcHVyZSB2aWV3ZXIgbmV2ZXIgb3BlbnMuIEEgc3RhdGljXFxucmVwb3J0IG9wZW5zIGV4YWN0bHkgYXMgYmVmb3JlIOKAlCB6ZXJvIHByb21wdHMsIHplcm8gY2hyb21lLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCJzZWMtMS00XCIgZGF0YS1zbHVnPVwiMTQtZXBoZW1lcmFsLXJlc3VsdHMtZHVyYWJsZS1lbm91Z2gtdGV4dC13aWYtcjlcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy0xLTRcIiAvPntcIjEuNCBFcGhlbWVyYWwgcmVzdWx0cywgZHVyYWJsZS1lbm91Z2ggdGV4dCAoV0lGLVI5KVwifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiRXBoZW1lcmFsIFwifTxfY29tcG9uZW50cy5lbT57XCJyZXN1bHRzXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgYXJlIGEgc2VjdXJpdHkgcG9zdHVyZTsgZXBoZW1lcmFsIFwifTxfY29tcG9uZW50cy5lbT57XCJ1c2VyLXR5cGVkIHNvdXJjZSB3aXRoIHplcm9cXG5yZWNvdmVyeVwifTwvX2NvbXBvbmVudHMuZW0+e1wiIHdvdWxkIGJlIHVuaGFuZGxlZCBkYXRhIGxvc3MuIHYxIHJlcXVpcmVtZW50czpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkJ1ZmZlciB0ZXh0IG91dGxpdmVzIHBhbmVsIHZpc2liaWxpdHkuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRoZSBzY3JhdGNoIGJ1ZmZlciBhbmQgcGVyLWNlbGwgdmFyaWFudFxcbnRleHRzIGFyZSBzZXNzaW9uLXNjb3BlZCBhcHAgc3RhdGU6IGNsb3NpbmcvcmVvcGVuaW5nIHRoZSB3b3JrYm9vayBwYW5lbCBvciBpbnNwZWN0b3JcXG5kb2VzIG5vdCBjbGVhciB0aGVtLiBBIHBhZ2UgcmVsb2FkIGRvZXMgKHBlcnNpc3RlbmNlIGlzIGJvb2tlZCwgwqc3LCB3aXRoIHRoZVxcbm9wYXF1ZS1vcmlnaW4gc3RvcmFnZSBjb25zdHJhaW50IG5hbWVkKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkV4cGxpY2l0IENsZWFyLCBjb25maXJtZWQuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRoZSBvbmx5IHdheSB0byBlbXB0eSBhIG5vbi1lbXB0eSBzY3JhdGNoIGJ1ZmZlciBpcyBhblxcbmV4cGxpY2l0IENsZWFyIGFjdGlvbiB3aXRoIGEgY29uZmlybSBzdGVwLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQ29weSBhZmZvcmRhbmNlLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGUgc2NyYXRjaCBwYWQgb2ZmZXJzIGNvcHktdG8tY2xpcGJvYXJkIGZvciB0aGUgYnVmZmVyIHRleHRcXG4oZ3VhcmRlZCDigJQgY2xpcGJvYXJkIGFjY2VzcyBjYW4gYmUgYWJzZW50IGluIHRoZSBzYW5kYm94ZWQgaWZyYW1lOyB0aGUgYnVmZmVyIGlzIGFcXG5wbGFpbiB0ZXh0YXJlYSwgc28gbWFudWFsIHNlbGVjdC1jb3B5IGFsd2F5cyB3b3JrcyBhcyB0aGUgZmxvb3IpLiBDb3B5aW5nIHRleHQgdG91Y2hlc1xcbm5vIG1vdW50IGFuZCBubyBSUy0xMCBnYXRlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCJzZWMtMS01XCIgZGF0YS1zbHVnPVwiMTUtbW9iaWxlLXZhbHVlLTgtd2lmLXI4XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtMS01XCIgLz57XCIxLjUgTW9iaWxlICh2YWx1ZSA4OyBXSUYtUjgpXCJ9PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJIb25lc3RseSBzY29wZWQgcmF0aGVyIHRoYW4gb21pdHRlZDogYm90aCBzdXJmYWNlcyByaWRlIHBhbmVscyB0aGF0IGFscmVhZHkgc3RhY2tcXG5mdWxsLXdpZHRoIG9uIHNtYWxsIHNjcmVlbnMuIHYxIHJlcXVpcmVzOiB0aGUgdmFyaWFudC9zY3JhdGNoIHRleHRhcmVhcyByZW5kZXIgYXQgYVxcbmZvbnQtc2l6ZSB0aGF0IGF2b2lkcyBmb2N1cy16b29tLCBSdW4vRGlzY2FyZC9Db3B5IGFyZSByZWFjaGFibGUgd2l0aG91dCBkaXNtaXNzaW5nIHRoZVxcbmtleWJvYXJkLCBhbmQgdGhlIGRlbHRhIGxpc3QgcmVhZHMgYXMgYSBzdGFja2VkIGxpc3QgKG5vIHdpZGUgbWF0cml4KS4gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJIYW5kLXR5cGluZ1xcbmZvcm11bGEgY29kZSBvbiBhIHBob25lIGlzIG5vdCB0aGUgdGFyZ2V0IGludGVyYWN0aW9uIGFuZCB0aGlzIHNwZWMgZG9lcyBub3QgY2xhaW0gaXRcXG5pc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIjogdGhlIG1vYmlsZS1jb21wbGV0ZSBjb3VudGVyZmFjdHVhbCBwYXRoIHJlbWFpbnMgdGhlIHJlcG9ydCdzIHBhcmFtcyB3aWRnZXRzOyB0aGVcXG53aGF0LWlmIGFuZCBzY3JhdGNoIHN1cmZhY2VzIG9uIG1vYmlsZSBhcmUgZnVuY3Rpb25hbC1idXQta2V5Ym9hcmQtYm91bmQsIGFuZCBhXFxuc3RydWN0dXJlZCAobm8tY29kZSkgbW9iaWxlIHZhcmlhbnQgZmxvdyBpcyBib29rZWQgdmFsdWUtOCBkZWJ0IChRNiksIG93bmVkIGJ5IHRoaXMgc3BlYy5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmhyIC8+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTJcIiBkYXRhLXNsdWc9XCIyLXRoZS1zaGFkb3ctc2Vzc2lvbi1ub3JtYXRpdmUtc2hpcHBlZC0yMDI2LTA4LTI3XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtMlwiIC8+e1wiMi4gVGhlIHNoYWRvdyBzZXNzaW9uICBcIn08X2NvbXBvbmVudHMuZW0+e1wiKG5vcm1hdGl2ZSDigJQgc2hpcHBlZCAyMDI2LTA4LTI3KVwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJBIHNoYWRvdyBzZXNzaW9uIGlzIGEgc2Vjb25kIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkFzeW5jRW5naW5lXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBvdmVyIGl0cyBvd24gdHJhbnNwb3J0LCBidWlsdCBmcm9tIHRoZVxcbmRvY3VtZW50J3Mgd29ya3NoZWV0IHNvdXJjZXMgd2l0aCBhIHBhdGNoIGFwcGxpZWQsIHJ1biBvbmNlIG92ZXIgYSBwaW5uZWQgYmFzZWxpbmU6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wcmU+PF9jb21wb25lbnRzLmNvZGU+e1wic2hhZG93UnVuKHtcXG4gIHNvdXJjZXMsICAgICAgICAgICAgLy8gdGhlIGxpdmUgc2Vzc2lvbidzIHJldGFpbmVkIHdvcmtzaGVldCBzb3VyY2VzXFxuICBwYXRjaCwgICAgICAgICAgICAgIC8vIHsgdmFyaWFudHM6IE1hcDxjZWxsSWQsIGZvcm11bGFTb3VyY2U+LCBzY3JhdGNoPzogc3RyaW5nIH1cXG4gIGJhc2VsaW5lLCAgICAgICAgICAgLy8gdGhlIHBpbm5lZCB7IHBhc3MsIGV4dGVybmFscyB9IHBhaXIgKMKnMi4xKVxcbiAgdHJhbnNwb3J0LCAgICAgICAgICAvLyBpdHMgb3duIHRyYW5zcG9ydCDigJQgbmV2ZXIgdGhlIGJhc2UgZW5naW5lJ3NcXG59KSDihpIgeyBwYXNzLCB2ZXJkaWN0cywgZGlmZiwgZGlhZ25vc3RpY3MgfVxcblwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnByZT57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCJzZWMtMi0xXCIgZGF0YS1zbHVnPVwiMjEtdGhlLXBpbm5lZC1iYXNlbGluZS13aWYtcjNcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy0yLTFcIiAvPntcIjIuMSBUaGUgcGlubmVkIGJhc2VsaW5lIChXSUYtUjMpXCJ9PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJVbmRlciBhIGxpdmUgZmVlZCB0aGUgYmFzZSBzZXNzaW9uIGlzIGEgbW92aW5nIHRhcmdldDogdGhlIGZlZWQgcnVudGltZSBkcml2ZXNcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJlbmdpbmUudXBkYXRlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjb250aW51b3VzbHksIGEgcGFzcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImNsZWFyc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBwdWJsaXNoZWQgcmVzdWx0cyBhdCBpdHMgc3RhcnQsIGFuZCBhXFxuanVzdC13cml0dGVuIGV4dGVybmFsIGNhbiBzaXQgaW4gdGhlIHBlbmRpbmcgc2xvdCBiZWZvcmUgYW55IHBhc3MgYWRvcHRzIGl0LiBEaWZmaW5nIGFcXG5zaGFkb3cgcGFzcyBhZ2FpbnN0IFxcXCJ0aGUgbGl2ZSBlbmdpbmUsIHdoZW5ldmVyIHRoZSBzaGFkb3cgaGFwcGVucyB0byBmaW5pc2hcXFwiIHdvdWxkXFxucHJvZHVjZSBzcHVyaW91cyBkZWx0YXMgb24gZXZlcnkgZmVlZC1kZXJpdmVkIGNlbGwuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlNvIFJ1biBiZWdpbnMgYnkgY2FwdHVyaW5nIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJjb2hlcmVudCBzZXR0bGVkIGJhc2VsaW5lXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGZyb20gdGhlIGJhc2UgZW5naW5lIOKAlCBhIG5ld1xcbmVuZ2luZSBhY2Nlc3NvciAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic2V0dGxlZFNuYXBzaG90KClcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBtdXN0LWVzdGFibGlzaCDCpzkpIHRoYXQ6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiYXdhaXRzIHF1aWVzY2VuY2UgKG5vIHBhc3MgaW4gZmxpZ2h0LCBubyBwZW5kaW5nIGV4dGVybmFscyDigJQgdGhlIHNpbmdsZS1zbG90XFxuc3VwZXJzZXNzaW9uIGxvb3AgbWFrZXMgdGhpcyBhIGJvdW5kZWQgd2FpdCk7XCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wicmV0dXJucyB0aGUgc2V0dGxlZCBwYXNzIChyZXN1bHRzICsgZXJyb3JzKSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImFuZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB0aGUgZXh0ZXJuYWxzIHRoYXQgcHJvZHVjZWQgaXQg4oCUXFxucGFyYW1zLCBmaXh0dXJlcywgXCJ9PF9jb21wb25lbnRzLmVtPntcImFuZCByZXRhaW5lZCBmZWVkIGJ1ZmZlcnNcIn08L19jb21wb25lbnRzLmVtPntcIiDigJQgYXMgb25lIHBhaXI7XCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJkZWVwLWNvcGllcyB0aGUgZXh0ZXJuYWxzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChzdHJ1Y3R1cmVkIGNsb25lOyB0aGUgdmFsdWVzIGFyZSBzdHJ1Y3R1cmVkLWNsb25lLXNhZmVcXG5ieSBjb25zdHJ1Y3Rpb24g4oCUIHRoZXkgY3Jvc3MgdGhlIHdvcmtlciBib3VuZGFyeSkuIFRoaXMgaXMgbm90IGh5Z2llbmUgYnV0IGFcXG5jb3JyZWN0bmVzcy9pbnRlZ3JpdHkgcmVxdWlyZW1lbnQgb24gdGhlIGluLXByb2Nlc3MgcGF0aDogd2l0aG91dCBpdCB0aGUgc2hhZG93J3NcXG5jb21wYXJ0bWVudHMgc2hhcmUgbGl2ZSBSb3cvYXJyYXkgcmVmZXJlbmNlcyB3aXRoIHRoZSBiYXNlIGVuZ2luZSwgYW5kIGEgdmFyaWFudFxcbm11dGF0aW5nIGFuIGlucHV0IHJvdyBjb3JydXB0cyB0aGUgYmFzZSBzZXNzaW9uJ3MgbmV4dCBwYXNzIChXSUYtUjEpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgc2hhZG93IHJ1bnMgb3ZlciB0aGUgcGlubmVkIGV4dGVybmFsczsgdGhlIGRpZmYgKMKnNCkgY29tcGFyZXMgdGhlIHNoYWRvdyBwYXNzIGFnYWluc3RcXG50aGUgcGlubmVkIHBhc3Mg4oCUIG5ldmVyIGFnYWluc3QgdGhlIGxpdmUgZW5naW5lLiBUaGUgcmVhZG91dCBsYWJlbHMgaXRzIHByb3ZlbmFuY2VcXG4oXFxcImJhc2VsaW5lIGFzIG9mIHRoZSBydW5cXFwiKS4gVGhlIGJhc2Ugc2Vzc2lvbiBjb250aW51ZXMgYWR2YW5jaW5nIHVuZGVybmVhdGg7IHRoYXQgaXNcXG5jb3JyZWN0IGFuZCB2aXNpYmxlLCBub3QgYSByYWNlLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCJzZWMtMi0yXCIgZGF0YS1zbHVnPVwiMjItd2hhdC1ob2xkcy10b2RheS12cy13aGF0LXRoaXMtYWRkc1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTItMlwiIC8+e1wiMi4yIFdoYXQgaG9sZHMgdG9kYXkgdnMgd2hhdCB0aGlzIGFkZHNcIn08L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkxvYWQtYmVhcmluZyBwcm9wZXJ0aWVzIHRoYXQgaG9sZCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInRvZGF5XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChhbmNob3JzLCDCpzkpOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQnVpbGQtZnJvbS1zb3VyY2VzIGlzIHRoZSBlbmdpbmUncyBvbmx5IGNvbnN0cnVjdG9yLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGUgd29ya2VyIHByb3RvY29sJ3MgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYnVpbGRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxubWVzc2FnZSB0YWtlcyByYXcgc291cmNlIHRleHQ7IFwifTxfY29tcG9uZW50cy5jb2RlPntcIkFzeW5jRW5naW5lXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiByZS1zZW5kcyBidWlsZHMgcm91dGluZWx5ICh3YXRjaGRvZ1xcbnJlc3RhcnRzKS4gQSBwYXRjaGVkIGJ1aWxkIGlzIGEgbm9ybWFsIGJ1aWxkLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQSBwYXNzIGlzIGFscmVhZHkgYSBmdWxsIHJlY29tcHV0ZS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhlIGVuZ2luZSBjbGVhcnMgcmVzdWx0cyBhbmQgZXZhbHVhdGVzIGV2ZXJ5XFxuY2VsbCBpbiB0b3BvIG9yZGVyIG9uIGV2ZXJ5IHBhc3M7IHRoZXJlIGlzIG5vIGluY3JlbWVudGFsIG1hY2hpbmVyeSBhIHNoYWRvdyBieXBhc3Nlcy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlRoZSBldmFsdWF0b3IgaXMgc3RhcnZlZCBieSBjb25zdHJ1Y3Rpb24uXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIEEgd29ya3NoZWV0IGNvbXBhcnRtZW50IGlzIGVuZG93ZWQgd2l0aFxcbnRoZSBzdGRsaWIgYW5kIG5vdGhpbmcgZWxzZTsgYSBzZWNvbmQgY29tcGFydG1lbnQgaG9sZHMgdGhlIHNhbWUgbm90aGluZy4gKEF1dGhvcml0eSDigJRcXG5zZWUgwqc1IGZvciB0aGUgXCJ9PF9jb21wb25lbnRzLmVtPntcImludGVncml0eVwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGNhdmVhdCBvbiB0aGUgaW4tcHJvY2VzcyBwYXRoLCB3aGljaCBpcyBhIGRpZmZlcmVudCBheGlzLilcIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkV4dGVybmFscyBmbG93IGhvc3TihpJlbmdpbmUgb25seS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgTm90aGluZyBldmFsdWF0b3Itc2lkZSBvcmlnaW5hdGVzIGFuIGV4dGVybmFsO1xcbnBhcmFtcywgZml4dHVyZXMsIGFuZCBmZWVkIGJ1ZmZlcnMgYXJlIGFsbCBob3N0LXdyaXR0ZW4uIChUaGUgXCJ9PF9jb21wb25lbnRzLmVtPntcInNuYXBzaG90IGFjY2Vzc29yXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgaXNcXG5uZXcg4oCUIG11c3QtZXN0YWJsaXNoLCDCpzkg4oCUIGJlY2F1c2UgZmVlZCBidWZmZXJzIGxpdmUgb25seSBpbnNpZGUgdGhlIGVuZ2luZSwgbm90IGluIHRoZVxcbnNlc3Npb24ncyByZWNvcmQuKVwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJOZXcgbWFjaGluZXJ5IChtdXN0LWVzdGFibGlzaCwgwqc5KTogXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQXN5bmNFbmdpbmUuc2V0dGxlZFNuYXBzaG90KClcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICjCpzIuMSk7IHNlc3Npb25cXG5yZXRlbnRpb24gb2Ygd29ya3NoZWV0IHNvdXJjZXMsIHRoZSBsb2FkZWQgZG9jdW1lbnQsIGFuZCB0aGUgcnVudGltZS1mZWVkIGxpc3QgKHRoZVxcbnNoYWRvdydzIGNyb3NzLXJlZmVyZW5jZSB2YWxpZGF0aW9uIG5lZWRzIHRoZSBzYW1lIHVuaXZlcnNlIHRoZSBiYXNlIHZhbGlkYXRpb24gdXNlZCxcXG7CpzMuMik7IFwifTxfY29tcG9uZW50cy5jb2RlPntcIldvcmtlclRyYW5zcG9ydC5kaXNwb3NlKClcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCB0ZXJtaW5hdGUgd2l0aG91dCByZXNwYXduICh0b2RheSdzIFwifTxfY29tcG9uZW50cy5jb2RlPntcInJlc3RhcnQoKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG5hbHdheXMgc3Bhd25zIGEgc3VjY2Vzc29yOyBhIGRpc2NhcmRlZCBzaGFkb3cgbXVzdCBiZSBhYmxlIHRvIFwifTxfY29tcG9uZW50cy5lbT57XCJzdG9wXCJ9PC9fY29tcG9uZW50cy5lbT57XCIpLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCJzZWMtMi0zXCIgZGF0YS1zbHVnPVwiMjMtY29zdC1ob25lc3RseS13aWYtcjdcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy0yLTNcIiAvPntcIjIuMyBDb3N0LCBob25lc3RseSAoV0lGLVI3KVwifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiQSBzaGFkb3cgUnVuIGlzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibW9yZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB0aGFuIGEgcGFyYW1zLXNsaWRlciBkcmFnOiBidWlsZCAoZnJlc2ggY29tcGFydG1lbnRzIHBlclxcbndvcmtzaGVldCArIGdyYXBoL2N5Y2xlIGFuYWx5c2lzKSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIitcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgZnVsbCBwYXNzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiK1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB0ZXN0IHN1aXRlLCB3aGVyZSBhIGRyYWcgaXMgYVxcbnBhc3Mgb25seS4gSXRzIGJyb3dzZXItc2lkZSBsYXRlbmN5IGlzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1widW5tZWFzdXJlZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgdGhlIENhbGRlcmEgZG9jdW1lbnQgcnVucyB0b2RheVxcbm9ubHkgaW4gdGhlIE5vZGUgdGVzdCBoYXJuZXNzLCBzbyBubyBpbnRlcmFjdGl2aXR5IGNsYWltIGlzIG1hZGUgaGVyZS4gV2hhdCBpcyBjbGFpbWVkOlxcbnRoZSBtYWNoaW5lcnkgaXMgZXhlcmNpc2VkIG92ZXIgdGhlIHJlYWwgQ2FsZGVyYSBkb2N1bWVudCBpbiB0aGUgaGFybmVzcyAoRy1XSUYtOSksIHRoZVxcbmV4cGxpY2l0LVJ1biBkZXNpZ24ga2VlcHMgdGhlIHVubWVhc3VyZWQgY29zdCBiZWhpbmQgYSBkZWxpYmVyYXRlIGFjdGlvbiwgYW5kIGEgYnJvd3Nlclxcbm1lYXN1cmVtZW50IGlzIGJvb2tlZCBhcyBhIHN0YXR1cy1kb2MgaXRlbSBiZWZvcmUgYW55IGNvbnRpbnVvdXMtZXZhbHVhdGlvbiBtb2RlIChRMSkgaXNcXG5jb25zaWRlcmVkLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaHIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtM1wiIGRhdGEtc2x1Zz1cIjMtc291cmNlLXBhdGNoaW5nLW5vcm1hdGl2ZS1zaGlwcGVkLTIwMjYtMDgtMjdcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy0zXCIgLz57XCIzLiBTb3VyY2UgcGF0Y2hpbmcgIFwifTxfY29tcG9uZW50cy5lbT57XCIobm9ybWF0aXZlIOKAlCBzaGlwcGVkIDIwMjYtMDgtMjcpXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cInNlYy0zLTFcIiBkYXRhLXNsdWc9XCIzMS1mb3JtdWxhLXZhcmlhbnRzLXVuaXF1ZS1vY2N1cnJlbmNlLXNwbGljZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTMtMVwiIC8+e1wiMy4xIEZvcm11bGEgdmFyaWFudHMg4oCUIHVuaXF1ZS1vY2N1cnJlbmNlIHNwbGljZVwifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiQSB2YXJpYW50IGZvciBjZWxsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIndzLm5hbWVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGlzIGFwcGxpZWQgYnkgcmVwbGFjaW5nIHRoZSBjZWxsJ3MgY3VycmVudCBmb3JtdWxhIHRleHQgaW5cXG53b3Jrc2hlZXQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wid3NcIn08L19jb21wb25lbnRzLmNvZGU+e1wiJ3Mgc291cmNlIHdpdGggdGhlIHZhcmlhbnQgdGV4dC4gVGhlIGRlc2NyaXB0b3IncyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmb3JtdWxhU291cmNlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpcyB0aGVcXG5mb3JtdWxhIGZ1bmN0aW9uJ3Mgb3duIHNvdXJjZSAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRnVuY3Rpb24ucHJvdG90eXBlLnRvU3RyaW5nXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgcHJlc2VydmVkIGJ5IFNFUyksIHRha2VuXFxuZnJvbSBhIGNvbXBhcnRtZW50IGV2YWx1YXRpb24gb2YgdGhlIHdvcmtzaGVldCBib2R5IGFmdGVyIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJsaW5lLWFuY2hvcmVkXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHRyYW5zZm9ybVxcbijCpzMuMyksIHNvIGZvciB3ZWxsLWZvcm1lZCBzaGVldHMgaXQgaXMgdmVyYmF0aW0gZmlsZSB0ZXh0LlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgc3BsaWNlIGlzIGRlZmVuc2l2ZSwgd2l0aCB0eXBlZCBlcnJvcnMgKG5ldmVyIGEgc2lsZW50IHdyb25nIHBhdGNoKTpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuY29kZT57XCJmb3JtdWxhLW5vdC1mb3VuZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIHRoZSBkZXNjcmlwdG9yIHRleHQgZG9lcyBub3Qgb2NjdXIgaW4gdGhlIHNoZWV0IHNvdXJjZSAodGhlXFxuZmlkZWxpdHkgYXNzdW1wdGlvbiBicm9rZTsgcmVmdXNlIHJhdGhlciB0aGFuIGd1ZXNzKTtcIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuY29kZT57XCJmb3JtdWxhLWFtYmlndW91c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIHRoZSB0ZXh0IG9jY3VycyBtb3JlIHRoYW4gb25jZS4gVGhpcyBjb3ZlcnMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJib3RoXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHRoZVxcbmlkZW50aWNhbC1mb3JtdWxhIGNhc2UgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJhbmRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdGhlIG1vcmUgY29tbW9uIHN1YnN0cmluZyBjYXNlOiBhIHNob3J0IGZvcm11bGEgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIigpID0+IDFcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCIoaSkgPT4gaS54XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikgb2NjdXJyaW5nIGluc2lkZSBhIGxvbmdlciBvbmUgY291bnRzIGFzIG11bHRpcGxlIG9jY3VycmVuY2VzIGFuZCBpc1xcbnJlZnVzZWQuIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiVGhpcyBtYWtlcyB0aGUgdjEgbWVjaGFuaXNtIGhvbmVzdGx5IHBhcnRpYWxcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCI6IGNlbGxzIHdpdGggdmVyeSBzaG9ydCBvclxcbmR1cGxpY2F0ZWQgZm9ybXVsYSB0ZXh0IHdpbGwgcmVmdXNlIHRvIHNwbGljZSwgd2l0aCB0aGUgcmVmdXNhbCBzaG93biBhcyBzdWNoIGluIHRoZVxcbnBhbmVsLiBUaGUgY2xlYW4gc3VjY2Vzc29yIOKAlCBhIGJ1aWxkLXRpbWUgc291cmNlIHNwYW4gb24gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQ2VsbERlc2NyaXB0b3JcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCBpcyBib29rZWRcXG4owqcxMCkgYW5kIGJlY29tZXMgdjEuNSB0aGUgbW9tZW50IHJlZnVzYWwgcmF0ZXMgYW5ub3kgaW4gcHJhY3RpY2UuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5lbT57XCIoUjMtNDI3IGxhbmRlZCwgMjAyNi0wOC0yOCDigJQgdGhlIHN1Y2Nlc3NvciBpcyBidWlsdDogdGhlIHdvcmtlciBidWlsZCBjb21wdXRlcyBlYWNoXFxuY2VsbCdzIGFuZCB0ZXN0J3MgZGVjbGFyYXRpb24tYmxvY2sgc3BhbiBvbiB0aGUgcmF3IHNvdXJjZSAodGhlIHNhbWUgbGluZS1hbmNob3JlZFxcbm1hdGNoZXMgYXMgdGhlIMKnMy4zIHRyYW5zZm9ybSksIHRoZSBzcGxpY2UgcGF0Y2hlcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIndpdGhpbiB0aGUgdmFyaWVkIGNlbGwncyBvd25cXG5ibG9ja1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgc28gY3Jvc3MtY2VsbCBpZGVudGljYWwgYW5kIHN1YnN0cmluZyBmb3JtdWxhcyBubyBsb25nZXIgcmVmdXNlIOKAlCBhbmQgdGhlXFxudHlwZWQgcmVmdXNhbHMgcmVtYWluIG9ubHkgZm9yIHRoZSBkZWdlbmVyYXRlIHdpdGhpbi1ibG9jayBjYXNlcy4gU3Bhbi1sZXNzIGRlc2NyaXB0b3JzXFxua2VlcCB0aGUgdW5pcXVlLW9jY3VycmVuY2UgZmFsbGJhY2sgYWJvdmUsIHNvIGEgbWl4ZWQgb2xkL25ldyBlbmdpbmUgaXMgbmV2ZXIgYSBzaWxlbnRcXG53cm9uZyBwYXRjaC4gU3BhbnMgYWxzbyBzdXJmYWNlIGFzIFwifTxfY29tcG9uZW50cy5jb2RlPntcImZpbGU6bGluZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgb24gdGhlIGluc3BlY3RvcidzIGZvcm11bGEgYW5kIHRlc3Qgcm93cztcXG50aGUgY2xpY2thYmxlIG9wZW4tYXQtbGluZSByaWRlcyB0aGUgbmF2aWdhdG9yIHdvcmsgYW5kIHRoZSBlZGl0b3IgbGluZS1oaW50IGRlbHRhLilcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgcGF0Y2hlZCBzb3VyY2UgdGhlbiBnb2VzIHRocm91Z2ggdGhlIG9yZGluYXJ5IGJ1aWxkIHBhdGg7IGEgdmFyaWFudCB0aGF0IG5vIGxvbmdlclxcbnBhcnNlcyBvciBicmVha3MgdGhlIGdyYXBoIHN1cmZhY2VzIGFzIHRoZSBvcmRpbmFyeSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJidWlsZC1lcnJvclwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgLyBkaWFnbm9zdGljcywgc2hvd24gaW5cXG50aGUgcGFuZWwuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cInNlYy0zLTJcIiBkYXRhLXNsdWc9XCIzMi10aGUtc2NyYXRjaC1tb2R1bGUtYW5kLWNyb3NzLXJlZmVyZW5jZS12YWxpZGF0aW9uLXdpZi1yNVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTMtMlwiIC8+e1wiMy4yIFRoZSBzY3JhdGNoIG1vZHVsZSwgYW5kIGNyb3NzLXJlZmVyZW5jZSB2YWxpZGF0aW9uIChXSUYtUjUpXCJ9PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgc2NyYXRjaCBidWZmZXIgaXMgYWRkZWQgdG8gdGhlIGJ1aWxkJ3Mgc291cmNlcyB1bmRlciBhIHJlc2VydmVkIHdvcmtzaGVldCBuYW1lXFxuKFwifTxfY29tcG9uZW50cy5jb2RlPntcInNjcmF0Y2hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKS4gSWYgdGhlIGRvY3VtZW50IGFscmVhZHkgZGVjbGFyZXMgYSB3b3Jrc2hlZXQgbmFtZWQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic2NyYXRjaFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIHRoZSBwYWQgaXNcXG5kaXNhYmxlZCB3aXRoIGEgdmlzaWJsZSBtZXNzYWdlIChjb2xsaXNpb24gaXMgcmVmdXNlZCwgbm90IG1lcmdlZDsgUTIgYm9va3MgdGhlIGR1cmFibGVcXG5maXgpLiBTY3JhdGNoIGNlbGxzIG1heSBkZWNsYXJlIGlucHV0cyBvbiBhbnkgZHVyYWJsZSBjZWxsIG9yIGV4dGVybmFsOyBkdXJhYmxlIHNvdXJjZXNcXG5hcmUgcGF0Y2hlZCBvbmx5IGJ5IMKnMy4xIHNwbGljZXMgb2YgZXhpc3RpbmcgZm9ybXVsYXMsIHNvIHNjcmF0Y2ggY2VsbHMgY2Fubm90IGJlY29tZVxcbmlucHV0cyBvZiBkdXJhYmxlIGNlbGxzLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlRoZSBzaGFkb3cgYnVpbGQgcmUtcnVucyBleHRlcm5hbCBjcm9zcy1yZWZlcmVuY2UgdmFsaWRhdGlvbi5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgRW5naW5lIGJ1aWxkcyBkbyBub3RcXG52YWxpZGF0ZSBleHRlcm5hbCByZWZlcmVuY2VzIOKAlCB0aGF0IHJ1bnMgb25jZSBhdCBkb2N1bWVudCBsb2FkIOKAlCBhbmQgYW4gYWJzZW50IGV4dGVybmFsXFxucmVzb2x2ZXMgdG8gYSBzaWxlbnQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibnVsbFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuIEEgc2NyYXRjaCBjZWxsJ3MgdHlwbydkIFwifTxfY29tcG9uZW50cy5jb2RlPntcImZpeHR1cmVzLmV4ZWNfc3VtYXJ5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBtdXN0IG5vdFxcbmV2YWx1YXRlIHRvIGNvbmZpZGVudCBub25zZW5zZTogdGhlIHNoYWRvdyBwYXRoIHJlLXJ1bnMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widmFsaWRhdGVFeHRlcm5hbFJlZmVyZW5jZXNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxub3ZlciB0aGUgc2hhZG93IGVuZ2luZSdzIFwifTxfY29tcG9uZW50cy5jb2RlPntcImV4dGVybmFsUmVmZXJlbmNlcygpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgYWdhaW5zdCB0aGUgc2FtZSB1bml2ZXJzZSB0aGUgYmFzZVxcbnZhbGlkYXRpb24gdXNlZCAoZG9jdW1lbnQgZmVlZHMvZml4dHVyZXMvcGFyYW1zICsgcnVudGltZSBmZWVkcyArIHRlbXBsYXRlIHdpZGdldFxcbnBhcmFtcyksIGFuZCBzdXJmYWNlcyB0aGUgZGlhZ25vc3RpY3MgaW4gdGhlIHBhbmVsIChHLVdJRi0xMCkuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cInNlYy0zLTNcIiBkYXRhLXNsdWc9XCIzMy10aGUtdHJhbnNmb3JtLWNvcnJlY3RlZC13aWYtcjRcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy0zLTNcIiAvPntcIjMuMyBUaGUgdHJhbnNmb3JtLCBjb3JyZWN0ZWQgKFdJRi1SNClcIn08L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSB3b3Jrc2hlZXQtdG8tY29tcGFydG1lbnQgdHJhbnNmb3JtIHN0cmlwcyB0aGUgc3RkbGliIGltcG9ydCBsaW5lIGFuZCByZXdyaXRlc1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcImV4cG9ydCBjb25zdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdG8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY29uc3RcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLiBBcyBzaGlwcGVkLCBib3RoIHJlZ2V4ZXMgYXJlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1widW5hbmNob3JlZCBvdmVyIHRoZSB3aG9sZVxcbmJvZHlcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCI6IHRoZSB0b2tlbiBzZXF1ZW5jZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJleHBvcnQgY29uc3RcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGluc2lkZSBhIGZvcm11bGEncyBzdHJpbmcgbGl0ZXJhbCBvciBjb21tZW50XFxud291bGQgYmUgcmV3cml0dGVuIChtYWtpbmcgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZm9ybXVsYS50b1N0cmluZygpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBkaXZlcmdlIGZyb20gZmlsZSB0ZXh0KSBhbmQgd291bGRcXG5zaW11bHRhbmVvdXNseSBjb2xsZWN0IGEgcGhhbnRvbSBleHBvcnQgbmFtZSB0aGF0IGJyZWFrcyB0aGUgYnVpbGQncyByZWdpc3RlciBjYWxsLiBUaGlzXFxuc3BlYyByZXF1aXJlcyB0aGUgcmVnZXhlcyBiZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImxpbmUtYW5jaG9yZWRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKGEgcHJlcmVxdWlzaXRlIGZpeCwgRy1XSUYtMWEpOyB0aGVcXG5yZXNpZHVhbCDigJQgYSBzdHJpbmcgbGl0ZXJhbCBjb250YWluaW5nIGEgbmV3bGluZSBmb2xsb3dlZCBieSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJleHBvcnQgY29uc3RcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCBpc1xcbmFjY2VwdGVkIGFuZCBuYW1lZCwgc2luY2Ugc3VjaCBhIHNoZWV0IGFscmVhZHkgYnJlYWtzIHRoZSBcIn08X2NvbXBvbmVudHMuZW0+e1wiYmFzZVwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGJ1aWxkIHRvZGF5LCBiZWZvcmUgYW55XFxuc2hhZG93IG1hY2hpbmVyeSBpcyBpbnZvbHZlZC5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwic2VjLTMtNFwiIGRhdGEtc2x1Zz1cIjM0LXdoYXQtcGF0Y2hpbmctY2Fubm90LWRvXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtMy00XCIgLz57XCIzLjQgV2hhdCBwYXRjaGluZyBjYW5ub3QgZG9cIn08L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIk5vIHBhdGNoIG1heSB0b3VjaCB0aGUgbWFuaWZlc3QsIGZpeHR1cmVzLCBmZWVkcywgdGVtcGxhdGVzLCBvciBwYXJhbXMgZGVjbGFyYXRpb25zIOKAlFxcbnNvdXJjZXMgaW4sIHNvdXJjZXMgb3V0LCB3b3Jrc2hlZXRzIG9ubHkuIChFeHRlcm5hbHMgY291bnRlcmZhY3R1YWxzIOKAlCBcXFwid2hhdCBpZiB0aGlzXFxuZml4dHVyZSBsZWFmIHdlcmUgWFxcXCIg4oCUIGFscmVhZHkgaGF2ZSBhIGxpdmUgcGF0aCB2aWEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZW5naW5lLnVwZGF0ZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYW5kIHRoZSBwYXJhbVJlZnNcXG5tYWNoaW5lcnk7IHdpZGVuaW5nIFwifTxfY29tcG9uZW50cy5lbT57XCJ0aGF0XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgaW50byBhIGZ1bGwgZXh0ZXJuYWxzLW92ZXJyaWRlIFVJIGlzIG91dCBvZiBzY29wZSBoZXJlLilcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmhyIC8+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTRcIiBkYXRhLXNsdWc9XCI0LWRpZmZpbmctdGhlLWNvdW50ZXJmYWN0dWFsLW5vcm1hdGl2ZS1zaGlwcGVkLTIwMjYtMDgtMjdcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy00XCIgLz57XCI0LiBEaWZmaW5nIHRoZSBjb3VudGVyZmFjdHVhbCAgXCJ9PF9jb21wb25lbnRzLmVtPntcIihub3JtYXRpdmUg4oCUIHNoaXBwZWQgMjAyNi0wOC0yNylcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIHdoYXQtaWYgcmVzdWx0IGlzIGNvbXB1dGVkLCBub3QgbmFycmF0ZWQ6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJEZXBlbmRlbnRzIGNsb3N1cmVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIGEgcHVyZSByZXZlcnNlLWVkZ2Ugd2FsayBvdmVyIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkNlbGxEZXNjcmlwdG9yLmRlcHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGZyb20gdGhlXFxudmFyaWVkIGNlbGwocyksIGJvdW5kaW5nIHdoaWNoIGNlbGxzIFwifTxfY29tcG9uZW50cy5lbT57XCJjYW5cIn08L19jb21wb25lbnRzLmVtPntcIiBoYXZlIGNoYW5nZWQuIChXaWxkY2FyZCBpbnB1dHMgYXJlIGV4cGFuZGVkXFxuaW50byBcIn08X2NvbXBvbmVudHMuY29kZT57XCJkZXBzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhdCBidWlsZCB0aW1lLCBzbyB0aGUgY2xvc3VyZSBzZWVzIHRoZW07IHZhcmlhbnRzIGNhbm5vdCBjaGFuZ2UgZGVjbGFyZWRcXG5pbnB1dHMgKMKnMS4xKSwgc28gdGhlIGNsb3N1cmUgaXMgaWRlbnRpY2FsIG92ZXIgYmFzZSBhbmQgc2hhZG93IGRlc2NyaXB0b3JzLilcIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlZhbHVlIGRpZmZcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHBlciBjZWxsLCBjb21wYXJlIHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInBpbm5lZCBiYXNlbGluZSBwYXNzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiJ3MgcHVibGlzaGVkXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY29udGVudEtleVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKGEgY2Fub25pY2FsIGNvbGxpc2lvbi1mcmVlIHNlcmlhbGl6YXRpb24sIG5vdCBhIGxvc3N5IGRpZ2VzdCkgYWdhaW5zdFxcbnRoZSBzaGFkb3cgcGFzcydzOyBjaGFuZ2VkIC8gdW5jaGFuZ2VkIC8gbmV3bHktZXJyb3JpbmcgLyBuby1sb25nZXItZXJyb3JpbmcuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJWZXJkaWN0IGRpZmZcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHJ1biB0aGUgc2hhZG93IGVuZ2luZSdzIHRlc3Qgc3VpdGUgKFwifTxfY29tcG9uZW50cy5jb2RlPntcInJ1blRlc3RzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikgYW5kIHJlcG9ydCBzdWJqZWN0c1xcbndob3NlIHZlcmRpY3QgZmxpcHBlZCAocGFzc+KGkmZhaWwgaXMgdGhlIGhlYWRsaW5lOyBmYWls4oaScGFzcyBpcyBzaG93biB0b28pLCBhZ2FpbnN0IHRoZVxcbmJhc2UgdmVyZGljdHMgYWxyZWFkeSBjb21wdXRlZCBieSB0aGUgcmV2aWV3IHN1cmZhY2UuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkNlbGxzIG91dHNpZGUgdGhlIGNsb3N1cmUgYXJlIGFzc2VydGVkIHVuY2hhbmdlZCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImFuZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB2ZXJpZmllZCBieSB0aGUgc2FtZSBjb250ZW50S2V5XFxuY29tcGFyaXNvbiBpbiB0ZXN0cyAoRy1XSUYtNCk6IHRvcG8tb3JkZXIgZnVsbCByZWNvbXB1dGUgbWVhbnMgYW4gb3V0LW9mLWNsb3N1cmUgY2hhbmdlXFxuaXMgYW4gZW5naW5lIGJ1ZywgYW5kIHRoZSBnYXRlIHdvdWxkIGNhdGNoIGl0LlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgc2NyYXRjaCBzdXJmYWNlIHJldXNlcyB0aGUgc2FtZSBtYWNoaW5lcnkgd2l0aCBhbiBlbXB0eSB2YXJpYW50cyBtYXAuIEZvclxcbnB1cmVseS1hZGRpdGl2ZSBzY3JhdGNoIHJ1bnMgdGhlIHJlYWRvdXQgaXMgdGhlIHNjcmF0Y2ggY2VsbHMnIG93blxcbnZhbHVlcy9lcnJvcnMvdmVyZGljdHMsIHBsdXMgdHdvIGludmFyaWFudHM6IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibm8gZHVyYWJsZSBjZWxsJ3MgdmFsdWUgY2hhbmdlZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIlxcbihHLVdJRi01KSBhbmQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJubyBkdXJhYmxlIHN1YmplY3QncyB2ZXJkaWN0IGNoYW5nZWRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIGd1YXJhbnRlZWQgc3RydWN0dXJhbGx5IGJ5XFxucmVmdXNpbmcgc2NyYXRjaCB0ZXN0cyBvbiBkdXJhYmxlIHN1YmplY3RzICjCpzEuMiwgRy1XSUYtNmEpLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaHIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtNVwiIGRhdGEtc2x1Zz1cIjUtc2VjdXJpdHktaW50ZWdyaXR5LW5vcm1hdGl2ZS1zaGlwcGVkLTIwMjYtMDgtMjdcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy01XCIgLz57XCI1LiBTZWN1cml0eSAmIGludGVncml0eSAgXCJ9PF9jb21wb25lbnRzLmVtPntcIihub3JtYXRpdmUg4oCUIHNoaXBwZWQgMjAyNi0wOC0yNylcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhpcyBzcGVjIGFkZHMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJubyBuZXcgY2FwYWJpbGl0eSwgcHJpbmNpcGFsLCBzZXJ2aWNlLCByZWFsbSwgb3IgZ2F0ZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIi4gSXQgZG9lcyBhZGRcXG50aGUgZmlyc3Qgc3VyZmFjZSB0aGF0IGludml0ZXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ0eXBlZC1pbiBhcmJpdHJhcnkgZm9ybXVsYSBjb2RlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBzbyB0aGUgY29uZmluZW1lbnRcXG5zdG9yeSBtdXN0IGJlIHN0YXRlZCBwZXIgdHJhbnNwb3J0LCBub3QgYXZlcmFnZWQgKFdJRi1SMS9SMik6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJBdXRob3JpdHkgKGJvdGggdHJhbnNwb3J0cyk6IHN0YXJ2ZWQuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFNoYWRvdyBldmFsdWF0aW9uIHJ1bnMgaW4gU0VTIGNvbXBhcnRtZW50c1xcbmVuZG93ZWQgd2l0aCB0aGUgc3RkbGliIGFuZCBub3RoaW5nIGVsc2Ug4oCUIG5vIGFtYmllbnQgZmV0Y2gvRE9NL3Byb2Nlc3MsIHNhbWUgYXMgdGhlXFxuYmFzZSBldmFsdWF0b3IuIEEgdXNlciB0eXBpbmcgYSB2YXJpYW50IGludG8gdGhlaXIgb3duIHNlc3Npb24gcnVucyBjb2RlIHdpdGggbGVzc1xcbnJlYWNoIHRoYW4gdGhlIGRldnRvb2xzIGNvbnNvbGUgdGhleSBhbHJlYWR5IGhvbGQ7IENsYXNzLUEtYm91bmRlZCwgYnJvd3Nlci1wYXJpdHkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJJc29sYXRpb24vaW50ZWdyaXR5IOKAlCByZWFsLXdvcmtlciB0cmFuc3BvcnQgKGxvY2FsIGRldiwgYW5kIHRoZSBwbGF0Zm9ybSBvbmNlIGl0XFxuZXZhbHVhdGVzIFwifTxfY29tcG9uZW50cy5jb2RlPntcImltcG9ydC5tZXRhLnVybFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB0aGUgc2hhZG93IHdvcmtlciBpcyBhIHNlcGFyYXRlIFwifTxfY29tcG9uZW50cy5jb2RlPntcImxvY2tkb3duKClcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLWVkIHJlYWxtO1xcbmludHJpbnNpY3MgcG9pc29uaW5nIGFuZCBydW5hd2F5IGRpdmVyZ2VuY2UgYXJlIGNvbnRhaW5lZCBhbmQgdGVybWluYWJsZVxcbih3YXRjaGRvZyDihpIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widGVybWluYXRlKClcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSwgYW5kIHRoZSBiYXNlIHNlc3Npb24gaXMgc3RydWN0dXJhbGx5IHVucmVhY2hhYmxlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiSXNvbGF0aW9uL2ludGVncml0eSDigJQgaW4tcHJvY2VzcyBmYWxsYmFjayAodGhlIHBsYXRmb3JtIHRvZGF5KTogd2Vha2VyLCBhbmQgdGhpc1xcbnNwZWMgc2F5cyBzby5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhlIGluLXByb2Nlc3Mgd29ya2VyIHJ1bnMgaW4gdGhlIGFwcCdzIG93biByZWFsbSwgd2hpY2ggaXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJub3RcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCJcXG5sb2NrZWQgZG93bjsgY29tcGFydG1lbnQgc3RhcnZhdGlvbiBzdGlsbCBib3VuZHMgXCJ9PF9jb21wb25lbnRzLmVtPntcInJlYWNoYWJpbGl0eVwifTwvX2NvbXBvbmVudHMuZW0+e1wiIChubyBhbWJpZW50XFxuYXV0aG9yaXR5KSwgYnV0IHNoYXJlZCBtdXRhYmxlIHByaW1vcmRpYWxzIG1lYW4gYSBob3N0aWxlL2J1Z2d5IHZhcmlhbnQgY2FuIHBvaXNvblxcbmludHJpbnNpY3Mgc2hhcmVkIHdpdGggdGhlIGJhc2UgZW5naW5lIGFuZCB0aGUgYXBwIFVJLCBhbmQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJhIHN5bmNocm9ub3VzbHkgZGl2ZXJnZW50XFxudmFyaWFudCAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wid2hpbGUodHJ1ZSlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSBjYW5ub3QgYmUgaW50ZXJydXB0ZWQgYXQgYWxsXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCB0aGUgd2F0Y2hkb2cgaXMgYSBtYWluLXRocmVhZFxcbnRpbWVyIHRoYXQgbmV2ZXIgZmlyZXM7IHRoZSB0YWIgd2VkZ2VzIHVudGlsIHRoZSBicm93c2VyIGtpbGxzIGl0LCBiYXNlIHNlc3Npb25cXG5pbmNsdWRlZC4gVGhlIHNhbWUgaG9sZHMgZm9yIHRoZSBzaGFkb3cgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicnVuVGVzdHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHBhdGguIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiVGhlc2UgYXJlIG5hbWVkIHJlc2lkdWFscyxcXG5ub3QgY2xhaW1zLWF3YXlcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCI6IHRoZSBkZWVwLWNvcGllZCBiYXNlbGluZSAowqcyLjEpIGNsb3NlcyB0aGUgc2hhcmVkLWlucHV0LW11dGF0aW9uXFxuaG9sZSwgd2hpY2ggaXMgdGhlIGRlbGliZXJhdGVseS1jbG9zYWJsZSBwYXJ0OyB0aGUgaW50cmluc2ljcyBhbmQgZGl2ZXJnZW5jZSByZXNpZHVhbHNcXG5hcmUgYWNjZXB0ZWQgZm9yIHYxICh0aGUgYmFzZSBlbmdpbmUgYWxyZWFkeSBydW5zIGRvY3VtZW50IGZvcm11bGFzIG9uIHRoaXMgcGF0aCDigJRcXG50aGUgbWFyZ2luYWwgZXhwb3N1cmUgaXMgdGhhdCB3aGF0LWlmIGludml0ZXMgXCJ9PF9jb21wb25lbnRzLmVtPntcInVucmV2aWV3ZWQgdHlwZWRcIn08L19jb21wb25lbnRzLmVtPntcIiBjb2RlKSBhbmRcXG5zZWxmLXJlc29sdmUgd2hlbiB0aGUgcGxhdGZvcm0gZ2FpbnMgcmVhbCB3b3JrZXJzLiBCb29rZWQgYWx0ZXJuYXRpdmUg4oCUIFwifTxfY29tcG9uZW50cy5jb2RlPntcImxvY2tkb3duKClcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxub24gdGhlIG1haW4gcmVhbG0g4oCUIGlzIFE3LCB3aXRoIGl0cyBhcHAtYnJlYWthZ2UgY29zdCB0byBiZSBtZWFzdXJlZCwgbm90IGFzc3VtZWQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJFcGhlbWVyYWwgYnkgY29uc3RydWN0aW9uIOKAlCBSUy0xMCB1bnRvdWNoZWQuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFNoYWRvdyByZXN1bHRzIGxpdmUgaW4gdGhlIHBhbmVsIGFuZFxcbmRpZSB3aXRoIGl0LiBObyBwZXJzaXN0IHBhdGgsIG5vIGZyZWV6ZSBwYXRoLCBubyBmaWxlIHdyaXRlIGFueXdoZXJlIGluIHRoaXMgc3BlYzsgdGhlXFxud3JpdGUtbGF1bmRlcmluZyBzdXJmYWNlIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJSRVBPUlRJTkdfU1BSRUFEU0hFRVRfU1BFQyDCpzVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSBnYWlucyBubyBuZXcgZW50cnkgcG9pbnQuXFxuKEEgdXNlciBoYW5kLWNvcHlpbmcgYSBudW1iZXIgdGhleSBjYW4gYWxyZWFkeSBzZWUgaXMgYnJvd3Nlci1wYXJpdHksIG5vdCBhIHdyaXRlXFxucGF0aC4pIFRoZSBvbmUgZGF5IGEgXFxcImtlZXAgdGhpc1xcXCIgYWZmb3JkYW5jZSBleGlzdHMgKMKnNyksIGl0IG11c3Qgcm91dGUgdGhyb3VnaCB0aGVcXG5zYW1lIGZyZWV6ZS9jb250cmlidXRlIGdhdGVzIGFzIGFueSBvdGhlciB3cml0ZSDigJQgdGhhdCBhZmZvcmRhbmNlIGlzIG91dCBvZiBzY29wZVxcbnByZWNpc2VseSBzbyB0aGlzIHNwZWMgY2Fubm90IGJlIGl0cyBiYWNrIGRvb3IuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaWVyaW5nIGZsb3dzIHRocm91Z2ggdW5jaGFuZ2VkLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGUgc2hhZG93IHBhc3MgZm9sZHMgdGllcnMgZXhhY3RseSBhcyB0aGUgYmFzZVxcbnBhc3MgZG9lczsgYSBzaGFkb3cgdmFsdWUgZGVyaXZlZCBmcm9tIGFuIE0zIGZlZWQgYnVmZmVyIGRpc3BsYXlzIGFzIHN1Y2guIE5vdGhpbmcgaXNcXG5wZXJzaXN0ZWQsIHNvIG5vIHJlZmxvb3IgcXVlc3Rpb24gYXJpc2VzLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiU2hhcmVkLWRvY3VtZW50IHZpZXdlcnMuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIEluIGEgZnV0dXJlIHNoYXJlZCBjb250ZXh0LCB0aGUgd2hhdC1pZiBwYW5lbCBsZXRzIGFcXG5cIn08X2NvbXBvbmVudHMuZW0+e1widmlld2VyXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgcnVuIHRoZWlyIG93biBmb3JtdWxhIHRleHQgb3ZlciBkYXRhIHRoZSByZXBvcnQgYWxyZWFkeSBkaXNjbG9zZXMgdG8gdGhlbVxcbihDbGFzcyBBKSDigJQgdGhlIGF1dGhvcml0eSB0aGV5IGFscmVhZHkgaG9sZDsgaXQgZGlzY2xvc2VzIG5vdGhpbmcgbmV3IGFuZCB3cml0ZXNcXG5ub3RoaW5nLiBUaGUgcGFuZWwgTVVTVCBzdGlsbCBiZSBhYnNlbnQgd2hlbiB0aGUgaW5zcGVjdG9yIGl0c2VsZiBpcyBhYnNlbnQgZm9yIGFcXG5naXZlbiBkZXBsb3ltZW50IHNoYXBlIChRNCkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5ociAvPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInNlYy02XCIgZGF0YS1zbHVnPVwiNi1saWZlY3ljbGUtdGhlLWVkaXRvci1maXJzdC1ib3VuZGFyeS1ub3JtYXRpdmUtc2hpcHBlZC0yMDI2LTA4LTI3XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtNlwiIC8+e1wiNi4gTGlmZWN5Y2xlICYgdGhlIGVkaXRvci1maXJzdCBib3VuZGFyeSAgXCJ9PF9jb21wb25lbnRzLmVtPntcIihub3JtYXRpdmUg4oCUIHNoaXBwZWQgMjAyNi0wOC0yNylcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIk9uZSBzaGFkb3cgY29udGV4dCBwZXIgc3VyZmFjZSBpbnN0YW5jZSwgcmV1c2VkIGFjcm9zcyBydW5zLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBFYWNoIFJ1biByZS1cIn08X2NvbXBvbmVudHMuY29kZT57XCJidWlsZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCJzXFxudGhlIHNhbWUgc2hhZG93IGNvbnRleHQgKGJ1aWxkIHJlcGxhY2VzIHdvcmtlciBzdGF0ZSk7IFwifTxfY29tcG9uZW50cy5jb2RlPntcImRpc3Bvc2UoKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgb25cXG51bm1vdW50L2Rpc2NhcmQuIFJ1biBpcyBkaXNhYmxlZCB3aGlsZSBhIHNoYWRvdyBwYXNzIGlzIGluIGZsaWdodCAoZXhwbGljaXQgcnVuczsgbm9cXG5zdXBlcnNlc3Npb24gbWFjaGluZXJ5IG5lZWRlZCkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgcGxhdGZvcm0gZmFpbHVyZSBtb2RlIGlzIHN0YXRlZCBpbiDCpzUsIG5vdCBoZXJlLWhlZGdlZDpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgb24gdGhlIGluLXByb2Nlc3NcXG5mYWxsYmFjayBhIGRpdmVyZ2VudCB2YXJpYW50IGlzIHVucmVjb3ZlcmFibGUuIFRoZSBwYW5lbCBzaG93cyBhIHJ1bm5pbmcgc3RhdGU7IHRoYXRcXG5pcyBhIFVYIGFmZm9yZGFuY2UsIG5vdCBhIGNvbnRhaW5tZW50IGNsYWltLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiV2h5IG5vdCB0aGUgcGxhdGZvcm0gZWRpdG9yXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJFRElUT1JfRklSU1RfRURJVElOR19TUEVDXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDCpzUncyBzdGF0ZWQtcmVhc29uIHJ1bGUpOlxcbnRoZSB0aGluZyBiZWluZyBlZGl0ZWQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJpcyBub3QgYSBmaWxlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBhIHZhcmlhbnQgaXMgYSBjb3VudGVyZmFjdHVhbCB0aGF0IG11c3RcXG5uZXZlciB0b3VjaCB0aGUgZG9jdW1lbnQsIGFuZCB0aGUgc2NyYXRjaCBidWZmZXIgaXMgYW4gdW5zYXZlZCBldmFsdWF0aW9uIGNvbnRleHRcXG53aG9zZSBcIn08X2NvbXBvbmVudHMuZW0+e1wiY29udGVudFwifTwvX2NvbXBvbmVudHMuZW0+e1wiIHRoZSB1c2VyIGNhbiBjb3B5IG91dCBhdCB3aWxsICjCpzEuNCkuIFRoZSBwbGF0Zm9ybSBlZGl0b3IncyBjb250cmFjdFxcbmlzIGVkaXRpbmcgXCJ9PF9jb21wb25lbnRzLmVtPntcImZpbGVzIGluIG1vdW50c1wifTwvX2NvbXBvbmVudHMuZW0+e1wiOyByb3V0aW5nIGFuIGV4cGxpY2l0bHktbmV2ZXItcGVyc2lzdGVkIGJ1ZmZlciB0aHJvdWdoIGl0XFxud291bGQgY3JlYXRlIHRoZSB2ZXJ5IHdyaXRlIHBhdGggdGhpcyBkZXNpZ24gZXhpc3RzIHRvIGF2b2lkLiBUaGUgbW9tZW50IGVpdGhlclxcbnN1cmZhY2UgZ3Jvd3MgYSBwZXJzaXN0ZW5jZSBhZmZvcmRhbmNlLCB0aGF0IGFmZm9yZGFuY2UgZGVsZWdhdGVzIHRvIHRoZSBwbGF0Zm9ybVxcbihcIn08X2NvbXBvbmVudHMuY29kZT57XCJlZGl0LWZpbGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIC8gY29udHJpYnV0ZSkg4oCUIHJlY29yZGVkIGhlcmUgYXMgdGhlIHN0YW5kaW5nIGJvdW5kYXJ5LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaHIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtN1wiIGRhdGEtc2x1Zz1cIjctb3V0LW9mLXNjb3BlLXRoZS1ob25lc3QtcmVtYWluZGVyLW5vcm1hdGl2ZS10aGUtYm9va2VkLXJlbWFpbmRlci1ub3RoaW5nLWhlcmUtc2hpcHBlZFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTdcIiAvPntcIjcuIE91dCBvZiBzY29wZSDigJQgdGhlIGhvbmVzdCByZW1haW5kZXIgIFwifTxfY29tcG9uZW50cy5lbT57XCIobm9ybWF0aXZlIOKAlCB0aGUgYm9va2VkIHJlbWFpbmRlciwgbm90aGluZyBoZXJlIHNoaXBwZWQpXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJBcHBseSAvIHByb21vdGUuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFdyaXRpbmcgYSB2YXJpYW50IGJhY2sgdG8gaXRzIHdvcmtzaGVldCwgb3IgYSBzY3JhdGNoIGNlbGwgaW50byBhXFxuZHVyYWJsZSBzaGVldCwgcmVxdWlyZXMgYSB3cml0YWJsZSBtb3VudCBhbmQgdGhlIHBsYXRmb3JtIGVkaXRpbmcgcGF0aFxcbihcIn08X2NvbXBvbmVudHMuY29kZT57XCJlZGl0LWZpbGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL2NvbnRyaWJ1dGUpIHBsdXMgdGhlIGZyZWV6ZS1nYXRlIHF1ZXN0aW9ucyBvZiBSUy0xMC4gTm90IGluIHRoaXMgc3BlYztcXG50aGUgVUkgc2hvd3MgXCJ9PF9jb21wb25lbnRzLmVtPntcIndoeVwifTwvX2NvbXBvbmVudHMuZW0+e1wiIChyZWFkLW9ubHkgZG9jdW1lbnQpIHJhdGhlciB0aGFuIGEgZGVhZCBidXR0b24uXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJSLTYncyBvdGhlciBoYWx2ZXMuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRoZSB0YWJ1bGFyIG11bHRpLWNlbGwgaW5zcGVjdG9yIGFuZCByYW5nZS1zZWxlY3Qtc3VtIHJlbWFpblxcbm9wZW47IHRoaXMgc3BlYyBjbG9zZXMgb25seSB0aGUgc2NyYXRjaC93aGF0LWlmIHNsaWNlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRXh0ZXJuYWxzLW92ZXJyaWRlIFVJXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChcXFwid2hhdCBpZiB0aGlzIGZpeHR1cmUgd2VyZeKAplxcXCIpIGJleW9uZCB0aGUgZXhpc3RpbmcgcGFyYW1zXFxucGF0aCAowqczLjQpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiU2NyYXRjaC10ZXh0IHBlcnNpc3RlbmNlIGFjcm9zcyByZWxvYWRzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBib29rZWQsIG5vdCBkZXNpZ25lZDogYW55IGxhdGVyXFxucGVyc2lzdGVuY2UgbXVzdCBzdXJ2aXZlIHRoZSBwbGF0Zm9ybSdzIG9wYXF1ZS1vcmlnaW4gc3RvcmFnZSBjb25zdHJhaW50cyAoYWNjZXNzIGNhblxcbnRocm93OyB3cmFwIGFuZCBkZWdyYWRlKSBhbmQgaXMgXCJ9PF9jb21wb25lbnRzLmVtPntcInRleHQtb25seVwifTwvX2NvbXBvbmVudHMuZW0+e1wiIChuZXZlciByZXN1bHRzKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIk11bHRpLXZhcmlhbnQgY29tcGFyZSAvIHN3ZWVwIFVJXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICh2YXJ5IGEgY2VsbCBhY3Jvc3MgTiB2YWx1ZXMpOiB0aGUgZW5naW5lIGNvc3RcXG5tb2RlbCBzdXBwb3J0cyBpdCAoTiBzaGFkb3cgcGFzc2VzKSwgYnV0IHRoZSBzdXJmYWNlIGlzIGZ1dHVyZSB3b3JrIChRMykuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5ociAvPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInNlYy04XCIgZGF0YS1zbHVnPVwiOC1nYXRlcy1ub3JtYXRpdmUtdGhlLWZhbHNpZmlhYmxlLWV4aXQtdGVzdHMtc2hpcHBlZC0yMDI2LTA4LTI3XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtOFwiIC8+e1wiOC4gR2F0ZXMgIFwifTxfY29tcG9uZW50cy5lbT57XCIobm9ybWF0aXZlIOKAlCB0aGUgZmFsc2lmaWFibGUgZXhpdCB0ZXN0cywgc2hpcHBlZCAyMDI2LTA4LTI3KVwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMudGFibGU+PF9jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGg+e1wiR2F0ZVwifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIlRlc3RcIn08L19jb21wb25lbnRzLnRoPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudGJvZHk+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkctV0lGLTFcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJTcGxpY2luZyBhIHZhcmlhbnQgaW50byBhIHNoZWV0IHdoZXJlIHRoZSBmb3JtdWxhIHRleHQgb2NjdXJzIGV4YWN0bHkgb25jZSBwcm9kdWNlcyBhIHNvdXJjZSB0aGF0IGJ1aWxkczsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZm9ybXVsYS1ub3QtZm91bmRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICh6ZXJvIG9jY3VycmVuY2VzKSBhbmQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZm9ybXVsYS1hbWJpZ3VvdXNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChpZGVudGljYWwtZm9ybXVsYSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImFuZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBzdWJzdHJpbmcgY2FzZXMpIGFyZSByZXR1cm5lZCBhcyB0eXBlZCBlcnJvcnMg4oCUIG5ldmVyIGEgc2lsZW50IHdyb25nIHBhdGNoLlwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRy1XSUYtMWFcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJUaGUgd29ya3NoZWV0IHRyYW5zZm9ybSBpcyBsaW5lLWFuY2hvcmVkOiBhIGZvcm11bGEgY29udGFpbmluZyB0aGUgc3RyaW5nIGxpdGVyYWwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiXFxcImV4cG9ydCBjb25zdCB4XFxcIlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYnVpbGRzLCByb3VuZC10cmlwcyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmb3JtdWxhU291cmNlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB2ZXJiYXRpbSwgYW5kIHJlZ2lzdGVycyBubyBwaGFudG9tIGV4cG9ydC5cIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkctV0lGLTJcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJBIHNoYWRvdyBydW4gb3ZlciBhIHZhcmlhbnQgY2hhbmdlcyB0aGUgdmFyaWVkIGNlbGwgYW5kIGl0cyBkZXBlbmRlbnRzIGluIHRoZSBzaGFkb3cgcGFzcyB3aGlsZSB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJiYXNlIGVuZ2luZSdzIHB1Ymxpc2hlZCByZXN1bHRzIGFyZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjb250ZW50S2V5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi1pZGVudGljYWxcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYmVmb3JlL2FmdGVyLiBPbiB0aGUgaW4tcHJvY2VzcyB0cmFuc3BvcnQgdGhpcyBpcyBhZGRpdGlvbmFsbHkgZXhlcmNpc2VkIHdpdGggYSB2YXJpYW50IHRoYXQgXCJ9PF9jb21wb25lbnRzLmVtPntcIm11dGF0ZXMgaXRzIGlucHV0IHJvd3NcIn08L19jb21wb25lbnRzLmVtPntcIiDigJQgdGhlIGRlZXAtY29waWVkIGJhc2VsaW5lICjCpzIuMSkga2VlcHMgdGhlIGJhc2Ugc2Vzc2lvbidzIG5leHQgcGFzcyB1bmFmZmVjdGVkLlwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRy1XSUYtM1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcInNldHRsZWRTbmFwc2hvdCgpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhd2FpdHMgcXVpZXNjZW5jZSBhbmQgcmV0dXJucyBhIGNvaGVyZW50IHBhaXI6IGEgcGFyYW1zIHdyaXRlIGlzc3VlZCBiZWZvcmUgdGhlIGNhbGwgaXMgcmVmbGVjdGVkIGluIGJvdGggdGhlIGV4dGVybmFscyBhbmQgdGhlIHBhc3M7IGZlZWQtYnVmZmVyIGtleXMgcHJlc2VudCBpbiB0aGUgZW5naW5lIGFyZSBwcmVzZW50IGluIHRoZSBzbmFwc2hvdDsgdGhlIHJldHVybmVkIGV4dGVybmFscyBhcmUgY29waWVzIChtdXRhdGluZyB0aGVtIGRvZXMgbm90IGFmZmVjdCB0aGUgZW5naW5lKS5cIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkctV0lGLTRcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJUaGUgdmFsdWUgZGlmZiByZXBvcnRzIGV4YWN0bHkgdGhlIGNlbGxzIHdob3NlIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNvbnRlbnRLZXlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGRpZmZlcnMgYmV0d2VlbiB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJwaW5uZWRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYmFzZWxpbmUgcGFzcyBhbmQgdGhlIHNoYWRvdyBwYXNzOyBldmVyeSBjaGFuZ2VkIGNlbGwgaXMgaW5zaWRlIHRoZSBkZXBlbmRlbnRzIGNsb3N1cmUgb2YgdGhlIHZhcmllZCBjZWxsKHMpLiBSdW4gdW5kZXIgY29uY3VycmVudCBiYXNlLWVuZ2luZSB1cGRhdGVzIChhIHRpY2tpbmcgZmVlZCksIGEgbm8tdmFyaWFudCBzaGFkb3cgb3ZlciB0aGUgcGlubmVkIHBhaXIgcmVwb3J0cyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInplcm9cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgZGVsdGFzLlwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRy1XSUYtNVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIkEgc2NyYXRjaC1vbmx5IHJ1biBsZWF2ZXMgZXZlcnkgZHVyYWJsZSBjZWxsJ3Mgc2hhZG93IHZhbHVlIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNvbnRlbnRLZXlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLWVxdWFsIHRvIHRoZSBwaW5uZWQgYmFzZWxpbmU7IHNjcmF0Y2ggY2VsbHMgZXZhbHVhdGUsIGVycm9yLCBhbmQgdGVzdCBsaWtlIGR1cmFibGUgY2VsbHMuXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnN0cm9uZz57XCJHLVdJRi02XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiU2hhZG93IHRlc3QgdmVyZGljdHM6IGEgdmFyaWFudCB0aGF0IGJyZWFrcyBhIHN1YmplY3QncyB0ZXN0IGZsaXBzIHRoYXQgc3ViamVjdCdzIHZlcmRpY3QgaW4gdGhlIHNoYWRvdyBzdWl0ZTsgdGhlIGJhc2Ugc2Vzc2lvbidzIHZlcmRpY3RzIGFyZSB1bnRvdWNoZWQuXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnN0cm9uZz57XCJHLVdJRi02YVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIkEgc2NyYXRjaCB0ZXN0IGNlbGwgd2hvc2UgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3ViamVjdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaXMgYSBkdXJhYmxlIGNlbGwgaXMgcmVmdXNlZCBhdCBzaGFkb3ctYnVpbGQgdGltZSB3aXRoIGEgdHlwZWQgZXJyb3I7IGR1cmFibGUgc3ViamVjdHMnIHZlcmRpY3RzIGNhbm5vdCBiZSBjb250YW1pbmF0ZWQgYnkgc2NyYXRjaCBjb250ZW50LlwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRy1XSUYtN1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcImRpc3Bvc2UoKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgb24gdGhlIHNoYWRvdyB0cmFuc3BvcnQgdGVybWluYXRlcyB0aGUgd29ya2VyIChyZWFsLVdvcmtlciBjYXNlKSAvIGRyb3BzIHRoZSBpbi1wcm9jZXNzIHdvcmtlciwgYW5kIGEgZGlzcG9zZWQgdHJhbnNwb3J0IGRlbGl2ZXJzIG5vIGZ1cnRoZXIgbWVzc2FnZXMuXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnN0cm9uZz57XCJHLVdJRi04XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiQSB3b3Jrc2hlZXQgbmFtZWQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic2NyYXRjaFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaW4gdGhlIGRvY3VtZW50IGRpc2FibGVzIHRoZSBzY3JhdGNoIHBhZCB3aXRoIGEgdmlzaWJsZSBtZXNzYWdlIChubyBzaWxlbnQgbWVyZ2UsIG5vIGNyYXNoKS5cIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkctV0lGLTlcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJBIHNoYWRvdyBydW4gb3ZlciB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJDYWxkZXJhIGNhc2Utc3R1ZHkgZG9jdW1lbnRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHZhcmlhbnQgb24gYSBtb2RlbCBjZWxsKSBjb21wbGV0ZXMgaW4gdGhlIGhhcm5lc3M6IHRoZSB2YXJpZWQgY2VsbCBhbmQgaXRzIGRlcGVuZGVudHMgY2hhbmdlOyBjZWxscyBvdXRzaWRlIHRoZSBjbG9zdXJlIG1hdGNoIHRoZSBQeXRob24tb3JhY2xlIHZhbHVlcyB1bmNoYW5nZWQuIFwifTxfY29tcG9uZW50cy5lbT57XCIoTm9kZSBoYXJuZXNzIG9ubHkg4oCUIG5vIGJyb3dzZXItbGF0ZW5jeSBjbGFpbTsgdGhlIGJyb3dzZXIgbWVhc3VyZW1lbnQgaXMgYSBzdGF0dXMtZG9jIGl0ZW0uKVwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnN0cm9uZz57XCJHLVdJRi0xMFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIkEgc2NyYXRjaCBjZWxsIHJlZmVyZW5jaW5nIGFuIHVuZGVjbGFyZWQgZXh0ZXJuYWwgKHR5cG8nZCBmaXh0dXJlLCB1bmRlY2xhcmVkIGZlZWQpIHByb2R1Y2VzIGEgdmlzaWJsZSBjcm9zcy1yZWZlcmVuY2UgZGlhZ25vc3RpYyBpbiB0aGUgc2hhZG93IHJlc3VsdCDigJQgbmV2ZXIgYSBzaWxlbnQgbnVsbC1kZXJpdmVkIHZhbHVlLlwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRy1XSUYtMTFcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJTY3JhdGNoL3ZhcmlhbnQgYnVmZmVyIHRleHQgc3Vydml2ZXMgY2xvc2luZyBhbmQgcmVvcGVuaW5nIGl0cyBwYW5lbDsgQ2xlYXIgb24gYSBub24tZW1wdHkgYnVmZmVyIHJlcXVpcmVzIGEgY29uZmlybSBzdGVwLlwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRib2R5PjwvX2NvbXBvbmVudHMudGFibGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmhyIC8+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTlcIiBkYXRhLXNsdWc9XCI5LWxvYWQtYmVhcmluZy1hc3N1bXB0aW9ucy1jb2RlLWFuY2hvcnMtcmVxdWlyZWRcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy05XCIgLz57XCI5LiBMb2FkLWJlYXJpbmcgYXNzdW1wdGlvbnMgJiBjb2RlIGFuY2hvcnMgIFwifTxfY29tcG9uZW50cy5lbT57XCIocmVxdWlyZWQpXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cImRlcGVuZHMtb24tdG9kYXktdmVyaWZpZWQtYWdhaW5zdC1jb2RlXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJkZXBlbmRzLW9uLXRvZGF5LXZlcmlmaWVkLWFnYWluc3QtY29kZVwiIC8+e1wiRGVwZW5kcy1vbi10b2RheSAodmVyaWZpZWQgYWdhaW5zdCBjb2RlKVwifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnRhYmxlPjxfY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRoPntcIkFzc3VtcHRpb25cIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aD57XCJBbmNob3IgKHJlcG8tcmVsYXRpdmUgZmlsZSlcIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aD57XCJUb2tlbiAoZ3JlcC1zdGFibGUpXCJ9PC9fY29tcG9uZW50cy50aD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGhlYWQ+PF9jb21wb25lbnRzLnRib2R5PjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiVGhlIGJ1aWxkIG1lc3NhZ2UgY2FycmllcyByYXcgd29ya3NoZWV0IHNvdXJjZXM7IHJlYnVpbGQgaXMgcm91dGluZVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcInNyYy9lbmdpbmUvd29ya2VyL3Byb3RvY29sLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcInR5cGU6ICdidWlsZCc7IHNvdXJjZXM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz5cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiVGhlIGVuZ2luZSByZS1zZW5kcyBidWlsZHMgYWZ0ZXIgd2F0Y2hkb2cgcmVzdGFydHMgKGJ1aWxkIGlzIHJlLWVudHJhbnQpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2VuZ2luZS9hc3luY0VuZ2luZS50c1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCIjc2VuZEJ1aWxkKHRoaXMuI3NvdXJjZXMpXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkEgcGFzcyBjbGVhcnMgcmVzdWx0cyBhbmQgcmUtZXZhbHVhdGVzIGV2ZXJ5IGNlbGwgKGZ1bGwgcmVjb21wdXRlKVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcInNyYy9lbmdpbmUvYXN5bmNFbmdpbmUudHNcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1widGhpcy4jcmVzdWx0cyA9IG5ldyBNYXAoKVwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJQdWJsaXNoZWQgcmVzdWx0cyBjYXJyeSBhIGNhbm9uaWNhbCBjb250ZW50IGtleSB1c2FibGUgZm9yIGRpZmZpbmdcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJzcmMvZW5naW5lL2hhc2gudHNcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiY2Fub25pY2FsIHNlcmlhbGl6YXRpb25cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiVGhlIHdvcmtzaGVldCB0cmFuc2Zvcm0gcmV3cml0ZXMgdGhlIHN0ZGxpYiBpbXBvcnQgYW5kIFwifTxfY29tcG9uZW50cy5jb2RlPntcImV4cG9ydCBjb25zdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKHVuYW5jaG9yZWQgdG9kYXkg4oCUIMKnMy4zJ3MgcHJlcmVxdWlzaXRlIGZpeClcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJzcmMvZW5naW5lL2NvbXBhcnRtZW50LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcIkVYUE9SVF9DT05TVFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJUaGUgZGVzY3JpcHRvcidzIGZvcm11bGEgdGV4dCBpcyB0aGUgZnVuY3Rpb24ncyBvd24gc291cmNlXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2VuZ2luZS93b3JrZXIvZW5naW5lV29ya2VyLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcImZvcm11bGEudG9TdHJpbmcoKVwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJEZXBlbmRlbmN5IGVkZ2VzICh3aWxkY2FyZHMgcHJlLWV4cGFuZGVkKSBhcmUgc2VyaWFsaXplZCBvbiB0aGUgZGVzY3JpcHRvclwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcInNyYy9lbmdpbmUvZ3JhcGgudHNcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiZm9yIChjb25zdCBkZXAgb2YgY2VsbHMpIGlmIChkZXAgIT09IGN0eC5pZCkgY3R4LmRlcHMuYWRkKGRlcClcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiVGhlIHN1aXRlIHJ1bnMgd29ya2VyLXNpZGUgb3ZlciBob3N0LXJlc29sdmVkIGNvbnRleHRzXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2VuZ2luZS9hc3luY0VuZ2luZS50c1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJydW5UZXN0c1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJBbiBhYnNlbnQgZXh0ZXJuYWwgcmVzb2x2ZXMgdG8gYSBzaWxlbnQgbnVsbCAod2h5IMKnMy4yIG11c3QgcmUtdmFsaWRhdGUpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2VuZ2luZS9yZXNvbHZlLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcImV4dD8udmFsdWUgPz8gbnVsbFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJFeHRlcm5hbCBjcm9zcy1yZWZlcmVuY2UgdmFsaWRhdGlvbiBydW5zIGF0IGxvYWQsIG5vdCBhdCBidWlsZFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcInNyYy9hcHAvcmVwb3J0U2Vzc2lvbi50c1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJ4cmVmRGlhZ25vc3RpY3NcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiUGFyYW1zIHdyaXRlcyBmbG93IHRocm91Z2ggXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZW5naW5lLnVwZGF0ZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKHRoZSBsaXZlIGNvdW50ZXJmYWN0dWFsIHByZWNlZGVudClcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJzcmMvYXBwL3JlcG9ydFNlc3Npb24udHNcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wic2Vzc2lvbi5lbmdpbmUudXBkYXRlXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIlRoZSBwbGF0Zm9ybSBmYWxscyBiYWNrIHRvIHRoZSBpbi1wcm9jZXNzIHRyYW5zcG9ydCAobWFpbi10aHJlYWQgcG9zdHVyZSwgwqc1KVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcInNyYy9hcHAvcmVwb3J0U2Vzc2lvbi50c1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJpbk1lbW9yeVRyYW5zcG9ydFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJUaGUgaW4tcHJvY2VzcyB3b3JrZXIgY2Fubm90IGludGVycnVwdCBzeW5jaHJvbm91cyBkaXZlcmdlbmNlXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2VuZ2luZS93b3JrZXJUcmFuc3BvcnQudHNcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiY2Fubm90IGludGVycnVwdCBhIHN5bmNocm9ub3VzIGRpdmVyZ2VuY2VcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wibG9ja2Rvd24oKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcnVucyBvbmx5IGluIHRoZSByZWFsLXdvcmtlciBlbnRyeVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcInNyYy9lbnRyeS9lbmdpbmUudHNcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wic2NvcGUubG9ja2Rvd25cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiVGhlIGNvbXBhcnRtZW50IGVuZG93cyBzdGRsaWIgKyBub3RoaW5nIChzdGFydmF0aW9uKVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcInNyYy9lbmdpbmUvY29tcGFydG1lbnQudHNcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wibmV3IENvbXBhcnRtZW50KHsgLi4uc3RkbGliLCBfX3JlZ2lzdGVyOiByZWdpc3RlciB9KVwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJGZWVkIGJ1ZmZlcnMgYXJlIGVuZ2luZS1pbnRlcm5hbCBleHRlcm5hbHMgKHdoeSB0aGUgc25hcHNob3QgbXVzdCBjb21lIGZyb20gdGhlIGVuZ2luZSlcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJzcmMvZW5naW5lL3Jlc29sdmUudHNcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiRkVFRF9CVUZGRVJfUFJFRklYXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRib2R5PjwvX2NvbXBvbmVudHMudGFibGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwibXVzdC1lc3RhYmxpc2gtbmV3LWludmFyaWFudHMtdGhlLWltcGxlbWVudGF0aW9uLWNyZWF0ZXNcIj48SGVhZGluZ0FuY2hvciBpZD1cIm11c3QtZXN0YWJsaXNoLW5ldy1pbnZhcmlhbnRzLXRoZS1pbXBsZW1lbnRhdGlvbi1jcmVhdGVzXCIgLz57XCJNdXN0LWVzdGFibGlzaCAobmV3IGludmFyaWFudHMgdGhlIGltcGxlbWVudGF0aW9uIGNyZWF0ZXMpXCJ9PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMudGFibGU+PF9jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGg+e1wiTmV3IGludmFyaWFudFwifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIlByb3ZlbiBieSAoZ2F0ZSB0ZXN0KVwifTwvX2NvbXBvbmVudHMudGg+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50Ym9keT48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcIkFzeW5jRW5naW5lLnNldHRsZWRTbmFwc2hvdCgpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgcXVpZXNjZW50LCBjb2hlcmVudCwgZGVlcC1jb3BpZWQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiKHBhc3MsIGV4dGVybmFscylcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiRy1XSUYtM1wifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIlRoZSBzZXNzaW9uIHJldGFpbnMgc291cmNlcyArIGxvYWRlZCBkb2N1bWVudCArIHJ1bnRpbWUgZmVlZHMgZm9yIHBhdGNoaW5nIGFuZCByZS12YWxpZGF0aW9uXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiRy1XSUYtMiwgRy1XSUYtMTBcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJXb3JrZXJUcmFuc3BvcnQuZGlzcG9zZSgpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB0ZXJtaW5hdGVzIHdpdGhvdXQgcmVzcGF3blwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIkctV0lGLTdcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJTcGxpY2UgcmVmdXNlcyB6ZXJvL2FtYmlndW91cyBvY2N1cnJlbmNlIHdpdGggdHlwZWQgZXJyb3JzXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiRy1XSUYtMVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIlRoZSB0cmFuc2Zvcm0gaXMgbGluZS1hbmNob3JlZFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIkctV0lGLTFhXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiU2hhZG93IHJ1bnMgbmV2ZXIgbXV0YXRlIGJhc2Utc2Vzc2lvbiBwdWJsaXNoZWQgc3RhdGUgb3IgaW5wdXRzXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiRy1XSUYtMiwgRy1XSUYtNlwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIlNjcmF0Y2ggcnVucyBhcmUgYWRkaXRpdmUgb3ZlciBkdXJhYmxlIHN0YXRlIOKAlCB2YWx1ZXMgYW5kIHZlcmRpY3RzXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiRy1XSUYtNSwgRy1XSUYtNmFcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJTaGFkb3cgYnVpbGRzIHJlLXJ1biBleHRlcm5hbCBjcm9zcy1yZWZlcmVuY2UgdmFsaWRhdGlvblwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIkctV0lGLTEwXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiQnVmZmVyIHRleHQgaXMgc2Vzc2lvbi1zY29wZWQ7IENsZWFyIGlzIGNvbmZpcm1lZFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIkctV0lGLTExXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGJvZHk+PC9fY29tcG9uZW50cy50YWJsZT57XCJcXG5cIn08X2NvbXBvbmVudHMuaHIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtMTBcIiBkYXRhLXNsdWc9XCIxMC1kZWNpc2lvbnMtcmVqZWN0ZWQtYWx0ZXJuYXRpdmVzLW5vcm1hdGl2ZS1kb250LXJlbGl0aWdhdGVcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy0xMFwiIC8+e1wiMTAuIERlY2lzaW9ucyAmIHJlamVjdGVkIGFsdGVybmF0aXZlcyAgXCJ9PF9jb21wb25lbnRzLmVtPntcIihub3JtYXRpdmUg4oCUIGRvbuKAmXQgcmVsaXRpZ2F0ZSlcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkEgc2Vjb25kIGVuZ2luZSBpbnN0YW5jZSwgbm90IGFuIGluLXBsYWNlIG1vZGUgb2YgdGhlIGJhc2UgZW5naW5lLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGUgYmFzZVxcbmVuZ2luZSdzIHNpbmdsZS1zbG90IHN1cGVyc2Vzc2lvbiBhbmQgcHVibGlzaGVkLXN0YXRlIG1hcHMgYXJlIHRoZSByZXBvcnQncyBzb3VyY2Ugb2ZcXG50cnV0aDsgdGhyZWFkaW5nIFxcXCJjb3VudGVyZmFjdHVhbFxcXCIgdGhyb3VnaCB0aGVtIHJpc2tzIGV4YWN0bHkgdGhlIHN1YnN0aXR1dGUtdXNlci1ieXRlc1xcbmNsYXNzIG9mIGJ1ZyB0aGUgZWRpdG9yIHNwZWMncyDCpzYgZXhpc3RzIHRvIHByZXZlbnQuIFR3byBpbnN0YW5jZXMgbWFrZSB0aGUgXCJ9PF9jb21wb25lbnRzLmVtPntcImhvc3Qtc2lkZVxcbnN0YXRlXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgc2VwYXJhdGlvbiBzdHJ1Y3R1cmFsOyByZWFsbS1sZXZlbCBpc29sYXRpb24gaXMgdHJhbnNwb3J0LWRlcGVuZGVudCBhbmQgc3RhdGVkXFxucGVyLXRyYW5zcG9ydCBpbiDCpzUgKFdJRi1SMSDigJQgdGhlIGVhcmxpZXIgXFxcInN0cnVjdHVyYWwgaXNvbGF0aW9uXFxcIiBwaHJhc2luZyBvdmVyY2xhaW1lZCkuXFxuXCJ9PF9jb21wb25lbnRzLmVtPntcIlJlamVjdGVkOlwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGFuIFwifTxfY29tcG9uZW50cy5jb2RlPntcImV2YWx1YXRlQ291bnRlcmZhY3R1YWwoKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgbW9kZSBmbGFnIG9uIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkFzeW5jRW5naW5lXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjsgc2F2ZS9yZXN0b3JlIG9mXFxucHVibGlzaGVkIG1hcHMgYXJvdW5kIGEgY291bnRlcmZhY3R1YWwgcGFzcy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkRpZmYgYWdhaW5zdCBhIHBpbm5lZCBzZXR0bGVkIGJhc2VsaW5lLCBuZXZlciB0aGUgbGl2ZSBlbmdpbmUgKFdJRi1SMykuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFVuZGVyIGFcXG50aWNraW5nIGZlZWQsIFxcXCJiYXNlIGF0IHNoYWRvdy1jb21wbGV0aW9uIHRpbWVcXFwiIHByb2R1Y2VzIHNwdXJpb3VzIGRlbHRhczsgYSBwaW5uZWRcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCIocGFzcywgZXh0ZXJuYWxzKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcGFpciBtYWtlcyB0aGUgZGlmZiBhIHB1cmUgZnVuY3Rpb24gb2Ygb25lIGVwb2NoLiBcIn08X2NvbXBvbmVudHMuZW0+e1wiUmVqZWN0ZWQ6XCJ9PC9fY29tcG9uZW50cy5lbT57XCJcXG5kaWZmaW5nIGFnYWluc3QgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZW5naW5lLnNuYXBzaG90KClcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGF0IGNvbXBsZXRpb24gdGltZSAocGFydGlhbCBtaWQtcGFzcyBtYXBzLCBtaXNzZWRcXG5wZW5kaW5nIGV4dGVybmFscykuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJVbmlxdWUtb2NjdXJyZW5jZSB0ZXh0IHNwbGljZSwgbm90IHNvdXJjZSBzcGFucywgZm9yIHYxIOKAlCB3aXRoIHRoZSByZWZ1c2FsIHJhdGVcXG5uYW1lZCAoV0lGLVI0KS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhlIHNwbGljZSBuZWVkcyB6ZXJvIHByb3RvY29sL3dvcmtlciBjaGFuZ2VzIGFuZCBmYWlscyBjbG9zZWRcXG4odHlwZWQgcmVmdXNhbCBvbiB6ZXJvL2FtYmlndW91cyBvY2N1cnJlbmNlLCBcIn08X2NvbXBvbmVudHMuZW0+e1wiaW5jbHVkaW5nIHN1YnN0cmluZ3Mgb2YgbG9uZ2VyXFxuZm9ybXVsYXNcIn08L19jb21wb25lbnRzLmVtPntcIikuIFwifTxfY29tcG9uZW50cy5lbT57XCJCb29rZWQgYXMgdGhlIHN1Y2Nlc3NvciwgcHJvbW90aW9uIGNyaXRlcmlvbiBzdGF0ZWQ6XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgYSBidWlsZC10aW1lIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNwYW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxub24gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQ2VsbERlc2NyaXB0b3JcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGJlY29tZXMgdGhlIG1lY2hhbmlzbSB3aGVuIHJlZnVzYWxzIGFubm95IGluIHByYWN0aWNlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiU2NyYXRjaCBpcyBhIHdvcmtzaGVldCwgbm90IGEgUkVQTC5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgT25lIGJ1ZmZlciB3aXRoIGZ1bGwgd29ya3NoZWV0IGdyYW1tYXIgcmV1c2VzXFxudGhlIGVudGlyZSBlbmdpbmUvdmVyZGljdCBwaXBlbGluZSBhbmQga2VlcHMgdGhlIHByb2R1Y3QncyBuYW1lZC1jZWxsIHNlbWFudGljczsgYVxcbmJlc3Bva2UgZXhwcmVzc2lvbiBSRVBMIHdvdWxkIGJlIGEgc2Vjb25kIGV2YWx1YXRpb24gZ3JhbW1hciB0byBzZWN1cmUgYW5kIGRvY3VtZW50LlxcblwifTxfY29tcG9uZW50cy5lbT57XCJSZWplY3RlZDpcIn08L19jb21wb25lbnRzLmVtPntcIiBwZXItcHJvYmUgaW5wdXQgYm94ZXM7IGFuIGV4cHJlc3Npb24tb25seSBldmFsdWF0b3IuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJTY3JhdGNoIHRlc3RzIG1heSBub3QgdGFyZ2V0IGR1cmFibGUgc3ViamVjdHMgaW4gdjEgKFdJRi1SNikuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFJlZnVzYWwgaXMgdGhlIG9ubHlcXG5vcHRpb24gdGhhdCBrZWVwcyBcXFwic2NyYXRjaCBpcyBhZGRpdGl2ZVxcXCIgdHJ1ZSBmb3IgdmVyZGljdHMgYXMgd2VsbCBhcyB2YWx1ZXMgd2l0aG91dCBhXFxuZGlmZi1sYWJlbGluZyBzY2hlbWU7IHRoZSBwcm9iZS1hLWR1cmFibGUtY2VsbCBmZWF0dXJlIGlzIFE1LCB0byBiZSBkZXNpZ25lZCB3aXRoIGl0c1xcbmxhYmVsaW5nLCBub3Qgc2xpcHBlZCBpbi4gXCJ9PF9jb21wb25lbnRzLmVtPntcIlJlamVjdGVkOlwifTwvX2NvbXBvbmVudHMuZW0+e1wiIHNpbGVudCBtZXJnZSBpbnRvIGR1cmFibGUgc3VpdGVzICh2ZXJkaWN0XFxuY29udGFtaW5hdGlvbiBpbmRpc3Rpbmd1aXNoYWJsZSBmcm9tIGEgcmVhbCByZWdyZXNzaW9uKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkV4cGxpY2l0IFJ1biwgbm90IGV2YWx1YXRlLW9uLWtleXN0cm9rZS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgQSBzaGFkb3cgcnVuIGlzIGJ1aWxkICsgcGFzcyArIHN1aXRlIHdpdGhcXG51bm1lYXN1cmVkIGJyb3dzZXIgbGF0ZW5jeSwgbWFpbi10aHJlYWQgb24gdGhlIHBsYXRmb3JtIHRvZGF5LiBcIn08X2NvbXBvbmVudHMuZW0+e1wiUmVqZWN0ZWQ6XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgZGVib3VuY2VkXFxuY29udGludW91cyBldmFsdWF0aW9uIChyZXZpc2l0IHVuZGVyIFExIHdoZW4gcmVhbCB3b3JrZXJzIGxhbmQgYW5kIGEgbWVhc3VyZW1lbnRcXG5leGlzdHMpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRXBoZW1lcmFsIHJlc3VsdHM7IHNlc3Npb24tc2NvcGVkIHRleHQ7IG5vIGFwcGx5IChXSUYtUjkpLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBQZXJzaXN0ZW5jZSByb3V0ZXNcXG5leGlzdCAoZWRpdC1maWxlLCBjb250cmlidXRlKSBhbmQgZ2F0ZXMgZXhpc3QgKFJTLTEwL2ZyZWV6ZSk7IHdpcmluZyB0aGVtIGlzIHNlcGFyYXRlXFxud29yayB3aXRoIGl0cyBvd24gcmV2aWV3LiBCdXQgdXNlci10eXBlZCBcIn08X2NvbXBvbmVudHMuZW0+e1widGV4dFwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGlzIG5vdCBhIHNlY3VyaXR5IGFydGlmYWN0OiBpdFxcbnN1cnZpdmVzIHBhbmVsIGNsb3NlLCBpcyBjb3B5YWJsZSwgYW5kIENsZWFyIGNvbmZpcm1zLiBcIn08X2NvbXBvbmVudHMuZW0+e1wiUmVqZWN0ZWQ6XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgYW4gYXBwbHkgYnV0dG9uXFxuZ2F0ZWQgb24gd3JpdGFiaWxpdHkgaW4gdjE7IGRpc2NhcmQtb24tY2xvc2Ugb2YgdHlwZWQgc291cmNlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVGhlIHBhbmVsIGxpdmVzIGluIHRoZSBpbnNwZWN0b3IgLyB3b3JrYm9vayBwYW5lbCwgbm90IHRoZSByZXBvcnQuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFZhbHVlIDI6XFxucnVuLW1vZGUgY2hyb21lIHN0YXlzIGNsZWFuOyB0aGUgdHdvIGRvb3JzIHRoYXQgYWxyZWFkeSBtZWFuIFxcXCJJJ20gbG9va2luZyBiZWhpbmQgdGhlXFxucmVwb3J0XFxcIiBhcmUgdGhlIHJpZ2h0IGRvb3JzLiBcIn08X2NvbXBvbmVudHMuZW0+e1wiUmVqZWN0ZWQ6XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgb24tcGl4ZWwgXFxcInRyeSBhIHZhcmlhbnRcXFwiIGFmZm9yZGFuY2VzIGluIHRoZVxcbnJlcG9ydCB2aWV3IChWMydzIGluc3BlY3Rpb24gYWZmb3JkYW5jZSBtYXkgXCJ9PF9jb21wb25lbnRzLmVtPntcIm9wZW5cIn08L19jb21wb25lbnRzLmVtPntcIiB0aGUgaW5zcGVjdG9yLCB3aGljaCB0aGVuIG9mZmVyc1xcbndoYXQtaWYpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaHIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtMTFcIiBkYXRhLXNsdWc9XCIxMS1hZHZlcnNhcmlhbC1yZXZpZXctcmVjb3JkXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtMTFcIiAvPntcIjExLiBBZHZlcnNhcmlhbCByZXZpZXcgIFwifTxfY29tcG9uZW50cy5lbT57XCIocmVjb3JkKVwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlBhc3MgMSAoMjAyNi0wOC0yNywgZnJlc2gtYWdlbnQpLCBXSUYtUjHigKZXSUYtUjExIOKAlCBhbGwgZm9sZGVkIGludG8gdGhpcyByZXZpc2lvbjpcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIldJRi1SMSBbQkxPQ0tFUl1cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXFxcInN0cnVjdHVyYWwgaXNvbGF0aW9uXFxcIiBmYWxzZSBvbiB0aGUgaW4tcHJvY2VzcyBwYXRoIChzaGFyZWRcXG51bmhhcmRlbmVkIHJlYWxtLCBzaGFyZWQgaW5wdXQgcmVmZXJlbmNlcykg4oaSIMKnNSByZXdyaXR0ZW4gcGVyLXRyYW5zcG9ydDsgwqcyLjFcXG5kZWVwLWNvcGllZCBiYXNlbGluZTsgRy1XSUYtMiBleHRlbmRlZCB3aXRoIHRoZSBpbnB1dC1tdXRhdGlvbiBjYXNlOyDCpzEwIGRlY2lzaW9uXFxucmV3b3JkZWQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJXSUYtUjIgW0JMT0NLRVJdXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHdhdGNoZG9nIGNhbm5vdCBpbnRlcnJ1cHQgc3luY2hyb25vdXMgZGl2ZXJnZW5jZSBpbi1wcm9jZXNzIOKGklxcbsKnNSBzdGF0ZXMgdGhlIHRydWUgZmFpbHVyZSBtb2RlIGFzIGEgbmFtZWQgcmVzaWR1YWw7IHRoZSBcXFwiYnVkZ2V0IHRyaXBzXFxcIiBjbGFpbSBzdHJ1Y2suXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJXSUYtUjMgW0JMT0NLRVJdXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIG5vIHBpbm5lZCBkaWZmIGJhc2VsaW5lIHVuZGVyIGxpdmUgZmVlZHM7IG1pZC1wYXNzL3BlbmRpbmctc2xvdFxcbnNuYXBzaG90IGhhemFyZHMg4oaSIMKnMi4xIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNldHRsZWRTbmFwc2hvdCgpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjsgRy1XSUYtMy9HLVdJRi00IHJld3JpdHRlbiAodGlja2luZy1mZWVkXFxuZ2F0ZSkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJXSUYtUjQgW01BSk9SXVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB0cmFuc2Zvcm0gXFxcInByZWZpeGVzXFxcIiBvdmVyY2xhaW0gKyBzdWJzdHJpbmctYW1iaWd1aXR5IG9taXR0ZWQg4oaSXFxuwqczLjMgbGluZS1hbmNob3JpbmcgcHJlcmVxdWlzaXRlIChHLVdJRi0xYSk7IMKnMy4xIHN1YnN0cmluZyBjYXNlICsgaG9uZXN0IGF2YWlsYWJpbGl0eVxcbnN0YXRlbWVudDsgYW5jaG9yIHJvdyBjb3JyZWN0ZWQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJXSUYtUjUgW01BSk9SXVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBzY3JhdGNoIGV4dGVybmFscyBieXBhc3MgeHJlZiB2YWxpZGF0aW9uIChzaWxlbnQgbnVsbHMpIOKGkiDCpzMuMlxcbnNoYWRvdyByZS12YWxpZGF0aW9uOyBHLVdJRi0xMC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIldJRi1SNiBbTUFKT1JdXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHNjcmF0Y2ggdGVzdHMgY2FuIGZsaXAgZHVyYWJsZSBzdWJqZWN0cycgdmVyZGljdHMg4oaSIMKnMS4yL8KnNFxcbnJlZnVzYWwgcnVsZTsgRy1XSUYtNmE7IFE1IGJvb2tzIHRoZSBmZWF0dXJlIHByb3Blcmx5LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiV0lGLVI3IFtNQUpPUl1cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgZmFsc2UgXFxcIkNhbGRlcmEgbGl2ZSBkZW1vIC8gcGVyIGRyYWcgLyBwcm92ZXMgaW50ZXJhY3RpdmVcXFwiIGNsYWltcztcXG51bmRlcnN0YXRlZCBjb3N0IOKGkiDCpzAvwqcyLjMgY29ycmVjdGVkIChidWlsZCtwYXNzK3N1aXRlLCB1bm1lYXN1cmVkLCBOb2RlLWhhcm5lc3MgZ2F0ZVxcbkctV0lGLTkgb25seSkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJXSUYtUjggW01BSk9SXVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBtb2JpbGUgYWJzZW50ICh0aGUgUkItNCByZXBlYXQpIOKGkiDCpzEuNS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIldJRi1SOSBbTUFKT1JdXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGRpc2NhcmQtb24tY2xvc2UgZGF0YS1sb3NzIHRyYXAg4oaSIMKnMS40IChzZXNzaW9uLXNjb3BlZCB0ZXh0LFxcbmNvbmZpcm1lZCBDbGVhciwgY29weSBhZmZvcmRhbmNlKTsgRy1XSUYtMTEuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJXSUYtUjEwIFtNSU5PUl1cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgd2lraS1zdHlsZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJbWyNzZWMtTl1dXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhbmNob3JzIHVudXNlZCBpbiB0aGlzIHJlcG8g4oaSIGNvbnZlcnRlZFxcbnRvIHBsYWluIMKnTi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIldJRi1SMTEgW01JTk9SXVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB0aGUgZXh0ZXJuYWxzLXNuYXBzaG90IGJ1bGxldCBmaWxlZCB1bmRlciBcXFwiaG9sZHMgdG9kYXlcXFwiIOKGkiDCpzIuMlxcbnJld29yZGVkIHRvIHRoZSBwcm9wZXJ0eSB0aGF0IGhvbGRzOyBzbmFwc2hvdCBsaXZlcyBvbmx5IGluIG11c3QtZXN0YWJsaXNoLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaHIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtMTJcIiBkYXRhLXNsdWc9XCIxMi1vcGVuLXF1ZXN0aW9uc1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTEyXCIgLz57XCIxMi4gT3BlbiBxdWVzdGlvbnNcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJRMVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgV2hlbiB0aGUgcGxhdGZvcm0gbGVhcm5zIFwifTxfY29tcG9uZW50cy5jb2RlPntcImltcG9ydC5tZXRhLnVybFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKHJlYWwgd29ya2VycyBpbi1wbGF0Zm9ybSksIHNob3VsZFxcbnRoZSBzaGFkb3cgZGVmYXVsdCB0byBjb250aW51b3VzIGV2YWx1YXRpb24/IFJlcXVpcmVzIHRoZSBicm93c2VyIG1lYXN1cmVtZW50IMKnMi4zXFxuYm9va3MuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJRMlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgVGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNjcmF0Y2hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG5hbWUgY29sbGlzaW9uOiByZW5hbWUgYWZmb3JkYW5jZSwgb3IgbWFrZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzY3JhdGNoXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhIHJlc2VydmVkXFxud29ya3NoZWV0IG5hbWUgdGhlIGxvYWRlciByZWZ1c2VzIGluIGRvY3VtZW50cz9cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlEzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBNdWx0aS12YXJpYW50IHN3ZWVwcyAoTiBzaGFkb3cgcGFzc2VzKTogc3VyZmFjZSBkZXNpZ247IHdoZXRoZXIgcmVzdWx0c1xcbm1lbW9pemUgYWNyb3NzIHZhcmlhbnRzIHNoYXJpbmcgYSB0b3BvLW9yZGVyIHByZWZpeC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlE0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBJbiBhIHNoYXJlZC9jb21wb3NpdGUgZGVwbG95bWVudCwgZG9lcyB0aGUgd2hhdC1pZiBwYW5lbCBuZWVkIGFcXG5kZXBsb3ltZW50LXNoYXBlIHN3aXRjaCwgb3IgaXMgaW5zcGVjdG9yLXByZXNlbmNlIHRoZSByaWdodCBwcm94eSAowqc1KT9cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlE1XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBBZC1ob2Mgc2NyYXRjaCB0ZXN0cyBvbiBkdXJhYmxlIHN1YmplY3RzOiBkZXNpZ24gdGhlIHZlcmRpY3QtZGlmZiBsYWJlbGluZ1xcbihcXFwibmV3IHNjcmF0Y2ggdGVzdFxcXCIgdnMgXFxcImZsaXBwZWQgYnkgdmFyaWFudFxcXCIpIHRoYXQgd291bGQgbWFrZSB0aGlzIHNhZmUgdG8gYWxsb3cuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJRNlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgVGhlIHN0cnVjdHVyZWQgKG5vLWNvZGUpIG1vYmlsZSB2YXJpYW50IGZsb3cgKMKnMS41J3MgYm9va2VkIHZhbHVlLTggZGVidCkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJRN1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibG9ja2Rvd24oKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgb24gdGhlIG1haW4gcmVhbG0gZm9yIHRoZSBpbi1wcm9jZXNzIHBhdGg6IG1lYXN1cmUgd2hhdCBpdFxcbmJyZWFrcyAoUmVhY3QsIHZlbmRvcmVkIGxpYnMpIGJlZm9yZSBkZWNpZGluZy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+PC8+O1xufVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTURYQ29udGVudChwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHt3cmFwcGVyOiBNRFhMYXlvdXR9ID0ge1xuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfTtcbiAgcmV0dXJuIE1EWExheW91dCA/IDxNRFhMYXlvdXQgey4uLnByb3BzfT48X2NyZWF0ZU1keENvbnRlbnQgey4uLnByb3BzfSAvPjwvTURYTGF5b3V0PiA6IF9jcmVhdGVNZHhDb250ZW50KHByb3BzKTtcbn1cbmZ1bmN0aW9uIF9taXNzaW5nTWR4UmVmZXJlbmNlKGlkLCBjb21wb25lbnQsIHBsYWNlKSB7XG4gIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIFwiICsgKGNvbXBvbmVudCA/IFwiY29tcG9uZW50XCIgOiBcIm9iamVjdFwiKSArIFwiIGBcIiArIGlkICsgXCJgIHRvIGJlIGRlZmluZWQ6IHlvdSBsaWtlbHkgZm9yZ290IHRvIGltcG9ydCwgcGFzcywgb3IgcHJvdmlkZSBpdC5cIiArIChwbGFjZSA/IFwiXFxuSXTigJlzIHJlZmVyZW5jZWQgaW4geW91ciBjb2RlIGF0IGBcIiArIHBsYWNlICsgXCJgIGluIGAvYXBwL2RvY3Mvc3BlY3MvV0hBVElGX1NIQURPV19FVkFMVUFUSU9OX1NQRUMubWRgXCIgOiBcIlwiKSk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUVBLElBQUFBLFlBQUEsR0FBQUMsT0FBQTtBQUF3RixJQUFBQyxXQUFBLEdBQUFELE9BQUE7QUFGeEY7QUFDQTs7QUFFQSxTQUFTRSxpQkFBaUJBLENBQUNDLEtBQUssRUFBRTtFQUNoQyxNQUFNQyxXQUFXLEdBQUc7TUFDbEJDLFVBQVUsRUFBRSxZQUFZO01BQ3hCQyxJQUFJLEVBQUUsTUFBTTtNQUNaQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxDQUFDLEVBQUUsR0FBRztNQUNOQyxHQUFHLEVBQUUsS0FBSztNQUNWQyxNQUFNLEVBQUUsUUFBUTtNQUNoQkMsS0FBSyxFQUFFLE9BQU87TUFDZEMsS0FBSyxFQUFFLE9BQU87TUFDZEMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsS0FBSyxFQUFFLE9BQU87TUFDZEMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUixHQUFHLElBQUFDLDZCQUFrQixFQUFDLENBQUM7TUFDdkIsR0FBR3BCLEtBQUssQ0FBQ3FCO0lBQ1gsQ0FBQztJQUFFO01BQUNDO0lBQWEsQ0FBQyxHQUFHckIsV0FBVztFQUNoQyxJQUFJLENBQUNxQixhQUFhLEVBQUVDLG9CQUFvQixDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUM7RUFDL0Qsb0JBQU8sSUFBQXpCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQTFCLFdBQUEsQ0FBQTJCLFFBQUE7SUFBQUMsUUFBQSxnQkFBRSxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDSSxFQUFFO01BQUNzQixFQUFFLEVBQUMsa0dBQWtHO01BQUFELFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBa0csQ0FBRSxDQUFDLEVBQUMsb0dBQW9HO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUyxDQUFDO01BQUFnQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVMsQ0FBcUIsQ0FBQyxFQUFDLHdLQUF3SyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVUsQ0FBcUIsQ0FBQyxFQUFDLGFBQWE7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNTLENBQUM7TUFBQWdCLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDRyxFQUFFO1FBQUFzQixRQUFBLEdBQUUscU9BQXFPLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQVUsQ0FBbUIsQ0FBQyxFQUFDLG1HQUFtRztNQUFBLENBQWlCO0lBQUMsQ0FBZSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNDLFVBQVU7TUFBQXdCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1MsQ0FBQztRQUFBZ0IsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsR0FBRSw0REFBNEQsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1lBQUF1QixRQUFBLEVBQUU7VUFBZ0QsQ0FBbUIsQ0FBQztRQUFBLENBQW9CLENBQUMsRUFBQyx3RUFBd0U7TUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQXlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ0MsVUFBVTtNQUFBd0IsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUyxDQUFDO1FBQUFnQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWMsQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBc0IsQ0FBbUIsQ0FBQyxFQUFDLGlJQUFpSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUErQixDQUFtQixDQUFDLEVBQUMsbUZBQW1GLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQWlDLENBQW1CLENBQUMsRUFBQyxpREFBaUQsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBOEIsQ0FBbUIsQ0FBQyxFQUFDLGdCQUFnQixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLEVBQUU7VUFBQXNCLFFBQUEsRUFBRTtRQUFLLENBQWlCLENBQUMsRUFBQyxtRkFBbUY7TUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQXlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ08sRUFBRSxJQUFFLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQVYsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDSyxFQUFFO01BQUNxQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUseUVBQXlFO01BQUFELFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQyxpREFBaUQsZUFBQyxJQUFBN0IsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxFQUFFO1FBQUFzQixRQUFBLEVBQUU7TUFBa0MsQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBZ0IsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBd0IsQ0FBbUIsQ0FBQyxFQUFDLGdCQUFnQixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLEVBQUU7UUFBQXNCLFFBQUEsRUFBRTtNQUEwRCxDQUFpQixDQUFDLEVBQUMsYUFBYSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQUssQ0FBcUIsQ0FBQyxFQUFDLDRKQUE0SixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLEVBQUU7UUFBQXNCLFFBQUEsRUFBRTtNQUE0QixDQUFpQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLEVBQUU7UUFBQXNCLFFBQUEsRUFBRTtNQUF3QixDQUFpQixDQUFDLEVBQUMsNlFBQTZRO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUyxDQUFDO01BQUFnQixRQUFBLEdBQUUsc0JBQXNCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBc0IsUUFBQSxFQUFFO01BQWMsQ0FBaUIsQ0FBQyxFQUFDLG9EQUFvRDtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ0MsVUFBVTtNQUFBd0IsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUyxDQUFDO1FBQUFnQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWtCLENBQXFCLENBQUMsRUFBQyx5REFBeUQsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxFQUFFO1VBQUFzQixRQUFBLEVBQUU7UUFBUyxDQUFpQixDQUFDLEVBQUMsNEZBQTRGLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBZ0YsQ0FBcUIsQ0FBQyxFQUFDLEdBQUc7TUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQXlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLDJCQUEyQixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQWUsQ0FBcUIsQ0FBQyxFQUFDLHNIQUFzSCxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQWEsQ0FBcUIsQ0FBQyxFQUFDLG1MQUFtTDtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBZ0IsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFxQyxDQUFxQixDQUFDLEVBQUMsa0hBQWtILGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBc0IsUUFBQSxFQUFFO01BQThCLENBQWlCLENBQUMsRUFBQyxPQUFPLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBc0IsUUFBQSxFQUFFO01BQWtCLENBQWlCLENBQUMsRUFBQyxvRkFBb0Y7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNPLEVBQUUsSUFBRSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFWLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDcUIsRUFBRSxFQUFDLE9BQU87TUFBQyxhQUFVLGdEQUFnRDtNQUFBRCxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMsc0JBQXNCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBc0IsUUFBQSxFQUFFO01BQWtDLENBQWlCLENBQUM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNNLEVBQUU7TUFBQ29CLEVBQUUsRUFBQyxTQUFTO01BQUMsYUFBVSxnQ0FBZ0M7TUFBQUQsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFTLENBQUUsQ0FBQyxFQUFDLG1DQUFtQztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLHVEQUF1RCxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQWEsQ0FBcUIsQ0FBQyxFQUFDLG1DQUFtQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2tCLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLEdBQUUsY0FBYyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQVMsQ0FBcUIsQ0FBQyxFQUFDLHVFQUF1RSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUE4QixDQUFtQixDQUFDLEVBQUMsb0NBQW9DLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBc0IsUUFBQSxFQUFFO1FBQWdCLENBQWlCLENBQUMsRUFBQyx3QkFBd0IsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsMklBQTJJO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQUssQ0FBcUIsQ0FBQyxFQUFDLDRLQUE0SztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxHQUFFLCtCQUErQixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXlCLENBQXFCLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBdUIsQ0FBcUIsQ0FBQyxFQUFDLDRGQUE0RixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQVksQ0FBcUIsQ0FBQyxFQUFDLFlBQVksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUE0QixDQUFxQixDQUFDLEVBQUMsR0FBRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFTLENBQXFCLENBQUMsRUFBQywrQ0FBK0MsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxFQUFFO1VBQUFzQixRQUFBLEVBQUU7UUFBTSxDQUFpQixDQUFDLEVBQUMseUdBQXlHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNTLENBQUM7TUFBQWdCLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDRyxFQUFFO1FBQUFzQixRQUFBLEdBQUUsZ1ZBQWdWLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLHlkQUF5ZDtNQUFBLENBQWlCO0lBQUMsQ0FBZSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNTLENBQUM7TUFBQWdCLFFBQUEsRUFBRTtJQUEyRixDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNrQixFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxFQUFFO01BQWlMLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDTSxFQUFFO01BQUNvQixFQUFFLEVBQUMsU0FBUztNQUFDLGFBQVUsbUNBQW1DO01BQUFELFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBUyxDQUFFLENBQUMsRUFBQyxzQ0FBc0M7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNTLENBQUM7TUFBQWdCLFFBQUEsR0FBRSw2QkFBNkIsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFhLENBQXFCLENBQUMsRUFBQyxrSkFBa0osZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFLLENBQXFCLENBQUMsRUFBQywyUEFBMlAsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxFQUFFO1FBQUFzQixRQUFBLEVBQUU7TUFBbUIsQ0FBaUIsQ0FBQyxFQUFDLEdBQUc7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNTLENBQUM7TUFBQWdCLFFBQUEsR0FBRSxVQUFVLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBeUMsQ0FBcUIsQ0FBQyxFQUFDLHlCQUF5QixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFTLENBQW1CLENBQUMsRUFBQyw2TEFBNkw7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNTLENBQUM7TUFBQWdCLFFBQUEsR0FBRSxxUEFBcVAsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFjLENBQXFCLENBQUMsRUFBQyxRQUFRO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDTSxFQUFFO01BQUNvQixFQUFFLEVBQUMsU0FBUztNQUFDLGFBQVUsMkJBQTJCO01BQUFELFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBUyxDQUFFLENBQUMsRUFBQyw4QkFBOEI7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNTLENBQUM7TUFBQWdCLFFBQUEsRUFBRTtJQUEwTyxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNNLEVBQUU7TUFBQ29CLEVBQUUsRUFBQyxTQUFTO01BQUMsYUFBVSxpREFBaUQ7TUFBQUQsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFTLENBQUUsQ0FBQyxFQUFDLHFEQUFxRDtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLFlBQVksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxFQUFFO1FBQUFzQixRQUFBLEVBQUU7TUFBUyxDQUFpQixDQUFDLEVBQUMscUNBQXFDLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBc0IsUUFBQSxFQUFFO01BQXVDLENBQWlCLENBQUMsRUFBQyxpREFBaUQ7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNrQixFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUF3QyxDQUFxQixDQUFDLEVBQUMseVBBQXlQO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTRCLENBQXFCLENBQUMsRUFBQyxxR0FBcUc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBa0IsQ0FBcUIsQ0FBQyxFQUFDLHdRQUF3UTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDTSxFQUFFO01BQUNvQixFQUFFLEVBQUMsU0FBUztNQUFDLGFBQVUsMEJBQTBCO01BQUFELFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBUyxDQUFFLENBQUMsRUFBQyw4QkFBOEI7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNTLENBQUM7TUFBQWdCLFFBQUEsR0FBRSwwVUFBMFUsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUF3RyxDQUFxQixDQUFDLEVBQUMsZ1FBQWdRO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDTyxFQUFFLElBQUUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBVixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNLLEVBQUU7TUFBQ3FCLEVBQUUsRUFBQyxPQUFPO01BQUMsYUFBVSxtREFBbUQ7TUFBQUQsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLHlCQUF5QixlQUFDLElBQUE3QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLEVBQUU7UUFBQXNCLFFBQUEsRUFBRTtNQUFrQyxDQUFpQixDQUFDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUyxDQUFDO01BQUFnQixRQUFBLEdBQUUsK0JBQStCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQWEsQ0FBbUIsQ0FBQyxFQUFDLDhIQUE4SDtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1UsR0FBRztNQUFBZSxRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQW1XLENBQW1CO0lBQUMsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDTSxFQUFFO01BQUNvQixFQUFFLEVBQUMsU0FBUztNQUFDLGFBQVUsK0JBQStCO01BQUFELFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBUyxDQUFFLENBQUMsRUFBQyxrQ0FBa0M7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNTLENBQUM7TUFBQWdCLFFBQUEsR0FBRSxrRkFBa0YsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBZSxDQUFtQixDQUFDLEVBQUMsd0JBQXdCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBUSxDQUFxQixDQUFDLEVBQUMsMlFBQTJRO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUyxDQUFDO01BQUFnQixRQUFBLEdBQUUsK0JBQStCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBMkIsQ0FBcUIsQ0FBQyxFQUFDLGtEQUFrRCxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFtQixDQUFtQixDQUFDLEVBQUMsNEJBQTRCO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDa0IsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsRUFBRTtNQUE2SCxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsR0FBRSw4Q0FBOEMsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFLLENBQXFCLENBQUMsRUFBQyx1REFBdUQsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxFQUFFO1VBQUFzQixRQUFBLEVBQUU7UUFBMkIsQ0FBaUIsQ0FBQyxFQUFDLGlCQUFpQjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUEyQixDQUFxQixDQUFDLEVBQUMsb1hBQW9YO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNTLENBQUM7TUFBQWdCLFFBQUEsRUFBRTtJQUF5UyxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNNLEVBQUU7TUFBQ29CLEVBQUUsRUFBQyxTQUFTO01BQUMsYUFBVSx1Q0FBdUM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFTLENBQUUsQ0FBQyxFQUFDLHdDQUF3QztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLG9DQUFvQyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQU8sQ0FBcUIsQ0FBQyxFQUFDLGlCQUFpQjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2tCLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXNELENBQXFCLENBQUMsRUFBQyx5QkFBeUIsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBTyxDQUFtQixDQUFDLEVBQUMsbUNBQW1DLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQyxFQUFDLHFGQUFxRjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFxQyxDQUFxQixDQUFDLEVBQUMsd0lBQXdJO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTJDLENBQXFCLENBQUMsRUFBQyxtSkFBbUosZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxFQUFFO1VBQUFzQixRQUFBLEVBQUU7UUFBVyxDQUFpQixDQUFDLEVBQUMsNkRBQTZEO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWtDLENBQXFCLENBQUMsRUFBQyxpSEFBaUgsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxFQUFFO1VBQUFzQixRQUFBLEVBQUU7UUFBbUIsQ0FBaUIsQ0FBQyxFQUFDLGtIQUFrSDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUyxDQUFDO01BQUFnQixRQUFBLEdBQUUsc0NBQXNDLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQStCLENBQW1CLENBQUMsRUFBQyx1TUFBdU0sZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBMkIsQ0FBbUIsQ0FBQyxFQUFDLHdDQUF3QyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFXLENBQW1CLENBQUMsRUFBQyxrRUFBa0UsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxFQUFFO1FBQUFzQixRQUFBLEVBQUU7TUFBTSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDb0IsRUFBRSxFQUFDLFNBQVM7TUFBQyxhQUFVLHlCQUF5QjtNQUFBRCxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVMsQ0FBRSxDQUFDLEVBQUMsNkJBQTZCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUyxDQUFDO01BQUFnQixRQUFBLEdBQUUsa0JBQWtCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBTSxDQUFxQixDQUFDLEVBQUMsK0ZBQStGLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBRyxDQUFxQixDQUFDLEVBQUMsYUFBYSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQUcsQ0FBcUIsQ0FBQyxFQUFDLHlFQUF5RSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVksQ0FBcUIsQ0FBQyxFQUFDLHNaQUFzWjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ08sRUFBRSxJQUFFLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQVYsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDSyxFQUFFO01BQUNxQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUsZ0RBQWdEO01BQUFELFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQyxzQkFBc0IsZUFBQyxJQUFBN0IsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxFQUFFO1FBQUFzQixRQUFBLEVBQUU7TUFBa0MsQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDb0IsRUFBRSxFQUFDLFNBQVM7TUFBQyxhQUFVLDhDQUE4QztNQUFBRCxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVMsQ0FBRSxDQUFDLEVBQUMsaURBQWlEO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUyxDQUFDO01BQUFnQixRQUFBLEdBQUUscUJBQXFCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQVMsQ0FBbUIsQ0FBQyxFQUFDLHlFQUF5RSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFJLENBQW1CLENBQUMsRUFBQyxvREFBb0QsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBZSxDQUFtQixDQUFDLEVBQUMsMENBQTBDLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQTZCLENBQW1CLENBQUMsRUFBQywwRkFBMEYsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFlLENBQXFCLENBQUMsRUFBQyx5RUFBeUU7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNTLENBQUM7TUFBQWdCLFFBQUEsRUFBRTtJQUEwRSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNrQixFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBbUIsQ0FBbUIsQ0FBQyxFQUFDLHVIQUF1SDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBbUIsQ0FBbUIsQ0FBQyxFQUFDLGlEQUFpRCxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQU0sQ0FBcUIsQ0FBQyxFQUFDLCtCQUErQixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQUssQ0FBcUIsQ0FBQyxFQUFDLG9EQUFvRCxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFTLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQVksQ0FBbUIsQ0FBQyxFQUFDLGtGQUFrRixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQThDLENBQXFCLENBQUMsRUFBQyw2S0FBNkssZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLGtGQUFrRjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDUyxDQUFDO01BQUFnQixRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBc0IsUUFBQSxHQUFFLDhOQUE4TixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXFDLENBQXFCLENBQUMsRUFBQyxvU0FBb1MsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsa0lBQWtJO01BQUEsQ0FBaUI7SUFBQyxDQUFlLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLDhJQUE4SSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFhLENBQW1CLENBQUMsRUFBQyxzQ0FBc0M7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNNLEVBQUU7TUFBQ29CLEVBQUUsRUFBQyxTQUFTO01BQUMsYUFBVSw2REFBNkQ7TUFBQUQsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFTLENBQUUsQ0FBQyxFQUFDLGlFQUFpRTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLHVGQUF1RixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFTLENBQW1CLENBQUMsRUFBQyx3REFBd0QsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBUyxDQUFtQixDQUFDLEVBQUMsaVRBQWlUO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUyxDQUFDO01BQUFnQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQStELENBQXFCLENBQUMsRUFBQyx1SUFBdUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBTSxDQUFtQixDQUFDLEVBQUMsNEJBQTRCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQXNCLENBQW1CLENBQUMsRUFBQyxxRUFBcUUsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBNEIsQ0FBbUIsQ0FBQyxFQUFDLDZCQUE2QixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFzQixDQUFtQixDQUFDLEVBQUMseUxBQXlMO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDTSxFQUFFO01BQUNvQixFQUFFLEVBQUMsU0FBUztNQUFDLGFBQVUsbUNBQW1DO01BQUFELFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBUyxDQUFFLENBQUMsRUFBQyx1Q0FBdUM7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNTLENBQUM7TUFBQWdCLFFBQUEsR0FBRSxxRkFBcUYsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBYyxDQUFtQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFPLENBQW1CLENBQUMsRUFBQyxpQ0FBaUMsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFpQyxDQUFxQixDQUFDLEVBQUMsdUJBQXVCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQWMsQ0FBbUIsQ0FBQyxFQUFDLDRFQUE0RSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFvQixDQUFtQixDQUFDLEVBQUMsNkpBQTZKLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBZSxDQUFxQixDQUFDLEVBQUMscUdBQXFHLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQWMsQ0FBbUIsQ0FBQyxFQUFDLG1FQUFtRSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLEVBQUU7UUFBQXNCLFFBQUEsRUFBRTtNQUFNLENBQWlCLENBQUMsRUFBQyx5REFBeUQ7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNNLEVBQUU7TUFBQ29CLEVBQUUsRUFBQyxTQUFTO01BQUMsYUFBVSw0QkFBNEI7TUFBQUQsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFTLENBQUUsQ0FBQyxFQUFDLDZCQUE2QjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLHFPQUFxTyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFlLENBQW1CLENBQUMsRUFBQywwQ0FBMEMsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxFQUFFO1FBQUFzQixRQUFBLEVBQUU7TUFBTSxDQUFpQixDQUFDLEVBQUMsMkRBQTJEO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDTyxFQUFFLElBQUUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBVixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNLLEVBQUU7TUFBQ3FCLEVBQUUsRUFBQyxPQUFPO01BQUMsYUFBVSwyREFBMkQ7TUFBQUQsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLGlDQUFpQyxlQUFDLElBQUE3QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLEVBQUU7UUFBQXNCLFFBQUEsRUFBRTtNQUFrQyxDQUFpQixDQUFDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDUyxDQUFDO01BQUFnQixRQUFBLEVBQUU7SUFBK0MsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDa0IsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBb0IsQ0FBcUIsQ0FBQyxFQUFDLG1DQUFtQyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFxQixDQUFtQixDQUFDLEVBQUMsa0RBQWtELGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBc0IsUUFBQSxFQUFFO1FBQUssQ0FBaUIsQ0FBQyxFQUFDLHFEQUFxRCxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFNLENBQW1CLENBQUMsRUFBQywwSkFBMEo7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBWSxDQUFxQixDQUFDLEVBQUMsMkJBQTJCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBc0IsQ0FBcUIsQ0FBQyxFQUFDLGdCQUFnQixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFZLENBQW1CLENBQUMsRUFBQyx3SkFBd0o7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBYyxDQUFxQixDQUFDLEVBQUMseUNBQXlDLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQVUsQ0FBbUIsQ0FBQyxFQUFDLHNLQUFzSztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUyxDQUFDO01BQUFnQixRQUFBLEdBQUUsbURBQW1ELGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBSyxDQUFxQixDQUFDLEVBQUMsMktBQTJLO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUyxDQUFDO01BQUFnQixRQUFBLEdBQUUsa01BQWtNLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBaUMsQ0FBcUIsQ0FBQyxFQUFDLGtCQUFrQixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQXNDLENBQXFCLENBQUMsRUFBQyw2RkFBNkY7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNPLEVBQUUsSUFBRSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFWLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDcUIsRUFBRSxFQUFDLE9BQU87TUFBQyxhQUFVLG1EQUFtRDtNQUFBRCxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMsMkJBQTJCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBc0IsUUFBQSxFQUFFO01BQWtDLENBQWlCLENBQUM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNTLENBQUM7TUFBQWdCLFFBQUEsR0FBRSxpQkFBaUIsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUF1RCxDQUFxQixDQUFDLEVBQUMsZ0RBQWdELGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBaUMsQ0FBcUIsQ0FBQyxFQUFDLHFGQUFxRjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2tCLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXVDLENBQXFCLENBQUMsRUFBQyw0U0FBNFM7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEdBQUUsOEZBQThGLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBdUIsUUFBQSxFQUFFO1VBQWlCLENBQW1CLENBQUMsRUFBQyxJQUFJO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLG1DQUFtQyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFZLENBQW1CLENBQUMsRUFBQyxvR0FBb0csZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBYSxDQUFtQixDQUFDLEVBQUMsc0RBQXNEO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWlHLENBQXFCLENBQUMsRUFBQywrREFBK0QsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFLLENBQXFCLENBQUMsRUFBQyxxREFBcUQsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxFQUFFO1VBQUFzQixRQUFBLEVBQUU7UUFBYyxDQUFpQixDQUFDLEVBQUMsK0pBQStKLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEdBQUUsc0NBQXNDLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBdUIsUUFBQSxFQUFFO1VBQWEsQ0FBbUIsQ0FBQyxFQUFDLGdDQUFnQztRQUFBLENBQXFCLENBQUMsRUFBQyw2SkFBNkosZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBVSxDQUFtQixDQUFDLEVBQUMsU0FBUyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTZDLENBQXFCLENBQUMsRUFBQyxnU0FBZ1MsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxFQUFFO1VBQUFzQixRQUFBLEVBQUU7UUFBa0IsQ0FBaUIsQ0FBQyxFQUFDLHNGQUFzRixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFZLENBQW1CLENBQUMsRUFBQyxzRkFBc0Y7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBOEMsQ0FBcUIsQ0FBQyxFQUFDLDJKQUEySixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUErQixDQUFtQixDQUFDLEVBQUMsMFVBQTBVO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWtDLENBQXFCLENBQUMsRUFBQyxvTEFBb0w7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBMEIsQ0FBcUIsQ0FBQyxFQUFDLHlEQUF5RCxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLEVBQUU7VUFBQXNCLFFBQUEsRUFBRTtRQUFRLENBQWlCLENBQUMsRUFBQywrUUFBK1E7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ08sRUFBRSxJQUFFLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQVYsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDSyxFQUFFO01BQUNxQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUsb0VBQW9FO01BQUFELFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQyw0Q0FBNEMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxFQUFFO1FBQUFzQixRQUFBLEVBQUU7TUFBa0MsQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2tCLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQThELENBQXFCLENBQUMsRUFBQyxlQUFlLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQU8sQ0FBbUIsQ0FBQyxFQUFDLDREQUE0RCxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyw0SEFBNEg7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBNkQsQ0FBcUIsQ0FBQyxFQUFDLHdKQUF3SjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUE2QixDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUEyQixDQUFtQixDQUFDLEVBQUMscURBQXFELGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBZSxDQUFxQixDQUFDLEVBQUMsdUlBQXVJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBc0IsUUFBQSxFQUFFO1FBQVMsQ0FBaUIsQ0FBQyxFQUFDLG9GQUFvRixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLEVBQUU7VUFBQXNCLFFBQUEsRUFBRTtRQUFpQixDQUFpQixDQUFDLEVBQUMsa09BQWtPLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLDBEQUEwRDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDTyxFQUFFLElBQUUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBVixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNLLEVBQUU7TUFBQ3FCLEVBQUUsRUFBQyxPQUFPO01BQUMsYUFBVSx5RkFBeUY7TUFBQUQsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLDBDQUEwQyxlQUFDLElBQUE3QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLEVBQUU7UUFBQXNCLFFBQUEsRUFBRTtNQUEwRCxDQUFpQixDQUFDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDa0IsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBa0IsQ0FBcUIsQ0FBQyxFQUFDLCtJQUErSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyx3RkFBd0YsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxFQUFFO1VBQUFzQixRQUFBLEVBQUU7UUFBSyxDQUFpQixDQUFDLEVBQUMsa0RBQWtEO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXFCLENBQXFCLENBQUMsRUFBQyx1SEFBdUg7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBdUIsQ0FBcUIsQ0FBQyxFQUFDLDRFQUE0RTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUF5QyxDQUFxQixDQUFDLEVBQUMsNkpBQTZKLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBc0IsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLG1CQUFtQjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFrQyxDQUFxQixDQUFDLEVBQUMsNEhBQTRIO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNPLEVBQUUsSUFBRSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFWLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDcUIsRUFBRSxFQUFDLE9BQU87TUFBQyxhQUFVLGlFQUFpRTtNQUFBRCxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMsWUFBWSxlQUFDLElBQUE3QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLEVBQUU7UUFBQXNCLFFBQUEsRUFBRTtNQUE4RCxDQUFpQixDQUFDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDWSxLQUFLO01BQUFhLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2dCLEtBQUs7UUFBQVMsUUFBQSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNpQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBTSxDQUFpQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDZSxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFNLENBQWlCLENBQUM7UUFBQSxDQUFnQjtNQUFDLENBQW1CLENBQUMsbUJBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNhLEtBQUs7UUFBQVksUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDaUIsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQVMsQ0FBcUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsR0FBRSw0R0FBNEcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBbUIsQ0FBbUIsQ0FBQyxFQUFDLDBCQUEwQixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFtQixDQUFtQixDQUFDLEVBQUMsc0JBQXNCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBSyxDQUFxQixDQUFDLEVBQUMsOEVBQThFO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNpQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBVSxDQUFxQjtVQUFDLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxHQUFFLG9GQUFvRixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFvQixDQUFtQixDQUFDLEVBQUMsdUJBQXVCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQWUsQ0FBbUIsQ0FBQyxFQUFDLDZDQUE2QztVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDaUIsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQVMsQ0FBcUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsR0FBRSxzR0FBc0csZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDVyxNQUFNO2NBQUFjLFFBQUEsR0FBRSxzQ0FBc0MsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2dCQUFBdUIsUUFBQSxFQUFFO2NBQVksQ0FBbUIsQ0FBQyxFQUFDLFlBQVk7WUFBQSxDQUFxQixDQUFDLEVBQUMsZ0dBQWdHLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csRUFBRTtjQUFBc0IsUUFBQSxFQUFFO1lBQXdCLENBQWlCLENBQUMsRUFBQyxtRkFBbUY7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFTLENBQXFCO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFtQixDQUFtQixDQUFDLEVBQUMsMFJBQTBSO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNpQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBUyxDQUFxQjtVQUFDLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxHQUFFLGlEQUFpRCxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFZLENBQW1CLENBQUMsRUFBQyx1QkFBdUIsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFRLENBQXFCLENBQUMsRUFBQyw2TkFBNk4sZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFNLENBQXFCLENBQUMsRUFBQyxVQUFVO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNpQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBUyxDQUFxQjtVQUFDLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxHQUFFLDhEQUE4RCxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFZLENBQW1CLENBQUMsRUFBQyw0RkFBNEY7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFTLENBQXFCO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBMkosQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNpQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBVSxDQUFxQjtVQUFDLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxHQUFFLDRCQUE0QixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFTLENBQW1CLENBQUMsRUFBQyw4SUFBOEk7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFTLENBQXFCO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFXLENBQW1CLENBQUMsRUFBQyx5SkFBeUo7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFTLENBQXFCO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEdBQUUsb0JBQW9CLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQVMsQ0FBbUIsQ0FBQyxFQUFDLCtGQUErRjtVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDaUIsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQVMsQ0FBcUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsR0FBRSx3QkFBd0IsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUE2QixDQUFxQixDQUFDLEVBQUMsc0tBQXNLLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csRUFBRTtjQUFBc0IsUUFBQSxFQUFFO1lBQStGLENBQWlCLENBQUM7VUFBQSxDQUFnQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFVLENBQXFCO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBNkwsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNpQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBVSxDQUFxQjtVQUFDLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQTRILENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDO01BQUEsQ0FBbUIsQ0FBQztJQUFBLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ08sRUFBRSxJQUFFLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQVYsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDSyxFQUFFO01BQUNxQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUsa0RBQWtEO01BQUFELFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQyw4Q0FBOEMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxFQUFFO1FBQUFzQixRQUFBLEVBQUU7TUFBWSxDQUFpQixDQUFDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDTSxFQUFFO01BQUNvQixFQUFFLEVBQUMsd0NBQXdDO01BQUFELFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBd0MsQ0FBRSxDQUFDLEVBQUMsMENBQTBDO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDWSxLQUFLO01BQUFhLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2dCLEtBQUs7UUFBQVMsUUFBQSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNpQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBWSxDQUFpQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDZSxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUE2QixDQUFpQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDZSxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFxQixDQUFpQixDQUFDO1FBQUEsQ0FBZ0I7TUFBQyxDQUFtQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDYSxLQUFLO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFxRSxDQUFpQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBK0IsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBZ0QsQ0FBbUI7VUFBQyxDQUFnQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUEwRSxDQUFpQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBMkIsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBMkIsQ0FBbUI7VUFBQyxDQUFnQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFvRSxDQUFpQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBMkIsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBMkIsQ0FBbUI7VUFBQyxDQUFnQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFvRSxDQUFpQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBb0IsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBeUIsQ0FBbUI7VUFBQyxDQUFnQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsR0FBRSx5REFBeUQsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBYyxDQUFtQixDQUFDLEVBQUMsK0NBQStDO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQTJCLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQWMsQ0FBbUI7VUFBQyxDQUFnQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUE0RCxDQUFpQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBbUMsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBb0IsQ0FBbUI7VUFBQyxDQUFnQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUE0RSxDQUFpQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBcUIsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBZ0UsQ0FBbUI7VUFBQyxDQUFnQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUF3RCxDQUFpQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBMkIsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBVSxDQUFtQjtVQUFDLENBQWdCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDaUIsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQTBFLENBQWlCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUF1QixDQUFtQjtVQUFDLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFvQixDQUFtQjtVQUFDLENBQWdCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDaUIsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQWdFLENBQWlCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUEwQixDQUFtQjtVQUFDLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFpQixDQUFtQjtVQUFDLENBQWdCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDaUIsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxHQUFFLDZCQUE2QixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFlLENBQW1CLENBQUMsRUFBQyxzQ0FBc0M7VUFBQSxDQUFpQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBMEIsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBdUIsQ0FBbUI7VUFBQyxDQUFnQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUErRSxDQUFpQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBMEIsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBbUIsQ0FBbUI7VUFBQyxDQUFnQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUErRCxDQUFpQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBK0IsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBMkMsQ0FBbUI7VUFBQyxDQUFnQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQVksQ0FBbUIsQ0FBQyxFQUFDLHFDQUFxQztVQUFBLENBQWlCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFxQixDQUFtQjtVQUFDLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFnQixDQUFtQjtVQUFDLENBQWdCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDaUIsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQXNELENBQWlCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUEyQixDQUFtQjtVQUFDLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFzRCxDQUFtQjtVQUFDLENBQWdCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDaUIsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQXlGLENBQWlCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUF1QixDQUFtQjtVQUFDLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFvQixDQUFtQjtVQUFDLENBQWdCLENBQUM7UUFBQSxDQUFnQixDQUFDO01BQUEsQ0FBbUIsQ0FBQztJQUFBLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDb0IsRUFBRSxFQUFDLDBEQUEwRDtNQUFBRCxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQTBELENBQUUsQ0FBQyxFQUFDLDREQUE0RDtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1ksS0FBSztNQUFBYSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNnQixLQUFLO1FBQUFTLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDaUIsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNlLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQWUsQ0FBaUIsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBdUIsQ0FBaUIsQ0FBQztRQUFBLENBQWdCO01BQUMsQ0FBbUIsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2EsS0FBSztRQUFBWSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNpQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUErQixDQUFtQixDQUFDLEVBQUMsc0NBQXNDLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQW1CLENBQW1CLENBQUM7VUFBQSxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFTLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDaUIsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQThGLENBQWlCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQW1CLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDaUIsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBMkIsQ0FBbUIsQ0FBQyxFQUFDLDZCQUE2QjtVQUFBLENBQWlCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQVMsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNpQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBNEQsQ0FBaUIsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBUyxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFnQyxDQUFpQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFVLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDaUIsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQWlFLENBQWlCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQWtCLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDaUIsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQW9FLENBQWlCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQW1CLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDaUIsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQTBELENBQWlCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQVUsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNpQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBbUQsQ0FBaUIsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBVSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQztNQUFBLENBQW1CLENBQUM7SUFBQSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNPLEVBQUUsSUFBRSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFWLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDcUIsRUFBRSxFQUFDLFFBQVE7TUFBQyxhQUFVLDhEQUE4RDtNQUFBRCxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVEsQ0FBRSxDQUFDLEVBQUMseUNBQXlDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBc0IsUUFBQSxFQUFFO01BQWdDLENBQWlCLENBQUM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNrQixFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFvRSxDQUFxQixDQUFDLEVBQUMsMFFBQTBRLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBc0IsUUFBQSxFQUFFO1FBQWtCLENBQWlCLENBQUMsRUFBQyw4S0FBOEssZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxFQUFFO1VBQUFzQixRQUFBLEVBQUU7UUFBVyxDQUFpQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUEwQixDQUFtQixDQUFDLEVBQUMsZ0JBQWdCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQyxFQUFDLGlFQUFpRTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUF5RSxDQUFxQixDQUFDLEVBQUMsaUdBQWlHLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQW1CLENBQW1CLENBQUMsRUFBQyxxREFBcUQsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxFQUFFO1VBQUFzQixRQUFBLEVBQUU7UUFBVyxDQUFpQixDQUFDLEVBQUMsb0JBQW9CLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQW1CLENBQW1CLENBQUMsRUFBQyx5RUFBeUU7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBa0csQ0FBcUIsQ0FBQyxFQUFDLGdIQUFnSCxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLEVBQUU7VUFBQXNCLFFBQUEsRUFBRTtRQUEwQyxDQUFpQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLEVBQUU7VUFBQXNCLFFBQUEsRUFBRTtRQUFzRCxDQUFpQixDQUFDLEVBQUMsZ0JBQWdCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQU0sQ0FBbUIsQ0FBQyxFQUFDLE9BQU8sZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLHlEQUF5RDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFxQyxDQUFxQixDQUFDLEVBQUMsNE5BQTROLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBc0IsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLHVEQUF1RDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUErRCxDQUFxQixDQUFDLEVBQUMsa09BQWtPLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBc0IsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLHNHQUFzRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUEwQyxDQUFxQixDQUFDLEVBQUMsNkdBQTZHLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBc0IsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLHdHQUF3RztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUE0RCxDQUFxQixDQUFDLEVBQUMsdUpBQXVKLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBc0IsUUFBQSxFQUFFO1FBQU0sQ0FBaUIsQ0FBQyxFQUFDLDBGQUEwRixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLEVBQUU7VUFBQXNCLFFBQUEsRUFBRTtRQUFXLENBQWlCLENBQUMsRUFBQyxpRkFBaUY7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBb0UsQ0FBcUIsQ0FBQyxFQUFDLGtJQUFrSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLEVBQUU7VUFBQXNCLFFBQUEsRUFBRTtRQUFXLENBQWlCLENBQUMsRUFBQyw4RkFBOEYsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxFQUFFO1VBQUFzQixRQUFBLEVBQUU7UUFBTSxDQUFpQixDQUFDLEVBQUMsOENBQThDO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNPLEVBQUUsSUFBRSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFWLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDcUIsRUFBRSxFQUFDLFFBQVE7TUFBQyxhQUFVLDhCQUE4QjtNQUFBRCxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVEsQ0FBRSxDQUFDLEVBQUMsMEJBQTBCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBc0IsUUFBQSxFQUFFO01BQVUsQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBZ0IsUUFBQSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQW1GLENBQXFCO0lBQUMsQ0FBZSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNrQixFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFrQixDQUFxQixDQUFDLEVBQUMsNk9BQTZPO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWtCLENBQXFCLENBQUMsRUFBQyx5SkFBeUo7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBa0IsQ0FBcUIsQ0FBQyxFQUFDLDRGQUE0RixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFtQixDQUFtQixDQUFDLEVBQUMsbURBQW1EO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWdCLENBQXFCLENBQUMsRUFBQyw2TEFBNkw7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBZ0IsQ0FBcUIsQ0FBQyxFQUFDLGtHQUFrRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFnQixDQUFxQixDQUFDLEVBQUMsc0hBQXNIO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWdCLENBQXFCLENBQUMsRUFBQyw2S0FBNks7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBZ0IsQ0FBcUIsQ0FBQyxFQUFDLDBDQUEwQztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFnQixDQUFxQixDQUFDLEVBQUMsNkdBQTZHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWlCLENBQXFCLENBQUMsRUFBQyxjQUFjLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQVksQ0FBbUIsQ0FBQyxFQUFDLHdEQUF3RDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFpQixDQUFxQixDQUFDLEVBQUMsZ0pBQWdKO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNPLEVBQUUsSUFBRSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFWLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDcUIsRUFBRSxFQUFDLFFBQVE7TUFBQyxhQUFVLG1CQUFtQjtNQUFBRCxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVEsQ0FBRSxDQUFDLEVBQUMsb0JBQW9CO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDa0IsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBSSxDQUFxQixDQUFDLEVBQUMsOEJBQThCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQWlCLENBQW1CLENBQUMsRUFBQyxpSUFBaUk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBSSxDQUFxQixDQUFDLEVBQUMsU0FBUyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFTLENBQW1CLENBQUMsRUFBQyw4Q0FBOEMsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBUyxDQUFtQixDQUFDLEVBQUMsOERBQThEO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQUksQ0FBcUIsQ0FBQyxFQUFDLGtJQUFrSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFJLENBQXFCLENBQUMsRUFBQyw2SUFBNkk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBSSxDQUFxQixDQUFDLEVBQUMscUtBQXFLO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQUksQ0FBcUIsQ0FBQyxFQUFDLCtFQUErRTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFJLENBQXFCLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQVksQ0FBbUIsQ0FBQyxFQUFDLDZHQUE2RztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQztFQUFBLENBQUUsQ0FBQztBQUM1NjVEO0FBQ2UsU0FBU0csVUFBVUEsQ0FBQzdCLEtBQUssR0FBRyxDQUFDLENBQUMsRUFBRTtFQUM3QyxNQUFNO0lBQUM4QixPQUFPLEVBQUVDO0VBQVMsQ0FBQyxHQUFHO0lBQzNCLEdBQUcsSUFBQVgsNkJBQWtCLEVBQUMsQ0FBQztJQUN2QixHQUFHcEIsS0FBSyxDQUFDcUI7RUFDWCxDQUFDO0VBQ0QsT0FBT1UsU0FBUyxnQkFBRyxJQUFBakMsV0FBQSxDQUFBOEIsR0FBQSxFQUFDRyxTQUFTO0lBQUEsR0FBSy9CLEtBQUs7SUFBQTBCLFFBQUEsZUFBRSxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDN0IsaUJBQWlCO01BQUEsR0FBS0M7SUFBSyxDQUFHO0VBQUMsQ0FBVyxDQUFDLEdBQUdELGlCQUFpQixDQUFDQyxLQUFLLENBQUM7QUFDbEg7QUFBQ2dDLEVBQUEsR0FOdUJILFVBQVU7QUFPbEMsU0FBU04sb0JBQW9CQSxDQUFDSSxFQUFFLEVBQUVNLFNBQVMsRUFBRUMsS0FBSyxFQUFFO0VBQ2xELE1BQU0sSUFBSUMsS0FBSyxDQUFDLFdBQVcsSUFBSUYsU0FBUyxHQUFHLFdBQVcsR0FBRyxRQUFRLENBQUMsR0FBRyxJQUFJLEdBQUdOLEVBQUUsR0FBRyxvRUFBb0UsSUFBSU8sS0FBSyxHQUFHLHFDQUFxQyxHQUFHQSxLQUFLLEdBQUcseURBQXlELEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDblI7QUFBQyxJQUFBRixFQUFBO0FBQUFJLFlBQUEsQ0FBQUosRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}