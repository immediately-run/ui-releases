var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      code: "code",
      h1: "h1",
      h2: "h2",
      li: "li",
      ol: "ol",
      p: "p",
      pre: "pre",
      strong: "strong",
      table: "table",
      tbody: "tbody",
      td: "td",
      th: "th",
      thead: "thead",
      tr: "tr",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "meridian-saas-exec-metrics-case-study",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "meridian-saas-exec-metrics-case-study"
      }), "Meridian SaaS — exec-metrics case study"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The concrete artifact commissioned by design-brief 01 (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "immediately-run/docs"
      }), " →\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "design-briefs/reckoner/01-benchmark-case-study.md"
      }), "): a coherent, internally-consistent\nsynthetic B2B-SaaS reporting workbook used to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "develop, validate, and demonstrate"
      }), " Reckoner.\nOne artifact, three jobs — design anchor, formula/template stress test, and evaluation corpus."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Everything here is generated"
      }), " by ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "generate.py",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "generate.py"
        })
      }), " (deterministic, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "seed=20260709"
      }), ");\nre-running reproduces byte-identical output. The numbers are computed in Python so they are\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "real and verified"
      }), " — in particular the MRR movement waterfall genuinely reconciles to the\nMRR delta, so the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "conservation()"
      }), " metamorphic test is a true check, not a tautology."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "files",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "files"
      }), "Files"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "File"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Sheet"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Rows"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "What it is"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "data/subscriptions.csv"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Subscriptions"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "2,175"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["one row per active customer-month: plan, seats, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "mrr_local"
            }), ", currency, region, signup month"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "data/invoices.csv"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Invoices"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "2,175"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "one invoice per active customer-month, in the customer's currency"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "data/fx.csv"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "FX"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "143"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["monthly rate per currency (EUR base) — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "with a deliberate gap: GBP 2024-02 is missing"
            })]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "data/targets.csv"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Targets"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "36"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "board MRR targets (base / bull / bear) + NRR target, per month"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "data/mrr_movements.csv"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "MRR movements"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "36"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "the waterfall: start → new / expansion / contraction / churned / reactivation → end, EUR"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "data/cohort_retention.csv"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Cohort retention"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "30"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "signup-cohort × months-since retention % triangle (offsets 0–12)"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "data/top_customers.csv"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Top customers"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "11"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "top-10 by ARR + an \"Other\" bucket, with concentration %"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "data/exec_summary.csv"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Exec summary"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "36"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "MRR, MoM growth, NRR, GRR, quick ratio, gross churn, vs-target — per month"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "meridian.xlsx"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "(all 8)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "—"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["the real Excel \"before\": all sheets + a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "live"
            }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "recon_formula"
            }), " column on MRR movements"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "expected.json"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "—"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "—"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["spot-check expected values that seed Reckoner ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "specification"
            }), " tests"]
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Scope: 150 customers over 36 months (2023-07 … 2026-06). The subscription table is ~2.2k rows\n(150 customers × their active lifetimes), smaller than the brief's illustrative \"~5k\" but with\nthe full event mix (expansion, contraction, churn, reactivation) needed to exercise the logic."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "the-formulas-excel-before-reckoner-after",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-formulas-excel-before-reckoner-after"
      }), "The formulas — Excel \"before\" → Reckoner \"after\""]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "The derived sheets are the port targets. Each is stated as the Excel logic and its intended\nReckoner formula, to drive the port and the language stress test."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "MRR movements (sheet 5)"
        }), " — per customer, this-month vs last-month state, EUR-normalized.\nExcel: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "SUMIFS"
        }), " batteries with sign conventions (the classic silent-error sheet). Reckoner:\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "lag"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "asofJoin"
        }), " over the FX + a self-join current↔prior on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "(customer, month)"
        }), "; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "new"
        }), " =\nfirst-ever-seen this month, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "reactivation"
        }), " = seen-before-but-absent-last-month (a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "min(month)"
        }), "\nsplit), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "churned"
        }), " = present-last-absent-this (a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "full/anti-join"
        }), " — one of the review-1 DSL\nadditions). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Invariant:"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "start + new + expansion + contraction + churned + reactivation = end"
        }), " → a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "conservation()"
        }), " test; the generator confirms it holds to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "0.0"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Cohort retention (sheet 6)"
        }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "groupBy(signup_cohort, months_since) → count"
        }), ", then\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "pivot"
        }), "; retention % = each cell ÷ the cohort's offset-0 size. Reckoner: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "normalize before\npivot"
        }), " (compute ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "cohort_size"
        }), " via ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "groupBy"
        }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "join"
        }), " back, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "derive pct"
        }), ", then ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "pivot"
        }), ") — the\nDSL-4 ordering hazard the case study is meant to catch."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Top customers (sheet 7)"
        }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "topN(10)"
        }), " by ARR + an \"Other\" bucket + concentration %.\nExercises ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "topN"
        }), " composition and tie/other-bucket semantics (DSL-7)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Exec summary (sheet 8)"
        }), " — ratios over grouped frames: NRR, GRR, quick ratio, MoM growth,\nchurn %, vs-target. Exercises empty-group / divide-by-zero semantics (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "safe_div"
        }), " in the\ngenerator; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "safeDiv"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "coalesce"
        }), " in Reckoner — the DSL-6 null-semantics additions)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "planted-probes-primary-outputs-of-the-port-not-footnotes",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "planted-probes-primary-outputs-of-the-port-not-footnotes"
      }), "Planted probes (primary outputs of the port, not footnotes)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Per brief 01 + the DSL adversarial review, the case study deliberately plants:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "FX gap"
        }), " — GBP has no 2024-02 rate → the port must use ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "asofJoin"
        }), " (carry-forward last\nknown), not an equi-join (which would NaN-poison the EUR figures). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "expected.json.fx_gap"
        }), "\nrecords the gap and the carry-forward source."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Conservation invariant"
        }), " — the waterfall reconciles to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "0.0"
        }), "\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "expected.json.waterfall_max_abs_recon_delta"
        }), "), so ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "conservation()"
        }), " is a real test."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Ordered/relational logic"
        }), " — month-over-month movement + running retention are exactly the\nordered-across-rows operations the review-1 stdlib additions (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "lag"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "scan"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "asofJoin"
        }), ") exist\nfor; if any needs a hand-rolled ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".reduce"
        }), ", that is a freeze-blocking DSL finding."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Catalog gaps"
        }), " — the exec-summary deck wants a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "retention heatmap"
        }), " (no v1 component), an\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "MRR waterfall"
        }), " (no first-class component), and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "growth-vs-target"
        }), " (dual-axis, excluded).\nThe port records a disposition for each (shade a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Table"
        }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Facets"
        }), " / propose an\nanti-affordance-reviewed addition), not a silent omission."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Empty/boundary groups"
        }), " — early cohorts and calm months exercise empty-group and ÷0\nreturns (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "null"
        }), ", not ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "0"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "NaN"
        }), ") — the DSL-6 semantics."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "regenerating-tuning",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "regenerating-tuning"
      }), "Regenerating / tuning"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-bash",
        children: "python3 generate.py     # writes data/*.csv, meridian.xlsx, expected.json\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Change ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "SEED"
      }), " for a different-but-coherent dataset; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "N_CUST"
      }), " / lifetimes to resize. The\nreconciliation, the FX gap, and the cohort structure hold across seeds — they are structural,\nnot seed-specific."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "provenance",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "provenance"
      }), "Provenance"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Design-brief: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "immediately-run/docs"
      }), " → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "design-briefs/reckoner/01-benchmark-case-study.md"
      }), ".\nThe DSL additions this stresses: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "docs/specs/DOCUMENT_VERSIONING_SPEC.md"
      }), " neighbours +\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ARCHITECTURE_PLAN.md"
      }), " §3.2 (the committed stdlib incl. the review-1 window/as-of/date/null\nfamilies) and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ADVERSARIAL_REVIEW_1.md"
      }), " (DSL findings)."]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/case-study/meridian/README.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiY29kZSIsImgxIiwiaDIiLCJsaSIsIm9sIiwicCIsInByZSIsInN0cm9uZyIsInRhYmxlIiwidGJvZHkiLCJ0ZCIsInRoIiwidGhlYWQiLCJ0ciIsInVsIiwiX3Byb3ZpZGVDb21wb25lbnRzIiwiY29tcG9uZW50cyIsIkhlYWRpbmdBbmNob3IiLCJfbWlzc2luZ01keFJlZmVyZW5jZSIsImpzeHMiLCJGcmFnbWVudCIsImNoaWxkcmVuIiwiaWQiLCJqc3giLCJocmVmIiwiY2xhc3NOYW1lIiwiTURYQ29udGVudCIsIndyYXBwZXIiLCJNRFhMYXlvdXQiLCJfYyIsImNvbXBvbmVudCIsInBsYWNlIiwiRXJyb3IiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJSRUFETUUubWQiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgYTogXCJhXCIsXG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgaDE6IFwiaDFcIixcbiAgICBoMjogXCJoMlwiLFxuICAgIGxpOiBcImxpXCIsXG4gICAgb2w6IFwib2xcIixcbiAgICBwOiBcInBcIixcbiAgICBwcmU6IFwicHJlXCIsXG4gICAgc3Ryb25nOiBcInN0cm9uZ1wiLFxuICAgIHRhYmxlOiBcInRhYmxlXCIsXG4gICAgdGJvZHk6IFwidGJvZHlcIixcbiAgICB0ZDogXCJ0ZFwiLFxuICAgIHRoOiBcInRoXCIsXG4gICAgdGhlYWQ6IFwidGhlYWRcIixcbiAgICB0cjogXCJ0clwiLFxuICAgIHVsOiBcInVsXCIsXG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9LCB7SGVhZGluZ0FuY2hvcn0gPSBfY29tcG9uZW50cztcbiAgaWYgKCFIZWFkaW5nQW5jaG9yKSBfbWlzc2luZ01keFJlZmVyZW5jZShcIkhlYWRpbmdBbmNob3JcIiwgdHJ1ZSk7XG4gIHJldHVybiA8PjxfY29tcG9uZW50cy5oMSBpZD1cIm1lcmlkaWFuLXNhYXMtZXhlYy1tZXRyaWNzLWNhc2Utc3R1ZHlcIj48SGVhZGluZ0FuY2hvciBpZD1cIm1lcmlkaWFuLXNhYXMtZXhlYy1tZXRyaWNzLWNhc2Utc3R1ZHlcIiAvPntcIk1lcmlkaWFuIFNhYVMg4oCUIGV4ZWMtbWV0cmljcyBjYXNlIHN0dWR5XCJ9PC9fY29tcG9uZW50cy5oMT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgY29uY3JldGUgYXJ0aWZhY3QgY29tbWlzc2lvbmVkIGJ5IGRlc2lnbi1icmllZiAwMSAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW1tZWRpYXRlbHktcnVuL2RvY3NcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKGklxcblwifTxfY29tcG9uZW50cy5jb2RlPntcImRlc2lnbi1icmllZnMvcmVja29uZXIvMDEtYmVuY2htYXJrLWNhc2Utc3R1ZHkubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKTogYSBjb2hlcmVudCwgaW50ZXJuYWxseS1jb25zaXN0ZW50XFxuc3ludGhldGljIEIyQi1TYWFTIHJlcG9ydGluZyB3b3JrYm9vayB1c2VkIHRvIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZGV2ZWxvcCwgdmFsaWRhdGUsIGFuZCBkZW1vbnN0cmF0ZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBSZWNrb25lci5cXG5PbmUgYXJ0aWZhY3QsIHRocmVlIGpvYnMg4oCUIGRlc2lnbiBhbmNob3IsIGZvcm11bGEvdGVtcGxhdGUgc3RyZXNzIHRlc3QsIGFuZCBldmFsdWF0aW9uIGNvcnB1cy5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJFdmVyeXRoaW5nIGhlcmUgaXMgZ2VuZXJhdGVkXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGJ5IFwifTxfY29tcG9uZW50cy5hIGhyZWY9XCJnZW5lcmF0ZS5weVwiPjxfY29tcG9uZW50cy5jb2RlPntcImdlbmVyYXRlLnB5XCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuYT57XCIgKGRldGVybWluaXN0aWMsIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNlZWQ9MjAyNjA3MDlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKTtcXG5yZS1ydW5uaW5nIHJlcHJvZHVjZXMgYnl0ZS1pZGVudGljYWwgb3V0cHV0LiBUaGUgbnVtYmVycyBhcmUgY29tcHV0ZWQgaW4gUHl0aG9uIHNvIHRoZXkgYXJlXFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJyZWFsIGFuZCB2ZXJpZmllZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgaW4gcGFydGljdWxhciB0aGUgTVJSIG1vdmVtZW50IHdhdGVyZmFsbCBnZW51aW5lbHkgcmVjb25jaWxlcyB0byB0aGVcXG5NUlIgZGVsdGEsIHNvIHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjb25zZXJ2YXRpb24oKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgbWV0YW1vcnBoaWMgdGVzdCBpcyBhIHRydWUgY2hlY2ssIG5vdCBhIHRhdXRvbG9neS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwiZmlsZXNcIj48SGVhZGluZ0FuY2hvciBpZD1cImZpbGVzXCIgLz57XCJGaWxlc1wifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnRhYmxlPjxfY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRoPntcIkZpbGVcIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aD57XCJTaGVldFwifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIlJvd3NcIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aD57XCJXaGF0IGl0IGlzXCJ9PC9fY29tcG9uZW50cy50aD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGhlYWQ+PF9jb21wb25lbnRzLnRib2R5PjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiZGF0YS9zdWJzY3JpcHRpb25zLmNzdlwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJTdWJzY3JpcHRpb25zXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiMiwxNzVcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJvbmUgcm93IHBlciBhY3RpdmUgY3VzdG9tZXItbW9udGg6IHBsYW4sIHNlYXRzLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJtcnJfbG9jYWxcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBjdXJyZW5jeSwgcmVnaW9uLCBzaWdudXAgbW9udGhcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJkYXRhL2ludm9pY2VzLmNzdlwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJJbnZvaWNlc1wifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIjIsMTc1XCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wib25lIGludm9pY2UgcGVyIGFjdGl2ZSBjdXN0b21lci1tb250aCwgaW4gdGhlIGN1c3RvbWVyJ3MgY3VycmVuY3lcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJkYXRhL2Z4LmNzdlwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJGWFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIjE0M1wifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIm1vbnRobHkgcmF0ZSBwZXIgY3VycmVuY3kgKEVVUiBiYXNlKSDigJQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ3aXRoIGEgZGVsaWJlcmF0ZSBnYXA6IEdCUCAyMDI0LTAyIGlzIG1pc3NpbmdcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJkYXRhL3RhcmdldHMuY3N2XCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIlRhcmdldHNcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCIzNlwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcImJvYXJkIE1SUiB0YXJnZXRzIChiYXNlIC8gYnVsbCAvIGJlYXIpICsgTlJSIHRhcmdldCwgcGVyIG1vbnRoXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiZGF0YS9tcnJfbW92ZW1lbnRzLmNzdlwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJNUlIgbW92ZW1lbnRzXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiMzZcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJ0aGUgd2F0ZXJmYWxsOiBzdGFydCDihpIgbmV3IC8gZXhwYW5zaW9uIC8gY29udHJhY3Rpb24gLyBjaHVybmVkIC8gcmVhY3RpdmF0aW9uIOKGkiBlbmQsIEVVUlwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcImRhdGEvY29ob3J0X3JldGVudGlvbi5jc3ZcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiQ29ob3J0IHJldGVudGlvblwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIjMwXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wic2lnbnVwLWNvaG9ydCDDlyBtb250aHMtc2luY2UgcmV0ZW50aW9uICUgdHJpYW5nbGUgKG9mZnNldHMgMOKAkzEyKVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcImRhdGEvdG9wX2N1c3RvbWVycy5jc3ZcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiVG9wIGN1c3RvbWVyc1wifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIjExXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1widG9wLTEwIGJ5IEFSUiArIGFuIFxcXCJPdGhlclxcXCIgYnVja2V0LCB3aXRoIGNvbmNlbnRyYXRpb24gJVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcImRhdGEvZXhlY19zdW1tYXJ5LmNzdlwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJFeGVjIHN1bW1hcnlcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCIzNlwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIk1SUiwgTW9NIGdyb3d0aCwgTlJSLCBHUlIsIHF1aWNrIHJhdGlvLCBncm9zcyBjaHVybiwgdnMtdGFyZ2V0IOKAlCBwZXIgbW9udGhcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJtZXJpZGlhbi54bHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIihhbGwgOClcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCLigJRcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJ0aGUgcmVhbCBFeGNlbCBcXFwiYmVmb3JlXFxcIjogYWxsIHNoZWV0cyArIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJsaXZlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5jb2RlPntcInJlY29uX2Zvcm11bGFcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNvbHVtbiBvbiBNUlIgbW92ZW1lbnRzXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiZXhwZWN0ZWQuanNvblwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCLigJRcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCLigJRcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJzcG90LWNoZWNrIGV4cGVjdGVkIHZhbHVlcyB0aGF0IHNlZWQgUmVja29uZXIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3BlY2lmaWNhdGlvblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdGVzdHNcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50Ym9keT48L19jb21wb25lbnRzLnRhYmxlPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlNjb3BlOiAxNTAgY3VzdG9tZXJzIG92ZXIgMzYgbW9udGhzICgyMDIzLTA3IOKApiAyMDI2LTA2KS4gVGhlIHN1YnNjcmlwdGlvbiB0YWJsZSBpcyB+Mi4yayByb3dzXFxuKDE1MCBjdXN0b21lcnMgw5cgdGhlaXIgYWN0aXZlIGxpZmV0aW1lcyksIHNtYWxsZXIgdGhhbiB0aGUgYnJpZWYncyBpbGx1c3RyYXRpdmUgXFxcIn41a1xcXCIgYnV0IHdpdGhcXG50aGUgZnVsbCBldmVudCBtaXggKGV4cGFuc2lvbiwgY29udHJhY3Rpb24sIGNodXJuLCByZWFjdGl2YXRpb24pIG5lZWRlZCB0byBleGVyY2lzZSB0aGUgbG9naWMuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInRoZS1mb3JtdWxhcy1leGNlbC1iZWZvcmUtcmVja29uZXItYWZ0ZXJcIj48SGVhZGluZ0FuY2hvciBpZD1cInRoZS1mb3JtdWxhcy1leGNlbC1iZWZvcmUtcmVja29uZXItYWZ0ZXJcIiAvPntcIlRoZSBmb3JtdWxhcyDigJQgRXhjZWwgXFxcImJlZm9yZVxcXCIg4oaSIFJlY2tvbmVyIFxcXCJhZnRlclxcXCJcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSBkZXJpdmVkIHNoZWV0cyBhcmUgdGhlIHBvcnQgdGFyZ2V0cy4gRWFjaCBpcyBzdGF0ZWQgYXMgdGhlIEV4Y2VsIGxvZ2ljIGFuZCBpdHMgaW50ZW5kZWRcXG5SZWNrb25lciBmb3JtdWxhLCB0byBkcml2ZSB0aGUgcG9ydCBhbmQgdGhlIGxhbmd1YWdlIHN0cmVzcyB0ZXN0LlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiTVJSIG1vdmVtZW50cyAoc2hlZXQgNSlcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHBlciBjdXN0b21lciwgdGhpcy1tb250aCB2cyBsYXN0LW1vbnRoIHN0YXRlLCBFVVItbm9ybWFsaXplZC5cXG5FeGNlbDogXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiU1VNSUZTXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBiYXR0ZXJpZXMgd2l0aCBzaWduIGNvbnZlbnRpb25zICh0aGUgY2xhc3NpYyBzaWxlbnQtZXJyb3Igc2hlZXQpLiBSZWNrb25lcjpcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJsYWdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcImFzb2ZKb2luXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBvdmVyIHRoZSBGWCArIGEgc2VsZi1qb2luIGN1cnJlbnTihpRwcmlvciBvbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCIoY3VzdG9tZXIsIG1vbnRoKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCI7IFwifTxfY29tcG9uZW50cy5jb2RlPntcIm5ld1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgPVxcbmZpcnN0LWV2ZXItc2VlbiB0aGlzIG1vbnRoLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyZWFjdGl2YXRpb25cIn08L19jb21wb25lbnRzLmNvZGU+e1wiID0gc2Vlbi1iZWZvcmUtYnV0LWFic2VudC1sYXN0LW1vbnRoIChhIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1pbihtb250aClcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxuc3BsaXQpLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjaHVybmVkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiA9IHByZXNlbnQtbGFzdC1hYnNlbnQtdGhpcyAoYSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImZ1bGwvYW50aS1qb2luXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBvbmUgb2YgdGhlIHJldmlldy0xIERTTFxcbmFkZGl0aW9ucykuIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiSW52YXJpYW50OlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzdGFydCArIG5ldyArIGV4cGFuc2lvbiArIGNvbnRyYWN0aW9uICsgY2h1cm5lZCArIHJlYWN0aXZhdGlvbiA9IGVuZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oaSIGEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY29uc2VydmF0aW9uKClcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHRlc3Q7IHRoZSBnZW5lcmF0b3IgY29uZmlybXMgaXQgaG9sZHMgdG8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiMC4wXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkNvaG9ydCByZXRlbnRpb24gKHNoZWV0IDYpXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJncm91cEJ5KHNpZ251cF9jb2hvcnQsIG1vbnRoc19zaW5jZSkg4oaSIGNvdW50XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgdGhlblxcblwifTxfY29tcG9uZW50cy5jb2RlPntcInBpdm90XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjsgcmV0ZW50aW9uICUgPSBlYWNoIGNlbGwgw7cgdGhlIGNvaG9ydCdzIG9mZnNldC0wIHNpemUuIFJlY2tvbmVyOiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vcm1hbGl6ZSBiZWZvcmVcXG5waXZvdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoY29tcHV0ZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjb2hvcnRfc2l6ZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdmlhIFwifTxfY29tcG9uZW50cy5jb2RlPntcImdyb3VwQnlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJqb2luXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBiYWNrLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJkZXJpdmUgcGN0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgdGhlbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJwaXZvdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpIOKAlCB0aGVcXG5EU0wtNCBvcmRlcmluZyBoYXphcmQgdGhlIGNhc2Ugc3R1ZHkgaXMgbWVhbnQgdG8gY2F0Y2guXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUb3AgY3VzdG9tZXJzIChzaGVldCA3KVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widG9wTigxMClcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGJ5IEFSUiArIGFuIFxcXCJPdGhlclxcXCIgYnVja2V0ICsgY29uY2VudHJhdGlvbiAlLlxcbkV4ZXJjaXNlcyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ0b3BOXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjb21wb3NpdGlvbiBhbmQgdGllL290aGVyLWJ1Y2tldCBzZW1hbnRpY3MgKERTTC03KS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkV4ZWMgc3VtbWFyeSAoc2hlZXQgOClcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHJhdGlvcyBvdmVyIGdyb3VwZWQgZnJhbWVzOiBOUlIsIEdSUiwgcXVpY2sgcmF0aW8sIE1vTSBncm93dGgsXFxuY2h1cm4gJSwgdnMtdGFyZ2V0LiBFeGVyY2lzZXMgZW1wdHktZ3JvdXAgLyBkaXZpZGUtYnktemVybyBzZW1hbnRpY3MgKFwifTxfY29tcG9uZW50cy5jb2RlPntcInNhZmVfZGl2XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpbiB0aGVcXG5nZW5lcmF0b3I7IFwifTxfY29tcG9uZW50cy5jb2RlPntcInNhZmVEaXZcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcImNvYWxlc2NlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpbiBSZWNrb25lciDigJQgdGhlIERTTC02IG51bGwtc2VtYW50aWNzIGFkZGl0aW9ucykuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInBsYW50ZWQtcHJvYmVzLXByaW1hcnktb3V0cHV0cy1vZi10aGUtcG9ydC1ub3QtZm9vdG5vdGVzXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJwbGFudGVkLXByb2Jlcy1wcmltYXJ5LW91dHB1dHMtb2YtdGhlLXBvcnQtbm90LWZvb3Rub3Rlc1wiIC8+e1wiUGxhbnRlZCBwcm9iZXMgKHByaW1hcnkgb3V0cHV0cyBvZiB0aGUgcG9ydCwgbm90IGZvb3Rub3RlcylcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlBlciBicmllZiAwMSArIHRoZSBEU0wgYWR2ZXJzYXJpYWwgcmV2aWV3LCB0aGUgY2FzZSBzdHVkeSBkZWxpYmVyYXRlbHkgcGxhbnRzOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMub2w+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRlggZ2FwXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBHQlAgaGFzIG5vIDIwMjQtMDIgcmF0ZSDihpIgdGhlIHBvcnQgbXVzdCB1c2UgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYXNvZkpvaW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChjYXJyeS1mb3J3YXJkIGxhc3RcXG5rbm93biksIG5vdCBhbiBlcXVpLWpvaW4gKHdoaWNoIHdvdWxkIE5hTi1wb2lzb24gdGhlIEVVUiBmaWd1cmVzKS4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZXhwZWN0ZWQuanNvbi5meF9nYXBcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxucmVjb3JkcyB0aGUgZ2FwIGFuZCB0aGUgY2FycnktZm9yd2FyZCBzb3VyY2UuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJDb25zZXJ2YXRpb24gaW52YXJpYW50XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCB0aGUgd2F0ZXJmYWxsIHJlY29uY2lsZXMgdG8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiMC4wXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIlxcbihcIn08X2NvbXBvbmVudHMuY29kZT57XCJleHBlY3RlZC5qc29uLndhdGVyZmFsbF9tYXhfYWJzX3JlY29uX2RlbHRhXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiksIHNvIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNvbnNlcnZhdGlvbigpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpcyBhIHJlYWwgdGVzdC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIk9yZGVyZWQvcmVsYXRpb25hbCBsb2dpY1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgbW9udGgtb3Zlci1tb250aCBtb3ZlbWVudCArIHJ1bm5pbmcgcmV0ZW50aW9uIGFyZSBleGFjdGx5IHRoZVxcbm9yZGVyZWQtYWNyb3NzLXJvd3Mgb3BlcmF0aW9ucyB0aGUgcmV2aWV3LTEgc3RkbGliIGFkZGl0aW9ucyAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibGFnXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJzY2FuXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJhc29mSm9pblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpIGV4aXN0XFxuZm9yOyBpZiBhbnkgbmVlZHMgYSBoYW5kLXJvbGxlZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCIucmVkdWNlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgdGhhdCBpcyBhIGZyZWV6ZS1ibG9ja2luZyBEU0wgZmluZGluZy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkNhdGFsb2cgZ2Fwc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgdGhlIGV4ZWMtc3VtbWFyeSBkZWNrIHdhbnRzIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJyZXRlbnRpb24gaGVhdG1hcFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAobm8gdjEgY29tcG9uZW50KSwgYW5cXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIk1SUiB3YXRlcmZhbGxcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKG5vIGZpcnN0LWNsYXNzIGNvbXBvbmVudCksIGFuZCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImdyb3d0aC12cy10YXJnZXRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKGR1YWwtYXhpcywgZXhjbHVkZWQpLlxcblRoZSBwb3J0IHJlY29yZHMgYSBkaXNwb3NpdGlvbiBmb3IgZWFjaCAoc2hhZGUgYSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJUYWJsZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgLyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJGYWNldHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIC8gcHJvcG9zZSBhblxcbmFudGktYWZmb3JkYW5jZS1yZXZpZXdlZCBhZGRpdGlvbiksIG5vdCBhIHNpbGVudCBvbWlzc2lvbi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkVtcHR5L2JvdW5kYXJ5IGdyb3Vwc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgZWFybHkgY29ob3J0cyBhbmQgY2FsbSBtb250aHMgZXhlcmNpc2UgZW1wdHktZ3JvdXAgYW5kIMO3MFxcbnJldHVybnMgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIm51bGxcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBub3QgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiMFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiTmFOXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikg4oCUIHRoZSBEU0wtNiBzZW1hbnRpY3MuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInJlZ2VuZXJhdGluZy10dW5pbmdcIj48SGVhZGluZ0FuY2hvciBpZD1cInJlZ2VuZXJhdGluZy10dW5pbmdcIiAvPntcIlJlZ2VuZXJhdGluZyAvIHR1bmluZ1wifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnByZT48X2NvbXBvbmVudHMuY29kZSBjbGFzc05hbWU9XCJsYW5ndWFnZS1iYXNoXCI+e1wicHl0aG9uMyBnZW5lcmF0ZS5weSAgICAgIyB3cml0ZXMgZGF0YS8qLmNzdiwgbWVyaWRpYW4ueGxzeCwgZXhwZWN0ZWQuanNvblxcblwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnByZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJDaGFuZ2UgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiU0VFRFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZm9yIGEgZGlmZmVyZW50LWJ1dC1jb2hlcmVudCBkYXRhc2V0OyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJOX0NVU1RcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIC8gbGlmZXRpbWVzIHRvIHJlc2l6ZS4gVGhlXFxucmVjb25jaWxpYXRpb24sIHRoZSBGWCBnYXAsIGFuZCB0aGUgY29ob3J0IHN0cnVjdHVyZSBob2xkIGFjcm9zcyBzZWVkcyDigJQgdGhleSBhcmUgc3RydWN0dXJhbCxcXG5ub3Qgc2VlZC1zcGVjaWZpYy5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwicHJvdmVuYW5jZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwicHJvdmVuYW5jZVwiIC8+e1wiUHJvdmVuYW5jZVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiRGVzaWduLWJyaWVmOiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJpbW1lZGlhdGVseS1ydW4vZG9jc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oaSIFwifTxfY29tcG9uZW50cy5jb2RlPntcImRlc2lnbi1icmllZnMvcmVja29uZXIvMDEtYmVuY2htYXJrLWNhc2Utc3R1ZHkubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLlxcblRoZSBEU0wgYWRkaXRpb25zIHRoaXMgc3RyZXNzZXM6IFwifTxfY29tcG9uZW50cy5jb2RlPntcImRvY3Mvc3BlY3MvRE9DVU1FTlRfVkVSU0lPTklOR19TUEVDLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBuZWlnaGJvdXJzICtcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJBUkNISVRFQ1RVUkVfUExBTi5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgwqczLjIgKHRoZSBjb21taXR0ZWQgc3RkbGliIGluY2wuIHRoZSByZXZpZXctMSB3aW5kb3cvYXMtb2YvZGF0ZS9udWxsXFxuZmFtaWxpZXMpIGFuZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJBRFZFUlNBUklBTF9SRVZJRVdfMS5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKERTTCBmaW5kaW5ncykuXCJ9PC9fY29tcG9uZW50cy5wPjwvPjtcbn1cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE1EWENvbnRlbnQocHJvcHMgPSB7fSkge1xuICBjb25zdCB7d3JhcHBlcjogTURYTGF5b3V0fSA9IHtcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH07XG4gIHJldHVybiBNRFhMYXlvdXQgPyA8TURYTGF5b3V0IHsuLi5wcm9wc30+PF9jcmVhdGVNZHhDb250ZW50IHsuLi5wcm9wc30gLz48L01EWExheW91dD4gOiBfY3JlYXRlTWR4Q29udGVudChwcm9wcyk7XG59XG5mdW5jdGlvbiBfbWlzc2luZ01keFJlZmVyZW5jZShpZCwgY29tcG9uZW50LCBwbGFjZSkge1xuICB0aHJvdyBuZXcgRXJyb3IoXCJFeHBlY3RlZCBcIiArIChjb21wb25lbnQgPyBcImNvbXBvbmVudFwiIDogXCJvYmplY3RcIikgKyBcIiBgXCIgKyBpZCArIFwiYCB0byBiZSBkZWZpbmVkOiB5b3UgbGlrZWx5IGZvcmdvdCB0byBpbXBvcnQsIHBhc3MsIG9yIHByb3ZpZGUgaXQuXCIgKyAocGxhY2UgPyBcIlxcbkl04oCZcyByZWZlcmVuY2VkIGluIHlvdXIgY29kZSBhdCBgXCIgKyBwbGFjZSArIFwiYCBpbiBgL2FwcC9kb2NzL2Nhc2Utc3R1ZHkvbWVyaWRpYW4vUkVBRE1FLm1kYFwiIDogXCJcIikpO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFFQSxJQUFBQSxZQUFBLEdBQUFDLE9BQUE7QUFBd0YsSUFBQUMsV0FBQSxHQUFBRCxPQUFBO0FBRnhGO0FBQ0E7O0FBRUEsU0FBU0UsaUJBQWlCQSxDQUFDQyxLQUFLLEVBQUU7RUFDaEMsTUFBTUMsV0FBVyxHQUFHO01BQ2xCQyxDQUFDLEVBQUUsR0FBRztNQUNOQyxJQUFJLEVBQUUsTUFBTTtNQUNaQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxDQUFDLEVBQUUsR0FBRztNQUNOQyxHQUFHLEVBQUUsS0FBSztNQUNWQyxNQUFNLEVBQUUsUUFBUTtNQUNoQkMsS0FBSyxFQUFFLE9BQU87TUFDZEMsS0FBSyxFQUFFLE9BQU87TUFDZEMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsS0FBSyxFQUFFLE9BQU87TUFDZEMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUixHQUFHLElBQUFDLDZCQUFrQixFQUFDLENBQUM7TUFDdkIsR0FBR2xCLEtBQUssQ0FBQ21CO0lBQ1gsQ0FBQztJQUFFO01BQUNDO0lBQWEsQ0FBQyxHQUFHbkIsV0FBVztFQUNoQyxJQUFJLENBQUNtQixhQUFhLEVBQUVDLG9CQUFvQixDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUM7RUFDL0Qsb0JBQU8sSUFBQXZCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQXhCLFdBQUEsQ0FBQXlCLFFBQUE7SUFBQUMsUUFBQSxnQkFBRSxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDRyxFQUFFO01BQUNxQixFQUFFLEVBQUMsdUNBQXVDO01BQUFELFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBdUMsQ0FBRSxDQUFDLEVBQUMseUNBQXlDO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDTyxDQUFDO01BQUFnQixRQUFBLEdBQUUseURBQXlELGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQXNCLENBQW1CLENBQUMsRUFBQyxNQUFNLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQW1ELENBQW1CLENBQUMsRUFBQyxzRkFBc0YsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFvQyxDQUFxQixDQUFDLEVBQUMsNEdBQTRHO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDTyxDQUFDO01BQUFnQixRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQThCLENBQXFCLENBQUMsRUFBQyxNQUFNLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0MsQ0FBQztRQUFDeUIsSUFBSSxFQUFDLGFBQWE7UUFBQUgsUUFBQSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFhLENBQW1CO01BQUMsQ0FBZSxDQUFDLEVBQUMsbUJBQW1CLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQWUsQ0FBbUIsQ0FBQyxFQUFDLG1HQUFtRyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQW1CLENBQXFCLENBQUMsRUFBQyw2RkFBNkYsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLHFEQUFxRDtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0ksRUFBRTtNQUFDb0IsRUFBRSxFQUFDLE9BQU87TUFBQUQsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLE9BQU87SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNVLEtBQUs7TUFBQWEsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDYyxLQUFLO1FBQUFTLFFBQUEsZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDZSxFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBTSxDQUFpQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDYSxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFPLENBQWlCLENBQUMsbUJBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNhLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQU0sQ0FBaUIsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBWSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0I7TUFBQyxDQUFtQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDVyxLQUFLO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ2UsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUF3QixDQUFtQjtVQUFDLENBQWdCLENBQUMsbUJBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQWUsQ0FBaUIsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBTyxDQUFpQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsR0FBRSxrREFBa0QsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBVyxDQUFtQixDQUFDLEVBQUMsa0NBQWtDO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNlLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBbUIsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFVLENBQWlCLENBQUMsbUJBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQU8sQ0FBaUIsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBbUUsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNlLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBYSxDQUFtQjtVQUFDLENBQWdCLENBQUMsbUJBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQUksQ0FBaUIsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBSyxDQUFpQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsR0FBRSx5Q0FBeUMsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUErQyxDQUFxQixDQUFDO1VBQUEsQ0FBZ0IsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNlLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBa0IsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFTLENBQWlCLENBQUMsbUJBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQUksQ0FBaUIsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBZ0UsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNlLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBd0IsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFlLENBQWlCLENBQUMsbUJBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQUksQ0FBaUIsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBMEYsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNlLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBMkIsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFrQixDQUFpQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFJLENBQWlCLENBQUMsbUJBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQWtFLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDZSxFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQXdCLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBZSxDQUFpQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFJLENBQWlCLENBQUMsbUJBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQTJELENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDZSxFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQXVCLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBYyxDQUFpQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFJLENBQWlCLENBQUMsbUJBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQTRFLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDZSxFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQWUsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFTLENBQWlCLENBQUMsbUJBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQUcsQ0FBaUIsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLEdBQUUsNENBQTRDLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBTSxDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUFlLENBQW1CLENBQUMsRUFBQywwQkFBMEI7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ2UsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUFlLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBRyxDQUFpQixDQUFDLG1CQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDWSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFHLENBQWlCLENBQUMsbUJBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNZLEVBQUU7WUFBQVcsUUFBQSxHQUFFLGdEQUFnRCxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUFlLENBQW1CLENBQUMsRUFBQyxRQUFRO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUM7TUFBQSxDQUFtQixDQUFDO0lBQUEsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDTyxDQUFDO01BQUFnQixRQUFBLEVBQUU7SUFBaVMsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDSSxFQUFFO01BQUNvQixFQUFFLEVBQUMsMENBQTBDO01BQUFELFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBMEMsQ0FBRSxDQUFDLEVBQUMsc0RBQXNEO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDTyxDQUFDO01BQUFnQixRQUFBLEVBQUU7SUFBZ0ssQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDZ0IsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNLLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBeUIsQ0FBcUIsQ0FBQyxFQUFDLDJFQUEyRSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFRLENBQW1CLENBQUMsRUFBQyxnRkFBZ0YsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBSyxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQyw4Q0FBOEMsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBbUIsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBSyxDQUFtQixDQUFDLEVBQUMsa0NBQWtDLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLDBDQUEwQyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFZLENBQW1CLENBQUMsRUFBQyxZQUFZLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQVMsQ0FBbUIsQ0FBQyxFQUFDLGlDQUFpQyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWdCLENBQXFCLENBQUMsRUFBQywwQ0FBMEMsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFZLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQXNFLENBQW1CLENBQUMsRUFBQyxPQUFPLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQWdCLENBQW1CLENBQUMsRUFBQyw0Q0FBNEMsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBSyxDQUFtQixDQUFDLEVBQUMsR0FBRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0ssRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUE0QixDQUFxQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUE4QyxDQUFtQixDQUFDLEVBQUMsVUFBVSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFPLENBQW1CLENBQUMsRUFBQyxvRUFBb0UsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUF5QixDQUFxQixDQUFDLEVBQUMsWUFBWSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyxPQUFPLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQVMsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBTSxDQUFtQixDQUFDLEVBQUMsU0FBUyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFZLENBQW1CLENBQUMsRUFBQyxTQUFTLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQU8sQ0FBbUIsQ0FBQyxFQUFDLGtFQUFrRTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0ssRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUF5QixDQUFxQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQyw4REFBOEQsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBTSxDQUFtQixDQUFDLEVBQUMsc0RBQXNEO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDSyxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNTLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXdCLENBQXFCLENBQUMsRUFBQywySUFBMkksZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBVSxDQUFtQixDQUFDLEVBQUMsc0JBQXNCLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQVMsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBVSxDQUFtQixDQUFDLEVBQUMscURBQXFEO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNJLEVBQUU7TUFBQ29CLEVBQUUsRUFBQywwREFBMEQ7TUFBQUQsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUEwRCxDQUFFLENBQUMsRUFBQyw2REFBNkQ7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNPLENBQUM7TUFBQWdCLFFBQUEsRUFBRTtJQUFnRixDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNNLEVBQUU7TUFBQWlCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0ssRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFRLENBQXFCLENBQUMsRUFBQyxpREFBaUQsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBVSxDQUFtQixDQUFDLEVBQUMsMkZBQTJGLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQXNCLENBQW1CLENBQUMsRUFBQyxpREFBaUQ7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNLLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBd0IsQ0FBcUIsQ0FBQyxFQUFDLGlDQUFpQyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFLLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQTZDLENBQW1CLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQWdCLENBQW1CLENBQUMsRUFBQyxrQkFBa0I7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUExQixXQUFBLENBQUF3QixJQUFBLEVBQUNyQixXQUFXLENBQUNLLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBMEIsQ0FBcUIsQ0FBQyxFQUFDLGtJQUFrSSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFLLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQU0sQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBVSxDQUFtQixDQUFDLEVBQUMsMkNBQTJDLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQVMsQ0FBbUIsQ0FBQyxFQUFDLDBDQUEwQztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0ssRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFjLENBQXFCLENBQUMsRUFBQyxtQ0FBbUMsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFtQixDQUFxQixDQUFDLEVBQUMsMEJBQTBCLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBZSxDQUFxQixDQUFDLEVBQUMsbUNBQW1DLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBa0IsQ0FBcUIsQ0FBQyxFQUFDLDRFQUE0RSxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFPLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQVEsQ0FBbUIsQ0FBQyxFQUFDLDJFQUEyRTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0ssRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDUyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUF1QixDQUFxQixDQUFDLEVBQUMseUVBQXlFLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQU0sQ0FBbUIsQ0FBQyxFQUFDLFFBQVEsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBRyxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFLLENBQW1CLENBQUMsRUFBQywwQkFBMEI7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ0ksRUFBRTtNQUFDb0IsRUFBRSxFQUFDLHFCQUFxQjtNQUFBRCxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQXFCLENBQUUsQ0FBQyxFQUFDLHVCQUF1QjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ1EsR0FBRztNQUFBZSxRQUFBLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFDeUIsU0FBUyxFQUFDLGVBQWU7UUFBQUosUUFBQSxFQUFFO01BQTZFLENBQW1CO0lBQUMsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDTyxDQUFDO01BQUFnQixRQUFBLEdBQUUsU0FBUyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFNLENBQW1CLENBQUMsRUFBQyx5Q0FBeUMsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBUSxDQUFtQixDQUFDLEVBQUMsZ0pBQWdKO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBd0IsSUFBQSxFQUFDckIsV0FBVyxDQUFDSSxFQUFFO01BQUNvQixFQUFFLEVBQUMsWUFBWTtNQUFBRCxRQUFBLGdCQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVksQ0FBRSxDQUFDLEVBQUMsWUFBWTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXdCLElBQUEsRUFBQ3JCLFdBQVcsQ0FBQ08sQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLGdCQUFnQixlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFzQixDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUFtRCxDQUFtQixDQUFDLEVBQUMsc0NBQXNDLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTRCLEdBQUEsRUFBQ3pCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBcUIsUUFBQSxFQUFFO01BQXdDLENBQW1CLENBQUMsRUFBQyxpQkFBaUIsZUFBQyxJQUFBMUIsV0FBQSxDQUFBNEIsR0FBQSxFQUFDekIsV0FBVyxDQUFDRSxJQUFJO1FBQUFxQixRQUFBLEVBQUU7TUFBc0IsQ0FBbUIsQ0FBQyxFQUFDLHVGQUF1RixlQUFDLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUN6QixXQUFXLENBQUNFLElBQUk7UUFBQXFCLFFBQUEsRUFBRTtNQUF5QixDQUFtQixDQUFDLEVBQUMsa0JBQWtCO0lBQUEsQ0FBZ0IsQ0FBQztFQUFBLENBQUUsQ0FBQztBQUNua1o7QUFDZSxTQUFTSyxVQUFVQSxDQUFDN0IsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFO0VBQzdDLE1BQU07SUFBQzhCLE9BQU8sRUFBRUM7RUFBUyxDQUFDLEdBQUc7SUFDM0IsR0FBRyxJQUFBYiw2QkFBa0IsRUFBQyxDQUFDO0lBQ3ZCLEdBQUdsQixLQUFLLENBQUNtQjtFQUNYLENBQUM7RUFDRCxPQUFPWSxTQUFTLGdCQUFHLElBQUFqQyxXQUFBLENBQUE0QixHQUFBLEVBQUNLLFNBQVM7SUFBQSxHQUFLL0IsS0FBSztJQUFBd0IsUUFBQSxlQUFFLElBQUExQixXQUFBLENBQUE0QixHQUFBLEVBQUMzQixpQkFBaUI7TUFBQSxHQUFLQztJQUFLLENBQUc7RUFBQyxDQUFXLENBQUMsR0FBR0QsaUJBQWlCLENBQUNDLEtBQUssQ0FBQztBQUNsSDtBQUFDZ0MsRUFBQSxHQU51QkgsVUFBVTtBQU9sQyxTQUFTUixvQkFBb0JBLENBQUNJLEVBQUUsRUFBRVEsU0FBUyxFQUFFQyxLQUFLLEVBQUU7RUFDbEQsTUFBTSxJQUFJQyxLQUFLLENBQUMsV0FBVyxJQUFJRixTQUFTLEdBQUcsV0FBVyxHQUFHLFFBQVEsQ0FBQyxHQUFHLElBQUksR0FBR1IsRUFBRSxHQUFHLG9FQUFvRSxJQUFJUyxLQUFLLEdBQUcscUNBQXFDLEdBQUdBLEtBQUssR0FBRyxnREFBZ0QsR0FBRyxFQUFFLENBQUMsQ0FBQztBQUMxUTtBQUFDLElBQUFGLEVBQUE7QUFBQUksWUFBQSxDQUFBSixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}