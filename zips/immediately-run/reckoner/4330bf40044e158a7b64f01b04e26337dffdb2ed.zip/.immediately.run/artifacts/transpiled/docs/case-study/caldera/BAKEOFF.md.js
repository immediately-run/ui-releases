var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      blockquote: "blockquote",
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      li: "li",
      p: "p",
      strong: "strong",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "the-sweep-idiom-bake-off-protocol-r3-380",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-sweep-idiom-bake-off-protocol-r3-380"
      }), "The sweep-idiom bake-off — protocol (R3-380)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Status:"
      }), " protocol landed 2026-08-27; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "runs pending"
      }), " (see §5 — what executing\nthem needs). The decision rule below is stated ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "before"
      }), " any results, so the\noutcome cannot be reverse-engineered from a preferred answer."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Companion to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "README.md",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "README.md"
        })
      }), " and\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "../../LBO_CASE_STUDY_GAP_ANALYSIS.md",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "../../LBO_CASE_STUDY_GAP_ANALYSIS.md"
        })
      }), " §2 G4:\nExcel's two-way data table is two minutes of clicking; Reckoner's parameter sweep is a\nmodel-as-function decomposition tax. The gap-closure plan (§3) decided: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "measure\nbefore building"
      }), " — if agents author the sweep idiom reliably from self-descriptions\nalone, an engine-level sweep construct is unnecessary; if not, the failure modes name\nits requirements."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-1",
      "data-slug": "1-the-question-falsifiable",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-1"
      }), "1 — The question, falsifiable"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: ["Can a formula-authoring agent, given ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "only"
        }), " the stdlib catalog\nself-descriptions (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "catalog.ts"
        }), ", RQ-A5) and the Caldera document's cells (excluding\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "model.sensitivity"
        }), " itself), author the sensitivity cell — 25 full model re-runs —\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "first-attempt correct and diff-auditable"
        }), "?"]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "\"First-attempt correct\" and \"diff-auditable\" are the E-1 bar (the DSL bake-off's\ncriteria), re-used deliberately so the two bake-offs are comparable."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-2",
      "data-slug": "2-the-rig",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-2"
      }), "2 — The rig"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Subjects."
        }), " N ≥ 10 independent agent runs (fresh session each; no memory of\nthis repo). Vary model + temperature per the E-1 protocol."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Inputs given."
        }), " (a) the stdlib catalog self-descriptions, verbatim; (b) the\nCaldera document as shipped ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "minus"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "model.sensitivity"
        }), " and its tests; (c) the\ntask: \"add a cell that computes sponsor IRR and MOIC for exit multiple\n7.0–9.0x × TLB leverage 4.0–6.0x\" — no idiom hints beyond what the catalog says."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Oracle."
        }), " The existing ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "expected.json.sensitivity_grid"
        }), " — an agent's cell passes\niff its 25 IRRs match to 1e-9. The oracle exists before the first run."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Loop."
        }), " The agent may run its cell against the document (the authoring loop's\nstep 4) but each ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "test-informed revision counts as an attempt"
        }), "; \"first-attempt\"\n= green with zero revisions."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-3",
      "data-slug": "3-scoring",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-3"
      }), "3 — Scoring"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Per run: attempts-to-green (1, 2, 3+), whether the solution used the idiom (pure\nmodule-scope helpers + one map cell) vs. an anti-pattern (duplicated model logic,\nreaching for nonexistent ambient state, hand-rolled rollforward/irr), and diff size\nof the final worksheet vs. the shipped one."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-4",
      "data-slug": "4-the-decision-rule-fixed-now",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-4"
      }), "4 — The decision rule (fixed now)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Idiom-reliable"
        }), " ⇒ ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "the construct is rejected as unnecessary"
        }), ": ≥ 8/10 runs\nfirst-attempt green with the idiom shape. Record in the gap-closure plan §3 and\nclose G4."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Idiom-fails"
        }), " ⇒ ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "the failure modes become the requirements list"
        }), " for a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "sweep()"
        }), "\ndesign spike: < 8/10 first-attempt green, or ≥ 5/10 requiring revision to discover\nthe model-as-function split (i.e. the catalog alone did not teach it)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: "Either way the RESULT + the raw runs land in this directory; the decision is\nrecorded with links, not prose memory."
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-5",
      "data-slug": "5-what-executing-this-needs-honest-state",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-5"
      }), "5 — What executing this needs (honest state)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The assistant realm (the G12 harness that would run formula-authoring agents over a\nlive document) is not built — plan M2. Until it is, the runs cannot be executed\nhonestly, and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "no substitute result will be fabricated"
      }), " (a text-only \"ask an LLM to\nwrite the cell\" drill lacks the run-the-cell loop that step 2 of the authoring loop\nmakes load-bearing). Reopen this file when the assistant realm lands; the protocol is\nready and the oracle already ships in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "expected.json"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-6",
      "data-slug": "6-provenance",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-6"
      }), "6 — Provenance"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Filed by R3-380 (project reckoner-lbo-gaps, W8/G4). The prompt half of the item —\nthe sweep idiom section in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "docs/assistant/FORMULA_AUTHORING_PROMPT.md"
      }), " — landed the\nsame day; note that its existence means the bake-off's \"no idiom hints beyond the\ncatalog\" arm must ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "exclude"
      }), " that prompt text for the control condition (the\ncatalog is the surface an agent with only self-descriptions sees)."]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/case-study/caldera/BAKEOFF.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiYmxvY2txdW90ZSIsImNvZGUiLCJlbSIsImgxIiwiaDIiLCJsaSIsInAiLCJzdHJvbmciLCJ1bCIsIl9wcm92aWRlQ29tcG9uZW50cyIsImNvbXBvbmVudHMiLCJIZWFkaW5nQW5jaG9yIiwiX21pc3NpbmdNZHhSZWZlcmVuY2UiLCJqc3hzIiwiRnJhZ21lbnQiLCJjaGlsZHJlbiIsImlkIiwianN4IiwiaHJlZiIsIk1EWENvbnRlbnQiLCJ3cmFwcGVyIiwiTURYTGF5b3V0IiwiX2MiLCJjb21wb25lbnQiLCJwbGFjZSIsIkVycm9yIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQkFLRU9GRi5tZCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKkBqc3hSdW50aW1lIGF1dG9tYXRpYyovXG4vKkBqc3hJbXBvcnRTb3VyY2UgcmVhY3QqL1xuaW1wb3J0IHt1c2VNRFhDb21wb25lbnRzIGFzIF9wcm92aWRlQ29tcG9uZW50c30gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrL01EWFByb3ZpZGVyXCI7XG5mdW5jdGlvbiBfY3JlYXRlTWR4Q29udGVudChwcm9wcykge1xuICBjb25zdCBfY29tcG9uZW50cyA9IHtcbiAgICBhOiBcImFcIixcbiAgICBibG9ja3F1b3RlOiBcImJsb2NrcXVvdGVcIixcbiAgICBjb2RlOiBcImNvZGVcIixcbiAgICBlbTogXCJlbVwiLFxuICAgIGgxOiBcImgxXCIsXG4gICAgaDI6IFwiaDJcIixcbiAgICBsaTogXCJsaVwiLFxuICAgIHA6IFwicFwiLFxuICAgIHN0cm9uZzogXCJzdHJvbmdcIixcbiAgICB1bDogXCJ1bFwiLFxuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfSwge0hlYWRpbmdBbmNob3J9ID0gX2NvbXBvbmVudHM7XG4gIGlmICghSGVhZGluZ0FuY2hvcikgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJIZWFkaW5nQW5jaG9yXCIsIHRydWUpO1xuICByZXR1cm4gPD48X2NvbXBvbmVudHMuaDEgaWQ9XCJ0aGUtc3dlZXAtaWRpb20tYmFrZS1vZmYtcHJvdG9jb2wtcjMtMzgwXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJ0aGUtc3dlZXAtaWRpb20tYmFrZS1vZmYtcHJvdG9jb2wtcjMtMzgwXCIgLz57XCJUaGUgc3dlZXAtaWRpb20gYmFrZS1vZmYg4oCUIHByb3RvY29sIChSMy0zODApXCJ9PC9fY29tcG9uZW50cy5oMT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlN0YXR1czpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgcHJvdG9jb2wgbGFuZGVkIDIwMjYtMDgtMjc7IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicnVucyBwZW5kaW5nXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChzZWUgwqc1IOKAlCB3aGF0IGV4ZWN1dGluZ1xcbnRoZW0gbmVlZHMpLiBUaGUgZGVjaXNpb24gcnVsZSBiZWxvdyBpcyBzdGF0ZWQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJiZWZvcmVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYW55IHJlc3VsdHMsIHNvIHRoZVxcbm91dGNvbWUgY2Fubm90IGJlIHJldmVyc2UtZW5naW5lZXJlZCBmcm9tIGEgcHJlZmVycmVkIGFuc3dlci5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiQ29tcGFuaW9uIHRvIFwifTxfY29tcG9uZW50cy5hIGhyZWY9XCJSRUFETUUubWRcIj48X2NvbXBvbmVudHMuY29kZT57XCJSRUFETUUubWRcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5hPntcIiBhbmRcXG5cIn08X2NvbXBvbmVudHMuYSBocmVmPVwiLi4vLi4vTEJPX0NBU0VfU1RVRFlfR0FQX0FOQUxZU0lTLm1kXCI+PF9jb21wb25lbnRzLmNvZGU+e1wiLi4vLi4vTEJPX0NBU0VfU1RVRFlfR0FQX0FOQUxZU0lTLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuYT57XCIgwqcyIEc0OlxcbkV4Y2VsJ3MgdHdvLXdheSBkYXRhIHRhYmxlIGlzIHR3byBtaW51dGVzIG9mIGNsaWNraW5nOyBSZWNrb25lcidzIHBhcmFtZXRlciBzd2VlcCBpcyBhXFxubW9kZWwtYXMtZnVuY3Rpb24gZGVjb21wb3NpdGlvbiB0YXguIFRoZSBnYXAtY2xvc3VyZSBwbGFuICjCpzMpIGRlY2lkZWQ6IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibWVhc3VyZVxcbmJlZm9yZSBidWlsZGluZ1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgaWYgYWdlbnRzIGF1dGhvciB0aGUgc3dlZXAgaWRpb20gcmVsaWFibHkgZnJvbSBzZWxmLWRlc2NyaXB0aW9uc1xcbmFsb25lLCBhbiBlbmdpbmUtbGV2ZWwgc3dlZXAgY29uc3RydWN0IGlzIHVubmVjZXNzYXJ5OyBpZiBub3QsIHRoZSBmYWlsdXJlIG1vZGVzIG5hbWVcXG5pdHMgcmVxdWlyZW1lbnRzLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtMVwiIGRhdGEtc2x1Zz1cIjEtdGhlLXF1ZXN0aW9uLWZhbHNpZmlhYmxlXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtMVwiIC8+e1wiMSDigJQgVGhlIHF1ZXN0aW9uLCBmYWxzaWZpYWJsZVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiQ2FuIGEgZm9ybXVsYS1hdXRob3JpbmcgYWdlbnQsIGdpdmVuIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wib25seVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB0aGUgc3RkbGliIGNhdGFsb2dcXG5zZWxmLWRlc2NyaXB0aW9ucyAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2F0YWxvZy50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFJRLUE1KSBhbmQgdGhlIENhbGRlcmEgZG9jdW1lbnQncyBjZWxscyAoZXhjbHVkaW5nXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibW9kZWwuc2Vuc2l0aXZpdHlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGl0c2VsZiksIGF1dGhvciB0aGUgc2Vuc2l0aXZpdHkgY2VsbCDigJQgMjUgZnVsbCBtb2RlbCByZS1ydW5zIOKAlFxcblwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZmlyc3QtYXR0ZW1wdCBjb3JyZWN0IGFuZCBkaWZmLWF1ZGl0YWJsZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIj9cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlxcXCJGaXJzdC1hdHRlbXB0IGNvcnJlY3RcXFwiIGFuZCBcXFwiZGlmZi1hdWRpdGFibGVcXFwiIGFyZSB0aGUgRS0xIGJhciAodGhlIERTTCBiYWtlLW9mZidzXFxuY3JpdGVyaWEpLCByZS11c2VkIGRlbGliZXJhdGVseSBzbyB0aGUgdHdvIGJha2Utb2ZmcyBhcmUgY29tcGFyYWJsZS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTJcIiBkYXRhLXNsdWc9XCIyLXRoZS1yaWdcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy0yXCIgLz57XCIyIOKAlCBUaGUgcmlnXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiU3ViamVjdHMuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIE4g4omlIDEwIGluZGVwZW5kZW50IGFnZW50IHJ1bnMgKGZyZXNoIHNlc3Npb24gZWFjaDsgbm8gbWVtb3J5IG9mXFxudGhpcyByZXBvKS4gVmFyeSBtb2RlbCArIHRlbXBlcmF0dXJlIHBlciB0aGUgRS0xIHByb3RvY29sLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiSW5wdXRzIGdpdmVuLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoYSkgdGhlIHN0ZGxpYiBjYXRhbG9nIHNlbGYtZGVzY3JpcHRpb25zLCB2ZXJiYXRpbTsgKGIpIHRoZVxcbkNhbGRlcmEgZG9jdW1lbnQgYXMgc2hpcHBlZCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm1pbnVzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1vZGVsLnNlbnNpdGl2aXR5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhbmQgaXRzIHRlc3RzOyAoYykgdGhlXFxudGFzazogXFxcImFkZCBhIGNlbGwgdGhhdCBjb21wdXRlcyBzcG9uc29yIElSUiBhbmQgTU9JQyBmb3IgZXhpdCBtdWx0aXBsZVxcbjcuMOKAkzkuMHggw5cgVExCIGxldmVyYWdlIDQuMOKAkzYuMHhcXFwiIOKAlCBubyBpZGlvbSBoaW50cyBiZXlvbmQgd2hhdCB0aGUgY2F0YWxvZyBzYXlzLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiT3JhY2xlLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGUgZXhpc3RpbmcgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZXhwZWN0ZWQuanNvbi5zZW5zaXRpdml0eV9ncmlkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgYW4gYWdlbnQncyBjZWxsIHBhc3Nlc1xcbmlmZiBpdHMgMjUgSVJScyBtYXRjaCB0byAxZS05LiBUaGUgb3JhY2xlIGV4aXN0cyBiZWZvcmUgdGhlIGZpcnN0IHJ1bi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkxvb3AuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRoZSBhZ2VudCBtYXkgcnVuIGl0cyBjZWxsIGFnYWluc3QgdGhlIGRvY3VtZW50ICh0aGUgYXV0aG9yaW5nIGxvb3Anc1xcbnN0ZXAgNCkgYnV0IGVhY2ggXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ0ZXN0LWluZm9ybWVkIHJldmlzaW9uIGNvdW50cyBhcyBhbiBhdHRlbXB0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiOyBcXFwiZmlyc3QtYXR0ZW1wdFxcXCJcXG49IGdyZWVuIHdpdGggemVybyByZXZpc2lvbnMuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInNlYy0zXCIgZGF0YS1zbHVnPVwiMy1zY29yaW5nXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtM1wiIC8+e1wiMyDigJQgU2NvcmluZ1wifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiUGVyIHJ1bjogYXR0ZW1wdHMtdG8tZ3JlZW4gKDEsIDIsIDMrKSwgd2hldGhlciB0aGUgc29sdXRpb24gdXNlZCB0aGUgaWRpb20gKHB1cmVcXG5tb2R1bGUtc2NvcGUgaGVscGVycyArIG9uZSBtYXAgY2VsbCkgdnMuIGFuIGFudGktcGF0dGVybiAoZHVwbGljYXRlZCBtb2RlbCBsb2dpYyxcXG5yZWFjaGluZyBmb3Igbm9uZXhpc3RlbnQgYW1iaWVudCBzdGF0ZSwgaGFuZC1yb2xsZWQgcm9sbGZvcndhcmQvaXJyKSwgYW5kIGRpZmYgc2l6ZVxcbm9mIHRoZSBmaW5hbCB3b3Jrc2hlZXQgdnMuIHRoZSBzaGlwcGVkIG9uZS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTRcIiBkYXRhLXNsdWc9XCI0LXRoZS1kZWNpc2lvbi1ydWxlLWZpeGVkLW5vd1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTRcIiAvPntcIjQg4oCUIFRoZSBkZWNpc2lvbiBydWxlIChmaXhlZCBub3cpXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiSWRpb20tcmVsaWFibGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oeSIFwifTxfY29tcG9uZW50cy5lbT57XCJ0aGUgY29uc3RydWN0IGlzIHJlamVjdGVkIGFzIHVubmVjZXNzYXJ5XCJ9PC9fY29tcG9uZW50cy5lbT57XCI6IOKJpSA4LzEwIHJ1bnNcXG5maXJzdC1hdHRlbXB0IGdyZWVuIHdpdGggdGhlIGlkaW9tIHNoYXBlLiBSZWNvcmQgaW4gdGhlIGdhcC1jbG9zdXJlIHBsYW4gwqczIGFuZFxcbmNsb3NlIEc0LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiSWRpb20tZmFpbHNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oeSIFwifTxfY29tcG9uZW50cy5lbT57XCJ0aGUgZmFpbHVyZSBtb2RlcyBiZWNvbWUgdGhlIHJlcXVpcmVtZW50cyBsaXN0XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgZm9yIGEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3dlZXAoKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG5kZXNpZ24gc3Bpa2U6IDwgOC8xMCBmaXJzdC1hdHRlbXB0IGdyZWVuLCBvciDiiaUgNS8xMCByZXF1aXJpbmcgcmV2aXNpb24gdG8gZGlzY292ZXJcXG50aGUgbW9kZWwtYXMtZnVuY3Rpb24gc3BsaXQgKGkuZS4gdGhlIGNhdGFsb2cgYWxvbmUgZGlkIG5vdCB0ZWFjaCBpdCkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiRWl0aGVyIHdheSB0aGUgUkVTVUxUICsgdGhlIHJhdyBydW5zIGxhbmQgaW4gdGhpcyBkaXJlY3Rvcnk7IHRoZSBkZWNpc2lvbiBpc1xcbnJlY29yZGVkIHdpdGggbGlua3MsIG5vdCBwcm9zZSBtZW1vcnkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInNlYy01XCIgZGF0YS1zbHVnPVwiNS13aGF0LWV4ZWN1dGluZy10aGlzLW5lZWRzLWhvbmVzdC1zdGF0ZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTVcIiAvPntcIjUg4oCUIFdoYXQgZXhlY3V0aW5nIHRoaXMgbmVlZHMgKGhvbmVzdCBzdGF0ZSlcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSBhc3Npc3RhbnQgcmVhbG0gKHRoZSBHMTIgaGFybmVzcyB0aGF0IHdvdWxkIHJ1biBmb3JtdWxhLWF1dGhvcmluZyBhZ2VudHMgb3ZlciBhXFxubGl2ZSBkb2N1bWVudCkgaXMgbm90IGJ1aWx0IOKAlCBwbGFuIE0yLiBVbnRpbCBpdCBpcywgdGhlIHJ1bnMgY2Fubm90IGJlIGV4ZWN1dGVkXFxuaG9uZXN0bHksIGFuZCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vIHN1YnN0aXR1dGUgcmVzdWx0IHdpbGwgYmUgZmFicmljYXRlZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoYSB0ZXh0LW9ubHkgXFxcImFzayBhbiBMTE0gdG9cXG53cml0ZSB0aGUgY2VsbFxcXCIgZHJpbGwgbGFja3MgdGhlIHJ1bi10aGUtY2VsbCBsb29wIHRoYXQgc3RlcCAyIG9mIHRoZSBhdXRob3JpbmcgbG9vcFxcbm1ha2VzIGxvYWQtYmVhcmluZykuIFJlb3BlbiB0aGlzIGZpbGUgd2hlbiB0aGUgYXNzaXN0YW50IHJlYWxtIGxhbmRzOyB0aGUgcHJvdG9jb2wgaXNcXG5yZWFkeSBhbmQgdGhlIG9yYWNsZSBhbHJlYWR5IHNoaXBzIGluIFwifTxfY29tcG9uZW50cy5jb2RlPntcImV4cGVjdGVkLmpzb25cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtNlwiIGRhdGEtc2x1Zz1cIjYtcHJvdmVuYW5jZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTZcIiAvPntcIjYg4oCUIFByb3ZlbmFuY2VcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkZpbGVkIGJ5IFIzLTM4MCAocHJvamVjdCByZWNrb25lci1sYm8tZ2FwcywgVzgvRzQpLiBUaGUgcHJvbXB0IGhhbGYgb2YgdGhlIGl0ZW0g4oCUXFxudGhlIHN3ZWVwIGlkaW9tIHNlY3Rpb24gaW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZG9jcy9hc3Npc3RhbnQvRk9STVVMQV9BVVRIT1JJTkdfUFJPTVBULm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgbGFuZGVkIHRoZVxcbnNhbWUgZGF5OyBub3RlIHRoYXQgaXRzIGV4aXN0ZW5jZSBtZWFucyB0aGUgYmFrZS1vZmYncyBcXFwibm8gaWRpb20gaGludHMgYmV5b25kIHRoZVxcbmNhdGFsb2dcXFwiIGFybSBtdXN0IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZXhjbHVkZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB0aGF0IHByb21wdCB0ZXh0IGZvciB0aGUgY29udHJvbCBjb25kaXRpb24gKHRoZVxcbmNhdGFsb2cgaXMgdGhlIHN1cmZhY2UgYW4gYWdlbnQgd2l0aCBvbmx5IHNlbGYtZGVzY3JpcHRpb25zIHNlZXMpLlwifTwvX2NvbXBvbmVudHMucD48Lz47XG59XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNRFhDb250ZW50KHByb3BzID0ge30pIHtcbiAgY29uc3Qge3dyYXBwZXI6IE1EWExheW91dH0gPSB7XG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9O1xuICByZXR1cm4gTURYTGF5b3V0ID8gPE1EWExheW91dCB7Li4ucHJvcHN9PjxfY3JlYXRlTWR4Q29udGVudCB7Li4ucHJvcHN9IC8+PC9NRFhMYXlvdXQ+IDogX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpO1xufVxuZnVuY3Rpb24gX21pc3NpbmdNZHhSZWZlcmVuY2UoaWQsIGNvbXBvbmVudCwgcGxhY2UpIHtcbiAgdGhyb3cgbmV3IEVycm9yKFwiRXhwZWN0ZWQgXCIgKyAoY29tcG9uZW50ID8gXCJjb21wb25lbnRcIiA6IFwib2JqZWN0XCIpICsgXCIgYFwiICsgaWQgKyBcImAgdG8gYmUgZGVmaW5lZDogeW91IGxpa2VseSBmb3Jnb3QgdG8gaW1wb3J0LCBwYXNzLCBvciBwcm92aWRlIGl0LlwiICsgKHBsYWNlID8gXCJcXG5JdOKAmXMgcmVmZXJlbmNlZCBpbiB5b3VyIGNvZGUgYXQgYFwiICsgcGxhY2UgKyBcImAgaW4gYC9hcHAvZG9jcy9jYXNlLXN0dWR5L2NhbGRlcmEvQkFLRU9GRi5tZGBcIiA6IFwiXCIpKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQXdGLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUZ4RjtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU1DLFdBQVcsR0FBRztNQUNsQkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsVUFBVSxFQUFFLFlBQVk7TUFDeEJDLElBQUksRUFBRSxNQUFNO01BQ1pDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLENBQUMsRUFBRSxHQUFHO01BQ05DLE1BQU0sRUFBRSxRQUFRO01BQ2hCQyxFQUFFLEVBQUUsSUFBSTtNQUNSLEdBQUcsSUFBQUMsNkJBQWtCLEVBQUMsQ0FBQztNQUN2QixHQUFHWixLQUFLLENBQUNhO0lBQ1gsQ0FBQztJQUFFO01BQUNDO0lBQWEsQ0FBQyxHQUFHYixXQUFXO0VBQ2hDLElBQUksQ0FBQ2EsYUFBYSxFQUFFQyxvQkFBb0IsQ0FBQyxlQUFlLEVBQUUsSUFBSSxDQUFDO0VBQy9ELG9CQUFPLElBQUFqQixXQUFBLENBQUFrQixJQUFBLEVBQUFsQixXQUFBLENBQUFtQixRQUFBO0lBQUFDLFFBQUEsZ0JBQUUsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDSyxFQUFFO01BQUNhLEVBQUUsRUFBQywwQ0FBMEM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUEwQyxDQUFFLENBQUMsRUFBQyw4Q0FBOEM7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ1EsQ0FBQztNQUFBUyxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQVMsQ0FBcUIsQ0FBQyxFQUFDLCtCQUErQixlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQWMsQ0FBcUIsQ0FBQyxFQUFDLDRFQUE0RSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQVEsQ0FBcUIsQ0FBQyxFQUFDLHFGQUFxRjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDUSxDQUFDO01BQUFTLFFBQUEsR0FBRSxlQUFlLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsQ0FBQztRQUFDbUIsSUFBSSxFQUFDLFdBQVc7UUFBQUgsUUFBQSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNHLElBQUk7VUFBQWMsUUFBQSxFQUFFO1FBQVcsQ0FBbUI7TUFBQyxDQUFlLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0MsQ0FBQztRQUFDbUIsSUFBSSxFQUFDLHNDQUFzQztRQUFBSCxRQUFBLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0csSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBc0MsQ0FBbUI7TUFBQyxDQUFlLENBQUMsRUFBQywyS0FBMkssZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDUyxNQUFNO1FBQUFRLFFBQUEsRUFBRTtNQUEwQixDQUFxQixDQUFDLEVBQUMsK0tBQStLO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7TUFBQ1ksRUFBRSxFQUFDLE9BQU87TUFBQyxhQUFVLDRCQUE0QjtNQUFBRCxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMsK0JBQStCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNFLFVBQVU7TUFBQWUsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNRLENBQUM7UUFBQVMsUUFBQSxHQUFFLHVDQUF1QyxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07VUFBQVEsUUFBQSxFQUFFO1FBQU0sQ0FBcUIsQ0FBQyxFQUFDLDBDQUEwQyxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNHLElBQUk7VUFBQWMsUUFBQSxFQUFFO1FBQVksQ0FBbUIsQ0FBQyxFQUFDLHdEQUF3RCxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNHLElBQUk7VUFBQWMsUUFBQSxFQUFFO1FBQW1CLENBQW1CLENBQUMsRUFBQyxtRUFBbUUsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDUyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUEwQyxDQUFxQixDQUFDLEVBQUMsR0FBRztNQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBeUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDUSxDQUFDO01BQUFTLFFBQUEsRUFBRTtJQUE0SixDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFrQixJQUFBLEVBQUNmLFdBQVcsQ0FBQ00sRUFBRTtNQUFDWSxFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUsV0FBVztNQUFBRCxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMsYUFBYTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDVSxFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTyxFQUFFO1FBQUFVLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBVyxDQUFxQixDQUFDLEVBQUMsOEhBQThIO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNPLEVBQUU7UUFBQVUsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDUyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFlLENBQXFCLENBQUMsRUFBQyw0RkFBNEYsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDUyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFPLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0csSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBbUIsQ0FBbUIsQ0FBQyxFQUFDLHFMQUFxTDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTyxFQUFFO1FBQUFVLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBUyxDQUFxQixDQUFDLEVBQUMsZ0JBQWdCLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0csSUFBSTtVQUFBYyxRQUFBLEVBQUU7UUFBZ0MsQ0FBbUIsQ0FBQyxFQUFDLG1HQUFtRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTyxFQUFFO1FBQUFVLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBTyxDQUFxQixDQUFDLEVBQUMsMkZBQTJGLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBNkMsQ0FBcUIsQ0FBQyxFQUFDLG1EQUFtRDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7TUFBQ1ksRUFBRSxFQUFDLE9BQU87TUFBQyxhQUFVLFdBQVc7TUFBQUQsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLGFBQWE7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFyQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNRLENBQUM7TUFBQVMsUUFBQSxFQUFFO0lBQXVTLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTSxFQUFFO01BQUNZLEVBQUUsRUFBQyxPQUFPO01BQUMsYUFBVSwrQkFBK0I7TUFBQUQsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLG1DQUFtQztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDVSxFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDTyxFQUFFO1FBQUFVLFFBQUEsZ0JBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBUSxRQUFBLEVBQUU7UUFBZ0IsQ0FBcUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDSSxFQUFFO1VBQUFhLFFBQUEsRUFBRTtRQUEwQyxDQUFpQixDQUFDLEVBQUMsMkdBQTJHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNPLEVBQUU7UUFBQVUsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDUyxNQUFNO1VBQUFRLFFBQUEsRUFBRTtRQUFhLENBQXFCLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ0ksRUFBRTtVQUFBYSxRQUFBLEVBQUU7UUFBZ0QsQ0FBaUIsQ0FBQyxFQUFDLFNBQVMsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRyxJQUFJO1VBQUFjLFFBQUEsRUFBRTtRQUFTLENBQW1CLENBQUMsRUFBQyw4SkFBOEo7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNPLEVBQUU7UUFBQVUsUUFBQSxFQUFFO01BQXNILENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7TUFBQ1ksRUFBRSxFQUFDLE9BQU87TUFBQyxhQUFVLDBDQUEwQztNQUFBRCxRQUFBLGdCQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMsOENBQThDO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBckIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNRLENBQUM7TUFBQVMsUUFBQSxHQUFFLHNMQUFzTCxlQUFDLElBQUFwQixXQUFBLENBQUFzQixHQUFBLEVBQUNuQixXQUFXLENBQUNTLE1BQU07UUFBQVEsUUFBQSxFQUFFO01BQXlDLENBQXFCLENBQUMsRUFBQyxvUEFBb1AsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRyxJQUFJO1FBQUFjLFFBQUEsRUFBRTtNQUFlLENBQW1CLENBQUMsRUFBQyxHQUFHO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBcEIsV0FBQSxDQUFBa0IsSUFBQSxFQUFDZixXQUFXLENBQUNNLEVBQUU7TUFBQ1ksRUFBRSxFQUFDLE9BQU87TUFBQyxhQUFVLGNBQWM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLGdCQUFnQjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXJCLFdBQUEsQ0FBQWtCLElBQUEsRUFBQ2YsV0FBVyxDQUFDUSxDQUFDO01BQUFTLFFBQUEsR0FBRSxnSEFBZ0gsZUFBQyxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDbkIsV0FBVyxDQUFDRyxJQUFJO1FBQUFjLFFBQUEsRUFBRTtNQUE0QyxDQUFtQixDQUFDLEVBQUMsd0hBQXdILGVBQUMsSUFBQXBCLFdBQUEsQ0FBQXNCLEdBQUEsRUFBQ25CLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBUSxRQUFBLEVBQUU7TUFBUyxDQUFxQixDQUFDLEVBQUMsc0hBQXNIO0lBQUEsQ0FBZ0IsQ0FBQztFQUFBLENBQUUsQ0FBQztBQUMxL007QUFDZSxTQUFTSSxVQUFVQSxDQUFDdEIsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFO0VBQzdDLE1BQU07SUFBQ3VCLE9BQU8sRUFBRUM7RUFBUyxDQUFDLEdBQUc7SUFDM0IsR0FBRyxJQUFBWiw2QkFBa0IsRUFBQyxDQUFDO0lBQ3ZCLEdBQUdaLEtBQUssQ0FBQ2E7RUFDWCxDQUFDO0VBQ0QsT0FBT1csU0FBUyxnQkFBRyxJQUFBMUIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDSSxTQUFTO0lBQUEsR0FBS3hCLEtBQUs7SUFBQWtCLFFBQUEsZUFBRSxJQUFBcEIsV0FBQSxDQUFBc0IsR0FBQSxFQUFDckIsaUJBQWlCO01BQUEsR0FBS0M7SUFBSyxDQUFHO0VBQUMsQ0FBVyxDQUFDLEdBQUdELGlCQUFpQixDQUFDQyxLQUFLLENBQUM7QUFDbEg7QUFBQ3lCLEVBQUEsR0FOdUJILFVBQVU7QUFPbEMsU0FBU1Asb0JBQW9CQSxDQUFDSSxFQUFFLEVBQUVPLFNBQVMsRUFBRUMsS0FBSyxFQUFFO0VBQ2xELE1BQU0sSUFBSUMsS0FBSyxDQUFDLFdBQVcsSUFBSUYsU0FBUyxHQUFHLFdBQVcsR0FBRyxRQUFRLENBQUMsR0FBRyxJQUFJLEdBQUdQLEVBQUUsR0FBRyxvRUFBb0UsSUFBSVEsS0FBSyxHQUFHLHFDQUFxQyxHQUFHQSxLQUFLLEdBQUcsZ0RBQWdELEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDMVE7QUFBQyxJQUFBRixFQUFBO0FBQUFJLFlBQUEsQ0FBQUosRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}