var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      code: "code",
      h1: "h1",
      h2: "h2",
      li: "li",
      ol: "ol",
      p: "p",
      pre: "pre",
      strong: "strong",
      table: "table",
      tbody: "tbody",
      td: "td",
      th: "th",
      thead: "thead",
      tr: "tr",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "caldera-components-lbo-case-study",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "caldera-components-lbo-case-study"
      }), "Caldera Components — LBO case study"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The financial-domain sibling of the Meridian study: a complete leveraged-buyout\nmodel, ported from a real-shape Excel workbook to a Reckoner document, with\nPython-verified truth. Commissioned to find the gaps between what Reckoner can\ncurrently do and what finance people use Excel for — the full findings live in\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "../../LBO_CASE_STUDY_GAP_ANALYSIS.md",
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "../../LBO_CASE_STUDY_GAP_ANALYSIS.md"
        })
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Target:"
      }), " Caldera Components Ltd (fictional mid-market industrial components\nmaker). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Sponsor:"
      }), " Harrow Capital (fictional). Close 2026-12-31, five-year hold\n(FY2027–FY2031). Structurally the canonical public LBO template (Macabacus,\n\"LBO model — short form\": assumptions → sources & uses → operating model → debt\nschedule → returns → sensitivity; see\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
        href: "https://macabacus.com/valuation/lbo-overview",
        children: "https://macabacus.com/valuation/lbo-overview"
      }), ")."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Everything is computed in Python (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "generate.py"
      }), ", deterministic, no RNG) so the\nnumbers are real and verified: sources equal uses to float precision, the debt\nroll-forward conserves, the circular average-balance interest variant is\nconverged to a fixed point, and the 25-cell sensitivity grid is 25 full model\nre-runs. The Reckoner port matches this truth to 1e-6 on every schedule row and\nto 1e-10 on IRR (proven by ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/document/calderaCaseStudy.test.ts"
      }), ")."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "files",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "files"
      }), "Files"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "File"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "What it is"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "generate.py"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "truth generator: model in Python, writes everything below"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "xlsx_writer.py"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "dependency-free .xlsx writer (live formulas, named ranges, iterative calc)"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "caldera_lbo.xlsx"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["the Excel \"before\": 8 sheets, 963 cells, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "622 live formulas"
            }), " — incl. MIN/MAX revolver logic, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "IRR()"
            }), ", a deliberately ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "circular average-balance sheet"
            }), ", a hand-rolled two-way sensitivity engine, and an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "IF(...,\"OK\",\"BREAK\")"
            }), " checks sheet"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "expected.json"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "full-detail truth (the vitest harness asserts against this)"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "data/*.csv"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "human-readable inputs: historicals, management plan, assumptions"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "document/"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["the Reckoner \"after\" — a real loadable document: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "reckoner.json"
            }), ", 2 worksheets (13 model cells + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "22 test cells"
            }), "), 5 fixtures, 1 template"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "document/worksheets/model.sheet.js"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["the model as pure functions: operating build (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "join"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "scan"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "groupBy"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "lag"
            }), "), sources & uses, debt schedule (multi-state packed ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "scan"
            }), "), the circular variant as an explicit converged fixed point, bisection IRR, 25-run sensitivity grid, goal-seek breakeven"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "document/worksheets/checks.sheet.js"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "the Excel checks sheet, upgraded: specification (oracle), conservation, permutation-invariance, and property tests (covenants, monotonicity, convergence) with mandatory kinds"
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "the-deal-base-case",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "the-deal-base-case"
      }), "The deal (base case)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["LTM EBITDA 46.27 → entry 8.0x = EV 370.16. Funding: 5.0x TLB (8.0%, 1%\nmandatory amort, 75% cash sweep) + 1.0x mezzanine (12% cash / 2% PIK) + 2.0\nbalance-sheet cash + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "sponsor equity 114.88"
      }), " (the plug; sources = uses to\n5.7e-14). Exit FY2031 at 8.0x EBITDA 64.61 → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "exit equity 315.46, MOIC\n2.75x, IRR 22.39%"
      }), " (average-balance interest variant: 22.52%). Breakeven exit\nmultiple for the 20% hurdle: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "7.54x"
      }), ". Covenants hold all years (worst\nleverage 5.31x vs 6.0x max; worst coverage 2.06x vs 2.0x min)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "planted-probes-what-the-port-had-to-survive",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "planted-probes-what-the-port-had-to-survive"
      }), "Planted probes (what the port had to survive)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Circularity"
        }), " — average-balance interest (Excel's iterative-calc sheet)\nvs Reckoner's rejected cycles: ported as an explicit per-year fixed point\ninside one cell, converged to 1e-12, with a property test proving\nconvergence. The gap report's headline finding."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Goal seek"
        }), " — breakeven exit multiple: bisection over the model-as-a-function."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Two-way sensitivity"
        }), " — Excel data table / hidden engine sheet vs\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "runModel()"
        }), " mapped over 25 parameter pairs (forces model-as-function\ndecomposition)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Multi-state roll-forward"
        }), " — the debt schedule is THE canonical financial\nstructure; the stdlib has no rollforward primitive (cumsum is single-state),\nso the port uses a custom packed ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "scan"
        }), " op."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Rate-bearing inputs"
        }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "scaleInvariance"
        }), " scales every numeric leaf\n(including margins/growth), making it unusable on financial inputs;\npermutation invariance + property tests carry the metamorphic leg instead."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The oracle gap"
        }), " — test-declared fixture inputs never reach the test\ncontext (test-runner wiring), so the Python oracle is inlined as constants."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "running",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "running"
      }), "Running"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-bash",
        children: "python3 generate.py                       # regenerate truth + xlsx (deterministic)\ncd ../../.. && npx vitest run src/document/calderaCaseStudy.test.ts\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The vitest harness loads ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "document/"
      }), " through the real ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "loadDocument"
      }), " loader,\nruns it in the real SES-compartment engine, asserts every schedule year, the\nreturns, the 25 grid cells, and the 22 workbook tests against ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "expected.json"
      }), ",\nand asserts the load-bearing cells earn a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "validated"
      }), " verdict (a metamorphic or\nproperty leg — not merely pinned to examples)."]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/case-study/caldera/README.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiY29kZSIsImgxIiwiaDIiLCJsaSIsIm9sIiwicCIsInByZSIsInN0cm9uZyIsInRhYmxlIiwidGJvZHkiLCJ0ZCIsInRoIiwidGhlYWQiLCJ0ciIsIl9wcm92aWRlQ29tcG9uZW50cyIsImNvbXBvbmVudHMiLCJIZWFkaW5nQW5jaG9yIiwiX21pc3NpbmdNZHhSZWZlcmVuY2UiLCJqc3hzIiwiRnJhZ21lbnQiLCJjaGlsZHJlbiIsImlkIiwianN4IiwiaHJlZiIsImNsYXNzTmFtZSIsIk1EWENvbnRlbnQiLCJ3cmFwcGVyIiwiTURYTGF5b3V0IiwiX2MiLCJjb21wb25lbnQiLCJwbGFjZSIsIkVycm9yIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUkVBRE1FLm1kIl0sInNvdXJjZXNDb250ZW50IjpbIi8qQGpzeFJ1bnRpbWUgYXV0b21hdGljKi9cbi8qQGpzeEltcG9ydFNvdXJjZSByZWFjdCovXG5pbXBvcnQge3VzZU1EWENvbXBvbmVudHMgYXMgX3Byb3ZpZGVDb21wb25lbnRzfSBmcm9tIFwiQGltbWVkaWF0ZWx5LXJ1bi9zZGsvTURYUHJvdmlkZXJcIjtcbmZ1bmN0aW9uIF9jcmVhdGVNZHhDb250ZW50KHByb3BzKSB7XG4gIGNvbnN0IF9jb21wb25lbnRzID0ge1xuICAgIGE6IFwiYVwiLFxuICAgIGNvZGU6IFwiY29kZVwiLFxuICAgIGgxOiBcImgxXCIsXG4gICAgaDI6IFwiaDJcIixcbiAgICBsaTogXCJsaVwiLFxuICAgIG9sOiBcIm9sXCIsXG4gICAgcDogXCJwXCIsXG4gICAgcHJlOiBcInByZVwiLFxuICAgIHN0cm9uZzogXCJzdHJvbmdcIixcbiAgICB0YWJsZTogXCJ0YWJsZVwiLFxuICAgIHRib2R5OiBcInRib2R5XCIsXG4gICAgdGQ6IFwidGRcIixcbiAgICB0aDogXCJ0aFwiLFxuICAgIHRoZWFkOiBcInRoZWFkXCIsXG4gICAgdHI6IFwidHJcIixcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH0sIHtIZWFkaW5nQW5jaG9yfSA9IF9jb21wb25lbnRzO1xuICBpZiAoIUhlYWRpbmdBbmNob3IpIF9taXNzaW5nTWR4UmVmZXJlbmNlKFwiSGVhZGluZ0FuY2hvclwiLCB0cnVlKTtcbiAgcmV0dXJuIDw+PF9jb21wb25lbnRzLmgxIGlkPVwiY2FsZGVyYS1jb21wb25lbnRzLWxiby1jYXNlLXN0dWR5XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJjYWxkZXJhLWNvbXBvbmVudHMtbGJvLWNhc2Utc3R1ZHlcIiAvPntcIkNhbGRlcmEgQ29tcG9uZW50cyDigJQgTEJPIGNhc2Ugc3R1ZHlcIn08L19jb21wb25lbnRzLmgxPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSBmaW5hbmNpYWwtZG9tYWluIHNpYmxpbmcgb2YgdGhlIE1lcmlkaWFuIHN0dWR5OiBhIGNvbXBsZXRlIGxldmVyYWdlZC1idXlvdXRcXG5tb2RlbCwgcG9ydGVkIGZyb20gYSByZWFsLXNoYXBlIEV4Y2VsIHdvcmtib29rIHRvIGEgUmVja29uZXIgZG9jdW1lbnQsIHdpdGhcXG5QeXRob24tdmVyaWZpZWQgdHJ1dGguIENvbW1pc3Npb25lZCB0byBmaW5kIHRoZSBnYXBzIGJldHdlZW4gd2hhdCBSZWNrb25lciBjYW5cXG5jdXJyZW50bHkgZG8gYW5kIHdoYXQgZmluYW5jZSBwZW9wbGUgdXNlIEV4Y2VsIGZvciDigJQgdGhlIGZ1bGwgZmluZGluZ3MgbGl2ZSBpblxcblwifTxfY29tcG9uZW50cy5hIGhyZWY9XCIuLi8uLi9MQk9fQ0FTRV9TVFVEWV9HQVBfQU5BTFlTSVMubWRcIj48X2NvbXBvbmVudHMuY29kZT57XCIuLi8uLi9MQk9fQ0FTRV9TVFVEWV9HQVBfQU5BTFlTSVMubWRcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5hPntcIi5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUYXJnZXQ6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIENhbGRlcmEgQ29tcG9uZW50cyBMdGQgKGZpY3Rpb25hbCBtaWQtbWFya2V0IGluZHVzdHJpYWwgY29tcG9uZW50c1xcbm1ha2VyKS4gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJTcG9uc29yOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBIYXJyb3cgQ2FwaXRhbCAoZmljdGlvbmFsKS4gQ2xvc2UgMjAyNi0xMi0zMSwgZml2ZS15ZWFyIGhvbGRcXG4oRlkyMDI34oCTRlkyMDMxKS4gU3RydWN0dXJhbGx5IHRoZSBjYW5vbmljYWwgcHVibGljIExCTyB0ZW1wbGF0ZSAoTWFjYWJhY3VzLFxcblxcXCJMQk8gbW9kZWwg4oCUIHNob3J0IGZvcm1cXFwiOiBhc3N1bXB0aW9ucyDihpIgc291cmNlcyAmIHVzZXMg4oaSIG9wZXJhdGluZyBtb2RlbCDihpIgZGVidFxcbnNjaGVkdWxlIOKGkiByZXR1cm5zIOKGkiBzZW5zaXRpdml0eTsgc2VlXFxuXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cImh0dHBzOi8vbWFjYWJhY3VzLmNvbS92YWx1YXRpb24vbGJvLW92ZXJ2aWV3XCI+e1wiaHR0cHM6Ly9tYWNhYmFjdXMuY29tL3ZhbHVhdGlvbi9sYm8tb3ZlcnZpZXdcIn08L19jb21wb25lbnRzLmE+e1wiKS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiRXZlcnl0aGluZyBpcyBjb21wdXRlZCBpbiBQeXRob24gKFwifTxfY29tcG9uZW50cy5jb2RlPntcImdlbmVyYXRlLnB5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgZGV0ZXJtaW5pc3RpYywgbm8gUk5HKSBzbyB0aGVcXG5udW1iZXJzIGFyZSByZWFsIGFuZCB2ZXJpZmllZDogc291cmNlcyBlcXVhbCB1c2VzIHRvIGZsb2F0IHByZWNpc2lvbiwgdGhlIGRlYnRcXG5yb2xsLWZvcndhcmQgY29uc2VydmVzLCB0aGUgY2lyY3VsYXIgYXZlcmFnZS1iYWxhbmNlIGludGVyZXN0IHZhcmlhbnQgaXNcXG5jb252ZXJnZWQgdG8gYSBmaXhlZCBwb2ludCwgYW5kIHRoZSAyNS1jZWxsIHNlbnNpdGl2aXR5IGdyaWQgaXMgMjUgZnVsbCBtb2RlbFxcbnJlLXJ1bnMuIFRoZSBSZWNrb25lciBwb3J0IG1hdGNoZXMgdGhpcyB0cnV0aCB0byAxZS02IG9uIGV2ZXJ5IHNjaGVkdWxlIHJvdyBhbmRcXG50byAxZS0xMCBvbiBJUlIgKHByb3ZlbiBieSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvZG9jdW1lbnQvY2FsZGVyYUNhc2VTdHVkeS50ZXN0LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cImZpbGVzXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJmaWxlc1wiIC8+e1wiRmlsZXNcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy50YWJsZT48X2NvbXBvbmVudHMudGhlYWQ+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50aD57XCJGaWxlXCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGg+e1wiV2hhdCBpdCBpc1wifTwvX2NvbXBvbmVudHMudGg+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50Ym9keT48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcImdlbmVyYXRlLnB5XCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcInRydXRoIGdlbmVyYXRvcjogbW9kZWwgaW4gUHl0aG9uLCB3cml0ZXMgZXZlcnl0aGluZyBiZWxvd1wifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcInhsc3hfd3JpdGVyLnB5XCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcImRlcGVuZGVuY3ktZnJlZSAueGxzeCB3cml0ZXIgKGxpdmUgZm9ybXVsYXMsIG5hbWVkIHJhbmdlcywgaXRlcmF0aXZlIGNhbGMpXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiY2FsZGVyYV9sYm8ueGxzeFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJ0aGUgRXhjZWwgXFxcImJlZm9yZVxcXCI6IDggc2hlZXRzLCA5NjMgY2VsbHMsIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiNjIyIGxpdmUgZm9ybXVsYXNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIGluY2wuIE1JTi9NQVggcmV2b2x2ZXIgbG9naWMsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIklSUigpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgYSBkZWxpYmVyYXRlbHkgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJjaXJjdWxhciBhdmVyYWdlLWJhbGFuY2Ugc2hlZXRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIsIGEgaGFuZC1yb2xsZWQgdHdvLXdheSBzZW5zaXRpdml0eSBlbmdpbmUsIGFuZCBhbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJJRiguLi4sXFxcIk9LXFxcIixcXFwiQlJFQUtcXFwiKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgY2hlY2tzIHNoZWV0XCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiZXhwZWN0ZWQuanNvblwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJmdWxsLWRldGFpbCB0cnV0aCAodGhlIHZpdGVzdCBoYXJuZXNzIGFzc2VydHMgYWdhaW5zdCB0aGlzKVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcImRhdGEvKi5jc3ZcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiaHVtYW4tcmVhZGFibGUgaW5wdXRzOiBoaXN0b3JpY2FscywgbWFuYWdlbWVudCBwbGFuLCBhc3N1bXB0aW9uc1wifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcImRvY3VtZW50L1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJ0aGUgUmVja29uZXIgXFxcImFmdGVyXFxcIiDigJQgYSByZWFsIGxvYWRhYmxlIGRvY3VtZW50OiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyZWNrb25lci5qc29uXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgMiB3b3Jrc2hlZXRzICgxMyBtb2RlbCBjZWxscyArIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiMjIgdGVzdCBjZWxsc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiksIDUgZml4dHVyZXMsIDEgdGVtcGxhdGVcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJkb2N1bWVudC93b3Jrc2hlZXRzL21vZGVsLnNoZWV0LmpzXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcInRoZSBtb2RlbCBhcyBwdXJlIGZ1bmN0aW9uczogb3BlcmF0aW5nIGJ1aWxkIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJqb2luXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJzY2FuXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJncm91cEJ5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJsYWdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSwgc291cmNlcyAmIHVzZXMsIGRlYnQgc2NoZWR1bGUgKG11bHRpLXN0YXRlIHBhY2tlZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzY2FuXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiksIHRoZSBjaXJjdWxhciB2YXJpYW50IGFzIGFuIGV4cGxpY2l0IGNvbnZlcmdlZCBmaXhlZCBwb2ludCwgYmlzZWN0aW9uIElSUiwgMjUtcnVuIHNlbnNpdGl2aXR5IGdyaWQsIGdvYWwtc2VlayBicmVha2V2ZW5cIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJkb2N1bWVudC93b3Jrc2hlZXRzL2NoZWNrcy5zaGVldC5qc1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJ0aGUgRXhjZWwgY2hlY2tzIHNoZWV0LCB1cGdyYWRlZDogc3BlY2lmaWNhdGlvbiAob3JhY2xlKSwgY29uc2VydmF0aW9uLCBwZXJtdXRhdGlvbi1pbnZhcmlhbmNlLCBhbmQgcHJvcGVydHkgdGVzdHMgKGNvdmVuYW50cywgbW9ub3RvbmljaXR5LCBjb252ZXJnZW5jZSkgd2l0aCBtYW5kYXRvcnkga2luZHNcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50Ym9keT48L19jb21wb25lbnRzLnRhYmxlPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInRoZS1kZWFsLWJhc2UtY2FzZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwidGhlLWRlYWwtYmFzZS1jYXNlXCIgLz57XCJUaGUgZGVhbCAoYmFzZSBjYXNlKVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiTFRNIEVCSVREQSA0Ni4yNyDihpIgZW50cnkgOC4weCA9IEVWIDM3MC4xNi4gRnVuZGluZzogNS4weCBUTEIgKDguMCUsIDElXFxubWFuZGF0b3J5IGFtb3J0LCA3NSUgY2FzaCBzd2VlcCkgKyAxLjB4IG1lenphbmluZSAoMTIlIGNhc2ggLyAyJSBQSUspICsgMi4wXFxuYmFsYW5jZS1zaGVldCBjYXNoICsgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJzcG9uc29yIGVxdWl0eSAxMTQuODhcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHRoZSBwbHVnOyBzb3VyY2VzID0gdXNlcyB0b1xcbjUuN2UtMTQpLiBFeGl0IEZZMjAzMSBhdCA4LjB4IEVCSVREQSA2NC42MSDihpIgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJleGl0IGVxdWl0eSAzMTUuNDYsIE1PSUNcXG4yLjc1eCwgSVJSIDIyLjM5JVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoYXZlcmFnZS1iYWxhbmNlIGludGVyZXN0IHZhcmlhbnQ6IDIyLjUyJSkuIEJyZWFrZXZlbiBleGl0XFxubXVsdGlwbGUgZm9yIHRoZSAyMCUgaHVyZGxlOiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIjcuNTR4XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLiBDb3ZlbmFudHMgaG9sZCBhbGwgeWVhcnMgKHdvcnN0XFxubGV2ZXJhZ2UgNS4zMXggdnMgNi4weCBtYXg7IHdvcnN0IGNvdmVyYWdlIDIuMDZ4IHZzIDIuMHggbWluKS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwicGxhbnRlZC1wcm9iZXMtd2hhdC10aGUtcG9ydC1oYWQtdG8tc3Vydml2ZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwicGxhbnRlZC1wcm9iZXMtd2hhdC10aGUtcG9ydC1oYWQtdG8tc3Vydml2ZVwiIC8+e1wiUGxhbnRlZCBwcm9iZXMgKHdoYXQgdGhlIHBvcnQgaGFkIHRvIHN1cnZpdmUpXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMub2w+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQ2lyY3VsYXJpdHlcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIGF2ZXJhZ2UtYmFsYW5jZSBpbnRlcmVzdCAoRXhjZWwncyBpdGVyYXRpdmUtY2FsYyBzaGVldClcXG52cyBSZWNrb25lcidzIHJlamVjdGVkIGN5Y2xlczogcG9ydGVkIGFzIGFuIGV4cGxpY2l0IHBlci15ZWFyIGZpeGVkIHBvaW50XFxuaW5zaWRlIG9uZSBjZWxsLCBjb252ZXJnZWQgdG8gMWUtMTIsIHdpdGggYSBwcm9wZXJ0eSB0ZXN0IHByb3ZpbmdcXG5jb252ZXJnZW5jZS4gVGhlIGdhcCByZXBvcnQncyBoZWFkbGluZSBmaW5kaW5nLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiR29hbCBzZWVrXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBicmVha2V2ZW4gZXhpdCBtdWx0aXBsZTogYmlzZWN0aW9uIG92ZXIgdGhlIG1vZGVsLWFzLWEtZnVuY3Rpb24uXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUd28td2F5IHNlbnNpdGl2aXR5XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBFeGNlbCBkYXRhIHRhYmxlIC8gaGlkZGVuIGVuZ2luZSBzaGVldCB2c1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcInJ1bk1vZGVsKClcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG1hcHBlZCBvdmVyIDI1IHBhcmFtZXRlciBwYWlycyAoZm9yY2VzIG1vZGVsLWFzLWZ1bmN0aW9uXFxuZGVjb21wb3NpdGlvbikuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJNdWx0aS1zdGF0ZSByb2xsLWZvcndhcmRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHRoZSBkZWJ0IHNjaGVkdWxlIGlzIFRIRSBjYW5vbmljYWwgZmluYW5jaWFsXFxuc3RydWN0dXJlOyB0aGUgc3RkbGliIGhhcyBubyByb2xsZm9yd2FyZCBwcmltaXRpdmUgKGN1bXN1bSBpcyBzaW5nbGUtc3RhdGUpLFxcbnNvIHRoZSBwb3J0IHVzZXMgYSBjdXN0b20gcGFja2VkIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNjYW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG9wLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUmF0ZS1iZWFyaW5nIGlucHV0c1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic2NhbGVJbnZhcmlhbmNlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBzY2FsZXMgZXZlcnkgbnVtZXJpYyBsZWFmXFxuKGluY2x1ZGluZyBtYXJnaW5zL2dyb3d0aCksIG1ha2luZyBpdCB1bnVzYWJsZSBvbiBmaW5hbmNpYWwgaW5wdXRzO1xcbnBlcm11dGF0aW9uIGludmFyaWFuY2UgKyBwcm9wZXJ0eSB0ZXN0cyBjYXJyeSB0aGUgbWV0YW1vcnBoaWMgbGVnIGluc3RlYWQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgb3JhY2xlIGdhcFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgdGVzdC1kZWNsYXJlZCBmaXh0dXJlIGlucHV0cyBuZXZlciByZWFjaCB0aGUgdGVzdFxcbmNvbnRleHQgKHRlc3QtcnVubmVyIHdpcmluZyksIHNvIHRoZSBQeXRob24gb3JhY2xlIGlzIGlubGluZWQgYXMgY29uc3RhbnRzLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJydW5uaW5nXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJydW5uaW5nXCIgLz57XCJSdW5uaW5nXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucHJlPjxfY29tcG9uZW50cy5jb2RlIGNsYXNzTmFtZT1cImxhbmd1YWdlLWJhc2hcIj57XCJweXRob24zIGdlbmVyYXRlLnB5ICAgICAgICAgICAgICAgICAgICAgICAjIHJlZ2VuZXJhdGUgdHJ1dGggKyB4bHN4IChkZXRlcm1pbmlzdGljKVxcbmNkIC4uLy4uLy4uICYmIG5weCB2aXRlc3QgcnVuIHNyYy9kb2N1bWVudC9jYWxkZXJhQ2FzZVN0dWR5LnRlc3QudHNcXG5cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5wcmU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIHZpdGVzdCBoYXJuZXNzIGxvYWRzIFwifTxfY29tcG9uZW50cy5jb2RlPntcImRvY3VtZW50L1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdGhyb3VnaCB0aGUgcmVhbCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJsb2FkRG9jdW1lbnRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGxvYWRlcixcXG5ydW5zIGl0IGluIHRoZSByZWFsIFNFUy1jb21wYXJ0bWVudCBlbmdpbmUsIGFzc2VydHMgZXZlcnkgc2NoZWR1bGUgeWVhciwgdGhlXFxucmV0dXJucywgdGhlIDI1IGdyaWQgY2VsbHMsIGFuZCB0aGUgMjIgd29ya2Jvb2sgdGVzdHMgYWdhaW5zdCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJleHBlY3RlZC5qc29uXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIixcXG5hbmQgYXNzZXJ0cyB0aGUgbG9hZC1iZWFyaW5nIGNlbGxzIGVhcm4gYSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ2YWxpZGF0ZWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHZlcmRpY3QgKGEgbWV0YW1vcnBoaWMgb3JcXG5wcm9wZXJ0eSBsZWcg4oCUIG5vdCBtZXJlbHkgcGlubmVkIHRvIGV4YW1wbGVzKS5cIn08L19jb21wb25lbnRzLnA+PC8+O1xufVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTURYQ29udGVudChwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHt3cmFwcGVyOiBNRFhMYXlvdXR9ID0ge1xuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfTtcbiAgcmV0dXJuIE1EWExheW91dCA/IDxNRFhMYXlvdXQgey4uLnByb3BzfT48X2NyZWF0ZU1keENvbnRlbnQgey4uLnByb3BzfSAvPjwvTURYTGF5b3V0PiA6IF9jcmVhdGVNZHhDb250ZW50KHByb3BzKTtcbn1cbmZ1bmN0aW9uIF9taXNzaW5nTWR4UmVmZXJlbmNlKGlkLCBjb21wb25lbnQsIHBsYWNlKSB7XG4gIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIFwiICsgKGNvbXBvbmVudCA/IFwiY29tcG9uZW50XCIgOiBcIm9iamVjdFwiKSArIFwiIGBcIiArIGlkICsgXCJgIHRvIGJlIGRlZmluZWQ6IHlvdSBsaWtlbHkgZm9yZ290IHRvIGltcG9ydCwgcGFzcywgb3IgcHJvdmlkZSBpdC5cIiArIChwbGFjZSA/IFwiXFxuSXTigJlzIHJlZmVyZW5jZWQgaW4geW91ciBjb2RlIGF0IGBcIiArIHBsYWNlICsgXCJgIGluIGAvYXBwL2RvY3MvY2FzZS1zdHVkeS9jYWxkZXJhL1JFQURNRS5tZGBcIiA6IFwiXCIpKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQXdGLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUZ4RjtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU1DLFdBQVcsR0FBRztNQUNsQkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsSUFBSSxFQUFFLE1BQU07TUFDWkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsR0FBRyxFQUFFLEtBQUs7TUFDVkMsTUFBTSxFQUFFLFFBQVE7TUFDaEJDLEtBQUssRUFBRSxPQUFPO01BQ2RDLEtBQUssRUFBRSxPQUFPO01BQ2RDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEtBQUssRUFBRSxPQUFPO01BQ2RDLEVBQUUsRUFBRSxJQUFJO01BQ1IsR0FBRyxJQUFBQyw2QkFBa0IsRUFBQyxDQUFDO01BQ3ZCLEdBQUdqQixLQUFLLENBQUNrQjtJQUNYLENBQUM7SUFBRTtNQUFDQztJQUFhLENBQUMsR0FBR2xCLFdBQVc7RUFDaEMsSUFBSSxDQUFDa0IsYUFBYSxFQUFFQyxvQkFBb0IsQ0FBQyxlQUFlLEVBQUUsSUFBSSxDQUFDO0VBQy9ELG9CQUFPLElBQUF0QixXQUFBLENBQUF1QixJQUFBLEVBQUF2QixXQUFBLENBQUF3QixRQUFBO0lBQUFDLFFBQUEsZ0JBQUUsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0csRUFBRTtNQUFDb0IsRUFBRSxFQUFDLG1DQUFtQztNQUFBRCxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQW1DLENBQUUsQ0FBQyxFQUFDLHFDQUFxQztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ08sQ0FBQztNQUFBZSxRQUFBLEdBQUUsZ1VBQWdVLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsQ0FBQztRQUFDd0IsSUFBSSxFQUFDLHNDQUFzQztRQUFBSCxRQUFBLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBb0IsUUFBQSxFQUFFO1FBQXNDLENBQW1CO01BQUMsQ0FBZSxDQUFDLEVBQUMsR0FBRztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ08sQ0FBQztNQUFBZSxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNTLE1BQU07UUFBQWEsUUFBQSxFQUFFO01BQVMsQ0FBcUIsQ0FBQyxFQUFDLCtFQUErRSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNTLE1BQU07UUFBQWEsUUFBQSxFQUFFO01BQVUsQ0FBcUIsQ0FBQyxFQUFDLHdRQUF3USxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNDLENBQUM7UUFBQ3dCLElBQUksRUFBQyw4Q0FBOEM7UUFBQUgsUUFBQSxFQUFFO01BQThDLENBQWdCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDTyxDQUFDO01BQUFlLFFBQUEsR0FBRSxvQ0FBb0MsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFvQixRQUFBLEVBQUU7TUFBYSxDQUFtQixDQUFDLEVBQUMsd1hBQXdYLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBb0IsUUFBQSxFQUFFO01BQXVDLENBQW1CLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDSSxFQUFFO01BQUNtQixFQUFFLEVBQUMsT0FBTztNQUFBRCxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMsT0FBTztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1UsS0FBSztNQUFBWSxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNjLEtBQUs7UUFBQVEsUUFBQSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNlLEVBQUU7VUFBQU8sUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDYSxFQUFFO1lBQUFTLFFBQUEsRUFBRTtVQUFNLENBQWlCLENBQUMsbUJBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNhLEVBQUU7WUFBQVMsUUFBQSxFQUFFO1VBQVksQ0FBaUIsQ0FBQztRQUFBLENBQWdCO01BQUMsQ0FBbUIsQ0FBQyxtQkFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ1csS0FBSztRQUFBVyxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNlLEVBQUU7VUFBQU8sUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDWSxFQUFFO1lBQUFVLFFBQUEsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRSxJQUFJO2NBQUFvQixRQUFBLEVBQUU7WUFBYSxDQUFtQjtVQUFDLENBQWdCLENBQUMsbUJBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNZLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQTJELENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDZSxFQUFFO1VBQUFPLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVSxRQUFBLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBb0IsUUFBQSxFQUFFO1lBQWdCLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBNEUsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNlLEVBQUU7VUFBQU8sUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDWSxFQUFFO1lBQUFVLFFBQUEsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRSxJQUFJO2NBQUFvQixRQUFBLEVBQUU7WUFBa0IsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDWSxFQUFFO1lBQUFVLFFBQUEsR0FBRSw2Q0FBNkMsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDUyxNQUFNO2NBQUFhLFFBQUEsRUFBRTtZQUFtQixDQUFxQixDQUFDLEVBQUMsbUNBQW1DLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBb0IsUUFBQSxFQUFFO1lBQU8sQ0FBbUIsQ0FBQyxFQUFDLG1CQUFtQixlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNTLE1BQU07Y0FBQWEsUUFBQSxFQUFFO1lBQWdDLENBQXFCLENBQUMsRUFBQyxxREFBcUQsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRSxJQUFJO2NBQUFvQixRQUFBLEVBQUU7WUFBMEIsQ0FBbUIsQ0FBQyxFQUFDLGVBQWU7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ2UsRUFBRTtVQUFBTyxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNZLEVBQUU7WUFBQVUsUUFBQSxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNFLElBQUk7Y0FBQW9CLFFBQUEsRUFBRTtZQUFlLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBNkQsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNlLEVBQUU7VUFBQU8sUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDWSxFQUFFO1lBQUFVLFFBQUEsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRSxJQUFJO2NBQUFvQixRQUFBLEVBQUU7WUFBWSxDQUFtQjtVQUFDLENBQWdCLENBQUMsbUJBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNZLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQWtFLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDZSxFQUFFO1VBQUFPLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVSxRQUFBLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBb0IsUUFBQSxFQUFFO1lBQVcsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDWSxFQUFFO1lBQUFVLFFBQUEsR0FBRSxxREFBcUQsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRSxJQUFJO2NBQUFvQixRQUFBLEVBQUU7WUFBZSxDQUFtQixDQUFDLEVBQUMsbUNBQW1DLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1MsTUFBTTtjQUFBYSxRQUFBLEVBQUU7WUFBZSxDQUFxQixDQUFDLEVBQUMsMkJBQTJCO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNlLEVBQUU7VUFBQU8sUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDWSxFQUFFO1lBQUFVLFFBQUEsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRSxJQUFJO2NBQUFvQixRQUFBLEVBQUU7WUFBb0MsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDWSxFQUFFO1lBQUFVLFFBQUEsR0FBRSxnREFBZ0QsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRSxJQUFJO2NBQUFvQixRQUFBLEVBQUU7WUFBTSxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNFLElBQUk7Y0FBQW9CLFFBQUEsRUFBRTtZQUFNLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBb0IsUUFBQSxFQUFFO1lBQVMsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRSxJQUFJO2NBQUFvQixRQUFBLEVBQUU7WUFBSyxDQUFtQixDQUFDLEVBQUMsdURBQXVELGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBb0IsUUFBQSxFQUFFO1lBQU0sQ0FBbUIsQ0FBQyxFQUFDLDJIQUEySDtVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDZSxFQUFFO1VBQUFPLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVSxRQUFBLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBb0IsUUFBQSxFQUFFO1lBQXFDLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1ksRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBZ0wsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUM7TUFBQSxDQUFtQixDQUFDO0lBQUEsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDSSxFQUFFO01BQUNtQixFQUFFLEVBQUMsb0JBQW9CO01BQUFELFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBb0IsQ0FBRSxDQUFDLEVBQUMsc0JBQXNCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBMUIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDTyxDQUFDO01BQUFlLFFBQUEsR0FBRSw0S0FBNEssZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDUyxNQUFNO1FBQUFhLFFBQUEsRUFBRTtNQUF1QixDQUFxQixDQUFDLEVBQUMsOEVBQThFLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1MsTUFBTTtRQUFBYSxRQUFBLEVBQUU7TUFBNkMsQ0FBcUIsQ0FBQyxFQUFDLDRGQUE0RixlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNTLE1BQU07UUFBQWEsUUFBQSxFQUFFO01BQU8sQ0FBcUIsQ0FBQyxFQUFDLG1HQUFtRztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0ksRUFBRTtNQUFDbUIsRUFBRSxFQUFDLDZDQUE2QztNQUFBRCxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQTZDLENBQUUsQ0FBQyxFQUFDLCtDQUErQztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ00sRUFBRTtNQUFBZ0IsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDSyxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNTLE1BQU07VUFBQWEsUUFBQSxFQUFFO1FBQWEsQ0FBcUIsQ0FBQyxFQUFDLDJQQUEyUDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQXVCLElBQUEsRUFBQ3BCLFdBQVcsQ0FBQ0ssRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDUyxNQUFNO1VBQUFhLFFBQUEsRUFBRTtRQUFXLENBQXFCLENBQUMsRUFBQyxxRUFBcUU7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNLLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBYSxRQUFBLEVBQUU7UUFBcUIsQ0FBcUIsQ0FBQyxFQUFDLGdEQUFnRCxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNFLElBQUk7VUFBQW9CLFFBQUEsRUFBRTtRQUFZLENBQW1CLENBQUMsRUFBQyw0RUFBNEU7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNLLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBYSxRQUFBLEVBQUU7UUFBMEIsQ0FBcUIsQ0FBQyxFQUFDLGtLQUFrSyxlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNFLElBQUk7VUFBQW9CLFFBQUEsRUFBRTtRQUFNLENBQW1CLENBQUMsRUFBQyxNQUFNO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDSyxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNTLE1BQU07VUFBQWEsUUFBQSxFQUFFO1FBQXFCLENBQXFCLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBb0IsUUFBQSxFQUFFO1FBQWlCLENBQW1CLENBQUMsRUFBQyw2S0FBNks7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUF6QixXQUFBLENBQUF1QixJQUFBLEVBQUNwQixXQUFXLENBQUNLLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1MsTUFBTTtVQUFBYSxRQUFBLEVBQUU7UUFBZ0IsQ0FBcUIsQ0FBQyxFQUFDLG1JQUFtSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDSSxFQUFFO01BQUNtQixFQUFFLEVBQUMsU0FBUztNQUFBRCxRQUFBLGdCQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVMsQ0FBRSxDQUFDLEVBQUMsU0FBUztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTFCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsR0FBRztNQUFBYyxRQUFBLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFDd0IsU0FBUyxFQUFDLGVBQWU7UUFBQUosUUFBQSxFQUFFO01BQTRKLENBQW1CO0lBQUMsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBekIsV0FBQSxDQUFBdUIsSUFBQSxFQUFDcEIsV0FBVyxDQUFDTyxDQUFDO01BQUFlLFFBQUEsR0FBRSwyQkFBMkIsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFvQixRQUFBLEVBQUU7TUFBVyxDQUFtQixDQUFDLEVBQUMsb0JBQW9CLGVBQUMsSUFBQXpCLFdBQUEsQ0FBQTJCLEdBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBb0IsUUFBQSxFQUFFO01BQWMsQ0FBbUIsQ0FBQyxFQUFDLHdKQUF3SixlQUFDLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUN4QixXQUFXLENBQUNFLElBQUk7UUFBQW9CLFFBQUEsRUFBRTtNQUFlLENBQW1CLENBQUMsRUFBQywrQ0FBK0MsZUFBQyxJQUFBekIsV0FBQSxDQUFBMkIsR0FBQSxFQUFDeEIsV0FBVyxDQUFDRSxJQUFJO1FBQUFvQixRQUFBLEVBQUU7TUFBVyxDQUFtQixDQUFDLEVBQUMsNEVBQTRFO0lBQUEsQ0FBZ0IsQ0FBQztFQUFBLENBQUUsQ0FBQztBQUNya1I7QUFDZSxTQUFTSyxVQUFVQSxDQUFDNUIsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFO0VBQzdDLE1BQU07SUFBQzZCLE9BQU8sRUFBRUM7RUFBUyxDQUFDLEdBQUc7SUFDM0IsR0FBRyxJQUFBYiw2QkFBa0IsRUFBQyxDQUFDO0lBQ3ZCLEdBQUdqQixLQUFLLENBQUNrQjtFQUNYLENBQUM7RUFDRCxPQUFPWSxTQUFTLGdCQUFHLElBQUFoQyxXQUFBLENBQUEyQixHQUFBLEVBQUNLLFNBQVM7SUFBQSxHQUFLOUIsS0FBSztJQUFBdUIsUUFBQSxlQUFFLElBQUF6QixXQUFBLENBQUEyQixHQUFBLEVBQUMxQixpQkFBaUI7TUFBQSxHQUFLQztJQUFLLENBQUc7RUFBQyxDQUFXLENBQUMsR0FBR0QsaUJBQWlCLENBQUNDLEtBQUssQ0FBQztBQUNsSDtBQUFDK0IsRUFBQSxHQU51QkgsVUFBVTtBQU9sQyxTQUFTUixvQkFBb0JBLENBQUNJLEVBQUUsRUFBRVEsU0FBUyxFQUFFQyxLQUFLLEVBQUU7RUFDbEQsTUFBTSxJQUFJQyxLQUFLLENBQUMsV0FBVyxJQUFJRixTQUFTLEdBQUcsV0FBVyxHQUFHLFFBQVEsQ0FBQyxHQUFHLElBQUksR0FBR1IsRUFBRSxHQUFHLG9FQUFvRSxJQUFJUyxLQUFLLEdBQUcscUNBQXFDLEdBQUdBLEtBQUssR0FBRywrQ0FBK0MsR0FBRyxFQUFFLENBQUMsQ0FBQztBQUN6UTtBQUFDLElBQUFGLEVBQUE7QUFBQUksWUFBQSxDQUFBSixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}