var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      blockquote: "blockquote",
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      li: "li",
      ol: "ol",
      p: "p",
      strong: "strong",
      table: "table",
      tbody: "tbody",
      td: "td",
      th: "th",
      thead: "thead",
      tr: "tr",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "status-connector-egress-fixing-d2",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "status-connector-egress-fixing-d2"
      }), "Status — Connector egress-fixing (D2)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["Overall: PARTIALLY BUILT — the target-fixing core, the request-body cap and the pinned\nsecret path are implemented and gated; the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "feed:fetch"
        }), " protocol wiring and the consent\nsurface's rendering are the remainder."]
      }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(2026-08-27: the protocol wiring and the SDK surface have\nsince landed — site-main #376, sdk 0.54.0. One new residual: the §3.1 path enforces no\ncredential-kind eligibility — roadmap R3-394, in Residuals below.)"
      }), " · ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Created:"
      }), " 2026-08-27 (roadmap R3-227)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: ["This document is the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "single implementation-status source"
        }), " for\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
          href: "../specs/CONNECTOR_EGRESS_FIXING_SPEC.md",
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "specs/CONNECTOR_EGRESS_FIXING_SPEC.md"
          })
        }), ".\nWhere the spec and this file disagree, this file governs."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "2026-09-25 (roadmap R3-768)."
        }), " Reckoner's report-view egress was removed: the app no\nlonger requests ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "net:fetch"
        }), ", the report view holds no network, and the bundled usage\nworkbook (R3-349) that hardcoded the analytics origin is moved to its own\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "immediately-run/usage-workbook"
        }), " repo with declared ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "feeds/*.feed.json"
        }), " files. The\nconnector realm that reconnects those feeds as template-bound ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "feed:fetch"
        }), " is R3-769."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "what-done-means-here-and-what-it-does-not",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "what-done-means-here-and-what-it-does-not"
      }), "What \"done\" means here, and what it does not"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The spec is emphatic on this and so is this file: egress-fixing ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "bounds a compromised\nconnector; it does not make one zero-exfil, and it does nothing against a hostile\nauthor."
      }), " The honest claim after this work is the spec's own §4 wording —"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
        children: "consented reach; write-to-fixed-host at declared-slot-entropy per request, completing\nwithin minutes; frequency-tripwired only."
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Nothing below upgrades that to \"safe\", and a future reader should treat any summary that\ndoes as a regression in the description, not an improvement in the mechanism."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "built",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "built"
      }), "Built"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "§"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Mechanism"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Where"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Gate"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "§2"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Trusted feed config compiles to a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "frozen"
            }), " request template; no URL surface"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "immediately-run-site-main/src/registry/feedTemplate.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "feedTemplate.test.ts"
            }), " — §5 moves 1, 4, 5, 8"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "§2 rule 2"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Typed data-plane slots (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "iso8601"
            }), " / bounded ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "int"
            }), " / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "enum"
            }), "); a slot may not carry a host, path or new query key"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "same"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "param-confinement cases"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "§2 rule 2"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Host-minted cursors"
            }), ", opaque to the connector; extraction by a config-declared rule"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "feedTemplate.ts"
            }), " + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "registry/feedInstance.ts"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "feedFetchHandler.test.ts"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "§2 rule 3"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Request body fully templated ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "and byte-capped"
            }), ", host-side and server-side"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "feedTemplate.ts"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "immediately-run-backend/src/netFetch.ts"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "netFetch.test.ts"
            }), " (incl. the UTF-8-vs-UTF-16 case)"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "§2 rule 4"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Template ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "deep-frozen"
            }), " at compile time"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "feedTemplate.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "frozen-template case"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "§2 rule 5"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Host-minted instance id"
            }), "; budget keyed on it; teardown revokes"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "feedInstance.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "budget + teardown cases"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "§2.1"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Write-sink vs read-source consent descriptor: names it outbound, lists the cells sent, states the volume"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "registry/writeSink.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "writeSink.test.ts"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "§3.1"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Pinned secret path"
            }), " — server-side header injection, caller cannot overwrite it, name stripped from the response, and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "no browser-direct fallback on any failure"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "editor/feedFetchHandler.ts"
            }), ", backend ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "netFetch.ts"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "feedFetchHandler.test.ts"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "netFetch.test.ts"
            })]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "§2 rule 1"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "feed:fetch"
            }), " exists as a capability distinct from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "net:fetch"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "@immediately-run/preauth-core"
            }), " 0.1.12 (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "registry 1.7.0"
            }), ")"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "test/capabilities.test.ts"
            })
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "not-built-the-remainder-in-the-order-it-should-land",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "not-built-the-remainder-in-the-order-it-should-land"
      }), "Not built — the remainder, in the order it should land"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["The ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "protocol-feed"
          }), " gate row and dispatch"]
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "site-main"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "registry/actionGate.ts"
        }), ",\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "editor/requestDispatcher.ts"
        }), "). Blocked on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "@immediately-run/preauth-core"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "0.1.12"
        }), "\nbeing published: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "MethodDef.capability"
        }), " is typed ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Capability"
        }), ", and the vocabulary is\nthe one source of truth for that union (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ways_of_working"
        }), " §6 — a shared vocabulary is\npublished once and consumed, never copied). Site-main deliberately did ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "not"
        }), " bump its\npin ahead of the publish, because a pin to an unpublished version turns every check in\nthe repo red on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npm ci"
        }), " and the informative one never runs."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The SDK client surface"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "@immediately-run/sdk"
        }), ") — a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "feedFetch(instanceId, params)"
        }), "\nwrapper. Until it exists no app can reach the handler, which is the intended order:\nenforcement ships before the authority it constrains (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ways_of_working"
        }), " §1)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Rendering"
        }), " the §2.1 write-sink consent descriptor in the powerbox. The descriptor is\ncomputed and tested; drawing it is D6 (roadmap R3-229), whose composite consent plan\nalready carries one step per feed with the descriptor attached."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Per-hop redirect behaviour for an injected request."
        }), " The server re-resolves and\nre-validates every hop (built, T40), and the injected header rides the request across\nhops that passed those checks. Whether an injected credential should be dropped on a\ncross-origin hop even when that hop is allowlisted is not settled here; today the\nallowlist is a single origin per feed template, so the case is unreachable through\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "feed:fetch"
        }), " — recorded because it becomes reachable the moment a template names more\nthan one origin."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "residuals-named-not-closed",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "residuals-named-not-closed"
      }), "Residuals — named, not closed"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Declared-slot entropy (§4)."
        }), " An ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "iso8601"
        }), " slot carries ~30–50 bits per request, so a\n256-bit secret drains in single-digit on-cadence requests. The budget bounds\nrequests-per-window, not bits-per-request, and therefore never fires on this. The code\nsays so at the definition of ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "consume"
        }), ", not only here."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Body reflection (§5 move 6)."
        }), " A malicious allowlisted host can echo the injected\ncredential in its response ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "body"
        }), ", which the connector reads as data. Server-side\ninjection removes the header from the connector's frame; it cannot remove the value\nfrom bytes the upstream chooses to send."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The hostile author (§2.1 / §5 move 9)."
        }), " Target-fixing pins faithfully to whatever\norigin the config names. Consent legibility is the only defense, and it is\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "unvalidated"
        }), " — the E3 comprehension study has not run and must now include an\noutbound-feed arm. A ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "POST"
        }), "-with-cell-body feed is a named residual, not a contained\nthreat."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Credential-kind eligibility on the §3.1 path is unenforced (roadmap R3-394, found\n2026-08-27)."
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "SECRETS_SPEC §2.1"
        }), " C2 enumerates the backend-proxied carve-out ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "by resource\nkind"
        }), " and says widening it \"is a spec edit somebody has to write, not a judgement call at a call\nsite\". §3.1 widened it to a second consumer, the edit was not written, and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "no layer checks the\nkind"
        }), ": ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "feedTemplate.ts"
        }), " types the selector ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "{ family?: string; type?: string }"
        }), " (a free-form\nstring, not ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "SecretType"
        }), ") and copies it through unvalidated — while validating data-plane slot\ntypes strictly in the same compiler — and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "resolveSecret"
        }), " → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "feedFetchHandler"
        }), " inject whatever\nmatches. The path that actually fires is an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "omitted"
        }), " type: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "matchesSelector"
        }), " treats a missing\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "type"
        }), " as ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "match every kind"
        }), ", so ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "injectSecret: { family: \"acme\" }"
        }), " can select an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "oauth-refresh"
        }), "\nrecord — which C2 excludes ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "unconditionally"
        }), " — and route it to the server. Bounded by the\nrecord existing, matching, and being ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "boundOrigin"
        }), "-bound to that feed's origin under a grant this\napp holds. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "This qualifies the §3.1 row above rather than retracting it:"
        }), " the mechanism is\nbuilt and sound; the gate on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "which credential may use it"
        }), " is missing. Note the scope — this is a\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "routing"
        }), " widening (C5 cell ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "T1"
        }), "), not a custody one; no feed credential is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "platform-held"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Availability cost of §3.1."
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "feed:fetch"
        }), " refuses when the pinned server path is\nunavailable rather than falling back. That is deliberate — the fallback path is the\nunpinned one — and it means a connector does not poll while the backend is down."]
      }), "\n"]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/status/CONNECTOR_EGRESS_FIXING_STATUS.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiYmxvY2txdW90ZSIsImNvZGUiLCJlbSIsImgxIiwiaDIiLCJsaSIsIm9sIiwicCIsInN0cm9uZyIsInRhYmxlIiwidGJvZHkiLCJ0ZCIsInRoIiwidGhlYWQiLCJ0ciIsInVsIiwiX3Byb3ZpZGVDb21wb25lbnRzIiwiY29tcG9uZW50cyIsIkhlYWRpbmdBbmNob3IiLCJfbWlzc2luZ01keFJlZmVyZW5jZSIsImpzeHMiLCJGcmFnbWVudCIsImNoaWxkcmVuIiwiaWQiLCJqc3giLCJocmVmIiwiTURYQ29udGVudCIsIndyYXBwZXIiLCJNRFhMYXlvdXQiLCJfYyIsImNvbXBvbmVudCIsInBsYWNlIiwiRXJyb3IiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJDT05ORUNUT1JfRUdSRVNTX0ZJWElOR19TVEFUVVMubWQiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgYTogXCJhXCIsXG4gICAgYmxvY2txdW90ZTogXCJibG9ja3F1b3RlXCIsXG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgZW06IFwiZW1cIixcbiAgICBoMTogXCJoMVwiLFxuICAgIGgyOiBcImgyXCIsXG4gICAgbGk6IFwibGlcIixcbiAgICBvbDogXCJvbFwiLFxuICAgIHA6IFwicFwiLFxuICAgIHN0cm9uZzogXCJzdHJvbmdcIixcbiAgICB0YWJsZTogXCJ0YWJsZVwiLFxuICAgIHRib2R5OiBcInRib2R5XCIsXG4gICAgdGQ6IFwidGRcIixcbiAgICB0aDogXCJ0aFwiLFxuICAgIHRoZWFkOiBcInRoZWFkXCIsXG4gICAgdHI6IFwidHJcIixcbiAgICB1bDogXCJ1bFwiLFxuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfSwge0hlYWRpbmdBbmNob3J9ID0gX2NvbXBvbmVudHM7XG4gIGlmICghSGVhZGluZ0FuY2hvcikgX21pc3NpbmdNZHhSZWZlcmVuY2UoXCJIZWFkaW5nQW5jaG9yXCIsIHRydWUpO1xuICByZXR1cm4gPD48X2NvbXBvbmVudHMuaDEgaWQ9XCJzdGF0dXMtY29ubmVjdG9yLWVncmVzcy1maXhpbmctZDJcIj48SGVhZGluZ0FuY2hvciBpZD1cInN0YXR1cy1jb25uZWN0b3ItZWdyZXNzLWZpeGluZy1kMlwiIC8+e1wiU3RhdHVzIOKAlCBDb25uZWN0b3IgZWdyZXNzLWZpeGluZyAoRDIpXCJ9PC9fY29tcG9uZW50cy5oMT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIk92ZXJhbGw6IFBBUlRJQUxMWSBCVUlMVCDigJQgdGhlIHRhcmdldC1maXhpbmcgY29yZSwgdGhlIHJlcXVlc3QtYm9keSBjYXAgYW5kIHRoZSBwaW5uZWRcXG5zZWNyZXQgcGF0aCBhcmUgaW1wbGVtZW50ZWQgYW5kIGdhdGVkOyB0aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZmVlZDpmZXRjaFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcHJvdG9jb2wgd2lyaW5nIGFuZCB0aGUgY29uc2VudFxcbnN1cmZhY2UncyByZW5kZXJpbmcgYXJlIHRoZSByZW1haW5kZXIuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5lbT57XCIoMjAyNi0wOC0yNzogdGhlIHByb3RvY29sIHdpcmluZyBhbmQgdGhlIFNESyBzdXJmYWNlIGhhdmVcXG5zaW5jZSBsYW5kZWQg4oCUIHNpdGUtbWFpbiAjMzc2LCBzZGsgMC41NC4wLiBPbmUgbmV3IHJlc2lkdWFsOiB0aGUgwqczLjEgcGF0aCBlbmZvcmNlcyBub1xcbmNyZWRlbnRpYWwta2luZCBlbGlnaWJpbGl0eSDigJQgcm9hZG1hcCBSMy0zOTQsIGluIFJlc2lkdWFscyBiZWxvdy4pXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgwrcgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJDcmVhdGVkOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAyMDI2LTA4LTI3IChyb2FkbWFwIFIzLTIyNylcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhpcyBkb2N1bWVudCBpcyB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJzaW5nbGUgaW1wbGVtZW50YXRpb24tc3RhdHVzIHNvdXJjZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBmb3JcXG5cIn08X2NvbXBvbmVudHMuYSBocmVmPVwiLi4vc3BlY3MvQ09OTkVDVE9SX0VHUkVTU19GSVhJTkdfU1BFQy5tZFwiPjxfY29tcG9uZW50cy5jb2RlPntcInNwZWNzL0NPTk5FQ1RPUl9FR1JFU1NfRklYSU5HX1NQRUMubWRcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5hPntcIi5cXG5XaGVyZSB0aGUgc3BlYyBhbmQgdGhpcyBmaWxlIGRpc2FncmVlLCB0aGlzIGZpbGUgZ292ZXJucy5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiMjAyNi0wOS0yNSAocm9hZG1hcCBSMy03NjgpLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBSZWNrb25lcidzIHJlcG9ydC12aWV3IGVncmVzcyB3YXMgcmVtb3ZlZDogdGhlIGFwcCBub1xcbmxvbmdlciByZXF1ZXN0cyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJuZXQ6ZmV0Y2hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCB0aGUgcmVwb3J0IHZpZXcgaG9sZHMgbm8gbmV0d29yaywgYW5kIHRoZSBidW5kbGVkIHVzYWdlXFxud29ya2Jvb2sgKFIzLTM0OSkgdGhhdCBoYXJkY29kZWQgdGhlIGFuYWx5dGljcyBvcmlnaW4gaXMgbW92ZWQgdG8gaXRzIG93blxcblwifTxfY29tcG9uZW50cy5jb2RlPntcImltbWVkaWF0ZWx5LXJ1bi91c2FnZS13b3JrYm9va1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcmVwbyB3aXRoIGRlY2xhcmVkIFwifTxfY29tcG9uZW50cy5jb2RlPntcImZlZWRzLyouZmVlZC5qc29uXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBmaWxlcy4gVGhlXFxuY29ubmVjdG9yIHJlYWxtIHRoYXQgcmVjb25uZWN0cyB0aG9zZSBmZWVkcyBhcyB0ZW1wbGF0ZS1ib3VuZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmZWVkOmZldGNoXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpcyBSMy03NjkuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTwvX2NvbXBvbmVudHMuYmxvY2txdW90ZT57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJ3aGF0LWRvbmUtbWVhbnMtaGVyZS1hbmQtd2hhdC1pdC1kb2VzLW5vdFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwid2hhdC1kb25lLW1lYW5zLWhlcmUtYW5kLXdoYXQtaXQtZG9lcy1ub3RcIiAvPntcIldoYXQgXFxcImRvbmVcXFwiIG1lYW5zIGhlcmUsIGFuZCB3aGF0IGl0IGRvZXMgbm90XCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgc3BlYyBpcyBlbXBoYXRpYyBvbiB0aGlzIGFuZCBzbyBpcyB0aGlzIGZpbGU6IGVncmVzcy1maXhpbmcgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJib3VuZHMgYSBjb21wcm9taXNlZFxcbmNvbm5lY3RvcjsgaXQgZG9lcyBub3QgbWFrZSBvbmUgemVyby1leGZpbCwgYW5kIGl0IGRvZXMgbm90aGluZyBhZ2FpbnN0IGEgaG9zdGlsZVxcbmF1dGhvci5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhlIGhvbmVzdCBjbGFpbSBhZnRlciB0aGlzIHdvcmsgaXMgdGhlIHNwZWMncyBvd24gwqc0IHdvcmRpbmcg4oCUXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcImNvbnNlbnRlZCByZWFjaDsgd3JpdGUtdG8tZml4ZWQtaG9zdCBhdCBkZWNsYXJlZC1zbG90LWVudHJvcHkgcGVyIHJlcXVlc3QsIGNvbXBsZXRpbmdcXG53aXRoaW4gbWludXRlczsgZnJlcXVlbmN5LXRyaXB3aXJlZCBvbmx5LlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08L19jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiTm90aGluZyBiZWxvdyB1cGdyYWRlcyB0aGF0IHRvIFxcXCJzYWZlXFxcIiwgYW5kIGEgZnV0dXJlIHJlYWRlciBzaG91bGQgdHJlYXQgYW55IHN1bW1hcnkgdGhhdFxcbmRvZXMgYXMgYSByZWdyZXNzaW9uIGluIHRoZSBkZXNjcmlwdGlvbiwgbm90IGFuIGltcHJvdmVtZW50IGluIHRoZSBtZWNoYW5pc20uXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cImJ1aWx0XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJidWlsdFwiIC8+e1wiQnVpbHRcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy50YWJsZT48X2NvbXBvbmVudHMudGhlYWQ+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50aD57XCLCp1wifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIk1lY2hhbmlzbVwifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIldoZXJlXCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGg+e1wiR2F0ZVwifTwvX2NvbXBvbmVudHMudGg+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50Ym9keT48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIsKnMlwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIlRydXN0ZWQgZmVlZCBjb25maWcgY29tcGlsZXMgdG8gYSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImZyb3plblwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiByZXF1ZXN0IHRlbXBsYXRlOyBubyBVUkwgc3VyZmFjZVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcImltbWVkaWF0ZWx5LXJ1bi1zaXRlLW1haW4vc3JjL3JlZ2lzdHJ5L2ZlZWRUZW1wbGF0ZS50c1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJmZWVkVGVtcGxhdGUudGVzdC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIMKnNSBtb3ZlcyAxLCA0LCA1LCA4XCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiwqcyIHJ1bGUgMlwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIlR5cGVkIGRhdGEtcGxhbmUgc2xvdHMgKFwifTxfY29tcG9uZW50cy5jb2RlPntcImlzbzg2MDFcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIC8gYm91bmRlZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJpbnRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIC8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZW51bVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpOyBhIHNsb3QgbWF5IG5vdCBjYXJyeSBhIGhvc3QsIHBhdGggb3IgbmV3IHF1ZXJ5IGtleVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcInNhbWVcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJwYXJhbS1jb25maW5lbWVudCBjYXNlc1wifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIsKnMiBydWxlIDJcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkhvc3QtbWludGVkIGN1cnNvcnNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIsIG9wYXF1ZSB0byB0aGUgY29ubmVjdG9yOyBleHRyYWN0aW9uIGJ5IGEgY29uZmlnLWRlY2xhcmVkIHJ1bGVcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJmZWVkVGVtcGxhdGUudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicmVnaXN0cnkvZmVlZEluc3RhbmNlLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcImZlZWRGZXRjaEhhbmRsZXIudGVzdC50c1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCLCpzIgcnVsZSAzXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiUmVxdWVzdCBib2R5IGZ1bGx5IHRlbXBsYXRlZCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImFuZCBieXRlLWNhcHBlZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgaG9zdC1zaWRlIGFuZCBzZXJ2ZXItc2lkZVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcImZlZWRUZW1wbGF0ZS50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcImltbWVkaWF0ZWx5LXJ1bi1iYWNrZW5kL3NyYy9uZXRGZXRjaC50c1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJuZXRGZXRjaC50ZXN0LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoaW5jbC4gdGhlIFVURi04LXZzLVVURi0xNiBjYXNlKVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIsKnMiBydWxlIDRcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJUZW1wbGF0ZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImRlZXAtZnJvemVuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGF0IGNvbXBpbGUgdGltZVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcImZlZWRUZW1wbGF0ZS50c1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJmcm96ZW4tdGVtcGxhdGUgY2FzZVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIsKnMiBydWxlIDVcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkhvc3QtbWludGVkIGluc3RhbmNlIGlkXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiOyBidWRnZXQga2V5ZWQgb24gaXQ7IHRlYXJkb3duIHJldm9rZXNcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJmZWVkSW5zdGFuY2UudHNcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiYnVkZ2V0ICsgdGVhcmRvd24gY2FzZXNcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCLCpzIuMVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIldyaXRlLXNpbmsgdnMgcmVhZC1zb3VyY2UgY29uc2VudCBkZXNjcmlwdG9yOiBuYW1lcyBpdCBvdXRib3VuZCwgbGlzdHMgdGhlIGNlbGxzIHNlbnQsIHN0YXRlcyB0aGUgdm9sdW1lXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wicmVnaXN0cnkvd3JpdGVTaW5rLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcIndyaXRlU2luay50ZXN0LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIsKnMy4xXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnN0cm9uZz57XCJQaW5uZWQgc2VjcmV0IHBhdGhcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHNlcnZlci1zaWRlIGhlYWRlciBpbmplY3Rpb24sIGNhbGxlciBjYW5ub3Qgb3ZlcndyaXRlIGl0LCBuYW1lIHN0cmlwcGVkIGZyb20gdGhlIHJlc3BvbnNlLCBhbmQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJubyBicm93c2VyLWRpcmVjdCBmYWxsYmFjayBvbiBhbnkgZmFpbHVyZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcImVkaXRvci9mZWVkRmV0Y2hIYW5kbGVyLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgYmFja2VuZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJuZXRGZXRjaC50c1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJmZWVkRmV0Y2hIYW5kbGVyLnRlc3QudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJuZXRGZXRjaC50ZXN0LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIsKnMiBydWxlIDFcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJmZWVkOmZldGNoXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBleGlzdHMgYXMgYSBjYXBhYmlsaXR5IGRpc3RpbmN0IGZyb20gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibmV0OmZldGNoXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcIkBpbW1lZGlhdGVseS1ydW4vcHJlYXV0aC1jb3JlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAwLjEuMTIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcInJlZ2lzdHJ5IDEuNy4wXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIilcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJ0ZXN0L2NhcGFiaWxpdGllcy50ZXN0LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRib2R5PjwvX2NvbXBvbmVudHMudGFibGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwibm90LWJ1aWx0LXRoZS1yZW1haW5kZXItaW4tdGhlLW9yZGVyLWl0LXNob3VsZC1sYW5kXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJub3QtYnVpbHQtdGhlLXJlbWFpbmRlci1pbi10aGUtb3JkZXItaXQtc2hvdWxkLWxhbmRcIiAvPntcIk5vdCBidWlsdCDigJQgdGhlIHJlbWFpbmRlciwgaW4gdGhlIG9yZGVyIGl0IHNob3VsZCBsYW5kXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMub2w+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcInByb3RvY29sLWZlZWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGdhdGUgcm93IGFuZCBkaXNwYXRjaFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic2l0ZS1tYWluXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyZWdpc3RyeS9hY3Rpb25HYXRlLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIixcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJlZGl0b3IvcmVxdWVzdERpc3BhdGNoZXIudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKS4gQmxvY2tlZCBvbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJAaW1tZWRpYXRlbHktcnVuL3ByZWF1dGgtY29yZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCIwLjEuMTJcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCJcXG5iZWluZyBwdWJsaXNoZWQ6IFwifTxfY29tcG9uZW50cy5jb2RlPntcIk1ldGhvZERlZi5jYXBhYmlsaXR5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpcyB0eXBlZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJDYXBhYmlsaXR5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgYW5kIHRoZSB2b2NhYnVsYXJ5IGlzXFxudGhlIG9uZSBzb3VyY2Ugb2YgdHJ1dGggZm9yIHRoYXQgdW5pb24gKFwifTxfY29tcG9uZW50cy5jb2RlPntcIndheXNfb2Zfd29ya2luZ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgwqc2IOKAlCBhIHNoYXJlZCB2b2NhYnVsYXJ5IGlzXFxucHVibGlzaGVkIG9uY2UgYW5kIGNvbnN1bWVkLCBuZXZlciBjb3BpZWQpLiBTaXRlLW1haW4gZGVsaWJlcmF0ZWx5IGRpZCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBidW1wIGl0c1xcbnBpbiBhaGVhZCBvZiB0aGUgcHVibGlzaCwgYmVjYXVzZSBhIHBpbiB0byBhbiB1bnB1Ymxpc2hlZCB2ZXJzaW9uIHR1cm5zIGV2ZXJ5IGNoZWNrIGluXFxudGhlIHJlcG8gcmVkIG9uIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm5wbSBjaVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYW5kIHRoZSBpbmZvcm1hdGl2ZSBvbmUgbmV2ZXIgcnVucy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlRoZSBTREsgY2xpZW50IHN1cmZhY2VcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIkBpbW1lZGlhdGVseS1ydW4vc2RrXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikg4oCUIGEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZmVlZEZldGNoKGluc3RhbmNlSWQsIHBhcmFtcylcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxud3JhcHBlci4gVW50aWwgaXQgZXhpc3RzIG5vIGFwcCBjYW4gcmVhY2ggdGhlIGhhbmRsZXIsIHdoaWNoIGlzIHRoZSBpbnRlbmRlZCBvcmRlcjpcXG5lbmZvcmNlbWVudCBzaGlwcyBiZWZvcmUgdGhlIGF1dGhvcml0eSBpdCBjb25zdHJhaW5zIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJ3YXlzX29mX3dvcmtpbmdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIMKnMSkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJSZW5kZXJpbmdcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdGhlIMKnMi4xIHdyaXRlLXNpbmsgY29uc2VudCBkZXNjcmlwdG9yIGluIHRoZSBwb3dlcmJveC4gVGhlIGRlc2NyaXB0b3IgaXNcXG5jb21wdXRlZCBhbmQgdGVzdGVkOyBkcmF3aW5nIGl0IGlzIEQ2IChyb2FkbWFwIFIzLTIyOSksIHdob3NlIGNvbXBvc2l0ZSBjb25zZW50IHBsYW5cXG5hbHJlYWR5IGNhcnJpZXMgb25lIHN0ZXAgcGVyIGZlZWQgd2l0aCB0aGUgZGVzY3JpcHRvciBhdHRhY2hlZC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlBlci1ob3AgcmVkaXJlY3QgYmVoYXZpb3VyIGZvciBhbiBpbmplY3RlZCByZXF1ZXN0LlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGUgc2VydmVyIHJlLXJlc29sdmVzIGFuZFxcbnJlLXZhbGlkYXRlcyBldmVyeSBob3AgKGJ1aWx0LCBUNDApLCBhbmQgdGhlIGluamVjdGVkIGhlYWRlciByaWRlcyB0aGUgcmVxdWVzdCBhY3Jvc3NcXG5ob3BzIHRoYXQgcGFzc2VkIHRob3NlIGNoZWNrcy4gV2hldGhlciBhbiBpbmplY3RlZCBjcmVkZW50aWFsIHNob3VsZCBiZSBkcm9wcGVkIG9uIGFcXG5jcm9zcy1vcmlnaW4gaG9wIGV2ZW4gd2hlbiB0aGF0IGhvcCBpcyBhbGxvd2xpc3RlZCBpcyBub3Qgc2V0dGxlZCBoZXJlOyB0b2RheSB0aGVcXG5hbGxvd2xpc3QgaXMgYSBzaW5nbGUgb3JpZ2luIHBlciBmZWVkIHRlbXBsYXRlLCBzbyB0aGUgY2FzZSBpcyB1bnJlYWNoYWJsZSB0aHJvdWdoXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZmVlZDpmZXRjaFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIHJlY29yZGVkIGJlY2F1c2UgaXQgYmVjb21lcyByZWFjaGFibGUgdGhlIG1vbWVudCBhIHRlbXBsYXRlIG5hbWVzIG1vcmVcXG50aGFuIG9uZSBvcmlnaW4uXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInJlc2lkdWFscy1uYW1lZC1ub3QtY2xvc2VkXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJyZXNpZHVhbHMtbmFtZWQtbm90LWNsb3NlZFwiIC8+e1wiUmVzaWR1YWxzIOKAlCBuYW1lZCwgbm90IGNsb3NlZFwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkRlY2xhcmVkLXNsb3QgZW50cm9weSAowqc0KS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgQW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaXNvODYwMVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgc2xvdCBjYXJyaWVzIH4zMOKAkzUwIGJpdHMgcGVyIHJlcXVlc3QsIHNvIGFcXG4yNTYtYml0IHNlY3JldCBkcmFpbnMgaW4gc2luZ2xlLWRpZ2l0IG9uLWNhZGVuY2UgcmVxdWVzdHMuIFRoZSBidWRnZXQgYm91bmRzXFxucmVxdWVzdHMtcGVyLXdpbmRvdywgbm90IGJpdHMtcGVyLXJlcXVlc3QsIGFuZCB0aGVyZWZvcmUgbmV2ZXIgZmlyZXMgb24gdGhpcy4gVGhlIGNvZGVcXG5zYXlzIHNvIGF0IHRoZSBkZWZpbml0aW9uIG9mIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNvbnN1bWVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBub3Qgb25seSBoZXJlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQm9keSByZWZsZWN0aW9uICjCpzUgbW92ZSA2KS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgQSBtYWxpY2lvdXMgYWxsb3dsaXN0ZWQgaG9zdCBjYW4gZWNobyB0aGUgaW5qZWN0ZWRcXG5jcmVkZW50aWFsIGluIGl0cyByZXNwb25zZSBcIn08X2NvbXBvbmVudHMuZW0+e1wiYm9keVwifTwvX2NvbXBvbmVudHMuZW0+e1wiLCB3aGljaCB0aGUgY29ubmVjdG9yIHJlYWRzIGFzIGRhdGEuIFNlcnZlci1zaWRlXFxuaW5qZWN0aW9uIHJlbW92ZXMgdGhlIGhlYWRlciBmcm9tIHRoZSBjb25uZWN0b3IncyBmcmFtZTsgaXQgY2Fubm90IHJlbW92ZSB0aGUgdmFsdWVcXG5mcm9tIGJ5dGVzIHRoZSB1cHN0cmVhbSBjaG9vc2VzIHRvIHNlbmQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgaG9zdGlsZSBhdXRob3IgKMKnMi4xIC8gwqc1IG1vdmUgOSkuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRhcmdldC1maXhpbmcgcGlucyBmYWl0aGZ1bGx5IHRvIHdoYXRldmVyXFxub3JpZ2luIHRoZSBjb25maWcgbmFtZXMuIENvbnNlbnQgbGVnaWJpbGl0eSBpcyB0aGUgb25seSBkZWZlbnNlLCBhbmQgaXQgaXNcXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInVudmFsaWRhdGVkXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCB0aGUgRTMgY29tcHJlaGVuc2lvbiBzdHVkeSBoYXMgbm90IHJ1biBhbmQgbXVzdCBub3cgaW5jbHVkZSBhblxcbm91dGJvdW5kLWZlZWQgYXJtLiBBIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlBPU1RcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLXdpdGgtY2VsbC1ib2R5IGZlZWQgaXMgYSBuYW1lZCByZXNpZHVhbCwgbm90IGEgY29udGFpbmVkXFxudGhyZWF0LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQ3JlZGVudGlhbC1raW5kIGVsaWdpYmlsaXR5IG9uIHRoZSDCpzMuMSBwYXRoIGlzIHVuZW5mb3JjZWQgKHJvYWRtYXAgUjMtMzk0LCBmb3VuZFxcbjIwMjYtMDgtMjcpLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJTRUNSRVRTX1NQRUMgwqcyLjFcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIEMyIGVudW1lcmF0ZXMgdGhlIGJhY2tlbmQtcHJveGllZCBjYXJ2ZS1vdXQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJieSByZXNvdXJjZVxcbmtpbmRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYW5kIHNheXMgd2lkZW5pbmcgaXQgXFxcImlzIGEgc3BlYyBlZGl0IHNvbWVib2R5IGhhcyB0byB3cml0ZSwgbm90IGEganVkZ2VtZW50IGNhbGwgYXQgYSBjYWxsXFxuc2l0ZVxcXCIuIMKnMy4xIHdpZGVuZWQgaXQgdG8gYSBzZWNvbmQgY29uc3VtZXIsIHRoZSBlZGl0IHdhcyBub3Qgd3JpdHRlbiwgYW5kIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibm8gbGF5ZXIgY2hlY2tzIHRoZVxcbmtpbmRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCI6IFwifTxfY29tcG9uZW50cy5jb2RlPntcImZlZWRUZW1wbGF0ZS50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdHlwZXMgdGhlIHNlbGVjdG9yIFwifTxfY29tcG9uZW50cy5jb2RlPntcInsgZmFtaWx5Pzogc3RyaW5nOyB0eXBlPzogc3RyaW5nIH1cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChhIGZyZWUtZm9ybVxcbnN0cmluZywgbm90IFwifTxfY29tcG9uZW50cy5jb2RlPntcIlNlY3JldFR5cGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSBhbmQgY29waWVzIGl0IHRocm91Z2ggdW52YWxpZGF0ZWQg4oCUIHdoaWxlIHZhbGlkYXRpbmcgZGF0YS1wbGFuZSBzbG90XFxudHlwZXMgc3RyaWN0bHkgaW4gdGhlIHNhbWUgY29tcGlsZXIg4oCUIGFuZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyZXNvbHZlU2VjcmV0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDihpIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZmVlZEZldGNoSGFuZGxlclwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaW5qZWN0IHdoYXRldmVyXFxubWF0Y2hlcy4gVGhlIHBhdGggdGhhdCBhY3R1YWxseSBmaXJlcyBpcyBhbiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm9taXR0ZWRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdHlwZTogXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibWF0Y2hlc1NlbGVjdG9yXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB0cmVhdHMgYSBtaXNzaW5nXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widHlwZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYXMgXCJ9PF9jb21wb25lbnRzLmVtPntcIm1hdGNoIGV2ZXJ5IGtpbmRcIn08L19jb21wb25lbnRzLmVtPntcIiwgc28gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW5qZWN0U2VjcmV0OiB7IGZhbWlseTogXFxcImFjbWVcXFwiIH1cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNhbiBzZWxlY3QgYW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wib2F1dGgtcmVmcmVzaFwifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG5yZWNvcmQg4oCUIHdoaWNoIEMyIGV4Y2x1ZGVzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1widW5jb25kaXRpb25hbGx5XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBhbmQgcm91dGUgaXQgdG8gdGhlIHNlcnZlci4gQm91bmRlZCBieSB0aGVcXG5yZWNvcmQgZXhpc3RpbmcsIG1hdGNoaW5nLCBhbmQgYmVpbmcgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYm91bmRPcmlnaW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLWJvdW5kIHRvIHRoYXQgZmVlZCdzIG9yaWdpbiB1bmRlciBhIGdyYW50IHRoaXNcXG5hcHAgaG9sZHMuIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiVGhpcyBxdWFsaWZpZXMgdGhlIMKnMy4xIHJvdyBhYm92ZSByYXRoZXIgdGhhbiByZXRyYWN0aW5nIGl0OlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB0aGUgbWVjaGFuaXNtIGlzXFxuYnVpbHQgYW5kIHNvdW5kOyB0aGUgZ2F0ZSBvbiBcIn08X2NvbXBvbmVudHMuZW0+e1wid2hpY2ggY3JlZGVudGlhbCBtYXkgdXNlIGl0XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgaXMgbWlzc2luZy4gTm90ZSB0aGUgc2NvcGUg4oCUIHRoaXMgaXMgYVxcblwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicm91dGluZ1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB3aWRlbmluZyAoQzUgY2VsbCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlQxXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiKSwgbm90IGEgY3VzdG9keSBvbmU7IG5vIGZlZWQgY3JlZGVudGlhbCBpcyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJwbGF0Zm9ybS1oZWxkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkF2YWlsYWJpbGl0eSBjb3N0IG9mIMKnMy4xLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmZWVkOmZldGNoXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiByZWZ1c2VzIHdoZW4gdGhlIHBpbm5lZCBzZXJ2ZXIgcGF0aCBpc1xcbnVuYXZhaWxhYmxlIHJhdGhlciB0aGFuIGZhbGxpbmcgYmFjay4gVGhhdCBpcyBkZWxpYmVyYXRlIOKAlCB0aGUgZmFsbGJhY2sgcGF0aCBpcyB0aGVcXG51bnBpbm5lZCBvbmUg4oCUIGFuZCBpdCBtZWFucyBhIGNvbm5lY3RvciBkb2VzIG5vdCBwb2xsIHdoaWxlIHRoZSBiYWNrZW5kIGlzIGRvd24uXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPjwvPjtcbn1cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE1EWENvbnRlbnQocHJvcHMgPSB7fSkge1xuICBjb25zdCB7d3JhcHBlcjogTURYTGF5b3V0fSA9IHtcbiAgICAuLi5fcHJvdmlkZUNvbXBvbmVudHMoKSxcbiAgICAuLi5wcm9wcy5jb21wb25lbnRzXG4gIH07XG4gIHJldHVybiBNRFhMYXlvdXQgPyA8TURYTGF5b3V0IHsuLi5wcm9wc30+PF9jcmVhdGVNZHhDb250ZW50IHsuLi5wcm9wc30gLz48L01EWExheW91dD4gOiBfY3JlYXRlTWR4Q29udGVudChwcm9wcyk7XG59XG5mdW5jdGlvbiBfbWlzc2luZ01keFJlZmVyZW5jZShpZCwgY29tcG9uZW50LCBwbGFjZSkge1xuICB0aHJvdyBuZXcgRXJyb3IoXCJFeHBlY3RlZCBcIiArIChjb21wb25lbnQgPyBcImNvbXBvbmVudFwiIDogXCJvYmplY3RcIikgKyBcIiBgXCIgKyBpZCArIFwiYCB0byBiZSBkZWZpbmVkOiB5b3UgbGlrZWx5IGZvcmdvdCB0byBpbXBvcnQsIHBhc3MsIG9yIHByb3ZpZGUgaXQuXCIgKyAocGxhY2UgPyBcIlxcbkl04oCZcyByZWZlcmVuY2VkIGluIHlvdXIgY29kZSBhdCBgXCIgKyBwbGFjZSArIFwiYCBpbiBgL2FwcC9kb2NzL3N0YXR1cy9DT05ORUNUT1JfRUdSRVNTX0ZJWElOR19TVEFUVVMubWRgXCIgOiBcIlwiKSk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUVBLElBQUFBLFlBQUEsR0FBQUMsT0FBQTtBQUF3RixJQUFBQyxXQUFBLEdBQUFELE9BQUE7QUFGeEY7QUFDQTs7QUFFQSxTQUFTRSxpQkFBaUJBLENBQUNDLEtBQUssRUFBRTtFQUNoQyxNQUFNQyxXQUFXLEdBQUc7TUFDbEJDLENBQUMsRUFBRSxHQUFHO01BQ05DLFVBQVUsRUFBRSxZQUFZO01BQ3hCQyxJQUFJLEVBQUUsTUFBTTtNQUNaQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxDQUFDLEVBQUUsR0FBRztNQUNOQyxNQUFNLEVBQUUsUUFBUTtNQUNoQkMsS0FBSyxFQUFFLE9BQU87TUFDZEMsS0FBSyxFQUFFLE9BQU87TUFDZEMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsS0FBSyxFQUFFLE9BQU87TUFDZEMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUixHQUFHLElBQUFDLDZCQUFrQixFQUFDLENBQUM7TUFDdkIsR0FBR25CLEtBQUssQ0FBQ29CO0lBQ1gsQ0FBQztJQUFFO01BQUNDO0lBQWEsQ0FBQyxHQUFHcEIsV0FBVztFQUNoQyxJQUFJLENBQUNvQixhQUFhLEVBQUVDLG9CQUFvQixDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUM7RUFDL0Qsb0JBQU8sSUFBQXhCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQXpCLFdBQUEsQ0FBQTBCLFFBQUE7SUFBQUMsUUFBQSxnQkFBRSxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDSyxFQUFFO01BQUNvQixFQUFFLEVBQUMsbUNBQW1DO01BQUFELFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBbUMsQ0FBRSxDQUFDLEVBQUMsdUNBQXVDO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDUyxDQUFDO01BQUFlLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1UsTUFBTTtRQUFBYyxRQUFBLEdBQUUscUlBQXFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQVksQ0FBbUIsQ0FBQyxFQUFDLDBFQUEwRTtNQUFBLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0ksRUFBRTtRQUFBb0IsUUFBQSxFQUFFO01BQXVOLENBQWlCLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBVSxDQUFxQixDQUFDLEVBQUMsOEJBQThCO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDRSxVQUFVO01BQUFzQixRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNTLENBQUM7UUFBQWUsUUFBQSxHQUFFLHVCQUF1QixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXFDLENBQXFCLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0MsQ0FBQztVQUFDMEIsSUFBSSxFQUFDLDBDQUEwQztVQUFBSCxRQUFBLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBcUIsUUFBQSxFQUFFO1VBQXVDLENBQW1CO1FBQUMsQ0FBZSxDQUFDLEVBQUMsOERBQThEO01BQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUF5QixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNFLFVBQVU7TUFBQXNCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1MsQ0FBQztRQUFBZSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQThCLENBQXFCLENBQUMsRUFBQywwRUFBMEUsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRyxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsd0lBQXdJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQWdDLENBQW1CLENBQUMsRUFBQyxzQkFBc0IsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRyxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBbUIsQ0FBbUIsQ0FBQyxFQUFDLDZFQUE2RSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNHLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFZLENBQW1CLENBQUMsRUFBQyxhQUFhO01BQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUF5QixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNNLEVBQUU7TUFBQ21CLEVBQUUsRUFBQywyQ0FBMkM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUEyQyxDQUFFLENBQUMsRUFBQyxnREFBZ0Q7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNTLENBQUM7TUFBQWUsUUFBQSxHQUFFLGtFQUFrRSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQWtILENBQXFCLENBQUMsRUFBQyxrRUFBa0U7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNFLFVBQVU7TUFBQXNCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1MsQ0FBQztRQUFBZSxRQUFBLEVBQUU7TUFBa0ksQ0FBZ0IsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUF5QixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNTLENBQUM7TUFBQWUsUUFBQSxFQUFFO0lBQTJLLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDbUIsRUFBRSxFQUFDLE9BQU87TUFBQUQsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLE9BQU87SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNXLEtBQUs7TUFBQWEsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDZSxLQUFLO1FBQUFTLFFBQUEsZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDZ0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNjLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQUcsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBVyxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDYyxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFPLENBQWlCLENBQUMsbUJBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNjLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQU0sQ0FBaUIsQ0FBQztRQUFBLENBQWdCO01BQUMsQ0FBbUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1ksS0FBSztRQUFBWSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNnQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBSSxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsR0FBRSxvQ0FBb0MsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFRLENBQXFCLENBQUMsRUFBQyxtQ0FBbUM7VUFBQSxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRyxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBd0QsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQXNCLENBQW1CLENBQUMsRUFBQyx3QkFBd0I7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2dCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFXLENBQWlCLENBQUMsbUJBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxHQUFFLDBCQUEwQixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNHLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUFTLENBQW1CLENBQUMsRUFBQyxhQUFhLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQUssQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRyxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBTSxDQUFtQixDQUFDLEVBQUMsdURBQXVEO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBTSxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUF5QixDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2dCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFXLENBQWlCLENBQUMsbUJBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFxQixDQUFxQixDQUFDLEVBQUMsaUVBQWlFO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNHLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUFpQixDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNHLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUEwQixDQUFtQixDQUFDO1VBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQTBCLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNnQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBVyxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsR0FBRSwrQkFBK0IsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFpQixDQUFxQixDQUFDLEVBQUMsNkJBQTZCO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNHLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUFpQixDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNHLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUF5QyxDQUFtQixDQUFDO1VBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNHLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUFrQixDQUFtQixDQUFDLEVBQUMsbUNBQW1DO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNnQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBVyxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsR0FBRSxXQUFXLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBYSxDQUFxQixDQUFDLEVBQUMsa0JBQWtCO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQWlCLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBc0IsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNnQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBVyxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBeUIsQ0FBcUIsQ0FBQyxFQUFDLHdDQUF3QztVQUFBLENBQWlCLENBQUMsbUJBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNHLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUFpQixDQUFtQjtVQUFDLENBQWdCLENBQUMsbUJBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQXlCLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDZ0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQU0sQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBMEcsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQXVCLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQW1CLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNnQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBTSxDQUFpQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBb0IsQ0FBcUIsQ0FBQyxFQUFDLG9HQUFvRyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQTJDLENBQXFCLENBQUM7VUFBQSxDQUFnQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDYSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQTRCLENBQW1CLENBQUMsRUFBQyxZQUFZLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBcUIsUUFBQSxFQUFFO1lBQWEsQ0FBbUIsQ0FBQztVQUFBLENBQWdCLENBQUMsbUJBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRyxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBMEIsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRyxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBa0IsQ0FBbUIsQ0FBQztVQUFBLENBQWdCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDZ0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQVcsQ0FBaUIsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNHLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUFZLENBQW1CLENBQUMsRUFBQyx3Q0FBd0MsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRyxJQUFJO2NBQUFxQixRQUFBLEVBQUU7WUFBVyxDQUFtQixDQUFDO1VBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ2EsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNHLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUErQixDQUFtQixDQUFDLEVBQUMsV0FBVyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNHLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUFnQixDQUFtQixDQUFDLEVBQUMsR0FBRztVQUFBLENBQWlCLENBQUMsbUJBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNhLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNHLElBQUk7Y0FBQXFCLFFBQUEsRUFBRTtZQUEyQixDQUFtQjtVQUFDLENBQWdCLENBQUM7UUFBQSxDQUFnQixDQUFDO01BQUEsQ0FBbUIsQ0FBQztJQUFBLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDbUIsRUFBRSxFQUFDLHFEQUFxRDtNQUFBRCxRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQXFELENBQUUsQ0FBQyxFQUFDLHdEQUF3RDtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ1EsRUFBRTtNQUFBZ0IsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDTyxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNVLE1BQU07VUFBQWMsUUFBQSxHQUFFLE1BQU0sZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRyxJQUFJO1lBQUFxQixRQUFBLEVBQUU7VUFBZSxDQUFtQixDQUFDLEVBQUMsd0JBQXdCO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRyxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNHLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUF3QixDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNHLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUE2QixDQUFtQixDQUFDLEVBQUMsZ0JBQWdCLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQStCLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBUSxDQUFxQixDQUFDLEVBQUMscUJBQXFCLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQXNCLENBQW1CLENBQUMsRUFBQyxZQUFZLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQVksQ0FBbUIsQ0FBQyxFQUFDLG1FQUFtRSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNHLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFpQixDQUFtQixDQUFDLEVBQUMsdUdBQXVHLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBSyxDQUFxQixDQUFDLEVBQUMscUhBQXFILGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQVEsQ0FBbUIsQ0FBQyxFQUFDLHNDQUFzQztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUF3QixDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNHLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFzQixDQUFtQixDQUFDLEVBQUMsUUFBUSxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNHLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUErQixDQUFtQixDQUFDLEVBQUMsK0lBQStJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQWlCLENBQW1CLENBQUMsRUFBQyxPQUFPO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDTyxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQVcsQ0FBcUIsQ0FBQyxFQUFDLG1PQUFtTztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFxRCxDQUFxQixDQUFDLEVBQUMsbVhBQW1YLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQVksQ0FBbUIsQ0FBQyxFQUFDLDZGQUE2RjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDTSxFQUFFO01BQUNtQixFQUFFLEVBQUMsNEJBQTRCO01BQUFELFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBNEIsQ0FBRSxDQUFDLEVBQUMsK0JBQStCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDaUIsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUEzQixXQUFBLENBQUF5QixJQUFBLEVBQUN0QixXQUFXLENBQUNPLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBNkIsQ0FBcUIsQ0FBQyxFQUFDLE1BQU0sZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRyxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBUyxDQUFtQixDQUFDLEVBQUMsa1BBQWtQLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQVMsQ0FBbUIsQ0FBQyxFQUFDLGtCQUFrQjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUE4QixDQUFxQixDQUFDLEVBQUMsa0ZBQWtGLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0ksRUFBRTtVQUFBb0IsUUFBQSxFQUFFO1FBQU0sQ0FBaUIsQ0FBQyxFQUFDLGlMQUFpTDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUF3QyxDQUFxQixDQUFDLEVBQUMsMEhBQTBILGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBYSxDQUFxQixDQUFDLEVBQUMsMEZBQTBGLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQU0sQ0FBbUIsQ0FBQyxFQUFDLG9FQUFvRTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQXlCLElBQUEsRUFBQ3RCLFdBQVcsQ0FBQ08sRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFpRyxDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNHLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFtQixDQUFtQixDQUFDLEVBQUMsK0NBQStDLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBbUIsQ0FBcUIsQ0FBQyxFQUFDLDRLQUE0SyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTJCLENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQWlCLENBQW1CLENBQUMsRUFBQyxzQkFBc0IsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRyxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBb0MsQ0FBbUIsQ0FBQyxFQUFDLDZCQUE2QixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNHLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFZLENBQW1CLENBQUMsRUFBQyxvSEFBb0gsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRyxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBZSxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNHLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFrQixDQUFtQixDQUFDLEVBQUMsZ0VBQWdFLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ1UsTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBUyxDQUFxQixDQUFDLEVBQUMsU0FBUyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNHLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFpQixDQUFtQixDQUFDLEVBQUMscUJBQXFCLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQU0sQ0FBbUIsQ0FBQyxFQUFDLE1BQU0sZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDSSxFQUFFO1VBQUFvQixRQUFBLEVBQUU7UUFBa0IsQ0FBaUIsQ0FBQyxFQUFDLE9BQU8sZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDRyxJQUFJO1VBQUFxQixRQUFBLEVBQUU7UUFBb0MsQ0FBbUIsQ0FBQyxFQUFDLGlCQUFpQixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNHLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFlLENBQW1CLENBQUMsRUFBQywrQkFBK0IsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDVSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFpQixDQUFxQixDQUFDLEVBQUMsc0ZBQXNGLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQyxFQUFDLDhEQUE4RCxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQThELENBQXFCLENBQUMsRUFBQyxrREFBa0QsZUFBQyxJQUFBM0IsV0FBQSxDQUFBNkIsR0FBQSxFQUFDMUIsV0FBVyxDQUFDSSxFQUFFO1VBQUFvQixRQUFBLEVBQUU7UUFBNkIsQ0FBaUIsQ0FBQyxFQUFDLDJDQUEyQyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQVMsQ0FBcUIsQ0FBQyxFQUFDLHFCQUFxQixlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQUksQ0FBcUIsQ0FBQyxFQUFDLDhDQUE4QyxlQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNHLElBQUk7VUFBQXFCLFFBQUEsRUFBRTtRQUFlLENBQW1CLENBQUMsRUFBQyxHQUFHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBM0IsV0FBQSxDQUFBeUIsSUFBQSxFQUFDdEIsV0FBVyxDQUFDTyxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUMxQixXQUFXLENBQUNVLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTRCLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTNCLFdBQUEsQ0FBQTZCLEdBQUEsRUFBQzFCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBcUIsUUFBQSxFQUFFO1FBQVksQ0FBbUIsQ0FBQyxFQUFDLGdOQUFnTjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQztFQUFBLENBQUUsQ0FBQztBQUNwamQ7QUFDZSxTQUFTSSxVQUFVQSxDQUFDN0IsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFO0VBQzdDLE1BQU07SUFBQzhCLE9BQU8sRUFBRUM7RUFBUyxDQUFDLEdBQUc7SUFDM0IsR0FBRyxJQUFBWiw2QkFBa0IsRUFBQyxDQUFDO0lBQ3ZCLEdBQUduQixLQUFLLENBQUNvQjtFQUNYLENBQUM7RUFDRCxPQUFPVyxTQUFTLGdCQUFHLElBQUFqQyxXQUFBLENBQUE2QixHQUFBLEVBQUNJLFNBQVM7SUFBQSxHQUFLL0IsS0FBSztJQUFBeUIsUUFBQSxlQUFFLElBQUEzQixXQUFBLENBQUE2QixHQUFBLEVBQUM1QixpQkFBaUI7TUFBQSxHQUFLQztJQUFLLENBQUc7RUFBQyxDQUFXLENBQUMsR0FBR0QsaUJBQWlCLENBQUNDLEtBQUssQ0FBQztBQUNsSDtBQUFDZ0MsRUFBQSxHQU51QkgsVUFBVTtBQU9sQyxTQUFTUCxvQkFBb0JBLENBQUNJLEVBQUUsRUFBRU8sU0FBUyxFQUFFQyxLQUFLLEVBQUU7RUFDbEQsTUFBTSxJQUFJQyxLQUFLLENBQUMsV0FBVyxJQUFJRixTQUFTLEdBQUcsV0FBVyxHQUFHLFFBQVEsQ0FBQyxHQUFHLElBQUksR0FBR1AsRUFBRSxHQUFHLG9FQUFvRSxJQUFJUSxLQUFLLEdBQUcscUNBQXFDLEdBQUdBLEtBQUssR0FBRywyREFBMkQsR0FBRyxFQUFFLENBQUMsQ0FBQztBQUNyUjtBQUFDLElBQUFGLEVBQUE7QUFBQUksWUFBQSxDQUFBSixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}