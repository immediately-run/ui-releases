var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      blockquote: "blockquote",
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      h3: "h3",
      hr: "hr",
      li: "li",
      p: "p",
      pre: "pre",
      strong: "strong",
      table: "table",
      tbody: "tbody",
      td: "td",
      th: "th",
      thead: "thead",
      tr: "tr",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "reckoner-authors-view-the-document-describing-itself-as-a-template-the-author-owns",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "reckoner-authors-view-the-document-describing-itself-as-a-template-the-author-owns"
      }), "Reckoner Author's View — the document describing itself, as a template the author owns"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Status:"
      }), " implemented at the deliverable level — R3-435/R3-436; one adversarial pass\nfolded (§11, AV-R1…R14); residuals live in the status doc. · ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Updated:"
      }), " 2026-08-28"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.em, {
        children: ["(Implementation note, 2026-08-28 — authored, adversarially reviewed, and built in the\nsame pass: §§1–6 and the §8 gates are normative and shipped; §7 and §12 remain the\nhonest remainder. The ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "proposal"
        }), " markers on built sections were reconciled in this\nedit, per spec_style \"keep status honest\".)"]
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["The single implementation-status source for this spec is\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "docs/status/AUTHORS_VIEW_STATUS.md"
          })]
        }), " — where this document and that one disagree, the\nstatus doc governs."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Reads first:"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ARCHITECTURE_PLAN.md"
        }), " §3.3 (the closed component catalog, RQ-F1,\nanti-affordances), §8 (the assistant + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "FORMULA_AUTHORING_PROMPT"
        }), "), R-5 (the\nadditive-only discipline — stated there for the stdlib; the catalog shares it through\nthe versioning/compat story, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "DOCUMENT_VERSIONING_SPEC"
        }), "); ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "product_definition.md"
        }), "'s\nviewer promise (\"open a link, see a live report … and never see a formula\" — load-bearing\nfor §6); ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "WHATIF_SHADOW_EVALUATION_SPEC.md"
        }), " (sibling review surface; shared\nrun-mode-first posture); ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "REPORTING_SPREADSHEET_SPEC.md"
        }), " §3.4 and the platform's\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "TRUST_MODES_SPEC"
        }), " §5.1 (non-executable templates)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-0",
      "data-slug": "0-charter-normative-shipped-2026-08-28",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-0"
      }), "0. Charter  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative — shipped 2026-08-28)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["A Reckoner document's consumer report deliberately shows ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "results, not workings"
      }), ". The\nworkings — what formulas exist, what tests cover them, what data feeds them, and why the\nmodel is shaped the way it is — are discoverable today only through interactive chrome\n(the workbook panel, the inspector) or by reading source files. There is no ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "document"
      }), "\nthat presents the document: nothing shareable, diffable, or reviewable that says \"here is\nthis workbook, explained.\""]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "author's view"
      }), " is that document: a second rendered view summarizing formulas, data\ntables, and test assets — plus, optionally, the creators' thinking. Its two halves have\ndifferent owners:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The inventory is application responsibility."
        }), " What exists and how well it is tested\nis ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "computed"
        }), ", rendered by new catalog ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "reflection components"
        }), " (§2) that enumerate\nlive state — never hand-listed, so it cannot rot or lie about coverage."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The narrative is the author's."
        }), " The view is an ordinary template file the author\nowns completely — reorderable, annotatable, and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "deletable in part or whole"
        }), ". There\nis deliberately ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "no enforcement"
        }), " that any generated section remains (§6; owner\ndecision, §10): the trust surface for completeness is the computed chrome (workbook\npanel, inspector), which stays unsuppressible regardless of what any template says. A\ndocument is curated; the chrome is complete."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "No new realm, capability, principal, service, or gate. One new template role, four new\ncatalog components, one new render port, one new (optional) manifest key."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-1",
      "data-slug": "1-product-surface-normative-shipped-2026-08-28",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-1"
      }), "1. Product surface  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative — shipped 2026-08-28)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-1-1",
      "data-slug": "11-default-when-absent-file-when-owned",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-1-1"
      }), "1.1 Default when absent; file when owned"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["With ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "no"
        }), " author's-view template in the document, the app renders a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "built-in\ndefault view"
        }), " (the scaffold, §5.1) — live, never materialized, complete by\nconstruction because its components enumerate everything (§2.1)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["When the document carries ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "templates/authors_view.mdx"
        }), " (or the template the manifest's\noptional ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "authorsView"
        }), " key names, §4), that file ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "is"
        }), " the author's view — replacing\nthe default entirely. Creating the file is how an author takes ownership; a\n\"customize\" affordance that materializes the scaffold into the document is booked\n(§7), pending the write path."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-1-2",
      "data-slug": "12-the-door-and-the-way-back",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-1-2"
      }), "1.2 The door, and the way back"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The author's view opens from the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "workbook panel"
      }), " (the existing author-side door;\nrun-mode report chrome is untouched — value 2, same posture as the what-if surfaces).\nMechanics, stated plainly (AV-R13):"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["Opening the view closes the workbook panel and renders the view ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "in place of the\nreport"
        }), ", under a small view header carrying the title and an explicit ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Back to\nreport"
        }), " action."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["The view is app component state, not a route: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "browser/hardware back exits the app"
        }), ",\nexactly as it does for the workbook panel today. In-app deep-linking to the view is\ndeferred to whatever routing story the app grows (§7) — not promised here."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: "A pure viewer who never opens the review door never sees any of it."
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-1-3",
      "data-slug": "13-mobile-value-8",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-1-3"
      }), "1.3 Mobile (value 8)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The view is prose + stacked cards + tables. v1 requirements (AV-R13): tables scroll in\ntheir own containers (the existing report-CSS discipline); ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "formula source blocks get\ntheir own horizontal-overflow containers"
      }), " (they are multi-line code, not prose); the\nformula index groups ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "per worksheet in native collapsible sections"
      }), " so an\nenumerate-everything render of a large workbook is navigable rather than one unbounded\npage; the door and Back are plain buttons, touch-complete. Nothing here is desktop-only."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-2",
      "data-slug": "2-the-reflection-components-normative-shipped-2026-08-28",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-2"
      }), "2. The reflection components  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative — shipped 2026-08-28)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Four additions to the closed catalog. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "The additive-only discipline applies with full\nforce"
      }), " (R-5's stdlib rule, shared by the catalog via versioning/compat): additions are\nforever, so the vocabulary is deliberately minimal, with enumerate-everything defaults\nand narrowly-typed filters; each addition passes the same anti-affordance scrutiny as\nany catalog change."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Component"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Attributes"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Renders"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "<FormulaIndex />"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "worksheet?: string"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Every cell (or the named worksheet's), grouped per worksheet in collapsible sections: name, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "doc"
            }), ", read-only formula source (own overflow container), computed verdict chip."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "<TestIndex />"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "worksheet?: string"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "subject?: string"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Every test (or the filtered set): kind label, subject, latest outcome (pass/fail + message)."
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "<DataInventory />"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "kind?: 'fixtures' | 'feeds'"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Fixtures: name, shape (§3.1's derivation), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "declared"
            }), " tier (§3.2), provenance note. Feeds: the §3.3 allowlist projection — never raw config."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "<SuiteSummary />"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "—"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["The panel's one-line suite report — same ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "summarizeSuite"
            }), ", same results object (§3.4)."]
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-2-1",
      "data-slug": "21-enumerate-everything-defaults",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-2-1"
      }), "2.1 Enumerate-everything defaults"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Filterless usage lists the whole document, live — so an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "unedited"
      }), " scaffold stays\ncomplete forever without regeneration. An author who explodes the view into hand-picked\nfiltered sections has chosen curation; the chrome remains the complete fallback."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-2-2",
      "data-slug": "22-degradation-not-silence",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-2-2"
      }), "2.2 Degradation, not silence"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["A filter naming a missing object (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "worksheet=\"modle\""
        }), ") renders the standard ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "broken\ntile"
        }), " with the reason — the no-silent-nulls discipline, at render time where the\nauthoring loop sees it."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["A reflection component rendered with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "no reflection port"
        }), " (§3) — including in a\nconsumer report, where the port is deliberately withheld (§6) — renders the broken\ntile stating the component is author's-view-only. Degrade, never crash."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-2-3",
      "data-slug": "23-computed-vs-authored-stays-visually-unmistakable-including-the-pending-state",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-2-3"
      }), "2.3 Computed vs authored stays visually unmistakable — including the pending state"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Verdict chips and kind labels render in the system's existing computed visual language;\nauthor prose renders as prose; templates cannot express chip styling (no attribute for\nit — the anti-affordance pattern). Two precision rules this pass added:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Pending is not a verdict (AV-R2)."
        }), " Suite results arrive asynchronously; before\nthey exist (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "verdicts: null"
        }), ", §3.4) chips render a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "distinct pending presentation"
        }), "\n(its own class and label, none of the four verdict states) and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "SuiteSummary"
        }), " renders\nthe panel's \"Running suites…\" line — never a false ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "untested"
        }), " count. The four-state\nchip vocabulary is reserved for computed verdicts, exactly as the workbook panel\nguards it."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "A declared tier is not computed chrome (AV-R5)"
        }), " — see §3.2."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-3",
      "data-slug": "3-the-reflection-port-normative-shipped-2026-08-28",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-3"
      }), "3. The reflection port  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative — shipped 2026-08-28)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Reflection components read a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "reflection port"
      }), " provided to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ReportView"
      }), " alongside the\nexisting ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "bindings"
      }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "inspection"
      }), " ports — the same optional-context pattern V3 uses:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-ts",
        children: "interface ReflectionPort {\n  cells(): readonly CellDescriptor[];      // id, worksheet, doc, formulaSource, deps\n  tests(): readonly TestDescriptor[];\n  /** The SAME suite-results object the review chrome renders (§3.4); null = pending. */\n  verdicts: ReadonlyMap<string, SubjectResult> | null;\n  fixtures: readonly FixtureSummary[];     // §3.1/§3.2 — derived, allowlisted\n  feeds: readonly FeedSummary[];           // §3.3 — allowlisted projection\n}\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Everything the port exposes is Class A — the document describing itself, already visible\nto anyone who can open the workbook panel — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "but Class-A reach is not the display rule"
      }), ";\nwhat may render ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "where"
      }), " is §6's product decision. The port is assembled app-side; it is\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "derived render-state, not a snapshot store"
      }), " (§3.4)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-3-1",
      "data-slug": "31-fixture-shape-is-derived-and-says-so-av-r4",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-3-1"
      }), "3.1 Fixture shape is derived, and says so (AV-R4)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "FixtureFile"
      }), " carries ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "rows"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "tier"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "provenance"
      }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "no column list or count exists in\nthe document model"
      }), ". The port derives, once per session (fixtures are load-time static):\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "rowCount = rows.length"
      }), "; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "columns"
      }), " = the keys of the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "first row"
      }), ", rendered with the\nqualifier \"first-row columns\" — an honest label for an O(1) derivation that can under-\ndescribe a heterogeneous fixture, rather than an unlabeled claim that can lie. (A full\nunion scan is rejected for v1 — unbounded cost on large pulled frames for a summary\nline.) These fields live in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "must-establish"
      }), ", not depends-on-today."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-3-2",
      "data-slug": "32-the-fixture-tier-is-authored-metadata-rendered-as-such-av-r5",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-3-2"
      }), "3.2 The fixture tier is authored metadata — rendered as such (AV-R5)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "FixtureFrame.tier"
      }), " is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "advisory display metadata the document's author wrote"
      }), "; the host\nmount tier is authoritative. The inventory therefore renders it as ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "plain labeled data\n(\"declared tier: static\")"
      }), " in the inspector's plain-text style (the review-1 H2\nprecedent: tier as data, never as a badge) — never in chip/chrome styling. Stamping an\nauthored trust claim with computed chrome would be the exact imitation §2.3 bans."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-3-3",
      "data-slug": "33-feeds-are-an-allowlist-projection-and-urls-are-stripped-av-r6",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-3-3"
      }), "3.3 Feeds are an allowlist projection, and URLs are stripped (AV-R6)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "FeedSummary"
      }), " is built ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["field by field — never a spread of ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "FeedConfig"
        })]
      }), ":\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "{ name, mode?, hosts }"
      }), ", where ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "hosts"
      }), " is derived per source entry as ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "scheme + host\nonly"
      }), " — path, query, and userinfo stripped, because real feed URLs routinely embed\ncredentials (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "?api_key=…"
      }), ", signed tokens) outside ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "auth.secretRef"
      }), ". An unparseable\nsource renders as \"unparseable source\", never raw. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "secretRef"
      }), " names are also excluded:\na name like ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "prod_stripe_key"
      }), " is not a secret but is reconnaissance about the user's\nsecret store, and the inventory has no need for it."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-3-4",
      "data-slug": "34-one-suite-computation-the-port-is-derived-state-av-r8",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-3-4"
      }), "3.4 One suite computation; the port is derived state (AV-R8)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The verdicts the port carries MUST be ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "the same results object"
      }), " the review chrome\nrenders — one ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "useVerdicts"
      }), " instance, owned at app level and passed down to the panel,\nthe inspector, and the port alike (\"the verdicts must not be computed twice per pass or\nthe two surfaces could disagree\" — the hook's own contract; the current\ndouble-instantiation in App and the panel is corrected by this work, not worsened). The\nport is assembled in render from current state and reassembles with it (tick / suite\ncompletion); its freshness property is \"always what the chrome shows\", not \"never\nstale\" — there is no independent snapshot to age."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-3-5",
      "data-slug": "35-session-shape-with-a-second-template-av-r14",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-3-5"
      }), "3.5 Session shape with a second template (AV-R14)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The session carries ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "two node trees"
      }), ": the consumer report's (as today) and the\nauthor's view's (from the document file, else the built-in scaffold). Each is validated\nagainst the catalog separately, with diagnostics attributed to its own file (the\nscaffold cannot fail validation — G-AV-8 gates that at build time). The cross-reference\nparams universe includes widget names from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "both"
      }), " trees, so a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "<Params>"
      }), " widget an\nauthor places in a custom author's view resolves rather than false-flagging. Bindings\nare pull-based (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "resolve(source)"
      }), " at render), so no subscription set changes."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-4",
      "data-slug": "4-template-selection-normative-shipped-2026-08-28",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-4"
      }), "4. Template selection  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative — shipped 2026-08-28)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["The reserved template name ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "authors_view"
          })
        }), " is the author's view by default; the\nmanifest may name a different one via an optional ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "authorsView"
          })
        }), " key (the one\nmanifest delta this spec proposes)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["The author's-view template is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "excluded from consumer-report selection"
        }), ". The\nconsumer pick keeps today's behavior otherwise (AV-R3): the template named ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "weekly"
        }), "\nif present, else the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "first non-authors-view"
        }), " template — no new report-naming key\nis proposed here (the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "weekly"
        }), " guess remains a wart, out of scope). A document whose\nonly template is an author's view renders the report empty-state, never the author's\nview."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-5",
      "data-slug": "5-the-scaffold-and-the-decisions-convention-normative-shipped-2026-08-28",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-5"
      }), "5. The scaffold and the Decisions convention  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative — shipped 2026-08-28)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-5-1",
      "data-slug": "51-the-scaffold",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-5-1"
      }), "5.1 The scaffold"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "The built-in default (also what a future \"customize\" materializes — the two are the\nsame document; the heading is static because templates have no interpolation and the\napp chrome already shows the document title, AV-R7):"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-mdx",
        children: "# Author's view.\n\n<SuiteSummary />\n\n## Decisions.\n\nNo decisions recorded yet — the workbook's why lives here: what was chosen, what was\nrejected, what the tests guard.\n\n## Formulas.\n\n<FormulaIndex />\n\n## Data.\n\n<DataInventory />\n\n## Tests.\n\n<TestIndex />\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-5-2",
      "data-slug": "52-decisions-where-the-thinking-survives",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-5-2"
      }), "5.2 Decisions — where the thinking survives"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "## Decisions."
      }), " section is the document-level home for the creators' reasoning —\nthe working culture's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "decisions & rejected alternatives"
      }), " discipline applied to workbook\ndocuments. Content boundaries, with their enforcement stated honestly (AV-R9):"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Decisions and assumptions, never transcripts."
        }), " What was inferred from, what shape\nwas rejected and why, what the holdout withholds, what each metamorphic relation\nguards. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The chat-log exclusion is a privacy boundary"
        }), " — chat may carry the user's\nprivate context, and this document is built to be shared and diffed — and it is\nenforced today only by prompt discipline plus the contribute gate's human full-diff\nreview, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "labeled as such, not presented as enforced"
        }), ". A mechanical backstop is an\nopen question (Q5), not a claim."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Why, never whether."
        }), " Coverage ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "claims"
        }), " belong to the computed chrome; the record\nexplains intent, the verdicts state fact. (Prose asserting \"fully tested\" beside a\nred chip misleads no one precisely because the chip is computed — §2.3.)"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Signed and dated by convention"
        }), " (\"recorded by the assistant, 2026-…\"). A\nlegibility convention, not provenance — the platform deliberately tracks no per-file\nauthorship."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-5-3",
      "data-slug": "53-the-agent-hook",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-5-3"
      }), "5.3 The agent hook"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "docs/assistant/FORMULA_AUTHORING_PROMPT.md"
      }), " gains a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "post-loop standing duty"
      }), " —\n\"record the decision\" — rather than a reordered loop step (the loop's ends are\nexplicitly fixed, AV-R10), and the prompt's scope note is widened by exactly one\nsentence: the Decisions record is the one template surface this prompt touches, until\nthe report-generation pipeline's own prompt (plan §8.4) exists and takes it over. The\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "fact"
      }), " of recording is documentation, so prompt-level is the honest mechanism; the\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "privacy boundary"
      }), " within it is labeled per §5.2. The E-6 agent-loop evaluation gains\n\"is the decision recorded, within the boundaries\" as a scored criterion when that\nharness runs."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-6",
      "data-slug": "6-where-reflection-may-render-the-product-decision-normative-shipped-2026-08-28-rewritten-per-av-r1",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-6"
      }), "6. Where reflection may render — the product decision  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative — shipped 2026-08-28; rewritten per AV-R1)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The draft's \"reflection components are legal in any template\" is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "withdrawn"
      }), ". The\nproduct definition promises the report viewer: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "\"open a link, see a live report, drill\ninto it, and never see a formula.\""
      }), " That sentence is about the consumer surface, and\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "<FormulaIndex />"
      }), " in a consumer template would put every cell's source in front of the\nviewers that promise covers. Class-A reach arguments do not decide this — reach bounds\nwhat a realm can ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "touch"
      }), ", not what the product ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "shows"
      }), " — and an author's ability to\nhand-paste formula text into prose (real, and unpreventable in any template system) is\nparity for ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "deliberate"
      }), " disclosure, not a reason to make wholesale disclosure one tag\naway."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The rule: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "reflection components render only in the author's-view template."
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Load time:"
        }), " a reflection component in any other template is a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "validation\ndiagnostic"
        }), " (warning — the document still loads)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Render time:"
        }), " the reflection port is provided ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "only"
        }), " to the author's-view\nrender; everywhere else the components hit the no-port path and render the\nauthor's-view-only broken tile (§2.2). The restriction is therefore structural, not\nadvisory."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "The rest of the trust story, unchanged from the draft:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "No enforcement of section presence — deliberate"
        }), " (owner decision 2026-08-28, §10).\nCompleteness is guaranteed where it is load-bearing: the panel and inspector render\nhost-computed verdicts over the full inventory, unsuppressible by any template."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Non-executable throughout."
        }), " The view is a template: safe-rendered, declarative, no\nexpression evaluation; prose is diff-visible at the contribute gate. Bounded-injection\nposture (TS-1) unchanged; no new channel."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The port is secret-free by construction"
        }), " (§3.3): allowlist projections, stripped\nhosts, no ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "secretRef"
        }), " names or values, gate-tested (G-AV-9)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-7",
      "data-slug": "7-out-of-scope-the-honest-remainder-normative-the-booked-remainder-nothing-here-shipped",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-7"
      }), "7. Out of scope — the honest remainder  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative — the booked remainder, nothing here shipped)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Materialize-on-customize"
        }), " (the button that writes the scaffold into ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "templates/"
        }), "):\nneeds the document write path (rw mount + editor flow, the navigator thread). Until\nthen, authors create the file by hand or via the editor."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "A file-include mechanism"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<Include file=\"…\"/>"
        }), "): needs bundle-relative\nresolution and cycle handling; deferred until composition pressure is real (owner:\ncomponents-only for v1)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Per-cell deep links"
        }), " from index rows into the editor ride the navigator work and\nR3-427 (spans), not this spec."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "In-app deep-linking / routing"
        }), " for the view (§1.2): follows the app's routing\nstory, which does not exist yet; the view is component state in v1."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Rendering in shared/anonymous-viewer deployments"
        }), " follows whatever the deployment\nshape decides for the workbook panel itself — the door gates the view, and §6 now\nguarantees the components cannot ride into the consumer report around that door."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-8",
      "data-slug": "8-gates-normative-the-falsifiable-exit-tests-shipped-2026-08-28",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-8"
      }), "8. Gates  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative — the falsifiable exit tests, shipped 2026-08-28)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Gate"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Test"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "G-AV-1"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "With no author's-view template, the default view renders from live state: the suite line, the Decisions heading, every cell, every fixture and feed, every test — no materialized file."
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "G-AV-2"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["A document's own ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "authors_view.mdx"
            }), " replaces the default entirely; a custom file omitting ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "<FormulaIndex />"
            }), " renders without the formula index (no enforcement), while the workbook panel still lists every cell."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "G-AV-3"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["The author's-view template is excluded from consumer-report selection: templates ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "[authors_view, weekly]"
            }), " serve ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "weekly"
            }), " as the report; a document with only an author's view renders the report empty-state, never the author's view."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "G-AV-4"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["The manifest's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "authorsView"
            }), " key selects a differently-named template as the author's view (and excludes it from consumer selection)."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "G-AV-5"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "<FormulaIndex worksheet=\"modle\" />"
            }), " (unknown filter) renders the broken tile with a reason — no crash, no silent empty list."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "G-AV-6"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Verdict chips render each computed verdict with its per-state class/label — the same four classes the workbook panel uses — driven by the same results object; a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "verdicts: null"
            }), " port renders a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "pending"
            }), " class/label that is none of the four, and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "SuiteSummary"
            }), " renders \"Running suites…\", never a verdict count (AV-R2/AV-R12)."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "G-AV-7"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "A reflection component rendered with no reflection port renders the author's-view-only broken tile — including when placed in a consumer template, which additionally raises a load-time validation warning (AV-R1)."
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "G-AV-8"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "The scaffold parses with zero template diagnostics and validates against the catalog."
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "G-AV-9"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "DataInventory"
            }), " renders fixture name / first-row columns / row count / declared tier (plain-labeled, not chip-styled) / provenance, and feed name/mode/host — and a feed whose source URL carries a query-string credential (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "?api_key=…"
            }), ") renders ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "without"
            }), " the query string, path, or userinfo; no ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "secretRef"
            }), " content appears (AV-R5/AV-R6)."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "G-AV-10"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["One suite computation: the port's verdicts are reference-identical to the results the workbook panel renders (the hoisted single ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "useVerdicts"
            }), "), asserted at the App wiring level (AV-R8)."]
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-9",
      "data-slug": "9-load-bearing-assumptions-code-anchors-required",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-9"
      }), "9. Load-bearing assumptions & code anchors  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(required)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "depends-on-today-verified-against-code",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "depends-on-today-verified-against-code"
      }), "Depends-on-today (verified against code)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Assumption"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Anchor (repo-relative file)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Token (grep-stable)"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "The catalog is a closed, typed schema list; unknown components render a placeholder"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/report/catalog.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "const COMPONENTS: ComponentSchema[]"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["The renderer dispatches by name over ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "componentMap"
            }), "; missing names → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "Placeholder"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/report/render/Renderer.tsx"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "componentMap[node.name]"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Optional ports flow through ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "ReportView"
            }), " as contexts (the V3 precedent)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/report/render/Renderer.tsx"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "InspectionContext.Provider"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Templates parse to a node model and validate against the catalog"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/report/validate.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "export function validateTemplate"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["The consumer template pick is name-guessed (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "weekly"
            }), ", else first) — §4 narrows its candidate set only"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/app/reportSession.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "name === 'weekly'"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Suite verdicts and the one-line summary are host-computed; a null result set renders a running state, not verdicts"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/app/WorkbookPanel.tsx"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "Running suites"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "The verdicts hook forbids double computation (\"only one of them\")"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/hooks/useVerdicts.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "re-runs the SAME"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Cell/test descriptors carry id, doc, formulaSource, deps (the index's data)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/engine/worker/protocol.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "formulaSource"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Fixture files carry rows/tier/provenance — and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "no"
            }), " column list or count (§3.1 derives)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/document/types.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "advisory display metadata"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Feed config's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "source"
            }), " is a raw URL string (why §3.3 strips)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/document/types.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "source"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "The workbook panel remains the complete, unsuppressible inventory"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/app/WorkbookPanel.tsx"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "WorkbookPanelBody"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "The authoring loop's ends are fixed (why §5.3 is post-loop)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "docs/assistant/FORMULA_AUTHORING_PROMPT.md"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "The authoring loop"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "The viewer promise §6 rests on"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "docs/product_definition.md"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "never see a formula"
            })
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "must-establish-new-invariants-the-implementation-creates",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "must-establish-new-invariants-the-implementation-creates"
      }), "Must-establish (new invariants the implementation creates)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "New invariant"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Proven by (gate test)"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "A reflection port assembled from live session state; verdicts single-sourced"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-AV-1, G-AV-10"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Fixture shape derived (first-row columns + rowCount), labeled as derived"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-AV-9"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "FeedSummary"
            }), " is an allowlist projection with stripped hosts"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-AV-9"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Default-when-absent / file-when-owned selection; manifest ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "authorsView"
            }), " honored"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-AV-1, G-AV-2, G-AV-4"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "The author's-view template never serves as the consumer report"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-AV-3"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Reflection components render only in the author's view (structural + diagnostic)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-AV-7"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Chips: four computed states + a distinct pending state, panel-identical classes"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-AV-6"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "The scaffold is valid against the catalog"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "G-AV-8"
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-10",
      "data-slug": "10-decisions-rejected-alternatives-normative-dont-relitigate",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-10"
      }), "10. Decisions & rejected alternatives  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(normative — don't relitigate)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "No enforcement that generated sections survive author editing"
        }), " (owner decision,\n2026-08-28). The author's view is a curated document; completeness lives in the\ncomputed chrome, which no template can suppress. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " an \"additive-only\"\nmechanism policing the author's own file — theater against a party who owns the tests\nthemselves."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Reflection components are author's-view-only (AV-R1)."
        }), " The product's viewer\npromise (\"never see a formula\") outranks the Class-A reach argument; the restriction\nis structural (port withheld) plus a load-time diagnostic. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " \"legal in any\ntemplate, no special-casing\" (the withdrawn draft position); prose-paste parity as a\njustification for one-tag wholesale disclosure."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Reflection components as the only mechanism — no annotation-fragment subsystem."
        }), "\nOne mechanism (templates + catalog) carries both inventory and narrative. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), "\na generated spine with keyed annotation fragments — a second content system with its\nown keying, orphan-validation, and staleness surface."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Default-when-absent, file-when-owned."
        }), " No boilerplate file in every document; the\nfile's existence means an author took ownership. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " pre-generating the file\ninto every document; regenerating over an authored file."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Enumerate-everything defaults; per-worksheet collapsible grouping."
        }), " An unedited\nscaffold stays complete without regeneration and stays navigable on a large workbook.\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " hand-enumerated scaffolds; one unbounded flat page."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "A minimal four-component vocabulary; a static scaffold heading (AV-R7)."
        }), " The\nadditive-forever discipline caps the surface; no interpolation mechanism and no fifth\ntitle component ride in — the app chrome already names the document. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), "\nper-object micro-components; a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "<DocTitle />"
        }), "; template interpolation."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "First-row column derivation, labeled (AV-R4)."
        }), " O(1), honest about its bound.\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " an unlabeled column claim; a full union scan (unbounded on large frames)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Declared fixture tier renders as plain labeled data (AV-R5)"
        }), " — the review-1 H2\nprecedent. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " chip-styling authored metadata."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Components-only; no ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "<Include>"
          })]
        }), " (owner lean, 2026-08-28). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected for v1:"
        }), "\nfile inclusion (bundle addressing + cycles)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The view opens from the workbook panel, renders in place of the report with an\nexplicit Back; no routing claims (AV-R13)."
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " a tab bar; implying\nbrowser-back or deep-link behavior the app cannot deliver yet."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-11",
      "data-slug": "11-adversarial-review-record",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-11"
      }), "11. Adversarial review  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(record)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Pass 1 (2026-08-28, fresh-agent), AV-R1…AV-R14 — all folded into this revision:"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "AV-R1 [BLOCKER]"
        }), " reflection legal in ungated consumer reports contradicted the\ndoor story and the product's \"never see a formula\" promise → §6 rewritten:\nauthor's-view-only, structural (port withheld) + diagnostic; decision recorded."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "AV-R2 [BLOCKER]"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "verdicts: null"
        }), " specified as an \"untested\"-style render — the\nfour-state mislabel the panel forbids — and contradicted G-AV-6 → §2.3/§3.4 distinct\npending state; SuiteSummary \"Running suites…\"; G-AV-6 rewritten."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "AV-R3 [MAJOR]"
        }), " \"manifest-named report template\" referenced a nonexistent key →\n§4 restated: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "weekly"
        }), " guess retained over non-authors-view candidates; no report key\nproposed."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "AV-R4 [MAJOR]"
        }), " fixture columns/rowCount filed as depends-on-today but exist\nnowhere → §3.1 derivation specified (first-row, labeled, O(1)); moved to\nmust-establish."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "AV-R5 [MAJOR]"
        }), " authored fixture tier stamped with computed chrome → §3.2 plain\nlabeled data, H2 precedent."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "AV-R6 [MAJOR]"
        }), " feed source URLs can embed credentials; G-AV-9 tested only\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "secretRef"
        }), " → §3.3 allowlist projection, scheme+host stripping, G-AV-9 extended."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "AV-R7 [MAJOR]"
        }), " scaffold ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "# <title>"
        }), " unimplementable (no interpolation, no title\nbinding) → static heading; default and materialized scaffold stay one document."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "AV-R8 [MAJOR]"
        }), " verdicts source unpinned against the hook's single-computation\ncontract (double instantiation already live); false \"never stale\" claim → §3.4\nhoisted single source, G-AV-10; freshness claim corrected."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "AV-R9 [MAJOR]"
        }), " the chat-log exclusion is a privacy boundary mislabeled as\nnon-safety → §5.2 split: prompt discipline labeled as such, human diff-gate named as\nthe backstop, mechanism booked (Q5)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "AV-R10 [MINOR]"
        }), " prompt delta violated the prompt's own scope note and fixed loop\nends → §5.3 post-loop standing duty + one-sentence scope widening."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "AV-R11 [MINOR]"
        }), " anchor token matched only a filename; R-5 cited as \"catalog\" risk\n→ token replaced; citation corrected to stdlib-rule-shared-via-versioning."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "AV-R12 [MINOR]"
        }), " \"visually distinct\" unfalsifiable → G-AV-6 restated over classes."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "AV-R13 [MINOR]"
        }), " mobile/door mechanics under-specified for code blocks and back\nbehavior → §1.2/§1.3 concretized (overflow containers, collapsible grouping, no\nrouting claims)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "AV-R14 [MINOR]"
        }), " second-template session threading unspecified → §3.5."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-12",
      "data-slug": "12-open-questions",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-12"
      }), "12. Open questions"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Q1"
        }), " — The \"customize\" affordance (materialize the scaffold): lands with the\ndocument write path; who owns the file-collision rule (a stray ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "authors_view.mdx"
        }), "\npresent but manifest-overridden)?"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Q2"
        }), " — Index-row deep links into the editor (file + line): compose with the\nnavigator work and R3-427 once spans exist."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Q3"
        }), " — Should the contribute/review surface render the author's-view ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "diff"
        }), "\nspecially (narrative beside formula/test diffs), or is the plain file diff enough?"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Q4"
        }), " — When the assistant realm lands: does record-the-decision create\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "authors_view.mdx"
        }), " (taking ownership on the author's behalf) or require it to exist?"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Q5"
        }), " — A mechanical backstop for the §5.2 privacy boundary (e.g., the contribute\ngate flagging transcript-shaped content in Decisions diffs) — worth its\nfalse-positive cost?"]
      }), "\n"]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/specs/AUTHORS_VIEW_SPEC.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJibG9ja3F1b3RlIiwiY29kZSIsImVtIiwiaDEiLCJoMiIsImgzIiwiaHIiLCJsaSIsInAiLCJwcmUiLCJzdHJvbmciLCJ0YWJsZSIsInRib2R5IiwidGQiLCJ0aCIsInRoZWFkIiwidHIiLCJ1bCIsIl9wcm92aWRlQ29tcG9uZW50cyIsImNvbXBvbmVudHMiLCJIZWFkaW5nQW5jaG9yIiwiX21pc3NpbmdNZHhSZWZlcmVuY2UiLCJqc3hzIiwiRnJhZ21lbnQiLCJjaGlsZHJlbiIsImlkIiwianN4IiwiY2xhc3NOYW1lIiwiTURYQ29udGVudCIsIndyYXBwZXIiLCJNRFhMYXlvdXQiLCJfYyIsImNvbXBvbmVudCIsInBsYWNlIiwiRXJyb3IiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBVVRIT1JTX1ZJRVdfU1BFQy5tZCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKkBqc3hSdW50aW1lIGF1dG9tYXRpYyovXG4vKkBqc3hJbXBvcnRTb3VyY2UgcmVhY3QqL1xuaW1wb3J0IHt1c2VNRFhDb21wb25lbnRzIGFzIF9wcm92aWRlQ29tcG9uZW50c30gZnJvbSBcIkBpbW1lZGlhdGVseS1ydW4vc2RrL01EWFByb3ZpZGVyXCI7XG5mdW5jdGlvbiBfY3JlYXRlTWR4Q29udGVudChwcm9wcykge1xuICBjb25zdCBfY29tcG9uZW50cyA9IHtcbiAgICBibG9ja3F1b3RlOiBcImJsb2NrcXVvdGVcIixcbiAgICBjb2RlOiBcImNvZGVcIixcbiAgICBlbTogXCJlbVwiLFxuICAgIGgxOiBcImgxXCIsXG4gICAgaDI6IFwiaDJcIixcbiAgICBoMzogXCJoM1wiLFxuICAgIGhyOiBcImhyXCIsXG4gICAgbGk6IFwibGlcIixcbiAgICBwOiBcInBcIixcbiAgICBwcmU6IFwicHJlXCIsXG4gICAgc3Ryb25nOiBcInN0cm9uZ1wiLFxuICAgIHRhYmxlOiBcInRhYmxlXCIsXG4gICAgdGJvZHk6IFwidGJvZHlcIixcbiAgICB0ZDogXCJ0ZFwiLFxuICAgIHRoOiBcInRoXCIsXG4gICAgdGhlYWQ6IFwidGhlYWRcIixcbiAgICB0cjogXCJ0clwiLFxuICAgIHVsOiBcInVsXCIsXG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9LCB7SGVhZGluZ0FuY2hvcn0gPSBfY29tcG9uZW50cztcbiAgaWYgKCFIZWFkaW5nQW5jaG9yKSBfbWlzc2luZ01keFJlZmVyZW5jZShcIkhlYWRpbmdBbmNob3JcIiwgdHJ1ZSk7XG4gIHJldHVybiA8PjxfY29tcG9uZW50cy5oMSBpZD1cInJlY2tvbmVyLWF1dGhvcnMtdmlldy10aGUtZG9jdW1lbnQtZGVzY3JpYmluZy1pdHNlbGYtYXMtYS10ZW1wbGF0ZS10aGUtYXV0aG9yLW93bnNcIj48SGVhZGluZ0FuY2hvciBpZD1cInJlY2tvbmVyLWF1dGhvcnMtdmlldy10aGUtZG9jdW1lbnQtZGVzY3JpYmluZy1pdHNlbGYtYXMtYS10ZW1wbGF0ZS10aGUtYXV0aG9yLW93bnNcIiAvPntcIlJlY2tvbmVyIEF1dGhvcidzIFZpZXcg4oCUIHRoZSBkb2N1bWVudCBkZXNjcmliaW5nIGl0c2VsZiwgYXMgYSB0ZW1wbGF0ZSB0aGUgYXV0aG9yIG93bnNcIn08L19jb21wb25lbnRzLmgxPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiU3RhdHVzOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBpbXBsZW1lbnRlZCBhdCB0aGUgZGVsaXZlcmFibGUgbGV2ZWwg4oCUIFIzLTQzNS9SMy00MzY7IG9uZSBhZHZlcnNhcmlhbCBwYXNzXFxuZm9sZGVkICjCpzExLCBBVi1SMeKAplIxNCk7IHJlc2lkdWFscyBsaXZlIGluIHRoZSBzdGF0dXMgZG9jLiDCtyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlVwZGF0ZWQ6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIDIwMjYtMDgtMjhcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLmVtPntcIihJbXBsZW1lbnRhdGlvbiBub3RlLCAyMDI2LTA4LTI4IOKAlCBhdXRob3JlZCwgYWR2ZXJzYXJpYWxseSByZXZpZXdlZCwgYW5kIGJ1aWx0IGluIHRoZVxcbnNhbWUgcGFzczogwqfCpzHigJM2IGFuZCB0aGUgwqc4IGdhdGVzIGFyZSBub3JtYXRpdmUgYW5kIHNoaXBwZWQ7IMKnNyBhbmQgwqcxMiByZW1haW4gdGhlXFxuaG9uZXN0IHJlbWFpbmRlci4gVGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcInByb3Bvc2FsXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBtYXJrZXJzIG9uIGJ1aWx0IHNlY3Rpb25zIHdlcmUgcmVjb25jaWxlZCBpbiB0aGlzXFxuZWRpdCwgcGVyIHNwZWNfc3R5bGUgXFxcImtlZXAgc3RhdHVzIGhvbmVzdFxcXCIuKVwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVGhlIHNpbmdsZSBpbXBsZW1lbnRhdGlvbi1zdGF0dXMgc291cmNlIGZvciB0aGlzIHNwZWMgaXNcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJkb2NzL3N0YXR1cy9BVVRIT1JTX1ZJRVdfU1RBVFVTLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgd2hlcmUgdGhpcyBkb2N1bWVudCBhbmQgdGhhdCBvbmUgZGlzYWdyZWUsIHRoZVxcbnN0YXR1cyBkb2MgZ292ZXJucy5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUmVhZHMgZmlyc3Q6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkFSQ0hJVEVDVFVSRV9QTEFOLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDCpzMuMyAodGhlIGNsb3NlZCBjb21wb25lbnQgY2F0YWxvZywgUlEtRjEsXFxuYW50aS1hZmZvcmRhbmNlcyksIMKnOCAodGhlIGFzc2lzdGFudCArIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkZPUk1VTEFfQVVUSE9SSU5HX1BST01QVFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLCBSLTUgKHRoZVxcbmFkZGl0aXZlLW9ubHkgZGlzY2lwbGluZSDigJQgc3RhdGVkIHRoZXJlIGZvciB0aGUgc3RkbGliOyB0aGUgY2F0YWxvZyBzaGFyZXMgaXQgdGhyb3VnaFxcbnRoZSB2ZXJzaW9uaW5nL2NvbXBhdCBzdG9yeSwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRE9DVU1FTlRfVkVSU0lPTklOR19TUEVDXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIik7IFwifTxfY29tcG9uZW50cy5jb2RlPntcInByb2R1Y3RfZGVmaW5pdGlvbi5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCInc1xcbnZpZXdlciBwcm9taXNlIChcXFwib3BlbiBhIGxpbmssIHNlZSBhIGxpdmUgcmVwb3J0IOKApiBhbmQgbmV2ZXIgc2VlIGEgZm9ybXVsYVxcXCIg4oCUIGxvYWQtYmVhcmluZ1xcbmZvciDCpzYpOyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJXSEFUSUZfU0hBRE9XX0VWQUxVQVRJT05fU1BFQy5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKHNpYmxpbmcgcmV2aWV3IHN1cmZhY2U7IHNoYXJlZFxcbnJ1bi1tb2RlLWZpcnN0IHBvc3R1cmUpOyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJSRVBPUlRJTkdfU1BSRUFEU0hFRVRfU1BFQy5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgwqczLjQgYW5kIHRoZSBwbGF0Zm9ybSdzXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiVFJVU1RfTU9ERVNfU1BFQ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgwqc1LjEgKG5vbi1leGVjdXRhYmxlIHRlbXBsYXRlcykuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTwvX2NvbXBvbmVudHMuYmxvY2txdW90ZT57XCJcXG5cIn08X2NvbXBvbmVudHMuaHIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtMFwiIGRhdGEtc2x1Zz1cIjAtY2hhcnRlci1ub3JtYXRpdmUtc2hpcHBlZC0yMDI2LTA4LTI4XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtMFwiIC8+e1wiMC4gQ2hhcnRlciAgXCJ9PF9jb21wb25lbnRzLmVtPntcIihub3JtYXRpdmUg4oCUIHNoaXBwZWQgMjAyNi0wOC0yOClcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiQSBSZWNrb25lciBkb2N1bWVudCdzIGNvbnN1bWVyIHJlcG9ydCBkZWxpYmVyYXRlbHkgc2hvd3MgXCJ9PF9jb21wb25lbnRzLmVtPntcInJlc3VsdHMsIG5vdCB3b3JraW5nc1wifTwvX2NvbXBvbmVudHMuZW0+e1wiLiBUaGVcXG53b3JraW5ncyDigJQgd2hhdCBmb3JtdWxhcyBleGlzdCwgd2hhdCB0ZXN0cyBjb3ZlciB0aGVtLCB3aGF0IGRhdGEgZmVlZHMgdGhlbSwgYW5kIHdoeSB0aGVcXG5tb2RlbCBpcyBzaGFwZWQgdGhlIHdheSBpdCBpcyDigJQgYXJlIGRpc2NvdmVyYWJsZSB0b2RheSBvbmx5IHRocm91Z2ggaW50ZXJhY3RpdmUgY2hyb21lXFxuKHRoZSB3b3JrYm9vayBwYW5lbCwgdGhlIGluc3BlY3Rvcikgb3IgYnkgcmVhZGluZyBzb3VyY2UgZmlsZXMuIFRoZXJlIGlzIG5vIFwifTxfY29tcG9uZW50cy5lbT57XCJkb2N1bWVudFwifTwvX2NvbXBvbmVudHMuZW0+e1wiXFxudGhhdCBwcmVzZW50cyB0aGUgZG9jdW1lbnQ6IG5vdGhpbmcgc2hhcmVhYmxlLCBkaWZmYWJsZSwgb3IgcmV2aWV3YWJsZSB0aGF0IHNheXMgXFxcImhlcmUgaXNcXG50aGlzIHdvcmtib29rLCBleHBsYWluZWQuXFxcIlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJhdXRob3IncyB2aWV3XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGlzIHRoYXQgZG9jdW1lbnQ6IGEgc2Vjb25kIHJlbmRlcmVkIHZpZXcgc3VtbWFyaXppbmcgZm9ybXVsYXMsIGRhdGFcXG50YWJsZXMsIGFuZCB0ZXN0IGFzc2V0cyDigJQgcGx1cywgb3B0aW9uYWxseSwgdGhlIGNyZWF0b3JzJyB0aGlua2luZy4gSXRzIHR3byBoYWx2ZXMgaGF2ZVxcbmRpZmZlcmVudCBvd25lcnM6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgaW52ZW50b3J5IGlzIGFwcGxpY2F0aW9uIHJlc3BvbnNpYmlsaXR5LlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBXaGF0IGV4aXN0cyBhbmQgaG93IHdlbGwgaXQgaXMgdGVzdGVkXFxuaXMgXCJ9PF9jb21wb25lbnRzLmVtPntcImNvbXB1dGVkXCJ9PC9fY29tcG9uZW50cy5lbT57XCIsIHJlbmRlcmVkIGJ5IG5ldyBjYXRhbG9nIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicmVmbGVjdGlvbiBjb21wb25lbnRzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICjCpzIpIHRoYXQgZW51bWVyYXRlXFxubGl2ZSBzdGF0ZSDigJQgbmV2ZXIgaGFuZC1saXN0ZWQsIHNvIGl0IGNhbm5vdCByb3Qgb3IgbGllIGFib3V0IGNvdmVyYWdlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVGhlIG5hcnJhdGl2ZSBpcyB0aGUgYXV0aG9yJ3MuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRoZSB2aWV3IGlzIGFuIG9yZGluYXJ5IHRlbXBsYXRlIGZpbGUgdGhlIGF1dGhvclxcbm93bnMgY29tcGxldGVseSDigJQgcmVvcmRlcmFibGUsIGFubm90YXRhYmxlLCBhbmQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJkZWxldGFibGUgaW4gcGFydCBvciB3aG9sZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIi4gVGhlcmVcXG5pcyBkZWxpYmVyYXRlbHkgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJubyBlbmZvcmNlbWVudFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB0aGF0IGFueSBnZW5lcmF0ZWQgc2VjdGlvbiByZW1haW5zICjCpzY7IG93bmVyXFxuZGVjaXNpb24sIMKnMTApOiB0aGUgdHJ1c3Qgc3VyZmFjZSBmb3IgY29tcGxldGVuZXNzIGlzIHRoZSBjb21wdXRlZCBjaHJvbWUgKHdvcmtib29rXFxucGFuZWwsIGluc3BlY3RvciksIHdoaWNoIHN0YXlzIHVuc3VwcHJlc3NpYmxlIHJlZ2FyZGxlc3Mgb2Ygd2hhdCBhbnkgdGVtcGxhdGUgc2F5cy4gQVxcbmRvY3VtZW50IGlzIGN1cmF0ZWQ7IHRoZSBjaHJvbWUgaXMgY29tcGxldGUuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIk5vIG5ldyByZWFsbSwgY2FwYWJpbGl0eSwgcHJpbmNpcGFsLCBzZXJ2aWNlLCBvciBnYXRlLiBPbmUgbmV3IHRlbXBsYXRlIHJvbGUsIGZvdXIgbmV3XFxuY2F0YWxvZyBjb21wb25lbnRzLCBvbmUgbmV3IHJlbmRlciBwb3J0LCBvbmUgbmV3IChvcHRpb25hbCkgbWFuaWZlc3Qga2V5LlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaHIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtMVwiIGRhdGEtc2x1Zz1cIjEtcHJvZHVjdC1zdXJmYWNlLW5vcm1hdGl2ZS1zaGlwcGVkLTIwMjYtMDgtMjhcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy0xXCIgLz57XCIxLiBQcm9kdWN0IHN1cmZhY2UgIFwifTxfY29tcG9uZW50cy5lbT57XCIobm9ybWF0aXZlIOKAlCBzaGlwcGVkIDIwMjYtMDgtMjgpXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cInNlYy0xLTFcIiBkYXRhLXNsdWc9XCIxMS1kZWZhdWx0LXdoZW4tYWJzZW50LWZpbGUtd2hlbi1vd25lZFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTEtMVwiIC8+e1wiMS4xIERlZmF1bHQgd2hlbiBhYnNlbnQ7IGZpbGUgd2hlbiBvd25lZFwifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJXaXRoIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibm9cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYXV0aG9yJ3MtdmlldyB0ZW1wbGF0ZSBpbiB0aGUgZG9jdW1lbnQsIHRoZSBhcHAgcmVuZGVycyBhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiYnVpbHQtaW5cXG5kZWZhdWx0IHZpZXdcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHRoZSBzY2FmZm9sZCwgwqc1LjEpIOKAlCBsaXZlLCBuZXZlciBtYXRlcmlhbGl6ZWQsIGNvbXBsZXRlIGJ5XFxuY29uc3RydWN0aW9uIGJlY2F1c2UgaXRzIGNvbXBvbmVudHMgZW51bWVyYXRlIGV2ZXJ5dGhpbmcgKMKnMi4xKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJXaGVuIHRoZSBkb2N1bWVudCBjYXJyaWVzIFwifTxfY29tcG9uZW50cy5jb2RlPntcInRlbXBsYXRlcy9hdXRob3JzX3ZpZXcubWR4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAob3IgdGhlIHRlbXBsYXRlIHRoZSBtYW5pZmVzdCdzXFxub3B0aW9uYWwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYXV0aG9yc1ZpZXdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGtleSBuYW1lcywgwqc0KSwgdGhhdCBmaWxlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiaXNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdGhlIGF1dGhvcidzIHZpZXcg4oCUIHJlcGxhY2luZ1xcbnRoZSBkZWZhdWx0IGVudGlyZWx5LiBDcmVhdGluZyB0aGUgZmlsZSBpcyBob3cgYW4gYXV0aG9yIHRha2VzIG93bmVyc2hpcDsgYVxcblxcXCJjdXN0b21pemVcXFwiIGFmZm9yZGFuY2UgdGhhdCBtYXRlcmlhbGl6ZXMgdGhlIHNjYWZmb2xkIGludG8gdGhlIGRvY3VtZW50IGlzIGJvb2tlZFxcbijCpzcpLCBwZW5kaW5nIHRoZSB3cml0ZSBwYXRoLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCJzZWMtMS0yXCIgZGF0YS1zbHVnPVwiMTItdGhlLWRvb3ItYW5kLXRoZS13YXktYmFja1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTEtMlwiIC8+e1wiMS4yIFRoZSBkb29yLCBhbmQgdGhlIHdheSBiYWNrXCJ9PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgYXV0aG9yJ3MgdmlldyBvcGVucyBmcm9tIHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIndvcmtib29rIHBhbmVsXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICh0aGUgZXhpc3RpbmcgYXV0aG9yLXNpZGUgZG9vcjtcXG5ydW4tbW9kZSByZXBvcnQgY2hyb21lIGlzIHVudG91Y2hlZCDigJQgdmFsdWUgMiwgc2FtZSBwb3N0dXJlIGFzIHRoZSB3aGF0LWlmIHN1cmZhY2VzKS5cXG5NZWNoYW5pY3MsIHN0YXRlZCBwbGFpbmx5IChBVi1SMTMpOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIk9wZW5pbmcgdGhlIHZpZXcgY2xvc2VzIHRoZSB3b3JrYm9vayBwYW5lbCBhbmQgcmVuZGVycyB0aGUgdmlldyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImluIHBsYWNlIG9mIHRoZVxcbnJlcG9ydFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgdW5kZXIgYSBzbWFsbCB2aWV3IGhlYWRlciBjYXJyeWluZyB0aGUgdGl0bGUgYW5kIGFuIGV4cGxpY2l0IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiQmFjayB0b1xcbnJlcG9ydFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBhY3Rpb24uXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiVGhlIHZpZXcgaXMgYXBwIGNvbXBvbmVudCBzdGF0ZSwgbm90IGEgcm91dGU6IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiYnJvd3Nlci9oYXJkd2FyZSBiYWNrIGV4aXRzIHRoZSBhcHBcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIsXFxuZXhhY3RseSBhcyBpdCBkb2VzIGZvciB0aGUgd29ya2Jvb2sgcGFuZWwgdG9kYXkuIEluLWFwcCBkZWVwLWxpbmtpbmcgdG8gdGhlIHZpZXcgaXNcXG5kZWZlcnJlZCB0byB3aGF0ZXZlciByb3V0aW5nIHN0b3J5IHRoZSBhcHAgZ3Jvd3MgKMKnNykg4oCUIG5vdCBwcm9taXNlZCBoZXJlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIkEgcHVyZSB2aWV3ZXIgd2hvIG5ldmVyIG9wZW5zIHRoZSByZXZpZXcgZG9vciBuZXZlciBzZWVzIGFueSBvZiBpdC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwic2VjLTEtM1wiIGRhdGEtc2x1Zz1cIjEzLW1vYmlsZS12YWx1ZS04XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtMS0zXCIgLz57XCIxLjMgTW9iaWxlICh2YWx1ZSA4KVwifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIHZpZXcgaXMgcHJvc2UgKyBzdGFja2VkIGNhcmRzICsgdGFibGVzLiB2MSByZXF1aXJlbWVudHMgKEFWLVIxMyk6IHRhYmxlcyBzY3JvbGwgaW5cXG50aGVpciBvd24gY29udGFpbmVycyAodGhlIGV4aXN0aW5nIHJlcG9ydC1DU1MgZGlzY2lwbGluZSk7IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZm9ybXVsYSBzb3VyY2UgYmxvY2tzIGdldFxcbnRoZWlyIG93biBob3Jpem9udGFsLW92ZXJmbG93IGNvbnRhaW5lcnNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHRoZXkgYXJlIG11bHRpLWxpbmUgY29kZSwgbm90IHByb3NlKTsgdGhlXFxuZm9ybXVsYSBpbmRleCBncm91cHMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJwZXIgd29ya3NoZWV0IGluIG5hdGl2ZSBjb2xsYXBzaWJsZSBzZWN0aW9uc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBzbyBhblxcbmVudW1lcmF0ZS1ldmVyeXRoaW5nIHJlbmRlciBvZiBhIGxhcmdlIHdvcmtib29rIGlzIG5hdmlnYWJsZSByYXRoZXIgdGhhbiBvbmUgdW5ib3VuZGVkXFxucGFnZTsgdGhlIGRvb3IgYW5kIEJhY2sgYXJlIHBsYWluIGJ1dHRvbnMsIHRvdWNoLWNvbXBsZXRlLiBOb3RoaW5nIGhlcmUgaXMgZGVza3RvcC1vbmx5LlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaHIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtMlwiIGRhdGEtc2x1Zz1cIjItdGhlLXJlZmxlY3Rpb24tY29tcG9uZW50cy1ub3JtYXRpdmUtc2hpcHBlZC0yMDI2LTA4LTI4XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtMlwiIC8+e1wiMi4gVGhlIHJlZmxlY3Rpb24gY29tcG9uZW50cyAgXCJ9PF9jb21wb25lbnRzLmVtPntcIihub3JtYXRpdmUg4oCUIHNoaXBwZWQgMjAyNi0wOC0yOClcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiRm91ciBhZGRpdGlvbnMgdG8gdGhlIGNsb3NlZCBjYXRhbG9nLiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlRoZSBhZGRpdGl2ZS1vbmx5IGRpc2NpcGxpbmUgYXBwbGllcyB3aXRoIGZ1bGxcXG5mb3JjZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoUi01J3Mgc3RkbGliIHJ1bGUsIHNoYXJlZCBieSB0aGUgY2F0YWxvZyB2aWEgdmVyc2lvbmluZy9jb21wYXQpOiBhZGRpdGlvbnMgYXJlXFxuZm9yZXZlciwgc28gdGhlIHZvY2FidWxhcnkgaXMgZGVsaWJlcmF0ZWx5IG1pbmltYWwsIHdpdGggZW51bWVyYXRlLWV2ZXJ5dGhpbmcgZGVmYXVsdHNcXG5hbmQgbmFycm93bHktdHlwZWQgZmlsdGVyczsgZWFjaCBhZGRpdGlvbiBwYXNzZXMgdGhlIHNhbWUgYW50aS1hZmZvcmRhbmNlIHNjcnV0aW55IGFzXFxuYW55IGNhdGFsb2cgY2hhbmdlLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudGFibGU+PF9jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGg+e1wiQ29tcG9uZW50XCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGg+e1wiQXR0cmlidXRlc1wifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIlJlbmRlcnNcIn08L19jb21wb25lbnRzLnRoPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudGJvZHk+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCI8Rm9ybXVsYUluZGV4IC8+XCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcIndvcmtzaGVldD86IHN0cmluZ1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJFdmVyeSBjZWxsIChvciB0aGUgbmFtZWQgd29ya3NoZWV0J3MpLCBncm91cGVkIHBlciB3b3Jrc2hlZXQgaW4gY29sbGFwc2libGUgc2VjdGlvbnM6IG5hbWUsIFwifTxfY29tcG9uZW50cy5jb2RlPntcImRvY1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIHJlYWQtb25seSBmb3JtdWxhIHNvdXJjZSAob3duIG92ZXJmbG93IGNvbnRhaW5lciksIGNvbXB1dGVkIHZlcmRpY3QgY2hpcC5cIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCI8VGVzdEluZGV4IC8+XCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcIndvcmtzaGVldD86IHN0cmluZ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcInN1YmplY3Q/OiBzdHJpbmdcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiRXZlcnkgdGVzdCAob3IgdGhlIGZpbHRlcmVkIHNldCk6IGtpbmQgbGFiZWwsIHN1YmplY3QsIGxhdGVzdCBvdXRjb21lIChwYXNzL2ZhaWwgKyBtZXNzYWdlKS5cIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCI8RGF0YUludmVudG9yeSAvPlwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJraW5kPzogJ2ZpeHR1cmVzJyB8ICdmZWVkcydcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiRml4dHVyZXM6IG5hbWUsIHNoYXBlICjCpzMuMSdzIGRlcml2YXRpb24pLCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImRlY2xhcmVkXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHRpZXIgKMKnMy4yKSwgcHJvdmVuYW5jZSBub3RlLiBGZWVkczogdGhlIMKnMy4zIGFsbG93bGlzdCBwcm9qZWN0aW9uIOKAlCBuZXZlciByYXcgY29uZmlnLlwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcIjxTdWl0ZVN1bW1hcnkgLz5cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wi4oCUXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiVGhlIHBhbmVsJ3Mgb25lLWxpbmUgc3VpdGUgcmVwb3J0IOKAlCBzYW1lIFwifTxfY29tcG9uZW50cy5jb2RlPntcInN1bW1hcml6ZVN1aXRlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgc2FtZSByZXN1bHRzIG9iamVjdCAowqczLjQpLlwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRib2R5PjwvX2NvbXBvbmVudHMudGFibGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwic2VjLTItMVwiIGRhdGEtc2x1Zz1cIjIxLWVudW1lcmF0ZS1ldmVyeXRoaW5nLWRlZmF1bHRzXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtMi0xXCIgLz57XCIyLjEgRW51bWVyYXRlLWV2ZXJ5dGhpbmcgZGVmYXVsdHNcIn08L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkZpbHRlcmxlc3MgdXNhZ2UgbGlzdHMgdGhlIHdob2xlIGRvY3VtZW50LCBsaXZlIOKAlCBzbyBhbiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInVuZWRpdGVkXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHNjYWZmb2xkIHN0YXlzXFxuY29tcGxldGUgZm9yZXZlciB3aXRob3V0IHJlZ2VuZXJhdGlvbi4gQW4gYXV0aG9yIHdobyBleHBsb2RlcyB0aGUgdmlldyBpbnRvIGhhbmQtcGlja2VkXFxuZmlsdGVyZWQgc2VjdGlvbnMgaGFzIGNob3NlbiBjdXJhdGlvbjsgdGhlIGNocm9tZSByZW1haW5zIHRoZSBjb21wbGV0ZSBmYWxsYmFjay5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwic2VjLTItMlwiIGRhdGEtc2x1Zz1cIjIyLWRlZ3JhZGF0aW9uLW5vdC1zaWxlbmNlXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtMi0yXCIgLz57XCIyLjIgRGVncmFkYXRpb24sIG5vdCBzaWxlbmNlXCJ9PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIkEgZmlsdGVyIG5hbWluZyBhIG1pc3Npbmcgb2JqZWN0IChcIn08X2NvbXBvbmVudHMuY29kZT57XCJ3b3Jrc2hlZXQ9XFxcIm1vZGxlXFxcIlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpIHJlbmRlcnMgdGhlIHN0YW5kYXJkIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiYnJva2VuXFxudGlsZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB3aXRoIHRoZSByZWFzb24g4oCUIHRoZSBuby1zaWxlbnQtbnVsbHMgZGlzY2lwbGluZSwgYXQgcmVuZGVyIHRpbWUgd2hlcmUgdGhlXFxuYXV0aG9yaW5nIGxvb3Agc2VlcyBpdC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJBIHJlZmxlY3Rpb24gY29tcG9uZW50IHJlbmRlcmVkIHdpdGggXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJubyByZWZsZWN0aW9uIHBvcnRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKMKnMykg4oCUIGluY2x1ZGluZyBpbiBhXFxuY29uc3VtZXIgcmVwb3J0LCB3aGVyZSB0aGUgcG9ydCBpcyBkZWxpYmVyYXRlbHkgd2l0aGhlbGQgKMKnNikg4oCUIHJlbmRlcnMgdGhlIGJyb2tlblxcbnRpbGUgc3RhdGluZyB0aGUgY29tcG9uZW50IGlzIGF1dGhvcidzLXZpZXctb25seS4gRGVncmFkZSwgbmV2ZXIgY3Jhc2guXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cInNlYy0yLTNcIiBkYXRhLXNsdWc9XCIyMy1jb21wdXRlZC12cy1hdXRob3JlZC1zdGF5cy12aXN1YWxseS11bm1pc3Rha2FibGUtaW5jbHVkaW5nLXRoZS1wZW5kaW5nLXN0YXRlXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtMi0zXCIgLz57XCIyLjMgQ29tcHV0ZWQgdnMgYXV0aG9yZWQgc3RheXMgdmlzdWFsbHkgdW5taXN0YWthYmxlIOKAlCBpbmNsdWRpbmcgdGhlIHBlbmRpbmcgc3RhdGVcIn08L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlZlcmRpY3QgY2hpcHMgYW5kIGtpbmQgbGFiZWxzIHJlbmRlciBpbiB0aGUgc3lzdGVtJ3MgZXhpc3RpbmcgY29tcHV0ZWQgdmlzdWFsIGxhbmd1YWdlO1xcbmF1dGhvciBwcm9zZSByZW5kZXJzIGFzIHByb3NlOyB0ZW1wbGF0ZXMgY2Fubm90IGV4cHJlc3MgY2hpcCBzdHlsaW5nIChubyBhdHRyaWJ1dGUgZm9yXFxuaXQg4oCUIHRoZSBhbnRpLWFmZm9yZGFuY2UgcGF0dGVybikuIFR3byBwcmVjaXNpb24gcnVsZXMgdGhpcyBwYXNzIGFkZGVkOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUGVuZGluZyBpcyBub3QgYSB2ZXJkaWN0IChBVi1SMikuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFN1aXRlIHJlc3VsdHMgYXJyaXZlIGFzeW5jaHJvbm91c2x5OyBiZWZvcmVcXG50aGV5IGV4aXN0IChcIn08X2NvbXBvbmVudHMuY29kZT57XCJ2ZXJkaWN0czogbnVsbFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIMKnMy40KSBjaGlwcyByZW5kZXIgYSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImRpc3RpbmN0IHBlbmRpbmcgcHJlc2VudGF0aW9uXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiXFxuKGl0cyBvd24gY2xhc3MgYW5kIGxhYmVsLCBub25lIG9mIHRoZSBmb3VyIHZlcmRpY3Qgc3RhdGVzKSBhbmQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiU3VpdGVTdW1tYXJ5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiByZW5kZXJzXFxudGhlIHBhbmVsJ3MgXFxcIlJ1bm5pbmcgc3VpdGVz4oCmXFxcIiBsaW5lIOKAlCBuZXZlciBhIGZhbHNlIFwifTxfY29tcG9uZW50cy5jb2RlPntcInVudGVzdGVkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjb3VudC4gVGhlIGZvdXItc3RhdGVcXG5jaGlwIHZvY2FidWxhcnkgaXMgcmVzZXJ2ZWQgZm9yIGNvbXB1dGVkIHZlcmRpY3RzLCBleGFjdGx5IGFzIHRoZSB3b3JrYm9vayBwYW5lbFxcbmd1YXJkcyBpdC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkEgZGVjbGFyZWQgdGllciBpcyBub3QgY29tcHV0ZWQgY2hyb21lIChBVi1SNSlcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHNlZSDCpzMuMi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmhyIC8+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTNcIiBkYXRhLXNsdWc9XCIzLXRoZS1yZWZsZWN0aW9uLXBvcnQtbm9ybWF0aXZlLXNoaXBwZWQtMjAyNi0wOC0yOFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTNcIiAvPntcIjMuIFRoZSByZWZsZWN0aW9uIHBvcnQgIFwifTxfY29tcG9uZW50cy5lbT57XCIobm9ybWF0aXZlIOKAlCBzaGlwcGVkIDIwMjYtMDgtMjgpXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlJlZmxlY3Rpb24gY29tcG9uZW50cyByZWFkIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJyZWZsZWN0aW9uIHBvcnRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgcHJvdmlkZWQgdG8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiUmVwb3J0Vmlld1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYWxvbmdzaWRlIHRoZVxcbmV4aXN0aW5nIFwifTxfY29tcG9uZW50cy5jb2RlPntcImJpbmRpbmdzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJpbnNwZWN0aW9uXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBwb3J0cyDigJQgdGhlIHNhbWUgb3B0aW9uYWwtY29udGV4dCBwYXR0ZXJuIFYzIHVzZXM6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wcmU+PF9jb21wb25lbnRzLmNvZGUgY2xhc3NOYW1lPVwibGFuZ3VhZ2UtdHNcIj57XCJpbnRlcmZhY2UgUmVmbGVjdGlvblBvcnQge1xcbiAgY2VsbHMoKTogcmVhZG9ubHkgQ2VsbERlc2NyaXB0b3JbXTsgICAgICAvLyBpZCwgd29ya3NoZWV0LCBkb2MsIGZvcm11bGFTb3VyY2UsIGRlcHNcXG4gIHRlc3RzKCk6IHJlYWRvbmx5IFRlc3REZXNjcmlwdG9yW107XFxuICAvKiogVGhlIFNBTUUgc3VpdGUtcmVzdWx0cyBvYmplY3QgdGhlIHJldmlldyBjaHJvbWUgcmVuZGVycyAowqczLjQpOyBudWxsID0gcGVuZGluZy4gKi9cXG4gIHZlcmRpY3RzOiBSZWFkb25seU1hcDxzdHJpbmcsIFN1YmplY3RSZXN1bHQ+IHwgbnVsbDtcXG4gIGZpeHR1cmVzOiByZWFkb25seSBGaXh0dXJlU3VtbWFyeVtdOyAgICAgLy8gwqczLjEvwqczLjIg4oCUIGRlcml2ZWQsIGFsbG93bGlzdGVkXFxuICBmZWVkczogcmVhZG9ubHkgRmVlZFN1bW1hcnlbXTsgICAgICAgICAgIC8vIMKnMy4zIOKAlCBhbGxvd2xpc3RlZCBwcm9qZWN0aW9uXFxufVxcblwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnByZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJFdmVyeXRoaW5nIHRoZSBwb3J0IGV4cG9zZXMgaXMgQ2xhc3MgQSDigJQgdGhlIGRvY3VtZW50IGRlc2NyaWJpbmcgaXRzZWxmLCBhbHJlYWR5IHZpc2libGVcXG50byBhbnlvbmUgd2hvIGNhbiBvcGVuIHRoZSB3b3JrYm9vayBwYW5lbCDigJQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJidXQgQ2xhc3MtQSByZWFjaCBpcyBub3QgdGhlIGRpc3BsYXkgcnVsZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIjtcXG53aGF0IG1heSByZW5kZXIgXCJ9PF9jb21wb25lbnRzLmVtPntcIndoZXJlXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgaXMgwqc2J3MgcHJvZHVjdCBkZWNpc2lvbi4gVGhlIHBvcnQgaXMgYXNzZW1ibGVkIGFwcC1zaWRlOyBpdCBpc1xcblwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZGVyaXZlZCByZW5kZXItc3RhdGUsIG5vdCBhIHNuYXBzaG90IHN0b3JlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICjCpzMuNCkuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cInNlYy0zLTFcIiBkYXRhLXNsdWc9XCIzMS1maXh0dXJlLXNoYXBlLWlzLWRlcml2ZWQtYW5kLXNheXMtc28tYXYtcjRcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy0zLTFcIiAvPntcIjMuMSBGaXh0dXJlIHNoYXBlIGlzIGRlcml2ZWQsIGFuZCBzYXlzIHNvIChBVi1SNClcIn08L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5jb2RlPntcIkZpeHR1cmVGaWxlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjYXJyaWVzIFwifTxfY29tcG9uZW50cy5jb2RlPntcInJvd3NcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ0aWVyXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicHJvdmVuYW5jZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibm8gY29sdW1uIGxpc3Qgb3IgY291bnQgZXhpc3RzIGluXFxudGhlIGRvY3VtZW50IG1vZGVsXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLiBUaGUgcG9ydCBkZXJpdmVzLCBvbmNlIHBlciBzZXNzaW9uIChmaXh0dXJlcyBhcmUgbG9hZC10aW1lIHN0YXRpYyk6XFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicm93Q291bnQgPSByb3dzLmxlbmd0aFwifTwvX2NvbXBvbmVudHMuY29kZT57XCI7IFwifTxfY29tcG9uZW50cy5jb2RlPntcImNvbHVtbnNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiID0gdGhlIGtleXMgb2YgdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZmlyc3Qgcm93XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCByZW5kZXJlZCB3aXRoIHRoZVxcbnF1YWxpZmllciBcXFwiZmlyc3Qtcm93IGNvbHVtbnNcXFwiIOKAlCBhbiBob25lc3QgbGFiZWwgZm9yIGFuIE8oMSkgZGVyaXZhdGlvbiB0aGF0IGNhbiB1bmRlci1cXG5kZXNjcmliZSBhIGhldGVyb2dlbmVvdXMgZml4dHVyZSwgcmF0aGVyIHRoYW4gYW4gdW5sYWJlbGVkIGNsYWltIHRoYXQgY2FuIGxpZS4gKEEgZnVsbFxcbnVuaW9uIHNjYW4gaXMgcmVqZWN0ZWQgZm9yIHYxIOKAlCB1bmJvdW5kZWQgY29zdCBvbiBsYXJnZSBwdWxsZWQgZnJhbWVzIGZvciBhIHN1bW1hcnlcXG5saW5lLikgVGhlc2UgZmllbGRzIGxpdmUgaW4gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJtdXN0LWVzdGFibGlzaFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgbm90IGRlcGVuZHMtb24tdG9kYXkuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cInNlYy0zLTJcIiBkYXRhLXNsdWc9XCIzMi10aGUtZml4dHVyZS10aWVyLWlzLWF1dGhvcmVkLW1ldGFkYXRhLXJlbmRlcmVkLWFzLXN1Y2gtYXYtcjVcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy0zLTJcIiAvPntcIjMuMiBUaGUgZml4dHVyZSB0aWVyIGlzIGF1dGhvcmVkIG1ldGFkYXRhIOKAlCByZW5kZXJlZCBhcyBzdWNoIChBVi1SNSlcIn08L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5jb2RlPntcIkZpeHR1cmVGcmFtZS50aWVyXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpcyBcIn08X2NvbXBvbmVudHMuZW0+e1wiYWR2aXNvcnkgZGlzcGxheSBtZXRhZGF0YSB0aGUgZG9jdW1lbnQncyBhdXRob3Igd3JvdGVcIn08L19jb21wb25lbnRzLmVtPntcIjsgdGhlIGhvc3RcXG5tb3VudCB0aWVyIGlzIGF1dGhvcml0YXRpdmUuIFRoZSBpbnZlbnRvcnkgdGhlcmVmb3JlIHJlbmRlcnMgaXQgYXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJwbGFpbiBsYWJlbGVkIGRhdGFcXG4oXFxcImRlY2xhcmVkIHRpZXI6IHN0YXRpY1xcXCIpXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGluIHRoZSBpbnNwZWN0b3IncyBwbGFpbi10ZXh0IHN0eWxlICh0aGUgcmV2aWV3LTEgSDJcXG5wcmVjZWRlbnQ6IHRpZXIgYXMgZGF0YSwgbmV2ZXIgYXMgYSBiYWRnZSkg4oCUIG5ldmVyIGluIGNoaXAvY2hyb21lIHN0eWxpbmcuIFN0YW1waW5nIGFuXFxuYXV0aG9yZWQgdHJ1c3QgY2xhaW0gd2l0aCBjb21wdXRlZCBjaHJvbWUgd291bGQgYmUgdGhlIGV4YWN0IGltaXRhdGlvbiDCpzIuMyBiYW5zLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCJzZWMtMy0zXCIgZGF0YS1zbHVnPVwiMzMtZmVlZHMtYXJlLWFuLWFsbG93bGlzdC1wcm9qZWN0aW9uLWFuZC11cmxzLWFyZS1zdHJpcHBlZC1hdi1yNlwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTMtM1wiIC8+e1wiMy4zIEZlZWRzIGFyZSBhbiBhbGxvd2xpc3QgcHJvamVjdGlvbiwgYW5kIFVSTHMgYXJlIHN0cmlwcGVkIChBVi1SNilcIn08L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5jb2RlPntcIkZlZWRTdW1tYXJ5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpcyBidWlsdCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImZpZWxkIGJ5IGZpZWxkIOKAlCBuZXZlciBhIHNwcmVhZCBvZiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJGZWVkQ29uZmlnXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIjpcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJ7IG5hbWUsIG1vZGU/LCBob3N0cyB9XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgd2hlcmUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaG9zdHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGlzIGRlcml2ZWQgcGVyIHNvdXJjZSBlbnRyeSBhcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInNjaGVtZSArIGhvc3RcXG5vbmx5XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBwYXRoLCBxdWVyeSwgYW5kIHVzZXJpbmZvIHN0cmlwcGVkLCBiZWNhdXNlIHJlYWwgZmVlZCBVUkxzIHJvdXRpbmVseSBlbWJlZFxcbmNyZWRlbnRpYWxzIChcIn08X2NvbXBvbmVudHMuY29kZT57XCI/YXBpX2tleT3igKZcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBzaWduZWQgdG9rZW5zKSBvdXRzaWRlIFwifTxfY29tcG9uZW50cy5jb2RlPntcImF1dGguc2VjcmV0UmVmXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi4gQW4gdW5wYXJzZWFibGVcXG5zb3VyY2UgcmVuZGVycyBhcyBcXFwidW5wYXJzZWFibGUgc291cmNlXFxcIiwgbmV2ZXIgcmF3LiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzZWNyZXRSZWZcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG5hbWVzIGFyZSBhbHNvIGV4Y2x1ZGVkOlxcbmEgbmFtZSBsaWtlIFwifTxfY29tcG9uZW50cy5jb2RlPntcInByb2Rfc3RyaXBlX2tleVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaXMgbm90IGEgc2VjcmV0IGJ1dCBpcyByZWNvbm5haXNzYW5jZSBhYm91dCB0aGUgdXNlcidzXFxuc2VjcmV0IHN0b3JlLCBhbmQgdGhlIGludmVudG9yeSBoYXMgbm8gbmVlZCBmb3IgaXQuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cInNlYy0zLTRcIiBkYXRhLXNsdWc9XCIzNC1vbmUtc3VpdGUtY29tcHV0YXRpb24tdGhlLXBvcnQtaXMtZGVyaXZlZC1zdGF0ZS1hdi1yOFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTMtNFwiIC8+e1wiMy40IE9uZSBzdWl0ZSBjb21wdXRhdGlvbjsgdGhlIHBvcnQgaXMgZGVyaXZlZCBzdGF0ZSAoQVYtUjgpXCJ9PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgdmVyZGljdHMgdGhlIHBvcnQgY2FycmllcyBNVVNUIGJlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1widGhlIHNhbWUgcmVzdWx0cyBvYmplY3RcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdGhlIHJldmlldyBjaHJvbWVcXG5yZW5kZXJzIOKAlCBvbmUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widXNlVmVyZGljdHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGluc3RhbmNlLCBvd25lZCBhdCBhcHAgbGV2ZWwgYW5kIHBhc3NlZCBkb3duIHRvIHRoZSBwYW5lbCxcXG50aGUgaW5zcGVjdG9yLCBhbmQgdGhlIHBvcnQgYWxpa2UgKFxcXCJ0aGUgdmVyZGljdHMgbXVzdCBub3QgYmUgY29tcHV0ZWQgdHdpY2UgcGVyIHBhc3Mgb3JcXG50aGUgdHdvIHN1cmZhY2VzIGNvdWxkIGRpc2FncmVlXFxcIiDigJQgdGhlIGhvb2sncyBvd24gY29udHJhY3Q7IHRoZSBjdXJyZW50XFxuZG91YmxlLWluc3RhbnRpYXRpb24gaW4gQXBwIGFuZCB0aGUgcGFuZWwgaXMgY29ycmVjdGVkIGJ5IHRoaXMgd29yaywgbm90IHdvcnNlbmVkKS4gVGhlXFxucG9ydCBpcyBhc3NlbWJsZWQgaW4gcmVuZGVyIGZyb20gY3VycmVudCBzdGF0ZSBhbmQgcmVhc3NlbWJsZXMgd2l0aCBpdCAodGljayAvIHN1aXRlXFxuY29tcGxldGlvbik7IGl0cyBmcmVzaG5lc3MgcHJvcGVydHkgaXMgXFxcImFsd2F5cyB3aGF0IHRoZSBjaHJvbWUgc2hvd3NcXFwiLCBub3QgXFxcIm5ldmVyXFxuc3RhbGVcXFwiIOKAlCB0aGVyZSBpcyBubyBpbmRlcGVuZGVudCBzbmFwc2hvdCB0byBhZ2UuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cInNlYy0zLTVcIiBkYXRhLXNsdWc9XCIzNS1zZXNzaW9uLXNoYXBlLXdpdGgtYS1zZWNvbmQtdGVtcGxhdGUtYXYtcjE0XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtMy01XCIgLz57XCIzLjUgU2Vzc2lvbiBzaGFwZSB3aXRoIGEgc2Vjb25kIHRlbXBsYXRlIChBVi1SMTQpXCJ9PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgc2Vzc2lvbiBjYXJyaWVzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1widHdvIG5vZGUgdHJlZXNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCI6IHRoZSBjb25zdW1lciByZXBvcnQncyAoYXMgdG9kYXkpIGFuZCB0aGVcXG5hdXRob3IncyB2aWV3J3MgKGZyb20gdGhlIGRvY3VtZW50IGZpbGUsIGVsc2UgdGhlIGJ1aWx0LWluIHNjYWZmb2xkKS4gRWFjaCBpcyB2YWxpZGF0ZWRcXG5hZ2FpbnN0IHRoZSBjYXRhbG9nIHNlcGFyYXRlbHksIHdpdGggZGlhZ25vc3RpY3MgYXR0cmlidXRlZCB0byBpdHMgb3duIGZpbGUgKHRoZVxcbnNjYWZmb2xkIGNhbm5vdCBmYWlsIHZhbGlkYXRpb24g4oCUIEctQVYtOCBnYXRlcyB0aGF0IGF0IGJ1aWxkIHRpbWUpLiBUaGUgY3Jvc3MtcmVmZXJlbmNlXFxucGFyYW1zIHVuaXZlcnNlIGluY2x1ZGVzIHdpZGdldCBuYW1lcyBmcm9tIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiYm90aFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB0cmVlcywgc28gYSBcIn08X2NvbXBvbmVudHMuY29kZT57XCI8UGFyYW1zPlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgd2lkZ2V0IGFuXFxuYXV0aG9yIHBsYWNlcyBpbiBhIGN1c3RvbSBhdXRob3IncyB2aWV3IHJlc29sdmVzIHJhdGhlciB0aGFuIGZhbHNlLWZsYWdnaW5nLiBCaW5kaW5nc1xcbmFyZSBwdWxsLWJhc2VkIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJyZXNvbHZlKHNvdXJjZSlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGF0IHJlbmRlciksIHNvIG5vIHN1YnNjcmlwdGlvbiBzZXQgY2hhbmdlcy5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmhyIC8+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTRcIiBkYXRhLXNsdWc9XCI0LXRlbXBsYXRlLXNlbGVjdGlvbi1ub3JtYXRpdmUtc2hpcHBlZC0yMDI2LTA4LTI4XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtNFwiIC8+e1wiNC4gVGVtcGxhdGUgc2VsZWN0aW9uICBcIn08X2NvbXBvbmVudHMuZW0+e1wiKG5vcm1hdGl2ZSDigJQgc2hpcHBlZCAyMDI2LTA4LTI4KVwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIlRoZSByZXNlcnZlZCB0ZW1wbGF0ZSBuYW1lIFwifTxfY29tcG9uZW50cy5zdHJvbmc+PF9jb21wb25lbnRzLmNvZGU+e1wiYXV0aG9yc192aWV3XCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBpcyB0aGUgYXV0aG9yJ3MgdmlldyBieSBkZWZhdWx0OyB0aGVcXG5tYW5pZmVzdCBtYXkgbmFtZSBhIGRpZmZlcmVudCBvbmUgdmlhIGFuIG9wdGlvbmFsIFwifTxfY29tcG9uZW50cy5zdHJvbmc+PF9jb21wb25lbnRzLmNvZGU+e1wiYXV0aG9yc1ZpZXdcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGtleSAodGhlIG9uZVxcbm1hbmlmZXN0IGRlbHRhIHRoaXMgc3BlYyBwcm9wb3NlcykuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiVGhlIGF1dGhvcidzLXZpZXcgdGVtcGxhdGUgaXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJleGNsdWRlZCBmcm9tIGNvbnN1bWVyLXJlcG9ydCBzZWxlY3Rpb25cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIuIFRoZVxcbmNvbnN1bWVyIHBpY2sga2VlcHMgdG9kYXkncyBiZWhhdmlvciBvdGhlcndpc2UgKEFWLVIzKTogdGhlIHRlbXBsYXRlIG5hbWVkIFwifTxfY29tcG9uZW50cy5jb2RlPntcIndlZWtseVwifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG5pZiBwcmVzZW50LCBlbHNlIHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImZpcnN0IG5vbi1hdXRob3JzLXZpZXdcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdGVtcGxhdGUg4oCUIG5vIG5ldyByZXBvcnQtbmFtaW5nIGtleVxcbmlzIHByb3Bvc2VkIGhlcmUgKHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ3ZWVrbHlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGd1ZXNzIHJlbWFpbnMgYSB3YXJ0LCBvdXQgb2Ygc2NvcGUpLiBBIGRvY3VtZW50IHdob3NlXFxub25seSB0ZW1wbGF0ZSBpcyBhbiBhdXRob3IncyB2aWV3IHJlbmRlcnMgdGhlIHJlcG9ydCBlbXB0eS1zdGF0ZSwgbmV2ZXIgdGhlIGF1dGhvcidzXFxudmlldy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmhyIC8+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTVcIiBkYXRhLXNsdWc9XCI1LXRoZS1zY2FmZm9sZC1hbmQtdGhlLWRlY2lzaW9ucy1jb252ZW50aW9uLW5vcm1hdGl2ZS1zaGlwcGVkLTIwMjYtMDgtMjhcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy01XCIgLz57XCI1LiBUaGUgc2NhZmZvbGQgYW5kIHRoZSBEZWNpc2lvbnMgY29udmVudGlvbiAgXCJ9PF9jb21wb25lbnRzLmVtPntcIihub3JtYXRpdmUg4oCUIHNoaXBwZWQgMjAyNi0wOC0yOClcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwic2VjLTUtMVwiIGRhdGEtc2x1Zz1cIjUxLXRoZS1zY2FmZm9sZFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTUtMVwiIC8+e1wiNS4xIFRoZSBzY2FmZm9sZFwifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIGJ1aWx0LWluIGRlZmF1bHQgKGFsc28gd2hhdCBhIGZ1dHVyZSBcXFwiY3VzdG9taXplXFxcIiBtYXRlcmlhbGl6ZXMg4oCUIHRoZSB0d28gYXJlIHRoZVxcbnNhbWUgZG9jdW1lbnQ7IHRoZSBoZWFkaW5nIGlzIHN0YXRpYyBiZWNhdXNlIHRlbXBsYXRlcyBoYXZlIG5vIGludGVycG9sYXRpb24gYW5kIHRoZVxcbmFwcCBjaHJvbWUgYWxyZWFkeSBzaG93cyB0aGUgZG9jdW1lbnQgdGl0bGUsIEFWLVI3KTpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnByZT48X2NvbXBvbmVudHMuY29kZSBjbGFzc05hbWU9XCJsYW5ndWFnZS1tZHhcIj57XCIjIEF1dGhvcidzIHZpZXcuXFxuXFxuPFN1aXRlU3VtbWFyeSAvPlxcblxcbiMjIERlY2lzaW9ucy5cXG5cXG5ObyBkZWNpc2lvbnMgcmVjb3JkZWQgeWV0IOKAlCB0aGUgd29ya2Jvb2sncyB3aHkgbGl2ZXMgaGVyZTogd2hhdCB3YXMgY2hvc2VuLCB3aGF0IHdhc1xcbnJlamVjdGVkLCB3aGF0IHRoZSB0ZXN0cyBndWFyZC5cXG5cXG4jIyBGb3JtdWxhcy5cXG5cXG48Rm9ybXVsYUluZGV4IC8+XFxuXFxuIyMgRGF0YS5cXG5cXG48RGF0YUludmVudG9yeSAvPlxcblxcbiMjIFRlc3RzLlxcblxcbjxUZXN0SW5kZXggLz5cXG5cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5wcmU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwic2VjLTUtMlwiIGRhdGEtc2x1Zz1cIjUyLWRlY2lzaW9ucy13aGVyZS10aGUtdGhpbmtpbmctc3Vydml2ZXNcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy01LTJcIiAvPntcIjUuMiBEZWNpc2lvbnMg4oCUIHdoZXJlIHRoZSB0aGlua2luZyBzdXJ2aXZlc1wifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcIiMjIERlY2lzaW9ucy5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHNlY3Rpb24gaXMgdGhlIGRvY3VtZW50LWxldmVsIGhvbWUgZm9yIHRoZSBjcmVhdG9ycycgcmVhc29uaW5nIOKAlFxcbnRoZSB3b3JraW5nIGN1bHR1cmUncyBcIn08X2NvbXBvbmVudHMuZW0+e1wiZGVjaXNpb25zICYgcmVqZWN0ZWQgYWx0ZXJuYXRpdmVzXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgZGlzY2lwbGluZSBhcHBsaWVkIHRvIHdvcmtib29rXFxuZG9jdW1lbnRzLiBDb250ZW50IGJvdW5kYXJpZXMsIHdpdGggdGhlaXIgZW5mb3JjZW1lbnQgc3RhdGVkIGhvbmVzdGx5IChBVi1SOSk6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJEZWNpc2lvbnMgYW5kIGFzc3VtcHRpb25zLCBuZXZlciB0cmFuc2NyaXB0cy5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgV2hhdCB3YXMgaW5mZXJyZWQgZnJvbSwgd2hhdCBzaGFwZVxcbndhcyByZWplY3RlZCBhbmQgd2h5LCB3aGF0IHRoZSBob2xkb3V0IHdpdGhob2xkcywgd2hhdCBlYWNoIG1ldGFtb3JwaGljIHJlbGF0aW9uXFxuZ3VhcmRzLiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlRoZSBjaGF0LWxvZyBleGNsdXNpb24gaXMgYSBwcml2YWN5IGJvdW5kYXJ5XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBjaGF0IG1heSBjYXJyeSB0aGUgdXNlcidzXFxucHJpdmF0ZSBjb250ZXh0LCBhbmQgdGhpcyBkb2N1bWVudCBpcyBidWlsdCB0byBiZSBzaGFyZWQgYW5kIGRpZmZlZCDigJQgYW5kIGl0IGlzXFxuZW5mb3JjZWQgdG9kYXkgb25seSBieSBwcm9tcHQgZGlzY2lwbGluZSBwbHVzIHRoZSBjb250cmlidXRlIGdhdGUncyBodW1hbiBmdWxsLWRpZmZcXG5yZXZpZXcsIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibGFiZWxlZCBhcyBzdWNoLCBub3QgcHJlc2VudGVkIGFzIGVuZm9yY2VkXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLiBBIG1lY2hhbmljYWwgYmFja3N0b3AgaXMgYW5cXG5vcGVuIHF1ZXN0aW9uIChRNSksIG5vdCBhIGNsYWltLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiV2h5LCBuZXZlciB3aGV0aGVyLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBDb3ZlcmFnZSBcIn08X2NvbXBvbmVudHMuZW0+e1wiY2xhaW1zXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgYmVsb25nIHRvIHRoZSBjb21wdXRlZCBjaHJvbWU7IHRoZSByZWNvcmRcXG5leHBsYWlucyBpbnRlbnQsIHRoZSB2ZXJkaWN0cyBzdGF0ZSBmYWN0LiAoUHJvc2UgYXNzZXJ0aW5nIFxcXCJmdWxseSB0ZXN0ZWRcXFwiIGJlc2lkZSBhXFxucmVkIGNoaXAgbWlzbGVhZHMgbm8gb25lIHByZWNpc2VseSBiZWNhdXNlIHRoZSBjaGlwIGlzIGNvbXB1dGVkIOKAlCDCpzIuMy4pXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJTaWduZWQgYW5kIGRhdGVkIGJ5IGNvbnZlbnRpb25cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKFxcXCJyZWNvcmRlZCBieSB0aGUgYXNzaXN0YW50LCAyMDI2LeKAplxcXCIpLiBBXFxubGVnaWJpbGl0eSBjb252ZW50aW9uLCBub3QgcHJvdmVuYW5jZSDigJQgdGhlIHBsYXRmb3JtIGRlbGliZXJhdGVseSB0cmFja3Mgbm8gcGVyLWZpbGVcXG5hdXRob3JzaGlwLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCJzZWMtNS0zXCIgZGF0YS1zbHVnPVwiNTMtdGhlLWFnZW50LWhvb2tcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy01LTNcIiAvPntcIjUuMyBUaGUgYWdlbnQgaG9va1wifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLmNvZGU+e1wiZG9jcy9hc3Npc3RhbnQvRk9STVVMQV9BVVRIT1JJTkdfUFJPTVBULm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBnYWlucyBhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicG9zdC1sb29wIHN0YW5kaW5nIGR1dHlcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUXFxuXFxcInJlY29yZCB0aGUgZGVjaXNpb25cXFwiIOKAlCByYXRoZXIgdGhhbiBhIHJlb3JkZXJlZCBsb29wIHN0ZXAgKHRoZSBsb29wJ3MgZW5kcyBhcmVcXG5leHBsaWNpdGx5IGZpeGVkLCBBVi1SMTApLCBhbmQgdGhlIHByb21wdCdzIHNjb3BlIG5vdGUgaXMgd2lkZW5lZCBieSBleGFjdGx5IG9uZVxcbnNlbnRlbmNlOiB0aGUgRGVjaXNpb25zIHJlY29yZCBpcyB0aGUgb25lIHRlbXBsYXRlIHN1cmZhY2UgdGhpcyBwcm9tcHQgdG91Y2hlcywgdW50aWxcXG50aGUgcmVwb3J0LWdlbmVyYXRpb24gcGlwZWxpbmUncyBvd24gcHJvbXB0IChwbGFuIMKnOC40KSBleGlzdHMgYW5kIHRha2VzIGl0IG92ZXIuIFRoZVxcblwifTxfY29tcG9uZW50cy5lbT57XCJmYWN0XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgb2YgcmVjb3JkaW5nIGlzIGRvY3VtZW50YXRpb24sIHNvIHByb21wdC1sZXZlbCBpcyB0aGUgaG9uZXN0IG1lY2hhbmlzbTsgdGhlXFxuXCJ9PF9jb21wb25lbnRzLmVtPntcInByaXZhY3kgYm91bmRhcnlcIn08L19jb21wb25lbnRzLmVtPntcIiB3aXRoaW4gaXQgaXMgbGFiZWxlZCBwZXIgwqc1LjIuIFRoZSBFLTYgYWdlbnQtbG9vcCBldmFsdWF0aW9uIGdhaW5zXFxuXFxcImlzIHRoZSBkZWNpc2lvbiByZWNvcmRlZCwgd2l0aGluIHRoZSBib3VuZGFyaWVzXFxcIiBhcyBhIHNjb3JlZCBjcml0ZXJpb24gd2hlbiB0aGF0XFxuaGFybmVzcyBydW5zLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaHIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtNlwiIGRhdGEtc2x1Zz1cIjYtd2hlcmUtcmVmbGVjdGlvbi1tYXktcmVuZGVyLXRoZS1wcm9kdWN0LWRlY2lzaW9uLW5vcm1hdGl2ZS1zaGlwcGVkLTIwMjYtMDgtMjgtcmV3cml0dGVuLXBlci1hdi1yMVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTZcIiAvPntcIjYuIFdoZXJlIHJlZmxlY3Rpb24gbWF5IHJlbmRlciDigJQgdGhlIHByb2R1Y3QgZGVjaXNpb24gIFwifTxfY29tcG9uZW50cy5lbT57XCIobm9ybWF0aXZlIOKAlCBzaGlwcGVkIDIwMjYtMDgtMjg7IHJld3JpdHRlbiBwZXIgQVYtUjEpXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSBkcmFmdCdzIFxcXCJyZWZsZWN0aW9uIGNvbXBvbmVudHMgYXJlIGxlZ2FsIGluIGFueSB0ZW1wbGF0ZVxcXCIgaXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ3aXRoZHJhd25cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIuIFRoZVxcbnByb2R1Y3QgZGVmaW5pdGlvbiBwcm9taXNlcyB0aGUgcmVwb3J0IHZpZXdlcjogXCJ9PF9jb21wb25lbnRzLmVtPntcIlxcXCJvcGVuIGEgbGluaywgc2VlIGEgbGl2ZSByZXBvcnQsIGRyaWxsXFxuaW50byBpdCwgYW5kIG5ldmVyIHNlZSBhIGZvcm11bGEuXFxcIlwifTwvX2NvbXBvbmVudHMuZW0+e1wiIFRoYXQgc2VudGVuY2UgaXMgYWJvdXQgdGhlIGNvbnN1bWVyIHN1cmZhY2UsIGFuZFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcIjxGb3JtdWxhSW5kZXggLz5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGluIGEgY29uc3VtZXIgdGVtcGxhdGUgd291bGQgcHV0IGV2ZXJ5IGNlbGwncyBzb3VyY2UgaW4gZnJvbnQgb2YgdGhlXFxudmlld2VycyB0aGF0IHByb21pc2UgY292ZXJzLiBDbGFzcy1BIHJlYWNoIGFyZ3VtZW50cyBkbyBub3QgZGVjaWRlIHRoaXMg4oCUIHJlYWNoIGJvdW5kc1xcbndoYXQgYSByZWFsbSBjYW4gXCJ9PF9jb21wb25lbnRzLmVtPntcInRvdWNoXCJ9PC9fY29tcG9uZW50cy5lbT57XCIsIG5vdCB3aGF0IHRoZSBwcm9kdWN0IFwifTxfY29tcG9uZW50cy5lbT57XCJzaG93c1wifTwvX2NvbXBvbmVudHMuZW0+e1wiIOKAlCBhbmQgYW4gYXV0aG9yJ3MgYWJpbGl0eSB0b1xcbmhhbmQtcGFzdGUgZm9ybXVsYSB0ZXh0IGludG8gcHJvc2UgKHJlYWwsIGFuZCB1bnByZXZlbnRhYmxlIGluIGFueSB0ZW1wbGF0ZSBzeXN0ZW0pIGlzXFxucGFyaXR5IGZvciBcIn08X2NvbXBvbmVudHMuZW0+e1wiZGVsaWJlcmF0ZVwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGRpc2Nsb3N1cmUsIG5vdCBhIHJlYXNvbiB0byBtYWtlIHdob2xlc2FsZSBkaXNjbG9zdXJlIG9uZSB0YWdcXG5hd2F5LlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgcnVsZTogXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJyZWZsZWN0aW9uIGNvbXBvbmVudHMgcmVuZGVyIG9ubHkgaW4gdGhlIGF1dGhvcidzLXZpZXcgdGVtcGxhdGUuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJMb2FkIHRpbWU6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGEgcmVmbGVjdGlvbiBjb21wb25lbnQgaW4gYW55IG90aGVyIHRlbXBsYXRlIGlzIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ2YWxpZGF0aW9uXFxuZGlhZ25vc3RpY1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAod2FybmluZyDigJQgdGhlIGRvY3VtZW50IHN0aWxsIGxvYWRzKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlJlbmRlciB0aW1lOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB0aGUgcmVmbGVjdGlvbiBwb3J0IGlzIHByb3ZpZGVkIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wib25seVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB0byB0aGUgYXV0aG9yJ3Mtdmlld1xcbnJlbmRlcjsgZXZlcnl3aGVyZSBlbHNlIHRoZSBjb21wb25lbnRzIGhpdCB0aGUgbm8tcG9ydCBwYXRoIGFuZCByZW5kZXIgdGhlXFxuYXV0aG9yJ3Mtdmlldy1vbmx5IGJyb2tlbiB0aWxlICjCpzIuMikuIFRoZSByZXN0cmljdGlvbiBpcyB0aGVyZWZvcmUgc3RydWN0dXJhbCwgbm90XFxuYWR2aXNvcnkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSByZXN0IG9mIHRoZSB0cnVzdCBzdG9yeSwgdW5jaGFuZ2VkIGZyb20gdGhlIGRyYWZ0OlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiTm8gZW5mb3JjZW1lbnQgb2Ygc2VjdGlvbiBwcmVzZW5jZSDigJQgZGVsaWJlcmF0ZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAob3duZXIgZGVjaXNpb24gMjAyNi0wOC0yOCwgwqcxMCkuXFxuQ29tcGxldGVuZXNzIGlzIGd1YXJhbnRlZWQgd2hlcmUgaXQgaXMgbG9hZC1iZWFyaW5nOiB0aGUgcGFuZWwgYW5kIGluc3BlY3RvciByZW5kZXJcXG5ob3N0LWNvbXB1dGVkIHZlcmRpY3RzIG92ZXIgdGhlIGZ1bGwgaW52ZW50b3J5LCB1bnN1cHByZXNzaWJsZSBieSBhbnkgdGVtcGxhdGUuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJOb24tZXhlY3V0YWJsZSB0aHJvdWdob3V0LlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGUgdmlldyBpcyBhIHRlbXBsYXRlOiBzYWZlLXJlbmRlcmVkLCBkZWNsYXJhdGl2ZSwgbm9cXG5leHByZXNzaW9uIGV2YWx1YXRpb247IHByb3NlIGlzIGRpZmYtdmlzaWJsZSBhdCB0aGUgY29udHJpYnV0ZSBnYXRlLiBCb3VuZGVkLWluamVjdGlvblxcbnBvc3R1cmUgKFRTLTEpIHVuY2hhbmdlZDsgbm8gbmV3IGNoYW5uZWwuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgcG9ydCBpcyBzZWNyZXQtZnJlZSBieSBjb25zdHJ1Y3Rpb25cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKMKnMy4zKTogYWxsb3dsaXN0IHByb2plY3Rpb25zLCBzdHJpcHBlZFxcbmhvc3RzLCBubyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzZWNyZXRSZWZcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG5hbWVzIG9yIHZhbHVlcywgZ2F0ZS10ZXN0ZWQgKEctQVYtOSkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5ociAvPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInNlYy03XCIgZGF0YS1zbHVnPVwiNy1vdXQtb2Ytc2NvcGUtdGhlLWhvbmVzdC1yZW1haW5kZXItbm9ybWF0aXZlLXRoZS1ib29rZWQtcmVtYWluZGVyLW5vdGhpbmctaGVyZS1zaGlwcGVkXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtN1wiIC8+e1wiNy4gT3V0IG9mIHNjb3BlIOKAlCB0aGUgaG9uZXN0IHJlbWFpbmRlciAgXCJ9PF9jb21wb25lbnRzLmVtPntcIihub3JtYXRpdmUg4oCUIHRoZSBib29rZWQgcmVtYWluZGVyLCBub3RoaW5nIGhlcmUgc2hpcHBlZClcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIk1hdGVyaWFsaXplLW9uLWN1c3RvbWl6ZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAodGhlIGJ1dHRvbiB0aGF0IHdyaXRlcyB0aGUgc2NhZmZvbGQgaW50byBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ0ZW1wbGF0ZXMvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIik6XFxubmVlZHMgdGhlIGRvY3VtZW50IHdyaXRlIHBhdGggKHJ3IG1vdW50ICsgZWRpdG9yIGZsb3csIHRoZSBuYXZpZ2F0b3IgdGhyZWFkKS4gVW50aWxcXG50aGVuLCBhdXRob3JzIGNyZWF0ZSB0aGUgZmlsZSBieSBoYW5kIG9yIHZpYSB0aGUgZWRpdG9yLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQSBmaWxlLWluY2x1ZGUgbWVjaGFuaXNtXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChcIn08X2NvbXBvbmVudHMuY29kZT57XCI8SW5jbHVkZSBmaWxlPVxcXCLigKZcXFwiLz5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiKTogbmVlZHMgYnVuZGxlLXJlbGF0aXZlXFxucmVzb2x1dGlvbiBhbmQgY3ljbGUgaGFuZGxpbmc7IGRlZmVycmVkIHVudGlsIGNvbXBvc2l0aW9uIHByZXNzdXJlIGlzIHJlYWwgKG93bmVyOlxcbmNvbXBvbmVudHMtb25seSBmb3IgdjEpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUGVyLWNlbGwgZGVlcCBsaW5rc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBmcm9tIGluZGV4IHJvd3MgaW50byB0aGUgZWRpdG9yIHJpZGUgdGhlIG5hdmlnYXRvciB3b3JrIGFuZFxcblIzLTQyNyAoc3BhbnMpLCBub3QgdGhpcyBzcGVjLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiSW4tYXBwIGRlZXAtbGlua2luZyAvIHJvdXRpbmdcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgZm9yIHRoZSB2aWV3ICjCpzEuMik6IGZvbGxvd3MgdGhlIGFwcCdzIHJvdXRpbmdcXG5zdG9yeSwgd2hpY2ggZG9lcyBub3QgZXhpc3QgeWV0OyB0aGUgdmlldyBpcyBjb21wb25lbnQgc3RhdGUgaW4gdjEuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJSZW5kZXJpbmcgaW4gc2hhcmVkL2Fub255bW91cy12aWV3ZXIgZGVwbG95bWVudHNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgZm9sbG93cyB3aGF0ZXZlciB0aGUgZGVwbG95bWVudFxcbnNoYXBlIGRlY2lkZXMgZm9yIHRoZSB3b3JrYm9vayBwYW5lbCBpdHNlbGYg4oCUIHRoZSBkb29yIGdhdGVzIHRoZSB2aWV3LCBhbmQgwqc2IG5vd1xcbmd1YXJhbnRlZXMgdGhlIGNvbXBvbmVudHMgY2Fubm90IHJpZGUgaW50byB0aGUgY29uc3VtZXIgcmVwb3J0IGFyb3VuZCB0aGF0IGRvb3IuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5ociAvPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInNlYy04XCIgZGF0YS1zbHVnPVwiOC1nYXRlcy1ub3JtYXRpdmUtdGhlLWZhbHNpZmlhYmxlLWV4aXQtdGVzdHMtc2hpcHBlZC0yMDI2LTA4LTI4XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtOFwiIC8+e1wiOC4gR2F0ZXMgIFwifTxfY29tcG9uZW50cy5lbT57XCIobm9ybWF0aXZlIOKAlCB0aGUgZmFsc2lmaWFibGUgZXhpdCB0ZXN0cywgc2hpcHBlZCAyMDI2LTA4LTI4KVwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMudGFibGU+PF9jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGg+e1wiR2F0ZVwifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIlRlc3RcIn08L19jb21wb25lbnRzLnRoPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudGJvZHk+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkctQVYtMVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIldpdGggbm8gYXV0aG9yJ3MtdmlldyB0ZW1wbGF0ZSwgdGhlIGRlZmF1bHQgdmlldyByZW5kZXJzIGZyb20gbGl2ZSBzdGF0ZTogdGhlIHN1aXRlIGxpbmUsIHRoZSBEZWNpc2lvbnMgaGVhZGluZywgZXZlcnkgY2VsbCwgZXZlcnkgZml4dHVyZSBhbmQgZmVlZCwgZXZlcnkgdGVzdCDigJQgbm8gbWF0ZXJpYWxpemVkIGZpbGUuXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnN0cm9uZz57XCJHLUFWLTJcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJBIGRvY3VtZW50J3Mgb3duIFwifTxfY29tcG9uZW50cy5jb2RlPntcImF1dGhvcnNfdmlldy5tZHhcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHJlcGxhY2VzIHRoZSBkZWZhdWx0IGVudGlyZWx5OyBhIGN1c3RvbSBmaWxlIG9taXR0aW5nIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjxGb3JtdWxhSW5kZXggLz5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHJlbmRlcnMgd2l0aG91dCB0aGUgZm9ybXVsYSBpbmRleCAobm8gZW5mb3JjZW1lbnQpLCB3aGlsZSB0aGUgd29ya2Jvb2sgcGFuZWwgc3RpbGwgbGlzdHMgZXZlcnkgY2VsbC5cIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkctQVYtM1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIlRoZSBhdXRob3Incy12aWV3IHRlbXBsYXRlIGlzIGV4Y2x1ZGVkIGZyb20gY29uc3VtZXItcmVwb3J0IHNlbGVjdGlvbjogdGVtcGxhdGVzIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlthdXRob3JzX3ZpZXcsIHdlZWtseV1cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHNlcnZlIFwifTxfY29tcG9uZW50cy5jb2RlPntcIndlZWtseVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYXMgdGhlIHJlcG9ydDsgYSBkb2N1bWVudCB3aXRoIG9ubHkgYW4gYXV0aG9yJ3MgdmlldyByZW5kZXJzIHRoZSByZXBvcnQgZW1wdHktc3RhdGUsIG5ldmVyIHRoZSBhdXRob3IncyB2aWV3LlwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRy1BVi00XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiVGhlIG1hbmlmZXN0J3MgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYXV0aG9yc1ZpZXdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGtleSBzZWxlY3RzIGEgZGlmZmVyZW50bHktbmFtZWQgdGVtcGxhdGUgYXMgdGhlIGF1dGhvcidzIHZpZXcgKGFuZCBleGNsdWRlcyBpdCBmcm9tIGNvbnN1bWVyIHNlbGVjdGlvbikuXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnN0cm9uZz57XCJHLUFWLTVcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCI8Rm9ybXVsYUluZGV4IHdvcmtzaGVldD1cXFwibW9kbGVcXFwiIC8+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAodW5rbm93biBmaWx0ZXIpIHJlbmRlcnMgdGhlIGJyb2tlbiB0aWxlIHdpdGggYSByZWFzb24g4oCUIG5vIGNyYXNoLCBubyBzaWxlbnQgZW1wdHkgbGlzdC5cIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkctQVYtNlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIlZlcmRpY3QgY2hpcHMgcmVuZGVyIGVhY2ggY29tcHV0ZWQgdmVyZGljdCB3aXRoIGl0cyBwZXItc3RhdGUgY2xhc3MvbGFiZWwg4oCUIHRoZSBzYW1lIGZvdXIgY2xhc3NlcyB0aGUgd29ya2Jvb2sgcGFuZWwgdXNlcyDigJQgZHJpdmVuIGJ5IHRoZSBzYW1lIHJlc3VsdHMgb2JqZWN0OyBhIFwifTxfY29tcG9uZW50cy5jb2RlPntcInZlcmRpY3RzOiBudWxsXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBwb3J0IHJlbmRlcnMgYSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInBlbmRpbmdcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgY2xhc3MvbGFiZWwgdGhhdCBpcyBub25lIG9mIHRoZSBmb3VyLCBhbmQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiU3VpdGVTdW1tYXJ5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiByZW5kZXJzIFxcXCJSdW5uaW5nIHN1aXRlc+KAplxcXCIsIG5ldmVyIGEgdmVyZGljdCBjb3VudCAoQVYtUjIvQVYtUjEyKS5cIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkctQVYtN1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIkEgcmVmbGVjdGlvbiBjb21wb25lbnQgcmVuZGVyZWQgd2l0aCBubyByZWZsZWN0aW9uIHBvcnQgcmVuZGVycyB0aGUgYXV0aG9yJ3Mtdmlldy1vbmx5IGJyb2tlbiB0aWxlIOKAlCBpbmNsdWRpbmcgd2hlbiBwbGFjZWQgaW4gYSBjb25zdW1lciB0ZW1wbGF0ZSwgd2hpY2ggYWRkaXRpb25hbGx5IHJhaXNlcyBhIGxvYWQtdGltZSB2YWxpZGF0aW9uIHdhcm5pbmcgKEFWLVIxKS5cIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkctQVYtOFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIlRoZSBzY2FmZm9sZCBwYXJzZXMgd2l0aCB6ZXJvIHRlbXBsYXRlIGRpYWdub3N0aWNzIGFuZCB2YWxpZGF0ZXMgYWdhaW5zdCB0aGUgY2F0YWxvZy5cIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkctQVYtOVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcIkRhdGFJbnZlbnRvcnlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHJlbmRlcnMgZml4dHVyZSBuYW1lIC8gZmlyc3Qtcm93IGNvbHVtbnMgLyByb3cgY291bnQgLyBkZWNsYXJlZCB0aWVyIChwbGFpbi1sYWJlbGVkLCBub3QgY2hpcC1zdHlsZWQpIC8gcHJvdmVuYW5jZSwgYW5kIGZlZWQgbmFtZS9tb2RlL2hvc3Qg4oCUIGFuZCBhIGZlZWQgd2hvc2Ugc291cmNlIFVSTCBjYXJyaWVzIGEgcXVlcnktc3RyaW5nIGNyZWRlbnRpYWwgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIj9hcGlfa2V5PeKAplwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpIHJlbmRlcnMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ3aXRob3V0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHRoZSBxdWVyeSBzdHJpbmcsIHBhdGgsIG9yIHVzZXJpbmZvOyBubyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzZWNyZXRSZWZcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNvbnRlbnQgYXBwZWFycyAoQVYtUjUvQVYtUjYpLlwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRy1BVi0xMFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIk9uZSBzdWl0ZSBjb21wdXRhdGlvbjogdGhlIHBvcnQncyB2ZXJkaWN0cyBhcmUgcmVmZXJlbmNlLWlkZW50aWNhbCB0byB0aGUgcmVzdWx0cyB0aGUgd29ya2Jvb2sgcGFuZWwgcmVuZGVycyAodGhlIGhvaXN0ZWQgc2luZ2xlIFwifTxfY29tcG9uZW50cy5jb2RlPntcInVzZVZlcmRpY3RzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiksIGFzc2VydGVkIGF0IHRoZSBBcHAgd2lyaW5nIGxldmVsIChBVi1SOCkuXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGJvZHk+PC9fY29tcG9uZW50cy50YWJsZT57XCJcXG5cIn08X2NvbXBvbmVudHMuaHIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtOVwiIGRhdGEtc2x1Zz1cIjktbG9hZC1iZWFyaW5nLWFzc3VtcHRpb25zLWNvZGUtYW5jaG9ycy1yZXF1aXJlZFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTlcIiAvPntcIjkuIExvYWQtYmVhcmluZyBhc3N1bXB0aW9ucyAmIGNvZGUgYW5jaG9ycyAgXCJ9PF9jb21wb25lbnRzLmVtPntcIihyZXF1aXJlZClcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwiZGVwZW5kcy1vbi10b2RheS12ZXJpZmllZC1hZ2FpbnN0LWNvZGVcIj48SGVhZGluZ0FuY2hvciBpZD1cImRlcGVuZHMtb24tdG9kYXktdmVyaWZpZWQtYWdhaW5zdC1jb2RlXCIgLz57XCJEZXBlbmRzLW9uLXRvZGF5ICh2ZXJpZmllZCBhZ2FpbnN0IGNvZGUpXCJ9PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMudGFibGU+PF9jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGg+e1wiQXNzdW1wdGlvblwifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIkFuY2hvciAocmVwby1yZWxhdGl2ZSBmaWxlKVwifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIlRva2VuIChncmVwLXN0YWJsZSlcIn08L19jb21wb25lbnRzLnRoPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudGJvZHk+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJUaGUgY2F0YWxvZyBpcyBhIGNsb3NlZCwgdHlwZWQgc2NoZW1hIGxpc3Q7IHVua25vd24gY29tcG9uZW50cyByZW5kZXIgYSBwbGFjZWhvbGRlclwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcInNyYy9yZXBvcnQvY2F0YWxvZy50c1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJjb25zdCBDT01QT05FTlRTOiBDb21wb25lbnRTY2hlbWFbXVwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJUaGUgcmVuZGVyZXIgZGlzcGF0Y2hlcyBieSBuYW1lIG92ZXIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY29tcG9uZW50TWFwXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjsgbWlzc2luZyBuYW1lcyDihpIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiUGxhY2Vob2xkZXJcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL3JlcG9ydC9yZW5kZXIvUmVuZGVyZXIudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcImNvbXBvbmVudE1hcFtub2RlLm5hbWVdXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIk9wdGlvbmFsIHBvcnRzIGZsb3cgdGhyb3VnaCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJSZXBvcnRWaWV3XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhcyBjb250ZXh0cyAodGhlIFYzIHByZWNlZGVudClcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJzcmMvcmVwb3J0L3JlbmRlci9SZW5kZXJlci50c3hcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiSW5zcGVjdGlvbkNvbnRleHQuUHJvdmlkZXJcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiVGVtcGxhdGVzIHBhcnNlIHRvIGEgbm9kZSBtb2RlbCBhbmQgdmFsaWRhdGUgYWdhaW5zdCB0aGUgY2F0YWxvZ1wifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcInNyYy9yZXBvcnQvdmFsaWRhdGUudHNcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiZXhwb3J0IGZ1bmN0aW9uIHZhbGlkYXRlVGVtcGxhdGVcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiVGhlIGNvbnN1bWVyIHRlbXBsYXRlIHBpY2sgaXMgbmFtZS1ndWVzc2VkIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJ3ZWVrbHlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBlbHNlIGZpcnN0KSDigJQgwqc0IG5hcnJvd3MgaXRzIGNhbmRpZGF0ZSBzZXQgb25seVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcInNyYy9hcHAvcmVwb3J0U2Vzc2lvbi50c1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJuYW1lID09PSAnd2Vla2x5J1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJTdWl0ZSB2ZXJkaWN0cyBhbmQgdGhlIG9uZS1saW5lIHN1bW1hcnkgYXJlIGhvc3QtY29tcHV0ZWQ7IGEgbnVsbCByZXN1bHQgc2V0IHJlbmRlcnMgYSBydW5uaW5nIHN0YXRlLCBub3QgdmVyZGljdHNcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJzcmMvYXBwL1dvcmtib29rUGFuZWwudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcIlJ1bm5pbmcgc3VpdGVzXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIlRoZSB2ZXJkaWN0cyBob29rIGZvcmJpZHMgZG91YmxlIGNvbXB1dGF0aW9uIChcXFwib25seSBvbmUgb2YgdGhlbVxcXCIpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2hvb2tzL3VzZVZlcmRpY3RzLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcInJlLXJ1bnMgdGhlIFNBTUVcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiQ2VsbC90ZXN0IGRlc2NyaXB0b3JzIGNhcnJ5IGlkLCBkb2MsIGZvcm11bGFTb3VyY2UsIGRlcHMgKHRoZSBpbmRleCdzIGRhdGEpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2VuZ2luZS93b3JrZXIvcHJvdG9jb2wudHNcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiZm9ybXVsYVNvdXJjZVwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJGaXh0dXJlIGZpbGVzIGNhcnJ5IHJvd3MvdGllci9wcm92ZW5hbmNlIOKAlCBhbmQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJub1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBjb2x1bW4gbGlzdCBvciBjb3VudCAowqczLjEgZGVyaXZlcylcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJzcmMvZG9jdW1lbnQvdHlwZXMudHNcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiYWR2aXNvcnkgZGlzcGxheSBtZXRhZGF0YVwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJGZWVkIGNvbmZpZydzIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNvdXJjZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaXMgYSByYXcgVVJMIHN0cmluZyAod2h5IMKnMy4zIHN0cmlwcylcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJzcmMvZG9jdW1lbnQvdHlwZXMudHNcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wic291cmNlXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIlRoZSB3b3JrYm9vayBwYW5lbCByZW1haW5zIHRoZSBjb21wbGV0ZSwgdW5zdXBwcmVzc2libGUgaW52ZW50b3J5XCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2FwcC9Xb3JrYm9va1BhbmVsLnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJXb3JrYm9va1BhbmVsQm9keVwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJUaGUgYXV0aG9yaW5nIGxvb3AncyBlbmRzIGFyZSBmaXhlZCAod2h5IMKnNS4zIGlzIHBvc3QtbG9vcClcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJkb2NzL2Fzc2lzdGFudC9GT1JNVUxBX0FVVEhPUklOR19QUk9NUFQubWRcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiVGhlIGF1dGhvcmluZyBsb29wXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIlRoZSB2aWV3ZXIgcHJvbWlzZSDCpzYgcmVzdHMgb25cIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJkb2NzL3Byb2R1Y3RfZGVmaW5pdGlvbi5tZFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJuZXZlciBzZWUgYSBmb3JtdWxhXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRib2R5PjwvX2NvbXBvbmVudHMudGFibGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwibXVzdC1lc3RhYmxpc2gtbmV3LWludmFyaWFudHMtdGhlLWltcGxlbWVudGF0aW9uLWNyZWF0ZXNcIj48SGVhZGluZ0FuY2hvciBpZD1cIm11c3QtZXN0YWJsaXNoLW5ldy1pbnZhcmlhbnRzLXRoZS1pbXBsZW1lbnRhdGlvbi1jcmVhdGVzXCIgLz57XCJNdXN0LWVzdGFibGlzaCAobmV3IGludmFyaWFudHMgdGhlIGltcGxlbWVudGF0aW9uIGNyZWF0ZXMpXCJ9PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMudGFibGU+PF9jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGg+e1wiTmV3IGludmFyaWFudFwifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIlByb3ZlbiBieSAoZ2F0ZSB0ZXN0KVwifTwvX2NvbXBvbmVudHMudGg+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50Ym9keT48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkEgcmVmbGVjdGlvbiBwb3J0IGFzc2VtYmxlZCBmcm9tIGxpdmUgc2Vzc2lvbiBzdGF0ZTsgdmVyZGljdHMgc2luZ2xlLXNvdXJjZWRcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJHLUFWLTEsIEctQVYtMTBcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJGaXh0dXJlIHNoYXBlIGRlcml2ZWQgKGZpcnN0LXJvdyBjb2x1bW5zICsgcm93Q291bnQpLCBsYWJlbGVkIGFzIGRlcml2ZWRcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJHLUFWLTlcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJGZWVkU3VtbWFyeVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaXMgYW4gYWxsb3dsaXN0IHByb2plY3Rpb24gd2l0aCBzdHJpcHBlZCBob3N0c1wifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIkctQVYtOVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkRlZmF1bHQtd2hlbi1hYnNlbnQgLyBmaWxlLXdoZW4tb3duZWQgc2VsZWN0aW9uOyBtYW5pZmVzdCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJhdXRob3JzVmlld1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaG9ub3JlZFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIkctQVYtMSwgRy1BVi0yLCBHLUFWLTRcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJUaGUgYXV0aG9yJ3MtdmlldyB0ZW1wbGF0ZSBuZXZlciBzZXJ2ZXMgYXMgdGhlIGNvbnN1bWVyIHJlcG9ydFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIkctQVYtM1wifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIlJlZmxlY3Rpb24gY29tcG9uZW50cyByZW5kZXIgb25seSBpbiB0aGUgYXV0aG9yJ3MgdmlldyAoc3RydWN0dXJhbCArIGRpYWdub3N0aWMpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiRy1BVi03XCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiQ2hpcHM6IGZvdXIgY29tcHV0ZWQgc3RhdGVzICsgYSBkaXN0aW5jdCBwZW5kaW5nIHN0YXRlLCBwYW5lbC1pZGVudGljYWwgY2xhc3Nlc1wifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIkctQVYtNlwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIlRoZSBzY2FmZm9sZCBpcyB2YWxpZCBhZ2FpbnN0IHRoZSBjYXRhbG9nXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiRy1BVi04XCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGJvZHk+PC9fY29tcG9uZW50cy50YWJsZT57XCJcXG5cIn08X2NvbXBvbmVudHMuaHIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtMTBcIiBkYXRhLXNsdWc9XCIxMC1kZWNpc2lvbnMtcmVqZWN0ZWQtYWx0ZXJuYXRpdmVzLW5vcm1hdGl2ZS1kb250LXJlbGl0aWdhdGVcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy0xMFwiIC8+e1wiMTAuIERlY2lzaW9ucyAmIHJlamVjdGVkIGFsdGVybmF0aXZlcyAgXCJ9PF9jb21wb25lbnRzLmVtPntcIihub3JtYXRpdmUg4oCUIGRvbid0IHJlbGl0aWdhdGUpXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJObyBlbmZvcmNlbWVudCB0aGF0IGdlbmVyYXRlZCBzZWN0aW9ucyBzdXJ2aXZlIGF1dGhvciBlZGl0aW5nXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChvd25lciBkZWNpc2lvbixcXG4yMDI2LTA4LTI4KS4gVGhlIGF1dGhvcidzIHZpZXcgaXMgYSBjdXJhdGVkIGRvY3VtZW50OyBjb21wbGV0ZW5lc3MgbGl2ZXMgaW4gdGhlXFxuY29tcHV0ZWQgY2hyb21lLCB3aGljaCBubyB0ZW1wbGF0ZSBjYW4gc3VwcHJlc3MuIFwifTxfY29tcG9uZW50cy5lbT57XCJSZWplY3RlZDpcIn08L19jb21wb25lbnRzLmVtPntcIiBhbiBcXFwiYWRkaXRpdmUtb25seVxcXCJcXG5tZWNoYW5pc20gcG9saWNpbmcgdGhlIGF1dGhvcidzIG93biBmaWxlIOKAlCB0aGVhdGVyIGFnYWluc3QgYSBwYXJ0eSB3aG8gb3ducyB0aGUgdGVzdHNcXG50aGVtc2VsdmVzLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUmVmbGVjdGlvbiBjb21wb25lbnRzIGFyZSBhdXRob3Incy12aWV3LW9ubHkgKEFWLVIxKS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhlIHByb2R1Y3QncyB2aWV3ZXJcXG5wcm9taXNlIChcXFwibmV2ZXIgc2VlIGEgZm9ybXVsYVxcXCIpIG91dHJhbmtzIHRoZSBDbGFzcy1BIHJlYWNoIGFyZ3VtZW50OyB0aGUgcmVzdHJpY3Rpb25cXG5pcyBzdHJ1Y3R1cmFsIChwb3J0IHdpdGhoZWxkKSBwbHVzIGEgbG9hZC10aW1lIGRpYWdub3N0aWMuIFwifTxfY29tcG9uZW50cy5lbT57XCJSZWplY3RlZDpcIn08L19jb21wb25lbnRzLmVtPntcIiBcXFwibGVnYWwgaW4gYW55XFxudGVtcGxhdGUsIG5vIHNwZWNpYWwtY2FzaW5nXFxcIiAodGhlIHdpdGhkcmF3biBkcmFmdCBwb3NpdGlvbik7IHByb3NlLXBhc3RlIHBhcml0eSBhcyBhXFxuanVzdGlmaWNhdGlvbiBmb3Igb25lLXRhZyB3aG9sZXNhbGUgZGlzY2xvc3VyZS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlJlZmxlY3Rpb24gY29tcG9uZW50cyBhcyB0aGUgb25seSBtZWNoYW5pc20g4oCUIG5vIGFubm90YXRpb24tZnJhZ21lbnQgc3Vic3lzdGVtLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIlxcbk9uZSBtZWNoYW5pc20gKHRlbXBsYXRlcyArIGNhdGFsb2cpIGNhcnJpZXMgYm90aCBpbnZlbnRvcnkgYW5kIG5hcnJhdGl2ZS4gXCJ9PF9jb21wb25lbnRzLmVtPntcIlJlamVjdGVkOlwifTwvX2NvbXBvbmVudHMuZW0+e1wiXFxuYSBnZW5lcmF0ZWQgc3BpbmUgd2l0aCBrZXllZCBhbm5vdGF0aW9uIGZyYWdtZW50cyDigJQgYSBzZWNvbmQgY29udGVudCBzeXN0ZW0gd2l0aCBpdHNcXG5vd24ga2V5aW5nLCBvcnBoYW4tdmFsaWRhdGlvbiwgYW5kIHN0YWxlbmVzcyBzdXJmYWNlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRGVmYXVsdC13aGVuLWFic2VudCwgZmlsZS13aGVuLW93bmVkLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBObyBib2lsZXJwbGF0ZSBmaWxlIGluIGV2ZXJ5IGRvY3VtZW50OyB0aGVcXG5maWxlJ3MgZXhpc3RlbmNlIG1lYW5zIGFuIGF1dGhvciB0b29rIG93bmVyc2hpcC4gXCJ9PF9jb21wb25lbnRzLmVtPntcIlJlamVjdGVkOlwifTwvX2NvbXBvbmVudHMuZW0+e1wiIHByZS1nZW5lcmF0aW5nIHRoZSBmaWxlXFxuaW50byBldmVyeSBkb2N1bWVudDsgcmVnZW5lcmF0aW5nIG92ZXIgYW4gYXV0aG9yZWQgZmlsZS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkVudW1lcmF0ZS1ldmVyeXRoaW5nIGRlZmF1bHRzOyBwZXItd29ya3NoZWV0IGNvbGxhcHNpYmxlIGdyb3VwaW5nLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBBbiB1bmVkaXRlZFxcbnNjYWZmb2xkIHN0YXlzIGNvbXBsZXRlIHdpdGhvdXQgcmVnZW5lcmF0aW9uIGFuZCBzdGF5cyBuYXZpZ2FibGUgb24gYSBsYXJnZSB3b3JrYm9vay5cXG5cIn08X2NvbXBvbmVudHMuZW0+e1wiUmVqZWN0ZWQ6XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgaGFuZC1lbnVtZXJhdGVkIHNjYWZmb2xkczsgb25lIHVuYm91bmRlZCBmbGF0IHBhZ2UuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJBIG1pbmltYWwgZm91ci1jb21wb25lbnQgdm9jYWJ1bGFyeTsgYSBzdGF0aWMgc2NhZmZvbGQgaGVhZGluZyAoQVYtUjcpLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGVcXG5hZGRpdGl2ZS1mb3JldmVyIGRpc2NpcGxpbmUgY2FwcyB0aGUgc3VyZmFjZTsgbm8gaW50ZXJwb2xhdGlvbiBtZWNoYW5pc20gYW5kIG5vIGZpZnRoXFxudGl0bGUgY29tcG9uZW50IHJpZGUgaW4g4oCUIHRoZSBhcHAgY2hyb21lIGFscmVhZHkgbmFtZXMgdGhlIGRvY3VtZW50LiBcIn08X2NvbXBvbmVudHMuZW0+e1wiUmVqZWN0ZWQ6XCJ9PC9fY29tcG9uZW50cy5lbT57XCJcXG5wZXItb2JqZWN0IG1pY3JvLWNvbXBvbmVudHM7IGEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiPERvY1RpdGxlIC8+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjsgdGVtcGxhdGUgaW50ZXJwb2xhdGlvbi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkZpcnN0LXJvdyBjb2x1bW4gZGVyaXZhdGlvbiwgbGFiZWxlZCAoQVYtUjQpLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBPKDEpLCBob25lc3QgYWJvdXQgaXRzIGJvdW5kLlxcblwifTxfY29tcG9uZW50cy5lbT57XCJSZWplY3RlZDpcIn08L19jb21wb25lbnRzLmVtPntcIiBhbiB1bmxhYmVsZWQgY29sdW1uIGNsYWltOyBhIGZ1bGwgdW5pb24gc2NhbiAodW5ib3VuZGVkIG9uIGxhcmdlIGZyYW1lcykuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJEZWNsYXJlZCBmaXh0dXJlIHRpZXIgcmVuZGVycyBhcyBwbGFpbiBsYWJlbGVkIGRhdGEgKEFWLVI1KVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgdGhlIHJldmlldy0xIEgyXFxucHJlY2VkZW50LiBcIn08X2NvbXBvbmVudHMuZW0+e1wiUmVqZWN0ZWQ6XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgY2hpcC1zdHlsaW5nIGF1dGhvcmVkIG1ldGFkYXRhLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQ29tcG9uZW50cy1vbmx5OyBubyBcIn08X2NvbXBvbmVudHMuY29kZT57XCI8SW5jbHVkZT5cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChvd25lciBsZWFuLCAyMDI2LTA4LTI4KS4gXCJ9PF9jb21wb25lbnRzLmVtPntcIlJlamVjdGVkIGZvciB2MTpcIn08L19jb21wb25lbnRzLmVtPntcIlxcbmZpbGUgaW5jbHVzaW9uIChidW5kbGUgYWRkcmVzc2luZyArIGN5Y2xlcykuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgdmlldyBvcGVucyBmcm9tIHRoZSB3b3JrYm9vayBwYW5lbCwgcmVuZGVycyBpbiBwbGFjZSBvZiB0aGUgcmVwb3J0IHdpdGggYW5cXG5leHBsaWNpdCBCYWNrOyBubyByb3V0aW5nIGNsYWltcyAoQVYtUjEzKS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXCJ9PF9jb21wb25lbnRzLmVtPntcIlJlamVjdGVkOlwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGEgdGFiIGJhcjsgaW1wbHlpbmdcXG5icm93c2VyLWJhY2sgb3IgZGVlcC1saW5rIGJlaGF2aW9yIHRoZSBhcHAgY2Fubm90IGRlbGl2ZXIgeWV0LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaHIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtMTFcIiBkYXRhLXNsdWc9XCIxMS1hZHZlcnNhcmlhbC1yZXZpZXctcmVjb3JkXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtMTFcIiAvPntcIjExLiBBZHZlcnNhcmlhbCByZXZpZXcgIFwifTxfY29tcG9uZW50cy5lbT57XCIocmVjb3JkKVwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlBhc3MgMSAoMjAyNi0wOC0yOCwgZnJlc2gtYWdlbnQpLCBBVi1SMeKApkFWLVIxNCDigJQgYWxsIGZvbGRlZCBpbnRvIHRoaXMgcmV2aXNpb246XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJBVi1SMSBbQkxPQ0tFUl1cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgcmVmbGVjdGlvbiBsZWdhbCBpbiB1bmdhdGVkIGNvbnN1bWVyIHJlcG9ydHMgY29udHJhZGljdGVkIHRoZVxcbmRvb3Igc3RvcnkgYW5kIHRoZSBwcm9kdWN0J3MgXFxcIm5ldmVyIHNlZSBhIGZvcm11bGFcXFwiIHByb21pc2Ug4oaSIMKnNiByZXdyaXR0ZW46XFxuYXV0aG9yJ3Mtdmlldy1vbmx5LCBzdHJ1Y3R1cmFsIChwb3J0IHdpdGhoZWxkKSArIGRpYWdub3N0aWM7IGRlY2lzaW9uIHJlY29yZGVkLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQVYtUjIgW0JMT0NLRVJdXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5jb2RlPntcInZlcmRpY3RzOiBudWxsXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBzcGVjaWZpZWQgYXMgYW4gXFxcInVudGVzdGVkXFxcIi1zdHlsZSByZW5kZXIg4oCUIHRoZVxcbmZvdXItc3RhdGUgbWlzbGFiZWwgdGhlIHBhbmVsIGZvcmJpZHMg4oCUIGFuZCBjb250cmFkaWN0ZWQgRy1BVi02IOKGkiDCpzIuMy/CpzMuNCBkaXN0aW5jdFxcbnBlbmRpbmcgc3RhdGU7IFN1aXRlU3VtbWFyeSBcXFwiUnVubmluZyBzdWl0ZXPigKZcXFwiOyBHLUFWLTYgcmV3cml0dGVuLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQVYtUjMgW01BSk9SXVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcXFwibWFuaWZlc3QtbmFtZWQgcmVwb3J0IHRlbXBsYXRlXFxcIiByZWZlcmVuY2VkIGEgbm9uZXhpc3RlbnQga2V5IOKGklxcbsKnNCByZXN0YXRlZDogXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wid2Vla2x5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBndWVzcyByZXRhaW5lZCBvdmVyIG5vbi1hdXRob3JzLXZpZXcgY2FuZGlkYXRlczsgbm8gcmVwb3J0IGtleVxcbnByb3Bvc2VkLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQVYtUjQgW01BSk9SXVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBmaXh0dXJlIGNvbHVtbnMvcm93Q291bnQgZmlsZWQgYXMgZGVwZW5kcy1vbi10b2RheSBidXQgZXhpc3RcXG5ub3doZXJlIOKGkiDCpzMuMSBkZXJpdmF0aW9uIHNwZWNpZmllZCAoZmlyc3Qtcm93LCBsYWJlbGVkLCBPKDEpKTsgbW92ZWQgdG9cXG5tdXN0LWVzdGFibGlzaC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkFWLVI1IFtNQUpPUl1cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYXV0aG9yZWQgZml4dHVyZSB0aWVyIHN0YW1wZWQgd2l0aCBjb21wdXRlZCBjaHJvbWUg4oaSIMKnMy4yIHBsYWluXFxubGFiZWxlZCBkYXRhLCBIMiBwcmVjZWRlbnQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJBVi1SNiBbTUFKT1JdXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGZlZWQgc291cmNlIFVSTHMgY2FuIGVtYmVkIGNyZWRlbnRpYWxzOyBHLUFWLTkgdGVzdGVkIG9ubHlcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJzZWNyZXRSZWZcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKGkiDCpzMuMyBhbGxvd2xpc3QgcHJvamVjdGlvbiwgc2NoZW1lK2hvc3Qgc3RyaXBwaW5nLCBHLUFWLTkgZXh0ZW5kZWQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJBVi1SNyBbTUFKT1JdXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHNjYWZmb2xkIFwifTxfY29tcG9uZW50cy5jb2RlPntcIiMgPHRpdGxlPlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdW5pbXBsZW1lbnRhYmxlIChubyBpbnRlcnBvbGF0aW9uLCBubyB0aXRsZVxcbmJpbmRpbmcpIOKGkiBzdGF0aWMgaGVhZGluZzsgZGVmYXVsdCBhbmQgbWF0ZXJpYWxpemVkIHNjYWZmb2xkIHN0YXkgb25lIGRvY3VtZW50LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQVYtUjggW01BSk9SXVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB2ZXJkaWN0cyBzb3VyY2UgdW5waW5uZWQgYWdhaW5zdCB0aGUgaG9vaydzIHNpbmdsZS1jb21wdXRhdGlvblxcbmNvbnRyYWN0IChkb3VibGUgaW5zdGFudGlhdGlvbiBhbHJlYWR5IGxpdmUpOyBmYWxzZSBcXFwibmV2ZXIgc3RhbGVcXFwiIGNsYWltIOKGkiDCpzMuNFxcbmhvaXN0ZWQgc2luZ2xlIHNvdXJjZSwgRy1BVi0xMDsgZnJlc2huZXNzIGNsYWltIGNvcnJlY3RlZC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkFWLVI5IFtNQUpPUl1cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdGhlIGNoYXQtbG9nIGV4Y2x1c2lvbiBpcyBhIHByaXZhY3kgYm91bmRhcnkgbWlzbGFiZWxlZCBhc1xcbm5vbi1zYWZldHkg4oaSIMKnNS4yIHNwbGl0OiBwcm9tcHQgZGlzY2lwbGluZSBsYWJlbGVkIGFzIHN1Y2gsIGh1bWFuIGRpZmYtZ2F0ZSBuYW1lZCBhc1xcbnRoZSBiYWNrc3RvcCwgbWVjaGFuaXNtIGJvb2tlZCAoUTUpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQVYtUjEwIFtNSU5PUl1cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgcHJvbXB0IGRlbHRhIHZpb2xhdGVkIHRoZSBwcm9tcHQncyBvd24gc2NvcGUgbm90ZSBhbmQgZml4ZWQgbG9vcFxcbmVuZHMg4oaSIMKnNS4zIHBvc3QtbG9vcCBzdGFuZGluZyBkdXR5ICsgb25lLXNlbnRlbmNlIHNjb3BlIHdpZGVuaW5nLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQVYtUjExIFtNSU5PUl1cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYW5jaG9yIHRva2VuIG1hdGNoZWQgb25seSBhIGZpbGVuYW1lOyBSLTUgY2l0ZWQgYXMgXFxcImNhdGFsb2dcXFwiIHJpc2tcXG7ihpIgdG9rZW4gcmVwbGFjZWQ7IGNpdGF0aW9uIGNvcnJlY3RlZCB0byBzdGRsaWItcnVsZS1zaGFyZWQtdmlhLXZlcnNpb25pbmcuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJBVi1SMTIgW01JTk9SXVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcXFwidmlzdWFsbHkgZGlzdGluY3RcXFwiIHVuZmFsc2lmaWFibGUg4oaSIEctQVYtNiByZXN0YXRlZCBvdmVyIGNsYXNzZXMuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJBVi1SMTMgW01JTk9SXVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBtb2JpbGUvZG9vciBtZWNoYW5pY3MgdW5kZXItc3BlY2lmaWVkIGZvciBjb2RlIGJsb2NrcyBhbmQgYmFja1xcbmJlaGF2aW9yIOKGkiDCpzEuMi/CpzEuMyBjb25jcmV0aXplZCAob3ZlcmZsb3cgY29udGFpbmVycywgY29sbGFwc2libGUgZ3JvdXBpbmcsIG5vXFxucm91dGluZyBjbGFpbXMpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQVYtUjE0IFtNSU5PUl1cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgc2Vjb25kLXRlbXBsYXRlIHNlc3Npb24gdGhyZWFkaW5nIHVuc3BlY2lmaWVkIOKGkiDCpzMuNS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmhyIC8+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTEyXCIgZGF0YS1zbHVnPVwiMTItb3Blbi1xdWVzdGlvbnNcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy0xMlwiIC8+e1wiMTIuIE9wZW4gcXVlc3Rpb25zXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUTFcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIFRoZSBcXFwiY3VzdG9taXplXFxcIiBhZmZvcmRhbmNlIChtYXRlcmlhbGl6ZSB0aGUgc2NhZmZvbGQpOiBsYW5kcyB3aXRoIHRoZVxcbmRvY3VtZW50IHdyaXRlIHBhdGg7IHdobyBvd25zIHRoZSBmaWxlLWNvbGxpc2lvbiBydWxlIChhIHN0cmF5IFwifTxfY29tcG9uZW50cy5jb2RlPntcImF1dGhvcnNfdmlldy5tZHhcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxucHJlc2VudCBidXQgbWFuaWZlc3Qtb3ZlcnJpZGRlbik/XCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJRMlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgSW5kZXgtcm93IGRlZXAgbGlua3MgaW50byB0aGUgZWRpdG9yIChmaWxlICsgbGluZSk6IGNvbXBvc2Ugd2l0aCB0aGVcXG5uYXZpZ2F0b3Igd29yayBhbmQgUjMtNDI3IG9uY2Ugc3BhbnMgZXhpc3QuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJRM1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgU2hvdWxkIHRoZSBjb250cmlidXRlL3JldmlldyBzdXJmYWNlIHJlbmRlciB0aGUgYXV0aG9yJ3MtdmlldyBcIn08X2NvbXBvbmVudHMuZW0+e1wiZGlmZlwifTwvX2NvbXBvbmVudHMuZW0+e1wiXFxuc3BlY2lhbGx5IChuYXJyYXRpdmUgYmVzaWRlIGZvcm11bGEvdGVzdCBkaWZmcyksIG9yIGlzIHRoZSBwbGFpbiBmaWxlIGRpZmYgZW5vdWdoP1wifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUTRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIFdoZW4gdGhlIGFzc2lzdGFudCByZWFsbSBsYW5kczogZG9lcyByZWNvcmQtdGhlLWRlY2lzaW9uIGNyZWF0ZVxcblwifTxfY29tcG9uZW50cy5jb2RlPntcImF1dGhvcnNfdmlldy5tZHhcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICh0YWtpbmcgb3duZXJzaGlwIG9uIHRoZSBhdXRob3IncyBiZWhhbGYpIG9yIHJlcXVpcmUgaXQgdG8gZXhpc3Q/XCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJRNVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgQSBtZWNoYW5pY2FsIGJhY2tzdG9wIGZvciB0aGUgwqc1LjIgcHJpdmFjeSBib3VuZGFyeSAoZS5nLiwgdGhlIGNvbnRyaWJ1dGVcXG5nYXRlIGZsYWdnaW5nIHRyYW5zY3JpcHQtc2hhcGVkIGNvbnRlbnQgaW4gRGVjaXNpb25zIGRpZmZzKSDigJQgd29ydGggaXRzXFxuZmFsc2UtcG9zaXRpdmUgY29zdD9cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+PC8+O1xufVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTURYQ29udGVudChwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHt3cmFwcGVyOiBNRFhMYXlvdXR9ID0ge1xuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfTtcbiAgcmV0dXJuIE1EWExheW91dCA/IDxNRFhMYXlvdXQgey4uLnByb3BzfT48X2NyZWF0ZU1keENvbnRlbnQgey4uLnByb3BzfSAvPjwvTURYTGF5b3V0PiA6IF9jcmVhdGVNZHhDb250ZW50KHByb3BzKTtcbn1cbmZ1bmN0aW9uIF9taXNzaW5nTWR4UmVmZXJlbmNlKGlkLCBjb21wb25lbnQsIHBsYWNlKSB7XG4gIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIFwiICsgKGNvbXBvbmVudCA/IFwiY29tcG9uZW50XCIgOiBcIm9iamVjdFwiKSArIFwiIGBcIiArIGlkICsgXCJgIHRvIGJlIGRlZmluZWQ6IHlvdSBsaWtlbHkgZm9yZ290IHRvIGltcG9ydCwgcGFzcywgb3IgcHJvdmlkZSBpdC5cIiArIChwbGFjZSA/IFwiXFxuSXTigJlzIHJlZmVyZW5jZWQgaW4geW91ciBjb2RlIGF0IGBcIiArIHBsYWNlICsgXCJgIGluIGAvYXBwL2RvY3Mvc3BlY3MvQVVUSE9SU19WSUVXX1NQRUMubWRgXCIgOiBcIlwiKSk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUVBLElBQUFBLFlBQUEsR0FBQUMsT0FBQTtBQUF3RixJQUFBQyxXQUFBLEdBQUFELE9BQUE7QUFGeEY7QUFDQTs7QUFFQSxTQUFTRSxpQkFBaUJBLENBQUNDLEtBQUssRUFBRTtFQUNoQyxNQUFNQyxXQUFXLEdBQUc7TUFDbEJDLFVBQVUsRUFBRSxZQUFZO01BQ3hCQyxJQUFJLEVBQUUsTUFBTTtNQUNaQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxDQUFDLEVBQUUsR0FBRztNQUNOQyxHQUFHLEVBQUUsS0FBSztNQUNWQyxNQUFNLEVBQUUsUUFBUTtNQUNoQkMsS0FBSyxFQUFFLE9BQU87TUFDZEMsS0FBSyxFQUFFLE9BQU87TUFDZEMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsS0FBSyxFQUFFLE9BQU87TUFDZEMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUixHQUFHLElBQUFDLDZCQUFrQixFQUFDLENBQUM7TUFDdkIsR0FBR3BCLEtBQUssQ0FBQ3FCO0lBQ1gsQ0FBQztJQUFFO01BQUNDO0lBQWEsQ0FBQyxHQUFHckIsV0FBVztFQUNoQyxJQUFJLENBQUNxQixhQUFhLEVBQUVDLG9CQUFvQixDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUM7RUFDL0Qsb0JBQU8sSUFBQXpCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQTFCLFdBQUEsQ0FBQTJCLFFBQUE7SUFBQUMsUUFBQSxnQkFBRSxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDSSxFQUFFO01BQUNzQixFQUFFLEVBQUMsb0ZBQW9GO01BQUFELFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBb0YsQ0FBRSxDQUFDLEVBQUMsd0ZBQXdGO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUyxDQUFDO01BQUFnQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVMsQ0FBcUIsQ0FBQyxFQUFDLDRJQUE0SSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVUsQ0FBcUIsQ0FBQyxFQUFDLGFBQWE7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNTLENBQUM7TUFBQWdCLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDRyxFQUFFO1FBQUFzQixRQUFBLEdBQUUsbU1BQW1NLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQVUsQ0FBbUIsQ0FBQyxFQUFDLG1HQUFtRztNQUFBLENBQWlCO0lBQUMsQ0FBZSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNDLFVBQVU7TUFBQXdCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1MsQ0FBQztRQUFBZ0IsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsR0FBRSw0REFBNEQsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1lBQUF1QixRQUFBLEVBQUU7VUFBb0MsQ0FBbUIsQ0FBQztRQUFBLENBQW9CLENBQUMsRUFBQyx3RUFBd0U7TUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQXlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ0MsVUFBVTtNQUFBd0IsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUyxDQUFDO1FBQUFnQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWMsQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBc0IsQ0FBbUIsQ0FBQyxFQUFDLHNGQUFzRixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUEwQixDQUFtQixDQUFDLEVBQUMsbUlBQW1JLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQTBCLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQXVCLENBQW1CLENBQUMsRUFBQyw0R0FBNEcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBa0MsQ0FBbUIsQ0FBQyxFQUFDLDZEQUE2RCxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUErQixDQUFtQixDQUFDLEVBQUMsNEJBQTRCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQWtCLENBQW1CLENBQUMsRUFBQyxtQ0FBbUM7TUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQXlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ08sRUFBRSxJQUFFLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQVYsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDSyxFQUFFO01BQUNxQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUsd0NBQXdDO01BQUFELFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQyxjQUFjLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBc0IsUUFBQSxFQUFFO01BQWtDLENBQWlCLENBQUM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNTLENBQUM7TUFBQWdCLFFBQUEsR0FBRSwyREFBMkQsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxFQUFFO1FBQUFzQixRQUFBLEVBQUU7TUFBdUIsQ0FBaUIsQ0FBQyxFQUFDLHVRQUF1USxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLEVBQUU7UUFBQXNCLFFBQUEsRUFBRTtNQUFVLENBQWlCLENBQUMsRUFBQywySEFBMkg7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNTLENBQUM7TUFBQWdCLFFBQUEsR0FBRSxNQUFNLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBZSxDQUFxQixDQUFDLEVBQUMsa0xBQWtMO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDa0IsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBOEMsQ0FBcUIsQ0FBQyxFQUFDLDZDQUE2QyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLEVBQUU7VUFBQXNCLFFBQUEsRUFBRTtRQUFVLENBQWlCLENBQUMsRUFBQyw0QkFBNEIsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUF1QixDQUFxQixDQUFDLEVBQUMsK0ZBQStGO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWdDLENBQXFCLENBQUMsRUFBQyxxR0FBcUcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUE0QixDQUFxQixDQUFDLEVBQUMsMkJBQTJCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBZ0IsQ0FBcUIsQ0FBQyxFQUFDLDBRQUEwUTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDUyxDQUFDO01BQUFnQixRQUFBLEVBQUU7SUFBbUssQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDTyxFQUFFLElBQUUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBVixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNLLEVBQUU7TUFBQ3FCLEVBQUUsRUFBQyxPQUFPO01BQUMsYUFBVSxnREFBZ0Q7TUFBQUQsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLHNCQUFzQixlQUFDLElBQUE3QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLEVBQUU7UUFBQXNCLFFBQUEsRUFBRTtNQUFrQyxDQUFpQixDQUFDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDTSxFQUFFO01BQUNvQixFQUFFLEVBQUMsU0FBUztNQUFDLGFBQVUsd0NBQXdDO01BQUFELFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBUyxDQUFFLENBQUMsRUFBQywwQ0FBMEM7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNrQixFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxHQUFFLE9BQU8sZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFJLENBQXFCLENBQUMsRUFBQyw2REFBNkQsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUF3QixDQUFxQixDQUFDLEVBQUMsaUlBQWlJO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLEdBQUUsNEJBQTRCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQTRCLENBQW1CLENBQUMsRUFBQyw2Q0FBNkMsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBYSxDQUFtQixDQUFDLEVBQUMsNkJBQTZCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBSSxDQUFxQixDQUFDLEVBQUMsaU9BQWlPO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNNLEVBQUU7TUFBQ29CLEVBQUUsRUFBQyxTQUFTO01BQUMsYUFBVSw4QkFBOEI7TUFBQUQsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFTLENBQUUsQ0FBQyxFQUFDLGdDQUFnQztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLG1DQUFtQyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQWdCLENBQXFCLENBQUMsRUFBQyw4SkFBOEo7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNrQixFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxHQUFFLGtFQUFrRSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXlCLENBQXFCLENBQUMsRUFBQyxpRUFBaUUsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFpQixDQUFxQixDQUFDLEVBQUMsVUFBVTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxHQUFFLGdEQUFnRCxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXFDLENBQXFCLENBQUMsRUFBQyxvS0FBb0s7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsRUFBRTtNQUFxRSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDb0IsRUFBRSxFQUFDLFNBQVM7TUFBQyxhQUFVLG1CQUFtQjtNQUFBRCxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVMsQ0FBRSxDQUFDLEVBQUMsc0JBQXNCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUyxDQUFDO01BQUFnQixRQUFBLEdBQUUscUpBQXFKLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBcUUsQ0FBcUIsQ0FBQyxFQUFDLG9FQUFvRSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQThDLENBQXFCLENBQUMsRUFBQywwTEFBMEw7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNPLEVBQUUsSUFBRSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFWLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDcUIsRUFBRSxFQUFDLE9BQU87TUFBQyxhQUFVLDBEQUEwRDtNQUFBRCxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMsZ0NBQWdDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBc0IsUUFBQSxFQUFFO01BQWtDLENBQWlCLENBQUM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNTLENBQUM7TUFBQWdCLFFBQUEsR0FBRSx3Q0FBd0MsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUF1RCxDQUFxQixDQUFDLEVBQUMsc1JBQXNSO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDWSxLQUFLO01BQUFhLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2dCLEtBQUs7UUFBQVMsUUFBQSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNpQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBVyxDQUFpQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDZSxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFZLENBQWlCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNlLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQVMsQ0FBaUIsQ0FBQztRQUFBLENBQWdCO01BQUMsQ0FBbUIsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2EsS0FBSztRQUFBWSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNpQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQWtCLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQW9CLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEdBQUUsOEZBQThGLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQUssQ0FBbUIsQ0FBQyxFQUFDLDZFQUE2RTtVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDaUIsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFlLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFvQixDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFrQixDQUFtQixDQUFDO1VBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBOEYsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNpQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQW1CLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQTZCLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEdBQUUsNkNBQTZDLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBVSxDQUFxQixDQUFDLEVBQUMseUZBQXlGO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNpQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQWtCLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBRyxDQUFpQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsR0FBRSwyQ0FBMkMsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLCtCQUErQjtVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDO01BQUEsQ0FBbUIsQ0FBQztJQUFBLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDb0IsRUFBRSxFQUFDLFNBQVM7TUFBQyxhQUFVLGtDQUFrQztNQUFBRCxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVMsQ0FBRSxDQUFDLEVBQUMsbUNBQW1DO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUyxDQUFDO01BQUFnQixRQUFBLEdBQUUsMERBQTBELGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBVSxDQUFxQixDQUFDLEVBQUMsNExBQTRMO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDTSxFQUFFO01BQUNvQixFQUFFLEVBQUMsU0FBUztNQUFDLGFBQVUsNEJBQTRCO01BQUFELFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBUyxDQUFFLENBQUMsRUFBQyw4QkFBOEI7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNrQixFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxHQUFFLG9DQUFvQyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFxQixDQUFtQixDQUFDLEVBQUMseUJBQXlCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBYyxDQUFxQixDQUFDLEVBQUMsc0dBQXNHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLEdBQUUsdUNBQXVDLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBb0IsQ0FBcUIsQ0FBQyxFQUFDLHFMQUFxTDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDTSxFQUFFO01BQUNvQixFQUFFLEVBQUMsU0FBUztNQUFDLGFBQVUsaUZBQWlGO01BQUFELFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBUyxDQUFFLENBQUMsRUFBQyxvRkFBb0Y7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNTLENBQUM7TUFBQWdCLFFBQUEsRUFBRTtJQUEwUCxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNrQixFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFtQyxDQUFxQixDQUFDLEVBQUMsNERBQTRELGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQWdCLENBQW1CLENBQUMsRUFBQyx5QkFBeUIsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUErQixDQUFxQixDQUFDLEVBQUMsbUVBQW1FLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLGlFQUFpRSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQyxzSEFBc0g7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBZ0QsQ0FBcUIsQ0FBQyxFQUFDLGNBQWM7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ08sRUFBRSxJQUFFLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQVYsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDSyxFQUFFO01BQUNxQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUsb0RBQW9EO01BQUFELFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQywwQkFBMEIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxFQUFFO1FBQUFzQixRQUFBLEVBQUU7TUFBa0MsQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLCtCQUErQixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQWlCLENBQXFCLENBQUMsRUFBQyxlQUFlLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQVksQ0FBbUIsQ0FBQyxFQUFDLDJCQUEyQixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFVLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQVksQ0FBbUIsQ0FBQyxFQUFDLHFEQUFxRDtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1UsR0FBRztNQUFBZSxRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFDMEIsU0FBUyxFQUFDLGFBQWE7UUFBQUgsUUFBQSxFQUFFO01BQThjLENBQW1CO0lBQUMsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUyxDQUFDO01BQUFnQixRQUFBLEdBQUUsd0lBQXdJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBMkMsQ0FBcUIsQ0FBQyxFQUFDLHFCQUFxQixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLEVBQUU7UUFBQXNCLFFBQUEsRUFBRTtNQUFPLENBQWlCLENBQUMsRUFBQyxvRUFBb0UsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUE0QyxDQUFxQixDQUFDLEVBQUMsVUFBVTtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDb0IsRUFBRSxFQUFDLFNBQVM7TUFBQyxhQUFVLCtDQUErQztNQUFBRCxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVMsQ0FBRSxDQUFDLEVBQUMsbURBQW1EO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUyxDQUFDO01BQUFnQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFhLENBQW1CLENBQUMsRUFBQyxXQUFXLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQU0sQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBTSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFZLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBdUQsQ0FBcUIsQ0FBQyxFQUFDLHlFQUF5RSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUF3QixDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFTLENBQW1CLENBQUMsRUFBQyxxQkFBcUIsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFXLENBQXFCLENBQUMsRUFBQywwVEFBMFQsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFnQixDQUFxQixDQUFDLEVBQUMseUJBQXlCO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDTSxFQUFFO01BQUNvQixFQUFFLEVBQUMsU0FBUztNQUFDLGFBQVUsaUVBQWlFO01BQUFELFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBUyxDQUFFLENBQUMsRUFBQyxzRUFBc0U7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNTLENBQUM7TUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQW1CLENBQW1CLENBQUMsRUFBQyxNQUFNLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBc0IsUUFBQSxFQUFFO01BQXVELENBQWlCLENBQUMsRUFBQyxpRkFBaUYsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFpRCxDQUFxQixDQUFDLEVBQUMsa09BQWtPO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDTSxFQUFFO01BQUNvQixFQUFFLEVBQUMsU0FBUztNQUFDLGFBQVUsa0VBQWtFO01BQUFELFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBUyxDQUFFLENBQUMsRUFBQyxzRUFBc0U7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNTLENBQUM7TUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQWEsQ0FBbUIsQ0FBQyxFQUFDLFlBQVksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsR0FBRSxxQ0FBcUMsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBWSxDQUFtQixDQUFDO01BQUEsQ0FBb0IsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBd0IsQ0FBbUIsQ0FBQyxFQUFDLFVBQVUsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBTyxDQUFtQixDQUFDLEVBQUMsa0NBQWtDLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBcUIsQ0FBcUIsQ0FBQyxFQUFDLDhGQUE4RixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFZLENBQW1CLENBQUMsRUFBQywyQkFBMkIsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLHlFQUF5RSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFXLENBQW1CLENBQUMsRUFBQyx5Q0FBeUMsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBaUIsQ0FBbUIsQ0FBQyxFQUFDLDhHQUE4RztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDb0IsRUFBRSxFQUFDLFNBQVM7TUFBQyxhQUFVLDBEQUEwRDtNQUFBRCxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVMsQ0FBRSxDQUFDLEVBQUMsOERBQThEO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUyxDQUFDO01BQUFnQixRQUFBLEdBQUUsd0NBQXdDLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBeUIsQ0FBcUIsQ0FBQyxFQUFDLG9DQUFvQyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFhLENBQW1CLENBQUMsRUFBQywwaEJBQTBoQjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDb0IsRUFBRSxFQUFDLFNBQVM7TUFBQyxhQUFVLGdEQUFnRDtNQUFBRCxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVMsQ0FBRSxDQUFDLEVBQUMsbURBQW1EO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUyxDQUFDO01BQUFnQixRQUFBLEdBQUUsc0JBQXNCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBZ0IsQ0FBcUIsQ0FBQyxFQUFDLDZWQUE2VixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQU0sQ0FBcUIsQ0FBQyxFQUFDLGVBQWUsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBVSxDQUFtQixDQUFDLEVBQUMscUhBQXFILGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBdUIsUUFBQSxFQUFFO01BQWlCLENBQW1CLENBQUMsRUFBQyw4Q0FBOEM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNPLEVBQUUsSUFBRSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFWLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDcUIsRUFBRSxFQUFDLE9BQU87TUFBQyxhQUFVLG1EQUFtRDtNQUFBRCxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMseUJBQXlCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBc0IsUUFBQSxFQUFFO01BQWtDLENBQWlCLENBQUM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNrQixFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxHQUFFLDZCQUE2QixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7WUFBQXVCLFFBQUEsRUFBRTtVQUFjLENBQW1CO1FBQUMsQ0FBb0IsQ0FBQyxFQUFDLDJGQUEyRixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7WUFBQXVCLFFBQUEsRUFBRTtVQUFhLENBQW1CO1FBQUMsQ0FBb0IsQ0FBQyxFQUFDLG9EQUFvRDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxHQUFFLGdDQUFnQyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXlDLENBQXFCLENBQUMsRUFBQyxvRkFBb0YsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMseUJBQXlCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBd0IsQ0FBcUIsQ0FBQyxFQUFDLDhEQUE4RCxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFRLENBQW1CLENBQUMsRUFBQyxxSkFBcUo7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ08sRUFBRSxJQUFFLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQVYsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDSyxFQUFFO01BQUNxQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUsMEVBQTBFO01BQUFELFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQyxnREFBZ0QsZUFBQyxJQUFBN0IsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxFQUFFO1FBQUFzQixRQUFBLEVBQUU7TUFBa0MsQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDb0IsRUFBRSxFQUFDLFNBQVM7TUFBQyxhQUFVLGlCQUFpQjtNQUFBRCxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVMsQ0FBRSxDQUFDLEVBQUMsa0JBQWtCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDUyxDQUFDO01BQUFnQixRQUFBLEVBQUU7SUFBbU8sQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVSxHQUFHO01BQUFlLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1FBQUMwQixTQUFTLEVBQUMsY0FBYztRQUFBSCxRQUFBLEVBQUU7TUFBcVIsQ0FBbUI7SUFBQyxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNNLEVBQUU7TUFBQ29CLEVBQUUsRUFBQyxTQUFTO01BQUMsYUFBVSwwQ0FBMEM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFTLENBQUUsQ0FBQyxFQUFDLDZDQUE2QztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1MsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLE1BQU0sZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1FBQUF1QixRQUFBLEVBQUU7TUFBZSxDQUFtQixDQUFDLEVBQUMsMkZBQTJGLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBc0IsUUFBQSxFQUFFO01BQW1DLENBQWlCLENBQUMsRUFBQyxpSEFBaUg7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNrQixFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUErQyxDQUFxQixDQUFDLEVBQUMsaUlBQWlJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBOEMsQ0FBcUIsQ0FBQyxFQUFDLDhNQUE4TSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTRDLENBQXFCLENBQUMsRUFBQyxpRUFBaUU7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBcUIsQ0FBcUIsQ0FBQyxFQUFDLFlBQVksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxFQUFFO1VBQUFzQixRQUFBLEVBQUU7UUFBUSxDQUFpQixDQUFDLEVBQUMsNE1BQTRNO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWdDLENBQXFCLENBQUMsRUFBQyxnSkFBZ0o7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDb0IsRUFBRSxFQUFDLFNBQVM7TUFBQyxhQUFVLG1CQUFtQjtNQUFBRCxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVMsQ0FBRSxDQUFDLEVBQUMsb0JBQW9CO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUyxDQUFDO01BQUFnQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUE0QyxDQUFtQixDQUFDLEVBQUMsV0FBVyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQXlCLENBQXFCLENBQUMsRUFBQyx3VkFBd1YsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxFQUFFO1FBQUFzQixRQUFBLEVBQUU7TUFBTSxDQUFpQixDQUFDLEVBQUMsZ0ZBQWdGLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBc0IsUUFBQSxFQUFFO01BQWtCLENBQWlCLENBQUMsRUFBQyx5S0FBeUs7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNPLEVBQUUsSUFBRSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFWLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDcUIsRUFBRSxFQUFDLE9BQU87TUFBQyxhQUFVLHFHQUFxRztNQUFBRCxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMseURBQXlELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBc0IsUUFBQSxFQUFFO01BQXVELENBQWlCLENBQUM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNTLENBQUM7TUFBQWdCLFFBQUEsR0FBRSxxRUFBcUUsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFXLENBQXFCLENBQUMsRUFBQyx3REFBd0QsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxFQUFFO1FBQUFzQixRQUFBLEVBQUU7TUFBOEUsQ0FBaUIsQ0FBQyxFQUFDLHFEQUFxRCxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7UUFBQXVCLFFBQUEsRUFBRTtNQUFrQixDQUFtQixDQUFDLEVBQUMsa0xBQWtMLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBc0IsUUFBQSxFQUFFO01BQU8sQ0FBaUIsQ0FBQyxFQUFDLHlCQUF5QixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLEVBQUU7UUFBQXNCLFFBQUEsRUFBRTtNQUFPLENBQWlCLENBQUMsRUFBQyxvSUFBb0ksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxFQUFFO1FBQUFzQixRQUFBLEVBQUU7TUFBWSxDQUFpQixDQUFDLEVBQUMsdUVBQXVFO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUyxDQUFDO01BQUFnQixRQUFBLEdBQUUsWUFBWSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQWtFLENBQXFCLENBQUM7SUFBQSxDQUFlLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2tCLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQVksQ0FBcUIsQ0FBQyxFQUFDLHFEQUFxRCxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXdCLENBQXFCLENBQUMsRUFBQyx3Q0FBd0M7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBYyxDQUFxQixDQUFDLEVBQUMsbUNBQW1DLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBTSxDQUFxQixDQUFDLEVBQUMsbU1BQW1NO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNTLENBQUM7TUFBQWdCLFFBQUEsRUFBRTtJQUF3RCxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNrQixFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFpRCxDQUFxQixDQUFDLEVBQUMsME1BQTBNO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTRCLENBQXFCLENBQUMsRUFBQyw0TEFBNEw7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBeUMsQ0FBcUIsQ0FBQyxFQUFDLHNEQUFzRCxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyx5Q0FBeUM7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ08sRUFBRSxJQUFFLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQVYsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDSyxFQUFFO01BQUNxQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUseUZBQXlGO01BQUFELFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQywwQ0FBMEMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxFQUFFO1FBQUFzQixRQUFBLEVBQUU7TUFBMEQsQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2tCLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTBCLENBQXFCLENBQUMsRUFBQyw2Q0FBNkMsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBWSxDQUFtQixDQUFDLEVBQUMsbUpBQW1KO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTBCLENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQXVCLENBQW1CLENBQUMsRUFBQyx3SUFBd0k7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBcUIsQ0FBcUIsQ0FBQyxFQUFDLDhGQUE4RjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUErQixDQUFxQixDQUFDLEVBQUMsc0hBQXNIO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWtELENBQXFCLENBQUMsRUFBQyx1TUFBdU07TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ08sRUFBRSxJQUFFLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQVYsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDSyxFQUFFO01BQUNxQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUsaUVBQWlFO01BQUFELFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQyxZQUFZLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBc0IsUUFBQSxFQUFFO01BQThELENBQWlCLENBQUM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNZLEtBQUs7TUFBQWEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDZ0IsS0FBSztRQUFBUyxRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDZSxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFNLENBQWlCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNlLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQU0sQ0FBaUIsQ0FBQztRQUFBLENBQWdCO01BQUMsQ0FBbUIsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2EsS0FBSztRQUFBWSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNpQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBUSxDQUFxQjtVQUFDLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQXlMLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDaUIsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQVEsQ0FBcUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsR0FBRSxtQkFBbUIsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBa0IsQ0FBbUIsQ0FBQyxFQUFDLHlEQUF5RCxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFrQixDQUFtQixDQUFDLEVBQUMsdUdBQXVHO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNpQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBUSxDQUFxQjtVQUFDLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxHQUFFLG1GQUFtRixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUF3QixDQUFtQixDQUFDLEVBQUMsU0FBUyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFRLENBQW1CLENBQUMsRUFBQyxnSEFBZ0g7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFRLENBQXFCO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEdBQUUsaUJBQWlCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQWEsQ0FBbUIsQ0FBQyxFQUFDLDJHQUEyRztVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDaUIsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQVEsQ0FBcUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQXNDLENBQW1CLENBQUMsRUFBQywyRkFBMkY7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFRLENBQXFCO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEdBQUUsbUtBQW1LLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQWdCLENBQW1CLENBQUMsRUFBQyxrQkFBa0IsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFTLENBQXFCLENBQUMsRUFBQyw2Q0FBNkMsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBYyxDQUFtQixDQUFDLEVBQUMscUVBQXFFO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNpQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBUSxDQUFxQjtVQUFDLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQXNOLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDaUIsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQVEsQ0FBcUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUF1RixDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFRLENBQXFCO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFlLENBQW1CLENBQUMsRUFBQyxnTkFBZ04sZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBWSxDQUFtQixDQUFDLEVBQUMsWUFBWSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQVMsQ0FBcUIsQ0FBQyxFQUFDLDJDQUEyQyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFXLENBQW1CLENBQUMsRUFBQyxpQ0FBaUM7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFTLENBQXFCO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEdBQUUsbUlBQW1JLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQWEsQ0FBbUIsQ0FBQyxFQUFDLDhDQUE4QztVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDO01BQUEsQ0FBbUIsQ0FBQztJQUFBLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ08sRUFBRSxJQUFFLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQVYsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDSyxFQUFFO01BQUNxQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUsa0RBQWtEO01BQUFELFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQyw4Q0FBOEMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxFQUFFO1FBQUFzQixRQUFBLEVBQUU7TUFBWSxDQUFpQixDQUFDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDTSxFQUFFO01BQUNvQixFQUFFLEVBQUMsd0NBQXdDO01BQUFELFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBd0MsQ0FBRSxDQUFDLEVBQUMsMENBQTBDO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDWSxLQUFLO01BQUFhLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2dCLEtBQUs7UUFBQVMsUUFBQSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNpQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBWSxDQUFpQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDZSxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUE2QixDQUFpQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDZSxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFxQixDQUFpQixDQUFDO1FBQUEsQ0FBZ0I7TUFBQyxDQUFtQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDYSxLQUFLO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFxRixDQUFpQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBdUIsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBcUMsQ0FBbUI7VUFBQyxDQUFnQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsR0FBRSx1Q0FBdUMsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBYyxDQUFtQixDQUFDLEVBQUMsb0JBQW9CLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQWEsQ0FBbUIsQ0FBQztVQUFBLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFnQyxDQUFtQjtVQUFDLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUF5QixDQUFtQjtVQUFDLENBQWdCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDaUIsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxHQUFFLDhCQUE4QixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFZLENBQW1CLENBQUMsRUFBQyxpQ0FBaUM7VUFBQSxDQUFpQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBZ0MsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBNEIsQ0FBbUI7VUFBQyxDQUFnQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFrRSxDQUFpQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBd0IsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBa0MsQ0FBbUI7VUFBQyxDQUFnQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsR0FBRSw4Q0FBOEMsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBUSxDQUFtQixDQUFDLEVBQUMsbURBQW1EO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQTBCLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQW1CLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNpQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBb0gsQ0FBaUIsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQTJCLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQWdCLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNpQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBcUUsQ0FBaUIsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQTBCLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQWtCLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNpQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBNkUsQ0FBaUIsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQStCLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQWUsQ0FBbUI7VUFBQyxDQUFnQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsR0FBRSxpREFBaUQsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFJLENBQXFCLENBQUMsRUFBQyxzQ0FBc0M7VUFBQSxDQUFpQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBdUIsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBMkIsQ0FBbUI7VUFBQyxDQUFnQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsR0FBRSxnQkFBZ0IsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBUSxDQUFtQixDQUFDLEVBQUMsd0NBQXdDO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQXVCLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBdUIsUUFBQSxFQUFFO1lBQVEsQ0FBbUI7VUFBQyxDQUFnQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFtRSxDQUFpQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBMkIsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBbUIsQ0FBbUI7VUFBQyxDQUFnQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUE2RCxDQUFpQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBNEMsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBb0IsQ0FBbUI7VUFBQyxDQUFnQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFnQyxDQUFpQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBNEIsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO2NBQUF1QixRQUFBLEVBQUU7WUFBcUIsQ0FBbUI7VUFBQyxDQUFnQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQztNQUFBLENBQW1CLENBQUM7SUFBQSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNNLEVBQUU7TUFBQ29CLEVBQUUsRUFBQywwREFBMEQ7TUFBQUQsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUEwRCxDQUFFLENBQUMsRUFBQyw0REFBNEQ7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNZLEtBQUs7TUFBQWEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDZ0IsS0FBSztRQUFBUyxRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDZSxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFlLENBQWlCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNlLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQXVCLENBQWlCLENBQUM7UUFBQSxDQUFnQjtNQUFDLENBQW1CLENBQUMsbUJBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNhLEtBQUs7UUFBQVksUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDaUIsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQThFLENBQWlCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQWlCLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDaUIsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQTBFLENBQWlCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQVEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNpQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFhLENBQW1CLENBQUMsRUFBQyxpREFBaUQ7VUFBQSxDQUFpQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFRLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDaUIsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxHQUFFLDREQUE0RCxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7Y0FBQXVCLFFBQUEsRUFBRTtZQUFhLENBQW1CLENBQUMsRUFBQyxVQUFVO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBd0IsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNpQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBZ0UsQ0FBaUIsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBUSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFrRixDQUFpQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFRLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDaUIsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQWlGLENBQWlCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQVEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNpQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBMkMsQ0FBaUIsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBUSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQztNQUFBLENBQW1CLENBQUM7SUFBQSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNPLEVBQUUsSUFBRSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFWLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDcUIsRUFBRSxFQUFDLFFBQVE7TUFBQyxhQUFVLDhEQUE4RDtNQUFBRCxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVEsQ0FBRSxDQUFDLEVBQUMseUNBQXlDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBc0IsUUFBQSxFQUFFO01BQWdDLENBQWlCLENBQUM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNrQixFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUErRCxDQUFxQixDQUFDLEVBQUMsdUpBQXVKLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBc0IsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLDJIQUEySDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUF1RCxDQUFxQixDQUFDLEVBQUMsNEtBQTRLLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBc0IsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLHlKQUF5SjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFpRixDQUFxQixDQUFDLEVBQUMsOEVBQThFLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBc0IsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLCtJQUErSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUF1QyxDQUFxQixDQUFDLEVBQUMsZ0dBQWdHLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBc0IsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLG9GQUFvRjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFvRSxDQUFxQixDQUFDLEVBQUMsdUdBQXVHLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBc0IsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLHNEQUFzRDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUF5RSxDQUFxQixDQUFDLEVBQUMsb0tBQW9LLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBc0IsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLG1DQUFtQyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUMsRUFBQywyQkFBMkI7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBK0MsQ0FBcUIsQ0FBQyxFQUFDLGtDQUFrQyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLEVBQUU7VUFBQXNCLFFBQUEsRUFBRTtRQUFXLENBQWlCLENBQUMsRUFBQyw0RUFBNEU7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBNkQsQ0FBcUIsQ0FBQyxFQUFDLGlDQUFpQyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLEVBQUU7VUFBQXNCLFFBQUEsRUFBRTtRQUFXLENBQWlCLENBQUMsRUFBQyxrQ0FBa0M7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEdBQUUsc0JBQXNCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBdUIsUUFBQSxFQUFFO1VBQVcsQ0FBbUIsQ0FBQztRQUFBLENBQW9CLENBQUMsRUFBQyw2QkFBNkIsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxFQUFFO1VBQUFzQixRQUFBLEVBQUU7UUFBa0IsQ0FBaUIsQ0FBQyxFQUFDLGdEQUFnRDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUE0SCxDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLEVBQUU7VUFBQXNCLFFBQUEsRUFBRTtRQUFXLENBQWlCLENBQUMsRUFBQyxzRkFBc0Y7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ08sRUFBRSxJQUFFLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQVYsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDSyxFQUFFO01BQUNxQixFQUFFLEVBQUMsUUFBUTtNQUFDLGFBQVUsOEJBQThCO01BQUFELFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBUSxDQUFFLENBQUMsRUFBQywwQkFBMEIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxFQUFFO1FBQUFzQixRQUFBLEVBQUU7TUFBVSxDQUFpQixDQUFDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDUyxDQUFDO01BQUFnQixRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBaUYsQ0FBcUI7SUFBQyxDQUFlLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2tCLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWlCLENBQXFCLENBQUMsRUFBQywrTkFBK047TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBaUIsQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLDRNQUE0TTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFlLENBQXFCLENBQUMsRUFBQyxtRkFBbUYsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRSxJQUFJO1VBQUF1QixRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsNEVBQTRFO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWUsQ0FBcUIsQ0FBQyxFQUFDLDBKQUEwSjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFlLENBQXFCLENBQUMsRUFBQywrRkFBK0Y7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBZSxDQUFxQixDQUFDLEVBQUMsK0RBQStELGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLHVFQUF1RTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFlLENBQXFCLENBQUMsRUFBQyxZQUFZLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBdUIsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLCtIQUErSDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFlLENBQXFCLENBQUMsRUFBQywrTUFBK007TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBZSxDQUFxQixDQUFDLEVBQUMseUxBQXlMO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWdCLENBQXFCLENBQUMsRUFBQyx1SUFBdUk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBZ0IsQ0FBcUIsQ0FBQyxFQUFDLGtKQUFrSjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFnQixDQUFxQixDQUFDLEVBQUMsc0VBQXNFO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWdCLENBQXFCLENBQUMsRUFBQyxvS0FBb0s7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNRLEVBQUU7UUFBQWlCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBZ0IsQ0FBcUIsQ0FBQyxFQUFDLHdEQUF3RDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDTyxFQUFFLElBQUUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBVixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNLLEVBQUU7TUFBQ3FCLEVBQUUsRUFBQyxRQUFRO01BQUMsYUFBVSxtQkFBbUI7TUFBQUQsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFRLENBQUUsQ0FBQyxFQUFDLG9CQUFvQjtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2tCLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQUksQ0FBcUIsQ0FBQyxFQUFDLDZJQUE2SSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFrQixDQUFtQixDQUFDLEVBQUMscUNBQXFDO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQUksQ0FBcUIsQ0FBQyxFQUFDLHNIQUFzSDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBaUIsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFJLENBQXFCLENBQUMsRUFBQyxtRUFBbUUsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxFQUFFO1VBQUFzQixRQUFBLEVBQUU7UUFBTSxDQUFpQixDQUFDLEVBQUMsc0ZBQXNGO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQUksQ0FBcUIsQ0FBQyxFQUFDLHNFQUFzRSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNFLElBQUk7VUFBQXVCLFFBQUEsRUFBRTtRQUFrQixDQUFtQixDQUFDLEVBQUMsb0VBQW9FO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUSxFQUFFO1FBQUFpQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQUksQ0FBcUIsQ0FBQyxFQUFDLDZLQUE2SztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQztFQUFBLENBQUUsQ0FBQztBQUM1OW5EO0FBQ2UsU0FBU0ksVUFBVUEsQ0FBQzlCLEtBQUssR0FBRyxDQUFDLENBQUMsRUFBRTtFQUM3QyxNQUFNO0lBQUMrQixPQUFPLEVBQUVDO0VBQVMsQ0FBQyxHQUFHO0lBQzNCLEdBQUcsSUFBQVosNkJBQWtCLEVBQUMsQ0FBQztJQUN2QixHQUFHcEIsS0FBSyxDQUFDcUI7RUFDWCxDQUFDO0VBQ0QsT0FBT1csU0FBUyxnQkFBRyxJQUFBbEMsV0FBQSxDQUFBOEIsR0FBQSxFQUFDSSxTQUFTO0lBQUEsR0FBS2hDLEtBQUs7SUFBQTBCLFFBQUEsZUFBRSxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDN0IsaUJBQWlCO01BQUEsR0FBS0M7SUFBSyxDQUFHO0VBQUMsQ0FBVyxDQUFDLEdBQUdELGlCQUFpQixDQUFDQyxLQUFLLENBQUM7QUFDbEg7QUFBQ2lDLEVBQUEsR0FOdUJILFVBQVU7QUFPbEMsU0FBU1Asb0JBQW9CQSxDQUFDSSxFQUFFLEVBQUVPLFNBQVMsRUFBRUMsS0FBSyxFQUFFO0VBQ2xELE1BQU0sSUFBSUMsS0FBSyxDQUFDLFdBQVcsSUFBSUYsU0FBUyxHQUFHLFdBQVcsR0FBRyxRQUFRLENBQUMsR0FBRyxJQUFJLEdBQUdQLEVBQUUsR0FBRyxvRUFBb0UsSUFBSVEsS0FBSyxHQUFHLHFDQUFxQyxHQUFHQSxLQUFLLEdBQUcsNkNBQTZDLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDdlE7QUFBQyxJQUFBRixFQUFBO0FBQUFJLFlBQUEsQ0FBQUosRUFBQSIsImlnbm9yZUxpc3QiOltdfQ==
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}