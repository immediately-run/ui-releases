var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      blockquote: "blockquote",
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      h3: "h3",
      hr: "hr",
      li: "li",
      ol: "ol",
      p: "p",
      pre: "pre",
      strong: "strong",
      table: "table",
      tbody: "tbody",
      td: "td",
      th: "th",
      thead: "thead",
      tr: "tr",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "immediatelyrun-reporting-spreadsheet-a-js-formula-analysis-app-as-a-multi-sandbox-composite",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "immediatelyrun-reporting-spreadsheet-a-js-formula-analysis-app-as-a-multi-sandbox-composite"
      }), "immediately.run Reporting Spreadsheet — a JS-formula analysis app as a multi-sandbox composite"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Status:"
      }), " proposal / draft — ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["the app ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "shape"
        }), " is feasibility-resolved and is the forcing-function contribution; its ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "safety"
        }), " is contingent on ~6 unbuilt platform deltas (one — host-enforced connector egress-fixing, §12 Q3 — is undesigned and the no-both invariant falls back onto it, RB-1) and carries booked residuals — safety is NOT yet resolved."]
      }), " Two fresh-agent adversarial passes complete (§10b/§10c); a third on this revision is recommended. Design only; nothing here is built. · ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Updated:"
      }), " 2026-07-09"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["The single implementation-status source for this spec is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "docs/status/REPORTING_SPREADSHEET_STATUS.md"
          })]
        }), " — where this document and that one disagree, the status doc governs. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "(Status doc not yet created; this spec is the twice-reviewed author draft.)"
        })]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Reads first:"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "context/core_concepts.md"
        }), " §1/§3/§4/§5/§8/§9; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "context/product_values.md"
        }), " (value 2 run-mode-first, value 8 mobile); ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "TRUST_MODES_SPEC.md"
        }), " §3 (M0–M3), §4 (personal/shared), §5 (interpreter/executor — ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["the interpreter/executor split is \"a declared, inspectable design choice, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "not"
          }), " a capability gate … unprovable against side-eval\""]
        }), ", §5:152), §5.1 (non-executable MDX safe renderer), §6 (M3-egress ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "G1a"
        }), "; \"no capability policy rests on the user reading it\"); ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "AGENT_AUTHORING_ARCHITECTURE.md"
        }), " §2/§3.2/§5/§6/§7; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "TRUST_AND_SAFETY_SPEC.md"
        }), " TS-1/TS-3/TS-4/TS-5b/TS-19 (decision #2: maximally-explicit lines never bundled)/TS-19b; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "UI_AS_APPS_SPEC.md"
        }), " G12, G1a, §8.11 (host-proxied ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "net:fetch"
        }), "); ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "HOST_ORIGIN_HARDENING_SPEC.md"
        }), " §2.1; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "STANDING_APP_LIFECYCLE_SPEC.md"
        }), " §4.1/§5/§5.1/§6.1 (R-SAL-2; per-instance delegation; unbuilt floor-tier; mobile overlay); ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "WHITEBOARD_SPEC.md"
        }), " §8."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-0",
      "data-slug": "0-charter-the-feasibility-question-and-an-honest-answer-proposal",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-0"
      }), "0. Charter — the feasibility question and an honest answer  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(proposal)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Two observations motivate this app: (1) spreadsheets carry vital reporting information but give poor means to build rich, live, interactive dashboards; (2) a spreadsheet is a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "programming language"
      }), " — if formulas were JavaScript, report logic would be a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "unit-testable"
      }), ", agent-authorable software artifact."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The question: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "can formulas be JavaScript, and can dashboards be shared, without a security nightmare?"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The honest one-frame answer (corrected after two adversarial passes)."
        }), " immediately.run already runs untrusted JS safely; the question is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "\"under whose authority does content-authored JS run, and what can it reach.\""
        }), " The answer ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "shape"
        }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "four sandboxed realms so no realm holds two of {executes content-as-code, holds Class-B capabilities, hosts an injectable agent}"
        }), ", with confidentiality defended as ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "reach, not egress"
        }), " — is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "feasible and is this spec's contribution."
        }), " But the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "safety"
        }), " of that shape is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "not host-enforced by any single mechanism"
        }), ": the no-both invariant is an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "app-structural discipline"
        }), " a malicious fork can weaken (§3.2/RB-1), backstopped only by mechanisms that are ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "unbuilt or undesigned"
        }), " (per-instance output tiering §4; host-enforced connector egress-fixing §12 Q3). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The app's shape is the forcing function; its safety is a set of named, unbuilt platform requirements — not a resolved property."
        }), " This spec is valuable precisely as the honest enumeration of those requirements, not as a claim that the app is already safe."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "This spec adds no new principal and no new capability tier; it composes existing mechanisms and names the new asks in §8."
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-1",
      "data-slug": "1-the-product-proposal",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-1"
      }), "1. The product  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(proposal)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["A ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "reporting spreadsheet"
      }), ": JS/TS cell formulas, declarative report layouts (charts, tables, KPIs, prose) rendering live and interactively, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "unit-tested"
      }), " report logic, an embedded coding agent, and data that is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "static (in-sheet), pulled (looked up), or live (streamed)"
      }), "."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Deployment continuum"
      }), " (two-FS × trust-mode):"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Shape"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Filesystems"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "App-code mode"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Content mode"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Character"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Stock app + your content"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "FS1 ≠ FS2"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "fixed, SDK-audited"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "varies (fenced)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "portable, cross-org, public-safe"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Fork + external content"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "FS1 ≠ FS2"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "your/org fork (M1/M2)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "shared space (M3)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "org-customized"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Fork + embedded content (fused)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "FS1 = FS2"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "org app (M2)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["content ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
              children: "is"
            }), " app source (M2)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "purpose-built"
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Run-mode-first (value 2), stated up front (RB-5):"
      }), " a dashboard with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "only static / in-sheet data"
      }), " (no live feed) MUST open with ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "no elevated powerbox and no connector"
      }), " — the viewer just sees the report. The composite/connector consent (§6.2) appears only when a viewer ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "activates a live feed."
      }), " \"Open a shared read-only dashboard\" is a first-class, low-friction path, not a byproduct of the authoring composite."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-2",
      "data-slug": "2-the-four-realm-architecture-proposal-the-core-shape",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-2"
      }), "2. The four-realm architecture  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(proposal — the core shape)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Four sandboxed realms (distinct ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "appKeys"
      }), ", distinct sandboxes) plus the host-owned safe renderer:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Realm"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Role"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            style: {
              textAlign: "center"
            },
            children: "Executes content?"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Holds"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Trust mode"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Report view"
            }), " (stage)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "interpreter: renders layout + results"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            style: {
              textAlign: "center"
            },
            children: "no"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Class-A only"
            }), ": ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "rw@self"
            }), " on the sheet, narrow feed-read"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "app-author's (M1/M2), M3 for a stranger's fork"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Formula engine"
            }), " (evaluator)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "executor: runs formulas + tests"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            style: {
              textAlign: "center"
            },
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "yes"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "nothing"
            }), " (starved by app design)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "—"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Data connector(s)"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "ingestion: streams/looks up external data"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            style: {
              textAlign: "center"
            },
            children: ["no (a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
              children: "dumb pipe"
            }), ", §4.5)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["elevated: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "secrets:use"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "net:fetch"
            }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "host-fixed targets, §12 Q3"
            }), "), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "per-instance-delegated"
            }), " narrow source reads"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "app-author's (M1/M2)"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Assistant"
            }), " (agent)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "authoring: writes formulas/tests/layout"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            style: {
              textAlign: "center"
            },
            children: "no"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Class-A only"
            }), ": ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "llm:chat"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "rw@self"
            }), "; catalog = the app's Class-A catalog (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "G12"
            }), ")"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "app-author's"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
              children: "(host)"
            }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Safe renderer"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "compiles non-executable MDX → React"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            style: {
              textAlign: "center"
            },
            children: "no"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "—"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "M0"
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["This table is the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "intended"
      }), " structure. §3.2 states honestly how much of it the host actually enforces versus how much is app-structural discipline."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-3",
      "data-slug": "3-security-model-proposal",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-3"
      }), "3. Security model  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(proposal)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-3-1",
      "data-slug": "31-confidentiality-is-reach-not-egress-class-a-vs-class-b-proposal",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-3-1"
      }), "3.1 Confidentiality is reach, not egress — Class A vs Class B  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(proposal)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Egress cannot be fully plugged even without ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "net:fetch"
      }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "TRUST_MODES §6"
      }), ": self-navigation leaks one small secret at browser-parity). So we bound ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "reach"
      }), ", not egress (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "core_concepts §9"
      }), "):"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Class A — the sheet's own content"
        }), ": its cells + values from feeds bound to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "this sheet"
        }), ". Exfiltration is possible and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "accepted unconditionally as a browser-parity residual"
        }), " (§12). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "\"Disclosure\" of this residual is best-effort defense-in-depth with no efficacy claim — no policy gates on the user reading it"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "TRUST_MODES §6"
        }), "; RB-7). We do ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "not"
        }), " claim the leak is \"OK because disclosed\"; we claim it is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "accepted, and equal to what a browser already grants any page."
        })]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Class B — the user's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "other"
          }), " data"]
        }), ": other spaces, secrets, other sheets. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The one property that must hold."
        })]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Load-bearing consequence."
      }), " The unclosable channel — a realm's own return value / rendered output — is safe only if ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "only Class A can reach it."
      }), " Ingesting a user's other file makes it Class A ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "by the deliberate act of routing it in"
      }), " (via the connector); the invariant protects only what was ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "not"
      }), " routed in."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["The reach-bound's real strength is the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "aggregate"
        }), " granularity of the connector's grants — which is unbuilt (RB-6/RB-9)."]
      }), " The Class-A/Class-B split is definitional (anything read becomes Class A), and per-source narrow grants (§4.2) bound each grant but ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "not the accumulated total"
      }), ": a fork can request many plausible narrow feeds across a session, each a small delta a fatigued user approves (the TS-19 fatigue that delta-consent §6.2 ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "reintroduces"
      }), "), until \"everything\" is disclosed Class A. So the reach-bound is only as strong as an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "aggregate reach view"
      }), " — \"you have routed N sources into this dashboard\" — plus a volume signal on accumulated deltas. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "That aggregate view is unbuilt"
      }), " (§6.3); until it exists, the reach-bound rests on per-source consent legibility that is unvalidated."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-3-2",
      "data-slug": "32-the-no-both-invariant-an-app-structural-discipline-not-host-enforced-against-a-fork-proposal-corrected-per-rb-1",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-3-2"
      }), "3.2 The no-both invariant — an app-structural discipline, NOT host-enforced against a fork  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(proposal; corrected per RB-1)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The architecture is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "built"
      }), " so no realm combines two dangerous properties:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Realm"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            style: {
              textAlign: "center"
            },
            children: "executes content"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            style: {
              textAlign: "center"
            },
            children: "Class-B caps"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            style: {
              textAlign: "center"
            },
            children: "injectable agent"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Formula engine"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            style: {
              textAlign: "center"
            },
            children: "✅"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            style: {
              textAlign: "center"
            },
            children: "—"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            style: {
              textAlign: "center"
            },
            children: "—"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Data connector"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            style: {
              textAlign: "center"
            },
            children: "—"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            style: {
              textAlign: "center"
            },
            children: "✅"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            style: {
              textAlign: "center"
            },
            children: "—"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Report view"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            style: {
              textAlign: "center"
            },
            children: "—"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            style: {
              textAlign: "center"
            },
            children: "—"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            style: {
              textAlign: "center"
            },
            children: "— (Class-A only, no eval)"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Assistant"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            style: {
              textAlign: "center"
            },
            children: "—"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            style: {
              textAlign: "center"
            },
            children: "—"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            style: {
              textAlign: "center"
            },
            children: "✅ (Class-A only)"
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "This is a design discipline, not a host-enforced guarantee (RB-1)."
      }), " The author draft claimed host-observable ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "\"executor detection\""
      }), " enforces it; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "that claim is struck"
      }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "TRUST_MODES §5:152"
      }), " deletes the interpreter/executor content-flow gate as ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.em, {
        children: ["\"a declared, inspectable design choice, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "not"
        }), " a capability gate … unprovable against side-eval.\""]
      }), " The host ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "cannot"
      }), " reliably detect that a realm executes content-as-code. Concretely, a malicious fork needs no ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "eval"
      }), " (blocked by CSP, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "HOST_ORIGIN_HARDENING §2.1"
      }), "): it can hand-roll a ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["metacircular interpreter inside the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "connector"
        })]
      }), " — which legitimately holds Class-B caps — walking M3 feed bytes as a mini-language, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "indistinguishable from ordinary data processing"
      }), ", so that realm holds ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "two"
      }), " dangerous properties with nothing to detect."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "What the host actually enforces, honestly:"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Per-realm Class-A-only grants — BUILT (the capability model)."
        }), " The evaluator, report view, and assistant are granted only ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "this sheet + this sheet's feeds"
        }), "; they hold no Class-B read (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "core_concepts §5"
        }), ", per-", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "appKey"
        }), " grants). A fork that wants them to hold Class-B must obtain the user's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "consent"
        }), ", visible in the powerbox (§6.2) — never silent. So the invariant holds by construction for honest apps and is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "surfaced, not silently violable"
        }), ", for forks."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Egress-fixing on any Class-B-cap holder — UNBUILT (§12 Q3)."
        }), " The connector's fetch targets are host-fixed, so even a metacircular-interpreter connector can exfiltrate only to those hosts — with the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "TS-4 residual"
        }), " (data can still leave via the request ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "body"
        }), " to a legitimate host; booked, §12). Secrets are host-injected, use-not-read, so no realm reads their value."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Output tiering — UNBUILT (§4)."
        }), " Each realm's output channel is host-tiered to the floor of its inputs, so a realm that launders internally still emits correctly-tainted output."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Honest claim:"
      }), " the four-realm structure is an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "app discipline"
      }), "; a malicious fork can weaken it, but — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "once the two unbuilt backstops ship"
      }), " — cannot (a) silently acquire Class-B reach without consent, (b) exfiltrate beyond the fixed egress hosts (modulo the TS-4 body residual), or (c) launder taint. Executor detection does ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "no"
      }), " load-bearing work. Until egress-fixing (Q3) and output tiering (§4) exist, the invariant's enforcement against a hostile fork is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "incomplete"
      }), ", and the spec says so."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["The evaluator is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "starved"
          }), " by app design"]
        }), " (grant it nothing) because even an M1/M2 formula computes over possibly-M3 data — a confused-deputy risk independent of authorship. This is discipline, not enforcement: a fork can arm its own evaluator, which is why the load-bearing backstops are egress-fixing + output tiering, not the starvation."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-3-3",
      "data-slug": "33-trust-mode-integration-and-the-sharing-spectrum-proposal",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-3-3"
      }), "3.3 Trust-mode integration and the sharing spectrum  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(proposal)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The two carriers are separate (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "TRUST_MODES §2"
      }), "): the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "shared sheet's data"
      }), " is M3 by construction (multi-writer); the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "formulas/app code"
      }), ", if authored in a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "verified org repo behind a review gate"
      }), ", is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "M2"
      }), ". Intra-org reporting is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "M2 code over M3-fenced data"
      }), ". The four-realm design is the M3-safe design, so it covers the spectrum — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "valid only under two conditions (RB-10, prior RA-10)"
      }), ": (i) the realms whose posture relaxes M3→M1/M2 (report view, assistant) hold no Class-B caps and no network; and (ii) the evaluator's starvation is held constant. These are app-structural conditions (§3.2), not host-enforced."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-3-4",
      "data-slug": "34-non-executable-content-the-safe-renderer-proposal-design-verified-trust_modes-51-unbuilt",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-3-4"
      }), "3.4 Non-executable content — the safe renderer  ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.em, {
        children: ["(proposal; design verified ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "TRUST_MODES §5.1"
        }), ", unbuilt)"]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The report view renders through the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "host/SDK-owned non-executable-MDX safe renderer"
      }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "TRUST_MODES §5.1"
      }), "): the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "no-acorn render-as-data"
      }), " path captures expressions as ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "inert strings with no evaluator in the pipeline"
      }), ". It is the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "SDK's TCB, not the app's."
      }), " Consequence: a data binding ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["cannot be ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "{result(\"x\")}"
        })]
      }), " — it must be a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "declarative attribute"
      }), " the interpreter resolves (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "<Chart source=\"revenue\"/>"
      }), "); no prop is treated as code or HTML."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-3-5",
      "data-slug": "35-the-escape-hatch-forking-adds-custom-components-proposal",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-3-5"
      }), "3.5 The escape hatch — forking adds custom components  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(proposal)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["A component ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "definition is app source"
      }), " (fork's code, M1/M2); a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "usage is content"
      }), " (M3, safe-rendered → safe placeholder if unknown). Custom code runs capably only to the degree its author is trusted; a non-member opening a fork gets an M3 app (capability-poor + hardened profile). Catalog audit moves to the fork author. Cost: a report using ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "<Timeline>"
      }), " renders only in a fork that has it (degrade gracefully; declare the target fork). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Agent-split:"
      }), " authoring formulas/tests/MDX is content → the embedded agent (live, §5); custom components are source → the workbench + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "contribute"
      }), " gate."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-4",
      "data-slug": "4-the-ingestion-taint-propagation-contract-proposal-a-trust_modes-5-extension-unbuilt-owns-the-injection-story",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-4"
      }), "4. The ingestion taint-propagation contract  ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.em, {
        children: ["(proposal — a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "TRUST_MODES §5"
        }), " extension; unbuilt; owns the injection story)"]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-4-1",
      "data-slug": "41-the-problem-proposal",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-4-1"
      }), "4.1 The problem  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(proposal)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The connector ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "interposes"
      }), " between an external M3 source (a Google Calendar others write invites into, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "PERSISTENCE_SPEC"
      }), ") and the sheet. It is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "not an executor"
      }), " in the tiering sense (it relays bytes as data), so ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "TRUST_MODES §5"
      }), "'s executor floor does not tier its output — the booked read-then-egress residual (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "§6a"
      }), " F5 / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "AUTHORING_PROVENANCE §6.3"
      }), "). No byte-level provenance exists (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "core_concepts §8"
      }), "). Getting this wrong ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "launders"
      }), " M3 → apparent M1 and worsens injection (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "AGENT_AUTHORING §3.2"
      }), " D4)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-4-2",
      "data-slug": "42-the-contract-proposal",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-4-2"
      }), "4.2 The contract  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(proposal)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Every host-mediated inter-realm channel carries a source tier the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "host"
          }), " assigns, equal to the monotone floor of all sources the producing realm has read this instance-session. No realm may declare its own output's tier."]
        })
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["Host-owned output channel, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "tiered to the floor over the instance's granted inputs"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Per-instance source delegation, not standing per-", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "appKey"
          }), " grants (prior RA-3)."]
        }), " Grants key on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "(user, appKey, principal)"
        }), "; two instances of one connector ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "appKey"
        }), " would share a grant bundle. So sources are delegated ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "per launched instance"
        }), " via an ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["attenuated ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "capDir"
          })]
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "STANDING_APP_LIFECYCLE §5"
        }), "), and the host tiers each instance over ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "its"
        }), " delegations. Unrelated feeds = separate instances = separate tiers; a cross-tier join floors to the min."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Monotone per instance-session"
        }), "; a mid-session down-tier triggers ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "flush-then-restart"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Propagates through every hop"
        }), " — the evaluator's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "result"
        }), " channel is host-tiered to the floor of its formula inputs."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-4-3",
      "data-slug": "43-channel-shape-a-tiered-mount-proposal",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-4-3"
      }), "4.3 Channel shape — a tiered mount  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(proposal)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["A ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "host-owned mount"
      }), " (not a message bus): the tier attaches to what ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "FILESYSTEM §5"
      }), " already tiers → minimal delta. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "STANDING_APP_LIFECYCLE §4.1"
      }), " is a ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["designed precedent (a delegated ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "capDir"
        }), " carrying a content-tier floor) but is unbuilt"]
      }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "§5.1"
      }), "/D4, rides AA-01). Consumption is uniform (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "fs.promises.*"
      }), " over ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "exportZenFS"
      }), "). ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["Streaming = materialize-to-mount + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "onFsChange"
        })]
      }), " (human-timescale; a tiered message-bus for high-frequency is deferred, §8)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-4-4",
      "data-slug": "44-laundering-resistance-ingress-only-proposal",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-4-4"
      }), "4.4 Laundering resistance — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "ingress"
      }), " only  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(proposal)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Against a compromised connector on the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "read/ingest"
      }), " path: host-brokering means the host tiers every channel; the app never sets its own tier; per-instance delegation bounds its inputs. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "This section covers ingress only."
      }), " The distinct ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "write-laundering"
      }), " path — a realm writing tiered bytes into a higher-trust ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "sheet"
      }), " mount it holds — is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "RB-2 / RS-10, an open BLOCKER for the live-persist case"
      }), ", resolved by the ephemeral-compute rule in §5, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "not"
      }), " by this section."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-4-5",
      "data-slug": "45-the-dumb-pipe-constraint-proposal-load-bearing-and-the-fallback-the-whole-invariant-rests-on-per-32",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-4-5"
      }), "4.5 The dumb-pipe constraint  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(proposal — load-bearing, and the fallback the whole invariant rests on per §3.2)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The connector holds the TS-5b combo in one app. Safe ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "only"
      }), " if it is a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "non-agentic, config-driven pipe with host-enforced fixed fetch targets"
      }), " (§12 Q3, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "undesigned"
      }), ") — fetched content can never decide what else to fetch or where to send. Because §3.2 shows the no-both invariant falls back onto this egress-fixing for a metacircular-connector fork, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Q3 is not a nicety — it is the load-bearing backstop, and it is undesigned."
      }), " Feed ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "definitions"
      }), " are trusted config; feed ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "references"
      }), " are content."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-5",
      "data-slug": "5-the-embedded-agent-live-compute-and-the-write-model-proposal",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-5"
      }), "5. The embedded agent, live compute, and the write model  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(proposal)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The assistant is an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "app-embedded agent"
      }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "agent-demo"
      }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "G12"
      }), "), not the workbench source-authoring agent, so the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "AGENT_AUTHORING"
      }), " \"no stage-composited agent\" rejection does not apply. Custom UI."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "G12 confinement."
        }), " Tools = the app's grant-filtered catalog; Class-A-scoped → an injected agent can drive only Class A."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Injection bounded, not eliminated"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "TS-1"
        }), "); feed/evaluator output reaches the agent as ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "fenced data, never a tool"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "AGENT_AUTHORING §3.2"
        }), ")."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Taint fires"
        }), " on reading M3-tiered feed data ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "or the shared sheet itself"
        }), " (M3 when multi-writer)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Evaluator results are ephemeral — the resolution to RB-2 write-laundering."
      }), " The ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "durable sheet stores formulas + user inputs"
      }), " (tiered by authorship). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Evaluator results are NOT persisted into the durable sheet"
      }), " — they live in the host-tiered result channel (§4.2) and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "render live"
      }), ". Rendering an M3-tiered result is safe (the report view is an interpreter — it displays, does not persist). So the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "continuous live path never launders"
      }), " (no M3-derived value enters a higher-trust mount). Two consequences, stated honestly:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Explicit \"freeze value\""
        }), " (paste-values of a computed result into a durable cell) is the RS-10 write: it ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "refloors the target cell/region to the result's tier, or is disallowed."
        }), " You ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "cannot durably cache an M3-feed-derived value in a higher-trust sheet without down-tiering it"
        }), " — a real constraint on the \"live\" premise, not hidden."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["The agent authoring ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "formulas"
        }), " (not frozen values) is fine — a formula is authored content at the sheet's mode; its M3 inputs produce an M3 ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "result"
        }), " that is rendered, not persisted."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Two write classes, gated differently, and made legible (RB-6/RB-9):"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Live Class-A content edits"
        }), " (formulas/tests/MDX, and rendered results): ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "un-gated"
        }), ", bounded by starvation + reach + the safe renderer + the human seeing the result render. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "TS-19b"
        }), " does not apply."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Publishing to a shared space, and any source/component edit"
        }), ": routed through the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "gate"
        }), " with a full non-truncated diff (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "TS-19b"
        }), ")."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["The boundary must be legible ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "before"
          }), " it is hit (RB-9):"]
        }), " the agent UI marks, at compose time, which drafted actions are live vs. gate-bound (a persistent \"this will publish / edit source → attended diff\" affordance), so the diff-gate is never a surprise after twenty silent live edits."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "chat()"
      }), " is egress (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "AGENT_AUTHORING §6"
      }), "), but the read is narrow (this sheet) → the accepted narrow-read residual, not the TS-5b broad-read gate."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-6",
      "data-slug": "6-the-composite-app-shape-proposal-the-net-new-platform-ask",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-6"
      }), "6. The composite app shape  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(proposal — the net-new platform ask)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["A composite is a ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["presentation/grouping over per-program grants, never a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "merge"
        })]
      }), " — one app to the user, N isolated principals to the kernel."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-6-1",
      "data-slug": "61-the-composite-manifest-proposal-binding-resolved-per-prior-ra-2",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-6-1"
      }), "6.1 The composite manifest  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(proposal; binding-resolved per prior RA-2)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Members are ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["binding-resolved, user-overridable ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "roles"
        }), ", not pinned app refs"]
      }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "STANDING_APP_LIFECYCLE"
      }), " R-SAL-2 rejects ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "launch(appRef)"
      }), ", and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "core_concepts §3"
      }), " forbids self-selected bindings. A member is a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "task-contract role"
      }), " with a ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["default ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ref"
        }), " the host/user may repoint"]
      }), "; the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "trust badge (§6.2) reflects the actually-bound provider"
      }), " (a repoint re-consents, since grants key on the new provider's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "appKey"
      }), ")."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.pre, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        className: "language-jsonc",
        children: "\"composite\": {\n  \"name\": \"Sheets\",              // app-chosen chrome — carries NO trust\n  \"role\": \"report-view\",\n  \"members\": [\n    { \"role\": \"formula-engine\",  \"contract\": \"ir.evaluate@1\", \"defaultRef\": \"…\", \"capsEnvelope\": [] },\n    { \"role\": \"data-connector\",  \"contract\": \"ir.feed@1\",     \"defaultRef\": \"…\", \"capsEnvelope\": [\"net:fetch\",\"secrets:use\"] },\n    { \"role\": \"assistant\",       \"contract\": \"ir.assist@1\",   \"defaultRef\": \"…\", \"capsEnvelope\": [\"llm:chat\",\"worktree:rw@self\"] }\n  ]\n}\n"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Declaration ≠ authority."
        }), " Each member requests its own caps under its own ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "appKey"
        }), ", gets its own host-derived trust mode, is binding-conferred its principal. Grouping grants nothing; the host shows the bound member's true badge."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Host reconciles declaration against the runtime launch graph"
        }), " — an undeclared sandbox under the app is flagged."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "capsEnvelope"
          }), " is a legibility signal only, NOT enforcement (prior RA-1 / RB-1)."]
        }), " It powers powerbox attribution and flags an honest author's declaration/grant mismatch; it does not bind a malicious root. The real containment is §3.2's (unbuilt) backstops."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Composite identity, not principal"
        }), " (root ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "appKey"
        }), " + manifest hash indexes members/grants; mints no authority)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-6-2",
      "data-slug": "62-the-composite-aware-powerbox-proposal",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-6-2"
      }), "6.2 The composite-aware powerbox  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(proposal)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["The connector's TS-5b line (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "secrets:use"
          }), " + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "net:fetch"
          }), ") is taken as an INDIVIDUAL interaction — never bundled (RB-3)."]
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "TS-19"
        }), " decision #2 forbids bundling the maximally-explicit line; \"Approve\" may batch only the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Class-A"
        }), " members. Risk-ordering (scariest first) is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "not"
        }), " a substitute for un-bundling."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Host-truth badges"
        }), " on the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "bound"
        }), " provider (M2 names the specific org; near-miss → M3). The composite ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "name is chrome, cannot suppress a badge."
        })]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The starved realm shown holding nothing"
        }), " — visible proof of the intended structure (with §3.2's honesty caveat: intended, not fork-proof)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Partial approval states dependencies COARSELY — no per-cell \"degradation preview\" (RB-8)."
        }), " The host cannot statically predict which charts/cells blank when a member is declined (content-flow opacity, same as §3.2). So partial approval discloses only ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "statically-known"
        }), " losses (\"declining the connector disables live data; declining the assistant disables AI authoring\"); it does ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "not"
        }), " promise a preview it cannot compute."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Delta consent"
        }), " for a new feed re-opens only the connector's new cap — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "and this reintroduces TS-19 fatigue"
        }), " (§3.1/RB-6), mitigated only by the aggregate view (§6.3, unbuilt)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-6-3",
      "data-slug": "63-observability-aggregate-reach-lifecycle-proposal",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-6-3"
      }), "6.3 Observability, aggregate reach, lifecycle  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(proposal)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "composite inspector"
      }), " shows members, roles, host-truth modes, granted caps, live status, and taint/egress flows; per-member ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "revoke"
      }), " (with only the coarse, statically-known consequence, per RB-8). It ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "must also show the aggregate Class-A frontier (RB-6): the full set of sources routed into this dashboard"
      }), ", plus a volume signal when a session accumulates many narrow feed deltas — the reach-bound is only as strong as this view. Composite ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "lifecycle"
      }), " (launch/keep-warm/teardown) rides launch-to-run (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "STANDING_APP_LIFECYCLE"
      }), ", Open Q#10, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "V2"
      }), "). Attribution of every ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "forbidden"
      }), "/error/\"report this app\" to the right member."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-6-4",
      "data-slug": "64-mobile-and-run-mode-first-value-8-value-2-proposal-was-entirely-absent-rb-4rb-5",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-6-4"
      }), "6.4 Mobile and run-mode-first — value 8 / value 2  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(proposal — was entirely absent, RB-4/RB-5)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The net-new consent/observability surfaces are the worst fit for a phone and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "must not ship mute on value 8"
      }), " (sibling specs honor it, e.g. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "STANDING_APP_LIFECYCLE §6.1"
      }), "):"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Powerbox on mobile:"
        }), " progressive disclosure, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "one member per card"
        }), ", the scary connector line reachable ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "without scrolling past benign members"
        }), "; the individual connector consent (§6.2) is its own full-screen step."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Inspector on mobile:"
        }), " a stacked per-member list, not a wide matrix; the aggregate reach frontier (§6.3) as a summarized count that expands."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Run-mode (value 2) on any device:"
        }), " a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "static/in-sheet-only dashboard opens with no powerbox at all"
        }), " (§1); the composite consent appears only on live-feed activation. Opening a shared read-only dashboard is a first-class, low-friction, mobile-complete path."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(This section is a booked requirement with an open owner, not a finished design — but the omission is closed.)"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-7",
      "data-slug": "7-capability-consent-summary-proposal",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-7"
      }), "7. Capability & consent summary  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(proposal)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Realm"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Standing caps"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Consent"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Notes"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Report view"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "rw@self"
            }), ", narrow feed-read"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "first-use (Class-A), batchable"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Class-A only; renders, does not persist evaluator results (§5)"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Formula engine"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "none"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "none"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "starved by app design; not fork-enforced (§3.2)"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Data connector"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "secrets:use"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "net:fetch"
            }), " (host-fixed, Q3 unbuilt), per-instance-delegated narrow reads (no broad ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "mounts:read"
            }), ")"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["first-use elevated — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "individual, never bundled (RB-3)"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "dumb pipe; one instance per tier-class"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Assistant"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "llm:chat"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "rw@self"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["first-use (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "chat"
            }), "-egress warning)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Class-A only; injection bounded (§5)"
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-8",
      "data-slug": "8-v1-v2-dependency-ladder-proposal-honest-split",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-8"
      }), "8. V1 / V2 dependency ladder  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(proposal — honest split)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Buildable now:"
      }), " four-realm separation via separate repos (isolation today); starved evaluator + interpreter report view; embedded ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "G12"
      }), " agent; lookup/poll ingestion via a for-result task; the run-mode-first static-dashboard path (§1/§6.4)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Platform deltas the SAFETY rests on (unbuilt/undesigned — the honest core of this spec):"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ol, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Ingestion taint extension + per-instance ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "capDir"
          }), " delegation"]
        }), " (§4) — ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.em, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "TRUST_MODES §5"
          }), "/D4 + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "STANDING_APP_LIFECYCLE §5.1"
          }), ", unbuilt."]
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The injection story rests on this."
        })]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Host-enforced connector egress-fixing"
        }), " (§4.5, §12 Q3) — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "UNDESIGNED"
        }), ", and §3.2 shows the no-both invariant falls back onto it against a metacircular-connector fork. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The single most load-bearing gap."
        })]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The non-executable-MDX safe renderer"
        }), " (§3.4) — ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.em, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "TRUST_MODES §5.1"
          }), ", designed + verified, unbuilt."]
        })]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "A hardened sandbox profile"
        }), " (§3.2/§8) — a delta on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "G1a"
        }), " (which keeps baseline for M0–M2); ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "net:fetch"
        }), " survives ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "connect-src 'none'"
        }), " via the host proxy (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "UI_AS_APPS §8.11"
        }), "). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Needs per-frame-CSP infra."
        })]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Launch-to-run / standing-app lifecycle"
        }), " incl. per-instance delegated launch — ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.em, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "STANDING_APP_LIFECYCLE"
          }), ", Open Q#10, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "V2, design-pending."
          })]
        })]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "NET-NEW composite"
        }), " — binding-resolved manifest + composite-aware powerbox (un-bundled, mobile-aware) + observability incl. the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "aggregate reach view"
        }), " (§6.3). No existing analog."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Deferred until forced:"
      }), " a tiered message-bus for high-frequency streaming (§4.3); sibling-entry-point members (AA-01)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-9",
      "data-slug": "9-decisions-rejected-alternatives-proposal-dont-relitigate",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-9"
      }), "9. Decisions & rejected alternatives  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(proposal — don't relitigate)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Confidentiality as reach, not egress."
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " sealing egress; DLP."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Four realms; the no-both invariant is an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
            children: "app discipline"
          }), ", contained (not enforced) by egress-fixing + output-tiering (both unbuilt) + per-realm grant consent (built) — NOT by executor detection (RB-1)."]
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " claiming host-observable executor detection enforces it (deleted as unprovable, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "TRUST_MODES §5:152"
        }), "); claiming ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "capsEnvelope"
        }), " enforces it (root-declared, a fork lies)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Evaluator starved by app design; the host backstops are egress-fixing + output-tiering."
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " asserting starvation is fork-proof."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Evaluator results are ephemeral (rendered, not persisted); explicit freeze refloors or is disallowed (RB-2)."
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " persisting M3-derived values into a higher-trust sheet (launders); a blanket \"never write tiered bytes\" rule (incompatible with the live premise)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Enforcement-by-grammar (non-executable MDX)."
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " CSP-alone; arbitrary components."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Ingestion tier host-assigned per instance via ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "capDir"
          }), " delegation."]
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " self-declared tier; whole-composite floor; standing per-", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "appKey"
        }), " source grants; a message bus (deferred)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Connector = dumb pipe with host-enforced fixed targets (Q3)."
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " an agentic connector."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Embedded ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "G12"
          }), " agent; live content un-gated, publish/source gated, boundary made legible pre-hoc (RB-6/RB-9)."]
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " stage-composited source agent; claiming ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "TS-19b"
        }), " gates the live path; a silent live/gate boundary."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Composite members are binding-resolved user-overridable roles (RA-2); ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "capsEnvelope"
          }), " is legibility, not enforcement (RB-1)."]
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " pinned ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "launch(appRef)"
        }), "; a composite principal / merged grants; a name that launders a badge."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The connector's TS-5b line is individually consented, never bundled (RB-3); no per-cell degradation preview (RB-8); run-mode-first + mobile are first-class (RB-4/RB-5)."
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " an \"Approve all\" that bundles the scary line; a degradation preview the host cannot compute; shipping the composite mute on values 2 and 8."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "\"Disclosed\" is best-effort defense-in-depth with no efficacy claim; the Class-A residual is accepted unconditionally at browser-parity (RB-7)."
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Rejected:"
        }), " treating disclosure as a mitigation the safety argument leans on."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-10",
      "data-slug": "10-adversarial-review-proposal",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-10"
      }), "10. Adversarial review  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(proposal)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-10a",
      "data-slug": "10a-author-self-review-superseded-by-the-two-fresh-agent-passes-below",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-10a"
      }), "10a. Author self-review — superseded by the two fresh-agent passes below."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-10b",
      "data-slug": "10b-fresh-agent-pass-1-ra-1ra-12-folded",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-10b"
      }), "10b. Fresh-agent pass 1 (RA-1…RA-12) — folded."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Found two BLOCKERs (RA-1 root-declared ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "capsEnvelope"
      }), " can't enforce; RA-2 pinned member refs are the rejected ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "launch(appRef)"
      }), ") + five MAJORs (per-instance keying, cross-mount write-laundering, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "G1a"
      }), " trigger, live-vs-gated gate, anchor honesty). All folded in the first revision."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "sec-10c",
      "data-slug": "10c-fresh-agent-pass-2-rb-1rb-10-folded-into-this-revision",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-10c"
      }), "10c. Fresh-agent pass 2 (RB-1…RB-10) — folded into THIS revision."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: "Re-attacked the pass-1 folds and challenged security + UX + claim-honesty hard. Results:"
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "RB-1 [BLOCKER] — RA-1 was RELABELED, not fixed."
        }), " \"Executor detection\" is the content-flow gate ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "TRUST_MODES §5:152"
        }), " deletes as unprovable; a metacircular interpreter in the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "connector"
        }), " violates no-both undetectably. → §3.2 rewritten: the invariant is an ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "app discipline"
        }), ", contained (not enforced) by egress-fixing (Q3, undesigned) + output tiering (§4, unbuilt) + per-realm grant consent (built); the executor-detection claim is struck. §0/status re-hedged (RB-10)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "RB-2 [BLOCKER] — RS-10 write-laundering contradicts the live premise."
        }), " → §5 ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "ephemeral-compute"
        }), " rule: evaluator results render, never persist; explicit freeze refloors-or-disallowed. RS-10 escalated (§11/§12)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "RB-3 [MAJOR] — \"Approve all\" bundles the TS-5b line"
        }), " (TS-19 #2). → §6.2 individual connector consent."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "RB-4 [MAJOR] — mobile (value 8) absent."
        }), " → §6.4 added."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "RB-5 [MAJOR] — run-mode-first (value 2) compromised."
        }), " → §1/§6.4 static-dashboard-no-powerbox path."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "RB-6 [MAJOR] — reach-bound rests on unbuilt aggregate legibility."
        }), " → §3.1/§6.3 aggregate reach view + volume signal, stated unbuilt."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "RB-7 [MAJOR] — \"disclosed\" over-claims."
        }), " → §3.1/§9 downgraded to best-effort, no-efficacy; residual accepted unconditionally."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "RB-8 [MAJOR] — \"degradation preview\" is uncomputable."
        }), " → §6.2 coarse, statically-known losses only."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "RB-9 [MAJOR] — live/gate boundary illegible."
        }), " → §5 pre-hoc affordance."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "RB-10 [MAJOR, honesty headline] — \"feasibility-resolved\" outran the evidence."
        }), " → §0/status now: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "shape feasible; safety contingent on unbuilt deltas, not resolved."
        })]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Remaining exit step:"
      }), " a third fresh-agent pass on THIS revision — especially on §3.2's honesty (does the \"app-discipline + unbuilt-backstops\" framing finally state the truth, or still overclaim?), the §5 ephemeral-compute resolution, and whether the safety verdict is now proportionate."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-11",
      "data-slug": "11-threat-id-registry-proposal",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-11"
      }), "11. Threat-ID registry  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(proposal)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "ID"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Threat"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Status"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "RS-1"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Malicious/shared formula (or metacircular-interpreter connector) exfiltrates"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Contained by egress-fixing (Q3, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "unbuilt"
            }), ") + output tiering (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "unbuilt"
            }), "); Class-A residual accepted (§3.1)"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "RS-2"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "A content-executing/agent realm reads Class B"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Per-realm Class-A-only grants + consent visibility (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "built"
            }), "); §3.2"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "RS-3"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Injected agent wields dangerous caps"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "G12"
            }), " Class-A catalog; Class-B caps live in the connector (§5)"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "RS-4"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Feed/shared-sheet steers the agent"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Fenced data; taint → attended (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "TS-1"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "TS-3"
            }), "); publish/source diff (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "TS-19b"
            }), ") — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "taint rests on §4 (unbuilt)"
            })]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "RS-5"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Ingestion launders M3 → M1 (ingress)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Per-instance mount tier floor (§4) — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "unbuilt"
            })]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "RS-6"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Connector steered to exfiltrate"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Dumb pipe + host-fixed targets (§4.5, Q3 ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "undesigned"
            }), ") — the load-bearing gap"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "RS-7"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Content executes in the report view"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Non-executable safe renderer (§3.4, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "unbuilt"
            }), ")"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "RS-8"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Composite name launders a member's trust"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Host-truth badges on the bound provider (§6.1/§6.2)"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "RS-9"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Undeclared sandbox under the app"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Manifest ↔ launch-graph reconciliation (§6.1)"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "RS-10"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Live write-laundering: an M3-derived value persisted into a higher-trust sheet"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Resolved for the live path by ephemeral compute (§5); the explicit-freeze case refloors-or-disallows"
            }), " — booked, dependency ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "AUTHORING_PROVENANCE"
            }), "/R3-156"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "RS-11"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Aggregate reach reconstructed via many narrow feed deltas (consent fatigue)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Aggregate reach view + volume signal (§3.1/§6.3) — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "unbuilt"
            })]
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-12",
      "data-slug": "12-booked-residuals-open-questions-proposal",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-12"
      }), "12. Booked residuals & open questions  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(proposal)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Booked residuals:"
      }), " Class-A self-exfil (return value / self-nav one-secret, browser-parity, accepted ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "unconditionally"
      }), ", disclosure best-effort); TS-4 body-exfil to an egress-fixed legitimate host; shared-sheet content reaching the LLM provider via the assistant; narrow-confidential-read (no DLP); over-tainting from per-instance flooring; explicit-freeze down-tiering of a personal sheet (§5)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Open questions (the honest gaps):"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Q1"
        }), " — spin the composite into ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "COMPOSITE_APP_SPEC"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Q2"
        }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "(RB-1)"
        }), " there is no host-observable executor-detection signal; is the \"egress-fixing + output-tiering\" backstop pair ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "sufficient"
        }), " to call the app safe, or is a further mechanism needed for a metacircular-connector fork?"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.li, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Q3 — the host-enforced form of the connector's fixed fetch targets. UNDESIGNED and load-bearing (§3.2/§4.5)."
        })
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Q4"
        }), " — the elevated slot/principal for the connector; open vs first-party-restricted."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Q5"
        }), " — high-frequency streaming (tiered message bus)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Q6"
        }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "(RB-2)"
        }), " the explicit-freeze refloor semantics + UX; does down-tiering a personal sheet on freeze surprise users?"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Q7"
        }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "(RB-4/RB-5/RB-6)"
        }), " owners for the mobile composite surfaces and the aggregate reach view."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-13",
      "data-slug": "13-load-bearing-assumptions-code-anchors-required",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-13"
      }), "13. Load-bearing assumptions & code anchors  ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "(required)"
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "depends-on-today-grep-verified",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "depends-on-today-grep-verified"
      }), "Depends-on-today (grep-verified)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Assumption"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Anchor (repo-relative file)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Token (grep-stable)"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["App code runs in opaque-origin sandboxed iframes without ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "allow-same-origin"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "immediately-run-sandpack/sandpack-client/src/clients/iframe-factory.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "allow-scripts"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["Host CSP enforces ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "script-src 'self'"
            }), ", no ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "unsafe-eval"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "immediately-run-site-main/src/security/csp.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "script-src"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["An app embeds an agent whose tools are the grant-filtered catalog (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "G12"
            }), ")"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "agent-demo/src"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "useCatalog"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["A mount is exported to a consumer over a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "MessagePort"
            }), ", scoped + mode-clamped"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "immediately-run-site-main/src/editor/task/mintDelegations.ts"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "exportZenFS"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Source tier is computed live from membership, never a stale stored bit"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "docs/specs/FILESYSTEM_SPEC.md"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "never a stale stored bit"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "net:fetch"
            }), " is host-proxied over the parent origin (survives iframe ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "connect-src 'none'"
            }), ")"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "docs/specs/UI_AS_APPS_SPEC.md"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "net-fetch"
            })
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "The interpreter/executor split is not a host-enforceable capability gate (bounds §3.2's honesty)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "docs/specs/TRUST_MODES_SPEC.md"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "not* a capability gate"
            })
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "must-establish-new-invariants-the-implementation-must-create",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "must-establish-new-invariants-the-implementation-must-create"
      }), "Must-establish (new invariants the implementation must create)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "New invariant"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Proven by (gate test)"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Connector-output & evaluator-result mounts carry a host-assigned tier = floor of per-instance-delegated inputs (§4)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["ingestion-taint gate: M3-bound output arrives tagged M3; two instances of one connector ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "appKey"
            }), " share no source grant"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Host-enforced connector egress-fixing (Q3): a connector cannot fetch a non-fixed host even under a metacircular interpreter (§3.2/§4.5)"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["egress-fixing gate — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "the load-bearing, undesigned backstop"
            })]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "The safe renderer runs no author JS (§3.4)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "f={fetch(\"/x\")}"
            }), " captured as an inert string; no evaluator in the pipeline"]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "Evaluator results are never silently persisted into a higher-trust sheet; explicit freeze refloors or is refused (§5/RS-10)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "write-laundering gate (dependency R3-156)"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "The composite name cannot alter a bound member's host-truth badge; the connector's TS-5b line is a stand-alone consent (§6.1/§6.2)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "powerbox tests (badge integrity; un-bundled elevated line)"
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "A static/in-sheet-only dashboard launches with no elevated powerbox on any device (§1/§6.4)"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: "run-mode-first gate (desktop + mobile)"
          })]
        })]
      })]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/REPORTING_SPREADSHEET_SPEC.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJibG9ja3F1b3RlIiwiY29kZSIsImVtIiwiaDEiLCJoMiIsImgzIiwiaHIiLCJsaSIsIm9sIiwicCIsInByZSIsInN0cm9uZyIsInRhYmxlIiwidGJvZHkiLCJ0ZCIsInRoIiwidGhlYWQiLCJ0ciIsInVsIiwiX3Byb3ZpZGVDb21wb25lbnRzIiwiY29tcG9uZW50cyIsIkhlYWRpbmdBbmNob3IiLCJfbWlzc2luZ01keFJlZmVyZW5jZSIsImpzeHMiLCJGcmFnbWVudCIsImNoaWxkcmVuIiwiaWQiLCJqc3giLCJzdHlsZSIsInRleHRBbGlnbiIsImNsYXNzTmFtZSIsIk1EWENvbnRlbnQiLCJ3cmFwcGVyIiwiTURYTGF5b3V0IiwiX2MiLCJjb21wb25lbnQiLCJwbGFjZSIsIkVycm9yIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUkVQT1JUSU5HX1NQUkVBRFNIRUVUX1NQRUMubWQiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgYmxvY2txdW90ZTogXCJibG9ja3F1b3RlXCIsXG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgZW06IFwiZW1cIixcbiAgICBoMTogXCJoMVwiLFxuICAgIGgyOiBcImgyXCIsXG4gICAgaDM6IFwiaDNcIixcbiAgICBocjogXCJoclwiLFxuICAgIGxpOiBcImxpXCIsXG4gICAgb2w6IFwib2xcIixcbiAgICBwOiBcInBcIixcbiAgICBwcmU6IFwicHJlXCIsXG4gICAgc3Ryb25nOiBcInN0cm9uZ1wiLFxuICAgIHRhYmxlOiBcInRhYmxlXCIsXG4gICAgdGJvZHk6IFwidGJvZHlcIixcbiAgICB0ZDogXCJ0ZFwiLFxuICAgIHRoOiBcInRoXCIsXG4gICAgdGhlYWQ6IFwidGhlYWRcIixcbiAgICB0cjogXCJ0clwiLFxuICAgIHVsOiBcInVsXCIsXG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9LCB7SGVhZGluZ0FuY2hvcn0gPSBfY29tcG9uZW50cztcbiAgaWYgKCFIZWFkaW5nQW5jaG9yKSBfbWlzc2luZ01keFJlZmVyZW5jZShcIkhlYWRpbmdBbmNob3JcIiwgdHJ1ZSk7XG4gIHJldHVybiA8PjxfY29tcG9uZW50cy5oMSBpZD1cImltbWVkaWF0ZWx5cnVuLXJlcG9ydGluZy1zcHJlYWRzaGVldC1hLWpzLWZvcm11bGEtYW5hbHlzaXMtYXBwLWFzLWEtbXVsdGktc2FuZGJveC1jb21wb3NpdGVcIj48SGVhZGluZ0FuY2hvciBpZD1cImltbWVkaWF0ZWx5cnVuLXJlcG9ydGluZy1zcHJlYWRzaGVldC1hLWpzLWZvcm11bGEtYW5hbHlzaXMtYXBwLWFzLWEtbXVsdGktc2FuZGJveC1jb21wb3NpdGVcIiAvPntcImltbWVkaWF0ZWx5LnJ1biBSZXBvcnRpbmcgU3ByZWFkc2hlZXQg4oCUIGEgSlMtZm9ybXVsYSBhbmFseXNpcyBhcHAgYXMgYSBtdWx0aS1zYW5kYm94IGNvbXBvc2l0ZVwifTwvX2NvbXBvbmVudHMuaDE+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJTdGF0dXM6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHByb3Bvc2FsIC8gZHJhZnQg4oCUIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1widGhlIGFwcCBcIn08X2NvbXBvbmVudHMuZW0+e1wic2hhcGVcIn08L19jb21wb25lbnRzLmVtPntcIiBpcyBmZWFzaWJpbGl0eS1yZXNvbHZlZCBhbmQgaXMgdGhlIGZvcmNpbmctZnVuY3Rpb24gY29udHJpYnV0aW9uOyBpdHMgXCJ9PF9jb21wb25lbnRzLmVtPntcInNhZmV0eVwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGlzIGNvbnRpbmdlbnQgb24gfjYgdW5idWlsdCBwbGF0Zm9ybSBkZWx0YXMgKG9uZSDigJQgaG9zdC1lbmZvcmNlZCBjb25uZWN0b3IgZWdyZXNzLWZpeGluZywgwqcxMiBRMyDigJQgaXMgdW5kZXNpZ25lZCBhbmQgdGhlIG5vLWJvdGggaW52YXJpYW50IGZhbGxzIGJhY2sgb250byBpdCwgUkItMSkgYW5kIGNhcnJpZXMgYm9va2VkIHJlc2lkdWFscyDigJQgc2FmZXR5IGlzIE5PVCB5ZXQgcmVzb2x2ZWQuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFR3byBmcmVzaC1hZ2VudCBhZHZlcnNhcmlhbCBwYXNzZXMgY29tcGxldGUgKMKnMTBiL8KnMTBjKTsgYSB0aGlyZCBvbiB0aGlzIHJldmlzaW9uIGlzIHJlY29tbWVuZGVkLiBEZXNpZ24gb25seTsgbm90aGluZyBoZXJlIGlzIGJ1aWx0LiDCtyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlVwZGF0ZWQ6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIDIwMjYtMDctMDlcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgc2luZ2xlIGltcGxlbWVudGF0aW9uLXN0YXR1cyBzb3VyY2UgZm9yIHRoaXMgc3BlYyBpcyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJkb2NzL3N0YXR1cy9SRVBPUlRJTkdfU1BSRUFEU0hFRVRfU1RBVFVTLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgd2hlcmUgdGhpcyBkb2N1bWVudCBhbmQgdGhhdCBvbmUgZGlzYWdyZWUsIHRoZSBzdGF0dXMgZG9jIGdvdmVybnMuIFwifTxfY29tcG9uZW50cy5lbT57XCIoU3RhdHVzIGRvYyBub3QgeWV0IGNyZWF0ZWQ7IHRoaXMgc3BlYyBpcyB0aGUgdHdpY2UtcmV2aWV3ZWQgYXV0aG9yIGRyYWZ0LilcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08L19jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJSZWFkcyBmaXJzdDpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY29udGV4dC9jb3JlX2NvbmNlcHRzLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDCpzEvwqczL8KnNC/CpzUvwqc4L8KnOTsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY29udGV4dC9wcm9kdWN0X3ZhbHVlcy5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKHZhbHVlIDIgcnVuLW1vZGUtZmlyc3QsIHZhbHVlIDggbW9iaWxlKTsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiVFJVU1RfTU9ERVNfU1BFQy5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgwqczIChNMOKAk00zKSwgwqc0IChwZXJzb25hbC9zaGFyZWQpLCDCpzUgKGludGVycHJldGVyL2V4ZWN1dG9yIOKAlCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInRoZSBpbnRlcnByZXRlci9leGVjdXRvciBzcGxpdCBpcyBcXFwiYSBkZWNsYXJlZCwgaW5zcGVjdGFibGUgZGVzaWduIGNob2ljZSwgXCJ9PF9jb21wb25lbnRzLmVtPntcIm5vdFwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGEgY2FwYWJpbGl0eSBnYXRlIOKApiB1bnByb3ZhYmxlIGFnYWluc3Qgc2lkZS1ldmFsXFxcIlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgwqc1OjE1MiksIMKnNS4xIChub24tZXhlY3V0YWJsZSBNRFggc2FmZSByZW5kZXJlciksIMKnNiAoTTMtZWdyZXNzIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkcxYVwifTwvX2NvbXBvbmVudHMuY29kZT57XCI7IFxcXCJubyBjYXBhYmlsaXR5IHBvbGljeSByZXN0cyBvbiB0aGUgdXNlciByZWFkaW5nIGl0XFxcIik7IFwifTxfY29tcG9uZW50cy5jb2RlPntcIkFHRU5UX0FVVEhPUklOR19BUkNISVRFQ1RVUkUubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIMKnMi/CpzMuMi/CpzUvwqc2L8KnNzsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiVFJVU1RfQU5EX1NBRkVUWV9TUEVDLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBUUy0xL1RTLTMvVFMtNC9UUy01Yi9UUy0xOSAoZGVjaXNpb24gIzI6IG1heGltYWxseS1leHBsaWNpdCBsaW5lcyBuZXZlciBidW5kbGVkKS9UUy0xOWI7IFwifTxfY29tcG9uZW50cy5jb2RlPntcIlVJX0FTX0FQUFNfU1BFQy5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgRzEyLCBHMWEsIMKnOC4xMSAoaG9zdC1wcm94aWVkIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm5ldDpmZXRjaFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpOyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJIT1NUX09SSUdJTl9IQVJERU5JTkdfU1BFQy5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgwqcyLjE7IFwifTxfY29tcG9uZW50cy5jb2RlPntcIlNUQU5ESU5HX0FQUF9MSUZFQ1lDTEVfU1BFQy5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgwqc0LjEvwqc1L8KnNS4xL8KnNi4xIChSLVNBTC0yOyBwZXItaW5zdGFuY2UgZGVsZWdhdGlvbjsgdW5idWlsdCBmbG9vci10aWVyOyBtb2JpbGUgb3ZlcmxheSk7IFwifTxfY29tcG9uZW50cy5jb2RlPntcIldISVRFQk9BUkRfU1BFQy5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgwqc4LlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08L19jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmhyIC8+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTBcIiBkYXRhLXNsdWc9XCIwLWNoYXJ0ZXItdGhlLWZlYXNpYmlsaXR5LXF1ZXN0aW9uLWFuZC1hbi1ob25lc3QtYW5zd2VyLXByb3Bvc2FsXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtMFwiIC8+e1wiMC4gQ2hhcnRlciDigJQgdGhlIGZlYXNpYmlsaXR5IHF1ZXN0aW9uIGFuZCBhbiBob25lc3QgYW5zd2VyICBcIn08X2NvbXBvbmVudHMuZW0+e1wiKHByb3Bvc2FsKVwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUd28gb2JzZXJ2YXRpb25zIG1vdGl2YXRlIHRoaXMgYXBwOiAoMSkgc3ByZWFkc2hlZXRzIGNhcnJ5IHZpdGFsIHJlcG9ydGluZyBpbmZvcm1hdGlvbiBidXQgZ2l2ZSBwb29yIG1lYW5zIHRvIGJ1aWxkIHJpY2gsIGxpdmUsIGludGVyYWN0aXZlIGRhc2hib2FyZHM7ICgyKSBhIHNwcmVhZHNoZWV0IGlzIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJwcm9ncmFtbWluZyBsYW5ndWFnZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgaWYgZm9ybXVsYXMgd2VyZSBKYXZhU2NyaXB0LCByZXBvcnQgbG9naWMgd291bGQgYmUgYSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInVuaXQtdGVzdGFibGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIsIGFnZW50LWF1dGhvcmFibGUgc29mdHdhcmUgYXJ0aWZhY3QuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSBxdWVzdGlvbjogXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJjYW4gZm9ybXVsYXMgYmUgSmF2YVNjcmlwdCwgYW5kIGNhbiBkYXNoYm9hcmRzIGJlIHNoYXJlZCwgd2l0aG91dCBhIHNlY3VyaXR5IG5pZ2h0bWFyZT9cIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmJsb2NrcXVvdGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgaG9uZXN0IG9uZS1mcmFtZSBhbnN3ZXIgKGNvcnJlY3RlZCBhZnRlciB0d28gYWR2ZXJzYXJpYWwgcGFzc2VzKS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgaW1tZWRpYXRlbHkucnVuIGFscmVhZHkgcnVucyB1bnRydXN0ZWQgSlMgc2FmZWx5OyB0aGUgcXVlc3Rpb24gaXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJcXFwidW5kZXIgd2hvc2UgYXV0aG9yaXR5IGRvZXMgY29udGVudC1hdXRob3JlZCBKUyBydW4sIGFuZCB3aGF0IGNhbiBpdCByZWFjaC5cXFwiXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRoZSBhbnN3ZXIgXCJ9PF9jb21wb25lbnRzLmVtPntcInNoYXBlXCJ9PC9fY29tcG9uZW50cy5lbT57XCIg4oCUIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZm91ciBzYW5kYm94ZWQgcmVhbG1zIHNvIG5vIHJlYWxtIGhvbGRzIHR3byBvZiB7ZXhlY3V0ZXMgY29udGVudC1hcy1jb2RlLCBob2xkcyBDbGFzcy1CIGNhcGFiaWxpdGllcywgaG9zdHMgYW4gaW5qZWN0YWJsZSBhZ2VudH1cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIsIHdpdGggY29uZmlkZW50aWFsaXR5IGRlZmVuZGVkIGFzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicmVhY2gsIG5vdCBlZ3Jlc3NcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIGlzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZmVhc2libGUgYW5kIGlzIHRoaXMgc3BlYydzIGNvbnRyaWJ1dGlvbi5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgQnV0IHRoZSBcIn08X2NvbXBvbmVudHMuZW0+e1wic2FmZXR5XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgb2YgdGhhdCBzaGFwZSBpcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vdCBob3N0LWVuZm9yY2VkIGJ5IGFueSBzaW5nbGUgbWVjaGFuaXNtXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiOiB0aGUgbm8tYm90aCBpbnZhcmlhbnQgaXMgYW4gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJhcHAtc3RydWN0dXJhbCBkaXNjaXBsaW5lXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGEgbWFsaWNpb3VzIGZvcmsgY2FuIHdlYWtlbiAowqczLjIvUkItMSksIGJhY2tzdG9wcGVkIG9ubHkgYnkgbWVjaGFuaXNtcyB0aGF0IGFyZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInVuYnVpbHQgb3IgdW5kZXNpZ25lZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAocGVyLWluc3RhbmNlIG91dHB1dCB0aWVyaW5nIMKnNDsgaG9zdC1lbmZvcmNlZCBjb25uZWN0b3IgZWdyZXNzLWZpeGluZyDCpzEyIFEzKS4gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgYXBwJ3Mgc2hhcGUgaXMgdGhlIGZvcmNpbmcgZnVuY3Rpb247IGl0cyBzYWZldHkgaXMgYSBzZXQgb2YgbmFtZWQsIHVuYnVpbHQgcGxhdGZvcm0gcmVxdWlyZW1lbnRzIOKAlCBub3QgYSByZXNvbHZlZCBwcm9wZXJ0eS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhpcyBzcGVjIGlzIHZhbHVhYmxlIHByZWNpc2VseSBhcyB0aGUgaG9uZXN0IGVudW1lcmF0aW9uIG9mIHRob3NlIHJlcXVpcmVtZW50cywgbm90IGFzIGEgY2xhaW0gdGhhdCB0aGUgYXBwIGlzIGFscmVhZHkgc2FmZS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoaXMgc3BlYyBhZGRzIG5vIG5ldyBwcmluY2lwYWwgYW5kIG5vIG5ldyBjYXBhYmlsaXR5IHRpZXI7IGl0IGNvbXBvc2VzIGV4aXN0aW5nIG1lY2hhbmlzbXMgYW5kIG5hbWVzIHRoZSBuZXcgYXNrcyBpbiDCpzguXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5ociAvPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInNlYy0xXCIgZGF0YS1zbHVnPVwiMS10aGUtcHJvZHVjdC1wcm9wb3NhbFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTFcIiAvPntcIjEuIFRoZSBwcm9kdWN0ICBcIn08X2NvbXBvbmVudHMuZW0+e1wiKHByb3Bvc2FsKVwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJBIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicmVwb3J0aW5nIHNwcmVhZHNoZWV0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiOiBKUy9UUyBjZWxsIGZvcm11bGFzLCBkZWNsYXJhdGl2ZSByZXBvcnQgbGF5b3V0cyAoY2hhcnRzLCB0YWJsZXMsIEtQSXMsIHByb3NlKSByZW5kZXJpbmcgbGl2ZSBhbmQgaW50ZXJhY3RpdmVseSwgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ1bml0LXRlc3RlZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiByZXBvcnQgbG9naWMsIGFuIGVtYmVkZGVkIGNvZGluZyBhZ2VudCwgYW5kIGRhdGEgdGhhdCBpcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInN0YXRpYyAoaW4tc2hlZXQpLCBwdWxsZWQgKGxvb2tlZCB1cCksIG9yIGxpdmUgKHN0cmVhbWVkKVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIi5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJEZXBsb3ltZW50IGNvbnRpbnV1bVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAodHdvLUZTIMOXIHRydXN0LW1vZGUpOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudGFibGU+PF9jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGg+e1wiU2hhcGVcIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aD57XCJGaWxlc3lzdGVtc1wifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIkFwcC1jb2RlIG1vZGVcIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aD57XCJDb250ZW50IG1vZGVcIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aD57XCJDaGFyYWN0ZXJcIn08L19jb21wb25lbnRzLnRoPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudGJvZHk+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJTdG9jayBhcHAgKyB5b3VyIGNvbnRlbnRcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJGUzEg4omgIEZTMlwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcImZpeGVkLCBTREstYXVkaXRlZFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcInZhcmllcyAoZmVuY2VkKVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcInBvcnRhYmxlLCBjcm9zcy1vcmcsIHB1YmxpYy1zYWZlXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiRm9yayArIGV4dGVybmFsIGNvbnRlbnRcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJGUzEg4omgIEZTMlwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcInlvdXIvb3JnIGZvcmsgKE0xL00yKVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcInNoYXJlZCBzcGFjZSAoTTMpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wib3JnLWN1c3RvbWl6ZWRcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJGb3JrICsgZW1iZWRkZWQgY29udGVudCAoZnVzZWQpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiRlMxID0gRlMyXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wib3JnIGFwcCAoTTIpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiY29udGVudCBcIn08X2NvbXBvbmVudHMuZW0+e1wiaXNcIn08L19jb21wb25lbnRzLmVtPntcIiBhcHAgc291cmNlIChNMilcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJwdXJwb3NlLWJ1aWx0XCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGJvZHk+PC9fY29tcG9uZW50cy50YWJsZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlJ1bi1tb2RlLWZpcnN0ICh2YWx1ZSAyKSwgc3RhdGVkIHVwIGZyb250IChSQi01KTpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYSBkYXNoYm9hcmQgd2l0aCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm9ubHkgc3RhdGljIC8gaW4tc2hlZXQgZGF0YVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAobm8gbGl2ZSBmZWVkKSBNVVNUIG9wZW4gd2l0aCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vIGVsZXZhdGVkIHBvd2VyYm94IGFuZCBubyBjb25uZWN0b3JcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHRoZSB2aWV3ZXIganVzdCBzZWVzIHRoZSByZXBvcnQuIFRoZSBjb21wb3NpdGUvY29ubmVjdG9yIGNvbnNlbnQgKMKnNi4yKSBhcHBlYXJzIG9ubHkgd2hlbiBhIHZpZXdlciBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImFjdGl2YXRlcyBhIGxpdmUgZmVlZC5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXFxcIk9wZW4gYSBzaGFyZWQgcmVhZC1vbmx5IGRhc2hib2FyZFxcXCIgaXMgYSBmaXJzdC1jbGFzcywgbG93LWZyaWN0aW9uIHBhdGgsIG5vdCBhIGJ5cHJvZHVjdCBvZiB0aGUgYXV0aG9yaW5nIGNvbXBvc2l0ZS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmhyIC8+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTJcIiBkYXRhLXNsdWc9XCIyLXRoZS1mb3VyLXJlYWxtLWFyY2hpdGVjdHVyZS1wcm9wb3NhbC10aGUtY29yZS1zaGFwZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTJcIiAvPntcIjIuIFRoZSBmb3VyLXJlYWxtIGFyY2hpdGVjdHVyZSAgXCJ9PF9jb21wb25lbnRzLmVtPntcIihwcm9wb3NhbCDigJQgdGhlIGNvcmUgc2hhcGUpXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkZvdXIgc2FuZGJveGVkIHJlYWxtcyAoZGlzdGluY3QgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYXBwS2V5c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGRpc3RpbmN0IHNhbmRib3hlcykgcGx1cyB0aGUgaG9zdC1vd25lZCBzYWZlIHJlbmRlcmVyOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudGFibGU+PF9jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGg+e1wiUmVhbG1cIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aD57XCJSb2xlXCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGggc3R5bGU9e3tcbiAgICB0ZXh0QWxpZ246IFwiY2VudGVyXCJcbiAgfX0+e1wiRXhlY3V0ZXMgY29udGVudD9cIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aD57XCJIb2xkc1wifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIlRydXN0IG1vZGVcIn08L19jb21wb25lbnRzLnRoPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudGJvZHk+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlJlcG9ydCB2aWV3XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChzdGFnZSlcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJpbnRlcnByZXRlcjogcmVuZGVycyBsYXlvdXQgKyByZXN1bHRzXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQgc3R5bGU9e3tcbiAgICB0ZXh0QWxpZ246IFwiY2VudGVyXCJcbiAgfX0+e1wibm9cIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkNsYXNzLUEgb25seVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIjogXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicndAc2VsZlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgb24gdGhlIHNoZWV0LCBuYXJyb3cgZmVlZC1yZWFkXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiYXBwLWF1dGhvcidzIChNMS9NMiksIE0zIGZvciBhIHN0cmFuZ2VyJ3MgZm9ya1wifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRm9ybXVsYSBlbmdpbmVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKGV2YWx1YXRvcilcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJleGVjdXRvcjogcnVucyBmb3JtdWxhcyArIHRlc3RzXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQgc3R5bGU9e3tcbiAgICB0ZXh0QWxpZ246IFwiY2VudGVyXCJcbiAgfX0+PF9jb21wb25lbnRzLnN0cm9uZz57XCJ5ZXNcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vdGhpbmdcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHN0YXJ2ZWQgYnkgYXBwIGRlc2lnbilcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCLigJRcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkRhdGEgY29ubmVjdG9yKHMpXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiaW5nZXN0aW9uOiBzdHJlYW1zL2xvb2tzIHVwIGV4dGVybmFsIGRhdGFcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZCBzdHlsZT17e1xuICAgIHRleHRBbGlnbjogXCJjZW50ZXJcIlxuICB9fT57XCJubyAoYSBcIn08X2NvbXBvbmVudHMuZW0+e1wiZHVtYiBwaXBlXCJ9PC9fY29tcG9uZW50cy5lbT57XCIsIMKnNC41KVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcImVsZXZhdGVkOiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzZWNyZXRzOnVzZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm5ldDpmZXRjaFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiaG9zdC1maXhlZCB0YXJnZXRzLCDCpzEyIFEzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiKSwgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJwZXItaW5zdGFuY2UtZGVsZWdhdGVkXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIG5hcnJvdyBzb3VyY2UgcmVhZHNcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJhcHAtYXV0aG9yJ3MgKE0xL00yKVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQXNzaXN0YW50XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChhZ2VudClcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJhdXRob3Jpbmc6IHdyaXRlcyBmb3JtdWxhcy90ZXN0cy9sYXlvdXRcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZCBzdHlsZT17e1xuICAgIHRleHRBbGlnbjogXCJjZW50ZXJcIlxuICB9fT57XCJub1wifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQ2xhc3MtQSBvbmx5XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiOiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJsbG06Y2hhdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcInJ3QHNlbGZcIn08L19jb21wb25lbnRzLmNvZGU+e1wiOyBjYXRhbG9nID0gdGhlIGFwcCdzIENsYXNzLUEgY2F0YWxvZyAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRzEyXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIilcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJhcHAtYXV0aG9yJ3NcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuZW0+e1wiKGhvc3QpXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJTYWZlIHJlbmRlcmVyXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiY29tcGlsZXMgbm9uLWV4ZWN1dGFibGUgTURYIOKGkiBSZWFjdFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkIHN0eWxlPXt7XG4gICAgdGV4dEFsaWduOiBcImNlbnRlclwiXG4gIH19PntcIm5vXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wi4oCUXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiTTBcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50Ym9keT48L19jb21wb25lbnRzLnRhYmxlPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoaXMgdGFibGUgaXMgdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiaW50ZW5kZWRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgc3RydWN0dXJlLiDCpzMuMiBzdGF0ZXMgaG9uZXN0bHkgaG93IG11Y2ggb2YgaXQgdGhlIGhvc3QgYWN0dWFsbHkgZW5mb3JjZXMgdmVyc3VzIGhvdyBtdWNoIGlzIGFwcC1zdHJ1Y3R1cmFsIGRpc2NpcGxpbmUuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5ociAvPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInNlYy0zXCIgZGF0YS1zbHVnPVwiMy1zZWN1cml0eS1tb2RlbC1wcm9wb3NhbFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTNcIiAvPntcIjMuIFNlY3VyaXR5IG1vZGVsICBcIn08X2NvbXBvbmVudHMuZW0+e1wiKHByb3Bvc2FsKVwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCJzZWMtMy0xXCIgZGF0YS1zbHVnPVwiMzEtY29uZmlkZW50aWFsaXR5LWlzLXJlYWNoLW5vdC1lZ3Jlc3MtY2xhc3MtYS12cy1jbGFzcy1iLXByb3Bvc2FsXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtMy0xXCIgLz57XCIzLjEgQ29uZmlkZW50aWFsaXR5IGlzIHJlYWNoLCBub3QgZWdyZXNzIOKAlCBDbGFzcyBBIHZzIENsYXNzIEIgIFwifTxfY29tcG9uZW50cy5lbT57XCIocHJvcG9zYWwpXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkVncmVzcyBjYW5ub3QgYmUgZnVsbHkgcGx1Z2dlZCBldmVuIHdpdGhvdXQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibmV0OmZldGNoXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiVFJVU1RfTU9ERVMgwqc2XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjogc2VsZi1uYXZpZ2F0aW9uIGxlYWtzIG9uZSBzbWFsbCBzZWNyZXQgYXQgYnJvd3Nlci1wYXJpdHkpLiBTbyB3ZSBib3VuZCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInJlYWNoXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBub3QgZWdyZXNzIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJjb3JlX2NvbmNlcHRzIMKnOVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQ2xhc3MgQSDigJQgdGhlIHNoZWV0J3Mgb3duIGNvbnRlbnRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCI6IGl0cyBjZWxscyArIHZhbHVlcyBmcm9tIGZlZWRzIGJvdW5kIHRvIFwifTxfY29tcG9uZW50cy5lbT57XCJ0aGlzIHNoZWV0XCJ9PC9fY29tcG9uZW50cy5lbT57XCIuIEV4ZmlsdHJhdGlvbiBpcyBwb3NzaWJsZSBhbmQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJhY2NlcHRlZCB1bmNvbmRpdGlvbmFsbHkgYXMgYSBicm93c2VyLXBhcml0eSByZXNpZHVhbFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAowqcxMikuIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiXFxcIkRpc2Nsb3N1cmVcXFwiIG9mIHRoaXMgcmVzaWR1YWwgaXMgYmVzdC1lZmZvcnQgZGVmZW5zZS1pbi1kZXB0aCB3aXRoIG5vIGVmZmljYWN5IGNsYWltIOKAlCBubyBwb2xpY3kgZ2F0ZXMgb24gdGhlIHVzZXIgcmVhZGluZyBpdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiVFJVU1RfTU9ERVMgwqc2XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjsgUkItNykuIFdlIGRvIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibm90XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGNsYWltIHRoZSBsZWFrIGlzIFxcXCJPSyBiZWNhdXNlIGRpc2Nsb3NlZFxcXCI7IHdlIGNsYWltIGl0IGlzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiYWNjZXB0ZWQsIGFuZCBlcXVhbCB0byB3aGF0IGEgYnJvd3NlciBhbHJlYWR5IGdyYW50cyBhbnkgcGFnZS5cIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkNsYXNzIEIg4oCUIHRoZSB1c2VyJ3MgXCJ9PF9jb21wb25lbnRzLmVtPntcIm90aGVyXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgZGF0YVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIjogb3RoZXIgc3BhY2VzLCBzZWNyZXRzLCBvdGhlciBzaGVldHMuIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiVGhlIG9uZSBwcm9wZXJ0eSB0aGF0IG11c3QgaG9sZC5cIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJMb2FkLWJlYXJpbmcgY29uc2VxdWVuY2UuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRoZSB1bmNsb3NhYmxlIGNoYW5uZWwg4oCUIGEgcmVhbG0ncyBvd24gcmV0dXJuIHZhbHVlIC8gcmVuZGVyZWQgb3V0cHV0IOKAlCBpcyBzYWZlIG9ubHkgaWYgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJvbmx5IENsYXNzIEEgY2FuIHJlYWNoIGl0LlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBJbmdlc3RpbmcgYSB1c2VyJ3Mgb3RoZXIgZmlsZSBtYWtlcyBpdCBDbGFzcyBBIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiYnkgdGhlIGRlbGliZXJhdGUgYWN0IG9mIHJvdXRpbmcgaXQgaW5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHZpYSB0aGUgY29ubmVjdG9yKTsgdGhlIGludmFyaWFudCBwcm90ZWN0cyBvbmx5IHdoYXQgd2FzIFwifTxfY29tcG9uZW50cy5lbT57XCJub3RcIn08L19jb21wb25lbnRzLmVtPntcIiByb3V0ZWQgaW4uXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVGhlIHJlYWNoLWJvdW5kJ3MgcmVhbCBzdHJlbmd0aCBpcyB0aGUgXCJ9PF9jb21wb25lbnRzLmVtPntcImFnZ3JlZ2F0ZVwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGdyYW51bGFyaXR5IG9mIHRoZSBjb25uZWN0b3IncyBncmFudHMg4oCUIHdoaWNoIGlzIHVuYnVpbHQgKFJCLTYvUkItOSkuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRoZSBDbGFzcy1BL0NsYXNzLUIgc3BsaXQgaXMgZGVmaW5pdGlvbmFsIChhbnl0aGluZyByZWFkIGJlY29tZXMgQ2xhc3MgQSksIGFuZCBwZXItc291cmNlIG5hcnJvdyBncmFudHMgKMKnNC4yKSBib3VuZCBlYWNoIGdyYW50IGJ1dCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vdCB0aGUgYWNjdW11bGF0ZWQgdG90YWxcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCI6IGEgZm9yayBjYW4gcmVxdWVzdCBtYW55IHBsYXVzaWJsZSBuYXJyb3cgZmVlZHMgYWNyb3NzIGEgc2Vzc2lvbiwgZWFjaCBhIHNtYWxsIGRlbHRhIGEgZmF0aWd1ZWQgdXNlciBhcHByb3ZlcyAodGhlIFRTLTE5IGZhdGlndWUgdGhhdCBkZWx0YS1jb25zZW50IMKnNi4yIFwifTxfY29tcG9uZW50cy5lbT57XCJyZWludHJvZHVjZXNcIn08L19jb21wb25lbnRzLmVtPntcIiksIHVudGlsIFxcXCJldmVyeXRoaW5nXFxcIiBpcyBkaXNjbG9zZWQgQ2xhc3MgQS4gU28gdGhlIHJlYWNoLWJvdW5kIGlzIG9ubHkgYXMgc3Ryb25nIGFzIGFuIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiYWdncmVnYXRlIHJlYWNoIHZpZXdcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIFxcXCJ5b3UgaGF2ZSByb3V0ZWQgTiBzb3VyY2VzIGludG8gdGhpcyBkYXNoYm9hcmRcXFwiIOKAlCBwbHVzIGEgdm9sdW1lIHNpZ25hbCBvbiBhY2N1bXVsYXRlZCBkZWx0YXMuIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiVGhhdCBhZ2dyZWdhdGUgdmlldyBpcyB1bmJ1aWx0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICjCpzYuMyk7IHVudGlsIGl0IGV4aXN0cywgdGhlIHJlYWNoLWJvdW5kIHJlc3RzIG9uIHBlci1zb3VyY2UgY29uc2VudCBsZWdpYmlsaXR5IHRoYXQgaXMgdW52YWxpZGF0ZWQuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cInNlYy0zLTJcIiBkYXRhLXNsdWc9XCIzMi10aGUtbm8tYm90aC1pbnZhcmlhbnQtYW4tYXBwLXN0cnVjdHVyYWwtZGlzY2lwbGluZS1ub3QtaG9zdC1lbmZvcmNlZC1hZ2FpbnN0LWEtZm9yay1wcm9wb3NhbC1jb3JyZWN0ZWQtcGVyLXJiLTFcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy0zLTJcIiAvPntcIjMuMiBUaGUgbm8tYm90aCBpbnZhcmlhbnQg4oCUIGFuIGFwcC1zdHJ1Y3R1cmFsIGRpc2NpcGxpbmUsIE5PVCBob3N0LWVuZm9yY2VkIGFnYWluc3QgYSBmb3JrICBcIn08X2NvbXBvbmVudHMuZW0+e1wiKHByb3Bvc2FsOyBjb3JyZWN0ZWQgcGVyIFJCLTEpXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSBhcmNoaXRlY3R1cmUgaXMgXCJ9PF9jb21wb25lbnRzLmVtPntcImJ1aWx0XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgc28gbm8gcmVhbG0gY29tYmluZXMgdHdvIGRhbmdlcm91cyBwcm9wZXJ0aWVzOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudGFibGU+PF9jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGg+e1wiUmVhbG1cIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aCBzdHlsZT17e1xuICAgIHRleHRBbGlnbjogXCJjZW50ZXJcIlxuICB9fT57XCJleGVjdXRlcyBjb250ZW50XCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGggc3R5bGU9e3tcbiAgICB0ZXh0QWxpZ246IFwiY2VudGVyXCJcbiAgfX0+e1wiQ2xhc3MtQiBjYXBzXCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGggc3R5bGU9e3tcbiAgICB0ZXh0QWxpZ246IFwiY2VudGVyXCJcbiAgfX0+e1wiaW5qZWN0YWJsZSBhZ2VudFwifTwvX2NvbXBvbmVudHMudGg+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50Ym9keT48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkZvcm11bGEgZW5naW5lXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQgc3R5bGU9e3tcbiAgICB0ZXh0QWxpZ246IFwiY2VudGVyXCJcbiAgfX0+e1wi4pyFXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQgc3R5bGU9e3tcbiAgICB0ZXh0QWxpZ246IFwiY2VudGVyXCJcbiAgfX0+e1wi4oCUXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQgc3R5bGU9e3tcbiAgICB0ZXh0QWxpZ246IFwiY2VudGVyXCJcbiAgfX0+e1wi4oCUXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiRGF0YSBjb25uZWN0b3JcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZCBzdHlsZT17e1xuICAgIHRleHRBbGlnbjogXCJjZW50ZXJcIlxuICB9fT57XCLigJRcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZCBzdHlsZT17e1xuICAgIHRleHRBbGlnbjogXCJjZW50ZXJcIlxuICB9fT57XCLinIVcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZCBzdHlsZT17e1xuICAgIHRleHRBbGlnbjogXCJjZW50ZXJcIlxuICB9fT57XCLigJRcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJSZXBvcnQgdmlld1wifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkIHN0eWxlPXt7XG4gICAgdGV4dEFsaWduOiBcImNlbnRlclwiXG4gIH19PntcIuKAlFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkIHN0eWxlPXt7XG4gICAgdGV4dEFsaWduOiBcImNlbnRlclwiXG4gIH19PntcIuKAlFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkIHN0eWxlPXt7XG4gICAgdGV4dEFsaWduOiBcImNlbnRlclwiXG4gIH19PntcIuKAlCAoQ2xhc3MtQSBvbmx5LCBubyBldmFsKVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkFzc2lzdGFudFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkIHN0eWxlPXt7XG4gICAgdGV4dEFsaWduOiBcImNlbnRlclwiXG4gIH19PntcIuKAlFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkIHN0eWxlPXt7XG4gICAgdGV4dEFsaWduOiBcImNlbnRlclwiXG4gIH19PntcIuKAlFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkIHN0eWxlPXt7XG4gICAgdGV4dEFsaWduOiBcImNlbnRlclwiXG4gIH19PntcIuKchSAoQ2xhc3MtQSBvbmx5KVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRib2R5PjwvX2NvbXBvbmVudHMudGFibGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGlzIGlzIGEgZGVzaWduIGRpc2NpcGxpbmUsIG5vdCBhIGhvc3QtZW5mb3JjZWQgZ3VhcmFudGVlIChSQi0xKS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhlIGF1dGhvciBkcmFmdCBjbGFpbWVkIGhvc3Qtb2JzZXJ2YWJsZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlxcXCJleGVjdXRvciBkZXRlY3Rpb25cXFwiXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGVuZm9yY2VzIGl0OyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInRoYXQgY2xhaW0gaXMgc3RydWNrXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJUUlVTVF9NT0RFUyDCpzU6MTUyXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBkZWxldGVzIHRoZSBpbnRlcnByZXRlci9leGVjdXRvciBjb250ZW50LWZsb3cgZ2F0ZSBhcyBcIn08X2NvbXBvbmVudHMuZW0+e1wiXFxcImEgZGVjbGFyZWQsIGluc3BlY3RhYmxlIGRlc2lnbiBjaG9pY2UsIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibm90XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGEgY2FwYWJpbGl0eSBnYXRlIOKApiB1bnByb3ZhYmxlIGFnYWluc3Qgc2lkZS1ldmFsLlxcXCJcIn08L19jb21wb25lbnRzLmVtPntcIiBUaGUgaG9zdCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImNhbm5vdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiByZWxpYWJseSBkZXRlY3QgdGhhdCBhIHJlYWxtIGV4ZWN1dGVzIGNvbnRlbnQtYXMtY29kZS4gQ29uY3JldGVseSwgYSBtYWxpY2lvdXMgZm9yayBuZWVkcyBubyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJldmFsXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoYmxvY2tlZCBieSBDU1AsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkhPU1RfT1JJR0lOX0hBUkRFTklORyDCpzIuMVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpOiBpdCBjYW4gaGFuZC1yb2xsIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJtZXRhY2lyY3VsYXIgaW50ZXJwcmV0ZXIgaW5zaWRlIHRoZSBcIn08X2NvbXBvbmVudHMuZW0+e1wiY29ubmVjdG9yXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHdoaWNoIGxlZ2l0aW1hdGVseSBob2xkcyBDbGFzcy1CIGNhcHMg4oCUIHdhbGtpbmcgTTMgZmVlZCBieXRlcyBhcyBhIG1pbmktbGFuZ3VhZ2UsIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiaW5kaXN0aW5ndWlzaGFibGUgZnJvbSBvcmRpbmFyeSBkYXRhIHByb2Nlc3NpbmdcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIsIHNvIHRoYXQgcmVhbG0gaG9sZHMgXCJ9PF9jb21wb25lbnRzLmVtPntcInR3b1wifTwvX2NvbXBvbmVudHMuZW0+e1wiIGRhbmdlcm91cyBwcm9wZXJ0aWVzIHdpdGggbm90aGluZyB0byBkZXRlY3QuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiV2hhdCB0aGUgaG9zdCBhY3R1YWxseSBlbmZvcmNlcywgaG9uZXN0bHk6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5vbD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJQZXItcmVhbG0gQ2xhc3MtQS1vbmx5IGdyYW50cyDigJQgQlVJTFQgKHRoZSBjYXBhYmlsaXR5IG1vZGVsKS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhlIGV2YWx1YXRvciwgcmVwb3J0IHZpZXcsIGFuZCBhc3Npc3RhbnQgYXJlIGdyYW50ZWQgb25seSBcIn08X2NvbXBvbmVudHMuZW0+e1widGhpcyBzaGVldCArIHRoaXMgc2hlZXQncyBmZWVkc1wifTwvX2NvbXBvbmVudHMuZW0+e1wiOyB0aGV5IGhvbGQgbm8gQ2xhc3MtQiByZWFkIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJjb3JlX2NvbmNlcHRzIMKnNVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIHBlci1cIn08X2NvbXBvbmVudHMuY29kZT57XCJhcHBLZXlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGdyYW50cykuIEEgZm9yayB0aGF0IHdhbnRzIHRoZW0gdG8gaG9sZCBDbGFzcy1CIG11c3Qgb2J0YWluIHRoZSB1c2VyJ3MgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJjb25zZW50XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCB2aXNpYmxlIGluIHRoZSBwb3dlcmJveCAowqc2LjIpIOKAlCBuZXZlciBzaWxlbnQuIFNvIHRoZSBpbnZhcmlhbnQgaG9sZHMgYnkgY29uc3RydWN0aW9uIGZvciBob25lc3QgYXBwcyBhbmQgaXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJzdXJmYWNlZCwgbm90IHNpbGVudGx5IHZpb2xhYmxlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBmb3IgZm9ya3MuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJFZ3Jlc3MtZml4aW5nIG9uIGFueSBDbGFzcy1CLWNhcCBob2xkZXIg4oCUIFVOQlVJTFQgKMKnMTIgUTMpLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGUgY29ubmVjdG9yJ3MgZmV0Y2ggdGFyZ2V0cyBhcmUgaG9zdC1maXhlZCwgc28gZXZlbiBhIG1ldGFjaXJjdWxhci1pbnRlcnByZXRlciBjb25uZWN0b3IgY2FuIGV4ZmlsdHJhdGUgb25seSB0byB0aG9zZSBob3N0cyDigJQgd2l0aCB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJUUy00IHJlc2lkdWFsXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChkYXRhIGNhbiBzdGlsbCBsZWF2ZSB2aWEgdGhlIHJlcXVlc3QgXCJ9PF9jb21wb25lbnRzLmVtPntcImJvZHlcIn08L19jb21wb25lbnRzLmVtPntcIiB0byBhIGxlZ2l0aW1hdGUgaG9zdDsgYm9va2VkLCDCpzEyKS4gU2VjcmV0cyBhcmUgaG9zdC1pbmplY3RlZCwgdXNlLW5vdC1yZWFkLCBzbyBubyByZWFsbSByZWFkcyB0aGVpciB2YWx1ZS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIk91dHB1dCB0aWVyaW5nIOKAlCBVTkJVSUxUICjCpzQpLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBFYWNoIHJlYWxtJ3Mgb3V0cHV0IGNoYW5uZWwgaXMgaG9zdC10aWVyZWQgdG8gdGhlIGZsb29yIG9mIGl0cyBpbnB1dHMsIHNvIGEgcmVhbG0gdGhhdCBsYXVuZGVycyBpbnRlcm5hbGx5IHN0aWxsIGVtaXRzIGNvcnJlY3RseS10YWludGVkIG91dHB1dC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMub2w+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJIb25lc3QgY2xhaW06XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHRoZSBmb3VyLXJlYWxtIHN0cnVjdHVyZSBpcyBhbiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImFwcCBkaXNjaXBsaW5lXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiOyBhIG1hbGljaW91cyBmb3JrIGNhbiB3ZWFrZW4gaXQsIGJ1dCDigJQgXCJ9PF9jb21wb25lbnRzLmVtPntcIm9uY2UgdGhlIHR3byB1bmJ1aWx0IGJhY2tzdG9wcyBzaGlwXCJ9PC9fY29tcG9uZW50cy5lbT57XCIg4oCUIGNhbm5vdCAoYSkgc2lsZW50bHkgYWNxdWlyZSBDbGFzcy1CIHJlYWNoIHdpdGhvdXQgY29uc2VudCwgKGIpIGV4ZmlsdHJhdGUgYmV5b25kIHRoZSBmaXhlZCBlZ3Jlc3MgaG9zdHMgKG1vZHVsbyB0aGUgVFMtNCBib2R5IHJlc2lkdWFsKSwgb3IgKGMpIGxhdW5kZXIgdGFpbnQuIEV4ZWN1dG9yIGRldGVjdGlvbiBkb2VzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibm9cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgbG9hZC1iZWFyaW5nIHdvcmsuIFVudGlsIGVncmVzcy1maXhpbmcgKFEzKSBhbmQgb3V0cHV0IHRpZXJpbmcgKMKnNCkgZXhpc3QsIHRoZSBpbnZhcmlhbnQncyBlbmZvcmNlbWVudCBhZ2FpbnN0IGEgaG9zdGlsZSBmb3JrIGlzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiaW5jb21wbGV0ZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgYW5kIHRoZSBzcGVjIHNheXMgc28uXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVGhlIGV2YWx1YXRvciBpcyBcIn08X2NvbXBvbmVudHMuZW0+e1wic3RhcnZlZFwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGJ5IGFwcCBkZXNpZ25cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKGdyYW50IGl0IG5vdGhpbmcpIGJlY2F1c2UgZXZlbiBhbiBNMS9NMiBmb3JtdWxhIGNvbXB1dGVzIG92ZXIgcG9zc2libHktTTMgZGF0YSDigJQgYSBjb25mdXNlZC1kZXB1dHkgcmlzayBpbmRlcGVuZGVudCBvZiBhdXRob3JzaGlwLiBUaGlzIGlzIGRpc2NpcGxpbmUsIG5vdCBlbmZvcmNlbWVudDogYSBmb3JrIGNhbiBhcm0gaXRzIG93biBldmFsdWF0b3IsIHdoaWNoIGlzIHdoeSB0aGUgbG9hZC1iZWFyaW5nIGJhY2tzdG9wcyBhcmUgZWdyZXNzLWZpeGluZyArIG91dHB1dCB0aWVyaW5nLCBub3QgdGhlIHN0YXJ2YXRpb24uXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTwvX2NvbXBvbmVudHMuYmxvY2txdW90ZT57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCJzZWMtMy0zXCIgZGF0YS1zbHVnPVwiMzMtdHJ1c3QtbW9kZS1pbnRlZ3JhdGlvbi1hbmQtdGhlLXNoYXJpbmctc3BlY3RydW0tcHJvcG9zYWxcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy0zLTNcIiAvPntcIjMuMyBUcnVzdC1tb2RlIGludGVncmF0aW9uIGFuZCB0aGUgc2hhcmluZyBzcGVjdHJ1bSAgXCJ9PF9jb21wb25lbnRzLmVtPntcIihwcm9wb3NhbClcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIHR3byBjYXJyaWVycyBhcmUgc2VwYXJhdGUgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIlRSVVNUX01PREVTIMKnMlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpOiB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJzaGFyZWQgc2hlZXQncyBkYXRhXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGlzIE0zIGJ5IGNvbnN0cnVjdGlvbiAobXVsdGktd3JpdGVyKTsgdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZm9ybXVsYXMvYXBwIGNvZGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIsIGlmIGF1dGhvcmVkIGluIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ2ZXJpZmllZCBvcmcgcmVwbyBiZWhpbmQgYSByZXZpZXcgZ2F0ZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgaXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJNMlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIi4gSW50cmEtb3JnIHJlcG9ydGluZyBpcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIk0yIGNvZGUgb3ZlciBNMy1mZW5jZWQgZGF0YVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIi4gVGhlIGZvdXItcmVhbG0gZGVzaWduIGlzIHRoZSBNMy1zYWZlIGRlc2lnbiwgc28gaXQgY292ZXJzIHRoZSBzcGVjdHJ1bSDigJQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ2YWxpZCBvbmx5IHVuZGVyIHR3byBjb25kaXRpb25zIChSQi0xMCwgcHJpb3IgUkEtMTApXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiOiAoaSkgdGhlIHJlYWxtcyB3aG9zZSBwb3N0dXJlIHJlbGF4ZXMgTTPihpJNMS9NMiAocmVwb3J0IHZpZXcsIGFzc2lzdGFudCkgaG9sZCBubyBDbGFzcy1CIGNhcHMgYW5kIG5vIG5ldHdvcms7IGFuZCAoaWkpIHRoZSBldmFsdWF0b3IncyBzdGFydmF0aW9uIGlzIGhlbGQgY29uc3RhbnQuIFRoZXNlIGFyZSBhcHAtc3RydWN0dXJhbCBjb25kaXRpb25zICjCpzMuMiksIG5vdCBob3N0LWVuZm9yY2VkLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCJzZWMtMy00XCIgZGF0YS1zbHVnPVwiMzQtbm9uLWV4ZWN1dGFibGUtY29udGVudC10aGUtc2FmZS1yZW5kZXJlci1wcm9wb3NhbC1kZXNpZ24tdmVyaWZpZWQtdHJ1c3RfbW9kZXMtNTEtdW5idWlsdFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTMtNFwiIC8+e1wiMy40IE5vbi1leGVjdXRhYmxlIGNvbnRlbnQg4oCUIHRoZSBzYWZlIHJlbmRlcmVyICBcIn08X2NvbXBvbmVudHMuZW0+e1wiKHByb3Bvc2FsOyBkZXNpZ24gdmVyaWZpZWQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiVFJVU1RfTU9ERVMgwqc1LjFcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCB1bmJ1aWx0KVwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgcmVwb3J0IHZpZXcgcmVuZGVycyB0aHJvdWdoIHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImhvc3QvU0RLLW93bmVkIG5vbi1leGVjdXRhYmxlLU1EWCBzYWZlIHJlbmRlcmVyXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJUUlVTVF9NT0RFUyDCpzUuMVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpOiB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJuby1hY29ybiByZW5kZXItYXMtZGF0YVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBwYXRoIGNhcHR1cmVzIGV4cHJlc3Npb25zIGFzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiaW5lcnQgc3RyaW5ncyB3aXRoIG5vIGV2YWx1YXRvciBpbiB0aGUgcGlwZWxpbmVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIuIEl0IGlzIHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlNESydzIFRDQiwgbm90IHRoZSBhcHAncy5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgQ29uc2VxdWVuY2U6IGEgZGF0YSBiaW5kaW5nIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiY2Fubm90IGJlIFwifTxfY29tcG9uZW50cy5jb2RlPntcIntyZXN1bHQoXFxcInhcXFwiKX1cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBpdCBtdXN0IGJlIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJkZWNsYXJhdGl2ZSBhdHRyaWJ1dGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdGhlIGludGVycHJldGVyIHJlc29sdmVzIChcIn08X2NvbXBvbmVudHMuY29kZT57XCI8Q2hhcnQgc291cmNlPVxcXCJyZXZlbnVlXFxcIi8+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIik7IG5vIHByb3AgaXMgdHJlYXRlZCBhcyBjb2RlIG9yIEhUTUwuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cInNlYy0zLTVcIiBkYXRhLXNsdWc9XCIzNS10aGUtZXNjYXBlLWhhdGNoLWZvcmtpbmctYWRkcy1jdXN0b20tY29tcG9uZW50cy1wcm9wb3NhbFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTMtNVwiIC8+e1wiMy41IFRoZSBlc2NhcGUgaGF0Y2gg4oCUIGZvcmtpbmcgYWRkcyBjdXN0b20gY29tcG9uZW50cyAgXCJ9PF9jb21wb25lbnRzLmVtPntcIihwcm9wb3NhbClcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiQSBjb21wb25lbnQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJkZWZpbml0aW9uIGlzIGFwcCBzb3VyY2VcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKGZvcmsncyBjb2RlLCBNMS9NMik7IGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ1c2FnZSBpcyBjb250ZW50XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChNMywgc2FmZS1yZW5kZXJlZCDihpIgc2FmZSBwbGFjZWhvbGRlciBpZiB1bmtub3duKS4gQ3VzdG9tIGNvZGUgcnVucyBjYXBhYmx5IG9ubHkgdG8gdGhlIGRlZ3JlZSBpdHMgYXV0aG9yIGlzIHRydXN0ZWQ7IGEgbm9uLW1lbWJlciBvcGVuaW5nIGEgZm9yayBnZXRzIGFuIE0zIGFwcCAoY2FwYWJpbGl0eS1wb29yICsgaGFyZGVuZWQgcHJvZmlsZSkuIENhdGFsb2cgYXVkaXQgbW92ZXMgdG8gdGhlIGZvcmsgYXV0aG9yLiBDb3N0OiBhIHJlcG9ydCB1c2luZyBcIn08X2NvbXBvbmVudHMuY29kZT57XCI8VGltZWxpbmU+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiByZW5kZXJzIG9ubHkgaW4gYSBmb3JrIHRoYXQgaGFzIGl0IChkZWdyYWRlIGdyYWNlZnVsbHk7IGRlY2xhcmUgdGhlIHRhcmdldCBmb3JrKS4gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJBZ2VudC1zcGxpdDpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYXV0aG9yaW5nIGZvcm11bGFzL3Rlc3RzL01EWCBpcyBjb250ZW50IOKGkiB0aGUgZW1iZWRkZWQgYWdlbnQgKGxpdmUsIMKnNSk7IGN1c3RvbSBjb21wb25lbnRzIGFyZSBzb3VyY2Ug4oaSIHRoZSB3b3JrYmVuY2ggKyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjb250cmlidXRlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBnYXRlLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaHIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtNFwiIGRhdGEtc2x1Zz1cIjQtdGhlLWluZ2VzdGlvbi10YWludC1wcm9wYWdhdGlvbi1jb250cmFjdC1wcm9wb3NhbC1hLXRydXN0X21vZGVzLTUtZXh0ZW5zaW9uLXVuYnVpbHQtb3ducy10aGUtaW5qZWN0aW9uLXN0b3J5XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtNFwiIC8+e1wiNC4gVGhlIGluZ2VzdGlvbiB0YWludC1wcm9wYWdhdGlvbiBjb250cmFjdCAgXCJ9PF9jb21wb25lbnRzLmVtPntcIihwcm9wb3NhbCDigJQgYSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJUUlVTVF9NT0RFUyDCpzVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGV4dGVuc2lvbjsgdW5idWlsdDsgb3ducyB0aGUgaW5qZWN0aW9uIHN0b3J5KVwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCJzZWMtNC0xXCIgZGF0YS1zbHVnPVwiNDEtdGhlLXByb2JsZW0tcHJvcG9zYWxcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy00LTFcIiAvPntcIjQuMSBUaGUgcHJvYmxlbSAgXCJ9PF9jb21wb25lbnRzLmVtPntcIihwcm9wb3NhbClcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIGNvbm5lY3RvciBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImludGVycG9zZXNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYmV0d2VlbiBhbiBleHRlcm5hbCBNMyBzb3VyY2UgKGEgR29vZ2xlIENhbGVuZGFyIG90aGVycyB3cml0ZSBpbnZpdGVzIGludG8sIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlBFUlNJU1RFTkNFX1NQRUNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSBhbmQgdGhlIHNoZWV0LiBJdCBpcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vdCBhbiBleGVjdXRvclwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBpbiB0aGUgdGllcmluZyBzZW5zZSAoaXQgcmVsYXlzIGJ5dGVzIGFzIGRhdGEpLCBzbyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJUUlVTVF9NT0RFUyDCpzVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiJ3MgZXhlY3V0b3IgZmxvb3IgZG9lcyBub3QgdGllciBpdHMgb3V0cHV0IOKAlCB0aGUgYm9va2VkIHJlYWQtdGhlbi1lZ3Jlc3MgcmVzaWR1YWwgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIsKnNmFcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIEY1IC8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQVVUSE9SSU5HX1BST1ZFTkFOQ0Ugwqc2LjNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKS4gTm8gYnl0ZS1sZXZlbCBwcm92ZW5hbmNlIGV4aXN0cyAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY29yZV9jb25jZXB0cyDCpzhcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKS4gR2V0dGluZyB0aGlzIHdyb25nIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibGF1bmRlcnNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgTTMg4oaSIGFwcGFyZW50IE0xIGFuZCB3b3JzZW5zIGluamVjdGlvbiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQUdFTlRfQVVUSE9SSU5HIMKnMy4yXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBENCkuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cInNlYy00LTJcIiBkYXRhLXNsdWc9XCI0Mi10aGUtY29udHJhY3QtcHJvcG9zYWxcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy00LTJcIiAvPntcIjQuMiBUaGUgY29udHJhY3QgIFwifTxfY29tcG9uZW50cy5lbT57XCIocHJvcG9zYWwpXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRXZlcnkgaG9zdC1tZWRpYXRlZCBpbnRlci1yZWFsbSBjaGFubmVsIGNhcnJpZXMgYSBzb3VyY2UgdGllciB0aGUgXCJ9PF9jb21wb25lbnRzLmVtPntcImhvc3RcIn08L19jb21wb25lbnRzLmVtPntcIiBhc3NpZ25zLCBlcXVhbCB0byB0aGUgbW9ub3RvbmUgZmxvb3Igb2YgYWxsIHNvdXJjZXMgdGhlIHByb2R1Y2luZyByZWFsbSBoYXMgcmVhZCB0aGlzIGluc3RhbmNlLXNlc3Npb24uIE5vIHJlYWxtIG1heSBkZWNsYXJlIGl0cyBvd24gb3V0cHV0J3MgdGllci5cIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiSG9zdC1vd25lZCBvdXRwdXQgY2hhbm5lbCwgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ0aWVyZWQgdG8gdGhlIGZsb29yIG92ZXIgdGhlIGluc3RhbmNlJ3MgZ3JhbnRlZCBpbnB1dHNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJQZXItaW5zdGFuY2Ugc291cmNlIGRlbGVnYXRpb24sIG5vdCBzdGFuZGluZyBwZXItXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYXBwS2V5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBncmFudHMgKHByaW9yIFJBLTMpLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBHcmFudHMga2V5IG9uIFwifTxfY29tcG9uZW50cy5jb2RlPntcIih1c2VyLCBhcHBLZXksIHByaW5jaXBhbClcIn08L19jb21wb25lbnRzLmNvZGU+e1wiOyB0d28gaW5zdGFuY2VzIG9mIG9uZSBjb25uZWN0b3IgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYXBwS2V5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB3b3VsZCBzaGFyZSBhIGdyYW50IGJ1bmRsZS4gU28gc291cmNlcyBhcmUgZGVsZWdhdGVkIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicGVyIGxhdW5jaGVkIGluc3RhbmNlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHZpYSBhbiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImF0dGVudWF0ZWQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2FwRGlyXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiU1RBTkRJTkdfQVBQX0xJRkVDWUNMRSDCpzVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSwgYW5kIHRoZSBob3N0IHRpZXJzIGVhY2ggaW5zdGFuY2Ugb3ZlciBcIn08X2NvbXBvbmVudHMuZW0+e1wiaXRzXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgZGVsZWdhdGlvbnMuIFVucmVsYXRlZCBmZWVkcyA9IHNlcGFyYXRlIGluc3RhbmNlcyA9IHNlcGFyYXRlIHRpZXJzOyBhIGNyb3NzLXRpZXIgam9pbiBmbG9vcnMgdG8gdGhlIG1pbi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIk1vbm90b25lIHBlciBpbnN0YW5jZS1zZXNzaW9uXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiOyBhIG1pZC1zZXNzaW9uIGRvd24tdGllciB0cmlnZ2VycyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImZsdXNoLXRoZW4tcmVzdGFydFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlByb3BhZ2F0ZXMgdGhyb3VnaCBldmVyeSBob3BcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHRoZSBldmFsdWF0b3IncyBcIn08X2NvbXBvbmVudHMuZW0+e1wicmVzdWx0XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgY2hhbm5lbCBpcyBob3N0LXRpZXJlZCB0byB0aGUgZmxvb3Igb2YgaXRzIGZvcm11bGEgaW5wdXRzLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCJzZWMtNC0zXCIgZGF0YS1zbHVnPVwiNDMtY2hhbm5lbC1zaGFwZS1hLXRpZXJlZC1tb3VudC1wcm9wb3NhbFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTQtM1wiIC8+e1wiNC4zIENoYW5uZWwgc2hhcGUg4oCUIGEgdGllcmVkIG1vdW50ICBcIn08X2NvbXBvbmVudHMuZW0+e1wiKHByb3Bvc2FsKVwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJBIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiaG9zdC1vd25lZCBtb3VudFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAobm90IGEgbWVzc2FnZSBidXMpOiB0aGUgdGllciBhdHRhY2hlcyB0byB3aGF0IFwifTxfY29tcG9uZW50cy5jb2RlPntcIkZJTEVTWVNURU0gwqc1XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhbHJlYWR5IHRpZXJzIOKGkiBtaW5pbWFsIGRlbHRhLiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJTVEFORElOR19BUFBfTElGRUNZQ0xFIMKnNC4xXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpcyBhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZGVzaWduZWQgcHJlY2VkZW50IChhIGRlbGVnYXRlZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjYXBEaXJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNhcnJ5aW5nIGEgY29udGVudC10aWVyIGZsb29yKSBidXQgaXMgdW5idWlsdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiwqc1LjFcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL0Q0LCByaWRlcyBBQS0wMSkuIENvbnN1bXB0aW9uIGlzIHVuaWZvcm0gKFwifTxfY29tcG9uZW50cy5jb2RlPntcImZzLnByb21pc2VzLipcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG92ZXIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZXhwb3J0WmVuRlNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKS4gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJTdHJlYW1pbmcgPSBtYXRlcmlhbGl6ZS10by1tb3VudCArIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm9uRnNDaGFuZ2VcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChodW1hbi10aW1lc2NhbGU7IGEgdGllcmVkIG1lc3NhZ2UtYnVzIGZvciBoaWdoLWZyZXF1ZW5jeSBpcyBkZWZlcnJlZCwgwqc4KS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwic2VjLTQtNFwiIGRhdGEtc2x1Zz1cIjQ0LWxhdW5kZXJpbmctcmVzaXN0YW5jZS1pbmdyZXNzLW9ubHktcHJvcG9zYWxcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy00LTRcIiAvPntcIjQuNCBMYXVuZGVyaW5nIHJlc2lzdGFuY2Ug4oCUIFwifTxfY29tcG9uZW50cy5lbT57XCJpbmdyZXNzXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgb25seSAgXCJ9PF9jb21wb25lbnRzLmVtPntcIihwcm9wb3NhbClcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiQWdhaW5zdCBhIGNvbXByb21pc2VkIGNvbm5lY3RvciBvbiB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJyZWFkL2luZ2VzdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBwYXRoOiBob3N0LWJyb2tlcmluZyBtZWFucyB0aGUgaG9zdCB0aWVycyBldmVyeSBjaGFubmVsOyB0aGUgYXBwIG5ldmVyIHNldHMgaXRzIG93biB0aWVyOyBwZXItaW5zdGFuY2UgZGVsZWdhdGlvbiBib3VuZHMgaXRzIGlucHV0cy4gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGlzIHNlY3Rpb24gY292ZXJzIGluZ3Jlc3Mgb25seS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgVGhlIGRpc3RpbmN0IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wid3JpdGUtbGF1bmRlcmluZ1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBwYXRoIOKAlCBhIHJlYWxtIHdyaXRpbmcgdGllcmVkIGJ5dGVzIGludG8gYSBoaWdoZXItdHJ1c3QgXCJ9PF9jb21wb25lbnRzLmVtPntcInNoZWV0XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgbW91bnQgaXQgaG9sZHMg4oCUIGlzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiUkItMiAvIFJTLTEwLCBhbiBvcGVuIEJMT0NLRVIgZm9yIHRoZSBsaXZlLXBlcnNpc3QgY2FzZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgcmVzb2x2ZWQgYnkgdGhlIGVwaGVtZXJhbC1jb21wdXRlIHJ1bGUgaW4gwqc1LCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBieSB0aGlzIHNlY3Rpb24uXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cInNlYy00LTVcIiBkYXRhLXNsdWc9XCI0NS10aGUtZHVtYi1waXBlLWNvbnN0cmFpbnQtcHJvcG9zYWwtbG9hZC1iZWFyaW5nLWFuZC10aGUtZmFsbGJhY2stdGhlLXdob2xlLWludmFyaWFudC1yZXN0cy1vbi1wZXItMzJcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy00LTVcIiAvPntcIjQuNSBUaGUgZHVtYi1waXBlIGNvbnN0cmFpbnQgIFwifTxfY29tcG9uZW50cy5lbT57XCIocHJvcG9zYWwg4oCUIGxvYWQtYmVhcmluZywgYW5kIHRoZSBmYWxsYmFjayB0aGUgd2hvbGUgaW52YXJpYW50IHJlc3RzIG9uIHBlciDCpzMuMilcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIGNvbm5lY3RvciBob2xkcyB0aGUgVFMtNWIgY29tYm8gaW4gb25lIGFwcC4gU2FmZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm9ubHlcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgaWYgaXQgaXMgYSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm5vbi1hZ2VudGljLCBjb25maWctZHJpdmVuIHBpcGUgd2l0aCBob3N0LWVuZm9yY2VkIGZpeGVkIGZldGNoIHRhcmdldHNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKMKnMTIgUTMsIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1widW5kZXNpZ25lZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIikg4oCUIGZldGNoZWQgY29udGVudCBjYW4gbmV2ZXIgZGVjaWRlIHdoYXQgZWxzZSB0byBmZXRjaCBvciB3aGVyZSB0byBzZW5kLiBCZWNhdXNlIMKnMy4yIHNob3dzIHRoZSBuby1ib3RoIGludmFyaWFudCBmYWxscyBiYWNrIG9udG8gdGhpcyBlZ3Jlc3MtZml4aW5nIGZvciBhIG1ldGFjaXJjdWxhci1jb25uZWN0b3IgZm9yaywgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJRMyBpcyBub3QgYSBuaWNldHkg4oCUIGl0IGlzIHRoZSBsb2FkLWJlYXJpbmcgYmFja3N0b3AsIGFuZCBpdCBpcyB1bmRlc2lnbmVkLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBGZWVkIFwifTxfY29tcG9uZW50cy5lbT57XCJkZWZpbml0aW9uc1wifTwvX2NvbXBvbmVudHMuZW0+e1wiIGFyZSB0cnVzdGVkIGNvbmZpZzsgZmVlZCBcIn08X2NvbXBvbmVudHMuZW0+e1wicmVmZXJlbmNlc1wifTwvX2NvbXBvbmVudHMuZW0+e1wiIGFyZSBjb250ZW50LlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaHIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtNVwiIGRhdGEtc2x1Zz1cIjUtdGhlLWVtYmVkZGVkLWFnZW50LWxpdmUtY29tcHV0ZS1hbmQtdGhlLXdyaXRlLW1vZGVsLXByb3Bvc2FsXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtNVwiIC8+e1wiNS4gVGhlIGVtYmVkZGVkIGFnZW50LCBsaXZlIGNvbXB1dGUsIGFuZCB0aGUgd3JpdGUgbW9kZWwgIFwifTxfY29tcG9uZW50cy5lbT57XCIocHJvcG9zYWwpXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSBhc3Npc3RhbnQgaXMgYW4gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJhcHAtZW1iZWRkZWQgYWdlbnRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcImFnZW50LWRlbW9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcIkcxMlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLCBub3QgdGhlIHdvcmtiZW5jaCBzb3VyY2UtYXV0aG9yaW5nIGFnZW50LCBzbyB0aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQUdFTlRfQVVUSE9SSU5HXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBcXFwibm8gc3RhZ2UtY29tcG9zaXRlZCBhZ2VudFxcXCIgcmVqZWN0aW9uIGRvZXMgbm90IGFwcGx5LiBDdXN0b20gVUkuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJHMTIgY29uZmluZW1lbnQuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRvb2xzID0gdGhlIGFwcCdzIGdyYW50LWZpbHRlcmVkIGNhdGFsb2c7IENsYXNzLUEtc2NvcGVkIOKGkiBhbiBpbmplY3RlZCBhZ2VudCBjYW4gZHJpdmUgb25seSBDbGFzcyBBLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiSW5qZWN0aW9uIGJvdW5kZWQsIG5vdCBlbGltaW5hdGVkXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJUUy0xXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIik7IGZlZWQvZXZhbHVhdG9yIG91dHB1dCByZWFjaGVzIHRoZSBhZ2VudCBhcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImZlbmNlZCBkYXRhLCBuZXZlciBhIHRvb2xcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIkFHRU5UX0FVVEhPUklORyDCpzMuMlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVGFpbnQgZmlyZXNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgb24gcmVhZGluZyBNMy10aWVyZWQgZmVlZCBkYXRhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wib3IgdGhlIHNoYXJlZCBzaGVldCBpdHNlbGZcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKE0zIHdoZW4gbXVsdGktd3JpdGVyKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJFdmFsdWF0b3IgcmVzdWx0cyBhcmUgZXBoZW1lcmFsIOKAlCB0aGUgcmVzb2x1dGlvbiB0byBSQi0yIHdyaXRlLWxhdW5kZXJpbmcuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImR1cmFibGUgc2hlZXQgc3RvcmVzIGZvcm11bGFzICsgdXNlciBpbnB1dHNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHRpZXJlZCBieSBhdXRob3JzaGlwKS4gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJFdmFsdWF0b3IgcmVzdWx0cyBhcmUgTk9UIHBlcnNpc3RlZCBpbnRvIHRoZSBkdXJhYmxlIHNoZWV0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCB0aGV5IGxpdmUgaW4gdGhlIGhvc3QtdGllcmVkIHJlc3VsdCBjaGFubmVsICjCpzQuMikgYW5kIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicmVuZGVyIGxpdmVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIuIFJlbmRlcmluZyBhbiBNMy10aWVyZWQgcmVzdWx0IGlzIHNhZmUgKHRoZSByZXBvcnQgdmlldyBpcyBhbiBpbnRlcnByZXRlciDigJQgaXQgZGlzcGxheXMsIGRvZXMgbm90IHBlcnNpc3QpLiBTbyB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJjb250aW51b3VzIGxpdmUgcGF0aCBuZXZlciBsYXVuZGVyc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAobm8gTTMtZGVyaXZlZCB2YWx1ZSBlbnRlcnMgYSBoaWdoZXItdHJ1c3QgbW91bnQpLiBUd28gY29uc2VxdWVuY2VzLCBzdGF0ZWQgaG9uZXN0bHk6XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJFeHBsaWNpdCBcXFwiZnJlZXplIHZhbHVlXFxcIlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAocGFzdGUtdmFsdWVzIG9mIGEgY29tcHV0ZWQgcmVzdWx0IGludG8gYSBkdXJhYmxlIGNlbGwpIGlzIHRoZSBSUy0xMCB3cml0ZTogaXQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJyZWZsb29ycyB0aGUgdGFyZ2V0IGNlbGwvcmVnaW9uIHRvIHRoZSByZXN1bHQncyB0aWVyLCBvciBpcyBkaXNhbGxvd2VkLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBZb3UgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJjYW5ub3QgZHVyYWJseSBjYWNoZSBhbiBNMy1mZWVkLWRlcml2ZWQgdmFsdWUgaW4gYSBoaWdoZXItdHJ1c3Qgc2hlZXQgd2l0aG91dCBkb3duLXRpZXJpbmcgaXRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIGEgcmVhbCBjb25zdHJhaW50IG9uIHRoZSBcXFwibGl2ZVxcXCIgcHJlbWlzZSwgbm90IGhpZGRlbi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJUaGUgYWdlbnQgYXV0aG9yaW5nIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZm9ybXVsYXNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKG5vdCBmcm96ZW4gdmFsdWVzKSBpcyBmaW5lIOKAlCBhIGZvcm11bGEgaXMgYXV0aG9yZWQgY29udGVudCBhdCB0aGUgc2hlZXQncyBtb2RlOyBpdHMgTTMgaW5wdXRzIHByb2R1Y2UgYW4gTTMgXCJ9PF9jb21wb25lbnRzLmVtPntcInJlc3VsdFwifTwvX2NvbXBvbmVudHMuZW0+e1wiIHRoYXQgaXMgcmVuZGVyZWQsIG5vdCBwZXJzaXN0ZWQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVHdvIHdyaXRlIGNsYXNzZXMsIGdhdGVkIGRpZmZlcmVudGx5LCBhbmQgbWFkZSBsZWdpYmxlIChSQi02L1JCLTkpOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiTGl2ZSBDbGFzcy1BIGNvbnRlbnQgZWRpdHNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKGZvcm11bGFzL3Rlc3RzL01EWCwgYW5kIHJlbmRlcmVkIHJlc3VsdHMpOiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInVuLWdhdGVkXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBib3VuZGVkIGJ5IHN0YXJ2YXRpb24gKyByZWFjaCArIHRoZSBzYWZlIHJlbmRlcmVyICsgdGhlIGh1bWFuIHNlZWluZyB0aGUgcmVzdWx0IHJlbmRlci4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiVFMtMTliXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBkb2VzIG5vdCBhcHBseS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlB1Ymxpc2hpbmcgdG8gYSBzaGFyZWQgc3BhY2UsIGFuZCBhbnkgc291cmNlL2NvbXBvbmVudCBlZGl0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiOiByb3V0ZWQgdGhyb3VnaCB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJnYXRlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHdpdGggYSBmdWxsIG5vbi10cnVuY2F0ZWQgZGlmZiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiVFMtMTliXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgYm91bmRhcnkgbXVzdCBiZSBsZWdpYmxlIFwifTxfY29tcG9uZW50cy5lbT57XCJiZWZvcmVcIn08L19jb21wb25lbnRzLmVtPntcIiBpdCBpcyBoaXQgKFJCLTkpOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB0aGUgYWdlbnQgVUkgbWFya3MsIGF0IGNvbXBvc2UgdGltZSwgd2hpY2ggZHJhZnRlZCBhY3Rpb25zIGFyZSBsaXZlIHZzLiBnYXRlLWJvdW5kIChhIHBlcnNpc3RlbnQgXFxcInRoaXMgd2lsbCBwdWJsaXNoIC8gZWRpdCBzb3VyY2Ug4oaSIGF0dGVuZGVkIGRpZmZcXFwiIGFmZm9yZGFuY2UpLCBzbyB0aGUgZGlmZi1nYXRlIGlzIG5ldmVyIGEgc3VycHJpc2UgYWZ0ZXIgdHdlbnR5IHNpbGVudCBsaXZlIGVkaXRzLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuY29kZT57XCJjaGF0KClcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGlzIGVncmVzcyAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQUdFTlRfQVVUSE9SSU5HIMKnNlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLCBidXQgdGhlIHJlYWQgaXMgbmFycm93ICh0aGlzIHNoZWV0KSDihpIgdGhlIGFjY2VwdGVkIG5hcnJvdy1yZWFkIHJlc2lkdWFsLCBub3QgdGhlIFRTLTViIGJyb2FkLXJlYWQgZ2F0ZS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmhyIC8+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTZcIiBkYXRhLXNsdWc9XCI2LXRoZS1jb21wb3NpdGUtYXBwLXNoYXBlLXByb3Bvc2FsLXRoZS1uZXQtbmV3LXBsYXRmb3JtLWFza1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTZcIiAvPntcIjYuIFRoZSBjb21wb3NpdGUgYXBwIHNoYXBlICBcIn08X2NvbXBvbmVudHMuZW0+e1wiKHByb3Bvc2FsIOKAlCB0aGUgbmV0LW5ldyBwbGF0Zm9ybSBhc2spXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIkEgY29tcG9zaXRlIGlzIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJwcmVzZW50YXRpb24vZ3JvdXBpbmcgb3ZlciBwZXItcHJvZ3JhbSBncmFudHMsIG5ldmVyIGEgXCJ9PF9jb21wb25lbnRzLmVtPntcIm1lcmdlXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIG9uZSBhcHAgdG8gdGhlIHVzZXIsIE4gaXNvbGF0ZWQgcHJpbmNpcGFscyB0byB0aGUga2VybmVsLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCJzZWMtNi0xXCIgZGF0YS1zbHVnPVwiNjEtdGhlLWNvbXBvc2l0ZS1tYW5pZmVzdC1wcm9wb3NhbC1iaW5kaW5nLXJlc29sdmVkLXBlci1wcmlvci1yYS0yXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtNi0xXCIgLz57XCI2LjEgVGhlIGNvbXBvc2l0ZSBtYW5pZmVzdCAgXCJ9PF9jb21wb25lbnRzLmVtPntcIihwcm9wb3NhbDsgYmluZGluZy1yZXNvbHZlZCBwZXIgcHJpb3IgUkEtMilcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiTWVtYmVycyBhcmUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJiaW5kaW5nLXJlc29sdmVkLCB1c2VyLW92ZXJyaWRhYmxlIFwifTxfY29tcG9uZW50cy5lbT57XCJyb2xlc1wifTwvX2NvbXBvbmVudHMuZW0+e1wiLCBub3QgcGlubmVkIGFwcCByZWZzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJTVEFORElOR19BUFBfTElGRUNZQ0xFXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBSLVNBTC0yIHJlamVjdHMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibGF1bmNoKGFwcFJlZilcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBhbmQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY29yZV9jb25jZXB0cyDCpzNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGZvcmJpZHMgc2VsZi1zZWxlY3RlZCBiaW5kaW5ncy4gQSBtZW1iZXIgaXMgYSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInRhc2stY29udHJhY3Qgcm9sZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB3aXRoIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJkZWZhdWx0IFwifTxfY29tcG9uZW50cy5jb2RlPntcInJlZlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdGhlIGhvc3QvdXNlciBtYXkgcmVwb2ludFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIjsgdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1widHJ1c3QgYmFkZ2UgKMKnNi4yKSByZWZsZWN0cyB0aGUgYWN0dWFsbHktYm91bmQgcHJvdmlkZXJcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKGEgcmVwb2ludCByZS1jb25zZW50cywgc2luY2UgZ3JhbnRzIGtleSBvbiB0aGUgbmV3IHByb3ZpZGVyJ3MgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYXBwS2V5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5wcmU+PF9jb21wb25lbnRzLmNvZGUgY2xhc3NOYW1lPVwibGFuZ3VhZ2UtanNvbmNcIj57XCJcXFwiY29tcG9zaXRlXFxcIjoge1xcbiAgXFxcIm5hbWVcXFwiOiBcXFwiU2hlZXRzXFxcIiwgICAgICAgICAgICAgIC8vIGFwcC1jaG9zZW4gY2hyb21lIOKAlCBjYXJyaWVzIE5PIHRydXN0XFxuICBcXFwicm9sZVxcXCI6IFxcXCJyZXBvcnQtdmlld1xcXCIsXFxuICBcXFwibWVtYmVyc1xcXCI6IFtcXG4gICAgeyBcXFwicm9sZVxcXCI6IFxcXCJmb3JtdWxhLWVuZ2luZVxcXCIsICBcXFwiY29udHJhY3RcXFwiOiBcXFwiaXIuZXZhbHVhdGVAMVxcXCIsIFxcXCJkZWZhdWx0UmVmXFxcIjogXFxcIuKAplxcXCIsIFxcXCJjYXBzRW52ZWxvcGVcXFwiOiBbXSB9LFxcbiAgICB7IFxcXCJyb2xlXFxcIjogXFxcImRhdGEtY29ubmVjdG9yXFxcIiwgIFxcXCJjb250cmFjdFxcXCI6IFxcXCJpci5mZWVkQDFcXFwiLCAgICAgXFxcImRlZmF1bHRSZWZcXFwiOiBcXFwi4oCmXFxcIiwgXFxcImNhcHNFbnZlbG9wZVxcXCI6IFtcXFwibmV0OmZldGNoXFxcIixcXFwic2VjcmV0czp1c2VcXFwiXSB9LFxcbiAgICB7IFxcXCJyb2xlXFxcIjogXFxcImFzc2lzdGFudFxcXCIsICAgICAgIFxcXCJjb250cmFjdFxcXCI6IFxcXCJpci5hc3Npc3RAMVxcXCIsICAgXFxcImRlZmF1bHRSZWZcXFwiOiBcXFwi4oCmXFxcIiwgXFxcImNhcHNFbnZlbG9wZVxcXCI6IFtcXFwibGxtOmNoYXRcXFwiLFxcXCJ3b3JrdHJlZTpyd0BzZWxmXFxcIl0gfVxcbiAgXVxcbn1cXG5cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5wcmU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkRlY2xhcmF0aW9uIOKJoCBhdXRob3JpdHkuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIEVhY2ggbWVtYmVyIHJlcXVlc3RzIGl0cyBvd24gY2FwcyB1bmRlciBpdHMgb3duIFwifTxfY29tcG9uZW50cy5jb2RlPntcImFwcEtleVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGdldHMgaXRzIG93biBob3N0LWRlcml2ZWQgdHJ1c3QgbW9kZSwgaXMgYmluZGluZy1jb25mZXJyZWQgaXRzIHByaW5jaXBhbC4gR3JvdXBpbmcgZ3JhbnRzIG5vdGhpbmc7IHRoZSBob3N0IHNob3dzIHRoZSBib3VuZCBtZW1iZXIncyB0cnVlIGJhZGdlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiSG9zdCByZWNvbmNpbGVzIGRlY2xhcmF0aW9uIGFnYWluc3QgdGhlIHJ1bnRpbWUgbGF1bmNoIGdyYXBoXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBhbiB1bmRlY2xhcmVkIHNhbmRib3ggdW5kZXIgdGhlIGFwcCBpcyBmbGFnZ2VkLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+PF9jb21wb25lbnRzLmNvZGU+e1wiY2Fwc0VudmVsb3BlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpcyBhIGxlZ2liaWxpdHkgc2lnbmFsIG9ubHksIE5PVCBlbmZvcmNlbWVudCAocHJpb3IgUkEtMSAvIFJCLTEpLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBJdCBwb3dlcnMgcG93ZXJib3ggYXR0cmlidXRpb24gYW5kIGZsYWdzIGFuIGhvbmVzdCBhdXRob3IncyBkZWNsYXJhdGlvbi9ncmFudCBtaXNtYXRjaDsgaXQgZG9lcyBub3QgYmluZCBhIG1hbGljaW91cyByb290LiBUaGUgcmVhbCBjb250YWlubWVudCBpcyDCpzMuMidzICh1bmJ1aWx0KSBiYWNrc3RvcHMuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJDb21wb3NpdGUgaWRlbnRpdHksIG5vdCBwcmluY2lwYWxcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHJvb3QgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYXBwS2V5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiArIG1hbmlmZXN0IGhhc2ggaW5kZXhlcyBtZW1iZXJzL2dyYW50czsgbWludHMgbm8gYXV0aG9yaXR5KS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwic2VjLTYtMlwiIGRhdGEtc2x1Zz1cIjYyLXRoZS1jb21wb3NpdGUtYXdhcmUtcG93ZXJib3gtcHJvcG9zYWxcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy02LTJcIiAvPntcIjYuMiBUaGUgY29tcG9zaXRlLWF3YXJlIHBvd2VyYm94ICBcIn08X2NvbXBvbmVudHMuZW0+e1wiKHByb3Bvc2FsKVwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVGhlIGNvbm5lY3RvcidzIFRTLTViIGxpbmUgKFwifTxfY29tcG9uZW50cy5jb2RlPntcInNlY3JldHM6dXNlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiArIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm5ldDpmZXRjaFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpIGlzIHRha2VuIGFzIGFuIElORElWSURVQUwgaW50ZXJhY3Rpb24g4oCUIG5ldmVyIGJ1bmRsZWQgKFJCLTMpLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJUUy0xOVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZGVjaXNpb24gIzIgZm9yYmlkcyBidW5kbGluZyB0aGUgbWF4aW1hbGx5LWV4cGxpY2l0IGxpbmU7IFxcXCJBcHByb3ZlXFxcIiBtYXkgYmF0Y2ggb25seSB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJDbGFzcy1BXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIG1lbWJlcnMuIFJpc2stb3JkZXJpbmcgKHNjYXJpZXN0IGZpcnN0KSBpcyBcIn08X2NvbXBvbmVudHMuZW0+e1wibm90XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgYSBzdWJzdGl0dXRlIGZvciB1bi1idW5kbGluZy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkhvc3QtdHJ1dGggYmFkZ2VzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIG9uIHRoZSBcIn08X2NvbXBvbmVudHMuZW0+e1wiYm91bmRcIn08L19jb21wb25lbnRzLmVtPntcIiBwcm92aWRlciAoTTIgbmFtZXMgdGhlIHNwZWNpZmljIG9yZzsgbmVhci1taXNzIOKGkiBNMykuIFRoZSBjb21wb3NpdGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJuYW1lIGlzIGNocm9tZSwgY2Fubm90IHN1cHByZXNzIGEgYmFkZ2UuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgc3RhcnZlZCByZWFsbSBzaG93biBob2xkaW5nIG5vdGhpbmdcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHZpc2libGUgcHJvb2Ygb2YgdGhlIGludGVuZGVkIHN0cnVjdHVyZSAod2l0aCDCpzMuMidzIGhvbmVzdHkgY2F2ZWF0OiBpbnRlbmRlZCwgbm90IGZvcmstcHJvb2YpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUGFydGlhbCBhcHByb3ZhbCBzdGF0ZXMgZGVwZW5kZW5jaWVzIENPQVJTRUxZIOKAlCBubyBwZXItY2VsbCBcXFwiZGVncmFkYXRpb24gcHJldmlld1xcXCIgKFJCLTgpLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBUaGUgaG9zdCBjYW5ub3Qgc3RhdGljYWxseSBwcmVkaWN0IHdoaWNoIGNoYXJ0cy9jZWxscyBibGFuayB3aGVuIGEgbWVtYmVyIGlzIGRlY2xpbmVkIChjb250ZW50LWZsb3cgb3BhY2l0eSwgc2FtZSBhcyDCpzMuMikuIFNvIHBhcnRpYWwgYXBwcm92YWwgZGlzY2xvc2VzIG9ubHkgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJzdGF0aWNhbGx5LWtub3duXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGxvc3NlcyAoXFxcImRlY2xpbmluZyB0aGUgY29ubmVjdG9yIGRpc2FibGVzIGxpdmUgZGF0YTsgZGVjbGluaW5nIHRoZSBhc3Npc3RhbnQgZGlzYWJsZXMgQUkgYXV0aG9yaW5nXFxcIik7IGl0IGRvZXMgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJub3RcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgcHJvbWlzZSBhIHByZXZpZXcgaXQgY2Fubm90IGNvbXB1dGUuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJEZWx0YSBjb25zZW50XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGZvciBhIG5ldyBmZWVkIHJlLW9wZW5zIG9ubHkgdGhlIGNvbm5lY3RvcidzIG5ldyBjYXAg4oCUIFwifTxfY29tcG9uZW50cy5lbT57XCJhbmQgdGhpcyByZWludHJvZHVjZXMgVFMtMTkgZmF0aWd1ZVwifTwvX2NvbXBvbmVudHMuZW0+e1wiICjCpzMuMS9SQi02KSwgbWl0aWdhdGVkIG9ubHkgYnkgdGhlIGFnZ3JlZ2F0ZSB2aWV3ICjCpzYuMywgdW5idWlsdCkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cInNlYy02LTNcIiBkYXRhLXNsdWc9XCI2My1vYnNlcnZhYmlsaXR5LWFnZ3JlZ2F0ZS1yZWFjaC1saWZlY3ljbGUtcHJvcG9zYWxcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy02LTNcIiAvPntcIjYuMyBPYnNlcnZhYmlsaXR5LCBhZ2dyZWdhdGUgcmVhY2gsIGxpZmVjeWNsZSAgXCJ9PF9jb21wb25lbnRzLmVtPntcIihwcm9wb3NhbClcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiVGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiY29tcG9zaXRlIGluc3BlY3RvclwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBzaG93cyBtZW1iZXJzLCByb2xlcywgaG9zdC10cnV0aCBtb2RlcywgZ3JhbnRlZCBjYXBzLCBsaXZlIHN0YXR1cywgYW5kIHRhaW50L2VncmVzcyBmbG93czsgcGVyLW1lbWJlciBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInJldm9rZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAod2l0aCBvbmx5IHRoZSBjb2Fyc2UsIHN0YXRpY2FsbHkta25vd24gY29uc2VxdWVuY2UsIHBlciBSQi04KS4gSXQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJtdXN0IGFsc28gc2hvdyB0aGUgYWdncmVnYXRlIENsYXNzLUEgZnJvbnRpZXIgKFJCLTYpOiB0aGUgZnVsbCBzZXQgb2Ygc291cmNlcyByb3V0ZWQgaW50byB0aGlzIGRhc2hib2FyZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiwgcGx1cyBhIHZvbHVtZSBzaWduYWwgd2hlbiBhIHNlc3Npb24gYWNjdW11bGF0ZXMgbWFueSBuYXJyb3cgZmVlZCBkZWx0YXMg4oCUIHRoZSByZWFjaC1ib3VuZCBpcyBvbmx5IGFzIHN0cm9uZyBhcyB0aGlzIHZpZXcuIENvbXBvc2l0ZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImxpZmVjeWNsZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAobGF1bmNoL2tlZXAtd2FybS90ZWFyZG93bikgcmlkZXMgbGF1bmNoLXRvLXJ1biAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiU1RBTkRJTkdfQVBQX0xJRkVDWUNMRVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIE9wZW4gUSMxMCwgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJWMlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIikuIEF0dHJpYnV0aW9uIG9mIGV2ZXJ5IFwifTxfY29tcG9uZW50cy5jb2RlPntcImZvcmJpZGRlblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvZXJyb3IvXFxcInJlcG9ydCB0aGlzIGFwcFxcXCIgdG8gdGhlIHJpZ2h0IG1lbWJlci5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwic2VjLTYtNFwiIGRhdGEtc2x1Zz1cIjY0LW1vYmlsZS1hbmQtcnVuLW1vZGUtZmlyc3QtdmFsdWUtOC12YWx1ZS0yLXByb3Bvc2FsLXdhcy1lbnRpcmVseS1hYnNlbnQtcmItNHJiLTVcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy02LTRcIiAvPntcIjYuNCBNb2JpbGUgYW5kIHJ1bi1tb2RlLWZpcnN0IOKAlCB2YWx1ZSA4IC8gdmFsdWUgMiAgXCJ9PF9jb21wb25lbnRzLmVtPntcIihwcm9wb3NhbCDigJQgd2FzIGVudGlyZWx5IGFic2VudCwgUkItNC9SQi01KVwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgbmV0LW5ldyBjb25zZW50L29ic2VydmFiaWxpdHkgc3VyZmFjZXMgYXJlIHRoZSB3b3JzdCBmaXQgZm9yIGEgcGhvbmUgYW5kIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibXVzdCBub3Qgc2hpcCBtdXRlIG9uIHZhbHVlIDhcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHNpYmxpbmcgc3BlY3MgaG9ub3IgaXQsIGUuZy4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiU1RBTkRJTkdfQVBQX0xJRkVDWUNMRSDCpzYuMVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUG93ZXJib3ggb24gbW9iaWxlOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBwcm9ncmVzc2l2ZSBkaXNjbG9zdXJlLCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIm9uZSBtZW1iZXIgcGVyIGNhcmRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIsIHRoZSBzY2FyeSBjb25uZWN0b3IgbGluZSByZWFjaGFibGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ3aXRob3V0IHNjcm9sbGluZyBwYXN0IGJlbmlnbiBtZW1iZXJzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiOyB0aGUgaW5kaXZpZHVhbCBjb25uZWN0b3IgY29uc2VudCAowqc2LjIpIGlzIGl0cyBvd24gZnVsbC1zY3JlZW4gc3RlcC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkluc3BlY3RvciBvbiBtb2JpbGU6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGEgc3RhY2tlZCBwZXItbWVtYmVyIGxpc3QsIG5vdCBhIHdpZGUgbWF0cml4OyB0aGUgYWdncmVnYXRlIHJlYWNoIGZyb250aWVyICjCpzYuMykgYXMgYSBzdW1tYXJpemVkIGNvdW50IHRoYXQgZXhwYW5kcy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlJ1bi1tb2RlICh2YWx1ZSAyKSBvbiBhbnkgZGV2aWNlOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBhIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wic3RhdGljL2luLXNoZWV0LW9ubHkgZGFzaGJvYXJkIG9wZW5zIHdpdGggbm8gcG93ZXJib3ggYXQgYWxsXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICjCpzEpOyB0aGUgY29tcG9zaXRlIGNvbnNlbnQgYXBwZWFycyBvbmx5IG9uIGxpdmUtZmVlZCBhY3RpdmF0aW9uLiBPcGVuaW5nIGEgc2hhcmVkIHJlYWQtb25seSBkYXNoYm9hcmQgaXMgYSBmaXJzdC1jbGFzcywgbG93LWZyaWN0aW9uLCBtb2JpbGUtY29tcGxldGUgcGF0aC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLmVtPntcIihUaGlzIHNlY3Rpb24gaXMgYSBib29rZWQgcmVxdWlyZW1lbnQgd2l0aCBhbiBvcGVuIG93bmVyLCBub3QgYSBmaW5pc2hlZCBkZXNpZ24g4oCUIGJ1dCB0aGUgb21pc3Npb24gaXMgY2xvc2VkLilcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaHIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtN1wiIGRhdGEtc2x1Zz1cIjctY2FwYWJpbGl0eS1jb25zZW50LXN1bW1hcnktcHJvcG9zYWxcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy03XCIgLz57XCI3LiBDYXBhYmlsaXR5ICYgY29uc2VudCBzdW1tYXJ5ICBcIn08X2NvbXBvbmVudHMuZW0+e1wiKHByb3Bvc2FsKVwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMudGFibGU+PF9jb21wb25lbnRzLnRoZWFkPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGg+e1wiUmVhbG1cIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aD57XCJTdGFuZGluZyBjYXBzXCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGg+e1wiQ29uc2VudFwifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIk5vdGVzXCJ9PC9fY29tcG9uZW50cy50aD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGhlYWQ+PF9jb21wb25lbnRzLnRib2R5PjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiUmVwb3J0IHZpZXdcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJyd0BzZWxmXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgbmFycm93IGZlZWQtcmVhZFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcImZpcnN0LXVzZSAoQ2xhc3MtQSksIGJhdGNoYWJsZVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIkNsYXNzLUEgb25seTsgcmVuZGVycywgZG9lcyBub3QgcGVyc2lzdCBldmFsdWF0b3IgcmVzdWx0cyAowqc1KVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkZvcm11bGEgZW5naW5lXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnN0cm9uZz57XCJub25lXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wibm9uZVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcInN0YXJ2ZWQgYnkgYXBwIGRlc2lnbjsgbm90IGZvcmstZW5mb3JjZWQgKMKnMy4yKVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkRhdGEgY29ubmVjdG9yXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wic2VjcmV0czp1c2VcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJuZXQ6ZmV0Y2hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChob3N0LWZpeGVkLCBRMyB1bmJ1aWx0KSwgcGVyLWluc3RhbmNlLWRlbGVnYXRlZCBuYXJyb3cgcmVhZHMgKG5vIGJyb2FkIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1vdW50czpyZWFkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIilcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJmaXJzdC11c2UgZWxldmF0ZWQg4oCUIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiaW5kaXZpZHVhbCwgbmV2ZXIgYnVuZGxlZCAoUkItMylcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJkdW1iIHBpcGU7IG9uZSBpbnN0YW5jZSBwZXIgdGllci1jbGFzc1wifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkFzc2lzdGFudFwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcImxsbTpjaGF0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicndAc2VsZlwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJmaXJzdC11c2UgKFwifTxfY29tcG9uZW50cy5jb2RlPntcImNoYXRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLWVncmVzcyB3YXJuaW5nKVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIkNsYXNzLUEgb25seTsgaW5qZWN0aW9uIGJvdW5kZWQgKMKnNSlcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50Ym9keT48L19jb21wb25lbnRzLnRhYmxlPntcIlxcblwifTxfY29tcG9uZW50cy5ociAvPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInNlYy04XCIgZGF0YS1zbHVnPVwiOC12MS12Mi1kZXBlbmRlbmN5LWxhZGRlci1wcm9wb3NhbC1ob25lc3Qtc3BsaXRcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy04XCIgLz57XCI4LiBWMSAvIFYyIGRlcGVuZGVuY3kgbGFkZGVyICBcIn08X2NvbXBvbmVudHMuZW0+e1wiKHByb3Bvc2FsIOKAlCBob25lc3Qgc3BsaXQpXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQnVpbGRhYmxlIG5vdzpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgZm91ci1yZWFsbSBzZXBhcmF0aW9uIHZpYSBzZXBhcmF0ZSByZXBvcyAoaXNvbGF0aW9uIHRvZGF5KTsgc3RhcnZlZCBldmFsdWF0b3IgKyBpbnRlcnByZXRlciByZXBvcnQgdmlldzsgZW1iZWRkZWQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRzEyXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhZ2VudDsgbG9va3VwL3BvbGwgaW5nZXN0aW9uIHZpYSBhIGZvci1yZXN1bHQgdGFzazsgdGhlIHJ1bi1tb2RlLWZpcnN0IHN0YXRpYy1kYXNoYm9hcmQgcGF0aCAowqcxL8KnNi40KS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJQbGF0Zm9ybSBkZWx0YXMgdGhlIFNBRkVUWSByZXN0cyBvbiAodW5idWlsdC91bmRlc2lnbmVkIOKAlCB0aGUgaG9uZXN0IGNvcmUgb2YgdGhpcyBzcGVjKTpcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLm9sPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkluZ2VzdGlvbiB0YWludCBleHRlbnNpb24gKyBwZXItaW5zdGFuY2UgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2FwRGlyXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBkZWxlZ2F0aW9uXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICjCpzQpIOKAlCBcIn08X2NvbXBvbmVudHMuZW0+PF9jb21wb25lbnRzLmNvZGU+e1wiVFJVU1RfTU9ERVMgwqc1XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9ENCArIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlNUQU5ESU5HX0FQUF9MSUZFQ1lDTEUgwqc1LjFcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCB1bmJ1aWx0LlwifTwvX2NvbXBvbmVudHMuZW0+e1wiIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiVGhlIGluamVjdGlvbiBzdG9yeSByZXN0cyBvbiB0aGlzLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiSG9zdC1lbmZvcmNlZCBjb25uZWN0b3IgZWdyZXNzLWZpeGluZ1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAowqc0LjUsIMKnMTIgUTMpIOKAlCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlVOREVTSUdORURcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIsIGFuZCDCpzMuMiBzaG93cyB0aGUgbm8tYm90aCBpbnZhcmlhbnQgZmFsbHMgYmFjayBvbnRvIGl0IGFnYWluc3QgYSBtZXRhY2lyY3VsYXItY29ubmVjdG9yIGZvcmsuIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiVGhlIHNpbmdsZSBtb3N0IGxvYWQtYmVhcmluZyBnYXAuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgbm9uLWV4ZWN1dGFibGUtTURYIHNhZmUgcmVuZGVyZXJcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKMKnMy40KSDigJQgXCJ9PF9jb21wb25lbnRzLmVtPjxfY29tcG9uZW50cy5jb2RlPntcIlRSVVNUX01PREVTIMKnNS4xXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgZGVzaWduZWQgKyB2ZXJpZmllZCwgdW5idWlsdC5cIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiQSBoYXJkZW5lZCBzYW5kYm94IHByb2ZpbGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKMKnMy4yL8KnOCkg4oCUIGEgZGVsdGEgb24gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRzFhXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAod2hpY2gga2VlcHMgYmFzZWxpbmUgZm9yIE0w4oCTTTIpOyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJuZXQ6ZmV0Y2hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHN1cnZpdmVzIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNvbm5lY3Qtc3JjICdub25lJ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdmlhIHRoZSBob3N0IHByb3h5IChcIn08X2NvbXBvbmVudHMuY29kZT57XCJVSV9BU19BUFBTIMKnOC4xMVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLiBcIn08X2NvbXBvbmVudHMuZW0+e1wiTmVlZHMgcGVyLWZyYW1lLUNTUCBpbmZyYS5cIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiTGF1bmNoLXRvLXJ1biAvIHN0YW5kaW5nLWFwcCBsaWZlY3ljbGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgaW5jbC4gcGVyLWluc3RhbmNlIGRlbGVnYXRlZCBsYXVuY2gg4oCUIFwifTxfY29tcG9uZW50cy5lbT48X2NvbXBvbmVudHMuY29kZT57XCJTVEFORElOR19BUFBfTElGRUNZQ0xFXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgT3BlbiBRIzEwLCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlYyLCBkZXNpZ24tcGVuZGluZy5cIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiTkVULU5FVyBjb21wb3NpdGVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIGJpbmRpbmctcmVzb2x2ZWQgbWFuaWZlc3QgKyBjb21wb3NpdGUtYXdhcmUgcG93ZXJib3ggKHVuLWJ1bmRsZWQsIG1vYmlsZS1hd2FyZSkgKyBvYnNlcnZhYmlsaXR5IGluY2wuIHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImFnZ3JlZ2F0ZSByZWFjaCB2aWV3XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICjCpzYuMykuIE5vIGV4aXN0aW5nIGFuYWxvZy5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMub2w+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJEZWZlcnJlZCB1bnRpbCBmb3JjZWQ6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGEgdGllcmVkIG1lc3NhZ2UtYnVzIGZvciBoaWdoLWZyZXF1ZW5jeSBzdHJlYW1pbmcgKMKnNC4zKTsgc2libGluZy1lbnRyeS1wb2ludCBtZW1iZXJzIChBQS0wMSkuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5ociAvPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInNlYy05XCIgZGF0YS1zbHVnPVwiOS1kZWNpc2lvbnMtcmVqZWN0ZWQtYWx0ZXJuYXRpdmVzLXByb3Bvc2FsLWRvbnQtcmVsaXRpZ2F0ZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTlcIiAvPntcIjkuIERlY2lzaW9ucyAmIHJlamVjdGVkIGFsdGVybmF0aXZlcyAgXCJ9PF9jb21wb25lbnRzLmVtPntcIihwcm9wb3NhbCDigJQgZG9uJ3QgcmVsaXRpZ2F0ZSlcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkNvbmZpZGVudGlhbGl0eSBhcyByZWFjaCwgbm90IGVncmVzcy5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXCJ9PF9jb21wb25lbnRzLmVtPntcIlJlamVjdGVkOlwifTwvX2NvbXBvbmVudHMuZW0+e1wiIHNlYWxpbmcgZWdyZXNzOyBETFAuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJGb3VyIHJlYWxtczsgdGhlIG5vLWJvdGggaW52YXJpYW50IGlzIGFuIFwifTxfY29tcG9uZW50cy5lbT57XCJhcHAgZGlzY2lwbGluZVwifTwvX2NvbXBvbmVudHMuZW0+e1wiLCBjb250YWluZWQgKG5vdCBlbmZvcmNlZCkgYnkgZWdyZXNzLWZpeGluZyArIG91dHB1dC10aWVyaW5nIChib3RoIHVuYnVpbHQpICsgcGVyLXJlYWxtIGdyYW50IGNvbnNlbnQgKGJ1aWx0KSDigJQgTk9UIGJ5IGV4ZWN1dG9yIGRldGVjdGlvbiAoUkItMSkuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5lbT57XCJSZWplY3RlZDpcIn08L19jb21wb25lbnRzLmVtPntcIiBjbGFpbWluZyBob3N0LW9ic2VydmFibGUgZXhlY3V0b3IgZGV0ZWN0aW9uIGVuZm9yY2VzIGl0IChkZWxldGVkIGFzIHVucHJvdmFibGUsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlRSVVNUX01PREVTIMKnNToxNTJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKTsgY2xhaW1pbmcgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2Fwc0VudmVsb3BlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBlbmZvcmNlcyBpdCAocm9vdC1kZWNsYXJlZCwgYSBmb3JrIGxpZXMpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRXZhbHVhdG9yIHN0YXJ2ZWQgYnkgYXBwIGRlc2lnbjsgdGhlIGhvc3QgYmFja3N0b3BzIGFyZSBlZ3Jlc3MtZml4aW5nICsgb3V0cHV0LXRpZXJpbmcuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5lbT57XCJSZWplY3RlZDpcIn08L19jb21wb25lbnRzLmVtPntcIiBhc3NlcnRpbmcgc3RhcnZhdGlvbiBpcyBmb3JrLXByb29mLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRXZhbHVhdG9yIHJlc3VsdHMgYXJlIGVwaGVtZXJhbCAocmVuZGVyZWQsIG5vdCBwZXJzaXN0ZWQpOyBleHBsaWNpdCBmcmVlemUgcmVmbG9vcnMgb3IgaXMgZGlzYWxsb3dlZCAoUkItMikuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5lbT57XCJSZWplY3RlZDpcIn08L19jb21wb25lbnRzLmVtPntcIiBwZXJzaXN0aW5nIE0zLWRlcml2ZWQgdmFsdWVzIGludG8gYSBoaWdoZXItdHJ1c3Qgc2hlZXQgKGxhdW5kZXJzKTsgYSBibGFua2V0IFxcXCJuZXZlciB3cml0ZSB0aWVyZWQgYnl0ZXNcXFwiIHJ1bGUgKGluY29tcGF0aWJsZSB3aXRoIHRoZSBsaXZlIHByZW1pc2UpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRW5mb3JjZW1lbnQtYnktZ3JhbW1hciAobm9uLWV4ZWN1dGFibGUgTURYKS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXCJ9PF9jb21wb25lbnRzLmVtPntcIlJlamVjdGVkOlwifTwvX2NvbXBvbmVudHMuZW0+e1wiIENTUC1hbG9uZTsgYXJiaXRyYXJ5IGNvbXBvbmVudHMuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJJbmdlc3Rpb24gdGllciBob3N0LWFzc2lnbmVkIHBlciBpbnN0YW5jZSB2aWEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2FwRGlyXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBkZWxlZ2F0aW9uLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuZW0+e1wiUmVqZWN0ZWQ6XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgc2VsZi1kZWNsYXJlZCB0aWVyOyB3aG9sZS1jb21wb3NpdGUgZmxvb3I7IHN0YW5kaW5nIHBlci1cIn08X2NvbXBvbmVudHMuY29kZT57XCJhcHBLZXlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHNvdXJjZSBncmFudHM7IGEgbWVzc2FnZSBidXMgKGRlZmVycmVkKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkNvbm5lY3RvciA9IGR1bWIgcGlwZSB3aXRoIGhvc3QtZW5mb3JjZWQgZml4ZWQgdGFyZ2V0cyAoUTMpLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuZW0+e1wiUmVqZWN0ZWQ6XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgYW4gYWdlbnRpYyBjb25uZWN0b3IuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJFbWJlZGRlZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJHMTJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFnZW50OyBsaXZlIGNvbnRlbnQgdW4tZ2F0ZWQsIHB1Ymxpc2gvc291cmNlIGdhdGVkLCBib3VuZGFyeSBtYWRlIGxlZ2libGUgcHJlLWhvYyAoUkItNi9SQi05KS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXCJ9PF9jb21wb25lbnRzLmVtPntcIlJlamVjdGVkOlwifTwvX2NvbXBvbmVudHMuZW0+e1wiIHN0YWdlLWNvbXBvc2l0ZWQgc291cmNlIGFnZW50OyBjbGFpbWluZyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJUUy0xOWJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGdhdGVzIHRoZSBsaXZlIHBhdGg7IGEgc2lsZW50IGxpdmUvZ2F0ZSBib3VuZGFyeS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkNvbXBvc2l0ZSBtZW1iZXJzIGFyZSBiaW5kaW5nLXJlc29sdmVkIHVzZXItb3ZlcnJpZGFibGUgcm9sZXMgKFJBLTIpOyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjYXBzRW52ZWxvcGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGlzIGxlZ2liaWxpdHksIG5vdCBlbmZvcmNlbWVudCAoUkItMSkuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5lbT57XCJSZWplY3RlZDpcIn08L19jb21wb25lbnRzLmVtPntcIiBwaW5uZWQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibGF1bmNoKGFwcFJlZilcIn08L19jb21wb25lbnRzLmNvZGU+e1wiOyBhIGNvbXBvc2l0ZSBwcmluY2lwYWwgLyBtZXJnZWQgZ3JhbnRzOyBhIG5hbWUgdGhhdCBsYXVuZGVycyBhIGJhZGdlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVGhlIGNvbm5lY3RvcidzIFRTLTViIGxpbmUgaXMgaW5kaXZpZHVhbGx5IGNvbnNlbnRlZCwgbmV2ZXIgYnVuZGxlZCAoUkItMyk7IG5vIHBlci1jZWxsIGRlZ3JhZGF0aW9uIHByZXZpZXcgKFJCLTgpOyBydW4tbW9kZS1maXJzdCArIG1vYmlsZSBhcmUgZmlyc3QtY2xhc3MgKFJCLTQvUkItNSkuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5lbT57XCJSZWplY3RlZDpcIn08L19jb21wb25lbnRzLmVtPntcIiBhbiBcXFwiQXBwcm92ZSBhbGxcXFwiIHRoYXQgYnVuZGxlcyB0aGUgc2NhcnkgbGluZTsgYSBkZWdyYWRhdGlvbiBwcmV2aWV3IHRoZSBob3N0IGNhbm5vdCBjb21wdXRlOyBzaGlwcGluZyB0aGUgY29tcG9zaXRlIG11dGUgb24gdmFsdWVzIDIgYW5kIDguXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJcXFwiRGlzY2xvc2VkXFxcIiBpcyBiZXN0LWVmZm9ydCBkZWZlbnNlLWluLWRlcHRoIHdpdGggbm8gZWZmaWNhY3kgY2xhaW07IHRoZSBDbGFzcy1BIHJlc2lkdWFsIGlzIGFjY2VwdGVkIHVuY29uZGl0aW9uYWxseSBhdCBicm93c2VyLXBhcml0eSAoUkItNykuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5lbT57XCJSZWplY3RlZDpcIn08L19jb21wb25lbnRzLmVtPntcIiB0cmVhdGluZyBkaXNjbG9zdXJlIGFzIGEgbWl0aWdhdGlvbiB0aGUgc2FmZXR5IGFyZ3VtZW50IGxlYW5zIG9uLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaHIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtMTBcIiBkYXRhLXNsdWc9XCIxMC1hZHZlcnNhcmlhbC1yZXZpZXctcHJvcG9zYWxcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy0xMFwiIC8+e1wiMTAuIEFkdmVyc2FyaWFsIHJldmlldyAgXCJ9PF9jb21wb25lbnRzLmVtPntcIihwcm9wb3NhbClcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgzIGlkPVwic2VjLTEwYVwiIGRhdGEtc2x1Zz1cIjEwYS1hdXRob3Itc2VsZi1yZXZpZXctc3VwZXJzZWRlZC1ieS10aGUtdHdvLWZyZXNoLWFnZW50LXBhc3Nlcy1iZWxvd1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTEwYVwiIC8+e1wiMTBhLiBBdXRob3Igc2VsZi1yZXZpZXcg4oCUIHN1cGVyc2VkZWQgYnkgdGhlIHR3byBmcmVzaC1hZ2VudCBwYXNzZXMgYmVsb3cuXCJ9PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCJzZWMtMTBiXCIgZGF0YS1zbHVnPVwiMTBiLWZyZXNoLWFnZW50LXBhc3MtMS1yYS0xcmEtMTItZm9sZGVkXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtMTBiXCIgLz57XCIxMGIuIEZyZXNoLWFnZW50IHBhc3MgMSAoUkEtMeKAplJBLTEyKSDigJQgZm9sZGVkLlwifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiRm91bmQgdHdvIEJMT0NLRVJzIChSQS0xIHJvb3QtZGVjbGFyZWQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2Fwc0VudmVsb3BlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjYW4ndCBlbmZvcmNlOyBSQS0yIHBpbm5lZCBtZW1iZXIgcmVmcyBhcmUgdGhlIHJlamVjdGVkIFwifTxfY29tcG9uZW50cy5jb2RlPntcImxhdW5jaChhcHBSZWYpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikgKyBmaXZlIE1BSk9ScyAocGVyLWluc3RhbmNlIGtleWluZywgY3Jvc3MtbW91bnQgd3JpdGUtbGF1bmRlcmluZywgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRzFhXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB0cmlnZ2VyLCBsaXZlLXZzLWdhdGVkIGdhdGUsIGFuY2hvciBob25lc3R5KS4gQWxsIGZvbGRlZCBpbiB0aGUgZmlyc3QgcmV2aXNpb24uXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cInNlYy0xMGNcIiBkYXRhLXNsdWc9XCIxMGMtZnJlc2gtYWdlbnQtcGFzcy0yLXJiLTFyYi0xMC1mb2xkZWQtaW50by10aGlzLXJldmlzaW9uXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtMTBjXCIgLz57XCIxMGMuIEZyZXNoLWFnZW50IHBhc3MgMiAoUkItMeKAplJCLTEwKSDigJQgZm9sZGVkIGludG8gVEhJUyByZXZpc2lvbi5cIn08L19jb21wb25lbnRzLmgzPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlJlLWF0dGFja2VkIHRoZSBwYXNzLTEgZm9sZHMgYW5kIGNoYWxsZW5nZWQgc2VjdXJpdHkgKyBVWCArIGNsYWltLWhvbmVzdHkgaGFyZC4gUmVzdWx0czpcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlJCLTEgW0JMT0NLRVJdIOKAlCBSQS0xIHdhcyBSRUxBQkVMRUQsIG5vdCBmaXhlZC5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgXFxcIkV4ZWN1dG9yIGRldGVjdGlvblxcXCIgaXMgdGhlIGNvbnRlbnQtZmxvdyBnYXRlIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlRSVVNUX01PREVTIMKnNToxNTJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGRlbGV0ZXMgYXMgdW5wcm92YWJsZTsgYSBtZXRhY2lyY3VsYXIgaW50ZXJwcmV0ZXIgaW4gdGhlIFwifTxfY29tcG9uZW50cy5lbT57XCJjb25uZWN0b3JcIn08L19jb21wb25lbnRzLmVtPntcIiB2aW9sYXRlcyBuby1ib3RoIHVuZGV0ZWN0YWJseS4g4oaSIMKnMy4yIHJld3JpdHRlbjogdGhlIGludmFyaWFudCBpcyBhbiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImFwcCBkaXNjaXBsaW5lXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBjb250YWluZWQgKG5vdCBlbmZvcmNlZCkgYnkgZWdyZXNzLWZpeGluZyAoUTMsIHVuZGVzaWduZWQpICsgb3V0cHV0IHRpZXJpbmcgKMKnNCwgdW5idWlsdCkgKyBwZXItcmVhbG0gZ3JhbnQgY29uc2VudCAoYnVpbHQpOyB0aGUgZXhlY3V0b3ItZGV0ZWN0aW9uIGNsYWltIGlzIHN0cnVjay4gwqcwL3N0YXR1cyByZS1oZWRnZWQgKFJCLTEwKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlJCLTIgW0JMT0NLRVJdIOKAlCBSUy0xMCB3cml0ZS1sYXVuZGVyaW5nIGNvbnRyYWRpY3RzIHRoZSBsaXZlIHByZW1pc2UuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKGkiDCpzUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJlcGhlbWVyYWwtY29tcHV0ZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBydWxlOiBldmFsdWF0b3IgcmVzdWx0cyByZW5kZXIsIG5ldmVyIHBlcnNpc3Q7IGV4cGxpY2l0IGZyZWV6ZSByZWZsb29ycy1vci1kaXNhbGxvd2VkLiBSUy0xMCBlc2NhbGF0ZWQgKMKnMTEvwqcxMikuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJSQi0zIFtNQUpPUl0g4oCUIFxcXCJBcHByb3ZlIGFsbFxcXCIgYnVuZGxlcyB0aGUgVFMtNWIgbGluZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoVFMtMTkgIzIpLiDihpIgwqc2LjIgaW5kaXZpZHVhbCBjb25uZWN0b3IgY29uc2VudC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlJCLTQgW01BSk9SXSDigJQgbW9iaWxlICh2YWx1ZSA4KSBhYnNlbnQuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKGkiDCpzYuNCBhZGRlZC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlJCLTUgW01BSk9SXSDigJQgcnVuLW1vZGUtZmlyc3QgKHZhbHVlIDIpIGNvbXByb21pc2VkLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDihpIgwqcxL8KnNi40IHN0YXRpYy1kYXNoYm9hcmQtbm8tcG93ZXJib3ggcGF0aC5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlJCLTYgW01BSk9SXSDigJQgcmVhY2gtYm91bmQgcmVzdHMgb24gdW5idWlsdCBhZ2dyZWdhdGUgbGVnaWJpbGl0eS5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oaSIMKnMy4xL8KnNi4zIGFnZ3JlZ2F0ZSByZWFjaCB2aWV3ICsgdm9sdW1lIHNpZ25hbCwgc3RhdGVkIHVuYnVpbHQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJSQi03IFtNQUpPUl0g4oCUIFxcXCJkaXNjbG9zZWRcXFwiIG92ZXItY2xhaW1zLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDihpIgwqczLjEvwqc5IGRvd25ncmFkZWQgdG8gYmVzdC1lZmZvcnQsIG5vLWVmZmljYWN5OyByZXNpZHVhbCBhY2NlcHRlZCB1bmNvbmRpdGlvbmFsbHkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJSQi04IFtNQUpPUl0g4oCUIFxcXCJkZWdyYWRhdGlvbiBwcmV2aWV3XFxcIiBpcyB1bmNvbXB1dGFibGUuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKGkiDCpzYuMiBjb2Fyc2UsIHN0YXRpY2FsbHkta25vd24gbG9zc2VzIG9ubHkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJSQi05IFtNQUpPUl0g4oCUIGxpdmUvZ2F0ZSBib3VuZGFyeSBpbGxlZ2libGUuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKGkiDCpzUgcHJlLWhvYyBhZmZvcmRhbmNlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUkItMTAgW01BSk9SLCBob25lc3R5IGhlYWRsaW5lXSDigJQgXFxcImZlYXNpYmlsaXR5LXJlc29sdmVkXFxcIiBvdXRyYW4gdGhlIGV2aWRlbmNlLlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDihpIgwqcwL3N0YXR1cyBub3c6IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wic2hhcGUgZmVhc2libGU7IHNhZmV0eSBjb250aW5nZW50IG9uIHVuYnVpbHQgZGVsdGFzLCBub3QgcmVzb2x2ZWQuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUmVtYWluaW5nIGV4aXQgc3RlcDpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgYSB0aGlyZCBmcmVzaC1hZ2VudCBwYXNzIG9uIFRISVMgcmV2aXNpb24g4oCUIGVzcGVjaWFsbHkgb24gwqczLjIncyBob25lc3R5IChkb2VzIHRoZSBcXFwiYXBwLWRpc2NpcGxpbmUgKyB1bmJ1aWx0LWJhY2tzdG9wc1xcXCIgZnJhbWluZyBmaW5hbGx5IHN0YXRlIHRoZSB0cnV0aCwgb3Igc3RpbGwgb3ZlcmNsYWltPyksIHRoZSDCpzUgZXBoZW1lcmFsLWNvbXB1dGUgcmVzb2x1dGlvbiwgYW5kIHdoZXRoZXIgdGhlIHNhZmV0eSB2ZXJkaWN0IGlzIG5vdyBwcm9wb3J0aW9uYXRlLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaHIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtMTFcIiBkYXRhLXNsdWc9XCIxMS10aHJlYXQtaWQtcmVnaXN0cnktcHJvcG9zYWxcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy0xMVwiIC8+e1wiMTEuIFRocmVhdC1JRCByZWdpc3RyeSAgXCJ9PF9jb21wb25lbnRzLmVtPntcIihwcm9wb3NhbClcIn08L19jb21wb25lbnRzLmVtPjwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnRhYmxlPjxfY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRoPntcIklEXCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGg+e1wiVGhyZWF0XCJ9PC9fY29tcG9uZW50cy50aD48X2NvbXBvbmVudHMudGg+e1wiU3RhdHVzXCJ9PC9fY29tcG9uZW50cy50aD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGhlYWQ+PF9jb21wb25lbnRzLnRib2R5PjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnN0cm9uZz57XCJSUy0xXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiTWFsaWNpb3VzL3NoYXJlZCBmb3JtdWxhIChvciBtZXRhY2lyY3VsYXItaW50ZXJwcmV0ZXIgY29ubmVjdG9yKSBleGZpbHRyYXRlc1wifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIkNvbnRhaW5lZCBieSBlZ3Jlc3MtZml4aW5nIChRMywgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ1bmJ1aWx0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiKSArIG91dHB1dCB0aWVyaW5nIChcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInVuYnVpbHRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIpOyBDbGFzcy1BIHJlc2lkdWFsIGFjY2VwdGVkICjCpzMuMSlcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlJTLTJcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJBIGNvbnRlbnQtZXhlY3V0aW5nL2FnZW50IHJlYWxtIHJlYWRzIENsYXNzIEJcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJQZXItcmVhbG0gQ2xhc3MtQS1vbmx5IGdyYW50cyArIGNvbnNlbnQgdmlzaWJpbGl0eSAoXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJidWlsdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIik7IMKnMy4yXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnN0cm9uZz57XCJSUy0zXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiSW5qZWN0ZWQgYWdlbnQgd2llbGRzIGRhbmdlcm91cyBjYXBzXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiRzEyXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBDbGFzcy1BIGNhdGFsb2c7IENsYXNzLUIgY2FwcyBsaXZlIGluIHRoZSBjb25uZWN0b3IgKMKnNSlcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlJTLTRcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJGZWVkL3NoYXJlZC1zaGVldCBzdGVlcnMgdGhlIGFnZW50XCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiRmVuY2VkIGRhdGE7IHRhaW50IOKGkiBhdHRlbmRlZCAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiVFMtMVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiVFMtM1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpOyBwdWJsaXNoL3NvdXJjZSBkaWZmIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJUUy0xOWJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSDigJQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ0YWludCByZXN0cyBvbiDCpzQgKHVuYnVpbHQpXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnN0cm9uZz57XCJSUy01XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiSW5nZXN0aW9uIGxhdW5kZXJzIE0zIOKGkiBNMSAoaW5ncmVzcylcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJQZXItaW5zdGFuY2UgbW91bnQgdGllciBmbG9vciAowqc0KSDigJQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ1bmJ1aWx0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnN0cm9uZz57XCJSUy02XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiQ29ubmVjdG9yIHN0ZWVyZWQgdG8gZXhmaWx0cmF0ZVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIkR1bWIgcGlwZSArIGhvc3QtZml4ZWQgdGFyZ2V0cyAowqc0LjUsIFEzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1widW5kZXNpZ25lZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIikg4oCUIHRoZSBsb2FkLWJlYXJpbmcgZ2FwXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnN0cm9uZz57XCJSUy03XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiQ29udGVudCBleGVjdXRlcyBpbiB0aGUgcmVwb3J0IHZpZXdcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJOb24tZXhlY3V0YWJsZSBzYWZlIHJlbmRlcmVyICjCpzMuNCwgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ1bmJ1aWx0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiKVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUlMtOFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIkNvbXBvc2l0ZSBuYW1lIGxhdW5kZXJzIGEgbWVtYmVyJ3MgdHJ1c3RcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJIb3N0LXRydXRoIGJhZGdlcyBvbiB0aGUgYm91bmQgcHJvdmlkZXIgKMKnNi4xL8KnNi4yKVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUlMtOVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIlVuZGVjbGFyZWQgc2FuZGJveCB1bmRlciB0aGUgYXBwXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiTWFuaWZlc3Qg4oaUIGxhdW5jaC1ncmFwaCByZWNvbmNpbGlhdGlvbiAowqc2LjEpXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnN0cm9uZz57XCJSUy0xMFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiTGl2ZSB3cml0ZS1sYXVuZGVyaW5nOiBhbiBNMy1kZXJpdmVkIHZhbHVlIHBlcnNpc3RlZCBpbnRvIGEgaGlnaGVyLXRydXN0IHNoZWV0XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnN0cm9uZz57XCJSZXNvbHZlZCBmb3IgdGhlIGxpdmUgcGF0aCBieSBlcGhlbWVyYWwgY29tcHV0ZSAowqc1KTsgdGhlIGV4cGxpY2l0LWZyZWV6ZSBjYXNlIHJlZmxvb3JzLW9yLWRpc2FsbG93c1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgYm9va2VkLCBkZXBlbmRlbmN5IFwifTxfY29tcG9uZW50cy5jb2RlPntcIkFVVEhPUklOR19QUk9WRU5BTkNFXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9SMy0xNTZcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlJTLTExXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiQWdncmVnYXRlIHJlYWNoIHJlY29uc3RydWN0ZWQgdmlhIG1hbnkgbmFycm93IGZlZWQgZGVsdGFzIChjb25zZW50IGZhdGlndWUpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiQWdncmVnYXRlIHJlYWNoIHZpZXcgKyB2b2x1bWUgc2lnbmFsICjCpzMuMS/CpzYuMykg4oCUIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1widW5idWlsdFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRib2R5PjwvX2NvbXBvbmVudHMudGFibGU+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmhyIC8+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTEyXCIgZGF0YS1zbHVnPVwiMTItYm9va2VkLXJlc2lkdWFscy1vcGVuLXF1ZXN0aW9ucy1wcm9wb3NhbFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTEyXCIgLz57XCIxMi4gQm9va2VkIHJlc2lkdWFscyAmIG9wZW4gcXVlc3Rpb25zICBcIn08X2NvbXBvbmVudHMuZW0+e1wiKHByb3Bvc2FsKVwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkJvb2tlZCByZXNpZHVhbHM6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIENsYXNzLUEgc2VsZi1leGZpbCAocmV0dXJuIHZhbHVlIC8gc2VsZi1uYXYgb25lLXNlY3JldCwgYnJvd3Nlci1wYXJpdHksIGFjY2VwdGVkIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1widW5jb25kaXRpb25hbGx5XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBkaXNjbG9zdXJlIGJlc3QtZWZmb3J0KTsgVFMtNCBib2R5LWV4ZmlsIHRvIGFuIGVncmVzcy1maXhlZCBsZWdpdGltYXRlIGhvc3Q7IHNoYXJlZC1zaGVldCBjb250ZW50IHJlYWNoaW5nIHRoZSBMTE0gcHJvdmlkZXIgdmlhIHRoZSBhc3Npc3RhbnQ7IG5hcnJvdy1jb25maWRlbnRpYWwtcmVhZCAobm8gRExQKTsgb3Zlci10YWludGluZyBmcm9tIHBlci1pbnN0YW5jZSBmbG9vcmluZzsgZXhwbGljaXQtZnJlZXplIGRvd24tdGllcmluZyBvZiBhIHBlcnNvbmFsIHNoZWV0ICjCpzUpLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIk9wZW4gcXVlc3Rpb25zICh0aGUgaG9uZXN0IGdhcHMpOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUTFcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHNwaW4gdGhlIGNvbXBvc2l0ZSBpbnRvIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkNPTVBPU0lURV9BUFBfU1BFQ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJRMlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgXCJ9PF9jb21wb25lbnRzLmVtPntcIihSQi0xKVwifTwvX2NvbXBvbmVudHMuZW0+e1wiIHRoZXJlIGlzIG5vIGhvc3Qtb2JzZXJ2YWJsZSBleGVjdXRvci1kZXRlY3Rpb24gc2lnbmFsOyBpcyB0aGUgXFxcImVncmVzcy1maXhpbmcgKyBvdXRwdXQtdGllcmluZ1xcXCIgYmFja3N0b3AgcGFpciBcIn08X2NvbXBvbmVudHMuZW0+e1wic3VmZmljaWVudFwifTwvX2NvbXBvbmVudHMuZW0+e1wiIHRvIGNhbGwgdGhlIGFwcCBzYWZlLCBvciBpcyBhIGZ1cnRoZXIgbWVjaGFuaXNtIG5lZWRlZCBmb3IgYSBtZXRhY2lyY3VsYXItY29ubmVjdG9yIGZvcms/XCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJRMyDigJQgdGhlIGhvc3QtZW5mb3JjZWQgZm9ybSBvZiB0aGUgY29ubmVjdG9yJ3MgZml4ZWQgZmV0Y2ggdGFyZ2V0cy4gVU5ERVNJR05FRCBhbmQgbG9hZC1iZWFyaW5nICjCpzMuMi/CpzQuNSkuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJRNFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgdGhlIGVsZXZhdGVkIHNsb3QvcHJpbmNpcGFsIGZvciB0aGUgY29ubmVjdG9yOyBvcGVuIHZzIGZpcnN0LXBhcnR5LXJlc3RyaWN0ZWQuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJRNVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgaGlnaC1mcmVxdWVuY3kgc3RyZWFtaW5nICh0aWVyZWQgbWVzc2FnZSBidXMpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUTZcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIFwifTxfY29tcG9uZW50cy5lbT57XCIoUkItMilcIn08L19jb21wb25lbnRzLmVtPntcIiB0aGUgZXhwbGljaXQtZnJlZXplIHJlZmxvb3Igc2VtYW50aWNzICsgVVg7IGRvZXMgZG93bi10aWVyaW5nIGEgcGVyc29uYWwgc2hlZXQgb24gZnJlZXplIHN1cnByaXNlIHVzZXJzP1wifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUTdcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIFwifTxfY29tcG9uZW50cy5lbT57XCIoUkItNC9SQi01L1JCLTYpXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgb3duZXJzIGZvciB0aGUgbW9iaWxlIGNvbXBvc2l0ZSBzdXJmYWNlcyBhbmQgdGhlIGFnZ3JlZ2F0ZSByZWFjaCB2aWV3LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMuaHIgLz57XCJcXG5cIn08X2NvbXBvbmVudHMuaDIgaWQ9XCJzZWMtMTNcIiBkYXRhLXNsdWc9XCIxMy1sb2FkLWJlYXJpbmctYXNzdW1wdGlvbnMtY29kZS1hbmNob3JzLXJlcXVpcmVkXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtMTNcIiAvPntcIjEzLiBMb2FkLWJlYXJpbmcgYXNzdW1wdGlvbnMgJiBjb2RlIGFuY2hvcnMgIFwifTxfY29tcG9uZW50cy5lbT57XCIocmVxdWlyZWQpXCJ9PC9fY29tcG9uZW50cy5lbT48L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cImRlcGVuZHMtb24tdG9kYXktZ3JlcC12ZXJpZmllZFwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiZGVwZW5kcy1vbi10b2RheS1ncmVwLXZlcmlmaWVkXCIgLz57XCJEZXBlbmRzLW9uLXRvZGF5IChncmVwLXZlcmlmaWVkKVwifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnRhYmxlPjxfY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRoPntcIkFzc3VtcHRpb25cIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aD57XCJBbmNob3IgKHJlcG8tcmVsYXRpdmUgZmlsZSlcIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aD57XCJUb2tlbiAoZ3JlcC1zdGFibGUpXCJ9PC9fY29tcG9uZW50cy50aD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGhlYWQ+PF9jb21wb25lbnRzLnRib2R5PjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiQXBwIGNvZGUgcnVucyBpbiBvcGFxdWUtb3JpZ2luIHNhbmRib3hlZCBpZnJhbWVzIHdpdGhvdXQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYWxsb3ctc2FtZS1vcmlnaW5cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiaW1tZWRpYXRlbHktcnVuLXNhbmRwYWNrL3NhbmRwYWNrLWNsaWVudC9zcmMvY2xpZW50cy9pZnJhbWUtZmFjdG9yeS50c1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJhbGxvdy1zY3JpcHRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkhvc3QgQ1NQIGVuZm9yY2VzIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNjcmlwdC1zcmMgJ3NlbGYnXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgbm8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widW5zYWZlLWV2YWxcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiaW1tZWRpYXRlbHktcnVuLXNpdGUtbWFpbi9zcmMvc2VjdXJpdHkvY3NwLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcInNjcmlwdC1zcmNcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+e1wiQW4gYXBwIGVtYmVkcyBhbiBhZ2VudCB3aG9zZSB0b29scyBhcmUgdGhlIGdyYW50LWZpbHRlcmVkIGNhdGFsb2cgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIkcxMlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiYWdlbnQtZGVtby9zcmNcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1widXNlQ2F0YWxvZ1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJBIG1vdW50IGlzIGV4cG9ydGVkIHRvIGEgY29uc3VtZXIgb3ZlciBhIFwifTxfY29tcG9uZW50cy5jb2RlPntcIk1lc3NhZ2VQb3J0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgc2NvcGVkICsgbW9kZS1jbGFtcGVkXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiaW1tZWRpYXRlbHktcnVuLXNpdGUtbWFpbi9zcmMvZWRpdG9yL3Rhc2svbWludERlbGVnYXRpb25zLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5jb2RlPntcImV4cG9ydFplbkZTXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIlNvdXJjZSB0aWVyIGlzIGNvbXB1dGVkIGxpdmUgZnJvbSBtZW1iZXJzaGlwLCBuZXZlciBhIHN0YWxlIHN0b3JlZCBiaXRcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJkb2NzL3NwZWNzL0ZJTEVTWVNURU1fU1BFQy5tZFwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJuZXZlciBhIHN0YWxlIHN0b3JlZCBiaXRcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wibmV0OmZldGNoXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpcyBob3N0LXByb3hpZWQgb3ZlciB0aGUgcGFyZW50IG9yaWdpbiAoc3Vydml2ZXMgaWZyYW1lIFwifTxfY29tcG9uZW50cy5jb2RlPntcImNvbm5lY3Qtc3JjICdub25lJ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wiZG9jcy9zcGVjcy9VSV9BU19BUFBTX1NQRUMubWRcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wibmV0LWZldGNoXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIlRoZSBpbnRlcnByZXRlci9leGVjdXRvciBzcGxpdCBpcyBub3QgYSBob3N0LWVuZm9yY2VhYmxlIGNhcGFiaWxpdHkgZ2F0ZSAoYm91bmRzIMKnMy4yJ3MgaG9uZXN0eSlcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJkb2NzL3NwZWNzL1RSVVNUX01PREVTX1NQRUMubWRcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wibm90KiBhIGNhcGFiaWxpdHkgZ2F0ZVwifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50Ym9keT48L19jb21wb25lbnRzLnRhYmxlPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cIm11c3QtZXN0YWJsaXNoLW5ldy1pbnZhcmlhbnRzLXRoZS1pbXBsZW1lbnRhdGlvbi1tdXN0LWNyZWF0ZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwibXVzdC1lc3RhYmxpc2gtbmV3LWludmFyaWFudHMtdGhlLWltcGxlbWVudGF0aW9uLW11c3QtY3JlYXRlXCIgLz57XCJNdXN0LWVzdGFibGlzaCAobmV3IGludmFyaWFudHMgdGhlIGltcGxlbWVudGF0aW9uIG11c3QgY3JlYXRlKVwifTwvX2NvbXBvbmVudHMuaDM+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnRhYmxlPjxfY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRoPntcIk5ldyBpbnZhcmlhbnRcIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aD57XCJQcm92ZW4gYnkgKGdhdGUgdGVzdClcIn08L19jb21wb25lbnRzLnRoPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudGJvZHk+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJDb25uZWN0b3Itb3V0cHV0ICYgZXZhbHVhdG9yLXJlc3VsdCBtb3VudHMgY2FycnkgYSBob3N0LWFzc2lnbmVkIHRpZXIgPSBmbG9vciBvZiBwZXItaW5zdGFuY2UtZGVsZWdhdGVkIGlucHV0cyAowqc0KVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcImluZ2VzdGlvbi10YWludCBnYXRlOiBNMy1ib3VuZCBvdXRwdXQgYXJyaXZlcyB0YWdnZWQgTTM7IHR3byBpbnN0YW5jZXMgb2Ygb25lIGNvbm5lY3RvciBcIn08X2NvbXBvbmVudHMuY29kZT57XCJhcHBLZXlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHNoYXJlIG5vIHNvdXJjZSBncmFudFwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiSG9zdC1lbmZvcmNlZCBjb25uZWN0b3IgZWdyZXNzLWZpeGluZyAoUTMpOiBhIGNvbm5lY3RvciBjYW5ub3QgZmV0Y2ggYSBub24tZml4ZWQgaG9zdCBldmVuIHVuZGVyIGEgbWV0YWNpcmN1bGFyIGludGVycHJldGVyICjCpzMuMi/CpzQuNSlcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJlZ3Jlc3MtZml4aW5nIGdhdGUg4oCUIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1widGhlIGxvYWQtYmVhcmluZywgdW5kZXNpZ25lZCBiYWNrc3RvcFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIlRoZSBzYWZlIHJlbmRlcmVyIHJ1bnMgbm8gYXV0aG9yIEpTICjCpzMuNClcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJmPXtmZXRjaChcXFwiL3hcXFwiKX1cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNhcHR1cmVkIGFzIGFuIGluZXJ0IHN0cmluZzsgbm8gZXZhbHVhdG9yIGluIHRoZSBwaXBlbGluZVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIkV2YWx1YXRvciByZXN1bHRzIGFyZSBuZXZlciBzaWxlbnRseSBwZXJzaXN0ZWQgaW50byBhIGhpZ2hlci10cnVzdCBzaGVldDsgZXhwbGljaXQgZnJlZXplIHJlZmxvb3JzIG9yIGlzIHJlZnVzZWQgKMKnNS9SUy0xMClcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJ3cml0ZS1sYXVuZGVyaW5nIGdhdGUgKGRlcGVuZGVuY3kgUjMtMTU2KVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPntcIlRoZSBjb21wb3NpdGUgbmFtZSBjYW5ub3QgYWx0ZXIgYSBib3VuZCBtZW1iZXIncyBob3N0LXRydXRoIGJhZGdlOyB0aGUgY29ubmVjdG9yJ3MgVFMtNWIgbGluZSBpcyBhIHN0YW5kLWFsb25lIGNvbnNlbnQgKMKnNi4xL8KnNi4yKVwifTwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcInBvd2VyYm94IHRlc3RzIChiYWRnZSBpbnRlZ3JpdHk7IHVuLWJ1bmRsZWQgZWxldmF0ZWQgbGluZSlcIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD57XCJBIHN0YXRpYy9pbi1zaGVldC1vbmx5IGRhc2hib2FyZCBsYXVuY2hlcyB3aXRoIG5vIGVsZXZhdGVkIHBvd2VyYm94IG9uIGFueSBkZXZpY2UgKMKnMS/CpzYuNClcIn08L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD57XCJydW4tbW9kZS1maXJzdCBnYXRlIChkZXNrdG9wICsgbW9iaWxlKVwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48L19jb21wb25lbnRzLnRib2R5PjwvX2NvbXBvbmVudHMudGFibGU+PC8+O1xufVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTURYQ29udGVudChwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHt3cmFwcGVyOiBNRFhMYXlvdXR9ID0ge1xuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfTtcbiAgcmV0dXJuIE1EWExheW91dCA/IDxNRFhMYXlvdXQgey4uLnByb3BzfT48X2NyZWF0ZU1keENvbnRlbnQgey4uLnByb3BzfSAvPjwvTURYTGF5b3V0PiA6IF9jcmVhdGVNZHhDb250ZW50KHByb3BzKTtcbn1cbmZ1bmN0aW9uIF9taXNzaW5nTWR4UmVmZXJlbmNlKGlkLCBjb21wb25lbnQsIHBsYWNlKSB7XG4gIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIFwiICsgKGNvbXBvbmVudCA/IFwiY29tcG9uZW50XCIgOiBcIm9iamVjdFwiKSArIFwiIGBcIiArIGlkICsgXCJgIHRvIGJlIGRlZmluZWQ6IHlvdSBsaWtlbHkgZm9yZ290IHRvIGltcG9ydCwgcGFzcywgb3IgcHJvdmlkZSBpdC5cIiArIChwbGFjZSA/IFwiXFxuSXTigJlzIHJlZmVyZW5jZWQgaW4geW91ciBjb2RlIGF0IGBcIiArIHBsYWNlICsgXCJgIGluIGAvYXBwL2RvY3MvUkVQT1JUSU5HX1NQUkVBRFNIRUVUX1NQRUMubWRgXCIgOiBcIlwiKSk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUVBLElBQUFBLFlBQUEsR0FBQUMsT0FBQTtBQUF3RixJQUFBQyxXQUFBLEdBQUFELE9BQUE7QUFGeEY7QUFDQTs7QUFFQSxTQUFTRSxpQkFBaUJBLENBQUNDLEtBQUssRUFBRTtFQUNoQyxNQUFNQyxXQUFXLEdBQUc7TUFDbEJDLFVBQVUsRUFBRSxZQUFZO01BQ3hCQyxJQUFJLEVBQUUsTUFBTTtNQUNaQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxDQUFDLEVBQUUsR0FBRztNQUNOQyxHQUFHLEVBQUUsS0FBSztNQUNWQyxNQUFNLEVBQUUsUUFBUTtNQUNoQkMsS0FBSyxFQUFFLE9BQU87TUFDZEMsS0FBSyxFQUFFLE9BQU87TUFDZEMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUkMsS0FBSyxFQUFFLE9BQU87TUFDZEMsRUFBRSxFQUFFLElBQUk7TUFDUkMsRUFBRSxFQUFFLElBQUk7TUFDUixHQUFHLElBQUFDLDZCQUFrQixFQUFDLENBQUM7TUFDdkIsR0FBR3JCLEtBQUssQ0FBQ3NCO0lBQ1gsQ0FBQztJQUFFO01BQUNDO0lBQWEsQ0FBQyxHQUFHdEIsV0FBVztFQUNoQyxJQUFJLENBQUNzQixhQUFhLEVBQUVDLG9CQUFvQixDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUM7RUFDL0Qsb0JBQU8sSUFBQTFCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQTNCLFdBQUEsQ0FBQTRCLFFBQUE7SUFBQUMsUUFBQSxnQkFBRSxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDSSxFQUFFO01BQUN1QixFQUFFLEVBQUMsNkZBQTZGO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBNkYsQ0FBRSxDQUFDLEVBQUMsZ0dBQWdHO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVMsQ0FBcUIsQ0FBQyxFQUFDLHNCQUFzQixlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxHQUFFLFVBQVUsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBTyxDQUFpQixDQUFDLEVBQUMseUVBQXlFLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQVEsQ0FBaUIsQ0FBQyxFQUFDLGtPQUFrTztNQUFBLENBQXFCLENBQUMsRUFBQywySUFBMkksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFVLENBQXFCLENBQUMsRUFBQyxhQUFhO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDQyxVQUFVO01BQUF5QixRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNVLENBQUM7UUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEdBQUUsMkRBQTJELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBd0IsUUFBQSxFQUFFO1VBQTZDLENBQW1CLENBQUM7UUFBQSxDQUFvQixDQUFDLEVBQUMsd0VBQXdFLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQTZFLENBQWlCLENBQUM7TUFBQSxDQUFlLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBeUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDQyxVQUFVO01BQUF5QixRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNVLENBQUM7UUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBYyxDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUEwQixDQUFtQixDQUFDLEVBQUMsc0JBQXNCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQTJCLENBQW1CLENBQUMsRUFBQyw2Q0FBNkMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBcUIsQ0FBbUIsQ0FBQyxFQUFDLGdFQUFnRSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxHQUFFLDZFQUE2RSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7WUFBQXVCLFFBQUEsRUFBRTtVQUFLLENBQWlCLENBQUMsRUFBQyxxREFBcUQ7UUFBQSxDQUFxQixDQUFDLEVBQUMsb0VBQW9FLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQUssQ0FBbUIsQ0FBQyxFQUFDLDREQUE0RCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFpQyxDQUFtQixDQUFDLEVBQUMscUJBQXFCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQTBCLENBQW1CLENBQUMsRUFBQyw0RkFBNEYsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBb0IsQ0FBbUIsQ0FBQyxFQUFDLGlDQUFpQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQStCLENBQW1CLENBQUMsRUFBQyxTQUFTLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQWdDLENBQW1CLENBQUMsRUFBQyw2RkFBNkYsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBb0IsQ0FBbUIsQ0FBQyxFQUFDLE1BQU07TUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQXlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ08sRUFBRSxJQUFFLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQVYsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDSyxFQUFFO01BQUNzQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUsa0VBQWtFO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQyw4REFBOEQsZUFBQyxJQUFBOUIsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1FBQUF1QixRQUFBLEVBQUU7TUFBWSxDQUFpQixDQUFDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLEdBQUUsaUxBQWlMLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBc0IsQ0FBcUIsQ0FBQyxFQUFDLDBEQUEwRCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQWUsQ0FBcUIsQ0FBQyxFQUFDLHVDQUF1QztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLGdCQUFnQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQXlGLENBQXFCLENBQUM7SUFBQSxDQUFlLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0MsVUFBVTtNQUFBeUIsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDVSxDQUFDO1FBQUFnQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXVFLENBQXFCLENBQUMsRUFBQyxxRUFBcUUsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFnRixDQUFxQixDQUFDLEVBQUMsY0FBYyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFPLENBQWlCLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBa0ksQ0FBcUIsQ0FBQyxFQUFDLHFDQUFxQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQW1CLENBQXFCLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBMkMsQ0FBcUIsQ0FBQyxFQUFDLFdBQVcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBUSxDQUFpQixDQUFDLEVBQUMsb0JBQW9CLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBMkMsQ0FBcUIsQ0FBQyxFQUFDLGdDQUFnQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTJCLENBQXFCLENBQUMsRUFBQyxvRkFBb0YsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUF1QixDQUFxQixDQUFDLEVBQUMsbUZBQW1GLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBaUksQ0FBcUIsQ0FBQyxFQUFDLGdJQUFnSTtNQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBeUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLEVBQUU7SUFBMkgsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDTyxFQUFFLElBQUUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBVixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNLLEVBQUU7TUFBQ3NCLEVBQUUsRUFBQyxPQUFPO01BQUMsYUFBVSx3QkFBd0I7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLGtCQUFrQixlQUFDLElBQUE5QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUFZLENBQWlCLENBQUM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNVLENBQUM7TUFBQWdCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBdUIsQ0FBcUIsQ0FBQyxFQUFDLG9IQUFvSCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQWEsQ0FBcUIsQ0FBQyxFQUFDLDREQUE0RCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQTJELENBQXFCLENBQUMsRUFBQyxHQUFHO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQXNCLENBQXFCLENBQUMsRUFBQyx5QkFBeUI7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNhLEtBQUs7TUFBQWEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDaUIsS0FBSztRQUFBUyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBTyxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBYSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBZSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBYyxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBVyxDQUFpQixDQUFDO1FBQUEsQ0FBZ0I7TUFBQyxDQUFtQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDYyxLQUFLO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUEwQixDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFXLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQW9CLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQWlCLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQWtDLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQXlCLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQVcsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBdUIsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBbUIsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBZ0IsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBaUMsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBVyxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFjLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxHQUFFLFVBQVUsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO2NBQUF1QixRQUFBLEVBQUU7WUFBSSxDQUFpQixDQUFDLEVBQUMsa0JBQWtCO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBZSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQztNQUFBLENBQW1CLENBQUM7SUFBQSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNVLENBQUM7TUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBbUQsQ0FBcUIsQ0FBQyxFQUFDLG9CQUFvQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQTZCLENBQXFCLENBQUMsRUFBQyxpQ0FBaUMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUF1QyxDQUFxQixDQUFDLEVBQUMsd0dBQXdHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBd0IsQ0FBcUIsQ0FBQyxFQUFDLHlIQUF5SDtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ08sRUFBRSxJQUFFLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQVYsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDSyxFQUFFO01BQUNzQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUsdURBQXVEO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQyxrQ0FBa0MsZUFBQyxJQUFBOUIsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1FBQUF1QixRQUFBLEVBQUU7TUFBNkIsQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLGtDQUFrQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFTLENBQW1CLENBQUMsRUFBQywwREFBMEQ7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNhLEtBQUs7TUFBQWEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDaUIsS0FBSztRQUFBUyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBTyxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBTSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZ0IsRUFBRTtZQUFDYSxLQUFLLEVBQUU7Y0FDeGxTQyxTQUFTLEVBQUU7WUFDYixDQUFFO1lBQUFKLFFBQUEsRUFBRTtVQUFtQixDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBTyxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBWSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0I7TUFBQyxDQUFtQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDYyxLQUFLO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBYSxDQUFxQixDQUFDLEVBQUMsVUFBVTtVQUFBLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQXVDLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQ2MsS0FBSyxFQUFFO2NBQzlZQyxTQUFTLEVBQUU7WUFDYixDQUFFO1lBQUFKLFFBQUEsRUFBRTtVQUFJLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFjLENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQVMsQ0FBbUIsQ0FBQyxFQUFDLGlDQUFpQztVQUFBLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQWdELENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFnQixDQUFxQixDQUFDLEVBQUMsY0FBYztVQUFBLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQWlDLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQ2MsS0FBSyxFQUFFO2NBQ3RnQkMsU0FBUyxFQUFFO1lBQ2IsQ0FBRTtZQUFBSixRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBSyxDQUFxQjtVQUFDLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFTLENBQXFCLENBQUMsRUFBQywwQkFBMEI7VUFBQSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFHLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQW1CLENBQXFCO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBMkMsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFDYyxLQUFLLEVBQUU7Y0FDOWJDLFNBQVMsRUFBRTtZQUNiLENBQUU7WUFBQUosUUFBQSxHQUFFLFFBQVEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO2NBQUF1QixRQUFBLEVBQUU7WUFBVyxDQUFpQixDQUFDLEVBQUMsU0FBUztVQUFBLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxHQUFFLFlBQVksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBYSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFXLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBNEIsQ0FBcUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUF3QixDQUFxQixDQUFDLEVBQUMsc0JBQXNCO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBc0IsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQVcsQ0FBcUIsQ0FBQyxFQUFDLFVBQVU7VUFBQSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUF5QyxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUNjLEtBQUssRUFBRTtjQUMvckJDLFNBQVMsRUFBRTtZQUNiLENBQUU7WUFBQUosUUFBQSxFQUFFO1VBQUksQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQWMsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBVSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFTLENBQW1CLENBQUMsRUFBQyx5Q0FBeUMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBSyxDQUFtQixDQUFDLEVBQUMsR0FBRztVQUFBLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQWMsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7Y0FBQXVCLFFBQUEsRUFBRTtZQUFRLENBQWlCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBZSxDQUFxQixDQUFDO1VBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBcUMsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFDYyxLQUFLLEVBQUU7Y0FDdm5CQyxTQUFTLEVBQUU7WUFDYixDQUFFO1lBQUFKLFFBQUEsRUFBRTtVQUFJLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQUcsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBSSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQztNQUFBLENBQW1CLENBQUM7SUFBQSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNVLENBQUM7TUFBQWdCLFFBQUEsR0FBRSxvQkFBb0IsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFVLENBQXFCLENBQUMsRUFBQywwSEFBMEg7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNPLEVBQUUsSUFBRSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFWLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDc0IsRUFBRSxFQUFDLE9BQU87TUFBQyxhQUFVLDJCQUEyQjtNQUFBRCxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMscUJBQXFCLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQVksQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDcUIsRUFBRSxFQUFDLFNBQVM7TUFBQyxhQUFVLG9FQUFvRTtNQUFBRCxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVMsQ0FBRSxDQUFDLEVBQUMsaUVBQWlFLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQVksQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLDhDQUE4QyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFXLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQWdCLENBQW1CLENBQUMsRUFBQywyRUFBMkUsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFPLENBQXFCLENBQUMsRUFBQyxnQkFBZ0IsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBa0IsQ0FBbUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNtQixFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFtQyxDQUFxQixDQUFDLEVBQUMsMkNBQTJDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQVksQ0FBaUIsQ0FBQyxFQUFDLGlDQUFpQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXVELENBQXFCLENBQUMsRUFBQyxVQUFVLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBaUksQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLGlCQUFpQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQUssQ0FBcUIsQ0FBQyxFQUFDLDhEQUE4RCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWdFLENBQXFCLENBQUM7TUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEdBQUUsdUJBQXVCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtZQUFBdUIsUUFBQSxFQUFFO1VBQU8sQ0FBaUIsQ0FBQyxFQUFDLE9BQU87UUFBQSxDQUFxQixDQUFDLEVBQUMseUNBQXlDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBa0MsQ0FBcUIsQ0FBQztNQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQTJCLENBQXFCLENBQUMsRUFBQywyRkFBMkYsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUE0QixDQUFxQixDQUFDLEVBQUMsa0RBQWtELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBd0MsQ0FBcUIsQ0FBQyxFQUFDLDZEQUE2RCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUFLLENBQWlCLENBQUMsRUFBQyxhQUFhO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxHQUFFLHlDQUF5QyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFXLENBQWlCLENBQUMsRUFBQyx3RUFBd0U7TUFBQSxDQUFxQixDQUFDLEVBQUMsdUlBQXVJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBMkIsQ0FBcUIsQ0FBQyxFQUFDLDRKQUE0SixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUFjLENBQWlCLENBQUMsRUFBQywyRkFBMkYsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFzQixDQUFxQixDQUFDLEVBQUMscUdBQXFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBZ0MsQ0FBcUIsQ0FBQyxFQUFDLHVHQUF1RztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDcUIsRUFBRSxFQUFDLFNBQVM7TUFBQyxhQUFVLG9IQUFvSDtNQUFBRCxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVMsQ0FBRSxDQUFDLEVBQUMsOEZBQThGLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQWdDLENBQWlCLENBQUM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNVLENBQUM7TUFBQWdCLFFBQUEsR0FBRSxzQkFBc0IsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1FBQUF1QixRQUFBLEVBQUU7TUFBTyxDQUFpQixDQUFDLEVBQUMsaURBQWlEO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDYSxLQUFLO01BQUFhLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2lCLEtBQUs7UUFBQVMsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQU8sQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQ2EsS0FBSyxFQUFFO2NBQzVsSkMsU0FBUyxFQUFFO1lBQ2IsQ0FBRTtZQUFBSixRQUFBLEVBQUU7VUFBa0IsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQ2EsS0FBSyxFQUFFO2NBQzdEQyxTQUFTLEVBQUU7WUFDYixDQUFFO1lBQUFKLFFBQUEsRUFBRTtVQUFjLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNnQixFQUFFO1lBQUNhLEtBQUssRUFBRTtjQUN6REMsU0FBUyxFQUFFO1lBQ2IsQ0FBRTtZQUFBSixRQUFBLEVBQUU7VUFBa0IsQ0FBaUIsQ0FBQztRQUFBLENBQWdCO01BQUMsQ0FBbUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2MsS0FBSztRQUFBWSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBZ0IsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFDYyxLQUFLLEVBQUU7Y0FDeExDLFNBQVMsRUFBRTtZQUNiLENBQUU7WUFBQUosUUFBQSxFQUFFO1VBQUcsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFDYyxLQUFLLEVBQUU7Y0FDOUNDLFNBQVMsRUFBRTtZQUNiLENBQUU7WUFBQUosUUFBQSxFQUFFO1VBQUcsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFDYyxLQUFLLEVBQUU7Y0FDOUNDLFNBQVMsRUFBRTtZQUNiLENBQUU7WUFBQUosUUFBQSxFQUFFO1VBQUcsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBZ0IsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFDYyxLQUFLLEVBQUU7Y0FDbElDLFNBQVMsRUFBRTtZQUNiLENBQUU7WUFBQUosUUFBQSxFQUFFO1VBQUcsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFDYyxLQUFLLEVBQUU7Y0FDOUNDLFNBQVMsRUFBRTtZQUNiLENBQUU7WUFBQUosUUFBQSxFQUFFO1VBQUcsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFDYyxLQUFLLEVBQUU7Y0FDOUNDLFNBQVMsRUFBRTtZQUNiLENBQUU7WUFBQUosUUFBQSxFQUFFO1VBQUcsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBYSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUNjLEtBQUssRUFBRTtjQUMvSEMsU0FBUyxFQUFFO1lBQ2IsQ0FBRTtZQUFBSixRQUFBLEVBQUU7VUFBRyxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUNjLEtBQUssRUFBRTtjQUM5Q0MsU0FBUyxFQUFFO1lBQ2IsQ0FBRTtZQUFBSixRQUFBLEVBQUU7VUFBRyxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUNjLEtBQUssRUFBRTtjQUM5Q0MsU0FBUyxFQUFFO1lBQ2IsQ0FBRTtZQUFBSixRQUFBLEVBQUU7VUFBMkIsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBVyxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUNjLEtBQUssRUFBRTtjQUNySkMsU0FBUyxFQUFFO1lBQ2IsQ0FBRTtZQUFBSixRQUFBLEVBQUU7VUFBRyxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUNjLEtBQUssRUFBRTtjQUM5Q0MsU0FBUyxFQUFFO1lBQ2IsQ0FBRTtZQUFBSixRQUFBLEVBQUU7VUFBRyxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUNjLEtBQUssRUFBRTtjQUM5Q0MsU0FBUyxFQUFFO1lBQ2IsQ0FBRTtZQUFBSixRQUFBLEVBQUU7VUFBa0IsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUM7TUFBQSxDQUFtQixDQUFDO0lBQUEsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQW9FLENBQXFCLENBQUMsRUFBQyw0Q0FBNEMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUF3QixDQUFxQixDQUFDLEVBQUMsZ0JBQWdCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBc0IsQ0FBcUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBb0IsQ0FBbUIsQ0FBQyxFQUFDLHlEQUF5RCxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsR0FBRSwyQ0FBMkMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFLLENBQXFCLENBQUMsRUFBQyxzREFBc0Q7TUFBQSxDQUFpQixDQUFDLEVBQUMsWUFBWSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVEsQ0FBcUIsQ0FBQyxFQUFDLGdHQUFnRyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFNLENBQW1CLENBQUMsRUFBQyxvQkFBb0IsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBNEIsQ0FBbUIsQ0FBQyxFQUFDLHdCQUF3QixlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxHQUFFLHNDQUFzQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFXLENBQWlCLENBQUM7TUFBQSxDQUFvQixDQUFDLEVBQUMsdUZBQXVGLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBaUQsQ0FBcUIsQ0FBQyxFQUFDLHdCQUF3QixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUFLLENBQWlCLENBQUMsRUFBQywrQ0FBK0M7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNVLENBQUM7TUFBQWdCLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUE0QyxDQUFxQjtJQUFDLENBQWUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUyxFQUFFO01BQUFpQixRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBK0QsQ0FBcUIsQ0FBQyxFQUFDLDhEQUE4RCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFpQyxDQUFpQixDQUFDLEVBQUMsK0JBQStCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQWtCLENBQW1CLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQVEsQ0FBbUIsQ0FBQyxFQUFDLDBFQUEwRSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQVMsQ0FBcUIsQ0FBQyxFQUFDLGlIQUFpSCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWlDLENBQXFCLENBQUMsRUFBQyxjQUFjO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTZELENBQXFCLENBQUMsRUFBQyw0SUFBNEksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFlLENBQXFCLENBQUMsRUFBQyx5Q0FBeUMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBTSxDQUFpQixDQUFDLEVBQUMsOEdBQThHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWdDLENBQXFCLENBQUMsRUFBQyxtSkFBbUo7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFlLENBQXFCLENBQUMsRUFBQyxrQ0FBa0MsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFnQixDQUFxQixDQUFDLEVBQUMsMENBQTBDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQXFDLENBQWlCLENBQUMsRUFBQyw0TEFBNEwsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFJLENBQXFCLENBQUMsRUFBQyxvSUFBb0ksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFZLENBQXFCLENBQUMsRUFBQyx5QkFBeUI7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNDLFVBQVU7TUFBQXlCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztRQUFBZ0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsR0FBRSxtQkFBbUIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1lBQUF1QixRQUFBLEVBQUU7VUFBUyxDQUFpQixDQUFDLEVBQUMsZ0JBQWdCO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLDZTQUE2UztNQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBeUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDTSxFQUFFO01BQUNxQixFQUFFLEVBQUMsU0FBUztNQUFDLGFBQVUsNkRBQTZEO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBUyxDQUFFLENBQUMsRUFBQyx1REFBdUQsZUFBQyxJQUFBOUIsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1FBQUF1QixRQUFBLEVBQUU7TUFBWSxDQUFpQixDQUFDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLEdBQUUsaUNBQWlDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQWdCLENBQW1CLENBQUMsRUFBQyxTQUFTLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBcUIsQ0FBcUIsQ0FBQyxFQUFDLDZDQUE2QyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQW1CLENBQXFCLENBQUMsRUFBQyxxQkFBcUIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUF3QyxDQUFxQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQUksQ0FBcUIsQ0FBQyxFQUFDLDJCQUEyQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQTZCLENBQXFCLENBQUMsRUFBQyw2RUFBNkUsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFzRCxDQUFxQixDQUFDLEVBQUMsb09BQW9PO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDTSxFQUFFO01BQUNxQixFQUFFLEVBQUMsU0FBUztNQUFDLGFBQVUsNkZBQTZGO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBUyxDQUFFLENBQUMsRUFBQyxrREFBa0QsZUFBQyxJQUFBOUIsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDRyxFQUFFO1FBQUF1QixRQUFBLEdBQUUsNkJBQTZCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQWtCLENBQW1CLENBQUMsRUFBQyxZQUFZO01BQUEsQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLHNDQUFzQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQWlELENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQWtCLENBQW1CLENBQUMsRUFBQyxTQUFTLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBeUIsQ0FBcUIsQ0FBQyxFQUFDLGdDQUFnQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQWlELENBQXFCLENBQUMsRUFBQyxjQUFjLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBMkIsQ0FBcUIsQ0FBQyxFQUFDLCtCQUErQixlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxHQUFFLFlBQVksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBaUIsQ0FBbUIsQ0FBQztNQUFBLENBQW9CLENBQUMsRUFBQyxrQkFBa0IsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUF1QixDQUFxQixDQUFDLEVBQUMsNkJBQTZCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQTZCLENBQW1CLENBQUMsRUFBQyx3Q0FBd0M7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNNLEVBQUU7TUFBQ3FCLEVBQUUsRUFBQyxTQUFTO01BQUMsYUFBVSw2REFBNkQ7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFTLENBQUUsQ0FBQyxFQUFDLHlEQUF5RCxlQUFDLElBQUE5QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUFZLENBQWlCLENBQUM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNVLENBQUM7TUFBQWdCLFFBQUEsR0FBRSxjQUFjLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBMEIsQ0FBcUIsQ0FBQyxFQUFDLDJCQUEyQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQWtCLENBQXFCLENBQUMsRUFBQyx1UUFBdVEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBWSxDQUFtQixDQUFDLEVBQUMscUZBQXFGLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBYyxDQUFxQixDQUFDLEVBQUMsMkhBQTJILGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQVksQ0FBbUIsQ0FBQyxFQUFDLFFBQVE7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNPLEVBQUUsSUFBRSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFWLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDc0IsRUFBRSxFQUFDLE9BQU87TUFBQyxhQUFVLGdIQUFnSDtNQUFBRCxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMsK0NBQStDLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxHQUFFLGdCQUFnQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFnQixDQUFtQixDQUFDLEVBQUMsZ0RBQWdEO01BQUEsQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDcUIsRUFBRSxFQUFDLFNBQVM7TUFBQyxhQUFVLHlCQUF5QjtNQUFBRCxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVMsQ0FBRSxDQUFDLEVBQUMsbUJBQW1CLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQVksQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLGdCQUFnQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVksQ0FBcUIsQ0FBQyxFQUFDLCtFQUErRSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFrQixDQUFtQixDQUFDLEVBQUMseUJBQXlCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBaUIsQ0FBcUIsQ0FBQyxFQUFDLHNEQUFzRCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFnQixDQUFtQixDQUFDLEVBQUMscUZBQXFGLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQUssQ0FBbUIsQ0FBQyxFQUFDLFFBQVEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBMkIsQ0FBbUIsQ0FBQyxFQUFDLHNDQUFzQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFrQixDQUFtQixDQUFDLEVBQUMsd0JBQXdCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBVSxDQUFxQixDQUFDLEVBQUMsMkNBQTJDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQXNCLENBQW1CLENBQUMsRUFBQyxPQUFPO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDTSxFQUFFO01BQUNxQixFQUFFLEVBQUMsU0FBUztNQUFDLGFBQVUsMEJBQTBCO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBUyxDQUFFLENBQUMsRUFBQyxvQkFBb0IsZUFBQyxJQUFBOUIsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1FBQUF1QixRQUFBLEVBQUU7TUFBWSxDQUFpQixDQUFDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDQyxVQUFVO01BQUF5QixRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNVLENBQUM7UUFBQWdCLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsR0FBRSxvRUFBb0UsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1lBQUF1QixRQUFBLEVBQUU7VUFBTSxDQUFpQixDQUFDLEVBQUMsc0pBQXNKO1FBQUEsQ0FBcUI7TUFBQyxDQUFlLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBeUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDbUIsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsR0FBRSw2QkFBNkIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUF3RCxDQUFxQixDQUFDLEVBQUMsR0FBRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsR0FBRSxtREFBbUQsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1lBQUF3QixRQUFBLEVBQUU7VUFBUSxDQUFtQixDQUFDLEVBQUMsdUJBQXVCO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLGlCQUFpQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUEyQixDQUFtQixDQUFDLEVBQUMsbUNBQW1DLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQVEsQ0FBbUIsQ0FBQyxFQUFDLHdEQUF3RCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXVCLENBQXFCLENBQUMsRUFBQyxVQUFVLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEdBQUUsYUFBYSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7WUFBQXdCLFFBQUEsRUFBRTtVQUFRLENBQW1CLENBQUM7UUFBQSxDQUFvQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUEyQixDQUFtQixDQUFDLEVBQUMsMkNBQTJDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQUssQ0FBaUIsQ0FBQyxFQUFDLDJHQUEyRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUErQixDQUFxQixDQUFDLEVBQUMscUNBQXFDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBb0IsQ0FBcUIsQ0FBQyxFQUFDLEdBQUc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBOEIsQ0FBcUIsQ0FBQyxFQUFDLHFCQUFxQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFRLENBQWlCLENBQUMsRUFBQyw2REFBNkQ7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDcUIsRUFBRSxFQUFDLFNBQVM7TUFBQyxhQUFVLDBDQUEwQztNQUFBRCxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVMsQ0FBRSxDQUFDLEVBQUMsc0NBQXNDLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQVksQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFrQixDQUFxQixDQUFDLEVBQUMsa0RBQWtELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQWUsQ0FBbUIsQ0FBQyxFQUFDLGtDQUFrQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUE2QixDQUFtQixDQUFDLEVBQUMsUUFBUSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxHQUFFLGtDQUFrQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFRLENBQW1CLENBQUMsRUFBQyxnREFBZ0Q7TUFBQSxDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFNLENBQW1CLENBQUMsRUFBQyw2Q0FBNkMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBZSxDQUFtQixDQUFDLEVBQUMsUUFBUSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFhLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEdBQUUscUNBQXFDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQVksQ0FBbUIsQ0FBQztNQUFBLENBQW9CLENBQUMsRUFBQyw4RUFBOEU7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNNLEVBQUU7TUFBQ3FCLEVBQUUsRUFBQyxTQUFTO01BQUMsYUFBVSxnREFBZ0Q7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFTLENBQUUsQ0FBQyxFQUFDLDhCQUE4QixlQUFDLElBQUE5QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUFTLENBQWlCLENBQUMsRUFBQyxTQUFTLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQVksQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLHlDQUF5QyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQWEsQ0FBcUIsQ0FBQyxFQUFDLHdJQUF3SSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQW1DLENBQXFCLENBQUMsRUFBQyxnQkFBZ0IsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFrQixDQUFxQixDQUFDLEVBQUMsMkRBQTJELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQU8sQ0FBaUIsQ0FBQyxFQUFDLHVCQUF1QixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQXlELENBQXFCLENBQUMsRUFBQyxrREFBa0QsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFLLENBQXFCLENBQUMsRUFBQyxtQkFBbUI7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNNLEVBQUU7TUFBQ3FCLEVBQUUsRUFBQyxTQUFTO01BQUMsYUFBVSx3R0FBd0c7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFTLENBQUUsQ0FBQyxFQUFDLGdDQUFnQyxlQUFDLElBQUE5QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUFtRixDQUFpQixDQUFDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLEdBQUUsdURBQXVELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBTSxDQUFxQixDQUFDLEVBQUMsY0FBYyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQXdFLENBQXFCLENBQUMsRUFBQyxZQUFZLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBWSxDQUFxQixDQUFDLEVBQUMsMkxBQTJMLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBNkUsQ0FBcUIsQ0FBQyxFQUFDLFFBQVEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1FBQUF1QixRQUFBLEVBQUU7TUFBYSxDQUFpQixDQUFDLEVBQUMsNEJBQTRCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQVksQ0FBaUIsQ0FBQyxFQUFDLGVBQWU7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNPLEVBQUUsSUFBRSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFWLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDc0IsRUFBRSxFQUFDLE9BQU87TUFBQyxhQUFVLGdFQUFnRTtNQUFBRCxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMsNERBQTRELGVBQUMsSUFBQTlCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQVksQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLHNCQUFzQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQW9CLENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQVksQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBSyxDQUFtQixDQUFDLEVBQUMsc0RBQXNELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQWlCLENBQW1CLENBQUMsRUFBQyxxRUFBcUU7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNtQixFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFrQixDQUFxQixDQUFDLEVBQUMsdUdBQXVHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQW1DLENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQU0sQ0FBbUIsQ0FBQyxFQUFDLGdEQUFnRCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTJCLENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQXNCLENBQW1CLENBQUMsRUFBQyxJQUFJO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWEsQ0FBcUIsQ0FBQyxFQUFDLGtDQUFrQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTRCLENBQXFCLENBQUMsRUFBQywwQkFBMEI7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUE0RSxDQUFxQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQTZDLENBQXFCLENBQUMsRUFBQywyQkFBMkIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUE0RCxDQUFxQixDQUFDLEVBQUMsNERBQTRELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBYSxDQUFxQixDQUFDLEVBQUMsc0hBQXNILGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBcUMsQ0FBcUIsQ0FBQyxFQUFDLHdGQUF3RjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ21CLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTJCLENBQXFCLENBQUMsRUFBQyxrRkFBa0YsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUF5RSxDQUFxQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQStGLENBQXFCLENBQUMsRUFBQywyREFBMkQ7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsR0FBRSxzQkFBc0IsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFVLENBQXFCLENBQUMsRUFBQyxnSEFBZ0gsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBUSxDQUFpQixDQUFDLEVBQUMsbUNBQW1DO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNVLENBQUM7TUFBQWdCLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFxRSxDQUFxQjtJQUFDLENBQWUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDbUIsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBNEIsQ0FBcUIsQ0FBQyxFQUFDLCtDQUErQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQVUsQ0FBcUIsQ0FBQyxFQUFDLDRGQUE0RixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFRLENBQW1CLENBQUMsRUFBQyxrQkFBa0I7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBNkQsQ0FBcUIsQ0FBQyxFQUFDLHVCQUF1QixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQU0sQ0FBcUIsQ0FBQyxFQUFDLG1DQUFtQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFRLENBQW1CLENBQUMsRUFBQyxJQUFJO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxHQUFFLCtCQUErQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7WUFBQXVCLFFBQUEsRUFBRTtVQUFRLENBQWlCLENBQUMsRUFBQyxvQkFBb0I7UUFBQSxDQUFxQixDQUFDLEVBQUMseU9BQXlPO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNVLENBQUM7TUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQVEsQ0FBbUIsQ0FBQyxFQUFDLGNBQWMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBb0IsQ0FBbUIsQ0FBQyxFQUFDLDRHQUE0RztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ08sRUFBRSxJQUFFLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQVYsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDSyxFQUFFO01BQUNzQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUsNkRBQTZEO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQyw4QkFBOEIsZUFBQyxJQUFBOUIsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1FBQUF1QixRQUFBLEVBQUU7TUFBdUMsQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLG1CQUFtQixlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxHQUFFLHlEQUF5RCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFPLENBQWlCLENBQUM7TUFBQSxDQUFvQixDQUFDLEVBQUMsOERBQThEO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDTSxFQUFFO01BQUNxQixFQUFFLEVBQUMsU0FBUztNQUFDLGFBQVUsb0VBQW9FO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBUyxDQUFFLENBQUMsRUFBQyw4QkFBOEIsZUFBQyxJQUFBOUIsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1FBQUF1QixRQUFBLEVBQUU7TUFBNkMsQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLGNBQWMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsR0FBRSxxQ0FBcUMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBTyxDQUFpQixDQUFDLEVBQUMsdUJBQXVCO01BQUEsQ0FBcUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBd0IsQ0FBbUIsQ0FBQyxFQUFDLG1CQUFtQixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFnQixDQUFtQixDQUFDLEVBQUMsUUFBUSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFrQixDQUFtQixDQUFDLEVBQUMsaURBQWlELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBb0IsQ0FBcUIsQ0FBQyxFQUFDLFVBQVUsZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsR0FBRSxVQUFVLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQUssQ0FBbUIsQ0FBQyxFQUFDLDRCQUE0QjtNQUFBLENBQXFCLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBeUQsQ0FBcUIsQ0FBQyxFQUFDLGtFQUFrRSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7UUFBQXdCLFFBQUEsRUFBRTtNQUFRLENBQW1CLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDVyxHQUFHO01BQUFlLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUM2QixTQUFTLEVBQUMsZ0JBQWdCO1FBQUFMLFFBQUEsRUFBRTtNQUF5akIsQ0FBbUI7SUFBQyxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNtQixFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUEwQixDQUFxQixDQUFDLEVBQUMsbURBQW1ELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQVEsQ0FBbUIsQ0FBQyxFQUFDLG9KQUFvSjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUE4RCxDQUFxQixDQUFDLEVBQUMsb0RBQW9EO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1lBQUF3QixRQUFBLEVBQUU7VUFBYyxDQUFtQixDQUFDLEVBQUMsb0VBQW9FO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLGlMQUFpTDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFtQyxDQUFxQixDQUFDLEVBQUMsU0FBUyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFRLENBQW1CLENBQUMsRUFBQywrREFBK0Q7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDcUIsRUFBRSxFQUFDLFNBQVM7TUFBQyxhQUFVLDBDQUEwQztNQUFBRCxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVMsQ0FBRSxDQUFDLEVBQUMsb0NBQW9DLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQVksQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ21CLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxHQUFFLDhCQUE4QixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7WUFBQXdCLFFBQUEsRUFBRTtVQUFhLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBd0IsUUFBQSxFQUFFO1VBQVcsQ0FBbUIsQ0FBQyxFQUFDLGlFQUFpRTtRQUFBLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQU8sQ0FBbUIsQ0FBQyxFQUFDLDRGQUE0RixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQVMsQ0FBcUIsQ0FBQyxFQUFDLDhDQUE4QyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFLLENBQWlCLENBQUMsRUFBQyxnQ0FBZ0M7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBbUIsQ0FBcUIsQ0FBQyxFQUFDLFVBQVUsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBTyxDQUFpQixDQUFDLEVBQUMsdUVBQXVFLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBMEMsQ0FBcUIsQ0FBQztNQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUF5QyxDQUFxQixDQUFDLEVBQUMsb0dBQW9HO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTZGLENBQXFCLENBQUMsRUFBQyxrS0FBa0ssZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFrQixDQUFxQixDQUFDLEVBQUMsbUhBQW1ILGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBSyxDQUFxQixDQUFDLEVBQUMsdUNBQXVDO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWUsQ0FBcUIsQ0FBQyxFQUFDLDBEQUEwRCxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFxQyxDQUFpQixDQUFDLEVBQUMscUVBQXFFO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNNLEVBQUU7TUFBQ3FCLEVBQUUsRUFBQyxTQUFTO01BQUMsYUFBVSxxREFBcUQ7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFTLENBQUUsQ0FBQyxFQUFDLGlEQUFpRCxlQUFDLElBQUE5QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUFZLENBQWlCLENBQUM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNVLENBQUM7TUFBQWdCLFFBQUEsR0FBRSxNQUFNLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBcUIsQ0FBcUIsQ0FBQyxFQUFDLHlHQUF5RyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVEsQ0FBcUIsQ0FBQyxFQUFDLHNFQUFzRSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQTBHLENBQXFCLENBQUMsRUFBQyx3SUFBd0ksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFXLENBQXFCLENBQUMsRUFBQyxvREFBb0QsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBd0IsQ0FBbUIsQ0FBQyxFQUFDLGVBQWUsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFJLENBQXFCLENBQUMsRUFBQywwQkFBMEIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBVyxDQUFtQixDQUFDLEVBQUMsaURBQWlEO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDTSxFQUFFO01BQUNxQixFQUFFLEVBQUMsU0FBUztNQUFDLGFBQVUsb0ZBQW9GO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBUyxDQUFFLENBQUMsRUFBQyxxREFBcUQsZUFBQyxJQUFBOUIsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1FBQUF1QixRQUFBLEVBQUU7TUFBNkMsQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxHQUFFLCtFQUErRSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQStCLENBQXFCLENBQUMsRUFBQyxpQ0FBaUMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBNkIsQ0FBbUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNtQixFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFxQixDQUFxQixDQUFDLEVBQUMsMkJBQTJCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBcUIsQ0FBcUIsQ0FBQyxFQUFDLHVDQUF1QyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXVDLENBQXFCLENBQUMsRUFBQyx3RUFBd0U7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBc0IsQ0FBcUIsQ0FBQyxFQUFDLHdIQUF3SDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFtQyxDQUFxQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQThELENBQXFCLENBQUMsRUFBQywrSkFBK0o7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUFnSCxDQUFpQjtJQUFDLENBQWUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDTyxFQUFFLElBQUUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBVixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNLLEVBQUU7TUFBQ3NCLEVBQUUsRUFBQyxPQUFPO01BQUMsYUFBVSx1Q0FBdUM7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLG1DQUFtQyxlQUFDLElBQUE5QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUFZLENBQWlCLENBQUM7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNhLEtBQUs7TUFBQWEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDaUIsS0FBSztRQUFBUyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBTyxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBZSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBUyxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBTyxDQUFpQixDQUFDO1FBQUEsQ0FBZ0I7TUFBQyxDQUFtQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDYyxLQUFLO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFhLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBUyxDQUFtQixDQUFDLEVBQUMsb0JBQW9CO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBZ0MsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBZ0UsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBZ0IsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBTSxDQUFxQjtVQUFDLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQU0sQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBaUQsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBZ0IsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFhLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQVcsQ0FBbUIsQ0FBQyxFQUFDLDJFQUEyRSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFhLENBQW1CLENBQUMsRUFBQyxHQUFHO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEdBQUUsdUJBQXVCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBa0MsQ0FBcUIsQ0FBQztVQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQXdDLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQVcsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFVLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQVMsQ0FBbUIsQ0FBQztVQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxHQUFFLGFBQWEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBTSxDQUFtQixDQUFDLEVBQUMsa0JBQWtCO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBc0MsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUM7TUFBQSxDQUFtQixDQUFDO0lBQUEsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDTyxFQUFFLElBQUUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBVixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNLLEVBQUU7TUFBQ3NCLEVBQUUsRUFBQyxPQUFPO01BQUMsYUFBVSxpREFBaUQ7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLGdDQUFnQyxlQUFDLElBQUE5QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7UUFBQXVCLFFBQUEsRUFBRTtNQUEyQixDQUFpQixDQUFDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQWdCLENBQXFCLENBQUMsRUFBQyxxSEFBcUgsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBSyxDQUFtQixDQUFDLEVBQUMsMEdBQTBHO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBMEYsQ0FBcUI7SUFBQyxDQUFlLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1MsRUFBRTtNQUFBaUIsUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxHQUFFLDJDQUEyQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7WUFBQXdCLFFBQUEsRUFBRTtVQUFRLENBQW1CLENBQUMsRUFBQyxhQUFhO1FBQUEsQ0FBcUIsQ0FBQyxFQUFDLFVBQVUsZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7WUFBQXdCLFFBQUEsRUFBRTtVQUFnQixDQUFtQixDQUFDLEVBQUMsUUFBUSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7WUFBQXdCLFFBQUEsRUFBRTtVQUE2QixDQUFtQixDQUFDLEVBQUMsWUFBWTtRQUFBLENBQWlCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBb0MsQ0FBcUIsQ0FBQztNQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUF1QyxDQUFxQixDQUFDLEVBQUMsb0JBQW9CLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBWSxDQUFxQixDQUFDLEVBQUMsbUdBQW1HLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBbUMsQ0FBcUIsQ0FBQztNQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFzQyxDQUFxQixDQUFDLEVBQUMsWUFBWSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBd0IsUUFBQSxFQUFFO1VBQWtCLENBQW1CLENBQUMsRUFBQyxpQ0FBaUM7UUFBQSxDQUFpQixDQUFDO01BQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQTRCLENBQXFCLENBQUMsRUFBQywwQkFBMEIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBSyxDQUFtQixDQUFDLEVBQUMscUNBQXFDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLFlBQVksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBb0IsQ0FBbUIsQ0FBQyxFQUFDLHVCQUF1QixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFrQixDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUE0QixDQUFpQixDQUFDO01BQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXdDLENBQXFCLENBQUMsRUFBQyx5Q0FBeUMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7WUFBQXdCLFFBQUEsRUFBRTtVQUF3QixDQUFtQixDQUFDLEVBQUMsZUFBZSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07WUFBQWMsUUFBQSxFQUFFO1VBQXFCLENBQXFCLENBQUM7UUFBQSxDQUFnQixDQUFDO01BQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQW1CLENBQXFCLENBQUMsRUFBQywrR0FBK0csZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFzQixDQUFxQixDQUFDLEVBQUMsOEJBQThCO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNVLENBQUM7TUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBd0IsQ0FBcUIsQ0FBQyxFQUFDLGlHQUFpRztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ08sRUFBRSxJQUFFLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQVYsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDSyxFQUFFO01BQUNzQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUsNERBQTREO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQyx3Q0FBd0MsZUFBQyxJQUFBOUIsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1FBQUF1QixRQUFBLEVBQUU7TUFBK0IsQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ21CLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXVDLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLHVCQUF1QjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsR0FBRSwyQ0FBMkMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1lBQUF1QixRQUFBLEVBQUU7VUFBZ0IsQ0FBaUIsQ0FBQyxFQUFDLG1KQUFtSjtRQUFBLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLG1GQUFtRixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFvQixDQUFtQixDQUFDLEVBQUMsY0FBYyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFjLENBQW1CLENBQUMsRUFBQyw0Q0FBNEM7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBeUYsQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBVyxDQUFpQixDQUFDLEVBQUMsc0NBQXNDO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQThHLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLHVKQUF1SjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUE4QyxDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFXLENBQWlCLENBQUMsRUFBQyxtQ0FBbUM7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEdBQUUsZ0RBQWdELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBd0IsUUFBQSxFQUFFO1VBQVEsQ0FBbUIsQ0FBQyxFQUFDLGNBQWM7UUFBQSxDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFXLENBQWlCLENBQUMsRUFBQywyREFBMkQsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsMkNBQTJDO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQThELENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLHdCQUF3QjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsR0FBRSxXQUFXLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBd0IsUUFBQSxFQUFFO1VBQUssQ0FBbUIsQ0FBQyxFQUFDLGlHQUFpRztRQUFBLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLDJDQUEyQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7VUFBQXdCLFFBQUEsRUFBRTtRQUFRLENBQW1CLENBQUMsRUFBQyxvREFBb0Q7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEdBQUUsd0VBQXdFLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtZQUFBd0IsUUFBQSxFQUFFO1VBQWMsQ0FBbUIsQ0FBQyxFQUFDLHlDQUF5QztRQUFBLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQVcsQ0FBaUIsQ0FBQyxFQUFDLFVBQVUsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLHdFQUF3RTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUEwSyxDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFXLENBQWlCLENBQUMsRUFBQyxnSkFBZ0o7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBa0osQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBVyxDQUFpQixDQUFDLEVBQUMsb0VBQW9FO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNPLEVBQUUsSUFBRSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFWLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDc0IsRUFBRSxFQUFDLFFBQVE7TUFBQyxhQUFVLGdDQUFnQztNQUFBRCxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVEsQ0FBRSxDQUFDLEVBQUMsMEJBQTBCLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQVksQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDcUIsRUFBRSxFQUFDLFNBQVM7TUFBQyxhQUFVLHVFQUF1RTtNQUFBRCxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVMsQ0FBRSxDQUFDLEVBQUMsMkVBQTJFO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDTSxFQUFFO01BQUNxQixFQUFFLEVBQUMsU0FBUztNQUFDLGFBQVUseUNBQXlDO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBUyxDQUFFLENBQUMsRUFBQyxnREFBZ0Q7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNVLENBQUM7TUFBQWdCLFFBQUEsR0FBRSx5Q0FBeUMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBYyxDQUFtQixDQUFDLEVBQUMsMkRBQTJELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtRQUFBd0IsUUFBQSxFQUFFO01BQWdCLENBQW1CLENBQUMsRUFBQyxzRUFBc0UsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1FBQUF3QixRQUFBLEVBQUU7TUFBSyxDQUFtQixDQUFDLEVBQUMsa0ZBQWtGO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDTSxFQUFFO01BQUNxQixFQUFFLEVBQUMsU0FBUztNQUFDLGFBQVUsNERBQTREO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBUyxDQUFFLENBQUMsRUFBQyxtRUFBbUU7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNVLENBQUM7TUFBQWdCLFFBQUEsRUFBRTtJQUEwRixDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNtQixFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFpRCxDQUFxQixDQUFDLEVBQUMsbURBQW1ELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtVQUFBd0IsUUFBQSxFQUFFO1FBQW9CLENBQW1CLENBQUMsRUFBQyw0REFBNEQsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBVyxDQUFpQixDQUFDLEVBQUMsd0VBQXdFLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBZ0IsQ0FBcUIsQ0FBQyxFQUFDLHFNQUFxTTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUF1RSxDQUFxQixDQUFDLEVBQUMsUUFBUSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQW1CLENBQXFCLENBQUMsRUFBQyxvSEFBb0g7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBdUQsQ0FBcUIsQ0FBQyxFQUFDLG1EQUFtRDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUF5QyxDQUFxQixDQUFDLEVBQUMsZ0JBQWdCO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXNELENBQXFCLENBQUMsRUFBQywrQ0FBK0M7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBbUUsQ0FBcUIsQ0FBQyxFQUFDLG9FQUFvRTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUEyQyxDQUFxQixDQUFDLEVBQUMsdUZBQXVGO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXlELENBQXFCLENBQUMsRUFBQywrQ0FBK0M7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBOEMsQ0FBcUIsQ0FBQyxFQUFDLDJCQUEyQjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFpRixDQUFxQixDQUFDLEVBQUMsb0JBQW9CLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBb0UsQ0FBcUIsQ0FBQztNQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDVSxDQUFDO01BQUFnQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQXNCLENBQXFCLENBQUMsRUFBQyw2UUFBNlE7SUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNPLEVBQUUsSUFBRSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFWLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDc0IsRUFBRSxFQUFDLFFBQVE7TUFBQyxhQUFVLGdDQUFnQztNQUFBRCxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVEsQ0FBRSxDQUFDLEVBQUMsMEJBQTBCLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQVksQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2EsS0FBSztNQUFBYSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNpQixLQUFLO1FBQUFTLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNnQixFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFJLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNnQixFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFRLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNnQixFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFRLENBQWlCLENBQUM7UUFBQSxDQUFnQjtNQUFDLENBQW1CLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNjLEtBQUs7UUFBQVksUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQU0sQ0FBcUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUE4RSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsR0FBRSxrQ0FBa0MsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFTLENBQXFCLENBQUMsRUFBQyxzQkFBc0IsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFTLENBQXFCLENBQUMsRUFBQyxxQ0FBcUM7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFNLENBQXFCO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBK0MsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEdBQUUsc0RBQXNELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBTyxDQUFxQixDQUFDLEVBQUMsU0FBUztVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQU0sQ0FBcUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFzQyxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQUssQ0FBbUIsQ0FBQyxFQUFDLDJEQUEyRDtVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQU0sQ0FBcUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFvQyxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsR0FBRSxpQ0FBaUMsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBTSxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFNLENBQW1CLENBQUMsRUFBQywwQkFBMEIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBUSxDQUFtQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQTZCLENBQXFCLENBQUM7VUFBQSxDQUFnQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFNLENBQXFCO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBc0MsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEdBQUUsdUNBQXVDLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBUyxDQUFxQixDQUFDO1VBQUEsQ0FBZ0IsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBTSxDQUFxQjtVQUFDLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQWlDLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxHQUFFLDJDQUEyQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQVksQ0FBcUIsQ0FBQyxFQUFDLDBCQUEwQjtVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQU0sQ0FBcUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFxQyxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsR0FBRSxzQ0FBc0MsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFTLENBQXFCLENBQUMsRUFBQyxHQUFHO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBTSxDQUFxQjtVQUFDLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQTBDLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQXFELENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQU0sQ0FBcUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFrQyxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUErQyxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFPLENBQXFCO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBZ0YsQ0FBcUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBc0csQ0FBcUIsQ0FBQyxFQUFDLHdCQUF3QixlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFzQixDQUFtQixDQUFDLEVBQUMsU0FBUztVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQU8sQ0FBcUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUE2RSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsR0FBRSxxREFBcUQsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFTLENBQXFCLENBQUM7VUFBQSxDQUFnQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQztNQUFBLENBQW1CLENBQUM7SUFBQSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNPLEVBQUUsSUFBRSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFWLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ0ssRUFBRTtNQUFDc0IsRUFBRSxFQUFDLFFBQVE7TUFBQyxhQUFVLDZDQUE2QztNQUFBRCxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQVEsQ0FBRSxDQUFDLEVBQUMseUNBQXlDLGVBQUMsSUFBQTlCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtRQUFBdUIsUUFBQSxFQUFFO01BQVksQ0FBaUIsQ0FBQztJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFtQixDQUFxQixDQUFDLEVBQUMsb0ZBQW9GLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBaUIsQ0FBcUIsQ0FBQyxFQUFDLHNSQUFzUjtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZ0IsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQW1DLENBQXFCO0lBQUMsQ0FBZSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNtQixFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFJLENBQXFCLENBQUMsRUFBQyw2QkFBNkIsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO1VBQUF3QixRQUFBLEVBQUU7UUFBb0IsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBSSxDQUFxQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNHLEVBQUU7VUFBQXVCLFFBQUEsRUFBRTtRQUFRLENBQWlCLENBQUMsRUFBQyxrSEFBa0gsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1VBQUF1QixRQUFBLEVBQUU7UUFBWSxDQUFpQixDQUFDLEVBQUMsNEZBQTRGO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBOEcsQ0FBcUI7TUFBQyxDQUFnQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNRLEVBQUU7UUFBQWtCLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBSSxDQUFxQixDQUFDLEVBQUMsbUZBQW1GO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDUSxFQUFFO1FBQUFrQixRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQUksQ0FBcUIsQ0FBQyxFQUFDLG1EQUFtRDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFJLENBQXFCLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQVEsQ0FBaUIsQ0FBQyxFQUFDLDJHQUEyRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ1EsRUFBRTtRQUFBa0IsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDWSxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFJLENBQXFCLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0csRUFBRTtVQUFBdUIsUUFBQSxFQUFFO1FBQWtCLENBQWlCLENBQUMsRUFBQyx5RUFBeUU7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ08sRUFBRSxJQUFFLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQVYsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDSyxFQUFFO01BQUNzQixFQUFFLEVBQUMsUUFBUTtNQUFDLGFBQVUsbURBQW1EO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBUSxDQUFFLENBQUMsRUFBQywrQ0FBK0MsZUFBQyxJQUFBOUIsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRyxFQUFFO1FBQUF1QixRQUFBLEVBQUU7TUFBWSxDQUFpQixDQUFDO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDTSxFQUFFO01BQUNxQixFQUFFLEVBQUMsZ0NBQWdDO01BQUFELFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBZ0MsQ0FBRSxDQUFDLEVBQUMsa0NBQWtDO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBOUIsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDYSxLQUFLO01BQUFhLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2lCLEtBQUs7UUFBQVMsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQVksQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2dCLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQTZCLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNnQixFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFxQixDQUFpQixDQUFDO1FBQUEsQ0FBZ0I7TUFBQyxDQUFtQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDYyxLQUFLO1FBQUFZLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsR0FBRSwyREFBMkQsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBbUIsQ0FBbUIsQ0FBQztVQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUF3RSxDQUFtQjtVQUFDLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFlLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEdBQUUsb0JBQW9CLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQW1CLENBQW1CLENBQUMsRUFBQyxPQUFPLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQWEsQ0FBbUIsQ0FBQztVQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUErQyxDQUFtQjtVQUFDLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFZLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEdBQUUscUVBQXFFLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQUssQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7VUFBQSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBZ0IsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBWSxDQUFtQjtVQUFDLENBQWdCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxHQUFFLDJDQUEyQyxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUFhLENBQW1CLENBQUMsRUFBQyx5QkFBeUI7VUFBQSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBOEQsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBYSxDQUFtQjtVQUFDLENBQWdCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQXdFLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUErQixDQUFtQjtVQUFDLENBQWdCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNFLElBQUk7Y0FBQXdCLFFBQUEsRUFBRTtZQUEwQixDQUFtQjtVQUFDLENBQWdCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBVyxDQUFtQixDQUFDLEVBQUMsMkRBQTJELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQW9CLENBQW1CLENBQUMsRUFBQyxHQUFHO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQStCLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQVcsQ0FBbUI7VUFBQyxDQUFnQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsRUFBRTtVQUFrRyxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBZ0MsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZSxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBd0IsQ0FBbUI7VUFBQyxDQUFnQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQztNQUFBLENBQW1CLENBQUM7SUFBQSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNNLEVBQUU7TUFBQ3FCLEVBQUUsRUFBQyw4REFBOEQ7TUFBQUQsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUE4RCxDQUFFLENBQUMsRUFBQyxnRUFBZ0U7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE5QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNhLEtBQUs7TUFBQWEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDaUIsS0FBSztRQUFBUyxRQUFBLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2tCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBZSxDQUFpQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDZ0IsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBdUIsQ0FBaUIsQ0FBQztRQUFBLENBQWdCO01BQUMsQ0FBbUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2MsS0FBSztRQUFBWSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNrQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEVBQUU7VUFBcUgsQ0FBaUIsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEdBQUUsMEZBQTBGLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ0UsSUFBSTtjQUFBd0IsUUFBQSxFQUFFO1lBQVEsQ0FBbUIsQ0FBQyxFQUFDLHdCQUF3QjtVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNZLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQXlJLENBQXFCO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTdCLFdBQUEsQ0FBQTJCLElBQUEsRUFBQ3hCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVyxRQUFBLEdBQUUsdUJBQXVCLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzVCLFdBQVcsQ0FBQ1ksTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBdUMsQ0FBcUIsQ0FBQztVQUFBLENBQWdCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQTRDLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUEyQixJQUFBLEVBQUN4QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBN0IsV0FBQSxDQUFBK0IsR0FBQSxFQUFDNUIsV0FBVyxDQUFDRSxJQUFJO2NBQUF3QixRQUFBLEVBQUU7WUFBbUIsQ0FBbUIsQ0FBQyxFQUFDLDREQUE0RDtVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQTZILENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQTJDLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQW9JLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQTRELENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBN0IsV0FBQSxDQUFBMkIsSUFBQSxFQUFDeEIsV0FBVyxDQUFDa0IsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQTZGLENBQWlCLENBQUMsbUJBQUE3QixXQUFBLENBQUErQixHQUFBLEVBQUM1QixXQUFXLENBQUNlLEVBQUU7WUFBQVcsUUFBQSxFQUFFO1VBQXdDLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDO01BQUEsQ0FBbUIsQ0FBQztJQUFBLENBQW1CLENBQUM7RUFBQSxDQUFFLENBQUM7QUFDaDF0RDtBQUNlLFNBQVNNLFVBQVVBLENBQUNqQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUU7RUFDN0MsTUFBTTtJQUFDa0MsT0FBTyxFQUFFQztFQUFTLENBQUMsR0FBRztJQUMzQixHQUFHLElBQUFkLDZCQUFrQixFQUFDLENBQUM7SUFDdkIsR0FBR3JCLEtBQUssQ0FBQ3NCO0VBQ1gsQ0FBQztFQUNELE9BQU9hLFNBQVMsZ0JBQUcsSUFBQXJDLFdBQUEsQ0FBQStCLEdBQUEsRUFBQ00sU0FBUztJQUFBLEdBQUtuQyxLQUFLO0lBQUEyQixRQUFBLGVBQUUsSUFBQTdCLFdBQUEsQ0FBQStCLEdBQUEsRUFBQzlCLGlCQUFpQjtNQUFBLEdBQUtDO0lBQUssQ0FBRztFQUFDLENBQVcsQ0FBQyxHQUFHRCxpQkFBaUIsQ0FBQ0MsS0FBSyxDQUFDO0FBQ2xIO0FBQUNvQyxFQUFBLEdBTnVCSCxVQUFVO0FBT2xDLFNBQVNULG9CQUFvQkEsQ0FBQ0ksRUFBRSxFQUFFUyxTQUFTLEVBQUVDLEtBQUssRUFBRTtFQUNsRCxNQUFNLElBQUlDLEtBQUssQ0FBQyxXQUFXLElBQUlGLFNBQVMsR0FBRyxXQUFXLEdBQUcsUUFBUSxDQUFDLEdBQUcsSUFBSSxHQUFHVCxFQUFFLEdBQUcsb0VBQW9FLElBQUlVLEtBQUssR0FBRyxxQ0FBcUMsR0FBR0EsS0FBSyxHQUFHLGdEQUFnRCxHQUFHLEVBQUUsQ0FBQyxDQUFDO0FBQzFRO0FBQUMsSUFBQUYsRUFBQTtBQUFBSSxZQUFBLENBQUFKLEVBQUEiLCJpZ25vcmVMaXN0IjpbXX0=
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}