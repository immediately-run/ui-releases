var _csbRefreshUtils = require("/node_modules/__csb_bust/refresh-helper.js");var prevRefreshReg = window.$RefreshReg$;var prevRefreshSig = window.$RefreshSig$;_csbRefreshUtils.prelude(module);try {"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MDXContent;
var _MDXProvider = require("@immediately-run/sdk/MDXProvider");
var _jsxRuntime = require("react/jsx-runtime");
/*@jsxRuntime automatic*/
/*@jsxImportSource react*/

function _createMdxContent(props) {
  const _components = {
      a: "a",
      blockquote: "blockquote",
      code: "code",
      em: "em",
      h1: "h1",
      h2: "h2",
      h3: "h3",
      hr: "hr",
      li: "li",
      p: "p",
      strong: "strong",
      table: "table",
      tbody: "tbody",
      td: "td",
      th: "th",
      thead: "thead",
      tr: "tr",
      ul: "ul",
      ...(0, _MDXProvider.useMDXComponents)(),
      ...props.components
    },
    {
      HeadingAnchor
    } = _components;
  if (!HeadingAnchor) _missingMdxReference("HeadingAnchor", true);
  return /*#__PURE__*/(0, _jsxRuntime.jsxs)(_jsxRuntime.Fragment, {
    children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h1, {
      id: "reckoner-m1-build-handoff",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "reckoner-m1-build-handoff"
      }), "Reckoner M1 — build handoff"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Purpose."
      }), " Pick up the Reckoner build in a fresh session. This records what is built (M1 — the\npure spine + all three effectful shells; and M2 — the live-feed workstream, underway), how it is\norganized and verified, the working conventions, the environment quirks, and the concrete next\nsteps. · ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Updated:"
      }), " 2026-08-24"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.blockquote, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Reads first, in order:"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "product_definition.md"
        }), " → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ARCHITECTURE_PLAN.md"
        }), " §2 (the five\nparts), §3 (document model + stdlib + templates), §4 (engine), §6 (testing), §10\n(milestones) → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "AXIS2_SELF_HOSTING_WORKITEMS.md"
        }), " + §0.2 (dogfooding) → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "spikes/S5_SES_MODULE_RESOLUTION.md"
        }), ".\nThe canonical security architecture is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "REPORTING_SPREADSHEET_SPEC.md"
        }), "; adversarial\nfindings are folded into ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ARCHITECTURE_PLAN.md"
        }), " §13 — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "don't relitigate those."
        })]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-1",
      "data-slug": "1-current-state-m1-complete-all-three-shells-m2-live-feed-workstream-underway",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-1"
      }), "1. Current state — M1 complete (all three shells) + M2 live-feed workstream underway"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Reckoner went from the starter template to a tested formula-engine core, the report-view render\nsurface, a runnable static report, the worker-backed async engine, and the live-feed data plane.\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["All of M1 (shells A/B/C) and four M2 feed increments are merged to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "main"
        })]
      }), " (PRs #2–#19; #9 is\nthe S5 spike doc). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "359 vitest cases"
      }), "; every merge is green on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "tsc -b"
      }), " + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "npm test"
      }), " +\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "npm run lint"
      }), " + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "npm run build"
      }), ", and the app is live-verified in a browser (the report renders\nand a live feed recomputes it — §2.B / §2 M2 note)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.table, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.thead, {
        children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Area"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "Where"
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.th, {
            children: "What it provides"
          })]
        })
      }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tbody, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "stdlib"
            }), " (complete)"]
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/stdlib/"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["The entire pure formula vocabulary. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "table()"
            }), " fluent + free functions: shaping (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "filter"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "derive"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "sort"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "groupBy"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "rollup"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "join"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "antiJoin"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "pivot"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "topN"
            }), "), aggregators (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "sum"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "mean"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "median"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "count"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "min"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "max"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "quantile"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "first"
            }), "), ordered (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "lag"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "lead"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "scan"
            }), "+", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "cumsum"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "cummax"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "ema"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "asofJoin"
            }), "), dates (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "monthKey"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "addMonths"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "resolveRange"
            }), "/…), nulls (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "coalesce"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "safeDiv"
            }), "), screening (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "trend"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "outliers"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "deltas"
            }), "), event-time ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "window()"
            }), ". Plus ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "cell()"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "testCell()"
            }), " constructors, input-spec parsing (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "parseInput"
            }), "), metamorphic relations (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "conservation"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "permutationInvariance"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "scaleInvariance"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "property"
            }), "), assertions (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "expectClose"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "expectEqual"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "deepEqual"
            }), "), and the self-description ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "catalog"
            }), ". Barrel: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/stdlib/index.ts"
            }), "."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "document model"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/document/"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "parseManifest"
            }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "reckoner.json"
            }), " + compat envelope), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "parseFeedConfig"
            }), " (inline-secret guard), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "parseFixtureFrame"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "loadDocument(reader, root)"
            }), " (port-injected fs), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "resolveCompat"
            }), " (run/degrade/refuse) on a minimal ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "semver"
            }), " matcher."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "engine"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/engine/"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["The recalc core: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "buildGraph"
            }), " (wildcard expansion + enumerability guards), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "analyze"
            }), "/cycle detection, tier lattice (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "meetTiers"
            }), "), content-", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "hash"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "Scheduler"
            }), " (topo order, tier fold, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "(value,tier)"
            }), " cutoff, incremental recompute), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "runTest"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "classifyCell"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "runSuite"
            }), " (review verdict). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Engine shell:"
            }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "evaluateWorksheet"
            }), " (SES-confined worksheet eval, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "compartment.ts"
            }), ") + the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "Engine"
            }), " orchestrator (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "engine.ts"
            }), ") that runs the whole spine."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "report — types + validation"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/report/"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["The template layer contract: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "nodes.ts"
            }), " (render-as-data node model), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "catalog.ts"
            }), " (closed v1 component catalog + attribute schemas), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "validateTemplate"
            }), " (binding collection + authoring diagnostics + structural rules)."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "report — render shell (A)"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/report/render/"
            }), " + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/report/parse/"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["The React render surface (§3.3). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "ReportView"
            }), " walks a parsed ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "TemplateNode[]"
            }), " and draws the audited components, resolving every ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "source"
            }), " through the injected ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
              children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                children: "Bindings"
              }), " port"]
            }), " (value + tier; shell B supplies the engine adapter). One component per catalog entry — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "Kpi"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "Chart"
            }), " (SVG: bar grouped/stacked/normalized, line, area, scatter, histogram, pie ≤5+other), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "Table"
            }), " (sortable), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "Value"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "Facets"
            }), " (small-multiples), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "Gauge"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "Map"
            }), " (point + region-breakdown choropleth), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "Callout"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "Section"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "Row"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "ShowAbove"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "ShowBelow"
            }), " (ResizeObserver/matchMedia), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "Params"
            }), " + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "Select"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "Toggle"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "Range"
            }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "DateRange"
            }), ". Degraded states are component-owned (broken tile / needs-access / placeholder); the tier badge slot is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "reserved"
            }), " for the host (review-1 H2, never drawn here). Plus the safe MDX-subset parser (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "parse/mdx.ts"
            }), " + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "parse/literal.ts"
            }), ") — the dev stand-in for the platform D3 renderer; it ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "never evaluates"
            }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "f={fetch(\"/x\")}"
            }), " → inert). Unit-rendered against mock engine results via ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "react-dom/server"
            }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "render.test.tsx"
            }), ") + parser/chart-math/format/shape tests. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Known v1 gap:"
            }), " an inline component ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
              children: "within a prose line"
            }), " parses to separate block nodes (block-level is covered); real polygon-geography Map and Kpi ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "spark"
            }), " are deferred (see ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/report/render/index.ts"
            }), ")."]
          })]
        }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.tr, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.td, {
            children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "app integration (B)"
            })
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/app/"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/seed/"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/hooks/useReport.ts"
            }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "App.tsx"
            })]
          }), /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.td, {
            children: ["The runnable report. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "buildReportSession"
            }), " loads the bundled demo document (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "loadDocument"
            }), " over ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "memoryReader"
            }), ") → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "Engine.fromSources"
            }), " → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "run"
            }), " → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "parseTemplate"
            }), " → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "<ReportView>"
            }), "; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "sessionBindings"
            }), " is the ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
              children: ["engine→", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
                children: "Bindings"
              }), " adapter"]
            }), " (cell result / external / ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "missing"
            }), ", and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "setParam"
            }), " → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "engine.update"
            }), " → re-render). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "src/seed/"
            }), " is the portable bundled ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
              children: "Meridian demo"
            }), " (no Vite macros). Integration-tested end-to-end (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "reportSession.test.ts"
            }), ") + live-verified in a browser."]
          })]
        })]
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "S5 is closed positive"
      }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "spikes/S5_SES_MODULE_RESOLUTION.md"
      }), "): the platform module-fetch\npath resolves SES + CodeMirror and a starved SES ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "Compartment"
      }), " runs in-platform, so the engine\nrealm is buildable in-platform. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "Engine.fromSources(...)"
      }), " already proves the SES-confined\npipeline in Node with the real ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ses"
      }), " package."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-2",
      "data-slug": "2-what-remains-the-effectful-shells-in-recommended-order",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-2"
      }), "2. What remains — the effectful shells (in recommended order)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The pure spine, the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "report-view render shell (A, done — §1)"
      }), ", and the ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "App.tsx"
        }), "\nintegration + a runnable static report (B, done — §1)"]
      }), " are built. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "M1's exit gate is met:"
      }), "\nthe bundled Meridian demo document opens with zero prompts and renders a full report (KPIs,\nline/bar/pie charts, region map, faceted retention, sortable table) desktop + mobile, with the\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "SES-confined engine running in-browser"
      }), " — live-verified via ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "vite dev"
      }), " + headless Chrome, and\nthe full document→engine→bindings→param-recompute pipeline locked by ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "reportSession.test.ts"
      }), ".\nAll three shells (A/B/C) are now merged to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "main"
      }), ". Each plugs into the existing pure modules —\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "do not rewrite the core; wrap it."
      })]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: ["M2 — the live-feed workstream (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/feed/"
        }), ") is underway; four increments merged to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "main"
        }), ":"]
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Feed data-plane core"
        }), " (§5.3, PR #16) — content-addressed ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Frame"
        }), "s, the connector\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "RetentionBuffer"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "keepLast"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "keepFor"
        }), " + gap markers), keep-latest ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Conflator"
        }), " (shared by feeds\nand param drags, §5.3 F8), and the static ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "checkBufferCoversWindows"
        }), " coverage check."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Connector port + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "FeedRuntime"
          })]
        }), " (§5.1/§5.2/§5.3, PR #17) — a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Connector"
        }), " interface\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "manualConnector"
        }), " for dev/tests, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "pollingConnector"
        }), " over an injected fetch) tying connectors →\nbuffers → conflation → ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["conflated ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "engine.update"
          }), "s"]
        }), ", so a feed drives a live recompute\n(E2E-tested against the real ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "AsyncEngine"
        }), "; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "feeds.*"
        }), " tier folds through)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Live feed wired into the app"
        }), " (PR #18) — a synthetic demo feed (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/app/demoFeed.ts"
        }), ") +\na ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "feeds.live_regions"
        }), " cell + a \"Live activity\" chart; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "useReport"
        }), " runs a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "FeedRuntime"
        }), " over the\nsession engine (rAF flush cadence) and re-renders on each settled recompute. Live-verified in a\nreal browser over CDP (the chart populates and its values change over time). ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.em, {
          children: ["(Removed by R3-768 —\nthe app-supplied demo feed was report-view egress, not document content; a live-region feed\nreturns in R3-769 as a declared ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "feeds/*.feed.json"
          }), ".)"]
        })]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Glitch-freedom proven"
        }), " (§4.2 C-R-B, PR #19) — see §5; the common-epoch barrier is resolved\n(satisfied by construction), not a pending item."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Windowed-feed input resolution"
        }), " — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "{ feed, window }"
        }), " at the input site now resolves through\nthe engine's shared input resolver: the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "FeedRuntime"
        }), " publishes each feed's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "retained rows"
        }), "\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "feedBuffers.<name>"
        }), ") alongside the snapshot, the graph routes the object form to a\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "windowed-feed"
        }), " resolver (also keyed on ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "params.now"
        }), ", so a clock-only update advances the\nwindow), and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "resolveInputs"
        }), " applies ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "window()"
        }), " with the decided conventions — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "by"
        }), " defaults to\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ts"
        }), "; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "now"
        }), " = ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "params.now"
        }), " when supplied, else the newest retained event time; unplaceable rows\ndrop out; resolution never throws (recorded in ARCHITECTURE_PLAN §3). The static\nbuffer-coverage check composes via ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "declaredWindows(graph)"
        }), ", and the demo feed carries ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ts"
        }), " +\na 30s windowed cell live in the report. E2E-tested against the real ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "AsyncEngine"
        }), "."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.p, {
      children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Genuinely-remaining feed increments:"
      })
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The real host-proxied connector"
        }), " (§5.1 — the SSRF-bounded fetch capability) + the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "OPFS\nmaterialize-to-mount transport"
        }), " (§5.2). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "Platform-blocked:"
        }), " both need host services not present\nin the standalone reckoner repo; the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Connector"
        }), "/transport ports are the seams they slot into."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["See ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/feed/index.ts"
      }), " for the scope map."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "a-report-view-react-components-mdxnode-parse-done-srcreportrender-srcreportparse",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "a-report-view-react-components-mdxnode-parse-done-srcreportrender-srcreportparse"
      }), "A. Report-view React components + MDX→node parse — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "DONE"
      }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/report/render"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/report/parse"
      }), ")"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Shipped in its own PR. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "ReportView"
      }), " + one component per catalog entry + the safe MDX-subset\nparser, unit-rendered against mock engine results. The load-bearing seam shell B consumes: the\ninjected ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Bindings"
        }), " port"]
      }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/report/render/bindings.ts"
      }), ") — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "resolve(source) → {value, tier, status}"
      }), " and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "setParam(name, value)"
      }), ". Shell B supplies a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "Bindings"
      }), " adapter over the engine's\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "PassResult"
      }), " + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "params"
      }), " externals; the renderer needs no other engine knowledge. Deferred\nenrichments are listed in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/report/render/index.ts"
      }), " (host tier badge is a reserved slot; real\npolygon Map; Kpi ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "spark"
      }), "; full inline-MDX = the platform D3 renderer's remit)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "b-apptsx-integration-a-runnable-static-report-done-srcapp-srcseed-srchooksusereportts",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "b-apptsx-integration-a-runnable-static-report-done-srcapp-srcseed-srchooksusereportts"
      }), "B. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "App.tsx"
      }), " integration — a runnable static report — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "DONE"
      }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/app"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/seed"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/hooks/useReport.ts"
      }), ")"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Shipped (stacked on shell A's PR). The pipeline: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "App.tsx"
      }), " → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "useReport"
      }), " → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "buildReportSession"
      }), "\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/app/reportSession.ts"
      }), ") loads the bundled demo document via ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "loadDocument"
      }), " over an in-memory\nreader (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/app/memoryReader.ts"
      }), ") → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "Engine.fromSources"
      }), " → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "engine.run(externals)"
      }), " → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "parseTemplate"
      }), "\n→ ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "<ReportView nodes bindings />"
      }), ". The one new integration piece is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "sessionBindings"
      }), " — the\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Bindings"
        }), " adapter over the engine"]
      }), ": ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "resolve(source)"
      }), " returns the scheduler's published\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "{value, tier}"
      }), " for a cell (or the external for a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "fixtures.*"
      }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "params.*"
      }), " name, or ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "missing"
      }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "error"
      }), ");\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "setParam(name, value)"
      }), " writes the param, calls ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "engine.update(...)"
      }), ", and bumps a re-render tick."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The demo document"
        }), " is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/seed/"
        }), " — a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "portable, bundled"
        }), " Meridian monthly review\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "document.ts"
        }), " = manifest + a plain-JS ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "review.sheet.js"
        }), " worksheet + the MDX template + frozen\nfixtures; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "data.ts"
        }), " = real Meridian figures sliced to the last 12 months, regenerable via\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "scratchpad/gen-seed.mjs"
        }), " from ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "docs/case-study/meridian/data/*.csv"
        }), "). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "No Vite-only macros"
        }), "\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "?raw"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "import.meta.glob"
        }), ") — those break on immediately.run; the files are string/object\nconstants so the same code runs on both."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Not yet wired:"
        }), " loading a document from a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "user-granted mount"
        }), " (needs mount consent — M2);\nthe app ships the bundled seed so it renders with zero prompts. A real fs-backed ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "DocumentReader"
        }), "\nover the platform ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "fs"
        }), "/local ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "dev-fs"
        }), " slots in where ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "memoryReader"
        }), " is today."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Live-verified"
        }), " at ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "vite dev"
        }), " (headless Chrome, desktop + 390px): the SES engine runs\nin-browser, all catalog components render, the span widget recomputes. immediately.run\nlocal-provider verification (the platform sandbox path) is the remaining live check — S5 already\nproved SES resolves + runs in-platform, so this is expected-green, not de-risking."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h3, {
      id: "c-engine-worker-wiring-done-wired-into-the-app-srcengineworker-srcengineasyncenginets-srcentryenginets",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "c-engine-worker-wiring-done-wired-into-the-app-srcengineworker-srcengineasyncenginets-srcentryenginets"
      }), "C. Engine worker wiring — ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "DONE + wired into the app"
      }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/engine/worker/"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/engine/asyncEngine.ts"
      }), ", ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "src/entry/engine.ts"
      }), ")"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["The executor realm is built and tested. The worker (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "worker/engineWorker.ts"
      }), " + the real\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "entry/engine.ts"
      }), " that ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "lockdown()"
      }), "s and serves ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "build"
      }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "eval"
      }), " over ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "postMessage"
      }), ") is a\nterminable formula executor; the host ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "AsyncEngine"
      }), " owns all scheduling + epoch/breaker state\n(§4.1) and drives it over a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "WorkerTransport"
      }), " port (real Web Worker or an in-process double).\nDelivered async invariants:"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Watchdog circuit breaker"
        }), " (§4.1) — a per-eval wall-clock budget; exceeding it is a hard\nrunaway → the worker is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "terminate()"
        }), "d + rebuilt and the pure ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "CircuitBreaker"
        }), " counts it;\nafter ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "hardLimit"
        }), " the cell ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "quarantines"
        }), " and dependents resolve to the propagated ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "lattice\nerror"
        }), " (a re-arm recovers). Soft budget-exceed = confirm-before-stick + TTL decay. This is\nthe availability protection SES cannot give (RQ-A4 residual)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Single-slot run-to-completion supersession"
        }), " — overlapping ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "update()"
        }), "s never cancel an\nin-flight pass; they coalesce to one follow-up with the latest externals (no cancel-restart\nlivelock). Async formulas (a formula may return a promise) are awaited."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["Shared input resolution (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "resolve.ts"
        }), ") — one path with the sync ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Scheduler"
        }), " (refactored to\nuse it), tier fold + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "(value,tier)"
        }), " publish, cycle→error-every-cell."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Glitch-freedom (§4.2 C-R-B) is satisfied by construction, and now PROVEN."
      }), " The serial\nsingle-context engine (sequential topo eval over one externals snapshot + serialized passes)\ncannot assemble a cell from two epochs even on an asymmetric diamond under a continuous feed —\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "asyncEngine.glitch.test.ts"
      }), " (spec §11 E-2: property test over random DAGs + bursty updates,\nwatching every settled pass via the new ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "onPass"
      }), " hook) demonstrates it. The ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "explicit per-cell\nepoch-gate barrier becomes necessary only if concurrent arm evaluation is introduced"
      }), " (the\ndeferred worker-pool partitioning, §4.1) — the single-context engine does not need it; that was\nthe correction from treating it as an unbuilt gap. ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "Also remaining:"
      }), " wiring ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "AsyncEngine"
      }), " into ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "App.tsx"
      }), " in place\nof the sync ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "Engine"
      }), " (so even the static render runs off-main-thread with watchdog protection),\nand the real-", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "Worker"
      }), " E2E in a browser (the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "entry/engine.ts"
      }), " shim + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "lockdown()"
      }), " — thin, and\nS5 already proved SES resolves + runs in-platform). Verified by the engine test suite\n(sync-equivalence, error propagation, cycles, watchdog→quarantine→recover, supersession)."]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-3",
      "data-slug": "3-working-conventions-honor-these",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-3"
      }), "3. Working conventions (honor these)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Protocol:"
        }), " the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "next-roadmap-item"
        }), " skill's flow. Each code change in a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "dedicated git\nworktree"
        }), " off ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "origin/main"
        }), " (or stacked on an open branch), a PR per repo, verified against\nthe exit criteria, worktree removed after the PR is up. Reckoner is a normal repo (PRs);\nonly the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "docs"
        }), " repo commits directly to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "main"
        }), "."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Verify gate (run before every PR):"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npx tsc -b"
        }), " · ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npm test"
        }), " (vitest) · ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npm run lint"
        }), "\n(the Fast-Refresh rule) · ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "npm run build"
        }), ". All must be green."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "tsconfig constraints"
        }), " (they bite): ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "erasableSyntaxOnly"
        }), " (no ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "enum"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "namespace"
        }), "/parameter\nproperties — use union literals + explicit fields), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "verbatimModuleSyntax"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "import type"
        }), " for\ntypes), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "noUnusedLocals"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "noUnusedParameters"
        }), ", and tseslint ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "no-explicit-any"
        }), " (use ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "unknown"
        }), "/\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Value"
        }), "/generics). Imports use explicit ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: ".ts"
        }), " extensions (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "allowImportingTsExtensions"
        }), ")."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "The load-bearing design principle:"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "separate pure logic from the effectful collaborator,\nand inject the collaborator as a port."
        }), " The whole spine is offline-testable because the\neffectful bits are ports: the scheduler's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Evaluator"
        }), ", the test runner's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "reevaluate"
        }), ", the\ndocument loader's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "DocumentReader"
        }), ", the engine's SES ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Compartment"
        }), ". Keep this — a new shell\nshould expose its effect as an injected port so its logic stays unit-testable."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "New formula-facing callable → add a self-description"
        }), " to ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/stdlib/catalog.ts"
        }), ". The\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "catalog.test.ts"
        }), " gate fails if an exported callable is undescribed (or a description orphaned)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "CLAUDE.md"
        }), " (repo root) is the app-authoring contract (entry is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "App.tsx"
        }), "'s default export;\na component file exports only components; delegate editing to the platform editor; etc.)."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-4",
      "data-slug": "4-environment",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-4"
      }), "4. Environment"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "The platform live-check is a gate, not an expectation (learned 2026-08-24, the hard\nway):"
          }), " the demo first ran on production immediately.run only after M2 — and died with\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "Cannot use 'import.meta' outside a module"
          }), ". The platform transpiles app source ESM→CJS\nand evaluates it as a classic script, where ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "import.meta"
          }), " is a parse-time SyntaxError\nthat kills the whole module (a claim that the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "new URL(..., import.meta.url)"
          }), " Worker form\n\"works on vite and immediately.run alike\" had asserted, never verified). Fixes: the\nworker URL lives in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "src/app/workerUrl.ts"
          }), ", reached only via dynamic import inside\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "makeTransport"
          }), "'s try/catch — on the platform the failure is catchable and the in-process\nengine transport takes over; ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "src/app/platformGuards.test.ts"
          }), " greeps the source for the\nclass (comment-aware, two exempt files) so it cannot silently return. ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
            children: ["Verify on\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.a, {
              href: "https://immediately.run/present/github/immediately-run/reckoner/main",
              children: "https://immediately.run/present/github/immediately-run/reckoner/main"
            }), " before calling any\nshell \"done\""]
          }), " — vite-only verification is exactly the trap the app CLAUDE.md warns about."]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
            children: ["Bring the local stack up when ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "local.immediately.run"
            }), " 502s"]
          }), " — see the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "local-stack-bringup"
          }), "\nmemory (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "docs/.claude/memory/"
          }), " in the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "docs"
          }), " repo) and the S5 spike's reproduce section:\nnginx → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: ":3000"
          }), " site-main (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "BROWSER=none npm start"
          }), "), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: ":1234"
          }), " sandbox\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "npx parcel ./src/index.html --port 1234"
          }), ", bypassing the stale-", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "dist/"
          }), " predev guard), ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: ":4000"
          }), "\nbackend (root 404 is normal)."]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "Chrome DevTools MCP"
          }), " is the intended live-debug tool. If it is down, drive the host headless\nwith ", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
            children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
              children: "puppeteer-core"
            }), " → system Chrome"]
          }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "acceptInsecureCerts"
          }), " + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "--ignore-certificate-errors"
          }), "\nfor the local nginx cert + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "--disable-features=LocalNetworkAccessChecks,BlockInsecurePrivateNetworkRequests"
          }), "\nfor the loopback provider fetch). The app renders in the sandbox's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "nested iframe"
          }), ", so scan\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "page.frames()"
          }), " and read a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "console.log"
          }), " marker. Keep any driver-only dep out of the served\napp's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "package.json"
          }), ". (A worked example lived in the session scratchpad ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "ses-spike/"
          }), ".)"]
        }), "\n"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
          children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
            children: "Run an app on the real host with no commit:"
          }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "immediately.run dev . --origin https://local.immediately.run --json"
          }), "\n→ open the printed ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "/edit/…/live#ir-endpoint=…&ir-token=…"
          }), " link."]
        }), "\n"]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.hr, {}), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-5",
      "data-slug": "5-deferred-items-registry-noted-in-code-dont-lose-these",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-5"
      }), "5. Deferred-items registry (noted in code; don't lose these)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.ul, {
      children: ["\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "stdlib"
        }), " — none outstanding (the tail — screening + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "window()"
        }), " — landed in #7)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "document model"
        }), " — host-side ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "compat"
        }), " ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
          children: "derivation"
        }), " by static analysis at save time (this\nmodule validates/resolves an existing envelope). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Cross-reference validation shipped"
        }), "\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/document/xref.ts"
        }), "): a worksheet external naming a missing feed/fixture/static is an\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "error"
        }), " (a silent-null class killed); a param with no default and no widget is a\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "warning"
        }), "; fixture ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "sourceFeed"
        }), " citations the document doesn't declare are ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "warnings"
        }), "\n(historical provenance — the frozen demo legitimately cites its capture source). Wired at\nload (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "validateFixtureProvenance"
        }), ") and in ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "reportSession"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "xrefDiagnostics"
        }), " over the\nengine's ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "externalReferences()"
        }), " + manifest params + template widget names + runtime feeds);\nerror-severity diagnostics render as a note above the report. (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/document/index.ts"
        }), ".)"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "engine scheduler"
        }), " — shell C shipped single-slot supersession + the watchdog circuit\nbreaker (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/engine/asyncEngine.ts"
        }), " + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "circuitBreaker.ts"
        }), "). ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "Glitch-freedom (§4.2 C-R-B) is\nsatisfied by construction + proven"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "asyncEngine.glitch.test.ts"
        }), ", spec §11 E-2); the explicit\nper-cell epoch-gate barrier is needed only if concurrent arm evaluation is added (deferred\nworker pool, §4.1) — see the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "asyncEngine.ts"
        }), " header."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "engine shell"
        }), " — worker built + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "wired into the app"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "AsyncEngine"
        }), " now backs\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "reportSession"
        }), ", real ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Worker"
        }), "+", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "lockdown()"
        }), " with an in-process fallback). Holdout-fixture\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "substitution"
        }), " test semantics ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "shipped"
        }), ": a test declaring its own ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "inputs"
        }), " runs the\nsubject over ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "{ ...live, ...declared }"
        }), " (same-local-name override, partial allowed;\nname mismatch / unresolvable ref / subject error over the fixture fails the test with a\nmessage) — the mapping is pinned in ARCHITECTURE_PLAN §6. Remaining: the transpiled-module\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "linker"
        }), " (the evaluator uses a source transform + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Compartment.evaluate"
        }), "; in-platform the\nsandbox transpiles and the Compartment module loader links). (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/engine/engine.ts"
        }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "compartment.ts"
        }), ".)"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "report"
        }), " — shell A shipped the components + MDX parser. Remaining/deferred (in\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/report/render/index.ts"
        }), "): the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "host-rendered tier badge"
        }), " (the slot is reserved, we\nsupply the value); a real ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "polygon-geography Map"
        }), " (v1 choropleth ships a region breakdown);\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.strong, {
          children: ["Kpi ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
            children: "spark"
          })]
        }), " (needs a series binding the v1 catalog doesn't carry); full CommonMark +\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "inline-component-in-prose"
        }), " (the platform D3 renderer's remit — block-level is covered)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "feed (M2)"
        }), " — the data-plane core + connector/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "FeedRuntime"
        }), " are built and wired into the app\n(#16–#18), and ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "windowed inputs resolve"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "{ feed, window }"
        }), " over the buffer via the engine's\ninput resolver — see §2). Remaining, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "platform-blocked"
        }), ": the real host-proxied connector\n(§5.1 SSRF fetch) + OPFS materialize-to-mount transport (§5.2). (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/feed/index.ts"
        }), ".)"]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "relations"
        }), " — the M2 test runner supplies the metamorphic re-evaluation; the relation\ndescriptors carry only their pure transform + comparison (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/stdlib/relations.ts"
        }), ")."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "review surface (§6, brief surface 3) — first slice shipped"
        }), ": the ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "workbook panel"
        }), "\n(", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/app/WorkbookPanel.tsx"
        }), " + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "WorkbookPanelBody.tsx"
        }), "). One card per cell (name, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "doc"
        }), ",\nvalue preview, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "coverage-state chip"
        }), ") with test cards beneath their subject (kind label +\npass/fail + message); the four states — validated / pinned / untested / failing — are\nvisually distinct by CSS class (§6: pinned must not read as tested). Engine plumbing: the\nworker keeps test defs (their closures never cross the wire — a ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "run-tests"
        }), " op executes\nthem in the SES realm over host-computed contexts and returns serializable verdicts);\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "AsyncEngine.runTests()"
        }), " rides a wall-clock budget like ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "eval"
        }), " (a wedged suite restarts the\nworker and rejects; the per-cell breaker does not yet count test-run terminations — a\nbooked residual). Opened from the report header (author surface — viewers never see\nworksheets, brief A3). The demo worksheet carries an honest mix (a specification test →\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "pinned"
        }), "; a property relation → ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "validated"
        }), "; the rest genuinely untested)."]
      }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.li, {
        children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "value inspector — first slice shipped"
        }), " (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/app/ValueInspector.tsx"
        }), ", brief surface 2):\nbinding name, ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "doc"
        }), ", current value + tier (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "plain data — the tier badge is host-drawn\nchrome, review-1 H2; the app reserves the slot, never draws one"
        }), "), read-only formula\nsource (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "formulaSource"
        }), " crosses the wire as ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "Function.prototype.toString"
        }), " at worker\nbuild), declared-input chips (cell refs navigable hop-by-hop — the V3 walk; windowed-feed\nand wildcard chips inert), and the coverage state + this cell's test outcomes. Opens from\nworkbook-panel card clicks (master-detail in the panel). The ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "precedent-neighborhood\nview"
        }), " (review-1 UX-4) shipped with it (", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "src/engine/precedents.ts"
        }), " + ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "PrecedentView"
        }), "):\nthe whole precedent subgraph at once — the DAG unrolled as a tree, externals as leaves,\nwildcards expanded, node-capped with an honest truncation flag — nested beneath the\ninspector's chips, every cell node navigable. The ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
          children: "on-pixel affordance"
        }), " (V3)\nshipped with it: ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "ReportView"
        }), " takes an optional inspection port — bound elements (a\nliteral ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
          children: "source"
        }), " attr) get a quiet hover/focus-reveal corner button (desktop) and a\n~450ms long-press opens directly (touch); without the port, run mode renders exactly as\nbefore (no affordance, no tax). The inspected cell is app-level state shared by the pixel\naffordance and the panel's cards; the inspector renders as a docked card (bottom-right\ndesktop / bottom-sheet phone). Remaining review-surface work: edit/ask-assistant\naffordances (need a writable mount — platform), and per-cell verdict marks inside the\nreport itself."]
      }), "\n"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.h2, {
      id: "sec-6",
      "data-slug": "6-dogfooding-note-axis-2",
      children: [/*#__PURE__*/(0, _jsxRuntime.jsx)(HeadingAnchor, {
        id: "sec-6"
      }), "6. Dogfooding note (Axis-2)"]
    }), "\n", /*#__PURE__*/(0, _jsxRuntime.jsxs)(_components.p, {
      children: ["Per §0.2: document ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "content"
      }), " is fully in-platform authorable now (S1); document ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "test runs"
      }), "\nare in-platform by construction once the engine runs (S2); ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "S5 is proven"
      }), " so the engine/editor\n", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.em, {
        children: "source realms are buildable in-platform"
      }), "; the remaining self-hosting gap is ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.strong, {
        children: "S4b"
      }), " (an\nin-platform Node-equivalent CI gate for ", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "build"
      }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "lint"
      }), "/", /*#__PURE__*/(0, _jsxRuntime.jsx)(_components.code, {
        children: "vitest"
      }), " of the TS source) — until it\nlands, source-level CI (the verify gate above) stays external, which is the honest exception."]
    })]
  });
}
function MDXContent(props = {}) {
  const {
    wrapper: MDXLayout
  } = {
    ...(0, _MDXProvider.useMDXComponents)(),
    ...props.components
  };
  return MDXLayout ? /*#__PURE__*/(0, _jsxRuntime.jsx)(MDXLayout, {
    ...props,
    children: /*#__PURE__*/(0, _jsxRuntime.jsx)(_createMdxContent, {
      ...props
    })
  }) : _createMdxContent(props);
}
_c = MDXContent;
function _missingMdxReference(id, component, place) {
  throw new Error("Expected " + (component ? "component" : "object") + " `" + id + "` to be defined: you likely forgot to import, pass, or provide it." + (place ? "\nIt’s referenced in your code at `" + place + "` in `/app/docs/M1_BUILD_HANDOFF.md`" : ""));
}
var _c;
$RefreshReg$(_c, "MDXContent");
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfTURYUHJvdmlkZXIiLCJyZXF1aXJlIiwiX2pzeFJ1bnRpbWUiLCJfY3JlYXRlTWR4Q29udGVudCIsInByb3BzIiwiX2NvbXBvbmVudHMiLCJhIiwiYmxvY2txdW90ZSIsImNvZGUiLCJlbSIsImgxIiwiaDIiLCJoMyIsImhyIiwibGkiLCJwIiwic3Ryb25nIiwidGFibGUiLCJ0Ym9keSIsInRkIiwidGgiLCJ0aGVhZCIsInRyIiwidWwiLCJfcHJvdmlkZUNvbXBvbmVudHMiLCJjb21wb25lbnRzIiwiSGVhZGluZ0FuY2hvciIsIl9taXNzaW5nTWR4UmVmZXJlbmNlIiwianN4cyIsIkZyYWdtZW50IiwiY2hpbGRyZW4iLCJpZCIsImpzeCIsImhyZWYiLCJNRFhDb250ZW50Iiwid3JhcHBlciIsIk1EWExheW91dCIsIl9jIiwiY29tcG9uZW50IiwicGxhY2UiLCJFcnJvciIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIk0xX0JVSUxEX0hBTkRPRkYubWQiXSwic291cmNlc0NvbnRlbnQiOlsiLypAanN4UnVudGltZSBhdXRvbWF0aWMqL1xuLypAanN4SW1wb3J0U291cmNlIHJlYWN0Ki9cbmltcG9ydCB7dXNlTURYQ29tcG9uZW50cyBhcyBfcHJvdmlkZUNvbXBvbmVudHN9IGZyb20gXCJAaW1tZWRpYXRlbHktcnVuL3Nkay9NRFhQcm92aWRlclwiO1xuZnVuY3Rpb24gX2NyZWF0ZU1keENvbnRlbnQocHJvcHMpIHtcbiAgY29uc3QgX2NvbXBvbmVudHMgPSB7XG4gICAgYTogXCJhXCIsXG4gICAgYmxvY2txdW90ZTogXCJibG9ja3F1b3RlXCIsXG4gICAgY29kZTogXCJjb2RlXCIsXG4gICAgZW06IFwiZW1cIixcbiAgICBoMTogXCJoMVwiLFxuICAgIGgyOiBcImgyXCIsXG4gICAgaDM6IFwiaDNcIixcbiAgICBocjogXCJoclwiLFxuICAgIGxpOiBcImxpXCIsXG4gICAgcDogXCJwXCIsXG4gICAgc3Ryb25nOiBcInN0cm9uZ1wiLFxuICAgIHRhYmxlOiBcInRhYmxlXCIsXG4gICAgdGJvZHk6IFwidGJvZHlcIixcbiAgICB0ZDogXCJ0ZFwiLFxuICAgIHRoOiBcInRoXCIsXG4gICAgdGhlYWQ6IFwidGhlYWRcIixcbiAgICB0cjogXCJ0clwiLFxuICAgIHVsOiBcInVsXCIsXG4gICAgLi4uX3Byb3ZpZGVDb21wb25lbnRzKCksXG4gICAgLi4ucHJvcHMuY29tcG9uZW50c1xuICB9LCB7SGVhZGluZ0FuY2hvcn0gPSBfY29tcG9uZW50cztcbiAgaWYgKCFIZWFkaW5nQW5jaG9yKSBfbWlzc2luZ01keFJlZmVyZW5jZShcIkhlYWRpbmdBbmNob3JcIiwgdHJ1ZSk7XG4gIHJldHVybiA8PjxfY29tcG9uZW50cy5oMSBpZD1cInJlY2tvbmVyLW0xLWJ1aWxkLWhhbmRvZmZcIj48SGVhZGluZ0FuY2hvciBpZD1cInJlY2tvbmVyLW0xLWJ1aWxkLWhhbmRvZmZcIiAvPntcIlJlY2tvbmVyIE0xIOKAlCBidWlsZCBoYW5kb2ZmXCJ9PC9fY29tcG9uZW50cy5oMT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlB1cnBvc2UuXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFBpY2sgdXAgdGhlIFJlY2tvbmVyIGJ1aWxkIGluIGEgZnJlc2ggc2Vzc2lvbi4gVGhpcyByZWNvcmRzIHdoYXQgaXMgYnVpbHQgKE0xIOKAlCB0aGVcXG5wdXJlIHNwaW5lICsgYWxsIHRocmVlIGVmZmVjdGZ1bCBzaGVsbHM7IGFuZCBNMiDigJQgdGhlIGxpdmUtZmVlZCB3b3Jrc3RyZWFtLCB1bmRlcndheSksIGhvdyBpdCBpc1xcbm9yZ2FuaXplZCBhbmQgdmVyaWZpZWQsIHRoZSB3b3JraW5nIGNvbnZlbnRpb25zLCB0aGUgZW52aXJvbm1lbnQgcXVpcmtzLCBhbmQgdGhlIGNvbmNyZXRlIG5leHRcXG5zdGVwcy4gwrcgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJVcGRhdGVkOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAyMDI2LTA4LTI0XCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5wPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUmVhZHMgZmlyc3QsIGluIG9yZGVyOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJwcm9kdWN0X2RlZmluaXRpb24ubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKGkiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJBUkNISVRFQ1RVUkVfUExBTi5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgwqcyICh0aGUgZml2ZVxcbnBhcnRzKSwgwqczIChkb2N1bWVudCBtb2RlbCArIHN0ZGxpYiArIHRlbXBsYXRlcyksIMKnNCAoZW5naW5lKSwgwqc2ICh0ZXN0aW5nKSwgwqcxMFxcbihtaWxlc3RvbmVzKSDihpIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQVhJUzJfU0VMRl9IT1NUSU5HX1dPUktJVEVNUy5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKyDCpzAuMiAoZG9nZm9vZGluZykg4oaSIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNwaWtlcy9TNV9TRVNfTU9EVUxFX1JFU09MVVRJT04ubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLlxcblRoZSBjYW5vbmljYWwgc2VjdXJpdHkgYXJjaGl0ZWN0dXJlIGlzIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlJFUE9SVElOR19TUFJFQURTSEVFVF9TUEVDLm1kXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjsgYWR2ZXJzYXJpYWxcXG5maW5kaW5ncyBhcmUgZm9sZGVkIGludG8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQVJDSElURUNUVVJFX1BMQU4ubWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIMKnMTMg4oCUIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZG9uJ3QgcmVsaXRpZ2F0ZSB0aG9zZS5cIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5ibG9ja3F1b3RlPntcIlxcblwifTxfY29tcG9uZW50cy5ociAvPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInNlYy0xXCIgZGF0YS1zbHVnPVwiMS1jdXJyZW50LXN0YXRlLW0xLWNvbXBsZXRlLWFsbC10aHJlZS1zaGVsbHMtbTItbGl2ZS1mZWVkLXdvcmtzdHJlYW0tdW5kZXJ3YXlcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy0xXCIgLz57XCIxLiBDdXJyZW50IHN0YXRlIOKAlCBNMSBjb21wbGV0ZSAoYWxsIHRocmVlIHNoZWxscykgKyBNMiBsaXZlLWZlZWQgd29ya3N0cmVhbSB1bmRlcndheVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+e1wiUmVja29uZXIgd2VudCBmcm9tIHRoZSBzdGFydGVyIHRlbXBsYXRlIHRvIGEgdGVzdGVkIGZvcm11bGEtZW5naW5lIGNvcmUsIHRoZSByZXBvcnQtdmlldyByZW5kZXJcXG5zdXJmYWNlLCBhIHJ1bm5hYmxlIHN0YXRpYyByZXBvcnQsIHRoZSB3b3JrZXItYmFja2VkIGFzeW5jIGVuZ2luZSwgYW5kIHRoZSBsaXZlLWZlZWQgZGF0YSBwbGFuZS5cXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIkFsbCBvZiBNMSAoc2hlbGxzIEEvQi9DKSBhbmQgZm91ciBNMiBmZWVkIGluY3JlbWVudHMgYXJlIG1lcmdlZCB0byBcIn08X2NvbXBvbmVudHMuY29kZT57XCJtYWluXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoUFJzICMy4oCTIzE5OyAjOSBpc1xcbnRoZSBTNSBzcGlrZSBkb2MpLiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIjM1OSB2aXRlc3QgY2FzZXNcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCI7IGV2ZXJ5IG1lcmdlIGlzIGdyZWVuIG9uIFwifTxfY29tcG9uZW50cy5jb2RlPntcInRzYyAtYlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJucG0gdGVzdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgK1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcIm5wbSBydW4gbGludFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJucG0gcnVuIGJ1aWxkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgYW5kIHRoZSBhcHAgaXMgbGl2ZS12ZXJpZmllZCBpbiBhIGJyb3dzZXIgKHRoZSByZXBvcnQgcmVuZGVyc1xcbmFuZCBhIGxpdmUgZmVlZCByZWNvbXB1dGVzIGl0IOKAlCDCpzIuQiAvIMKnMiBNMiBub3RlKS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnRhYmxlPjxfY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRoPntcIkFyZWFcIn08L19jb21wb25lbnRzLnRoPjxfY29tcG9uZW50cy50aD57XCJXaGVyZVwifTwvX2NvbXBvbmVudHMudGg+PF9jb21wb25lbnRzLnRoPntcIldoYXQgaXQgcHJvdmlkZXNcIn08L19jb21wb25lbnRzLnRoPjwvX2NvbXBvbmVudHMudHI+PC9fY29tcG9uZW50cy50aGVhZD48X2NvbXBvbmVudHMudGJvZHk+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcInN0ZGxpYlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoY29tcGxldGUpXCJ9PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL3N0ZGxpYi9cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiVGhlIGVudGlyZSBwdXJlIGZvcm11bGEgdm9jYWJ1bGFyeS4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widGFibGUoKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZmx1ZW50ICsgZnJlZSBmdW5jdGlvbnM6IHNoYXBpbmcgKFwifTxfY29tcG9uZW50cy5jb2RlPntcImZpbHRlclwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZGVyaXZlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJzb3J0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJncm91cEJ5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJyb2xsdXBcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcImpvaW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcImFudGlKb2luXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJwaXZvdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widG9wTlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLCBhZ2dyZWdhdG9ycyAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3VtXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJtZWFuXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJtZWRpYW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcImNvdW50XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJtaW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcIm1heFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicXVhbnRpbGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcImZpcnN0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiksIG9yZGVyZWQgKFwifTxfY29tcG9uZW50cy5jb2RlPntcImxhZ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibGVhZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic2NhblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIrXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY3Vtc3VtXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJjdW1tYXhcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcImVtYVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYXNvZkpvaW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSwgZGF0ZXMgKFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1vbnRoS2V5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJhZGRNb250aHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcInJlc29sdmVSYW5nZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIv4oCmKSwgbnVsbHMgKFwifTxfY29tcG9uZW50cy5jb2RlPntcImNvYWxlc2NlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJzYWZlRGl2XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiksIHNjcmVlbmluZyAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widHJlbmRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcIm91dGxpZXJzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJkZWx0YXNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSwgZXZlbnQtdGltZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ3aW5kb3coKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuIFBsdXMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2VsbCgpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJ0ZXN0Q2VsbCgpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjb25zdHJ1Y3RvcnMsIGlucHV0LXNwZWMgcGFyc2luZyAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicGFyc2VJbnB1dFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLCBtZXRhbW9ycGhpYyByZWxhdGlvbnMgKFwifTxfY29tcG9uZW50cy5jb2RlPntcImNvbnNlcnZhdGlvblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicGVybXV0YXRpb25JbnZhcmlhbmNlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJzY2FsZUludmFyaWFuY2VcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcInByb3BlcnR5XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiksIGFzc2VydGlvbnMgKFwifTxfY29tcG9uZW50cy5jb2RlPntcImV4cGVjdENsb3NlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJleHBlY3RFcXVhbFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZGVlcEVxdWFsXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiksIGFuZCB0aGUgc2VsZi1kZXNjcmlwdGlvbiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjYXRhbG9nXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi4gQmFycmVsOiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvc3RkbGliL2luZGV4LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi5cIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcImRvY3VtZW50IG1vZGVsXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2RvY3VtZW50L1wifTwvX2NvbXBvbmVudHMuY29kZT48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJwYXJzZU1hbmlmZXN0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicmVja29uZXIuanNvblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKyBjb21wYXQgZW52ZWxvcGUpLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJwYXJzZUZlZWRDb25maWdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChpbmxpbmUtc2VjcmV0IGd1YXJkKSwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicGFyc2VGaXh0dXJlRnJhbWVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJsb2FkRG9jdW1lbnQocmVhZGVyLCByb290KVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKHBvcnQtaW5qZWN0ZWQgZnMpLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyZXNvbHZlQ29tcGF0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAocnVuL2RlZ3JhZGUvcmVmdXNlKSBvbiBhIG1pbmltYWwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic2VtdmVyXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBtYXRjaGVyLlwifTwvX2NvbXBvbmVudHMudGQ+PC9fY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiZW5naW5lXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2VuZ2luZS9cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiVGhlIHJlY2FsYyBjb3JlOiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJidWlsZEdyYXBoXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAod2lsZGNhcmQgZXhwYW5zaW9uICsgZW51bWVyYWJpbGl0eSBndWFyZHMpLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJhbmFseXplXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9jeWNsZSBkZXRlY3Rpb24sIHRpZXIgbGF0dGljZSAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibWVldFRpZXJzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiksIGNvbnRlbnQtXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaGFzaFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlNjaGVkdWxlclwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKHRvcG8gb3JkZXIsIHRpZXIgZm9sZCwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiKHZhbHVlLHRpZXIpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjdXRvZmYsIGluY3JlbWVudGFsIHJlY29tcHV0ZSksIFwifTxfY29tcG9uZW50cy5jb2RlPntcInJ1blRlc3RcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcImNsYXNzaWZ5Q2VsbFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicnVuU3VpdGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChyZXZpZXcgdmVyZGljdCkuIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiRW5naW5lIHNoZWxsOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJldmFsdWF0ZVdvcmtzaGVldFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKFNFUy1jb25maW5lZCB3b3Jrc2hlZXQgZXZhbCwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY29tcGFydG1lbnQudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSArIHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJFbmdpbmVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG9yY2hlc3RyYXRvciAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZW5naW5lLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikgdGhhdCBydW5zIHRoZSB3aG9sZSBzcGluZS5cIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcInJlcG9ydCDigJQgdHlwZXMgKyB2YWxpZGF0aW9uXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL3JlcG9ydC9cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiVGhlIHRlbXBsYXRlIGxheWVyIGNvbnRyYWN0OiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJub2Rlcy50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKHJlbmRlci1hcy1kYXRhIG5vZGUgbW9kZWwpLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjYXRhbG9nLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoY2xvc2VkIHYxIGNvbXBvbmVudCBjYXRhbG9nICsgYXR0cmlidXRlIHNjaGVtYXMpLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ2YWxpZGF0ZVRlbXBsYXRlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoYmluZGluZyBjb2xsZWN0aW9uICsgYXV0aG9yaW5nIGRpYWdub3N0aWNzICsgc3RydWN0dXJhbCBydWxlcykuXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50cj48X2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnN0cm9uZz57XCJyZXBvcnQg4oCUIHJlbmRlciBzaGVsbCAoQSlcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJzcmMvcmVwb3J0L3JlbmRlci9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiICsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL3JlcG9ydC9wYXJzZS9cIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMudGQ+e1wiVGhlIFJlYWN0IHJlbmRlciBzdXJmYWNlICjCpzMuMykuIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlJlcG9ydFZpZXdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHdhbGtzIGEgcGFyc2VkIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlRlbXBsYXRlTm9kZVtdXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhbmQgZHJhd3MgdGhlIGF1ZGl0ZWQgY29tcG9uZW50cywgcmVzb2x2aW5nIGV2ZXJ5IFwifTxfY29tcG9uZW50cy5jb2RlPntcInNvdXJjZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdGhyb3VnaCB0aGUgaW5qZWN0ZWQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz48X2NvbXBvbmVudHMuY29kZT57XCJCaW5kaW5nc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcG9ydFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAodmFsdWUgKyB0aWVyOyBzaGVsbCBCIHN1cHBsaWVzIHRoZSBlbmdpbmUgYWRhcHRlcikuIE9uZSBjb21wb25lbnQgcGVyIGNhdGFsb2cgZW50cnkg4oCUIFwifTxfY29tcG9uZW50cy5jb2RlPntcIktwaVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkNoYXJ0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoU1ZHOiBiYXIgZ3JvdXBlZC9zdGFja2VkL25vcm1hbGl6ZWQsIGxpbmUsIGFyZWEsIHNjYXR0ZXIsIGhpc3RvZ3JhbSwgcGllIOKJpDUrb3RoZXIpLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJUYWJsZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKHNvcnRhYmxlKSwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiVmFsdWVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJGYWNldHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChzbWFsbC1tdWx0aXBsZXMpLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJHYXVnZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIk1hcFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKHBvaW50ICsgcmVnaW9uLWJyZWFrZG93biBjaG9yb3BsZXRoKSwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQ2FsbG91dFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlNlY3Rpb25cIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcIlJvd1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlNob3dBYm92ZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiU2hvd0JlbG93XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoUmVzaXplT2JzZXJ2ZXIvbWF0Y2hNZWRpYSksIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlBhcmFtc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJTZWxlY3RcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcIlRvZ2dsZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiUmFuZ2VcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcIkRhdGVSYW5nZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuIERlZ3JhZGVkIHN0YXRlcyBhcmUgY29tcG9uZW50LW93bmVkIChicm9rZW4gdGlsZSAvIG5lZWRzLWFjY2VzcyAvIHBsYWNlaG9sZGVyKTsgdGhlIHRpZXIgYmFkZ2Ugc2xvdCBpcyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInJlc2VydmVkXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGZvciB0aGUgaG9zdCAocmV2aWV3LTEgSDIsIG5ldmVyIGRyYXduIGhlcmUpLiBQbHVzIHRoZSBzYWZlIE1EWC1zdWJzZXQgcGFyc2VyIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJwYXJzZS9tZHgudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicGFyc2UvbGl0ZXJhbC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpIOKAlCB0aGUgZGV2IHN0YW5kLWluIGZvciB0aGUgcGxhdGZvcm0gRDMgcmVuZGVyZXI7IGl0IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibmV2ZXIgZXZhbHVhdGVzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJmPXtmZXRjaChcXFwiL3hcXFwiKX1cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKGkiBpbmVydCkuIFVuaXQtcmVuZGVyZWQgYWdhaW5zdCBtb2NrIGVuZ2luZSByZXN1bHRzIHZpYSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyZWFjdC1kb20vc2VydmVyXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicmVuZGVyLnRlc3QudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikgKyBwYXJzZXIvY2hhcnQtbWF0aC9mb3JtYXQvc2hhcGUgdGVzdHMuIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiS25vd24gdjEgZ2FwOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBhbiBpbmxpbmUgY29tcG9uZW50IFwifTxfY29tcG9uZW50cy5lbT57XCJ3aXRoaW4gYSBwcm9zZSBsaW5lXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgcGFyc2VzIHRvIHNlcGFyYXRlIGJsb2NrIG5vZGVzIChibG9jay1sZXZlbCBpcyBjb3ZlcmVkKTsgcmVhbCBwb2x5Z29uLWdlb2dyYXBoeSBNYXAgYW5kIEtwaSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcGFya1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYXJlIGRlZmVycmVkIChzZWUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL3JlcG9ydC9yZW5kZXIvaW5kZXgudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKS5cIn08L19jb21wb25lbnRzLnRkPjwvX2NvbXBvbmVudHMudHI+PF9jb21wb25lbnRzLnRyPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuc3Ryb25nPntcImFwcCBpbnRlZ3JhdGlvbiAoQilcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnRkPjxfY29tcG9uZW50cy50ZD48X2NvbXBvbmVudHMuY29kZT57XCJzcmMvYXBwL1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9zZWVkL1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9ob29rcy91c2VSZXBvcnQudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJBcHAudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMudGQ+PF9jb21wb25lbnRzLnRkPntcIlRoZSBydW5uYWJsZSByZXBvcnQuIFwifTxfY29tcG9uZW50cy5jb2RlPntcImJ1aWxkUmVwb3J0U2Vzc2lvblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgbG9hZHMgdGhlIGJ1bmRsZWQgZGVtbyBkb2N1bWVudCAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibG9hZERvY3VtZW50XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBvdmVyIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1lbW9yeVJlYWRlclwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpIOKGkiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJFbmdpbmUuZnJvbVNvdXJjZXNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKGkiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJydW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKGkiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJwYXJzZVRlbXBsYXRlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDihpIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiPFJlcG9ydFZpZXc+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic2Vzc2lvbkJpbmRpbmdzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpcyB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJlbmdpbmXihpJcIn08X2NvbXBvbmVudHMuY29kZT57XCJCaW5kaW5nc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYWRhcHRlclwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoY2VsbCByZXN1bHQgLyBleHRlcm5hbCAvIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1pc3NpbmdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBhbmQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic2V0UGFyYW1cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKGkiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJlbmdpbmUudXBkYXRlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDihpIgcmUtcmVuZGVyKS4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL3NlZWQvXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBpcyB0aGUgcG9ydGFibGUgYnVuZGxlZCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIk1lcmlkaWFuIGRlbW9cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKG5vIFZpdGUgbWFjcm9zKS4gSW50ZWdyYXRpb24tdGVzdGVkIGVuZC10by1lbmQgKFwifTxfY29tcG9uZW50cy5jb2RlPntcInJlcG9ydFNlc3Npb24udGVzdC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpICsgbGl2ZS12ZXJpZmllZCBpbiBhIGJyb3dzZXIuXCJ9PC9fY29tcG9uZW50cy50ZD48L19jb21wb25lbnRzLnRyPjwvX2NvbXBvbmVudHMudGJvZHk+PC9fY29tcG9uZW50cy50YWJsZT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIlM1IGlzIGNsb3NlZCBwb3NpdGl2ZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3Bpa2VzL1M1X1NFU19NT0RVTEVfUkVTT0xVVElPTi5tZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpOiB0aGUgcGxhdGZvcm0gbW9kdWxlLWZldGNoXFxucGF0aCByZXNvbHZlcyBTRVMgKyBDb2RlTWlycm9yIGFuZCBhIHN0YXJ2ZWQgU0VTIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkNvbXBhcnRtZW50XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBydW5zIGluLXBsYXRmb3JtLCBzbyB0aGUgZW5naW5lXFxucmVhbG0gaXMgYnVpbGRhYmxlIGluLXBsYXRmb3JtLiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJFbmdpbmUuZnJvbVNvdXJjZXMoLi4uKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYWxyZWFkeSBwcm92ZXMgdGhlIFNFUy1jb25maW5lZFxcbnBpcGVsaW5lIGluIE5vZGUgd2l0aCB0aGUgcmVhbCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzZXNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHBhY2thZ2UuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5ociAvPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInNlYy0yXCIgZGF0YS1zbHVnPVwiMi13aGF0LXJlbWFpbnMtdGhlLWVmZmVjdGZ1bC1zaGVsbHMtaW4tcmVjb21tZW5kZWQtb3JkZXJcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy0yXCIgLz57XCIyLiBXaGF0IHJlbWFpbnMg4oCUIHRoZSBlZmZlY3RmdWwgc2hlbGxzIChpbiByZWNvbW1lbmRlZCBvcmRlcilcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlRoZSBwdXJlIHNwaW5lLCB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJyZXBvcnQtdmlldyByZW5kZXIgc2hlbGwgKEEsIGRvbmUg4oCUIMKnMSlcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIsIGFuZCB0aGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz48X2NvbXBvbmVudHMuY29kZT57XCJBcHAudHN4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIlxcbmludGVncmF0aW9uICsgYSBydW5uYWJsZSBzdGF0aWMgcmVwb3J0IChCLCBkb25lIOKAlCDCpzEpXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGFyZSBidWlsdC4gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJNMSdzIGV4aXQgZ2F0ZSBpcyBtZXQ6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiXFxudGhlIGJ1bmRsZWQgTWVyaWRpYW4gZGVtbyBkb2N1bWVudCBvcGVucyB3aXRoIHplcm8gcHJvbXB0cyBhbmQgcmVuZGVycyBhIGZ1bGwgcmVwb3J0IChLUElzLFxcbmxpbmUvYmFyL3BpZSBjaGFydHMsIHJlZ2lvbiBtYXAsIGZhY2V0ZWQgcmV0ZW50aW9uLCBzb3J0YWJsZSB0YWJsZSkgZGVza3RvcCArIG1vYmlsZSwgd2l0aCB0aGVcXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlNFUy1jb25maW5lZCBlbmdpbmUgcnVubmluZyBpbi1icm93c2VyXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBsaXZlLXZlcmlmaWVkIHZpYSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ2aXRlIGRldlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKyBoZWFkbGVzcyBDaHJvbWUsIGFuZFxcbnRoZSBmdWxsIGRvY3VtZW504oaSZW5naW5l4oaSYmluZGluZ3PihpJwYXJhbS1yZWNvbXB1dGUgcGlwZWxpbmUgbG9ja2VkIGJ5IFwifTxfY29tcG9uZW50cy5jb2RlPntcInJlcG9ydFNlc3Npb24udGVzdC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIuXFxuQWxsIHRocmVlIHNoZWxscyAoQS9CL0MpIGFyZSBub3cgbWVyZ2VkIHRvIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1haW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLiBFYWNoIHBsdWdzIGludG8gdGhlIGV4aXN0aW5nIHB1cmUgbW9kdWxlcyDigJRcXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImRvIG5vdCByZXdyaXRlIHRoZSBjb3JlOyB3cmFwIGl0LlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIk0yIOKAlCB0aGUgbGl2ZS1mZWVkIHdvcmtzdHJlYW0gKFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9mZWVkL1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpIGlzIHVuZGVyd2F5OyBmb3VyIGluY3JlbWVudHMgbWVyZ2VkIHRvIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1haW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPjwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiRmVlZCBkYXRhLXBsYW5lIGNvcmVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKMKnNS4zLCBQUiAjMTYpIOKAlCBjb250ZW50LWFkZHJlc3NlZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJGcmFtZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCJzLCB0aGUgY29ubmVjdG9yXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiUmV0ZW50aW9uQnVmZmVyXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wia2VlcExhc3RcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcImtlZXBGb3JcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICsgZ2FwIG1hcmtlcnMpLCBrZWVwLWxhdGVzdCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJDb25mbGF0b3JcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChzaGFyZWQgYnkgZmVlZHNcXG5hbmQgcGFyYW0gZHJhZ3MsIMKnNS4zIEY4KSwgYW5kIHRoZSBzdGF0aWMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2hlY2tCdWZmZXJDb3ZlcnNXaW5kb3dzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBjb3ZlcmFnZSBjaGVjay5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkNvbm5lY3RvciBwb3J0ICsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRmVlZFJ1bnRpbWVcIn08L19jb21wb25lbnRzLmNvZGU+PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICjCpzUuMS/CpzUuMi/CpzUuMywgUFIgIzE3KSDigJQgYSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJDb25uZWN0b3JcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGludGVyZmFjZVxcbihcIn08X2NvbXBvbmVudHMuY29kZT57XCJtYW51YWxDb25uZWN0b3JcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGZvciBkZXYvdGVzdHMsIFwifTxfY29tcG9uZW50cy5jb2RlPntcInBvbGxpbmdDb25uZWN0b3JcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG92ZXIgYW4gaW5qZWN0ZWQgZmV0Y2gpIHR5aW5nIGNvbm5lY3RvcnMg4oaSXFxuYnVmZmVycyDihpIgY29uZmxhdGlvbiDihpIgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJjb25mbGF0ZWQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZW5naW5lLnVwZGF0ZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCJzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBzbyBhIGZlZWQgZHJpdmVzIGEgbGl2ZSByZWNvbXB1dGVcXG4oRTJFLXRlc3RlZCBhZ2FpbnN0IHRoZSByZWFsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkFzeW5jRW5naW5lXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZmVlZHMuKlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdGllciBmb2xkcyB0aHJvdWdoKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIkxpdmUgZmVlZCB3aXJlZCBpbnRvIHRoZSBhcHBcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKFBSICMxOCkg4oCUIGEgc3ludGhldGljIGRlbW8gZmVlZCAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2FwcC9kZW1vRmVlZC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpICtcXG5hIFwifTxfY29tcG9uZW50cy5jb2RlPntcImZlZWRzLmxpdmVfcmVnaW9uc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgY2VsbCArIGEgXFxcIkxpdmUgYWN0aXZpdHlcXFwiIGNoYXJ0OyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ1c2VSZXBvcnRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHJ1bnMgYSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJGZWVkUnVudGltZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgb3ZlciB0aGVcXG5zZXNzaW9uIGVuZ2luZSAockFGIGZsdXNoIGNhZGVuY2UpIGFuZCByZS1yZW5kZXJzIG9uIGVhY2ggc2V0dGxlZCByZWNvbXB1dGUuIExpdmUtdmVyaWZpZWQgaW4gYVxcbnJlYWwgYnJvd3NlciBvdmVyIENEUCAodGhlIGNoYXJ0IHBvcHVsYXRlcyBhbmQgaXRzIHZhbHVlcyBjaGFuZ2Ugb3ZlciB0aW1lKS4gXCJ9PF9jb21wb25lbnRzLmVtPntcIihSZW1vdmVkIGJ5IFIzLTc2OCDigJRcXG50aGUgYXBwLXN1cHBsaWVkIGRlbW8gZmVlZCB3YXMgcmVwb3J0LXZpZXcgZWdyZXNzLCBub3QgZG9jdW1lbnQgY29udGVudDsgYSBsaXZlLXJlZ2lvbiBmZWVkXFxucmV0dXJucyBpbiBSMy03NjkgYXMgYSBkZWNsYXJlZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmZWVkcy8qLmZlZWQuanNvblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIuKVwifTwvX2NvbXBvbmVudHMuZW0+PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJHbGl0Y2gtZnJlZWRvbSBwcm92ZW5cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKMKnNC4yIEMtUi1CLCBQUiAjMTkpIOKAlCBzZWUgwqc1OyB0aGUgY29tbW9uLWVwb2NoIGJhcnJpZXIgaXMgcmVzb2x2ZWRcXG4oc2F0aXNmaWVkIGJ5IGNvbnN0cnVjdGlvbiksIG5vdCBhIHBlbmRpbmcgaXRlbS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIldpbmRvd2VkLWZlZWQgaW5wdXQgcmVzb2x1dGlvblwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wieyBmZWVkLCB3aW5kb3cgfVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYXQgdGhlIGlucHV0IHNpdGUgbm93IHJlc29sdmVzIHRocm91Z2hcXG50aGUgZW5naW5lJ3Mgc2hhcmVkIGlucHV0IHJlc29sdmVyOiB0aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRmVlZFJ1bnRpbWVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHB1Ymxpc2hlcyBlYWNoIGZlZWQncyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInJldGFpbmVkIHJvd3NcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCJcXG4oXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZmVlZEJ1ZmZlcnMuPG5hbWU+XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikgYWxvbmdzaWRlIHRoZSBzbmFwc2hvdCwgdGhlIGdyYXBoIHJvdXRlcyB0aGUgb2JqZWN0IGZvcm0gdG8gYVxcblwifTxfY29tcG9uZW50cy5jb2RlPntcIndpbmRvd2VkLWZlZWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHJlc29sdmVyIChhbHNvIGtleWVkIG9uIFwifTxfY29tcG9uZW50cy5jb2RlPntcInBhcmFtcy5ub3dcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBzbyBhIGNsb2NrLW9ubHkgdXBkYXRlIGFkdmFuY2VzIHRoZVxcbndpbmRvdyksIGFuZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyZXNvbHZlSW5wdXRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhcHBsaWVzIFwifTxfY29tcG9uZW50cy5jb2RlPntcIndpbmRvdygpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB3aXRoIHRoZSBkZWNpZGVkIGNvbnZlbnRpb25zIOKAlCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJieVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZGVmYXVsdHMgdG9cXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJ0c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCI7IFwifTxfY29tcG9uZW50cy5jb2RlPntcIm5vd1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgPSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJwYXJhbXMubm93XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB3aGVuIHN1cHBsaWVkLCBlbHNlIHRoZSBuZXdlc3QgcmV0YWluZWQgZXZlbnQgdGltZTsgdW5wbGFjZWFibGUgcm93c1xcbmRyb3Agb3V0OyByZXNvbHV0aW9uIG5ldmVyIHRocm93cyAocmVjb3JkZWQgaW4gQVJDSElURUNUVVJFX1BMQU4gwqczKS4gVGhlIHN0YXRpY1xcbmJ1ZmZlci1jb3ZlcmFnZSBjaGVjayBjb21wb3NlcyB2aWEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZGVjbGFyZWRXaW5kb3dzKGdyYXBoKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGFuZCB0aGUgZGVtbyBmZWVkIGNhcnJpZXMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICtcXG5hIDMwcyB3aW5kb3dlZCBjZWxsIGxpdmUgaW4gdGhlIHJlcG9ydC4gRTJFLXRlc3RlZCBhZ2FpbnN0IHRoZSByZWFsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkFzeW5jRW5naW5lXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJHZW51aW5lbHktcmVtYWluaW5nIGZlZWQgaW5jcmVtZW50czpcIn08L19jb21wb25lbnRzLnN0cm9uZz48L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlRoZSByZWFsIGhvc3QtcHJveGllZCBjb25uZWN0b3JcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKMKnNS4xIOKAlCB0aGUgU1NSRi1ib3VuZGVkIGZldGNoIGNhcGFiaWxpdHkpICsgdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiT1BGU1xcbm1hdGVyaWFsaXplLXRvLW1vdW50IHRyYW5zcG9ydFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAowqc1LjIpLiBcIn08X2NvbXBvbmVudHMuZW0+e1wiUGxhdGZvcm0tYmxvY2tlZDpcIn08L19jb21wb25lbnRzLmVtPntcIiBib3RoIG5lZWQgaG9zdCBzZXJ2aWNlcyBub3QgcHJlc2VudFxcbmluIHRoZSBzdGFuZGFsb25lIHJlY2tvbmVyIHJlcG87IHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJDb25uZWN0b3JcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL3RyYW5zcG9ydCBwb3J0cyBhcmUgdGhlIHNlYW1zIHRoZXkgc2xvdCBpbnRvLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJTZWUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2ZlZWQvaW5kZXgudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGZvciB0aGUgc2NvcGUgbWFwLlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMuaDMgaWQ9XCJhLXJlcG9ydC12aWV3LXJlYWN0LWNvbXBvbmVudHMtbWR4bm9kZS1wYXJzZS1kb25lLXNyY3JlcG9ydHJlbmRlci1zcmNyZXBvcnRwYXJzZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwiYS1yZXBvcnQtdmlldy1yZWFjdC1jb21wb25lbnRzLW1keG5vZGUtcGFyc2UtZG9uZS1zcmNyZXBvcnRyZW5kZXItc3JjcmVwb3J0cGFyc2VcIiAvPntcIkEuIFJlcG9ydC12aWV3IFJlYWN0IGNvbXBvbmVudHMgKyBNRFjihpJub2RlIHBhcnNlIOKAlCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIkRPTkVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9yZXBvcnQvcmVuZGVyXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL3JlcG9ydC9wYXJzZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpXCJ9PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJTaGlwcGVkIGluIGl0cyBvd24gUFIuIFwifTxfY29tcG9uZW50cy5jb2RlPntcIlJlcG9ydFZpZXdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICsgb25lIGNvbXBvbmVudCBwZXIgY2F0YWxvZyBlbnRyeSArIHRoZSBzYWZlIE1EWC1zdWJzZXRcXG5wYXJzZXIsIHVuaXQtcmVuZGVyZWQgYWdhaW5zdCBtb2NrIGVuZ2luZSByZXN1bHRzLiBUaGUgbG9hZC1iZWFyaW5nIHNlYW0gc2hlbGwgQiBjb25zdW1lczogdGhlXFxuaW5qZWN0ZWQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz48X2NvbXBvbmVudHMuY29kZT57XCJCaW5kaW5nc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcG9ydFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL3JlcG9ydC9yZW5kZXIvYmluZGluZ3MudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSDigJQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicmVzb2x2ZShzb3VyY2UpIOKGkiB7dmFsdWUsIHRpZXIsIHN0YXR1c31cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFuZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzZXRQYXJhbShuYW1lLCB2YWx1ZSlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLiBTaGVsbCBCIHN1cHBsaWVzIGEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQmluZGluZ3NcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGFkYXB0ZXIgb3ZlciB0aGUgZW5naW5lJ3NcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJQYXNzUmVzdWx0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiArIFwifTxfY29tcG9uZW50cy5jb2RlPntcInBhcmFtc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZXh0ZXJuYWxzOyB0aGUgcmVuZGVyZXIgbmVlZHMgbm8gb3RoZXIgZW5naW5lIGtub3dsZWRnZS4gRGVmZXJyZWRcXG5lbnJpY2htZW50cyBhcmUgbGlzdGVkIGluIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9yZXBvcnQvcmVuZGVyL2luZGV4LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoaG9zdCB0aWVyIGJhZGdlIGlzIGEgcmVzZXJ2ZWQgc2xvdDsgcmVhbFxcbnBvbHlnb24gTWFwOyBLcGkgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3BhcmtcIn08L19jb21wb25lbnRzLmNvZGU+e1wiOyBmdWxsIGlubGluZS1NRFggPSB0aGUgcGxhdGZvcm0gRDMgcmVuZGVyZXIncyByZW1pdCkuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cImItYXBwdHN4LWludGVncmF0aW9uLWEtcnVubmFibGUtc3RhdGljLXJlcG9ydC1kb25lLXNyY2FwcC1zcmNzZWVkLXNyY2hvb2tzdXNlcmVwb3J0dHNcIj48SGVhZGluZ0FuY2hvciBpZD1cImItYXBwdHN4LWludGVncmF0aW9uLWEtcnVubmFibGUtc3RhdGljLXJlcG9ydC1kb25lLXNyY2FwcC1zcmNzZWVkLXNyY2hvb2tzdXNlcmVwb3J0dHNcIiAvPntcIkIuIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkFwcC50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGludGVncmF0aW9uIOKAlCBhIHJ1bm5hYmxlIHN0YXRpYyByZXBvcnQg4oCUIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiRE9ORVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2FwcFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9zZWVkXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2hvb2tzL3VzZVJlcG9ydC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpXCJ9PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJTaGlwcGVkIChzdGFja2VkIG9uIHNoZWxsIEEncyBQUikuIFRoZSBwaXBlbGluZTogXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQXBwLnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oaSIFwifTxfY29tcG9uZW50cy5jb2RlPntcInVzZVJlcG9ydFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oaSIFwifTxfY29tcG9uZW50cy5jb2RlPntcImJ1aWxkUmVwb3J0U2Vzc2lvblwifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG4oXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2FwcC9yZXBvcnRTZXNzaW9uLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikgbG9hZHMgdGhlIGJ1bmRsZWQgZGVtbyBkb2N1bWVudCB2aWEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibG9hZERvY3VtZW50XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBvdmVyIGFuIGluLW1lbW9yeVxcbnJlYWRlciAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2FwcC9tZW1vcnlSZWFkZXIudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSDihpIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRW5naW5lLmZyb21Tb3VyY2VzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDihpIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZW5naW5lLnJ1bihleHRlcm5hbHMpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDihpIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicGFyc2VUZW1wbGF0ZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG7ihpIgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiPFJlcG9ydFZpZXcgbm9kZXMgYmluZGluZ3MgLz5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLiBUaGUgb25lIG5ldyBpbnRlZ3JhdGlvbiBwaWVjZSBpcyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzZXNzaW9uQmluZGluZ3NcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCB0aGVcXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPjxfY29tcG9uZW50cy5jb2RlPntcIkJpbmRpbmdzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhZGFwdGVyIG92ZXIgdGhlIGVuZ2luZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIjogXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicmVzb2x2ZShzb3VyY2UpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiByZXR1cm5zIHRoZSBzY2hlZHVsZXIncyBwdWJsaXNoZWRcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJ7dmFsdWUsIHRpZXJ9XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBmb3IgYSBjZWxsIChvciB0aGUgZXh0ZXJuYWwgZm9yIGEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZml4dHVyZXMuKlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicGFyYW1zLipcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG5hbWUsIG9yIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1pc3NpbmdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcImVycm9yXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIik7XFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic2V0UGFyYW0obmFtZSwgdmFsdWUpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB3cml0ZXMgdGhlIHBhcmFtLCBjYWxscyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJlbmdpbmUudXBkYXRlKC4uLilcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBhbmQgYnVtcHMgYSByZS1yZW5kZXIgdGljay5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcIlRoZSBkZW1vIGRvY3VtZW50XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGlzIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9zZWVkL1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIg4oCUIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJwb3J0YWJsZSwgYnVuZGxlZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBNZXJpZGlhbiBtb250aGx5IHJldmlld1xcbihcIn08X2NvbXBvbmVudHMuY29kZT57XCJkb2N1bWVudC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgPSBtYW5pZmVzdCArIGEgcGxhaW4tSlMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicmV2aWV3LnNoZWV0LmpzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiB3b3Jrc2hlZXQgKyB0aGUgTURYIHRlbXBsYXRlICsgZnJvemVuXFxuZml4dHVyZXM7IFwifTxfY29tcG9uZW50cy5jb2RlPntcImRhdGEudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiID0gcmVhbCBNZXJpZGlhbiBmaWd1cmVzIHNsaWNlZCB0byB0aGUgbGFzdCAxMiBtb250aHMsIHJlZ2VuZXJhYmxlIHZpYVxcblwifTxfY29tcG9uZW50cy5jb2RlPntcInNjcmF0Y2hwYWQvZ2VuLXNlZWQubWpzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBmcm9tIFwifTxfY29tcG9uZW50cy5jb2RlPntcImRvY3MvY2FzZS1zdHVkeS9tZXJpZGlhbi9kYXRhLyouY3N2XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikuIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiTm8gVml0ZS1vbmx5IG1hY3Jvc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIlxcbihcIn08X2NvbXBvbmVudHMuY29kZT57XCI/cmF3XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJpbXBvcnQubWV0YS5nbG9iXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikg4oCUIHRob3NlIGJyZWFrIG9uIGltbWVkaWF0ZWx5LnJ1bjsgdGhlIGZpbGVzIGFyZSBzdHJpbmcvb2JqZWN0XFxuY29uc3RhbnRzIHNvIHRoZSBzYW1lIGNvZGUgcnVucyBvbiBib3RoLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiTm90IHlldCB3aXJlZDpcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgbG9hZGluZyBhIGRvY3VtZW50IGZyb20gYSBcIn08X2NvbXBvbmVudHMuZW0+e1widXNlci1ncmFudGVkIG1vdW50XCJ9PC9fY29tcG9uZW50cy5lbT57XCIgKG5lZWRzIG1vdW50IGNvbnNlbnQg4oCUIE0yKTtcXG50aGUgYXBwIHNoaXBzIHRoZSBidW5kbGVkIHNlZWQgc28gaXQgcmVuZGVycyB3aXRoIHplcm8gcHJvbXB0cy4gQSByZWFsIGZzLWJhY2tlZCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJEb2N1bWVudFJlYWRlclwifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG5vdmVyIHRoZSBwbGF0Zm9ybSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJmc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIvbG9jYWwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZGV2LWZzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBzbG90cyBpbiB3aGVyZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJtZW1vcnlSZWFkZXJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGlzIHRvZGF5LlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiTGl2ZS12ZXJpZmllZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBhdCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ2aXRlIGRldlwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKGhlYWRsZXNzIENocm9tZSwgZGVza3RvcCArIDM5MHB4KTogdGhlIFNFUyBlbmdpbmUgcnVuc1xcbmluLWJyb3dzZXIsIGFsbCBjYXRhbG9nIGNvbXBvbmVudHMgcmVuZGVyLCB0aGUgc3BhbiB3aWRnZXQgcmVjb21wdXRlcy4gaW1tZWRpYXRlbHkucnVuXFxubG9jYWwtcHJvdmlkZXIgdmVyaWZpY2F0aW9uICh0aGUgcGxhdGZvcm0gc2FuZGJveCBwYXRoKSBpcyB0aGUgcmVtYWluaW5nIGxpdmUgY2hlY2sg4oCUIFM1IGFscmVhZHlcXG5wcm92ZWQgU0VTIHJlc29sdmVzICsgcnVucyBpbi1wbGF0Zm9ybSwgc28gdGhpcyBpcyBleHBlY3RlZC1ncmVlbiwgbm90IGRlLXJpc2tpbmcuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5oMyBpZD1cImMtZW5naW5lLXdvcmtlci13aXJpbmctZG9uZS13aXJlZC1pbnRvLXRoZS1hcHAtc3JjZW5naW5ld29ya2VyLXNyY2VuZ2luZWFzeW5jZW5naW5ldHMtc3JjZW50cnllbmdpbmV0c1wiPjxIZWFkaW5nQW5jaG9yIGlkPVwiYy1lbmdpbmUtd29ya2VyLXdpcmluZy1kb25lLXdpcmVkLWludG8tdGhlLWFwcC1zcmNlbmdpbmV3b3JrZXItc3JjZW5naW5lYXN5bmNlbmdpbmV0cy1zcmNlbnRyeWVuZ2luZXRzXCIgLz57XCJDLiBFbmdpbmUgd29ya2VyIHdpcmluZyDigJQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJET05FICsgd2lyZWQgaW50byB0aGUgYXBwXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvZW5naW5lL3dvcmtlci9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvZW5naW5lL2FzeW5jRW5naW5lLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2VudHJ5L2VuZ2luZS50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpXCJ9PC9fY29tcG9uZW50cy5oMz57XCJcXG5cIn08X2NvbXBvbmVudHMucD57XCJUaGUgZXhlY3V0b3IgcmVhbG0gaXMgYnVpbHQgYW5kIHRlc3RlZC4gVGhlIHdvcmtlciAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wid29ya2VyL2VuZ2luZVdvcmtlci50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKyB0aGUgcmVhbFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcImVudHJ5L2VuZ2luZS50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdGhhdCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJsb2NrZG93bigpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcInMgYW5kIHNlcnZlcyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJidWlsZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZXZhbFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgb3ZlciBcIn08X2NvbXBvbmVudHMuY29kZT57XCJwb3N0TWVzc2FnZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIpIGlzIGFcXG50ZXJtaW5hYmxlIGZvcm11bGEgZXhlY3V0b3I7IHRoZSBob3N0IFwifTxfY29tcG9uZW50cy5jb2RlPntcIkFzeW5jRW5naW5lXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBvd25zIGFsbCBzY2hlZHVsaW5nICsgZXBvY2gvYnJlYWtlciBzdGF0ZVxcbijCpzQuMSkgYW5kIGRyaXZlcyBpdCBvdmVyIGEgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiV29ya2VyVHJhbnNwb3J0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBwb3J0IChyZWFsIFdlYiBXb3JrZXIgb3IgYW4gaW4tcHJvY2VzcyBkb3VibGUpLlxcbkRlbGl2ZXJlZCBhc3luYyBpbnZhcmlhbnRzOlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiV2F0Y2hkb2cgY2lyY3VpdCBicmVha2VyXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICjCpzQuMSkg4oCUIGEgcGVyLWV2YWwgd2FsbC1jbG9jayBidWRnZXQ7IGV4Y2VlZGluZyBpdCBpcyBhIGhhcmRcXG5ydW5hd2F5IOKGkiB0aGUgd29ya2VyIGlzIFwifTxfY29tcG9uZW50cy5jb2RlPntcInRlcm1pbmF0ZSgpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcImQgKyByZWJ1aWx0IGFuZCB0aGUgcHVyZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJDaXJjdWl0QnJlYWtlclwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgY291bnRzIGl0O1xcbmFmdGVyIFwifTxfY29tcG9uZW50cy5jb2RlPntcImhhcmRMaW1pdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgdGhlIGNlbGwgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJxdWFyYW50aW5lc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBhbmQgZGVwZW5kZW50cyByZXNvbHZlIHRvIHRoZSBwcm9wYWdhdGVkIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wibGF0dGljZVxcbmVycm9yXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChhIHJlLWFybSByZWNvdmVycykuIFNvZnQgYnVkZ2V0LWV4Y2VlZCA9IGNvbmZpcm0tYmVmb3JlLXN0aWNrICsgVFRMIGRlY2F5LiBUaGlzIGlzXFxudGhlIGF2YWlsYWJpbGl0eSBwcm90ZWN0aW9uIFNFUyBjYW5ub3QgZ2l2ZSAoUlEtQTQgcmVzaWR1YWwpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiU2luZ2xlLXNsb3QgcnVuLXRvLWNvbXBsZXRpb24gc3VwZXJzZXNzaW9uXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBvdmVybGFwcGluZyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ1cGRhdGUoKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCJzIG5ldmVyIGNhbmNlbCBhblxcbmluLWZsaWdodCBwYXNzOyB0aGV5IGNvYWxlc2NlIHRvIG9uZSBmb2xsb3ctdXAgd2l0aCB0aGUgbGF0ZXN0IGV4dGVybmFscyAobm8gY2FuY2VsLXJlc3RhcnRcXG5saXZlbG9jaykuIEFzeW5jIGZvcm11bGFzIChhIGZvcm11bGEgbWF5IHJldHVybiBhIHByb21pc2UpIGFyZSBhd2FpdGVkLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPntcIlNoYXJlZCBpbnB1dCByZXNvbHV0aW9uIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJyZXNvbHZlLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIikg4oCUIG9uZSBwYXRoIHdpdGggdGhlIHN5bmMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiU2NoZWR1bGVyXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAocmVmYWN0b3JlZCB0b1xcbnVzZSBpdCksIHRpZXIgZm9sZCArIFwifTxfY29tcG9uZW50cy5jb2RlPntcIih2YWx1ZSx0aWVyKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcHVibGlzaCwgY3ljbGXihpJlcnJvci1ldmVyeS1jZWxsLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkdsaXRjaC1mcmVlZG9tICjCpzQuMiBDLVItQikgaXMgc2F0aXNmaWVkIGJ5IGNvbnN0cnVjdGlvbiwgYW5kIG5vdyBQUk9WRU4uXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFRoZSBzZXJpYWxcXG5zaW5nbGUtY29udGV4dCBlbmdpbmUgKHNlcXVlbnRpYWwgdG9wbyBldmFsIG92ZXIgb25lIGV4dGVybmFscyBzbmFwc2hvdCArIHNlcmlhbGl6ZWQgcGFzc2VzKVxcbmNhbm5vdCBhc3NlbWJsZSBhIGNlbGwgZnJvbSB0d28gZXBvY2hzIGV2ZW4gb24gYW4gYXN5bW1ldHJpYyBkaWFtb25kIHVuZGVyIGEgY29udGludW91cyBmZWVkIOKAlFxcblwifTxfY29tcG9uZW50cy5jb2RlPntcImFzeW5jRW5naW5lLmdsaXRjaC50ZXN0LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoc3BlYyDCpzExIEUtMjogcHJvcGVydHkgdGVzdCBvdmVyIHJhbmRvbSBEQUdzICsgYnVyc3R5IHVwZGF0ZXMsXFxud2F0Y2hpbmcgZXZlcnkgc2V0dGxlZCBwYXNzIHZpYSB0aGUgbmV3IFwifTxfY29tcG9uZW50cy5jb2RlPntcIm9uUGFzc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaG9vaykgZGVtb25zdHJhdGVzIGl0LiBUaGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJleHBsaWNpdCBwZXItY2VsbFxcbmVwb2NoLWdhdGUgYmFycmllciBiZWNvbWVzIG5lY2Vzc2FyeSBvbmx5IGlmIGNvbmN1cnJlbnQgYXJtIGV2YWx1YXRpb24gaXMgaW50cm9kdWNlZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAodGhlXFxuZGVmZXJyZWQgd29ya2VyLXBvb2wgcGFydGl0aW9uaW5nLCDCpzQuMSkg4oCUIHRoZSBzaW5nbGUtY29udGV4dCBlbmdpbmUgZG9lcyBub3QgbmVlZCBpdDsgdGhhdCB3YXNcXG50aGUgY29ycmVjdGlvbiBmcm9tIHRyZWF0aW5nIGl0IGFzIGFuIHVuYnVpbHQgZ2FwLiBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIkFsc28gcmVtYWluaW5nOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiB3aXJpbmcgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQXN5bmNFbmdpbmVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGludG8gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQXBwLnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaW4gcGxhY2VcXG5vZiB0aGUgc3luYyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJFbmdpbmVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChzbyBldmVuIHRoZSBzdGF0aWMgcmVuZGVyIHJ1bnMgb2ZmLW1haW4tdGhyZWFkIHdpdGggd2F0Y2hkb2cgcHJvdGVjdGlvbiksXFxuYW5kIHRoZSByZWFsLVwifTxfY29tcG9uZW50cy5jb2RlPntcIldvcmtlclwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgRTJFIGluIGEgYnJvd3NlciAodGhlIFwifTxfY29tcG9uZW50cy5jb2RlPntcImVudHJ5L2VuZ2luZS50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgc2hpbSArIFwifTxfY29tcG9uZW50cy5jb2RlPntcImxvY2tkb3duKClcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIOKAlCB0aGluLCBhbmRcXG5TNSBhbHJlYWR5IHByb3ZlZCBTRVMgcmVzb2x2ZXMgKyBydW5zIGluLXBsYXRmb3JtKS4gVmVyaWZpZWQgYnkgdGhlIGVuZ2luZSB0ZXN0IHN1aXRlXFxuKHN5bmMtZXF1aXZhbGVuY2UsIGVycm9yIHByb3BhZ2F0aW9uLCBjeWNsZXMsIHdhdGNoZG9n4oaScXVhcmFudGluZeKGknJlY292ZXIsIHN1cGVyc2Vzc2lvbikuXCJ9PC9fY29tcG9uZW50cy5wPntcIlxcblwifTxfY29tcG9uZW50cy5ociAvPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInNlYy0zXCIgZGF0YS1zbHVnPVwiMy13b3JraW5nLWNvbnZlbnRpb25zLWhvbm9yLXRoZXNlXCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtM1wiIC8+e1wiMy4gV29ya2luZyBjb252ZW50aW9ucyAoaG9ub3IgdGhlc2UpXCJ9PC9fY29tcG9uZW50cy5oMj57XCJcXG5cIn08X2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiUHJvdG9jb2w6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJuZXh0LXJvYWRtYXAtaXRlbVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgc2tpbGwncyBmbG93LiBFYWNoIGNvZGUgY2hhbmdlIGluIGEgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJkZWRpY2F0ZWQgZ2l0XFxud29ya3RyZWVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgb2ZmIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm9yaWdpbi9tYWluXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAob3Igc3RhY2tlZCBvbiBhbiBvcGVuIGJyYW5jaCksIGEgUFIgcGVyIHJlcG8sIHZlcmlmaWVkIGFnYWluc3RcXG50aGUgZXhpdCBjcml0ZXJpYSwgd29ya3RyZWUgcmVtb3ZlZCBhZnRlciB0aGUgUFIgaXMgdXAuIFJlY2tvbmVyIGlzIGEgbm9ybWFsIHJlcG8gKFBScyk7XFxub25seSB0aGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZG9jc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcmVwbyBjb21taXRzIGRpcmVjdGx5IHRvIFwifTxfY29tcG9uZW50cy5jb2RlPntcIm1haW5cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVmVyaWZ5IGdhdGUgKHJ1biBiZWZvcmUgZXZlcnkgUFIpOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJucHggdHNjIC1iXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDCtyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJucG0gdGVzdFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKHZpdGVzdCkgwrcgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibnBtIHJ1biBsaW50XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIlxcbih0aGUgRmFzdC1SZWZyZXNoIHJ1bGUpIMK3IFwifTxfY29tcG9uZW50cy5jb2RlPntcIm5wbSBydW4gYnVpbGRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLiBBbGwgbXVzdCBiZSBncmVlbi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcInRzY29uZmlnIGNvbnN0cmFpbnRzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiICh0aGV5IGJpdGUpOiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJlcmFzYWJsZVN5bnRheE9ubHlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChubyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJlbnVtXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi9cIn08X2NvbXBvbmVudHMuY29kZT57XCJuYW1lc3BhY2VcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL3BhcmFtZXRlclxcbnByb3BlcnRpZXMg4oCUIHVzZSB1bmlvbiBsaXRlcmFscyArIGV4cGxpY2l0IGZpZWxkcyksIFwifTxfY29tcG9uZW50cy5jb2RlPntcInZlcmJhdGltTW9kdWxlU3ludGF4XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW1wb3J0IHR5cGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGZvclxcbnR5cGVzKSwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibm9VbnVzZWRMb2NhbHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL1wifTxfY29tcG9uZW50cy5jb2RlPntcIm5vVW51c2VkUGFyYW1ldGVyc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGFuZCB0c2VzbGludCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJuby1leHBsaWNpdC1hbnlcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICh1c2UgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widW5rbm93blwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiVmFsdWVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiL2dlbmVyaWNzKS4gSW1wb3J0cyB1c2UgZXhwbGljaXQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBleHRlbnNpb25zIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJhbGxvd0ltcG9ydGluZ1RzRXh0ZW5zaW9uc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiVGhlIGxvYWQtYmVhcmluZyBkZXNpZ24gcHJpbmNpcGxlOlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBcIn08X2NvbXBvbmVudHMuZW0+e1wic2VwYXJhdGUgcHVyZSBsb2dpYyBmcm9tIHRoZSBlZmZlY3RmdWwgY29sbGFib3JhdG9yLFxcbmFuZCBpbmplY3QgdGhlIGNvbGxhYm9yYXRvciBhcyBhIHBvcnQuXCJ9PC9fY29tcG9uZW50cy5lbT57XCIgVGhlIHdob2xlIHNwaW5lIGlzIG9mZmxpbmUtdGVzdGFibGUgYmVjYXVzZSB0aGVcXG5lZmZlY3RmdWwgYml0cyBhcmUgcG9ydHM6IHRoZSBzY2hlZHVsZXIncyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJFdmFsdWF0b3JcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCB0aGUgdGVzdCBydW5uZXIncyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJyZWV2YWx1YXRlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgdGhlXFxuZG9jdW1lbnQgbG9hZGVyJ3MgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRG9jdW1lbnRSZWFkZXJcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCB0aGUgZW5naW5lJ3MgU0VTIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkNvbXBhcnRtZW50XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIi4gS2VlcCB0aGlzIOKAlCBhIG5ldyBzaGVsbFxcbnNob3VsZCBleHBvc2UgaXRzIGVmZmVjdCBhcyBhbiBpbmplY3RlZCBwb3J0IHNvIGl0cyBsb2dpYyBzdGF5cyB1bml0LXRlc3RhYmxlLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiTmV3IGZvcm11bGEtZmFjaW5nIGNhbGxhYmxlIOKGkiBhZGQgYSBzZWxmLWRlc2NyaXB0aW9uXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHRvIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9zdGRsaWIvY2F0YWxvZy50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIuIFRoZVxcblwifTxfY29tcG9uZW50cy5jb2RlPntcImNhdGFsb2cudGVzdC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgZ2F0ZSBmYWlscyBpZiBhbiBleHBvcnRlZCBjYWxsYWJsZSBpcyB1bmRlc2NyaWJlZCAob3IgYSBkZXNjcmlwdGlvbiBvcnBoYW5lZCkuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+PF9jb21wb25lbnRzLnN0cm9uZz57XCJDTEFVREUubWRcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHJlcG8gcm9vdCkgaXMgdGhlIGFwcC1hdXRob3JpbmcgY29udHJhY3QgKGVudHJ5IGlzIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkFwcC50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiJ3MgZGVmYXVsdCBleHBvcnQ7XFxuYSBjb21wb25lbnQgZmlsZSBleHBvcnRzIG9ubHkgY29tcG9uZW50czsgZGVsZWdhdGUgZWRpdGluZyB0byB0aGUgcGxhdGZvcm0gZWRpdG9yOyBldGMuKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmhyIC8+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTRcIiBkYXRhLXNsdWc9XCI0LWVudmlyb25tZW50XCI+PEhlYWRpbmdBbmNob3IgaWQ9XCJzZWMtNFwiIC8+e1wiNC4gRW52aXJvbm1lbnRcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy51bD57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJUaGUgcGxhdGZvcm0gbGl2ZS1jaGVjayBpcyBhIGdhdGUsIG5vdCBhbiBleHBlY3RhdGlvbiAobGVhcm5lZCAyMDI2LTA4LTI0LCB0aGUgaGFyZFxcbndheSk6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIHRoZSBkZW1vIGZpcnN0IHJhbiBvbiBwcm9kdWN0aW9uIGltbWVkaWF0ZWx5LnJ1biBvbmx5IGFmdGVyIE0yIOKAlCBhbmQgZGllZCB3aXRoXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQ2Fubm90IHVzZSAnaW1wb3J0Lm1ldGEnIG91dHNpZGUgYSBtb2R1bGVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLiBUaGUgcGxhdGZvcm0gdHJhbnNwaWxlcyBhcHAgc291cmNlIEVTTeKGkkNKU1xcbmFuZCBldmFsdWF0ZXMgaXQgYXMgYSBjbGFzc2ljIHNjcmlwdCwgd2hlcmUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW1wb3J0Lm1ldGFcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGlzIGEgcGFyc2UtdGltZSBTeW50YXhFcnJvclxcbnRoYXQga2lsbHMgdGhlIHdob2xlIG1vZHVsZSAoYSBjbGFpbSB0aGF0IHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJuZXcgVVJMKC4uLiwgaW1wb3J0Lm1ldGEudXJsKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgV29ya2VyIGZvcm1cXG5cXFwid29ya3Mgb24gdml0ZSBhbmQgaW1tZWRpYXRlbHkucnVuIGFsaWtlXFxcIiBoYWQgYXNzZXJ0ZWQsIG5ldmVyIHZlcmlmaWVkKS4gRml4ZXM6IHRoZVxcbndvcmtlciBVUkwgbGl2ZXMgaW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2FwcC93b3JrZXJVcmwudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCByZWFjaGVkIG9ubHkgdmlhIGR5bmFtaWMgaW1wb3J0IGluc2lkZVxcblwifTxfY29tcG9uZW50cy5jb2RlPntcIm1ha2VUcmFuc3BvcnRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiJ3MgdHJ5L2NhdGNoIOKAlCBvbiB0aGUgcGxhdGZvcm0gdGhlIGZhaWx1cmUgaXMgY2F0Y2hhYmxlIGFuZCB0aGUgaW4tcHJvY2Vzc1xcbmVuZ2luZSB0cmFuc3BvcnQgdGFrZXMgb3ZlcjsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2FwcC9wbGF0Zm9ybUd1YXJkcy50ZXN0LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBncmVlcHMgdGhlIHNvdXJjZSBmb3IgdGhlXFxuY2xhc3MgKGNvbW1lbnQtYXdhcmUsIHR3byBleGVtcHQgZmlsZXMpIHNvIGl0IGNhbm5vdCBzaWxlbnRseSByZXR1cm4uIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiVmVyaWZ5IG9uXFxuXCJ9PF9jb21wb25lbnRzLmEgaHJlZj1cImh0dHBzOi8vaW1tZWRpYXRlbHkucnVuL3ByZXNlbnQvZ2l0aHViL2ltbWVkaWF0ZWx5LXJ1bi9yZWNrb25lci9tYWluXCI+e1wiaHR0cHM6Ly9pbW1lZGlhdGVseS5ydW4vcHJlc2VudC9naXRodWIvaW1tZWRpYXRlbHktcnVuL3JlY2tvbmVyL21haW5cIn08L19jb21wb25lbnRzLmE+e1wiIGJlZm9yZSBjYWxsaW5nIGFueVxcbnNoZWxsIFxcXCJkb25lXFxcIlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgdml0ZS1vbmx5IHZlcmlmaWNhdGlvbiBpcyBleGFjdGx5IHRoZSB0cmFwIHRoZSBhcHAgQ0xBVURFLm1kIHdhcm5zIGFib3V0LlwifTwvX2NvbXBvbmVudHMucD57XCJcXG5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMucD48X2NvbXBvbmVudHMuc3Ryb25nPntcIkJyaW5nIHRoZSBsb2NhbCBzdGFjayB1cCB3aGVuIFwifTxfY29tcG9uZW50cy5jb2RlPntcImxvY2FsLmltbWVkaWF0ZWx5LnJ1blwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgNTAyc1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgc2VlIHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJsb2NhbC1zdGFjay1icmluZ3VwXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIlxcbm1lbW9yeSAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiZG9jcy8uY2xhdWRlL21lbW9yeS9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGluIHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJkb2NzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiByZXBvKSBhbmQgdGhlIFM1IHNwaWtlJ3MgcmVwcm9kdWNlIHNlY3Rpb246XFxubmdpbngg4oaSIFwifTxfY29tcG9uZW50cy5jb2RlPntcIjozMDAwXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBzaXRlLW1haW4gKFwifTxfY29tcG9uZW50cy5jb2RlPntcIkJST1dTRVI9bm9uZSBucG0gc3RhcnRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiOjEyMzRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHNhbmRib3hcXG4oXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibnB4IHBhcmNlbCAuL3NyYy9pbmRleC5odG1sIC0tcG9ydCAxMjM0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiwgYnlwYXNzaW5nIHRoZSBzdGFsZS1cIn08X2NvbXBvbmVudHMuY29kZT57XCJkaXN0L1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcHJlZGV2IGd1YXJkKSwgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiOjQwMDBcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxuYmFja2VuZCAocm9vdCA0MDQgaXMgbm9ybWFsKS5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJDaHJvbWUgRGV2VG9vbHMgTUNQXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGlzIHRoZSBpbnRlbmRlZCBsaXZlLWRlYnVnIHRvb2wuIElmIGl0IGlzIGRvd24sIGRyaXZlIHRoZSBob3N0IGhlYWRsZXNzXFxud2l0aCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPjxfY29tcG9uZW50cy5jb2RlPntcInB1cHBldGVlci1jb3JlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDihpIgc3lzdGVtIENocm9tZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYWNjZXB0SW5zZWN1cmVDZXJ0c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKyBcIn08X2NvbXBvbmVudHMuY29kZT57XCItLWlnbm9yZS1jZXJ0aWZpY2F0ZS1lcnJvcnNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxuZm9yIHRoZSBsb2NhbCBuZ2lueCBjZXJ0ICsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiLS1kaXNhYmxlLWZlYXR1cmVzPUxvY2FsTmV0d29ya0FjY2Vzc0NoZWNrcyxCbG9ja0luc2VjdXJlUHJpdmF0ZU5ldHdvcmtSZXF1ZXN0c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCJcXG5mb3IgdGhlIGxvb3BiYWNrIHByb3ZpZGVyIGZldGNoKS4gVGhlIGFwcCByZW5kZXJzIGluIHRoZSBzYW5kYm94J3MgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJuZXN0ZWQgaWZyYW1lXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiLCBzbyBzY2FuXFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicGFnZS5mcmFtZXMoKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYW5kIHJlYWQgYSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJjb25zb2xlLmxvZ1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgbWFya2VyLiBLZWVwIGFueSBkcml2ZXItb25seSBkZXAgb3V0IG9mIHRoZSBzZXJ2ZWRcXG5hcHAncyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJwYWNrYWdlLmpzb25cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLiAoQSB3b3JrZWQgZXhhbXBsZSBsaXZlZCBpbiB0aGUgc2Vzc2lvbiBzY3JhdGNocGFkIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNlcy1zcGlrZS9cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLilcIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08X2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnA+PF9jb21wb25lbnRzLnN0cm9uZz57XCJSdW4gYW4gYXBwIG9uIHRoZSByZWFsIGhvc3Qgd2l0aCBubyBjb21taXQ6XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIFwifTxfY29tcG9uZW50cy5jb2RlPntcImltbWVkaWF0ZWx5LnJ1biBkZXYgLiAtLW9yaWdpbiBodHRwczovL2xvY2FsLmltbWVkaWF0ZWx5LnJ1biAtLWpzb25cIn08L19jb21wb25lbnRzLmNvZGU+e1wiXFxu4oaSIG9wZW4gdGhlIHByaW50ZWQgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiL2VkaXQv4oCmL2xpdmUjaXItZW5kcG9pbnQ94oCmJmlyLXRva2VuPeKAplwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgbGluay5cIn08L19jb21wb25lbnRzLnA+e1wiXFxuXCJ9PC9fY29tcG9uZW50cy5saT57XCJcXG5cIn08L19jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5ociAvPntcIlxcblwifTxfY29tcG9uZW50cy5oMiBpZD1cInNlYy01XCIgZGF0YS1zbHVnPVwiNS1kZWZlcnJlZC1pdGVtcy1yZWdpc3RyeS1ub3RlZC1pbi1jb2RlLWRvbnQtbG9zZS10aGVzZVwiPjxIZWFkaW5nQW5jaG9yIGlkPVwic2VjLTVcIiAvPntcIjUuIERlZmVycmVkLWl0ZW1zIHJlZ2lzdHJ5IChub3RlZCBpbiBjb2RlOyBkb24ndCBsb3NlIHRoZXNlKVwifTwvX2NvbXBvbmVudHMuaDI+e1wiXFxuXCJ9PF9jb21wb25lbnRzLnVsPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcInN0ZGxpYlwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgbm9uZSBvdXRzdGFuZGluZyAodGhlIHRhaWwg4oCUIHNjcmVlbmluZyArIFwifTxfY29tcG9uZW50cy5jb2RlPntcIndpbmRvdygpXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiDigJQgbGFuZGVkIGluICM3KS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcImRvY3VtZW50IG1vZGVsXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCBob3N0LXNpZGUgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY29tcGF0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBcIn08X2NvbXBvbmVudHMuZW0+e1wiZGVyaXZhdGlvblwifTwvX2NvbXBvbmVudHMuZW0+e1wiIGJ5IHN0YXRpYyBhbmFseXNpcyBhdCBzYXZlIHRpbWUgKHRoaXNcXG5tb2R1bGUgdmFsaWRhdGVzL3Jlc29sdmVzIGFuIGV4aXN0aW5nIGVudmVsb3BlKS4gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJDcm9zcy1yZWZlcmVuY2UgdmFsaWRhdGlvbiBzaGlwcGVkXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiXFxuKFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9kb2N1bWVudC94cmVmLnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIik6IGEgd29ya3NoZWV0IGV4dGVybmFsIG5hbWluZyBhIG1pc3NpbmcgZmVlZC9maXh0dXJlL3N0YXRpYyBpcyBhblxcblwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiZXJyb3JcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKGEgc2lsZW50LW51bGwgY2xhc3Mga2lsbGVkKTsgYSBwYXJhbSB3aXRoIG5vIGRlZmF1bHQgYW5kIG5vIHdpZGdldCBpcyBhXFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJ3YXJuaW5nXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiOyBmaXh0dXJlIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNvdXJjZUZlZWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNpdGF0aW9ucyB0aGUgZG9jdW1lbnQgZG9lc24ndCBkZWNsYXJlIGFyZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIndhcm5pbmdzXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiXFxuKGhpc3RvcmljYWwgcHJvdmVuYW5jZSDigJQgdGhlIGZyb3plbiBkZW1vIGxlZ2l0aW1hdGVseSBjaXRlcyBpdHMgY2FwdHVyZSBzb3VyY2UpLiBXaXJlZCBhdFxcbmxvYWQgKFwifTxfY29tcG9uZW50cy5jb2RlPntcInZhbGlkYXRlRml4dHVyZVByb3ZlbmFuY2VcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKSBhbmQgaW4gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wicmVwb3J0U2Vzc2lvblwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcInhyZWZEaWFnbm9zdGljc1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgb3ZlciB0aGVcXG5lbmdpbmUncyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJleHRlcm5hbFJlZmVyZW5jZXMoKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKyBtYW5pZmVzdCBwYXJhbXMgKyB0ZW1wbGF0ZSB3aWRnZXQgbmFtZXMgKyBydW50aW1lIGZlZWRzKTtcXG5lcnJvci1zZXZlcml0eSBkaWFnbm9zdGljcyByZW5kZXIgYXMgYSBub3RlIGFib3ZlIHRoZSByZXBvcnQuIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvZG9jdW1lbnQvaW5kZXgudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLilcIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcImVuZ2luZSBzY2hlZHVsZXJcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIg4oCUIHNoZWxsIEMgc2hpcHBlZCBzaW5nbGUtc2xvdCBzdXBlcnNlc3Npb24gKyB0aGUgd2F0Y2hkb2cgY2lyY3VpdFxcbmJyZWFrZXIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9lbmdpbmUvYXN5bmNFbmdpbmUudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY2lyY3VpdEJyZWFrZXIudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKS4gXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJHbGl0Y2gtZnJlZWRvbSAowqc0LjIgQy1SLUIpIGlzXFxuc2F0aXNmaWVkIGJ5IGNvbnN0cnVjdGlvbiArIHByb3ZlblwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiYXN5bmNFbmdpbmUuZ2xpdGNoLnRlc3QudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBzcGVjIMKnMTEgRS0yKTsgdGhlIGV4cGxpY2l0XFxucGVyLWNlbGwgZXBvY2gtZ2F0ZSBiYXJyaWVyIGlzIG5lZWRlZCBvbmx5IGlmIGNvbmN1cnJlbnQgYXJtIGV2YWx1YXRpb24gaXMgYWRkZWQgKGRlZmVycmVkXFxud29ya2VyIHBvb2wsIMKnNC4xKSDigJQgc2VlIHRoZSBcIn08X2NvbXBvbmVudHMuY29kZT57XCJhc3luY0VuZ2luZS50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgaGVhZGVyLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wiZW5naW5lIHNoZWxsXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCB3b3JrZXIgYnVpbHQgKyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIndpcmVkIGludG8gdGhlIGFwcFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAoXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQXN5bmNFbmdpbmVcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG5vdyBiYWNrc1xcblwifTxfY29tcG9uZW50cy5jb2RlPntcInJlcG9ydFNlc3Npb25cIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCByZWFsIFwifTxfY29tcG9uZW50cy5jb2RlPntcIldvcmtlclwifTwvX2NvbXBvbmVudHMuY29kZT57XCIrXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibG9ja2Rvd24oKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgd2l0aCBhbiBpbi1wcm9jZXNzIGZhbGxiYWNrKS4gSG9sZG91dC1maXh0dXJlXFxuXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJzdWJzdGl0dXRpb25cIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgdGVzdCBzZW1hbnRpY3MgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJzaGlwcGVkXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiOiBhIHRlc3QgZGVjbGFyaW5nIGl0cyBvd24gXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiaW5wdXRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBydW5zIHRoZVxcbnN1YmplY3Qgb3ZlciBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ7IC4uLmxpdmUsIC4uLmRlY2xhcmVkIH1cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChzYW1lLWxvY2FsLW5hbWUgb3ZlcnJpZGUsIHBhcnRpYWwgYWxsb3dlZDtcXG5uYW1lIG1pc21hdGNoIC8gdW5yZXNvbHZhYmxlIHJlZiAvIHN1YmplY3QgZXJyb3Igb3ZlciB0aGUgZml4dHVyZSBmYWlscyB0aGUgdGVzdCB3aXRoIGFcXG5tZXNzYWdlKSDigJQgdGhlIG1hcHBpbmcgaXMgcGlubmVkIGluIEFSQ0hJVEVDVFVSRV9QTEFOIMKnNi4gUmVtYWluaW5nOiB0aGUgdHJhbnNwaWxlZC1tb2R1bGVcXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImxpbmtlclwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAodGhlIGV2YWx1YXRvciB1c2VzIGEgc291cmNlIHRyYW5zZm9ybSArIFwifTxfY29tcG9uZW50cy5jb2RlPntcIkNvbXBhcnRtZW50LmV2YWx1YXRlXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIjsgaW4tcGxhdGZvcm0gdGhlXFxuc2FuZGJveCB0cmFuc3BpbGVzIGFuZCB0aGUgQ29tcGFydG1lbnQgbW9kdWxlIGxvYWRlciBsaW5rcykuIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvZW5naW5lL2VuZ2luZS50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiY29tcGFydG1lbnQudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLilcIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcInJlcG9ydFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgc2hlbGwgQSBzaGlwcGVkIHRoZSBjb21wb25lbnRzICsgTURYIHBhcnNlci4gUmVtYWluaW5nL2RlZmVycmVkIChpblxcblwifTxfY29tcG9uZW50cy5jb2RlPntcInNyYy9yZXBvcnQvcmVuZGVyL2luZGV4LnRzXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIik6IHRoZSBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImhvc3QtcmVuZGVyZWQgdGllciBiYWRnZVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAodGhlIHNsb3QgaXMgcmVzZXJ2ZWQsIHdlXFxuc3VwcGx5IHRoZSB2YWx1ZSk7IGEgcmVhbCBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcInBvbHlnb24tZ2VvZ3JhcGh5IE1hcFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAodjEgY2hvcm9wbGV0aCBzaGlwcyBhIHJlZ2lvbiBicmVha2Rvd24pO1xcblwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiS3BpIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNwYXJrXCJ9PC9fY29tcG9uZW50cy5jb2RlPjwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAobmVlZHMgYSBzZXJpZXMgYmluZGluZyB0aGUgdjEgY2F0YWxvZyBkb2Vzbid0IGNhcnJ5KTsgZnVsbCBDb21tb25NYXJrICtcXG5cIn08X2NvbXBvbmVudHMuc3Ryb25nPntcImlubGluZS1jb21wb25lbnQtaW4tcHJvc2VcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKHRoZSBwbGF0Zm9ybSBEMyByZW5kZXJlcidzIHJlbWl0IOKAlCBibG9jay1sZXZlbCBpcyBjb3ZlcmVkKS5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTxfY29tcG9uZW50cy5saT48X2NvbXBvbmVudHMuc3Ryb25nPntcImZlZWQgKE0yKVwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiDigJQgdGhlIGRhdGEtcGxhbmUgY29yZSArIGNvbm5lY3Rvci9cIn08X2NvbXBvbmVudHMuY29kZT57XCJGZWVkUnVudGltZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYXJlIGJ1aWx0IGFuZCB3aXJlZCBpbnRvIHRoZSBhcHBcXG4oIzE24oCTIzE4KSwgYW5kIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wid2luZG93ZWQgaW5wdXRzIHJlc29sdmVcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCIgKFwifTxfY29tcG9uZW50cy5jb2RlPntcInsgZmVlZCwgd2luZG93IH1cIn08L19jb21wb25lbnRzLmNvZGU+e1wiIG92ZXIgdGhlIGJ1ZmZlciB2aWEgdGhlIGVuZ2luZSdzXFxuaW5wdXQgcmVzb2x2ZXIg4oCUIHNlZSDCpzIpLiBSZW1haW5pbmcsIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wicGxhdGZvcm0tYmxvY2tlZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIjogdGhlIHJlYWwgaG9zdC1wcm94aWVkIGNvbm5lY3RvclxcbijCpzUuMSBTU1JGIGZldGNoKSArIE9QRlMgbWF0ZXJpYWxpemUtdG8tbW91bnQgdHJhbnNwb3J0ICjCpzUuMikuIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvZmVlZC9pbmRleC50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIuKVwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wicmVsYXRpb25zXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIOKAlCB0aGUgTTIgdGVzdCBydW5uZXIgc3VwcGxpZXMgdGhlIG1ldGFtb3JwaGljIHJlLWV2YWx1YXRpb247IHRoZSByZWxhdGlvblxcbmRlc2NyaXB0b3JzIGNhcnJ5IG9ubHkgdGhlaXIgcHVyZSB0cmFuc2Zvcm0gKyBjb21wYXJpc29uIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvc3RkbGliL3JlbGF0aW9ucy50c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1wicmV2aWV3IHN1cmZhY2UgKMKnNiwgYnJpZWYgc3VyZmFjZSAzKSDigJQgZmlyc3Qgc2xpY2Ugc2hpcHBlZFwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIjogdGhlIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wid29ya2Jvb2sgcGFuZWxcIn08L19jb21wb25lbnRzLnN0cm9uZz57XCJcXG4oXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wic3JjL2FwcC9Xb3JrYm9va1BhbmVsLnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgKyBcIn08X2NvbXBvbmVudHMuY29kZT57XCJXb3JrYm9va1BhbmVsQm9keS50c3hcIn08L19jb21wb25lbnRzLmNvZGU+e1wiKS4gT25lIGNhcmQgcGVyIGNlbGwgKG5hbWUsIFwifTxfY29tcG9uZW50cy5jb2RlPntcImRvY1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIsXFxudmFsdWUgcHJldmlldywgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJjb3ZlcmFnZS1zdGF0ZSBjaGlwXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiKSB3aXRoIHRlc3QgY2FyZHMgYmVuZWF0aCB0aGVpciBzdWJqZWN0IChraW5kIGxhYmVsICtcXG5wYXNzL2ZhaWwgKyBtZXNzYWdlKTsgdGhlIGZvdXIgc3RhdGVzIOKAlCB2YWxpZGF0ZWQgLyBwaW5uZWQgLyB1bnRlc3RlZCAvIGZhaWxpbmcg4oCUIGFyZVxcbnZpc3VhbGx5IGRpc3RpbmN0IGJ5IENTUyBjbGFzcyAowqc2OiBwaW5uZWQgbXVzdCBub3QgcmVhZCBhcyB0ZXN0ZWQpLiBFbmdpbmUgcGx1bWJpbmc6IHRoZVxcbndvcmtlciBrZWVwcyB0ZXN0IGRlZnMgKHRoZWlyIGNsb3N1cmVzIG5ldmVyIGNyb3NzIHRoZSB3aXJlIOKAlCBhIFwifTxfY29tcG9uZW50cy5jb2RlPntcInJ1bi10ZXN0c1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIgb3AgZXhlY3V0ZXNcXG50aGVtIGluIHRoZSBTRVMgcmVhbG0gb3ZlciBob3N0LWNvbXB1dGVkIGNvbnRleHRzIGFuZCByZXR1cm5zIHNlcmlhbGl6YWJsZSB2ZXJkaWN0cyk7XFxuXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiQXN5bmNFbmdpbmUucnVuVGVzdHMoKVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgcmlkZXMgYSB3YWxsLWNsb2NrIGJ1ZGdldCBsaWtlIFwifTxfY29tcG9uZW50cy5jb2RlPntcImV2YWxcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIChhIHdlZGdlZCBzdWl0ZSByZXN0YXJ0cyB0aGVcXG53b3JrZXIgYW5kIHJlamVjdHM7IHRoZSBwZXItY2VsbCBicmVha2VyIGRvZXMgbm90IHlldCBjb3VudCB0ZXN0LXJ1biB0ZXJtaW5hdGlvbnMg4oCUIGFcXG5ib29rZWQgcmVzaWR1YWwpLiBPcGVuZWQgZnJvbSB0aGUgcmVwb3J0IGhlYWRlciAoYXV0aG9yIHN1cmZhY2Ug4oCUIHZpZXdlcnMgbmV2ZXIgc2VlXFxud29ya3NoZWV0cywgYnJpZWYgQTMpLiBUaGUgZGVtbyB3b3Jrc2hlZXQgY2FycmllcyBhbiBob25lc3QgbWl4IChhIHNwZWNpZmljYXRpb24gdGVzdCDihpJcXG5cIn08X2NvbXBvbmVudHMuY29kZT57XCJwaW5uZWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiOyBhIHByb3BlcnR5IHJlbGF0aW9uIOKGkiBcIn08X2NvbXBvbmVudHMuY29kZT57XCJ2YWxpZGF0ZWRcIn08L19jb21wb25lbnRzLmNvZGU+e1wiOyB0aGUgcmVzdCBnZW51aW5lbHkgdW50ZXN0ZWQpLlwifTwvX2NvbXBvbmVudHMubGk+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmxpPjxfY29tcG9uZW50cy5zdHJvbmc+e1widmFsdWUgaW5zcGVjdG9yIOKAlCBmaXJzdCBzbGljZSBzaGlwcGVkXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvYXBwL1ZhbHVlSW5zcGVjdG9yLnRzeFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIsIGJyaWVmIHN1cmZhY2UgMik6XFxuYmluZGluZyBuYW1lLCBcIn08X2NvbXBvbmVudHMuY29kZT57XCJkb2NcIn08L19jb21wb25lbnRzLmNvZGU+e1wiLCBjdXJyZW50IHZhbHVlICsgdGllciAoXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJwbGFpbiBkYXRhIOKAlCB0aGUgdGllciBiYWRnZSBpcyBob3N0LWRyYXduXFxuY2hyb21lLCByZXZpZXctMSBIMjsgdGhlIGFwcCByZXNlcnZlcyB0aGUgc2xvdCwgbmV2ZXIgZHJhd3Mgb25lXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiKSwgcmVhZC1vbmx5IGZvcm11bGFcXG5zb3VyY2UgKFwifTxfY29tcG9uZW50cy5jb2RlPntcImZvcm11bGFTb3VyY2VcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIGNyb3NzZXMgdGhlIHdpcmUgYXMgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiRnVuY3Rpb24ucHJvdG90eXBlLnRvU3RyaW5nXCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBhdCB3b3JrZXJcXG5idWlsZCksIGRlY2xhcmVkLWlucHV0IGNoaXBzIChjZWxsIHJlZnMgbmF2aWdhYmxlIGhvcC1ieS1ob3Ag4oCUIHRoZSBWMyB3YWxrOyB3aW5kb3dlZC1mZWVkXFxuYW5kIHdpbGRjYXJkIGNoaXBzIGluZXJ0KSwgYW5kIHRoZSBjb3ZlcmFnZSBzdGF0ZSArIHRoaXMgY2VsbCdzIHRlc3Qgb3V0Y29tZXMuIE9wZW5zIGZyb21cXG53b3JrYm9vay1wYW5lbCBjYXJkIGNsaWNrcyAobWFzdGVyLWRldGFpbCBpbiB0aGUgcGFuZWwpLiBUaGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJwcmVjZWRlbnQtbmVpZ2hib3Job29kXFxudmlld1wifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiAocmV2aWV3LTEgVVgtNCkgc2hpcHBlZCB3aXRoIGl0IChcIn08X2NvbXBvbmVudHMuY29kZT57XCJzcmMvZW5naW5lL3ByZWNlZGVudHMudHNcIn08L19jb21wb25lbnRzLmNvZGU+e1wiICsgXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wiUHJlY2VkZW50Vmlld1wifTwvX2NvbXBvbmVudHMuY29kZT57XCIpOlxcbnRoZSB3aG9sZSBwcmVjZWRlbnQgc3ViZ3JhcGggYXQgb25jZSDigJQgdGhlIERBRyB1bnJvbGxlZCBhcyBhIHRyZWUsIGV4dGVybmFscyBhcyBsZWF2ZXMsXFxud2lsZGNhcmRzIGV4cGFuZGVkLCBub2RlLWNhcHBlZCB3aXRoIGFuIGhvbmVzdCB0cnVuY2F0aW9uIGZsYWcg4oCUIG5lc3RlZCBiZW5lYXRoIHRoZVxcbmluc3BlY3RvcidzIGNoaXBzLCBldmVyeSBjZWxsIG5vZGUgbmF2aWdhYmxlLiBUaGUgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJvbi1waXhlbCBhZmZvcmRhbmNlXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChWMylcXG5zaGlwcGVkIHdpdGggaXQ6IFwifTxfY29tcG9uZW50cy5jb2RlPntcIlJlcG9ydFZpZXdcIn08L19jb21wb25lbnRzLmNvZGU+e1wiIHRha2VzIGFuIG9wdGlvbmFsIGluc3BlY3Rpb24gcG9ydCDigJQgYm91bmQgZWxlbWVudHMgKGFcXG5saXRlcmFsIFwifTxfY29tcG9uZW50cy5jb2RlPntcInNvdXJjZVwifTwvX2NvbXBvbmVudHMuY29kZT57XCIgYXR0cikgZ2V0IGEgcXVpZXQgaG92ZXIvZm9jdXMtcmV2ZWFsIGNvcm5lciBidXR0b24gKGRlc2t0b3ApIGFuZCBhXFxufjQ1MG1zIGxvbmctcHJlc3Mgb3BlbnMgZGlyZWN0bHkgKHRvdWNoKTsgd2l0aG91dCB0aGUgcG9ydCwgcnVuIG1vZGUgcmVuZGVycyBleGFjdGx5IGFzXFxuYmVmb3JlIChubyBhZmZvcmRhbmNlLCBubyB0YXgpLiBUaGUgaW5zcGVjdGVkIGNlbGwgaXMgYXBwLWxldmVsIHN0YXRlIHNoYXJlZCBieSB0aGUgcGl4ZWxcXG5hZmZvcmRhbmNlIGFuZCB0aGUgcGFuZWwncyBjYXJkczsgdGhlIGluc3BlY3RvciByZW5kZXJzIGFzIGEgZG9ja2VkIGNhcmQgKGJvdHRvbS1yaWdodFxcbmRlc2t0b3AgLyBib3R0b20tc2hlZXQgcGhvbmUpLiBSZW1haW5pbmcgcmV2aWV3LXN1cmZhY2Ugd29yazogZWRpdC9hc2stYXNzaXN0YW50XFxuYWZmb3JkYW5jZXMgKG5lZWQgYSB3cml0YWJsZSBtb3VudCDigJQgcGxhdGZvcm0pLCBhbmQgcGVyLWNlbGwgdmVyZGljdCBtYXJrcyBpbnNpZGUgdGhlXFxucmVwb3J0IGl0c2VsZi5cIn08L19jb21wb25lbnRzLmxpPntcIlxcblwifTwvX2NvbXBvbmVudHMudWw+e1wiXFxuXCJ9PF9jb21wb25lbnRzLmgyIGlkPVwic2VjLTZcIiBkYXRhLXNsdWc9XCI2LWRvZ2Zvb2Rpbmctbm90ZS1heGlzLTJcIj48SGVhZGluZ0FuY2hvciBpZD1cInNlYy02XCIgLz57XCI2LiBEb2dmb29kaW5nIG5vdGUgKEF4aXMtMilcIn08L19jb21wb25lbnRzLmgyPntcIlxcblwifTxfY29tcG9uZW50cy5wPntcIlBlciDCpzAuMjogZG9jdW1lbnQgXCJ9PF9jb21wb25lbnRzLnN0cm9uZz57XCJjb250ZW50XCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIGlzIGZ1bGx5IGluLXBsYXRmb3JtIGF1dGhvcmFibGUgbm93IChTMSk7IGRvY3VtZW50IFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1widGVzdCBydW5zXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiXFxuYXJlIGluLXBsYXRmb3JtIGJ5IGNvbnN0cnVjdGlvbiBvbmNlIHRoZSBlbmdpbmUgcnVucyAoUzIpOyBcIn08X2NvbXBvbmVudHMuc3Ryb25nPntcIlM1IGlzIHByb3ZlblwifTwvX2NvbXBvbmVudHMuc3Ryb25nPntcIiBzbyB0aGUgZW5naW5lL2VkaXRvclxcblwifTxfY29tcG9uZW50cy5lbT57XCJzb3VyY2UgcmVhbG1zIGFyZSBidWlsZGFibGUgaW4tcGxhdGZvcm1cIn08L19jb21wb25lbnRzLmVtPntcIjsgdGhlIHJlbWFpbmluZyBzZWxmLWhvc3RpbmcgZ2FwIGlzIFwifTxfY29tcG9uZW50cy5zdHJvbmc+e1wiUzRiXCJ9PC9fY29tcG9uZW50cy5zdHJvbmc+e1wiIChhblxcbmluLXBsYXRmb3JtIE5vZGUtZXF1aXZhbGVudCBDSSBnYXRlIGZvciBcIn08X2NvbXBvbmVudHMuY29kZT57XCJidWlsZFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1wibGludFwifTwvX2NvbXBvbmVudHMuY29kZT57XCIvXCJ9PF9jb21wb25lbnRzLmNvZGU+e1widml0ZXN0XCJ9PC9fY29tcG9uZW50cy5jb2RlPntcIiBvZiB0aGUgVFMgc291cmNlKSDigJQgdW50aWwgaXRcXG5sYW5kcywgc291cmNlLWxldmVsIENJICh0aGUgdmVyaWZ5IGdhdGUgYWJvdmUpIHN0YXlzIGV4dGVybmFsLCB3aGljaCBpcyB0aGUgaG9uZXN0IGV4Y2VwdGlvbi5cIn08L19jb21wb25lbnRzLnA+PC8+O1xufVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTURYQ29udGVudChwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHt3cmFwcGVyOiBNRFhMYXlvdXR9ID0ge1xuICAgIC4uLl9wcm92aWRlQ29tcG9uZW50cygpLFxuICAgIC4uLnByb3BzLmNvbXBvbmVudHNcbiAgfTtcbiAgcmV0dXJuIE1EWExheW91dCA/IDxNRFhMYXlvdXQgey4uLnByb3BzfT48X2NyZWF0ZU1keENvbnRlbnQgey4uLnByb3BzfSAvPjwvTURYTGF5b3V0PiA6IF9jcmVhdGVNZHhDb250ZW50KHByb3BzKTtcbn1cbmZ1bmN0aW9uIF9taXNzaW5nTWR4UmVmZXJlbmNlKGlkLCBjb21wb25lbnQsIHBsYWNlKSB7XG4gIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIFwiICsgKGNvbXBvbmVudCA/IFwiY29tcG9uZW50XCIgOiBcIm9iamVjdFwiKSArIFwiIGBcIiArIGlkICsgXCJgIHRvIGJlIGRlZmluZWQ6IHlvdSBsaWtlbHkgZm9yZ290IHRvIGltcG9ydCwgcGFzcywgb3IgcHJvdmlkZSBpdC5cIiArIChwbGFjZSA/IFwiXFxuSXTigJlzIHJlZmVyZW5jZWQgaW4geW91ciBjb2RlIGF0IGBcIiArIHBsYWNlICsgXCJgIGluIGAvYXBwL2RvY3MvTTFfQlVJTERfSEFORE9GRi5tZGBcIiA6IFwiXCIpKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBRUEsSUFBQUEsWUFBQSxHQUFBQyxPQUFBO0FBQXdGLElBQUFDLFdBQUEsR0FBQUQsT0FBQTtBQUZ4RjtBQUNBOztBQUVBLFNBQVNFLGlCQUFpQkEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ2hDLE1BQU1DLFdBQVcsR0FBRztNQUNsQkMsQ0FBQyxFQUFFLEdBQUc7TUFDTkMsVUFBVSxFQUFFLFlBQVk7TUFDeEJDLElBQUksRUFBRSxNQUFNO01BQ1pDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLEVBQUUsRUFBRSxJQUFJO01BQ1JDLENBQUMsRUFBRSxHQUFHO01BQ05DLE1BQU0sRUFBRSxRQUFRO01BQ2hCQyxLQUFLLEVBQUUsT0FBTztNQUNkQyxLQUFLLEVBQUUsT0FBTztNQUNkQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxLQUFLLEVBQUUsT0FBTztNQUNkQyxFQUFFLEVBQUUsSUFBSTtNQUNSQyxFQUFFLEVBQUUsSUFBSTtNQUNSLEdBQUcsSUFBQUMsNkJBQWtCLEVBQUMsQ0FBQztNQUN2QixHQUFHcEIsS0FBSyxDQUFDcUI7SUFDWCxDQUFDO0lBQUU7TUFBQ0M7SUFBYSxDQUFDLEdBQUdyQixXQUFXO0VBQ2hDLElBQUksQ0FBQ3FCLGFBQWEsRUFBRUMsb0JBQW9CLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQztFQUMvRCxvQkFBTyxJQUFBekIsV0FBQSxDQUFBMEIsSUFBQSxFQUFBMUIsV0FBQSxDQUFBMkIsUUFBQTtJQUFBQyxRQUFBLGdCQUFFLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNLLEVBQUU7TUFBQ3FCLEVBQUUsRUFBQywyQkFBMkI7TUFBQUQsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUEyQixDQUFFLENBQUMsRUFBQyw2QkFBNkI7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNVLENBQUM7TUFBQWUsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFVLENBQXFCLENBQUMsRUFBQyxtU0FBbVMsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFVLENBQXFCLENBQUMsRUFBQyxhQUFhO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDRSxVQUFVO01BQUF1QixRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNVLENBQUM7UUFBQWUsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUF3QixDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUF1QixDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFzQixDQUFtQixDQUFDLEVBQUMsa0hBQWtILGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQWlDLENBQW1CLENBQUMsRUFBQyx5QkFBeUIsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBb0MsQ0FBbUIsQ0FBQyxFQUFDLDRDQUE0QyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUErQixDQUFtQixDQUFDLEVBQUMsMENBQTBDLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQXNCLENBQW1CLENBQUMsRUFBQyxTQUFTLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBeUIsQ0FBcUIsQ0FBQztNQUFBLENBQWUsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUF5QixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNRLEVBQUUsSUFBRSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUFYLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ00sRUFBRTtNQUFDb0IsRUFBRSxFQUFDLE9BQU87TUFBQyxhQUFVLCtFQUErRTtNQUFBRCxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMsc0ZBQXNGO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDVSxDQUFDO01BQUFlLFFBQUEsR0FBRSxxTUFBcU0sZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsR0FBRSxxRUFBcUUsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBTSxDQUFtQixDQUFDO01BQUEsQ0FBb0IsQ0FBQyxFQUFDLDBDQUEwQyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQWtCLENBQXFCLENBQUMsRUFBQyw0QkFBNEIsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1FBQUFzQixRQUFBLEVBQUU7TUFBUSxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7UUFBQXNCLFFBQUEsRUFBRTtNQUFVLENBQW1CLENBQUMsRUFBQyxNQUFNLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBc0IsUUFBQSxFQUFFO01BQWMsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1FBQUFzQixRQUFBLEVBQUU7TUFBZSxDQUFtQixDQUFDLEVBQUMsc0hBQXNIO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDWSxLQUFLO01BQUFhLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2dCLEtBQUs7UUFBQVMsUUFBQSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNpQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2UsRUFBRTtZQUFBVSxRQUFBLEVBQUU7VUFBTSxDQUFpQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDZSxFQUFFO1lBQUFVLFFBQUEsRUFBRTtVQUFPLENBQWlCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNlLEVBQUU7WUFBQVUsUUFBQSxFQUFFO1VBQWtCLENBQWlCLENBQUM7UUFBQSxDQUFnQjtNQUFDLENBQW1CLENBQUMsbUJBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNhLEtBQUs7UUFBQVksUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDaUIsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFRLENBQXFCLENBQUMsRUFBQyxhQUFhO1VBQUEsQ0FBaUIsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQWEsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsR0FBRSxzQ0FBc0MsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO2NBQUFzQixRQUFBLEVBQUU7WUFBUyxDQUFtQixDQUFDLEVBQUMscUNBQXFDLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQVEsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO2NBQUFzQixRQUFBLEVBQUU7WUFBUSxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFNLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQVMsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO2NBQUFzQixRQUFBLEVBQUU7WUFBUSxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFNLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQVUsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO2NBQUFzQixRQUFBLEVBQUU7WUFBTyxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFNLENBQW1CLENBQUMsRUFBQyxrQkFBa0IsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO2NBQUFzQixRQUFBLEVBQUU7WUFBSyxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFNLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQVEsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO2NBQUFzQixRQUFBLEVBQUU7WUFBTyxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFLLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQUssQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO2NBQUFzQixRQUFBLEVBQUU7WUFBVSxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFPLENBQW1CLENBQUMsRUFBQyxjQUFjLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQUssQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO2NBQUFzQixRQUFBLEVBQUU7WUFBTSxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFNLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQVEsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO2NBQUFzQixRQUFBLEVBQUU7WUFBUSxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFLLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQVUsQ0FBbUIsQ0FBQyxFQUFDLFlBQVksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO2NBQUFzQixRQUFBLEVBQUU7WUFBVSxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFXLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQWMsQ0FBbUIsQ0FBQyxFQUFDLGNBQWMsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO2NBQUFzQixRQUFBLEVBQUU7WUFBVSxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFTLENBQW1CLENBQUMsRUFBQyxnQkFBZ0IsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO2NBQUFzQixRQUFBLEVBQUU7WUFBTyxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFVLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQVEsQ0FBbUIsQ0FBQyxFQUFDLGdCQUFnQixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFVLENBQW1CLENBQUMsRUFBQyxTQUFTLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQVEsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO2NBQUFzQixRQUFBLEVBQUU7WUFBWSxDQUFtQixDQUFDLEVBQUMscUNBQXFDLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQVksQ0FBbUIsQ0FBQyxFQUFDLDRCQUE0QixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFjLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQXVCLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQWlCLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQVUsQ0FBbUIsQ0FBQyxFQUFDLGlCQUFpQixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFhLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQWEsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO2NBQUFzQixRQUFBLEVBQUU7WUFBVyxDQUFtQixDQUFDLEVBQUMsOEJBQThCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQVMsQ0FBbUIsQ0FBQyxFQUFDLFlBQVksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO2NBQUFzQixRQUFBLEVBQUU7WUFBcUIsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFnQixDQUFxQjtVQUFDLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFlLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFlLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQWUsQ0FBbUIsQ0FBQyxFQUFDLHVCQUF1QixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFpQixDQUFtQixDQUFDLEVBQUMsMEJBQTBCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQW1CLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQTRCLENBQW1CLENBQUMsRUFBQyx1QkFBdUIsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO2NBQUFzQixRQUFBLEVBQUU7WUFBZSxDQUFtQixDQUFDLEVBQUMscUNBQXFDLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQVEsQ0FBbUIsQ0FBQyxFQUFDLFdBQVc7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFRLENBQXFCO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQWEsQ0FBbUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsR0FBRSxtQkFBbUIsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO2NBQUFzQixRQUFBLEVBQUU7WUFBWSxDQUFtQixDQUFDLEVBQUMsZ0RBQWdELGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQVMsQ0FBbUIsQ0FBQyxFQUFDLGtDQUFrQyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFXLENBQW1CLENBQUMsRUFBQyxhQUFhLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQU0sQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO2NBQUFzQixRQUFBLEVBQUU7WUFBVyxDQUFtQixDQUFDLEVBQUMsMkJBQTJCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQWMsQ0FBbUIsQ0FBQyxFQUFDLG1DQUFtQyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFTLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQWMsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO2NBQUFzQixRQUFBLEVBQUU7WUFBVSxDQUFtQixDQUFDLEVBQUMscUJBQXFCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBZSxDQUFxQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFtQixDQUFtQixDQUFDLEVBQUMsaUNBQWlDLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQWdCLENBQW1CLENBQUMsRUFBQyxVQUFVLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQVEsQ0FBbUIsQ0FBQyxFQUFDLGlCQUFpQixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFXLENBQW1CLENBQUMsRUFBQyw4QkFBOEI7VUFBQSxDQUFpQixDQUFDO1FBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2lCLEVBQUU7VUFBQVEsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUE2QixDQUFxQjtVQUFDLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFhLENBQW1CO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEdBQUUsK0JBQStCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQVUsQ0FBbUIsQ0FBQyxFQUFDLGdDQUFnQyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFZLENBQW1CLENBQUMsRUFBQyxzREFBc0QsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO2NBQUFzQixRQUFBLEVBQUU7WUFBa0IsQ0FBbUIsQ0FBQyxFQUFDLG1FQUFtRTtVQUFBLENBQWlCLENBQUM7UUFBQSxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDaUIsRUFBRTtVQUFBUSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNjLEVBQUU7WUFBQVcsUUFBQSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQTJCLENBQXFCO1VBQUMsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFvQixDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFtQixDQUFtQixDQUFDO1VBQUEsQ0FBZ0IsQ0FBQyxtQkFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLEdBQUUsbUNBQW1DLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQVksQ0FBbUIsQ0FBQyxFQUFDLGtCQUFrQixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFnQixDQUFtQixDQUFDLEVBQUMscURBQXFELGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQVEsQ0FBbUIsQ0FBQyxFQUFDLHdCQUF3QixlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNXLE1BQU07Y0FBQWMsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO2dCQUFBc0IsUUFBQSxFQUFFO2NBQVUsQ0FBbUIsQ0FBQyxFQUFDLE9BQU87WUFBQSxDQUFxQixDQUFDLEVBQUMsMEZBQTBGLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQUssQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO2NBQUFzQixRQUFBLEVBQUU7WUFBTyxDQUFtQixDQUFDLEVBQUMsd0ZBQXdGLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQU8sQ0FBbUIsQ0FBQyxFQUFDLGVBQWUsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO2NBQUFzQixRQUFBLEVBQUU7WUFBTyxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFRLENBQW1CLENBQUMsRUFBQyxzQkFBc0IsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO2NBQUFzQixRQUFBLEVBQUU7WUFBTyxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFLLENBQW1CLENBQUMsRUFBQywwQ0FBMEMsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO2NBQUFzQixRQUFBLEVBQUU7WUFBUyxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFTLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQUssQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO2NBQUFzQixRQUFBLEVBQUU7WUFBVyxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFXLENBQW1CLENBQUMsRUFBQyxnQ0FBZ0MsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO2NBQUFzQixRQUFBLEVBQUU7WUFBUSxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFRLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQVEsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO2NBQUFzQixRQUFBLEVBQUU7WUFBTyxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFXLENBQW1CLENBQUMsRUFBQywyR0FBMkcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO2NBQUFjLFFBQUEsRUFBRTtZQUFVLENBQXFCLENBQUMsRUFBQyxrRkFBa0YsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO2NBQUFzQixRQUFBLEVBQUU7WUFBYyxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFrQixDQUFtQixDQUFDLEVBQUMsd0RBQXdELGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBaUIsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO2NBQUFzQixRQUFBLEVBQUU7WUFBbUIsQ0FBbUIsQ0FBQyxFQUFDLDJEQUEyRCxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFrQixDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFpQixDQUFtQixDQUFDLEVBQUMsNENBQTRDLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBZSxDQUFxQixDQUFDLEVBQUMsdUJBQXVCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0ksRUFBRTtjQUFBcUIsUUFBQSxFQUFFO1lBQXFCLENBQWlCLENBQUMsRUFBQywrRkFBK0YsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO2NBQUFzQixRQUFBLEVBQUU7WUFBTyxDQUFtQixDQUFDLEVBQUMscUJBQXFCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQTRCLENBQW1CLENBQUMsRUFBQyxJQUFJO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUMsbUJBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNpQixFQUFFO1VBQUFRLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ2MsRUFBRTtZQUFBVyxRQUFBLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtjQUFBYyxRQUFBLEVBQUU7WUFBcUIsQ0FBcUI7VUFBQyxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQVUsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO2NBQUFzQixRQUFBLEVBQUU7WUFBVyxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUF3QixDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFTLENBQW1CLENBQUM7VUFBQSxDQUFnQixDQUFDLG1CQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDYyxFQUFFO1lBQUFXLFFBQUEsR0FBRSx1QkFBdUIsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO2NBQUFzQixRQUFBLEVBQUU7WUFBb0IsQ0FBbUIsQ0FBQyxFQUFDLG9DQUFvQyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFjLENBQW1CLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQWMsQ0FBbUIsQ0FBQyxFQUFDLE1BQU0sZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO2NBQUFzQixRQUFBLEVBQUU7WUFBb0IsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO2NBQUFzQixRQUFBLEVBQUU7WUFBSyxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFlLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQWMsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO2NBQUFzQixRQUFBLEVBQUU7WUFBaUIsQ0FBbUIsQ0FBQyxFQUFDLFVBQVUsZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDVyxNQUFNO2NBQUFjLFFBQUEsR0FBRSxTQUFTLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtnQkFBQXNCLFFBQUEsRUFBRTtjQUFVLENBQW1CLENBQUMsRUFBQyxVQUFVO1lBQUEsQ0FBcUIsQ0FBQyxFQUFDLDZCQUE2QixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUFTLENBQW1CLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQVUsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO2NBQUFzQixRQUFBLEVBQUU7WUFBZSxDQUFtQixDQUFDLEVBQUMsaUJBQWlCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQVcsQ0FBbUIsQ0FBQyxFQUFDLDJCQUEyQixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07Y0FBQWMsUUFBQSxFQUFFO1lBQWUsQ0FBcUIsQ0FBQyxFQUFDLG9EQUFvRCxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUF1QixDQUFtQixDQUFDLEVBQUMsaUNBQWlDO1VBQUEsQ0FBaUIsQ0FBQztRQUFBLENBQWdCLENBQUM7TUFBQSxDQUFtQixDQUFDO0lBQUEsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDVSxDQUFDO01BQUFlLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBdUIsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1FBQUFzQixRQUFBLEVBQUU7TUFBb0MsQ0FBbUIsQ0FBQyxFQUFDLGlGQUFpRixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7UUFBQXNCLFFBQUEsRUFBRTtNQUFhLENBQW1CLENBQUMsRUFBQyxvRUFBb0UsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1FBQUFzQixRQUFBLEVBQUU7TUFBeUIsQ0FBbUIsQ0FBQyxFQUFDLG1FQUFtRSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7UUFBQXNCLFFBQUEsRUFBRTtNQUFLLENBQW1CLENBQUMsRUFBQyxXQUFXO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDUSxFQUFFLElBQUUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBWCxXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNNLEVBQUU7TUFBQ29CLEVBQUUsRUFBQyxPQUFPO01BQUMsYUFBVSwwREFBMEQ7TUFBQUQsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLCtEQUErRDtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZSxRQUFBLEdBQUUsc0JBQXNCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBeUMsQ0FBcUIsQ0FBQyxFQUFDLFlBQVksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQVMsQ0FBbUIsQ0FBQyxFQUFDLHlEQUF5RDtNQUFBLENBQXFCLENBQUMsRUFBQyxjQUFjLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBd0IsQ0FBcUIsQ0FBQyxFQUFDLGlNQUFpTSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQXdDLENBQXFCLENBQUMsRUFBQyx1QkFBdUIsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1FBQUFzQixRQUFBLEVBQUU7TUFBVSxDQUFtQixDQUFDLEVBQUMsZ0dBQWdHLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBc0IsUUFBQSxFQUFFO01BQXVCLENBQW1CLENBQUMsRUFBQyxnREFBZ0QsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1FBQUFzQixRQUFBLEVBQUU7TUFBTSxDQUFtQixDQUFDLEVBQUMsaURBQWlELGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBbUMsQ0FBcUIsQ0FBQztJQUFBLENBQWUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVSxDQUFDO01BQUFlLFFBQUEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsR0FBRSxpQ0FBaUMsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsMkNBQTJDLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQU0sQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7TUFBQSxDQUFxQjtJQUFDLENBQWUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDa0IsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNTLEVBQUU7UUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBc0IsQ0FBcUIsQ0FBQyxFQUFDLHNDQUFzQyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFPLENBQW1CLENBQUMsRUFBQyxvQkFBb0IsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBaUIsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBVSxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFTLENBQW1CLENBQUMsRUFBQywrQkFBK0IsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsK0RBQStELGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQTBCLENBQW1CLENBQUMsRUFBQyxrQkFBa0I7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNTLEVBQUU7UUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEdBQUUsbUJBQW1CLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBc0IsUUFBQSxFQUFFO1VBQWEsQ0FBbUIsQ0FBQztRQUFBLENBQW9CLENBQUMsRUFBQyxnQ0FBZ0MsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsZUFBZSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFpQixDQUFtQixDQUFDLEVBQUMsa0JBQWtCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQWtCLENBQW1CLENBQUMsRUFBQyxzRUFBc0UsZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsR0FBRSxZQUFZLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBc0IsUUFBQSxFQUFFO1VBQWUsQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7UUFBQSxDQUFxQixDQUFDLEVBQUMsb0VBQW9FLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBUyxDQUFtQixDQUFDLEVBQUMsdUJBQXVCO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUyxFQUFFO1FBQUFnQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQThCLENBQXFCLENBQUMsRUFBQyxxQ0FBcUMsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBcUIsQ0FBbUIsQ0FBQyxFQUFDLFNBQVMsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBb0IsQ0FBbUIsQ0FBQyxFQUFDLHFDQUFxQyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyxVQUFVLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQyxFQUFDLDJMQUEyTCxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNJLEVBQUU7VUFBQXFCLFFBQUEsR0FBRSxxSkFBcUosZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1lBQUFzQixRQUFBLEVBQUU7VUFBbUIsQ0FBbUIsQ0FBQyxFQUFDLElBQUk7UUFBQSxDQUFpQixDQUFDO01BQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUyxFQUFFO1FBQUFnQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXVCLENBQXFCLENBQUMsRUFBQyx3SEFBd0g7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNTLEVBQUU7UUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBZ0MsQ0FBcUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBa0IsQ0FBbUIsQ0FBQyxFQUFDLG1GQUFtRixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyx5QkFBeUIsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFlLENBQXFCLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQW9CLENBQW1CLENBQUMsRUFBQyxtRUFBbUUsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBZSxDQUFtQixDQUFDLEVBQUMsMkJBQTJCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQVksQ0FBbUIsQ0FBQyxFQUFDLHNEQUFzRCxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFlLENBQW1CLENBQUMsRUFBQyxXQUFXLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQVUsQ0FBbUIsQ0FBQyxFQUFDLGtDQUFrQyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFJLENBQW1CLENBQUMsRUFBQyxnQkFBZ0IsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBSSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFLLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQVksQ0FBbUIsQ0FBQyxFQUFDLDhMQUE4TCxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUF3QixDQUFtQixDQUFDLEVBQUMsOEJBQThCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQUksQ0FBbUIsQ0FBQyxFQUFDLDBFQUEwRSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyxHQUFHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUk7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNVLENBQUM7TUFBQWUsUUFBQSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQXNDLENBQXFCO0lBQUMsQ0FBZSxDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNrQixFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1MsRUFBRTtRQUFBZ0IsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFpQyxDQUFxQixDQUFDLEVBQUMsb0RBQW9ELGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBc0MsQ0FBcUIsQ0FBQyxFQUFDLFdBQVcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDSSxFQUFFO1VBQUFxQixRQUFBLEVBQUU7UUFBbUIsQ0FBaUIsQ0FBQyxFQUFDLDZFQUE2RSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyxnREFBZ0Q7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZSxRQUFBLEdBQUUsTUFBTSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7UUFBQXNCLFFBQUEsRUFBRTtNQUFtQixDQUFtQixDQUFDLEVBQUMscUJBQXFCO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDTyxFQUFFO01BQUNtQixFQUFFLEVBQUMsa0ZBQWtGO01BQUFELFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBa0YsQ0FBRSxDQUFDLEVBQUMscURBQXFELGVBQUMsSUFBQTdCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBTSxDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7UUFBQXNCLFFBQUEsRUFBRTtNQUFtQixDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7UUFBQXNCLFFBQUEsRUFBRTtNQUFrQixDQUFtQixDQUFDLEVBQUMsR0FBRztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZSxRQUFBLEdBQUUseUJBQXlCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBc0IsUUFBQSxFQUFFO01BQVksQ0FBbUIsQ0FBQyxFQUFDLHFLQUFxSyxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBVSxDQUFtQixDQUFDLEVBQUMsT0FBTztNQUFBLENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBc0IsUUFBQSxFQUFFO01BQStCLENBQW1CLENBQUMsRUFBQyxNQUFNLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBc0IsUUFBQSxFQUFFO01BQXlDLENBQW1CLENBQUMsRUFBQyxPQUFPLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBc0IsUUFBQSxFQUFFO01BQXVCLENBQW1CLENBQUMsRUFBQyx1QkFBdUIsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1FBQUFzQixRQUFBLEVBQUU7TUFBVSxDQUFtQixDQUFDLEVBQUMsOEJBQThCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBc0IsUUFBQSxFQUFFO01BQVksQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1FBQUFzQixRQUFBLEVBQUU7TUFBUSxDQUFtQixDQUFDLEVBQUMsZ0dBQWdHLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBc0IsUUFBQSxFQUFFO01BQTRCLENBQW1CLENBQUMsRUFBQywrREFBK0QsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1FBQUFzQixRQUFBLEVBQUU7TUFBTyxDQUFtQixDQUFDLEVBQUMsd0RBQXdEO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDTyxFQUFFO01BQUNtQixFQUFFLEVBQUMsdUZBQXVGO01BQUFELFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBdUYsQ0FBRSxDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUE3QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7UUFBQXNCLFFBQUEsRUFBRTtNQUFTLENBQW1CLENBQUMsRUFBQyw0Q0FBNEMsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFNLENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBc0IsUUFBQSxFQUFFO01BQVMsQ0FBbUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1FBQUFzQixRQUFBLEVBQUU7TUFBVSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7UUFBQXNCLFFBQUEsRUFBRTtNQUF3QixDQUFtQixDQUFDLEVBQUMsR0FBRztJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1UsQ0FBQztNQUFBZSxRQUFBLEdBQUUsbURBQW1ELGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBc0IsUUFBQSxFQUFFO01BQVMsQ0FBbUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1FBQUFzQixRQUFBLEVBQUU7TUFBVyxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7UUFBQXNCLFFBQUEsRUFBRTtNQUFvQixDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7UUFBQXNCLFFBQUEsRUFBRTtNQUEwQixDQUFtQixDQUFDLEVBQUMsd0NBQXdDLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBc0IsUUFBQSxFQUFFO01BQWMsQ0FBbUIsQ0FBQyxFQUFDLDhCQUE4QixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7UUFBQXNCLFFBQUEsRUFBRTtNQUF5QixDQUFtQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7UUFBQXNCLFFBQUEsRUFBRTtNQUFvQixDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7UUFBQXNCLFFBQUEsRUFBRTtNQUF1QixDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7UUFBQXNCLFFBQUEsRUFBRTtNQUFlLENBQW1CLENBQUMsRUFBQyxNQUFNLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBc0IsUUFBQSxFQUFFO01BQStCLENBQW1CLENBQUMsRUFBQyxxQ0FBcUMsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1FBQUFzQixRQUFBLEVBQUU7TUFBaUIsQ0FBbUIsQ0FBQyxFQUFDLFVBQVUsZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQVUsQ0FBbUIsQ0FBQyxFQUFDLDBCQUEwQjtNQUFBLENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBc0IsUUFBQSxFQUFFO01BQWlCLENBQW1CLENBQUMsRUFBQyxzQ0FBc0MsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1FBQUFzQixRQUFBLEVBQUU7TUFBZSxDQUFtQixDQUFDLEVBQUMscUNBQXFDLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBc0IsUUFBQSxFQUFFO01BQVksQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1FBQUFzQixRQUFBLEVBQUU7TUFBVSxDQUFtQixDQUFDLEVBQUMsWUFBWSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7UUFBQXNCLFFBQUEsRUFBRTtNQUFTLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBc0IsUUFBQSxFQUFFO01BQU8sQ0FBbUIsQ0FBQyxFQUFDLE1BQU0sZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1FBQUFzQixRQUFBLEVBQUU7TUFBdUIsQ0FBbUIsQ0FBQyxFQUFDLDJCQUEyQixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7UUFBQXNCLFFBQUEsRUFBRTtNQUFvQixDQUFtQixDQUFDLEVBQUMsK0JBQStCO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDa0IsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNTLEVBQUU7UUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBbUIsQ0FBcUIsQ0FBQyxFQUFDLE1BQU0sZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQW1CLENBQXFCLENBQUMsRUFBQyw2QkFBNkIsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBYSxDQUFtQixDQUFDLEVBQUMsMkJBQTJCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQWlCLENBQW1CLENBQUMsRUFBQyxvREFBb0QsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBUyxDQUFtQixDQUFDLEVBQUMsMEVBQTBFLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQXlCLENBQW1CLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQXFDLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBcUIsQ0FBcUIsQ0FBQyxFQUFDLEtBQUssZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBTSxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFrQixDQUFtQixDQUFDLEVBQUMsMkdBQTJHO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUyxFQUFFO1FBQUFnQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQWdCLENBQXFCLENBQUMsRUFBQyw2QkFBNkIsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDSSxFQUFFO1VBQUFxQixRQUFBLEVBQUU7UUFBb0IsQ0FBaUIsQ0FBQyxFQUFDLGlIQUFpSCxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFnQixDQUFtQixDQUFDLEVBQUMsc0JBQXNCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQUksQ0FBbUIsQ0FBQyxFQUFDLFNBQVMsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsa0JBQWtCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLFlBQVk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNTLEVBQUU7UUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBZSxDQUFxQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQyx3VUFBd1U7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ08sRUFBRTtNQUFDbUIsRUFBRSxFQUFDLHdHQUF3RztNQUFBRCxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQXdHLENBQUUsQ0FBQyxFQUFDLDRCQUE0QixlQUFDLElBQUE3QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQTJCLENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBc0IsUUFBQSxFQUFFO01BQW9CLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBc0IsUUFBQSxFQUFFO01BQTJCLENBQW1CLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBc0IsUUFBQSxFQUFFO01BQXFCLENBQW1CLENBQUMsRUFBQyxHQUFHO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDVSxDQUFDO01BQUFlLFFBQUEsR0FBRSxzREFBc0QsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1FBQUFzQixRQUFBLEVBQUU7TUFBd0IsQ0FBbUIsQ0FBQyxFQUFDLGVBQWUsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1FBQUFzQixRQUFBLEVBQUU7TUFBaUIsQ0FBbUIsQ0FBQyxFQUFDLFFBQVEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1FBQUFzQixRQUFBLEVBQUU7TUFBWSxDQUFtQixDQUFDLEVBQUMsZUFBZSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7UUFBQXNCLFFBQUEsRUFBRTtNQUFPLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBc0IsUUFBQSxFQUFFO01BQU0sQ0FBbUIsQ0FBQyxFQUFDLFFBQVEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1FBQUFzQixRQUFBLEVBQUU7TUFBYSxDQUFtQixDQUFDLEVBQUMsZ0RBQWdELGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBc0IsUUFBQSxFQUFFO01BQWEsQ0FBbUIsQ0FBQyxFQUFDLDBFQUEwRSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7UUFBQXNCLFFBQUEsRUFBRTtNQUFpQixDQUFtQixDQUFDLEVBQUMsK0VBQStFO0lBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDa0IsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNTLEVBQUU7UUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBMEIsQ0FBcUIsQ0FBQyxFQUFDLDBGQUEwRixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQywyQkFBMkIsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLHFCQUFxQixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyxZQUFZLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBYSxDQUFxQixDQUFDLEVBQUMsNENBQTRDLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBZ0IsQ0FBcUIsQ0FBQyxFQUFDLHFKQUFxSjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1MsRUFBRTtRQUFBZ0IsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUE0QyxDQUFxQixDQUFDLEVBQUMsaUJBQWlCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQVUsQ0FBbUIsQ0FBQyxFQUFDLHlMQUF5TDtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1MsRUFBRTtRQUFBZ0IsUUFBQSxHQUFFLDJCQUEyQixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFZLENBQW1CLENBQUMsRUFBQyw2QkFBNkIsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsd0NBQXdDLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLG1DQUFtQztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDVSxDQUFDO01BQUFlLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBMkUsQ0FBcUIsQ0FBQyxFQUFDLDZNQUE2TSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7UUFBQXNCLFFBQUEsRUFBRTtNQUE0QixDQUFtQixDQUFDLEVBQUMsNEdBQTRHLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBc0IsUUFBQSxFQUFFO01BQVEsQ0FBbUIsQ0FBQyxFQUFDLDhCQUE4QixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQXlHLENBQXFCLENBQUMsRUFBQyw2SkFBNkosZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1FBQUFjLFFBQUEsRUFBRTtNQUFpQixDQUFxQixDQUFDLEVBQUMsVUFBVSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7UUFBQXNCLFFBQUEsRUFBRTtNQUFhLENBQW1CLENBQUMsRUFBQyxRQUFRLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBc0IsUUFBQSxFQUFFO01BQVMsQ0FBbUIsQ0FBQyxFQUFDLHlCQUF5QixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7UUFBQXNCLFFBQUEsRUFBRTtNQUFRLENBQW1CLENBQUMsRUFBQyw0RkFBNEYsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1FBQUFzQixRQUFBLEVBQUU7TUFBUSxDQUFtQixDQUFDLEVBQUMseUJBQXlCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBc0IsUUFBQSxFQUFFO01BQWlCLENBQW1CLENBQUMsRUFBQyxVQUFVLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBc0IsUUFBQSxFQUFFO01BQVksQ0FBbUIsQ0FBQyxFQUFDLGdNQUFnTTtJQUFBLENBQWdCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1EsRUFBRSxJQUFFLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQVgsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDTSxFQUFFO01BQUNvQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUsbUNBQW1DO01BQUFELFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQyxzQ0FBc0M7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNrQixFQUFFO01BQUFPLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1MsRUFBRTtRQUFBZ0IsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFXLENBQXFCLENBQUMsRUFBQyxPQUFPLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQW1CLENBQW1CLENBQUMsRUFBQyx1Q0FBdUMsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUF5QixDQUFxQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyx1S0FBdUssZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBTSxDQUFtQixDQUFDLEVBQUMsNEJBQTRCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQU0sQ0FBbUIsQ0FBQyxFQUFDLEdBQUc7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNTLEVBQUU7UUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBb0MsQ0FBcUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBWSxDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQyxjQUFjLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQWMsQ0FBbUIsQ0FBQyxFQUFDLDhCQUE4QixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFlLENBQW1CLENBQUMsRUFBQyxzQkFBc0I7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNTLEVBQUU7UUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBc0IsQ0FBcUIsQ0FBQyxFQUFDLGdCQUFnQixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFvQixDQUFtQixDQUFDLEVBQUMsT0FBTyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFNLENBQW1CLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQVcsQ0FBbUIsQ0FBQyxFQUFDLGtFQUFrRSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFzQixDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyxnQkFBZ0IsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBb0IsQ0FBbUIsQ0FBQyxFQUFDLGlCQUFpQixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFpQixDQUFtQixDQUFDLEVBQUMsUUFBUSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFTLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQU8sQ0FBbUIsQ0FBQyxFQUFDLG1DQUFtQyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFLLENBQW1CLENBQUMsRUFBQyxlQUFlLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQTRCLENBQW1CLENBQUMsRUFBQyxJQUFJO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUyxFQUFFO1FBQUFnQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQW9DLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0ksRUFBRTtVQUFBcUIsUUFBQSxFQUFFO1FBQThGLENBQWlCLENBQUMsRUFBQyw4RkFBOEYsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsc0JBQXNCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQVksQ0FBbUIsQ0FBQyxFQUFDLDJCQUEyQixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFnQixDQUFtQixDQUFDLEVBQUMscUJBQXFCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQWEsQ0FBbUIsQ0FBQyxFQUFDLDJHQUEyRztNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1MsRUFBRTtRQUFBZ0IsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFzRCxDQUFxQixDQUFDLEVBQUMsTUFBTSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUF1QixDQUFtQixDQUFDLEVBQUMsU0FBUyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFpQixDQUFtQixDQUFDLEVBQUMsaUZBQWlGO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUyxFQUFFO1FBQUFnQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQVcsQ0FBcUIsQ0FBQyxFQUFDLHVEQUF1RCxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFTLENBQW1CLENBQUMsRUFBQywrR0FBK0c7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSTtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1EsRUFBRSxJQUFFLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQVgsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDTSxFQUFFO01BQUNvQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUsZUFBZTtNQUFBRCxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUNOLGFBQWE7UUFBQ0ssRUFBRSxFQUFDO01BQU8sQ0FBRSxDQUFDLEVBQUMsZ0JBQWdCO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBN0IsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDa0IsRUFBRTtNQUFBTyxRQUFBLEdBQUUsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNTLEVBQUU7UUFBQWdCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1UsQ0FBQztVQUFBZSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07WUFBQWMsUUFBQSxFQUFFO1VBQTRGLENBQXFCLENBQUMsRUFBQyxtRkFBbUYsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1lBQUFzQixRQUFBLEVBQUU7VUFBMkMsQ0FBbUIsQ0FBQyxFQUFDLDRGQUE0RixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7WUFBQXNCLFFBQUEsRUFBRTtVQUFhLENBQW1CLENBQUMsRUFBQyw4RUFBOEUsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1lBQUFzQixRQUFBLEVBQUU7VUFBK0IsQ0FBbUIsQ0FBQyxFQUFDLDJIQUEySCxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7WUFBQXNCLFFBQUEsRUFBRTtVQUFzQixDQUFtQixDQUFDLEVBQUMsNENBQTRDLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBc0IsUUFBQSxFQUFFO1VBQWUsQ0FBbUIsQ0FBQyxFQUFDLDJHQUEyRyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7WUFBQXNCLFFBQUEsRUFBRTtVQUFnQyxDQUFtQixDQUFDLEVBQUMsb0dBQW9HLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1csTUFBTTtZQUFBYyxRQUFBLEdBQUUsYUFBYSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNDLENBQUM7Y0FBQzJCLElBQUksRUFBQyxzRUFBc0U7Y0FBQUgsUUFBQSxFQUFFO1lBQXNFLENBQWdCLENBQUMsRUFBQyxxQ0FBcUM7VUFBQSxDQUFxQixDQUFDLEVBQUMsOEVBQThFO1FBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNTLEVBQUU7UUFBQWdCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1UsQ0FBQztVQUFBZSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNXLE1BQU07WUFBQWMsUUFBQSxHQUFFLGdDQUFnQyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7Y0FBQXNCLFFBQUEsRUFBRTtZQUF1QixDQUFtQixDQUFDLEVBQUMsT0FBTztVQUFBLENBQXFCLENBQUMsRUFBQyxhQUFhLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBc0IsUUFBQSxFQUFFO1VBQXFCLENBQW1CLENBQUMsRUFBQyxZQUFZLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBc0IsUUFBQSxFQUFFO1VBQXNCLENBQW1CLENBQUMsRUFBQyxVQUFVLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBc0IsUUFBQSxFQUFFO1VBQU0sQ0FBbUIsQ0FBQyxFQUFDLHdEQUF3RCxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7WUFBQXNCLFFBQUEsRUFBRTtVQUFPLENBQW1CLENBQUMsRUFBQyxjQUFjLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBc0IsUUFBQSxFQUFFO1VBQXdCLENBQW1CLENBQUMsRUFBQyxLQUFLLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBc0IsUUFBQSxFQUFFO1VBQU8sQ0FBbUIsQ0FBQyxFQUFDLGFBQWEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1lBQUFzQixRQUFBLEVBQUU7VUFBeUMsQ0FBbUIsQ0FBQyxFQUFDLHdCQUF3QixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7WUFBQXNCLFFBQUEsRUFBRTtVQUFPLENBQW1CLENBQUMsRUFBQyxrQkFBa0IsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1lBQUFzQixRQUFBLEVBQUU7VUFBTyxDQUFtQixDQUFDLEVBQUMsaUNBQWlDO1FBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNTLEVBQUU7UUFBQWdCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1UsQ0FBQztVQUFBZSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07WUFBQWMsUUFBQSxFQUFFO1VBQXFCLENBQXFCLENBQUMsRUFBQyxpRkFBaUYsZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDVyxNQUFNO1lBQUFjLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtjQUFBc0IsUUFBQSxFQUFFO1lBQWdCLENBQW1CLENBQUMsRUFBQyxrQkFBa0I7VUFBQSxDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7WUFBQXNCLFFBQUEsRUFBRTtVQUFxQixDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7WUFBQXNCLFFBQUEsRUFBRTtVQUE2QixDQUFtQixDQUFDLEVBQUMsK0JBQStCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBc0IsUUFBQSxFQUFFO1VBQWlGLENBQW1CLENBQUMsRUFBQyx1RUFBdUUsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1lBQUFjLFFBQUEsRUFBRTtVQUFlLENBQXFCLENBQUMsRUFBQyxhQUFhLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBc0IsUUFBQSxFQUFFO1VBQWUsQ0FBbUIsQ0FBQyxFQUFDLGNBQWMsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1lBQUFzQixRQUFBLEVBQUU7VUFBYSxDQUFtQixDQUFDLEVBQUMsNkRBQTZELGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBc0IsUUFBQSxFQUFFO1VBQWMsQ0FBbUIsQ0FBQyxFQUFDLHNEQUFzRCxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7WUFBQXNCLFFBQUEsRUFBRTtVQUFZLENBQW1CLENBQUMsRUFBQyxJQUFJO1FBQUEsQ0FBZ0IsQ0FBQyxFQUFDLElBQUk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNTLEVBQUU7UUFBQWdCLFFBQUEsR0FBRSxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1UsQ0FBQztVQUFBZSxRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07WUFBQWMsUUFBQSxFQUFFO1VBQTZDLENBQXFCLENBQUMsRUFBQyxHQUFHLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBc0IsUUFBQSxFQUFFO1VBQXFFLENBQW1CLENBQUMsRUFBQyx1QkFBdUIsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1lBQUFzQixRQUFBLEVBQUU7VUFBdUMsQ0FBbUIsQ0FBQyxFQUFDLFFBQVE7UUFBQSxDQUFnQixDQUFDLEVBQUMsSUFBSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDUSxFQUFFLElBQUUsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBWCxXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNNLEVBQUU7TUFBQ29CLEVBQUUsRUFBQyxPQUFPO01BQUMsYUFBVSx5REFBeUQ7TUFBQUQsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDTixhQUFhO1FBQUNLLEVBQUUsRUFBQztNQUFPLENBQUUsQ0FBQyxFQUFDLDhEQUE4RDtJQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTdCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ2tCLEVBQUU7TUFBQU8sUUFBQSxHQUFFLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUyxFQUFFO1FBQUFnQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQVEsQ0FBcUIsQ0FBQyxFQUFDLDhDQUE4QyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFVLENBQW1CLENBQUMsRUFBQyxtQkFBbUI7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNTLEVBQUU7UUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBZ0IsQ0FBcUIsQ0FBQyxFQUFDLGVBQWUsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBUSxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNJLEVBQUU7VUFBQXFCLFFBQUEsRUFBRTtRQUFZLENBQWlCLENBQUMsRUFBQywyRkFBMkYsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFvQyxDQUFxQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFzQixDQUFtQixDQUFDLEVBQUMsc0VBQXNFLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBTyxDQUFxQixDQUFDLEVBQUMsNkVBQTZFLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBUyxDQUFxQixDQUFDLEVBQUMsWUFBWSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFZLENBQW1CLENBQUMsRUFBQyw4Q0FBOEMsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFVLENBQXFCLENBQUMsRUFBQyxxR0FBcUcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBMkIsQ0FBbUIsQ0FBQyxFQUFDLFdBQVcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBZSxDQUFtQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFpQixDQUFtQixDQUFDLEVBQUMsc0JBQXNCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQXNCLENBQW1CLENBQUMsRUFBQywrSEFBK0gsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBdUIsQ0FBbUIsQ0FBQyxFQUFDLElBQUk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNTLEVBQUU7UUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBa0IsQ0FBcUIsQ0FBQyxFQUFDLCtFQUErRSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUEyQixDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFtQixDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQW9FLENBQXFCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQTRCLENBQW1CLENBQUMsRUFBQywwSkFBMEosZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLFVBQVU7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNTLEVBQUU7UUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBYyxDQUFxQixDQUFDLEVBQUMsb0JBQW9CLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBb0IsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBYSxDQUFtQixDQUFDLEVBQUMsY0FBYyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFlLENBQW1CLENBQUMsRUFBQyxTQUFTLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQVEsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBWSxDQUFtQixDQUFDLEVBQUMsa0RBQWtELGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBYyxDQUFxQixDQUFDLEVBQUMsa0JBQWtCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBUyxDQUFxQixDQUFDLEVBQUMsNkJBQTZCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQVEsQ0FBbUIsQ0FBQyxFQUFDLDBCQUEwQixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUEwQixDQUFtQixDQUFDLEVBQUMscU9BQXFPLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBUSxDQUFxQixDQUFDLEVBQUMsNENBQTRDLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQXNCLENBQW1CLENBQUMsRUFBQyxtRkFBbUYsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBc0IsQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBZ0IsQ0FBbUIsQ0FBQyxFQUFDLElBQUk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNTLEVBQUU7UUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBUSxDQUFxQixDQUFDLEVBQUMsMEVBQTBFLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQTRCLENBQW1CLENBQUMsRUFBQyxTQUFTLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBMEIsQ0FBcUIsQ0FBQyxFQUFDLHdEQUF3RCxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXVCLENBQXFCLENBQUMsRUFBQyw4Q0FBOEMsZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsR0FBRSxNQUFNLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtZQUFBc0IsUUFBQSxFQUFFO1VBQU8sQ0FBbUIsQ0FBQztRQUFBLENBQW9CLENBQUMsRUFBQyw2RUFBNkUsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUEyQixDQUFxQixDQUFDLEVBQUMsK0RBQStEO01BQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDUyxFQUFFO1FBQUFnQixRQUFBLGdCQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQVcsQ0FBcUIsQ0FBQyxFQUFDLHFDQUFxQyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFhLENBQW1CLENBQUMsRUFBQyxvREFBb0QsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUF5QixDQUFxQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFrQixDQUFtQixDQUFDLEVBQUMsMEVBQTBFLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBa0IsQ0FBcUIsQ0FBQyxFQUFDLHNHQUFzRyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFtQixDQUFtQixDQUFDLEVBQUMsSUFBSTtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQTBCLElBQUEsRUFBQ3ZCLFdBQVcsQ0FBQ1MsRUFBRTtRQUFBZ0IsUUFBQSxnQkFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFXLENBQXFCLENBQUMsRUFBQyx3SUFBd0ksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBeUIsQ0FBbUIsQ0FBQyxFQUFDLElBQUk7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNTLEVBQUU7UUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBNEQsQ0FBcUIsQ0FBQyxFQUFDLFFBQVEsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFnQixDQUFxQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUEyQixDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUF1QixDQUFtQixDQUFDLEVBQUMsOEJBQThCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQUssQ0FBbUIsQ0FBQyxFQUFDLG9CQUFvQixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07VUFBQWMsUUFBQSxFQUFFO1FBQXFCLENBQXFCLENBQUMsRUFBQywyU0FBMlMsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBVyxDQUFtQixDQUFDLEVBQUMsdUdBQXVHLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQXdCLENBQW1CLENBQUMsRUFBQyxrQ0FBa0MsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBTSxDQUFtQixDQUFDLEVBQUMsc1NBQXNTLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQVEsQ0FBbUIsQ0FBQyxFQUFDLDBCQUEwQixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFXLENBQW1CLENBQUMsRUFBQyxpQ0FBaUM7TUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE1QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNTLEVBQUU7UUFBQWdCLFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBdUMsQ0FBcUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1VBQUFzQixRQUFBLEVBQUU7UUFBNEIsQ0FBbUIsQ0FBQyxFQUFDLHFDQUFxQyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFLLENBQW1CLENBQUMsRUFBQywwQkFBMEIsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUE0RyxDQUFxQixDQUFDLEVBQUMsZ0NBQWdDLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQWUsQ0FBbUIsQ0FBQyxFQUFDLHVCQUF1QixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUE2QixDQUFtQixDQUFDLEVBQUMsaVFBQWlRLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtVQUFBYyxRQUFBLEVBQUU7UUFBOEIsQ0FBcUIsQ0FBQyxFQUFDLG9DQUFvQyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUEwQixDQUFtQixDQUFDLEVBQUMsS0FBSyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFlLENBQW1CLENBQUMsRUFBQyxzT0FBc08sZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDVyxNQUFNO1VBQUFjLFFBQUEsRUFBRTtRQUFxQixDQUFxQixDQUFDLEVBQUMsMEJBQTBCLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtVQUFBc0IsUUFBQSxFQUFFO1FBQVksQ0FBbUIsQ0FBQyxFQUFDLGtFQUFrRSxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7VUFBQXNCLFFBQUEsRUFBRTtRQUFRLENBQW1CLENBQUMsRUFBQywwZ0JBQTBnQjtNQUFBLENBQWlCLENBQUMsRUFBQyxJQUFJO0lBQUEsQ0FBaUIsQ0FBQyxFQUFDLElBQUksZUFBQyxJQUFBNUIsV0FBQSxDQUFBMEIsSUFBQSxFQUFDdkIsV0FBVyxDQUFDTSxFQUFFO01BQUNvQixFQUFFLEVBQUMsT0FBTztNQUFDLGFBQVUsMEJBQTBCO01BQUFELFFBQUEsZ0JBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQ04sYUFBYTtRQUFDSyxFQUFFLEVBQUM7TUFBTyxDQUFFLENBQUMsRUFBQyw2QkFBNkI7SUFBQSxDQUFpQixDQUFDLEVBQUMsSUFBSSxlQUFDLElBQUE3QixXQUFBLENBQUEwQixJQUFBLEVBQUN2QixXQUFXLENBQUNVLENBQUM7TUFBQWUsUUFBQSxHQUFFLHFCQUFxQixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVMsQ0FBcUIsQ0FBQyxFQUFDLHNEQUFzRCxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQVcsQ0FBcUIsQ0FBQyxFQUFDLCtEQUErRCxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNXLE1BQU07UUFBQWMsUUFBQSxFQUFFO01BQWMsQ0FBcUIsQ0FBQyxFQUFDLHlCQUF5QixlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNJLEVBQUU7UUFBQXFCLFFBQUEsRUFBRTtNQUF5QyxDQUFpQixDQUFDLEVBQUMsc0NBQXNDLGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ1csTUFBTTtRQUFBYyxRQUFBLEVBQUU7TUFBSyxDQUFxQixDQUFDLEVBQUMsZ0RBQWdELGVBQUMsSUFBQTVCLFdBQUEsQ0FBQThCLEdBQUEsRUFBQzNCLFdBQVcsQ0FBQ0csSUFBSTtRQUFBc0IsUUFBQSxFQUFFO01BQU8sQ0FBbUIsQ0FBQyxFQUFDLEdBQUcsZUFBQyxJQUFBNUIsV0FBQSxDQUFBOEIsR0FBQSxFQUFDM0IsV0FBVyxDQUFDRyxJQUFJO1FBQUFzQixRQUFBLEVBQUU7TUFBTSxDQUFtQixDQUFDLEVBQUMsR0FBRyxlQUFDLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUMzQixXQUFXLENBQUNHLElBQUk7UUFBQXNCLFFBQUEsRUFBRTtNQUFRLENBQW1CLENBQUMsRUFBQyw4SEFBOEg7SUFBQSxDQUFnQixDQUFDO0VBQUEsQ0FBRSxDQUFDO0FBQzcvL0M7QUFDZSxTQUFTSSxVQUFVQSxDQUFDOUIsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFO0VBQzdDLE1BQU07SUFBQytCLE9BQU8sRUFBRUM7RUFBUyxDQUFDLEdBQUc7SUFDM0IsR0FBRyxJQUFBWiw2QkFBa0IsRUFBQyxDQUFDO0lBQ3ZCLEdBQUdwQixLQUFLLENBQUNxQjtFQUNYLENBQUM7RUFDRCxPQUFPVyxTQUFTLGdCQUFHLElBQUFsQyxXQUFBLENBQUE4QixHQUFBLEVBQUNJLFNBQVM7SUFBQSxHQUFLaEMsS0FBSztJQUFBMEIsUUFBQSxlQUFFLElBQUE1QixXQUFBLENBQUE4QixHQUFBLEVBQUM3QixpQkFBaUI7TUFBQSxHQUFLQztJQUFLLENBQUc7RUFBQyxDQUFXLENBQUMsR0FBR0QsaUJBQWlCLENBQUNDLEtBQUssQ0FBQztBQUNsSDtBQUFDaUMsRUFBQSxHQU51QkgsVUFBVTtBQU9sQyxTQUFTUCxvQkFBb0JBLENBQUNJLEVBQUUsRUFBRU8sU0FBUyxFQUFFQyxLQUFLLEVBQUU7RUFDbEQsTUFBTSxJQUFJQyxLQUFLLENBQUMsV0FBVyxJQUFJRixTQUFTLEdBQUcsV0FBVyxHQUFHLFFBQVEsQ0FBQyxHQUFHLElBQUksR0FBR1AsRUFBRSxHQUFHLG9FQUFvRSxJQUFJUSxLQUFLLEdBQUcscUNBQXFDLEdBQUdBLEtBQUssR0FBRyxzQ0FBc0MsR0FBRyxFQUFFLENBQUMsQ0FBQztBQUNoUTtBQUFDLElBQUFGLEVBQUE7QUFBQUksWUFBQSxDQUFBSixFQUFBIiwiaWdub3JlTGlzdCI6W119
_csbRefreshUtils.postlude(module);} finally {  window.$RefreshReg$ = prevRefreshReg;  window.$RefreshSig$ = prevRefreshSig;}